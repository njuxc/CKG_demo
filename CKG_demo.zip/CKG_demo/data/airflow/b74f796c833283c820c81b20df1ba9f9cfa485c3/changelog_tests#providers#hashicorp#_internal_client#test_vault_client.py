===
match
---
param [30387,30396]
param [30399,30408]
===
match
---
name: mock_client [3065,3076]
name: mock_client [3071,3082]
===
match
---
trailer [21387,21406]
trailer [21399,21418]
===
match
---
trailer [28807,28810]
trailer [28819,28822]
===
match
---
name: mock_client [14661,14672]
name: mock_client [14673,14684]
===
match
---
atom [38464,38494]
atom [38476,38506]
===
match
---
funcdef [26514,27180]
funcdef [26526,27192]
===
match
---
simple_stmt [24854,24895]
simple_stmt [24866,24907]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [18015,18079]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [18027,18091]
===
match
---
operator: = [33386,33387]
operator: = [33398,33399]
===
match
---
operator: = [42959,42960]
operator: = [42971,42972]
===
match
---
operator: = [7635,7636]
operator: = [7647,7648]
===
match
---
operator: = [4349,4350]
operator: = [4361,4362]
===
match
---
name: self [27315,27319]
name: self [27327,27331]
===
match
---
suite [14183,14444]
suite [14195,14456]
===
match
---
operator: , [23933,23934]
operator: , [23945,23946]
===
match
---
name: MagicMock [43422,43431]
name: MagicMock [43434,43443]
===
match
---
argument [13924,13943]
argument [13936,13955]
===
match
---
dotted_name [1484,1494]
dotted_name [1484,1494]
===
match
---
expr_stmt [6599,6629]
expr_stmt [6611,6641]
===
match
---
name: kv_engine_version [23430,23447]
name: kv_engine_version [23442,23459]
===
match
---
argument [28872,28886]
argument [28884,28898]
===
match
---
operator: = [23258,23259]
operator: = [23270,23271]
===
match
---
name: radius_secret [28580,28593]
name: radius_secret [28592,28605]
===
match
---
expr_stmt [24631,24659]
expr_stmt [24643,24671]
===
match
---
name: is_authenticated [19326,19342]
name: is_authenticated [19338,19354]
===
match
---
name: radius_host [41389,41400]
name: radius_host [41401,41412]
===
match
---
string: "token" [23892,23899]
string: "token" [23904,23911]
===
match
---
name: auth_type [11874,11883]
name: auth_type [11886,11895]
===
match
---
simple_stmt [12207,12344]
simple_stmt [12219,12356]
===
match
---
string: "pass" [21528,21534]
string: "pass" [21540,21546]
===
match
---
trailer [9640,9659]
trailer [9652,9671]
===
match
---
trailer [15192,15209]
trailer [15204,15221]
===
match
---
string: 'lease_id' [33103,33113]
string: 'lease_id' [33115,33125]
===
match
---
trailer [5546,5564]
trailer [5558,5576]
===
match
---
name: secret_path [43961,43972]
name: secret_path [43973,43984]
===
match
---
string: 'pass' [6014,6020]
string: 'pass' [6026,6032]
===
match
---
trailer [1356,1409]
trailer [1356,1409]
===
match
---
param [34527,34532]
param [34539,34544]
===
match
---
name: url [16572,16575]
name: url [16584,16587]
===
match
---
funcdef [41158,41804]
funcdef [41170,41816]
===
match
---
decorated [2842,3610]
decorated [2848,3622]
===
match
---
name: assert_called_with [3538,3556]
name: assert_called_with [3550,3568]
===
match
---
argument [42118,42139]
argument [42130,42151]
===
match
---
name: kv [28808,28810]
name: kv [28820,28822]
===
match
---
arglist [13569,13715]
arglist [13581,13727]
===
match
---
name: auth_type [22773,22782]
name: auth_type [22785,22794]
===
match
---
name: url [5076,5079]
name: url [5088,5091]
===
match
---
operator: = [12494,12495]
operator: = [12506,12507]
===
match
---
atom_expr [15033,15097]
atom_expr [15045,15109]
===
match
---
argument [27820,27841]
argument [27832,27853]
===
match
---
name: test_github_different_auth_mount_point [13372,13410]
name: test_github_different_auth_mount_point [13384,13422]
===
match
---
string: 'metadata' [38512,38522]
string: 'metadata' [38524,38534]
===
match
---
name: vault_client [5534,5546]
name: vault_client [5546,5558]
===
match
---
operator: = [5705,5706]
operator: = [5717,5718]
===
match
---
operator: , [31210,31211]
operator: , [31222,31223]
===
match
---
operator: , [39309,39310]
operator: , [39321,39322]
===
match
---
operator: == [26393,26395]
operator: == [26405,26407]
===
match
---
operator: , [10522,10523]
operator: , [10534,10535]
===
match
---
atom [30064,30094]
atom [30076,30106]
===
match
---
name: _VaultClient [39265,39277]
name: _VaultClient [39277,39289]
===
match
---
operator: , [12731,12732]
operator: , [12743,12744]
===
match
---
name: mock_hvac [25848,25857]
name: mock_hvac [25860,25869]
===
match
---
operator: { [38257,38258]
operator: { [38269,38270]
===
match
---
operator: = [17883,17884]
operator: = [17895,17896]
===
match
---
trailer [30462,30475]
trailer [30474,30487]
===
match
---
operator: = [4547,4548]
operator: = [4559,4560]
===
match
---
operator: , [42902,42903]
operator: , [42914,42915]
===
match
---
atom_expr [19955,19971]
atom_expr [19967,19983]
===
match
---
name: vault_client [4384,4396]
name: vault_client [4396,4408]
===
match
---
trailer [43874,43877]
trailer [43886,43889]
===
match
---
operator: , [1951,1952]
operator: , [1951,1952]
===
match
---
name: VaultError [43079,43089]
name: VaultError [43091,43101]
===
match
---
operator: = [24451,24452]
operator: = [24463,24464]
===
match
---
name: Client [24488,24494]
name: Client [24500,24506]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [8701,8765]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [8713,8777]
===
match
---
operator: = [40666,40667]
operator: = [40678,40679]
===
match
---
operator: = [40074,40075]
operator: = [40086,40087]
===
match
---
simple_stmt [13185,13230]
simple_stmt [13197,13242]
===
match
---
operator: , [22312,22313]
operator: , [22324,22325]
===
match
---
name: ldap [19226,19230]
name: ldap [19238,19242]
===
match
---
arglist [35405,35487]
arglist [35417,35499]
===
match
---
operator: = [21509,21510]
operator: = [21521,21522]
===
match
---
argument [1436,1455]
argument [1436,1455]
===
match
---
name: assert_called_with [15210,15228]
name: assert_called_with [15222,15240]
===
match
---
with_stmt [43060,43249]
with_stmt [43072,43261]
===
match
---
name: vault_client [23841,23853]
name: vault_client [23853,23865]
===
match
---
string: 'secret' [38954,38962]
string: 'secret' [38966,38974]
===
match
---
simple_stmt [2550,2579]
simple_stmt [2550,2579]
===
match
---
dotted_name [39009,39019]
dotted_name [39021,39031]
===
match
---
trailer [41682,41706]
trailer [41694,41718]
===
match
---
trailer [15049,15068]
trailer [15061,15080]
===
match
---
trailer [37317,37320]
trailer [37329,37332]
===
match
---
simple_stmt [11699,11751]
simple_stmt [11711,11763]
===
match
---
name: match [22693,22698]
name: match [22705,22710]
===
match
---
argument [38964,38978]
argument [38976,38990]
===
match
---
decorator [21686,21764]
decorator [21698,21776]
===
match
---
name: configure [7112,7121]
name: configure [7124,7133]
===
match
---
name: path [32693,32697]
name: path [32705,32709]
===
match
---
simple_stmt [31883,32240]
simple_stmt [31895,32252]
===
match
---
name: auth_mount_point [6940,6956]
name: auth_mount_point [6952,6968]
===
match
---
dictorsetmaker [12289,12303]
dictorsetmaker [12301,12315]
===
match
---
name: radius_port [27676,27687]
name: radius_port [27688,27699]
===
match
---
simple_stmt [17371,17465]
simple_stmt [17383,17477]
===
match
---
atom [30767,30797]
atom [30779,30809]
===
match
---
name: assert_called_with [20788,20806]
name: assert_called_with [20800,20818]
===
match
---
operator: = [33996,33997]
operator: = [34008,34009]
===
match
---
expr_stmt [17200,17230]
expr_stmt [17212,17242]
===
match
---
trailer [31533,31553]
trailer [31545,31565]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [31666,31730]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [31678,31742]
===
match
---
expr_stmt [8139,8182]
expr_stmt [8151,8194]
===
match
---
operator: , [36158,36159]
operator: , [36170,36171]
===
match
---
argument [11903,11936]
argument [11915,11948]
===
match
---
name: url [33579,33582]
name: url [33591,33594]
===
match
---
atom_expr [39265,39493]
atom_expr [39277,39505]
===
match
---
string: "pass" [7266,7272]
string: "pass" [7278,7284]
===
match
---
name: vault_client [15803,15815]
name: vault_client [15815,15827]
===
match
---
operator: = [21341,21342]
operator: = [21353,21354]
===
match
---
number: 1 [31637,31638]
number: 1 [31649,31650]
===
match
---
name: mock_client [31791,31802]
name: mock_client [31803,31814]
===
match
---
name: return_value [1303,1315]
name: return_value [1303,1315]
===
match
---
operator: , [39374,39375]
operator: , [39386,39387]
===
match
---
string: "pass" [20502,20508]
string: "pass" [20514,20520]
===
match
---
trailer [2666,2679]
trailer [2671,2679]
===
match
---
operator: = [29824,29825]
operator: = [29836,29837]
===
match
---
arglist [12885,12968]
arglist [12897,12980]
===
match
---
operator: , [27155,27156]
operator: , [27167,27168]
===
match
---
string: "value" [11928,11935]
string: "value" [11940,11947]
===
match
---
name: mock_client [41633,41644]
name: mock_client [41645,41656]
===
match
---
string: "kubernetes" [17394,17406]
string: "kubernetes" [17406,17418]
===
match
---
operator: , [11114,11115]
operator: , [11126,11127]
===
match
---
string: 'renewable' [29291,29302]
string: 'renewable' [29303,29314]
===
match
---
simple_stmt [9615,9710]
simple_stmt [9627,9722]
===
match
---
simple_stmt [21016,21047]
simple_stmt [21028,21059]
===
match
---
name: mock [41077,41081]
name: mock [41089,41093]
===
match
---
name: radius_secret [31289,31302]
name: radius_secret [31301,31314]
===
match
---
name: create_or_update_secret [43878,43901]
name: create_or_update_secret [43890,43913]
===
match
---
trailer [14030,14048]
trailer [14042,14060]
===
match
---
name: MagicMock [11627,11636]
name: MagicMock [11639,11648]
===
match
---
name: radius_host [39996,40007]
name: radius_host [40008,40019]
===
match
---
operator: , [10484,10485]
operator: , [10496,10497]
===
match
---
simple_stmt [25555,25600]
simple_stmt [25567,25612]
===
match
---
name: pytest [36883,36889]
name: pytest [36895,36901]
===
match
---
parameters [20989,21006]
parameters [21001,21018]
===
match
---
atom_expr [14629,14658]
atom_expr [14641,14670]
===
match
---
name: client [24833,24839]
name: client [24845,24851]
===
match
---
trailer [43431,43433]
trailer [43443,43445]
===
match
---
operator: = [7849,7850]
operator: = [7861,7862]
===
match
---
operator: = [6845,6846]
operator: = [6857,6858]
===
match
---
name: kv_engine_version [2115,2132]
name: kv_engine_version [2115,2132]
===
match
---
number: 2 [23412,23413]
number: 2 [23424,23425]
===
match
---
with_stmt [17714,17998]
with_stmt [17726,18010]
===
match
---
argument [43804,43827]
argument [43816,43839]
===
match
---
string: "user" [6288,6294]
string: "user" [6300,6306]
===
match
---
string: 'resource' [8351,8361]
string: 'resource' [8363,8373]
===
match
---
name: MagicMock [17642,17651]
name: MagicMock [17654,17663]
===
match
---
operator: = [19301,19302]
operator: = [19313,19314]
===
match
---
operator: , [36118,36119]
operator: , [36130,36131]
===
match
---
operator: = [8430,8431]
operator: = [8442,8443]
===
match
---
string: "radius" [33387,33395]
string: "radius" [33399,33407]
===
match
---
trailer [27396,27409]
trailer [27408,27421]
===
match
---
name: password [19273,19281]
name: password [19285,19293]
===
match
---
operator: } [40221,40222]
operator: } [40233,40234]
===
match
---
string: "pass" [29926,29932]
string: "pass" [29938,29944]
===
match
---
atom_expr [13743,13762]
atom_expr [13755,13774]
===
match
---
argument [43667,43686]
argument [43679,43698]
===
match
---
simple_stmt [1247,1278]
simple_stmt [1247,1278]
===
match
---
argument [22792,22819]
argument [22804,22831]
===
match
---
operator: , [1367,1368]
operator: , [1367,1368]
===
match
---
name: return_value [22627,22639]
name: return_value [22639,22651]
===
match
---
operator: = [8310,8311]
operator: = [8322,8323]
===
match
---
name: read_secret_version [29148,29167]
name: read_secret_version [29160,29179]
===
match
---
name: azure_resource [5897,5911]
name: azure_resource [5909,5923]
===
match
---
operator: = [36546,36547]
operator: = [36558,36559]
===
match
---
expr_stmt [27568,27778]
expr_stmt [27580,27790]
===
match
---
trailer [39879,39886]
trailer [39891,39898]
===
match
---
expr_stmt [42808,43051]
expr_stmt [42820,43063]
===
match
---
trailer [36269,36277]
trailer [36281,36289]
===
match
---
atom_expr [19596,19625]
atom_expr [19608,19637]
===
match
---
number: 1 [35090,35091]
number: 1 [35102,35103]
===
match
---
operator: , [22030,22031]
operator: , [22042,22043]
===
match
---
name: patch [11252,11257]
name: patch [11264,11269]
===
match
---
name: assert_called_with [10988,11006]
name: assert_called_with [11000,11018]
===
match
---
simple_stmt [5732,5776]
simple_stmt [5744,5788]
===
match
---
name: kv [34664,34666]
name: kv [34676,34678]
===
match
---
argument [5431,5450]
argument [5443,5462]
===
match
---
operator: , [30385,30386]
operator: , [30397,30398]
===
match
---
simple_stmt [39923,40134]
simple_stmt [39935,40146]
===
match
---
name: return_value [2373,2385]
name: return_value [2373,2385]
===
match
---
name: mock_client [27341,27352]
name: mock_client [27353,27364]
===
match
---
name: secret_path [39659,39670]
name: secret_path [39671,39682]
===
match
---
trailer [27952,27955]
trailer [27964,27967]
===
match
---
name: radius_port [28550,28561]
name: radius_port [28562,28573]
===
match
---
name: mock_client [29122,29133]
name: mock_client [29134,29145]
===
match
---
trailer [40589,40591]
trailer [40601,40603]
===
match
---
name: mock [14055,14059]
name: mock [14067,14071]
===
match
---
name: mock_get_scopes [10177,10192]
name: mock_get_scopes [10189,10204]
===
match
---
atom_expr [40974,41070]
atom_expr [40986,41082]
===
match
---
trailer [37024,37047]
trailer [37036,37059]
===
match
---
trailer [25837,25839]
trailer [25849,25851]
===
match
---
argument [38942,38962]
argument [38954,38974]
===
match
---
atom_expr [4989,5209]
atom_expr [5001,5221]
===
match
---
number: 8110 [29894,29898]
number: 8110 [29906,29910]
===
match
---
name: MagicMock [39177,39186]
name: MagicMock [39189,39198]
===
match
---
number: 8110 [40773,40777]
number: 8110 [40785,40789]
===
match
---
name: mock [19571,19575]
name: mock [19583,19587]
===
match
---
simple_stmt [18216,18347]
simple_stmt [18228,18359]
===
match
---
string: "radhost" [29859,29868]
string: "radhost" [29871,29880]
===
match
---
trailer [24114,24133]
trailer [24126,24145]
===
match
---
operator: , [34388,34389]
operator: , [34400,34401]
===
match
---
operator: = [12765,12766]
operator: = [12777,12778]
===
match
---
argument [17955,17982]
argument [17967,17994]
===
match
---
operator: @ [7959,7960]
operator: @ [7971,7972]
===
match
---
name: MagicMock [32897,32906]
name: MagicMock [32909,32918]
===
match
---
name: match [1369,1374]
name: match [1369,1374]
===
match
---
string: "pass" [38098,38104]
string: "pass" [38110,38116]
===
match
---
atom_expr [24018,24082]
atom_expr [24030,24094]
===
match
---
name: vault_client [24640,24652]
name: vault_client [24652,24664]
===
match
---
operator: , [32062,32063]
operator: , [32074,32075]
===
match
---
trailer [38881,38884]
trailer [38893,38896]
===
match
---
atom_expr [41535,41624]
atom_expr [41547,41636]
===
match
---
name: _VaultClient [10443,10455]
name: _VaultClient [10455,10467]
===
match
---
operator: = [33822,33823]
operator: = [33834,33835]
===
match
---
simple_stmt [25129,25160]
simple_stmt [25141,25172]
===
match
---
atom [8971,8991]
atom [8983,9003]
===
match
---
name: client [3302,3308]
name: client [3308,3314]
===
match
---
trailer [24027,24034]
trailer [24039,24046]
===
match
---
trailer [20602,20609]
trailer [20614,20621]
===
match
---
name: mock_client [31862,31873]
name: mock_client [31874,31885]
===
match
---
operator: @ [11246,11247]
operator: @ [11258,11259]
===
match
---
name: mock_client [20384,20395]
name: mock_client [20396,20407]
===
match
---
name: MagicMock [13456,13465]
name: MagicMock [13468,13477]
===
match
---
operator: = [2458,2459]
operator: = [2458,2459]
===
match
---
atom [31459,31489]
atom [31471,31501]
===
match
---
operator: == [5531,5533]
operator: == [5543,5545]
===
match
---
string: "http://localhost:8180" [22796,22819]
string: "http://localhost:8180" [22808,22831]
===
match
---
trailer [4901,4911]
trailer [4913,4923]
===
match
---
atom_expr [18231,18346]
atom_expr [18243,18358]
===
match
---
operator: = [30241,30242]
operator: = [30253,30254]
===
match
---
argument [14314,14367]
argument [14326,14379]
===
match
---
operator: , [7904,7905]
operator: , [7916,7917]
===
match
---
operator: = [19281,19282]
operator: = [19293,19294]
===
match
---
suite [17358,17465]
suite [17370,17477]
===
match
---
string: 'scope2' [10943,10951]
string: 'scope2' [10955,10963]
===
match
---
name: auth [19221,19225]
name: auth [19233,19237]
===
match
---
name: key_path [9455,9463]
name: key_path [9467,9475]
===
match
---
testlist_comp [12314,12332]
testlist_comp [12326,12344]
===
match
---
trailer [7584,7594]
trailer [7596,7606]
===
match
---
name: Client [1296,1302]
name: Client [1296,1302]
===
match
---
string: "pass" [42197,42203]
string: "pass" [42209,42215]
===
match
---
comparison [33697,33725]
comparison [33709,33737]
===
match
---
simple_stmt [43747,43844]
simple_stmt [43759,43856]
===
match
---
name: vault_client [18364,18376]
name: vault_client [18376,18388]
===
match
---
simple_stmt [24478,24522]
simple_stmt [24490,24534]
===
match
---
name: kv_engine_version [1457,1474]
name: kv_engine_version [1457,1474]
===
match
---
string: 'http://localhost:8180' [15916,15939]
string: 'http://localhost:8180' [15928,15951]
===
match
---
argument [14395,14413]
argument [14407,14425]
===
match
---
string: "/var/run/secrets/kubernetes.io/serviceaccount/token" [14970,15023]
string: "/var/run/secrets/kubernetes.io/serviceaccount/token" [14982,15035]
===
match
---
trailer [37320,37340]
trailer [37332,37352]
===
match
---
operator: , [42514,42515]
operator: , [42526,42527]
===
match
---
name: mock [32892,32896]
name: mock [32904,32908]
===
match
---
simple_stmt [19713,19797]
simple_stmt [19725,19809]
===
match
---
dictorsetmaker [11921,11935]
dictorsetmaker [11933,11947]
===
match
---
name: return_value [11664,11676]
name: return_value [11676,11688]
===
match
---
trailer [33745,33753]
trailer [33757,33765]
===
match
---
operator: = [38987,38988]
operator: = [38999,39000]
===
match
---
name: mock [1633,1637]
name: mock [1633,1637]
===
match
---
string: "radhost" [38031,38040]
string: "radhost" [38043,38052]
===
match
---
simple_stmt [3792,3836]
simple_stmt [3804,3848]
===
match
---
name: _VaultClient [1725,1737]
name: _VaultClient [1725,1737]
===
match
---
simple_stmt [16082,16125]
simple_stmt [16094,16137]
===
match
---
atom_expr [2356,2385]
atom_expr [2356,2385]
===
match
---
expr_stmt [40653,40863]
expr_stmt [40665,40875]
===
match
---
name: mock [835,839]
name: mock [835,839]
===
match
---
string: "token" [34126,34133]
string: "token" [34138,34145]
===
match
---
simple_stmt [25809,25840]
simple_stmt [25821,25852]
===
match
---
argument [18257,18273]
argument [18269,18285]
===
match
---
operator: = [41329,41330]
operator: = [41341,41342]
===
match
---
simple_stmt [18125,18156]
simple_stmt [18137,18168]
===
match
---
name: mock [18139,18143]
name: mock [18151,18155]
===
match
---
operator: @ [4731,4732]
operator: @ [4743,4744]
===
match
---
string: "kube_role" [16904,16915]
string: "kube_role" [16916,16927]
===
match
---
argument [30196,30216]
argument [30208,30228]
===
match
---
trailer [37340,37353]
trailer [37352,37365]
===
match
---
operator: = [31164,31165]
operator: = [31176,31177]
===
match
---
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [34153,34181]
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [34165,34193]
===
match
---
atom_expr [11699,11727]
atom_expr [11711,11739]
===
match
---
dotted_name [991,1048]
dotted_name [991,1048]
===
match
---
parameters [14165,14182]
parameters [14177,14194]
===
match
---
argument [9305,9332]
argument [9317,9344]
===
match
---
operator: , [37805,37806]
operator: , [37817,37818]
===
match
---
operator: , [38827,38828]
operator: , [38839,38840]
===
match
---
atom_expr [17239,17268]
atom_expr [17251,17280]
===
match
---
operator: = [42927,42928]
operator: = [42939,42940]
===
match
---
funcdef [28975,30257]
funcdef [28987,30269]
===
match
---
name: auth [9622,9626]
name: auth [9634,9638]
===
match
---
number: 1 [43685,43686]
number: 1 [43697,43698]
===
match
---
name: self [2291,2295]
name: self [2291,2295]
===
match
---
name: auth_type [32290,32299]
name: auth_type [32302,32311]
===
match
---
string: 'missing' [30223,30232]
string: 'missing' [30235,30244]
===
match
---
name: mock_get_scopes [11699,11714]
name: mock_get_scopes [11711,11726]
===
match
---
name: kv_engine_version [39422,39439]
name: kv_engine_version [39434,39451]
===
match
---
name: self [30381,30385]
name: self [30393,30397]
===
match
---
name: mock [4003,4007]
name: mock [4015,4019]
===
match
---
argument [27706,27726]
argument [27718,27738]
===
match
---
expr_stmt [33626,33681]
expr_stmt [33638,33693]
===
match
---
name: mock [26587,26591]
name: mock [26599,26603]
===
match
---
argument [22773,22790]
argument [22785,22802]
===
match
---
simple_stmt [34644,35356]
simple_stmt [34656,35368]
===
match
---
name: mock [27355,27359]
name: mock [27367,27371]
===
match
---
arglist [1357,1408]
arglist [1357,1408]
===
match
---
argument [33377,33395]
argument [33389,33407]
===
match
---
name: radius_port [22014,22025]
name: radius_port [22026,22037]
===
match
---
name: Client [21065,21071]
name: Client [21077,21083]
===
match
---
name: secret_id [2715,2724]
name: secret_id [2721,2730]
===
match
---
string: "secret" [27888,27896]
string: "secret" [27900,27908]
===
match
---
name: self [26547,26551]
name: self [26559,26563]
===
match
---
operator: = [19759,19760]
operator: = [19771,19772]
===
match
---
name: mock [34567,34571]
name: mock [34579,34583]
===
match
---
name: radius_secret [36764,36777]
name: radius_secret [36776,36789]
===
match
---
name: key_path [12260,12268]
name: key_path [12272,12280]
===
match
---
name: mock_hvac [5255,5264]
name: mock_hvac [5267,5276]
===
match
---
name: kv_engine_version [28614,28631]
name: kv_engine_version [28626,28643]
===
match
---
name: auth [7101,7105]
name: auth [7113,7117]
===
match
---
name: mock_hvac [26612,26621]
name: mock_hvac [26624,26633]
===
match
---
name: url [2623,2626]
name: url [2623,2626]
===
match
---
name: vault_client [10670,10682]
name: vault_client [10682,10694]
===
match
---
operator: = [27353,27354]
operator: = [27365,27366]
===
match
---
string: "airflow.providers.google.cloud.utils.credentials_provider._get_scopes" [11258,11329]
string: "airflow.providers.google.cloud.utils.credentials_provider._get_scopes" [11270,11341]
===
match
---
operator: = [6991,6992]
operator: = [7003,7004]
===
match
---
operator: , [5963,5964]
operator: , [5975,5976]
===
match
---
name: mock [16131,16135]
name: mock [16143,16147]
===
match
---
number: 4 [1475,1476]
number: 4 [1475,1476]
===
match
---
operator: = [33021,33022]
operator: = [33033,33034]
===
match
---
name: Client [14241,14247]
name: Client [14253,14259]
===
match
---
trailer [21380,21387]
trailer [21392,21399]
===
match
---
argument [10576,10603]
argument [10588,10615]
===
match
---
atom_expr [33734,33833]
atom_expr [33746,33845]
===
match
---
operator: @ [31654,31655]
operator: @ [31666,31667]
===
match
---
atom_expr [4922,4951]
atom_expr [4934,4963]
===
match
---
trailer [36304,36328]
trailer [36316,36340]
===
match
---
funcdef [2274,2837]
funcdef [2274,2843]
===
match
---
string: "radius" [37997,38005]
string: "radius" [38009,38017]
===
match
---
name: jwt [16917,16920]
name: jwt [16929,16932]
===
match
---
arglist [20714,20754]
arglist [20726,20766]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [39699,39763]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [39711,39775]
===
match
---
decorator [31654,31732]
decorator [31666,31744]
===
match
---
name: mount_point [36342,36353]
name: mount_point [36354,36365]
===
match
---
name: assert_called_with [13977,13995]
name: assert_called_with [13989,14007]
===
match
---
arglist [5015,5199]
arglist [5027,5211]
===
match
---
name: Client [13486,13492]
name: Client [13498,13504]
===
match
---
assert_stmt [20817,20859]
assert_stmt [20829,20871]
===
match
---
atom_expr [12046,12065]
atom_expr [12058,12077]
===
match
---
expr_stmt [43403,43433]
expr_stmt [43415,43445]
===
match
---
operator: = [43415,43416]
operator: = [43427,43428]
===
match
---
operator: , [33494,33495]
operator: , [33506,33507]
===
match
---
trailer [7111,7121]
trailer [7123,7133]
===
match
---
name: self [8074,8078]
name: self [8086,8090]
===
match
---
dotted_name [11444,11454]
dotted_name [11456,11466]
===
match
---
argument [2486,2513]
argument [2486,2513]
===
match
---
simple_stmt [32249,32493]
simple_stmt [32261,32505]
===
match
---
operator: , [23899,23900]
operator: , [23911,23912]
===
match
---
name: Client [17249,17255]
name: Client [17261,17267]
===
match
---
expr_stmt [17239,17282]
expr_stmt [17251,17294]
===
match
---
name: url [4448,4451]
name: url [4460,4463]
===
match
---
trailer [13121,13140]
trailer [13133,13152]
===
match
---
operator: , [35747,35748]
operator: , [35759,35760]
===
match
---
trailer [16863,16879]
trailer [16875,16891]
===
match
---
trailer [15955,15971]
trailer [15967,15983]
===
match
---
operator: = [14778,14779]
operator: = [14790,14791]
===
match
---
name: read_secret_version [27959,27978]
name: read_secret_version [27971,27990]
===
match
---
arglist [21505,21566]
arglist [21517,21578]
===
match
---
expr_stmt [31791,31821]
expr_stmt [31803,31833]
===
match
---
string: 'created_time' [37645,37659]
string: 'created_time' [37657,37671]
===
match
---
simple_stmt [22988,23032]
simple_stmt [23000,23044]
===
match
---
name: return_value [11780,11792]
name: return_value [11792,11804]
===
match
---
operator: = [9502,9503]
operator: = [9514,9515]
===
match
---
name: auth_type [35405,35414]
name: auth_type [35417,35426]
===
match
---
atom [43223,43239]
atom [43235,43251]
===
match
---
name: mock [4732,4736]
name: mock [4744,4748]
===
match
---
simple_stmt [24668,24733]
simple_stmt [24680,24745]
===
match
---
name: assert_called_with [15972,15990]
name: assert_called_with [15984,16002]
===
match
---
parameters [36507,36524]
parameters [36519,36536]
===
match
---
name: create_or_update_secret [41548,41571]
name: create_or_update_secret [41560,41583]
===
match
---
assert_stmt [24794,24845]
assert_stmt [24806,24857]
===
match
---
import_as_names [901,917]
import_as_names [901,917]
===
match
---
name: secret [43804,43810]
name: secret [43816,43822]
===
match
---
name: radius [21456,21462]
name: radius [21468,21474]
===
match
---
param [4101,4106]
param [4113,4118]
===
match
---
operator: } [43238,43239]
operator: } [43250,43251]
===
match
---
trailer [6647,6654]
trailer [6659,6666]
===
match
---
name: mock [25143,25147]
name: mock [25155,25159]
===
match
---
name: auth_type [12885,12894]
name: auth_type [12897,12906]
===
match
---
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [35430,35458]
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [35442,35470]
===
match
---
name: client [13185,13191]
name: client [13197,13203]
===
match
---
expr_stmt [14629,14672]
expr_stmt [14641,14684]
===
match
---
trailer [14608,14618]
trailer [14620,14630]
===
match
---
suite [16276,17054]
suite [16288,17066]
===
match
---
operator: = [39900,39901]
operator: = [39912,39913]
===
match
---
atom_expr [7605,7634]
atom_expr [7617,7646]
===
match
---
string: "pass" [2725,2731]
string: "pass" [2731,2737]
===
match
---
param [16265,16274]
param [16277,16286]
===
match
---
trailer [14831,14877]
trailer [14843,14889]
===
match
---
testlist_comp [10326,10344]
testlist_comp [10338,10356]
===
match
---
name: mock_hvac [18838,18847]
name: mock_hvac [18850,18859]
===
match
---
operator: = [20749,20750]
operator: = [20761,20762]
===
match
---
string: 'metadata' [30815,30825]
string: 'metadata' [30827,30837]
===
match
---
trailer [40609,40616]
trailer [40621,40628]
===
match
---
decorated [23505,24299]
decorated [23517,24311]
===
match
---
name: InvalidPath [28420,28431]
name: InvalidPath [28432,28443]
===
match
---
argument [14415,14442]
argument [14427,14454]
===
match
---
string: 'kube_role' [17884,17895]
string: 'kube_role' [17896,17907]
===
match
---
name: mock_client [28788,28799]
name: mock_client [28800,28811]
===
match
---
simple_stmt [9342,9394]
simple_stmt [9354,9406]
===
match
---
simple_stmt [16702,16731]
simple_stmt [16714,16743]
===
match
---
operator: == [24830,24832]
operator: == [24842,24844]
===
match
---
simple_stmt [39250,39494]
simple_stmt [39262,39506]
===
match
---
name: Client [13034,13040]
name: Client [13046,13052]
===
match
---
name: mock_hvac [20293,20302]
name: mock_hvac [20305,20314]
===
match
---
name: vault_client [7390,7402]
name: vault_client [7402,7414]
===
match
---
argument [43091,43144]
argument [43103,43156]
===
match
---
string: 'destroyed' [29580,29591]
string: 'destroyed' [29592,29603]
===
match
---
trailer [28726,28749]
trailer [28738,28761]
===
match
---
trailer [21355,21362]
trailer [21367,21374]
===
match
---
name: url [16820,16823]
name: url [16832,16835]
===
match
---
param [43377,43382]
param [43389,43394]
===
match
---
name: url [17436,17439]
name: url [17448,17451]
===
match
---
name: assert_called_with [9641,9659]
name: assert_called_with [9653,9671]
===
match
---
string: "http://localhost:8180" [36835,36858]
string: "http://localhost:8180" [36847,36870]
===
match
---
operator: } [11935,11936]
operator: } [11947,11948]
===
match
---
name: assert_called_with [9286,9304]
name: assert_called_with [9298,9316]
===
match
---
number: 2 [12588,12589]
number: 2 [12600,12601]
===
match
---
string: 'auth' [32216,32222]
string: 'auth' [32228,32234]
===
match
---
string: 'http://localhost:8180' [9309,9332]
string: 'http://localhost:8180' [9321,9344]
===
match
---
expr_stmt [26800,26933]
expr_stmt [26812,26945]
===
match
---
operator: = [20382,20383]
operator: = [20394,20395]
===
match
---
operator: = [19626,19627]
operator: = [19638,19639]
===
match
---
operator: , [11809,11810]
operator: , [11821,11822]
===
match
---
trailer [18143,18153]
trailer [18155,18165]
===
match
---
string: "scope1,scope2" [10806,10821]
string: "scope1,scope2" [10818,10833]
===
match
---
string: "pass" [19282,19288]
string: "pass" [19294,19300]
===
match
---
simple_stmt [3085,3294]
simple_stmt [3091,3300]
===
match
---
trailer [41252,41254]
trailer [41264,41266]
===
match
---
trailer [38218,38241]
trailer [38230,38253]
===
match
---
operator: , [33962,33963]
operator: , [33974,33975]
===
match
---
operator: , [34181,34182]
operator: , [34193,34194]
===
match
---
simple_stmt [41992,42036]
simple_stmt [42004,42048]
===
match
---
trailer [24487,24494]
trailer [24499,24506]
===
match
---
dictorsetmaker [35813,35974]
dictorsetmaker [35825,35986]
===
match
---
operator: , [29008,29009]
operator: , [29020,29021]
===
match
---
operator: , [42539,42540]
operator: , [42551,42552]
===
match
---
simple_stmt [24741,24786]
simple_stmt [24753,24798]
===
match
---
atom_expr [43852,44029]
atom_expr [43864,44041]
===
match
---
atom [37537,37839]
atom [37549,37851]
===
match
---
name: _VaultClient [33351,33363]
name: _VaultClient [33363,33375]
===
match
---
trailer [31846,31859]
trailer [31858,31871]
===
match
---
trailer [16981,17000]
trailer [16993,17012]
===
match
---
trailer [41652,41655]
trailer [41664,41667]
===
match
---
operator: = [6956,6957]
operator: = [6968,6969]
===
match
---
trailer [15859,15867]
trailer [15871,15879]
===
match
---
name: secret [32594,32600]
name: secret [32606,32612]
===
match
---
expr_stmt [4883,4913]
expr_stmt [4895,4925]
===
match
---
operator: = [30000,30001]
operator: = [30012,30013]
===
match
---
trailer [24097,24114]
trailer [24109,24126]
===
match
---
string: "custom" [1797,1805]
string: "custom" [1797,1805]
===
match
---
argument [40061,40081]
argument [40073,40093]
===
match
---
suite [27332,28077]
suite [27344,28089]
===
match
---
name: password [18990,18998]
name: password [19002,19010]
===
match
---
trailer [3418,3431]
trailer [3429,3437]
===
match
---
name: assert_called_with [22179,22197]
name: assert_called_with [22191,22209]
===
match
---
name: mock_hvac [18164,18173]
name: mock_hvac [18176,18185]
===
match
---
string: "Metadata might only be used with version 2 of the KV engine." [36915,36977]
string: "Metadata might only be used with version 2 of the KV engine." [36927,36989]
===
match
---
string: "role" [4288,4294]
string: "role" [4300,4306]
===
match
---
string: "custom" [1772,1780]
string: "custom" [1772,1780]
===
match
---
operator: , [35458,35459]
operator: , [35470,35471]
===
match
---
operator: , [40081,40082]
operator: , [40093,40094]
===
match
---
name: mock_client [4954,4965]
name: mock_client [4966,4977]
===
match
---
operator: } [29419,29420]
operator: } [29431,29432]
===
match
---
argument [16009,16019]
argument [16021,16031]
===
match
---
parameters [8783,8839]
parameters [8795,8851]
===
match
---
atom_expr [4141,4157]
atom_expr [4153,4169]
===
match
---
argument [32534,32555]
argument [32546,32567]
===
match
---
name: mock [2193,2197]
name: mock [2193,2197]
===
match
---
name: patch [16136,16141]
name: patch [16148,16153]
===
match
---
dotted_name [34414,34424]
dotted_name [34426,34436]
===
match
---
name: client [25555,25561]
name: client [25567,25573]
===
match
---
name: test_kubernetes [15373,15388]
name: test_kubernetes [15385,15400]
===
match
---
name: return_value [23005,23017]
name: return_value [23017,23029]
===
match
---
operator: = [21120,21121]
operator: = [21132,21133]
===
match
---
name: assert_called_once_with [31554,31577]
name: assert_called_once_with [31566,31589]
===
match
---
operator: = [18300,18301]
operator: = [18312,18313]
===
match
---
name: _VaultClient [16391,16403]
name: _VaultClient [16403,16415]
===
match
---
name: gcp_scopes [9158,9168]
name: gcp_scopes [9170,9180]
===
match
---
name: return_value [2029,2041]
name: return_value [2029,2041]
===
match
---
trailer [15128,15147]
trailer [15140,15159]
===
match
---
trailer [23868,23972]
trailer [23880,23984]
===
match
---
comparison [28765,28779]
comparison [28777,28791]
===
match
---
name: secrets [31520,31527]
name: secrets [31532,31539]
===
match
---
argument [22314,22323]
argument [22326,22335]
===
match
---
atom_expr [21585,21629]
atom_expr [21597,21641]
===
match
---
operator: , [23098,23099]
operator: , [23110,23111]
===
match
---
decorated [8492,9814]
decorated [8504,9826]
===
match
---
number: 1 [2151,2152]
number: 1 [2151,2152]
===
match
---
trailer [34039,34052]
trailer [34051,34064]
===
match
---
trailer [3591,3609]
trailer [3603,3621]
===
match
---
trailer [31553,31577]
trailer [31565,31589]
===
match
---
operator: , [27726,27727]
operator: , [27738,27739]
===
match
---
trailer [18481,18487]
trailer [18493,18499]
===
match
---
name: patch [18656,18661]
name: patch [18668,18673]
===
match
---
name: client [24653,24659]
name: client [24665,24671]
===
match
---
operator: , [19677,19678]
operator: , [19689,19690]
===
match
---
name: pytest [40877,40883]
name: pytest [40889,40895]
===
match
---
name: method [41056,41062]
name: method [41068,41074]
===
match
---
name: configure [22254,22263]
name: configure [22266,22275]
===
match
---
atom_expr [22963,22979]
atom_expr [22975,22991]
===
match
---
trailer [25479,25493]
trailer [25491,25505]
===
match
---
argument [34116,34133]
argument [34128,34145]
===
match
---
decorator [42568,42646]
decorator [42580,42658]
===
match
---
string: 'key' [43989,43994]
string: 'key' [44001,44006]
===
match
---
operator: = [6253,6254]
operator: = [6265,6266]
===
match
---
string: "path" [16514,16520]
string: "path" [16526,16532]
===
match
---
trailer [41343,41526]
trailer [41355,41538]
===
match
---
argument [36798,36817]
argument [36810,36829]
===
match
---
name: configure [20685,20694]
name: configure [20697,20706]
===
match
---
operator: = [18266,18267]
operator: = [18278,18279]
===
match
---
name: mock [24453,24457]
name: mock [24465,24469]
===
match
---
string: 'request_id' [29197,29209]
string: 'request_id' [29209,29221]
===
match
---
argument [31323,31350]
argument [31335,31362]
===
match
---
operator: } [32589,32590]
operator: } [32601,32602]
===
match
---
name: assert_called_with [21473,21491]
name: assert_called_with [21485,21503]
===
match
---
operator: , [26019,26020]
operator: , [26031,26032]
===
match
---
name: mock_hvac [34592,34601]
name: mock_hvac [34604,34613]
===
match
---
argument [17745,17783]
argument [17757,17795]
===
match
---
name: mock [4897,4901]
name: mock [4909,4913]
===
match
---
operator: = [1445,1446]
operator: = [1445,1446]
===
match
---
name: mock [1840,1844]
name: mock [1840,1844]
===
match
---
atom_expr [36883,36978]
atom_expr [36895,36990]
===
match
---
name: assert_called_with [7038,7056]
name: assert_called_with [7050,7068]
===
match
---
string: "other" [16551,16558]
string: "other" [16563,16570]
===
match
---
atom_expr [12792,12821]
atom_expr [12804,12833]
===
match
---
simple_stmt [4166,4210]
simple_stmt [4178,4222]
===
match
---
operator: = [8918,8919]
operator: = [8930,8931]
===
match
---
simple_stmt [13437,13468]
simple_stmt [13449,13480]
===
match
---
name: mock_hvac [8790,8799]
name: mock_hvac [8802,8811]
===
match
---
argument [8336,8361]
argument [8348,8373]
===
match
---
argument [19256,19271]
argument [19268,19283]
===
match
---
name: mock_hvac [13024,13033]
name: mock_hvac [13036,13045]
===
match
---
name: vault_client [42808,42820]
name: vault_client [42820,42832]
===
match
---
operator: @ [41076,41077]
operator: @ [41088,41089]
===
match
---
name: pytest [14288,14294]
name: pytest [14300,14306]
===
match
---
operator: = [37996,37997]
operator: = [38008,38009]
===
match
---
argument [32387,32407]
argument [32399,32419]
===
match
---
name: Client [12802,12808]
name: Client [12814,12820]
===
match
---
string: "key" [11921,11926]
string: "key" [11933,11938]
===
match
---
operator: = [2132,2133]
operator: = [2132,2133]
===
match
---
name: raises [8203,8209]
name: raises [8215,8221]
===
match
---
atom_expr [27380,27409]
atom_expr [27392,27421]
===
match
---
name: self [4101,4105]
name: self [4113,4117]
===
match
---
trailer [1275,1277]
trailer [1275,1277]
===
match
---
name: mock_client [3824,3835]
name: mock_client [3836,3847]
===
match
---
operator: , [41590,41591]
operator: , [41602,41603]
===
match
---
operator: = [26949,26950]
operator: = [26961,26962]
===
match
---
atom_expr [42387,42562]
atom_expr [42399,42574]
===
match
---
expr_stmt [3302,3330]
expr_stmt [3308,3336]
===
match
---
number: 2764800 [32094,32101]
number: 2764800 [32106,32113]
===
match
---
simple_stmt [43852,44030]
simple_stmt [43864,44042]
===
match
---
atom_expr [40142,40223]
atom_expr [40154,40235]
===
match
---
operator: , [34304,34305]
operator: , [34316,34317]
===
match
---
decorator [8492,8577]
decorator [8504,8589]
===
match
---
number: 2 [35309,35310]
number: 2 [35321,35322]
===
match
---
expr_stmt [18838,18881]
expr_stmt [18850,18893]
===
match
---
operator: = [36676,36677]
operator: = [36688,36689]
===
match
---
name: auth_type [6731,6740]
name: auth_type [6743,6752]
===
match
---
name: mock_client [17271,17282]
name: mock_client [17283,17294]
===
match
---
funcdef [34495,36389]
funcdef [34507,36401]
===
match
---
simple_stmt [2317,2348]
simple_stmt [2317,2348]
===
match
---
trailer [40883,40890]
trailer [40895,40902]
===
match
---
atom_expr [4485,4621]
atom_expr [4497,4633]
===
match
---
name: ldap [18477,18481]
name: ldap [18489,18493]
===
match
---
name: side_effect [27532,27543]
name: side_effect [27544,27555]
===
match
---
simple_stmt [18838,18882]
simple_stmt [18850,18894]
===
match
---
name: client [15816,15822]
name: client [15828,15834]
===
match
---
trailer [27508,27511]
trailer [27520,27523]
===
match
---
argument [19273,19288]
argument [19285,19300]
===
match
---
trailer [9741,9760]
trailer [9753,9772]
===
match
---
funcdef [37135,39003]
funcdef [37147,39015]
===
match
---
operator: @ [10016,10017]
operator: @ [10028,10029]
===
match
---
operator: = [19569,19570]
operator: = [19581,19582]
===
match
---
operator: , [35344,35345]
operator: , [35356,35357]
===
match
---
trailer [43871,43874]
trailer [43883,43886]
===
match
---
name: v1 [28391,28393]
name: v1 [28403,28405]
===
match
---
operator: , [43827,43828]
operator: , [43839,43840]
===
match
---
atom_expr [6348,6392]
atom_expr [6360,6404]
===
match
---
trailer [23661,23663]
trailer [23673,23675]
===
match
---
expr_stmt [1973,2003]
expr_stmt [1973,2003]
===
match
---
trailer [28002,28076]
trailer [28014,28088]
===
match
---
trailer [24002,24009]
trailer [24014,24021]
===
match
---
argument [3979,3995]
argument [3991,4007]
===
match
---
arglist [3863,3901]
arglist [3875,3913]
===
match
---
name: cas [40386,40389]
name: cas [40398,40401]
===
match
---
operator: = [40804,40805]
operator: = [40816,40817]
===
match
---
operator: = [12822,12823]
operator: = [12834,12835]
===
match
---
simple_stmt [29993,30049]
simple_stmt [30005,30061]
===
match
---
expr_stmt [33336,33617]
expr_stmt [33348,33629]
===
match
---
operator: } [32140,32141]
operator: } [32152,32153]
===
match
---
name: secret_path [35550,35561]
name: secret_path [35562,35573]
===
match
---
string: 'world' [33220,33227]
string: 'world' [33232,33239]
===
match
---
argument [36342,36362]
argument [36354,36374]
===
match
---
trailer [39176,39186]
trailer [39188,39198]
===
match
---
name: assert_called_with [25579,25597]
name: assert_called_with [25591,25609]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [36406,36470]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [36418,36482]
===
match
---
name: kv_engine_version [11223,11240]
name: kv_engine_version [11235,11252]
===
match
---
atom_expr [12207,12343]
atom_expr [12219,12355]
===
match
---
string: "http://localhost:8180" [3954,3977]
string: "http://localhost:8180" [3966,3989]
===
match
---
name: read_data [15749,15758]
name: read_data [15761,15770]
===
match
---
simple_stmt [9542,9607]
simple_stmt [9554,9619]
===
match
---
operator: , [29598,29599]
operator: , [29610,29611]
===
match
---
name: auth_type [43536,43545]
name: auth_type [43548,43557]
===
match
---
dotted_name [1117,1127]
dotted_name [1117,1127]
===
match
---
parameters [19914,19931]
parameters [19926,19943]
===
match
---
operator: , [5842,5843]
operator: , [5854,5855]
===
match
---
string: 'renewable' [35696,35707]
string: 'renewable' [35708,35719]
===
match
---
operator: = [4578,4579]
operator: = [4590,4591]
===
match
---
trailer [29147,29167]
trailer [29159,29179]
===
match
---
operator: , [16927,16928]
operator: , [16939,16940]
===
match
---
trailer [42764,42771]
trailer [42776,42783]
===
match
---
name: vault_client [26800,26812]
name: vault_client [26812,26824]
===
match
---
operator: , [22927,22928]
operator: , [22939,22940]
===
match
---
atom_expr [13024,13088]
atom_expr [13036,13100]
===
match
---
trailer [25384,25391]
trailer [25396,25403]
===
match
---
atom [42523,42539]
atom [42535,42551]
===
match
---
operator: , [35017,35018]
operator: , [35029,35030]
===
match
---
operator: = [12910,12911]
operator: = [12922,12923]
===
match
---
name: read_secret_version [37321,37340]
name: read_secret_version [37333,37352]
===
match
---
operator: @ [15287,15288]
operator: @ [15299,15300]
===
match
---
name: auth_type [21947,21956]
name: auth_type [21959,21968]
===
match
---
trailer [40257,40281]
trailer [40269,40293]
===
match
---
operator: = [19035,19036]
operator: = [19047,19048]
===
match
---
string: '/tmp/test_token.txt' [23734,23755]
string: '/tmp/test_token.txt' [23746,23767]
===
match
---
name: pytest [20037,20043]
name: pytest [20049,20055]
===
match
---
dictorsetmaker [38465,38493]
dictorsetmaker [38477,38505]
===
match
---
name: mock [39172,39176]
name: mock [39184,39188]
===
match
---
simple_stmt [24903,24946]
simple_stmt [24915,24958]
===
match
---
name: auth_type [18257,18266]
name: auth_type [18269,18278]
===
match
---
atom_expr [4630,4674]
atom_expr [4642,4686]
===
match
---
operator: { [43988,43989]
operator: { [44000,44001]
===
match
---
arglist [8210,8256]
arglist [8222,8268]
===
match
---
name: is_authenticated [23299,23315]
name: is_authenticated [23311,23327]
===
match
---
string: 'key' [42362,42367]
string: 'key' [42374,42379]
===
match
---
param [25783,25788]
param [25795,25800]
===
match
---
string: "other" [13936,13943]
string: "other" [13948,13955]
===
match
---
name: unittest [880,888]
name: unittest [880,888]
===
match
---
operator: = [5190,5191]
operator: = [5202,5203]
===
match
---
trailer [13191,13208]
trailer [13203,13220]
===
match
---
name: patch [23511,23516]
name: patch [23523,23528]
===
match
---
operator: = [20632,20633]
operator: = [20644,20645]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [37065,37129]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [37077,37141]
===
match
---
name: self [39805,39809]
name: self [39817,39821]
===
match
---
dotted_name [6450,6460]
dotted_name [6462,6472]
===
match
---
argument [40199,40222]
argument [40211,40234]
===
match
---
operator: = [26276,26277]
operator: = [26288,26289]
===
match
---
name: test_token_missing_token [22520,22544]
name: test_token_missing_token [22532,22556]
===
match
---
dictorsetmaker [43812,43826]
dictorsetmaker [43824,43838]
===
match
---
string: "pass" [42960,42966]
string: "pass" [42972,42978]
===
match
---
trailer [18401,18408]
trailer [18413,18420]
===
match
---
name: return_value [13493,13505]
name: return_value [13505,13517]
===
match
---
atom_expr [37217,37233]
atom_expr [37229,37245]
===
match
---
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [35616,35654]
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [35628,35666]
===
match
---
param [1221,1226]
param [1221,1226]
===
match
---
comparison [13245,13280]
comparison [13257,13292]
===
match
---
string: "/tmp/test_token.txt" [23912,23933]
string: "/tmp/test_token.txt" [23924,23945]
===
match
---
name: token [26860,26865]
name: token [26872,26877]
===
match
---
simple_stmt [11044,11137]
simple_stmt [11056,11149]
===
match
---
operator: = [37272,37273]
operator: = [37284,37285]
===
match
---
name: mock_hvac [17662,17671]
name: mock_hvac [17674,17683]
===
match
---
expr_stmt [25168,25211]
expr_stmt [25180,25223]
===
match
---
name: Client [18402,18408]
name: Client [18414,18420]
===
match
---
name: is_authenticated [15193,15209]
name: is_authenticated [15205,15221]
===
match
---
atom_expr [33351,33617]
atom_expr [33363,33629]
===
match
---
atom_expr [15876,15940]
atom_expr [15888,15952]
===
match
---
operator: , [18947,18948]
operator: , [18959,18960]
===
match
---
name: assert_called_with [10852,10870]
name: assert_called_with [10864,10882]
===
match
---
simple_stmt [28788,28888]
simple_stmt [28800,28900]
===
match
---
trailer [4175,4182]
trailer [4187,4194]
===
match
---
string: 'secret' [31603,31611]
string: 'secret' [31615,31623]
===
match
---
name: Client [20362,20368]
name: Client [20374,20380]
===
match
---
argument [31259,31275]
argument [31271,31287]
===
match
---
funcdef [14136,14444]
funcdef [14148,14456]
===
match
---
operator: = [2489,2490]
operator: = [2489,2490]
===
match
---
operator: = [23105,23106]
operator: = [23117,23118]
===
match
---
trailer [42406,42409]
trailer [42418,42421]
===
match
---
trailer [8128,8130]
trailer [8140,8142]
===
match
---
argument [5076,5103]
argument [5088,5115]
===
match
---
name: mock [7960,7964]
name: mock [7972,7976]
===
match
---
operator: = [34053,34054]
operator: = [34065,34066]
===
match
---
operator: , [35422,35423]
operator: , [35434,35435]
===
match
---
name: test_get_secret_including_metadata_v1 [39094,39131]
name: test_get_secret_including_metadata_v1 [39106,39143]
===
match
---
trailer [36582,36589]
trailer [36594,36601]
===
match
---
atom_expr [24741,24785]
atom_expr [24753,24797]
===
match
---
trailer [13555,13725]
trailer [13567,13737]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [33851,33915]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [33863,33927]
===
match
---
trailer [32992,32995]
trailer [33004,33007]
===
match
---
number: 8110 [33456,33460]
number: 8110 [33468,33472]
===
match
---
operator: = [26986,26987]
operator: = [26998,26999]
===
match
---
name: providers [999,1008]
name: providers [999,1008]
===
match
---
name: vault_client [24872,24884]
name: vault_client [24884,24896]
===
match
---
trailer [6654,6667]
trailer [6666,6679]
===
match
---
arglist [28483,28675]
arglist [28495,28687]
===
match
---
operator: , [20508,20509]
operator: , [20520,20521]
===
match
---
name: mock [31655,31659]
name: mock [31667,31671]
===
match
---
simple_stmt [6638,6682]
simple_stmt [6650,6694]
===
match
---
name: vault_client [14681,14693]
name: vault_client [14693,14705]
===
match
---
operator: = [21558,21559]
operator: = [21570,21571]
===
match
---
simple_stmt [19596,19640]
simple_stmt [19608,19652]
===
match
---
string: 'secret_value' [37578,37592]
string: 'secret_value' [37590,37604]
===
match
---
operator: = [12113,12114]
operator: = [12125,12126]
===
match
---
name: mock_hvac [31830,31839]
name: mock_hvac [31842,31851]
===
match
---
name: radius_host [42881,42892]
name: radius_host [42893,42904]
===
match
---
simple_stmt [6077,6142]
simple_stmt [6089,6154]
===
match
---
simple_stmt [13734,13763]
simple_stmt [13746,13775]
===
match
---
expr_stmt [41992,42035]
expr_stmt [42004,42047]
===
match
---
name: Client [19151,19157]
name: Client [19163,19169]
===
match
---
string: 'w+' [23757,23761]
string: 'w+' [23769,23773]
===
match
---
operator: = [9168,9169]
operator: = [9180,9181]
===
match
---
name: tenant_id [7154,7163]
name: tenant_id [7166,7175]
===
match
---
name: client [22125,22131]
name: client [22137,22143]
===
match
---
atom_expr [14288,14368]
atom_expr [14300,14380]
===
match
---
atom_expr [1633,1649]
atom_expr [1633,1649]
===
match
---
atom_expr [19214,19310]
atom_expr [19226,19322]
===
match
---
name: Client [18174,18180]
name: Client [18186,18192]
===
match
---
comparison [16089,16124]
comparison [16101,16136]
===
match
---
name: mock_hvac [9269,9278]
name: mock_hvac [9281,9290]
===
match
---
string: 'pass' [5410,5416]
string: 'pass' [5422,5428]
===
match
---
argument [23081,23098]
argument [23093,23110]
===
match
---
suite [21007,21681]
suite [21019,21693]
===
match
---
name: Client [4932,4938]
name: Client [4944,4950]
===
match
---
string: '182d0673-618c-9889-4cba-4e1f4cfe4b4b' [33051,33089]
string: '182d0673-618c-9889-4cba-4e1f4cfe4b4b' [33063,33101]
===
match
---
name: Client [41273,41279]
name: Client [41285,41291]
===
match
---
param [8790,8800]
param [8802,8812]
===
match
---
atom_expr [43510,43738]
atom_expr [43522,43750]
===
match
---
string: 'key' [43812,43817]
string: 'key' [43824,43829]
===
match
---
param [17603,17612]
param [17615,17624]
===
match
---
name: mock_hvac [11647,11656]
name: mock_hvac [11659,11668]
===
match
---
name: client [24183,24189]
name: client [24195,24201]
===
match
---
atom_expr [37242,37271]
atom_expr [37254,37283]
===
match
---
name: vault_client [5784,5796]
name: vault_client [5796,5808]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [4014,4078]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [4026,4090]
===
match
---
atom_expr [1423,1477]
atom_expr [1423,1477]
===
match
---
operator: = [13606,13607]
operator: = [13618,13619]
===
match
---
name: mock_hvac [1599,1608]
name: mock_hvac [1599,1608]
===
match
---
operator: } [40383,40384]
operator: } [40395,40396]
===
match
---
name: mock_client [24510,24521]
name: mock_client [24522,24533]
===
match
---
string: "http://localhost:8180" [10580,10603]
string: "http://localhost:8180" [10592,10615]
===
match
---
trailer [15971,15990]
trailer [15983,16002]
===
match
---
operator: , [27627,27628]
operator: , [27639,27640]
===
match
---
name: mock_client [7637,7648]
name: mock_client [7649,7660]
===
match
---
operator: = [43579,43580]
operator: = [43591,43592]
===
match
---
atom_expr [41238,41254]
atom_expr [41250,41266]
===
match
---
atom_expr [32970,33020]
atom_expr [32982,33032]
===
match
---
name: metadata [36241,36249]
name: metadata [36253,36261]
===
match
---
operator: = [43207,43208]
operator: = [43219,43220]
===
match
---
trailer [23298,23315]
trailer [23310,23327]
===
match
---
number: 1 [35972,35973]
number: 1 [35984,35985]
===
match
---
trailer [24034,24053]
trailer [24046,24065]
===
match
---
operator: @ [1483,1484]
operator: @ [1483,1484]
===
match
---
trailer [40178,40223]
trailer [40190,40235]
===
match
---
expr_stmt [41953,41983]
expr_stmt [41965,41995]
===
match
---
name: mock_client [14590,14601]
name: mock_client [14602,14613]
===
match
---
name: test_azure_missing_tenant_id [8045,8073]
name: test_azure_missing_tenant_id [8057,8085]
===
match
---
operator: = [36777,36778]
operator: = [36789,36790]
===
match
---
dictorsetmaker [29472,29633]
dictorsetmaker [29484,29645]
===
match
---
name: tenant_id [6210,6219]
name: tenant_id [6222,6231]
===
match
---
trailer [43451,43458]
trailer [43463,43470]
===
match
---
operator: == [36238,36240]
operator: == [36250,36252]
===
match
---
name: Client [26622,26628]
name: Client [26634,26640]
===
match
---
string: "airflow.providers.google.cloud.utils.credentials_provider.get_credentials_and_project_id" [9920,10010]
string: "airflow.providers.google.cloud.utils.credentials_provider.get_credentials_and_project_id" [9932,10022]
===
match
---
trailer [3323,3330]
trailer [3329,3336]
===
match
---
trailer [22997,23004]
trailer [23009,23016]
===
match
---
argument [43536,43554]
argument [43548,43566]
===
match
---
dictorsetmaker [34720,35345]
dictorsetmaker [34732,35357]
===
match
---
name: mock_client [15486,15497]
name: mock_client [15498,15509]
===
match
---
simple_stmt [9718,9763]
simple_stmt [9730,9775]
===
match
---
name: match [36909,36914]
name: match [36921,36926]
===
match
---
operator: = [23988,23989]
operator: = [24000,24001]
===
match
---
number: 2 [6408,6409]
number: 2 [6420,6421]
===
match
---
arglist [12483,12509]
arglist [12495,12521]
===
match
---
simple_stmt [23405,23448]
simple_stmt [23417,23460]
===
match
---
argument [18275,18290]
argument [18287,18302]
===
match
---
name: kubernetes_role [14746,14761]
name: kubernetes_role [14758,14773]
===
match
---
operator: @ [36394,36395]
operator: @ [36406,36407]
===
match
---
number: 8110 [36746,36750]
number: 8110 [36758,36762]
===
match
---
decorator [22434,22512]
decorator [22446,22524]
===
match
---
operator: = [11846,11847]
operator: = [11858,11859]
===
match
---
decorator [30262,30340]
decorator [30274,30352]
===
match
---
name: test_default_auth_type [24390,24412]
name: test_default_auth_type [24402,24424]
===
match
---
string: "userpass" [25951,25961]
string: "userpass" [25963,25973]
===
match
---
name: v2 [30136,30138]
name: v2 [30148,30150]
===
match
---
operator: } [12303,12304]
operator: } [12315,12316]
===
match
---
operator: , [29632,29633]
operator: , [29644,29645]
===
match
---
operator: = [33582,33583]
operator: = [33594,33595]
===
match
---
string: "resource" [6254,6264]
string: "resource" [6266,6276]
===
match
---
simple_stmt [3339,3404]
simple_stmt [3345,3410]
===
match
---
name: mock_hvac [22551,22560]
name: mock_hvac [22563,22572]
===
match
---
name: return_value [31847,31859]
name: return_value [31859,31871]
===
match
---
trailer [31178,31361]
trailer [31190,31373]
===
match
---
argument [37025,37046]
argument [37037,37058]
===
match
---
string: "pass" [28594,28600]
string: "pass" [28606,28612]
===
match
---
name: kv_engine_version [16107,16124]
name: kv_engine_version [16119,16136]
===
match
---
argument [5825,5842]
argument [5837,5854]
===
match
---
operator: , [18103,18104]
operator: , [18115,18116]
===
match
---
name: username [25283,25291]
name: username [25295,25303]
===
match
---
assert_stmt [32565,32600]
assert_stmt [32577,32612]
===
match
---
string: "other" [6957,6964]
string: "other" [6969,6976]
===
match
---
name: auth_type [21148,21157]
name: auth_type [21160,21169]
===
match
---
name: _VaultClient [26815,26827]
name: _VaultClient [26827,26839]
===
match
---
string: 'missing' [27146,27155]
string: 'missing' [27158,27167]
===
match
---
atom [43811,43827]
atom [43823,43839]
===
match
---
name: self [42690,42694]
name: self [42702,42706]
===
match
---
operator: = [24508,24509]
operator: = [24520,24521]
===
match
---
operator: } [37823,37824]
operator: } [37835,37836]
===
match
---
trailer [5721,5723]
trailer [5733,5735]
===
match
---
argument [4259,4278]
argument [4271,4290]
===
match
---
suite [19932,20184]
suite [19944,20196]
===
match
---
name: kv_engine_version [4708,4725]
name: kv_engine_version [4720,4737]
===
match
---
trailer [13855,13862]
trailer [13867,13874]
===
match
---
arglist [14722,14802]
arglist [14734,14814]
===
match
---
name: mock_hvac [10242,10251]
name: mock_hvac [10254,10263]
===
match
---
name: return_value [37259,37271]
name: return_value [37271,37283]
===
match
---
operator: @ [39008,39009]
operator: @ [39020,39021]
===
match
---
name: _VaultClient [20099,20111]
name: _VaultClient [20111,20123]
===
match
---
name: return_value [33008,33020]
name: return_value [33020,33032]
===
match
---
operator: = [10737,10738]
operator: = [10749,10750]
===
match
---
name: mock_hvac [41992,42001]
name: mock_hvac [42004,42013]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [34425,34489]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [34437,34501]
===
match
---
trailer [40281,40305]
trailer [40293,40317]
===
match
---
simple_stmt [4485,4622]
simple_stmt [4497,4634]
===
match
---
string: "data" [15170,15176]
string: "data" [15182,15188]
===
match
---
operator: = [30037,30038]
operator: = [30049,30050]
===
match
---
operator: = [41491,41492]
operator: = [41503,41504]
===
match
---
operator: = [26585,26586]
operator: = [26597,26598]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [5582,5646]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [5594,5658]
===
match
---
name: vault_client [41535,41547]
name: vault_client [41547,41559]
===
match
---
name: auth_type [15547,15556]
name: auth_type [15559,15568]
===
match
---
atom_expr [26331,26375]
atom_expr [26343,26387]
===
match
---
name: mock_client [19557,19568]
name: mock_client [19569,19580]
===
match
---
name: mock [20190,20194]
name: mock [20202,20206]
===
match
---
simple_stmt [27486,27560]
simple_stmt [27498,27572]
===
match
---
argument [16453,16480]
argument [16465,16492]
===
match
---
trailer [24053,24082]
trailer [24065,24094]
===
match
---
string: "user" [5124,5130]
string: "user" [5136,5142]
===
match
---
operator: = [43222,43223]
operator: = [43234,43235]
===
match
---
name: mock_hvac [10971,10980]
name: mock_hvac [10983,10992]
===
match
---
trailer [42008,42021]
trailer [42020,42033]
===
match
---
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [13607,13635]
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [13619,13647]
===
match
---
simple_stmt [12844,12979]
simple_stmt [12856,12991]
===
match
---
name: vault_client [26396,26408]
name: vault_client [26408,26420]
===
match
---
operator: = [1259,1260]
operator: = [1259,1260]
===
match
---
string: "pass" [40805,40811]
string: "pass" [40817,40823]
===
match
---
string: 'metadata' [35761,35771]
string: 'metadata' [35773,35783]
===
match
---
trailer [43078,43145]
trailer [43090,43157]
===
match
---
argument [36734,36750]
argument [36746,36762]
===
match
---
operator: = [9144,9145]
operator: = [9156,9157]
===
match
---
name: token [13601,13606]
name: token [13613,13618]
===
match
---
trailer [35549,35572]
trailer [35561,35584]
===
match
---
simple_stmt [30057,30105]
simple_stmt [30069,30117]
===
match
---
name: _VaultClient [12859,12871]
name: _VaultClient [12871,12883]
===
match
---
operator: , [9512,9513]
operator: , [9524,9525]
===
match
---
operator: , [25315,25316]
operator: , [25327,25328]
===
match
---
argument [27609,27627]
argument [27621,27639]
===
match
---
trailer [4931,4938]
trailer [4943,4950]
===
match
---
name: mock_hvac [10698,10707]
name: mock_hvac [10710,10719]
===
match
---
name: github [13856,13862]
name: github [13868,13874]
===
match
---
expr_stmt [14681,14812]
expr_stmt [14693,14824]
===
match
---
name: return_value [21072,21084]
name: return_value [21084,21096]
===
match
---
atom_expr [30421,30437]
atom_expr [30433,30449]
===
match
---
param [5667,5672]
param [5679,5684]
===
match
---
name: MagicMock [41243,41252]
name: MagicMock [41255,41264]
===
match
---
operator: , [6748,6749]
operator: , [6760,6761]
===
match
---
simple_stmt [3916,3997]
simple_stmt [3928,4009]
===
match
---
name: kv [37315,37317]
name: kv [37327,37329]
===
match
---
operator: , [17982,17983]
operator: , [17994,17995]
===
match
---
parameters [31764,31781]
parameters [31776,31793]
===
match
---
operator: , [31074,31075]
operator: , [31086,31087]
===
match
---
operator: @ [8492,8493]
operator: @ [8504,8505]
===
match
---
atom_expr [30002,30048]
atom_expr [30014,30060]
===
match
---
trailer [21462,21472]
trailer [21474,21484]
===
match
---
name: secret [41762,41768]
name: secret [41774,41780]
===
match
---
name: radius_host [36699,36710]
name: radius_host [36711,36722]
===
match
---
operator: = [25370,25371]
operator: = [25382,25383]
===
match
---
operator: = [34404,34405]
operator: = [34416,34417]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [14461,14525]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [14473,14537]
===
match
---
trailer [19612,19625]
trailer [19624,19637]
===
match
---
trailer [31894,31902]
trailer [31906,31914]
===
match
---
argument [43829,43842]
argument [43841,43854]
===
match
---
operator: = [13541,13542]
operator: = [13553,13554]
===
match
---
operator: = [10388,10389]
operator: = [10400,10401]
===
match
---
operator: = [28455,28456]
operator: = [28467,28468]
===
match
---
name: MagicMock [4146,4155]
name: MagicMock [4158,4167]
===
match
---
funcdef [4813,5565]
funcdef [4825,5577]
===
match
---
trailer [13140,13176]
trailer [13152,13188]
===
match
---
argument [22014,22030]
argument [22026,22042]
===
match
---
name: mock [13451,13455]
name: mock [13463,13467]
===
match
---
name: mock_client [3753,3764]
name: mock_client [3765,3776]
===
match
---
argument [29912,29932]
argument [29924,29944]
===
match
---
simple_stmt [35506,35573]
simple_stmt [35518,35585]
===
match
---
atom_expr [31883,31933]
atom_expr [31895,31945]
===
match
---
operator: , [35276,35277]
operator: , [35288,35289]
===
match
---
argument [28850,28870]
argument [28862,28882]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [13298,13362]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [13310,13374]
===
match
---
name: client [2572,2578]
name: client [2572,2578]
===
match
---
trailer [26164,26171]
trailer [26176,26183]
===
match
---
atom_expr [9342,9393]
atom_expr [9354,9405]
===
match
---
name: mock_client [17694,17705]
name: mock_client [17706,17717]
===
match
---
atom_expr [28703,28749]
atom_expr [28715,28761]
===
match
---
simple_stmt [17798,17998]
simple_stmt [17810,18010]
===
match
---
name: MagicMock [1266,1275]
name: MagicMock [1266,1275]
===
match
---
name: auth_approle [3419,3431]
name: approle [3430,3437]
===
match
---
dictorsetmaker [34931,35092]
dictorsetmaker [34943,35104]
===
match
---
name: host [21505,21509]
name: host [21517,21521]
===
match
---
name: self [4857,4861]
name: self [4869,4873]
===
match
---
name: mock_hvac [6638,6647]
name: mock_hvac [6650,6659]
===
match
---
param [30381,30386]
param [30393,30398]
===
match
---
string: "path.json" [10511,10522]
string: "path.json" [10523,10534]
===
match
---
operator: = [30558,30559]
operator: = [30570,30571]
===
match
---
atom_expr [3339,3403]
atom_expr [3345,3409]
===
match
---
trailer [34571,34581]
trailer [34583,34593]
===
match
---
operator: = [20010,20011]
operator: = [20022,20023]
===
match
---
argument [6731,6748]
argument [6743,6760]
===
match
---
name: mock_client [11608,11619]
name: mock_client [11620,11631]
===
match
---
name: mock_hvac [21854,21863]
name: mock_hvac [21866,21875]
===
match
---
name: Client [5742,5748]
name: Client [5754,5760]
===
match
---
string: "approle" [3136,3145]
string: "approle" [3142,3151]
===
match
---
trailer [16071,16073]
trailer [16083,16085]
===
match
---
trailer [39186,39188]
trailer [39198,39200]
===
match
---
name: kv_engine_version [43667,43684]
name: kv_engine_version [43679,43696]
===
match
---
comparison [31459,31499]
comparison [31471,31511]
===
match
---
operator: , [37422,37423]
operator: , [37434,37435]
===
match
---
operator: @ [11443,11444]
operator: @ [11455,11456]
===
match
---
operator: , [43653,43654]
operator: , [43665,43666]
===
match
---
name: mock_hvac [22610,22619]
name: mock_hvac [22622,22631]
===
match
---
name: mock_hvac [39197,39206]
name: mock_hvac [39209,39218]
===
match
---
operator: = [41435,41436]
operator: = [41447,41448]
===
match
---
expr_stmt [15454,15497]
expr_stmt [15466,15509]
===
match
---
string: "http://localhost:8180" [17440,17463]
string: "http://localhost:8180" [17452,17475]
===
match
---
simple_stmt [8139,8183]
simple_stmt [8151,8195]
===
match
---
name: test_get_secret_including_metadata_v2 [37139,37176]
name: test_get_secret_including_metadata_v2 [37151,37188]
===
match
---
operator: , [33395,33396]
operator: , [33407,33408]
===
match
---
string: 'deletion_time' [37712,37727]
string: 'deletion_time' [37724,37739]
===
match
---
atom_expr [13185,13229]
atom_expr [13197,13241]
===
match
---
arglist [13888,13943]
arglist [13900,13955]
===
match
---
name: _VaultClient [14382,14394]
name: _VaultClient [14394,14406]
===
match
---
name: patch [20871,20876]
name: patch [20883,20888]
===
match
---
trailer [23733,23762]
trailer [23745,23774]
===
match
---
trailer [41706,41803]
trailer [41718,41815]
===
match
---
operator: = [42253,42254]
operator: = [42265,42266]
===
match
---
operator: = [6321,6322]
operator: = [6333,6334]
===
match
---
name: return_value [23689,23701]
name: return_value [23701,23713]
===
match
---
trailer [25157,25159]
trailer [25169,25171]
===
match
---
name: assert_called_with [25417,25435]
name: assert_called_with [25429,25447]
===
match
---
atom_expr [25400,25464]
atom_expr [25412,25476]
===
match
---
operator: = [13706,13707]
operator: = [13718,13719]
===
match
---
arglist [15148,15176]
arglist [15160,15188]
===
match
---
assert_stmt [26384,26426]
assert_stmt [26396,26438]
===
match
---
string: 'warnings' [31088,31098]
string: 'warnings' [31100,31110]
===
match
---
name: _VaultClient [5799,5811]
name: _VaultClient [5811,5823]
===
match
---
operator: = [28492,28493]
operator: = [28504,28505]
===
match
---
name: Client [2366,2372]
name: Client [2366,2372]
===
match
---
operator: = [5225,5226]
operator: = [5237,5238]
===
match
---
trailer [26601,26603]
trailer [26613,26615]
===
match
---
name: role [16899,16903]
name: role [16911,16915]
===
match
---
name: assert_called_with [23236,23254]
name: assert_called_with [23248,23266]
===
match
---
operator: = [41467,41468]
operator: = [41479,41480]
===
match
---
name: kv_engine_version [20842,20859]
name: kv_engine_version [20854,20871]
===
match
---
name: mock_client [29101,29112]
name: mock_client [29113,29124]
===
match
---
parameters [22922,22939]
parameters [22934,22951]
===
match
---
operator: = [22081,22082]
operator: = [22093,22094]
===
match
---
trailer [41571,41624]
trailer [41583,41636]
===
match
---
trailer [11222,11240]
trailer [11234,11252]
===
match
---
trailer [6617,6627]
trailer [6629,6639]
===
match
---
decorated [18650,19415]
decorated [18662,19427]
===
match
---
trailer [3855,3862]
trailer [3867,3874]
===
match
---
name: mock_get_credentials [10354,10374]
name: mock_get_credentials [10366,10386]
===
match
---
name: return_value [36590,36602]
name: return_value [36602,36614]
===
match
---
suite [40552,41071]
suite [40564,41083]
===
match
---
operator: , [4278,4279]
operator: , [4290,4291]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [36048,36077]
string: '2020-03-16T21:01:43.331126Z' [36060,36089]
===
match
---
decorated [12629,13281]
decorated [12641,13293]
===
match
---
operator: = [15152,15153]
operator: = [15164,15165]
===
match
---
trailer [5711,5721]
trailer [5723,5733]
===
match
---
atom_expr [15739,15766]
atom_expr [15751,15778]
===
match
---
operator: = [3822,3823]
operator: = [3834,3835]
===
match
---
string: "kube_role" [15599,15610]
string: "kube_role" [15611,15622]
===
match
---
string: 'deletion_time' [35217,35232]
string: 'deletion_time' [35229,35244]
===
match
---
name: username [25513,25521]
name: username [25525,25533]
===
match
---
operator: @ [37053,37054]
operator: @ [37065,37066]
===
match
---
name: client [12528,12534]
name: client [12540,12546]
===
match
---
string: 'scope1' [10326,10334]
string: 'scope1' [10338,10346]
===
match
---
string: "http://localhost:8180" [32458,32481]
string: "http://localhost:8180" [32470,32493]
===
match
---
string: "missing" [35562,35571]
string: "missing" [35574,35583]
===
match
---
name: radius_secret [27706,27719]
name: radius_secret [27718,27731]
===
match
---
string: "radhost" [42893,42902]
string: "radhost" [42905,42914]
===
match
---
expr_stmt [13476,13519]
expr_stmt [13488,13531]
===
match
---
name: mount_point [43939,43950]
name: mount_point [43951,43962]
===
match
---
dotted_name [9909,9919]
dotted_name [9921,9931]
===
match
---
decorators [8492,8767]
decorators [8504,8779]
===
match
---
name: auth_mount_point [10617,10633]
name: auth_mount_point [10629,10645]
===
match
---
trailer [9304,9333]
trailer [9316,9345]
===
match
---
name: secret [27013,27019]
name: secret [27025,27031]
===
match
---
name: vault_client [9074,9086]
name: vault_client [9086,9098]
===
match
---
operator: , [15569,15570]
operator: , [15581,15582]
===
match
---
trailer [5748,5761]
trailer [5760,5773]
===
match
---
string: "other" [21559,21566]
string: "other" [21571,21578]
===
match
---
name: mock_hvac [34023,34032]
name: mock_hvac [34035,34044]
===
match
---
operator: , [29868,29869]
operator: , [29880,29881]
===
match
---
string: 'value' [42531,42538]
string: 'value' [42543,42550]
===
match
---
name: assert_called_with [24035,24053]
name: assert_called_with [24047,24065]
===
match
---
number: 8110 [42928,42932]
number: 8110 [42940,42944]
===
match
---
number: 8110 [31271,31275]
number: 8110 [31283,31287]
===
match
---
name: mock_client [22571,22582]
name: mock_client [22583,22594]
===
match
---
atom_expr [8114,8130]
atom_expr [8126,8142]
===
match
---
name: client [24003,24009]
name: client [24015,24021]
===
match
---
name: self [28197,28201]
name: self [28209,28213]
===
match
---
name: vault_client [43495,43507]
name: vault_client [43507,43519]
===
match
---
operator: = [40630,40631]
operator: = [40642,40643]
===
match
---
operator: } [29665,29666]
operator: } [29677,29678]
===
match
---
name: role_id [3159,3166]
name: role_id [3165,3172]
===
match
---
comparison [32572,32600]
comparison [32584,32612]
===
match
---
simple_stmt [32970,33327]
simple_stmt [32982,33339]
===
match
---
operator: = [20563,20564]
operator: = [20575,20576]
===
match
---
string: "gcp" [11884,11889]
string: "gcp" [11896,11901]
===
match
---
name: configure [12441,12450]
name: configure [12453,12462]
===
match
---
operator: , [20728,20729]
operator: , [20740,20741]
===
match
---
atom_expr [37295,37353]
atom_expr [37307,37365]
===
match
---
name: url [14415,14418]
name: url [14427,14430]
===
match
---
trailer [38188,38218]
trailer [38200,38230]
===
match
---
operator: = [16903,16904]
operator: = [16915,16916]
===
match
---
name: kv_engine_version [25633,25650]
name: kv_engine_version [25645,25662]
===
match
---
argument [27740,27767]
argument [27752,27779]
===
match
---
operator: = [4603,4604]
operator: = [4615,4616]
===
match
---
operator: } [36236,36237]
operator: } [36248,36249]
===
match
---
operator: = [41620,41621]
operator: = [41632,41633]
===
match
---
argument [39388,39408]
argument [39400,39420]
===
match
---
simple_stmt [12037,12066]
simple_stmt [12049,12078]
===
match
---
atom_expr [13953,13997]
atom_expr [13965,14009]
===
match
---
trailer [15885,15892]
trailer [15897,15904]
===
match
---
trailer [22263,22282]
trailer [22275,22294]
===
match
---
operator: = [33807,33808]
operator: = [33819,33820]
===
match
---
name: mock [41238,41242]
name: mock [41250,41254]
===
match
---
name: vault_client [40653,40665]
name: vault_client [40665,40677]
===
match
---
simple_stmt [39870,39914]
simple_stmt [39882,39926]
===
match
---
operator: , [42694,42695]
operator: , [42706,42707]
===
match
---
operator: = [42858,42859]
operator: = [42870,42871]
===
match
---
name: vault_client [11210,11222]
name: vault_client [11222,11234]
===
match
---
assert_stmt [35581,36249]
assert_stmt [35593,36261]
===
match
---
trailer [42309,42333]
trailer [42321,42345]
===
match
---
name: kv_engine_version [42980,42997]
name: kv_engine_version [42992,43009]
===
match
---
argument [20445,20463]
argument [20457,20475]
===
match
---
assert_stmt [12581,12623]
assert_stmt [12593,12635]
===
match
---
trailer [23651,23661]
trailer [23663,23673]
===
match
---
string: "builtins.open" [15722,15737]
string: "builtins.open" [15734,15749]
===
match
---
trailer [14969,15024]
trailer [14981,15036]
===
match
---
simple_stmt [36626,36870]
simple_stmt [36638,36882]
===
match
---
name: mock [8493,8497]
name: mock [8505,8509]
===
match
---
trailer [16879,16898]
trailer [16891,16910]
===
match
---
operator: , [29727,29728]
operator: , [29739,29740]
===
match
---
decorated [27185,28077]
decorated [27197,28089]
===
match
---
atom_expr [28788,28887]
atom_expr [28800,28899]
===
match
---
name: mock [1261,1265]
name: mock [1261,1265]
===
match
---
expr_stmt [31883,32239]
expr_stmt [31895,32251]
===
match
---
simple_stmt [18465,18541]
simple_stmt [18477,18553]
===
match
---
operator: = [25878,25879]
operator: = [25890,25891]
===
match
---
string: 'missing' [38969,38978]
string: 'missing' [38981,38990]
===
match
---
dotted_name [10017,10027]
dotted_name [10029,10039]
===
match
---
operator: , [35682,35683]
operator: , [35694,35695]
===
match
---
operator: { [29450,29451]
operator: { [29462,29463]
===
match
---
argument [6113,6140]
argument [6125,6152]
===
match
---
name: test_create_or_update_secret_v1_post [43340,43376]
name: test_create_or_update_secret_v1_post [43352,43388]
===
match
---
operator: = [42058,42059]
operator: = [42070,42071]
===
match
---
argument [40361,40384]
argument [40373,40396]
===
match
---
decorator [27185,27263]
decorator [27197,27275]
===
match
---
name: assert_called_with [9423,9441]
name: assert_called_with [9435,9453]
===
match
---
atom_expr [26718,26775]
atom_expr [26730,26787]
===
match
---
operator: , [2113,2114]
operator: , [2113,2114]
===
match
---
simple_stmt [20666,20756]
simple_stmt [20678,20768]
===
match
---
trailer [2818,2836]
trailer [2824,2842]
===
match
---
name: client [26140,26146]
name: client [26152,26158]
===
match
---
operator: , [29833,29834]
operator: , [29845,29846]
===
match
---
string: "radhost" [21991,22000]
string: "radhost" [22003,22012]
===
match
---
name: mock_get_credentials [10155,10175]
name: mock_get_credentials [10167,10187]
===
match
---
operator: , [40122,40123]
operator: , [40134,40135]
===
match
---
operator: = [25320,25321]
operator: = [25332,25333]
===
match
---
operator: { [30767,30768]
operator: { [30779,30780]
===
match
---
expr_stmt [31370,31443]
expr_stmt [31382,31455]
===
match
---
operator: = [3190,3191]
operator: = [3196,3197]
===
match
---
name: kv [43872,43874]
name: kv [43884,43886]
===
match
---
name: mock_hvac [39870,39879]
name: mock_hvac [39882,39891]
===
match
---
argument [42980,42999]
argument [42992,43011]
===
match
---
simple_stmt [24144,24196]
simple_stmt [24156,24208]
===
match
---
operator: , [36720,36721]
operator: , [36732,36733]
===
match
---
operator: , [17937,17938]
operator: , [17949,17950]
===
match
---
name: vault_client [1036,1048]
name: vault_client [1036,1048]
===
match
---
operator: { [31459,31460]
operator: { [31471,31472]
===
match
---
trailer [22680,22746]
trailer [22692,22758]
===
match
---
operator: , [39982,39983]
operator: , [39994,39995]
===
match
---
argument [25975,25990]
argument [25987,26002]
===
match
---
atom_expr [25473,25546]
atom_expr [25485,25558]
===
match
---
argument [4599,4610]
argument [4611,4622]
===
match
---
name: mock_hvac [36573,36582]
name: mock_hvac [36585,36594]
===
match
---
operator: } [31488,31489]
operator: } [31500,31501]
===
match
---
operator: = [16666,16667]
operator: = [16678,16679]
===
match
---
simple_stmt [21444,21577]
simple_stmt [21456,21589]
===
match
---
string: "pass" [19760,19766]
string: "pass" [19772,19778]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [35166,35195]
string: '2020-03-16T21:01:43.331126Z' [35178,35207]
===
match
---
argument [13888,13922]
argument [13900,13934]
===
match
---
name: mock_client [31508,31519]
name: mock_client [31520,31531]
===
match
---
operator: , [5922,5923]
operator: , [5934,5935]
===
match
---
arglist [21148,21315]
arglist [21160,21327]
===
match
---
trailer [9626,9630]
trailer [9638,9642]
===
match
---
string: "tenant_id" [5872,5883]
string: "tenant_id" [5884,5895]
===
match
---
trailer [27819,27842]
trailer [27831,27854]
===
match
---
argument [10906,10923]
argument [10918,10935]
===
match
---
name: login [19231,19236]
name: login [19243,19248]
===
match
---
string: "user" [25984,25990]
string: "user" [25996,26002]
===
match
---
name: assert_called_with [16880,16898]
name: assert_called_with [16892,16910]
===
match
---
operator: , [12322,12323]
operator: , [12334,12335]
===
match
---
operator: = [31636,31637]
operator: = [31648,31649]
===
match
---
name: password [18292,18300]
name: password [18304,18312]
===
match
---
name: assert_called_with [7349,7367]
name: assert_called_with [7361,7379]
===
match
---
name: radius_host [39323,39334]
name: radius_host [39335,39346]
===
match
---
trailer [9441,9533]
trailer [9453,9545]
===
match
---
name: return_value [5749,5761]
name: return_value [5761,5773]
===
match
---
operator: == [24271,24273]
operator: == [24283,24285]
===
match
---
parameters [39131,39148]
parameters [39143,39160]
===
match
---
argument [6883,6896]
argument [6895,6908]
===
match
---
trailer [21591,21608]
trailer [21603,21620]
===
match
---
param [2297,2306]
param [2297,2306]
===
match
---
operator: == [16091,16093]
operator: == [16103,16105]
===
match
---
param [41933,41942]
param [41945,41954]
===
match
---
name: mock_get_credentials [11560,11580]
name: mock_get_credentials [11572,11592]
===
match
---
trailer [11779,11792]
trailer [11791,11804]
===
match
---
operator: , [22691,22692]
operator: , [22703,22704]
===
match
---
string: "http://localhost:8180" [6846,6869]
string: "http://localhost:8180" [6858,6881]
===
match
---
string: "radhost" [20144,20153]
string: "radhost" [20156,20165]
===
match
---
argument [18292,18307]
argument [18304,18319]
===
match
---
operator: , [17434,17435]
operator: , [17446,17447]
===
match
---
argument [14775,14802]
argument [14787,14814]
===
match
---
simple_stmt [14006,14049]
simple_stmt [14018,14061]
===
match
---
operator: , [20061,20062]
operator: , [20073,20074]
===
match
---
operator: = [26899,26900]
operator: = [26911,26912]
===
match
---
operator: = [27130,27131]
operator: = [27142,27143]
===
match
---
argument [15148,15164]
argument [15160,15176]
===
match
---
arglist [27119,27169]
arglist [27131,27181]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [42580,42644]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [42592,42656]
===
match
---
operator: } [42538,42539]
operator: } [42550,42551]
===
match
---
trailer [22178,22197]
trailer [22190,22209]
===
match
---
operator: , [25281,25282]
operator: , [25293,25294]
===
match
---
name: _VaultClient [18905,18917]
name: _VaultClient [18917,18929]
===
match
---
simple_stmt [4974,5210]
simple_stmt [4986,5222]
===
match
---
string: '' [33115,33117]
string: '' [33127,33129]
===
match
---
expr_stmt [33984,34014]
expr_stmt [33996,34026]
===
match
---
expr_stmt [12844,12978]
expr_stmt [12856,12990]
===
match
---
argument [15664,15691]
argument [15676,15703]
===
match
---
argument [12483,12508]
argument [12495,12520]
===
match
---
string: "post" [43836,43842]
string: "post" [43848,43854]
===
match
---
argument [19057,19084]
argument [19069,19096]
===
match
---
argument [27119,27139]
argument [27131,27151]
===
match
---
operator: , [32030,32031]
operator: , [32042,32043]
===
match
---
name: client_secret [6308,6321]
name: client_secret [6320,6333]
===
match
---
argument [15583,15610]
argument [15595,15622]
===
match
---
name: patch [20195,20200]
name: patch [20207,20212]
===
match
---
atom [38257,38838]
atom [38269,38850]
===
match
---
name: test_github [12715,12726]
name: test_github [12727,12738]
===
match
---
name: Client [22998,23004]
name: Client [23010,23016]
===
match
---
operator: = [38968,38969]
operator: = [38980,38981]
===
match
---
string: "requires 'azure_resource'" [7694,7721]
string: "requires 'azure_resource'" [7706,7733]
===
match
---
trailer [40579,40589]
trailer [40591,40601]
===
match
---
string: "radhost" [21192,21201]
string: "radhost" [21204,21213]
===
match
---
argument [18507,18522]
argument [18519,18534]
===
match
---
param [17597,17602]
param [17609,17614]
===
match
---
atom_expr [4166,4195]
atom_expr [4178,4207]
===
match
---
name: client_id [7222,7231]
name: client_id [7234,7243]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [1851,1915]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [1851,1915]
===
match
---
operator: = [30419,30420]
operator: = [30431,30432]
===
match
---
operator: { [37563,37564]
operator: { [37575,37576]
===
match
---
assert_stmt [24144,24195]
assert_stmt [24156,24207]
===
match
---
argument [41720,41740]
argument [41732,41752]
===
match
---
name: secret_id [3228,3237]
name: secret_id [3234,3243]
===
match
---
operator: { [34909,34910]
operator: { [34921,34922]
===
match
---
operator: , [13714,13715]
operator: , [13726,13727]
===
match
---
number: 1 [42998,42999]
number: 1 [43010,43011]
===
match
---
operator: , [33228,33229]
operator: , [33240,33241]
===
match
---
trailer [17302,17309]
trailer [17314,17321]
===
match
---
name: kv [36278,36280]
name: kv [36290,36292]
===
match
---
name: client [13734,13740]
name: client [13746,13752]
===
match
---
expr_stmt [23040,23173]
expr_stmt [23052,23185]
===
match
---
arglist [17828,17983]
arglist [17840,17995]
===
match
---
simple_stmt [18164,18208]
simple_stmt [18176,18220]
===
match
---
suite [40961,41071]
suite [40973,41083]
===
match
---
string: 'value' [43231,43238]
string: 'value' [43243,43250]
===
match
---
name: is_authenticated [13192,13208]
name: is_authenticated [13204,13220]
===
match
---
dotted_name [4732,4742]
dotted_name [4744,4754]
===
match
---
name: client [12037,12043]
name: client [12049,12055]
===
match
---
param [8823,8838]
param [8835,8850]
===
match
---
name: role [4599,4603]
name: role [4611,4615]
===
match
---
name: auth [22242,22246]
name: auth [22254,22258]
===
match
---
name: mock [34414,34418]
name: mock [34426,34430]
===
match
---
atom [12288,12304]
atom [12300,12316]
===
match
---
name: Client [18848,18854]
name: Client [18860,18866]
===
match
---
operator: , [3483,3484]
operator: , [3495,3496]
===
match
---
name: mock_hvac [26553,26562]
name: mock_hvac [26565,26574]
===
match
---
operator: = [7693,7694]
operator: = [7705,7706]
===
match
---
trailer [23429,23447]
trailer [23441,23459]
===
match
---
string: "missing" [27832,27841]
string: "missing" [27844,27853]
===
match
---
operator: , [30719,30720]
operator: , [30731,30732]
===
match
---
expr_stmt [23672,23715]
expr_stmt [23684,23727]
===
match
---
simple_stmt [39158,39189]
simple_stmt [39170,39201]
===
match
---
argument [38019,38040]
argument [38031,38052]
===
match
---
string: 'path' [40353,40359]
string: 'path' [40365,40371]
===
match
---
string: 'renewable' [37464,37475]
string: 'renewable' [37476,37487]
===
match
---
name: client [25385,25391]
name: client [25397,25403]
===
match
---
name: raises [22674,22680]
name: raises [22686,22692]
===
match
---
trailer [14220,14222]
trailer [14232,14234]
===
match
---
name: client [5328,5334]
name: client [5340,5346]
===
match
---
name: client [4397,4403]
name: client [4409,4415]
===
match
---
string: "Secret version" [34312,34328]
string: "Secret version" [34324,34340]
===
match
---
name: mock [1987,1991]
name: mock [1987,1991]
===
match
---
operator: , [2484,2485]
operator: , [2484,2485]
===
match
---
dictorsetmaker [41600,41614]
dictorsetmaker [41612,41626]
===
match
---
number: 10 [41621,41623]
number: 10 [41633,41635]
===
match
---
trailer [41644,41652]
trailer [41656,41664]
===
match
---
string: "path" [17428,17434]
string: "path" [17440,17446]
===
match
---
parameters [43376,43393]
parameters [43388,43405]
===
match
---
trailer [2571,2578]
trailer [2571,2578]
===
match
---
name: VaultError [974,984]
name: VaultError [974,984]
===
match
---
name: mock_client [14192,14203]
name: mock_client [14204,14215]
===
match
---
trailer [19342,19361]
trailer [19354,19373]
===
match
---
argument [12260,12273]
argument [12272,12285]
===
match
---
operator: , [19535,19536]
operator: , [19547,19548]
===
match
---
operator: = [13935,13936]
operator: = [13947,13948]
===
match
---
trailer [30025,30048]
trailer [30037,30060]
===
match
---
trailer [13995,13997]
trailer [14007,14009]
===
match
---
name: mock_hvac [7605,7614]
name: mock_hvac [7617,7626]
===
match
---
name: username [18507,18515]
name: username [18519,18527]
===
match
---
name: mock [10017,10021]
name: mock [10029,10033]
===
match
---
atom_expr [36258,36388]
atom_expr [36270,36400]
===
match
---
string: "scope1,scope2" [10547,10562]
string: "scope1,scope2" [10559,10574]
===
match
---
operator: , [8799,8800]
operator: , [8811,8812]
===
match
---
name: vault_client [25220,25232]
name: vault_client [25232,25244]
===
match
---
operator: , [43802,43803]
operator: , [43814,43815]
===
match
---
name: radius_host [31224,31235]
name: radius_host [31236,31247]
===
match
---
operator: = [5079,5080]
operator: = [5091,5092]
===
match
---
string: "github" [12895,12903]
string: "github" [12907,12915]
===
match
---
operator: , [14773,14774]
operator: , [14785,14786]
===
match
---
string: "pass" [3989,3995]
string: "pass" [4001,4007]
===
match
---
name: return_value [34040,34052]
name: return_value [34052,34064]
===
match
---
operator: = [31377,31378]
operator: = [31389,31390]
===
match
---
expr_stmt [10242,10285]
expr_stmt [10254,10297]
===
match
---
operator: , [33259,33260]
operator: , [33271,33272]
===
match
---
trailer [39886,39899]
trailer [39898,39911]
===
match
---
dotted_name [24305,24315]
dotted_name [24317,24327]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [7438,7502]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [7450,7514]
===
match
---
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [24801,24829]
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [24813,24841]
===
match
---
name: mock_client [23704,23715]
name: mock_client [23716,23727]
===
match
---
simple_stmt [38250,38851]
simple_stmt [38262,38863]
===
match
---
simple_stmt [40600,40644]
simple_stmt [40612,40656]
===
match
---
name: mock_hvac [39138,39147]
name: mock_hvac [39150,39159]
===
match
---
trailer [29144,29147]
trailer [29156,29159]
===
match
---
operator: , [33315,33316]
operator: , [33327,33328]
===
match
---
operator: = [40330,40331]
operator: = [40342,40343]
===
match
---
decorated [34413,36389]
decorated [34425,36401]
===
match
---
name: MagicMock [4902,4911]
name: MagicMock [4914,4923]
===
match
---
simple_stmt [11145,11190]
simple_stmt [11157,11202]
===
match
---
string: 'wrap_info' [37853,37864]
string: 'wrap_info' [37865,37876]
===
match
---
trailer [18827,18829]
trailer [18839,18841]
===
match
---
expr_stmt [10294,10345]
expr_stmt [10306,10357]
===
match
---
string: "radius" [31202,31210]
string: "radius" [31214,31222]
===
match
---
name: mock [26433,26437]
name: mock [26445,26449]
===
match
---
argument [29946,29973]
argument [29958,29985]
===
match
---
name: auth_type [1738,1747]
name: auth_type [1738,1747]
===
match
---
operator: = [34253,34254]
operator: = [34265,34266]
===
match
---
atom_expr [29044,29060]
atom_expr [29056,29072]
===
match
---
suite [33975,34408]
suite [33987,34420]
===
match
---
operator: = [17837,17838]
operator: = [17849,17850]
===
match
---
name: vault_client [14913,14925]
name: vault_client [14925,14937]
===
match
---
name: client [23981,23987]
name: client [23993,23999]
===
match
---
decorated [4002,4726]
decorated [4014,4738]
===
match
---
number: 8110 [39370,39374]
number: 8110 [39382,39386]
===
match
---
name: login [13116,13121]
name: login [13128,13133]
===
match
---
operator: = [10323,10324]
operator: = [10335,10336]
===
match
---
name: vault_client [28442,28454]
name: vault_client [28454,28466]
===
match
---
operator: = [8382,8383]
operator: = [8394,8395]
===
match
---
operator: = [35377,35378]
operator: = [35389,35390]
===
match
---
expr_stmt [6690,6975]
expr_stmt [6702,6987]
===
match
---
atom_expr [18392,18456]
atom_expr [18404,18468]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [7971,8035]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [7983,8047]
===
match
---
name: mock_client [39902,39913]
name: mock_client [39914,39925]
===
match
---
string: "user" [18516,18522]
string: "user" [18528,18534]
===
match
---
name: mock_hvac [8139,8148]
name: mock_hvac [8151,8160]
===
match
---
name: vault_client [26127,26139]
name: vault_client [26139,26151]
===
match
---
trailer [1302,1315]
trailer [1302,1315]
===
match
---
name: radius_secret [41454,41467]
name: radius_secret [41466,41479]
===
match
---
trailer [30521,30524]
trailer [30533,30536]
===
match
---
number: 2 [24211,24212]
number: 2 [24223,24224]
===
match
---
simple_stmt [38165,38242]
simple_stmt [38177,38254]
===
match
---
argument [40341,40359]
argument [40353,40371]
===
match
---
atom_expr [20565,20584]
atom_expr [20577,20596]
===
match
---
name: Client [29079,29085]
name: Client [29091,29097]
===
match
---
trailer [15463,15470]
trailer [15475,15482]
===
match
---
argument [13690,13714]
argument [13702,13726]
===
match
---
operator: = [35515,35516]
operator: = [35527,35528]
===
match
---
name: _VaultClient [41331,41343]
name: _VaultClient [41343,41355]
===
match
---
operator: , [13635,13636]
operator: , [13647,13648]
===
match
---
atom_expr [21055,21084]
atom_expr [21067,21096]
===
match
---
trailer [30510,30518]
trailer [30522,30530]
===
match
---
trailer [18626,18644]
trailer [18638,18656]
===
match
---
name: self [29004,29008]
name: self [29016,29020]
===
match
---
atom_expr [10670,10689]
atom_expr [10682,10701]
===
match
---
trailer [15840,15859]
trailer [15852,15871]
===
match
---
param [33958,33963]
param [33970,33975]
===
match
---
operator: , [15164,15165]
operator: , [15176,15177]
===
match
---
trailer [23681,23688]
trailer [23693,23700]
===
match
---
operator: = [23891,23892]
operator: = [23903,23904]
===
match
---
name: assert_called_once_with [40282,40305]
name: assert_called_once_with [40294,40317]
===
match
---
param [17174,17179]
param [17186,17191]
===
match
---
operator: = [7060,7061]
operator: = [7072,7073]
===
match
---
comparison [38257,38850]
comparison [38269,38862]
===
match
---
parameters [7539,7556]
parameters [7551,7568]
===
match
---
argument [30026,30047]
argument [30038,30059]
===
match
---
atom_expr [19980,20009]
atom_expr [19992,20021]
===
match
---
arglist [42086,42278]
arglist [42098,42290]
===
match
---
name: return_value [32934,32946]
name: return_value [32946,32958]
===
match
---
operator: , [25528,25529]
operator: , [25540,25541]
===
match
---
atom_expr [16094,16124]
atom_expr [16106,16136]
===
match
---
string: "userpass" [25271,25281]
string: "userpass" [25283,25293]
===
match
---
trailer [43901,43925]
trailer [43913,43937]
===
match
---
name: mount_point [16929,16940]
name: mount_point [16941,16952]
===
match
---
argument [2715,2731]
argument [2721,2737]
===
match
---
dotted_name [2193,2203]
dotted_name [2193,2203]
===
match
---
string: "pass" [31303,31309]
string: "pass" [31315,31321]
===
match
---
argument [39996,40017]
argument [40008,40029]
===
match
---
trailer [3374,3403]
trailer [3380,3409]
===
match
---
string: "post" [44013,44019]
string: "post" [44025,44031]
===
match
---
name: mock [21030,21034]
name: mock [21042,21046]
===
match
---
trailer [22589,22599]
trailer [22601,22611]
===
match
---
name: mock_hvac [18392,18401]
name: mock_hvac [18404,18413]
===
match
---
name: v1 [32632,32634]
name: v1 [32644,32646]
===
match
---
operator: = [12287,12288]
operator: = [12299,12300]
===
match
---
string: "http://localhost:8180" [5080,5103]
string: "http://localhost:8180" [5092,5115]
===
match
---
comparison [6408,6443]
comparison [6420,6455]
===
match
---
name: secret [28765,28771]
name: secret [28777,28783]
===
match
---
argument [21505,21519]
argument [21517,21531]
===
match
---
name: client [20556,20562]
name: client [20568,20574]
===
match
---
name: vault_client [43747,43759]
name: vault_client [43759,43771]
===
match
---
name: self [34527,34531]
name: self [34539,34543]
===
match
---
operator: , [3244,3245]
operator: , [3250,3251]
===
match
---
simple_stmt [43495,43739]
simple_stmt [43507,43751]
===
match
---
operator: = [14868,14869]
operator: = [14880,14881]
===
match
---
trailer [13780,13787]
trailer [13792,13799]
===
match
---
comparison [1797,1833]
comparison [1797,1833]
===
match
---
string: 'lease_id' [35668,35678]
string: 'lease_id' [35680,35690]
===
match
---
argument [26285,26300]
argument [26297,26312]
===
match
---
name: secret_id [8455,8464]
name: secret_id [8467,8476]
===
match
---
name: vault_client [20404,20416]
name: vault_client [20416,20428]
===
match
---
name: MagicMock [36553,36562]
name: MagicMock [36565,36574]
===
match
---
name: auth [13851,13855]
name: auth [13863,13867]
===
match
---
operator: = [4331,4332]
operator: = [4343,4344]
===
match
---
trailer [15112,15128]
trailer [15124,15140]
===
match
---
number: 8110 [22319,22323]
number: 8110 [22331,22335]
===
match
---
simple_stmt [11198,11241]
simple_stmt [11210,11253]
===
match
---
name: auth_mount_point [5174,5190]
name: auth_mount_point [5186,5202]
===
match
---
operator: , [21235,21236]
operator: , [21247,21248]
===
match
---
argument [7922,7938]
argument [7934,7950]
===
match
---
operator: = [16550,16551]
operator: = [16562,16563]
===
match
---
name: vault_client [24915,24927]
name: vault_client [24927,24939]
===
match
---
suite [1238,1478]
suite [1238,1478]
===
match
---
operator: , [33565,33566]
operator: , [33577,33578]
===
match
---
trailer [31530,31533]
trailer [31542,31545]
===
match
---
name: patch [6455,6460]
name: patch [6467,6472]
===
match
---
name: Client [16334,16340]
name: Client [16346,16352]
===
match
---
operator: = [10215,10216]
operator: = [10227,10228]
===
match
---
trailer [24684,24703]
trailer [24696,24715]
===
match
---
name: client [4630,4636]
name: client [4642,4648]
===
match
---
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [23106,23134]
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [23118,23146]
===
match
---
atom_expr [19384,19414]
atom_expr [19396,19426]
===
match
---
operator: = [29181,29182]
operator: = [29193,29194]
===
match
---
name: mock [40575,40579]
name: mock [40587,40591]
===
match
---
name: client [7325,7331]
name: client [7337,7343]
===
match
---
argument [41572,41590]
argument [41584,41602]
===
match
---
trailer [14301,14368]
trailer [14313,14380]
===
match
---
simple_stmt [24204,24247]
simple_stmt [24216,24259]
===
match
---
operator: = [10892,10893]
operator: = [10904,10905]
===
match
---
number: 8110 [40043,40047]
number: 8110 [40055,40059]
===
match
---
simple_stmt [13953,13998]
simple_stmt [13965,14010]
===
match
---
trailer [40251,40254]
trailer [40263,40266]
===
match
---
string: '' [35680,35682]
string: '' [35692,35694]
===
match
---
operator: == [15248,15250]
operator: == [15260,15262]
===
match
---
trailer [4396,4403]
trailer [4408,4415]
===
match
---
trailer [32634,32646]
trailer [32646,32658]
===
match
---
string: "secret" [24262,24270]
string: "secret" [24274,24282]
===
match
---
operator: , [2513,2514]
operator: , [2513,2514]
===
match
---
name: mock_client [18125,18136]
name: mock_client [18137,18148]
===
match
---
name: mock_client [26718,26729]
name: mock_client [26730,26741]
===
match
---
argument [6842,6869]
argument [6854,6881]
===
match
---
trailer [5001,5209]
trailer [5013,5221]
===
match
---
name: assert_called_with [20695,20713]
name: assert_called_with [20707,20725]
===
match
---
simple_stmt [15106,15178]
simple_stmt [15118,15190]
===
match
---
atom_expr [15521,15702]
atom_expr [15533,15714]
===
match
---
operator: , [22105,22106]
operator: , [22117,22118]
===
match
---
trailer [20361,20368]
trailer [20373,20380]
===
match
---
operator: , [37824,37825]
operator: , [37836,37837]
===
match
---
name: vault_client [12844,12856]
name: vault_client [12856,12868]
===
match
---
name: VaultError [17733,17743]
name: VaultError [17745,17755]
===
match
---
operator: , [11580,11581]
operator: , [11592,11593]
===
match
---
string: 'created_time' [35150,35164]
string: 'created_time' [35162,35176]
===
match
---
operator: = [36745,36746]
operator: = [36757,36758]
===
match
---
name: token [13888,13893]
name: token [13900,13905]
===
match
---
name: assert_called_with [6178,6196]
name: assert_called_with [6190,6208]
===
match
---
name: azure_resource [8336,8350]
name: azure_resource [8348,8362]
===
match
---
trailer [23203,23210]
trailer [23215,23222]
===
match
---
trailer [8867,8877]
trailer [8879,8889]
===
match
---
name: mock_client [29030,29041]
name: mock_client [29042,29053]
===
match
---
expr_stmt [38165,38241]
expr_stmt [38177,38253]
===
match
---
name: test_get_existing_key_v2_version [30348,30380]
name: test_get_existing_key_v2_version [30360,30392]
===
match
---
argument [11950,11976]
argument [11962,11988]
===
match
---
operator: == [30095,30097]
operator: == [30107,30109]
===
match
---
trailer [21491,21576]
trailer [21503,21588]
===
match
---
trailer [19575,19585]
trailer [19587,19597]
===
match
---
atom_expr [23384,23396]
atom_expr [23396,23408]
===
match
---
operator: , [6231,6232]
operator: , [6243,6244]
===
match
---
atom_expr [27546,27559]
atom_expr [27558,27571]
===
match
---
name: test_get_existing_key_v1 [31740,31764]
name: test_get_existing_key_v1 [31752,31776]
===
match
---
string: "pass" [22058,22064]
string: "pass" [22070,22076]
===
match
---
name: version [30234,30241]
name: version [30246,30253]
===
match
---
name: mock_file [16739,16748]
name: mock_file [16751,16760]
===
match
---
trailer [13755,13762]
trailer [13767,13774]
===
match
---
string: 'http://localhost:8180' [21411,21434]
string: 'http://localhost:8180' [21423,21446]
===
match
---
name: mock [31805,31809]
name: mock [31817,31821]
===
match
---
operator: { [30827,30828]
operator: { [30839,30840]
===
match
---
operator: } [33714,33715]
operator: } [33726,33727]
===
match
---
arglist [17733,17783]
arglist [17745,17795]
===
match
---
with_item [16624,16688]
with_item [16636,16700]
===
match
---
trailer [29078,29085]
trailer [29090,29097]
===
match
---
argument [22198,22225]
argument [22210,22237]
===
match
---
trailer [24557,24622]
trailer [24569,24634]
===
match
---
trailer [13787,13806]
trailer [13799,13818]
===
match
---
name: vault_client [39923,39935]
name: vault_client [39935,39947]
===
match
---
name: read_secret [32635,32646]
name: read_secret [32647,32658]
===
match
---
trailer [16052,16071]
trailer [16064,16083]
===
match
---
expr_stmt [28694,28749]
expr_stmt [28706,28761]
===
match
---
atom_expr [3767,3783]
atom_expr [3779,3795]
===
match
---
operator: , [42203,42204]
operator: , [42215,42216]
===
match
---
operator: , [40384,40385]
operator: , [40396,40397]
===
match
---
simple_stmt [34343,34408]
simple_stmt [34355,34420]
===
match
---
name: vault_client [35364,35376]
name: vault_client [35376,35388]
===
match
---
atom_expr [19571,19587]
atom_expr [19583,19599]
===
match
---
name: mock [6450,6454]
name: mock [6462,6466]
===
match
---
with_stmt [36878,37048]
with_stmt [36890,37060]
===
match
---
name: mock_hvac [25168,25177]
name: mock_hvac [25180,25189]
===
match
---
string: "ldap" [18267,18273]
string: "ldap" [18279,18285]
===
match
---
string: '182d0673-618c-9889-4cba-4e1f4cfe4b4b' [31964,32002]
string: '182d0673-618c-9889-4cba-4e1f4cfe4b4b' [31976,32014]
===
match
---
name: is_authenticated [18556,18572]
name: is_authenticated [18568,18584]
===
match
---
simple_stmt [30499,31142]
simple_stmt [30511,31154]
===
match
---
name: mock [41967,41971]
name: mock [41979,41983]
===
match
---
name: _VaultClient [42060,42072]
name: _VaultClient [42072,42084]
===
match
---
suite [34544,36389]
suite [34556,36401]
===
match
---
number: 8110 [42165,42169]
number: 8110 [42177,42181]
===
match
---
comparison [25615,25650]
comparison [25627,25662]
===
match
---
simple_stmt [20556,20585]
simple_stmt [20568,20597]
===
match
---
atom_expr [7094,7316]
atom_expr [7106,7328]
===
match
---
operator: { [38524,38525]
operator: { [38536,38537]
===
match
---
suite [39149,39682]
suite [39161,39694]
===
match
---
operator: = [24057,24058]
operator: = [24069,24070]
===
match
---
string: "http://localhost:8180" [13653,13676]
string: "http://localhost:8180" [13665,13688]
===
match
---
atom [36010,36211]
atom [36022,36223]
===
match
---
operator: , [29309,29310]
operator: , [29321,29322]
===
match
---
expr_stmt [39158,39188]
expr_stmt [39170,39200]
===
match
---
comparison [24262,24298]
comparison [24274,24310]
===
match
---
dotted_name [17471,17481]
dotted_name [17483,17493]
===
match
---
name: password [26285,26293]
name: password [26297,26305]
===
match
---
name: mock [18651,18655]
name: mock [18663,18667]
===
match
---
name: client [25473,25479]
name: client [25485,25491]
===
match
---
name: mock_hvac [13476,13485]
name: mock_hvac [13488,13497]
===
match
---
trailer [30425,30435]
trailer [30437,30447]
===
match
---
operator: = [17269,17270]
operator: = [17281,17282]
===
match
---
operator: = [42164,42165]
operator: = [42176,42177]
===
match
---
name: v1 [33757,33759]
name: v1 [33769,33771]
===
match
---
operator: = [5409,5410]
operator: = [5421,5422]
===
match
---
simple_stmt [4375,4404]
simple_stmt [4387,4416]
===
match
---
name: _internal_client [1019,1035]
name: _internal_client [1019,1035]
===
match
---
trailer [32989,32992]
trailer [33001,33004]
===
match
---
name: auth_type [39291,39300]
name: auth_type [39303,39312]
===
match
---
name: auth_type [20445,20454]
name: auth_type [20457,20466]
===
match
---
name: self [32852,32856]
name: self [32864,32868]
===
match
---
operator: = [41731,41732]
operator: = [41743,41744]
===
match
---
operator: @ [21686,21687]
operator: @ [21698,21699]
===
match
---
argument [5418,5429]
argument [5430,5441]
===
match
---
trailer [18506,18540]
trailer [18518,18552]
===
match
---
name: raises [36890,36896]
name: raises [36902,36908]
===
match
---
decorator [6449,6527]
decorator [6461,6539]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [4743,4807]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [4755,4819]
===
match
---
name: patch [9825,9830]
name: patch [9837,9842]
===
match
---
with_stmt [17291,17465]
with_stmt [17303,17477]
===
match
---
number: 1 [34254,34255]
number: 1 [34266,34267]
===
match
---
operator: @ [43254,43255]
operator: @ [43266,43267]
===
match
---
operator: = [5983,5984]
operator: = [5995,5996]
===
match
---
operator: @ [19420,19421]
operator: @ [19432,19433]
===
match
---
comparison [23352,23396]
comparison [23364,23408]
===
match
---
name: MagicMock [1992,2001]
name: MagicMock [1992,2001]
===
match
---
operator: == [4692,4694]
operator: == [4704,4706]
===
match
---
operator: , [33289,33290]
operator: , [33301,33302]
===
match
---
simple_stmt [35364,35498]
simple_stmt [35376,35510]
===
match
---
simple_stmt [33984,34015]
simple_stmt [33996,34027]
===
match
---
funcdef [18732,19415]
funcdef [18744,19427]
===
match
---
name: v1 [42410,42412]
name: v1 [42422,42424]
===
match
---
arglist [7766,7939]
arglist [7778,7951]
===
match
---
simple_stmt [27380,27424]
simple_stmt [27392,27436]
===
match
---
name: client [15794,15800]
name: client [15806,15812]
===
match
---
operator: = [34198,34199]
operator: = [34210,34211]
===
match
---
suite [22940,23500]
suite [22952,23512]
===
match
---
decorator [24304,24382]
decorator [24316,24394]
===
match
---
atom_expr [6993,7012]
atom_expr [7005,7024]
===
match
---
name: url [12110,12113]
name: url [12122,12125]
===
match
---
argument [18309,18336]
argument [18321,18348]
===
match
---
name: vault_client [43159,43171]
name: vault_client [43171,43183]
===
match
---
trailer [40680,40863]
trailer [40692,40875]
===
match
---
arglist [26841,26923]
arglist [26853,26935]
===
match
---
name: vault_client [13528,13540]
name: vault_client [13540,13552]
===
match
---
string: "resource" [6818,6828]
string: "resource" [6830,6840]
===
match
---
trailer [12090,12109]
trailer [12102,12121]
===
match
---
name: assert_called_with [13041,13059]
name: assert_called_with [13053,13071]
===
match
---
name: self [41198,41202]
name: self [41210,41214]
===
match
---
expr_stmt [12792,12835]
expr_stmt [12804,12847]
===
match
---
parameters [1592,1609]
parameters [1592,1609]
===
match
---
atom_expr [27486,27543]
atom_expr [27498,27555]
===
match
---
operator: = [21527,21528]
operator: = [21539,21540]
===
match
---
name: mock [14206,14210]
name: mock [14218,14222]
===
match
---
expr_stmt [2065,2135]
expr_stmt [2065,2135]
===
match
---
operator: = [25538,25539]
operator: = [25550,25551]
===
match
---
trailer [20672,20677]
trailer [20684,20689]
===
match
---
atom_expr [22585,22601]
atom_expr [22597,22613]
===
match
---
argument [21536,21545]
argument [21548,21557]
===
match
---
atom_expr [1658,1687]
atom_expr [1658,1687]
===
match
---
param [19531,19536]
param [19543,19548]
===
match
---
parameters [34526,34543]
parameters [34538,34555]
===
match
---
string: 'created_time' [29472,29486]
string: 'created_time' [29484,29498]
===
match
---
name: version [38980,38987]
name: version [38992,38999]
===
match
---
operator: = [40828,40829]
operator: = [40840,40841]
===
match
---
operator: == [23472,23474]
operator: == [23484,23486]
===
match
---
atom_expr [10771,10822]
atom_expr [10783,10834]
===
match
---
name: secrets [31895,31902]
name: secrets [31907,31914]
===
match
---
name: radius_port [40031,40042]
name: radius_port [40043,40054]
===
match
---
decorated [3615,3997]
decorated [3627,4009]
===
match
---
string: '' [34798,34800]
string: '' [34810,34812]
===
match
---
expr_stmt [25809,25839]
expr_stmt [25821,25851]
===
match
---
operator: , [39344,39345]
operator: , [39356,39357]
===
match
---
trailer [18471,18476]
trailer [18483,18488]
===
match
---
trailer [42771,42784]
trailer [42783,42796]
===
match
---
dictorsetmaker [42524,42538]
dictorsetmaker [42536,42550]
===
match
---
operator: , [31028,31029]
operator: , [31040,31041]
===
match
---
name: mock [36548,36552]
name: mock [36560,36564]
===
match
---
operator: , [7305,7306]
operator: , [7317,7318]
===
match
---
operator: = [39401,39402]
operator: = [39413,39414]
===
match
---
name: mock [18813,18817]
name: mock [18825,18829]
===
match
---
expr_stmt [18216,18346]
expr_stmt [18228,18358]
===
match
---
name: mock [21687,21691]
name: mock [21699,21703]
===
match
---
atom_expr [40877,40960]
atom_expr [40889,40972]
===
match
---
name: return_value [6655,6667]
name: return_value [6667,6679]
===
match
---
operator: = [10633,10634]
operator: = [10645,10646]
===
match
---
argument [25530,25545]
argument [25542,25557]
===
match
---
atom [37623,37824]
atom [37635,37836]
===
match
---
name: mock [16299,16303]
name: mock [16311,16315]
===
match
---
simple_stmt [25900,26110]
simple_stmt [25912,26122]
===
match
---
number: 2 [22393,22394]
number: 2 [22405,22406]
===
match
---
dictorsetmaker [37645,37806]
dictorsetmaker [37657,37818]
===
match
---
expr_stmt [4166,4209]
expr_stmt [4178,4221]
===
match
---
funcdef [43336,44030]
funcdef [43348,44042]
===
match
---
trailer [23067,23173]
trailer [23079,23185]
===
match
---
name: self [22923,22927]
name: self [22935,22939]
===
match
---
name: url [9305,9308]
name: url [9317,9320]
===
match
---
trailer [7005,7012]
trailer [7017,7024]
===
match
---
operator: = [3953,3954]
operator: = [3965,3966]
===
match
---
trailer [4145,4155]
trailer [4157,4167]
===
match
---
name: _VaultClient [34090,34102]
name: _VaultClient [34102,34114]
===
match
---
simple_stmt [22162,22227]
simple_stmt [22174,22239]
===
match
---
string: "token" [35415,35422]
string: "token" [35427,35434]
===
match
---
trailer [14294,14301]
trailer [14306,14313]
===
match
---
string: 'lease_duration' [29323,29339]
string: 'lease_duration' [29335,29351]
===
match
---
operator: = [12944,12945]
operator: = [12956,12957]
===
match
---
argument [31192,31210]
argument [31204,31222]
===
match
---
name: read_secret_version [30525,30544]
name: read_secret_version [30537,30556]
===
match
---
name: _VaultClient [3916,3928]
name: _VaultClient [3928,3940]
===
match
---
atom_expr [8940,8968]
atom_expr [8952,8980]
===
match
---
name: vault_client [25900,25912]
name: vault_client [25912,25924]
===
match
---
name: _VaultClient [15521,15533]
name: _VaultClient [15533,15545]
===
match
---
decorator [9819,9904]
decorator [9831,9916]
===
match
---
string: "'github' authentication type requires 'token'" [14320,14367]
string: "'github' authentication type requires 'token'" [14332,14379]
===
match
---
name: assert_called_once_with [42437,42460]
name: assert_called_once_with [42449,42472]
===
match
---
simple_stmt [31791,31822]
simple_stmt [31803,31834]
===
match
---
param [4107,4116]
param [4119,4128]
===
match
---
trailer [20050,20085]
trailer [20062,20097]
===
match
---
name: MagicMock [1638,1647]
name: MagicMock [1638,1647]
===
match
---
operator: @ [4002,4003]
operator: @ [4014,4015]
===
match
---
string: '' [35234,35236]
string: '' [35246,35248]
===
match
---
trailer [21071,21084]
trailer [21083,21096]
===
match
---
trailer [42744,42746]
trailer [42756,42758]
===
match
---
atom_expr [1809,1833]
atom_expr [1809,1833]
===
match
---
simple_stmt [27933,28077]
simple_stmt [27945,28089]
===
match
---
trailer [7037,7056]
trailer [7049,7068]
===
match
---
argument [23255,23282]
argument [23267,23294]
===
match
---
name: pytest [3849,3855]
name: pytest [3861,3867]
===
match
---
operator: } [38493,38494]
operator: } [38505,38506]
===
match
---
simple_stmt [16958,17003]
simple_stmt [16970,17015]
===
match
---
parameters [25782,25799]
parameters [25794,25811]
===
match
---
name: return_value [3809,3821]
name: return_value [3821,3833]
===
match
---
operator: = [39936,39937]
operator: = [39948,39949]
===
match
---
name: Client [17672,17678]
name: Client [17684,17690]
===
match
---
trailer [28271,28278]
trailer [28283,28290]
===
match
---
comparison [24151,24195]
comparison [24163,24207]
===
match
---
operator: = [4451,4452]
operator: = [4463,4464]
===
match
---
name: radius_port [41424,41435]
name: radius_port [41436,41447]
===
match
---
operator: == [17020,17022]
operator: == [17032,17034]
===
match
---
name: azure_tenant_id [7801,7816]
name: azure_tenant_id [7813,7828]
===
match
---
string: "requires 'role_id'" [3881,3901]
string: "requires 'role_id'" [3893,3913]
===
match
---
name: create_or_update_secret [43172,43195]
name: create_or_update_secret [43184,43207]
===
match
---
argument [12905,12939]
argument [12917,12951]
===
match
---
arglist [2093,2134]
arglist [2093,2134]
===
match
---
operator: = [2078,2079]
operator: = [2078,2079]
===
match
---
string: 'pass' [6920,6926]
string: 'pass' [6932,6938]
===
match
---
string: 'deletion_time' [29539,29554]
string: 'deletion_time' [29551,29566]
===
match
---
operator: @ [2192,2193]
operator: @ [2192,2193]
===
match
---
parameters [22544,22561]
parameters [22556,22573]
===
match
---
operator: , [36512,36513]
operator: , [36524,36525]
===
match
---
dictorsetmaker [38271,38828]
dictorsetmaker [38283,38840]
===
match
---
dotted_name [32715,32725]
dotted_name [32727,32737]
===
match
---
name: raises [39514,39520]
name: raises [39526,39532]
===
match
---
name: Client [10708,10714]
name: Client [10720,10726]
===
match
---
argument [28515,28536]
argument [28527,28548]
===
match
---
operator: = [6116,6117]
operator: = [6128,6129]
===
match
---
name: is_authenticated [26338,26354]
name: is_authenticated [26350,26366]
===
match
---
atom_expr [42060,42288]
atom_expr [42072,42300]
===
match
---
name: patch [41082,41087]
name: patch [41094,41099]
===
match
---
operator: , [11936,11937]
operator: , [11948,11949]
===
match
---
name: radius_host [38019,38030]
name: radius_host [38031,38042]
===
match
---
dictorsetmaker [30849,31010]
dictorsetmaker [30861,31022]
===
match
---
operator: = [38065,38066]
operator: = [38077,38078]
===
match
---
trailer [33795,33833]
trailer [33807,33845]
===
match
---
atom_expr [9402,9533]
atom_expr [9414,9545]
===
match
---
operator: = [15169,15170]
operator: = [15181,15182]
===
match
---
simple_stmt [12581,12624]
simple_stmt [12593,12636]
===
match
---
operator: = [23911,23912]
operator: = [23923,23924]
===
match
---
string: 'deletion_time' [35880,35895]
string: 'deletion_time' [35892,35907]
===
match
---
operator: , [31309,31310]
operator: , [31321,31322]
===
match
---
name: v1 [43875,43877]
name: v1 [43887,43889]
===
match
---
simple_stmt [5784,6032]
simple_stmt [5796,6044]
===
match
---
trailer [11069,11088]
trailer [11081,11100]
===
match
---
operator: = [20501,20502]
operator: = [20513,20514]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [28905,28969]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [28917,28981]
===
match
---
trailer [22375,22377]
trailer [22387,22389]
===
match
---
operator: @ [2842,2843]
operator: @ [2848,2849]
===
match
---
name: self [31765,31769]
name: self [31777,31781]
===
match
---
name: test_create_or_update_secret_v2 [39773,39804]
name: test_create_or_update_secret_v2 [39785,39816]
===
match
---
name: VaultError [40891,40901]
name: VaultError [40903,40913]
===
match
---
atom_expr [16711,16730]
atom_expr [16723,16742]
===
match
---
string: 'world' [32582,32589]
string: 'world' [32594,32601]
===
match
---
comparison [24211,24246]
comparison [24223,24258]
===
match
---
decorator [3615,3693]
decorator [3627,3705]
===
match
---
name: mount_point [23488,23499]
name: mount_point [23500,23511]
===
match
---
name: mock_client [21087,21098]
name: mock_client [21099,21110]
===
match
---
expr_stmt [20556,20584]
expr_stmt [20568,20596]
===
match
---
name: mount_point [19290,19301]
name: mount_point [19302,19313]
===
match
---
name: test_aws_iam_different_auth_mount_point [4817,4856]
name: test_aws_iam_different_auth_mount_point [4829,4868]
===
match
---
name: url [29946,29949]
name: url [29958,29961]
===
match
---
assert_stmt [15239,15281]
assert_stmt [15251,15293]
===
match
---
name: credentials [9673,9684]
name: credentials [9685,9696]
===
match
---
operator: = [28526,28527]
operator: = [28538,28539]
===
match
---
name: mock [25657,25661]
name: mock [25669,25673]
===
match
---
operator: == [18611,18613]
operator: == [18623,18625]
===
match
---
operator: , [38070,38071]
operator: , [38082,38083]
===
match
---
name: return_value [27397,27409]
name: return_value [27409,27421]
===
match
---
name: url [40825,40828]
name: url [40837,40840]
===
match
---
name: mock [43255,43259]
name: mock [43267,43271]
===
match
---
name: mock_hvac [1658,1667]
name: mock_hvac [1658,1667]
===
match
---
name: password [25300,25308]
name: password [25312,25320]
===
match
---
atom_expr [17296,17357]
atom_expr [17308,17369]
===
match
---
string: 'pass' [5154,5160]
string: 'pass' [5166,5172]
===
match
---
expr_stmt [31151,31361]
expr_stmt [31163,31373]
===
match
---
argument [34367,34388]
argument [34379,34400]
===
match
---
name: self [8784,8788]
name: self [8796,8800]
===
match
---
atom_expr [21650,21680]
atom_expr [21662,21692]
===
match
---
operator: , [11889,11890]
operator: , [11901,11902]
===
match
---
decorated [31654,32709]
decorated [31666,32721]
===
match
---
trailer [17725,17732]
trailer [17737,17744]
===
match
---
operator: } [35109,35110]
operator: } [35121,35122]
===
match
---
simple_stmt [20313,20344]
simple_stmt [20325,20356]
===
match
---
name: auth_userpass [25480,25493]
name: auth_userpass [25492,25505]
===
match
---
expr_stmt [14192,14222]
expr_stmt [14204,14234]
===
match
---
parameters [41926,41943]
parameters [41938,41955]
===
match
---
trailer [18476,18481]
trailer [18488,18493]
===
match
---
name: vault_client [20829,20841]
name: vault_client [20841,20853]
===
match
---
arglist [28016,28066]
arglist [28028,28078]
===
match
---
argument [18931,18947]
argument [18943,18959]
===
match
---
param [8784,8789]
param [8796,8801]
===
match
---
trailer [24927,24945]
trailer [24939,24957]
===
match
---
name: mock [11622,11626]
name: mock [11634,11638]
===
match
---
operator: = [21990,21991]
operator: = [22002,22003]
===
match
---
simple_stmt [10971,11036]
simple_stmt [10983,11048]
===
match
---
string: 'value' [40376,40383]
string: 'value' [40388,40395]
===
match
---
expr_stmt [30499,31141]
expr_stmt [30511,31153]
===
match
---
number: 2 [13245,13246]
number: 2 [13257,13258]
===
match
---
operator: = [9034,9035]
operator: = [9046,9047]
===
match
---
name: _VaultClient [29789,29801]
name: _VaultClient [29801,29813]
===
match
---
funcdef [4084,4726]
funcdef [4096,4738]
===
match
---
name: kv_engine_version [9796,9813]
name: kv_engine_version [9808,9825]
===
match
---
expr_stmt [9074,9223]
expr_stmt [9086,9235]
===
match
---
argument [10884,10904]
argument [10896,10916]
===
match
---
name: Client [36583,36589]
name: Client [36595,36601]
===
match
---
argument [13807,13834]
argument [13819,13846]
===
match
---
operator: = [6668,6669]
operator: = [6680,6681]
===
match
---
name: mock_hvac [40541,40550]
name: mock_hvac [40553,40562]
===
match
---
argument [6278,6294]
argument [6290,6306]
===
match
---
argument [34306,34328]
argument [34318,34340]
===
match
---
argument [16820,16847]
argument [16832,16859]
===
match
---
trailer [3801,3808]
trailer [3813,3820]
===
match
---
name: auth_mount_point [13690,13706]
name: auth_mount_point [13702,13718]
===
match
---
name: secrets [41645,41652]
name: secrets [41657,41664]
===
match
---
operator: @ [8581,8582]
operator: @ [8593,8594]
===
match
---
expr_stmt [16376,16610]
expr_stmt [16388,16622]
===
match
---
operator: = [18903,18904]
operator: = [18915,18916]
===
match
---
trailer [17732,17784]
trailer [17744,17796]
===
match
---
operator: , [40539,40540]
operator: , [40551,40552]
===
match
---
dictorsetmaker [32124,32140]
dictorsetmaker [32136,32152]
===
match
---
operator: = [42196,42197]
operator: = [42208,42209]
===
match
---
operator: , [19043,19044]
operator: , [19055,19056]
===
match
---
param [26547,26552]
param [26559,26564]
===
match
---
simple_stmt [18355,18384]
simple_stmt [18367,18396]
===
match
---
name: path [38964,38968]
name: path [38976,38980]
===
match
---
with_stmt [16619,16731]
with_stmt [16631,16743]
===
match
---
operator: , [13415,13416]
operator: , [13427,13428]
===
match
---
name: secrets [32621,32628]
name: secrets [32633,32640]
===
match
---
operator: = [32697,32698]
operator: = [32709,32710]
===
match
---
name: mount_point [33796,33807]
name: mount_point [33808,33819]
===
match
---
string: "user" [6890,6896]
string: "user" [6902,6908]
===
match
---
name: mock [14450,14454]
name: mock [14462,14466]
===
match
---
trailer [6196,6339]
trailer [6208,6351]
===
match
---
string: "key" [12289,12294]
string: "key" [12301,12306]
===
match
---
name: radius_host [21979,21990]
name: radius_host [21991,22002]
===
match
---
argument [21947,21965]
argument [21959,21977]
===
match
---
arglist [34294,34328]
arglist [34306,34340]
===
match
---
operator: , [20291,20292]
operator: , [20303,20304]
===
match
---
trailer [26337,26354]
trailer [26349,26366]
===
match
---
simple_stmt [19319,19364]
simple_stmt [19331,19376]
===
match
---
param [22929,22938]
param [22941,22950]
===
match
---
string: "requires 'azure_tenant_id'" [8228,8256]
string: "requires 'azure_tenant_id'" [8240,8268]
===
match
---
atom_expr [39845,39861]
atom_expr [39857,39873]
===
match
---
argument [36764,36784]
argument [36776,36796]
===
match
---
string: 'lease_duration' [37496,37512]
string: 'lease_duration' [37508,37524]
===
match
---
name: Client [40610,40616]
name: Client [40622,40628]
===
match
---
name: vault_client [6049,6061]
name: vault_client [6061,6073]
===
match
---
name: mock_client [1973,1984]
name: mock_client [1973,1984]
===
match
---
parameters [5666,5683]
parameters [5678,5695]
===
match
---
operator: , [24592,24593]
operator: , [24604,24605]
===
match
---
atom_expr [36992,37047]
atom_expr [37004,37059]
===
match
---
name: patch [8695,8700]
name: patch [8707,8712]
===
match
---
operator: , [38351,38352]
operator: , [38363,38364]
===
match
---
name: auth_approle [2667,2679]
name: approle [2672,2679]
===
match
---
name: VaultError [8210,8220]
name: VaultError [8222,8232]
===
match
---
comparison [26391,26426]
comparison [26403,26438]
===
match
---
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [24564,24592]
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [24576,24604]
===
match
---
expr_stmt [13528,13725]
expr_stmt [13540,13737]
===
match
---
operator: , [34255,34256]
operator: , [34267,34268]
===
match
---
argument [11007,11034]
argument [11019,11046]
===
match
---
argument [2093,2113]
argument [2093,2113]
===
match
---
decorator [18003,18081]
decorator [18015,18093]
===
match
---
trailer [5239,5246]
trailer [5251,5258]
===
match
---
operator: @ [22826,22827]
operator: @ [22838,22839]
===
match
---
suite [21806,22429]
suite [21818,22441]
===
match
---
atom [11730,11750]
atom [11742,11762]
===
match
---
string: "user" [18284,18290]
string: "user" [18296,18302]
===
match
---
trailer [37973,38156]
trailer [37985,38168]
===
match
---
name: mock_hvac [41933,41942]
name: mock_hvac [41945,41954]
===
match
---
name: mock [13287,13291]
name: mock [13299,13303]
===
match
---
trailer [42734,42744]
trailer [42746,42756]
===
match
---
trailer [21863,21870]
trailer [21875,21882]
===
match
---
operator: , [30935,30936]
operator: , [30947,30948]
===
match
---
operator: { [30064,30065]
operator: { [30076,30077]
===
match
---
operator: = [5123,5124]
operator: = [5135,5136]
===
match
---
simple_stmt [840,875]
simple_stmt [840,875]
===
match
---
expr_stmt [14590,14620]
expr_stmt [14602,14632]
===
match
---
name: vault_client [24973,24985]
name: vault_client [24985,24997]
===
match
---
name: patch [17065,17070]
name: patch [17077,17082]
===
match
---
argument [32421,32440]
argument [32433,32452]
===
match
---
expr_stmt [15506,15702]
expr_stmt [15518,15714]
===
match
---
operator: @ [26432,26433]
operator: @ [26444,26445]
===
match
---
name: mock_client [19628,19639]
name: mock_client [19640,19651]
===
match
---
assert_stmt [27881,27924]
assert_stmt [27893,27936]
===
match
---
operator: = [31860,31861]
operator: = [31872,31873]
===
match
---
expr_stmt [28368,28433]
expr_stmt [28380,28445]
===
match
---
name: mock_hvac [1227,1236]
name: mock_hvac [1227,1236]
===
match
---
name: VaultError [7676,7686]
name: VaultError [7688,7698]
===
match
---
operator: , [39809,39810]
operator: , [39821,39822]
===
match
---
trailer [20694,20713]
trailer [20706,20725]
===
match
---
atom [29450,29651]
atom [29462,29663]
===
match
---
dictorsetmaker [35150,35311]
dictorsetmaker [35162,35323]
===
match
---
name: mock_hvac [6077,6086]
name: mock_hvac [6089,6098]
===
match
---
name: radius_secret [40061,40074]
name: radius_secret [40073,40086]
===
match
---
operator: = [18868,18869]
operator: = [18880,18881]
===
match
---
name: resource [7189,7197]
name: resource [7201,7209]
===
match
---
name: secret [32501,32507]
name: secret [32513,32519]
===
match
---
name: mock_client [2994,3005]
name: mock_client [3000,3011]
===
match
---
operator: , [26551,26552]
operator: , [26563,26564]
===
match
---
argument [22078,22105]
argument [22090,22117]
===
match
---
argument [9132,9156]
argument [9144,9168]
===
match
---
name: assert_called_with [13788,13806]
name: assert_called_with [13800,13818]
===
match
---
string: 'secret' [28862,28870]
string: 'secret' [28874,28882]
===
match
---
atom_expr [42755,42784]
atom_expr [42767,42796]
===
match
---
string: "radius" [40704,40712]
string: "radius" [40716,40724]
===
match
---
assert_stmt [2794,2836]
assert_stmt [2800,2842]
===
match
---
name: mock [39009,39013]
name: mock [39021,39025]
===
match
---
name: mock_client [5764,5775]
name: mock_client [5776,5787]
===
match
---
name: auth_type [36667,36676]
name: auth_type [36679,36688]
===
match
---
string: "pass" [40075,40081]
string: "pass" [40087,40093]
===
match
---
simple_stmt [13844,13945]
simple_stmt [13856,13957]
===
match
---
atom_expr [3311,3330]
atom_expr [3317,3336]
===
match
---
argument [34147,34181]
argument [34159,34193]
===
match
---
name: return_value [11715,11727]
name: return_value [11727,11739]
===
match
---
trailer [16303,16313]
trailer [16315,16325]
===
match
---
name: mock [25004,25008]
name: mock [25016,25020]
===
match
---
decorated [7426,7954]
decorated [7438,7966]
===
match
---
name: Client [30456,30462]
name: Client [30468,30474]
===
match
---
name: mock_get_scopes [9342,9357]
name: mock_get_scopes [9354,9369]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [18662,18726]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [18674,18738]
===
match
---
name: VaultError [36897,36907]
name: VaultError [36909,36919]
===
match
---
trailer [33363,33617]
trailer [33375,33629]
===
match
---
operator: , [23755,23756]
operator: , [23767,23768]
===
match
---
trailer [10231,10233]
trailer [10243,10245]
===
match
---
trailer [5334,5347]
trailer [5346,5359]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [41821,41885]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [41833,41897]
===
match
---
operator: = [11677,11678]
operator: = [11689,11690]
===
match
---
operator: = [40367,40368]
operator: = [40379,40380]
===
match
---
trailer [30182,30256]
trailer [30194,30268]
===
match
---
operator: = [25270,25271]
operator: = [25282,25283]
===
match
---
name: url [3375,3378]
name: url [3381,3384]
===
match
---
expr_stmt [34644,35355]
expr_stmt [34656,35367]
===
match
---
dotted_name [36395,36405]
dotted_name [36407,36417]
===
match
---
with_stmt [7657,7954]
with_stmt [7669,7966]
===
match
---
simple_stmt [27006,27028]
simple_stmt [27018,27040]
===
match
---
simple_stmt [16739,16776]
simple_stmt [16751,16788]
===
match
---
atom_expr [16299,16315]
atom_expr [16311,16327]
===
match
---
operator: , [9156,9157]
operator: , [9168,9169]
===
match
---
name: auth [20673,20677]
name: auth [20685,20689]
===
match
---
operator: @ [32714,32715]
operator: @ [32726,32727]
===
match
---
expr_stmt [18125,18155]
expr_stmt [18137,18167]
===
match
---
trailer [39206,39213]
trailer [39218,39225]
===
match
---
operator: , [12273,12274]
operator: , [12285,12286]
===
match
---
name: radius_host [20132,20143]
name: radius_host [20144,20155]
===
match
---
operator: == [22395,22397]
operator: == [22407,22409]
===
match
---
argument [38219,38240]
argument [38231,38252]
===
match
---
operator: , [4554,4555]
operator: , [4566,4567]
===
match
---
comparison [18609,18644]
comparison [18621,18656]
===
match
---
decorated [11246,12624]
decorated [11258,12636]
===
match
---
name: self [12727,12731]
name: self [12739,12743]
===
match
---
number: 1 [39440,39441]
number: 1 [39452,39453]
===
match
---
name: auth_type [3929,3938]
name: auth_type [3941,3950]
===
match
---
name: match [34306,34311]
name: match [34318,34323]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [15299,15363]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [15311,15375]
===
match
---
trailer [20111,20183]
trailer [20123,20195]
===
match
---
name: url [21287,21290]
name: url [21299,21302]
===
match
---
param [25103,25108]
param [25115,25120]
===
match
---
name: secret_id [3979,3988]
name: secret_id [3991,4000]
===
match
---
operator: = [34704,34705]
operator: = [34716,34717]
===
match
---
simple_stmt [15831,15868]
simple_stmt [15843,15880]
===
match
---
name: return_value [20369,20381]
name: return_value [20381,20393]
===
match
---
simple_stmt [986,1077]
simple_stmt [986,1077]
===
match
---
name: test_radius [20275,20286]
name: test_radius [20287,20298]
===
match
---
operator: = [27164,27165]
operator: = [27176,27177]
===
match
---
name: patch [12635,12640]
name: patch [12647,12652]
===
match
---
operator: = [31270,31271]
operator: = [31282,31283]
===
match
---
suite [3744,3997]
suite [3756,4009]
===
match
---
suite [10194,11241]
suite [10206,11253]
===
match
---
argument [11116,11135]
argument [11128,11147]
===
match
---
atom_expr [38859,39002]
atom_expr [38871,39014]
===
match
---
operator: == [38839,38841]
operator: == [38851,38853]
===
match
---
string: "The method parameter is only valid for version 1" [40909,40959]
string: "The method parameter is only valid for version 1" [40921,40971]
===
match
---
expr_stmt [18355,18383]
expr_stmt [18367,18395]
===
match
---
atom_expr [31379,31443]
atom_expr [31391,31455]
===
match
---
name: mock_hvac [20996,21005]
name: mock_hvac [21008,21017]
===
match
---
trailer [11168,11187]
trailer [11180,11199]
===
match
---
simple_stmt [32501,32557]
simple_stmt [32513,32569]
===
match
---
string: 'metadata' [37611,37621]
string: 'metadata' [37623,37633]
===
match
---
parameters [3726,3743]
parameters [3738,3755]
===
match
---
name: mock_file [15831,15840]
name: mock_file [15843,15852]
===
match
---
operator: = [43472,43473]
operator: = [43484,43485]
===
match
---
atom_expr [16324,16353]
atom_expr [16336,16365]
===
match
---
name: self [40535,40539]
name: self [40547,40551]
===
match
---
name: kv_engine_version [2169,2186]
name: kv_engine_version [2169,2186]
===
match
---
expr_stmt [29069,29112]
expr_stmt [29081,29124]
===
match
---
operator: , [41029,41030]
operator: , [41041,41042]
===
match
---
trailer [7748,7953]
trailer [7760,7965]
===
match
---
operator: @ [9819,9820]
operator: @ [9831,9832]
===
match
---
string: 'metadata' [34879,34889]
string: 'metadata' [34891,34901]
===
match
---
arglist [36897,36977]
arglist [36909,36989]
===
match
---
string: "http://localhost:8180" [25321,25344]
string: "http://localhost:8180" [25333,25356]
===
match
---
name: mock_hvac [15876,15885]
name: mock_hvac [15888,15897]
===
match
---
string: '' [35897,35899]
string: '' [35909,35911]
===
match
---
operator: , [11558,11559]
operator: , [11570,11571]
===
match
---
name: VaultError [20051,20061]
name: VaultError [20063,20073]
===
match
---
dotted_name [39688,39698]
dotted_name [39700,39710]
===
match
---
name: is_authenticated [7332,7348]
name: is_authenticated [7344,7360]
===
match
---
name: get_secret [31392,31402]
name: get_secret [31404,31414]
===
match
---
parameters [2290,2307]
parameters [2290,2307]
===
match
---
argument [15547,15569]
argument [15559,15581]
===
match
---
operator: = [3988,3989]
operator: = [4000,4001]
===
match
---
argument [38980,38992]
argument [38992,39004]
===
match
---
trailer [9577,9606]
trailer [9589,9618]
===
match
---
argument [4280,4294]
argument [4292,4306]
===
match
---
trailer [6093,6112]
trailer [6105,6124]
===
match
---
operator: , [32407,32408]
operator: , [32419,32420]
===
match
---
simple_stmt [14681,14813]
simple_stmt [14693,14825]
===
match
---
operator: { [43811,43812]
operator: { [43823,43824]
===
match
---
trailer [40986,41010]
trailer [40998,41022]
===
match
---
operator: , [29277,29278]
operator: , [29289,29290]
===
match
---
trailer [17651,17653]
trailer [17663,17665]
===
match
---
dotted_name [18004,18014]
dotted_name [18016,18026]
===
match
---
operator: = [22132,22133]
operator: = [22144,22145]
===
match
---
expr_stmt [14904,14932]
expr_stmt [14916,14944]
===
match
---
operator: = [12391,12392]
operator: = [12403,12404]
===
match
---
atom_expr [42730,42746]
atom_expr [42742,42758]
===
match
---
simple_stmt [20817,20860]
simple_stmt [20829,20872]
===
match
---
param [26553,26562]
param [26565,26574]
===
match
---
operator: , [29249,29250]
operator: , [29261,29262]
===
match
---
name: auth_type [2449,2458]
name: auth_type [2449,2458]
===
match
---
string: "tenant_id" [6220,6231]
string: "tenant_id" [6232,6243]
===
match
---
name: client [7006,7012]
name: client [7018,7024]
===
match
---
operator: , [7208,7209]
operator: , [7220,7221]
===
match
---
name: is_authenticated [24098,24114]
name: is_authenticated [24110,24126]
===
match
---
string: 'http://localhost:8180' [26195,26218]
string: 'http://localhost:8180' [26207,26230]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [1495,1559]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [1495,1559]
===
match
---
name: kubernetes_jwt_path [17408,17427]
name: kubernetes_jwt_path [17420,17439]
===
match
---
operator: = [36710,36711]
operator: = [36722,36723]
===
match
---
atom_expr [5799,6031]
atom_expr [5811,6043]
===
match
---
param [10144,10154]
param [10156,10166]
===
match
---
trailer [28715,28726]
trailer [28727,28738]
===
match
---
string: "http://localhost:8180" [43017,43040]
string: "http://localhost:8180" [43029,43052]
===
match
---
comparison [9778,9813]
comparison [9790,9825]
===
match
---
name: auth_type [41357,41366]
name: auth_type [41369,41378]
===
match
---
trailer [20787,20806]
trailer [20799,20818]
===
match
---
operator: { [29364,29365]
operator: { [29376,29377]
===
match
---
funcdef [28164,28888]
funcdef [28176,28900]
===
match
---
name: mock_client [1318,1329]
name: mock_client [1318,1329]
===
match
---
operator: = [13063,13064]
operator: = [13075,13076]
===
match
---
simple_stmt [12147,12199]
simple_stmt [12159,12211]
===
match
---
argument [21287,21314]
argument [21299,21326]
===
match
---
operator: , [4105,4106]
operator: , [4117,4118]
===
match
---
operator: { [38438,38439]
operator: { [38450,38451]
===
match
---
operator: , [18777,18778]
operator: , [18789,18790]
===
match
---
name: test_version_one_init [1925,1946]
name: test_version_one_init [1925,1946]
===
match
---
trailer [2783,2785]
trailer [2789,2791]
===
match
---
string: 'secret' [33808,33816]
string: 'secret' [33820,33828]
===
match
---
trailer [32981,32989]
trailer [32993,33001]
===
match
---
atom_expr [12352,12416]
atom_expr [12364,12428]
===
match
---
name: MagicMock [7585,7594]
name: MagicMock [7597,7606]
===
match
---
name: return_value [28279,28291]
name: return_value [28291,28303]
===
match
---
name: url [15069,15072]
name: url [15081,15084]
===
match
---
string: "resource" [5912,5922]
string: "resource" [5924,5934]
===
match
---
operator: , [42932,42933]
operator: , [42944,42945]
===
match
---
name: key_id [7891,7897]
name: key_id [7903,7909]
===
match
---
name: secret [42354,42360]
name: secret [42366,42372]
===
match
---
operator: = [5762,5763]
operator: = [5774,5775]
===
match
---
argument [7688,7721]
argument [7700,7733]
===
match
---
name: mock_client [27412,27423]
name: mock_client [27424,27435]
===
match
---
name: is_authenticated [9725,9741]
name: is_authenticated [9737,9753]
===
match
---
trailer [21134,21325]
trailer [21146,21337]
===
match
---
operator: = [39170,39171]
operator: = [39182,39183]
===
match
---
trailer [41547,41571]
trailer [41559,41583]
===
match
---
trailer [8148,8155]
trailer [8160,8167]
===
match
---
name: vault_client [4974,4986]
name: vault_client [4986,4998]
===
match
---
string: "user" [25522,25528]
string: "user" [25534,25540]
===
match
---
trailer [12387,12416]
trailer [12399,12428]
===
match
---
string: "http://localhost:8180" [4300,4323]
string: "http://localhost:8180" [4312,4335]
===
match
---
name: VaultError [22681,22691]
name: VaultError [22693,22703]
===
match
---
name: mock_hvac [14231,14240]
name: mock_hvac [14243,14252]
===
match
---
arglist [14302,14367]
arglist [14314,14379]
===
match
---
operator: = [32400,32401]
operator: = [32412,32413]
===
match
---
trailer [5366,5460]
trailer [5378,5472]
===
match
---
trailer [25864,25877]
trailer [25876,25889]
===
match
---
expr_stmt [36626,36869]
expr_stmt [36638,36881]
===
match
---
atom_expr [43065,43145]
atom_expr [43077,43157]
===
match
---
trailer [2168,2186]
trailer [2168,2186]
===
match
---
name: url [3187,3190]
name: url [3193,3196]
===
match
---
atom [33210,33228]
atom [33222,33240]
===
match
---
name: mock [7427,7431]
name: mock [7439,7443]
===
match
---
atom_expr [39197,39226]
atom_expr [39209,39238]
===
match
---
argument [41787,41793]
argument [41799,41805]
===
match
---
string: "http://localhost:8180" [40099,40122]
string: "http://localhost:8180" [40111,40134]
===
match
---
atom_expr [39507,39602]
atom_expr [39519,39614]
===
match
---
operator: = [41293,41294]
operator: = [41305,41306]
===
match
---
operator: , [35992,35993]
operator: , [36004,36005]
===
match
---
suite [43394,44030]
suite [43406,44042]
===
match
---
atom_expr [22760,22820]
atom_expr [22772,22832]
===
match
---
operator: , [1758,1759]
operator: , [1758,1759]
===
match
---
expr_stmt [11608,11638]
expr_stmt [11620,11650]
===
match
---
name: secret_id [5144,5153]
name: secret_id [5156,5165]
===
match
---
suite [14369,14444]
suite [14381,14456]
===
match
---
name: mock_hvac [2012,2021]
name: mock_hvac [2012,2021]
===
match
---
name: vault_client [9241,9253]
name: vault_client [9253,9265]
===
match
---
suite [7557,7954]
suite [7569,7966]
===
match
---
operator: } [31042,31043]
operator: } [31054,31055]
===
match
---
operator: = [36834,36835]
operator: = [36846,36847]
===
match
---
name: Client [43452,43458]
name: Client [43464,43470]
===
match
---
name: v2 [37318,37320]
name: v2 [37330,37332]
===
match
---
operator: , [2295,2296]
operator: , [2295,2296]
===
match
---
atom_expr [14941,15024]
atom_expr [14953,15036]
===
match
---
comparison [12588,12623]
comparison [12600,12635]
===
match
---
name: test_aws_iam [4088,4100]
name: test_aws_iam [4100,4112]
===
match
---
operator: = [14319,14320]
operator: = [14331,14332]
===
match
---
operator: @ [12629,12630]
operator: @ [12641,12642]
===
match
---
atom_expr [5227,5246]
atom_expr [5239,5258]
===
match
---
name: patch [16624,16629]
name: patch [16636,16641]
===
match
---
operator: @ [1116,1117]
operator: @ [1116,1117]
===
match
---
simple_stmt [2794,2837]
simple_stmt [2800,2843]
===
match
---
dotted_name [11247,11257]
dotted_name [11259,11269]
===
match
---
param [11543,11548]
param [11555,11560]
===
match
---
name: patch [19426,19431]
name: patch [19438,19443]
===
match
---
argument [21407,21434]
argument [21419,21446]
===
match
---
name: self [14166,14170]
name: self [14178,14182]
===
match
---
operator: = [42997,42998]
operator: = [43009,43010]
===
match
---
funcdef [20271,20860]
funcdef [20283,20872]
===
match
---
name: test_github_missing_token [14140,14165]
name: test_github_missing_token [14152,14177]
===
match
---
operator: = [9463,9464]
operator: = [9475,9476]
===
match
---
param [11549,11559]
param [11561,11571]
===
match
---
name: auth [13104,13108]
name: auth [13116,13120]
===
match
---
operator: , [5130,5131]
operator: , [5142,5143]
===
match
---
atom_expr [28457,28685]
atom_expr [28469,28697]
===
match
---
name: MagicMock [14609,14618]
name: MagicMock [14621,14630]
===
match
---
number: 8110 [22026,22030]
number: 8110 [22038,22042]
===
match
---
name: url [12941,12944]
name: url [12953,12956]
===
match
---
simple_stmt [27787,27843]
simple_stmt [27799,27855]
===
match
---
simple_stmt [2356,2400]
simple_stmt [2356,2400]
===
match
---
suite [2308,2837]
suite [2308,2843]
===
match
---
simple_stmt [30407,30438]
simple_stmt [30419,30450]
===
match
---
simple_stmt [28262,28306]
simple_stmt [28274,28318]
===
match
---
name: _VaultClient [28457,28469]
name: _VaultClient [28469,28481]
===
match
---
param [32852,32857]
param [32864,32869]
===
match
---
operator: , [37593,37594]
operator: , [37605,37606]
===
match
---
operator: = [13741,13742]
operator: = [13753,13754]
===
match
---
name: mock_hvac [3792,3801]
name: mock_hvac [3804,3813]
===
match
---
name: assert_called_once_with [33772,33795]
name: assert_called_once_with [33784,33807]
===
match
---
atom_expr [24668,24732]
atom_expr [24680,24744]
===
match
---
operator: , [37870,37871]
operator: , [37882,37883]
===
match
---
argument [17868,17895]
argument [17880,17907]
===
match
---
trailer [2021,2028]
trailer [2021,2028]
===
match
---
operator: = [30476,30477]
operator: = [30488,30489]
===
match
---
operator: = [29042,29043]
operator: = [29054,29055]
===
match
---
operator: { [34706,34707]
operator: { [34718,34719]
===
match
---
operator: = [29099,29100]
operator: = [29111,29112]
===
match
---
string: 'missing' [28043,28052]
string: 'missing' [28055,28064]
===
match
---
name: assert_called_with [26249,26267]
name: assert_called_with [26261,26279]
===
match
---
name: patch [40416,40421]
name: patch [40428,40433]
===
match
---
trailer [16819,16848]
trailer [16831,16860]
===
match
---
name: client [11044,11050]
name: client [11056,11062]
===
match
---
name: return_value [16341,16353]
name: return_value [16353,16365]
===
match
---
trailer [2622,2651]
trailer [2622,2651]
===
match
---
operator: , [6964,6965]
operator: , [6976,6977]
===
match
---
decorator [34413,34491]
decorator [34425,34503]
===
match
---
operator: = [6287,6288]
operator: = [6299,6300]
===
match
---
name: client [2660,2666]
name: client [2660,2666]
===
match
---
suite [32869,33834]
suite [32881,33846]
===
match
---
atom_expr [12767,12783]
atom_expr [12779,12795]
===
match
---
argument [6940,6964]
argument [6952,6976]
===
match
---
name: Client [16794,16800]
name: Client [16806,16812]
===
match
---
param [14166,14171]
param [14178,14183]
===
match
---
argument [20465,20486]
argument [20477,20498]
===
match
---
operator: @ [8689,8690]
operator: @ [8701,8702]
===
match
---
trailer [3112,3293]
trailer [3118,3299]
===
match
---
param [25109,25118]
param [25121,25130]
===
match
---
operator: = [13146,13147]
operator: = [13158,13159]
===
match
---
atom_expr [16647,16674]
atom_expr [16659,16686]
===
match
---
funcdef [25738,26427]
funcdef [25750,26439]
===
match
---
name: kv [27056,27058]
name: kv [27068,27070]
===
match
---
string: "radhost" [22288,22297]
string: "radhost" [22300,22309]
===
match
---
suite [1610,1834]
suite [1610,1834]
===
match
---
expr_stmt [16702,16730]
expr_stmt [16714,16742]
===
match
---
operator: , [4585,4586]
operator: , [4597,4598]
===
match
---
name: mock_hvac [17180,17189]
name: mock_hvac [17192,17201]
===
match
---
trailer [42409,42412]
trailer [42421,42424]
===
match
---
operator: = [14659,14660]
operator: = [14671,14672]
===
match
---
string: "radhost" [21510,21519]
string: "radhost" [21522,21531]
===
match
---
expr_stmt [16324,16367]
expr_stmt [16336,16379]
===
match
---
trailer [36328,36388]
trailer [36340,36400]
===
match
---
name: is_authenticated [24748,24764]
name: is_authenticated [24760,24776]
===
match
---
trailer [34355,34366]
trailer [34367,34378]
===
match
---
name: mock [8863,8867]
name: mock [8875,8879]
===
match
---
name: self [10138,10142]
name: self [10150,10154]
===
match
---
atom_expr [23729,23762]
atom_expr [23741,23774]
===
match
---
name: vault_client [13250,13262]
name: vault_client [13262,13274]
===
match
---
operator: , [31611,31612]
operator: , [31623,31624]
===
match
---
string: "radius" [42096,42104]
string: "radius" [42108,42116]
===
match
---
operator: , [20153,20154]
operator: , [20165,20166]
===
match
---
operator: , [12939,12940]
operator: , [12951,12952]
===
match
---
trailer [32926,32933]
trailer [32938,32945]
===
match
---
trailer [12361,12368]
trailer [12373,12380]
===
match
---
arglist [9673,9699]
arglist [9685,9711]
===
match
---
operator: , [41410,41411]
operator: , [41422,41423]
===
match
---
name: mock_hvac [16784,16793]
name: mock_hvac [16796,16805]
===
match
---
operator: = [42129,42130]
operator: = [42141,42142]
===
match
---
name: mock_hvac [1953,1962]
name: mock_hvac [1953,1962]
===
match
---
atom_expr [18549,18593]
atom_expr [18561,18605]
===
match
---
name: read_secret_version [27512,27531]
name: read_secret_version [27524,27543]
===
match
---
trailer [9285,9304]
trailer [9297,9316]
===
match
---
name: mock_hvac [21055,21064]
name: mock_hvac [21067,21076]
===
match
---
string: "kubernetes" [15557,15569]
string: "kubernetes" [15569,15581]
===
match
---
suite [17785,17998]
suite [17797,18010]
===
match
---
operator: , [26894,26895]
operator: , [26906,26907]
===
match
---
operator: , [42169,42170]
operator: , [42181,42182]
===
match
---
argument [41424,41440]
argument [41436,41452]
===
match
---
name: host [20714,20718]
name: host [20726,20730]
===
match
---
operator: , [37926,37927]
operator: , [37938,37939]
===
match
---
param [3727,3732]
param [3739,3744]
===
match
---
operator: , [3282,3283]
operator: , [3288,3289]
===
match
---
operator: = [27145,27146]
operator: = [27157,27158]
===
match
---
operator: , [7686,7687]
operator: , [7698,7699]
===
match
---
operator: = [19735,19736]
operator: = [19747,19748]
===
match
---
operator: , [38725,38726]
operator: , [38737,38738]
===
match
---
operator: , [18976,18977]
operator: , [18988,18989]
===
match
---
name: read_secret_version [30139,30158]
name: read_secret_version [30151,30170]
===
match
---
name: TestCase [866,874]
name: TestCase [866,874]
===
match
---
name: mock_client [32970,32981]
name: mock_client [32982,32993]
===
match
---
name: secrets [29134,29141]
name: secrets [29146,29153]
===
match
---
name: test_get_non_existing_key_v2 [26518,26546]
name: test_get_non_existing_key_v2 [26530,26558]
===
match
---
argument [40319,40339]
argument [40331,40351]
===
match
---
string: 'version' [30997,31006]
string: 'version' [31009,31018]
===
match
---
operator: = [4196,4197]
operator: = [4208,4209]
===
match
---
expr_stmt [21334,21362]
expr_stmt [21346,21374]
===
match
---
operator: = [17439,17440]
operator: = [17451,17452]
===
match
---
simple_stmt [19214,19311]
simple_stmt [19226,19323]
===
match
---
expr_stmt [17623,17653]
expr_stmt [17635,17665]
===
match
---
testlist_comp [11731,11749]
testlist_comp [11743,11761]
===
match
---
name: cas [43241,43244]
name: cas [43253,43256]
===
match
---
operator: = [6919,6920]
operator: = [6931,6932]
===
match
---
trailer [20609,20628]
trailer [20621,20640]
===
match
---
string: 'data' [29382,29388]
string: 'data' [29394,29400]
===
match
---
operator: = [17750,17751]
operator: = [17762,17763]
===
match
---
funcdef [17141,17465]
funcdef [17153,17477]
===
match
---
trailer [6167,6177]
trailer [6179,6189]
===
match
---
parameters [20286,20303]
parameters [20298,20315]
===
match
---
simple_stmt [34075,34267]
simple_stmt [34087,34279]
===
match
---
decorated [33839,34408]
decorated [33851,34420]
===
match
---
atom_expr [19319,19363]
atom_expr [19331,19375]
===
match
---
param [28203,28212]
param [28215,28224]
===
match
---
string: "radius" [43546,43554]
string: "radius" [43558,43566]
===
match
---
comparison [2801,2836]
comparison [2807,2842]
===
match
---
name: test_create_or_update_secret_v1 [41895,41926]
name: test_create_or_update_secret_v1 [41907,41938]
===
match
---
trailer [31839,31846]
trailer [31851,31858]
===
match
---
operator: = [34152,34153]
operator: = [34164,34165]
===
match
---
string: 'data' [32115,32121]
string: 'data' [32127,32133]
===
match
---
argument [44006,44019]
argument [44018,44031]
===
match
---
operator: = [21157,21158]
operator: = [21169,21170]
===
match
---
operator: = [38121,38122]
operator: = [38133,38134]
===
match
---
trailer [36896,36978]
trailer [36908,36990]
===
match
---
name: MagicMock [34003,34012]
name: MagicMock [34015,34024]
===
match
---
argument [6004,6020]
argument [6016,6032]
===
match
---
operator: , [26858,26859]
operator: , [26870,26871]
===
match
---
operator: = [15915,15916]
operator: = [15927,15928]
===
match
---
operator: , [8471,8472]
operator: , [8483,8484]
===
match
---
string: 'secret_value' [30079,30093]
string: 'secret_value' [30091,30105]
===
match
---
trailer [15470,15483]
trailer [15482,15495]
===
match
---
operator: { [33210,33211]
operator: { [33222,33223]
===
match
---
trailer [27359,27369]
trailer [27371,27381]
===
match
---
name: mock_hvac [2297,2306]
name: mock_hvac [2297,2306]
===
match
---
string: "radhost" [43580,43589]
string: "radhost" [43592,43601]
===
match
---
suite [3903,3997]
suite [3915,4009]
===
match
---
operator: @ [18003,18004]
operator: @ [18015,18016]
===
match
---
name: v2 [41656,41658]
name: v2 [41668,41670]
===
match
---
arglist [41572,41623]
arglist [41584,41635]
===
match
---
atom [9503,9523]
atom [9515,9535]
===
match
---
operator: , [29898,29899]
operator: , [29910,29911]
===
match
---
operator: @ [23505,23506]
operator: @ [23517,23518]
===
match
---
string: 'user' [5391,5397]
string: 'user' [5403,5409]
===
match
---
name: mock_client [8849,8860]
name: mock_client [8861,8872]
===
match
---
operator: } [41614,41615]
operator: } [41626,41627]
===
match
---
name: is_authenticated [16965,16981]
name: is_authenticated [16977,16993]
===
match
---
dotted_name [30263,30273]
dotted_name [30275,30285]
===
match
---
trailer [8283,8486]
trailer [8295,8498]
===
match
---
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [30588,30626]
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [30600,30638]
===
match
---
name: Client [39207,39213]
name: Client [39219,39225]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [19432,19496]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [19444,19508]
===
match
---
string: "airflow.providers.google.cloud.utils.credentials_provider.get_credentials_and_project_id" [8593,8683]
string: "airflow.providers.google.cloud.utils.credentials_provider.get_credentials_and_project_id" [8605,8695]
===
match
---
operator: = [10478,10479]
operator: = [10490,10491]
===
match
---
string: "credentials" [11101,11114]
string: "credentials" [11113,11126]
===
match
---
string: "approle" [2459,2468]
string: "approle" [2459,2468]
===
match
---
string: "azure" [5835,5842]
string: "azure" [5847,5854]
===
match
---
trailer [40154,40178]
trailer [40166,40190]
===
match
---
argument [6762,6789]
argument [6774,6801]
===
match
---
operator: , [43727,43728]
operator: , [43739,43740]
===
match
---
simple_stmt [26573,26604]
simple_stmt [26585,26616]
===
match
---
suite [26564,27180]
suite [26576,27192]
===
match
---
name: credentials [12483,12494]
name: credentials [12495,12506]
===
match
---
operator: , [29517,29518]
operator: , [29529,29530]
===
match
---
operator: = [30207,30208]
operator: = [30219,30220]
===
match
---
trailer [26139,26146]
trailer [26151,26158]
===
match
---
operator: = [39439,39440]
operator: = [39451,39452]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [30865,30894]
string: '2020-03-16T21:01:43.331126Z' [30877,30906]
===
match
---
trailer [25435,25464]
trailer [25447,25476]
===
match
---
name: client [21444,21450]
name: client [21456,21462]
===
match
---
argument [25300,25315]
argument [25312,25327]
===
match
---
trailer [7105,7111]
trailer [7117,7123]
===
match
---
name: vault_client [31151,31163]
name: vault_client [31163,31175]
===
match
---
name: mock_hvac [15454,15463]
name: mock_hvac [15466,15475]
===
match
---
argument [16572,16599]
argument [16584,16611]
===
match
---
trailer [27808,27819]
trailer [27820,27831]
===
match
---
name: v1 [32993,32995]
name: v1 [33005,33007]
===
match
---
atom_expr [5469,5513]
atom_expr [5481,5525]
===
match
---
name: client [24091,24097]
name: client [24103,24109]
===
match
---
atom_expr [3849,3902]
atom_expr [3861,3914]
===
match
---
name: kv [26738,26740]
name: kv [26750,26752]
===
match
---
name: get_secret_metadata [35530,35549]
name: get_secret_metadata [35542,35561]
===
match
---
trailer [42333,42378]
trailer [42345,42390]
===
match
---
name: mock_hvac [14570,14579]
name: mock_hvac [14582,14591]
===
match
---
name: secret_path [33659,33670]
name: secret_path [33671,33682]
===
match
---
decorated [39008,39682]
decorated [39020,39694]
===
match
---
operator: , [19919,19920]
operator: , [19931,19932]
===
match
---
expr_stmt [1710,1781]
expr_stmt [1710,1781]
===
match
---
arglist [18257,18336]
arglist [18269,18348]
===
match
---
simple_stmt [28368,28434]
simple_stmt [28380,28446]
===
match
---
name: test_get_non_existing_key_v1 [28168,28196]
name: test_get_non_existing_key_v1 [28180,28208]
===
match
---
param [7546,7555]
param [7558,7567]
===
match
---
simple_stmt [23672,23716]
simple_stmt [23684,23728]
===
match
---
string: "pass" [3477,3483]
string: "pass" [3489,3495]
===
match
---
operator: = [40042,40043]
operator: = [40054,40055]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [6461,6525]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [6473,6537]
===
match
---
simple_stmt [37295,37938]
simple_stmt [37307,37950]
===
match
---
operator: , [19288,19289]
operator: , [19300,19301]
===
match
---
trailer [25927,26109]
trailer [25939,26121]
===
match
---
operator: , [28566,28567]
operator: , [28578,28579]
===
match
---
operator: = [1374,1375]
operator: = [1374,1375]
===
match
---
string: "http://localhost:8180" [14779,14802]
string: "http://localhost:8180" [14791,14814]
===
match
---
simple_stmt [1710,1782]
simple_stmt [1710,1782]
===
match
---
name: mock [19803,19807]
name: mock [19815,19819]
===
match
---
trailer [42835,43051]
trailer [42847,43063]
===
match
---
name: url [31323,31326]
name: url [31335,31338]
===
match
---
simple_stmt [17239,17283]
simple_stmt [17251,17295]
===
match
---
simple_stmt [20099,20184]
simple_stmt [20111,20196]
===
match
---
operator: = [16575,16576]
operator: = [16587,16588]
===
match
---
string: "userpass" [1748,1758]
string: "userpass" [1748,1758]
===
match
---
name: get_secret [32523,32533]
name: get_secret [32535,32545]
===
match
---
trailer [5264,5271]
trailer [5276,5283]
===
match
---
string: 'scope2' [8982,8990]
string: 'scope2' [8994,9002]
===
match
---
param [33964,33973]
param [33976,33985]
===
match
---
argument [24594,24621]
argument [24606,24633]
===
match
---
name: secret_path [41572,41583]
name: secret_path [41584,41595]
===
match
---
name: mock [37054,37058]
name: mock [37066,37070]
===
match
---
string: 'world' [33707,33714]
string: 'world' [33719,33726]
===
match
---
trailer [20331,20341]
trailer [20343,20353]
===
match
---
assert_stmt [24903,24945]
assert_stmt [24915,24957]
===
match
---
operator: = [22795,22796]
operator: = [22807,22808]
===
match
---
funcdef [5652,6444]
funcdef [5664,6456]
===
match
---
name: mock_client [42024,42035]
name: mock_client [42036,42047]
===
match
---
comparison [20824,20859]
comparison [20836,20871]
===
match
---
name: auth_mount_point [33541,33557]
name: auth_mount_point [33553,33569]
===
match
---
trailer [34032,34039]
trailer [34044,34051]
===
match
---
arglist [43536,43728]
arglist [43548,43740]
===
match
---
operator: = [5294,5295]
operator: = [5306,5307]
===
match
---
atom_expr [26228,26322]
atom_expr [26240,26334]
===
match
---
name: mock_hvac [6579,6588]
name: mock_hvac [6591,6600]
===
match
---
expr_stmt [2317,2347]
expr_stmt [2317,2347]
===
match
---
dotted_name [31655,31665]
dotted_name [31667,31677]
===
match
---
name: auth_type [9115,9124]
name: auth_type [9127,9136]
===
match
---
parameters [23606,23623]
parameters [23618,23635]
===
match
---
operator: = [31302,31303]
operator: = [31314,31315]
===
match
---
name: _VaultClient [21921,21933]
name: _VaultClient [21933,21945]
===
match
---
argument [1760,1780]
argument [1760,1780]
===
match
---
name: Client [25178,25184]
name: Client [25190,25196]
===
match
---
name: auth_type [34116,34125]
name: auth_type [34128,34137]
===
match
---
operator: @ [18650,18651]
operator: @ [18662,18663]
===
match
---
simple_stmt [27881,27925]
simple_stmt [27893,27937]
===
match
---
string: 'secret' [30208,30216]
string: 'secret' [30220,30228]
===
match
---
simple_stmt [27036,27180]
simple_stmt [27048,27192]
===
match
---
name: auth_kubernetes [15113,15128]
name: auth_kubernetes [15125,15140]
===
match
---
simple_stmt [30113,30257]
simple_stmt [30125,30269]
===
match
---
argument [28580,28600]
argument [28592,28612]
===
match
---
trailer [25247,25354]
trailer [25259,25366]
===
match
---
string: "other" [5191,5198]
string: "other" [5203,5210]
===
match
---
expr_stmt [18799,18829]
expr_stmt [18811,18841]
===
match
---
decorator [20189,20267]
decorator [20201,20279]
===
match
---
argument [22283,22297]
argument [22295,22309]
===
match
---
name: mock_client [16285,16296]
name: mock_client [16297,16308]
===
match
---
trailer [11860,12028]
trailer [11872,12040]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [43266,43330]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [43278,43342]
===
match
---
name: read_secret_version [31534,31553]
name: read_secret_version [31546,31565]
===
match
---
name: assert_called_with [14951,14969]
name: assert_called_with [14963,14981]
===
match
---
argument [9455,9475]
argument [9467,9487]
===
match
---
funcdef [19884,20184]
funcdef [19896,20196]
===
match
---
operator: , [7238,7239]
operator: , [7250,7251]
===
match
---
trailer [31920,31933]
trailer [31932,31945]
===
match
---
operator: , [41760,41761]
operator: , [41772,41773]
===
match
---
trailer [41971,41981]
trailer [41983,41993]
===
match
---
name: patch [2198,2203]
name: patch [2198,2203]
===
match
---
name: MagicMock [28242,28251]
name: MagicMock [28254,28263]
===
match
---
parameters [39804,39821]
parameters [39816,39833]
===
match
---
trailer [22339,22356]
trailer [22351,22368]
===
match
---
argument [43568,43589]
argument [43580,43601]
===
match
---
name: mock_open [14849,14858]
name: mock_open [14861,14870]
===
match
---
name: assert_called_once_with [27082,27105]
name: assert_called_once_with [27094,27117]
===
match
---
name: kv [30519,30521]
name: kv [30531,30533]
===
match
---
name: client [22333,22339]
name: client [22345,22351]
===
match
---
argument [39358,39374]
argument [39370,39386]
===
match
---
simple_stmt [4922,4966]
simple_stmt [4934,4978]
===
match
---
string: "project_id" [10406,10418]
string: "project_id" [10418,10430]
===
match
---
string: "radius" [41367,41375]
string: "radius" [41379,41387]
===
match
---
operator: = [15667,15668]
operator: = [15679,15680]
===
match
---
name: mock_hvac [19596,19605]
name: mock_hvac [19608,19617]
===
match
---
string: "pass" [25309,25315]
string: "pass" [25321,25327]
===
match
---
argument [4340,4356]
argument [4352,4368]
===
match
---
operator: , [34222,34223]
operator: , [34234,34235]
===
match
---
name: role_id [5048,5055]
name: role_id [5060,5067]
===
match
---
param [14564,14569]
param [14576,14581]
===
match
---
name: assert_called_with [3356,3374]
name: assert_called_with [3362,3380]
===
match
---
operator: , [10923,10924]
operator: , [10935,10936]
===
match
---
operator: = [3458,3459]
operator: = [3470,3471]
===
match
---
operator: , [15610,15611]
operator: , [15622,15623]
===
match
---
atom_expr [40232,40404]
atom_expr [40244,40416]
===
match
---
operator: , [29666,29667]
operator: , [29678,29679]
===
match
---
atom_expr [29122,29180]
atom_expr [29134,29192]
===
match
---
simple_stmt [6040,6069]
simple_stmt [6052,6081]
===
match
---
string: "radhost" [27653,27662]
string: "radhost" [27665,27674]
===
match
---
operator: = [9684,9685]
operator: = [9696,9697]
===
match
---
name: radius_host [27641,27652]
name: radius_host [27653,27664]
===
match
---
operator: = [3765,3766]
operator: = [3777,3778]
===
match
---
dictorsetmaker [30768,30796]
dictorsetmaker [30780,30808]
===
match
---
operator: = [13893,13894]
operator: = [13905,13906]
===
match
---
name: mock_hvac [12074,12083]
name: mock_hvac [12086,12095]
===
match
---
name: auth_type [25941,25950]
name: auth_type [25953,25962]
===
match
---
trailer [10221,10231]
trailer [10233,10243]
===
match
---
simple_stmt [19104,19133]
simple_stmt [19116,19145]
===
match
---
trailer [1637,1647]
trailer [1637,1647]
===
match
---
operator: == [32591,32593]
operator: == [32603,32605]
===
match
---
atom_expr [24478,24507]
atom_expr [24490,24519]
===
match
---
trailer [19176,19205]
trailer [19188,19217]
===
match
---
name: github [13109,13115]
name: github [13121,13127]
===
match
---
argument [29815,29833]
argument [29827,29845]
===
match
---
operator: , [40339,40340]
operator: , [40351,40352]
===
match
---
name: secret [22299,22305]
name: secret [22311,22317]
===
match
---
name: mock [18004,18008]
name: mock [18016,18020]
===
match
---
arglist [18507,18539]
arglist [18519,18551]
===
match
---
funcdef [41891,42563]
funcdef [41903,42575]
===
match
---
operator: } [32238,32239]
operator: } [32250,32251]
===
match
---
trailer [17228,17230]
trailer [17240,17242]
===
match
---
string: "radius" [20122,20130]
string: "radius" [20134,20142]
===
match
---
argument [6308,6328]
argument [6320,6340]
===
match
---
trailer [28379,28387]
trailer [28391,28399]
===
match
---
operator: = [15995,15996]
operator: = [16007,16008]
===
match
---
operator: = [7231,7232]
operator: = [7243,7244]
===
match
---
operator: = [20476,20477]
operator: = [20488,20489]
===
match
---
assert_stmt [3567,3609]
assert_stmt [3579,3621]
===
match
---
param [15395,15404]
param [15407,15416]
===
match
---
trailer [31905,31908]
trailer [31917,31920]
===
match
---
string: '' [30652,30654]
string: '' [30664,30666]
===
match
---
string: 'data' [30759,30765]
string: 'data' [30771,30777]
===
match
---
name: Client [24028,24034]
name: Client [24040,24046]
===
match
---
name: assert_called_with [4429,4447]
name: assert_called_with [4441,4459]
===
match
---
operator: @ [25656,25657]
operator: @ [25668,25669]
===
match
---
name: _VaultClient [25235,25247]
name: _VaultClient [25247,25259]
===
match
---
dictorsetmaker [31460,31488]
dictorsetmaker [31472,31500]
===
match
---
operator: = [36639,36640]
operator: = [36651,36652]
===
match
---
name: _VaultClient [3100,3112]
name: _VaultClient [3106,3118]
===
match
---
operator: , [30626,30627]
operator: , [30638,30639]
===
match
---
name: gcp_key_path [10498,10510]
name: gcp_key_path [10510,10522]
===
match
---
param [5673,5682]
param [5685,5694]
===
match
---
string: "radius" [21158,21166]
string: "radius" [21170,21178]
===
match
---
param [4857,4862]
param [4869,4874]
===
match
---
operator: , [32440,32441]
operator: , [32452,32453]
===
match
---
operator: = [40772,40773]
operator: = [40784,40785]
===
match
---
operator: = [43987,43988]
operator: = [43999,44000]
===
match
---
name: azure [6162,6167]
name: azure [6174,6179]
===
match
---
name: mock_get_scopes [8823,8838]
name: mock_get_scopes [8835,8850]
===
match
---
name: mock_client [39158,39169]
name: mock_client [39170,39181]
===
match
---
atom_expr [7325,7369]
atom_expr [7337,7381]
===
match
---
trailer [43071,43078]
trailer [43083,43090]
===
match
---
name: MagicMock [31810,31819]
name: MagicMock [31822,31831]
===
match
---
simple_stmt [8888,8932]
simple_stmt [8900,8944]
===
match
---
string: 'renewable' [34814,34825]
string: 'renewable' [34826,34837]
===
match
---
param [14172,14181]
param [14184,14193]
===
match
---
name: self [36508,36512]
name: self [36520,36524]
===
match
---
atom_expr [7736,7953]
atom_expr [7748,7965]
===
match
---
trailer [2028,2041]
trailer [2028,2041]
===
match
---
dotted_name [8690,8700]
dotted_name [8702,8712]
===
match
---
name: assert_called_with [13209,13227]
name: assert_called_with [13221,13239]
===
match
---
string: "http://localhost:8180" [24598,24621]
string: "http://localhost:8180" [24610,24633]
===
match
---
decorator [17470,17548]
decorator [17482,17560]
===
match
---
expr_stmt [19104,19132]
expr_stmt [19116,19144]
===
match
---
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [37384,37422]
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [37396,37434]
===
match
---
atom_expr [24915,24945]
atom_expr [24927,24957]
===
match
---
atom_expr [26127,26146]
atom_expr [26139,26158]
===
match
---
atom_expr [16739,16775]
atom_expr [16751,16787]
===
match
---
name: patch [2848,2853]
name: patch [2854,2859]
===
match
---
argument [8222,8256]
argument [8234,8268]
===
match
---
trailer [20577,20584]
trailer [20589,20596]
===
match
---
name: v2 [29145,29147]
name: v2 [29157,29159]
===
match
---
atom_expr [25168,25197]
atom_expr [25180,25209]
===
match
---
trailer [18555,18572]
trailer [18567,18584]
===
match
---
simple_stmt [4683,4726]
simple_stmt [4695,4738]
===
match
---
name: Client [10981,10987]
name: Client [10993,10999]
===
match
---
string: "role" [2707,2713]
string: "role" [2713,2719]
===
match
---
name: assert_called_with [25494,25512]
name: assert_called_with [25506,25524]
===
match
---
parameters [18772,18789]
parameters [18784,18801]
===
match
---
trailer [27531,27543]
trailer [27543,27555]
===
match
---
trailer [16333,16340]
trailer [16345,16352]
===
match
---
name: access_key [5380,5390]
name: access_key [5392,5402]
===
match
---
testlist_comp [35791,36212]
testlist_comp [35803,36224]
===
match
---
operator: = [22305,22306]
operator: = [22317,22318]
===
match
---
name: return_value [30463,30475]
name: return_value [30475,30487]
===
match
---
operator: , [23611,23612]
operator: , [23623,23624]
===
match
---
dotted_name [22435,22445]
dotted_name [22447,22457]
===
match
---
name: path [27141,27145]
name: path [27153,27157]
===
match
---
atom_expr [28368,28417]
atom_expr [28380,28429]
===
match
---
operator: , [32481,32482]
operator: , [32493,32494]
===
match
---
argument [5015,5034]
argument [5027,5046]
===
match
---
decorator [7959,8037]
decorator [7971,8049]
===
match
---
number: 2 [19379,19380]
number: 2 [19391,19392]
===
match
---
decorated [25003,25651]
decorated [25015,25663]
===
match
---
name: mock_client [40561,40572]
name: mock_client [40573,40584]
===
match
---
arglist [23081,23163]
arglist [23093,23175]
===
match
---
arglist [19667,19698]
arglist [19679,19710]
===
match
---
name: mock_hvac [42696,42705]
name: mock_hvac [42708,42717]
===
match
---
name: Client [42765,42771]
name: Client [42777,42783]
===
match
---
atom_expr [2080,2135]
atom_expr [2080,2135]
===
match
---
funcdef [8041,8487]
funcdef [8053,8499]
===
match
---
name: resource [6245,6253]
name: resource [6257,6265]
===
match
---
suite [13428,14049]
suite [13440,14061]
===
match
---
name: kv [30133,30135]
name: kv [30145,30147]
===
match
---
string: "radhost" [33421,33430]
string: "radhost" [33433,33442]
===
match
---
operator: = [13810,13811]
operator: = [13822,13823]
===
match
---
operator: = [15519,15520]
operator: = [15531,15532]
===
match
---
name: mock_client [28294,28305]
name: mock_client [28306,28317]
===
match
---
name: role [15991,15995]
name: role [16003,16007]
===
match
---
decorator [37053,37131]
decorator [37065,37143]
===
match
---
operator: = [28631,28632]
operator: = [28643,28644]
===
match
---
trailer [31402,31443]
trailer [31414,31455]
===
match
---
atom_expr [24091,24135]
atom_expr [24103,24147]
===
match
---
name: secrets [30511,30518]
name: secrets [30523,30530]
===
match
---
argument [26071,26098]
argument [26083,26110]
===
match
---
operator: = [19264,19265]
operator: = [19276,19277]
===
match
---
argument [31591,31611]
argument [31603,31623]
===
match
---
trailer [4155,4157]
trailer [4167,4169]
===
match
---
name: MagicMock [14211,14220]
name: MagicMock [14223,14232]
===
match
---
operator: = [37036,37037]
operator: = [37048,37049]
===
match
---
atom_expr [18838,18867]
atom_expr [18850,18879]
===
match
---
decorated [6449,7421]
decorated [6461,7433]
===
match
---
name: mock [42569,42573]
name: mock [42581,42585]
===
match
---
operator: = [20513,20514]
operator: = [20525,20526]
===
match
---
operator: = [43810,43811]
operator: = [43822,43823]
===
match
---
argument [7766,7783]
argument [7778,7795]
===
match
---
argument [6803,6828]
argument [6815,6840]
===
match
---
trailer [38904,38928]
trailer [38916,38940]
===
match
---
name: VaultError [34294,34304]
name: VaultError [34306,34316]
===
match
---
name: self [1221,1225]
name: self [1221,1225]
===
match
---
string: "http://localhost:8180" [19772,19795]
string: "http://localhost:8180" [19784,19807]
===
match
---
operator: , [29558,29559]
operator: , [29570,29571]
===
match
---
name: vault_client [18614,18626]
name: vault_client [18626,18638]
===
match
---
expr_stmt [26942,26997]
expr_stmt [26954,27009]
===
match
---
name: vault_client [12593,12605]
name: vault_client [12605,12617]
===
match
---
simple_stmt [34592,34636]
simple_stmt [34604,34648]
===
match
---
expr_stmt [3033,3076]
expr_stmt [3039,3082]
===
match
---
atom_expr [43442,43471]
atom_expr [43454,43483]
===
match
---
decorator [10016,10094]
decorator [10028,10106]
===
match
---
name: Client [11657,11663]
name: Client [11669,11675]
===
match
---
name: mock_hvac [19921,19930]
name: mock_hvac [19933,19942]
===
match
---
decorated [17059,17465]
decorated [17071,17477]
===
match
---
expr_stmt [5732,5775]
expr_stmt [5744,5787]
===
match
---
param [6573,6578]
param [6585,6590]
===
match
---
name: Client [26165,26171]
name: Client [26177,26183]
===
match
---
name: read_secret_version [26744,26763]
name: read_secret_version [26756,26775]
===
match
---
simple_stmt [23040,23174]
simple_stmt [23052,23186]
===
match
---
string: "kubernetes" [14732,14744]
string: "kubernetes" [14744,14756]
===
match
---
atom_expr [8139,8168]
atom_expr [8151,8180]
===
match
---
dotted_name [938,953]
dotted_name [938,953]
===
match
---
string: "missing" [34379,34388]
string: "missing" [34391,34400]
===
match
---
name: path [31613,31617]
name: path [31625,31629]
===
match
---
name: assert_called_with [15841,15859]
name: assert_called_with [15853,15871]
===
match
---
string: 'missing' [36369,36378]
string: 'missing' [36381,36390]
===
match
---
operator: = [40190,40191]
operator: = [40202,40203]
===
match
---
trailer [4653,4672]
trailer [4665,4684]
===
match
---
trailer [22410,22428]
trailer [22422,22440]
===
match
---
atom [41769,41785]
atom [41781,41797]
===
match
---
operator: , [14568,14569]
operator: , [14580,14581]
===
match
---
argument [32454,32481]
argument [32466,32493]
===
match
---
operator: = [14204,14205]
operator: = [14216,14217]
===
match
---
name: mock_client [32609,32620]
name: mock_client [32621,32632]
===
match
---
dictorsetmaker [37555,37825]
dictorsetmaker [37567,37837]
===
match
---
expr_stmt [16285,16315]
expr_stmt [16297,16327]
===
match
---
operator: , [7938,7939]
operator: , [7950,7951]
===
match
---
name: _VaultClient [9089,9101]
name: _VaultClient [9101,9113]
===
match
---
string: "scope1,scope2" [9377,9392]
string: "scope1,scope2" [9389,9404]
===
match
---
name: _VaultClient [32264,32276]
name: _VaultClient [32276,32288]
===
match
---
name: vault_client [22398,22410]
name: vault_client [22410,22422]
===
match
---
trailer [34286,34293]
trailer [34298,34305]
===
match
---
parameters [17596,17613]
parameters [17608,17625]
===
match
---
trailer [21870,21883]
trailer [21882,21895]
===
match
---
name: MagicMock [27360,27369]
name: MagicMock [27372,27381]
===
match
---
operator: = [34622,34623]
operator: = [34634,34635]
===
match
---
argument [23935,23962]
argument [23947,23974]
===
match
---
trailer [1435,1477]
trailer [1435,1477]
===
match
---
name: VaultError [17310,17320]
name: VaultError [17322,17332]
===
match
---
name: method [42541,42547]
name: method [42553,42559]
===
match
---
operator: = [28876,28877]
operator: = [28888,28889]
===
match
---
argument [42916,42932]
argument [42928,42944]
===
match
---
operator: , [10404,10405]
operator: , [10416,10417]
===
match
---
operator: = [36368,36369]
operator: = [36380,36381]
===
match
---
name: mock_hvac [32917,32926]
name: mock_hvac [32929,32938]
===
match
---
name: assert_called_with [13122,13140]
name: assert_called_with [13134,13152]
===
match
---
operator: , [29342,29343]
operator: , [29354,29355]
===
match
---
operator: = [41400,41401]
operator: = [41412,41413]
===
match
---
argument [39659,39680]
argument [39671,39692]
===
match
---
string: 'lease_id' [32016,32026]
string: 'lease_id' [32028,32038]
===
match
---
argument [39323,39344]
argument [39335,39356]
===
match
---
argument [1457,1476]
argument [1457,1476]
===
match
---
simple_stmt [22125,22154]
simple_stmt [22137,22166]
===
match
---
argument [27141,27155]
argument [27153,27167]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [2204,2268]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [2204,2268]
===
match
---
trailer [4504,4523]
trailer [4516,4535]
===
match
---
name: vault_client [24530,24542]
name: vault_client [24542,24554]
===
match
---
string: "radhost" [40008,40017]
string: "radhost" [40020,40029]
===
match
---
expr_stmt [11699,11750]
expr_stmt [11711,11762]
===
match
---
trailer [10987,11006]
trailer [10999,11018]
===
match
---
name: Client [9552,9558]
name: Client [9564,9570]
===
match
---
name: auth_type [14395,14404]
name: auth_type [14407,14416]
===
match
---
name: secret_key [4568,4578]
name: secret_key [4580,4590]
===
match
---
string: "path" [15644,15650]
string: "path" [15656,15662]
===
match
---
operator: , [10175,10176]
operator: , [10187,10188]
===
match
---
name: url [10576,10579]
name: url [10588,10591]
===
match
---
decorator [19420,19498]
decorator [19432,19510]
===
match
---
name: assert_called_with [5348,5366]
name: assert_called_with [5360,5378]
===
match
---
atom [41599,41615]
atom [41611,41627]
===
match
---
string: 'http://localhost:8180' [24058,24081]
string: 'http://localhost:8180' [24070,24093]
===
match
---
operator: = [18229,18230]
operator: = [18241,18242]
===
match
---
operator: , [38383,38384]
operator: , [38395,38396]
===
match
---
name: assert_called_with [10715,10733]
name: assert_called_with [10727,10745]
===
match
---
string: '' [37729,37731]
string: '' [37741,37743]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [2854,2918]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [2860,2924]
===
match
---
operator: = [37215,37216]
operator: = [37227,37228]
===
match
---
name: _VaultClient [20419,20431]
name: _VaultClient [20431,20443]
===
match
---
atom_expr [9718,9762]
atom_expr [9730,9774]
===
match
---
trailer [10805,10822]
trailer [10817,10834]
===
match
---
string: "radius" [32300,32308]
string: "radius" [32312,32320]
===
match
---
suite [30398,31649]
suite [30410,31661]
===
match
---
atom_expr [24872,24894]
atom_expr [24884,24906]
===
match
---
simple_stmt [2994,3025]
simple_stmt [3000,3031]
===
match
---
name: client [13097,13103]
name: client [13109,13115]
===
match
---
name: self [14564,14568]
name: self [14576,14580]
===
match
---
operator: = [14731,14732]
operator: = [14743,14744]
===
match
---
operator: = [14911,14912]
operator: = [14923,14924]
===
match
---
expr_stmt [32249,32492]
expr_stmt [32261,32504]
===
match
---
name: vault_client [24216,24228]
name: vault_client [24228,24240]
===
match
---
atom_expr [14826,14877]
atom_expr [14838,14889]
===
match
---
name: read_secret [33760,33771]
name: read_secret [33772,33783]
===
match
---
dictorsetmaker [41039,41053]
dictorsetmaker [41051,41065]
===
match
---
operator: , [41785,41786]
operator: , [41797,41798]
===
match
---
operator: , [14312,14313]
operator: , [14324,14325]
===
match
---
argument [41357,41375]
argument [41369,41387]
===
match
---
name: mock_client [34553,34564]
name: mock_client [34565,34576]
===
match
---
operator: == [14015,14017]
operator: == [14027,14029]
===
match
---
arglist [18931,19085]
arglist [18943,19097]
===
match
---
arglist [42334,42377]
arglist [42346,42389]
===
match
---
simple_stmt [12074,12139]
simple_stmt [12086,12151]
===
match
---
arglist [20051,20084]
arglist [20063,20096]
===
match
---
atom_expr [24640,24659]
atom_expr [24652,24671]
===
match
---
name: mock_hvac [24018,24027]
name: mock_hvac [24030,24039]
===
match
---
string: 'secret_key' [38465,38477]
string: 'secret_key' [38477,38489]
===
match
---
trailer [3781,3783]
trailer [3793,3795]
===
match
---
trailer [25493,25512]
trailer [25505,25524]
===
match
---
name: vault_client [23040,23052]
name: vault_client [23052,23064]
===
match
---
expr_stmt [21055,21098]
expr_stmt [21067,21110]
===
match
---
arglist [39964,40123]
arglist [39976,40135]
===
match
---
trailer [16748,16767]
trailer [16760,16779]
===
match
---
name: assert_called_with [18488,18506]
name: assert_called_with [18500,18518]
===
match
---
simple_stmt [18799,18830]
simple_stmt [18811,18842]
===
match
---
string: 'destroyed' [30957,30968]
string: 'destroyed' [30969,30980]
===
match
---
name: auth_type [19726,19735]
name: auth_type [19738,19747]
===
match
---
string: '' [29556,29558]
string: '' [29568,29570]
===
match
---
name: url [41488,41491]
name: url [41500,41503]
===
match
---
atom_expr [23055,23173]
atom_expr [23067,23185]
===
match
---
param [27321,27330]
param [27333,27342]
===
match
---
arglist [9455,9523]
arglist [9467,9535]
===
match
---
name: mock_hvac [26155,26164]
name: mock_hvac [26167,26176]
===
match
---
trailer [30158,30182]
trailer [30170,30194]
===
match
---
simple_stmt [13771,13836]
simple_stmt [13783,13848]
===
match
---
atom_expr [23475,23499]
atom_expr [23487,23511]
===
match
---
atom_expr [18614,18644]
atom_expr [18626,18656]
===
match
---
atom_expr [23672,23701]
atom_expr [23684,23713]
===
match
---
atom_expr [13543,13725]
atom_expr [13555,13737]
===
match
---
atom_expr [8271,8486]
atom_expr [8283,8498]
===
match
---
name: vault_client [23475,23487]
name: vault_client [23487,23499]
===
match
---
arglist [5380,5450]
arglist [5392,5462]
===
match
---
trailer [15892,15911]
trailer [15904,15923]
===
match
---
param [19537,19546]
param [19549,19558]
===
match
---
operator: = [19111,19112]
operator: = [19123,19124]
===
match
---
atom_expr [24833,24845]
atom_expr [24845,24857]
===
match
---
arglist [16630,16674]
arglist [16642,16686]
===
match
---
name: patch [32720,32725]
name: patch [32732,32737]
===
match
---
name: assert_called_with [3432,3450]
name: assert_called_with [3444,3462]
===
match
---
comparison [23412,23447]
comparison [23424,23459]
===
match
---
string: '' [37448,37450]
string: '' [37460,37462]
===
match
---
decorated [43254,44030]
decorated [43266,44042]
===
match
---
argument [42516,42539]
argument [42528,42551]
===
match
---
name: get_secret [34356,34366]
name: get_secret [34368,34378]
===
match
---
name: secret_id [6910,6919]
name: secret_id [6922,6931]
===
match
---
name: v2 [38882,38884]
name: v2 [38894,38896]
===
match
---
operator: , [9698,9699]
operator: , [9710,9711]
===
match
---
name: assert_called_with [10787,10805]
name: assert_called_with [10799,10817]
===
match
---
string: 'data' [37555,37561]
string: 'data' [37567,37573]
===
match
---
operator: , [1597,1598]
operator: , [1597,1598]
===
match
---
dictorsetmaker [33698,33714]
dictorsetmaker [33710,33726]
===
match
---
name: MagicMock [22968,22977]
name: MagicMock [22980,22989]
===
match
---
parameters [4856,4873]
parameters [4868,4885]
===
match
---
string: 'request_id' [35602,35614]
string: 'request_id' [35614,35626]
===
match
---
operator: } [37838,37839]
operator: } [37850,37851]
===
match
---
expr_stmt [28223,28253]
expr_stmt [28235,28265]
===
match
---
name: self [37177,37181]
name: self [37189,37193]
===
match
---
operator: = [25291,25292]
operator: = [25303,25304]
===
match
---
name: token [23100,23105]
name: token [23112,23117]
===
match
---
atom [12313,12333]
atom [12325,12345]
===
match
---
string: "http://localhost:8180" [3191,3214]
string: "http://localhost:8180" [3197,3220]
===
match
---
operator: , [17320,17321]
operator: , [17332,17333]
===
match
---
trailer [34366,34407]
trailer [34378,34419]
===
match
---
expr_stmt [18164,18207]
expr_stmt [18176,18219]
===
match
---
argument [31426,31442]
argument [31438,31454]
===
match
---
name: return_value [14646,14658]
name: return_value [14658,14670]
===
match
---
operator: = [18998,18999]
operator: = [19010,19011]
===
match
---
operator: = [32947,32948]
operator: = [32959,32960]
===
match
---
name: radius_port [38054,38065]
name: radius_port [38066,38077]
===
match
---
name: auth_type [25261,25270]
name: auth_type [25273,25282]
===
match
---
atom_expr [43417,43433]
atom_expr [43429,43445]
===
match
---
simple_stmt [25848,25892]
simple_stmt [25860,25904]
===
match
---
string: 'key' [41600,41605]
string: 'key' [41612,41617]
===
match
---
atom_expr [19713,19796]
atom_expr [19725,19808]
===
match
---
atom_expr [14231,14260]
atom_expr [14243,14272]
===
match
---
trailer [7030,7037]
trailer [7042,7049]
===
match
---
operator: , [27319,27320]
operator: , [27331,27332]
===
match
---
name: mock_client [36605,36616]
name: mock_client [36617,36628]
===
match
---
name: url [12388,12391]
name: url [12400,12403]
===
match
---
string: 'http://localhost:8180' [25440,25463]
string: 'http://localhost:8180' [25452,25475]
===
match
---
operator: == [25617,25619]
operator: == [25629,25631]
===
match
---
string: "credentials" [11796,11809]
string: "credentials" [11808,11821]
===
match
---
name: mock_client [36534,36545]
name: mock_client [36546,36557]
===
match
---
name: patch [17476,17481]
name: patch [17488,17493]
===
match
---
operator: { [37537,37538]
operator: { [37549,37550]
===
match
---
dotted_name [7960,7970]
dotted_name [7972,7982]
===
match
---
atom_expr [12996,13015]
atom_expr [13008,13027]
===
match
---
argument [19290,19309]
argument [19302,19321]
===
match
---
name: vault_client [1710,1722]
name: vault_client [1710,1722]
===
match
---
operator: = [19180,19181]
operator: = [19192,19193]
===
match
---
dotted_name [41810,41820]
dotted_name [41822,41832]
===
match
---
param [31765,31770]
param [31777,31782]
===
match
---
assert_stmt [30057,30104]
assert_stmt [30069,30116]
===
match
---
argument [25436,25463]
argument [25448,25475]
===
match
---
argument [39455,39482]
argument [39467,39494]
===
match
---
string: "github" [13579,13587]
string: "github" [13591,13599]
===
match
---
argument [43241,43247]
argument [43253,43259]
===
match
---
operator: = [23189,23190]
operator: = [23201,23202]
===
match
---
string: 'secret' [36354,36362]
string: 'secret' [36366,36374]
===
match
---
name: url [5936,5939]
name: url [5948,5951]
===
match
---
name: mock_hvac [29069,29078]
name: mock_hvac [29081,29090]
===
match
---
name: client [12425,12431]
name: client [12437,12443]
===
match
---
simple_stmt [17200,17231]
simple_stmt [17212,17243]
===
match
---
name: mock_client [6599,6610]
name: mock_client [6611,6622]
===
match
---
string: 'value' [43819,43826]
string: 'value' [43831,43838]
===
match
---
trailer [36280,36283]
trailer [36292,36295]
===
match
---
string: "radius" [27619,27627]
string: "radius" [27631,27639]
===
match
---
name: secret [43981,43987]
name: secret [43993,43999]
===
match
---
number: 2 [2801,2802]
number: 2 [2807,2808]
===
match
---
funcdef [23587,24299]
funcdef [23599,24311]
===
match
---
atom_expr [10698,10762]
atom_expr [10710,10774]
===
match
---
trailer [7675,7722]
trailer [7687,7734]
===
match
---
string: 'other' [5443,5450]
string: 'other' [5455,5462]
===
match
---
expr_stmt [19557,19587]
expr_stmt [19569,19599]
===
match
---
name: secrets [43864,43871]
name: secrets [43876,43883]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [22446,22510]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [22458,22522]
===
match
---
name: mock_client [24439,24450]
name: mock_client [24451,24462]
===
match
---
name: auth_type [16417,16426]
name: auth_type [16429,16438]
===
match
---
simple_stmt [3033,3077]
simple_stmt [3039,3083]
===
match
---
string: "path" [43208,43214]
string: "path" [43220,43226]
===
match
---
trailer [27105,27179]
trailer [27117,27191]
===
match
---
argument [30218,30232]
argument [30230,30244]
===
match
---
trailer [10455,10652]
trailer [10467,10664]
===
match
---
operator: = [4268,4269]
operator: = [4280,4281]
===
match
---
trailer [4428,4447]
trailer [4440,4459]
===
match
---
string: 'created_time' [36032,36046]
string: 'created_time' [36044,36058]
===
match
---
operator: = [17635,17636]
operator: = [17647,17648]
===
match
---
argument [5380,5397]
argument [5392,5409]
===
match
---
name: mock [28894,28898]
name: mock [28906,28910]
===
match
---
name: return_value [41280,41292]
name: return_value [41292,41304]
===
match
---
string: 'http://localhost:8180' [12114,12137]
string: 'http://localhost:8180' [12126,12149]
===
match
---
atom [38524,38725]
atom [38536,38737]
===
match
---
name: patch [9914,9919]
name: patch [9926,9931]
===
match
---
simple_stmt [8849,8880]
simple_stmt [8861,8892]
===
match
---
comparison [5529,5564]
comparison [5541,5576]
===
match
---
string: 'secret' [41732,41740]
string: 'secret' [41744,41752]
===
match
---
string: 'value' [41777,41784]
string: 'value' [41789,41796]
===
match
---
operator: , [10334,10335]
operator: , [10346,10347]
===
match
---
name: self [39132,39136]
name: self [39144,39148]
===
match
---
atom_expr [36641,36869]
atom_expr [36653,36881]
===
match
---
name: mock_client [1619,1630]
name: mock_client [1619,1630]
===
match
---
expr_stmt [18890,19095]
expr_stmt [18902,19107]
===
match
---
operator: = [9124,9125]
operator: = [9136,9137]
===
match
---
string: "http://localhost:8180" [18313,18336]
string: "http://localhost:8180" [18325,18348]
===
match
---
parameters [26546,26563]
parameters [26558,26575]
===
match
---
expr_stmt [20404,20547]
expr_stmt [20416,20559]
===
match
---
operator: = [21827,21828]
operator: = [21839,21840]
===
match
---
atom_expr [21854,21883]
atom_expr [21866,21895]
===
match
---
trailer [13262,13280]
trailer [13274,13292]
===
match
---
trailer [24228,24246]
trailer [24240,24258]
===
match
---
trailer [24764,24783]
trailer [24776,24795]
===
match
---
name: test_azure_different_auth_mount_point [6535,6572]
name: test_azure_different_auth_mount_point [6547,6584]
===
match
---
operator: , [35310,35311]
operator: , [35322,35323]
===
match
---
name: assert_called_with [12163,12181]
name: assert_called_with [12175,12193]
===
match
---
simple_stmt [14382,14444]
simple_stmt [14394,14456]
===
match
---
string: "kube_role" [14762,14773]
string: "kube_role" [14774,14785]
===
match
---
operator: , [16439,16440]
operator: , [16451,16452]
===
match
---
name: mock_hvac [25400,25409]
name: mock_hvac [25412,25421]
===
match
---
simple_stmt [11759,11825]
simple_stmt [11771,11837]
===
match
---
operator: } [44003,44004]
operator: } [44015,44016]
===
match
---
suite [15406,16125]
suite [15418,16137]
===
match
---
atom_expr [10831,10962]
atom_expr [10843,10974]
===
match
---
decorated [5570,6444]
decorated [5582,6456]
===
match
---
operator: , [42966,42967]
operator: , [42978,42979]
===
match
---
operator: @ [6449,6450]
operator: @ [6461,6462]
===
match
---
name: client [20578,20584]
name: client [20590,20596]
===
match
---
trailer [32276,32492]
trailer [32288,32504]
===
match
---
name: self [20287,20291]
name: self [20299,20303]
===
match
---
simple_stmt [14192,14223]
simple_stmt [14204,14235]
===
match
---
name: auth_type [26841,26850]
name: auth_type [26853,26862]
===
match
---
arglist [43939,44019]
arglist [43951,44031]
===
match
---
name: client [23292,23298]
name: client [23304,23310]
===
match
---
assert_stmt [13238,13280]
assert_stmt [13250,13292]
===
match
---
number: 2 [9778,9779]
number: 2 [9790,9791]
===
match
---
name: assert_called_with [24765,24783]
name: assert_called_with [24777,24795]
===
match
---
simple_stmt [6599,6630]
simple_stmt [6611,6642]
===
match
---
name: patch [36400,36405]
name: patch [36412,36417]
===
match
---
trailer [18376,18383]
trailer [18388,18395]
===
match
---
name: secrets [30125,30132]
name: secrets [30137,30144]
===
match
---
atom_expr [2331,2347]
atom_expr [2331,2347]
===
match
---
name: mock_hvac [27321,27330]
name: mock_hvac [27333,27342]
===
match
---
atom_expr [10294,10322]
atom_expr [10306,10334]
===
match
---
trailer [27497,27505]
trailer [27509,27517]
===
match
---
suite [4118,4726]
suite [4130,4738]
===
match
---
operator: , [41202,41203]
operator: , [41214,41215]
===
match
---
name: mock_hvac [23613,23622]
name: mock_hvac [23625,23634]
===
match
---
expr_stmt [21906,22116]
expr_stmt [21918,22128]
===
match
---
name: client [5240,5246]
name: client [5252,5258]
===
match
---
name: secret_path [42496,42507]
name: secret_path [42508,42519]
===
match
---
param [37183,37192]
param [37195,37204]
===
match
---
parameters [18098,18115]
parameters [18110,18127]
===
match
---
number: 10 [41791,41793]
number: 10 [41803,41805]
===
match
---
operator: , [36362,36363]
operator: , [36374,36375]
===
match
---
atom_expr [23788,23832]
atom_expr [23800,23844]
===
match
---
trailer [27511,27531]
trailer [27523,27543]
===
match
---
argument [17408,17434]
argument [17420,17446]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [25668,25732]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [25680,25744]
===
match
---
name: v2 [27509,27511]
name: v2 [27521,27523]
===
match
---
name: patch [41815,41820]
name: patch [41827,41832]
===
match
---
operator: = [40389,40390]
operator: = [40401,40402]
===
match
---
atom_expr [17662,17691]
atom_expr [17674,17703]
===
match
---
simple_stmt [14231,14275]
simple_stmt [14243,14287]
===
match
---
argument [33409,33430]
argument [33421,33442]
===
match
---
atom_expr [21343,21362]
atom_expr [21355,21374]
===
match
---
argument [12306,12333]
argument [12318,12345]
===
match
---
string: 'request_id' [38271,38283]
string: 'request_id' [38283,38295]
===
match
---
atom_expr [3100,3293]
atom_expr [3106,3299]
===
match
---
string: '' [35015,35017]
string: '' [35027,35029]
===
match
---
name: radius_host [21180,21191]
name: radius_host [21192,21203]
===
match
---
name: url [8379,8382]
name: url [8391,8394]
===
match
---
string: 'auth' [31118,31124]
string: 'auth' [31130,31136]
===
match
---
argument [23901,23933]
argument [23913,23945]
===
match
---
operator: , [39531,39532]
operator: , [39543,39544]
===
match
---
operator: = [26850,26851]
operator: = [26862,26863]
===
match
---
simple_stmt [21815,21846]
simple_stmt [21827,21858]
===
match
---
operator: = [41062,41063]
operator: = [41074,41075]
===
match
---
operator: } [41784,41785]
operator: } [41796,41797]
===
match
---
funcdef [39090,39682]
funcdef [39102,39694]
===
match
---
operator: , [29753,29754]
operator: , [29765,29766]
===
match
---
name: pytest [43065,43071]
name: pytest [43077,43083]
===
match
---
name: mock_client [10274,10285]
name: mock_client [10286,10297]
===
match
---
operator: = [21884,21885]
operator: = [21896,21897]
===
match
---
atom_expr [12425,12519]
atom_expr [12437,12531]
===
match
---
name: client [13756,13762]
name: client [13768,13774]
===
match
---
name: return_value [7622,7634]
name: return_value [7634,7646]
===
match
---
decorator [25003,25081]
decorator [25015,25093]
===
match
---
name: return_value [9021,9033]
name: return_value [9033,9045]
===
match
---
dotted_name [15288,15298]
dotted_name [15300,15310]
===
match
---
operator: = [8969,8970]
operator: = [8981,8982]
===
match
---
expr_stmt [4218,4366]
expr_stmt [4230,4378]
===
match
---
name: match [17745,17750]
name: match [17757,17762]
===
match
---
name: patch [33845,33850]
name: patch [33857,33862]
===
match
---
argument [43603,43619]
argument [43615,43631]
===
match
---
atom_expr [16624,16675]
atom_expr [16636,16687]
===
match
---
decorated [15287,16125]
decorated [15299,16137]
===
match
---
string: 'destroyed' [35039,35050]
string: 'destroyed' [35051,35062]
===
match
---
name: create_or_update_secret [40987,41010]
name: create_or_update_secret [40999,41022]
===
match
---
argument [41742,41760]
argument [41754,41772]
===
match
---
param [40541,40550]
param [40553,40562]
===
match
---
operator: = [5939,5940]
operator: = [5951,5952]
===
match
---
name: kv_engine_version [22411,22428]
name: kv_engine_version [22423,22440]
===
match
---
operator: = [15427,15428]
operator: = [15439,15440]
===
match
---
name: secret [21521,21527]
name: secret [21533,21539]
===
match
---
trailer [41981,41983]
trailer [41993,41995]
===
match
---
operator: , [13587,13588]
operator: , [13599,13600]
===
match
---
name: vault_client [18890,18902]
name: vault_client [18902,18914]
===
match
---
suite [1111,44030]
suite [1111,44042]
===
match
---
funcdef [32796,33834]
funcdef [32808,33846]
===
match
---
name: VaultError [3863,3873]
name: VaultError [3875,3885]
===
match
---
string: 'version' [35298,35307]
string: 'version' [35310,35319]
===
match
---
name: MagicMock [23652,23661]
name: MagicMock [23664,23673]
===
match
---
atom_expr [18465,18540]
atom_expr [18477,18552]
===
match
---
trailer [1349,1356]
trailer [1349,1356]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [29488,29517]
string: '2020-03-16T21:01:43.331126Z' [29500,29529]
===
match
---
trailer [43877,43901]
trailer [43889,43913]
===
match
---
trailer [4245,4366]
trailer [4257,4378]
===
match
---
simple_stmt [3514,3559]
simple_stmt [3526,3571]
===
match
---
operator: = [9239,9240]
operator: = [9251,9252]
===
match
---
operator: = [15801,15802]
operator: = [15813,15814]
===
match
---
name: auth_aws_iam [5335,5347]
name: auth_aws_iam [5347,5359]
===
match
---
simple_stmt [28223,28254]
simple_stmt [28235,28266]
===
match
---
name: test_ldap [18089,18098]
name: test_ldap [18101,18110]
===
match
---
name: auth_type [42849,42858]
name: auth_type [42861,42870]
===
match
---
arglist [2699,2731]
arglist [2705,2737]
===
match
---
trailer [22626,22639]
trailer [22638,22651]
===
match
---
simple_stmt [3302,3331]
simple_stmt [3308,3337]
===
match
---
atom_expr [1987,2003]
atom_expr [1987,2003]
===
match
---
atom_expr [18164,18193]
atom_expr [18176,18205]
===
match
---
trailer [30138,30158]
trailer [30150,30170]
===
match
---
operator: , [3948,3949]
operator: , [3960,3961]
===
match
---
expr_stmt [34075,34266]
expr_stmt [34087,34278]
===
match
---
simple_stmt [10661,10690]
simple_stmt [10673,10702]
===
match
---
decorator [41809,41887]
decorator [41821,41899]
===
match
---
operator: { [30741,30742]
operator: { [30753,30754]
===
match
---
atom_expr [3579,3609]
atom_expr [3591,3621]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [39020,39084]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [39032,39096]
===
match
---
dotted_name [37054,37064]
dotted_name [37066,37076]
===
match
---
atom_expr [42823,43051]
atom_expr [42835,43063]
===
match
---
operator: , [40852,40853]
operator: , [40864,40865]
===
match
---
simple_stmt [18549,18594]
simple_stmt [18561,18606]
===
match
---
param [10138,10143]
param [10150,10155]
===
match
---
trailer [27047,27055]
trailer [27059,27067]
===
match
---
trailer [12801,12808]
trailer [12813,12820]
===
match
---
operator: { [33023,33024]
operator: { [33035,33036]
===
match
---
argument [33659,33680]
argument [33671,33692]
===
match
---
param [18105,18114]
param [18117,18126]
===
match
---
string: "token" [23091,23098]
string: "token" [23103,23110]
===
match
---
atom_expr [22610,22639]
atom_expr [22622,22651]
===
match
---
number: 1 [37804,37805]
number: 1 [37816,37817]
===
match
---
param [2291,2296]
param [2291,2296]
===
match
---
atom_expr [2806,2836]
atom_expr [2812,2842]
===
match
---
name: vault_client [42297,42309]
name: vault_client [42309,42321]
===
match
---
simple_stmt [9074,9224]
simple_stmt [9086,9236]
===
match
---
name: mock_get_credentials [8801,8821]
name: mock_get_credentials [8813,8833]
===
match
---
string: "radhost" [42130,42139]
string: "radhost" [42142,42151]
===
match
---
simple_stmt [8271,8487]
simple_stmt [8283,8499]
===
match
---
name: client [18549,18555]
name: client [18561,18567]
===
match
---
operator: = [14694,14695]
operator: = [14706,14707]
===
match
---
operator: , [10641,10642]
operator: , [10653,10654]
===
match
---
name: create_or_update_secret [41659,41682]
name: create_or_update_secret [41671,41694]
===
match
---
string: "airflow.providers.google.cloud.utils.credentials_provider._get_scopes" [9831,9902]
string: "airflow.providers.google.cloud.utils.credentials_provider._get_scopes" [9843,9914]
===
match
---
operator: = [33525,33526]
operator: = [33537,33538]
===
match
---
operator: = [3237,3238]
operator: = [3243,3244]
===
match
---
simple_stmt [41953,41984]
simple_stmt [41965,41996]
===
match
---
string: "path" [41023,41029]
string: "path" [41035,41041]
===
match
---
suite [12744,13281]
suite [12756,13293]
===
match
---
trailer [29133,29141]
trailer [29145,29153]
===
match
---
param [17180,17189]
param [17192,17201]
===
match
---
trailer [8209,8257]
trailer [8221,8269]
===
match
---
name: secret [33626,33632]
name: secret [33638,33644]
===
match
---
string: 'deletion_time' [34998,35013]
string: 'deletion_time' [35010,35025]
===
match
---
argument [9477,9494]
argument [9489,9506]
===
match
---
atom_expr [26951,26997]
atom_expr [26963,27009]
===
match
---
operator: , [17601,17602]
operator: , [17613,17614]
===
match
---
string: 'version' [35961,35970]
string: 'version' [35973,35982]
===
match
---
operator: , [38323,38324]
operator: , [38335,38336]
===
match
---
operator: , [42352,42353]
operator: , [42364,42365]
===
match
---
trailer [11663,11676]
trailer [11675,11688]
===
match
---
name: mock [8114,8118]
name: mock [8126,8130]
===
match
---
operator: , [36907,36908]
operator: , [36919,36920]
===
match
---
trailer [17218,17228]
trailer [17230,17240]
===
match
---
name: radius_secret [32387,32400]
name: radius_secret [32399,32412]
===
match
---
string: 'secret' [32683,32691]
string: 'secret' [32695,32703]
===
match
---
name: secret_version [31426,31440]
name: secret_version [31438,31452]
===
match
---
operator: , [37839,37840]
operator: , [37851,37852]
===
match
---
atom_expr [6049,6068]
atom_expr [6061,6080]
===
match
---
name: mock [889,893]
name: mock [889,893]
===
match
---
name: radius_secret [29912,29925]
name: radius_secret [29924,29937]
===
match
---
name: mock [9820,9824]
name: mock [9832,9836]
===
match
---
string: "other" [10634,10641]
string: "other" [10646,10653]
===
match
---
trailer [3348,3355]
trailer [3354,3361]
===
match
---
param [18773,18778]
param [18785,18790]
===
match
---
atom_expr [3792,3821]
atom_expr [3804,3833]
===
match
---
trailer [23254,23283]
trailer [23266,23295]
===
match
---
trailer [24985,24997]
trailer [24997,25009]
===
match
---
operator: = [36914,36915]
operator: = [36926,36927]
===
match
---
string: "http://localhost:8180" [40829,40852]
string: "http://localhost:8180" [40841,40864]
===
match
---
name: scopes [12306,12312]
name: scopes [12318,12324]
===
match
---
name: MagicMock [18818,18827]
name: MagicMock [18830,18839]
===
match
---
suite [8091,8487]
suite [8103,8499]
===
match
---
atom_expr [34592,34621]
atom_expr [34604,34633]
===
match
---
atom_expr [15716,15767]
atom_expr [15728,15779]
===
match
---
operator: = [26865,26866]
operator: = [26877,26878]
===
match
---
number: 1 [2133,2134]
number: 1 [2133,2134]
===
match
---
operator: , [32202,32203]
operator: , [32214,32215]
===
match
---
name: mock_client [7566,7577]
name: mock_client [7578,7589]
===
match
---
name: url [14775,14778]
name: url [14787,14790]
===
match
---
name: auth_type [20112,20121]
name: auth_type [20124,20133]
===
match
---
operator: , [43979,43980]
operator: , [43991,43992]
===
match
---
name: secrets [42399,42406]
name: secrets [42411,42418]
===
match
---
operator: , [33527,33528]
operator: , [33539,33540]
===
match
---
expr_stmt [29122,29764]
expr_stmt [29134,29776]
===
match
---
string: "pass" [27720,27726]
string: "pass" [27732,27738]
===
match
---
funcdef [2924,3610]
funcdef [2930,3622]
===
match
---
name: test_get_non_existing_key_v2_different_auth [27271,27314]
name: test_get_non_existing_key_v2_different_auth [27283,27326]
===
match
---
name: version [31629,31636]
name: version [31641,31648]
===
match
---
name: mock_client [30113,30124]
name: mock_client [30125,30136]
===
match
---
name: test_create_or_update_secret_v2_method [40496,40534]
name: test_create_or_update_secret_v2_method [40508,40546]
===
match
---
argument [3875,3901]
argument [3887,3913]
===
match
---
operator: = [22057,22058]
operator: = [22069,22070]
===
match
---
operator: , [41931,41932]
operator: , [41943,41944]
===
match
---
string: 'scope1' [8972,8980]
string: 'scope1' [8984,8992]
===
match
---
trailer [9376,9393]
trailer [9388,9405]
===
match
---
string: 'scope1' [10933,10941]
string: 'scope1' [10945,10953]
===
match
---
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [23352,23380]
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [23364,23392]
===
match
---
name: mock [24305,24309]
name: mock [24317,24321]
===
match
---
string: 'renewable' [30668,30679]
string: 'renewable' [30680,30691]
===
match
---
operator: = [26313,26314]
operator: = [26325,26326]
===
match
---
name: vault_client [16094,16106]
name: vault_client [16106,16118]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [1128,1192]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [1128,1192]
===
match
---
decorated [1839,2187]
decorated [1839,2187]
===
match
---
expr_stmt [11833,12028]
expr_stmt [11845,12040]
===
match
---
trailer [19666,19699]
trailer [19678,19711]
===
match
---
param [2974,2983]
param [2980,2989]
===
match
---
trailer [39658,39681]
trailer [39670,39693]
===
match
---
trailer [17309,17357]
trailer [17321,17369]
===
match
---
simple_stmt [34023,34067]
simple_stmt [34035,34079]
===
match
---
string: 'scope2' [11741,11749]
string: 'scope2' [11753,11761]
===
match
---
name: MagicMock [3013,3022]
name: MagicMock [3019,3028]
===
match
---
operator: = [20121,20122]
operator: = [20133,20134]
===
match
---
operator: , [38104,38105]
operator: , [38116,38117]
===
match
---
arglist [30196,30246]
arglist [30208,30258]
===
match
---
operator: , [25961,25962]
operator: , [25973,25974]
===
match
---
string: 'world' [32133,32140]
string: 'world' [32145,32152]
===
match
---
simple_stmt [33336,33618]
simple_stmt [33348,33630]
===
match
---
name: mock_hvac [4412,4421]
name: mock_hvac [4424,4433]
===
match
---
expr_stmt [29030,29060]
expr_stmt [29042,29072]
===
match
---
operator: @ [28893,28894]
operator: @ [28905,28906]
===
match
---
arglist [27609,27768]
arglist [27621,27780]
===
match
---
testlist_comp [9037,9064]
testlist_comp [9049,9076]
===
match
---
param [4863,4872]
param [4875,4884]
===
match
---
name: mock_hvac [4107,4116]
name: mock_hvac [4119,4128]
===
match
---
argument [3258,3282]
argument [3264,3288]
===
match
---
simple_stmt [7094,7317]
simple_stmt [7106,7329]
===
match
---
string: "token" [22783,22790]
string: "token" [22795,22802]
===
match
---
string: "azure" [8311,8318]
string: "azure" [8323,8330]
===
match
---
argument [9186,9213]
argument [9198,9225]
===
match
---
name: vault_client [6993,7005]
name: vault_client [7005,7017]
===
match
---
comparison [7385,7420]
comparison [7397,7432]
===
match
---
name: vault_client [10428,10440]
name: vault_client [10440,10452]
===
match
---
argument [20112,20130]
argument [20124,20142]
===
match
---
simple_stmt [42808,43052]
simple_stmt [42820,43064]
===
match
---
string: 'http://localhost:8180' [23259,23282]
string: 'http://localhost:8180' [23271,23294]
===
match
---
operator: = [1723,1724]
operator: = [1723,1724]
===
match
---
assert_stmt [14006,14048]
assert_stmt [14018,14060]
===
match
---
trailer [19150,19157]
trailer [19162,19169]
===
match
---
suite [4874,5565]
suite [4886,5577]
===
match
---
argument [4325,4338]
argument [4337,4350]
===
match
---
atom_expr [16958,17002]
atom_expr [16970,17014]
===
match
---
operator: = [38097,38098]
operator: = [38109,38110]
===
match
---
name: kv [27953,27955]
name: kv [27965,27967]
===
match
---
operator: , [31043,31044]
operator: , [31055,31056]
===
match
---
name: auth_type [31192,31201]
name: auth_type [31204,31213]
===
match
---
name: gcp_keyfile_dict [11903,11919]
name: gcp_keyfile_dict [11915,11931]
===
match
---
atom_expr [25915,26109]
atom_expr [25927,26121]
===
match
---
funcdef [24386,24998]
funcdef [24398,25010]
===
match
---
operator: = [40703,40704]
operator: = [40715,40716]
===
match
---
operator: = [41598,41599]
operator: = [41610,41611]
===
match
---
expr_stmt [32970,33326]
expr_stmt [32982,33338]
===
match
---
param [10155,10176]
param [10167,10188]
===
match
---
string: 'http://localhost:8180' [11011,11034]
string: 'http://localhost:8180' [11023,11046]
===
match
---
argument [15069,15096]
argument [15081,15108]
===
match
---
argument [17322,17356]
argument [17334,17368]
===
match
---
name: secret_key [5399,5409]
name: secret_key [5411,5421]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [20201,20265]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [20213,20277]
===
match
---
comparison [2151,2186]
comparison [2151,2186]
===
match
---
name: v2 [31531,31533]
name: v2 [31543,31545]
===
match
---
name: scopes [10925,10931]
name: scopes [10937,10943]
===
match
---
name: login [13863,13868]
name: login [13875,13880]
===
match
---
operator: = [15643,15644]
operator: = [15655,15656]
===
match
---
expr_stmt [7566,7596]
expr_stmt [7578,7608]
===
match
---
trailer [25578,25597]
trailer [25590,25609]
===
match
---
atom_expr [24545,24622]
atom_expr [24557,24634]
===
match
---
name: self [41927,41931]
name: self [41939,41943]
===
match
---
name: assert_called_with [5493,5511]
name: assert_called_with [5505,5523]
===
match
---
name: mock [10217,10221]
name: mock [10229,10233]
===
match
---
operator: = [22961,22962]
operator: = [22973,22974]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [37661,37690]
string: '2020-03-16T21:01:43.331126Z' [37673,37702]
===
match
---
operator: = [42507,42508]
operator: = [42519,42520]
===
match
---
operator: = [16354,16355]
operator: = [16366,16367]
===
match
---
expr_stmt [26718,26791]
expr_stmt [26730,26803]
===
match
---
expr_stmt [25848,25891]
expr_stmt [25860,25903]
===
match
---
trailer [18854,18867]
trailer [18866,18879]
===
match
---
name: return_value [18855,18867]
name: return_value [18867,18879]
===
match
---
trailer [9101,9223]
trailer [9113,9235]
===
match
---
assert_stmt [16082,16124]
assert_stmt [16094,16136]
===
match
---
operator: = [39300,39301]
operator: = [39312,39313]
===
match
---
name: mock_client [23633,23644]
name: mock_client [23645,23656]
===
match
---
operator: = [7163,7164]
operator: = [7175,7176]
===
match
---
operator: @ [27185,27186]
operator: @ [27197,27198]
===
match
---
operator: == [1806,1808]
operator: == [1806,1808]
===
match
---
dotted_name [845,858]
dotted_name [845,858]
===
match
---
operator: = [31235,31236]
operator: = [31247,31248]
===
match
---
string: "other" [3497,3504]
string: "other" [3509,3516]
===
match
---
name: create_or_update_secret [40258,40281]
name: create_or_update_secret [40270,40293]
===
match
---
atom [34909,35110]
atom [34921,35122]
===
match
---
name: mock_client [41295,41306]
name: mock_client [41307,41318]
===
match
---
trailer [9795,9813]
trailer [9807,9825]
===
match
---
string: "http://localhost:8180" [34199,34222]
string: "http://localhost:8180" [34211,34234]
===
match
---
string: 'http://localhost:8180' [10738,10761]
string: 'http://localhost:8180' [10750,10773]
===
match
---
number: 2 [16089,16090]
number: 2 [16101,16102]
===
match
---
arglist [25261,25344]
arglist [25273,25356]
===
match
---
dotted_name [41077,41087]
dotted_name [41089,41099]
===
match
---
assert_stmt [23456,23499]
assert_stmt [23468,23511]
===
match
---
simple_stmt [28694,28750]
simple_stmt [28706,28762]
===
match
---
operator: = [43614,43615]
operator: = [43626,43627]
===
match
---
simple_stmt [14904,14933]
simple_stmt [14916,14945]
===
match
---
string: "kubernetes" [17838,17850]
string: "kubernetes" [17850,17862]
===
match
---
name: mount_point [7286,7297]
name: mount_point [7298,7309]
===
match
---
operator: , [26283,26284]
operator: , [26295,26296]
===
match
---
string: "user" [5984,5990]
string: "user" [5996,6002]
===
match
---
decorator [26432,26510]
decorator [26444,26522]
===
match
---
string: 'value' [43996,44003]
string: 'value' [44008,44015]
===
match
---
name: mock [23647,23651]
name: mock [23659,23663]
===
match
---
string: 'version' [35079,35088]
string: 'version' [35091,35100]
===
match
---
name: _VaultClient [37961,37973]
name: _VaultClient [37973,37985]
===
match
---
name: assert_called_with [2765,2783]
name: assert_called_with [2771,2789]
===
match
---
operator: = [1316,1317]
operator: = [1316,1317]
===
match
---
name: secrets [37307,37314]
name: secrets [37319,37326]
===
match
---
string: "http://localhost:8180" [9190,9213]
string: "http://localhost:8180" [9202,9225]
===
match
---
string: "github" [14405,14413]
string: "github" [14417,14425]
===
match
---
name: pytest [926,932]
name: pytest [926,932]
===
match
---
with_stmt [40872,41071]
with_stmt [40884,41083]
===
match
---
operator: } [41053,41054]
operator: } [41065,41066]
===
match
---
expr_stmt [27486,27559]
expr_stmt [27498,27571]
===
match
---
name: kubernetes_role [17868,17883]
name: kubernetes_role [17880,17895]
===
match
---
simple_stmt [26718,26792]
simple_stmt [26730,26804]
===
match
---
string: "pass" [18301,18307]
string: "pass" [18313,18319]
===
match
---
atom [30560,31141]
atom [30572,31153]
===
match
---
trailer [13959,13976]
trailer [13971,13988]
===
match
---
expr_stmt [7605,7648]
expr_stmt [7617,7660]
===
match
---
argument [15991,16007]
argument [16003,16019]
===
match
---
trailer [24467,24469]
trailer [24479,24481]
===
match
---
name: mock_hvac [22162,22171]
name: mock_hvac [22174,22183]
===
match
---
trailer [10714,10733]
trailer [10726,10745]
===
match
---
trailer [13108,13115]
trailer [13120,13127]
===
match
---
trailer [28405,28417]
trailer [28417,28429]
===
match
---
name: return_value [15471,15483]
name: return_value [15483,15495]
===
match
---
param [1599,1608]
param [1599,1608]
===
match
---
argument [2470,2484]
argument [2470,2484]
===
match
---
parameters [10137,10193]
parameters [10149,10205]
===
match
---
argument [11990,12017]
argument [12002,12029]
===
match
---
name: auth_type [23882,23891]
name: auth_type [23894,23903]
===
match
---
param [20990,20995]
param [21002,21007]
===
match
---
name: vault_client [22134,22146]
name: vault_client [22146,22158]
===
match
---
decorated [32714,33834]
decorated [32726,33846]
===
match
---
trailer [12605,12623]
trailer [12617,12635]
===
match
---
trailer [1821,1833]
trailer [1821,1833]
===
match
---
name: username [25975,25983]
name: username [25987,25995]
===
match
---
atom_expr [19141,19205]
atom_expr [19153,19217]
===
match
---
name: raises [1350,1356]
name: raises [1350,1356]
===
match
---
param [1593,1598]
param [1593,1598]
===
match
---
name: url [10734,10737]
name: url [10746,10749]
===
match
---
arglist [10884,10952]
arglist [10896,10964]
===
match
---
operator: , [31245,31246]
operator: , [31257,31258]
===
match
---
string: 'lease_duration' [35728,35744]
string: 'lease_duration' [35740,35756]
===
match
---
trailer [27389,27396]
trailer [27401,27408]
===
match
---
simple_stmt [2408,2542]
simple_stmt [2408,2542]
===
match
---
string: 'request_id' [31950,31962]
string: 'request_id' [31962,31974]
===
match
---
name: url [7846,7849]
name: url [7858,7861]
===
match
---
atom_expr [34280,34329]
atom_expr [34292,34341]
===
match
---
operator: = [12994,12995]
operator: = [13006,13007]
===
match
---
name: mock_file [14941,14950]
name: mock_file [14953,14962]
===
match
---
trailer [19659,19666]
trailer [19671,19678]
===
match
---
atom_expr [34343,34407]
atom_expr [34355,34419]
===
match
---
name: mock_client [41224,41235]
name: mock_client [41236,41247]
===
match
---
operator: = [27581,27582]
operator: = [27593,27594]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [27197,27261]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [27209,27273]
===
match
---
name: patch [21692,21697]
name: patch [21704,21709]
===
match
---
trailer [18817,18827]
trailer [18829,18839]
===
match
---
argument [2699,2713]
argument [2705,2719]
===
match
---
simple_stmt [22235,22325]
simple_stmt [22247,22337]
===
match
---
trailer [2365,2372]
trailer [2365,2372]
===
match
---
name: vault_client [25620,25632]
name: vault_client [25632,25644]
===
match
---
simple_stmt [25400,25465]
simple_stmt [25412,25477]
===
match
---
operator: @ [30262,30263]
operator: @ [30274,30275]
===
match
---
operator: , [4323,4324]
operator: , [4335,4336]
===
match
---
string: 'value' [41607,41614]
string: 'value' [41619,41626]
===
match
---
simple_stmt [24954,24998]
simple_stmt [24966,25010]
===
match
---
suite [8840,9814]
suite [8852,9826]
===
match
---
simple_stmt [7325,7370]
simple_stmt [7337,7382]
===
match
---
operator: = [25141,25142]
operator: = [25153,25154]
===
match
---
string: "data" [14869,14875]
string: "data" [14881,14887]
===
match
---
name: get_secret_metadata [37005,37024]
name: get_secret_metadata [37017,37036]
===
match
---
string: 'lease_duration' [33163,33179]
string: 'lease_duration' [33175,33191]
===
match
---
operator: , [28674,28675]
operator: , [28686,28687]
===
match
---
trailer [9558,9577]
trailer [9570,9589]
===
match
---
trailer [26190,26219]
trailer [26202,26231]
===
match
---
arglist [1738,1780]
arglist [1738,1780]
===
match
---
atom_expr [11622,11638]
atom_expr [11634,11650]
===
match
---
simple_stmt [27568,27779]
simple_stmt [27580,27791]
===
match
---
trailer [29167,29180]
trailer [29179,29192]
===
match
---
trailer [6161,6167]
trailer [6173,6179]
===
match
---
trailer [13862,13868]
trailer [13874,13880]
===
match
---
expr_stmt [12037,12065]
expr_stmt [12049,12077]
===
match
---
decorator [17059,17137]
decorator [17071,17149]
===
match
---
arglist [7154,7306]
arglist [7166,7318]
===
match
---
argument [41389,41410]
argument [41401,41422]
===
match
---
name: MagicMock [22590,22599]
name: MagicMock [22602,22611]
===
match
---
name: the_file [23788,23796]
name: the_file [23800,23808]
===
match
---
atom_expr [3008,3024]
atom_expr [3014,3030]
===
match
---
operator: = [6889,6890]
operator: = [6901,6902]
===
match
---
name: vault_client [12996,13008]
name: vault_client [13008,13020]
===
match
---
string: "pass" [36778,36784]
string: "pass" [36790,36796]
===
match
---
string: "tenant_id" [7817,7828]
string: "tenant_id" [7829,7840]
===
match
---
expr_stmt [34592,34635]
expr_stmt [34604,34647]
===
match
---
atom_expr [4233,4366]
atom_expr [4245,4378]
===
match
---
testlist_comp [11796,11823]
testlist_comp [11808,11835]
===
match
---
atom [34706,35355]
atom [34718,35367]
===
match
---
operator: } [38724,38725]
operator: } [38736,38737]
===
match
---
name: _VaultClient [2080,2092]
name: _VaultClient [2080,2092]
===
match
---
trailer [11626,11636]
trailer [11638,11648]
===
match
---
number: 2 [4690,4691]
number: 2 [4702,4703]
===
match
---
param [39811,39820]
param [39823,39832]
===
match
---
name: url [22078,22081]
name: url [22090,22093]
===
match
---
name: MagicMock [29049,29058]
name: MagicMock [29061,29070]
===
match
---
atom [29183,29764]
atom [29195,29776]
===
match
---
operator: , [8078,8079]
operator: , [8090,8091]
===
match
---
decorator [28082,28160]
decorator [28094,28172]
===
match
---
atom_expr [20099,20183]
atom_expr [20111,20195]
===
match
---
expr_stmt [25220,25354]
expr_stmt [25232,25366]
===
match
---
string: "radhost" [39335,39344]
string: "radhost" [39347,39356]
===
match
---
argument [7222,7238]
argument [7234,7250]
===
match
---
operator: = [22025,22026]
operator: = [22037,22038]
===
match
---
name: patch [25662,25667]
name: patch [25674,25679]
===
match
---
name: mock_hvac [3733,3742]
name: mock_hvac [3745,3754]
===
match
---
trailer [23228,23235]
trailer [23240,23247]
===
match
---
funcdef [25085,25651]
funcdef [25097,25663]
===
match
---
operator: = [2042,2043]
operator: = [2042,2043]
===
match
---
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [26866,26894]
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [26878,26906]
===
match
---
name: kv_engine_version [12606,12623]
name: kv_engine_version [12618,12635]
===
match
---
name: radius_port [29882,29893]
name: radius_port [29894,29905]
===
match
---
suite [6590,7421]
suite [6602,7433]
===
match
---
atom [37563,37593]
atom [37575,37605]
===
match
---
with_stmt [8191,8487]
with_stmt [8203,8499]
===
match
---
trailer [4707,4725]
trailer [4719,4737]
===
match
---
simple_stmt [16857,16950]
simple_stmt [16869,16962]
===
match
---
operator: , [39441,39442]
operator: , [39453,39454]
===
match
---
string: 'secret' [43951,43959]
string: 'secret' [43963,43971]
===
match
---
trailer [16656,16674]
trailer [16668,16686]
===
match
---
name: MagicMock [19576,19585]
name: MagicMock [19588,19597]
===
match
---
name: self [6573,6577]
name: self [6585,6589]
===
match
---
name: secret_path [30026,30037]
name: secret_path [30038,30049]
===
match
---
name: mock [15429,15433]
name: mock [15441,15445]
===
match
---
atom_expr [22988,23017]
atom_expr [23000,23029]
===
match
---
file_input [814,44030]
file_input [814,44042]
===
match
---
argument [43013,43040]
argument [43025,43052]
===
match
---
string: "http://localhost:8180" [27744,27767]
string: "http://localhost:8180" [27756,27779]
===
match
---
assert_stmt [2144,2186]
assert_stmt [2144,2186]
===
match
---
comparison [4690,4725]
comparison [4702,4737]
===
match
---
name: client [20666,20672]
name: client [20678,20684]
===
match
---
trailer [30544,30557]
trailer [30556,30569]
===
match
---
operator: = [21265,21266]
operator: = [21277,21278]
===
match
---
trailer [4447,4476]
trailer [4459,4488]
===
match
---
atom_expr [32917,32946]
atom_expr [32929,32958]
===
match
---
argument [25261,25281]
argument [25273,25293]
===
match
---
name: mock [22435,22439]
name: mock [22447,22451]
===
match
---
name: VaultError [1357,1367]
name: VaultError [1357,1367]
===
match
---
operator: , [5198,5199]
operator: , [5210,5211]
===
match
---
simple_stmt [26800,26934]
simple_stmt [26812,26946]
===
match
---
trailer [29085,29098]
trailer [29097,29110]
===
match
---
parameters [21788,21805]
parameters [21800,21817]
===
match
---
name: login [18482,18487]
name: login [18494,18499]
===
match
---
atom_expr [23990,24009]
atom_expr [24002,24021]
===
match
---
dotted_name [20866,20876]
dotted_name [20878,20888]
===
match
---
name: vault_client [14018,14030]
name: vault_client [14030,14042]
===
match
---
name: client [15186,15192]
name: client [15198,15204]
===
match
---
operator: = [24707,24708]
operator: = [24719,24720]
===
match
---
operator: = [5055,5056]
operator: = [5067,5068]
===
match
---
trailer [14240,14247]
trailer [14252,14259]
===
match
---
string: 'value' [33698,33705]
string: 'value' [33710,33717]
===
match
---
name: kv [31903,31905]
name: kv [31915,31917]
===
match
---
name: kv_engine_version [13263,13280]
name: kv_engine_version [13275,13292]
===
match
---
operator: == [23381,23383]
operator: == [23393,23395]
===
match
---
atom_expr [9241,9260]
atom_expr [9253,9272]
===
match
---
name: mock_hvac [7021,7030]
name: mock_hvac [7033,7042]
===
match
---
param [1227,1236]
param [1227,1236]
===
match
---
name: InvalidPath [26778,26789]
name: InvalidPath [26790,26801]
===
match
---
simple_stmt [2660,2733]
simple_stmt [2660,2739]
===
match
---
argument [23100,23134]
argument [23112,23146]
===
match
---
atom_expr [31166,31361]
atom_expr [31178,31373]
===
match
---
name: auth [6157,6161]
name: auth [6169,6173]
===
match
---
name: return_value [21871,21883]
name: return_value [21883,21895]
===
match
---
operator: = [42522,42523]
operator: = [42534,42535]
===
match
---
trailer [10707,10714]
trailer [10719,10726]
===
match
---
decorator [23505,23583]
decorator [23517,23595]
===
match
---
atom_expr [16857,16949]
atom_expr [16869,16961]
===
match
---
name: kv [42407,42409]
name: kv [42419,42421]
===
match
---
argument [36667,36685]
argument [36679,36697]
===
match
---
expr_stmt [22610,22653]
expr_stmt [22622,22665]
===
match
---
name: gcp_scopes [11950,11960]
name: gcp_scopes [11962,11972]
===
match
---
atom_expr [40668,40863]
atom_expr [40680,40875]
===
match
---
simple_stmt [25363,25392]
simple_stmt [25375,25404]
===
match
---
operator: } [38739,38740]
operator: } [38751,38752]
===
match
---
arglist [42474,42552]
arglist [42486,42564]
===
match
---
decorator [13286,13364]
decorator [13298,13376]
===
match
---
expr_stmt [4127,4157]
expr_stmt [4139,4169]
===
match
---
string: "http://localhost:8180" [21291,21314]
string: "http://localhost:8180" [21303,21326]
===
match
---
name: assert_called_with [2604,2622]
name: assert_called_with [2604,2622]
===
match
---
simple_stmt [11833,12029]
simple_stmt [11845,12041]
===
match
---
argument [20510,20537]
argument [20522,20549]
===
match
---
string: '' [32028,32030]
string: '' [32040,32042]
===
match
---
number: 2 [26391,26392]
number: 2 [26403,26404]
===
match
---
argument [13649,13676]
argument [13661,13688]
===
match
---
operator: } [42376,42377]
operator: } [42388,42389]
===
match
---
name: self [17597,17601]
name: self [17609,17613]
===
match
---
funcdef [31736,32709]
funcdef [31748,32721]
===
match
---
parameters [32851,32868]
parameters [32863,32880]
===
match
---
argument [12388,12415]
argument [12400,12427]
===
match
---
operator: = [10510,10511]
operator: = [10522,10523]
===
match
---
atom_expr [4897,4913]
atom_expr [4909,4925]
===
match
---
name: secrets [28800,28807]
name: secrets [28812,28819]
===
match
---
name: mock_client [36258,36269]
name: mock_client [36270,36281]
===
match
---
name: vault_client [21650,21662]
name: vault_client [21662,21674]
===
match
---
operator: = [31201,31202]
operator: = [31213,31214]
===
match
---
param [25789,25798]
param [25801,25810]
===
match
---
operator: = [29787,29788]
operator: = [29799,29800]
===
match
---
name: token [34147,34152]
name: token [34159,34164]
===
match
---
string: 'created_time' [38546,38560]
string: 'created_time' [38558,38572]
===
match
---
argument [40791,40811]
argument [40803,40823]
===
match
---
trailer [21627,21629]
trailer [21639,21641]
===
match
---
operator: , [10153,10154]
operator: , [10165,10166]
===
match
---
atom_expr [39172,39188]
atom_expr [39184,39200]
===
match
---
name: version [27157,27164]
name: version [27169,27176]
===
match
---
atom_expr [42297,42378]
atom_expr [42309,42390]
===
match
---
simple_stmt [7736,7954]
simple_stmt [7748,7966]
===
match
---
name: kv_engine_version [17036,17053]
name: kv_engine_version [17048,17065]
===
match
---
operator: @ [11335,11336]
operator: @ [11347,11348]
===
match
---
operator: = [40205,40206]
operator: = [40217,40218]
===
match
---
operator: = [23702,23703]
operator: = [23714,23715]
===
match
---
param [41927,41932]
param [41939,41944]
===
match
---
name: patch [8587,8592]
name: patch [8599,8604]
===
match
---
trailer [43783,43843]
trailer [43795,43855]
===
match
---
name: return_value [10310,10322]
name: return_value [10322,10334]
===
match
---
assert_stmt [11198,11240]
assert_stmt [11210,11252]
===
match
---
atom_expr [36573,36602]
atom_expr [36585,36614]
===
match
---
expr_stmt [3753,3783]
expr_stmt [3765,3795]
===
match
---
operator: , [9130,9131]
operator: , [9142,9143]
===
match
---
name: azure_resource [6803,6817]
name: azure_resource [6815,6829]
===
match
---
name: mount_point [11116,11127]
name: mount_point [11128,11139]
===
match
---
trailer [21044,21046]
trailer [21056,21058]
===
match
---
expr_stmt [40600,40643]
expr_stmt [40612,40655]
===
match
---
argument [12941,12968]
argument [12953,12980]
===
match
---
name: mock [43417,43421]
name: mock [43429,43433]
===
match
---
trailer [43759,43783]
trailer [43771,43795]
===
match
---
atom_expr [18905,19095]
atom_expr [18917,19107]
===
match
---
simple_stmt [15033,15098]
simple_stmt [15045,15110]
===
match
---
name: vault_client [25372,25384]
name: vault_client [25384,25396]
===
match
---
with_stmt [20032,20184]
with_stmt [20044,20196]
===
match
---
atom [33023,33326]
atom [33035,33338]
===
match
---
name: mock [11247,11251]
name: mock [11259,11263]
===
match
---
trailer [9278,9285]
trailer [9290,9297]
===
match
---
name: vault_client [40974,40986]
name: vault_client [40986,40998]
===
match
---
param [42690,42695]
param [42702,42707]
===
match
---
operator: = [31934,31935]
operator: = [31946,31947]
===
match
---
decorated [7959,8487]
decorated [7971,8499]
===
match
---
string: "missing" [26987,26996]
string: "missing" [26999,27008]
===
match
---
operator: , [6828,6829]
operator: , [6840,6841]
===
match
---
name: Client [25858,25864]
name: Client [25870,25876]
===
match
---
trailer [5811,6031]
trailer [5823,6043]
===
match
---
dotted_name [23506,23516]
dotted_name [23518,23528]
===
match
---
arglist [19256,19309]
arglist [19268,19321]
===
match
---
trailer [17000,17002]
trailer [17012,17014]
===
match
---
atom_expr [13771,13835]
atom_expr [13783,13847]
===
match
---
arglist [25513,25545]
arglist [25525,25557]
===
match
---
name: test_ldap_different_auth_mount_point [18736,18772]
name: test_ldap_different_auth_mount_point [18748,18784]
===
match
---
operator: , [37900,37901]
operator: , [37912,37913]
===
match
---
atom_expr [10971,11035]
atom_expr [10983,11047]
===
match
---
trailer [6425,6443]
trailer [6437,6455]
===
match
---
name: self [3727,3731]
name: self [3739,3743]
===
match
---
operator: , [43239,43240]
operator: , [43251,43252]
===
match
---
trailer [23315,23334]
trailer [23327,23346]
===
match
---
atom_expr [16784,16848]
atom_expr [16796,16860]
===
match
---
comparison [17018,17053]
comparison [17030,17065]
===
match
---
operator: = [40352,40353]
operator: = [40364,40365]
===
match
---
argument [22044,22064]
argument [22056,22076]
===
match
---
operator: @ [42568,42569]
operator: @ [42580,42581]
===
match
---
trailer [28390,28393]
trailer [28402,28405]
===
match
---
operator: , [39136,39137]
operator: , [39148,39149]
===
match
---
name: method [44006,44012]
name: method [44018,44024]
===
match
---
operator: = [42547,42548]
operator: = [42559,42560]
===
match
---
atom_expr [24183,24195]
atom_expr [24195,24207]
===
match
---
operator: = [21028,21029]
operator: = [21040,21041]
===
match
---
trailer [13868,13887]
trailer [13880,13899]
===
match
---
name: mock_client [30407,30418]
name: mock_client [30419,30430]
===
match
---
operator: , [42867,42868]
operator: , [42879,42880]
===
match
---
trailer [12771,12781]
trailer [12783,12793]
===
match
---
operator: , [31009,31010]
operator: , [31021,31022]
===
match
---
operator: } [33227,33228]
operator: } [33239,33240]
===
match
---
argument [18428,18455]
argument [18440,18467]
===
match
---
string: 'request_id' [30574,30586]
string: 'request_id' [30586,30598]
===
match
---
trailer [31519,31527]
trailer [31531,31539]
===
match
---
operator: = [41366,41367]
operator: = [41378,41379]
===
match
---
decorated [14054,14444]
decorated [14066,14456]
===
match
---
simple_stmt [26942,26998]
simple_stmt [26954,27010]
===
match
---
string: 'secret_value' [38479,38493]
string: 'secret_value' [38491,38505]
===
match
---
operator: , [5397,5398]
operator: , [5409,5410]
===
match
---
trailer [26354,26373]
trailer [26366,26385]
===
match
---
name: MagicMock [19960,19969]
name: MagicMock [19972,19981]
===
match
---
atom_expr [26778,26791]
atom_expr [26790,26803]
===
match
---
name: client [9232,9238]
name: client [9244,9250]
===
match
---
string: "http://localhost:8180" [2490,2513]
string: "http://localhost:8180" [2490,2513]
===
match
---
name: url [18309,18312]
name: url [18321,18324]
===
match
---
operator: = [33670,33671]
operator: = [33682,33683]
===
match
---
decorator [4002,4080]
decorator [4014,4092]
===
match
---
operator: , [14847,14848]
operator: , [14859,14860]
===
match
---
trailer [12436,12440]
trailer [12448,12452]
===
match
---
arglist [15722,15766]
arglist [15734,15778]
===
match
---
suite [29021,30257]
suite [29033,30269]
===
match
---
argument [28483,28501]
argument [28495,28513]
===
match
---
operator: = [11919,11920]
operator: = [11931,11932]
===
match
---
string: "builtins.open" [16630,16645]
string: "builtins.open" [16642,16657]
===
match
---
atom_expr [23417,23447]
atom_expr [23429,23459]
===
match
---
string: "kubernetes" [16427,16439]
string: "kubernetes" [16439,16451]
===
match
---
atom_expr [27900,27924]
atom_expr [27912,27936]
===
match
---
arglist [33377,33607]
arglist [33389,33619]
===
match
---
decorated [9819,11241]
decorated [9831,11253]
===
match
---
string: "http://localhost:8180" [20514,20537]
string: "http://localhost:8180" [20526,20549]
===
match
---
name: mock_hvac [21795,21804]
name: mock_hvac [21807,21816]
===
match
---
name: Client [15886,15892]
name: Client [15898,15904]
===
match
---
simple_stmt [15239,15282]
simple_stmt [15251,15294]
===
match
---
operator: , [42236,42237]
operator: , [42248,42249]
===
match
---
decorator [36394,36472]
decorator [36406,36484]
===
match
---
atom [29390,29420]
atom [29402,29432]
===
match
---
atom_expr [9615,9709]
atom_expr [9627,9721]
===
match
---
name: return_value [37341,37353]
name: return_value [37353,37365]
===
match
---
string: "tenant_id" [7164,7175]
string: "tenant_id" [7176,7187]
===
match
---
operator: { [40368,40369]
operator: { [40380,40381]
===
match
---
expr_stmt [19596,19639]
expr_stmt [19608,19651]
===
match
---
name: kubernetes_jwt_path [15624,15643]
name: kubernetes_jwt_path [15636,15655]
===
match
---
name: mount_point [21547,21558]
name: mount_point [21559,21570]
===
match
---
trailer [21406,21435]
trailer [21418,21447]
===
match
---
argument [26841,26858]
argument [26853,26870]
===
match
---
trailer [15911,15940]
trailer [15923,15952]
===
match
---
simple_stmt [23219,23284]
simple_stmt [23231,23296]
===
match
---
operator: = [32890,32891]
operator: = [32902,32903]
===
match
---
argument [43196,43214]
argument [43208,43226]
===
match
---
decorated [39687,40405]
decorated [39699,40417]
===
match
---
argument [25317,25344]
argument [25329,25356]
===
match
---
atom_expr [1725,1781]
atom_expr [1725,1781]
===
match
---
name: client [20764,20770]
name: client [20776,20782]
===
match
---
operator: , [3145,3146]
operator: , [3151,3152]
===
match
---
atom_expr [25235,25354]
atom_expr [25247,25366]
===
match
---
name: patch [31660,31665]
name: patch [31672,31677]
===
match
---
name: mock_client [25129,25140]
name: mock_client [25141,25152]
===
match
---
name: path [33818,33822]
name: path [33830,33834]
===
match
---
string: "radius" [19736,19744]
string: "radius" [19748,19756]
===
match
---
name: _VaultClient [40668,40680]
name: _VaultClient [40680,40692]
===
match
---
name: url [28647,28650]
name: url [28659,28662]
===
match
---
name: MagicMock [25148,25157]
name: MagicMock [25160,25169]
===
match
---
name: client [5469,5475]
name: client [5481,5487]
===
match
---
name: secret [28694,28700]
name: secret [28706,28712]
===
match
---
trailer [26234,26248]
trailer [26246,26260]
===
match
---
operator: , [34800,34801]
operator: , [34812,34813]
===
match
---
argument [21215,21235]
argument [21227,21247]
===
match
---
name: assert_called_with [4654,4672]
name: assert_called_with [4666,4684]
===
match
---
name: password [26004,26012]
name: password [26016,26024]
===
match
---
atom [42361,42377]
atom [42373,42389]
===
match
---
trailer [19325,19342]
trailer [19337,19354]
===
match
---
name: username [18961,18969]
name: username [18973,18981]
===
match
---
name: vault_client [2065,2077]
name: vault_client [2065,2077]
===
match
---
name: pytest [1343,1349]
name: pytest [1343,1349]
===
match
---
name: mock_client [37295,37306]
name: mock_client [37307,37318]
===
match
---
operator: , [41740,41741]
operator: , [41752,41753]
===
match
---
name: mock_client [18196,18207]
name: mock_client [18208,18219]
===
match
---
atom [38438,38740]
atom [38450,38752]
===
match
---
string: "user" [7898,7904]
string: "user" [7910,7916]
===
match
---
string: 'data' [29356,29362]
string: 'data' [29368,29374]
===
match
---
operator: , [43040,43041]
operator: , [43052,43053]
===
match
---
operator: = [28561,28562]
operator: = [28573,28574]
===
match
---
with_stmt [3844,3997]
with_stmt [3856,4009]
===
match
---
simple_stmt [24794,24846]
simple_stmt [24806,24858]
===
match
---
operator: = [32299,32300]
operator: = [32311,32312]
===
match
---
trailer [40616,40629]
trailer [40628,40641]
===
match
---
name: secrets [34656,34663]
name: secrets [34668,34675]
===
match
---
name: test_approle [2278,2290]
name: test_approle [2278,2290]
===
match
---
trailer [18408,18427]
trailer [18420,18439]
===
match
---
operator: = [23090,23091]
operator: = [23102,23103]
===
match
---
name: mount_point [1822,1833]
name: mount_point [1822,1833]
===
match
---
string: "builtins.open" [14832,14847]
string: "builtins.open" [14844,14859]
===
match
---
name: read_secret_metadata [34670,34690]
name: read_secret_metadata [34682,34702]
===
match
---
simple_stmt [5255,5320]
simple_stmt [5267,5332]
===
match
---
suite [42707,43249]
suite [42719,43261]
===
match
---
name: auth_type [1436,1445]
name: auth_type [1436,1445]
===
match
---
dotted_name [2843,2853]
dotted_name [2849,2859]
===
match
---
name: _VaultClient [2423,2435]
name: _VaultClient [2423,2435]
===
match
---
operator: = [2329,2330]
operator: = [2329,2330]
===
match
---
number: 1 [42235,42236]
number: 1 [42247,42248]
===
match
---
suite [25120,25651]
suite [25132,25663]
===
match
---
number: 8110 [32369,32373]
number: 8110 [32381,32385]
===
match
---
arglist [25941,26099]
arglist [25953,26111]
===
match
---
testlist_comp [34909,35330]
testlist_comp [34921,35342]
===
match
---
operator: = [41790,41791]
operator: = [41802,41803]
===
match
---
string: "other" [3275,3282]
string: "other" [3281,3288]
===
match
---
argument [40095,40122]
argument [40107,40134]
===
match
---
string: 'key' [42524,42529]
string: 'key' [42536,42541]
===
match
---
name: mock_open [16647,16656]
name: mock_open [16659,16668]
===
match
---
simple_stmt [25473,25547]
simple_stmt [25485,25559]
===
match
---
name: vault_client [32249,32261]
name: vault_client [32261,32273]
===
match
---
name: mock_client [25809,25820]
name: mock_client [25821,25832]
===
match
---
name: mock_client [16356,16367]
name: mock_client [16368,16379]
===
match
---
trailer [7100,7105]
trailer [7112,7117]
===
match
---
name: kv_engine_version [24928,24945]
name: kv_engine_version [24940,24957]
===
match
---
name: Client [3802,3808]
name: Client [3814,3820]
===
match
---
name: raises [20044,20050]
name: raises [20056,20062]
===
match
---
trailer [33756,33759]
trailer [33768,33771]
===
match
---
trailer [28810,28813]
trailer [28822,28825]
===
match
---
name: MagicMock [26592,26601]
name: MagicMock [26604,26613]
===
match
---
trailer [9621,9626]
trailer [9633,9638]
===
match
---
operator: == [9780,9782]
operator: == [9792,9794]
===
match
---
operator: = [42785,42786]
operator: = [42797,42798]
===
match
---
argument [21180,21201]
argument [21192,21213]
===
match
---
name: vault_client [19113,19125]
name: vault_client [19125,19137]
===
match
---
expr_stmt [12753,12783]
expr_stmt [12765,12795]
===
match
---
name: token [35424,35429]
name: token [35436,35441]
===
match
---
operator: , [29420,29421]
operator: , [29432,29433]
===
match
---
operator: = [3476,3477]
operator: = [3488,3489]
===
match
---
name: test_kubernetes_different_auth_mount_point [16216,16258]
name: test_kubernetes_different_auth_mount_point [16228,16270]
===
match
---
string: "gcp" [10479,10484]
string: "gcp" [10491,10496]
===
match
---
trailer [3012,3022]
trailer [3018,3028]
===
match
---
name: _VaultClient [36641,36653]
name: _VaultClient [36653,36665]
===
match
---
name: return_value [42009,42021]
name: return_value [42021,42033]
===
match
---
atom_expr [35517,35572]
atom_expr [35529,35584]
===
match
---
atom_expr [17371,17464]
atom_expr [17383,17476]
===
match
---
name: mock_hvac [23672,23681]
name: mock_hvac [23684,23693]
===
match
---
name: mock_hvac [24419,24428]
name: mock_hvac [24431,24440]
===
match
---
simple_stmt [40974,41071]
simple_stmt [40986,41083]
===
match
---
decorators [11246,11521]
decorators [11258,11533]
===
match
---
arglist [26268,26321]
arglist [26280,26333]
===
match
---
atom [37356,37937]
atom [37368,37949]
===
match
---
operator: , [21545,21546]
operator: , [21557,21558]
===
match
---
operator: @ [28082,28083]
operator: @ [28094,28095]
===
match
---
trailer [3537,3556]
trailer [3549,3568]
===
match
---
name: client [26228,26234]
name: client [26240,26246]
===
match
---
trailer [12227,12246]
trailer [12239,12258]
===
match
---
trailer [43421,43431]
trailer [43433,43443]
===
match
---
string: "other" [19036,19043]
string: "other" [19048,19055]
===
match
---
operator: { [31936,31937]
operator: { [31948,31949]
===
match
---
name: mount_point [40319,40330]
name: mount_point [40331,40342]
===
match
---
argument [4448,4475]
argument [4460,4487]
===
match
---
name: test_radius_port [21772,21788]
name: test_radius_port [21784,21800]
===
match
---
name: kv_engine_version [5547,5564]
name: kv_engine_version [5559,5576]
===
match
---
name: radius_port [42153,42164]
name: radius_port [42165,42176]
===
match
---
name: VaultError [14302,14312]
name: VaultError [14314,14324]
===
match
---
number: 2 [15246,15247]
number: 2 [15258,15259]
===
match
---
decorator [39687,39765]
decorator [39699,39777]
===
match
---
operator: , [31769,31770]
operator: , [31781,31782]
===
match
---
atom_expr [12147,12198]
atom_expr [12159,12210]
===
match
---
trailer [15990,16020]
trailer [16002,16032]
===
match
---
name: mock_hvac [28203,28212]
name: mock_hvac [28215,28224]
===
match
---
name: secrets [38871,38878]
name: secrets [38883,38890]
===
match
---
trailer [16964,16981]
trailer [16976,16993]
===
match
---
expr_stmt [22125,22153]
expr_stmt [22137,22165]
===
match
---
arglist [4537,4611]
arglist [4549,4623]
===
match
---
string: 'warnings' [29711,29721]
string: 'warnings' [29723,29733]
===
match
---
name: match [8222,8227]
name: match [8234,8239]
===
match
---
arglist [11089,11135]
arglist [11101,11147]
===
match
---
funcdef [14531,15282]
funcdef [14543,15294]
===
match
---
assert_stmt [23405,23447]
assert_stmt [23417,23459]
===
match
---
operator: , [11739,11740]
operator: , [11751,11752]
===
match
---
operator: = [1747,1748]
operator: = [1747,1748]
===
match
---
param [15389,15394]
param [15401,15406]
===
match
---
name: mount_point [5431,5442]
name: mount_point [5443,5454]
===
match
---
trailer [22772,22820]
trailer [22784,22832]
===
match
---
simple_stmt [10698,10763]
simple_stmt [10710,10775]
===
match
---
operator: = [26012,26013]
operator: = [26024,26025]
===
match
---
operator: , [38771,38772]
operator: , [38783,38784]
===
match
---
trailer [19725,19796]
trailer [19737,19808]
===
match
---
name: version [28054,28061]
name: version [28066,28073]
===
match
---
name: secret_path [38219,38230]
name: secret_path [38231,38242]
===
match
---
trailer [3450,3505]
trailer [3462,3517]
===
match
---
expr_stmt [22949,22979]
expr_stmt [22961,22991]
===
match
---
arglist [34367,34406]
arglist [34379,34418]
===
match
---
operator: = [13506,13507]
operator: = [13518,13519]
===
match
---
name: vault_client [33336,33348]
name: vault_client [33348,33360]
===
match
---
expr_stmt [26612,26655]
expr_stmt [26624,26667]
===
match
---
simple_stmt [4127,4158]
simple_stmt [4139,4170]
===
match
---
expr_stmt [6638,6681]
expr_stmt [6650,6693]
===
match
---
operator: , [30232,30233]
operator: , [30244,30245]
===
match
---
dotted_name [8582,8592]
dotted_name [8594,8604]
===
match
---
name: assert_called_once_with [38905,38928]
name: assert_called_once_with [38917,38940]
===
match
---
name: assert_called_with [26355,26373]
name: assert_called_with [26367,26385]
===
match
---
argument [32671,32691]
argument [32683,32703]
===
match
---
expr_stmt [35364,35497]
expr_stmt [35376,35509]
===
match
---
atom_expr [41967,41983]
atom_expr [41979,41995]
===
match
---
argument [2115,2134]
argument [2115,2134]
===
match
---
name: key_path [10884,10892]
name: key_path [10896,10904]
===
match
---
arglist [6210,6329]
arglist [6222,6341]
===
match
---
argument [12275,12304]
argument [12287,12316]
===
match
---
trailer [30014,30025]
trailer [30026,30037]
===
match
---
argument [5117,5130]
argument [5129,5142]
===
match
---
operator: , [21314,21315]
operator: , [21326,21327]
===
match
---
string: 'http://localhost:8180' [13811,13834]
string: 'http://localhost:8180' [13823,13846]
===
match
---
trailer [38884,38904]
trailer [38896,38916]
===
match
---
string: "pass" [21229,21235]
string: "pass" [21241,21247]
===
match
---
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [24151,24179]
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [24163,24191]
===
match
---
number: 1 [28632,28633]
number: 1 [28644,28645]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [32726,32790]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [32738,32802]
===
match
---
param [40535,40540]
param [40547,40552]
===
match
---
simple_stmt [43159,43249]
simple_stmt [43171,43261]
===
match
---
name: kv_engine_version [26409,26426]
name: kv_engine_version [26421,26438]
===
match
---
trailer [19230,19236]
trailer [19242,19248]
===
match
---
name: MagicMock [37222,37231]
name: MagicMock [37234,37243]
===
match
---
name: kv_engine_version [2819,2836]
name: kv_engine_version [2825,2842]
===
match
---
name: MagicMock [42735,42744]
name: MagicMock [42747,42756]
===
match
---
decorated [28082,28888]
decorated [28094,28900]
===
match
---
name: auth_type [24885,24894]
name: auth_type [24897,24906]
===
match
---
operator: , [17895,17896]
operator: , [17907,17908]
===
match
---
operator: = [23854,23855]
operator: = [23866,23867]
===
match
---
name: radius_secret [19746,19759]
name: radius_secret [19758,19771]
===
match
---
trailer [12808,12821]
trailer [12820,12833]
===
match
---
operator: = [25913,25914]
operator: = [25925,25926]
===
match
---
name: client [3324,3330]
name: client [3330,3336]
===
match
---
name: _VaultClient [1056,1068]
name: _VaultClient [1056,1068]
===
match
---
simple_stmt [24439,24470]
simple_stmt [24451,24482]
===
match
---
atom_expr [4384,4403]
atom_expr [4396,4415]
===
match
---
name: Client [6648,6654]
name: Client [6660,6666]
===
match
---
atom_expr [15831,15867]
atom_expr [15843,15879]
===
match
---
atom_expr [34644,34703]
atom_expr [34656,34715]
===
match
---
operator: = [17212,17213]
operator: = [17224,17225]
===
match
---
operator: , [14170,14171]
operator: , [14182,14183]
===
match
---
name: path [28872,28876]
name: path [28884,28888]
===
match
---
expr_stmt [25363,25391]
expr_stmt [25375,25403]
===
match
---
name: gcp_scopes [10536,10546]
name: gcp_scopes [10548,10558]
===
match
---
simple_stmt [7605,7649]
simple_stmt [7617,7661]
===
match
---
string: 'request_id' [34720,34732]
string: 'request_id' [34732,34744]
===
match
---
operator: , [31350,31351]
operator: , [31362,31363]
===
match
---
name: patch [37059,37064]
name: patch [37071,37076]
===
match
---
name: Client [13781,13787]
name: Client [13793,13799]
===
match
---
name: url [26071,26074]
name: url [26083,26086]
===
match
---
argument [21148,21166]
argument [21160,21178]
===
match
---
number: 8110 [41436,41440]
number: 8110 [41448,41452]
===
match
---
operator: = [35414,35415]
operator: = [35426,35427]
===
match
---
import_from [840,874]
import_from [840,874]
===
match
---
trailer [1265,1275]
trailer [1265,1275]
===
match
---
trailer [16723,16730]
trailer [16735,16742]
===
match
---
trailer [15042,15049]
trailer [15054,15061]
===
match
---
simple_stmt [11608,11639]
simple_stmt [11620,11651]
===
match
---
name: self [25103,25107]
name: self [25115,25119]
===
match
---
simple_stmt [5522,5565]
simple_stmt [5534,5577]
===
match
---
operator: = [22698,22699]
operator: = [22710,22711]
===
match
---
trailer [2764,2783]
trailer [2770,2789]
===
match
---
name: vault_client [33635,33647]
name: vault_client [33647,33659]
===
match
---
operator: = [39263,39264]
operator: = [39275,39276]
===
match
---
number: 0 [34864,34865]
number: 0 [34876,34877]
===
match
---
trailer [40305,40404]
trailer [40317,40416]
===
match
---
name: assert_called_with [18573,18591]
name: assert_called_with [18585,18603]
===
match
---
name: assert_called_once_with [30159,30182]
name: assert_called_once_with [30171,30194]
===
match
---
atom_expr [17637,17653]
atom_expr [17649,17665]
===
match
---
simple_stmt [2012,2056]
simple_stmt [2012,2056]
===
match
---
argument [10498,10522]
argument [10510,10534]
===
match
---
decorator [11335,11439]
decorator [11347,11451]
===
match
---
name: client [24631,24637]
name: client [24643,24649]
===
match
---
trailer [19989,19996]
trailer [20001,20008]
===
match
---
name: auth_type [40694,40703]
name: auth_type [40706,40715]
===
match
---
operator: = [3166,3167]
operator: = [3172,3173]
===
match
---
argument [26860,26894]
argument [26872,26906]
===
match
---
argument [41592,41615]
argument [41604,41627]
===
match
---
operator: , [18522,18523]
operator: , [18534,18535]
===
match
---
atom_expr [2156,2186]
atom_expr [2156,2186]
===
match
---
decorated [37053,39003]
decorated [37065,39015]
===
match
---
arglist [14832,14876]
arglist [14844,14888]
===
match
---
trailer [26789,26791]
trailer [26801,26803]
===
match
---
name: mock [40411,40415]
name: mock [40423,40427]
===
match
---
name: client [13953,13959]
name: client [13965,13971]
===
match
---
simple_stmt [21371,21436]
simple_stmt [21383,21448]
===
match
---
operator: = [16389,16390]
operator: = [16401,16402]
===
match
---
operator: , [43619,43620]
operator: , [43631,43632]
===
match
---
operator: , [8318,8319]
operator: , [8330,8331]
===
match
---
name: patch [39693,39698]
name: patch [39705,39710]
===
match
---
assert_stmt [9771,9813]
assert_stmt [9783,9825]
===
match
---
suite [22747,22821]
suite [22759,22833]
===
match
---
decorator [1483,1561]
decorator [1483,1561]
===
match
---
name: url [13060,13063]
name: url [13072,13075]
===
match
---
string: "pass" [41468,41474]
string: "pass" [41480,41486]
===
match
---
operator: = [18431,18432]
operator: = [18443,18444]
===
match
---
name: assert_called_with [19158,19176]
name: assert_called_with [19170,19188]
===
match
---
name: hashicorp [1009,1018]
name: hashicorp [1009,1018]
===
match
---
name: mount_point [26302,26313]
name: mount_point [26314,26325]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [34947,34976]
string: '2020-03-16T21:01:43.331126Z' [34959,34988]
===
match
---
argument [36909,36977]
argument [36921,36989]
===
match
---
argument [41617,41623]
argument [41629,41635]
===
match
---
funcdef [3697,3997]
funcdef [3709,4009]
===
match
---
operator: } [29763,29764]
operator: } [29775,29776]
===
match
---
suite [37194,39003]
suite [37206,39015]
===
match
---
operator: @ [25003,25004]
operator: @ [25015,25016]
===
match
---
string: 'scope2' [12324,12332]
string: 'scope2' [12336,12344]
===
match
---
name: client [13844,13850]
name: client [13856,13862]
===
match
---
atom_expr [24216,24246]
atom_expr [24228,24258]
===
match
---
simple_stmt [13097,13177]
simple_stmt [13109,13189]
===
match
---
trailer [32631,32634]
trailer [32643,32646]
===
match
---
simple_stmt [15506,15703]
simple_stmt [15518,15715]
===
match
---
trailer [23390,23396]
trailer [23402,23408]
===
match
---
trailer [41010,41070]
trailer [41022,41082]
===
match
---
dictorsetmaker [35602,36227]
dictorsetmaker [35614,36239]
===
match
---
trailer [27055,27058]
trailer [27067,27070]
===
match
---
operator: { [42523,42524]
operator: { [42535,42536]
===
match
---
string: '' [38630,38632]
string: '' [38642,38644]
===
match
---
simple_stmt [15876,15941]
simple_stmt [15888,15953]
===
match
---
operator: = [43244,43245]
operator: = [43256,43257]
===
match
---
funcdef [36476,37048]
funcdef [36488,37060]
===
match
---
name: auth_type [7766,7775]
name: auth_type [7778,7787]
===
match
---
argument [21547,21566]
argument [21559,21578]
===
match
---
operator: @ [40410,40411]
operator: @ [40422,40423]
===
match
---
param [18099,18104]
param [18111,18116]
===
match
---
trailer [34293,34329]
trailer [34305,34341]
===
match
---
simple_stmt [13024,13089]
simple_stmt [13036,13101]
===
match
---
atom_expr [21921,22116]
atom_expr [21933,22128]
===
match
---
operator: , [42139,42140]
operator: , [42151,42152]
===
match
---
trailer [12469,12519]
trailer [12481,12531]
===
match
---
operator: = [43684,43685]
operator: = [43696,43697]
===
match
---
argument [31629,31638]
argument [31641,31650]
===
match
---
trailer [24494,24507]
trailer [24506,24519]
===
match
---
trailer [13103,13108]
trailer [13115,13120]
===
match
---
name: secret [33719,33725]
name: secret [33731,33737]
===
match
---
name: client [23182,23188]
name: client [23194,23200]
===
match
---
simple_stmt [7021,7086]
simple_stmt [7033,7098]
===
match
---
simple_stmt [31452,31500]
simple_stmt [31464,31512]
===
match
---
operator: , [38801,38802]
operator: , [38813,38814]
===
match
---
name: auth_type [4259,4268]
name: auth_type [4271,4280]
===
match
---
name: vault_client [35517,35529]
name: vault_client [35529,35541]
===
match
---
atom_expr [1343,1409]
atom_expr [1343,1409]
===
match
---
name: patch [11341,11346]
name: patch [11353,11358]
===
match
---
name: kv_engine_version [3592,3609]
name: kv_engine_version [3604,3621]
===
match
---
parameters [15388,15405]
parameters [15400,15417]
===
match
---
name: test_gcp [8775,8783]
name: test_gcp [8787,8795]
===
match
---
name: read_data [14859,14868]
name: read_data [14871,14880]
===
match
---
atom_expr [14849,14876]
atom_expr [14861,14888]
===
match
---
param [22923,22928]
param [22935,22940]
===
match
---
trailer [28813,28825]
trailer [28825,28837]
===
match
---
simple_stmt [19372,19415]
simple_stmt [19384,19427]
===
match
---
argument [31224,31245]
argument [31236,31257]
===
match
---
operator: = [42485,42486]
operator: = [42497,42498]
===
match
---
name: test_token [22912,22922]
name: test_token [22924,22934]
===
match
---
trailer [22967,22977]
trailer [22979,22989]
===
match
---
trailer [21064,21071]
trailer [21076,21083]
===
match
---
trailer [15748,15766]
trailer [15760,15778]
===
match
---
name: assert_called_with [16749,16767]
name: assert_called_with [16761,16779]
===
match
---
trailer [32896,32906]
trailer [32908,32918]
===
match
---
operator: = [11127,11128]
operator: = [11139,11140]
===
match
---
operator: @ [5570,5571]
operator: @ [5582,5583]
===
match
---
name: MagicMock [18144,18153]
name: MagicMock [18156,18165]
===
match
---
name: token [24190,24195]
name: token [24202,24207]
===
match
---
name: port [21536,21540]
name: port [21548,21552]
===
match
---
name: auth [11051,11055]
name: auth [11063,11067]
===
match
---
argument [39291,39309]
argument [39303,39321]
===
match
---
param [8074,8079]
param [8086,8091]
===
match
---
operator: , [43554,43555]
operator: , [43566,43567]
===
match
---
operator: = [17393,17394]
operator: = [17405,17406]
===
match
---
trailer [22197,22226]
trailer [22209,22238]
===
match
---
operator: , [3214,3215]
operator: , [3220,3221]
===
match
---
name: radius_host [43568,43579]
name: radius_host [43580,43591]
===
match
---
string: "secret" [24961,24969]
string: "secret" [24973,24981]
===
match
---
name: radius_host [28515,28526]
name: radius_host [28527,28538]
===
match
---
string: '' [38349,38351]
string: '' [38361,38363]
===
match
---
name: vault_client [24274,24286]
name: vault_client [24286,24298]
===
match
---
argument [34236,34255]
argument [34248,34267]
===
match
---
trailer [8897,8904]
trailer [8909,8916]
===
match
---
name: client [9718,9724]
name: client [9730,9736]
===
match
---
trailer [27912,27924]
trailer [27924,27936]
===
match
---
simple_stmt [23456,23500]
simple_stmt [23468,23512]
===
match
---
trailer [24747,24764]
trailer [24759,24776]
===
match
---
name: v2 [27956,27958]
name: v2 [27968,27970]
===
match
---
name: mock_client [25200,25211]
name: mock_client [25212,25223]
===
match
---
argument [38054,38070]
argument [38066,38082]
===
match
---
name: client [15949,15955]
name: client [15961,15967]
===
match
---
argument [28727,28748]
argument [28739,28760]
===
match
---
name: client [2741,2747]
name: client [2747,2753]
===
match
---
name: raises [3856,3862]
name: raises [3868,3874]
===
match
---
operator: , [38962,38963]
operator: , [38974,38975]
===
match
---
argument [7189,7208]
argument [7201,7220]
===
match
---
trailer [26743,26763]
trailer [26755,26775]
===
match
---
simple_stmt [6150,6340]
simple_stmt [6162,6352]
===
match
---
name: path [36364,36368]
name: path [36376,36380]
===
match
---
operator: @ [13286,13287]
operator: @ [13298,13299]
===
match
---
atom_expr [15454,15483]
atom_expr [15466,15495]
===
match
---
argument [3950,3977]
argument [3962,3989]
===
match
---
operator: , [33816,33817]
operator: , [33828,33829]
===
match
---
trailer [12551,12570]
trailer [12563,12582]
===
match
---
string: 'version' [36180,36189]
string: 'version' [36192,36201]
===
match
---
param [19915,19920]
param [19927,19932]
===
match
---
operator: = [35463,35464]
operator: = [35475,35476]
===
match
---
operator: = [42892,42893]
operator: = [42904,42905]
===
match
---
expr_stmt [12987,13015]
expr_stmt [12999,13027]
===
match
---
argument [26191,26218]
argument [26203,26230]
===
match
---
funcdef [7508,7954]
funcdef [7520,7966]
===
match
---
assert_stmt [4683,4725]
assert_stmt [4695,4737]
===
match
---
expr_stmt [21016,21046]
expr_stmt [21028,21058]
===
match
---
atom_expr [27933,28076]
atom_expr [27945,28088]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [41088,41152]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [41100,41164]
===
match
---
operator: , [43214,43215]
operator: , [43226,43227]
===
match
---
atom_expr [26155,26219]
atom_expr [26167,26231]
===
match
---
name: role [5418,5422]
name: role [5430,5434]
===
match
---
assert_stmt [24854,24894]
assert_stmt [24866,24906]
===
match
---
operator: = [9489,9490]
operator: = [9501,9502]
===
match
---
name: _VaultClient [4989,5001]
name: _VaultClient [5001,5013]
===
match
---
name: client [6348,6354]
name: client [6360,6366]
===
match
---
arglist [32671,32707]
arglist [32683,32719]
===
match
---
operator: , [19766,19767]
operator: , [19778,19779]
===
match
---
suite [17614,17998]
suite [17626,18010]
===
match
---
operator: = [41022,41023]
operator: = [41034,41035]
===
match
---
trailer [38878,38881]
trailer [38890,38893]
===
match
---
name: raises [17726,17732]
name: raises [17738,17744]
===
match
---
name: MagicMock [5712,5721]
name: MagicMock [5724,5733]
===
match
---
expr_stmt [19980,20023]
expr_stmt [19992,20035]
===
match
---
name: mock_get_credentials [9000,9020]
name: mock_get_credentials [9012,9032]
===
match
---
trailer [36889,36896]
trailer [36901,36908]
===
match
---
name: mock [22963,22967]
name: mock [22975,22979]
===
match
---
trailer [26963,26974]
trailer [26975,26986]
===
match
---
operator: = [5871,5872]
operator: = [5883,5884]
===
match
---
name: secret_version [34390,34404]
name: secret_version [34402,34416]
===
match
---
operator: = [29858,29859]
operator: = [29870,29871]
===
match
---
param [36514,36523]
param [36526,36535]
===
match
---
name: auth_type [17828,17837]
name: auth_type [17840,17849]
===
match
---
name: v2 [36281,36283]
name: v2 [36293,36295]
===
match
---
operator: = [43646,43647]
operator: = [43658,43659]
===
match
---
name: Client [5265,5271]
name: Client [5277,5283]
===
match
---
operator: } [35354,35355]
operator: } [35366,35367]
===
match
---
argument [35460,35487]
argument [35472,35499]
===
match
---
name: self [1593,1597]
name: self [1593,1597]
===
match
---
operator: , [5671,5672]
operator: , [5683,5684]
===
match
---
operator: = [34311,34312]
operator: = [34323,34324]
===
match
---
atom_expr [22398,22428]
atom_expr [22410,22440]
===
match
---
operator: , [33606,33607]
operator: , [33618,33619]
===
match
---
name: _VaultClient [7736,7748]
name: _VaultClient [7748,7760]
===
match
---
simple_stmt [19141,19206]
simple_stmt [19153,19218]
===
match
---
name: return_value [18181,18193]
name: return_value [18193,18205]
===
match
---
argument [20714,20728]
argument [20726,20740]
===
match
---
operator: , [24417,24418]
operator: , [24429,24430]
===
match
---
string: 'pass' [7932,7938]
string: 'pass' [7944,7950]
===
match
---
string: 'version' [29620,29629]
string: 'version' [29632,29641]
===
match
---
expr_stmt [8940,8991]
expr_stmt [8952,9003]
===
match
---
trailer [4491,4504]
trailer [4503,4516]
===
match
---
name: is_authenticated [11152,11168]
name: is_authenticated [11164,11180]
===
match
---
trailer [21608,21627]
trailer [21620,21639]
===
match
---
suite [18790,19415]
suite [18802,19427]
===
match
---
operator: = [16920,16921]
operator: = [16932,16933]
===
match
---
atom_expr [8888,8917]
atom_expr [8900,8929]
===
match
---
param [32858,32867]
param [32870,32879]
===
match
---
operator: = [32508,32509]
operator: = [32520,32521]
===
match
---
simple_stmt [12987,13016]
simple_stmt [12999,13028]
===
match
---
operator: , [32691,32692]
operator: , [32703,32704]
===
match
---
operator: , [27662,27663]
operator: , [27674,27675]
===
match
---
atom [32572,32590]
atom [32584,32602]
===
match
---
trailer [22282,22324]
trailer [22294,22336]
===
match
---
operator: = [34125,34126]
operator: = [34137,34138]
===
match
---
string: "role" [3167,3173]
string: "role" [3173,3179]
===
match
---
name: url [24054,24057]
name: url [24066,24069]
===
match
---
operator: , [16558,16559]
operator: , [16570,16571]
===
match
---
name: _VaultClient [42823,42835]
name: _VaultClient [42835,42847]
===
match
---
dotted_name [17060,17070]
dotted_name [17072,17082]
===
match
---
operator: , [15691,15692]
operator: , [15703,15704]
===
match
---
operator: = [7197,7198]
operator: = [7209,7210]
===
match
---
trailer [14618,14620]
trailer [14630,14632]
===
match
---
operator: , [30894,30895]
operator: , [30906,30907]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [28094,28158]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [28106,28170]
===
match
---
arglist [6731,6965]
arglist [6743,6977]
===
match
---
trailer [14247,14260]
trailer [14259,14272]
===
match
---
name: return_value [4183,4195]
name: return_value [4195,4207]
===
match
---
argument [9158,9184]
argument [9170,9196]
===
match
---
string: "radhost" [36711,36720]
string: "radhost" [36723,36732]
===
match
---
assert_stmt [24954,24997]
assert_stmt [24966,25009]
===
match
---
atom_expr [20666,20755]
atom_expr [20678,20767]
===
match
---
string: "missing" [38231,38240]
string: "missing" [38243,38252]
===
match
---
argument [21979,22000]
argument [21991,22012]
===
match
---
simple_stmt [27851,27873]
simple_stmt [27863,27885]
===
match
---
atom_expr [30446,30475]
atom_expr [30458,30487]
===
match
---
operator: { [41038,41039]
operator: { [41050,41051]
===
match
---
atom_expr [26396,26426]
atom_expr [26408,26438]
===
match
---
name: test_kubernetes_default_path [14535,14563]
name: test_kubernetes_default_path [14547,14575]
===
match
---
string: "pass" [33488,33494]
string: "pass" [33500,33506]
===
match
---
atom_expr [2587,2651]
atom_expr [2587,2651]
===
match
---
string: "role" [5056,5062]
string: "role" [5068,5074]
===
match
---
name: vault_client [20565,20577]
name: vault_client [20577,20589]
===
match
---
string: 'wrap_info' [38754,38765]
string: 'wrap_info' [38766,38777]
===
match
---
operator: , [28052,28053]
operator: , [28064,28065]
===
match
---
with_stmt [39502,39682]
with_stmt [39514,39694]
===
match
---
name: vault_client [12046,12058]
name: vault_client [12058,12070]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [21698,21762]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [21710,21774]
===
match
---
operator: , [41474,41475]
operator: , [41486,41487]
===
match
---
expr_stmt [2012,2055]
expr_stmt [2012,2055]
===
match
---
operator: = [33633,33634]
operator: = [33645,33646]
===
match
---
name: token [23391,23396]
name: token [23403,23408]
===
match
---
decorated [20189,20860]
decorated [20201,20872]
===
match
---
simple_stmt [23345,23397]
simple_stmt [23357,23409]
===
match
---
expr_stmt [39831,39861]
expr_stmt [39843,39873]
===
match
---
string: "http://localhost:8180" [7850,7873]
string: "http://localhost:8180" [7862,7885]
===
match
---
operator: = [3496,3497]
operator: = [3508,3509]
===
match
---
name: key_id [8424,8430]
name: key_id [8436,8442]
===
match
---
param [29010,29019]
param [29022,29031]
===
match
---
name: vault_client [39616,39628]
name: vault_client [39628,39640]
===
match
---
decorator [14449,14527]
decorator [14461,14539]
===
match
---
argument [11874,11889]
argument [11886,11901]
===
match
---
expr_stmt [30446,30489]
expr_stmt [30458,30501]
===
match
---
arglist [40179,40222]
arglist [40191,40234]
===
match
---
operator: = [16823,16824]
operator: = [16835,16836]
===
match
---
name: Client [23682,23688]
name: Client [23694,23700]
===
match
---
simple_stmt [26228,26323]
simple_stmt [26240,26335]
===
match
---
argument [33474,33494]
argument [33486,33506]
===
match
---
name: v2 [30522,30524]
name: v2 [30534,30536]
===
match
---
import_from [875,917]
import_from [875,917]
===
match
---
dictorsetmaker [32573,32589]
dictorsetmaker [32585,32601]
===
match
---
name: MagicMock [16304,16313]
name: MagicMock [16316,16325]
===
match
---
trailer [13485,13492]
trailer [13497,13504]
===
match
---
trailer [19605,19612]
trailer [19617,19624]
===
match
---
parameters [40534,40551]
parameters [40546,40563]
===
match
---
param [6579,6588]
param [6591,6600]
===
match
---
simple_stmt [10203,10234]
simple_stmt [10215,10246]
===
match
---
operator: , [14413,14414]
operator: , [14425,14426]
===
match
---
suite [39822,40405]
suite [39834,40417]
===
match
---
operator: , [34832,34833]
operator: , [34844,34845]
===
match
---
name: mock_hvac [23219,23228]
name: mock_hvac [23231,23240]
===
match
---
string: "azure" [7776,7783]
string: "azure" [7788,7795]
===
match
---
name: mock [41810,41814]
name: mock [41822,41826]
===
match
---
trailer [20841,20859]
trailer [20853,20871]
===
match
---
assert_stmt [18602,18644]
assert_stmt [18614,18656]
===
match
---
expr_stmt [10354,10419]
expr_stmt [10366,10431]
===
match
---
operator: = [43835,43836]
operator: = [43847,43848]
===
match
---
expr_stmt [19941,19971]
expr_stmt [19953,19983]
===
match
---
name: vault_client [2559,2571]
name: vault_client [2559,2571]
===
match
---
string: "http://localhost:8180" [29950,29973]
string: "http://localhost:8180" [29962,29985]
===
match
---
trailer [19361,19363]
trailer [19373,19375]
===
match
---
name: mock [17060,17064]
name: mock [17072,17076]
===
match
---
string: "azure" [6741,6748]
string: "azure" [6753,6760]
===
match
---
operator: , [30654,30655]
operator: , [30666,30667]
===
match
---
assert_stmt [23345,23396]
assert_stmt [23357,23408]
===
match
---
name: radius_secret [42946,42959]
name: radius_secret [42958,42971]
===
match
---
name: mock_get_credentials [9402,9422]
name: mock_get_credentials [9414,9434]
===
match
---
trailer [8118,8128]
trailer [8130,8140]
===
match
---
argument [16899,16915]
argument [16911,16927]
===
match
---
trailer [33007,33020]
trailer [33019,33032]
===
match
---
trailer [41279,41292]
trailer [41291,41304]
===
match
---
operator: = [41768,41769]
operator: = [41780,41781]
===
match
---
name: radius_host [32322,32333]
name: radius_host [32334,32345]
===
match
---
parameters [1946,1963]
parameters [1946,1963]
===
match
---
operator: == [24213,24215]
operator: == [24225,24227]
===
match
---
atom_expr [20419,20547]
atom_expr [20431,20559]
===
match
---
expr_stmt [43442,43485]
expr_stmt [43454,43497]
===
match
---
operator: = [17932,17933]
operator: = [17944,17945]
===
match
---
string: "Metadata might only be used with version 2 of the KV engine." [39539,39601]
string: "Metadata might only be used with version 2 of the KV engine." [39551,39613]
===
match
---
string: 'key' [40207,40212]
string: 'key' [40219,40224]
===
match
---
operator: = [31602,31603]
operator: = [31614,31615]
===
match
---
operator: , [36858,36859]
operator: , [36870,36871]
===
match
---
operator: , [38978,38979]
operator: , [38990,38991]
===
match
---
decorated [36394,37048]
decorated [36406,37060]
===
match
---
operator: = [26776,26777]
operator: = [26788,26789]
===
match
---
operator: { [12288,12289]
operator: { [12300,12301]
===
match
---
atom_expr [23647,23663]
atom_expr [23659,23675]
===
match
---
name: assert_called_with [11070,11088]
name: assert_called_with [11082,11100]
===
match
---
operator: = [40007,40008]
operator: = [40019,40020]
===
match
---
operator: = [1985,1986]
operator: = [1985,1986]
===
match
---
operator: = [40098,40099]
operator: = [40110,40111]
===
match
---
param [41204,41213]
param [41216,41225]
===
match
---
name: test_userpass [25089,25102]
name: test_userpass [25101,25114]
===
match
---
operator: = [8861,8862]
operator: = [8873,8874]
===
match
---
name: MagicMock [25828,25837]
name: MagicMock [25840,25849]
===
match
---
name: vault_client [16711,16723]
name: vault_client [16723,16735]
===
match
---
name: patch [28899,28904]
name: patch [28911,28916]
===
match
---
dictorsetmaker [43989,44003]
dictorsetmaker [44001,44015]
===
match
---
param [37177,37182]
param [37189,37194]
===
match
---
name: client [21334,21340]
name: client [21346,21352]
===
match
---
trailer [25416,25435]
trailer [25428,25447]
===
match
---
trailer [21450,21455]
trailer [21462,21467]
===
match
---
name: assert_called_with [22264,22282]
name: assert_called_with [22276,22294]
===
match
---
name: match [7688,7693]
name: match [7700,7705]
===
match
---
param [19921,19930]
param [19933,19942]
===
match
---
assert_stmt [31452,31499]
assert_stmt [31464,31511]
===
match
---
comparison [15246,15281]
comparison [15258,15293]
===
match
---
operator: , [16645,16646]
operator: , [16657,16658]
===
match
---
parameters [1220,1237]
parameters [1220,1237]
===
match
---
expr_stmt [39923,40133]
expr_stmt [39935,40145]
===
match
---
simple_stmt [20352,20396]
simple_stmt [20364,20408]
===
match
---
name: vault_client [16376,16388]
name: vault_client [16388,16400]
===
match
---
name: client [2550,2556]
name: client [2550,2556]
===
match
---
atom_expr [28420,28433]
atom_expr [28432,28445]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [17482,17546]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [17494,17558]
===
match
---
funcdef [30344,31649]
funcdef [30356,31661]
===
match
---
trailer [19959,19969]
trailer [19971,19981]
===
match
---
argument [42086,42104]
argument [42098,42116]
===
match
---
trailer [43863,43871]
trailer [43875,43883]
===
match
---
argument [5144,5160]
argument [5156,5172]
===
match
---
atom_expr [14696,14812]
atom_expr [14708,14824]
===
match
---
name: return_value [19613,19625]
name: return_value [19625,19637]
===
match
---
argument [15749,15765]
argument [15761,15777]
===
match
---
trailer [11187,11189]
trailer [11199,11201]
===
match
---
atom_expr [1261,1277]
atom_expr [1261,1277]
===
match
---
simple_stmt [23788,23833]
simple_stmt [23800,23845]
===
match
---
name: return_value [10259,10271]
name: return_value [10271,10283]
===
match
---
atom_expr [23856,23972]
atom_expr [23868,23984]
===
match
---
name: mock_hvac [9542,9551]
name: mock_hvac [9554,9563]
===
match
---
name: mock [21829,21833]
name: mock [21841,21845]
===
match
---
name: get_secret_including_metadata [39629,39658]
name: get_secret_including_metadata [39641,39670]
===
match
---
trailer [6627,6629]
trailer [6639,6641]
===
match
---
number: 10 [43245,43247]
number: 10 [43257,43259]
===
match
---
name: mock [1484,1488]
name: mock [1484,1488]
===
match
---
operator: = [41965,41966]
operator: = [41977,41978]
===
match
---
trailer [34663,34666]
trailer [34675,34678]
===
match
---
param [14570,14579]
param [14582,14591]
===
match
---
atom_expr [21444,21576]
atom_expr [21456,21588]
===
match
---
operator: = [27410,27411]
operator: = [27422,27423]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [25015,25079]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [25027,25091]
===
match
---
atom_expr [7021,7085]
atom_expr [7033,7097]
===
match
---
name: v2 [34667,34669]
name: v2 [34679,34681]
===
match
---
operator: , [2972,2973]
operator: , [2978,2979]
===
match
---
number: 8110 [43615,43619]
number: 8110 [43627,43631]
===
match
---
dotted_name [13287,13297]
dotted_name [13299,13309]
===
match
---
trailer [31577,31648]
trailer [31589,31660]
===
match
---
name: patch [1845,1850]
name: patch [1845,1850]
===
match
---
parameters [11542,11598]
parameters [11554,11610]
===
match
---
arglist [23734,23761]
arglist [23746,23773]
===
match
---
operator: = [21228,21229]
operator: = [21240,21241]
===
match
---
name: Client [4176,4182]
name: Client [4188,4194]
===
match
---
operator: = [5422,5423]
operator: = [5434,5435]
===
match
---
name: url [11007,11010]
name: url [11019,11022]
===
match
---
operator: = [22640,22641]
operator: = [22652,22653]
===
match
---
param [24419,24428]
param [24431,24440]
===
match
---
string: 'wrap_info' [32155,32166]
string: 'wrap_info' [32167,32178]
===
match
---
atom_expr [5534,5564]
atom_expr [5546,5576]
===
match
---
operator: , [21519,21520]
operator: , [21531,21532]
===
match
---
argument [10734,10761]
argument [10746,10773]
===
match
---
name: mount_point [3485,3496]
name: mount_point [3497,3508]
===
match
---
operator: = [18283,18284]
operator: = [18295,18296]
===
match
---
name: Client [15043,15049]
name: Client [15055,15061]
===
match
---
operator: , [20486,20487]
operator: , [20498,20499]
===
match
---
operator: , [40747,40748]
operator: , [40759,40760]
===
match
---
operator: = [43795,43796]
operator: = [43807,43808]
===
match
---
argument [41762,41785]
argument [41774,41797]
===
match
---
string: 'http://localhost:8180' [2627,2650]
string: 'http://localhost:8180' [2627,2650]
===
match
---
operator: , [37690,37691]
operator: , [37702,37703]
===
match
---
name: mock_hvac [21371,21380]
name: mock_hvac [21383,21392]
===
match
---
string: "gcp" [9125,9130]
string: "gcp" [9137,9142]
===
match
---
operator: = [5442,5443]
operator: = [5454,5455]
===
match
---
expr_stmt [37295,37937]
expr_stmt [37307,37949]
===
match
---
operator: = [43016,43017]
operator: = [43028,43029]
===
match
---
arglist [39521,39601]
arglist [39533,39613]
===
match
---
simple_stmt [23182,23211]
simple_stmt [23194,23223]
===
match
---
simple_stmt [933,985]
simple_stmt [933,985]
===
match
---
decorated [41809,42563]
decorated [41821,42575]
===
match
---
trailer [17678,17691]
trailer [17690,17703]
===
match
---
name: self [43377,43381]
name: self [43389,43393]
===
match
---
name: test_kubernetes_missing_role [17145,17173]
name: test_kubernetes_missing_role [17157,17185]
===
match
---
name: patch [27191,27196]
name: patch [27203,27208]
===
match
---
operator: { [32572,32573]
operator: { [32584,32585]
===
match
---
name: match [14314,14319]
name: match [14326,14331]
===
match
---
operator: = [29949,29950]
operator: = [29961,29962]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [19814,19878]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [19826,19890]
===
match
---
name: mock_open [901,910]
name: mock_open [901,910]
===
match
---
argument [17384,17406]
argument [17396,17418]
===
match
---
name: mock_hvac [25109,25118]
name: mock_hvac [25121,25130]
===
match
---
name: patch [24310,24315]
name: patch [24322,24327]
===
match
---
param [21795,21804]
param [21807,21816]
===
match
---
atom_expr [13097,13176]
atom_expr [13109,13188]
===
match
---
decorated [21686,22429]
decorated [21698,22441]
===
match
---
decorator [28893,28971]
decorator [28905,28983]
===
match
---
string: 'value' [32573,32580]
string: 'value' [32585,32592]
===
match
---
arglist [14395,14442]
arglist [14407,14454]
===
match
---
name: radius_secret [42183,42196]
name: radius_secret [42195,42208]
===
match
---
funcdef [16212,17054]
funcdef [16224,17066]
===
match
---
name: cas [41617,41620]
name: cas [41629,41632]
===
match
---
operator: = [3938,3939]
operator: = [3950,3951]
===
match
---
name: mock_hvac [27380,27389]
name: mock_hvac [27392,27401]
===
match
---
operator: = [35429,35430]
operator: = [35441,35442]
===
match
---
string: 'path' [42508,42514]
string: 'path' [42520,42526]
===
match
---
name: password [25530,25538]
name: password [25542,25550]
===
match
---
operator: , [42999,43000]
operator: , [43011,43012]
===
match
---
funcdef [1198,1478]
funcdef [1198,1478]
===
match
---
name: mock_client [21016,21027]
name: mock_client [21028,21039]
===
match
---
argument [36831,36858]
argument [36843,36870]
===
match
---
name: return_value [25185,25197]
name: return_value [25197,25209]
===
match
---
operator: , [31424,31425]
operator: , [31436,31437]
===
match
---
operator: = [9087,9088]
operator: = [9099,9100]
===
match
---
trailer [1295,1302]
trailer [1295,1302]
===
match
---
trailer [13887,13944]
trailer [13899,13956]
===
match
---
operator: = [42095,42096]
operator: = [42107,42108]
===
match
---
argument [5174,5198]
argument [5186,5210]
===
match
---
trailer [32620,32628]
trailer [32632,32640]
===
match
---
string: "radius" [29825,29833]
string: "radius" [29837,29845]
===
match
---
simple_stmt [41224,41255]
simple_stmt [41236,41267]
===
match
---
operator: , [8788,8789]
operator: , [8800,8801]
===
match
---
name: return_value [8905,8917]
name: return_value [8917,8929]
===
match
---
trailer [25597,25599]
trailer [25609,25611]
===
match
---
atom_expr [29069,29098]
atom_expr [29081,29110]
===
match
---
name: return_value [10375,10387]
name: return_value [10387,10399]
===
match
---
argument [7154,7175]
argument [7166,7187]
===
match
---
funcdef [22908,23500]
funcdef [22920,23512]
===
match
---
name: vault_client [42045,42057]
name: vault_client [42057,42069]
===
match
---
trailer [34581,34583]
trailer [34593,34595]
===
match
---
name: return_value [29086,29098]
name: return_value [29098,29110]
===
match
---
param [41198,41203]
param [41210,41215]
===
match
---
arglist [9115,9213]
arglist [9127,9225]
===
match
---
name: radius_host [33409,33420]
name: radius_host [33421,33432]
===
match
---
simple_stmt [32878,32909]
simple_stmt [32890,32921]
===
match
---
operator: @ [34413,34414]
operator: @ [34425,34426]
===
match
---
operator: = [3006,3007]
operator: = [3012,3013]
===
match
---
name: mock_client [4127,4138]
name: mock_client [4139,4150]
===
match
---
operator: , [31275,31276]
operator: , [31287,31288]
===
match
---
name: MagicMock [6618,6627]
name: MagicMock [6630,6639]
===
match
---
string: 'secret_key' [29391,29403]
string: 'secret_key' [29403,29415]
===
match
---
name: secret_path [43784,43795]
name: secret_path [43796,43807]
===
match
---
expr_stmt [42045,42288]
expr_stmt [42057,42300]
===
match
---
operator: } [30796,30797]
operator: } [30808,30809]
===
match
---
trailer [24703,24732]
trailer [24715,24744]
===
match
---
trailer [4421,4428]
trailer [4433,4440]
===
match
---
operator: , [13676,13677]
operator: , [13688,13689]
===
match
---
string: "radius" [39301,39309]
string: "radius" [39313,39321]
===
match
---
name: mock_hvac [12792,12801]
name: mock_hvac [12804,12813]
===
match
---
dotted_name [28083,28093]
dotted_name [28095,28105]
===
match
---
dotted_name [20190,20200]
dotted_name [20202,20212]
===
match
---
atom [10325,10345]
atom [10337,10357]
===
match
---
string: "other" [26314,26321]
string: "other" [26326,26333]
===
match
---
string: 'http://localhost:8180' [9582,9605]
string: 'http://localhost:8180' [9594,9617]
===
match
---
operator: = [11100,11101]
operator: = [11112,11113]
===
match
---
name: radius_secret [43633,43646]
name: radius_secret [43645,43658]
===
match
---
trailer [25827,25837]
trailer [25839,25849]
===
match
---
operator: { [37623,37624]
operator: { [37635,37636]
===
match
---
argument [14722,14744]
argument [14734,14756]
===
match
---
simple_stmt [28758,28780]
simple_stmt [28770,28792]
===
match
---
trailer [24133,24135]
trailer [24145,24147]
===
match
---
arglist [19726,19795]
arglist [19738,19807]
===
match
---
name: mock [4141,4145]
name: mock [4153,4157]
===
match
---
atom_expr [10242,10271]
atom_expr [10254,10283]
===
match
---
expr_stmt [36534,36564]
expr_stmt [36546,36576]
===
match
---
name: auth_type [17384,17393]
name: auth_type [17396,17405]
===
match
---
operator: = [27743,27744]
operator: = [27755,27756]
===
match
---
trailer [21833,21843]
trailer [21845,21855]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [30274,30338]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [30286,30350]
===
match
---
suite [14891,14933]
suite [14903,14945]
===
match
---
operator: = [27719,27720]
operator: = [27731,27732]
===
match
---
operator: , [6896,6897]
operator: , [6908,6909]
===
match
---
name: Client [1668,1674]
name: Client [1668,1674]
===
match
---
trailer [18572,18591]
trailer [18584,18603]
===
match
---
operator: @ [14449,14450]
operator: @ [14461,14462]
===
match
---
name: _VaultClient [14696,14708]
name: _VaultClient [14708,14720]
===
match
---
string: 'warnings' [38785,38795]
string: 'warnings' [38797,38807]
===
match
---
operator: = [31803,31804]
operator: = [31815,31816]
===
match
---
string: "other" [11128,11135]
string: "other" [11140,11147]
===
match
---
argument [9115,9130]
argument [9127,9142]
===
match
---
name: mock [12767,12771]
name: mock [12779,12783]
===
match
---
funcdef [20947,21681]
funcdef [20959,21693]
===
match
---
dotted_name [25657,25667]
dotted_name [25669,25679]
===
match
---
name: mock_client [14263,14274]
name: mock_client [14275,14286]
===
match
---
simple_stmt [40232,40405]
simple_stmt [40244,40417]
===
match
---
atom_expr [30499,30557]
atom_expr [30511,30569]
===
match
---
argument [18990,19005]
argument [19002,19017]
===
match
---
trailer [8904,8917]
trailer [8916,8929]
===
match
---
operator: = [1631,1632]
operator: = [1631,1632]
===
match
---
operator: @ [39687,39688]
operator: @ [39699,39700]
===
match
---
arglist [22681,22745]
arglist [22693,22757]
===
match
---
expr_stmt [15794,15822]
expr_stmt [15806,15834]
===
match
---
trailer [17248,17255]
trailer [17260,17267]
===
match
---
string: "radhost" [20719,20728]
string: "radhost" [20731,20740]
===
match
---
name: secret_id [2515,2524]
name: secret_id [2515,2524]
===
match
---
name: port [22314,22318]
name: port [22326,22330]
===
match
---
expr_stmt [32878,32908]
expr_stmt [32890,32920]
===
match
---
operator: @ [3615,3616]
operator: @ [3627,3628]
===
match
---
string: "http://localhost:8180" [41492,41515]
string: "http://localhost:8180" [41504,41527]
===
match
---
name: mock_hvac [17603,17612]
name: mock_hvac [17615,17624]
===
match
---
with_stmt [14283,14444]
with_stmt [14295,14456]
===
match
---
operator: = [39334,39335]
operator: = [39346,39347]
===
match
---
string: "airflow.providers.google.cloud.utils.credentials_provider._get_scopes" [8504,8575]
string: "airflow.providers.google.cloud.utils.credentials_provider._get_scopes" [8516,8587]
===
match
---
name: _VaultClient [8271,8283]
name: _VaultClient [8283,8295]
===
match
---
argument [40031,40047]
argument [40043,40059]
===
match
---
name: token [24558,24563]
name: token [24570,24575]
===
match
---
atom_expr [24973,24997]
atom_expr [24985,25009]
===
match
---
operator: , [5429,5430]
operator: , [5441,5442]
===
match
---
name: is_authenticated [5476,5492]
name: is_authenticated [5488,5504]
===
match
---
name: return_value [24495,24507]
name: return_value [24507,24519]
===
match
---
operator: = [6740,6741]
operator: = [6752,6753]
===
match
---
name: return_value [26629,26641]
name: return_value [26641,26653]
===
match
---
name: test_get_existing_key_v1_version [33925,33957]
name: test_get_existing_key_v1_version [33937,33969]
===
match
---
decorator [5570,5648]
decorator [5582,5660]
===
match
---
name: pytest [8196,8202]
name: pytest [8208,8214]
===
match
---
name: key_id [4325,4331]
name: key_id [4337,4343]
===
match
---
name: kubernetes_role [16453,16468]
name: kubernetes_role [16465,16480]
===
match
---
arglist [5825,6021]
arglist [5837,6033]
===
match
---
operator: = [32545,32546]
operator: = [32557,32558]
===
match
---
name: radius_host [20465,20476]
name: radius_host [20477,20488]
===
match
---
name: patch [10022,10027]
name: patch [10034,10039]
===
match
---
operator: , [10941,10942]
operator: , [10953,10954]
===
match
---
argument [20132,20153]
argument [20144,20165]
===
match
---
string: "post" [41063,41069]
string: "post" [41075,41081]
===
match
---
atom_expr [22235,22324]
atom_expr [22247,22336]
===
match
---
argument [40179,40197]
argument [40191,40209]
===
match
---
name: return_value [30545,30557]
name: return_value [30557,30569]
===
match
---
expr_stmt [10428,10652]
expr_stmt [10440,10664]
===
match
---
decorator [4731,4809]
decorator [4743,4821]
===
match
---
trailer [22977,22979]
trailer [22989,22991]
===
match
---
simple_stmt [41633,41804]
simple_stmt [41645,41816]
===
match
---
name: mount_point [28850,28861]
name: mount_point [28862,28873]
===
match
---
operator: = [20417,20418]
operator: = [20429,20430]
===
match
---
decorator [32714,32792]
decorator [32726,32804]
===
match
---
trailer [18917,19095]
trailer [18929,19107]
===
match
---
trailer [17255,17268]
trailer [17267,17280]
===
match
---
trailer [18591,18593]
trailer [18603,18605]
===
match
---
name: mock_client [43403,43414]
name: mock_client [43415,43426]
===
match
---
simple_stmt [30446,30490]
simple_stmt [30458,30502]
===
match
---
atom_expr [31830,31859]
atom_expr [31842,31871]
===
match
---
simple_stmt [35581,36250]
simple_stmt [35593,36262]
===
match
---
atom_expr [12593,12623]
atom_expr [12605,12635]
===
match
---
trailer [2679,2698]
trailer [2685,2704]
===
match
---
trailer [41655,41658]
trailer [41667,41670]
===
match
---
name: kv [28388,28390]
name: kv [28400,28402]
===
match
---
operator: , [37771,37772]
operator: , [37783,37784]
===
match
---
name: read_secret [28814,28825]
name: read_secret [28826,28837]
===
match
---
assert_stmt [28758,28779]
assert_stmt [28770,28791]
===
match
---
simple_stmt [5469,5514]
simple_stmt [5481,5526]
===
match
---
trailer [22599,22601]
trailer [22611,22613]
===
match
---
string: "radius_host" [19685,19698]
string: "radius_host" [19697,19710]
===
match
---
argument [23136,23163]
argument [23148,23175]
===
match
---
atom_expr [19653,19699]
atom_expr [19665,19711]
===
match
---
operator: = [20068,20069]
operator: = [20080,20081]
===
match
---
name: mock_client [17623,17634]
name: mock_client [17635,17646]
===
match
---
trailer [37258,37271]
trailer [37270,37283]
===
match
---
simple_stmt [42755,42799]
simple_stmt [42767,42811]
===
match
---
name: mock_client [4198,4209]
name: mock_client [4210,4221]
===
match
---
trailer [34002,34012]
trailer [34014,34024]
===
match
---
string: "kube_role" [16469,16480]
string: "kube_role" [16481,16492]
===
match
---
trailer [9253,9260]
trailer [9265,9272]
===
match
---
name: secret_path [28727,28738]
name: secret_path [28739,28750]
===
match
---
decorators [9819,10094]
decorators [9831,10106]
===
match
---
trailer [16340,16353]
trailer [16352,16365]
===
match
---
simple_stmt [19980,20024]
simple_stmt [19992,20036]
===
match
---
name: VaultError [39521,39531]
name: VaultError [39533,39543]
===
match
---
name: Client [22620,22626]
name: Client [22632,22638]
===
match
---
string: 'wrap_info' [31057,31068]
string: 'wrap_info' [31069,31080]
===
match
---
operator: = [37354,37355]
operator: = [37366,37367]
===
match
---
assert_stmt [27006,27027]
assert_stmt [27018,27039]
===
match
---
name: client [14926,14932]
name: client [14938,14944]
===
match
---
name: test_radius_different_auth_mount_point [20951,20989]
name: test_radius_different_auth_mount_point [20963,21001]
===
match
---
simple_stmt [9402,9534]
simple_stmt [9414,9546]
===
match
---
funcdef [19502,19797]
funcdef [19514,19809]
===
match
---
name: mock [12630,12634]
name: mock [12642,12646]
===
match
---
param [39132,39137]
param [39144,39149]
===
match
---
dictorsetmaker [29197,29754]
dictorsetmaker [29209,29766]
===
match
---
simple_stmt [10242,10286]
simple_stmt [10254,10298]
===
match
---
simple_stmt [15454,15498]
simple_stmt [15466,15510]
===
match
---
atom_expr [37961,38156]
atom_expr [37973,38168]
===
match
---
arglist [37987,38146]
arglist [37999,38158]
===
match
---
string: "user" [18970,18976]
string: "user" [18982,18988]
===
match
---
name: url [19768,19771]
name: url [19780,19783]
===
match
---
name: client [11145,11151]
name: client [11157,11163]
===
match
---
dictorsetmaker [31950,32229]
dictorsetmaker [31962,32241]
===
match
---
trailer [19585,19587]
trailer [19597,19599]
===
match
---
string: "user" [26277,26283]
string: "user" [26289,26295]
===
match
---
argument [40726,40747]
argument [40738,40759]
===
match
---
name: create_or_update_secret [42310,42333]
name: create_or_update_secret [42322,42345]
===
match
---
suite [1410,1478]
suite [1410,1478]
===
match
---
trailer [13227,13229]
trailer [13239,13241]
===
match
---
string: 'destroyed' [36140,36151]
string: 'destroyed' [36152,36163]
===
match
---
trailer [33771,33795]
trailer [33783,33807]
===
match
---
argument [42334,42352]
argument [42346,42364]
===
match
---
name: return_value [39887,39899]
name: return_value [39899,39911]
===
match
---
trailer [7402,7420]
trailer [7414,7432]
===
match
---
operator: = [11793,11794]
operator: = [11805,11806]
===
match
---
dotted_name [26433,26443]
dotted_name [26445,26455]
===
match
---
decorated [30262,31649]
decorated [30274,31661]
===
match
---
argument [30234,30246]
argument [30246,30258]
===
match
---
name: secrets [27945,27952]
name: secrets [27957,27964]
===
match
---
argument [15166,15176]
argument [15178,15188]
===
match
---
name: url [22792,22795]
name: url [22804,22807]
===
match
---
trailer [15721,15767]
trailer [15733,15779]
===
match
---
string: 'The version is not supported: 4' [1375,1408]
string: 'The version is not supported: 4' [1375,1408]
===
match
---
string: "http://localhost:8180" [38122,38145]
string: "http://localhost:8180" [38134,38157]
===
match
---
simple_stmt [43442,43486]
simple_stmt [43454,43498]
===
match
---
name: mock_file [14881,14890]
name: mock_file [14893,14902]
===
match
---
name: kv [40252,40254]
name: kv [40264,40266]
===
match
---
operator: , [32373,32374]
operator: , [32385,32386]
===
match
---
string: "other" [33558,33565]
string: "other" [33570,33577]
===
match
---
string: 'metadata' [29438,29448]
string: 'metadata' [29450,29460]
===
match
---
simple_stmt [4883,4914]
simple_stmt [4895,4926]
===
match
---
operator: = [9581,9582]
operator: = [9593,9594]
===
match
---
string: "credentials" [10391,10404]
string: "credentials" [10403,10416]
===
match
---
trailer [3355,3374]
trailer [3361,3380]
===
match
---
operator: , [35858,35859]
operator: , [35870,35871]
===
match
---
name: mock_hvac [15395,15404]
name: mock_hvac [15407,15416]
===
match
---
operator: , [27767,27768]
operator: , [27779,27780]
===
match
---
argument [2623,2650]
argument [2623,2650]
===
match
---
name: MagicMock [30426,30435]
name: MagicMock [30438,30447]
===
match
---
trailer [13455,13465]
trailer [13467,13477]
===
match
---
name: is_authenticated [3521,3537]
name: is_authenticated [3533,3549]
===
match
---
trailer [41272,41279]
trailer [41284,41291]
===
match
---
name: return_value [42772,42784]
name: return_value [42784,42796]
===
match
---
operator: = [28701,28702]
operator: = [28713,28714]
===
match
---
dotted_name [880,893]
dotted_name [880,893]
===
match
---
name: read_secret_metadata [36284,36304]
name: read_secret_metadata [36296,36316]
===
match
---
trailer [27978,28002]
trailer [27990,28014]
===
match
---
name: return_value [25865,25877]
name: return_value [25877,25889]
===
match
---
name: _VaultClient [22760,22772]
name: _VaultClient [22772,22784]
===
match
---
trailer [33647,33658]
trailer [33659,33670]
===
match
---
with_item [14826,14890]
with_item [14838,14902]
===
match
---
trailer [28278,28291]
trailer [28290,28303]
===
match
---
trailer [12871,12978]
trailer [12883,12990]
===
match
---
string: 'version' [38694,38703]
string: 'version' [38706,38715]
===
match
---
suite [23624,24299]
suite [23636,24311]
===
match
---
name: host [22283,22287]
name: host [22295,22299]
===
match
---
operator: , [13922,13923]
operator: , [13934,13935]
===
match
---
name: kv_engine_version [7403,7420]
name: kv_engine_version [7415,7432]
===
match
---
name: mock_hvac [19537,19546]
name: mock_hvac [19549,19558]
===
match
---
operator: = [16709,16710]
operator: = [16721,16722]
===
match
---
funcdef [13368,14049]
funcdef [13380,14061]
===
match
---
string: 'destroyed' [37753,37764]
string: 'destroyed' [37765,37776]
===
match
---
trailer [28799,28807]
trailer [28811,28819]
===
match
---
operator: } [31140,31141]
operator: } [31152,31153]
===
match
---
name: MagicMock [24458,24467]
name: MagicMock [24470,24479]
===
match
---
name: secret [40361,40367]
name: secret [40373,40379]
===
match
---
name: mock_hvac [5732,5741]
name: mock_hvac [5744,5753]
===
match
---
trailer [26737,26740]
trailer [26749,26752]
===
match
---
name: mock_hvac [18105,18114]
name: mock_hvac [18117,18126]
===
match
---
operator: , [5416,5417]
operator: , [5428,5429]
===
match
---
string: 'secret' [40331,40339]
string: 'secret' [40343,40351]
===
match
---
string: 'secret_key' [37564,37576]
string: 'secret_key' [37576,37588]
===
match
---
name: mock_client [13437,13448]
name: mock_client [13449,13460]
===
match
---
string: 'pass' [8465,8471]
string: 'pass' [8477,8483]
===
match
---
operator: , [9475,9476]
operator: , [9487,9488]
===
match
---
operator: , [41440,41441]
operator: , [41452,41453]
===
match
---
name: mock_get_credentials [10831,10851]
name: mock_get_credentials [10843,10863]
===
match
---
operator: , [30975,30976]
operator: , [30987,30988]
===
match
---
string: "data" [16013,16019]
string: "data" [16025,16031]
===
match
---
string: 'deletion_time' [30916,30931]
string: 'deletion_time' [30928,30943]
===
match
---
arglist [3929,3995]
arglist [3941,4007]
===
match
---
simple_stmt [23292,23337]
simple_stmt [23304,23349]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [24316,24380]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [24328,24392]
===
match
---
param [12727,12732]
param [12739,12744]
===
match
---
string: 'secret_key' [30768,30780]
string: 'secret_key' [30780,30792]
===
match
---
trailer [5511,5513]
trailer [5523,5525]
===
match
---
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [29211,29249]
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [29223,29261]
===
match
---
trailer [29801,29984]
trailer [29813,29996]
===
match
---
operator: = [28418,28419]
operator: = [28430,28431]
===
match
---
operator: = [41236,41237]
operator: = [41248,41249]
===
match
---
trailer [15068,15097]
trailer [15080,15109]
===
match
---
name: vault_client [41316,41328]
name: vault_client [41328,41340]
===
match
---
operator: = [32333,32334]
operator: = [32345,32346]
===
match
---
operator: , [38040,38041]
operator: , [38052,38053]
===
match
---
name: mock [23506,23510]
name: mock [23518,23522]
===
match
---
operator: = [23018,23019]
operator: = [23030,23031]
===
match
---
name: auth_type [8301,8310]
name: auth_type [8313,8322]
===
match
---
string: 'key' [40369,40374]
string: 'key' [40381,40386]
===
match
---
name: self [16259,16263]
name: self [16271,16275]
===
match
---
operator: = [32368,32369]
operator: = [32380,32381]
===
match
---
operator: = [23053,23054]
operator: = [23065,23066]
===
match
---
expr_stmt [30407,30437]
expr_stmt [30419,30449]
===
match
---
funcdef [39769,40405]
funcdef [39781,40417]
===
match
---
string: "data" [16667,16673]
string: "data" [16679,16685]
===
match
---
name: client [6150,6156]
name: client [6162,6168]
===
match
---
name: url [19057,19060]
name: url [19069,19072]
===
match
---
operator: @ [1839,1840]
operator: @ [1839,1840]
===
match
---
name: vault_client [23990,24002]
name: vault_client [24002,24014]
===
match
---
string: "http://localhost:8180" [23939,23962]
string: "http://localhost:8180" [23951,23974]
===
match
---
operator: , [36817,36818]
operator: , [36829,36830]
===
match
---
arglist [39291,39483]
arglist [39303,39495]
===
match
---
operator: = [2477,2478]
operator: = [2477,2478]
===
match
---
name: client [16702,16708]
name: client [16714,16720]
===
match
---
trailer [12368,12387]
trailer [12380,12399]
===
match
---
name: MagicMock [21834,21843]
name: MagicMock [21846,21855]
===
match
---
simple_stmt [12753,12784]
simple_stmt [12765,12796]
===
match
---
arglist [8301,8472]
arglist [8313,8484]
===
match
---
trailer [36562,36564]
trailer [36574,36576]
===
match
---
simple_stmt [40142,40224]
simple_stmt [40154,40236]
===
match
---
name: credentials [11089,11100]
name: credentials [11101,11112]
===
match
---
argument [16534,16558]
argument [16546,16570]
===
match
---
string: 'value' [41046,41053]
string: 'value' [41058,41065]
===
match
---
number: 2 [3574,3575]
number: 2 [3586,3587]
===
match
---
param [42696,42705]
param [42708,42717]
===
match
---
trailer [36277,36280]
trailer [36289,36292]
===
match
---
name: _VaultClient [31166,31178]
name: _VaultClient [31178,31190]
===
match
---
simple_stmt [8100,8131]
simple_stmt [8112,8143]
===
match
---
name: assert_called_with [12091,12109]
name: assert_called_with [12103,12121]
===
match
---
atom_expr [17719,17784]
atom_expr [17731,17796]
===
match
---
atom_expr [6413,6443]
atom_expr [6425,6455]
===
match
---
operator: = [3135,3136]
operator: = [3141,3142]
===
match
---
atom_expr [25620,25650]
atom_expr [25632,25662]
===
match
---
argument [28647,28674]
argument [28659,28686]
===
match
---
name: mock_hvac [14172,14181]
name: mock_hvac [14184,14193]
===
match
---
name: mock_hvac [4922,4931]
name: mock_hvac [4934,4943]
===
match
---
trailer [14638,14645]
trailer [14650,14657]
===
match
---
name: radius_port [39358,39369]
name: radius_port [39370,39381]
===
match
---
simple_stmt [33690,33726]
simple_stmt [33702,33738]
===
match
---
decorated [20865,21681]
decorated [20877,21693]
===
match
---
string: "pass" [18533,18539]
string: "pass" [18545,18551]
===
match
---
name: MagicMock [15434,15443]
name: MagicMock [15446,15455]
===
match
---
atom_expr [5328,5460]
atom_expr [5340,5472]
===
match
---
name: radius_secret [22044,22057]
name: radius_secret [22056,22069]
===
match
---
name: Client [27390,27396]
name: Client [27402,27408]
===
match
---
name: token [24840,24845]
name: token [24852,24857]
===
match
---
name: vault_client [11833,11845]
name: vault_client [11845,11857]
===
match
---
name: url [3950,3953]
name: url [3962,3965]
===
match
---
string: "http://localhost:8180" [39459,39482]
string: "http://localhost:8180" [39471,39494]
===
match
---
simple_stmt [26155,26220]
simple_stmt [26167,26232]
===
match
---
string: "pass" [39402,39408]
string: "pass" [39414,39420]
===
match
---
dotted_name [1840,1850]
dotted_name [1840,1850]
===
match
---
simple_stmt [24091,24136]
simple_stmt [24103,24148]
===
match
---
param [10177,10192]
param [10189,10204]
===
match
---
operator: = [29893,29894]
operator: = [29905,29906]
===
match
---
operator: , [30216,30217]
operator: , [30228,30229]
===
match
---
simple_stmt [25220,25355]
simple_stmt [25232,25367]
===
match
---
operator: = [34088,34089]
operator: = [34100,34101]
===
match
---
name: raises [7669,7675]
name: raises [7681,7687]
===
match
---
name: side_effect [26764,26775]
name: side_effect [26776,26787]
===
match
---
name: radius_secret [40791,40804]
name: radius_secret [40803,40816]
===
match
---
parameters [13410,13427]
parameters [13422,13439]
===
match
---
name: mock_client [4883,4894]
name: mock_client [4895,4906]
===
match
---
name: mock_client [43852,43863]
name: mock_client [43864,43875]
===
match
---
operator: = [27618,27619]
operator: = [27630,27631]
===
match
---
name: patch [34419,34424]
name: patch [34431,34436]
===
match
---
operator: , [40017,40018]
operator: , [40029,40030]
===
match
---
trailer [10258,10271]
trailer [10270,10283]
===
match
---
operator: , [40811,40812]
operator: , [40823,40824]
===
match
---
trailer [37251,37258]
trailer [37263,37270]
===
match
---
atom_expr [2660,2732]
atom_expr [2660,2738]
===
match
---
operator: , [3873,3874]
operator: , [3885,3886]
===
match
---
atom_expr [27583,27778]
atom_expr [27595,27790]
===
match
---
name: kv [33754,33756]
name: kv [33766,33768]
===
match
---
trailer [26621,26628]
trailer [26633,26640]
===
match
---
atom_expr [22667,22746]
atom_expr [22679,22758]
===
match
---
trailer [26628,26641]
trailer [26640,26653]
===
match
---
trailer [2747,2764]
trailer [2753,2770]
===
match
---
operator: = [39227,39228]
operator: = [39239,39240]
===
match
---
trailer [12431,12436]
trailer [12443,12448]
===
match
---
simple_stmt [32609,32709]
simple_stmt [32621,32721]
===
match
---
operator: , [28870,28871]
operator: , [28882,28883]
===
match
---
name: test_create_or_update_secret_v2_cas [41162,41197]
name: test_create_or_update_secret_v2_cas [41174,41209]
===
match
---
atom_expr [2559,2578]
atom_expr [2559,2578]
===
match
---
operator: } [36210,36211]
operator: } [36222,36223]
===
match
---
operator: , [39482,39483]
operator: , [39494,39495]
===
match
---
operator: = [33420,33421]
operator: = [33432,33433]
===
match
---
simple_stmt [3753,3784]
simple_stmt [3765,3796]
===
match
---
trailer [7614,7621]
trailer [7626,7633]
===
match
---
argument [43939,43959]
argument [43951,43971]
===
match
---
simple_stmt [4218,4367]
simple_stmt [4230,4379]
===
match
---
number: 0 [37514,37515]
number: 0 [37526,37527]
===
match
---
operator: , [8437,8438]
operator: , [8449,8450]
===
match
---
name: auth_type [37987,37996]
name: auth_type [37999,38008]
===
match
---
testlist_comp [9504,9522]
testlist_comp [9516,9534]
===
match
---
name: write [23797,23802]
name: write [23809,23814]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [20877,20941]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [20889,20953]
===
match
---
string: "path" [16768,16774]
string: "path" [16780,16786]
===
match
---
name: token_path [23901,23911]
name: token_path [23913,23923]
===
match
---
number: 2 [36191,36192]
number: 2 [36203,36204]
===
match
---
expr_stmt [2356,2399]
expr_stmt [2356,2399]
===
match
---
name: open [23729,23733]
name: open [23741,23745]
===
match
---
operator: , [33430,33431]
operator: , [33442,33443]
===
match
---
trailer [40243,40251]
trailer [40255,40263]
===
match
---
name: mock_hvac [16265,16274]
name: mock_hvac [16277,16286]
===
match
---
with_stmt [15711,15823]
with_stmt [15723,15835]
===
match
---
operator: , [17743,17744]
operator: , [17755,17756]
===
match
---
string: "missing" [32546,32555]
string: "missing" [32558,32567]
===
match
---
atom_expr [21829,21845]
atom_expr [21841,21857]
===
match
---
number: 2 [11205,11206]
number: 2 [11217,11218]
===
match
---
string: "userpass" [2103,2113]
string: "userpass" [2103,2113]
===
match
---
operator: = [2724,2725]
operator: = [2730,2731]
===
match
---
string: 'http://localhost:8180' [5295,5318]
string: 'http://localhost:8180' [5307,5330]
===
match
---
funcdef [27267,28077]
funcdef [27279,28089]
===
match
---
simple_stmt [31830,31874]
simple_stmt [31842,31886]
===
match
---
string: 'http://localhost:8180' [6117,6140]
string: 'http://localhost:8180' [6129,6152]
===
match
---
number: 2764800 [33181,33188]
number: 2764800 [33193,33200]
===
match
---
trailer [19396,19414]
trailer [19408,19426]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [16142,16206]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [16154,16218]
===
match
---
name: secrets [27048,27055]
name: secrets [27060,27067]
===
match
---
atom_expr [40600,40629]
atom_expr [40612,40641]
===
match
---
operator: = [16426,16427]
operator: = [16438,16439]
===
match
---
operator: = [9189,9190]
operator: = [9201,9202]
===
match
---
argument [42250,42277]
argument [42262,42289]
===
match
---
argument [18961,18976]
argument [18973,18988]
===
match
---
atom_expr [5707,5723]
atom_expr [5719,5735]
===
match
---
operator: = [28027,28028]
operator: = [28039,28040]
===
match
---
param [13417,13426]
param [13429,13438]
===
match
---
trailer [43458,43471]
trailer [43470,43483]
===
match
---
operator: @ [7426,7427]
operator: @ [7438,7439]
===
match
---
number: 1 [29631,29632]
number: 1 [29643,29644]
===
match
---
operator: = [18362,18363]
operator: = [18374,18375]
===
match
---
atom_expr [15429,15445]
atom_expr [15441,15457]
===
match
---
comparison [27888,27924]
comparison [27900,27936]
===
match
---
trailer [15209,15228]
trailer [15221,15240]
===
match
---
assert_stmt [25608,25650]
assert_stmt [25620,25662]
===
match
---
atom_expr [3412,3505]
atom_expr [3418,3517]
===
match
---
name: test_radius_missing_secret [19888,19914]
name: test_radius_missing_secret [19900,19926]
===
match
---
trailer [3808,3821]
trailer [3820,3833]
===
match
---
classdef [1079,44030]
classdef [1079,44042]
===
match
---
name: secret [41031,41037]
name: secret [41043,41049]
===
match
---
expr_stmt [6984,7012]
expr_stmt [6996,7024]
===
match
---
number: 0 [38415,38416]
number: 0 [38427,38428]
===
match
---
dotted_name [14055,14065]
dotted_name [14067,14077]
===
match
---
name: vault_client [29774,29786]
name: vault_client [29786,29798]
===
match
---
name: mount_point [24986,24997]
name: mount_point [24998,25009]
===
match
---
argument [14859,14875]
argument [14871,14887]
===
match
---
param [12733,12742]
param [12745,12754]
===
match
---
assert_stmt [7378,7420]
assert_stmt [7390,7432]
===
match
---
testlist_comp [8972,8990]
testlist_comp [8984,9002]
===
match
---
number: 2 [5529,5530]
number: 2 [5541,5542]
===
match
---
trailer [30455,30462]
trailer [30467,30474]
===
match
---
operator: , [5062,5063]
operator: , [5074,5075]
===
match
---
trailer [20628,20657]
trailer [20640,20669]
===
match
---
trailer [34655,34663]
trailer [34667,34675]
===
match
---
trailer [24839,24845]
trailer [24851,24857]
===
match
---
arglist [40319,40394]
arglist [40331,40406]
===
match
---
string: 'version' [37793,37802]
string: 'version' [37805,37814]
===
match
---
name: is_authenticated [25562,25578]
name: is_authenticated [25574,25590]
===
match
---
suite [20086,20184]
suite [20098,20196]
===
match
---
operator: = [43508,43509]
operator: = [43520,43521]
===
match
---
arglist [41011,41069]
arglist [41023,41081]
===
match
---
atom_expr [39616,39681]
atom_expr [39628,39693]
===
match
---
name: MagicMock [8868,8877]
name: MagicMock [8880,8889]
===
match
---
name: mock_client [22949,22960]
name: mock_client [22961,22972]
===
match
---
name: mock [32715,32719]
name: mock [32727,32731]
===
match
---
atom_expr [11145,11189]
atom_expr [11157,11201]
===
match
---
number: 2 [17018,17019]
number: 2 [17030,17031]
===
match
---
expr_stmt [32501,32556]
expr_stmt [32513,32568]
===
match
---
name: keyfile_dict [12275,12287]
name: keyfile_dict [12287,12299]
===
match
---
name: mock_hvac [42755,42764]
name: mock_hvac [42767,42776]
===
match
---
simple_stmt [1973,2004]
simple_stmt [1973,2004]
===
match
---
string: "pass" [2525,2531]
string: "pass" [2525,2531]
===
match
---
string: "radius" [36677,36685]
string: "radius" [36689,36697]
===
match
---
trailer [15443,15445]
trailer [15455,15457]
===
match
---
trailer [18243,18346]
trailer [18255,18358]
===
match
---
arglist [2449,2531]
arglist [2449,2531]
===
match
---
operator: = [7816,7817]
operator: = [7828,7829]
===
match
---
operator: , [42104,42105]
operator: , [42116,42117]
===
match
---
name: client [22147,22153]
name: client [22159,22165]
===
match
---
operator: = [17427,17428]
operator: = [17439,17440]
===
match
---
suite [34330,34408]
suite [34342,34420]
===
match
---
trailer [13008,13015]
trailer [13020,13027]
===
match
---
string: "project_id" [11811,11823]
string: "project_id" [11823,11835]
===
match
---
arglist [43079,43144]
arglist [43091,43156]
===
match
---
name: mock [28083,28087]
name: mock [28095,28099]
===
match
---
operator: = [14761,14762]
operator: = [14773,14774]
===
match
---
argument [3187,3214]
argument [3193,3220]
===
match
---
name: secret [27787,27793]
name: secret [27799,27805]
===
match
---
number: 0 [29341,29342]
number: 0 [29353,29354]
===
match
---
name: pytest [7662,7668]
name: pytest [7674,7680]
===
match
---
number: 2 [21645,21646]
number: 2 [21657,21658]
===
match
---
operator: = [31617,31618]
operator: = [31629,31630]
===
match
---
simple_stmt [20764,20809]
simple_stmt [20776,20821]
===
match
---
simple_stmt [10771,10823]
simple_stmt [10783,10835]
===
match
---
name: mock_get_credentials [12207,12227]
name: mock_get_credentials [12219,12239]
===
match
---
string: 'deletion_time' [38613,38628]
string: 'deletion_time' [38625,38640]
===
match
---
expr_stmt [23981,24009]
expr_stmt [23993,24021]
===
match
---
operator: , [9494,9495]
operator: , [9506,9507]
===
match
---
name: mock [27186,27190]
name: mock [27198,27202]
===
match
---
name: mock [11444,11448]
name: mock [11456,11460]
===
match
---
simple_stmt [14590,14621]
simple_stmt [14602,14633]
===
match
---
name: kubernetes_jwt_path [16494,16513]
name: kubernetes_jwt_path [16506,16525]
===
match
---
atom [30827,31028]
atom [30839,31040]
===
match
---
operator: , [36211,36212]
operator: , [36223,36224]
===
match
---
name: MagicMock [20332,20341]
name: MagicMock [20344,20353]
===
match
---
string: 'lease_duration' [32076,32092]
string: 'lease_duration' [32088,32104]
===
match
---
atom_expr [32609,32708]
atom_expr [32621,32720]
===
match
---
name: assert_called_with [9559,9577]
name: assert_called_with [9571,9589]
===
match
---
trailer [23004,23017]
trailer [23016,23029]
===
match
---
expr_stmt [26118,26146]
expr_stmt [26130,26158]
===
match
---
dictorsetmaker [29382,29652]
dictorsetmaker [29394,29664]
===
match
---
operator: , [25107,25108]
operator: , [25119,25120]
===
match
---
atom_expr [11044,11136]
atom_expr [11056,11148]
===
match
---
name: client [3514,3520]
name: client [3526,3532]
===
match
---
simple_stmt [10354,10420]
simple_stmt [10366,10432]
===
match
---
argument [35405,35422]
argument [35417,35434]
===
match
---
simple_stmt [17011,17054]
simple_stmt [17023,17066]
===
match
---
parameters [4100,4117]
parameters [4112,4129]
===
match
---
argument [33579,33606]
argument [33591,33618]
===
match
---
argument [3159,3173]
argument [3165,3179]
===
match
---
name: auth_mount_point [3258,3274]
name: auth_mount_point [3264,3280]
===
match
---
name: assert_called_with [24115,24133]
name: assert_called_with [24127,24145]
===
match
---
atom_expr [20764,20808]
atom_expr [20776,20820]
===
match
---
string: "scope1,scope2" [12182,12197]
string: "scope1,scope2" [12194,12209]
===
match
---
suite [25800,26427]
suite [25812,26439]
===
match
---
atom_expr [12074,12138]
atom_expr [12086,12150]
===
match
---
string: "http://localhost:8180" [43704,43727]
string: "http://localhost:8180" [43716,43739]
===
match
---
atom_expr [36548,36564]
atom_expr [36560,36576]
===
match
---
trailer [9551,9558]
trailer [9563,9570]
===
match
---
name: vault_client [23191,23203]
name: vault_client [23203,23215]
===
match
---
trailer [16629,16675]
trailer [16641,16687]
===
match
---
name: mock_hvac [7546,7555]
name: mock_hvac [7558,7567]
===
match
---
argument [15912,15939]
argument [15924,15951]
===
match
---
name: test_get_secret_metadata_v2 [34499,34526]
name: test_get_secret_metadata_v2 [34511,34538]
===
match
---
string: "pass" [3238,3244]
string: "pass" [3244,3250]
===
match
---
string: 'value' [40214,40221]
string: 'value' [40226,40233]
===
match
---
atom_expr [2423,2541]
atom_expr [2423,2541]
===
match
---
with_stmt [1338,1478]
with_stmt [1338,1478]
===
match
---
string: "http://localhost:8180" [12945,12968]
string: "http://localhost:8180" [12957,12980]
===
match
---
atom_expr [38176,38241]
atom_expr [38188,38253]
===
match
---
name: assert_called_with [22357,22375]
name: assert_called_with [22369,22387]
===
match
---
name: kv_engine_version [32421,32438]
name: kv_engine_version [32433,32450]
===
match
---
name: vault_client [21107,21119]
name: vault_client [21119,21131]
===
match
---
argument [13601,13635]
argument [13613,13647]
===
match
---
trailer [12162,12181]
trailer [12174,12193]
===
match
---
trailer [20770,20787]
trailer [20782,20799]
===
match
---
name: MagicMock [34572,34581]
name: MagicMock [34584,34593]
===
match
---
name: return_value [34609,34621]
name: return_value [34621,34633]
===
match
---
decorator [22826,22904]
decorator [22838,22916]
===
match
---
operator: = [24563,24564]
operator: = [24575,24576]
===
match
---
operator: , [35329,35330]
operator: , [35341,35342]
===
match
---
name: mock [15288,15292]
name: mock [15300,15304]
===
match
---
name: mock [5707,5711]
name: mock [5719,5723]
===
match
---
funcdef [8771,9814]
funcdef [8783,9826]
===
match
---
name: mock [19421,19425]
name: mock [19433,19437]
===
match
---
arglist [40891,40959]
arglist [40903,40971]
===
match
---
operator: = [16940,16941]
operator: = [16952,16953]
===
match
---
operator: = [13578,13579]
operator: = [13590,13591]
===
match
---
operator: , [6869,6870]
operator: , [6881,6882]
===
match
---
operator: = [7897,7898]
operator: = [7909,7910]
===
match
---
with_stmt [19648,19797]
with_stmt [19660,19809]
===
match
---
atom_expr [7390,7420]
atom_expr [7402,7432]
===
match
---
arglist [34116,34256]
arglist [34128,34268]
===
match
---
operator: = [25950,25951]
operator: = [25962,25963]
===
match
---
argument [35550,35571]
argument [35562,35583]
===
match
---
expr_stmt [1286,1329]
expr_stmt [1286,1329]
===
match
---
operator: == [12590,12592]
operator: == [12602,12604]
===
match
---
name: vault_client [34343,34355]
name: vault_client [34355,34367]
===
match
---
simple_stmt [26612,26656]
simple_stmt [26624,26668]
===
match
---
atom_expr [33998,34014]
atom_expr [34010,34026]
===
match
---
dictorsetmaker [41770,41784]
dictorsetmaker [41782,41796]
===
match
---
name: vault_client [40142,40154]
name: vault_client [40154,40166]
===
match
---
operator: , [36685,36686]
operator: , [36697,36698]
===
match
---
simple_stmt [18602,18645]
simple_stmt [18614,18657]
===
match
---
name: assert_called_with [24685,24703]
name: assert_called_with [24697,24715]
===
match
---
string: "resource" [7198,7208]
string: "resource" [7210,7220]
===
match
---
string: 'http://localhost:8180' [15073,15096]
string: 'http://localhost:8180' [15085,15108]
===
match
---
suite [23775,23833]
suite [23787,23845]
===
match
---
name: vault_client [23417,23429]
name: vault_client [23429,23441]
===
match
---
name: Client [21381,21387]
name: Client [21393,21399]
===
match
---
name: keyfile_dict [10906,10918]
name: keyfile_dict [10918,10930]
===
match
---
simple_stmt [1286,1330]
simple_stmt [1286,1330]
===
match
---
operator: = [25439,25440]
operator: = [25451,25452]
===
match
---
name: assert_called_with [12552,12570]
name: assert_called_with [12564,12582]
===
match
---
arglist [12260,12333]
arglist [12272,12345]
===
match
---
string: "credentials" [12495,12508]
string: "credentials" [12507,12520]
===
match
---
trailer [10786,10805]
trailer [10798,10817]
===
match
---
assert_stmt [22386,22428]
assert_stmt [22398,22440]
===
match
---
operator: == [23414,23416]
operator: == [23426,23428]
===
match
---
operator: , [40901,40902]
operator: , [40913,40914]
===
match
---
operator: = [18969,18970]
operator: = [18981,18982]
===
match
---
operator: = [34565,34566]
operator: = [34577,34578]
===
match
---
operator: , [8980,8981]
operator: , [8992,8993]
===
match
---
simple_stmt [10428,10653]
simple_stmt [10440,10665]
===
match
---
operator: == [19381,19383]
operator: == [19393,19395]
===
match
---
string: 'missing' [31618,31627]
string: 'missing' [31630,31639]
===
match
---
string: 'lease_duration' [34846,34862]
string: 'lease_duration' [34858,34874]
===
match
---
name: mock_hvac [2587,2596]
name: mock_hvac [2587,2596]
===
match
---
name: kv_engine_version [24229,24246]
name: kv_engine_version [24241,24258]
===
match
---
dictorsetmaker [30759,31029]
dictorsetmaker [30771,31041]
===
match
---
name: Client [21864,21870]
name: Client [21876,21882]
===
match
---
argument [26033,26057]
argument [26045,26069]
===
match
---
arglist [29815,29974]
arglist [29827,29986]
===
match
---
trailer [26248,26267]
trailer [26260,26279]
===
match
---
atom_expr [31508,31648]
atom_expr [31520,31660]
===
match
---
simple_stmt [17662,17706]
simple_stmt [17674,17718]
===
match
---
operator: , [21793,21794]
operator: , [21805,21806]
===
match
---
atom_expr [15106,15177]
atom_expr [15118,15189]
===
match
---
name: mock_client [34055,34066]
name: mock_client [34067,34078]
===
match
---
name: configure [9631,9640]
name: configure [9643,9652]
===
match
---
name: return_value [34691,34703]
name: return_value [34703,34715]
===
match
---
name: mount_point [30196,30207]
name: mount_point [30208,30219]
===
match
---
trailer [26827,26933]
trailer [26839,26945]
===
match
---
parameters [12726,12743]
parameters [12738,12755]
===
match
---
name: assert_called_once_with [43902,43925]
name: assert_called_once_with [43914,43937]
===
match
---
string: "'token' authentication type requires 'token'" [22699,22745]
string: "'token' authentication type requires 'token'" [22711,22757]
===
match
---
decorated [26432,27180]
decorated [26444,27192]
===
match
---
atom_expr [5255,5319]
atom_expr [5267,5331]
===
match
---
trailer [17383,17464]
trailer [17395,17476]
===
match
---
operator: = [24638,24639]
operator: = [24650,24651]
===
match
---
name: v1 [31906,31908]
name: v1 [31918,31920]
===
match
---
operator: = [21191,21192]
operator: = [21203,21204]
===
match
---
string: "approle" [1446,1455]
string: "approle" [1446,1455]
===
match
---
operator: = [26293,26294]
operator: = [26305,26306]
===
match
---
atom_expr [1286,1315]
atom_expr [1286,1315]
===
match
---
operator: , [32308,32309]
operator: , [32320,32321]
===
match
---
name: jwt [15166,15169]
name: jwt [15178,15181]
===
match
---
name: mock_client [10203,10214]
name: mock_client [10215,10226]
===
match
---
operator: , [28600,28601]
operator: , [28612,28613]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [35829,35858]
string: '2020-03-16T21:01:43.331126Z' [35841,35870]
===
match
---
name: MagicMock [17219,17228]
name: MagicMock [17231,17240]
===
match
---
operator: { [29183,29184]
operator: { [29195,29196]
===
match
---
simple_stmt [21585,21630]
simple_stmt [21597,21642]
===
match
---
simple_stmt [1619,1650]
simple_stmt [1619,1650]
===
match
---
name: radius [22247,22253]
name: radius [22259,22265]
===
match
---
expr_stmt [4375,4403]
expr_stmt [4387,4415]
===
match
---
argument [13060,13087]
argument [13072,13099]
===
match
---
argument [21249,21273]
argument [21261,21285]
===
match
---
arglist [1436,1476]
arglist [1436,1476]
===
match
---
operator: } [35328,35329]
operator: } [35340,35341]
===
match
---
name: key_id [5977,5983]
name: key_id [5989,5995]
===
match
---
name: patch [7965,7970]
name: patch [7977,7982]
===
match
---
operator: , [28036,28037]
operator: , [28048,28049]
===
match
---
string: 'renewable' [38365,38376]
string: 'renewable' [38377,38388]
===
match
---
name: mock [22585,22589]
name: mock [22597,22601]
===
match
---
name: secret_path [40341,40352]
name: secret_path [40353,40364]
===
match
---
operator: , [22064,22065]
operator: , [22076,22077]
===
match
---
name: mock_client [5693,5704]
name: mock_client [5705,5716]
===
match
---
string: 'auth' [29741,29747]
string: 'auth' [29753,29759]
===
match
---
operator: = [11728,11729]
operator: = [11740,11741]
===
match
---
operator: , [40712,40713]
operator: , [40724,40725]
===
match
---
trailer [34601,34608]
trailer [34613,34620]
===
match
---
name: Client [34602,34608]
name: Client [34614,34620]
===
match
---
trailer [28849,28887]
trailer [28861,28899]
===
match
---
name: pytest [17719,17725]
name: pytest [17731,17737]
===
match
---
argument [20063,20084]
argument [20075,20096]
===
match
---
name: test_gcp_different_auth_mount_point [10102,10137]
name: test_gcp_different_auth_mount_point [10114,10149]
===
match
---
trailer [11151,11168]
trailer [11163,11180]
===
match
---
operator: , [32228,32229]
operator: , [32240,32241]
===
match
---
expr_stmt [23841,23972]
expr_stmt [23853,23984]
===
match
---
name: return_value [39214,39226]
name: return_value [39226,39238]
===
match
---
operator: , [5990,5991]
operator: , [6002,6003]
===
match
---
name: self [13411,13415]
name: self [13423,13427]
===
match
---
name: self [1947,1951]
name: self [1947,1951]
===
match
---
dotted_name [27186,27196]
dotted_name [27198,27208]
===
match
---
operator: , [25298,25299]
operator: , [25310,25311]
===
match
---
name: mock_hvac [12733,12742]
name: mock_hvac [12745,12754]
===
match
---
trailer [41242,41252]
trailer [41254,41264]
===
match
---
param [13411,13416]
param [13423,13428]
===
match
---
name: self [20990,20994]
name: self [21002,21006]
===
match
---
name: mock_client [37274,37285]
name: mock_client [37286,37297]
===
match
---
operator: = [43545,43546]
operator: = [43557,43558]
===
match
---
string: "missing" [33671,33680]
string: "missing" [33683,33692]
===
match
---
name: test_token_path [23591,23606]
name: test_token_path [23603,23618]
===
match
---
name: username [19256,19264]
name: username [19268,19276]
===
match
---
trailer [25632,25650]
trailer [25644,25662]
===
match
---
simple_stmt [5218,5247]
simple_stmt [5230,5259]
===
match
---
simple_stmt [15415,15446]
simple_stmt [15427,15458]
===
match
---
operator: , [4610,4611]
operator: , [4622,4623]
===
match
---
funcdef [10098,11241]
funcdef [10110,11253]
===
match
---
operator: = [10579,10580]
operator: = [10591,10592]
===
match
---
operator: = [44012,44013]
operator: = [44024,44025]
===
match
---
trailer [6371,6390]
trailer [6383,6402]
===
match
---
trailer [3928,3996]
trailer [3940,4008]
===
match
---
comparison [30064,30104]
comparison [30076,30116]
===
match
---
trailer [13208,13227]
trailer [13220,13239]
===
match
---
operator: = [11960,11961]
operator: = [11972,11973]
===
match
---
simple_stmt [37946,38157]
simple_stmt [37958,38169]
===
match
---
operator: , [34133,34134]
operator: , [34145,34146]
===
match
---
name: client [19104,19110]
name: client [19116,19122]
===
match
---
name: assert_called_with [15129,15147]
name: assert_called_with [15141,15159]
===
match
---
operator: , [35091,35092]
operator: , [35103,35104]
===
match
---
argument [41031,41054]
argument [41043,41066]
===
match
---
operator: = [18137,18138]
operator: = [18149,18150]
===
match
---
argument [43784,43802]
argument [43796,43814]
===
match
---
atom_expr [34567,34583]
atom_expr [34579,34595]
===
match
---
trailer [16313,16315]
trailer [16325,16327]
===
match
---
operator: , [37731,37732]
operator: , [37743,37744]
===
match
---
string: 'request_id' [33037,33049]
string: 'request_id' [33049,33061]
===
match
---
trailer [22246,22253]
trailer [22258,22265]
===
match
---
name: mock_client [32949,32960]
name: mock_client [32961,32972]
===
match
---
expr_stmt [4974,5209]
expr_stmt [4986,5221]
===
match
---
string: "requires 'kubernetes_jwt_path'" [17751,17783]
string: "requires 'kubernetes_jwt_path'" [17763,17795]
===
match
---
name: mock_client [15415,15426]
name: mock_client [15427,15438]
===
match
---
operator: = [11993,11994]
operator: = [12005,12006]
===
match
---
trailer [39628,39658]
trailer [39640,39670]
===
match
---
trailer [10870,10962]
trailer [10882,10974]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [23517,23581]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [23529,23593]
===
match
---
string: "http://localhost:8180" [20159,20182]
string: "http://localhost:8180" [20171,20194]
===
match
---
name: mock_hvac [13417,13426]
name: mock_hvac [13429,13438]
===
match
---
decorated [1116,1478]
decorated [1116,1478]
===
match
---
name: mock [42730,42734]
name: mock [42742,42746]
===
match
---
name: the_file [23766,23774]
name: the_file [23778,23786]
===
match
---
operator: = [21956,21957]
operator: = [21968,21969]
===
match
---
operator: } [30093,30094]
operator: } [30105,30106]
===
match
---
dotted_name [25004,25014]
dotted_name [25016,25026]
===
match
---
name: client [13009,13015]
name: client [13021,13027]
===
match
---
parameters [30380,30397]
parameters [30392,30409]
===
match
---
expr_stmt [39250,39493]
expr_stmt [39262,39505]
===
match
---
dotted_name [7427,7437]
dotted_name [7439,7449]
===
match
---
name: kubernetes_jwt_path [17913,17932]
name: kubernetes_jwt_path [17925,17944]
===
match
---
suite [41215,41804]
suite [41227,41816]
===
match
---
simple_stmt [15186,15231]
simple_stmt [15198,15243]
===
match
---
operator: { [11920,11921]
operator: { [11932,11933]
===
match
---
name: Client [28272,28278]
name: Client [28284,28290]
===
match
---
trailer [18153,18155]
trailer [18165,18167]
===
match
---
name: client [23384,23390]
name: client [23396,23402]
===
match
---
argument [5856,5883]
argument [5868,5895]
===
match
---
operator: , [5160,5161]
operator: , [5172,5173]
===
match
---
name: client [18377,18383]
name: client [18389,18395]
===
match
---
trailer [10980,10987]
trailer [10992,10999]
===
match
---
operator: @ [17059,17060]
operator: @ [17071,17072]
===
match
---
simple_stmt [2065,2136]
simple_stmt [2065,2136]
===
match
---
name: client_id [6278,6287]
name: client_id [6290,6299]
===
match
---
trailer [43522,43738]
trailer [43534,43750]
===
match
---
name: is_authenticated [13960,13976]
name: is_authenticated [13972,13988]
===
match
---
operator: = [43972,43973]
operator: = [43984,43985]
===
match
---
trailer [42460,42562]
trailer [42472,42574]
===
match
---
string: "other" [16941,16948]
string: "other" [16953,16960]
===
match
---
trailer [15533,15702]
trailer [15545,15714]
===
match
---
name: mock_client [30478,30489]
name: mock_client [30490,30501]
===
match
---
trailer [34102,34266]
trailer [34114,34278]
===
match
---
trailer [23802,23832]
trailer [23814,23844]
===
match
---
simple_stmt [2741,2786]
simple_stmt [2747,2792]
===
match
---
operator: = [7265,7266]
operator: = [7277,7278]
===
match
---
operator: = [40908,40909]
operator: = [40920,40921]
===
match
---
argument [10617,10641]
argument [10629,10653]
===
match
---
atom_expr [22333,22377]
atom_expr [22345,22389]
===
match
---
operator: , [16263,16264]
operator: , [16275,16276]
===
match
---
simple_stmt [29774,29985]
simple_stmt [29786,29997]
===
match
---
name: self [7540,7544]
name: self [7552,7556]
===
match
---
operator: , [38706,38707]
operator: , [38718,38719]
===
match
---
atom_expr [3033,3062]
atom_expr [3039,3068]
===
match
---
string: 'scope2' [10336,10344]
string: 'scope2' [10348,10356]
===
match
---
funcdef [42650,43249]
funcdef [42662,43261]
===
match
---
argument [25283,25298]
argument [25295,25310]
===
match
---
name: is_authenticated [21592,21608]
name: is_authenticated [21604,21620]
===
match
---
suite [19548,19797]
suite [19560,19809]
===
match
---
operator: , [16599,16600]
operator: , [16611,16612]
===
match
---
decorated [22434,22821]
decorated [22446,22833]
===
match
---
simple_stmt [42716,42747]
simple_stmt [42728,42759]
===
match
---
string: 'secret_value' [30782,30796]
string: 'secret_value' [30794,30808]
===
match
---
name: mock [2843,2847]
name: mock [2849,2853]
===
match
---
name: mount_point [1760,1771]
name: mount_point [1760,1771]
===
match
---
arglist [23882,23962]
arglist [23894,23974]
===
match
---
name: kv_engine_version [6426,6443]
name: kv_engine_version [6438,6455]
===
match
---
trailer [39277,39493]
trailer [39289,39505]
===
match
---
name: assert_called_with [19343,19361]
name: assert_called_with [19355,19373]
===
match
---
suite [43146,43249]
suite [43158,43261]
===
match
---
operator: = [19684,19685]
operator: = [19696,19697]
===
match
---
operator: == [21647,21649]
operator: == [21659,21661]
===
match
---
dotted_name [33840,33850]
dotted_name [33852,33862]
===
match
---
name: client [18355,18361]
name: client [18367,18373]
===
match
---
name: secret [26942,26948]
name: secret [26954,26960]
===
match
---
argument [38084,38104]
argument [38096,38116]
===
match
---
name: unittest [845,853]
name: unittest [845,853]
===
match
---
name: url [11990,11993]
name: url [12002,12005]
===
match
---
name: auth_type [5825,5834]
name: auth_type [5837,5846]
===
match
---
operator: , [38005,38006]
operator: , [38017,38018]
===
match
---
trailer [14925,14932]
trailer [14937,14944]
===
match
---
operator: , [7175,7176]
operator: , [7187,7188]
===
match
---
operator: = [25198,25199]
operator: = [25210,25211]
===
match
---
arglist [24558,24621]
arglist [24570,24633]
===
match
---
argument [22299,22312]
argument [22311,22324]
===
match
---
simple_stmt [21107,21326]
simple_stmt [21119,21338]
===
match
---
name: auth_kubernetes [16864,16879]
name: auth_kubernetes [16876,16891]
===
match
---
argument [33796,33816]
argument [33808,33828]
===
match
---
operator: = [23139,23140]
operator: = [23151,23152]
===
match
---
trailer [11656,11663]
trailer [11668,11675]
===
match
---
name: vault_client [30002,30014]
name: vault_client [30014,30026]
===
match
---
operator: = [42345,42346]
operator: = [42357,42358]
===
match
---
operator: } [43826,43827]
operator: } [43838,43839]
===
match
---
string: 'http://localhost:8180' [22202,22225]
string: 'http://localhost:8180' [22214,22237]
===
match
---
trailer [4523,4621]
trailer [4535,4633]
===
match
---
name: Client [7615,7621]
name: Client [7627,7633]
===
match
---
expr_stmt [2550,2578]
expr_stmt [2550,2578]
===
match
---
dotted_name [21687,21697]
dotted_name [21699,21709]
===
match
---
name: match [20063,20068]
name: match [20075,20080]
===
match
---
operator: = [21540,21541]
operator: = [21552,21553]
===
match
---
string: "user" [19265,19271]
string: "user" [19277,19283]
===
match
---
trailer [28241,28251]
trailer [28253,28263]
===
match
---
atom_expr [41633,41803]
atom_expr [41645,41815]
===
match
---
argument [16917,16927]
argument [16929,16939]
===
match
---
name: path [30218,30222]
name: path [30230,30234]
===
match
---
name: mock_client [22642,22653]
name: mock_client [22654,22665]
===
match
---
atom_expr [18364,18383]
atom_expr [18376,18395]
===
match
---
string: "radhost" [28527,28536]
string: "radhost" [28539,28548]
===
match
---
name: kv_engine_version [42217,42234]
name: kv_engine_version [42229,42246]
===
match
---
name: vault_client [3579,3591]
name: vault_client [3591,3603]
===
match
---
name: kv [29142,29144]
name: kv [29154,29156]
===
match
---
atom_expr [15803,15822]
atom_expr [15815,15834]
===
match
---
parameters [8073,8090]
parameters [8085,8102]
===
match
---
name: _VaultClient [35379,35391]
name: _VaultClient [35391,35403]
===
match
---
decorator [41076,41154]
decorator [41088,41166]
===
match
---
atom_expr [20829,20859]
atom_expr [20841,20871]
===
match
---
operator: = [42360,42361]
operator: = [42372,42373]
===
match
---
operator: , [19084,19085]
operator: , [19096,19097]
===
match
---
atom_expr [28262,28291]
atom_expr [28274,28303]
===
match
---
name: assert_called_with [18409,18427]
name: assert_called_with [18421,18439]
===
match
---
name: radius [20678,20684]
name: radius [20690,20696]
===
match
---
trailer [37221,37231]
trailer [37233,37243]
===
match
---
operator: { [41769,41770]
operator: { [41781,41782]
===
match
---
name: v2 [26741,26743]
name: v2 [26753,26755]
===
match
---
name: url [23935,23938]
name: url [23947,23950]
===
match
---
string: 'key' [43224,43229]
string: 'key' [43236,43241]
===
match
---
name: url [17955,17958]
name: url [17967,17970]
===
match
---
name: radius_host [40726,40737]
name: radius_host [40738,40749]
===
match
---
string: "radhost" [40738,40747]
string: "radhost" [40750,40759]
===
match
---
trailer [20806,20808]
trailer [20818,20820]
===
match
---
name: test_azure_missing_resource [7512,7539]
name: test_azure_missing_resource [7524,7551]
===
match
---
trailer [5492,5511]
trailer [5504,5523]
===
match
---
string: 'http://localhost:8180' [3379,3402]
string: 'http://localhost:8180' [3385,3408]
===
match
---
operator: , [17178,17179]
operator: , [17190,17191]
===
match
---
argument [40386,40394]
argument [40398,40406]
===
match
---
argument [32357,32373]
argument [32369,32385]
===
match
---
suite [41944,42563]
suite [41956,42575]
===
match
---
parameters [42689,42706]
parameters [42701,42718]
===
match
---
name: url [43013,43016]
name: url [43025,43028]
===
match
---
operator: , [35236,35237]
operator: , [35248,35249]
===
match
---
name: patch [5576,5581]
name: patch [5588,5593]
===
match
---
string: "data" [15759,15765]
string: "data" [15771,15777]
===
match
---
dictorsetmaker [37564,37592]
dictorsetmaker [37576,37604]
===
match
---
operator: = [30222,30223]
operator: = [30234,30235]
===
match
---
atom [10390,10419]
atom [10402,10431]
===
match
---
expr_stmt [41316,41526]
expr_stmt [41328,41538]
===
match
---
name: assert_called_once_with [27979,28002]
name: assert_called_once_with [27991,28014]
===
match
---
expr_stmt [34023,34066]
expr_stmt [34035,34078]
===
match
---
atom_expr [12859,12978]
atom_expr [12871,12990]
===
match
---
trailer [39859,39861]
trailer [39871,39873]
===
match
---
atom_expr [43747,43843]
atom_expr [43759,43855]
===
match
---
trailer [30435,30437]
trailer [30447,30449]
===
match
---
trailer [24652,24659]
trailer [24664,24671]
===
match
---
atom_expr [20352,20381]
atom_expr [20364,20393]
===
match
---
argument [33818,33832]
argument [33830,33844]
===
match
---
name: _VaultClient [21122,21134]
name: _VaultClient [21134,21146]
===
match
---
assert_stmt [17011,17053]
assert_stmt [17023,17065]
===
match
---
expr_stmt [17662,17705]
expr_stmt [17674,17717]
===
match
---
name: kv_engine_version [18627,18644]
name: kv_engine_version [18639,18656]
===
match
---
simple_stmt [17623,17654]
simple_stmt [17635,17666]
===
match
---
simple_stmt [39831,39862]
simple_stmt [39843,39874]
===
match
---
atom_expr [27036,27179]
atom_expr [27048,27191]
===
match
---
name: mount_point [42474,42485]
name: mount_point [42486,42497]
===
match
---
name: secrets [28380,28387]
name: secrets [28392,28399]
===
match
---
simple_stmt [814,840]
simple_stmt [814,840]
===
match
---
string: "http://localhost:8180" [8383,8406]
string: "http://localhost:8180" [8395,8418]
===
match
---
name: mock [17471,17475]
name: mock [17483,17487]
===
match
---
trailer [10733,10762]
trailer [10745,10774]
===
match
---
with_stmt [14821,14933]
with_stmt [14833,14945]
===
match
---
operator: , [35057,35058]
operator: , [35069,35070]
===
match
---
simple_stmt [29122,29765]
simple_stmt [29134,29777]
===
match
---
arglist [32290,32482]
arglist [32302,32494]
===
match
---
simple_stmt [5693,5724]
simple_stmt [5705,5736]
===
match
---
name: patch [22440,22445]
name: patch [22452,22457]
===
match
---
name: cas [41787,41790]
name: cas [41799,41802]
===
match
---
argument [31613,31627]
argument [31625,31639]
===
match
---
simple_stmt [919,933]
simple_stmt [919,933]
===
match
---
string: "scope1,scope2" [9169,9184]
string: "scope1,scope2" [9181,9196]
===
match
---
name: secret_id [3467,3476]
name: secret_id [3479,3488]
===
match
---
number: 1 [31008,31009]
number: 1 [31020,31021]
===
match
---
operator: = [6047,6048]
operator: = [6059,6060]
===
match
---
name: client [14904,14910]
name: client [14916,14922]
===
match
---
operator: { [32123,32124]
operator: { [32135,32136]
===
match
---
name: mock_client [6670,6681]
name: mock_client [6682,6693]
===
match
---
name: auth_type [33377,33386]
name: auth_type [33389,33398]
===
match
---
arglist [15991,16019]
arglist [16003,16031]
===
match
---
name: mock_client [34644,34655]
name: mock_client [34656,34667]
===
match
---
operator: @ [24304,24305]
operator: @ [24316,24317]
===
match
---
operator: , [16520,16521]
operator: , [16532,16533]
===
match
---
string: "path" [40191,40197]
string: "path" [40203,40209]
===
match
---
operator: , [33117,33118]
operator: , [33129,33130]
===
match
---
name: url [23136,23139]
name: url [23148,23151]
===
match
---
operator: , [19271,19272]
operator: , [19283,19284]
===
match
---
string: "approle" [3939,3948]
string: "approle" [3951,3960]
===
match
---
operator: { [29390,29391]
operator: { [29402,29403]
===
match
---
operator: @ [20865,20866]
operator: @ [20877,20878]
===
match
---
arglist [41357,41516]
arglist [41369,41528]
===
match
---
funcdef [21768,22429]
funcdef [21780,22441]
===
match
---
expr_stmt [3085,3293]
expr_stmt [3091,3299]
===
match
---
name: Client [37252,37258]
name: Client [37264,37270]
===
match
---
number: 1 [33526,33527]
number: 1 [33538,33539]
===
match
---
string: 'secret' [27131,27139]
string: 'secret' [27143,27151]
===
match
---
operator: , [20994,20995]
operator: , [21006,21007]
===
match
---
trailer [20684,20694]
trailer [20696,20706]
===
match
---
name: assert_called_with [11169,11187]
name: assert_called_with [11181,11199]
===
match
---
operator: = [42728,42729]
operator: = [42740,42741]
===
match
---
argument [25941,25961]
argument [25953,25973]
===
match
---
operator: = [19771,19772]
operator: = [19783,19784]
===
match
---
simple_stmt [12792,12836]
simple_stmt [12804,12848]
===
match
---
simple_stmt [29030,29061]
simple_stmt [29042,29073]
===
match
---
operator: = [2102,2103]
operator: = [2102,2103]
===
match
---
operator: = [43703,43704]
operator: = [43715,43716]
===
match
---
name: vault_client [31379,31391]
name: vault_client [31391,31403]
===
match
---
operator: = [31440,31441]
operator: = [31452,31453]
===
match
---
argument [2449,2468]
argument [2449,2468]
===
match
---
name: vault_client [27568,27580]
name: vault_client [27580,27592]
===
match
---
string: "pass" [26013,26019]
string: "pass" [26025,26031]
===
match
---
operator: @ [22434,22435]
operator: @ [22446,22447]
===
match
---
trailer [32522,32533]
trailer [32534,32545]
===
match
---
name: read_data [16657,16666]
name: read_data [16669,16678]
===
match
---
atom_expr [16029,16073]
atom_expr [16041,16085]
===
match
---
name: auth [21451,21455]
name: auth [21463,21467]
===
match
---
atom_expr [39938,40133]
atom_expr [39950,40145]
===
match
---
comparison [19379,19414]
comparison [19391,19426]
===
match
---
name: _VaultClient [17798,17810]
name: _VaultClient [17810,17822]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [12641,12705]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [12653,12717]
===
match
---
atom_expr [23219,23283]
atom_expr [23231,23295]
===
match
---
operator: == [24180,24182]
operator: == [24192,24194]
===
match
---
name: keyfile_dict [9477,9489]
name: keyfile_dict [9489,9501]
===
match
---
simple_stmt [37242,37286]
simple_stmt [37254,37298]
===
match
---
trailer [25147,25157]
trailer [25159,25169]
===
match
---
atom_expr [2741,2785]
atom_expr [2747,2791]
===
match
---
name: _VaultClient [24545,24557]
name: _VaultClient [24557,24569]
===
match
---
simple_stmt [28442,28686]
simple_stmt [28454,28698]
===
match
---
name: vault_client [15506,15518]
name: vault_client [15518,15530]
===
match
---
name: client [23204,23210]
name: client [23216,23222]
===
match
---
operator: , [31627,31628]
operator: , [31639,31640]
===
match
---
name: raises [19660,19666]
name: raises [19672,19678]
===
match
---
operator: = [29925,29926]
operator: = [29937,29938]
===
match
---
name: assert_called_with [19237,19255]
name: assert_called_with [19249,19267]
===
match
---
atom_expr [20593,20657]
atom_expr [20605,20669]
===
match
---
name: secrets [40244,40251]
name: secrets [40256,40263]
===
match
---
argument [15624,15650]
argument [15636,15662]
===
match
---
name: kv [41653,41655]
name: kv [41665,41667]
===
match
---
name: Client [42002,42008]
name: Client [42014,42020]
===
match
---
argument [7891,7904]
argument [7903,7916]
===
match
---
arglist [33796,33832]
arglist [33808,33844]
===
match
---
operator: , [19744,19745]
operator: , [19756,19757]
===
match
---
name: auth_mount_point [16534,16550]
name: auth_mount_point [16546,16562]
===
match
---
name: auth [18472,18476]
name: auth [18484,18488]
===
match
---
argument [38118,38145]
argument [38130,38157]
===
match
---
atom_expr [13844,13944]
atom_expr [13856,13956]
===
match
---
argument [31403,31424]
argument [31415,31436]
===
match
---
string: "missing" [30038,30047]
string: "missing" [30050,30059]
===
match
---
name: vault_client [36992,37004]
name: vault_client [37004,37016]
===
match
---
trailer [20677,20684]
trailer [20689,20696]
===
match
---
operator: = [8464,8465]
operator: = [8476,8477]
===
match
---
expr_stmt [21854,21897]
expr_stmt [21866,21909]
===
match
---
operator: } [29650,29651]
operator: } [29662,29663]
===
match
---
name: radius_secret [33474,33487]
name: radius_secret [33486,33499]
===
match
---
name: auth_type [10469,10478]
name: auth_type [10481,10490]
===
match
---
atom_expr [25848,25877]
atom_expr [25860,25889]
===
match
---
simple_stmt [31370,31444]
simple_stmt [31382,31456]
===
match
---
argument [39964,39982]
argument [39976,39994]
===
match
---
dotted_name [18651,18661]
dotted_name [18663,18673]
===
match
---
operator: = [33487,33488]
operator: = [33499,33500]
===
match
---
operator: = [14404,14405]
operator: = [14416,14417]
===
match
---
operator: = [28738,28739]
operator: = [28750,28751]
===
match
---
trailer [23334,23336]
trailer [23346,23348]
===
match
---
name: secret_path [41742,41753]
name: secret_path [41754,41765]
===
match
---
trailer [9422,9441]
trailer [9434,9453]
===
match
---
name: vault_client [38176,38188]
name: vault_client [38188,38200]
===
match
---
argument [16494,16520]
argument [16506,16532]
===
match
---
string: 'auth' [38815,38821]
string: 'auth' [38827,38833]
===
match
---
trailer [31908,31920]
trailer [31920,31932]
===
match
---
name: assert_called_with [2680,2698]
name: assert_called_with [2686,2704]
===
match
---
name: auth_type [29815,29824]
name: auth_type [29827,29836]
===
match
---
argument [8424,8437]
argument [8436,8449]
===
match
---
operator: { [36010,36011]
operator: { [36022,36023]
===
match
---
suite [17191,17465]
suite [17203,17477]
===
match
---
trailer [29058,29060]
trailer [29070,29072]
===
match
---
operator: , [7272,7273]
operator: , [7284,7285]
===
match
---
trailer [3049,3062]
trailer [3055,3068]
===
match
---
trailer [25512,25546]
trailer [25524,25558]
===
match
---
atom_expr [14206,14222]
atom_expr [14218,14234]
===
match
---
trailer [1674,1687]
trailer [1674,1687]
===
match
---
name: _VaultClient [39938,39950]
name: _VaultClient [39950,39962]
===
match
---
simple_stmt [9000,9066]
simple_stmt [9012,9078]
===
match
---
funcdef [33921,34408]
funcdef [33933,34420]
===
match
---
atom_expr [14018,14048]
atom_expr [14030,14060]
===
match
---
trailer [42072,42288]
trailer [42084,42300]
===
match
---
name: mock_hvac [4863,4872]
name: mock_hvac [4875,4884]
===
match
---
operator: , [15737,15738]
operator: , [15749,15750]
===
match
---
name: client [10661,10667]
name: client [10673,10679]
===
match
---
operator: , [35654,35655]
operator: , [35666,35667]
===
match
---
argument [26268,26283]
argument [26280,26295]
===
match
---
string: 'wrap_info' [29680,29691]
string: 'wrap_info' [29692,29703]
===
match
---
name: Client [6087,6093]
name: Client [6099,6105]
===
match
---
operator: , [20743,20744]
operator: , [20755,20756]
===
match
---
name: client [22235,22241]
name: client [22247,22253]
===
match
---
name: assert_called_with [26172,26190]
name: assert_called_with [26184,26202]
===
match
---
decorator [14054,14132]
decorator [14066,14144]
===
match
---
decorator [8689,8767]
decorator [8701,8779]
===
match
---
trailer [20043,20050]
trailer [20055,20062]
===
match
---
name: mock_hvac [1286,1295]
name: mock_hvac [1286,1295]
===
match
---
name: assert_called_with [21388,21406]
name: assert_called_with [21400,21418]
===
match
---
trailer [21472,21491]
trailer [21484,21503]
===
match
---
expr_stmt [22988,23031]
expr_stmt [23000,23043]
===
match
---
name: gcp_key_path [9132,9144]
name: gcp_key_path [9144,9156]
===
match
---
operator: , [23134,23135]
operator: , [23146,23147]
===
match
---
name: assert_called_with [5272,5290]
name: assert_called_with [5284,5302]
===
match
---
argument [40825,40852]
argument [40837,40864]
===
match
---
expr_stmt [8888,8931]
expr_stmt [8900,8943]
===
match
---
decorated [16130,17054]
decorated [16142,17066]
===
match
---
dotted_name [22827,22837]
dotted_name [22839,22849]
===
match
---
operator: , [31130,31131]
operator: , [31142,31143]
===
match
---
trailer [33753,33756]
trailer [33765,33768]
===
match
---
string: "http://localhost:8180" [14419,14442]
string: "http://localhost:8180" [14431,14454]
===
match
---
name: assert_called_with [12228,12246]
name: assert_called_with [12240,12258]
===
match
---
atom_expr [16391,16610]
atom_expr [16403,16622]
===
match
---
param [20996,21005]
param [21008,21017]
===
match
---
name: Client [12362,12368]
name: Client [12374,12380]
===
match
---
operator: = [38953,38954]
operator: = [38965,38966]
===
match
---
name: mock_hvac [28262,28271]
name: mock_hvac [28274,28283]
===
match
---
operator: , [4338,4339]
operator: , [4350,4351]
===
match
---
name: auth_type [42086,42095]
name: auth_type [42098,42107]
===
match
---
trailer [8955,8968]
trailer [8967,8980]
===
match
---
simple_stmt [4412,4477]
simple_stmt [4424,4489]
===
match
---
name: return_value [3050,3062]
name: return_value [3056,3068]
===
match
---
operator: @ [19802,19803]
operator: @ [19814,19815]
===
match
---
trailer [23688,23701]
trailer [23700,23713]
===
match
---
trailer [32670,32708]
trailer [32682,32720]
===
match
---
string: "radius" [28493,28501]
string: "radius" [28505,28513]
===
match
---
operator: = [12857,12858]
operator: = [12869,12870]
===
match
---
operator: , [6789,6790]
operator: , [6801,6802]
===
match
---
trailer [6177,6196]
trailer [6189,6208]
===
match
---
name: radius_port [36734,36745]
name: radius_port [36746,36757]
===
match
---
name: mock_client [2044,2055]
name: mock_client [2044,2055]
===
match
---
simple_stmt [19941,19972]
simple_stmt [19953,19984]
===
match
---
operator: = [11620,11621]
operator: = [11632,11633]
===
match
---
operator: = [39369,39370]
operator: = [39381,39382]
===
match
---
dotted_name [3616,3626]
dotted_name [3628,3638]
===
match
---
name: url [32454,32457]
name: url [32466,32469]
===
match
---
operator: = [36353,36354]
operator: = [36365,36366]
===
match
---
trailer [2372,2385]
trailer [2372,2385]
===
match
---
atom_expr [32510,32556]
atom_expr [32522,32568]
===
match
---
name: mock [20866,20870]
name: mock [20878,20882]
===
match
---
atom_expr [13451,13467]
atom_expr [13463,13479]
===
match
---
operator: , [7828,7829]
operator: , [7840,7841]
===
match
---
name: v1 [28811,28813]
name: v1 [28823,28825]
===
match
---
param [20287,20292]
param [20299,20304]
===
match
---
argument [19019,19043]
argument [19031,19055]
===
match
---
trailer [12450,12469]
trailer [12462,12481]
===
match
---
parameters [24412,24429]
parameters [24424,24441]
===
match
---
trailer [12440,12450]
trailer [12452,12462]
===
match
---
param [3733,3742]
param [3745,3754]
===
match
---
trailer [13850,13855]
trailer [13862,13867]
===
match
---
operator: , [34772,34773]
operator: , [34784,34785]
===
match
---
argument [1738,1758]
argument [1738,1758]
===
match
---
atom_expr [9783,9813]
atom_expr [9795,9825]
===
match
---
testlist_comp [10933,10951]
testlist_comp [10945,10963]
===
match
---
simple_stmt [24530,24623]
simple_stmt [24542,24635]
===
match
---
operator: @ [9908,9909]
operator: @ [9920,9921]
===
match
---
operator: = [18312,18313]
operator: = [18324,18325]
===
match
---
argument [42946,42966]
argument [42958,42978]
===
match
---
operator: , [40197,40198]
operator: , [40209,40210]
===
match
---
parameters [25102,25119]
parameters [25114,25131]
===
match
---
dictorsetmaker [40369,40383]
dictorsetmaker [40381,40395]
===
match
---
atom_expr [19113,19132]
atom_expr [19125,19144]
===
match
---
decorated [41076,41804]
decorated [41088,41816]
===
match
---
argument [20155,20182]
argument [20167,20194]
===
match
---
name: url [20510,20513]
name: url [20522,20525]
===
match
---
operator: = [20718,20719]
operator: = [20730,20731]
===
match
---
suite [39603,39682]
suite [39615,39694]
===
match
---
atom_expr [43159,43248]
atom_expr [43171,43260]
===
match
---
string: "role" [5423,5429]
string: "role" [5435,5441]
===
match
---
atom_expr [23292,23336]
atom_expr [23304,23348]
===
match
---
expr_stmt [13734,13762]
expr_stmt [13746,13774]
===
match
---
name: secret_path [37025,37036]
name: secret_path [37037,37048]
===
match
---
name: mock_client [1247,1258]
name: mock_client [1247,1258]
===
match
---
name: url [20629,20632]
name: url [20641,20644]
===
match
---
argument [35424,35458]
argument [35436,35470]
===
match
---
operator: = [1474,1475]
operator: = [1474,1475]
===
match
---
string: "http://localhost:8180" [42254,42277]
string: "http://localhost:8180" [42266,42289]
===
match
---
operator: = [6817,6818]
operator: = [6829,6830]
===
match
---
string: 'lease_duration' [30700,30716]
string: 'lease_duration' [30712,30728]
===
match
---
name: mount_point [28016,28027]
name: mount_point [28028,28039]
===
match
---
trailer [21933,22116]
trailer [21945,22128]
===
match
---
argument [3126,3145]
argument [3132,3151]
===
match
---
atom_expr [17798,17997]
atom_expr [17810,18009]
===
match
---
string: "radhost" [41401,41410]
string: "radhost" [41413,41422]
===
match
---
name: InvalidPath [27546,27557]
name: InvalidPath [27558,27569]
===
match
---
parameters [29003,29020]
parameters [29015,29032]
===
match
---
name: get_secret_including_metadata [38189,38218]
name: get_secret_including_metadata [38201,38230]
===
match
---
simple_stmt [23981,24010]
simple_stmt [23993,24022]
===
match
---
name: _VaultClient [23856,23868]
name: _VaultClient [23868,23880]
===
match
---
name: secrets [36270,36277]
name: secrets [36282,36289]
===
match
---
trailer [12181,12198]
trailer [12193,12210]
===
match
---
name: client [25363,25369]
name: client [25375,25381]
===
match
---
operator: , [7544,7545]
operator: , [7556,7557]
===
match
---
name: return_value [40617,40629]
name: return_value [40629,40641]
===
match
---
simple_stmt [1423,1478]
simple_stmt [1423,1478]
===
match
---
string: 'missing' [32698,32707]
string: 'missing' [32710,32719]
===
match
---
string: 'auth' [37914,37920]
string: 'auth' [37926,37932]
===
match
---
operator: , [14744,14745]
operator: , [14756,14757]
===
match
---
param [8080,8089]
param [8092,8101]
===
match
---
name: mock [33840,33844]
name: mock [33852,33856]
===
match
---
name: client [12059,12065]
name: client [12071,12077]
===
match
---
argument [24704,24731]
argument [24716,24743]
===
match
---
operator: , [36192,36193]
operator: , [36204,36205]
===
match
---
string: 'path' [43973,43979]
string: 'path' [43985,43991]
===
match
---
parameters [33957,33974]
parameters [33969,33986]
===
match
---
name: mock_client [39831,39842]
name: mock_client [39843,39854]
===
match
---
operator: = [14418,14419]
operator: = [14430,14431]
===
match
---
name: MagicMock [8119,8128]
name: MagicMock [8131,8140]
===
match
---
operator: = [18194,18195]
operator: = [18206,18207]
===
match
---
atom_expr [18139,18155]
atom_expr [18151,18167]
===
match
---
name: assert_called_with [16982,17000]
name: assert_called_with [16994,17012]
===
match
---
param [39805,39810]
param [39817,39822]
===
match
---
operator: = [12312,12313]
operator: = [12324,12325]
===
match
---
name: gcp [9627,9630]
name: gcp [9639,9642]
===
match
---
string: 'data' [33202,33208]
string: 'data' [33214,33220]
===
match
---
trailer [5271,5290]
trailer [5283,5302]
===
match
---
name: url [27740,27743]
name: url [27752,27755]
===
match
---
operator: , [12304,12305]
operator: , [12316,12317]
===
match
---
string: 'http://localhost:8180' [20633,20656]
string: 'http://localhost:8180' [20645,20668]
===
match
---
operator: = [12894,12895]
operator: = [12906,12907]
===
match
---
string: "http://localhost:8180" [31327,31350]
string: "http://localhost:8180" [31339,31362]
===
match
---
operator: , [12017,12018]
operator: , [12029,12030]
===
match
---
trailer [42436,42460]
trailer [42448,42472]
===
match
---
name: mock_client [30499,30510]
name: mock_client [30511,30522]
===
match
---
name: return_value [8956,8968]
name: return_value [8968,8980]
===
match
---
expr_stmt [5218,5246]
expr_stmt [5230,5258]
===
match
---
atom [35588,36237]
atom [35600,36249]
===
match
---
name: assert_called_once_with [36305,36328]
name: assert_called_once_with [36317,36340]
===
match
---
number: 2 [18609,18610]
number: 2 [18621,18622]
===
match
---
simple_stmt [22610,22654]
simple_stmt [22622,22666]
===
match
---
number: 1 [34405,34406]
number: 1 [34417,34418]
===
match
---
name: test_custom_mount_point [1569,1592]
name: test_custom_mount_point [1569,1592]
===
match
---
name: Client [24678,24684]
name: Client [24690,24696]
===
match
---
trailer [25184,25197]
trailer [25196,25209]
===
match
---
import_as_names [961,984]
import_as_names [961,984]
===
match
---
argument [19726,19744]
argument [19738,19756]
===
match
---
string: "radius" [39974,39982]
string: "radius" [39986,39994]
===
match
---
expr_stmt [4922,4965]
expr_stmt [4934,4977]
===
match
---
simple_stmt [32565,32601]
simple_stmt [32577,32613]
===
match
---
name: read_secret [32996,33007]
name: read_secret [33008,33019]
===
match
---
string: '2020-03-16T21:01:43.331126Z' [38562,38591]
string: '2020-03-16T21:01:43.331126Z' [38574,38603]
===
match
---
dotted_name [12630,12640]
dotted_name [12642,12652]
===
match
---
name: url [40095,40098]
name: url [40107,40110]
===
match
---
comparison [23463,23499]
comparison [23475,23511]
===
match
---
trailer [26408,26426]
trailer [26420,26438]
===
match
---
name: mock [6613,6617]
name: mock [6625,6629]
===
match
---
operator: = [43950,43951]
operator: = [43962,43963]
===
match
---
operator: = [26813,26814]
operator: = [26825,26826]
===
match
---
operator: , [25990,25991]
operator: , [26002,26003]
===
match
---
decorator [33839,33917]
decorator [33851,33929]
===
match
---
argument [3451,3465]
argument [3463,3477]
===
match
---
operator: , [40359,40360]
operator: , [40371,40372]
===
match
---
name: secret_path [42334,42345]
name: secret_path [42346,42357]
===
match
---
assert_stmt [33690,33725]
assert_stmt [33702,33737]
===
match
---
import_from [933,984]
import_from [933,984]
===
match
---
name: auth_type [2093,2102]
name: auth_type [2093,2102]
===
match
---
name: radius_port [43603,43614]
name: radius_port [43615,43626]
===
match
---
argument [29882,29898]
argument [29894,29910]
===
match
---
name: VaultError [19667,19677]
name: VaultError [19679,19689]
===
match
---
argument [28038,28052]
argument [28050,28064]
===
match
---
trailer [6390,6392]
trailer [6402,6404]
===
match
---
argument [20488,20508]
argument [20500,20520]
===
match
---
string: "ldap" [18941,18947]
string: "ldap" [18953,18959]
===
match
---
simple_stmt [9232,9261]
simple_stmt [9244,9273]
===
match
---
name: mock_hvac [37242,37251]
name: mock_hvac [37254,37263]
===
match
---
name: mock_hvac [33964,33973]
name: mock_hvac [33976,33985]
===
match
---
trailer [34669,34690]
trailer [34681,34702]
===
match
---
string: "http://localhost:8180" [23140,23163]
string: "http://localhost:8180" [23152,23175]
===
match
---
name: role [15148,15152]
name: role [15160,15164]
===
match
---
assert_stmt [38250,38850]
assert_stmt [38262,38862]
===
match
---
string: "path.json" [10893,10904]
string: "path.json" [10905,10916]
===
match
---
argument [7252,7272]
argument [7264,7284]
===
match
---
argument [40903,40959]
argument [40915,40971]
===
match
---
string: 'pass' [4350,4356]
string: 'pass' [4362,4368]
===
match
---
trailer [26591,26601]
trailer [26603,26613]
===
match
---
name: client [6984,6990]
name: client [6996,7002]
===
match
---
string: 'http://localhost:8180' [18432,18455]
string: 'http://localhost:8180' [18444,18467]
===
match
---
name: mock_hvac [20352,20361]
name: mock_hvac [20364,20373]
===
match
---
operator: = [13652,13653]
operator: = [13664,13665]
===
match
---
operator: = [33455,33456]
operator: = [33467,33468]
===
match
---
trailer [30135,30138]
trailer [30147,30150]
===
match
---
with_item [23729,23774]
with_item [23741,23786]
===
match
---
name: mock_client [21886,21897]
name: mock_client [21898,21909]
===
match
---
operator: = [26049,26050]
operator: = [26061,26062]
===
match
---
atom_expr [20037,20085]
atom_expr [20049,20097]
===
match
---
operator: = [7931,7932]
operator: = [7943,7944]
===
match
---
string: 'destroyed' [35921,35932]
string: 'destroyed' [35933,35944]
===
match
---
decorator [15287,15365]
decorator [15299,15377]
===
match
---
name: mock_hvac [40600,40609]
name: mock_hvac [40612,40621]
===
match
---
name: mock_hvac [30387,30396]
name: mock_hvac [30399,30408]
===
match
---
operator: , [38416,38417]
operator: , [38428,38429]
===
match
---
trailer [18427,18456]
trailer [18439,18468]
===
match
---
name: assert_called_with [16801,16819]
name: assert_called_with [16813,16831]
===
match
---
trailer [19225,19230]
trailer [19237,19242]
===
match
---
name: configure [21463,21472]
name: configure [21475,21484]
===
match
---
name: mock_client [8920,8931]
name: mock_client [8932,8943]
===
match
---
string: 'value' [32124,32131]
string: 'value' [32136,32143]
===
match
---
trailer [5290,5319]
trailer [5302,5331]
===
match
---
atom_expr [7580,7596]
atom_expr [7592,7608]
===
match
---
argument [28054,28066]
argument [28066,28078]
===
match
---
operator: , [3977,3978]
operator: , [3989,3990]
===
match
---
name: vault_client [9783,9795]
name: vault_client [9795,9807]
===
match
---
trailer [13033,13040]
trailer [13045,13052]
===
match
---
string: "http://localhost:8180" [22082,22105]
string: "http://localhost:8180" [22094,22117]
===
match
---
name: mount_point [13924,13935]
name: mount_point [13936,13947]
===
match
---
operator: , [25787,25788]
operator: , [25799,25800]
===
match
---
name: url [25436,25439]
name: url [25448,25451]
===
match
---
atom_expr [12528,12572]
atom_expr [12540,12584]
===
match
---
trailer [25561,25578]
trailer [25573,25590]
===
match
---
name: radius_port [32357,32368]
name: radius_port [32369,32380]
===
match
---
argument [37987,38005]
argument [37999,38017]
===
match
---
name: radius_secret [38084,38097]
name: radius_secret [38096,38109]
===
match
---
operator: , [18273,18274]
operator: , [18285,18286]
===
match
---
string: "other" [26050,26057]
string: "other" [26062,26069]
===
match
---
trailer [27061,27081]
trailer [27073,27093]
===
match
---
atom_expr [18813,18829]
atom_expr [18825,18841]
===
match
---
operator: = [38174,38175]
operator: = [38186,38187]
===
match
---
arglist [16899,16948]
arglist [16911,16960]
===
match
---
operator: { [37356,37357]
operator: { [37368,37369]
===
match
---
string: 'wrap_info' [33242,33253]
string: 'wrap_info' [33254,33265]
===
match
---
string: "aws_iam" [5025,5034]
string: "aws_iam" [5037,5046]
===
match
---
operator: , [35110,35111]
operator: , [35122,35123]
===
match
---
trailer [28825,28849]
trailer [28837,28861]
===
match
---
trailer [10682,10689]
trailer [10694,10701]
===
match
---
trailer [42001,42008]
trailer [42013,42020]
===
match
---
name: patch [28088,28093]
name: patch [28100,28105]
===
match
---
name: url [24704,24707]
name: url [24716,24719]
===
match
---
operator: = [6703,6704]
operator: = [6715,6716]
===
match
---
atom_expr [6613,6629]
atom_expr [6625,6641]
===
match
---
trailer [11714,11727]
trailer [11726,11739]
===
match
---
string: 'lease_id' [34786,34796]
string: 'lease_id' [34798,34808]
===
match
---
trailer [16800,16819]
trailer [16812,16831]
===
match
---
arglist [43784,43842]
arglist [43796,43854]
===
match
---
operator: , [37450,37451]
operator: , [37462,37463]
===
match
---
name: Client [14639,14645]
name: Client [14651,14657]
===
match
---
string: '' [29275,29277]
string: '' [29287,29289]
===
match
---
name: get_secret [28716,28726]
name: get_secret [28728,28738]
===
match
---
argument [6910,6926]
argument [6922,6938]
===
match
---
trailer [8155,8168]
trailer [8167,8180]
===
match
---
simple_stmt [24018,24083]
simple_stmt [24030,24095]
===
match
---
trailer [32646,32670]
trailer [32658,32682]
===
match
---
name: patch [1122,1127]
name: patch [1122,1127]
===
match
---
atom_expr [15186,15230]
atom_expr [15198,15242]
===
match
---
name: mock_client [34624,34635]
name: mock_client [34636,34647]
===
match
---
name: patch [4737,4742]
name: patch [4749,4754]
===
match
---
atom [35791,35992]
atom [35803,36004]
===
match
---
operator: = [22287,22288]
operator: = [22299,22300]
===
match
---
name: vault_client [4218,4230]
name: vault_client [4230,4242]
===
match
---
trailer [34666,34669]
trailer [34678,34681]
===
match
---
atom_expr [9542,9606]
atom_expr [9554,9618]
===
match
---
trailer [23796,23802]
trailer [23808,23814]
===
match
---
string: 'renewable' [33131,33142]
string: 'renewable' [33143,33154]
===
match
---
argument [18524,18539]
argument [18536,18551]
===
match
---
operator: , [37482,37483]
operator: , [37494,37495]
===
match
---
name: url [34195,34198]
name: url [34207,34210]
===
match
---
simple_stmt [9771,9814]
simple_stmt [9783,9826]
===
match
---
operator: { [41599,41600]
operator: { [41611,41612]
===
match
---
name: self [24413,24417]
name: self [24425,24429]
===
match
---
name: Client [39880,39886]
name: Client [39892,39898]
===
match
---
name: gcp [12437,12440]
name: gcp [12449,12452]
===
match
---
operator: , [36226,36227]
operator: , [36238,36239]
===
match
---
name: is_authenticated [20771,20787]
name: is_authenticated [20783,20799]
===
match
---
name: mock [14604,14608]
name: mock [14616,14620]
===
match
---
string: 'created_time' [35813,35827]
string: 'created_time' [35825,35839]
===
match
---
comparison [11205,11240]
comparison [11217,11252]
===
match
---
atom [32123,32141]
atom [32135,32153]
===
match
---
name: MagicMock [41972,41981]
name: MagicMock [41984,41993]
===
match
---
argument [19679,19698]
argument [19691,19710]
===
match
---
comparison [24961,24997]
comparison [24973,25009]
===
match
---
name: token [13141,13146]
name: token [13153,13158]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [22838,22902]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [22850,22914]
===
match
---
name: _VaultClient [18231,18243]
name: _VaultClient [18243,18255]
===
match
---
comparison [27013,27027]
comparison [27025,27039]
===
match
---
simple_stmt [4630,4675]
simple_stmt [4642,4687]
===
match
---
trailer [11006,11035]
trailer [11018,11047]
===
match
---
operator: = [14602,14603]
operator: = [14614,14615]
===
match
---
trailer [7056,7085]
trailer [7068,7097]
===
match
---
decorated [24304,24998]
decorated [24316,25010]
===
match
---
name: auth_userpass [26235,26248]
name: auth_userpass [26247,26260]
===
match
---
name: kv [38879,38881]
name: kv [38891,38893]
===
match
---
operator: @ [20189,20190]
operator: @ [20201,20202]
===
match
---
name: mock_hvac [12352,12361]
name: mock_hvac [12364,12373]
===
match
---
name: mock_client [19941,19952]
name: mock_client [19953,19964]
===
match
---
operator: , [32101,32102]
operator: , [32113,32114]
===
match
---
simple_stmt [21055,21099]
simple_stmt [21067,21111]
===
match
---
name: mock [8690,8694]
name: mock [8702,8706]
===
match
---
decorated [19802,20184]
decorated [19814,20196]
===
match
---
simple_stmt [37203,37234]
simple_stmt [37215,37246]
===
match
---
expr_stmt [9232,9260]
expr_stmt [9244,9272]
===
match
---
operator: = [31326,31327]
operator: = [31338,31339]
===
match
---
name: mock_client [2388,2399]
name: mock_client [2388,2399]
===
match
---
name: mock_hvac [2356,2365]
name: mock_hvac [2356,2365]
===
match
---
atom_expr [8196,8257]
atom_expr [8208,8269]
===
match
---
param [34533,34542]
param [34545,34554]
===
match
---
operator: = [4299,4300]
operator: = [4311,4312]
===
match
---
operator: = [18811,18812]
operator: = [18823,18824]
===
match
---
operator: = [35561,35562]
operator: = [35573,35574]
===
match
---
trailer [2345,2347]
trailer [2345,2347]
===
match
---
operator: , [10904,10905]
operator: , [10916,10917]
===
match
---
trailer [38928,39002]
trailer [38940,39014]
===
match
---
operator: , [3731,3732]
operator: , [3743,3744]
===
match
---
operator: = [3378,3379]
operator: = [3384,3385]
===
match
---
name: self [22545,22549]
name: self [22557,22561]
===
match
---
expr_stmt [31830,31873]
expr_stmt [31842,31885]
===
match
---
atom_expr [8863,8879]
atom_expr [8875,8891]
===
match
---
operator: = [25233,25234]
operator: = [25245,25246]
===
match
---
name: vault_client [27900,27912]
name: vault_client [27912,27924]
===
match
---
name: vault_client [21906,21918]
name: vault_client [21918,21930]
===
match
---
param [36508,36513]
param [36520,36525]
===
match
---
trailer [15815,15822]
trailer [15827,15834]
===
match
---
trailer [27955,27958]
trailer [27967,27970]
===
match
---
name: url [15912,15915]
name: url [15924,15927]
===
match
---
name: secret_path [31403,31414]
name: secret_path [31415,31426]
===
match
---
expr_stmt [20313,20343]
expr_stmt [20325,20355]
===
match
---
arglist [31192,31351]
arglist [31204,31363]
===
match
---
name: auth_kubernetes [15956,15971]
name: auth_kubernetes [15968,15983]
===
match
---
atom_expr [24274,24298]
atom_expr [24286,24310]
===
match
---
operator: , [910,911]
operator: , [910,911]
===
match
---
string: 'scope1' [9504,9512]
string: 'scope1' [9516,9524]
===
match
---
name: mock [30421,30425]
name: mock [30433,30437]
===
match
---
param [1947,1952]
param [1947,1952]
===
match
---
argument [42881,42902]
argument [42893,42914]
===
match
---
name: mock_hvac [24668,24677]
name: mock_hvac [24680,24689]
===
match
---
operator: = [24543,24544]
operator: = [24555,24556]
===
match
---
operator: = [21919,21920]
operator: = [21931,21932]
===
match
---
simple_stmt [20404,20548]
simple_stmt [20416,20560]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [17071,17135]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [17083,17147]
===
match
---
operator: == [3576,3578]
operator: == [3588,3590]
===
match
---
name: mock [29044,29048]
name: mock [29056,29060]
===
match
---
name: scopes [9496,9502]
name: scopes [9508,9514]
===
match
---
string: 'created_time' [30849,30863]
string: 'created_time' [30861,30875]
===
match
---
parameters [16258,16275]
parameters [16270,16287]
===
match
---
string: "other" [7298,7305]
string: "other" [7310,7317]
===
match
---
name: secret_path [40179,40190]
name: secret_path [40191,40202]
===
match
---
simple_stmt [9269,9334]
simple_stmt [9281,9346]
===
match
---
name: mock_client [8171,8182]
name: mock_client [8183,8194]
===
match
---
operator: , [38494,38495]
operator: , [38506,38507]
===
match
---
string: 'pass' [4579,4585]
string: 'pass' [4591,4597]
===
match
---
atom_expr [30113,30256]
atom_expr [30125,30268]
===
match
---
comparison [21645,21680]
comparison [21657,21692]
===
match
---
number: 1 [38705,38706]
number: 1 [38717,38718]
===
match
---
expr_stmt [34553,34583]
expr_stmt [34565,34595]
===
match
---
trailer [12570,12572]
trailer [12582,12584]
===
match
---
name: patch [26438,26443]
name: patch [26450,26455]
===
match
---
trailer [6717,6975]
trailer [6729,6987]
===
match
---
simple_stmt [41263,41307]
simple_stmt [41275,41319]
===
match
---
trailer [20713,20755]
trailer [20725,20767]
===
match
---
number: 1 [31441,31442]
number: 1 [31453,31454]
===
match
---
name: mock [39688,39692]
name: mock [39700,39704]
===
match
---
name: url [6113,6116]
name: url [6125,6128]
===
match
---
string: 'lease_id' [30640,30650]
string: 'lease_id' [30652,30662]
===
match
---
name: vault_client [15251,15263]
name: vault_client [15263,15275]
===
match
---
operator: = [28061,28062]
operator: = [28073,28074]
===
match
---
decorator [18650,18728]
decorator [18662,18740]
===
match
---
string: 'auth' [33303,33309]
string: 'auth' [33315,33321]
===
match
---
simple_stmt [40561,40592]
simple_stmt [40573,40604]
===
match
---
assert_stmt [24255,24298]
assert_stmt [24267,24310]
===
match
---
trailer [26171,26190]
trailer [26183,26202]
===
match
---
funcdef [15369,16125]
funcdef [15381,16137]
===
match
---
param [8801,8822]
param [8813,8834]
===
match
---
name: url [2486,2489]
name: url [2486,2489]
===
match
---
string: "secret" [23463,23471]
string: "secret" [23475,23483]
===
match
---
operator: , [28633,28634]
operator: , [28645,28646]
===
match
---
simple_stmt [39616,39682]
simple_stmt [39628,39694]
===
match
---
name: return_value [8156,8168]
name: return_value [8168,8180]
===
match
---
operator: , [43589,43590]
operator: , [43601,43602]
===
match
---
trailer [12058,12065]
trailer [12070,12077]
===
match
---
atom [11795,11824]
atom [11807,11836]
===
match
---
name: _VaultClient [23055,23067]
name: _VaultClient [23067,23079]
===
match
---
argument [7286,7305]
argument [7298,7317]
===
match
---
name: url [6842,6845]
name: url [6854,6857]
===
match
---
name: self [18099,18103]
name: self [18111,18115]
===
match
---
operator: , [43381,43382]
operator: , [43393,43394]
===
match
---
parameters [2967,2984]
parameters [2973,2990]
===
match
---
name: method [43829,43835]
name: method [43841,43847]
===
match
---
name: url [35460,35463]
name: url [35472,35475]
===
match
---
name: client [9615,9621]
name: client [9627,9633]
===
match
---
number: 8110 [27688,27692]
number: 8110 [27700,27704]
===
match
---
trailer [7621,7634]
trailer [7633,7646]
===
match
---
operator: = [26125,26126]
operator: = [26137,26138]
===
match
---
param [29004,29009]
param [29016,29021]
===
match
---
atom_expr [41263,41292]
atom_expr [41275,41304]
===
match
---
name: mock_hvac [16324,16333]
name: mock_hvac [16336,16345]
===
match
---
trailer [23235,23254]
trailer [23247,23266]
===
match
---
operator: = [17958,17959]
operator: = [17970,17971]
===
match
---
argument [26004,26019]
argument [26016,26031]
===
match
---
name: is_authenticated [12535,12551]
name: is_authenticated [12547,12563]
===
match
---
string: "http://localhost:8180" [19061,19084]
string: "http://localhost:8180" [19073,19096]
===
match
---
argument [23882,23899]
argument [23894,23911]
===
match
---
operator: = [4987,4988]
operator: = [4999,5000]
===
match
---
operator: , [11547,11548]
operator: , [11559,11560]
===
match
---
atom_expr [27355,27371]
atom_expr [27367,27383]
===
match
---
argument [31289,31309]
argument [31301,31321]
===
match
---
argument [27641,27662]
argument [27653,27674]
===
match
---
argument [24558,24592]
argument [24570,24604]
===
match
---
expr_stmt [20352,20395]
expr_stmt [20364,20407]
===
match
---
trailer [31809,31819]
trailer [31821,31831]
===
match
---
decorator [11443,11521]
decorator [11455,11533]
===
match
---
name: mock_open [15739,15748]
name: mock_open [15751,15760]
===
match
---
name: vault_client [3085,3097]
name: vault_client [3091,3103]
===
match
---
operator: , [22000,22001]
operator: , [22012,22013]
===
match
---
arglist [43196,43247]
arglist [43208,43259]
===
match
---
operator: = [15758,15759]
operator: = [15770,15771]
===
match
---
expr_stmt [11647,11690]
expr_stmt [11659,11702]
===
match
---
assert_stmt [27851,27872]
assert_stmt [27863,27884]
===
match
---
operator: == [13247,13249]
operator: == [13259,13261]
===
match
---
operator: , [26098,26099]
operator: , [26110,26111]
===
match
---
name: mock_get_scopes [8940,8955]
name: mock_get_scopes [8952,8967]
===
match
---
decorator [1839,1917]
decorator [1839,1917]
===
match
---
argument [33444,33460]
argument [33456,33472]
===
match
---
string: "http://localhost:8180" [11994,12017]
string: "http://localhost:8180" [12006,12029]
===
match
---
trailer [1667,1674]
trailer [1667,1674]
===
match
---
trailer [7367,7369]
trailer [7379,7381]
===
match
---
argument [6210,6231]
argument [6222,6243]
===
match
---
argument [19768,19795]
argument [19780,19807]
===
match
---
operator: , [29932,29933]
operator: , [29944,29945]
===
match
---
operator: , [6926,6927]
operator: , [6938,6939]
===
match
---
operator: , [5883,5884]
operator: , [5895,5896]
===
match
---
name: mock_hvac [17239,17248]
name: mock_hvac [17251,17260]
===
match
---
name: Client [8149,8155]
name: Client [8161,8167]
===
match
---
atom_expr [14382,14443]
atom_expr [14394,14455]
===
match
---
string: 'lease_id' [38337,38347]
string: 'lease_id' [38349,38359]
===
match
---
trailer [2596,2603]
trailer [2596,2603]
===
match
---
trailer [28469,28685]
trailer [28481,28697]
===
match
---
trailer [3022,3024]
trailer [3028,3030]
===
match
---
operator: == [7387,7389]
operator: == [7399,7401]
===
match
---
name: assert_called_with [23316,23334]
name: assert_called_with [23328,23346]
===
match
---
name: url [20155,20158]
name: url [20167,20170]
===
match
---
atom_expr [39870,39899]
atom_expr [39882,39911]
===
match
---
expr_stmt [42755,42798]
expr_stmt [42767,42810]
===
match
---
operator: = [5024,5025]
operator: = [5036,5037]
===
match
---
argument [13141,13175]
argument [13153,13187]
===
match
---
expr_stmt [2408,2541]
expr_stmt [2408,2541]
===
match
---
simple_stmt [33734,33834]
simple_stmt [33746,33846]
===
match
---
argument [43700,43727]
argument [43712,43739]
===
match
---
name: url [23255,23258]
name: url [23267,23270]
===
match
---
operator: } [33325,33326]
operator: } [33337,33338]
===
match
---
name: url [18428,18431]
name: url [18440,18443]
===
match
---
atom_expr [34090,34266]
atom_expr [34102,34278]
===
match
---
string: "pass" [43647,43653]
string: "pass" [43659,43665]
===
match
---
trailer [14645,14658]
trailer [14657,14670]
===
match
---
operator: , [17406,17407]
operator: , [17418,17419]
===
match
---
operator: , [35714,35715]
operator: , [35726,35727]
===
match
---
operator: } [38837,38838]
operator: } [38849,38850]
===
match
---
string: "path" [43796,43802]
string: "path" [43808,43814]
===
match
---
name: secret [20730,20736]
name: secret [20742,20748]
===
match
---
name: token [12905,12910]
name: token [12917,12922]
===
match
---
operator: = [24597,24598]
operator: = [24609,24610]
===
match
---
name: key_id [6883,6889]
name: key_id [6895,6901]
===
match
---
name: patch [1489,1494]
name: patch [1489,1494]
===
match
---
expr_stmt [41263,41306]
expr_stmt [41275,41318]
===
match
---
string: 'warnings' [32186,32196]
string: 'warnings' [32198,32208]
===
match
---
arglist [31403,31442]
arglist [31415,31454]
===
match
---
atom_expr [32892,32908]
atom_expr [32904,32920]
===
match
---
trailer [1737,1781]
trailer [1737,1781]
===
match
---
trailer [12083,12090]
trailer [12095,12102]
===
match
---
string: 'http://localhost:8180' [24708,24731]
string: 'http://localhost:8180' [24720,24743]
===
match
---
atom_expr [6705,6975]
atom_expr [6717,6987]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [40422,40486]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [40434,40498]
===
match
---
atom [40206,40222]
atom [40218,40234]
===
match
---
number: 2 [14013,14014]
number: 2 [14025,14026]
===
match
---
arglist [15547,15692]
arglist [15559,15704]
===
match
---
name: assert_called_with [15893,15911]
name: assert_called_with [15905,15923]
===
match
---
operator: = [26194,26195]
operator: = [26206,26207]
===
match
---
assert_stmt [5522,5564]
assert_stmt [5534,5576]
===
match
---
operator: = [33557,33558]
operator: = [33569,33570]
===
match
---
operator: = [39538,39539]
operator: = [39550,39551]
===
match
---
name: create_or_update_secret [40155,40178]
name: create_or_update_secret [40167,40190]
===
match
---
name: secrets [26730,26737]
name: secrets [26742,26749]
===
match
---
param [23613,23622]
param [23625,23634]
===
match
---
argument [10925,10952]
argument [10937,10964]
===
match
---
trailer [39950,40133]
trailer [39962,40145]
===
match
---
import_name [919,932]
import_name [919,932]
===
match
---
string: "tenant_id" [6778,6789]
string: "tenant_id" [6790,6801]
===
match
---
funcdef [12711,13281]
funcdef [12723,13293]
===
match
---
name: client [21356,21362]
name: client [21368,21374]
===
match
---
simple_stmt [2144,2187]
simple_stmt [2144,2187]
===
match
---
arglist [36667,36859]
arglist [36679,36871]
===
match
---
name: read_secret [31909,31920]
name: read_secret [31921,31932]
===
match
---
argument [2515,2531]
argument [2515,2531]
===
match
---
dotted_name [11336,11346]
dotted_name [11348,11358]
===
match
---
operator: , [21273,21274]
operator: , [21285,21286]
===
match
---
name: auth_type [5015,5024]
name: auth_type [5027,5036]
===
match
---
dotted_name [40411,40421]
dotted_name [40423,40433]
===
match
---
simple_stmt [22949,22980]
simple_stmt [22961,22992]
===
match
---
operator: , [6577,6578]
operator: , [6589,6590]
===
match
---
operator: , [18290,18291]
operator: , [18302,18303]
===
match
---
trailer [26740,26743]
trailer [26752,26755]
===
match
---
trailer [4672,4674]
trailer [4684,4686]
===
match
---
operator: , [16007,16008]
operator: , [16019,16020]
===
match
---
atom_expr [10354,10387]
atom_expr [10366,10399]
===
match
---
operator: , [10603,10604]
operator: , [10615,10616]
===
match
---
simple_stmt [12352,12417]
simple_stmt [12364,12429]
===
match
---
argument [21521,21534]
argument [21533,21546]
===
match
---
operator: , [43686,43687]
operator: , [43698,43699]
===
match
---
name: raises [43072,43078]
name: raises [43084,43090]
===
match
---
trailer [33658,33681]
trailer [33670,33693]
===
match
---
trailer [18847,18854]
trailer [18859,18866]
===
match
---
operator: , [22549,22550]
operator: , [22561,22562]
===
match
---
comparison [24861,24894]
comparison [24873,24906]
===
match
---
operator: = [3063,3064]
operator: = [3069,3070]
===
match
---
name: pytest [22667,22673]
name: pytest [22679,22685]
===
match
---
trailer [16767,16775]
trailer [16779,16787]
===
match
---
string: "path" [41584,41590]
string: "path" [41596,41602]
===
match
---
operator: = [16513,16514]
operator: = [16525,16526]
===
match
---
operator: = [7297,7298]
operator: = [7309,7310]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [26444,26508]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [26456,26520]
===
match
---
string: 'http://localhost:8180' [12392,12415]
string: 'http://localhost:8180' [12404,12427]
===
match
---
expr_stmt [25129,25159]
expr_stmt [25141,25171]
===
match
---
operator: = [15072,15073]
operator: = [15084,15085]
===
match
---
simple_stmt [25168,25212]
simple_stmt [25180,25224]
===
match
---
argument [36364,36378]
argument [36376,36390]
===
match
---
atom_expr [17023,17053]
atom_expr [17035,17065]
===
match
---
arglist [4259,4356]
arglist [4271,4368]
===
match
---
operator: { [42361,42362]
operator: { [42373,42374]
===
match
---
name: match [40903,40908]
name: match [40915,40920]
===
match
---
simple_stmt [33626,33682]
simple_stmt [33638,33694]
===
match
---
name: return_value [31921,31933]
name: return_value [31933,31945]
===
match
---
trailer [42412,42436]
trailer [42424,42448]
===
match
---
parameters [41197,41214]
parameters [41209,41226]
===
match
---
trailer [29141,29144]
trailer [29153,29156]
===
match
---
argument [17913,17937]
argument [17925,17949]
===
match
---
string: 'secret' [42486,42494]
string: 'secret' [42498,42506]
===
match
---
atom_expr [29789,29984]
atom_expr [29801,29996]
===
match
---
name: client [21585,21591]
name: client [21597,21603]
===
match
---
decorated [22826,23500]
decorated [22838,23512]
===
match
---
decorator [40410,40488]
decorator [40422,40500]
===
match
---
argument [41056,41069]
argument [41068,41081]
===
match
---
trailer [43195,43248]
trailer [43207,43260]
===
match
---
operator: = [33349,33350]
operator: = [33361,33362]
===
match
---
trailer [22619,22626]
trailer [22631,22638]
===
match
---
trailer [22146,22153]
trailer [22158,22165]
===
match
---
operator: = [25521,25522]
operator: = [25533,25534]
===
match
---
atom_expr [26587,26603]
atom_expr [26599,26615]
===
match
---
expr_stmt [25900,26109]
expr_stmt [25912,26121]
===
match
---
atom_expr [7662,7722]
atom_expr [7674,7734]
===
match
---
atom_expr [11647,11676]
atom_expr [11659,11688]
===
match
---
param [18779,18788]
param [18791,18800]
===
match
---
name: patch [15293,15298]
name: patch [15305,15310]
===
match
---
name: secret [29993,29999]
name: secret [30005,30011]
===
match
---
trailer [2698,2732]
trailer [2704,2738]
===
match
---
string: 'http://localhost:8180' [19181,19204]
string: 'http://localhost:8180' [19193,19216]
===
match
---
trailer [4636,4653]
trailer [4648,4665]
===
match
---
parameters [27314,27331]
parameters [27326,27343]
===
match
---
name: client [7094,7100]
name: client [7106,7112]
===
match
---
string: "radhost" [20477,20486]
string: "radhost" [20489,20498]
===
match
---
name: metadata [38165,38173]
name: metadata [38177,38185]
===
match
---
name: auth_mount_point [19019,19035]
name: auth_mount_point [19031,19047]
===
match
---
argument [43981,44004]
argument [43993,44016]
===
match
---
operator: , [18307,18308]
operator: , [18319,18320]
===
match
---
name: mock_hvac [3033,3042]
name: mock_hvac [3039,3048]
===
match
---
simple_stmt [25608,25651]
simple_stmt [25620,25663]
===
match
---
trailer [10374,10387]
trailer [10386,10399]
===
match
---
trailer [27058,27061]
trailer [27070,27073]
===
match
---
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [13894,13922]
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [13906,13934]
===
match
---
suite [11599,12624]
suite [11611,12636]
===
match
---
operator: = [26642,26643]
operator: = [26654,26655]
===
match
---
operator: , [35973,35974]
operator: , [35985,35986]
===
match
---
name: Client [19990,19996]
name: Client [20002,20008]
===
match
---
expr_stmt [9000,9065]
expr_stmt [9012,9077]
===
match
---
operator: = [2557,2558]
operator: = [2557,2558]
===
match
---
funcdef [1921,2187]
funcdef [1921,2187]
===
match
---
argument [1369,1408]
argument [1369,1408]
===
match
---
argument [9673,9698]
argument [9685,9710]
===
match
---
name: mock_client [18870,18881]
name: mock_client [18882,18893]
===
match
---
name: kv_engine_version [19397,19414]
name: kv_engine_version [19409,19426]
===
match
---
atom [31936,32239]
atom [31948,32251]
===
match
---
name: patch [42574,42579]
name: patch [42586,42591]
===
match
---
name: vault_client [1809,1821]
name: vault_client [1809,1821]
===
match
---
operator: , [6020,6021]
operator: , [6032,6033]
===
match
---
operator: , [7873,7874]
operator: , [7885,7886]
===
match
---
argument [3485,3504]
argument [3497,3516]
===
match
---
simple_stmt [40653,40864]
simple_stmt [40665,40876]
===
match
---
simple_stmt [14629,14673]
simple_stmt [14641,14685]
===
match
---
name: auth_type [27609,27618]
name: auth_type [27621,27630]
===
match
---
operator: , [35195,35196]
operator: , [35207,35208]
===
match
---
name: access_key [4537,4547]
name: access_key [4549,4559]
===
match
---
name: mock [25823,25827]
name: mock [25835,25839]
===
match
---
name: hvac [938,942]
name: hvac [938,942]
===
match
---
name: Client [7031,7037]
name: Client [7043,7049]
===
match
---
name: mock [20327,20331]
name: mock [20339,20343]
===
match
---
name: return_value [17256,17268]
name: return_value [17268,17280]
===
match
---
arglist [22283,22323]
arglist [22295,22335]
===
match
---
argument [32322,32343]
argument [32334,32355]
===
match
---
trailer [32906,32908]
trailer [32918,32920]
===
match
---
operator: , [19005,19006]
operator: , [19017,19018]
===
match
---
operator: , [3173,3174]
operator: , [3179,3180]
===
match
---
suite [18116,18645]
suite [18128,18657]
===
match
---
name: vault_client [5227,5239]
name: vault_client [5239,5251]
===
match
---
atom_expr [24453,24469]
atom_expr [24465,24481]
===
match
---
name: metadata [38842,38850]
name: metadata [38854,38862]
===
match
---
argument [16657,16673]
argument [16669,16685]
===
match
---
operator: = [10918,10919]
operator: = [10930,10931]
===
match
---
name: vault_client [19384,19396]
name: vault_client [19396,19408]
===
match
---
operator: , [972,973]
operator: , [972,973]
===
match
---
trailer [31391,31402]
trailer [31403,31414]
===
match
---
name: mock_client [20313,20324]
name: mock_client [20325,20336]
===
match
---
atom_expr [14604,14620]
atom_expr [14616,14632]
===
match
---
atom_expr [35379,35497]
atom_expr [35391,35509]
===
match
---
simple_stmt [6348,6393]
simple_stmt [6360,6405]
===
match
---
argument [4296,4323]
argument [4308,4335]
===
match
---
operator: = [28861,28862]
operator: = [28873,28874]
===
match
---
trailer [8877,8879]
trailer [8889,8891]
===
match
---
suite [7723,7954]
suite [7735,7966]
===
match
---
operator: , [17850,17851]
operator: , [17862,17863]
===
match
---
name: secret_path [26975,26986]
name: secret_path [26987,26998]
===
match
---
decorated [28893,30257]
decorated [28905,30269]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [11455,11519]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [11467,11531]
===
match
---
trailer [27944,27952]
trailer [27956,27964]
===
match
---
string: "pass" [25539,25545]
string: "pass" [25551,25557]
===
match
---
operator: = [32262,32263]
operator: = [32274,32275]
===
match
---
operator: , [16480,16481]
operator: , [16492,16493]
===
match
---
trailer [2603,2622]
trailer [2603,2622]
===
match
---
expr_stmt [37203,37233]
expr_stmt [37215,37245]
===
match
---
operator: = [25308,25309]
operator: = [25320,25321]
===
match
---
trailer [39513,39520]
trailer [39525,39532]
===
match
---
name: vault_client [26951,26963]
name: vault_client [26963,26975]
===
match
---
name: url [21407,21410]
name: url [21419,21422]
===
match
---
name: _VaultClient [17371,17383]
name: _VaultClient [17383,17395]
===
match
---
atom_expr [10217,10233]
atom_expr [10229,10245]
===
match
---
name: url [13807,13810]
name: url [13819,13822]
===
match
---
simple_stmt [13238,13281]
simple_stmt [13250,13293]
===
match
---
trailer [3520,3537]
trailer [3532,3549]
===
match
---
name: mock_client [33734,33745]
name: mock_client [33746,33757]
===
match
---
operator: , [38672,38673]
operator: , [38684,38685]
===
match
---
suite [31782,32709]
suite [31794,32721]
===
match
---
string: "http://localhost:8180" [5940,5963]
string: "http://localhost:8180" [5952,5975]
===
match
---
name: airflow [991,998]
name: airflow [991,998]
===
match
---
name: return_value [17679,17691]
name: return_value [17691,17703]
===
match
---
name: mock_client [28368,28379]
name: mock_client [28380,28391]
===
match
---
decorator [39008,39086]
decorator [39020,39098]
===
match
---
name: _VaultClient [13543,13555]
name: _VaultClient [13555,13567]
===
match
---
expr_stmt [32917,32960]
expr_stmt [32929,32972]
===
match
---
trailer [40254,40257]
trailer [40266,40269]
===
match
---
trailer [2335,2345]
trailer [2335,2345]
===
match
---
string: "radhost" [32334,32343]
string: "radhost" [32346,32355]
===
match
---
operator: = [17327,17328]
operator: = [17339,17340]
===
match
---
decorated [17470,17998]
decorated [17482,18010]
===
match
---
name: mock_client [27486,27497]
name: mock_client [27498,27509]
===
match
---
simple_stmt [5328,5461]
simple_stmt [5340,5473]
===
match
---
trailer [28251,28253]
trailer [28263,28265]
===
match
---
trailer [24189,24195]
trailer [24201,24207]
===
match
---
name: Client [2597,2603]
name: Client [2597,2603]
===
match
---
expr_stmt [10661,10689]
expr_stmt [10673,10701]
===
match
---
name: vault_client [28703,28715]
name: vault_client [28715,28727]
===
match
---
name: mock_hvac [41204,41213]
name: mock_hvac [41216,41225]
===
match
---
operator: = [12268,12269]
operator: = [12280,12281]
===
match
---
operator: = [28593,28594]
operator: = [28605,28606]
===
match
---
name: kv [31528,31530]
name: kv [31540,31542]
===
match
---
operator: , [40047,40048]
operator: , [40059,40060]
===
match
---
simple_stmt [20593,20658]
simple_stmt [20605,20670]
===
match
---
name: mock_client [26573,26584]
name: mock_client [26585,26596]
===
match
---
trailer [10251,10258]
trailer [10263,10270]
===
match
---
name: patch [13292,13297]
name: patch [13304,13309]
===
match
---
operator: , [36750,36751]
operator: , [36762,36763]
===
match
---
expr_stmt [27380,27423]
expr_stmt [27392,27435]
===
match
---
operator: = [4231,4232]
operator: = [4243,4244]
===
match
---
atom_expr [28237,28253]
atom_expr [28249,28265]
===
match
---
name: vault_client [18216,18228]
name: vault_client [18228,18240]
===
match
---
suite [19700,19797]
suite [19712,19809]
===
match
---
operator: = [23938,23939]
operator: = [23950,23951]
===
match
---
operator: == [11207,11209]
operator: == [11219,11221]
===
match
---
operator: , [8406,8407]
operator: , [8418,8419]
===
match
---
simple_stmt [22571,22602]
simple_stmt [22583,22614]
===
match
---
name: username [18275,18283]
name: username [18287,18295]
===
match
---
atom_expr [11759,11792]
atom_expr [11771,11804]
===
match
---
trailer [11059,11069]
trailer [11071,11081]
===
match
---
expr_stmt [6040,6068]
expr_stmt [6052,6080]
===
match
---
name: url [9186,9189]
name: url [9198,9201]
===
match
---
trailer [27958,27978]
trailer [27970,27990]
===
match
---
expr_stmt [23633,23663]
expr_stmt [23645,23675]
===
match
---
name: MagicMock [40580,40589]
name: MagicMock [40592,40601]
===
match
---
expr_stmt [43495,43738]
expr_stmt [43507,43750]
===
match
---
trailer [3771,3781]
trailer [3783,3793]
===
match
---
operator: , [38632,38633]
operator: , [38644,38645]
===
match
---
simple_stmt [16784,16849]
simple_stmt [16796,16861]
===
match
---
name: vault_client [39250,39262]
name: vault_client [39262,39274]
===
match
---
trailer [6112,6141]
trailer [6124,6153]
===
match
---
arglist [11874,12018]
arglist [11886,12030]
===
match
---
atom_expr [40575,40591]
atom_expr [40587,40603]
===
match
---
atom_expr [25143,25159]
atom_expr [25155,25171]
===
match
---
suite [20304,20860]
suite [20316,20872]
===
match
---
name: secret_id [7922,7931]
name: secret_id [7934,7943]
===
match
---
simple_stmt [26118,26147]
simple_stmt [26130,26159]
===
match
---
trailer [35529,35549]
trailer [35541,35561]
===
match
---
name: mock [11336,11340]
name: mock [11348,11352]
===
match
---
arglist [10469,10642]
arglist [10481,10654]
===
match
---
operator: , [37515,37516]
operator: , [37527,37528]
===
match
---
operator: , [27692,27693]
operator: , [27704,27705]
===
match
---
trailer [14950,14969]
trailer [14962,14981]
===
match
---
name: vault_client [2408,2420]
name: vault_client [2408,2420]
===
match
---
name: mock_hvac [37183,37192]
name: mock_hvac [37195,37204]
===
match
---
simple_stmt [31151,31362]
simple_stmt [31163,31374]
===
match
---
argument [7057,7084]
argument [7069,7096]
===
match
---
name: mock_client [42716,42727]
name: mock_client [42728,42739]
===
match
---
number: 2 [25615,25616]
number: 2 [25627,25628]
===
match
---
atom_expr [23191,23210]
atom_expr [23203,23222]
===
match
---
name: role_id [4280,4287]
name: role_id [4292,4299]
===
match
---
operator: = [2421,2422]
operator: = [2421,2422]
===
match
---
name: mock_client [23020,23031]
name: mock_client [23032,23043]
===
match
---
expr_stmt [29774,29984]
expr_stmt [29786,29996]
===
match
---
expr_stmt [23182,23210]
expr_stmt [23194,23222]
===
match
---
trailer [3431,3450]
trailer [3443,3462]
===
match
---
trailer [7121,7140]
trailer [7133,7152]
===
match
---
decorated [25656,26427]
decorated [25668,26439]
===
match
---
name: read_secret_version [27062,27081]
name: read_secret_version [27074,27093]
===
match
---
string: "missing" [28739,28748]
string: "missing" [28751,28760]
===
match
---
trailer [36653,36869]
trailer [36665,36881]
===
match
---
trailer [21843,21845]
trailer [21855,21857]
===
match
---
name: patch [43260,43265]
name: patch [43272,43277]
===
match
---
funcdef [1565,1834]
funcdef [1565,1834]
===
match
---
name: v2 [40255,40257]
name: v2 [40267,40269]
===
match
---
name: mock_client [32878,32889]
name: mock_client [32890,32901]
===
match
---
argument [5048,5062]
argument [5060,5074]
===
match
---
operator: , [2468,2469]
operator: , [2468,2469]
===
match
---
name: url [7057,7060]
name: url [7069,7072]
===
match
---
operator: = [6013,6014]
operator: = [6025,6026]
===
match
---
atom [33697,33715]
atom [33709,33727]
===
match
---
string: 'value' [33211,33218]
string: 'value' [33223,33230]
===
match
---
name: mock [33998,34002]
name: mock [34010,34014]
===
match
---
operator: , [33089,33090]
operator: , [33101,33102]
===
match
---
operator: @ [33839,33840]
operator: @ [33851,33852]
===
match
---
trailer [1991,2001]
trailer [1991,2001]
===
match
---
trailer [14708,14812]
trailer [14720,14824]
===
match
---
name: Client [12084,12090]
name: Client [12096,12102]
===
match
---
trailer [30132,30135]
trailer [30144,30147]
===
match
---
name: self [23607,23611]
name: self [23619,23623]
===
match
---
operator: , [43089,43090]
operator: , [43101,43102]
===
match
---
trailer [33759,33771]
trailer [33771,33783]
===
match
---
trailer [19157,19176]
trailer [19169,19188]
===
match
---
string: "user" [4332,4338]
string: "user" [4344,4350]
===
match
---
arglist [20445,20537]
arglist [20457,20549]
===
match
---
string: "radius" [20455,20463]
string: "radius" [20467,20475]
===
match
---
suite [22562,22821]
suite [22574,22833]
===
match
---
name: client [19214,19220]
name: client [19226,19232]
===
match
---
operator: = [19060,19061]
operator: = [19072,19073]
===
match
---
decorated [19420,19797]
decorated [19432,19809]
===
match
---
string: 'http://localhost:8180' [7061,7084]
string: 'http://localhost:8180' [7073,7096]
===
match
---
trailer [35391,35497]
trailer [35403,35509]
===
match
---
expr_stmt [14231,14274]
expr_stmt [14243,14286]
===
match
---
name: mock [1117,1121]
name: mock [1117,1121]
===
match
---
testlist_comp [10391,10418]
testlist_comp [10403,10430]
===
match
---
name: mock_hvac [11549,11558]
name: mock_hvac [11561,11570]
===
match
---
operator: , [7783,7784]
operator: , [7795,7796]
===
match
---
name: client [12987,12993]
name: client [12999,13005]
===
match
---
string: "http://localhost:8180" [26900,26923]
string: "http://localhost:8180" [26912,26935]
===
match
---
param [7540,7545]
param [7552,7557]
===
match
---
trailer [16035,16052]
trailer [16047,16064]
===
match
---
string: 'scope1' [11731,11739]
string: 'scope1' [11743,11751]
===
match
---
operator: = [22782,22783]
operator: = [22794,22795]
===
match
---
string: "pass" [26294,26300]
string: "pass" [26306,26312]
===
match
---
string: "pass" [18999,19005]
string: "pass" [19011,19017]
===
match
---
trailer [21034,21044]
trailer [21046,21056]
===
match
---
operator: = [27794,27795]
operator: = [27806,27807]
===
match
---
name: mock_hvac [30446,30455]
name: mock_hvac [30458,30467]
===
match
---
dictorsetmaker [40207,40221]
dictorsetmaker [40219,40233]
===
match
---
operator: , [36077,36078]
operator: , [36089,36090]
===
match
---
name: mock_hvac [4166,4175]
name: mock_hvac [4178,4187]
===
match
---
operator: = [32457,32458]
operator: = [32469,32470]
===
match
---
name: _VaultClient [19713,19725]
name: _VaultClient [19725,19737]
===
match
---
string: "missing" [39671,39680]
string: "missing" [39683,39692]
===
match
---
operator: { [35791,35792]
operator: { [35803,35804]
===
match
---
operator: , [9184,9185]
operator: , [9196,9197]
===
match
---
name: return_value [43459,43471]
name: return_value [43471,43483]
===
match
---
string: "http://localhost:8180" [28651,28674]
string: "http://localhost:8180" [28663,28686]
===
match
---
operator: , [43959,43960]
operator: , [43971,43972]
===
match
---
name: secret [31370,31376]
name: secret [31382,31388]
===
match
---
operator: , [3465,3466]
operator: , [3477,3478]
===
match
---
name: mock_hvac [43383,43392]
name: mock_hvac [43395,43404]
===
match
---
string: "path" [42346,42352]
string: "path" [42358,42364]
===
match
---
simple_stmt [7566,7597]
simple_stmt [7578,7609]
===
match
---
trailer [26267,26322]
trailer [26279,26334]
===
match
---
argument [5936,5963]
argument [5948,5975]
===
match
---
string: "pass" [6322,6328]
string: "pass" [6334,6340]
===
match
---
name: client [10683,10689]
name: client [10695,10701]
===
match
---
simple_stmt [29069,29113]
simple_stmt [29081,29125]
===
match
---
name: assert_called_with [9358,9376]
name: assert_called_with [9370,9388]
===
match
---
argument [3228,3244]
argument [3234,3250]
===
match
---
operator: == [2803,2805]
operator: == [2809,2811]
===
match
---
name: Client [20603,20609]
name: Client [20615,20621]
===
match
---
trailer [7140,7316]
trailer [7152,7328]
===
match
---
operator: = [2524,2525]
operator: = [2524,2525]
===
match
---
decorated [4731,5565]
decorated [4743,5577]
===
match
---
operator: , [31104,31105]
operator: , [31116,31117]
===
match
---
parameters [14563,14580]
parameters [14575,14592]
===
match
---
name: InvalidPath [961,972]
name: InvalidPath [961,972]
===
match
---
expr_stmt [27341,27371]
expr_stmt [27353,27383]
===
match
---
operator: , [32172,32173]
operator: , [32184,32185]
===
match
---
name: return_value [19997,20009]
name: return_value [20009,20021]
===
match
---
expr_stmt [1619,1649]
expr_stmt [1619,1649]
===
match
---
argument [14746,14773]
argument [14758,14785]
===
match
---
name: mock_client [27036,27047]
name: mock_client [27048,27059]
===
match
---
name: mock_client [37203,37214]
name: mock_client [37215,37226]
===
match
---
name: self [21789,21793]
name: self [21801,21805]
===
match
---
operator: = [3880,3881]
operator: = [3892,3893]
===
match
---
string: "missing" [37037,37046]
string: "missing" [37049,37058]
===
match
---
operator: = [28650,28651]
operator: = [28662,28663]
===
match
---
trailer [26373,26375]
trailer [26385,26387]
===
match
---
name: test_version_wrong [1202,1220]
name: test_version_wrong [1202,1220]
===
match
---
operator: = [20454,20455]
operator: = [20466,20467]
===
match
---
operator: = [16012,16013]
operator: = [16024,16025]
===
match
---
trailer [25857,25864]
trailer [25869,25876]
===
match
---
operator: , [28501,28502]
operator: , [28513,28514]
===
match
---
operator: , [42494,42495]
operator: , [42506,42507]
===
match
---
name: MagicMock [2336,2345]
name: MagicMock [2336,2345]
===
match
---
name: vault_client [27796,27808]
name: vault_client [27808,27820]
===
match
---
atom_expr [4412,4476]
atom_expr [4424,4488]
===
match
---
trailer [15228,15230]
trailer [15240,15242]
===
match
---
simple_stmt [16324,16368]
simple_stmt [16336,16380]
===
match
---
name: mock_client [40232,40243]
name: mock_client [40244,40255]
===
match
---
string: "requires 'kubernetes_role'" [17328,17356]
string: "requires 'kubernetes_role'" [17340,17368]
===
match
---
name: Client [31840,31846]
name: Client [31852,31858]
===
match
---
name: mock_hvac [43442,43451]
name: mock_hvac [43454,43463]
===
match
---
name: MagicMock [3772,3781]
name: MagicMock [3784,3793]
===
match
---
operator: = [20325,20326]
operator: = [20337,20338]
===
match
---
operator: = [1771,1772]
operator: = [1771,1772]
===
match
---
simple_stmt [14941,15025]
simple_stmt [14953,15037]
===
match
---
name: pytest [19653,19659]
name: pytest [19665,19671]
===
match
---
name: radius_port [42916,42927]
name: radius_port [42928,42939]
===
match
---
name: vault_client [6690,6702]
name: vault_client [6702,6714]
===
match
---
name: assert_called_with [20610,20628]
name: assert_called_with [20622,20640]
===
match
---
argument [17828,17850]
argument [17840,17862]
===
match
---
argument [42354,42377]
argument [42366,42389]
===
match
---
trailer [32628,32631]
trailer [32640,32643]
===
match
---
expr_stmt [42716,42746]
expr_stmt [42728,42758]
===
match
---
simple_stmt [1658,1702]
simple_stmt [1658,1702]
===
match
---
simple_stmt [10294,10346]
simple_stmt [10306,10358]
===
match
---
name: assert_called_once_with [32647,32670]
name: assert_called_once_with [32659,32682]
===
match
---
operator: , [15393,15394]
operator: , [15405,15406]
===
match
---
operator: = [23645,23646]
operator: = [23657,23658]
===
match
---
operator: , [36784,36785]
operator: , [36796,36797]
===
match
---
simple_stmt [42387,42563]
simple_stmt [42399,42575]
===
match
---
name: mock_client [2317,2328]
name: mock_client [2317,2328]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [10028,10092]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [10040,10104]
===
match
---
trailer [22253,22263]
trailer [22265,22275]
===
match
---
operator: , [30686,30687]
operator: , [30698,30699]
===
match
---
operator: , [33149,33150]
operator: , [33161,33162]
===
match
---
argument [28016,28036]
argument [28028,28048]
===
match
---
decorator [20865,20943]
decorator [20877,20955]
===
match
---
operator: , [26300,26301]
operator: , [26312,26313]
===
match
---
param [2968,2973]
param [2974,2979]
===
match
---
operator: = [3309,3310]
operator: = [3315,3316]
===
match
---
name: url [15664,15667]
name: url [15676,15679]
===
match
---
name: assert_called_with [13869,13887]
name: assert_called_with [13881,13899]
===
match
---
name: mock_get_credentials [11759,11779]
name: mock_get_credentials [11771,11791]
===
match
---
funcdef [11525,12624]
funcdef [11537,12636]
===
match
---
argument [33541,33565]
argument [33553,33577]
===
match
---
expr_stmt [27787,27842]
expr_stmt [27799,27854]
===
match
---
dotted_name [42569,42579]
dotted_name [42581,42591]
===
match
---
simple_stmt [36534,36565]
simple_stmt [36546,36577]
===
match
---
trailer [20431,20547]
trailer [20443,20559]
===
match
---
trailer [37306,37314]
trailer [37318,37326]
===
match
---
name: secrets [33746,33753]
name: secrets [33758,33765]
===
match
---
string: "scope1,scope2" [11961,11976]
string: "scope1,scope2" [11973,11988]
===
match
---
trailer [31819,31821]
trailer [31831,31833]
===
match
---
string: "missing" [31415,31424]
string: "missing" [31427,31436]
===
match
---
trailer [19969,19971]
trailer [19981,19983]
===
match
---
name: mount_point [24287,24298]
name: mount_point [24299,24310]
===
match
---
operator: = [27544,27545]
operator: = [27556,27557]
===
match
---
name: test_kubernetes_kubernetes_jwt_path_none [17556,17596]
name: test_kubernetes_kubernetes_jwt_path_none [17568,17608]
===
match
---
name: return_value [29168,29180]
name: return_value [29180,29192]
===
match
---
param [23607,23612]
param [23619,23624]
===
match
---
name: mount_point [38942,38953]
name: mount_point [38954,38965]
===
match
---
trailer [16793,16800]
trailer [16805,16812]
===
match
---
string: "credentials" [9685,9698]
string: "credentials" [9697,9710]
===
match
---
operator: = [9308,9309]
operator: = [9320,9321]
===
match
---
param [22551,22560]
param [22563,22572]
===
match
---
name: url [38118,38121]
name: url [38130,38133]
===
match
---
name: MagicMock [21035,21044]
name: MagicMock [21047,21056]
===
match
---
operator: = [39458,39459]
operator: = [39470,39471]
===
match
---
decorator [12629,12707]
decorator [12641,12719]
===
match
---
argument [19746,19766]
argument [19758,19778]
===
match
---
name: exceptions [943,953]
name: exceptions [943,953]
===
match
---
param [20293,20302]
param [20305,20314]
===
match
---
param [39138,39147]
param [39150,39159]
===
match
---
name: mock [3008,3012]
name: mock [3014,3018]
===
match
---
suite [1964,2187]
suite [1964,2187]
===
match
---
trailer [42398,42406]
trailer [42410,42418]
===
match
---
expr_stmt [13437,13467]
expr_stmt [13449,13479]
===
match
---
name: patch [19808,19813]
name: patch [19820,19825]
===
match
---
argument [26302,26321]
argument [26314,26333]
===
match
---
name: _VaultClient [43510,43522]
name: _VaultClient [43522,43534]
===
match
---
argument [41011,41029]
argument [41023,41041]
===
match
---
string: 'secret_value' [29405,29419]
string: 'secret_value' [29417,29431]
===
match
---
argument [13569,13587]
argument [13581,13599]
===
match
---
name: get_secret [30015,30025]
name: get_secret [30027,30037]
===
match
---
trailer [5475,5492]
trailer [5487,5504]
===
match
---
trailer [32533,32556]
trailer [32545,32568]
===
match
---
arglist [22773,22819]
arglist [22785,22831]
===
match
---
name: secret [41592,41598]
name: secret [41604,41610]
===
match
---
trailer [7331,7348]
trailer [7343,7360]
===
match
---
param [21789,21794]
param [21801,21806]
===
match
---
expr_stmt [39870,39913]
expr_stmt [39882,39925]
===
match
---
expr_stmt [28262,28305]
expr_stmt [28274,28317]
===
match
---
operator: = [27652,27653]
operator: = [27664,27665]
===
match
---
trailer [19125,19132]
trailer [19137,19144]
===
match
---
name: client [16029,16035]
name: client [16041,16047]
===
match
---
operator: = [15484,15485]
operator: = [15496,15497]
===
match
---
dictorsetmaker [33211,33227]
dictorsetmaker [33223,33239]
===
match
---
operator: , [2713,2714]
operator: , [2719,2720]
===
match
---
operator: == [2153,2155]
operator: == [2153,2155]
===
match
---
name: patch [18009,18014]
name: patch [18021,18026]
===
match
---
string: 'secret_value' [31474,31488]
string: 'secret_value' [31486,31500]
===
match
---
name: Client [10252,10258]
name: Client [10264,10270]
===
match
---
simple_stmt [42045,42289]
simple_stmt [42057,42301]
===
match
---
name: self [19531,19535]
name: self [19543,19547]
===
match
---
dictorsetmaker [30574,31131]
dictorsetmaker [30586,31143]
===
match
---
operator: == [31490,31492]
operator: == [31502,31504]
===
match
---
name: radius_host [42118,42129]
name: radius_host [42130,42141]
===
match
---
trailer [2001,2003]
trailer [2001,2003]
===
match
---
atom [35128,35329]
atom [35140,35341]
===
match
---
string: "role" [2478,2484]
string: "role" [2478,2484]
===
match
---
name: vault_client [2156,2168]
name: vault_client [2156,2168]
===
match
---
operator: , [35899,35900]
operator: , [35911,35912]
===
match
---
trailer [43171,43195]
trailer [43183,43207]
===
match
---
expr_stmt [24439,24469]
expr_stmt [24451,24481]
===
match
---
string: "token" [24861,24868]
string: "token" [24873,24880]
===
match
---
string: 'warnings' [37884,37894]
string: 'warnings' [37896,37906]
===
match
---
trailer [12246,12343]
trailer [12258,12355]
===
match
---
argument [11089,11114]
argument [11101,11126]
===
match
---
operator: = [5834,5835]
operator: = [5846,5847]
===
match
---
simple_stmt [21906,22117]
simple_stmt [21918,22129]
===
match
---
operator: , [21201,21202]
operator: , [21213,21214]
===
match
---
trailer [13492,13505]
trailer [13504,13517]
===
match
---
operator: = [34378,34379]
operator: = [34390,34391]
===
match
---
string: 'path' [41754,41760]
string: 'path' [41766,41772]
===
match
---
simple_stmt [24631,24660]
simple_stmt [24643,24672]
===
match
---
param [11560,11581]
param [11572,11593]
===
match
---
trailer [2092,2135]
trailer [2092,2135]
===
match
---
trailer [18180,18193]
trailer [18192,18205]
===
match
---
name: vault_client [34075,34087]
name: vault_client [34087,34099]
===
match
---
trailer [31527,31530]
trailer [31539,31542]
===
match
---
suite [15781,15823]
suite [15793,15835]
===
match
---
name: test_radius_missing_host [19506,19530]
name: test_radius_missing_host [19518,19542]
===
match
---
string: "radius_secret" [20069,20084]
string: "radius_secret" [20081,20096]
===
match
---
operator: = [14261,14262]
operator: = [14273,14274]
===
match
---
name: mock_client [33984,33995]
name: mock_client [33996,34007]
===
match
---
expr_stmt [35506,35572]
expr_stmt [35518,35584]
===
match
---
trailer [3042,3049]
trailer [3048,3055]
===
match
---
operator: , [1225,1226]
operator: , [1225,1226]
===
match
---
argument [43216,43239]
argument [43228,43251]
===
match
---
expr_stmt [39197,39240]
expr_stmt [39209,39252]
===
match
---
name: mock [22827,22831]
name: mock [22839,22843]
===
match
---
dotted_name [4003,4013]
dotted_name [4015,4025]
===
match
---
atom_expr [32264,32492]
atom_expr [32276,32504]
===
match
---
trailer [9630,9640]
trailer [9642,9652]
===
match
---
operator: { [35128,35129]
operator: { [35140,35141]
===
match
---
name: _VaultClient [1423,1435]
name: _VaultClient [1423,1435]
===
match
---
name: mock_hvac [5673,5682]
name: mock_hvac [5685,5694]
===
match
---
name: mock_hvac [19141,19150]
name: mock_hvac [19153,19162]
===
match
---
name: azure [7106,7111]
name: azure [7118,7123]
===
match
---
string: "value" [12296,12303]
string: "value" [12308,12315]
===
match
---
atom_expr [22162,22226]
atom_expr [22174,22238]
===
match
---
operator: , [21965,21966]
operator: , [21977,21978]
===
match
---
name: mock_client [13508,13519]
name: mock_client [13520,13531]
===
match
---
atom_expr [6077,6141]
atom_expr [6089,6153]
===
match
---
string: "aws_iam" [4269,4278]
string: "aws_iam" [4281,4290]
===
match
---
operator: = [39973,39974]
operator: = [39985,39986]
===
match
---
operator: = [10272,10273]
operator: = [10284,10285]
===
match
---
trailer [24286,24298]
trailer [24298,24310]
===
match
---
argument [20629,20656]
argument [20641,20668]
===
match
---
trailer [37231,37233]
trailer [37243,37245]
===
match
---
name: username [26268,26276]
name: username [26280,26288]
===
match
---
string: 'secret_key' [30065,30077]
string: 'secret_key' [30077,30089]
===
match
---
operator: , [20463,20464]
operator: , [20475,20476]
===
match
---
arglist [42849,43041]
arglist [42861,43053]
===
match
---
name: Client [3043,3049]
name: Client [3049,3055]
===
match
---
string: 'created_time' [34931,34945]
string: 'created_time' [34943,34957]
===
match
---
name: Client [2022,2028]
name: Client [2022,2028]
===
match
---
trailer [21455,21462]
trailer [21467,21474]
===
match
---
string: "pass" [22306,22312]
string: "pass" [22318,22324]
===
match
---
expr_stmt [1247,1277]
expr_stmt [1247,1277]
===
match
---
string: "kube_role" [15996,16007]
string: "kube_role" [16008,16019]
===
match
---
param [22545,22550]
param [22557,22562]
===
match
---
argument [16929,16948]
argument [16941,16960]
===
match
---
string: 'warnings' [33273,33283]
string: 'warnings' [33285,33295]
===
match
---
arglist [31591,31638]
arglist [31603,31650]
===
match
---
string: 'http://localhost:8180' [16824,16847]
string: 'http://localhost:8180' [16836,16859]
===
match
---
parameters [19530,19547]
parameters [19542,19559]
===
match
---
trailer [9020,9033]
trailer [9032,9045]
===
match
---
string: "airflow.providers.google.cloud.utils.credentials_provider.get_credentials_and_project_id" [11347,11437]
string: "airflow.providers.google.cloud.utils.credentials_provider.get_credentials_and_project_id" [11359,11449]
===
match
---
comparison [14013,14048]
comparison [14025,14060]
===
match
---
name: test_get_existing_key_v2 [28979,29003]
name: test_get_existing_key_v2 [28991,29015]
===
match
---
argument [7846,7873]
argument [7858,7885]
===
match
---
atom_expr [25372,25391]
atom_expr [25384,25403]
===
match
---
operator: = [16468,16469]
operator: = [16480,16481]
===
match
---
trailer [9659,9709]
trailer [9671,9721]
===
match
---
name: radius_port [33444,33455]
name: radius_port [33456,33467]
===
match
---
comparison [3574,3609]
comparison [3586,3621]
===
match
---
param [28197,28202]
param [28209,28214]
===
match
---
name: mock_client [18799,18810]
name: mock_client [18811,18822]
===
match
---
trailer [9357,9376]
trailer [9369,9388]
===
match
---
argument [5399,5416]
argument [5411,5428]
===
match
---
name: mock_hvac [34533,34542]
name: mock_hvac [34545,34554]
===
match
---
expr_stmt [8849,8879]
expr_stmt [8861,8891]
===
match
---
trailer [36283,36304]
trailer [36295,36316]
===
match
---
operator: = [18532,18533]
operator: = [18544,18545]
===
match
---
trailer [32995,33007]
trailer [33007,33019]
===
match
---
name: mount_point [41720,41731]
name: mount_point [41732,41743]
===
match
---
operator: = [6777,6778]
operator: = [6789,6790]
===
match
---
comparison [35588,36249]
comparison [35600,36261]
===
match
---
suite [8258,8487]
suite [8270,8499]
===
match
---
name: vault_client [37946,37958]
name: vault_client [37958,37970]
===
match
---
name: mock_hvac [19980,19989]
name: mock_hvac [19992,20001]
===
match
---
name: radius_secret [20488,20501]
name: radius_secret [20500,20513]
===
match
---
atom_expr [3916,3996]
atom_expr [3928,4008]
===
match
---
operator: = [4952,4953]
operator: = [4964,4965]
===
match
---
argument [10469,10484]
argument [10481,10496]
===
match
---
expr_stmt [22571,22601]
expr_stmt [22583,22613]
===
match
---
operator: = [17692,17693]
operator: = [17704,17705]
===
match
---
operator: = [18515,18516]
operator: = [18527,18528]
===
match
---
string: "path" [15860,15866]
string: "path" [15872,15878]
===
match
---
name: match [43091,43096]
name: match [43103,43108]
===
match
---
name: client [16958,16964]
name: client [16970,16976]
===
match
---
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [13147,13175]
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [13159,13187]
===
match
---
name: auth_mount_point [26033,26049]
name: auth_mount_point [26045,26061]
===
match
---
simple_stmt [31508,31649]
simple_stmt [31520,31661]
===
match
---
operator: == [20826,20828]
operator: == [20838,20840]
===
match
---
simple_stmt [22760,22821]
simple_stmt [22772,22833]
===
match
---
suite [28214,28888]
suite [28226,28900]
===
match
---
name: mock_hvac [20593,20602]
name: mock_hvac [20605,20614]
===
match
---
trailer [11055,11059]
trailer [11067,11071]
===
match
---
operator: , [12508,12509]
operator: , [12520,12521]
===
match
---
assert_stmt [6401,6443]
assert_stmt [6413,6455]
===
match
---
name: self [5667,5671]
name: self [5679,5683]
===
match
---
name: raises [34287,34293]
name: raises [34299,34305]
===
match
---
operator: = [27831,27832]
operator: = [27843,27844]
===
match
---
trailer [6156,6161]
trailer [6168,6173]
===
match
---
name: assert_called_with [7122,7140]
name: assert_called_with [7134,7152]
===
match
---
operator: , [33460,33461]
operator: , [33472,33473]
===
match
---
trailer [12109,12138]
trailer [12121,12150]
===
match
---
number: 1 [32439,32440]
number: 1 [32451,32452]
===
match
---
simple_stmt [6401,6444]
simple_stmt [6413,6456]
===
match
---
name: test_create_or_update_secret_v1_cas [42654,42689]
name: test_create_or_update_secret_v1_cas [42666,42701]
===
match
---
atom [34891,35344]
atom [34903,35356]
===
match
---
name: client [15106,15112]
name: client [15118,15124]
===
match
---
name: auth [12432,12436]
name: auth [12444,12448]
===
match
---
string: "path.json" [9145,9156]
string: "path.json" [9157,9168]
===
match
---
name: client [16857,16863]
name: client [16869,16875]
===
match
---
expr_stmt [24478,24521]
expr_stmt [24490,24533]
===
match
---
trailer [16403,16610]
trailer [16415,16622]
===
match
---
dictorsetmaker [38456,38726]
dictorsetmaker [38468,38738]
===
match
---
argument [20745,20754]
argument [20757,20766]
===
match
---
name: mock_client [38859,38870]
name: mock_client [38871,38882]
===
match
---
operator: = [26074,26075]
operator: = [26086,26087]
===
match
---
trailer [34608,34621]
trailer [34620,34633]
===
match
---
name: is_authenticated [22340,22356]
name: is_authenticated [22352,22368]
===
match
---
operator: = [39670,39671]
operator: = [39682,39683]
===
match
---
trailer [6061,6068]
trailer [6073,6080]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [3627,3691]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [3639,3703]
===
match
---
param [24413,24418]
param [24425,24430]
===
match
---
name: vault_client [32510,32522]
name: vault_client [32522,32534]
===
match
---
trailer [23487,23499]
trailer [23499,23511]
===
match
---
trailer [10851,10870]
trailer [10863,10882]
===
match
---
atom_expr [21122,21325]
atom_expr [21134,21337]
===
match
---
string: "user" [7232,7238]
string: "user" [7244,7250]
===
match
---
name: mount_point [31591,31602]
name: mount_point [31603,31614]
===
match
---
name: kv_engine_version [14031,14048]
name: kv_engine_version [14043,14060]
===
match
---
simple_stmt [38859,39003]
simple_stmt [38871,39015]
===
match
---
string: 'key' [41039,41044]
string: 'key' [41051,41056]
===
match
---
string: 'missing' [33823,33832]
string: 'missing' [33835,33844]
===
match
---
name: read_secret_version [38885,38904]
name: read_secret_version [38897,38916]
===
match
---
dictorsetmaker [43224,43238]
dictorsetmaker [43236,43250]
===
match
---
dotted_name [43255,43265]
dotted_name [43267,43277]
===
match
---
name: mock_file [16679,16688]
name: mock_file [16691,16700]
===
match
---
name: mock [30263,30267]
name: mock [30275,30279]
===
match
---
name: is_authenticated [6355,6371]
name: is_authenticated [6367,6383]
===
match
---
name: kv [32990,32992]
name: kv [33002,33004]
===
match
---
string: 'request_id' [37370,37382]
string: 'request_id' [37382,37394]
===
match
---
name: azure_tenant_id [6762,6777]
name: azure_tenant_id [6774,6789]
===
match
---
name: patch [22832,22837]
name: patch [22844,22849]
===
match
---
name: url [24594,24597]
name: url [24606,24609]
===
match
---
name: client [24741,24747]
name: client [24753,24759]
===
match
---
operator: = [13449,13450]
operator: = [13461,13462]
===
match
---
operator: , [12903,12904]
operator: , [12915,12916]
===
match
---
operator: = [8350,8351]
operator: = [8362,8363]
===
match
---
name: configure [6168,6177]
name: configure [6180,6189]
===
match
---
arglist [3126,3283]
arglist [3132,3289]
===
match
---
string: '' [36116,36118]
string: '' [36128,36130]
===
match
---
operator: , [38591,38592]
operator: , [38603,38604]
===
match
---
string: 'http://localhost:8180' [4452,4475]
string: 'http://localhost:8180' [4464,4487]
===
match
---
dictorsetmaker [42362,42376]
dictorsetmaker [42374,42388]
===
match
---
atom_expr [2012,2041]
atom_expr [2012,2041]
===
match
---
string: "other" [21266,21273]
string: "other" [21278,21285]
===
match
---
name: patch [912,917]
name: patch [912,917]
===
match
---
comparison [24910,24945]
comparison [24922,24957]
===
match
---
simple_stmt [26384,26427]
simple_stmt [26396,26439]
===
match
---
operator: = [37959,37960]
operator: = [37971,37972]
===
match
---
name: test_gcp_dict [11529,11542]
name: test_gcp_dict [11541,11554]
===
match
---
atom_expr [21030,21046]
atom_expr [21042,21058]
===
match
---
name: radius_secret [21215,21228]
name: radius_secret [21227,21240]
===
match
---
name: Client [34033,34039]
name: Client [34045,34051]
===
match
---
operator: = [27687,27688]
operator: = [27699,27700]
===
match
---
atom_expr [11848,12028]
atom_expr [11860,12040]
===
match
---
name: mock_hvac [15033,15042]
name: mock_hvac [15045,15054]
===
match
---
name: patch [14060,14065]
name: patch [14072,14077]
===
match
---
operator: = [5153,5154]
operator: = [5165,5166]
===
match
---
simple_stmt [6690,6976]
simple_stmt [6702,6988]
===
match
---
atom_expr [17214,17230]
atom_expr [17226,17242]
===
match
---
operator: , [5103,5104]
operator: , [5115,5116]
===
match
---
name: mock [37217,37221]
name: mock [37229,37233]
===
match
---
name: radius_port [31259,31270]
name: radius_port [31271,31282]
===
match
---
string: "http://localhost:8180" [15668,15691]
string: "http://localhost:8180" [15680,15703]
===
match
---
name: secret [40199,40205]
name: secret [40211,40217]
===
match
---
param [1953,1962]
param [1953,1962]
===
match
---
name: mock_hvac [36514,36523]
name: mock_hvac [36526,36535]
===
match
---
name: self [33958,33962]
name: self [33970,33974]
===
match
---
name: mock_client [12824,12835]
name: mock_client [12836,12847]
===
match
---
assert_stmt [21638,21680]
assert_stmt [21650,21692]
===
match
---
operator: = [20158,20159]
operator: = [20170,20171]
===
match
---
operator: , [27139,27140]
operator: , [27151,27152]
===
match
---
name: secret [27858,27864]
name: secret [27870,27876]
===
match
---
string: "http://localhost:8180" [17959,17982]
string: "http://localhost:8180" [17971,17994]
===
match
---
with_item [15716,15780]
with_item [15728,15792]
===
match
---
name: return_value [12809,12821]
name: return_value [12821,12833]
===
match
---
name: return_value [4939,4951]
name: return_value [4951,4963]
===
match
---
name: mock_client [12753,12764]
name: mock_client [12765,12776]
===
match
---
param [11582,11597]
param [11594,11609]
===
match
---
simple_stmt [22386,22429]
simple_stmt [22398,22441]
===
match
---
name: mock_hvac [10144,10153]
name: mock_hvac [10156,10165]
===
match
---
trailer [7348,7367]
trailer [7360,7379]
===
match
---
name: assert_called_with [21609,21627]
name: assert_called_with [21621,21639]
===
match
---
trailer [18487,18506]
trailer [18499,18518]
===
match
---
trailer [19255,19310]
trailer [19267,19322]
===
match
---
trailer [12781,12783]
trailer [12793,12795]
===
match
---
trailer [27369,27371]
trailer [27381,27383]
===
match
---
name: client [19319,19325]
name: client [19331,19337]
===
match
---
name: secrets [32982,32989]
name: secrets [32994,33001]
===
match
---
arglist [36342,36378]
arglist [36354,36390]
===
match
---
trailer [24457,24467]
trailer [24469,24479]
===
match
---
atom [41038,41054]
atom [41050,41066]
===
match
---
comparison [24801,24845]
comparison [24813,24857]
===
match
---
argument [32290,32308]
argument [32302,32320]
===
match
---
string: "other" [19302,19309]
string: "other" [19314,19321]
===
match
---
trailer [40890,40960]
trailer [40902,40972]
===
match
---
operator: , [4294,4295]
operator: , [4306,4307]
===
match
---
param [16259,16264]
param [16271,16276]
===
match
---
name: mock_client [39229,39240]
name: mock_client [39241,39252]
===
match
---
name: read_secret [28394,28405]
name: read_secret [28406,28417]
===
match
---
operator: , [34531,34532]
operator: , [34543,34544]
===
match
---
atom_expr [34023,34052]
atom_expr [34035,34064]
===
match
---
trailer [22171,22178]
trailer [22183,22190]
===
match
---
operator: , [38145,38146]
operator: , [38157,38158]
===
match
---
trailer [27505,27508]
trailer [27517,27520]
===
match
---
simple_stmt [18392,18457]
simple_stmt [18404,18469]
===
match
---
expr_stmt [24530,24622]
expr_stmt [24542,24634]
===
match
---
operator: == [33716,33718]
operator: == [33728,33730]
===
match
---
simple_stmt [10831,10963]
simple_stmt [10843,10975]
===
match
---
operator: } [37592,37593]
operator: } [37604,37605]
===
match
---
name: side_effect [28406,28417]
name: side_effect [28418,28429]
===
match
---
name: secret [43216,43222]
name: secret [43228,43234]
===
match
---
operator: = [20143,20144]
operator: = [20155,20156]
===
match
---
trailer [43925,44029]
trailer [43937,44041]
===
match
---
dictorsetmaker [38546,38707]
dictorsetmaker [38558,38719]
===
match
---
name: create_or_update_secret [43760,43783]
name: create_or_update_secret [43772,43795]
===
match
---
name: vault_client [36626,36638]
name: vault_client [36638,36650]
===
match
---
name: kv [32629,32631]
name: kv [32641,32643]
===
match
---
operator: = [16297,16298]
operator: = [16309,16310]
===
match
---
simple_stmt [3567,3610]
simple_stmt [3579,3622]
===
match
---
simple_stmt [12528,12573]
simple_stmt [12540,12585]
===
match
---
simple_stmt [24255,24299]
simple_stmt [24267,24311]
===
match
---
name: mock_client [28223,28234]
name: mock_client [28235,28246]
===
match
---
atom [43988,44004]
atom [44000,44016]
===
match
---
name: test_get_existing_key_v1_different_auth_mount_point [32800,32851]
name: test_get_existing_key_v1_different_auth_mount_point [32812,32863]
===
match
---
operator: = [2386,2387]
operator: = [2386,2387]
===
match
---
trailer [7668,7675]
trailer [7680,7687]
===
match
---
operator: = [28292,28293]
operator: = [28304,28305]
===
match
---
simple_stmt [42297,42379]
simple_stmt [42309,42391]
===
match
---
trailer [11636,11638]
trailer [11648,11650]
===
match
---
trailer [22241,22246]
trailer [22253,22258]
===
match
---
suite [36525,37048]
suite [36537,37060]
===
match
---
arglist [40694,40853]
arglist [40706,40865]
===
match
---
operator: = [41753,41754]
operator: = [41765,41766]
===
match
---
operator: = [42022,42023]
operator: = [42034,42035]
===
match
---
decorated [40410,41071]
decorated [40422,41083]
===
match
---
name: v2 [27059,27061]
name: v2 [27071,27073]
===
match
---
string: 'scope1' [12314,12322]
string: 'scope1' [12326,12334]
===
match
---
name: mock_get_scopes [11582,11597]
name: mock_get_scopes [11594,11609]
===
match
---
argument [42153,42169]
argument [42165,42181]
===
match
---
arglist [7676,7721]
arglist [7688,7733]
===
match
---
expr_stmt [41224,41254]
expr_stmt [41236,41266]
===
match
---
operator: = [38030,38031]
operator: = [38042,38043]
===
match
---
trailer [39849,39859]
trailer [39861,39871]
===
match
---
name: MagicMock [12772,12781]
name: MagicMock [12784,12793]
===
match
---
simple_stmt [41535,41625]
simple_stmt [41547,41637]
===
match
---
trailer [25409,25416]
trailer [25421,25428]
===
match
---
operator: , [41615,41616]
operator: , [41627,41628]
===
match
---
parameters [28196,28213]
parameters [28208,28225]
===
match
---
string: 'destroyed' [38654,38665]
string: 'destroyed' [38666,38677]
===
match
---
operator: = [22318,22319]
operator: = [22330,22331]
===
match
---
arglist [38942,38992]
arglist [38954,39004]
===
match
---
string: 's.7AU0I51yv1Q1lxOIg1F3ZRAS' [23803,23831]
string: 's.7AU0I51yv1Q1lxOIg1F3ZRAS' [23815,23843]
===
match
---
trailer [26974,26997]
trailer [26986,27009]
===
match
---
dotted_name [14450,14460]
dotted_name [14462,14472]
===
match
---
name: mock_hvac [32858,32867]
name: mock_hvac [32870,32879]
===
match
---
operator: = [36603,36604]
operator: = [36615,36616]
===
match
---
operator: = [11883,11884]
operator: = [11895,11896]
===
match
---
param [43383,43392]
param [43395,43404]
===
match
---
name: client [18465,18471]
name: client [18477,18483]
===
match
---
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [12911,12939]
string: "s.7AU0I51yv1Q1lxOIg1F3ZRAS" [12923,12951]
===
match
---
operator: = [8227,8228]
operator: = [8239,8240]
===
match
---
trailer [20341,20343]
trailer [20353,20355]
===
match
---
operator: = [3098,3099]
operator: = [3104,3105]
===
match
---
trailer [28387,28390]
trailer [28399,28402]
===
match
---
decorator [16130,16208]
decorator [16142,16220]
===
match
---
trailer [17641,17651]
trailer [17653,17663]
===
match
---
number: 0 [30718,30719]
number: 0 [30730,30731]
===
match
---
name: mock [28237,28241]
name: mock [28249,28253]
===
match
---
name: client [6062,6068]
name: client [6074,6080]
===
match
---
name: create_or_update_secret [42413,42436]
name: create_or_update_secret [42425,42448]
===
match
---
atom_expr [21371,21435]
atom_expr [21383,21447]
===
match
---
name: mock_client [17200,17211]
name: mock_client [17212,17223]
===
match
---
name: url [26896,26899]
name: url [26908,26911]
===
match
---
trailer [26763,26775]
trailer [26775,26787]
===
match
---
trailer [29048,29058]
trailer [29060,29070]
===
match
---
operator: , [32343,32344]
operator: , [32355,32356]
===
match
---
name: mock [3616,3620]
name: mock [3628,3632]
===
match
---
simple_stmt [2587,2652]
simple_stmt [2587,2652]
===
match
---
argument [43961,43979]
argument [43973,43991]
===
match
---
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [14066,14130]
string: "airflow.providers.hashicorp._internal_client.vault_client.hvac" [14078,14142]
===
match
---
operator: , [34865,34866]
operator: , [34877,34878]
===
match
---
name: get_secret [26964,26974]
name: get_secret [26976,26986]
===
match
---
string: "project_id" [9052,9064]
string: "project_id" [9064,9076]
===
match
---
string: "radius" [21957,21965]
string: "radius" [21969,21977]
===
match
---
name: secret_path [32534,32545]
name: secret_path [32546,32557]
===
match
---
dictorsetmaker [37370,37927]
dictorsetmaker [37382,37939]
===
match
---
name: radius_port [40761,40772]
name: radius_port [40773,40784]
===
match
---
string: 'scope2' [9514,9522]
string: 'scope2' [9526,9534]
===
match
---
atom_expr [25823,25839]
atom_expr [25835,25851]
===
match
---
name: self [11543,11547]
name: self [11555,11559]
===
match
---
operator: = [5390,5391]
operator: = [5402,5403]
===
match
---
operator: { [35588,35589]
operator: { [35600,35601]
===
match
---
simple_stmt [15794,15823]
simple_stmt [15806,15835]
===
match
---
atom [35773,36226]
atom [35785,36238]
===
match
---
argument [39422,39441]
argument [39434,39453]
===
match
---
expr_stmt [10203,10233]
expr_stmt [10215,10245]
===
match
---
name: assert_called_with [6372,6390]
name: assert_called_with [6384,6402]
===
match
---
name: secret_path [34367,34378]
name: secret_path [34379,34390]
===
match
---
name: mock [9909,9913]
name: mock [9921,9925]
===
match
---
operator: { [38464,38465]
operator: { [38476,38477]
===
match
---
operator: @ [17470,17471]
operator: @ [17482,17483]
===
match
---
atom_expr [13476,13505]
atom_expr [13488,13517]
===
match
---
arglist [3451,3504]
arglist [3463,3516]
===
match
---
name: secret_path [27820,27831]
name: secret_path [27832,27843]
===
match
---
name: radius_secret [39388,39401]
name: radius_secret [39400,39413]
===
match
---
atom [40368,40384]
atom [40380,40396]
===
match
---
operator: { [43223,43224]
operator: { [43235,43236]
===
match
---
trailer [9760,9762]
trailer [9772,9774]
===
match
---
trailer [30518,30521]
trailer [30530,30533]
===
match
---
name: Client [3349,3355]
name: Client [3355,3361]
===
match
---
argument [5897,5922]
argument [5909,5934]
===
match
---
dictorsetmaker [30065,30093]
dictorsetmaker [30077,30105]
===
match
---
name: mock_get_scopes [12147,12162]
name: mock_get_scopes [12159,12174]
===
match
---
string: 'value' [42369,42376]
string: 'value' [42381,42388]
===
match
---
name: mock_hvac [18779,18788]
name: mock_hvac [18791,18800]
===
match
---
name: mock_file [15771,15780]
name: mock_file [15783,15792]
===
match
---
name: self [2968,2972]
name: self [2974,2978]
===
match
---
operator: , [38740,38741]
operator: , [38752,38753]
===
match
---
with_stmt [34275,34408]
with_stmt [34287,34420]
===
match
---
name: mock_hvac [31771,31780]
name: mock_hvac [31783,31792]
===
match
---
operator: , [6264,6265]
operator: , [6276,6277]
===
match
---
argument [27157,27169]
argument [27169,27181]
===
match
---
comparison [27858,27872]
comparison [27870,27884]
===
match
---
trailer [3862,3902]
trailer [3874,3914]
===
match
---
argument [4537,4554]
argument [4549,4566]
===
match
---
argument [26975,26996]
argument [26987,27008]
===
match
---
operator: { [30560,30561]
operator: { [30572,30573]
===
match
---
trailer [27595,27778]
trailer [27607,27790]
===
match
---
simple_stmt [21638,21681]
simple_stmt [21650,21693]
===
match
---
name: pytest [17296,17302]
name: pytest [17308,17314]
===
match
---
string: 'http://localhost:8180' [13064,13087]
string: 'http://localhost:8180' [13076,13099]
===
match
---
trailer [31902,31905]
trailer [31914,31917]
===
match
---
name: test_approle_missing_role [3701,3726]
name: test_approle_missing_role [3713,3738]
===
match
---
argument [26896,26923]
argument [26908,26935]
===
match
---
operator: @ [14054,14055]
operator: @ [14066,14067]
===
match
---
argument [40761,40777]
argument [40773,40789]
===
match
---
operator: = [41037,41038]
operator: = [41049,41050]
===
match
---
operator: , [32141,32142]
operator: , [32153,32154]
===
match
---
decorated [14449,15282]
decorated [14461,15294]
===
match
---
name: kv_engine_version [36798,36815]
name: kv_engine_version [36810,36827]
===
match
---
operator: = [8112,8113]
operator: = [8124,8125]
===
match
---
name: patch [14826,14831]
name: patch [14838,14843]
===
match
---
name: assert_called_with [6094,6112]
name: assert_called_with [6106,6124]
===
match
---
parameters [17173,17190]
parameters [17185,17202]
===
match
---
name: mock_hvac [39811,39820]
name: mock_hvac [39823,39832]
===
match
---
funcdef [6531,7421]
funcdef [6543,7433]
===
match
---
name: patch [8498,8503]
name: patch [8510,8515]
===
match
---
name: _VaultClient [25915,25927]
name: _VaultClient [25927,25939]
===
match
---
name: return_value [1675,1687]
name: return_value [1675,1687]
===
match
---
name: mock [36395,36399]
name: mock [36407,36411]
===
match
---
trailer [1647,1649]
trailer [1647,1649]
===
match
---
trailer [5347,5366]
trailer [5359,5378]
===
match
---
argument [20730,20743]
argument [20742,20755]
===
match
---
string: "credentials" [9037,9050]
string: "credentials" [9049,9062]
===
match
---
operator: , [20130,20131]
operator: , [20142,20143]
===
match
---
name: key_id [5117,5123]
name: key_id [5129,5135]
===
match
---
argument [8379,8406]
argument [8391,8418]
===
match
---
operator: = [21290,21291]
operator: = [21302,21303]
===
match
---
string: 'data' [38430,38436]
string: 'data' [38442,38448]
===
match
---
parameters [37176,37193]
parameters [37188,37205]
===
match
---
argument [8301,8318]
argument [8313,8330]
===
match
---
operator: , [22790,22791]
operator: , [22802,22803]
===
match
---
trailer [24677,24684]
trailer [24689,24696]
===
match
---
operator: , [22297,22298]
operator: , [22309,22310]
===
match
---
operator: = [21085,21086]
operator: = [21097,21098]
===
match
---
trailer [27081,27105]
trailer [27093,27117]
===
match
---
operator: , [6294,6295]
operator: , [6306,6307]
===
match
---
string: "other" [13707,13714]
string: "other" [13719,13726]
===
match
---
argument [34195,34222]
argument [34207,34234]
===
match
---
simple_stmt [13528,13726]
simple_stmt [13540,13738]
===
match
---
operator: , [11976,11977]
operator: , [11988,11989]
===
match
---
name: auth_type [3126,3135]
name: auth_type [3132,3141]
===
match
---
name: _VaultClient [11848,11860]
name: _VaultClient [11860,11872]
===
match
---
name: client [26118,26124]
name: client [26130,26136]
===
match
---
simple_stmt [7378,7421]
simple_stmt [7390,7433]
===
match
---
string: 'user' [4548,4554]
string: 'user' [4560,4566]
===
match
---
name: match [3875,3880]
name: match [3887,3892]
===
match
---
operator: == [24970,24972]
operator: == [24982,24984]
===
match
---
operator: , [33188,33189]
operator: , [33200,33201]
===
match
---
simple_stmt [43403,43434]
simple_stmt [43415,43446]
===
match
---
argument [28614,28633]
argument [28626,28645]
===
match
---
suite [14581,15282]
suite [14593,15294]
===
match
---
operator: = [18940,18941]
operator: = [18952,18953]
===
match
---
operator: = [38230,38231]
operator: = [38242,38243]
===
match
---
name: patch [25009,25014]
name: patch [25021,25026]
===
match
---
string: "pass" [20737,20743]
string: "pass" [20749,20755]
===
match
---
name: secret_id [4340,4349]
name: secret_id [4352,4361]
===
match
---
decorator [9908,10012]
decorator [9920,10024]
===
match
---
argument [25513,25528]
argument [25525,25540]
===
match
---
operator: = [10668,10669]
operator: = [10680,10681]
===
match
---
operator: , [41515,41516]
operator: , [41527,41528]
===
match
---
argument [40694,40712]
argument [40706,40724]
===
match
---
expr_stmt [21107,21325]
expr_stmt [21119,21337]
===
match
---
operator: = [32682,32683]
operator: = [32694,32695]
===
match
---
argument [3467,3483]
argument [3479,3495]
===
match
---
decorated [2192,2837]
decorated [2192,2843]
===
match
---
atom_expr [14913,14932]
atom_expr [14925,14944]
===
match
---
trailer [11050,11055]
trailer [11062,11067]
===
match
---
expr_stmt [36573,36616]
expr_stmt [36585,36628]
===
match
---
atom_expr [10443,10652]
atom_expr [10455,10664]
===
match
---
argument [42849,42867]
argument [42861,42879]
===
match
---
decorator [1116,1194]
decorator [1116,1194]
===
match
---
operator: , [39408,39409]
operator: , [39420,39421]
===
match
---
atom_expr [26815,26933]
atom_expr [26827,26945]
===
match
---
string: 'secret_key' [31460,31472]
string: 'secret_key' [31472,31484]
===
match
---
trailer [13465,13467]
trailer [13477,13479]
===
match
---
name: mock_get_scopes [10771,10786]
name: mock_get_scopes [10783,10798]
===
match
---
operator: = [25821,25822]
operator: = [25833,25834]
===
match
---
operator: = [4139,4140]
operator: = [4151,4152]
===
match
---
import_from [986,1068]
import_from [986,1068]
===
match
---
trailer [13115,13121]
trailer [13127,13133]
===
match
---
operator: = [4895,4896]
operator: = [4907,4908]
===
match
---
string: 'deletion_time' [36099,36114]
string: 'deletion_time' [36111,36126]
===
match
---
operator: = [8169,8170]
operator: = [8181,8182]
===
match
---
name: kv_engine_version [21663,21680]
name: kv_engine_version [21675,21692]
===
match
---
suite [2985,3610]
suite [2991,3622]
===
match
---
name: get_secret [27809,27819]
name: get_secret [27821,27831]
===
match
---
dotted_name [16131,16141]
dotted_name [16143,16153]
===
match
---
decorator [19802,19880]
decorator [19814,19892]
===
match
---
trailer [30124,30132]
trailer [30136,30144]
===
match
---
name: mount_point [27913,27924]
name: mount_point [27925,27936]
===
match
---
name: mock [5571,5575]
name: mock [5583,5587]
===
match
---
operator: = [19953,19954]
operator: = [19965,19966]
===
match
---
name: metadata [35506,35514]
name: metadata [35518,35526]
===
match
---
operator: , [34976,34977]
operator: , [34988,34989]
===
match
---
operator: { [33697,33698]
operator: { [33709,33710]
===
match
---
name: mock_hvac [29010,29019]
name: mock_hvac [29022,29031]
===
match
---
string: "http://localhost:8180" [33583,33606]
string: "http://localhost:8180" [33595,33618]
===
match
---
atom_expr [5732,5761]
atom_expr [5744,5773]
===
match
---
argument [29847,29868]
argument [29859,29880]
===
match
---
name: auth_type [13569,13578]
name: auth_type [13581,13590]
===
match
---
arglist [41720,41793]
arglist [41732,41805]
===
match
---
operator: , [5034,5035]
operator: , [5046,5047]
===
match
---
name: _VaultClient [27583,27595]
name: _VaultClient [27595,27607]
===
match
---
name: mock_get_scopes [10294,10309]
name: mock_get_scopes [10306,10321]
===
match
---
dotted_name [5571,5581]
dotted_name [5583,5593]
===
match
---
operator: , [40777,40778]
operator: , [40789,40790]
===
match
---
decorator [2842,2920]
decorator [2848,2926]
===
match
---
name: url [26191,26194]
name: url [26203,26206]
===
match
---
atom [29364,29666]
atom [29376,29678]
===
match
---
operator: , [32002,32003]
operator: , [32014,32015]
===
match
---
trailer [6086,6093]
trailer [6098,6105]
===
match
---
name: auth_mount_point [21249,21265]
name: auth_mount_point [21261,21277]
===
match
---
argument [3929,3948]
argument [3941,3960]
===
match
---
operator: = [42821,42822]
operator: = [42833,42834]
===
match
---
atom [11920,11936]
atom [11932,11948]
===
match
---
argument [42474,42494]
argument [42486,42506]
===
match
---
suite [24430,24998]
suite [24442,25010]
===
match
---
name: return_value [14248,14260]
name: return_value [14260,14272]
===
match
---
operator: = [36815,36816]
operator: = [36827,36828]
===
match
---
argument [8455,8471]
argument [8467,8483]
===
match
---
name: auth_type [28483,28492]
name: auth_type [28495,28504]
===
match
---
dictorsetmaker [33037,33316]
dictorsetmaker [33049,33328]
===
match
---
operator: @ [16130,16131]
operator: @ [16142,16143]
===
match
---
operator: = [4287,4288]
operator: = [4299,4300]
===
match
---
name: url [19177,19180]
name: url [19189,19192]
===
match
---
trailer [28393,28405]
trailer [28405,28417]
===
match
---
trailer [30524,30544]
trailer [30536,30556]
===
match
---
suite [16689,16731]
suite [16701,16743]
===
match
---
trailer [37314,37317]
trailer [37326,37329]
===
match
---
name: mock_hvac [24478,24487]
name: mock_hvac [24490,24499]
===
match
---
operator: == [27897,27899]
operator: == [27909,27911]
===
match
---
name: pytest [34280,34286]
name: pytest [34292,34298]
===
match
---
operator: = [6611,6612]
operator: = [6623,6624]
===
match
---
argument [10536,10562]
argument [10548,10574]
===
match
---
argument [28550,28566]
argument [28562,28578]
===
match
---
name: auth_type [39964,39973]
name: auth_type [39976,39985]
===
match
---
operator: = [2626,2627]
operator: = [2626,2627]
===
match
---
atom_expr [41331,41526]
atom_expr [41343,41538]
===
match
---
expr_stmt [8100,8130]
expr_stmt [8112,8142]
===
match
---
operator: , [21166,21167]
operator: , [21178,21179]
===
match
---
name: client [3412,3418]
name: client [3418,3424]
===
match
---
name: role_id [3451,3458]
name: role_id [3463,3470]
===
match
---
name: mock_hvac [13771,13780]
name: mock_hvac [13783,13792]
===
match
---
operator: , [32856,32857]
operator: , [32868,32869]
===
match
---
name: Client [22172,22178]
name: Client [22184,22190]
===
match
---
atom [30741,31043]
atom [30753,31055]
===
match
---
comparison [22393,22428]
comparison [22405,22440]
===
match
---
decorator [43254,43332]
decorator [43266,43344]
===
match
---
decorated [13286,14049]
decorated [13298,14061]
===
match
---
atom_expr [6150,6339]
atom_expr [6162,6351]
===
match
---
name: test_get_secret_metadata_v1 [36480,36507]
name: test_get_secret_metadata_v1 [36492,36519]
===
match
---
operator: , [10142,10143]
operator: , [10154,10155]
===
match
---
name: path [28038,28042]
name: path [28050,28054]
===
match
---
name: configure [11060,11069]
name: configure [11072,11081]
===
match
---
trailer [12534,12551]
trailer [12546,12563]
===
match
---
name: Client [9279,9285]
name: Client [9291,9297]
===
match
---
decorator [8581,8685]
decorator [8593,8697]
===
match
---
argument [42541,42552]
argument [42553,42564]
===
match
---
argument [6245,6264]
argument [6257,6276]
===
match
---
expr_stmt [28442,28685]
expr_stmt [28454,28697]
===
match
---
name: mock_hvac [2974,2983]
name: mock_hvac [2980,2989]
===
match
---
argument [33508,33527]
argument [33520,33539]
===
match
---
simple_stmt [8940,8992]
simple_stmt [8952,9004]
===
match
---
argument [19177,19204]
argument [19189,19216]
===
match
---
operator: , [9050,9051]
operator: , [9062,9063]
===
match
---
name: client [6040,6046]
name: client [6052,6058]
===
match
---
operator: = [28042,28043]
operator: = [28054,28055]
===
match
---
name: client [26331,26337]
name: client [26343,26349]
===
match
---
operator: , [4861,4862]
operator: , [4873,4874]
===
match
---
atom_expr [4695,4725]
atom_expr [4707,4737]
===
match
---
operator: = [31414,31415]
operator: = [31426,31427]
===
match
---
name: assert_called_with [15050,15068]
name: assert_called_with [15062,15080]
===
match
---
name: self [25783,25787]
name: self [25795,25799]
===
match
---
name: unittest [819,827]
name: unittest [819,827]
===
match
---
name: mock_hvac [3339,3348]
name: mock_hvac [3345,3354]
===
match
---
atom_expr [15251,15281]
atom_expr [15263,15293]
===
match
---
import_from [814,839]
import_from [814,839]
===
match
---
expr_stmt [40561,40591]
expr_stmt [40573,40603]
===
match
---
dotted_name [9820,9830]
dotted_name [9832,9842]
===
match
---
operator: , [6328,6329]
operator: , [6340,6341]
===
match
---
operator: , [30797,30798]
operator: , [30809,30810]
===
match
---
operator: = [7775,7776]
operator: = [7787,7788]
===
match
---
argument [27676,27692]
argument [27688,27704]
===
match
---
operator: } [31027,31028]
operator: } [31039,31040]
===
match
---
name: password [18524,18532]
name: password [18536,18544]
===
match
---
name: is_authenticated [4637,4653]
name: is_authenticated [4649,4665]
===
match
---
simple_stmt [21334,21363]
simple_stmt [21346,21375]
===
match
---
name: mock_client [41953,41964]
name: mock_client [41965,41976]
===
match
---
number: 1 [36816,36817]
number: 1 [36828,36829]
===
match
---
operator: , [21534,21535]
operator: , [21546,21547]
===
match
---
simple_stmt [16376,16611]
simple_stmt [16388,16623]
===
match
---
expr_stmt [2994,3024]
expr_stmt [3000,3030]
===
match
---
name: match [19679,19684]
name: match [19691,19696]
===
match
---
operator: = [28235,28236]
operator: = [28247,28248]
===
match
---
simple_stmt [6984,7013]
simple_stmt [6996,7025]
===
match
---
argument [34390,34406]
argument [34402,34418]
===
match
---
operator: , [44004,44005]
operator: , [44016,44017]
===
match
---
trailer [39213,39226]
trailer [39225,39238]
===
match
---
name: jwt [16009,16012]
name: jwt [16021,16024]
===
match
---
argument [17436,17463]
argument [17448,17475]
===
match
---
trailer [32933,32946]
trailer [32945,32958]
===
match
---
string: 'lease_id' [37436,37446]
string: 'lease_id' [37448,37458]
===
match
---
atom [10932,10952]
atom [10944,10964]
===
match
---
atom_expr [15949,16020]
atom_expr [15961,16032]
===
match
---
simple_stmt [19557,19588]
simple_stmt [19569,19600]
===
match
---
simple_stmt [21854,21898]
simple_stmt [21866,21910]
===
match
---
funcdef [17552,17998]
funcdef [17564,18010]
===
match
---
operator: = [22201,22202]
operator: = [22213,22214]
===
match
---
simple_stmt [875,918]
simple_stmt [875,918]
===
match
---
dotted_name [19803,19813]
dotted_name [19815,19825]
===
match
---
name: secret [30098,30104]
name: secret [30110,30116]
===
match
---
trailer [17035,17053]
trailer [17047,17065]
===
match
---
name: client [4375,4381]
name: client [4387,4393]
===
match
---
name: patch [39014,39019]
name: patch [39026,39031]
===
match
---
trailer [4911,4913]
trailer [4923,4925]
===
match
---
trailer [13976,13995]
trailer [13988,14007]
===
match
---
name: url [43700,43703]
name: url [43712,43715]
===
match
---
name: mock_client [26644,26655]
name: mock_client [26656,26667]
===
match
---
string: "radhost" [31236,31245]
string: "radhost" [31248,31257]
===
match
---
string: '' [30933,30935]
string: '' [30945,30947]
===
match
---
suite [36979,37048]
suite [36991,37060]
===
match
---
operator: = [5797,5798]
operator: = [5809,5810]
===
match
---
operator: = [40737,40738]
operator: = [40749,40750]
===
match
---
name: mock_client [31883,31894]
name: mock_client [31895,31906]
===
match
---
string: "http://localhost:8180" [26075,26098]
string: "http://localhost:8180" [26087,26110]
===
match
---
name: mock_client [21815,21826]
name: mock_client [21827,21838]
===
match
---
string: 'data' [37529,37535]
string: 'data' [37541,37547]
===
match
---
name: mock [19955,19959]
name: mock [19967,19971]
===
match
---
atom_expr [33635,33681]
atom_expr [33647,33693]
===
match
---
name: patch [14455,14460]
name: patch [14467,14472]
===
match
---
name: client [4485,4491]
name: client [4497,4503]
===
match
---
argument [42217,42236]
argument [42229,42248]
===
match
---
trailer [13806,13835]
trailer [13818,13847]
===
match
---
operator: = [15556,15557]
operator: = [15568,15569]
===
match
---
operator: = [22583,22584]
operator: = [22595,22596]
===
match
---
trailer [8202,8209]
trailer [8214,8221]
===
match
---
atom_expr [9000,9033]
atom_expr [9012,9045]
===
match
---
trailer [4938,4951]
trailer [4950,4963]
===
match
---
name: mock_hvac [25789,25798]
name: mock_hvac [25801,25810]
===
match
---
name: raises [17303,17309]
name: raises [17315,17321]
===
match
---
name: mock [39845,39849]
name: mock [39857,39861]
===
match
---
trailer [16898,16949]
trailer [16910,16961]
===
match
---
argument [24054,24081]
argument [24066,24093]
===
match
---
argument [5291,5318]
argument [5303,5330]
===
match
---
simple_stmt [36573,36617]
simple_stmt [36585,36629]
===
match
---
number: 8110 [38066,38070]
number: 8110 [38078,38082]
===
match
---
name: Client [23229,23235]
name: Client [23241,23247]
===
match
---
name: mock_hvac [8888,8897]
name: mock_hvac [8900,8909]
===
match
---
with_stmt [23724,23833]
with_stmt [23736,23845]
===
match
---
name: vault_client [2806,2818]
name: vault_client [2812,2824]
===
match
---
name: mock_client [11679,11690]
name: mock_client [11691,11702]
===
match
---
funcdef [40492,41071]
funcdef [40504,41083]
===
match
---
name: mock_hvac [41263,41272]
name: mock_hvac [41275,41284]
===
match
---
name: self [18773,18777]
name: self [18785,18789]
===
match
---
name: azure_tenant_id [5856,5871]
name: azure_tenant_id [5868,5883]
===
match
---
operator: @ [41809,41810]
operator: @ [41821,41822]
===
match
---
string: "role" [3459,3465]
string: "role" [3471,3477]
===
match
---
string: "radius" [42859,42867]
string: "radius" [42871,42879]
===
match
---
assert_stmt [1790,1833]
assert_stmt [1790,1833]
===
match
---
string: "pass" [32401,32407]
string: "pass" [32413,32419]
===
match
---
name: patch [30268,30273]
name: patch [30280,30285]
===
match
---
name: assert_called_with [12451,12469]
name: assert_called_with [12463,12481]
===
match
---
argument [41488,41515]
argument [41500,41527]
===
match
---
decorated [42568,43249]
decorated [42580,43261]
===
match
---
trailer [5741,5748]
trailer [5753,5760]
===
match
---
simple_stmt [23633,23664]
simple_stmt [23645,23676]
===
match
---
name: secret_id [6004,6013]
name: secret_id [6016,6025]
===
match
---
trailer [37004,37024]
trailer [37016,37036]
===
match
---
trailer [17810,17997]
trailer [17822,18009]
===
match
---
string: "data" [16921,16927]
string: "data" [16933,16939]
===
match
---
expr_stmt [29993,30048]
expr_stmt [30005,30060]
===
match
---
dotted_name [8493,8503]
dotted_name [8505,8515]
===
match
---
name: mock_client [8100,8111]
name: mock_client [8112,8123]
===
match
---
name: test_azure [5656,5666]
name: test_azure [5668,5678]
===
match
---
name: patch [15716,15721]
name: patch [15728,15733]
===
match
---
dotted_name [28894,28904]
dotted_name [28906,28916]
===
match
---
arglist [20112,20182]
arglist [20124,20194]
===
match
---
operator: , [29973,29974]
operator: , [29985,29986]
===
match
---
arglist [21947,22106]
arglist [21959,22118]
===
match
---
simple_stmt [27341,27372]
simple_stmt [27353,27384]
===
match
---
operator: = [5911,5912]
operator: = [5923,5924]
===
match
---
operator: = [25983,25984]
operator: = [25995,25996]
===
match
---
string: 'lease_id' [29263,29273]
string: 'lease_id' [29275,29285]
===
match
---
argument [43633,43653]
argument [43645,43665]
===
match
---
name: patch [4008,4013]
name: patch [4020,4025]
===
match
---
name: is_authenticated [16036,16052]
name: is_authenticated [16048,16064]
===
match
---
simple_stmt [36992,37048]
simple_stmt [37004,37060]
===
match
---
name: get_secret [33648,33658]
name: get_secret [33660,33670]
===
match
---
arglist [17384,17463]
arglist [17396,17475]
===
match
---
operator: } [35991,35992]
operator: } [36003,36004]
===
match
---
name: test_userpass_different_auth_mount_point [25742,25782]
name: test_userpass_different_auth_mount_point [25754,25794]
===
match
---
name: client [9254,9260]
name: client [9266,9272]
===
match
---
name: secret [31493,31499]
name: secret [31505,31511]
===
match
---
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [34734,34772]
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [34746,34784]
===
match
---
name: mock_client [27933,27944]
name: mock_client [27945,27956]
===
match
---
name: _VaultClient [4233,4245]
name: _VaultClient [4245,4257]
===
match
---
trailer [25177,25184]
trailer [25189,25196]
===
match
---
name: client_secret [7252,7265]
name: client_secret [7264,7277]
===
match
---
name: secret [42516,42522]
name: secret [42528,42534]
===
match
---
trailer [7594,7596]
trailer [7606,7608]
===
match
---
param [27315,27320]
param [27327,27332]
===
match
---
name: vault_client [13743,13755]
name: vault_client [13755,13767]
===
match
---
operator: , [8821,8822]
operator: , [8833,8834]
===
match
---
name: mock [17214,17218]
name: mock [17226,17230]
===
match
---
trailer [13040,13059]
trailer [13052,13071]
===
match
---
string: "role" [4604,4610]
string: "role" [4616,4622]
===
match
---
operator: == [6410,6412]
operator: == [6422,6424]
===
match
---
operator: = [21410,21411]
operator: = [21422,21423]
===
match
---
name: url [9578,9581]
name: url [9590,9593]
===
match
---
name: mock_client [20012,20023]
name: mock_client [20024,20035]
===
match
---
trailer [36589,36602]
trailer [36601,36614]
===
match
---
operator: , [29697,29698]
operator: , [29709,29710]
===
match
---
trailer [10309,10322]
trailer [10321,10334]
===
match
---
argument [4568,4585]
argument [4580,4597]
===
match
---
atom_expr [9089,9223]
atom_expr [9101,9235]
===
match
---
operator: , [8361,8362]
operator: , [8373,8374]
===
match
---
number: 2 [24910,24911]
number: 2 [24922,24923]
===
match
---
string: "user" [25292,25298]
string: "user" [25304,25310]
===
match
---
argument [41454,41474]
argument [41466,41486]
===
match
---
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [38285,38323]
string: '94011e25-f8dc-ec29-221b-1f9c1d9ad2ae' [38297,38335]
===
match
---
trailer [15147,15177]
trailer [15159,15189]
===
match
---
trailer [19996,20009]
trailer [20008,20021]
===
match
---
name: mock_client [25880,25891]
name: mock_client [25892,25903]
===
match
---
name: case [854,858]
name: case [854,858]
===
match
---
name: patch [11449,11454]
name: patch [11461,11466]
===
match
---
simple_stmt [39197,39241]
simple_stmt [39209,39253]
===
match
---
name: mock_hvac [22929,22938]
name: mock_hvac [22941,22950]
===
match
---
string: 'key' [41770,41775]
string: 'key' [41782,41787]
===
match
---
name: url [36831,36834]
name: url [36843,36846]
===
match
---
argument [16417,16439]
argument [16429,16451]
===
match
---
name: mock [7580,7584]
name: mock [7592,7596]
===
match
---
string: "The cas parameter is only valid for version 2" [43097,43144]
string: "The cas parameter is only valid for version 2" [43109,43156]
===
match
---
name: mock_client [42387,42398]
name: mock_client [42399,42410]
===
match
---
operator: = [3274,3275]
operator: = [3280,3281]
===
match
---
name: mock_client [42787,42798]
name: mock_client [42799,42810]
===
match
---
string: 'data' [30733,30739]
string: 'data' [30745,30751]
===
match
---
string: "http://localhost:8180" [16576,16599]
string: "http://localhost:8180" [16588,16611]
===
match
---
name: secret_path [43196,43207]
name: secret_path [43208,43219]
===
match
---
simple_stmt [34553,34584]
simple_stmt [34565,34596]
===
match
---
operator: = [10931,10932]
operator: = [10943,10944]
===
match
---
decorated [1483,1834]
decorated [1483,1834]
===
match
---
operator: } [37936,37937]
operator: } [37948,37949]
===
match
---
name: assert_called_with [4505,4523]
name: assert_called_with [4517,4535]
===
match
---
trailer [34012,34014]
trailer [34024,34026]
===
match
---
simple_stmt [22333,22378]
simple_stmt [22345,22390]
===
match
---
operator: = [4382,4383]
operator: = [4394,4395]
===
match
---
argument [22693,22745]
argument [22705,22757]
===
match
---
name: role_id [2470,2477]
name: role_id [2470,2477]
===
match
---
name: MagicMock [10222,10231]
name: MagicMock [10234,10243]
===
match
---
argument [42496,42514]
argument [42508,42526]
===
match
---
expr_stmt [5693,5723]
expr_stmt [5705,5735]
===
match
---
expr_stmt [37946,38156]
expr_stmt [37958,38168]
===
match
---
simple_stmt [26331,26376]
simple_stmt [26343,26388]
===
match
---
atom_expr [25555,25599]
atom_expr [25567,25611]
===
match
---
argument [42183,42203]
argument [42195,42215]
===
match
---
trailer [19220,19225]
trailer [19232,19237]
===
match
---
decorator [7426,7504]
decorator [7438,7516]
===
match
---
name: Client [32927,32933]
name: Client [32939,32945]
===
match
---
expr_stmt [15415,15445]
expr_stmt [15427,15457]
===
match
---
argument [9496,9523]
argument [9508,9535]
===
match
---
name: secret_path [41011,41022]
name: secret_path [41023,41034]
===
match
---
name: MagicMock [39850,39859]
name: MagicMock [39862,39871]
===
match
---
operator: == [24869,24871]
operator: == [24881,24883]
===
match
---
name: mock [8582,8586]
name: mock [8594,8598]
===
match
---
string: 'missing' [28877,28886]
string: 'missing' [28889,28898]
===
match
---
trailer [36552,36562]
trailer [36564,36574]
===
match
---
operator: = [41583,41584]
operator: = [41595,41596]
===
match
---
name: Client [19606,19612]
name: Client [19618,19624]
===
match
---
name: mock_hvac [22988,22997]
name: mock_hvac [23000,23009]
===
match
---
atom [9036,9065]
atom [9048,9077]
===
match
---
expr_stmt [5784,6031]
expr_stmt [5796,6043]
===
match
---
trailer [14394,14443]
trailer [14406,14455]
===
match
---
atom_expr [31805,31821]
atom_expr [31817,31833]
===
match
---
trailer [2435,2541]
trailer [2435,2541]
===
match
---
string: 'destroyed' [35258,35269]
string: 'destroyed' [35270,35281]
===
match
---
simple_stmt [23841,23973]
simple_stmt [23853,23985]
===
match
---
name: mock_hvac [14629,14638]
name: mock_hvac [14641,14650]
===
match
---
operator: = [10441,10442]
operator: = [10453,10454]
===
match
---
name: _VaultClient [6705,6717]
name: _VaultClient [6717,6729]
===
match
---
dictorsetmaker [29391,29419]
dictorsetmaker [29403,29431]
===
match
---
name: kv_engine_version [33508,33525]
name: kv_engine_version [33520,33537]
===
match
---
operator: , [28536,28537]
operator: , [28548,28549]
===
match
---
trailer [18173,18180]
trailer [18185,18192]
===
match
---
arglist [17310,17356]
arglist [17322,17368]
===
match
---
operator: , [41375,41376]
operator: , [41387,41388]
===
match
---
name: patch [3621,3626]
name: patch [3633,3638]
===
match
---
name: kv_engine_version [15264,15281]
name: kv_engine_version [15276,15293]
===
match
---
with_stmt [22662,22821]
with_stmt [22674,22833]
===
match
---
operator: = [2706,2707]
operator: = [2712,2713]
===
match
---
trailer [6354,6371]
trailer [6366,6383]
===
match
---
name: Client [4422,4428]
name: Client [4434,4440]
===
match
---
trailer [20368,20381]
trailer [20380,20393]
===
match
---
name: assert_called_with [9742,9760]
name: assert_called_with [9754,9772]
===
match
---
trailer [28431,28433]
trailer [28443,28445]
===
match
---
name: match [17322,17327]
name: match [17334,17339]
===
match
---
name: pytest [39507,39513]
name: pytest [39519,39525]
===
match
---
trailer [19236,19255]
trailer [19248,19267]
===
match
---
name: raises [14295,14301]
name: raises [14307,14313]
===
match
---
atom_expr [22134,22153]
atom_expr [22146,22165]
===
match
---
name: self [15389,15393]
name: self [15401,15405]
===
match
---
name: url [13649,13652]
name: url [13661,13664]
===
match
---
expr_stmt [26573,26603]
expr_stmt [26585,26615]
===
match
---
string: "path.json" [9464,9475]
string: "path.json" [9476,9487]
===
match
---
atom_expr [20327,20343]
atom_expr [20339,20355]
===
match
---
name: kv [27506,27508]
name: kv [27518,27520]
===
match
---
trailer [24783,24785]
trailer [24795,24797]
===
match
---
simple_stmt [36258,36389]
simple_stmt [36270,36401]
===
match
---
simple_stmt [3412,3506]
simple_stmt [3418,3518]
===
match
---
operator: , [8220,8221]
operator: , [8232,8233]
===
match
---
assert_stmt [24204,24246]
assert_stmt [24216,24258]
===
match
---
name: assert_called_with [16053,16071]
name: assert_called_with [16065,16083]
===
match
---
operator: = [12044,12045]
operator: = [12056,12057]
===
match
---
name: vault_client [17023,17035]
name: vault_client [17035,17047]
===
match
---
trailer [38870,38878]
trailer [38882,38890]
===
match
---
atom_expr [3514,3558]
atom_expr [3526,3570]
===
match
---
funcdef [22516,22821]
funcdef [22528,22833]
===
match
---
trailer [17671,17678]
trailer [17683,17690]
===
match
---
trailer [39520,39602]
trailer [39532,39614]
===
match
---
name: raises [40884,40890]
name: raises [40896,40902]
===
match
---
decorated [18003,18645]
decorated [18015,18657]
===
match
---
funcdef [18085,18645]
funcdef [18097,18657]
===
match
---
atom_expr [9269,9333]
atom_expr [9281,9345]
===
match
---
trailer [15433,15443]
trailer [15445,15455]
===
match
---
argument [36699,36720]
argument [36711,36732]
===
match
---
expr_stmt [1658,1701]
expr_stmt [1658,1701]
===
match
---
name: vault_client [4695,4707]
name: vault_client [4707,4719]
===
match
---
trailer [15263,15281]
trailer [15275,15293]
===
match
---
dictorsetmaker [36032,36193]
dictorsetmaker [36044,36205]
===
match
---
operator: , [16915,16916]
operator: , [16927,16928]
===
match
---
atom_expr [41992,42021]
atom_expr [42004,42033]
===
match
---
operator: , [26057,26058]
operator: , [26069,26070]
===
match
---
operator: = [43096,43097]
operator: = [43108,43109]
===
match
---
name: is_authenticated [2748,2764]
name: is_authenticated [2754,2770]
===
match
---
atom_expr [13250,13280]
atom_expr [13262,13292]
===
match
---
name: mock_client [43474,43485]
name: mock_client [43486,43497]
===
match
---
name: match [39533,39538]
name: match [39545,39550]
===
match
---
name: auth_type [14722,14731]
name: auth_type [14734,14743]
===
match
---
name: assert_called_once_with [41683,41706]
name: assert_called_once_with [41695,41718]
===
match
---
name: assert_called_with [12369,12387]
name: assert_called_with [12381,12399]
===
match
---
operator: = [32438,32439]
operator: = [32450,32451]
===
match
---
name: secrets [27498,27505]
name: secrets [27510,27517]
===
match
---
simple_stmt [16029,16074]
simple_stmt [16041,16086]
===
match
---
operator: , [35939,35940]
operator: , [35951,35952]
===
match
---
operator: , [41054,41055]
operator: , [41066,41067]
===
match
---
string: 'secret' [28028,28036]
string: 'secret' [28040,28048]
===
match
---
name: self [17174,17178]
name: self [17186,17190]
===
match
---
suite [5684,6444]
suite [5696,6456]
===
match
---
operator: = [40573,40574]
operator: = [40585,40586]
===
match
---
trailer [22673,22680]
trailer [22685,22692]
===
match
---
name: mock_hvac [8080,8089]
name: mock_hvac [8092,8101]
===
match
---
number: 0 [35746,35747]
number: 0 [35758,35759]
===
match
---
decorator [2192,2270]
decorator [2192,2270]
===
match
---
name: client [16724,16730]
name: client [16736,16742]
===
match
---
name: mount_point [32671,32682]
name: mount_point [32683,32694]
===
match
---
atom_expr [11210,11240]
atom_expr [11222,11252]
===
match
---
argument [39533,39601]
argument [39545,39613]
===
match
---
simple_stmt [15949,16021]
simple_stmt [15961,16033]
===
match
---
string: 'renewable' [32044,32055]
string: 'renewable' [32056,32067]
===
match
---
name: assert_called_once_with [28826,28849]
name: assert_called_once_with [28838,28861]
===
match
---
name: url [39455,39458]
name: url [39467,39470]
===
match
---
name: mock_client [40632,40643]
name: mock_client [40644,40655]
===
match
---
operator: = [39843,39844]
operator: = [39855,39856]
===
match
---
argument [7801,7828]
argument [7813,7840]
===
match
---
trailer [41658,41682]
trailer [41670,41694]
===
match
---
name: patch [7432,7437]
name: patch [7444,7449]
===
match
---
argument [32693,32707]
argument [32705,32719]
===
match
---
operator: { [40206,40207]
operator: { [40218,40219]
===
match
---
name: auth_type [18931,18940]
name: auth_type [18943,18952]
===
match
---
simple_stmt [32917,32961]
simple_stmt [32929,32973]
===
match
---
atom_expr [27796,27842]
atom_expr [27808,27854]
===
match
---
arglist [28850,28886]
arglist [28862,28898]
===
match
---
name: url [42250,42253]
name: url [42262,42265]
===
match
---
parameters [6572,6589]
parameters [6584,6601]
===
match
---
argument [12885,12903]
argument [12897,12915]
===
match
---
operator: , [37181,37182]
operator: , [37193,37194]
===
match
---
name: gcp [11056,11059]
name: gcp [11068,11071]
===
match
---
simple_stmt [18890,19096]
simple_stmt [18902,19108]
===
match
---
name: role_id [2699,2706]
name: role_id [2705,2712]
===
match
---
atom_expr [6638,6667]
atom_expr [6650,6679]
===
match
---
name: Client [8898,8904]
name: Client [8910,8916]
===
match
---
assert_stmt [19372,19414]
assert_stmt [19384,19426]
===
match
---
name: Client [15464,15470]
name: Client [15476,15482]
===
match
---
name: mock [2331,2335]
name: mock [2331,2335]
===
match
---
operator: , [28201,28202]
operator: , [28213,28214]
===
match
---
operator: = [1688,1689]
operator: = [1688,1689]
===
match
---
name: self [19915,19919]
name: self [19927,19931]
===
match
---
name: kubernetes_role [15583,15598]
name: kubernetes_role [15595,15610]
===
match
---
trailer [14210,14220]
trailer [14222,14232]
===
match
---
number: 2 [7385,7386]
number: 2 [7397,7398]
===
match
---
operator: = [10546,10547]
operator: = [10558,10559]
===
match
---
name: url [22198,22201]
name: url [22210,22213]
===
match
---
simple_stmt [13476,13520]
simple_stmt [13488,13532]
===
match
---
trailer [14858,14876]
trailer [14870,14888]
===
match
---
expr_stmt [3792,3835]
expr_stmt [3804,3847]
===
match
---
trailer [11088,11136]
trailer [11100,11148]
===
match
---
trailer [24884,24894]
trailer [24896,24906]
===
match
---
operator: , [29651,29652]
operator: , [29663,29664]
===
match
---
operator: = [15598,15599]
operator: = [15610,15611]
===
match
---
expr_stmt [37242,37285]
expr_stmt [37254,37297]
===
match
---
number: 2 [20824,20825]
number: 2 [20836,20837]
===
match
---
trailer [9724,9741]
trailer [9736,9753]
===
match
---
dotted_name [19421,19431]
dotted_name [19433,19443]
===
match
---
operator: = [6219,6220]
operator: = [6231,6232]
===
match
---
string: 'lease_duration' [38397,38413]
string: 'lease_duration' [38409,38425]
===
match
---
trailer [4182,4195]
trailer [4194,4207]
===
match
---
operator: , [10562,10563]
operator: , [10574,10575]
===
match
---
operator: = [42234,42235]
operator: = [42246,42247]
===
match
---
trailer [22356,22375]
trailer [22368,22387]
===
match
---
trailer [27557,27559]
trailer [27569,27571]
===
match
---
decorator [11246,11331]
decorator [11258,11343]
===
match
---
name: port [20745,20749]
name: port [20757,20761]
===
match
---
decorator [25656,25734]
decorator [25668,25746]
===
match
---
number: 8110 [28562,28566]
number: 8110 [28574,28578]
===
match
---
argument [12110,12137]
argument [12122,12149]
===
match
---
name: url [5291,5294]
name: url [5303,5306]
===
match
---
string: "http://localhost:8180" [35464,35487]
string: "http://localhost:8180" [35476,35499]
===
match
---
name: auth_aws_iam [4492,4504]
name: auth_aws_iam [4504,4516]
===
match
---
trailer [26729,26737]
trailer [26741,26749]
===
match
---
argument [9578,9605]
argument [9590,9617]
===
match
---
trailer [16106,16124]
trailer [16118,16136]
===
match
---
trailer [13059,13088]
trailer [13071,13100]
===
match
---
name: mock_client [1690,1701]
name: mock_client [1690,1701]
===
match
---
name: url [25317,25320]
name: url [25329,25332]
===
match
---
trailer [21662,21680]
trailer [21674,21692]
===
match
---
simple_stmt [41316,41527]
simple_stmt [41328,41539]
===
match
---
operator: , [15650,15651]
operator: , [15662,15663]
===
match
---
string: "token" [26851,26858]
string: "token" [26863,26870]
===
match
---
name: mount_point [27119,27130]
name: mount_point [27131,27142]
===
match
---
name: radius_host [29847,29858]
name: radius_host [29859,29870]
===
match
---
expr_stmt [11759,11824]
expr_stmt [11771,11836]
===
match
---
arglist [16417,16600]
arglist [16429,16612]
===
match
---
name: test_approle_different_auth_mount_point [2928,2967]
name: test_approle_different_auth_mount_point [2934,2973]
===
match
---
string: "user" [8431,8437]
string: "user" [8443,8449]
===
match
---
argument [5977,5990]
argument [5989,6002]
===
match
---
name: vault_client [6413,6425]
name: vault_client [6425,6437]
===
match
---
name: mock [3767,3771]
name: mock [3779,3783]
===
match
---
operator: = [20736,20737]
operator: = [20748,20749]
===
match
---
trailer [34690,34703]
trailer [34702,34715]
===
match
---
simple_stmt [12425,12520]
simple_stmt [12437,12532]
===
match
---
atom_expr [26612,26641]
atom_expr [26624,26653]
===
match
---
expr_stmt [21815,21845]
expr_stmt [21827,21857]
===
match
---
string: 'data' [38456,38462]
string: 'data' [38468,38474]
===
match
---
operator: , [1455,1456]
operator: , [1455,1456]
===
match
---
operator: = [7578,7579]
operator: = [7590,7591]
===
match
---
simple_stmt [16285,16316]
simple_stmt [16297,16328]
===
match
---
name: auth_type [23081,23090]
name: auth_type [23093,23102]
===
match
---
argument [3375,3402]
argument [3381,3408]
===
match
---
param [31771,31780]
param [31783,31792]
===
match
---
simple_stmt [11647,11691]
simple_stmt [11659,11703]
===
match
---
name: mock [17637,17641]
name: mock [17649,17653]
===
match
---
trailer [3556,3558]
trailer [3568,3570]
===
match
---
name: client [5218,5224]
name: client [5230,5236]
===
match
---
name: Client [25410,25416]
name: Client [25422,25428]
===
match
---
operator: == [24912,24914]
operator: == [24924,24926]
===
match
---
simple_stmt [1790,1834]
simple_stmt [1790,1834]
===
match
---
operator: , [42277,42278]
operator: , [42289,42290]
===
match
---
string: "kube_role" [15153,15164]
string: "kube_role" [15165,15176]
===
match
---
name: vault_client [21343,21355]
name: vault_client [21355,21367]
===
match
---
name: url [4296,4299]
name: url [4308,4311]
===
match
---
name: kv_engine_version [34236,34253]
name: kv_engine_version [34248,34265]
===
match
---
name: client [19126,19132]
name: client [19138,19144]
===
match
---
name: vault_client [3311,3323]
name: vault_client [3317,3329]
===
match
---
operator: = [11010,11011]
operator: = [11022,11023]
===
insert-node
---
name: TestVaultClient [1085,1100]
to
classdef [1079,44030]
at 0
===
insert-node
---
name: TestCase [1101,1109]
to
classdef [1079,44030]
at 1
===
insert-tree
---
trailer [2666,2671]
    name: auth [2667,2671]
to
atom_expr [2660,2732]
at 1
===
insert-tree
---
trailer [2679,2685]
    name: login [2680,2685]
to
atom_expr [2660,2732]
at 3
===
insert-tree
---
trailer [3424,3429]
    name: auth [3425,3429]
to
atom_expr [3412,3505]
at 1
===
insert-tree
---
trailer [3437,3443]
    name: login [3438,3443]
to
atom_expr [3412,3505]
at 3
===
update-node
---
name: auth_approle [2667,2679]
replace auth_approle by approle
===
update-node
---
name: auth_approle [3419,3431]
replace auth_approle by approle
===
delete-node
---
name: TestVaultClient [1085,1100]
===
===
delete-node
---
name: TestCase [1101,1109]
===
