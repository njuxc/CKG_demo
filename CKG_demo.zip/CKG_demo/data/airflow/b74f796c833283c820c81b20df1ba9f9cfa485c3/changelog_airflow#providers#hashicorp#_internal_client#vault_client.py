===
match
---
simple_stmt [12266,12425]
simple_stmt [12266,12425]
===
match
---
atom_expr [8637,8654]
atom_expr [8637,8654]
===
match
---
operator: = [12441,12442]
operator: = [12441,12442]
===
match
---
name: secret_path [20156,20167]
name: secret_path [20168,20179]
===
match
---
testlist_star_expr [12480,12494]
testlist_star_expr [12480,12494]
===
match
---
trailer [15574,15577]
trailer [15586,15589]
===
match
---
name: host [10757,10761]
name: host [10757,10761]
===
match
---
simple_stmt [8535,8574]
simple_stmt [8535,8574]
===
match
---
name: self [10339,10343]
name: self [10339,10343]
===
match
---
trailer [20298,20301]
trailer [20310,20313]
===
match
---
trailer [13824,13894]
trailer [13824,13894]
===
match
---
funcdef [13900,14230]
funcdef [13900,14242]
===
match
---
atom_expr [9760,9784]
atom_expr [9760,9784]
===
match
---
name: mount_point [5325,5336]
name: mount_point [5325,5336]
===
match
---
comparison [17739,17766]
comparison [17751,17778]
===
match
---
trailer [7093,7149]
trailer [7093,7149]
===
match
---
name: VaultError [7246,7256]
name: VaultError [7246,7256]
===
match
---
simple_stmt [8056,8127]
simple_stmt [8056,8127]
===
match
---
operator: , [13494,13495]
operator: , [13494,13495]
===
match
---
suite [7500,7761]
suite [7500,7761]
===
match
---
expr_stmt [8582,8628]
expr_stmt [8582,8628]
===
match
---
operator: = [11916,11917]
operator: = [11916,11917]
===
match
---
name: typing [790,796]
name: typing [790,796]
===
match
---
atom_expr [14001,14134]
atom_expr [14001,14140]
===
match
---
operator: , [12369,12370]
operator: , [12369,12370]
===
match
---
name: self [8895,8899]
name: self [8895,8899]
===
match
---
argument [14061,14085]
argument [14067,14091]
===
match
---
simple_stmt [8249,8278]
simple_stmt [8249,8278]
===
match
---
name: self [10422,10426]
name: self [10422,10426]
===
match
---
with_item [11641,11676]
with_item [11641,11676]
===
match
---
name: Optional [18419,18427]
name: Optional [18431,18439]
===
match
---
name: self [15472,15476]
name: self [15484,15488]
===
match
---
suite [13526,13895]
suite [13526,13895]
===
match
---
trailer [13542,13559]
trailer [13542,13559]
===
match
---
name: cached_property [932,947]
name: cached_property [932,947]
===
match
---
name: login [12073,12078]
name: login [12073,12078]
===
match
---
atom_expr [11385,11398]
atom_expr [11385,11398]
===
match
---
expr_stmt [20066,20241]
expr_stmt [20078,20253]
===
match
---
trailer [13251,13256]
trailer [13251,13256]
===
match
---
operator: == [9495,9497]
operator: == [9495,9497]
===
match
---
name: key_id [8454,8460]
name: key_id [8454,8460]
===
match
---
name: f [14392,14393]
name: f [14404,14405]
===
match
---
fstring_end: " [10123,10124]
fstring_end: " [10123,10124]
===
match
---
trailer [10766,10778]
trailer [10766,10778]
===
match
---
except_clause [18049,18067]
except_clause [18061,18079]
===
match
---
operator: = [8785,8786]
operator: = [8785,8786]
===
match
---
simple_stmt [8856,8887]
simple_stmt [8856,8887]
===
match
---
trailer [19964,20013]
trailer [19976,20025]
===
match
---
operator: , [13202,13203]
operator: , [13202,13203]
===
match
---
operator: , [15665,15666]
operator: , [15677,15678]
===
match
---
testlist_comp [1279,1415]
testlist_comp [1279,1415]
===
match
---
name: self [11263,11267]
name: self [11263,11267]
===
match
---
name: _client [10017,10024]
name: _client [10017,10024]
===
match
---
name: self [8764,8768]
name: self [8764,8768]
===
match
---
number: 2 [8125,8126]
number: 2 [8125,8126]
===
match
---
trailer [11766,11782]
trailer [11766,11782]
===
match
---
return_stmt [20446,20461]
return_stmt [20458,20473]
===
match
---
operator: = [10445,10446]
operator: = [10445,10446]
===
match
---
name: radius [10966,10972]
name: radius [10966,10972]
===
match
---
name: gcp_key_path [8642,8654]
name: gcp_key_path [8642,8654]
===
match
---
trailer [16823,16829]
trailer [16835,16841]
===
match
---
name: InvalidPath [976,987]
name: InvalidPath [976,987]
===
match
---
atom_expr [13347,13366]
atom_expr [13347,13366]
===
match
---
operator: = [20220,20221]
operator: = [20232,20233]
===
match
---
operator: , [10631,10632]
operator: , [10631,10632]
===
match
---
name: VALID_KV_VERSIONS [6455,6472]
name: VALID_KV_VERSIONS [6455,6472]
===
match
---
expr_stmt [8895,8929]
expr_stmt [8895,8929]
===
match
---
name: airflow [1036,1043]
name: airflow [1036,1043]
===
match
---
operator: = [12084,12085]
operator: = [12084,12085]
===
match
---
name: self [13000,13004]
name: self [13000,13004]
===
match
---
string: "secret" [5344,5352]
string: "secret" [5344,5352]
===
match
---
param [17000,17036]
param [17012,17048]
===
match
---
name: self [9722,9726]
name: self [9722,9726]
===
match
---
name: self [13860,13864]
name: self [13860,13864]
===
match
---
name: auth [12952,12956]
name: auth [12952,12956]
===
match
---
name: token [6890,6895]
name: token [6890,6895]
===
match
---
trailer [11359,11364]
trailer [11359,11364]
===
match
---
operator: , [20414,20415]
operator: , [20426,20427]
===
match
---
operator: ** [6194,6196]
operator: ** [6194,6196]
===
match
---
atom_expr [8286,8307]
atom_expr [8286,8307]
===
match
---
trailer [9283,9297]
trailer [9283,9297]
===
match
---
argument [11810,11817]
argument [11810,11817]
===
match
---
name: key_id [5570,5576]
name: key_id [5570,5576]
===
match
---
trailer [11212,11325]
trailer [11212,11325]
===
match
---
operator: = [6001,6002]
operator: = [6001,6002]
===
match
---
name: auth_mount_point [12114,12130]
name: auth_mount_point [12114,12130]
===
match
---
operator: = [10889,10890]
operator: = [10889,10890]
===
match
---
atom_expr [6333,6488]
atom_expr [6333,6488]
===
match
---
parameters [11105,11133]
parameters [11105,11133]
===
match
---
operator: = [20377,20378]
operator: = [20389,20390]
===
match
---
tfpdef [18352,18368]
tfpdef [18364,18380]
===
match
---
argument [20169,20182]
argument [20181,20194]
===
match
---
trailer [10068,10125]
trailer [10068,10125]
===
match
---
atom_expr [5460,5473]
atom_expr [5460,5473]
===
match
---
name: kwargs [9219,9225]
name: kwargs [9219,9225]
===
match
---
suite [14554,15989]
suite [14566,16001]
===
match
---
atom_expr [5418,5431]
atom_expr [5418,5431]
===
match
---
comparison [9955,9983]
comparison [9955,9983]
===
match
---
operator: = [12108,12109]
operator: = [12108,12109]
===
match
---
tfpdef [11112,11132]
tfpdef [11112,11132]
===
match
---
trailer [5389,5394]
trailer [5389,5394]
===
match
---
argument [12079,12095]
argument [12079,12095]
===
match
---
except_clause [15716,15734]
except_clause [15728,15746]
===
match
---
comparison [7025,7047]
comparison [7025,7047]
===
match
---
string: "Secret not found %s with mount point %s and version %s" [18113,18169]
string: "Secret not found %s with mount point %s and version %s" [18125,18181]
===
match
---
fstring_string: The auth_type is not supported:  [6583,6615]
fstring_string: The auth_type is not supported:  [6583,6615]
===
match
---
string: "userpass" [9973,9983]
string: "userpass" [9973,9983]
===
match
---
name: auth_type [9803,9812]
name: auth_type [9803,9812]
===
match
---
name: self [8727,8731]
name: self [8727,8731]
===
match
---
trailer [12459,12470]
trailer [12459,12470]
===
match
---
import_from [12266,12424]
import_from [12266,12424]
===
match
---
simple_stmt [8222,8241]
simple_stmt [8222,8241]
===
match
---
name: InvalidPath [18056,18067]
name: InvalidPath [18068,18079]
===
match
---
string: "The cas parameter is only valid for version 2" [19965,20012]
string: "The cas parameter is only valid for version 2" [19977,20024]
===
match
---
name: secrets [17905,17912]
name: secrets [17917,17924]
===
match
---
trailer [10717,10722]
trailer [10717,10722]
===
match
---
trailer [6780,6848]
trailer [6780,6848]
===
match
---
trailer [19903,19921]
trailer [19915,19933]
===
match
---
trailer [12687,12691]
trailer [12687,12691]
===
match
---
trailer [18427,18432]
trailer [18439,18444]
===
match
---
trailer [14168,14181]
trailer [14179,14187]
===
match
---
operator: , [13633,13634]
operator: , [13633,13634]
===
match
---
param [5325,5353]
param [5325,5353]
===
match
---
name: mount_point [16732,16743]
name: mount_point [16744,16755]
===
match
---
name: read_secret_version [17919,17938]
name: read_secret_version [17931,17950]
===
match
---
operator: , [1238,1239]
operator: , [1238,1239]
===
match
---
suite [9027,10267]
suite [9027,10267]
===
match
---
name: auth_mount_point [10478,10494]
name: auth_mount_point [10478,10494]
===
match
---
name: self [10675,10679]
name: self [10675,10679]
===
match
---
name: auth_type [8175,8184]
name: auth_type [8175,8184]
===
match
---
trailer [7396,7467]
trailer [7396,7467]
===
match
---
name: _client [10374,10381]
name: _client [10374,10381]
===
match
---
if_stmt [13963,14230]
if_stmt [13963,14242]
===
match
---
trailer [14547,14553]
trailer [14559,14565]
===
match
---
operator: = [11830,11831]
operator: = [11830,11831]
===
match
---
string: "azure" [7492,7499]
string: "azure" [7492,7499]
===
match
---
name: secret [20371,20377]
name: secret [20383,20389]
===
match
---
trailer [6343,6488]
trailer [6343,6488]
===
match
---
name: Client [10311,10317]
name: Client [10311,10317]
===
match
---
funcdef [12845,13467]
funcdef [12845,13467]
===
match
---
name: self [12109,12113]
name: self [12109,12113]
===
match
---
expr_stmt [20268,20437]
expr_stmt [20280,20449]
===
match
---
trailer [8226,8232]
trailer [8226,8232]
===
match
---
name: cloud [12296,12301]
name: cloud [12296,12301]
===
match
---
simple_stmt [14001,14135]
simple_stmt [14001,14141]
===
match
---
argument [11050,11071]
argument [11050,11071]
===
match
---
name: auth_mount_point [11295,11311]
name: auth_mount_point [11295,11311]
===
match
---
atom_expr [7558,7629]
atom_expr [7558,7629]
===
match
---
name: gcp [12688,12691]
name: gcp [12688,12691]
===
match
---
trailer [13004,13020]
trailer [13004,13020]
===
match
---
operator: = [14528,14529]
operator: = [14540,14541]
===
match
---
name: Optional [6164,6172]
name: Optional [6164,6172]
===
match
---
name: VALID_AUTH_TYPES [1243,1259]
name: VALID_AUTH_TYPES [1243,1259]
===
match
---
trailer [12743,12760]
trailer [12743,12760]
===
match
---
suite [9665,9709]
suite [9665,9709]
===
match
---
name: username [8379,8387]
name: username [8379,8387]
===
match
---
name: _set_token [9922,9932]
name: _set_token [9922,9932]
===
match
---
operator: = [5258,5259]
operator: = [5258,5259]
===
match
---
trailer [5857,5862]
trailer [5857,5862]
===
match
---
trailer [12183,12201]
trailer [12183,12201]
===
match
---
trailer [16669,16672]
trailer [16681,16684]
===
match
---
trailer [11697,11702]
trailer [11697,11702]
===
match
---
simple_stmt [7380,7468]
simple_stmt [7380,7468]
===
match
---
name: super [6219,6224]
name: super [6219,6224]
===
match
---
name: azure_resource [7520,7534]
name: azure_resource [7520,7534]
===
match
---
number: 1 [17765,17766]
number: 1 [17777,17778]
===
match
---
atom_expr [11239,11252]
atom_expr [11239,11252]
===
match
---
trailer [16748,16760]
trailer [16760,16772]
===
match
---
name: secret_path [20144,20155]
name: secret_path [20156,20167]
===
match
---
param [5879,5919]
param [5879,5919]
===
match
---
simple_stmt [14376,14401]
simple_stmt [14388,14413]
===
match
---
operator: = [18011,18012]
operator: = [18023,18024]
===
match
---
name: self [11005,11009]
name: self [11005,11009]
===
match
---
funcdef [16933,18304]
funcdef [16945,18316]
===
match
---
atom_expr [8135,8143]
atom_expr [8135,8143]
===
match
---
name: self [14047,14051]
name: self [14053,14057]
===
match
---
name: _auth_userpass [10276,10290]
name: _auth_userpass [10276,10290]
===
match
---
trailer [9764,9775]
trailer [9764,9775]
===
match
---
trailer [9611,9620]
trailer [9611,9620]
===
match
---
trailer [17918,17938]
trailer [17930,17950]
===
match
---
argument [17974,18002]
argument [17986,18014]
===
match
---
trailer [12972,13217]
trailer [12972,13217]
===
match
---
name: self [10291,10295]
name: self [10291,10295]
===
match
---
operator: , [5438,5439]
operator: , [5438,5439]
===
match
---
name: VALID_KV_VERSIONS [1205,1222]
name: VALID_KV_VERSIONS [1205,1222]
===
match
---
decorator [8974,8991]
decorator [8974,8991]
===
match
---
suite [9348,9389]
suite [9348,9389]
===
match
---
name: auth_userpass [10382,10395]
name: auth_userpass [10382,10395]
===
match
---
atom_expr [9238,9252]
atom_expr [9238,9252]
===
match
---
atom_expr [13662,13676]
atom_expr [13662,13676]
===
match
---
atom_expr [10339,10360]
atom_expr [10339,10360]
===
match
---
trailer [20081,20088]
trailer [20093,20100]
===
match
---
operator: , [15635,15636]
operator: , [15647,15648]
===
match
---
operator: , [5869,5870]
operator: , [5869,5870]
===
match
---
strings [6581,6671]
strings [6581,6671]
===
match
---
atom_expr [15884,15900]
atom_expr [15896,15912]
===
match
---
tfpdef [5362,5394]
tfpdef [5362,5394]
===
match
---
name: auth_type [9727,9736]
name: auth_type [9727,9736]
===
match
---
simple_stmt [9678,9709]
simple_stmt [9678,9709]
===
match
---
with_stmt [11636,11948]
with_stmt [11636,11948]
===
match
---
if_stmt [13535,13895]
if_stmt [13535,13895]
===
match
---
operator: = [13880,13881]
operator: = [13880,13881]
===
match
---
name: role_id [14039,14046]
name: role_id [14045,14052]
===
match
---
arglist [12541,12618]
arglist [12541,12618]
===
match
---
operator: , [5233,5234]
operator: , [5233,5234]
===
match
---
atom_expr [10374,10508]
atom_expr [10374,10508]
===
match
---
trailer [14522,14527]
trailer [14534,14539]
===
match
---
simple_stmt [12944,13218]
simple_stmt [12944,13218]
===
match
---
trailer [11724,11741]
trailer [11724,11741]
===
match
---
name: VaultError [6553,6563]
name: VaultError [6553,6563]
===
match
---
if_stmt [7022,7150]
if_stmt [7022,7150]
===
match
---
try_stmt [833,948]
try_stmt [833,948]
===
match
---
tfpdef [5879,5911]
tfpdef [5879,5911]
===
match
---
operator: = [8421,8422]
operator: = [8421,8422]
===
match
---
name: secret_path [18187,18198]
name: secret_path [18199,18210]
===
match
---
expr_stmt [8249,8277]
expr_stmt [8249,8277]
===
match
---
operator: , [15804,15805]
operator: , [15816,15817]
===
match
---
simple_stmt [11690,11705]
simple_stmt [11690,11705]
===
match
---
name: client_secret [13123,13136]
name: client_secret [13123,13136]
===
match
---
argument [15619,15635]
argument [15631,15647]
===
match
---
name: secret_path [16024,16035]
name: secret_path [16036,16047]
===
match
---
tfpdef [12227,12247]
tfpdef [12227,12247]
===
match
---
atom_expr [9361,9388]
atom_expr [9361,9388]
===
match
---
operator: == [9253,9255]
operator: == [9253,9255]
===
match
---
trailer [10729,10739]
trailer [10729,10739]
===
match
---
operator: , [5918,5919]
operator: , [5918,5919]
===
match
---
operator: = [15471,15472]
operator: = [15483,15484]
===
match
---
trailer [20096,20099]
trailer [20108,20111]
===
match
---
if_stmt [10336,10605]
if_stmt [10336,10605]
===
match
---
atom_expr [9634,9648]
atom_expr [9634,9648]
===
match
---
name: _auth_kubernetes [9683,9699]
name: _auth_kubernetes [9683,9699]
===
match
---
tfpdef [14480,14496]
tfpdef [14492,14508]
===
match
---
name: self [13662,13666]
name: self [13662,13666]
===
match
---
comparison [6271,6313]
comparison [6271,6313]
===
match
---
name: str [5858,5861]
name: str [5858,5861]
===
match
---
name: configure [10973,10982]
name: configure [10973,10982]
===
match
---
name: str [5949,5952]
name: str [5949,5952]
===
match
---
atom_expr [19767,19789]
atom_expr [19779,19801]
===
match
---
decorated [8974,10267]
decorated [8974,10267]
===
match
---
name: int [17025,17028]
name: int [17037,17040]
===
match
---
tfpdef [5411,5431]
tfpdef [5411,5431]
===
match
---
simple_stmt [10052,10126]
simple_stmt [10052,10126]
===
match
---
param [5608,5640]
param [5608,5640]
===
match
---
operator: , [15458,15459]
operator: , [15470,15471]
===
match
---
string: "radius" [9816,9824]
string: "radius" [9816,9824]
===
match
---
not_test [6886,6895]
not_test [6886,6895]
===
match
---
number: 2 [19793,19794]
number: 2 [19805,19806]
===
match
---
name: Optional [5987,5995]
name: Optional [5987,5995]
===
match
---
trailer [10477,10494]
trailer [10477,10494]
===
match
---
comparison [9238,9265]
comparison [9238,9265]
===
match
---
trailer [10570,10579]
trailer [10570,10579]
===
match
---
trailer [17990,18002]
trailer [18002,18014]
===
match
---
name: self [9517,9521]
name: self [9517,9521]
===
match
---
name: secrets [15395,15402]
name: secrets [15407,15414]
===
match
---
name: secret_path [15806,15817]
name: secret_path [15818,15829]
===
match
---
param [14480,14497]
param [14492,14509]
===
match
---
trailer [11556,11627]
trailer [11556,11627]
===
match
---
name: radius_secret [10808,10821]
name: radius_secret [10808,10821]
===
match
---
name: method [19799,19805]
name: method [19811,19817]
===
match
---
name: LoggingMixin [1075,1087]
name: LoggingMixin [1075,1087]
===
match
---
if_stmt [10135,10267]
if_stmt [10135,10267]
===
match
---
name: auth_mount_point [11725,11741]
name: auth_mount_point [11725,11741]
===
match
---
operator: , [20384,20385]
operator: , [20396,20397]
===
match
---
param [16982,16999]
param [16994,17011]
===
match
---
simple_stmt [11540,11628]
simple_stmt [11540,11628]
===
match
---
name: _client [12675,12682]
name: _client [12675,12682]
===
match
---
name: self [13094,13098]
name: self [13094,13098]
===
match
---
if_stmt [7336,7468]
if_stmt [7336,7468]
===
match
---
operator: = [15381,15382]
operator: = [15393,15394]
===
match
---
tfpdef [5570,5591]
tfpdef [5570,5591]
===
match
---
param [11976,11996]
param [11976,11996]
===
match
---
if_stmt [15185,15708]
if_stmt [15197,15720]
===
match
---
name: _client [13496,13503]
name: _client [13496,13503]
===
match
---
trailer [15387,15394]
trailer [15399,15406]
===
match
---
string: 'userpass' [1404,1414]
string: 'userpass' [1404,1414]
===
match
---
atom_expr [9955,9969]
atom_expr [9955,9969]
===
match
---
atom_expr [11030,11048]
atom_expr [11030,11048]
===
match
---
name: dict [5906,5910]
name: dict [5906,5910]
===
match
---
return_stmt [10178,10192]
return_stmt [10178,10192]
===
match
---
trailer [17912,17915]
trailer [17924,17927]
===
match
---
atom_expr [20196,20212]
atom_expr [20208,20224]
===
match
---
number: 2 [1201,1202]
number: 2 [1201,1202]
===
match
---
trailer [12113,12130]
trailer [12113,12130]
===
match
---
name: self [8582,8586]
name: self [8582,8586]
===
match
---
name: self [20077,20081]
name: self [20089,20093]
===
match
---
suite [7952,8047]
suite [7952,8047]
===
match
---
name: self [8193,8197]
name: self [8193,8197]
===
match
---
arglist [10557,10603]
arglist [10557,10603]
===
match
---
name: self [13347,13351]
name: self [13347,13351]
===
match
---
operator: == [7782,7784]
operator: == [7782,7784]
===
match
---
name: kubernetes_role [11793,11808]
name: kubernetes_role [11793,11808]
===
match
---
trailer [12527,12628]
trailer [12527,12628]
===
match
---
atom_expr [8895,8913]
atom_expr [8895,8913]
===
match
---
param [10297,10317]
param [10297,10317]
===
match
---
param [5448,5481]
param [5448,5481]
===
match
---
name: self [12909,12913]
name: self [12909,12913]
===
match
---
name: mount_point [12097,12108]
name: mount_point [12097,12108]
===
match
---
atom_expr [10225,10266]
atom_expr [10225,10266]
===
match
---
simple_stmt [6547,6686]
simple_stmt [6547,6686]
===
match
---
suite [10206,10267]
suite [10206,10267]
===
match
---
name: kubernetes_jwt_path [8609,8628]
name: kubernetes_jwt_path [8609,8628]
===
match
---
simple_stmt [8504,8527]
simple_stmt [8504,8527]
===
match
---
trailer [13304,13320]
trailer [13304,13320]
===
match
---
name: kv [17913,17915]
name: kv [17925,17927]
===
match
---
name: token [14384,14389]
name: token [14396,14401]
===
match
---
name: self [9917,9921]
name: self [9917,9921]
===
match
---
operator: , [1341,1342]
operator: , [1341,1342]
===
match
---
operator: , [18264,18265]
operator: , [18276,18277]
===
match
---
operator: = [11238,11239]
operator: = [11238,11239]
===
match
---
atom_expr [13505,13516]
atom_expr [13505,13516]
===
match
---
name: VaultError [6333,6343]
name: VaultError [6333,6343]
===
match
---
operator: == [6870,6872]
operator: == [6870,6872]
===
match
---
param [18346,18351]
param [18358,18363]
===
match
---
suite [13791,13895]
suite [13791,13895]
===
match
---
argument [11023,11048]
argument [11023,11048]
===
match
---
comparison [15188,15215]
comparison [15200,15227]
===
match
---
expr_stmt [1243,1417]
expr_stmt [1243,1417]
===
match
---
name: token_path [5448,5458]
name: token_path [5448,5458]
===
match
---
name: self [14298,14302]
name: self [14310,14314]
===
match
---
with_item [14332,14358]
with_item [14344,14370]
===
match
---
operator: = [8743,8744]
operator: = [8743,8744]
===
match
---
atom_expr [9214,9225]
atom_expr [9214,9225]
===
match
---
atom_expr [10093,10107]
atom_expr [10093,10107]
===
match
---
name: hvac [13505,13509]
name: hvac [13505,13509]
===
match
---
suite [19935,20014]
suite [19947,20026]
===
match
---
simple_stmt [8158,8185]
simple_stmt [8158,8185]
===
match
---
name: google [12289,12295]
name: google [12289,12295]
===
match
---
atom_expr [5756,5769]
atom_expr [5756,5769]
===
match
---
name: VaultError [10225,10235]
name: VaultError [10225,10235]
===
match
---
name: auth_type [7772,7781]
name: auth_type [7772,7781]
===
match
---
argument [12815,12838]
argument [12815,12838]
===
match
---
comparison [9402,9427]
comparison [9402,9427]
===
match
---
simple_stmt [15849,15861]
simple_stmt [15861,15873]
===
match
---
simple_stmt [8469,8496]
simple_stmt [8469,8496]
===
match
---
simple_stmt [9838,9865]
simple_stmt [9838,9865]
===
match
---
name: VaultError [19825,19835]
name: VaultError [19837,19847]
===
match
---
operator: , [5960,5961]
operator: , [5960,5961]
===
match
---
suite [11871,11948]
suite [11871,11948]
===
match
---
name: hvac [9186,9190]
name: hvac [9186,9190]
===
match
---
operator: == [9813,9815]
operator: == [9813,9815]
===
match
---
trailer [6235,6237]
trailer [6235,6237]
===
match
---
arglist [10757,10912]
arglist [10757,10912]
===
match
---
param [18352,18369]
param [18364,18381]
===
match
---
trailer [8815,8830]
trailer [8815,8830]
===
match
---
name: kubernetes_jwt_path [5735,5754]
name: kubernetes_jwt_path [5735,5754]
===
match
---
comparison [7772,7793]
comparison [7772,7793]
===
match
---
name: str [5765,5768]
name: str [5765,5768]
===
match
---
name: method [18384,18390]
name: method [18396,18402]
===
match
---
trailer [10343,10360]
trailer [10343,10360]
===
match
---
atom_expr [15188,15210]
atom_expr [15200,15222]
===
match
---
name: auth_mount_point [10895,10911]
name: auth_mount_point [10895,10911]
===
match
---
simple_stmt [8286,8327]
simple_stmt [8286,8327]
===
match
---
operator: , [11817,11818]
operator: , [11817,11818]
===
match
---
trailer [8508,8516]
trailer [8508,8516]
===
match
---
atom_expr [8938,8954]
atom_expr [8938,8954]
===
match
---
trailer [9190,9197]
trailer [9190,9197]
===
match
---
trailer [11792,11808]
trailer [11792,11808]
===
match
---
operator: , [6096,6097]
operator: , [6096,6097]
===
match
---
expr_stmt [11690,11704]
expr_stmt [11690,11704]
===
match
---
trailer [15408,15420]
trailer [15420,15432]
===
match
---
name: port [11050,11054]
name: port [11050,11054]
===
match
---
param [10291,10296]
param [10291,10296]
===
match
---
suite [11742,11854]
suite [11742,11854]
===
match
---
tfpdef [10297,10317]
tfpdef [10297,10317]
===
match
---
trailer [10016,10025]
trailer [10016,10025]
===
match
---
name: f [14357,14358]
name: f [14369,14370]
===
match
---
name: VaultError [19954,19964]
name: VaultError [19966,19976]
===
match
---
operator: = [14390,14391]
operator: = [14402,14403]
===
match
---
name: azure_tenant_id [5970,5985]
name: azure_tenant_id [5970,5985]
===
match
---
trailer [11413,11422]
trailer [11413,11422]
===
match
---
name: self [10890,10894]
name: self [10890,10894]
===
match
---
fstring_string: Authentication type ' [10071,10092]
fstring_string: Authentication type ' [10071,10092]
===
match
---
simple_stmt [14161,14230]
simple_stmt [14167,14242]
===
match
---
simple_stmt [12675,12762]
simple_stmt [12675,12762]
===
match
---
trailer [14341,14352]
trailer [14353,14364]
===
match
---
name: secrets [16662,16669]
name: secrets [16674,16681]
===
match
---
trailer [17938,18040]
trailer [17950,18052]
===
match
---
tfpdef [16982,16998]
tfpdef [16994,17010]
===
match
---
name: token [5411,5416]
name: token [5411,5416]
===
match
---
name: Optional [5295,5303]
name: Optional [5295,5303]
===
match
---
string: "token" [6710,6717]
string: "token" [6710,6717]
===
match
---
name: f [11696,11697]
name: f [11696,11697]
===
match
---
simple_stmt [16643,16775]
simple_stmt [16655,16787]
===
match
---
atom_expr [12053,12131]
atom_expr [12053,12131]
===
match
---
name: password [5530,5538]
name: password [5530,5538]
===
match
---
name: read_secret [15409,15420]
name: read_secret [15421,15432]
===
match
---
atom_expr [19825,19887]
atom_expr [19837,19899]
===
match
---
trailer [11364,11369]
trailer [11364,11369]
===
match
---
atom_expr [8407,8420]
atom_expr [8407,8420]
===
match
---
name: get_credentials_and_project_id [12383,12413]
name: get_credentials_and_project_id [12383,12413]
===
match
---
suite [13231,13467]
suite [13231,13467]
===
match
---
expr_stmt [8504,8526]
expr_stmt [8504,8526]
===
match
---
trailer [8586,8606]
trailer [8586,8606]
===
match
---
name: kwargs [8198,8204]
name: kwargs [8198,8204]
===
match
---
operator: , [987,988]
operator: , [987,988]
===
match
---
name: InvalidPath [15723,15734]
name: InvalidPath [15735,15746]
===
match
---
operator: = [10761,10762]
operator: = [10761,10762]
===
match
---
suite [12257,12840]
suite [12257,12840]
===
match
---
operator: = [8233,8234]
operator: = [8233,8234]
===
match
---
operator: , [808,809]
operator: , [808,809]
===
match
---
fstring_end: " [6628,6629]
fstring_end: " [6628,6629]
===
match
---
name: azure_tenant_id [13305,13320]
name: azure_tenant_id [13305,13320]
===
match
---
arglist [17956,18026]
arglist [17968,18038]
===
match
---
operator: = [8831,8832]
operator: = [8831,8832]
===
match
---
operator: , [10579,10580]
operator: , [10579,10580]
===
match
---
if_stmt [7769,8047]
if_stmt [7769,8047]
===
match
---
trailer [12165,12170]
trailer [12165,12170]
===
match
---
simple_stmt [17886,18041]
simple_stmt [17898,18053]
===
match
---
name: credentials [12815,12826]
name: credentials [12815,12826]
===
match
---
atom_expr [14298,14313]
atom_expr [14310,14325]
===
match
---
name: self [10446,10450]
name: self [10446,10450]
===
match
---
operator: -> [16042,16044]
operator: -> [16054,16056]
===
match
---
name: VaultError [7386,7396]
name: VaultError [7386,7396]
===
match
---
if_stmt [7642,7761]
if_stmt [7642,7761]
===
match
---
name: radius_host [11010,11021]
name: radius_host [11010,11021]
===
match
---
trailer [9726,9736]
trailer [9726,9736]
===
match
---
simple_stmt [15541,15708]
simple_stmt [15553,15720]
===
match
---
name: kubernetes_role [8540,8555]
name: kubernetes_role [8540,8555]
===
match
---
operator: == [9335,9337]
operator: == [9335,9337]
===
match
---
name: _client [9612,9619]
name: _client [9612,9619]
===
match
---
name: Optional [16045,16053]
name: Optional [16057,16065]
===
match
---
trailer [15762,15836]
trailer [15774,15848]
===
match
---
operator: , [5598,5599]
operator: , [5598,5599]
===
match
---
operator: , [12725,12726]
operator: , [12725,12726]
===
match
---
name: self [15188,15192]
name: self [15200,15204]
===
match
---
simple_stmt [15970,15989]
simple_stmt [15982,16001]
===
match
---
atom_expr [5940,5953]
atom_expr [5940,5953]
===
match
---
name: self [8056,8060]
name: self [8056,8060]
===
match
---
parameters [11969,11997]
parameters [11969,11997]
===
match
---
trailer [11506,11526]
trailer [11506,11526]
===
match
---
simple_stmt [15870,15962]
simple_stmt [15882,15974]
===
match
---
expr_stmt [8374,8398]
expr_stmt [8374,8398]
===
match
---
string: "Vault Authentication Error!" [10236,10265]
string: "Vault Authentication Error!" [10236,10265]
===
match
---
operator: = [20419,20420]
operator: = [20431,20432]
===
match
---
string: "Metadata might only be used with version 2 of the KV engine." [17797,17859]
string: "Metadata might only be used with version 2 of the KV engine." [17809,17871]
===
match
---
atom_expr [8504,8516]
atom_expr [8504,8516]
===
match
---
atom_expr [15472,15488]
atom_expr [15484,15500]
===
match
---
atom_expr [1224,1233]
atom_expr [1224,1233]
===
match
---
argument [10437,10459]
argument [10437,10459]
===
match
---
param [6151,6185]
param [6151,6185]
===
match
---
atom_expr [1261,1270]
atom_expr [1261,1270]
===
match
---
trailer [15823,15835]
trailer [15835,15847]
===
match
---
funcdef [8995,10267]
funcdef [8995,10267]
===
match
---
simple_stmt [8407,8432]
simple_stmt [8407,8432]
===
match
---
atom_expr [10710,10926]
atom_expr [10710,10926]
===
match
---
name: _client [10710,10717]
name: _client [10710,10717]
===
match
---
operator: , [6141,6142]
operator: , [6141,6142]
===
match
---
raise_stmt [7682,7760]
raise_stmt [7682,7760]
===
match
---
operator: , [12603,12604]
operator: , [12603,12604]
===
match
---
name: _client [11888,11895]
name: _client [11888,11895]
===
match
---
argument [10461,10494]
argument [10461,10494]
===
match
---
trailer [9638,9648]
trailer [9638,9648]
===
match
---
name: secrets [15564,15571]
name: secrets [15576,15583]
===
match
---
name: self [17893,17897]
name: self [17905,17909]
===
match
---
operator: = [15674,15675]
operator: = [15686,15687]
===
match
---
trailer [16053,16059]
trailer [16065,16071]
===
match
---
trailer [9457,9466]
trailer [9457,9466]
===
match
---
simple_stmt [12480,12629]
simple_stmt [12480,12629]
===
match
---
name: self [10844,10848]
name: self [10844,10848]
===
match
---
expr_stmt [8335,8365]
expr_stmt [8335,8365]
===
match
---
name: VaultError [17786,17796]
name: VaultError [17798,17808]
===
match
---
name: resource [13338,13346]
name: resource [13338,13346]
===
match
---
argument [13611,13633]
argument [13611,13633]
===
match
---
fstring [6432,6474]
fstring [6432,6474]
===
match
---
name: auth_type [9325,9334]
name: auth_type [9325,9334]
===
match
---
operator: , [12413,12414]
operator: , [12413,12414]
===
match
---
name: gcp_key_path [8657,8669]
name: gcp_key_path [8657,8669]
===
match
---
trailer [9959,9969]
trailer [9959,9969]
===
match
---
name: int [18428,18431]
name: int [18440,18443]
===
match
---
suite [7665,7761]
suite [7665,7761]
===
match
---
fstring_expr [10092,10108]
fstring_expr [10092,10108]
===
match
---
name: auth_type [7025,7034]
name: auth_type [7025,7034]
===
match
---
name: url [9198,9201]
name: url [9198,9201]
===
match
---
operator: { [6652,6653]
operator: { [6652,6653]
===
match
---
name: Optional [6033,6041]
name: Optional [6033,6041]
===
match
---
name: auth_type [7479,7488]
name: auth_type [7479,7488]
===
match
---
name: method [20214,20220]
name: method [20226,20232]
===
match
---
name: auth_mount_point [13746,13762]
name: auth_mount_point [13746,13762]
===
match
---
expr_stmt [8440,8460]
expr_stmt [8440,8460]
===
match
---
comparison [7161,7186]
comparison [7161,7186]
===
match
---
trailer [16553,16617]
trailer [16565,16629]
===
match
---
suite [7826,7919]
suite [7826,7919]
===
match
---
trailer [9855,9864]
trailer [9855,9864]
===
match
---
atom_expr [5987,6000]
atom_expr [5987,6000]
===
match
---
if_stmt [9235,10126]
if_stmt [9235,10126]
===
match
---
operator: , [13320,13321]
operator: , [13320,13321]
===
match
---
tfpdef [5688,5718]
tfpdef [5688,5718]
===
match
---
argument [20371,20384]
argument [20383,20396]
===
match
---
return_stmt [15849,15860]
return_stmt [15861,15872]
===
match
---
raise_stmt [11540,11627]
raise_stmt [11540,11627]
===
match
---
simple_stmt [10219,10267]
simple_stmt [10219,10267]
===
match
---
atom_expr [6219,6237]
atom_expr [6219,6237]
===
match
---
trailer [10395,10508]
trailer [10395,10508]
===
match
---
name: credentials [12702,12713]
name: credentials [12702,12713]
===
match
---
name: secret_version [14498,14512]
name: secret_version [14510,14524]
===
match
---
suite [14359,14401]
suite [14371,14413]
===
match
---
name: secrets [20089,20096]
name: secrets [20101,20108]
===
match
---
operator: , [14085,14086]
operator: , [14091,14092]
===
match
---
atom_expr [5619,5632]
atom_expr [5619,5632]
===
match
---
name: str [5996,5999]
name: str [5996,5999]
===
match
---
name: hvac [12876,12880]
name: hvac [12876,12880]
===
match
---
param [12867,12887]
param [12867,12887]
===
match
---
operator: , [15817,15818]
operator: , [15829,15830]
===
match
---
name: client [15388,15394]
name: client [15400,15406]
===
match
---
expr_stmt [8637,8669]
expr_stmt [8637,8669]
===
match
---
name: int [1229,1232]
name: int [1229,1232]
===
match
---
name: mount_point [11278,11289]
name: mount_point [11278,11289]
===
match
---
expr_stmt [8407,8431]
expr_stmt [8407,8431]
===
match
---
name: self [16815,16819]
name: self [16827,16831]
===
match
---
fstring_string: It should be one of  [6434,6454]
fstring_string: It should be one of  [6434,6454]
===
match
---
simple_stmt [8335,8366]
simple_stmt [8335,8366]
===
match
---
trailer [10145,10162]
trailer [10145,10162]
===
match
---
suite [1501,20462]
suite [1501,20474]
===
match
---
atom_expr [14376,14389]
atom_expr [14388,14401]
===
match
---
name: radius_secret [7938,7951]
name: radius_secret [7938,7951]
===
match
---
parameters [14473,14535]
parameters [14485,14547]
===
match
---
param [10633,10653]
param [10633,10653]
===
match
---
trailer [8942,8954]
trailer [8942,8954]
===
match
---
argument [12727,12760]
argument [12727,12760]
===
match
---
simple_stmt [9361,9389]
simple_stmt [9361,9389]
===
match
---
name: auth_type [9485,9494]
name: auth_type [9485,9494]
===
match
---
name: _client [12227,12234]
name: _client [12227,12234]
===
match
---
trailer [15908,15926]
trailer [15920,15938]
===
match
---
name: str [5222,5225]
name: str [5222,5225]
===
match
---
operator: = [5227,5228]
operator: = [5227,5228]
===
match
---
atom_expr [13300,13320]
atom_expr [13300,13320]
===
match
---
expr_stmt [8222,8240]
expr_stmt [8222,8240]
===
match
---
name: hvac [10642,10646]
name: hvac [10642,10646]
===
match
---
name: DEFAULT_KV_ENGINE_VERSION [1173,1198]
name: DEFAULT_KV_ENGINE_VERSION [1173,1198]
===
match
---
name: self [9554,9558]
name: self [9554,9558]
===
match
---
trailer [18095,18279]
trailer [18107,18291]
===
match
---
trailer [8411,8420]
trailer [8411,8420]
===
match
---
name: password [11268,11276]
name: password [11268,11276]
===
match
---
if_stmt [14295,14454]
if_stmt [14307,14466]
===
match
---
suite [9266,9307]
suite [9266,9307]
===
match
---
atom_expr [20279,20437]
atom_expr [20291,20449]
===
match
---
operator: = [5432,5433]
operator: = [5432,5433]
===
match
---
name: str [16995,16998]
name: str [17007,17010]
===
match
---
name: Optional [5381,5389]
name: Optional [5381,5389]
===
match
---
operator: = [12189,12190]
operator: = [12189,12190]
===
match
---
operator: -> [12889,12891]
operator: -> [12889,12891]
===
match
---
atom_expr [9320,9334]
atom_expr [9320,9334]
===
match
---
simple_stmt [8727,8756]
simple_stmt [8727,8756]
===
match
---
name: self [10473,10477]
name: self [10473,10477]
===
match
---
atom_expr [5213,5226]
atom_expr [5213,5226]
===
match
---
trailer [10162,10164]
trailer [10162,10164]
===
match
---
simple_stmt [948,1000]
simple_stmt [948,1000]
===
match
---
atom_expr [12582,12603]
atom_expr [12582,12603]
===
match
---
try_stmt [17869,18304]
try_stmt [17881,18316]
===
match
---
operator: , [11937,11938]
operator: , [11937,11938]
===
match
---
name: self [12739,12743]
name: self [12739,12743]
===
match
---
name: client_id [13384,13393]
name: client_id [13384,13393]
===
match
---
atom_expr [9402,9416]
atom_expr [9402,9416]
===
match
---
name: mount_point [14087,14098]
name: mount_point [14093,14104]
===
match
---
operator: , [13020,13021]
operator: , [13020,13021]
===
match
---
argument [20416,20423]
argument [20428,20435]
===
match
---
name: self [18346,18350]
name: self [18358,18362]
===
match
---
fstring_start: f" [6630,6632]
fstring_start: f" [6630,6632]
===
match
---
name: self [11502,11506]
name: self [11502,11506]
===
match
---
name: VALID_KV_VERSIONS [6296,6313]
name: VALID_KV_VERSIONS [6296,6313]
===
match
---
trailer [6563,6685]
trailer [6563,6685]
===
match
---
string: "data" [15946,15952]
string: "data" [15958,15964]
===
match
---
name: mount_point [15637,15648]
name: mount_point [15649,15660]
===
match
---
operator: , [11021,11022]
operator: , [11021,11022]
===
match
---
name: auth_mount_point [8291,8307]
name: auth_mount_point [8291,8307]
===
match
---
name: secret_id [14219,14228]
name: secret_id [14231,14240]
===
match
---
atom_expr [5295,5308]
atom_expr [5295,5308]
===
match
---
atom_expr [10138,10164]
atom_expr [10138,10164]
===
match
---
operator: -> [12249,12251]
operator: -> [12249,12251]
===
match
---
trailer [13272,13466]
trailer [13272,13466]
===
match
---
operator: == [7171,7173]
operator: == [7171,7173]
===
match
---
operator: = [5954,5955]
operator: = [5954,5955]
===
match
---
name: str [5549,5552]
name: str [5549,5552]
===
match
---
expr_stmt [8158,8184]
expr_stmt [8158,8184]
===
match
---
atom_expr [15937,15961]
atom_expr [15949,15973]
===
match
---
atom_expr [14392,14400]
atom_expr [14404,14412]
===
match
---
name: self [13741,13745]
name: self [13741,13745]
===
match
---
operator: { [6454,6455]
operator: { [6454,6455]
===
match
---
name: mount_point [18221,18232]
name: mount_point [18233,18244]
===
match
---
trailer [16819,16823]
trailer [16831,16835]
===
match
---
name: self [8222,8226]
name: self [8222,8226]
===
match
---
simple_stmt [6327,6489]
simple_stmt [6327,6489]
===
match
---
trailer [15192,15210]
trailer [15204,15222]
===
match
---
atom_expr [13933,13944]
atom_expr [13933,13944]
===
match
---
if_stmt [11717,11948]
if_stmt [11717,11948]
===
match
---
name: role_id [13886,13893]
name: role_id [13886,13893]
===
match
---
name: auth [13252,13256]
name: auth [13252,13256]
===
match
---
atom_expr [11831,11852]
atom_expr [11831,11852]
===
match
---
name: _client [11352,11359]
name: _client [11352,11359]
===
match
---
name: Optional [5897,5905]
name: Optional [5897,5905]
===
match
---
simple_stmt [9517,9541]
simple_stmt [9517,9541]
===
match
---
name: kubernetes_role [7207,7222]
name: kubernetes_role [7207,7222]
===
match
---
name: scopes [12612,12618]
name: scopes [12612,12618]
===
match
---
atom_expr [11465,11476]
atom_expr [11465,11476]
===
match
---
name: login [11370,11375]
name: login [11370,11375]
===
match
---
expr_stmt [8056,8126]
expr_stmt [8056,8126]
===
match
---
simple_stmt [13244,13467]
simple_stmt [13244,13467]
===
match
---
name: token_path [6740,6750]
name: token_path [6740,6750]
===
match
---
string: "radius" [7785,7793]
string: "radius" [7785,7793]
===
match
---
name: self [9878,9882]
name: self [9878,9882]
===
match
---
name: return_data [15870,15881]
name: return_data [15882,15893]
===
match
---
name: auth_type [9639,9648]
name: auth_type [9639,9648]
===
match
---
name: DEFAULT_KUBERNETES_JWT_PATH [1089,1116]
name: DEFAULT_KUBERNETES_JWT_PATH [1089,1116]
===
match
---
suite [6751,6849]
suite [6751,6849]
===
match
---
argument [16732,16760]
argument [16744,16772]
===
match
---
trailer [6041,6046]
trailer [6041,6046]
===
match
---
name: get_secret_metadata [15998,16017]
name: get_secret_metadata [16010,16029]
===
match
---
simple_stmt [7077,7150]
simple_stmt [7077,7150]
===
match
---
simple_stmt [12053,12132]
simple_stmt [12053,12132]
===
match
---
name: configure [12805,12814]
name: configure [12805,12814]
===
match
---
trailer [15752,15756]
trailer [15764,15768]
===
match
---
param [5277,5316]
param [5277,5316]
===
match
---
parameters [12860,12888]
parameters [12860,12888]
===
match
---
operator: , [18382,18383]
operator: , [18394,18395]
===
match
---
name: List [1261,1265]
name: List [1261,1265]
===
match
---
atom_expr [5540,5553]
atom_expr [5540,5553]
===
match
---
return_stmt [15970,15988]
return_stmt [15982,16000]
===
match
---
tfpdef [5448,5473]
tfpdef [5448,5473]
===
match
---
name: exceptions [958,968]
name: exceptions [958,968]
===
match
---
comparison [20025,20052]
comparison [20037,20064]
===
match
---
trailer [7985,8046]
trailer [7985,8046]
===
match
---
name: radius_secret [8900,8913]
name: radius_secret [8900,8913]
===
match
---
funcdef [10610,11086]
funcdef [10610,11086]
===
match
---
atom_expr [8678,8699]
atom_expr [8678,8699]
===
match
---
name: scopes [12605,12611]
name: scopes [12605,12611]
===
match
---
trailer [18220,18232]
trailer [18232,18244]
===
match
---
fstring_end: " [6670,6671]
fstring_end: " [6670,6671]
===
match
---
name: self [8440,8444]
name: self [8440,8444]
===
match
---
tfpdef [5277,5308]
tfpdef [5277,5308]
===
match
---
operator: , [10778,10779]
operator: , [10778,10779]
===
match
---
funcdef [14235,14454]
funcdef [14247,14466]
===
match
---
number: 1 [20051,20052]
number: 1 [20063,20064]
===
match
---
name: role [11783,11787]
name: role [11783,11787]
===
match
---
name: VaultError [10058,10068]
name: VaultError [10058,10068]
===
match
---
param [11970,11975]
param [11970,11975]
===
match
---
name: self [18081,18085]
name: self [18093,18097]
===
match
---
name: client [15557,15563]
name: client [15569,15575]
===
match
---
parameters [13489,13517]
parameters [13489,13517]
===
match
---
name: _client [9700,9707]
name: _client [9700,9707]
===
match
---
trailer [10894,10911]
trailer [10894,10911]
===
match
---
argument [10878,10911]
argument [10878,10911]
===
match
---
name: self [8504,8508]
name: self [8504,8508]
===
match
---
trailer [9218,9225]
trailer [9218,9225]
===
match
---
suite [6210,8969]
suite [6210,8969]
===
match
---
name: auth_kubernetes [11896,11911]
name: auth_kubernetes [11896,11911]
===
match
---
name: secret [20176,20182]
name: secret [20188,20194]
===
match
---
name: _client [12788,12795]
name: _client [12788,12795]
===
match
---
operator: = [12826,12827]
operator: = [12826,12827]
===
match
---
name: get_secret [14463,14473]
name: get_secret [14475,14485]
===
match
---
trailer [12814,12839]
trailer [12814,12839]
===
match
---
operator: == [15927,15929]
operator: == [15939,15941]
===
match
---
test [15884,15961]
test [15896,15973]
===
match
---
name: self [18216,18220]
name: self [18228,18232]
===
match
---
if_stmt [7807,7919]
if_stmt [7807,7919]
===
match
---
name: _auth_gcp [12211,12220]
name: _auth_gcp [12211,12220]
===
match
---
raise_stmt [6764,6848]
raise_stmt [6764,6848]
===
match
---
name: role_id [7056,7063]
name: role_id [7056,7063]
===
match
---
if_stmt [7200,7324]
if_stmt [7200,7324]
===
match
---
trailer [11158,11175]
trailer [11158,11175]
===
match
---
name: Optional [5756,5764]
name: Optional [5756,5764]
===
match
---
trailer [14021,14134]
trailer [14027,14140]
===
match
---
import_from [842,879]
import_from [842,879]
===
match
---
operator: = [18406,18407]
operator: = [18418,18419]
===
match
---
name: method [20221,20227]
name: method [20233,20239]
===
match
---
name: secret_id [8474,8483]
name: secret_id [8474,8483]
===
match
---
name: auth_mount_point [13186,13202]
name: auth_mount_point [13186,13202]
===
match
---
argument [13169,13202]
argument [13169,13202]
===
match
---
string: "kubernetes" [9652,9664]
string: "kubernetes" [9652,9664]
===
match
---
simple_stmt [8374,8399]
simple_stmt [8374,8399]
===
match
---
string: "approle" [9256,9265]
string: "approle" [9256,9265]
===
match
---
name: Response [18449,18457]
name: Response [18461,18469]
===
match
---
operator: , [14478,14479]
operator: , [14490,14491]
===
match
---
name: kv [15403,15405]
name: kv [15415,15417]
===
match
---
tfpdef [6151,6177]
tfpdef [6151,6177]
===
match
---
simple_stmt [8938,8969]
simple_stmt [8938,8969]
===
match
---
name: _auth_approle [9284,9297]
name: _auth_approle [9284,9297]
===
match
---
name: self [12221,12225]
name: self [12221,12225]
===
match
---
name: dict [18378,18382]
name: dict [18390,18394]
===
match
---
comparison [6860,6881]
comparison [6860,6881]
===
match
---
dotted_name [1036,1067]
dotted_name [1036,1067]
===
match
---
atom_expr [16045,16059]
atom_expr [16057,16071]
===
match
---
operator: , [11974,11975]
operator: , [11974,11975]
===
match
---
arglist [16830,16902]
arglist [16842,16914]
===
match
---
operator: } [6625,6626]
operator: } [6625,6626]
===
match
---
param [12861,12866]
param [12861,12866]
===
match
---
trailer [14008,14021]
trailer [14013,14021]
===
match
---
operator: = [20397,20398]
operator: = [20409,20410]
===
match
---
if_stmt [12637,12840]
if_stmt [12637,12840]
===
match
---
suite [899,948]
suite [899,948]
===
match
---
atom_expr [8727,8742]
atom_expr [8727,8742]
===
match
---
name: v2 [17916,17918]
name: v2 [17928,17930]
===
match
---
name: self [13437,13441]
name: self [13437,13441]
===
match
---
name: log [15753,15756]
name: log [15765,15768]
===
match
---
simple_stmt [13804,13895]
simple_stmt [13804,13895]
===
match
---
name: self [19899,19903]
name: self [19911,19915]
===
match
---
name: debug [18090,18095]
name: debug [18102,18107]
===
match
---
operator: = [11054,11055]
operator: = [11054,11055]
===
match
---
operator: , [5315,5316]
operator: , [5315,5316]
===
match
---
trailer [9206,9210]
trailer [9206,9210]
===
match
---
name: auth_mount_point [12645,12661]
name: auth_mount_point [12645,12661]
===
match
---
atom_expr [6553,6685]
atom_expr [6553,6685]
===
match
---
name: _client [11759,11766]
name: _client [11759,11766]
===
match
---
name: username [10557,10565]
name: username [10557,10565]
===
match
---
operator: = [13136,13137]
operator: = [13136,13137]
===
match
---
name: kv_engine_version [17744,17761]
name: kv_engine_version [17756,17773]
===
match
---
fstring_start: f" [6432,6434]
fstring_start: f" [6432,6434]
===
match
---
trailer [12682,12687]
trailer [12682,12687]
===
match
---
operator: , [10860,10861]
operator: , [10860,10861]
===
match
---
param [5362,5402]
param [5362,5402]
===
match
---
operator: = [14098,14099]
operator: = [14104,14105]
===
match
---
operator: , [13366,13367]
operator: , [13366,13367]
===
match
---
simple_stmt [1000,1030]
simple_stmt [1000,1030]
===
match
---
operator: == [15211,15213]
operator: == [15223,15225]
===
match
---
atom_expr [11055,11071]
atom_expr [11055,11071]
===
match
---
expr_stmt [8727,8755]
expr_stmt [8727,8755]
===
match
---
name: auth_type [7161,7170]
name: auth_type [7161,7170]
===
match
---
atom_expr [14514,14527]
atom_expr [14526,14539]
===
match
---
name: str [5304,5307]
name: str [5304,5307]
===
match
---
trailer [8641,8654]
trailer [8641,8654]
===
match
---
operator: , [12225,12226]
operator: , [12225,12226]
===
match
---
comparison [16496,16523]
comparison [16508,16535]
===
match
---
atom_expr [10535,10604]
atom_expr [10535,10604]
===
match
---
name: configure [12692,12701]
name: configure [12692,12701]
===
match
---
name: key_id [13399,13405]
name: key_id [13399,13405]
===
match
---
trailer [11243,11252]
trailer [11243,11252]
===
match
---
name: kv_engine_version [20030,20047]
name: kv_engine_version [20042,20059]
===
match
---
operator: = [5863,5864]
operator: = [5863,5864]
===
match
---
annassign [1222,1242]
annassign [1222,1242]
===
match
---
trailer [12240,12247]
trailer [12240,12247]
===
match
---
atom_expr [14539,14553]
atom_expr [14551,14565]
===
match
---
atom_expr [10953,11085]
atom_expr [10953,11085]
===
match
---
trailer [5221,5226]
trailer [5221,5226]
===
match
---
simple_stmt [9176,9227]
simple_stmt [9176,9227]
===
match
---
tfpdef [5243,5257]
tfpdef [5243,5257]
===
match
---
operator: , [5678,5679]
operator: , [5678,5679]
===
match
---
operator: , [12567,12568]
operator: , [12567,12568]
===
match
---
string: "kubernetes" [7174,7186]
string: "kubernetes" [7174,7186]
===
match
---
name: self [16650,16654]
name: self [16662,16666]
===
match
---
operator: , [14254,14255]
operator: , [14266,14267]
===
match
---
trailer [7698,7760]
trailer [7698,7760]
===
match
---
if_stmt [19896,20014]
if_stmt [19908,20026]
===
match
---
expr_stmt [8469,8495]
expr_stmt [8469,8495]
===
match
---
trailer [10972,10982]
trailer [10972,10982]
===
match
---
param [5649,5679]
param [5649,5679]
===
match
---
name: self [8158,8162]
name: self [8158,8162]
===
match
---
operator: = [16743,16744]
operator: = [16755,16756]
===
match
---
arglist [12079,12130]
arglist [12079,12130]
===
match
---
name: kv_engine_version [8102,8119]
name: kv_engine_version [8102,8119]
===
match
---
operator: , [16998,16999]
operator: , [17010,17011]
===
match
---
import_from [1000,1029]
import_from [1000,1029]
===
match
---
argument [11230,11252]
argument [11230,11252]
===
match
---
trailer [11702,11704]
trailer [11702,11704]
===
match
---
operator: , [20369,20370]
operator: , [20381,20382]
===
match
---
simple_stmt [8895,8930]
simple_stmt [8895,8930]
===
match
---
name: kv [20299,20301]
name: kv [20311,20313]
===
match
---
expr_stmt [8856,8886]
expr_stmt [8856,8886]
===
match
---
name: Client [11126,11132]
name: Client [11126,11132]
===
match
---
trailer [15756,15762]
trailer [15768,15774]
===
match
---
trailer [13745,13762]
trailer [13745,13762]
===
match
---
name: username [11376,11384]
name: username [11376,11384]
===
match
---
argument [20184,20212]
argument [20196,20224]
===
match
---
atom_expr [7246,7323]
atom_expr [7246,7323]
===
match
---
atom_expr [8535,8555]
atom_expr [8535,8555]
===
match
---
name: response [15541,15549]
name: response [15553,15561]
===
match
---
name: log [1050,1053]
name: log [1050,1053]
===
match
---
operator: -> [14278,14280]
operator: -> [14290,14292]
===
match
---
name: read [14394,14398]
name: read [14406,14410]
===
match
---
name: login [12178,12183]
name: login [12178,12183]
===
match
---
trailer [13937,13944]
trailer [13937,13944]
===
match
---
name: kwargs [8207,8213]
name: kwargs [8207,8213]
===
match
---
operator: { [6615,6616]
operator: { [6615,6616]
===
match
---
not_test [7203,7222]
not_test [7203,7222]
===
match
---
trailer [14181,14229]
trailer [14193,14241]
===
match
---
if_stmt [12906,13467]
if_stmt [12906,13467]
===
match
---
trailer [8162,8172]
trailer [8162,8172]
===
match
---
atom_expr [12443,12471]
atom_expr [12443,12471]
===
match
---
trailer [10807,10821]
trailer [10807,10821]
===
match
---
name: hvac [9015,9019]
name: hvac [9015,9019]
===
match
---
name: self [13300,13304]
name: self [13300,13304]
===
match
---
atom_expr [11646,11670]
atom_expr [11646,11670]
===
match
---
atom_expr [15819,15835]
atom_expr [15831,15847]
===
match
---
simple_stmt [12158,12202]
simple_stmt [12158,12202]
===
match
---
trailer [15597,15707]
trailer [15609,15719]
===
match
---
tfpdef [10633,10653]
tfpdef [10633,10653]
===
match
---
simple_stmt [9279,9307]
simple_stmt [9279,9307]
===
match
---
name: auth [10961,10965]
name: auth [10961,10965]
===
match
---
trailer [8253,8264]
trailer [8253,8264]
===
match
---
name: _client [12158,12165]
name: _client [12158,12165]
===
match
---
atom_expr [6076,6089]
atom_expr [6076,6089]
===
match
---
atom_expr [7688,7760]
atom_expr [7688,7760]
===
match
---
name: _client [14256,14263]
name: _client [14268,14275]
===
match
---
name: create_or_update_secret [20305,20328]
name: create_or_update_secret [20317,20340]
===
match
---
trailer [9197,9226]
trailer [9197,9226]
===
match
---
trailer [5764,5769]
trailer [5764,5769]
===
match
---
simple_stmt [19819,19888]
simple_stmt [19831,19900]
===
match
---
name: self [13394,13398]
name: self [13394,13398]
===
match
---
fstring_expr [6652,6670]
fstring_expr [6652,6670]
===
match
---
name: response [20066,20074]
name: response [20078,20086]
===
match
---
name: kv [15572,15574]
name: kv [15584,15586]
===
match
---
name: logging_mixin [1054,1067]
name: logging_mixin [1054,1067]
===
match
---
name: self [9279,9283]
name: self [9279,9283]
===
match
---
name: VaultError [6934,6944]
name: VaultError [6934,6944]
===
match
---
name: auth [12796,12800]
name: auth [12796,12800]
===
match
---
name: azure_resource [6017,6031]
name: azure_resource [6017,6031]
===
match
---
atom_expr [17786,17860]
atom_expr [17798,17872]
===
match
---
operator: , [18350,18351]
operator: , [18362,18363]
===
match
---
name: str [5469,5472]
name: str [5469,5472]
===
match
---
operator: } [6411,6412]
operator: } [6411,6412]
===
match
---
parameters [16017,16041]
parameters [16029,16053]
===
match
---
trailer [15394,15402]
trailer [15406,15414]
===
match
---
trailer [10450,10459]
trailer [10450,10459]
===
match
---
suite [15172,15708]
suite [15184,15720]
===
match
---
atom_expr [10890,10911]
atom_expr [10890,10911]
===
match
---
trailer [15571,15574]
trailer [15583,15586]
===
match
---
trailer [13351,13366]
trailer [13351,13366]
===
match
---
name: Optional [5418,5426]
name: Optional [5418,5426]
===
match
---
trailer [10381,10395]
trailer [10381,10395]
===
match
---
atom_expr [11154,11175]
atom_expr [11154,11175]
===
match
---
name: self [11385,11389]
name: self [11385,11389]
===
match
---
trailer [16696,16774]
trailer [16708,16786]
===
match
---
name: self [14443,14447]
name: self [14455,14459]
===
match
---
name: self [12455,12459]
name: self [12455,12459]
===
match
---
operator: = [13046,13047]
operator: = [13046,13047]
===
match
---
suite [9581,9621]
suite [9581,9621]
===
match
---
simple_stmt [6928,7014]
simple_stmt [6928,7014]
===
match
---
trailer [11989,11996]
trailer [11989,11996]
===
match
---
argument [12990,13020]
argument [12990,13020]
===
match
---
operator: , [16022,16023]
operator: , [16034,16035]
===
match
---
trailer [9019,9026]
trailer [9019,9026]
===
match
---
arglist [18113,18265]
arglist [18125,18277]
===
match
---
parameters [5146,6209]
parameters [5146,6209]
===
match
---
trailer [6224,6226]
trailer [6224,6226]
===
match
---
argument [13729,13762]
argument [13729,13762]
===
match
---
trailer [9445,9457]
trailer [9445,9457]
===
match
---
if_stmt [6246,6489]
if_stmt [6246,6489]
===
match
---
operator: == [17762,17764]
operator: == [17774,17776]
===
match
---
suite [13560,13778]
suite [13560,13778]
===
match
---
string: "ldap" [9740,9746]
string: "ldap" [9740,9746]
===
match
---
operator: = [20175,20176]
operator: = [20187,20188]
===
match
---
name: hvac [13933,13937]
name: hvac [13933,13937]
===
match
---
name: _client [12867,12874]
name: _client [12867,12874]
===
match
---
fstring_string: .  [6626,6628]
fstring_string: .  [6626,6628]
===
match
---
trailer [13398,13405]
trailer [13398,13405]
===
match
---
operator: = [11004,11005]
operator: = [11004,11005]
===
match
---
name: self [11290,11294]
name: self [11290,11294]
===
match
---
tfpdef [14256,14276]
tfpdef [14268,14288]
===
match
---
name: secret_path [16719,16730]
name: secret_path [16731,16742]
===
match
---
argument [13338,13366]
argument [13338,13366]
===
match
---
tfpdef [5835,5862]
tfpdef [5835,5862]
===
match
---
name: _client [9776,9783]
name: _client [9776,9783]
===
match
---
operator: , [13874,13875]
operator: , [13874,13875]
===
match
---
trailer [20301,20304]
trailer [20313,20316]
===
match
---
param [11112,11132]
param [11112,11132]
===
match
---
atom_expr [11189,11325]
atom_expr [11189,11325]
===
match
---
name: mount_point [16749,16760]
name: mount_point [16761,16772]
===
match
---
operator: == [9737,9739]
operator: == [9737,9739]
===
match
---
name: VaultError [7688,7698]
name: VaultError [7688,7698]
===
match
---
atom_expr [8222,8232]
atom_expr [8222,8232]
===
match
---
operator: = [5912,5913]
operator: = [5912,5913]
===
match
---
operator: = [6047,6048]
operator: = [6047,6048]
===
match
---
trailer [9379,9388]
trailer [9379,9388]
===
match
---
arglist [13290,13452]
arglist [13290,13452]
===
match
---
trailer [13185,13202]
trailer [13185,13202]
===
match
---
suite [9504,9541]
suite [9504,9541]
===
match
---
operator: == [9893,9895]
operator: == [9893,9895]
===
match
---
suite [6314,6489]
suite [6314,6489]
===
match
---
string: "The 'github' authentication type requires 'token' or 'token_path'" [6945,7012]
string: "The 'github' authentication type requires 'token' or 'token_path'" [6945,7012]
===
match
---
simple_stmt [8678,8719]
simple_stmt [8678,8719]
===
match
---
trailer [11650,11670]
trailer [11650,11670]
===
match
---
number: 1 [15930,15931]
number: 1 [15942,15943]
===
match
---
param [5243,5268]
param [5243,5268]
===
match
---
atom_expr [13881,13893]
atom_expr [13881,13893]
===
match
---
trailer [14447,14453]
trailer [14459,14465]
===
match
---
trailer [12170,12177]
trailer [12170,12177]
===
match
---
param [9006,9010]
param [9006,9010]
===
match
---
name: secret [10796,10802]
name: secret [10796,10802]
===
match
---
trailer [7256,7323]
trailer [7256,7323]
===
match
---
atom_expr [13622,13633]
atom_expr [13622,13633]
===
match
---
atom_expr [7083,7149]
atom_expr [7083,7149]
===
match
---
name: VaultError [7975,7985]
name: VaultError [7975,7985]
===
match
---
name: self [8286,8290]
name: self [8286,8290]
===
match
---
trailer [14103,14120]
trailer [14109,14126]
===
match
---
trailer [1265,1270]
trailer [1265,1270]
===
match
---
name: _auth_azure [12849,12860]
name: _auth_azure [12849,12860]
===
match
---
tfpdef [12867,12887]
tfpdef [12867,12887]
===
match
---
operator: = [8265,8266]
operator: = [8265,8266]
===
match
---
suite [9825,9865]
suite [9825,9865]
===
match
---
raise_stmt [7380,7467]
raise_stmt [7380,7467]
===
match
---
atom_expr [13437,13451]
atom_expr [13437,13451]
===
match
---
operator: = [10421,10422]
operator: = [10421,10422]
===
match
---
if_stmt [16493,16618]
if_stmt [16505,16630]
===
match
---
name: Optional [5578,5586]
name: Optional [5578,5586]
===
match
---
name: radius_port [6151,6162]
name: radius_port [6151,6162]
===
match
---
tfpdef [6017,6046]
tfpdef [6017,6046]
===
match
---
name: _client [13804,13811]
name: _client [13804,13811]
===
match
---
trailer [5468,5473]
trailer [5468,5473]
===
match
---
suite [15216,15507]
suite [15228,15519]
===
match
---
trailer [15945,15953]
trailer [15957,15965]
===
match
---
name: self [9594,9598]
name: self [9594,9598]
===
match
---
trailer [12078,12131]
trailer [12078,12131]
===
match
---
name: self [10762,10766]
name: self [10762,10766]
===
match
---
atom [1236,1242]
atom [1236,1242]
===
match
---
comp_op [6289,6295]
comp_op [6289,6295]
===
match
---
string: 'token' [1391,1398]
string: 'token' [1391,1398]
===
match
---
name: self [8135,8139]
name: self [8135,8139]
===
match
---
atom_expr [10422,10435]
atom_expr [10422,10435]
===
match
---
trailer [12804,12814]
trailer [12804,12814]
===
match
---
operator: = [8873,8874]
operator: = [8873,8874]
===
match
---
name: self [9997,10001]
name: self [9997,10001]
===
match
---
trailer [18400,18405]
trailer [18412,18417]
===
match
---
operator: , [11110,11111]
operator: , [11110,11111]
===
match
---
name: mount_point [10878,10889]
name: mount_point [10878,10889]
===
match
---
operator: = [5672,5673]
operator: = [5672,5673]
===
match
---
name: self [5194,5198]
name: self [5194,5198]
===
match
---
not_test [7516,7534]
not_test [7516,7534]
===
match
---
string: 'ldap' [1365,1371]
string: 'ldap' [1365,1371]
===
match
---
trailer [17897,17904]
trailer [17909,17916]
===
match
---
name: role_id [14195,14202]
name: role_id [14207,14214]
===
match
---
tfpdef [6106,6134]
tfpdef [6106,6134]
===
match
---
name: cas [18414,18417]
name: cas [18426,18429]
===
match
---
name: mount_point [8354,8365]
name: mount_point [8354,8365]
===
match
---
atom_expr [14332,14353]
atom_expr [14344,14365]
===
match
---
name: self [13918,13922]
name: self [13918,13922]
===
match
---
name: auth_mount_point [14104,14120]
name: auth_mount_point [14110,14126]
===
match
---
name: kv_engine_version [6271,6288]
name: kv_engine_version [6271,6288]
===
match
---
name: kv_engine_version [8081,8098]
name: kv_engine_version [8081,8098]
===
match
---
name: self [11106,11110]
name: self [11106,11110]
===
match
---
operator: , [12865,12866]
operator: , [12865,12866]
===
match
---
trailer [13509,13516]
trailer [13509,13516]
===
match
---
atom_expr [13094,13105]
atom_expr [13094,13105]
===
match
---
atom_expr [12497,12628]
atom_expr [12497,12628]
===
match
---
name: role_id [14052,14059]
name: role_id [14058,14065]
===
match
---
atom_expr [9917,9941]
atom_expr [9917,9941]
===
match
---
operator: , [1288,1289]
operator: , [1288,1289]
===
match
---
name: get_secret_including_metadata [16937,16966]
name: get_secret_including_metadata [16949,16978]
===
match
---
return_stmt [17886,18040]
return_stmt [17898,18052]
===
match
---
parameters [13917,13945]
parameters [13917,13945]
===
match
---
name: dict [16054,16058]
name: dict [16066,16070]
===
match
---
name: role_id [8509,8516]
name: role_id [8509,8516]
===
match
---
and_test [6249,6313]
and_test [6249,6313]
===
match
---
name: gcp_keyfile_dict [8683,8699]
name: gcp_keyfile_dict [8683,8699]
===
match
---
arglist [12702,12760]
arglist [12702,12760]
===
match
---
atom_expr [11641,11671]
atom_expr [11641,11671]
===
match
---
operator: = [17985,17986]
operator: = [17997,17998]
===
match
---
name: mount_point [20184,20195]
name: mount_point [20196,20207]
===
match
---
name: auth_aws_iam [13812,13824]
name: auth_aws_iam [13812,13824]
===
match
---
name: self [11917,11921]
name: self [11917,11921]
===
match
---
suite [14148,14230]
suite [14154,14242]
===
match
---
trailer [5995,6000]
trailer [5995,6000]
===
match
---
atom_expr [5897,5911]
atom_expr [5897,5911]
===
match
---
name: configure [13263,13272]
name: configure [13263,13272]
===
match
---
suite [17767,17861]
suite [17779,17873]
===
match
---
trailer [11059,11071]
trailer [11059,11071]
===
match
---
name: _get_scopes [12358,12369]
name: _get_scopes [12358,12369]
===
match
---
not_test [7934,7951]
not_test [7934,7951]
===
match
---
name: _auth_ldap [9765,9775]
name: _auth_ldap [9765,9775]
===
match
---
simple_stmt [9594,9621]
simple_stmt [9594,9621]
===
match
---
name: github [12066,12072]
name: github [12066,12072]
===
match
---
atom_expr [10566,10579]
atom_expr [10566,10579]
===
match
---
name: self [13137,13141]
name: self [13137,13141]
===
match
---
name: _client [9532,9539]
name: _client [9532,9539]
===
match
---
argument [13849,13874]
argument [13849,13874]
===
match
---
suite [17061,18304]
suite [17073,18316]
===
match
---
argument [10413,10435]
argument [10413,10435]
===
match
---
raise_stmt [6928,7013]
raise_stmt [6928,7013]
===
match
---
raise_stmt [7240,7323]
raise_stmt [7240,7323]
===
match
---
trailer [11645,11671]
trailer [11645,11671]
===
match
---
trailer [17796,17860]
trailer [17808,17872]
===
match
---
name: self [10627,10631]
name: self [10627,10631]
===
match
---
parameters [10626,10654]
parameters [10626,10654]
===
match
---
and_test [6697,6750]
and_test [6697,6750]
===
match
---
name: response [20268,20276]
name: response [20280,20288]
===
match
---
tfpdef [5325,5341]
tfpdef [5325,5341]
===
match
---
atom_expr [11788,11808]
atom_expr [11788,11808]
===
match
---
param [5530,5561]
param [5530,5561]
===
match
---
atom_expr [16886,16902]
atom_expr [16898,16914]
===
match
---
name: ImportError [887,898]
name: ImportError [887,898]
===
match
---
param [5570,5599]
param [5570,5599]
===
match
---
trailer [14075,14085]
trailer [14081,14091]
===
match
---
name: jwt [11690,11693]
name: jwt [11690,11693]
===
match
---
operator: = [18433,18434]
operator: = [18445,18446]
===
match
---
suite [7064,7150]
suite [7064,7150]
===
match
---
name: credentials_provider [12308,12328]
name: credentials_provider [12308,12328]
===
match
---
suite [10361,10509]
suite [10361,10509]
===
match
---
atom_expr [16815,16903]
atom_expr [16827,16915]
===
match
---
name: radius_host [10767,10778]
name: radius_host [10767,10778]
===
match
---
operator: } [6472,6473]
operator: } [6472,6473]
===
match
---
string: "Metadata might only be used with version 2 of the KV engine." [16554,16616]
string: "Metadata might only be used with version 2 of the KV engine." [16566,16628]
===
match
---
name: hvac [12236,12240]
name: hvac [12236,12240]
===
match
---
argument [14182,14202]
argument [14194,14214]
===
match
---
name: auth_mount_point [10344,10360]
name: auth_mount_point [10344,10360]
===
match
---
argument [11912,11937]
argument [11912,11937]
===
match
---
name: radius_host [7814,7825]
name: radius_host [7814,7825]
===
match
---
name: username [10571,10579]
name: username [10571,10579]
===
match
---
operator: = [17960,17961]
operator: = [17972,17973]
===
match
---
atom_expr [15278,15355]
atom_expr [15290,15367]
===
match
---
atom [1273,1417]
atom [1273,1417]
===
match
---
trailer [8539,8555]
trailer [8539,8555]
===
match
---
atom_expr [9997,10025]
atom_expr [9997,10025]
===
match
---
name: mount_point [12727,12738]
name: mount_point [12727,12738]
===
match
---
name: auth_type [6500,6509]
name: auth_type [6500,6509]
===
match
---
argument [12541,12567]
argument [12541,12567]
===
match
---
name: azure [13257,13262]
name: azure [13257,13262]
===
match
---
name: radius_host [6063,6074]
name: radius_host [6063,6074]
===
match
---
name: is_authenticated [10146,10162]
name: is_authenticated [10146,10162]
===
match
---
param [14256,14276]
param [14268,14288]
===
match
---
operator: = [8388,8389]
operator: = [8388,8389]
===
match
---
operator: = [13299,13300]
operator: = [13299,13300]
===
match
---
tfpdef [18384,18405]
tfpdef [18396,18417]
===
match
---
trailer [15405,15408]
trailer [15417,15420]
===
match
---
operator: , [5560,5561]
operator: , [5560,5561]
===
match
---
atom_expr [8158,8172]
atom_expr [8158,8172]
===
match
---
name: role_id [13704,13711]
name: role_id [13704,13711]
===
match
---
raise_stmt [6327,6488]
raise_stmt [6327,6488]
===
match
---
atom_expr [11502,11526]
atom_expr [11502,11526]
===
match
---
funcdef [11091,11424]
funcdef [11091,11424]
===
match
---
atom_expr [12675,12761]
atom_expr [12675,12761]
===
match
---
name: response [20453,20461]
name: response [20465,20473]
===
match
---
name: self [14190,14194]
name: self [14202,14206]
===
match
---
operator: = [6135,6136]
operator: = [6135,6136]
===
match
---
name: self [11239,11243]
name: self [11239,11243]
===
match
---
parameters [16966,17042]
parameters [16978,17054]
===
match
---
name: str [5714,5717]
name: str [5714,5717]
===
match
---
name: access_key [13825,13835]
name: access_key [13825,13835]
===
match
---
trailer [11375,11423]
trailer [11375,11423]
===
match
---
argument [12184,12200]
argument [12184,12200]
===
match
---
name: Client [11470,11476]
name: Client [11470,11476]
===
match
---
string: "The 'approle' authentication type requires 'role_id'" [7094,7148]
string: "The 'approle' authentication type requires 'role_id'" [7094,7148]
===
match
---
and_test [6860,6914]
and_test [6860,6914]
===
match
---
atom_expr [8374,8387]
atom_expr [8374,8387]
===
match
---
atom_expr [9878,9892]
atom_expr [9878,9892]
===
match
---
trailer [17054,17060]
trailer [17066,17072]
===
match
---
param [10627,10632]
param [10627,10632]
===
match
---
name: auth_approle [14169,14181]
name: approle [14180,14187]
===
match
---
name: _auth_github [11957,11969]
name: _auth_github [11957,11969]
===
match
---
file_input [785,20462]
file_input [785,20474]
===
match
---
operator: = [5474,5475]
operator: = [5474,5475]
===
match
---
atom_expr [16543,16617]
atom_expr [16555,16629]
===
match
---
trailer [12913,12930]
trailer [12913,12930]
===
match
---
name: Optional [5658,5666]
name: Optional [5658,5666]
===
match
---
name: password [11400,11408]
name: password [11400,11408]
===
match
---
atom_expr [12018,12039]
atom_expr [12018,12039]
===
match
---
trailer [12880,12887]
trailer [12880,12887]
===
match
---
atom_expr [15552,15707]
atom_expr [15564,15719]
===
match
---
operator: , [18232,18233]
operator: , [18244,18245]
===
match
---
expr_stmt [8811,8847]
expr_stmt [8811,8847]
===
match
---
name: self [9441,9445]
name: self [9441,9445]
===
match
---
name: auth_type [9883,9892]
name: auth_type [9883,9892]
===
match
---
name: password [8423,8431]
name: password [8423,8431]
===
match
---
operator: , [16871,16872]
operator: , [16883,16884]
===
match
---
operator: , [14496,14497]
operator: , [14508,14509]
===
match
---
string: 'azure' [9420,9427]
string: 'azure' [9420,9427]
===
match
---
trailer [10646,10653]
trailer [10646,10653]
===
match
---
suite [9904,9942]
suite [9904,9942]
===
match
---
name: tenant_id [13290,13299]
name: tenant_id [13290,13299]
===
match
---
suite [14314,14401]
suite [14326,14413]
===
match
---
name: self [12640,12644]
name: self [12640,12644]
===
match
---
name: token [6726,6731]
name: token [6726,6731]
===
match
---
atom_expr [8056,8078]
atom_expr [8056,8078]
===
match
---
trailer [10001,10016]
trailer [10001,10016]
===
match
---
name: str [5338,5341]
name: str [5338,5341]
===
match
---
name: self [9402,9406]
name: self [9402,9406]
===
match
---
argument [20214,20227]
argument [20226,20239]
===
match
---
name: _client [11456,11463]
name: _client [11456,11463]
===
match
---
name: credentials [12480,12491]
name: credentials [12480,12491]
===
match
---
operator: , [5825,5826]
operator: , [5825,5826]
===
match
---
name: self [13966,13970]
name: self [13966,13970]
===
match
---
name: VALID_AUTH_TYPES [6653,6669]
name: VALID_AUTH_TYPES [6653,6669]
===
match
---
comparison [9798,9824]
comparison [9798,9824]
===
match
---
name: self [13181,13185]
name: self [13181,13185]
===
match
---
name: Response [1021,1029]
name: Response [1021,1029]
===
match
---
name: hvac [11465,11469]
name: hvac [11465,11469]
===
match
---
name: self [8535,8539]
name: self [8535,8539]
===
match
---
raise_stmt [15272,15355]
raise_stmt [15284,15367]
===
match
---
arglist [11912,11946]
arglist [11912,11946]
===
match
---
suite [11176,11326]
suite [11176,11326]
===
match
---
suite [12897,13467]
suite [12897,13467]
===
match
---
name: auth_type [9559,9568]
name: auth_type [9559,9568]
===
match
---
name: self [14250,14254]
name: self [14262,14266]
===
match
---
name: Optional [14539,14547]
name: Optional [14551,14559]
===
match
---
trailer [8682,8699]
trailer [8682,8699]
===
match
---
trailer [20328,20437]
trailer [20340,20449]
===
match
---
atom_expr [13181,13202]
atom_expr [13181,13202]
===
match
---
name: _client [9380,9387]
name: _client [9380,9387]
===
match
---
operator: , [6053,6054]
operator: , [6053,6054]
===
match
---
operator: = [5309,5310]
operator: = [5309,5310]
===
match
---
if_stmt [6694,6849]
if_stmt [6694,6849]
===
match
---
tfpdef [5608,5632]
tfpdef [5608,5632]
===
match
---
name: self [9955,9959]
name: self [9955,9959]
===
match
---
fstring_start: f" [10069,10071]
fstring_start: f" [10069,10071]
===
match
---
name: _auth_approle [13904,13917]
name: _auth_approle [13904,13917]
===
match
---
arglist [11376,11422]
arglist [11376,11422]
===
match
---
trailer [12951,12956]
trailer [12951,12956]
===
match
---
name: hvac [953,957]
name: hvac [953,957]
===
match
---
name: secret_path [15447,15458]
name: secret_path [15459,15470]
===
match
---
atom_expr [20077,20241]
atom_expr [20089,20253]
===
match
---
operator: , [10911,10912]
operator: , [10911,10912]
===
match
---
comparison [19767,19794]
comparison [19779,19806]
===
match
---
trailer [9842,9855]
trailer [9842,9855]
===
match
---
name: secret_version [15236,15250]
name: secret_version [15248,15262]
===
match
---
name: Client [13938,13944]
name: Client [13938,13944]
===
match
---
simple_stmt [6764,6849]
simple_stmt [6764,6849]
===
match
---
with_stmt [14327,14401]
with_stmt [14339,14413]
===
match
---
operator: = [8914,8915]
operator: = [8914,8915]
===
match
---
atom_expr [5381,5394]
atom_expr [5381,5394]
===
match
---
operator: = [13835,13836]
operator: = [13835,13836]
===
match
---
atom_expr [8764,8784]
atom_expr [8764,8784]
===
match
---
name: self [8811,8815]
name: self [8811,8815]
===
match
---
trailer [9297,9306]
trailer [9297,9306]
===
match
---
name: auth_mount_point [11836,11852]
name: auth_mount_point [11836,11852]
===
match
---
name: self [14337,14341]
name: self [14349,14353]
===
match
---
atom_expr [9441,9466]
atom_expr [9441,9466]
===
match
---
string: "The 'token' authentication type requires 'token' or 'token_path'" [6781,6847]
string: "The 'token' authentication type requires 'token' or 'token_path'" [6781,6847]
===
match
---
parameters [12220,12248]
parameters [12220,12248]
===
match
---
name: auth_type [9243,9252]
name: auth_type [9243,9252]
===
match
---
operator: , [20167,20168]
operator: , [20179,20180]
===
match
---
name: open [11641,11645]
name: open [11641,11645]
===
match
---
atom_expr [17016,17029]
atom_expr [17028,17041]
===
match
---
trailer [12701,12761]
trailer [12701,12761]
===
match
---
trailer [13051,13066]
trailer [13051,13066]
===
match
---
operator: = [20075,20076]
operator: = [20087,20088]
===
match
---
name: self [12085,12089]
name: self [12085,12089]
===
match
---
name: dict [14548,14552]
name: dict [14560,14564]
===
match
---
raise_stmt [19948,20013]
raise_stmt [19960,20025]
===
match
---
trailer [10310,10317]
trailer [10310,10317]
===
match
---
atom_expr [6033,6046]
atom_expr [6033,6046]
===
match
---
fstring [10069,10124]
fstring [10069,10124]
===
match
---
expr_stmt [15870,15961]
expr_stmt [15882,15973]
===
match
---
operator: = [15882,15883]
operator: = [15894,15895]
===
match
---
expr_stmt [8193,8213]
expr_stmt [8193,8213]
===
match
---
name: _auth_kubernetes [11433,11449]
name: _auth_kubernetes [11433,11449]
===
match
---
operator: , [18198,18199]
operator: , [18210,18211]
===
match
---
name: access_key [13611,13621]
name: access_key [13611,13621]
===
match
---
trailer [9682,9699]
trailer [9682,9699]
===
match
---
name: radius_port [10849,10860]
name: radius_port [10849,10860]
===
match
---
tfpdef [11456,11476]
tfpdef [11456,11476]
===
match
---
operator: = [6178,6179]
operator: = [6178,6179]
===
match
---
trailer [9802,9812]
trailer [9802,9812]
===
match
---
trailer [11201,11206]
trailer [11201,11206]
===
match
---
suite [16630,16775]
suite [16642,16787]
===
match
---
trailer [11469,11476]
trailer [11469,11476]
===
match
---
argument [11783,11808]
argument [11783,11808]
===
match
---
trailer [16672,16675]
trailer [16684,16687]
===
match
---
operator: , [20182,20183]
operator: , [20194,20195]
===
match
---
name: gcp_scopes [5928,5938]
name: gcp_scopes [5928,5938]
===
match
---
trailer [9484,9494]
trailer [9484,9494]
===
match
---
name: mount_point [11819,11830]
name: mount_point [11819,11830]
===
match
---
raise_stmt [7552,7629]
raise_stmt [7552,7629]
===
match
---
string: "The method parameter is only valid for version 1" [19836,19886]
string: "The method parameter is only valid for version 1" [19848,19898]
===
match
---
string: 'radius' [1377,1385]
string: 'radius' [1377,1385]
===
match
---
simple_stmt [1089,1173]
simple_stmt [1089,1173]
===
match
---
trailer [12454,12471]
trailer [12454,12471]
===
match
---
trailer [1228,1233]
trailer [1228,1233]
===
match
---
if_stmt [17736,17861]
if_stmt [17748,17873]
===
match
---
trailer [14051,14059]
trailer [14057,14065]
===
match
---
trailer [16675,16696]
trailer [16687,16708]
===
match
---
trailer [13703,13711]
trailer [13703,13711]
===
match
---
atom_expr [16744,16760]
atom_expr [16756,16772]
===
match
---
name: Optional [17046,17054]
name: Optional [17058,17066]
===
match
---
import_name [820,831]
import_name [820,831]
===
match
---
operator: = [13698,13699]
operator: = [13698,13699]
===
match
---
name: self [8469,8473]
name: self [8469,8473]
===
match
---
operator: = [13859,13860]
operator: = [13859,13860]
===
match
---
name: secret_version [18012,18026]
name: secret_version [18024,18038]
===
match
---
name: cached_property [864,879]
name: cached_property [864,879]
===
match
---
operator: = [8452,8453]
operator: = [8452,8453]
===
match
---
fstring_string: The version is not supported:  [6363,6393]
fstring_string: The version is not supported:  [6363,6393]
===
match
---
name: Optional [5213,5221]
name: Optional [5213,5221]
===
match
---
expr_stmt [8286,8326]
expr_stmt [8286,8326]
===
match
---
argument [13825,13847]
argument [13825,13847]
===
match
---
name: _client [10297,10304]
name: _client [10297,10304]
===
match
---
atom_expr [12158,12201]
atom_expr [12158,12201]
===
match
---
operator: = [5514,5515]
operator: = [5514,5515]
===
match
---
name: gcp_scopes [8732,8742]
name: gcp_scopes [8732,8742]
===
match
---
atom_expr [17046,17060]
atom_expr [17058,17072]
===
match
---
atom_expr [11005,11021]
atom_expr [11005,11021]
===
match
---
atom_expr [12455,12470]
atom_expr [12455,12470]
===
match
---
arglist [15442,15488]
arglist [15454,15500]
===
match
---
atom_expr [15649,15665]
atom_expr [15661,15677]
===
match
---
operator: == [9970,9972]
operator: == [9970,9972]
===
match
---
trailer [10982,11085]
trailer [10982,11085]
===
match
---
string: "The 'radius' authentication type requires 'radius_secret'" [7986,8045]
string: "The 'radius' authentication type requires 'radius_secret'" [7986,8045]
===
match
---
string: 'aws_iam' [1294,1303]
string: 'aws_iam' [1294,1303]
===
match
---
name: hvac [11985,11989]
name: hvac [11985,11989]
===
match
---
argument [15637,15665]
argument [15649,15677]
===
match
---
fstring [6361,6415]
fstring [6361,6415]
===
match
---
name: self [9634,9638]
name: self [9634,9638]
===
match
---
suite [9984,10026]
suite [9984,10026]
===
match
---
operator: = [13346,13347]
operator: = [13346,13347]
===
match
---
operator: , [12491,12492]
operator: , [12491,12492]
===
match
---
operator: = [10589,10590]
operator: = [10589,10590]
===
match
---
operator: -> [9012,9014]
operator: -> [9012,9014]
===
match
---
name: mount_point [15460,15471]
name: mount_point [15472,15483]
===
match
---
name: VaultError [7849,7859]
name: VaultError [7849,7859]
===
match
---
atom_expr [14265,14276]
atom_expr [14277,14288]
===
match
---
simple_stmt [17070,17728]
simple_stmt [17082,17740]
===
match
---
operator: = [13093,13094]
operator: = [13093,13094]
===
match
---
suite [11142,11424]
suite [11142,11424]
===
match
---
name: credentials [12714,12725]
name: credentials [12714,12725]
===
match
---
simple_stmt [20066,20242]
simple_stmt [20078,20254]
===
match
---
trailer [9324,9334]
trailer [9324,9334]
===
match
---
trailer [11009,11021]
trailer [11009,11021]
===
match
---
atom_expr [10762,10778]
atom_expr [10762,10778]
===
match
---
name: return_data [15977,15988]
name: return_data [15989,16000]
===
match
---
name: self [13622,13626]
name: self [13622,13626]
===
match
---
expr_stmt [1205,1242]
expr_stmt [1205,1242]
===
match
---
name: read_secret_metadata [16676,16696]
name: read_secret_metadata [16688,16708]
===
match
---
trailer [5905,5911]
trailer [5905,5911]
===
match
---
operator: -> [11134,11136]
operator: -> [11134,11136]
===
match
---
atom_expr [14443,14453]
atom_expr [14455,14465]
===
match
---
operator: = [11262,11263]
operator: = [11262,11263]
===
match
---
raise_stmt [10052,10125]
raise_stmt [10052,10125]
===
match
---
simple_stmt [19948,20014]
simple_stmt [19960,20026]
===
match
---
operator: = [17030,17031]
operator: = [17042,17043]
===
match
---
name: self [13538,13542]
name: self [13538,13542]
===
match
---
suite [9747,9785]
suite [9747,9785]
===
match
---
simple_stmt [18081,18280]
simple_stmt [18093,18292]
===
match
---
trailer [9242,9252]
trailer [9242,9252]
===
match
---
operator: = [6090,6091]
operator: = [6090,6091]
===
match
---
name: _client [9176,9183]
name: _client [9176,9183]
===
match
---
name: ldap [11202,11206]
name: ldap [11202,11206]
===
match
---
atom_expr [13394,13405]
atom_expr [13394,13405]
===
match
---
name: role_id [8519,8526]
name: role_id [8519,8526]
===
match
---
name: self [12582,12586]
name: self [12582,12586]
===
match
---
name: token [12090,12095]
name: token [12090,12095]
===
match
---
trailer [19835,19887]
trailer [19847,19899]
===
match
---
operator: , [6184,6185]
operator: , [6184,6185]
===
match
---
atom_expr [14161,14229]
atom_expr [14167,14241]
===
match
---
suite [10039,10126]
suite [10039,10126]
===
match
---
name: secret [18370,18376]
name: secret [18382,18388]
===
match
---
tfpdef [5530,5553]
tfpdef [5530,5553]
===
match
---
suite [7223,7324]
suite [7223,7324]
===
match
---
operator: = [10472,10473]
operator: = [10472,10473]
===
match
---
atom_expr [16650,16774]
atom_expr [16662,16786]
===
match
---
atom_expr [8249,8264]
atom_expr [8249,8264]
===
match
---
name: _client [10535,10542]
name: _client [10535,10542]
===
match
---
name: secret_id [13442,13451]
name: secret_id [13442,13451]
===
match
---
trailer [8290,8307]
trailer [8290,8307]
===
match
---
suite [11677,11948]
suite [11677,11948]
===
match
---
param [16018,16023]
param [16030,16035]
===
match
---
operator: = [1271,1272]
operator: = [1271,1272]
===
match
---
name: mount_point [20201,20212]
name: mount_point [20213,20224]
===
match
---
suite [6915,7014]
suite [6915,7014]
===
match
---
name: token_path [8254,8264]
name: token_path [8254,8264]
===
match
---
operator: = [12611,12612]
operator: = [12611,12612]
===
match
---
operator: , [11398,11399]
operator: , [11398,11399]
===
match
---
operator: = [1199,1200]
operator: = [1199,1200]
===
match
---
name: radius_host [8875,8886]
name: radius_host [8875,8886]
===
match
---
tfpdef [17000,17029]
tfpdef [17012,17041]
===
match
---
trailer [10542,10556]
trailer [10542,10556]
===
match
---
name: version [15667,15674]
name: version [15679,15686]
===
match
---
except_clause [880,898]
except_clause [880,898]
===
match
---
trailer [15420,15506]
trailer [15432,15518]
===
match
---
name: _client [10953,10960]
name: _client [10953,10960]
===
match
---
name: key_id [13099,13105]
name: key_id [13099,13105]
===
match
---
trailer [12644,12661]
trailer [12644,12661]
===
match
---
operator: = [11029,11030]
operator: = [11029,11030]
===
match
---
name: mount_point [13729,13740]
name: mount_point [13729,13740]
===
match
---
operator: -> [13946,13948]
operator: -> [13946,13948]
===
match
---
atom_expr [10306,10317]
atom_expr [10306,10317]
===
match
---
trailer [10426,10435]
trailer [10426,10435]
===
match
---
argument [13384,13405]
argument [13384,13405]
===
match
---
name: host [11000,11004]
name: host [11000,11004]
===
match
---
name: token_path [8267,8277]
name: token_path [8267,8277]
===
match
---
name: kubernetes_role [5688,5703]
name: kubernetes_role [5688,5703]
===
match
---
name: VaultError [7083,7093]
name: VaultError [7083,7093]
===
match
---
name: kv_engine_version [6249,6266]
name: kv_engine_version [6249,6266]
===
match
---
trailer [10594,10603]
trailer [10594,10603]
===
match
---
number: 2 [1240,1241]
number: 2 [1240,1241]
===
match
---
name: credentials [12827,12838]
name: credentials [12827,12838]
===
match
---
argument [13423,13451]
argument [13423,13451]
===
match
---
string: "approle" [7038,7047]
string: "approle" [7038,7047]
===
match
---
name: url [5208,5211]
name: url [5208,5211]
===
match
---
arglist [11783,11852]
arglist [11783,11852]
===
match
---
name: url [8140,8143]
name: url [8140,8143]
===
match
---
simple_stmt [10953,11086]
simple_stmt [10953,11086]
===
match
---
operator: = [11408,11409]
operator: = [11408,11409]
===
match
---
trailer [20200,20212]
trailer [20212,20224]
===
match
---
name: log [16820,16823]
name: log [16832,16835]
===
match
---
operator: -> [17043,17045]
operator: -> [17055,17057]
===
match
---
name: _auth_github [9599,9611]
name: _auth_github [9599,9611]
===
match
---
operator: , [5198,5199]
operator: , [5198,5199]
===
match
---
simple_stmt [8637,8670]
simple_stmt [8637,8670]
===
match
---
name: role [13876,13880]
name: role [13876,13880]
===
match
---
argument [10757,10778]
argument [10757,10778]
===
match
---
name: port [10839,10843]
name: port [10839,10843]
===
match
---
tfpdef [5735,5769]
tfpdef [5735,5769]
===
match
---
trailer [9921,9932]
trailer [9921,9932]
===
match
---
operator: , [5639,5640]
operator: , [5639,5640]
===
match
---
name: radius_secret [8916,8929]
name: radius_secret [8916,8929]
===
match
---
suite [14414,14454]
suite [14426,14466]
===
match
---
trailer [10679,10696]
trailer [10679,10696]
===
match
---
name: Optional [5500,5508]
name: Optional [5500,5508]
===
match
---
simple_stmt [11888,11948]
simple_stmt [11888,11948]
===
match
---
atom_expr [7975,8046]
atom_expr [7975,8046]
===
match
---
argument [20144,20167]
argument [20156,20179]
===
match
---
operator: , [16980,16981]
operator: , [16992,16993]
===
match
---
trailer [6944,7013]
trailer [6944,7013]
===
match
---
name: self [9838,9842]
name: self [9838,9842]
===
match
---
name: url [9207,9210]
name: url [9207,9210]
===
match
---
simple_stmt [9036,9168]
simple_stmt [9036,9168]
===
match
---
atom_expr [10473,10494]
atom_expr [10473,10494]
===
match
---
trailer [15288,15355]
trailer [15300,15367]
===
match
---
atom_expr [13804,13894]
atom_expr [13804,13894]
===
match
---
name: _client [9298,9305]
name: _client [9298,9305]
===
match
---
operator: = [20195,20196]
operator: = [20207,20208]
===
match
---
name: kubernetes_role [11922,11937]
name: kubernetes_role [11922,11937]
===
match
---
name: Optional [5619,5627]
name: Optional [5619,5627]
===
match
---
atom_expr [14214,14228]
atom_expr [14226,14240]
===
match
---
name: _auth_aws_iam [9366,9379]
name: _auth_aws_iam [9366,9379]
===
match
---
name: self [11646,11650]
name: self [11646,11650]
===
match
---
comparison [9320,9347]
comparison [9320,9347]
===
match
---
comparison [9722,9746]
comparison [9722,9746]
===
match
---
trailer [15577,15597]
trailer [15589,15609]
===
match
---
name: secret_version [15675,15689]
name: secret_version [15687,15701]
===
match
---
operator: , [18169,18170]
operator: , [18181,18182]
===
match
---
operator: , [5480,5481]
operator: , [5480,5481]
===
match
---
trailer [8768,8784]
trailer [8768,8784]
===
match
---
argument [14039,14059]
argument [14045,14065]
===
match
---
name: VaultError [15278,15288]
name: VaultError [15290,15300]
===
match
---
param [5194,5199]
param [5194,5199]
===
match
---
operator: == [19790,19792]
operator: == [19802,19804]
===
match
---
comparison [6697,6717]
comparison [6697,6717]
===
match
---
arglist [9198,9225]
arglist [9198,9225]
===
match
---
trailer [12586,12603]
trailer [12586,12603]
===
match
---
operator: , [14202,14203]
operator: , [14214,14215]
===
match
---
argument [13290,13320]
argument [13290,13320]
===
match
---
parameters [9005,9011]
parameters [9005,9011]
===
match
---
operator: , [1385,1386]
operator: , [1385,1386]
===
match
---
name: auth_type [9960,9969]
name: auth_type [9960,9969]
===
match
---
if_stmt [7158,7468]
if_stmt [7158,7468]
===
match
---
simple_stmt [7552,7630]
simple_stmt [7552,7630]
===
match
---
string: "The 'radius' authentication type requires 'radius_host'" [7860,7917]
string: "The 'radius' authentication type requires 'radius_host'" [7860,7917]
===
match
---
except_clause [16783,16801]
except_clause [16795,16813]
===
match
---
and_test [7025,7063]
and_test [7025,7063]
===
match
---
atom_expr [8811,8830]
atom_expr [8811,8830]
===
match
---
trailer [14383,14389]
trailer [14395,14401]
===
match
---
trailer [10097,10107]
trailer [10097,10107]
===
match
---
trailer [13864,13874]
trailer [13864,13874]
===
match
---
name: self [9480,9484]
name: self [9480,9484]
===
match
---
name: open [14332,14336]
name: open [14344,14348]
===
match
---
param [5688,5726]
param [5688,5726]
===
match
---
operator: , [1398,1399]
operator: , [1398,1399]
===
match
---
expr_stmt [12480,12628]
expr_stmt [12480,12628]
===
match
---
atom_expr [12944,13217]
atom_expr [12944,13217]
===
match
---
operator: = [11813,11814]
operator: = [11813,11814]
===
match
---
trailer [14302,14313]
trailer [14314,14325]
===
match
---
operator: , [5520,5521]
operator: , [5520,5521]
===
match
---
name: password [10595,10603]
name: password [10595,10603]
===
match
---
expr_stmt [15541,15707]
expr_stmt [15553,15719]
===
match
---
name: Client [12241,12247]
name: Client [12241,12247]
===
match
---
atom_expr [11985,11996]
atom_expr [11985,11996]
===
match
---
try_stmt [15168,15861]
try_stmt [15180,15873]
===
match
---
import_as_names [804,818]
import_as_names [804,818]
===
match
---
argument [13694,13711]
argument [13694,13711]
===
match
---
name: str [1266,1269]
name: str [1266,1269]
===
match
---
operator: , [1371,1372]
operator: , [1371,1372]
===
match
---
name: cached_property [909,924]
name: cached_property [909,924]
===
match
---
atom_expr [13538,13559]
atom_expr [13538,13559]
===
match
---
atom_expr [5705,5718]
atom_expr [5705,5718]
===
match
---
trailer [12691,12701]
trailer [12691,12701]
===
match
---
name: self [16018,16022]
name: self [16030,16034]
===
match
---
param [5928,5961]
param [5928,5961]
===
match
---
trailer [20126,20241]
trailer [20138,20253]
===
match
---
name: client [17898,17904]
name: client [17910,17916]
===
match
---
atom_expr [8582,8606]
atom_expr [8582,8606]
===
match
---
param [13918,13923]
param [13918,13923]
===
match
---
name: self [15552,15556]
name: self [15564,15568]
===
match
---
name: self [8249,8253]
name: self [8249,8253]
===
match
---
trailer [15476,15488]
trailer [15488,15500]
===
match
---
operator: , [13405,13406]
operator: , [13405,13406]
===
match
---
simple_stmt [8811,8848]
simple_stmt [8811,8848]
===
match
---
name: azure_resource [8816,8830]
name: azure_resource [8816,8830]
===
match
---
name: hvac [14265,14269]
name: hvac [14277,14281]
===
match
---
simple_stmt [7969,8047]
simple_stmt [7969,8047]
===
match
---
operator: == [6707,6709]
operator: == [6707,6709]
===
match
---
name: azure_tenant_id [13005,13020]
name: azure_tenant_id [13005,13020]
===
match
---
comparison [9480,9503]
comparison [9480,9503]
===
match
---
operator: , [5725,5726]
operator: , [5725,5726]
===
match
---
argument [12097,12130]
argument [12097,12130]
===
match
---
param [14250,14255]
param [14262,14267]
===
match
---
name: providers [12279,12288]
name: providers [12279,12288]
===
match
---
atom_expr [12640,12661]
atom_expr [12640,12661]
===
match
---
string: 'kubernetes' [1347,1359]
string: 'kubernetes' [1347,1359]
===
match
---
operator: = [12999,13000]
operator: = [12999,13000]
===
match
---
name: self [11720,11724]
name: self [11720,11724]
===
match
---
name: jwt [11814,11817]
name: jwt [11814,11817]
===
match
---
name: token [14448,14453]
name: token [14460,14465]
===
match
---
name: str [5254,5257]
name: str [5254,5257]
===
match
---
name: auth [12061,12065]
name: auth [12061,12065]
===
match
---
name: _auth_azure [9446,9457]
name: _auth_azure [9446,9457]
===
match
---
argument [16714,16730]
argument [16726,16742]
===
match
---
trailer [9558,9568]
trailer [9558,9568]
===
match
---
strings [6361,6474]
strings [6361,6474]
===
match
---
atom_expr [10844,10860]
atom_expr [10844,10860]
===
match
---
raise_stmt [6547,6685]
raise_stmt [6547,6685]
===
match
---
simple_stmt [7240,7324]
simple_stmt [7240,7324]
===
match
---
trailer [11389,11398]
trailer [11389,11398]
===
match
---
string: "The kubernetes_jwt_path should be set here. This should not happen." [11557,11626]
string: "The kubernetes_jwt_path should be set here. This should not happen." [11557,11626]
===
match
---
operator: @ [8974,8975]
operator: @ [8974,8975]
===
match
---
name: utils [12302,12307]
name: utils [12302,12307]
===
match
---
dotted_name [953,968]
dotted_name [953,968]
===
match
---
trailer [13666,13676]
trailer [13666,13676]
===
match
---
trailer [18089,18095]
trailer [18101,18107]
===
match
---
name: self [11154,11158]
name: self [11154,11158]
===
match
---
name: secret_path [18352,18363]
name: secret_path [18364,18375]
===
match
---
name: utils [1044,1049]
name: utils [1044,1049]
===
match
---
name: secret_id [8486,8495]
name: secret_id [8486,8495]
===
match
---
name: password [11254,11262]
name: password [11254,11262]
===
match
---
trailer [5426,5431]
trailer [5426,5431]
===
match
---
argument [9212,9225]
argument [9212,9225]
===
match
---
import_as_names [12358,12414]
import_as_names [12358,12414]
===
match
---
simple_stmt [12434,12472]
simple_stmt [12434,12472]
===
match
---
name: response [15372,15380]
name: response [15384,15392]
===
match
---
string: "The 'kubernetes' authentication type requires 'kubernetes_role'" [7257,7322]
string: "The 'kubernetes' authentication type requires 'kubernetes_role'" [7257,7322]
===
match
---
atom_expr [11121,11132]
atom_expr [11121,11132]
===
match
---
name: Client [9191,9197]
name: Client [9191,9197]
===
match
---
name: self [12550,12554]
name: self [12550,12554]
===
match
---
name: radius_secret [11035,11048]
name: radius_secret [11035,11048]
===
match
---
funcdef [5134,8969]
funcdef [5134,8969]
===
match
---
name: secret_id [14061,14070]
name: secret_id [14067,14076]
===
match
---
trailer [14398,14400]
trailer [14410,14412]
===
match
---
name: self [11030,11034]
name: self [11030,11034]
===
match
---
trailer [14393,14398]
trailer [14405,14410]
===
match
---
trailer [8378,8387]
trailer [8378,8387]
===
match
---
suite [17873,18041]
suite [17885,18053]
===
match
---
operator: = [13661,13662]
operator: = [13661,13662]
===
match
---
suite [14286,14454]
suite [14298,14466]
===
match
---
atom_expr [5500,5513]
atom_expr [5500,5513]
===
match
---
trailer [7568,7629]
trailer [7568,7629]
===
match
---
operator: = [13393,13394]
operator: = [13393,13394]
===
match
---
argument [15442,15458]
argument [15454,15470]
===
match
---
name: mount_point [15654,15665]
name: mount_point [15666,15677]
===
match
---
name: VaultError [7558,7568]
name: VaultError [7558,7568]
===
match
---
name: VaultError [16543,16553]
name: VaultError [16555,16565]
===
match
---
if_stmt [20022,20438]
if_stmt [20034,20450]
===
match
---
if_stmt [10672,11086]
if_stmt [10672,11086]
===
match
---
suite [11486,11948]
suite [11486,11948]
===
match
---
raise_stmt [19819,19887]
raise_stmt [19831,19899]
===
match
---
name: token [12195,12200]
name: token [12195,12200]
===
match
---
funcdef [11429,11948]
funcdef [11429,11948]
===
match
---
trailer [17024,17029]
trailer [17036,17041]
===
match
---
trailer [5948,5953]
trailer [5948,5953]
===
match
---
argument [13876,13893]
argument [13876,13893]
===
match
---
atom_expr [5849,5862]
atom_expr [5849,5862]
===
match
---
atom_expr [12236,12247]
atom_expr [12236,12247]
===
match
---
operator: = [5342,5343]
operator: = [5342,5343]
===
match
---
suite [10327,10605]
suite [10327,10605]
===
match
---
not_test [6900,6914]
not_test [6900,6914]
===
match
---
param [11456,11476]
param [11456,11476]
===
match
---
operator: , [1303,1304]
operator: , [1303,1304]
===
match
---
argument [10839,10860]
argument [10839,10860]
===
match
---
name: auth_userpass [10543,10556]
name: auth_userpass [10543,10556]
===
match
---
trailer [14269,14276]
trailer [14281,14288]
===
match
---
comparison [15904,15931]
comparison [15916,15943]
===
match
---
name: create_or_update_secret [20103,20126]
name: create_or_update_secret [20115,20138]
===
match
---
operator: == [16519,16521]
operator: == [16531,16533]
===
match
---
suite [16802,16928]
suite [16814,16940]
===
match
---
name: int [14523,14526]
name: int [14535,14538]
===
match
---
name: secret_version [17000,17014]
name: secret_version [17012,17026]
===
match
---
trailer [17915,17918]
trailer [17927,17930]
===
match
---
trailer [20402,20414]
trailer [20414,20426]
===
match
---
trailer [12962,12972]
trailer [12962,12972]
===
match
---
operator: = [8700,8701]
operator: = [8700,8701]
===
match
---
argument [11278,11311]
argument [11278,11311]
===
match
---
atom_expr [13047,13066]
atom_expr [13047,13066]
===
match
---
operator: = [12581,12582]
operator: = [12581,12582]
===
match
---
raise_stmt [17780,17860]
raise_stmt [17792,17872]
===
match
---
name: str [5427,5430]
name: str [5427,5430]
===
match
---
name: kv_engine_version [8061,8078]
name: kv_engine_version [8061,8078]
===
match
---
atom_expr [8440,8451]
atom_expr [8440,8451]
===
match
---
expr_stmt [8764,8802]
expr_stmt [8764,8802]
===
match
---
operator: = [11787,11788]
operator: = [11787,11788]
===
match
---
operator: , [10821,10822]
operator: , [10821,10822]
===
match
---
simple_stmt [7682,7761]
simple_stmt [7682,7761]
===
match
---
name: self [8938,8942]
name: self [8938,8942]
===
match
---
string: """         Reads secret including metadata. It is only valid for KV version 2.          See https://hvac.readthedocs.io/en/stable/usage/secrets_engines/kv_v2.html for details.          :param secret_path: The path of the secret.         :type secret_path: str         :param secret_version: Specifies the version of Secret to return. If not set, the latest             version is returned. (Can only be used in case of version 2 of KV).         :type secret_version: int         :rtype: dict         :return: The key info. This is a Dict with "data" mapping keeping secret                  and "metadata" mapping keeping metadata of the secret.         """ [17070,17727]
string: """         Reads secret including metadata. It is only valid for KV version 2.          See https://hvac.readthedocs.io/en/stable/usage/secrets_engines/kv_v2.html for details.          :param secret_path: The path of the secret.         :type secret_path: str         :param secret_version: Specifies the version of Secret to return. If not set, the latest             version is returned. (Can only be used in case of version 2 of KV).         :type secret_version: int         :rtype: dict         :return: The key info. This is a Dict with "data" mapping keeping secret                  and "metadata" mapping keeping metadata of the secret.         """ [17082,17739]
===
match
---
name: configure [10730,10739]
name: configure [10730,10739]
===
match
---
atom_expr [6121,6134]
atom_expr [6121,6134]
===
match
---
trailer [16500,16518]
trailer [16512,16530]
===
match
---
trailer [17743,17761]
trailer [17755,17773]
===
match
---
name: airflow [12271,12278]
name: airflow [12271,12278]
===
match
---
name: auth [12166,12170]
name: auth [12166,12170]
===
match
---
operator: , [13451,13452]
operator: , [13451,13452]
===
match
---
name: self [9678,9682]
name: self [9678,9682]
===
match
---
simple_stmt [11189,11326]
simple_stmt [11189,11326]
===
match
---
argument [13084,13105]
argument [13084,13105]
===
match
---
name: self [11788,11792]
name: self [11788,11792]
===
match
---
simple_stmt [17780,17861]
simple_stmt [17792,17873]
===
match
---
trailer [11369,11375]
trailer [11369,11375]
===
match
---
param [13924,13944]
param [13924,13944]
===
match
---
string: 'approle' [1279,1288]
string: 'approle' [1279,1288]
===
match
---
trailer [15563,15571]
trailer [15575,15583]
===
match
---
trailer [8339,8351]
trailer [8339,8351]
===
match
---
arglist [13825,13893]
arglist [13825,13893]
===
match
---
simple_stmt [16916,16928]
simple_stmt [16928,16940]
===
match
---
atom_expr [15748,15836]
atom_expr [15760,15848]
===
match
---
name: self [8407,8411]
name: self [8407,8411]
===
match
---
operator: , [18412,18413]
operator: , [18424,18425]
===
match
---
operator: = [10802,10803]
operator: = [10802,10803]
===
match
---
atom_expr [6770,6848]
atom_expr [6770,6848]
===
match
---
name: _client [11112,11119]
name: _client [11112,11119]
===
match
---
name: self [8637,8641]
name: self [8637,8641]
===
match
---
name: auth_aws_iam [13581,13593]
name: auth_aws_iam [13581,13593]
===
match
---
name: self [16886,16890]
name: self [16898,16902]
===
match
---
operator: = [11384,11385]
operator: = [11384,11385]
===
match
---
name: kv [16670,16672]
name: kv [16682,16684]
===
match
---
operator: = [1117,1118]
operator: = [1117,1118]
===
match
---
trailer [8860,8872]
trailer [8860,8872]
===
match
---
trailer [13441,13451]
trailer [13441,13451]
===
match
---
argument [14087,14120]
argument [14093,14126]
===
match
---
name: azure_resource [13352,13366]
name: azure_resource [13352,13366]
===
match
---
simple_stmt [15748,15837]
simple_stmt [15760,15849]
===
match
---
name: password [10451,10459]
name: password [10451,10459]
===
match
---
string: 'github' [1322,1330]
string: 'github' [1322,1330]
===
match
---
atom_expr [17986,18002]
atom_expr [17998,18014]
===
match
---
import_from [948,999]
import_from [948,999]
===
match
---
name: auth_mount_point [10680,10696]
name: auth_mount_point [10680,10696]
===
match
---
suite [20053,20242]
suite [20065,20254]
===
match
---
raise_stmt [7077,7149]
raise_stmt [7077,7149]
===
match
---
atom_expr [11888,11947]
atom_expr [11888,11947]
===
match
---
simple_stmt [8135,8150]
simple_stmt [8135,8150]
===
match
---
atom_expr [11409,11422]
atom_expr [11409,11422]
===
match
---
if_stmt [12015,12202]
if_stmt [12015,12202]
===
match
---
name: _client [10185,10192]
name: _client [10185,10192]
===
match
---
tfpdef [16024,16040]
tfpdef [16036,16052]
===
match
---
operator: = [1234,1235]
operator: = [1234,1235]
===
match
---
simple_stmt [11352,11424]
simple_stmt [11352,11424]
===
match
---
name: auth_type [6860,6869]
name: auth_type [6860,6869]
===
match
---
comparison [7479,7499]
comparison [7479,7499]
===
match
---
name: keyfile_dict [12569,12581]
name: keyfile_dict [12569,12581]
===
match
---
operator: -> [13518,13520]
operator: -> [13518,13520]
===
match
---
param [5835,5870]
param [5835,5870]
===
match
---
number: 1 [1237,1238]
number: 1 [1237,1238]
===
match
---
name: secret [20378,20384]
name: secret [20390,20396]
===
match
---
name: password [10437,10445]
name: password [10437,10445]
===
match
---
atom_expr [12190,12200]
atom_expr [12190,12200]
===
match
---
simple_stmt [9441,9467]
simple_stmt [9441,9467]
===
match
---
name: str [5667,5670]
name: str [5667,5670]
===
match
---
arglist [11230,11311]
arglist [11230,11311]
===
match
---
name: client_id [13084,13093]
name: client_id [13084,13093]
===
match
---
operator: , [13105,13106]
operator: , [13105,13106]
===
match
---
operator: = [15623,15624]
operator: = [15635,15636]
===
match
---
trailer [16890,16902]
trailer [16902,16914]
===
match
---
tfpdef [18414,18432]
tfpdef [18426,18444]
===
match
---
trailer [9598,9611]
trailer [9598,9611]
===
match
---
name: password [10581,10589]
name: password [10581,10589]
===
match
---
name: mount_point [20386,20397]
name: mount_point [20398,20409]
===
match
---
name: VALID_AUTH_TYPES [6517,6533]
name: VALID_AUTH_TYPES [6517,6533]
===
match
---
name: self [16496,16500]
name: self [16508,16512]
===
match
---
trailer [5627,5632]
trailer [5627,5632]
===
match
---
simple_stmt [10710,10927]
simple_stmt [10710,10927]
===
match
---
name: Optional [5705,5713]
name: Optional [5705,5713]
===
match
---
name: auth_type [10098,10107]
name: auth_type [10098,10107]
===
match
---
name: str [16037,16040]
name: str [16049,16052]
===
match
---
simple_stmt [842,880]
simple_stmt [842,880]
===
match
---
operator: , [14059,14060]
operator: , [14065,14066]
===
match
---
name: self [11409,11413]
name: self [11409,11413]
===
match
---
string: """         Get secret value from the KV engine.          :param secret_path: The path of the secret.         :type secret_path: str         :param secret_version: Specifies the version of Secret to return. If not set, the latest             version is returned. (Can only be used in case of version 2 of KV).         :type secret_version: int          See https://hvac.readthedocs.io/en/stable/usage/secrets_engines/kv_v1.html         and https://hvac.readthedocs.io/en/stable/usage/secrets_engines/kv_v2.html for details.          :return: secret stored in the vault as a dictionary         """ [14563,15159]
string: """         Get secret value from the KV engine.          :param secret_path: The path of the secret.         :type secret_path: str         :param secret_version: Specifies the version of Secret to return. If not set, the latest             version is returned. (Can only be used in case of version 2 of KV).         :type secret_version: int          See https://hvac.readthedocs.io/en/stable/usage/secrets_engines/kv_v1.html         and https://hvac.readthedocs.io/en/stable/usage/secrets_engines/kv_v2.html for details.          :return: secret stored in the vault as a dictionary         """ [14575,15171]
===
match
---
fstring [6630,6671]
fstring [6630,6671]
===
match
---
name: self [17986,17990]
name: self [17998,18002]
===
match
---
classdef [1420,20462]
classdef [1420,20474]
===
match
---
expr_stmt [8938,8968]
expr_stmt [8938,8968]
===
match
---
name: Client [14270,14276]
name: Client [14282,14288]
===
match
---
trailer [9775,9784]
trailer [9775,9784]
===
match
---
trailer [13885,13893]
trailer [13885,13893]
===
match
---
string: "Secret version can only be used with version 2 of the KV engine" [15289,15354]
string: "Secret version can only be used with version 2 of the KV engine" [15301,15366]
===
match
---
name: mount_point [20403,20414]
name: mount_point [20415,20426]
===
match
---
operator: = [8352,8353]
operator: = [8352,8353]
===
match
---
name: cached_property [8975,8990]
name: cached_property [8975,8990]
===
match
---
name: mount_point [13169,13180]
name: mount_point [13169,13180]
===
match
---
param [14498,14534]
param [14510,14546]
===
match
---
atom_expr [12788,12839]
atom_expr [12788,12839]
===
match
---
operator: = [8173,8174]
operator: = [8173,8174]
===
match
---
atom_expr [12550,12567]
atom_expr [12550,12567]
===
match
---
string: 'gcp' [1336,1341]
string: 'gcp' [1336,1341]
===
match
---
import_from [1031,1087]
import_from [1031,1087]
===
match
---
arglist [11000,11071]
arglist [11000,11071]
===
match
---
name: auth_type [5243,5252]
name: auth_type [5243,5252]
===
match
---
atom_expr [19954,20013]
atom_expr [19966,20025]
===
match
---
name: _client [9856,9863]
name: _client [9856,9863]
===
match
---
name: _client [14001,14008]
name: _client [14001,14008]
===
match
---
trailer [14194,14202]
trailer [14206,14214]
===
match
---
string: '/var/run/secrets/kubernetes.io/serviceaccount/token' [5772,5825]
string: '/var/run/secrets/kubernetes.io/serviceaccount/token' [5772,5825]
===
match
---
suite [11339,11424]
suite [11339,11424]
===
match
---
atom_expr [12109,12130]
atom_expr [12109,12130]
===
match
---
fstring_string: .  [6412,6414]
fstring_string: .  [6412,6414]
===
match
---
name: self [9320,9324]
name: self [9320,9324]
===
match
---
operator: = [14441,14442]
operator: = [14453,14454]
===
match
---
suite [12040,12132]
suite [12040,12132]
===
match
---
operator: , [6202,6203]
operator: , [6202,6203]
===
match
---
name: client [16655,16661]
name: client [16667,16673]
===
match
---
number: 1 [19925,19926]
number: 1 [19937,19938]
===
match
---
name: v2 [16673,16675]
name: v2 [16685,16687]
===
match
---
name: response [15937,15945]
name: response [15949,15957]
===
match
---
parameters [11449,11477]
parameters [11449,11477]
===
match
---
operator: == [9569,9571]
operator: == [9569,9571]
===
match
---
not_test [6736,6750]
not_test [6736,6750]
===
match
---
name: auth [11360,11364]
name: auth [11360,11364]
===
match
---
operator: { [6393,6394]
operator: { [6393,6394]
===
match
---
trailer [8899,8913]
trailer [8899,8913]
===
match
---
trailer [6129,6134]
trailer [6129,6134]
===
match
---
string: """         Return an authenticated Hashicorp Vault client.          :rtype: hvac.Client         :return: Vault Client          """ [9036,9167]
string: """         Return an authenticated Hashicorp Vault client.          :rtype: hvac.Client         :return: Vault Client          """ [9036,9167]
===
match
---
string: "gcp" [9498,9503]
string: "gcp" [9498,9503]
===
match
---
atom_expr [13966,13987]
atom_expr [13966,13987]
===
match
---
testlist_comp [1237,1241]
testlist_comp [1237,1241]
===
match
---
name: jwt [11810,11813]
name: jwt [11810,11813]
===
match
---
name: Client [10647,10653]
name: Client [10647,10653]
===
match
---
name: auth_type [6616,6625]
name: auth_type [6616,6625]
===
match
---
funcdef [18309,20462]
funcdef [18321,20474]
===
match
---
name: _client [13573,13580]
name: _client [13573,13580]
===
match
---
atom_expr [17739,17761]
atom_expr [17751,17773]
===
match
---
suite [12006,12202]
suite [12006,12202]
===
match
---
name: kv_engine_version [15909,15926]
name: kv_engine_version [15921,15938]
===
match
---
simple_stmt [16069,16485]
simple_stmt [16081,16497]
===
match
---
atom_expr [15904,15926]
atom_expr [15916,15938]
===
match
---
fstring_expr [6615,6626]
fstring_expr [6615,6626]
===
match
---
operator: = [8205,8206]
operator: = [8205,8206]
===
match
---
expr_stmt [14376,14400]
expr_stmt [14388,14412]
===
match
---
if_stmt [15233,15356]
if_stmt [15245,15368]
===
match
---
argument [20386,20414]
argument [20398,20426]
===
match
---
trailer [12554,12567]
trailer [12554,12567]
===
match
---
name: mount_point [15477,15488]
name: mount_point [15489,15500]
===
match
---
operator: = [8955,8956]
operator: = [8955,8956]
===
match
---
atom_expr [13573,13777]
atom_expr [13573,13777]
===
match
---
comparison [9634,9664]
comparison [9634,9664]
===
match
---
name: self [12018,12022]
name: self [12018,12022]
===
match
---
atom_expr [12909,12930]
atom_expr [12909,12930]
===
match
---
atom_expr [11720,11741]
atom_expr [11720,11741]
===
match
---
name: self [13699,13703]
name: self [13699,13703]
===
match
---
name: debug [15757,15762]
name: debug [15769,15774]
===
match
---
argument [18004,18026]
argument [18016,18038]
===
match
---
atom_expr [14047,14059]
atom_expr [14053,14065]
===
match
---
name: mount_point [17974,17985]
name: mount_point [17986,17997]
===
match
---
string: "data" [15954,15960]
string: "data" [15966,15972]
===
match
---
name: _get_scopes [12443,12454]
name: _get_scopes [12443,12454]
===
match
---
fstring_string: It should be one of  [6632,6652]
fstring_string: It should be one of  [6632,6652]
===
match
---
trailer [11267,11276]
trailer [11267,11276]
===
match
---
name: secret_path [16982,16993]
name: secret_path [16994,17005]
===
match
---
name: path [16714,16718]
name: path [16726,16730]
===
match
---
trailer [10848,10860]
trailer [10848,10860]
===
match
---
name: secret_key [13849,13859]
name: secret_key [13849,13859]
===
match
---
trailer [9932,9941]
trailer [9932,9941]
===
match
---
simple_stmt [10535,10605]
simple_stmt [10535,10605]
===
match
---
name: read_secret_version [15578,15597]
name: read_secret_version [15590,15609]
===
match
---
atom_expr [14099,14120]
atom_expr [14105,14126]
===
match
---
trailer [12022,12039]
trailer [12022,12039]
===
match
---
parameters [18336,18445]
parameters [18348,18457]
===
match
---
name: mount_point [15824,15835]
name: mount_point [15836,15847]
===
match
---
trailer [13141,13151]
trailer [13141,13151]
===
match
---
suite [15251,15356]
suite [15263,15368]
===
match
---
trailer [9882,9892]
trailer [9882,9892]
===
match
---
atom_expr [16496,16518]
atom_expr [16508,16530]
===
match
---
trailer [11125,11132]
trailer [11125,11132]
===
match
---
atom_expr [10642,10653]
atom_expr [10642,10653]
===
match
---
name: key_id [8445,8451]
name: key_id [8445,8451]
===
match
---
trailer [12065,12072]
trailer [12065,12072]
===
match
---
argument [13038,13066]
argument [13038,13066]
===
match
---
atom_expr [13000,13020]
atom_expr [13000,13020]
===
match
---
operator: = [8144,8145]
operator: = [8144,8145]
===
match
---
name: auth_mount_point [13543,13559]
name: auth_mount_point [13543,13559]
===
match
---
atom_expr [12085,12095]
atom_expr [12085,12095]
===
match
---
atom_expr [20398,20414]
atom_expr [20410,20426]
===
match
---
simple_stmt [8193,8214]
simple_stmt [8193,8214]
===
match
---
name: InvalidPath [16790,16801]
name: InvalidPath [16802,16813]
===
match
---
param [5490,5521]
param [5490,5521]
===
match
---
trailer [13262,13272]
trailer [13262,13272]
===
match
---
name: Client [11990,11996]
name: Client [11990,11996]
===
match
---
trailer [8731,8742]
trailer [8731,8742]
===
match
---
trailer [16661,16669]
trailer [16673,16681]
===
match
---
if_stmt [7931,8047]
if_stmt [7931,8047]
===
match
---
name: secret_path [20358,20369]
name: secret_path [20370,20381]
===
match
---
if_stmt [7476,7761]
if_stmt [7476,7761]
===
match
---
expr_stmt [12434,12471]
expr_stmt [12434,12471]
===
match
---
atom_expr [13244,13466]
atom_expr [13244,13466]
===
match
---
atom_expr [18216,18232]
atom_expr [18228,18244]
===
match
---
operator: = [11289,11290]
operator: = [11289,11290]
===
match
---
name: Optional [810,818]
name: Optional [810,818]
===
match
---
trailer [8197,8204]
trailer [8197,8204]
===
match
---
trailer [9365,9379]
trailer [9365,9379]
===
match
---
suite [18458,20462]
suite [18470,20474]
===
match
---
funcdef [14459,15989]
funcdef [14471,16001]
===
match
---
name: version [18004,18011]
name: version [18016,18023]
===
match
---
name: auth_mount_point [13971,13987]
name: auth_mount_point [13971,13987]
===
match
---
name: gcp [12801,12804]
name: gcp [12801,12804]
===
match
---
name: azure_tenant_id [8787,8802]
name: azure_tenant_id [8787,8802]
===
match
---
atom_expr [5658,5671]
atom_expr [5658,5671]
===
match
---
string: """         Creates or updates secret.          :param secret_path: The path of the secret.         :type secret_path: str         :param secret: Secret to create or update for the path specified         :type secret: dict         :param method: Optional parameter to explicitly request a POST (create) or PUT (update) request to             the selected kv secret engine. If no argument is provided for this parameter, hvac attempts to             intelligently determine which method is appropriate. Only valid for KV engine version 1         :type method: str         :param cas: Set the "cas" value to use a Check-And-Set operation. If not set the write will be             allowed. If set to 0 a write will only be allowed if the key doesn't exist.             If the index is non-zero the write will only be allowed if the key's current version             matches the version specified in the cas parameter. Only valid for KV engine version 2.         :type cas: int         :rtype: requests.Response         :return: The response of the create_or_update_secret request.                   See https://hvac.readthedocs.io/en/stable/usage/secrets_engines/kv_v1.html                  and https://hvac.readthedocs.io/en/stable/usage/secrets_engines/kv_v2.html for details.          """ [18467,19755]
string: """         Creates or updates secret.          :param secret_path: The path of the secret.         :type secret_path: str         :param secret: Secret to create or update for the path specified         :type secret: dict         :param method: Optional parameter to explicitly request a POST (create) or PUT (update) request to             the selected kv secret engine. If no argument is provided for this parameter, hvac attempts to             intelligently determine which method is appropriate. Only valid for KV engine version 1         :type method: str         :param cas: Set the "cas" value to use a Check-And-Set operation. If not set the write will be             allowed. If set to 0 a write will only be allowed if the key doesn't exist.             If the index is non-zero the write will only be allowed if the key's current version             matches the version specified in the cas parameter. Only valid for KV engine version 2.         :type cas: int         :rtype: requests.Response         :return: The response of the create_or_update_secret request.                   See https://hvac.readthedocs.io/en/stable/usage/secrets_engines/kv_v1.html                  and https://hvac.readthedocs.io/en/stable/usage/secrets_engines/kv_v2.html for details.          """ [18479,19767]
===
match
---
name: username [11390,11398]
name: username [11390,11398]
===
match
---
trailer [13840,13847]
trailer [13840,13847]
===
match
---
name: auth [12683,12687]
name: auth [12683,12687]
===
match
---
name: __init__ [5138,5146]
name: __init__ [5138,5146]
===
match
---
atom_expr [9015,9026]
atom_expr [9015,9026]
===
match
---
argument [10796,10821]
argument [10796,10821]
===
match
---
test [8081,8126]
test [8081,8126]
===
match
---
trailer [7859,7918]
trailer [7859,7918]
===
match
---
operator: , [13151,13152]
operator: , [13151,13152]
===
match
---
name: username [5490,5498]
name: username [5490,5498]
===
match
---
operator: = [14189,14190]
operator: = [14201,14202]
===
match
---
suite [13954,14230]
suite [13954,14242]
===
match
---
funcdef [11953,12202]
funcdef [11953,12202]
===
match
---
atom_expr [13836,13847]
atom_expr [13836,13847]
===
match
---
name: _auth_radius [9843,9855]
name: _auth_radius [9843,9855]
===
match
---
import_from [904,947]
import_from [904,947]
===
match
---
name: client [8999,9005]
name: client [8999,9005]
===
match
---
atom_expr [13860,13874]
atom_expr [13860,13874]
===
match
---
atom_expr [8469,8483]
atom_expr [8469,8483]
===
match
---
atom_expr [8856,8872]
atom_expr [8856,8872]
===
match
---
atom_expr [18419,18432]
atom_expr [18431,18444]
===
match
---
simple_stmt [8764,8803]
simple_stmt [8764,8803]
===
match
---
trailer [14336,14353]
trailer [14348,14365]
===
match
---
argument [11254,11276]
argument [11254,11276]
===
match
---
name: username [8390,8398]
name: username [8390,8398]
===
match
---
name: kv_engine_version [19904,19921]
name: kv_engine_version [19916,19933]
===
match
---
param [6106,6142]
param [6106,6142]
===
match
---
name: auth [10718,10722]
name: auth [10718,10722]
===
match
---
name: kv_engine_version [19772,19789]
name: kv_engine_version [19784,19801]
===
match
---
arglist [14039,14120]
arglist [14045,14126]
===
match
---
operator: -> [10319,10321]
operator: -> [10319,10321]
===
match
---
param [12221,12226]
param [12221,12226]
===
match
---
suite [20255,20438]
suite [20267,20450]
===
match
---
atom_expr [10675,10696]
atom_expr [10675,10696]
===
match
---
atom_expr [13137,13151]
atom_expr [13137,13151]
===
match
---
atom_expr [11696,11704]
atom_expr [11696,11704]
===
match
---
name: Optional [5540,5548]
name: Optional [5540,5548]
===
match
---
operator: = [12549,12550]
operator: = [12549,12550]
===
match
---
name: jwt [11939,11942]
name: jwt [11939,11942]
===
match
---
operator: , [20212,20213]
operator: , [20224,20225]
===
match
---
name: ldap [11365,11369]
name: ldap [11365,11369]
===
match
---
trailer [20088,20096]
trailer [20100,20108]
===
match
---
raise_stmt [10219,10266]
raise_stmt [10219,10266]
===
match
---
trailer [10556,10604]
trailer [10556,10604]
===
match
---
comparison [6500,6533]
comparison [6500,6533]
===
match
---
name: debug [16824,16829]
name: debug [16836,16841]
===
match
---
name: path [15619,15623]
name: path [15631,15635]
===
match
---
name: gcp_keyfile_dict [5879,5895]
name: gcp_keyfile_dict [5879,5895]
===
match
---
name: radius_secret [6106,6119]
name: radius_secret [6106,6119]
===
match
---
trailer [13580,13593]
trailer [13580,13593]
===
match
---
param [16976,16981]
param [16988,16993]
===
match
---
operator: == [20048,20050]
operator: == [20060,20062]
===
match
---
simple_stmt [18292,18304]
simple_stmt [18304,18316]
===
match
---
name: key_id [13841,13847]
name: key_id [13841,13847]
===
match
---
name: self [13836,13840]
name: self [13836,13840]
===
match
---
name: self [13047,13051]
name: self [13047,13051]
===
match
---
operator: = [8079,8080]
operator: = [8079,8080]
===
match
---
atom_expr [7849,7918]
atom_expr [7849,7918]
===
match
---
operator: = [10565,10566]
operator: = [10565,10566]
===
match
---
operator: = [5592,5593]
operator: = [5592,5593]
===
match
---
name: Optional [6121,6129]
name: Optional [6121,6129]
===
match
---
name: Optional [18392,18400]
name: Optional [18404,18412]
===
match
---
suite [10697,10927]
suite [10697,10927]
===
match
---
simple_stmt [9917,9942]
simple_stmt [9917,9942]
===
match
---
name: List [804,808]
name: List [804,808]
===
match
---
operator: -> [18446,18448]
operator: -> [18458,18460]
===
match
---
simple_stmt [18467,19756]
simple_stmt [18479,19768]
===
match
---
name: kv_engine_version [5362,5379]
name: kv_engine_version [5362,5379]
===
match
---
argument [11939,11946]
argument [11939,11946]
===
match
---
atom_expr [11352,11423]
atom_expr [11352,11423]
===
match
---
name: dict [17055,17059]
name: dict [17067,17071]
===
match
---
name: _auth_ldap [11095,11105]
name: _auth_ldap [11095,11105]
===
match
---
name: self [17739,17743]
name: self [17751,17755]
===
match
---
operator: , [9210,9211]
operator: , [9210,9211]
===
match
---
not_test [7339,7362]
not_test [7339,7362]
===
match
---
operator: = [14070,14071]
operator: = [14076,14077]
===
match
---
name: self [9214,9218]
name: self [9214,9218]
===
match
---
atom_expr [15383,15506]
atom_expr [15395,15518]
===
match
---
name: self [15748,15752]
name: self [15760,15764]
===
match
---
string: "Secret not found %s with mount point %s" [15763,15804]
string: "Secret not found %s with mount point %s" [15775,15816]
===
match
---
name: gcp_key_path [12555,12567]
name: gcp_key_path [12555,12567]
===
match
---
param [6017,6054]
param [6017,6054]
===
match
---
operator: , [13762,13763]
operator: , [13762,13763]
===
match
---
name: azure_tenant_id [7649,7664]
name: azure_tenant_id [7649,7664]
===
match
---
name: self [11970,11974]
name: self [11970,11974]
===
match
---
operator: , [12095,12096]
operator: , [12095,12096]
===
match
---
atom_expr [11917,11937]
atom_expr [11917,11937]
===
match
---
operator: = [14046,14047]
operator: = [14052,14053]
===
match
---
name: token [14435,14440]
name: token [14447,14452]
===
match
---
param [5208,5234]
param [5208,5234]
===
match
---
operator: = [5554,5555]
operator: = [5554,5555]
===
match
---
if_stmt [11495,11628]
if_stmt [11495,11628]
===
match
---
simple_stmt [785,819]
simple_stmt [785,819]
===
match
---
operator: = [13436,13437]
operator: = [13436,13437]
===
match
---
name: jwt [11943,11946]
name: jwt [11943,11946]
===
match
---
operator: = [15550,15551]
operator: = [15562,15563]
===
match
---
trailer [10235,10266]
trailer [10235,10266]
===
match
---
operator: , [5267,5268]
operator: , [5267,5268]
===
match
---
argument [12569,12603]
argument [12569,12603]
===
match
---
name: secret_path [20346,20357]
name: secret_path [20358,20369]
===
match
---
atom_expr [8335,8351]
atom_expr [8335,8351]
===
match
---
name: role_id [14182,14189]
name: role_id [14194,14201]
===
match
---
arglist [20346,20423]
arglist [20358,20435]
===
match
---
atom_expr [14071,14085]
atom_expr [14077,14091]
===
match
---
trailer [12800,12804]
trailer [12800,12804]
===
match
---
name: _ [12493,12494]
name: _ [12493,12494]
===
match
---
atom_expr [18081,18279]
atom_expr [18093,18291]
===
match
---
name: _auth_aws_iam [13476,13489]
name: _auth_aws_iam [13476,13489]
===
match
---
trailer [15892,15900]
trailer [15904,15912]
===
match
---
name: auth_mount_point [12744,12760]
name: auth_mount_point [12744,12760]
===
match
---
name: auth_mount_point [5277,5293]
name: auth_mount_point [5277,5293]
===
match
---
fstring_end: " [6473,6474]
fstring_end: " [6473,6474]
===
match
---
tfpdef [14498,14527]
tfpdef [14510,14539]
===
match
---
name: self [8374,8378]
name: self [8374,8378]
===
match
---
argument [13123,13151]
argument [13123,13151]
===
match
---
simple_stmt [13573,13778]
simple_stmt [13573,13778]
===
match
---
name: self [20279,20283]
name: self [20291,20295]
===
match
---
name: Optional [14514,14522]
name: Optional [14526,14534]
===
match
---
operator: = [11694,11695]
operator: = [11694,11695]
===
match
---
param [18414,18439]
param [18426,18451]
===
match
---
name: configure [12963,12972]
name: configure [12963,12972]
===
match
---
arglist [15763,15835]
arglist [15775,15847]
===
match
---
atom_expr [10590,10603]
atom_expr [10590,10603]
===
match
---
trailer [15653,15665]
trailer [15665,15677]
===
match
---
param [5411,5439]
param [5411,5439]
===
match
---
try_stmt [16626,16928]
try_stmt [16638,16940]
===
match
---
name: azure_resource [13052,13066]
name: azure_resource [13052,13066]
===
match
---
operator: , [1330,1331]
operator: , [1330,1331]
===
match
---
annassign [1259,1417]
annassign [1259,1417]
===
match
---
simple_stmt [11759,11854]
simple_stmt [11759,11854]
===
match
---
name: radius_port [8957,8968]
name: radius_port [8957,8968]
===
match
---
name: path [17956,17960]
name: path [17968,17972]
===
match
---
argument [15460,15488]
argument [15472,15500]
===
match
---
trailer [14434,14440]
trailer [14446,14452]
===
match
---
name: _client [10633,10640]
name: _client [10633,10640]
===
match
---
simple_stmt [8582,8629]
simple_stmt [8582,8629]
===
match
---
name: self [10590,10594]
name: self [10590,10594]
===
match
---
operator: == [9417,9419]
operator: == [9417,9419]
===
match
---
param [18384,18413]
param [18396,18425]
===
match
---
name: secret_id [14204,14213]
name: secret_id [14216,14225]
===
match
---
name: kubernetes_jwt_path [7343,7362]
name: kubernetes_jwt_path [7343,7362]
===
match
---
name: str [6042,6045]
name: str [6042,6045]
===
match
---
name: secret [20169,20175]
name: secret [20181,20187]
===
match
---
raise_stmt [7843,7918]
raise_stmt [7843,7918]
===
match
---
simple_stmt [16537,16618]
simple_stmt [16549,16630]
===
match
---
tfpdef [5970,6000]
tfpdef [5970,6000]
===
match
---
trailer [13811,13824]
trailer [13811,13824]
===
match
---
param [14474,14479]
param [14486,14491]
===
match
---
operator: , [10459,10460]
operator: , [10459,10460]
===
match
---
name: self [14071,14075]
name: self [14077,14081]
===
match
---
name: self [14474,14478]
name: self [14486,14490]
===
match
---
not_test [11498,11526]
not_test [11498,11526]
===
match
---
name: self [15383,15387]
name: self [15395,15399]
===
match
---
trailer [5586,5591]
trailer [5586,5591]
===
match
---
operator: , [5352,5353]
operator: , [5352,5353]
===
match
---
name: github [12171,12177]
name: github [12171,12177]
===
match
---
argument [9198,9210]
argument [9198,9210]
===
match
---
name: self [9798,9802]
name: self [9798,9802]
===
match
---
atom_expr [11546,11627]
atom_expr [11546,11627]
===
match
---
name: self [16744,16748]
name: self [16756,16760]
===
match
---
name: auth [11197,11201]
name: auth [11197,11201]
===
match
---
expr_stmt [8678,8718]
expr_stmt [8678,8718]
===
match
---
param [11450,11455]
param [11450,11455]
===
match
---
trailer [8139,8143]
trailer [8139,8143]
===
match
---
simple_stmt [14427,14454]
simple_stmt [14439,14466]
===
match
---
argument [15667,15689]
argument [15679,15701]
===
match
---
name: _set_token [14239,14249]
name: _set_token [14251,14261]
===
match
---
simple_stmt [15372,15507]
simple_stmt [15384,15519]
===
match
---
name: radius_port [11060,11071]
name: radius_port [11060,11071]
===
match
---
name: key_id [13627,13633]
name: key_id [13627,13633]
===
match
---
name: Optional [5849,5857]
name: Optional [5849,5857]
===
match
---
atom_expr [20025,20047]
atom_expr [20037,20059]
===
match
---
name: gcp_keyfile_dict [8702,8718]
name: gcp_keyfile_dict [8702,8718]
===
match
---
name: response [15884,15892]
name: response [15896,15904]
===
match
---
trailer [13098,13105]
trailer [13098,13105]
===
match
---
operator: ** [9212,9214]
operator: ** [9212,9214]
===
match
---
operator: , [13711,13712]
operator: , [13711,13712]
===
match
---
name: token_path [14303,14313]
name: token_path [14315,14325]
===
match
---
name: role [11912,11916]
name: role [11912,11916]
===
match
---
name: role [13694,13698]
name: role [13694,13698]
===
match
---
name: f [11675,11676]
name: f [11675,11676]
===
match
---
atom_expr [9480,9494]
atom_expr [9480,9494]
===
match
---
name: gcp_keyfile_dict [12587,12603]
name: gcp_keyfile_dict [12587,12603]
===
match
---
and_test [19899,19934]
and_test [19911,19946]
===
match
---
name: _client [10138,10145]
name: _client [10138,10145]
===
match
---
trailer [10739,10926]
trailer [10739,10926]
===
match
---
fstring_start: f" [6361,6363]
fstring_start: f" [6361,6363]
===
match
---
name: self [13490,13494]
name: self [13490,13494]
===
match
---
name: password [8412,8420]
name: password [8412,8420]
===
match
---
operator: , [11276,11277]
operator: , [11276,11277]
===
match
---
operator: = [9201,9202]
operator: = [9201,9202]
===
match
---
name: secret_id [5608,5617]
name: secret_id [5608,5617]
===
match
---
name: VaultError [6770,6780]
name: VaultError [6770,6780]
===
match
---
suite [10522,10605]
suite [10522,10605]
===
match
---
simple_stmt [904,948]
simple_stmt [904,948]
===
match
---
expr_stmt [1089,1172]
expr_stmt [1089,1172]
===
match
---
name: read [11698,11702]
name: read [11698,11702]
===
match
---
name: int [6173,6176]
name: int [6173,6176]
===
match
---
name: v2 [20302,20304]
name: v2 [20314,20316]
===
match
---
name: client [20284,20290]
name: client [20296,20302]
===
match
---
name: self [8678,8682]
name: self [8678,8682]
===
match
---
operator: } [10107,10108]
operator: } [10107,10108]
===
match
---
operator: = [5770,5771]
operator: = [5770,5771]
===
match
---
name: __init__ [6227,6235]
name: __init__ [6227,6235]
===
match
---
name: self [14099,14103]
name: self [14105,14109]
===
match
---
name: kubernetes_jwt_path [11651,11670]
name: kubernetes_jwt_path [11651,11670]
===
match
---
name: self [20025,20029]
name: self [20037,20041]
===
match
---
argument [12605,12618]
argument [12605,12618]
===
match
---
operator: = [8484,8485]
operator: = [8484,8485]
===
match
---
argument [11400,11422]
argument [11400,11422]
===
match
---
trailer [12795,12800]
trailer [12795,12800]
===
match
---
simple_stmt [20446,20462]
simple_stmt [20458,20474]
===
match
---
name: gcp_scopes [12460,12470]
name: gcp_scopes [12460,12470]
===
match
---
suite [12931,13218]
suite [12931,13218]
===
match
---
operator: , [1316,1317]
operator: , [1316,1317]
===
match
---
suite [18068,18304]
suite [18080,18316]
===
match
---
name: kubernetes_jwt_path [8587,8606]
name: kubernetes_jwt_path [8587,8606]
===
match
---
operator: , [11454,11455]
operator: , [11454,11455]
===
match
---
arglist [20144,20227]
arglist [20156,20239]
===
match
---
suite [7363,7468]
suite [7363,7468]
===
match
---
name: token [12079,12084]
name: token [12079,12084]
===
match
---
trailer [6084,6089]
trailer [6084,6089]
===
match
---
string: "github" [6873,6881]
string: "github" [6873,6881]
===
match
---
name: int [5390,5393]
name: int [5390,5393]
===
match
---
name: cas [20416,20419]
name: cas [20428,20431]
===
match
---
funcdef [15994,16928]
funcdef [16006,16940]
===
match
---
atom_expr [11263,11276]
atom_expr [11263,11276]
===
match
---
atom_expr [10446,10459]
atom_expr [10446,10459]
===
match
---
name: cas [19931,19934]
name: cas [19943,19946]
===
match
---
name: auth_type [6697,6706]
name: auth_type [6697,6706]
===
match
---
simple_stmt [10374,10509]
simple_stmt [10374,10509]
===
match
---
name: mount_point [10461,10472]
name: mount_point [10461,10472]
===
match
---
name: auth_mount_point [12023,12039]
name: auth_mount_point [12023,12039]
===
match
---
name: self [9361,9365]
name: self [9361,9365]
===
match
---
if_stmt [6497,6686]
if_stmt [6497,6686]
===
match
---
atom_expr [12876,12887]
atom_expr [12876,12887]
===
match
---
operator: = [5395,5396]
operator: = [5395,5396]
===
match
---
trailer [5713,5718]
trailer [5713,5718]
===
match
---
name: azure_tenant_id [8769,8784]
name: azure_tenant_id [8769,8784]
===
match
---
suite [12775,12840]
suite [12775,12840]
===
match
---
string: "data" [15893,15899]
string: "data" [15905,15911]
===
match
---
comparison [9878,9903]
comparison [9878,9903]
===
match
---
name: auth_type [9407,9416]
name: auth_type [9407,9416]
===
match
---
suite [10940,11086]
suite [10940,11086]
===
match
---
trailer [5508,5513]
trailer [5508,5513]
===
match
---
operator: = [8655,8656]
operator: = [8655,8656]
===
match
---
operator: , [16884,16885]
operator: , [16896,16897]
===
match
---
argument [13651,13676]
argument [13651,13676]
===
match
---
suite [9428,9467]
suite [9428,9467]
===
match
---
trailer [20102,20126]
trailer [20114,20138]
===
match
---
expr_stmt [14427,14453]
expr_stmt [14439,14465]
===
match
---
operator: , [13066,13067]
operator: , [13066,13067]
===
match
---
fstring [6581,6629]
fstring [6581,6629]
===
match
---
operator: = [10843,10844]
operator: = [10843,10844]
===
match
---
atom_expr [9517,9540]
atom_expr [9517,9540]
===
match
---
name: path [15442,15446]
name: path [15454,15458]
===
match
---
name: token [8235,8240]
name: token [8235,8240]
===
match
---
operator: , [6007,6008]
operator: , [6007,6008]
===
match
---
trailer [11835,11852]
trailer [11835,11852]
===
match
---
name: str [14493,14496]
name: str [14505,14508]
===
match
---
name: Optional [6076,6084]
name: Optional [6076,6084]
===
match
---
comparison [9554,9580]
comparison [9554,9580]
===
match
---
simple_stmt [8440,8461]
simple_stmt [8440,8461]
===
match
---
simple_stmt [14563,15160]
simple_stmt [14575,15172]
===
match
---
name: log [18086,18089]
name: log [18098,18101]
===
match
---
name: radius_host [8861,8872]
name: radius_host [8861,8872]
===
match
---
not_test [7810,7825]
not_test [7810,7825]
===
match
---
param [13490,13495]
param [13490,13495]
===
match
---
operator: = [20155,20156]
operator: = [20167,20168]
===
match
---
name: functools [847,856]
name: functools [847,856]
===
match
---
operator: -> [14536,14538]
operator: -> [14548,14550]
===
match
---
trailer [12089,12095]
trailer [12089,12095]
===
match
---
name: self [8856,8860]
name: self [8856,8860]
===
match
---
param [13496,13516]
param [13496,13516]
===
match
---
suite [16060,16928]
suite [16072,16940]
===
match
---
name: username [10427,10435]
name: username [10427,10435]
===
match
---
expr_stmt [8135,8149]
expr_stmt [8135,8149]
===
match
---
atom_expr [19899,19921]
atom_expr [19911,19933]
===
match
---
name: username [11230,11238]
name: username [11230,11238]
===
match
---
name: tenant_id [12990,12999]
name: tenant_id [12990,12999]
===
match
---
expr_stmt [8535,8573]
expr_stmt [8535,8573]
===
match
---
name: secrets [20291,20298]
name: secrets [20303,20310]
===
match
---
arglist [14182,14228]
arglist [14194,14240]
===
match
---
suite [12662,12762]
suite [12662,12762]
===
match
---
trailer [8473,8483]
trailer [8473,8483]
===
match
---
atom_expr [10058,10125]
atom_expr [10058,10125]
===
match
---
trailer [17904,17912]
trailer [17916,17924]
===
match
---
operator: = [20357,20358]
operator: = [20369,20370]
===
match
---
name: self [10566,10570]
name: self [10566,10570]
===
match
---
raise_stmt [7969,8046]
raise_stmt [7969,8046]
===
match
---
operator: = [13621,13622]
operator: = [13621,13622]
===
match
---
string: """         Reads secret metadata (including versions) from the engine. It is only valid for KV version 2.          :param secret_path: The path of the secret.         :type secret_path: str         :rtype: dict         :return: secret metadata. This is a Dict containing metadata for the secret.                   See https://hvac.readthedocs.io/en/stable/usage/secrets_engines/kv_v2.html for details.          """ [16069,16484]
string: """         Reads secret metadata (including versions) from the engine. It is only valid for KV version 2.          :param secret_path: The path of the secret.         :type secret_path: str         :rtype: dict         :return: secret metadata. This is a Dict containing metadata for the secret.                   See https://hvac.readthedocs.io/en/stable/usage/secrets_engines/kv_v2.html for details.          """ [16081,16496]
===
match
---
name: kv_engine_version [6394,6411]
name: kv_engine_version [6394,6411]
===
match
---
name: mount_point [8340,8351]
name: mount_point [8340,8351]
===
match
---
operator: = [9184,9185]
operator: = [9184,9185]
===
match
---
suite [16524,16618]
suite [16536,16630]
===
match
---
name: requests [1005,1013]
name: requests [1005,1013]
===
match
---
name: kv_engine_version [15193,15210]
name: kv_engine_version [15205,15222]
===
match
---
name: self [13881,13885]
name: self [13881,13885]
===
match
---
not_test [7645,7664]
not_test [7645,7664]
===
match
---
name: secret_key [13651,13661]
name: secret_key [13651,13661]
===
match
---
argument [10557,10579]
argument [10557,10579]
===
match
---
name: radius [10723,10729]
name: radius [10723,10729]
===
match
---
name: VaultError [989,999]
name: VaultError [989,999]
===
match
---
atom_expr [10803,10821]
atom_expr [10803,10821]
===
match
---
operator: = [12738,12739]
operator: = [12738,12739]
===
match
---
trailer [13970,13987]
trailer [13970,13987]
===
match
---
number: 1 [15214,15215]
number: 1 [15226,15227]
===
match
---
name: _client [12053,12060]
name: _client [12053,12060]
===
match
---
operator: = [13180,13181]
operator: = [13180,13181]
===
match
---
trailer [14218,14228]
trailer [14230,14240]
===
match
---
atom_expr [8193,8204]
atom_expr [8193,8204]
===
match
---
suite [13988,14135]
suite [13988,14141]
===
match
---
name: kv_engine_version [16501,16518]
name: kv_engine_version [16513,16530]
===
match
---
trailer [15953,15961]
trailer [15965,15973]
===
match
---
not_test [7052,7063]
not_test [7052,7063]
===
match
---
parameters [10290,10318]
parameters [10290,10318]
===
match
---
suite [11527,11628]
suite [11527,11628]
===
match
---
tfpdef [6063,6089]
tfpdef [6063,6089]
===
match
---
name: self [10803,10807]
name: self [10803,10807]
===
match
---
argument [12702,12725]
argument [12702,12725]
===
match
---
name: gcp_key_path [5835,5847]
name: gcp_key_path [5835,5847]
===
match
---
operator: , [10295,10296]
operator: , [10295,10296]
===
match
---
name: hvac [10306,10310]
name: hvac [10306,10310]
===
match
---
trailer [13593,13777]
trailer [13593,13777]
===
match
---
operator: { [10092,10093]
operator: { [10092,10093]
===
match
---
atom_expr [14190,14202]
atom_expr [14202,14214]
===
match
---
trailer [10722,10729]
trailer [10722,10729]
===
match
---
name: username [10413,10421]
name: username [10413,10421]
===
match
---
name: self [11831,11835]
name: self [11831,11835]
===
match
---
name: secret_path [16873,16884]
name: secret_path [16885,16896]
===
match
---
atom_expr [5578,5591]
atom_expr [5578,5591]
===
match
---
comp_op [6510,6516]
comp_op [6510,6516]
===
match
---
trailer [16829,16903]
trailer [16841,16915]
===
match
---
trailer [9406,9416]
trailer [9406,9416]
===
match
---
operator: = [16718,16719]
operator: = [16730,16731]
===
match
---
tfpdef [13924,13944]
tfpdef [13924,13944]
===
match
---
name: token [12184,12189]
name: token [12184,12189]
===
match
---
arglist [10413,10494]
arglist [10413,10494]
===
match
---
trailer [11911,11947]
trailer [11911,11947]
===
match
---
trailer [6172,6177]
trailer [6172,6177]
===
match
---
simple_stmt [1173,1203]
simple_stmt [1173,1203]
===
match
---
string: "The 'azure' authentication type requires 'azure_resource'" [7569,7628]
string: "The 'azure' authentication type requires 'azure_resource'" [7569,7628]
===
match
---
atom_expr [9279,9306]
atom_expr [9279,9306]
===
match
---
tfpdef [5649,5671]
tfpdef [5649,5671]
===
match
---
name: gcp_scopes [8745,8755]
name: gcp_scopes [8745,8755]
===
match
---
operator: , [1414,1415]
operator: , [1414,1415]
===
match
---
trailer [10960,10965]
trailer [10960,10965]
===
match
---
name: kv [20097,20099]
name: kv [20109,20111]
===
match
---
name: self [20398,20402]
name: self [20410,20414]
===
match
---
name: kubernetes_role [8558,8573]
name: kubernetes_role [8558,8573]
===
match
---
operator: , [13847,13848]
operator: , [13847,13848]
===
match
---
tfpdef [18370,18382]
tfpdef [18382,18394]
===
match
---
simple_stmt [20268,20438]
simple_stmt [20280,20450]
===
match
---
arglist [15619,15689]
arglist [15631,15701]
===
match
---
simple_stmt [7843,7919]
simple_stmt [7843,7919]
===
match
---
atom_expr [12739,12760]
atom_expr [12739,12760]
===
match
---
name: auth_mount_point [12914,12930]
name: auth_mount_point [12914,12930]
===
match
---
tfpdef [5490,5513]
tfpdef [5490,5513]
===
match
---
string: "Secret not found %s with mount point %s" [16830,16871]
string: "Secret not found %s with mount point %s" [16842,16883]
===
match
---
suite [15735,15861]
suite [15747,15873]
===
match
---
operator: , [13922,13923]
operator: , [13922,13923]
===
match
---
name: secret_id [13865,13874]
name: secret_id [13865,13874]
===
match
---
operator: = [8308,8309]
operator: = [8308,8309]
===
match
---
name: secret_version [18250,18264]
name: secret_version [18262,18276]
===
match
---
fstring_expr [6393,6412]
fstring_expr [6393,6412]
===
match
---
name: username [11244,11252]
name: username [11244,11252]
===
match
---
atom_expr [11759,11853]
atom_expr [11759,11853]
===
match
---
argument [11000,11021]
argument [11000,11021]
===
match
---
name: self [9760,9764]
name: self [9760,9764]
===
match
---
funcdef [12207,12840]
funcdef [12207,12840]
===
match
---
name: auth_mount_point [8310,8326]
name: auth_mount_point [8310,8326]
===
match
---
name: create_or_update_secret [18313,18336]
name: create_or_update_secret [18325,18348]
===
match
---
name: _client [11976,11983]
name: _client [11976,11983]
===
match
---
name: resource [13038,13046]
name: resource [13038,13046]
===
match
---
trailer [6226,6235]
trailer [6226,6235]
===
match
---
trailer [12060,12065]
trailer [12060,12065]
===
match
---
name: secret_id [13142,13151]
name: secret_id [13142,13151]
===
match
---
name: _client [13244,13251]
name: _client [13244,13251]
===
match
---
name: _client [13924,13931]
name: _client [13924,13931]
===
match
---
name: secret [11023,11029]
name: secret [11023,11029]
===
match
---
name: self [19767,19771]
name: self [19779,19783]
===
match
---
name: v1 [15406,15408]
name: v1 [15418,15420]
===
match
---
name: self [8335,8339]
name: self [8335,8339]
===
match
---
trailer [9699,9708]
trailer [9699,9708]
===
match
---
trailer [8060,8078]
trailer [8060,8078]
===
match
---
operator: -> [11998,12000]
operator: -> [11998,12000]
===
match
---
fstring_end: " [6414,6415]
fstring_end: " [6414,6415]
===
match
---
name: str [18401,18404]
name: str [18413,18416]
===
match
---
trailer [11895,11911]
trailer [11895,11911]
===
match
---
trailer [18085,18089]
trailer [18097,18101]
===
match
---
number: 1 [16522,16523]
number: 1 [16534,16535]
===
match
---
trailer [15556,15563]
trailer [15568,15575]
===
match
---
comparison [19899,19926]
comparison [19911,19938]
===
match
---
fstring_expr [6454,6473]
fstring_expr [6454,6473]
===
match
---
funcdef [13472,13895]
funcdef [13472,13895]
===
match
---
name: self [12861,12865]
name: self [12861,12865]
===
match
---
name: _client [12944,12951]
name: _client [12944,12951]
===
match
---
argument [17956,17972]
argument [17968,17984]
===
match
---
import_as_names [976,999]
import_as_names [976,999]
===
match
---
operator: = [20277,20278]
operator: = [20289,20290]
===
match
---
string: "github" [9572,9580]
string: "github" [9572,9580]
===
match
---
name: Optional [5460,5468]
name: Optional [5460,5468]
===
match
---
parameters [14249,14277]
parameters [14261,14289]
===
match
---
tfpdef [11976,11996]
tfpdef [11976,11996]
===
match
---
name: Optional [17016,17024]
name: Optional [17028,17036]
===
match
---
name: secret_id [13667,13676]
name: secret_id [13667,13676]
===
match
---
name: client [20082,20088]
name: client [20094,20100]
===
match
---
atom_expr [9554,9568]
atom_expr [9554,9568]
===
match
---
param [12227,12247]
param [12227,12247]
===
match
---
operator: , [10435,10436]
operator: , [10435,10436]
===
match
---
atom_expr [9798,9812]
atom_expr [9798,9812]
===
match
---
param [5735,5826]
param [5735,5826]
===
match
---
trailer [12177,12183]
trailer [12177,12183]
===
match
---
string: 'azure' [1309,1316]
string: 'azure' [1309,1316]
===
match
---
name: str [6085,6088]
name: str [6085,6088]
===
match
---
atom_expr [9722,9736]
atom_expr [9722,9736]
===
match
---
return_stmt [18292,18303]
return_stmt [18304,18315]
===
match
---
name: str [5587,5590]
name: str [5587,5590]
===
match
---
name: get_credentials_and_project_id [12497,12527]
name: get_credentials_and_project_id [12497,12527]
===
match
---
name: self [14214,14218]
name: self [14226,14230]
===
match
---
trailer [20029,20047]
trailer [20041,20059]
===
match
---
tfpdef [5208,5226]
tfpdef [5208,5226]
===
match
---
simple_stmt [6219,6238]
simple_stmt [6219,6238]
===
match
---
simple_stmt [16815,16904]
simple_stmt [16827,16916]
===
match
---
simple_stmt [9997,10026]
simple_stmt [9997,10026]
===
match
---
trailer [16654,16661]
trailer [16666,16673]
===
match
---
name: client_secret [13423,13436]
name: client_secret [13423,13436]
===
match
---
name: str [5509,5512]
name: str [5509,5512]
===
match
---
name: azure_resource [8833,8847]
name: azure_resource [8833,8847]
===
match
---
trailer [11921,11937]
trailer [11921,11937]
===
match
---
suite [15524,15708]
suite [15536,15720]
===
match
---
trailer [13626,13633]
trailer [13626,13633]
===
match
---
argument [11376,11398]
argument [11376,11398]
===
match
---
name: token_path [14342,14352]
name: token_path [14354,14364]
===
match
---
name: self [9202,9206]
name: self [9202,9206]
===
match
---
trailer [9521,9531]
trailer [9521,9531]
===
match
---
operator: = [15446,15447]
operator: = [15458,15459]
===
match
---
name: self [16976,16980]
name: self [16988,16992]
===
match
---
trailer [9531,9540]
trailer [9531,9540]
===
match
---
name: auth_type [8163,8172]
name: auth_type [8163,8172]
===
match
---
funcdef [10272,10605]
funcdef [10272,10605]
===
match
---
simple_stmt [1243,1418]
simple_stmt [1243,1418]
===
match
---
dotted_name [12271,12328]
dotted_name [12271,12328]
===
match
---
raise_stmt [16537,16617]
raise_stmt [16549,16629]
===
match
---
name: Client [12881,12887]
name: Client [12881,12887]
===
match
---
name: token_path [6904,6914]
name: token_path [6904,6914]
===
match
---
atom_expr [9202,9210]
atom_expr [9202,9210]
===
match
---
name: self [9006,9010]
name: self [9006,9010]
===
match
---
trailer [11196,11201]
trailer [11196,11201]
===
match
---
operator: = [8517,8518]
operator: = [8517,8518]
===
match
---
name: _client [9933,9940]
name: _client [9933,9940]
===
match
---
operator: , [11808,11809]
operator: , [11808,11809]
===
match
---
name: radius_port [8943,8954]
name: radius_port [8943,8954]
===
match
---
name: List [1224,1228]
name: List [1224,1228]
===
match
---
name: self [10093,10097]
name: self [10093,10097]
===
match
---
operator: = [14213,14214]
operator: = [14225,14226]
===
match
---
operator: = [12495,12496]
operator: = [12495,12496]
===
match
---
trailer [8444,8451]
trailer [8444,8451]
===
match
---
import_from [785,818]
import_from [785,818]
===
match
---
trailer [12956,12962]
trailer [12956,12962]
===
match
---
param [6063,6097]
param [6063,6097]
===
match
---
param [18370,18383]
param [18382,18395]
===
match
---
operator: , [18002,18003]
operator: , [18014,18015]
===
match
---
name: _client [14161,14168]
name: _client [14167,14174]
===
match
---
operator: = [5719,5720]
operator: = [5719,5720]
===
match
---
return_stmt [16643,16774]
return_stmt [16655,16786]
===
match
---
atom_expr [7386,7467]
atom_expr [7386,7467]
===
match
---
if_stmt [11151,11424]
if_stmt [11151,11424]
===
match
---
atom_expr [9838,9864]
atom_expr [9838,9864]
===
match
---
operator: , [5401,5402]
operator: , [5401,5402]
===
match
---
name: token [8227,8232]
name: token [8227,8232]
===
match
---
trailer [19771,19789]
trailer [19783,19801]
===
match
---
string: "The 'kubernetes' authentication type requires 'kubernetes_jwt_path'" [7397,7466]
string: "The 'kubernetes' authentication type requires 'kubernetes_jwt_path'" [7397,7466]
===
match
---
suite [7535,7630]
suite [7535,7630]
===
match
---
simple_stmt [1205,1243]
simple_stmt [1205,1243]
===
match
---
name: secret_id [14076,14085]
name: secret_id [14082,14091]
===
match
---
param [5970,6008]
param [5970,6008]
===
match
---
suite [6534,6686]
suite [6534,6686]
===
match
---
atom_expr [6934,7013]
atom_expr [6934,7013]
===
match
---
operator: == [7035,7037]
operator: == [7035,7037]
===
match
---
atom_expr [14337,14352]
atom_expr [14349,14364]
===
match
---
tfpdef [5928,5953]
tfpdef [5928,5953]
===
match
---
simple_stmt [10178,10193]
simple_stmt [10178,10193]
===
match
---
name: hvac [11121,11125]
name: hvac [11121,11125]
===
match
---
name: key_path [12541,12549]
name: key_path [12541,12549]
===
match
---
name: secret_path [14480,14491]
name: secret_path [14492,14503]
===
match
---
atom_expr [13699,13711]
atom_expr [13699,13711]
===
match
---
arglist [16714,16760]
arglist [16726,16772]
===
match
---
atom_expr [11290,11311]
atom_expr [11290,11311]
===
match
---
operator: , [18368,18369]
operator: , [18380,18381]
===
match
---
operator: = [8556,8557]
operator: = [8556,8557]
===
match
---
operator: == [7489,7491]
operator: == [7489,7491]
===
match
---
if_stmt [19764,19888]
if_stmt [19776,19900]
===
match
---
string: '/var/run/secrets/kubernetes.io/serviceaccount/token' [1119,1172]
string: '/var/run/secrets/kubernetes.io/serviceaccount/token' [1119,1172]
===
match
---
expr_stmt [15372,15506]
expr_stmt [15384,15518]
===
match
---
trailer [20304,20328]
trailer [20316,20340]
===
match
---
name: role_id [5649,5656]
name: role_id [5649,5656]
===
match
---
name: secret_path [17961,17972]
name: secret_path [17973,17984]
===
match
---
name: self [11055,11059]
name: self [11055,11059]
===
match
---
name: _client [11189,11196]
name: _client [11189,11196]
===
match
---
argument [10581,10603]
argument [10581,10603]
===
match
---
trailer [20290,20298]
trailer [20302,20310]
===
match
---
suite [7794,8047]
suite [7794,8047]
===
match
---
name: Optional [5940,5948]
name: Optional [5940,5948]
===
match
---
name: _client [14427,14434]
name: _client [14439,14446]
===
match
---
name: mount_point [17991,18002]
name: mount_point [18003,18014]
===
match
---
name: self [20196,20200]
name: self [20208,20212]
===
match
---
name: self [9238,9242]
name: self [9238,9242]
===
match
---
name: v2 [15575,15577]
name: v2 [15587,15589]
===
match
---
operator: , [11048,11049]
operator: , [11048,11049]
===
match
---
string: "The 'azure' authentication type requires 'azure_tenant_id'" [7699,7759]
string: "The 'azure' authentication type requires 'azure_tenant_id'" [7699,7759]
===
match
---
param [6194,6203]
param [6194,6203]
===
match
---
simple_stmt [1031,1088]
simple_stmt [1031,1088]
===
match
---
operator: = [11942,11943]
operator: = [11942,11943]
===
match
---
suite [7187,7468]
suite [7187,7468]
===
match
---
expr_stmt [9176,9226]
expr_stmt [9176,9226]
===
match
---
operator: , [17972,17973]
operator: , [17984,17985]
===
match
---
trailer [5548,5553]
trailer [5548,5553]
===
match
---
trailer [20283,20290]
trailer [20295,20302]
===
match
---
name: VaultError [11546,11556]
name: VaultError [11546,11556]
===
match
---
operator: == [19922,19924]
operator: == [19934,19936]
===
match
---
trailer [11206,11212]
trailer [11206,11212]
===
match
---
fstring_string: ' not supported [10108,10123]
fstring_string: ' not supported [10108,10123]
===
match
---
name: cas [20420,20423]
name: cas [20432,20435]
===
match
---
name: self [15649,15653]
name: self [15661,15665]
===
match
---
trailer [11294,11311]
trailer [11294,11311]
===
match
---
simple_stmt [820,832]
simple_stmt [820,832]
===
match
---
operator: == [9649,9651]
operator: == [9649,9651]
===
match
---
operator: , [1359,1360]
operator: , [1359,1360]
===
match
---
name: str [5628,5631]
name: str [5628,5631]
===
match
---
atom_expr [6164,6177]
atom_expr [6164,6177]
===
match
---
simple_stmt [12788,12840]
simple_stmt [12788,12840]
===
match
---
atom_expr [9678,9708]
atom_expr [9678,9708]
===
match
---
operator: = [8607,8608]
operator: = [8607,8608]
===
match
---
name: auth_kubernetes [11767,11782]
name: auth_kubernetes [11767,11782]
===
match
---
name: _auth_userpass [10002,10016]
name: _auth_userpass [10002,10016]
===
match
---
name: _auth_gcp [9522,9531]
name: _auth_gcp [9522,9531]
===
match
---
operator: = [5633,5634]
operator: = [5633,5634]
===
match
---
param [11106,11111]
param [11106,11111]
===
match
---
name: _auth_radius [10614,10626]
name: _auth_radius [10614,10626]
===
match
---
trailer [12194,12200]
trailer [12194,12200]
===
match
---
suite [19806,19888]
suite [19818,19900]
===
match
---
operator: = [13740,13741]
operator: = [13740,13741]
===
match
---
argument [20346,20369]
argument [20358,20381]
===
match
---
string: 'aws_iam' [9338,9347]
string: 'aws_iam' [9338,9347]
===
match
---
atom_expr [9594,9620]
atom_expr [9594,9620]
===
match
---
suite [10663,11086]
suite [10663,11086]
===
match
---
name: hvac [827,831]
name: hvac [827,831]
===
match
---
name: self [11450,11454]
name: self [11450,11454]
===
match
---
trailer [11034,11048]
trailer [11034,11048]
===
match
---
string: 'token' [5260,5267]
string: 'token' [5260,5267]
===
match
---
operator: = [12713,12714]
operator: = [12713,12714]
===
match
---
atom_expr [13741,13762]
atom_expr [13741,13762]
===
match
---
operator: , [11252,11253]
operator: , [11252,11253]
===
match
---
arglist [13611,13763]
arglist [13611,13763]
===
match
---
suite [10165,10193]
suite [10165,10193]
===
match
---
trailer [20099,20102]
trailer [20111,20114]
===
match
---
name: kubernetes_jwt_path [11507,11526]
name: kubernetes_jwt_path [11507,11526]
===
match
---
return_stmt [16916,16927]
return_stmt [16928,16939]
===
match
---
operator: , [16730,16731]
operator: , [16742,16743]
===
match
---
name: mount_point [16891,16902]
name: mount_point [16903,16914]
===
match
---
name: self [12190,12194]
name: self [12190,12194]
===
match
---
name: str [6130,6133]
name: str [6130,6133]
===
match
---
name: secret_path [15624,15635]
name: secret_path [15636,15647]
===
match
---
string: "token" [9896,9903]
string: "token" [9896,9903]
===
match
---
trailer [5303,5308]
trailer [5303,5308]
===
match
---
name: self [15819,15823]
name: self [15831,15835]
===
match
---
trailer [5666,5671]
trailer [5666,5671]
===
match
---
operator: , [13676,13677]
operator: , [13676,13677]
===
match
---
arglist [12990,13203]
arglist [12990,13203]
===
match
---
operator: = [15648,15649]
operator: = [15660,15661]
===
match
---
expr_stmt [1173,1202]
expr_stmt [1173,1202]
===
match
---
simple_stmt [9760,9785]
simple_stmt [9760,9785]
===
match
---
operator: -> [11478,11480]
operator: -> [11478,11480]
===
match
---
name: login [11207,11212]
name: login [11207,11212]
===
match
---
name: scopes [12434,12440]
name: scopes [12434,12440]
===
match
---
not_test [6722,6731]
not_test [6722,6731]
===
match
---
operator: -> [10655,10657]
operator: -> [10655,10657]
===
match
---
atom_expr [18392,18405]
atom_expr [18404,18417]
===
match
---
if_stmt [7513,7630]
if_stmt [7513,7630]
===
match
---
name: password [11414,11422]
name: password [11414,11422]
===
match
---
argument [11819,11852]
argument [11819,11852]
===
match
---
name: v1 [20100,20102]
name: v1 [20112,20114]
===
match
---
simple_stmt [15272,15356]
simple_stmt [15284,15368]
===
match
---
name: Client [9020,9026]
name: Client [9020,9026]
===
match
---
name: auth_approle [14009,14021]
name: approle [14014,14021]
===
match
---
trailer [11782,11853]
trailer [11782,11853]
===
match
---
suite [837,880]
suite [837,880]
===
match
---
trailer [13256,13262]
trailer [13256,13262]
===
match
---
name: str [18365,18368]
name: str [18377,18380]
===
match
---
trailer [10965,10972]
trailer [10965,10972]
===
match
---
name: kwargs [6196,6202]
name: kwargs [6196,6202]
===
match
---
name: azure [12957,12962]
name: azure [12957,12962]
===
match
---
suite [12145,12202]
suite [12145,12202]
===
match
---
param [16024,16040]
param [16036,16052]
===
match
---
atom_expr [9186,9226]
atom_expr [9186,9226]
===
match
---
name: url [8146,8149]
name: url [8146,8149]
===
match
---
if_stmt [6857,7014]
if_stmt [6857,7014]
===
match
---
name: Client [13510,13516]
name: Client [13510,13516]
===
match
---
name: self [15904,15908]
name: self [15916,15920]
===
match
---
name: _client [9458,9465]
name: _client [9458,9465]
===
match
---
trailer [15402,15405]
trailer [15414,15417]
===
match
---
tfpdef [13496,13516]
tfpdef [13496,13516]
===
match
---
fstring_start: f" [6581,6583]
fstring_start: f" [6581,6583]
===
match
---
atom_expr [17893,18040]
atom_expr [17905,18052]
===
match
---
and_test [19767,19805]
and_test [19779,19817]
===
match
---
operator: } [6669,6670]
operator: } [6669,6670]
===
match
---
name: auth_mount_point [11159,11175]
name: auth_mount_point [11159,11175]
===
match
---
atom_expr [14427,14440]
atom_expr [14439,14452]
===
match
---
name: _client [14376,14383]
name: _client [14388,14395]
===
match
---
argument [14204,14228]
argument [14216,14240]
===
match
---
trailer [12072,12078]
trailer [12072,12078]
===
insert-node
---
name: _VaultClient [1426,1438]
to
classdef [1420,20462]
at 0
===
insert-node
---
name: LoggingMixin [1439,1451]
to
classdef [1420,20462]
at 1
===
insert-tree
---
simple_stmt [1506,5129]
    string: """     Retrieves Authenticated client from Hashicorp Vault. This is purely internal class promoting     authentication code reuse between the Hook and the SecretBackend, it should not be used directly in     Airflow DAGs. Use VaultBackend for backend integration and Hook in case you want to communicate     with VaultHook using standard Airflow Connection definition.      :param url: Base URL for the Vault instance being addressed.     :type url: str     :param auth_type: Authentication Type for Vault. Default is ``token``. Available values are in         ('approle', 'aws_iam', 'azure', 'github', 'gcp', 'kubernetes', 'ldap', 'radius', 'token', 'userpass')     :type auth_type: str     :param auth_mount_point: It can be used to define mount_point for authentication chosen           Default depends on the authentication method used.     :type auth_mount_point: str     :param mount_point: The "path" the secret engine was mounted on. Default is "secret". Note that          this mount_point is not used for authentication if authentication is done via a          different engine. For authentication mount_points see, auth_mount_point.     :type mount_point: str     :param kv_engine_version: Selects the version of the engine to run (``1`` or ``2``, default: ``2``).     :type kv_engine_version: int     :param token: Authentication token to include in requests sent to Vault         (for ``token`` and ``github`` auth_type).     :type token: str     :param token_path: path to file containing authentication token to include in requests sent to Vault         (for ``token`` and ``github`` auth_type).     :type token_path: str     :param username: Username for Authentication (for ``ldap`` and ``userpass`` auth_types).     :type username: str     :param password: Password for Authentication (for ``ldap`` and ``userpass`` auth_types).     :type password: str     :param key_id: Key ID for Authentication (for ``aws_iam`` and ''azure`` auth_type).     :type  key_id: str     :param secret_id: Secret ID for Authentication (for ``approle``, ``aws_iam`` and ``azure`` auth_types).     :type secret_id: str     :param role_id: Role ID for Authentication (for ``approle``, ``aws_iam`` auth_types).     :type role_id: str     :param kubernetes_role: Role for Authentication (for ``kubernetes`` auth_type).     :type kubernetes_role: str     :param kubernetes_jwt_path: Path for kubernetes jwt token (for ``kubernetes`` auth_type, default:         ``/var/run/secrets/kubernetes.io/serviceaccount/token``).     :type kubernetes_jwt_path: str     :param gcp_key_path: Path to Google Cloud Service Account key file (JSON)  (for ``gcp`` auth_type).            Mutually exclusive with gcp_keyfile_dict     :type gcp_key_path: str     :param gcp_keyfile_dict: Dictionary of keyfile parameters. (for ``gcp`` auth_type).            Mutually exclusive with gcp_key_path     :type gcp_keyfile_dict: dict     :param gcp_scopes: Comma-separated string containing OAuth2 scopes (for ``gcp`` auth_type).     :type gcp_scopes: str     :param azure_tenant_id: The tenant id for the Azure Active Directory (for ``azure`` auth_type).     :type azure_tenant_id: str     :param azure_resource: The configured URL for the application registered in Azure Active Directory            (for ``azure`` auth_type).     :type azure_resource: str     :param radius_host: Host for radius (for ``radius`` auth_type).     :type radius_host: str     :param radius_secret: Secret for radius (for ``radius`` auth_type).     :type radius_secret: str     :param radius_port: Port for radius (for ``radius`` auth_type).     :type radius_port: int     """ [1506,5128]
to
suite [1501,20462]
at 0
===
insert-tree
---
trailer [14008,14013]
    name: auth [14009,14013]
to
atom_expr [14001,14134]
at 1
===
insert-tree
---
trailer [14021,14027]
    name: login [14022,14027]
to
atom_expr [14001,14134]
at 3
===
insert-tree
---
trailer [14174,14179]
    name: auth [14175,14179]
to
atom_expr [14161,14229]
at 1
===
insert-tree
---
trailer [14187,14193]
    name: login [14188,14193]
to
atom_expr [14161,14229]
at 3
===
update-node
---
name: auth_approle [14009,14021]
replace auth_approle by approle
===
update-node
---
name: auth_approle [14169,14181]
replace auth_approle by approle
===
delete-node
---
name: _VaultClient [1426,1438]
===
===
delete-node
---
name: LoggingMixin [1439,1451]
===
===
delete-tree
---
simple_stmt [1506,5129]
    string: """     Retrieves Authenticated client from Hashicorp Vault. This is purely internal class promoting     authentication code reuse between the Hook and the SecretBackend, it should not be used directly in     Airflow DAGs. Use VaultBackend for backend integration and Hook in case you want to communicate     with VaultHook using standard Airflow Connection definition.      :param url: Base URL for the Vault instance being addressed.     :type url: str     :param auth_type: Authentication Type for Vault. Default is ``token``. Available values are in         ('approle', 'aws_iam', 'azure', 'github', 'gcp', 'kubernetes', 'ldap', 'radius', 'token', 'userpass')     :type auth_type: str     :param auth_mount_point: It can be used to define mount_point for authentication chosen           Default depends on the authentication method used.     :type auth_mount_point: str     :param mount_point: The "path" the secret engine was mounted on. Default is "secret". Note that          this mount_point is not used for authentication if authentication is done via a          different engine. For authentication mount_points see, auth_mount_point.     :type mount_point: str     :param kv_engine_version: Selects the version of the engine to run (``1`` or ``2``, default: ``2``).     :type kv_engine_version: int     :param token: Authentication token to include in requests sent to Vault         (for ``token`` and ``github`` auth_type).     :type token: str     :param token_path: path to file containing authentication token to include in requests sent to Vault         (for ``token`` and ``github`` auth_type).     :type token_path: str     :param username: Username for Authentication (for ``ldap`` and ``userpass`` auth_types).     :type username: str     :param password: Password for Authentication (for ``ldap`` and ``userpass`` auth_types).     :type password: str     :param key_id: Key ID for Authentication (for ``aws_iam`` and ''azure`` auth_type).     :type  key_id: str     :param secret_id: Secret ID for Authentication (for ``approle``, ``aws_iam`` and ``azure`` auth_types).     :type secret_id: str     :param role_id: Role ID for Authentication (for ``approle``, ``aws_iam`` auth_types).     :type role_id: str     :param kubernetes_role: Role for Authentication (for ``kubernetes`` auth_type).     :type kubernetes_role: str     :param kubernetes_jwt_path: Path for kubernetes jwt token (for ``kubernetes`` auth_type, default:         ``/var/run/secrets/kubernetes.io/serviceaccount/token``).     :type kubernetes_jwt_path: str     :param gcp_key_path: Path to Google Cloud Service Account key file (JSON)  (for ``gcp`` auth_type).            Mutually exclusive with gcp_keyfile_dict     :type gcp_key_path: str     :param gcp_keyfile_dict: Dictionary of keyfile parameters. (for ``gcp`` auth_type).            Mutually exclusive with gcp_key_path     :type gcp_keyfile_dict: dict     :param gcp_scopes: Comma-separated string containing OAuth2 scopes (for ``gcp`` auth_type).     :type gcp_scopes: str     :param azure_tenant_id: The tenant id for the Azure Active Directory (for ``azure`` auth_type).     :type azure_tenant_id: str     :param azure_resource: The configured URL for the application registered in Azure Active Directory            (for ``azure`` auth_type).     :type azure_resource: str     :param radius_host: Host for radius (for ``radius`` auth_type).     :type radius_host: str     :param radius_secret: Secret for radius (for ``radius`` auth_type).     :type radius_secret: str     :param radius_port: Port for radius (for ``radius`` auth_type).     :type radius_port: int     """ [1506,5128]
