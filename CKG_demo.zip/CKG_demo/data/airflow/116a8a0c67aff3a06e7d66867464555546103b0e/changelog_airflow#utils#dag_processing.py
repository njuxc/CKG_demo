===
match
---
atom_expr [4611,4632]
atom_expr [4611,4632]
===
match
---
name: file_path [38710,38719]
name: file_path [38832,38841]
===
match
---
trailer [20023,20030]
trailer [20145,20152]
===
match
---
return_stmt [36965,37011]
return_stmt [37087,37133]
===
match
---
string: 'scheduler' [20082,20093]
string: 'scheduler' [20204,20215]
===
match
---
name: self [32913,32917]
name: self [33035,33039]
===
match
---
suite [40713,41696]
suite [40835,41818]
===
match
---
trailer [47707,47714]
trailer [47829,47836]
===
match
---
name: get [20144,20147]
name: get [20266,20269]
===
match
---
name: provide_session [44838,44853]
name: provide_session [44960,44975]
===
match
---
atom_expr [48781,48794]
atom_expr [48903,48916]
===
match
---
operator: = [28755,28756]
operator: = [28877,28878]
===
match
---
trailer [30429,30459]
trailer [30551,30581]
===
match
---
trailer [33511,33517]
trailer [33633,33639]
===
match
---
trailer [9346,9370]
trailer [9346,9370]
===
match
---
name: _parent_signal_conn [8176,8195]
name: _parent_signal_conn [8176,8195]
===
match
---
name: List [19221,19225]
name: List [19343,19347]
===
match
---
name: debug [44399,44404]
name: debug [44521,44526]
===
match
---
not_test [27023,27043]
not_test [27145,27165]
===
match
---
atom_expr [11940,11961]
atom_expr [12062,12083]
===
match
---
simple_stmt [11118,11123]
simple_stmt [11118,11123]
===
match
---
arglist [48868,48961]
arglist [48990,49083]
===
match
---
suite [40196,40222]
suite [40318,40344]
===
match
---
name: _processors [35359,35370]
name: _processors [35481,35492]
===
match
---
suite [25442,25521]
suite [25564,25643]
===
match
---
atom_expr [25499,25517]
atom_expr [25621,25639]
===
match
---
trailer [38376,38382]
trailer [38498,38504]
===
match
---
name: TYPE_CHECKING [1203,1216]
name: TYPE_CHECKING [1203,1216]
===
match
---
simple_stmt [44193,44381]
simple_stmt [44315,44503]
===
match
---
name: dag_id [45853,45859]
name: dag_id [45975,45981]
===
match
---
atom_expr [26163,26180]
atom_expr [26285,26302]
===
match
---
string: "Exiting dag parsing loop as all files have been processed %s times" [28566,28634]
string: "Exiting dag parsing loop as all files have been processed %s times" [28688,28756]
===
match
---
name: self [34763,34767]
name: self [34885,34889]
===
match
---
name: time [48628,48632]
name: time [48750,48754]
===
match
---
operator: = [42272,42273]
operator: = [42394,42395]
===
match
---
name: models [45505,45511]
name: models [45627,45633]
===
match
---
arglist [8819,8879]
arglist [8819,8879]
===
match
---
name: query [31791,31796]
name: query [31913,31918]
===
match
---
fstring_string: .2f [34206,34209]
fstring_string: .2f [34328,34331]
===
match
---
simple_stmt [45533,45613]
simple_stmt [45655,45735]
===
match
---
trailer [32784,32786]
trailer [32906,32908]
===
match
---
name: tabulate [1394,1402]
name: tabulate [1394,1402]
===
match
---
name: waitables [41647,41656]
name: waitables [41769,41778]
===
match
---
comparison [41036,41072]
comparison [41158,41194]
===
match
---
name: self [26513,26517]
name: self [26635,26639]
===
match
---
expr_stmt [41833,41879]
expr_stmt [41955,42001]
===
match
---
name: processor [47169,47178]
name: processor [47291,47300]
===
match
---
trailer [40931,40934]
trailer [41053,41056]
===
match
---
trailer [23602,23607]
trailer [23724,23729]
===
match
---
name: query [31643,31648]
name: query [31765,31770]
===
match
---
trailer [18912,18975]
trailer [19034,19097]
===
match
---
trailer [24633,24638]
trailer [24755,24760]
===
match
---
simple_stmt [30049,30113]
simple_stmt [30171,30235]
===
match
---
name: files_paths_at_run_limit [43762,43786]
name: files_paths_at_run_limit [43884,43908]
===
match
---
name: _processors [40838,40849]
name: _processors [40960,40971]
===
match
---
simple_stmt [46267,46471]
simple_stmt [46389,46593]
===
match
---
trailer [40182,40195]
trailer [40304,40317]
===
match
---
name: filtered_processors [38446,38465]
name: filtered_processors [38568,38587]
===
match
---
name: self [26458,26462]
name: self [26580,26584]
===
match
---
atom_expr [34062,34480]
atom_expr [34184,34602]
===
match
---
simple_stmt [45368,45435]
simple_stmt [45490,45557]
===
match
---
trailer [22574,22582]
trailer [22696,22704]
===
match
---
funcdef [3146,3391]
funcdef [3146,3391]
===
match
---
name: num_dags [39527,39535]
name: num_dags [39649,39657]
===
match
---
name: self [7663,7667]
name: self [7663,7667]
===
match
---
name: ValueError [11277,11287]
name: ValueError [11277,11287]
===
match
---
name: get_pid [33172,33179]
name: get_pid [33294,33301]
===
match
---
name: run_count [37798,37807]
name: run_count [37920,37929]
===
match
---
atom_expr [38885,38910]
atom_expr [39007,39032]
===
match
---
name: _processors [41595,41606]
name: _processors [41717,41728]
===
match
---
name: self [19290,19294]
name: self [19412,19416]
===
match
---
trailer [30814,30826]
trailer [30936,30948]
===
match
---
name: start [41461,41466]
name: start [41583,41588]
===
match
---
simple_stmt [48843,48972]
simple_stmt [48965,49094]
===
match
---
atom_expr [41399,41437]
atom_expr [41521,41559]
===
match
---
name: recv [14010,14014]
name: recv [14132,14136]
===
match
---
name: self [42838,42842]
name: self [42960,42964]
===
match
---
name: pid [35148,35151]
name: pid [35270,35273]
===
match
---
operator: = [39675,39676]
operator: = [39797,39798]
===
match
---
expr_stmt [42073,42096]
expr_stmt [42195,42218]
===
match
---
parameters [11845,12180]
parameters [11967,12302]
===
match
---
atom_expr [6703,6724]
atom_expr [6703,6724]
===
match
---
trailer [31337,31347]
trailer [31459,31469]
===
match
---
name: self [8661,8665]
name: self [8661,8665]
===
match
---
name: self [45157,45161]
name: self [45279,45283]
===
match
---
return_stmt [35160,35171]
return_stmt [35282,35293]
===
match
---
simple_stmt [47237,47276]
simple_stmt [47359,47398]
===
match
---
name: join [14837,14841]
name: join [14959,14963]
===
match
---
atom [22329,22390]
atom [22451,22512]
===
match
---
atom_expr [44637,44771]
atom_expr [44759,44893]
===
match
---
suite [4502,4633]
suite [4502,4633]
===
match
---
name: stat [35705,35709]
name: stat [35827,35831]
===
match
---
trailer [16877,16912]
trailer [16999,17034]
===
match
---
name: runtime [33681,33688]
name: runtime [33803,33810]
===
match
---
name: signal [922,928]
name: signal [922,928]
===
match
---
simple_stmt [42339,42374]
simple_stmt [42461,42496]
===
match
---
operator: -> [12181,12183]
operator: -> [12303,12305]
===
match
---
suite [44891,46635]
suite [45013,46757]
===
match
---
atom_expr [3719,3744]
atom_expr [3719,3744]
===
match
---
suite [42416,42945]
suite [42538,43067]
===
match
---
simple_stmt [16147,16198]
simple_stmt [16269,16320]
===
match
---
atom_expr [39740,39760]
atom_expr [39862,39882]
===
match
---
operator: , [40106,40107]
operator: , [40228,40229]
===
match
---
param [16707,16711]
param [16829,16833]
===
match
---
operator: -> [13597,13599]
operator: -> [13719,13721]
===
match
---
simple_stmt [27425,27452]
simple_stmt [27547,27574]
===
match
---
name: _async_mode [25560,25571]
name: _async_mode [25682,25693]
===
match
---
comp_op [44566,44572]
comp_op [44688,44694]
===
match
---
suite [26804,26888]
suite [26926,27010]
===
match
---
name: result [11530,11536]
name: result [11649,11655]
===
match
---
name: abstractmethod [3411,3425]
name: abstractmethod [3411,3425]
===
match
---
string: "Process not started." [13778,13800]
string: "Process not started." [13900,13922]
===
match
---
name: time [24525,24529]
name: time [24647,24651]
===
match
---
trailer [16489,16494]
trailer [16611,16616]
===
match
---
name: processor [38347,38356]
name: processor [38469,38478]
===
match
---
trailer [24260,24262]
trailer [24382,24384]
===
match
---
param [2788,2792]
param [2788,2792]
===
match
---
trailer [22108,22136]
trailer [22230,22258]
===
match
---
atom_expr [37746,37777]
atom_expr [37868,37899]
===
match
---
parameters [3438,3444]
parameters [3438,3444]
===
match
---
name: done [15160,15164]
name: done [15282,15286]
===
match
---
funcdef [31376,31858]
funcdef [31498,31980]
===
match
---
parameters [47901,47907]
parameters [48023,48029]
===
match
---
string: """         Update this with a new set of paths to DAG definition files.          :param new_file_paths: list of paths to DAG definition files         :type new_file_paths: list[unicode]         :return: None         """ [37878,38098]
string: """         Update this with a new set of paths to DAG definition files.          :param new_file_paths: list of paths to DAG definition files         :type new_file_paths: list[unicode]         :return: None         """ [38000,38220]
===
match
---
name: self [16425,16429]
name: self [16547,16551]
===
match
---
string: 'dag_dir_list_interval' [21992,22015]
string: 'dag_dir_list_interval' [22114,22137]
===
match
---
simple_stmt [41090,41099]
simple_stmt [41212,41221]
===
match
---
name: MultiprocessingConnection [1158,1183]
name: MultiprocessingConnection [1158,1183]
===
match
---
suite [24292,24474]
suite [24414,24596]
===
match
---
name: self [8356,8360]
name: self [8356,8360]
===
match
---
name: fileno [20024,20030]
name: fileno [20146,20152]
===
match
---
atom_expr [7828,7844]
atom_expr [7828,7844]
===
match
---
atom_expr [30049,30112]
atom_expr [30171,30234]
===
match
---
operator: , [13501,13502]
operator: , [13623,13624]
===
match
---
trailer [26462,26474]
trailer [26584,26596]
===
match
---
return_stmt [36552,36595]
return_stmt [36674,36717]
===
match
---
name: file_path [39433,39442]
name: file_path [39555,39564]
===
match
---
name: airflow [2166,2173]
name: airflow [2166,2173]
===
match
---
simple_stmt [39490,39515]
simple_stmt [39612,39637]
===
match
---
name: file_path [43561,43570]
name: file_path [43683,43692]
===
match
---
simple_stmt [20546,20630]
simple_stmt [20668,20752]
===
match
---
arith_expr [39721,39760]
arith_expr [39843,39882]
===
match
---
name: self [26163,26167]
name: self [26285,26289]
===
match
---
name: info [34732,34736]
name: info [34854,34858]
===
match
---
name: _file_path_queue [38190,38206]
name: _file_path_queue [38312,38328]
===
match
---
name: Callable [11925,11933]
name: Callable [12047,12055]
===
match
---
suite [39948,40678]
suite [40070,40800]
===
match
---
param [10419,10430]
param [10419,10430]
===
match
---
param [34763,34768]
param [34885,34890]
===
match
---
name: stat [37793,37797]
name: stat [37915,37919]
===
match
---
atom_expr [43075,43095]
atom_expr [43197,43217]
===
match
---
simple_stmt [1389,1419]
simple_stmt [1389,1419]
===
match
---
atom_expr [31167,31192]
atom_expr [31289,31314]
===
match
---
name: max_runs [19351,19359]
name: max_runs [19473,19481]
===
match
---
expr_stmt [37739,37777]
expr_stmt [37861,37899]
===
match
---
trailer [30347,30362]
trailer [30469,30484]
===
match
---
string: "alphabetical" [43137,43151]
string: "alphabetical" [43259,43273]
===
match
---
trailer [48654,48674]
trailer [48776,48796]
===
match
---
name: bool [2622,2626]
name: bool [2622,2626]
===
match
---
trailer [13777,13801]
trailer [13899,13923]
===
match
---
name: collect_results [39918,39933]
name: collect_results [40040,40055]
===
match
---
name: dag_ids [7217,7224]
name: dag_ids [7217,7224]
===
match
---
trailer [46401,46405]
trailer [46523,46527]
===
match
---
name: file_path [43547,43556]
name: file_path [43669,43678]
===
match
---
name: _pickle_dags [7238,7250]
name: _pickle_dags [7238,7250]
===
match
---
string: "Waiting for processors to finish since we're using sqlite" [27076,27135]
string: "Waiting for processors to finish since we're using sqlite" [27198,27257]
===
match
---
simple_stmt [39130,39169]
simple_stmt [39252,39291]
===
match
---
param [6633,6647]
param [6633,6647]
===
match
---
operator: , [12173,12174]
operator: , [12295,12296]
===
match
---
name: Stats [48056,48061]
name: Stats [48178,48183]
===
match
---
name: self [15824,15828]
name: self [15946,15950]
===
match
---
string: '.' [33133,33136]
string: '.' [33255,33258]
===
match
---
atom_expr [47405,47446]
atom_expr [47527,47568]
===
match
---
operator: } [33566,33567]
operator: } [33688,33689]
===
match
---
simple_stmt [41346,41387]
simple_stmt [41468,41509]
===
match
---
simple_stmt [26988,27007]
simple_stmt [27110,27129]
===
match
---
comparison [43210,43246]
comparison [43332,43368]
===
match
---
name: _processors [35125,35136]
name: _processors [35247,35258]
===
match
---
name: _processors [35088,35099]
name: _processors [35210,35221]
===
match
---
atom_expr [30969,30985]
atom_expr [31091,31107]
===
match
---
expr_stmt [33074,33137]
expr_stmt [33196,33259]
===
match
---
operator: , [15527,15528]
operator: , [15649,15650]
===
match
---
factor [31731,31781]
factor [31853,31903]
===
match
---
name: _async_mode [7278,7289]
name: _async_mode [7278,7289]
===
match
---
expr_stmt [20546,20629]
expr_stmt [20668,20751]
===
match
---
name: x [27698,27699]
name: x [27820,27821]
===
match
---
name: stats [1702,1707]
name: stats [1702,1707]
===
match
---
atom_expr [19500,19513]
atom_expr [19622,19635]
===
match
---
name: self [2607,2611]
name: self [2607,2611]
===
match
---
comp_if [38207,38229]
comp_if [38329,38351]
===
match
---
trailer [23806,23926]
trailer [23928,24048]
===
match
---
number: 0 [33114,33115]
number: 0 [33236,33237]
===
match
---
operator: = [39298,39299]
operator: = [39420,39421]
===
match
---
suite [34049,34481]
suite [34171,34603]
===
match
---
operator: < [42836,42837]
operator: < [42958,42959]
===
match
---
del_stmt [13218,13267]
del_stmt [13340,13389]
===
match
---
import_from [1069,1104]
import_from [1069,1104]
===
match
---
name: mp_start_method [7977,7992]
name: mp_start_method [7977,7992]
===
match
---
trailer [38943,38948]
trailer [39065,39070]
===
match
---
simple_stmt [838,853]
simple_stmt [838,853]
===
match
---
name: self [44876,44880]
name: self [44998,45002]
===
match
---
name: enum [816,820]
name: enum [816,820]
===
match
---
decorated [3112,3391]
decorated [3112,3391]
===
match
---
expr_stmt [21236,21253]
expr_stmt [21358,21375]
===
match
---
name: timeout [13928,13935]
name: timeout [14050,14057]
===
match
---
operator: == [25043,25045]
operator: == [25165,25167]
===
match
---
name: processor [39423,39432]
name: processor [39545,39554]
===
match
---
string: """         :param file_path: the path to the file that was processed         :type file_path: unicode         :return: the number of import errors from processing, or None if the file             was never processed.         :rtype: int         """ [36247,36496]
string: """         :param file_path: the path to the file that was processed         :type file_path: unicode         :return: the number of import errors from processing, or None if the file             was never processed.         :rtype: int         """ [36369,36618]
===
match
---
name: airflow [1447,1454]
name: airflow [1447,1454]
===
match
---
name: num_dags [33751,33759]
name: num_dags [33873,33881]
===
match
---
operator: , [41254,41255]
operator: , [41376,41377]
===
match
---
name: property [2935,2943]
name: property [2935,2943]
===
match
---
trailer [15335,15337]
trailer [15457,15459]
===
match
---
name: result [11404,11410]
name: result [11522,11528]
===
match
---
funcdef [15990,16089]
funcdef [16112,16211]
===
match
---
simple_stmt [38812,38860]
simple_stmt [38934,38982]
===
match
---
name: max_runs [18862,18870]
name: max_runs [18984,18992]
===
match
---
name: dag_dir_list_interval [29944,29965]
name: dag_dir_list_interval [30066,30087]
===
match
---
operator: > [45203,45204]
operator: > [45325,45326]
===
match
---
operator: , [15011,15012]
operator: , [15133,15134]
===
match
---
name: file_path [42574,42583]
name: file_path [42696,42705]
===
match
---
suite [42447,42522]
suite [42569,42644]
===
match
---
trailer [23760,23783]
trailer [23882,23905]
===
match
---
atom_expr [29844,29898]
atom_expr [29966,30020]
===
match
---
trailer [29882,29896]
trailer [30004,30018]
===
match
---
expr_stmt [11404,11444]
expr_stmt [11522,11562]
===
match
---
trailer [22347,22360]
trailer [22469,22482]
===
match
---
name: super [19176,19181]
name: super [19298,19303]
===
match
---
operator: , [19013,19014]
operator: , [19135,19136]
===
match
---
arglist [22937,22990]
arglist [23059,23112]
===
match
---
name: start [23225,23230]
name: start [23347,23352]
===
match
---
name: file_path [38401,38410]
name: file_path [38523,38532]
===
match
---
name: runtime [33269,33276]
name: runtime [33391,33398]
===
match
---
name: file_path [42481,42490]
name: file_path [42603,42612]
===
match
---
trailer [10831,10875]
trailer [10831,10875]
===
match
---
name: processor_pid [33727,33740]
name: processor_pid [33849,33862]
===
match
---
name: _heartbeat_manager [14554,14572]
name: _heartbeat_manager [14676,14694]
===
match
---
name: waitable_handle [4480,4495]
name: waitable_handle [4480,4495]
===
match
---
name: _file_paths [31769,31780]
name: _file_paths [31891,31902]
===
match
---
trailer [14014,14016]
trailer [14136,14138]
===
match
---
atom_expr [19221,19230]
atom_expr [19343,19352]
===
match
---
atom_expr [26549,26569]
atom_expr [26671,26691]
===
match
---
name: self [37847,37851]
name: self [37969,37973]
===
match
---
name: get_all_pids [48297,48309]
name: get_all_pids [48419,48431]
===
match
---
fstring_start: f" [34317,34319]
fstring_start: f" [34439,34441]
===
match
---
operator: , [1815,1816]
operator: , [1815,1816]
===
match
---
operator: = [36510,36511]
operator: = [36632,36633]
===
match
---
decorated [4016,4224]
decorated [4016,4224]
===
match
---
operator: = [42674,42675]
operator: = [42796,42797]
===
match
---
comparison [24894,24944]
comparison [25016,25066]
===
match
---
name: self [40859,40863]
name: self [40981,40985]
===
match
---
string: "Stopping processor for %s" [38540,38567]
string: "Stopping processor for %s" [38662,38689]
===
match
---
if_stmt [14865,15143]
if_stmt [14987,15265]
===
match
---
sync_comp_for [48795,48832]
sync_comp_for [48917,48954]
===
match
---
trailer [14915,15113]
trailer [15037,15235]
===
match
---
name: self [20180,20184]
name: self [20302,20306]
===
match
---
name: self [31275,31279]
name: self [31397,31401]
===
match
---
if_stmt [48320,48392]
if_stmt [48442,48514]
===
match
---
comp_op [27682,27688]
comp_op [27804,27810]
===
match
---
comp_op [44079,44085]
comp_op [44201,44207]
===
match
---
trailer [46978,46982]
trailer [47100,47104]
===
match
---
trailer [48908,48922]
trailer [49030,49044]
===
match
---
trailer [14103,14120]
trailer [14225,14242]
===
match
---
simple_stmt [25096,25107]
simple_stmt [25218,25229]
===
match
---
simple_stmt [8937,9256]
simple_stmt [8937,9256]
===
match
---
trailer [13727,13747]
trailer [13849,13869]
===
match
---
param [31008,31012]
param [31130,31134]
===
match
---
name: file_path [38569,38578]
name: file_path [38691,38700]
===
match
---
name: context [8044,8051]
name: context [8044,8051]
===
match
---
name: _dag_directory [30097,30111]
name: _dag_directory [30219,30233]
===
match
---
operator: , [1216,1217]
operator: , [1216,1217]
===
match
---
tfpdef [28976,29000]
tfpdef [29098,29122]
===
match
---
trailer [24970,24980]
trailer [25092,25102]
===
match
---
name: done [3434,3438]
name: done [3434,3438]
===
match
---
simple_stmt [9330,9371]
simple_stmt [9330,9371]
===
match
---
name: NotImplementedError [3085,3104]
name: NotImplementedError [3085,3104]
===
match
---
string: "Runtime" [32675,32684]
string: "Runtime" [32797,32806]
===
match
---
simple_stmt [40722,40795]
simple_stmt [40844,40917]
===
match
---
atom_expr [3638,3659]
atom_expr [3638,3659]
===
match
---
param [23231,23235]
param [23353,23357]
===
match
---
atom_expr [38651,38672]
atom_expr [38773,38794]
===
match
---
trailer [32998,33009]
trailer [33120,33131]
===
match
---
trailer [23138,23142]
trailer [23260,23264]
===
match
---
operator: , [37040,37041]
operator: , [37162,37163]
===
match
---
atom_expr [47237,47275]
atom_expr [47359,47397]
===
match
---
trailer [28544,28668]
trailer [28666,28790]
===
match
---
operator: = [13294,13295]
operator: = [13416,13417]
===
match
---
trailer [26567,26569]
trailer [26689,26691]
===
match
---
name: ImportError [31656,31667]
name: ImportError [31778,31789]
===
match
---
name: file_paths_recently_processed [42339,42368]
name: file_paths_recently_processed [42461,42490]
===
match
---
annassign [19219,19235]
annassign [19341,19357]
===
match
---
atom_expr [23793,23926]
atom_expr [23915,24048]
===
match
---
name: self [23869,23873]
name: self [23991,23995]
===
match
---
name: self [35194,35198]
name: self [35316,35320]
===
match
---
atom_expr [47169,47201]
atom_expr [47291,47323]
===
match
---
param [14258,14265]
param [14380,14387]
===
match
---
trailer [46500,46536]
trailer [46622,46658]
===
match
---
name: send [9482,9486]
name: send [9482,9486]
===
match
---
arith_expr [46880,46906]
arith_expr [47002,47028]
===
match
---
name: log [16866,16869]
name: log [16988,16991]
===
match
---
operator: -> [4283,4285]
operator: -> [4283,4285]
===
match
---
trailer [26244,26254]
trailer [26366,26376]
===
match
---
funcdef [6569,7845]
funcdef [6569,7845]
===
match
---
expr_stmt [24507,24541]
expr_stmt [24629,24663]
===
match
---
trailer [24106,24118]
trailer [24228,24240]
===
match
---
trailer [42566,42573]
trailer [42688,42695]
===
match
---
name: sentinel [26259,26267]
name: sentinel [26381,26389]
===
match
---
name: elapsed_time_since_refresh [29910,29936]
name: elapsed_time_since_refresh [30032,30058]
===
match
---
atom_expr [46886,46906]
atom_expr [47008,47028]
===
match
---
trailer [28403,28407]
trailer [28525,28529]
===
match
---
atom_expr [42897,42944]
atom_expr [43019,43066]
===
match
---
name: request [28976,28983]
name: request [29098,29105]
===
match
---
arith_expr [34513,34703]
arith_expr [34635,34825]
===
match
---
atom_expr [45837,45846]
atom_expr [45959,45968]
===
match
---
name: all [27649,27652]
name: all [27771,27774]
===
match
---
name: file_path [44069,44078]
name: file_path [44191,44200]
===
match
---
name: staticmethod [11802,11814]
name: staticmethod [11924,11936]
===
match
---
parameters [35193,35199]
parameters [35315,35321]
===
match
---
name: file_path [36632,36641]
name: file_path [36754,36763]
===
match
---
trailer [39432,39442]
trailer [39554,39564]
===
match
---
name: self [30640,30644]
name: self [30762,30766]
===
match
---
name: log [14904,14907]
name: log [15026,15029]
===
match
---
atom_expr [33457,33489]
atom_expr [33579,33611]
===
match
---
expr_stmt [33151,33190]
expr_stmt [33273,33312]
===
match
---
name: self [40549,40553]
name: self [40671,40675]
===
match
---
atom_expr [25096,25106]
atom_expr [25218,25228]
===
match
---
arglist [47010,47202]
arglist [47132,47324]
===
match
---
fstring_expr [33667,33678]
fstring_expr [33789,33800]
===
match
---
simple_stmt [14081,14087]
simple_stmt [14203,14209]
===
match
---
operator: == [43220,43222]
operator: == [43342,43344]
===
match
---
name: self [27425,27429]
name: self [27547,27551]
===
match
---
suite [31918,34746]
suite [32040,34868]
===
match
---
atom_expr [39226,39242]
atom_expr [39348,39364]
===
match
---
sync_comp_for [29506,29582]
sync_comp_for [29628,29704]
===
match
---
trailer [24811,24874]
trailer [24933,24996]
===
match
---
operator: - [39738,39739]
operator: - [39860,39861]
===
match
---
name: os [12396,12398]
name: os [12518,12520]
===
match
---
atom_expr [11925,11996]
atom_expr [12047,12118]
===
match
---
name: _parallelism [20451,20463]
name: _parallelism [20573,20585]
===
match
---
name: processor_timeout [7175,7192]
name: processor_timeout [7175,7192]
===
match
---
except_clause [28008,28030]
except_clause [28130,28152]
===
match
---
operator: , [32666,32667]
operator: , [32788,32789]
===
match
---
funcdef [4263,4437]
funcdef [4263,4437]
===
match
---
name: multiprocessing [875,890]
name: multiprocessing [875,890]
===
match
---
name: airflow [1761,1768]
name: airflow [1761,1768]
===
match
---
name: NotImplementedError [4202,4221]
name: NotImplementedError [4202,4221]
===
match
---
name: new_file_paths [38215,38229]
name: new_file_paths [38337,38351]
===
match
---
fstring_string: dag_processing.last_duration. [33638,33667]
fstring_string: dag_processing.last_duration. [33760,33789]
===
match
---
name: log [40601,40604]
name: log [40723,40726]
===
match
---
trailer [46495,46500]
trailer [46617,46622]
===
match
---
operator: , [45751,45752]
operator: , [45873,45874]
===
match
---
simple_stmt [32644,32736]
simple_stmt [32766,32858]
===
match
---
if_stmt [24272,24474]
if_stmt [24394,24596]
===
match
---
atom_expr [30941,30986]
atom_expr [31063,31108]
===
match
---
name: rows [33883,33887]
name: rows [34005,34009]
===
match
---
name: bool [16008,16012]
name: bool [16130,16134]
===
match
---
name: connection [1126,1136]
name: connection [1126,1136]
===
match
---
simple_stmt [42261,42277]
simple_stmt [42383,42399]
===
match
---
name: datetime [21537,21545]
name: datetime [21659,21667]
===
match
---
simple_stmt [36505,36544]
simple_stmt [36627,36666]
===
match
---
suite [11473,11496]
suite [11591,11615]
===
match
---
simple_stmt [26549,26612]
simple_stmt [26671,26734]
===
match
---
name: _file_stats [35717,35728]
name: _file_stats [35839,35850]
===
match
---
for_stmt [38332,38721]
for_stmt [38454,38843]
===
match
---
number: 80 [34538,34540]
number: 80 [34660,34662]
===
match
---
trailer [40400,40421]
trailer [40522,40543]
===
match
---
operator: = [7418,7419]
operator: = [7418,7419]
===
match
---
operator: , [34233,34234]
operator: , [34355,34356]
===
match
---
operator: @ [44837,44838]
operator: @ [44959,44960]
===
match
---
trailer [8665,8678]
trailer [8665,8678]
===
match
---
trailer [19183,19192]
trailer [19305,19314]
===
match
---
name: parse_time [48730,48740]
name: parse_time [48852,48862]
===
match
---
atom_expr [35083,35099]
atom_expr [35205,35221]
===
match
---
trailer [45935,46110]
trailer [46057,46232]
===
match
---
name: self [39801,39805]
name: self [39923,39927]
===
match
---
atom_expr [22260,22325]
atom_expr [22382,22447]
===
match
---
operator: , [48775,48776]
operator: , [48897,48898]
===
match
---
name: List [6735,6739]
name: List [6735,6739]
===
match
---
name: now [42796,42799]
name: now [42918,42921]
===
match
---
name: run_count [44742,44751]
name: run_count [44864,44873]
===
match
---
trailer [39890,39900]
trailer [40012,40022]
===
match
---
operator: - [45564,45565]
operator: - [45686,45687]
===
match
---
trailer [8257,8265]
trailer [8257,8265]
===
match
---
simple_stmt [40491,40587]
simple_stmt [40613,40709]
===
match
---
trailer [42496,42501]
trailer [42618,42623]
===
match
---
name: monotonic [8150,8159]
name: monotonic [8150,8159]
===
match
---
operator: , [22719,22720]
operator: , [22841,22842]
===
match
---
trailer [33635,33689]
trailer [33757,33811]
===
match
---
name: processor_factory [18885,18902]
name: processor_factory [19007,19024]
===
match
---
name: Optional [3169,3177]
name: Optional [3169,3177]
===
match
---
name: start_time [44343,44353]
name: start_time [44465,44475]
===
match
---
atom_expr [30144,30183]
atom_expr [30266,30305]
===
match
---
trailer [8793,8795]
trailer [8793,8795]
===
match
---
operator: , [6623,6624]
operator: , [6623,6624]
===
match
---
and_test [14763,14809]
and_test [14885,14931]
===
match
---
name: dagcode [30901,30908]
name: dagcode [31023,31030]
===
match
---
testlist_comp [33716,33795]
testlist_comp [33838,33917]
===
match
---
atom_expr [3728,3743]
atom_expr [3728,3743]
===
match
---
name: _parent_signal_conn [11331,11350]
name: _parent_signal_conn [11449,11468]
===
match
---
arglist [39072,39120]
arglist [39194,39242]
===
match
---
name: log [16486,16489]
name: log [16608,16611]
===
match
---
name: _processors [37421,37432]
name: _processors [37543,37554]
===
match
---
param [37504,37513]
param [37626,37635]
===
match
---
or_test [33917,33928]
or_test [34039,34050]
===
match
---
name: stat [47733,47737]
name: stat [47855,47859]
===
match
---
parameters [31893,31917]
parameters [32015,32039]
===
match
---
fstring [34317,34339]
fstring [34439,34461]
===
match
---
param [39029,39038]
param [39151,39160]
===
match
---
name: ready [24599,24604]
name: ready [24721,24726]
===
match
---
simple_stmt [8805,8881]
simple_stmt [8805,8881]
===
match
---
suite [46957,47480]
suite [47079,47602]
===
match
---
name: set [43684,43687]
name: set [43806,43809]
===
match
---
name: self [31209,31213]
name: self [31331,31335]
===
match
---
name: NotImplementedError [4415,4434]
name: NotImplementedError [4415,4434]
===
match
---
name: formatted_rows [34062,34076]
name: formatted_rows [34184,34198]
===
match
---
simple_stmt [39057,39122]
simple_stmt [39179,39244]
===
match
---
name: TI [45885,45887]
name: TI [46007,46009]
===
match
---
expr_stmt [20050,20115]
expr_stmt [20172,20237]
===
match
---
operator: , [34447,34448]
operator: , [34569,34570]
===
match
---
name: random [908,914]
name: random [908,914]
===
match
---
argument [10832,10859]
argument [10832,10859]
===
match
---
arglist [17172,17206]
arglist [17294,17328]
===
match
---
name: AbstractDagFileProcessorProcess [7385,7416]
name: AbstractDagFileProcessorProcess [7385,7416]
===
match
---
atom_expr [23494,23522]
atom_expr [23616,23644]
===
match
---
atom_expr [8107,8142]
atom_expr [8107,8142]
===
match
---
suite [24119,24148]
suite [24241,24270]
===
match
---
operator: * [34536,34537]
operator: * [34658,34659]
===
match
---
simple_stmt [26349,26397]
simple_stmt [26471,26519]
===
match
---
operator: @ [16094,16095]
operator: @ [16216,16217]
===
match
---
name: result [13976,13982]
name: result [14098,14104]
===
match
---
name: map [23054,23057]
name: map [23176,23179]
===
match
---
import_from [2211,2248]
import_from [2211,2248]
===
match
---
name: async_mode [13515,13525]
name: async_mode [13637,13647]
===
match
---
operator: , [7383,7384]
operator: , [7383,7384]
===
match
---
string: "wait() unexpectedly returned nothing ready after infinite timeout (%r)!" [25967,26040]
string: "wait() unexpectedly returned nothing ready after infinite timeout (%r)!" [26089,26162]
===
match
---
name: path [42497,42501]
name: path [42619,42623]
===
match
---
trailer [19225,19230]
trailer [19347,19352]
===
match
---
trailer [27772,27774]
trailer [27894,27896]
===
match
---
name: _file_paths [30752,30763]
name: _file_paths [30874,30885]
===
match
---
name: utils [2042,2047]
name: utils [2042,2047]
===
match
---
atom_expr [12101,12120]
atom_expr [12223,12242]
===
match
---
testlist_star_expr [8171,8214]
testlist_star_expr [8171,8214]
===
match
---
name: _parent_signal_conn [11238,11257]
name: _parent_signal_conn [11238,11257]
===
match
---
simple_stmt [35209,35323]
simple_stmt [35331,35445]
===
match
---
parameters [8913,8919]
parameters [8913,8919]
===
match
---
name: _file_stats [44578,44589]
name: _file_stats [44700,44711]
===
match
---
if_stmt [10001,10087]
if_stmt [10001,10087]
===
match
---
name: file_paths_in_progress [43688,43710]
name: file_paths_in_progress [43810,43832]
===
match
---
name: EX_OK [25139,25144]
name: EX_OK [25261,25266]
===
match
---
trailer [42480,42491]
trailer [42602,42613]
===
match
---
expr_stmt [4719,4729]
expr_stmt [4719,4729]
===
match
---
operator: = [43682,43683]
operator: = [43804,43805]
===
match
---
name: terminate [24971,24980]
name: terminate [25093,25102]
===
match
---
string: "BlockingIOError recived trying to send DagParsingStat, ignoring" [28414,28479]
string: "BlockingIOError recived trying to send DagParsingStat, ignoring" [28536,28601]
===
match
---
operator: @ [2759,2760]
operator: @ [2759,2760]
===
match
---
atom_expr [19176,19194]
atom_expr [19298,19316]
===
match
---
name: self [25096,25100]
name: self [25218,25222]
===
match
---
name: _last_zombie_query_time [45162,45185]
name: _last_zombie_query_time [45284,45307]
===
match
---
simple_stmt [2726,2754]
simple_stmt [2726,2754]
===
match
---
name: AGENT_RUN_ONCE [5068,5082]
name: AGENT_RUN_ONCE [5068,5082]
===
match
---
expr_stmt [41112,41179]
expr_stmt [41234,41301]
===
match
---
string: 'dag_processing.import_errors' [48868,48898]
string: 'dag_processing.import_errors' [48990,49020]
===
match
---
trailer [48823,48830]
trailer [48945,48952]
===
match
---
name: all_files_processed [16112,16131]
name: all_files_processed [16234,16253]
===
match
---
name: self [15669,15673]
name: self [15791,15795]
===
match
---
trailer [47247,47275]
trailer [47369,47397]
===
match
---
name: self [30747,30751]
name: self [30869,30873]
===
match
---
atom_expr [40434,40481]
atom_expr [40556,40603]
===
match
---
simple_stmt [48615,48675]
simple_stmt [48737,48797]
===
match
---
trailer [24539,24541]
trailer [24661,24663]
===
match
---
param [12130,12148]
param [12252,12270]
===
match
---
string: "pathlib.Path" [18837,18851]
string: "pathlib.Path" [18959,18973]
===
match
---
trailer [47410,47415]
trailer [47532,47537]
===
match
---
trailer [31763,31781]
trailer [31885,31903]
===
match
---
operator: = [2627,2628]
operator: = [2627,2628]
===
match
---
expr_stmt [32902,32947]
expr_stmt [33024,33069]
===
match
---
name: file_path [29510,29519]
name: file_path [29632,29641]
===
match
---
name: _process [16448,16456]
name: _process [16570,16578]
===
match
---
name: airflow [13154,13161]
name: airflow [13276,13283]
===
match
---
suite [10724,10778]
suite [10724,10778]
===
match
---
argument [46362,46405]
argument [46484,46527]
===
match
---
name: sum [48900,48903]
name: sum [49022,49025]
===
match
---
operator: , [6898,6899]
operator: , [6898,6899]
===
match
---
name: agent_signal [25030,25042]
name: agent_signal [25152,25164]
===
match
---
name: msg [46427,46430]
name: msg [46549,46552]
===
match
---
name: str [21184,21187]
name: str [21306,21309]
===
match
---
name: path [33037,33041]
name: path [33159,33163]
===
match
---
string: """Processes a DAG file. See SchedulerJob.process_file() for more details.""" [2351,2428]
string: """Processes a DAG file. See SchedulerJob.process_file() for more details.""" [2351,2428]
===
match
---
name: self [39023,39027]
name: self [39145,39149]
===
match
---
name: file_path [39891,39900]
name: file_path [40013,40022]
===
match
---
name: TERMINATE_MANAGER [16618,16635]
name: TERMINATE_MANAGER [16740,16757]
===
match
---
atom_expr [12422,12482]
atom_expr [12544,12604]
===
match
---
operator: , [15562,15563]
operator: , [15684,15685]
===
match
---
name: _get_multiprocessing_start_method [8000,8033]
name: _get_multiprocessing_start_method [8000,8033]
===
match
---
name: SIGTERM [22575,22582]
name: SIGTERM [22697,22704]
===
match
---
operator: = [8248,8249]
operator: = [8248,8249]
===
match
---
trailer [35728,35732]
trailer [35850,35854]
===
match
---
atom_expr [37416,37454]
atom_expr [37538,37576]
===
match
---
test [36159,36190]
test [36281,36312]
===
match
---
trailer [44802,44809]
trailer [44924,44931]
===
match
---
simple_stmt [10449,10684]
simple_stmt [10449,10684]
===
match
---
trailer [45200,45202]
trailer [45322,45324]
===
match
---
simple_stmt [47917,47992]
simple_stmt [48039,48114]
===
match
---
trailer [45638,45693]
trailer [45760,45815]
===
match
---
trailer [48848,48854]
trailer [48970,48976]
===
match
---
name: typing [1189,1195]
name: typing [1189,1195]
===
match
---
string: """         :param file_path: the path to the file that was processed         :type file_path: unicode         :return: the runtime (in seconds) of the process of the last run, or             None if the file was never processed.         :rtype: float         """ [35433,35696]
string: """         :param file_path: the path to the file that was processed         :type file_path: unicode         :return: the runtime (in seconds) of the process of the last run, or             None if the file was never processed.         :rtype: float         """ [35555,35818]
===
match
---
operator: , [44880,44881]
operator: , [45002,45003]
===
match
---
raise_stmt [3632,3659]
raise_stmt [3632,3659]
===
match
---
arglist [45833,45859]
arglist [45955,45981]
===
match
---
operator: = [39194,39195]
operator: = [39316,39317]
===
match
---
expr_stmt [29783,29806]
expr_stmt [29905,29928]
===
match
---
trailer [38705,38709]
trailer [38827,38831]
===
match
---
param [18797,18802]
param [18919,18924]
===
match
---
name: getint [20952,20958]
name: getint [21074,21080]
===
match
---
name: self [41590,41594]
name: self [41712,41716]
===
match
---
operator: = [7215,7216]
operator: = [7215,7216]
===
match
---
name: runtime [34216,34223]
name: runtime [34338,34345]
===
match
---
if_stmt [43003,43497]
if_stmt [43125,43619]
===
match
---
trailer [14479,14544]
trailer [14601,14666]
===
match
---
name: airflow [30886,30893]
name: airflow [31008,31015]
===
match
---
trailer [28640,28650]
trailer [28762,28772]
===
match
---
name: _file_process_interval [23761,23783]
name: _file_process_interval [23883,23905]
===
match
---
trailer [39819,39840]
trailer [39941,39962]
===
match
---
trailer [41561,41565]
trailer [41683,41687]
===
match
---
name: self [28970,28974]
name: self [29092,29096]
===
match
---
name: getint [20581,20587]
name: getint [20703,20709]
===
match
---
comparison [40809,40854]
comparison [40931,40976]
===
match
---
name: self [38360,38364]
name: self [38482,38486]
===
match
---
name: poll [11351,11355]
name: poll [11469,11473]
===
match
---
suite [44180,44381]
suite [44302,44503]
===
match
---
name: get_start_time [37021,37035]
name: get_start_time [37143,37157]
===
match
---
param [47902,47906]
param [48024,48028]
===
match
---
name: _done [7553,7558]
name: _done [7553,7558]
===
match
---
name: ConnectionError [10166,10181]
name: ConnectionError [10166,10181]
===
match
---
name: pop [38706,38709]
name: pop [38828,38831]
===
match
---
parameters [41728,41734]
parameters [41850,41856]
===
match
---
comparison [24696,24722]
comparison [24818,24844]
===
match
---
atom_expr [27595,27613]
atom_expr [27717,27735]
===
match
---
atom_expr [32857,32889]
atom_expr [32979,33011]
===
match
---
simple_stmt [29701,29775]
simple_stmt [29823,29897]
===
match
---
term [34532,34540]
term [34654,34662]
===
match
---
parameters [2975,2981]
parameters [2975,2981]
===
match
---
simple_stmt [8171,8232]
simple_stmt [8171,8232]
===
match
---
arglist [28566,28650]
arglist [28688,28772]
===
match
---
arglist [42183,42220]
arglist [42305,42342]
===
match
---
name: inspect [845,852]
name: inspect [845,852]
===
match
---
name: known_file_paths [31900,31916]
name: known_file_paths [32022,32038]
===
match
---
trailer [19504,19513]
trailer [19626,19635]
===
match
---
atom_expr [29011,29075]
atom_expr [29133,29197]
===
match
---
name: signum [22984,22990]
name: signum [23106,23112]
===
match
---
argument [2327,2344]
argument [2327,2344]
===
match
---
name: self [7995,7999]
name: self [7995,7999]
===
match
---
suite [46677,47480]
suite [46799,47602]
===
match
---
name: _file_paths [30368,30379]
name: _file_paths [30490,30501]
===
match
---
import_name [838,852]
import_name [838,852]
===
match
---
name: SimpleTaskInstance [46383,46401]
name: SimpleTaskInstance [46505,46523]
===
match
---
trailer [38693,38705]
trailer [38815,38827]
===
match
---
trailer [43484,43496]
trailer [43606,43618]
===
match
---
trailer [23797,23801]
trailer [23919,23923]
===
match
---
simple_stmt [28741,28792]
simple_stmt [28863,28914]
===
match
---
trailer [31309,31330]
trailer [31431,31452]
===
match
---
trailer [2565,2567]
trailer [2565,2567]
===
match
---
name: bool [12143,12147]
name: bool [12265,12269]
===
match
---
simple_stmt [13976,14017]
simple_stmt [14098,14139]
===
match
---
operator: - [42800,42801]
operator: - [42922,42923]
===
match
---
simple_stmt [48429,48607]
simple_stmt [48551,48729]
===
match
---
name: conf [20139,20143]
name: conf [20261,20265]
===
match
---
operator: , [1279,1280]
operator: , [1279,1280]
===
match
---
name: SIG_IGN [22728,22735]
name: SIG_IGN [22850,22857]
===
match
---
name: models [1494,1500]
name: models [1494,1500]
===
match
---
trailer [23208,23214]
trailer [23330,23336]
===
match
---
string: "Process not started." [10063,10085]
string: "Process not started." [10063,10085]
===
match
---
name: gauge [33512,33517]
name: gauge [33634,33639]
===
match
---
arglist [39581,39845]
arglist [39703,39967]
===
match
---
name: self [24275,24279]
name: self [24397,24401]
===
match
---
parameters [49045,49051]
parameters [49167,49173]
===
match
---
simple_stmt [36652,36910]
simple_stmt [36774,37032]
===
match
---
atom_expr [44458,44491]
atom_expr [44580,44613]
===
match
---
if_stmt [39223,39540]
if_stmt [39345,39662]
===
match
---
name: self [13591,13595]
name: self [13713,13717]
===
match
---
trailer [7361,7373]
trailer [7361,7373]
===
match
---
simple_stmt [24599,24681]
simple_stmt [24721,24803]
===
match
---
name: _dag_directory [7019,7033]
name: _dag_directory [7019,7033]
===
match
---
name: inspect [23063,23070]
name: inspect [23185,23192]
===
match
---
operator: , [12147,12148]
operator: , [12269,12270]
===
match
---
atom_expr [6861,6870]
atom_expr [6861,6870]
===
match
---
name: self [7233,7237]
name: self [7233,7237]
===
match
---
atom_expr [26901,26927]
atom_expr [27023,27049]
===
match
---
suite [12189,13572]
suite [12311,13694]
===
match
---
string: "Process not started." [14728,14750]
string: "Process not started." [14850,14872]
===
match
---
trailer [40384,40396]
trailer [40506,40518]
===
match
---
operator: - [47623,47624]
operator: - [47745,47746]
===
match
---
simple_stmt [7097,7141]
simple_stmt [7097,7141]
===
match
---
name: self [36221,36225]
name: self [36343,36347]
===
match
---
atom_expr [21179,21221]
atom_expr [21301,21343]
===
match
---
name: _parent_signal_conn [10704,10723]
name: _parent_signal_conn [10704,10723]
===
match
---
number: 0.0 [24144,24147]
number: 0.0 [24266,24269]
===
match
---
parameters [16131,16137]
parameters [16253,16259]
===
match
---
trailer [23119,23123]
trailer [23241,23245]
===
match
---
name: os [33125,33127]
name: os [33247,33249]
===
match
---
name: signal [22721,22727]
name: signal [22843,22849]
===
match
---
annassign [4951,4968]
annassign [4951,4968]
===
match
---
trailer [27075,27136]
trailer [27197,27258]
===
match
---
name: _callback_to_execute [29016,29036]
name: _callback_to_execute [29138,29158]
===
match
---
param [48414,48418]
param [48536,48540]
===
match
---
argument [24662,24679]
argument [24784,24801]
===
match
---
dotted_name [1447,1468]
dotted_name [1447,1468]
===
match
---
name: timeout [11356,11363]
name: timeout [11474,11481]
===
match
---
string: "random_seeded_by_host" [43223,43246]
string: "random_seeded_by_host" [43345,43368]
===
match
---
operator: @ [4016,4017]
operator: @ [4016,4017]
===
match
---
simple_stmt [47658,47671]
simple_stmt [47780,47793]
===
match
---
atom_expr [14276,14345]
atom_expr [14398,14467]
===
match
---
simple_stmt [40380,40422]
simple_stmt [40502,40544]
===
match
---
simple_stmt [13276,13537]
simple_stmt [13398,13659]
===
match
---
tfpdef [18862,18875]
tfpdef [18984,18997]
===
match
---
trailer [48903,48961]
trailer [49025,49083]
===
match
---
name: _find_zombies [26554,26567]
name: _find_zombies [26676,26689]
===
match
---
name: join [44465,44469]
name: join [44587,44591]
===
match
---
name: _process [15077,15085]
name: _process [15199,15207]
===
match
---
simple_stmt [43506,43651]
simple_stmt [43628,43773]
===
match
---
name: self [10888,10892]
name: self [10888,10892]
===
match
---
suite [16138,16239]
suite [16260,16361]
===
match
---
name: max_runs_reached [47489,47505]
name: max_runs_reached [47611,47627]
===
match
---
name: CallbackRequest [28985,29000]
name: CallbackRequest [29107,29122]
===
match
---
name: file_path [35070,35079]
name: file_path [35192,35201]
===
match
---
atom_expr [28399,28480]
atom_expr [28521,28602]
===
match
---
trailer [8265,8738]
trailer [8265,8738]
===
match
---
name: files_paths_to_queue [43991,44011]
name: files_paths_to_queue [44113,44133]
===
match
---
simple_stmt [21371,21407]
simple_stmt [21493,21529]
===
match
---
operator: ~ [31731,31732]
operator: ~ [31853,31854]
===
match
---
name: Union [1274,1279]
name: Union [1274,1279]
===
match
---
name: splitext [33094,33102]
name: splitext [33216,33224]
===
match
---
name: file_path [38466,38475]
name: file_path [38588,38597]
===
match
---
simple_stmt [31627,31669]
simple_stmt [31749,31791]
===
match
---
if_stmt [31113,31350]
if_stmt [31235,31472]
===
match
---
name: LJ [45804,45806]
name: LJ [45926,45928]
===
match
---
operator: , [11896,11897]
operator: , [12018,12019]
===
match
---
expr_stmt [27627,27719]
expr_stmt [27749,27841]
===
match
---
operator: = [45544,45545]
operator: = [45666,45667]
===
match
---
tfpdef [11883,11896]
tfpdef [12005,12018]
===
match
---
return_stmt [47782,47794]
return_stmt [47904,47916]
===
match
---
name: self [30291,30295]
name: self [30413,30417]
===
match
---
atom_expr [46553,46589]
atom_expr [46675,46711]
===
match
---
expr_stmt [8747,8770]
expr_stmt [8747,8770]
===
match
---
trailer [20587,20629]
trailer [20709,20751]
===
match
---
parameters [23230,23236]
parameters [23352,23358]
===
match
---
name: set_blocking [19993,20005]
name: set_blocking [20115,20127]
===
match
---
name: request [29152,29159]
name: request [29274,29281]
===
match
---
trailer [13207,13209]
trailer [13329,13331]
===
match
---
simple_stmt [2211,2249]
simple_stmt [2211,2249]
===
match
---
decorator [3126,3142]
decorator [3126,3142]
===
match
---
simple_stmt [33354,33402]
simple_stmt [33476,33524]
===
match
---
trailer [22711,22719]
trailer [22833,22841]
===
match
---
funcdef [38987,39909]
funcdef [39109,40031]
===
match
---
atom_expr [30310,30329]
atom_expr [30432,30451]
===
match
---
operator: , [30090,30091]
operator: , [30212,30213]
===
match
---
funcdef [34751,35172]
funcdef [34873,35294]
===
match
---
operator: , [44697,44698]
operator: , [44819,44820]
===
match
---
simple_stmt [8044,8099]
simple_stmt [8044,8099]
===
match
---
operator: , [45789,45790]
operator: , [45911,45912]
===
match
---
name: NotImplementedError [4611,4630]
name: NotImplementedError [4611,4630]
===
match
---
parameters [18787,19166]
parameters [18909,19288]
===
match
---
name: self [26988,26992]
name: self [27110,27114]
===
match
---
simple_stmt [35160,35172]
simple_stmt [35282,35294]
===
match
---
trailer [31247,31274]
trailer [31369,31396]
===
match
---
trailer [48377,48391]
trailer [48499,48513]
===
match
---
operator: , [11996,11997]
operator: , [12118,12119]
===
match
---
simple_stmt [1964,2029]
simple_stmt [1964,2029]
===
match
---
operator: = [31823,31824]
operator: = [31945,31946]
===
match
---
expr_stmt [33443,33489]
expr_stmt [33565,33611]
===
match
---
string: """Refresh file paths from dag dir if we haven't done it for too long.""" [29701,29774]
string: """Refresh file paths from dag dir if we haven't done it for too long.""" [29823,29896]
===
match
---
trailer [25479,25520]
trailer [25601,25642]
===
match
---
name: get_last_runtime [32862,32878]
name: get_last_runtime [32984,33000]
===
match
---
name: register_exit_signals [22400,22421]
name: register_exit_signals [22522,22543]
===
match
---
trailer [27579,27581]
trailer [27701,27703]
===
match
---
atom_expr [14467,14544]
atom_expr [14589,14666]
===
match
---
operator: , [40543,40544]
operator: , [40665,40666]
===
match
---
atom_expr [6852,6871]
atom_expr [6852,6871]
===
match
---
dotted_name [45301,45328]
dotted_name [45423,45450]
===
match
---
suite [29199,29597]
suite [29321,29719]
===
match
---
trailer [48694,48741]
trailer [48816,48863]
===
match
---
simple_stmt [33623,33690]
simple_stmt [33745,33812]
===
match
---
operator: < [28825,28826]
operator: < [28947,28948]
===
match
---
simple_stmt [41192,41333]
simple_stmt [41314,41455]
===
match
---
raise_stmt [10046,10086]
raise_stmt [10046,10086]
===
match
---
name: models [30894,30900]
name: models [31016,31022]
===
match
---
trailer [17202,17206]
trailer [17324,17328]
===
match
---
name: file_name [33022,33031]
name: file_name [33144,33153]
===
match
---
operator: , [1265,1266]
operator: , [1265,1266]
===
match
---
decorators [3665,3695]
decorators [3665,3695]
===
match
---
for_stmt [32795,33798]
for_stmt [32917,33920]
===
match
---
simple_stmt [929,940]
simple_stmt [929,940]
===
match
---
atom_expr [15824,15834]
atom_expr [15946,15956]
===
match
---
atom_expr [34723,34745]
atom_expr [34845,34867]
===
match
---
operator: , [35411,35412]
operator: , [35533,35534]
===
match
---
trailer [24638,24680]
trailer [24760,24802]
===
match
---
name: self [41833,41837]
name: self [41955,41959]
===
match
---
trailer [20010,20023]
trailer [20132,20145]
===
match
---
name: signal [22698,22704]
name: signal [22820,22826]
===
match
---
atom_expr [7097,7120]
atom_expr [7097,7120]
===
match
---
trailer [38531,38539]
trailer [38653,38661]
===
match
---
suite [15740,15971]
suite [15862,16093]
===
match
---
name: get_run_count [39806,39819]
name: get_run_count [39928,39941]
===
match
---
name: monotonic [31153,31162]
name: monotonic [31275,31284]
===
match
---
name: Callable [18904,18912]
name: Callable [19026,19034]
===
match
---
simple_stmt [4196,4224]
simple_stmt [4196,4224]
===
match
---
name: str [10414,10417]
name: str [10414,10417]
===
match
---
name: ValueError [14717,14727]
name: ValueError [14839,14849]
===
match
---
name: last_duration [44722,44735]
name: last_duration [44844,44857]
===
match
---
arglist [40506,40585]
arglist [40628,40707]
===
match
---
expr_stmt [15824,15846]
expr_stmt [15946,15968]
===
match
---
name: monotonic [7833,7842]
name: monotonic [7833,7842]
===
match
---
expr_stmt [45533,45612]
expr_stmt [45655,45734]
===
match
---
simple_stmt [3632,3660]
simple_stmt [3632,3660]
===
match
---
tfpdef [6605,6623]
tfpdef [6605,6623]
===
match
---
atom_expr [30196,30226]
atom_expr [30318,30348]
===
match
---
string: """         Find zombie task instances, which are tasks haven't heartbeated for too long         and update the current zombie list.         """ [44900,45044]
string: """         Find zombie task instances, which are tasks haven't heartbeated for too long         and update the current zombie list.         """ [45022,45166]
===
match
---
trailer [25062,25074]
trailer [25184,25196]
===
match
---
name: _signal_conn [40093,40105]
name: _signal_conn [40215,40227]
===
match
---
name: self [15999,16003]
name: self [16121,16125]
===
match
---
name: last_duration [35764,35777]
name: last_duration [35886,35899]
===
match
---
atom_expr [48349,48391]
atom_expr [48471,48513]
===
match
---
name: processor_factory [7123,7140]
name: processor_factory [7123,7140]
===
match
---
atom_expr [47733,47747]
atom_expr [47855,47869]
===
match
---
name: self [24755,24759]
name: self [24877,24881]
===
match
---
trailer [44469,44491]
trailer [44591,44613]
===
match
---
expr_stmt [33203,33256]
expr_stmt [33325,33378]
===
match
---
trailer [34727,34731]
trailer [34849,34853]
===
match
---
operator: , [32673,32674]
operator: , [32795,32796]
===
match
---
dotted_name [2216,2235]
dotted_name [2216,2235]
===
match
---
simple_stmt [15624,15679]
simple_stmt [15746,15801]
===
match
---
operator: @ [3126,3127]
operator: @ [3126,3127]
===
match
---
name: self [7548,7552]
name: self [7548,7552]
===
match
---
trailer [33369,33390]
trailer [33491,33512]
===
match
---
name: self [46671,46675]
name: self [46793,46797]
===
match
---
operator: , [2611,2612]
operator: , [2611,2612]
===
match
---
name: poll_time [24174,24183]
name: poll_time [24296,24305]
===
match
---
name: log [23798,23801]
name: log [23920,23923]
===
match
---
trailer [39061,39065]
trailer [39183,39187]
===
match
---
name: last_stat_print_time [21616,21636]
name: last_stat_print_time [21738,21758]
===
match
---
operator: == [45801,45803]
operator: == [45923,45925]
===
match
---
atom_expr [14357,14392]
atom_expr [14479,14514]
===
match
---
operator: , [6924,6925]
operator: , [6924,6925]
===
match
---
simple_stmt [16722,16819]
simple_stmt [16844,16941]
===
match
---
atom_expr [13222,13267]
atom_expr [13344,13389]
===
match
---
annassign [21332,21361]
annassign [21454,21483]
===
match
---
funcdef [39914,40678]
funcdef [40036,40800]
===
match
---
atom [45717,46147]
atom [45839,46269]
===
match
---
name: _all_files_processed [16218,16238]
name: _all_files_processed [16340,16360]
===
match
---
expr_stmt [20917,21006]
expr_stmt [21039,21128]
===
match
---
trailer [39351,39357]
trailer [39473,39479]
===
match
---
name: file_path [42511,42520]
name: file_path [42633,42642]
===
match
---
expr_stmt [7063,7088]
expr_stmt [7063,7088]
===
match
---
trailer [21942,21964]
trailer [22064,22086]
===
match
---
name: import_errors [48909,48922]
name: import_errors [49031,49044]
===
match
---
simple_stmt [891,901]
simple_stmt [891,901]
===
match
---
trailer [22195,22224]
trailer [22317,22346]
===
match
---
atom_expr [11233,11257]
atom_expr [11233,11257]
===
match
---
name: airflow [1912,1919]
name: airflow [1912,1919]
===
match
---
name: warning [25938,25945]
name: warning [26060,26067]
===
match
---
name: _dag_ids [19505,19513]
name: _dag_ids [19627,19635]
===
match
---
name: utcnow [45068,45074]
name: utcnow [45190,45196]
===
match
---
trailer [16485,16489]
trailer [16607,16611]
===
match
---
name: airflow [13180,13187]
name: airflow [13302,13309]
===
match
---
number: 0 [21560,21561]
number: 0 [21682,21683]
===
match
---
atom_expr [8696,8712]
atom_expr [8696,8712]
===
match
---
argument [10861,10874]
argument [10861,10874]
===
match
---
simple_stmt [17153,17208]
simple_stmt [17275,17330]
===
match
---
atom_expr [38596,38634]
atom_expr [38718,38756]
===
match
---
operator: , [20383,20384]
operator: , [20505,20506]
===
match
---
for_stmt [46222,46635]
for_stmt [46344,46757]
===
match
---
name: self [30125,30129]
name: self [30247,30251]
===
match
---
name: utils [2174,2179]
name: utils [2174,2179]
===
match
---
operator: = [17139,17140]
operator: = [17261,17262]
===
match
---
decorated [2759,2929]
decorated [2759,2929]
===
match
---
string: """         Check if the process launched to process this file is done.         :return: whether the process is finished running         :rtype: bool         """ [3462,3623]
string: """         Check if the process launched to process this file is done.         :return: whether the process is finished running         :rtype: bool         """ [3462,3623]
===
match
---
fstring_string: s [34210,34211]
fstring_string: s [34332,34333]
===
match
---
name: new_file_paths [38126,38140]
name: new_file_paths [38248,38262]
===
match
---
name: clear_nonexistent_import_errors [30481,30512]
name: clear_nonexistent_import_errors [30603,30634]
===
match
---
name: pid [17186,17189]
name: pid [17308,17311]
===
match
---
decorated [15976,16089]
decorated [16098,16211]
===
match
---
name: file_path [26489,26498]
name: file_path [26611,26620]
===
match
---
trailer [25135,25145]
trailer [25257,25267]
===
match
---
funcdef [47888,48129]
funcdef [48010,48251]
===
match
---
atom_expr [24525,24541]
atom_expr [24647,24663]
===
match
---
name: _num_run [47811,47819]
name: _num_run [47933,47941]
===
match
---
decorator [3112,3122]
decorator [3112,3122]
===
match
---
atom_expr [21685,21712]
atom_expr [21807,21834]
===
match
---
trailer [30057,30062]
trailer [30179,30184]
===
match
---
operator: = [8761,8762]
operator: = [8761,8762]
===
match
---
decorator [3665,3675]
decorator [3665,3675]
===
match
---
name: _dag_directory [23874,23888]
name: _dag_directory [23996,24010]
===
match
---
operator: -> [8920,8922]
operator: -> [8920,8922]
===
match
---
if_stmt [9379,9431]
if_stmt [9379,9431]
===
match
---
name: total_seconds [34190,34203]
name: total_seconds [34312,34325]
===
match
---
atom_expr [45791,45800]
atom_expr [45913,45922]
===
match
---
name: message [14258,14265]
name: message [14380,14387]
===
match
---
trailer [31848,31855]
trailer [31970,31977]
===
match
---
operator: , [45680,45681]
operator: , [45802,45803]
===
match
---
name: self [26821,26825]
name: self [26943,26947]
===
match
---
number: 0 [44679,44680]
number: 0 [44801,44802]
===
match
---
string: 'print_stats_interval' [20795,20817]
string: 'print_stats_interval' [20917,20939]
===
match
---
name: _sync_metadata [14411,14425]
name: _sync_metadata [14533,14547]
===
match
---
simple_stmt [38689,38721]
simple_stmt [38811,38843]
===
match
---
name: full_filepath [29045,29058]
name: full_filepath [29167,29180]
===
match
---
name: callback_to_execute_for_file [41256,41284]
name: callback_to_execute_for_file [41378,41406]
===
match
---
name: self [45368,45372]
name: self [45490,45494]
===
match
---
name: _processor_factory [7102,7120]
name: _processor_factory [7102,7120]
===
match
---
name: join [17127,17131]
name: join [17249,17253]
===
match
---
name: monotonic [15218,15227]
name: monotonic [15340,15349]
===
match
---
param [11152,11156]
param [11152,11156]
===
match
---
if_stmt [47602,47671]
if_stmt [47724,47793]
===
match
---
name: sum [48777,48780]
name: sum [48899,48902]
===
match
---
name: timezone [39196,39204]
name: timezone [39318,39326]
===
match
---
simple_stmt [49061,49085]
simple_stmt [49183,49207]
===
match
---
trailer [13569,13571]
trailer [13691,13693]
===
match
---
expr_stmt [33939,33958]
expr_stmt [34061,34080]
===
match
---
name: pids_to_kill [48323,48335]
name: pids_to_kill [48445,48457]
===
match
---
operator: = [46775,46776]
operator: = [46897,46898]
===
match
---
name: importlib [13026,13035]
name: importlib [13148,13157]
===
match
---
name: sentinel [26113,26121]
name: sentinel [26235,26243]
===
match
---
name: signal [22568,22574]
name: signal [22690,22696]
===
match
---
name: signal [22554,22560]
name: signal [22676,22682]
===
match
---
tfpdef [2613,2626]
tfpdef [2613,2626]
===
match
---
atom_expr [37793,37807]
atom_expr [37915,37929]
===
match
---
name: utcnow [32778,32784]
name: utcnow [32900,32906]
===
match
---
trailer [39347,39351]
trailer [39469,39473]
===
match
---
atom_expr [27649,27719]
atom_expr [27771,27841]
===
match
---
trailer [28407,28413]
trailer [28529,28535]
===
match
---
suite [16848,16932]
suite [16970,17054]
===
match
---
if_stmt [13716,13802]
if_stmt [13838,13924]
===
match
---
name: _async_mode [8701,8712]
name: _async_mode [8701,8712]
===
match
---
string: "Process not started." [10754,10776]
string: "Process not started." [10754,10776]
===
match
---
atom_expr [23197,23215]
atom_expr [23319,23337]
===
match
---
expr_stmt [43991,44117]
expr_stmt [44113,44239]
===
match
---
if_stmt [11550,11796]
if_stmt [11669,11918]
===
match
---
simple_stmt [6968,7006]
simple_stmt [6968,7006]
===
match
---
trailer [3177,3182]
trailer [3177,3182]
===
match
---
suite [14882,15143]
suite [15004,15265]
===
match
---
trailer [21689,21712]
trailer [21811,21834]
===
match
---
name: _last_zombie_query_time [45111,45134]
name: _last_zombie_query_time [45233,45256]
===
match
---
simple_stmt [14200,14226]
simple_stmt [14322,14348]
===
match
---
comparison [37366,37395]
comparison [37488,37517]
===
match
---
operator: = [21400,21401]
operator: = [21522,21523]
===
match
---
operator: , [6833,6834]
operator: , [6833,6834]
===
match
---
string: "Detected as zombie" [46431,46451]
string: "Detected as zombie" [46553,46573]
===
match
---
trailer [27449,27451]
trailer [27571,27573]
===
match
---
expr_stmt [5150,5177]
expr_stmt [5150,5177]
===
match
---
trailer [20405,20418]
trailer [20527,20540]
===
match
---
trailer [30253,30258]
trailer [30375,30380]
===
match
---
operator: , [41550,41551]
operator: , [41672,41673]
===
match
---
arglist [44225,44366]
arglist [44347,44488]
===
match
---
name: num_dags [39268,39276]
name: num_dags [39390,39398]
===
match
---
trailer [30973,30985]
trailer [31095,31107]
===
match
---
simple_stmt [23090,23107]
simple_stmt [23212,23229]
===
match
---
name: result [39310,39316]
name: result [39432,39438]
===
match
---
name: self [16707,16711]
name: self [16829,16833]
===
match
---
name: str [6740,6743]
name: str [6740,6743]
===
match
---
trailer [25104,25106]
trailer [25226,25228]
===
match
---
expr_stmt [19420,19451]
expr_stmt [19542,19573]
===
match
---
name: request [29637,29644]
name: request [29759,29766]
===
match
---
name: keys [40078,40082]
name: keys [40200,40204]
===
match
---
name: log [40496,40499]
name: log [40618,40621]
===
match
---
simple_stmt [41744,41825]
simple_stmt [41866,41947]
===
match
---
name: SerializedDagModel [30708,30726]
name: SerializedDagModel [30830,30848]
===
match
---
simple_stmt [16273,16414]
simple_stmt [16395,16536]
===
match
---
simple_stmt [1184,1286]
simple_stmt [1184,1286]
===
match
---
operator: , [33568,33569]
operator: , [33690,33691]
===
match
---
name: request [46528,46535]
name: request [46650,46657]
===
match
---
trailer [43687,43711]
trailer [43809,43833]
===
match
---
atom_expr [27809,27995]
atom_expr [27931,28117]
===
match
---
name: _file_paths [30974,30985]
name: _file_paths [31096,31107]
===
match
---
name: log [39062,39065]
name: log [39184,39187]
===
match
---
testlist_comp [8356,8713]
testlist_comp [8356,8713]
===
match
---
suite [16713,17249]
suite [16835,17371]
===
match
---
name: _parent_signal_conn [9462,9481]
name: _parent_signal_conn [9462,9481]
===
match
---
expr_stmt [7097,7140]
expr_stmt [7097,7140]
===
match
---
name: list_mode [43124,43133]
name: list_mode [43246,43255]
===
match
---
simple_stmt [1069,1105]
simple_stmt [1069,1105]
===
match
---
name: target [8279,8285]
name: target [8279,8285]
===
match
---
name: _processors [38734,38745]
name: _processors [38856,38867]
===
match
---
expr_stmt [36505,36543]
expr_stmt [36627,36665]
===
match
---
atom_expr [19990,20040]
atom_expr [20112,20162]
===
match
---
name: self [21070,21074]
name: self [21192,21196]
===
match
---
trailer [47826,47836]
trailer [47948,47958]
===
match
---
argument [48904,48960]
argument [49026,49082]
===
match
---
name: self [20546,20550]
name: self [20668,20672]
===
match
---
atom_expr [41204,41332]
atom_expr [41326,41454]
===
match
---
name: DM [45753,45755]
name: DM [45875,45877]
===
match
---
string: """Launch the process to process the file""" [2487,2531]
string: """Launch the process to process the file""" [2487,2531]
===
match
---
trailer [14326,14335]
trailer [14448,14457]
===
match
---
operator: = [13983,13984]
operator: = [14105,14106]
===
match
---
atom_expr [33086,33137]
atom_expr [33208,33259]
===
match
---
name: local_task_job [45314,45328]
name: local_task_job [45436,45450]
===
match
---
string: "Started a process (PID: %s) to generate tasks for %s" [41496,41550]
string: "Started a process (PID: %s) to generate tasks for %s" [41618,41672]
===
match
---
name: bool [3448,3452]
name: bool [3448,3452]
===
match
---
string: "Failing jobs without heartbeat after %s" [45639,45680]
string: "Failing jobs without heartbeat after %s" [45761,45802]
===
match
---
name: SlaCallbackRequest [10813,10831]
name: SlaCallbackRequest [10813,10831]
===
match
---
operator: , [13103,13104]
operator: , [13225,13226]
===
match
---
operator: @ [15976,15977]
operator: @ [16098,16099]
===
match
---
atom_expr [20006,20032]
atom_expr [20128,20154]
===
match
---
argument [46318,46340]
argument [46440,46462]
===
match
---
name: _parent_signal_conn [13990,14009]
name: _parent_signal_conn [14112,14131]
===
match
---
simple_stmt [12422,12483]
simple_stmt [12544,12605]
===
match
---
name: self [27703,27707]
name: self [27825,27829]
===
match
---
trailer [30785,30809]
trailer [30907,30931]
===
match
---
string: '\n' [23044,23048]
string: '\n' [23166,23170]
===
match
---
simple_stmt [2072,2161]
simple_stmt [2072,2161]
===
match
---
name: commit [31849,31855]
name: commit [31971,31977]
===
match
---
name: self [20215,20219]
name: self [20337,20341]
===
match
---
name: self [7097,7101]
name: self [7097,7101]
===
match
---
operator: = [21222,21223]
operator: = [21344,21345]
===
match
---
trailer [31347,31349]
trailer [31469,31471]
===
match
---
simple_stmt [39549,39856]
simple_stmt [39671,39978]
===
match
---
operator: , [39598,39599]
operator: , [39720,39721]
===
match
---
operator: + [34674,34675]
operator: + [34796,34797]
===
match
---
trailer [15695,15701]
trailer [15817,15823]
===
match
---
suite [44590,44772]
suite [44712,44894]
===
match
---
operator: , [11938,11939]
operator: , [12060,12061]
===
match
---
simple_stmt [9711,9716]
simple_stmt [9711,9716]
===
match
---
trailer [37443,37454]
trailer [37565,37576]
===
match
---
name: _file_paths [30815,30826]
name: _file_paths [30937,30948]
===
match
---
atom_expr [39801,39840]
atom_expr [39923,39962]
===
match
---
operator: , [21990,21991]
operator: , [22112,22113]
===
match
---
trailer [39749,39760]
trailer [39871,39882]
===
match
---
trailer [42833,42835]
trailer [42955,42957]
===
match
---
decorated [4442,4633]
decorated [4442,4633]
===
match
---
name: file_path [47103,47112]
name: file_path [47225,47234]
===
match
---
trailer [37420,37432]
trailer [37542,37554]
===
match
---
expr_stmt [44607,44771]
expr_stmt [44729,44893]
===
match
---
name: _processor_timeout [15303,15321]
name: _processor_timeout [15425,15443]
===
match
---
name: DagParsingSignal [25046,25062]
name: DagParsingSignal [25168,25184]
===
match
---
trailer [12114,12119]
trailer [12236,12241]
===
match
---
trailer [47199,47201]
trailer [47321,47323]
===
match
---
atom_expr [14200,14225]
atom_expr [14322,14347]
===
match
---
name: child_signal_conn [8595,8612]
name: child_signal_conn [8595,8612]
===
match
---
exprlist [33971,34040]
exprlist [34093,34162]
===
match
---
parameters [28969,29001]
parameters [29091,29123]
===
match
---
name: emit_metrics [26826,26838]
name: emit_metrics [26948,26960]
===
match
---
suite [38911,38982]
suite [39033,39104]
===
match
---
name: self [7149,7153]
name: self [7149,7153]
===
match
---
fstring_expr [33556,33567]
fstring_expr [33678,33689]
===
match
---
if_stmt [16827,16932]
if_stmt [16949,17054]
===
match
---
simple_stmt [28685,28691]
simple_stmt [28807,28813]
===
match
---
parameters [39933,39939]
parameters [40055,40061]
===
match
---
suite [39330,39540]
suite [39452,39662]
===
match
---
trailer [42842,42865]
trailer [42964,42987]
===
match
---
atom [18913,18941]
atom [19035,19063]
===
match
---
simple_stmt [35113,35152]
simple_stmt [35235,35274]
===
match
---
operator: = [7826,7827]
operator: = [7826,7827]
===
match
---
name: processor_timeout [6805,6822]
name: processor_timeout [6805,6822]
===
match
---
name: self [31680,31684]
name: self [31802,31806]
===
match
---
name: sep [33128,33131]
name: sep [33250,33253]
===
match
---
trailer [7739,7766]
trailer [7739,7766]
===
match
---
name: file_name [33557,33566]
name: file_name [33679,33688]
===
match
---
name: dag_directory [13333,13346]
name: dag_directory [13455,13468]
===
match
---
operator: = [46190,46191]
operator: = [46312,46313]
===
match
---
suite [29002,29660]
suite [29124,29782]
===
match
---
param [35830,35839]
param [35952,35961]
===
match
---
suite [14393,14435]
suite [14515,14557]
===
match
---
comparison [38401,38428]
comparison [38523,38550]
===
match
---
trailer [28761,28771]
trailer [28883,28893]
===
match
---
name: self [4277,4281]
name: self [4277,4281]
===
match
---
name: debug [23143,23148]
name: debug [23265,23270]
===
match
---
name: Callable [1223,1231]
name: Callable [1223,1231]
===
match
---
operator: = [22137,22138]
operator: = [22259,22260]
===
match
---
atom_expr [7375,7417]
atom_expr [7375,7417]
===
match
---
name: DagFileProcessorManager [17257,17280]
name: DagFileProcessorManager [17379,17402]
===
match
---
suite [27044,27452]
suite [27166,27574]
===
match
---
name: stat [36105,36109]
name: stat [36227,36231]
===
match
---
import_from [2029,2071]
import_from [2029,2071]
===
match
---
name: self [11152,11156]
name: self [11152,11156]
===
match
---
name: os [33034,33036]
name: os [33156,33158]
===
match
---
simple_stmt [12794,12849]
simple_stmt [12916,12971]
===
match
---
suite [48043,48129]
suite [48165,48251]
===
match
---
trailer [45755,45763]
trailer [45877,45885]
===
match
---
trailer [26517,26534]
trailer [26639,26656]
===
match
---
comparison [39226,39254]
comparison [39348,39376]
===
match
---
atom_expr [43461,43475]
atom_expr [43583,43597]
===
match
---
name: property [4443,4451]
name: property [4443,4451]
===
match
---
name: num_dags [33996,34004]
name: num_dags [34118,34126]
===
match
---
trailer [45074,45076]
trailer [45196,45198]
===
match
---
trailer [31796,31803]
trailer [31918,31925]
===
match
---
operator: , [33994,33995]
operator: , [34116,34117]
===
match
---
operator: , [32722,32723]
operator: , [32844,32845]
===
match
---
param [39023,39028]
param [39145,39150]
===
match
---
name: self [9386,9390]
name: self [9386,9390]
===
match
---
trailer [44197,44201]
trailer [44319,44323]
===
match
---
string: "Finished terminating DAG processors." [23149,23187]
string: "Finished terminating DAG processors." [23271,23309]
===
match
---
trailer [33517,33582]
trailer [33639,33704]
===
match
---
atom_expr [45850,45859]
atom_expr [45972,45981]
===
match
---
suite [40150,40482]
suite [40272,40604]
===
match
---
name: sigkill [2613,2620]
name: sigkill [2613,2620]
===
match
---
param [29686,29690]
param [29808,29812]
===
match
---
name: ti [46402,46404]
name: ti [46524,46526]
===
match
---
number: 1 [39513,39514]
number: 1 [39635,39636]
===
match
---
name: self [25555,25559]
name: self [25677,25681]
===
match
---
expr_stmt [46161,46209]
expr_stmt [46283,46331]
===
match
---
simple_stmt [44781,44832]
simple_stmt [44903,44954]
===
match
---
string: "modified_time" [42314,42329]
string: "modified_time" [42436,42451]
===
match
---
name: file_path [41245,41254]
name: file_path [41367,41376]
===
match
---
name: is_alive [16457,16465]
name: is_alive [16579,16587]
===
match
---
operator: = [43044,43045]
operator: = [43166,43167]
===
match
---
trailer [40653,40676]
trailer [40775,40798]
===
match
---
name: pop [40928,40931]
name: pop [41050,41053]
===
match
---
name: time [15213,15217]
name: time [15335,15339]
===
match
---
trailer [15647,15656]
trailer [15769,15778]
===
match
---
operator: , [37502,37503]
operator: , [37624,37625]
===
match
---
funcdef [2593,2754]
funcdef [2593,2754]
===
match
---
name: exit_code [39454,39463]
name: exit_code [39576,39585]
===
match
---
comp_if [44066,44107]
comp_if [44188,44229]
===
match
---
operator: = [13935,13936]
operator: = [14057,14058]
===
match
---
name: self [44155,44159]
name: self [44277,44281]
===
match
---
simple_stmt [31841,31858]
simple_stmt [31963,31980]
===
match
---
name: zombies [45707,45714]
name: zombies [45829,45836]
===
match
---
arith_expr [31148,31192]
arith_expr [31270,31314]
===
match
---
name: utils [1977,1982]
name: utils [1977,1982]
===
match
---
decorator [3396,3406]
decorator [3396,3406]
===
match
---
import_as_names [1800,1856]
import_as_names [1800,1856]
===
match
---
comparison [20127,20175]
comparison [20249,20297]
===
match
---
operator: @ [3410,3411]
operator: @ [3410,3411]
===
match
---
name: file_path [41169,41178]
name: file_path [41291,41300]
===
match
---
name: file_paths [43033,43043]
name: file_paths [43155,43165]
===
match
---
operator: , [46069,46070]
operator: , [46191,46192]
===
match
---
trailer [23704,23784]
trailer [23826,23906]
===
match
---
trailer [10703,10723]
trailer [10703,10723]
===
match
---
atom_expr [15855,15880]
atom_expr [15977,16002]
===
match
---
atom_expr [22362,22379]
atom_expr [22484,22501]
===
match
---
simple_stmt [39343,39478]
simple_stmt [39465,39600]
===
match
---
trailer [47143,47147]
trailer [47265,47269]
===
match
---
suite [14448,14545]
suite [14570,14667]
===
match
---
name: _zombie_threshold_secs [20922,20944]
name: _zombie_threshold_secs [21044,21066]
===
match
---
trailer [23014,23081]
trailer [23136,23203]
===
match
---
atom_expr [30092,30111]
atom_expr [30214,30233]
===
match
---
name: pathlib [2279,2286]
name: pathlib [2279,2286]
===
match
---
name: configuration [1455,1468]
name: configuration [1455,1468]
===
match
---
operator: { [42250,42251]
operator: { [42372,42373]
===
match
---
arglist [23579,23583]
arglist [23701,23705]
===
match
---
trailer [29644,29658]
trailer [29766,29780]
===
match
---
trailer [14523,14532]
trailer [14645,14654]
===
match
---
operator: @ [2573,2574]
operator: @ [2573,2574]
===
match
---
name: self [3439,3443]
name: self [3439,3443]
===
match
---
name: log_str [34489,34496]
name: log_str [34611,34618]
===
match
---
trailer [41460,41466]
trailer [41582,41588]
===
match
---
name: self [30196,30200]
name: self [30318,30322]
===
match
---
trailer [45629,45633]
trailer [45751,45755]
===
match
---
suite [2802,2929]
suite [2802,2929]
===
match
---
operator: < [31118,31119]
operator: < [31240,31241]
===
match
---
name: int [3734,3737]
name: int [3734,3737]
===
match
---
name: Connection [1144,1154]
name: Connection [1144,1154]
===
match
---
trailer [36132,36143]
trailer [36254,36265]
===
match
---
name: message [14327,14334]
name: message [14449,14456]
===
match
---
trailer [22238,22248]
trailer [22360,22370]
===
match
---
suite [22819,23216]
suite [22941,23338]
===
match
---
if_stmt [44553,44772]
if_stmt [44675,44894]
===
match
---
name: CallbackRequest [9765,9780]
name: CallbackRequest [9765,9780]
===
match
---
param [11906,11997]
param [12028,12119]
===
match
---
name: timedelta [12025,12034]
name: timedelta [12147,12156]
===
match
---
trailer [31768,31780]
trailer [31890,31902]
===
match
---
name: self [45106,45110]
name: self [45228,45232]
===
match
---
trailer [42178,42182]
trailer [42300,42304]
===
match
---
tfpdef [12130,12147]
tfpdef [12252,12269]
===
match
---
operator: = [12840,12841]
operator: = [12962,12963]
===
match
---
atom_expr [43580,43604]
atom_expr [43702,43726]
===
match
---
trailer [2926,2928]
trailer [2926,2928]
===
match
---
trailer [11355,11369]
trailer [11473,11487]
===
match
---
name: SimpleTaskInstance [1626,1644]
name: SimpleTaskInstance [1626,1644]
===
match
---
parameters [23994,24000]
parameters [24116,24122]
===
match
---
operator: -> [39940,39942]
operator: -> [40062,40064]
===
match
---
trailer [15159,15164]
trailer [15281,15286]
===
match
---
name: self [15232,15236]
name: self [15354,15358]
===
match
---
expr_stmt [13976,14016]
expr_stmt [14098,14138]
===
match
---
simple_stmt [23936,23968]
simple_stmt [24058,24090]
===
match
---
name: Dict [7375,7379]
name: Dict [7375,7379]
===
match
---
name: start_time [39750,39760]
name: start_time [39872,39882]
===
match
---
name: duration [46922,46930]
name: duration [47044,47052]
===
match
---
trailer [7832,7842]
trailer [7832,7842]
===
match
---
suite [16013,16089]
suite [16135,16211]
===
match
---
simple_stmt [41481,41578]
simple_stmt [41603,41700]
===
match
---
trailer [44623,44634]
trailer [44745,44756]
===
match
---
atom_expr [39820,39839]
atom_expr [39942,39961]
===
match
---
name: DagParsingSignal [4996,5012]
name: DagParsingSignal [4996,5012]
===
match
---
operator: = [32911,32912]
operator: = [33033,33034]
===
match
---
name: _process [17118,17126]
name: _process [17240,17248]
===
match
---
string: """         Use multiple processes to parse and generate tasks for the         DAGs in parallel. By processing them in separate processes,         we can get parallelism and isolation from potentially harmful         user code.         """ [23246,23485]
string: """         Use multiple processes to parse and generate tasks for the         DAGs in parallel. By processing them in separate processes,         we can get parallelism and isolation from potentially harmful         user code.         """ [23368,23607]
===
match
---
atom_expr [22568,22582]
atom_expr [22690,22704]
===
match
---
trailer [35763,35777]
trailer [35885,35899]
===
match
---
atom_expr [39130,39168]
atom_expr [39252,39290]
===
match
---
trailer [41404,41409]
trailer [41526,41531]
===
match
---
expr_stmt [45707,46147]
expr_stmt [45829,46269]
===
match
---
trailer [3733,3743]
trailer [3733,3743]
===
match
---
suite [36238,36596]
suite [36360,36718]
===
match
---
suite [24945,25009]
suite [25067,25131]
===
match
---
name: self [40906,40910]
name: self [41028,41032]
===
match
---
tfpdef [18985,19013]
tfpdef [19107,19135]
===
match
---
trailer [22150,22156]
trailer [22272,22278]
===
match
---
name: self [23000,23004]
name: self [23122,23126]
===
match
---
trailer [38733,38745]
trailer [38855,38867]
===
match
---
atom_expr [41350,41386]
atom_expr [41472,41508]
===
match
---
file_input [787,49085]
file_input [787,49207]
===
match
---
testlist_star_expr [39268,39297]
testlist_star_expr [39390,39419]
===
match
---
operator: , [1516,1517]
operator: , [1516,1517]
===
match
---
name: _parent_signal_conn [10013,10032]
name: _parent_signal_conn [10013,10032]
===
match
---
name: self [7063,7067]
name: self [7063,7067]
===
match
---
operator: = [7533,7534]
operator: = [7533,7534]
===
match
---
return_stmt [37463,37474]
return_stmt [37585,37596]
===
match
---
operator: , [1255,1256]
operator: , [1255,1256]
===
match
---
trailer [41147,41168]
trailer [41269,41290]
===
match
---
operator: , [34263,34264]
operator: , [34385,34386]
===
match
---
name: getLogger [22186,22195]
name: getLogger [22308,22317]
===
match
---
name: file_path [34123,34132]
name: file_path [34245,34254]
===
match
---
comparison [42795,42865]
comparison [42917,42987]
===
match
---
name: self [22234,22238]
name: self [22356,22360]
===
match
---
suite [46250,46635]
suite [46372,46757]
===
match
---
name: stat [36176,36180]
name: stat [36298,36302]
===
match
---
name: _processors [37384,37395]
name: _processors [37506,37517]
===
match
---
decorated [44837,46635]
decorated [44959,46757]
===
match
---
dotted_name [1694,1707]
dotted_name [1694,1707]
===
match
---
operator: } [42251,42252]
operator: } [42373,42374]
===
match
---
simple_stmt [44900,45045]
simple_stmt [45022,45167]
===
match
---
trailer [33245,33256]
trailer [33367,33378]
===
match
---
atom_expr [30476,30514]
atom_expr [30598,30636]
===
match
---
tfpdef [19071,19099]
tfpdef [19193,19221]
===
match
---
operator: = [45715,45716]
operator: = [45837,45838]
===
match
---
name: self [6591,6595]
name: self [6591,6595]
===
match
---
operator: = [19610,19611]
operator: = [19732,19733]
===
match
---
operator: - [40827,40828]
operator: - [40949,40950]
===
match
---
name: signal_conn [13444,13455]
name: signal_conn [13566,13577]
===
match
---
trailer [47714,47716]
trailer [47836,47838]
===
match
---
trailer [19271,19276]
trailer [19393,19398]
===
match
---
name: getint [20775,20781]
name: getint [20897,20903]
===
match
---
name: _dag_ids [8635,8643]
name: _dag_ids [8635,8643]
===
match
---
param [36221,36226]
param [36343,36348]
===
match
---
atom_expr [11277,11311]
atom_expr [11277,11311]
===
match
---
trailer [24451,24471]
trailer [24573,24593]
===
match
---
number: 0 [13108,13109]
number: 0 [13230,13231]
===
match
---
simple_stmt [26087,26096]
simple_stmt [26209,26218]
===
match
---
name: self [15155,15159]
name: self [15277,15281]
===
match
---
fstring_end: " [14542,14543]
fstring_end: " [14664,14665]
===
match
---
expr_stmt [43033,43110]
expr_stmt [43155,43232]
===
match
---
simple_stmt [7273,7303]
simple_stmt [7273,7303]
===
match
---
atom_expr [19596,19609]
atom_expr [19718,19731]
===
match
---
name: pickle_dags [19109,19120]
name: pickle_dags [19231,19242]
===
match
---
annassign [4723,4729]
annassign [4723,4729]
===
match
---
trailer [39567,39855]
trailer [39689,39977]
===
match
---
atom_expr [43684,43796]
atom_expr [43806,43918]
===
match
---
trailer [47695,47707]
trailer [47817,47829]
===
match
---
comparison [43124,43151]
comparison [43246,43273]
===
match
---
trailer [15134,15140]
trailer [15256,15262]
===
match
---
expr_stmt [34489,34713]
expr_stmt [34611,34835]
===
match
---
simple_stmt [41590,41630]
simple_stmt [41712,41752]
===
match
---
operator: , [12082,12083]
operator: , [12204,12205]
===
match
---
name: mixins [1983,1989]
name: mixins [1983,1989]
===
match
---
param [6591,6596]
param [6591,6596]
===
match
---
expr_stmt [7663,7695]
expr_stmt [7663,7695]
===
match
---
atom_expr [15155,15164]
atom_expr [15277,15286]
===
match
---
string: 'sql_alchemy_conn' [20156,20174]
string: 'sql_alchemy_conn' [20278,20296]
===
match
---
name: self [15033,15037]
name: self [15155,15159]
===
match
---
operator: < [31146,31147]
operator: < [31268,31269]
===
match
---
parameters [48413,48419]
parameters [48535,48541]
===
match
---
name: self [40380,40384]
name: self [40502,40506]
===
match
---
atom_expr [36925,36956]
atom_expr [37047,37078]
===
match
---
name: now [29783,29786]
name: now [29905,29908]
===
match
---
name: self [46831,46835]
name: self [46953,46957]
===
match
---
expr_stmt [40023,40118]
expr_stmt [40145,40240]
===
match
---
trailer [46207,46209]
trailer [46329,46331]
===
match
---
fstring_string: Unexpected message received of type  [14482,14518]
fstring_string: Unexpected message received of type  [14604,14640]
===
match
---
name: log [34728,34731]
name: log [34850,34853]
===
match
---
simple_stmt [45053,45077]
simple_stmt [45175,45199]
===
match
---
trailer [29896,29898]
trailer [30018,30020]
===
match
---
name: self [48807,48811]
name: self [48929,48933]
===
match
---
name: self [2464,2468]
name: self [2464,2468]
===
match
---
simple_stmt [31436,31619]
simple_stmt [31558,31741]
===
match
---
simple_stmt [12396,12413]
simple_stmt [12518,12535]
===
match
---
name: self [16132,16136]
name: self [16254,16258]
===
match
---
trailer [22697,22704]
trailer [22819,22826]
===
match
---
atom_expr [42838,42865]
atom_expr [42960,42987]
===
match
---
funcdef [29665,30987]
funcdef [29787,31109]
===
match
---
name: Stats [33623,33628]
name: Stats [33745,33750]
===
match
---
string: """         :param file_path: the path to the file that's being processed         :type file_path: unicode         :return: the start time of the process that's processing the             specified file or None if the file is not currently being processed         :rtype: datetime         """ [37062,37354]
string: """         :param file_path: the path to the file that's being processed         :type file_path: unicode         :return: the start time of the process that's processing the             specified file or None if the file is not currently being processed         :rtype: datetime         """ [37184,37476]
===
match
---
argument [17132,17143]
argument [17254,17265]
===
match
---
atom_expr [7496,7531]
atom_expr [7496,7531]
===
match
---
funcdef [23973,28938]
funcdef [24095,29060]
===
match
---
arglist [23705,23783]
arglist [23827,23905]
===
match
---
trailer [22527,22544]
trailer [22649,22666]
===
match
---
name: _parallelism [23669,23681]
name: _parallelism [23791,23803]
===
match
---
name: file_path [44506,44515]
name: file_path [44628,44637]
===
match
---
name: self [14823,14827]
name: self [14945,14949]
===
match
---
annassign [19265,19281]
annassign [19387,19403]
===
match
---
name: reverse [43097,43104]
name: reverse [43219,43226]
===
match
---
param [31418,31425]
param [31540,31547]
===
match
---
trailer [43584,43596]
trailer [43706,43718]
===
match
---
name: self [38689,38693]
name: self [38811,38815]
===
match
---
simple_stmt [31305,31350]
simple_stmt [31427,31472]
===
match
---
suite [29692,30987]
suite [29814,31109]
===
match
---
name: self [35712,35716]
name: self [35834,35838]
===
match
---
atom_expr [14406,14434]
atom_expr [14528,14556]
===
match
---
atom_expr [30287,30308]
atom_expr [30409,30430]
===
match
---
funcdef [11819,13572]
funcdef [11941,13694]
===
match
---
name: State [45998,46003]
name: State [46120,46125]
===
match
---
name: wait [40058,40062]
name: wait [40180,40184]
===
match
---
name: settings [1658,1666]
name: settings [1658,1666]
===
match
---
atom_expr [47822,47836]
atom_expr [47944,47958]
===
match
---
trailer [31723,31730]
trailer [31845,31852]
===
match
---
expr_stmt [26988,27006]
expr_stmt [27110,27128]
===
match
---
simple_stmt [37463,37475]
simple_stmt [37585,37597]
===
match
---
name: monotonic [15959,15968]
name: monotonic [16081,16090]
===
match
---
operator: , [34295,34296]
operator: , [34417,34418]
===
match
---
name: strftime [34396,34404]
name: strftime [34518,34526]
===
match
---
operator: = [36110,36111]
operator: = [36232,36233]
===
match
---
atom_expr [33125,33131]
atom_expr [33247,33253]
===
match
---
name: DagParsingSignal [16601,16617]
name: DagParsingSignal [16723,16739]
===
match
---
expr_stmt [45492,45520]
expr_stmt [45614,45642]
===
match
---
name: Stats [47292,47297]
name: Stats [47414,47419]
===
match
---
string: 'AIRFLOW__LOGGING__COLORED_CONSOLE_LOG' [12868,12907]
string: 'AIRFLOW__LOGGING__COLORED_CONSOLE_LOG' [12990,13029]
===
match
---
import_name [868,890]
import_name [868,890]
===
match
---
name: self [15072,15076]
name: self [15194,15198]
===
match
---
comparison [38210,38229]
comparison [38332,38351]
===
match
---
atom_expr [44573,44589]
atom_expr [44695,44711]
===
match
---
name: _signal_conn [26168,26180]
name: _signal_conn [26290,26302]
===
match
---
operator: = [19231,19232]
operator: = [19353,19354]
===
match
---
trailer [30480,30512]
trailer [30602,30634]
===
match
---
param [33914,33915]
param [34036,34037]
===
match
---
name: List [6703,6707]
name: List [6703,6707]
===
match
---
simple_stmt [48683,48742]
simple_stmt [48805,48864]
===
match
---
trailer [10141,10150]
trailer [10141,10150]
===
match
---
trailer [40340,40367]
trailer [40462,40489]
===
match
---
operator: = [36923,36924]
operator: = [37045,37046]
===
match
---
exprlist [38336,38356]
exprlist [38458,38478]
===
match
---
name: List [19089,19093]
name: List [19211,19215]
===
match
---
name: str [19226,19229]
name: str [19348,19351]
===
match
---
trailer [13161,13170]
trailer [13283,13292]
===
match
---
atom_expr [37379,37395]
atom_expr [37501,37517]
===
match
---
simple_stmt [47292,47340]
simple_stmt [47414,47462]
===
match
---
name: files_with_mtime [43075,43091]
name: files_with_mtime [43197,43213]
===
match
---
operator: , [34767,34768]
operator: , [34889,34890]
===
match
---
name: file_path [35413,35422]
name: file_path [35535,35544]
===
match
---
name: self [29851,29855]
name: self [29973,29977]
===
match
---
name: self [42399,42403]
name: self [42521,42525]
===
match
---
arglist [48695,48740]
arglist [48817,48862]
===
match
---
name: DagParsingStat [27853,27867]
name: DagParsingStat [27975,27989]
===
match
---
operator: = [45450,45451]
operator: = [45572,45573]
===
match
---
expr_stmt [19532,19561]
expr_stmt [19654,19683]
===
match
---
atom_expr [8217,8231]
atom_expr [8217,8231]
===
match
---
atom_expr [31841,31857]
atom_expr [31963,31979]
===
match
---
atom_expr [15954,15970]
atom_expr [16076,16092]
===
match
---
name: self [24447,24451]
name: self [24569,24573]
===
match
---
simple_stmt [45296,45355]
simple_stmt [45418,45477]
===
match
---
name: union [43712,43717]
name: union [43834,43839]
===
match
---
arglist [20588,20628]
arglist [20710,20750]
===
match
---
name: headers [32644,32651]
name: headers [32766,32773]
===
match
---
operator: = [41858,41859]
operator: = [41980,41981]
===
match
---
expr_stmt [38299,38323]
expr_stmt [38421,38445]
===
match
---
name: start [15696,15701]
name: start [15818,15823]
===
match
---
name: file_path [4267,4276]
name: file_path [4267,4276]
===
match
---
operator: = [7993,7994]
operator: = [7993,7994]
===
match
---
arglist [25967,26051]
arglist [26089,26173]
===
match
---
name: kill [2783,2787]
name: kill [2783,2787]
===
match
---
name: debug [28408,28413]
name: debug [28530,28535]
===
match
---
trailer [14677,14697]
trailer [14799,14819]
===
match
---
trailer [40077,40082]
trailer [40199,40204]
===
match
---
number: 0 [40853,40854]
number: 0 [40975,40976]
===
match
---
trailer [11437,11442]
trailer [11555,11560]
===
match
---
name: dag_directory [6605,6618]
name: dag_directory [6605,6618]
===
match
---
name: self [24797,24801]
name: self [24919,24923]
===
match
---
operator: } [38322,38323]
operator: } [38444,38445]
===
match
---
trailer [20450,20463]
trailer [20572,20585]
===
match
---
classdef [2289,4633]
classdef [2289,4633]
===
match
---
string: 'fetch' [31824,31831]
string: 'fetch' [31946,31953]
===
match
---
name: bool [4755,4759]
name: bool [4755,4759]
===
match
---
name: is_alive [9400,9408]
name: is_alive [9400,9408]
===
match
---
simple_stmt [4973,4988]
simple_stmt [4973,4988]
===
match
---
name: _process [14790,14798]
name: _process [14912,14920]
===
match
---
try_stmt [9440,9716]
try_stmt [9440,9716]
===
match
---
name: self [22166,22170]
name: self [22288,22292]
===
match
---
operator: = [7078,7079]
operator: = [7078,7079]
===
match
---
trailer [6957,6959]
trailer [6957,6959]
===
match
---
string: """Launch DagFileProcessorManager processor and start DAG parsing loop in manager.""" [7883,7968]
string: """Launch DagFileProcessorManager processor and start DAG parsing loop in manager.""" [7883,7968]
===
match
---
name: abstractmethod [2760,2774]
name: abstractmethod [2760,2774]
===
match
---
name: self [29605,29609]
name: self [29727,29731]
===
match
---
name: session [31418,31425]
name: session [31540,31547]
===
match
---
param [14252,14257]
param [14374,14379]
===
match
---
simple_stmt [21685,21718]
simple_stmt [21807,21840]
===
match
---
trailer [36563,36577]
trailer [36685,36699]
===
match
---
operator: , [43760,43761]
operator: , [43882,43883]
===
match
---
trailer [32777,32784]
trailer [32899,32906]
===
match
---
name: query [31627,31632]
name: query [31749,31754]
===
match
---
simple_stmt [40213,40222]
simple_stmt [40335,40344]
===
match
---
operator: @ [3665,3666]
operator: @ [3665,3666]
===
match
---
try_stmt [16550,16694]
try_stmt [16672,16816]
===
match
---
name: Union [22260,22265]
name: Union [22382,22387]
===
match
---
name: last_finish_time [39721,39737]
name: last_finish_time [39843,39859]
===
match
---
arglist [14291,14344]
arglist [14413,14466]
===
match
---
if_stmt [9264,9371]
if_stmt [9264,9371]
===
match
---
argument [15662,15677]
argument [15784,15799]
===
match
---
atom_expr [22250,22326]
atom_expr [22372,22448]
===
match
---
name: _file_paths [30130,30141]
name: _file_paths [30252,30263]
===
match
---
trailer [38111,38123]
trailer [38233,38245]
===
match
---
name: heartbeat [13581,13590]
name: heartbeat [13703,13712]
===
match
---
operator: , [8513,8514]
operator: , [8513,8514]
===
match
---
name: TI [45791,45793]
name: TI [45913,45915]
===
match
---
trailer [23578,23584]
trailer [23700,23706]
===
match
---
simple_stmt [24200,24224]
simple_stmt [24322,24346]
===
match
---
name: self [46933,46937]
name: self [47055,47059]
===
match
---
fstring_start: f' [33636,33638]
fstring_start: f' [33758,33760]
===
match
---
name: _processors [48022,48033]
name: _processors [48144,48155]
===
match
---
name: self [9303,9307]
name: self [9303,9307]
===
match
---
operator: = [8052,8053]
operator: = [8052,8053]
===
match
---
name: limit_dttm [46059,46069]
name: limit_dttm [46181,46191]
===
match
---
atom_expr [27653,27681]
atom_expr [27775,27803]
===
match
---
atom_expr [23568,23584]
atom_expr [23690,23706]
===
match
---
trailer [24204,24221]
trailer [24326,24343]
===
match
---
parameters [39022,39039]
parameters [39144,39161]
===
match
---
name: self [33167,33171]
name: self [33289,33293]
===
match
---
tfpdef [18811,18852]
tfpdef [18933,18974]
===
match
---
simple_stmt [43991,44118]
simple_stmt [44113,44240]
===
match
---
name: file_paths [42556,42566]
name: file_paths [42678,42688]
===
match
---
trailer [44201,44207]
trailer [44323,44329]
===
match
---
trailer [7552,7558]
trailer [7552,7558]
===
match
---
name: start_new_processes [24452,24471]
name: start_new_processes [24574,24593]
===
match
---
name: _file_stats [36117,36128]
name: _file_stats [36239,36250]
===
match
---
name: time [947,951]
name: time [947,951]
===
match
---
atom_expr [24755,24779]
atom_expr [24877,24901]
===
match
---
decorator [4243,4259]
decorator [4243,4259]
===
match
---
param [23995,23999]
param [24117,24121]
===
match
---
simple_stmt [3192,3355]
simple_stmt [3192,3355]
===
match
---
trailer [24700,24713]
trailer [24822,24835]
===
match
---
atom_expr [27853,27977]
atom_expr [27975,28099]
===
match
---
name: timezone [42079,42087]
name: timezone [42201,42209]
===
match
---
simple_stmt [13761,13802]
simple_stmt [13883,13924]
===
match
---
name: _add_callback_to_queue [25384,25406]
name: _add_callback_to_queue [25506,25528]
===
match
---
name: log [23696,23699]
name: log [23818,23821]
===
match
---
tfpdef [9756,9780]
tfpdef [9756,9780]
===
match
---
suite [38385,38721]
suite [38507,38843]
===
match
---
for_stmt [40128,40482]
for_stmt [40250,40604]
===
match
---
operator: , [11570,11571]
operator: , [11689,11690]
===
match
---
operator: , [8319,8320]
operator: , [8319,8320]
===
match
---
atom_expr [33623,33689]
atom_expr [33745,33811]
===
match
---
param [2464,2468]
param [2464,2468]
===
match
---
atom_expr [3169,3182]
atom_expr [3169,3182]
===
match
---
name: _parent_signal_conn [10117,10136]
name: _parent_signal_conn [10117,10136]
===
match
---
name: airflow [1726,1733]
name: airflow [1726,1733]
===
match
---
simple_stmt [36918,36957]
simple_stmt [37040,37079]
===
match
---
atom_expr [38729,38745]
atom_expr [38851,38867]
===
match
---
operator: = [2336,2337]
operator: = [2336,2337]
===
match
---
parameters [15727,15739]
parameters [15849,15861]
===
match
---
annassign [4864,4869]
annassign [4864,4869]
===
match
---
simple_stmt [13546,13572]
simple_stmt [13668,13694]
===
match
---
name: monotonic [24530,24539]
name: monotonic [24652,24661]
===
match
---
string: "=" [34695,34698]
string: "=" [34817,34820]
===
match
---
operator: , [43069,43070]
operator: , [43191,43192]
===
match
---
trailer [41656,41683]
trailer [41778,41805]
===
match
---
name: self [31120,31124]
name: self [31242,31246]
===
match
---
trailer [39829,39839]
trailer [39951,39961]
===
match
---
name: file_path [33391,33400]
name: file_path [33513,33522]
===
match
---
trailer [40499,40505]
trailer [40621,40627]
===
match
---
name: reap_process_group [15624,15642]
name: reap_process_group [15746,15764]
===
match
---
operator: @ [2434,2435]
operator: @ [2434,2435]
===
match
---
operator: = [22327,22328]
operator: = [22449,22450]
===
match
---
name: start [13564,13569]
name: start [13686,13691]
===
match
---
name: processor [41451,41460]
name: processor [41573,41582]
===
match
---
trailer [26534,26536]
trailer [26656,26658]
===
match
---
simple_stmt [30777,30828]
simple_stmt [30899,30950]
===
match
---
trailer [48755,48761]
trailer [48877,48883]
===
match
---
trailer [47472,47477]
trailer [47594,47599]
===
match
---
name: stat [36159,36163]
name: stat [36281,36285]
===
match
---
operator: , [39844,39845]
operator: , [39966,39967]
===
match
---
trailer [33127,33131]
trailer [33249,33253]
===
match
---
name: poll_time [24132,24141]
name: poll_time [24254,24263]
===
match
---
operator: @ [49017,49018]
operator: @ [49139,49140]
===
match
---
atom_expr [13180,13209]
atom_expr [13302,13331]
===
match
---
trailer [27826,27831]
trailer [27948,27953]
===
match
---
name: last_dag_dir_refresh_time [30201,30226]
name: last_dag_dir_refresh_time [30323,30348]
===
match
---
suite [6932,7845]
suite [6932,7845]
===
match
---
name: self [8696,8700]
name: self [8696,8700]
===
match
---
parameters [36220,36237]
parameters [36342,36359]
===
match
---
trailer [33390,33401]
trailer [33512,33523]
===
match
---
simple_stmt [2811,2893]
simple_stmt [2811,2893]
===
match
---
and_test [16425,16467]
and_test [16547,16589]
===
match
---
trailer [14798,14807]
trailer [14920,14929]
===
match
---
operator: , [8536,8537]
operator: , [8536,8537]
===
match
---
name: connection [40047,40057]
name: connection [40169,40179]
===
match
---
atom_expr [40322,40367]
atom_expr [40444,40489]
===
match
---
name: _done [15829,15834]
name: _done [15951,15956]
===
match
---
name: agent_signal [25327,25339]
name: agent_signal [25449,25461]
===
match
---
name: log [44395,44398]
name: log [44517,44520]
===
match
---
trailer [48021,48033]
trailer [48143,48155]
===
match
---
except_clause [9528,9550]
except_clause [9528,9550]
===
match
---
param [13591,13595]
param [13713,13717]
===
match
---
trailer [6948,6957]
trailer [6948,6957]
===
match
---
name: _async_mode [19965,19976]
name: _async_mode [20087,20098]
===
match
---
name: self [23134,23138]
name: self [23256,23260]
===
match
---
trailer [35340,35344]
trailer [35462,35466]
===
match
---
atom_expr [47691,47716]
atom_expr [47813,47838]
===
match
---
name: _file_path_queue [26787,26803]
name: _file_path_queue [26909,26925]
===
match
---
atom_expr [24910,24944]
atom_expr [25032,25066]
===
match
---
trailer [20550,20573]
trailer [20672,20695]
===
match
---
trailer [38660,38670]
trailer [38782,38792]
===
match
---
operator: , [40648,40649]
operator: , [40770,40771]
===
match
---
simple_stmt [27732,27775]
simple_stmt [27854,27897]
===
match
---
name: property [49018,49026]
name: property [49140,49148]
===
match
---
trailer [14280,14284]
trailer [14402,14406]
===
match
---
name: abstractmethod [3127,3141]
name: abstractmethod [3127,3141]
===
match
---
name: sentinel [26432,26440]
name: sentinel [26554,26562]
===
match
---
trailer [41305,41318]
trailer [41427,41440]
===
match
---
number: 0.0 [33925,33928]
number: 0.0 [34047,34050]
===
match
---
trailer [24529,24539]
trailer [24651,24661]
===
match
---
operator: , [42194,42195]
operator: , [42316,42317]
===
match
---
operator: , [14045,14046]
operator: , [14167,14168]
===
match
---
name: file_path [36227,36236]
name: file_path [36349,36358]
===
match
---
name: _signal_conn [24701,24713]
name: _signal_conn [24823,24835]
===
match
---
name: self [17216,17220]
name: self [17338,17342]
===
match
---
trailer [38189,38206]
trailer [38311,38328]
===
match
---
import_as_names [1508,1524]
import_as_names [1508,1524]
===
match
---
atom_expr [23869,23888]
atom_expr [23991,24010]
===
match
---
operator: = [24753,24754]
operator: = [24875,24876]
===
match
---
name: file_path [32999,33008]
name: file_path [33121,33130]
===
match
---
name: sqlalchemy [1367,1377]
name: sqlalchemy [1367,1377]
===
match
---
if_stmt [24099,24191]
if_stmt [24221,24313]
===
match
---
while_stmt [11320,11796]
while_stmt [11438,11918]
===
match
---
comparison [15279,15337]
comparison [15401,15459]
===
match
---
subscriptlist [21184,21220]
subscriptlist [21306,21342]
===
match
---
name: _signal_conn [24760,24772]
name: _signal_conn [24882,24894]
===
match
---
decorated [4229,4437]
decorated [4229,4437]
===
match
---
name: append [42927,42933]
name: append [43049,43055]
===
match
---
name: self [21236,21240]
name: self [21358,21362]
===
match
---
trailer [26825,26838]
trailer [26947,26960]
===
match
---
trailer [33088,33093]
trailer [33210,33215]
===
match
---
decorators [4229,4259]
decorators [4229,4259]
===
match
---
trailer [23598,23602]
trailer [23720,23724]
===
match
---
simple_stmt [25290,25295]
simple_stmt [25412,25417]
===
match
---
decorator [2434,2450]
decorator [2434,2450]
===
match
---
arith_expr [40063,40106]
arith_expr [40185,40228]
===
match
---
name: self [26349,26353]
name: self [26471,26475]
===
match
---
name: pids_to_kill [48378,48390]
name: pids_to_kill [48500,48512]
===
match
---
name: _max_runs [43631,43640]
name: _max_runs [43753,43762]
===
match
---
name: Stats [48683,48688]
name: Stats [48805,48810]
===
match
---
operator: , [31898,31899]
operator: , [32020,32021]
===
match
---
trailer [19604,19609]
trailer [19726,19731]
===
match
---
if_stmt [20124,20468]
if_stmt [20246,20590]
===
match
---
name: processor [38934,38943]
name: processor [39056,39065]
===
match
---
operator: = [17197,17198]
operator: = [17319,17320]
===
match
---
name: num_dags [39590,39598]
name: num_dags [39712,39720]
===
match
---
operator: = [39719,39720]
operator: = [39841,39842]
===
match
---
name: _num_run [21241,21249]
name: _num_run [21363,21371]
===
match
---
trailer [21338,21356]
trailer [21460,21478]
===
match
---
if_stmt [33414,33583]
if_stmt [33536,33705]
===
match
---
parameters [34762,34779]
parameters [34884,34901]
===
match
---
expr_stmt [38149,38230]
expr_stmt [38271,38352]
===
match
---
if_stmt [14666,14752]
if_stmt [14788,14874]
===
match
---
name: processor [44142,44151]
name: processor [44264,44273]
===
match
---
name: error [46983,46988]
name: error [47105,47110]
===
match
---
name: logging_mixin [1930,1943]
name: logging_mixin [1930,1943]
===
match
---
name: x [33914,33915]
name: x [34036,34037]
===
match
---
simple_stmt [8107,8162]
simple_stmt [8107,8162]
===
match
---
name: settings [13162,13170]
name: settings [13284,13292]
===
match
---
operator: , [6646,6647]
operator: , [6646,6647]
===
match
---
simple_stmt [2029,2072]
simple_stmt [2029,2072]
===
match
---
trailer [14789,14798]
trailer [14911,14920]
===
match
---
name: CallbackRequest [22119,22134]
name: CallbackRequest [22241,22256]
===
match
---
name: self [42041,42045]
name: self [42163,42167]
===
match
---
trailer [16600,16636]
trailer [16722,16758]
===
match
---
trailer [31152,31162]
trailer [31274,31284]
===
match
---
name: start_time [46896,46906]
name: start_time [47018,47028]
===
match
---
if_stmt [10692,10778]
if_stmt [10692,10778]
===
match
---
simple_stmt [29605,29660]
simple_stmt [29727,29782]
===
match
---
simple_stmt [30881,30924]
simple_stmt [31003,31046]
===
match
---
suite [28829,28880]
suite [28951,29002]
===
match
---
name: _async_mode [24280,24291]
name: _async_mode [24402,24413]
===
match
---
arglist [40251,40308]
arglist [40373,40430]
===
match
---
raise_stmt [14461,14544]
raise_stmt [14583,14666]
===
match
---
trailer [13927,13941]
trailer [14049,14063]
===
match
---
name: _async_mode [19537,19548]
name: _async_mode [19659,19670]
===
match
---
name: loop_duration [28811,28824]
name: loop_duration [28933,28946]
===
match
---
name: max_runs [6633,6641]
name: max_runs [6633,6641]
===
match
---
simple_stmt [24447,24474]
simple_stmt [24569,24596]
===
match
---
trailer [40610,40677]
trailer [40732,40799]
===
match
---
trailer [48854,48971]
trailer [48976,49093]
===
match
---
atom_expr [10888,10926]
atom_expr [10888,10926]
===
match
---
expr_stmt [5106,5145]
expr_stmt [5106,5145]
===
match
---
name: _kill_timed_out_processors [46644,46670]
name: _kill_timed_out_processors [46766,46792]
===
match
---
suite [14064,14087]
suite [14186,14209]
===
match
---
name: file_loc [46332,46340]
name: file_loc [46454,46462]
===
match
---
atom_expr [46831,46855]
atom_expr [46953,46977]
===
match
---
name: signal [22501,22507]
name: signal [22623,22629]
===
match
---
if_stmt [47730,47795]
if_stmt [47852,47917]
===
match
---
atom_expr [34387,34425]
atom_expr [34509,34547]
===
match
---
argument [44742,44753]
argument [44864,44875]
===
match
---
trailer [20580,20587]
trailer [20702,20709]
===
match
---
atom_expr [26513,26536]
atom_expr [26635,26658]
===
match
---
trailer [17131,17144]
trailer [17253,17266]
===
match
---
simple_stmt [10803,10876]
simple_stmt [10803,10876]
===
match
---
name: CallbackRequest [11945,11960]
name: CallbackRequest [12067,12082]
===
match
---
name: errors [1518,1524]
name: errors [1518,1524]
===
match
---
atom_expr [15916,15951]
atom_expr [16038,16073]
===
match
---
name: dag_id [10419,10425]
name: dag_id [10419,10425]
===
match
---
operator: = [15952,15953]
operator: = [16074,16075]
===
match
---
trailer [15361,15394]
trailer [15483,15516]
===
match
---
name: file_path [34769,34778]
name: file_path [34891,34900]
===
match
---
operator: , [41299,41300]
operator: , [41421,41422]
===
match
---
trailer [47302,47339]
trailer [47424,47461]
===
match
---
trailer [8818,8880]
trailer [8818,8880]
===
match
---
trailer [30053,30057]
trailer [30175,30179]
===
match
---
name: start_time [4054,4064]
name: start_time [4054,4064]
===
match
---
atom_expr [23134,23188]
atom_expr [23256,23310]
===
match
---
trailer [38908,38910]
trailer [39030,39032]
===
match
---
trailer [48126,48128]
trailer [48248,48250]
===
match
---
trailer [31213,31225]
trailer [31335,31347]
===
match
---
string: 'dag_processing.processes' [38607,38633]
string: 'dag_processing.processes' [38729,38755]
===
match
---
simple_stmt [4719,4730]
simple_stmt [4719,4730]
===
match
---
name: self [38185,38189]
name: self [38307,38311]
===
match
---
name: join [23049,23053]
name: join [23171,23175]
===
match
---
name: all_files_processed [15888,15907]
name: all_files_processed [16010,16029]
===
match
---
name: parsing_stat_age [15279,15295]
name: parsing_stat_age [15401,15417]
===
match
---
trailer [8175,8195]
trailer [8175,8195]
===
match
---
trailer [20231,20433]
trailer [20353,20555]
===
match
---
trailer [40438,40470]
trailer [40560,40592]
===
match
---
name: num_errors [34285,34295]
name: num_errors [34407,34417]
===
match
---
atom_expr [26349,26396]
atom_expr [26471,26518]
===
match
---
name: LocalTaskJob [45336,45348]
name: LocalTaskJob [45458,45470]
===
match
---
name: rows [33897,33901]
name: rows [34019,34023]
===
match
---
simple_stmt [24507,24542]
simple_stmt [24629,24664]
===
match
---
name: get_start_time [33231,33245]
name: get_start_time [33353,33367]
===
match
---
name: log [25934,25937]
name: log [26056,26059]
===
match
---
trailer [16617,16635]
trailer [16739,16757]
===
match
---
simple_stmt [7149,7193]
simple_stmt [7149,7193]
===
match
---
operator: , [36225,36226]
operator: , [36347,36348]
===
match
---
name: Any [1218,1221]
name: Any [1218,1221]
===
match
---
name: self [19368,19372]
name: self [19490,19494]
===
match
---
name: self [24966,24970]
name: self [25088,25092]
===
match
---
name: self [20917,20921]
name: self [21039,21043]
===
match
---
simple_stmt [19532,19562]
simple_stmt [19654,19684]
===
match
---
name: prepare_file_path_queue [26862,26885]
name: prepare_file_path_queue [26984,27007]
===
match
---
name: self [41642,41646]
name: self [41764,41768]
===
match
---
name: self [45205,45209]
name: self [45327,45331]
===
match
---
operator: , [1231,1232]
operator: , [1231,1232]
===
match
---
comparison [35070,35099]
comparison [35192,35221]
===
match
---
name: getmtime [42502,42510]
name: getmtime [42624,42632]
===
match
---
name: pid [15657,15660]
name: pid [15779,15782]
===
match
---
name: self [9457,9461]
name: self [9457,9461]
===
match
---
simple_stmt [17113,17145]
simple_stmt [17235,17267]
===
match
---
suite [34780,35172]
suite [34902,35294]
===
match
---
operator: , [8643,8644]
operator: , [8643,8644]
===
match
---
name: self [35354,35358]
name: self [35476,35480]
===
match
---
name: is_mtime_mode [42433,42446]
name: is_mtime_mode [42555,42568]
===
match
---
trailer [19372,19391]
trailer [19494,19513]
===
match
---
number: 1 [28862,28863]
number: 1 [28984,28985]
===
match
---
name: file_path [44624,44633]
name: file_path [44746,44755]
===
match
---
simple_stmt [17216,17249]
simple_stmt [17338,17371]
===
match
---
name: request [10142,10149]
name: request [10142,10149]
===
match
---
name: max_runs_reached [28497,28513]
name: max_runs_reached [28619,28635]
===
match
---
name: deactivate_deleted_dags [30786,30809]
name: deactivate_deleted_dags [30908,30931]
===
match
---
argument [31804,31831]
argument [31926,31953]
===
match
---
name: signal [22508,22514]
name: signal [22630,22636]
===
match
---
name: utcnow [46786,46792]
name: utcnow [46908,46914]
===
match
---
simple_stmt [20446,20468]
simple_stmt [20568,20590]
===
match
---
simple_stmt [30941,30987]
simple_stmt [31063,31109]
===
match
---
name: pid [35341,35344]
name: pid [35463,35466]
===
match
---
simple_stmt [14711,14752]
simple_stmt [14833,14874]
===
match
---
name: num_errors [34006,34016]
name: num_errors [34128,34138]
===
match
---
param [46671,46675]
param [46793,46797]
===
match
---
param [22769,22776]
param [22891,22898]
===
match
---
name: self [38885,38889]
name: self [39007,39011]
===
match
---
number: 0 [44696,44697]
number: 0 [44818,44819]
===
match
---
parameters [2463,2469]
parameters [2463,2469]
===
match
---
operator: , [1237,1238]
operator: , [1237,1238]
===
match
---
atom_expr [4953,4968]
atom_expr [4953,4968]
===
match
---
simple_stmt [34789,35059]
simple_stmt [34911,35181]
===
match
---
name: stat [35759,35763]
name: stat [35881,35885]
===
match
---
atom [14036,14063]
atom [14158,14185]
===
match
---
trailer [7067,7077]
trailer [7067,7077]
===
match
---
suite [47765,47795]
suite [47887,47917]
===
match
---
name: __init__ [6573,6581]
name: __init__ [6573,6581]
===
match
---
simple_stmt [35433,35697]
simple_stmt [35555,35819]
===
match
---
name: incr [41405,41409]
name: incr [41527,41531]
===
match
---
name: _pickle_dags [19465,19477]
name: _pickle_dags [19587,19599]
===
match
---
atom [11934,11962]
atom [12056,12084]
===
match
---
trailer [10116,10136]
trailer [10116,10136]
===
match
---
trailer [19088,19099]
trailer [19210,19221]
===
match
---
name: DM [45850,45852]
name: DM [45972,45974]
===
match
---
simple_stmt [20917,21007]
simple_stmt [21039,21129]
===
match
---
atom_expr [36972,36993]
atom_expr [37094,37115]
===
match
---
name: stat [39549,39553]
name: stat [39671,39675]
===
match
---
simple_stmt [1907,1964]
simple_stmt [1907,1964]
===
match
---
arglist [12407,12411]
arglist [12529,12533]
===
match
---
name: query [31718,31723]
name: query [31840,31845]
===
match
---
trailer [25130,25135]
trailer [25252,25257]
===
match
---
atom_expr [7705,7729]
atom_expr [7705,7729]
===
match
---
expr_stmt [38446,38488]
expr_stmt [38568,38610]
===
match
---
param [12157,12174]
param [12279,12296]
===
match
---
suite [4290,4437]
suite [4290,4437]
===
match
---
trailer [26861,26885]
trailer [26983,27007]
===
match
---
parameters [31411,31426]
parameters [31533,31548]
===
match
---
atom [34101,34466]
atom [34223,34588]
===
match
---
name: _parsing_start_time [41838,41857]
name: _parsing_start_time [41960,41979]
===
match
---
name: self [46553,46557]
name: self [46675,46679]
===
match
---
name: processor_start_time [33311,33331]
name: processor_start_time [33433,33453]
===
match
---
simple_stmt [1721,1756]
simple_stmt [1721,1756]
===
match
---
number: 0 [14850,14851]
number: 0 [14972,14973]
===
match
---
name: stat [36997,37001]
name: stat [37119,37123]
===
match
---
simple_stmt [48277,48312]
simple_stmt [48399,48434]
===
match
---
operator: , [33131,33132]
operator: , [33253,33254]
===
match
---
and_test [40809,40880]
and_test [40931,41002]
===
match
---
trailer [14425,14434]
trailer [14547,14556]
===
match
---
name: debug [30424,30429]
name: debug [30546,30551]
===
match
---
name: int [4984,4987]
name: int [4984,4987]
===
match
---
simple_stmt [4897,4934]
simple_stmt [4897,4934]
===
match
---
expr_stmt [33022,33061]
expr_stmt [33144,33183]
===
match
---
name: set_file_paths [30348,30362]
name: set_file_paths [30470,30484]
===
match
---
name: _parent_signal_conn [16576,16595]
name: _parent_signal_conn [16698,16717]
===
match
---
simple_stmt [7014,7055]
simple_stmt [7014,7055]
===
match
---
param [4496,4500]
param [4496,4500]
===
match
---
name: file_path [35830,35839]
name: file_path [35952,35961]
===
match
---
expr_stmt [24132,24147]
expr_stmt [24254,24269]
===
match
---
param [35824,35829]
param [35946,35951]
===
match
---
funcdef [4476,4633]
funcdef [4476,4633]
===
match
---
operator: , [23042,23043]
operator: , [23164,23165]
===
match
---
param [4277,4281]
param [4277,4281]
===
match
---
for_stmt [44127,44381]
for_stmt [44249,44503]
===
match
---
trailer [45381,45434]
trailer [45503,45556]
===
match
---
trailer [19338,19348]
trailer [19460,19470]
===
match
---
arglist [27893,27955]
arglist [28015,28077]
===
match
---
name: self [14763,14767]
name: self [14885,14889]
===
match
---
simple_stmt [26857,26888]
simple_stmt [26979,27010]
===
match
---
string: """         :param file_path: the path to the file that's being processed         :type file_path: unicode         :return: the PID of the process processing the given file or None if             the specified file is not being processed         :rtype: int         """ [34789,35058]
string: """         :param file_path: the path to the file that's being processed         :type file_path: unicode         :return: the PID of the process processing the given file or None if             the specified file is not being processed         :rtype: int         """ [34911,35180]
===
match
---
suite [41073,41099]
suite [41195,41221]
===
match
---
name: ValueError [25469,25479]
name: ValueError [25591,25601]
===
match
---
trailer [13107,13110]
trailer [13229,13232]
===
match
---
expr_stmt [41590,41629]
expr_stmt [41712,41751]
===
match
---
return_stmt [47658,47670]
return_stmt [47780,47792]
===
match
---
expr_stmt [4874,4892]
expr_stmt [4874,4892]
===
match
---
operator: , [33980,33981]
operator: , [34102,34103]
===
match
---
name: async_mode [19136,19146]
name: async_mode [19258,19268]
===
match
---
simple_stmt [23246,23486]
simple_stmt [23368,23608]
===
match
---
operator: , [23888,23889]
operator: , [24010,24011]
===
match
---
name: self [40707,40711]
name: self [40829,40833]
===
match
---
argument [44722,44740]
argument [44844,44862]
===
match
---
atom_expr [28757,28773]
atom_expr [28879,28895]
===
match
---
name: start [2458,2463]
name: start [2458,2463]
===
match
---
name: RUNNING [45903,45910]
name: RUNNING [46025,46032]
===
match
---
param [10393,10398]
param [10393,10398]
===
match
---
atom_expr [16834,16847]
atom_expr [16956,16969]
===
match
---
trailer [30096,30111]
trailer [30218,30233]
===
match
---
atom_expr [8501,8536]
atom_expr [8501,8536]
===
match
---
atom_expr [47806,47819]
atom_expr [47928,47941]
===
match
---
trailer [27867,27977]
trailer [27989,28099]
===
match
---
suite [43247,43497]
suite [43369,43619]
===
match
---
trailer [26258,26268]
trailer [26380,26390]
===
match
---
name: values [47708,47714]
name: values [47830,47836]
===
match
---
arglist [20249,20419]
arglist [20371,20541]
===
match
---
operator: = [38477,38478]
operator: = [38599,38600]
===
match
---
name: bool [19122,19126]
name: bool [19244,19248]
===
match
---
atom_expr [38185,38206]
atom_expr [38307,38328]
===
match
---
param [3710,3714]
param [3710,3714]
===
match
---
trailer [17185,17189]
trailer [17307,17311]
===
match
---
name: self [13898,13902]
name: self [14020,14024]
===
match
---
arglist [22705,22735]
arglist [22827,22857]
===
match
---
atom_expr [23000,23081]
atom_expr [23122,23203]
===
match
---
simple_stmt [15824,15847]
simple_stmt [15946,15969]
===
match
---
decorated [31355,31858]
decorated [31477,31980]
===
match
---
atom [42250,42252]
atom [42372,42374]
===
match
---
name: _processor_timeout [46938,46956]
name: _processor_timeout [47060,47078]
===
match
---
operator: , [1057,1058]
operator: , [1057,1058]
===
match
---
name: max_runs [7080,7088]
name: max_runs [7080,7088]
===
match
---
name: self [40833,40837]
name: self [40955,40959]
===
match
---
name: self [7273,7277]
name: self [7273,7277]
===
match
---
name: _process_message [11513,11529]
name: _process_message [11632,11648]
===
match
---
name: Optional [7487,7495]
name: Optional [7487,7495]
===
match
---
atom_expr [34182,34205]
atom_expr [34304,34327]
===
match
---
return_stmt [35331,35380]
return_stmt [35453,35502]
===
match
---
trailer [40082,40084]
trailer [40204,40206]
===
match
---
name: self [7014,7018]
name: self [7014,7018]
===
match
---
string: "_processor_factory" [8515,8535]
string: "_processor_factory" [8515,8535]
===
match
---
tfpdef [18885,18975]
tfpdef [19007,19097]
===
match
---
trailer [14841,14852]
trailer [14963,14974]
===
match
---
name: _file_stats [48940,48951]
name: _file_stats [49062,49073]
===
match
---
suite [2636,2754]
suite [2636,2754]
===
match
---
trailer [18831,18852]
trailer [18953,18974]
===
match
---
name: seconds_ago [33443,33454]
name: seconds_ago [33565,33576]
===
match
---
name: _parallelism [40573,40585]
name: _parallelism [40695,40707]
===
match
---
name: terminate [48117,48126]
name: terminate [48239,48248]
===
match
---
if_stmt [19957,20041]
if_stmt [20079,20163]
===
match
---
name: DagParsingSignal [25183,25199]
name: DagParsingSignal [25305,25321]
===
match
---
name: keys [41066,41070]
name: keys [41188,41192]
===
match
---
trailer [40910,40927]
trailer [41032,41049]
===
match
---
atom_expr [16601,16635]
atom_expr [16723,16757]
===
match
---
name: _max_runs [28641,28650]
name: _max_runs [28763,28772]
===
match
---
atom_expr [40063,40084]
atom_expr [40185,40206]
===
match
---
decorator [44837,44854]
decorator [44959,44976]
===
match
---
name: filter [45929,45935]
name: filter [46051,46057]
===
match
---
atom_expr [31764,31780]
atom_expr [31886,31902]
===
match
---
name: type [25499,25503]
name: type [25621,25625]
===
match
---
simple_stmt [14588,14658]
simple_stmt [14710,14780]
===
match
---
name: dag_ids [19516,19523]
name: dag_ids [19638,19645]
===
match
---
name: file_path [35733,35742]
name: file_path [35855,35864]
===
match
---
trailer [39071,39121]
trailer [39193,39243]
===
match
---
param [12092,12121]
param [12214,12243]
===
match
---
name: info [8814,8818]
name: info [8814,8818]
===
match
---
atom_expr [39196,39213]
atom_expr [39318,39335]
===
match
---
string: "airflow scheduler -- DagFileProcessorManager" [12435,12481]
string: "airflow scheduler -- DagFileProcessorManager" [12557,12603]
===
match
---
atom_expr [20546,20573]
atom_expr [20668,20695]
===
match
---
name: self [4496,4500]
name: self [4496,4500]
===
match
---
string: """Has DagFileProcessorManager ended?""" [16022,16062]
string: """Has DagFileProcessorManager ended?""" [16144,16184]
===
match
---
expr_stmt [8240,8738]
expr_stmt [8240,8738]
===
match
---
atom_expr [30163,30182]
atom_expr [30285,30304]
===
match
---
name: self [28707,28711]
name: self [28829,28833]
===
match
---
atom_expr [10743,10777]
atom_expr [10743,10777]
===
match
---
string: """Helper method to clean up DAG file processors to avoid leaving orphan processes.""" [22828,22914]
string: """Helper method to clean up DAG file processors to avoid leaving orphan processes.""" [22950,23036]
===
match
---
trailer [39805,39819]
trailer [39927,39941]
===
match
---
suite [10182,10347]
suite [10182,10347]
===
match
---
simple_stmt [23594,23683]
simple_stmt [23716,23805]
===
match
---
name: last_finish_time [39676,39692]
name: last_finish_time [39798,39814]
===
match
---
suite [35841,36191]
suite [35963,36313]
===
match
---
trailer [44353,44363]
trailer [44475,44485]
===
match
---
name: run_count [4973,4982]
name: run_count [4973,4982]
===
match
---
atom_expr [22104,22136]
atom_expr [22226,22258]
===
match
---
name: num_errors [33761,33771]
name: num_errors [33883,33893]
===
match
---
name: self [47506,47510]
name: self [47628,47632]
===
match
---
raise_stmt [11271,11311]
raise_stmt [11271,11311]
===
match
---
param [44882,44889]
param [45004,45011]
===
match
---
trailer [17246,17248]
trailer [17368,17370]
===
match
---
simple_stmt [33506,33583]
simple_stmt [33628,33705]
===
match
---
name: processor_timeout [18985,19002]
name: processor_timeout [19107,19124]
===
match
---
name: LJ [45352,45354]
name: LJ [45474,45476]
===
match
---
name: incr [47411,47415]
name: incr [47533,47537]
===
match
---
simple_stmt [821,838]
simple_stmt [821,838]
===
match
---
name: conf [21967,21971]
name: conf [22089,22093]
===
match
---
tfpdef [6633,6646]
tfpdef [6633,6646]
===
match
---
trailer [36532,36543]
trailer [36654,36665]
===
match
---
name: ABCMeta [2337,2344]
name: ABCMeta [2337,2344]
===
match
---
name: TaskCallbackRequest [46277,46296]
name: TaskCallbackRequest [46399,46418]
===
match
---
trailer [6739,6744]
trailer [6739,6744]
===
match
---
expr_stmt [7149,7192]
expr_stmt [7149,7192]
===
match
---
name: _process [15648,15656]
name: _process [15770,15778]
===
match
---
if_stmt [24891,25521]
if_stmt [25013,25643]
===
match
---
simple_stmt [34062,34481]
simple_stmt [34184,34603]
===
match
---
name: self [15916,15920]
name: self [16038,16042]
===
match
---
trailer [40927,40931]
trailer [41049,41053]
===
match
---
trailer [31750,31759]
trailer [31872,31881]
===
match
---
name: self [20050,20054]
name: self [20172,20176]
===
match
---
number: 0.01 [13936,13940]
number: 0.01 [14058,14062]
===
match
---
name: datetime [1049,1057]
name: datetime [1049,1057]
===
match
---
suite [25572,26096]
suite [25694,26218]
===
match
---
name: _processors [40554,40565]
name: _processors [40676,40687]
===
match
---
name: incr [15357,15361]
name: incr [15479,15483]
===
match
---
trailer [23094,23104]
trailer [23216,23226]
===
match
---
name: property [3113,3121]
name: property [3113,3121]
===
match
---
atom_expr [41642,41683]
atom_expr [41764,41805]
===
match
---
simple_stmt [15178,15185]
simple_stmt [15300,15307]
===
match
---
arglist [23058,23078]
arglist [23180,23200]
===
match
---
suite [20202,20468]
suite [20324,20590]
===
match
---
name: remove_deleted_code [30949,30968]
name: remove_deleted_code [31071,31090]
===
match
---
name: total_seconds [42820,42833]
name: total_seconds [42942,42955]
===
match
---
atom_expr [9487,9518]
atom_expr [9487,9518]
===
match
---
testlist_comp [18914,18940]
testlist_comp [19036,19062]
===
match
---
name: _log_file_processing_stats [31248,31274]
name: _log_file_processing_stats [31370,31396]
===
match
---
name: DagCode [30941,30948]
name: DagCode [31063,31070]
===
match
---
name: stat [36505,36509]
name: stat [36627,36631]
===
match
---
subscriptlist [18913,18974]
subscriptlist [19035,19096]
===
match
---
expr_stmt [7977,8035]
expr_stmt [7977,8035]
===
match
---
simple_stmt [29783,29807]
simple_stmt [29905,29929]
===
match
---
name: self [43626,43630]
name: self [43748,43752]
===
match
---
name: list_py_file_paths [1888,1906]
name: list_py_file_paths [1888,1906]
===
match
---
name: __init__ [18779,18787]
name: __init__ [18901,18909]
===
match
---
trailer [40553,40565]
trailer [40675,40687]
===
match
---
import_as_names [2112,2160]
import_as_names [2112,2160]
===
match
---
operator: , [22775,22776]
operator: , [22897,22898]
===
match
---
name: filter [31724,31730]
name: filter [31846,31852]
===
match
---
simple_stmt [28531,28669]
simple_stmt [28653,28791]
===
match
---
atom_expr [48628,48647]
atom_expr [48750,48769]
===
match
---
name: _parent_signal_conn [11418,11437]
name: _parent_signal_conn [11536,11555]
===
match
---
funcdef [37017,37475]
funcdef [37139,37597]
===
match
---
annassign [21177,21226]
annassign [21299,21348]
===
match
---
suite [39255,39317]
suite [39377,39439]
===
match
---
operator: , [13455,13456]
operator: , [13577,13578]
===
match
---
trailer [40495,40499]
trailer [40617,40621]
===
match
---
param [40707,40711]
param [40829,40833]
===
match
---
trailer [24777,24779]
trailer [24899,24901]
===
match
---
suite [26302,26332]
suite [26424,26454]
===
match
---
trailer [22185,22195]
trailer [22307,22317]
===
match
---
atom_expr [29561,29582]
atom_expr [29683,29704]
===
match
---
trailer [16082,16088]
trailer [16204,16210]
===
match
---
name: path [33089,33093]
name: path [33211,33215]
===
match
---
name: request [10918,10925]
name: request [10918,10925]
===
match
---
trailer [31648,31668]
trailer [31770,31790]
===
match
---
name: _file_paths [19208,19219]
name: _file_paths [19330,19341]
===
match
---
funcdef [2968,3107]
funcdef [2968,3107]
===
match
---
name: _parent_signal_conn [13903,13922]
name: _parent_signal_conn [14025,14044]
===
match
---
name: values [48034,48040]
name: values [48156,48162]
===
match
---
annassign [6989,7005]
annassign [6989,7005]
===
match
---
name: agent_signal [24740,24752]
name: agent_signal [24862,24874]
===
match
---
operator: = [19549,19550]
operator: = [19671,19672]
===
match
---
atom_expr [40284,40308]
atom_expr [40406,40430]
===
match
---
name: log [17203,17206]
name: log [17325,17328]
===
match
---
name: log [30645,30648]
name: log [30767,30770]
===
match
---
trailer [33179,33190]
trailer [33301,33312]
===
match
---
simple_stmt [17348,18770]
simple_stmt [17470,18892]
===
match
---
not_test [9299,9316]
not_test [9299,9316]
===
match
---
name: _kill_timed_out_processors [26630,26656]
name: _kill_timed_out_processors [26752,26778]
===
match
---
trailer [43476,43484]
trailer [43598,43606]
===
match
---
name: file_paths [44055,44065]
name: file_paths [44177,44187]
===
match
---
simple_stmt [21161,21227]
simple_stmt [21283,21349]
===
match
---
comparison [29548,29582]
comparison [29670,29704]
===
match
---
trailer [41495,41577]
trailer [41617,41699]
===
match
---
name: self [27559,27563]
name: self [27681,27685]
===
match
---
operator: == [42311,42313]
operator: == [42433,42435]
===
match
---
trailer [33102,33113]
trailer [33224,33235]
===
match
---
trailer [45504,45511]
trailer [45626,45633]
===
match
---
if_stmt [45085,46635]
if_stmt [45207,46757]
===
match
---
trailer [2751,2753]
trailer [2751,2753]
===
match
---
name: self [16834,16838]
name: self [16956,16960]
===
match
---
trailer [20223,20231]
trailer [20345,20353]
===
match
---
parameters [29685,29691]
parameters [29807,29813]
===
match
---
suite [16468,16694]
suite [16590,16816]
===
match
---
trailer [41290,41299]
trailer [41412,41421]
===
match
---
simple_stmt [42231,42253]
simple_stmt [42353,42375]
===
match
---
name: stat [15883,15887]
name: stat [16005,16009]
===
match
---
name: timeout [17132,17139]
name: timeout [17254,17261]
===
match
---
trailer [8397,8407]
trailer [8397,8407]
===
match
---
atom_expr [25136,25144]
atom_expr [25258,25266]
===
match
---
name: utils [2085,2090]
name: utils [2085,2090]
===
match
---
trailer [30644,30648]
trailer [30766,30770]
===
match
---
operator: = [5162,5163]
operator: = [5162,5163]
===
match
---
simple_stmt [8747,8771]
simple_stmt [8747,8771]
===
match
---
name: self [40063,40067]
name: self [40185,40189]
===
match
---
simple_stmt [4734,4760]
simple_stmt [4734,4760]
===
match
---
atom_expr [29637,29658]
atom_expr [29759,29780]
===
match
---
atom [33279,33307]
atom [33401,33429]
===
match
---
operator: , [20032,20033]
operator: , [20154,20155]
===
match
---
trailer [22936,22991]
trailer [23058,23113]
===
match
---
atom_expr [46277,46470]
atom_expr [46399,46592]
===
match
---
operator: , [23867,23868]
operator: , [23989,23990]
===
match
---
name: get_all_pids [35181,35193]
name: get_all_pids [35303,35315]
===
match
---
atom_expr [15232,15267]
atom_expr [15354,15389]
===
match
---
name: count_import_errors [39278,39297]
name: count_import_errors [39400,39419]
===
match
---
atom_expr [45584,45611]
atom_expr [45706,45733]
===
match
---
trailer [40813,40826]
trailer [40935,40948]
===
match
---
param [47506,47510]
param [47628,47632]
===
match
---
name: self [19532,19536]
name: self [19654,19658]
===
match
---
suite [28724,28938]
suite [28846,29060]
===
match
---
fstring_start: f" [14480,14482]
fstring_start: f" [14602,14604]
===
match
---
name: self [14785,14789]
name: self [14907,14911]
===
match
---
name: debug [14285,14290]
name: debug [14407,14412]
===
match
---
atom_expr [46933,46956]
atom_expr [47055,47078]
===
match
---
funcdef [31863,34746]
funcdef [31985,34868]
===
match
---
name: get_last_dag_count [32918,32936]
name: get_last_dag_count [33040,33058]
===
match
---
suite [15165,15185]
suite [15287,15307]
===
match
---
argument [8279,8319]
argument [8279,8319]
===
match
---
name: DM [45492,45494]
name: DM [45614,45616]
===
match
---
import_from [1481,1524]
import_from [1481,1524]
===
match
---
name: last_dag_dir_refresh_time [21489,21514]
name: last_dag_dir_refresh_time [21611,21636]
===
match
---
name: _file_stats [47696,47707]
name: _file_stats [47818,47829]
===
match
---
atom_expr [15643,15660]
atom_expr [15765,15782]
===
match
---
simple_stmt [14276,14346]
simple_stmt [14398,14468]
===
match
---
name: TaskCallbackRequest [1837,1856]
name: TaskCallbackRequest [1837,1856]
===
match
---
name: self [8630,8634]
name: self [8630,8634]
===
match
---
trailer [22931,22936]
trailer [23053,23058]
===
match
---
trailer [15085,15094]
trailer [15207,15216]
===
match
---
name: poll_time [28922,28931]
name: poll_time [29044,29053]
===
match
---
operator: , [41565,41566]
operator: , [41687,41688]
===
match
---
string: "File path %s is still being processed (started: %s)" [44225,44278]
string: "File path %s is still being processed (started: %s)" [44347,44400]
===
match
---
trailer [21545,21559]
trailer [21667,21681]
===
match
---
simple_stmt [26513,26537]
simple_stmt [26635,26659]
===
match
---
atom_expr [48843,48971]
atom_expr [48965,49093]
===
match
---
operator: = [39800,39801]
operator: = [39922,39923]
===
match
---
name: file_paths [42261,42271]
name: file_paths [42383,42393]
===
match
---
suite [44540,44772]
suite [44662,44894]
===
match
---
string: 'dag_processing.total_parse_time' [48695,48728]
string: 'dag_processing.total_parse_time' [48817,48850]
===
match
---
trailer [7667,7688]
trailer [7667,7688]
===
match
---
operator: = [15668,15669]
operator: = [15790,15791]
===
match
---
operator: = [21825,21826]
operator: = [21947,21948]
===
match
---
trailer [24658,24660]
trailer [24780,24782]
===
match
---
atom_expr [20947,21006]
atom_expr [21069,21128]
===
match
---
param [19071,19100]
param [19193,19222]
===
match
---
trailer [31730,31782]
trailer [31852,31904]
===
match
---
name: self [15545,15549]
name: self [15667,15671]
===
match
---
atom_expr [41286,41299]
atom_expr [41408,41421]
===
match
---
operator: = [45583,45584]
operator: = [45705,45706]
===
match
---
trailer [17171,17207]
trailer [17293,17329]
===
match
---
operator: = [12909,12910]
operator: = [13031,13032]
===
match
---
name: log [20220,20223]
name: log [20342,20345]
===
match
---
trailer [8809,8813]
trailer [8809,8813]
===
match
---
name: x [35349,35350]
name: x [35471,35472]
===
match
---
name: str [12115,12118]
name: str [12237,12240]
===
match
---
atom_expr [19080,19099]
atom_expr [19202,19221]
===
match
---
atom_expr [27425,27451]
atom_expr [27547,27573]
===
match
---
atom_expr [19290,19309]
atom_expr [19412,19431]
===
match
---
trailer [23570,23578]
trailer [23692,23700]
===
match
---
name: datetime [4924,4932]
name: datetime [4924,4932]
===
match
---
trailer [22514,22521]
trailer [22636,22643]
===
match
---
decorator [2759,2775]
decorator [2759,2775]
===
match
---
name: self [37036,37040]
name: self [37158,37162]
===
match
---
if_stmt [26148,26211]
if_stmt [26270,26333]
===
match
---
atom_expr [45106,45134]
atom_expr [45228,45256]
===
match
---
operator: = [44695,44696]
operator: = [44817,44818]
===
match
---
comparison [45791,45809]
comparison [45913,45931]
===
match
---
atom_expr [23756,23783]
atom_expr [23878,23905]
===
match
---
simple_stmt [39527,39540]
simple_stmt [39649,39662]
===
match
---
expr_stmt [19460,19491]
expr_stmt [19582,19613]
===
match
---
name: wait_until_finished [27430,27449]
name: wait_until_finished [27552,27571]
===
match
---
trailer [6734,6745]
trailer [6734,6745]
===
match
---
trailer [34736,34745]
trailer [34858,34867]
===
match
---
name: import_errors [4874,4887]
name: import_errors [4874,4887]
===
match
---
name: abstractmethod [2949,2963]
name: abstractmethod [2949,2963]
===
match
---
name: multiprocessing [24607,24622]
name: multiprocessing [24729,24744]
===
match
---
except_clause [14029,14063]
except_clause [14151,14185]
===
match
---
atom_expr [15669,15677]
atom_expr [15791,15799]
===
match
---
name: isinstance [14357,14367]
name: isinstance [14479,14489]
===
match
---
comparison [29910,29965]
comparison [30032,30087]
===
match
---
trailer [48632,48645]
trailer [48754,48767]
===
match
---
operator: = [31633,31634]
operator: = [31755,31756]
===
match
---
atom_expr [9271,9295]
atom_expr [9271,9295]
===
match
---
name: _run_parsing_loop [23977,23994]
name: _run_parsing_loop [24099,24116]
===
match
---
trailer [13042,13112]
trailer [13164,13234]
===
match
---
name: max_runs_reached [27893,27909]
name: max_runs_reached [28015,28031]
===
match
---
param [10399,10418]
param [10399,10418]
===
match
---
operator: = [44635,44636]
operator: = [44757,44758]
===
match
---
trailer [27563,27579]
trailer [27685,27701]
===
match
---
name: self [36626,36630]
name: self [36748,36752]
===
match
---
number: 0 [12407,12408]
number: 0 [12529,12530]
===
match
---
if_stmt [46919,47480]
if_stmt [47041,47602]
===
match
---
operator: , [22982,22983]
operator: , [23104,23105]
===
match
---
name: num_dags [36164,36172]
name: num_dags [36286,36294]
===
match
---
trailer [22560,22567]
trailer [22682,22689]
===
match
---
trailer [20746,20767]
trailer [20868,20889]
===
match
---
suite [38429,38489]
suite [38551,38611]
===
match
---
arglist [41496,41576]
arglist [41618,41698]
===
match
---
operator: = [7767,7768]
operator: = [7767,7768]
===
match
---
trailer [46491,46495]
trailer [46613,46617]
===
match
---
string: "file_parsing_sort_mode" [42196,42220]
string: "file_parsing_sort_mode" [42318,42342]
===
match
---
name: self [19570,19574]
name: self [19692,19696]
===
match
---
atom [39720,39761]
atom [39842,39883]
===
match
---
name: done [14877,14881]
name: done [14999,15003]
===
match
---
simple_stmt [809,821]
simple_stmt [809,821]
===
match
---
name: file_path [44042,44051]
name: file_path [44164,44173]
===
match
---
suite [24161,24191]
suite [24283,24313]
===
match
---
name: zombies [46242,46249]
name: zombies [46364,46371]
===
match
---
name: sentinel [40299,40307]
name: sentinel [40421,40429]
===
match
---
atom_expr [48900,48961]
atom_expr [49022,49083]
===
match
---
atom_expr [15545,15562]
atom_expr [15667,15684]
===
match
---
param [31900,31916]
param [32022,32038]
===
match
---
name: _parent_signal_conn [13728,13747]
name: _parent_signal_conn [13850,13869]
===
match
---
subscriptlist [22109,22135]
subscriptlist [22231,22257]
===
match
---
name: Stats [41399,41404]
name: Stats [41521,41526]
===
match
---
name: Callable [6675,6683]
name: Callable [6675,6683]
===
match
---
atom_expr [23206,23214]
atom_expr [23328,23336]
===
match
---
operator: @ [4243,4244]
operator: @ [4243,4244]
===
match
---
name: airflow [13057,13064]
name: airflow [13179,13186]
===
match
---
name: count_import_errors [39626,39645]
name: count_import_errors [39748,39767]
===
match
---
operator: , [10417,10418]
operator: , [10417,10418]
===
match
---
trailer [15828,15834]
trailer [15950,15956]
===
match
---
name: stat [36581,36585]
name: stat [36703,36707]
===
match
---
name: airflow [1969,1976]
name: airflow [1969,1976]
===
match
---
name: self [36112,36116]
name: self [36234,36238]
===
match
---
funcdef [35801,36191]
funcdef [35923,36313]
===
match
---
trailer [21240,21249]
trailer [21362,21371]
===
match
---
trailer [29181,29198]
trailer [29303,29320]
===
match
---
trailer [23699,23704]
trailer [23821,23826]
===
match
---
name: async_mode [6908,6918]
name: async_mode [6908,6918]
===
match
---
name: runtime [33598,33605]
name: runtime [33720,33727]
===
match
---
atom_expr [36512,36543]
atom_expr [36634,36665]
===
match
---
try_stmt [10095,10347]
try_stmt [10095,10347]
===
match
---
trailer [41489,41495]
trailer [41611,41617]
===
match
---
string: 'dag_processing.processes' [47248,47274]
string: 'dag_processing.processes' [47370,47396]
===
match
---
name: info [23603,23607]
name: info [23725,23729]
===
match
---
name: dag_ids [19071,19078]
name: dag_ids [19193,19200]
===
match
---
atom_expr [25183,25214]
atom_expr [25305,25336]
===
match
---
trailer [30314,30329]
trailer [30436,30451]
===
match
---
number: 0 [29634,29635]
number: 0 [29756,29757]
===
match
---
name: Stats [46606,46611]
name: Stats [46728,46733]
===
match
---
name: _processor_timeout [21806,21824]
name: _processor_timeout [21928,21946]
===
match
---
name: _file_stats [36517,36528]
name: _file_stats [36639,36650]
===
match
---
operator: @ [4442,4443]
operator: @ [4442,4443]
===
match
---
trailer [29159,29173]
trailer [29281,29295]
===
match
---
name: self [44607,44611]
name: self [44729,44733]
===
match
---
trailer [27429,27449]
trailer [27551,27571]
===
match
---
trailer [36516,36528]
trailer [36638,36650]
===
match
---
trailer [45839,45846]
trailer [45961,45968]
===
match
---
atom_expr [45897,45910]
atom_expr [46019,46032]
===
match
---
name: str [11870,11873]
name: str [11992,11995]
===
match
---
simple_stmt [20215,20434]
simple_stmt [20337,20556]
===
match
---
atom_expr [28636,28650]
atom_expr [28758,28772]
===
match
---
name: log [39348,39351]
name: log [39470,39473]
===
match
---
atom_expr [3989,4010]
atom_expr [3989,4010]
===
match
---
name: self [8747,8751]
name: self [8747,8751]
===
match
---
name: process [8868,8875]
name: process [8868,8875]
===
match
---
trailer [38465,38476]
trailer [38587,38598]
===
match
---
atom_expr [40833,40849]
atom_expr [40955,40971]
===
match
---
atom_expr [45625,45693]
atom_expr [45747,45815]
===
match
---
operator: , [22258,22259]
operator: , [22380,22381]
===
match
---
name: END_MANAGER [25063,25074]
name: END_MANAGER [25185,25196]
===
match
---
funcdef [44858,46635]
funcdef [44980,46757]
===
match
---
atom_expr [14673,14697]
atom_expr [14795,14819]
===
match
---
param [28970,28975]
param [29092,29097]
===
match
---
name: dag_id [45840,45846]
name: dag_id [45962,45968]
===
match
---
operator: , [12120,12121]
operator: , [12242,12243]
===
match
---
operator: = [43074,43075]
operator: = [43196,43197]
===
match
---
string: "DagFileProcessorManager (PID=%d) exited with exit code %d - re-launching" [14937,15011]
string: "DagFileProcessorManager (PID=%d) exited with exit code %d - re-launching" [15059,15133]
===
match
---
name: total_seconds [29883,29896]
name: total_seconds [30005,30018]
===
match
---
expr_stmt [29454,29596]
expr_stmt [29576,29718]
===
match
---
operator: + [34693,34694]
operator: + [34815,34816]
===
match
---
suite [2478,2568]
suite [2478,2568]
===
match
---
name: _processors [46836,46847]
name: _processors [46958,46969]
===
match
---
name: self [15855,15859]
name: self [15977,15981]
===
match
---
name: Optional [6852,6860]
name: Optional [6852,6860]
===
match
---
fstring_end: ' [33567,33568]
fstring_end: ' [33689,33690]
===
match
---
name: terminate [38661,38670]
name: terminate [38783,38792]
===
match
---
expr_stmt [33269,33341]
expr_stmt [33391,33463]
===
match
---
name: request [46267,46274]
name: request [46389,46396]
===
match
---
suite [35100,35152]
suite [35222,35274]
===
match
---
trailer [14827,14836]
trailer [14949,14958]
===
match
---
suite [47645,47671]
suite [47767,47793]
===
match
---
expr_stmt [19368,19411]
expr_stmt [19490,19533]
===
match
---
expr_stmt [39864,39908]
expr_stmt [39986,40030]
===
match
---
operator: = [35710,35711]
operator: = [35832,35833]
===
match
---
name: timezone [45059,45067]
name: timezone [45181,45189]
===
match
---
name: total_seconds [39762,39775]
name: total_seconds [39884,39897]
===
match
---
trailer [46611,46616]
trailer [46733,46738]
===
match
---
trailer [34404,34425]
trailer [34526,34547]
===
match
---
name: send [27827,27831]
name: send [27949,27953]
===
match
---
operator: = [24184,24185]
operator: = [24306,24307]
===
match
---
trailer [44207,44380]
trailer [44329,44502]
===
match
---
arglist [44405,44491]
arglist [44527,44613]
===
match
---
name: get_hostname [2059,2071]
name: get_hostname [2059,2071]
===
match
---
operator: , [33985,33986]
operator: , [34107,34108]
===
match
---
atom_expr [11508,11537]
atom_expr [11627,11656]
===
match
---
import_from [1287,1324]
import_from [1287,1324]
===
match
---
expr_stmt [42464,42521]
expr_stmt [42586,42643]
===
match
---
name: file_path [44028,44037]
name: file_path [44150,44159]
===
match
---
trailer [32977,32998]
trailer [33099,33120]
===
match
---
trailer [38601,38606]
trailer [38723,38728]
===
match
---
trailer [48958,48960]
trailer [49080,49082]
===
match
---
name: mp_start_method [8082,8097]
name: mp_start_method [8082,8097]
===
match
---
trailer [48951,48958]
trailer [49073,49080]
===
match
---
name: filter [45878,45884]
name: filter [46000,46006]
===
match
---
name: self [14406,14410]
name: self [14528,14532]
===
match
---
funcdef [3430,3660]
funcdef [3430,3660]
===
match
---
name: recv [11438,11442]
name: recv [11556,11560]
===
match
---
expr_stmt [7783,7844]
expr_stmt [7783,7844]
===
match
---
suite [43020,43111]
suite [43142,43233]
===
match
---
name: import_errors [44682,44695]
name: import_errors [44804,44817]
===
match
---
simple_stmt [16571,16637]
simple_stmt [16693,16759]
===
match
---
test [34387,34447]
test [34509,34569]
===
match
---
trailer [38970,38976]
trailer [39092,39098]
===
match
---
trailer [8360,8375]
trailer [8360,8375]
===
match
---
operator: } [21225,21226]
operator: } [21347,21348]
===
match
---
string: "Queuing the following files for processing:\n\t%s" [44405,44456]
string: "Queuing the following files for processing:\n\t%s" [44527,44578]
===
match
---
atom [32654,32735]
atom [32776,32857]
===
match
---
trailer [20081,20115]
trailer [20203,20237]
===
match
---
suite [10958,11123]
suite [10958,11123]
===
match
---
expr_stmt [30125,30183]
expr_stmt [30247,30305]
===
match
---
operator: } [25517,25518]
operator: } [25639,25640]
===
match
---
trailer [47754,47764]
trailer [47876,47886]
===
match
---
dotted_name [2077,2104]
dotted_name [2077,2104]
===
match
---
name: set_file_paths [37832,37846]
name: set_file_paths [37954,37968]
===
match
---
name: _last_parsing_stat_received_at [7788,7818]
name: _last_parsing_stat_received_at [7788,7818]
===
match
---
classdef [17251,49085]
classdef [17373,49207]
===
match
---
simple_stmt [26228,26269]
simple_stmt [26350,26391]
===
match
---
name: last_run [34032,34040]
name: last_run [34154,34162]
===
match
---
trailer [29943,29965]
trailer [30065,30087]
===
match
---
name: _run_processor_manager [11823,11845]
name: _run_processor_manager [11945,11967]
===
match
---
and_test [25537,25571]
and_test [25659,25693]
===
match
---
name: dag_id [10861,10867]
name: dag_id [10861,10867]
===
match
---
trailer [20774,20781]
trailer [20896,20903]
===
match
---
arglist [8509,8535]
arglist [8509,8535]
===
match
---
operator: , [47147,47148]
operator: , [47269,47270]
===
match
---
parameters [37846,37868]
parameters [37968,37990]
===
match
---
name: processor [26228,26237]
name: processor [26350,26359]
===
match
---
atom_expr [40829,40850]
atom_expr [40951,40972]
===
match
---
name: file_path [40411,40420]
name: file_path [40533,40542]
===
match
---
operator: , [33725,33726]
operator: , [33847,33848]
===
match
---
param [2976,2980]
param [2976,2980]
===
match
---
simple_stmt [1525,1586]
simple_stmt [1525,1586]
===
match
---
name: _process [9391,9399]
name: _process [9391,9399]
===
match
---
trailer [30512,30514]
trailer [30634,30636]
===
match
---
simple_stmt [7663,7696]
simple_stmt [7663,7696]
===
match
---
atom_expr [7487,7532]
atom_expr [7487,7532]
===
match
---
atom_expr [22554,22606]
atom_expr [22676,22728]
===
match
---
arglist [40611,40676]
arglist [40733,40798]
===
match
---
not_test [9382,9410]
not_test [9382,9410]
===
match
---
name: self [16571,16575]
name: self [16693,16697]
===
match
---
atom_expr [13546,13571]
atom_expr [13668,13693]
===
match
---
name: str [19094,19097]
name: str [19216,19219]
===
match
---
name: self [41204,41208]
name: self [41326,41330]
===
match
---
atom_expr [48107,48128]
atom_expr [48229,48250]
===
match
---
number: 1 [39843,39844]
number: 1 [39965,39966]
===
match
---
funcdef [8886,9716]
funcdef [8886,9716]
===
match
---
name: processor [48107,48116]
name: processor [48229,48238]
===
match
---
trailer [30258,30330]
trailer [30380,30452]
===
match
---
simple_stmt [23000,23082]
simple_stmt [23122,23204]
===
match
---
trailer [14836,14841]
trailer [14958,14963]
===
match
---
name: gauge [48849,48854]
name: gauge [48971,48976]
===
match
---
operator: , [8612,8613]
operator: , [8612,8613]
===
match
---
trailer [15356,15361]
trailer [15478,15483]
===
match
---
comparison [47605,47625]
comparison [47727,47747]
===
match
---
arglist [33518,33581]
arglist [33640,33703]
===
match
---
expr_stmt [13276,13536]
expr_stmt [13398,13658]
===
match
---
name: num_errors [32960,32970]
name: num_errors [33082,33092]
===
match
---
operator: } [34336,34337]
operator: } [34458,34459]
===
match
---
trailer [41227,41332]
trailer [41349,41454]
===
match
---
atom_expr [41833,41857]
atom_expr [41955,41979]
===
match
---
name: self [45625,45629]
name: self [45747,45751]
===
match
---
simple_stmt [37786,37823]
simple_stmt [37908,37945]
===
match
---
import_from [2161,2210]
import_from [2161,2210]
===
match
---
name: get [26255,26258]
name: get [26377,26380]
===
match
---
for_stmt [33967,34481]
for_stmt [34089,34603]
===
match
---
param [2607,2612]
param [2607,2612]
===
match
---
operator: -> [2982,2984]
operator: -> [2982,2984]
===
match
---
name: start_new_processes [26906,26925]
name: start_new_processes [27028,27047]
===
match
---
name: self [30343,30347]
name: self [30465,30469]
===
match
---
name: self [22523,22527]
name: self [22645,22649]
===
match
---
name: ConnectionError [16656,16671]
name: ConnectionError [16778,16793]
===
match
---
operator: > [20198,20199]
operator: > [20320,20321]
===
match
---
fstring_start: f" [25480,25482]
fstring_start: f" [25602,25604]
===
match
---
atom [45150,45186]
atom [45272,45308]
===
match
---
name: last_stat_print_time [31172,31192]
name: last_stat_print_time [31294,31314]
===
match
---
string: "%s file paths queued for processing" [40611,40648]
string: "%s file paths queued for processing" [40733,40770]
===
match
---
name: self [44573,44577]
name: self [44695,44699]
===
match
---
operator: - [28774,28775]
operator: - [28896,28897]
===
match
---
operator: - [45155,45156]
operator: - [45277,45278]
===
match
---
parameters [15998,16004]
parameters [16120,16126]
===
match
---
trailer [14204,14223]
trailer [14326,14345]
===
match
---
atom_expr [33890,33929]
atom_expr [34012,34051]
===
match
---
trailer [4630,4632]
trailer [4630,4632]
===
match
---
trailer [12859,12867]
trailer [12981,12989]
===
match
---
operator: , [10397,10398]
operator: , [10397,10398]
===
match
---
atom_expr [33365,33401]
atom_expr [33487,33523]
===
match
---
string: 'CONFIG_PROCESSOR_MANAGER_LOGGER' [13233,13266]
string: 'CONFIG_PROCESSOR_MANAGER_LOGGER' [13355,13388]
===
match
---
trailer [40832,40850]
trailer [40954,40972]
===
match
---
trailer [14807,14809]
trailer [14929,14931]
===
match
---
raise_stmt [3079,3106]
raise_stmt [3079,3106]
===
match
---
name: _process [7477,7485]
name: _process [7477,7485]
===
match
---
atom_expr [19420,19437]
atom_expr [19542,19559]
===
match
---
simple_stmt [4856,4870]
simple_stmt [4856,4870]
===
match
---
expr_stmt [4734,4759]
expr_stmt [4734,4759]
===
match
---
name: pid [33982,33985]
name: pid [34104,34107]
===
match
---
suite [26181,26211]
suite [26303,26333]
===
match
---
expr_stmt [26228,26268]
expr_stmt [26350,26390]
===
match
---
if_stmt [16422,16694]
if_stmt [16544,16816]
===
match
---
name: airflow [2077,2084]
name: airflow [2077,2084]
===
match
---
trailer [15549,15558]
trailer [15671,15680]
===
match
---
funcdef [36196,36596]
funcdef [36318,36718]
===
match
---
trailer [36528,36532]
trailer [36650,36654]
===
match
---
name: rows [33703,33707]
name: rows [33825,33829]
===
match
---
atom_expr [45753,45763]
atom_expr [45875,45885]
===
match
---
name: self [23090,23094]
name: self [23212,23216]
===
match
---
param [37036,37041]
param [37158,37163]
===
match
---
simple_stmt [7201,7225]
simple_stmt [7201,7225]
===
match
---
name: pid [15047,15050]
name: pid [15169,15172]
===
match
---
simple_stmt [23115,23126]
simple_stmt [23237,23248]
===
match
---
atom_expr [40809,40826]
atom_expr [40931,40948]
===
match
---
param [12006,12035]
param [12128,12157]
===
match
---
name: BlockingIOError [28015,28030]
name: BlockingIOError [28137,28152]
===
match
---
simple_stmt [47463,47480]
simple_stmt [47585,47602]
===
match
---
string: 'dagbag_size' [48762,48775]
string: 'dagbag_size' [48884,48897]
===
match
---
atom_expr [20215,20433]
atom_expr [20337,20555]
===
match
---
simple_stmt [40434,40482]
simple_stmt [40556,40604]
===
match
---
name: self [11233,11237]
name: self [11233,11237]
===
match
---
name: headers [34645,34652]
name: headers [34767,34774]
===
match
---
name: self [41350,41354]
name: self [41472,41476]
===
match
---
name: perf_counter [41865,41877]
name: perf_counter [41987,41999]
===
match
---
sync_comp_for [44038,44107]
sync_comp_for [44160,44229]
===
match
---
name: abstractmethod [977,991]
name: abstractmethod [977,991]
===
match
---
name: processor_pid [33151,33164]
name: processor_pid [33273,33286]
===
match
---
annassign [22102,22156]
annassign [22224,22278]
===
match
---
expr_stmt [39490,39514]
expr_stmt [39612,39636]
===
match
---
comparison [43608,43640]
comparison [43730,43762]
===
match
---
atom_expr [3369,3390]
atom_expr [3369,3390]
===
match
---
simple_stmt [25463,25521]
simple_stmt [25585,25643]
===
match
---
number: 0 [40116,40117]
number: 0 [40238,40239]
===
match
---
param [31894,31899]
param [32016,32021]
===
match
---
operator: , [18941,18942]
operator: , [19063,19064]
===
match
---
classdef [4990,5178]
classdef [4990,5178]
===
match
---
name: self [22923,22927]
name: self [23045,23049]
===
match
---
name: DagModel [45512,45520]
name: DagModel [45634,45642]
===
match
---
fstring_expr [25498,25518]
fstring_expr [25620,25640]
===
match
---
if_stmt [28704,28938]
if_stmt [28826,29060]
===
match
---
name: pid [34154,34157]
name: pid [34276,34279]
===
match
---
operator: , [44456,44457]
operator: , [44578,44579]
===
match
---
name: file_path [37433,37442]
name: file_path [37555,37564]
===
match
---
operator: , [46011,46012]
operator: , [46133,46134]
===
match
---
trailer [37383,37395]
trailer [37505,37517]
===
match
---
name: total_seconds [45187,45200]
name: total_seconds [45309,45322]
===
match
---
trailer [13035,13042]
trailer [13157,13164]
===
match
---
trailer [19093,19098]
trailer [19215,19220]
===
match
---
operator: , [15050,15051]
operator: , [15172,15173]
===
match
---
name: files_paths_to_queue [44810,44830]
name: files_paths_to_queue [44932,44952]
===
match
---
name: self [48017,48021]
name: self [48139,48143]
===
match
---
string: 'core' [20148,20154]
string: 'core' [20270,20276]
===
match
---
atom_expr [9457,9519]
atom_expr [9457,9519]
===
match
---
name: log [30054,30057]
name: log [30176,30179]
===
match
---
simple_stmt [43660,43797]
simple_stmt [43782,43919]
===
match
---
name: errors [31732,31738]
name: errors [31854,31860]
===
match
---
atom_expr [31333,31349]
atom_expr [31455,31471]
===
match
---
number: 1.0 [17140,17143]
number: 1.0 [17262,17265]
===
match
---
trailer [38901,38908]
trailer [39023,39030]
===
match
---
name: get_last_finish_time [36605,36625]
name: get_last_finish_time [36727,36747]
===
match
---
operator: = [42492,42493]
operator: = [42614,42615]
===
match
---
expr_stmt [20742,20818]
expr_stmt [20864,20940]
===
match
---
parameters [37497,37514]
parameters [37619,37636]
===
match
---
name: processor [38872,38881]
name: processor [38994,39003]
===
match
---
name: sentinel [40132,40140]
name: sentinel [40254,40262]
===
match
---
trailer [27657,27678]
trailer [27779,27800]
===
match
---
simple_stmt [7977,8036]
simple_stmt [7977,8036]
===
match
---
trailer [3388,3390]
trailer [3388,3390]
===
match
---
simple_stmt [25003,25009]
simple_stmt [25125,25131]
===
match
---
name: self [22343,22347]
name: self [22465,22469]
===
match
---
trailer [14532,14541]
trailer [14654,14663]
===
match
---
name: pop [40397,40400]
name: pop [40519,40522]
===
match
---
trailer [40410,40420]
trailer [40532,40542]
===
match
---
name: self [19460,19464]
name: self [19582,19586]
===
match
---
argument [33903,33928]
argument [34025,34050]
===
match
---
expr_stmt [28850,28879]
expr_stmt [28972,29001]
===
match
---
simple_stmt [41399,41438]
simple_stmt [41521,41560]
===
match
---
trailer [21183,21221]
trailer [21305,21343]
===
match
---
trailer [39211,39213]
trailer [39333,39335]
===
match
---
param [37498,37503]
param [37620,37625]
===
match
---
operator: , [1835,1836]
operator: , [1835,1836]
===
match
---
simple_stmt [22494,22546]
simple_stmt [22616,22668]
===
match
---
name: timeout [40108,40115]
name: timeout [40230,40237]
===
match
---
atom_expr [42795,42835]
atom_expr [42917,42957]
===
match
---
trailer [25100,25104]
trailer [25222,25226]
===
match
---
operator: @ [4456,4457]
operator: @ [4456,4457]
===
match
---
atom_expr [29851,29881]
atom_expr [29973,30003]
===
match
---
operator: , [13399,13400]
operator: , [13521,13522]
===
match
---
name: self [17198,17202]
name: self [17320,17324]
===
match
---
trailer [8229,8231]
trailer [8229,8231]
===
match
---
simple_stmt [3079,3107]
simple_stmt [3079,3107]
===
match
---
simple_stmt [23568,23585]
simple_stmt [23690,23707]
===
match
---
expr_stmt [7201,7224]
expr_stmt [7201,7224]
===
match
---
name: self [2788,2792]
name: self [2788,2792]
===
match
---
simple_stmt [26821,26841]
simple_stmt [26943,26963]
===
match
---
operator: , [32684,32685]
operator: , [32806,32807]
===
match
---
name: self [21161,21165]
name: self [21283,21287]
===
match
---
import_from [1907,1963]
import_from [1907,1963]
===
match
---
operator: = [45057,45058]
operator: = [45179,45180]
===
match
---
name: shuffle [43477,43484]
name: shuffle [43599,43606]
===
match
---
argument [39581,39598]
argument [39703,39720]
===
match
---
operator: = [27647,27648]
operator: = [27769,27770]
===
match
---
simple_stmt [37409,37455]
simple_stmt [37531,37577]
===
match
---
string: """Waits until DAG parsing is finished.""" [11175,11217]
string: """Waits until DAG parsing is finished.""" [11175,11217]
===
match
---
trailer [41375,41386]
trailer [41497,41508]
===
match
---
atom_expr [24797,24874]
atom_expr [24919,24996]
===
match
---
suite [28031,28481]
suite [28153,28603]
===
match
---
simple_stmt [4797,4851]
simple_stmt [4797,4851]
===
match
---
simple_stmt [38299,38324]
simple_stmt [38421,38446]
===
match
---
atom_expr [23063,23078]
atom_expr [23185,23200]
===
match
---
name: self [14099,14103]
name: self [14221,14225]
===
match
---
if_stmt [15276,15704]
if_stmt [15398,15826]
===
match
---
trailer [40250,40309]
trailer [40372,40431]
===
match
---
trailer [14284,14290]
trailer [14406,14412]
===
match
---
atom_expr [38446,38476]
atom_expr [38568,38598]
===
match
---
suite [24723,25521]
suite [24845,25643]
===
match
---
name: State [45897,45902]
name: State [46019,46024]
===
match
---
operator: , [18917,18918]
operator: , [19039,19040]
===
match
---
arith_expr [28862,28879]
arith_expr [28984,29001]
===
match
---
name: perf_counter [48633,48645]
name: perf_counter [48755,48767]
===
match
---
atom_expr [41049,41072]
atom_expr [41171,41194]
===
match
---
and_test [42746,42865]
and_test [42868,42987]
===
match
---
operator: , [27909,27910]
operator: , [28031,28032]
===
match
---
atom_expr [39444,39463]
atom_expr [39566,39585]
===
match
---
parameters [31007,31013]
parameters [31129,31135]
===
match
---
dotted_name [1862,1880]
dotted_name [1862,1880]
===
match
---
fstring_string: .2f [34333,34336]
fstring_string: .2f [34455,34458]
===
match
---
import_from [1105,1183]
import_from [1105,1183]
===
match
---
import_name [809,820]
import_name [809,820]
===
match
---
name: pop [26475,26478]
name: pop [26597,26600]
===
match
---
operator: = [8337,8338]
operator: = [8337,8338]
===
match
---
name: now [33280,33283]
name: now [33402,33405]
===
match
---
atom [38321,38323]
atom [38443,38445]
===
match
---
trailer [46847,46853]
trailer [46969,46975]
===
match
---
trailer [11442,11444]
trailer [11560,11562]
===
match
---
operator: = [32652,32653]
operator: = [32774,32775]
===
match
---
simple_stmt [13614,13708]
simple_stmt [13736,13830]
===
match
---
name: _parent_signal_conn [14678,14697]
name: _parent_signal_conn [14800,14819]
===
match
---
name: agent_signal [25407,25419]
name: agent_signal [25529,25541]
===
match
---
comparison [45837,45859]
comparison [45959,45981]
===
match
---
comparison [47733,47764]
comparison [47855,47886]
===
match
---
operator: , [36630,36631]
operator: , [36752,36753]
===
match
---
atom_expr [23594,23682]
atom_expr [23716,23804]
===
match
---
trailer [45466,45479]
trailer [45588,45601]
===
match
---
simple_stmt [44390,44493]
simple_stmt [44512,44615]
===
match
---
trailer [46557,46580]
trailer [46679,46702]
===
match
---
name: log [30420,30423]
name: log [30542,30545]
===
match
---
arglist [43053,43109]
arglist [43175,43231]
===
match
---
simple_stmt [8780,8796]
simple_stmt [8780,8796]
===
match
---
name: Stats [38596,38601]
name: Stats [38718,38723]
===
match
---
name: files_paths_to_queue [44470,44490]
name: files_paths_to_queue [44592,44612]
===
match
---
name: setproctitle [1312,1324]
name: setproctitle [1312,1324]
===
match
---
trailer [40326,40336]
trailer [40448,40458]
===
match
---
trailer [15411,15415]
trailer [15533,15537]
===
match
---
trailer [23070,23076]
trailer [23192,23198]
===
match
---
trailer [35087,35099]
trailer [35209,35221]
===
match
---
name: self [33365,33369]
name: self [33487,33491]
===
match
---
name: get [37763,37766]
name: get [37885,37888]
===
match
---
arglist [14368,14391]
arglist [14490,14513]
===
match
---
name: super [6941,6946]
name: super [6941,6946]
===
match
---
operator: , [44365,44366]
operator: , [44487,44488]
===
match
---
trailer [21615,21636]
trailer [21737,21758]
===
match
---
atom_expr [13154,13170]
atom_expr [13276,13292]
===
match
---
atom_expr [32913,32947]
atom_expr [33035,33069]
===
match
---
atom_expr [25046,25074]
atom_expr [25168,25196]
===
match
---
import_from [1362,1388]
import_from [1362,1388]
===
match
---
simple_stmt [32960,33010]
simple_stmt [33082,33132]
===
match
---
operator: += [27002,27004]
operator: += [27124,27126]
===
match
---
name: _run_processor_manager [8297,8319]
name: _run_processor_manager [8297,8319]
===
match
---
trailer [24622,24633]
trailer [24744,24755]
===
match
---
name: processor [38479,38488]
name: processor [38601,38610]
===
match
---
dotted_name [1591,1618]
dotted_name [1591,1618]
===
match
---
operator: = [43531,43532]
operator: = [43653,43654]
===
match
---
name: airflow [45497,45504]
name: airflow [45619,45626]
===
match
---
import_name [1420,1441]
import_name [1420,1441]
===
match
---
simple_stmt [24966,24983]
simple_stmt [25088,25105]
===
match
---
trailer [26478,26499]
trailer [26600,26621]
===
match
---
atom_expr [40380,40421]
atom_expr [40502,40543]
===
match
---
atom [38173,38230]
atom [38295,38352]
===
match
---
string: "%d ) when using sqlite. So we set parallelism to 1." [20330,20383]
string: "%d ) when using sqlite. So we set parallelism to 1." [20452,20505]
===
match
---
name: time [8145,8149]
name: time [8145,8149]
===
match
---
trailer [27599,27611]
trailer [27721,27733]
===
match
---
operator: = [32971,32972]
operator: = [33093,33094]
===
match
---
subscriptlist [22266,22324]
subscriptlist [22388,22446]
===
match
---
name: close [17241,17246]
name: close [17363,17368]
===
match
---
name: last_run [33787,33795]
name: last_run [33909,33917]
===
match
---
simple_stmt [19570,19617]
simple_stmt [19692,19739]
===
match
---
name: prepare_file_path_queue [41705,41728]
name: prepare_file_path_queue [41827,41850]
===
match
---
name: self [30049,30053]
name: self [30171,30175]
===
match
---
return_stmt [35113,35151]
return_stmt [35235,35273]
===
match
---
atom_expr [8250,8738]
atom_expr [8250,8738]
===
match
---
expr_stmt [24740,24779]
expr_stmt [24862,24901]
===
match
---
if_stmt [26775,26888]
if_stmt [26897,27010]
===
match
---
atom_expr [7201,7214]
atom_expr [7201,7214]
===
match
---
simple_stmt [38446,38489]
simple_stmt [38568,38611]
===
match
---
suite [39048,39909]
suite [39170,40031]
===
match
---
name: pid [47144,47147]
name: pid [47266,47269]
===
match
---
simple_stmt [4673,4714]
simple_stmt [4673,4714]
===
match
---
name: message [14426,14433]
name: message [14548,14555]
===
match
---
trailer [16429,16438]
trailer [16551,16560]
===
match
---
atom_expr [40341,40366]
atom_expr [40463,40488]
===
match
---
suite [13748,13802]
suite [13870,13924]
===
match
---
string: 'dag_processing.manager_stalls' [15362,15393]
string: 'dag_processing.manager_stalls' [15484,15515]
===
match
---
trailer [19294,19309]
trailer [19416,19431]
===
match
---
simple_stmt [33703,33798]
simple_stmt [33825,33920]
===
match
---
arglist [13333,13526]
arglist [13455,13648]
===
match
---
atom_expr [48750,48834]
atom_expr [48872,48956]
===
match
---
name: pickle_dags [6881,6892]
name: pickle_dags [6881,6892]
===
match
---
name: self [35407,35411]
name: self [35529,35533]
===
match
---
atom [19233,19235]
atom [19355,19357]
===
match
---
name: headers [34653,34660]
name: headers [34775,34782]
===
match
---
atom_expr [39057,39121]
atom_expr [39179,39243]
===
match
---
atom_expr [21938,21964]
atom_expr [22060,22086]
===
match
---
atom [45088,45242]
atom [45210,45364]
===
match
---
string: """Terminate (and then kill) the process launched to process the file""" [2645,2717]
string: """Terminate (and then kill) the process launched to process the file""" [2645,2717]
===
match
---
name: CallbackRequest [6708,6723]
name: CallbackRequest [6708,6723]
===
match
---
name: waitables [22239,22248]
name: waitables [22361,22370]
===
match
---
name: _process [16430,16438]
name: _process [16552,16560]
===
match
---
name: session [45735,45742]
name: session [45857,45864]
===
match
---
trailer [23520,23522]
trailer [23642,23644]
===
match
---
operator: , [38345,38346]
operator: , [38467,38468]
===
match
---
name: self [21484,21488]
name: self [21606,21610]
===
match
---
name: os [23568,23570]
name: os [23690,23692]
===
match
---
name: self [37416,37420]
name: self [37538,37542]
===
match
---
atom_expr [41590,41617]
atom_expr [41712,41739]
===
match
---
atom_expr [18919,18940]
atom_expr [19041,19062]
===
match
---
atom_expr [22494,22545]
atom_expr [22616,22667]
===
match
---
import_name [2272,2286]
import_name [2272,2286]
===
match
---
name: AbstractDagFileProcessorProcess [6754,6785]
name: AbstractDagFileProcessorProcess [6754,6785]
===
match
---
name: exception [30649,30658]
name: exception [30771,30780]
===
match
---
string: "Processing files using up to %s processes at a time " [23608,23662]
string: "Processing files using up to %s processes at a time " [23730,23784]
===
match
---
atom_expr [15837,15846]
atom_expr [15959,15968]
===
match
---
import_as_names [1203,1285]
import_as_names [1203,1285]
===
match
---
string: """Have all files been processed at least once?""" [16147,16197]
string: """Have all files been processed at least once?""" [16269,16319]
===
match
---
arglist [25327,25356]
arglist [25449,25478]
===
match
---
atom_expr [46487,46536]
atom_expr [46609,46658]
===
match
---
simple_stmt [23691,23785]
simple_stmt [23813,23907]
===
match
---
funcdef [47485,47883]
funcdef [47607,48005]
===
match
---
atom_expr [42041,42064]
atom_expr [42163,42186]
===
match
---
operator: , [35828,35829]
operator: , [35950,35951]
===
match
---
trailer [38889,38901]
trailer [39011,39023]
===
match
---
trailer [46853,46855]
trailer [46975,46977]
===
match
---
name: max_runs_reached [27732,27748]
name: max_runs_reached [27854,27870]
===
match
---
trailer [30062,30112]
trailer [30184,30234]
===
match
---
name: get_last_error_count [36200,36220]
name: get_last_error_count [36322,36342]
===
match
---
name: process [8763,8770]
name: process [8763,8770]
===
match
---
name: self [26782,26786]
name: self [26904,26908]
===
match
---
atom_expr [30245,30330]
atom_expr [30367,30452]
===
match
---
expr_stmt [42261,42276]
expr_stmt [42383,42398]
===
match
---
string: 'scheduler_zombie_task_threshold' [20972,21005]
string: 'scheduler_zombie_task_threshold' [21094,21127]
===
match
---
name: _all_files_processed [7668,7688]
name: _all_files_processed [7668,7688]
===
match
---
expr_stmt [39268,39316]
expr_stmt [39390,39438]
===
match
---
name: processor [40234,40243]
name: processor [40356,40365]
===
match
---
raise_stmt [4409,4436]
raise_stmt [4409,4436]
===
match
---
name: files_with_mtime [43053,43069]
name: files_with_mtime [43175,43191]
===
match
---
name: log [14281,14284]
name: log [14403,14406]
===
match
---
trailer [15321,15335]
trailer [15443,15457]
===
match
---
name: os [13222,13224]
name: os [13344,13346]
===
match
---
name: result [11564,11570]
name: result [11683,11689]
===
match
---
trailer [41666,41682]
trailer [41788,41804]
===
match
---
operator: , [8195,8196]
operator: , [8195,8196]
===
match
---
if_stmt [27020,27452]
if_stmt [27142,27574]
===
match
---
atom_expr [20446,20463]
atom_expr [20568,20585]
===
match
---
name: setproctitle [1292,1304]
name: setproctitle [1292,1304]
===
match
---
atom_expr [42676,42712]
atom_expr [42798,42834]
===
match
---
name: reload [13036,13042]
name: reload [13158,13164]
===
match
---
name: self [44390,44394]
name: self [44512,44516]
===
match
---
name: log [27066,27069]
name: log [27188,27191]
===
match
---
name: TYPE_CHECKING [2253,2266]
name: TYPE_CHECKING [2253,2266]
===
match
---
name: self [41286,41290]
name: self [41408,41412]
===
match
---
trailer [7519,7531]
trailer [7519,7531]
===
match
---
name: DagModel [1508,1516]
name: DagModel [1508,1516]
===
match
---
operator: , [33771,33772]
operator: , [33893,33894]
===
match
---
name: processor [40471,40480]
name: processor [40593,40602]
===
match
---
param [7860,7864]
param [7860,7864]
===
match
---
atom_expr [10008,10032]
atom_expr [10008,10032]
===
match
---
trailer [23053,23080]
trailer [23175,23202]
===
match
---
trailer [41168,41179]
trailer [41290,41301]
===
match
---
atom_expr [21161,21177]
atom_expr [21283,21299]
===
match
---
simple_stmt [27809,27996]
simple_stmt [27931,28118]
===
match
---
decorator [4030,4046]
decorator [4030,4046]
===
match
---
atom_expr [14872,14881]
atom_expr [14994,15003]
===
match
---
trailer [47297,47302]
trailer [47419,47424]
===
match
---
name: processor_manager [13276,13293]
name: processor_manager [13398,13415]
===
match
---
atom_expr [7357,7373]
atom_expr [7357,7373]
===
match
---
trailer [33036,33041]
trailer [33158,33163]
===
match
---
name: file [1876,1880]
name: file [1876,1880]
===
match
---
name: ImportError [31739,31750]
name: ImportError [31861,31872]
===
match
---
string: "Process not started." [11288,11310]
string: "Process not started." [11288,11310]
===
match
---
operator: = [31331,31332]
operator: = [31453,31454]
===
match
---
name: self [21611,21615]
name: self [21733,21737]
===
match
---
atom_expr [44607,44634]
atom_expr [44729,44756]
===
match
---
operator: = [10811,10812]
operator: = [10811,10812]
===
match
---
simple_stmt [10737,10778]
simple_stmt [10737,10778]
===
match
---
suite [11387,11445]
suite [11505,11563]
===
match
---
trailer [41485,41489]
trailer [41607,41611]
===
match
---
operator: , [46405,46406]
operator: , [46527,46528]
===
match
---
operator: > [46931,46932]
operator: > [47053,47054]
===
match
---
param [12044,12083]
param [12166,12205]
===
match
---
operator: = [21965,21966]
operator: = [22087,22088]
===
match
---
name: processor [41686,41695]
name: processor [41808,41817]
===
match
---
name: self [7783,7787]
name: self [7783,7787]
===
match
---
name: monotonic [31338,31347]
name: monotonic [31460,31469]
===
match
---
name: runtime [33987,33994]
name: runtime [34109,34116]
===
match
---
trailer [40288,40298]
trailer [40410,40420]
===
match
---
name: STORE_DAG_CODE [21092,21106]
name: STORE_DAG_CODE [21214,21228]
===
match
---
simple_stmt [29454,29597]
simple_stmt [29576,29719]
===
match
---
operator: = [7039,7040]
operator: = [7039,7040]
===
match
---
simple_stmt [19176,19195]
simple_stmt [19298,19317]
===
match
---
name: debug [24806,24811]
name: debug [24928,24933]
===
match
---
name: time [31333,31337]
name: time [31455,31459]
===
match
---
name: timezone [1747,1755]
name: timezone [1747,1755]
===
match
---
simple_stmt [30640,30695]
simple_stmt [30762,30817]
===
match
---
operator: = [20574,20575]
operator: = [20696,20697]
===
match
---
name: self [41143,41147]
name: self [41265,41269]
===
match
---
import_name [929,939]
import_name [929,939]
===
match
---
trailer [19181,19183]
trailer [19303,19305]
===
match
---
trailer [36929,36941]
trailer [37051,37063]
===
match
---
raise_stmt [2726,2753]
raise_stmt [2726,2753]
===
match
---
atom_expr [13898,13941]
atom_expr [14020,14063]
===
match
---
simple_stmt [30415,30460]
simple_stmt [30537,30582]
===
match
---
atom_expr [19267,19276]
atom_expr [19389,19398]
===
match
---
name: now [45053,45056]
name: now [45175,45178]
===
match
---
trailer [25326,25357]
trailer [25448,25479]
===
match
---
trailer [46580,46589]
trailer [46702,46711]
===
match
---
atom_expr [21484,21514]
atom_expr [21606,21636]
===
match
---
name: NamedTuple [4780,4790]
name: NamedTuple [4780,4790]
===
match
---
name: get [36942,36945]
name: get [37064,37067]
===
match
---
string: "\n\t" [44458,44464]
string: "\n\t" [44580,44586]
===
match
---
name: or_ [45957,45960]
name: or_ [46079,46082]
===
match
---
simple_stmt [30196,30233]
simple_stmt [30318,30355]
===
match
---
arglist [41245,41318]
arglist [41367,41440]
===
match
---
trailer [22170,22175]
trailer [22292,22297]
===
match
---
trailer [40548,40566]
trailer [40670,40688]
===
match
---
name: _file_path_queue [19249,19265]
name: _file_path_queue [19371,19387]
===
match
---
trailer [11350,11355]
trailer [11468,11473]
===
match
---
atom_expr [40906,40934]
atom_expr [41028,41056]
===
match
---
trailer [25383,25406]
trailer [25505,25528]
===
match
---
name: TERMINATE_MANAGER [5106,5123]
name: TERMINATE_MANAGER [5106,5123]
===
match
---
trailer [23148,23188]
trailer [23270,23310]
===
match
---
name: last_finish_time [4897,4913]
name: last_finish_time [4897,4913]
===
match
---
name: get [43092,43095]
name: get [43214,43217]
===
match
---
name: self [19960,19964]
name: self [20082,20086]
===
match
---
trailer [44177,44179]
trailer [44299,44301]
===
match
---
simple_stmt [26625,26659]
simple_stmt [26747,26781]
===
match
---
atom_expr [40401,40420]
atom_expr [40523,40542]
===
match
---
name: Pipe [8225,8229]
name: Pipe [8225,8229]
===
match
---
trailer [44171,44177]
trailer [44293,44299]
===
match
---
name: items [46848,46853]
name: items [46970,46975]
===
match
---
name: monotonic [28762,28771]
name: monotonic [28884,28893]
===
match
---
operator: , [20599,20600]
operator: , [20721,20722]
===
match
---
trailer [22265,22325]
trailer [22387,22447]
===
match
---
trailer [30167,30182]
trailer [30289,30304]
===
match
---
argument [14842,14851]
argument [14964,14973]
===
match
---
name: Tuple [1267,1272]
name: Tuple [1267,1272]
===
match
---
trailer [17240,17246]
trailer [17362,17368]
===
match
---
trailer [31803,31832]
trailer [31925,31954]
===
match
---
simple_stmt [10342,10347]
simple_stmt [10342,10347]
===
match
---
simple_stmt [35331,35381]
simple_stmt [35453,35503]
===
match
---
argument [34645,34660]
argument [34767,34782]
===
match
---
trailer [11529,11537]
trailer [11648,11656]
===
match
---
name: self [35083,35087]
name: self [35205,35209]
===
match
---
atom_expr [41143,41179]
atom_expr [41265,41301]
===
match
---
param [6656,6796]
param [6656,6796]
===
match
---
name: end [25101,25104]
name: end [25223,25226]
===
match
---
argument [39706,39777]
argument [39828,39899]
===
match
---
name: get_hostname [43461,43473]
name: get_hostname [43583,43595]
===
match
---
tfpdef [10419,10430]
tfpdef [10419,10430]
===
match
---
simple_stmt [10046,10087]
simple_stmt [10046,10087]
===
match
---
name: _run_parsing_loop [23948,23965]
name: _run_parsing_loop [24070,24087]
===
match
---
operator: @ [3679,3680]
operator: @ [3679,3680]
===
match
---
trailer [45988,45994]
trailer [46110,46116]
===
match
---
funcdef [16699,17249]
funcdef [16821,17371]
===
match
---
operator: , [1272,1273]
operator: , [1272,1273]
===
match
---
operator: = [33032,33033]
operator: = [33154,33155]
===
match
---
number: 10 [21715,21717]
number: 10 [21837,21839]
===
match
---
simple_stmt [2487,2532]
simple_stmt [2487,2532]
===
match
---
name: net [2048,2051]
name: net [2048,2051]
===
match
---
name: str [11935,11938]
name: str [12057,12060]
===
match
---
name: os [12794,12796]
name: os [12916,12918]
===
match
---
trailer [39140,39168]
trailer [39262,39290]
===
match
---
suite [49052,49085]
suite [49174,49207]
===
match
---
expr_stmt [43660,43796]
expr_stmt [43782,43918]
===
match
---
atom_expr [21967,22016]
atom_expr [22089,22138]
===
match
---
simple_stmt [22554,22607]
simple_stmt [22676,22729]
===
match
---
suite [31193,31350]
suite [31315,31472]
===
match
---
simple_stmt [40894,40935]
simple_stmt [41016,41057]
===
match
---
expr_stmt [30196,30232]
expr_stmt [30318,30354]
===
match
---
name: waitables [26245,26254]
name: waitables [26367,26376]
===
match
---
trailer [48645,48647]
trailer [48767,48769]
===
match
---
trailer [28413,28480]
trailer [28535,28602]
===
match
---
name: LJ [45986,45988]
name: LJ [46108,46110]
===
match
---
name: processor [48004,48013]
name: processor [48126,48135]
===
match
---
atom_expr [17198,17206]
atom_expr [17320,17328]
===
match
---
not_test [13719,13747]
not_test [13841,13869]
===
match
---
suite [37869,38768]
suite [37991,38890]
===
match
---
trailer [21805,21824]
trailer [21927,21946]
===
match
---
operator: = [33277,33278]
operator: = [33399,33400]
===
match
---
trailer [6683,6795]
trailer [6683,6795]
===
match
---
for_stmt [26109,26500]
for_stmt [26231,26622]
===
match
---
name: ConnectionError [9535,9550]
name: ConnectionError [9535,9550]
===
match
---
atom_expr [25379,25420]
atom_expr [25501,25542]
===
match
---
name: _processors [41054,41065]
name: _processors [41176,41187]
===
match
---
operator: + [34553,34554]
operator: + [34675,34676]
===
match
---
trailer [16869,16877]
trailer [16991,16999]
===
match
---
expr_stmt [21161,21226]
expr_stmt [21283,21348]
===
match
---
trailer [44398,44404]
trailer [44520,44526]
===
match
---
trailer [28711,28723]
trailer [28833,28845]
===
match
---
operator: = [39625,39626]
operator: = [39747,39748]
===
match
---
atom_expr [45497,45520]
atom_expr [45619,45642]
===
match
---
trailer [26385,26396]
trailer [26507,26518]
===
match
---
atom_expr [42399,42415]
atom_expr [42521,42537]
===
match
---
simple_stmt [22234,22391]
simple_stmt [22356,22513]
===
match
---
name: AbstractDagFileProcessorProcess [22293,22324]
name: AbstractDagFileProcessorProcess [22415,22446]
===
match
---
simple_stmt [32745,32755]
simple_stmt [32867,32877]
===
match
---
parameters [36625,36642]
parameters [36747,36764]
===
match
---
name: info [23700,23704]
name: info [23822,23826]
===
match
---
name: session [31635,31642]
name: session [31757,31764]
===
match
---
simple_stmt [45707,46148]
simple_stmt [45829,46270]
===
match
---
atom_expr [40491,40586]
atom_expr [40613,40708]
===
match
---
name: self [31764,31768]
name: self [31886,31890]
===
match
---
lambdef [33907,33928]
lambdef [34029,34050]
===
match
---
operator: , [46340,46341]
operator: , [46462,46463]
===
match
---
simple_stmt [15691,15704]
simple_stmt [15813,15826]
===
match
---
operator: = [21713,21714]
operator: = [21835,21836]
===
match
---
trailer [46131,46133]
trailer [46253,46255]
===
match
---
name: last_finish_time [39177,39193]
name: last_finish_time [39299,39315]
===
match
---
name: ready [40144,40149]
name: ready [40266,40271]
===
match
---
atom_expr [17172,17189]
atom_expr [17294,17311]
===
match
---
atom_expr [23691,23784]
atom_expr [23813,23906]
===
match
---
decorator [2573,2589]
decorator [2573,2589]
===
match
---
simple_stmt [19290,19326]
simple_stmt [19412,19448]
===
match
---
name: self [23995,23999]
name: self [24117,24121]
===
match
---
name: os [33086,33088]
name: os [33208,33210]
===
match
---
annassign [4982,4987]
annassign [4982,4987]
===
match
---
name: async_mode [19551,19561]
name: async_mode [19673,19683]
===
match
---
name: start_new_processes [40687,40706]
name: start_new_processes [40809,40828]
===
match
---
name: cast [40246,40250]
name: cast [40368,40372]
===
match
---
trailer [30162,30183]
trailer [30284,30305]
===
match
---
name: file_path [33971,33980]
name: file_path [34093,34102]
===
match
---
expr_stmt [40234,40309]
expr_stmt [40356,40431]
===
match
---
string: """Information about single processing of one file""" [4797,4850]
string: """Information about single processing of one file""" [4797,4850]
===
match
---
trailer [33714,33797]
trailer [33836,33919]
===
match
---
name: bool [19148,19152]
name: bool [19270,19274]
===
match
---
atom_expr [26479,26498]
atom_expr [26601,26620]
===
match
---
import_from [1442,1480]
import_from [1442,1480]
===
match
---
atom [21224,21226]
atom [21346,21348]
===
match
---
atom_expr [22923,22991]
atom_expr [23045,23113]
===
match
---
arglist [44670,44753]
arglist [44792,44875]
===
match
---
name: ConnectionError [14047,14062]
name: ConnectionError [14169,14184]
===
match
---
name: errors [31649,31655]
name: errors [31771,31777]
===
match
---
name: self [28636,28640]
name: self [28758,28762]
===
match
---
import_from [1857,1906]
import_from [1857,1906]
===
match
---
trailer [15642,15678]
trailer [15764,15800]
===
match
---
name: send [10137,10141]
name: send [10137,10141]
===
match
---
trailer [45960,46092]
trailer [46082,46214]
===
match
---
trailer [13153,13171]
trailer [13275,13293]
===
match
---
name: _dag_ids [41291,41299]
name: _dag_ids [41413,41421]
===
match
---
suite [10790,10927]
suite [10790,10927]
===
match
---
name: get_last_finish_time [33370,33390]
name: get_last_finish_time [33492,33512]
===
match
---
trailer [33707,33714]
trailer [33829,33836]
===
match
---
comparison [42746,42774]
comparison [42868,42896]
===
match
---
atom_expr [23664,23681]
atom_expr [23786,23803]
===
match
---
name: self [28531,28535]
name: self [28653,28657]
===
match
---
name: self [31412,31416]
name: self [31534,31538]
===
match
---
number: 0 [37821,37822]
number: 0 [37943,37944]
===
match
---
trailer [23668,23681]
trailer [23790,23803]
===
match
---
string: """         :param file_path: the path to the file that was processed         :type file_path: unicode         :return: the number of dags loaded from that file, or None if the file             was never processed.         :rtype: int         """ [35850,36096]
string: """         :param file_path: the path to the file that was processed         :type file_path: unicode         :return: the number of dags loaded from that file, or None if the file             was never processed.         :rtype: int         """ [35972,36218]
===
match
---
operator: -> [39040,39042]
operator: -> [39162,39164]
===
match
---
trailer [47415,47446]
trailer [47537,47568]
===
match
---
name: reap_process_group [17153,17171]
name: reap_process_group [17275,17293]
===
match
---
simple_stmt [9424,9431]
simple_stmt [9424,9431]
===
match
---
expr_stmt [33354,33401]
expr_stmt [33476,33523]
===
match
---
funcdef [10352,11123]
funcdef [10352,11123]
===
match
---
comp_op [42763,42769]
comp_op [42885,42891]
===
match
---
simple_stmt [11271,11312]
simple_stmt [11271,11312]
===
match
---
name: sleep [38971,38976]
name: sleep [39093,39098]
===
match
---
expr_stmt [45053,45076]
expr_stmt [45175,45198]
===
match
---
trailer [23004,23008]
trailer [23126,23130]
===
match
---
operator: + [34530,34531]
operator: + [34652,34653]
===
match
---
name: self [8171,8175]
name: self [8171,8175]
===
match
---
test [36559,36595]
test [36681,36717]
===
match
---
atom_expr [8747,8760]
atom_expr [8747,8760]
===
match
---
name: signal_conn [19023,19034]
name: signal_conn [19145,19156]
===
match
---
trailer [48780,48833]
trailer [48902,48955]
===
match
---
tfpdef [19136,19152]
tfpdef [19258,19274]
===
match
---
operator: , [20154,20155]
operator: , [20276,20277]
===
match
---
simple_stmt [43165,43197]
simple_stmt [43287,43319]
===
match
---
operator: { [22329,22330]
operator: { [22451,22452]
===
match
---
atom_expr [40545,40566]
atom_expr [40667,40688]
===
match
---
atom_expr [33226,33256]
atom_expr [33348,33378]
===
match
---
trailer [36941,36945]
trailer [37063,37067]
===
match
---
name: self [25929,25933]
name: self [26051,26055]
===
match
---
atom_expr [29939,29965]
atom_expr [30061,30087]
===
match
---
name: DM [45833,45835]
name: DM [45955,45957]
===
match
---
name: get [35729,35732]
name: get [35851,35854]
===
match
---
simple_stmt [2645,2718]
simple_stmt [2645,2718]
===
match
---
trailer [41606,41617]
trailer [41728,41739]
===
match
---
operator: , [21187,21188]
operator: , [21309,21310]
===
match
---
parameters [13590,13596]
parameters [13712,13718]
===
match
---
name: _dag_ids [7206,7214]
name: _dag_ids [7206,7214]
===
match
---
trailer [48811,48823]
trailer [48933,48945]
===
match
---
operator: , [15732,15733]
operator: , [15854,15855]
===
match
---
atom_expr [15213,15229]
atom_expr [15335,15351]
===
match
---
simple_stmt [24132,24148]
simple_stmt [24254,24270]
===
match
---
simple_stmt [46771,46795]
simple_stmt [46893,46917]
===
match
---
trailer [26254,26258]
trailer [26376,26380]
===
match
---
operator: { [33556,33557]
operator: { [33678,33679]
===
match
---
name: self [47750,47754]
name: self [47872,47876]
===
match
---
atom_expr [7273,7289]
atom_expr [7273,7289]
===
match
---
fstring_expr [34181,34210]
fstring_expr [34303,34332]
===
match
---
simple_stmt [40322,40368]
simple_stmt [40444,40490]
===
match
---
operator: = [7001,7002]
operator: = [7001,7002]
===
match
---
annassign [7033,7054]
annassign [7033,7054]
===
match
---
name: str [18832,18835]
name: str [18954,18957]
===
match
---
name: SerializedDagModel [1567,1585]
name: SerializedDagModel [1567,1585]
===
match
---
trailer [24653,24658]
trailer [24775,24780]
===
match
---
funcdef [37828,38768]
funcdef [37950,38890]
===
match
---
decorated [2573,2754]
decorated [2573,2754]
===
match
---
simple_stmt [21316,21362]
simple_stmt [21438,21484]
===
match
---
name: utils [2224,2229]
name: utils [2224,2229]
===
match
---
string: """A "waitable" handle that can be passed to ``multiprocessing.connection.wait()``""" [4511,4596]
string: """A "waitable" handle that can be passed to ``multiprocessing.connection.wait()``""" [4511,4596]
===
match
---
trailer [15421,15611]
trailer [15543,15733]
===
match
---
operator: = [46382,46383]
operator: = [46504,46505]
===
match
---
trailer [8224,8229]
trailer [8224,8229]
===
match
---
number: 0 [21639,21640]
number: 0 [21761,21762]
===
match
---
name: _async_mode [27032,27043]
name: _async_mode [27154,27165]
===
match
---
atom_expr [39101,39120]
atom_expr [39223,39242]
===
match
---
trailer [29855,29881]
trailer [29977,30003]
===
match
---
trailer [15236,15267]
trailer [15358,15389]
===
match
---
simple_stmt [19460,19492]
simple_stmt [19582,19614]
===
match
---
name: self [26857,26861]
name: self [26979,26983]
===
match
---
simple_stmt [23134,23189]
simple_stmt [23256,23311]
===
match
---
trailer [14223,14225]
trailer [14345,14347]
===
match
---
name: waitable_handle [40351,40366]
name: waitable_handle [40473,40488]
===
match
---
name: self [9271,9275]
name: self [9271,9275]
===
match
---
trailer [39868,39880]
trailer [39990,40002]
===
match
---
trailer [30968,30986]
trailer [31090,31108]
===
match
---
import_name [915,928]
import_name [915,928]
===
match
---
atom_expr [14322,14344]
atom_expr [14444,14466]
===
match
---
name: append [42567,42573]
name: append [42689,42695]
===
match
---
trailer [13099,13107]
trailer [13221,13229]
===
match
---
name: ValueError [10743,10753]
name: ValueError [10743,10753]
===
match
---
subscriptlist [11934,11995]
subscriptlist [12056,12117]
===
match
---
trailer [44809,44831]
trailer [44931,44953]
===
match
---
trailer [7101,7120]
trailer [7101,7120]
===
match
---
trailer [23048,23053]
trailer [23170,23175]
===
match
---
name: last_dag_dir_refresh_time [29856,29881]
name: last_dag_dir_refresh_time [29978,30003]
===
match
---
name: _num_run [26993,27001]
name: _num_run [27115,27123]
===
match
---
trailer [26417,26427]
trailer [26539,26549]
===
match
---
name: connection [24623,24633]
name: connection [24745,24755]
===
match
---
simple_stmt [33203,33257]
simple_stmt [33325,33379]
===
match
---
trailer [33896,33929]
trailer [34018,34051]
===
match
---
atom_expr [40031,40118]
atom_expr [40153,40240]
===
match
---
operator: , [34157,34158]
operator: , [34279,34280]
===
match
---
trailer [35370,35377]
trailer [35492,35499]
===
match
---
name: stat [47683,47687]
name: stat [47805,47809]
===
match
---
name: int [3739,3742]
name: int [3739,3742]
===
match
---
simple_stmt [1105,1184]
simple_stmt [1105,1184]
===
match
---
name: self [20742,20746]
name: self [20864,20868]
===
match
---
string: "Checking for new files in %s every %s seconds" [23820,23867]
string: "Checking for new files in %s every %s seconds" [23942,23989]
===
match
---
name: environ [12797,12804]
name: environ [12919,12926]
===
match
---
operator: = [34497,34498]
operator: = [34619,34620]
===
match
---
name: self [38797,38801]
name: self [38919,38923]
===
match
---
trailer [34731,34736]
trailer [34853,34858]
===
match
---
atom_expr [25127,25145]
atom_expr [25249,25267]
===
match
---
test [34317,34365]
test [34439,34487]
===
match
---
suite [11588,11796]
suite [11707,11918]
===
match
---
name: timezone [45546,45554]
name: timezone [45668,45676]
===
match
---
trailer [24471,24473]
trailer [24593,24595]
===
match
---
simple_stmt [33939,33959]
simple_stmt [34061,34081]
===
match
---
name: self [23664,23668]
name: self [23786,23790]
===
match
---
name: num_dags [32902,32910]
name: num_dags [33024,33032]
===
match
---
name: file_loc [46230,46238]
name: file_loc [46352,46360]
===
match
---
name: type [14519,14523]
name: type [14641,14645]
===
match
---
not_test [26288,26301]
not_test [26410,26423]
===
match
---
if_stmt [33595,33690]
if_stmt [33717,33812]
===
match
---
simple_stmt [48056,48095]
simple_stmt [48178,48217]
===
match
---
expr_stmt [31305,31349]
expr_stmt [31427,31471]
===
match
---
name: Stats [33506,33511]
name: Stats [33628,33633]
===
match
---
string: 'dag_processing.processes' [48067,48093]
string: 'dag_processing.processes' [48189,48215]
===
match
---
name: environ [12860,12867]
name: environ [12982,12989]
===
match
---
operator: @ [2948,2949]
operator: @ [2948,2949]
===
match
---
simple_stmt [19500,19524]
simple_stmt [19622,19646]
===
match
---
simple_stmt [853,868]
simple_stmt [853,868]
===
match
---
name: conf [20576,20580]
name: conf [20698,20702]
===
match
---
name: gauge [48689,48694]
name: gauge [48811,48816]
===
match
---
name: NotImplementedError [3369,3388]
name: NotImplementedError [3369,3388]
===
match
---
name: decr [47243,47247]
name: decr [47365,47369]
===
match
---
simple_stmt [46686,46763]
simple_stmt [46808,46885]
===
match
---
atom_expr [14717,14751]
atom_expr [14839,14873]
===
match
---
name: Stats [15351,15356]
name: Stats [15473,15478]
===
match
---
name: waitables [24644,24653]
name: waitables [24766,24775]
===
match
---
name: waitables [40289,40298]
name: waitables [40411,40420]
===
match
---
name: file_paths [43485,43495]
name: file_paths [43607,43617]
===
match
---
name: self [37379,37383]
name: self [37501,37505]
===
match
---
suite [3745,4011]
suite [3745,4011]
===
match
---
atom_expr [26625,26658]
atom_expr [26747,26780]
===
match
---
string: "scheduler" [42183,42194]
string: "scheduler" [42305,42316]
===
match
---
simple_stmt [42016,42065]
simple_stmt [42138,42187]
===
match
---
name: _file_stats [21321,21332]
name: _file_stats [21443,21454]
===
match
---
atom_expr [21517,21563]
atom_expr [21639,21685]
===
match
---
atom_expr [22178,22224]
atom_expr [22300,22346]
===
match
---
if_stmt [28808,28938]
if_stmt [28930,29060]
===
match
---
operator: + [34572,34573]
operator: + [34694,34695]
===
match
---
parameters [2606,2635]
parameters [2606,2635]
===
match
---
name: _parent_signal_conn [9276,9295]
name: _parent_signal_conn [9276,9295]
===
match
---
name: list_mode [42162,42171]
name: list_mode [42284,42293]
===
match
---
operator: , [32694,32695]
operator: , [32816,32817]
===
match
---
name: last_run [33354,33362]
name: last_run [33476,33484]
===
match
---
name: airflow [2034,2041]
name: airflow [2034,2041]
===
match
---
trailer [45459,45466]
trailer [45581,45588]
===
match
---
name: _parallelism [40814,40826]
name: _parallelism [40936,40948]
===
match
---
trailer [42573,42584]
trailer [42695,42706]
===
match
---
atom_expr [45986,45994]
atom_expr [46108,46116]
===
match
---
name: num_dags [44670,44678]
name: num_dags [44792,44800]
===
match
---
name: stat [48927,48931]
name: stat [49049,49053]
===
match
---
trailer [44159,44171]
trailer [44281,44293]
===
match
---
number: 1 [28827,28828]
number: 1 [28949,28950]
===
match
---
name: _file_path_queue [40864,40880]
name: _file_path_queue [40986,41002]
===
match
---
simple_stmt [48157,48269]
simple_stmt [48279,48391]
===
match
---
atom_expr [31275,31291]
atom_expr [31397,31413]
===
match
---
fstring [33518,33568]
fstring [33640,33690]
===
match
---
trailer [9399,9408]
trailer [9399,9408]
===
match
---
operator: , [34004,34005]
operator: , [34126,34127]
===
match
---
atom_expr [35712,35743]
atom_expr [35834,35865]
===
match
---
string: """         Should only be used when launched DAG file processor manager in sync mode.         Send agent heartbeat signal to the manager, requesting that it runs one         processing "loop".          Call wait_until_finished to ensure that any launched processors have         finished before continuing         """ [8937,9255]
string: """         Should only be used when launched DAG file processor manager in sync mode.         Send agent heartbeat signal to the manager, requesting that it runs one         processing "loop".          Call wait_until_finished to ensure that any launched processors have         finished before continuing         """ [8937,9255]
===
match
---
atom_expr [15298,15337]
atom_expr [15420,15459]
===
match
---
name: _dag_directory [30315,30329]
name: _dag_directory [30437,30451]
===
match
---
trailer [33230,33245]
trailer [33352,33367]
===
match
---
name: pickle_dags [7253,7264]
name: pickle_dags [7253,7264]
===
match
---
suite [25215,25295]
suite [25337,25417]
===
match
---
trailer [27831,27995]
trailer [27953,28117]
===
match
---
operator: = [41618,41619]
operator: = [41740,41741]
===
match
---
trailer [11417,11437]
trailer [11535,11555]
===
match
---
expr_stmt [31627,31668]
expr_stmt [31749,31790]
===
match
---
arglist [23015,23080]
arglist [23137,23202]
===
match
---
name: get [36529,36532]
name: get [36651,36654]
===
match
---
simple_stmt [25929,26070]
simple_stmt [26051,26192]
===
match
---
decorator [4456,4472]
decorator [4456,4472]
===
match
---
trailer [43052,43110]
trailer [43174,43232]
===
match
---
dictorsetmaker [22343,22380]
dictorsetmaker [22465,22502]
===
match
---
simple_stmt [41112,41180]
simple_stmt [41234,41302]
===
match
---
expr_stmt [42162,42221]
expr_stmt [42284,42343]
===
match
---
atom_expr [23054,23079]
atom_expr [23176,23201]
===
match
---
trailer [7709,7729]
trailer [7709,7729]
===
match
---
trailer [35136,35147]
trailer [35258,35269]
===
match
---
trailer [13319,13536]
trailer [13441,13658]
===
match
---
arglist [33125,33136]
arglist [33247,33258]
===
match
---
name: self [8805,8809]
name: self [8805,8809]
===
match
---
name: last_runtime [34343,34355]
name: last_runtime [34465,34477]
===
match
---
simple_stmt [15855,15908]
simple_stmt [15977,16030]
===
match
---
operator: = [38319,38320]
operator: = [38441,38442]
===
match
---
operator: = [45495,45496]
operator: = [45617,45618]
===
match
---
number: 0 [23582,23583]
number: 0 [23704,23705]
===
match
---
name: log [28404,28407]
name: log [28526,28529]
===
match
---
operator: , [6795,6796]
operator: , [6795,6796]
===
match
---
operator: = [29787,29788]
operator: = [29909,29910]
===
match
---
name: clear_nonexistent_import_errors [31380,31411]
name: clear_nonexistent_import_errors [31502,31533]
===
match
---
name: List [18919,18923]
name: List [19041,19045]
===
match
---
name: self [40434,40438]
name: self [40556,40560]
===
match
---
operator: , [44140,44141]
operator: , [44262,44263]
===
match
---
operator: == [43134,43136]
operator: == [43256,43258]
===
match
---
operator: , [19126,19127]
operator: , [19248,19249]
===
match
---
trailer [21978,22016]
trailer [22100,22138]
===
match
---
operator: < [47820,47821]
operator: < [47942,47943]
===
match
---
trailer [47609,47619]
trailer [47731,47741]
===
match
---
arglist [8279,8728]
arglist [8279,8728]
===
match
---
trailer [26786,26803]
trailer [26908,26925]
===
match
---
trailer [34083,34480]
trailer [34205,34602]
===
match
---
name: type [14322,14326]
name: type [14444,14448]
===
match
---
atom_expr [14785,14809]
atom_expr [14907,14931]
===
match
---
simple_stmt [43033,43111]
simple_stmt [43155,43233]
===
match
---
atom_expr [48017,48042]
atom_expr [48139,48164]
===
match
---
trailer [23947,23965]
trailer [24069,24087]
===
match
---
name: terminate [16248,16257]
name: terminate [16370,16379]
===
match
---
arglist [29634,29658]
arglist [29756,29780]
===
match
---
name: _max_runs [7068,7077]
name: _max_runs [7068,7077]
===
match
---
trailer [7153,7172]
trailer [7153,7172]
===
match
---
atom_expr [7548,7558]
atom_expr [7548,7558]
===
match
---
simple_stmt [5068,5102]
simple_stmt [5068,5102]
===
match
---
atom_expr [8780,8795]
atom_expr [8780,8795]
===
match
---
name: pickle_dags [13490,13501]
name: pickle_dags [13612,13623]
===
match
---
operator: = [7251,7252]
operator: = [7251,7252]
===
match
---
simple_stmt [8240,8739]
simple_stmt [8240,8739]
===
match
---
atom_expr [20070,20115]
atom_expr [20192,20237]
===
match
---
name: _pickle_dags [8666,8678]
name: _pickle_dags [8666,8678]
===
match
---
name: _process [15038,15046]
name: _process [15160,15168]
===
match
---
name: str [19272,19275]
name: str [19394,19397]
===
match
---
name: agent_signal [24894,24906]
name: agent_signal [25016,25028]
===
match
---
name: _file_stats [48812,48823]
name: _file_stats [48934,48945]
===
match
---
operator: = [39902,39903]
operator: = [40024,40025]
===
match
---
expr_stmt [46267,46470]
expr_stmt [46389,46592]
===
match
---
name: Tuple [3728,3733]
name: Tuple [3728,3733]
===
match
---
name: processor [41620,41629]
name: processor [41742,41751]
===
match
---
name: log [8810,8813]
name: log [8810,8813]
===
match
---
if_stmt [35067,35152]
if_stmt [35189,35274]
===
match
---
string: "There are %s files in %s" [30259,30285]
string: "There are %s files in %s" [30381,30407]
===
match
---
operator: , [48898,48899]
operator: , [49020,49021]
===
match
---
arglist [21979,22015]
arglist [22101,22137]
===
match
---
name: poll [13923,13927]
name: poll [14045,14049]
===
match
---
name: self [15643,15647]
name: self [15765,15769]
===
match
---
trailer [44305,44315]
trailer [44427,44437]
===
match
---
name: last_run [33417,33425]
name: last_run [33539,33547]
===
match
---
operator: , [39421,39422]
operator: , [39543,39544]
===
match
---
trailer [22588,22605]
trailer [22710,22727]
===
match
---
expr_stmt [8107,8161]
expr_stmt [8107,8161]
===
match
---
if_stmt [41033,41099]
if_stmt [41155,41221]
===
match
---
name: self [30476,30480]
name: self [30598,30602]
===
match
---
trailer [45852,45859]
trailer [45974,45981]
===
match
---
try_stmt [10786,11123]
try_stmt [10786,11123]
===
match
---
string: """         A list of simple dags found, and the number of import errors          :return: result of running SchedulerJob.process_file() if available. Otherwise, none         :rtype: Optional[Tuple[int, int]]         """ [3754,3974]
string: """         A list of simple dags found, and the number of import errors          :return: result of running SchedulerJob.process_file() if available. Otherwise, none         :rtype: Optional[Tuple[int, int]]         """ [3754,3974]
===
match
---
trailer [8508,8536]
trailer [8508,8536]
===
match
---
string: 'False' [12911,12918]
string: 'False' [13033,13040]
===
match
---
name: pid [2972,2975]
name: pid [2972,2975]
===
match
---
trailer [34203,34205]
trailer [34325,34327]
===
match
---
name: NotImplementedError [2907,2926]
name: NotImplementedError [2907,2926]
===
match
---
operator: , [8577,8578]
operator: , [8577,8578]
===
match
---
name: decr [39136,39140]
name: decr [39258,39262]
===
match
---
name: log [45630,45633]
name: log [45752,45755]
===
match
---
operator: = [28860,28861]
operator: = [28982,28983]
===
match
---
atom_expr [19532,19548]
atom_expr [19654,19670]
===
match
---
simple_stmt [15407,15612]
simple_stmt [15529,15734]
===
match
---
suite [24494,28938]
suite [24616,29060]
===
match
---
operator: , [8407,8408]
operator: , [8407,8408]
===
match
---
import_name [821,837]
import_name [821,837]
===
match
---
simple_stmt [25127,25146]
simple_stmt [25249,25268]
===
match
---
trailer [42501,42510]
trailer [42623,42632]
===
match
---
name: _print_stat [27600,27611]
name: _print_stat [27722,27733]
===
match
---
param [4065,4069]
param [4065,4069]
===
match
---
atom_expr [40246,40309]
atom_expr [40368,40431]
===
match
---
name: ValueError [9336,9346]
name: ValueError [9336,9346]
===
match
---
trailer [38527,38531]
trailer [38649,38653]
===
match
---
operator: @ [3112,3113]
operator: @ [3112,3113]
===
match
---
name: setpgid [12399,12406]
name: setpgid [12521,12528]
===
match
---
operator: , [45835,45836]
operator: , [45957,45958]
===
match
---
atom_expr [31718,31782]
atom_expr [31840,31904]
===
match
---
name: file_path [39111,39120]
name: file_path [39233,39242]
===
match
---
name: files_with_mtime [42464,42480]
name: files_with_mtime [42586,42602]
===
match
---
subscriptlist [3734,3742]
subscriptlist [3734,3742]
===
match
---
expr_stmt [5068,5101]
expr_stmt [5068,5101]
===
match
---
operator: = [8285,8286]
operator: = [8285,8286]
===
match
---
simple_stmt [32902,32948]
simple_stmt [33024,33070]
===
match
---
name: self [21371,21375]
name: self [21493,21497]
===
match
---
expr_stmt [21611,21640]
expr_stmt [21733,21762]
===
match
---
name: _exit_gracefully [22746,22762]
name: _exit_gracefully [22868,22884]
===
match
---
name: self [26901,26905]
name: self [27023,27027]
===
match
---
except_clause [11457,11472]
except_clause [11575,11590]
===
match
---
name: airflow [1530,1537]
name: airflow [1530,1537]
===
match
---
atom_expr [30291,30307]
atom_expr [30413,30429]
===
match
---
simple_stmt [14899,15114]
simple_stmt [15021,15236]
===
match
---
expr_stmt [22077,22156]
expr_stmt [22199,22278]
===
match
---
name: conf [42174,42178]
name: conf [42296,42300]
===
match
---
trailer [44464,44469]
trailer [44586,44591]
===
match
---
name: simple_task_instance [46362,46382]
name: simple_task_instance [46484,46504]
===
match
---
operator: , [22379,22380]
operator: , [22501,22502]
===
match
---
name: self [47806,47810]
name: self [47928,47932]
===
match
---
name: self [16258,16262]
name: self [16380,16384]
===
match
---
name: _file_path_queue [29528,29544]
name: _file_path_queue [29650,29666]
===
match
---
name: self [23890,23894]
name: self [24012,24016]
===
match
---
name: x [33917,33918]
name: x [34039,34040]
===
match
---
name: num_dags [34255,34263]
name: num_dags [34377,34385]
===
match
---
name: _file_path_queue [6973,6989]
name: _file_path_queue [6973,6989]
===
match
---
trailer [15558,15562]
trailer [15680,15684]
===
match
---
name: collect_results [27564,27579]
name: collect_results [27686,27701]
===
match
---
name: NamedTuple [1245,1255]
name: NamedTuple [1245,1255]
===
match
---
simple_stmt [23197,23216]
simple_stmt [23319,23338]
===
match
---
operator: == [25180,25182]
operator: == [25302,25304]
===
match
---
name: DagFileStat [4768,4779]
name: DagFileStat [4768,4779]
===
match
---
name: last_duration [39706,39719]
name: last_duration [39828,39841]
===
match
---
name: self [15298,15302]
name: self [15420,15424]
===
match
---
name: os [12857,12859]
name: os [12979,12981]
===
match
---
if_stmt [42725,42945]
if_stmt [42847,43067]
===
match
---
atom_expr [22114,22135]
atom_expr [22236,22257]
===
match
---
name: file_path [37042,37051]
name: file_path [37164,37173]
===
match
---
trailer [30746,30764]
trailer [30868,30886]
===
match
---
param [37853,37867]
param [37975,37989]
===
match
---
suite [8928,9716]
suite [8928,9716]
===
match
---
name: str [6620,6623]
name: str [6620,6623]
===
match
---
trailer [15140,15142]
trailer [15262,15264]
===
match
---
arith_expr [33280,33306]
arith_expr [33402,33428]
===
match
---
name: done [38944,38948]
name: done [39066,39070]
===
match
---
name: _file_path_queue [40911,40927]
name: _file_path_queue [41033,41049]
===
match
---
simple_stmt [35850,36097]
simple_stmt [35972,36219]
===
match
---
simple_stmt [39864,39909]
simple_stmt [39986,40031]
===
match
---
operator: = [46331,46332]
operator: = [46453,46454]
===
match
---
operator: = [32855,32856]
operator: = [32977,32978]
===
match
---
operator: - [33284,33285]
operator: - [33406,33407]
===
match
---
name: self [23115,23119]
name: self [23237,23241]
===
match
---
expr_stmt [27732,27774]
expr_stmt [27854,27896]
===
match
---
trailer [16456,16465]
trailer [16578,16587]
===
match
---
name: wait_until_finished [11132,11151]
name: wait_until_finished [11132,11151]
===
match
---
name: ValueError [13767,13777]
name: ValueError [13889,13899]
===
match
---
name: _log_file_processing_stats [31867,31893]
name: _log_file_processing_stats [31989,32015]
===
match
---
string: 'dag_processing.processes' [41410,41436]
string: 'dag_processing.processes' [41532,41558]
===
match
---
operator: , [31416,31417]
operator: , [31538,31539]
===
match
---
suite [28901,28938]
suite [29023,29060]
===
match
---
operator: { [34319,34320]
operator: { [34441,34442]
===
match
---
trailer [7018,7033]
trailer [7018,7033]
===
match
---
fstring_start: f' [33518,33520]
fstring_start: f' [33640,33642]
===
match
---
name: self [30092,30096]
name: self [30214,30218]
===
match
---
param [6805,6834]
param [6805,6834]
===
match
---
atom_expr [24102,24118]
atom_expr [24224,24240]
===
match
---
string: 'sqlite' [20127,20135]
string: 'sqlite' [20249,20257]
===
match
---
not_test [10004,10032]
not_test [10004,10032]
===
match
---
simple_stmt [35752,35796]
simple_stmt [35874,35918]
===
match
---
trailer [29804,29806]
trailer [29926,29928]
===
match
---
try_stmt [30394,30695]
try_stmt [30516,30817]
===
match
---
param [8914,8918]
param [8914,8918]
===
match
---
trailer [6946,6948]
trailer [6946,6948]
===
match
---
atom_expr [26413,26441]
atom_expr [26535,26563]
===
match
---
string: "Detected zombie job: %s" [46501,46526]
string: "Detected zombie job: %s" [46623,46648]
===
match
---
arglist [39375,39463]
arglist [39497,39585]
===
match
---
name: airflow [1862,1869]
name: airflow [1862,1869]
===
match
---
atom_expr [2907,2928]
atom_expr [2907,2928]
===
match
---
atom_expr [21334,21356]
atom_expr [21456,21478]
===
match
---
atom [29844,29882]
atom [29966,30004]
===
match
---
name: Optional [19080,19088]
name: Optional [19202,19210]
===
match
---
string: "Current Stacktrace is: %s" [23015,23042]
string: "Current Stacktrace is: %s" [23137,23164]
===
match
---
trailer [44611,44623]
trailer [44733,44745]
===
match
---
simple_stmt [7783,7845]
simple_stmt [7783,7845]
===
match
---
suite [46856,47480]
suite [46978,47602]
===
match
---
name: append [33708,33714]
name: append [33830,33836]
===
match
---
expr_stmt [19244,19281]
expr_stmt [19366,19403]
===
match
---
trailer [42933,42944]
trailer [43055,43066]
===
match
---
operator: , [11873,11874]
operator: , [11995,11996]
===
match
---
name: file_paths [27708,27718]
name: file_paths [27830,27840]
===
match
---
atom_expr [25316,25357]
atom_expr [25438,25479]
===
match
---
name: timezone [46192,46200]
name: timezone [46314,46322]
===
match
---
name: _file_paths [31280,31291]
name: _file_paths [31402,31413]
===
match
---
atom [43533,43650]
atom [43655,43772]
===
match
---
name: self [19203,19207]
name: self [19325,19329]
===
match
---
funcdef [9721,10347]
funcdef [9721,10347]
===
match
---
name: import_module [1091,1104]
name: import_module [1091,1104]
===
match
---
name: str [22109,22112]
name: str [22231,22234]
===
match
---
simple_stmt [31710,31783]
simple_stmt [31832,31905]
===
match
---
operator: = [42369,42370]
operator: = [42491,42492]
===
match
---
trailer [33918,33921]
trailer [34040,34043]
===
match
---
trailer [7842,7844]
trailer [7842,7844]
===
match
---
atom_expr [20050,20067]
atom_expr [20172,20189]
===
match
---
operator: = [11363,11364]
operator: = [11481,11482]
===
match
---
not_test [16830,16847]
not_test [16952,16969]
===
match
---
suite [14267,14545]
suite [14389,14667]
===
match
---
while_stmt [13892,14129]
while_stmt [14014,14251]
===
match
---
operator: } [22389,22390]
operator: } [22511,22512]
===
match
---
name: import_errors [36564,36577]
name: import_errors [36686,36699]
===
match
---
name: file_paths [49035,49045]
name: file_paths [49157,49167]
===
match
---
string: """Occasionally print out stats about how fast the files are getting processed""" [31023,31104]
string: """Occasionally print out stats about how fast the files are getting processed""" [31145,31226]
===
match
---
simple_stmt [20742,20819]
simple_stmt [20864,20941]
===
match
---
name: run_single_parsing_loop [8890,8913]
name: run_single_parsing_loop [8890,8913]
===
match
---
name: self [44193,44197]
name: self [44315,44319]
===
match
---
name: self [24232,24236]
name: self [24354,24358]
===
match
---
expr_stmt [35705,35743]
expr_stmt [35827,35865]
===
match
---
param [9750,9755]
param [9750,9755]
===
match
---
param [11855,11874]
param [11977,11996]
===
match
---
atom_expr [38689,38720]
atom_expr [38811,38842]
===
match
---
name: stat [43572,43576]
name: stat [43694,43698]
===
match
---
name: processor [39226,39235]
name: processor [39348,39357]
===
match
---
atom_expr [22166,22175]
atom_expr [22288,22297]
===
match
---
name: _file_path_queue [44786,44802]
name: _file_path_queue [44908,44924]
===
match
---
operator: = [46878,46879]
operator: = [47000,47001]
===
match
---
name: key [43071,43074]
name: key [43193,43196]
===
match
---
name: self [7201,7205]
name: self [7201,7205]
===
match
---
argument [46427,46451]
argument [46549,46573]
===
match
---
name: file_path [40894,40903]
name: file_path [41016,41025]
===
match
---
trailer [41837,41857]
trailer [41959,41979]
===
match
---
name: rows [32745,32749]
name: rows [32867,32871]
===
match
---
decorated [2434,2568]
decorated [2434,2568]
===
match
---
trailer [39761,39775]
trailer [39883,39897]
===
match
---
trailer [41877,41879]
trailer [41999,42001]
===
match
---
expr_stmt [7273,7302]
expr_stmt [7273,7302]
===
match
---
name: self [45584,45588]
name: self [45706,45710]
===
match
---
name: full_filepath [29645,29658]
name: full_filepath [29767,29780]
===
match
---
atom_expr [31148,31164]
atom_expr [31270,31286]
===
match
---
name: str [21339,21342]
name: str [21461,21464]
===
match
---
atom_expr [26782,26803]
atom_expr [26904,26925]
===
match
---
simple_stmt [2351,2429]
simple_stmt [2351,2429]
===
match
---
name: pop [40337,40340]
name: pop [40459,40462]
===
match
---
operator: = [41684,41685]
operator: = [41806,41807]
===
match
---
atom_expr [45368,45434]
atom_expr [45490,45556]
===
match
---
import_from [30881,30923]
import_from [31003,31045]
===
match
---
funcdef [14231,14545]
funcdef [14353,14667]
===
match
---
operator: = [7689,7690]
operator: = [7689,7690]
===
match
---
expr_stmt [32763,32786]
expr_stmt [32885,32908]
===
match
---
suite [19167,22391]
suite [19289,22513]
===
match
---
trailer [23965,23967]
trailer [24087,24089]
===
match
---
atom_expr [38149,38170]
atom_expr [38271,38292]
===
match
---
arglist [46318,46452]
arglist [46440,46574]
===
match
---
atom_expr [16481,16537]
atom_expr [16603,16659]
===
match
---
name: _parsing_start_time [48655,48674]
name: _parsing_start_time [48777,48796]
===
match
---
name: self [19244,19248]
name: self [19366,19370]
===
match
---
dotted_name [1761,1792]
dotted_name [1761,1792]
===
match
---
trailer [23123,23125]
trailer [23245,23247]
===
match
---
operator: , [34643,34644]
operator: , [34765,34766]
===
match
---
name: new_file_paths [37853,37867]
name: new_file_paths [37975,37989]
===
match
---
comparison [28811,28828]
comparison [28933,28950]
===
match
---
operator: , [34365,34366]
operator: , [34487,34488]
===
match
---
name: property [15977,15985]
name: property [16099,16107]
===
match
---
operator: , [6752,6753]
operator: , [6752,6753]
===
match
---
simple_stmt [42464,42522]
simple_stmt [42586,42644]
===
match
---
trailer [29059,29066]
trailer [29181,29188]
===
match
---
simple_stmt [39177,39214]
simple_stmt [39299,39336]
===
match
---
comparison [40166,40195]
comparison [40288,40317]
===
match
---
string: """         Send termination signal to DAG parsing processor manager         and expect it to terminate all DAG file processors.         """ [16273,16413]
string: """         Send termination signal to DAG parsing processor manager         and expect it to terminate all DAG file processors.         """ [16395,16535]
===
match
---
name: dag_dir_list_interval [23895,23916]
name: dag_dir_list_interval [24017,24038]
===
match
---
expr_stmt [39177,39213]
expr_stmt [39299,39335]
===
match
---
arglist [23820,23916]
arglist [23942,24038]
===
match
---
name: ready [40023,40028]
name: ready [40145,40150]
===
match
---
trailer [8813,8818]
trailer [8813,8818]
===
match
---
expr_stmt [32644,32735]
expr_stmt [32766,32857]
===
match
---
name: info [46496,46500]
name: info [46618,46622]
===
match
---
atom_expr [11326,11369]
atom_expr [11444,11487]
===
match
---
simple_stmt [19244,19282]
simple_stmt [19366,19404]
===
match
---
name: MultiprocessingConnection [22266,22291]
name: MultiprocessingConnection [22388,22413]
===
match
---
name: items [38377,38382]
name: items [38499,38504]
===
match
---
name: query [45743,45748]
name: query [45865,45870]
===
match
---
fstring_end: " [34338,34339]
fstring_end: " [34460,34461]
===
match
---
name: done [15842,15846]
name: done [15964,15968]
===
match
---
operator: , [6745,6746]
operator: , [6745,6746]
===
match
---
atom_expr [7014,7033]
atom_expr [7014,7033]
===
match
---
if_stmt [2250,2287]
if_stmt [2250,2287]
===
match
---
name: done [15994,15998]
name: done [16116,16120]
===
match
---
trailer [34395,34404]
trailer [34517,34526]
===
match
---
name: LJ [46037,46039]
name: LJ [46159,46161]
===
match
---
trailer [31684,31696]
trailer [31806,31818]
===
match
---
decorated [3665,4011]
decorated [3665,4011]
===
match
---
simple_stmt [46553,46590]
simple_stmt [46675,46712]
===
match
---
operator: - [33462,33463]
operator: - [33584,33585]
===
match
---
operator: , [22521,22522]
operator: , [22643,22644]
===
match
---
trailer [28771,28773]
trailer [28893,28895]
===
match
---
expr_stmt [12857,12918]
expr_stmt [12979,13040]
===
match
---
name: conf [20947,20951]
name: conf [21069,21073]
===
match
---
trailer [19992,20005]
trailer [20114,20127]
===
match
---
operator: = [39536,39537]
operator: = [39658,39659]
===
match
---
name: len [40829,40832]
name: len [40951,40954]
===
match
---
name: self [30415,30419]
name: self [30537,30541]
===
match
---
simple_stmt [16022,16063]
simple_stmt [16144,16185]
===
match
---
simple_stmt [2272,2287]
simple_stmt [2272,2287]
===
match
---
trailer [10892,10912]
trailer [10892,10912]
===
match
---
trailer [27652,27719]
trailer [27774,27841]
===
match
---
parameters [14572,14578]
parameters [14694,14700]
===
match
---
trailer [39357,39477]
trailer [39479,39599]
===
match
---
parameters [6581,6931]
parameters [6581,6931]
===
match
---
decorator [15976,15986]
decorator [16098,16108]
===
match
---
if_stmt [30841,30987]
if_stmt [30963,31109]
===
match
---
import_as_name [1144,1183]
import_as_name [1144,1183]
===
match
---
term [34695,34703]
term [34817,34825]
===
match
---
name: _done [16083,16088]
name: _done [16205,16210]
===
match
---
name: log [44198,44201]
name: log [44320,44323]
===
match
---
name: request [29561,29568]
name: request [29683,29690]
===
match
---
trailer [14120,14128]
trailer [14242,14250]
===
match
---
trailer [16447,16456]
trailer [16569,16578]
===
match
---
name: num_dags [4856,4864]
name: num_dags [4856,4864]
===
match
---
trailer [14367,14392]
trailer [14489,14514]
===
match
---
name: log [28536,28539]
name: log [28658,28661]
===
match
---
trailer [41864,41877]
trailer [41986,41999]
===
match
---
raise_stmt [13761,13801]
raise_stmt [13883,13923]
===
match
---
operator: -> [11158,11160]
operator: -> [11158,11160]
===
match
---
parameters [35406,35423]
parameters [35528,35545]
===
match
---
trailer [6972,6989]
trailer [6972,6989]
===
match
---
name: ABCMeta [968,975]
name: ABCMeta [968,975]
===
match
---
param [16132,16136]
param [16254,16258]
===
match
---
operator: = [19349,19350]
operator: = [19471,19472]
===
match
---
name: end [23120,23123]
name: end [23242,23245]
===
match
---
atom_expr [17113,17144]
atom_expr [17235,17266]
===
match
---
name: _signal_conn [19425,19437]
name: _signal_conn [19547,19559]
===
match
---
operator: , [23662,23663]
operator: , [23784,23785]
===
match
---
arglist [13100,13106]
arglist [13222,13228]
===
match
---
operator: * [34699,34700]
operator: * [34821,34822]
===
match
---
name: self [47902,47906]
name: self [48024,48028]
===
match
---
expr_stmt [31710,31782]
expr_stmt [31832,31904]
===
match
---
name: self [35824,35828]
name: self [35946,35950]
===
match
---
expr_stmt [36918,36956]
expr_stmt [37040,37078]
===
match
---
name: limit_dttm [45682,45692]
name: limit_dttm [45804,45814]
===
match
---
name: agent_signal [24861,24873]
name: agent_signal [24983,24995]
===
match
---
trailer [33113,33116]
trailer [33235,33238]
===
match
---
if_stmt [26285,26332]
if_stmt [26407,26454]
===
match
---
atom_expr [41552,41565]
atom_expr [41674,41687]
===
match
---
name: state [45989,45994]
name: state [46111,46116]
===
match
---
atom_expr [48056,48094]
atom_expr [48178,48216]
===
match
---
string: """         Print out stats about how files are getting processed.          :param known_file_paths: a list of file paths that may contain Airflow             DAG definitions         :type known_file_paths: list[unicode]         :return: None         """ [31927,32181]
string: """         Print out stats about how files are getting processed.          :param known_file_paths: a list of file paths that may contain Airflow             DAG definitions         :type known_file_paths: list[unicode]         :return: None         """ [32049,32303]
===
match
---
name: wait [24634,24638]
name: wait [24756,24760]
===
match
---
if_stmt [37363,37455]
if_stmt [37485,37577]
===
match
---
parameters [44875,44890]
parameters [44997,45012]
===
match
---
suite [11370,11796]
suite [11488,11918]
===
match
---
arglist [22508,22544]
arglist [22630,22666]
===
match
---
name: metaclass [2327,2336]
name: metaclass [2327,2336]
===
match
---
trailer [9461,9481]
trailer [9461,9481]
===
match
---
name: _zombie_query_interval [21690,21712]
name: _zombie_query_interval [21812,21834]
===
match
---
trailer [27755,27772]
trailer [27877,27894]
===
match
---
operator: , [3737,3738]
operator: , [3737,3738]
===
match
---
name: start [8788,8793]
name: start [8788,8793]
===
match
---
simple_stmt [28399,28481]
simple_stmt [28521,28603]
===
match
---
string: "Processor for %s finished" [39072,39099]
string: "Processor for %s finished" [39194,39221]
===
match
---
atom_expr [19960,19976]
atom_expr [20082,20098]
===
match
---
atom_expr [46777,46794]
atom_expr [46899,46916]
===
match
---
trailer [31162,31164]
trailer [31284,31286]
===
match
---
trailer [31738,31750]
trailer [31860,31872]
===
match
---
name: file_path [33180,33189]
name: file_path [33302,33311]
===
match
---
name: log [1926,1929]
name: log [1926,1929]
===
match
---
operator: { [34181,34182]
operator: { [34303,34304]
===
match
---
name: abstractmethod [2574,2588]
name: abstractmethod [2574,2588]
===
match
---
name: keys [24654,24658]
name: keys [24776,24780]
===
match
---
simple_stmt [29815,29899]
simple_stmt [29937,30021]
===
match
---
atom_expr [26857,26887]
atom_expr [26979,27009]
===
match
---
atom_expr [32769,32786]
atom_expr [32891,32908]
===
match
---
operator: , [22112,22113]
operator: , [22234,22235]
===
match
---
return_stmt [36152,36190]
return_stmt [36274,36312]
===
match
---
name: process [8240,8247]
name: process [8240,8247]
===
match
---
name: basename [33042,33050]
name: basename [33164,33172]
===
match
---
name: int [3178,3181]
name: int [3178,3181]
===
match
---
trailer [7511,7519]
trailer [7511,7519]
===
match
---
name: self [17172,17176]
name: self [17294,17298]
===
match
---
name: List [12110,12114]
name: List [12232,12236]
===
match
---
string: "Processor for %s with PID %s started at %s has timed out, killing it." [47010,47081]
string: "Processor for %s with PID %s started at %s has timed out, killing it." [47132,47203]
===
match
---
name: isinstance [11553,11563]
name: isinstance [11672,11682]
===
match
---
param [9756,9780]
param [9756,9780]
===
match
---
trailer [7787,7818]
trailer [7787,7818]
===
match
---
name: processor_factory [19394,19411]
name: processor_factory [19516,19533]
===
match
---
parameters [22762,22783]
parameters [22884,22905]
===
match
---
comparison [25167,25214]
comparison [25289,25336]
===
match
---
arglist [45749,45763]
arglist [45871,45885]
===
match
---
param [15734,15738]
param [15856,15860]
===
match
---
atom_expr [20180,20197]
atom_expr [20302,20319]
===
match
---
trailer [43596,43602]
trailer [43718,43724]
===
match
---
name: self [16481,16485]
name: self [16603,16607]
===
match
---
operator: < [46057,46058]
operator: < [46179,46180]
===
match
---
name: Dict [22104,22108]
name: Dict [22226,22230]
===
match
---
operator: = [24669,24670]
operator: = [24791,24792]
===
match
---
operator: , [24660,24661]
operator: , [24782,24783]
===
match
---
trailer [9408,9410]
trailer [9408,9410]
===
match
---
name: SlaCallbackRequest [1817,1835]
name: SlaCallbackRequest [1817,1835]
===
match
---
atom_expr [41860,41879]
atom_expr [41982,42001]
===
match
---
arglist [46501,46535]
arglist [46623,46657]
===
match
---
for_stmt [48000,48129]
for_stmt [48122,48251]
===
match
---
atom_expr [43178,43196]
atom_expr [43300,43318]
===
match
---
decorated [49017,49085]
decorated [49139,49207]
===
match
---
trailer [5017,5022]
trailer [5017,5022]
===
match
---
suite [36643,37012]
suite [36765,37134]
===
match
---
expr_stmt [29815,29898]
expr_stmt [29937,30020]
===
match
---
string: 'CONFIG_PROCESSOR_MANAGER_LOGGER' [12805,12838]
string: 'CONFIG_PROCESSOR_MANAGER_LOGGER' [12927,12960]
===
match
---
string: """         Sends information about the callback to be executed by DagFileProcessor.          :param request: Callback request to be executed.         :type request: CallbackRequest         """ [9799,9992]
string: """         Sends information about the callback to be executed by DagFileProcessor.          :param request: Callback request to be executed.         :type request: CallbackRequest         """ [9799,9992]
===
match
---
name: RuntimeError [14467,14479]
name: RuntimeError [14589,14601]
===
match
---
atom_expr [47750,47764]
atom_expr [47872,47886]
===
match
---
arith_expr [39801,39844]
arith_expr [39923,39966]
===
match
---
expr_stmt [38107,38140]
expr_stmt [38229,38262]
===
match
---
fstring_string: s [34337,34338]
fstring_string: s [34459,34460]
===
match
---
atom_expr [11413,11444]
atom_expr [11531,11562]
===
match
---
parameters [38796,38802]
parameters [38918,38924]
===
match
---
simple_stmt [24232,24263]
simple_stmt [24354,24385]
===
match
---
trailer [19574,19594]
trailer [19696,19716]
===
match
---
string: "# Errors" [32696,32706]
string: "# Errors" [32818,32828]
===
match
---
name: total_seconds [15322,15335]
name: total_seconds [15444,15457]
===
match
---
atom_expr [6968,6989]
atom_expr [6968,6989]
===
match
---
not_test [25551,25571]
not_test [25673,25693]
===
match
---
if_stmt [31677,31783]
if_stmt [31799,31905]
===
match
---
trailer [42701,42712]
trailer [42823,42834]
===
match
---
name: Stats [48843,48848]
name: Stats [48965,48970]
===
match
---
name: max_runs_reached [27756,27772]
name: max_runs_reached [27878,27894]
===
match
---
expr_stmt [19500,19523]
expr_stmt [19622,19645]
===
match
---
name: self [18797,18801]
name: self [18919,18923]
===
match
---
name: file_path [32879,32888]
name: file_path [33001,33010]
===
match
---
name: now [46880,46883]
name: now [47002,47005]
===
match
---
atom_expr [18826,18852]
atom_expr [18948,18974]
===
match
---
operator: , [8375,8376]
operator: , [8375,8376]
===
match
---
trailer [13146,13153]
trailer [13268,13275]
===
match
---
trailer [23104,23106]
trailer [23226,23228]
===
match
---
trailer [45827,45832]
trailer [45949,45954]
===
match
---
name: pop [26428,26431]
name: pop [26550,26553]
===
match
---
name: file_path [36133,36142]
name: file_path [36255,36264]
===
match
---
name: _parent_signal_conn [7710,7729]
name: _parent_signal_conn [7710,7729]
===
match
---
name: end [16703,16706]
name: end [16825,16828]
===
match
---
parameters [3159,3165]
parameters [3159,3165]
===
match
---
simple_stmt [42897,42945]
simple_stmt [43019,43067]
===
match
---
name: poll_time [24670,24679]
name: poll_time [24792,24801]
===
match
---
name: last_finish_time [44699,44715]
name: last_finish_time [44821,44837]
===
match
---
string: 'scheduler' [20782,20793]
string: 'scheduler' [20904,20915]
===
match
---
trailer [29015,29036]
trailer [29137,29158]
===
match
---
tfpdef [12044,12082]
tfpdef [12166,12204]
===
match
---
operator: , [39692,39693]
operator: , [39814,39815]
===
match
---
name: self [3710,3714]
name: self [3710,3714]
===
match
---
operator: , [25339,25340]
operator: , [25461,25462]
===
match
---
trailer [9503,9518]
trailer [9503,9518]
===
match
---
name: self [24102,24106]
name: self [24224,24228]
===
match
---
dotted_name [1427,1441]
dotted_name [1427,1441]
===
match
---
trailer [30423,30429]
trailer [30545,30551]
===
match
---
name: NotImplementedError [2732,2751]
name: NotImplementedError [2732,2751]
===
match
---
trailer [25559,25571]
trailer [25681,25693]
===
match
---
atom_expr [8554,8577]
atom_expr [8554,8577]
===
match
---
number: 1 [13105,13106]
number: 1 [13227,13228]
===
match
---
trailer [45186,45200]
trailer [45308,45322]
===
match
---
import_name [901,914]
import_name [901,914]
===
match
---
import_from [1586,1644]
import_from [1586,1644]
===
match
---
name: _processors [38365,38376]
name: _processors [38487,38498]
===
match
---
simple_stmt [13137,13172]
simple_stmt [13259,13294]
===
match
---
trailer [36128,36132]
trailer [36250,36254]
===
match
---
decorator [4442,4452]
decorator [4442,4452]
===
match
---
name: utils [1769,1774]
name: utils [1769,1774]
===
match
---
name: List [1239,1243]
name: List [1239,1243]
===
match
---
name: AGENT_RUN_ONCE [25200,25214]
name: AGENT_RUN_ONCE [25322,25336]
===
match
---
name: kill_child_processes_by_pids [2112,2140]
name: kill_child_processes_by_pids [2112,2140]
===
match
---
operator: , [8727,8728]
operator: , [8727,8728]
===
match
---
trailer [23057,23079]
trailer [23179,23201]
===
match
---
if_stmt [14354,14545]
if_stmt [14476,14667]
===
match
---
operator: - [46884,46885]
operator: - [47006,47007]
===
match
---
atom_expr [12396,12412]
atom_expr [12518,12534]
===
match
---
atom_expr [48935,48960]
atom_expr [49057,49082]
===
match
---
name: sorted [43178,43184]
name: sorted [43300,43306]
===
match
---
name: self [30969,30973]
name: self [31091,31095]
===
match
---
comp_if [43605,43640]
comp_if [43727,43762]
===
match
---
name: max_runs [11883,11891]
name: max_runs [12005,12013]
===
match
---
name: __init__ [19184,19192]
name: __init__ [19306,19314]
===
match
---
simple_stmt [39957,40015]
simple_stmt [40079,40137]
===
match
---
while_stmt [24483,28938]
while_stmt [24605,29060]
===
match
---
param [18862,18876]
param [18984,18998]
===
match
---
atom_expr [26458,26499]
atom_expr [26580,26621]
===
match
---
name: importlib [13137,13146]
name: importlib [13259,13268]
===
match
---
atom_expr [18904,18975]
atom_expr [19026,19097]
===
match
---
name: timing [33629,33635]
name: timing [33751,33757]
===
match
---
name: _file_stats [37751,37762]
name: _file_stats [37873,37884]
===
match
---
suite [10440,11123]
suite [10440,11123]
===
match
---
atom_expr [42464,42491]
atom_expr [42586,42613]
===
match
---
decorators [4016,4046]
decorators [4016,4046]
===
match
---
name: self [20446,20450]
name: self [20568,20572]
===
match
---
simple_stmt [21236,21254]
simple_stmt [21358,21376]
===
match
---
arith_expr [29845,29881]
arith_expr [29967,30003]
===
match
---
name: abstractmethod [4031,4045]
name: abstractmethod [4031,4045]
===
match
---
simple_stmt [940,952]
simple_stmt [940,952]
===
match
---
string: 'True' [12842,12848]
string: 'True' [12964,12970]
===
match
---
name: dag_dir_list_interval [21943,21964]
name: dag_dir_list_interval [22065,22086]
===
match
---
if_stmt [28494,28691]
if_stmt [28616,28813]
===
match
---
trailer [45748,45764]
trailer [45870,45886]
===
match
---
parameters [48141,48147]
parameters [48263,48269]
===
match
---
simple_stmt [26323,26332]
simple_stmt [26445,26454]
===
match
---
name: property [3397,3405]
name: property [3397,3405]
===
match
---
name: conf [20070,20074]
name: conf [20192,20196]
===
match
---
trailer [8159,8161]
trailer [8159,8161]
===
match
---
operator: , [33759,33760]
operator: , [33881,33882]
===
match
---
name: self [31305,31309]
name: self [31427,31431]
===
match
---
trailer [16865,16869]
trailer [16987,16991]
===
match
---
trailer [17126,17131]
trailer [17248,17253]
===
match
---
operator: = [44678,44679]
operator: = [44800,44801]
===
match
---
annassign [7818,7844]
annassign [7818,7844]
===
match
---
trailer [40604,40610]
trailer [40726,40732]
===
match
---
trailer [42045,42057]
trailer [42167,42179]
===
match
---
param [41729,41733]
param [41851,41855]
===
match
---
trailer [11287,11311]
trailer [11287,11311]
===
match
---
name: airflow [45452,45459]
name: airflow [45574,45581]
===
match
---
atom_expr [21611,21636]
atom_expr [21733,21758]
===
match
---
decorator [2948,2964]
decorator [2948,2964]
===
match
---
simple_stmt [28922,28938]
simple_stmt [29044,29060]
===
match
---
string: "Removing old import errors" [30430,30458]
string: "Removing old import errors" [30552,30580]
===
match
---
name: file_path [41376,41385]
name: file_path [41498,41507]
===
match
---
name: _signal_conn [20011,20023]
name: _signal_conn [20133,20145]
===
match
---
fstring_string: dag_processing.last_run.seconds_ago. [33520,33556]
fstring_string: dag_processing.last_run.seconds_ago. [33642,33678]
===
match
---
name: agent_signal [25504,25516]
name: agent_signal [25626,25638]
===
match
---
string: "Last Runtime" [32708,32722]
string: "Last Runtime" [32830,32844]
===
match
---
atom [44014,44117]
atom [44136,44239]
===
match
---
tfpdef [6843,6871]
tfpdef [6843,6871]
===
match
---
name: _processors [38890,38901]
name: _processors [39012,39023]
===
match
---
atom_expr [22721,22735]
atom_expr [22843,22857]
===
match
---
name: info [45377,45381]
name: info [45499,45503]
===
match
---
name: now [29845,29848]
name: now [29967,29970]
===
match
---
atom_expr [42079,42096]
atom_expr [42201,42218]
===
match
---
trailer [8558,8577]
trailer [8558,8577]
===
match
---
name: signal_conn [19440,19451]
name: signal_conn [19562,19573]
===
match
---
trailer [42062,42064]
trailer [42184,42186]
===
match
---
name: str [7380,7383]
name: str [7380,7383]
===
match
---
atom_expr [22139,22156]
atom_expr [22261,22278]
===
match
---
simple_stmt [48750,48835]
simple_stmt [48872,48957]
===
match
---
name: last_finish_time [42802,42818]
name: last_finish_time [42924,42940]
===
match
---
operator: , [20793,20794]
operator: , [20915,20916]
===
match
---
atom_expr [46161,46189]
atom_expr [46283,46311]
===
match
---
trailer [13056,13111]
trailer [13178,13233]
===
match
---
name: self [31243,31247]
name: self [31365,31369]
===
match
---
name: _dag_directory [19295,19309]
name: _dag_directory [19417,19431]
===
match
---
argument [43071,43095]
argument [43193,43217]
===
match
---
atom_expr [39881,39900]
atom_expr [40003,40022]
===
match
---
expr_stmt [7357,7422]
expr_stmt [7357,7422]
===
match
---
name: NotImplementedError [3989,4008]
name: NotImplementedError [3989,4008]
===
match
---
trailer [4008,4010]
trailer [4008,4010]
===
match
---
trailer [48066,48094]
trailer [48188,48216]
===
match
---
name: list_mode [43210,43219]
name: list_mode [43332,43341]
===
match
---
name: file_name [33074,33083]
name: file_name [33196,33205]
===
match
---
name: utcnow [39205,39211]
name: utcnow [39327,39333]
===
match
---
operator: , [13525,13526]
operator: , [13647,13648]
===
match
---
trailer [23894,23916]
trailer [24016,24038]
===
match
---
name: _collect_results_from_processor [40439,40470]
name: _collect_results_from_processor [40561,40592]
===
match
---
name: context [8217,8224]
name: context [8217,8224]
===
match
---
name: EX_OK [23209,23214]
name: EX_OK [23331,23336]
===
match
---
operator: = [46275,46276]
operator: = [46397,46398]
===
match
---
arglist [20959,21005]
arglist [21081,21127]
===
match
---
suite [43152,43197]
suite [43274,43319]
===
match
---
trailer [45793,45800]
trailer [45915,45922]
===
match
---
name: processor [46818,46827]
name: processor [46940,46949]
===
match
---
decorators [4442,4472]
decorators [4442,4472]
===
match
---
expr_stmt [4856,4869]
expr_stmt [4856,4869]
===
match
---
string: """         :return: a list of the PIDs for the processors that are running         :rtype: List[int]         """ [35209,35322]
string: """         :return: a list of the PIDs for the processors that are running         :rtype: List[int]         """ [35331,35444]
===
match
---
simple_stmt [47871,47883]
simple_stmt [47993,48005]
===
match
---
comparison [31116,31192]
comparison [31238,31314]
===
match
---
parameters [16706,16712]
parameters [16828,16834]
===
match
---
try_stmt [27788,28481]
try_stmt [27910,28603]
===
match
---
atom_expr [29454,29475]
atom_expr [29576,29597]
===
match
---
atom_expr [16078,16088]
atom_expr [16200,16210]
===
match
---
expr_stmt [21685,21717]
expr_stmt [21807,21839]
===
match
---
name: log [24802,24805]
name: log [24924,24927]
===
match
---
trailer [48761,48834]
trailer [48883,48956]
===
match
---
trailer [29036,29059]
trailer [29158,29181]
===
match
---
name: full_filepath [10832,10845]
name: full_filepath [10832,10845]
===
match
---
simple_stmt [7883,7969]
simple_stmt [7883,7969]
===
match
---
name: processor [38651,38660]
name: processor [38773,38782]
===
match
---
name: request [10803,10810]
name: request [10803,10810]
===
match
---
name: num_dags [48786,48794]
name: num_dags [48908,48916]
===
match
---
tfpdef [19023,19061]
tfpdef [19145,19183]
===
match
---
expr_stmt [19290,19325]
expr_stmt [19412,19447]
===
match
---
simple_stmt [33151,33191]
simple_stmt [33273,33313]
===
match
---
name: pids_to_kill [48277,48289]
name: pids_to_kill [48399,48411]
===
match
---
simple_stmt [45492,45521]
simple_stmt [45614,45643]
===
match
---
simple_stmt [42657,42713]
simple_stmt [42779,42835]
===
match
---
trailer [41065,41070]
trailer [41187,41192]
===
match
---
name: sentinel [40166,40174]
name: sentinel [40288,40296]
===
match
---
trailer [30367,30379]
trailer [30489,30501]
===
match
---
simple_stmt [5150,5178]
simple_stmt [5150,5178]
===
match
---
annassign [7373,7422]
annassign [7373,7422]
===
match
---
string: "Because we cannot use more than 1 thread (parsing_processes = " [20249,20313]
string: "Because we cannot use more than 1 thread (parsing_processes = " [20371,20435]
===
match
---
simple_stmt [25379,25421]
simple_stmt [25501,25543]
===
match
---
operator: , [10859,10860]
operator: , [10859,10860]
===
match
---
expr_stmt [19334,19359]
expr_stmt [19456,19481]
===
match
---
atom_expr [29789,29806]
atom_expr [29911,29928]
===
match
---
atom_expr [31635,31668]
atom_expr [31757,31790]
===
match
---
name: keys [42058,42062]
name: keys [42180,42184]
===
match
---
operator: , [39276,39277]
operator: , [39398,39399]
===
match
---
operator: - [28864,28865]
operator: - [28986,28987]
===
match
---
string: 'scheduler' [20959,20970]
string: 'scheduler' [21081,21092]
===
match
---
atom [42795,42819]
atom [42917,42941]
===
match
---
trailer [39110,39120]
trailer [39232,39242]
===
match
---
simple_stmt [32842,32890]
simple_stmt [32964,33012]
===
match
---
trailer [13196,13207]
trailer [13318,13329]
===
match
---
operator: , [23580,23581]
operator: , [23702,23703]
===
match
---
simple_stmt [36247,36497]
simple_stmt [36369,36619]
===
match
---
string: "Error removing old import errors" [30659,30693]
string: "Error removing old import errors" [30781,30815]
===
match
---
name: self [29686,29690]
name: self [29808,29812]
===
match
---
subscriptlist [6697,6785]
subscriptlist [6697,6785]
===
match
---
trailer [13224,13232]
trailer [13346,13354]
===
match
---
name: decr [48062,48066]
name: decr [48184,48188]
===
match
---
trailer [20074,20081]
trailer [20196,20203]
===
match
---
argument [44670,44680]
argument [44792,44802]
===
match
---
trailer [46895,46906]
trailer [47017,47028]
===
match
---
name: type [8286,8290]
name: type [8286,8290]
===
match
---
name: self [40596,40600]
name: self [40718,40722]
===
match
---
name: file_path [36946,36955]
name: file_path [37068,37077]
===
match
---
name: NotImplementedError [3638,3657]
name: NotImplementedError [3638,3657]
===
match
---
simple_stmt [3754,3975]
simple_stmt [3754,3975]
===
match
---
trailer [26167,26180]
trailer [26289,26302]
===
match
---
string: """Start more processors if we have enough slots and files to process""" [40722,40794]
string: """Start more processors if we have enough slots and files to process""" [40844,40916]
===
match
---
name: file_path [32937,32946]
name: file_path [33059,33068]
===
match
---
trailer [31855,31857]
trailer [31977,31979]
===
match
---
atom_expr [38523,38579]
atom_expr [38645,38701]
===
match
---
atom_expr [48904,48922]
atom_expr [49026,49044]
===
match
---
name: callback_requests [1775,1792]
name: callback_requests [1775,1792]
===
match
---
trailer [16217,16238]
trailer [16339,16360]
===
match
---
suite [5024,5178]
suite [5024,5178]
===
match
---
parameters [46670,46676]
parameters [46792,46798]
===
match
---
name: multiprocessing [8054,8069]
name: multiprocessing [8054,8069]
===
match
---
name: self [39057,39061]
name: self [39179,39183]
===
match
---
operator: , [14375,14376]
operator: , [14497,14498]
===
match
---
string: """Kill the process launched to process the file, and ensure consistent state.""" [2811,2892]
string: """Kill the process launched to process the file, and ensure consistent state.""" [2811,2892]
===
match
---
name: str [4286,4289]
name: str [4286,4289]
===
match
---
atom_expr [7472,7485]
atom_expr [7472,7485]
===
match
---
string: """All signals sent to parser.""" [5029,5062]
string: """All signals sent to parser.""" [5029,5062]
===
match
---
operator: , [38567,38568]
operator: , [38689,38690]
===
match
---
arglist [24812,24873]
arglist [24934,24995]
===
match
---
simple_stmt [32763,32787]
simple_stmt [32885,32909]
===
match
---
trailer [19248,19265]
trailer [19370,19387]
===
match
---
name: file_path [38336,38345]
name: file_path [38458,38467]
===
match
---
atom_expr [20576,20629]
atom_expr [20698,20751]
===
match
---
name: get_last_finish_time [27658,27678]
name: get_last_finish_time [27780,27800]
===
match
---
atom_expr [43046,43110]
atom_expr [43168,43232]
===
match
---
trailer [40046,40057]
trailer [40168,40179]
===
match
---
simple_stmt [3462,3624]
simple_stmt [3462,3624]
===
match
---
simple_stmt [4874,4893]
simple_stmt [4874,4893]
===
match
---
annassign [22248,22390]
annassign [22370,22512]
===
match
---
trailer [44342,44353]
trailer [44464,44475]
===
match
---
name: self [39343,39347]
name: self [39465,39469]
===
match
---
atom_expr [22234,22248]
atom_expr [22356,22370]
===
match
---
dotted_name [2166,2187]
dotted_name [2166,2187]
===
match
---
simple_stmt [11745,11773]
simple_stmt [11911,11918]
===
match
---
trailer [41053,41065]
trailer [41175,41187]
===
match
---
name: __name__ [14336,14344]
name: __name__ [14458,14466]
===
match
---
name: isoformat [44354,44363]
name: isoformat [44476,44485]
===
match
---
operator: , [19061,19062]
operator: , [19183,19184]
===
match
---
trailer [15415,15421]
trailer [15537,15543]
===
match
---
operator: , [13368,13369]
operator: , [13490,13491]
===
match
---
trailer [38670,38672]
trailer [38792,38794]
===
match
---
simple_stmt [10112,10151]
simple_stmt [10112,10151]
===
match
---
trailer [7999,8033]
trailer [7999,8033]
===
match
---
testlist_comp [6698,6751]
testlist_comp [6698,6751]
===
match
---
operator: = [33954,33955]
operator: = [34076,34077]
===
match
---
operator: = [39510,39511]
operator: = [39632,39633]
===
match
---
operator: , [14320,14321]
operator: , [14442,14443]
===
match
---
atom_expr [24639,24660]
atom_expr [24761,24782]
===
match
---
trailer [31171,31192]
trailer [31293,31314]
===
match
---
operator: , [18875,18876]
operator: , [18997,18998]
===
match
---
trailer [46988,47220]
trailer [47110,47342]
===
match
---
name: multiprocessing [7496,7511]
name: multiprocessing [7496,7511]
===
match
---
name: self [17113,17117]
name: self [17235,17239]
===
match
---
name: log [23599,23602]
name: log [23721,23724]
===
match
---
name: async_mode [12157,12167]
name: async_mode [12279,12289]
===
match
---
simple_stmt [2161,2211]
simple_stmt [2161,2211]
===
match
---
trailer [39880,39901]
trailer [40002,40023]
===
match
---
name: property [4017,4025]
name: property [4017,4025]
===
match
---
name: time [7828,7832]
name: time [7828,7832]
===
match
---
trailer [21536,21563]
trailer [21658,21685]
===
match
---
name: self [23691,23695]
name: self [23813,23817]
===
match
---
decorated [3396,3660]
decorated [3396,3660]
===
match
---
trailer [39775,39777]
trailer [39897,39899]
===
match
---
name: message [14368,14375]
name: message [14490,14497]
===
match
---
name: self [15407,15411]
name: self [15529,15533]
===
match
---
trailer [23142,23148]
trailer [23264,23270]
===
match
---
name: self [49068,49072]
name: self [49190,49194]
===
match
---
arith_expr [48628,48674]
arith_expr [48750,48796]
===
match
---
simple_stmt [16481,16538]
simple_stmt [16603,16660]
===
match
---
name: last_finish_time [36977,36993]
name: last_finish_time [37099,37115]
===
match
---
name: file_path [37504,37513]
name: file_path [37626,37635]
===
match
---
name: self [29523,29527]
name: self [29645,29649]
===
match
---
test [34179,34233]
test [34301,34355]
===
match
---
name: bool [12169,12173]
name: bool [12291,12295]
===
match
---
name: processor [44296,44305]
name: processor [44418,44427]
===
match
---
atom_expr [16425,16438]
atom_expr [16547,16560]
===
match
---
name: _log [22171,22175]
name: _log [22293,22297]
===
match
---
trailer [22254,22326]
trailer [22376,22448]
===
match
---
trailer [23205,23215]
trailer [23327,23337]
===
match
---
atom [8338,8727]
atom [8338,8727]
===
match
---
name: _max_runs [19339,19348]
name: _max_runs [19461,19470]
===
match
---
name: ConnectionError [10942,10957]
name: ConnectionError [10942,10957]
===
match
---
name: _signal_conn [40183,40195]
name: _signal_conn [40305,40317]
===
match
---
name: _file_stats [38694,38705]
name: _file_stats [38816,38827]
===
match
---
string: "# DAGs" [32686,32694]
string: "# DAGs" [32808,32816]
===
match
---
funcdef [35177,35381]
funcdef [35299,35503]
===
match
---
trailer [24643,24653]
trailer [24765,24775]
===
match
---
simple_stmt [952,992]
simple_stmt [952,992]
===
match
---
name: warning [20224,20231]
name: warning [20346,20353]
===
match
---
string: "Received message of type %s" [14291,14320]
string: "Received message of type %s" [14413,14442]
===
match
---
string: 'min_file_process_interval' [20601,20628]
string: 'min_file_process_interval' [20723,20750]
===
match
---
name: signum [22769,22775]
name: signum [22891,22897]
===
match
---
simple_stmt [37062,37355]
simple_stmt [37184,37477]
===
match
---
name: self [23494,23498]
name: self [23616,23620]
===
match
---
name: Stats [47237,47242]
name: Stats [47359,47364]
===
match
---
name: exitcode [15086,15094]
name: exitcode [15208,15216]
===
match
---
simple_stmt [40596,40678]
simple_stmt [40718,40800]
===
match
---
name: state [2230,2235]
name: state [2230,2235]
===
match
---
operator: @ [4030,4031]
operator: @ [4030,4031]
===
match
---
atom_expr [25555,25571]
atom_expr [25677,25693]
===
match
---
operator: , [39099,39100]
operator: , [39221,39222]
===
match
---
trailer [24801,24805]
trailer [24923,24927]
===
match
---
operator: , [6595,6596]
operator: , [6595,6596]
===
match
---
name: bool [6747,6751]
name: bool [6747,6751]
===
match
---
trailer [11933,11996]
trailer [12055,12118]
===
match
---
trailer [45067,45074]
trailer [45189,45196]
===
match
---
return_stmt [35752,35795]
return_stmt [35874,35917]
===
match
---
atom_expr [42556,42584]
atom_expr [42678,42706]
===
match
---
atom_expr [33703,33797]
atom_expr [33825,33919]
===
match
---
name: last_runtime [32842,32854]
name: last_runtime [32964,32976]
===
match
---
string: """         Stops all running processors         :return: None         """ [47917,47991]
string: """         Stops all running processors         :return: None         """ [48039,48113]
===
match
---
operator: , [19159,19160]
operator: , [19281,19282]
===
match
---
trailer [44648,44771]
trailer [44770,44893]
===
match
---
atom_expr [45205,45232]
atom_expr [45327,45354]
===
match
---
atom_expr [45157,45185]
atom_expr [45279,45307]
===
match
---
decorator [16094,16104]
decorator [16216,16226]
===
match
---
name: runtime [34182,34189]
name: runtime [34304,34311]
===
match
---
simple_stmt [16689,16694]
simple_stmt [16811,16816]
===
match
---
annassign [7729,7773]
annassign [7729,7773]
===
match
---
name: self [29177,29181]
name: self [29299,29303]
===
match
---
name: self [14252,14256]
name: self [14374,14378]
===
match
---
name: last_run [34429,34437]
name: last_run [34551,34559]
===
match
---
name: file_path [36533,36542]
name: file_path [36655,36664]
===
match
---
expr_stmt [12794,12848]
expr_stmt [12916,12970]
===
match
---
parameters [14251,14266]
parameters [14373,14388]
===
match
---
atom_expr [33506,33582]
atom_expr [33628,33704]
===
match
---
operator: , [6701,6702]
operator: , [6701,6702]
===
match
---
operator: + [39841,39842]
operator: + [39963,39964]
===
match
---
dotted_name [1110,1136]
dotted_name [1110,1136]
===
match
---
trailer [30129,30141]
trailer [30251,30263]
===
match
---
expr_stmt [21371,21406]
expr_stmt [21493,21528]
===
match
---
suite [27792,27996]
suite [27914,28118]
===
match
---
trailer [45588,45611]
trailer [45710,45733]
===
match
---
trailer [45742,45748]
trailer [45864,45870]
===
match
---
trailer [14876,14881]
trailer [14998,15003]
===
match
---
atom_expr [40178,40195]
atom_expr [40300,40317]
===
match
---
name: _exit_gracefully [22589,22605]
name: _exit_gracefully [22711,22727]
===
match
---
name: isinstance [25316,25326]
name: isinstance [25438,25448]
===
match
---
operator: , [37851,37852]
operator: , [37973,37974]
===
match
---
name: DagParsingSignal [9487,9503]
name: DagParsingSignal [9487,9503]
===
match
---
name: _process [15550,15558]
name: _process [15672,15680]
===
match
---
arglist [23608,23681]
arglist [23730,23803]
===
match
---
name: self [20401,20405]
name: self [20523,20527]
===
match
---
operator: = [44012,44013]
operator: = [44134,44135]
===
match
---
trailer [3657,3659]
trailer [3657,3659]
===
match
---
name: stat [35781,35785]
name: stat [35903,35907]
===
match
---
trailer [39135,39140]
trailer [39257,39262]
===
match
---
comparison [45986,46011]
comparison [46108,46133]
===
match
---
simple_stmt [14099,14129]
simple_stmt [14221,14251]
===
match
---
trailer [47189,47199]
trailer [47311,47321]
===
match
---
param [35413,35422]
param [35535,35544]
===
match
---
simple_stmt [37739,37778]
simple_stmt [37861,37900]
===
match
---
operator: , [22582,22583]
operator: , [22704,22705]
===
match
---
name: last_runtime [33773,33785]
name: last_runtime [33895,33907]
===
match
---
trailer [39309,39316]
trailer [39431,39438]
===
match
---
name: bool [6920,6924]
name: bool [6920,6924]
===
match
---
name: stat [37811,37815]
name: stat [37933,37937]
===
match
---
factor [47623,47625]
factor [47745,47747]
===
match
---
parameters [4495,4501]
parameters [4495,4501]
===
match
---
atom [7420,7422]
atom [7420,7422]
===
match
---
name: request [29037,29044]
name: request [29159,29166]
===
match
---
trailer [40062,40118]
trailer [40184,40240]
===
match
---
operator: , [33740,33741]
operator: , [33862,33863]
===
match
---
operator: = [40904,40905]
operator: = [41026,41027]
===
match
---
fstring_expr [34319,34337]
fstring_expr [34441,34459]
===
match
---
name: message [14524,14531]
name: message [14646,14653]
===
match
---
name: warning [38532,38539]
name: warning [38654,38661]
===
match
---
trailer [20781,20818]
trailer [20903,20940]
===
match
---
funcdef [28943,29660]
funcdef [29065,29782]
===
match
---
name: jobs [45309,45313]
name: jobs [45431,45435]
===
match
---
trailer [35716,35728]
trailer [35838,35850]
===
match
---
name: last_runtime [34018,34030]
name: last_runtime [34140,34152]
===
match
---
except_clause [16649,16671]
except_clause [16771,16793]
===
match
---
name: self [29454,29458]
name: self [29576,29580]
===
match
---
name: self [37746,37750]
name: self [37868,37872]
===
match
---
trailer [26474,26478]
trailer [26596,26600]
===
match
---
name: stat [48904,48908]
name: stat [49026,49030]
===
match
---
simple_stmt [7548,7573]
simple_stmt [7548,7573]
===
match
---
name: _file_paths [38112,38123]
name: _file_paths [38234,38245]
===
match
---
funcdef [13577,14226]
funcdef [13699,14348]
===
match
---
trailer [8296,8319]
trailer [8296,8319]
===
match
---
simple_stmt [46606,46635]
simple_stmt [46728,46757]
===
match
---
name: str [6866,6869]
name: str [6866,6869]
===
match
---
name: get_context [8070,8081]
name: get_context [8070,8081]
===
match
---
simple_stmt [901,915]
simple_stmt [901,915]
===
match
---
name: sorted [43046,43052]
name: sorted [43168,43174]
===
match
---
name: _max_runs [47610,47619]
name: _max_runs [47732,47741]
===
match
---
expr_stmt [40894,40934]
expr_stmt [41016,41056]
===
match
---
for_stmt [47679,47795]
for_stmt [47801,47917]
===
match
---
atom_expr [32973,33009]
atom_expr [33095,33131]
===
match
---
name: request [46581,46588]
name: request [46703,46710]
===
match
---
suite [9444,9520]
suite [9444,9520]
===
match
---
name: LoggingMixin [1951,1963]
name: LoggingMixin [1951,1963]
===
match
---
trailer [15887,15907]
trailer [16009,16029]
===
match
---
operator: = [34652,34653]
operator: = [34774,34775]
===
match
---
name: _async_mode [28712,28723]
name: _async_mode [28834,28845]
===
match
---
decorators [2934,2964]
decorators [2934,2964]
===
match
---
trailer [30751,30763]
trailer [30873,30885]
===
match
---
funcdef [41701,44832]
funcdef [41823,44954]
===
match
---
name: _processors [40385,40396]
name: _processors [40507,40518]
===
match
---
trailer [30726,30746]
trailer [30848,30868]
===
match
---
simple_stmt [36105,36144]
simple_stmt [36227,36266]
===
match
---
simple_stmt [38596,38635]
simple_stmt [38718,38757]
===
match
---
expr_stmt [8171,8231]
expr_stmt [8171,8231]
===
match
---
atom_expr [23115,23125]
atom_expr [23237,23247]
===
match
---
not_test [11229,11257]
not_test [11229,11257]
===
match
---
name: defaultdict [1016,1027]
name: defaultdict [1016,1027]
===
match
---
name: self [25379,25383]
name: self [25501,25505]
===
match
---
name: self [4065,4069]
name: self [4065,4069]
===
match
---
atom_expr [47292,47339]
atom_expr [47414,47461]
===
match
---
parameters [47505,47511]
parameters [47627,47633]
===
match
---
name: dag_ids [13469,13476]
name: dag_ids [13591,13598]
===
match
---
name: print_stats_interval [20747,20767]
name: print_stats_interval [20869,20889]
===
match
---
simple_stmt [27627,27720]
simple_stmt [27749,27842]
===
match
---
arglist [20782,20817]
arglist [20904,20939]
===
match
---
name: full_filepath [29160,29173]
name: full_filepath [29282,29295]
===
match
---
atom_expr [13296,13536]
atom_expr [13418,13658]
===
match
---
atom_expr [30125,30141]
atom_expr [30247,30263]
===
match
---
operator: } [7421,7422]
operator: } [7421,7422]
===
match
---
trailer [19964,19976]
trailer [20086,20098]
===
match
---
expr_stmt [42231,42252]
expr_stmt [42353,42374]
===
match
---
trailer [4434,4436]
trailer [4434,4436]
===
match
---
simple_stmt [6941,6960]
simple_stmt [6941,6960]
===
match
---
name: dag_directory [7041,7054]
name: dag_directory [7041,7054]
===
match
---
try_stmt [11383,11496]
try_stmt [11501,11615]
===
match
---
funcdef [46640,47480]
funcdef [46762,47602]
===
match
---
operator: , [43570,43571]
operator: , [43692,43693]
===
match
---
operator: - [48648,48649]
operator: - [48770,48771]
===
match
---
name: x [35339,35340]
name: x [35461,35462]
===
match
---
trailer [43453,43460]
trailer [43575,43582]
===
match
---
simple_stmt [30245,30331]
simple_stmt [30367,30453]
===
match
---
trailer [48939,48951]
trailer [49061,49073]
===
match
---
name: LOGGING_CLASS_PATH [13074,13092]
name: LOGGING_CLASS_PATH [13196,13214]
===
match
---
trailer [26905,26925]
trailer [27027,27047]
===
match
---
name: multiprocessing [40031,40046]
name: multiprocessing [40153,40168]
===
match
---
atom_expr [8145,8161]
atom_expr [8145,8161]
===
match
---
name: _max_runs [47755,47764]
name: _max_runs [47877,47886]
===
match
---
trailer [14335,14344]
trailer [14457,14466]
===
match
---
name: _collect_results_from_processor [38991,39022]
name: _collect_results_from_processor [39113,39144]
===
match
---
name: TI [45837,45839]
name: TI [45959,45961]
===
match
---
name: info [23802,23806]
name: info [23924,23928]
===
match
---
name: _process_message [14235,14251]
name: _process_message [14357,14373]
===
match
---
suite [7874,8881]
suite [7874,8881]
===
match
---
name: log [23139,23142]
name: log [23261,23264]
===
match
---
simple_stmt [26202,26211]
simple_stmt [26324,26333]
===
match
---
atom_expr [16861,16912]
atom_expr [16983,17034]
===
match
---
import_from [1689,1720]
import_from [1689,1720]
===
match
---
name: log [38528,38531]
name: log [38650,38653]
===
match
---
name: log_str [34737,34744]
name: log_str [34859,34866]
===
match
---
not_test [45102,45134]
not_test [45224,45256]
===
match
---
name: terminate [2597,2606]
name: terminate [2597,2606]
===
match
---
simple_stmt [13026,13129]
simple_stmt [13148,13251]
===
match
---
operator: -> [9782,9784]
operator: -> [9782,9784]
===
match
---
simple_stmt [19990,20041]
simple_stmt [20112,20163]
===
match
---
suite [32829,33798]
suite [32951,33920]
===
match
---
trailer [25937,25945]
trailer [26059,26067]
===
match
---
trailer [20958,21006]
trailer [21080,21128]
===
match
---
name: self [40284,40288]
name: self [40406,40410]
===
match
---
name: _add_callback_to_queue [46558,46580]
name: _add_callback_to_queue [46680,46702]
===
match
---
funcdef [37480,37823]
funcdef [37602,37945]
===
match
---
name: kill_child_processes_by_pids [48349,48377]
name: kill_child_processes_by_pids [48471,48499]
===
match
---
string: "=" [34532,34535]
string: "=" [34654,34657]
===
match
---
expr_stmt [39549,39855]
expr_stmt [39671,39977]
===
match
---
trailer [45209,45232]
trailer [45331,45354]
===
match
---
trailer [13902,13922]
trailer [14024,14044]
===
match
---
string: 'airflow.processor_manager' [22196,22223]
string: 'airflow.processor_manager' [22318,22345]
===
match
---
number: 0 [31116,31117]
number: 0 [31238,31239]
===
match
---
name: print_stats_interval [31125,31145]
name: print_stats_interval [31247,31267]
===
match
---
arith_expr [45546,45612]
arith_expr [45668,45734]
===
match
---
atom_expr [8356,8375]
atom_expr [8356,8375]
===
match
---
operator: = [29842,29843]
operator: = [29964,29965]
===
match
---
trailer [40505,40586]
trailer [40627,40708]
===
match
---
atom_expr [48650,48674]
atom_expr [48772,48796]
===
match
---
name: log [22928,22931]
name: log [23050,23053]
===
match
---
name: _add_callback_to_queue [28947,28969]
name: _add_callback_to_queue [29069,29091]
===
match
---
atom_expr [40859,40880]
atom_expr [40981,41002]
===
match
---
name: result [3703,3709]
name: result [3703,3709]
===
match
---
atom_expr [14763,14776]
atom_expr [14885,14898]
===
match
---
simple_stmt [26413,26442]
simple_stmt [26535,26564]
===
match
---
name: self [15728,15732]
name: self [15850,15854]
===
match
---
string: "Searching for files in %s" [30063,30090]
string: "Searching for files in %s" [30185,30212]
===
match
---
simple_stmt [1362,1389]
simple_stmt [1362,1389]
===
match
---
string: """         :return: When this started to process the file         :rtype: datetime         """ [4092,4187]
string: """         :return: When this started to process the file         :rtype: datetime         """ [4092,4187]
===
match
---
name: models [45460,45466]
name: models [45582,45588]
===
match
---
expr_stmt [20446,20467]
expr_stmt [20568,20589]
===
match
---
name: terminate [47892,47901]
name: terminate [48014,48023]
===
match
---
atom_expr [22523,22544]
atom_expr [22645,22666]
===
match
---
atom [6697,6752]
atom [6697,6752]
===
match
---
operator: = [20464,20465]
operator: = [20586,20587]
===
match
---
name: in_ [31760,31763]
name: in_ [31882,31885]
===
match
---
operator: , [15094,15095]
operator: , [15216,15217]
===
match
---
operator: , [22767,22768]
operator: , [22889,22890]
===
match
---
suite [3183,3391]
suite [3183,3391]
===
match
---
simple_stmt [33883,33930]
simple_stmt [34005,34052]
===
match
---
operator: = [41202,41203]
operator: = [41324,41325]
===
match
---
atom_expr [13026,13112]
atom_expr [13148,13234]
===
match
---
trailer [27678,27681]
trailer [27800,27803]
===
match
---
operator: , [41284,41285]
operator: , [41406,41407]
===
match
---
trailer [10917,10926]
trailer [10917,10926]
===
match
---
atom_expr [19368,19391]
atom_expr [19490,19513]
===
match
---
simple_stmt [22828,22915]
simple_stmt [22950,23037]
===
match
---
simple_stmt [15351,15395]
simple_stmt [15473,15517]
===
match
---
name: processor [26479,26488]
name: processor [26601,26610]
===
match
---
name: self [14276,14280]
name: self [14398,14402]
===
match
---
param [19023,19062]
param [19145,19184]
===
match
---
operator: = [42172,42173]
operator: = [42294,42295]
===
match
---
operator: , [47081,47082]
operator: , [47203,47204]
===
match
---
trailer [34076,34083]
trailer [34198,34205]
===
match
---
atom_expr [11553,11587]
atom_expr [11672,11706]
===
match
---
expr_stmt [4938,4968]
expr_stmt [4938,4968]
===
match
---
name: isoformat [47190,47199]
name: isoformat [47312,47321]
===
match
---
name: stat [15734,15738]
name: stat [15856,15860]
===
match
---
comparison [42301,42329]
comparison [42423,42451]
===
match
---
name: waitable_handle [41667,41682]
name: waitable_handle [41789,41804]
===
match
---
simple_stmt [13218,13268]
simple_stmt [13340,13390]
===
match
---
trailer [7379,7417]
trailer [7379,7417]
===
match
---
sync_comp_for [48923,48960]
sync_comp_for [49045,49082]
===
match
---
name: files_paths_at_run_limit [43506,43530]
name: files_paths_at_run_limit [43628,43652]
===
match
---
atom [33715,33796]
atom [33837,33918]
===
match
---
trailer [39453,39463]
trailer [39575,39585]
===
match
---
trailer [26353,26385]
trailer [26475,26507]
===
match
---
name: self [8107,8111]
name: self [8107,8111]
===
match
---
operator: = [38124,38125]
operator: = [38246,38247]
===
match
---
suite [9411,9431]
suite [9411,9431]
===
match
---
expr_stmt [4897,4933]
expr_stmt [4897,4933]
===
match
---
name: Optional [7731,7739]
name: Optional [7731,7739]
===
match
---
name: Dict [21334,21338]
name: Dict [21456,21460]
===
match
---
atom_expr [7663,7688]
atom_expr [7663,7688]
===
match
---
trailer [29527,29544]
trailer [29649,29666]
===
match
---
name: self [41049,41053]
name: self [41171,41175]
===
match
---
atom_expr [24696,24713]
atom_expr [24818,24835]
===
match
---
atom_expr [42174,42221]
atom_expr [42296,42343]
===
match
---
simple_stmt [40023,40119]
simple_stmt [40145,40241]
===
match
---
trailer [42403,42415]
trailer [42525,42537]
===
match
---
name: debug [27070,27075]
name: debug [27192,27197]
===
match
---
atom_expr [8661,8678]
atom_expr [8661,8678]
===
match
---
suite [38803,38982]
suite [38925,39104]
===
match
---
atom_expr [27027,27043]
atom_expr [27149,27165]
===
match
---
testlist_comp [14037,14062]
testlist_comp [14159,14184]
===
match
---
name: parsing_stat_age [15194,15210]
name: parsing_stat_age [15316,15332]
===
match
---
trailer [14727,14751]
trailer [14849,14873]
===
match
---
arglist [15643,15677]
arglist [15765,15799]
===
match
---
simple_stmt [16861,16913]
simple_stmt [16983,17035]
===
match
---
simple_stmt [4409,4437]
simple_stmt [4409,4437]
===
match
---
trailer [10753,10777]
trailer [10753,10777]
===
match
---
name: os [898,900]
name: os [898,900]
===
match
---
name: child_signal_conn [8197,8214]
name: child_signal_conn [8197,8214]
===
match
---
operator: != [45995,45997]
operator: != [46117,46119]
===
match
---
expr_stmt [46869,46906]
expr_stmt [46991,47028]
===
match
---
trailer [10136,10141]
trailer [10136,10141]
===
match
---
operator: = [33888,33889]
operator: = [34010,34011]
===
match
---
name: self [14899,14903]
name: self [15021,15025]
===
match
---
operator: @ [4229,4230]
operator: @ [4229,4230]
===
match
---
funcdef [18775,22391]
funcdef [18897,22513]
===
match
---
expr_stmt [22166,22224]
expr_stmt [22288,22346]
===
match
---
trailer [30200,30226]
trailer [30322,30348]
===
match
---
name: self [13985,13989]
name: self [14107,14111]
===
match
---
trailer [39235,39242]
trailer [39357,39364]
===
match
---
operator: == [45847,45849]
operator: == [45969,45971]
===
match
---
simple_stmt [37878,38099]
simple_stmt [38000,38221]
===
match
---
classdef [4635,4760]
classdef [4635,4760]
===
match
---
operator: = [7121,7122]
operator: = [7121,7122]
===
match
---
name: Any [22255,22258]
name: Any [22377,22380]
===
match
---
name: EOFError [14037,14045]
name: EOFError [14159,14167]
===
match
---
operator: , [20093,20094]
operator: , [20215,20216]
===
match
---
atom_expr [30640,30694]
atom_expr [30762,30816]
===
match
---
name: send_callback_to_execute [9725,9749]
name: send_callback_to_execute [9725,9749]
===
match
---
name: debug [23009,23014]
name: debug [23131,23136]
===
match
---
trailer [32861,32878]
trailer [32983,33000]
===
match
---
operator: = [40244,40245]
operator: = [40366,40367]
===
match
---
name: _zombie_query_interval [45210,45232]
name: _zombie_query_interval [45332,45354]
===
match
---
name: SIGUSR2 [22712,22719]
name: SIGUSR2 [22834,22841]
===
match
---
name: utcnow [42088,42094]
name: utcnow [42210,42216]
===
match
---
name: key [33903,33906]
name: key [34025,34028]
===
match
---
trailer [24926,24944]
trailer [25048,25066]
===
match
---
string: """Collect the result from any finished DAG processors""" [39957,40014]
string: """Collect the result from any finished DAG processors""" [40079,40136]
===
match
---
fstring_format_spec [34332,34336]
fstring_format_spec [34454,34458]
===
match
---
operator: } [34209,34210]
operator: } [34331,34332]
===
match
---
name: self [41481,41485]
name: self [41603,41607]
===
match
---
string: """         Emit metrics about dag parsing summary          This is called once every time around the parsing "loop" - i.e. after         all files have been parsed.         """ [48429,48606]
string: """         Emit metrics about dag parsing summary          This is called once every time around the parsing "loop" - i.e. after         all files have been parsed.         """ [48551,48728]
===
match
---
simple_stmt [41833,41880]
simple_stmt [41955,42002]
===
match
---
trailer [22118,22135]
trailer [22240,22257]
===
match
---
name: file_paths [43185,43195]
name: file_paths [43307,43317]
===
match
---
trailer [30295,30307]
trailer [30417,30429]
===
match
---
atom_expr [30810,30826]
atom_expr [30932,30948]
===
match
---
name: DagFileStat [44637,44648]
name: DagFileStat [44759,44770]
===
match
---
name: NamedTuple [4656,4666]
name: NamedTuple [4656,4666]
===
match
---
name: self [43580,43584]
name: self [43702,43706]
===
match
---
name: str [23058,23061]
name: str [23180,23183]
===
match
---
return_stmt [37409,37454]
return_stmt [37531,37576]
===
match
---
name: processor [26292,26301]
name: processor [26414,26423]
===
match
---
name: MultiprocessingConnection [12057,12082]
name: MultiprocessingConnection [12179,12204]
===
match
---
atom_expr [31209,31225]
atom_expr [31331,31347]
===
match
---
name: self [40809,40813]
name: self [40931,40935]
===
match
---
name: frame [22777,22782]
name: frame [22899,22904]
===
match
---
trailer [6860,6871]
trailer [6860,6871]
===
match
---
name: replace [33117,33124]
name: replace [33239,33246]
===
match
---
suite [37515,37823]
suite [37637,37945]
===
match
---
name: _find_zombies [44862,44875]
name: _find_zombies [44984,44997]
===
match
---
operator: { [14518,14519]
operator: { [14640,14641]
===
match
---
atom [34499,34713]
atom [34621,34835]
===
match
---
atom_expr [46037,46056]
atom_expr [46159,46178]
===
match
---
simple_stmt [31243,31293]
simple_stmt [31365,31415]
===
match
---
simple_stmt [46869,46907]
simple_stmt [46991,47029]
===
match
---
operator: = [11411,11412]
operator: = [11529,11530]
===
match
---
atom_expr [40596,40677]
atom_expr [40718,40799]
===
match
---
name: files_paths_to_queue [44519,44539]
name: files_paths_to_queue [44641,44661]
===
match
---
name: loop_duration [28741,28754]
name: loop_duration [28863,28876]
===
match
---
suite [42880,42945]
suite [43002,43067]
===
match
---
trailer [14903,14907]
trailer [15025,15029]
===
match
---
trailer [45928,45935]
trailer [46050,46057]
===
match
---
atom [7003,7005]
atom [7003,7005]
===
match
---
atom_expr [20770,20818]
atom_expr [20892,20940]
===
match
---
name: self [33226,33230]
name: self [33348,33352]
===
match
---
return_stmt [49061,49084]
return_stmt [49183,49206]
===
match
---
atom_expr [16213,16238]
atom_expr [16335,16360]
===
match
---
name: self [32857,32861]
name: self [32979,32983]
===
match
---
atom_expr [38934,38948]
atom_expr [39056,39070]
===
match
---
name: processor [46886,46895]
name: processor [47008,47017]
===
match
---
name: join [45782,45786]
name: join [45904,45908]
===
match
---
argument [13928,13940]
argument [14050,14062]
===
match
---
string: "Sending termination message to manager." [16495,16536]
string: "Sending termination message to manager." [16617,16658]
===
match
---
import_from [2072,2160]
import_from [2072,2160]
===
match
---
atom_expr [6675,6795]
atom_expr [6675,6795]
===
match
---
atom_expr [20917,20944]
atom_expr [21039,21066]
===
match
---
name: self [28399,28403]
name: self [28521,28525]
===
match
---
funcdef [48134,48392]
funcdef [48256,48514]
===
match
---
operator: = [19310,19311]
operator: = [19432,19433]
===
match
---
name: self [27751,27755]
name: self [27873,27877]
===
match
---
atom_expr [30747,30763]
atom_expr [30869,30885]
===
match
---
atom_expr [13767,13801]
atom_expr [13889,13923]
===
match
---
expr_stmt [28741,28791]
expr_stmt [28863,28913]
===
match
---
param [22763,22768]
param [22885,22890]
===
match
---
name: run_count [39791,39800]
name: run_count [39913,39922]
===
match
---
atom_expr [19244,19265]
atom_expr [19366,19387]
===
match
---
number: 0 [21252,21253]
number: 0 [21374,21375]
===
match
---
name: values [38902,38908]
name: values [39024,39030]
===
match
---
atom_expr [38360,38384]
atom_expr [38482,38506]
===
match
---
param [18985,19014]
param [19107,19136]
===
match
---
atom_expr [33917,33921]
atom_expr [34039,34043]
===
match
---
trailer [38153,38170]
trailer [38275,38292]
===
match
---
testlist_comp [44028,44107]
testlist_comp [44150,44229]
===
match
---
simple_stmt [4511,4597]
simple_stmt [4511,4597]
===
match
---
name: self [22422,22426]
name: self [22544,22548]
===
match
---
funcdef [36601,37012]
funcdef [36723,37134]
===
match
---
name: all [46128,46131]
name: all [46250,46253]
===
match
---
number: 1 [47624,47625]
number: 1 [47746,47747]
===
match
---
trailer [6995,7000]
trailer [6995,7000]
===
match
---
atom_expr [21801,21824]
atom_expr [21923,21946]
===
match
---
name: kill [47473,47477]
name: kill [47595,47599]
===
match
---
trailer [13232,13267]
trailer [13354,13389]
===
match
---
name: self [31894,31898]
name: self [32016,32020]
===
match
---
trailer [41354,41375]
trailer [41476,41497]
===
match
---
name: self [41729,41733]
name: self [41851,41855]
===
match
---
expr_stmt [15855,15907]
expr_stmt [15977,16029]
===
match
---
simple_stmt [1586,1645]
simple_stmt [1586,1645]
===
match
---
operator: = [43104,43105]
operator: = [43226,43227]
===
match
---
operator: = [44751,44752]
operator: = [44873,44874]
===
match
---
suite [14698,14752]
suite [14820,14874]
===
match
---
atom_expr [10052,10086]
atom_expr [10052,10086]
===
match
---
name: self [38149,38153]
name: self [38271,38275]
===
match
---
tfpdef [12092,12120]
tfpdef [12214,12242]
===
match
---
name: airflow [1427,1434]
name: airflow [1427,1434]
===
match
---
trailer [42087,42094]
trailer [42209,42216]
===
match
---
operator: , [8866,8867]
operator: , [8866,8867]
===
match
---
return_stmt [23936,23967]
return_stmt [24058,24089]
===
match
---
atom_expr [26821,26840]
atom_expr [26943,26962]
===
match
---
atom_expr [33034,33061]
atom_expr [33156,33183]
===
match
---
name: gauge [48756,48761]
name: gauge [48878,48883]
===
match
---
param [6843,6872]
param [6843,6872]
===
match
---
atom_expr [35120,35151]
atom_expr [35242,35273]
===
match
---
name: List [11940,11944]
name: List [12062,12066]
===
match
---
suite [30864,30987]
suite [30986,31109]
===
match
---
trailer [36163,36172]
trailer [36285,36294]
===
match
---
arglist [15439,15597]
arglist [15561,15719]
===
match
---
trailer [15701,15703]
trailer [15823,15825]
===
match
---
trailer [21320,21332]
trailer [21442,21454]
===
match
---
trailer [22727,22735]
trailer [22849,22857]
===
match
---
raise_stmt [3363,3390]
raise_stmt [3363,3390]
===
match
---
name: timeout [14842,14849]
name: timeout [14964,14971]
===
match
---
name: self [27027,27031]
name: self [27149,27153]
===
match
---
simple_stmt [47521,47594]
simple_stmt [47643,47716]
===
match
---
import_as_names [1049,1068]
import_as_names [1049,1068]
===
match
---
name: AGENT_RUN_ONCE [9504,9518]
name: AGENT_RUN_ONCE [9504,9518]
===
match
---
operator: , [21342,21343]
operator: , [21464,21465]
===
match
---
comparison [44069,44107]
comparison [44191,44229]
===
match
---
dotted_name [1726,1739]
dotted_name [1726,1739]
===
match
---
name: ValueError [10052,10062]
name: ValueError [10052,10062]
===
match
---
name: file_path [37366,37375]
name: file_path [37488,37497]
===
match
---
atom_expr [47605,47619]
atom_expr [47727,47741]
===
match
---
simple_stmt [47782,47795]
simple_stmt [47904,47917]
===
match
---
trailer [22704,22736]
trailer [22826,22858]
===
match
---
name: _processors [42046,42057]
name: _processors [42168,42179]
===
match
---
string: """         After the process is finished, this can be called to get the return code         :return: the exit code of the process         :rtype: int         """ [3192,3354]
string: """         After the process is finished, this can be called to get the return code         :return: the exit code of the process         :rtype: int         """ [3192,3354]
===
match
---
name: self [37498,37502]
name: self [37620,37624]
===
match
---
trailer [4221,4223]
trailer [4221,4223]
===
match
---
trailer [23607,23682]
trailer [23729,23804]
===
match
---
trailer [32936,32947]
trailer [33058,33069]
===
match
---
atom_expr [24200,24223]
atom_expr [24322,24345]
===
match
---
operator: - [39512,39513]
operator: - [39634,39635]
===
match
---
param [6605,6624]
param [6605,6624]
===
match
---
expr_stmt [7014,7054]
expr_stmt [7014,7054]
===
match
---
atom_expr [44155,44179]
atom_expr [44277,44301]
===
match
---
name: importlib [828,837]
name: importlib [828,837]
===
match
---
name: self [35120,35124]
name: self [35242,35246]
===
match
---
trailer [8290,8296]
trailer [8290,8296]
===
match
---
atom_expr [29177,29198]
atom_expr [29299,29320]
===
match
---
name: timedelta [45566,45575]
name: timedelta [45688,45697]
===
match
---
param [3439,3443]
param [3439,3443]
===
match
---
string: """         :param file_path: the path to the file that's being processed         :type file_path: unicode         :return: the number of times the given file has been parsed         :rtype: int         """ [37524,37730]
string: """         :param file_path: the path to the file that's being processed         :type file_path: unicode         :return: the number of times the given file has been parsed         :rtype: int         """ [37646,37852]
===
match
---
not_test [14868,14881]
not_test [14990,15003]
===
match
---
simple_stmt [11508,11538]
simple_stmt [11627,11657]
===
match
---
name: airflow [45301,45308]
name: airflow [45423,45430]
===
match
---
operator: , [39027,39028]
operator: , [39149,39150]
===
match
---
atom_expr [31120,31145]
atom_expr [31242,31267]
===
match
---
trailer [38709,38720]
trailer [38831,38842]
===
match
---
trailer [45161,45185]
trailer [45283,45307]
===
match
---
name: seconds_ago [33570,33581]
name: seconds_ago [33692,33703]
===
match
---
atom_expr [39556,39855]
atom_expr [39678,39977]
===
match
---
name: stat [48781,48785]
name: stat [48903,48907]
===
match
---
name: self [10393,10397]
name: self [10393,10397]
===
match
---
trailer [45786,45810]
trailer [45908,45932]
===
match
---
trailer [45887,45893]
trailer [46009,46015]
===
match
---
name: _file_paths [49073,49084]
name: _file_paths [49195,49206]
===
match
---
trailer [9481,9486]
trailer [9481,9486]
===
match
---
trailer [42680,42701]
trailer [42802,42823]
===
match
---
except_clause [30569,30585]
except_clause [30691,30707]
===
match
---
atom_expr [45566,45612]
atom_expr [45688,45734]
===
match
---
name: _processor_timeout [7154,7172]
name: _processor_timeout [7154,7172]
===
match
---
name: self [15130,15134]
name: self [15252,15256]
===
match
---
name: logger [17191,17197]
name: logger [17313,17319]
===
match
---
operator: = [19514,19515]
operator: = [19636,19637]
===
match
---
name: Dict [1233,1237]
name: Dict [1233,1237]
===
match
---
name: _async_mode [24107,24118]
name: _async_mode [24229,24240]
===
match
---
name: Stats [39130,39135]
name: Stats [39252,39257]
===
match
---
name: dag_directory [11855,11868]
name: dag_directory [11977,11990]
===
match
---
string: """         Kill all child processes on exit since we don't want to leave         them as orphaned.         """ [48157,48268]
string: """         Kill all child processes on exit since we don't want to leave         them as orphaned.         """ [48279,48390]
===
match
---
trailer [7205,7214]
trailer [7205,7214]
===
match
---
trailer [22927,22931]
trailer [23049,23053]
===
match
---
name: List [19267,19271]
name: List [19389,19393]
===
match
---
atom_expr [21070,21089]
atom_expr [21192,21211]
===
match
---
argument [44699,44720]
argument [44821,44842]
===
match
---
suite [4792,4988]
suite [4792,4988]
===
match
---
return_stmt [16206,16238]
return_stmt [16328,16360]
===
match
---
trailer [14767,14776]
trailer [14889,14898]
===
match
---
name: processor [39300,39309]
name: processor [39422,39431]
===
match
---
trailer [16494,16537]
trailer [16616,16659]
===
match
---
trailer [27813,27826]
trailer [27935,27948]
===
match
---
name: _file_path_queue [29182,29198]
name: _file_path_queue [29304,29320]
===
match
---
operator: , [33901,33902]
operator: , [34023,34024]
===
match
---
arglist [43731,43786]
arglist [43853,43908]
===
match
---
operator: , [23754,23755]
operator: , [23876,23877]
===
match
---
comparison [44556,44589]
comparison [44678,44711]
===
match
---
string: 'scheduler' [21979,21990]
string: 'scheduler' [22101,22112]
===
match
---
suite [33426,33583]
suite [33548,33705]
===
match
---
name: formatted_rows [33939,33953]
name: formatted_rows [34061,34075]
===
match
---
arglist [34629,34660]
arglist [34751,34782]
===
match
---
trailer [12406,12412]
trailer [12528,12534]
===
match
---
param [44876,44881]
param [44998,45003]
===
match
---
atom_expr [40568,40585]
atom_expr [40690,40707]
===
match
---
expr_stmt [41192,41332]
expr_stmt [41314,41454]
===
match
---
operator: } [33677,33678]
operator: } [33799,33800]
===
match
---
trailer [3104,3106]
trailer [3104,3106]
===
match
---
simple_stmt [7705,7774]
simple_stmt [7705,7774]
===
match
---
operator: , [39777,39778]
operator: , [39899,39900]
===
match
---
name: remove_deleted_dags [30727,30746]
name: remove_deleted_dags [30849,30868]
===
match
---
simple_stmt [4938,4969]
simple_stmt [4938,4969]
===
match
---
simple_stmt [1689,1721]
simple_stmt [1689,1721]
===
match
---
name: file_path [41567,41576]
name: file_path [41689,41698]
===
match
---
name: session [31841,31848]
name: session [31963,31970]
===
match
---
name: timezone [29789,29797]
name: timezone [29911,29919]
===
match
---
if_stmt [47803,47863]
if_stmt [47925,47985]
===
match
---
comparison [26151,26180]
comparison [26273,26302]
===
match
---
trailer [40658,40675]
trailer [40780,40797]
===
match
---
argument [39612,39645]
argument [39734,39767]
===
match
---
operator: -> [7866,7868]
operator: -> [7866,7868]
===
match
---
arglist [48762,48833]
arglist [48884,48955]
===
match
---
name: DagParsingStat [14377,14391]
name: DagParsingStat [14499,14513]
===
match
---
name: Union [18826,18831]
name: Union [18948,18953]
===
match
---
name: self [30163,30167]
name: self [30285,30289]
===
match
---
suite [47837,47863]
suite [47959,47985]
===
match
---
name: datetime [4074,4082]
name: datetime [4074,4082]
===
match
---
trailer [9390,9399]
trailer [9390,9399]
===
match
---
expr_stmt [22234,22390]
expr_stmt [22356,22512]
===
match
---
atom_expr [8805,8880]
atom_expr [8805,8880]
===
match
---
trailer [22507,22545]
trailer [22629,22667]
===
match
---
operator: , [47201,47202]
operator: , [47323,47324]
===
match
---
suite [31014,31350]
suite [31136,31472]
===
match
---
trailer [24221,24223]
trailer [24343,24345]
===
match
---
decorators [3396,3426]
decorators [3396,3426]
===
match
---
trailer [19536,19548]
trailer [19658,19670]
===
match
---
trailer [43630,43640]
trailer [43752,43762]
===
match
---
trailer [13563,13569]
trailer [13685,13691]
===
match
---
name: _file_path_queue [29459,29475]
name: _file_path_queue [29581,29597]
===
match
---
if_stmt [11226,11312]
if_stmt [11226,11312]
===
match
---
atom_expr [13057,13110]
atom_expr [13179,13232]
===
match
---
operator: , [20970,20971]
operator: , [21092,21093]
===
match
---
atom_expr [8171,8195]
atom_expr [8171,8195]
===
match
---
name: pickle_dags [12130,12141]
name: pickle_dags [12252,12263]
===
match
---
name: self [34723,34727]
name: self [34845,34849]
===
match
---
name: info [45634,45638]
name: info [45756,45760]
===
match
---
name: file_path [33051,33060]
name: file_path [33173,33182]
===
match
---
param [36227,36236]
param [36349,36358]
===
match
---
simple_stmt [46974,47221]
simple_stmt [47096,47343]
===
match
---
trailer [43473,43475]
trailer [43595,43597]
===
match
---
name: synchronize_session [31804,31823]
name: synchronize_session [31926,31945]
===
match
---
name: models [1435,1441]
name: models [1435,1441]
===
match
---
argument [8333,8727]
argument [8333,8727]
===
match
---
name: _file_process_interval [20551,20573]
name: _file_process_interval [20673,20695]
===
match
---
operator: == [24907,24909]
operator: == [25029,25031]
===
match
---
test [33279,33341]
test [33401,33463]
===
match
---
test [37793,37822]
test [37915,37944]
===
match
---
trailer [26838,26840]
trailer [26960,26962]
===
match
---
not_test [14781,14809]
not_test [14903,14931]
===
match
---
raise_stmt [25463,25520]
raise_stmt [25585,25642]
===
match
---
trailer [11330,11350]
trailer [11448,11468]
===
match
---
operator: = [10867,10868]
operator: = [10867,10868]
===
match
---
funcdef [48397,48972]
funcdef [48519,49094]
===
match
---
name: self [40322,40326]
name: self [40444,40448]
===
match
---
operator: + [34618,34619]
operator: + [34740,34741]
===
match
---
param [15999,16003]
param [16121,16125]
===
match
---
name: _print_stat [30996,31007]
name: _print_stat [31118,31129]
===
match
---
operator: = [20068,20069]
operator: = [20190,20191]
===
match
---
simple_stmt [38107,38141]
simple_stmt [38229,38263]
===
match
---
name: getint [21972,21978]
name: getint [22094,22100]
===
match
---
name: self [19420,19424]
name: self [19542,19546]
===
match
---
atom_expr [44781,44831]
atom_expr [44903,44953]
===
match
---
trailer [48688,48694]
trailer [48810,48816]
===
match
---
name: _file_path_queue [29610,29626]
name: _file_path_queue [29732,29748]
===
match
---
name: str [6996,6999]
name: str [6996,6999]
===
match
---
atom_expr [7149,7172]
atom_expr [7149,7172]
===
match
---
name: DagParsingSignal [24910,24926]
name: DagParsingSignal [25032,25048]
===
match
---
trailer [30290,30308]
trailer [30412,30430]
===
match
---
atom_expr [47463,47479]
atom_expr [47585,47601]
===
match
---
operator: , [40566,40567]
operator: , [40688,40689]
===
match
---
trailer [11563,11587]
trailer [11682,11706]
===
match
---
name: session [44882,44889]
name: session [45004,45011]
===
match
---
name: duration [46869,46877]
name: duration [46991,46999]
===
match
---
param [6881,6899]
param [6881,6899]
===
match
---
name: reload [13147,13153]
name: reload [13269,13275]
===
match
---
parameters [11151,11157]
parameters [11151,11157]
===
match
---
operator: == [47620,47622]
operator: == [47742,47744]
===
match
---
atom_expr [40088,40105]
atom_expr [40210,40227]
===
match
---
atom_expr [47134,47147]
atom_expr [47256,47269]
===
match
---
name: os [25136,25138]
name: os [25258,25260]
===
match
---
import_from [1964,2028]
import_from [1964,2028]
===
match
---
trailer [38364,38376]
trailer [38486,38498]
===
match
---
simple_stmt [47405,47447]
simple_stmt [47527,47569]
===
match
---
trailer [21488,21514]
trailer [21610,21636]
===
match
---
name: log [30250,30253]
name: log [30372,30375]
===
match
---
atom [33956,33958]
atom [34078,34080]
===
match
---
number: 0.1 [38977,38980]
number: 0.1 [39099,39102]
===
match
---
name: warning [16870,16877]
name: warning [16992,16999]
===
match
---
trailer [24980,24982]
trailer [25102,25104]
===
match
---
name: self [10008,10012]
name: self [10008,10012]
===
match
---
simple_stmt [7063,7089]
simple_stmt [7063,7089]
===
match
---
trailer [20054,20067]
trailer [20176,20189]
===
match
---
operator: } [21360,21361]
operator: } [21482,21483]
===
match
---
suite [40881,41696]
suite [41003,41818]
===
match
---
name: Dict [21179,21183]
name: Dict [21301,21305]
===
match
---
simple_stmt [9457,9520]
simple_stmt [9457,9520]
===
match
---
decorator [4016,4026]
decorator [4016,4026]
===
match
---
arglist [20006,20039]
arglist [20128,20161]
===
match
---
trailer [25406,25420]
trailer [25528,25542]
===
match
---
name: self [48414,48418]
name: self [48536,48540]
===
match
---
name: file_path [46807,46816]
name: file_path [46929,46938]
===
match
---
expr_stmt [7472,7539]
expr_stmt [7472,7539]
===
match
---
operator: = [19438,19439]
operator: = [19560,19561]
===
match
---
argument [48781,48832]
argument [48903,48954]
===
match
---
string: """:return: the PID of the process launched to process the given file""" [2998,3070]
string: """:return: the PID of the process launched to process the given file""" [2998,3070]
===
match
---
testlist_comp [43547,43640]
testlist_comp [43669,43762]
===
match
---
name: parse_time [48615,48625]
name: parse_time [48737,48747]
===
match
---
operator: } [14541,14542]
operator: } [14663,14664]
===
match
---
operator: = [46430,46431]
operator: = [46552,46553]
===
match
---
trailer [13092,13099]
trailer [13214,13221]
===
match
---
string: "\n" [34676,34680]
string: "\n" [34798,34802]
===
match
---
name: Enum [5018,5022]
name: Enum [5018,5022]
===
match
---
atom_expr [6726,6745]
atom_expr [6726,6745]
===
match
---
trailer [20184,20197]
trailer [20306,20319]
===
match
---
name: processor_start_time [33286,33306]
name: processor_start_time [33408,33428]
===
match
---
atom_expr [22691,22736]
atom_expr [22813,22858]
===
match
---
name: DagParsingStat [4641,4655]
name: DagParsingStat [4641,4655]
===
match
---
name: self [24639,24643]
name: self [24761,24765]
===
match
---
simple_stmt [2901,2929]
simple_stmt [2901,2929]
===
match
---
name: signal [22705,22711]
name: signal [22827,22833]
===
match
---
name: logging [860,867]
name: logging [860,867]
===
match
---
atom_expr [7731,7766]
atom_expr [7731,7766]
===
match
---
name: self [11326,11330]
name: self [11444,11448]
===
match
---
suite [47908,48129]
suite [48030,48251]
===
match
---
dotted_name [1650,1666]
dotted_name [1650,1666]
===
match
---
name: list_mode [42301,42310]
name: list_mode [42423,42432]
===
match
---
atom_expr [10112,10150]
atom_expr [10112,10150]
===
match
---
atom_expr [35759,35777]
atom_expr [35881,35899]
===
match
---
trailer [27611,27613]
trailer [27733,27735]
===
match
---
param [19109,19127]
param [19231,19249]
===
match
---
name: get_last_runtime [35390,35406]
name: get_last_runtime [35512,35528]
===
match
---
name: seconds [45576,45583]
name: seconds [45698,45705]
===
match
---
name: incr [46612,46616]
name: incr [46734,46738]
===
match
---
name: abstractmethod [4244,4258]
name: abstractmethod [4244,4258]
===
match
---
trailer [40336,40340]
trailer [40458,40462]
===
match
---
atom_expr [41301,41318]
atom_expr [41423,41440]
===
match
---
suite [15338,15704]
suite [15460,15826]
===
match
---
operator: = [29476,29477]
operator: = [29598,29599]
===
match
---
atom_expr [15624,15678]
atom_expr [15746,15800]
===
match
---
trailer [24772,24777]
trailer [24894,24899]
===
match
---
name: wait_until_finished [38777,38796]
name: wait_until_finished [38899,38918]
===
match
---
name: _file_paths [42404,42415]
name: _file_paths [42526,42537]
===
match
---
decorator [31355,31372]
decorator [31477,31494]
===
match
---
import_name [940,951]
import_name [940,951]
===
match
---
operator: , [46228,46229]
operator: , [46350,46351]
===
match
---
name: settings [13065,13073]
name: settings [13187,13195]
===
match
---
name: new_file_paths [38414,38428]
name: new_file_paths [38536,38550]
===
match
---
name: processor_factory [13382,13399]
name: processor_factory [13504,13521]
===
match
---
expr_stmt [24174,24190]
expr_stmt [24296,24312]
===
match
---
name: len [30287,30290]
name: len [30409,30412]
===
match
---
operator: = [37744,37745]
operator: = [37866,37867]
===
match
---
name: utils [1920,1925]
name: utils [1920,1925]
===
match
---
name: len [40650,40653]
name: len [40772,40775]
===
match
---
operator: -> [4071,4073]
operator: -> [4071,4073]
===
match
---
expr_stmt [32960,33009]
expr_stmt [33082,33131]
===
match
---
name: provide_session [2195,2210]
name: provide_session [2195,2210]
===
match
---
name: _processors [21166,21177]
name: _processors [21288,21299]
===
match
---
name: self [48935,48939]
name: self [49057,49061]
===
match
---
trailer [47737,47747]
trailer [47859,47869]
===
match
---
name: Optional [4915,4923]
name: Optional [4915,4923]
===
match
---
operator: , [39645,39646]
operator: , [39767,39768]
===
match
---
trailer [41594,41606]
trailer [41716,41728]
===
match
---
name: processor_timeout [21827,21844]
name: processor_timeout [21949,21966]
===
match
---
atom_expr [28707,28723]
atom_expr [28829,28845]
===
match
---
raise_stmt [4196,4223]
raise_stmt [4196,4223]
===
match
---
atom_expr [40654,40675]
atom_expr [40776,40797]
===
match
---
string: """Kill any file processors that timeout to defend against process hangs.""" [46686,46762]
string: """Kill any file processors that timeout to defend against process hangs.""" [46808,46884]
===
match
---
expr_stmt [15916,15970]
expr_stmt [16038,16092]
===
match
---
string: 'Ending without manager process.' [16878,16911]
string: 'Ending without manager process.' [17000,17033]
===
match
---
funcdef [4050,4224]
funcdef [4050,4224]
===
match
---
expr_stmt [21484,21563]
expr_stmt [21606,21685]
===
match
---
name: self [30310,30314]
name: self [30432,30436]
===
match
---
atom_expr [22705,22719]
atom_expr [22827,22841]
===
match
---
name: timezone [32769,32777]
name: timezone [32891,32899]
===
match
---
operator: , [20418,20419]
operator: , [20540,20541]
===
match
---
tfpdef [6908,6924]
tfpdef [6908,6924]
===
match
---
string: """         Sends information about the SLA callback to be executed by DagFileProcessor.          :param full_filepath: DAG File path         :type full_filepath: str         :param dag_id: DAG ID         :type dag_id: str         """ [10449,10683]
string: """         Sends information about the SLA callback to be executed by DagFileProcessor.          :param full_filepath: DAG File path         :type full_filepath: str         :param dag_id: DAG ID         :type dag_id: str         """ [10449,10683]
===
match
---
name: reap_process_group [2142,2160]
name: reap_process_group [2142,2160]
===
match
---
parameters [16257,16263]
parameters [16379,16385]
===
match
---
trailer [23498,23520]
trailer [23620,23642]
===
match
---
number: 80 [34701,34703]
number: 80 [34823,34825]
===
match
---
simple_stmt [26901,26928]
simple_stmt [27023,27050]
===
match
---
trailer [20147,20175]
trailer [20269,20297]
===
match
---
name: processor [39740,39749]
name: processor [39862,39871]
===
match
---
name: get [42179,42182]
name: get [42301,42304]
===
match
---
operator: , [47112,47113]
operator: , [47234,47235]
===
match
---
name: models [1599,1605]
name: models [1599,1605]
===
match
---
fstring_end: " [25518,25519]
fstring_end: " [25640,25641]
===
match
---
name: last_finish_time [39659,39675]
name: last_finish_time [39781,39797]
===
match
---
name: _processors [44160,44171]
name: _processors [44282,44293]
===
match
---
operator: = [5083,5084]
operator: = [5083,5084]
===
match
---
name: List [6861,6865]
name: List [6861,6865]
===
match
---
try_stmt [13955,14087]
try_stmt [14077,14209]
===
match
---
atom_expr [48292,48311]
atom_expr [48414,48433]
===
match
---
dotted_name [1969,1989]
dotted_name [1969,1989]
===
match
---
arglist [22568,22605]
arglist [22690,22727]
===
match
---
string: 'dag_processing.processor_timeouts' [47303,47338]
string: 'dag_processing.processor_timeouts' [47425,47460]
===
match
---
trailer [24759,24772]
trailer [24881,24894]
===
match
---
operator: = [8215,8216]
operator: = [8215,8216]
===
match
---
testlist_comp [32655,32734]
testlist_comp [32777,32856]
===
match
---
operator: - [15230,15231]
operator: - [15352,15353]
===
match
---
subscriptlist [22255,22325]
subscriptlist [22377,22447]
===
match
---
name: pid [41562,41565]
name: pid [41684,41687]
===
match
---
name: self [15691,15695]
name: self [15813,15817]
===
match
---
operator: = [42299,42300]
operator: = [42421,42422]
===
match
---
trailer [27707,27718]
trailer [27829,27840]
===
match
---
atom_expr [48683,48741]
atom_expr [48805,48863]
===
match
---
operator: = [10845,10846]
operator: = [10845,10846]
===
match
---
name: random [43447,43453]
name: random [43569,43575]
===
match
---
trailer [45554,45561]
trailer [45676,45683]
===
match
---
simple_stmt [13180,13210]
simple_stmt [13302,13332]
===
match
---
parameters [9749,9781]
parameters [9749,9781]
===
match
---
simple_stmt [27061,27137]
simple_stmt [27183,27259]
===
match
---
trailer [22567,22606]
trailer [22689,22728]
===
match
---
or_test [9267,9316]
or_test [9267,9316]
===
match
---
simple_stmt [23494,23523]
simple_stmt [23616,23645]
===
match
---
atom [33457,33473]
atom [33579,33595]
===
match
---
operator: , [6871,6872]
operator: , [6871,6872]
===
match
---
simple_stmt [1287,1362]
simple_stmt [1287,1362]
===
match
---
atom_expr [24275,24291]
atom_expr [24397,24413]
===
match
---
if_stmt [31206,31293]
if_stmt [31328,31415]
===
match
---
atom_expr [35354,35379]
atom_expr [35476,35501]
===
match
---
param [36632,36641]
param [36754,36763]
===
match
---
name: now [32763,32766]
name: now [32885,32888]
===
match
---
atom_expr [9303,9316]
atom_expr [9303,9316]
===
match
---
name: debug [40500,40505]
name: debug [40622,40627]
===
match
---
trailer [21559,21562]
trailer [21681,21684]
===
match
---
trailer [28535,28539]
trailer [28657,28661]
===
match
---
simple_stmt [40234,40310]
simple_stmt [40356,40432]
===
match
---
atom_expr [12794,12839]
atom_expr [12916,12961]
===
match
---
trailer [16838,16847]
trailer [16960,16969]
===
match
---
trailer [3727,3744]
trailer [3727,3744]
===
match
---
name: self [26240,26244]
name: self [26362,26366]
===
match
---
name: tabulate [34620,34628]
name: tabulate [34742,34750]
===
match
---
name: property [4230,4238]
name: property [4230,4238]
===
match
---
name: total_seconds [33474,33487]
name: total_seconds [33596,33609]
===
match
---
name: dag_directory [18811,18824]
name: dag_directory [18933,18946]
===
match
---
not_test [10695,10723]
not_test [10695,10723]
===
match
---
name: _max_runs [8398,8407]
name: _max_runs [8398,8407]
===
match
---
name: start_time [37444,37454]
name: start_time [37566,37576]
===
match
---
parameters [40706,40712]
parameters [40828,40834]
===
match
---
name: abstractmethod [2435,2449]
name: abstractmethod [2435,2449]
===
match
---
name: sys [23197,23200]
name: sys [23319,23322]
===
match
---
operator: , [18835,18836]
operator: , [18957,18958]
===
match
---
name: setpgid [23571,23578]
name: setpgid [23693,23700]
===
match
---
name: _file_stats [39869,39880]
name: _file_stats [39991,40002]
===
match
---
string: 'zombies_killed' [46617,46633]
string: 'zombies_killed' [46739,46755]
===
match
---
name: get [36129,36132]
name: get [36251,36254]
===
match
---
name: file_path [29548,29557]
name: file_path [29670,29679]
===
match
---
string: """Register signals that stop child processes""" [22437,22485]
string: """Register signals that stop child processes""" [22559,22607]
===
match
---
trailer [12109,12120]
trailer [12231,12242]
===
match
---
name: _refresh_dag_dir [26518,26534]
name: _refresh_dag_dir [26640,26656]
===
match
---
simple_stmt [38651,38673]
simple_stmt [38773,38795]
===
match
---
trailer [43184,43196]
trailer [43306,43318]
===
match
---
fstring_expr [14518,14542]
fstring_expr [14640,14664]
===
match
---
trailer [48040,48042]
trailer [48162,48164]
===
match
---
name: self [22077,22081]
name: self [22199,22203]
===
match
---
name: file_path [44556,44565]
name: file_path [44678,44687]
===
match
---
arglist [45639,45692]
arglist [45761,45814]
===
match
---
trailer [11237,11257]
trailer [11237,11257]
===
match
---
simple_stmt [11490,11496]
simple_stmt [11608,11615]
===
match
---
atom_expr [19203,19219]
atom_expr [19325,19341]
===
match
---
name: self [16213,16217]
name: self [16335,16339]
===
match
---
name: file_path [44306,44315]
name: file_path [44428,44437]
===
match
---
trailer [48785,48794]
trailer [48907,48916]
===
match
---
atom_expr [29037,29058]
atom_expr [29159,29180]
===
match
---
name: models [1538,1544]
name: models [1538,1544]
===
match
---
trailer [29044,29058]
trailer [29166,29180]
===
match
---
atom_expr [7783,7818]
atom_expr [7783,7818]
===
match
---
simple_stmt [30125,30184]
simple_stmt [30247,30306]
===
match
---
string: "Processor for %s exited with return code %s." [39375,39421]
string: "Processor for %s exited with return code %s." [39497,39543]
===
match
---
atom_expr [30708,30764]
atom_expr [30830,30886]
===
match
---
expr_stmt [33883,33929]
expr_stmt [34005,34051]
===
match
---
name: datetime [1033,1041]
name: datetime [1033,1041]
===
match
---
name: exit [25131,25135]
name: exit [25253,25257]
===
match
---
return_stmt [16071,16088]
return_stmt [16193,16210]
===
match
---
trailer [7277,7289]
trailer [7277,7289]
===
match
---
name: processor_timeout [12006,12023]
name: processor_timeout [12128,12145]
===
match
---
simple_stmt [1420,1442]
simple_stmt [1420,1442]
===
match
---
name: is_mtime_mode [43006,43019]
name: is_mtime_mode [43128,43141]
===
match
---
name: MultiprocessingConnection [19036,19061]
name: MultiprocessingConnection [19158,19183]
===
match
---
trailer [29633,29659]
trailer [29755,29781]
===
match
---
atom_expr [15033,15050]
atom_expr [15155,15172]
===
match
---
trailer [47178,47189]
trailer [47300,47311]
===
match
---
name: self [14673,14677]
name: self [14795,14799]
===
match
---
atom_expr [29605,29659]
atom_expr [29727,29781]
===
match
---
trailer [43460,43476]
trailer [43582,43598]
===
match
---
name: file_paths_to_exclude [43660,43681]
name: file_paths_to_exclude [43782,43803]
===
match
---
operator: - [31165,31166]
operator: - [31287,31288]
===
match
---
name: append [34077,34083]
name: append [34199,34205]
===
match
---
suite [47512,47883]
suite [47634,48005]
===
match
---
name: pickle_dags [19480,19491]
name: pickle_dags [19602,19613]
===
match
---
testlist_comp [35339,35379]
testlist_comp [35461,35501]
===
match
---
name: _last_parsing_stat_received_at [8112,8142]
name: _last_parsing_stat_received_at [8112,8142]
===
match
---
name: _process [14828,14836]
name: _process [14950,14958]
===
match
---
trailer [35358,35370]
trailer [35480,35492]
===
match
---
suite [29966,30987]
suite [30088,31109]
===
match
---
name: self [30245,30249]
name: self [30367,30371]
===
match
---
operator: = [33363,33364]
operator: = [33485,33486]
===
match
---
name: get_run_count [37484,37497]
name: get_run_count [37606,37619]
===
match
---
atom_expr [14519,14541]
atom_expr [14641,14663]
===
match
---
operator: , [1243,1244]
operator: , [1243,1244]
===
match
---
name: send_sla_callback_request_to_execute [10356,10392]
name: send_sla_callback_request_to_execute [10356,10392]
===
match
---
name: values [48952,48958]
name: values [49074,49080]
===
match
---
name: multiprocessing [1110,1125]
name: multiprocessing [1110,1125]
===
match
---
name: self [8914,8918]
name: self [8914,8918]
===
match
---
decorator [3410,3426]
decorator [3410,3426]
===
match
---
trailer [19192,19194]
trailer [19314,19316]
===
match
---
atom [32752,32754]
atom [32874,32876]
===
match
---
name: _dag_directory [8361,8375]
name: _dag_directory [8361,8375]
===
match
---
atom_expr [40549,40565]
atom_expr [40671,40687]
===
match
---
tfpdef [12006,12034]
tfpdef [12128,12156]
===
match
---
and_test [20127,20201]
and_test [20249,20323]
===
match
---
suite [28514,28691]
suite [28636,28813]
===
match
---
import_from [952,991]
import_from [952,991]
===
match
---
atom_expr [30844,30863]
atom_expr [30966,30985]
===
match
---
tfpdef [11855,11873]
tfpdef [11977,11995]
===
match
---
expr_stmt [7548,7572]
expr_stmt [7548,7572]
===
match
---
name: log [45373,45376]
name: log [45495,45498]
===
match
---
exprlist [46807,46827]
exprlist [46929,46949]
===
match
---
operator: = [48290,48291]
operator: = [48412,48413]
===
match
---
expr_stmt [21801,21844]
expr_stmt [21923,21966]
===
match
---
name: self [23793,23797]
name: self [23915,23919]
===
match
---
name: self [11413,11417]
name: self [11531,11535]
===
match
---
funcdef [22742,23216]
funcdef [22864,23338]
===
match
---
suite [41735,44832]
suite [41857,44954]
===
match
---
arglist [20148,20174]
arglist [20270,20296]
===
match
---
name: file_name [33668,33677]
name: file_name [33790,33799]
===
match
---
operator: > [40851,40852]
operator: > [40973,40974]
===
match
---
name: self [48142,48146]
name: self [48264,48268]
===
match
---
atom_expr [19460,19477]
atom_expr [19582,19599]
===
match
---
name: processor [41552,41561]
name: processor [41674,41683]
===
match
---
name: log [23005,23008]
name: log [23127,23130]
===
match
---
name: info [28540,28544]
name: info [28662,28666]
===
match
---
name: extend [44803,44809]
name: extend [44925,44931]
===
match
---
name: waitables [40327,40336]
name: waitables [40449,40458]
===
match
---
annassign [7485,7539]
annassign [7485,7539]
===
match
---
name: LoggingMixin [17281,17293]
name: LoggingMixin [17403,17415]
===
match
---
trailer [29626,29633]
trailer [29748,29755]
===
match
---
name: stat [36972,36976]
name: stat [37094,37098]
===
match
---
fstring [33636,33679]
fstring [33758,33801]
===
match
---
operator: -> [3445,3447]
operator: -> [3445,3447]
===
match
---
name: file_path [37767,37776]
name: file_path [37889,37898]
===
match
---
arith_expr [15213,15267]
arith_expr [15335,15389]
===
match
---
name: settings [13188,13196]
name: settings [13310,13318]
===
match
---
trailer [45110,45134]
trailer [45232,45256]
===
match
---
import_as_names [968,991]
import_as_names [968,991]
===
match
---
name: os [23206,23208]
name: os [23328,23330]
===
match
---
comparison [46922,46956]
comparison [47044,47078]
===
match
---
dotted_name [30886,30908]
dotted_name [31008,31030]
===
match
---
trailer [40572,40585]
trailer [40694,40707]
===
match
---
simple_stmt [30476,30557]
simple_stmt [30598,30679]
===
match
---
operator: { [38321,38322]
operator: { [38443,38444]
===
match
---
trailer [29458,29475]
trailer [29580,29597]
===
match
---
atom_expr [2546,2567]
atom_expr [2546,2567]
===
match
---
trailer [13922,13927]
trailer [14044,14049]
===
match
---
name: timedelta [19004,19013]
name: timedelta [19126,19135]
===
match
---
operator: = [21250,21251]
operator: = [21372,21373]
===
match
---
param [37042,37051]
param [37164,37173]
===
match
---
param [15728,15733]
param [15850,15855]
===
match
---
operator: -> [16005,16007]
operator: -> [16127,16129]
===
match
---
operator: = [15211,15212]
operator: = [15333,15334]
===
match
---
operator: , [18975,18976]
operator: , [19097,19098]
===
match
---
name: loop_start_time [24507,24522]
name: loop_start_time [24629,24644]
===
match
---
trailer [26431,26441]
trailer [26553,26563]
===
match
---
trailer [29568,29582]
trailer [29690,29704]
===
match
---
atom_expr [23943,23967]
atom_expr [24065,24089]
===
match
---
simple_stmt [37524,37731]
simple_stmt [37646,37853]
===
match
---
trailer [17220,17240]
trailer [17342,17362]
===
match
---
operator: == [43623,43625]
operator: == [43745,43747]
===
match
---
operator: -> [2470,2472]
operator: -> [2470,2472]
===
match
---
name: sorted [33890,33896]
name: sorted [34012,34018]
===
match
---
decorator [4229,4239]
decorator [4229,4239]
===
match
---
name: file_path [35137,35146]
name: file_path [35259,35268]
===
match
---
name: _processor_factory [41209,41227]
name: _processor_factory [41331,41349]
===
match
---
trailer [14009,14014]
trailer [14131,14136]
===
match
---
expr_stmt [41642,41695]
expr_stmt [41764,41817]
===
match
---
sync_comp_for [43557,43640]
sync_comp_for [43679,43762]
===
match
---
param [22777,22782]
param [22899,22904]
===
match
---
name: _callback_to_execute [22082,22102]
name: _callback_to_execute [22204,22224]
===
match
---
name: self [48650,48654]
name: self [48772,48776]
===
match
---
trailer [15968,15970]
trailer [16090,16092]
===
match
---
name: self [32973,32977]
name: self [33095,33099]
===
match
---
name: MultiprocessingStartMethodMixin [1997,2028]
name: MultiprocessingStartMethodMixin [1997,2028]
===
match
---
name: or_ [1385,1388]
name: or_ [1385,1388]
===
match
---
suite [31427,31858]
suite [31549,31980]
===
match
---
name: known_file_paths [32812,32828]
name: known_file_paths [32934,32950]
===
match
---
name: self [19334,19338]
name: self [19456,19460]
===
match
---
name: AbstractDagFileProcessorProcess [21189,21220]
name: AbstractDagFileProcessorProcess [21311,21342]
===
match
---
trailer [38382,38384]
trailer [38504,38506]
===
match
---
return_stmt [37786,37822]
return_stmt [37908,37944]
===
match
---
name: info [22932,22936]
name: info [23054,23058]
===
match
---
suite [31226,31293]
suite [31348,31415]
===
match
---
name: Optional [1257,1265]
name: Optional [1257,1265]
===
match
---
trailer [46127,46131]
trailer [46249,46253]
===
match
---
while_stmt [40803,41696]
while_stmt [40925,41818]
===
match
---
name: List [6991,6995]
name: List [6991,6995]
===
match
---
atom_expr [36559,36577]
atom_expr [36681,36699]
===
match
---
param [36626,36631]
param [36748,36753]
===
match
---
trailer [33124,33137]
trailer [33246,33259]
===
match
---
number: 0 [44752,44753]
number: 0 [44874,44875]
===
match
---
not_test [38930,38948]
not_test [39052,39070]
===
match
---
name: file_path [42386,42395]
name: file_path [42508,42517]
===
match
---
parameters [2787,2793]
parameters [2787,2793]
===
match
---
atom_expr [20401,20418]
atom_expr [20523,20540]
===
match
---
atom_expr [21537,21562]
atom_expr [21659,21684]
===
match
---
comp_if [29545,29582]
comp_if [29667,29704]
===
match
---
operator: = [40115,40116]
operator: = [40237,40238]
===
match
---
trailer [30249,30253]
trailer [30371,30375]
===
match
---
name: error [39352,39357]
name: error [39474,39479]
===
match
---
number: 0 [39538,39539]
number: 0 [39660,39661]
===
match
---
for_stmt [46803,47480]
for_stmt [46925,47602]
===
match
---
operator: , [46816,46817]
operator: , [46938,46939]
===
match
---
suite [9790,10347]
suite [9790,10347]
===
match
---
name: processor [44333,44342]
name: processor [44455,44464]
===
match
---
operator: , [12034,12035]
operator: , [12156,12157]
===
match
---
simple_stmt [19203,19236]
simple_stmt [19325,19358]
===
match
---
operator: = [19277,19278]
operator: = [19399,19400]
===
match
---
trailer [37766,37777]
trailer [37888,37899]
===
match
---
param [31412,31417]
param [31534,31539]
===
match
---
atom_expr [13043,13111]
atom_expr [13165,13233]
===
match
---
name: store_dag_code [30849,30863]
name: store_dag_code [30971,30985]
===
match
---
trailer [35147,35151]
trailer [35269,35273]
===
match
---
atom_expr [4415,4436]
atom_expr [4415,4436]
===
match
---
simple_stmt [38966,38982]
simple_stmt [39088,39104]
===
match
---
name: self [47605,47609]
name: self [47727,47731]
===
match
---
trailer [31655,31667]
trailer [31777,31789]
===
match
---
decorator [49017,49027]
decorator [49139,49149]
===
match
---
string: "\n" [34513,34517]
string: "\n" [34635,34639]
===
match
---
trailer [44363,44365]
trailer [44485,44487]
===
match
---
name: self [10112,10116]
name: self [10112,10116]
===
match
---
simple_stmt [31023,31105]
simple_stmt [31145,31227]
===
match
---
name: id [45807,45809]
name: id [45929,45931]
===
match
---
operator: @ [3396,3397]
operator: @ [3396,3397]
===
match
---
trailer [42510,42521]
trailer [42632,42643]
===
match
---
simple_stmt [22923,22992]
simple_stmt [23045,23114]
===
match
---
trailer [48033,48040]
trailer [48155,48162]
===
match
---
name: str [7035,7038]
name: str [7035,7038]
===
match
---
trailer [46835,46847]
trailer [46957,46969]
===
match
---
string: """         Terminate (and then kill) the manager process launched.         :return:         """ [16722,16818]
string: """         Terminate (and then kill) the manager process launched.         :return:         """ [16844,16940]
===
match
---
name: AbstractDagFileProcessorProcess [40251,40282]
name: AbstractDagFileProcessorProcess [40373,40404]
===
match
---
name: DagModel [30777,30785]
name: DagModel [30899,30907]
===
match
---
name: time [38966,38970]
name: time [39088,39092]
===
match
---
name: len [40545,40548]
name: len [40667,40670]
===
match
---
name: enum [5013,5017]
name: enum [5013,5017]
===
match
---
name: logger [15662,15668]
name: logger [15784,15790]
===
match
---
return_stmt [47871,47882]
return_stmt [47993,48004]
===
match
---
name: abstractmethod [4457,4471]
name: abstractmethod [4457,4471]
===
match
---
atom_expr [21371,21399]
atom_expr [21493,21521]
===
match
---
name: full_filepath [29569,29582]
name: full_filepath [29691,29704]
===
match
---
name: processor [41657,41666]
name: processor [41779,41788]
===
match
---
name: self [23756,23760]
name: self [23878,23882]
===
match
---
name: file_name [33103,33112]
name: file_name [33225,33234]
===
match
---
name: Process [8258,8265]
name: Process [8258,8265]
===
match
---
name: self [40568,40572]
name: self [40690,40694]
===
match
---
trailer [30648,30658]
trailer [30770,30780]
===
match
---
atom_expr [24232,24262]
atom_expr [24354,24384]
===
match
---
trailer [8700,8712]
trailer [8700,8712]
===
match
---
name: debug [40605,40610]
name: debug [40727,40732]
===
match
---
name: str [18914,18917]
name: str [19036,19039]
===
match
---
trailer [48061,48066]
trailer [48183,48188]
===
match
---
operator: , [13346,13347]
operator: , [13468,13469]
===
match
---
name: CallbackRequest [25341,25356]
name: CallbackRequest [25463,25478]
===
match
---
test [35759,35795]
test [35881,35917]
===
match
---
funcdef [40683,41696]
funcdef [40805,41818]
===
match
---
name: BaseProcess [7520,7531]
name: BaseProcess [7520,7531]
===
match
---
not_test [26778,26803]
not_test [26900,26925]
===
match
---
name: file_path [29496,29505]
name: file_path [29618,29627]
===
match
---
trailer [41409,41437]
trailer [41531,41559]
===
match
---
operator: , [14256,14257]
operator: , [14378,14379]
===
match
---
name: environ [13225,13232]
name: environ [13347,13354]
===
match
---
name: _process [17177,17185]
name: _process [17299,17307]
===
match
---
atom_expr [23090,23106]
atom_expr [23212,23228]
===
match
---
atom_expr [31680,31696]
atom_expr [31802,31818]
===
match
---
name: Stats [47405,47410]
name: Stats [47527,47532]
===
match
---
name: self [13723,13727]
name: self [13845,13849]
===
match
---
trailer [23200,23205]
trailer [23322,23327]
===
match
---
string: "Process not started." [9347,9369]
string: "Process not started." [9347,9369]
===
match
---
name: TERMINATE_MANAGER [24927,24944]
name: TERMINATE_MANAGER [25049,25066]
===
match
---
name: signal_conn [12044,12055]
name: signal_conn [12166,12177]
===
match
---
name: exit [23201,23205]
name: exit [23323,23327]
===
match
---
trailer [39065,39071]
trailer [39187,39193]
===
match
---
atom_expr [45546,45563]
atom_expr [45668,45685]
===
match
---
name: loop_duration [28866,28879]
name: loop_duration [28988,29001]
===
match
---
number: 3 [33919,33920]
number: 3 [34041,34042]
===
match
---
suite [16554,16637]
suite [16676,16759]
===
match
---
dotted_name [1912,1943]
dotted_name [1912,1943]
===
match
---
name: warning [14908,14915]
name: warning [15030,15037]
===
match
---
atom [42274,42276]
atom [42396,42398]
===
match
---
simple_stmt [1645,1689]
simple_stmt [1645,1689]
===
match
---
name: State [2243,2248]
name: State [2243,2248]
===
match
---
tfpdef [6881,6898]
tfpdef [6881,6898]
===
match
---
operator: , [23061,23062]
operator: , [23183,23184]
===
match
---
simple_stmt [3363,3391]
simple_stmt [3363,3391]
===
match
---
operator: , [17189,17190]
operator: , [17311,17312]
===
match
---
name: int [19605,19608]
name: int [19727,19730]
===
match
---
trailer [43717,43796]
trailer [43839,43918]
===
match
---
name: import_module [13043,13056]
name: import_module [13165,13178]
===
match
---
operator: = [5124,5125]
operator: = [5124,5125]
===
match
---
name: last_finish_time [42657,42673]
name: last_finish_time [42779,42795]
===
match
---
trailer [43612,43622]
trailer [43734,43744]
===
match
---
string: "\n" [34555,34559]
string: "\n" [34677,34681]
===
match
---
trailer [24279,24291]
trailer [24401,24413]
===
match
---
operator: -> [10432,10434]
operator: -> [10432,10434]
===
match
---
trailer [45633,45638]
trailer [45755,45760]
===
match
---
trailer [47242,47247]
trailer [47364,47369]
===
match
---
name: DagFileStat [21344,21355]
name: DagFileStat [21466,21477]
===
match
---
trailer [45575,45612]
trailer [45697,45734]
===
match
---
decorator [3679,3695]
decorator [3679,3695]
===
match
---
atom_expr [24607,24680]
atom_expr [24729,24802]
===
match
---
name: self [23594,23598]
name: self [23716,23720]
===
match
---
trailer [46039,46056]
trailer [46161,46178]
===
match
---
suite [10099,10151]
suite [10099,10151]
===
match
---
argument [40108,40117]
argument [40230,40239]
===
match
---
name: last_duration [4938,4951]
name: last_duration [4938,4951]
===
match
---
name: self [2976,2980]
name: self [2976,2980]
===
match
---
trailer [20143,20147]
trailer [20265,20269]
===
match
---
operator: , [22291,22292]
operator: , [22413,22414]
===
match
---
name: items [43597,43602]
name: items [43719,43724]
===
match
---
operator: , [18801,18802]
operator: , [18923,18924]
===
match
---
param [35194,35198]
param [35316,35320]
===
match
---
operator: = [19478,19479]
operator: = [19600,19601]
===
match
---
name: self [20006,20010]
name: self [20128,20132]
===
match
---
name: self [40654,40658]
name: self [40776,40780]
===
match
---
simple_stmt [21801,21845]
simple_stmt [21923,21967]
===
match
---
atom_expr [27751,27774]
atom_expr [27873,27896]
===
match
---
simple_stmt [3983,4011]
simple_stmt [3983,4011]
===
match
---
trailer [32917,32936]
trailer [33039,33058]
===
match
---
trailer [46792,46794]
trailer [46914,46916]
===
match
---
atom_expr [17153,17207]
atom_expr [17275,17329]
===
match
---
name: Optional [19596,19604]
name: Optional [19718,19726]
===
match
---
arglist [30259,30329]
arglist [30381,30451]
===
match
---
expr_stmt [36105,36143]
expr_stmt [36227,36265]
===
match
---
simple_stmt [42285,42330]
simple_stmt [42407,42452]
===
match
---
name: Optional [4953,4961]
name: Optional [4953,4961]
===
match
---
trailer [20921,20944]
trailer [21043,21066]
===
match
---
if_stmt [40163,40222]
if_stmt [40285,40344]
===
match
---
atom_expr [45998,46011]
atom_expr [46120,46133]
===
match
---
trailer [26656,26658]
trailer [26778,26780]
===
match
---
trailer [29797,29804]
trailer [29919,29926]
===
match
---
operator: , [1221,1222]
operator: , [1221,1222]
===
match
---
operator: , [28634,28635]
operator: , [28756,28757]
===
match
---
name: self [8509,8513]
name: self [8509,8513]
===
match
---
name: self [8554,8558]
name: self [8554,8558]
===
match
---
atom_expr [45735,46133]
atom_expr [45857,46255]
===
match
---
suite [17343,49085]
suite [17465,49207]
===
match
---
name: process [7512,7519]
name: process [7512,7519]
===
match
---
name: utcnow [46201,46207]
name: utcnow [46323,46329]
===
match
---
name: bool [6894,6898]
name: bool [6894,6898]
===
match
---
name: time [15954,15958]
name: time [16076,16080]
===
match
---
funcdef [22396,22737]
funcdef [22518,22859]
===
match
---
operator: = [33455,33456]
operator: = [33577,33578]
===
match
---
operator: , [48728,48729]
operator: , [48850,48851]
===
match
---
operator: , [34030,34031]
operator: , [34152,34153]
===
match
---
atom_expr [15691,15703]
atom_expr [15813,15825]
===
match
---
name: _callback_to_execute [41355,41375]
name: _callback_to_execute [41477,41497]
===
match
---
simple_stmt [20050,20116]
simple_stmt [20172,20238]
===
match
---
name: _parallelism [20406,20418]
name: _parallelism [20528,20540]
===
match
---
name: _parsing_start_time [19575,19594]
name: _parsing_start_time [19697,19716]
===
match
---
trailer [22366,22379]
trailer [22488,22501]
===
match
---
suite [25075,25146]
suite [25197,25268]
===
match
---
arglist [40063,40117]
arglist [40185,40239]
===
match
---
name: AbstractDagFileProcessorProcess [2295,2326]
name: AbstractDagFileProcessorProcess [2295,2326]
===
match
---
trailer [25199,25214]
trailer [25321,25336]
===
match
---
trailer [31274,31292]
trailer [31396,31414]
===
match
---
name: _pickle_dags [41306,41318]
name: _pickle_dags [41428,41440]
===
match
---
number: 0 [23579,23580]
number: 0 [23701,23702]
===
match
---
expr_stmt [21316,21361]
expr_stmt [21438,21483]
===
match
---
trailer [23695,23699]
trailer [23817,23821]
===
match
---
simple_stmt [42162,42222]
simple_stmt [42284,42344]
===
match
---
trailer [40350,40366]
trailer [40472,40488]
===
match
---
trailer [30658,30694]
trailer [30780,30816]
===
match
---
trailer [46003,46011]
trailer [46125,46133]
===
match
---
param [3160,3164]
param [3160,3164]
===
match
---
name: self [38523,38527]
name: self [38645,38649]
===
match
---
name: start_time [47179,47189]
name: start_time [47301,47311]
===
match
---
string: "Exiting gracefully upon receiving signal %s" [22937,22982]
string: "Exiting gracefully upon receiving signal %s" [23059,23104]
===
match
---
name: processor [40341,40350]
name: processor [40463,40472]
===
match
---
arglist [10832,10874]
arglist [10832,10874]
===
match
---
name: DagParsingStat [11572,11586]
name: DagParsingStat [11691,11705]
===
match
---
trailer [45902,45910]
trailer [46024,46032]
===
match
---
name: fromtimestamp [21546,21559]
name: fromtimestamp [21668,21681]
===
match
---
param [14573,14577]
param [14695,14699]
===
match
---
arglist [30063,30111]
arglist [30185,30233]
===
match
---
name: run_count [43613,43622]
name: run_count [43735,43744]
===
match
---
trailer [15217,15227]
trailer [15339,15349]
===
match
---
atom_expr [14899,15113]
atom_expr [15021,15235]
===
match
---
trailer [8149,8159]
trailer [8149,8159]
===
match
---
name: file_path [33246,33255]
name: file_path [33368,33377]
===
match
---
testlist_comp [11935,11961]
testlist_comp [12057,12083]
===
match
---
dotted_name [2034,2051]
dotted_name [2034,2051]
===
match
---
trailer [34189,34203]
trailer [34311,34325]
===
match
---
name: job_id [45794,45800]
name: job_id [45916,45922]
===
match
---
trailer [16465,16467]
trailer [16587,16589]
===
match
---
or_test [45102,45232]
or_test [45224,45354]
===
match
---
atom_expr [38107,38123]
atom_expr [38229,38245]
===
match
---
import_name [891,900]
import_name [891,900]
===
match
---
name: _parallelism [20055,20067]
name: _parallelism [20177,20189]
===
match
---
name: getint [20075,20081]
name: getint [20197,20203]
===
match
---
name: processor [39029,39038]
name: processor [39151,39160]
===
match
---
name: stat [43608,43612]
name: stat [43730,43734]
===
match
---
operator: , [27954,27955]
operator: , [28076,28077]
===
match
---
operator: = [7173,7174]
operator: = [7173,7174]
===
match
---
name: _zombie_threshold_secs [45589,45611]
name: _zombie_threshold_secs [45711,45733]
===
match
---
string: "%Y-%m-%dT%H:%M:%S" [34405,34424]
string: "%Y-%m-%dT%H:%M:%S" [34527,34546]
===
match
---
name: Random [43454,43460]
name: Random [43576,43582]
===
match
---
funcdef [16244,16694]
funcdef [16366,16816]
===
match
---
name: _file_stats [44612,44623]
name: _file_stats [44734,44745]
===
match
---
string: """Check if the DagFileProcessorManager process is alive, and process any pending messages""" [13614,13707]
string: """Check if the DagFileProcessorManager process is alive, and process any pending messages""" [13736,13829]
===
match
---
trailer [15046,15050]
trailer [15168,15172]
===
match
---
for_stmt [44502,44772]
for_stmt [44624,44894]
===
match
---
operator: = [15835,15836]
operator: = [15957,15958]
===
match
---
name: self [47822,47826]
name: self [47944,47948]
===
match
---
name: last_run [33464,33472]
name: last_run [33586,33594]
===
match
---
operator: , [33749,33750]
operator: , [33871,33872]
===
match
---
trailer [45884,45911]
trailer [46006,46033]
===
match
---
operator: = [33165,33166]
operator: = [33287,33288]
===
match
---
trailer [16575,16595]
trailer [16697,16717]
===
match
---
trailer [33487,33489]
trailer [33609,33611]
===
match
---
operator: , [33679,33680]
operator: , [33801,33802]
===
match
---
name: async_mode [7292,7302]
name: async_mode [7292,7302]
===
match
---
name: request [9756,9763]
name: request [9756,9763]
===
match
---
if_stmt [42430,42585]
if_stmt [42552,42707]
===
match
---
trailer [46165,46189]
trailer [46287,46311]
===
match
---
atom_expr [10813,10875]
atom_expr [10813,10875]
===
match
---
name: poll_time [28850,28859]
name: poll_time [28972,28981]
===
match
---
atom_expr [46192,46209]
atom_expr [46314,46331]
===
match
---
operator: = [7290,7291]
operator: = [7290,7291]
===
match
---
name: _processors [26463,26474]
name: _processors [26585,26596]
===
match
---
name: EOFError [11464,11472]
name: EOFError [11582,11590]
===
match
---
suite [37053,37475]
suite [37175,37597]
===
match
---
operator: , [43095,43096]
operator: , [43217,43218]
===
match
---
trailer [12434,12482]
trailer [12556,12604]
===
match
---
name: process_utils [2091,2104]
name: process_utils [2091,2104]
===
match
---
atom_expr [30343,30380]
atom_expr [30465,30502]
===
match
---
funcdef [7850,8881]
funcdef [7850,8881]
===
match
---
name: timezone [46777,46785]
name: timezone [46899,46907]
===
match
---
name: timedelta [1059,1068]
name: timedelta [1059,1068]
===
match
---
operator: = [14849,14850]
operator: = [14971,14972]
===
match
---
trailer [10012,10032]
trailer [10012,10032]
===
match
---
name: sys [936,939]
name: sys [936,939]
===
match
---
suite [38949,38982]
suite [39071,39104]
===
match
---
trailer [20005,20040]
trailer [20127,20162]
===
match
---
param [16258,16262]
param [16380,16384]
===
match
---
for_stmt [38868,38982]
for_stmt [38990,39104]
===
match
---
name: _file_paths [31685,31696]
name: _file_paths [31807,31818]
===
match
---
name: x [38174,38175]
name: x [38296,38297]
===
match
---
name: _processor_factory [19373,19391]
name: _processor_factory [19495,19513]
===
match
---
name: stat [48799,48803]
name: stat [48921,48925]
===
match
---
name: processor_manager [13546,13563]
name: processor_manager [13668,13685]
===
match
---
atom_expr [39720,39777]
atom_expr [39842,39899]
===
match
---
param [2613,2634]
param [2613,2634]
===
match
---
if_stmt [29149,29597]
if_stmt [29271,29719]
===
match
---
name: self [38107,38111]
name: self [38229,38233]
===
match
---
trailer [46296,46470]
trailer [46418,46592]
===
match
---
atom [21359,21361]
atom [21481,21483]
===
match
---
sync_comp_for [27694,27718]
sync_comp_for [27816,27840]
===
match
---
name: elapsed_time_since_refresh [29815,29841]
name: elapsed_time_since_refresh [29937,29963]
===
match
---
param [11883,11897]
param [12005,12019]
===
match
---
name: rsplit [13093,13099]
name: rsplit [13215,13221]
===
match
---
operator: = [32767,32768]
operator: = [32889,32890]
===
match
---
atom_expr [22343,22360]
atom_expr [22465,22482]
===
match
---
name: args [8333,8337]
name: args [8333,8337]
===
match
---
parameters [37035,37052]
parameters [37157,37174]
===
match
---
operator: , [9754,9755]
operator: , [9754,9755]
===
match
---
operator: -> [3166,3168]
operator: -> [3166,3168]
===
match
---
name: log [15412,15415]
name: log [15534,15537]
===
match
---
suite [22428,22737]
suite [22550,22859]
===
match
---
name: processor [41192,41201]
name: processor [41314,41323]
===
match
---
simple_stmt [9799,9993]
simple_stmt [9799,9993]
===
match
---
argument [45576,45611]
argument [45698,45733]
===
match
---
string: '.' [13100,13103]
string: '.' [13222,13225]
===
match
---
name: bool [7560,7564]
name: bool [7560,7564]
===
match
---
trailer [8069,8081]
trailer [8069,8081]
===
match
---
testlist_comp [38174,38229]
testlist_comp [38296,38351]
===
match
---
suite [9551,9716]
suite [9551,9716]
===
match
---
trailer [12804,12839]
trailer [12926,12961]
===
match
---
name: _processors [7362,7373]
name: _processors [7362,7373]
===
match
---
arglist [33636,33688]
arglist [33758,33810]
===
match
---
trailer [11512,11529]
trailer [11631,11648]
===
match
---
operator: , [46451,46452]
operator: , [46573,46574]
===
match
---
operator: -> [2794,2796]
operator: -> [2794,2796]
===
match
---
name: insert [29627,29633]
name: insert [29749,29755]
===
match
---
trailer [30419,30423]
trailer [30541,30545]
===
match
---
atom_expr [40650,40676]
atom_expr [40772,40798]
===
match
---
operator: = [21090,21091]
operator: = [21212,21213]
===
match
---
name: stat [36559,36563]
name: stat [36681,36685]
===
match
---
name: processor [47134,47143]
name: processor [47256,47265]
===
match
---
atom_expr [14099,14128]
atom_expr [14221,14250]
===
match
---
suite [11166,11796]
suite [11166,11918]
===
match
---
name: _sync_metadata [15713,15727]
name: _sync_metadata [15835,15849]
===
match
---
name: defaultdict [22139,22150]
name: defaultdict [22261,22272]
===
match
---
trailer [48830,48832]
trailer [48952,48954]
===
match
---
name: signal [22494,22500]
name: signal [22616,22622]
===
match
---
trailer [25138,25144]
trailer [25260,25266]
===
match
---
name: _refresh_dag_dir [29669,29685]
name: _refresh_dag_dir [29791,29807]
===
match
---
operator: , [15596,15597]
operator: , [15718,15719]
===
match
---
name: _dag_directory [30168,30182]
name: _dag_directory [30290,30304]
===
match
---
name: self [40491,40495]
name: self [40613,40617]
===
match
---
name: self [40088,40092]
name: self [40210,40214]
===
match
---
number: 0 [12410,12411]
number: 0 [12532,12533]
===
match
---
parameters [7859,7865]
parameters [7859,7865]
===
match
---
operator: = [42077,42078]
operator: = [42199,42200]
===
match
---
name: timezone [21517,21525]
name: timezone [21639,21647]
===
match
---
operator: = [28932,28933]
operator: = [29054,29055]
===
match
---
trailer [8033,8035]
trailer [8033,8035]
===
match
---
name: ready [26125,26130]
name: ready [26247,26252]
===
match
---
name: Exception [30576,30585]
name: Exception [30698,30707]
===
match
---
suite [13959,14017]
suite [14081,14139]
===
match
---
atom_expr [6941,6959]
atom_expr [6941,6959]
===
match
---
name: self [42676,42680]
name: self [42798,42802]
===
match
---
trailer [46616,46634]
trailer [46738,46756]
===
match
---
atom_expr [21236,21249]
atom_expr [21358,21371]
===
match
---
operator: = [21637,21638]
operator: = [21759,21760]
===
match
---
trailer [13064,13073]
trailer [13186,13195]
===
match
---
name: self [22763,22767]
name: self [22885,22889]
===
match
---
name: dag_directory [19312,19325]
name: dag_directory [19434,19447]
===
match
---
expr_stmt [19570,19616]
expr_stmt [19692,19738]
===
match
---
if_stmt [29907,30987]
if_stmt [30029,31109]
===
match
---
trailer [30362,30380]
trailer [30484,30502]
===
match
---
expr_stmt [10803,10875]
expr_stmt [10803,10875]
===
match
---
parameters [4276,4282]
parameters [4276,4282]
===
match
---
name: last_runtime [34320,34332]
name: last_runtime [34442,34454]
===
match
---
atom_expr [7063,7077]
atom_expr [7063,7077]
===
match
---
atom_expr [9386,9410]
atom_expr [9386,9410]
===
match
---
suite [25358,25421]
suite [25480,25543]
===
match
---
operator: = [39554,39555]
operator: = [39676,39677]
===
match
---
name: self [39934,39938]
name: self [40056,40060]
===
match
---
atom_expr [48807,48832]
atom_expr [48929,48954]
===
match
---
raise_stmt [2901,2928]
raise_stmt [2901,2928]
===
match
---
simple_stmt [34489,34714]
simple_stmt [34611,34836]
===
match
---
expr_stmt [6968,7005]
expr_stmt [6968,7005]
===
match
---
atom_expr [7233,7250]
atom_expr [7233,7250]
===
match
---
suite [48336,48392]
suite [48458,48514]
===
match
---
name: taskinstance [1606,1618]
name: taskinstance [1606,1618]
===
match
---
atom_expr [36112,36143]
atom_expr [36234,36265]
===
match
---
operator: = [22176,22177]
operator: = [22298,22299]
===
match
---
trailer [15302,15321]
trailer [15424,15443]
===
match
---
trailer [22500,22507]
trailer [22622,22629]
===
match
---
atom_expr [35339,35344]
atom_expr [35461,35466]
===
match
---
for_stmt [42382,42945]
for_stmt [42504,43067]
===
match
---
expr_stmt [43506,43650]
expr_stmt [43628,43772]
===
match
---
fstring [14480,14543]
fstring [14602,14665]
===
match
---
name: loop_start_time [28776,28791]
name: loop_start_time [28898,28913]
===
match
---
operator: = [21515,21516]
operator: = [21637,21638]
===
match
---
name: processor_factory [11906,11923]
name: processor_factory [12028,12045]
===
match
---
arith_expr [42796,42818]
arith_expr [42918,42940]
===
match
---
name: stat [36918,36922]
name: stat [37040,37044]
===
match
---
string: "%s/%s DAG parsing processes running" [40506,40543]
string: "%s/%s DAG parsing processes running" [40628,40665]
===
match
---
atom_expr [45059,45076]
atom_expr [45181,45198]
===
match
---
name: store_dag_code [21075,21089]
name: store_dag_code [21197,21211]
===
match
---
name: self [30363,30367]
name: self [30485,30489]
===
match
---
if_stmt [38398,38721]
if_stmt [38520,38843]
===
match
---
name: processor [39820,39829]
name: processor [39942,39951]
===
match
---
expr_stmt [45447,45479]
expr_stmt [45569,45601]
===
match
---
trailer [4961,4968]
trailer [4961,4968]
===
match
---
name: send [10913,10917]
name: send [10913,10917]
===
match
---
trailer [20951,20958]
trailer [21073,21080]
===
match
---
name: now [30229,30232]
name: now [30351,30354]
===
match
---
trailer [15037,15046]
trailer [15159,15168]
===
match
---
operator: = [27749,27750]
operator: = [27871,27872]
===
match
---
trailer [46937,46956]
trailer [47059,47078]
===
match
---
trailer [17117,17126]
trailer [17239,17248]
===
match
---
atom_expr [46974,47220]
atom_expr [47096,47342]
===
match
---
name: dag_ids [6843,6850]
name: dag_ids [6843,6850]
===
match
---
suite [2989,3107]
suite [2989,3107]
===
match
---
trailer [41646,41656]
trailer [41768,41778]
===
match
---
operator: , [8712,8713]
operator: , [8712,8713]
===
match
---
simple_stmt [36152,36191]
simple_stmt [36274,36313]
===
match
---
string: """     Given a list of DAG definition files, this kicks off several processors     in parallel to process them and put the results to a multiprocessing.Queue     for DagFileProcessorAgent to harvest. The parallelism is limited and as the     processors finish, more are launched. The files are processed over and     over again, but no more often than the specified interval.      :param dag_directory: Directory where DAG definitions are kept. All         files in file_paths should be under this directory     :type dag_directory: unicode     :param max_runs: The number of times to parse and schedule each file. -1         for unlimited.     :type max_runs: int     :param processor_factory: function that creates processors for DAG         definition files. Arguments are (dag_definition_path)     :type processor_factory: (unicode, unicode, list) -> (AbstractDagFileProcessorProcess)     :param processor_timeout: How long to wait before timing out a DAG file processor     :type processor_timeout: timedelta     :param signal_conn: connection to communicate signal with processor agent.     :type signal_conn: MultiprocessingConnection     :param dag_ids: if specified, only schedule tasks with these DAG IDs     :type dag_ids: list[str]     :param pickle_dags: whether to pickle DAGs.     :type pickle_dags: bool     :param async_mode: whether to start the manager in async mode     :type async_mode: bool     """ [17348,18769]
string: """     Given a list of DAG definition files, this kicks off several processors     in parallel to process them and put the results to a multiprocessing.Queue     for DagFileProcessorAgent to harvest. The parallelism is limited and as the     processors finish, more are launched. The files are processed over and     over again, but no more often than the specified interval.      :param dag_directory: Directory where DAG definitions are kept. All         files in file_paths should be under this directory     :type dag_directory: unicode     :param max_runs: The number of times to parse and schedule each file. -1         for unlimited.     :type max_runs: int     :param processor_factory: function that creates processors for DAG         definition files. Arguments are (dag_definition_path)     :type processor_factory: (unicode, unicode, list) -> (AbstractDagFileProcessorProcess)     :param processor_timeout: How long to wait before timing out a DAG file processor     :type processor_timeout: timedelta     :param signal_conn: connection to communicate signal with processor agent.     :type signal_conn: MultiprocessingConnection     :param dag_ids: if specified, only schedule tasks with these DAG IDs     :type dag_ids: list[str]     :param pickle_dags: whether to pickle DAGs.     :type pickle_dags: bool     :param async_mode: whether to start the manager in async mode     :type async_mode: bool     """ [17470,18891]
===
match
---
string: """Sleeps until all the processors are done.""" [38812,38859]
string: """Sleeps until all the processors are done.""" [38934,38981]
===
match
---
name: self [14872,14876]
name: self [14994,14998]
===
match
---
name: values [35371,35377]
name: values [35493,35499]
===
match
---
trailer [44394,44398]
trailer [44516,44520]
===
match
---
name: _process [16839,16847]
name: _process [16961,16969]
===
match
---
trailer [40863,40880]
trailer [40985,41002]
===
match
---
name: decr [38602,38606]
name: decr [38724,38728]
===
match
---
name: _callback_to_execute [41148,41168]
name: _callback_to_execute [41270,41290]
===
match
---
atom_expr [43626,43640]
atom_expr [43748,43762]
===
match
---
operator: , [32706,32707]
operator: , [32828,32829]
===
match
---
name: self [7860,7864]
name: self [7860,7864]
===
match
---
param [49046,49050]
param [49168,49172]
===
match
---
name: self [27653,27657]
name: self [27775,27779]
===
match
---
name: log [46492,46495]
name: log [46614,46617]
===
match
---
number: 1 [20200,20201]
number: 1 [20322,20323]
===
match
---
atom_expr [13723,13747]
atom_expr [13845,13869]
===
match
---
trailer [36976,36993]
trailer [37098,37115]
===
match
---
atom [40087,40106]
atom [40209,40228]
===
match
---
simple_stmt [11404,11445]
simple_stmt [11522,11563]
===
match
---
name: self [30844,30848]
name: self [30966,30970]
===
match
---
tfpdef [11906,11996]
tfpdef [12028,12118]
===
match
---
simple_stmt [26458,26500]
simple_stmt [26580,26622]
===
match
---
parameters [35823,35840]
parameters [35945,35962]
===
match
---
operator: { [33667,33668]
operator: { [33789,33790]
===
match
---
param [35407,35412]
param [35529,35534]
===
match
---
trailer [31124,31145]
trailer [31246,31267]
===
match
---
tfpdef [19109,19126]
tfpdef [19231,19248]
===
match
---
name: airflow [1591,1598]
name: airflow [1591,1598]
===
match
---
trailer [45877,45884]
trailer [45999,46006]
===
match
---
trailer [31279,31291]
trailer [31401,31413]
===
match
---
name: AbstractDagFileProcessorProcess [18943,18974]
name: AbstractDagFileProcessorProcess [19065,19096]
===
match
---
name: self [21938,21942]
name: self [22060,22064]
===
match
---
name: collections [997,1008]
name: collections [997,1008]
===
match
---
operator: { [21224,21225]
operator: { [21346,21347]
===
match
---
atom_expr [5013,5022]
atom_expr [5013,5022]
===
match
---
name: waitables [26418,26427]
name: waitables [26540,26549]
===
match
---
name: file_paths_in_progress [42016,42038]
name: file_paths_in_progress [42138,42160]
===
match
---
simple_stmt [34723,34746]
simple_stmt [34845,34868]
===
match
---
name: last_stat_print_time [31310,31330]
name: last_stat_print_time [31432,31452]
===
match
---
name: TI [45447,45449]
name: TI [45569,45571]
===
match
---
name: ready [24717,24722]
name: ready [24839,24844]
===
match
---
name: file_paths [43165,43175]
name: file_paths [43287,43297]
===
match
---
fstring_format_spec [34205,34209]
fstring_format_spec [34327,34331]
===
match
---
simple_stmt [5029,5063]
simple_stmt [5029,5063]
===
match
---
name: pid [15559,15562]
name: pid [15681,15684]
===
match
---
tfpdef [6656,6795]
tfpdef [6656,6795]
===
match
---
operator: , [8678,8679]
operator: , [8678,8679]
===
match
---
trailer [45511,45520]
trailer [45633,45642]
===
match
---
suite [10033,10087]
suite [10033,10087]
===
match
---
atom_expr [31791,31832]
atom_expr [31913,31954]
===
match
---
name: get_last_error_count [32978,32998]
name: get_last_error_count [33100,33120]
===
match
---
name: all_files_processed [4734,4753]
name: all_files_processed [4734,4753]
===
match
---
atom_expr [23044,23080]
atom_expr [23166,23202]
===
match
---
trailer [43091,43095]
trailer [43213,43217]
===
match
---
simple_stmt [1481,1525]
simple_stmt [1481,1525]
===
match
---
name: time [31148,31152]
name: time [31270,31274]
===
match
---
simple_stmt [38729,38768]
simple_stmt [38851,38890]
===
match
---
operator: , [44720,44721]
operator: , [44842,44843]
===
match
---
name: timedelta [6824,6833]
name: timedelta [6824,6833]
===
match
---
funcdef [14550,15704]
funcdef [14672,15826]
===
match
---
trailer [40600,40604]
trailer [40722,40726]
===
match
---
name: ti [46226,46228]
name: ti [46348,46350]
===
match
---
name: setproctitle [12422,12434]
name: setproctitle [12544,12556]
===
match
---
trailer [8875,8879]
trailer [8875,8879]
===
match
---
atom_expr [2732,2753]
atom_expr [2732,2753]
===
match
---
tfpdef [10399,10417]
tfpdef [10399,10417]
===
match
---
dotted_name [1530,1559]
dotted_name [1530,1559]
===
match
---
simple_stmt [21070,21107]
simple_stmt [21192,21229]
===
match
---
comparison [29152,29198]
comparison [29274,29320]
===
match
---
tfpdef [6805,6833]
tfpdef [6805,6833]
===
match
---
funcdef [2779,2929]
funcdef [2779,2929]
===
match
---
name: float [7820,7825]
name: float [7820,7825]
===
match
---
trailer [35124,35136]
trailer [35246,35258]
===
match
---
trailer [38539,38579]
trailer [38661,38701]
===
match
---
name: int [18872,18875]
name: int [18994,18997]
===
match
---
name: _signal_conn [27814,27826]
name: _signal_conn [27936,27948]
===
match
---
suite [31697,31783]
suite [31819,31905]
===
match
---
name: waitables [40068,40077]
name: waitables [40190,40199]
===
match
---
name: airflow [2216,2223]
name: airflow [2216,2223]
===
match
---
name: abstractmethod [3680,3694]
name: abstractmethod [3680,3694]
===
match
---
simple_stmt [23793,23927]
simple_stmt [23915,24049]
===
match
---
simple_stmt [21938,22017]
simple_stmt [22060,22139]
===
match
---
atom_expr [43608,43622]
atom_expr [43730,43744]
===
match
---
name: self [29939,29943]
name: self [30061,30065]
===
match
---
trailer [35732,35743]
trailer [35854,35865]
===
match
---
name: session [2180,2187]
name: session [2180,2187]
===
match
---
name: emit_metrics [48401,48413]
name: emit_metrics [48523,48535]
===
match
---
trailer [48309,48311]
trailer [48431,48433]
===
match
---
decorator [2934,2944]
decorator [2934,2944]
===
match
---
string: 'parsing_processes' [20095,20114]
string: 'parsing_processes' [20217,20236]
===
match
---
atom [42728,42879]
atom [42850,43001]
===
match
---
atom_expr [15407,15611]
atom_expr [15529,15733]
===
match
---
atom_expr [29523,29544]
atom_expr [29645,29666]
===
match
---
name: property [3666,3674]
name: property [3666,3674]
===
match
---
atom_expr [21316,21332]
atom_expr [21438,21454]
===
match
---
simple_stmt [30708,30765]
simple_stmt [30830,30887]
===
match
---
trailer [24236,24260]
trailer [24358,24382]
===
match
---
expr_stmt [32745,32754]
expr_stmt [32867,32876]
===
match
---
simple_stmt [42556,42585]
simple_stmt [42678,42707]
===
match
---
name: time [28757,28761]
name: time [28879,28883]
===
match
---
trailer [33473,33487]
trailer [33595,33609]
===
match
---
expr_stmt [42285,42329]
expr_stmt [42407,42451]
===
match
---
simple_stmt [47850,47863]
simple_stmt [47972,47985]
===
match
---
simple_stmt [15130,15143]
simple_stmt [15252,15265]
===
match
---
operator: , [11962,11963]
operator: , [12084,12085]
===
match
---
expr_stmt [21938,22016]
expr_stmt [22060,22138]
===
match
---
name: ready [25541,25546]
name: ready [25663,25668]
===
match
---
name: self [29011,29015]
name: self [29133,29137]
===
match
---
name: _exit_gracefully [22528,22544]
name: _exit_gracefully [22650,22666]
===
match
---
name: _heartbeat_manager [14205,14223]
name: _heartbeat_manager [14327,14345]
===
match
---
name: full_filepath [46318,46331]
name: full_filepath [46440,46453]
===
match
---
operator: , [44315,44316]
operator: , [44437,44438]
===
match
---
trailer [42094,42096]
trailer [42216,42218]
===
match
---
trailer [41466,41468]
trailer [41588,41590]
===
match
---
trailer [21074,21089]
trailer [21196,21211]
===
match
---
name: serialized_dag [1545,1559]
name: serialized_dag [1545,1559]
===
match
---
expr_stmt [15194,15267]
expr_stmt [15316,15389]
===
match
---
suite [35200,35381]
suite [35322,35503]
===
match
---
trailer [42819,42833]
trailer [42941,42955]
===
match
---
except_clause [10159,10181]
except_clause [10159,10181]
===
match
---
operator: , [30308,30309]
operator: , [30430,30431]
===
match
---
operator: , [2140,2141]
operator: , [2140,2141]
===
match
---
trailer [21971,21978]
trailer [22093,22100]
===
match
---
trailer [38976,38981]
trailer [39098,39103]
===
match
---
parameters [22421,22427]
parameters [22543,22549]
===
match
---
trailer [45561,45563]
trailer [45683,45685]
===
match
---
name: _signal_conn [22367,22379]
name: _signal_conn [22489,22501]
===
match
---
name: self [7705,7709]
name: self [7705,7709]
===
match
---
string: "Launched DagFileProcessorManager with pid: %s" [8819,8866]
string: "Launched DagFileProcessorManager with pid: %s" [8819,8866]
===
match
---
atom_expr [22077,22102]
atom_expr [22199,22224]
===
match
---
trailer [40298,40308]
trailer [40420,40430]
===
match
---
simple_stmt [27559,27582]
simple_stmt [27681,27704]
===
match
---
simple_stmt [41642,41696]
simple_stmt [41764,41818]
===
match
---
operator: @ [11801,11802]
operator: @ [11923,11924]
===
match
---
operator: = [21357,21358]
operator: = [21479,21480]
===
match
---
name: tabulate [1410,1418]
name: tabulate [1410,1418]
===
match
---
suite [13942,14129]
suite [14064,14251]
===
match
---
name: signal [22691,22697]
name: signal [22813,22819]
===
match
---
name: self [21801,21805]
name: self [21923,21927]
===
match
---
trailer [11944,11961]
trailer [12066,12083]
===
match
---
trailer [7495,7532]
trailer [7495,7532]
===
match
---
trailer [27069,27075]
trailer [27191,27197]
===
match
---
trailer [15920,15951]
trailer [16042,16073]
===
match
---
suite [5255,17249]
suite [5255,17371]
===
match
---
trailer [36116,36128]
trailer [36238,36250]
===
match
---
name: self [46161,46165]
name: self [46283,46287]
===
match
---
expr_stmt [7233,7264]
expr_stmt [7233,7264]
===
match
---
atom_expr [22584,22605]
atom_expr [22706,22727]
===
match
---
sync_comp_for [35345,35379]
sync_comp_for [35467,35501]
===
match
---
name: self [40178,40182]
name: self [40300,40304]
===
match
---
name: time [41860,41864]
name: time [41982,41986]
===
match
---
trailer [13989,14009]
trailer [14111,14131]
===
match
---
name: error [15416,15421]
name: error [15538,15543]
===
match
---
suite [23237,23968]
suite [23359,24090]
===
match
---
classdef [5180,17249]
classdef [5180,17371]
===
match
---
argument [43097,43109]
argument [43219,43231]
===
match
---
string: 'agent_run_once' [5085,5101]
string: 'agent_run_once' [5085,5101]
===
match
---
name: import_errors [39612,39625]
name: import_errors [39734,39747]
===
match
---
atom_expr [4915,4933]
atom_expr [4915,4933]
===
match
---
trailer [40837,40849]
trailer [40959,40971]
===
match
---
trailer [15656,15660]
trailer [15778,15782]
===
match
---
tfpdef [12157,12173]
tfpdef [12279,12295]
===
match
---
suite [9317,9371]
suite [9317,9371]
===
match
---
suite [14810,15143]
suite [14932,15265]
===
match
---
number: 1 [20466,20467]
number: 1 [20588,20589]
===
match
---
simple_stmt [4605,4633]
simple_stmt [4605,4633]
===
match
---
name: last_run [34387,34395]
name: last_run [34509,34517]
===
match
---
trailer [23008,23014]
trailer [23130,23136]
===
match
---
param [48142,48146]
param [48264,48268]
===
match
---
suite [35424,35796]
suite [35546,35918]
===
match
---
name: self [41301,41305]
name: self [41423,41427]
===
match
---
atom_expr [3085,3106]
atom_expr [3085,3106]
===
match
---
atom_expr [13137,13171]
atom_expr [13259,13293]
===
match
---
string: """         Clears import errors for files that no longer exist.          :param session: session for ORM operations         :type session: sqlalchemy.orm.session.Session         """ [31436,31618]
string: """         Clears import errors for files that no longer exist.          :param session: session for ORM operations         :type session: sqlalchemy.orm.session.Session         """ [31558,31740]
===
match
---
operator: @ [2934,2935]
operator: @ [2934,2935]
===
match
---
name: is_alive [14799,14807]
name: is_alive [14921,14929]
===
match
---
operator: = [24142,24143]
operator: = [24264,24265]
===
match
---
simple_stmt [5106,5146]
simple_stmt [5106,5146]
===
match
---
trailer [8111,8142]
trailer [8111,8142]
===
match
---
name: sentinel [26151,26159]
name: sentinel [26273,26281]
===
match
---
name: self [8393,8397]
name: self [8393,8397]
===
match
---
subscriptlist [18832,18851]
subscriptlist [18954,18973]
===
match
---
argument [11356,11368]
argument [11474,11486]
===
match
---
comp_op [39243,39249]
comp_op [39365,39371]
===
match
---
parameters [4064,4070]
parameters [4064,4070]
===
match
---
atom_expr [7995,8035]
atom_expr [7995,8035]
===
match
---
name: self [26413,26417]
name: self [26535,26539]
===
match
---
name: log [41486,41489]
name: log [41608,41611]
===
match
---
name: done [4719,4723]
name: done [4719,4723]
===
match
---
suite [30398,30557]
suite [30520,30679]
===
match
---
name: x [38180,38181]
name: x [38302,38303]
===
match
---
trailer [14907,14915]
trailer [15029,15037]
===
match
---
trailer [19207,19219]
trailer [19329,19341]
===
match
---
suite [19977,20041]
suite [20099,20163]
===
match
---
atom_expr [45885,45893]
atom_expr [46007,46015]
===
match
---
simple_stmt [36552,36596]
simple_stmt [36674,36718]
===
match
---
comparison [25030,25074]
comparison [25152,25196]
===
match
---
trailer [46785,46792]
trailer [46907,46914]
===
match
---
name: _parent_signal_conn [10893,10912]
name: _parent_signal_conn [10893,10912]
===
match
---
atom_expr [39300,39316]
atom_expr [39422,39438]
===
match
---
fstring_end: ' [33678,33679]
fstring_end: ' [33800,33801]
===
match
---
trailer [26885,26887]
trailer [27007,27009]
===
match
---
name: formatted_rows [34629,34643]
name: formatted_rows [34751,34765]
===
match
---
name: debug [44202,44207]
name: debug [44324,44329]
===
match
---
operator: , [44680,44681]
operator: , [44802,44803]
===
match
---
name: utcnow [45555,45561]
name: utcnow [45677,45683]
===
match
---
name: DagFileStat [39556,39567]
name: DagFileStat [39678,39689]
===
match
---
argument [44682,44697]
argument [44804,44819]
===
match
---
name: parsing_stat_age [15580,15596]
name: parsing_stat_age [15702,15718]
===
match
---
name: dag_ids [12092,12099]
name: dag_ids [12214,12221]
===
match
---
trailer [26553,26567]
trailer [26675,26689]
===
match
---
name: _process_message [14104,14120]
name: _process_message [14226,14242]
===
match
---
name: timeout [24662,24669]
name: timeout [24784,24791]
===
match
---
name: run_count [47738,47747]
name: run_count [47860,47869]
===
match
---
operator: = [19392,19393]
operator: = [19514,19515]
===
match
---
trailer [41070,41072]
trailer [41192,41194]
===
match
---
name: dag_id [10868,10874]
name: dag_id [10868,10874]
===
match
---
operator: , [6724,6725]
operator: , [6724,6725]
===
match
---
atom_expr [15883,15907]
atom_expr [16005,16029]
===
match
---
trailer [21375,21399]
trailer [21497,21521]
===
match
---
trailer [37797,37807]
trailer [37919,37929]
===
match
---
name: self [46974,46978]
name: self [47096,47100]
===
match
---
name: bool [4725,4729]
name: bool [4725,4729]
===
match
---
name: pid [8876,8879]
name: pid [8876,8879]
===
match
---
operator: = [38171,38172]
operator: = [38293,38294]
===
match
---
name: file_path [39830,39839]
name: file_path [39952,39961]
===
match
---
atom [29478,29596]
atom [29600,29718]
===
match
---
trailer [36945,36956]
trailer [37067,37078]
===
match
---
trailer [26488,26498]
trailer [26610,26620]
===
match
---
name: values [48824,48830]
name: values [48946,48952]
===
match
---
name: list_py_file_paths [30144,30162]
name: list_py_file_paths [30266,30284]
===
match
---
simple_stmt [14823,14853]
simple_stmt [14945,14975]
===
match
---
name: processor [39101,39110]
name: processor [39223,39232]
===
match
---
name: num_dags [39581,39589]
name: num_dags [39703,39711]
===
match
---
name: _file_stats [43585,43596]
name: _file_stats [43707,43718]
===
match
---
simple_stmt [22437,22486]
simple_stmt [22559,22608]
===
match
---
operator: , [39442,39443]
operator: , [39564,39565]
===
match
---
operator: = [7565,7566]
operator: = [7565,7566]
===
match
---
arglist [45787,45809]
arglist [45909,45931]
===
match
---
name: end [48138,48141]
name: end [48260,48263]
===
match
---
name: join [45828,45832]
name: join [45950,45954]
===
match
---
raise_stmt [3983,4010]
raise_stmt [3983,4010]
===
match
---
name: poll_time [26042,26051]
name: poll_time [26164,26173]
===
match
---
atom_expr [30363,30379]
atom_expr [30485,30501]
===
match
---
name: _refresh_dag_dir [24205,24221]
name: _refresh_dag_dir [24327,24343]
===
match
---
name: file_paths_recently_processed [43731,43760]
name: file_paths_recently_processed [43853,43882]
===
match
---
operator: , [13430,13431]
operator: , [13552,13553]
===
match
---
trailer [25503,25517]
trailer [25625,25639]
===
match
---
fstring [25480,25519]
fstring [25602,25641]
===
match
---
comparison [46037,46069]
comparison [46159,46191]
===
match
---
name: END_MANAGER [5150,5161]
name: END_MANAGER [5150,5161]
===
match
---
name: processor_timeout [13413,13430]
name: processor_timeout [13535,13552]
===
match
---
trailer [29609,29626]
trailer [29731,29748]
===
match
---
name: start [15135,15140]
name: start [15257,15262]
===
match
---
simple_stmt [16925,16932]
simple_stmt [17047,17054]
===
match
---
operator: , [29635,29636]
operator: , [29757,29758]
===
match
---
trailer [48296,48309]
trailer [48418,48431]
===
match
---
operator: = [33224,33225]
operator: = [33346,33347]
===
match
---
param [37847,37852]
param [37969,37974]
===
match
---
trailer [10912,10917]
trailer [10912,10917]
===
match
---
sync_comp_for [38176,38229]
sync_comp_for [38298,38351]
===
match
---
name: self [11508,11512]
name: self [11627,11631]
===
match
---
number: 0.0 [28934,28937]
number: 0.0 [29056,29059]
===
match
---
param [28976,29000]
param [29098,29122]
===
match
---
simple_stmt [16206,16239]
simple_stmt [16328,16361]
===
match
---
if_stmt [14760,15143]
if_stmt [14882,15265]
===
match
---
name: self [7357,7361]
name: self [7357,7361]
===
match
---
name: self [21685,21689]
name: self [21807,21811]
===
match
---
atom_expr [31649,31667]
atom_expr [31771,31789]
===
match
---
name: debug [39066,39071]
name: debug [39188,39193]
===
match
---
arglist [14937,15095]
arglist [15059,15217]
===
match
---
simple_stmt [1756,1857]
simple_stmt [1756,1857]
===
match
---
name: file_path [41036,41045]
name: file_path [41158,41167]
===
match
---
import_name [853,867]
import_name [853,867]
===
match
---
simple_stmt [24797,24875]
simple_stmt [24919,24997]
===
match
---
if_stmt [24693,25521]
if_stmt [24815,25643]
===
match
---
name: file_paths_recently_processed [42897,42926]
name: file_paths_recently_processed [43019,43048]
===
match
---
trailer [42926,42933]
trailer [43048,43055]
===
match
---
atom_expr [42494,42521]
atom_expr [42616,42643]
===
match
---
string: "DAG File Processing Stats\n\n" [34574,34605]
string: "DAG File Processing Stats\n\n" [34696,34727]
===
match
---
parameters [10392,10431]
parameters [10392,10431]
===
match
---
simple_stmt [868,891]
simple_stmt [868,891]
===
match
---
trailer [20219,20223]
trailer [20341,20345]
===
match
---
arglist [38540,38578]
arglist [38662,38700]
===
match
---
funcdef [38773,38982]
funcdef [38895,39104]
===
match
---
trailer [27065,27069]
trailer [27187,27191]
===
match
---
simple_stmt [14461,14545]
simple_stmt [14583,14667]
===
match
---
name: cast [1281,1285]
name: cast [1281,1285]
===
match
---
atom_expr [27061,27136]
atom_expr [27183,27258]
===
match
---
operator: = [41141,41142]
operator: = [41263,41264]
===
match
---
name: _process [9308,9316]
name: _process [9308,9316]
===
match
---
name: conf [20770,20774]
name: conf [20892,20896]
===
match
---
name: self [14200,14204]
name: self [14322,14326]
===
match
---
name: _process [8752,8760]
name: _process [8752,8760]
===
match
---
string: "PID" [32668,32673]
string: "PID" [32790,32795]
===
match
---
name: full_filepath [10399,10412]
name: full_filepath [10399,10412]
===
match
---
param [38797,38801]
param [38919,38923]
===
match
---
name: airflow [1650,1657]
name: airflow [1650,1657]
===
match
---
trailer [29066,29075]
trailer [29188,29197]
===
match
---
expr_stmt [48615,48674]
expr_stmt [48737,48796]
===
match
---
simple_stmt [915,929]
simple_stmt [915,929]
===
match
---
operator: = [42039,42040]
operator: = [42161,42162]
===
match
---
atom_expr [12110,12119]
atom_expr [12232,12241]
===
match
---
trailer [6707,6724]
trailer [6707,6724]
===
match
---
trailer [43602,43604]
trailer [43724,43726]
===
match
---
name: items [44172,44177]
name: items [44294,44299]
===
match
---
name: self [9750,9754]
name: self [9750,9754]
===
match
---
name: SIGINT [22515,22521]
name: SIGINT [22637,22643]
===
match
---
atom_expr [8868,8879]
atom_expr [8868,8879]
===
match
---
trailer [26992,27001]
trailer [27114,27123]
===
match
---
name: x [27679,27680]
name: x [27801,27802]
===
match
---
suite [26131,26500]
suite [26253,26622]
===
match
---
funcdef [3699,4011]
funcdef [3699,4011]
===
match
---
operator: , [28974,28975]
operator: , [29096,29097]
===
match
---
trailer [34628,34661]
trailer [34750,34783]
===
match
---
trailer [42182,42221]
trailer [42304,42343]
===
match
---
operator: = [44715,44716]
operator: = [44837,44838]
===
match
---
operator: = [42248,42249]
operator: = [42370,42371]
===
match
---
simple_stmt [4299,4401]
simple_stmt [4299,4401]
===
match
---
atom_expr [39864,39901]
atom_expr [39986,40023]
===
match
---
name: self [48292,48296]
name: self [48414,48418]
===
match
---
simple_stmt [45625,45694]
simple_stmt [45747,45816]
===
match
---
suite [47717,47795]
suite [47839,47917]
===
match
---
name: self [16443,16447]
name: self [16565,16569]
===
match
---
trailer [47810,47819]
trailer [47932,47941]
===
match
---
trailer [9486,9519]
trailer [9486,9519]
===
match
---
operator: = [43176,43177]
operator: = [43298,43299]
===
match
---
atom_expr [45452,45479]
atom_expr [45574,45601]
===
match
---
atom_expr [19570,19594]
atom_expr [19692,19716]
===
match
---
simple_stmt [42073,42097]
simple_stmt [42195,42219]
===
match
---
name: self [19500,19504]
name: self [19622,19626]
===
match
---
name: __name__ [14533,14541]
name: __name__ [14655,14663]
===
match
---
trailer [8751,8760]
trailer [8751,8760]
===
match
---
name: now [33458,33461]
name: now [33580,33583]
===
match
---
name: self [38729,38733]
name: self [38851,38855]
===
match
---
operator: - [40085,40086]
operator: - [40207,40208]
===
match
---
trailer [28539,28544]
trailer [28661,28666]
===
match
---
operator: = [33906,33907]
operator: = [34028,34029]
===
match
---
name: CallbackRequest [18924,18939]
name: CallbackRequest [19046,19061]
===
match
---
name: _file_paths [30296,30307]
name: _file_paths [30418,30429]
===
match
---
trailer [19464,19477]
trailer [19586,19599]
===
match
---
trailer [25945,26069]
trailer [26067,26191]
===
match
---
operator: , [34132,34133]
operator: , [34254,34255]
===
match
---
suite [42539,42585]
suite [42661,42707]
===
match
---
param [19136,19160]
param [19258,19282]
===
match
---
import_from [1721,1755]
import_from [1721,1755]
===
match
---
trailer [7476,7485]
trailer [7476,7485]
===
match
---
simple_stmt [38523,38580]
simple_stmt [38645,38702]
===
match
---
string: 'dag_processing.processes' [39141,39167]
string: 'dag_processing.processes' [39263,39289]
===
match
---
funcdef [16108,16239]
funcdef [16230,16361]
===
match
---
name: _process [14768,14776]
name: _process [14890,14898]
===
match
---
trailer [15859,15880]
trailer [15981,16002]
===
match
---
name: all_files_processed [27627,27646]
name: all_files_processed [27749,27768]
===
match
---
simple_stmt [19334,19360]
simple_stmt [19456,19482]
===
match
---
atom_expr [15072,15094]
atom_expr [15194,15216]
===
match
---
trailer [32878,32889]
trailer [33000,33011]
===
match
---
simple_stmt [36965,37012]
simple_stmt [37087,37134]
===
match
---
suite [16264,16694]
suite [16386,16816]
===
match
---
import_from [1525,1585]
import_from [1525,1585]
===
match
---
name: list [22151,22155]
name: list [22273,22277]
===
match
---
suite [24001,28938]
suite [24123,29060]
===
match
---
string: "Received %s signal from DagFileProcessorAgent" [24812,24859]
string: "Received %s signal from DagFileProcessorAgent" [24934,24981]
===
match
---
subscriptlist [21339,21355]
subscriptlist [21461,21477]
===
match
---
trailer [44577,44589]
trailer [44699,44711]
===
match
---
fstring_start: f" [34179,34181]
fstring_start: f" [34301,34303]
===
match
---
name: self [8291,8295]
name: self [8291,8295]
===
match
---
number: 0 [40932,40933]
number: 0 [41054,41055]
===
match
---
expr_stmt [7705,7773]
expr_stmt [7705,7773]
===
match
---
operator: == [45894,45896]
operator: == [46016,46018]
===
match
---
trailer [13187,13196]
trailer [13309,13318]
===
match
---
name: log [15674,15677]
name: log [15796,15799]
===
match
---
simple_stmt [31791,31833]
simple_stmt [31913,31955]
===
match
---
name: get_last_finish_time [42681,42701]
name: get_last_finish_time [42803,42823]
===
match
---
simple_stmt [4092,4188]
simple_stmt [4092,4188]
===
match
---
funcdef [35386,35796]
funcdef [35508,35918]
===
match
---
simple_stmt [38149,38231]
simple_stmt [38271,38353]
===
match
---
del_stmt [41346,41386]
del_stmt [41468,41508]
===
match
---
name: filtered_processors [38748,38767]
name: filtered_processors [38870,38889]
===
match
---
name: fileloc [45756,45763]
name: fileloc [45878,45885]
===
match
---
name: STORE_DAG_CODE [1674,1688]
name: STORE_DAG_CODE [1674,1688]
===
match
---
name: append [29060,29066]
name: append [29182,29188]
===
match
---
trailer [35377,35379]
trailer [35499,35501]
===
match
---
name: processor [39444,39453]
name: processor [39566,39575]
===
match
---
atom_expr [22508,22521]
atom_expr [22630,22643]
===
match
---
name: terminate [23095,23104]
name: terminate [23217,23226]
===
match
---
simple_stmt [33074,33138]
simple_stmt [33196,33260]
===
match
---
param [18811,18853]
param [18933,18975]
===
match
---
name: processor [40401,40410]
name: processor [40523,40532]
===
match
---
return_stmt [47850,47862]
return_stmt [47972,47984]
===
match
---
string: """Heartbeat DAG file processor and restart it if we are not done.""" [14588,14657]
string: """Heartbeat DAG file processor and restart it if we are not done.""" [14710,14779]
===
match
---
atom_expr [24966,24982]
atom_expr [25088,25104]
===
match
---
name: file_path [33716,33725]
name: file_path [33838,33847]
===
match
---
strings [20249,20383]
strings [20371,20505]
===
match
---
name: _collect_results_from_processor [26354,26385]
name: _collect_results_from_processor [26476,26507]
===
match
---
atom_expr [43447,43496]
atom_expr [43569,43618]
===
match
---
arglist [24639,24679]
arglist [24761,24801]
===
match
---
atom_expr [34620,34661]
atom_expr [34742,34783]
===
match
---
string: "File Path" [32655,32666]
string: "File Path" [32777,32788]
===
match
---
raise_stmt [9330,9370]
raise_stmt [9330,9370]
===
match
---
simple_stmt [35705,35744]
simple_stmt [35827,35866]
===
match
---
name: int [6643,6646]
name: int [6643,6646]
===
match
---
name: file_paths_to_exclude [44086,44107]
name: file_paths_to_exclude [44208,44229]
===
match
---
while_stmt [38924,38982]
while_stmt [39046,39104]
===
match
---
expr_stmt [8044,8098]
expr_stmt [8044,8098]
===
match
---
string: """         :param file_path: the path to the file that was processed         :type file_path: unicode         :return: the finish time of the process of the last run, or None if the             file was never processed.         :rtype: datetime         """ [36652,36909]
string: """         :param file_path: the path to the file that was processed         :type file_path: unicode         :return: the finish time of the process of the last run, or None if the             file was never processed.         :rtype: datetime         """ [36774,37031]
===
match
---
simple_stmt [12857,12919]
simple_stmt [12979,13041]
===
match
---
import_from [1645,1688]
import_from [1645,1688]
===
match
---
name: LJ [45787,45789]
name: LJ [45909,45911]
===
match
---
import_from [1756,1856]
import_from [1756,1856]
===
match
---
name: int [4866,4869]
name: int [4866,4869]
===
match
---
name: self [36925,36929]
name: self [37047,37051]
===
match
---
suite [48148,48392]
suite [48270,48514]
===
match
---
operator: , [12408,12409]
operator: , [12530,12531]
===
match
---
simple_stmt [19368,19412]
simple_stmt [19490,19534]
===
match
---
name: info [30254,30258]
name: info [30376,30380]
===
match
---
name: _file_path_queue [40659,40675]
name: _file_path_queue [40781,40797]
===
match
---
trailer [27031,27043]
trailer [27153,27165]
===
match
---
expr_stmt [42657,42712]
expr_stmt [42779,42834]
===
match
---
atom_expr [15130,15142]
atom_expr [15252,15264]
===
match
---
name: _last_zombie_query_time [46166,46189]
name: _last_zombie_query_time [46288,46311]
===
match
---
operator: , [15660,15661]
operator: , [15782,15783]
===
match
---
operator: = [20768,20769]
operator: = [20890,20891]
===
match
---
string: "Finding 'running' jobs without a recent heartbeat" [45382,45433]
string: "Finding 'running' jobs without a recent heartbeat" [45504,45555]
===
match
---
trailer [37750,37762]
trailer [37872,37884]
===
match
---
name: self [16861,16865]
name: self [16983,16987]
===
match
---
funcdef [11128,11796]
funcdef [11128,11918]
===
match
---
operator: = [33084,33085]
operator: = [33206,33207]
===
match
---
arglist [33897,33928]
arglist [34019,34050]
===
match
---
raise_stmt [2540,2567]
raise_stmt [2540,2567]
===
match
---
atom_expr [20139,20175]
atom_expr [20261,20297]
===
match
---
operator: , [40282,40283]
operator: , [40404,40405]
===
match
---
atom_expr [31243,31292]
atom_expr [31365,31414]
===
match
---
arglist [45986,46070]
arglist [46108,46192]
===
match
---
atom_expr [46383,46405]
atom_expr [46505,46527]
===
match
---
simple_stmt [22077,22157]
simple_stmt [22199,22279]
===
match
---
decorators [3112,3142]
decorators [3112,3142]
===
match
---
trailer [46200,46207]
trailer [46322,46329]
===
match
---
atom [35338,35380]
atom [35460,35502]
===
match
---
name: result [39236,39242]
name: result [39358,39364]
===
match
---
name: self [6968,6972]
name: self [6968,6972]
===
match
---
simple_stmt [27595,27614]
simple_stmt [27717,27736]
===
match
---
import_from [45296,45354]
import_from [45418,45476]
===
match
---
operator: = [15881,15882]
operator: = [16003,16004]
===
match
---
name: result [14121,14127]
name: result [14243,14249]
===
match
---
decorated [11801,13572]
decorated [11923,13694]
===
match
---
operator: < [47748,47749]
operator: < [47870,47871]
===
match
---
trailer [26427,26431]
trailer [26549,26553]
===
match
---
trailer [41208,41227]
trailer [41330,41349]
===
match
---
name: initialize [13197,13207]
name: initialize [13319,13329]
===
match
---
atom_expr [19334,19348]
atom_expr [19456,19470]
===
match
---
comparison [45150,45232]
comparison [45272,45354]
===
match
---
suite [2346,4633]
suite [2346,4633]
===
match
---
name: self [23231,23235]
name: self [23353,23357]
===
match
---
atom_expr [17216,17248]
atom_expr [17338,17370]
===
match
---
trailer [33050,33061]
trailer [33172,33183]
===
match
---
trailer [33116,33124]
trailer [33238,33246]
===
match
---
name: float [4962,4967]
name: float [4962,4967]
===
match
---
name: getattr [8501,8508]
name: getattr [8501,8508]
===
match
---
atom_expr [20742,20767]
atom_expr [20864,20889]
===
match
---
name: request [29067,29074]
name: request [29189,29196]
===
match
---
simple_stmt [24174,24191]
simple_stmt [24296,24313]
===
match
---
trailer [33093,33102]
trailer [33215,33224]
===
match
---
atom_expr [30777,30827]
atom_expr [30899,30949]
===
match
---
trailer [16595,16600]
trailer [16717,16722]
===
match
---
atom_expr [8286,8319]
atom_expr [8286,8319]
===
match
---
name: utils [1870,1875]
name: utils [1870,1875]
===
match
---
trailer [26629,26656]
trailer [26751,26778]
===
match
---
trailer [31759,31763]
trailer [31881,31885]
===
match
---
simple_stmt [15916,15971]
simple_stmt [16038,16093]
===
match
---
name: Optional [12101,12109]
name: Optional [12223,12231]
===
match
---
atom_expr [28531,28668]
atom_expr [28653,28790]
===
match
---
name: max_runs [13360,13368]
name: max_runs [13482,13490]
===
match
---
atom_expr [45150,45202]
atom_expr [45272,45324]
===
match
---
trailer [37432,37443]
trailer [37554,37565]
===
match
---
comparison [27653,27693]
comparison [27775,27815]
===
match
---
suite [4668,4760]
suite [4668,4760]
===
match
---
trailer [17176,17185]
trailer [17298,17307]
===
match
---
atom_expr [8054,8098]
atom_expr [8054,8098]
===
match
---
import_from [1389,1418]
import_from [1389,1418]
===
match
---
trailer [8634,8643]
trailer [8634,8643]
===
match
---
simple_stmt [7472,7540]
simple_stmt [7472,7540]
===
match
---
string: 'dag_file_processor_timeouts' [47416,47445]
string: 'dag_file_processor_timeouts' [47538,47567]
===
match
---
atom_expr [27703,27718]
atom_expr [27825,27840]
===
match
---
trailer [22081,22102]
trailer [22203,22224]
===
match
---
atom_expr [8630,8643]
atom_expr [8630,8643]
===
match
---
name: process [8780,8787]
name: process [8780,8787]
===
match
---
atom [19279,19281]
atom [19401,19403]
===
match
---
name: processor [26386,26395]
name: processor [26508,26517]
===
match
---
trailer [48116,48126]
trailer [48238,48248]
===
match
---
atom_expr [44296,44315]
atom_expr [44418,44437]
===
match
---
trailer [45376,45381]
trailer [45498,45503]
===
match
---
string: "Last Run" [32724,32734]
string: "Last Run" [32846,32856]
===
match
---
trailer [37762,37766]
trailer [37884,37888]
===
match
---
name: self [22362,22366]
name: self [22484,22488]
===
match
---
name: now [45151,45154]
name: now [45273,45276]
===
match
---
name: file_path [44131,44140]
name: file_path [44253,44262]
===
match
---
atom_expr [19089,19098]
atom_expr [19211,19220]
===
match
---
name: RUNNING [46004,46011]
name: RUNNING [46126,46133]
===
match
---
suite [3453,3660]
suite [3453,3660]
===
match
---
operator: = [8143,8144]
operator: = [8143,8144]
===
match
---
trailer [15841,15846]
trailer [15963,15968]
===
match
---
operator: = [24523,24524]
operator: = [24645,24646]
===
match
---
name: utcnow [29798,29804]
name: utcnow [29920,29926]
===
match
---
atom_expr [4202,4223]
atom_expr [4202,4223]
===
match
---
trailer [19424,19437]
trailer [19546,19559]
===
match
---
expr_stmt [21070,21106]
expr_stmt [21192,21228]
===
match
---
string: """Generate more file paths to process. Result are saved in _file_path_queue.""" [41744,41824]
string: """Generate more file paths to process. Result are saved in _file_path_queue.""" [41866,41946]
===
match
---
name: _all_files_processed [15860,15880]
name: _all_files_processed [15982,16002]
===
match
---
name: processor_factory [6656,6673]
name: processor_factory [6656,6673]
===
match
---
exprlist [46226,46238]
exprlist [46348,46360]
===
match
---
name: self [24696,24700]
name: self [24818,24822]
===
match
---
name: _file_stats [36930,36941]
name: _file_stats [37052,37063]
===
match
---
simple_stmt [14406,14435]
simple_stmt [14528,14557]
===
match
---
simple_stmt [39268,39317]
simple_stmt [39390,39439]
===
match
---
simple_stmt [33269,33342]
simple_stmt [33391,33464]
===
match
---
simple_stmt [45447,45480]
simple_stmt [45569,45602]
===
match
---
param [39934,39938]
param [40056,40060]
===
match
---
trailer [14410,14425]
trailer [14532,14547]
===
match
---
simple_stmt [19420,19452]
simple_stmt [19542,19574]
===
match
---
atom_expr [30415,30459]
atom_expr [30537,30581]
===
match
---
import_as_name [45336,45354]
import_as_name [45458,45476]
===
match
---
suite [30623,30695]
suite [30745,30817]
===
match
---
except_clause [10935,10957]
except_clause [10935,10957]
===
match
---
string: 'scheduler' [20588,20599]
string: 'scheduler' [20710,20721]
===
match
---
if_stmt [25534,26096]
if_stmt [25656,26218]
===
match
---
name: file_path [41607,41616]
name: file_path [41729,41738]
===
match
---
name: self [27809,27813]
name: self [27931,27935]
===
match
---
name: signal [22561,22567]
name: signal [22683,22689]
===
match
---
operator: = [19153,19154]
operator: = [19275,19276]
===
match
---
name: NotImplementedError [2546,2565]
name: NotImplementedError [2546,2565]
===
match
---
simple_stmt [48349,48392]
simple_stmt [48471,48514]
===
match
---
name: full_filepath [10846,10859]
name: full_filepath [10846,10859]
===
match
---
name: provide_session [31356,31371]
name: provide_session [31478,31493]
===
match
---
operator: , [33785,33786]
operator: , [33907,33908]
===
match
---
name: x [38210,38211]
name: x [38332,38333]
===
match
---
atom_expr [46606,46634]
atom_expr [46728,46756]
===
match
---
name: self [47691,47695]
name: self [47813,47817]
===
match
---
suite [45243,46635]
suite [45365,46757]
===
match
---
name: self [49046,49050]
name: self [49168,49172]
===
match
---
expr_stmt [19203,19235]
expr_stmt [19325,19357]
===
match
---
operator: = [32750,32751]
operator: = [32872,32873]
===
match
---
testlist_comp [34123,34448]
testlist_comp [34245,34570]
===
match
---
dotted_name [1486,1500]
dotted_name [1486,1500]
===
match
---
operator: = [44735,44736]
operator: = [44857,44858]
===
match
---
expr_stmt [24599,24680]
expr_stmt [24721,24802]
===
match
---
name: self [31167,31171]
name: self [31289,31293]
===
match
---
operator: , [19099,19100]
operator: , [19221,19222]
===
match
---
name: processor [47463,47472]
name: processor [47585,47594]
===
match
---
operator: , [44740,44741]
operator: , [44862,44863]
===
match
---
operator: , [46526,46527]
operator: , [46648,46649]
===
match
---
name: filtered_processors [38299,38318]
name: filtered_processors [38421,38440]
===
match
---
name: Optional [6726,6734]
name: Optional [6726,6734]
===
match
---
name: _last_zombie_query_time [21376,21399]
name: _last_zombie_query_time [21498,21521]
===
match
---
name: register_exit_signals [23499,23520]
name: register_exit_signals [23621,23642]
===
match
---
name: self [21316,21320]
name: self [21438,21442]
===
match
---
name: state [45888,45893]
name: state [46010,46015]
===
match
---
simple_stmt [31927,32182]
simple_stmt [32049,32304]
===
match
---
suite [37396,37455]
suite [37518,37577]
===
match
---
expr_stmt [38729,38767]
expr_stmt [38851,38889]
===
match
---
name: Stats [48750,48755]
name: Stats [48872,48877]
===
match
---
trailer [40057,40062]
trailer [40179,40184]
===
match
---
operator: = [48626,48627]
operator: = [48748,48749]
===
match
---
name: Stats [1715,1720]
name: Stats [1715,1720]
===
match
---
simple_stmt [1442,1481]
simple_stmt [1442,1481]
===
match
---
simple_stmt [7357,7423]
simple_stmt [7357,7423]
===
match
---
atom_expr [8393,8407]
atom_expr [8393,8407]
===
match
---
not_test [9267,9295]
not_test [9267,9295]
===
match
---
suite [4083,4224]
suite [4083,4224]
===
match
---
trailer [30809,30827]
trailer [30931,30949]
===
match
---
atom_expr [45804,45809]
atom_expr [45926,45931]
===
match
---
name: int [11893,11896]
name: int [12015,12018]
===
match
---
atom_expr [27559,27581]
atom_expr [27681,27703]
===
match
---
atom_expr [14823,14852]
atom_expr [14945,14974]
===
match
---
name: _file_paths [31214,31225]
name: _file_paths [31336,31347]
===
match
---
trailer [25933,25937]
trailer [26055,26059]
===
match
---
trailer [26925,26927]
trailer [27047,27049]
===
match
---
trailer [33628,33635]
trailer [33750,33757]
===
match
---
name: DagFileProcessorManager [13296,13319]
name: DagFileProcessorManager [13418,13441]
===
match
---
name: count_import_errors [39490,39509]
name: count_import_errors [39612,39631]
===
match
---
name: file_path [42702,42711]
name: file_path [42824,42833]
===
match
---
name: self [7472,7476]
name: self [7472,7476]
===
match
---
name: rows [34044,34048]
name: rows [34166,34170]
===
match
---
atom_expr [16571,16636]
atom_expr [16693,16758]
===
match
---
simple_stmt [21484,21564]
simple_stmt [21606,21686]
===
match
---
raise_stmt [10737,10777]
raise_stmt [10737,10777]
===
match
---
expr_stmt [28922,28937]
expr_stmt [29044,29059]
===
match
---
name: is_mtime_mode [42285,42298]
name: is_mtime_mode [42407,42420]
===
match
---
simple_stmt [46161,46210]
simple_stmt [46283,46332]
===
match
---
simple_stmt [48107,48129]
simple_stmt [48229,48251]
===
match
---
name: str [10427,10430]
name: str [10427,10430]
===
match
---
trailer [45832,45860]
trailer [45954,45982]
===
match
---
name: Optional [3719,3727]
name: Optional [3719,3727]
===
match
---
operator: = [30142,30143]
operator: = [30264,30265]
===
match
---
name: query [31710,31715]
name: query [31832,31837]
===
match
---
atom_expr [15351,15394]
atom_expr [15473,15516]
===
match
---
trailer [30848,30863]
trailer [30970,30985]
===
match
---
name: self [31008,31012]
name: self [31130,31134]
===
match
---
argument [17191,17206]
argument [17313,17328]
===
match
---
not_test [25537,25546]
not_test [25659,25668]
===
match
---
fstring_end: " [34211,34212]
fstring_end: " [34333,34334]
===
match
---
param [22422,22426]
param [22544,22548]
===
match
---
name: conf [1476,1480]
name: conf [1476,1480]
===
match
---
name: file_path [42934,42943]
name: file_path [43056,43065]
===
match
---
name: log [46979,46982]
name: log [47101,47104]
===
match
---
name: now [42073,42076]
name: now [42195,42198]
===
match
---
atom_expr [49068,49084]
atom_expr [49190,49206]
===
match
---
expr_stmt [42339,42373]
expr_stmt [42461,42495]
===
match
---
name: self [22584,22588]
name: self [22706,22710]
===
match
---
name: DagCode [30916,30923]
name: DagCode [31038,31045]
===
match
---
simple_stmt [10888,10927]
simple_stmt [10888,10927]
===
match
---
name: start [7854,7859]
name: start [7854,7859]
===
match
---
trailer [23873,23888]
trailer [23995,24010]
===
match
---
atom_expr [33167,33190]
atom_expr [33289,33312]
===
match
---
annassign [7558,7572]
annassign [7558,7572]
===
match
---
name: get_pid [34755,34762]
name: get_pid [34877,34884]
===
match
---
name: info [30058,30062]
name: info [30180,30184]
===
match
---
argument [39659,39692]
argument [39781,39814]
===
match
---
classdef [4762,4988]
classdef [4762,4988]
===
match
---
name: str [6698,6701]
name: str [6698,6701]
===
match
---
operator: - [29849,29850]
operator: - [29971,29972]
===
match
---
simple_stmt [21611,21641]
simple_stmt [21733,21763]
===
match
---
atom_expr [26988,27001]
atom_expr [27110,27123]
===
match
---
name: AbstractDagFileProcessorProcess [11964,11995]
name: AbstractDagFileProcessorProcess [12086,12117]
===
match
---
trailer [45781,45786]
trailer [45903,45908]
===
match
---
name: info [16490,16494]
name: info [16612,16616]
===
match
---
atom_expr [31305,31330]
atom_expr [31427,31452]
===
match
---
trailer [49072,49084]
trailer [49194,49206]
===
match
---
name: self [36512,36516]
name: self [36634,36638]
===
match
---
string: """Sync metadata from stat queue and only keep the latest stat.""" [15749,15815]
string: """Sync metadata from stat queue and only keep the latest stat.""" [15871,15937]
===
match
---
operator: , [34016,34017]
operator: , [34138,34139]
===
match
---
operator: != [29558,29560]
operator: != [29680,29682]
===
match
---
name: processor [39881,39890]
name: processor [40003,40012]
===
match
---
name: self [14573,14577]
name: self [14695,14699]
===
match
---
exprlist [44131,44151]
exprlist [44253,44273]
===
match
---
name: self [26549,26553]
name: self [26671,26675]
===
match
---
name: file_path [32799,32808]
name: file_path [32921,32930]
===
match
---
string: """:return: whether all file paths have been processed max_runs times""" [47521,47593]
string: """:return: whether all file paths have been processed max_runs times""" [47643,47715]
===
match
---
atom_expr [45957,46092]
atom_expr [46079,46214]
===
match
---
name: os [19990,19992]
name: os [20112,20114]
===
match
---
name: self [10699,10703]
name: self [10699,10703]
===
match
---
trailer [31642,31648]
trailer [31764,31770]
===
match
---
simple_stmt [22166,22225]
simple_stmt [22288,22347]
===
match
---
name: debug [41490,41495]
name: debug [41612,41617]
===
match
---
trailer [42057,42062]
trailer [42179,42184]
===
match
---
name: self [39864,39868]
name: self [39986,39990]
===
match
---
string: """Information on processing progress""" [4673,4713]
string: """Information on processing progress""" [4673,4713]
===
match
---
atom_expr [23890,23916]
atom_expr [24012,24038]
===
match
---
argument [39791,39844]
argument [39913,39966]
===
match
---
comparison [20180,20201]
comparison [20302,20323]
===
match
---
trailer [14290,14345]
trailer [14412,14467]
===
match
---
name: self [46487,46491]
name: self [46609,46613]
===
match
---
decorated [2934,3107]
decorated [2934,3107]
===
match
---
name: _file_path_queue [38154,38170]
name: _file_path_queue [38276,38292]
===
match
---
simple_stmt [1857,1907]
simple_stmt [1857,1907]
===
match
---
name: files_with_mtime [42231,42247]
name: files_with_mtime [42353,42369]
===
match
---
operator: { [21359,21360]
operator: { [21481,21482]
===
match
---
atom_expr [24447,24473]
atom_expr [24569,24595]
===
match
---
name: send [16596,16600]
name: send [16718,16722]
===
match
---
name: _processor_timeout [8559,8577]
name: _processor_timeout [8559,8577]
===
match
---
name: delete [31797,31803]
name: delete [31919,31925]
===
match
---
simple_stmt [33443,33490]
simple_stmt [33565,33612]
===
match
---
atom_expr [25469,25520]
atom_expr [25591,25642]
===
match
---
operator: , [18852,18853]
operator: , [18974,18975]
===
match
---
simple_stmt [2998,3071]
simple_stmt [2998,3071]
===
match
---
simple_stmt [33022,33062]
simple_stmt [33144,33184]
===
match
---
exprlist [43561,43576]
exprlist [43683,43698]
===
match
---
trailer [23076,23078]
trailer [23198,23200]
===
match
---
name: TaskInstance [45467,45479]
name: TaskInstance [45589,45601]
===
match
---
decorator [11801,11815]
decorator [11923,11937]
===
match
---
test [36972,37011]
test [37094,37133]
===
match
---
trailer [45806,45809]
trailer [45928,45931]
===
match
---
testlist_comp [29496,29582]
testlist_comp [29618,29704]
===
match
---
trailer [15958,15968]
trailer [16080,16090]
===
match
---
name: os [42494,42496]
name: os [42616,42618]
===
match
---
simple_stmt [41451,41469]
simple_stmt [41573,41591]
===
match
---
name: MultiprocessingConnection [7740,7765]
name: MultiprocessingConnection [7740,7765]
===
match
---
trailer [44404,44492]
trailer [44526,44614]
===
match
---
name: TI [45749,45751]
name: TI [45871,45873]
===
match
---
name: abc [957,960]
name: abc [957,960]
===
match
---
param [34769,34778]
param [34891,34900]
===
match
---
operator: = [38746,38747]
operator: = [38868,38869]
===
match
---
suite [48420,48972]
suite [48542,49094]
===
match
---
funcdef [15709,15971]
funcdef [15831,16093]
===
match
---
trailer [12796,12804]
trailer [12918,12926]
===
match
---
trailer [20030,20032]
trailer [20152,20154]
===
match
---
trailer [21165,21177]
trailer [21287,21299]
===
match
---
name: Dict [22250,22254]
name: Dict [22372,22376]
===
match
---
atom_expr [6991,7000]
atom_expr [6991,7000]
===
match
---
name: self [3160,3164]
name: self [3160,3164]
===
match
---
name: stack [23071,23076]
name: stack [23193,23198]
===
match
---
trailer [43711,43717]
trailer [43833,43839]
===
match
---
name: _last_parsing_stat_received_at [15237,15267]
name: _last_parsing_stat_received_at [15359,15389]
===
match
---
name: prepare_file_path_queue [24237,24260]
name: prepare_file_path_queue [24359,24382]
===
match
---
atom_expr [44193,44380]
atom_expr [44315,44502]
===
match
---
name: agent_signal [25167,25179]
name: agent_signal [25289,25301]
===
match
---
operator: = [24605,24606]
operator: = [24727,24728]
===
match
---
name: runtime [33742,33749]
name: runtime [33864,33871]
===
match
---
name: _last_parsing_stat_received_at [15921,15951]
name: _last_parsing_stat_received_at [16043,16073]
===
match
---
trailer [8081,8098]
trailer [8081,8098]
===
match
---
operator: { [25498,25499]
operator: { [25620,25621]
===
match
---
factor [39512,39514]
factor [39634,39636]
===
match
---
name: utils [1734,1739]
name: utils [1734,1739]
===
match
---
trailer [12398,12406]
trailer [12520,12528]
===
match
---
name: latest_heartbeat [46040,46056]
name: latest_heartbeat [46162,46178]
===
match
---
expr_stmt [4973,4987]
expr_stmt [4973,4987]
===
match
---
name: processor_start_time [33203,33223]
name: processor_start_time [33325,33345]
===
match
---
trailer [40396,40400]
trailer [40518,40522]
===
match
---
atom_expr [48777,48833]
atom_expr [48899,48955]
===
match
---
trailer [33041,33050]
trailer [33163,33172]
===
match
---
trailer [40470,40481]
trailer [40592,40603]
===
match
---
simple_stmt [2540,2568]
simple_stmt [2540,2568]
===
match
---
atom_expr [16443,16467]
atom_expr [16565,16589]
===
match
---
import_from [1184,1285]
import_from [1184,1285]
===
match
---
suite [2267,2287]
suite [2267,2287]
===
match
---
trailer [44785,44802]
trailer [44907,44924]
===
match
---
simple_stmt [7233,7265]
simple_stmt [7233,7265]
===
match
---
decorated [16094,16239]
decorated [16216,16361]
===
match
---
operator: = [39589,39590]
operator: = [39711,39712]
===
match
---
expr_stmt [46771,46794]
expr_stmt [46893,46916]
===
match
---
trailer [40067,40077]
trailer [40189,40199]
===
match
---
trailer [15076,15085]
trailer [15198,15207]
===
match
---
atom_expr [39343,39477]
atom_expr [39465,39599]
===
match
---
name: property [16095,16103]
name: property [16217,16225]
===
match
---
atom_expr [6735,6744]
atom_expr [6735,6744]
===
match
---
simple_stmt [16071,16089]
simple_stmt [16193,16211]
===
match
---
trailer [38606,38634]
trailer [38728,38756]
===
match
---
simple_stmt [15194,15268]
simple_stmt [15316,15390]
===
match
---
name: _parallelism [20185,20197]
name: _parallelism [20307,20319]
===
match
---
argument [27653,27718]
argument [27775,27840]
===
match
---
not_test [14669,14697]
not_test [14791,14819]
===
match
---
expr_stmt [42016,42064]
expr_stmt [42138,42186]
===
match
---
string: 'terminate_manager' [5126,5145]
string: 'terminate_manager' [5126,5145]
===
match
---
atom_expr [25929,26069]
atom_expr [26051,26191]
===
match
---
trailer [7237,7250]
trailer [7237,7250]
===
match
---
operator: = [26238,26239]
operator: = [26360,26361]
===
match
---
atom_expr [36159,36172]
atom_expr [36281,36294]
===
match
---
name: all_files_processed [27935,27954]
name: all_files_processed [28057,28076]
===
match
---
name: int [2985,2988]
name: int [2985,2988]
===
match
---
annassign [4913,4933]
annassign [4913,4933]
===
match
---
expr_stmt [39527,39539]
expr_stmt [39649,39661]
===
match
---
funcdef [30992,31350]
funcdef [31114,31472]
===
match
---
atom_expr [13985,14016]
atom_expr [14107,14138]
===
match
---
trailer [9275,9295]
trailer [9275,9295]
===
match
---
number: 1 [27005,27006]
number: 1 [27127,27128]
===
match
---
atom_expr [9336,9370]
atom_expr [9336,9370]
===
match
---
operator: { [7420,7421]
operator: { [7420,7421]
===
match
---
raise_stmt [4605,4632]
raise_stmt [4605,4632]
===
match
---
name: self [16078,16082]
name: self [16200,16204]
===
match
---
trailer [18923,18940]
trailer [19045,19062]
===
match
---
operator: > [29937,29938]
operator: > [30059,30060]
===
match
---
trailer [47477,47479]
trailer [47599,47601]
===
match
---
operator: -> [3716,3718]
operator: -> [3716,3718]
===
match
---
name: _max_runs [47827,47836]
name: _max_runs [47949,47958]
===
match
---
name: filename [31751,31759]
name: filename [31873,31881]
===
match
---
arith_expr [28757,28791]
arith_expr [28879,28913]
===
match
---
name: get_last_dag_count [35805,35823]
name: get_last_dag_count [35927,35945]
===
match
---
name: callback_to_execute_for_file [41112,41140]
name: callback_to_execute_for_file [41234,41262]
===
match
---
subscriptlist [7380,7416]
subscriptlist [7380,7416]
===
match
---
funcdef [2454,2568]
funcdef [2454,2568]
===
match
---
atom_expr [12857,12908]
atom_expr [12979,13030]
===
match
---
atom_expr [44333,44365]
atom_expr [44455,44487]
===
match
---
simple_stmt [1028,1069]
simple_stmt [1028,1069]
===
match
---
trailer [9307,9316]
trailer [9307,9316]
===
match
---
fstring_string: Invalid message  [25482,25498]
fstring_string: Invalid message  [25604,25620]
===
match
---
atom_expr [44390,44492]
atom_expr [44512,44614]
===
match
---
expr_stmt [48277,48311]
expr_stmt [48399,48433]
===
match
---
operator: , [13476,13477]
operator: , [13598,13599]
===
match
---
suite [16672,16694]
suite [16794,16816]
===
match
---
trailer [40092,40105]
trailer [40214,40227]
===
match
---
operator: , [24859,24860]
operator: , [24981,24982]
===
match
---
simple_stmt [44607,44772]
simple_stmt [44729,44894]
===
match
---
operator: > [15296,15297]
operator: > [15418,15419]
===
match
---
operator: , [44278,44279]
operator: , [44400,44401]
===
match
---
name: self [27595,27599]
name: self [27717,27721]
===
match
---
simple_stmt [28850,28880]
simple_stmt [28972,29002]
===
match
---
string: "DagFileProcessorManager (PID=%d) last sent a heartbeat %.2f seconds ago! Restarting it" [15439,15527]
string: "DagFileProcessorManager (PID=%d) last sent a heartbeat %.2f seconds ago! Restarting it" [15561,15649]
===
match
---
trailer [23801,23806]
trailer [23923,23928]
===
match
---
annassign [19594,19616]
annassign [19716,19738]
===
match
---
atom_expr [31732,31781]
atom_expr [31854,31903]
===
match
---
annassign [4887,4892]
annassign [4887,4892]
===
match
---
name: airflow [1694,1701]
name: airflow [1694,1701]
===
match
---
name: context [8250,8257]
name: context [8250,8257]
===
match
---
operator: , [975,976]
operator: , [975,976]
===
match
---
trailer [46982,46988]
trailer [47104,47110]
===
match
---
name: int [4889,4892]
name: int [4889,4892]
===
match
---
if_stmt [15152,15185]
if_stmt [15274,15307]
===
match
---
operator: = [40029,40030]
operator: = [40151,40152]
===
match
---
operator: , [30285,30286]
operator: , [30407,30408]
===
match
---
name: logging [22178,22185]
name: logging [22300,22307]
===
match
---
name: _file_process_interval [42843,42865]
name: _file_process_interval [42965,42987]
===
match
---
raise_stmt [14711,14751]
raise_stmt [14833,14873]
===
match
---
name: self [27061,27065]
name: self [27183,27187]
===
match
---
atom [42371,42373]
atom [42493,42495]
===
match
---
name: _parent_signal_conn [17221,17240]
name: _parent_signal_conn [17343,17362]
===
match
---
funcdef [23221,23968]
funcdef [23343,24090]
===
match
---
string: "Process each file at most once every %s seconds" [23705,23754]
string: "Process each file at most once every %s seconds" [23827,23876]
===
match
---
simple_stmt [30343,30381]
simple_stmt [30465,30503]
===
match
---
simple_stmt [15749,15816]
simple_stmt [15871,15938]
===
match
---
simple_stmt [24740,24780]
simple_stmt [24862,24902]
===
match
---
trailer [30948,30968]
trailer [31070,31090]
===
match
---
atom_expr [41451,41468]
atom_expr [41573,41590]
===
match
---
name: stat [39904,39908]
name: stat [40026,40030]
===
match
---
name: importlib [1074,1083]
name: importlib [1074,1083]
===
match
---
trailer [39204,39211]
trailer [39326,39333]
===
match
---
name: airflow [1486,1493]
name: airflow [1486,1493]
===
match
---
operator: @ [31355,31356]
operator: @ [31477,31478]
===
match
---
arith_expr [40809,40850]
arith_expr [40931,40972]
===
match
---
suite [38506,38721]
suite [38628,38843]
===
match
---
trailer [24805,24811]
trailer [24927,24933]
===
match
---
trailer [21525,21536]
trailer [21647,21658]
===
match
---
suite [13605,14226]
suite [13727,14348]
===
match
---
annassign [4753,4759]
annassign [4753,4759]
===
match
---
name: self [24200,24204]
name: self [24322,24326]
===
match
---
arith_expr [33458,33472]
arith_expr [33580,33594]
===
match
---
simple_stmt [992,1028]
simple_stmt [992,1028]
===
match
---
name: now [46771,46774]
name: now [46893,46896]
===
match
---
parameters [3709,3715]
parameters [3709,3715]
===
match
---
simple_stmt [29011,29076]
simple_stmt [29133,29198]
===
match
---
trailer [4923,4933]
trailer [4923,4933]
===
match
---
suite [14579,15704]
suite [14701,15826]
===
match
---
name: _signal_conn [22348,22360]
name: _signal_conn [22470,22482]
===
match
---
trailer [12867,12908]
trailer [12989,13030]
===
match
---
name: stat [37739,37743]
name: stat [37861,37865]
===
match
---
name: limit_dttm [45533,45543]
name: limit_dttm [45655,45665]
===
match
---
expr_stmt [43165,43196]
expr_stmt [43287,43318]
===
match
---
arglist [11564,11586]
arglist [11683,11705]
===
match
---
arith_expr [45151,45185]
arith_expr [45273,45307]
===
match
---
name: make_aware [21526,21536]
name: make_aware [21648,21658]
===
match
---
name: self [23943,23947]
name: self [24065,24069]
===
match
---
simple_stmt [46487,46537]
simple_stmt [46609,46659]
===
match
---
name: recv [24773,24777]
name: recv [24895,24899]
===
match
---
name: self [44781,44785]
name: self [44903,44907]
===
match
---
arglist [20082,20114]
arglist [20204,20236]
===
match
---
string: 'end_manager' [5164,5177]
string: 'end_manager' [5164,5177]
===
match
---
param [6908,6925]
param [6908,6925]
===
match
---
operator: , [26040,26041]
operator: , [26162,26163]
===
match
---
import_from [1028,1068]
import_from [1028,1068]
===
match
---
string: """         :return: the path to the file that this is processing         :rtype: unicode         """ [4299,4400]
string: """         :return: the path to the file that this is processing         :rtype: unicode         """ [4299,4400]
===
match
---
trailer [15673,15677]
trailer [15795,15799]
===
match
---
name: self [26625,26629]
name: self [26747,26751]
===
match
---
simple_stmt [11175,11218]
simple_stmt [11175,11218]
===
match
---
funcdef [49031,49085]
funcdef [49153,49207]
===
match
---
atom_expr [41481,41577]
atom_expr [41603,41699]
===
match
---
atom_expr [41657,41682]
atom_expr [41779,41804]
===
match
---
name: stat [15837,15841]
name: stat [15959,15963]
===
match
---
suite [11258,11312]
suite [11258,11312]
===
match
---
trailer [45372,45376]
trailer [45494,45498]
===
match
---
name: sys [25127,25130]
name: sys [25249,25252]
===
match
---
name: incr [47298,47302]
name: incr [47420,47424]
===
match
---
operator: = [30227,30228]
operator: = [30349,30350]
===
match
---
simple_stmt [22691,22737]
simple_stmt [22813,22859]
===
match
---
trailer [33171,33179]
trailer [33293,33301]
===
match
---
name: self [30810,30814]
name: self [30932,30936]
===
match
---
name: last_finish_time [42746,42762]
name: last_finish_time [42868,42884]
===
match
---
import_from [992,1027]
import_from [992,1027]
===
match
---
fstring [34179,34212]
fstring [34301,34334]
===
match
---
name: List [22114,22118]
name: List [22236,22240]
===
match
---
comparison [47806,47836]
comparison [47928,47958]
===
match
---
operator: = [20945,20946]
operator: = [21067,21068]
===
match
---
trailer [10062,10086]
trailer [10062,10086]
===
match
---
simple_stmt [43447,43497]
simple_stmt [43569,43619]
===
match
---
comparison [45885,45910]
comparison [46007,46032]
===
match
---
name: __init__ [6949,6957]
name: __init__ [6949,6957]
===
match
---
atom_expr [10699,10723]
atom_expr [10699,10723]
===
match
---
atom_expr [29152,29173]
atom_expr [29274,29295]
===
match
---
atom_expr [39423,39442]
atom_expr [39545,39564]
===
match
---
atom_expr [38966,38981]
atom_expr [39088,39103]
===
match
---
name: exit_code [3150,3159]
name: exit_code [3150,3159]
===
match
---
expr_stmt [32842,32889]
expr_stmt [32964,33011]
===
match
---
suite [33606,33690]
suite [33728,33812]
===
match
---
trailer [8787,8793]
trailer [8787,8793]
===
match
---
name: CallbackRequest [1800,1815]
name: CallbackRequest [1800,1815]
===
match
---
atom_expr [26240,26268]
atom_expr [26362,26390]
===
match
---
trailer [6865,6870]
trailer [6865,6870]
===
match
---
trailer [15227,15229]
trailer [15349,15351]
===
match
---
param [18885,18976]
param [19007,19098]
===
match
---
operator: = [31716,31717]
operator: = [31838,31839]
===
match
---
trailer [13073,13092]
trailer [13195,13214]
===
insert-tree
---
simple_stmt [787,809]
    string: """Processes DAGs.""" [787,808]
to
file_input [787,49085]
at 0
===
insert-node
---
name: DagFileProcessorAgent [5186,5207]
to
classdef [5180,17249]
at 0
===
insert-tree
---
arglist [5208,5253]
    name: LoggingMixin [5208,5220]
    operator: , [5220,5221]
    name: MultiprocessingStartMethodMixin [5222,5253]
to
classdef [5180,17249]
at 1
===
insert-tree
---
simple_stmt [5260,6564]
    string: """     Agent for DAG file processing. It is responsible for all DAG parsing     related jobs in scheduler process. Mainly it can spin up DagFileProcessorManager     in a subprocess, collect DAG parsing results from it and communicate     signal/DAG parsing stat with it.      This class runs in the main `airflow scheduler` process.      :param dag_directory: Directory where DAG definitions are kept. All         files in file_paths should be under this directory     :type dag_directory: str     :param max_runs: The number of times to parse and schedule each file. -1         for unlimited.     :type max_runs: int     :param processor_factory: function that creates processors for DAG         definition files. Arguments are (dag_definition_path, log_file_path)     :type processor_factory: ([str, List[CallbackRequest], Optional[List[str]], bool]) -> (         AbstractDagFileProcessorProcess     )     :param processor_timeout: How long to wait before timing out a DAG file processor     :type processor_timeout: timedelta     :param dag_ids: if specified, only schedule tasks with these DAG IDs     :type dag_ids: list[str]     :param pickle_dags: whether to pickle DAGs.     :type: pickle_dags: bool     :param async_mode: Whether to start agent in async mode     :type async_mode: bool     """ [5260,6563]
to
suite [5255,17249]
at 0
===
insert-tree
---
if_stmt [11320,11430]
    atom_expr [11323,11339]
        name: self [11323,11327]
        trailer [11327,11339]
            name: _async_mode [11328,11339]
    suite [11340,11430]
        simple_stmt [11353,11430]
            raise_stmt [11353,11429]
                atom_expr [11359,11429]
                    name: RuntimeError [11359,11371]
                    trailer [11371,11429]
                        string: "wait_until_finished should only be called in sync_mode" [11372,11428]
to
suite [11166,11796]
at 2
===
delete-tree
---
simple_stmt [787,809]
    string: """Processes DAGs.""" [787,808]
===
delete-node
---
name: DagFileProcessorAgent [5186,5207]
===
===
delete-tree
---
arglist [5208,5253]
    name: LoggingMixin [5208,5220]
    operator: , [5220,5221]
    name: MultiprocessingStartMethodMixin [5222,5253]
===
delete-tree
---
simple_stmt [5260,6564]
    string: """     Agent for DAG file processing. It is responsible for all DAG parsing     related jobs in scheduler process. Mainly it can spin up DagFileProcessorManager     in a subprocess, collect DAG parsing results from it and communicate     signal/DAG parsing stat with it.      This class runs in the main `airflow scheduler` process.      :param dag_directory: Directory where DAG definitions are kept. All         files in file_paths should be under this directory     :type dag_directory: str     :param max_runs: The number of times to parse and schedule each file. -1         for unlimited.     :type max_runs: int     :param processor_factory: function that creates processors for DAG         definition files. Arguments are (dag_definition_path, log_file_path)     :type processor_factory: ([str, List[CallbackRequest], Optional[List[str]], bool]) -> (         AbstractDagFileProcessorProcess     )     :param processor_timeout: How long to wait before timing out a DAG file processor     :type processor_timeout: timedelta     :param dag_ids: if specified, only schedule tasks with these DAG IDs     :type dag_ids: list[str]     :param pickle_dags: whether to pickle DAGs.     :type: pickle_dags: bool     :param async_mode: Whether to start agent in async mode     :type async_mode: bool     """ [5260,6563]
===
delete-tree
---
atom_expr [11745,11772]
    name: self [11745,11749]
    trailer [11749,11764]
        name: _sync_metadata [11750,11764]
    trailer [11764,11772]
        name: result [11765,11771]
===
delete-node
---
simple_stmt [11789,11796]
===
