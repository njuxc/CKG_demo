===
match
---
name: refresh_from_db [22295,22310]
name: refresh_from_db [22295,22310]
===
match
---
suite [28255,29767]
suite [28255,29767]
===
match
---
name: e [46075,46076]
name: e [46075,46076]
===
match
---
simple_stmt [68818,68860]
simple_stmt [69242,69284]
===
match
---
name: test_mode [46305,46314]
name: test_mode [46305,46314]
===
match
---
name: self [12545,12549]
name: self [12545,12549]
===
match
---
string: 'TaskInstance' [30333,30347]
string: 'TaskInstance' [30333,30347]
===
match
---
simple_stmt [46368,46374]
simple_stmt [46368,46374]
===
match
---
suite [49122,49361]
suite [49122,49361]
===
match
---
trailer [9627,9634]
trailer [9627,9634]
===
match
---
trailer [58668,58675]
trailer [59092,59099]
===
match
---
trailer [60865,60873]
trailer [61289,61297]
===
match
---
name: task [45307,45311]
name: task [45307,45311]
===
match
---
name: self [80342,80346]
name: self [80766,80770]
===
match
---
name: query [37149,37154]
name: query [37149,37154]
===
match
---
name: utils [2938,2943]
name: utils [2938,2943]
===
match
---
arglist [43326,43701]
arglist [43326,43701]
===
match
---
or_test [33419,33446]
or_test [33419,33446]
===
match
---
atom_expr [81616,81636]
atom_expr [82040,82060]
===
match
---
simple_stmt [62830,62904]
simple_stmt [63254,63328]
===
match
---
name: error_fd [53445,53453]
name: error_fd [53869,53877]
===
match
---
trailer [39508,39516]
trailer [39508,39516]
===
match
---
operator: = [70032,70033]
operator: = [70456,70457]
===
match
---
operator: = [68235,68236]
operator: = [68659,68660]
===
match
---
simple_stmt [15994,16014]
simple_stmt [15994,16014]
===
match
---
name: self [72094,72098]
name: self [72518,72522]
===
match
---
param [37517,37548]
param [37517,37548]
===
match
---
if_stmt [78200,78493]
if_stmt [78624,78917]
===
match
---
import_from [7822,7863]
import_from [7822,7863]
===
match
---
name: DagRun [8728,8734]
name: DagRun [8728,8734]
===
match
---
simple_stmt [27780,27826]
simple_stmt [27780,27826]
===
match
---
name: session [66583,66590]
name: session [67007,67014]
===
match
---
name: execution_date [12754,12768]
name: execution_date [12754,12768]
===
match
---
name: BooleanClauseList [77207,77224]
name: BooleanClauseList [77631,77648]
===
match
---
parameters [61730,61848]
parameters [62154,62272]
===
match
---
atom_expr [40866,40923]
atom_expr [40866,40923]
===
match
---
name: property [15134,15142]
name: property [15134,15142]
===
match
---
simple_stmt [49873,49900]
simple_stmt [49873,49900]
===
match
---
name: String [11439,11445]
name: String [11439,11445]
===
match
---
trailer [25000,25010]
trailer [25000,25010]
===
match
---
name: is_container [2603,2615]
name: is_container [2603,2615]
===
match
---
dotted_name [1476,1499]
dotted_name [1476,1499]
===
match
---
name: external_trigger [59674,59690]
name: external_trigger [60098,60114]
===
match
---
name: first [81798,81803]
name: first [82222,82227]
===
match
---
string: 'ti' [69749,69753]
string: 'ti' [70173,70177]
===
match
---
name: self [39345,39349]
name: self [39345,39349]
===
match
---
name: log [42383,42386]
name: log [42383,42386]
===
match
---
name: ti [5474,5476]
name: ti [5474,5476]
===
match
---
operator: , [48134,48135]
operator: , [48134,48135]
===
match
---
number: 2 [30741,30742]
number: 2 [30741,30742]
===
match
---
operator: | [34237,34238]
operator: | [34237,34238]
===
match
---
trailer [73189,73367]
trailer [73613,73791]
===
match
---
operator: ** [70491,70493]
operator: ** [70915,70917]
===
match
---
trailer [53896,53919]
trailer [54320,54343]
===
match
---
name: var [61610,61613]
name: var [62034,62037]
===
match
---
operator: , [49777,49778]
operator: , [49777,49778]
===
match
---
decorator [13902,13912]
decorator [13902,13912]
===
match
---
name: state [5477,5482]
name: state [5477,5482]
===
match
---
arith_expr [70862,70881]
arith_expr [71286,71305]
===
match
---
simple_stmt [15590,15781]
simple_stmt [15590,15781]
===
match
---
atom_expr [33434,33446]
atom_expr [33434,33446]
===
match
---
name: self [23935,23939]
name: self [23935,23939]
===
match
---
name: SUCCESS [64596,64603]
name: SUCCESS [65020,65027]
===
match
---
arglist [8061,8241]
arglist [8061,8241]
===
match
---
arglist [4534,4550]
arglist [4534,4550]
===
match
---
name: task [24865,24869]
name: task [24865,24869]
===
match
---
trailer [36741,36747]
trailer [36741,36747]
===
match
---
trailer [24815,24837]
trailer [24815,24837]
===
match
---
argument [68166,68206]
argument [68590,68630]
===
match
---
with_stmt [50604,50727]
with_stmt [50604,50727]
===
match
---
string: "previous_start_date was called" [31818,31850]
string: "previous_start_date was called" [31818,31850]
===
match
---
name: self [50037,50041]
name: self [50037,50041]
===
match
---
return_stmt [80452,80473]
return_stmt [80876,80897]
===
match
---
trailer [54054,54076]
trailer [54478,54500]
===
match
---
param [80652,80656]
param [81076,81080]
===
match
---
name: key [72335,72338]
name: key [72759,72762]
===
match
---
simple_stmt [13287,13307]
simple_stmt [13287,13307]
===
match
---
decorator [62587,62601]
decorator [63011,63025]
===
match
---
operator: == [9010,9012]
operator: == [9010,9012]
===
match
---
atom_expr [21601,21612]
atom_expr [21601,21612]
===
match
---
not_test [40203,40334]
not_test [40203,40334]
===
match
---
argument [41595,41610]
argument [41595,41610]
===
match
---
argument [16794,16825]
argument [16794,16825]
===
match
---
operator: = [49645,49646]
operator: = [49645,49646]
===
match
---
name: staticmethod [62588,62600]
name: staticmethod [63012,63024]
===
match
---
string: "Current context is not equal to the state at context stack. Expected=%s, got=%s" [3886,3967]
string: "Current context is not equal to the state at context stack. Expected=%s, got=%s" [3886,3967]
===
match
---
operator: = [39894,39895]
operator: = [39894,39895]
===
match
---
name: ti [23744,23746]
name: ti [23744,23746]
===
match
---
name: ti [23185,23187]
name: ti [23185,23187]
===
match
---
trailer [54986,54998]
trailer [55410,55422]
===
match
---
operator: , [60987,60988]
operator: , [61411,61412]
===
match
---
operator: @ [21891,21892]
operator: @ [21891,21892]
===
match
---
name: str [79376,79379]
name: str [79800,79803]
===
match
---
trailer [21819,21825]
trailer [21819,21825]
===
match
---
name: timeout [3010,3017]
name: timeout [3010,3017]
===
match
---
name: end_date [79541,79549]
name: end_date [79965,79973]
===
match
---
trailer [80380,80392]
trailer [80804,80816]
===
match
---
operator: = [26189,26190]
operator: = [26189,26190]
===
match
---
trailer [68330,68348]
trailer [68754,68772]
===
match
---
name: TaskInstanceStateType [79093,79114]
name: TaskInstanceStateType [79517,79538]
===
match
---
name: self [22773,22777]
name: self [22773,22777]
===
match
---
name: Log [1989,1992]
name: Log [1989,1992]
===
match
---
operator: , [66355,66356]
operator: , [66779,66780]
===
match
---
trailer [78325,78332]
trailer [78749,78756]
===
match
---
trailer [55552,55570]
trailer [55976,55994]
===
match
---
name: bool [57725,57729]
name: bool [58149,58153]
===
match
---
trailer [37204,37211]
trailer [37204,37211]
===
match
---
arglist [53536,53732]
arglist [53960,54156]
===
match
---
file_input [787,82169]
file_input [787,82593]
===
match
---
atom_expr [72065,72080]
atom_expr [72489,72504]
===
match
---
name: get_dagrun [36851,36861]
name: get_dagrun [36851,36861]
===
match
---
fstring_start: f' [56056,56058]
fstring_start: f' [56480,56482]
===
match
---
trailer [57192,57203]
trailer [57616,57627]
===
match
---
trailer [12503,12511]
trailer [12503,12511]
===
match
---
operator: , [65156,65157]
operator: , [65580,65581]
===
match
---
name: self [42507,42511]
name: self [42507,42511]
===
match
---
dotted_name [1853,1872]
dotted_name [1853,1872]
===
match
---
operator: @ [80559,80560]
operator: @ [80983,80984]
===
match
---
atom_expr [78207,78215]
atom_expr [78631,78639]
===
match
---
name: self [31870,31874]
name: self [31870,31874]
===
match
---
name: airflow [1914,1921]
name: airflow [1914,1921]
===
match
---
parameters [71038,71052]
parameters [71462,71476]
===
match
---
name: ID_LEN [1896,1902]
name: ID_LEN [1896,1902]
===
match
---
simple_stmt [72186,72207]
simple_stmt [72610,72631]
===
match
---
trailer [39207,39233]
trailer [39207,39233]
===
match
---
name: self [39242,39246]
name: self [39242,39246]
===
match
---
name: task_id [5801,5808]
name: task_id [5801,5808]
===
match
---
operator: , [79757,79758]
operator: , [80181,80182]
===
match
---
suite [57301,57467]
suite [57725,57891]
===
match
---
expr_stmt [24667,24690]
expr_stmt [24667,24690]
===
match
---
operator: , [67950,67951]
operator: , [68374,68375]
===
match
---
operator: , [2187,2188]
operator: , [2187,2188]
===
match
---
atom_expr [16545,16557]
atom_expr [16545,16557]
===
match
---
suite [46077,46374]
suite [46077,46374]
===
match
---
decorator [25784,25801]
decorator [25784,25801]
===
match
---
name: self [42290,42294]
name: self [42290,42294]
===
match
---
name: self [32702,32706]
name: self [32702,32706]
===
match
---
name: all [8872,8875]
name: all [8872,8875]
===
match
---
expr_stmt [71396,71464]
expr_stmt [71820,71888]
===
match
---
suite [29570,29654]
suite [29570,29654]
===
match
---
arglist [4596,4605]
arglist [4596,4605]
===
match
---
decorator [80313,80323]
decorator [80737,80747]
===
match
---
name: self [72127,72131]
name: self [72551,72555]
===
match
---
name: ti [6456,6458]
name: ti [6456,6458]
===
match
---
operator: = [53684,53685]
operator: = [54108,54109]
===
match
---
trailer [62438,62442]
trailer [62862,62866]
===
match
---
operator: , [65027,65028]
operator: , [65451,65452]
===
match
---
expr_stmt [68818,68859]
expr_stmt [69242,69283]
===
match
---
operator: , [12010,12011]
operator: , [12010,12011]
===
match
---
atom_expr [67850,67862]
atom_expr [68274,68286]
===
match
---
string: "Received SIGTERM. Terminating subprocesses." [47624,47669]
string: "Received SIGTERM. Terminating subprocesses." [47624,47669]
===
match
---
atom_expr [6419,6442]
atom_expr [6419,6442]
===
match
---
funcdef [67221,67472]
funcdef [67645,67896]
===
match
---
name: ts [59143,59145]
name: ts [59567,59569]
===
match
---
name: execution_date [73549,73563]
name: execution_date [73973,73987]
===
match
---
trailer [47737,47769]
trailer [47737,47769]
===
match
---
suite [8285,8320]
suite [8285,8320]
===
match
---
name: _set_context [77079,77091]
name: _set_context [77503,77515]
===
match
---
name: self [41544,41548]
name: self [41544,41548]
===
match
---
trailer [47962,47969]
trailer [47962,47969]
===
match
---
atom_expr [24266,24315]
atom_expr [24266,24315]
===
match
---
simple_stmt [3767,3807]
simple_stmt [3767,3807]
===
match
---
atom_expr [51492,51513]
atom_expr [51492,51513]
===
match
---
name: schedule [29009,29017]
name: schedule [29009,29017]
===
match
---
name: self [51855,51859]
name: self [51855,51859]
===
match
---
name: self [75639,75643]
name: self [76063,76067]
===
match
---
name: self [79830,79834]
name: self [80254,80258]
===
match
---
name: jobs [7835,7839]
name: jobs [7835,7839]
===
match
---
name: force_fail [57849,57859]
name: force_fail [58273,58283]
===
match
---
name: log [25263,25266]
name: log [25263,25266]
===
match
---
return_stmt [80605,80623]
return_stmt [81029,81047]
===
match
---
simple_stmt [24788,24838]
simple_stmt [24788,24838]
===
match
---
name: Optional [55330,55338]
name: Optional [55754,55762]
===
match
---
operator: < [36801,36802]
operator: < [36801,36802]
===
match
---
name: signal [47793,47799]
name: signal [47793,47799]
===
match
---
trailer [22955,22963]
trailer [22955,22963]
===
match
---
atom_expr [17608,17617]
atom_expr [17608,17617]
===
match
---
suite [62536,62574]
suite [62960,62998]
===
match
---
simple_stmt [20096,20120]
simple_stmt [20096,20120]
===
match
---
trailer [44751,44761]
trailer [44751,44761]
===
match
---
name: prev_execution_date [59826,59845]
name: prev_execution_date [60250,60269]
===
match
---
trailer [36756,36769]
trailer [36756,36769]
===
match
---
name: self [23608,23612]
name: self [23608,23612]
===
match
---
expr_stmt [9199,9223]
expr_stmt [9199,9223]
===
match
---
suite [73884,76514]
suite [74308,76938]
===
match
---
string: 'var' [65041,65046]
string: 'var' [65465,65470]
===
match
---
name: setattr [65723,65730]
name: setattr [66147,66154]
===
match
---
atom_expr [29428,29439]
atom_expr [29428,29439]
===
match
---
name: self [61605,61609]
name: self [62029,62033]
===
match
---
name: path [16123,16127]
name: path [16123,16127]
===
match
---
operator: -> [67507,67509]
operator: -> [67931,67933]
===
match
---
name: context [51899,51906]
name: context [51899,51906]
===
match
---
name: log [49148,49151]
name: log [49148,49151]
===
match
---
name: self [35628,35632]
name: self [35628,35632]
===
match
---
name: exception [57414,57423]
name: exception [57838,57847]
===
match
---
simple_stmt [1201,1217]
simple_stmt [1201,1217]
===
match
---
name: timezone [47078,47086]
name: timezone [47078,47086]
===
match
---
operator: = [53013,53014]
operator: = [53437,53438]
===
match
---
simple_stmt [23690,23718]
simple_stmt [23690,23718]
===
match
---
name: self [75568,75572]
name: self [75992,75996]
===
match
---
suite [4473,4798]
suite [4473,4798]
===
match
---
name: pool [24733,24737]
name: pool [24733,24737]
===
match
---
trailer [36309,36357]
trailer [36309,36357]
===
match
---
param [17355,17375]
param [17355,17375]
===
match
---
suite [13092,13162]
suite [13092,13162]
===
match
---
if_stmt [51788,51978]
if_stmt [51788,52120]
===
match
---
name: session [43990,43997]
name: session [43990,43997]
===
match
---
try_stmt [51243,51438]
try_stmt [51243,51438]
===
match
---
name: self [12484,12488]
name: self [12484,12488]
===
match
---
not_test [28380,28386]
not_test [28380,28386]
===
match
---
arglist [49666,49684]
arglist [49666,49684]
===
match
---
atom_expr [12423,12441]
atom_expr [12423,12441]
===
match
---
trailer [34759,34774]
trailer [34759,34774]
===
match
---
trailer [68389,68416]
trailer [68813,68840]
===
match
---
trailer [50658,50660]
trailer [50658,50660]
===
match
---
name: ApiClient [3224,3233]
name: ApiClient [3224,3233]
===
match
---
name: kubernetes [3033,3043]
name: kubernetes [3033,3043]
===
match
---
trailer [33828,33837]
trailer [33828,33837]
===
match
---
trailer [8655,8858]
trailer [8655,8858]
===
match
---
operator: , [73497,73498]
operator: , [73921,73922]
===
match
---
name: self [45208,45212]
name: self [45208,45212]
===
match
---
trailer [45093,45135]
trailer [45093,45135]
===
match
---
atom_expr [11251,11286]
atom_expr [11251,11286]
===
match
---
name: AirflowSensorTimeout [1741,1761]
name: AirflowSensorTimeout [1741,1761]
===
match
---
dotted_name [3089,3119]
dotted_name [3089,3119]
===
match
---
atom_expr [81567,81586]
atom_expr [81991,82010]
===
match
---
name: warnings [29986,29994]
name: warnings [29986,29994]
===
match
---
tfpdef [67248,67274]
tfpdef [67672,67698]
===
match
---
operator: , [72325,72326]
operator: , [72749,72750]
===
match
---
import_from [1526,1554]
import_from [1526,1554]
===
match
---
expr_stmt [59908,59978]
expr_stmt [60332,60402]
===
match
---
name: start_date [23272,23282]
name: start_date [23272,23282]
===
match
---
expr_stmt [40980,41024]
expr_stmt [40980,41024]
===
match
---
name: prev_attempted_tries [14595,14615]
name: prev_attempted_tries [14595,14615]
===
match
---
operator: , [64674,64675]
operator: , [65098,65099]
===
match
---
name: Variable [61794,61802]
name: Variable [62218,62226]
===
match
---
string: """Load and return error from error file""" [4117,4160]
string: """Load and return error from error file""" [4117,4160]
===
match
---
name: execute [50702,50709]
name: execute [50702,50709]
===
match
---
name: use_default [69707,69718]
name: use_default [70131,70142]
===
match
---
name: extend [19797,19803]
name: extend [19797,19803]
===
match
---
trailer [67722,67736]
trailer [68146,68160]
===
match
---
param [47331,47336]
param [47331,47336]
===
match
---
name: session [32726,32733]
name: session [32726,32733]
===
match
---
atom_expr [3331,3358]
atom_expr [3331,3358]
===
match
---
atom_expr [30769,30810]
atom_expr [30769,30810]
===
match
---
operator: = [13261,13262]
operator: = [13261,13262]
===
match
---
operator: == [39500,39502]
operator: == [39500,39502]
===
match
---
atom_expr [5845,5866]
atom_expr [5845,5866]
===
match
---
name: timedelta [968,977]
name: timedelta [968,977]
===
match
---
param [37703,37730]
param [37703,37730]
===
match
---
operator: = [31896,31897]
operator: = [31896,31897]
===
match
---
atom_expr [24130,24148]
atom_expr [24130,24148]
===
match
---
trailer [59048,59050]
trailer [59472,59474]
===
match
---
operator: + [42365,42366]
operator: + [42365,42366]
===
match
---
argument [57804,57815]
argument [58228,58239]
===
match
---
expr_stmt [15994,16013]
expr_stmt [15994,16013]
===
match
---
operator: , [42348,42349]
operator: , [42348,42349]
===
match
---
name: session [55360,55367]
name: session [55784,55791]
===
match
---
name: read [71232,71236]
name: read [71656,71660]
===
match
---
name: Exception [51354,51363]
name: Exception [51354,51363]
===
match
---
string: """Handle Failure for the TaskInstance""" [55397,55438]
string: """Handle Failure for the TaskInstance""" [55821,55862]
===
match
---
suite [30349,30811]
suite [30349,30811]
===
match
---
name: self [58248,58252]
name: self [58672,58676]
===
match
---
name: commit [40360,40366]
name: commit [40360,40366]
===
match
---
string: """         The task instance for the task that ran before this task instance.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [27983,28211]
string: """         The task instance for the task that ran before this task instance.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [27983,28211]
===
match
---
name: min_backoff [35891,35902]
name: min_backoff [35891,35902]
===
match
---
string: "XCom data cleared" [25536,25555]
string: "XCom data cleared" [25536,25555]
===
match
---
expr_stmt [60470,60530]
expr_stmt [60894,60954]
===
match
---
param [4418,4434]
param [4418,4434]
===
match
---
funcdef [9459,9700]
funcdef [9459,9700]
===
match
---
operator: , [41610,41611]
operator: , [41610,41611]
===
match
---
return_stmt [80530,80553]
return_stmt [80954,80977]
===
match
---
suite [14622,15128]
suite [14622,15128]
===
match
---
string: "wb" [4546,4550]
string: "wb" [4546,4550]
===
match
---
name: DagRun [8628,8634]
name: DagRun [8628,8634]
===
match
---
suite [21839,21865]
suite [21839,21865]
===
match
---
name: context [45298,45305]
name: context [45298,45305]
===
match
---
tfpdef [62638,62647]
tfpdef [63062,63071]
===
match
---
trailer [14551,14563]
trailer [14551,14563]
===
match
---
argument [41427,41460]
argument [41427,41460]
===
match
---
simple_stmt [20761,20806]
simple_stmt [20761,20806]
===
match
---
expr_stmt [12450,12475]
expr_stmt [12450,12475]
===
match
---
decorated [80697,80792]
decorated [81121,81216]
===
match
---
import_from [1594,1847]
import_from [1594,1847]
===
match
---
simple_stmt [13371,13390]
simple_stmt [13371,13390]
===
match
---
name: ti [23860,23862]
name: ti [23860,23862]
===
match
---
operator: , [19525,19526]
operator: , [19525,19526]
===
match
---
operator: = [79580,79581]
operator: = [80004,80005]
===
match
---
suite [53763,53933]
suite [54187,54357]
===
match
---
trailer [33703,33887]
trailer [33703,33887]
===
match
---
trailer [7392,7396]
trailer [7392,7396]
===
match
---
raise_stmt [65923,66298]
raise_stmt [66347,66722]
===
match
---
name: execution_date [12916,12930]
name: execution_date [12916,12930]
===
match
---
param [32708,32725]
param [32708,32725]
===
match
---
name: utils [2504,2509]
name: utils [2504,2509]
===
match
---
test [53784,53850]
test [54208,54274]
===
match
---
subscriptlist [55217,55231]
subscriptlist [55641,55655]
===
match
---
expr_stmt [13620,13636]
expr_stmt [13620,13636]
===
match
---
name: self [47531,47535]
name: self [47531,47535]
===
match
---
expr_stmt [31285,31345]
expr_stmt [31285,31345]
===
match
---
string: 'TaskInstanceKey' [9751,9768]
string: 'TaskInstanceKey' [9751,9768]
===
match
---
name: self [23766,23770]
name: self [23766,23770]
===
match
---
name: self [25762,25766]
name: self [25762,25766]
===
match
---
trailer [48223,48231]
trailer [48223,48231]
===
match
---
parameters [62620,62738]
parameters [63044,63162]
===
match
---
operator: = [70652,70653]
operator: = [71076,71077]
===
match
---
funcdef [22291,24316]
funcdef [22291,24316]
===
match
---
atom_expr [63866,63904]
atom_expr [64290,64328]
===
match
---
name: session [29544,29551]
name: session [29544,29551]
===
match
---
name: utils [2729,2734]
name: utils [2729,2734]
===
match
---
import_as_names [958,977]
import_as_names [958,977]
===
match
---
fstring_expr [60845,60858]
fstring_expr [61269,61282]
===
match
---
trailer [13034,13074]
trailer [13034,13074]
===
match
---
trailer [5931,5949]
trailer [5931,5949]
===
match
---
operator: , [53066,53067]
operator: , [53490,53491]
===
match
---
name: task [43028,43032]
name: task [43028,43032]
===
match
---
operator: , [37211,37212]
operator: , [37211,37212]
===
match
---
simple_stmt [60077,60128]
simple_stmt [60501,60552]
===
match
---
simple_stmt [9991,10066]
simple_stmt [9991,10066]
===
match
---
name: log [1978,1981]
name: log [1978,1981]
===
match
---
trailer [50001,50042]
trailer [50001,50042]
===
match
---
atom_expr [77154,77192]
atom_expr [77578,77616]
===
match
---
string: """Return task instance primary key part of the key""" [9323,9377]
string: """Return task instance primary key part of the key""" [9323,9377]
===
match
---
suite [19948,20002]
suite [19948,20002]
===
match
---
atom_expr [26178,26188]
atom_expr [26178,26188]
===
match
---
trailer [51309,51329]
trailer [51309,51329]
===
match
---
trailer [50791,50799]
trailer [50791,50799]
===
match
---
atom_expr [51944,51977]
atom_expr [51969,52002]
===
match
---
trailer [67434,67439]
trailer [67858,67863]
===
match
---
atom_expr [60965,61021]
atom_expr [61389,61445]
===
match
---
operator: = [60085,60086]
operator: = [60509,60510]
===
match
---
operator: = [58979,58980]
operator: = [59403,59404]
===
match
---
simple_stmt [70638,70682]
simple_stmt [71062,71106]
===
match
---
name: all [21763,21766]
name: all [21763,21766]
===
match
---
name: Column [11224,11230]
name: Column [11224,11230]
===
match
---
name: DagRun [8406,8412]
name: DagRun [8406,8412]
===
match
---
name: on_execute_callback [51268,51287]
name: on_execute_callback [51268,51287]
===
match
---
name: UndefinedError [1260,1274]
name: UndefinedError [1260,1274]
===
match
---
funcdef [14591,15128]
funcdef [14591,15128]
===
match
---
name: max_retry_delay [36447,36462]
name: max_retry_delay [36447,36462]
===
match
---
param [15387,15416]
param [15387,15416]
===
match
---
atom_expr [7914,7937]
atom_expr [7914,7937]
===
match
---
suite [4558,4798]
suite [4558,4798]
===
match
---
name: ignore_ti_state [16794,16809]
name: ignore_ti_state [16794,16809]
===
match
---
name: context [51845,51852]
name: context [51845,51852]
===
match
---
parameters [62529,62535]
parameters [62953,62959]
===
match
---
trailer [25510,25512]
trailer [25510,25512]
===
match
---
name: PodGenerator [67710,67722]
name: PodGenerator [68134,68146]
===
match
---
atom_expr [54832,54855]
atom_expr [55256,55279]
===
match
---
name: job_id [39359,39365]
name: job_id [39359,39365]
===
match
---
name: session [75805,75812]
name: session [76229,76236]
===
match
---
name: RenderedTaskInstanceFields [47446,47472]
name: RenderedTaskInstanceFields [47446,47472]
===
match
---
trailer [73385,73603]
trailer [73809,74027]
===
match
---
operator: , [11963,11964]
operator: , [11963,11964]
===
match
---
name: test_mode [57817,57826]
name: test_mode [58241,58250]
===
match
---
expr_stmt [16444,16460]
expr_stmt [16444,16460]
===
match
---
name: KubeConfig [3127,3137]
name: KubeConfig [3127,3137]
===
match
---
name: dag_id [78644,78650]
name: dag_id [79068,79074]
===
match
---
expr_stmt [69732,69760]
expr_stmt [70156,70184]
===
match
---
name: task [60940,60944]
name: task [61364,61368]
===
match
---
return_stmt [31997,32076]
return_stmt [31997,32076]
===
match
---
trailer [12549,12567]
trailer [12549,12567]
===
match
---
name: dep_context [34173,34184]
name: dep_context [34173,34184]
===
match
---
name: dag_id [8786,8792]
name: dag_id [8786,8792]
===
match
---
trailer [48520,48573]
trailer [48520,48573]
===
match
---
name: file_path [17425,17434]
name: file_path [17425,17434]
===
match
---
atom_expr [75639,75658]
atom_expr [76063,76082]
===
match
---
name: ignore_all_deps [17191,17206]
name: ignore_all_deps [17191,17206]
===
match
---
atom_expr [56173,56209]
atom_expr [56597,56633]
===
match
---
simple_stmt [58972,59017]
simple_stmt [59396,59441]
===
match
---
operator: , [56093,56094]
operator: , [56517,56518]
===
match
---
operator: = [39993,39994]
operator: = [39993,39994]
===
match
---
trailer [28967,28972]
trailer [28967,28972]
===
match
---
name: ti [23388,23390]
name: ti [23388,23390]
===
match
---
operator: = [41619,41620]
operator: = [41619,41620]
===
match
---
name: execution_date [7556,7570]
name: execution_date [7556,7570]
===
match
---
expr_stmt [60011,60032]
expr_stmt [60435,60456]
===
match
---
name: execution_date [28885,28899]
name: execution_date [28885,28899]
===
match
---
atom_expr [12392,12405]
atom_expr [12392,12405]
===
match
---
simple_stmt [69732,69761]
simple_stmt [70156,70185]
===
match
---
name: bool [52584,52588]
name: bool [53008,53012]
===
match
---
operator: = [77603,77604]
operator: = [78027,78028]
===
match
---
operator: , [16932,16933]
operator: , [16932,16933]
===
match
---
operator: = [37723,37724]
operator: = [37723,37724]
===
match
---
arith_expr [42350,42368]
arith_expr [42350,42368]
===
match
---
trailer [48099,48160]
trailer [48099,48160]
===
match
---
trailer [80854,80861]
trailer [81278,81285]
===
match
---
name: TaskInstance [28924,28936]
name: TaskInstance [28924,28936]
===
match
---
trailer [46251,46267]
trailer [46251,46267]
===
match
---
simple_stmt [42290,42370]
simple_stmt [42290,42370]
===
match
---
operator: = [61952,61953]
operator: = [62376,62377]
===
match
---
tfpdef [37432,37453]
tfpdef [37432,37453]
===
match
---
name: property [80221,80229]
name: property [80645,80653]
===
match
---
name: Exception [4453,4462]
name: Exception [4453,4462]
===
match
---
atom_expr [80740,80753]
atom_expr [81164,81177]
===
match
---
trailer [34231,34236]
trailer [34231,34236]
===
match
---
trailer [16235,16252]
trailer [16235,16252]
===
match
---
name: AirflowException [65929,65945]
name: AirflowException [66353,66369]
===
match
---
trailer [6407,6417]
trailer [6407,6417]
===
match
---
operator: = [39227,39228]
operator: = [39227,39228]
===
match
---
suite [4632,4798]
suite [4632,4798]
===
match
---
name: Union [73686,73691]
name: Union [74110,74115]
===
match
---
name: first [77643,77648]
name: first [78067,78072]
===
match
---
name: relationship [1415,1427]
name: relationship [1415,1427]
===
match
---
operator: = [15371,15372]
operator: = [15371,15372]
===
match
---
argument [53616,53629]
argument [54040,54053]
===
match
---
trailer [58860,58920]
trailer [59284,59344]
===
match
---
name: path [16331,16335]
name: path [16331,16335]
===
match
---
atom_expr [8728,8760]
atom_expr [8728,8760]
===
match
---
operator: , [81081,81082]
operator: , [81505,81506]
===
match
---
operator: = [11222,11223]
operator: = [11222,11223]
===
match
---
operator: = [25070,25071]
operator: = [25070,25071]
===
match
---
atom_expr [36751,36769]
atom_expr [36751,36769]
===
match
---
name: airflow_context_vars [48620,48640]
name: airflow_context_vars [48620,48640]
===
match
---
name: ignore_ti_state [53202,53217]
name: ignore_ti_state [53626,53641]
===
match
---
atom_expr [4309,4327]
atom_expr [4309,4327]
===
match
---
operator: = [33462,33463]
operator: = [33462,33463]
===
match
---
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [69622,69684]
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [70046,70108]
===
match
---
name: TR [7353,7355]
name: TR [7353,7355]
===
match
---
param [73803,73837]
param [74227,74261]
===
match
---
trailer [7776,7784]
trailer [7776,7784]
===
match
---
name: check_and_change_state_before_execution [52953,52992]
name: check_and_change_state_before_execution [53377,53416]
===
match
---
expr_stmt [71220,71238]
expr_stmt [71644,71662]
===
match
---
atom [35421,35442]
atom [35421,35442]
===
match
---
name: get_failed_dep_statuses [33577,33600]
name: get_failed_dep_statuses [33577,33600]
===
match
---
expr_stmt [5972,5999]
expr_stmt [5972,5999]
===
match
---
name: executor_config [80963,80978]
name: executor_config [81387,81402]
===
match
---
trailer [80205,80214]
trailer [80629,80638]
===
match
---
name: dag_run [67050,67057]
name: dag_run [67474,67481]
===
match
---
name: cmd [20206,20209]
name: cmd [20206,20209]
===
match
---
arglist [26122,26168]
arglist [26122,26168]
===
match
---
name: self [24667,24671]
name: self [24667,24671]
===
match
---
name: execution_date [73123,73137]
name: execution_date [73547,73561]
===
match
---
name: sqlalchemy [1476,1486]
name: sqlalchemy [1476,1486]
===
match
---
name: email [71846,71851]
name: email [72270,72275]
===
match
---
operator: , [71577,71578]
operator: , [72001,72002]
===
match
---
operator: , [12351,12352]
operator: , [12351,12352]
===
match
---
name: self [79787,79791]
name: self [80211,80215]
===
match
---
name: failed [33900,33906]
name: failed [33900,33906]
===
match
---
name: State [5486,5491]
name: State [5486,5491]
===
match
---
trailer [58850,58860]
trailer [59274,59284]
===
match
---
name: self [43669,43673]
name: self [43669,43673]
===
match
---
expr_stmt [23157,23173]
expr_stmt [23157,23173]
===
match
---
string: "--raw" [20218,20225]
string: "--raw" [20218,20225]
===
match
---
atom_expr [78505,78539]
atom_expr [78929,78963]
===
match
---
operator: , [77174,77175]
operator: , [77598,77599]
===
match
---
name: state [6459,6464]
name: state [6459,6464]
===
match
---
name: attr [43105,43109]
name: attr [43105,43109]
===
match
---
name: getpid [44967,44973]
name: getpid [44967,44973]
===
match
---
name: start_date [72070,72080]
name: start_date [72494,72504]
===
match
---
name: self [59875,59879]
name: self [60299,60303]
===
match
---
name: log [42880,42883]
name: log [42880,42883]
===
match
---
name: result [76175,76181]
name: result [76599,76605]
===
match
---
name: verbose [53006,53013]
name: verbose [53430,53437]
===
match
---
operator: , [12383,12384]
operator: , [12383,12384]
===
match
---
simple_stmt [47062,47096]
simple_stmt [47062,47096]
===
match
---
name: timezone [55991,55999]
name: timezone [56415,56423]
===
match
---
name: provide_session [22271,22286]
name: provide_session [22271,22286]
===
match
---
atom_expr [77900,77975]
atom_expr [78324,78399]
===
match
---
trailer [44786,44804]
trailer [44786,44804]
===
match
---
if_stmt [16180,16315]
if_stmt [16180,16315]
===
match
---
name: and_ [7140,7144]
name: and_ [7140,7144]
===
match
---
operator: @ [13902,13903]
operator: @ [13902,13903]
===
match
---
atom_expr [79489,79502]
atom_expr [79913,79926]
===
match
---
name: dagrun [8392,8398]
name: dagrun [8392,8398]
===
match
---
funcdef [63159,63308]
funcdef [63583,63732]
===
match
---
parameters [14524,14537]
parameters [14524,14537]
===
match
---
trailer [70866,70877]
trailer [71290,71301]
===
match
---
trailer [49665,49685]
trailer [49665,49685]
===
match
---
operator: , [41593,41594]
operator: , [41593,41594]
===
match
---
atom_expr [81776,81805]
atom_expr [82200,82229]
===
match
---
name: try_number [70867,70877]
name: try_number [71291,71301]
===
match
---
name: task [27373,27377]
name: task [27373,27377]
===
match
---
name: error_file [4534,4544]
name: error_file [4534,4544]
===
match
---
string: 'dag' [15974,15979]
string: 'dag' [15974,15979]
===
match
---
name: modded_hash [36310,36321]
name: modded_hash [36310,36321]
===
match
---
operator: , [62879,62880]
operator: , [63303,63304]
===
match
---
name: self [52039,52043]
name: self [52181,52185]
===
match
---
trailer [49151,49159]
trailer [49151,49159]
===
match
---
trailer [31238,31276]
trailer [31238,31276]
===
match
---
number: 0 [13305,13306]
number: 0 [13305,13306]
===
match
---
name: dates [8794,8799]
name: dates [8794,8799]
===
match
---
return_stmt [78564,78839]
return_stmt [78988,79263]
===
match
---
name: jinja_env [70974,70983]
name: jinja_env [71398,71407]
===
match
---
atom_expr [27681,27735]
atom_expr [27681,27735]
===
match
---
name: dag [28236,28239]
name: dag [28236,28239]
===
match
---
comparison [36774,36820]
comparison [36774,36820]
===
match
---
trailer [19725,19752]
trailer [19725,19752]
===
match
---
not_test [8263,8284]
not_test [8263,8284]
===
match
---
fstring_string: ti.finish. [46960,46970]
fstring_string: ti.finish. [46960,46970]
===
match
---
name: task [24951,24955]
name: task [24951,24955]
===
match
---
name: dag [13061,13064]
name: dag [13061,13064]
===
match
---
tfpdef [31513,31529]
tfpdef [31513,31529]
===
match
---
name: str [61754,61757]
name: str [62178,62181]
===
match
---
trailer [70135,70145]
trailer [70559,70569]
===
match
---
string: 'TaskInstanceKey' [9480,9497]
string: 'TaskInstanceKey' [9480,9497]
===
match
---
atom_expr [11885,11929]
atom_expr [11885,11929]
===
match
---
name: result [51096,51102]
name: result [51096,51102]
===
match
---
expr_stmt [24928,24971]
expr_stmt [24928,24971]
===
match
---
name: test_mode [55242,55251]
name: test_mode [55666,55675]
===
match
---
name: force_fail [55284,55294]
name: force_fail [55708,55718]
===
match
---
name: priority_weight [23886,23901]
name: priority_weight [23886,23901]
===
match
---
atom [46794,46824]
atom [46794,46824]
===
match
---
param [21928,21940]
param [21928,21940]
===
match
---
atom_expr [4770,4797]
atom_expr [4770,4797]
===
match
---
name: context [48378,48385]
name: context [48378,48385]
===
match
---
string: """         Checks on whether the task instance is in the right state and timeframe         to be retried.         """ [36603,36721]
string: """         Checks on whether the task instance is in the right state and timeframe         to be retried.         """ [36603,36721]
===
match
---
operator: = [15545,15546]
operator: = [15545,15546]
===
match
---
if_stmt [28248,29767]
if_stmt [28248,29767]
===
match
---
suite [77538,77563]
suite [77962,77987]
===
match
---
operator: , [21172,21173]
operator: , [21172,21173]
===
match
---
name: mark_success [52731,52743]
name: mark_success [53155,53167]
===
match
---
simple_stmt [60353,60404]
simple_stmt [60777,60828]
===
match
---
name: DagRun [82058,82064]
name: DagRun [82482,82488]
===
match
---
and_test [5837,5866]
and_test [5837,5866]
===
match
---
name: relative_fileloc [16298,16314]
name: relative_fileloc [16298,16314]
===
match
---
name: reduced [9463,9470]
name: reduced [9463,9470]
===
match
---
operator: = [73863,73864]
operator: = [74287,74288]
===
match
---
trailer [13215,13231]
trailer [13215,13231]
===
match
---
trailer [7480,7482]
trailer [7480,7482]
===
match
---
operator: = [57157,57158]
operator: = [57581,57582]
===
match
---
name: platform [2802,2810]
name: platform [2802,2810]
===
match
---
operator: , [71860,71861]
operator: , [72284,72285]
===
match
---
operator: , [17521,17522]
operator: , [17521,17522]
===
match
---
atom_expr [58629,58644]
atom_expr [59053,59068]
===
match
---
name: jinja_context [70695,70708]
name: jinja_context [71119,71132]
===
match
---
name: Session [73855,73862]
name: Session [74279,74286]
===
match
---
operator: = [40906,40907]
operator: = [40906,40907]
===
match
---
operator: = [55301,55302]
operator: = [55725,55726]
===
match
---
trailer [47945,48001]
trailer [47945,48001]
===
match
---
operator: , [40058,40059]
operator: , [40058,40059]
===
match
---
trailer [65703,65705]
trailer [66127,66129]
===
match
---
name: str [17613,17616]
name: str [17613,17616]
===
match
---
trailer [51906,51919]
trailer [51906,51919]
===
match
---
simple_stmt [47482,47523]
simple_stmt [47482,47523]
===
match
---
trailer [81628,81636]
trailer [82052,82060]
===
match
---
trailer [16050,16060]
trailer [16050,16060]
===
match
---
name: property [29794,29802]
name: property [29794,29802]
===
match
---
trailer [33539,33545]
trailer [33539,33545]
===
match
---
trailer [56180,56184]
trailer [56604,56608]
===
match
---
name: previous_start_date_success [32100,32127]
name: previous_start_date_success [32100,32127]
===
match
---
name: task_id [60866,60873]
name: task_id [61290,61297]
===
match
---
atom_expr [29706,29766]
atom_expr [29706,29766]
===
match
---
name: xcom [2160,2164]
name: xcom [2160,2164]
===
match
---
name: k [48536,48537]
name: k [48536,48537]
===
match
---
name: ignore_schedule [29344,29359]
name: ignore_schedule [29344,29359]
===
match
---
name: context [52471,52478]
name: context [52780,52787]
===
match
---
trailer [76114,76122]
trailer [76538,76546]
===
match
---
import_from [37047,37087]
import_from [37047,37087]
===
match
---
trailer [32145,32164]
trailer [32145,32164]
===
match
---
atom_expr [5764,5773]
atom_expr [5764,5773]
===
match
---
name: get_previous_ti [30254,30269]
name: get_previous_ti [30254,30269]
===
match
---
atom_expr [70654,70681]
atom_expr [71078,71105]
===
match
---
name: first_task_id [78243,78256]
name: first_task_id [78667,78680]
===
match
---
trailer [63549,63577]
trailer [63973,64001]
===
match
---
trailer [47004,47010]
trailer [47004,47010]
===
match
---
name: state [8926,8931]
name: state [8926,8931]
===
match
---
atom_expr [71825,71875]
atom_expr [72249,72299]
===
match
---
atom_expr [57159,57178]
atom_expr [57583,57602]
===
match
---
string: "started running, please use 'airflow tasks render' for debugging the " [66150,66221]
string: "started running, please use 'airflow tasks render' for debugging the " [66574,66645]
===
match
---
operator: , [73695,73696]
operator: , [74119,74120]
===
match
---
if_stmt [58025,58210]
if_stmt [58449,58634]
===
match
---
string: '%Y%m%dT%H%M%S' [60621,60636]
string: '%Y%m%dT%H%M%S' [61045,61060]
===
match
---
atom_expr [37200,37211]
atom_expr [37200,37211]
===
match
---
simple_stmt [68707,68747]
simple_stmt [69131,69171]
===
match
---
name: bool [52709,52713]
name: bool [53133,53137]
===
match
---
operator: = [32572,32573]
operator: = [32572,32573]
===
match
---
atom_expr [80459,80473]
atom_expr [80883,80897]
===
match
---
atom_expr [75568,75579]
atom_expr [75992,76003]
===
match
---
operator: , [47807,47808]
operator: , [47807,47808]
===
match
---
expr_stmt [3288,3324]
expr_stmt [3288,3324]
===
match
---
trailer [25322,25329]
trailer [25322,25329]
===
match
---
atom_expr [44984,45003]
atom_expr [44984,45003]
===
match
---
name: self [14616,14620]
name: self [14616,14620]
===
match
---
atom_expr [39374,39387]
atom_expr [39374,39387]
===
match
---
operator: = [33633,33634]
operator: = [33633,33634]
===
match
---
atom_expr [48544,48572]
atom_expr [48544,48572]
===
match
---
fstring_start: f' [47946,47948]
fstring_start: f' [47946,47948]
===
match
---
trailer [27710,27718]
trailer [27710,27718]
===
match
---
dotted_name [2043,2072]
dotted_name [2043,2072]
===
match
---
trailer [73705,73710]
trailer [74129,74134]
===
match
---
operator: = [19489,19490]
operator: = [19489,19490]
===
match
---
name: key [73399,73402]
name: key [73823,73826]
===
match
---
comparison [39489,39516]
comparison [39489,39516]
===
match
---
arglist [4782,4796]
arglist [4782,4796]
===
match
---
param [80583,80587]
param [81007,81011]
===
match
---
atom_expr [77904,77912]
atom_expr [78328,78336]
===
match
---
trailer [3310,3319]
trailer [3310,3319]
===
match
---
trailer [36545,36554]
trailer [36545,36554]
===
match
---
atom_expr [9393,9404]
atom_expr [9393,9404]
===
match
---
trailer [27474,27482]
trailer [27474,27482]
===
match
---
expr_stmt [71330,71383]
expr_stmt [71754,71807]
===
match
---
operator: = [16449,16450]
operator: = [16449,16450]
===
match
---
trailer [78684,78692]
trailer [79108,79116]
===
match
---
lambdef [5397,5442]
lambdef [5397,5442]
===
match
---
name: task_id [79385,79392]
name: task_id [79809,79816]
===
match
---
trailer [47199,47222]
trailer [47199,47222]
===
match
---
trailer [11652,11678]
trailer [11652,11678]
===
match
---
trailer [22130,22136]
trailer [22130,22136]
===
match
---
param [37471,37508]
param [37471,37508]
===
match
---
name: or_ [78571,78574]
name: or_ [78995,78998]
===
match
---
trailer [22126,22130]
trailer [22126,22130]
===
match
---
arglist [41769,41995]
arglist [41769,41995]
===
match
---
name: TaskInstanceKey [9086,9101]
name: TaskInstanceKey [9086,9101]
===
match
---
atom [35415,35443]
atom [35415,35443]
===
match
---
name: State [32636,32641]
name: State [32636,32641]
===
match
---
name: run_id [58546,58552]
name: run_id [58970,58976]
===
match
---
atom_expr [17577,17590]
atom_expr [17577,17590]
===
match
---
expr_stmt [79093,79144]
expr_stmt [79517,79568]
===
match
---
testlist_comp [46795,46823]
testlist_comp [46795,46823]
===
match
---
operator: , [22979,22980]
operator: , [22979,22980]
===
match
---
argument [70069,70099]
argument [70493,70523]
===
match
---
decorated [32082,32651]
decorated [32082,32651]
===
match
---
trailer [31554,31573]
trailer [31554,31573]
===
match
---
name: tomorrow_ds_nodash [60771,60789]
name: tomorrow_ds_nodash [61195,61213]
===
match
---
name: state [14386,14391]
name: state [14386,14391]
===
match
---
name: task_id [25388,25395]
name: task_id [25388,25395]
===
match
---
trailer [28870,28879]
trailer [28870,28879]
===
match
---
name: first_task_id [77672,77685]
name: first_task_id [78096,78109]
===
match
---
atom_expr [70270,70295]
atom_expr [70694,70719]
===
match
---
arglist [62443,62470]
arglist [62867,62894]
===
match
---
trailer [48851,48878]
trailer [48851,48878]
===
match
---
name: dry_run [54160,54167]
name: dry_run [54584,54591]
===
match
---
trailer [39493,39499]
trailer [39493,39499]
===
match
---
atom_expr [44930,44944]
atom_expr [44930,44944]
===
match
---
name: set_current_context [3461,3480]
name: set_current_context [3461,3480]
===
match
---
name: str [17086,17089]
name: str [17086,17089]
===
match
---
atom_expr [8539,8554]
atom_expr [8539,8554]
===
match
---
atom_expr [72186,72199]
atom_expr [72610,72623]
===
match
---
operator: @ [62587,62588]
operator: @ [63011,63012]
===
match
---
operator: == [26746,26748]
operator: == [26746,26748]
===
match
---
atom [59203,59239]
atom [59627,59663]
===
match
---
name: sha1 [35543,35547]
name: sha1 [35543,35547]
===
match
---
name: get_email_subject_content [71763,71788]
name: get_email_subject_content [72187,72212]
===
match
---
string: 'Immediate failure requested. ' [57204,57235]
string: 'Immediate failure requested. ' [57628,57659]
===
match
---
atom_expr [50158,50174]
atom_expr [50158,50174]
===
match
---
trailer [59957,59978]
trailer [60381,60402]
===
match
---
simple_stmt [52403,52432]
simple_stmt [52687,52716]
===
match
---
operator: = [60841,60842]
operator: = [61265,61266]
===
match
---
name: airflow [66438,66445]
name: airflow [66862,66869]
===
match
---
name: filter [76750,76756]
name: filter [77174,77180]
===
match
---
simple_stmt [19793,19835]
simple_stmt [19793,19835]
===
match
---
suite [53399,53419]
suite [53823,53843]
===
match
---
expr_stmt [11179,11210]
expr_stmt [11179,11210]
===
match
---
operator: = [60361,60362]
operator: = [60785,60786]
===
match
---
trailer [37242,37257]
trailer [37242,37257]
===
match
---
and_test [57270,57300]
and_test [57694,57724]
===
match
---
trailer [11407,11416]
trailer [11407,11416]
===
match
---
name: self [52128,52132]
name: self [52270,52274]
===
match
---
trailer [68775,68786]
trailer [69199,69210]
===
match
---
dictorsetmaker [76108,76230]
dictorsetmaker [76532,76654]
===
match
---
name: post_execute [49749,49761]
name: post_execute [49749,49761]
===
match
---
tfpdef [17191,17212]
tfpdef [17191,17212]
===
match
---
trailer [36818,36820]
trailer [36818,36820]
===
match
---
name: params [60926,60932]
name: params [61350,61356]
===
match
---
operator: , [9669,9670]
operator: , [9669,9670]
===
match
---
atom_expr [42350,42364]
atom_expr [42350,42364]
===
match
---
return_stmt [36730,36820]
return_stmt [36730,36820]
===
match
---
decorated [29793,30272]
decorated [29793,30272]
===
match
---
trailer [62423,62427]
trailer [62847,62851]
===
match
---
argument [68043,68106]
argument [68467,68530]
===
match
---
param [72424,72448]
param [72848,72872]
===
match
---
operator: , [52642,52643]
operator: , [53066,53067]
===
match
---
simple_stmt [21494,21779]
simple_stmt [21494,21779]
===
match
---
name: extend [20046,20052]
name: extend [20046,20052]
===
match
---
operator: , [46048,46049]
operator: , [46048,46049]
===
match
---
trailer [7474,7480]
trailer [7474,7480]
===
match
---
if_stmt [20236,20298]
if_stmt [20236,20298]
===
match
---
name: str [27903,27906]
name: str [27903,27906]
===
match
---
operator: = [80031,80032]
operator: = [80455,80456]
===
match
---
name: timeout [50609,50616]
name: timeout [50609,50616]
===
match
---
operator: , [11875,11876]
operator: , [11875,11876]
===
match
---
atom_expr [39242,39256]
atom_expr [39242,39256]
===
match
---
name: jinja_env [70191,70200]
name: jinja_env [70615,70624]
===
match
---
simple_stmt [81145,81505]
simple_stmt [81569,81929]
===
match
---
name: session [45012,45019]
name: session [45012,45019]
===
match
---
operator: = [20765,20766]
operator: = [20765,20766]
===
match
---
string: "Marking success for %s on %s" [42889,42919]
string: "Marking success for %s on %s" [42889,42919]
===
match
---
name: session [34098,34105]
name: session [34098,34105]
===
match
---
name: query [7892,7897]
name: query [7892,7897]
===
match
---
trailer [39417,39421]
trailer [39417,39421]
===
match
---
atom_expr [67969,67988]
atom_expr [68393,68412]
===
match
---
trailer [15967,15972]
trailer [15967,15972]
===
match
---
argument [75624,75658]
argument [76048,76082]
===
match
---
atom_expr [58412,58421]
atom_expr [58836,58845]
===
match
---
argument [53035,53066]
argument [53459,53490]
===
match
---
trailer [71077,71088]
trailer [71501,71512]
===
match
---
name: task [71930,71934]
name: task [72354,72358]
===
match
---
operator: = [73525,73526]
operator: = [73949,73950]
===
match
---
name: dates [8754,8759]
name: dates [8754,8759]
===
match
---
name: self [43264,43268]
name: self [43264,43268]
===
match
---
operator: + [20883,20884]
operator: + [20883,20884]
===
match
---
funcdef [73630,76514]
funcdef [74054,76938]
===
match
---
if_stmt [76453,76514]
if_stmt [76877,76938]
===
match
---
string: "Failed when executing execute callback" [51396,51436]
string: "Failed when executing execute callback" [51396,51436]
===
match
---
name: dep_context [34321,34332]
name: dep_context [34321,34332]
===
match
---
name: AirflowTaskTimeout [50746,50764]
name: AirflowTaskTimeout [50746,50764]
===
match
---
trailer [60693,60702]
trailer [61117,61126]
===
match
---
name: default [11320,11327]
name: default [11320,11327]
===
match
---
operator: = [62428,62429]
operator: = [62852,62853]
===
match
---
name: next_ds_nodash [60140,60154]
name: next_ds_nodash [60564,60578]
===
match
---
trailer [42046,42061]
trailer [42046,42061]
===
match
---
operator: = [12592,12593]
operator: = [12592,12593]
===
match
---
arglist [44805,44829]
arglist [44805,44829]
===
match
---
name: instance [31382,31390]
name: instance [31382,31390]
===
match
---
trailer [60811,60820]
trailer [61235,61244]
===
match
---
trailer [19879,19886]
trailer [19879,19886]
===
match
---
trailer [78140,78148]
trailer [78564,78572]
===
match
---
param [54219,54224]
param [54643,54648]
===
match
---
name: models [66446,66452]
name: models [66870,66876]
===
match
---
atom_expr [8614,8877]
atom_expr [8614,8877]
===
match
---
name: self [26532,26536]
name: self [26532,26536]
===
match
---
name: Optional [73737,73745]
name: Optional [74161,74169]
===
match
---
name: try_number [6608,6618]
name: try_number [6608,6618]
===
match
---
atom_expr [29503,29552]
atom_expr [29503,29552]
===
match
---
name: execution_date [77929,77943]
name: execution_date [78353,78367]
===
match
---
name: kubernetes [3155,3165]
name: kubernetes [3155,3165]
===
match
---
name: xcom [76394,76398]
name: xcom [76818,76822]
===
match
---
return_stmt [80194,80214]
return_stmt [80618,80638]
===
match
---
operator: , [68490,68491]
operator: , [68914,68915]
===
match
---
name: task_id [27566,27573]
name: task_id [27566,27573]
===
match
---
import_from [67568,67640]
import_from [67992,68064]
===
match
---
name: kubernetes_helper_functions [67592,67619]
name: kubernetes_helper_functions [68016,68043]
===
match
---
name: session [21928,21935]
name: session [21928,21935]
===
match
---
simple_stmt [45776,45803]
simple_stmt [45776,45803]
===
match
---
name: registered [49381,49391]
name: registered [49381,49391]
===
match
---
atom_expr [4168,4177]
atom_expr [4168,4177]
===
match
---
simple_stmt [20472,20517]
simple_stmt [20472,20517]
===
match
---
simple_stmt [3288,3325]
simple_stmt [3288,3325]
===
match
---
operator: = [23623,23624]
operator: = [23623,23624]
===
match
---
name: encode [35701,35707]
name: encode [35701,35707]
===
match
---
param [14531,14536]
param [14531,14536]
===
match
---
trailer [22255,22262]
trailer [22255,22262]
===
match
---
expr_stmt [6016,6063]
expr_stmt [6016,6063]
===
match
---
trailer [70560,70586]
trailer [70984,71010]
===
match
---
fstring_expr [21016,21021]
fstring_expr [21016,21021]
===
match
---
string: """         The start date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [31583,31794]
string: """         The start date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [31583,31794]
===
match
---
name: State [46628,46633]
name: State [46628,46633]
===
match
---
trailer [23583,23595]
trailer [23583,23595]
===
match
---
operator: @ [25784,25785]
operator: @ [25784,25785]
===
match
---
tfpdef [61748,61757]
tfpdef [62172,62181]
===
match
---
decorator [25016,25033]
decorator [25016,25033]
===
match
---
name: dag [58681,58684]
name: dag [59105,59108]
===
match
---
atom_expr [5405,5442]
atom_expr [5405,5442]
===
match
---
decorated [34025,34668]
decorated [34025,34668]
===
match
---
atom_expr [20149,20177]
atom_expr [20149,20177]
===
match
---
name: task_copy [50972,50981]
name: task_copy [50972,50981]
===
match
---
operator: , [53172,53173]
operator: , [53596,53597]
===
match
---
name: max_tries [23613,23622]
name: max_tries [23613,23622]
===
match
---
operator: , [54242,54243]
operator: , [54666,54667]
===
match
---
name: __tablename__ [10679,10692]
name: __tablename__ [10679,10692]
===
match
---
simple_stmt [68430,68451]
simple_stmt [68854,68875]
===
match
---
name: file_path [16897,16906]
name: file_path [16897,16906]
===
match
---
name: html_content [70425,70437]
name: html_content [70849,70861]
===
match
---
trailer [31563,31572]
trailer [31563,31572]
===
match
---
name: state [41648,41653]
name: state [41648,41653]
===
match
---
expr_stmt [39374,39404]
expr_stmt [39374,39404]
===
match
---
trailer [32064,32075]
trailer [32064,32075]
===
match
---
simple_stmt [80050,80069]
simple_stmt [80474,80493]
===
match
---
subscript [81914,81918]
subscript [82338,82342]
===
match
---
trailer [4068,4075]
trailer [4068,4075]
===
match
---
suite [20193,20228]
suite [20193,20228]
===
match
---
name: add [56258,56261]
name: add [56682,56685]
===
match
---
atom_expr [67062,67074]
atom_expr [67486,67498]
===
match
---
name: self [36862,36866]
name: self [36862,36866]
===
match
---
name: filter [8649,8655]
name: filter [8649,8655]
===
match
---
return_stmt [36534,36562]
return_stmt [36534,36562]
===
match
---
trailer [82159,82168]
trailer [82583,82592]
===
match
---
expr_stmt [24107,24148]
expr_stmt [24107,24148]
===
match
---
trailer [54024,54029]
trailer [54448,54453]
===
match
---
name: self [73140,73144]
name: self [73564,73568]
===
match
---
operator: , [19737,19738]
operator: , [19737,19738]
===
match
---
operator: = [79341,79342]
operator: = [79765,79766]
===
match
---
simple_stmt [79830,79856]
simple_stmt [80254,80280]
===
match
---
name: context [48811,48818]
name: context [48811,48818]
===
match
---
name: Optional [17501,17509]
name: Optional [17501,17509]
===
match
---
trailer [9872,9879]
trailer [9872,9879]
===
match
---
name: dep_context [34159,34170]
name: dep_context [34159,34170]
===
match
---
name: task [39208,39212]
name: task [39208,39212]
===
match
---
name: self [12450,12454]
name: self [12450,12454]
===
match
---
expr_stmt [80050,80068]
expr_stmt [80474,80492]
===
match
---
name: AirflowFailException [1653,1673]
name: AirflowFailException [1653,1673]
===
match
---
name: self [23295,23299]
name: self [23295,23299]
===
match
---
trailer [56302,56313]
trailer [56726,56737]
===
match
---
atom [66733,66773]
atom [67157,67197]
===
match
---
trailer [7256,7271]
trailer [7256,7271]
===
match
---
name: first [76433,76438]
name: first [76857,76862]
===
match
---
name: pool [43912,43916]
name: pool [43912,43916]
===
match
---
operator: = [57754,57755]
operator: = [58178,58179]
===
match
---
trailer [66559,66576]
trailer [66983,67000]
===
match
---
operator: = [29070,29071]
operator: = [29070,29071]
===
match
---
atom_expr [13331,13340]
atom_expr [13331,13340]
===
match
---
name: self [51031,51035]
name: self [51031,51035]
===
match
---
trailer [26302,26308]
trailer [26302,26308]
===
match
---
name: item [61510,61514]
name: item [61934,61938]
===
match
---
trailer [52132,52153]
trailer [52274,52295]
===
match
---
operator: , [4601,4602]
operator: , [4601,4602]
===
match
---
atom_expr [6533,6550]
atom_expr [6533,6550]
===
match
---
name: TaskFail [2029,2037]
name: TaskFail [2029,2037]
===
match
---
trailer [19796,19803]
trailer [19796,19803]
===
match
---
param [25063,25075]
param [25063,25075]
===
match
---
name: job_ids [5749,5756]
name: job_ids [5749,5756]
===
match
---
operator: = [54048,54049]
operator: = [54472,54473]
===
match
---
name: tis [77971,77974]
name: tis [78395,78398]
===
match
---
name: property [80399,80407]
name: property [80823,80831]
===
match
---
arith_expr [39929,39960]
arith_expr [39929,39960]
===
match
---
atom_expr [64590,64603]
atom_expr [65014,65027]
===
match
---
expr_stmt [60264,60278]
expr_stmt [60688,60702]
===
match
---
name: last_dagrun [29489,29500]
name: last_dagrun [29489,29500]
===
match
---
argument [67816,67863]
argument [68240,68287]
===
match
---
name: or_ [7199,7202]
name: or_ [7199,7202]
===
match
---
string: "Starting attempt %s of %s" [42304,42331]
string: "Starting attempt %s of %s" [42304,42331]
===
match
---
name: timezone [2517,2525]
name: timezone [2517,2525]
===
match
---
operator: = [36486,36487]
operator: = [36486,36487]
===
match
---
name: self [79323,79327]
name: self [79747,79751]
===
match
---
return_stmt [58198,58209]
return_stmt [58622,58633]
===
match
---
param [72321,72326]
param [72745,72750]
===
match
---
name: render_templates [48136,48152]
name: render_templates [48136,48152]
===
match
---
atom_expr [77580,77586]
atom_expr [78004,78010]
===
match
---
trailer [5721,5732]
trailer [5721,5732]
===
match
---
trailer [76223,76229]
trailer [76647,76653]
===
match
---
atom_expr [3682,3714]
atom_expr [3682,3714]
===
match
---
argument [10767,10783]
argument [10767,10783]
===
match
---
name: t [77904,77905]
name: t [78328,78329]
===
match
---
operator: -> [67283,67285]
operator: -> [67707,67709]
===
match
---
atom_expr [33531,33545]
atom_expr [33531,33545]
===
match
---
operator: = [20476,20477]
operator: = [20476,20477]
===
match
---
atom_expr [4442,4463]
atom_expr [4442,4463]
===
match
---
number: 1000 [11168,11172]
number: 1000 [11168,11172]
===
match
---
simple_stmt [4358,4397]
simple_stmt [4358,4397]
===
match
---
name: DagRun [37213,37219]
name: DagRun [37213,37219]
===
match
---
operator: } [46640,46641]
operator: } [46640,46641]
===
match
---
trailer [58490,58492]
trailer [58914,58916]
===
match
---
trailer [24911,24919]
trailer [24911,24919]
===
match
---
name: log [48428,48431]
name: log [48428,48431]
===
match
---
name: value [73426,73431]
name: value [73850,73855]
===
match
---
if_stmt [29425,29654]
if_stmt [29425,29654]
===
match
---
name: self [34822,34826]
name: self [34822,34826]
===
match
---
not_test [29452,29471]
not_test [29452,29471]
===
match
---
trailer [80291,80307]
trailer [80715,80731]
===
match
---
name: session [75813,75820]
name: session [76237,76244]
===
match
---
name: cmd [20331,20334]
name: cmd [20331,20334]
===
match
---
atom_expr [52128,52155]
atom_expr [52270,52297]
===
match
---
simple_stmt [70974,71015]
simple_stmt [71398,71439]
===
match
---
test [33501,33545]
test [33501,33545]
===
match
---
name: self [70913,70917]
name: self [71337,71341]
===
match
---
string: 'ti_job_id' [12106,12117]
string: 'ti_job_id' [12106,12117]
===
match
---
suite [36463,36526]
suite [36463,36526]
===
match
---
name: Sentry [2282,2288]
name: Sentry [2282,2288]
===
match
---
operator: -> [21188,21190]
operator: -> [21188,21190]
===
match
---
atom_expr [35628,35640]
atom_expr [35628,35640]
===
match
---
if_stmt [55517,55941]
if_stmt [55941,56365]
===
match
---
trailer [60905,60912]
trailer [61329,61336]
===
match
---
name: warning [41740,41747]
name: warning [41740,41747]
===
match
---
operator: = [6514,6515]
operator: = [6514,6515]
===
match
---
operator: , [4926,4927]
operator: , [4926,4927]
===
match
---
atom_expr [48100,48159]
atom_expr [48100,48159]
===
match
---
parameters [9278,9284]
parameters [9278,9284]
===
match
---
atom_expr [59029,59050]
atom_expr [59453,59474]
===
match
---
string: "--pickle" [19655,19665]
string: "--pickle" [19655,19665]
===
match
---
trailer [50143,50149]
trailer [50143,50149]
===
match
---
funcdef [57577,57927]
funcdef [58001,58351]
===
match
---
simple_stmt [56993,57019]
simple_stmt [57417,57443]
===
match
---
funcdef [43249,43712]
funcdef [43249,43712]
===
match
---
atom_expr [47721,47769]
atom_expr [47721,47769]
===
match
---
name: BaseJob [82012,82019]
name: BaseJob [82436,82443]
===
match
---
name: self [28273,28277]
name: self [28273,28277]
===
match
---
return_stmt [63653,63672]
return_stmt [64077,64096]
===
match
---
suite [78271,78493]
suite [78695,78917]
===
match
---
fstring_expr [46984,46998]
fstring_expr [46984,46998]
===
match
---
name: pool [24704,24708]
name: pool [24704,24708]
===
match
---
trailer [79584,79595]
trailer [80008,80019]
===
match
---
arglist [60563,60570]
arglist [60987,60994]
===
match
---
argument [49762,49777]
argument [49762,49777]
===
match
---
trailer [41739,41747]
trailer [41739,41747]
===
match
---
testlist_comp [46028,46070]
testlist_comp [46028,46070]
===
match
---
simple_stmt [3242,3262]
simple_stmt [3242,3262]
===
match
---
name: min_backoff [35867,35878]
name: min_backoff [35867,35878]
===
match
---
name: try_number [42338,42348]
name: try_number [42338,42348]
===
match
---
atom_expr [36541,36554]
atom_expr [36541,36554]
===
match
---
comparison [25425,25467]
comparison [25425,25467]
===
match
---
name: sqlalchemy [1378,1388]
name: sqlalchemy [1378,1388]
===
match
---
expr_stmt [59988,60002]
expr_stmt [60412,60426]
===
match
---
name: dr [8900,8902]
name: dr [8900,8902]
===
match
---
name: state [46603,46608]
name: state [46603,46608]
===
match
---
operator: = [5714,5715]
operator: = [5714,5715]
===
match
---
expr_stmt [66667,66713]
expr_stmt [67091,67137]
===
match
---
operator: = [29646,29647]
operator: = [29646,29647]
===
match
---
return_stmt [80369,80392]
return_stmt [80793,80816]
===
match
---
name: job_id [44890,44896]
name: job_id [44890,44896]
===
match
---
operator: , [68106,68107]
operator: , [68530,68531]
===
match
---
simple_stmt [48694,48733]
simple_stmt [48694,48733]
===
match
---
trailer [79625,79631]
trailer [80049,80055]
===
match
---
name: self [36541,36545]
name: self [36541,36545]
===
match
---
operator: = [51072,51073]
operator: = [51072,51073]
===
match
---
decorator [49905,49922]
decorator [49905,49922]
===
match
---
name: from_string [70360,70371]
name: from_string [70784,70795]
===
match
---
atom_expr [20655,20666]
atom_expr [20655,20666]
===
match
---
name: dag_id [58877,58883]
name: dag_id [59301,59307]
===
match
---
trailer [55602,55648]
trailer [56026,56072]
===
match
---
trailer [24165,24186]
trailer [24165,24186]
===
match
---
simple_stmt [54445,54465]
simple_stmt [54869,54889]
===
match
---
name: __table_args__ [11812,11826]
name: __table_args__ [11812,11826]
===
match
---
name: dict [67519,67523]
name: dict [67943,67947]
===
match
---
atom_expr [47494,47522]
atom_expr [47494,47522]
===
match
---
trailer [7748,7760]
trailer [7748,7760]
===
match
---
string: 'utf-8' [35708,35715]
string: 'utf-8' [35708,35715]
===
match
---
name: task_copy [48694,48703]
name: task_copy [48694,48703]
===
match
---
operator: = [43974,43975]
operator: = [43974,43975]
===
match
---
operator: , [53021,53022]
operator: , [53445,53446]
===
match
---
name: ti [79434,79436]
name: ti [79858,79860]
===
match
---
atom_expr [55542,55570]
atom_expr [55966,55994]
===
match
---
expr_stmt [61552,61581]
expr_stmt [61976,62005]
===
match
---
name: dag_run [66976,66983]
name: dag_run [67400,67407]
===
match
---
operator: , [9729,9730]
operator: , [9729,9730]
===
match
---
name: dependencies_deps [2393,2410]
name: dependencies_deps [2393,2410]
===
match
---
name: task [52265,52269]
name: task [52549,52553]
===
match
---
operator: , [11993,11994]
operator: , [11993,11994]
===
match
---
operator: = [14564,14565]
operator: = [14564,14565]
===
match
---
trailer [45026,45028]
trailer [45026,45028]
===
match
---
trailer [51385,51395]
trailer [51385,51395]
===
match
---
return_stmt [62553,62573]
return_stmt [62977,62997]
===
match
---
trailer [15962,15980]
trailer [15962,15980]
===
match
---
simple_stmt [76080,76245]
simple_stmt [76504,76669]
===
match
---
trailer [59730,59745]
trailer [60154,60169]
===
match
---
trailer [3705,3714]
trailer [3705,3714]
===
match
---
if_stmt [15926,16061]
if_stmt [15926,16061]
===
match
---
name: self [52219,52223]
name: self [52503,52507]
===
match
---
operator: { [34754,34755]
operator: { [34754,34755]
===
match
---
atom_expr [80850,80861]
atom_expr [81274,81285]
===
match
---
suite [4178,4199]
suite [4178,4199]
===
match
---
name: yesterday_ds_nodash [65277,65296]
name: yesterday_ds_nodash [65701,65720]
===
match
---
simple_stmt [19485,19541]
simple_stmt [19485,19541]
===
match
---
name: incr [56051,56055]
name: incr [56475,56479]
===
match
---
atom_expr [50972,50994]
atom_expr [50972,50994]
===
match
---
trailer [70359,70371]
trailer [70783,70795]
===
match
---
trailer [37182,37258]
trailer [37182,37258]
===
match
---
fstring_expr [20654,20667]
fstring_expr [20654,20667]
===
match
---
operator: , [66974,66975]
operator: , [67398,67399]
===
match
---
trailer [60509,60530]
trailer [60933,60954]
===
match
---
simple_stmt [835,847]
simple_stmt [835,847]
===
match
---
operator: @ [31420,31421]
operator: @ [31420,31421]
===
match
---
trailer [56956,56977]
trailer [57380,57401]
===
match
---
name: Optional [32137,32145]
name: Optional [32137,32145]
===
match
---
atom_expr [26749,26767]
atom_expr [26749,26767]
===
match
---
atom_expr [31870,31920]
atom_expr [31870,31920]
===
match
---
atom_expr [11036,11046]
atom_expr [11036,11046]
===
match
---
name: add [42484,42487]
name: add [42484,42487]
===
match
---
expr_stmt [23847,23868]
expr_stmt [23847,23868]
===
match
---
with_stmt [47929,49794]
with_stmt [47929,49794]
===
match
---
atom_expr [78360,78422]
atom_expr [78784,78846]
===
match
---
name: Variable [61563,61571]
name: Variable [61987,61995]
===
match
---
return_stmt [43063,43074]
return_stmt [43063,43074]
===
match
---
name: Exception [71891,71900]
name: Exception [72315,72324]
===
match
---
name: _dag_id [79328,79335]
name: _dag_id [79752,79759]
===
match
---
name: task [59930,59934]
name: task [60354,60358]
===
match
---
atom_expr [61563,61581]
atom_expr [61987,62005]
===
match
---
atom_expr [67202,67214]
atom_expr [67626,67638]
===
match
---
string: '-' [60173,60176]
string: '-' [60597,60600]
===
match
---
operator: , [12274,12275]
operator: , [12274,12275]
===
match
---
operator: = [48404,48405]
operator: = [48404,48405]
===
match
---
suite [58059,58210]
suite [58483,58634]
===
match
---
testlist_comp [78974,79002]
testlist_comp [79398,79426]
===
match
---
trailer [76727,76733]
trailer [77151,77157]
===
match
---
trailer [36496,36501]
trailer [36496,36501]
===
match
---
name: jinja2 [70246,70252]
name: jinja2 [70670,70676]
===
match
---
name: session [29624,29631]
name: session [29624,29631]
===
match
---
name: relationship [82093,82105]
name: relationship [82517,82529]
===
match
---
name: _run_raw_task [53505,53518]
name: _run_raw_task [53929,53942]
===
match
---
operator: = [49035,49036]
operator: = [49035,49036]
===
match
---
if_stmt [5834,6444]
if_stmt [5834,6444]
===
match
---
number: 0 [21817,21818]
number: 0 [21817,21818]
===
match
---
trailer [24732,24737]
trailer [24732,24737]
===
match
---
atom_expr [80612,80623]
atom_expr [81036,81047]
===
match
---
simple_stmt [11421,11453]
simple_stmt [11421,11453]
===
match
---
atom_expr [56250,56330]
atom_expr [56674,56754]
===
match
---
suite [30991,31415]
suite [30991,31415]
===
match
---
trailer [7740,7742]
trailer [7740,7742]
===
match
---
name: ti [81832,81834]
name: ti [82256,82258]
===
match
---
trailer [42082,42094]
trailer [42082,42094]
===
match
---
operator: = [64436,64437]
operator: = [64860,64861]
===
match
---
atom_expr [29601,29653]
atom_expr [29601,29653]
===
match
---
trailer [34481,34490]
trailer [34481,34490]
===
match
---
name: end_date [42562,42570]
name: end_date [42562,42570]
===
match
---
trailer [12791,12799]
trailer [12791,12799]
===
match
---
name: airflow_context_vars [48331,48351]
name: airflow_context_vars [48331,48351]
===
match
---
name: error [55934,55939]
name: error [56358,56363]
===
match
---
name: Integer [11130,11137]
name: Integer [11130,11137]
===
match
---
name: execution_date [59099,59113]
name: execution_date [59523,59537]
===
match
---
arglist [39541,39569]
arglist [39541,39569]
===
match
---
name: t [78392,78393]
name: t [78816,78817]
===
match
---
param [50339,50347]
param [50339,50347]
===
match
---
simple_stmt [24699,24738]
simple_stmt [24699,24738]
===
match
---
trailer [25272,25294]
trailer [25272,25294]
===
match
---
name: rendered_task_instance_fields [65591,65620]
name: rendered_task_instance_fields [66015,66044]
===
match
---
trailer [55020,55026]
trailer [55444,55450]
===
match
---
trailer [46952,46957]
trailer [46952,46957]
===
match
---
operator: = [11279,11280]
operator: = [11279,11280]
===
match
---
operator: @ [58287,58288]
operator: @ [58711,58712]
===
match
---
name: self [26107,26111]
name: self [26107,26111]
===
match
---
name: _CURRENT_CONTEXT [3784,3800]
name: _CURRENT_CONTEXT [3784,3800]
===
match
---
name: query_for_task_instance [40869,40892]
name: query_for_task_instance [40869,40892]
===
match
---
operator: , [21734,21735]
operator: , [21734,21735]
===
match
---
name: dump [4777,4781]
name: dump [4777,4781]
===
match
---
name: Any [3282,3285]
name: Any [3282,3285]
===
match
---
param [34098,34110]
param [34098,34110]
===
match
---
name: timedelta [36378,36387]
name: timedelta [36378,36387]
===
match
---
name: VariableJsonAccessor [61981,62001]
name: VariableJsonAccessor [62405,62425]
===
match
---
name: task_copy [50542,50551]
name: task_copy [50542,50551]
===
match
---
param [17466,17484]
param [17466,17484]
===
match
---
param [20418,20422]
param [20418,20422]
===
match
---
trailer [26465,26467]
trailer [26465,26467]
===
match
---
atom_expr [8560,8583]
atom_expr [8560,8583]
===
match
---
tfpdef [63399,63416]
tfpdef [63823,63840]
===
match
---
name: reschedule_date [54749,54764]
name: reschedule_date [55173,55188]
===
match
---
name: raw [77056,77059]
name: raw [77480,77483]
===
match
---
name: start_date [41014,41024]
name: start_date [41014,41024]
===
match
---
number: 256 [11373,11376]
number: 256 [11373,11376]
===
match
---
trailer [72098,72107]
trailer [72522,72531]
===
match
---
trailer [49540,49542]
trailer [49540,49542]
===
match
---
name: set [8477,8480]
name: set [8477,8480]
===
match
---
atom_expr [47972,47989]
atom_expr [47972,47989]
===
match
---
trailer [52223,52229]
trailer [52507,52513]
===
match
---
name: ignore_depends_on_past [40076,40098]
name: ignore_depends_on_past [40076,40098]
===
match
---
name: on_failure_callback [51796,51815]
name: on_failure_callback [51796,51815]
===
match
---
name: task_id [12003,12010]
name: task_id [12003,12010]
===
match
---
trailer [78698,78706]
trailer [79122,79130]
===
match
---
trailer [12799,12945]
trailer [12799,12945]
===
match
---
name: self [15963,15967]
name: self [15963,15967]
===
match
---
param [73653,73658]
param [74077,74082]
===
match
---
simple_stmt [42030,42062]
simple_stmt [42030,42062]
===
match
---
name: run_as_user [24870,24881]
name: run_as_user [24870,24881]
===
match
---
name: Index [11885,11890]
name: Index [11885,11890]
===
match
---
operator: -> [51523,51525]
operator: -> [51523,51525]
===
match
---
decorated [80867,80940]
decorated [81291,81364]
===
match
---
atom_expr [77996,78191]
atom_expr [78420,78615]
===
match
---
expr_stmt [23650,23677]
expr_stmt [23650,23677]
===
match
---
string: '%Y-%m-%d' [60392,60402]
string: '%Y-%m-%d' [60816,60826]
===
match
---
operator: = [17174,17175]
operator: = [17174,17175]
===
match
---
name: renderedtifields [66453,66469]
name: renderedtifields [66877,66893]
===
match
---
trailer [77078,77091]
trailer [77502,77515]
===
match
---
trailer [23255,23266]
trailer [23255,23266]
===
match
---
name: str [63220,63223]
name: str [63644,63647]
===
match
---
trailer [29017,29026]
trailer [29017,29026]
===
match
---
dotted_name [3431,3456]
dotted_name [3431,3456]
===
match
---
subscriptlist [77160,77191]
subscriptlist [77584,77615]
===
match
---
trailer [11129,11138]
trailer [11129,11138]
===
match
---
name: job_id [5519,5525]
name: job_id [5519,5525]
===
match
---
operator: == [52002,52004]
operator: == [52144,52146]
===
match
---
name: State [30796,30801]
name: State [30796,30801]
===
match
---
expr_stmt [79401,79451]
expr_stmt [79825,79875]
===
match
---
name: Stats [45083,45088]
name: Stats [45083,45088]
===
match
---
name: self [54591,54595]
name: self [55015,55019]
===
match
---
trailer [20152,20159]
trailer [20152,20159]
===
match
---
atom_expr [28273,28305]
atom_expr [28273,28305]
===
match
---
atom_expr [24788,24808]
atom_expr [24788,24808]
===
match
---
trailer [19581,19588]
trailer [19581,19588]
===
match
---
name: pid [39418,39421]
name: pid [39418,39421]
===
match
---
if_stmt [40200,40398]
if_stmt [40200,40398]
===
match
---
parameters [29822,29828]
parameters [29822,29828]
===
match
---
name: ignore_ti_state [20013,20028]
name: ignore_ti_state [20013,20028]
===
match
---
param [15520,15532]
param [15520,15532]
===
match
---
name: self [64398,64402]
name: self [64822,64826]
===
match
---
simple_stmt [16040,16061]
simple_stmt [16040,16061]
===
match
---
name: task [24680,24684]
name: task [24680,24684]
===
match
---
tfpdef [61775,61791]
tfpdef [62199,62215]
===
match
---
trailer [78513,78521]
trailer [78937,78945]
===
match
---
trailer [39535,39540]
trailer [39535,39540]
===
match
---
simple_stmt [82070,82114]
simple_stmt [82494,82538]
===
match
---
name: self [54697,54701]
name: self [55121,55125]
===
match
---
simple_stmt [61663,61684]
simple_stmt [62087,62108]
===
match
---
name: TaskInstance [79300,79312]
name: TaskInstance [79724,79736]
===
match
---
trailer [54748,54764]
trailer [55172,55188]
===
match
---
trailer [56270,56329]
trailer [56694,56753]
===
match
---
tfpdef [17355,17366]
tfpdef [17355,17366]
===
match
---
trailer [79327,79335]
trailer [79751,79759]
===
match
---
name: prev_ds_nodash [64234,64248]
name: prev_ds_nodash [64658,64672]
===
match
---
operator: -> [73877,73879]
operator: -> [74301,74303]
===
match
---
parameters [67500,67506]
parameters [67924,67930]
===
match
---
name: executor_namespace [68188,68206]
name: executor_namespace [68612,68630]
===
match
---
name: task [45106,45110]
name: task [45106,45110]
===
match
---
expr_stmt [70425,70507]
expr_stmt [70849,70931]
===
match
---
name: get_many [75602,75610]
name: get_many [76026,76034]
===
match
---
name: ti_hash [35504,35511]
name: ti_hash [35504,35511]
===
match
---
string: '\n' [68795,68799]
string: '\n' [69219,69223]
===
match
---
operator: = [68006,68007]
operator: = [68430,68431]
===
match
---
tfpdef [55242,55267]
tfpdef [55666,55691]
===
match
---
parameters [34685,34691]
parameters [34685,34691]
===
match
---
trailer [45384,45390]
trailer [45384,45390]
===
match
---
name: test_mode [46866,46875]
name: test_mode [46866,46875]
===
match
---
name: Connection [63539,63549]
name: Connection [63963,63973]
===
match
---
name: self [72047,72051]
name: self [72471,72475]
===
match
---
atom_expr [23975,23991]
atom_expr [23975,23991]
===
match
---
simple_stmt [40352,40369]
simple_stmt [40352,40369]
===
match
---
trailer [42181,42183]
trailer [42181,42183]
===
match
---
name: job_id [53623,53629]
name: job_id [54047,54053]
===
match
---
expr_stmt [82118,82168]
expr_stmt [82542,82592]
===
match
---
operator: , [31327,31328]
operator: , [31327,31328]
===
match
---
operator: = [77578,77579]
operator: = [78002,78003]
===
match
---
name: info [42262,42266]
name: info [42262,42266]
===
match
---
fstring_end: ' [45133,45134]
fstring_end: ' [45133,45134]
===
match
---
name: include_prior_dates [73803,73822]
name: include_prior_dates [74227,74246]
===
match
---
atom_expr [27800,27824]
atom_expr [27800,27824]
===
match
---
return_stmt [29699,29766]
return_stmt [29699,29766]
===
match
---
trailer [35700,35707]
trailer [35700,35707]
===
match
---
trailer [69926,69933]
trailer [70350,70357]
===
match
---
operator: = [70438,70439]
operator: = [70862,70863]
===
match
---
classdef [61975,62904]
classdef [62399,63328]
===
match
---
trailer [36336,36350]
trailer [36336,36350]
===
match
---
operator: , [15573,15574]
operator: , [15573,15574]
===
match
---
trailer [70995,71012]
trailer [71419,71436]
===
match
---
operator: -> [72455,72457]
operator: -> [72879,72881]
===
match
---
trailer [7723,7733]
trailer [7723,7733]
===
match
---
simple_stmt [46424,46447]
simple_stmt [46424,46447]
===
match
---
name: execution_date [63889,63903]
name: execution_date [64313,64327]
===
match
---
comparison [76774,76808]
comparison [77198,77232]
===
match
---
decorator [80697,80707]
decorator [81121,81131]
===
match
---
operator: , [14529,14530]
operator: , [14529,14530]
===
match
---
param [55318,55351]
param [55742,55775]
===
match
---
trailer [23802,23813]
trailer [23802,23813]
===
match
---
trailer [77903,77975]
trailer [78327,78399]
===
match
---
simple_stmt [55588,55649]
simple_stmt [56012,56073]
===
match
---
name: exception_html [68755,68769]
name: exception_html [69179,69193]
===
match
---
atom_expr [69951,70164]
atom_expr [70375,70588]
===
match
---
name: pickle [4584,4590]
name: pickle [4584,4590]
===
match
---
name: dep_context [40250,40261]
name: dep_context [40250,40261]
===
match
---
operator: % [35889,35890]
operator: % [35889,35890]
===
match
---
name: TaskInstanceKey [25698,25713]
name: TaskInstanceKey [25698,25713]
===
match
---
arglist [71503,71552]
arglist [71927,71976]
===
match
---
name: test_mode [39259,39268]
name: test_mode [39259,39268]
===
match
---
trailer [34198,34200]
trailer [34198,34200]
===
match
---
name: airflow [1531,1538]
name: airflow [1531,1538]
===
match
---
name: passed [34623,34629]
name: passed [34623,34629]
===
match
---
name: strftime [59320,59328]
name: strftime [59744,59752]
===
match
---
arglist [55603,55647]
arglist [56027,56071]
===
match
---
name: Iterable [73697,73705]
name: Iterable [74121,74129]
===
match
---
tfpdef [37517,37539]
tfpdef [37517,37539]
===
match
---
trailer [47498,47520]
trailer [47498,47520]
===
match
---
dotted_name [2721,2751]
dotted_name [2721,2751]
===
match
---
name: ti [6016,6018]
name: ti [6016,6018]
===
match
---
trailer [72397,72407]
trailer [72821,72831]
===
match
---
trailer [76722,76736]
trailer [77146,77160]
===
match
---
name: update [60933,60939]
name: update [61357,61363]
===
match
---
string: "exception" [51907,51918]
string: "exception" [51907,51918]
===
match
---
string: 'params' [64154,64162]
string: 'params' [64578,64586]
===
match
---
expr_stmt [11215,11239]
expr_stmt [11215,11239]
===
match
---
operator: = [15486,15487]
operator: = [15486,15487]
===
match
---
except_clause [65853,65905]
except_clause [66277,66329]
===
match
---
string: "Task Duration set to %s" [72230,72255]
string: "Task Duration set to %s" [72654,72679]
===
match
---
name: qry [81513,81516]
name: qry [81937,81940]
===
match
---
expr_stmt [45380,45406]
expr_stmt [45380,45406]
===
match
---
trailer [59315,59318]
trailer [59739,59742]
===
match
---
trailer [25535,25556]
trailer [25535,25556]
===
match
---
trailer [28230,28235]
trailer [28230,28235]
===
match
---
arglist [34306,34332]
arglist [34306,34332]
===
match
---
atom_expr [59226,59238]
atom_expr [59650,59662]
===
match
---
name: log [55688,55691]
name: log [56112,56115]
===
match
---
trailer [76733,76735]
trailer [77157,77159]
===
match
---
atom_expr [31491,31504]
atom_expr [31491,31504]
===
match
---
name: self [27648,27652]
name: self [27648,27652]
===
match
---
operator: , [12065,12066]
operator: , [12065,12066]
===
match
---
suite [59813,59979]
suite [60237,60403]
===
match
---
atom [19726,19751]
atom [19726,19751]
===
match
---
simple_stmt [37122,37290]
simple_stmt [37122,37290]
===
match
---
return_stmt [26728,26798]
return_stmt [26728,26798]
===
match
---
operator: = [24086,24087]
operator: = [24086,24087]
===
match
---
name: Any [61788,61791]
name: Any [62212,62215]
===
match
---
name: item [61935,61939]
name: item [62359,62363]
===
match
---
trailer [7680,7686]
trailer [7680,7686]
===
match
---
test [43193,43243]
test [43193,43243]
===
match
---
trailer [52384,52386]
trailer [52668,52670]
===
match
---
trailer [12567,12573]
trailer [12567,12573]
===
match
---
expr_stmt [79787,79821]
expr_stmt [80211,80245]
===
match
---
parameters [63354,63438]
parameters [63778,63862]
===
match
---
name: ti [6386,6388]
name: ti [6386,6388]
===
match
---
operator: , [27539,27540]
operator: , [27539,27540]
===
match
---
simple_stmt [1373,1428]
simple_stmt [1373,1428]
===
match
---
atom_expr [19876,19913]
atom_expr [19876,19913]
===
match
---
atom_expr [24239,24249]
atom_expr [24239,24249]
===
match
---
name: execution_date [27630,27644]
name: execution_date [27630,27644]
===
match
---
name: self [45325,45329]
name: self [45325,45329]
===
match
---
operator: = [61435,61436]
operator: = [61859,61860]
===
match
---
annassign [80025,80041]
annassign [80449,80465]
===
match
---
atom_expr [25303,25487]
atom_expr [25303,25487]
===
match
---
trailer [43549,43557]
trailer [43549,43557]
===
match
---
trailer [65139,65141]
trailer [65563,65565]
===
match
---
atom_expr [13315,13328]
atom_expr [13315,13328]
===
match
---
atom_expr [45325,45367]
atom_expr [45325,45367]
===
match
---
name: execution_date [19450,19464]
name: execution_date [19450,19464]
===
match
---
simple_stmt [47683,47703]
simple_stmt [47683,47703]
===
match
---
atom_expr [8034,8251]
atom_expr [8034,8251]
===
match
---
name: _queue [80855,80861]
name: _queue [81279,81285]
===
match
---
name: cmd [19715,19718]
name: cmd [19715,19718]
===
match
---
name: default_var [62856,62867]
name: default_var [63280,63291]
===
match
---
name: self [40980,40984]
name: self [40980,40984]
===
match
---
atom_expr [76850,76862]
atom_expr [77274,77286]
===
match
---
dotted_name [3388,3406]
dotted_name [3388,3406]
===
match
---
name: default_html_content_err [70561,70585]
name: default_html_content_err [70985,71009]
===
match
---
name: task [39160,39164]
name: task [39160,39164]
===
match
---
fstring [49814,49857]
fstring [49814,49857]
===
match
---
atom_expr [26266,26276]
atom_expr [26266,26276]
===
match
---
simple_stmt [6560,6636]
simple_stmt [6560,6636]
===
match
---
trailer [13841,13851]
trailer [13841,13851]
===
match
---
operator: @ [52485,52486]
operator: @ [52909,52910]
===
match
---
operator: = [13382,13383]
operator: = [13382,13383]
===
match
---
trailer [7597,7599]
trailer [7597,7599]
===
match
---
name: Exception [46795,46804]
name: Exception [46795,46804]
===
match
---
name: next_execution_date [60087,60106]
name: next_execution_date [60511,60530]
===
match
---
name: getattr [43134,43141]
name: getattr [43134,43141]
===
match
---
name: UP_FOR_RETRY [26755,26767]
name: UP_FOR_RETRY [26755,26767]
===
match
---
suite [49979,50310]
suite [49979,50310]
===
match
---
atom_expr [65074,65096]
atom_expr [65498,65520]
===
match
---
sync_comp_for [7645,7688]
sync_comp_for [7645,7688]
===
match
---
operator: = [16128,16129]
operator: = [16128,16129]
===
match
---
atom_expr [9406,9418]
atom_expr [9406,9418]
===
match
---
name: items [7592,7597]
name: items [7592,7597]
===
match
---
operator: = [30220,30221]
operator: = [30220,30221]
===
match
---
arglist [12106,12125]
arglist [12106,12125]
===
match
---
simple_stmt [30762,30811]
simple_stmt [30762,30811]
===
match
---
atom_expr [24107,24127]
atom_expr [24107,24127]
===
match
---
name: DepContext [41248,41258]
name: DepContext [41248,41258]
===
match
---
name: execution_date [75624,75638]
name: execution_date [76048,76062]
===
match
---
atom_expr [23162,23173]
atom_expr [23162,23173]
===
match
---
simple_stmt [19961,20002]
simple_stmt [19961,20002]
===
match
---
atom_expr [65123,65141]
atom_expr [65547,65565]
===
match
---
trailer [71346,71383]
trailer [71770,71807]
===
match
---
name: session [73846,73853]
name: session [74270,74277]
===
match
---
name: self [67501,67505]
name: self [67925,67929]
===
match
---
trailer [23818,23829]
trailer [23818,23829]
===
match
---
name: Union [55211,55216]
name: Union [55635,55640]
===
match
---
name: Integer [11087,11094]
name: Integer [11087,11094]
===
match
---
arglist [78880,78950]
arglist [79304,79374]
===
match
---
name: self [54628,54632]
name: self [55052,55056]
===
match
---
name: with_entities [76407,76420]
name: with_entities [76831,76844]
===
match
---
raise_stmt [50227,50309]
raise_stmt [50227,50309]
===
match
---
trailer [79608,79615]
trailer [80032,80039]
===
match
---
operator: , [76579,76580]
operator: , [77003,77004]
===
match
---
trailer [67096,67102]
trailer [67520,67526]
===
match
---
operator: = [39257,39258]
operator: = [39257,39258]
===
match
---
simple_stmt [60264,60279]
simple_stmt [60688,60703]
===
match
---
suite [80596,80624]
suite [81020,81048]
===
match
---
atom_expr [23766,23775]
atom_expr [23766,23775]
===
match
---
operator: , [2968,2969]
operator: , [2968,2969]
===
match
---
name: TaskInstance [78065,78077]
name: TaskInstance [78489,78501]
===
match
---
atom_expr [42492,42505]
atom_expr [42492,42505]
===
match
---
if_stmt [78502,79018]
if_stmt [78926,79442]
===
match
---
name: State [54832,54837]
name: State [55256,55261]
===
match
---
name: state [40794,40799]
name: state [40794,40799]
===
match
---
trailer [6421,6442]
trailer [6421,6442]
===
match
---
trailer [44859,44876]
trailer [44859,44876]
===
match
---
name: session [58339,58346]
name: session [58763,58770]
===
match
---
name: test_mode [64790,64799]
name: test_mode [65214,65223]
===
match
---
operator: , [16629,16630]
operator: , [16629,16630]
===
match
---
operator: , [3280,3281]
operator: , [3280,3281]
===
match
---
if_stmt [60962,61107]
if_stmt [61386,61531]
===
match
---
arith_expr [20585,20668]
arith_expr [20585,20668]
===
match
---
operator: , [70778,70779]
operator: , [71202,71203]
===
match
---
atom_expr [7353,7366]
atom_expr [7353,7366]
===
match
---
name: Dict [3272,3276]
name: Dict [3272,3276]
===
match
---
name: DateTime [32155,32163]
name: DateTime [32155,32163]
===
match
---
trailer [28879,28900]
trailer [28879,28900]
===
match
---
name: ImportError [3207,3218]
name: ImportError [3207,3218]
===
match
---
atom_expr [48423,48588]
atom_expr [48423,48588]
===
match
---
atom_expr [42644,42660]
atom_expr [42644,42660]
===
match
---
argument [12284,12297]
argument [12284,12297]
===
match
---
name: pool [15541,15545]
name: pool [15541,15545]
===
match
---
funcdef [52506,53933]
funcdef [52930,54357]
===
match
---
atom_expr [52359,52386]
atom_expr [52643,52670]
===
match
---
trailer [55596,55602]
trailer [56020,56026]
===
match
---
tfpdef [52800,52821]
tfpdef [53224,53245]
===
match
---
fstring_expr [66872,66875]
fstring_expr [67296,67299]
===
match
---
name: tis [78266,78269]
name: tis [78690,78693]
===
match
---
atom_expr [56185,56208]
atom_expr [56609,56632]
===
match
---
name: TemplateAssertionError [65861,65883]
name: TemplateAssertionError [66285,66307]
===
match
---
trailer [27573,27577]
trailer [27573,27577]
===
match
---
import_from [2976,3017]
import_from [2976,3017]
===
match
---
subscriptlist [9294,9312]
subscriptlist [9294,9312]
===
match
---
operator: , [21612,21613]
operator: , [21612,21613]
===
match
---
atom_expr [73377,73603]
atom_expr [73801,74027]
===
match
---
trailer [11310,11346]
trailer [11310,11346]
===
match
---
argument [53353,53368]
argument [53777,53792]
===
match
---
trailer [65573,65579]
trailer [65997,66003]
===
match
---
operator: = [23704,23705]
operator: = [23704,23705]
===
match
---
operator: = [43284,43285]
operator: = [43284,43285]
===
match
---
decorator [80945,80955]
decorator [81369,81379]
===
match
---
arglist [73399,73593]
arglist [73823,74017]
===
match
---
atom_expr [7586,7599]
atom_expr [7586,7599]
===
match
---
trailer [16506,17024]
trailer [16506,17024]
===
match
---
trailer [60932,60939]
trailer [61356,61363]
===
match
---
name: incr [56115,56119]
name: incr [56539,56543]
===
match
---
operator: , [66756,66757]
operator: , [67180,67181]
===
match
---
name: dep_name [33829,33837]
name: dep_name [33829,33837]
===
match
---
operator: = [55641,55642]
operator: = [56065,56066]
===
match
---
operator: } [66874,66875]
operator: } [67298,67299]
===
match
---
operator: @ [80797,80798]
operator: @ [81221,81222]
===
match
---
name: dag_id [7175,7181]
name: dag_id [7175,7181]
===
match
---
simple_stmt [2095,2140]
simple_stmt [2095,2140]
===
match
---
name: UtcDateTime [2913,2924]
name: UtcDateTime [2913,2924]
===
match
---
atom_expr [25698,25778]
atom_expr [25698,25778]
===
match
---
name: log [47614,47617]
name: log [47614,47617]
===
match
---
name: get_hostname [2703,2715]
name: get_hostname [2703,2715]
===
match
---
name: task_type [25001,25010]
name: task_type [25001,25010]
===
match
---
operator: = [59092,59093]
operator: = [59516,59517]
===
match
---
arglist [11891,11928]
arglist [11891,11928]
===
match
---
simple_stmt [53965,54005]
simple_stmt [54389,54429]
===
match
---
expr_stmt [33478,33545]
expr_stmt [33478,33545]
===
match
---
trailer [35667,35678]
trailer [35667,35678]
===
match
---
expr_stmt [11383,11416]
expr_stmt [11383,11416]
===
match
---
name: duration [72262,72270]
name: duration [72686,72694]
===
match
---
operator: , [44809,44810]
operator: , [44809,44810]
===
match
---
operator: , [7289,7290]
operator: , [7289,7290]
===
match
---
operator: = [40261,40262]
operator: = [40261,40262]
===
match
---
trailer [27444,27450]
trailer [27444,27450]
===
match
---
funcdef [21912,22265]
funcdef [21912,22265]
===
match
---
name: str [4430,4433]
name: str [4430,4433]
===
match
---
arglist [58861,58919]
arglist [59285,59343]
===
match
---
simple_stmt [63456,63491]
simple_stmt [63880,63915]
===
match
---
parameters [80888,80894]
parameters [81312,81318]
===
match
---
trailer [72157,72159]
trailer [72581,72583]
===
match
---
trailer [32343,32585]
trailer [32343,32585]
===
match
---
string: 'Exception:<br>{{exception_html}}<br>' [69124,69162]
string: 'Exception:<br>{{exception_html}}<br>' [69548,69586]
===
match
---
string: "Webserver does not have access to User-defined Macros or Filters " [65967,66034]
string: "Webserver does not have access to User-defined Macros or Filters " [66391,66458]
===
match
---
suite [19702,19753]
suite [19702,19753]
===
match
---
name: Optional [12392,12400]
name: Optional [12392,12400]
===
match
---
trailer [12439,12441]
trailer [12439,12441]
===
match
---
operator: -> [80737,80739]
operator: -> [81161,81163]
===
match
---
argument [40250,40289]
argument [40250,40289]
===
match
---
operator: = [79487,79488]
operator: = [79911,79912]
===
match
---
atom_expr [63539,63583]
atom_expr [63963,64007]
===
match
---
string: '-' [60812,60815]
string: '-' [61236,61239]
===
match
---
if_stmt [56143,56210]
if_stmt [56567,56634]
===
match
---
name: ignore_all_deps [16643,16658]
name: ignore_all_deps [16643,16658]
===
match
---
name: self [43520,43524]
name: self [43520,43524]
===
match
---
name: airflow [2981,2988]
name: airflow [2981,2988]
===
match
---
trailer [3800,3804]
trailer [3800,3804]
===
match
---
comparison [27617,27667]
comparison [27617,27667]
===
match
---
operator: , [32516,32517]
operator: , [32516,32517]
===
match
---
trailer [78913,78921]
trailer [79337,79345]
===
match
---
name: state [58033,58038]
name: state [58457,58462]
===
match
---
funcdef [36847,37309]
funcdef [36847,37309]
===
match
---
name: self [31478,31482]
name: self [31478,31482]
===
match
---
simple_stmt [52911,52934]
simple_stmt [53335,53358]
===
match
---
param [25057,25062]
param [25057,25062]
===
match
---
expr_stmt [28220,28239]
expr_stmt [28220,28239]
===
match
---
operator: == [40800,40802]
operator: == [40800,40802]
===
match
---
expr_stmt [9228,9247]
expr_stmt [9228,9247]
===
match
---
operator: = [22324,22325]
operator: = [22324,22325]
===
match
---
simple_stmt [53892,53933]
simple_stmt [54316,54357]
===
match
---
trailer [24768,24779]
trailer [24768,24779]
===
match
---
argument [10839,10855]
argument [10839,10855]
===
match
---
atom_expr [27528,27539]
atom_expr [27528,27539]
===
match
---
param [61510,61520]
param [61934,61944]
===
match
---
name: unixname [23709,23717]
name: unixname [23709,23717]
===
match
---
operator: , [72414,72415]
operator: , [72838,72839]
===
match
---
atom_expr [36492,36517]
atom_expr [36492,36517]
===
match
---
param [52767,52791]
param [53191,53215]
===
match
---
name: duration [10992,11000]
name: duration [10992,11000]
===
match
---
name: self [65731,65735]
name: self [66155,66159]
===
match
---
if_stmt [34605,34668]
if_stmt [34605,34668]
===
match
---
if_stmt [75528,75580]
if_stmt [75952,76004]
===
match
---
name: qry [23101,23104]
name: qry [23101,23104]
===
match
---
param [26849,26854]
param [26849,26854]
===
match
---
operator: = [47541,47542]
operator: = [47541,47542]
===
match
---
name: utcnow [47087,47093]
name: utcnow [47087,47093]
===
match
---
name: logging [3331,3338]
name: logging [3331,3338]
===
match
---
string: """Sets the log context.""" [77015,77042]
string: """Sets the log context.""" [77439,77466]
===
match
---
expr_stmt [10920,10952]
expr_stmt [10920,10952]
===
match
---
trailer [8824,8826]
trailer [8824,8826]
===
match
---
operator: { [21016,21017]
operator: { [21016,21017]
===
match
---
param [20709,20713]
param [20709,20713]
===
match
---
operator: , [10896,10897]
operator: , [10896,10897]
===
match
---
trailer [19670,19681]
trailer [19670,19681]
===
match
---
name: force_fail [46316,46326]
name: force_fail [46316,46326]
===
match
---
simple_stmt [12423,12442]
simple_stmt [12423,12442]
===
match
---
except_clause [28786,28807]
except_clause [28786,28807]
===
match
---
atom_expr [51031,51080]
atom_expr [51031,51080]
===
match
---
trailer [29735,29766]
trailer [29735,29766]
===
match
---
name: pod_id [67816,67822]
name: pod_id [68240,68246]
===
match
---
string: """Fetch rendered template fields from DB""" [66380,66424]
string: """Fetch rendered template fields from DB""" [66804,66848]
===
match
---
suite [3844,4040]
suite [3844,4040]
===
match
---
operator: = [13629,13630]
operator: = [13629,13630]
===
match
---
string: """Executes Task (optionally with a Timeout) and pushes Xcom results""" [50368,50439]
string: """Executes Task (optionally with a Timeout) and pushes Xcom results""" [50368,50439]
===
match
---
name: task_id [67782,67789]
name: task_id [68206,68213]
===
match
---
argument [11320,11329]
argument [11320,11329]
===
match
---
operator: , [62447,62448]
operator: , [62871,62872]
===
match
---
string: 'tomorrow_ds' [64837,64850]
string: 'tomorrow_ds' [65261,65274]
===
match
---
name: in_ [78952,78955]
name: in_ [79376,79379]
===
match
---
operator: = [11027,11028]
operator: = [11027,11028]
===
match
---
atom_expr [5385,5443]
atom_expr [5385,5443]
===
match
---
argument [75672,75679]
argument [76096,76103]
===
match
---
atom_expr [36488,36525]
atom_expr [36488,36525]
===
match
---
operator: = [40155,40156]
operator: = [40155,40156]
===
match
---
sync_comp_for [77962,77974]
sync_comp_for [78386,78398]
===
match
---
name: pod [68417,68420]
name: pod [68841,68844]
===
match
---
parameters [34821,34827]
parameters [34821,34827]
===
match
---
arglist [21578,21735]
arglist [21578,21735]
===
match
---
suite [77006,77098]
suite [77430,77522]
===
match
---
trailer [50172,50174]
trailer [50172,50174]
===
match
---
param [76575,76580]
param [76999,77004]
===
match
---
trailer [58904,58919]
trailer [59328,59343]
===
match
---
name: debug [31233,31238]
name: debug [31233,31238]
===
match
---
argument [39978,40009]
argument [39978,40009]
===
match
---
name: max [9671,9674]
name: max [9671,9674]
===
match
---
trailer [6546,6550]
trailer [6546,6550]
===
match
---
suite [4264,4285]
suite [4264,4285]
===
match
---
string: """Returns a tuple that identifies the task instance uniquely""" [25618,25682]
string: """Returns a tuple that identifies the task instance uniquely""" [25618,25682]
===
match
---
name: XCOM_RETURN_KEY [2172,2187]
name: XCOM_RETURN_KEY [2172,2187]
===
match
---
operator: , [43474,43475]
operator: , [43474,43475]
===
match
---
trailer [51329,51338]
trailer [51329,51338]
===
match
---
decorator [57556,57573]
decorator [57980,57997]
===
match
---
trailer [6574,6585]
trailer [6574,6585]
===
match
---
name: mark_success_url [20692,20708]
name: mark_success_url [20692,20708]
===
match
---
name: KubeConfig [67683,67693]
name: KubeConfig [68107,68117]
===
match
---
name: State [45789,45794]
name: State [45789,45794]
===
match
---
name: execution_date [75644,75658]
name: execution_date [76068,76082]
===
match
---
name: XCom [2189,2193]
name: XCom [2189,2193]
===
match
---
expr_stmt [39866,40187]
expr_stmt [39866,40187]
===
match
---
name: error_file [55318,55328]
name: error_file [55742,55752]
===
match
---
tfpdef [4894,4943]
tfpdef [4894,4943]
===
match
---
expr_stmt [26402,26467]
expr_stmt [26402,26467]
===
match
---
name: open [71179,71183]
name: open [71603,71607]
===
match
---
number: 1 [70098,70099]
number: 1 [70522,70523]
===
match
---
string: 'Rescheduling task, marking task as UP_FOR_RESCHEDULE' [55080,55134]
string: 'Rescheduling task, marking task as UP_FOR_RESCHEDULE' [55504,55558]
===
match
---
name: get [61931,61934]
name: get [62355,62358]
===
match
---
except_clause [46787,46829]
except_clause [46787,46829]
===
match
---
name: helpers [2588,2595]
name: helpers [2588,2595]
===
match
---
trailer [10804,10856]
trailer [10804,10856]
===
match
---
param [31484,31512]
param [31484,31512]
===
match
---
suite [69719,70611]
suite [70143,71035]
===
match
---
name: error [4435,4440]
name: error [4435,4440]
===
match
---
param [29823,29827]
param [29823,29827]
===
match
---
name: state [31897,31902]
name: state [31897,31902]
===
match
---
name: dep_context [32708,32719]
name: dep_context [32708,32719]
===
match
---
simple_stmt [55481,55508]
simple_stmt [55905,55932]
===
match
---
suite [80443,80474]
suite [80867,80898]
===
match
---
operator: @ [22270,22271]
operator: @ [22270,22271]
===
match
---
operator: = [55491,55492]
operator: = [55915,55916]
===
match
---
simple_stmt [44722,44739]
simple_stmt [44722,44739]
===
match
---
trailer [22860,22874]
trailer [22860,22874]
===
match
---
name: COLLATION_ARGS [10822,10836]
name: COLLATION_ARGS [10822,10836]
===
match
---
return_stmt [62488,62503]
return_stmt [62912,62927]
===
match
---
name: task [12568,12572]
name: task [12568,12572]
===
match
---
expr_stmt [42557,42577]
expr_stmt [42557,42577]
===
match
---
operator: , [57649,57650]
operator: , [58073,58074]
===
match
---
expr_stmt [67704,68313]
expr_stmt [68128,68737]
===
match
---
trailer [56021,56034]
trailer [56445,56458]
===
match
---
return_stmt [34701,34792]
return_stmt [34701,34792]
===
match
---
name: pool [16973,16977]
name: pool [16973,16977]
===
match
---
operator: = [30913,30914]
operator: = [30913,30914]
===
match
---
name: ti [23778,23780]
name: ti [23778,23780]
===
match
---
name: Column [11190,11196]
name: Column [11190,11196]
===
match
---
trailer [76950,76952]
trailer [77374,77376]
===
match
---
expr_stmt [50051,50077]
expr_stmt [50051,50077]
===
match
---
trailer [79834,79840]
trailer [80258,80264]
===
match
---
trailer [59177,59179]
trailer [59601,59603]
===
match
---
name: pendulum [32146,32154]
name: pendulum [32146,32154]
===
match
---
simple_stmt [27755,27772]
simple_stmt [27755,27772]
===
match
---
operator: , [73793,73794]
operator: , [74217,74218]
===
match
---
import_as_names [1400,1427]
import_as_names [1400,1427]
===
match
---
atom_expr [23388,23396]
atom_expr [23388,23396]
===
match
---
operator: , [33992,33993]
operator: , [33992,33993]
===
match
---
name: default_var [61775,61786]
name: default_var [62199,62210]
===
match
---
name: instance [32048,32056]
name: instance [32048,32056]
===
match
---
fstring_string: ]> [34789,34791]
fstring_string: ]> [34789,34791]
===
match
---
atom [8600,8887]
atom [8600,8887]
===
match
---
simple_stmt [77015,77043]
simple_stmt [77439,77467]
===
match
---
name: self [52523,52527]
name: self [52947,52951]
===
match
---
expr_stmt [60711,60762]
expr_stmt [61135,61186]
===
match
---
name: ignore_depends_on_past [41364,41386]
name: ignore_depends_on_past [41364,41386]
===
match
---
name: format [73310,73316]
name: format [73734,73740]
===
match
---
name: get_connection_from_secrets [63550,63577]
name: get_connection_from_secrets [63974,64001]
===
match
---
simple_stmt [51899,51928]
simple_stmt [51899,51928]
===
match
---
name: dag [15994,15997]
name: dag [15994,15997]
===
match
---
atom_expr [68236,68302]
atom_expr [68660,68726]
===
match
---
name: e [45543,45544]
name: e [45543,45544]
===
match
---
name: self [52948,52952]
name: self [53372,53376]
===
match
---
atom_expr [46947,47013]
atom_expr [46947,47013]
===
match
---
atom_expr [5486,5499]
atom_expr [5486,5499]
===
match
---
name: self [45776,45780]
name: self [45776,45780]
===
match
---
simple_stmt [36902,37039]
simple_stmt [36902,37039]
===
match
---
operator: = [79621,79622]
operator: = [80045,80046]
===
match
---
operator: , [49673,49674]
operator: , [49673,49674]
===
match
---
suite [12414,13712]
suite [12414,13712]
===
match
---
simple_stmt [40844,40924]
simple_stmt [40844,40924]
===
match
---
name: filter [81547,81553]
name: filter [81971,81977]
===
match
---
name: execution_date [77626,77640]
name: execution_date [78050,78064]
===
match
---
trailer [79365,79374]
trailer [79789,79798]
===
match
---
simple_stmt [80923,80940]
simple_stmt [81347,81364]
===
match
---
atom_expr [5891,5912]
atom_expr [5891,5912]
===
match
---
name: int [35514,35517]
name: int [35514,35517]
===
match
---
operator: , [11329,11330]
operator: , [11329,11330]
===
match
---
atom_expr [62495,62503]
atom_expr [62919,62927]
===
match
---
simple_stmt [62756,62814]
simple_stmt [63180,63238]
===
match
---
argument [73577,73592]
argument [74001,74016]
===
match
---
operator: = [48723,48724]
operator: = [48723,48724]
===
match
---
operator: , [9418,9419]
operator: , [9418,9419]
===
match
---
atom_expr [58868,58883]
atom_expr [59292,59307]
===
match
---
simple_stmt [24161,24213]
simple_stmt [24161,24213]
===
match
---
atom_expr [78696,78706]
atom_expr [79120,79130]
===
match
---
name: ti [78993,78995]
name: ti [79417,79419]
===
match
---
operator: , [27735,27736]
operator: , [27735,27736]
===
match
---
simple_stmt [50850,50894]
simple_stmt [50850,50894]
===
match
---
operator: = [51764,51765]
operator: = [51764,51765]
===
match
---
argument [67964,67988]
argument [68388,68412]
===
match
---
trailer [78976,78980]
trailer [79400,79404]
===
match
---
name: context [51969,51976]
name: context [51994,52001]
===
match
---
suite [46683,46779]
suite [46683,46779]
===
match
---
name: run_id [58972,58978]
name: run_id [59396,59402]
===
match
---
trailer [62692,62723]
trailer [63116,63147]
===
match
---
simple_stmt [30242,30272]
simple_stmt [30242,30272]
===
match
---
name: verbose [40308,40315]
name: verbose [40308,40315]
===
match
---
name: get [61572,61575]
name: get [61996,61999]
===
match
---
name: dep_context [2342,2353]
name: dep_context [2342,2353]
===
match
---
trailer [23104,23120]
trailer [23104,23120]
===
match
---
or_test [23816,23834]
or_test [23816,23834]
===
match
---
name: make_aware [13024,13034]
name: make_aware [13024,13034]
===
match
---
atom_expr [8803,8826]
atom_expr [8803,8826]
===
match
---
simple_stmt [71220,71239]
simple_stmt [71644,71663]
===
match
---
name: self [80128,80132]
name: self [80552,80556]
===
match
---
name: self [62495,62499]
name: self [62919,62923]
===
match
---
name: warning [12792,12799]
name: warning [12792,12799]
===
match
---
name: task [71841,71845]
name: task [72265,72269]
===
match
---
name: default_var [62868,62879]
name: default_var [63292,63303]
===
match
---
expr_stmt [24846,24881]
expr_stmt [24846,24881]
===
match
---
trailer [73321,73336]
trailer [73745,73760]
===
match
---
operator: = [19448,19449]
operator: = [19448,19449]
===
match
---
operator: -> [80827,80829]
operator: -> [81251,81253]
===
match
---
operator: , [43021,43022]
operator: , [43021,43022]
===
match
---
arglist [31316,31344]
arglist [31316,31344]
===
match
---
simple_stmt [46912,46918]
simple_stmt [46912,46918]
===
match
---
if_stmt [29667,29767]
if_stmt [29667,29767]
===
match
---
operator: = [73402,73403]
operator: = [73826,73827]
===
match
---
name: default_subject [70372,70387]
name: default_subject [70796,70811]
===
match
---
trailer [8555,8559]
trailer [8555,8559]
===
match
---
decorated [25016,25557]
decorated [25016,25557]
===
match
---
name: execution_date [59785,59799]
name: execution_date [60209,60223]
===
match
---
dotted_name [2377,2410]
dotted_name [2377,2410]
===
match
---
atom [19589,19607]
atom [19589,19607]
===
match
---
trailer [80054,80059]
trailer [80478,80483]
===
match
---
name: execution_date [78096,78110]
name: execution_date [78520,78534]
===
match
---
name: provide_session [27832,27847]
name: provide_session [27832,27847]
===
match
---
return_stmt [32594,32650]
return_stmt [32594,32650]
===
match
---
name: execution_date [59289,59303]
name: execution_date [59713,59727]
===
match
---
name: ti [21494,21496]
name: ti [21494,21496]
===
match
---
name: Stats [56045,56050]
name: Stats [56469,56474]
===
match
---
suite [31574,32077]
suite [31574,32077]
===
match
---
name: _state [79609,79615]
name: _state [80033,80039]
===
match
---
decorated [54175,55136]
decorated [54599,55560]
===
match
---
name: next_ds_nodash [64033,64047]
name: next_ds_nodash [64457,64471]
===
match
---
simple_stmt [30506,30754]
simple_stmt [30506,30754]
===
match
---
simple_stmt [23766,23786]
simple_stmt [23766,23786]
===
match
---
name: taskreschedule [2058,2072]
name: taskreschedule [2058,2072]
===
match
---
name: params [58662,58668]
name: params [59086,59092]
===
match
---
name: execution_date [67974,67988]
name: execution_date [68398,68412]
===
match
---
simple_stmt [52448,52480]
simple_stmt [52757,52789]
===
match
---
suite [4349,4397]
suite [4349,4397]
===
match
---
atom_expr [51766,51775]
atom_expr [51766,51775]
===
match
---
simple_stmt [2449,2491]
simple_stmt [2449,2491]
===
match
---
name: Union [4089,4094]
name: Union [4089,4094]
===
match
---
trailer [76293,76302]
trailer [76717,76726]
===
match
---
name: end_date [72052,72060]
name: end_date [72476,72484]
===
match
---
argument [40027,40058]
argument [40027,40058]
===
match
---
name: item [63302,63306]
name: item [63726,63730]
===
match
---
funcdef [80234,80308]
funcdef [80658,80732]
===
match
---
name: State [50064,50069]
name: State [50064,50069]
===
match
---
name: Stats [49803,49808]
name: Stats [49803,49808]
===
match
---
operator: = [79115,79116]
operator: = [79539,79540]
===
match
---
trailer [62499,62503]
trailer [62923,62927]
===
match
---
atom_expr [79864,79885]
atom_expr [80288,80309]
===
match
---
simple_stmt [24667,24691]
simple_stmt [24667,24691]
===
match
---
name: res [53395,53398]
name: res [53819,53822]
===
match
---
operator: = [24949,24950]
operator: = [24949,24950]
===
match
---
name: property [25563,25571]
name: property [25563,25571]
===
match
---
simple_stmt [2255,2289]
simple_stmt [2255,2289]
===
match
---
name: mark_success [45168,45180]
name: mark_success [45168,45180]
===
match
---
operator: <= [58264,58266]
operator: <= [58688,58690]
===
match
---
trailer [23780,23785]
trailer [23780,23785]
===
match
---
trailer [81644,81653]
trailer [82068,82077]
===
match
---
operator: , [9634,9635]
operator: , [9634,9635]
===
match
---
name: pool [20131,20135]
name: pool [20131,20135]
===
match
---
suite [51288,51339]
suite [51288,51339]
===
match
---
operator: , [34490,34491]
operator: , [34490,34491]
===
match
---
operator: , [16590,16591]
operator: , [16590,16591]
===
match
---
trailer [67794,67802]
trailer [68218,68226]
===
match
---
operator: , [7570,7571]
operator: , [7570,7571]
===
match
---
trailer [27484,27491]
trailer [27484,27491]
===
match
---
suite [72081,72160]
suite [72505,72584]
===
match
---
atom_expr [23269,23282]
atom_expr [23269,23282]
===
match
---
name: deps [41276,41280]
name: deps [41276,41280]
===
match
---
name: signal_handler [47809,47823]
name: signal_handler [47809,47823]
===
match
---
operator: = [53782,53783]
operator: = [54206,54207]
===
match
---
name: self [13425,13429]
name: self [13425,13429]
===
match
---
try_stmt [45144,47014]
try_stmt [45144,47014]
===
match
---
operator: , [64975,64976]
operator: , [65399,65400]
===
match
---
atom_expr [14381,14391]
atom_expr [14381,14391]
===
match
---
name: String [11258,11264]
name: String [11258,11264]
===
match
---
expr_stmt [52403,52431]
expr_stmt [52687,52715]
===
match
---
atom_expr [35064,35099]
atom_expr [35064,35099]
===
match
---
operator: = [11357,11358]
operator: = [11357,11358]
===
match
---
simple_stmt [77051,77066]
simple_stmt [77475,77490]
===
match
---
expr_stmt [79323,79352]
expr_stmt [79747,79776]
===
match
---
name: self [26776,26780]
name: self [26776,26780]
===
match
---
trailer [76420,76432]
trailer [76844,76856]
===
match
---
expr_stmt [68707,68746]
expr_stmt [69131,69170]
===
match
---
simple_stmt [80994,81023]
simple_stmt [81418,81447]
===
match
---
name: stacklevel [30730,30740]
name: stacklevel [30730,30740]
===
match
---
name: state [79626,79631]
name: state [80050,80055]
===
match
---
param [15477,15492]
param [15477,15492]
===
match
---
decorated [61697,61966]
decorated [62121,62390]
===
match
---
atom_expr [17395,17408]
atom_expr [17395,17408]
===
match
---
name: self [44998,45002]
name: self [44998,45002]
===
match
---
arglist [10733,10783]
arglist [10733,10783]
===
match
---
expr_stmt [27755,27771]
expr_stmt [27755,27771]
===
match
---
name: Optional [17537,17545]
name: Optional [17537,17545]
===
match
---
name: TaskInstance [81616,81628]
name: TaskInstance [82040,82052]
===
match
---
operator: = [77686,77687]
operator: = [78110,78111]
===
match
---
operator: = [44962,44963]
operator: = [44962,44963]
===
match
---
fstring [60843,60888]
fstring [61267,61312]
===
match
---
name: drs [8906,8909]
name: drs [8906,8909]
===
match
---
suite [71053,71317]
suite [71477,71741]
===
match
---
name: self [20972,20976]
name: self [20972,20976]
===
match
---
trailer [30801,30809]
trailer [30801,30809]
===
match
---
name: retry_exponential_backoff [35074,35099]
name: retry_exponential_backoff [35074,35099]
===
match
---
arglist [71089,71101]
arglist [71513,71525]
===
match
---
trailer [71845,71851]
trailer [72269,72275]
===
match
---
number: 0 [4211,4212]
number: 0 [4211,4212]
===
match
---
operator: , [12090,12091]
operator: , [12090,12091]
===
match
---
name: in_ [78388,78391]
name: in_ [78812,78815]
===
match
---
atom_expr [73486,73497]
atom_expr [73910,73921]
===
match
---
fstring_end: " [66875,66876]
fstring_end: " [67299,67300]
===
match
---
trailer [59879,59894]
trailer [60303,60318]
===
match
---
operator: = [53454,53455]
operator: = [53878,53879]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [30013,30164]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [30013,30164]
===
match
---
atom_expr [45776,45786]
atom_expr [45776,45786]
===
match
---
param [63192,63197]
param [63616,63621]
===
match
---
arglist [40893,40914]
arglist [40893,40914]
===
match
---
trailer [34730,34737]
trailer [34730,34737]
===
match
---
atom_expr [6490,6513]
atom_expr [6490,6513]
===
match
---
operator: , [73657,73658]
operator: , [74081,74082]
===
match
---
sliceop [81915,81918]
sliceop [82339,82342]
===
match
---
term [16407,16427]
term [16407,16427]
===
match
---
name: datetime [72398,72406]
name: datetime [72822,72830]
===
match
---
atom_expr [7199,7617]
atom_expr [7199,7617]
===
match
---
name: execution_date [35647,35661]
name: execution_date [35647,35661]
===
match
---
expr_stmt [8298,8319]
expr_stmt [8298,8319]
===
match
---
name: max_tries [6408,6417]
name: max_tries [6408,6417]
===
match
---
name: debug [67097,67102]
name: debug [67521,67526]
===
match
---
string: """Set TI duration""" [72014,72035]
string: """Set TI duration""" [72438,72459]
===
match
---
operator: = [4869,4870]
operator: = [4869,4870]
===
match
---
name: tis [5458,5461]
name: tis [5458,5461]
===
match
---
atom_expr [72110,72159]
atom_expr [72534,72583]
===
match
---
operator: , [17266,17267]
operator: , [17266,17267]
===
match
---
trailer [54514,54518]
trailer [54938,54942]
===
match
---
simple_stmt [51944,51978]
simple_stmt [51969,52003]
===
match
---
with_item [71179,71194]
with_item [71603,71618]
===
match
---
name: pickle_id [19620,19629]
name: pickle_id [19620,19629]
===
match
---
name: state [13384,13389]
name: state [13384,13389]
===
match
---
name: warning [49152,49159]
name: warning [49152,49159]
===
match
---
operator: { [60860,60861]
operator: { [61284,61285]
===
match
---
trailer [45088,45093]
trailer [45088,45093]
===
match
---
simple_stmt [80843,80862]
simple_stmt [81267,81286]
===
match
---
name: context [49770,49777]
name: context [49770,49777]
===
match
---
trailer [71835,71875]
trailer [72259,72299]
===
match
---
parameters [51133,51163]
parameters [51133,51163]
===
match
---
name: ti [6405,6407]
name: ti [6405,6407]
===
match
---
simple_stmt [10789,10857]
simple_stmt [10789,10857]
===
match
---
dotted_name [14488,14505]
dotted_name [14488,14505]
===
match
---
name: FAILED [51739,51745]
name: FAILED [51739,51745]
===
match
---
param [4435,4463]
param [4435,4463]
===
match
---
trailer [75643,75658]
trailer [76067,76082]
===
match
---
name: self [26205,26209]
name: self [26205,26209]
===
match
---
atom_expr [27763,27771]
atom_expr [27763,27771]
===
match
---
operator: @ [80146,80147]
operator: @ [80570,80571]
===
match
---
operator: , [63715,63716]
operator: , [64139,64140]
===
match
---
operator: -> [81120,81122]
operator: -> [81544,81546]
===
match
---
simple_stmt [26728,26799]
simple_stmt [26728,26799]
===
match
---
atom_expr [44839,44876]
atom_expr [44839,44876]
===
match
---
name: sql [1487,1490]
name: sql [1487,1490]
===
match
---
operator: = [52881,52882]
operator: = [53305,53306]
===
match
---
name: queued_dttm [23997,24008]
name: queued_dttm [23997,24008]
===
match
---
funcdef [55162,57551]
funcdef [55586,57975]
===
match
---
trailer [59856,59874]
trailer [60280,60298]
===
match
---
parameters [80252,80258]
parameters [80676,80682]
===
match
---
trailer [46267,46269]
trailer [46267,46269]
===
match
---
simple_stmt [5972,6000]
simple_stmt [5972,6000]
===
match
---
argument [53536,53561]
argument [53960,53985]
===
match
---
trailer [71502,71553]
trailer [71926,71977]
===
match
---
name: raw [17466,17469]
name: raw [17466,17469]
===
match
---
trailer [26364,26373]
trailer [26364,26373]
===
match
---
suite [79314,80069]
suite [79738,80493]
===
match
---
if_stmt [51260,51339]
if_stmt [51260,51339]
===
match
---
parameters [3480,3498]
parameters [3480,3498]
===
match
---
name: log [31229,31232]
name: log [31229,31232]
===
match
---
trailer [80685,80691]
trailer [81109,81115]
===
match
---
name: TaskInstance [81533,81545]
name: TaskInstance [81957,81969]
===
match
---
atom_expr [78923,78950]
atom_expr [79347,79374]
===
match
---
name: task_id [22956,22963]
name: task_id [22956,22963]
===
match
---
trailer [23313,23322]
trailer [23313,23322]
===
match
---
operator: , [4024,4025]
operator: , [4024,4025]
===
match
---
name: job_id [43874,43880]
name: job_id [43874,43880]
===
match
---
operator: = [72108,72109]
operator: = [72532,72533]
===
match
---
name: job_id [19695,19701]
name: job_id [19695,19701]
===
match
---
simple_stmt [45037,45075]
simple_stmt [45037,45075]
===
match
---
operator: , [70099,70100]
operator: , [70523,70524]
===
match
---
decorated [80479,80554]
decorated [80903,80978]
===
match
---
name: RESTARTING [5722,5732]
name: RESTARTING [5722,5732]
===
match
---
except_clause [57371,57387]
except_clause [57795,57811]
===
match
---
name: bind [78522,78526]
name: bind [78946,78950]
===
match
---
name: XCom [25383,25387]
name: XCom [25383,25387]
===
match
---
name: commit [45020,45026]
name: commit [45020,45026]
===
match
---
trailer [23390,23396]
trailer [23390,23396]
===
match
---
name: ignore_ti_state [41494,41509]
name: ignore_ti_state [41494,41509]
===
match
---
param [32726,32739]
param [32726,32739]
===
match
---
trailer [26270,26276]
trailer [26270,26276]
===
match
---
atom_expr [29986,30233]
atom_expr [29986,30233]
===
match
---
atom_expr [4066,4075]
atom_expr [4066,4075]
===
match
---
name: in_ [27700,27703]
name: in_ [27700,27703]
===
match
---
name: execution_date [78373,78387]
name: execution_date [78797,78811]
===
match
---
atom_expr [71496,71553]
atom_expr [71920,71977]
===
match
---
operator: , [1304,1305]
operator: , [1304,1305]
===
match
---
atom_expr [14461,14477]
atom_expr [14461,14477]
===
match
---
name: cmd [19578,19581]
name: cmd [19578,19581]
===
match
---
atom_expr [23563,23578]
atom_expr [23563,23578]
===
match
---
name: self [9420,9424]
name: self [9420,9424]
===
match
---
name: try_number [7440,7450]
name: try_number [7440,7450]
===
match
---
operator: , [57623,57624]
operator: , [58047,58048]
===
match
---
simple_stmt [54150,54170]
simple_stmt [54574,54594]
===
match
---
name: primaryjoin [12193,12204]
name: primaryjoin [12193,12204]
===
match
---
name: self [47000,47004]
name: self [47000,47004]
===
match
---
operator: @ [80479,80480]
operator: @ [80903,80904]
===
match
---
atom_expr [29383,29404]
atom_expr [29383,29404]
===
match
---
arglist [55698,55709]
arglist [56122,56133]
===
match
---
name: error [52426,52431]
name: error [52710,52715]
===
match
---
name: sentry [2268,2274]
name: sentry [2268,2274]
===
match
---
trailer [53796,53802]
trailer [54220,54226]
===
match
---
name: kube_config [67669,67680]
name: kube_config [68093,68104]
===
match
---
string: "/confirm" [20899,20909]
string: "/confirm" [20899,20909]
===
match
---
atom_expr [54697,54710]
atom_expr [55121,55134]
===
match
---
expr_stmt [40844,40923]
expr_stmt [40844,40923]
===
match
---
atom_expr [23581,23595]
atom_expr [23581,23595]
===
match
---
simple_stmt [23881,23923]
simple_stmt [23881,23923]
===
match
---
name: ceil [35386,35390]
name: ceil [35386,35390]
===
match
---
atom_expr [79117,79144]
atom_expr [79541,79568]
===
match
---
trailer [35390,35444]
trailer [35390,35444]
===
match
---
param [81097,81118]
param [81521,81542]
===
match
---
suite [59691,59800]
suite [60115,60224]
===
match
---
name: queue [23852,23857]
name: queue [23852,23857]
===
match
---
operator: , [52790,52791]
operator: , [53214,53215]
===
match
---
trailer [43492,43498]
trailer [43492,43498]
===
match
---
trailer [7928,7937]
trailer [7928,7937]
===
match
---
suite [50359,51103]
suite [50359,51103]
===
match
---
name: log [42295,42298]
name: log [42295,42298]
===
match
---
operator: = [50690,50691]
operator: = [50690,50691]
===
match
---
name: State [26280,26285]
name: State [26280,26285]
===
match
---
arglist [71836,71874]
arglist [72260,72298]
===
match
---
atom_expr [15111,15127]
atom_expr [15111,15127]
===
match
---
arglist [48219,48244]
arglist [48219,48244]
===
match
---
name: and_ [7348,7352]
name: and_ [7348,7352]
===
match
---
name: hostname [23669,23677]
name: hostname [23669,23677]
===
match
---
param [57671,57704]
param [58095,58128]
===
match
---
operator: = [24905,24906]
operator: = [24905,24906]
===
match
---
operator: == [37235,37237]
operator: == [37235,37237]
===
match
---
trailer [21816,21819]
trailer [21816,21819]
===
match
---
name: ts_nodash [60580,60589]
name: ts_nodash [61004,61013]
===
match
---
name: instance [8560,8568]
name: instance [8560,8568]
===
match
---
arglist [27505,27736]
arglist [27505,27736]
===
match
---
operator: , [69996,69997]
operator: , [70420,70421]
===
match
---
atom_expr [25425,25444]
atom_expr [25425,25444]
===
match
---
name: session [6533,6540]
name: session [6533,6540]
===
match
---
trailer [57788,57803]
trailer [58212,58227]
===
match
---
argument [67917,67950]
argument [68341,68374]
===
match
---
operator: == [21712,21714]
operator: == [21712,21714]
===
match
---
name: pool [23781,23785]
name: pool [23781,23785]
===
match
---
name: result [43229,43235]
name: result [43229,43235]
===
match
---
name: RenderedTaskInstanceFields [66477,66503]
name: RenderedTaskInstanceFields [66901,66927]
===
match
---
fstring [20961,20985]
fstring [20961,20985]
===
match
---
operator: = [73829,73830]
operator: = [74253,74254]
===
match
---
operator: = [5809,5810]
operator: = [5809,5810]
===
match
---
arglist [60754,60761]
arglist [61178,61185]
===
match
---
name: session [34312,34319]
name: session [34312,34319]
===
match
---
trailer [25503,25510]
trailer [25503,25510]
===
match
---
not_test [41540,41625]
not_test [41540,41625]
===
match
---
operator: = [11249,11250]
operator: = [11249,11250]
===
match
---
name: dispose [42784,42791]
name: dispose [42784,42791]
===
match
---
trailer [57541,57548]
trailer [57965,57972]
===
match
---
trailer [43926,43931]
trailer [43926,43931]
===
match
---
name: dag_id [7649,7655]
name: dag_id [7649,7655]
===
match
---
name: State [27705,27710]
name: State [27705,27710]
===
match
---
name: self [81077,81081]
name: self [81501,81505]
===
match
---
trailer [30519,30753]
trailer [30519,30753]
===
match
---
trailer [8753,8760]
trailer [8753,8760]
===
match
---
trailer [40915,40921]
trailer [40915,40921]
===
match
---
trailer [34356,34360]
trailer [34356,34360]
===
match
---
simple_stmt [42616,42636]
simple_stmt [42616,42636]
===
match
---
name: _task_id [81645,81653]
name: _task_id [82069,82077]
===
match
---
operator: = [45787,45788]
operator: = [45787,45788]
===
match
---
trailer [9622,9699]
trailer [9622,9699]
===
match
---
name: str [79140,79143]
name: str [79564,79567]
===
match
---
string: 'try_number' [11073,11085]
string: 'try_number' [11073,11085]
===
match
---
name: dep_context [33601,33612]
name: dep_context [33601,33612]
===
match
---
operator: = [59996,59997]
operator: = [60420,60421]
===
match
---
simple_stmt [56173,56210]
simple_stmt [56597,56634]
===
match
---
simple_stmt [67088,67176]
simple_stmt [67512,67600]
===
match
---
name: self [80099,80103]
name: self [80523,80527]
===
match
---
trailer [31381,31390]
trailer [31381,31390]
===
match
---
name: warnings [8034,8042]
name: warnings [8034,8042]
===
match
---
atom_expr [47235,47254]
atom_expr [47235,47254]
===
match
---
operator: = [44824,44825]
operator: = [44824,44825]
===
match
---
name: tuple_ [78873,78879]
name: tuple_ [79297,79303]
===
match
---
argument [16735,16780]
argument [16735,16780]
===
match
---
operator: , [43795,43796]
operator: , [43795,43796]
===
match
---
name: self [24928,24932]
name: self [24928,24932]
===
match
---
atom_expr [41976,41990]
atom_expr [41976,41990]
===
match
---
name: downstream_task_ids [27583,27602]
name: downstream_task_ids [27583,27602]
===
match
---
name: self [13689,13693]
name: self [13689,13693]
===
match
---
suite [80521,80554]
suite [80945,80978]
===
match
---
trailer [48431,48436]
trailer [48431,48436]
===
match
---
atom_expr [25358,25369]
atom_expr [25358,25369]
===
match
---
name: utils [2582,2587]
name: utils [2582,2587]
===
match
---
string: 'ti_dag_state' [11845,11859]
string: 'ti_dag_state' [11845,11859]
===
match
---
if_stmt [21787,21865]
if_stmt [21787,21865]
===
match
---
simple_stmt [48602,48642]
simple_stmt [48602,48642]
===
match
---
simple_stmt [66796,66885]
simple_stmt [67220,67309]
===
match
---
trailer [70708,70715]
trailer [71132,71139]
===
match
---
string: """         Returns a command that can be executed anywhere where airflow is         installed. This command is part of the message sent to executors by         the orchestrator.         """ [15590,15780]
string: """         Returns a command that can be executed anywhere where airflow is         installed. This command is part of the message sent to executors by         the orchestrator.         """ [15590,15780]
===
match
---
tfpdef [52692,52713]
tfpdef [53116,53137]
===
match
---
trailer [12163,12328]
trailer [12163,12328]
===
match
---
atom_expr [45106,45117]
atom_expr [45106,45117]
===
match
---
parameters [34073,34111]
parameters [34073,34111]
===
match
---
operator: = [44762,44763]
operator: = [44762,44763]
===
match
---
simple_stmt [27340,27357]
simple_stmt [27340,27357]
===
match
---
expr_stmt [35853,35902]
expr_stmt [35853,35902]
===
match
---
simple_stmt [80763,80792]
simple_stmt [81187,81216]
===
match
---
name: local [20077,20082]
name: local [20077,20082]
===
match
---
name: dag_id [37205,37211]
name: dag_id [37205,37211]
===
match
---
subscriptlist [3277,3285]
subscriptlist [3277,3285]
===
match
---
atom_expr [70986,71014]
atom_expr [71410,71438]
===
match
---
simple_stmt [2783,2826]
simple_stmt [2783,2826]
===
match
---
trailer [35068,35073]
trailer [35068,35073]
===
match
---
name: task [55962,55966]
name: task [56386,56390]
===
match
---
param [49965,49977]
param [49965,49977]
===
match
---
parameters [43098,43115]
parameters [43098,43115]
===
match
---
string: 'outlets' [64117,64126]
string: 'outlets' [64541,64550]
===
match
---
atom_expr [42097,42114]
atom_expr [42097,42114]
===
match
---
name: pool [53652,53656]
name: pool [54076,54080]
===
match
---
simple_stmt [55950,55967]
simple_stmt [56374,56391]
===
match
---
name: field_name [65638,65648]
name: field_name [66062,66072]
===
match
---
operator: = [29631,29632]
operator: = [29631,29632]
===
match
---
name: get_previous_start_date [32606,32629]
name: get_previous_start_date [32606,32629]
===
match
---
operator: , [75791,75792]
operator: , [76215,76216]
===
match
---
name: get [62439,62442]
name: get [62863,62866]
===
match
---
name: executor_config [24133,24148]
name: executor_config [24133,24148]
===
match
---
trailer [50876,50893]
trailer [50876,50893]
===
match
---
decorator [17030,17044]
decorator [17030,17044]
===
match
---
simple_stmt [2289,2321]
simple_stmt [2289,2321]
===
match
---
name: expected_state [3818,3832]
name: expected_state [3818,3832]
===
match
---
name: task [57159,57163]
name: task [57583,57587]
===
match
---
fstring_string: . [34738,34739]
fstring_string: . [34738,34739]
===
match
---
atom_expr [80681,80691]
atom_expr [81105,81115]
===
match
---
operator: = [44867,44868]
operator: = [44867,44868]
===
match
---
trailer [68089,68105]
trailer [68513,68529]
===
match
---
name: pendulum [32039,32047]
name: pendulum [32039,32047]
===
match
---
name: mark_success [37596,37608]
name: mark_success [37596,37608]
===
match
---
param [43105,43114]
param [43105,43114]
===
match
---
name: self [81698,81702]
name: self [82122,82126]
===
match
---
try_stmt [50583,50824]
try_stmt [50583,50824]
===
match
---
string: 'html_content_template' [71418,71441]
string: 'html_content_template' [71842,71865]
===
match
---
name: dag_run [59654,59661]
name: dag_run [60078,60085]
===
match
---
simple_stmt [77989,78192]
simple_stmt [78413,78616]
===
match
---
operator: = [11637,11638]
operator: = [11637,11638]
===
match
---
operator: , [9302,9303]
operator: , [9302,9303]
===
match
---
name: session [22317,22324]
name: session [22317,22324]
===
match
---
operator: == [25355,25357]
operator: == [25355,25357]
===
match
---
operator: @ [55141,55142]
operator: @ [55565,55566]
===
match
---
operator: = [73584,73585]
operator: = [74008,74009]
===
match
---
simple_stmt [81513,81730]
simple_stmt [81937,82154]
===
match
---
name: ds_nodash [63825,63834]
name: ds_nodash [64249,64258]
===
match
---
operator: , [12183,12184]
operator: , [12183,12184]
===
match
---
try_stmt [63507,63673]
try_stmt [63931,64097]
===
match
---
import_from [1993,2037]
import_from [1993,2037]
===
match
---
suite [40335,40398]
suite [40335,40398]
===
match
---
atom_expr [70203,70327]
atom_expr [70627,70751]
===
match
---
decorator [27831,27848]
decorator [27831,27848]
===
match
---
arith_expr [72111,72142]
arith_expr [72535,72566]
===
match
---
atom_expr [15929,15950]
atom_expr [15929,15950]
===
match
---
suite [45869,46012]
suite [45869,46012]
===
match
---
string: 'Airflow alert: {{ti}}' [68836,68859]
string: 'Airflow alert: {{ti}}' [69260,69283]
===
match
---
name: next_execution_date [60044,60063]
name: next_execution_date [60468,60487]
===
match
---
atom_expr [54532,54779]
atom_expr [54956,55203]
===
match
---
name: TaskInstanceKey [79123,79138]
name: TaskInstanceKey [79547,79562]
===
match
---
name: session [40352,40359]
name: session [40352,40359]
===
match
---
operator: = [68062,68063]
operator: = [68486,68487]
===
match
---
simple_stmt [63256,63308]
simple_stmt [63680,63732]
===
match
---
trailer [47093,47095]
trailer [47093,47095]
===
match
---
name: try_number [9916,9926]
name: try_number [9916,9926]
===
match
---
name: List [3306,3310]
name: List [3306,3310]
===
match
---
arglist [35535,35767]
arglist [35535,35767]
===
match
---
operator: = [57809,57810]
operator: = [58233,58234]
===
match
---
operator: { [69748,69749]
operator: { [70172,70173]
===
match
---
operator: = [79805,79806]
operator: = [80229,80230]
===
match
---
return_stmt [63682,65307]
return_stmt [64106,65731]
===
match
---
trailer [24894,24904]
trailer [24894,24904]
===
match
---
trailer [78387,78391]
trailer [78811,78815]
===
match
---
trailer [81898,81928]
trailer [82322,82352]
===
match
---
dotted_name [65419,65450]
dotted_name [65843,65874]
===
match
---
atom_expr [34612,34629]
atom_expr [34612,34629]
===
match
---
trailer [45110,45117]
trailer [45110,45117]
===
match
---
operator: = [50062,50063]
operator: = [50062,50063]
===
match
---
string: "Rescheduling due to concurrency limits reached " [41769,41818]
string: "Rescheduling due to concurrency limits reached " [41769,41818]
===
match
---
operator: = [58574,58575]
operator: = [58998,58999]
===
match
---
funcdef [25576,25779]
funcdef [25576,25779]
===
match
---
tfpdef [37596,37614]
tfpdef [37596,37614]
===
match
---
name: dep_status [33818,33828]
name: dep_status [33818,33828]
===
match
---
trailer [22922,22929]
trailer [22922,22929]
===
match
---
trailer [79754,79773]
trailer [80178,80197]
===
match
---
name: self [9895,9899]
name: self [9895,9899]
===
match
---
atom_expr [51991,52001]
atom_expr [52133,52143]
===
match
---
name: pre_execute [48704,48715]
name: pre_execute [48704,48715]
===
match
---
for_stmt [34267,34668]
for_stmt [34267,34668]
===
match
---
name: iso [21017,21020]
name: iso [21017,21020]
===
match
---
atom_expr [78974,78988]
atom_expr [79398,79412]
===
match
---
operator: = [41493,41494]
operator: = [41493,41494]
===
match
---
name: session [31912,31919]
name: session [31912,31919]
===
match
---
name: _state [80617,80623]
name: _state [81041,81047]
===
match
---
operator: = [29501,29502]
operator: = [29501,29502]
===
match
---
name: list [77508,77512]
name: list [77932,77936]
===
match
---
name: pickle_id [16874,16883]
name: pickle_id [16874,16883]
===
match
---
name: cfg_path [16996,17004]
name: cfg_path [16996,17004]
===
match
---
parameters [27871,27945]
parameters [27871,27945]
===
match
---
name: NamedTuple [1083,1093]
name: NamedTuple [1083,1093]
===
match
---
operator: = [54830,54831]
operator: = [55254,55255]
===
match
---
name: ignore_all_deps [53035,53050]
name: ignore_all_deps [53459,53474]
===
match
---
simple_stmt [49143,49361]
simple_stmt [49143,49361]
===
match
---
param [9731,9746]
param [9731,9746]
===
match
---
number: 1 [15246,15247]
number: 1 [15246,15247]
===
match
---
trailer [78208,78215]
trailer [78632,78639]
===
match
---
atom [20342,20366]
atom [20342,20366]
===
match
---
expr_stmt [13398,13416]
expr_stmt [13398,13416]
===
match
---
trailer [47623,47670]
trailer [47623,47670]
===
match
---
name: self [73453,73457]
name: self [73877,73881]
===
match
---
decorator [43717,43734]
decorator [43717,43734]
===
match
---
name: self [73486,73490]
name: self [73910,73914]
===
match
---
name: args [68002,68006]
name: args [68426,68430]
===
match
---
operator: , [76862,76863]
operator: , [77286,77287]
===
match
---
argument [73511,73563]
argument [73935,73987]
===
match
---
atom_expr [13051,13073]
atom_expr [13051,13073]
===
match
---
operator: , [34449,34450]
operator: , [34449,34450]
===
match
---
operator: = [31911,31912]
operator: = [31911,31912]
===
match
---
simple_stmt [32594,32651]
simple_stmt [32594,32651]
===
match
---
operator: , [57836,57837]
operator: , [58260,58261]
===
match
---
suite [7813,7987]
suite [7813,7987]
===
match
---
string: """Returns SQLAlchemy filter to query selected task instances""" [77235,77299]
string: """Returns SQLAlchemy filter to query selected task instances""" [77659,77723]
===
match
---
name: task [60901,60905]
name: task [61325,61329]
===
match
---
trailer [42386,42391]
trailer [42386,42391]
===
match
---
suite [55571,55649]
suite [55995,56073]
===
match
---
simple_stmt [62553,62574]
simple_stmt [62977,62998]
===
match
---
simple_stmt [79640,79688]
simple_stmt [80064,80112]
===
match
---
operator: = [10724,10725]
operator: = [10724,10725]
===
match
---
trailer [40868,40892]
trailer [40868,40892]
===
match
---
name: Column [10933,10939]
name: Column [10933,10939]
===
match
---
except_clause [45512,45544]
except_clause [45512,45544]
===
match
---
operator: , [11929,11930]
operator: , [11929,11930]
===
match
---
name: execution_date [13146,13160]
name: execution_date [13146,13160]
===
match
---
operator: , [49337,49338]
operator: , [49337,49338]
===
match
---
testlist_comp [11839,12127]
testlist_comp [11839,12127]
===
match
---
operator: , [61939,61940]
operator: , [62363,62364]
===
match
---
decorated [80945,81023]
decorated [81369,81447]
===
match
---
trailer [48427,48431]
trailer [48427,48431]
===
match
---
fstring_end: " [48530,48531]
fstring_end: " [48530,48531]
===
match
---
name: session [40907,40914]
name: session [40907,40914]
===
match
---
tfpdef [37471,37499]
tfpdef [37471,37499]
===
match
---
trailer [48199,48218]
trailer [48199,48218]
===
match
---
trailer [78761,78776]
trailer [79185,79200]
===
match
---
dotted_name [67573,67619]
dotted_name [67997,68043]
===
match
---
string: '' [60454,60456]
string: '' [60878,60880]
===
match
---
simple_stmt [23251,23283]
simple_stmt [23251,23283]
===
match
---
name: error [57920,57925]
name: error [58344,58349]
===
match
---
simple_stmt [71330,71384]
simple_stmt [71754,71808]
===
match
---
expr_stmt [71477,71553]
expr_stmt [71901,71977]
===
match
---
string: """Overwrite Task Params with DagRun.conf""" [66994,67038]
string: """Overwrite Task Params with DagRun.conf""" [67418,67462]
===
match
---
trailer [8476,8481]
trailer [8476,8481]
===
match
---
name: cmd [20149,20152]
name: cmd [20149,20152]
===
match
---
simple_stmt [23335,23363]
simple_stmt [23335,23363]
===
match
---
name: queue [80036,80041]
name: queue [80460,80465]
===
match
---
trailer [15936,15950]
trailer [15936,15950]
===
match
---
param [47581,47588]
param [47581,47588]
===
match
---
name: bool [55262,55266]
name: bool [55686,55690]
===
match
---
name: total_seconds [35397,35410]
name: total_seconds [35397,35410]
===
match
---
trailer [61930,61934]
trailer [62354,62358]
===
match
---
suite [37767,43075]
suite [37767,43075]
===
match
---
decorator [37314,37331]
decorator [37314,37331]
===
match
---
operator: = [47076,47077]
operator: = [47076,47077]
===
match
---
atom_expr [12151,12328]
atom_expr [12151,12328]
===
match
---
name: strftime [60107,60115]
name: strftime [60531,60539]
===
match
---
name: self [39489,39493]
name: self [39489,39493]
===
match
---
atom_expr [80537,80553]
atom_expr [80961,80977]
===
match
---
name: TaskInstance [27617,27629]
name: TaskInstance [27617,27629]
===
match
---
param [58333,58338]
param [58757,58762]
===
match
---
name: execution_date [43039,43053]
name: execution_date [43039,43053]
===
match
---
trailer [56119,56134]
trailer [56543,56558]
===
match
---
string: 'task' [15943,15949]
string: 'task' [15943,15949]
===
match
---
name: prev_ti [32057,32064]
name: prev_ti [32057,32064]
===
match
---
operator: , [53698,53699]
operator: , [54122,54123]
===
match
---
funcdef [4800,9078]
funcdef [4800,9078]
===
match
---
try_stmt [66646,66885]
try_stmt [67070,67309]
===
match
---
argument [70298,70313]
argument [70722,70737]
===
match
---
return_stmt [61598,61613]
return_stmt [62022,62037]
===
match
---
name: log [41736,41739]
name: log [41736,41739]
===
match
---
if_stmt [23182,24257]
if_stmt [23182,24257]
===
match
---
string: 'task' [64662,64668]
string: 'task' [65086,65092]
===
match
---
name: State [36751,36756]
name: State [36751,36756]
===
match
---
expr_stmt [50850,50893]
expr_stmt [50850,50893]
===
match
---
tfpdef [55204,55232]
tfpdef [55628,55656]
===
match
---
simple_stmt [51377,51438]
simple_stmt [51377,51438]
===
match
---
trailer [20272,20297]
trailer [20272,20297]
===
match
---
name: self [42932,42936]
name: self [42932,42936]
===
match
---
name: log [12788,12791]
name: log [12788,12791]
===
match
---
simple_stmt [79787,79822]
simple_stmt [80211,80246]
===
match
---
string: "--force" [20054,20063]
string: "--force" [20054,20063]
===
match
---
atom_expr [50782,50801]
atom_expr [50782,50801]
===
match
---
decorated [3430,4040]
decorated [3430,4040]
===
match
---
atom [5361,5363]
atom [5361,5363]
===
match
---
trailer [11520,11529]
trailer [11520,11529]
===
match
---
name: or_ [1361,1364]
name: or_ [1361,1364]
===
match
---
name: dep_status [34512,34522]
name: dep_status [34512,34522]
===
match
---
expr_stmt [71124,71153]
expr_stmt [71548,71577]
===
match
---
suite [34112,34668]
suite [34112,34668]
===
match
---
trailer [35035,35040]
trailer [35035,35040]
===
match
---
name: getuser [2818,2825]
name: getuser [2818,2825]
===
match
---
atom_expr [11258,11269]
atom_expr [11258,11269]
===
match
---
name: Column [10726,10732]
name: Column [10726,10732]
===
match
---
atom_expr [36306,36357]
atom_expr [36306,36357]
===
match
---
name: jinja_context [70638,70651]
name: jinja_context [71062,71075]
===
match
---
if_stmt [3815,4040]
if_stmt [3815,4040]
===
match
---
fstring_string: __ [60874,60876]
fstring_string: __ [61298,61300]
===
match
---
atom_expr [26360,26373]
atom_expr [26360,26373]
===
match
---
operator: -> [4465,4467]
operator: -> [4465,4467]
===
match
---
operator: = [55955,55956]
operator: = [56379,56380]
===
match
---
string: """         Get the very latest state from the database, if a session is passed,         we use and looking up the state becomes part of the session, otherwise         a new session is used.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [21204,21485]
string: """         Get the very latest state from the database, if a session is passed,         we use and looking up the state becomes part of the session, otherwise         a new session is used.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [21204,21485]
===
match
---
name: self [73317,73321]
name: self [73741,73745]
===
match
---
argument [64584,64603]
argument [65008,65027]
===
match
---
name: qry [22841,22844]
name: qry [22841,22844]
===
match
---
name: self [12783,12787]
name: self [12783,12787]
===
match
---
name: error [53776,53781]
name: error [54200,54205]
===
match
---
simple_stmt [61552,61582]
simple_stmt [61976,62006]
===
match
---
name: clear_task_instances [4804,4824]
name: clear_task_instances [4804,4824]
===
match
---
name: SUCCESS [27726,27733]
name: SUCCESS [27726,27733]
===
match
---
name: self [49959,49963]
name: self [49959,49963]
===
match
---
name: exception [69977,69986]
name: exception [70401,70410]
===
match
---
argument [12255,12274]
argument [12255,12274]
===
match
---
name: self [31803,31807]
name: self [31803,31807]
===
match
---
atom_expr [56298,56313]
atom_expr [56722,56737]
===
match
---
trailer [71012,71014]
trailer [71436,71438]
===
match
---
trailer [58599,58612]
trailer [59023,59036]
===
match
---
name: Optional [17395,17403]
name: Optional [17395,17403]
===
match
---
name: info [42996,43000]
name: info [42996,43000]
===
match
---
operator: , [34529,34530]
operator: , [34529,34530]
===
match
---
simple_stmt [937,978]
simple_stmt [937,978]
===
match
---
if_stmt [46595,46779]
if_stmt [46595,46779]
===
match
---
try_stmt [53428,53933]
try_stmt [53852,54357]
===
match
---
operator: , [40306,40307]
operator: , [40306,40307]
===
match
---
name: session [2845,2852]
name: session [2845,2852]
===
match
---
name: context [49612,49619]
name: context [49612,49619]
===
match
---
name: self [59148,59152]
name: self [59572,59576]
===
match
---
atom_expr [73140,73159]
atom_expr [73564,73583]
===
match
---
name: dag_id [6578,6584]
name: dag_id [6578,6584]
===
match
---
for_stmt [8490,8585]
for_stmt [8490,8585]
===
match
---
name: exception_html [70815,70829]
name: exception_html [71239,71253]
===
match
---
if_stmt [79916,80006]
if_stmt [80340,80430]
===
match
---
name: deserialize_model_file [68249,68271]
name: deserialize_model_file [68673,68695]
===
match
---
name: non_requeueable_dep_context [40262,40289]
name: non_requeueable_dep_context [40262,40289]
===
match
---
name: airflow [2831,2838]
name: airflow [2831,2838]
===
match
---
operator: , [22824,22825]
operator: , [22824,22825]
===
match
---
operator: == [8717,8719]
operator: == [8717,8719]
===
match
---
simple_stmt [33405,33447]
simple_stmt [33405,33447]
===
match
---
arglist [42889,42951]
arglist [42889,42951]
===
match
---
name: filter [25323,25329]
name: filter [25323,25329]
===
match
---
arglist [6405,6442]
arglist [6405,6442]
===
match
---
operator: , [9648,9649]
operator: , [9648,9649]
===
match
---
operator: @ [73609,73610]
operator: @ [74033,74034]
===
match
---
name: cmd [20042,20045]
name: cmd [20042,20045]
===
match
---
funcdef [25037,25557]
funcdef [25037,25557]
===
match
---
atom_expr [11224,11239]
atom_expr [11224,11239]
===
match
---
name: task [51771,51775]
name: task [51771,51775]
===
match
---
atom_expr [56262,56329]
atom_expr [56686,56753]
===
match
---
expr_stmt [51899,51927]
expr_stmt [51899,51927]
===
match
---
funcdef [37335,43075]
funcdef [37335,43075]
===
match
---
trailer [10939,10952]
trailer [10939,10952]
===
match
---
operator: = [42533,42534]
operator: = [42533,42534]
===
match
---
operator: , [30716,30717]
operator: , [30716,30717]
===
match
---
trailer [6458,6464]
trailer [6458,6464]
===
match
---
operator: = [81517,81518]
operator: = [81941,81942]
===
match
---
name: local [15456,15461]
name: local [15456,15461]
===
match
---
name: str [4095,4098]
name: str [4095,4098]
===
match
---
operator: , [73836,73837]
operator: , [74260,74261]
===
match
---
operator: = [55344,55345]
operator: = [55768,55769]
===
match
---
atom_expr [78873,79017]
atom_expr [79297,79441]
===
match
---
name: render [71340,71346]
name: render [71764,71770]
===
match
---
trailer [53693,53698]
trailer [54117,54122]
===
match
---
simple_stmt [71914,71969]
simple_stmt [72338,72393]
===
match
---
simple_stmt [78564,78840]
simple_stmt [78988,79264]
===
match
---
trailer [13200,13215]
trailer [13200,13215]
===
match
---
fstring_expr [20971,20984]
fstring_expr [20971,20984]
===
match
---
expr_stmt [23295,23322]
expr_stmt [23295,23322]
===
match
---
atom_expr [12582,12591]
atom_expr [12582,12591]
===
match
---
name: test_mode [44764,44773]
name: test_mode [44764,44773]
===
match
---
simple_stmt [63532,63584]
simple_stmt [63956,64008]
===
match
---
operator: @ [66304,66305]
operator: @ [66728,66729]
===
match
---
string: 'conf' [63703,63709]
string: 'conf' [64127,64133]
===
match
---
name: self [34686,34690]
name: self [34686,34690]
===
match
---
simple_stmt [61035,61107]
simple_stmt [61459,61531]
===
match
---
argument [41315,41346]
argument [41315,41346]
===
match
---
name: TaskInstance [81567,81579]
name: TaskInstance [81991,82003]
===
match
---
name: is_eligible_to_retry [57936,57956]
name: is_eligible_to_retry [58360,58380]
===
match
---
operator: , [64103,64104]
operator: , [64527,64528]
===
match
---
trailer [76507,76513]
trailer [76931,76937]
===
match
---
suite [57963,58282]
suite [58387,58706]
===
match
---
trailer [30514,30519]
trailer [30514,30519]
===
match
---
simple_stmt [8523,8585]
simple_stmt [8523,8585]
===
match
---
simple_stmt [9386,9440]
simple_stmt [9386,9440]
===
match
---
expr_stmt [24239,24256]
expr_stmt [24239,24256]
===
match
---
simple_stmt [33920,33933]
simple_stmt [33920,33933]
===
match
---
atom_expr [79511,79525]
atom_expr [79935,79949]
===
match
---
suite [51018,51081]
suite [51018,51081]
===
match
---
trailer [46602,46608]
trailer [46602,46608]
===
match
---
name: self [77092,77096]
name: self [77516,77520]
===
match
---
name: pickle_id [17384,17393]
name: pickle_id [17384,17393]
===
match
---
string: "`activate_dag_runs` parameter to clear_task_instances function is deprecated. " [8061,8141]
string: "`activate_dag_runs` parameter to clear_task_instances function is deprecated. " [8061,8141]
===
match
---
trailer [21520,21526]
trailer [21520,21526]
===
match
---
name: self [68007,68011]
name: self [68431,68435]
===
match
---
argument [70759,70778]
argument [71183,71202]
===
match
---
trailer [60668,60676]
trailer [61092,61100]
===
match
---
name: session [54507,54514]
name: session [54931,54938]
===
match
---
simple_stmt [48016,48055]
simple_stmt [48016,48055]
===
match
---
operator: , [53368,53369]
operator: , [53792,53793]
===
match
---
name: str [43280,43283]
name: str [43280,43283]
===
match
---
name: utcnow [45066,45072]
name: utcnow [45066,45072]
===
match
---
name: instance [8539,8547]
name: instance [8539,8547]
===
match
---
name: urllib [1123,1129]
name: urllib [1123,1129]
===
match
---
string: """Remake the key by subtracting 1 from try number to match in memory information""" [9507,9591]
string: """Remake the key by subtracting 1 from try number to match in memory information""" [9507,9591]
===
match
---
name: self [40738,40742]
name: self [40738,40742]
===
match
---
atom_expr [61670,61683]
atom_expr [62094,62107]
===
match
---
name: session [26476,26483]
name: session [26476,26483]
===
match
---
operator: , [17220,17221]
operator: , [17220,17221]
===
match
---
string: 'prev_ds_nodash' [64216,64232]
string: 'prev_ds_nodash' [64640,64656]
===
match
---
name: TR [7254,7256]
name: TR [7254,7256]
===
match
---
name: self [80376,80380]
name: self [80800,80804]
===
match
---
if_stmt [19549,19609]
if_stmt [19549,19609]
===
match
---
trailer [40793,40799]
trailer [40793,40799]
===
match
---
parameters [49958,49978]
parameters [49958,49978]
===
match
---
name: task_id [78155,78162]
name: task_id [78579,78586]
===
match
---
decorator [80629,80639]
decorator [81053,81063]
===
match
---
funcdef [43764,47281]
funcdef [43764,47281]
===
match
---
name: try_number [7370,7380]
name: try_number [7370,7380]
===
match
---
comparison [81616,81653]
comparison [82040,82077]
===
match
---
operator: @ [32082,32083]
operator: @ [32082,32083]
===
match
---
name: e [46409,46410]
name: e [46409,46410]
===
match
---
arith_expr [70080,70099]
arith_expr [70504,70523]
===
match
---
simple_stmt [48067,48161]
simple_stmt [48067,48161]
===
match
---
string: '%Y-%m-%d' [59249,59259]
string: '%Y-%m-%d' [59673,59683]
===
match
---
name: set_state [25809,25818]
name: set_state [25809,25818]
===
match
---
operator: , [37729,37730]
operator: , [37729,37730]
===
match
---
fstring_string: &execution_date= [21000,21016]
fstring_string: &execution_date= [21000,21016]
===
match
---
argument [70800,70829]
argument [71224,71253]
===
match
---
name: airflow [3089,3096]
name: airflow [3089,3096]
===
match
---
name: task_copy [54038,54047]
name: task_copy [54462,54471]
===
match
---
name: error_file [55922,55932]
name: error_file [56346,56356]
===
match
---
simple_stmt [39651,39699]
simple_stmt [39651,39699]
===
match
---
simple_stmt [70191,70328]
simple_stmt [70615,70752]
===
match
---
annassign [79335,79352]
annassign [79759,79776]
===
match
---
parameters [4417,4464]
parameters [4417,4464]
===
match
---
suite [25077,25557]
suite [25077,25557]
===
match
---
simple_stmt [9182,9195]
simple_stmt [9182,9195]
===
match
---
simple_stmt [16123,16135]
simple_stmt [16123,16135]
===
match
---
expr_stmt [23608,23637]
expr_stmt [23608,23637]
===
match
---
operator: , [81653,81654]
operator: , [82077,82078]
===
match
---
simple_stmt [22220,22240]
simple_stmt [22220,22240]
===
match
---
operator: = [55989,55990]
operator: = [56413,56414]
===
match
---
arglist [53006,53369]
arglist [53430,53793]
===
match
---
atom_expr [39390,39404]
atom_expr [39390,39404]
===
match
---
name: e [45706,45707]
name: e [45706,45707]
===
match
---
operator: = [34105,34106]
operator: = [34105,34106]
===
match
---
trailer [20513,20515]
trailer [20513,20515]
===
match
---
arglist [9675,9697]
arglist [9675,9697]
===
match
---
trailer [78393,78408]
trailer [78817,78832]
===
match
---
operator: } [47010,47011]
operator: } [47010,47011]
===
match
---
trailer [42419,42431]
trailer [42419,42431]
===
match
---
name: exceptions [1607,1617]
name: exceptions [1607,1617]
===
match
---
string: """Log URL for TaskInstance""" [20433,20463]
string: """Log URL for TaskInstance""" [20433,20463]
===
match
---
expr_stmt [29344,29412]
expr_stmt [29344,29412]
===
match
---
name: log [55071,55074]
name: log [55495,55498]
===
match
---
tfpdef [43270,43283]
tfpdef [43270,43283]
===
match
---
name: count [27787,27792]
name: count [27787,27792]
===
match
---
operator: , [73406,73407]
operator: , [73830,73831]
===
match
---
number: 0 [77584,77585]
number: 0 [78008,78009]
===
match
---
name: Optional [67257,67265]
name: Optional [67681,67689]
===
match
---
name: State [57110,57115]
name: State [57534,57539]
===
match
---
name: ignore_depends_on_past [53080,53102]
name: ignore_depends_on_past [53504,53526]
===
match
---
tfpdef [31484,31504]
tfpdef [31484,31504]
===
match
---
trailer [32047,32056]
trailer [32047,32056]
===
match
---
fstring_end: " [20947,20948]
fstring_end: " [20947,20948]
===
match
---
operator: == [76847,76849]
operator: == [77271,77273]
===
match
---
trailer [40892,40915]
trailer [40892,40915]
===
match
---
name: t [78207,78208]
name: t [78631,78632]
===
match
---
name: xcom [76508,76512]
name: xcom [76932,76936]
===
match
---
name: self [27528,27532]
name: self [27528,27532]
===
match
---
atom_expr [79558,79574]
atom_expr [79982,79998]
===
match
---
atom_expr [60157,60181]
atom_expr [60581,60605]
===
match
---
fstring_expr [46999,47011]
fstring_expr [46999,47011]
===
match
---
exprlist [7440,7460]
exprlist [7440,7460]
===
match
---
name: exc_info [49324,49332]
name: exc_info [49324,49332]
===
match
---
name: timer [47940,47945]
name: timer [47940,47945]
===
match
---
name: last_dagrun [29706,29717]
name: last_dagrun [29706,29717]
===
match
---
number: 2 [35416,35417]
number: 2 [35416,35417]
===
match
---
suite [9114,10086]
suite [9114,10086]
===
match
---
string: 'prev_execution_date' [64262,64283]
string: 'prev_execution_date' [64686,64707]
===
match
---
name: str [17510,17513]
name: str [17510,17513]
===
match
---
trailer [25529,25535]
trailer [25529,25535]
===
match
---
operator: = [70984,70985]
operator: = [71408,71409]
===
match
---
simple_stmt [1848,1909]
simple_stmt [1848,1909]
===
match
---
parameters [36587,36593]
parameters [36587,36593]
===
match
---
string: 'json' [65066,65072]
string: 'json' [65490,65496]
===
match
---
name: state [31316,31321]
name: state [31316,31321]
===
match
---
name: bool [17169,17173]
name: bool [17169,17173]
===
match
---
param [43948,43981]
param [43948,43981]
===
match
---
string: "TaskInstance.dag_id == DagModel.dag_id" [12205,12245]
string: "TaskInstance.dag_id == DagModel.dag_id" [12205,12245]
===
match
---
name: lead_msg [43466,43474]
name: lead_msg [43466,43474]
===
match
---
name: airflow [2043,2050]
name: airflow [2043,2050]
===
match
---
name: test_mode [52767,52776]
name: test_mode [53191,53200]
===
match
---
name: actual_start_date [45037,45054]
name: actual_start_date [45037,45054]
===
match
---
parameters [32701,32754]
parameters [32701,32754]
===
match
---
operator: , [24353,24354]
operator: , [24353,24354]
===
match
---
simple_stmt [47361,47394]
simple_stmt [47361,47394]
===
match
---
operator: = [32635,32636]
operator: = [32635,32636]
===
match
---
expr_stmt [29587,29653]
expr_stmt [29587,29653]
===
match
---
atom_expr [19715,19752]
atom_expr [19715,19752]
===
match
---
name: models [1861,1867]
name: models [1861,1867]
===
match
---
name: task_reschedule [40844,40859]
name: task_reschedule [40844,40859]
===
match
---
trailer [5518,5525]
trailer [5518,5525]
===
match
---
simple_stmt [61866,61899]
simple_stmt [62290,62323]
===
match
---
atom_expr [24077,24085]
atom_expr [24077,24085]
===
match
---
operator: , [65096,65097]
operator: , [65520,65521]
===
match
---
atom_expr [5749,5774]
atom_expr [5749,5774]
===
match
---
operator: , [42930,42931]
operator: , [42930,42931]
===
match
---
trailer [70990,70995]
trailer [71414,71419]
===
match
---
number: 2 [30221,30222]
number: 2 [30221,30222]
===
match
---
operator: , [63834,63835]
operator: , [64258,64259]
===
match
---
suite [65352,66299]
suite [65776,66723]
===
match
---
name: DagModel [3419,3427]
name: DagModel [3419,3427]
===
match
---
operator: { [48523,48524]
operator: { [48523,48524]
===
match
---
parameters [13752,13758]
parameters [13752,13758]
===
match
---
name: self [47609,47613]
name: self [47609,47613]
===
match
---
name: path [16907,16911]
name: path [16907,16911]
===
match
---
arglist [66577,66598]
arglist [67001,67022]
===
match
---
trailer [81532,81546]
trailer [81956,81970]
===
match
---
name: self [44729,44733]
name: self [44729,44733]
===
match
---
trailer [64559,64583]
trailer [64983,65007]
===
match
---
name: result [50850,50856]
name: result [50850,50856]
===
match
---
import_from [2194,2254]
import_from [2194,2254]
===
match
---
operator: , [49963,49964]
operator: , [49963,49964]
===
match
---
trailer [24090,24094]
trailer [24090,24094]
===
match
---
fstring_expr [48523,48526]
fstring_expr [48523,48526]
===
match
---
parameters [54218,54296]
parameters [54642,54720]
===
match
---
string: """         Pull XComs that optionally meet certain criteria.          The default value for `key` limits the search to XComs         that were returned by other tasks (as opposed to those that were pushed         manually). To remove this filter, pass key=None (or any desired value).          If a single task_id string is provided, the result is the value of the         most recent matching XCom from that task_id. If multiple task_ids are         provided, a tuple of matching values is returned. None is returned         whenever no matches are found.          :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. The default key is 'return_value', also             available as a constant XCOM_RETURN_KEY. This key is automatically             given to XComs returned by tasks (as opposed to being pushed             manually). To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_id: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: Sqlalchemy ORM Session         :type session: Session         """ [73893,75519]
string: """         Pull XComs that optionally meet certain criteria.          The default value for `key` limits the search to XComs         that were returned by other tasks (as opposed to those that were pushed         manually). To remove this filter, pass key=None (or any desired value).          If a single task_id string is provided, the result is the value of the         most recent matching XCom from that task_id. If multiple task_ids are         provided, a tuple of matching values is returned. None is returned         whenever no matches are found.          :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. The default key is 'return_value', also             available as a constant XCOM_RETURN_KEY. This key is automatically             given to XComs returned by tasks (as opposed to being pushed             manually). To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_id: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: Sqlalchemy ORM Session         :type session: Session         """ [74317,75943]
===
match
---
name: self [31295,31299]
name: self [31295,31299]
===
match
---
name: state [12385,12390]
name: state [12385,12390]
===
match
---
name: _queue [80019,80025]
name: _queue [80443,80449]
===
match
---
simple_stmt [71657,71708]
simple_stmt [72081,72132]
===
match
---
simple_stmt [40385,40398]
simple_stmt [40385,40398]
===
match
---
name: generate_command [16490,16506]
name: generate_command [16490,16506]
===
match
---
operator: , [27885,27886]
operator: , [27885,27886]
===
match
---
operator: { [47952,47953]
operator: { [47952,47953]
===
match
---
simple_stmt [75589,75832]
simple_stmt [76013,76256]
===
match
---
operator: = [53925,53926]
operator: = [54349,54350]
===
match
---
name: _date_or_empty [43576,43590]
name: _date_or_empty [43576,43590]
===
match
---
atom_expr [46628,46640]
atom_expr [46628,46640]
===
match
---
atom_expr [22993,23020]
atom_expr [22993,23020]
===
match
---
expr_stmt [8923,8947]
expr_stmt [8923,8947]
===
match
---
name: self [79696,79700]
name: self [80120,80124]
===
match
---
operator: = [16292,16293]
operator: = [16292,16293]
===
match
---
arglist [60449,60456]
arglist [60873,60880]
===
match
---
atom_expr [54087,54096]
atom_expr [54511,54520]
===
match
---
name: UP_FOR_RESCHEDULE [54838,54855]
name: UP_FOR_RESCHEDULE [55262,55279]
===
match
---
trailer [42995,43000]
trailer [42995,43000]
===
match
---
atom_expr [31391,31413]
atom_expr [31391,31413]
===
match
---
arglist [39298,39335]
arglist [39298,39335]
===
match
---
name: start_date [40743,40753]
name: start_date [40743,40753]
===
match
---
name: self [21168,21172]
name: self [21168,21172]
===
match
---
name: xcom_push [51036,51045]
name: xcom_push [51036,51045]
===
match
---
atom_expr [62560,62573]
atom_expr [62984,62997]
===
match
---
operator: = [52783,52784]
operator: = [53207,53208]
===
match
---
trailer [15115,15127]
trailer [15115,15127]
===
match
---
import_name [1176,1200]
import_name [1176,1200]
===
match
---
operator: @ [27831,27832]
operator: @ [27831,27832]
===
match
---
atom_expr [28924,29049]
atom_expr [28924,29049]
===
match
---
operator: = [73776,73777]
operator: = [74200,74201]
===
match
---
return_stmt [4273,4284]
return_stmt [4273,4284]
===
match
---
atom_expr [25741,25760]
atom_expr [25741,25760]
===
match
---
name: init_on_load [13430,13442]
name: init_on_load [13430,13442]
===
match
---
string: "--cfg-path" [20343,20355]
string: "--cfg-path" [20343,20355]
===
match
---
trailer [70548,70560]
trailer [70972,70984]
===
match
---
name: error [51922,51927]
name: error [51922,51927]
===
match
---
name: AirflowSmartSensorException [45422,45449]
name: AirflowSmartSensorException [45422,45449]
===
match
---
string: 'dag_run_conf_overrides_params' [60989,61020]
string: 'dag_run_conf_overrides_params' [61413,61444]
===
match
---
name: count [27755,27760]
name: count [27755,27760]
===
match
---
operator: , [55308,55309]
operator: , [55732,55733]
===
match
---
name: cmd [19793,19796]
name: cmd [19793,19796]
===
match
---
trailer [45329,45345]
trailer [45329,45345]
===
match
---
tfpdef [62377,62386]
tfpdef [62801,62810]
===
match
---
trailer [6540,6546]
trailer [6540,6546]
===
match
---
trailer [28936,29049]
trailer [28936,29049]
===
match
---
operator: , [78706,78707]
operator: , [79130,79131]
===
match
---
name: state [56998,57003]
name: state [57422,57427]
===
match
---
param [71039,71043]
param [71463,71467]
===
match
---
argument [75752,75791]
argument [76176,76215]
===
match
---
if_stmt [50969,51081]
if_stmt [50969,51081]
===
match
---
name: self [50051,50055]
name: self [50051,50055]
===
match
---
operator: } [65155,65156]
operator: } [65579,65580]
===
match
---
name: debug [22782,22787]
name: debug [22782,22787]
===
match
---
name: self [20484,20488]
name: self [20484,20488]
===
match
---
trailer [11160,11174]
trailer [11160,11174]
===
match
---
parameters [76988,77005]
parameters [77412,77429]
===
match
---
trailer [3276,3286]
trailer [3276,3286]
===
match
---
trailer [55074,55079]
trailer [55498,55503]
===
match
---
atom_expr [4203,4226]
atom_expr [4203,4226]
===
match
---
param [17384,17416]
param [17384,17416]
===
match
---
name: renderedtifields [65434,65450]
name: renderedtifields [65858,65874]
===
match
---
param [55204,55233]
param [55628,55657]
===
match
---
name: job_id [53303,53309]
name: job_id [53727,53733]
===
match
---
operator: = [40298,40299]
operator: = [40298,40299]
===
match
---
operator: , [1761,1762]
operator: , [1761,1762]
===
match
---
annassign [9238,9247]
annassign [9238,9247]
===
match
---
trailer [70449,70461]
trailer [70873,70885]
===
match
---
return_stmt [63532,63583]
return_stmt [63956,64007]
===
match
---
operator: @ [36826,36827]
operator: @ [36826,36827]
===
match
---
name: raw [76995,76998]
name: raw [77419,77422]
===
match
---
trailer [21766,21768]
trailer [21766,21768]
===
match
---
trailer [26483,26489]
trailer [26483,26489]
===
match
---
trailer [41647,41653]
trailer [41647,41653]
===
match
---
trailer [46975,46982]
trailer [46975,46982]
===
match
---
name: IO [4066,4068]
name: IO [4066,4068]
===
match
---
operator: = [40042,40043]
operator: = [40042,40043]
===
match
---
name: self [51719,51723]
name: self [51719,51723]
===
match
---
trailer [51035,51045]
trailer [51035,51045]
===
match
---
param [22331,22352]
param [22331,22352]
===
match
---
trailer [36491,36525]
trailer [36491,36525]
===
match
---
suite [50765,50824]
suite [50765,50824]
===
match
---
trailer [47613,47617]
trailer [47613,47617]
===
match
---
simple_stmt [70340,70413]
simple_stmt [70764,70837]
===
match
---
operator: , [43980,43981]
operator: , [43980,43981]
===
match
---
dotted_name [1433,1455]
dotted_name [1433,1455]
===
match
---
trailer [5707,5713]
trailer [5707,5713]
===
match
---
name: path [16360,16364]
name: path [16360,16364]
===
match
---
trailer [37148,37154]
trailer [37148,37154]
===
match
---
operator: = [70348,70349]
operator: = [70772,70773]
===
match
---
name: self [47331,47335]
name: self [47331,47335]
===
match
---
name: all [78203,78206]
name: all [78627,78630]
===
match
---
atom_expr [79830,79840]
atom_expr [80254,80264]
===
match
---
trailer [78521,78526]
trailer [78945,78950]
===
match
---
name: self [24746,24750]
name: self [24746,24750]
===
match
---
operator: = [15504,15505]
operator: = [15504,15505]
===
match
---
operator: , [43700,43701]
operator: , [43700,43701]
===
match
---
dotted_name [2788,2810]
dotted_name [2788,2810]
===
match
---
simple_stmt [71563,71610]
simple_stmt [71987,72034]
===
match
---
fstring_string: . [46998,46999]
fstring_string: . [46998,46999]
===
match
---
param [17276,17307]
param [17276,17307]
===
match
---
param [15296,15315]
param [15296,15315]
===
match
---
operator: , [73592,73593]
operator: , [74016,74017]
===
match
---
name: self [66687,66691]
name: self [67111,67115]
===
match
---
name: self [24266,24270]
name: self [24266,24270]
===
match
---
param [80253,80257]
param [80677,80681]
===
match
---
atom [19804,19833]
atom [19804,19833]
===
match
---
atom_expr [7721,7760]
atom_expr [7721,7760]
===
match
---
name: where [7743,7748]
name: where [7743,7748]
===
match
---
trailer [59248,59260]
trailer [59672,59684]
===
match
---
atom [20273,20296]
atom [20273,20296]
===
match
---
decorator [80479,80489]
decorator [80903,80913]
===
match
---
trailer [48703,48715]
trailer [48703,48715]
===
match
---
name: task [5950,5954]
name: task [5950,5954]
===
match
---
name: ti [23904,23906]
name: ti [23904,23906]
===
match
---
trailer [54407,54416]
trailer [54831,54840]
===
match
---
name: task_id [78453,78460]
name: task_id [78877,78884]
===
match
---
parameters [21167,21187]
parameters [21167,21187]
===
match
---
operator: = [4883,4884]
operator: = [4883,4884]
===
match
---
name: self [15937,15941]
name: self [15937,15941]
===
match
---
name: tomorrow_ds [59269,59280]
name: tomorrow_ds [59693,59704]
===
match
---
if_stmt [20074,20120]
if_stmt [20074,20120]
===
match
---
atom_expr [41656,41666]
atom_expr [41656,41666]
===
match
---
trailer [46989,46997]
trailer [46989,46997]
===
match
---
operator: @ [9933,9934]
operator: @ [9933,9934]
===
match
---
trailer [52852,52857]
trailer [53276,53281]
===
match
---
name: test_mode [37632,37641]
name: test_mode [37632,37641]
===
match
---
name: state [2944,2949]
name: state [2944,2949]
===
match
---
atom_expr [33683,33887]
atom_expr [33683,33887]
===
match
---
decorated [80146,80215]
decorated [80570,80639]
===
match
---
simple_stmt [59269,59341]
simple_stmt [59693,59765]
===
match
---
trailer [8734,8749]
trailer [8734,8749]
===
match
---
atom_expr [36803,36820]
atom_expr [36803,36820]
===
match
---
simple_stmt [20262,20298]
simple_stmt [20262,20298]
===
match
---
annassign [79615,79631]
annassign [80039,80055]
===
match
---
operator: = [81112,81113]
operator: = [81536,81537]
===
match
---
simple_stmt [1150,1162]
simple_stmt [1150,1162]
===
match
---
operator: -> [37759,37761]
operator: -> [37759,37761]
===
match
---
trailer [45212,45233]
trailer [45212,45233]
===
match
---
string: 'inlets' [63918,63926]
string: 'inlets' [64342,64350]
===
match
---
name: query [81527,81532]
name: query [81951,81956]
===
match
---
argument [53303,53316]
argument [53727,53740]
===
match
---
name: ti [79927,79929]
name: ti [80351,80353]
===
match
---
name: ti [81771,81773]
name: ti [82195,82197]
===
match
---
simple_stmt [56250,56331]
simple_stmt [56674,56755]
===
match
---
name: self [72215,72219]
name: self [72639,72643]
===
match
---
trailer [63932,63939]
trailer [64356,64363]
===
match
---
name: ignore_task_deps [40139,40155]
name: ignore_task_deps [40139,40155]
===
match
---
trailer [79515,79525]
trailer [79939,79949]
===
match
---
name: self [80537,80541]
name: self [80961,80965]
===
match
---
name: task [58405,58409]
name: task [58829,58833]
===
match
---
name: models [2051,2057]
name: models [2051,2057]
===
match
---
trailer [54632,54644]
trailer [55056,55068]
===
match
---
name: sqlalchemy [1280,1290]
name: sqlalchemy [1280,1290]
===
match
---
name: RESTARTING [58048,58058]
name: RESTARTING [58472,58482]
===
match
---
name: Optional [55253,55261]
name: Optional [55677,55685]
===
match
---
name: task_copy [47683,47692]
name: task_copy [47683,47692]
===
match
---
except_clause [66726,66778]
except_clause [67150,67202]
===
match
---
arglist [48378,48409]
arglist [48378,48409]
===
match
---
tfpdef [72353,72363]
tfpdef [72777,72787]
===
match
---
operator: , [57737,57738]
operator: , [58161,58162]
===
match
---
name: self [70654,70658]
name: self [71078,71082]
===
match
---
simple_stmt [14631,14779]
simple_stmt [14631,14779]
===
match
---
name: tis [77502,77505]
name: tis [77926,77929]
===
match
---
simple_stmt [70695,70961]
simple_stmt [71119,71385]
===
match
---
name: context_to_airflow_vars [48354,48377]
name: context_to_airflow_vars [48354,48377]
===
match
---
suite [4112,4397]
suite [4112,4397]
===
match
---
operator: , [17483,17484]
operator: , [17483,17484]
===
match
---
atom_expr [50104,50121]
atom_expr [50104,50121]
===
match
---
name: REQUEUEABLE_DEPS [41281,41297]
name: REQUEUEABLE_DEPS [41281,41297]
===
match
---
trailer [9640,9648]
trailer [9640,9648]
===
match
---
operator: = [35029,35030]
operator: = [35029,35030]
===
match
---
name: KeyboardInterrupt [46806,46823]
name: KeyboardInterrupt [46806,46823]
===
match
---
trailer [54837,54855]
trailer [55261,55279]
===
match
---
parameters [79289,79313]
parameters [79713,79737]
===
match
---
arglist [7254,7509]
arglist [7254,7509]
===
match
---
and_test [26735,26798]
and_test [26735,26798]
===
match
---
name: dag_run_state [8328,8341]
name: dag_run_state [8328,8341]
===
match
---
name: key [75672,75675]
name: key [76096,76099]
===
match
---
return_stmt [29776,29787]
return_stmt [29776,29787]
===
match
---
atom_expr [47934,48001]
atom_expr [47934,48001]
===
match
---
name: render_templates [65822,65838]
name: render_templates [66246,66262]
===
match
---
trailer [27765,27768]
trailer [27765,27768]
===
match
---
decorated [72277,73604]
decorated [72701,74028]
===
match
---
trailer [60500,60509]
trailer [60924,60933]
===
match
---
name: test_mode [54266,54275]
name: test_mode [54690,54699]
===
match
---
string: "Setting task state for %s to %s" [26122,26155]
string: "Setting task state for %s to %s" [26122,26155]
===
match
---
trailer [67209,67214]
trailer [67633,67638]
===
match
---
trailer [35619,35626]
trailer [35619,35626]
===
match
---
trailer [31499,31504]
trailer [31499,31504]
===
match
---
expr_stmt [23096,23130]
expr_stmt [23096,23130]
===
match
---
operator: , [29030,29031]
operator: , [29030,29031]
===
match
---
operator: , [19534,19535]
operator: , [19534,19535]
===
match
---
name: self [56017,56021]
name: self [56441,56445]
===
match
---
atom_expr [79848,79855]
atom_expr [80272,80279]
===
match
---
name: end_date [54408,54416]
name: end_date [54832,54840]
===
match
---
name: Column [11514,11520]
name: Column [11514,11520]
===
match
---
trailer [59152,59167]
trailer [59576,59591]
===
match
---
atom_expr [43193,43225]
atom_expr [43193,43225]
===
match
---
operator: = [58410,58411]
operator: = [58834,58835]
===
match
---
name: execution_timeout [50552,50569]
name: execution_timeout [50552,50569]
===
match
---
simple_stmt [53776,53851]
simple_stmt [54200,54275]
===
match
---
atom_expr [41731,42013]
atom_expr [41731,42013]
===
match
---
trailer [57690,57696]
trailer [58114,58120]
===
match
---
trailer [51738,51745]
trailer [51738,51745]
===
match
---
name: self [9406,9410]
name: self [9406,9410]
===
match
---
name: log [24271,24274]
name: log [24271,24274]
===
match
---
name: relationship [82147,82159]
name: relationship [82571,82583]
===
match
---
operator: , [4098,4099]
operator: , [4098,4099]
===
match
---
expr_stmt [36480,36525]
expr_stmt [36480,36525]
===
match
---
name: replace [60746,60753]
name: replace [61170,61177]
===
match
---
atom_expr [20767,20805]
atom_expr [20767,20805]
===
match
---
operator: , [53629,53630]
operator: , [54053,54054]
===
match
---
atom_expr [22186,22196]
atom_expr [22186,22196]
===
match
---
fstring_start: f" [66819,66821]
fstring_start: f" [67243,67245]
===
match
---
operator: = [53334,53335]
operator: = [53758,53759]
===
match
---
operator: = [24368,24369]
operator: = [24368,24369]
===
match
---
name: start_date [26210,26220]
name: start_date [26210,26220]
===
match
---
simple_stmt [62293,62309]
simple_stmt [62717,62733]
===
match
---
operator: = [25844,25845]
operator: = [25844,25845]
===
match
---
operator: } [46997,46998]
operator: } [46997,46998]
===
match
---
suite [77976,78192]
suite [78400,78616]
===
match
---
trailer [81553,81729]
trailer [81977,82153]
===
match
---
atom_expr [53825,53850]
atom_expr [54249,54274]
===
match
---
simple_stmt [21873,21886]
simple_stmt [21873,21886]
===
match
---
atom_expr [54982,54998]
atom_expr [55406,55422]
===
match
---
atom_expr [11639,11679]
atom_expr [11639,11679]
===
match
---
if_stmt [65588,66299]
if_stmt [66012,66723]
===
match
---
name: execution_date [59880,59894]
name: execution_date [60304,60318]
===
match
---
name: var [61431,61434]
name: var [61855,61858]
===
match
---
name: params [66968,66974]
name: params [67392,67398]
===
match
---
name: execution_date [77947,77961]
name: execution_date [78371,78385]
===
match
---
name: pool [20171,20175]
name: pool [20171,20175]
===
match
---
return_stmt [31354,31414]
return_stmt [31354,31414]
===
match
---
expr_stmt [35023,35052]
expr_stmt [35023,35052]
===
match
---
name: end_date [56320,56328]
name: end_date [56744,56752]
===
match
---
name: Exception [57651,57660]
name: Exception [58075,58084]
===
match
---
trailer [32641,32649]
trailer [32641,32649]
===
match
---
suite [43290,43712]
suite [43290,43712]
===
match
---
name: tis [77580,77583]
name: tis [78004,78007]
===
match
---
name: AirflowSkipException [1767,1787]
name: AirflowSkipException [1767,1787]
===
match
---
funcdef [14510,14572]
funcdef [14510,14572]
===
match
---
suite [79774,79822]
suite [80198,80246]
===
match
---
operator: , [65883,65884]
operator: , [66307,66308]
===
match
---
name: force_fail [57838,57848]
name: force_fail [58262,58272]
===
match
---
operator: , [3967,3968]
operator: , [3967,3968]
===
match
---
name: SKIPPED [45795,45802]
name: SKIPPED [45795,45802]
===
match
---
trailer [23165,23171]
trailer [23165,23171]
===
match
---
name: task_tries [7464,7474]
name: task_tries [7464,7474]
===
match
---
operator: -> [30321,30323]
operator: -> [30321,30323]
===
match
---
name: QUEUED [9019,9025]
name: QUEUED [9019,9025]
===
match
---
name: self [81640,81644]
name: self [82064,82068]
===
match
---
name: session [22847,22854]
name: session [22847,22854]
===
match
---
atom_expr [32146,32163]
atom_expr [32146,32163]
===
match
---
atom_expr [11003,11016]
atom_expr [11003,11016]
===
match
---
or_test [26223,26254]
or_test [26223,26254]
===
match
---
suite [58364,65308]
suite [58788,65732]
===
match
---
atom_expr [61552,61560]
atom_expr [61976,61984]
===
match
---
trailer [77610,77617]
trailer [78034,78041]
===
match
---
simple_stmt [1909,1958]
simple_stmt [1909,1958]
===
match
---
name: dag_run_state [8298,8311]
name: dag_run_state [8298,8311]
===
match
---
name: error [53926,53931]
name: error [54350,54355]
===
match
---
trailer [57890,57913]
trailer [58314,58337]
===
match
---
operator: = [75566,75567]
operator: = [75990,75991]
===
match
---
atom_expr [32039,32076]
atom_expr [32039,32076]
===
match
---
name: dag_id [77906,77912]
name: dag_id [78330,78336]
===
match
---
dotted_name [1123,1135]
dotted_name [1123,1135]
===
match
---
not_test [42589,42602]
not_test [42589,42602]
===
match
---
trailer [8568,8583]
trailer [8568,8583]
===
match
---
trailer [48788,48810]
trailer [48788,48810]
===
match
---
atom_expr [6624,6634]
atom_expr [6624,6634]
===
match
---
atom_expr [71262,71316]
atom_expr [71686,71740]
===
match
---
name: task_id [77694,77701]
name: task_id [78118,78125]
===
match
---
expr_stmt [59704,59745]
expr_stmt [60128,60169]
===
match
---
atom_expr [67188,67215]
atom_expr [67612,67639]
===
match
---
name: task [52044,52048]
name: task [52186,52190]
===
match
---
atom_expr [61035,61106]
atom_expr [61459,61530]
===
match
---
string: """Prepare Task for Execution""" [47361,47393]
string: """Prepare Task for Execution""" [47361,47393]
===
match
---
simple_stmt [65494,65580]
simple_stmt [65918,66004]
===
match
---
argument [50877,50892]
argument [50877,50892]
===
match
---
name: execution_date [9425,9439]
name: execution_date [9425,9439]
===
match
---
atom_expr [59306,59318]
atom_expr [59730,59742]
===
match
---
import_from [2372,2448]
import_from [2372,2448]
===
match
---
name: kube_image [67917,67927]
name: kube_image [68341,68351]
===
match
---
string: 'run_id' [64632,64640]
string: 'run_id' [65056,65064]
===
match
---
name: dep_status [34271,34281]
name: dep_status [34271,34281]
===
match
---
suite [14538,14572]
suite [14538,14572]
===
match
---
operator: @ [63321,63322]
operator: @ [63745,63746]
===
match
---
return_stmt [28917,29049]
return_stmt [28917,29049]
===
match
---
trailer [79122,79144]
trailer [79546,79568]
===
match
---
trailer [71924,71968]
trailer [72348,72392]
===
match
---
atom_expr [26107,26169]
atom_expr [26107,26169]
===
match
---
operator: , [55220,55221]
operator: , [55644,55645]
===
match
---
name: Exception [4339,4348]
name: Exception [4339,4348]
===
match
---
import_from [47402,47472]
import_from [47402,47472]
===
match
---
operator: , [49298,49299]
operator: , [49298,49299]
===
match
---
sync_comp_for [78257,78269]
sync_comp_for [78681,78693]
===
match
---
expr_stmt [82070,82113]
expr_stmt [82494,82537]
===
match
---
trailer [73309,73316]
trailer [73733,73740]
===
match
---
trailer [81594,81602]
trailer [82018,82026]
===
match
---
name: __init__ [62261,62269]
name: __init__ [62685,62693]
===
match
---
decorator [72277,72294]
decorator [72701,72718]
===
match
---
trailer [50868,50876]
trailer [50868,50876]
===
match
---
trailer [63740,63744]
trailer [64164,64168]
===
match
---
atom_expr [37673,37686]
atom_expr [37673,37686]
===
match
---
name: hashlib [812,819]
name: hashlib [812,819]
===
match
---
operator: = [16873,16874]
operator: = [16873,16874]
===
match
---
fstring_string: ti.start. [45096,45105]
fstring_string: ti.start. [45096,45105]
===
match
---
name: orm [1444,1447]
name: orm [1444,1447]
===
match
---
not_test [45164,45180]
not_test [45164,45180]
===
match
---
simple_stmt [47779,47825]
simple_stmt [47779,47825]
===
match
---
trailer [70388,70395]
trailer [70812,70819]
===
match
---
name: _try_number [54987,54998]
name: _try_number [55411,55422]
===
match
---
term [35391,35443]
term [35391,35443]
===
match
---
name: dag_id [67750,67756]
name: dag_id [68174,68180]
===
match
---
import_from [901,936]
import_from [901,936]
===
match
---
operator: , [60697,60698]
operator: , [61121,61122]
===
match
---
name: log [72220,72223]
name: log [72644,72647]
===
match
---
operator: = [67681,67682]
operator: = [68105,68106]
===
match
---
atom_expr [9043,9070]
atom_expr [9043,9070]
===
match
---
name: __getattr__ [63163,63174]
name: __getattr__ [63587,63598]
===
match
---
trailer [51770,51775]
trailer [51770,51775]
===
match
---
trailer [81846,81848]
trailer [82270,82272]
===
match
---
atom [69381,69694]
atom [69805,70118]
===
match
---
arglist [11653,11677]
arglist [11653,11677]
===
match
---
name: self [26735,26739]
name: self [26735,26739]
===
match
---
string: """Get the email subject content for exceptions.""" [68512,68563]
string: """Get the email subject content for exceptions.""" [68936,68987]
===
match
---
name: provide_session [32657,32672]
name: provide_session [32657,32672]
===
match
---
operator: = [52037,52038]
operator: = [52179,52180]
===
match
---
simple_stmt [41234,41525]
simple_stmt [41234,41525]
===
match
---
expr_stmt [47062,47095]
expr_stmt [47062,47095]
===
match
---
string: "airflow" [19492,19501]
string: "airflow" [19492,19501]
===
match
---
name: property [80946,80954]
name: property [81370,81378]
===
match
---
operator: , [43902,43903]
operator: , [43902,43903]
===
match
---
expr_stmt [53776,53850]
expr_stmt [54200,54274]
===
match
---
trailer [80774,80791]
trailer [81198,81215]
===
match
---
simple_stmt [79401,79452]
simple_stmt [79825,79876]
===
match
---
operator: , [51501,51502]
operator: , [51501,51502]
===
match
---
name: jinja_context [69913,69926]
name: jinja_context [70337,70350]
===
match
---
trailer [61678,61682]
trailer [62102,62106]
===
match
---
atom_expr [43520,43531]
atom_expr [43520,43531]
===
match
---
name: __table__ [7724,7733]
name: __table__ [7724,7733]
===
match
---
atom_expr [32601,32650]
atom_expr [32601,32650]
===
match
---
expr_stmt [24021,24064]
expr_stmt [24021,24064]
===
match
---
operator: = [81882,81883]
operator: = [82306,82307]
===
match
---
name: os [44964,44966]
name: os [44964,44966]
===
match
---
simple_stmt [25086,25250]
simple_stmt [25086,25250]
===
match
---
name: session [81083,81090]
name: session [81507,81514]
===
match
---
operator: , [52682,52683]
operator: , [53106,53107]
===
match
---
param [72335,72344]
param [72759,72768]
===
match
---
trailer [47108,47119]
trailer [47108,47119]
===
match
---
name: TaskInstance [22993,23005]
name: TaskInstance [22993,23005]
===
match
---
name: verbose [32740,32747]
name: verbose [32740,32747]
===
match
---
expr_stmt [44747,44773]
expr_stmt [44747,44773]
===
match
---
simple_stmt [16400,16428]
simple_stmt [16400,16428]
===
match
---
return_stmt [43186,43243]
return_stmt [43186,43243]
===
match
---
name: self [76850,76854]
name: self [77274,77278]
===
match
---
simple_stmt [8298,8320]
simple_stmt [8298,8320]
===
match
---
fstring_string: operator_failures_ [56058,56076]
fstring_string: operator_failures_ [56482,56500]
===
match
---
trailer [11584,11610]
trailer [11584,11610]
===
match
---
name: primary_key [10839,10850]
name: primary_key [10839,10850]
===
match
---
atom_expr [23295,23308]
atom_expr [23295,23308]
===
match
---
string: "%s dependency '%s' PASSED: %s, %s" [34388,34423]
string: "%s dependency '%s' PASSED: %s, %s" [34388,34423]
===
match
---
operator: { [20933,20934]
operator: { [20933,20934]
===
match
---
atom_expr [23798,23813]
atom_expr [23798,23813]
===
match
---
operator: , [17345,17346]
operator: , [17345,17346]
===
match
---
simple_stmt [7708,7761]
simple_stmt [7708,7761]
===
match
---
trailer [11944,11963]
trailer [11944,11963]
===
match
---
trailer [42879,42883]
trailer [42879,42883]
===
match
---
name: str [25832,25835]
name: str [25832,25835]
===
match
---
name: dag_id [75531,75537]
name: dag_id [75955,75961]
===
match
---
trailer [55961,55966]
trailer [56385,56390]
===
match
---
operator: , [35766,35767]
operator: , [35766,35767]
===
match
---
name: self [49074,49078]
name: self [49074,49078]
===
match
---
param [71631,71636]
param [72055,72060]
===
match
---
trailer [76432,76438]
trailer [76856,76862]
===
match
---
trailer [76854,76862]
trailer [77278,77286]
===
match
---
operator: , [4212,4213]
operator: , [4212,4213]
===
match
---
tfpdef [17384,17408]
tfpdef [17384,17408]
===
match
---
trailer [12049,12090]
trailer [12049,12090]
===
match
---
name: max_tries [42355,42364]
name: max_tries [42355,42364]
===
match
---
return_stmt [62830,62903]
return_stmt [63254,63327]
===
match
---
atom_expr [51377,51437]
atom_expr [51377,51437]
===
match
---
not_test [66611,66632]
not_test [67035,67056]
===
match
---
name: self [46843,46847]
name: self [46843,46847]
===
match
---
arglist [65731,65768]
arglist [66155,66192]
===
match
---
name: context [50718,50725]
name: context [50718,50725]
===
match
---
argument [53139,53172]
argument [53563,53596]
===
match
---
name: timezone [26081,26089]
name: timezone [26081,26089]
===
match
---
atom_expr [27617,27644]
atom_expr [27617,27644]
===
match
---
name: run_as_user [79810,79821]
name: run_as_user [80234,80245]
===
match
---
string: 'ti_successes' [49884,49898]
string: 'ti_successes' [49884,49898]
===
match
---
name: run [52510,52513]
name: run [52934,52937]
===
match
---
expr_stmt [65494,65579]
expr_stmt [65918,66003]
===
match
---
trailer [60391,60403]
trailer [60815,60827]
===
match
---
name: _executor_config [79645,79661]
name: _executor_config [80069,80085]
===
match
---
simple_stmt [5705,5733]
simple_stmt [5705,5733]
===
match
---
param [68486,68491]
param [68910,68915]
===
match
---
name: first [81841,81846]
name: first [82265,82270]
===
match
---
operator: , [78899,78900]
operator: , [79323,79324]
===
match
---
expr_stmt [6386,6443]
expr_stmt [6386,6443]
===
match
---
name: state [52224,52229]
name: state [52508,52513]
===
match
---
suite [23144,23174]
suite [23144,23174]
===
match
---
name: jinja2 [1222,1228]
name: jinja2 [1222,1228]
===
match
---
atom_expr [25496,25512]
atom_expr [25496,25512]
===
match
---
simple_stmt [32174,32322]
simple_stmt [32174,32322]
===
match
---
name: timedelta [59226,59235]
name: timedelta [59650,59659]
===
match
---
name: task [60861,60865]
name: task [61285,61289]
===
match
---
decorated [26501,26799]
decorated [26501,26799]
===
match
---
suite [20715,21124]
suite [20715,21124]
===
match
---
atom_expr [67790,67802]
atom_expr [68214,68226]
===
match
---
parameters [32127,32133]
parameters [32127,32133]
===
match
---
atom_expr [30249,30271]
atom_expr [30249,30271]
===
match
---
suite [44018,47281]
suite [44018,47281]
===
match
---
param [17099,17112]
param [17099,17112]
===
match
---
operator: = [52675,52676]
operator: = [53099,53100]
===
match
---
name: upper [43499,43504]
name: upper [43499,43504]
===
match
---
string: """         Based on this instance's try_number, this will calculate         the number of previously attempted tries, defaulting to 0.         """ [14631,14778]
string: """         Based on this instance's try_number, this will calculate         the number of previously attempted tries, defaulting to 0.         """ [14631,14778]
===
match
---
name: bytes [4069,4074]
name: bytes [4069,4074]
===
match
---
trailer [21526,21540]
trailer [21526,21540]
===
match
---
trailer [47242,47248]
trailer [47242,47248]
===
match
---
simple_stmt [77235,77300]
simple_stmt [77659,77724]
===
match
---
atom_expr [62293,62301]
atom_expr [62717,62725]
===
match
---
expr_stmt [19444,19476]
expr_stmt [19444,19476]
===
match
---
trailer [60164,60172]
trailer [60588,60596]
===
match
---
fstring_expr [49835,49856]
fstring_expr [49835,49856]
===
match
---
name: self [36737,36741]
name: self [36737,36741]
===
match
---
name: max_tries [41981,41990]
name: max_tries [41981,41990]
===
match
---
operator: @ [49905,49906]
operator: @ [49905,49906]
===
match
---
expr_stmt [3224,3240]
expr_stmt [3224,3240]
===
match
---
name: ti [79489,79491]
name: ti [79913,79915]
===
match
---
expr_stmt [39651,39684]
expr_stmt [39651,39684]
===
match
---
trailer [31228,31232]
trailer [31228,31232]
===
match
---
name: utcnow [36812,36818]
name: utcnow [36812,36818]
===
match
---
operator: = [48352,48353]
operator: = [48352,48353]
===
match
---
name: merge [6541,6546]
name: merge [6541,6546]
===
match
---
atom_expr [9671,9698]
atom_expr [9671,9698]
===
match
---
trailer [79405,79421]
trailer [79829,79845]
===
match
---
name: self [59204,59208]
name: self [59628,59632]
===
match
---
trailer [61571,61575]
trailer [61995,61999]
===
match
---
and_test [8328,8362]
and_test [8328,8362]
===
match
---
trailer [22787,22831]
trailer [22787,22831]
===
match
---
arglist [70239,70313]
arglist [70663,70737]
===
match
---
param [51158,51162]
param [51158,51162]
===
match
---
name: test_mode [53270,53279]
name: test_mode [53694,53703]
===
match
---
argument [77904,77974]
argument [78328,78398]
===
match
---
trailer [31817,31851]
trailer [31817,31851]
===
match
---
if_stmt [59651,59979]
if_stmt [60075,60403]
===
match
---
name: conf [63711,63715]
name: conf [64135,64139]
===
match
---
name: mark_success [53536,53548]
name: mark_success [53960,53972]
===
match
---
name: extend [19582,19588]
name: extend [19582,19588]
===
match
---
name: timezone [40756,40764]
name: timezone [40756,40764]
===
match
---
atom_expr [47609,47670]
atom_expr [47609,47670]
===
match
---
atom_expr [24667,24677]
atom_expr [24667,24677]
===
match
---
name: task_id [21643,21650]
name: task_id [21643,21650]
===
match
---
trailer [24111,24127]
trailer [24111,24127]
===
match
---
trailer [20334,20341]
trailer [20334,20341]
===
match
---
operator: , [57859,57860]
operator: , [58283,58284]
===
match
---
name: strftime [60612,60620]
name: strftime [61036,61044]
===
match
---
trailer [11445,11451]
trailer [11445,11451]
===
match
---
trailer [71762,71788]
trailer [72186,72212]
===
match
---
trailer [79850,79855]
trailer [80274,80279]
===
match
---
name: session [49965,49972]
name: session [49965,49972]
===
match
---
name: task_type [49846,49855]
name: task_type [49846,49855]
===
match
---
trailer [4321,4327]
trailer [4321,4327]
===
match
---
argument [40308,40320]
argument [40308,40320]
===
match
---
name: execution_date [73511,73525]
name: execution_date [73935,73949]
===
match
---
name: self [22234,22238]
name: self [22234,22238]
===
match
---
operator: , [41954,41955]
operator: , [41954,41955]
===
match
---
atom_expr [57886,57926]
atom_expr [58310,58350]
===
match
---
trailer [76056,76066]
trailer [76480,76490]
===
match
---
atom_expr [76774,76793]
atom_expr [77198,77217]
===
match
---
argument [68002,68029]
argument [68426,68453]
===
match
---
argument [70491,70506]
argument [70915,70930]
===
match
---
argument [71300,71315]
argument [71724,71739]
===
match
---
trailer [59288,59303]
trailer [59712,59727]
===
match
---
name: self [26849,26853]
name: self [26849,26853]
===
match
---
name: AirflowException [47721,47737]
name: AirflowException [47721,47737]
===
match
---
operator: -> [80105,80107]
operator: -> [80529,80531]
===
match
---
atom_expr [11439,11451]
atom_expr [11439,11451]
===
match
---
atom_expr [16451,16460]
atom_expr [16451,16460]
===
match
---
operator: = [42095,42096]
operator: = [42095,42096]
===
match
---
dotted_name [81984,82004]
dotted_name [82408,82428]
===
match
---
atom_expr [11578,11610]
atom_expr [11578,11610]
===
match
---
name: self [57188,57192]
name: self [57612,57616]
===
match
---
name: signum [47581,47587]
name: signum [47581,47587]
===
match
---
trailer [65821,65838]
trailer [66245,66262]
===
match
---
name: end_date [10957,10965]
name: end_date [10957,10965]
===
match
---
expr_stmt [54087,54108]
expr_stmt [54511,54532]
===
match
---
simple_stmt [11244,11287]
simple_stmt [11244,11287]
===
match
---
arglist [39924,40173]
arglist [39924,40173]
===
match
---
trailer [20637,20645]
trailer [20637,20645]
===
match
---
atom_expr [76485,76513]
atom_expr [76909,76937]
===
match
---
dotted_name [2100,2123]
dotted_name [2100,2123]
===
match
---
name: Union [51492,51497]
name: Union [51492,51497]
===
match
---
operator: = [16405,16406]
operator: = [16405,16406]
===
match
---
name: self [24077,24081]
name: self [24077,24081]
===
match
---
trailer [46286,46301]
trailer [46286,46301]
===
match
---
operator: = [16809,16810]
operator: = [16809,16810]
===
match
---
dotted_name [43739,43759]
dotted_name [43739,43759]
===
match
---
name: self [31224,31228]
name: self [31224,31228]
===
match
---
atom_expr [70080,70095]
atom_expr [70504,70519]
===
match
---
name: DateTime [30981,30989]
name: DateTime [30981,30989]
===
match
---
simple_stmt [20331,20368]
simple_stmt [20331,20368]
===
match
---
name: self [24980,24984]
name: self [24980,24984]
===
match
---
tfpdef [17078,17089]
tfpdef [17078,17089]
===
match
---
name: STATICA_HACK [81869,81881]
name: STATICA_HACK [82293,82305]
===
match
---
simple_stmt [42378,42407]
simple_stmt [42378,42407]
===
match
---
string: 'webserver' [20834,20845]
string: 'webserver' [20834,20845]
===
match
---
simple_stmt [70520,70611]
simple_stmt [70944,71035]
===
match
---
name: var [62500,62503]
name: var [62924,62927]
===
match
---
name: extend [19719,19725]
name: extend [19719,19725]
===
match
---
simple_stmt [69025,69345]
simple_stmt [69449,69769]
===
match
---
name: pool [44825,44829]
name: pool [44825,44829]
===
match
---
operator: = [66685,66686]
operator: = [67109,67110]
===
match
---
string: "Exporting the following env vars:\n%s" [48454,48493]
string: "Exporting the following env vars:\n%s" [48454,48493]
===
match
---
name: operator [23954,23962]
name: operator [23954,23962]
===
match
---
fstring_expr [34739,34753]
fstring_expr [34739,34753]
===
match
---
trailer [23708,23717]
trailer [23708,23717]
===
match
---
argument [39315,39335]
argument [39315,39335]
===
match
---
atom [19887,19912]
atom [19887,19912]
===
match
---
parameters [13930,13936]
parameters [13930,13936]
===
match
---
operator: , [24347,24348]
operator: , [24347,24348]
===
match
---
name: DepContext [2361,2371]
name: DepContext [2361,2371]
===
match
---
atom_expr [50233,50309]
atom_expr [50233,50309]
===
match
---
operator: , [39313,39314]
operator: , [39313,39314]
===
match
---
funcdef [61723,61966]
funcdef [62147,62390]
===
match
---
name: dt [29027,29029]
name: dt [29027,29029]
===
match
---
argument [40139,40172]
argument [40139,40172]
===
match
---
operator: , [1103,1104]
operator: , [1103,1104]
===
match
---
testlist_comp [20274,20295]
testlist_comp [20274,20295]
===
match
---
name: task [44722,44726]
name: task [44722,44726]
===
match
---
name: execution_date [16576,16590]
name: execution_date [16576,16590]
===
match
---
operator: , [53125,53126]
operator: , [53549,53550]
===
match
---
import_from [3142,3199]
import_from [3142,3199]
===
match
---
name: TaskInstance [81667,81679]
name: TaskInstance [82091,82103]
===
match
---
name: self [50144,50148]
name: self [50144,50148]
===
match
---
funcdef [30837,31415]
funcdef [30837,31415]
===
match
---
string: """Render k8s pod yaml""" [67534,67559]
string: """Render k8s pod yaml""" [67958,67983]
===
match
---
name: Optional [27894,27902]
name: Optional [27894,27902]
===
match
---
trailer [33509,33514]
trailer [33509,33514]
===
match
---
trailer [59784,59799]
trailer [60208,60223]
===
match
---
atom_expr [29009,29030]
atom_expr [29009,29030]
===
match
---
simple_stmt [3084,3138]
simple_stmt [3084,3138]
===
match
---
suite [57775,57927]
suite [58199,58351]
===
match
---
name: provide_session [54176,54191]
name: provide_session [54600,54615]
===
match
---
suite [39728,42213]
suite [39728,42213]
===
match
---
dotted_name [37052,37073]
dotted_name [37052,37073]
===
match
---
operator: , [67988,67989]
operator: , [68412,68413]
===
match
---
name: conf [67170,67174]
name: conf [67594,67598]
===
match
---
operator: , [30919,30920]
operator: , [30919,30920]
===
match
---
expr_stmt [58546,58557]
expr_stmt [58970,58981]
===
match
---
trailer [23028,23043]
trailer [23028,23043]
===
match
---
name: scheduler_job_id [68120,68136]
name: scheduler_job_id [68544,68560]
===
match
---
operator: = [70768,70769]
operator: = [71192,71193]
===
match
---
decorator [13717,13732]
decorator [13717,13732]
===
match
---
name: v [48539,48540]
name: v [48539,48540]
===
match
---
decorated [13717,13897]
decorated [13717,13897]
===
match
---
trailer [8676,8844]
trailer [8676,8844]
===
match
---
param [61488,61493]
param [61912,61917]
===
match
---
string: "-" [39675,39678]
string: "-" [39675,39678]
===
match
---
param [61775,61834]
param [62199,62258]
===
match
---
name: values_ordered_by_id [76258,76278]
name: values_ordered_by_id [76682,76702]
===
match
---
trailer [35385,35390]
trailer [35385,35390]
===
match
---
simple_stmt [58198,58210]
simple_stmt [58622,58634]
===
match
---
name: mark_success [53231,53243]
name: mark_success [53655,53667]
===
match
---
fstring_start: f" [20961,20963]
fstring_start: f" [20961,20963]
===
match
---
trailer [27768,27771]
trailer [27768,27771]
===
match
---
simple_stmt [1471,1525]
simple_stmt [1471,1525]
===
match
---
import_name [857,870]
import_name [857,870]
===
match
---
trailer [43968,43973]
trailer [43968,43973]
===
match
---
name: session [57861,57868]
name: session [58285,58292]
===
match
---
name: task [47346,47350]
name: task [47346,47350]
===
match
---
trailer [64132,64140]
trailer [64556,64564]
===
match
---
name: self [64705,64709]
name: self [65129,65133]
===
match
---
operator: = [75638,75639]
operator: = [76062,76063]
===
match
---
tfpdef [43841,43856]
tfpdef [43841,43856]
===
match
---
string: '-' [60754,60757]
string: '-' [61178,61181]
===
match
---
suite [28808,28841]
suite [28808,28841]
===
match
---
name: SUCCESS [30802,30809]
name: SUCCESS [30802,30809]
===
match
---
name: set_error_file [4403,4417]
name: set_error_file [4403,4417]
===
match
---
name: execution_date [11914,11928]
name: execution_date [11914,11928]
===
match
---
suite [60340,60531]
suite [60764,60955]
===
match
---
string: '' [60759,60761]
string: '' [61183,61185]
===
match
---
name: str [79337,79340]
name: str [79761,79764]
===
match
---
name: bool [37574,37578]
name: bool [37574,37578]
===
match
---
trailer [25452,25467]
trailer [25452,25467]
===
match
---
trailer [17509,17514]
trailer [17509,17514]
===
match
---
string: """         Returns whether a task is in UP_FOR_RETRY state and its retry interval         has elapsed.         """ [26547,26662]
string: """         Returns whether a task is in UP_FOR_RETRY state and its retry interval         has elapsed.         """ [26547,26662]
===
match
---
name: content [71044,71051]
name: content [71468,71475]
===
match
---
name: airflow [67573,67580]
name: airflow [67997,68004]
===
match
---
trailer [23979,23991]
trailer [23979,23991]
===
match
---
name: self [24846,24850]
name: self [24846,24850]
===
match
---
expr_stmt [79361,79392]
expr_stmt [79785,79816]
===
match
---
operator: , [41917,41918]
operator: , [41917,41918]
===
match
---
simple_stmt [13689,13712]
simple_stmt [13689,13712]
===
match
---
name: try_number [9683,9693]
name: try_number [9683,9693]
===
match
---
name: html_content_err [71593,71609]
name: html_content_err [72017,72033]
===
match
---
name: task_ids [76318,76326]
name: task_ids [76742,76750]
===
match
---
operator: { [60876,60877]
operator: { [61300,61301]
===
match
---
name: BooleanClauseList [1507,1524]
name: BooleanClauseList [1507,1524]
===
match
---
operator: } [20645,20646]
operator: } [20645,20646]
===
match
---
name: get_previous_ti [31300,31315]
name: get_previous_ti [31300,31315]
===
match
---
argument [46333,46354]
argument [46333,46354]
===
match
---
name: jinja_env [70440,70449]
name: jinja_env [70864,70873]
===
match
---
operator: = [40754,40755]
operator: = [40754,40755]
===
match
---
atom_expr [34188,34200]
atom_expr [34188,34200]
===
match
---
trailer [36811,36818]
trailer [36811,36818]
===
match
---
decorator [80146,80156]
decorator [80570,80580]
===
match
---
name: task [58629,58633]
name: task [59053,59057]
===
match
---
operator: = [69986,69987]
operator: = [70410,70411]
===
match
---
name: update [67195,67201]
name: update [67619,67625]
===
match
---
name: set_duration [47135,47147]
name: set_duration [47135,47147]
===
match
---
operator: } [45117,45118]
operator: } [45117,45118]
===
match
---
suite [34828,36563]
suite [34828,36563]
===
match
---
expr_stmt [23798,23834]
expr_stmt [23798,23834]
===
match
---
name: queue [80815,80820]
name: queue [81239,81244]
===
match
---
testlist_comp [19655,19681]
testlist_comp [19655,19681]
===
match
---
if_stmt [40786,41025]
if_stmt [40786,41025]
===
match
---
name: PickleType [11585,11595]
name: PickleType [11585,11595]
===
match
---
name: render [71411,71417]
name: render [71835,71841]
===
match
---
name: refresh_from_task [12550,12567]
name: refresh_from_task [12550,12567]
===
match
---
name: task_copy [47543,47552]
name: task_copy [47543,47552]
===
match
---
name: extend [20210,20216]
name: extend [20210,20216]
===
match
---
name: test_mode [53280,53289]
name: test_mode [53704,53713]
===
match
---
name: self [22186,22190]
name: self [22186,22190]
===
match
---
operator: - [59224,59225]
operator: - [59648,59649]
===
match
---
name: task [57455,57459]
name: task [57879,57883]
===
match
---
name: _prepare_and_execute_task_with_callbacks [45257,45297]
name: _prepare_and_execute_task_with_callbacks [45257,45297]
===
match
---
name: and_ [78592,78596]
name: and_ [79016,79020]
===
match
---
classdef [79147,81867]
classdef [79571,82291]
===
match
---
atom_expr [22773,22831]
atom_expr [22773,22831]
===
match
---
name: next_execution_date [59758,59777]
name: next_execution_date [60182,60201]
===
match
---
string: """URL to mark TI success""" [20724,20752]
string: """URL to mark TI success""" [20724,20752]
===
match
---
name: self [61488,61492]
name: self [61912,61916]
===
match
---
operator: = [41654,41655]
operator: = [41654,41655]
===
match
---
name: ignore_task_deps [19846,19862]
name: ignore_task_deps [19846,19862]
===
match
---
name: task [15968,15972]
name: task [15968,15972]
===
match
---
tfpdef [79296,79312]
tfpdef [79720,79736]
===
match
---
name: refresh_from_db [46252,46267]
name: refresh_from_db [46252,46267]
===
match
---
operator: @ [3430,3431]
operator: @ [3430,3431]
===
match
---
if_stmt [12958,13162]
if_stmt [12958,13162]
===
match
---
param [50348,50357]
param [50348,50357]
===
match
---
trailer [59070,59077]
trailer [59494,59501]
===
match
---
param [12347,12352]
param [12347,12352]
===
match
---
return_stmt [78866,79017]
return_stmt [79290,79441]
===
match
---
name: self [12582,12586]
name: self [12582,12586]
===
match
---
trailer [6585,6604]
trailer [6585,6604]
===
match
---
name: in_env_var_format [48387,48404]
name: in_env_var_format [48387,48404]
===
match
---
name: email [2545,2550]
name: email [2545,2550]
===
match
---
trailer [19464,19474]
trailer [19464,19474]
===
match
---
name: self [28226,28230]
name: self [28226,28230]
===
match
---
operator: { [47971,47972]
operator: { [47971,47972]
===
match
---
parameters [50332,50358]
parameters [50332,50358]
===
match
---
name: ignore_task_deps [37517,37533]
name: ignore_task_deps [37517,37533]
===
match
---
name: register_in_sensor_service [49047,49073]
name: register_in_sensor_service [49047,49073]
===
match
---
name: exception [71637,71646]
name: exception [72061,72070]
===
match
---
name: error [47618,47623]
name: error [47618,47623]
===
match
---
expr_stmt [22186,22211]
expr_stmt [22186,22211]
===
match
---
trailer [35744,35746]
trailer [35744,35746]
===
match
---
operator: , [7617,7618]
operator: , [7617,7618]
===
match
---
expr_stmt [60194,60254]
expr_stmt [60618,60678]
===
match
---
param [17493,17522]
param [17493,17522]
===
match
---
atom [11829,12133]
atom [11829,12133]
===
match
---
name: self [55957,55961]
name: self [56381,56385]
===
match
---
name: str [51498,51501]
name: str [51498,51501]
===
match
---
name: query [76717,76722]
name: query [77141,77146]
===
match
---
name: str [57646,57649]
name: str [58070,58073]
===
match
---
decorator [36826,36843]
decorator [36826,36843]
===
match
---
name: engine [42777,42783]
name: engine [42777,42783]
===
match
---
suite [25851,26496]
suite [25851,26496]
===
match
---
name: State [2970,2975]
name: State [2970,2975]
===
match
---
name: TaskInstanceKey [80898,80913]
name: TaskInstanceKey [81322,81337]
===
match
---
name: self [43545,43549]
name: self [43545,43549]
===
match
---
operator: == [78333,78335]
operator: == [78757,78759]
===
match
---
decorated [80629,80692]
decorated [81053,81116]
===
match
---
decorated [27831,29788]
decorated [27831,29788]
===
match
---
name: rendered_k8s_spec [66615,66632]
name: rendered_k8s_spec [67039,67056]
===
match
---
name: context [45198,45205]
name: context [45198,45205]
===
match
---
trailer [65838,65840]
trailer [66262,66264]
===
match
---
name: overwrite_params_with_dag_run_conf [66927,66961]
name: overwrite_params_with_dag_run_conf [67351,67385]
===
match
---
trailer [52301,52319]
trailer [52585,52603]
===
match
---
name: extend [20335,20341]
name: extend [20335,20341]
===
match
---
name: task_id [20939,20946]
name: task_id [20939,20946]
===
match
---
try_stmt [3019,3241]
try_stmt [3019,3241]
===
match
---
name: session [42644,42651]
name: session [42644,42651]
===
match
---
name: ti [27763,27765]
name: ti [27763,27765]
===
match
---
atom_expr [58028,58038]
atom_expr [58452,58462]
===
match
---
param [62355,62360]
param [62779,62784]
===
match
---
operator: , [64709,64710]
operator: , [65133,65134]
===
match
---
name: session [66357,66364]
name: session [66781,66788]
===
match
---
trailer [78630,78637]
trailer [79054,79061]
===
match
---
suite [66985,67216]
suite [67409,67640]
===
match
---
trailer [9654,9669]
trailer [9654,9669]
===
match
---
name: Variable [61922,61930]
name: Variable [62346,62354]
===
match
---
name: client [3044,3050]
name: client [3044,3050]
===
match
---
simple_stmt [81869,81889]
simple_stmt [82293,82313]
===
match
---
param [17191,17221]
param [17191,17221]
===
match
---
name: dag_id [9873,9879]
name: dag_id [9873,9879]
===
match
---
expr_stmt [29063,29075]
expr_stmt [29063,29075]
===
match
---
name: self [43299,43303]
name: self [43299,43303]
===
match
---
decorated [21891,22265]
decorated [21891,22265]
===
match
---
funcdef [17048,20387]
funcdef [17048,20387]
===
match
---
operator: = [23267,23268]
operator: = [23267,23268]
===
match
---
simple_stmt [66380,66425]
simple_stmt [66804,66849]
===
match
---
atom_expr [29063,29069]
atom_expr [29063,29069]
===
match
---
trailer [65730,65769]
trailer [66154,66193]
===
match
---
atom_expr [12044,12090]
atom_expr [12044,12090]
===
match
---
if_stmt [4252,4285]
if_stmt [4252,4285]
===
match
---
name: seconds [36388,36395]
name: seconds [36388,36395]
===
match
---
string: "Task failed with exception" [55603,55631]
string: "Task failed with exception" [56027,56055]
===
match
---
operator: , [16959,16960]
operator: , [16959,16960]
===
match
---
operator: -> [32134,32136]
operator: -> [32134,32136]
===
match
---
operator: = [11188,11189]
operator: = [11188,11189]
===
match
---
simple_stmt [4973,5347]
simple_stmt [4973,5347]
===
match
---
expr_stmt [23335,23362]
expr_stmt [23335,23362]
===
match
---
simple_stmt [54982,55004]
simple_stmt [55406,55428]
===
match
---
argument [10820,10836]
argument [10820,10836]
===
match
---
name: pendulum [31555,31563]
name: pendulum [31555,31563]
===
match
---
operator: = [11430,11431]
operator: = [11430,11431]
===
match
---
sync_comp_for [76303,76326]
sync_comp_for [76727,76750]
===
match
---
operator: = [4236,4237]
operator: = [4236,4237]
===
match
---
decorator [73609,73626]
decorator [74033,74050]
===
match
---
name: self [79864,79868]
name: self [80288,80292]
===
match
---
funcdef [80327,80393]
funcdef [80751,80817]
===
match
---
name: State [22199,22204]
name: State [22199,22204]
===
match
---
name: ti [79538,79540]
name: ti [79962,79964]
===
match
---
name: conf [1589,1593]
name: conf [1589,1593]
===
match
---
name: task_id [9641,9648]
name: task_id [9641,9648]
===
match
---
name: self [42987,42991]
name: self [42987,42991]
===
match
---
string: """         Get datetime of the next retry if the task instance fails. For exponential         backoff, retry_delay is used as base and will be converted to seconds.         """ [34837,35014]
string: """         Get datetime of the next retry if the task instance fails. For exponential         backoff, retry_delay is used as base and will be converted to seconds.         """ [34837,35014]
===
match
---
tfpdef [37632,37647]
tfpdef [37632,37647]
===
match
---
dotted_name [2930,2949]
dotted_name [2930,2949]
===
match
---
operator: -> [80178,80180]
operator: -> [80602,80604]
===
match
---
if_stmt [19843,19914]
if_stmt [19843,19914]
===
match
---
name: TaskInstance [78923,78935]
name: TaskInstance [79347,79359]
===
match
---
operator: -> [31543,31545]
operator: -> [31543,31545]
===
match
---
name: self [73653,73657]
name: self [74077,74081]
===
match
---
simple_stmt [9166,9178]
simple_stmt [9166,9178]
===
match
---
trailer [29994,29999]
trailer [29994,29999]
===
match
---
suite [42603,42636]
suite [42603,42636]
===
match
---
trailer [29505,29535]
trailer [29505,29535]
===
match
---
suite [62402,62504]
suite [62826,62928]
===
match
---
simple_stmt [48423,48589]
simple_stmt [48423,48589]
===
match
---
trailer [23339,23348]
trailer [23339,23348]
===
match
---
funcdef [76540,76963]
funcdef [76964,77387]
===
match
---
simple_stmt [11179,11211]
simple_stmt [11179,11211]
===
match
---
simple_stmt [2038,2095]
simple_stmt [2038,2095]
===
match
---
simple_stmt [66994,67039]
simple_stmt [67418,67463]
===
match
---
trailer [11230,11239]
trailer [11230,11239]
===
match
---
name: datetime [80434,80442]
name: datetime [80858,80866]
===
match
---
operator: , [78110,78111]
operator: , [78534,78535]
===
match
---
atom_expr [23994,24008]
atom_expr [23994,24008]
===
match
---
expr_stmt [76258,76327]
expr_stmt [76682,76751]
===
match
---
name: kube_image [67940,67950]
name: kube_image [68364,68374]
===
match
---
trailer [45481,45484]
trailer [45481,45484]
===
match
---
comparison [58028,58058]
comparison [58452,58482]
===
match
---
name: get_template_context [67398,67418]
name: get_template_context [67822,67842]
===
match
---
operator: , [1735,1736]
operator: , [1735,1736]
===
match
---
operator: } [34737,34738]
operator: } [34737,34738]
===
match
---
name: self [45692,45696]
name: self [45692,45696]
===
match
---
name: max_tries [70903,70912]
name: max_tries [71327,71336]
===
match
---
expr_stmt [11560,11610]
expr_stmt [11560,11610]
===
match
---
expr_stmt [62419,62471]
expr_stmt [62843,62895]
===
match
---
atom_expr [63884,63903]
atom_expr [64308,64327]
===
match
---
argument [31329,31344]
argument [31329,31344]
===
match
---
name: dep_status [33855,33865]
name: dep_status [33855,33865]
===
match
---
atom_expr [11123,11138]
atom_expr [11123,11138]
===
match
---
name: session [52874,52881]
name: session [53298,53305]
===
match
---
name: dag_run [67162,67169]
name: dag_run [67586,67593]
===
match
---
trailer [17612,17617]
trailer [17612,17617]
===
match
---
comparison [53792,53819]
comparison [54216,54243]
===
match
---
fstring_end: " [34791,34792]
fstring_end: " [34791,34792]
===
match
---
name: AirflowNotFoundException [1679,1703]
name: AirflowNotFoundException [1679,1703]
===
match
---
expr_stmt [57031,57070]
expr_stmt [57455,57494]
===
match
---
name: next_ds [60077,60084]
name: next_ds [60501,60508]
===
match
---
name: ti [24088,24090]
name: ti [24088,24090]
===
match
---
operator: = [52635,52636]
operator: = [53059,53060]
===
match
---
arith_expr [26419,26450]
arith_expr [26419,26450]
===
match
---
name: pickle_id [19671,19680]
name: pickle_id [19671,19680]
===
match
---
trailer [6607,6618]
trailer [6607,6618]
===
match
---
operator: = [23814,23815]
operator: = [23814,23815]
===
match
---
operator: - [72125,72126]
operator: - [72549,72550]
===
match
---
operator: = [31868,31869]
operator: = [31868,31869]
===
match
---
suite [73160,73368]
suite [73584,73792]
===
match
---
operator: -> [17605,17607]
operator: -> [17605,17607]
===
match
---
suite [26869,27826]
suite [26869,27826]
===
match
---
operator: , [1844,1845]
operator: , [1844,1845]
===
match
---
string: """Write error into error file by path""" [4478,4519]
string: """Write error into error file by path""" [4478,4519]
===
match
---
operator: , [54264,54265]
operator: , [54688,54689]
===
match
---
decorated [9253,9440]
decorated [9253,9440]
===
match
---
simple_stmt [67300,67347]
simple_stmt [67724,67771]
===
match
---
trailer [45921,45940]
trailer [45921,45940]
===
match
---
trailer [77905,77912]
trailer [78329,78336]
===
match
---
name: email_for_state [57141,57156]
name: email_for_state [57565,57580]
===
match
---
trailer [59852,59856]
trailer [60276,60280]
===
match
---
name: self [20633,20637]
name: self [20633,20637]
===
match
---
atom_expr [41683,41714]
atom_expr [41683,41714]
===
match
---
operator: = [6399,6400]
operator: = [6399,6400]
===
match
---
param [52692,52722]
param [53116,53146]
===
match
---
atom_expr [13126,13161]
atom_expr [13126,13161]
===
match
---
name: _try_number [80542,80553]
name: _try_number [80966,80977]
===
match
---
name: Session [36877,36884]
name: Session [36877,36884]
===
match
---
trailer [54546,54779]
trailer [54970,55203]
===
match
---
trailer [6388,6398]
trailer [6388,6398]
===
match
---
string: 'DAGS_FOLDER' [16407,16420]
string: 'DAGS_FOLDER' [16407,16420]
===
match
---
not_test [56948,56979]
not_test [57372,57403]
===
match
---
name: ds_nodash [60540,60549]
name: ds_nodash [60964,60973]
===
match
---
name: info [33510,33514]
name: info [33510,33514]
===
match
---
param [15501,15511]
param [15501,15511]
===
match
---
expr_stmt [70191,70327]
expr_stmt [70615,70751]
===
match
---
name: ignore_all_deps [37432,37447]
name: ignore_all_deps [37432,37447]
===
match
---
trailer [7144,7632]
trailer [7144,7632]
===
match
---
name: Context [3490,3497]
name: Context [3490,3497]
===
match
---
trailer [52010,52018]
trailer [52152,52160]
===
match
---
name: self [14429,14433]
name: self [14429,14433]
===
match
---
operator: , [53217,53218]
operator: , [53641,53642]
===
match
---
operator: { [34725,34726]
operator: { [34725,34726]
===
match
---
atom_expr [79919,79949]
atom_expr [80343,80373]
===
match
---
operator: , [52721,52722]
operator: , [53145,53146]
===
match
---
name: queue [23863,23868]
name: queue [23863,23868]
===
match
---
simple_stmt [72094,72160]
simple_stmt [72518,72584]
===
match
---
name: Optional [37709,37717]
name: Optional [37709,37717]
===
match
---
simple_stmt [23798,23835]
simple_stmt [23798,23835]
===
match
---
operator: , [37586,37587]
operator: , [37586,37587]
===
match
---
name: ignore_ti_state [52692,52707]
name: ignore_ti_state [53116,53131]
===
match
---
trailer [67693,67695]
trailer [68117,68119]
===
match
---
trailer [35542,35547]
trailer [35542,35547]
===
match
---
atom [21499,21778]
atom [21499,21778]
===
match
---
argument [73399,73406]
argument [73823,73830]
===
match
---
name: signal [47786,47792]
name: signal [47786,47792]
===
match
---
param [4894,4965]
param [4894,4965]
===
match
---
name: pendulum [63866,63874]
name: pendulum [64290,64298]
===
match
---
subscriptlist [4095,4109]
subscriptlist [4095,4109]
===
match
---
simple_stmt [67430,67472]
simple_stmt [67854,67896]
===
match
---
argument [78153,78175]
argument [78577,78599]
===
match
---
if_stmt [41537,42213]
if_stmt [41537,42213]
===
match
---
atom_expr [64785,64799]
atom_expr [65209,65223]
===
match
---
simple_stmt [61915,61966]
simple_stmt [62339,62390]
===
match
---
not_test [77530,77537]
not_test [77954,77961]
===
match
---
comparison [27787,27825]
comparison [27787,27825]
===
match
---
trailer [8818,8824]
trailer [8818,8824]
===
match
---
name: session [28289,28296]
name: session [28289,28296]
===
match
---
simple_stmt [77596,77618]
simple_stmt [78020,78042]
===
match
---
expr_stmt [43125,43159]
expr_stmt [43125,43159]
===
match
---
operator: } [76243,76244]
operator: } [76667,76668]
===
match
---
atom_expr [59726,59745]
atom_expr [60150,60169]
===
match
---
operator: , [47344,47345]
operator: , [47344,47345]
===
match
---
expr_stmt [26205,26254]
expr_stmt [26205,26254]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.         """ [32174,32321]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.         """ [32174,32321]
===
match
---
decorator [9253,9263]
decorator [9253,9263]
===
match
---
trailer [45741,45763]
trailer [45741,45763]
===
match
---
trailer [50981,50994]
trailer [50981,50994]
===
match
---
suite [19630,19684]
suite [19630,19684]
===
match
---
trailer [68416,68421]
trailer [68840,68845]
===
match
---
trailer [72131,72142]
trailer [72555,72566]
===
match
---
trailer [12740,12753]
trailer [12740,12753]
===
match
---
atom_expr [8703,8716]
atom_expr [8703,8716]
===
match
---
name: self [34778,34782]
name: self [34778,34782]
===
match
---
trailer [44942,44944]
trailer [44942,44944]
===
match
---
name: TR [7721,7723]
name: TR [7721,7723]
===
match
---
name: start_date [80331,80341]
name: start_date [80755,80765]
===
match
---
strings [69062,69334]
strings [69486,69758]
===
match
---
name: self [70080,70084]
name: self [70504,70508]
===
match
---
simple_stmt [79963,80006]
simple_stmt [80387,80430]
===
match
---
name: kube_config [68272,68283]
name: kube_config [68696,68707]
===
match
---
name: close [53872,53877]
name: close [54296,54301]
===
match
---
name: self [55683,55687]
name: self [56107,56111]
===
match
---
subscriptlist [15800,15817]
subscriptlist [15800,15817]
===
match
---
import_name [847,856]
import_name [847,856]
===
match
---
trailer [48878,48880]
trailer [48878,48880]
===
match
---
expr_stmt [79864,79907]
expr_stmt [80288,80331]
===
match
---
parameters [77139,77194]
parameters [77563,77618]
===
match
---
parameters [80171,80177]
parameters [80595,80601]
===
match
---
simple_stmt [29776,29788]
simple_stmt [29776,29788]
===
match
---
name: job_id [53310,53316]
name: job_id [53734,53740]
===
match
---
name: verbose_aware_logger [33478,33498]
name: verbose_aware_logger [33478,33498]
===
match
---
string: """         Make an XCom available for tasks to pull.          :param key: A key for the XCom         :type key: str         :param value: A value for the XCom. The value is pickled and stored             in the database.         :type value: any picklable object         :param execution_date: if provided, the XCom will not be visible until             this date. This can be used, for example, to send a message to a             task on a future date without it being immediately visible.         :type execution_date: datetime         :param session: Sqlalchemy ORM Session         :type session: Session         """ [72472,73092]
string: """         Make an XCom available for tasks to pull.          :param key: A key for the XCom         :type key: str         :param value: A value for the XCom. The value is pickled and stored             in the database.         :type value: any picklable object         :param execution_date: if provided, the XCom will not be visible until             this date. This can be used, for example, to send a message to a             task on a future date without it being immediately visible.         :type execution_date: datetime         :param session: Sqlalchemy ORM Session         :type session: Session         """ [72896,73516]
===
match
---
atom_expr [58662,58692]
atom_expr [59086,59116]
===
match
---
trailer [49651,49665]
trailer [49651,49665]
===
match
---
argument [41570,41593]
argument [41570,41593]
===
match
---
trailer [7784,7796]
trailer [7784,7796]
===
match
---
name: provide_session [49906,49921]
name: provide_session [49906,49921]
===
match
---
operator: , [63381,63382]
operator: , [63805,63806]
===
match
---
suite [80112,80141]
suite [80536,80565]
===
match
---
trailer [7897,7906]
trailer [7897,7906]
===
match
---
argument [53270,53289]
argument [53694,53713]
===
match
---
name: path [71124,71128]
name: path [71548,71552]
===
match
---
name: dag_id [77611,77617]
name: dag_id [78035,78041]
===
match
---
number: 1 [56098,56099]
number: 1 [56522,56523]
===
match
---
param [37402,37423]
param [37402,37423]
===
match
---
trailer [47792,47824]
trailer [47792,47824]
===
match
---
name: dag_run [58999,59006]
name: dag_run [59423,59430]
===
match
---
expr_stmt [55481,55507]
expr_stmt [55905,55931]
===
match
---
name: _execution_date [79406,79421]
name: _execution_date [79830,79845]
===
match
---
suite [48002,49794]
suite [48002,49794]
===
match
---
trailer [45233,45235]
trailer [45233,45235]
===
match
---
name: execution_date [12012,12026]
name: execution_date [12012,12026]
===
match
---
name: ti [23096,23098]
name: ti [23096,23098]
===
match
---
atom_expr [35663,35678]
atom_expr [35663,35678]
===
match
---
atom_expr [25448,25467]
atom_expr [25448,25467]
===
match
---
name: airflow [2721,2728]
name: airflow [2721,2728]
===
match
---
parameters [52513,52893]
parameters [52937,53317]
===
match
---
simple_stmt [44984,45004]
simple_stmt [44984,45004]
===
match
---
suite [19780,19835]
suite [19780,19835]
===
match
---
atom_expr [45012,45028]
atom_expr [45012,45028]
===
match
---
atom_expr [64555,64604]
atom_expr [64979,65028]
===
match
---
simple_stmt [13241,13278]
simple_stmt [13241,13278]
===
match
---
and_test [77904,77961]
and_test [78328,78385]
===
match
---
name: first [77605,77610]
name: first [78029,78034]
===
match
---
atom_expr [20934,20946]
atom_expr [20934,20946]
===
match
---
name: prev_attempted_tries [6422,6442]
name: prev_attempted_tries [6422,6442]
===
match
---
trailer [54091,54096]
trailer [54515,54520]
===
match
---
param [55360,55373]
param [55784,55797]
===
match
---
name: self [46700,46704]
name: self [46700,46704]
===
match
---
name: TaskInstance [76826,76838]
name: TaskInstance [77250,77262]
===
match
---
trailer [11035,11047]
trailer [11035,11047]
===
match
---
simple_stmt [5884,5913]
simple_stmt [5884,5913]
===
match
---
operator: , [71096,71097]
operator: , [71520,71521]
===
match
---
name: settings [68322,68330]
name: settings [68746,68754]
===
match
---
funcdef [34673,34793]
funcdef [34673,34793]
===
match
---
operator: -> [77195,77197]
operator: -> [77619,77621]
===
match
---
suite [57084,57179]
suite [57508,57603]
===
match
---
except_clause [50739,50764]
except_clause [50739,50764]
===
match
---
operator: = [79536,79537]
operator: = [79960,79961]
===
match
---
atom [72110,72143]
atom [72534,72567]
===
match
---
name: staticmethod [17031,17043]
name: staticmethod [17031,17043]
===
match
---
string: "TaskInstance" [77160,77174]
string: "TaskInstance" [77584,77598]
===
match
---
name: task_id [9411,9418]
name: task_id [9411,9418]
===
match
---
name: task_id [35633,35640]
name: task_id [35633,35640]
===
match
---
atom_expr [33942,33999]
atom_expr [33942,33999]
===
match
---
name: dag_run [61090,61097]
name: dag_run [61514,61521]
===
match
---
name: error [55692,55697]
name: error [56116,56121]
===
match
---
number: 1 [59236,59237]
number: 1 [59660,59661]
===
match
---
atom_expr [67888,67903]
atom_expr [68312,68327]
===
match
---
arglist [48811,48824]
arglist [48811,48824]
===
match
---
operator: , [1353,1354]
operator: , [1353,1354]
===
match
---
comparison [21578,21612]
comparison [21578,21612]
===
match
---
import_from [2095,2139]
import_from [2095,2139]
===
match
---
simple_stmt [31285,31346]
simple_stmt [31285,31346]
===
match
---
operator: - [9694,9695]
operator: - [9694,9695]
===
match
---
expr_stmt [8447,8481]
expr_stmt [8447,8481]
===
match
---
atom_expr [24811,24837]
atom_expr [24811,24837]
===
match
---
name: ready_for_retry [36572,36587]
name: ready_for_retry [36572,36587]
===
match
---
operator: = [8932,8933]
operator: = [8932,8933]
===
match
---
atom_expr [48173,48245]
atom_expr [48173,48245]
===
match
---
name: _dag_id [80133,80140]
name: _dag_id [80557,80564]
===
match
---
atom_expr [49803,49864]
atom_expr [49803,49864]
===
match
---
trailer [76838,76846]
trailer [77262,77270]
===
match
---
operator: , [16674,16675]
operator: , [16674,16675]
===
match
---
name: dag_id [21591,21597]
name: dag_id [21591,21597]
===
match
---
trailer [57011,57018]
trailer [57435,57442]
===
match
---
trailer [52276,52281]
trailer [52560,52565]
===
match
---
expr_stmt [47482,47522]
expr_stmt [47482,47522]
===
match
---
operator: = [46887,46888]
operator: = [46887,46888]
===
match
---
trailer [47617,47623]
trailer [47617,47623]
===
match
---
operator: , [11955,11956]
operator: , [11955,11956]
===
match
---
name: self [22311,22315]
name: self [22311,22315]
===
match
---
name: append [3699,3705]
name: append [3699,3705]
===
match
---
name: conditions [7110,7120]
name: conditions [7110,7120]
===
match
---
operator: , [15286,15287]
operator: , [15286,15287]
===
match
---
yield_expr [3732,3745]
yield_expr [3732,3745]
===
match
---
name: replace [60555,60562]
name: replace [60979,60986]
===
match
---
trailer [40359,40366]
trailer [40359,40366]
===
match
---
name: loads [4316,4321]
name: loads [4316,4321]
===
match
---
if_stmt [7992,8320]
if_stmt [7992,8320]
===
match
---
suite [65783,66299]
suite [66207,66723]
===
match
---
trailer [43688,43700]
trailer [43688,43700]
===
match
---
suite [16379,16428]
suite [16379,16428]
===
match
---
trailer [55338,55343]
trailer [55762,55767]
===
match
---
atom_expr [55588,55648]
atom_expr [56012,56072]
===
match
---
suite [57388,57467]
suite [57812,57891]
===
match
---
string: "Task received SIGTERM signal" [47738,47768]
string: "Task received SIGTERM signal" [47738,47768]
===
match
---
name: end_date [36546,36554]
name: end_date [36546,36554]
===
match
---
atom_expr [5425,5441]
atom_expr [5425,5441]
===
match
---
name: self [39374,39378]
name: self [39374,39378]
===
match
---
param [57747,57760]
param [58171,58184]
===
match
---
trailer [70084,70095]
trailer [70508,70519]
===
match
---
trailer [59077,59079]
trailer [59501,59503]
===
match
---
name: log [22778,22781]
name: log [22778,22781]
===
match
---
atom_expr [42932,42951]
atom_expr [42932,42951]
===
match
---
name: property [9254,9262]
name: property [9254,9262]
===
match
---
name: test_mode [13694,13703]
name: test_mode [13694,13703]
===
match
---
suite [66650,66714]
suite [67074,67138]
===
match
---
string: "Executing %s on %s" [43001,43021]
string: "Executing %s on %s" [43001,43021]
===
match
---
operator: , [67848,67849]
operator: , [68272,68273]
===
match
---
param [80508,80512]
param [80932,80936]
===
match
---
name: TaskReschedule [3247,3261]
name: TaskReschedule [3247,3261]
===
match
---
name: self [26435,26439]
name: self [26435,26439]
===
match
---
operator: , [33800,33801]
operator: , [33800,33801]
===
match
---
string: "Please use `dag_run_state`" [8154,8182]
string: "Please use `dag_run_state`" [8154,8182]
===
match
---
name: self [71758,71762]
name: self [72182,72186]
===
match
---
trailer [45398,45406]
trailer [45398,45406]
===
match
---
atom_expr [60666,60702]
atom_expr [61090,61126]
===
match
---
name: session [22220,22227]
name: session [22220,22227]
===
match
---
trailer [13060,13064]
trailer [13060,13064]
===
match
---
suite [24375,25011]
suite [24375,25011]
===
match
---
operator: = [24128,24129]
operator: = [24128,24129]
===
match
---
atom_expr [79715,79728]
atom_expr [80139,80152]
===
match
---
param [15324,15346]
param [15324,15346]
===
match
---
trailer [7733,7740]
trailer [7733,7740]
===
match
---
name: html_content_err [71739,71755]
name: html_content_err [72163,72179]
===
match
---
name: TaskInstanceKey [77176,77191]
name: TaskInstanceKey [77600,77615]
===
match
---
name: pool [53330,53334]
name: pool [53754,53758]
===
match
---
trailer [79491,79502]
trailer [79915,79926]
===
match
---
operator: = [17299,17300]
operator: = [17299,17300]
===
match
---
name: hashlib [35535,35542]
name: hashlib [35535,35542]
===
match
---
name: TaskInstance [76774,76786]
name: TaskInstance [77198,77210]
===
match
---
and_test [29428,29471]
and_test [29428,29471]
===
match
---
simple_stmt [81832,81849]
simple_stmt [82256,82273]
===
match
---
atom_expr [46971,46982]
atom_expr [46971,46982]
===
match
---
atom_expr [78641,78650]
atom_expr [79065,79074]
===
match
---
name: append [5757,5763]
name: append [5757,5763]
===
match
---
atom_expr [79460,79476]
atom_expr [79884,79900]
===
match
---
operator: = [60302,60303]
operator: = [60726,60727]
===
match
---
atom_expr [54118,54141]
atom_expr [54542,54565]
===
match
---
argument [70121,70145]
argument [70545,70569]
===
match
---
name: str [79617,79620]
name: str [80041,80044]
===
match
---
operator: = [58792,58793]
operator: = [59216,59217]
===
match
---
trailer [26096,26098]
trailer [26096,26098]
===
match
---
name: count [76728,76733]
name: count [77152,77157]
===
match
---
operator: = [81929,81930]
operator: = [82353,82354]
===
match
---
trailer [54167,54169]
trailer [54591,54593]
===
match
---
trailer [78372,78387]
trailer [78796,78811]
===
match
---
simple_stmt [67568,67660]
simple_stmt [67992,68084]
===
match
---
simple_stmt [57335,57359]
simple_stmt [57759,57783]
===
match
---
atom_expr [22199,22211]
atom_expr [22199,22211]
===
match
---
name: String [1341,1347]
name: String [1341,1347]
===
match
---
name: self [25399,25403]
name: self [25399,25403]
===
match
---
and_test [39441,39516]
and_test [39441,39516]
===
match
---
simple_stmt [20376,20387]
simple_stmt [20376,20387]
===
match
---
simple_stmt [79323,79353]
simple_stmt [79747,79777]
===
match
---
simple_stmt [49988,50043]
simple_stmt [49988,50043]
===
match
---
not_test [57479,57492]
not_test [57903,57916]
===
match
---
atom_expr [23650,23663]
atom_expr [23650,23663]
===
match
---
name: session [66591,66598]
name: session [67015,67022]
===
match
---
trailer [42791,42793]
trailer [42791,42793]
===
match
---
trailer [57459,57465]
trailer [57883,57889]
===
match
---
operator: = [15440,15441]
operator: = [15440,15441]
===
match
---
string: 'execution_date can not be in the past (current ' [73207,73256]
string: 'execution_date can not be in the past (current ' [73631,73680]
===
match
---
operator: = [55367,55368]
operator: = [55791,55792]
===
match
---
string: "execution date %s has no timezone information. Using default from dag or system" [12817,12898]
string: "execution date %s has no timezone information. Using default from dag or system" [12817,12898]
===
match
---
name: jinja_context [70398,70411]
name: jinja_context [70822,70835]
===
match
---
name: context [3985,3992]
name: context [3985,3992]
===
match
---
name: session [27916,27923]
name: session [27916,27923]
===
match
---
name: html_content [71725,71737]
name: html_content [72149,72161]
===
match
---
operator: = [52858,52859]
operator: = [53282,53283]
===
match
---
atom_expr [60216,60254]
atom_expr [60640,60678]
===
match
---
operator: , [43152,43153]
operator: , [43152,43153]
===
match
---
operator: = [45361,45362]
operator: = [45361,45362]
===
match
---
name: FAILED [56195,56201]
name: FAILED [56619,56625]
===
match
---
expr_stmt [9182,9194]
expr_stmt [9182,9194]
===
match
---
name: Optional [31546,31554]
name: Optional [31546,31554]
===
match
---
simple_stmt [54819,54856]
simple_stmt [55243,55280]
===
match
---
simple_stmt [2194,2255]
simple_stmt [2194,2255]
===
match
---
or_test [56934,56979]
or_test [57358,57403]
===
match
---
string: 'execution_date is {}; received {})' [73273,73309]
string: 'execution_date is {}; received {})' [73697,73733]
===
match
---
tfpdef [17531,17550]
tfpdef [17531,17550]
===
match
---
name: pool_override [24355,24368]
name: pool_override [24355,24368]
===
match
---
operator: , [68302,68303]
operator: , [68726,68727]
===
match
---
fstring [48521,48531]
fstring [48521,48531]
===
match
---
operator: } [34788,34789]
operator: } [34788,34789]
===
match
---
operator: } [69759,69760]
operator: } [70183,70184]
===
match
---
atom_expr [4238,4247]
atom_expr [4238,4247]
===
match
---
operator: = [37579,37580]
operator: = [37579,37580]
===
match
---
trailer [8702,8761]
trailer [8702,8761]
===
match
---
name: task [44734,44738]
name: task [44734,44738]
===
match
---
arith_expr [6031,6063]
arith_expr [6031,6063]
===
match
---
operator: = [28224,28225]
operator: = [28224,28225]
===
match
---
operator: = [69046,69047]
operator: = [69470,69471]
===
match
---
name: max_tries [6019,6028]
name: max_tries [6019,6028]
===
match
---
trailer [42038,42046]
trailer [42038,42046]
===
match
---
operator: = [13852,13853]
operator: = [13852,13853]
===
match
---
name: merge [44992,44997]
name: merge [44992,44997]
===
match
---
operator: , [15491,15492]
operator: , [15491,15492]
===
match
---
atom_expr [43034,43053]
atom_expr [43034,43053]
===
match
---
name: test_mode [55498,55507]
name: test_mode [55922,55931]
===
match
---
name: reason [34562,34568]
name: reason [34562,34568]
===
match
---
param [80889,80893]
param [81313,81317]
===
match
---
if_stmt [23064,23174]
if_stmt [23064,23174]
===
match
---
comparison [78018,78047]
comparison [78442,78471]
===
match
---
simple_stmt [50683,50727]
simple_stmt [50683,50727]
===
match
---
trailer [42261,42266]
trailer [42261,42266]
===
match
---
string: """         Call callback defined for finished state change.          NOTE: Only invoke this function from caller of self._run_raw_task or         self.run         """ [51540,51707]
string: """         Call callback defined for finished state change.          NOTE: Only invoke this function from caller of self._run_raw_task or         self.run         """ [51540,51707]
===
match
---
simple_stmt [47264,47281]
simple_stmt [47264,47281]
===
match
---
trailer [65552,65573]
trailer [65976,65997]
===
match
---
atom [3322,3324]
atom [3322,3324]
===
match
---
name: airflow [2199,2206]
name: airflow [2199,2206]
===
match
---
argument [50710,50725]
argument [50710,50725]
===
match
---
string: 'task' [68739,68745]
string: 'task' [69163,69169]
===
match
---
string: 'BASE_URL' [20847,20857]
string: 'BASE_URL' [20847,20857]
===
match
---
atom_expr [44729,44738]
atom_expr [44729,44738]
===
match
---
name: Optional [17436,17444]
name: Optional [17436,17444]
===
match
---
name: base_url [20525,20533]
name: base_url [20525,20533]
===
match
---
operator: , [71042,71043]
operator: , [71466,71467]
===
match
---
simple_stmt [13315,13341]
simple_stmt [13315,13341]
===
match
---
operator: @ [26501,26502]
operator: @ [26501,26502]
===
match
---
trailer [5476,5482]
trailer [5476,5482]
===
match
---
return_stmt [10074,10085]
return_stmt [10074,10085]
===
match
---
trailer [61673,61683]
trailer [62097,62107]
===
match
---
operator: , [70881,70882]
operator: , [71305,71306]
===
match
---
arglist [48454,48574]
arglist [48454,48574]
===
match
---
atom_expr [58226,58243]
atom_expr [58650,58667]
===
match
---
trailer [16524,16531]
trailer [16524,16531]
===
match
---
trailer [67439,67462]
trailer [67863,67886]
===
match
---
param [57633,57662]
param [58057,58086]
===
match
---
expr_stmt [52349,52386]
expr_stmt [52633,52670]
===
match
---
trailer [43312,43711]
trailer [43312,43711]
===
match
---
name: queued_by_job_id [24048,24064]
name: queued_by_job_id [24048,24064]
===
match
---
name: generate_command [17052,17068]
name: generate_command [17052,17068]
===
match
---
number: 2 [32573,32574]
number: 2 [32573,32574]
===
match
---
trailer [20159,20177]
trailer [20159,20177]
===
match
---
decorated [20674,21124]
decorated [20674,21124]
===
match
---
atom_expr [42378,42406]
atom_expr [42378,42406]
===
match
---
trailer [55697,55710]
trailer [56121,56134]
===
match
---
name: e [46828,46829]
name: e [46828,46829]
===
match
---
arith_expr [14461,14481]
arith_expr [14461,14481]
===
match
---
operator: , [64140,64141]
operator: , [64564,64565]
===
match
---
trailer [35589,35700]
trailer [35589,35700]
===
match
---
name: ti [79755,79757]
name: ti [80179,80181]
===
match
---
operator: = [70308,70309]
operator: = [70732,70733]
===
match
---
name: timezone [13126,13134]
name: timezone [13126,13134]
===
match
---
name: queue [11351,11356]
name: queue [11351,11356]
===
match
---
name: math [35381,35385]
name: math [35381,35385]
===
match
---
trailer [75610,75831]
trailer [76034,76255]
===
match
---
atom [20217,20226]
atom [20217,20226]
===
match
---
atom_expr [12499,12511]
atom_expr [12499,12511]
===
match
---
name: dict [70733,70737]
name: dict [71157,71161]
===
match
---
if_stmt [76041,76514]
if_stmt [76465,76938]
===
match
---
name: collections [906,917]
name: collections [906,917]
===
match
---
atom_expr [56045,56100]
atom_expr [56469,56524]
===
match
---
except_clause [3200,3218]
except_clause [3200,3218]
===
match
---
name: XCom [25425,25429]
name: XCom [25425,25429]
===
match
---
suite [61022,61107]
suite [61446,61531]
===
match
---
funcdef [80811,80862]
funcdef [81235,81286]
===
match
---
operator: = [12267,12268]
operator: = [12267,12268]
===
match
---
import_from [8372,8412]
import_from [8372,8412]
===
match
---
name: _run_as_user [79701,79713]
name: _run_as_user [80125,80137]
===
match
---
string: "--ignore-all-dependencies" [19805,19832]
string: "--ignore-all-dependencies" [19805,19832]
===
match
---
name: extend [20100,20106]
name: extend [20100,20106]
===
match
---
name: pod [67704,67707]
name: pod [68128,68131]
===
match
---
trailer [32629,32650]
trailer [32629,32650]
===
match
---
name: self [48784,48788]
name: self [48784,48788]
===
match
---
simple_stmt [23935,23963]
simple_stmt [23935,23963]
===
match
---
name: result [49638,49644]
name: result [49638,49644]
===
match
---
simple_stmt [70425,70508]
simple_stmt [70849,70932]
===
match
---
name: self [80681,80685]
name: self [81105,81109]
===
match
---
atom_expr [73686,73711]
atom_expr [74110,74135]
===
match
---
decorator [61697,61711]
decorator [62121,62135]
===
match
---
name: self [79963,79967]
name: self [80387,80391]
===
match
---
funcdef [13736,13897]
funcdef [13736,13897]
===
match
---
string: "DAG" [15800,15805]
string: "DAG" [15800,15805]
===
match
---
simple_stmt [1118,1149]
simple_stmt [1118,1149]
===
match
---
expr_stmt [13241,13277]
expr_stmt [13241,13277]
===
match
---
atom_expr [4909,4943]
atom_expr [4909,4943]
===
match
---
suite [5788,6551]
suite [5788,6551]
===
match
---
name: self [14525,14529]
name: self [14525,14529]
===
match
---
expr_stmt [10992,11016]
expr_stmt [10992,11016]
===
match
---
atom_expr [73544,73563]
atom_expr [73968,73987]
===
match
---
trailer [35410,35412]
trailer [35410,35412]
===
match
---
name: key [73403,73406]
name: key [73827,73830]
===
match
---
string: 'dag' [63729,63734]
string: 'dag' [64153,64158]
===
match
---
atom_expr [27451,27483]
atom_expr [27451,27483]
===
match
---
classdef [10088,79018]
classdef [10088,79442]
===
match
---
operator: , [11904,11905]
operator: , [11904,11905]
===
match
---
name: on_execute_callback [51310,51329]
name: on_execute_callback [51310,51329]
===
match
---
trailer [25745,25760]
trailer [25745,25760]
===
match
---
param [58339,58351]
param [58763,58775]
===
match
---
trailer [79345,79352]
trailer [79769,79776]
===
match
---
atom_expr [79604,79615]
atom_expr [80028,80039]
===
match
---
atom_expr [47200,47221]
atom_expr [47200,47221]
===
match
---
trailer [68084,68106]
trailer [68508,68530]
===
match
---
operator: != [3833,3835]
operator: != [3833,3835]
===
match
---
comparison [81667,81718]
comparison [82091,82142]
===
match
---
name: math [842,846]
name: math [842,846]
===
match
---
operator: , [73465,73466]
operator: , [73889,73890]
===
match
---
funcdef [9267,9440]
funcdef [9267,9440]
===
match
---
atom_expr [79747,79773]
atom_expr [80171,80197]
===
match
---
name: set_duration [56022,56034]
name: set_duration [56446,56458]
===
match
---
name: count [27456,27461]
name: count [27456,27461]
===
match
---
name: datetime [80262,80270]
name: datetime [80686,80694]
===
match
---
name: COLLATION_ARGS [10750,10764]
name: COLLATION_ARGS [10750,10764]
===
match
---
name: log [43304,43307]
name: log [43304,43307]
===
match
---
name: String [11646,11652]
name: String [11646,11652]
===
match
---
param [13931,13935]
param [13931,13935]
===
match
---
operator: , [53289,53290]
operator: , [53713,53714]
===
match
---
trailer [71929,71934]
trailer [72353,72358]
===
match
---
name: FAILED [46634,46640]
name: FAILED [46634,46640]
===
match
---
simple_stmt [48173,48246]
simple_stmt [48173,48246]
===
match
---
name: models [3396,3402]
name: models [3396,3402]
===
match
---
suite [63239,63308]
suite [63663,63732]
===
match
---
name: dep_context [33419,33430]
name: dep_context [33419,33430]
===
match
---
atom_expr [7315,7508]
atom_expr [7315,7508]
===
match
---
trailer [25266,25272]
trailer [25266,25272]
===
match
---
name: innerjoin [12307,12316]
name: innerjoin [12307,12316]
===
match
---
arglist [22895,23044]
arglist [22895,23044]
===
match
---
name: provide_session [26805,26820]
name: provide_session [26805,26820]
===
match
---
string: 'prev_start_date_success' [64479,64504]
string: 'prev_start_date_success' [64903,64928]
===
match
---
trailer [82105,82113]
trailer [82529,82537]
===
match
---
name: property [13903,13911]
name: property [13903,13911]
===
match
---
classdef [61116,61966]
classdef [61540,62390]
===
match
---
atom_expr [13371,13381]
atom_expr [13371,13381]
===
match
---
name: exception_html [70800,70814]
name: exception_html [71224,71238]
===
match
---
name: datetime [79423,79431]
name: datetime [79847,79855]
===
match
---
simple_stmt [23847,23869]
simple_stmt [23847,23869]
===
match
---
name: Optional [79715,79723]
name: Optional [80139,80147]
===
match
---
operator: = [61081,61082]
operator: = [61505,61506]
===
match
---
operator: = [30795,30796]
operator: = [30795,30796]
===
match
---
operator: = [27908,27909]
operator: = [27908,27909]
===
match
---
arglist [3886,4025]
arglist [3886,4025]
===
match
---
atom_expr [26735,26745]
atom_expr [26735,26745]
===
match
---
name: task [12353,12357]
name: task [12353,12357]
===
match
---
name: self [26360,26364]
name: self [26360,26364]
===
match
---
atom_expr [55991,56008]
atom_expr [56415,56432]
===
match
---
funcdef [20406,20669]
funcdef [20406,20669]
===
match
---
operator: , [46875,46876]
operator: , [46875,46876]
===
match
---
param [9725,9730]
param [9725,9730]
===
match
---
name: execution_date [23006,23020]
name: execution_date [23006,23020]
===
match
---
name: tis [78999,79002]
name: tis [79423,79426]
===
match
---
name: task_tries [7572,7582]
name: task_tries [7572,7582]
===
match
---
name: key [51046,51049]
name: key [51046,51049]
===
match
---
name: property [20675,20683]
name: property [20675,20683]
===
match
---
name: dag_id [78893,78899]
name: dag_id [79317,79323]
===
match
---
simple_stmt [23157,23174]
simple_stmt [23157,23174]
===
match
---
name: key [9951,9954]
name: key [9951,9954]
===
match
---
simple_stmt [52349,52387]
simple_stmt [52633,52671]
===
match
---
name: task [54050,54054]
name: task [54474,54478]
===
match
---
name: job_id [15520,15526]
name: job_id [15520,15526]
===
match
---
name: activate_dag_runs [8267,8284]
name: activate_dag_runs [8267,8284]
===
match
---
name: property [80314,80322]
name: property [80738,80746]
===
match
---
operator: , [64799,64800]
operator: , [65223,65224]
===
match
---
operator: = [51853,51854]
operator: = [51853,51854]
===
match
---
string: "Failed to load task run error" [4365,4396]
string: "Failed to load task run error" [4365,4396]
===
match
---
atom_expr [51899,51919]
atom_expr [51899,51919]
===
match
---
trailer [16489,16506]
trailer [16489,16506]
===
match
---
trailer [27351,27356]
trailer [27351,27356]
===
match
---
operator: = [16219,16220]
operator: = [16219,16220]
===
match
---
atom_expr [8960,8973]
atom_expr [8960,8973]
===
match
---
name: task_type [56082,56091]
name: task_type [56506,56515]
===
match
---
name: Log [42488,42491]
name: Log [42488,42491]
===
match
---
simple_stmt [11616,11680]
simple_stmt [11616,11680]
===
match
---
name: next_retry_datetime [34802,34821]
name: next_retry_datetime [34802,34821]
===
match
---
simple_stmt [47609,47671]
simple_stmt [47609,47671]
===
match
---
argument [30790,30809]
argument [30790,30809]
===
match
---
parameters [15166,15172]
parameters [15166,15172]
===
match
---
atom_expr [6586,6603]
atom_expr [6586,6603]
===
match
---
string: '-' [60449,60452]
string: '-' [60873,60876]
===
match
---
param [62377,62387]
param [62801,62811]
===
match
---
name: self [37388,37392]
name: self [37388,37392]
===
match
---
name: task [55950,55954]
name: task [56374,56378]
===
match
---
name: has_option [71078,71088]
name: has_option [71502,71512]
===
match
---
name: TaskInstanceKey [9607,9622]
name: TaskInstanceKey [9607,9622]
===
match
---
param [21168,21173]
param [21168,21173]
===
match
---
name: staticmethod [63322,63334]
name: staticmethod [63746,63758]
===
match
---
operator: = [27933,27934]
operator: = [27933,27934]
===
match
---
simple_stmt [57972,58017]
simple_stmt [58396,58441]
===
match
---
name: self [42350,42354]
name: self [42350,42354]
===
match
---
name: start_date [26228,26238]
name: start_date [26228,26238]
===
match
---
try_stmt [4567,4798]
try_stmt [4567,4798]
===
match
---
suite [42463,42514]
suite [42463,42514]
===
match
---
name: self [71991,71995]
name: self [72415,72419]
===
match
---
name: delete [7734,7740]
name: delete [7734,7740]
===
match
---
string: 'html_content_template' [71503,71526]
string: 'html_content_template' [71927,71950]
===
match
---
name: render [70587,70593]
name: render [71011,71017]
===
match
---
trailer [9899,9914]
trailer [9899,9914]
===
match
---
trailer [23299,23308]
trailer [23299,23308]
===
match
---
trailer [80018,80025]
trailer [80442,80449]
===
match
---
name: self [42630,42634]
name: self [42630,42634]
===
match
---
expr_stmt [33405,33446]
expr_stmt [33405,33446]
===
match
---
name: self [58333,58337]
name: self [58757,58761]
===
match
---
trailer [45940,45992]
trailer [45940,45992]
===
match
---
expr_stmt [11351,11378]
expr_stmt [11351,11378]
===
match
---
name: prepare_for_execution [54055,54076]
name: prepare_for_execution [54479,54500]
===
match
---
trailer [80035,80041]
trailer [80459,80465]
===
match
---
simple_stmt [76394,76441]
simple_stmt [76818,76865]
===
match
---
trailer [20052,20065]
trailer [20052,20065]
===
match
---
name: lock_for_update [39315,39330]
name: lock_for_update [39315,39330]
===
match
---
name: ti [6605,6607]
name: ti [6605,6607]
===
match
---
operator: = [33612,33613]
operator: = [33612,33613]
===
match
---
argument [73420,73431]
argument [73844,73855]
===
match
---
trailer [32023,32034]
trailer [32023,32034]
===
match
---
trailer [20829,20833]
trailer [20829,20833]
===
match
---
operator: = [7719,7720]
operator: = [7719,7720]
===
match
---
name: airflow [37052,37059]
name: airflow [37052,37059]
===
match
---
arglist [12050,12089]
arglist [12050,12089]
===
match
---
name: path [16287,16291]
name: path [16287,16291]
===
match
---
tfpdef [17121,17145]
tfpdef [17121,17145]
===
match
---
string: 'previously_succeeded' [39541,39563]
string: 'previously_succeeded' [39541,39563]
===
match
---
name: verbose [41612,41619]
name: verbose [41612,41619]
===
match
---
name: instance [28871,28879]
name: instance [28871,28879]
===
match
---
atom_expr [23706,23717]
atom_expr [23706,23717]
===
match
---
atom_expr [65723,65769]
atom_expr [66147,66193]
===
match
---
suite [17618,20387]
suite [17618,20387]
===
match
---
not_test [16093,16106]
not_test [16093,16106]
===
match
---
suite [20136,20178]
suite [20136,20178]
===
match
---
name: isinstance [55542,55552]
name: isinstance [55966,55976]
===
match
---
name: task [57290,57294]
name: task [57714,57718]
===
match
---
name: ti [5929,5931]
name: ti [5929,5931]
===
match
---
name: task [52277,52281]
name: task [52561,52565]
===
match
---
name: self [26419,26423]
name: self [26419,26423]
===
match
---
expr_stmt [12998,13074]
expr_stmt [12998,13074]
===
match
---
operator: , [73869,73870]
operator: , [74293,74294]
===
match
---
trailer [27902,27907]
trailer [27902,27907]
===
match
---
simple_stmt [23295,23323]
simple_stmt [23295,23323]
===
match
---
atom_expr [30972,30989]
atom_expr [30972,30989]
===
match
---
trailer [62442,62471]
trailer [62866,62895]
===
match
---
trailer [49511,49540]
trailer [49511,49540]
===
match
---
suite [36594,36821]
suite [36594,36821]
===
match
---
decorator [80074,80084]
decorator [80498,80508]
===
match
---
operator: , [45958,45959]
operator: , [45958,45959]
===
match
---
name: prev_ds_nodash [60287,60301]
name: prev_ds_nodash [60711,60725]
===
match
---
name: test_mode [53579,53588]
name: test_mode [54003,54012]
===
match
---
operator: { [34739,34740]
operator: { [34739,34740]
===
match
---
atom_expr [7224,7531]
atom_expr [7224,7531]
===
match
---
fstring_expr [46970,46983]
fstring_expr [46970,46983]
===
match
---
atom_expr [78728,78755]
atom_expr [79152,79179]
===
match
---
atom [20885,21123]
atom [20885,21123]
===
match
---
simple_stmt [20206,20228]
simple_stmt [20206,20228]
===
match
---
trailer [64402,64430]
trailer [64826,64854]
===
match
---
param [62270,62274]
param [62694,62698]
===
match
---
name: state [29647,29652]
name: state [29647,29652]
===
match
---
name: task_copy [49675,49684]
name: task_copy [49675,49684]
===
match
---
atom_expr [41643,41653]
atom_expr [41643,41653]
===
match
---
expr_stmt [52032,52048]
expr_stmt [52174,52190]
===
match
---
simple_stmt [59089,59135]
simple_stmt [59513,59559]
===
match
---
operator: , [12357,12358]
operator: , [12357,12358]
===
match
---
operator: , [25369,25370]
operator: , [25369,25370]
===
match
---
atom_expr [11471,11490]
atom_expr [11471,11490]
===
match
---
operator: , [16531,16532]
operator: , [16531,16532]
===
match
---
name: quote [1143,1148]
name: quote [1143,1148]
===
match
---
name: self [9725,9729]
name: self [9725,9729]
===
match
---
name: next_retry_datetime [36779,36798]
name: next_retry_datetime [36779,36798]
===
match
---
name: self [13753,13757]
name: self [13753,13757]
===
match
---
name: ti [78816,78818]
name: ti [79240,79242]
===
match
---
name: property [20393,20401]
name: property [20393,20401]
===
match
---
trailer [80064,80068]
trailer [80488,80492]
===
match
---
operator: , [57661,57662]
operator: , [58085,58086]
===
match
---
name: warning [41692,41699]
name: warning [41692,41699]
===
match
---
name: jinja2 [1169,1175]
name: jinja2 [1169,1175]
===
match
---
name: airflow [2678,2685]
name: airflow [2678,2685]
===
match
---
trailer [81919,81925]
trailer [82343,82349]
===
match
---
string: "Recording the task instance as FAILED" [22137,22176]
string: "Recording the task instance as FAILED" [22137,22176]
===
match
---
operator: { [49835,49836]
operator: { [49835,49836]
===
match
---
simple_stmt [46700,46757]
simple_stmt [46700,46757]
===
match
---
atom_expr [13398,13411]
atom_expr [13398,13411]
===
match
---
expr_stmt [11495,11529]
expr_stmt [11495,11529]
===
match
---
trailer [23612,23622]
trailer [23612,23622]
===
match
---
term [35881,35902]
term [35881,35902]
===
match
---
name: self [32128,32132]
name: self [32128,32132]
===
match
---
simple_stmt [3857,4040]
simple_stmt [3857,4040]
===
match
---
name: session [42476,42483]
name: session [42476,42483]
===
match
---
name: log [3325,3328]
name: log [3325,3328]
===
match
---
name: _executor_config [81006,81022]
name: _executor_config [81430,81446]
===
match
---
name: dag_id [75701,75707]
name: dag_id [76125,76131]
===
match
---
trailer [46719,46756]
trailer [46719,46756]
===
match
---
name: from_string [70549,70560]
name: from_string [70973,70984]
===
match
---
atom_expr [59875,59894]
atom_expr [60299,60318]
===
match
---
arglist [10885,10914]
arglist [10885,10914]
===
match
---
name: convert_to_utc [13201,13215]
name: convert_to_utc [13201,13215]
===
match
---
tfpdef [43805,43823]
tfpdef [43805,43823]
===
match
---
simple_stmt [14454,14482]
simple_stmt [14454,14482]
===
match
---
atom_expr [71131,71153]
atom_expr [71555,71577]
===
match
---
name: dag_id [27518,27524]
name: dag_id [27518,27524]
===
match
---
simple_stmt [61152,61377]
simple_stmt [61576,61801]
===
match
---
operator: , [25823,25824]
operator: , [25823,25824]
===
match
---
and_test [32004,32076]
and_test [32004,32076]
===
match
---
trailer [24703,24708]
trailer [24703,24708]
===
match
---
name: ti [79987,79989]
name: ti [80411,80413]
===
match
---
decorator [80797,80807]
decorator [81221,81231]
===
match
---
name: task_id [9182,9189]
name: task_id [9182,9189]
===
match
---
expr_stmt [22841,23054]
expr_stmt [22841,23054]
===
match
---
name: self [25819,25823]
name: self [25819,25823]
===
match
---
trailer [7942,7944]
trailer [7942,7944]
===
match
---
name: dag_id [12268,12274]
name: dag_id [12268,12274]
===
match
---
name: AirflowSkipException [45519,45539]
name: AirflowSkipException [45519,45539]
===
match
---
operator: + [14478,14479]
operator: + [14478,14479]
===
match
---
operator: = [68770,68771]
operator: = [69194,69195]
===
match
---
fstring [45094,45134]
fstring [45094,45134]
===
match
---
raise_stmt [73173,73367]
raise_stmt [73597,73791]
===
match
---
trailer [66818,66877]
trailer [67242,67301]
===
match
---
atom_expr [79623,79631]
atom_expr [80047,80055]
===
match
---
name: try_number [25767,25777]
name: try_number [25767,25777]
===
match
---
name: content [71220,71227]
name: content [71644,71651]
===
match
---
simple_stmt [2876,2925]
simple_stmt [2876,2925]
===
match
---
atom_expr [21814,21825]
atom_expr [21814,21825]
===
match
---
name: TaskInstance [78901,78913]
name: TaskInstance [79325,79337]
===
match
---
name: conditions [7749,7759]
name: conditions [7749,7759]
===
match
---
name: tis [78172,78175]
name: tis [78596,78599]
===
match
---
name: cmd [20262,20265]
name: cmd [20262,20265]
===
match
---
funcdef [21150,21886]
funcdef [21150,21886]
===
match
---
name: deps [34249,34253]
name: deps [34249,34253]
===
match
---
fstring_expr [47952,47970]
fstring_expr [47952,47970]
===
match
---
name: overwrite_params_with_dag_run_conf [61040,61074]
name: overwrite_params_with_dag_run_conf [61464,61498]
===
match
---
operator: = [29599,29600]
operator: = [29599,29600]
===
match
---
trailer [53811,53819]
trailer [54235,54243]
===
match
---
comparison [5474,5499]
comparison [5474,5499]
===
match
---
string: 'ti' [64813,64817]
string: 'ti' [65237,65241]
===
match
---
operator: , [7450,7451]
operator: , [7450,7451]
===
match
---
simple_stmt [2491,2526]
simple_stmt [2491,2526]
===
match
---
trailer [26780,26796]
trailer [26780,26796]
===
match
---
name: self [10081,10085]
name: self [10081,10085]
===
match
---
param [24355,24373]
param [24355,24373]
===
match
---
trailer [43027,43032]
trailer [43027,43032]
===
match
---
name: bool [52745,52749]
name: bool [53169,53173]
===
match
---
name: operator [23940,23948]
name: operator [23940,23948]
===
match
---
name: _date_or_empty [43084,43098]
name: _date_or_empty [43084,43098]
===
match
---
name: state [12028,12033]
name: state [12028,12033]
===
match
---
name: state [21880,21885]
name: state [21880,21885]
===
match
---
operator: , [16780,16781]
operator: , [16780,16781]
===
match
---
trailer [37154,37162]
trailer [37154,37162]
===
match
---
trailer [43890,43895]
trailer [43890,43895]
===
match
---
trailer [30253,30269]
trailer [30253,30269]
===
match
---
simple_stmt [4273,4285]
simple_stmt [4273,4285]
===
match
---
trailer [3698,3705]
trailer [3698,3705]
===
match
---
name: __init__ [61394,61402]
name: __init__ [61818,61826]
===
match
---
import_from [937,977]
import_from [937,977]
===
match
---
name: hostname [44919,44927]
name: hostname [44919,44927]
===
match
---
operator: == [22964,22966]
operator: == [22964,22966]
===
match
---
annassign [40859,40923]
annassign [40859,40923]
===
match
---
trailer [58416,58421]
trailer [58840,58845]
===
match
---
or_test [26266,26330]
or_test [26266,26330]
===
match
---
name: state [29362,29367]
name: state [29362,29367]
===
match
---
simple_stmt [42131,42151]
simple_stmt [42131,42151]
===
match
---
name: self [36437,36441]
name: self [36437,36441]
===
match
---
trailer [76438,76440]
trailer [76862,76864]
===
match
---
operator: , [46314,46315]
operator: , [46314,46315]
===
match
---
operator: + [43402,43403]
operator: + [43402,43403]
===
match
---
trailer [81797,81803]
trailer [82221,82227]
===
match
---
simple_stmt [39242,39269]
simple_stmt [39242,39269]
===
match
---
simple_stmt [42253,42282]
simple_stmt [42253,42282]
===
match
---
trailer [5396,5443]
trailer [5396,5443]
===
match
---
simple_stmt [52942,53380]
simple_stmt [53366,53804]
===
match
---
simple_stmt [8447,8482]
simple_stmt [8447,8482]
===
match
---
suite [61849,61966]
suite [62273,62390]
===
match
---
param [61748,61758]
param [62172,62182]
===
match
---
name: foreign_keys [12255,12267]
name: foreign_keys [12255,12267]
===
match
---
name: self [54564,54568]
name: self [54988,54992]
===
match
---
operator: = [58553,58554]
operator: = [58977,58978]
===
match
---
simple_stmt [51173,51235]
simple_stmt [51173,51235]
===
match
---
name: __repr__ [34677,34685]
name: __repr__ [34677,34685]
===
match
---
simple_stmt [55907,55941]
simple_stmt [56331,56365]
===
match
---
atom_expr [48784,48825]
atom_expr [48784,48825]
===
match
---
name: task_copy [47972,47981]
name: task_copy [47972,47981]
===
match
---
trailer [52068,52088]
trailer [52210,52230]
===
match
---
name: self [53792,53796]
name: self [54216,54220]
===
match
---
expr_stmt [51845,51882]
expr_stmt [51845,51882]
===
match
---
trailer [14465,14477]
trailer [14465,14477]
===
match
---
name: result [76108,76114]
name: result [76532,76538]
===
match
---
name: int [79896,79899]
name: int [80320,80323]
===
match
---
trailer [64442,64450]
trailer [64866,64874]
===
match
---
atom_expr [3857,4039]
atom_expr [3857,4039]
===
match
---
atom_expr [49143,49360]
atom_expr [49143,49360]
===
match
---
name: merge [50138,50143]
name: merge [50138,50143]
===
match
---
suite [52101,52206]
suite [52243,52490]
===
match
---
name: yesterday_ds [59188,59200]
name: yesterday_ds [59612,59624]
===
match
---
name: self [9623,9627]
name: self [9623,9627]
===
match
---
atom_expr [71073,71102]
atom_expr [71497,71526]
===
match
---
expr_stmt [47531,47552]
expr_stmt [47531,47552]
===
match
---
atom_expr [42768,42793]
atom_expr [42768,42793]
===
match
---
arglist [46863,46898]
arglist [46863,46898]
===
match
---
string: '' [60699,60701]
string: '' [61123,61125]
===
match
---
trailer [24132,24148]
trailer [24132,24148]
===
match
---
tfpdef [73729,73750]
tfpdef [74153,74174]
===
match
---
expr_stmt [60353,60403]
expr_stmt [60777,60827]
===
match
---
name: logging_mixin [2639,2652]
name: logging_mixin [2639,2652]
===
match
---
param [17316,17346]
param [17316,17346]
===
match
---
expr_stmt [12139,12328]
expr_stmt [12139,12328]
===
match
---
simple_stmt [10957,10988]
simple_stmt [10957,10988]
===
match
---
operator: , [75679,75680]
operator: , [76103,76104]
===
match
---
name: self [9393,9397]
name: self [9393,9397]
===
match
---
name: DagRun [58826,58832]
name: DagRun [59250,59256]
===
match
---
trailer [14433,14445]
trailer [14433,14445]
===
match
---
name: TaskInstance [22895,22907]
name: TaskInstance [22895,22907]
===
match
---
name: TaskInstance [22943,22955]
name: TaskInstance [22943,22955]
===
match
---
operator: , [25760,25761]
operator: , [25760,25761]
===
match
---
argument [45346,45366]
argument [45346,45366]
===
match
---
trailer [78231,78239]
trailer [78655,78663]
===
match
---
operator: = [26079,26080]
operator: = [26079,26080]
===
match
---
sync_comp_for [78812,78825]
sync_comp_for [79236,79249]
===
match
---
string: 'conn' [65170,65176]
string: 'conn' [65594,65600]
===
match
---
name: state [23391,23396]
name: state [23391,23396]
===
match
---
name: from_obj [68076,68084]
name: from_obj [68500,68508]
===
match
---
atom_expr [19643,19683]
atom_expr [19643,19683]
===
match
---
name: format [35583,35589]
name: format [35583,35589]
===
match
---
trailer [70371,70388]
trailer [70795,70812]
===
match
---
comparison [22895,22929]
comparison [22895,22929]
===
match
---
atom_expr [23730,23741]
atom_expr [23730,23741]
===
match
---
param [71044,71051]
param [71468,71475]
===
match
---
string: 'tomorrow_ds_nodash' [64877,64897]
string: 'tomorrow_ds_nodash' [65301,65321]
===
match
---
trailer [20488,20503]
trailer [20488,20503]
===
match
---
simple_stmt [55066,55136]
simple_stmt [55490,55560]
===
match
---
trailer [57115,57128]
trailer [57539,57552]
===
match
---
name: jinja_env [70539,70548]
name: jinja_env [70963,70972]
===
match
---
string: 'ds' [63790,63794]
string: 'ds' [64214,64218]
===
match
---
atom_expr [76282,76302]
atom_expr [76706,76726]
===
match
---
trailer [24792,24808]
trailer [24792,24808]
===
match
---
trailer [24047,24064]
trailer [24047,24064]
===
match
---
name: on_kill [50792,50799]
name: on_kill [50792,50799]
===
match
---
trailer [72143,72157]
trailer [72567,72581]
===
match
---
name: State [27720,27725]
name: State [27720,27725]
===
match
---
name: default_html_content_err [71528,71552]
name: default_html_content_err [71952,71976]
===
match
---
expr_stmt [49024,49088]
expr_stmt [49024,49088]
===
match
---
operator: , [30222,30223]
operator: , [30222,30223]
===
match
---
operator: , [64863,64864]
operator: , [65287,65288]
===
match
---
name: query [75589,75594]
name: query [76013,76018]
===
match
---
comparison [21630,21666]
comparison [21630,21666]
===
match
---
operator: , [16982,16983]
operator: , [16982,16983]
===
match
---
name: Optional [77198,77206]
name: Optional [77622,77630]
===
match
---
testlist_comp [19492,19539]
testlist_comp [19492,19539]
===
match
---
atom_expr [27578,27602]
atom_expr [27578,27602]
===
match
---
param [36862,36867]
param [36862,36867]
===
match
---
operator: , [37622,37623]
operator: , [37622,37623]
===
match
---
name: instance [60501,60509]
name: instance [60925,60933]
===
match
---
expr_stmt [7958,7986]
expr_stmt [7958,7986]
===
match
---
expr_stmt [39345,39365]
expr_stmt [39345,39365]
===
match
---
trailer [79723,79728]
trailer [80147,80152]
===
match
---
atom_expr [42131,42150]
atom_expr [42131,42150]
===
match
---
name: error [55704,55709]
name: error [56128,56133]
===
match
---
number: 1 [39568,39569]
number: 1 [39568,39569]
===
match
---
name: str [62560,62563]
name: str [62984,62987]
===
match
---
or_test [26360,26389]
or_test [26360,26389]
===
match
---
suite [71648,71969]
suite [72072,72393]
===
match
---
name: self [58900,58904]
name: self [59324,59328]
===
match
---
atom_expr [13287,13302]
atom_expr [13287,13302]
===
match
---
name: int [17404,17407]
name: int [17404,17407]
===
match
---
simple_stmt [43063,43075]
simple_stmt [43063,43075]
===
match
---
string: """Get Airflow Connection value""" [63456,63490]
string: """Get Airflow Connection value""" [63880,63914]
===
match
---
name: task_id [78699,78706]
name: task_id [79123,79130]
===
match
---
name: context [52403,52410]
name: context [52687,52694]
===
match
---
atom_expr [47130,47149]
atom_expr [47130,47149]
===
match
---
suite [14409,14446]
suite [14409,14446]
===
match
---
comparison [78440,78477]
comparison [78864,78901]
===
match
---
string: 'mssql' [78543,78550]
string: 'mssql' [78967,78974]
===
match
---
name: String [10733,10739]
name: String [10733,10739]
===
match
---
atom_expr [4080,4111]
atom_expr [4080,4111]
===
match
---
trailer [41661,41666]
trailer [41661,41666]
===
match
---
if_stmt [5513,5775]
if_stmt [5513,5775]
===
match
---
name: FAILED [22205,22211]
name: FAILED [22205,22211]
===
match
---
suite [47175,47255]
suite [47175,47255]
===
match
---
name: on_success_callback [52069,52088]
name: on_success_callback [52211,52230]
===
match
---
name: self [80287,80291]
name: self [80711,80715]
===
match
---
name: self [48219,48223]
name: self [48219,48223]
===
match
---
trailer [22777,22781]
trailer [22777,22781]
===
match
---
operator: , [68737,68738]
operator: , [69161,69162]
===
match
---
suite [70625,71554]
suite [71049,71978]
===
match
---
suite [27398,27423]
suite [27398,27423]
===
match
---
name: start_date [40985,40995]
name: start_date [40985,40995]
===
match
---
name: State [56189,56194]
name: State [56613,56618]
===
match
---
operator: + [36555,36556]
operator: + [36555,36556]
===
match
---
atom_expr [21578,21597]
atom_expr [21578,21597]
===
match
---
atom_expr [60433,60457]
atom_expr [60857,60881]
===
match
---
argument [29624,29639]
argument [29624,29639]
===
match
---
operator: , [8214,8215]
operator: , [8214,8215]
===
match
---
name: task_id [76294,76301]
name: task_id [76718,76725]
===
match
---
expr_stmt [48331,48410]
expr_stmt [48331,48410]
===
match
---
name: execution_date [8569,8583]
name: execution_date [8569,8583]
===
match
---
expr_stmt [81771,81805]
expr_stmt [82195,82229]
===
match
---
name: last_scheduling_decision [9046,9070]
name: last_scheduling_decision [9046,9070]
===
match
---
name: TYPE_CHECKING [1041,1054]
name: TYPE_CHECKING [1041,1054]
===
match
---
name: self [43142,43146]
name: self [43142,43146]
===
match
---
atom_expr [42415,42431]
atom_expr [42415,42431]
===
match
---
atom_expr [31803,31851]
atom_expr [31803,31851]
===
match
---
funcdef [71615,71969]
funcdef [72039,72393]
===
match
---
name: ds [59089,59091]
name: ds [59513,59515]
===
match
---
name: dag [28251,28254]
name: dag [28251,28254]
===
match
---
arglist [67103,67174]
arglist [67527,67598]
===
match
---
name: dag_run [67202,67209]
name: dag_run [67626,67633]
===
match
---
name: params [60906,60912]
name: params [61330,61336]
===
match
---
simple_stmt [24107,24149]
simple_stmt [24107,24149]
===
match
---
trailer [81526,81532]
trailer [81950,81956]
===
match
---
name: params [58685,58691]
name: params [59109,59115]
===
match
---
operator: , [1039,1040]
operator: , [1039,1040]
===
match
---
trailer [5857,5866]
trailer [5857,5866]
===
match
---
operator: = [39928,39929]
operator: = [39928,39929]
===
match
---
atom_expr [13837,13851]
atom_expr [13837,13851]
===
match
---
operator: = [43824,43825]
operator: = [43824,43825]
===
match
---
name: get_template_context [52364,52384]
name: get_template_context [52648,52668]
===
match
---
trailer [16004,16009]
trailer [16004,16009]
===
match
---
name: get_prev [29018,29026]
name: get_prev [29018,29026]
===
match
---
name: Optional [79887,79895]
name: Optional [80311,80319]
===
match
---
name: parse [1130,1135]
name: parse [1130,1135]
===
match
---
fstring_string: . [46983,46984]
fstring_string: . [46983,46984]
===
match
---
name: is_smart_sensor_compatible [48852,48878]
name: is_smart_sensor_compatible [48852,48878]
===
match
---
name: utcnow [40765,40771]
name: utcnow [40765,40771]
===
match
---
simple_stmt [1594,1848]
simple_stmt [1594,1848]
===
match
---
name: PodGenerator [68236,68248]
name: PodGenerator [68660,68672]
===
match
---
param [73729,73758]
param [74153,74182]
===
match
---
decorated [9933,10086]
decorated [9933,10086]
===
match
---
expr_stmt [61426,61441]
expr_stmt [61850,61865]
===
match
---
name: ti [48127,48129]
name: ti [48127,48129]
===
match
---
exprlist [65638,65664]
exprlist [66062,66088]
===
match
---
name: os [48602,48604]
name: os [48602,48604]
===
match
---
name: models [2108,2114]
name: models [2108,2114]
===
match
---
name: duration [23340,23348]
name: duration [23340,23348]
===
match
---
trailer [54434,54436]
trailer [54858,54860]
===
match
---
name: self [22826,22830]
name: self [22826,22830]
===
match
---
expr_stmt [60830,60888]
expr_stmt [61254,61312]
===
match
---
trailer [49147,49151]
trailer [49147,49151]
===
match
---
atom_expr [24699,24708]
atom_expr [24699,24708]
===
match
---
name: UP_FOR_RETRY [26318,26330]
name: UP_FOR_RETRY [26318,26330]
===
match
---
name: Index [11839,11844]
name: Index [11839,11844]
===
match
---
atom_expr [42333,42348]
atom_expr [42333,42348]
===
match
---
trailer [23627,23637]
trailer [23627,23637]
===
match
---
name: t [77966,77967]
name: t [78390,78391]
===
match
---
trailer [12978,12980]
trailer [12978,12980]
===
match
---
trailer [3348,3358]
trailer [3348,3358]
===
match
---
atom_expr [77508,77517]
atom_expr [77932,77941]
===
match
---
name: cmd [19961,19964]
name: cmd [19961,19964]
===
match
---
trailer [41747,42013]
trailer [41747,42013]
===
match
---
atom_expr [56277,56296]
atom_expr [56701,56720]
===
match
---
name: conf [67070,67074]
name: conf [67494,67498]
===
match
---
decorated [32656,34020]
decorated [32656,34020]
===
match
---
operator: = [17367,17368]
operator: = [17367,17368]
===
match
---
trailer [76786,76793]
trailer [77210,77217]
===
match
---
name: pickler [11596,11603]
name: pickler [11596,11603]
===
match
---
name: bool [37643,37647]
name: bool [37643,37647]
===
match
---
name: raw [13625,13628]
name: raw [13625,13628]
===
match
---
simple_stmt [66433,66504]
simple_stmt [66857,66928]
===
match
---
atom_expr [20331,20367]
atom_expr [20331,20367]
===
match
---
atom_expr [29736,29748]
atom_expr [29736,29748]
===
match
---
name: dag_id [25348,25354]
name: dag_id [25348,25354]
===
match
---
comp_op [51816,51822]
comp_op [51816,51822]
===
match
---
name: pid [44958,44961]
name: pid [44958,44961]
===
match
---
decorated [80074,80141]
decorated [80498,80565]
===
match
---
name: state [26740,26745]
name: state [26740,26745]
===
match
---
atom_expr [35615,35626]
atom_expr [35615,35626]
===
match
---
atom_expr [54728,54764]
atom_expr [55152,55188]
===
match
---
argument [16946,16959]
argument [16946,16959]
===
match
---
import_name [871,884]
import_name [871,884]
===
match
---
atom_expr [59063,59079]
atom_expr [59487,59503]
===
match
---
dotted_name [2531,2550]
dotted_name [2531,2550]
===
match
---
operator: = [12530,12531]
operator: = [12530,12531]
===
match
---
operator: , [51065,51066]
operator: , [51065,51066]
===
match
---
fstring [20922,20948]
fstring [20922,20948]
===
match
---
operator: = [48045,48046]
operator: = [48045,48046]
===
match
---
arglist [42492,42511]
arglist [42492,42511]
===
match
---
decorated [55141,57551]
decorated [55565,57975]
===
match
---
trailer [23770,23775]
trailer [23770,23775]
===
match
---
name: self [80583,80587]
name: self [81007,81011]
===
match
---
operator: , [1110,1111]
operator: , [1110,1111]
===
match
---
operator: = [8238,8239]
operator: = [8238,8239]
===
match
---
atom_expr [60552,60571]
atom_expr [60976,60995]
===
match
---
trailer [70483,70490]
trailer [70907,70914]
===
match
---
atom_expr [26402,26415]
atom_expr [26402,26415]
===
match
---
operator: , [7181,7182]
operator: , [7181,7182]
===
match
---
arglist [16520,17014]
arglist [16520,17014]
===
match
---
name: self [13315,13319]
name: self [13315,13319]
===
match
---
suite [52902,53933]
suite [53326,54357]
===
match
---
operator: , [1258,1259]
operator: , [1258,1259]
===
match
---
operator: = [64589,64590]
operator: = [65013,65014]
===
match
---
funcdef [26825,27826]
funcdef [26825,27826]
===
match
---
trailer [11072,11106]
trailer [11072,11106]
===
match
---
if_stmt [53388,53419]
if_stmt [53812,53843]
===
match
---
trailer [23654,23663]
trailer [23654,23663]
===
match
---
atom_expr [9013,9025]
atom_expr [9013,9025]
===
match
---
name: provide_session [73610,73625]
name: provide_session [74034,74049]
===
match
---
operator: = [82091,82092]
operator: = [82515,82516]
===
match
---
trailer [59036,59048]
trailer [59460,59472]
===
match
---
name: t [78413,78414]
name: t [78837,78838]
===
match
---
string: 'test_mode' [64772,64783]
string: 'test_mode' [65196,65207]
===
match
---
name: commit [57542,57548]
name: commit [57966,57972]
===
match
---
simple_stmt [26066,26099]
simple_stmt [26066,26099]
===
match
---
name: primary_key [10898,10909]
name: primary_key [10898,10909]
===
match
---
simple_stmt [45692,45709]
simple_stmt [45692,45709]
===
match
---
atom_expr [49037,49088]
atom_expr [49037,49088]
===
match
---
name: session [76581,76588]
name: session [77005,77012]
===
match
---
atom_expr [67710,68313]
atom_expr [68134,68737]
===
match
---
name: vals_kv [76282,76289]
name: vals_kv [76706,76713]
===
match
---
simple_stmt [77502,77518]
simple_stmt [77926,77942]
===
match
---
simple_stmt [76478,76514]
simple_stmt [76902,76938]
===
match
---
trailer [7355,7366]
trailer [7355,7366]
===
match
---
testlist_comp [66734,66772]
testlist_comp [67158,67196]
===
match
---
trailer [22136,22177]
trailer [22136,22177]
===
match
---
operator: , [37751,37752]
operator: , [37751,37752]
===
match
---
string: """Run TaskInstance""" [52911,52933]
string: """Run TaskInstance""" [53335,53357]
===
match
---
name: value [14566,14571]
name: value [14566,14571]
===
match
---
trailer [49159,49360]
trailer [49159,49360]
===
match
---
name: deserialize_value [76129,76146]
name: deserialize_value [76553,76570]
===
match
---
string: """         Set TaskInstance state.          :param state: State to set for the TI         :type state: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [25860,26057]
string: """         Set TaskInstance state.          :param state: State to set for the TI         :type state: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [25860,26057]
===
match
---
if_stmt [20306,20368]
if_stmt [20306,20368]
===
match
---
parameters [51469,51522]
parameters [51469,51522]
===
match
---
tfpdef [30929,30945]
tfpdef [30929,30945]
===
match
---
trailer [77091,77097]
trailer [77515,77521]
===
match
---
name: _log_state [43253,43263]
name: _log_state [43253,43263]
===
match
---
name: task [67435,67439]
name: task [67859,67863]
===
match
---
simple_stmt [80530,80554]
simple_stmt [80954,80978]
===
match
---
name: Column [10798,10804]
name: Column [10798,10804]
===
match
---
name: try_number [70085,70095]
name: try_number [70509,70519]
===
match
---
name: dump [4591,4595]
name: dump [4591,4595]
===
match
---
name: verbose_aware_logger [33683,33703]
name: verbose_aware_logger [33683,33703]
===
match
---
operator: , [27603,27604]
operator: , [27603,27604]
===
match
---
name: integrate_macros_plugins [58466,58490]
name: integrate_macros_plugins [58890,58914]
===
match
---
name: pendulum [28862,28870]
name: pendulum [28862,28870]
===
match
---
simple_stmt [68362,68422]
simple_stmt [68786,68846]
===
match
---
trailer [35646,35661]
trailer [35646,35661]
===
match
---
trailer [52992,53379]
trailer [53416,53803]
===
match
---
simple_stmt [46282,46356]
simple_stmt [46282,46356]
===
match
---
name: self [72065,72069]
name: self [72489,72493]
===
match
---
name: state [47005,47010]
name: state [47005,47010]
===
match
---
atom [46027,46071]
atom [46027,46071]
===
match
---
name: ignore_ti_state [15425,15440]
name: ignore_ti_state [15425,15440]
===
match
---
trailer [45696,45700]
trailer [45696,45700]
===
match
---
name: AirflowSmartSensorException [1793,1820]
name: AirflowSmartSensorException [1793,1820]
===
match
---
atom_expr [73207,73353]
atom_expr [73631,73777]
===
match
---
operator: = [75771,75772]
operator: = [76195,76196]
===
match
---
simple_stmt [60771,60821]
simple_stmt [61195,61245]
===
match
---
name: ignore_task_deps [52652,52668]
name: ignore_task_deps [53076,53092]
===
match
---
name: are_dependencies_met [32681,32701]
name: are_dependencies_met [32681,32701]
===
match
---
name: Exception [4622,4631]
name: Exception [4622,4631]
===
match
---
trailer [57409,57413]
trailer [57833,57837]
===
match
---
operator: = [31321,31322]
operator: = [31321,31322]
===
match
---
tfpdef [63214,63223]
tfpdef [63638,63647]
===
match
---
return_stmt [37299,37308]
return_stmt [37299,37308]
===
match
---
param [15167,15171]
param [15167,15171]
===
match
---
name: get [62846,62849]
name: get [63270,63273]
===
match
---
operator: , [1059,1060]
operator: , [1059,1060]
===
match
---
atom_expr [43545,43557]
atom_expr [43545,43557]
===
match
---
atom_expr [24764,24779]
atom_expr [24764,24779]
===
match
---
fstring_end: ' [56092,56093]
fstring_end: ' [56516,56517]
===
match
---
operator: = [43997,43998]
operator: = [43997,43998]
===
match
---
name: and_ [78291,78295]
name: and_ [78715,78719]
===
match
---
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [69395,69444]
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [69819,69868]
===
match
---
name: self [39277,39281]
name: self [39277,39281]
===
match
---
operator: = [27761,27762]
operator: = [27761,27762]
===
match
---
argument [28289,28304]
argument [28289,28304]
===
match
---
suite [3023,3200]
suite [3023,3200]
===
match
---
name: try_number [67893,67903]
name: try_number [68317,68327]
===
match
---
atom [59283,59319]
atom [59707,59743]
===
match
---
trailer [64523,64529]
trailer [64947,64953]
===
match
---
trailer [79644,79661]
trailer [80068,80085]
===
match
---
atom_expr [66533,66599]
atom_expr [66957,67023]
===
match
---
atom_expr [13192,13231]
atom_expr [13192,13231]
===
match
---
trailer [77648,77663]
trailer [78072,78087]
===
match
---
atom_expr [10968,10987]
atom_expr [10968,10987]
===
match
---
trailer [71283,71292]
trailer [71707,71716]
===
match
---
atom_expr [47000,47010]
atom_expr [47000,47010]
===
match
---
operator: , [78342,78343]
operator: , [78766,78767]
===
match
---
atom_expr [5705,5713]
atom_expr [5705,5713]
===
match
---
simple_stmt [2673,2716]
simple_stmt [2673,2716]
===
match
---
operator: , [29748,29749]
operator: , [29748,29749]
===
match
---
simple_stmt [9600,9700]
simple_stmt [9600,9700]
===
match
---
name: filter [27485,27491]
name: filter [27485,27491]
===
match
---
funcdef [30291,30811]
funcdef [30291,30811]
===
match
---
trailer [70209,70221]
trailer [70633,70645]
===
match
---
operator: = [73452,73453]
operator: = [73876,73877]
===
match
---
annassign [79574,79595]
annassign [79998,80019]
===
match
---
suite [81136,81867]
suite [81560,82291]
===
match
---
name: TaskInstance [27553,27565]
name: TaskInstance [27553,27565]
===
match
---
tfpdef [57671,57696]
tfpdef [58095,58120]
===
match
---
name: next_execution_date [60234,60253]
name: next_execution_date [60658,60677]
===
match
---
name: setter [14499,14505]
name: setter [14499,14505]
===
match
---
name: ignore_depends_on_past [17230,17252]
name: ignore_depends_on_past [17230,17252]
===
match
---
simple_stmt [46659,46666]
simple_stmt [46659,46666]
===
match
---
name: query [76185,76190]
name: query [76609,76614]
===
match
---
operator: , [4874,4875]
operator: , [4874,4875]
===
match
---
param [22311,22316]
param [22311,22316]
===
match
---
name: task_copy [50692,50701]
name: task_copy [50692,50701]
===
match
---
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [69175,69219]
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [69599,69643]
===
match
---
expr_stmt [3262,3286]
expr_stmt [3262,3286]
===
match
---
atom_expr [62419,62427]
atom_expr [62843,62851]
===
match
---
name: Stats [39530,39535]
name: Stats [39530,39535]
===
match
---
simple_stmt [11560,11611]
simple_stmt [11560,11611]
===
match
---
raise_stmt [66796,66884]
raise_stmt [67220,67308]
===
match
---
simple_stmt [37047,37113]
simple_stmt [37047,37113]
===
match
---
except_clause [46382,46410]
except_clause [46382,46410]
===
match
---
expr_stmt [11812,12133]
expr_stmt [11812,12133]
===
match
---
operator: , [21666,21667]
operator: , [21666,21667]
===
match
---
argument [53475,53486]
argument [53899,53910]
===
match
---
name: task_id [76115,76122]
name: task_id [76539,76546]
===
match
---
param [34074,34079]
param [34074,34079]
===
match
---
name: models [2006,2012]
name: models [2006,2012]
===
match
---
atom_expr [52808,52821]
atom_expr [53232,53245]
===
match
---
comp_op [52320,52326]
comp_op [52604,52610]
===
match
---
name: is_absolute [16365,16376]
name: is_absolute [16365,16376]
===
match
---
name: filter_for_tis [77125,77139]
name: filter_for_tis [77549,77563]
===
match
---
trailer [44889,44896]
trailer [44889,44896]
===
match
---
operator: = [21812,21813]
operator: = [21812,21813]
===
match
---
name: dag_id [77596,77602]
name: dag_id [78020,78026]
===
match
---
name: execution_date [73145,73159]
name: execution_date [73569,73583]
===
match
---
name: self [47898,47902]
name: self [47898,47902]
===
match
---
name: task_reschedule [40943,40958]
name: task_reschedule [40943,40958]
===
match
---
name: isoformat [20504,20513]
name: isoformat [20504,20513]
===
match
---
name: airflow [1998,2005]
name: airflow [1998,2005]
===
match
---
operator: { [60845,60846]
operator: { [61269,61270]
===
match
---
trailer [41980,41990]
trailer [41980,41990]
===
match
---
name: test_mode [42593,42602]
name: test_mode [42593,42602]
===
match
---
name: dag_run [82083,82090]
name: dag_run [82507,82514]
===
match
---
name: models [2153,2159]
name: models [2153,2159]
===
match
---
name: execution_date [59153,59167]
name: execution_date [59577,59591]
===
match
---
operator: = [67789,67790]
operator: = [68213,68214]
===
match
---
trailer [60224,60233]
trailer [60648,60657]
===
match
---
operator: = [39357,39358]
operator: = [39357,39358]
===
match
---
arglist [32357,32575]
arglist [32357,32575]
===
match
---
operator: } [20946,20947]
operator: } [20946,20947]
===
match
---
name: commit [25504,25510]
name: commit [25504,25510]
===
match
---
name: subject [71330,71337]
name: subject [71754,71761]
===
match
---
return_stmt [4302,4327]
return_stmt [4302,4327]
===
match
---
trailer [47278,47280]
trailer [47278,47280]
===
match
---
string: '%sMarking task as %s.' [43326,43349]
string: '%sMarking task as %s.' [43326,43349]
===
match
---
argument [66583,66598]
argument [67007,67022]
===
match
---
operator: -> [4077,4079]
operator: -> [4077,4079]
===
match
---
comparison [7254,7289]
comparison [7254,7289]
===
match
---
operator: , [53731,53732]
operator: , [54155,54156]
===
match
---
string: """Send alert email with exception information.""" [71657,71707]
string: """Send alert email with exception information.""" [72081,72131]
===
match
---
fstring_string: __ [60858,60860]
fstring_string: __ [61282,61284]
===
match
---
trailer [41691,41699]
trailer [41691,41699]
===
match
---
fstring_start: f" [20922,20924]
fstring_start: f" [20922,20924]
===
match
---
name: self [44953,44957]
name: self [44953,44957]
===
match
---
trailer [12965,12970]
trailer [12965,12970]
===
match
---
atom_expr [71340,71383]
atom_expr [71764,71807]
===
match
---
name: execution_date [23029,23043]
name: execution_date [23029,23043]
===
match
---
atom_expr [13241,13260]
atom_expr [13241,13260]
===
match
---
trailer [16575,16590]
trailer [16575,16590]
===
match
---
lambdef [64390,64451]
lambdef [64814,64875]
===
match
---
arglist [68733,68745]
arglist [69157,69169]
===
match
---
atom_expr [80287,80307]
atom_expr [80711,80731]
===
match
---
simple_stmt [58219,58282]
simple_stmt [58643,58706]
===
match
---
trailer [26739,26745]
trailer [26739,26745]
===
match
---
name: str [3277,3280]
name: str [3277,3280]
===
match
---
atom_expr [71411,71464]
atom_expr [71835,71888]
===
match
---
arglist [11945,11962]
arglist [11945,11962]
===
match
---
param [63399,63424]
param [63823,63848]
===
match
---
simple_stmt [73377,73604]
simple_stmt [73801,74028]
===
match
---
atom_expr [56189,56201]
atom_expr [56613,56625]
===
match
---
trailer [55070,55074]
trailer [55494,55498]
===
match
---
atom_expr [79807,79821]
atom_expr [80231,80245]
===
match
---
operator: @ [14577,14578]
operator: @ [14577,14578]
===
match
---
arglist [47793,47823]
arglist [47793,47823]
===
match
---
expr_stmt [11111,11138]
expr_stmt [11111,11138]
===
match
---
simple_stmt [26402,26468]
simple_stmt [26402,26468]
===
match
---
trailer [7924,7928]
trailer [7924,7928]
===
match
---
trailer [45256,45297]
trailer [45256,45297]
===
match
---
name: __init__ [12338,12346]
name: __init__ [12338,12346]
===
match
---
string: 'run_as_user' [79759,79772]
string: 'run_as_user' [80183,80196]
===
match
---
simple_stmt [40738,40774]
simple_stmt [40738,40774]
===
match
---
arglist [9868,9926]
arglist [9868,9926]
===
match
---
name: and_ [7224,7228]
name: and_ [7224,7228]
===
match
---
atom_expr [79963,79984]
atom_expr [80387,80408]
===
match
---
name: ignore_task_deps [40156,40172]
name: ignore_task_deps [40156,40172]
===
match
---
import_from [1909,1957]
import_from [1909,1957]
===
match
---
import_name [820,834]
import_name [820,834]
===
match
---
name: self [79401,79405]
name: self [79825,79829]
===
match
---
trailer [70252,70269]
trailer [70676,70693]
===
match
---
tfpdef [73667,73712]
tfpdef [74091,74136]
===
match
---
trailer [42138,42144]
trailer [42138,42144]
===
match
---
name: state [39494,39499]
name: state [39494,39499]
===
match
---
operator: = [54097,54098]
operator: = [54521,54522]
===
match
---
operator: = [51515,51516]
operator: = [51515,51516]
===
match
---
suite [33907,33933]
suite [33907,33933]
===
match
---
name: executor_config [79672,79687]
name: executor_config [80096,80111]
===
match
---
decorated [52485,53933]
decorated [52909,54357]
===
match
---
name: state [51724,51729]
name: state [51724,51729]
===
match
---
atom_expr [79669,79687]
atom_expr [80093,80111]
===
match
---
return_stmt [20376,20386]
return_stmt [20376,20386]
===
match
---
name: render [71293,71299]
name: render [71717,71723]
===
match
---
name: provide_session [43718,43733]
name: provide_session [43718,43733]
===
match
---
suite [35100,36526]
suite [35100,36526]
===
match
---
name: ti [27432,27434]
name: ti [27432,27434]
===
match
---
name: self [76575,76579]
name: self [76999,77003]
===
match
---
trailer [47918,47920]
trailer [47918,47920]
===
match
---
simple_stmt [79361,79393]
simple_stmt [79785,79817]
===
match
---
parameters [61639,61645]
parameters [62063,62069]
===
match
---
name: error [55553,55558]
name: error [55977,55982]
===
match
---
trailer [45725,45741]
trailer [45725,45741]
===
match
---
name: unixname [11179,11187]
name: unixname [11179,11187]
===
match
---
simple_stmt [16287,16315]
simple_stmt [16287,16315]
===
match
---
atom_expr [10726,10784]
atom_expr [10726,10784]
===
match
---
simple_stmt [58466,58493]
simple_stmt [58890,58917]
===
match
---
suite [52252,52480]
suite [52536,52904]
===
match
---
name: get_previous_execution_date [64403,64430]
name: get_previous_execution_date [64827,64854]
===
match
---
name: job [7958,7961]
name: job [7958,7961]
===
match
---
operator: = [60214,60215]
operator: = [60638,60639]
===
match
---
trailer [16549,16557]
trailer [16549,16557]
===
match
---
if_stmt [5471,6551]
if_stmt [5471,6551]
===
match
---
name: error_file [55879,55889]
name: error_file [56303,56313]
===
match
---
trailer [68348,68353]
trailer [68772,68777]
===
match
---
name: result [50683,50689]
name: result [50683,50689]
===
match
---
atom_expr [78880,78899]
atom_expr [79304,79323]
===
match
---
operator: = [46326,46327]
operator: = [46326,46327]
===
match
---
atom_expr [9420,9439]
atom_expr [9420,9439]
===
match
---
operator: ** [11661,11663]
operator: ** [11661,11663]
===
match
---
argument [58885,58919]
argument [59309,59343]
===
match
---
name: result [49786,49792]
name: result [49786,49792]
===
match
---
for_stmt [7873,7987]
for_stmt [7873,7987]
===
match
---
name: items [65698,65703]
name: items [66122,66127]
===
match
---
name: cmd [20383,20386]
name: cmd [20383,20386]
===
match
---
name: dag_id [67842,67848]
name: dag_id [68266,68272]
===
match
---
expr_stmt [23375,23396]
expr_stmt [23375,23396]
===
match
---
return_stmt [14422,14445]
return_stmt [14422,14445]
===
match
---
operator: = [21181,21182]
operator: = [21181,21182]
===
match
---
name: getboolean [60970,60980]
name: getboolean [61394,61404]
===
match
---
operator: , [30742,30743]
operator: , [30742,30743]
===
match
---
trailer [45705,45708]
trailer [45705,45708]
===
match
---
arglist [25343,25468]
arglist [25343,25468]
===
match
---
name: hr_line_break [42047,42060]
name: hr_line_break [42047,42060]
===
match
---
operator: , [43531,43532]
operator: , [43531,43532]
===
match
---
operator: = [15461,15462]
operator: = [15461,15462]
===
match
---
expr_stmt [44914,44944]
expr_stmt [44914,44944]
===
match
---
name: next_ds [63994,64001]
name: next_ds [64418,64425]
===
match
---
name: params [60945,60951]
name: params [61369,61375]
===
match
---
trailer [64583,64604]
trailer [65007,65028]
===
match
---
simple_stmt [78866,79018]
simple_stmt [79290,79442]
===
match
---
atom_expr [27648,27667]
atom_expr [27648,27667]
===
match
---
operator: = [43896,43897]
operator: = [43896,43897]
===
match
---
atom_expr [27720,27733]
atom_expr [27720,27733]
===
match
---
with_stmt [49587,49686]
with_stmt [49587,49686]
===
match
---
trailer [58230,58235]
trailer [58654,58659]
===
match
---
name: self [26178,26182]
name: self [26178,26182]
===
match
---
string: 'value' [65114,65121]
string: 'value' [65538,65545]
===
match
---
name: _key [80935,80939]
name: _key [81359,81363]
===
match
---
decorator [81028,81045]
decorator [81452,81469]
===
match
---
trailer [52363,52384]
trailer [52647,52668]
===
match
---
trailer [71417,71464]
trailer [71841,71888]
===
match
---
trailer [73457,73465]
trailer [73881,73889]
===
match
---
if_stmt [77527,77563]
if_stmt [77951,77987]
===
match
---
name: task [64128,64132]
name: task [64552,64556]
===
match
---
if_stmt [19617,19684]
if_stmt [19617,19684]
===
match
---
operator: , [56296,56297]
operator: , [56720,56721]
===
match
---
name: str [43891,43894]
name: str [43891,43894]
===
match
---
atom_expr [56077,56091]
atom_expr [56501,56515]
===
match
---
tfpdef [4062,4075]
tfpdef [4062,4075]
===
match
---
trailer [4205,4210]
trailer [4205,4210]
===
match
---
name: get_num_running_task_instances [76544,76574]
name: get_num_running_task_instances [76968,76998]
===
match
---
trailer [13319,13328]
trailer [13319,13328]
===
match
---
operator: = [68136,68137]
operator: = [68560,68561]
===
match
---
name: dag_id [19519,19525]
name: dag_id [19519,19525]
===
match
---
param [61403,61407]
param [61827,61831]
===
match
---
name: pool_override [24711,24724]
name: pool_override [24711,24724]
===
match
---
operator: = [67391,67392]
operator: = [67815,67816]
===
match
---
atom_expr [68378,68421]
atom_expr [68802,68845]
===
match
---
atom_expr [6560,6635]
atom_expr [6560,6635]
===
match
---
atom_expr [54507,54789]
atom_expr [54931,55213]
===
match
---
trailer [42354,42364]
trailer [42354,42364]
===
match
---
operator: , [60452,60453]
operator: , [60876,60877]
===
match
---
trailer [42257,42261]
trailer [42257,42261]
===
match
---
comparison [75531,75545]
comparison [75955,75969]
===
match
---
trailer [59319,59328]
trailer [59743,59752]
===
match
---
expr_stmt [60287,60308]
expr_stmt [60711,60732]
===
match
---
name: utils [2989,2994]
name: utils [2989,2994]
===
match
---
name: load_error_file [4046,4061]
name: load_error_file [4046,4061]
===
match
---
name: pool [11244,11248]
name: pool [11244,11248]
===
match
---
name: are_dependencies_met [40212,40232]
name: are_dependencies_met [40212,40232]
===
match
---
operator: = [3320,3321]
operator: = [3320,3321]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [30358,30497]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [30358,30497]
===
match
---
name: init_run_context [76972,76988]
name: init_run_context [77396,77412]
===
match
---
trailer [60611,60620]
trailer [61035,61044]
===
match
---
atom_expr [23881,23901]
atom_expr [23881,23901]
===
match
---
trailer [46633,46640]
trailer [46633,46640]
===
match
---
name: log [42992,42995]
name: log [42992,42995]
===
match
---
trailer [5903,5912]
trailer [5903,5912]
===
match
---
name: dr [29503,29505]
name: dr [29503,29505]
===
match
---
name: str [43111,43114]
name: str [43111,43114]
===
match
---
atom_expr [70131,70145]
atom_expr [70555,70569]
===
match
---
tfpdef [37557,37578]
tfpdef [37557,37578]
===
match
---
operator: == [7367,7369]
operator: == [7367,7369]
===
match
---
name: delay_backoff_in_seconds [36279,36303]
name: delay_backoff_in_seconds [36279,36303]
===
match
---
name: get_previous_start_date [64560,64583]
name: get_previous_start_date [64984,65007]
===
match
---
name: task_reschedule [40998,41013]
name: task_reschedule [40998,41013]
===
match
---
name: refresh_from_task [39190,39207]
name: refresh_from_task [39190,39207]
===
match
---
atom_expr [58900,58919]
atom_expr [59324,59343]
===
match
---
parameters [53949,53955]
parameters [54373,54379]
===
match
---
decorated [62587,62904]
decorated [63011,63328]
===
match
---
trailer [70461,70483]
trailer [70885,70907]
===
match
---
return_stmt [28829,28840]
return_stmt [28829,28840]
===
match
---
name: task [12499,12503]
name: task [12499,12503]
===
match
---
atom_expr [3784,3806]
atom_expr [3784,3806]
===
match
---
name: prev_execution_date [59704,59723]
name: prev_execution_date [60128,60147]
===
match
---
operator: , [72255,72256]
operator: , [72679,72680]
===
match
---
trailer [51948,51968]
trailer [51973,51993]
===
match
---
name: session [59063,59070]
name: session [59487,59494]
===
match
---
expr_stmt [79640,79687]
expr_stmt [80064,80111]
===
match
---
import_from [1118,1148]
import_from [1118,1148]
===
match
---
tfpdef [12359,12383]
tfpdef [12359,12383]
===
match
---
name: execution_date [78078,78092]
name: execution_date [78502,78516]
===
match
---
atom_expr [43488,43506]
atom_expr [43488,43506]
===
match
---
name: t [78230,78231]
name: t [78654,78655]
===
match
---
argument [33601,33624]
argument [33601,33624]
===
match
---
atom_expr [7123,7698]
atom_expr [7123,7698]
===
match
---
expr_stmt [28857,28900]
expr_stmt [28857,28900]
===
match
---
arglist [56056,56099]
arglist [56480,56523]
===
match
---
simple_stmt [79558,79596]
simple_stmt [79982,80020]
===
match
---
atom_expr [42875,42952]
atom_expr [42875,42952]
===
match
---
simple_stmt [72472,73093]
simple_stmt [72896,73517]
===
match
---
argument [44860,44875]
argument [44860,44875]
===
match
---
trailer [35734,35744]
trailer [35734,35744]
===
match
---
name: Log [47200,47203]
name: Log [47200,47203]
===
match
---
operator: @ [21129,21130]
operator: @ [21129,21130]
===
match
---
operator: , [65648,65649]
operator: , [66072,66073]
===
match
---
trailer [81840,81846]
trailer [82264,82270]
===
match
---
trailer [8538,8555]
trailer [8538,8555]
===
match
---
name: func [27451,27455]
name: func [27451,27455]
===
match
---
operator: = [60590,60591]
operator: = [61014,61015]
===
match
---
trailer [5991,5999]
trailer [5991,5999]
===
match
---
name: start_date [8963,8973]
name: start_date [8963,8973]
===
match
---
operator: , [1318,1319]
operator: , [1318,1319]
===
match
---
comparison [36737,36769]
comparison [36737,36769]
===
match
---
simple_stmt [58784,58960]
simple_stmt [59208,59384]
===
match
---
expr_stmt [10861,10915]
expr_stmt [10861,10915]
===
match
---
name: staticmethod [77104,77116]
name: staticmethod [77528,77540]
===
match
---
name: cmd [19643,19646]
name: cmd [19643,19646]
===
match
---
not_test [56146,56159]
not_test [56570,56583]
===
match
---
simple_stmt [57188,57259]
simple_stmt [57612,57683]
===
match
---
suite [9982,10086]
suite [9982,10086]
===
match
---
trailer [41943,41954]
trailer [41943,41954]
===
match
---
name: task_id_by_key [5368,5382]
name: task_id_by_key [5368,5382]
===
match
---
operator: = [17213,17214]
operator: = [17213,17214]
===
match
---
operator: = [55268,55269]
operator: = [55692,55693]
===
match
---
name: self [30878,30882]
name: self [30878,30882]
===
match
---
name: str [30908,30911]
name: str [30908,30911]
===
match
---
expr_stmt [11143,11174]
expr_stmt [11143,11174]
===
match
---
name: Literal [2483,2490]
name: Literal [2483,2490]
===
match
---
name: self [59726,59730]
name: self [60150,60154]
===
match
---
not_test [39441,39460]
not_test [39441,39460]
===
match
---
atom_expr [82147,82168]
atom_expr [82571,82592]
===
match
---
trailer [6472,6477]
trailer [6472,6477]
===
match
---
return_stmt [58219,58281]
return_stmt [58643,58705]
===
match
---
simple_stmt [77626,77664]
simple_stmt [78050,78088]
===
match
---
trailer [36501,36517]
trailer [36501,36517]
===
match
---
suite [81973,82169]
suite [82397,82593]
===
match
---
suite [80360,80393]
suite [80784,80817]
===
match
---
suite [53956,54170]
suite [54380,54594]
===
match
---
name: key [78977,78980]
name: key [79401,79404]
===
match
---
operator: = [57868,57869]
operator: = [58292,58293]
===
match
---
expr_stmt [52942,53379]
expr_stmt [53366,53803]
===
match
---
name: self [68085,68089]
name: self [68509,68513]
===
match
---
fstring_expr [34754,34775]
fstring_expr [34754,34775]
===
match
---
and_test [58226,58281]
and_test [58650,58705]
===
match
---
operator: = [28962,28963]
operator: = [28962,28963]
===
match
---
operator: , [61492,61493]
operator: , [61916,61917]
===
match
---
simple_stmt [11111,11139]
simple_stmt [11111,11139]
===
match
---
suite [50570,50824]
suite [50570,50824]
===
match
---
decorated [22270,24316]
decorated [22270,24316]
===
match
---
trailer [80934,80939]
trailer [81358,81363]
===
match
---
name: duration [72099,72107]
name: duration [72523,72531]
===
match
---
operator: = [17409,17410]
operator: = [17409,17410]
===
match
---
trailer [76146,76154]
trailer [76570,76578]
===
match
---
name: on_retry_callback [52453,52470]
name: on_retry_callback [52762,52779]
===
match
---
param [17078,17090]
param [17078,17090]
===
match
---
suite [77226,79018]
suite [77650,79442]
===
match
---
name: ignore_all_deps [39445,39460]
name: ignore_all_deps [39445,39460]
===
match
---
trailer [19474,19476]
trailer [19474,19476]
===
match
---
name: str [80181,80184]
name: str [80605,80608]
===
match
---
operator: = [11327,11328]
operator: = [11327,11328]
===
match
---
simple_stmt [13837,13897]
simple_stmt [13837,13897]
===
match
---
simple_stmt [45917,45993]
simple_stmt [45917,45993]
===
match
---
name: dep_status [34657,34667]
name: dep_status [34657,34667]
===
match
---
operator: } [20666,20667]
operator: } [20666,20667]
===
match
---
trailer [48020,48037]
trailer [48020,48037]
===
match
---
expr_stmt [13689,13711]
expr_stmt [13689,13711]
===
match
---
simple_stmt [12450,12476]
simple_stmt [12450,12476]
===
match
---
name: _log_state [57193,57203]
name: _log_state [57617,57627]
===
match
---
trailer [55921,55940]
trailer [56345,56364]
===
match
---
name: Tuple [1105,1110]
name: Tuple [1105,1110]
===
match
---
name: dag_id [77916,77922]
name: dag_id [78340,78346]
===
match
---
name: value [72353,72358]
name: value [72777,72782]
===
match
---
name: models [8385,8391]
name: models [8385,8391]
===
match
---
operator: -> [30960,30962]
operator: -> [30960,30962]
===
match
---
operator: , [1054,1055]
operator: , [1054,1055]
===
match
---
name: BaseJob [7914,7921]
name: BaseJob [7914,7921]
===
match
---
operator: = [50102,50103]
operator: = [50102,50103]
===
match
---
operator: , [52596,52597]
operator: , [53020,53021]
===
match
---
name: tis [77140,77143]
name: tis [77564,77567]
===
match
---
decorator [80867,80877]
decorator [81291,81301]
===
match
---
name: _try_number [15232,15243]
name: _try_number [15232,15243]
===
match
---
atom_expr [70539,70610]
atom_expr [70963,71034]
===
match
---
fstring_string: .duration [47990,47999]
fstring_string: .duration [47990,47999]
===
match
---
name: ti [6547,6549]
name: ti [6547,6549]
===
match
---
simple_stmt [44953,44976]
simple_stmt [44953,44976]
===
match
---
name: task_id [12489,12496]
name: task_id [12489,12496]
===
match
---
name: self [45721,45725]
name: self [45721,45725]
===
match
---
name: AirflowFailException [46028,46048]
name: AirflowFailException [46028,46048]
===
match
---
name: previous_ti_success [30295,30314]
name: previous_ti_success [30295,30314]
===
match
---
trailer [57413,57423]
trailer [57837,57847]
===
match
---
operator: = [9244,9245]
operator: = [9244,9245]
===
match
---
name: utcnow [26090,26096]
name: utcnow [26090,26096]
===
match
---
name: refresh_from_db [45887,45902]
name: refresh_from_db [45887,45902]
===
match
---
name: params [58502,58508]
name: params [58926,58932]
===
match
---
simple_stmt [21806,21826]
simple_stmt [21806,21826]
===
match
---
name: self [15111,15115]
name: self [15111,15115]
===
match
---
atom_expr [50086,50101]
atom_expr [50086,50101]
===
match
---
trailer [77512,77517]
trailer [77936,77941]
===
match
---
operator: = [15998,15999]
operator: = [15998,15999]
===
match
---
name: job_id [11215,11221]
name: job_id [11215,11221]
===
match
---
atom_expr [44914,44927]
atom_expr [44914,44927]
===
match
---
atom_expr [8673,8844]
atom_expr [8673,8844]
===
match
---
fstring_start: f" [60843,60845]
fstring_start: f" [61267,61269]
===
match
---
trailer [23120,23122]
trailer [23120,23122]
===
match
---
name: get_template_env [70996,71012]
name: get_template_env [71420,71436]
===
match
---
name: pop [3801,3804]
name: pop [3801,3804]
===
match
---
name: get_previous_execution_date [30841,30868]
name: get_previous_execution_date [30841,30868]
===
match
---
name: self [44885,44889]
name: self [44885,44889]
===
match
---
name: priority_weight [24793,24808]
name: priority_weight [24793,24808]
===
match
---
atom_expr [45882,45904]
atom_expr [45882,45904]
===
match
---
operator: = [53050,53051]
operator: = [53474,53475]
===
match
---
funcdef [77121,79018]
funcdef [77545,79442]
===
match
---
simple_stmt [50782,50802]
simple_stmt [50782,50802]
===
match
---
name: items [7475,7480]
name: items [7475,7480]
===
match
---
name: self [51134,51138]
name: self [51134,51138]
===
match
---
name: pool_slots [24769,24779]
name: pool_slots [24769,24779]
===
match
---
name: start_date [72132,72142]
name: start_date [72556,72566]
===
match
---
name: get_rendered_template_fields [65317,65345]
name: get_rendered_template_fields [65741,65769]
===
match
---
name: _log_state [47109,47119]
name: _log_state [47109,47119]
===
match
---
expr_stmt [7110,7698]
expr_stmt [7110,7698]
===
match
---
trailer [21642,21650]
trailer [21642,21650]
===
match
---
name: property [80147,80155]
name: property [80571,80579]
===
match
---
atom_expr [43571,43608]
atom_expr [43571,43608]
===
match
---
name: handle_failure_with_callback [57581,57609]
name: handle_failure_with_callback [58005,58033]
===
match
---
atom_expr [27894,27907]
atom_expr [27894,27907]
===
match
---
atom_expr [34755,34774]
atom_expr [34755,34774]
===
match
---
trailer [10811,10837]
trailer [10811,10837]
===
match
---
operator: , [43557,43558]
operator: , [43557,43558]
===
match
---
name: commit [47272,47278]
name: commit [47272,47278]
===
match
---
import_name [1162,1175]
import_name [1162,1175]
===
match
---
name: Session [30938,30945]
name: Session [30938,30945]
===
match
---
return_stmt [40385,40397]
return_stmt [40385,40397]
===
match
---
suite [3758,4040]
suite [3758,4040]
===
match
---
tfpdef [43912,43931]
tfpdef [43912,43931]
===
match
---
name: task [56077,56081]
name: task [56501,56505]
===
match
---
operator: , [37507,37508]
operator: , [37507,37508]
===
match
---
operator: = [60731,60732]
operator: = [61155,61156]
===
match
---
trailer [78574,78839]
trailer [78998,79263]
===
match
---
operator: = [71409,71410]
operator: = [71833,71834]
===
match
---
name: self [49507,49511]
name: self [49507,49511]
===
match
---
name: COLLATION_ARGS [11663,11677]
name: COLLATION_ARGS [11663,11677]
===
match
---
simple_stmt [12139,12329]
simple_stmt [12139,12329]
===
match
---
name: self [64785,64789]
name: self [65209,65213]
===
match
---
atom_expr [79323,79335]
atom_expr [79747,79759]
===
match
---
trailer [78030,78037]
trailer [78454,78461]
===
match
---
if_stmt [20010,20066]
if_stmt [20010,20066]
===
match
---
atom_expr [6467,6477]
atom_expr [6467,6477]
===
match
---
name: priority_weight [80715,80730]
name: priority_weight [81139,81154]
===
match
---
trailer [70679,70681]
trailer [71103,71105]
===
match
---
argument [61941,61964]
argument [62365,62388]
===
match
---
name: self [54087,54091]
name: self [54511,54515]
===
match
---
name: clear_xcom_data [47903,47918]
name: clear_xcom_data [47903,47918]
===
match
---
decorated [73609,76514]
decorated [74033,76938]
===
match
---
name: Sentry [43739,43745]
name: Sentry [43739,43745]
===
match
---
operator: , [55631,55632]
operator: , [56055,56056]
===
match
---
name: items [48565,48570]
name: items [48565,48570]
===
match
---
operator: = [10876,10877]
operator: = [10876,10877]
===
match
---
name: timezone [12732,12740]
name: timezone [12732,12740]
===
match
---
name: self [23881,23885]
name: self [23881,23885]
===
match
---
name: replace [60669,60676]
name: replace [61093,61100]
===
match
---
expr_stmt [26066,26098]
expr_stmt [26066,26098]
===
match
---
name: replace [68787,68794]
name: replace [69211,69218]
===
match
---
simple_stmt [11495,11530]
simple_stmt [11495,11530]
===
match
---
string: 'core' [60981,60987]
string: 'core' [61405,61411]
===
match
---
trailer [40232,40334]
trailer [40232,40334]
===
match
---
name: try_number [41944,41954]
name: try_number [41944,41954]
===
match
---
parameters [15272,15580]
parameters [15272,15580]
===
match
---
import_as_names [2418,2448]
import_as_names [2418,2448]
===
match
---
name: retry_delay [35041,35052]
name: retry_delay [35041,35052]
===
match
---
name: open [4529,4533]
name: open [4529,4533]
===
match
---
name: hasattr [58592,58599]
name: hasattr [59016,59023]
===
match
---
comparison [26735,26767]
comparison [26735,26767]
===
match
---
comparison [78065,78110]
comparison [78489,78534]
===
match
---
trailer [79671,79687]
trailer [80095,80111]
===
match
---
name: log_url [20410,20417]
name: log_url [20410,20417]
===
match
---
operator: = [20823,20824]
operator: = [20823,20824]
===
match
---
simple_stmt [1162,1176]
simple_stmt [1162,1176]
===
match
---
simple_stmt [28829,28841]
simple_stmt [28829,28841]
===
match
---
atom_expr [57405,57466]
atom_expr [57829,57890]
===
match
---
simple_stmt [72014,72036]
simple_stmt [72438,72460]
===
match
---
trailer [7913,7938]
trailer [7913,7938]
===
match
---
suite [28387,29050]
suite [28387,29050]
===
match
---
simple_stmt [11812,12134]
simple_stmt [11812,12134]
===
match
---
name: dialect [78527,78534]
name: dialect [78951,78958]
===
match
---
operator: , [41409,41410]
operator: , [41409,41410]
===
match
---
simple_stmt [59758,59800]
simple_stmt [60182,60224]
===
match
---
operator: , [64939,64940]
operator: , [65363,65364]
===
match
---
name: test_mode [13842,13851]
name: test_mode [13842,13851]
===
match
---
operator: = [13190,13191]
operator: = [13190,13191]
===
match
---
name: self [66962,66966]
name: self [67386,67390]
===
match
---
atom [20160,20176]
atom [20160,20176]
===
match
---
name: self [12961,12965]
name: self [12961,12965]
===
match
---
if_stmt [45665,45709]
if_stmt [45665,45709]
===
match
---
import_from [1958,1992]
import_from [1958,1992]
===
match
---
comparison [22943,22979]
comparison [22943,22979]
===
match
---
trailer [9885,9893]
trailer [9885,9893]
===
match
---
trailer [64789,64799]
trailer [65213,65223]
===
match
---
name: construct_task_instance [81053,81076]
name: construct_task_instance [81477,81500]
===
match
---
parameters [71990,71996]
parameters [72414,72420]
===
match
---
simple_stmt [9199,9224]
simple_stmt [9199,9224]
===
match
---
comp_op [51006,51012]
comp_op [51006,51012]
===
match
---
name: dag_id [76802,76808]
name: dag_id [77226,77232]
===
match
---
name: instance [60225,60233]
name: instance [60649,60657]
===
match
---
operator: , [55194,55195]
operator: , [55618,55619]
===
match
---
name: dep_name [34482,34490]
name: dep_name [34482,34490]
===
match
---
atom_expr [16520,16531]
atom_expr [16520,16531]
===
match
---
trailer [44733,44738]
trailer [44733,44738]
===
match
---
name: Any [1056,1059]
name: Any [1056,1059]
===
match
---
operator: + [35879,35880]
operator: + [35879,35880]
===
match
---
trailer [51859,51880]
trailer [51859,51880]
===
match
---
param [15560,15574]
param [15560,15574]
===
match
---
name: path [16214,16218]
name: path [16214,16218]
===
match
---
name: ts [64937,64939]
name: ts [65361,65363]
===
match
---
trailer [60944,60951]
trailer [61368,61375]
===
match
---
name: task_id [80164,80171]
name: task_id [80588,80595]
===
match
---
argument [41364,41409]
argument [41364,41409]
===
match
---
name: execution_date [25746,25760]
name: execution_date [25746,25760]
===
match
---
name: execution_date [13216,13230]
name: execution_date [13216,13230]
===
match
---
trailer [67462,67471]
trailer [67886,67895]
===
match
---
simple_stmt [8923,8948]
simple_stmt [8923,8948]
===
match
---
trailer [10974,10987]
trailer [10974,10987]
===
match
---
atom_expr [79401,79421]
atom_expr [79825,79845]
===
match
---
atom_expr [54591,54610]
atom_expr [55015,55034]
===
match
---
trailer [70395,70412]
trailer [70819,70836]
===
match
---
name: dag_id [12455,12461]
name: dag_id [12455,12461]
===
match
---
name: dag_id [81580,81586]
name: dag_id [82004,82010]
===
match
---
name: info [55075,55079]
name: info [55499,55503]
===
match
---
operator: = [53201,53202]
operator: = [53625,53626]
===
match
---
trailer [73548,73563]
trailer [73972,73987]
===
match
---
name: airflow [2260,2267]
name: airflow [2260,2267]
===
match
---
return_stmt [15220,15247]
return_stmt [15220,15247]
===
match
---
name: _dag_id [81595,81602]
name: _dag_id [82019,82026]
===
match
---
expr_stmt [16070,16114]
expr_stmt [16070,16114]
===
match
---
operator: , [26853,26854]
operator: , [26853,26854]
===
match
---
operator: , [43032,43033]
operator: , [43032,43033]
===
match
---
funcdef [80573,80624]
funcdef [80997,81048]
===
match
---
atom_expr [16183,16196]
atom_expr [16183,16196]
===
match
---
name: pool [53647,53651]
name: pool [54071,54075]
===
match
---
expr_stmt [36370,36421]
expr_stmt [36370,36421]
===
match
---
expr_stmt [36279,36357]
expr_stmt [36279,36357]
===
match
---
name: raw [77062,77065]
name: raw [77486,77489]
===
match
---
trailer [5491,5499]
trailer [5491,5499]
===
match
---
dotted_name [2294,2307]
dotted_name [2294,2307]
===
match
---
trailer [47086,47093]
trailer [47086,47093]
===
match
---
name: self [54219,54223]
name: self [54643,54647]
===
match
---
simple_stmt [45468,45485]
simple_stmt [45468,45485]
===
match
---
name: AirflowRescheduleException [45818,45844]
name: AirflowRescheduleException [45818,45844]
===
match
---
atom_expr [76880,76898]
atom_expr [77304,77322]
===
match
---
operator: = [57108,57109]
operator: = [57532,57533]
===
match
---
import_from [2783,2825]
import_from [2783,2825]
===
match
---
operator: , [61833,61834]
operator: , [62257,62258]
===
match
---
argument [53330,53339]
argument [53754,53763]
===
match
---
name: last_dagrun [29670,29681]
name: last_dagrun [29670,29681]
===
match
---
suite [19863,19914]
suite [19863,19914]
===
match
---
operator: , [12001,12002]
operator: , [12001,12002]
===
match
---
name: on_retry_callback [52302,52319]
name: on_retry_callback [52586,52603]
===
match
---
atom_expr [27505,27524]
atom_expr [27505,27524]
===
match
---
parameters [25056,25076]
parameters [25056,25076]
===
match
---
name: value [76224,76229]
name: value [76648,76653]
===
match
---
atom_expr [51483,51514]
atom_expr [51483,51514]
===
match
---
trailer [35396,35410]
trailer [35396,35410]
===
match
---
atom_expr [23375,23385]
atom_expr [23375,23385]
===
match
---
trailer [23953,23962]
trailer [23953,23962]
===
match
---
name: super [12423,12428]
name: super [12423,12428]
===
match
---
trailer [4781,4797]
trailer [4781,4797]
===
match
---
return_stmt [81857,81866]
return_stmt [82281,82290]
===
match
---
trailer [6604,6619]
trailer [6604,6619]
===
match
---
name: context [51330,51337]
name: context [51330,51337]
===
match
---
simple_stmt [12582,12628]
simple_stmt [12582,12628]
===
match
---
name: NONE [41662,41666]
name: NONE [41662,41666]
===
match
---
trailer [55079,55135]
trailer [55503,55559]
===
match
---
trailer [4315,4321]
trailer [4315,4321]
===
match
---
operator: = [62682,62683]
operator: = [63106,63107]
===
match
---
expr_stmt [9043,9077]
expr_stmt [9043,9077]
===
match
---
operator: * [39679,39680]
operator: * [39679,39680]
===
match
---
expr_stmt [5801,5821]
expr_stmt [5801,5821]
===
match
---
name: cmd [19876,19879]
name: cmd [19876,19879]
===
match
---
name: Integer [11231,11238]
name: Integer [11231,11238]
===
match
---
operator: = [57826,57827]
operator: = [58250,58251]
===
match
---
name: session [47235,47242]
name: session [47235,47242]
===
match
---
trailer [41735,41739]
trailer [41735,41739]
===
match
---
name: test_mode [57827,57836]
name: test_mode [58251,58260]
===
match
---
name: Column [11401,11407]
name: Column [11401,11407]
===
match
---
fstring_end: " [20667,20668]
fstring_end: " [20667,20668]
===
match
---
trailer [11890,11929]
trailer [11890,11929]
===
match
---
comparison [52219,52251]
comparison [52503,52535]
===
match
---
import_from [58430,58456]
import_from [58854,58880]
===
match
---
name: self [56203,56207]
name: self [56627,56631]
===
match
---
simple_stmt [80605,80624]
simple_stmt [81029,81048]
===
match
---
operator: @ [43738,43739]
operator: @ [43738,43739]
===
match
---
arglist [20834,20857]
arglist [20834,20857]
===
match
---
operator: { [76090,76091]
operator: { [76514,76515]
===
match
---
trailer [7396,7406]
trailer [7396,7406]
===
match
---
name: task [24996,25000]
name: task [24996,25000]
===
match
---
name: local [16845,16850]
name: local [16845,16850]
===
match
---
name: Any [63413,63416]
name: Any [63837,63840]
===
match
---
name: bool [37411,37415]
name: bool [37411,37415]
===
match
---
operator: ** [10748,10750]
operator: ** [10748,10750]
===
match
---
atom_expr [62837,62903]
atom_expr [63261,63327]
===
match
---
fstring_string: = [48526,48527]
fstring_string: = [48526,48527]
===
match
---
trailer [42658,42660]
trailer [42658,42660]
===
match
---
trailer [27957,27973]
trailer [27957,27973]
===
match
---
trailer [11645,11679]
trailer [11645,11679]
===
match
---
trailer [24684,24690]
trailer [24684,24690]
===
match
---
atom_expr [33855,33872]
atom_expr [33855,33872]
===
match
---
operator: = [16091,16092]
operator: = [16091,16092]
===
match
---
atom_expr [11366,11377]
atom_expr [11366,11377]
===
match
---
name: str [9174,9177]
name: str [9174,9177]
===
match
---
name: self [43023,43027]
name: self [43023,43027]
===
match
---
name: self [13287,13291]
name: self [13287,13291]
===
match
---
trailer [23668,23677]
trailer [23668,23677]
===
match
---
simple_stmt [13768,13829]
simple_stmt [13768,13829]
===
match
---
name: dagrun [82044,82050]
name: dagrun [82468,82474]
===
match
---
atom_expr [32016,32034]
atom_expr [32016,32034]
===
match
---
operator: , [64001,64002]
operator: , [64425,64426]
===
match
---
name: execution_date [58885,58899]
name: execution_date [59309,59323]
===
match
---
atom_expr [53892,53932]
atom_expr [54316,54356]
===
match
---
operator: , [2434,2435]
operator: , [2434,2435]
===
match
---
atom_expr [63263,63307]
atom_expr [63687,63731]
===
match
---
argument [7224,7599]
argument [7224,7599]
===
match
---
name: contextlib [3431,3441]
name: contextlib [3431,3441]
===
match
---
operator: } [45132,45133]
operator: } [45132,45133]
===
match
---
atom_expr [31295,31345]
atom_expr [31295,31345]
===
match
---
name: self [36774,36778]
name: self [36774,36778]
===
match
---
name: are_dependents_done [26829,26848]
name: are_dependents_done [26829,26848]
===
match
---
name: self [14547,14551]
name: self [14547,14551]
===
match
---
expr_stmt [5884,5912]
expr_stmt [5884,5912]
===
match
---
expr_stmt [54403,54436]
expr_stmt [54827,54860]
===
match
---
simple_stmt [37776,39152]
simple_stmt [37776,39152]
===
match
---
name: error_fd [53863,53871]
name: error_fd [54287,54295]
===
match
---
name: dag_id [22908,22914]
name: dag_id [22908,22914]
===
match
---
trailer [11167,11173]
trailer [11167,11173]
===
match
---
name: strftime [59240,59248]
name: strftime [59664,59672]
===
match
---
tfpdef [52767,52782]
tfpdef [53191,53206]
===
match
---
name: signal [47779,47785]
name: signal [47779,47785]
===
match
---
parameters [80820,80826]
parameters [81244,81250]
===
match
---
trailer [33865,33872]
trailer [33865,33872]
===
match
---
name: self [44782,44786]
name: self [44782,44786]
===
match
---
name: airflow [2881,2888]
name: airflow [2881,2888]
===
match
---
operator: , [49860,49861]
operator: , [49860,49861]
===
match
---
simple_stmt [60470,60531]
simple_stmt [60894,60955]
===
match
---
param [73846,73870]
param [74270,74294]
===
match
---
number: 20 [11043,11045]
number: 20 [11043,11045]
===
match
---
atom_expr [25762,25777]
atom_expr [25762,25777]
===
match
---
dotted_name [1378,1392]
dotted_name [1378,1392]
===
match
---
atom_expr [47683,47702]
atom_expr [47683,47702]
===
match
---
decorated [76519,76963]
decorated [76943,77387]
===
match
---
name: strftime [59114,59122]
name: strftime [59538,59546]
===
match
---
simple_stmt [28268,28306]
simple_stmt [28268,28306]
===
match
---
operator: , [1347,1348]
operator: , [1347,1348]
===
match
---
simple_stmt [32330,32586]
simple_stmt [32330,32586]
===
match
---
operator: = [17004,17005]
operator: = [17004,17005]
===
match
---
atom [20107,20118]
atom [20107,20118]
===
match
---
name: task [12525,12529]
name: task [12525,12529]
===
match
---
operator: , [57453,57454]
operator: , [57877,57878]
===
match
---
expr_stmt [13371,13389]
expr_stmt [13371,13389]
===
match
---
name: self [27347,27351]
name: self [27347,27351]
===
match
---
simple_stmt [42768,42810]
simple_stmt [42768,42810]
===
match
---
name: self [12347,12351]
name: self [12347,12351]
===
match
---
name: self [26266,26270]
name: self [26266,26270]
===
match
---
trailer [7352,7407]
trailer [7352,7407]
===
match
---
suite [76067,76368]
suite [76491,76792]
===
match
---
name: hasattr [15955,15962]
name: hasattr [15955,15962]
===
match
---
param [14525,14530]
param [14525,14530]
===
match
---
name: dag_id [78219,78225]
name: dag_id [78643,78649]
===
match
---
atom_expr [57682,57696]
atom_expr [58106,58120]
===
match
---
operator: -> [9285,9287]
operator: -> [9285,9287]
===
match
---
name: task [42926,42930]
name: task [42926,42930]
===
match
---
trailer [13402,13411]
trailer [13402,13411]
===
match
---
trailer [12105,12126]
trailer [12105,12126]
===
match
---
trailer [68786,68794]
trailer [69210,69218]
===
match
---
operator: { [20632,20633]
operator: { [20632,20633]
===
match
---
name: utils [2796,2801]
name: utils [2796,2801]
===
match
---
name: rendered_task_instance_fields [65668,65697]
name: rendered_task_instance_fields [66092,66121]
===
match
---
suite [42858,42953]
suite [42858,42953]
===
match
---
suite [54374,54394]
suite [54798,54818]
===
match
---
atom_expr [48016,48054]
atom_expr [48016,48054]
===
match
---
name: email_alert [57340,57351]
name: email_alert [57764,57775]
===
match
---
operator: = [11302,11303]
operator: = [11302,11303]
===
match
---
parameters [63174,63238]
parameters [63598,63662]
===
match
---
string: "Clearing XCom data" [25273,25293]
string: "Clearing XCom data" [25273,25293]
===
match
---
operator: == [77913,77915]
operator: == [78337,78339]
===
match
---
decorator [26804,26821]
decorator [26804,26821]
===
match
---
trailer [7384,7392]
trailer [7384,7392]
===
match
---
operator: = [41602,41603]
operator: = [41602,41603]
===
match
---
argument [46316,46331]
argument [46316,46331]
===
match
---
name: kube_config [67928,67939]
name: kube_config [68352,68363]
===
match
---
trailer [47119,47121]
trailer [47119,47121]
===
match
---
atom [58794,58959]
atom [59218,59383]
===
match
---
name: send_email [2558,2568]
name: send_email [2558,2568]
===
match
---
simple_stmt [60194,60255]
simple_stmt [60618,60679]
===
match
---
name: commit [42652,42658]
name: commit [42652,42658]
===
match
---
name: _update_ti_state_for_sensing [49930,49958]
name: _update_ti_state_for_sensing [49930,49958]
===
match
---
operator: } [60857,60858]
operator: } [61281,61282]
===
match
---
expr_stmt [21806,21825]
expr_stmt [21806,21825]
===
match
---
name: airflow [2496,2503]
name: airflow [2496,2503]
===
match
---
atom_expr [51855,51882]
atom_expr [51855,51882]
===
match
---
name: mark_success [43805,43817]
name: mark_success [43805,43817]
===
match
---
operator: -> [80895,80897]
operator: -> [81319,81321]
===
match
---
name: first [40916,40921]
name: first [40916,40921]
===
match
---
name: commit [42175,42181]
name: commit [42175,42181]
===
match
---
atom_expr [67393,67420]
atom_expr [67817,67844]
===
match
---
simple_stmt [54387,54394]
simple_stmt [54811,54818]
===
match
---
atom_expr [11514,11529]
atom_expr [11514,11529]
===
match
---
name: t [78153,78154]
name: t [78577,78578]
===
match
---
name: Exception [57378,57387]
name: Exception [57802,57811]
===
match
---
number: 16 [35764,35766]
number: 16 [35764,35766]
===
match
---
atom_expr [48511,48573]
atom_expr [48511,48573]
===
match
---
arglist [71925,71967]
arglist [72349,72391]
===
match
---
operator: = [23099,23100]
operator: = [23099,23100]
===
match
---
name: task_id_by_key [7666,7680]
name: task_id_by_key [7666,7680]
===
match
---
arglist [43142,43158]
arglist [43142,43158]
===
match
---
name: Optional [43882,43890]
name: Optional [43882,43890]
===
match
---
name: item [62638,62642]
name: item [63062,63066]
===
match
---
name: first [23166,23171]
name: first [23166,23171]
===
match
---
name: dag [5845,5848]
name: dag [5845,5848]
===
match
---
name: self [35422,35426]
name: self [35422,35426]
===
match
---
funcdef [80711,80792]
funcdef [81135,81216]
===
match
---
import_as_names [1037,1117]
import_as_names [1037,1117]
===
match
---
name: self [55027,55031]
name: self [55451,55455]
===
match
---
name: self [34755,34759]
name: self [34755,34759]
===
match
---
name: pool [16978,16982]
name: pool [16978,16982]
===
match
---
name: set_duration [54450,54462]
name: set_duration [54874,54886]
===
match
---
argument [7348,7482]
argument [7348,7482]
===
match
---
name: AirflowSmartSensorException [50233,50260]
name: AirflowSmartSensorException [50233,50260]
===
match
---
atom_expr [47188,47222]
atom_expr [47188,47222]
===
match
---
name: self [26223,26227]
name: self [26223,26227]
===
match
---
expr_stmt [39160,39176]
expr_stmt [39160,39176]
===
match
---
simple_stmt [13946,14203]
simple_stmt [13946,14203]
===
match
---
name: session [54283,54290]
name: session [54707,54714]
===
match
---
name: task_id [73445,73452]
name: task_id [73869,73876]
===
match
---
name: pickle_id [15477,15486]
name: pickle_id [15477,15486]
===
match
---
name: item [63372,63376]
name: item [63796,63800]
===
match
---
name: state [31891,31896]
name: state [31891,31896]
===
match
---
simple_stmt [44747,44774]
simple_stmt [44747,44774]
===
match
---
name: str [31500,31503]
name: str [31500,31503]
===
match
---
string: 'Host: {{ti.hostname}}<br>' [69582,69609]
string: 'Host: {{ti.hostname}}<br>' [70006,70033]
===
match
---
name: on_kill [47693,47700]
name: on_kill [47693,47700]
===
match
---
name: self [29736,29740]
name: self [29736,29740]
===
match
---
operator: @ [17030,17031]
operator: @ [17030,17031]
===
match
---
atom_expr [23608,23622]
atom_expr [23608,23622]
===
match
---
operator: = [11603,11604]
operator: = [11603,11604]
===
match
---
param [34822,34826]
param [34822,34826]
===
match
---
operator: , [50035,50036]
operator: , [50035,50036]
===
match
---
name: State [40803,40808]
name: State [40803,40808]
===
match
---
simple_stmt [2616,2673]
simple_stmt [2616,2673]
===
match
---
operator: , [81718,81719]
operator: , [82142,82143]
===
match
---
name: verbose [37402,37409]
name: verbose [37402,37409]
===
match
---
atom_expr [67510,67524]
atom_expr [67934,67948]
===
match
---
name: closed [4171,4177]
name: closed [4171,4177]
===
match
---
fstring_expr [20632,20646]
fstring_expr [20632,20646]
===
match
---
operator: = [11103,11104]
operator: = [11103,11104]
===
match
---
name: refresh_from_db [39282,39297]
name: refresh_from_db [39282,39297]
===
match
---
trailer [61934,61965]
trailer [62358,62389]
===
match
---
name: task_retries [5972,5984]
name: task_retries [5972,5984]
===
match
---
trailer [22227,22233]
trailer [22227,22233]
===
match
---
expr_stmt [69025,69344]
expr_stmt [69449,69768]
===
match
---
atom_expr [44964,44975]
atom_expr [44964,44975]
===
match
---
trailer [26182,26188]
trailer [26182,26188]
===
match
---
simple_stmt [53863,53880]
simple_stmt [54287,54304]
===
match
---
name: airflow [1853,1860]
name: airflow [1853,1860]
===
match
---
string: "at task runtime. Attempt %s of " [41839,41872]
string: "at task runtime. Attempt %s of " [41839,41872]
===
match
---
string: "%s. State set to NONE." [41893,41917]
string: "%s. State set to NONE." [41893,41917]
===
match
---
tfpdef [73803,73828]
tfpdef [74227,74252]
===
match
---
name: ts_nodash [64966,64975]
name: ts_nodash [65390,65399]
===
match
---
name: state [13376,13381]
name: state [13376,13381]
===
match
---
argument [53006,53021]
argument [53430,53445]
===
match
---
trailer [51045,51080]
trailer [51045,51080]
===
match
---
name: dag [29428,29431]
name: dag [29428,29431]
===
match
---
string: """         Returns the DagRun for this TaskInstance          :param session: SQLAlchemy ORM Session         :return: DagRun         """ [36902,37038]
string: """         Returns the DagRun for this TaskInstance          :param session: SQLAlchemy ORM Session         :return: DagRun         """ [36902,37038]
===
match
---
expr_stmt [23251,23282]
expr_stmt [23251,23282]
===
match
---
name: int [80749,80752]
name: int [81173,81176]
===
match
---
name: self [48423,48427]
name: self [48423,48427]
===
match
---
name: typing [1023,1029]
name: typing [1023,1029]
===
match
---
simple_stmt [29699,29767]
simple_stmt [29699,29767]
===
match
---
if_stmt [73101,73368]
if_stmt [73525,73792]
===
match
---
param [14616,14620]
param [14616,14620]
===
match
---
atom_expr [20262,20297]
atom_expr [20262,20297]
===
match
---
string: """         Copy common attributes from the given task.          :param task: The task object to copy from         :type task: airflow.models.BaseOperator         :param pool_override: Use the pool_override instead of task's pool         :type pool_override: str         """ [24384,24658]
string: """         Copy common attributes from the given task.          :param task: The task object to copy from         :type task: airflow.models.BaseOperator         :param pool_override: Use the pool_override instead of task's pool         :type pool_override: str         """ [24384,24658]
===
match
---
param [66351,66356]
param [66775,66780]
===
match
---
arglist [47204,47220]
arglist [47204,47220]
===
match
---
name: self [76989,76993]
name: self [77413,77417]
===
match
---
name: bool [73824,73828]
name: bool [74248,74252]
===
match
---
string: 'ti_dag_date' [11891,11904]
string: 'ti_dag_date' [11891,11904]
===
match
---
name: tis [78822,78825]
name: tis [79246,79249]
===
match
---
name: delay_backoff_in_seconds [36396,36420]
name: delay_backoff_in_seconds [36396,36420]
===
match
---
name: self [72321,72325]
name: self [72745,72749]
===
match
---
dotted_name [2574,2595]
dotted_name [2574,2595]
===
match
---
name: Context [58356,58363]
name: Context [58780,58787]
===
match
---
name: execution_date [28994,29008]
name: execution_date [28994,29008]
===
match
---
trailer [29717,29735]
trailer [29717,29735]
===
match
---
atom_expr [26476,26495]
atom_expr [26476,26495]
===
match
---
trailer [23906,23922]
trailer [23906,23922]
===
match
---
atom_expr [80930,80939]
atom_expr [81354,81363]
===
match
---
name: self [55066,55070]
name: self [55490,55494]
===
match
---
trailer [20772,20805]
trailer [20772,20805]
===
match
---
name: self [77074,77078]
name: self [77498,77502]
===
match
---
name: or_ [7123,7126]
name: or_ [7123,7126]
===
match
---
import_from [2526,2568]
import_from [2526,2568]
===
match
---
name: session [25303,25310]
name: session [25303,25310]
===
match
---
simple_stmt [4478,4520]
simple_stmt [4478,4520]
===
match
---
operator: = [48129,48130]
operator: = [48129,48130]
===
match
---
name: task [12966,12970]
name: task [12966,12970]
===
match
---
simple_stmt [53412,53419]
simple_stmt [53836,53843]
===
match
---
param [55284,55309]
param [55708,55733]
===
match
---
trailer [13442,13444]
trailer [13442,13444]
===
match
---
funcdef [79277,80069]
funcdef [79701,80493]
===
match
---
simple_stmt [77672,77702]
simple_stmt [78096,78126]
===
match
---
simple_stmt [41643,41667]
simple_stmt [41643,41667]
===
match
---
name: TaskInstance [22861,22873]
name: TaskInstance [22861,22873]
===
match
---
name: dep_status [34471,34481]
name: dep_status [34471,34481]
===
match
---
suite [5500,5775]
suite [5500,5775]
===
match
---
name: log [57410,57413]
name: log [57834,57837]
===
match
---
string: ':' [60694,60697]
string: ':' [61118,61121]
===
match
---
operator: , [40897,40898]
operator: , [40897,40898]
===
match
---
name: task [64670,64674]
name: task [65094,65098]
===
match
---
operator: , [37461,37462]
operator: , [37461,37462]
===
match
---
string: 'ts_nodash' [64953,64964]
string: 'ts_nodash' [65377,65388]
===
match
---
parameters [9724,9747]
parameters [9724,9747]
===
match
---
name: int [9743,9746]
name: int [9743,9746]
===
match
---
operator: , [73719,73720]
operator: , [74143,74144]
===
match
---
name: pool_override [39214,39227]
name: pool_override [39214,39227]
===
match
---
parameters [20417,20423]
parameters [20417,20423]
===
match
---
name: prev_ti [31361,31368]
name: prev_ti [31361,31368]
===
match
---
trailer [71231,71236]
trailer [71655,71660]
===
match
---
simple_stmt [59704,59746]
simple_stmt [60128,60170]
===
match
---
simple_stmt [9043,9078]
simple_stmt [9043,9078]
===
match
---
decorators [43717,43760]
decorators [43717,43760]
===
match
---
name: task [24349,24353]
name: task [24349,24353]
===
match
---
operator: , [43103,43104]
operator: , [43103,43104]
===
match
---
simple_stmt [1217,1275]
simple_stmt [1217,1275]
===
match
---
tfpdef [52731,52749]
tfpdef [53155,53173]
===
match
---
return_stmt [25691,25778]
return_stmt [25691,25778]
===
match
---
operator: , [4846,4847]
operator: , [4846,4847]
===
match
---
import_name [885,900]
import_name [885,900]
===
match
---
funcdef [32096,32651]
funcdef [32096,32651]
===
match
---
name: task [47536,47540]
name: task [47536,47540]
===
match
---
name: UP_FOR_RETRY [57116,57128]
name: UP_FOR_RETRY [57540,57552]
===
match
---
name: kubernetes [3097,3107]
name: kubernetes [3097,3107]
===
match
---
operator: == [25445,25447]
operator: == [25445,25447]
===
match
---
operator: = [31336,31337]
operator: = [31336,31337]
===
match
---
name: priority_weight [79990,80005]
name: priority_weight [80414,80429]
===
match
---
atom [46612,46641]
atom [46612,46641]
===
match
---
param [27916,27939]
param [27916,27939]
===
match
---
funcdef [51108,51438]
funcdef [51108,51438]
===
match
---
trailer [27804,27824]
trailer [27804,27824]
===
match
---
name: DagRun [37183,37189]
name: DagRun [37183,37189]
===
match
---
name: state [26271,26276]
name: state [26271,26276]
===
match
---
name: session [42167,42174]
name: session [42167,42174]
===
match
---
comparison [37183,37211]
comparison [37183,37211]
===
match
---
trailer [4533,4551]
trailer [4533,4551]
===
match
---
name: queue [24672,24677]
name: queue [24672,24677]
===
match
---
name: e [46863,46864]
name: e [46863,46864]
===
match
---
name: pod_template_file [68284,68301]
name: pod_template_file [68708,68725]
===
match
---
atom_expr [10805,10837]
atom_expr [10805,10837]
===
match
---
operator: , [55232,55233]
operator: , [55656,55657]
===
match
---
name: self [80731,80735]
name: self [81155,81159]
===
match
---
name: self [23251,23255]
name: self [23251,23255]
===
match
---
suite [32755,34020]
suite [32755,34020]
===
match
---
name: filter [21554,21560]
name: filter [21554,21560]
===
match
---
decorated [15133,15248]
decorated [15133,15248]
===
match
---
parameters [25583,25589]
parameters [25583,25589]
===
match
---
operator: , [75738,75739]
operator: , [76162,76163]
===
match
---
operator: , [37693,37694]
operator: , [37693,37694]
===
match
---
name: dag_id [67762,67768]
name: dag_id [68186,68192]
===
match
---
operator: , [50346,50347]
operator: , [50346,50347]
===
match
---
operator: , [20284,20285]
operator: , [20284,20285]
===
match
---
fstring_end: ' [47999,48000]
fstring_end: ' [47999,48000]
===
match
---
trailer [48377,48410]
trailer [48377,48410]
===
match
---
name: configuration [1568,1581]
name: configuration [1568,1581]
===
match
---
operator: = [53651,53652]
operator: = [54075,54076]
===
match
---
operator: @ [80074,80075]
operator: @ [80498,80499]
===
match
---
argument [70239,70296]
argument [70663,70720]
===
match
---
comparison [21684,21734]
comparison [21684,21734]
===
match
---
suite [48881,49543]
suite [48881,49543]
===
match
---
operator: , [20355,20356]
operator: , [20355,20356]
===
match
---
atom_expr [72389,72407]
atom_expr [72813,72831]
===
match
---
name: task [27340,27344]
name: task [27340,27344]
===
match
---
atom_expr [11939,11963]
atom_expr [11939,11963]
===
match
---
name: dag_id [25363,25369]
name: dag_id [25363,25369]
===
match
---
simple_stmt [11143,11175]
simple_stmt [11143,11175]
===
match
---
expr_stmt [27340,27356]
expr_stmt [27340,27356]
===
match
---
trailer [47785,47792]
trailer [47785,47792]
===
match
---
trailer [24274,24280]
trailer [24274,24280]
===
match
---
name: self [41731,41735]
name: self [41731,41735]
===
match
---
fstring_start: f' [49814,49816]
fstring_start: f' [49814,49816]
===
match
---
name: reschedule_exception [45848,45868]
name: reschedule_exception [45848,45868]
===
match
---
trailer [78534,78539]
trailer [78958,78963]
===
match
---
operator: == [21598,21600]
operator: == [21598,21600]
===
match
---
expr_stmt [81889,81936]
expr_stmt [82313,82360]
===
match
---
atom_expr [66687,66713]
atom_expr [67111,67137]
===
match
---
fstring_string: ?task_id= [20924,20933]
fstring_string: ?task_id= [20924,20933]
===
match
---
trailer [4210,4226]
trailer [4210,4226]
===
match
---
operator: = [28271,28272]
operator: = [28271,28272]
===
match
---
name: job_id [12119,12125]
name: job_id [12119,12125]
===
match
---
name: _end_date [79516,79525]
name: _end_date [79940,79949]
===
match
---
operator: @ [9445,9446]
operator: @ [9445,9446]
===
match
---
simple_stmt [45721,45764]
simple_stmt [45721,45764]
===
match
---
name: test_mode [53589,53598]
name: test_mode [54013,54022]
===
match
---
return_stmt [61663,61683]
return_stmt [62087,62107]
===
match
---
trailer [7906,7913]
trailer [7906,7913]
===
match
---
name: ti [78974,78976]
name: ti [79398,79400]
===
match
---
name: settings [1546,1554]
name: settings [1546,1554]
===
match
---
operator: == [7172,7174]
operator: == [7172,7174]
===
match
---
name: airflow [3388,3395]
name: airflow [3388,3395]
===
match
---
atom_expr [78153,78162]
atom_expr [78577,78586]
===
match
---
simple_stmt [29063,29076]
simple_stmt [29063,29076]
===
match
---
name: task_id [73458,73465]
name: task_id [73882,73889]
===
match
---
name: Column [11066,11072]
name: Column [11066,11072]
===
match
---
name: pod [68349,68352]
name: pod [68773,68776]
===
match
---
string: 'email' [71089,71096]
string: 'email' [71513,71520]
===
match
---
operator: = [39665,39666]
operator: = [39665,39666]
===
match
---
name: NamedTuple [9102,9112]
name: NamedTuple [9102,9112]
===
match
---
name: _run_raw_task [43768,43781]
name: _run_raw_task [43768,43781]
===
match
---
atom_expr [60363,60403]
atom_expr [60787,60827]
===
match
---
atom_expr [78672,78692]
atom_expr [79096,79116]
===
match
---
atom_expr [81519,81729]
atom_expr [81943,82153]
===
match
---
trailer [54595,54610]
trailer [55019,55034]
===
match
---
operator: , [52864,52865]
operator: , [53288,53289]
===
match
---
trailer [48619,48641]
trailer [48619,48641]
===
match
---
name: self [55493,55497]
name: self [55917,55921]
===
match
---
simple_stmt [79177,79272]
simple_stmt [79601,79696]
===
match
---
name: ignore_depends_on_past [19925,19947]
name: ignore_depends_on_past [19925,19947]
===
match
---
annassign [15792,15818]
annassign [15792,15818]
===
match
---
name: next_execution_date [59908,59927]
name: next_execution_date [60332,60351]
===
match
---
trailer [62845,62849]
trailer [63269,63273]
===
match
---
operator: , [64823,64824]
operator: , [65247,65248]
===
match
---
expr_stmt [24788,24837]
expr_stmt [24788,24837]
===
match
---
name: duration [26407,26415]
name: duration [26407,26415]
===
match
---
name: get_dagrun [28278,28288]
name: get_dagrun [28278,28288]
===
match
---
operator: , [9879,9880]
operator: , [9879,9880]
===
match
---
name: last_dagrun [29587,29598]
name: last_dagrun [29587,29598]
===
match
---
import_from [1555,1593]
import_from [1555,1593]
===
match
---
param [57957,57961]
param [58381,58385]
===
match
---
trailer [43641,43655]
trailer [43641,43655]
===
match
---
atom_expr [52948,53379]
atom_expr [53372,53803]
===
match
---
operator: = [67708,67709]
operator: = [68132,68133]
===
match
---
fstring [56056,56093]
fstring [56480,56517]
===
match
---
dotted_name [1599,1617]
dotted_name [1599,1617]
===
match
---
name: ti [24045,24047]
name: ti [24045,24047]
===
match
---
name: pod_override_object [68043,68062]
name: pod_override_object [68467,68486]
===
match
---
name: SUCCESS [53812,53819]
name: SUCCESS [54236,54243]
===
match
---
atom_expr [47898,47920]
atom_expr [47898,47920]
===
match
---
atom_expr [40803,40826]
atom_expr [40803,40826]
===
match
---
suite [34334,34668]
suite [34334,34668]
===
match
---
param [52652,52683]
param [53076,53107]
===
match
---
name: var [62298,62301]
name: var [62722,62725]
===
match
---
suite [50587,50727]
suite [50587,50727]
===
match
---
argument [62881,62902]
argument [63305,63326]
===
match
---
operator: , [48231,48232]
operator: , [48231,48232]
===
match
---
name: exception_html [70033,70047]
name: exception_html [70457,70471]
===
match
---
name: ValueError [73179,73189]
name: ValueError [73603,73613]
===
match
---
name: ignore_all_deps [41315,41330]
name: ignore_all_deps [41315,41330]
===
match
---
trailer [31874,31890]
trailer [31874,31890]
===
match
---
name: self [80508,80512]
name: self [80932,80936]
===
match
---
trailer [71271,71283]
trailer [71695,71707]
===
match
---
testlist_comp [19727,19750]
testlist_comp [19727,19750]
===
match
---
operator: , [63904,63905]
operator: , [64328,64329]
===
match
---
trailer [37681,37686]
trailer [37681,37686]
===
match
---
suite [3723,3746]
suite [3723,3746]
===
match
---
name: dag_id [78041,78047]
name: dag_id [78465,78471]
===
match
---
param [30315,30319]
param [30315,30319]
===
match
---
trailer [37175,37182]
trailer [37175,37182]
===
match
---
param [80425,80429]
param [80849,80853]
===
match
---
name: bool [43819,43823]
name: bool [43819,43823]
===
match
---
trailer [78452,78460]
trailer [78876,78884]
===
match
---
name: construct_pod [67723,67736]
name: construct_pod [68147,68160]
===
match
---
trailer [50626,50644]
trailer [50626,50644]
===
match
---
trailer [31315,31345]
trailer [31315,31345]
===
match
---
operator: @ [80313,80314]
operator: @ [80737,80738]
===
match
---
name: refresh_from_db [44844,44859]
name: refresh_from_db [44844,44859]
===
match
---
suite [42970,43055]
suite [42970,43055]
===
match
---
lambdef [64547,64604]
lambdef [64971,65028]
===
match
---
name: merge [57514,57519]
name: merge [57938,57943]
===
match
---
import_as_names [1631,1845]
import_as_names [1631,1845]
===
match
---
trailer [60562,60571]
trailer [60986,60995]
===
match
---
name: error_file [46333,46343]
name: error_file [46333,46343]
===
match
---
name: self [43488,43492]
name: self [43488,43492]
===
match
---
operator: = [12462,12463]
operator: = [12462,12463]
===
match
---
simple_stmt [67383,67421]
simple_stmt [67807,67845]
===
match
---
operator: = [59201,59202]
operator: = [59625,59626]
===
match
---
simple_stmt [42644,42661]
simple_stmt [42644,42661]
===
match
---
name: ti [78759,78761]
name: ti [79183,79185]
===
match
---
name: sanitize_for_serialization [68390,68416]
name: sanitize_for_serialization [68814,68840]
===
match
---
trailer [66691,66711]
trailer [67115,67135]
===
match
---
string: "previous_execution_date was called" [31239,31275]
string: "previous_execution_date was called" [31239,31275]
===
match
---
trailer [26089,26096]
trailer [26089,26096]
===
match
---
name: default_var [62665,62676]
name: default_var [63089,63100]
===
match
---
comp_op [29368,29374]
comp_op [29368,29374]
===
match
---
trailer [4245,4247]
trailer [4245,4247]
===
match
---
name: rendered_k8s_spec [66513,66530]
name: rendered_k8s_spec [66937,66954]
===
match
---
comparison [78618,78650]
comparison [79042,79074]
===
match
---
name: execution_date [37243,37257]
name: execution_date [37243,37257]
===
match
---
atom_expr [51305,51338]
atom_expr [51305,51338]
===
match
---
simple_stmt [80452,80474]
simple_stmt [80876,80898]
===
match
---
trailer [53871,53877]
trailer [54295,54301]
===
match
---
or_test [24711,24737]
or_test [24711,24737]
===
match
---
param [26855,26867]
param [26855,26867]
===
match
---
trailer [80748,80753]
trailer [81172,81177]
===
match
---
operator: , [78477,78478]
operator: , [78901,78902]
===
match
---
name: set_current_context [49592,49611]
name: set_current_context [49592,49611]
===
match
---
try_stmt [71808,71969]
try_stmt [72232,72393]
===
match
---
trailer [58252,58263]
trailer [58676,58687]
===
match
---
name: self [33994,33998]
name: self [33994,33998]
===
match
---
trailer [54122,54139]
trailer [54546,54563]
===
match
---
suite [8363,9078]
suite [8363,9078]
===
match
---
argument [16604,16629]
argument [16604,16629]
===
match
---
name: UtcDateTime [10940,10951]
name: UtcDateTime [10940,10951]
===
match
---
trailer [51880,51882]
trailer [51880,51882]
===
match
---
name: e [66297,66298]
name: e [66721,66722]
===
match
---
simple_stmt [60580,60638]
simple_stmt [61004,61062]
===
match
---
trailer [70272,70277]
trailer [70696,70701]
===
match
---
simple_stmt [51759,51776]
simple_stmt [51759,51776]
===
match
---
name: self [72111,72115]
name: self [72535,72539]
===
match
---
atom_expr [52172,52205]
atom_expr [52339,52372]
===
match
---
trailer [25525,25529]
trailer [25525,25529]
===
match
---
suite [66779,66885]
suite [67203,67309]
===
match
---
name: TaskInstance [78440,78452]
name: TaskInstance [78864,78876]
===
match
---
operator: = [17476,17477]
operator: = [17476,17477]
===
match
---
trailer [27582,27602]
trailer [27582,27602]
===
match
---
atom_expr [11190,11210]
atom_expr [11190,11210]
===
match
---
trailer [22854,22860]
trailer [22854,22860]
===
match
---
name: task_id [78232,78239]
name: task_id [78656,78663]
===
match
---
name: int [79576,79579]
name: int [80000,80003]
===
match
---
param [15425,15447]
param [15425,15447]
===
match
---
suite [78853,79018]
suite [79277,79442]
===
match
---
operator: = [40996,40997]
operator: = [40996,40997]
===
match
---
operator: , [4544,4545]
operator: , [4544,4545]
===
match
---
name: execution_date [9199,9213]
name: execution_date [9199,9213]
===
match
---
expr_stmt [11616,11679]
expr_stmt [11616,11679]
===
match
---
string: "{}#{}#{}#{}" [35569,35582]
string: "{}#{}#{}#{}" [35569,35582]
===
match
---
argument [16925,16932]
argument [16925,16932]
===
match
---
trailer [43000,43054]
trailer [43000,43054]
===
match
---
name: pool [80647,80651]
name: pool [81071,81075]
===
match
---
string: "Refreshed TaskInstance %s" [24281,24308]
string: "Refreshed TaskInstance %s" [24281,24308]
===
match
---
name: DagRunState [4946,4957]
name: DagRunState [4946,4957]
===
match
---
name: in_ [8750,8753]
name: in_ [8750,8753]
===
match
---
operator: , [60176,60177]
operator: , [60600,60601]
===
match
---
name: self [64555,64559]
name: self [64979,64983]
===
match
---
simple_stmt [40980,41025]
simple_stmt [40980,41025]
===
match
---
trailer [35707,35716]
trailer [35707,35716]
===
match
---
trailer [82130,82144]
trailer [82554,82568]
===
match
---
atom_expr [39413,39421]
atom_expr [39413,39421]
===
match
---
trailer [57513,57519]
trailer [57937,57943]
===
match
---
fstring_expr [45119,45133]
fstring_expr [45119,45133]
===
match
---
atom_expr [79538,79549]
atom_expr [79962,79973]
===
match
---
name: tis [77534,77537]
name: tis [77958,77961]
===
match
---
expr_stmt [16287,16314]
expr_stmt [16287,16314]
===
match
---
simple_stmt [57141,57179]
simple_stmt [57565,57603]
===
match
---
atom_expr [45692,45708]
atom_expr [45692,45708]
===
match
---
name: key [75676,75679]
name: key [76100,76103]
===
match
---
param [80821,80825]
param [81245,81249]
===
match
---
operator: = [52750,52751]
operator: = [53174,53175]
===
match
---
name: debug [31812,31817]
name: debug [31812,31817]
===
match
---
string: "Task successfully registered in smart sensor." [50261,50308]
string: "Task successfully registered in smart sensor." [50261,50308]
===
match
---
name: task [70991,70995]
name: task [71415,71419]
===
match
---
name: dag [29383,29386]
name: dag [29383,29386]
===
match
---
trailer [50069,50077]
trailer [50069,50077]
===
match
---
name: incr [49809,49813]
name: incr [49809,49813]
===
match
---
name: context [3481,3488]
name: context [3481,3488]
===
match
---
name: contextlib [794,804]
name: contextlib [794,804]
===
match
---
name: dag_id [11995,12001]
name: dag_id [11995,12001]
===
match
---
trailer [45669,45674]
trailer [45669,45674]
===
match
---
atom_expr [12961,12980]
atom_expr [12961,12980]
===
match
---
name: ti [23157,23159]
name: ti [23157,23159]
===
match
---
operator: == [27793,27795]
operator: == [27793,27795]
===
match
---
atom_expr [24045,24064]
atom_expr [24045,24064]
===
match
---
name: session [30929,30936]
name: session [30929,30936]
===
match
---
parameters [80582,80588]
parameters [81006,81012]
===
match
---
name: context [49762,49769]
name: context [49762,49769]
===
match
---
return_stmt [80763,80791]
return_stmt [81187,81215]
===
match
---
name: session [50130,50137]
name: session [50130,50137]
===
match
---
operator: -> [25590,25592]
operator: -> [25590,25592]
===
match
---
import_as_names [2957,2975]
import_as_names [2957,2975]
===
match
---
name: delete [53475,53481]
name: delete [53899,53905]
===
match
---
suite [71812,71876]
suite [72236,72300]
===
match
---
expr_stmt [24980,25010]
expr_stmt [24980,25010]
===
match
---
suite [9026,9078]
suite [9026,9078]
===
match
---
param [9279,9283]
param [9279,9283]
===
match
---
string: """         Construct a TaskInstance from the database based on the primary key          :param session: DB session.         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :return: the task instance constructed         """ [81145,81504]
string: """         Construct a TaskInstance from the database based on the primary key          :param session: DB session.         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :return: the task instance constructed         """ [81569,81928]
===
match
---
atom [19654,19682]
atom [19654,19682]
===
match
---
simple_stmt [45198,45236]
simple_stmt [45198,45236]
===
match
---
operator: , [41346,41347]
operator: , [41346,41347]
===
match
---
name: executor_config [68090,68105]
name: executor_config [68514,68529]
===
match
---
operator: { [65048,65049]
operator: { [65472,65473]
===
match
---
atom_expr [55330,55343]
atom_expr [55754,55767]
===
match
---
trailer [78935,78950]
trailer [79359,79374]
===
match
---
name: utils [2629,2634]
name: utils [2629,2634]
===
match
---
name: get_failed_dep_statuses [34050,34073]
name: get_failed_dep_statuses [34050,34073]
===
match
---
name: self [45252,45256]
name: self [45252,45256]
===
match
---
name: next_execution_date [60194,60213]
name: next_execution_date [60618,60637]
===
match
---
if_stmt [39708,42213]
if_stmt [39708,42213]
===
match
---
atom_expr [77927,77943]
atom_expr [78351,78367]
===
match
---
decorator [29793,29803]
decorator [29793,29803]
===
match
---
name: ignore_all_deps [52567,52582]
name: ignore_all_deps [52991,53006]
===
match
---
operator: = [59146,59147]
operator: = [59570,59571]
===
match
---
comp_op [8342,8348]
comp_op [8342,8348]
===
match
---
name: dag_model [12139,12148]
name: dag_model [12139,12148]
===
match
---
name: session [25063,25070]
name: session [25063,25070]
===
match
---
name: task_id [12504,12511]
name: task_id [12504,12511]
===
match
---
funcdef [80088,80141]
funcdef [80512,80565]
===
match
---
name: dates [7657,7662]
name: dates [7657,7662]
===
match
---
try_stmt [48999,49361]
try_stmt [48999,49361]
===
match
---
trailer [70586,70593]
trailer [71010,71017]
===
match
---
operator: - [36353,36354]
operator: - [36353,36354]
===
match
---
name: local [17355,17360]
name: local [17355,17360]
===
match
---
name: include_prior_dates [75772,75791]
name: include_prior_dates [76196,76215]
===
match
---
decorator [21891,21908]
decorator [21891,21908]
===
match
---
atom_expr [57290,57300]
atom_expr [57714,57724]
===
match
---
operator: , [40289,40290]
operator: , [40289,40290]
===
match
---
expr_stmt [60077,60127]
expr_stmt [60501,60551]
===
match
---
expr_stmt [28268,28305]
expr_stmt [28268,28305]
===
match
---
name: dag [5891,5894]
name: dag [5891,5894]
===
match
---
name: pool [12061,12065]
name: pool [12061,12065]
===
match
---
simple_stmt [73893,75520]
simple_stmt [74317,75944]
===
match
---
operator: , [11659,11660]
operator: , [11659,11660]
===
match
---
trailer [27450,27484]
trailer [27450,27484]
===
match
---
name: isoformat [20793,20802]
name: isoformat [20793,20802]
===
match
---
name: self [15282,15286]
name: self [15282,15286]
===
match
---
name: task [58868,58872]
name: task [59292,59296]
===
match
---
name: execution_date [37220,37234]
name: execution_date [37220,37234]
===
match
---
name: external_executor_id [6493,6513]
name: external_executor_id [6493,6513]
===
match
---
expr_stmt [10716,10784]
expr_stmt [10716,10784]
===
match
---
simple_stmt [59188,59261]
simple_stmt [59612,59685]
===
match
---
trailer [23171,23173]
trailer [23171,23173]
===
match
---
operator: , [53561,53562]
operator: , [53985,53986]
===
match
---
simple_stmt [5749,5775]
simple_stmt [5749,5775]
===
match
---
trailer [26115,26121]
trailer [26115,26121]
===
match
---
operator: @ [80697,80698]
operator: @ [81121,81122]
===
match
---
name: Context [51149,51156]
name: Context [51149,51156]
===
match
---
return_stmt [68430,68450]
return_stmt [68854,68874]
===
match
---
comparison [7995,8024]
comparison [7995,8024]
===
match
---
trailer [20216,20227]
trailer [20216,20227]
===
match
---
atom_expr [15227,15243]
atom_expr [15227,15243]
===
match
---
operator: { [20971,20972]
operator: { [20971,20972]
===
match
---
name: get_previous_dagrun [29604,29623]
name: get_previous_dagrun [29604,29623]
===
match
---
atom_expr [5929,5955]
atom_expr [5929,5955]
===
match
---
name: task [36497,36501]
name: task [36497,36501]
===
match
---
operator: = [37615,37616]
operator: = [37615,37616]
===
match
---
arglist [70759,70928]
arglist [71183,71352]
===
match
---
name: xcom_push [72302,72311]
name: xcom_push [72726,72735]
===
match
---
name: delete_qry [7708,7718]
name: delete_qry [7708,7718]
===
match
---
operator: = [51920,51921]
operator: = [51920,51921]
===
match
---
name: provide_session [2860,2875]
name: provide_session [2860,2875]
===
match
---
operator: = [58346,58347]
operator: = [58770,58771]
===
match
---
trailer [25403,25411]
trailer [25403,25411]
===
match
---
operator: -> [44010,44012]
operator: -> [44010,44012]
===
match
---
operator: = [58899,58900]
operator: = [59323,59324]
===
match
---
name: delay [36480,36485]
name: delay [36480,36485]
===
match
---
atom_expr [19578,19608]
atom_expr [19578,19608]
===
match
---
name: data [4259,4263]
name: data [4259,4263]
===
match
---
funcdef [47562,47770]
funcdef [47562,47770]
===
match
---
operator: = [36395,36396]
operator: = [36395,36396]
===
match
---
name: self [21601,21605]
name: self [21601,21605]
===
match
---
name: state [21820,21825]
name: state [21820,21825]
===
match
---
name: task [27352,27356]
name: task [27352,27356]
===
match
---
name: lock_for_update [81742,81757]
name: lock_for_update [82166,82181]
===
match
---
arith_expr [41976,41994]
arith_expr [41976,41994]
===
match
---
name: dates [7586,7591]
name: dates [7586,7591]
===
match
---
atom [78973,79003]
atom [79397,79427]
===
match
---
name: dates_by_dag_id [8523,8538]
name: dates_by_dag_id [8523,8538]
===
match
---
name: task [65736,65740]
name: task [66160,66164]
===
match
---
name: self [42557,42561]
name: self [42557,42561]
===
match
---
operator: , [15550,15551]
operator: , [15550,15551]
===
match
---
param [36588,36592]
param [36588,36592]
===
match
---
operator: = [10693,10694]
operator: = [10693,10694]
===
match
---
name: log [67093,67096]
name: log [67517,67520]
===
match
---
trailer [67939,67950]
trailer [68363,68374]
===
match
---
argument [75721,75738]
argument [76145,76162]
===
match
---
name: task_id [76839,76846]
name: task_id [77263,77270]
===
match
---
funcdef [12334,13712]
funcdef [12334,13712]
===
match
---
operator: @ [54175,54176]
operator: @ [54599,54600]
===
match
---
atom [63689,65307]
atom [64113,65731]
===
match
---
simple_stmt [26205,26255]
simple_stmt [26205,26255]
===
match
---
operator: , [32738,32739]
operator: , [32738,32739]
===
match
---
operator: @ [76519,76520]
operator: @ [76943,76944]
===
match
---
atom_expr [23816,23829]
atom_expr [23816,23829]
===
match
---
simple_stmt [20578,20669]
simple_stmt [20578,20669]
===
match
---
name: state [11957,11962]
name: state [11957,11962]
===
match
---
trailer [8648,8655]
trailer [8648,8655]
===
match
---
arglist [42304,42368]
arglist [42304,42368]
===
match
---
parameters [14615,14621]
parameters [14615,14621]
===
match
---
simple_stmt [60287,60309]
simple_stmt [60711,60733]
===
match
---
name: email [71935,71940]
name: email [72359,72364]
===
match
---
expr_stmt [40738,40773]
expr_stmt [40738,40773]
===
match
---
operator: = [71494,71495]
operator: = [71918,71919]
===
match
---
operator: , [45980,45981]
operator: , [45980,45981]
===
match
---
trailer [4088,4111]
trailer [4088,4111]
===
match
---
name: State [41656,41661]
name: State [41656,41661]
===
match
---
name: self [52272,52276]
name: self [52556,52560]
===
match
---
name: execution_date [54596,54610]
name: execution_date [55020,55034]
===
match
---
trailer [81702,81718]
trailer [82126,82142]
===
match
---
name: max_tries [24895,24904]
name: max_tries [24895,24904]
===
match
---
name: TaskInstance [21578,21590]
name: TaskInstance [21578,21590]
===
match
---
operator: = [24250,24251]
operator: = [24250,24251]
===
match
---
name: Index [11939,11944]
name: Index [11939,11944]
===
match
---
name: is_localized [12741,12753]
name: is_localized [12741,12753]
===
match
---
trailer [11844,11875]
trailer [11844,11875]
===
match
---
atom_expr [46424,46446]
atom_expr [46424,46446]
===
match
---
name: fd [4238,4240]
name: fd [4238,4240]
===
match
---
name: Context [3311,3318]
name: Context [3311,3318]
===
match
---
name: tomorrow_ds_nodash [64899,64917]
name: tomorrow_ds_nodash [65323,65341]
===
match
---
name: nullable [11331,11339]
name: nullable [11331,11339]
===
match
---
operator: , [71723,71724]
operator: , [72147,72148]
===
match
---
operator: , [71949,71950]
operator: , [72373,72374]
===
match
---
name: prev_ti [31285,31292]
name: prev_ti [31285,31292]
===
match
---
name: dag_run [67062,67069]
name: dag_run [67486,67493]
===
match
---
name: ti_key_str [60830,60840]
name: ti_key_str [61254,61264]
===
match
---
string: """         Returns whether or not all the conditions are met for this task instance to be run         given the context for the dependencies (e.g. a task instance being force run from         the UI will ignore some dependencies).          :param dep_context: The execution context that determines the dependencies that             should be evaluated.         :type dep_context: DepContext         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param verbose: whether log details on failed dependencies on             info or debug log level         :type verbose: bool         """ [32764,33396]
string: """         Returns whether or not all the conditions are met for this task instance to be run         given the context for the dependencies (e.g. a task instance being force run from         the UI will ignore some dependencies).          :param dep_context: The execution context that determines the dependencies that             should be evaluated.         :type dep_context: DepContext         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param verbose: whether log details on failed dependencies on             info or debug log level         :type verbose: bool         """ [32764,33396]
===
match
---
operator: } [47969,47970]
operator: } [47969,47970]
===
match
---
atom_expr [12450,12461]
atom_expr [12450,12461]
===
match
---
trailer [40808,40826]
trailer [40808,40826]
===
match
---
param [22317,22330]
param [22317,22330]
===
match
---
operator: , [63969,63970]
operator: , [64393,64394]
===
match
---
and_test [72047,72080]
and_test [72471,72504]
===
match
---
string: "TaskInstanceKey" [9964,9981]
string: "TaskInstanceKey" [9964,9981]
===
match
---
name: kube_config [3108,3119]
name: kube_config [3108,3119]
===
match
---
suite [23083,23131]
suite [23083,23131]
===
match
---
and_test [15929,15980]
and_test [15929,15980]
===
match
---
operator: } [48529,48530]
operator: } [48529,48530]
===
match
---
operator: } [56091,56092]
operator: } [56515,56516]
===
match
---
simple_stmt [62488,62504]
simple_stmt [62912,62928]
===
match
---
trailer [22881,23054]
trailer [22881,23054]
===
match
---
atom_expr [32330,32585]
atom_expr [32330,32585]
===
match
---
name: ti [23581,23583]
name: ti [23581,23583]
===
match
---
name: date [67964,67968]
name: date [68388,68392]
===
match
---
simple_stmt [73173,73368]
simple_stmt [73597,73792]
===
match
---
string: "Dependencies all met for %s" [33963,33992]
string: "Dependencies all met for %s" [33963,33992]
===
match
---
trailer [31811,31817]
trailer [31811,31817]
===
match
---
funcdef [50315,51103]
funcdef [50315,51103]
===
match
---
operator: + [6045,6046]
operator: + [6045,6046]
===
match
---
name: email [57295,57300]
name: email [57719,57724]
===
match
---
name: passed [34523,34529]
name: passed [34523,34529]
===
match
---
operator: { [46999,47000]
operator: { [46999,47000]
===
match
---
trailer [48126,48159]
trailer [48126,48159]
===
match
---
atom_expr [35514,35781]
atom_expr [35514,35781]
===
match
---
atom_expr [52219,52229]
atom_expr [52503,52513]
===
match
---
operator: , [43938,43939]
operator: , [43938,43939]
===
match
---
argument [48387,48409]
argument [48387,48409]
===
match
---
argument [53231,53256]
argument [53655,53680]
===
match
---
operator: , [4964,4965]
operator: , [4964,4965]
===
match
---
import_from [2321,2371]
import_from [2321,2371]
===
match
---
name: params [61082,61088]
name: params [61506,61512]
===
match
---
atom_expr [42522,42532]
atom_expr [42522,42532]
===
match
---
atom_expr [16221,16252]
atom_expr [16221,16252]
===
match
---
expr_stmt [53445,53487]
expr_stmt [53869,53911]
===
match
---
name: timezone [36803,36811]
name: timezone [36803,36811]
===
match
---
trailer [77693,77701]
trailer [78117,78125]
===
match
---
suite [6081,6444]
suite [6081,6444]
===
match
---
name: elements [1491,1499]
name: elements [1491,1499]
===
match
---
comparison [52297,52331]
comparison [52581,52615]
===
match
---
name: self [42921,42925]
name: self [42921,42925]
===
match
---
string: 'end_date' [43689,43699]
string: 'end_date' [43689,43699]
===
match
---
name: task_copy [54099,54108]
name: task_copy [54523,54532]
===
match
---
name: self [53950,53954]
name: self [54374,54378]
===
match
---
simple_stmt [13398,13417]
simple_stmt [13398,13417]
===
match
---
operator: , [15972,15973]
operator: , [15972,15973]
===
match
---
trailer [49046,49073]
trailer [49046,49073]
===
match
---
operator: , [33837,33838]
operator: , [33837,33838]
===
match
---
decorated [43717,47281]
decorated [43717,47281]
===
match
---
operator: , [17374,17375]
operator: , [17374,17375]
===
match
---
name: session [26855,26862]
name: session [26855,26862]
===
match
---
name: provide_session [30817,30832]
name: provide_session [30817,30832]
===
match
---
name: log [3857,3860]
name: log [3857,3860]
===
match
---
param [73667,73720]
param [74091,74144]
===
match
---
string: 'TaskInstance' [27958,27972]
string: 'TaskInstance' [27958,27972]
===
match
---
atom_expr [19450,19476]
atom_expr [19450,19476]
===
match
---
name: property [26502,26510]
name: property [26502,26510]
===
match
---
operator: , [43146,43147]
operator: , [43146,43147]
===
match
---
trailer [25485,25487]
trailer [25485,25487]
===
match
---
operator: = [53548,53549]
operator: = [53972,53973]
===
match
---
operator: = [53723,53724]
operator: = [54147,54148]
===
match
---
expr_stmt [70638,70681]
expr_stmt [71062,71105]
===
match
---
suite [9314,9440]
suite [9314,9440]
===
match
---
operator: @ [20392,20393]
operator: @ [20392,20393]
===
match
---
simple_stmt [2569,2616]
simple_stmt [2569,2616]
===
match
---
name: session [29632,29639]
name: session [29632,29639]
===
match
---
name: session [37141,37148]
name: session [37141,37148]
===
match
---
operator: , [68206,68207]
operator: , [68630,68631]
===
match
---
atom_expr [73677,73712]
atom_expr [74101,74136]
===
match
---
name: exception [70759,70768]
name: exception [71183,71192]
===
match
---
name: ti [6031,6033]
name: ti [6031,6033]
===
match
---
expr_stmt [51759,51775]
expr_stmt [51759,51775]
===
match
---
operator: , [56313,56314]
operator: , [56737,56738]
===
match
---
return_stmt [63256,63307]
return_stmt [63680,63731]
===
match
---
trailer [24671,24677]
trailer [24671,24677]
===
match
---
param [15355,15378]
param [15355,15378]
===
match
---
trailer [72229,72271]
trailer [72653,72695]
===
match
---
name: state [34783,34788]
name: state [34783,34788]
===
match
---
string: '\n' [48511,48515]
string: '\n' [48511,48515]
===
match
---
param [31513,31536]
param [31513,31536]
===
match
---
decorated [21129,21886]
decorated [21129,21886]
===
match
---
name: task_id [78914,78921]
name: task_id [79338,79345]
===
match
---
suite [53432,53747]
suite [53856,54171]
===
match
---
name: k [48524,48525]
name: k [48524,48525]
===
match
---
name: str [17586,17589]
name: str [17586,17589]
===
match
---
param [43264,43269]
param [43264,43269]
===
match
---
test [57204,57257]
test [57628,57681]
===
match
---
atom_expr [48694,48732]
atom_expr [48694,48732]
===
match
---
operator: , [78776,78777]
operator: , [79200,79201]
===
match
---
name: first [37272,37277]
name: first [37272,37277]
===
match
---
string: """Render templates in the operator fields.""" [67300,67346]
string: """Render templates in the operator fields.""" [67724,67770]
===
match
---
name: self [25741,25745]
name: self [25741,25745]
===
match
---
operator: , [70047,70048]
operator: , [70471,70472]
===
match
---
name: Any [73880,73883]
name: Any [74304,74307]
===
match
---
exprlist [8786,8799]
exprlist [8786,8799]
===
match
---
comparison [78672,78706]
comparison [79096,79130]
===
match
---
name: warning [3861,3868]
name: warning [3861,3868]
===
match
---
simple_stmt [16444,16461]
simple_stmt [16444,16461]
===
match
---
annassign [79421,79451]
annassign [79845,79875]
===
match
---
name: test_mode [43841,43850]
name: test_mode [43841,43850]
===
match
---
name: Index [12044,12049]
name: Index [12044,12049]
===
match
---
operator: == [78693,78695]
operator: == [79117,79119]
===
match
---
name: execution_date [56282,56296]
name: execution_date [56706,56720]
===
match
---
name: conf [20536,20540]
name: conf [20536,20540]
===
match
---
name: kubernetes [67581,67591]
name: kubernetes [68005,68015]
===
match
---
return_stmt [30242,30271]
return_stmt [30242,30271]
===
match
---
name: end_date [26424,26432]
name: end_date [26424,26432]
===
match
---
name: dag_run_state [4894,4907]
name: dag_run_state [4894,4907]
===
match
---
name: key [80065,80068]
name: key [80489,80492]
===
match
---
name: get_template_context [52133,52153]
name: get_template_context [52275,52295]
===
match
---
name: tis [78418,78421]
name: tis [78842,78845]
===
match
---
name: start_date [32065,32075]
name: start_date [32065,32075]
===
match
---
operator: = [70912,70913]
operator: = [71336,71337]
===
match
---
suite [20424,20669]
suite [20424,20669]
===
match
---
name: defaultdict [5425,5436]
name: defaultdict [5425,5436]
===
match
---
name: bool [52778,52782]
name: bool [53202,53206]
===
match
---
name: run_as_user [24851,24862]
name: run_as_user [24851,24862]
===
match
---
comparison [26298,26330]
comparison [26298,26330]
===
match
---
yield_expr [34651,34667]
yield_expr [34651,34667]
===
match
---
name: dag [29072,29075]
name: dag [29072,29075]
===
match
---
operator: - [35438,35439]
operator: - [35438,35439]
===
match
---
trailer [79868,79885]
trailer [80292,80309]
===
match
---
suite [56980,57071]
suite [57404,57495]
===
match
---
trailer [42382,42386]
trailer [42382,42386]
===
match
---
atom_expr [79987,80005]
atom_expr [80411,80429]
===
match
---
name: self [34352,34356]
name: self [34352,34356]
===
match
---
operator: @ [29793,29794]
operator: @ [29793,29794]
===
match
---
arith_expr [59284,59318]
arith_expr [59708,59742]
===
match
---
name: warnings [30506,30514]
name: warnings [30506,30514]
===
match
---
name: self [42030,42034]
name: self [42030,42034]
===
match
---
operator: = [11469,11470]
operator: = [11469,11470]
===
match
---
decorator [34025,34042]
decorator [34025,34042]
===
match
---
name: ti [81864,81866]
name: ti [82288,82290]
===
match
---
name: task_id [5904,5911]
name: task_id [5904,5911]
===
match
---
simple_stmt [69913,70179]
simple_stmt [70337,70603]
===
match
---
atom_expr [4529,4551]
atom_expr [4529,4551]
===
match
---
name: task [36442,36446]
name: task [36442,36446]
===
match
---
trailer [36778,36798]
trailer [36778,36798]
===
match
---
name: execution_date [10861,10875]
name: execution_date [10861,10875]
===
match
---
atom_expr [7348,7407]
atom_expr [7348,7407]
===
match
---
funcdef [36568,36821]
funcdef [36568,36821]
===
match
---
name: or_ [7315,7318]
name: or_ [7315,7318]
===
match
---
atom_expr [57006,57018]
atom_expr [57430,57442]
===
match
---
string: """Returns TaskInstanceKey with provided ``try_number``""" [9778,9836]
string: """Returns TaskInstanceKey with provided ``try_number``""" [9778,9836]
===
match
---
name: email_on_failure [57054,57070]
name: email_on_failure [57478,57494]
===
match
---
expr_stmt [55975,56008]
expr_stmt [56399,56432]
===
match
---
name: str [37718,37721]
name: str [37718,37721]
===
match
---
name: Stats [49873,49878]
name: Stats [49873,49878]
===
match
---
operator: , [1820,1821]
operator: , [1820,1821]
===
match
---
string: "worker-config" [68137,68152]
string: "worker-config" [68561,68576]
===
match
---
name: context_to_airflow_vars [2759,2782]
name: context_to_airflow_vars [2759,2782]
===
match
---
atom_expr [27437,27746]
atom_expr [27437,27746]
===
match
---
operator: @ [81028,81029]
operator: @ [81452,81453]
===
match
---
suite [49621,49686]
suite [49621,49686]
===
match
---
name: self [47249,47253]
name: self [47249,47253]
===
match
---
atom_expr [72127,72142]
atom_expr [72551,72566]
===
match
---
name: str [52817,52820]
name: str [53241,53244]
===
match
---
suite [71195,71239]
suite [71619,71663]
===
match
---
name: or_ [8673,8676]
name: or_ [8673,8676]
===
match
---
expr_stmt [13315,13340]
expr_stmt [13315,13340]
===
match
---
name: task_copy [49037,49046]
name: task_copy [49037,49046]
===
match
---
return_stmt [4358,4396]
return_stmt [4358,4396]
===
match
---
name: ignore_ti_state [39469,39484]
name: ignore_ti_state [39469,39484]
===
match
---
trailer [27491,27746]
trailer [27491,27746]
===
match
---
atom_expr [76185,76230]
atom_expr [76609,76654]
===
match
---
name: job_id [53616,53622]
name: job_id [54040,54046]
===
match
---
suite [12981,13075]
suite [12981,13075]
===
match
---
simple_stmt [44885,44906]
simple_stmt [44885,44906]
===
match
---
simple_stmt [15104,15128]
simple_stmt [15104,15128]
===
match
---
operator: = [82145,82146]
operator: = [82569,82570]
===
match
---
atom_expr [7666,7688]
atom_expr [7666,7688]
===
match
---
simple_stmt [24890,24920]
simple_stmt [24890,24920]
===
match
---
suite [80185,80215]
suite [80609,80639]
===
match
---
suite [3499,4040]
suite [3499,4040]
===
match
---
simple_stmt [20867,21124]
simple_stmt [20867,21124]
===
match
---
atom_expr [57335,57358]
atom_expr [57759,57782]
===
match
---
name: AirflowException [66802,66818]
name: AirflowException [67226,67242]
===
match
---
name: ignore_task_deps [53139,53155]
name: ignore_task_deps [53563,53579]
===
match
---
simple_stmt [58430,58457]
simple_stmt [58854,58881]
===
match
---
name: dag [58873,58876]
name: dag [59297,59300]
===
match
---
string: "Updating task params (%s) with DagRun.conf (%s)" [67103,67152]
string: "Updating task params (%s) with DagRun.conf (%s)" [67527,67576]
===
match
---
name: error [4596,4601]
name: error [4596,4601]
===
match
---
name: relationship [12151,12163]
name: relationship [12151,12163]
===
match
---
expr_stmt [13287,13306]
expr_stmt [13287,13306]
===
match
---
name: incr [46953,46957]
name: incr [46953,46957]
===
match
---
atom_expr [36437,36462]
atom_expr [36437,36462]
===
match
---
name: execution_date [12998,13012]
name: execution_date [12998,13012]
===
match
---
param [32702,32707]
param [32702,32707]
===
match
---
simple_stmt [47898,47921]
simple_stmt [47898,47921]
===
match
---
trailer [78643,78650]
trailer [79067,79074]
===
match
---
atom_expr [76219,76229]
atom_expr [76643,76653]
===
match
---
name: current_time [26242,26254]
name: current_time [26242,26254]
===
match
---
name: pod_mutation_hook [68331,68348]
name: pod_mutation_hook [68755,68772]
===
match
---
operator: , [9893,9894]
operator: , [9893,9894]
===
match
---
tfpdef [77140,77193]
tfpdef [77564,77617]
===
match
---
simple_stmt [28857,28901]
simple_stmt [28857,28901]
===
match
---
atom_expr [60926,60952]
atom_expr [61350,61376]
===
match
---
expr_stmt [13175,13231]
expr_stmt [13175,13231]
===
match
---
name: self [35642,35646]
name: self [35642,35646]
===
match
---
name: raw [16925,16928]
name: raw [16925,16928]
===
match
---
name: self [54118,54122]
name: self [54542,54546]
===
match
---
name: fd [4062,4064]
name: fd [4062,4064]
===
match
---
atom_expr [76124,76154]
atom_expr [76548,76578]
===
match
---
operator: , [26155,26156]
operator: , [26155,26156]
===
match
---
name: handle_failure [55166,55180]
name: handle_failure [55590,55604]
===
match
---
name: DagRun [82106,82112]
name: DagRun [82530,82536]
===
match
---
name: merge [22228,22233]
name: merge [22228,22233]
===
match
---
expr_stmt [55950,55966]
expr_stmt [56374,56390]
===
match
---
name: macros [63963,63969]
name: macros [64387,64393]
===
match
---
suite [34692,34793]
suite [34692,34793]
===
match
---
name: hr_line_break [39651,39664]
name: hr_line_break [39651,39664]
===
match
---
expr_stmt [60416,60457]
expr_stmt [60840,60881]
===
match
---
name: data [4322,4326]
name: data [4322,4326]
===
match
---
if_stmt [42586,42636]
if_stmt [42586,42636]
===
match
---
name: TaskInstance [82118,82130]
name: TaskInstance [82542,82554]
===
match
---
atom_expr [16360,16378]
atom_expr [16360,16378]
===
match
---
name: v [48528,48529]
name: v [48528,48529]
===
match
---
name: dag_id [8720,8726]
name: dag_id [8720,8726]
===
match
---
trailer [55999,56006]
trailer [56423,56430]
===
match
---
trailer [66576,66599]
trailer [67000,67023]
===
match
---
trailer [9018,9025]
trailer [9018,9025]
===
match
---
name: session [53361,53368]
name: session [53785,53792]
===
match
---
trailer [31807,31811]
trailer [31807,31811]
===
match
---
operator: , [65198,65199]
operator: , [65622,65623]
===
match
---
import_from [2491,2525]
import_from [2491,2525]
===
match
---
trailer [27455,27461]
trailer [27455,27461]
===
match
---
name: context [52118,52125]
name: context [52260,52267]
===
match
---
atom_expr [68272,68301]
atom_expr [68696,68725]
===
match
---
operator: , [48385,48386]
operator: , [48385,48386]
===
match
---
trailer [42144,42150]
trailer [42144,42150]
===
match
---
name: error_file [53674,53684]
name: error_file [54098,54108]
===
match
---
parameters [9470,9476]
parameters [9470,9476]
===
match
---
name: deserialize_json [62449,62465]
name: deserialize_json [62873,62889]
===
match
---
name: ti [21790,21792]
name: ti [21790,21792]
===
match
---
number: 1 [49859,49860]
number: 1 [49859,49860]
===
match
---
operator: = [16977,16978]
operator: = [16977,16978]
===
match
---
strings [20899,21113]
strings [20899,21113]
===
match
---
atom_expr [59930,59978]
atom_expr [60354,60402]
===
match
---
operator: { [20654,20655]
operator: { [20654,20655]
===
match
---
name: task_ids [7452,7460]
name: task_ids [7452,7460]
===
match
---
atom_expr [7884,7944]
atom_expr [7884,7944]
===
match
---
operator: , [55350,55351]
operator: , [55774,55775]
===
match
---
expr_stmt [66513,66599]
expr_stmt [66937,67023]
===
match
---
name: prev_ds [60264,60271]
name: prev_ds [60688,60695]
===
match
---
param [24349,24354]
param [24349,24354]
===
match
---
simple_stmt [21204,21486]
simple_stmt [21204,21486]
===
match
---
suite [26538,26799]
suite [26538,26799]
===
match
---
name: str [55217,55220]
name: str [55641,55644]
===
match
---
param [24343,24348]
param [24343,24348]
===
match
---
import_from [65414,65484]
import_from [65838,65908]
===
match
---
name: update [70709,70715]
name: update [71133,71139]
===
match
---
simple_stmt [21951,22114]
simple_stmt [21951,22114]
===
match
---
trailer [45019,45026]
trailer [45019,45026]
===
match
---
name: bool [52630,52634]
name: bool [53054,53058]
===
match
---
operator: , [57815,57816]
operator: , [58239,58240]
===
match
---
operator: , [76915,76916]
operator: , [77339,77340]
===
match
---
name: info [43308,43312]
name: info [43308,43312]
===
match
---
name: get_previous_ti [27856,27871]
name: get_previous_ti [27856,27871]
===
match
---
trailer [19646,19653]
trailer [19646,19653]
===
match
---
simple_stmt [39185,39234]
simple_stmt [39185,39234]
===
match
---
operator: , [29639,29640]
operator: , [29639,29640]
===
match
---
simple_stmt [52118,52156]
simple_stmt [52260,52298]
===
match
---
funcdef [51443,52480]
funcdef [51443,52904]
===
match
---
operator: , [60680,60681]
operator: , [61104,61105]
===
match
---
expr_stmt [35363,35445]
expr_stmt [35363,35445]
===
match
---
name: start_date [26440,26450]
name: start_date [26440,26450]
===
match
---
suite [28502,28770]
suite [28502,28770]
===
match
---
name: executor_config [24956,24971]
name: executor_config [24956,24971]
===
match
---
except_clause [45415,45454]
except_clause [45415,45454]
===
match
---
trailer [27725,27733]
trailer [27725,27733]
===
match
---
trailer [58876,58883]
trailer [59300,59307]
===
match
---
name: reason [33866,33872]
name: reason [33866,33872]
===
match
---
annassign [79476,79502]
annassign [79900,79926]
===
match
---
name: prepare_for_execution [47499,47520]
name: prepare_for_execution [47499,47520]
===
match
---
trailer [20540,20544]
trailer [20540,20544]
===
match
---
name: getLogger [12602,12611]
name: getLogger [12602,12611]
===
match
---
trailer [26423,26432]
trailer [26423,26432]
===
match
---
name: STATICA_HACK [81940,81952]
name: STATICA_HACK [82364,82376]
===
match
---
name: queued_dttm [42083,42094]
name: queued_dttm [42083,42094]
===
match
---
operator: , [1894,1895]
operator: , [1894,1895]
===
match
---
operator: = [29757,29758]
operator: = [29757,29758]
===
match
---
operator: = [75729,75730]
operator: = [76153,76154]
===
match
---
expr_stmt [59269,59340]
expr_stmt [59693,59764]
===
match
---
operator: == [78240,78242]
operator: == [78664,78666]
===
match
---
if_stmt [55447,55508]
if_stmt [55871,55932]
===
match
---
arglist [24281,24314]
arglist [24281,24314]
===
match
---
expr_stmt [77596,77617]
expr_stmt [78020,78041]
===
match
---
trailer [10732,10784]
trailer [10732,10784]
===
match
---
simple_stmt [48784,48826]
simple_stmt [48784,48826]
===
match
---
operator: = [62897,62898]
operator: = [63321,63322]
===
match
---
suite [75546,75580]
suite [75970,76004]
===
match
---
arglist [49185,49338]
arglist [49185,49338]
===
match
---
name: try_number [70069,70079]
name: try_number [70493,70503]
===
match
---
simple_stmt [3028,3079]
simple_stmt [3028,3079]
===
match
---
name: str [73706,73709]
name: str [74130,74133]
===
match
---
name: try_number [14488,14498]
name: try_number [14488,14498]
===
match
---
operator: , [25061,25062]
operator: , [25061,25062]
===
match
---
name: self [71925,71929]
name: self [72349,72353]
===
match
---
name: dag_id [8710,8716]
name: dag_id [8710,8716]
===
match
---
name: state [31322,31327]
name: state [31322,31327]
===
match
---
operator: , [8726,8727]
operator: , [8726,8727]
===
match
---
operator: , [43268,43269]
operator: , [43268,43269]
===
match
---
comparison [78313,78342]
comparison [78737,78766]
===
match
---
name: _run_execute_callback [51112,51133]
name: _run_execute_callback [51112,51133]
===
match
---
name: items [7681,7686]
name: items [7681,7686]
===
match
---
name: DeprecationWarning [8196,8214]
name: DeprecationWarning [8196,8214]
===
match
---
name: environ [48605,48612]
name: environ [48605,48612]
===
match
---
name: Any [79663,79666]
name: Any [80087,80090]
===
match
---
simple_stmt [43125,43178]
simple_stmt [43125,43178]
===
match
---
name: bool [52546,52550]
name: bool [52970,52974]
===
match
---
simple_stmt [79093,79145]
simple_stmt [79517,79569]
===
match
---
name: execute [50869,50876]
name: execute [50869,50876]
===
match
---
dotted_name [2145,2164]
dotted_name [2145,2164]
===
match
---
trailer [54518,54789]
trailer [54942,55213]
===
match
---
name: Proxy [64524,64529]
name: Proxy [64948,64953]
===
match
---
operator: = [41581,41582]
operator: = [41581,41582]
===
match
---
atom_expr [26298,26308]
atom_expr [26298,26308]
===
match
---
param [43874,43903]
param [43874,43903]
===
match
---
name: self [59284,59288]
name: self [59708,59712]
===
match
---
operator: , [64758,64759]
operator: , [65182,65183]
===
match
---
simple_stmt [3383,3428]
simple_stmt [3383,3428]
===
match
---
atom_expr [54445,54464]
atom_expr [54869,54888]
===
match
---
if_stmt [81937,82169]
if_stmt [82361,82593]
===
match
---
name: expected_state [3767,3781]
name: expected_state [3767,3781]
===
match
---
for_stmt [34209,34668]
for_stmt [34209,34668]
===
match
---
import_from [1217,1274]
import_from [1217,1274]
===
match
---
fstring [20596,20668]
fstring [20596,20668]
===
match
---
operator: = [40098,40099]
operator: = [40098,40099]
===
match
---
name: dill [11604,11608]
name: dill [11604,11608]
===
match
---
arglist [15963,15979]
arglist [15963,15979]
===
match
---
trailer [76943,76950]
trailer [77367,77374]
===
match
---
trailer [34288,34305]
trailer [34288,34305]
===
match
---
name: _run_finished_callback [53897,53919]
name: _run_finished_callback [54321,54343]
===
match
---
name: task [63736,63740]
name: task [64160,64164]
===
match
---
name: dr [29601,29603]
name: dr [29601,29603]
===
match
---
fstring_string: . [47970,47971]
fstring_string: . [47970,47971]
===
match
---
name: start_date [56303,56313]
name: start_date [56727,56737]
===
match
---
name: jinja_env [71262,71271]
name: jinja_env [71686,71695]
===
match
---
name: self [35663,35667]
name: self [35663,35667]
===
match
---
name: e [46720,46721]
name: e [46720,46721]
===
match
---
name: airflow [1963,1970]
name: airflow [1963,1970]
===
match
---
name: _priority_weight [79869,79885]
name: _priority_weight [80293,80309]
===
match
---
comparison [77927,77961]
comparison [78351,78385]
===
match
---
argument [62449,62470]
argument [62873,62894]
===
match
---
name: State [64590,64595]
name: State [65014,65019]
===
match
---
atom_expr [57110,57128]
atom_expr [57534,57552]
===
match
---
trailer [27652,27667]
trailer [27652,27667]
===
match
---
name: e [45482,45483]
name: e [45482,45483]
===
match
---
atom_expr [64506,64618]
atom_expr [64930,65042]
===
match
---
atom_expr [35391,35412]
atom_expr [35391,35412]
===
match
---
arglist [58600,58611]
arglist [59024,59035]
===
match
---
param [12385,12412]
param [12385,12412]
===
match
---
operator: = [66531,66532]
operator: = [66955,66956]
===
match
---
string: 'ti_state_lkp' [11979,11993]
string: 'ti_state_lkp' [11979,11993]
===
match
---
simple_stmt [34159,34201]
simple_stmt [34159,34201]
===
match
---
dotted_name [2326,2353]
dotted_name [2326,2353]
===
match
---
param [51476,51521]
param [51476,51521]
===
match
---
atom_expr [27796,27825]
atom_expr [27796,27825]
===
match
---
suite [33643,33888]
suite [33643,33888]
===
match
---
name: self [37200,37204]
name: self [37200,37204]
===
match
---
atom_expr [7254,7271]
atom_expr [7254,7271]
===
match
---
trailer [24081,24085]
trailer [24081,24085]
===
match
---
operator: = [60664,60665]
operator: = [61088,61089]
===
match
---
atom_expr [60901,60912]
atom_expr [61325,61336]
===
match
---
name: sanitized_pod [68437,68450]
name: sanitized_pod [68861,68874]
===
match
---
atom_expr [68085,68105]
atom_expr [68509,68529]
===
match
---
operator: = [10931,10932]
operator: = [10931,10932]
===
match
---
name: DagRun [37081,37087]
name: DagRun [37081,37087]
===
match
---
trailer [40771,40773]
trailer [40771,40773]
===
match
---
name: self [62564,62568]
name: self [62988,62992]
===
match
---
name: run_id [58989,58995]
name: run_id [59413,59419]
===
match
---
trailer [60554,60562]
trailer [60978,60986]
===
match
---
operator: = [52357,52358]
operator: = [52641,52642]
===
match
---
name: command_as_list [15257,15272]
name: command_as_list [15257,15272]
===
match
---
operator: , [46721,46722]
operator: , [46721,46722]
===
match
---
simple_stmt [72215,72272]
simple_stmt [72639,72696]
===
match
---
parameters [21921,21941]
parameters [21921,21941]
===
match
---
argument [45742,45762]
argument [45742,45762]
===
match
---
trailer [42294,42298]
trailer [42294,42298]
===
match
---
name: self [60592,60596]
name: self [61016,61020]
===
match
---
name: task [47494,47498]
name: task [47494,47498]
===
match
---
trailer [13145,13161]
trailer [13145,13161]
===
match
---
simple_stmt [67188,67216]
simple_stmt [67612,67640]
===
match
---
atom_expr [81667,81694]
atom_expr [82091,82118]
===
match
---
name: AttributeError [28793,28807]
name: AttributeError [28793,28807]
===
match
---
decorated [13902,14482]
decorated [13902,14482]
===
match
---
trailer [39540,39570]
trailer [39540,39570]
===
match
---
suite [5462,6636]
suite [5462,6636]
===
match
---
expr_stmt [52265,52281]
expr_stmt [52549,52565]
===
match
---
operator: , [68799,68800]
operator: , [69223,69224]
===
match
---
operator: = [29543,29544]
operator: = [29543,29544]
===
match
---
suite [63632,63673]
suite [64056,64097]
===
match
---
atom_expr [26223,26238]
atom_expr [26223,26238]
===
match
---
name: UP_FOR_RETRY [36757,36769]
name: UP_FOR_RETRY [36757,36769]
===
match
---
argument [61090,61105]
argument [61514,61529]
===
match
---
name: ti [80033,80035]
name: ti [80457,80459]
===
match
---
name: session [57534,57541]
name: session [57958,57965]
===
match
---
trailer [78526,78534]
trailer [78950,78958]
===
match
---
name: self [39185,39189]
name: self [39185,39189]
===
match
---
comparison [78207,78225]
comparison [78631,78649]
===
match
---
atom_expr [51719,51729]
atom_expr [51719,51729]
===
match
---
name: delete_qry [7785,7795]
name: delete_qry [7785,7795]
===
match
---
simple_stmt [10679,10711]
simple_stmt [10679,10711]
===
match
---
name: session [44984,44991]
name: session [44984,44991]
===
match
---
trailer [76907,76915]
trailer [77331,77339]
===
match
---
atom_expr [77198,77225]
atom_expr [77622,77649]
===
match
---
operator: , [34096,34097]
operator: , [34096,34097]
===
match
---
operator: @ [43717,43718]
operator: @ [43717,43718]
===
match
---
name: execution_date [78936,78950]
name: execution_date [79360,79374]
===
match
---
name: set_error_file [55907,55921]
name: set_error_file [56331,56345]
===
match
---
name: Column [11304,11310]
name: Column [11304,11310]
===
match
---
name: rendered_value [65650,65664]
name: rendered_value [66074,66088]
===
match
---
comparison [76826,76862]
comparison [77250,77286]
===
match
---
name: task_id [76855,76862]
name: task_id [77279,77286]
===
match
---
trailer [57053,57070]
trailer [57477,57494]
===
match
---
atom_expr [55013,55032]
atom_expr [55437,55456]
===
match
---
comparison [58248,58281]
comparison [58672,58705]
===
match
---
operator: , [65296,65297]
operator: , [65720,65721]
===
match
---
trailer [60745,60753]
trailer [61169,61177]
===
match
---
operator: = [37454,37455]
operator: = [37454,37455]
===
match
---
name: _run_finished_callback [57891,57913]
name: _run_finished_callback [58315,58337]
===
match
---
name: params [61075,61081]
name: params [61499,61505]
===
match
---
atom_expr [23311,23322]
atom_expr [23311,23322]
===
match
---
operator: @ [25562,25563]
operator: @ [25562,25563]
===
match
---
trailer [40742,40753]
trailer [40742,40753]
===
match
---
suite [26331,26468]
suite [26331,26468]
===
match
---
operator: , [45305,45306]
operator: , [45305,45306]
===
match
---
simple_stmt [63682,65308]
simple_stmt [64106,65732]
===
match
---
name: f [71230,71231]
name: f [71654,71655]
===
match
---
arglist [8703,8760]
arglist [8703,8760]
===
match
---
trailer [73316,73353]
trailer [73740,73777]
===
match
---
name: exception [69987,69996]
name: exception [70411,70420]
===
match
---
operator: , [52886,52887]
operator: , [53310,53311]
===
match
---
name: base_worker_pod [68220,68235]
name: base_worker_pod [68644,68659]
===
match
---
tfpdef [27916,27932]
tfpdef [27916,27932]
===
match
---
name: ID_LEN [10740,10746]
name: ID_LEN [10740,10746]
===
match
---
tfpdef [4435,4463]
tfpdef [4435,4463]
===
match
---
funcdef [49926,50310]
funcdef [49926,50310]
===
match
---
name: execution_date [20489,20503]
name: execution_date [20489,20503]
===
match
---
trailer [46428,46444]
trailer [46428,46444]
===
match
---
operator: , [71635,71636]
operator: , [72059,72060]
===
match
---
trailer [59208,59223]
trailer [59632,59647]
===
match
---
atom_expr [52403,52423]
atom_expr [52687,52707]
===
match
---
name: str [9191,9194]
name: str [9191,9194]
===
match
---
name: task_id [48224,48231]
name: task_id [48224,48231]
===
match
---
operator: , [34319,34320]
operator: , [34319,34320]
===
match
---
name: dag_id [78631,78637]
name: dag_id [79055,79061]
===
match
---
name: test_mode [55450,55459]
name: test_mode [55874,55883]
===
match
---
name: ignore_all_deps [53051,53066]
name: ignore_all_deps [53475,53490]
===
match
---
trailer [41548,41569]
trailer [41548,41569]
===
match
---
operator: = [13124,13125]
operator: = [13124,13125]
===
match
---
name: Session [27925,27932]
name: Session [27925,27932]
===
match
---
name: is_subdag [16187,16196]
name: is_subdag [16187,16196]
===
match
---
atom_expr [7769,7796]
atom_expr [7769,7796]
===
match
---
name: get_template_context [58312,58332]
name: get_template_context [58736,58756]
===
match
---
operator: -> [9748,9750]
operator: -> [9748,9750]
===
match
---
trailer [52952,52992]
trailer [53376,53416]
===
match
---
parameters [12346,12413]
parameters [12346,12413]
===
match
---
trailer [68248,68271]
trailer [68672,68695]
===
match
---
trailer [55979,55988]
trailer [56403,56412]
===
match
---
operator: = [60155,60156]
operator: = [60579,60580]
===
match
---
name: dep_status [34612,34622]
name: dep_status [34612,34622]
===
match
---
suite [66633,66885]
suite [67057,67309]
===
match
---
trailer [39349,39356]
trailer [39349,39356]
===
match
---
name: State [42535,42540]
name: State [42535,42540]
===
match
---
trailer [79967,79984]
trailer [80391,80408]
===
match
---
trailer [56050,56055]
trailer [56474,56479]
===
match
---
operator: == [58039,58041]
operator: == [58463,58465]
===
match
---
atom_expr [64128,64140]
atom_expr [64552,64564]
===
match
---
name: _task_id [80206,80214]
name: _task_id [80630,80638]
===
match
---
operator: = [59724,59725]
operator: = [60148,60149]
===
match
---
operator: , [36321,36322]
operator: , [36321,36322]
===
match
---
trailer [65697,65703]
trailer [66121,66127]
===
match
---
trailer [65735,65740]
trailer [66159,66164]
===
match
---
operator: , [73431,73432]
operator: , [73855,73856]
===
match
---
argument [8698,8826]
argument [8698,8826]
===
match
---
simple_stmt [13620,13637]
simple_stmt [13620,13637]
===
match
---
funcdef [34798,36563]
funcdef [34798,36563]
===
match
---
operator: , [52527,52528]
operator: , [52951,52952]
===
match
---
name: self [40893,40897]
name: self [40893,40897]
===
match
---
suite [3219,3241]
suite [3219,3241]
===
match
---
atom_expr [22248,22264]
atom_expr [22248,22264]
===
match
---
operator: , [12930,12931]
operator: , [12930,12931]
===
match
---
comp_op [8013,8019]
comp_op [8013,8019]
===
match
---
trailer [76892,76898]
trailer [77316,77322]
===
match
---
param [4880,4889]
param [4880,4889]
===
match
---
trailer [9397,9404]
trailer [9397,9404]
===
match
---
simple_stmt [34352,34588]
simple_stmt [34352,34588]
===
match
---
argument [67782,67802]
argument [68206,68226]
===
match
---
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.json.variable_name }}`` or             ``{{ var.json.get('variable_name', {'fall': 'back'}) }}``.             """ [62015,62243]
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.json.variable_name }}`` or             ``{{ var.json.get('variable_name', {'fall': 'back'}) }}``.             """ [62439,62667]
===
match
---
string: """Key used to identify task instance.""" [9119,9160]
string: """Key used to identify task instance.""" [9119,9160]
===
match
---
trailer [41569,41625]
trailer [41569,41625]
===
match
---
name: models [58718,58724]
name: models [59142,59148]
===
match
---
name: execution_date [73322,73336]
name: execution_date [73746,73760]
===
match
---
suite [13358,13390]
suite [13358,13390]
===
match
---
name: ts [60666,60668]
name: ts [61090,61092]
===
match
---
return_stmt [42200,42212]
return_stmt [42200,42212]
===
match
---
trailer [57913,57926]
trailer [58337,58350]
===
match
---
name: Column [1298,1304]
name: Column [1298,1304]
===
match
---
name: Session [78514,78521]
name: Session [78938,78945]
===
match
---
trailer [11595,11609]
trailer [11595,11609]
===
match
---
operator: = [36376,36377]
operator: = [36376,36377]
===
match
---
dotted_name [2881,2905]
dotted_name [2881,2905]
===
match
---
trailer [27703,27735]
trailer [27703,27735]
===
match
---
name: tis [4830,4833]
name: tis [4830,4833]
===
match
---
name: conf [20825,20829]
name: conf [20825,20829]
===
match
---
name: conf [60965,60969]
name: conf [61389,61393]
===
match
---
simple_stmt [19876,19914]
simple_stmt [19876,19914]
===
match
---
operator: -> [80514,80516]
operator: -> [80938,80940]
===
match
---
name: SIGTERM [47800,47807]
name: SIGTERM [47800,47807]
===
match
---
name: dag_id [73479,73485]
name: dag_id [73903,73909]
===
match
---
expr_stmt [4231,4247]
expr_stmt [4231,4247]
===
match
---
operator: , [51138,51139]
operator: , [51138,51139]
===
match
---
name: self [81001,81005]
name: self [81425,81429]
===
match
---
or_test [29362,29412]
or_test [29362,29412]
===
match
---
argument [78592,78825]
argument [79016,79249]
===
match
---
trailer [70658,70679]
trailer [71082,71103]
===
match
---
name: str [52853,52856]
name: str [53277,53280]
===
match
---
atom_expr [40789,40799]
atom_expr [40789,40799]
===
match
---
trailer [35632,35640]
trailer [35632,35640]
===
match
---
simple_stmt [51540,51708]
simple_stmt [51540,51708]
===
match
---
name: handle_failure [46705,46719]
name: handle_failure [46705,46719]
===
match
---
name: deserialize_value [76490,76507]
name: deserialize_value [76914,76931]
===
match
---
operator: = [57848,57849]
operator: = [58272,58273]
===
match
---
simple_stmt [60140,60182]
simple_stmt [60564,60606]
===
match
---
operator: -> [80259,80261]
operator: -> [80683,80685]
===
match
---
simple_stmt [1428,1471]
simple_stmt [1428,1471]
===
match
---
name: self [79361,79365]
name: self [79785,79789]
===
match
---
operator: , [71441,71442]
operator: , [71865,71866]
===
match
---
dictorsetmaker [65066,65142]
dictorsetmaker [65490,65566]
===
match
---
name: and_ [1349,1353]
name: and_ [1349,1353]
===
match
---
name: airflow [2145,2152]
name: airflow [2145,2152]
===
match
---
funcdef [61390,61442]
funcdef [61814,61866]
===
match
---
parameters [73643,73876]
parameters [74067,74300]
===
match
---
import_from [2673,2715]
import_from [2673,2715]
===
match
---
expr_stmt [19485,19540]
expr_stmt [19485,19540]
===
match
---
name: session [47264,47271]
name: session [47264,47271]
===
match
---
operator: = [37648,37649]
operator: = [37648,37649]
===
match
---
simple_stmt [63653,63673]
simple_stmt [64077,64097]
===
match
---
suite [20318,20368]
suite [20318,20368]
===
match
---
name: SENSING [50070,50077]
name: SENSING [50070,50077]
===
match
---
string: """             Wrapper around Connection. This way you can get connections in             templates by using ``{{ conn.conn_id }}`` or             ``{{ conn.get('conn_id') }}``.             """ [62951,63145]
string: """             Wrapper around Connection. This way you can get connections in             templates by using ``{{ conn.conn_id }}`` or             ``{{ conn.get('conn_id') }}``.             """ [63375,63569]
===
match
---
name: VariableAccessor [65123,65139]
name: VariableAccessor [65547,65563]
===
match
---
suite [62276,62309]
suite [62700,62733]
===
match
---
name: Exception [55560,55569]
name: Exception [55984,55993]
===
match
---
trailer [43626,43641]
trailer [43626,43641]
===
match
---
trailer [6404,6443]
trailer [6404,6443]
===
match
---
operator: , [4833,4834]
operator: , [4833,4834]
===
match
---
simple_stmt [6386,6444]
simple_stmt [6386,6444]
===
match
---
operator: , [61757,61758]
operator: , [62181,62182]
===
match
---
operator: , [35746,35747]
operator: , [35746,35747]
===
match
---
name: Exception [49112,49121]
name: Exception [49112,49121]
===
match
---
name: get_template_context [45213,45233]
name: get_template_context [45213,45233]
===
match
---
name: ti [79848,79850]
name: ti [80272,80274]
===
match
---
trailer [30971,30990]
trailer [30971,30990]
===
match
---
operator: , [11867,11868]
operator: , [11867,11868]
===
match
---
if_stmt [52294,52480]
if_stmt [52578,52904]
===
match
---
name: ti [6419,6421]
name: ti [6419,6421]
===
match
---
atom_expr [8465,8481]
atom_expr [8465,8481]
===
match
---
decorator [31420,31437]
decorator [31420,31437]
===
match
---
atom_expr [27705,27718]
atom_expr [27705,27718]
===
match
---
arglist [10812,10836]
arglist [10812,10836]
===
match
---
simple_stmt [49024,49089]
simple_stmt [49024,49089]
===
match
---
name: IO [1037,1039]
name: IO [1037,1039]
===
match
---
name: test_mode [57671,57680]
name: test_mode [58095,58104]
===
match
---
import_from [2255,2288]
import_from [2255,2288]
===
match
---
name: ti [23666,23668]
name: ti [23666,23668]
===
match
---
trailer [39246,39256]
trailer [39246,39256]
===
match
---
name: dag [16294,16297]
name: dag [16294,16297]
===
match
---
name: self [57097,57101]
name: self [57521,57525]
===
match
---
name: State [14395,14400]
name: State [14395,14400]
===
match
---
simple_stmt [45012,45029]
simple_stmt [45012,45029]
===
match
---
name: state [23380,23385]
name: state [23380,23385]
===
match
---
simple_stmt [33942,34000]
simple_stmt [33942,34000]
===
match
---
name: airflow [2788,2795]
name: airflow [2788,2795]
===
match
---
operator: = [79901,79902]
operator: = [80325,80326]
===
match
---
trailer [78077,78092]
trailer [78501,78516]
===
match
---
name: TaskInstance [27681,27693]
name: TaskInstance [27681,27693]
===
match
---
operator: -> [58353,58355]
operator: -> [58777,58779]
===
match
---
argument [36388,36420]
argument [36388,36420]
===
match
---
simple_stmt [57886,57927]
simple_stmt [58310,58351]
===
match
---
name: raw [16929,16932]
name: raw [16929,16932]
===
match
---
expr_stmt [11052,11106]
expr_stmt [11052,11106]
===
match
---
trailer [61074,61106]
trailer [61498,61530]
===
match
---
with_item [4529,4557]
with_item [4529,4557]
===
match
---
name: execution_date [12709,12723]
name: execution_date [12709,12723]
===
match
---
string: """     Simplified Task Instance.      Used to send data between processes via Queues.     """ [79177,79271]
string: """     Simplified Task Instance.      Used to send data between processes via Queues.     """ [79601,79695]
===
match
---
name: lazy_object_proxy [64349,64366]
name: lazy_object_proxy [64773,64790]
===
match
---
if_stmt [3361,3428]
if_stmt [3361,3428]
===
match
---
atom_expr [64437,64450]
atom_expr [64861,64874]
===
match
---
atom_expr [82118,82144]
atom_expr [82542,82568]
===
match
---
name: __getattr__ [61459,61470]
name: __getattr__ [61883,61894]
===
match
---
simple_stmt [51031,51081]
simple_stmt [51031,51081]
===
match
---
atom_expr [61794,61833]
atom_expr [62218,62257]
===
match
---
string: 'BASE_URL' [20558,20568]
string: 'BASE_URL' [20558,20568]
===
match
---
name: hr_line_break [42392,42405]
name: hr_line_break [42392,42405]
===
match
---
name: Column [11578,11584]
name: Column [11578,11584]
===
match
---
name: isoformat [59168,59177]
name: isoformat [59592,59601]
===
match
---
operator: = [79846,79847]
operator: = [80270,80271]
===
match
---
funcdef [61627,61684]
funcdef [62051,62108]
===
match
---
name: all [7939,7942]
name: all [7939,7942]
===
match
---
suite [23188,24213]
suite [23188,24213]
===
match
---
name: rendered_k8s_spec [66900,66917]
name: rendered_k8s_spec [67324,67341]
===
match
---
name: ti [6624,6626]
name: ti [6624,6626]
===
match
---
name: exception [68776,68785]
name: exception [69200,69209]
===
match
---
if_stmt [8260,8320]
if_stmt [8260,8320]
===
match
---
name: airflow [2294,2301]
name: airflow [2294,2301]
===
match
---
name: _priority_weight [79968,79984]
name: _priority_weight [80392,80408]
===
match
---
simple_stmt [805,820]
simple_stmt [805,820]
===
match
---
parameters [68485,68502]
parameters [68909,68926]
===
match
---
arglist [7162,7618]
arglist [7162,7618]
===
match
---
simple_stmt [71716,71800]
simple_stmt [72140,72224]
===
match
---
operator: , [15377,15378]
operator: , [15377,15378]
===
match
---
trailer [58271,58281]
trailer [58695,58705]
===
match
---
atom_expr [23690,23703]
atom_expr [23690,23703]
===
match
---
simple_stmt [7769,7797]
simple_stmt [7769,7797]
===
match
---
name: self [62270,62274]
name: self [62694,62698]
===
match
---
simple_stmt [57405,57467]
simple_stmt [57829,57891]
===
match
---
operator: == [53803,53805]
operator: == [54227,54229]
===
match
---
simple_stmt [57031,57071]
simple_stmt [57455,57495]
===
match
---
simple_stmt [3142,3200]
simple_stmt [3142,3200]
===
match
---
simple_stmt [45325,45368]
simple_stmt [45325,45368]
===
match
---
trailer [27377,27397]
trailer [27377,27397]
===
match
---
operator: @ [9253,9254]
operator: @ [9253,9254]
===
match
---
operator: = [32733,32734]
operator: = [32733,32734]
===
match
---
trailer [31390,31414]
trailer [31390,31414]
===
match
---
atom_expr [68063,68106]
atom_expr [68487,68530]
===
match
---
operator: + [39672,39673]
operator: + [39672,39673]
===
match
---
name: str [62644,62647]
name: str [63068,63071]
===
match
---
operator: = [49972,49973]
operator: = [49972,49973]
===
match
---
name: RenderedTaskInstanceFields [48100,48126]
name: RenderedTaskInstanceFields [48100,48126]
===
match
---
import_from [3084,3137]
import_from [3084,3137]
===
match
---
name: error [55520,55525]
name: error [55944,55949]
===
match
---
trailer [20265,20272]
trailer [20265,20272]
===
match
---
trailer [34360,34366]
trailer [34360,34366]
===
match
---
atom_expr [36774,36800]
atom_expr [36774,36800]
===
match
---
trailer [48093,48099]
trailer [48093,48099]
===
match
---
trailer [9410,9418]
trailer [9410,9418]
===
match
---
arglist [55553,55569]
arglist [55977,55993]
===
match
---
atom_expr [45208,45235]
atom_expr [45208,45235]
===
match
---
argument [53080,53125]
argument [53504,53549]
===
match
---
if_stmt [39438,39571]
if_stmt [39438,39571]
===
match
---
name: self [49647,49651]
name: self [49647,49651]
===
match
---
simple_stmt [36480,36526]
simple_stmt [36480,36526]
===
match
---
name: error [57633,57638]
name: error [58057,58062]
===
match
---
operator: == [78756,78758]
operator: == [79180,79182]
===
match
---
trailer [43141,43159]
trailer [43141,43159]
===
match
---
trailer [67836,67863]
trailer [68260,68287]
===
match
---
name: str [73692,73695]
name: str [74116,74119]
===
match
---
name: session [44868,44875]
name: session [44868,44875]
===
match
---
operator: , [79294,79295]
operator: , [79718,79719]
===
match
---
param [52567,52597]
param [52991,53021]
===
match
---
name: airflow [2377,2384]
name: airflow [2377,2384]
===
match
---
name: self [13371,13375]
name: self [13371,13375]
===
match
---
if_stmt [79744,79822]
if_stmt [80168,80246]
===
match
---
operator: , [68152,68153]
operator: , [68576,68577]
===
match
---
suite [15173,15248]
suite [15173,15248]
===
match
---
name: strftime [60383,60391]
name: strftime [60807,60815]
===
match
---
string: """For API-compatibly with TaskInstance.          Returns self         """ [9991,10065]
string: """For API-compatibly with TaskInstance.          Returns self         """ [9991,10065]
===
match
---
simple_stmt [11291,11347]
simple_stmt [11291,11347]
===
match
---
name: self [24021,24025]
name: self [24021,24025]
===
match
---
parameters [55180,55379]
parameters [55604,55803]
===
match
---
not_test [39711,39727]
not_test [39711,39727]
===
match
---
simple_stmt [60540,60572]
simple_stmt [60964,60996]
===
match
---
atom_expr [81698,81718]
atom_expr [82122,82142]
===
match
---
name: self [28880,28884]
name: self [28880,28884]
===
match
---
name: self [57784,57788]
name: self [58208,58212]
===
match
---
atom_expr [11973,12034]
atom_expr [11973,12034]
===
match
---
simple_stmt [8372,8438]
simple_stmt [8372,8438]
===
match
---
name: task [52032,52036]
name: task [52174,52178]
===
match
---
name: task_id [6627,6634]
name: task_id [6627,6634]
===
match
---
operator: , [67863,67864]
operator: , [68287,68288]
===
match
---
operator: , [66966,66967]
operator: , [67390,67391]
===
match
---
operator: / [16421,16422]
operator: / [16421,16422]
===
match
---
trailer [42487,42513]
trailer [42487,42513]
===
match
---
operator: , [64304,64305]
operator: , [64728,64729]
===
match
---
trailer [72051,72060]
trailer [72475,72484]
===
match
---
name: UtcDateTime [11478,11489]
name: UtcDateTime [11478,11489]
===
match
---
operator: , [63423,63424]
operator: , [63847,63848]
===
match
---
trailer [49073,49088]
trailer [49073,49088]
===
match
---
name: self [68486,68490]
name: self [68910,68914]
===
match
---
name: job_ids [5351,5358]
name: job_ids [5351,5358]
===
match
---
operator: = [26416,26417]
operator: = [26416,26417]
===
match
---
name: Union [1112,1117]
name: Union [1112,1117]
===
match
---
operator: @ [37314,37315]
operator: @ [37314,37315]
===
match
---
atom_expr [78440,78460]
atom_expr [78864,78884]
===
match
---
operator: , [7380,7381]
operator: , [7380,7381]
===
match
---
tfpdef [72335,72343]
tfpdef [72759,72767]
===
match
---
atom_expr [72257,72270]
atom_expr [72681,72694]
===
match
---
name: self [57619,57623]
name: self [58043,58047]
===
match
---
name: current_time [26377,26389]
name: current_time [26377,26389]
===
match
---
trailer [8962,8973]
trailer [8962,8973]
===
match
---
testlist_comp [27705,27733]
testlist_comp [27705,27733]
===
match
---
operator: = [5383,5384]
operator: = [5383,5384]
===
match
---
name: SUCCESS [39509,39516]
name: SUCCESS [39509,39516]
===
match
---
trailer [12454,12461]
trailer [12454,12461]
===
match
---
trailer [29065,29069]
trailer [29065,29069]
===
match
---
arglist [76774,76916]
arglist [77198,77340]
===
match
---
suite [80834,80862]
suite [81258,81286]
===
match
---
name: get_hostname [44930,44942]
name: get_hostname [44930,44942]
===
match
---
name: dag_id [35620,35626]
name: dag_id [35620,35626]
===
match
---
name: external_executor_id [24166,24186]
name: external_executor_id [24166,24186]
===
match
---
name: render [70484,70490]
name: render [70908,70914]
===
match
---
operator: , [51474,51475]
operator: , [51474,51475]
===
match
---
simple_stmt [71396,71465]
simple_stmt [71820,71889]
===
match
---
name: signal_handler [47566,47580]
name: signal_handler [47566,47580]
===
match
---
name: dag_id [7165,7171]
name: dag_id [7165,7171]
===
match
---
name: first [58938,58943]
name: first [59362,59367]
===
match
---
name: conf [71131,71135]
name: conf [71555,71559]
===
match
---
atom_expr [65668,65705]
atom_expr [66092,66129]
===
match
---
expr_stmt [23766,23785]
expr_stmt [23766,23785]
===
match
---
name: state [42527,42532]
name: state [42527,42532]
===
match
---
tfpdef [9731,9746]
tfpdef [9731,9746]
===
match
---
atom_expr [30506,30753]
atom_expr [30506,30753]
===
match
---
atom_expr [65178,65198]
atom_expr [65602,65622]
===
match
---
trailer [19803,19834]
trailer [19803,19834]
===
match
---
return_stmt [20867,21123]
return_stmt [20867,21123]
===
match
---
string: 'next_execution_date' [64061,64082]
string: 'next_execution_date' [64485,64506]
===
match
---
trailer [23851,23857]
trailer [23851,23857]
===
match
---
atom_expr [55975,55988]
atom_expr [56399,56412]
===
match
---
name: state [11021,11026]
name: state [11021,11026]
===
match
---
trailer [51267,51287]
trailer [51267,51287]
===
match
---
trailer [56114,56119]
trailer [56538,56543]
===
match
---
name: content [71284,71291]
name: content [71708,71715]
===
match
---
operator: , [19501,19502]
operator: , [19501,19502]
===
match
---
param [57713,57738]
param [58137,58162]
===
match
---
trailer [37271,37277]
trailer [37271,37277]
===
match
---
trailer [76749,76756]
trailer [77173,77180]
===
match
---
parameters [62269,62275]
parameters [62693,62699]
===
match
---
param [43099,43104]
param [43099,43104]
===
match
---
operator: = [79729,79730]
operator: = [80153,80154]
===
match
---
atom_expr [34778,34788]
atom_expr [34778,34788]
===
match
---
trailer [25362,25369]
trailer [25362,25369]
===
match
---
atom_expr [21684,21711]
atom_expr [21684,21711]
===
match
---
operator: { [20618,20619]
operator: { [20618,20619]
===
match
---
trailer [6588,6603]
trailer [6588,6603]
===
match
---
suite [60064,60255]
suite [60488,60679]
===
match
---
expr_stmt [23730,23753]
expr_stmt [23730,23753]
===
match
---
name: task_id [20638,20645]
name: task_id [20638,20645]
===
match
---
name: exc_info [55633,55641]
name: exc_info [56057,56065]
===
match
---
trailer [57803,57877]
trailer [58227,58301]
===
match
---
operator: = [45757,45758]
operator: = [45757,45758]
===
match
---
simple_stmt [9845,9928]
simple_stmt [9845,9928]
===
match
---
trailer [3338,3348]
trailer [3338,3348]
===
match
---
arglist [11258,11285]
arglist [11258,11285]
===
match
---
trailer [20341,20367]
trailer [20341,20367]
===
match
---
subscriptlist [79123,79143]
subscriptlist [79547,79567]
===
match
---
dotted_name [7827,7848]
dotted_name [7827,7848]
===
match
---
atom_expr [20484,20515]
atom_expr [20484,20515]
===
match
---
simple_stmt [25860,26058]
simple_stmt [25860,26058]
===
match
---
operator: = [11576,11577]
operator: = [11576,11577]
===
match
---
name: should_pass_filepath [16146,16166]
name: should_pass_filepath [16146,16166]
===
match
---
param [37632,37656]
param [37632,37656]
===
match
---
atom_expr [42167,42183]
atom_expr [42167,42183]
===
match
---
name: task [28231,28235]
name: task [28231,28235]
===
match
---
string: 'priority_weight' [79931,79948]
string: 'priority_weight' [80355,80372]
===
match
---
param [17531,17558]
param [17531,17558]
===
match
---
trailer [39171,39176]
trailer [39171,39176]
===
match
---
operator: = [37746,37747]
operator: = [37746,37747]
===
match
---
arglist [9623,9698]
arglist [9623,9698]
===
match
---
trailer [59239,59248]
trailer [59663,59672]
===
match
---
name: State [26749,26754]
name: State [26749,26754]
===
match
---
return_stmt [78284,78492]
return_stmt [78708,78916]
===
match
---
operator: = [46343,46344]
operator: = [46343,46344]
===
match
---
trailer [33576,33600]
trailer [33576,33600]
===
match
---
simple_stmt [14422,14446]
simple_stmt [14422,14446]
===
match
---
name: context [52349,52356]
name: context [52633,52640]
===
match
---
name: task [58231,58235]
name: task [58655,58659]
===
match
---
name: log [41688,41691]
name: log [41688,41691]
===
match
---
name: Column [11432,11438]
name: Column [11432,11438]
===
match
---
name: html_content [71862,71874]
name: html_content [72286,72298]
===
match
---
trailer [63874,63883]
trailer [64298,64307]
===
match
---
number: 1 [36355,36356]
number: 1 [36355,36356]
===
match
---
operator: = [15308,15309]
operator: = [15308,15309]
===
match
---
tfpdef [52567,52588]
tfpdef [52991,53012]
===
match
---
name: session [1448,1455]
name: session [1448,1455]
===
match
---
simple_stmt [76340,76368]
simple_stmt [76764,76792]
===
match
---
operator: , [68029,68030]
operator: , [68453,68454]
===
match
---
name: self [56952,56956]
name: self [57376,57380]
===
match
---
funcdef [80881,80940]
funcdef [81305,81364]
===
match
---
name: Optional [51483,51491]
name: Optional [51483,51491]
===
match
---
simple_stmt [50086,50122]
simple_stmt [50086,50122]
===
match
---
operator: = [12316,12317]
operator: = [12316,12317]
===
match
---
string: 'execution_date' [43591,43607]
string: 'execution_date' [43591,43607]
===
match
---
atom_expr [5716,5732]
atom_expr [5716,5732]
===
match
---
atom_expr [76421,76431]
atom_expr [76845,76855]
===
match
---
operator: - [81916,81917]
operator: - [82340,82341]
===
match
---
atom_expr [20206,20227]
atom_expr [20206,20227]
===
match
---
name: provide_session [31421,31436]
name: provide_session [31421,31436]
===
match
---
atom_expr [54050,54078]
atom_expr [54474,54502]
===
match
---
param [71991,71995]
param [72415,72419]
===
match
---
name: running [14401,14408]
name: running [14401,14408]
===
match
---
operator: } [20622,20623]
operator: } [20622,20623]
===
match
---
simple_stmt [2976,3018]
simple_stmt [2976,3018]
===
match
---
name: TaskInstanceKey [9852,9867]
name: TaskInstanceKey [9852,9867]
===
match
---
operator: = [33417,33418]
operator: = [33417,33418]
===
match
---
operator: == [23021,23023]
operator: == [23021,23023]
===
match
---
simple_stmt [13175,13232]
simple_stmt [13175,13232]
===
match
---
simple_stmt [14547,14572]
simple_stmt [14547,14572]
===
match
---
trailer [43575,43590]
trailer [43575,43590]
===
match
---
trailer [66711,66713]
trailer [67135,67137]
===
match
---
name: self [43791,43795]
name: self [43791,43795]
===
match
---
simple_stmt [77551,77563]
simple_stmt [77975,77987]
===
match
---
arglist [78018,78177]
arglist [78442,78601]
===
match
---
if_stmt [19692,19753]
if_stmt [19692,19753]
===
match
---
trailer [67736,68313]
trailer [68160,68737]
===
match
---
operator: = [7121,7122]
operator: = [7121,7122]
===
match
---
trailer [20483,20516]
trailer [20483,20516]
===
match
---
arith_expr [39667,39684]
arith_expr [39667,39684]
===
match
---
suite [9769,9928]
suite [9769,9928]
===
match
---
name: __file__ [70286,70294]
name: __file__ [70710,70718]
===
match
---
name: bool [17471,17475]
name: bool [17471,17475]
===
match
---
name: __repr__ [62521,62529]
name: __repr__ [62945,62953]
===
match
---
atom_expr [31224,31276]
atom_expr [31224,31276]
===
match
---
suite [81819,81849]
suite [82243,82273]
===
match
---
operator: = [48152,48153]
operator: = [48152,48153]
===
match
---
expr_stmt [14547,14571]
expr_stmt [14547,14571]
===
match
---
atom_expr [79343,79352]
atom_expr [79767,79776]
===
match
---
simple_stmt [22371,22765]
simple_stmt [22371,22765]
===
match
---
comparison [7353,7380]
comparison [7353,7380]
===
match
---
name: provide_session [21892,21907]
name: provide_session [21892,21907]
===
match
---
operator: = [59846,59847]
operator: = [60270,60271]
===
match
---
name: self [16046,16050]
name: self [16046,16050]
===
match
---
name: contextmanager [3442,3456]
name: contextmanager [3442,3456]
===
match
---
name: self [13051,13055]
name: self [13051,13055]
===
match
---
expr_stmt [60580,60637]
expr_stmt [61004,61061]
===
match
---
param [27881,27886]
param [27881,27886]
===
match
---
string: '%Y-%m-%d' [59329,59339]
string: '%Y-%m-%d' [59753,59763]
===
match
---
name: commit [59071,59077]
name: commit [59495,59501]
===
match
---
trailer [17403,17408]
trailer [17403,17408]
===
match
---
name: execution_date [80238,80252]
name: execution_date [80662,80676]
===
match
---
trailer [49878,49883]
trailer [49878,49883]
===
match
---
operator: , [25467,25468]
operator: , [25467,25468]
===
match
---
name: pickle_id [16864,16873]
name: pickle_id [16864,16873]
===
match
---
name: TYPE_CHECKING [3364,3377]
name: TYPE_CHECKING [3364,3377]
===
match
---
atom_expr [58248,58263]
atom_expr [58672,58687]
===
match
---
simple_stmt [46005,46012]
simple_stmt [46005,46012]
===
match
---
atom_expr [9895,9914]
atom_expr [9895,9914]
===
match
---
operator: , [34568,34569]
operator: , [34568,34569]
===
match
---
name: debug [24275,24280]
name: debug [24275,24280]
===
match
---
operator: , [73336,73337]
operator: , [73760,73761]
===
match
---
operator: = [57697,57698]
operator: = [58121,58122]
===
match
---
expr_stmt [58566,58580]
expr_stmt [58990,59004]
===
match
---
decorator [58287,58304]
decorator [58711,58728]
===
match
---
name: ti_hash [35881,35888]
name: ti_hash [35881,35888]
===
match
---
name: dag [16183,16186]
name: dag [16183,16186]
===
match
---
name: in_ [7925,7928]
name: in_ [7925,7928]
===
match
---
trailer [8559,8584]
trailer [8559,8584]
===
match
---
trailer [11438,11452]
trailer [11438,11452]
===
match
---
name: dr [37122,37124]
name: dr [37122,37124]
===
match
---
name: _execution_date [81703,81718]
name: _execution_date [82127,82142]
===
match
---
arglist [12817,12931]
arglist [12817,12931]
===
match
---
name: self [35064,35068]
name: self [35064,35068]
===
match
---
decorated [25562,25779]
decorated [25562,25779]
===
match
---
trailer [33600,33642]
trailer [33600,33642]
===
match
---
tfpdef [37703,37722]
tfpdef [37703,37722]
===
match
---
atom_expr [32057,32075]
atom_expr [32057,32075]
===
match
---
fstring [66819,66876]
fstring [67243,67300]
===
match
---
atom [69048,69344]
atom [69472,69768]
===
match
---
operator: , [42919,42920]
operator: , [42919,42920]
===
match
---
trailer [55048,55055]
trailer [55472,55479]
===
match
---
suite [22362,24316]
suite [22362,24316]
===
match
---
trailer [3868,4039]
trailer [3868,4039]
===
match
---
name: render [70389,70395]
name: render [70813,70819]
===
match
---
suite [57493,57526]
suite [57917,57950]
===
match
---
name: XCom [25317,25321]
name: XCom [25317,25321]
===
match
---
operator: -> [80658,80660]
operator: -> [81082,81084]
===
match
---
decorator [9933,9943]
decorator [9933,9943]
===
match
---
trailer [71788,71799]
trailer [72212,72223]
===
match
---
name: provide_session [81029,81044]
name: provide_session [81453,81468]
===
match
---
expr_stmt [24699,24737]
expr_stmt [24699,24737]
===
match
---
operator: -> [80348,80350]
operator: -> [80772,80774]
===
match
---
trailer [58943,58945]
trailer [59367,59369]
===
match
---
name: pendulum [60492,60500]
name: pendulum [60916,60924]
===
match
---
atom_expr [26419,26432]
atom_expr [26419,26432]
===
match
---
name: dag [16040,16043]
name: dag [16040,16043]
===
match
---
operator: = [22845,22846]
operator: = [22845,22846]
===
match
---
name: pickle [4770,4776]
name: pickle [4770,4776]
===
match
---
operator: = [60272,60273]
operator: = [60696,60697]
===
match
---
operator: , [62854,62855]
operator: , [63278,63279]
===
match
---
if_stmt [14378,14446]
if_stmt [14378,14446]
===
match
---
trailer [76425,76431]
trailer [76849,76855]
===
match
---
trailer [22190,22196]
trailer [22190,22196]
===
match
---
name: ignore_ti_state [40043,40058]
name: ignore_ti_state [40043,40058]
===
match
---
subscriptlist [57646,57660]
subscriptlist [58070,58084]
===
match
---
atom_expr [81640,81653]
atom_expr [82064,82077]
===
match
---
operator: == [27645,27647]
operator: == [27645,27647]
===
match
---
name: _try_number [14552,14563]
name: _try_number [14552,14563]
===
match
---
string: '%Y-%m-%d' [59123,59133]
string: '%Y-%m-%d' [59547,59557]
===
match
---
atom_expr [6386,6398]
atom_expr [6386,6398]
===
match
---
name: self [30249,30253]
name: self [30249,30253]
===
match
---
expr_stmt [77672,77701]
expr_stmt [78096,78125]
===
match
---
testlist [71570,71609]
testlist [71994,72033]
===
match
---
name: registered [48964,48974]
name: registered [48964,48974]
===
match
---
name: self [36492,36496]
name: self [36492,36496]
===
match
---
atom_expr [11401,11416]
atom_expr [11401,11416]
===
match
---
param [37665,37694]
param [37665,37694]
===
match
---
name: iso [19444,19447]
name: iso [19444,19447]
===
match
---
simple_stmt [25618,25683]
simple_stmt [25618,25683]
===
match
---
atom_expr [49873,49899]
atom_expr [49873,49899]
===
match
---
string: "Failed to register in sensor service." [49185,49224]
string: "Failed to register in sensor service." [49185,49224]
===
match
---
trailer [42497,42505]
trailer [42497,42505]
===
match
---
trailer [51381,51385]
trailer [51381,51385]
===
match
---
name: do_xcom_push [50982,50994]
name: do_xcom_push [50982,50994]
===
match
---
simple_stmt [31860,31921]
simple_stmt [31860,31921]
===
match
---
param [79296,79312]
param [79720,79736]
===
match
---
operator: , [63223,63224]
operator: , [63647,63648]
===
match
---
name: dag_id [34731,34737]
name: dag_id [34731,34737]
===
match
---
trailer [42391,42406]
trailer [42391,42406]
===
match
---
name: job_id [52800,52806]
name: job_id [53224,53230]
===
match
---
name: airflow_context_vars [48544,48564]
name: airflow_context_vars [48544,48564]
===
match
---
trailer [22907,22914]
trailer [22907,22914]
===
match
---
trailer [71292,71299]
trailer [71716,71723]
===
match
---
atom_expr [72094,72107]
atom_expr [72518,72531]
===
match
---
trailer [71840,71845]
trailer [72264,72269]
===
match
---
param [15541,15551]
param [15541,15551]
===
match
---
suite [72463,73604]
suite [72887,74028]
===
match
---
name: pid [11534,11537]
name: pid [11534,11537]
===
match
---
suite [65706,65770]
suite [66130,66194]
===
match
---
argument [28958,28972]
argument [28958,28972]
===
match
---
name: self [55975,55979]
name: self [56399,56403]
===
match
---
argument [10898,10914]
argument [10898,10914]
===
match
---
trailer [76204,76230]
trailer [76628,76654]
===
match
---
name: dep_context [33613,33624]
name: dep_context [33613,33624]
===
match
---
name: pool [79851,79855]
name: pool [80275,80279]
===
match
---
trailer [47134,47147]
trailer [47134,47147]
===
match
---
arglist [11979,12033]
arglist [11979,12033]
===
match
---
suite [46934,47014]
suite [46934,47014]
===
match
---
string: "&downstream=false" [21065,21084]
string: "&downstream=false" [21065,21084]
===
match
---
name: execution_date [79437,79451]
name: execution_date [79861,79875]
===
match
---
name: session [56173,56180]
name: session [56597,56604]
===
match
---
atom_expr [54403,54416]
atom_expr [54827,54840]
===
match
---
tfpdef [17230,17258]
tfpdef [17230,17258]
===
match
---
expr_stmt [70520,70610]
expr_stmt [70944,71034]
===
match
---
simple_stmt [23650,23678]
simple_stmt [23650,23678]
===
match
---
atom_expr [19793,19834]
atom_expr [19793,19834]
===
match
---
funcdef [4042,4397]
funcdef [4042,4397]
===
match
---
trailer [54701,54710]
trailer [55125,55134]
===
match
---
operator: = [53588,53589]
operator: = [54012,54013]
===
match
---
atom_expr [49988,50042]
atom_expr [49988,50042]
===
match
---
decorator [54175,54192]
decorator [54599,54616]
===
match
---
return_stmt [80121,80140]
return_stmt [80545,80564]
===
match
---
name: str [68772,68775]
name: str [69196,69199]
===
match
---
name: Any [72360,72363]
name: Any [72784,72787]
===
match
---
atom_expr [31555,31572]
atom_expr [31555,31572]
===
match
---
operator: , [16825,16826]
operator: , [16825,16826]
===
match
---
atom_expr [78618,78637]
atom_expr [79042,79061]
===
match
---
atom_expr [79382,79392]
atom_expr [79806,79816]
===
match
---
operator: -> [27946,27948]
operator: -> [27946,27948]
===
match
---
trailer [55687,55691]
trailer [56111,56115]
===
match
---
trailer [69955,70164]
trailer [70379,70588]
===
match
---
operator: , [58337,58338]
operator: , [58761,58762]
===
match
---
trailer [81679,81694]
trailer [82103,82118]
===
match
---
expr_stmt [26178,26196]
expr_stmt [26178,26196]
===
match
---
name: self [64819,64823]
name: self [65243,65247]
===
match
---
name: value [14531,14536]
name: value [14531,14536]
===
match
---
name: self [71631,71635]
name: self [72055,72059]
===
match
---
number: 1 [6062,6063]
number: 1 [6062,6063]
===
match
---
operator: , [79929,79930]
operator: , [80353,80354]
===
match
---
fstring_string: <TaskInstance:  [34710,34725]
fstring_string: <TaskInstance:  [34710,34725]
===
match
---
name: dr [9043,9045]
name: dr [9043,9045]
===
match
---
name: self [42875,42879]
name: self [42875,42879]
===
match
---
name: airflow [2574,2581]
name: airflow [2574,2581]
===
match
---
name: verbose [52537,52544]
name: verbose [52961,52968]
===
match
---
fstring_string:  [ [34775,34777]
fstring_string:  [ [34775,34777]
===
match
---
param [3481,3497]
param [3481,3497]
===
match
---
sync_comp_for [78989,79002]
sync_comp_for [79413,79426]
===
match
---
operator: , [65740,65741]
operator: , [66164,66165]
===
match
---
simple_stmt [34837,35015]
simple_stmt [34837,35015]
===
match
---
factor [81916,81918]
factor [82340,82342]
===
match
---
param [37596,37623]
param [37596,37623]
===
match
---
name: staticmethod [61698,61710]
name: staticmethod [62122,62134]
===
match
---
trailer [42491,42512]
trailer [42491,42512]
===
match
---
operator: = [23386,23387]
operator: = [23386,23387]
===
match
---
name: context [67463,67470]
name: context [67887,67894]
===
match
---
operator: = [52270,52271]
operator: = [52554,52555]
===
match
---
simple_stmt [54118,54142]
simple_stmt [54542,54566]
===
match
---
trailer [51795,51815]
trailer [51795,51815]
===
match
---
simple_stmt [59988,60003]
simple_stmt [60412,60427]
===
match
---
operator: = [11121,11122]
operator: = [11121,11122]
===
match
---
operator: , [17145,17146]
operator: , [17145,17146]
===
match
---
name: session [7884,7891]
name: session [7884,7891]
===
match
---
atom_expr [7958,7967]
atom_expr [7958,7967]
===
match
---
simple_stmt [22248,22265]
simple_stmt [22248,22265]
===
match
---
name: error_file [46888,46898]
name: error_file [46888,46898]
===
match
---
name: execution_date [13035,13049]
name: execution_date [13035,13049]
===
match
---
atom_expr [28226,28239]
atom_expr [28226,28239]
===
match
---
simple_stmt [24746,24780]
simple_stmt [24746,24780]
===
match
---
name: result [49779,49785]
name: result [49779,49785]
===
match
---
operator: , [3417,3418]
operator: , [3417,3418]
===
match
---
expr_stmt [42522,42548]
expr_stmt [42522,42548]
===
match
---
name: in_ [27574,27577]
name: in_ [27574,27577]
===
match
---
simple_stmt [820,835]
simple_stmt [820,835]
===
match
---
operator: , [6417,6418]
operator: , [6417,6418]
===
match
---
operator: = [81090,81091]
operator: = [81514,81515]
===
match
---
operator: , [4433,4434]
operator: , [4433,4434]
===
match
---
param [4830,4834]
param [4830,4834]
===
match
---
argument [53647,53656]
argument [54071,54080]
===
match
---
argument [67877,67903]
argument [68301,68327]
===
match
---
param [30892,30920]
param [30892,30920]
===
match
---
name: Integer [11521,11528]
name: Integer [11521,11528]
===
match
---
dotted_name [2678,2695]
dotted_name [2678,2695]
===
match
---
operator: = [35375,35376]
operator: = [35375,35376]
===
match
---
operator: , [55274,55275]
operator: , [55698,55699]
===
match
---
simple_stmt [9119,9161]
simple_stmt [9119,9161]
===
match
---
operator: , [9404,9405]
operator: , [9404,9405]
===
match
---
atom_expr [33818,33837]
atom_expr [33818,33837]
===
match
---
arglist [78618,78777]
arglist [79042,79201]
===
match
---
name: try_number [13292,13302]
name: try_number [13292,13302]
===
match
---
tfpdef [55318,55343]
tfpdef [55742,55767]
===
match
---
atom_expr [57455,57465]
atom_expr [57879,57889]
===
match
---
operator: = [16844,16845]
operator: = [16844,16845]
===
match
---
name: mark_success [39715,39727]
name: mark_success [39715,39727]
===
match
---
atom_expr [23625,23637]
atom_expr [23625,23637]
===
match
---
name: and_ [77996,78000]
name: and_ [78420,78424]
===
match
---
operator: = [43132,43133]
operator: = [43132,43133]
===
match
---
name: reschedule_exception [54244,54264]
name: reschedule_exception [54668,54688]
===
match
---
name: delay [36370,36375]
name: delay [36370,36375]
===
match
---
atom_expr [49592,49620]
atom_expr [49592,49620]
===
match
---
operator: , [64170,64171]
operator: , [64594,64595]
===
match
---
name: ignore_task_deps [41427,41443]
name: ignore_task_deps [41427,41443]
===
match
---
name: self [47204,47208]
name: self [47204,47208]
===
match
---
name: task [39172,39176]
name: task [39172,39176]
===
match
---
name: add [56181,56184]
name: add [56605,56608]
===
match
---
name: vals_kv [76080,76087]
name: vals_kv [76504,76511]
===
match
---
trailer [5766,5773]
trailer [5766,5773]
===
match
---
simple_stmt [80121,80141]
simple_stmt [80545,80565]
===
match
---
trailer [68283,68301]
trailer [68707,68725]
===
match
---
name: ignore_ti_state [17316,17331]
name: ignore_ti_state [17316,17331]
===
match
---
simple_stmt [33656,33670]
simple_stmt [33656,33670]
===
match
---
operator: = [79380,79381]
operator: = [79804,79805]
===
match
---
name: UtcDateTime [10885,10896]
name: UtcDateTime [10885,10896]
===
match
---
trailer [13064,13073]
trailer [13064,13073]
===
match
---
simple_stmt [59029,59051]
simple_stmt [59453,59475]
===
match
---
name: typing_compat [2462,2475]
name: typing_compat [2462,2475]
===
match
---
name: ignore_depends_on_past [53103,53125]
name: ignore_depends_on_past [53527,53549]
===
match
---
name: args [45670,45674]
name: args [45670,45674]
===
match
---
name: session [76709,76716]
name: session [77133,77140]
===
match
---
name: self [70131,70135]
name: self [70555,70559]
===
match
---
name: end_date [72116,72124]
name: end_date [72540,72548]
===
match
---
atom_expr [70350,70412]
atom_expr [70774,70836]
===
match
---
name: session [58812,58819]
name: session [59236,59243]
===
match
---
decorated [14577,15128]
decorated [14577,15128]
===
match
---
decorated [36826,37309]
decorated [36826,37309]
===
match
---
trailer [79700,79713]
trailer [80124,80137]
===
match
---
name: task [28958,28962]
name: task [28958,28962]
===
match
---
name: dag_id [16525,16531]
name: dag_id [16525,16531]
===
match
---
name: self [57520,57524]
name: self [57944,57948]
===
match
---
operator: = [67822,67823]
operator: = [68246,68247]
===
match
---
name: test_mode [57483,57492]
name: test_mode [57907,57916]
===
match
---
name: XCom [76421,76425]
name: XCom [76845,76849]
===
match
---
argument [11331,11345]
argument [11331,11345]
===
match
---
atom_expr [77605,77617]
atom_expr [78029,78041]
===
match
---
name: self [51377,51381]
name: self [51377,51381]
===
match
---
trailer [16454,16460]
trailer [16454,16460]
===
match
---
atom_expr [42476,42513]
atom_expr [42476,42513]
===
match
---
funcdef [80160,80215]
funcdef [80584,80639]
===
match
---
trailer [5756,5763]
trailer [5756,5763]
===
match
---
name: reschedule_exception [45960,45980]
name: reschedule_exception [45960,45980]
===
match
---
operator: , [46732,46733]
operator: , [46732,46733]
===
match
---
name: dag_run_state [8996,9009]
name: dag_run_state [8996,9009]
===
match
---
atom_expr [4782,4792]
atom_expr [4782,4792]
===
match
---
name: query [8622,8627]
name: query [8622,8627]
===
match
---
parameters [80507,80513]
parameters [80931,80937]
===
match
---
name: self [25714,25718]
name: self [25714,25718]
===
match
---
name: airflow [8377,8384]
name: airflow [8377,8384]
===
match
---
name: task [24907,24911]
name: task [24907,24911]
===
match
---
name: ti [78641,78643]
name: ti [79065,79067]
===
match
---
comparison [8328,8354]
comparison [8328,8354]
===
match
---
name: max_tries [11111,11120]
name: max_tries [11111,11120]
===
match
---
string: """         Checks dependencies and then sets state to RUNNING if they are met. Returns         True if and only if state is set to RUNNING, which implies that task should be         executed, in preparation for _run_raw_task          :param verbose: whether to turn on more verbose logging         :type verbose: bool         :param ignore_all_deps: Ignore all of the non-critical dependencies, just runs         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past DAG attribute         :type ignore_depends_on_past: bool         :param ignore_task_deps: Don't check the dependencies of this TaskInstance's task         :type ignore_task_deps: bool         :param ignore_ti_state: Disregards previous task instance state         :type ignore_ti_state: bool         :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param job_id: Job (BackfillJob / LocalTaskJob / SchedulerJob) ID         :type job_id: str         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         :return: whether the state was changed to running or not         :rtype: bool         """ [37776,39151]
string: """         Checks dependencies and then sets state to RUNNING if they are met. Returns         True if and only if state is set to RUNNING, which implies that task should be         executed, in preparation for _run_raw_task          :param verbose: whether to turn on more verbose logging         :type verbose: bool         :param ignore_all_deps: Ignore all of the non-critical dependencies, just runs         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past DAG attribute         :type ignore_depends_on_past: bool         :param ignore_task_deps: Don't check the dependencies of this TaskInstance's task         :type ignore_task_deps: bool         :param ignore_ti_state: Disregards previous task instance state         :type ignore_ti_state: bool         :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param job_id: Job (BackfillJob / LocalTaskJob / SchedulerJob) ID         :type job_id: str         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         :return: whether the state was changed to running or not         :rtype: bool         """ [37776,39151]
===
match
---
string: '<br>' [68801,68807]
string: '<br>' [69225,69231]
===
match
---
annassign [9213,9223]
annassign [9213,9223]
===
match
---
operator: = [58867,58868]
operator: = [59291,59292]
===
match
---
operator: @ [30816,30817]
operator: @ [30816,30817]
===
match
---
atom_expr [8523,8584]
atom_expr [8523,8584]
===
match
---
name: _pool [80686,80691]
name: _pool [81110,81115]
===
match
---
decorated [30816,31415]
decorated [30816,31415]
===
match
---
name: mark_success [42845,42857]
name: mark_success [42845,42857]
===
match
---
name: value [76426,76431]
name: value [76850,76855]
===
match
---
name: self [47062,47066]
name: self [47062,47066]
===
match
---
atom_expr [77643,77663]
atom_expr [78067,78087]
===
match
---
simple_stmt [36730,36821]
simple_stmt [36730,36821]
===
match
---
operator: = [59281,59282]
operator: = [59705,59706]
===
match
---
name: dr [8923,8925]
name: dr [8923,8925]
===
match
---
suite [21942,22265]
suite [21942,22265]
===
match
---
arglist [29736,29765]
arglist [29736,29765]
===
match
---
name: base_job [81996,82004]
name: base_job [82420,82428]
===
match
---
name: item [62377,62381]
name: item [62801,62805]
===
match
---
for_stmt [8896,9078]
for_stmt [8896,9078]
===
match
---
operator: = [73485,73486]
operator: = [73909,73910]
===
match
---
name: str [55339,55342]
name: str [55763,55766]
===
match
---
parameters [66961,66984]
parameters [67385,67408]
===
match
---
trailer [68732,68746]
trailer [69156,69170]
===
match
---
operator: = [5889,5890]
operator: = [5889,5890]
===
match
---
trailer [64372,64465]
trailer [64796,64889]
===
match
---
name: start_date [32024,32034]
name: start_date [32024,32034]
===
match
---
expr [34220,34253]
expr [34220,34253]
===
match
---
name: dag_id [11861,11867]
name: dag_id [11861,11867]
===
match
---
name: Exception [4100,4109]
name: Exception [4100,4109]
===
match
---
atom_expr [72111,72124]
atom_expr [72535,72548]
===
match
---
atom_expr [51791,51815]
atom_expr [51791,51815]
===
match
---
operator: = [12497,12498]
operator: = [12497,12498]
===
match
---
trailer [35380,35445]
trailer [35380,35445]
===
match
---
operator: , [56275,56276]
operator: , [56699,56700]
===
match
---
if_stmt [19761,19835]
if_stmt [19761,19835]
===
match
---
operator: = [4944,4945]
operator: = [4944,4945]
===
match
---
trailer [78740,78755]
trailer [79164,79179]
===
match
---
simple_stmt [23375,23397]
simple_stmt [23375,23397]
===
match
---
atom_expr [64349,64465]
atom_expr [64773,64889]
===
match
---
name: try_number [7356,7366]
name: try_number [7356,7366]
===
match
---
name: self [80821,80825]
name: self [81245,81249]
===
match
---
operator: , [4451,4452]
operator: , [4451,4452]
===
match
---
suite [40827,41025]
suite [40827,41025]
===
match
---
operator: = [16704,16705]
operator: = [16704,16705]
===
match
---
simple_stmt [33683,33888]
simple_stmt [33683,33888]
===
match
---
param [36868,36891]
param [36868,36891]
===
match
---
trailer [28749,28759]
trailer [28749,28759]
===
match
---
return_stmt [76478,76513]
return_stmt [76902,76937]
===
match
---
operator: } [60886,60887]
operator: } [61310,61311]
===
match
---
suite [51247,51339]
suite [51247,51339]
===
match
---
simple_stmt [9507,9592]
simple_stmt [9507,9592]
===
match
---
tfpdef [72373,72407]
tfpdef [72797,72831]
===
match
---
name: TaskInstance [27462,27474]
name: TaskInstance [27462,27474]
===
match
---
name: property [80630,80638]
name: property [81054,81062]
===
match
---
name: ignore_schedule [29456,29471]
name: ignore_schedule [29456,29471]
===
match
---
trailer [47520,47522]
trailer [47520,47522]
===
match
---
name: RESTARTING [7976,7986]
name: RESTARTING [7976,7986]
===
match
---
expr_stmt [60646,60702]
expr_stmt [61070,61126]
===
match
---
simple_stmt [4187,4199]
simple_stmt [4187,4199]
===
match
---
trailer [42991,42995]
trailer [42991,42995]
===
match
---
if_stmt [60898,60953]
if_stmt [61322,61377]
===
match
---
name: force_fail [57713,57723]
name: force_fail [58137,58147]
===
match
---
name: self [67969,67973]
name: self [68393,68397]
===
match
---
atom_expr [82070,82090]
atom_expr [82494,82514]
===
match
---
simple_stmt [9778,9837]
simple_stmt [9778,9837]
===
match
---
trailer [63301,63307]
trailer [63725,63731]
===
match
---
simple_stmt [71477,71554]
simple_stmt [71901,71978]
===
match
---
arglist [43001,43053]
arglist [43001,43053]
===
match
---
name: self [9636,9640]
name: self [9636,9640]
===
match
---
name: id [7922,7924]
name: id [7922,7924]
===
match
---
param [72353,72364]
param [72777,72788]
===
match
---
trailer [58047,58058]
trailer [58471,58482]
===
match
---
string: """     Clears a set of task instances, but makes sure the running ones     get killed.      :param tis: a list of task instances     :param session: current session     :param dag_run_state: state to set DagRun to. If set to False, dagrun state will not         be changed.     :param dag: DAG object     :param activate_dag_runs: Deprecated parameter, do not pass     """ [4973,5346]
string: """     Clears a set of task instances, but makes sure the running ones     get killed.      :param tis: a list of task instances     :param session: current session     :param dag_run_state: state to set DagRun to. If set to False, dagrun state will not         be changed.     :param dag: DAG object     :param activate_dag_runs: Deprecated parameter, do not pass     """ [4973,5346]
===
match
---
name: provide_session [25017,25032]
name: provide_session [25017,25032]
===
match
---
name: stacklevel [32562,32572]
name: stacklevel [32562,32572]
===
match
---
trailer [50701,50709]
trailer [50701,50709]
===
match
---
name: context [50877,50884]
name: context [50877,50884]
===
match
---
atom_expr [16000,16013]
atom_expr [16000,16013]
===
match
---
name: task [54569,54573]
name: task [54993,54997]
===
match
---
name: ignore_all_deps [15324,15339]
name: ignore_all_deps [15324,15339]
===
match
---
atom [27704,27734]
atom [27704,27734]
===
match
---
operator: @ [80629,80630]
operator: @ [81053,81054]
===
match
---
simple_stmt [44914,44945]
simple_stmt [44914,44945]
===
match
---
name: execution_date [13263,13277]
name: execution_date [13263,13277]
===
match
---
trailer [6018,6028]
trailer [6018,6028]
===
match
---
name: get [63351,63354]
name: get [63775,63778]
===
match
---
name: self [12520,12524]
name: self [12520,12524]
===
match
---
name: t [77927,77928]
name: t [78351,78352]
===
match
---
name: ti [23269,23271]
name: ti [23269,23271]
===
match
---
atom_expr [55683,55710]
atom_expr [56107,56134]
===
match
---
operator: , [32574,32575]
operator: , [32574,32575]
===
match
---
name: String [10805,10811]
name: String [10805,10811]
===
match
---
parameters [26531,26537]
parameters [26531,26537]
===
match
---
decorator [14577,14587]
decorator [14577,14587]
===
match
---
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [69272,69334]
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [69696,69758]
===
match
---
operator: = [29360,29361]
operator: = [29360,29361]
===
match
---
suite [49392,49543]
suite [49392,49543]
===
match
---
trailer [22971,22979]
trailer [22971,22979]
===
match
---
atom_expr [28880,28899]
atom_expr [28880,28899]
===
match
---
trailer [39402,39404]
trailer [39402,39404]
===
match
---
comparison [78230,78256]
comparison [78654,78680]
===
match
---
name: TaskInstance [81123,81135]
name: TaskInstance [81547,81559]
===
match
---
operator: } [60873,60874]
operator: } [61297,61298]
===
match
---
name: session [40299,40306]
name: session [40299,40306]
===
match
---
simple_stmt [43299,43712]
simple_stmt [43299,43712]
===
match
---
trailer [70285,70295]
trailer [70709,70719]
===
match
---
name: net [2692,2695]
name: net [2692,2695]
===
match
---
name: DagRun [8703,8709]
name: DagRun [8703,8709]
===
match
---
trailer [7228,7531]
trailer [7228,7531]
===
match
---
name: utils [2889,2894]
name: utils [2889,2894]
===
match
---
name: frame [47589,47594]
name: frame [47589,47594]
===
match
---
operator: } [20983,20984]
operator: } [20983,20984]
===
match
---
name: property [30278,30286]
name: property [30278,30286]
===
match
---
parameters [24342,24374]
parameters [24342,24374]
===
match
---
param [43912,43939]
param [43912,43939]
===
match
---
simple_stmt [44839,44877]
simple_stmt [44839,44877]
===
match
---
simple_stmt [26178,26197]
simple_stmt [26178,26197]
===
match
---
operator: -> [57767,57769]
operator: -> [58191,58193]
===
match
---
atom_expr [48219,48231]
atom_expr [48219,48231]
===
match
---
atom_expr [35031,35052]
atom_expr [35031,35052]
===
match
---
operator: == [77944,77946]
operator: == [78368,78370]
===
match
---
name: self [59958,59962]
name: self [60382,60386]
===
match
---
name: os [70270,70272]
name: os [70694,70696]
===
match
---
name: execution_date [27653,27667]
name: execution_date [27653,27667]
===
match
---
operator: , [19517,19518]
operator: , [19517,19518]
===
match
---
name: QUEUED [4958,4964]
name: QUEUED [4958,4964]
===
match
---
name: str [80108,80111]
name: str [80532,80535]
===
match
---
name: XCom [25343,25347]
name: XCom [25343,25347]
===
match
---
tfpdef [30892,30912]
tfpdef [30892,30912]
===
match
---
not_test [12728,12769]
not_test [12728,12769]
===
match
---
name: jinja_context [69732,69745]
name: jinja_context [70156,70169]
===
match
---
operator: , [46331,46332]
operator: , [46331,46332]
===
match
---
name: clear_xcom_data [25041,25056]
name: clear_xcom_data [25041,25056]
===
match
---
param [47589,47594]
param [47589,47594]
===
match
---
name: DAG [3414,3417]
name: DAG [3414,3417]
===
match
---
param [68492,68501]
param [68916,68925]
===
match
---
trailer [56034,56036]
trailer [56458,56460]
===
match
---
arglist [12173,12322]
arglist [12173,12322]
===
match
---
operator: , [11318,11319]
operator: , [11318,11319]
===
match
---
name: exception [68492,68501]
name: exception [68916,68925]
===
match
---
name: downstream_task_ids [27378,27397]
name: downstream_task_ids [27378,27397]
===
match
---
suite [29472,29553]
suite [29472,29553]
===
match
---
name: email_for_state [57031,57046]
name: email_for_state [57455,57470]
===
match
---
name: FileSystemLoader [70253,70269]
name: FileSystemLoader [70677,70693]
===
match
---
atom_expr [35535,35746]
atom_expr [35535,35746]
===
match
---
operator: ** [71300,71302]
operator: ** [71724,71726]
===
match
---
trailer [75572,75579]
trailer [75996,76003]
===
match
---
simple_stmt [71255,71317]
simple_stmt [71679,71741]
===
match
---
trailer [76716,76722]
trailer [77140,77146]
===
match
---
name: Session [1463,1470]
name: Session [1463,1470]
===
match
---
return_stmt [71563,71609]
return_stmt [71987,72033]
===
match
---
name: render_k8s_pod_yaml [66692,66711]
name: render_k8s_pod_yaml [67116,67135]
===
match
---
atom_expr [24865,24881]
atom_expr [24865,24881]
===
match
---
atom_expr [26081,26098]
atom_expr [26081,26098]
===
match
---
name: self [58412,58416]
name: self [58836,58840]
===
match
---
name: Optional [1095,1103]
name: Optional [1095,1103]
===
match
---
expr_stmt [77572,77586]
expr_stmt [77996,78010]
===
match
---
expr_stmt [59089,59134]
expr_stmt [59513,59558]
===
match
---
arglist [22788,22830]
arglist [22788,22830]
===
match
---
name: warning [42039,42046]
name: warning [42039,42046]
===
match
---
name: _try_number [14466,14477]
name: _try_number [14466,14477]
===
match
---
atom_expr [48602,48641]
atom_expr [48602,48641]
===
match
---
simple_stmt [59908,59979]
simple_stmt [60332,60403]
===
match
---
operator: , [41509,41510]
operator: , [41509,41510]
===
match
---
name: task_id [21659,21666]
name: task_id [21659,21666]
===
match
---
if_stmt [52061,52206]
if_stmt [52203,52490]
===
match
---
testlist_comp [65861,65899]
testlist_comp [66285,66323]
===
match
---
simple_stmt [978,1018]
simple_stmt [978,1018]
===
match
---
atom_expr [17537,17550]
atom_expr [17537,17550]
===
match
---
name: base [1868,1872]
name: base [1868,1872]
===
match
---
name: stats [2302,2307]
name: stats [2302,2307]
===
match
---
operator: , [43864,43865]
operator: , [43864,43865]
===
match
---
name: str [43927,43930]
name: str [43927,43930]
===
match
---
name: provide_session [25785,25800]
name: provide_session [25785,25800]
===
match
---
suite [65800,65841]
suite [66224,66265]
===
match
---
operator: = [15339,15340]
operator: = [15339,15340]
===
match
---
operator: = [11827,11828]
operator: = [11827,11828]
===
match
---
atom_expr [4214,4225]
atom_expr [4214,4225]
===
match
---
name: task_id [7385,7392]
name: task_id [7385,7392]
===
match
---
name: XCom [73377,73381]
name: XCom [73801,73805]
===
match
---
name: context [48716,48723]
name: context [48716,48723]
===
match
---
name: first [77572,77577]
name: first [77996,78001]
===
match
---
trailer [7961,7967]
trailer [7961,7967]
===
match
---
atom_expr [58267,58281]
atom_expr [58691,58705]
===
match
---
name: datetime [79527,79535]
name: datetime [79951,79959]
===
match
---
operator: = [39305,39306]
operator: = [39305,39306]
===
match
---
term [39675,39683]
term [39675,39683]
===
match
---
name: taskfail [2013,2021]
name: taskfail [2013,2021]
===
match
---
trailer [71088,71102]
trailer [71512,71526]
===
match
---
simple_stmt [24846,24882]
simple_stmt [24846,24882]
===
match
---
atom_expr [34239,34253]
atom_expr [34239,34253]
===
match
---
name: test_mode [39247,39256]
name: test_mode [39247,39256]
===
match
---
except_clause [63600,63631]
except_clause [64024,64055]
===
match
---
name: res [52942,52945]
name: res [53366,53369]
===
match
---
simple_stmt [20042,20066]
simple_stmt [20042,20066]
===
match
---
atom_expr [20825,20858]
atom_expr [20825,20858]
===
match
---
expr_stmt [23690,23717]
expr_stmt [23690,23717]
===
match
---
fstring_string:   [34753,34754]
fstring_string:   [34753,34754]
===
match
---
name: _try_number [79563,79574]
name: _try_number [79987,79998]
===
match
---
trailer [78154,78162]
trailer [78578,78586]
===
match
---
atom_expr [12732,12769]
atom_expr [12732,12769]
===
match
---
trailer [11264,11269]
trailer [11264,11269]
===
match
---
simple_stmt [66893,66918]
simple_stmt [67317,67342]
===
match
---
trailer [8627,8635]
trailer [8627,8635]
===
match
---
string: """Only Renders Templates for the TI""" [53965,54004]
string: """Only Renders Templates for the TI""" [54389,54428]
===
match
---
argument [11661,11677]
argument [11661,11677]
===
match
---
name: schedule_interval [29387,29404]
name: schedule_interval [29387,29404]
===
match
---
name: ti [23816,23818]
name: ti [23816,23818]
===
match
---
parameters [4824,4967]
parameters [4824,4967]
===
match
---
expr_stmt [8594,8887]
expr_stmt [8594,8887]
===
match
---
atom_expr [76401,76440]
atom_expr [76825,76864]
===
match
---
decorated [80313,80393]
decorated [80737,80817]
===
match
---
operator: , [17306,17307]
operator: , [17306,17307]
===
match
---
dotted_name [47407,47438]
dotted_name [47407,47438]
===
match
---
name: int [80517,80520]
name: int [80941,80944]
===
match
---
trailer [42776,42783]
trailer [42776,42783]
===
match
---
suite [63511,63584]
suite [63935,64008]
===
match
---
atom_expr [81889,81928]
atom_expr [82313,82352]
===
match
---
name: execution_date [8735,8749]
name: execution_date [8735,8749]
===
match
---
name: context [49080,49087]
name: context [49080,49087]
===
match
---
operator: * [35413,35414]
operator: * [35413,35414]
===
match
---
trailer [21762,21766]
trailer [21762,21766]
===
match
---
strings [49185,49298]
strings [49185,49298]
===
match
---
name: yesterday_ds_nodash [60711,60730]
name: yesterday_ds_nodash [61135,61154]
===
match
---
atom_expr [58676,58691]
atom_expr [59100,59115]
===
match
---
name: query [22855,22860]
name: query [22855,22860]
===
match
---
operator: , [3992,3993]
operator: , [3992,3993]
===
match
---
atom_expr [45917,45992]
atom_expr [45917,45992]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [30533,30684]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [30533,30684]
===
match
---
operator: = [16757,16758]
operator: = [16757,16758]
===
match
---
if_stmt [33897,33933]
if_stmt [33897,33933]
===
match
---
name: provide_session [52486,52501]
name: provide_session [52910,52925]
===
match
---
operator: = [43857,43858]
operator: = [43857,43858]
===
match
---
trailer [73490,73497]
trailer [73914,73921]
===
match
---
operator: , [47587,47588]
operator: , [47587,47588]
===
match
---
param [17230,17267]
param [17230,17267]
===
match
---
subscriptlist [51498,51512]
subscriptlist [51498,51512]
===
match
---
name: default_html_content [69025,69045]
name: default_html_content [69449,69469]
===
match
---
trailer [45886,45902]
trailer [45886,45902]
===
match
---
name: self [41976,41980]
name: self [41976,41980]
===
match
---
name: write [48094,48099]
name: write [48094,48099]
===
match
---
operator: -> [22354,22356]
operator: -> [22354,22356]
===
match
---
raise_stmt [47715,47769]
raise_stmt [47715,47769]
===
match
---
operator: , [43831,43832]
operator: , [43831,43832]
===
match
---
name: executor_config [24933,24948]
name: executor_config [24933,24948]
===
match
---
trailer [75601,75610]
trailer [76025,76034]
===
match
---
name: bool [43852,43856]
name: bool [43852,43856]
===
match
---
simple_stmt [5368,5444]
simple_stmt [5368,5444]
===
match
---
simple_stmt [13109,13162]
simple_stmt [13109,13162]
===
match
---
operator: , [55372,55373]
operator: , [55796,55797]
===
match
---
decorator [43738,43760]
decorator [43738,43760]
===
match
---
atom_expr [77074,77097]
atom_expr [77498,77521]
===
match
---
trailer [59098,59113]
trailer [59522,59537]
===
match
---
name: execution_date [73526,73540]
name: execution_date [73950,73964]
===
match
---
trailer [43590,43608]
trailer [43590,43608]
===
match
---
simple_stmt [15220,15248]
simple_stmt [15220,15248]
===
match
---
operator: = [41330,41331]
operator: = [41330,41331]
===
match
---
trailer [31890,31920]
trailer [31890,31920]
===
match
---
operator: , [12034,12035]
operator: , [12034,12035]
===
match
---
suite [25609,25779]
suite [25609,25779]
===
match
---
atom_expr [62430,62471]
atom_expr [62854,62895]
===
match
---
string: " Continue to run task in non smart sensor mode." [49249,49298]
string: " Continue to run task in non smart sensor mode." [49249,49298]
===
match
---
operator: - [6060,6061]
operator: - [6060,6061]
===
match
---
number: 2 [8239,8240]
number: 2 [8239,8240]
===
match
---
comparison [76880,76915]
comparison [77304,77339]
===
match
---
name: ti [79343,79345]
name: ti [79767,79769]
===
match
---
trailer [42623,42629]
trailer [42623,42629]
===
match
---
atom_expr [57188,57258]
atom_expr [57612,57682]
===
match
---
trailer [67892,67903]
trailer [68316,68327]
===
match
---
fstring_string: &dag_id= [20963,20971]
fstring_string: &dag_id= [20963,20971]
===
match
---
name: self [80050,80054]
name: self [80474,80478]
===
match
---
name: params [67188,67194]
name: params [67612,67618]
===
match
---
simple_stmt [31583,31795]
simple_stmt [31583,31795]
===
match
---
atom_expr [78018,78037]
atom_expr [78442,78461]
===
match
---
string: """         Return the try number that this task number will be when it is actually         run.          If the TaskInstance is currently running, this will match the column in the         database, in all other cases this will be incremented.         """ [13946,14202]
string: """         Return the try number that this task number will be when it is actually         run.          If the TaskInstance is currently running, this will match the column in the         database, in all other cases this will be incremented.         """ [13946,14202]
===
match
---
trailer [20099,20106]
trailer [20099,20106]
===
match
---
atom_expr [20633,20645]
atom_expr [20633,20645]
===
match
---
expr_stmt [54013,54029]
expr_stmt [54437,54453]
===
match
---
trailer [80132,80140]
trailer [80556,80564]
===
match
---
suite [65621,65770]
suite [66045,66194]
===
match
---
operator: = [11512,11513]
operator: = [11512,11513]
===
match
---
operator: = [65524,65525]
operator: = [65948,65949]
===
match
---
trailer [48570,48572]
trailer [48570,48572]
===
match
---
operator: , [7508,7509]
operator: , [7508,7509]
===
match
---
name: get_template_context [70659,70679]
name: get_template_context [71083,71103]
===
match
---
name: task_id [10716,10723]
name: task_id [10716,10723]
===
match
---
atom_expr [22220,22239]
atom_expr [22220,22239]
===
match
---
trailer [47700,47702]
trailer [47700,47702]
===
match
---
trailer [42526,42532]
trailer [42526,42532]
===
match
---
trailer [47981,47989]
trailer [47981,47989]
===
match
---
name: ignore_depends_on_past [41387,41409]
name: ignore_depends_on_past [41387,41409]
===
match
---
operator: , [79138,79139]
operator: , [79562,79563]
===
match
---
atom_expr [23101,23130]
atom_expr [23101,23130]
===
match
---
suite [62938,63673]
suite [63362,64097]
===
match
---
operator: { [58511,58512]
operator: { [58935,58936]
===
match
---
name: Connection [1947,1957]
name: Connection [1947,1957]
===
match
---
atom_expr [64398,64451]
atom_expr [64822,64875]
===
match
---
return_stmt [20578,20668]
return_stmt [20578,20668]
===
match
---
name: self [80014,80018]
name: self [80438,80442]
===
match
---
name: DepContext [34188,34198]
name: DepContext [34188,34198]
===
match
---
name: self [55588,55592]
name: self [56012,56016]
===
match
---
operator: , [1647,1648]
operator: , [1647,1648]
===
match
---
name: str [80830,80833]
name: str [81254,81257]
===
match
---
trailer [60620,60637]
trailer [61044,61061]
===
match
---
name: log [33536,33539]
name: log [33536,33539]
===
match
---
name: task [49841,49845]
name: task [49841,49845]
===
match
---
name: log [42035,42038]
name: log [42035,42038]
===
match
---
parameters [43781,44009]
parameters [43781,44009]
===
match
---
atom [65048,65156]
atom [65472,65580]
===
match
---
trailer [48612,48619]
trailer [48612,48619]
===
match
---
name: error_fd [53685,53693]
name: error_fd [54109,54117]
===
match
---
trailer [58680,58684]
trailer [59104,59108]
===
match
---
name: task_ids [75730,75738]
name: task_ids [76154,76162]
===
match
---
suite [80985,81023]
suite [81409,81447]
===
match
---
simple_stmt [26476,26496]
simple_stmt [26476,26496]
===
match
---
trailer [63888,63903]
trailer [64312,64327]
===
match
---
operator: { [45119,45120]
operator: { [45119,45120]
===
match
---
name: prev_ds [64195,64202]
name: prev_ds [64619,64626]
===
match
---
name: ti [5516,5518]
name: ti [5516,5518]
===
match
---
name: RenderedTaskInstanceFields [66533,66559]
name: RenderedTaskInstanceFields [66957,66983]
===
match
---
operator: = [62465,62466]
operator: = [62889,62890]
===
match
---
name: html_content [71579,71591]
name: html_content [72003,72015]
===
match
---
return_stmt [21873,21885]
return_stmt [21873,21885]
===
match
---
simple_stmt [4584,4607]
simple_stmt [4584,4607]
===
match
---
name: str [9294,9297]
name: str [9294,9297]
===
match
---
trailer [45780,45786]
trailer [45780,45786]
===
match
---
trailer [16376,16378]
trailer [16376,16378]
===
match
---
trailer [59962,59977]
trailer [60386,60401]
===
match
---
name: task_copy [49739,49748]
name: task_copy [49739,49748]
===
match
---
arglist [48127,48158]
arglist [48127,48158]
===
match
---
trailer [20802,20804]
trailer [20802,20804]
===
match
---
operator: = [21497,21498]
operator: = [21497,21498]
===
match
---
operator: = [44897,44898]
operator: = [44897,44898]
===
match
---
operator: , [53598,53599]
operator: , [54022,54023]
===
match
---
trailer [51995,52001]
trailer [52137,52143]
===
match
---
tfpdef [52838,52857]
tfpdef [53262,53281]
===
match
---
trailer [46704,46719]
trailer [46704,46719]
===
match
---
funcdef [47286,49900]
funcdef [47286,49900]
===
match
---
tfpdef [12385,12405]
tfpdef [12385,12405]
===
match
---
funcdef [66325,66918]
funcdef [66749,67342]
===
match
---
name: dict [69951,69955]
name: dict [70375,70379]
===
match
---
atom_expr [59958,59977]
atom_expr [60382,60401]
===
match
---
name: ti [79807,79809]
name: ti [80231,80233]
===
match
---
argument [41612,41624]
argument [41612,41624]
===
match
---
comparison [52064,52100]
comparison [52206,52242]
===
match
---
suite [4571,4607]
suite [4571,4607]
===
match
---
simple_stmt [36603,36722]
simple_stmt [36603,36722]
===
match
---
name: XCom [76219,76223]
name: XCom [76643,76647]
===
match
---
name: dag [16111,16114]
name: dag [16111,16114]
===
match
---
simple_stmt [26547,26663]
simple_stmt [26547,26663]
===
match
---
name: execution_date [13246,13260]
name: execution_date [13246,13260]
===
match
---
expr_stmt [12582,12627]
expr_stmt [12582,12627]
===
match
---
number: 1 [59316,59317]
number: 1 [59740,59741]
===
match
---
argument [12307,12321]
argument [12307,12321]
===
match
---
param [54225,54243]
param [54649,54667]
===
match
---
string: 'dag_run' [63758,63767]
string: 'dag_run' [64182,64191]
===
match
---
name: self [48130,48134]
name: self [48130,48134]
===
match
---
and_test [59654,59690]
and_test [60078,60114]
===
match
---
arith_expr [43326,43452]
arith_expr [43326,43452]
===
match
---
simple_stmt [10992,11017]
simple_stmt [10992,11017]
===
match
---
atom_expr [11197,11209]
atom_expr [11197,11209]
===
match
---
operator: == [25396,25398]
operator: == [25396,25398]
===
match
---
atom_expr [68772,68808]
atom_expr [69196,69232]
===
match
---
expr_stmt [79830,79855]
expr_stmt [80254,80279]
===
match
---
trailer [52196,52205]
trailer [52363,52372]
===
match
---
name: lock_for_update [22331,22346]
name: lock_for_update [22331,22346]
===
match
---
name: ignore_all_deps [39978,39993]
name: ignore_all_deps [39978,39993]
===
match
---
return_stmt [51089,51102]
return_stmt [51089,51102]
===
match
---
decorator [20674,20684]
decorator [20674,20684]
===
match
---
name: render [71496,71502]
name: render [71920,71926]
===
match
---
operator: , [72447,72448]
operator: , [72871,72872]
===
match
---
name: models [1971,1977]
name: models [1971,1977]
===
match
---
name: conf [67210,67214]
name: conf [67634,67638]
===
match
---
expr_stmt [54819,54855]
expr_stmt [55243,55279]
===
match
---
trailer [4776,4781]
trailer [4776,4781]
===
match
---
atom_expr [11540,11555]
atom_expr [11540,11555]
===
match
---
name: html_content [71396,71408]
name: html_content [71820,71832]
===
match
---
atom_expr [26205,26220]
atom_expr [26205,26220]
===
match
---
name: dep_context [41570,41581]
name: dep_context [41570,41581]
===
match
---
suite [16197,16253]
suite [16197,16253]
===
match
---
annassign [9172,9177]
annassign [9172,9177]
===
match
---
operator: == [81637,81639]
operator: == [82061,82063]
===
match
---
name: Integer [11547,11554]
name: Integer [11547,11554]
===
match
---
name: path [70273,70277]
name: path [70697,70701]
===
match
---
arglist [60677,60684]
arglist [61101,61108]
===
match
---
atom_expr [44953,44961]
atom_expr [44953,44961]
===
match
---
argument [48136,48158]
argument [48136,48158]
===
match
---
decorated [80220,80308]
decorated [80644,80732]
===
match
---
name: upper [81920,81925]
name: upper [82344,82349]
===
match
---
operator: = [40864,40865]
operator: = [40864,40865]
===
match
---
name: self [33501,33505]
name: self [33501,33505]
===
match
---
trailer [5436,5441]
trailer [5436,5441]
===
match
---
import_from [81979,82019]
import_from [82403,82443]
===
match
---
name: str [63378,63381]
name: str [63802,63805]
===
match
---
parameters [71630,71647]
parameters [72054,72071]
===
match
---
name: handle_failure [57789,57803]
name: handle_failure [58213,58227]
===
match
---
name: non_requeueable_dep_context [39866,39893]
name: non_requeueable_dep_context [39866,39893]
===
match
---
name: State [5716,5721]
name: State [5716,5721]
===
match
---
simple_stmt [43186,43244]
simple_stmt [43186,43244]
===
match
---
name: first [23123,23128]
name: first [23123,23128]
===
match
---
argument [39214,39232]
argument [39214,39232]
===
match
---
name: get [20541,20544]
name: get [20541,20544]
===
match
---
trailer [79989,80005]
trailer [80413,80429]
===
match
---
operator: = [23776,23777]
operator: = [23776,23777]
===
match
---
operator: , [52757,52758]
operator: , [53181,53182]
===
match
---
atom_expr [70695,70960]
atom_expr [71119,71384]
===
match
---
string: """         Checks whether the immediate dependents of this task instance have succeeded or have been skipped.         This is meant to be used by wait_for_downstream.          This is useful when you do not want to start processing the next         schedule of a task until the dependents are done. For instance,         if the task DROPs and recreates a table.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [26878,27331]
string: """         Checks whether the immediate dependents of this task instance have succeeded or have been skipped.         This is meant to be used by wait_for_downstream.          This is useful when you do not want to start processing the next         schedule of a task until the dependents are done. For instance,         if the task DROPs and recreates a table.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [26878,27331]
===
match
---
name: delay [36557,36562]
name: delay [36557,36562]
===
match
---
operator: , [65240,65241]
operator: , [65664,65665]
===
match
---
operator: - [39942,39943]
operator: - [39942,39943]
===
match
---
arglist [73317,73352]
arglist [73741,73776]
===
match
---
argument [67750,67768]
argument [68174,68192]
===
match
---
name: airflow [81984,81991]
name: airflow [82408,82415]
===
match
---
operator: , [23043,23044]
operator: , [23043,23044]
===
match
---
operator: = [73751,73752]
operator: = [74175,74176]
===
match
---
decorated [80398,80474]
decorated [80822,80898]
===
match
---
name: get_previous_start_date [31445,31468]
name: get_previous_start_date [31445,31468]
===
match
---
trailer [63883,63904]
trailer [64307,64328]
===
match
---
name: dr [28268,28270]
name: dr [28268,28270]
===
match
---
operator: = [70079,70080]
operator: = [70503,70504]
===
match
---
atom_expr [23024,23043]
atom_expr [23024,23043]
===
match
---
comparison [25343,25369]
comparison [25343,25369]
===
match
---
number: 1 [56095,56096]
number: 1 [56519,56520]
===
match
---
trailer [11009,11016]
trailer [11009,11016]
===
match
---
operator: , [52557,52558]
operator: , [52981,52982]
===
match
---
simple_stmt [62419,62472]
simple_stmt [62843,62896]
===
match
---
simple_stmt [51089,51103]
simple_stmt [51089,51103]
===
match
---
simple_stmt [39160,39177]
simple_stmt [39160,39177]
===
match
---
name: self [79640,79644]
name: self [80064,80068]
===
match
---
operator: , [60815,60816]
operator: , [61239,61240]
===
match
---
name: base_url [20585,20593]
name: base_url [20585,20593]
===
match
---
trailer [50709,50726]
trailer [50709,50726]
===
match
---
name: BaseJob [7856,7863]
name: BaseJob [7856,7863]
===
match
---
atom_expr [34726,34737]
atom_expr [34726,34737]
===
match
---
name: self [54982,54986]
name: self [55406,55410]
===
match
---
strings [69395,69684]
strings [69819,70108]
===
match
---
name: dep_context [34220,34231]
name: dep_context [34220,34231]
===
match
---
operator: = [24863,24864]
operator: = [24863,24864]
===
match
---
atom_expr [22967,22979]
atom_expr [22967,22979]
===
match
---
name: property [14578,14586]
name: property [14578,14586]
===
match
---
atom_expr [34512,34529]
atom_expr [34512,34529]
===
match
---
operator: , [1673,1674]
operator: , [1673,1674]
===
match
---
name: self [13398,13402]
name: self [13398,13402]
===
match
---
operator: , [11912,11913]
operator: , [11912,11913]
===
match
---
name: task [51158,51162]
name: task [51158,51162]
===
match
---
atom_expr [35569,35716]
atom_expr [35569,35716]
===
match
---
simple_stmt [60646,60703]
simple_stmt [61070,61127]
===
match
---
name: _run_finished_callback [51447,51469]
name: _run_finished_callback [51447,51469]
===
match
---
atom_expr [9288,9313]
atom_expr [9288,9313]
===
match
---
name: task [58417,58421]
name: task [58841,58845]
===
match
---
name: Optional [72389,72397]
name: Optional [72813,72821]
===
match
---
comparison [73123,73159]
comparison [73547,73583]
===
match
---
arglist [76205,76229]
arglist [76629,76653]
===
match
---
argument [16839,16850]
argument [16839,16850]
===
match
---
operator: , [11094,11095]
operator: , [11094,11095]
===
match
---
simple_stmt [68755,68809]
simple_stmt [69179,69233]
===
match
---
funcdef [43080,43244]
funcdef [43080,43244]
===
match
---
operator: , [12059,12060]
operator: , [12059,12060]
===
match
---
operator: = [53309,53310]
operator: = [53733,53734]
===
match
---
fstring_expr [48527,48530]
fstring_expr [48527,48530]
===
match
---
name: external_executor_id [11616,11636]
name: external_executor_id [11616,11636]
===
match
---
trailer [81005,81022]
trailer [81429,81446]
===
match
---
atom_expr [22122,22177]
atom_expr [22122,22177]
===
match
---
operator: , [76217,76218]
operator: , [76641,76642]
===
match
---
arglist [45941,45991]
arglist [45941,45991]
===
match
---
name: Variable [62684,62692]
name: Variable [63108,63116]
===
match
---
trailer [27699,27703]
trailer [27699,27703]
===
match
---
operator: , [22315,22316]
operator: , [22315,22316]
===
match
---
trailer [27629,27644]
trailer [27629,27644]
===
match
---
name: State [51733,51738]
name: State [51733,51738]
===
match
---
argument [46734,46755]
argument [46734,46755]
===
match
---
name: tuple_ [1366,1372]
name: tuple_ [1366,1372]
===
match
---
atom_expr [54150,54169]
atom_expr [54574,54593]
===
match
---
name: queued_by_job_id [24026,24042]
name: queued_by_job_id [24026,24042]
===
match
---
name: timezone [42097,42105]
name: timezone [42097,42105]
===
match
---
operator: = [52551,52552]
operator: = [52975,52976]
===
match
---
name: refresh_from_task [5932,5949]
name: refresh_from_task [5932,5949]
===
match
---
argument [8228,8240]
argument [8228,8240]
===
match
---
trailer [21696,21711]
trailer [21696,21711]
===
match
---
name: job_id [19743,19749]
name: job_id [19743,19749]
===
match
---
name: self [67242,67246]
name: self [67666,67670]
===
match
---
name: item [63578,63582]
name: item [64002,64006]
===
match
---
if_stmt [36434,36526]
if_stmt [36434,36526]
===
match
---
name: ts_nodash_with_tz [65010,65027]
name: ts_nodash_with_tz [65434,65451]
===
match
---
name: email_alert [71619,71630]
name: email_alert [72043,72054]
===
match
---
funcdef [29807,30272]
funcdef [29807,30272]
===
match
---
name: state [30892,30897]
name: state [30892,30897]
===
match
---
param [52800,52829]
param [53224,53253]
===
match
---
name: prev_execution_date [60470,60489]
name: prev_execution_date [60894,60913]
===
match
---
name: e [65904,65905]
name: e [66328,66329]
===
match
---
name: mark_success [19552,19564]
name: mark_success [19552,19564]
===
match
---
tfpdef [43948,43973]
tfpdef [43948,43973]
===
match
---
fstring_end: ' [47011,47012]
fstring_end: ' [47011,47012]
===
match
---
name: Optional [52808,52816]
name: Optional [53232,53240]
===
match
---
simple_stmt [54038,54079]
simple_stmt [54462,54503]
===
match
---
operator: , [36866,36867]
operator: , [36866,36867]
===
match
---
operator: , [60566,60567]
operator: , [60990,60991]
===
match
---
name: dep_status [34551,34561]
name: dep_status [34551,34561]
===
match
---
string: """Fetch rendered template fields from DB""" [65361,65405]
string: """Fetch rendered template fields from DB""" [65785,65829]
===
match
---
operator: = [53279,53280]
operator: = [53703,53704]
===
match
---
name: Context [67266,67273]
name: Context [67690,67697]
===
match
---
name: priority_weight [12074,12089]
name: priority_weight [12074,12089]
===
match
---
atom_expr [55253,55267]
atom_expr [55677,55691]
===
match
---
name: State [53806,53811]
name: State [54230,54235]
===
match
---
name: context [48046,48053]
name: context [48046,48053]
===
match
---
trailer [67102,67175]
trailer [67526,67599]
===
match
---
if_stmt [60041,60255]
if_stmt [60465,60679]
===
match
---
trailer [45902,45904]
trailer [45902,45904]
===
match
---
operator: = [23160,23161]
operator: = [23160,23161]
===
match
---
name: create_pod_id [67627,67640]
name: create_pod_id [68051,68064]
===
match
---
name: start_date [79492,79502]
name: start_date [79916,79926]
===
match
---
name: hasattr [79747,79754]
name: hasattr [80171,80178]
===
match
---
trailer [79926,79949]
trailer [80350,80373]
===
match
---
name: pickle [864,870]
name: pickle [864,870]
===
match
---
simple_stmt [47104,47122]
simple_stmt [47104,47122]
===
match
---
trailer [24243,24249]
trailer [24243,24249]
===
match
---
if_stmt [47158,47255]
if_stmt [47158,47255]
===
match
---
name: seek [4206,4210]
name: seek [4206,4210]
===
match
---
string: '' [60817,60819]
string: '' [61241,61243]
===
match
---
decorated [80797,80862]
decorated [81221,81286]
===
match
---
name: DeprecationWarning [30178,30196]
name: DeprecationWarning [30178,30196]
===
match
---
trailer [77206,77225]
trailer [77630,77649]
===
match
---
simple_stmt [48331,48411]
simple_stmt [48331,48411]
===
match
---
funcdef [61455,61614]
funcdef [61879,62038]
===
match
---
name: path [71184,71188]
name: path [71608,71612]
===
match
---
trailer [16224,16235]
trailer [16224,16235]
===
match
---
decorated [30277,30811]
decorated [30277,30811]
===
match
---
operator: , [11085,11086]
operator: , [11085,11086]
===
match
---
trailer [54568,54573]
trailer [54992,54997]
===
match
---
number: 1 [70880,70881]
number: 1 [71304,71305]
===
match
---
trailer [59122,59134]
trailer [59546,59558]
===
match
---
name: debug [34361,34366]
name: debug [34361,34366]
===
match
---
simple_stmt [52032,52049]
simple_stmt [52174,52191]
===
match
---
operator: = [31293,31294]
operator: = [31293,31294]
===
match
---
name: task_id [67795,67802]
name: task_id [68219,68226]
===
match
---
operator: @ [32656,32657]
operator: @ [32656,32657]
===
match
---
simple_stmt [35504,35782]
simple_stmt [35504,35782]
===
match
---
name: State [39503,39508]
name: State [39503,39508]
===
match
---
param [66968,66975]
param [67392,67399]
===
match
---
trailer [7975,7986]
trailer [7975,7986]
===
match
---
suite [67370,67421]
suite [67794,67845]
===
match
---
name: execution_date [9655,9669]
name: execution_date [9655,9669]
===
match
---
operator: , [1359,1360]
operator: , [1359,1360]
===
match
---
name: self [79460,79464]
name: self [79884,79888]
===
match
---
trailer [27577,27603]
trailer [27577,27603]
===
match
---
name: end_date [26365,26373]
name: end_date [26365,26373]
===
match
---
name: next_try_number [15151,15166]
name: next_try_number [15151,15166]
===
match
---
name: task [51305,51309]
name: task [51305,51309]
===
match
---
suite [49003,49089]
suite [49003,49089]
===
match
---
param [12359,12384]
param [12359,12384]
===
match
---
atom_expr [78759,78776]
atom_expr [79183,79200]
===
match
---
string: "--pool" [20161,20169]
string: "--pool" [20161,20169]
===
match
---
param [37557,37587]
param [37557,37587]
===
match
---
atom_expr [39896,40187]
atom_expr [39896,40187]
===
match
---
name: get_k8s_pod_yaml [66560,66576]
name: get_k8s_pod_yaml [66984,67000]
===
match
---
name: warn [32339,32343]
name: warn [32339,32343]
===
match
---
name: SimpleTaskInstance [79153,79171]
name: SimpleTaskInstance [79577,79595]
===
match
---
trailer [70593,70610]
trailer [71017,71034]
===
match
---
name: ti [79582,79584]
name: ti [80006,80008]
===
match
---
name: self [25727,25731]
name: self [25727,25731]
===
match
---
suite [79950,80006]
suite [80374,80430]
===
match
---
operator: = [24762,24763]
operator: = [24762,24763]
===
match
---
name: self [66577,66581]
name: self [67001,67005]
===
match
---
trailer [58032,58038]
trailer [58456,58462]
===
match
---
name: dag [28746,28749]
name: dag [28746,28749]
===
match
---
suite [27974,29788]
suite [27974,29788]
===
match
---
name: self [67850,67854]
name: self [68274,68278]
===
match
---
suite [50837,50894]
suite [50837,50894]
===
match
---
trailer [70221,70327]
trailer [70645,70751]
===
match
---
name: timezone [13065,13073]
name: timezone [13065,13073]
===
match
---
string: 'ts_nodash_with_tz' [64989,65008]
string: 'ts_nodash_with_tz' [65413,65432]
===
match
---
name: REQUEUEABLE_DEPS [2418,2434]
name: REQUEUEABLE_DEPS [2418,2434]
===
match
---
operator: = [11152,11153]
operator: = [11152,11153]
===
match
---
name: error_file [43948,43958]
name: error_file [43948,43958]
===
match
---
not_test [16356,16378]
not_test [16356,16378]
===
match
---
name: State [46613,46618]
name: State [46613,46618]
===
match
---
name: _date_or_empty [43674,43688]
name: _date_or_empty [43674,43688]
===
match
---
operator: , [41460,41461]
operator: , [41460,41461]
===
match
---
atom_expr [53806,53819]
atom_expr [54230,54243]
===
match
---
operator: = [49769,49770]
operator: = [49769,49770]
===
match
---
name: execution_date [13109,13123]
name: execution_date [13109,13123]
===
match
---
simple_stmt [61426,61442]
simple_stmt [61850,61866]
===
match
---
argument [53579,53598]
argument [54003,54022]
===
match
---
name: xcom [76456,76460]
name: xcom [76880,76884]
===
match
---
name: str [72340,72343]
name: str [72764,72767]
===
match
---
operator: , [13049,13050]
operator: , [13049,13050]
===
match
---
name: min [36488,36491]
name: min [36488,36491]
===
match
---
arglist [51046,51079]
arglist [51046,51079]
===
match
---
atom_expr [24996,25010]
atom_expr [24996,25010]
===
match
---
name: max [36333,36336]
name: max [36333,36336]
===
match
---
name: self [16000,16004]
name: self [16000,16004]
===
match
---
funcdef [62517,62574]
funcdef [62941,62998]
===
match
---
dotted_name [3147,3179]
dotted_name [3147,3179]
===
match
---
not_test [4255,4263]
not_test [4255,4263]
===
match
---
arglist [11311,11345]
arglist [11311,11345]
===
match
---
trailer [44843,44859]
trailer [44843,44859]
===
match
---
name: ignore_depends_on_past [37471,37493]
name: ignore_depends_on_past [37471,37493]
===
match
---
operator: = [81774,81775]
operator: = [82198,82199]
===
match
---
import_from [2289,2320]
import_from [2289,2320]
===
match
---
name: ignore_depends_on_past [16758,16780]
name: ignore_depends_on_past [16758,16780]
===
match
---
name: self [79604,79608]
name: self [80028,80032]
===
match
---
name: TaskInstance [78018,78030]
name: TaskInstance [78442,78454]
===
match
---
dotted_name [3033,3061]
dotted_name [3033,3061]
===
match
---
suite [45545,45803]
suite [45545,45803]
===
match
---
atom_expr [9678,9693]
atom_expr [9678,9693]
===
match
---
import_from [1848,1908]
import_from [1848,1908]
===
match
---
arglist [36310,36356]
arglist [36310,36356]
===
match
---
trailer [59938,59957]
trailer [60362,60381]
===
match
---
dotted_name [1560,1581]
dotted_name [1560,1581]
===
match
---
testlist_star_expr [71716,71755]
testlist_star_expr [72140,72179]
===
match
---
expr_stmt [12520,12536]
expr_stmt [12520,12536]
===
match
---
argument [70594,70609]
argument [71018,71033]
===
match
---
trailer [57423,57466]
trailer [57847,57890]
===
match
---
name: task_retries [6047,6059]
name: task_retries [6047,6059]
===
match
---
name: timezone [13015,13023]
name: timezone [13015,13023]
===
match
---
return_stmt [14454,14481]
return_stmt [14454,14481]
===
match
---
simple_stmt [28735,28770]
simple_stmt [28735,28770]
===
match
---
name: task_copy [48842,48851]
name: task_copy [48842,48851]
===
match
---
atom [69748,69760]
atom [70172,70184]
===
match
---
name: task [16005,16009]
name: task [16005,16009]
===
match
---
name: log [22127,22130]
name: log [22127,22130]
===
match
---
comparison [51719,51745]
comparison [51719,51745]
===
match
---
name: item [63214,63218]
name: item [63638,63642]
===
match
---
name: dill [1157,1161]
name: dill [1157,1161]
===
match
---
name: query [76401,76406]
name: query [76825,76830]
===
match
---
operator: , [30882,30883]
operator: , [30882,30883]
===
match
---
argument [70018,70047]
argument [70442,70471]
===
match
---
atom_expr [78571,78839]
atom_expr [78995,79263]
===
match
---
operator: , [67903,67904]
operator: , [68327,68328]
===
match
---
atom_expr [75597,75831]
atom_expr [76021,76255]
===
match
---
atom_expr [45721,45763]
atom_expr [45721,45763]
===
match
---
fstring_string: . [45118,45119]
fstring_string: . [45118,45119]
===
match
---
name: State [6467,6472]
name: State [6467,6472]
===
match
---
arglist [71140,71152]
arglist [71564,71576]
===
match
---
atom_expr [24021,24042]
atom_expr [24021,24042]
===
match
---
string: 'next_ds' [63983,63992]
string: 'next_ds' [64407,64416]
===
match
---
atom_expr [36378,36421]
atom_expr [36378,36421]
===
match
---
name: qry [81837,81840]
name: qry [82261,82264]
===
match
---
operator: = [53155,53156]
operator: = [53579,53580]
===
match
---
atom_expr [15794,15818]
atom_expr [15794,15818]
===
match
---
operator: += [42432,42434]
operator: += [42432,42434]
===
match
---
name: PodGenerator [68063,68075]
name: PodGenerator [68487,68499]
===
match
---
operator: = [21935,21936]
operator: = [21935,21936]
===
match
---
suite [36893,37309]
suite [36893,37309]
===
match
---
param [53950,53954]
param [54374,54378]
===
match
---
name: self [61640,61644]
name: self [62064,62068]
===
match
---
expr_stmt [60771,60820]
expr_stmt [61195,61244]
===
match
---
atom_expr [42030,42061]
atom_expr [42030,42061]
===
match
---
arglist [33963,33998]
arglist [33963,33998]
===
match
---
arglist [10740,10764]
arglist [10740,10764]
===
match
---
trailer [23746,23753]
trailer [23746,23753]
===
match
---
dotted_name [1914,1939]
dotted_name [1914,1939]
===
match
---
name: ts_nodash_with_tz [60646,60663]
name: ts_nodash_with_tz [61070,61087]
===
match
---
argument [39924,39960]
argument [39924,39960]
===
match
---
operator: , [4792,4793]
operator: , [4792,4793]
===
match
---
trailer [26754,26767]
trailer [26754,26767]
===
match
---
number: 1000 [11204,11208]
number: 1000 [11204,11208]
===
match
---
subscriptlist [4915,4942]
subscriptlist [4915,4942]
===
match
---
operator: = [52126,52127]
operator: = [52268,52269]
===
match
---
name: base_job [7840,7848]
name: base_job [7840,7848]
===
match
---
atom_expr [60492,60530]
atom_expr [60916,60954]
===
match
---
trailer [27517,27524]
trailer [27517,27524]
===
match
---
name: jinja2 [70203,70209]
name: jinja2 [70627,70633]
===
match
---
name: task [58600,58604]
name: task [59024,59028]
===
match
---
expr_stmt [57141,57178]
expr_stmt [57565,57602]
===
match
---
simple_stmt [11534,11556]
simple_stmt [11534,11556]
===
match
---
simple_stmt [27432,27747]
simple_stmt [27432,27747]
===
match
---
simple_stmt [4203,4227]
simple_stmt [4203,4227]
===
match
---
atom_expr [7140,7632]
atom_expr [7140,7632]
===
match
---
strings [65967,66273]
strings [66391,66697]
===
match
---
name: Connection [63263,63273]
name: Connection [63687,63697]
===
match
---
name: delete [25479,25485]
name: delete [25479,25485]
===
match
---
import_from [1373,1427]
import_from [1373,1427]
===
match
---
operator: = [51049,51050]
operator: = [51049,51050]
===
match
---
atom_expr [48233,48244]
atom_expr [48233,48244]
===
match
---
trailer [20976,20983]
trailer [20976,20983]
===
match
---
trailer [45476,45481]
trailer [45476,45481]
===
match
---
name: str [9299,9302]
name: str [9299,9302]
===
match
---
name: _log [12587,12591]
name: _log [12587,12591]
===
match
---
operator: = [11064,11065]
operator: = [11064,11065]
===
match
---
name: session [36868,36875]
name: session [36868,36875]
===
match
---
trailer [42483,42487]
trailer [42483,42487]
===
match
---
except_clause [4332,4348]
except_clause [4332,4348]
===
match
---
simple_stmt [80014,80042]
simple_stmt [80438,80466]
===
match
---
name: self [61552,61556]
name: self [61976,61980]
===
match
---
name: log [34357,34360]
name: log [34357,34360]
===
match
---
name: field_name [65742,65752]
name: field_name [66166,66176]
===
match
---
trailer [30332,30348]
trailer [30332,30348]
===
match
---
expr_stmt [48964,48982]
expr_stmt [48964,48982]
===
match
---
trailer [13624,13628]
trailer [13624,13628]
===
match
---
string: 'Failed to send email to: %s' [57424,57453]
string: 'Failed to send email to: %s' [57848,57877]
===
match
---
name: self [15167,15171]
name: self [15167,15171]
===
match
---
funcdef [58308,65308]
funcdef [58732,65732]
===
match
---
operator: , [31482,31483]
operator: , [31482,31483]
===
match
---
name: downstream_task_ids [27805,27824]
name: downstream_task_ids [27805,27824]
===
match
---
trailer [77153,77193]
trailer [77577,77617]
===
match
---
name: context [51140,51147]
name: context [51140,51147]
===
match
---
operator: = [26862,26863]
operator: = [26862,26863]
===
match
---
operator: , [9297,9298]
operator: , [9297,9298]
===
match
---
number: 80 [39681,39683]
number: 80 [39681,39683]
===
match
---
trailer [46618,46626]
trailer [46618,46626]
===
match
---
name: self [27881,27885]
name: self [27881,27885]
===
match
---
simple_stmt [33478,33546]
simple_stmt [33478,33546]
===
match
---
simple_stmt [22773,22832]
simple_stmt [22773,22832]
===
match
---
name: str [17445,17448]
name: str [17445,17448]
===
match
---
atom_expr [39503,39516]
atom_expr [39503,39516]
===
match
---
atom_expr [59283,59340]
atom_expr [59707,59764]
===
match
---
atom_expr [34740,34752]
atom_expr [34740,34752]
===
match
---
name: info [49997,50001]
name: info [49997,50001]
===
match
---
trailer [4170,4177]
trailer [4170,4177]
===
match
---
trailer [42629,42635]
trailer [42629,42635]
===
match
---
name: execution_date [21720,21734]
name: execution_date [21720,21734]
===
match
---
name: and_ [8698,8702]
name: and_ [8698,8702]
===
match
---
name: Exception [51503,51512]
name: Exception [51503,51512]
===
match
---
atom_expr [67928,67950]
atom_expr [68352,68374]
===
match
---
annassign [79713,79735]
annassign [80137,80159]
===
match
---
name: html_content_err [71951,71967]
name: html_content_err [72375,72391]
===
match
---
param [79290,79295]
param [79714,79719]
===
match
---
tfpdef [62665,62681]
tfpdef [63089,63105]
===
match
---
operator: , [12117,12118]
operator: , [12117,12118]
===
match
---
name: task_id [76307,76314]
name: task_id [76731,76738]
===
match
---
argument [16643,16674]
argument [16643,16674]
===
match
---
param [80099,80103]
param [80523,80527]
===
match
---
trailer [67201,67215]
trailer [67625,67639]
===
match
---
argument [11596,11608]
argument [11596,11608]
===
match
---
fstring_expr [20933,20947]
fstring_expr [20933,20947]
===
match
---
simple_stmt [36279,36358]
simple_stmt [36279,36358]
===
match
---
operator: , [1327,1328]
operator: , [1327,1328]
===
match
---
name: self [45917,45921]
name: self [45917,45921]
===
match
---
name: mark_success [53244,53256]
name: mark_success [53668,53680]
===
match
---
simple_stmt [24384,24659]
simple_stmt [24384,24659]
===
match
---
operator: , [19665,19666]
operator: , [19665,19666]
===
match
---
atom_expr [50617,50660]
atom_expr [50617,50660]
===
match
---
simple_stmt [51845,51883]
simple_stmt [51845,51883]
===
match
---
trailer [67265,67274]
trailer [67689,67698]
===
match
---
name: Optional [37673,37681]
name: Optional [37673,37681]
===
match
---
suite [9498,9700]
suite [9498,9700]
===
match
---
except_clause [49105,49121]
except_clause [49105,49121]
===
match
---
simple_stmt [31354,31415]
simple_stmt [31354,31415]
===
match
---
name: SUCCESS [52011,52018]
name: SUCCESS [52153,52160]
===
match
---
trailer [81779,81795]
trailer [82203,82219]
===
match
---
simple_stmt [3732,3746]
simple_stmt [3732,3746]
===
match
---
atom_expr [35377,35445]
atom_expr [35377,35445]
===
match
---
name: _run_as_user [79792,79804]
name: _run_as_user [80216,80228]
===
match
---
testlist_comp [20343,20365]
testlist_comp [20343,20365]
===
match
---
suite [72173,72207]
suite [72597,72631]
===
match
---
name: self [28963,28967]
name: self [28963,28967]
===
match
---
argument [16973,16982]
argument [16973,16982]
===
match
---
name: dag [29066,29069]
name: dag [29066,29069]
===
match
---
name: test_mode [46723,46732]
name: test_mode [46723,46732]
===
match
---
operator: = [69746,69747]
operator: = [70170,70171]
===
match
---
operator: , [1787,1788]
operator: , [1787,1788]
===
match
---
simple_stmt [58373,58397]
simple_stmt [58797,58821]
===
match
---
simple_stmt [57534,57551]
simple_stmt [57958,57975]
===
match
---
return_stmt [9600,9699]
return_stmt [9600,9699]
===
match
---
name: airflow [2100,2107]
name: airflow [2100,2107]
===
match
---
number: 1 [14480,14481]
number: 1 [14480,14481]
===
match
---
name: state [11869,11874]
name: state [11869,11874]
===
match
---
simple_stmt [57506,57526]
simple_stmt [57930,57950]
===
match
---
operator: = [37540,37541]
operator: = [37540,37541]
===
match
---
name: hostname [23655,23663]
name: hostname [23655,23663]
===
match
---
name: Optional [17577,17585]
name: Optional [17577,17585]
===
match
---
string: '' [13414,13416]
string: '' [13414,13416]
===
match
---
name: self [65346,65350]
name: self [65770,65774]
===
match
---
name: session [29758,29765]
name: session [29758,29765]
===
match
---
decorated [63321,63673]
decorated [63745,64097]
===
match
---
argument [48521,48572]
argument [48521,48572]
===
match
---
operator: = [61097,61098]
operator: = [61521,61522]
===
match
---
atom_expr [54020,54029]
atom_expr [54444,54453]
===
match
---
comparison [22993,23043]
comparison [22993,23043]
===
match
---
operator: , [4888,4889]
operator: , [4888,4889]
===
match
---
operator: = [54417,54418]
operator: = [54841,54842]
===
match
---
trailer [20503,20513]
trailer [20503,20513]
===
match
---
atom_expr [32636,32649]
atom_expr [32636,32649]
===
match
---
operator: = [66590,66591]
operator: = [67014,67015]
===
match
---
name: sqlalchemy [1433,1443]
name: sqlalchemy [1433,1443]
===
match
---
simple_stmt [35023,35053]
simple_stmt [35023,35053]
===
match
---
expr_stmt [81513,81729]
expr_stmt [81937,82153]
===
match
---
name: execution_date [17121,17135]
name: execution_date [17121,17135]
===
match
---
trailer [70917,70927]
trailer [71341,71351]
===
match
---
operator: = [75812,75813]
operator: = [76236,76237]
===
match
---
suite [76461,76514]
suite [76885,76938]
===
match
---
name: COLLATION_ARGS [1880,1894]
name: COLLATION_ARGS [1880,1894]
===
match
---
trailer [61609,61613]
trailer [62033,62037]
===
match
---
trailer [79436,79451]
trailer [79860,79875]
===
match
---
name: dates_by_dag_id [8447,8462]
name: dates_by_dag_id [8447,8462]
===
match
---
name: warnings [892,900]
name: warnings [892,900]
===
match
---
name: quote [20767,20772]
name: quote [20767,20772]
===
match
---
name: refresh_from_task [24325,24342]
name: refresh_from_task [24325,24342]
===
match
---
atom_expr [56109,56134]
atom_expr [56533,56558]
===
match
---
param [4839,4847]
param [4839,4847]
===
match
---
name: items [8819,8824]
name: items [8819,8824]
===
match
---
name: Float [1306,1311]
name: Float [1306,1311]
===
match
---
trailer [26348,26357]
trailer [26348,26357]
===
match
---
string: """         Immediately runs the task (without checking or changing db state         before execution) and then sets the appropriate final state after         completion and runs any post-execute callbacks. Meant to be called         only after another function changes the state to running.          :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [44027,44713]
string: """         Immediately runs the task (without checking or changing db state         before execution) and then sets the appropriate final state after         completion and runs any post-execute callbacks. Meant to be called         only after another function changes the state to running.          :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [44027,44713]
===
match
---
decorator [26501,26511]
decorator [26501,26511]
===
match
---
parameters [57956,57962]
parameters [58380,58386]
===
match
---
fstring_end: " [20984,20985]
fstring_end: " [20984,20985]
===
match
---
operator: == [78638,78640]
operator: == [79062,79064]
===
match
---
operator: = [24994,24995]
operator: = [24994,24995]
===
match
---
operator: ** [70396,70398]
operator: ** [70820,70822]
===
match
---
name: task [52448,52452]
name: task [52757,52761]
===
match
---
atom_expr [46598,46608]
atom_expr [46598,46608]
===
match
---
name: dag_run [58981,58988]
name: dag_run [59405,59412]
===
match
---
operator: , [71940,71941]
operator: , [72364,72365]
===
match
---
operator: = [47492,47493]
operator: = [47492,47493]
===
match
---
name: self [56277,56281]
name: self [56701,56705]
===
match
---
or_test [34173,34200]
or_test [34173,34200]
===
match
---
expr_stmt [27432,27746]
expr_stmt [27432,27746]
===
match
---
arith_expr [59204,59238]
arith_expr [59628,59662]
===
match
---
test [58981,59016]
test [59405,59440]
===
match
---
name: default_conn [63660,63672]
name: default_conn [64084,64096]
===
match
---
trailer [35582,35589]
trailer [35582,35589]
===
match
---
name: delay [35023,35028]
name: delay [35023,35028]
===
match
---
comparison [77904,77922]
comparison [78328,78346]
===
match
---
simple_stmt [34651,34668]
simple_stmt [34651,34668]
===
match
---
trailer [8621,8627]
trailer [8621,8627]
===
match
---
expr_stmt [16123,16134]
expr_stmt [16123,16134]
===
match
---
trailer [55691,55697]
trailer [56115,56121]
===
match
---
name: executor_config [11560,11575]
name: executor_config [11560,11575]
===
match
---
trailer [76756,76930]
trailer [77180,77354]
===
match
---
trailer [17585,17590]
trailer [17585,17590]
===
match
---
name: context [48038,48045]
name: context [48038,48045]
===
match
---
atom_expr [20478,20516]
atom_expr [20478,20516]
===
match
---
operator: = [44928,44929]
operator: = [44928,44929]
===
match
---
trailer [26121,26169]
trailer [26121,26169]
===
match
---
simple_stmt [59826,59896]
simple_stmt [60250,60320]
===
match
---
name: end_date [80416,80424]
name: end_date [80840,80848]
===
match
---
name: task_id [19527,19534]
name: task_id [19527,19534]
===
match
---
name: str [79724,79727]
name: str [80148,80151]
===
match
---
operator: , [64047,64048]
operator: , [64471,64472]
===
match
---
argument [33626,33641]
argument [33626,33641]
===
match
---
name: task [54092,54096]
name: task [54516,54520]
===
match
---
param [34080,34097]
param [34080,34097]
===
match
---
name: Optional [30324,30332]
name: Optional [30324,30332]
===
match
---
operator: = [52822,52823]
operator: = [53246,53247]
===
match
---
name: email [57460,57465]
name: email [57884,57889]
===
match
---
operator: , [37392,37393]
operator: , [37392,37393]
===
match
---
name: provide_session [76520,76535]
name: provide_session [76944,76959]
===
match
---
name: Optional [73677,73685]
name: Optional [74101,74109]
===
match
---
string: '' [60568,60570]
string: '' [60992,60994]
===
match
---
name: ti [79669,79671]
name: ti [80093,80095]
===
match
---
with_stmt [4524,4798]
with_stmt [4524,4798]
===
match
---
trailer [20833,20858]
trailer [20833,20858]
===
match
---
arglist [45298,45311]
arglist [45298,45311]
===
match
---
trailer [5763,5774]
trailer [5763,5774]
===
match
---
name: Optional [80740,80748]
name: Optional [81164,81172]
===
match
---
atom_expr [55211,55232]
atom_expr [55635,55656]
===
match
---
argument [32562,32574]
argument [32562,32574]
===
match
---
name: state [25825,25830]
name: state [25825,25830]
===
match
---
name: datetime [80351,80359]
name: datetime [80775,80783]
===
match
---
operator: = [76279,76280]
operator: = [76703,76704]
===
match
---
operator: = [10966,10967]
operator: = [10966,10967]
===
match
---
trailer [45794,45802]
trailer [45794,45802]
===
match
---
name: DagRun [58739,58745]
name: DagRun [59163,59169]
===
match
---
string: '' [60682,60684]
string: '' [61106,61108]
===
match
---
arglist [40250,40320]
arglist [40250,40320]
===
match
---
expr_stmt [6456,6477]
expr_stmt [6456,6477]
===
match
---
name: self [44914,44918]
name: self [44914,44918]
===
match
---
operator: = [17591,17592]
operator: = [17591,17592]
===
match
---
trailer [47939,47945]
trailer [47939,47945]
===
match
---
name: task_id [46990,46997]
name: task_id [46990,46997]
===
match
---
name: NamedTemporaryFile [999,1017]
name: NamedTemporaryFile [999,1017]
===
match
---
name: session [39306,39313]
name: session [39306,39313]
===
match
---
operator: , [49857,49858]
operator: , [49857,49858]
===
match
---
simple_stmt [49507,49543]
simple_stmt [49507,49543]
===
match
---
suite [8910,9078]
suite [8910,9078]
===
match
---
dictorsetmaker [46613,46640]
dictorsetmaker [46613,46640]
===
match
---
name: func [76723,76727]
name: func [77147,77151]
===
match
---
trailer [24750,24761]
trailer [24750,24761]
===
match
---
name: job_id [23747,23753]
name: job_id [23747,23753]
===
match
---
funcdef [53938,54170]
funcdef [54362,54594]
===
match
---
name: execution_date [81680,81694]
name: execution_date [82104,82118]
===
match
---
name: self [16571,16575]
name: self [16571,16575]
===
match
---
name: iso [20619,20622]
name: iso [20619,20622]
===
match
---
argument [53186,53217]
argument [53610,53641]
===
match
---
name: dagrun [58725,58731]
name: dagrun [59149,59155]
===
match
---
atom_expr [71914,71968]
atom_expr [72338,72392]
===
match
---
trailer [40211,40232]
trailer [40211,40232]
===
match
---
simple_stmt [25258,25295]
simple_stmt [25258,25295]
===
match
---
trailer [4935,4942]
trailer [4935,4942]
===
match
---
argument [16864,16883]
argument [16864,16883]
===
match
---
atom_expr [12100,12126]
atom_expr [12100,12126]
===
match
---
trailer [37717,37722]
trailer [37717,37722]
===
match
---
atom_expr [79696,79713]
atom_expr [80120,80137]
===
match
---
atom_expr [34352,34587]
atom_expr [34352,34587]
===
match
---
name: raw [20189,20192]
name: raw [20189,20192]
===
match
---
atom_expr [76709,76952]
atom_expr [77133,77376]
===
match
---
simple_stmt [79511,79550]
simple_stmt [79935,79974]
===
match
---
comparison [26266,26294]
comparison [26266,26294]
===
match
---
import_name [1150,1161]
import_name [1150,1161]
===
match
---
atom_expr [46247,46269]
atom_expr [46247,46269]
===
match
---
name: plugins_manager [2207,2222]
name: plugins_manager [2207,2222]
===
match
---
trailer [4447,4463]
trailer [4447,4463]
===
match
---
simple_stmt [77074,77098]
simple_stmt [77498,77522]
===
match
---
name: cfg_path [20357,20365]
name: cfg_path [20357,20365]
===
match
---
atom_expr [65731,65740]
atom_expr [66155,66164]
===
match
---
name: task_id [34745,34752]
name: task_id [34745,34752]
===
match
---
name: get [62617,62620]
name: get [63041,63044]
===
match
---
simple_stmt [13425,13445]
simple_stmt [13425,13445]
===
match
---
atom_expr [20096,20119]
atom_expr [20096,20119]
===
match
---
comparison [29428,29447]
comparison [29428,29447]
===
match
---
trailer [56055,56100]
trailer [56479,56524]
===
match
---
operator: , [1065,1066]
operator: , [1065,1066]
===
match
---
operator: = [33663,33664]
operator: = [33663,33664]
===
match
---
operator: == [5483,5485]
operator: == [5483,5485]
===
match
---
operator: = [9071,9072]
operator: = [9071,9072]
===
match
---
decorator [77103,77117]
decorator [77527,77541]
===
match
---
atom_expr [19667,19681]
atom_expr [19667,19681]
===
match
---
name: get_hostname [39390,39402]
name: get_hostname [39390,39402]
===
match
---
name: failed [33656,33662]
name: failed [33656,33662]
===
match
---
trailer [32338,32343]
trailer [32338,32343]
===
match
---
operator: = [60431,60432]
operator: = [60855,60856]
===
match
---
tfpdef [43874,43895]
tfpdef [43874,43895]
===
match
---
name: str [16451,16454]
name: str [16451,16454]
===
match
---
trailer [49845,49855]
trailer [49845,49855]
===
match
---
atom_expr [57784,57877]
atom_expr [58208,58301]
===
match
---
atom_expr [80770,80791]
atom_expr [81194,81215]
===
match
---
operator: , [17013,17014]
operator: , [17013,17014]
===
match
---
name: Union [4442,4447]
name: Union [4442,4447]
===
match
---
param [4062,4075]
param [4062,4075]
===
match
---
expr_stmt [11457,11490]
expr_stmt [11457,11490]
===
match
---
expr_stmt [11244,11286]
expr_stmt [11244,11286]
===
match
---
funcdef [9705,9928]
funcdef [9705,9928]
===
match
---
trailer [6033,6044]
trailer [6033,6044]
===
match
---
trailer [47271,47278]
trailer [47271,47278]
===
match
---
param [25837,25849]
param [25837,25849]
===
match
---
trailer [42034,42038]
trailer [42034,42038]
===
match
---
name: dep [34285,34288]
name: dep [34285,34288]
===
match
---
name: _CURRENT_CONTEXT [3682,3698]
name: _CURRENT_CONTEXT [3682,3698]
===
match
---
name: session [44860,44867]
name: session [44860,44867]
===
match
---
if_stmt [54361,54394]
if_stmt [54785,54818]
===
match
---
trailer [46957,47013]
trailer [46957,47013]
===
match
---
expr_stmt [59826,59895]
expr_stmt [60250,60319]
===
match
---
name: Optional [31491,31499]
name: Optional [31491,31499]
===
match
---
operator: -> [80589,80591]
operator: -> [81013,81015]
===
match
---
atom_expr [34471,34490]
atom_expr [34471,34490]
===
match
---
name: self [42415,42419]
name: self [42415,42419]
===
match
---
name: try_number [80497,80507]
name: try_number [80921,80931]
===
match
---
atom_expr [24746,24761]
atom_expr [24746,24761]
===
match
---
name: Dict [1061,1065]
name: Dict [1061,1065]
===
match
---
operator: = [23664,23665]
operator: = [23664,23665]
===
match
---
operator: { [46612,46613]
operator: { [46612,46613]
===
match
---
simple_stmt [56017,56037]
simple_stmt [56441,56461]
===
match
---
operator: = [16952,16953]
operator: = [16952,16953]
===
match
---
operator: , [62723,62724]
operator: , [63147,63148]
===
match
---
name: dag_id [45111,45117]
name: dag_id [45111,45117]
===
match
---
name: SUCCESS [45399,45406]
name: SUCCESS [45399,45406]
===
match
---
name: airflow [1560,1567]
name: airflow [1560,1567]
===
match
---
atom_expr [22943,22963]
atom_expr [22943,22963]
===
match
---
param [30929,30953]
param [30929,30953]
===
match
---
trailer [9045,9070]
trailer [9045,9070]
===
match
---
name: state [26303,26308]
name: state [26303,26308]
===
match
---
name: _update_ti_state_for_sensing [49512,49540]
name: _update_ti_state_for_sensing [49512,49540]
===
match
---
atom_expr [48842,48880]
atom_expr [48842,48880]
===
match
---
suite [51164,51438]
suite [51164,51438]
===
match
---
argument [68220,68302]
argument [68644,68726]
===
match
---
strings [8061,8182]
strings [8061,8182]
===
match
---
name: info [45701,45705]
name: info [45701,45705]
===
match
---
atom_expr [37213,37234]
atom_expr [37213,37234]
===
match
---
atom_expr [26435,26450]
atom_expr [26435,26450]
===
match
---
name: ti [5764,5766]
name: ti [5764,5766]
===
match
---
arglist [33601,33641]
arglist [33601,33641]
===
match
---
operator: = [23579,23580]
operator: = [23579,23580]
===
match
---
param [52606,52643]
param [53030,53067]
===
match
---
decorator [30816,30833]
decorator [30816,30833]
===
match
---
funcdef [34046,34668]
funcdef [34046,34668]
===
match
---
name: error [57810,57815]
name: error [58234,58239]
===
match
---
name: extend [20153,20159]
name: extend [20153,20159]
===
match
---
name: TaskInstance [76880,76892]
name: TaskInstance [77304,77316]
===
match
---
string: 'webserver' [20545,20556]
string: 'webserver' [20545,20556]
===
match
---
trailer [50165,50172]
trailer [50165,50172]
===
match
---
atom_expr [66802,66877]
atom_expr [67226,67301]
===
match
---
operator: -> [55380,55382]
operator: -> [55804,55806]
===
match
---
atom [65860,65900]
atom [66284,66324]
===
match
---
name: context [3706,3713]
name: context [3706,3713]
===
match
---
string: '%Y%m%dT%H%M%S' [43209,43224]
string: '%Y%m%dT%H%M%S' [43209,43224]
===
match
---
name: context [48724,48731]
name: context [48724,48731]
===
match
---
atom_expr [37238,37257]
atom_expr [37238,37257]
===
match
---
trailer [7742,7748]
trailer [7742,7748]
===
match
---
argument [51067,51079]
argument [51067,51079]
===
match
---
trailer [11257,11286]
trailer [11257,11286]
===
match
---
expr_stmt [5368,5443]
expr_stmt [5368,5443]
===
match
---
trailer [46847,46862]
trailer [46847,46862]
===
match
---
param [12353,12358]
param [12353,12358]
===
match
---
atom_expr [24907,24919]
atom_expr [24907,24919]
===
match
---
atom_expr [67257,67274]
atom_expr [67681,67698]
===
match
---
name: are_dependencies_met [41549,41569]
name: are_dependencies_met [41549,41569]
===
match
---
name: execution_date [21697,21711]
name: execution_date [21697,21711]
===
match
---
name: force_fail [57239,57249]
name: force_fail [57663,57673]
===
match
---
dotted_name [1963,1981]
dotted_name [1963,1981]
===
match
---
operator: , [10765,10766]
operator: , [10765,10766]
===
match
---
simple_stmt [10716,10785]
simple_stmt [10716,10785]
===
match
---
name: email_on_retry [57164,57178]
name: email_on_retry [57588,57602]
===
match
---
trailer [48218,48245]
trailer [48218,48245]
===
match
---
string: "rendering of template_fields." [66242,66273]
string: "rendering of template_fields." [66666,66697]
===
match
---
simple_stmt [79460,79503]
simple_stmt [79884,79927]
===
match
---
operator: , [43506,43507]
operator: , [43506,43507]
===
match
---
name: State [52233,52238]
name: State [52517,52522]
===
match
---
name: test_mode [44752,44761]
name: test_mode [44752,44761]
===
match
---
name: job_id [39350,39356]
name: job_id [39350,39356]
===
match
---
param [57619,57624]
param [58043,58048]
===
match
---
name: priority_weight_total [24816,24837]
name: priority_weight_total [24816,24837]
===
match
---
name: execute [7777,7784]
name: execute [7777,7784]
===
match
---
argument [75693,75707]
argument [76117,76131]
===
match
---
name: self [58226,58230]
name: self [58650,58654]
===
match
---
argument [57914,57925]
argument [58338,58349]
===
match
---
name: task_id [29741,29748]
name: task_id [29741,29748]
===
match
---
operator: , [63776,63777]
operator: , [64200,64201]
===
match
---
name: fd [4603,4605]
name: fd [4603,4605]
===
match
---
tfpdef [63372,63381]
tfpdef [63796,63805]
===
match
---
string: 'ti_failures' [56120,56133]
string: 'ti_failures' [56544,56557]
===
match
---
name: merge [26484,26489]
name: merge [26484,26489]
===
match
---
trailer [35517,35781]
trailer [35517,35781]
===
match
---
name: self [65574,65578]
name: self [65998,66002]
===
match
---
subscriptlist [4448,4462]
subscriptlist [4448,4462]
===
match
---
trailer [76190,76204]
trailer [76614,76628]
===
match
---
atom_expr [11585,11609]
atom_expr [11585,11609]
===
match
---
simple_stmt [60926,60953]
simple_stmt [61350,61377]
===
match
---
name: property [80560,80568]
name: property [80984,80992]
===
match
---
name: AirflowException [1631,1647]
name: AirflowException [1631,1647]
===
match
---
operator: = [53243,53244]
operator: = [53667,53668]
===
match
---
name: task_copy [50859,50868]
name: task_copy [50859,50868]
===
match
---
string: 'kcah_acitats' [81899,81913]
string: 'kcah_acitats' [82323,82337]
===
match
---
trailer [78206,78270]
trailer [78630,78694]
===
match
---
name: update [69927,69933]
name: update [70351,70357]
===
match
---
return_stmt [71255,71316]
return_stmt [71679,71740]
===
match
---
parameters [80978,80984]
parameters [81402,81408]
===
match
---
operator: = [71129,71130]
operator: = [71553,71554]
===
match
---
return_stmt [76688,76962]
return_stmt [77112,77386]
===
match
---
suite [54297,55136]
suite [54721,55560]
===
match
---
name: test_mode [56150,56159]
name: test_mode [56574,56583]
===
match
---
dictorsetmaker [63703,65297]
dictorsetmaker [64127,65721]
===
match
---
trailer [4595,4606]
trailer [4595,4606]
===
match
---
name: self [52359,52363]
name: self [52643,52647]
===
match
---
atom_expr [23904,23922]
atom_expr [23904,23922]
===
match
---
trailer [71236,71238]
trailer [71660,71662]
===
match
---
comparison [37213,37257]
comparison [37213,37257]
===
match
---
operator: { [63689,63690]
operator: { [64113,64114]
===
match
---
operator: , [41297,41298]
operator: , [41297,41298]
===
match
---
name: self [46598,46602]
name: self [46598,46602]
===
match
---
name: self [9471,9475]
name: self [9471,9475]
===
match
---
trailer [31299,31315]
trailer [31299,31315]
===
match
---
atom_expr [5516,5525]
atom_expr [5516,5525]
===
match
---
argument [30730,30742]
argument [30730,30742]
===
match
---
atom_expr [23744,23753]
atom_expr [23744,23753]
===
match
---
dotted_name [2199,2222]
dotted_name [2199,2222]
===
match
---
param [51134,51139]
param [51134,51139]
===
match
---
argument [30210,30222]
argument [30210,30222]
===
match
---
operator: == [51730,51732]
operator: == [51730,51732]
===
match
---
annassign [79840,79855]
annassign [80264,80279]
===
match
---
atom_expr [42616,42635]
atom_expr [42616,42635]
===
match
---
name: UP_FOR_RETRY [52239,52251]
name: UP_FOR_RETRY [52523,52535]
===
match
---
name: property [9934,9942]
name: property [9934,9942]
===
match
---
operator: , [62386,62387]
operator: , [62810,62811]
===
match
---
name: property [80480,80488]
name: property [80904,80912]
===
match
---
name: Tuple [79117,79122]
name: Tuple [79541,79546]
===
match
---
atom_expr [76108,76122]
atom_expr [76532,76546]
===
match
---
operator: , [25411,25412]
operator: , [25411,25412]
===
match
---
name: dag [28220,28223]
name: dag [28220,28223]
===
match
---
atom_expr [57097,57107]
atom_expr [57521,57531]
===
match
---
name: yesterday_ds [60733,60745]
name: yesterday_ds [61157,61169]
===
match
---
atom_expr [55907,55940]
atom_expr [56331,56364]
===
match
---
suite [55890,55941]
suite [56314,56365]
===
match
---
operator: ** [10820,10822]
operator: ** [10820,10822]
===
match
---
name: priority_weight [23907,23922]
name: priority_weight [23907,23922]
===
match
---
trailer [39906,40187]
trailer [39906,40187]
===
match
---
trailer [78892,78899]
trailer [79316,79323]
===
match
---
classdef [62913,63673]
classdef [63337,64097]
===
match
---
name: result [50999,51005]
name: result [50999,51005]
===
match
---
simple_stmt [8594,8888]
simple_stmt [8594,8888]
===
match
---
operator: = [72408,72409]
operator: = [72832,72833]
===
match
---
name: Tuple [9288,9293]
name: Tuple [9288,9293]
===
match
---
operator: = [11538,11539]
operator: = [11538,11539]
===
match
---
operator: = [34171,34172]
operator: = [34171,34172]
===
match
---
name: var [61557,61560]
name: var [61981,61984]
===
match
---
name: DepContext [39896,39906]
name: DepContext [39896,39906]
===
match
---
name: Union [4909,4914]
name: Union [4909,4914]
===
match
---
name: api_client [3051,3061]
name: api_client [3051,3061]
===
match
---
name: provide_session [66305,66320]
name: provide_session [66729,66744]
===
match
---
name: Optional [27949,27957]
name: Optional [27949,27957]
===
match
---
atom_expr [52005,52018]
atom_expr [52147,52160]
===
match
---
simple_stmt [6533,6551]
simple_stmt [6533,6551]
===
match
---
name: Union [57640,57645]
name: Union [58064,58069]
===
match
---
name: dag [16221,16224]
name: dag [16221,16224]
===
match
---
operator: , [42331,42332]
operator: , [42331,42332]
===
match
---
arglist [4211,4225]
arglist [4211,4225]
===
match
---
if_stmt [48839,49543]
if_stmt [48839,49543]
===
match
---
annassign [79885,79907]
annassign [80309,80331]
===
match
---
simple_stmt [11215,11240]
simple_stmt [11215,11240]
===
match
---
argument [78392,78421]
argument [78816,78845]
===
match
---
name: dt [28857,28859]
name: dt [28857,28859]
===
match
---
name: self [16545,16549]
name: self [16545,16549]
===
match
---
sync_comp_for [48532,48572]
sync_comp_for [48532,48572]
===
match
---
suite [81758,81806]
suite [82182,82230]
===
match
---
trailer [81803,81805]
trailer [82227,82229]
===
match
---
name: ti [24189,24191]
name: ti [24189,24191]
===
match
---
operator: } [34752,34753]
operator: } [34752,34753]
===
match
---
import_from [66433,66503]
import_from [66857,66927]
===
match
---
name: e [46302,46303]
name: e [46302,46303]
===
match
---
name: Column [11003,11009]
name: Column [11003,11009]
===
match
---
name: timeout [2995,3002]
name: timeout [2995,3002]
===
match
---
operator: = [68719,68720]
operator: = [69143,69144]
===
match
---
operator: , [12321,12322]
operator: , [12321,12322]
===
match
---
trailer [53474,53487]
trailer [53898,53911]
===
match
---
operator: , [64648,64649]
operator: , [65072,65073]
===
match
---
atom_expr [25727,25739]
atom_expr [25727,25739]
===
match
---
name: self [79290,79294]
name: self [79714,79718]
===
match
---
trailer [12787,12791]
trailer [12787,12791]
===
match
---
trailer [20209,20216]
trailer [20209,20216]
===
match
---
name: State [76902,76907]
name: State [77326,77331]
===
match
---
operator: = [53481,53482]
operator: = [53905,53906]
===
match
---
name: session [42131,42138]
name: session [42131,42138]
===
match
---
operator: , [46864,46865]
operator: , [46864,46865]
===
match
---
string: "%s" [55698,55702]
string: "%s" [56122,56126]
===
match
---
operator: = [16616,16617]
operator: = [16616,16617]
===
match
---
sync_comp_for [8782,8826]
sync_comp_for [8782,8826]
===
match
---
atom_expr [43134,43159]
atom_expr [43134,43159]
===
match
---
name: session [53716,53723]
name: session [54140,54147]
===
match
---
operator: , [30684,30685]
operator: , [30684,30685]
===
match
---
operator: @ [80398,80399]
operator: @ [80822,80823]
===
match
---
operator: , [43655,43656]
operator: , [43655,43656]
===
match
---
argument [61075,61088]
argument [61499,61512]
===
match
---
param [76989,76994]
param [77413,77418]
===
match
---
name: TaskInstance [27505,27517]
name: TaskInstance [27505,27517]
===
match
---
expr_stmt [6490,6520]
expr_stmt [6490,6520]
===
match
---
name: state [22191,22196]
name: state [22191,22196]
===
match
---
simple_stmt [82024,82065]
simple_stmt [82448,82489]
===
match
---
trailer [68271,68302]
trailer [68695,68726]
===
match
---
trailer [58684,58691]
trailer [59108,59115]
===
match
---
operator: = [15568,15569]
operator: = [15568,15569]
===
match
---
atom_expr [81899,81927]
atom_expr [82323,82351]
===
match
---
operator: , [15467,15468]
operator: , [15467,15468]
===
match
---
name: self [20418,20422]
name: self [20418,20422]
===
match
---
simple_stmt [11457,11491]
simple_stmt [11457,11491]
===
match
---
name: task [45120,45124]
name: task [45120,45124]
===
match
---
simple_stmt [55397,55439]
simple_stmt [55821,55863]
===
match
---
operator: = [24709,24710]
operator: = [24709,24710]
===
match
---
name: dag_id [11906,11912]
name: dag_id [11906,11912]
===
match
---
if_stmt [42842,43055]
if_stmt [42842,43055]
===
match
---
name: deps [39924,39928]
name: deps [39924,39928]
===
match
---
funcdef [68456,71610]
funcdef [68880,72034]
===
match
---
trailer [67169,67174]
trailer [67593,67598]
===
match
---
expr_stmt [58502,58513]
expr_stmt [58926,58937]
===
match
---
simple_stmt [31000,31216]
simple_stmt [31000,31216]
===
match
---
name: init_on_load [13740,13752]
name: init_on_load [13740,13752]
===
match
---
atom_expr [78592,78795]
atom_expr [79016,79219]
===
match
---
name: ignore_task_deps [16705,16721]
name: ignore_task_deps [16705,16721]
===
match
---
simple_stmt [44027,44714]
simple_stmt [44027,44714]
===
match
---
name: execution_date [20778,20792]
name: execution_date [20778,20792]
===
match
---
decorator [22270,22287]
decorator [22270,22287]
===
match
---
name: _start_date [79465,79476]
name: _start_date [79889,79900]
===
match
---
name: tis [8359,8362]
name: tis [8359,8362]
===
match
---
name: fd [4794,4796]
name: fd [4794,4796]
===
match
---
trailer [60448,60457]
trailer [60872,60881]
===
match
---
operator: - [70878,70879]
operator: - [71302,71303]
===
match
---
string: """Get Airflow Variable value""" [61866,61898]
string: """Get Airflow Variable value""" [62290,62322]
===
match
---
atom_expr [24728,24737]
atom_expr [24728,24737]
===
match
---
operator: , [1093,1094]
operator: , [1093,1094]
===
match
---
param [72373,72415]
param [72797,72839]
===
match
---
name: exception [70769,70778]
name: exception [71193,71202]
===
match
---
name: defaultdict [925,936]
name: defaultdict [925,936]
===
match
---
name: models [37060,37066]
name: models [37060,37066]
===
match
---
atom_expr [70733,70946]
atom_expr [71157,71370]
===
match
---
name: queued_by_job_id [11495,11511]
name: queued_by_job_id [11495,11511]
===
match
---
simple_stmt [25691,25779]
simple_stmt [25691,25779]
===
match
---
simple_stmt [5351,5364]
simple_stmt [5351,5364]
===
match
---
argument [70903,70927]
argument [71327,71351]
===
match
---
operator: , [1364,1365]
operator: , [1364,1365]
===
match
---
name: update [48613,48619]
name: update [48613,48619]
===
match
---
atom_expr [23847,23857]
atom_expr [23847,23857]
===
match
---
trailer [57101,57107]
trailer [57525,57531]
===
match
---
expr_stmt [49638,49685]
expr_stmt [49638,49685]
===
match
---
comparison [81567,81602]
comparison [81991,82026]
===
match
---
if_stmt [8993,9078]
if_stmt [8993,9078]
===
match
---
atom_expr [50051,50061]
atom_expr [50051,50061]
===
match
---
argument [57817,57836]
argument [58241,58260]
===
match
---
name: session [57747,57754]
name: session [58171,58178]
===
match
---
parameters [61402,61408]
parameters [61826,61832]
===
match
---
suite [6659,7797]
suite [6659,7797]
===
match
---
name: executor_config [24112,24127]
name: executor_config [24112,24127]
===
match
---
trailer [60803,60811]
trailer [61227,61235]
===
match
---
argument [40899,40914]
argument [40899,40914]
===
match
---
name: default [11096,11103]
name: default [11096,11103]
===
match
---
name: property [80798,80806]
name: property [81222,81230]
===
match
---
if_stmt [71070,71239]
if_stmt [71494,71663]
===
match
---
suite [45675,45709]
suite [45675,45709]
===
match
---
name: send_email [71914,71924]
name: send_email [72338,72348]
===
match
---
simple_stmt [1958,1993]
simple_stmt [1958,1993]
===
match
---
trailer [61556,61560]
trailer [61980,61984]
===
match
---
trailer [22781,22787]
trailer [22781,22787]
===
match
---
name: conf [71073,71077]
name: conf [71497,71501]
===
match
---
if_stmt [20186,20228]
if_stmt [20186,20228]
===
match
---
name: Environment [70210,70221]
name: Environment [70634,70645]
===
match
---
argument [53716,53731]
argument [54140,54155]
===
match
---
funcdef [24321,25011]
funcdef [24321,25011]
===
match
---
name: job [7877,7880]
name: job [7877,7880]
===
match
---
param [25819,25824]
param [25819,25824]
===
match
---
import_from [2716,2782]
import_from [2716,2782]
===
match
---
name: self [22122,22126]
name: self [22122,22126]
===
match
---
name: ApiClient [68378,68387]
name: ApiClient [68802,68811]
===
match
---
if_stmt [56931,57179]
if_stmt [57355,57603]
===
match
---
param [51140,51157]
param [51140,51157]
===
match
---
parameters [37378,37758]
parameters [37378,37758]
===
match
---
name: error [57352,57357]
name: error [57776,57781]
===
match
---
name: enrich_errors [43746,43759]
name: enrich_errors [43746,43759]
===
match
---
simple_stmt [20525,20570]
simple_stmt [20525,20570]
===
match
---
name: str [79842,79845]
name: str [80266,80269]
===
match
---
name: default_html_content_err [69354,69378]
name: default_html_content_err [69778,69802]
===
match
---
if_stmt [69704,71554]
if_stmt [70128,71978]
===
match
---
name: __init__ [12431,12439]
name: __init__ [12431,12439]
===
match
---
comparison [27505,27539]
comparison [27505,27539]
===
match
---
atom_expr [67088,67175]
atom_expr [67512,67599]
===
match
---
trailer [78879,78951]
trailer [79303,79375]
===
match
---
atom_expr [43669,43700]
atom_expr [43669,43700]
===
match
---
name: loader [70239,70245]
name: loader [70663,70669]
===
match
---
operator: , [62359,62360]
operator: , [62783,62784]
===
match
---
name: self [24788,24792]
name: self [24788,24792]
===
match
---
trailer [7891,7897]
trailer [7891,7897]
===
match
---
name: delete_old_records [48200,48218]
name: delete_old_records [48200,48218]
===
match
---
name: key [71098,71101]
name: key [71522,71525]
===
match
---
name: _execution_date [80292,80307]
name: _execution_date [80716,80731]
===
match
---
trailer [29603,29623]
trailer [29603,29623]
===
match
---
name: next_ds_nodash [60011,60025]
name: next_ds_nodash [60435,60449]
===
match
---
import_from [2826,2875]
import_from [2826,2875]
===
match
---
simple_stmt [54087,54109]
simple_stmt [54511,54533]
===
match
---
decorated [17030,20387]
decorated [17030,20387]
===
match
---
number: 1 [49862,49863]
number: 1 [49862,49863]
===
match
---
operator: , [67152,67153]
operator: , [67576,67577]
===
match
---
simple_stmt [53445,53488]
simple_stmt [53869,53912]
===
match
---
exprlist [48536,48540]
exprlist [48536,48540]
===
match
---
name: Proxy [64367,64372]
name: Proxy [64791,64796]
===
match
---
name: self [22967,22971]
name: self [22967,22971]
===
match
---
name: _execute_task [49652,49665]
name: _execute_task [49652,49665]
===
match
---
simple_stmt [24266,24316]
simple_stmt [24266,24316]
===
match
---
funcdef [3457,4040]
funcdef [3457,4040]
===
match
---
atom_expr [45120,45132]
atom_expr [45120,45132]
===
match
---
name: info [42387,42391]
name: info [42387,42391]
===
match
---
name: task [51944,51948]
name: task [51969,51973]
===
match
---
operator: , [49078,49079]
operator: , [49078,49079]
===
match
---
expr_stmt [10679,10710]
expr_stmt [10679,10710]
===
match
---
operator: = [72200,72201]
operator: = [72624,72625]
===
match
---
name: task [59848,59852]
name: task [60272,60276]
===
match
---
atom [19972,20000]
atom [19972,20000]
===
match
---
atom_expr [79361,79374]
atom_expr [79785,79798]
===
match
---
trailer [34243,34248]
trailer [34243,34248]
===
match
---
name: try_number [70851,70861]
name: try_number [71275,71285]
===
match
---
operator: = [28744,28745]
operator: = [28744,28745]
===
match
---
name: ds [63796,63798]
name: ds [64220,64222]
===
match
---
name: is_eligible_to_retry [56957,56977]
name: is_eligible_to_retry [57381,57401]
===
match
---
simple_stmt [46843,46900]
simple_stmt [46843,46900]
===
match
---
trailer [64430,64451]
trailer [64854,64875]
===
match
---
try_stmt [28498,28841]
try_stmt [28498,28841]
===
match
---
string: '' [43286,43288]
string: '' [43286,43288]
===
match
---
name: max [6401,6404]
name: max [6401,6404]
===
match
---
name: pool_slots [23819,23829]
name: pool_slots [23819,23829]
===
match
---
atom_expr [12783,12945]
atom_expr [12783,12945]
===
match
---
simple_stmt [55013,55033]
simple_stmt [55437,55457]
===
match
---
name: self [43622,43626]
name: self [43622,43626]
===
match
---
string: 'start_date' [43642,43654]
string: 'start_date' [43642,43654]
===
match
---
atom_expr [61426,61434]
atom_expr [61850,61858]
===
match
---
name: DeprecationWarning [32530,32548]
name: DeprecationWarning [32530,32548]
===
match
---
name: task [24811,24815]
name: task [24811,24815]
===
match
---
import_from [2038,2094]
import_from [2038,2094]
===
match
---
argument [64431,64450]
argument [64855,64874]
===
match
---
name: execution_date [78741,78755]
name: execution_date [79165,79179]
===
match
---
trailer [33505,33509]
trailer [33505,33509]
===
match
---
argument [39298,39313]
argument [39298,39313]
===
match
---
name: airflow [47407,47414]
name: airflow [47407,47414]
===
match
---
name: task [52064,52068]
name: task [52206,52210]
===
match
---
arglist [67837,67862]
arglist [68261,68286]
===
match
---
param [67501,67505]
param [67925,67929]
===
match
---
name: send_email [71825,71835]
name: send_email [72249,72259]
===
match
---
simple_stmt [80369,80393]
simple_stmt [80793,80817]
===
match
---
name: path [16400,16404]
name: path [16400,16404]
===
match
---
atom_expr [3272,3286]
atom_expr [3272,3286]
===
match
---
trailer [12428,12430]
trailer [12428,12430]
===
match
---
name: provide_session [57557,57572]
name: provide_session [57981,57996]
===
match
---
parameters [36861,36892]
parameters [36861,36892]
===
match
---
name: start_date [10920,10930]
name: start_date [10920,10930]
===
match
---
expr_stmt [79460,79502]
expr_stmt [79884,79926]
===
match
---
trailer [8871,8875]
trailer [8871,8875]
===
match
---
name: execution_date [31399,31413]
name: execution_date [31399,31413]
===
match
---
arglist [78313,78478]
arglist [78737,78902]
===
match
---
name: bool [37495,37499]
name: bool [37495,37499]
===
match
---
arith_expr [15227,15247]
arith_expr [15227,15247]
===
match
---
trailer [6619,6623]
trailer [6619,6623]
===
match
---
trailer [24270,24274]
trailer [24270,24274]
===
match
---
name: session [42616,42623]
name: session [42616,42623]
===
match
---
operator: = [24809,24810]
operator: = [24809,24810]
===
match
---
param [52838,52865]
param [53262,53289]
===
match
---
return_stmt [9386,9439]
return_stmt [9386,9439]
===
match
---
name: self [42333,42337]
name: self [42333,42337]
===
match
---
trailer [52470,52479]
trailer [52779,52788]
===
match
---
name: dag_id [73491,73497]
name: dag_id [73915,73921]
===
match
---
name: subject [71853,71860]
name: subject [72277,72284]
===
match
---
name: execution_date [12359,12373]
name: execution_date [12359,12373]
===
match
---
operator: = [41443,41444]
operator: = [41443,41444]
===
match
---
funcdef [27852,29788]
funcdef [27852,29788]
===
match
---
suite [12770,13232]
suite [12770,13232]
===
match
---
arith_expr [9678,9697]
arith_expr [9678,9697]
===
match
---
name: execution_date [7275,7289]
name: execution_date [7275,7289]
===
match
---
operator: , [8792,8793]
operator: , [8792,8793]
===
match
---
and_test [12709,12769]
and_test [12709,12769]
===
match
---
simple_stmt [34008,34020]
simple_stmt [34008,34020]
===
match
---
name: datetime [9304,9312]
name: datetime [9304,9312]
===
match
---
name: expunge_all [59037,59048]
name: expunge_all [59461,59472]
===
match
---
trailer [43038,43053]
trailer [43038,43053]
===
match
---
name: with_for_update [81780,81795]
name: with_for_update [82204,82219]
===
match
---
suite [29829,30272]
suite [29829,30272]
===
match
---
operator: = [71338,71339]
operator: = [71762,71763]
===
match
---
simple_stmt [1176,1201]
simple_stmt [1176,1201]
===
match
---
name: error [53920,53925]
name: error [54344,54349]
===
match
---
name: self [16520,16524]
name: self [16520,16524]
===
match
---
operator: , [60757,60758]
operator: , [61181,61182]
===
match
---
parameters [72311,72454]
parameters [72735,72878]
===
match
---
trailer [60106,60115]
trailer [60530,60539]
===
match
---
name: html_content_err [70520,70536]
name: html_content_err [70944,70960]
===
match
---
simple_stmt [19444,19477]
simple_stmt [19444,19477]
===
match
---
operator: = [53360,53361]
operator: = [53784,53785]
===
match
---
name: strftime [43200,43208]
name: strftime [43200,43208]
===
match
---
trailer [36387,36421]
trailer [36387,36421]
===
match
---
trailer [42112,42114]
trailer [42112,42114]
===
match
---
name: _pool [79835,79840]
name: _pool [80259,80264]
===
match
---
atom_expr [49836,49855]
atom_expr [49836,49855]
===
match
---
name: job_id [17493,17499]
name: job_id [17493,17499]
===
match
---
operator: = [10909,10910]
operator: = [10909,10910]
===
match
---
atom_expr [3306,3319]
atom_expr [3306,3319]
===
match
---
simple_stmt [58662,58693]
simple_stmt [59086,59117]
===
match
---
name: List [17608,17612]
name: List [17608,17612]
===
match
---
try_stmt [57314,57467]
try_stmt [57738,57891]
===
match
---
atom_expr [27949,27973]
atom_expr [27949,27973]
===
match
---
trailer [48564,48570]
trailer [48564,48570]
===
match
---
name: provide_session [37315,37330]
name: provide_session [37315,37330]
===
match
---
name: dag_id [43525,43531]
name: dag_id [43525,43531]
===
match
---
argument [70396,70411]
argument [70820,70835]
===
match
---
trailer [68027,68029]
trailer [68451,68453]
===
match
---
import_from [2449,2490]
import_from [2449,2490]
===
match
---
name: self [62530,62534]
name: self [62954,62958]
===
match
---
name: replace [60804,60811]
name: replace [61228,61235]
===
match
---
trailer [12586,12591]
trailer [12586,12591]
===
match
---
atom_expr [6405,6417]
atom_expr [6405,6417]
===
match
---
trailer [76209,76217]
trailer [76633,76641]
===
match
---
expr_stmt [67669,67695]
expr_stmt [68093,68119]
===
match
---
name: models [1922,1928]
name: models [1922,1928]
===
match
---
param [4852,4875]
param [4852,4875]
===
match
---
trailer [8709,8716]
trailer [8709,8716]
===
match
---
trailer [67092,67096]
trailer [67516,67520]
===
match
---
trailer [72115,72124]
trailer [72539,72548]
===
match
---
funcdef [20688,21124]
funcdef [20688,21124]
===
match
---
simple_stmt [60416,60458]
simple_stmt [60840,60882]
===
match
---
atom_expr [81001,81022]
atom_expr [81425,81446]
===
match
---
name: verbose [53014,53021]
name: verbose [53438,53445]
===
match
---
trailer [60440,60448]
trailer [60864,60872]
===
match
---
atom_expr [37141,37279]
atom_expr [37141,37279]
===
match
---
arglist [69977,70146]
arglist [70401,70570]
===
match
---
operator: , [50337,50338]
operator: , [50337,50338]
===
match
---
tfpdef [52606,52634]
tfpdef [53030,53058]
===
match
---
name: unixname [23695,23703]
name: unixname [23695,23703]
===
match
---
simple_stmt [857,871]
simple_stmt [857,871]
===
match
---
fstring_end: ' [49856,49857]
fstring_end: ' [49856,49857]
===
match
---
operator: = [52946,52947]
operator: = [53370,53371]
===
match
---
string: 'ts' [64931,64935]
string: 'ts' [65355,65359]
===
match
---
name: datetime [12375,12383]
name: datetime [12375,12383]
===
match
---
name: execution_date [73104,73118]
name: execution_date [73528,73542]
===
match
---
string: "--local" [20108,20117]
string: "--local" [20108,20117]
===
match
---
for_stmt [5448,6636]
for_stmt [5448,6636]
===
match
---
trailer [81795,81797]
trailer [82219,82221]
===
match
---
trailer [37277,37279]
trailer [37277,37279]
===
match
---
suite [61139,61966]
suite [61563,62390]
===
match
---
except_clause [45811,45868]
except_clause [45811,45868]
===
match
---
operator: = [22346,22347]
operator: = [22346,22347]
===
match
---
simple_stmt [39374,39405]
simple_stmt [39374,39405]
===
match
---
tfpdef [17155,17173]
tfpdef [17155,17173]
===
match
---
name: scalar [76944,76950]
name: scalar [77368,77374]
===
match
---
name: path [16423,16427]
name: path [16423,16427]
===
match
---
name: task [27578,27582]
name: task [27578,27582]
===
match
---
name: subject [71942,71949]
name: subject [72366,72373]
===
match
---
if_stmt [66608,66885]
if_stmt [67032,67309]
===
match
---
name: render_template_fields [67440,67462]
name: render_template_fields [67864,67886]
===
match
---
simple_stmt [10861,10916]
simple_stmt [10861,10916]
===
match
---
atom_expr [35642,35661]
atom_expr [35642,35661]
===
match
---
name: task_id [43550,43557]
name: task_id [43550,43557]
===
match
---
expr_stmt [44722,44738]
expr_stmt [44722,44738]
===
match
---
atom_expr [43023,43032]
atom_expr [43023,43032]
===
match
---
operator: , [35626,35627]
operator: , [35626,35627]
===
match
---
name: result [76147,76153]
name: result [76571,76577]
===
match
---
name: item [62850,62854]
name: item [63274,63278]
===
match
---
operator: , [70145,70146]
operator: , [70569,70570]
===
match
---
expr_stmt [81832,81848]
expr_stmt [82256,82272]
===
match
---
simple_stmt [54403,54437]
simple_stmt [54827,54861]
===
match
---
atom_expr [49507,49542]
atom_expr [49507,49542]
===
match
---
name: job_id [23735,23741]
name: job_id [23735,23741]
===
match
---
atom_expr [40998,41024]
atom_expr [40998,41024]
===
match
---
param [77140,77193]
param [77564,77617]
===
match
---
atom_expr [50064,50077]
atom_expr [50064,50077]
===
match
---
name: self [23650,23654]
name: self [23650,23654]
===
match
---
operator: , [54764,54765]
operator: , [55188,55189]
===
match
---
atom_expr [50859,50893]
atom_expr [50859,50893]
===
match
---
simple_stmt [11021,11048]
simple_stmt [11021,11048]
===
match
---
operator: = [3270,3271]
operator: = [3270,3271]
===
match
---
name: task [34244,34248]
name: task [34244,34248]
===
match
---
name: TaskReschedule [2080,2094]
name: TaskReschedule [2080,2094]
===
match
---
name: self [47216,47220]
name: self [47216,47220]
===
match
---
name: self [67837,67841]
name: self [68261,68265]
===
match
---
atom_expr [55957,55966]
atom_expr [56381,56390]
===
match
---
name: lock_for_update [23067,23082]
name: lock_for_update [23067,23082]
===
match
---
string: 'prev_execution_date_success' [64318,64347]
string: 'prev_execution_date_success' [64742,64771]
===
match
---
atom_expr [24951,24971]
atom_expr [24951,24971]
===
match
---
name: ti [23951,23953]
name: ti [23951,23953]
===
match
---
operator: = [45055,45056]
operator: = [45055,45056]
===
match
---
name: self [34074,34078]
name: self [34074,34078]
===
match
---
name: key [25580,25583]
name: key [25580,25583]
===
match
---
atom_expr [6605,6618]
atom_expr [6605,6618]
===
match
---
name: is_container [76044,76056]
name: is_container [76468,76480]
===
match
---
expr_stmt [58784,58959]
expr_stmt [59208,59383]
===
match
---
atom_expr [79582,79595]
atom_expr [80006,80019]
===
match
---
name: utils [2839,2844]
name: utils [2839,2844]
===
match
---
suite [15981,16014]
suite [15981,16014]
===
match
---
operator: = [73713,73714]
operator: = [74137,74138]
===
match
---
fstring_expr [20618,20623]
fstring_expr [20618,20623]
===
match
---
atom_expr [65526,65579]
atom_expr [65950,66003]
===
match
---
trailer [21560,21749]
trailer [21560,21749]
===
match
---
name: bool [37762,37766]
name: bool [37762,37766]
===
match
---
name: get_connection_from_secrets [63274,63301]
name: get_connection_from_secrets [63698,63725]
===
match
---
expr_stmt [28735,28769]
expr_stmt [28735,28769]
===
match
---
string: "task_instance" [10695,10710]
string: "task_instance" [10695,10710]
===
match
---
name: task [54025,54029]
name: task [54449,54453]
===
match
---
suite [80271,80308]
suite [80695,80732]
===
match
---
operator: = [16906,16907]
operator: = [16906,16907]
===
match
---
operator: = [5359,5360]
operator: = [5359,5360]
===
match
---
name: macros [58450,58456]
name: macros [58874,58880]
===
match
---
name: get_task [5895,5903]
name: get_task [5895,5903]
===
match
---
suite [55666,55711]
suite [56090,56135]
===
match
---
try_stmt [3719,4040]
try_stmt [3719,4040]
===
match
---
simple_stmt [15789,15819]
simple_stmt [15789,15819]
===
match
---
trailer [29386,29404]
trailer [29386,29404]
===
match
---
string: ' dag_id=%s, task_id=%s,' [43364,43389]
string: ' dag_id=%s, task_id=%s,' [43364,43389]
===
match
---
trailer [42337,42348]
trailer [42337,42348]
===
match
---
name: dag_id [79346,79352]
name: dag_id [79770,79776]
===
match
---
param [66962,66967]
param [67386,67391]
===
match
---
funcdef [26515,26799]
funcdef [26515,26799]
===
match
---
expr_stmt [67383,67420]
expr_stmt [67807,67844]
===
match
---
name: provide_session [21130,21145]
name: provide_session [21130,21145]
===
match
---
string: """         Clears all XCom data from the database for the task instance          :param session: SQLAlchemy ORM Session         :type session: Session         """ [25086,25249]
string: """         Clears all XCom data from the database for the task instance          :param session: SQLAlchemy ORM Session         :type session: Session         """ [25086,25249]
===
match
---
param [32740,32753]
param [32740,32753]
===
match
---
atom_expr [46700,46756]
atom_expr [46700,46756]
===
match
---
trailer [73144,73159]
trailer [73568,73583]
===
match
---
trailer [24280,24315]
trailer [24280,24315]
===
match
---
operator: } [48525,48526]
operator: } [48525,48526]
===
match
---
operator: = [50884,50885]
operator: = [50884,50885]
===
match
---
trailer [37189,37196]
trailer [37189,37196]
===
match
---
name: debug [25530,25535]
name: debug [25530,25535]
===
match
---
expr_stmt [20814,20858]
expr_stmt [20814,20858]
===
match
---
name: previous_ti [29811,29822]
name: previous_ti [29811,29822]
===
match
---
name: dag_run [61098,61105]
name: dag_run [61522,61529]
===
match
---
name: should_pass_filepath [16070,16090]
name: should_pass_filepath [16070,16090]
===
match
---
trailer [52043,52048]
trailer [52185,52190]
===
match
---
name: reconstructor [1400,1413]
name: reconstructor [1400,1413]
===
match
---
name: queue [24685,24690]
name: queue [24685,24690]
===
match
---
name: primary [9271,9278]
name: primary [9271,9278]
===
match
---
argument [10748,10764]
argument [10748,10764]
===
match
---
name: prev_execution_date [60510,60529]
name: prev_execution_date [60934,60953]
===
match
---
atom_expr [17501,17514]
atom_expr [17501,17514]
===
match
---
simple_stmt [29986,30234]
simple_stmt [29986,30234]
===
match
---
name: dag [59853,59856]
name: dag [60277,60280]
===
match
---
atom_expr [67162,67174]
atom_expr [67586,67598]
===
match
---
name: filter [7907,7913]
name: filter [7907,7913]
===
match
---
name: add [8556,8559]
name: add [8556,8559]
===
match
---
if_stmt [26263,26468]
if_stmt [26263,26468]
===
match
---
argument [31891,31902]
argument [31891,31902]
===
match
---
atom_expr [70913,70927]
atom_expr [71337,71351]
===
match
---
name: force_fail [56934,56944]
name: force_fail [57358,57368]
===
match
---
name: _handle_reschedule [54200,54218]
name: _handle_reschedule [54624,54642]
===
match
---
trailer [42925,42930]
trailer [42925,42930]
===
match
---
atom_expr [23335,23348]
atom_expr [23335,23348]
===
match
---
return_stmt [27780,27825]
return_stmt [27780,27825]
===
match
---
atom_expr [24890,24904]
atom_expr [24890,24904]
===
match
---
name: self [23375,23379]
name: self [23375,23379]
===
match
---
operator: = [61561,61562]
operator: = [61985,61986]
===
match
---
name: self [26298,26302]
name: self [26298,26302]
===
match
---
trailer [43498,43504]
trailer [43498,43504]
===
match
---
trailer [40984,40995]
trailer [40984,40995]
===
match
---
parameters [31468,31542]
parameters [31468,31542]
===
match
---
suite [76381,76514]
suite [76805,76938]
===
match
---
operator: = [45206,45207]
operator: = [45206,45207]
===
match
---
trailer [54139,54141]
trailer [54563,54565]
===
match
---
param [73767,73794]
param [74191,74218]
===
match
---
dotted_name [58710,58731]
dotted_name [59134,59155]
===
match
---
operator: = [46744,46745]
operator: = [46744,46745]
===
match
---
atom_expr [24680,24690]
atom_expr [24680,24690]
===
match
---
operator: , [1902,1903]
operator: , [1902,1903]
===
match
---
expr_stmt [42415,42436]
expr_stmt [42415,42436]
===
match
---
name: UtcDateTime [10975,10986]
name: UtcDateTime [10975,10986]
===
match
---
trailer [71139,71153]
trailer [71563,71577]
===
match
---
operator: , [27667,27668]
operator: , [27667,27668]
===
match
---
name: prev_ti [32004,32011]
name: prev_ti [32004,32011]
===
match
---
name: dag [58634,58637]
name: dag [59058,59061]
===
match
---
simple_stmt [7822,7864]
simple_stmt [7822,7864]
===
match
---
atom_expr [45380,45390]
atom_expr [45380,45390]
===
match
---
argument [49324,49337]
argument [49324,49337]
===
match
---
name: quote [20478,20483]
name: quote [20478,20483]
===
match
---
operator: , [47214,47215]
operator: , [47214,47215]
===
match
---
name: task_id [78685,78692]
name: task_id [79109,79116]
===
match
---
expr_stmt [13109,13161]
expr_stmt [13109,13161]
===
match
---
trailer [39297,39336]
trailer [39297,39336]
===
match
---
simple_stmt [1555,1594]
simple_stmt [1555,1594]
===
match
---
trailer [35547,35734]
trailer [35547,35734]
===
match
---
operator: , [48537,48538]
operator: , [48537,48538]
===
match
---
atom_expr [23666,23677]
atom_expr [23666,23677]
===
match
---
name: task [24728,24732]
name: task [24728,24732]
===
match
---
except_clause [51347,51363]
except_clause [51347,51363]
===
match
---
simple_stmt [45380,45407]
simple_stmt [45380,45407]
===
match
---
name: info [42299,42303]
name: info [42299,42303]
===
match
---
expr_stmt [20761,20805]
expr_stmt [20761,20805]
===
match
---
atom_expr [30796,30809]
atom_expr [30796,30809]
===
match
---
operator: , [53339,53340]
operator: , [53763,53764]
===
match
---
param [17425,17457]
param [17425,17457]
===
match
---
simple_stmt [2526,2569]
simple_stmt [2526,2569]
===
match
---
name: datetime [79478,79486]
name: datetime [79902,79910]
===
match
---
name: _handle_reschedule [45922,45940]
name: _handle_reschedule [45922,45940]
===
match
---
trailer [8547,8554]
trailer [8547,8554]
===
match
---
or_test [73526,73563]
or_test [73950,73987]
===
match
---
name: _date_or_empty [43627,43641]
name: _date_or_empty [43627,43641]
===
match
---
atom_expr [37709,37722]
atom_expr [37709,37722]
===
match
---
expr_stmt [16400,16427]
expr_stmt [16400,16427]
===
match
---
expr_stmt [54038,54078]
expr_stmt [54462,54502]
===
match
---
simple_stmt [55975,56009]
simple_stmt [56399,56433]
===
match
---
atom_expr [36323,36352]
atom_expr [36323,36352]
===
match
---
trailer [5848,5857]
trailer [5848,5857]
===
match
---
comparison [40789,40826]
comparison [40789,40826]
===
match
---
atom_expr [23351,23362]
atom_expr [23351,23362]
===
match
---
dotted_name [2981,3002]
dotted_name [2981,3002]
===
match
---
name: base_url [20874,20882]
name: base_url [20874,20882]
===
match
---
string: "--ignore-dependencies" [19888,19911]
string: "--ignore-dependencies" [19888,19911]
===
match
---
tfpdef [17493,17514]
tfpdef [17493,17514]
===
match
---
trailer [25316,25322]
trailer [25316,25322]
===
match
---
trailer [30907,30912]
trailer [30907,30912]
===
match
---
simple_stmt [58405,58422]
simple_stmt [58829,58846]
===
match
---
name: try_number [35427,35437]
name: try_number [35427,35437]
===
match
---
name: get_template_context [51860,51880]
name: get_template_context [51860,51880]
===
match
---
not_test [26772,26798]
not_test [26772,26798]
===
match
---
atom_expr [10733,10765]
atom_expr [10733,10765]
===
match
---
operator: = [16044,16045]
operator: = [16044,16045]
===
match
---
name: dag [59935,59938]
name: dag [60359,60362]
===
match
---
operator: = [66364,66365]
operator: = [66788,66789]
===
match
---
name: state [26183,26188]
name: state [26183,26188]
===
match
---
param [62665,62724]
param [63089,63148]
===
match
---
name: session [8614,8621]
name: session [8614,8621]
===
match
---
trailer [50119,50121]
trailer [50119,50121]
===
match
---
name: self [62355,62359]
name: self [62779,62783]
===
match
---
name: self [33531,33535]
name: self [33531,33535]
===
match
---
param [62530,62534]
param [62954,62958]
===
match
---
name: ti [23311,23313]
name: ti [23311,23313]
===
match
---
name: self [41643,41647]
name: self [41643,41647]
===
match
---
operator: = [24678,24679]
operator: = [24678,24679]
===
match
---
string: 'subject_template' [71347,71365]
string: 'subject_template' [71771,71789]
===
match
---
operator: = [53102,53103]
operator: = [53526,53527]
===
match
---
atom_expr [6575,6584]
atom_expr [6575,6584]
===
match
---
atom_expr [16046,16060]
atom_expr [16046,16060]
===
match
---
name: error [55597,55602]
name: error [56021,56026]
===
match
---
name: execution_date [77649,77663]
name: execution_date [78073,78087]
===
match
---
name: job [81992,81995]
name: job [82416,82419]
===
match
---
name: dirname [70278,70285]
name: dirname [70702,70709]
===
match
---
operator: @ [34025,34026]
operator: @ [34025,34026]
===
match
---
atom_expr [48067,48160]
atom_expr [48067,48160]
===
match
---
atom_expr [10878,10915]
atom_expr [10878,10915]
===
match
---
trailer [30789,30810]
trailer [30789,30810]
===
match
---
trailer [79540,79549]
trailer [79964,79973]
===
match
---
expr_stmt [20525,20569]
expr_stmt [20525,20569]
===
match
---
simple_stmt [68512,68564]
simple_stmt [68936,68988]
===
match
---
operator: = [54018,54019]
operator: = [54442,54443]
===
match
---
name: on_success_callback [52177,52196]
name: on_success_callback [52344,52363]
===
match
---
string: 'task_instance_key_str' [64723,64746]
string: 'task_instance_key_str' [65147,65170]
===
match
---
fstring_start: f" [20596,20598]
fstring_start: f" [20596,20598]
===
match
---
operator: = [54290,54291]
operator: = [54714,54715]
===
match
---
name: dag_ids [75693,75700]
name: dag_ids [76117,76124]
===
match
---
atom_expr [67837,67848]
atom_expr [68261,68272]
===
match
---
string: """Functions that need to be run before a Task is executed""" [51173,51234]
string: """Functions that need to be run before a Task is executed""" [51173,51234]
===
match
---
atom_expr [20972,20983]
atom_expr [20972,20983]
===
match
---
operator: { [48527,48528]
operator: { [48527,48528]
===
match
---
atom_expr [9607,9699]
atom_expr [9607,9699]
===
match
---
dotted_name [2831,2852]
dotted_name [2831,2852]
===
match
---
trailer [29740,29748]
trailer [29740,29748]
===
match
---
operator: } [49855,49856]
operator: } [49855,49856]
===
match
---
simple_stmt [42987,43055]
simple_stmt [42987,43055]
===
match
---
if_stmt [27366,27423]
if_stmt [27366,27423]
===
match
---
operator: , [54710,54711]
operator: , [55134,55135]
===
match
---
string: '' [60178,60180]
string: '' [60602,60604]
===
match
---
operator: , [63798,63799]
operator: , [64222,64223]
===
match
---
simple_stmt [79864,79908]
simple_stmt [80288,80332]
===
match
---
name: dag_run [59666,59673]
name: dag_run [60090,60097]
===
match
---
name: Column [11123,11129]
name: Column [11123,11129]
===
match
---
operator: , [56096,56097]
operator: , [56520,56521]
===
match
---
dotted_name [2260,2274]
dotted_name [2260,2274]
===
match
---
name: namespace [68166,68175]
name: namespace [68590,68599]
===
match
---
name: Optional [4080,4088]
name: Optional [4080,4088]
===
match
---
atom_expr [44885,44896]
atom_expr [44885,44896]
===
match
---
param [54266,54282]
param [54690,54706]
===
match
---
expr_stmt [77502,77517]
expr_stmt [77926,77941]
===
match
---
name: dag [5837,5840]
name: dag [5837,5840]
===
match
---
name: dr [29063,29065]
name: dr [29063,29065]
===
match
---
name: verbose_aware_logger [33942,33962]
name: verbose_aware_logger [33942,33962]
===
match
---
atom_expr [52297,52319]
atom_expr [52581,52603]
===
match
---
trailer [36332,36336]
trailer [36332,36336]
===
match
---
name: State [9013,9018]
name: State [9013,9018]
===
match
---
suite [20029,20066]
suite [20029,20066]
===
match
---
name: RenderedTaskInstanceFields [65526,65552]
name: RenderedTaskInstanceFields [65950,65976]
===
match
---
suite [40959,41025]
suite [40959,41025]
===
match
---
name: State [45393,45398]
name: State [45393,45398]
===
match
---
string: '-' [60563,60566]
string: '-' [60987,60990]
===
match
---
name: self [57886,57890]
name: self [58310,58314]
===
match
---
trailer [26451,26465]
trailer [26451,26465]
===
match
---
simple_stmt [52172,52206]
simple_stmt [52339,52373]
===
match
---
name: ready_for_retry [26781,26796]
name: ready_for_retry [26781,26796]
===
match
---
operator: = [23992,23993]
operator: = [23992,23993]
===
match
---
operator: , [43452,43453]
operator: , [43452,43453]
===
match
---
name: Optional [57682,57690]
name: Optional [58106,58114]
===
match
---
operator: + [43362,43363]
operator: + [43362,43363]
===
match
---
param [17567,17598]
param [17567,17598]
===
match
---
trailer [61039,61074]
trailer [61463,61498]
===
match
---
suite [45181,45313]
suite [45181,45313]
===
match
---
name: globals [81889,81896]
name: globals [82313,82320]
===
match
---
trailer [26406,26415]
trailer [26406,26415]
===
match
---
trailer [47066,47075]
trailer [47066,47075]
===
match
---
atom_expr [77145,77193]
atom_expr [77569,77617]
===
match
---
operator: = [42571,42572]
operator: = [42571,42572]
===
match
---
operator: -> [9477,9479]
operator: -> [9477,9479]
===
match
---
name: self [29823,29827]
name: self [29823,29827]
===
match
---
argument [44811,44829]
argument [44811,44829]
===
match
---
name: str [4448,4451]
name: str [4448,4451]
===
match
---
name: pool_slots [24751,24761]
name: pool_slots [24751,24761]
===
match
---
operator: = [70130,70131]
operator: = [70554,70555]
===
match
---
simple_stmt [20814,20859]
simple_stmt [20814,20859]
===
match
---
arglist [60812,60819]
arglist [61236,61243]
===
match
---
name: SKIPPED [27711,27718]
name: SKIPPED [27711,27718]
===
match
---
name: hostname [11143,11151]
name: hostname [11143,11151]
===
match
---
name: rendered_task_instance_fields [65494,65523]
name: rendered_task_instance_fields [65918,65947]
===
match
---
name: dag_id [20977,20983]
name: dag_id [20977,20983]
===
match
---
operator: = [60790,60791]
operator: = [61214,61215]
===
match
---
decorated [26804,27826]
decorated [26804,27826]
===
match
---
operator: = [28860,28861]
operator: = [28860,28861]
===
match
---
name: state [32630,32635]
name: state [32630,32635]
===
match
---
number: 256 [11265,11268]
number: 256 [11265,11268]
===
match
---
trailer [23122,23128]
trailer [23122,23128]
===
match
---
if_stmt [16353,16428]
if_stmt [16353,16428]
===
match
---
name: first [77688,77693]
name: first [78112,78117]
===
match
---
name: self [25358,25362]
name: self [25358,25362]
===
match
---
simple_stmt [36370,36422]
simple_stmt [36370,36422]
===
match
---
suite [46411,46779]
suite [46411,46779]
===
match
---
name: self [80930,80934]
name: self [81354,81358]
===
match
---
name: session [22248,22255]
name: session [22248,22255]
===
match
---
arglist [81567,81719]
arglist [81991,82143]
===
match
---
name: Integer [11408,11415]
name: Integer [11408,11415]
===
match
---
argument [70851,70881]
argument [71275,71305]
===
match
---
name: task [63928,63932]
name: task [64352,64356]
===
match
---
name: render_k8s_pod_yaml [67481,67500]
name: render_k8s_pod_yaml [67905,67924]
===
match
---
name: mark_success [53549,53561]
name: mark_success [53973,53985]
===
match
---
operator: == [76899,76901]
operator: == [77323,77325]
===
match
---
operator: , [55932,55933]
operator: , [56356,56357]
===
match
---
simple_stmt [24980,25011]
simple_stmt [24980,25011]
===
match
---
operator: , [35661,35662]
operator: , [35661,35662]
===
match
---
name: t [78167,78168]
name: t [78591,78592]
===
match
---
name: dag_id [78209,78215]
name: dag_id [78633,78639]
===
match
---
trailer [6577,6584]
trailer [6577,6584]
===
match
---
atom_expr [12545,12573]
atom_expr [12545,12573]
===
match
---
not_test [42449,42462]
not_test [42449,42462]
===
match
---
name: ti [5705,5707]
name: ti [5705,5707]
===
match
---
name: pool_slots [11291,11301]
name: pool_slots [11291,11301]
===
match
---
name: self [51470,51474]
name: self [51470,51474]
===
match
---
trailer [65945,66291]
trailer [66369,66715]
===
match
---
name: has_dag [12971,12978]
name: has_dag [12971,12978]
===
match
---
expr_stmt [24077,24094]
expr_stmt [24077,24094]
===
match
---
fstring_end: " [60887,60888]
fstring_end: " [61311,61312]
===
match
---
not_test [68721,68746]
not_test [69145,69170]
===
match
---
expr_stmt [33656,33669]
expr_stmt [33656,33669]
===
match
---
simple_stmt [19715,19753]
simple_stmt [19715,19753]
===
match
---
name: State [42492,42497]
name: State [42492,42497]
===
match
---
operator: , [67802,67803]
operator: , [68226,68227]
===
match
---
suite [8025,8320]
suite [8025,8320]
===
match
---
param [25584,25588]
param [25584,25588]
===
match
---
operator: == [81587,81589]
operator: == [82011,82013]
===
match
---
name: os [4214,4216]
name: os [4214,4216]
===
match
---
trailer [76289,76293]
trailer [76713,76717]
===
match
---
operator: , [67246,67247]
operator: , [67670,67671]
===
match
---
return_stmt [76340,76367]
return_stmt [76764,76791]
===
match
---
operator: , [39960,39961]
operator: , [39960,39961]
===
match
---
name: run_id [64642,64648]
name: run_id [65066,65072]
===
match
---
operator: = [36304,36305]
operator: = [36304,36305]
===
match
---
name: str [37682,37685]
name: str [37682,37685]
===
match
---
trailer [43208,43225]
trailer [43208,43225]
===
match
---
operator: , [54223,54224]
operator: , [54647,54648]
===
match
---
name: filter [37176,37182]
name: filter [37176,37182]
===
match
---
argument [28994,29030]
argument [28994,29030]
===
match
---
atom_expr [51733,51745]
atom_expr [51733,51745]
===
match
---
operator: = [43932,43933]
operator: = [43932,43933]
===
match
---
trailer [45700,45705]
trailer [45700,45705]
===
match
---
parameters [17068,17604]
parameters [17068,17604]
===
match
---
atom_expr [42078,42094]
atom_expr [42078,42094]
===
match
---
trailer [13429,13442]
trailer [13429,13442]
===
match
---
operator: = [39165,39166]
operator: = [39165,39166]
===
match
---
name: read [4241,4245]
name: read [4241,4245]
===
match
---
operator: = [31530,31531]
operator: = [31530,31531]
===
match
---
trailer [71183,71189]
trailer [71607,71613]
===
match
---
operator: = [36885,36886]
operator: = [36885,36886]
===
match
---
operator: @ [80220,80221]
operator: @ [80644,80645]
===
match
---
name: self [40789,40793]
name: self [40789,40793]
===
match
---
operator: == [7272,7274]
operator: == [7272,7274]
===
match
---
name: self [58028,58032]
name: self [58452,58456]
===
match
---
name: self [43571,43575]
name: self [43571,43575]
===
match
---
simple_stmt [31803,31852]
simple_stmt [31803,31852]
===
match
---
simple_stmt [39277,39337]
simple_stmt [39277,39337]
===
match
---
trailer [58988,58995]
trailer [59412,59419]
===
match
---
operator: ** [70594,70596]
operator: ** [71018,71020]
===
match
---
expr_stmt [72094,72159]
expr_stmt [72518,72583]
===
match
---
simple_stmt [3224,3241]
simple_stmt [3224,3241]
===
match
---
simple_stmt [81771,81806]
simple_stmt [82195,82230]
===
match
---
name: Column [11639,11645]
name: Column [11639,11645]
===
match
---
funcdef [32677,34020]
funcdef [32677,34020]
===
match
---
name: execution_date [6589,6603]
name: execution_date [6589,6603]
===
match
---
name: orm [1389,1392]
name: orm [1389,1392]
===
match
---
name: rendered_k8s_spec [66667,66684]
name: rendered_k8s_spec [67091,67108]
===
match
---
atom [37127,37289]
atom [37127,37289]
===
match
---
atom_expr [53863,53879]
atom_expr [54287,54303]
===
match
---
name: ignore_depends_on_past [52606,52628]
name: ignore_depends_on_past [53030,53052]
===
match
---
name: replace [60686,60693]
name: replace [61110,61117]
===
match
---
name: self [61403,61407]
name: self [61827,61831]
===
match
---
name: TaskInstance [78618,78630]
name: TaskInstance [79042,79054]
===
match
---
expr_stmt [70340,70412]
expr_stmt [70764,70836]
===
match
---
name: merge [42139,42144]
name: merge [42139,42144]
===
match
---
name: self [81590,81594]
name: self [82014,82018]
===
match
---
name: str [61670,61673]
name: str [62094,62097]
===
match
---
decorated [25784,26496]
decorated [25784,26496]
===
match
---
if_stmt [42818,43055]
if_stmt [42818,43055]
===
match
---
fstring_end: " [21021,21022]
fstring_end: " [21021,21022]
===
match
---
suite [62002,62904]
suite [62426,63328]
===
match
---
name: session [28297,28304]
name: session [28297,28304]
===
match
---
name: Variable [62430,62438]
name: Variable [62854,62862]
===
match
---
operator: = [61792,61793]
operator: = [62216,62217]
===
match
---
name: bool [17362,17366]
name: bool [17362,17366]
===
match
---
name: pool [17531,17535]
name: pool [17531,17535]
===
match
---
tfpdef [61510,61519]
tfpdef [61934,61943]
===
match
---
atom_expr [72215,72271]
atom_expr [72639,72695]
===
match
---
name: self [20934,20938]
name: self [20934,20938]
===
match
---
atom_expr [71179,71189]
atom_expr [71603,71613]
===
match
---
operator: , [66581,66582]
operator: , [67005,67006]
===
match
---
name: TaskFail [56262,56270]
name: TaskFail [56686,56694]
===
match
---
atom_expr [25383,25395]
atom_expr [25383,25395]
===
match
---
lambdef [5417,5441]
lambdef [5417,5441]
===
match
---
atom_expr [53792,53802]
atom_expr [54216,54226]
===
match
---
simple_stmt [80280,80308]
simple_stmt [80704,80732]
===
match
---
suite [60913,60953]
suite [61337,61377]
===
match
---
atom_expr [40352,40368]
atom_expr [40352,40368]
===
match
---
expr_stmt [79604,79631]
expr_stmt [80028,80055]
===
match
---
atom_expr [19961,20001]
atom_expr [19961,20001]
===
match
---
name: error_file [4418,4428]
name: error_file [4418,4428]
===
match
---
name: task [51759,51763]
name: task [51759,51763]
===
match
---
operator: , [17456,17457]
operator: , [17456,17457]
===
match
---
name: LoggingMixin [2660,2672]
name: LoggingMixin [2660,2672]
===
match
---
trailer [52238,52251]
trailer [52522,52535]
===
match
---
name: refresh_from_db [45726,45741]
name: refresh_from_db [45726,45741]
===
match
---
expr_stmt [3325,3358]
expr_stmt [3325,3358]
===
match
---
simple_stmt [46773,46779]
simple_stmt [46773,46779]
===
match
---
simple_stmt [4770,4798]
simple_stmt [4770,4798]
===
match
---
funcdef [71028,71317]
funcdef [71452,71741]
===
match
---
name: deps [34232,34236]
name: deps [34232,34236]
===
match
---
name: State [7970,7975]
name: State [7970,7975]
===
match
---
arglist [36492,36524]
arglist [36492,36524]
===
match
---
name: iso [20761,20764]
name: iso [20761,20764]
===
match
---
fstring [47946,48000]
fstring [47946,48000]
===
match
---
operator: , [64202,64203]
operator: , [64626,64627]
===
match
---
name: create_pod_id [67823,67836]
name: create_pod_id [68247,68260]
===
match
---
fstring_string: &dag_id= [20646,20654]
fstring_string: &dag_id= [20646,20654]
===
match
---
atom_expr [22918,22929]
atom_expr [22918,22929]
===
match
---
name: TaskInstance [21684,21696]
name: TaskInstance [21684,21696]
===
match
---
simple_stmt [31997,32077]
simple_stmt [31997,32077]
===
match
---
name: pendulum [30972,30980]
name: pendulum [30972,30980]
===
match
---
name: self [47130,47134]
name: self [47130,47134]
===
match
---
name: actual_start_date [54662,54679]
name: actual_start_date [55086,55103]
===
match
---
strings [73207,73309]
strings [73631,73733]
===
match
---
name: self [9650,9654]
name: self [9650,9654]
===
match
---
trailer [20659,20666]
trailer [20659,20666]
===
match
---
operator: == [21651,21653]
operator: == [21651,21653]
===
match
---
name: info [42884,42888]
name: info [42884,42888]
===
match
---
name: warnings [32330,32338]
name: warnings [32330,32338]
===
match
---
atom_expr [60792,60820]
atom_expr [61216,61244]
===
match
---
name: session [33626,33633]
name: session [33626,33633]
===
match
---
arglist [30533,30743]
arglist [30533,30743]
===
match
---
name: self [67393,67397]
name: self [67817,67821]
===
match
---
trailer [48810,48825]
trailer [48810,48825]
===
match
---
name: qry [81776,81779]
name: qry [82200,82203]
===
match
---
fstring_expr [56076,56092]
fstring_expr [56500,56516]
===
match
---
name: jinja_context [70596,70609]
name: jinja_context [71020,71033]
===
match
---
trailer [30773,30789]
trailer [30773,30789]
===
match
---
trailer [78951,78955]
trailer [79375,79379]
===
match
---
atom_expr [33501,33514]
atom_expr [33501,33514]
===
match
---
fstring_expr [60876,60887]
fstring_expr [61300,61311]
===
match
---
name: ConnectionAccessor [62919,62937]
name: ConnectionAccessor [63343,63361]
===
match
---
param [37388,37393]
param [37388,37393]
===
match
---
name: Optional [43960,43968]
name: Optional [43960,43968]
===
match
---
if_stmt [58589,59080]
if_stmt [59013,59504]
===
match
---
arith_expr [35867,35902]
arith_expr [35867,35902]
===
match
---
suite [8510,8585]
suite [8510,8585]
===
match
---
simple_stmt [60711,60763]
simple_stmt [61135,61187]
===
match
---
atom_expr [4584,4606]
atom_expr [4584,4606]
===
match
---
atom_expr [20773,20804]
atom_expr [20773,20804]
===
match
---
name: get_email_subject_content [68460,68485]
name: get_email_subject_content [68884,68909]
===
match
---
trailer [51497,51513]
trailer [51497,51513]
===
match
---
string: "--ignore-depends-on-past" [19973,19999]
string: "--ignore-depends-on-past" [19973,19999]
===
match
---
simple_stmt [39413,39429]
simple_stmt [39413,39429]
===
match
---
string: 'email' [71140,71147]
string: 'email' [71564,71571]
===
match
---
trailer [9293,9313]
trailer [9293,9313]
===
match
---
atom_expr [24980,24993]
atom_expr [24980,24993]
===
match
---
name: integrate_macros_plugins [2230,2254]
name: integrate_macros_plugins [2230,2254]
===
match
---
atom_expr [69913,70178]
atom_expr [70337,70602]
===
match
---
trailer [32154,32163]
trailer [32154,32163]
===
match
---
import_name [1201,1216]
import_name [1201,1216]
===
match
---
atom_expr [20042,20065]
atom_expr [20042,20065]
===
match
---
trailer [7921,7924]
trailer [7921,7924]
===
match
---
atom_expr [77688,77701]
atom_expr [78112,78125]
===
match
---
name: task [52172,52176]
name: task [52339,52343]
===
match
---
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [69525,69569]
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [69949,69993]
===
match
---
name: drs [8594,8597]
name: drs [8594,8597]
===
match
---
trailer [67841,67848]
trailer [68265,68272]
===
match
---
trailer [71934,71940]
trailer [72358,72364]
===
match
---
name: context [52197,52204]
name: context [52364,52371]
===
match
---
operator: -= [54999,55001]
operator: -= [55423,55425]
===
match
---
trailer [36441,36446]
trailer [36441,36446]
===
match
---
name: query [27445,27450]
name: query [27445,27450]
===
match
---
atom_expr [79787,79804]
atom_expr [80211,80228]
===
match
---
operator: , [1413,1414]
operator: , [1413,1414]
===
match
---
trailer [15799,15818]
trailer [15799,15818]
===
match
---
trailer [62568,62572]
trailer [62992,62996]
===
match
---
tfpdef [17466,17475]
tfpdef [17466,17475]
===
match
---
name: job_id [16946,16952]
name: job_id [16946,16952]
===
match
---
atom_expr [61922,61965]
atom_expr [62346,62389]
===
match
---
operator: = [23309,23310]
operator: = [23309,23310]
===
match
---
trailer [65094,65096]
trailer [65518,65520]
===
match
---
name: _priority_weight [80775,80791]
name: _priority_weight [81199,81215]
===
match
---
param [65346,65350]
param [65770,65774]
===
match
---
simple_stmt [67669,67696]
simple_stmt [68093,68120]
===
match
---
operator: , [31511,31512]
operator: , [31511,31512]
===
match
---
string: "Refreshing TaskInstance %s from DB" [22788,22824]
string: "Refreshing TaskInstance %s from DB" [22788,22824]
===
match
---
name: str [80661,80664]
name: str [81085,81088]
===
match
---
name: dag_id [9398,9404]
name: dag_id [9398,9404]
===
match
---
name: Base [1904,1908]
name: Base [1904,1908]
===
match
---
atom_expr [45057,45074]
atom_expr [45057,45074]
===
match
---
trailer [43673,43688]
trailer [43673,43688]
===
match
---
name: dag_id [48238,48244]
name: dag_id [48238,48244]
===
match
---
name: ignore_all_deps [41331,41346]
name: ignore_all_deps [41331,41346]
===
match
---
atom_expr [11029,11047]
atom_expr [11029,11047]
===
match
---
suite [45148,45407]
suite [45148,45407]
===
match
---
trailer [54427,54434]
trailer [54851,54858]
===
match
---
atom_expr [14547,14563]
atom_expr [14547,14563]
===
match
---
operator: = [33499,33500]
operator: = [33499,33500]
===
match
---
trailer [34782,34788]
trailer [34782,34788]
===
match
---
operator: = [39388,39389]
operator: = [39388,39389]
===
match
---
operator: = [32747,32748]
operator: = [32747,32748]
===
match
---
name: TaskInstance [78728,78740]
name: TaskInstance [79152,79164]
===
match
---
import_from [1471,1524]
import_from [1471,1524]
===
match
---
atom_expr [67757,67768]
atom_expr [68181,68192]
===
match
---
name: delay [36519,36524]
name: delay [36519,36524]
===
match
---
name: provide_session [36827,36842]
name: provide_session [36827,36842]
===
match
---
trailer [8047,8251]
trailer [8047,8251]
===
match
---
param [61640,61644]
param [62064,62068]
===
match
---
arglist [79755,79772]
arglist [80179,80196]
===
match
---
arglist [11073,11105]
arglist [11073,11105]
===
match
---
trailer [12400,12405]
trailer [12400,12405]
===
match
---
simple_stmt [76688,76963]
simple_stmt [77112,77387]
===
match
---
trailer [76406,76420]
trailer [76830,76844]
===
match
---
operator: , [15531,15532]
operator: , [15531,15532]
===
match
---
operator: , [16911,16912]
operator: , [16911,16912]
===
match
---
name: __init__ [79281,79289]
name: __init__ [79705,79713]
===
match
---
name: state [45385,45390]
name: state [45385,45390]
===
match
---
operator: -> [52894,52896]
operator: -> [53318,53320]
===
match
---
name: lock_for_update [81097,81112]
name: lock_for_update [81521,81536]
===
match
---
name: error [21916,21921]
name: error [21916,21921]
===
match
---
name: task [35069,35073]
name: task [35069,35073]
===
match
---
atom_expr [27347,27356]
atom_expr [27347,27356]
===
match
---
name: Index [11973,11978]
name: Index [11973,11978]
===
match
---
name: job_id [16953,16959]
name: job_id [16953,16959]
===
match
---
fstring_string: &task_id= [20623,20632]
fstring_string: &task_id= [20623,20632]
===
match
---
operator: = [58509,58510]
operator: = [58933,58934]
===
match
---
operator: = [67927,67928]
operator: = [68351,68352]
===
match
---
name: utcnow [54428,54434]
name: utcnow [54852,54858]
===
match
---
trailer [26285,26294]
trailer [26285,26294]
===
match
---
tfpdef [3481,3497]
tfpdef [3481,3497]
===
match
---
name: extend [19965,19971]
name: extend [19965,19971]
===
match
---
simple_stmt [60830,60889]
simple_stmt [61254,61313]
===
match
---
if_stmt [7802,7987]
if_stmt [7802,7987]
===
match
---
argument [29536,29551]
argument [29536,29551]
===
match
---
not_test [27369,27397]
not_test [27369,27397]
===
match
---
trailer [27461,27483]
trailer [27461,27483]
===
match
---
name: execution_timeout [50627,50644]
name: execution_timeout [50627,50644]
===
match
---
name: parent_dag [16225,16235]
name: parent_dag [16225,16235]
===
match
---
name: task [58676,58680]
name: task [59100,59104]
===
match
---
simple_stmt [51305,51339]
simple_stmt [51305,51339]
===
match
---
name: mark_success [16604,16616]
name: mark_success [16604,16616]
===
match
---
trailer [51968,51977]
trailer [51993,52002]
===
match
---
simple_stmt [81857,81867]
simple_stmt [82281,82291]
===
match
---
name: ignore_task_deps [16688,16704]
name: ignore_task_deps [16688,16704]
===
match
---
expr_stmt [3242,3261]
expr_stmt [3242,3261]
===
match
---
name: external_executor_id [24192,24212]
name: external_executor_id [24192,24212]
===
match
---
name: bool [17333,17337]
name: bool [17333,17337]
===
match
---
operator: , [9676,9677]
operator: , [9676,9677]
===
match
---
name: autoescape [70298,70308]
name: autoescape [70722,70732]
===
match
---
name: state [45781,45786]
name: state [45781,45786]
===
match
---
suite [56160,56210]
suite [56584,56634]
===
match
---
param [52523,52528]
param [52947,52952]
===
match
---
operator: , [41994,41995]
operator: , [41994,41995]
===
match
---
name: set [5437,5440]
name: set [5437,5440]
===
match
---
name: self [56315,56319]
name: self [56739,56743]
===
match
---
name: error [55642,55647]
name: error [56066,56071]
===
match
---
simple_stmt [37299,37309]
simple_stmt [37299,37309]
===
match
---
atom [20053,20064]
atom [20053,20064]
===
match
---
string: ' execution_date=%s, start_date=%s, end_date=%s' [43404,43452]
string: ' execution_date=%s, start_date=%s, end_date=%s' [43404,43452]
===
match
---
name: self [34445,34449]
name: self [34445,34449]
===
match
---
fstring_string: /log?execution_date= [20598,20618]
fstring_string: /log?execution_date= [20598,20618]
===
match
---
name: job_ids [7805,7812]
name: job_ids [7805,7812]
===
match
---
name: operator_helpers [2735,2751]
name: operator_helpers [2735,2751]
===
match
---
name: path [16455,16459]
name: path [16455,16459]
===
match
---
name: job_ids [7929,7936]
name: job_ids [7929,7936]
===
match
---
trailer [60382,60391]
trailer [60806,60815]
===
match
---
trailer [47203,47221]
trailer [47203,47221]
===
match
---
atom_expr [14429,14445]
atom_expr [14429,14445]
===
match
---
atom_expr [78203,78270]
atom_expr [78627,78694]
===
match
---
simple_stmt [35853,35903]
simple_stmt [35853,35903]
===
match
---
operator: = [67275,67276]
operator: = [67699,67700]
===
match
---
name: primary_key [10767,10778]
name: primary_key [10767,10778]
===
match
---
name: self [67888,67892]
name: self [68312,68316]
===
match
---
trailer [54449,54462]
trailer [54873,54886]
===
match
---
trailer [21658,21666]
trailer [21658,21666]
===
match
---
simple_stmt [55041,55058]
simple_stmt [55465,55482]
===
match
---
import_from [978,1017]
import_from [978,1017]
===
match
---
expr_stmt [3767,3806]
expr_stmt [3767,3806]
===
match
---
name: rendered_value [65754,65768]
name: rendered_value [66178,66192]
===
match
---
trailer [8042,8047]
trailer [8042,8047]
===
match
---
name: mark_success [17155,17167]
name: mark_success [17155,17167]
===
match
---
atom_expr [44782,44830]
atom_expr [44782,44830]
===
match
---
name: session [40291,40298]
name: session [40291,40298]
===
match
---
name: self [37238,37242]
name: self [37238,37242]
===
match
---
suite [16027,16061]
suite [16027,16061]
===
match
---
name: self [13837,13841]
name: self [13837,13841]
===
match
---
name: ID_LEN [11653,11659]
name: ID_LEN [11653,11659]
===
match
---
trailer [20792,20802]
trailer [20792,20802]
===
match
---
suite [55468,55508]
suite [55892,55932]
===
match
---
operator: = [30946,30947]
operator: = [30946,30947]
===
match
---
atom_expr [26312,26330]
atom_expr [26312,26330]
===
match
---
trailer [42561,42570]
trailer [42561,42570]
===
match
---
arglist [54564,54765]
arglist [54988,55189]
===
match
---
trailer [58825,58833]
trailer [59249,59257]
===
match
---
trailer [71299,71316]
trailer [71723,71740]
===
match
---
decorator [63321,63335]
decorator [63745,63759]
===
match
---
atom_expr [7970,7986]
atom_expr [7970,7986]
===
match
---
name: session [37739,37746]
name: session [37739,37746]
===
match
---
string: """Is task instance is eligible for retry""" [57972,58016]
string: """Is task instance is eligible for retry""" [58396,58440]
===
match
---
name: try_number [9228,9238]
name: try_number [9228,9238]
===
match
---
name: self [66351,66355]
name: self [66775,66779]
===
match
---
simple_stmt [11351,11379]
simple_stmt [11351,11379]
===
match
---
simple_stmt [60011,60033]
simple_stmt [60435,60457]
===
match
---
parameters [22310,22353]
parameters [22310,22353]
===
match
---
trailer [79809,79821]
trailer [80233,80245]
===
match
---
name: timedelta [59306,59315]
name: timedelta [59730,59739]
===
match
---
atom_expr [55493,55507]
atom_expr [55917,55931]
===
match
---
name: _Variable__NO_DEFAULT_SENTINEL [61803,61833]
name: _Variable__NO_DEFAULT_SENTINEL [62227,62257]
===
match
---
atom_expr [71758,71799]
atom_expr [72182,72223]
===
match
---
atom_expr [42290,42369]
atom_expr [42290,42369]
===
match
---
trailer [56997,57003]
trailer [57421,57427]
===
match
---
name: provide_session [58288,58303]
name: provide_session [58712,58727]
===
match
---
name: task_ids [76057,76065]
name: task_ids [76481,76489]
===
match
---
operator: , [37422,37423]
operator: , [37422,37423]
===
match
---
suite [65906,66299]
suite [66330,66723]
===
match
---
suite [3378,3428]
suite [3378,3428]
===
match
---
param [66976,66983]
param [67400,67407]
===
match
---
atom_expr [11161,11173]
atom_expr [11161,11173]
===
match
---
return_stmt [80994,81022]
return_stmt [81418,81446]
===
match
---
argument [31316,31327]
argument [31316,31327]
===
match
---
name: TR [40866,40868]
name: TR [40866,40868]
===
match
---
name: log [26112,26115]
name: log [26112,26115]
===
match
---
parameters [4061,4076]
parameters [4061,4076]
===
match
---
name: total_seconds [36337,36350]
name: total_seconds [36337,36350]
===
match
---
name: self [63192,63196]
name: self [63616,63620]
===
match
---
atom_expr [76797,76808]
atom_expr [77221,77232]
===
match
---
name: fd [4168,4170]
name: fd [4168,4170]
===
match
---
name: task_id [76210,76217]
name: task_id [76634,76641]
===
match
---
name: error_fd [53841,53849]
name: error_fd [54265,54273]
===
match
---
operator: , [71591,71592]
operator: , [72015,72016]
===
match
---
name: get_previous_scheduled_dagrun [29506,29535]
name: get_previous_scheduled_dagrun [29506,29535]
===
match
---
simple_stmt [29838,29978]
simple_stmt [29838,29978]
===
match
---
import_name [835,846]
import_name [835,846]
===
match
---
atom_expr [76826,76846]
atom_expr [77250,77270]
===
match
---
name: State [26312,26317]
name: State [26312,26317]
===
match
---
simple_stmt [41731,42014]
simple_stmt [41731,42014]
===
match
---
name: pendulum [1208,1216]
name: pendulum [1208,1216]
===
match
---
name: self [71836,71840]
name: self [72260,72264]
===
match
---
operator: = [34091,34092]
operator: = [34091,34092]
===
match
---
trailer [48715,48732]
trailer [48715,48732]
===
match
---
name: hasattr [15929,15936]
name: hasattr [15929,15936]
===
match
---
operator: = [12149,12150]
operator: = [12149,12150]
===
match
---
name: delay [35391,35396]
name: delay [35391,35396]
===
match
---
name: self [61035,61039]
name: self [61459,61463]
===
match
---
funcdef [31441,32077]
funcdef [31441,32077]
===
match
---
trailer [45345,45367]
trailer [45345,45367]
===
match
---
simple_stmt [9228,9248]
simple_stmt [9228,9248]
===
match
---
name: stacklevel [8228,8238]
name: stacklevel [8228,8238]
===
match
---
suite [79172,81867]
suite [79596,82291]
===
match
---
atom_expr [47953,47969]
atom_expr [47953,47969]
===
match
---
expr_stmt [39413,39428]
expr_stmt [39413,39428]
===
match
---
name: TaskReschedule [54532,54546]
name: TaskReschedule [54956,54970]
===
match
---
simple_stmt [33455,33470]
simple_stmt [33455,33470]
===
match
---
simple_stmt [21852,21865]
simple_stmt [21852,21865]
===
match
---
name: self [68733,68737]
name: self [69157,69161]
===
match
---
name: bool [57691,57695]
name: bool [58115,58119]
===
match
---
dictorsetmaker [69749,69759]
dictorsetmaker [70173,70183]
===
match
---
name: TR [7382,7384]
name: TR [7382,7384]
===
match
---
name: start_date [50091,50101]
name: start_date [50091,50101]
===
match
---
operator: = [71756,71757]
operator: = [72180,72181]
===
match
---
trailer [20544,20569]
trailer [20544,20569]
===
match
---
name: task [12464,12468]
name: task [12464,12468]
===
match
---
atom_expr [55041,55057]
atom_expr [55465,55481]
===
match
---
name: dag_run [63769,63776]
name: dag_run [64193,64200]
===
match
---
name: task_id [5858,5865]
name: task_id [5858,5865]
===
match
---
suite [46830,46918]
suite [46830,46918]
===
match
---
fstring_expr [34725,34738]
fstring_expr [34725,34738]
===
match
---
name: AirflowRescheduleException [1709,1735]
name: AirflowRescheduleException [1709,1735]
===
match
---
name: deserialize_json [62881,62897]
name: deserialize_json [63305,63321]
===
match
---
atom_expr [13620,13628]
atom_expr [13620,13628]
===
match
---
atom_expr [11304,11346]
atom_expr [11304,11346]
===
match
---
name: execution_date [25430,25444]
name: execution_date [25430,25444]
===
match
---
trailer [57645,57661]
trailer [58069,58085]
===
match
---
comparison [29362,29379]
comparison [29362,29379]
===
match
---
atom_expr [54628,54644]
atom_expr [55052,55068]
===
match
---
name: lazy_object_proxy [1183,1200]
name: lazy_object_proxy [1183,1200]
===
match
---
name: task_id [67855,67862]
name: task_id [68279,68286]
===
match
---
trailer [11042,11046]
trailer [11042,11046]
===
match
---
name: state [30790,30795]
name: state [30790,30795]
===
match
---
expr_stmt [21494,21778]
expr_stmt [21494,21778]
===
match
---
operator: + [15244,15245]
operator: + [15244,15245]
===
match
---
name: query [21521,21526]
name: query [21521,21526]
===
match
---
operator: , [34423,34424]
operator: , [34423,34424]
===
match
---
name: try_number [79585,79595]
name: try_number [80009,80019]
===
match
---
name: Iterable [1067,1075]
name: Iterable [1067,1075]
===
match
---
trailer [59113,59122]
trailer [59537,59546]
===
match
---
name: test_mode [47165,47174]
name: test_mode [47165,47174]
===
match
---
name: operator [11421,11429]
name: operator [11421,11429]
===
match
---
operator: = [70861,70862]
operator: = [71285,71286]
===
match
---
trailer [81925,81927]
trailer [82349,82351]
===
match
---
trailer [79791,79804]
trailer [80215,80228]
===
match
---
name: dag_id [78031,78037]
name: dag_id [78455,78461]
===
match
---
name: current_state [21154,21167]
name: current_state [21154,21167]
===
match
---
argument [49779,49792]
argument [49779,49792]
===
match
---
name: execution_date [58905,58919]
name: execution_date [59329,59343]
===
match
---
expr_stmt [15789,15818]
expr_stmt [15789,15818]
===
match
---
name: pendulum [60216,60224]
name: pendulum [60640,60648]
===
match
---
name: tomorrow_ds [64852,64863]
name: tomorrow_ds [65276,65287]
===
match
---
suite [20249,20298]
suite [20249,20298]
===
match
---
atom_expr [73453,73465]
atom_expr [73877,73889]
===
match
---
name: self [25057,25061]
name: self [25057,25061]
===
match
---
name: self [39167,39171]
name: self [39167,39171]
===
match
---
simple_stmt [81979,82020]
simple_stmt [82403,82444]
===
match
---
trailer [57163,57178]
trailer [57587,57602]
===
match
---
name: lock_for_update [45346,45361]
name: lock_for_update [45346,45361]
===
match
---
trailer [12468,12475]
trailer [12468,12475]
===
match
---
if_stmt [55539,55711]
if_stmt [55963,56135]
===
match
---
operator: , [17597,17598]
operator: , [17597,17598]
===
match
---
suite [80754,80792]
suite [81178,81216]
===
match
---
atom_expr [76044,76066]
atom_expr [76468,76490]
===
match
---
string: "\n" [39667,39671]
string: "\n" [39667,39671]
===
match
---
name: state [50056,50061]
name: state [50056,50061]
===
match
---
name: self [79511,79515]
name: self [79935,79939]
===
match
---
string: 'Exception:<br>Failed attempt to attach error logs<br>' [69457,69512]
string: 'Exception:<br>Failed attempt to attach error logs<br>' [69881,69936]
===
match
---
try_stmt [65796,66299]
try_stmt [66220,66723]
===
match
---
name: on_failure_callback [51949,51968]
name: on_failure_callback [51974,51993]
===
match
---
param [80172,80176]
param [80596,80600]
===
match
---
operator: = [70537,70538]
operator: = [70961,70962]
===
match
---
atom_expr [78392,78408]
atom_expr [78816,78832]
===
match
---
atom_expr [60087,60127]
atom_expr [60511,60551]
===
match
---
funcdef [66923,67216]
funcdef [67347,67640]
===
match
---
name: self [36588,36592]
name: self [36588,36592]
===
match
---
trailer [70490,70507]
trailer [70914,70931]
===
match
---
name: refresh_from_db [45330,45345]
name: refresh_from_db [45330,45345]
===
match
---
operator: - [26433,26434]
operator: - [26433,26434]
===
match
---
name: utils [2686,2691]
name: utils [2686,2691]
===
match
---
string: 'yesterday_ds' [65212,65226]
string: 'yesterday_ds' [65636,65650]
===
match
---
name: RUNNING [42498,42505]
name: RUNNING [42498,42505]
===
match
---
return_stmt [61915,61965]
return_stmt [62339,62389]
===
match
---
name: retries [5992,5999]
name: retries [5992,5999]
===
match
---
operator: , [75820,75821]
operator: , [76244,76245]
===
match
---
funcdef [4399,4798]
funcdef [4399,4798]
===
match
---
arglist [61935,61964]
arglist [62359,62388]
===
match
---
name: execution_date [59731,59745]
name: execution_date [60155,60169]
===
match
---
if_stmt [6641,7797]
if_stmt [6641,7797]
===
match
---
trailer [60850,60857]
trailer [61274,61281]
===
match
---
name: end_date [23300,23308]
name: end_date [23300,23308]
===
match
---
name: dep_context [34080,34091]
name: dep_context [34080,34091]
===
match
---
param [80979,80983]
param [81403,81407]
===
match
---
fstring [46958,47012]
fstring [46958,47012]
===
match
---
arglist [13035,13073]
arglist [13035,13073]
===
match
---
name: test_mode [45982,45991]
name: test_mode [45982,45991]
===
match
---
trailer [13023,13034]
trailer [13023,13034]
===
match
---
argument [29641,29652]
argument [29641,29652]
===
match
---
trailer [78152,78176]
trailer [78576,78600]
===
match
---
name: hr_line_break [41700,41713]
name: hr_line_break [41700,41713]
===
match
---
name: DeprecationWarning [30698,30716]
name: DeprecationWarning [30698,30716]
===
match
---
name: params [58638,58644]
name: params [59062,59068]
===
match
---
name: uselist [12284,12291]
name: uselist [12284,12291]
===
match
---
trailer [4240,4245]
trailer [4240,4245]
===
match
---
name: dep_context [41234,41245]
name: dep_context [41234,41245]
===
match
---
name: self [25448,25452]
name: self [25448,25452]
===
match
---
name: XCom [75597,75601]
name: XCom [76021,76025]
===
match
---
name: execution_date [78762,78776]
name: execution_date [79186,79200]
===
match
---
atom_expr [30963,30990]
atom_expr [30963,30990]
===
match
---
atom [19491,19540]
atom [19491,19540]
===
match
---
operator: , [20845,20846]
operator: , [20845,20846]
===
match
---
simple_stmt [1526,1555]
simple_stmt [1526,1555]
===
match
---
operator: , [58883,58884]
operator: , [59307,59308]
===
match
---
trailer [73685,73712]
trailer [74109,74136]
===
match
---
atom_expr [57506,57525]
atom_expr [57930,57949]
===
match
---
name: ti [23351,23353]
name: ti [23351,23353]
===
match
---
tfpdef [17099,17111]
tfpdef [17099,17111]
===
match
---
name: qry [23162,23165]
name: qry [23162,23165]
===
match
---
expr_stmt [31860,31920]
expr_stmt [31860,31920]
===
match
---
name: error [57914,57919]
name: error [58338,58343]
===
match
---
name: queued_by_job [82131,82144]
name: queued_by_job [82555,82568]
===
match
---
decorator [9445,9455]
decorator [9445,9455]
===
match
---
name: session [21513,21520]
name: session [21513,21520]
===
match
---
atom_expr [68322,68353]
atom_expr [68746,68777]
===
match
---
trailer [62849,62903]
trailer [63273,63327]
===
match
---
decorator [80220,80230]
decorator [80644,80654]
===
match
---
atom_expr [73697,73710]
atom_expr [74121,74134]
===
match
---
if_stmt [8325,9078]
if_stmt [8325,9078]
===
match
---
name: str [4782,4785]
name: str [4782,4785]
===
match
---
operator: , [22329,22330]
operator: , [22329,22330]
===
match
---
name: RenderedTaskInstanceFields [65458,65484]
name: RenderedTaskInstanceFields [65882,65908]
===
match
---
simple_stmt [52265,52282]
simple_stmt [52549,52566]
===
match
---
atom_expr [72047,72060]
atom_expr [72471,72484]
===
match
---
operator: @ [15133,15134]
operator: @ [15133,15134]
===
match
---
trailer [39378,39387]
trailer [39378,39387]
===
match
---
trailer [39281,39297]
trailer [39281,39297]
===
match
---
name: Optional [30963,30971]
name: Optional [30963,30971]
===
match
---
name: bool [17208,17212]
name: bool [17208,17212]
===
match
---
operator: = [59778,59779]
operator: = [60202,60203]
===
match
---
trailer [63273,63301]
trailer [63697,63725]
===
match
---
if_stmt [12706,13232]
if_stmt [12706,13232]
===
match
---
trailer [42936,42951]
trailer [42936,42951]
===
match
---
name: key [71039,71042]
name: key [71463,71466]
===
match
---
atom_expr [60592,60637]
atom_expr [61016,61061]
===
match
---
name: retries [24912,24919]
name: retries [24912,24919]
===
match
---
trailer [23005,23020]
trailer [23005,23020]
===
match
---
string: """         Forces the task instance's state to FAILED in the database.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [21951,22113]
string: """         Forces the task instance's state to FAILED in the database.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [21951,22113]
===
match
---
atom_expr [50542,50569]
atom_expr [50542,50569]
===
match
---
param [80342,80346]
param [80766,80770]
===
match
---
name: key [80885,80888]
name: key [81309,81312]
===
match
---
decorator [66304,66321]
decorator [66728,66745]
===
match
---
name: params [64164,64170]
name: params [64588,64594]
===
match
---
trailer [50090,50101]
trailer [50090,50101]
===
match
---
name: self [49143,49147]
name: self [49143,49147]
===
match
---
arglist [71418,71463]
arglist [71842,71887]
===
match
---
name: TaskInstance [78360,78372]
name: TaskInstance [78784,78796]
===
match
---
name: signal [878,884]
name: signal [878,884]
===
match
---
suite [13759,13897]
suite [13759,13897]
===
match
---
name: jinja_context [71302,71315]
name: jinja_context [71726,71739]
===
match
---
trailer [5416,5442]
trailer [5416,5442]
===
match
---
name: get_previous_ti [31875,31890]
name: get_previous_ti [31875,31890]
===
match
---
operator: = [68175,68176]
operator: = [68599,68600]
===
match
---
name: Column [11154,11160]
name: Column [11154,11160]
===
match
---
operator: = [16928,16929]
operator: = [16928,16929]
===
match
---
testlist [9393,9439]
testlist [9393,9439]
===
match
---
name: task [28968,28972]
name: task [28968,28972]
===
match
---
tfpdef [72424,72440]
tfpdef [72848,72864]
===
match
---
simple_stmt [59143,59180]
simple_stmt [59567,59604]
===
match
---
name: self [51766,51770]
name: self [51766,51770]
===
match
---
trailer [60685,60693]
trailer [61109,61117]
===
match
---
name: var [61679,61682]
name: var [62103,62106]
===
match
---
name: self [76797,76801]
name: self [77221,77225]
===
match
---
operator: = [17515,17516]
operator: = [17515,17516]
===
match
---
trailer [23379,23385]
trailer [23379,23385]
===
match
---
trailer [60233,60254]
trailer [60657,60678]
===
match
---
simple_stmt [24021,24065]
simple_stmt [24021,24065]
===
match
---
operator: = [63417,63418]
operator: = [63841,63842]
===
match
---
atom_expr [22895,22914]
atom_expr [22895,22914]
===
match
---
atom_expr [68007,68029]
atom_expr [68431,68453]
===
match
---
suite [34630,34668]
suite [34630,34668]
===
match
---
trailer [13245,13260]
trailer [13245,13260]
===
match
---
name: render [71032,71038]
name: render [71456,71462]
===
match
---
name: dag_id [20660,20666]
name: dag_id [20660,20666]
===
match
---
import_from [3383,3427]
import_from [3383,3427]
===
match
---
expr_stmt [41643,41666]
expr_stmt [41643,41666]
===
match
---
expr_stmt [10789,10856]
expr_stmt [10789,10856]
===
match
---
operator: , [15941,15942]
operator: , [15941,15942]
===
match
---
name: e [45668,45669]
name: e [45668,45669]
===
match
---
name: self [46424,46428]
name: self [46424,46428]
===
match
---
operator: } [47989,47990]
operator: } [47989,47990]
===
match
---
trailer [7202,7617]
trailer [7202,7617]
===
match
---
name: self [26402,26406]
name: self [26402,26406]
===
match
---
simple_stmt [3262,3287]
simple_stmt [3262,3287]
===
match
---
name: add [54515,54518]
name: add [54939,54942]
===
match
---
name: Stats [56109,56114]
name: Stats [56533,56538]
===
match
---
arglist [34388,34569]
arglist [34388,34569]
===
match
---
trailer [20938,20946]
trailer [20938,20946]
===
match
---
trailer [76801,76808]
trailer [77225,77232]
===
match
---
name: dep_status [33558,33568]
name: dep_status [33558,33568]
===
match
---
trailer [67418,67420]
trailer [67842,67844]
===
match
---
operator: , [11859,11860]
operator: , [11859,11860]
===
match
---
operator: , [12898,12899]
operator: , [12898,12899]
===
match
---
name: airflow [2531,2538]
name: airflow [2531,2538]
===
match
---
simple_stmt [45882,45905]
simple_stmt [45882,45905]
===
match
---
name: replace [60165,60172]
name: replace [60589,60596]
===
match
---
param [43990,44003]
param [43990,44003]
===
match
---
name: modded_hash [35853,35864]
name: modded_hash [35853,35864]
===
match
---
name: prev_ti [32016,32023]
name: prev_ti [32016,32023]
===
match
---
name: self [53500,53504]
name: self [53924,53928]
===
match
---
name: Log [56185,56188]
name: Log [56609,56612]
===
match
---
name: prev_execution_date [60363,60382]
name: prev_execution_date [60787,60806]
===
match
---
trailer [8749,8753]
trailer [8749,8753]
===
match
---
arglist [56189,56207]
arglist [56613,56631]
===
match
---
trailer [44957,44961]
trailer [44957,44961]
===
match
---
name: get_dep_statuses [34289,34305]
name: get_dep_statuses [34289,34305]
===
match
---
name: task_id [16550,16557]
name: task_id [16550,16557]
===
match
---
atom_expr [25399,25411]
atom_expr [25399,25411]
===
match
---
name: self [57957,57961]
name: self [58381,58385]
===
match
---
funcdef [80493,80554]
funcdef [80917,80978]
===
match
---
operator: = [37500,37501]
operator: = [37500,37501]
===
match
---
name: TemplateAssertionError [66734,66756]
name: TemplateAssertionError [67158,67180]
===
match
---
operator: = [26358,26359]
operator: = [26358,26359]
===
match
---
trailer [42888,42952]
trailer [42888,42952]
===
match
---
name: Session [72433,72440]
name: Session [72857,72864]
===
match
---
arglist [68795,68807]
arglist [69219,69231]
===
match
---
name: default_conn [63399,63411]
name: default_conn [63823,63835]
===
match
---
for_stmt [33554,33888]
for_stmt [33554,33888]
===
match
---
trailer [22204,22211]
trailer [22204,22211]
===
match
---
atom_expr [47531,47540]
atom_expr [47531,47540]
===
match
---
param [52731,52758]
param [53155,53182]
===
match
---
name: finished [26286,26294]
name: finished [26286,26294]
===
match
---
name: error_file [46877,46887]
name: error_file [46877,46887]
===
match
---
atom_expr [9852,9927]
atom_expr [9852,9927]
===
match
---
operator: , [33778,33779]
operator: , [33778,33779]
===
match
---
name: session [31904,31911]
name: session [31904,31911]
===
match
---
trailer [49996,50001]
trailer [49996,50001]
===
match
---
name: utcnow [42106,42112]
name: utcnow [42106,42112]
===
match
---
trailer [23271,23282]
trailer [23271,23282]
===
match
---
name: session [39298,39305]
name: session [39298,39305]
===
match
---
simple_stmt [65923,66299]
simple_stmt [66347,66723]
===
match
---
param [17155,17182]
param [17155,17182]
===
match
---
name: FAILED [57012,57018]
name: FAILED [57436,57442]
===
match
---
expr_stmt [75589,75831]
expr_stmt [76013,76255]
===
match
---
trailer [53518,53746]
trailer [53942,54170]
===
match
---
simple_stmt [8034,8252]
simple_stmt [8034,8252]
===
match
---
expr_stmt [80014,80041]
expr_stmt [80438,80465]
===
match
---
operator: = [16658,16659]
operator: = [16658,16659]
===
match
---
trailer [20777,20792]
trailer [20777,20792]
===
match
---
trailer [31232,31238]
trailer [31232,31238]
===
match
---
name: debug [72224,72229]
name: debug [72648,72653]
===
match
---
simple_stmt [787,805]
simple_stmt [787,805]
===
match
---
operator: = [7968,7969]
operator: = [7968,7969]
===
match
---
simple_stmt [847,857]
simple_stmt [847,857]
===
match
---
trailer [65196,65198]
trailer [65620,65622]
===
match
---
name: execution_date [7257,7271]
name: execution_date [7257,7271]
===
match
---
name: timezone [50104,50112]
name: timezone [50104,50112]
===
match
---
expr_stmt [8960,8980]
expr_stmt [8960,8980]
===
match
---
atom_expr [26344,26357]
atom_expr [26344,26357]
===
match
---
name: state [36742,36747]
name: state [36742,36747]
===
match
---
trailer [16009,16013]
trailer [16009,16013]
===
match
---
operator: , [16850,16851]
operator: , [16850,16851]
===
match
---
atom_expr [52448,52479]
atom_expr [52757,52788]
===
match
---
name: task_id [27475,27482]
name: task_id [27475,27482]
===
match
---
name: ti [6575,6577]
name: ti [6575,6577]
===
match
---
operator: -> [80431,80433]
operator: -> [80855,80857]
===
match
---
annassign [79374,79392]
annassign [79798,79816]
===
match
---
name: execution_date [34760,34774]
name: execution_date [34760,34774]
===
match
---
name: pid [24082,24085]
name: pid [24082,24085]
===
match
---
suite [51364,51438]
suite [51364,51438]
===
match
---
comparison [3818,3843]
comparison [3818,3843]
===
match
---
operator: = [23858,23859]
operator: = [23858,23859]
===
match
---
expr_stmt [77626,77663]
expr_stmt [78050,78087]
===
match
---
name: commit [50166,50172]
name: commit [50166,50172]
===
match
---
name: task_id [25404,25411]
name: task_id [25404,25411]
===
match
---
name: self [53892,53896]
name: self [54316,54320]
===
match
---
atom_expr [60940,60951]
atom_expr [61364,61375]
===
match
---
trailer [13055,13060]
trailer [13055,13060]
===
match
---
trailer [34622,34629]
trailer [34622,34629]
===
match
---
name: ApiClient [3069,3078]
name: ApiClient [3069,3078]
===
match
---
atom_expr [56993,57003]
atom_expr [57417,57427]
===
match
---
name: tis [8506,8509]
name: tis [8506,8509]
===
match
---
operator: = [27435,27436]
operator: = [27435,27436]
===
match
---
name: self [80850,80854]
name: self [81274,81278]
===
match
---
trailer [33535,33539]
trailer [33535,33539]
===
match
---
name: state [7962,7967]
name: state [7962,7967]
===
match
---
atom_expr [47078,47095]
atom_expr [47078,47095]
===
match
---
atom_expr [56952,56979]
atom_expr [57376,57403]
===
match
---
tfpdef [57713,57729]
tfpdef [58137,58153]
===
match
---
name: state [27694,27699]
name: state [27694,27699]
===
match
---
name: subject [71570,71577]
name: subject [71994,72001]
===
match
---
comparison [8996,9025]
comparison [8996,9025]
===
match
---
name: verbose [42821,42828]
name: verbose [42821,42828]
===
match
---
atom_expr [56017,56036]
atom_expr [56441,56460]
===
match
---
operator: = [10796,10797]
operator: = [10796,10797]
===
match
---
name: self [54403,54407]
name: self [54827,54831]
===
match
---
trailer [67194,67201]
trailer [67618,67625]
===
match
---
name: state [53797,53802]
name: state [54221,54226]
===
match
---
name: get_rendered_k8s_spec [66329,66350]
name: get_rendered_k8s_spec [66753,66774]
===
match
---
name: handle_failure [46287,46301]
name: handle_failure [46287,46301]
===
match
---
trailer [16297,16314]
trailer [16297,16314]
===
match
---
atom_expr [15955,15980]
atom_expr [15955,15980]
===
match
---
string: '' [57255,57257]
string: '' [57679,57681]
===
match
---
argument [69977,69996]
argument [70401,70420]
===
match
---
operator: , [20169,20170]
operator: , [20169,20170]
===
match
---
param [21174,21186]
param [21174,21186]
===
match
---
fstring_string: operator_successes_ [49816,49835]
fstring_string: operator_successes_ [49816,49835]
===
match
---
funcdef [54196,55136]
funcdef [54620,55560]
===
match
---
name: self [80201,80205]
name: self [80625,80629]
===
match
---
trailer [57294,57300]
trailer [57718,57724]
===
match
---
name: update [58669,58675]
name: update [59093,59099]
===
match
---
expr_stmt [35504,35781]
expr_stmt [35504,35781]
===
match
---
name: AirflowSensorTimeout [46050,46070]
name: AirflowSensorTimeout [46050,46070]
===
match
---
name: ds_nodash [60877,60886]
name: ds_nodash [61301,61310]
===
match
---
name: str [17546,17549]
name: str [17546,17549]
===
match
---
trailer [34744,34752]
trailer [34744,34752]
===
match
---
simple_stmt [39345,39366]
simple_stmt [39345,39366]
===
match
---
name: NamedTemporaryFile [53456,53474]
name: NamedTemporaryFile [53880,53898]
===
match
---
name: f [71193,71194]
name: f [71617,71618]
===
match
---
arglist [60173,60180]
arglist [60597,60604]
===
match
---
name: session [72424,72431]
name: session [72848,72855]
===
match
---
atom_expr [82093,82113]
atom_expr [82517,82537]
===
match
---
expr_stmt [5705,5732]
expr_stmt [5705,5732]
===
match
---
atom [76090,76244]
atom [76514,76668]
===
match
---
name: schedule [28735,28743]
name: schedule [28735,28743]
===
match
---
trailer [14400,14408]
trailer [14400,14408]
===
match
---
name: Integer [11311,11318]
name: Integer [11311,11318]
===
match
---
name: dag_id [21606,21612]
name: dag_id [21606,21612]
===
match
---
name: log [45697,45700]
name: log [45697,45700]
===
match
---
operator: = [23349,23350]
operator: = [23349,23350]
===
match
---
name: ignore_task_deps [15355,15371]
name: ignore_task_deps [15355,15371]
===
match
---
operator: , [54573,54574]
operator: , [54997,54998]
===
match
---
atom_expr [50609,50661]
atom_expr [50609,50661]
===
match
---
string: "Dependencies not met for %s, dependency '%s' FAILED: %s" [33721,33778]
string: "Dependencies not met for %s, dependency '%s' FAILED: %s" [33721,33778]
===
match
---
name: ti [6490,6492]
name: ti [6490,6492]
===
match
---
arglist [67750,68303]
arglist [68174,68727]
===
match
---
name: connection [1929,1939]
name: connection [1929,1939]
===
match
---
param [31478,31483]
param [31478,31483]
===
match
---
return_stmt [80843,80861]
return_stmt [81267,81285]
===
match
---
atom_expr [59203,59260]
atom_expr [59627,59684]
===
match
---
name: e [45453,45454]
name: e [45453,45454]
===
match
---
trailer [32056,32076]
trailer [32056,32076]
===
match
---
name: debug [25267,25272]
name: debug [25267,25272]
===
match
---
power [35416,35442]
power [35416,35442]
===
match
---
name: self [39413,39417]
name: self [39413,39417]
===
match
---
atom_expr [6031,6044]
atom_expr [6031,6044]
===
match
---
trailer [47799,47807]
trailer [47799,47807]
===
match
---
simple_stmt [29344,29413]
simple_stmt [29344,29413]
===
match
---
if_stmt [40940,41025]
if_stmt [40940,41025]
===
match
---
simple_stmt [35363,35446]
simple_stmt [35363,35446]
===
match
---
trailer [25713,25778]
trailer [25713,25778]
===
match
---
operator: , [35640,35641]
operator: , [35640,35641]
===
match
---
trailer [58235,58243]
trailer [58659,58667]
===
match
---
trailer [67518,67524]
trailer [67942,67948]
===
match
---
operator: { [46970,46971]
operator: { [46970,46971]
===
match
---
trailer [79895,79900]
trailer [80319,80324]
===
match
---
simple_stmt [1993,2038]
simple_stmt [1993,2038]
===
match
---
operator: , [62647,62648]
operator: , [63071,63072]
===
match
---
atom_expr [57534,57550]
atom_expr [57958,57974]
===
match
---
simple_stmt [50818,50824]
simple_stmt [50818,50824]
===
match
---
argument [55633,55647]
argument [56057,56071]
===
match
---
expr_stmt [79963,80005]
expr_stmt [80387,80429]
===
match
---
funcdef [9947,10086]
funcdef [9947,10086]
===
match
---
name: task_ids [73667,73675]
name: task_ids [74091,74099]
===
match
---
atom [26418,26451]
atom [26418,26451]
===
match
---
name: actual_start_date [54225,54242]
name: actual_start_date [54649,54666]
===
match
---
atom_expr [52844,52857]
atom_expr [53268,53281]
===
match
---
simple_stmt [57097,57129]
simple_stmt [57521,57553]
===
match
---
simple_stmt [71124,71154]
simple_stmt [71548,71578]
===
match
---
trailer [9867,9927]
trailer [9867,9927]
===
match
---
name: pickle_id [16097,16106]
name: pickle_id [16097,16106]
===
match
---
simple_stmt [28220,28240]
simple_stmt [28220,28240]
===
match
---
fstring_start: f' [45094,45096]
fstring_start: f' [45094,45096]
===
match
---
operator: , [12245,12246]
operator: , [12245,12246]
===
match
---
trailer [49840,49845]
trailer [49840,49845]
===
match
---
trailer [67854,67862]
trailer [68278,68286]
===
match
---
operator: = [3234,3235]
operator: = [3234,3235]
===
match
---
suite [41626,42213]
suite [41626,42213]
===
match
---
name: hostname [13403,13411]
name: hostname [13403,13411]
===
match
---
trailer [43303,43307]
trailer [43303,43307]
===
match
---
if_stmt [58626,58693]
if_stmt [59050,59117]
===
match
---
trailer [49992,49996]
trailer [49992,49996]
===
match
---
operator: , [46626,46627]
operator: , [46626,46627]
===
match
---
name: self [45468,45472]
name: self [45468,45472]
===
match
---
trailer [25766,25777]
trailer [25766,25777]
===
match
---
trailer [43199,43208]
trailer [43199,43208]
===
match
---
atom_expr [59666,59690]
atom_expr [60090,60114]
===
match
---
trailer [21590,21597]
trailer [21590,21597]
===
match
---
name: self [9678,9682]
name: self [9678,9682]
===
match
---
name: models [47415,47421]
name: models [47415,47421]
===
match
---
string: """Setting Next Try Number""" [15182,15211]
string: """Setting Next Try Number""" [15182,15211]
===
match
---
operator: = [29008,29009]
operator: = [29008,29009]
===
match
---
parameters [65345,65351]
parameters [65769,65775]
===
match
---
decorator [25562,25572]
decorator [25562,25572]
===
match
---
name: AirflowNotFoundException [63607,63631]
name: AirflowNotFoundException [64031,64055]
===
match
---
name: self [55190,55194]
name: self [55614,55618]
===
match
---
argument [57861,57876]
argument [58285,58300]
===
match
---
trailer [19653,19683]
trailer [19653,19683]
===
match
---
name: RUNNING [5492,5499]
name: RUNNING [5492,5499]
===
match
---
operator: = [75700,75701]
operator: = [76124,76125]
===
match
---
name: session [7769,7776]
name: session [7769,7776]
===
match
---
trailer [46301,46355]
trailer [46301,46355]
===
match
---
name: _run_execute_callback [48789,48810]
name: _run_execute_callback [48789,48810]
===
match
---
operator: ** [35418,35420]
operator: ** [35418,35420]
===
match
---
name: self [33572,33576]
name: self [33572,33576]
===
match
---
trailer [57519,57525]
trailer [57943,57949]
===
match
---
return_stmt [16470,17024]
return_stmt [16470,17024]
===
match
---
operator: , [63939,63940]
operator: , [64363,64364]
===
match
---
name: _task_id [79366,79374]
name: _task_id [79790,79798]
===
match
---
name: self [25258,25262]
name: self [25258,25262]
===
match
---
name: self [13620,13624]
name: self [13620,13624]
===
match
---
atom_expr [53685,53698]
atom_expr [54109,54122]
===
match
---
simple_stmt [30358,30498]
simple_stmt [30358,30498]
===
match
---
name: prev_ds [60433,60440]
name: prev_ds [60857,60864]
===
match
---
name: next_ds [59988,59995]
name: next_ds [60412,60419]
===
match
---
name: state [27887,27892]
name: state [27887,27892]
===
match
---
name: self [80612,80616]
name: self [81036,81040]
===
match
---
operator: , [78422,78423]
operator: , [78846,78847]
===
match
---
atom_expr [73737,73750]
atom_expr [74161,74174]
===
match
---
name: try_number [14514,14524]
name: try_number [14514,14524]
===
match
---
name: total_seconds [72144,72157]
name: total_seconds [72568,72581]
===
match
---
expr_stmt [16214,16252]
expr_stmt [16214,16252]
===
match
---
strings [41769,41917]
strings [41769,41917]
===
match
---
arglist [28958,29031]
arglist [28958,29031]
===
match
---
trailer [8875,8877]
trailer [8875,8877]
===
match
---
operator: = [41246,41247]
operator: = [41246,41247]
===
match
---
suite [39517,39571]
suite [39517,39571]
===
match
---
trailer [7318,7508]
trailer [7318,7508]
===
match
---
name: self [34740,34744]
name: self [34740,34744]
===
match
---
argument [41478,41509]
argument [41478,41509]
===
match
---
expr_stmt [71716,71799]
expr_stmt [72140,72223]
===
match
---
operator: = [68376,68377]
operator: = [68800,68801]
===
match
---
operator: = [73425,73426]
operator: = [73849,73850]
===
match
---
operator: , [65141,65142]
operator: , [65565,65566]
===
match
---
name: error_file [46745,46755]
name: error_file [46745,46755]
===
match
---
trailer [5894,5903]
trailer [5894,5903]
===
match
---
suite [47596,47770]
suite [47596,47770]
===
match
---
string: 'ti_pool' [12050,12059]
string: 'ti_pool' [12050,12059]
===
match
---
name: self [54020,54024]
name: self [54444,54448]
===
match
---
name: join [48516,48520]
name: join [48516,48520]
===
match
---
expr_stmt [29489,29552]
expr_stmt [29489,29552]
===
match
---
name: reschedule_exception [54728,54748]
name: reschedule_exception [55152,55172]
===
match
---
trailer [11372,11377]
trailer [11372,11377]
===
match
---
operator: , [78650,78651]
operator: , [79074,79075]
===
match
---
trailer [35073,35099]
trailer [35073,35099]
===
match
---
name: ti [78696,78698]
name: ti [79120,79122]
===
match
---
suite [55388,57551]
suite [55812,57975]
===
match
---
operator: @ [72277,72278]
operator: @ [72701,72702]
===
match
---
atom_expr [78065,78092]
atom_expr [78489,78516]
===
match
---
operator: { [45105,45106]
operator: { [45105,45106]
===
match
---
suite [16167,16461]
suite [16167,16461]
===
match
---
operator: , [75707,75708]
operator: , [76131,76132]
===
match
---
name: session [57506,57513]
name: session [57930,57937]
===
match
---
trailer [27532,27539]
trailer [27532,27539]
===
match
---
operator: , [61519,61520]
operator: , [61943,61944]
===
match
---
operator: , [72343,72344]
operator: , [72767,72768]
===
match
---
name: self [43034,43038]
name: self [43034,43038]
===
match
---
trailer [29623,29653]
trailer [29623,29653]
===
match
---
operator: = [20534,20535]
operator: = [20534,20535]
===
match
---
tfpdef [52652,52674]
tfpdef [53076,53098]
===
match
---
atom_expr [52233,52251]
atom_expr [52517,52535]
===
match
---
atom_expr [59148,59179]
atom_expr [59572,59603]
===
match
---
operator: , [51156,51157]
operator: , [51156,51157]
===
match
---
atom_expr [80376,80392]
atom_expr [80800,80816]
===
match
---
simple_stmt [65414,65485]
simple_stmt [65838,65909]
===
match
---
trailer [79562,79574]
trailer [79986,79998]
===
match
---
decorated [31420,32077]
decorated [31420,32077]
===
match
---
suite [52332,52480]
suite [52616,52904]
===
match
---
string: 'ti_state' [11945,11955]
string: 'ti_state' [11945,11955]
===
match
---
trailer [72223,72229]
trailer [72647,72653]
===
match
---
atom_expr [15963,15972]
atom_expr [15963,15972]
===
match
---
operator: = [41386,41387]
operator: = [41386,41387]
===
match
---
name: session [31337,31344]
name: session [31337,31344]
===
match
---
trailer [4094,4110]
trailer [4094,4110]
===
match
---
expr_stmt [10957,10987]
expr_stmt [10957,10987]
===
match
---
trailer [7126,7698]
trailer [7126,7698]
===
match
---
param [80731,80735]
param [81155,81159]
===
match
---
atom_expr [11839,11875]
atom_expr [11839,11875]
===
match
---
trailer [12970,12978]
trailer [12970,12978]
===
match
---
name: State [58042,58047]
name: State [58466,58471]
===
match
---
operator: = [26221,26222]
operator: = [26221,26222]
===
match
---
suite [71103,71239]
suite [71527,71663]
===
match
---
name: bool [37535,37539]
name: bool [37535,37539]
===
match
---
name: self [41683,41687]
name: self [41683,41687]
===
match
---
name: execution_date [25453,25467]
name: execution_date [25453,25467]
===
match
---
string: 'next_ds_nodash' [64015,64031]
string: 'next_ds_nodash' [64439,64455]
===
match
---
funcdef [76968,77098]
funcdef [77392,77522]
===
match
---
funcdef [80412,80474]
funcdef [80836,80898]
===
match
---
name: State [64437,64442]
name: State [64861,64866]
===
match
---
trailer [51395,51437]
trailer [51395,51437]
===
match
---
name: provide_session [55142,55157]
name: provide_session [55566,55581]
===
match
---
decorated [49905,50310]
decorated [49905,50310]
===
match
---
trailer [25731,25739]
trailer [25731,25739]
===
match
---
name: _try_number [54633,54644]
name: _try_number [55057,55068]
===
match
---
name: self [54819,54823]
name: self [55243,55247]
===
match
---
name: log [42258,42261]
name: log [42258,42261]
===
match
---
name: info [45477,45481]
name: info [45477,45481]
===
match
---
name: execution_date [78394,78408]
name: execution_date [78818,78832]
===
match
---
suite [32165,32651]
suite [32165,32651]
===
match
---
atom_expr [80050,80059]
atom_expr [80474,80483]
===
match
---
trailer [28235,28239]
trailer [28235,28239]
===
match
---
trailer [82082,82090]
trailer [82506,82514]
===
match
---
name: next_ds [60157,60164]
name: next_ds [60581,60588]
===
match
---
funcdef [62613,62904]
funcdef [63037,63328]
===
match
---
name: bool [52670,52674]
name: bool [53094,53098]
===
match
---
tfpdef [17316,17337]
tfpdef [17316,17337]
===
match
---
param [76995,77004]
param [77419,77428]
===
match
---
atom_expr [46613,46626]
atom_expr [46613,46626]
===
match
---
name: __name__ [3349,3357]
name: __name__ [3349,3357]
===
match
---
name: self [42078,42082]
name: self [42078,42082]
===
match
---
name: max_tries [58272,58281]
name: max_tries [58696,58705]
===
match
---
name: task [12532,12536]
name: task [12532,12536]
===
match
---
param [43805,43832]
param [43805,43832]
===
match
---
name: PickleType [1329,1339]
name: PickleType [1329,1339]
===
match
---
trailer [81579,81586]
trailer [82003,82010]
===
match
---
return_stmt [4187,4198]
return_stmt [4187,4198]
===
match
---
name: job_id [5767,5773]
name: job_id [5767,5773]
===
match
---
trailer [53504,53518]
trailer [53928,53942]
===
match
---
operator: , [28972,28973]
operator: , [28972,28973]
===
match
---
name: pool [52838,52842]
name: pool [53262,53266]
===
match
---
if_stmt [49378,49543]
if_stmt [49378,49543]
===
match
---
trailer [56319,56328]
trailer [56743,56752]
===
match
---
operator: , [63196,63197]
operator: , [63620,63621]
===
match
---
atom_expr [35381,35444]
atom_expr [35381,35444]
===
match
---
simple_stmt [80194,80215]
simple_stmt [80618,80639]
===
match
---
name: prev_execution_date [60320,60339]
name: prev_execution_date [60744,60763]
===
match
---
atom_expr [8923,8931]
atom_expr [8923,8931]
===
match
---
name: TR [40861,40863]
name: TR [40861,40863]
===
match
---
decorator [55141,55158]
decorator [55565,55582]
===
match
---
parameters [80424,80430]
parameters [80848,80854]
===
match
---
expr_stmt [45198,45235]
expr_stmt [45198,45235]
===
match
---
name: context [49666,49673]
name: context [49666,49673]
===
match
---
name: session [27437,27444]
name: session [27437,27444]
===
match
---
trailer [42540,42548]
trailer [42540,42548]
===
match
---
name: fd [4555,4557]
name: fd [4555,4557]
===
match
---
operator: , [9914,9915]
operator: , [9914,9915]
===
match
---
name: self [57335,57339]
name: self [57759,57763]
===
match
---
name: default_var [61941,61952]
name: default_var [62365,62376]
===
match
---
operator: = [52424,52425]
operator: = [52708,52709]
===
match
---
atom_expr [60861,60873]
atom_expr [61285,61297]
===
match
---
atom_expr [41939,41954]
atom_expr [41939,41954]
===
match
---
number: 1 [42435,42436]
number: 1 [42435,42436]
===
match
---
trailer [67761,67768]
trailer [68185,68192]
===
match
---
name: task_ids [75721,75729]
name: task_ids [76145,76153]
===
match
---
suite [67075,67216]
suite [67499,67640]
===
match
---
trailer [23939,23948]
trailer [23939,23948]
===
match
---
name: pool [37703,37707]
name: pool [37703,37707]
===
match
---
fstring [34708,34792]
fstring [34708,34792]
===
match
---
name: utcnow [50113,50119]
name: utcnow [50113,50119]
===
match
---
operator: , [1075,1076]
operator: , [1075,1076]
===
match
---
atom_expr [20536,20569]
atom_expr [20536,20569]
===
match
---
atom_expr [13425,13444]
atom_expr [13425,13444]
===
match
---
string: 'task_instance' [64688,64703]
string: 'task_instance' [65112,65127]
===
match
---
name: timedelta [36323,36332]
name: timedelta [36323,36332]
===
match
---
simple_stmt [44782,44831]
simple_stmt [44782,44831]
===
match
---
name: models [65427,65433]
name: models [65851,65857]
===
match
---
return_stmt [34008,34019]
return_stmt [34008,34019]
===
match
---
trailer [29026,29030]
trailer [29026,29030]
===
match
---
name: TaskInstance [78313,78325]
name: TaskInstance [78737,78749]
===
match
---
suite [67525,68451]
suite [67949,68875]
===
match
---
trailer [55497,55507]
trailer [55921,55931]
===
match
---
name: state [26163,26168]
name: state [26163,26168]
===
match
---
operator: == [27525,27527]
operator: == [27525,27527]
===
match
---
argument [62856,62879]
argument [63280,63303]
===
match
---
param [17121,17146]
param [17121,17146]
===
match
---
name: catchup [29432,29439]
name: catchup [29432,29439]
===
match
---
number: 1 [81917,81918]
number: 1 [82341,82342]
===
match
---
name: with_entities [76191,76204]
name: with_entities [76615,76628]
===
match
---
operator: , [64618,64619]
operator: , [65042,65043]
===
match
---
name: ignore_depends_on_past [15387,15409]
name: ignore_depends_on_past [15387,15409]
===
match
---
atom_expr [9868,9879]
atom_expr [9868,9879]
===
match
---
expr_stmt [42078,42114]
expr_stmt [42078,42114]
===
match
---
trailer [27799,27825]
trailer [27799,27825]
===
match
---
name: state [12067,12072]
name: state [12067,12072]
===
match
---
trailer [68794,68808]
trailer [69218,69232]
===
match
---
operator: @ [14487,14488]
operator: @ [14487,14488]
===
match
---
arglist [39208,39232]
arglist [39208,39232]
===
match
---
simple_stmt [69354,69695]
simple_stmt [69778,70119]
===
match
---
name: String [11161,11167]
name: String [11161,11167]
===
match
---
operator: = [67887,67888]
operator: = [68311,68312]
===
match
---
trailer [61802,61833]
trailer [62226,62257]
===
match
---
trailer [57351,57358]
trailer [57775,57782]
===
match
---
name: render_templates [54123,54139]
name: render_templates [54547,54563]
===
match
---
name: _try_number [42420,42431]
name: _try_number [42420,42431]
===
match
---
name: self [23335,23339]
name: self [23335,23339]
===
match
---
arglist [49762,49792]
arglist [49762,49792]
===
match
---
name: task_id [17099,17106]
name: task_id [17099,17106]
===
match
---
operator: , [33872,33873]
operator: , [33872,33873]
===
match
---
name: BaseJob [82160,82167]
name: BaseJob [82584,82591]
===
match
---
simple_stmt [62951,63146]
simple_stmt [63375,63570]
===
match
---
trailer [27693,27699]
trailer [27693,27699]
===
match
---
name: self [24161,24165]
name: self [24161,24165]
===
match
---
trailer [78148,78152]
trailer [78572,78576]
===
match
---
name: item [61576,61580]
name: item [62000,62004]
===
match
---
trailer [64529,64618]
trailer [64953,65042]
===
match
---
name: bool [37610,37614]
name: bool [37610,37614]
===
match
---
argument [53920,53931]
argument [54344,54355]
===
match
---
name: result [51073,51079]
name: result [51073,51079]
===
match
---
operator: } [21020,21021]
operator: } [21020,21021]
===
match
---
name: max_tries [70918,70927]
name: max_tries [71342,71351]
===
match
---
decorated [37314,43075]
decorated [37314,43075]
===
match
---
simple_stmt [4117,4161]
simple_stmt [4117,4161]
===
match
---
name: XCom [76124,76128]
name: XCom [76548,76552]
===
match
---
name: task [54013,54017]
name: task [54437,54441]
===
match
---
name: task [13056,13060]
name: task [13056,13060]
===
match
---
name: property [32083,32091]
name: property [32083,32091]
===
match
---
atom_expr [78901,78921]
atom_expr [79325,79345]
===
match
---
fstring_start: f" [34708,34710]
fstring_start: f" [34708,34710]
===
match
---
dotted_name [2621,2652]
dotted_name [2621,2652]
===
match
---
trailer [40764,40771]
trailer [40764,40771]
===
match
---
atom_expr [4928,4942]
atom_expr [4928,4942]
===
match
---
trailer [12430,12439]
trailer [12430,12439]
===
match
---
trailer [25310,25316]
trailer [25310,25316]
===
match
---
name: filter_by [58851,58860]
name: filter_by [59275,59284]
===
match
---
operator: , [43608,43609]
operator: , [43608,43609]
===
match
---
trailer [58819,58825]
trailer [59243,59249]
===
match
---
trailer [12601,12611]
trailer [12601,12611]
===
match
---
if_stmt [16328,16461]
if_stmt [16328,16461]
===
match
---
name: dag_id [75559,75565]
name: dag_id [75983,75989]
===
match
---
name: pool [53335,53339]
name: pool [53759,53763]
===
match
---
trailer [23885,23901]
trailer [23885,23901]
===
match
---
name: self [34726,34730]
name: self [34726,34730]
===
match
---
name: settings [78505,78513]
name: settings [78929,78937]
===
match
---
name: handle_failure [46848,46862]
name: handle_failure [46848,46862]
===
match
---
name: dr [37306,37308]
name: dr [37306,37308]
===
match
---
argument [46877,46898]
argument [46877,46898]
===
match
---
operator: , [40172,40173]
operator: , [40172,40173]
===
match
---
operator: , [15415,15416]
operator: , [15415,15416]
===
match
---
atom_expr [21715,21734]
atom_expr [21715,21734]
===
match
---
trailer [6626,6634]
trailer [6626,6634]
===
match
---
string: """     Sets the current execution context to the provided context object.     This method should be called once per Task execution, before calling operator.execute.     """ [3504,3677]
string: """     Sets the current execution context to the provided context object.     This method should be called once per Task execution, before calling operator.execute.     """ [3504,3677]
===
match
---
atom_expr [76205,76217]
atom_expr [76629,76641]
===
match
---
decorated [66304,66918]
decorated [66728,67342]
===
match
---
fstring_expr [47971,47990]
fstring_expr [47971,47990]
===
match
---
atom_expr [62684,62723]
atom_expr [63108,63147]
===
match
---
name: task_id [81629,81636]
name: task_id [82053,82060]
===
match
---
trailer [47902,47918]
trailer [47902,47918]
===
match
---
name: session [56250,56257]
name: session [56674,56681]
===
match
---
name: airflow [58435,58442]
name: airflow [58859,58866]
===
match
---
atom_expr [13689,13703]
atom_expr [13689,13703]
===
match
---
operator: , [72363,72364]
operator: , [72787,72788]
===
match
---
name: hasattr [79919,79926]
name: hasattr [80343,80350]
===
match
---
simple_stmt [23608,23638]
simple_stmt [23608,23638]
===
match
---
name: task_id_by_key [6644,6658]
name: task_id_by_key [6644,6658]
===
match
---
name: str [80027,80030]
name: str [80451,80454]
===
match
---
operator: , [17415,17416]
operator: , [17415,17416]
===
match
---
trailer [7591,7597]
trailer [7591,7597]
===
match
---
arglist [10805,10855]
arglist [10805,10855]
===
match
---
simple_stmt [39866,40188]
simple_stmt [39866,40188]
===
match
---
trailer [19718,19725]
trailer [19718,19725]
===
match
---
atom_expr [58042,58058]
atom_expr [58466,58482]
===
match
---
name: name [53694,53698]
name: name [54118,54122]
===
match
---
operator: = [80060,80061]
operator: = [80484,80485]
===
match
---
trailer [50551,50569]
trailer [50551,50569]
===
match
---
name: error [55204,55209]
name: error [55628,55633]
===
match
---
operator: == [78038,78040]
operator: == [78462,78464]
===
match
---
name: min_backoff [35363,35374]
name: min_backoff [35363,35374]
===
match
---
arglist [41276,41510]
arglist [41276,41510]
===
match
---
operator: = [3329,3330]
operator: = [3329,3330]
===
match
---
name: task_id_by_key [6560,6574]
name: task_id_by_key [6560,6574]
===
match
---
operator: - [70096,70097]
operator: - [70520,70521]
===
match
---
name: Variable [2131,2139]
name: Variable [2131,2139]
===
match
---
trailer [69933,70178]
trailer [70357,70602]
===
match
---
name: state [43493,43498]
name: state [43493,43498]
===
match
---
operator: = [23949,23950]
operator: = [23949,23950]
===
match
---
operator: = [67968,67969]
operator: = [68392,68393]
===
match
---
expr_stmt [52118,52155]
expr_stmt [52260,52297]
===
match
---
name: defaultdict [5405,5416]
name: defaultdict [5405,5416]
===
match
---
name: end_date [54702,54710]
name: end_date [55126,55134]
===
match
---
name: self [59094,59098]
name: self [59518,59522]
===
match
---
name: variable [2115,2123]
name: variable [2115,2123]
===
match
---
suite [4293,4328]
suite [4293,4328]
===
match
---
name: incr [49879,49883]
name: incr [49879,49883]
===
match
---
operator: , [76808,76809]
operator: , [77232,77233]
===
match
---
operator: = [11399,11400]
operator: = [11399,11400]
===
match
---
name: subject [71716,71723]
name: subject [72140,72147]
===
match
---
return_stmt [30762,30810]
return_stmt [30762,30810]
===
match
---
trailer [23996,24008]
trailer [23996,24008]
===
match
---
name: _try_number [11052,11063]
name: _try_number [11052,11063]
===
match
---
trailer [53840,53850]
trailer [54264,54274]
===
match
---
name: TaskInstance [78672,78684]
name: TaskInstance [79096,79108]
===
match
---
operator: , [17089,17090]
operator: , [17089,17090]
===
match
---
funcdef [57932,58282]
funcdef [58356,58706]
===
match
---
param [37739,37752]
param [37739,37752]
===
match
---
name: self [26344,26348]
name: self [26344,26348]
===
match
---
name: self [13241,13245]
name: self [13241,13245]
===
match
---
string: """Get failed Dependencies""" [34121,34150]
string: """Get failed Dependencies""" [34121,34150]
===
match
---
simple_stmt [5801,5822]
simple_stmt [5801,5822]
===
match
---
trailer [50260,50309]
trailer [50260,50309]
===
match
---
operator: , [25739,25740]
operator: , [25739,25740]
===
match
---
trailer [23128,23130]
trailer [23128,23130]
===
match
---
operator: , [67160,67161]
operator: , [67584,67585]
===
match
---
name: fd [4203,4205]
name: fd [4203,4205]
===
match
---
expr_stmt [24746,24779]
expr_stmt [24746,24779]
===
match
---
atom_expr [78128,78176]
atom_expr [78552,78600]
===
match
---
operator: = [8463,8464]
operator: = [8463,8464]
===
match
---
name: self [25521,25525]
name: self [25521,25525]
===
match
---
atom_expr [56315,56328]
atom_expr [56739,56752]
===
match
---
name: ti [79382,79384]
name: ti [79806,79808]
===
match
---
operator: , [44002,44003]
operator: , [44002,44003]
===
match
---
suite [4968,9078]
suite [4968,9078]
===
match
---
name: self [80425,80429]
name: self [80849,80853]
===
match
---
import_from [2569,2615]
import_from [2569,2615]
===
match
---
atom_expr [80062,80068]
atom_expr [80486,80492]
===
match
---
atom_expr [21654,21666]
atom_expr [21654,21666]
===
match
---
name: failed [33455,33461]
name: failed [33455,33461]
===
match
---
tfpdef [51140,51156]
tfpdef [51140,51156]
===
match
---
suite [34254,34668]
suite [34254,34668]
===
match
---
funcdef [80959,81023]
funcdef [81383,81447]
===
match
---
atom_expr [12594,12627]
atom_expr [12594,12627]
===
match
---
name: __repr__ [61631,61639]
name: __repr__ [62055,62063]
===
match
---
simple_stmt [81889,81937]
simple_stmt [82313,82361]
===
match
---
trailer [70715,70960]
trailer [71139,71384]
===
match
---
name: session [4839,4846]
name: session [4839,4846]
===
match
---
name: ti [5811,5813]
name: ti [5811,5813]
===
match
---
name: extend [19647,19653]
name: extend [19647,19653]
===
match
---
name: task [52297,52301]
name: task [52581,52585]
===
match
---
name: ti [80062,80064]
name: ti [80486,80488]
===
match
---
atom_expr [52272,52281]
atom_expr [52556,52565]
===
match
---
atom_expr [30899,30912]
atom_expr [30899,30912]
===
match
---
operator: , [15345,15346]
operator: , [15345,15346]
===
match
---
name: hasattr [68725,68732]
name: hasattr [69149,69156]
===
match
---
atom_expr [23935,23948]
atom_expr [23935,23948]
===
match
---
name: relative_fileloc [16236,16252]
name: relative_fileloc [16236,16252]
===
match
---
string: "DagModel" [15807,15817]
string: "DagModel" [15807,15817]
===
match
---
trailer [47147,47149]
trailer [47147,47149]
===
match
---
name: default_subject [71367,71382]
name: default_subject [71791,71806]
===
match
---
name: cmd [20096,20099]
name: cmd [20096,20099]
===
match
---
dotted_name [8377,8398]
dotted_name [8377,8398]
===
match
---
operator: , [34078,34079]
operator: , [34078,34079]
===
match
---
simple_stmt [15182,15212]
simple_stmt [15182,15212]
===
match
---
param [49959,49964]
param [49959,49964]
===
match
---
suite [15581,17025]
suite [15581,17025]
===
match
---
trailer [19971,20001]
trailer [19971,20001]
===
match
---
name: TaskInstanceKey [25593,25608]
name: TaskInstanceKey [25593,25608]
===
match
---
name: self [32601,32605]
name: self [32601,32605]
===
match
---
name: self [21654,21658]
name: self [21654,21658]
===
match
---
operator: == [37197,37199]
operator: == [37197,37199]
===
match
---
expr_stmt [13837,13859]
expr_stmt [13837,13859]
===
match
---
if_stmt [28377,29050]
if_stmt [28377,29050]
===
match
---
name: DagRunState [4915,4926]
name: DagRunState [4915,4926]
===
match
---
name: pool_override [44811,44824]
name: pool_override [44811,44824]
===
match
---
atom_expr [68176,68206]
atom_expr [68600,68630]
===
match
---
expr_stmt [72186,72206]
expr_stmt [72610,72630]
===
match
---
trailer [16364,16376]
trailer [16364,16376]
===
match
---
simple_stmt [42200,42213]
simple_stmt [42200,42213]
===
match
---
name: max_tries [70121,70130]
name: max_tries [70545,70554]
===
match
---
sync_comp_for [78163,78175]
sync_comp_for [78587,78599]
===
match
---
operator: = [17259,17260]
operator: = [17259,17260]
===
match
---
trailer [36798,36800]
trailer [36798,36800]
===
match
---
name: ignore_task_deps [17276,17292]
name: ignore_task_deps [17276,17292]
===
match
---
trailer [41258,41524]
trailer [41258,41524]
===
match
---
trailer [42266,42281]
trailer [42266,42281]
===
match
---
trailer [42105,42112]
trailer [42105,42112]
===
match
---
import_from [2616,2672]
import_from [2616,2672]
===
match
---
operator: , [54610,54611]
operator: , [55034,55035]
===
match
---
trailer [70269,70296]
trailer [70693,70720]
===
match
---
name: ti [79623,79625]
name: ti [80047,80049]
===
match
---
name: ti_key_str [64748,64758]
name: ti_key_str [65172,65182]
===
match
---
name: min [36306,36309]
name: min [36306,36309]
===
match
---
name: state [54824,54829]
name: state [55248,55253]
===
match
---
funcdef [67477,68451]
funcdef [67901,68875]
===
match
---
name: airflow [58710,58717]
name: airflow [59134,59141]
===
match
---
parameters [57609,57766]
parameters [58033,58190]
===
match
---
name: nullable [11271,11279]
name: nullable [11271,11279]
===
match
---
name: prev_ds [60353,60360]
name: prev_ds [60777,60784]
===
match
---
simple_stmt [49739,49794]
simple_stmt [49739,49794]
===
match
---
atom_expr [14395,14408]
atom_expr [14395,14408]
===
match
---
atom_expr [21630,21650]
atom_expr [21630,21650]
===
match
---
name: self [61426,61430]
name: self [61850,61854]
===
match
---
name: tis [77513,77516]
name: tis [77937,77940]
===
match
---
operator: , [12026,12027]
operator: , [12026,12027]
===
match
---
name: String [11036,11042]
name: String [11036,11042]
===
match
---
argument [7140,7688]
argument [7140,7688]
===
match
---
expr_stmt [24890,24919]
expr_stmt [24890,24919]
===
match
---
suite [51531,52480]
suite [51531,52904]
===
match
---
suite [21195,21886]
suite [21195,21886]
===
match
---
atom_expr [47793,47807]
atom_expr [47793,47807]
===
match
---
tfpdef [37665,37686]
tfpdef [37665,37686]
===
match
---
trailer [58872,58876]
trailer [59296,59300]
===
match
---
name: check_and_change_state_before_execution [37339,37378]
name: check_and_change_state_before_execution [37339,37378]
===
match
---
name: key [73767,73770]
name: key [74191,74194]
===
match
---
name: session [41595,41602]
name: session [41595,41602]
===
match
---
trailer [26489,26495]
trailer [26489,26495]
===
match
---
trailer [52452,52470]
trailer [52761,52779]
===
match
---
name: prev_execution_date [64285,64304]
name: prev_execution_date [64709,64728]
===
match
---
name: self [20773,20777]
name: self [20773,20777]
===
match
---
simple_stmt [42078,42115]
simple_stmt [42078,42115]
===
match
---
decorator [80398,80408]
decorator [80822,80832]
===
match
---
simple_stmt [80674,80692]
simple_stmt [81098,81116]
===
match
---
trailer [59167,59177]
trailer [59591,59601]
===
match
---
name: warn [30515,30519]
name: warn [30515,30519]
===
match
---
name: e [66777,66778]
name: e [67201,67202]
===
match
---
decorator [3430,3457]
decorator [3430,3457]
===
match
---
name: execution_date [60597,60611]
name: execution_date [61021,61035]
===
match
---
string: """         Refreshes the task instance from the database based on the primary key          :param session: SQLAlchemy ORM Session         :type session: Session         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :type lock_for_update: bool         """ [22371,22764]
string: """         Refreshes the task instance from the database based on the primary key          :param session: SQLAlchemy ORM Session         :type session: Session         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :type lock_for_update: bool         """ [22371,22764]
===
match
---
simple_stmt [62015,62244]
simple_stmt [62439,62668]
===
match
---
name: context [50710,50717]
name: context [50710,50717]
===
match
---
name: self [15227,15231]
name: self [15227,15231]
===
match
---
operator: , [1339,1340]
operator: , [1339,1340]
===
match
---
operator: , [48573,48574]
operator: , [48573,48574]
===
match
---
atom_expr [8698,8761]
atom_expr [8698,8761]
===
match
---
name: datetime [942,950]
name: datetime [942,950]
===
match
---
return_stmt [77989,78191]
return_stmt [78413,78615]
===
match
---
atom_expr [6401,6443]
atom_expr [6401,6443]
===
match
---
name: get [76290,76293]
name: get [76714,76717]
===
match
---
simple_stmt [79604,79632]
simple_stmt [80028,80056]
===
match
---
number: 0 [27769,27770]
number: 0 [27769,27770]
===
match
---
name: _schedule [28760,28769]
name: _schedule [28760,28769]
===
match
---
arith_expr [35422,35441]
arith_expr [35422,35441]
===
match
---
name: end_date [23314,23322]
name: end_date [23314,23322]
===
match
---
name: self [80979,80983]
name: self [81403,81407]
===
match
---
simple_stmt [46947,47014]
simple_stmt [46947,47014]
===
match
---
suite [5867,6064]
suite [5867,6064]
===
match
---
suite [45455,45504]
suite [45455,45504]
===
match
---
number: 1 [9246,9247]
number: 1 [9246,9247]
===
match
---
atom_expr [9623,9634]
atom_expr [9623,9634]
===
match
---
arglist [11845,11874]
arglist [11845,11874]
===
match
---
operator: , [57703,57704]
operator: , [58127,58128]
===
match
---
tfpdef [37402,37415]
tfpdef [37402,37415]
===
match
---
trailer [35040,35052]
trailer [35040,35052]
===
match
---
trailer [26439,26450]
trailer [26439,26450]
===
match
---
atom_expr [12464,12475]
atom_expr [12464,12475]
===
match
---
arglist [7353,7406]
arglist [7353,7406]
===
match
---
expr_stmt [23881,23922]
expr_stmt [23881,23922]
===
match
---
name: self [47104,47108]
name: self [47104,47108]
===
match
---
atom_expr [28746,28769]
atom_expr [28746,28769]
===
match
---
name: add [6620,6623]
name: add [6620,6623]
===
match
---
atom_expr [45083,45135]
atom_expr [45083,45135]
===
match
---
parameters [61470,61534]
parameters [61894,61958]
===
match
---
expr_stmt [24161,24212]
expr_stmt [24161,24212]
===
match
---
trailer [56261,56330]
trailer [56685,56754]
===
match
---
return_stmt [80923,80939]
return_stmt [81347,81363]
===
match
---
not_test [34608,34629]
not_test [34608,34629]
===
match
---
atom_expr [42987,43054]
atom_expr [42987,43054]
===
match
---
name: RenderedTaskInstanceFields [48173,48199]
name: RenderedTaskInstanceFields [48173,48199]
===
match
---
name: self [70986,70990]
name: self [71410,71414]
===
match
---
trailer [13134,13145]
trailer [13134,13145]
===
match
---
param [54283,54295]
param [54707,54719]
===
match
---
operator: = [60026,60027]
operator: = [60450,60451]
===
match
---
atom_expr [17436,17449]
atom_expr [17436,17449]
===
match
---
name: _start_date [80381,80392]
name: _start_date [80805,80816]
===
match
---
name: session [21174,21181]
name: session [21174,21181]
===
match
---
funcdef [15253,17025]
funcdef [15253,17025]
===
match
---
name: with_for_update [23105,23120]
name: with_for_update [23105,23120]
===
match
---
simple_stmt [47715,47770]
simple_stmt [47715,47770]
===
match
---
operator: @ [25016,25017]
operator: @ [25016,25017]
===
match
---
simple_stmt [65817,65841]
simple_stmt [66241,66265]
===
match
---
suite [43116,43244]
suite [43116,43244]
===
match
---
decorator [80559,80569]
decorator [80983,80993]
===
match
---
atom_expr [27462,27482]
atom_expr [27462,27482]
===
match
---
operator: = [76088,76089]
operator: = [76512,76513]
===
match
---
simple_stmt [42557,42578]
simple_stmt [42557,42578]
===
match
---
operator: = [11339,11340]
operator: = [11339,11340]
===
match
---
trailer [13338,13340]
trailer [13338,13340]
===
match
---
expr_stmt [79511,79549]
expr_stmt [79935,79973]
===
match
---
atom_expr [44747,44761]
atom_expr [44747,44761]
===
match
---
name: job_id [44899,44905]
name: job_id [44899,44905]
===
match
---
name: dag_id [8548,8554]
name: dag_id [8548,8554]
===
match
---
name: self [24310,24314]
name: self [24310,24314]
===
match
---
atom_expr [36737,36747]
atom_expr [36737,36747]
===
match
---
name: self [80889,80893]
name: self [81313,81317]
===
match
---
import_name [805,819]
import_name [805,819]
===
match
---
expr_stmt [57097,57128]
expr_stmt [57521,57552]
===
match
---
name: DagRun [37155,37161]
name: DagRun [37155,37161]
===
match
---
trailer [19964,19971]
trailer [19964,19971]
===
match
---
argument [12193,12245]
argument [12193,12245]
===
match
---
name: airflow [2326,2333]
name: airflow [2326,2333]
===
match
---
name: task [51791,51795]
name: task [51791,51795]
===
match
---
tfpdef [17276,17298]
tfpdef [17276,17298]
===
match
---
trailer [70277,70285]
trailer [70701,70709]
===
match
---
name: str [73746,73749]
name: str [74170,74173]
===
match
---
name: state [26191,26196]
name: state [26191,26196]
===
match
---
trailer [77055,77059]
trailer [77479,77483]
===
match
---
string: 'prev_ds' [64184,64193]
string: 'prev_ds' [64608,64617]
===
match
---
atom_expr [13015,13074]
atom_expr [13015,13074]
===
match
---
parameters [80730,80736]
parameters [81154,81160]
===
match
---
operator: == [78216,78218]
operator: == [78640,78642]
===
match
---
trailer [13375,13381]
trailer [13375,13381]
===
match
---
operator: = [22197,22198]
operator: = [22197,22198]
===
match
---
name: self [79558,79562]
name: self [79982,79986]
===
match
---
comparison [14381,14408]
comparison [14381,14408]
===
match
---
decorator [32656,32673]
decorator [32656,32673]
===
match
---
name: state [64431,64436]
name: state [64855,64860]
===
match
---
name: airflow [65419,65426]
name: airflow [65843,65850]
===
match
---
name: Column [11540,11546]
name: Column [11540,11546]
===
match
---
name: self [25584,25588]
name: self [25584,25588]
===
match
---
arglist [75624,75821]
arglist [76048,76245]
===
match
---
trailer [62563,62573]
trailer [62987,62997]
===
match
---
atom_expr [16477,17024]
atom_expr [16477,17024]
===
match
---
name: execution_date [9900,9914]
name: execution_date [9900,9914]
===
match
---
simple_stmt [4302,4328]
simple_stmt [4302,4328]
===
match
---
operator: , [57759,57760]
operator: , [58183,58184]
===
match
---
operator: = [70245,70246]
operator: = [70669,70670]
===
match
---
name: str [17108,17111]
name: str [17108,17111]
===
match
---
name: task_ids [7397,7405]
name: task_ids [7397,7405]
===
match
---
operator: , [64465,64466]
operator: , [64889,64890]
===
match
---
operator: , [10746,10747]
operator: , [10746,10747]
===
match
---
trailer [49761,49793]
trailer [49761,49793]
===
match
---
trailer [72069,72080]
trailer [72493,72504]
===
match
---
trailer [28884,28899]
trailer [28884,28899]
===
match
---
atom_expr [49647,49685]
atom_expr [49647,49685]
===
match
---
name: get [71136,71139]
name: get [71560,71563]
===
match
---
suite [29682,29767]
suite [29682,29767]
===
match
---
trailer [17444,17449]
trailer [17444,17449]
===
match
---
trailer [52410,52423]
trailer [52694,52707]
===
match
---
param [47337,47345]
param [47337,47345]
===
match
---
name: XCom [76485,76489]
name: XCom [76909,76913]
===
match
---
name: iso [20472,20475]
name: iso [20472,20475]
===
match
---
atom_expr [5811,5821]
atom_expr [5811,5821]
===
match
---
name: params [67154,67160]
name: params [67578,67584]
===
match
---
trailer [6623,6635]
trailer [6623,6635]
===
match
---
expr_stmt [45776,45802]
expr_stmt [45776,45802]
===
match
---
name: dep_context [33405,33416]
name: dep_context [33405,33416]
===
match
---
atom_expr [65929,66291]
atom_expr [66353,66715]
===
match
---
param [51470,51475]
param [51470,51475]
===
match
---
name: self [45380,45384]
name: self [45380,45384]
===
match
---
suite [67291,67472]
suite [67715,67896]
===
match
---
atom_expr [11066,11106]
atom_expr [11066,11106]
===
match
---
trailer [29431,29439]
trailer [29431,29439]
===
match
---
name: self [9279,9283]
name: self [9279,9283]
===
match
---
simple_stmt [10920,10953]
simple_stmt [10920,10953]
===
match
---
name: try_number [35668,35678]
name: try_number [35668,35678]
===
match
---
string: "--job-id" [19727,19737]
string: "--job-id" [19727,19737]
===
match
---
name: str [61516,61519]
name: str [61940,61943]
===
match
---
name: __getattr__ [62326,62337]
name: __getattr__ [62750,62761]
===
match
---
name: Index [1313,1318]
name: Index [1313,1318]
===
match
---
trailer [81913,81919]
trailer [82337,82343]
===
match
---
trailer [60980,61021]
trailer [61404,61445]
===
match
---
operator: == [22915,22917]
operator: == [22915,22917]
===
match
---
name: dag [15789,15792]
name: dag [15789,15792]
===
match
---
name: self [26490,26494]
name: self [26490,26494]
===
match
---
name: self [80459,80463]
name: self [80883,80887]
===
match
---
operator: , [55702,55703]
operator: , [56126,56127]
===
match
---
trailer [13291,13302]
trailer [13291,13302]
===
match
---
param [55190,55195]
param [55614,55619]
===
match
---
name: query [58820,58825]
name: query [59244,59249]
===
match
---
simple_stmt [2826,2876]
simple_stmt [2826,2876]
===
match
---
trailer [24932,24948]
trailer [24932,24948]
===
match
---
name: execution_date [59963,59977]
name: execution_date [60387,60401]
===
match
---
name: UP_FOR_RESCHEDULE [40809,40826]
name: UP_FOR_RESCHEDULE [40809,40826]
===
match
---
operator: , [53656,53657]
operator: , [54080,54081]
===
match
---
parameters [30314,30320]
parameters [30314,30320]
===
match
---
name: dag_id [12469,12475]
name: dag_id [12469,12475]
===
match
---
and_test [16093,16114]
and_test [16093,16114]
===
match
---
name: NONE [6473,6477]
name: NONE [6473,6477]
===
match
---
string: """Return TI Context""" [58373,58396]
string: """Return TI Context""" [58797,58820]
===
match
---
trailer [67069,67074]
trailer [67493,67498]
===
match
---
name: ti [6586,6588]
name: ti [6586,6588]
===
match
---
atom_expr [81590,81602]
atom_expr [82014,82026]
===
match
---
string: "run" [19512,19517]
string: "run" [19512,19517]
===
match
---
exprlist [7556,7582]
exprlist [7556,7582]
===
match
---
name: bool [17254,17258]
name: bool [17254,17258]
===
match
---
operator: , [7655,7656]
operator: , [7655,7656]
===
match
---
name: state [57102,57107]
name: state [57526,57531]
===
match
---
atom_expr [45789,45802]
atom_expr [45789,45802]
===
match
---
param [9955,9959]
param [9955,9959]
===
match
---
name: task [46971,46975]
name: task [46971,46975]
===
match
---
suite [16336,16461]
suite [16336,16461]
===
match
---
name: var [62424,62427]
name: var [62848,62851]
===
match
---
trailer [63577,63583]
trailer [64001,64007]
===
match
---
name: Stats [47934,47939]
name: Stats [47934,47939]
===
match
---
expr_stmt [11291,11346]
expr_stmt [11291,11346]
===
match
---
name: following_schedule [59939,59957]
name: following_schedule [60363,60381]
===
match
---
operator: = [75595,75596]
operator: = [76019,76020]
===
match
---
name: error_file [46734,46744]
name: error_file [46734,46744]
===
match
---
name: duration [23354,23362]
name: duration [23354,23362]
===
match
---
trailer [13693,13703]
trailer [13693,13703]
===
match
---
operator: = [35865,35866]
operator: = [35865,35866]
===
match
---
atom_expr [33572,33642]
atom_expr [33572,33642]
===
match
---
operator: = [71228,71229]
operator: = [71652,71653]
===
match
---
name: self [42522,42526]
name: self [42522,42526]
===
match
---
trailer [60753,60762]
trailer [61177,61186]
===
match
---
atom_expr [25714,25725]
atom_expr [25714,25725]
===
match
---
tfpdef [36868,36884]
tfpdef [36868,36884]
===
match
---
name: airflow [1599,1606]
name: airflow [1599,1606]
===
match
---
operator: = [57730,57731]
operator: = [58154,58155]
===
match
---
operator: , [71737,71738]
operator: , [72161,72162]
===
match
---
trailer [43524,43531]
trailer [43524,43531]
===
match
---
trailer [62297,62301]
trailer [62721,62725]
===
match
---
name: state [80577,80582]
name: state [81001,81006]
===
match
---
atom_expr [41248,41524]
atom_expr [41248,41524]
===
match
---
name: self [46282,46286]
name: self [46282,46286]
===
match
---
name: len [27796,27799]
name: len [27796,27799]
===
match
---
name: timezone [54419,54427]
name: timezone [54843,54851]
===
match
---
suite [55526,55941]
suite [55950,56365]
===
match
---
name: dag_id [17078,17084]
name: dag_id [17078,17084]
===
match
---
name: airflow [7827,7834]
name: airflow [7827,7834]
===
match
---
name: log [2635,2638]
name: log [2635,2638]
===
match
---
trailer [12524,12529]
trailer [12524,12529]
===
match
---
simple_stmt [58546,58558]
simple_stmt [58970,58982]
===
match
---
name: self [70862,70866]
name: self [71286,71290]
===
match
---
return_stmt [27411,27422]
return_stmt [27411,27422]
===
match
---
operator: , [71526,71527]
operator: , [71950,71951]
===
match
---
operator: , [1311,1312]
operator: , [1311,1312]
===
match
---
name: RUNNING_DEPS [39929,39941]
name: RUNNING_DEPS [39929,39941]
===
match
---
operator: = [8312,8313]
operator: = [8312,8313]
===
match
---
simple_stmt [42476,42514]
simple_stmt [42476,42514]
===
match
---
name: dag [4880,4883]
name: dag [4880,4883]
===
match
---
name: self [50086,50090]
name: self [50086,50090]
===
match
---
import_from [2876,2924]
import_from [2876,2924]
===
match
---
name: ignore_ti_state [53186,53201]
name: ignore_ti_state [53610,53625]
===
match
---
name: ConnectionAccessor [65178,65196]
name: ConnectionAccessor [65602,65620]
===
match
---
param [26532,26536]
param [26532,26536]
===
match
---
atom_expr [40207,40334]
atom_expr [40207,40334]
===
match
---
name: default_subject [68818,68833]
name: default_subject [69242,69257]
===
match
---
name: unixname [13320,13328]
name: unixname [13320,13328]
===
match
---
atom_expr [10933,10952]
atom_expr [10933,10952]
===
match
---
simple_stmt [47235,47255]
simple_stmt [47235,47255]
===
match
---
operator: @ [80867,80868]
operator: @ [81291,81292]
===
match
---
suite [61535,61614]
suite [61959,62038]
===
match
---
expr_stmt [76394,76440]
expr_stmt [76818,76864]
===
match
---
name: dep_context [41582,41593]
name: dep_context [41582,41593]
===
match
---
name: add [47196,47199]
name: add [47196,47199]
===
match
---
name: get_previous_ti [30774,30789]
name: get_previous_ti [30774,30789]
===
match
---
argument [73445,73465]
argument [73869,73889]
===
match
---
name: session [53353,53360]
name: session [53777,53784]
===
match
---
operator: , [67768,67769]
operator: , [68192,68193]
===
match
---
operator: , [24308,24309]
operator: , [24308,24309]
===
match
---
trailer [7164,7171]
trailer [7164,7171]
===
match
---
name: max_tries [6389,6398]
name: max_tries [6389,6398]
===
match
---
name: task_copy [47953,47962]
name: task_copy [47953,47962]
===
match
---
name: self [42145,42149]
name: self [42145,42149]
===
match
---
decorator [32082,32092]
decorator [32082,32092]
===
match
---
name: str [62383,62386]
name: str [62807,62810]
===
match
---
name: refresh_from_db [46429,46444]
name: refresh_from_db [46429,46444]
===
match
---
simple_stmt [36534,36563]
simple_stmt [36534,36563]
===
match
---
simple_stmt [6490,6521]
simple_stmt [6490,6521]
===
match
---
suite [13937,14482]
suite [13937,14482]
===
match
---
tfpdef [43105,43114]
tfpdef [43105,43114]
===
match
---
tfpdef [73767,73775]
tfpdef [74191,74199]
===
match
---
param [81083,81096]
param [81507,81520]
===
match
---
trailer [14385,14391]
trailer [14385,14391]
===
match
---
param [50333,50338]
param [50333,50338]
===
match
---
operator: , [15805,15806]
operator: , [15805,15806]
===
match
---
simple_stmt [1275,1373]
simple_stmt [1275,1373]
===
match
---
suite [78551,78840]
suite [78975,79264]
===
match
---
expr_stmt [23563,23595]
expr_stmt [23563,23595]
===
match
---
name: ti [21814,21816]
name: ti [21814,21816]
===
match
---
funcdef [81049,81867]
funcdef [81473,82291]
===
match
---
name: self [56993,56997]
name: self [57417,57421]
===
match
---
name: filter [22875,22881]
name: filter [22875,22881]
===
match
---
name: self [23563,23567]
name: self [23563,23567]
===
match
---
simple_stmt [57784,57878]
simple_stmt [58208,58302]
===
match
---
name: task_id [45125,45132]
name: task_id [45125,45132]
===
match
---
name: self [9955,9959]
name: self [9955,9959]
===
match
---
if_stmt [35061,36526]
if_stmt [35061,36526]
===
match
---
name: context [50885,50892]
name: context [50885,50892]
===
match
---
simple_stmt [6016,6064]
simple_stmt [6016,6064]
===
match
---
name: task [44805,44809]
name: task [44805,44809]
===
match
---
trailer [52816,52821]
trailer [53240,53245]
===
match
---
atom_expr [7162,7171]
atom_expr [7162,7171]
===
match
---
trailer [11365,11378]
trailer [11365,11378]
===
match
---
atom_expr [67430,67471]
atom_expr [67854,67895]
===
match
---
operator: } [65306,65307]
operator: } [65730,65731]
===
match
---
expr_stmt [11534,11555]
expr_stmt [11534,11555]
===
match
---
operator: } [58512,58513]
operator: } [58936,58937]
===
match
---
name: airflow [82029,82036]
name: airflow [82453,82460]
===
match
---
operator: @ [30277,30278]
operator: @ [30277,30278]
===
match
---
name: replace [60441,60448]
name: replace [60865,60872]
===
match
---
name: max_tries [70136,70145]
name: max_tries [70560,70569]
===
match
---
name: self [35615,35619]
name: self [35615,35619]
===
match
---
trailer [24955,24971]
trailer [24955,24971]
===
match
---
name: test_mode [54364,54373]
name: test_mode [54788,54797]
===
match
---
trailer [72219,72223]
trailer [72643,72647]
===
match
---
trailer [39189,39207]
trailer [39189,39207]
===
match
---
simple_stmt [39530,39571]
simple_stmt [39530,39571]
===
match
---
expr_stmt [7708,7760]
expr_stmt [7708,7760]
===
match
---
name: instance [8494,8502]
name: instance [8494,8502]
===
match
---
number: 1 [23833,23834]
number: 1 [23833,23834]
===
match
---
name: from_string [71272,71283]
name: from_string [71696,71707]
===
match
---
name: has_task [5849,5857]
name: has_task [5849,5857]
===
match
---
name: state [47209,47214]
name: state [47209,47214]
===
match
---
operator: , [30952,30953]
operator: , [30952,30953]
===
match
---
suite [7945,7987]
suite [7945,7987]
===
match
---
name: dag_run [58566,58573]
name: dag_run [58990,58997]
===
match
---
argument [40076,40121]
argument [40076,40121]
===
match
---
name: self [14381,14385]
name: self [14381,14385]
===
match
---
name: TemplateAssertionError [1236,1258]
name: TemplateAssertionError [1236,1258]
===
match
---
trailer [10884,10915]
trailer [10884,10915]
===
match
---
atom_expr [39345,39356]
atom_expr [39345,39356]
===
match
---
trailer [56194,56201]
trailer [56618,56625]
===
match
---
testlist_comp [20161,20175]
testlist_comp [20161,20175]
===
match
---
param [67248,67281]
param [67672,67705]
===
match
---
name: _try_number [23584,23595]
name: _try_number [23584,23595]
===
match
---
name: session [29750,29757]
name: session [29750,29757]
===
match
---
atom_expr [48354,48410]
atom_expr [48354,48410]
===
match
---
operator: = [13329,13330]
operator: = [13329,13330]
===
match
---
simple_stmt [885,901]
simple_stmt [885,901]
===
match
---
simple_stmt [26878,27332]
simple_stmt [26878,27332]
===
match
---
argument [32630,32649]
argument [32630,32649]
===
match
---
name: merge [42624,42629]
name: merge [42624,42629]
===
match
---
simple_stmt [77572,77587]
simple_stmt [77996,78011]
===
match
---
trailer [60115,60127]
trailer [60539,60551]
===
match
---
name: warn [8043,8047]
name: warn [8043,8047]
===
match
---
arith_expr [20874,21123]
arith_expr [20874,21123]
===
match
---
import_from [1428,1470]
import_from [1428,1470]
===
match
---
suite [20083,20120]
suite [20083,20120]
===
match
---
name: Optional [43918,43926]
name: Optional [43918,43926]
===
match
---
trailer [54823,54829]
trailer [55247,55253]
===
match
---
expr_stmt [33455,33469]
expr_stmt [33455,33469]
===
match
---
atom_expr [24928,24948]
atom_expr [24928,24948]
===
match
---
name: datetime [9215,9223]
name: datetime [9215,9223]
===
match
---
atom_expr [80201,80214]
atom_expr [80625,80638]
===
match
---
import_name [787,804]
import_name [787,804]
===
match
---
import_from [1018,1117]
import_from [1018,1117]
===
match
---
argument [31904,31919]
argument [31904,31919]
===
match
---
arglist [37183,37257]
arglist [37183,37257]
===
match
---
simple_stmt [12783,12946]
simple_stmt [12783,12946]
===
match
---
trailer [25329,25478]
trailer [25329,25478]
===
match
---
name: self [72257,72261]
name: self [72681,72685]
===
match
---
trailer [7938,7942]
trailer [7938,7942]
===
match
---
atom_expr [52039,52048]
atom_expr [52181,52190]
===
match
---
name: self [58267,58271]
name: self [58691,58695]
===
match
---
arglist [33721,33873]
arglist [33721,33873]
===
match
---
if_stmt [77897,78192]
if_stmt [78321,78616]
===
match
---
trailer [76128,76146]
trailer [76552,76570]
===
match
---
decorated [57556,57927]
decorated [57980,58351]
===
match
---
trailer [4590,4595]
trailer [4590,4595]
===
match
---
name: self [23730,23734]
name: self [23730,23734]
===
match
---
trailer [27565,27573]
trailer [27565,27573]
===
match
---
suite [62739,62904]
suite [63163,63328]
===
match
---
string: 'execution_date' [63848,63864]
string: 'execution_date' [64272,64288]
===
match
---
funcdef [15147,15248]
funcdef [15147,15248]
===
match
---
operator: } [34774,34775]
operator: } [34774,34775]
===
match
---
operator: , [8182,8183]
operator: , [8182,8183]
===
match
---
atom_expr [79434,79451]
atom_expr [79858,79875]
===
match
---
name: priority_weight [11383,11398]
name: priority_weight [11383,11398]
===
match
---
decorated [9445,9700]
decorated [9445,9700]
===
match
---
trailer [42174,42181]
trailer [42174,42181]
===
match
---
and_test [31361,31414]
and_test [31361,31414]
===
match
---
operator: = [6029,6030]
operator: = [6029,6030]
===
match
---
simple_stmt [31224,31277]
simple_stmt [31224,31277]
===
match
---
name: ignore_depends_on_past [40099,40121]
name: ignore_depends_on_past [40099,40121]
===
match
---
name: self [23975,23979]
name: self [23975,23979]
===
match
---
operator: == [78093,78095]
operator: == [78517,78519]
===
match
---
operator: = [62302,62303]
operator: = [62726,62727]
===
match
---
number: 2 [35440,35441]
number: 2 [35440,35441]
===
match
---
trailer [3860,3868]
trailer [3860,3868]
===
match
---
name: dag_id [80092,80098]
name: dag_id [80516,80522]
===
match
---
atom_expr [30324,30348]
atom_expr [30324,30348]
===
match
---
operator: = [17450,17451]
operator: = [17450,17451]
===
match
---
trailer [56006,56008]
trailer [56430,56432]
===
match
---
trailer [44966,44973]
trailer [44966,44973]
===
match
---
name: total_seconds [26452,26465]
name: total_seconds [26452,26465]
===
match
---
name: reconstructor [13718,13731]
name: reconstructor [13718,13731]
===
match
---
name: bool [17294,17298]
name: bool [17294,17298]
===
match
---
operator: -> [71997,71999]
operator: -> [72421,72423]
===
match
---
simple_stmt [12545,12574]
simple_stmt [12545,12574]
===
match
---
name: jinja_context [70493,70506]
name: jinja_context [70917,70930]
===
match
---
decorator [76519,76536]
decorator [76943,76960]
===
match
---
simple_stmt [27983,28212]
simple_stmt [27983,28212]
===
match
---
trailer [54462,54464]
trailer [54886,54888]
===
match
---
simple_stmt [56045,56101]
simple_stmt [56469,56525]
===
match
---
trailer [48604,48612]
trailer [48604,48612]
===
match
---
comp_op [52089,52095]
comp_op [52231,52237]
===
match
---
tfpdef [4418,4433]
tfpdef [4418,4433]
===
match
---
atom_expr [70440,70507]
atom_expr [70864,70931]
===
match
---
name: dag_id [73729,73735]
name: dag_id [74153,74159]
===
match
---
operator: , [48493,48494]
operator: , [48493,48494]
===
match
---
expr_stmt [41234,41524]
expr_stmt [41234,41524]
===
match
---
suite [71901,71969]
suite [72325,72393]
===
match
---
operator: , [55558,55559]
operator: , [55982,55983]
===
match
---
name: self [9868,9872]
name: self [9868,9872]
===
match
---
arglist [15937,15949]
arglist [15937,15949]
===
match
---
name: email_for_state [57270,57285]
name: email_for_state [57694,57709]
===
match
---
expr_stmt [11421,11452]
expr_stmt [11421,11452]
===
match
---
simple_stmt [20724,20753]
simple_stmt [20724,20753]
===
match
---
parameters [58332,58352]
parameters [58756,58776]
===
match
---
trailer [29535,29552]
trailer [29535,29552]
===
match
---
name: ti [23625,23627]
name: ti [23625,23627]
===
match
---
suite [51828,51978]
suite [51828,52120]
===
match
---
name: self [35031,35035]
name: self [35031,35035]
===
match
---
atom_expr [58812,58945]
atom_expr [59236,59369]
===
match
---
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.value.variable_name }}`` or             ``{{ var.value.get('variable_name', 'fallback') }}``.             """ [61152,61376]
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.value.variable_name }}`` or             ``{{ var.value.get('variable_name', 'fallback') }}``.             """ [61576,61800]
===
match
---
name: exception [71789,71798]
name: exception [72213,72222]
===
match
---
simple_stmt [8960,8981]
simple_stmt [8960,8981]
===
match
---
name: ignore_task_deps [53156,53172]
name: ignore_task_deps [53580,53596]
===
match
---
name: str [80592,80595]
name: str [81016,81019]
===
match
---
if_stmt [51716,52480]
if_stmt [51716,52904]
===
match
---
name: Column [11359,11365]
name: Column [11359,11365]
===
match
---
name: task [5884,5888]
name: task [5884,5888]
===
match
---
name: BaseJob [7898,7905]
name: BaseJob [7898,7905]
===
match
---
trailer [40921,40923]
trailer [40921,40923]
===
match
---
operator: = [27345,27346]
operator: = [27345,27346]
===
match
---
parameters [47580,47595]
parameters [47580,47595]
===
match
---
fstring_expr [45105,45118]
fstring_expr [45105,45118]
===
match
---
string: """Return Number of running TIs from the DB""" [76599,76645]
string: """Return Number of running TIs from the DB""" [77023,77069]
===
match
---
name: exception_html [70018,70032]
name: exception_html [70442,70456]
===
match
---
name: stacklevel [30210,30220]
name: stacklevel [30210,30220]
===
match
---
name: RenderedTaskInstanceFields [48067,48093]
name: RenderedTaskInstanceFields [48067,48093]
===
match
---
trailer [42883,42888]
trailer [42883,42888]
===
match
---
operator: = [37687,37688]
operator: = [37687,37688]
===
match
---
trailer [50616,50661]
trailer [50616,50661]
===
match
---
expr_stmt [50086,50121]
expr_stmt [50086,50121]
===
match
---
expr_stmt [59143,59179]
expr_stmt [59567,59603]
===
match
---
trailer [78955,79017]
trailer [79379,79441]
===
match
---
simple_stmt [54013,54030]
simple_stmt [54437,54454]
===
match
---
name: Any [62678,62681]
name: Any [63102,63105]
===
match
---
trailer [5949,5955]
trailer [5949,5955]
===
match
---
string: """Get Airflow Variable after deserializing JSON value""" [62756,62813]
string: """Get Airflow Variable after deserializing JSON value""" [63180,63237]
===
match
---
simple_stmt [3504,3678]
simple_stmt [3504,3678]
===
match
---
name: RUNNING [76908,76915]
name: RUNNING [77332,77339]
===
match
---
name: tomorrow_ds [60792,60803]
name: tomorrow_ds [61216,61227]
===
match
---
name: key [71149,71152]
name: key [71573,71576]
===
match
---
name: dag [16010,16013]
name: dag [16010,16013]
===
match
---
trailer [55592,55596]
trailer [56016,56020]
===
match
---
name: self [67790,67794]
name: self [68214,68218]
===
match
---
string: "airflow.task" [12612,12626]
string: "airflow.task" [12612,12626]
===
match
---
name: subject [70340,70347]
name: subject [70764,70771]
===
match
---
simple_stmt [45252,45313]
simple_stmt [45252,45313]
===
match
---
trailer [41699,41714]
trailer [41699,41714]
===
match
---
name: verbose [33518,33525]
name: verbose [33518,33525]
===
match
---
import_as_names [1298,1372]
import_as_names [1298,1372]
===
match
---
string: 'Host: {{ti.hostname}}<br>' [69232,69259]
string: 'Host: {{ti.hostname}}<br>' [69656,69683]
===
match
---
operator: = [15526,15527]
operator: = [15526,15527]
===
match
---
operator: , [54281,54282]
operator: , [54705,54706]
===
match
---
suite [10127,79018]
suite [10127,79442]
===
match
---
name: session [73585,73592]
name: session [74009,74016]
===
match
---
name: AirflowException [46389,46405]
name: AirflowException [46389,46405]
===
match
---
name: try_number [6034,6044]
name: try_number [6034,6044]
===
match
---
simple_stmt [24928,24972]
simple_stmt [24928,24972]
===
match
---
operator: , [11269,11270]
operator: , [11269,11270]
===
match
---
simple_stmt [25303,25488]
simple_stmt [25303,25488]
===
match
---
name: property [9446,9454]
name: property [9446,9454]
===
match
---
arglist [49074,49087]
arglist [49074,49087]
===
match
---
atom_expr [42535,42548]
atom_expr [42535,42548]
===
match
---
name: task_copy [50617,50626]
name: task_copy [50617,50626]
===
match
---
operator: = [17338,17339]
operator: = [17338,17339]
===
match
---
suite [76590,76963]
suite [77014,77387]
===
match
---
operator: = [11001,11002]
operator: = [11001,11002]
===
match
---
name: value [51067,51072]
name: value [51067,51072]
===
match
---
trailer [68387,68389]
trailer [68811,68813]
===
match
---
trailer [58937,58943]
trailer [59361,59367]
===
match
---
argument [41276,41297]
argument [41276,41297]
===
match
---
name: Integer [1320,1327]
name: Integer [1320,1327]
===
match
---
trailer [58675,58692]
trailer [59099,59116]
===
match
---
parameters [9954,9960]
parameters [9954,9960]
===
match
---
name: TaskInstance [82070,82082]
name: TaskInstance [82494,82506]
===
match
---
parameters [80098,80104]
parameters [80522,80528]
===
match
---
operator: , [20556,20557]
operator: , [20556,20557]
===
match
---
name: incr [45089,45093]
name: incr [45089,45093]
===
match
---
atom_expr [47104,47121]
atom_expr [47104,47121]
===
match
---
name: context [3836,3843]
name: context [3836,3843]
===
match
---
name: xcom_pull [73634,73643]
name: xcom_pull [74058,74067]
===
match
---
simple_stmt [45083,45136]
simple_stmt [45083,45136]
===
match
---
name: self [72186,72190]
name: self [72610,72614]
===
match
---
name: utcnow [56000,56006]
name: utcnow [56424,56430]
===
match
---
param [52537,52558]
param [52961,52982]
===
match
---
trailer [53877,53879]
trailer [54301,54303]
===
match
---
expr_stmt [68362,68421]
expr_stmt [68786,68845]
===
match
---
atom_expr [71925,71940]
atom_expr [72349,72364]
===
match
---
operator: == [26309,26311]
operator: == [26309,26311]
===
match
---
trailer [25387,25395]
trailer [25387,25395]
===
match
---
atom_expr [65817,65840]
atom_expr [66241,66264]
===
match
---
name: try_number [23568,23578]
name: try_number [23568,23578]
===
match
---
operator: = [68834,68835]
operator: = [69258,69259]
===
match
---
name: SUCCESS [64443,64450]
name: SUCCESS [64867,64874]
===
match
---
name: Optional [67510,67518]
name: Optional [67934,67942]
===
match
---
trailer [48037,48054]
trailer [48037,48054]
===
match
---
name: var [62569,62572]
name: var [62993,62996]
===
match
---
string: """         Generates the shell command required to execute this task instance.          :param dag_id: DAG ID         :type dag_id: str         :param task_id: Task ID         :type task_id: str         :param execution_date: Execution date for the task         :type execution_date: datetime         :param mark_success: Whether to mark the task as successful         :type mark_success: bool         :param ignore_all_deps: Ignore all ignorable dependencies.             Overrides the other ignore_* parameters.         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past parameter of DAGs             (e.g. for Backfills)         :type ignore_depends_on_past: bool         :param ignore_task_deps: Ignore task-specific dependencies such as depends_on_past             and trigger rule         :type ignore_task_deps: bool         :param ignore_ti_state: Ignore the task instance's previous failure/success         :type ignore_ti_state: bool         :param local: Whether to run the task locally         :type local: bool         :param pickle_id: If the DAG was serialized to the DB, the ID             associated with the pickled DAG         :type pickle_id: Optional[int]         :param file_path: path to the file containing the DAG definition         :type file_path: Optional[str]         :param raw: raw mode (needs more details)         :type raw: Optional[bool]         :param job_id: job ID (needs more details)         :type job_id: Optional[int]         :param pool: the Airflow pool that the task should run in         :type pool: Optional[str]         :param cfg_path: the Path to the configuration file         :type cfg_path: Optional[str]         :return: shell command that can be used to run the task instance         :rtype: list[str]         """ [17627,19435]
string: """         Generates the shell command required to execute this task instance.          :param dag_id: DAG ID         :type dag_id: str         :param task_id: Task ID         :type task_id: str         :param execution_date: Execution date for the task         :type execution_date: datetime         :param mark_success: Whether to mark the task as successful         :type mark_success: bool         :param ignore_all_deps: Ignore all ignorable dependencies.             Overrides the other ignore_* parameters.         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past parameter of DAGs             (e.g. for Backfills)         :type ignore_depends_on_past: bool         :param ignore_task_deps: Ignore task-specific dependencies such as depends_on_past             and trigger rule         :type ignore_task_deps: bool         :param ignore_ti_state: Ignore the task instance's previous failure/success         :type ignore_ti_state: bool         :param local: Whether to run the task locally         :type local: bool         :param pickle_id: If the DAG was serialized to the DB, the ID             associated with the pickled DAG         :type pickle_id: Optional[int]         :param file_path: path to the file containing the DAG definition         :type file_path: Optional[str]         :param raw: raw mode (needs more details)         :type raw: Optional[bool]         :param job_id: job ID (needs more details)         :type job_id: Optional[int]         :param pool: the Airflow pool that the task should run in         :type pool: Optional[str]         :param cfg_path: the Path to the configuration file         :type cfg_path: Optional[str]         :return: shell command that can be used to run the task instance         :rtype: list[str]         """ [17627,19435]
===
match
---
name: result [43125,43131]
name: result [43125,43131]
===
match
---
arglist [41570,41624]
arglist [41570,41624]
===
match
---
name: self [67757,67761]
name: self [68181,68185]
===
match
---
operator: = [69379,69380]
operator: = [69803,69804]
===
match
---
tfpdef [17425,17449]
tfpdef [17425,17449]
===
match
---
and_test [50972,51017]
and_test [50972,51017]
===
match
---
name: operator [24985,24993]
name: operator [24985,24993]
===
match
---
simple_stmt [24239,24257]
simple_stmt [24239,24257]
===
match
---
name: dag_id [47963,47969]
name: dag_id [47963,47969]
===
match
---
simple_stmt [23730,23754]
simple_stmt [23730,23754]
===
match
---
name: self [14461,14465]
name: self [14461,14465]
===
match
---
name: cfg_path [20309,20317]
name: cfg_path [20309,20317]
===
match
---
name: _key [80055,80059]
name: _key [80479,80483]
===
match
---
name: log [45473,45476]
name: log [45473,45476]
===
match
---
operator: , [10818,10819]
operator: , [10818,10819]
===
match
---
atom_expr [47062,47075]
atom_expr [47062,47075]
===
match
---
name: yesterday_ds [65228,65240]
name: yesterday_ds [65652,65664]
===
match
---
operator: = [24043,24044]
operator: = [24043,24044]
===
match
---
name: state [64584,64589]
name: state [65008,65013]
===
match
---
expr_stmt [59188,59260]
expr_stmt [59612,59684]
===
match
---
expr_stmt [16040,16060]
expr_stmt [16040,16060]
===
match
---
testlist_comp [76282,76326]
testlist_comp [76706,76750]
===
match
---
name: dag [63741,63744]
name: dag [64165,64168]
===
match
---
string: 'ds_nodash' [63812,63823]
string: 'ds_nodash' [64236,64247]
===
match
---
name: registered [49024,49034]
name: registered [49024,49034]
===
match
---
trailer [28759,28769]
trailer [28759,28769]
===
match
---
operator: = [21858,21859]
operator: = [21858,21859]
===
match
---
name: render_templates [67225,67241]
name: render_templates [67649,67665]
===
match
---
sync_comp_for [7436,7482]
sync_comp_for [7436,7482]
===
match
---
suite [24226,24257]
suite [24226,24257]
===
match
---
atom_expr [47264,47280]
atom_expr [47264,47280]
===
match
---
name: self [67430,67434]
name: self [67854,67858]
===
match
---
simple_stmt [50158,50175]
simple_stmt [50158,50175]
===
match
---
name: tempfile [983,991]
name: tempfile [983,991]
===
match
---
name: self [67088,67092]
name: self [67512,67516]
===
match
---
suite [80665,80692]
suite [81089,81116]
===
match
---
name: lead_msg [43270,43278]
name: lead_msg [43270,43278]
===
match
---
atom_expr [70862,70877]
atom_expr [71286,71301]
===
match
---
atom_expr [58466,58492]
atom_expr [58890,58916]
===
match
---
name: state [29641,29646]
name: state [29641,29646]
===
match
---
simple_stmt [71825,71876]
simple_stmt [72249,72300]
===
match
---
atom_expr [25258,25294]
atom_expr [25258,25294]
===
match
---
name: pool [39228,39232]
name: pool [39228,39232]
===
match
---
name: commit [22256,22262]
name: commit [22256,22262]
===
match
---
arglist [57804,57876]
arglist [58228,58300]
===
match
---
trailer [48515,48520]
trailer [48515,48520]
===
match
---
trailer [34366,34587]
trailer [34366,34587]
===
match
---
tfpdef [17567,17590]
tfpdef [17567,17590]
===
match
---
atom_expr [45252,45312]
atom_expr [45252,45312]
===
match
---
operator: = [45391,45392]
operator: = [45391,45392]
===
match
---
expr_stmt [70974,71014]
expr_stmt [71398,71438]
===
match
---
operator: + [59304,59305]
operator: + [59728,59729]
===
match
---
simple_stmt [26344,26390]
simple_stmt [26344,26390]
===
match
---
operator: , [32548,32549]
operator: , [32548,32549]
===
match
---
param [25825,25836]
param [25825,25836]
===
match
---
simple_stmt [23975,24009]
simple_stmt [23975,24009]
===
match
---
simple_stmt [4231,4248]
simple_stmt [4231,4248]
===
match
---
operator: , [71147,71148]
operator: , [71571,71572]
===
match
---
funcdef [62257,62309]
funcdef [62681,62733]
===
match
---
fstring_start: f" [48521,48523]
fstring_start: f" [48521,48523]
===
match
---
name: log [55593,55596]
name: log [56017,56020]
===
match
---
trailer [80541,80553]
trailer [80965,80977]
===
match
---
name: airflow [3147,3154]
name: airflow [3147,3154]
===
match
---
atom_expr [39167,39176]
atom_expr [39167,39176]
===
match
---
name: values_ordered_by_id [76347,76367]
name: values_ordered_by_id [76771,76791]
===
match
---
name: airflow [2930,2937]
name: airflow [2930,2937]
===
match
---
name: dag_id [58861,58867]
name: dag_id [59285,59291]
===
match
---
import_from [1275,1372]
import_from [1275,1372]
===
match
---
name: max_tries [23628,23637]
name: max_tries [23628,23637]
===
match
---
name: command_as_list [68012,68027]
name: command_as_list [68436,68451]
===
match
---
simple_stmt [25496,25513]
simple_stmt [25496,25513]
===
match
---
atom_expr [40980,40995]
atom_expr [40980,40995]
===
match
---
parameters [76574,76589]
parameters [76998,77013]
===
match
---
atom_expr [80033,80041]
atom_expr [80457,80465]
===
match
---
name: path [16444,16448]
name: path [16444,16448]
===
match
---
annassign [3304,3324]
annassign [3304,3324]
===
match
---
name: utils [2539,2544]
name: utils [2539,2544]
===
match
---
name: local [16839,16844]
name: local [16839,16844]
===
match
---
name: func [1355,1359]
name: func [1355,1359]
===
match
---
atom_expr [6016,6028]
atom_expr [6016,6028]
===
match
---
expr_stmt [45037,45074]
expr_stmt [45037,45074]
===
match
---
name: task_copy [54150,54159]
name: task_copy [54574,54583]
===
match
---
trailer [34305,34333]
trailer [34305,34333]
===
match
---
operator: , [53316,53317]
operator: , [53740,53741]
===
match
---
param [63214,63224]
param [63638,63648]
===
match
---
name: self [30315,30319]
name: self [30315,30319]
===
match
---
name: dag [3403,3406]
name: dag [3403,3406]
===
match
---
atom_expr [24189,24212]
atom_expr [24189,24212]
===
match
---
operator: , [15510,15511]
operator: , [15510,15511]
===
match
---
name: _try_number [15116,15127]
name: _try_number [15116,15127]
===
match
---
atom_expr [24846,24862]
atom_expr [24846,24862]
===
match
---
operator: = [39330,39331]
operator: = [39330,39331]
===
match
---
trailer [50137,50143]
trailer [50137,50143]
===
match
---
operator: = [39422,39423]
operator: = [39422,39423]
===
match
---
name: REQUEUEABLE_DEPS [39944,39960]
name: REQUEUEABLE_DEPS [39944,39960]
===
match
---
trailer [33962,33999]
trailer [33962,33999]
===
match
---
expr_stmt [34159,34200]
expr_stmt [34159,34200]
===
match
---
operator: , [27718,27719]
operator: , [27718,27719]
===
match
---
operator: = [12291,12292]
operator: = [12291,12292]
===
match
---
simple_stmt [24077,24095]
simple_stmt [24077,24095]
===
match
---
trailer [49883,49899]
trailer [49883,49899]
===
match
---
name: t [78261,78262]
name: t [78685,78686]
===
match
---
trailer [9682,9693]
trailer [9682,9693]
===
match
---
name: logging [827,834]
name: logging [827,834]
===
match
---
number: 1000 [11446,11450]
number: 1000 [11446,11450]
===
match
---
trailer [4785,4792]
trailer [4785,4792]
===
match
---
operator: , [39563,39564]
operator: , [39563,39564]
===
match
---
name: ti_deps [2334,2341]
name: ti_deps [2334,2341]
===
match
---
atom_expr [67823,67863]
atom_expr [68247,68287]
===
match
---
operator: , [966,967]
operator: , [966,967]
===
match
---
name: context [67383,67390]
name: context [67807,67814]
===
match
---
suite [21793,21826]
suite [21793,21826]
===
match
---
simple_stmt [20149,20178]
simple_stmt [20149,20178]
===
match
---
name: self [57405,57409]
name: self [57829,57833]
===
match
---
name: use_default [68707,68718]
name: use_default [69131,69142]
===
match
---
atom_expr [79640,79661]
atom_expr [80064,80085]
===
match
---
operator: = [76998,76999]
operator: = [77422,77423]
===
match
---
argument [48127,48134]
argument [48127,48134]
===
match
---
parameters [47330,47351]
parameters [47330,47351]
===
match
---
name: Union [77154,77159]
name: Union [77578,77583]
===
match
---
expr_stmt [62293,62308]
expr_stmt [62717,62732]
===
match
---
import_as_names [2172,2193]
import_as_names [2172,2193]
===
match
---
name: base_url [20814,20822]
name: base_url [20814,20822]
===
match
---
simple_stmt [47188,47223]
simple_stmt [47188,47223]
===
match
---
name: str [12401,12404]
name: str [12401,12404]
===
match
---
simple_stmt [65361,65406]
simple_stmt [65785,65830]
===
match
---
param [81077,81082]
param [81501,81506]
===
match
---
name: start_date [23256,23266]
name: start_date [23256,23266]
===
match
---
param [43270,43288]
param [43270,43288]
===
match
---
simple_stmt [2925,2976]
simple_stmt [2925,2976]
===
match
---
suite [80914,80940]
suite [81338,81364]
===
match
---
name: error_file [46344,46354]
name: error_file [46344,46354]
===
match
---
expr_stmt [54982,55003]
expr_stmt [55406,55427]
===
match
---
name: log [49993,49996]
name: log [49993,49996]
===
match
---
trailer [36350,36352]
trailer [36350,36352]
===
match
---
param [62638,62648]
param [63062,63072]
===
match
---
string: "tasks" [19503,19510]
string: "tasks" [19503,19510]
===
match
---
trailer [20045,20052]
trailer [20045,20052]
===
match
---
trailer [35426,35437]
trailer [35426,35437]
===
match
---
operator: = [54275,54276]
operator: = [54699,54700]
===
match
---
decorator [15133,15143]
decorator [15133,15143]
===
match
---
name: prev_ds_nodash [60416,60430]
name: prev_ds_nodash [60840,60854]
===
match
---
suite [42829,43055]
suite [42829,43055]
===
match
---
name: self [80253,80257]
name: self [80677,80681]
===
match
---
name: Session [31522,31529]
name: Session [31522,31529]
===
match
---
atom_expr [34551,34568]
atom_expr [34551,34568]
===
match
---
funcdef [63347,63673]
funcdef [63771,64097]
===
match
---
simple_stmt [7958,7987]
simple_stmt [7958,7987]
===
match
---
name: Stats [46947,46952]
name: Stats [46947,46952]
===
match
---
atom_expr [43299,43711]
atom_expr [43299,43711]
===
match
---
comparison [51991,52018]
comparison [52133,52160]
===
match
---
name: dag_id [76787,76793]
name: dag_id [77211,77217]
===
match
---
operator: , [25835,25836]
operator: , [25835,25836]
===
match
---
param [9471,9475]
param [9471,9475]
===
match
---
name: State [57006,57011]
name: State [57430,57435]
===
match
---
string: "exception" [52411,52422]
string: "exception" [52695,52706]
===
match
---
trailer [42303,42369]
trailer [42303,42369]
===
match
---
operator: , [36517,36518]
operator: , [36517,36518]
===
match
---
name: mark_success [16617,16629]
name: mark_success [16617,16629]
===
match
---
name: ignore_all_deps [16659,16674]
name: ignore_all_deps [16659,16674]
===
match
---
trailer [12753,12769]
trailer [12753,12769]
===
match
---
name: self [42378,42382]
name: self [42378,42382]
===
match
---
name: raw [15501,15504]
name: raw [15501,15504]
===
match
---
operator: , [39212,39213]
operator: , [39212,39213]
===
match
---
atom_expr [39489,39499]
atom_expr [39489,39499]
===
match
---
sync_comp_for [76171,76230]
sync_comp_for [76595,76654]
===
match
---
name: session [55041,55048]
name: session [55465,55472]
===
match
---
number: 1 [42367,42368]
number: 1 [42367,42368]
===
match
---
return_stmt [66893,66917]
return_stmt [67317,67341]
===
match
---
trailer [25429,25444]
trailer [25429,25444]
===
match
---
simple_stmt [61598,61614]
simple_stmt [62022,62038]
===
match
---
name: self [46247,46251]
name: self [46247,46251]
===
match
---
name: task_id [78141,78148]
name: task_id [78565,78572]
===
match
---
suite [46642,46666]
suite [46642,46666]
===
match
---
trailer [55026,55032]
trailer [55450,55456]
===
match
---
operator: , [12072,12073]
operator: , [12072,12073]
===
match
---
operator: , [53256,53257]
operator: , [53680,53681]
===
match
---
simple_stmt [22122,22178]
simple_stmt [22122,22178]
===
match
---
atom_expr [59204,59223]
atom_expr [59628,59647]
===
match
---
name: get_templated_fields [65553,65573]
name: get_templated_fields [65977,65997]
===
match
---
operator: @ [80945,80946]
operator: @ [81369,81370]
===
match
---
atom_expr [57640,57661]
atom_expr [58064,58085]
===
match
---
name: dag_run [58784,58791]
name: dag_run [59208,59215]
===
match
---
atom_expr [34220,34236]
atom_expr [34220,34236]
===
match
---
name: Column [11251,11257]
name: Column [11251,11257]
===
match
---
if_stmt [20128,20178]
if_stmt [20128,20178]
===
match
---
atom_expr [31373,31414]
atom_expr [31373,31414]
===
match
---
name: warn [29995,29999]
name: warn [29995,29999]
===
match
---
name: render_templates [48021,48037]
name: render_templates [48021,48037]
===
match
---
simple_stmt [50051,50078]
simple_stmt [50051,50078]
===
match
---
simple_stmt [50130,50150]
simple_stmt [50130,50150]
===
match
---
operator: = [10778,10779]
operator: = [10778,10779]
===
match
---
atom_expr [39277,39336]
atom_expr [39277,39336]
===
match
---
atom_expr [16294,16314]
atom_expr [16294,16314]
===
match
---
simple_stmt [25521,25557]
simple_stmt [25521,25557]
===
match
---
operator: @ [61697,61698]
operator: @ [62121,62122]
===
match
---
trailer [72261,72270]
trailer [72685,72694]
===
match
---
name: self [50333,50337]
name: self [50333,50337]
===
match
---
decorated [81028,81867]
decorated [81452,82291]
===
match
---
trailer [42783,42791]
trailer [42783,42791]
===
match
---
atom_expr [46282,46355]
atom_expr [46282,46355]
===
match
---
arglist [46302,46354]
arglist [46302,46354]
===
match
---
simple_stmt [28917,29050]
simple_stmt [28917,29050]
===
match
---
name: self [48016,48020]
name: self [48016,48020]
===
match
---
simple_stmt [19643,19684]
simple_stmt [19643,19684]
===
match
---
simple_stmt [9323,9378]
simple_stmt [9323,9378]
===
match
---
operator: = [32719,32720]
operator: = [32719,32720]
===
match
---
trailer [76489,76507]
trailer [76913,76931]
===
match
---
name: List [1077,1081]
name: List [1077,1081]
===
match
---
argument [48716,48731]
argument [48716,48731]
===
match
---
simple_stmt [22186,22212]
simple_stmt [22186,22212]
===
match
---
trailer [52176,52196]
trailer [52343,52363]
===
match
---
atom_expr [7464,7482]
atom_expr [7464,7482]
===
match
---
name: dag_id [60851,60857]
name: dag_id [61275,61281]
===
match
---
operator: , [61088,61089]
operator: , [61512,61513]
===
match
---
fstring_expr [60860,60874]
fstring_expr [61284,61298]
===
match
---
operator: , [8240,8241]
operator: , [8240,8241]
===
match
---
param [15282,15287]
param [15282,15287]
===
match
---
trailer [55216,55232]
trailer [55640,55656]
===
match
---
import_from [3028,3078]
import_from [3028,3078]
===
match
---
operator: , [37547,37548]
operator: , [37547,37548]
===
match
---
number: 1 [9675,9676]
number: 1 [9675,9676]
===
match
---
name: getuser [13331,13338]
name: getuser [13331,13338]
===
match
---
trailer [53919,53932]
trailer [54343,54356]
===
match
---
operator: = [79667,79668]
operator: = [80091,80092]
===
match
---
arglist [20545,20568]
arglist [20545,20568]
===
match
---
name: outlets [64133,64140]
name: outlets [64557,64564]
===
match
---
trailer [47692,47700]
trailer [47692,47700]
===
match
---
trailer [81896,81898]
trailer [82320,82322]
===
match
---
operator: = [70201,70202]
operator: = [70625,70626]
===
match
---
operator: , [19510,19511]
operator: , [19510,19511]
===
match
---
trailer [51723,51729]
trailer [51723,51729]
===
match
---
name: Column [10878,10884]
name: Column [10878,10884]
===
match
---
simple_stmt [12520,12537]
simple_stmt [12520,12537]
===
match
---
classdef [9080,10086]
classdef [9080,10086]
===
match
---
trailer [10739,10765]
trailer [10739,10765]
===
match
---
param [32128,32132]
param [32128,32132]
===
match
---
atom_expr [12484,12496]
atom_expr [12484,12496]
===
match
---
param [67242,67247]
param [67666,67671]
===
match
---
return_stmt [80280,80307]
return_stmt [80704,80731]
===
match
---
name: ignore_ti_state [37557,37572]
name: ignore_ti_state [37557,37572]
===
match
---
except_clause [46020,46076]
except_clause [46020,46076]
===
match
---
name: execution_date [72373,72387]
name: execution_date [72797,72811]
===
match
---
name: ti [5452,5454]
name: ti [5452,5454]
===
match
---
atom_expr [71230,71238]
atom_expr [71654,71662]
===
match
---
trailer [36446,36462]
trailer [36446,36462]
===
match
---
simple_stmt [55683,55711]
simple_stmt [56107,56135]
===
match
---
name: set [73382,73385]
name: set [73806,73809]
===
match
---
trailer [78980,78988]
trailer [79404,79412]
===
match
---
argument [73479,73497]
argument [73903,73921]
===
match
---
funcdef [25805,26496]
funcdef [25805,26496]
===
match
---
name: session [47188,47195]
name: session [47188,47195]
===
match
---
number: 1 [11328,11329]
number: 1 [11328,11329]
===
match
---
number: 1 [55002,55003]
number: 1 [55426,55427]
===
match
---
name: next_execution_date [64084,64103]
name: next_execution_date [64508,64527]
===
match
---
atom_expr [55066,55135]
atom_expr [55490,55559]
===
match
---
name: self [24699,24703]
name: self [24699,24703]
===
match
---
operator: , [15314,15315]
operator: , [15314,15315]
===
match
---
string: "--mark-success" [19590,19606]
string: "--mark-success" [19590,19606]
===
match
---
name: total_seconds [50645,50658]
name: total_seconds [50645,50658]
===
match
---
simple_stmt [76599,76646]
simple_stmt [77023,77070]
===
match
---
suite [58645,58693]
suite [59069,59117]
===
match
---
decorator [30277,30287]
decorator [30277,30287]
===
match
---
name: models [82037,82043]
name: models [82461,82467]
===
match
---
operator: @ [57556,57557]
operator: @ [57980,57981]
===
match
---
name: task [46985,46989]
name: task [46985,46989]
===
match
---
operator: , [63744,63745]
operator: , [64168,64169]
===
match
---
name: default_html_content [70462,70482]
name: default_html_content [70886,70906]
===
match
---
fstring_start: f" [20998,21000]
fstring_start: f" [20998,21000]
===
match
---
name: datetime [17137,17145]
name: datetime [17137,17145]
===
match
---
atom_expr [76723,76735]
atom_expr [77147,77159]
===
match
---
param [21922,21927]
param [21922,21927]
===
match
---
trailer [44804,44830]
trailer [44804,44830]
===
match
---
expr_stmt [58405,58421]
expr_stmt [58829,58845]
===
match
---
name: activate_dag_runs [7995,8012]
name: activate_dag_runs [7995,8012]
===
match
---
name: self [22918,22922]
name: self [22918,22922]
===
match
---
parameters [43263,43289]
parameters [43263,43289]
===
match
---
expr_stmt [23975,24008]
expr_stmt [23975,24008]
===
match
---
trailer [21605,21612]
trailer [21605,21612]
===
match
---
trailer [57548,57550]
trailer [57972,57974]
===
match
---
name: merge [47243,47248]
name: merge [47243,47248]
===
match
---
operator: = [13704,13705]
operator: = [13704,13705]
===
match
---
name: with_try_number [9709,9724]
name: with_try_number [9709,9724]
===
match
---
name: int [35377,35380]
name: int [35377,35380]
===
match
---
atom_expr [27553,27603]
atom_expr [27553,27603]
===
match
---
simple_stmt [58705,58771]
simple_stmt [59129,59195]
===
match
---
name: execution_date [42937,42951]
name: execution_date [42937,42951]
===
match
---
suite [66371,66918]
suite [66795,67342]
===
match
---
name: XCom [76205,76209]
name: XCom [76629,76633]
===
match
---
trailer [4216,4225]
trailer [4216,4225]
===
match
---
name: self [77051,77055]
name: self [77475,77479]
===
match
---
operator: , [47335,47336]
operator: , [47335,47336]
===
match
---
trailer [77159,77192]
trailer [77583,77616]
===
match
---
name: airflow [2621,2628]
name: airflow [2621,2628]
===
match
---
trailer [11477,11490]
trailer [11477,11490]
===
match
---
name: _try_number [14434,14445]
name: _try_number [14434,14445]
===
match
---
operator: , [58604,58605]
operator: , [59028,59029]
===
match
---
string: """         The execution date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [31000,31215]
string: """         The execution date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [31000,31215]
===
match
---
operator: = [76399,76400]
operator: = [76823,76824]
===
match
---
name: html_content_err [71477,71493]
name: html_content_err [71901,71917]
===
match
---
name: kube_config [68176,68187]
name: kube_config [68600,68611]
===
match
---
operator: , [26161,26162]
operator: , [26161,26162]
===
match
---
name: default_var [61953,61964]
name: default_var [62377,62388]
===
match
---
simple_stmt [32764,33397]
simple_stmt [32764,33397]
===
match
---
trailer [50644,50658]
trailer [50644,50658]
===
match
---
simple_stmt [901,937]
simple_stmt [901,937]
===
match
---
param [63372,63382]
param [63796,63806]
===
match
---
operator: , [54644,54645]
operator: , [55068,55069]
===
match
---
name: str [43969,43972]
name: str [43969,43972]
===
match
---
parameters [26848,26868]
parameters [26848,26868]
===
match
---
operator: = [12204,12205]
operator: = [12204,12205]
===
match
---
name: state [21852,21857]
name: state [21852,21857]
===
match
---
fstring_string: dag. [47948,47952]
fstring_string: dag. [47948,47952]
===
match
---
atom_expr [9650,9669]
atom_expr [9650,9669]
===
match
---
trailer [24191,24212]
trailer [24191,24212]
===
match
---
import_as_names [1236,1274]
import_as_names [1236,1274]
===
match
---
operator: = [67756,67757]
operator: = [68180,68181]
===
match
---
simple_stmt [67534,67560]
simple_stmt [67958,67984]
===
match
---
operator: , [31902,31903]
operator: , [31902,31903]
===
match
---
name: renderedtifields [47422,47438]
name: renderedtifields [47422,47438]
===
match
---
name: self [63884,63888]
name: self [64308,64312]
===
match
---
expr_stmt [79558,79595]
expr_stmt [79982,80019]
===
match
---
operator: = [49332,49333]
operator: = [49332,49333]
===
match
---
atom_expr [46985,46997]
atom_expr [46985,46997]
===
match
---
simple_stmt [7110,7699]
simple_stmt [7110,7699]
===
match
---
suite [58613,59080]
suite [59037,59504]
===
match
---
string: 'yesterday_ds_nodash' [65254,65275]
string: 'yesterday_ds_nodash' [65678,65699]
===
match
---
trailer [49813,49864]
trailer [49813,49864]
===
match
---
decorator [20392,20402]
decorator [20392,20402]
===
match
---
trailer [70737,70946]
trailer [71161,71370]
===
match
---
fstring_start: f' [46958,46960]
fstring_start: f' [46958,46960]
===
match
---
atom_expr [34285,34333]
atom_expr [34285,34333]
===
match
---
name: int [9240,9243]
name: int [9240,9243]
===
match
---
name: ignore_ti_state [40027,40042]
name: ignore_ti_state [40027,40042]
===
match
---
atom_expr [7382,7406]
atom_expr [7382,7406]
===
match
---
import_from [82024,82064]
import_from [82448,82488]
===
match
---
trailer [44918,44927]
trailer [44918,44927]
===
match
---
name: dr [28384,28386]
name: dr [28384,28386]
===
match
---
name: self [30769,30773]
name: self [30769,30773]
===
match
---
name: _CURRENT_CONTEXT [3288,3304]
name: _CURRENT_CONTEXT [3288,3304]
===
match
---
argument [48038,48053]
argument [48038,48053]
===
match
---
trailer [60172,60181]
trailer [60596,60605]
===
match
---
simple_stmt [22841,23055]
simple_stmt [22841,23055]
===
match
---
atom_expr [23860,23868]
atom_expr [23860,23868]
===
match
---
operator: @ [13717,13718]
operator: @ [13717,13718]
===
match
---
comparison [46598,46641]
comparison [46598,46641]
===
match
---
string: "&state=success" [21097,21113]
string: "&state=success" [21097,21113]
===
match
---
if_stmt [50539,50894]
if_stmt [50539,50894]
===
match
---
name: task_copy [50348,50357]
name: task_copy [50348,50357]
===
match
---
operator: , [12126,12127]
operator: , [12126,12127]
===
match
---
name: Column [11471,11477]
name: Column [11471,11477]
===
match
---
atom_expr [10798,10856]
atom_expr [10798,10856]
===
match
---
trailer [60969,60980]
trailer [61393,61404]
===
match
---
arglist [62850,62902]
arglist [63274,63326]
===
match
---
atom_expr [59094,59134]
atom_expr [59518,59558]
===
match
---
trailer [41687,41691]
trailer [41687,41691]
===
match
---
simple_stmt [871,885]
simple_stmt [871,885]
===
match
---
trailer [5813,5821]
trailer [5813,5821]
===
match
---
operator: = [8598,8599]
operator: = [8598,8599]
===
match
---
name: execution_date [59209,59223]
name: execution_date [59633,59647]
===
match
---
string: "--subdir" [20274,20284]
string: "--subdir" [20274,20284]
===
match
---
trailer [45072,45074]
trailer [45072,45074]
===
match
---
expr_stmt [75559,75579]
expr_stmt [75983,76003]
===
match
---
name: self [24107,24111]
name: self [24107,24111]
===
match
---
name: end_date [47067,47075]
name: end_date [47067,47075]
===
match
---
string: "&upstream=false" [21035,21052]
string: "&upstream=false" [21035,21052]
===
match
---
trailer [21553,21560]
trailer [21553,21560]
===
match
---
name: ti_deps [2385,2392]
name: ti_deps [2385,2392]
===
match
---
name: self [62419,62423]
name: self [62843,62847]
===
match
---
atom_expr [78313,78332]
atom_expr [78737,78756]
===
match
---
trailer [56257,56261]
trailer [56681,56685]
===
match
---
arglist [49814,49863]
arglist [49814,49863]
===
match
---
trailer [79464,79476]
trailer [79888,79900]
===
match
---
string: "DagModel" [12173,12183]
string: "DagModel" [12173,12183]
===
match
---
trailer [22874,22881]
trailer [22874,22881]
===
match
---
name: jinja_env [70350,70359]
name: jinja_env [70774,70783]
===
match
---
name: get [61727,61730]
name: get [62151,62154]
===
match
---
operator: = [75675,75676]
operator: = [76099,76100]
===
match
---
name: ignore_ti_state [16810,16825]
name: ignore_ti_state [16810,16825]
===
match
---
operator: = [59928,59929]
operator: = [60352,60353]
===
match
---
name: data [4231,4235]
name: data [4231,4235]
===
match
---
comparison [7162,7181]
comparison [7162,7181]
===
match
---
name: Iterable [77145,77153]
name: Iterable [77569,77577]
===
match
---
name: DateTime [31564,31572]
name: DateTime [31564,31572]
===
match
---
simple_stmt [48964,48983]
simple_stmt [48964,48983]
===
match
---
atom_expr [50692,50726]
atom_expr [50692,50726]
===
match
---
expr_stmt [76080,76244]
expr_stmt [76504,76668]
===
match
---
decorated [58287,65308]
decorated [58711,65732]
===
match
---
atom_expr [19739,19750]
atom_expr [19739,19750]
===
match
---
name: ti [23994,23996]
name: ti [23994,23996]
===
match
---
name: dag_id [46976,46982]
name: dag_id [46976,46982]
===
match
---
name: task_id [9886,9893]
name: task_id [9886,9893]
===
match
---
trailer [26227,26238]
trailer [26227,26238]
===
match
---
atom_expr [62564,62572]
atom_expr [62988,62996]
===
match
---
operator: , [27914,27915]
operator: , [27914,27915]
===
match
---
trailer [44991,44997]
trailer [44991,44997]
===
match
---
name: isoformat [19465,19474]
name: isoformat [19465,19474]
===
match
---
expr_stmt [59758,59799]
expr_stmt [60182,60223]
===
match
---
trailer [17545,17550]
trailer [17545,17550]
===
match
---
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [69062,69111]
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [69486,69535]
===
match
---
name: settings [42768,42776]
name: settings [42768,42776]
===
match
---
name: test_mode [55481,55490]
name: test_mode [55905,55914]
===
match
---
name: self [34306,34310]
name: self [34306,34310]
===
match
---
atom_expr [76902,76915]
atom_expr [77326,77339]
===
match
---
import_as_names [1880,1908]
import_as_names [1880,1908]
===
match
---
comparison [8703,8726]
comparison [8703,8726]
===
match
---
name: session [33634,33641]
name: session [33634,33641]
===
match
---
parameters [66350,66370]
parameters [66774,66794]
===
match
---
suite [47352,49900]
suite [47352,49900]
===
match
---
operator: = [44727,44728]
operator: = [44727,44728]
===
match
---
simple_stmt [10074,10086]
simple_stmt [10074,10086]
===
match
---
name: dep [34213,34216]
name: dep [34213,34216]
===
match
---
arglist [56271,56328]
arglist [56695,56752]
===
match
---
name: PodGenerator [3187,3199]
name: PodGenerator [3187,3199]
===
match
---
atom_expr [9636,9648]
atom_expr [9636,9648]
===
match
---
name: session [41603,41610]
name: session [41603,41610]
===
match
---
atom_expr [53500,53746]
atom_expr [53924,54170]
===
match
---
return_stmt [9845,9927]
return_stmt [9845,9927]
===
match
---
name: defaultdict [5385,5396]
name: defaultdict [5385,5396]
===
match
---
comparison [50999,51017]
comparison [50999,51017]
===
match
---
atom_expr [11646,11678]
atom_expr [11646,11678]
===
match
---
name: hostname [39379,39387]
name: hostname [39379,39387]
===
match
---
atom_expr [52064,52088]
atom_expr [52206,52230]
===
match
---
name: ti [24130,24132]
name: ti [24130,24132]
===
match
---
name: TaskInstance [21630,21642]
name: TaskInstance [21630,21642]
===
match
---
operator: = [40315,40316]
operator: = [40315,40316]
===
match
---
name: file_path [20239,20248]
name: file_path [20239,20248]
===
match
---
operator: , [40121,40122]
operator: , [40121,40122]
===
match
---
trailer [24869,24881]
trailer [24869,24881]
===
match
---
operator: { [46984,46985]
operator: { [46984,46985]
===
match
---
name: from_string [70450,70461]
name: from_string [70874,70885]
===
match
---
name: self [34239,34243]
name: self [34239,34243]
===
match
---
name: task_copy [47482,47491]
name: task_copy [47482,47491]
===
match
---
simple_stmt [58566,58581]
simple_stmt [58990,59005]
===
match
---
operator: = [57047,57048]
operator: = [57471,57472]
===
match
---
arglist [71347,71382]
arglist [71771,71806]
===
match
---
name: end_date [26349,26357]
name: end_date [26349,26357]
===
match
---
atom_expr [54419,54436]
atom_expr [54843,54860]
===
match
---
atom_expr [28862,28900]
atom_expr [28862,28900]
===
match
---
operator: = [31505,31506]
operator: = [31505,31506]
===
match
---
name: task [27800,27804]
name: task [27800,27804]
===
match
---
name: commit [55049,55055]
name: commit [55473,55479]
===
match
---
name: dag_id [78326,78332]
name: dag_id [78750,78756]
===
match
---
name: RUNNING_DEPS [2436,2448]
name: RUNNING_DEPS [2436,2448]
===
match
---
atom [39674,39684]
atom [39674,39684]
===
match
---
name: Union [15794,15799]
name: Union [15794,15799]
===
match
---
trailer [43504,43506]
trailer [43504,43506]
===
match
---
trailer [37219,37234]
trailer [37219,37234]
===
match
---
trailer [50055,50061]
trailer [50055,50061]
===
match
---
operator: = [79432,79433]
operator: = [79856,79857]
===
match
---
trailer [24984,24993]
trailer [24984,24993]
===
match
---
number: 1 [41993,41994]
number: 1 [41993,41994]
===
match
---
trailer [78596,78795]
trailer [79020,79219]
===
match
---
operator: , [17557,17558]
operator: , [17557,17558]
===
match
---
name: provide_session [34026,34041]
name: provide_session [34026,34041]
===
match
---
operator: , [78176,78177]
operator: , [78600,78601]
===
match
---
name: self [80770,80774]
name: self [81194,81198]
===
match
---
atom_expr [4089,4110]
atom_expr [4089,4110]
===
match
---
trailer [73381,73385]
trailer [73805,73809]
===
match
---
name: dag_id [37190,37196]
name: dag_id [37190,37196]
===
match
---
exprlist [7649,7662]
exprlist [7649,7662]
===
match
---
name: error [51476,51481]
name: error [51476,51481]
===
match
---
funcdef [13916,14482]
funcdef [13916,14482]
===
match
---
name: _Variable__NO_DEFAULT_SENTINEL [62693,62723]
name: _Variable__NO_DEFAULT_SENTINEL [63117,63147]
===
match
---
trailer [43307,43312]
trailer [43307,43312]
===
match
---
tfpdef [57633,57661]
tfpdef [58057,58085]
===
match
---
name: expected_state [4010,4024]
name: expected_state [4010,4024]
===
match
---
atom_expr [21513,21768]
atom_expr [21513,21768]
===
match
---
name: try_number [67877,67887]
name: try_number [68301,68311]
===
match
---
name: try_number [58253,58263]
name: try_number [58677,58687]
===
match
---
operator: , [56201,56202]
operator: , [56625,56626]
===
match
---
simple_stmt [19578,19609]
simple_stmt [19578,19609]
===
match
---
operator: , [81095,81096]
operator: , [81519,81520]
===
match
---
suite [72005,72272]
suite [72429,72696]
===
match
---
string: '' [43241,43243]
string: '' [43241,43243]
===
match
---
name: Column [11029,11035]
name: Column [11029,11035]
===
match
---
operator: = [30740,30741]
operator: = [30740,30741]
===
match
---
arglist [35615,35678]
arglist [35615,35678]
===
match
---
simple_stmt [23563,23596]
simple_stmt [23563,23596]
===
match
---
name: ignore_all_deps [39994,40009]
name: ignore_all_deps [39994,40009]
===
match
---
name: self [26157,26161]
name: self [26157,26161]
===
match
---
trailer [77928,77943]
trailer [78352,78367]
===
match
---
name: self [44839,44843]
name: self [44839,44843]
===
match
---
comparison [78505,78550]
comparison [78929,78974]
===
match
---
name: SUCCESS [32642,32649]
name: SUCCESS [32642,32649]
===
match
---
arglist [46720,46755]
arglist [46720,46755]
===
match
---
operator: = [12406,12407]
operator: = [12406,12407]
===
match
---
operator: , [21926,21927]
operator: , [21926,21927]
===
match
---
argument [11271,11285]
argument [11271,11285]
===
match
---
if_stmt [42446,42514]
if_stmt [42446,42514]
===
match
---
string: """Initialize the attributes that aren't stored in the DB""" [13768,13828]
string: """Initialize the attributes that aren't stored in the DB""" [13768,13828]
===
match
---
name: getLogger [3339,3348]
name: getLogger [3339,3348]
===
match
---
trailer [80463,80473]
trailer [80887,80897]
===
match
---
operator: = [62867,62868]
operator: = [63291,63292]
===
match
---
name: task [24764,24768]
name: task [24764,24768]
===
match
---
trailer [23694,23703]
trailer [23694,23703]
===
match
---
trailer [59328,59340]
trailer [59752,59764]
===
match
---
operator: , [42505,42506]
operator: , [42505,42506]
===
match
---
simple_stmt [67704,68314]
simple_stmt [68128,68738]
===
match
---
name: Stats [2315,2320]
name: Stats [2315,2320]
===
match
---
argument [11096,11105]
argument [11096,11105]
===
match
---
string: "when Dag Serialization is enabled. Hence for the task that have not yet " [66055,66129]
string: "when Dag Serialization is enabled. Hence for the task that have not yet " [66479,66553]
===
match
---
suite [16270,16315]
suite [16270,16315]
===
match
---
argument [53674,53698]
argument [54098,54122]
===
match
---
name: ti [79296,79298]
name: ti [79720,79722]
===
match
---
atom_expr [16571,16590]
atom_expr [16571,16590]
===
match
---
name: TR [7162,7164]
name: TR [7162,7164]
===
match
---
comparison [29383,29412]
comparison [29383,29412]
===
match
---
atom_expr [42921,42930]
atom_expr [42921,42930]
===
match
---
if_stmt [16143,16461]
if_stmt [16143,16461]
===
match
---
name: pool [23771,23775]
name: pool [23771,23775]
===
match
---
atom_expr [51263,51287]
atom_expr [51263,51287]
===
match
---
name: e [66883,66884]
name: e [67307,67308]
===
match
---
name: self [40207,40211]
name: self [40207,40211]
===
match
---
trailer [56184,56209]
trailer [56608,56633]
===
match
---
name: self [24890,24894]
name: self [24890,24894]
===
match
---
name: session [73577,73584]
name: session [74001,74008]
===
match
---
trailer [81546,81553]
trailer [81970,81977]
===
match
---
if_stmt [55876,55941]
if_stmt [56300,56365]
===
match
---
trailer [58633,58637]
trailer [59057,59061]
===
match
---
name: self [49988,49992]
name: self [49988,49992]
===
match
---
name: datetime [958,966]
name: datetime [958,966]
===
match
---
trailer [45297,45312]
trailer [45297,45312]
===
match
---
name: actual_start_date [45941,45958]
name: actual_start_date [45941,45958]
===
match
---
atom_expr [63736,63744]
atom_expr [64160,64168]
===
match
---
name: self [23690,23694]
name: self [23690,23694]
===
match
---
trailer [4957,4964]
trailer [4957,4964]
===
match
---
name: XCOM_RETURN_KEY [51050,51065]
name: XCOM_RETURN_KEY [51050,51065]
===
match
---
name: sanitized_pod [68362,68375]
name: sanitized_pod [68786,68799]
===
match
---
arglist [60981,61020]
arglist [61405,61444]
===
match
---
parameters [62337,62401]
parameters [62761,62825]
===
match
---
suite [57318,57359]
suite [57742,57783]
===
match
---
operator: { [66872,66873]
operator: { [67296,67297]
===
match
---
operator: , [48818,48819]
operator: , [48818,48819]
===
match
---
atom_expr [26418,26467]
atom_expr [26418,26467]
===
match
---
name: AirflowTaskTimeout [1826,1844]
name: AirflowTaskTimeout [1826,1844]
===
match
---
name: task [48820,48824]
name: task [48820,48824]
===
match
---
name: log [31808,31811]
name: log [31808,31811]
===
match
---
operator: = [3782,3783]
operator: = [3782,3783]
===
match
---
name: refresh_from_task [44787,44804]
name: refresh_from_task [44787,44804]
===
match
---
operator: = [52714,52715]
operator: = [53138,53139]
===
match
---
atom_expr [45668,45674]
atom_expr [45668,45674]
===
match
---
name: include_prior_dates [75752,75771]
name: include_prior_dates [76176,76195]
===
match
---
name: queued_dttm [23980,23991]
name: queued_dttm [23980,23991]
===
match
---
trailer [64595,64603]
trailer [65019,65027]
===
match
---
name: cfg_path [17005,17013]
name: cfg_path [17005,17013]
===
match
---
operator: , [64917,64918]
operator: , [65341,65342]
===
match
---
name: Float [11010,11015]
name: Float [11010,11015]
===
match
---
name: set_duration [71978,71990]
name: set_duration [72402,72414]
===
match
---
operator: -> [9961,9963]
operator: -> [9961,9963]
===
match
---
name: inlets [63933,63939]
name: inlets [64357,64363]
===
match
---
atom_expr [39185,39233]
atom_expr [39185,39233]
===
match
---
operator: = [13412,13413]
operator: = [13412,13413]
===
match
---
return_stmt [77551,77562]
return_stmt [77975,77986]
===
match
---
name: str [19739,19742]
name: str [19739,19742]
===
match
---
operator: , [70296,70297]
operator: , [70720,70721]
===
match
---
number: 0 [11104,11105]
number: 0 [11104,11105]
===
match
---
name: task_id [47982,47989]
name: task_id [47982,47989]
===
match
---
simple_stmt [29587,29654]
simple_stmt [29587,29654]
===
match
---
name: cfg_path [15560,15568]
name: cfg_path [15560,15568]
===
match
---
name: max_retry_delay [36502,36517]
name: max_retry_delay [36502,36517]
===
match
---
name: self [20655,20659]
name: self [20655,20659]
===
match
---
name: self [21922,21926]
name: self [21922,21926]
===
match
---
name: TaskInstance [78128,78140]
name: TaskInstance [78552,78564]
===
match
---
name: self [42253,42257]
name: self [42253,42257]
===
match
---
atom_expr [77051,77059]
atom_expr [77475,77483]
===
match
---
atom_expr [22847,23054]
atom_expr [22847,23054]
===
match
---
operator: = [53622,53623]
operator: = [54046,54047]
===
match
---
string: 'dag' [58606,58611]
string: 'dag' [59030,59035]
===
match
---
trailer [54159,54167]
trailer [54583,54591]
===
match
---
expr_stmt [39242,39268]
expr_stmt [39242,39268]
===
match
---
atom_expr [53456,53487]
atom_expr [53880,53911]
===
match
---
name: file_path [20286,20295]
name: file_path [20286,20295]
===
match
---
param [76581,76588]
param [77005,77012]
===
match
---
operator: , [76993,76994]
operator: , [77417,77418]
===
match
---
param [43841,43865]
param [43841,43865]
===
match
---
atom [76695,76962]
atom [77119,77386]
===
match
---
name: self [33796,33800]
name: self [33796,33800]
===
match
---
suite [68503,71610]
suite [68927,72034]
===
match
---
simple_stmt [6456,6478]
simple_stmt [6456,6478]
===
match
---
operator: < [73138,73139]
operator: < [73562,73563]
===
match
---
sync_comp_for [7552,7599]
sync_comp_for [7552,7599]
===
match
---
operator: = [77060,77061]
operator: = [77484,77485]
===
match
---
arglist [31891,31919]
arglist [31891,31919]
===
match
---
simple_stmt [27411,27423]
simple_stmt [27411,27423]
===
match
---
trailer [30269,30271]
trailer [30269,30271]
===
match
---
atom_expr [40738,40753]
atom_expr [40738,40753]
===
match
---
trailer [56977,56979]
trailer [57401,57403]
===
match
---
name: prev_ti [31860,31867]
name: prev_ti [31860,31867]
===
match
---
expr_stmt [79696,79735]
expr_stmt [80120,80159]
===
match
---
name: mark_success [15296,15308]
name: mark_success [15296,15308]
===
match
---
name: pendulum [31373,31381]
name: pendulum [31373,31381]
===
match
---
operator: , [22929,22930]
operator: , [22929,22930]
===
match
---
name: session [25837,25844]
name: session [25837,25844]
===
match
---
param [54244,54265]
param [54668,54689]
===
match
---
annassign [79661,79687]
annassign [80085,80111]
===
match
---
operator: = [79985,79986]
operator: = [80409,80410]
===
match
---
atom_expr [28963,28972]
atom_expr [28963,28972]
===
match
---
funcdef [71974,72272]
funcdef [72398,72696]
===
match
---
trailer [24025,24042]
trailer [24025,24042]
===
match
---
atom_expr [70246,70296]
atom_expr [70670,70720]
===
match
---
operator: , [52828,52829]
operator: , [53252,53253]
===
match
---
name: cmd [19485,19488]
name: cmd [19485,19488]
===
match
---
trailer [6492,6513]
trailer [6492,6513]
===
match
---
name: TR [3242,3244]
name: TR [3242,3244]
===
match
---
trailer [47535,47540]
trailer [47535,47540]
===
match
---
name: bool [55296,55300]
name: bool [55720,55724]
===
match
---
name: self [62293,62297]
name: self [62717,62721]
===
match
---
fstring_string: Unable to render a k8s spec for this taskinstance:  [66821,66872]
fstring_string: Unable to render a k8s spec for this taskinstance:  [67245,67296]
===
match
---
name: pid [24091,24094]
name: pid [24091,24094]
===
match
---
trailer [28288,28305]
trailer [28288,28305]
===
match
---
operator: = [13303,13304]
operator: = [13303,13304]
===
match
---
name: dag_model [16051,16060]
name: dag_model [16051,16060]
===
match
---
name: get [20830,20833]
name: get [20830,20833]
===
match
---
name: state [31484,31489]
name: state [31484,31489]
===
match
---
atom_expr [42253,42281]
atom_expr [42253,42281]
===
match
---
argument [68120,68152]
argument [68544,68576]
===
match
---
name: state [51996,52001]
name: state [52138,52143]
===
match
---
operator: , [25725,25726]
operator: , [25725,25726]
===
match
---
argument [16897,16911]
argument [16897,16911]
===
match
---
expr_stmt [60140,60181]
expr_stmt [60564,60605]
===
match
---
operator: = [28296,28297]
operator: = [28296,28297]
===
match
---
atom_expr [9881,9893]
atom_expr [9881,9893]
===
match
---
atom_expr [23951,23962]
atom_expr [23951,23962]
===
match
---
return_stmt [80674,80691]
return_stmt [81098,81115]
===
match
---
operator: = [3245,3246]
operator: = [3245,3246]
===
match
---
expr_stmt [81869,81888]
expr_stmt [82293,82312]
===
match
---
name: dag_id [25719,25725]
name: dag_id [25719,25725]
===
match
---
name: session [25496,25503]
name: session [25496,25503]
===
match
---
operator: == [78461,78463]
operator: == [78885,78887]
===
match
---
trailer [23353,23362]
trailer [23353,23362]
===
match
---
simple_stmt [79696,79736]
simple_stmt [80120,80160]
===
match
---
name: timezone [13192,13200]
name: timezone [13192,13200]
===
match
---
name: Literal [4928,4935]
name: Literal [4928,4935]
===
match
---
param [34686,34690]
param [34686,34690]
===
match
---
trailer [26111,26115]
trailer [26111,26115]
===
match
---
and_test [67050,67074]
and_test [67474,67498]
===
match
---
argument [16996,17013]
argument [16996,17013]
===
match
---
if_stmt [67047,67216]
if_stmt [67471,67640]
===
match
---
operator: = [37125,37126]
operator: = [37125,37126]
===
match
---
annassign [9189,9194]
annassign [9189,9194]
===
match
---
atom_expr [24161,24186]
atom_expr [24161,24186]
===
match
---
name: try_number [9731,9741]
name: try_number [9731,9741]
===
match
---
funcdef [62322,62504]
funcdef [62746,62928]
===
match
---
name: task_id [22972,22979]
name: task_id [22972,22979]
===
match
---
operator: , [37655,37656]
operator: , [37655,37656]
===
match
---
operator: , [10837,10838]
operator: , [10837,10838]
===
match
---
name: self [80172,80176]
name: self [80596,80600]
===
match
---
trailer [21719,21734]
trailer [21719,21734]
===
match
---
name: log [25526,25529]
name: log [25526,25529]
===
match
---
operator: , [1081,1082]
operator: , [1081,1082]
===
match
---
simple_stmt [23096,23131]
simple_stmt [23096,23131]
===
match
---
trailer [80616,80623]
trailer [81040,81047]
===
match
---
sync_comp_for [78409,78421]
sync_comp_for [78833,78845]
===
match
---
trailer [19742,19750]
trailer [19742,19750]
===
match
---
trailer [22233,22239]
trailer [22233,22239]
===
match
---
atom_expr [12520,12529]
atom_expr [12520,12529]
===
match
---
name: lock_for_update [45742,45757]
name: lock_for_update [45742,45757]
===
match
---
operator: , [16883,16884]
operator: , [16883,16884]
===
match
---
name: task [60846,60850]
name: task [61270,61274]
===
match
---
name: _execute_task [50319,50332]
name: _execute_task [50319,50332]
===
match
---
expr_stmt [11021,11047]
expr_stmt [11021,11047]
===
match
---
trailer [71135,71139]
trailer [71559,71563]
===
match
---
trailer [61430,61434]
trailer [61854,61858]
===
match
---
trailer [45065,45072]
trailer [45065,45072]
===
match
---
string: '' [58555,58557]
string: '' [58979,58981]
===
match
---
name: pod_generator [3166,3179]
name: pod_generator [3166,3179]
===
match
---
name: context [67362,67369]
name: context [67786,67793]
===
match
---
if_stmt [45161,45313]
if_stmt [45161,45313]
===
match
---
name: e [66873,66874]
name: e [67297,67298]
===
match
---
trailer [73745,73750]
trailer [74169,74174]
===
match
---
param [15456,15468]
param [15456,15468]
===
match
---
tfpdef [27887,27907]
tfpdef [27887,27907]
===
match
---
subscriptlist [73692,73710]
subscriptlist [74116,74134]
===
match
---
name: Optional [30899,30907]
name: Optional [30899,30907]
===
match
---
operator: = [5985,5986]
operator: = [5985,5986]
===
match
---
atom_expr [45468,45484]
atom_expr [45468,45484]
===
match
---
trailer [31398,31413]
trailer [31398,31413]
===
match
---
string: 'macros' [63953,63961]
string: 'macros' [64377,64385]
===
match
---
name: result [43193,43199]
name: result [43193,43199]
===
match
---
name: dag_run_state [8934,8947]
name: dag_run_state [8934,8947]
===
match
---
simple_stmt [34701,34793]
simple_stmt [34701,34793]
===
match
---
decorated [14487,14572]
decorated [14487,14572]
===
match
---
name: test_mode [42453,42462]
name: test_mode [42453,42462]
===
match
---
param [13753,13757]
param [13753,13757]
===
match
---
name: UndefinedError [65885,65899]
name: UndefinedError [66309,66323]
===
match
---
not_test [47161,47174]
not_test [47161,47174]
===
match
---
name: self [61674,61678]
name: self [62098,62102]
===
match
---
name: TaskInstance [16477,16489]
name: TaskInstance [16477,16489]
===
match
---
name: self [24343,24347]
name: self [24343,24347]
===
match
---
funcdef [72298,73604]
funcdef [72722,74028]
===
match
---
name: State [52005,52010]
name: State [52147,52152]
===
match
---
operator: = [57004,57005]
operator: = [57428,57429]
===
match
---
expr_stmt [44885,44905]
expr_stmt [44885,44905]
===
match
---
argument [78207,78269]
argument [78631,78693]
===
match
---
name: session [40899,40906]
name: session [40899,40906]
===
match
---
trailer [79384,79392]
trailer [79808,79816]
===
match
---
name: context [47337,47344]
name: context [47337,47344]
===
match
---
operator: , [70829,70830]
operator: , [71253,71254]
===
match
---
name: Variable [62837,62845]
name: Variable [63261,63269]
===
match
---
name: ds [60552,60554]
name: ds [60976,60978]
===
match
---
atom_expr [23251,23266]
atom_expr [23251,23266]
===
match
---
suite [52019,52206]
suite [52161,52490]
===
match
---
expr_stmt [44953,44975]
expr_stmt [44953,44975]
===
match
---
operator: , [30164,30165]
operator: , [30164,30165]
===
match
---
name: self [23024,23028]
name: self [23024,23028]
===
match
---
name: extend [19880,19886]
name: extend [19880,19886]
===
match
---
arglist [61075,61105]
arglist [61499,61529]
===
match
---
trailer [32605,32629]
trailer [32605,32629]
===
match
---
name: pool_slots [23803,23813]
name: pool_slots [23803,23813]
===
match
---
name: SUCCESS [46619,46626]
name: SUCCESS [46619,46626]
===
match
---
name: session [50158,50165]
name: session [50158,50165]
===
match
---
name: in_ [7393,7396]
name: in_ [7393,7396]
===
match
---
name: self [56298,56302]
name: self [56722,56726]
===
match
---
string: '%Y-%m-%d' [60116,60126]
string: '%Y-%m-%d' [60540,60550]
===
match
---
operator: , [75658,75659]
operator: , [76082,76083]
===
match
---
expr_stmt [26344,26389]
expr_stmt [26344,26389]
===
match
---
atom_expr [5987,5999]
atom_expr [5987,5999]
===
match
---
name: timetable [28750,28759]
name: timetable [28750,28759]
===
match
---
param [30878,30883]
param [30878,30883]
===
match
---
simple_stmt [42522,42549]
simple_stmt [42522,42549]
===
match
---
annassign [79525,79549]
annassign [79949,79973]
===
match
---
trailer [16186,16196]
trailer [16186,16196]
===
match
---
name: instance [63875,63883]
name: instance [64299,64307]
===
match
---
simple_stmt [78284,78493]
simple_stmt [78708,78917]
===
match
---
name: defaultdict [8465,8476]
name: defaultdict [8465,8476]
===
match
---
atom_expr [40756,40773]
atom_expr [40756,40773]
===
match
---
simple_stmt [2140,2194]
simple_stmt [2140,2194]
===
match
---
operator: = [41280,41281]
operator: = [41280,41281]
===
match
---
name: dr [8960,8962]
name: dr [8960,8962]
===
match
---
name: task [35036,35040]
name: task [35036,35040]
===
match
---
trailer [25478,25485]
trailer [25478,25485]
===
match
---
simple_stmt [45497,45504]
simple_stmt [45497,45504]
===
match
---
simple_stmt [58502,58538]
simple_stmt [58926,58962]
===
match
---
name: debug [26116,26121]
name: debug [26116,26121]
===
match
---
simple_stmt [12484,12512]
simple_stmt [12484,12512]
===
match
---
atom_expr [71836,71851]
atom_expr [72260,72275]
===
match
---
name: _prepare_and_execute_task_with_callbacks [47290,47330]
name: _prepare_and_execute_task_with_callbacks [47290,47330]
===
match
---
simple_stmt [5929,5956]
simple_stmt [5929,5956]
===
match
---
trailer [8925,8931]
trailer [8925,8931]
===
match
---
trailer [46862,46899]
trailer [46862,46899]
===
match
---
trailer [49808,49813]
trailer [49808,49813]
===
match
---
suite [19565,19609]
suite [19565,19609]
===
match
---
suite [61409,61442]
suite [61833,61866]
===
match
---
name: query [25311,25316]
name: query [25311,25316]
===
match
---
name: context [50339,50346]
name: context [50339,50346]
===
match
---
name: make_aware [13135,13145]
name: make_aware [13135,13145]
===
match
---
operator: = [70814,70815]
operator: = [71238,71239]
===
match
---
with_stmt [71174,71239]
with_stmt [71598,71663]
===
match
---
expr_stmt [12484,12511]
expr_stmt [12484,12511]
===
match
---
name: self [54445,54449]
name: self [54869,54873]
===
match
---
operator: = [72441,72442]
operator: = [72865,72866]
===
match
---
simple_stmt [41683,41715]
simple_stmt [41683,41715]
===
match
---
name: self [23847,23851]
name: self [23847,23851]
===
match
---
name: self [20709,20713]
name: self [20709,20713]
===
match
---
if_stmt [72044,72207]
if_stmt [72468,72631]
===
match
---
expr_stmt [77051,77065]
expr_stmt [77475,77489]
===
match
---
simple_stmt [50227,50310]
simple_stmt [50227,50310]
===
match
---
simple_stmt [76258,76328]
simple_stmt [76682,76752]
===
match
---
import_as_names [3414,3427]
import_as_names [3414,3427]
===
match
---
name: execution_date [73338,73352]
name: execution_date [73762,73776]
===
match
---
trailer [49748,49761]
trailer [49748,49761]
===
match
---
decorated [77103,79018]
decorated [77527,79442]
===
match
---
atom_expr [23778,23785]
atom_expr [23778,23785]
===
match
---
operator: = [50717,50718]
operator: = [50717,50718]
===
match
---
trailer [50112,50119]
trailer [50112,50119]
===
match
---
trailer [67973,67988]
trailer [68397,68412]
===
match
---
atom_expr [11154,11174]
atom_expr [11154,11174]
===
match
---
name: queued_dttm [11457,11468]
name: queued_dttm [11457,11468]
===
match
---
trailer [45472,45476]
trailer [45472,45476]
===
match
---
expr_stmt [23935,23962]
expr_stmt [23935,23962]
===
match
---
if_stmt [19922,20002]
if_stmt [19922,20002]
===
match
---
except_clause [71884,71900]
except_clause [72308,72324]
===
match
---
name: exception [51386,51395]
name: exception [51386,51395]
===
match
---
parameters [80651,80657]
parameters [81075,81081]
===
match
---
operator: = [60550,60551]
operator: = [60974,60975]
===
match
---
name: DagRunState [2957,2968]
name: DagRunState [2957,2968]
===
match
---
comparison [55450,55467]
comparison [55874,55891]
===
match
---
trailer [60596,60611]
trailer [61020,61035]
===
match
---
name: ti [23706,23708]
name: ti [23706,23708]
===
match
---
atom_expr [46843,46899]
atom_expr [46843,46899]
===
match
---
name: self [9881,9885]
name: self [9881,9885]
===
match
---
comparison [51791,51827]
comparison [51791,51827]
===
match
---
simple_stmt [42875,42953]
simple_stmt [42875,42953]
===
match
---
argument [58861,58883]
argument [59285,59307]
===
match
---
trailer [42651,42658]
trailer [42651,42658]
===
match
---
name: error [57804,57809]
name: error [58228,58233]
===
match
---
dotted_name [66438,66469]
dotted_name [66862,66893]
===
match
---
operator: = [81835,81836]
operator: = [82259,82260]
===
match
---
arglist [25714,25777]
arglist [25714,25777]
===
match
---
name: self [43099,43103]
name: self [43099,43103]
===
match
---
simple_stmt [16470,17025]
simple_stmt [16470,17025]
===
match
---
name: log [51382,51385]
name: log [51382,51385]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [29838,29977]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [29838,29977]
===
match
---
return_stmt [15104,15127]
return_stmt [15104,15127]
===
match
---
trailer [30980,30989]
trailer [30980,30989]
===
match
---
trailer [23862,23868]
trailer [23862,23868]
===
match
---
atom_expr [26280,26294]
atom_expr [26280,26294]
===
match
---
operator: , [32724,32725]
operator: , [32724,32725]
===
match
---
name: UndefinedError [66758,66772]
name: UndefinedError [67182,67196]
===
match
---
atom_expr [68725,68746]
atom_expr [69149,69170]
===
match
---
trailer [59874,59895]
trailer [60298,60319]
===
match
---
operator: , [1703,1704]
operator: , [1703,1704]
===
match
---
operator: , [34310,34311]
operator: , [34310,34311]
===
match
---
name: all [77900,77903]
name: all [78324,78327]
===
match
---
atom_expr [50130,50149]
atom_expr [50130,50149]
===
match
---
trailer [9424,9439]
trailer [9424,9439]
===
match
---
trailer [49611,49620]
trailer [49611,49620]
===
match
---
trailer [64366,64372]
trailer [64790,64796]
===
match
---
trailer [25262,25266]
trailer [25262,25266]
===
match
---
name: dag_id [9166,9172]
name: dag_id [9166,9172]
===
match
---
operator: , [70927,70928]
operator: , [71351,71352]
===
match
---
name: str [73772,73775]
name: str [74196,74199]
===
match
---
trailer [19886,19913]
trailer [19886,19913]
===
match
---
atom_expr [79887,79900]
atom_expr [80311,80324]
===
match
---
simple_stmt [16214,16253]
simple_stmt [16214,16253]
===
match
---
atom_expr [25521,25556]
atom_expr [25521,25556]
===
match
---
arglist [79927,79948]
arglist [80351,80372]
===
match
---
name: ignore_depends_on_past [16735,16757]
name: ignore_depends_on_past [16735,16757]
===
match
---
simple_stmt [26107,26170]
simple_stmt [26107,26170]
===
match
---
simple_stmt [54507,54790]
simple_stmt [54931,55214]
===
match
---
trailer [34248,34253]
trailer [34248,34253]
===
match
---
name: activate_dag_runs [4852,4869]
name: activate_dag_runs [4852,4869]
===
match
---
trailer [50799,50801]
trailer [50799,50801]
===
match
---
operator: , [16721,16722]
operator: , [16721,16722]
===
match
---
trailer [23567,23578]
trailer [23567,23578]
===
match
---
atom_expr [57049,57070]
atom_expr [57473,57494]
===
match
---
atom_expr [45393,45406]
atom_expr [45393,45406]
===
match
---
name: load_error_file [53825,53840]
name: load_error_file [54249,54264]
===
match
---
operator: , [78047,78048]
operator: , [78471,78472]
===
match
---
trailer [4914,4943]
trailer [4914,4943]
===
match
---
comparison [78728,78776]
comparison [79152,79200]
===
match
---
trailer [48436,48588]
trailer [48436,48588]
===
match
---
simple_stmt [49803,49865]
simple_stmt [49803,49865]
===
match
---
name: merge [55021,55026]
name: merge [55445,55450]
===
match
---
simple_stmt [49638,49686]
simple_stmt [49638,49686]
===
match
---
simple_stmt [12998,13075]
simple_stmt [12998,13075]
===
match
---
trailer [48237,48244]
trailer [48237,48244]
===
match
---
atom_expr [11359,11378]
atom_expr [11359,11378]
===
match
---
name: state [5708,5713]
name: state [5708,5713]
===
match
---
operator: = [35512,35513]
operator: = [35512,35513]
===
match
---
name: bool [37449,37453]
name: bool [37449,37453]
===
match
---
simple_stmt [82118,82169]
simple_stmt [82542,82593]
===
match
---
tfpdef [52537,52550]
tfpdef [52961,52974]
===
match
---
operator: == [76794,76796]
operator: == [77218,77220]
===
match
---
trailer [40366,40368]
trailer [40366,40368]
===
match
---
fstring_expr [34777,34789]
fstring_expr [34777,34789]
===
match
---
operator: } [46982,46983]
operator: } [46982,46983]
===
match
---
name: str [21191,21194]
name: str [21191,21194]
===
match
---
trailer [78391,78422]
trailer [78815,78846]
===
match
---
name: self [24239,24243]
name: self [24239,24243]
===
match
---
atom_expr [63928,63939]
atom_expr [64352,64363]
===
match
---
if_stmt [13349,13390]
if_stmt [13349,13390]
===
match
---
name: Column [10968,10974]
name: Column [10968,10974]
===
match
---
atom_expr [60733,60762]
atom_expr [61157,61186]
===
match
---
atom_expr [42557,42570]
atom_expr [42557,42570]
===
match
---
name: session [57869,57876]
name: session [58293,58300]
===
match
---
trailer [12488,12496]
trailer [12488,12496]
===
match
---
name: Exception [55222,55231]
name: Exception [55646,55655]
===
match
---
trailer [55261,55267]
trailer [55685,55691]
===
match
---
trailer [68075,68084]
trailer [68499,68508]
===
match
---
trailer [25718,25725]
trailer [25718,25725]
===
match
---
trailer [58637,58644]
trailer [59061,59068]
===
match
---
trailer [19588,19608]
trailer [19588,19608]
===
match
---
trailer [26796,26798]
trailer [26796,26798]
===
match
---
trailer [56188,56208]
trailer [56612,56632]
===
match
---
if_stmt [57476,57526]
if_stmt [57900,57950]
===
match
---
import_from [58705,58745]
import_from [59129,59169]
===
match
---
operator: , [46804,46805]
operator: , [46804,46805]
===
match
---
name: dag_id [78336,78342]
name: dag_id [78760,78766]
===
match
---
number: 1 [39565,39566]
number: 1 [39565,39566]
===
match
---
dotted_name [1998,2021]
dotted_name [1998,2021]
===
match
---
name: TaskInstance [78880,78892]
name: TaskInstance [79304,79316]
===
match
---
operator: , [12297,12298]
operator: , [12297,12298]
===
match
---
atom_expr [59284,59303]
atom_expr [59708,59727]
===
match
---
simple_stmt [56109,56135]
simple_stmt [56533,56559]
===
match
---
name: VariableAccessor [61122,61138]
name: VariableAccessor [61546,61562]
===
match
---
atom_expr [73317,73336]
atom_expr [73741,73760]
===
match
---
suite [5526,5775]
suite [5526,5775]
===
match
---
atom_expr [49739,49793]
atom_expr [49739,49793]
===
match
---
name: RUNNING [42541,42548]
name: RUNNING [42541,42548]
===
match
---
name: _end_date [80464,80473]
name: _end_date [80888,80897]
===
match
---
arglist [55922,55939]
arglist [56346,56363]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.             """ [32357,32516]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.             """ [32357,32516]
===
match
---
trailer [26209,26220]
trailer [26209,26220]
===
match
---
suite [61646,61684]
suite [62070,62108]
===
match
---
operator: @ [26804,26805]
operator: @ [26804,26805]
===
match
---
operator: = [48975,48976]
operator: = [48975,48976]
===
match
---
simple_stmt [68322,68354]
simple_stmt [68746,68778]
===
match
---
operator: @ [77103,77104]
operator: @ [77527,77528]
===
match
---
name: ignore_all_deps [19764,19779]
name: ignore_all_deps [19764,19779]
===
match
---
trailer [15231,15243]
trailer [15231,15243]
===
match
---
expr_stmt [69354,69694]
expr_stmt [69778,70118]
===
match
---
name: dry_run [53942,53949]
name: dry_run [54366,54373]
===
match
---
param [37432,37462]
param [37432,37462]
===
match
---
trailer [45124,45132]
trailer [45124,45132]
===
match
---
name: duration [72191,72199]
name: duration [72615,72623]
===
match
---
name: task [5987,5991]
name: task [5987,5991]
===
match
---
name: VariableJsonAccessor [65074,65094]
name: VariableJsonAccessor [65498,65518]
===
match
---
atom_expr [32137,32164]
atom_expr [32137,32164]
===
match
---
dotted_name [2496,2509]
dotted_name [2496,2509]
===
match
---
atom_expr [47204,47214]
atom_expr [47204,47214]
===
match
---
name: Context [3262,3269]
name: Context [3262,3269]
===
match
---
simple_stmt [47130,47150]
simple_stmt [47130,47150]
===
match
---
parameters [67241,67282]
parameters [67665,67706]
===
match
---
name: dag_id [22923,22929]
name: dag_id [22923,22929]
===
match
---
operator: , [64248,64249]
operator: , [64672,64673]
===
match
---
trailer [54076,54078]
trailer [54500,54502]
===
match
---
trailer [56281,56296]
trailer [56705,56720]
===
match
---
arglist [72230,72270]
arglist [72654,72694]
===
match
---
funcdef [80643,80692]
funcdef [81067,81116]
===
match
---
funcdef [65313,66299]
funcdef [65737,66723]
===
match
---
operator: , [16557,16558]
operator: , [16557,16558]
===
match
---
trailer [78295,78492]
trailer [78719,78916]
===
match
---
param [55242,55275]
param [55666,55699]
===
match
---
trailer [20106,20119]
trailer [20106,20119]
===
match
---
operator: @ [20674,20675]
operator: @ [20674,20675]
===
match
---
parameters [25818,25850]
parameters [25818,25850]
===
match
---
and_test [78207,78256]
and_test [78631,78680]
===
match
---
atom_expr [67683,67695]
atom_expr [68107,68119]
===
match
---
atom_expr [41544,41625]
atom_expr [41544,41625]
===
match
---
operator: = [23742,23743]
operator: = [23742,23743]
===
match
---
name: dag_id [10789,10795]
name: dag_id [10789,10795]
===
match
---
name: sqlalchemy [2895,2905]
name: sqlalchemy [2895,2905]
===
match
---
name: dagrun [37067,37073]
name: dagrun [37067,37073]
===
match
---
if_stmt [4165,4199]
if_stmt [4165,4199]
===
match
---
trailer [60939,60952]
trailer [61363,61376]
===
match
---
name: hr_line_break [42267,42280]
name: hr_line_break [42267,42280]
===
match
---
param [47346,47350]
param [47346,47350]
===
match
---
name: error [4786,4791]
name: error [4786,4791]
===
match
---
operator: = [57919,57920]
operator: = [58343,58344]
===
match
---
operator: , [15446,15447]
operator: , [15446,15447]
===
match
---
atom_expr [61605,61613]
atom_expr [62029,62037]
===
match
---
trailer [34522,34529]
trailer [34522,34529]
===
match
---
simple_stmt [11383,11417]
simple_stmt [11383,11417]
===
match
---
trailer [47208,47214]
trailer [47208,47214]
===
match
---
number: 1 [9696,9697]
number: 1 [9696,9697]
===
match
---
name: property [80075,80083]
name: property [80499,80507]
===
match
---
name: state [21806,21811]
name: state [21806,21811]
===
match
---
string: 'Submitting %s to sensor service' [50002,50035]
string: 'Submitting %s to sensor service' [50002,50035]
===
match
---
expr_stmt [20472,20516]
expr_stmt [20472,20516]
===
match
---
atom_expr [39530,39570]
atom_expr [39530,39570]
===
match
---
name: iso [19536,19539]
name: iso [19536,19539]
===
match
---
atom_expr [4946,4964]
atom_expr [4946,4964]
===
match
---
name: value [73420,73425]
name: value [73844,73849]
===
match
---
trailer [57339,57351]
trailer [57763,57775]
===
match
---
atom_expr [59780,59799]
atom_expr [60204,60223]
===
match
---
name: self [23798,23802]
name: self [23798,23802]
===
match
---
simple_stmt [59063,59080]
simple_stmt [59487,59504]
===
match
---
simple_stmt [53500,53747]
simple_stmt [53924,54171]
===
match
---
name: item [61748,61752]
name: item [62172,62176]
===
match
---
trailer [55055,55057]
trailer [55479,55481]
===
match
---
operator: = [77641,77642]
operator: = [78065,78066]
===
match
---
name: dag_id [75573,75579]
name: dag_id [75997,76003]
===
match
---
name: dag_id [27533,27539]
name: dag_id [27533,27539]
===
match
---
name: try_number [13920,13930]
name: try_number [13920,13930]
===
match
---
expr_stmt [58972,59016]
expr_stmt [59396,59440]
===
match
---
name: session [31513,31520]
name: session [31513,31520]
===
match
---
name: is_premature [26519,26531]
name: is_premature [26519,26531]
===
match
---
simple_stmt [16070,16115]
simple_stmt [16070,16115]
===
match
---
atom_expr [73179,73367]
atom_expr [73603,73791]
===
match
---
name: SEEK_SET [4217,4225]
name: SEEK_SET [4217,4225]
===
match
---
trailer [60676,60685]
trailer [61100,61109]
===
match
---
name: ignore_task_deps [41444,41460]
name: ignore_task_deps [41444,41460]
===
match
---
operator: == [78540,78542]
operator: == [78964,78966]
===
match
---
atom_expr [31546,31573]
atom_expr [31546,31573]
===
match
---
name: item [62443,62447]
name: item [62867,62871]
===
match
---
operator: = [24187,24188]
operator: = [24187,24188]
===
match
---
atom_expr [78230,78239]
atom_expr [78654,78663]
===
match
---
operator: , [17181,17182]
operator: , [17181,17182]
===
match
---
name: log [33506,33509]
name: log [33506,33509]
===
match
---
operator: == [36748,36750]
operator: == [36748,36750]
===
match
---
argument [29750,29765]
argument [29750,29765]
===
match
---
operator: + [20594,20595]
operator: + [20594,20595]
===
match
---
expr_stmt [37122,37289]
expr_stmt [37122,37289]
===
match
---
trailer [42298,42303]
trailer [42298,42303]
===
match
---
trailer [77583,77586]
trailer [78007,78010]
===
match
---
trailer [33444,33446]
trailer [33444,33446]
===
match
---
name: session [31329,31336]
name: session [31329,31336]
===
match
---
trailer [59235,59238]
trailer [59659,59662]
===
match
---
simple_stmt [3325,3359]
simple_stmt [3325,3359]
===
match
---
argument [40291,40306]
argument [40291,40306]
===
match
---
trailer [61575,61581]
trailer [61999,62005]
===
match
---
operator: , [32706,32707]
operator: , [32706,32707]
===
match
---
atom_expr [35422,35437]
atom_expr [35422,35437]
===
match
---
name: context [67248,67255]
name: context [67672,67679]
===
match
---
import_from [2925,2975]
import_from [2925,2975]
===
match
---
operator: , [17111,17112]
operator: , [17111,17112]
===
match
---
trailer [29999,30233]
trailer [29999,30233]
===
match
---
name: self [48233,48237]
name: self [48233,48237]
===
match
---
simple_stmt [66667,66714]
simple_stmt [67091,67138]
===
match
---
simple_stmt [20433,20464]
simple_stmt [20433,20464]
===
match
---
not_test [39465,39484]
not_test [39465,39484]
===
match
---
name: String [11366,11372]
name: String [11366,11372]
===
match
---
trailer [59673,59690]
trailer [60097,60114]
===
match
---
arith_expr [36541,36562]
arith_expr [36541,36562]
===
match
---
name: self [51991,51995]
name: self [52133,52137]
===
match
---
name: XCOM_RETURN_KEY [73778,73793]
name: XCOM_RETURN_KEY [74202,74217]
===
match
---
name: provide_session [72278,72293]
name: provide_session [72702,72717]
===
match
---
operator: , [65752,65753]
operator: , [66176,66177]
===
match
---
name: task_id [25732,25739]
name: task_id [25732,25739]
===
match
---
name: logging [12594,12601]
name: logging [12594,12601]
===
match
---
arglist [50002,50041]
arglist [50002,50041]
===
match
---
trailer [41013,41024]
trailer [41013,41024]
===
match
---
name: self [21715,21719]
name: self [21715,21719]
===
match
---
decorated [20392,20669]
decorated [20392,20669]
===
match
---
trailer [47195,47199]
trailer [47195,47199]
===
match
---
decorator [52485,52502]
decorator [52909,52926]
===
match
---
argument [16688,16721]
argument [16688,16721]
===
match
---
name: str [19667,19670]
name: str [19667,19670]
===
match
---
trailer [59934,59938]
trailer [60358,60362]
===
match
---
name: first_task_id [78464,78477]
name: first_task_id [78888,78901]
===
match
---
not_test [53391,53398]
not_test [53815,53822]
===
match
---
name: String [11197,11203]
name: String [11197,11203]
===
match
---
trailer [44973,44975]
trailer [44973,44975]
===
match
---
atom_expr [6456,6464]
atom_expr [6456,6464]
===
match
---
operator: = [60490,60491]
operator: = [60914,60915]
===
match
---
operator: , [71851,71852]
operator: , [72275,72276]
===
match
---
trailer [3804,3806]
trailer [3804,3806]
===
match
---
name: airflow [2454,2461]
name: airflow [2454,2461]
===
match
---
name: self [49836,49840]
name: self [49836,49840]
===
match
---
trailer [26317,26330]
trailer [26317,26330]
===
match
---
trailer [72190,72199]
trailer [72614,72623]
===
match
---
trailer [24850,24862]
trailer [24850,24862]
===
match
---
trailer [28277,28288]
trailer [28277,28288]
===
match
---
parameters [20708,20714]
parameters [20708,20714]
===
match
---
atom_expr [25343,25354]
atom_expr [25343,25354]
===
match
---
operator: , [73563,73564]
operator: , [73987,73988]
===
match
---
simple_stmt [46247,46270]
simple_stmt [46247,46270]
===
match
---
atom_expr [54819,54829]
atom_expr [55243,55253]
===
match
---
atom [76281,76327]
atom [76705,76751]
===
match
---
dotted_name [2454,2475]
dotted_name [2454,2475]
===
match
---
import_from [2140,2193]
import_from [2140,2193]
===
match
---
tfpdef [55284,55300]
tfpdef [55708,55724]
===
match
---
operator: = [52589,52590]
operator: = [53013,53014]
===
match
---
simple_stmt [50368,50440]
simple_stmt [50368,50440]
===
match
---
arglist [29624,29652]
arglist [29624,29652]
===
match
---
arith_expr [36323,36356]
arith_expr [36323,36356]
===
match
---
operator: , [73757,73758]
operator: , [74181,74182]
===
match
---
trailer [11203,11209]
trailer [11203,11209]
===
match
---
expr_stmt [56993,57018]
expr_stmt [57417,57442]
===
match
---
name: ID_LEN [10812,10818]
name: ID_LEN [10812,10818]
===
match
---
name: task [56271,56275]
name: task [56695,56699]
===
match
---
arglist [60694,60701]
arglist [61118,61125]
===
match
---
name: property [80698,80706]
name: property [81122,81130]
===
match
---
atom_expr [43622,43655]
atom_expr [43622,43655]
===
match
---
expr_stmt [60540,60571]
expr_stmt [60964,60995]
===
match
---
trailer [23734,23741]
trailer [23734,23741]
===
match
---
trailer [67397,67418]
trailer [67821,67842]
===
match
---
operator: { [34777,34778]
operator: { [34777,34778]
===
match
---
operator: = [8974,8975]
operator: = [8974,8975]
===
match
---
name: ignore_ti_state [41478,41493]
name: ignore_ti_state [41478,41493]
===
match
---
simple_stmt [11052,11107]
simple_stmt [11052,11107]
===
match
---
param [71637,71646]
param [72061,72070]
===
match
---
trailer [11196,11210]
trailer [11196,11210]
===
match
---
tfpdef [51476,51514]
tfpdef [51476,51514]
===
match
---
name: get_task_instance [29718,29735]
name: get_task_instance [29718,29735]
===
match
---
operator: { [56076,56077]
operator: { [56500,56501]
===
match
---
operator: == [81695,81697]
operator: == [82119,82121]
===
match
---
name: Index [12100,12105]
name: Index [12100,12105]
===
match
---
param [43791,43796]
param [43791,43796]
===
match
---
simple_stmt [29489,29553]
simple_stmt [29489,29553]
===
match
---
trailer [73691,73711]
trailer [74115,74135]
===
match
---
argument [75805,75820]
argument [76229,76244]
===
match
---
name: task [57049,57053]
name: task [57473,57477]
===
match
---
name: job_id [37665,37671]
name: job_id [37665,37671]
===
match
---
atom_expr [80014,80025]
atom_expr [80438,80449]
===
match
---
name: self [73544,73548]
name: self [73968,73972]
===
match
---
atom_expr [43882,43895]
atom_expr [43882,43895]
===
match
---
trailer [46444,46446]
trailer [46444,46446]
===
match
---
expr_stmt [9166,9177]
expr_stmt [9166,9177]
===
match
---
operator: , [30196,30197]
operator: , [30196,30197]
===
match
---
name: TaskInstance [21527,21539]
name: TaskInstance [21527,21539]
===
match
---
expr_stmt [68755,68808]
expr_stmt [69179,69232]
===
match
---
name: os [854,856]
name: os [854,856]
===
match
---
trailer [51491,51514]
trailer [51491,51514]
===
match
---
suite [63439,63673]
suite [63863,64097]
===
match
---
name: hexdigest [35735,35744]
name: hexdigest [35735,35744]
===
match
---
if_stmt [67355,67421]
if_stmt [67779,67845]
===
match
---
name: attr [43148,43152]
name: attr [43148,43152]
===
match
---
name: context [3738,3745]
name: context [3738,3745]
===
match
---
name: session [59029,59036]
name: session [59453,59460]
===
match
---
operator: + [41991,41992]
operator: + [41991,41992]
===
match
---
operator: = [15409,15410]
operator: = [15409,15410]
===
match
---
name: timezone [45057,45065]
name: timezone [45057,45065]
===
match
---
name: state [76893,76898]
name: state [77317,77322]
===
match
---
trailer [34561,34568]
trailer [34561,34568]
===
match
---
number: 0 [27766,27767]
number: 0 [27766,27767]
===
match
---
name: dates_by_dag_id [8803,8818]
name: dates_by_dag_id [8803,8818]
===
match
---
name: previous_schedule [59857,59874]
name: previous_schedule [60281,60298]
===
match
---
name: dag_id [9628,9634]
name: dag_id [9628,9634]
===
match
---
name: self [41939,41943]
name: self [41939,41943]
===
match
---
suite [50662,50727]
suite [50662,50727]
===
match
---
name: name [78535,78539]
name: name [78959,78963]
===
match
---
fstring [20998,21022]
fstring [20998,21022]
===
match
---
name: property [80868,80876]
name: property [81292,81300]
===
match
---
simple_stmt [42415,42437]
simple_stmt [42415,42437]
===
match
---
parameters [81076,81119]
parameters [81500,81543]
===
match
---
simple_stmt [1018,1118]
simple_stmt [1018,1118]
===
match
---
trailer [57203,57258]
trailer [57627,57682]
===
match
---
param [52874,52887]
param [53298,53311]
===
match
---
atom_expr [43960,43973]
atom_expr [43960,43973]
===
match
---
name: info [48432,48436]
name: info [48432,48436]
===
match
---
operator: = [13013,13014]
operator: = [13013,13014]
===
match
---
trailer [9674,9698]
trailer [9674,9698]
===
match
---
operator: , [81602,81603]
operator: , [82026,82027]
===
match
---
name: self [44747,44751]
name: self [44747,44751]
===
match
---
parameters [80341,80347]
parameters [80765,80771]
===
match
---
trailer [68011,68027]
trailer [68435,68451]
===
match
---
simple_stmt [65723,65770]
simple_stmt [66147,66194]
===
match
---
atom_expr [42488,42512]
atom_expr [42488,42512]
===
match
---
name: self [45882,45886]
name: self [45882,45886]
===
match
---
atom_expr [59848,59895]
atom_expr [60272,60319]
===
match
---
simple_stmt [2321,2372]
simple_stmt [2321,2372]
===
match
---
operator: = [77506,77507]
operator: = [77930,77931]
===
match
---
operator: , [33624,33625]
operator: , [33624,33625]
===
match
---
name: self [80652,80656]
name: self [81076,81080]
===
match
---
expr_stmt [5351,5363]
expr_stmt [5351,5363]
===
match
---
name: prev_ti [31391,31398]
name: prev_ti [31391,31398]
===
match
---
operator: , [40009,40010]
operator: , [40009,40010]
===
match
---
atom_expr [5474,5482]
atom_expr [5474,5482]
===
match
---
argument [51046,51065]
argument [51046,51065]
===
match
---
name: pickle [4309,4315]
name: pickle [4309,4315]
===
match
---
comparison [25383,25411]
comparison [25383,25411]
===
match
---
name: incr [39536,39540]
name: incr [39536,39540]
===
match
---
atom_expr [26776,26798]
atom_expr [26776,26798]
===
match
---
simple_stmt [2372,2449]
simple_stmt [2372,2449]
===
match
---
simple_stmt [17627,19436]
simple_stmt [17627,19436]
===
match
---
operator: = [50857,50858]
operator: = [50857,50858]
===
match
---
atom [58511,58513]
atom [58935,58937]
===
match
---
name: end_date [55980,55988]
name: end_date [56404,56412]
===
match
---
operator: , [54679,54680]
operator: , [55103,55104]
===
match
---
atom_expr [24088,24094]
atom_expr [24088,24094]
===
match
---
simple_stmt [47531,47553]
simple_stmt [47531,47553]
===
match
---
arglist [57424,57465]
arglist [57848,57889]
===
match
---
return_stmt [33920,33932]
return_stmt [33920,33932]
===
match
---
atom_expr [37183,37196]
atom_expr [37183,37196]
===
match
---
expr_stmt [21852,21864]
expr_stmt [21852,21864]
===
match
---
atom_expr [11432,11452]
atom_expr [11432,11452]
===
match
---
trailer [68187,68206]
trailer [68611,68630]
===
match
---
name: retries [58236,58243]
name: retries [58660,58667]
===
match
---
for_stmt [65634,65770]
for_stmt [66058,66194]
===
match
---
atom_expr [58592,58612]
atom_expr [59016,59036]
===
match
---
atom_expr [58981,58995]
atom_expr [59405,59419]
===
match
---
trailer [78000,78191]
trailer [78424,78615]
===
match
---
simple_stmt [34121,34151]
simple_stmt [34121,34151]
===
match
---
trailer [11978,12034]
trailer [11978,12034]
===
match
---
name: execution_date [13175,13189]
name: execution_date [13175,13189]
===
match
---
expr_stmt [50683,50726]
expr_stmt [50683,50726]
===
match
---
name: debug [33540,33545]
name: debug [33540,33545]
===
match
---
tfpdef [25825,25835]
tfpdef [25825,25835]
===
match
---
atom_expr [81837,81848]
atom_expr [82261,82272]
===
match
---
name: cfg_path [17567,17575]
name: cfg_path [17567,17575]
===
match
---
dotted_name [82029,82050]
dotted_name [82453,82474]
===
match
---
name: current_time [26066,26078]
name: current_time [26066,26078]
===
match
---
name: default_html_content [71443,71463]
name: default_html_content [71867,71887]
===
match
---
simple_stmt [66513,66600]
simple_stmt [66937,67024]
===
match
---
name: session [81519,81526]
name: session [81943,81950]
===
match
---
param [27887,27915]
param [27887,27915]
===
match
---
suite [51746,51978]
suite [51746,52120]
===
match
---
name: Optional [52844,52852]
name: Optional [53268,53276]
===
match
---
trailer [47248,47254]
trailer [47248,47254]
===
match
---
atom_expr [78291,78492]
atom_expr [78715,78916]
===
match
---
atom_expr [80128,80140]
atom_expr [80552,80564]
===
match
---
tfpdef [73846,73862]
tfpdef [74270,74286]
===
match
---
param [66357,66369]
param [66781,66793]
===
match
---
decorated [80559,80624]
decorated [80983,81048]
===
match
---
trailer [11546,11555]
trailer [11546,11555]
===
match
---
atom_expr [60846,60857]
atom_expr [61270,61281]
===
match
---
operator: = [6465,6466]
operator: = [6465,6466]
===
match
---
not_test [67358,67369]
not_test [67782,67793]
===
match
---
operator: , [78921,78922]
operator: , [79345,79346]
===
match
---
and_test [73104,73159]
and_test [73528,73583]
===
match
---
name: state [13352,13357]
name: state [13352,13357]
===
match
---
simple_stmt [2716,2783]
simple_stmt [2716,2783]
===
match
---
arglist [30013,30223]
arglist [30013,30223]
===
match
---
name: session [55013,55020]
name: session [55437,55444]
===
match
---
name: lazy_object_proxy [64506,64523]
name: lazy_object_proxy [64930,64947]
===
match
---
name: task [51263,51267]
name: task [51263,51267]
===
match
---
atom_expr [47779,47824]
atom_expr [47779,47824]
===
match
---
trailer [25347,25354]
trailer [25347,25354]
===
match
---
if_stmt [57267,57467]
if_stmt [57691,57891]
===
match
---
trailer [22262,22264]
trailer [22262,22264]
===
match
---
name: self [65817,65821]
name: self [66241,66245]
===
match
---
simple_stmt [3682,3715]
simple_stmt [3682,3715]
===
match
---
operator: == [52230,52232]
operator: == [52514,52516]
===
match
---
operator: , [46303,46304]
operator: , [46303,46304]
===
match
---
operator: = [23902,23903]
operator: = [23902,23903]
===
match
---
trailer [56081,56091]
trailer [56505,56515]
===
match
---
name: state [24244,24249]
name: state [24244,24249]
===
match
---
try_stmt [4289,4397]
try_stmt [4289,4397]
===
match
---
operator: = [17551,17552]
operator: = [17551,17552]
===
match
---
name: DepContext [33434,33444]
name: DepContext [33434,33444]
===
match
---
operator: , [71365,71366]
operator: , [71789,71790]
===
match
---
decorator [21129,21146]
decorator [21129,21146]
===
match
---
parameters [30868,30959]
parameters [30868,30959]
===
match
---
operator: = [49785,49786]
operator: = [49785,49786]
===
match
---
except_clause [4615,4631]
except_clause [4615,4631]
===
match
---
operator: = [37416,37417]
operator: = [37416,37417]
===
match
---
name: error [22131,22136]
name: error [22131,22136]
===
match
---
name: self [13931,13935]
name: self [13931,13935]
===
match
---
string: '-' [60677,60680]
string: '-' [61101,61104]
===
match
---
decorator [14487,14506]
decorator [14487,14506]
===
match
---
trailer [52153,52155]
trailer [52295,52297]
===
match
---
simple_stmt [47402,47473]
simple_stmt [47402,47473]
===
match
---
simple_stmt [75559,75580]
simple_stmt [75983,76004]
===
match
---
atom_expr [61674,61682]
atom_expr [62098,62106]
===
match
---
atom_expr [54564,54573]
atom_expr [54988,54997]
===
match
---
trailer [12611,12627]
trailer [12611,12627]
===
match
---
atom_expr [27373,27397]
atom_expr [27373,27397]
===
match
---
name: task_copy [50782,50791]
name: task_copy [50782,50791]
===
match
---
name: primary [78981,78988]
name: primary [79405,79412]
===
match
---
operator: , [39566,39567]
operator: , [39566,39567]
===
match
---
name: task_id [5814,5821]
name: task_id [5814,5821]
===
match
---
name: session [29536,29543]
name: session [29536,29543]
===
match
---
argument [57838,57859]
argument [58262,58283]
===
match
---
if_stmt [60317,60531]
if_stmt [60741,60955]
===
match
---
and_test [36737,36820]
and_test [36737,36820]
===
match
---
trailer [7686,7688]
trailer [7686,7688]
===
match
---
operator: = [10850,10851]
operator: = [10850,10851]
===
match
---
name: in_ [78149,78152]
name: in_ [78573,78576]
===
match
---
if_stmt [81739,81849]
if_stmt [82163,82273]
===
match
---
name: session [53724,53731]
name: session [54148,54155]
===
match
---
atom_expr [43918,43931]
atom_expr [43918,43931]
===
match
---
name: extend [20266,20272]
name: extend [20266,20272]
===
match
---
simple_stmt [42167,42184]
simple_stmt [42167,42184]
===
match
---
name: self [69755,69759]
name: self [70179,70183]
===
match
---
trailer [44997,45003]
trailer [44997,45003]
===
match
---
name: self [59780,59784]
name: self [60204,60208]
===
insert-node
---
name: TaskInstance [10094,10106]
to
classdef [10088,79018]
at 0
===
insert-tree
---
arglist [10107,10125]
    name: Base [10107,10111]
    operator: , [10111,10112]
    name: LoggingMixin [10113,10125]
to
classdef [10088,79018]
at 1
===
insert-tree
---
simple_stmt [10132,10674]
    string: """     Task instances store the state of a task instance. This table is the     authority and single source of truth around what tasks have run and the     state they are in.      The SqlAlchemy model doesn't have a SqlAlchemy foreign key to the task or     dag model deliberately to have more control over transactions.      Database transactions on this table should insure double triggers and     any confusion around what task instances are or aren't ready to run     even while multiple schedulers may be firing task instances.     """ [10132,10673]
to
suite [10127,79018]
at 0
===
insert-node
---
try_stmt [51944,52120]
to
suite [51828,51978]
at 2
===
insert-node
---
try_stmt [52314,52490]
to
suite [52101,52206]
at 1
===
insert-node
---
try_stmt [52732,52904]
to
suite [52332,52480]
at 2
===
insert-node
---
suite [51948,52003]
to
try_stmt [51944,52120]
at 0
===
insert-node
---
suite [52318,52373]
to
try_stmt [52314,52490]
at 0
===
insert-node
---
suite [52736,52789]
to
try_stmt [52732,52904]
at 0
===
move-tree
---
simple_stmt [51944,51978]
    atom_expr [51944,51977]
        name: task [51944,51948]
        trailer [51948,51968]
            name: on_failure_callback [51949,51968]
        trailer [51968,51977]
            name: context [51969,51976]
to
suite [51948,52003]
at 0
===
move-tree
---
simple_stmt [52172,52206]
    atom_expr [52172,52205]
        name: task [52172,52176]
        trailer [52176,52196]
            name: on_success_callback [52177,52196]
        trailer [52196,52205]
            name: context [52197,52204]
to
suite [52318,52373]
at 0
===
move-tree
---
simple_stmt [52448,52480]
    atom_expr [52448,52479]
        name: task [52448,52452]
        trailer [52452,52470]
            name: on_retry_callback [52453,52470]
        trailer [52470,52479]
            name: context [52471,52478]
to
suite [52736,52789]
at 0
===
delete-node
---
name: TaskInstance [10094,10106]
===
===
delete-tree
---
arglist [10107,10125]
    name: Base [10107,10111]
    operator: , [10111,10112]
    name: LoggingMixin [10113,10125]
===
delete-tree
---
simple_stmt [10132,10674]
    string: """     Task instances store the state of a task instance. This table is the     authority and single source of truth around what tasks have run and the     state they are in.      The SqlAlchemy model doesn't have a SqlAlchemy foreign key to the task or     dag model deliberately to have more control over transactions.      Database transactions on this table should insure double triggers and     any confusion around what task instances are or aren't ready to run     even while multiple schedulers may be firing task instances.     """ [10132,10673]
