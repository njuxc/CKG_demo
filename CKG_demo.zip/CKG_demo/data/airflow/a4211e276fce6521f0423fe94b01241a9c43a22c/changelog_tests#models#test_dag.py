===
match
---
trailer [31248,31252]
trailer [31248,31252]
===
match
---
parameters [65668,65670]
parameters [67616,67618]
===
match
---
shift_expr [55244,55261]
shift_expr [57192,57209]
===
match
---
name: dag_diff_name [45007,45020]
name: dag_diff_name [45007,45020]
===
match
---
name: dump [45249,45253]
name: dump [45249,45253]
===
match
---
operator: = [46668,46669]
operator: = [46668,46669]
===
match
---
operator: == [57465,57467]
operator: == [59413,59415]
===
match
---
comparison [45289,45314]
comparison [45289,45314]
===
match
---
trailer [18431,18437]
trailer [18431,18437]
===
match
---
name: dag [38364,38367]
name: dag [38364,38367]
===
match
---
operator: , [1407,1408]
operator: , [1407,1408]
===
match
---
simple_stmt [37943,37983]
simple_stmt [37943,37983]
===
match
---
operator: - [14689,14690]
operator: - [14689,14690]
===
match
---
name: default_args [44376,44388]
name: default_args [44376,44388]
===
match
---
operator: = [60721,60722]
operator: = [62669,62670]
===
match
---
parameters [5119,5125]
parameters [5119,5125]
===
match
---
string: 'child_dag' [8212,8223]
string: 'child_dag' [8212,8223]
===
match
---
operator: == [32481,32483]
operator: == [32481,32483]
===
match
---
name: DagModel [31704,31712]
name: DagModel [31704,31712]
===
match
---
name: MANUAL [40560,40566]
name: MANUAL [40560,40566]
===
match
---
name: dag [36483,36486]
name: dag [36483,36486]
===
match
---
atom_expr [10612,10681]
atom_expr [10612,10681]
===
match
---
atom_expr [39053,39071]
atom_expr [39053,39071]
===
match
---
argument [64274,64297]
argument [66222,66245]
===
match
---
with_stmt [34100,34203]
with_stmt [34100,34203]
===
match
---
trailer [26393,26395]
trailer [26393,26395]
===
match
---
operator: } [12989,12990]
operator: } [12989,12990]
===
match
---
simple_stmt [19408,19438]
simple_stmt [19408,19438]
===
match
---
name: self [40891,40895]
name: self [40891,40895]
===
match
---
number: 2 [36715,36716]
number: 2 [36715,36716]
===
match
---
name: dag_decorator [66586,66599]
name: dag_decorator [68534,68547]
===
match
---
argument [63187,63210]
argument [65135,65158]
===
match
---
comparison [12041,12074]
comparison [12041,12074]
===
match
---
atom_expr [35879,35906]
atom_expr [35879,35906]
===
match
---
string: 'owner1' [28630,28638]
string: 'owner1' [28630,28638]
===
match
---
argument [12100,12140]
argument [12100,12140]
===
match
---
name: set_dag_runs_state [47259,47277]
name: set_dag_runs_state [47259,47277]
===
match
---
simple_stmt [40721,40783]
simple_stmt [40721,40783]
===
match
---
expr_stmt [16881,16942]
expr_stmt [16881,16942]
===
match
---
atom_expr [34500,34515]
atom_expr [34500,34515]
===
match
---
comparison [23171,23219]
comparison [23171,23219]
===
match
---
name: f [19743,19744]
name: f [19743,19744]
===
match
---
name: test_task_id [17833,17845]
name: test_task_id [17833,17845]
===
match
---
operator: = [46800,46801]
operator: = [46800,46801]
===
match
---
name: datetime [22583,22591]
name: datetime [22583,22591]
===
match
---
atom_expr [63767,63782]
atom_expr [65715,65730]
===
match
---
argument [8845,8856]
argument [8845,8856]
===
match
---
arglist [48256,48339]
arglist [48256,48339]
===
match
---
name: orm_dag [34459,34466]
name: orm_dag [34459,34466]
===
match
---
atom_expr [35787,35814]
atom_expr [35787,35814]
===
match
---
atom_expr [47188,47245]
atom_expr [47188,47245]
===
match
---
string: "test_schedule_dag_once" [42188,42212]
string: "test_schedule_dag_once" [42188,42212]
===
match
---
atom_expr [41531,41547]
atom_expr [41531,41547]
===
match
---
operator: = [7520,7521]
operator: = [7520,7521]
===
match
---
trailer [10059,10076]
trailer [10059,10076]
===
match
---
simple_stmt [43854,43884]
simple_stmt [43854,43884]
===
match
---
testlist_comp [26245,26274]
testlist_comp [26245,26274]
===
match
---
trailer [29479,29485]
trailer [29479,29485]
===
match
---
operator: = [21466,21467]
operator: = [21466,21467]
===
match
---
trailer [33030,33032]
trailer [33030,33032]
===
match
---
name: make_dag [54658,54666]
name: make_dag [56606,56614]
===
match
---
name: object [2549,2555]
name: object [2549,2555]
===
match
---
name: task_decorator [1345,1359]
name: task_decorator [1345,1359]
===
match
---
operator: = [52765,52766]
operator: = [54713,54714]
===
match
---
simple_stmt [38427,38461]
simple_stmt [38427,38461]
===
match
---
operator: , [62009,62010]
operator: , [63957,63958]
===
match
---
trailer [63925,63931]
trailer [65873,65879]
===
match
---
name: self [66048,66052]
name: self [67996,68000]
===
match
---
argument [16649,16670]
argument [16649,16670]
===
match
---
argument [9494,9526]
argument [9494,9526]
===
match
---
expr_stmt [34848,34925]
expr_stmt [34848,34925]
===
match
---
operator: , [20411,20412]
operator: , [20411,20412]
===
match
---
name: include_subdag_tasks [8073,8093]
name: include_subdag_tasks [8073,8093]
===
match
---
name: subdag [50332,50338]
name: subdag [50332,50338]
===
match
---
operator: = [6108,6109]
operator: = [6108,6109]
===
match
---
atom [48430,48498]
atom [48430,48498]
===
match
---
atom_expr [37196,37209]
atom_expr [37196,37209]
===
match
---
name: task_id [50384,50391]
name: task_id [50384,50391]
===
match
---
string: 'params' [4318,4326]
string: 'params' [4318,4326]
===
match
---
trailer [12002,12011]
trailer [12002,12011]
===
match
---
name: dag_id [45890,45896]
name: dag_id [45890,45896]
===
match
---
operator: = [50949,50950]
operator: = [50949,50950]
===
match
---
name: user_defined_filters [18609,18629]
name: user_defined_filters [18609,18629]
===
match
---
atom [64152,64157]
atom [66100,66105]
===
match
---
atom_expr [39382,39392]
atom_expr [39382,39392]
===
match
---
operator: = [50629,50630]
operator: = [50629,50630]
===
match
---
trailer [51513,51552]
trailer [51513,51552]
===
match
---
name: rollback [63899,63907]
name: rollback [65847,65855]
===
match
---
operator: = [50429,50430]
operator: = [50429,50430]
===
match
---
simple_stmt [17039,17122]
simple_stmt [17039,17122]
===
match
---
name: next_date [61192,61201]
name: next_date [63140,63149]
===
match
---
comparison [7205,7219]
comparison [7205,7219]
===
match
---
name: query [27114,27119]
name: query [27114,27119]
===
match
---
operator: = [47087,47088]
operator: = [47087,47088]
===
match
---
number: 12 [64153,64155]
number: 12 [66101,66103]
===
match
---
atom_expr [64956,64971]
atom_expr [66904,66919]
===
match
---
simple_stmt [10290,10325]
simple_stmt [10290,10325]
===
match
---
comparison [12413,12446]
comparison [12413,12446]
===
match
---
name: op5 [10004,10007]
name: op5 [10004,10007]
===
match
---
string: "2018-03-25T01:00:00+00:00" [23192,23219]
string: "2018-03-25T01:00:00+00:00" [23192,23219]
===
match
---
operator: = [28209,28210]
operator: = [28209,28210]
===
match
---
simple_stmt [14873,14906]
simple_stmt [14873,14906]
===
match
---
operator: , [8936,8937]
operator: , [8936,8937]
===
match
---
name: ti3 [17164,17167]
name: ti3 [17164,17167]
===
match
---
trailer [32673,32717]
trailer [32673,32717]
===
match
---
suite [12911,13783]
suite [12911,13783]
===
match
---
name: self [29829,29833]
name: self [29829,29833]
===
match
---
atom_expr [21077,21105]
atom_expr [21077,21105]
===
match
---
trailer [50230,50292]
trailer [50230,50292]
===
match
---
atom_expr [10087,10117]
atom_expr [10087,10117]
===
match
---
simple_stmt [56224,56270]
simple_stmt [58172,58218]
===
match
---
name: test_dag_none_default_args_start_date [12200,12237]
name: test_dag_none_default_args_start_date [12200,12237]
===
match
---
name: orm_dag [33082,33089]
name: orm_dag [33082,33089]
===
match
---
testlist_comp [32034,32046]
testlist_comp [32034,32046]
===
match
---
name: permissions [1846,1857]
name: permissions [1846,1857]
===
match
---
argument [5253,5308]
argument [5253,5308]
===
match
---
simple_stmt [34171,34203]
simple_stmt [34171,34203]
===
match
---
operator: = [7015,7016]
operator: = [7015,7016]
===
match
---
atom_expr [34631,34691]
atom_expr [34631,34691]
===
match
---
name: session [29074,29081]
name: session [29074,29081]
===
match
---
name: DAG [7334,7337]
name: DAG [7334,7337]
===
match
---
string: 'test_dags' [63174,63185]
string: 'test_dags' [65122,65133]
===
match
---
string: "2018-10-27T01:00:00+00:00" [22317,22344]
string: "2018-10-27T01:00:00+00:00" [22317,22344]
===
match
---
atom_expr [23911,23928]
atom_expr [23911,23928]
===
match
---
simple_stmt [8956,8978]
simple_stmt [8956,8978]
===
match
---
name: default_args [55025,55037]
name: default_args [56973,56985]
===
match
---
operator: = [37073,37074]
operator: = [37073,37074]
===
match
---
atom_expr [36524,36541]
atom_expr [36524,36541]
===
match
---
operator: , [50330,50331]
operator: , [50330,50331]
===
match
---
trailer [2603,2620]
trailer [2603,2620]
===
match
---
name: os [19082,19084]
name: os [19082,19084]
===
match
---
name: prev_local [21166,21176]
name: prev_local [21166,21176]
===
match
---
operator: == [2987,2989]
operator: == [2987,2989]
===
match
---
param [16405,16409]
param [16405,16409]
===
match
---
trailer [63520,63534]
trailer [65468,65482]
===
match
---
name: dag_id [31730,31736]
name: dag_id [31730,31736]
===
match
---
trailer [50183,50209]
trailer [50183,50209]
===
match
---
number: 2 [59471,59472]
number: 2 [61419,61420]
===
match
---
name: end_date [54393,54401]
name: end_date [56341,56349]
===
match
---
string: 'faketastic' [54070,54082]
string: 'faketastic' [56018,56030]
===
match
---
string: 'test-dag2' [26998,27009]
string: 'test-dag2' [26998,27009]
===
match
---
operator: != [45021,45023]
operator: != [45021,45023]
===
match
---
simple_stmt [35038,35082]
simple_stmt [35038,35082]
===
match
---
name: dag [8531,8534]
name: dag [8531,8534]
===
match
---
operator: = [55808,55809]
operator: = [57756,57757]
===
match
---
trailer [21484,21554]
trailer [21484,21554]
===
match
---
name: Exception [40122,40131]
name: Exception [40122,40131]
===
match
---
operator: , [50564,50565]
operator: , [50564,50565]
===
match
---
trailer [48761,48787]
trailer [48761,48787]
===
match
---
name: session [2831,2838]
name: session [2831,2838]
===
match
---
name: self [48124,48128]
name: self [48124,48128]
===
match
---
comparison [34253,34278]
comparison [34253,34278]
===
match
---
name: self [63988,63992]
name: self [65936,65940]
===
match
---
argument [54900,54935]
argument [56848,56883]
===
match
---
operator: , [32438,32439]
operator: , [32438,32439]
===
match
---
operator: = [65396,65397]
operator: = [67344,67345]
===
match
---
assert_stmt [67768,67803]
assert_stmt [69716,69751]
===
match
---
argument [56602,56638]
argument [58550,58586]
===
match
---
atom_expr [61099,61115]
atom_expr [63047,63063]
===
match
---
atom_expr [17477,17495]
atom_expr [17477,17495]
===
match
---
name: test_schedule_dag_no_previous_runs [38866,38900]
name: test_schedule_dag_no_previous_runs [38866,38900]
===
match
---
funcdef [3507,3824]
funcdef [3507,3824]
===
match
---
atom_expr [29184,29210]
atom_expr [29184,29210]
===
match
---
atom_expr [36349,36376]
atom_expr [36349,36376]
===
match
---
parameters [19525,19531]
parameters [19525,19531]
===
match
---
trailer [17517,17522]
trailer [17517,17522]
===
match
---
atom_expr [51500,51623]
atom_expr [51500,51623]
===
match
---
name: timezone [20319,20327]
name: timezone [20319,20327]
===
match
---
name: dr [48365,48367]
name: dr [48365,48367]
===
match
---
expr_stmt [5911,5986]
expr_stmt [5911,5986]
===
match
---
trailer [65628,65641]
trailer [67576,67589]
===
match
---
name: session [17658,17665]
name: session [17658,17665]
===
match
---
operator: = [12110,12111]
operator: = [12110,12111]
===
match
---
sync_comp_for [25848,25895]
sync_comp_for [25848,25895]
===
match
---
argument [55508,55518]
argument [57456,57466]
===
match
---
name: remove [9159,9165]
name: remove [9159,9165]
===
match
---
operator: } [25148,25149]
operator: } [25148,25149]
===
match
---
operator: = [49087,49088]
operator: = [49087,49088]
===
match
---
name: settings [33014,33022]
name: settings [33014,33022]
===
match
---
name: start_date [19141,19151]
name: start_date [19141,19151]
===
match
---
name: task_id [60438,60445]
name: task_id [62386,62393]
===
match
---
argument [9704,9715]
argument [9704,9715]
===
match
---
atom_expr [16612,16671]
atom_expr [16612,16671]
===
match
---
atom_expr [17558,17574]
atom_expr [17558,17574]
===
match
---
operator: @ [64089,64090]
operator: @ [66037,66038]
===
match
---
trailer [9748,9761]
trailer [9748,9761]
===
match
---
arglist [52468,52522]
arglist [54416,54470]
===
match
---
expr_stmt [63323,63573]
expr_stmt [65271,65521]
===
match
---
arglist [50104,50154]
arglist [50104,50154]
===
match
---
argument [9659,9670]
argument [9659,9670]
===
match
---
operator: , [43745,43746]
operator: , [43745,43746]
===
match
---
expr_stmt [19861,19896]
expr_stmt [19861,19896]
===
match
---
simple_stmt [63286,63315]
simple_stmt [65234,65263]
===
match
---
operator: = [2541,2542]
operator: = [2541,2542]
===
match
---
name: task_id [36317,36324]
name: task_id [36317,36324]
===
match
---
operator: , [3181,3182]
operator: , [3181,3182]
===
match
---
atom_expr [28869,28886]
atom_expr [28869,28886]
===
match
---
assert_stmt [24931,25205]
assert_stmt [24931,25205]
===
match
---
simple_stmt [21844,21899]
simple_stmt [21844,21899]
===
match
---
name: doc_md [66402,66408]
name: doc_md [68350,68356]
===
match
---
name: schedule_interval [54900,54917]
name: schedule_interval [56848,56865]
===
match
---
name: match [13442,13447]
name: match [13442,13447]
===
match
---
operator: , [59224,59225]
operator: , [61172,61173]
===
match
---
operator: = [55622,55623]
operator: = [57570,57571]
===
match
---
name: op1 [35781,35784]
name: op1 [35781,35784]
===
match
---
atom_expr [26576,26592]
atom_expr [26576,26592]
===
match
---
trailer [39239,39249]
trailer [39239,39249]
===
match
---
import_from [1858,1892]
import_from [1858,1892]
===
match
---
name: next_date [57644,57653]
name: next_date [59592,59601]
===
match
---
arglist [24606,24610]
arglist [24606,24610]
===
match
---
trailer [22142,22160]
trailer [22142,22160]
===
match
---
operator: , [43977,43978]
operator: , [43977,43978]
===
match
---
name: DagModel [62883,62891]
name: DagModel [64831,64839]
===
match
---
with_stmt [6963,7093]
with_stmt [6963,7093]
===
match
---
name: DummyOperator [27546,27559]
name: DummyOperator [27546,27559]
===
match
---
trailer [20377,20451]
trailer [20377,20451]
===
match
---
assert_stmt [41858,41935]
assert_stmt [41858,41935]
===
match
---
string: 'b_parent' [8450,8460]
string: 'b_parent' [8450,8460]
===
match
---
number: 10 [59851,59853]
number: 10 [61799,61801]
===
match
---
simple_stmt [18660,18695]
simple_stmt [18660,18695]
===
match
---
operator: , [39126,39127]
operator: , [39126,39127]
===
match
---
atom_expr [41816,41833]
atom_expr [41816,41833]
===
match
---
string: 'owner1' [8596,8604]
string: 'owner1' [8596,8604]
===
match
---
testlist_comp [25006,25035]
testlist_comp [25006,25035]
===
match
---
name: DummyOperator [9735,9748]
name: DummyOperator [9735,9748]
===
match
---
string: 'owner1' [16534,16542]
string: 'owner1' [16534,16542]
===
match
---
name: dag_id [23707,23713]
name: dag_id [23707,23713]
===
match
---
name: dag_id [65469,65475]
name: dag_id [67417,67423]
===
match
---
name: self [2647,2651]
name: self [2647,2651]
===
match
---
name: DagModel [29116,29124]
name: DagModel [29116,29124]
===
match
---
assert_stmt [43620,43701]
assert_stmt [43620,43701]
===
match
---
comparison [51770,51792]
comparison [53718,53740]
===
match
---
name: next_date [58745,58754]
name: next_date [60693,60702]
===
match
---
simple_stmt [21228,21247]
simple_stmt [21228,21247]
===
match
---
operator: == [41896,41898]
operator: == [41896,41898]
===
match
---
operator: == [29748,29750]
operator: == [29748,29750]
===
match
---
trailer [68621,68625]
trailer [70569,70573]
===
match
---
trailer [55309,55316]
trailer [57257,57264]
===
match
---
atom_expr [47129,47147]
atom_expr [47129,47147]
===
match
---
name: task_id [6937,6944]
name: task_id [6937,6944]
===
match
---
trailer [13500,13506]
trailer [13500,13506]
===
match
---
name: filter [3068,3074]
name: filter [3068,3074]
===
match
---
suite [66665,66785]
suite [68613,68733]
===
match
---
simple_stmt [17288,17371]
simple_stmt [17288,17371]
===
match
---
name: _occur_before [8274,8287]
name: _occur_before [8274,8287]
===
match
---
arith_expr [17204,17245]
arith_expr [17204,17245]
===
match
---
simple_stmt [23697,23747]
simple_stmt [23697,23747]
===
match
---
name: start [21594,21599]
name: start [21594,21599]
===
match
---
operator: = [44334,44335]
operator: = [44334,44335]
===
match
---
string: 'test_rich_comparison_ops' [44149,44175]
string: 'test_rich_comparison_ops' [44149,44175]
===
match
---
string: 'Also fake' [42404,42415]
string: 'Also fake' [42404,42415]
===
match
---
name: timedelta [17228,17237]
name: timedelta [17228,17237]
===
match
---
comparison [49607,49630]
comparison [49607,49630]
===
match
---
operator: = [4784,4785]
operator: = [4784,4785]
===
match
---
arith_expr [53857,53865]
arith_expr [55805,55813]
===
match
---
trailer [31215,31225]
trailer [31215,31225]
===
match
---
trailer [19914,19925]
trailer [19914,19925]
===
match
---
name: schedule_interval [7642,7659]
name: schedule_interval [7642,7659]
===
match
---
trailer [33164,33168]
trailer [33164,33168]
===
match
---
trailer [50103,50155]
trailer [50103,50155]
===
match
---
name: dag_id [34519,34525]
name: dag_id [34519,34525]
===
match
---
operator: , [54692,54693]
operator: , [56640,56641]
===
match
---
operator: = [19282,19283]
operator: = [19282,19283]
===
match
---
name: DummyOperator [35925,35938]
name: DummyOperator [35925,35938]
===
match
---
simple_stmt [37607,37650]
simple_stmt [37607,37650]
===
match
---
name: dag_id [30847,30853]
name: dag_id [30847,30853]
===
match
---
atom_expr [17294,17370]
atom_expr [17294,17370]
===
match
---
trailer [34813,34822]
trailer [34813,34822]
===
match
---
operator: = [2366,2367]
operator: = [2366,2367]
===
match
---
arglist [46806,46867]
arglist [46806,46867]
===
match
---
name: dag2 [6290,6294]
name: dag2 [6290,6294]
===
match
---
expr_stmt [47775,47827]
expr_stmt [47775,47827]
===
match
---
atom_expr [43322,43339]
atom_expr [43322,43339]
===
match
---
name: dag [20610,20613]
name: dag [20610,20613]
===
match
---
trailer [53290,53302]
trailer [55238,55250]
===
match
---
name: session [51500,51507]
name: session [51500,51507]
===
match
---
name: dag [39741,39744]
name: dag [39741,39744]
===
match
---
name: task_id [48770,48777]
name: task_id [48770,48777]
===
match
---
import_from [2009,2046]
import_from [2009,2046]
===
match
---
operator: = [66295,66296]
operator: = [68243,68244]
===
match
---
trailer [23070,23078]
trailer [23070,23078]
===
match
---
trailer [18692,18694]
trailer [18692,18694]
===
match
---
atom_expr [65061,65076]
atom_expr [67009,67024]
===
match
---
atom_expr [38479,38506]
atom_expr [38479,38506]
===
match
---
atom_expr [52825,52964]
atom_expr [54773,54912]
===
match
---
atom_expr [20467,20484]
atom_expr [20467,20484]
===
match
---
simple_stmt [20299,20345]
simple_stmt [20299,20345]
===
match
---
name: range [13026,13031]
name: range [13026,13031]
===
match
---
operator: = [68024,68025]
operator: = [69972,69973]
===
match
---
trailer [3067,3074]
trailer [3067,3074]
===
match
---
atom_expr [38186,38199]
atom_expr [38186,38199]
===
match
---
for_stmt [26429,26486]
for_stmt [26429,26486]
===
match
---
for_stmt [13219,13361]
for_stmt [13219,13361]
===
match
---
name: clear [51209,51214]
name: clear [51209,51214]
===
match
---
operator: @ [30550,30551]
operator: @ [30550,30551]
===
match
---
expr_stmt [12924,13097]
expr_stmt [12924,13097]
===
match
---
trailer [29109,29115]
trailer [29109,29115]
===
match
---
simple_stmt [58236,58281]
simple_stmt [60184,60229]
===
match
---
number: 1 [46669,46670]
number: 1 [46669,46670]
===
match
---
assert_stmt [6235,6263]
assert_stmt [6235,6263]
===
match
---
simple_stmt [30621,30646]
simple_stmt [30621,30646]
===
match
---
atom [42817,42830]
atom [42817,42830]
===
match
---
number: 1 [62419,62420]
number: 1 [64367,64368]
===
match
---
atom_expr [9202,9221]
atom_expr [9202,9221]
===
match
---
name: following_schedule [23981,23999]
name: following_schedule [23981,23999]
===
match
---
name: operators [1680,1689]
name: operators [1680,1689]
===
match
---
trailer [30376,30386]
trailer [30376,30386]
===
match
---
name: DummyOperator [55195,55208]
name: DummyOperator [57143,57156]
===
match
---
suite [18481,18839]
suite [18481,18839]
===
match
---
name: default_args [14079,14091]
name: default_args [14079,14091]
===
match
---
simple_stmt [23229,23265]
simple_stmt [23229,23265]
===
match
---
expr_stmt [3452,3463]
expr_stmt [3452,3463]
===
match
---
name: j [15572,15573]
name: j [15572,15573]
===
match
---
simple_stmt [34541,34570]
simple_stmt [34541,34570]
===
match
---
atom_expr [17170,17246]
atom_expr [17170,17246]
===
match
---
operator: , [44374,44375]
operator: , [44374,44375]
===
match
---
parameters [64208,64227]
parameters [66156,66175]
===
match
---
operator: , [38611,38612]
operator: , [38611,38612]
===
match
---
operator: = [53213,53214]
operator: = [55161,55162]
===
match
---
operator: = [22711,22712]
operator: = [22711,22712]
===
match
---
name: weight [16233,16239]
name: weight [16233,16239]
===
match
---
trailer [60854,60861]
trailer [62802,62809]
===
match
---
trailer [33310,33316]
trailer [33310,33316]
===
match
---
argument [50274,50291]
argument [50274,50291]
===
match
---
atom_expr [32120,32183]
atom_expr [32120,32183]
===
match
---
expr_stmt [31137,31160]
expr_stmt [31137,31160]
===
match
---
name: operator [68233,68241]
name: operator [70181,70189]
===
match
---
assert_stmt [34295,34319]
assert_stmt [34295,34319]
===
match
---
comparison [9288,9316]
comparison [9288,9316]
===
match
---
name: dag [59340,59343]
name: dag [61288,61291]
===
match
---
argument [3005,3030]
argument [3005,3030]
===
match
---
argument [10795,10836]
argument [10795,10836]
===
match
---
atom_expr [68244,68261]
atom_expr [70192,70209]
===
match
---
trailer [29364,29397]
trailer [29364,29397]
===
match
---
simple_stmt [34328,34366]
simple_stmt [34328,34366]
===
match
---
simple_stmt [23005,23041]
simple_stmt [23005,23041]
===
match
---
number: 2019 [61223,61227]
number: 2019 [63171,63175]
===
match
---
operator: = [17389,17390]
operator: = [17389,17390]
===
match
---
operator: = [35350,35351]
operator: = [35350,35351]
===
match
---
assert_stmt [4444,4480]
assert_stmt [4444,4480]
===
match
---
trailer [17888,17911]
trailer [17888,17911]
===
match
---
testlist_comp [32330,32347]
testlist_comp [32330,32347]
===
match
---
name: operator [67330,67338]
name: operator [69278,69286]
===
match
---
name: datetime [12003,12011]
name: datetime [12003,12011]
===
match
---
expr_stmt [62870,62927]
expr_stmt [64818,64875]
===
match
---
funcdef [64179,64624]
funcdef [66127,66572]
===
match
---
simple_stmt [66391,66446]
simple_stmt [68339,68394]
===
match
---
name: sync_to_db [24227,24237]
name: sync_to_db [24227,24237]
===
match
---
name: next_date [55798,55807]
name: next_date [57746,57755]
===
match
---
arglist [50384,50410]
arglist [50384,50410]
===
match
---
name: date [54229,54233]
name: date [56177,56181]
===
match
---
name: int [13491,13494]
name: int [13491,13494]
===
match
---
expr_stmt [43309,43339]
expr_stmt [43309,43339]
===
match
---
simple_stmt [14589,14598]
simple_stmt [14589,14598]
===
match
---
trailer [62358,62425]
trailer [64306,64373]
===
match
---
expr_stmt [58348,58397]
expr_stmt [60296,60345]
===
match
---
suite [60743,60923]
suite [62691,62871]
===
match
---
name: timezone [2066,2074]
name: timezone [2066,2074]
===
match
---
assert_stmt [23095,23155]
assert_stmt [23095,23155]
===
match
---
name: PRE_TRANSITION [20436,20450]
name: PRE_TRANSITION [20436,20450]
===
match
---
operator: = [5258,5259]
operator: = [5258,5259]
===
match
---
operator: = [20040,20041]
operator: = [20040,20041]
===
match
---
argument [48762,48777]
argument [48762,48777]
===
match
---
operator: = [28615,28616]
operator: = [28615,28616]
===
match
---
name: task_id [35504,35511]
name: task_id [35504,35511]
===
match
---
operator: , [56203,56204]
operator: , [58151,58152]
===
match
---
string: "t2" [36325,36329]
string: "t2" [36325,36329]
===
match
---
name: DAG [9458,9461]
name: DAG [9458,9461]
===
match
---
comparison [61192,61240]
comparison [63140,63188]
===
match
---
atom_expr [3361,3370]
atom_expr [3361,3370]
===
match
---
argument [31012,31025]
argument [31012,31025]
===
match
---
name: set_upstream [9974,9986]
name: set_upstream [9974,9986]
===
match
---
name: DummyOperator [12954,12967]
name: DummyOperator [12954,12967]
===
match
---
number: 2015 [2380,2384]
number: 2015 [2380,2384]
===
match
---
name: dag [8718,8721]
name: dag [8718,8721]
===
match
---
operator: , [37584,37585]
operator: , [37584,37585]
===
match
---
simple_stmt [58738,58788]
simple_stmt [60686,60736]
===
match
---
name: dagrun [49768,49774]
name: dagrun [49768,49774]
===
match
---
simple_stmt [30979,31027]
simple_stmt [30979,31027]
===
match
---
expr_stmt [48834,49029]
expr_stmt [48834,49029]
===
match
---
argument [30075,30092]
argument [30075,30092]
===
match
---
trailer [14836,14842]
trailer [14836,14842]
===
match
---
string: '.template' [20043,20054]
string: '.template' [20043,20054]
===
match
---
name: task_id [38139,38146]
name: task_id [38139,38146]
===
match
---
trailer [12437,12446]
trailer [12437,12446]
===
match
---
name: parent_dag [8045,8055]
name: parent_dag [8045,8055]
===
match
---
string: "2015-01-02T01:00:00+00:00" [23932,23959]
string: "2015-01-02T01:00:00+00:00" [23932,23959]
===
match
---
simple_stmt [17130,17156]
simple_stmt [17130,17156]
===
match
---
argument [8800,8811]
argument [8800,8811]
===
match
---
operator: == [37210,37212]
operator: == [37210,37212]
===
match
---
operator: == [34516,34518]
operator: == [34516,34518]
===
match
---
name: merge [51109,51114]
name: merge [51109,51114]
===
match
---
comparison [6415,6430]
comparison [6415,6430]
===
match
---
name: xcom_arg [68244,68252]
name: xcom_arg [70192,70200]
===
match
---
operator: = [41173,41174]
operator: = [41173,41174]
===
match
---
trailer [29579,29585]
trailer [29579,29585]
===
match
---
name: tasks [9225,9230]
name: tasks [9225,9230]
===
match
---
name: DummyOperator [7499,7512]
name: DummyOperator [7499,7512]
===
match
---
string: 'test-dag' [25967,25977]
string: 'test-dag' [25967,25977]
===
match
---
trailer [27119,27146]
trailer [27119,27146]
===
match
---
name: self [38300,38304]
name: self [38300,38304]
===
match
---
assert_stmt [6678,6706]
assert_stmt [6678,6706]
===
match
---
trailer [64081,64083]
trailer [66029,66031]
===
match
---
comparison [11809,11885]
comparison [11809,11885]
===
match
---
assert_stmt [10290,10324]
assert_stmt [10290,10324]
===
match
---
trailer [28169,28186]
trailer [28169,28186]
===
match
---
atom_expr [25230,25276]
atom_expr [25230,25276]
===
match
---
trailer [17351,17361]
trailer [17351,17361]
===
match
---
atom_expr [8831,8857]
atom_expr [8831,8857]
===
match
---
argument [56516,56549]
argument [58464,58497]
===
match
---
name: RUNNING [51785,51792]
name: RUNNING [53733,53740]
===
match
---
parameters [63060,63066]
parameters [65008,65014]
===
match
---
string: 'dag-bulk-sync-0' [26829,26846]
string: 'dag-bulk-sync-0' [26829,26846]
===
match
---
operator: = [17242,17243]
operator: = [17242,17243]
===
match
---
atom_expr [39189,39331]
atom_expr [39189,39331]
===
match
---
sync_comp_for [13059,13083]
sync_comp_for [13059,13083]
===
match
---
name: match [14821,14826]
name: match [14821,14826]
===
match
---
simple_stmt [23606,23649]
simple_stmt [23606,23649]
===
match
---
trailer [63843,63847]
trailer [65791,65795]
===
match
---
trailer [9867,9882]
trailer [9867,9882]
===
match
---
simple_stmt [68338,68353]
simple_stmt [70286,70301]
===
match
---
operator: = [23713,23714]
operator: = [23713,23714]
===
match
---
name: one [51618,51621]
name: one [51618,51621]
===
match
---
trailer [51507,51513]
trailer [51507,51513]
===
match
---
assert_stmt [22221,22281]
assert_stmt [22221,22281]
===
match
---
name: dag_id [53946,53952]
name: dag_id [55894,55900]
===
match
---
name: session [30335,30342]
name: session [30335,30342]
===
match
---
name: states [18062,18068]
name: states [18062,18068]
===
match
---
operator: = [60483,60484]
operator: = [62431,62432]
===
match
---
name: task_id [7513,7520]
name: task_id [7513,7520]
===
match
---
operator: , [52394,52395]
operator: , [54342,54343]
===
match
---
operator: , [25134,25135]
operator: , [25134,25135]
===
match
---
number: 5 [58567,58568]
number: 5 [60515,60516]
===
match
---
atom_expr [38135,38146]
atom_expr [38135,38146]
===
match
---
with_stmt [30746,30838]
with_stmt [30746,30838]
===
match
---
atom_expr [23755,23844]
atom_expr [23755,23844]
===
match
---
operator: = [37556,37557]
operator: = [37556,37557]
===
match
---
name: now [55483,55486]
name: now [57431,57434]
===
match
---
atom_expr [50673,50860]
atom_expr [50673,50860]
===
match
---
name: write [18962,18967]
name: write [18962,18967]
===
match
---
simple_stmt [20022,20057]
simple_stmt [20022,20057]
===
match
---
operator: = [55428,55429]
operator: = [57376,57377]
===
match
---
operator: = [59572,59573]
operator: = [61520,61521]
===
match
---
simple_stmt [9729,9762]
simple_stmt [9729,9762]
===
match
---
string: """         Test invalid `default_view` of DAG initialization         """ [4535,4608]
string: """         Test invalid `default_view` of DAG initialization         """ [4535,4608]
===
match
---
string: 't2' [36651,36655]
string: 't2' [36651,36655]
===
match
---
lambdef [40281,40290]
lambdef [40281,40290]
===
match
---
name: get_num_task_instances [17784,17806]
name: get_num_task_instances [17784,17806]
===
match
---
name: microsecond [55432,55443]
name: microsecond [57380,57391]
===
match
---
string: 'start_date' [11748,11760]
string: 'start_date' [11748,11760]
===
match
---
comparison [45043,45068]
comparison [45043,45068]
===
match
---
name: parent_dag [7798,7808]
name: parent_dag [7798,7808]
===
match
---
simple_stmt [33303,33319]
simple_stmt [33303,33319]
===
match
---
atom [36011,36021]
atom [36011,36021]
===
match
---
atom [31600,31672]
atom [31600,31672]
===
match
---
trailer [32228,32234]
trailer [32228,32234]
===
match
---
argument [63548,63562]
argument [65496,65510]
===
match
---
name: start_date [62384,62394]
name: start_date [64332,64342]
===
match
---
operator: == [26701,26703]
operator: == [26701,26703]
===
match
---
argument [59345,59360]
argument [61293,61308]
===
match
---
trailer [24718,24720]
trailer [24718,24720]
===
match
---
number: 2018 [20396,20400]
number: 2018 [20396,20400]
===
match
---
operator: = [42544,42545]
operator: = [42544,42545]
===
match
---
atom_expr [67673,67690]
atom_expr [69621,69638]
===
match
---
operator: = [11953,11954]
operator: = [11953,11954]
===
match
---
name: op2 [6279,6282]
name: op2 [6279,6282]
===
match
---
name: execution_date [52473,52487]
name: execution_date [54421,54435]
===
match
---
name: dag_id [63167,63173]
name: dag_id [65115,65121]
===
match
---
name: value [68209,68214]
name: value [70157,70162]
===
match
---
trailer [21493,21502]
trailer [21493,21502]
===
match
---
expr_stmt [61711,61906]
expr_stmt [63659,63854]
===
match
---
trailer [58119,58128]
trailer [60067,60076]
===
match
---
operator: == [24040,24042]
operator: == [24040,24042]
===
match
---
string: 'dag-bulk-sync-0' [25948,25965]
string: 'dag-bulk-sync-0' [25948,25965]
===
match
---
name: dag [67403,67406]
name: dag [69351,69354]
===
match
---
expr_stmt [34212,34285]
expr_stmt [34212,34285]
===
match
---
simple_stmt [38064,38075]
simple_stmt [38064,38075]
===
match
---
trailer [21538,21553]
trailer [21538,21553]
===
match
---
atom_expr [52220,52405]
atom_expr [54168,54353]
===
match
---
trailer [26747,26753]
trailer [26747,26753]
===
match
---
trailer [21434,21451]
trailer [21434,21451]
===
match
---
atom_expr [41865,41895]
atom_expr [41865,41895]
===
match
---
operator: = [67526,67527]
operator: = [69474,69475]
===
match
---
comparison [49691,49708]
comparison [49691,49708]
===
match
---
operator: , [18213,18214]
operator: , [18213,18214]
===
match
---
simple_stmt [33869,33930]
simple_stmt [33869,33930]
===
match
---
operator: , [60325,60326]
operator: , [62273,62274]
===
match
---
expr_stmt [64673,64861]
expr_stmt [66621,66809]
===
match
---
atom_expr [24868,24904]
atom_expr [24868,24904]
===
match
---
operator: { [39617,39618]
operator: { [39617,39618]
===
match
---
operator: , [58448,58449]
operator: , [60396,60397]
===
match
---
operator: , [59842,59843]
operator: , [61790,61791]
===
match
---
name: following_schedule [21920,21938]
name: following_schedule [21920,21938]
===
match
---
trailer [39433,39440]
trailer [39433,39440]
===
match
---
name: dagrun [49717,49723]
name: dagrun [49717,49723]
===
match
---
simple_stmt [21908,21944]
simple_stmt [21908,21944]
===
match
---
suite [16411,16672]
suite [16411,16672]
===
match
---
simple_stmt [68732,68765]
simple_stmt [70680,70713]
===
match
---
name: len [49691,49694]
name: len [49691,49694]
===
match
---
string: "test_get_paused_dag_ids" [45899,45924]
string: "test_get_paused_dag_ids" [45899,45924]
===
match
---
funcdef [66706,66754]
funcdef [68654,68702]
===
match
---
name: task_id [38401,38408]
name: task_id [38401,38408]
===
match
---
simple_stmt [18523,18546]
simple_stmt [18523,18546]
===
match
---
name: NONE [47893,47897]
name: NONE [47893,47897]
===
match
---
name: test_params_not_passed_is_empty_dict [3511,3547]
name: test_params_not_passed_is_empty_dict [3511,3547]
===
match
---
operator: >> [38045,38047]
operator: >> [38045,38047]
===
match
---
string: "@daily" [46393,46401]
string: "@daily" [46393,46401]
===
match
---
name: redirect_stdout [902,917]
name: redirect_stdout [902,917]
===
match
---
name: model [41865,41870]
name: model [41865,41870]
===
match
---
operator: { [61522,61523]
operator: { [63470,63471]
===
match
---
name: _next [20786,20791]
name: _next [20786,20791]
===
match
---
argument [60299,60325]
argument [62247,62273]
===
match
---
name: dag [32635,32638]
name: dag [32635,32638]
===
match
---
operator: = [39157,39158]
operator: = [39157,39158]
===
match
---
simple_stmt [47641,47699]
simple_stmt [47641,47699]
===
match
---
assert_stmt [53520,53544]
assert_stmt [55468,55492]
===
match
---
argument [36271,36283]
argument [36271,36283]
===
match
---
simple_stmt [19910,19959]
simple_stmt [19910,19959]
===
match
---
expr_stmt [37046,37079]
expr_stmt [37046,37079]
===
match
---
name: merge [50877,50882]
name: merge [50877,50882]
===
match
---
operator: = [15471,15472]
operator: = [15471,15472]
===
match
---
trailer [39765,39775]
trailer [39765,39775]
===
match
---
suite [67855,68765]
suite [69803,70713]
===
match
---
name: prev_task [13350,13359]
name: prev_task [13350,13359]
===
match
---
trailer [67677,67690]
trailer [69625,69638]
===
match
---
operator: , [52680,52681]
operator: , [54628,54629]
===
match
---
atom_expr [25413,25439]
atom_expr [25413,25439]
===
match
---
operator: , [59849,59850]
operator: , [61797,61798]
===
match
---
name: utc [22661,22664]
name: utc [22661,22664]
===
match
---
atom_expr [27513,27532]
atom_expr [27513,27532]
===
match
---
operator: = [21693,21694]
operator: = [21693,21694]
===
match
---
arglist [43966,43996]
arglist [43966,43996]
===
match
---
simple_stmt [32841,32872]
simple_stmt [32841,32872]
===
match
---
trailer [3051,3057]
trailer [3051,3057]
===
match
---
trailer [43807,43815]
trailer [43807,43815]
===
match
---
operator: , [52744,52745]
operator: , [54692,54693]
===
match
---
simple_stmt [26617,26791]
simple_stmt [26617,26791]
===
match
---
simple_stmt [42221,42246]
simple_stmt [42221,42246]
===
match
---
operator: { [64383,64384]
operator: { [66331,66332]
===
match
---
name: test_dag_naive_default_args_start_date_with_timezone [34726,34778]
name: test_dag_naive_default_args_start_date_with_timezone [34726,34778]
===
match
---
operator: , [7373,7374]
operator: , [7373,7374]
===
match
---
number: 0 [10177,10178]
number: 0 [10177,10178]
===
match
---
trailer [3108,3135]
trailer [3108,3135]
===
match
---
trailer [4956,4960]
trailer [4956,4960]
===
match
---
trailer [61213,61222]
trailer [63161,63170]
===
match
---
operator: = [47127,47128]
operator: = [47127,47128]
===
match
---
name: basename [19090,19098]
name: basename [19090,19098]
===
match
---
atom_expr [65398,65413]
atom_expr [67346,67361]
===
match
---
name: datetime [34887,34895]
name: datetime [34887,34895]
===
match
---
trailer [26389,26393]
trailer [26389,26393]
===
match
---
name: mock_callback_with_exception [40324,40352]
name: mock_callback_with_exception [40324,40352]
===
match
---
atom_expr [48305,48315]
atom_expr [48305,48315]
===
match
---
trailer [40524,40532]
trailer [40524,40532]
===
match
---
argument [49323,49329]
argument [49323,49329]
===
match
---
trailer [64361,64411]
trailer [66309,66359]
===
match
---
dotted_name [1863,1876]
dotted_name [1863,1876]
===
match
---
name: DAG [12352,12355]
name: DAG [12352,12355]
===
match
---
name: depth [13612,13617]
name: depth [13612,13617]
===
match
---
name: DEFAULT_DATE [29897,29909]
name: DEFAULT_DATE [29897,29909]
===
match
---
operator: = [55226,55227]
operator: = [57174,57175]
===
match
---
name: dag_id [38993,38999]
name: dag_id [38993,38999]
===
match
---
name: dag [50094,50097]
name: dag [50094,50097]
===
match
---
expr_stmt [49493,49674]
expr_stmt [49493,49674]
===
match
---
argument [68529,68548]
argument [70477,70496]
===
match
---
parameters [27242,27248]
parameters [27242,27248]
===
match
---
trailer [16827,16872]
trailer [16827,16872]
===
match
---
atom_expr [12041,12053]
atom_expr [12041,12053]
===
match
---
name: dag [32933,32936]
name: dag [32933,32936]
===
match
---
name: task_id [35893,35900]
name: task_id [35893,35900]
===
match
---
name: models [1250,1256]
name: models [1250,1256]
===
match
---
expr_stmt [60756,60922]
expr_stmt [62704,62870]
===
match
---
operator: , [63372,63373]
operator: , [65320,65321]
===
match
---
trailer [10268,10275]
trailer [10268,10275]
===
match
---
atom_expr [30489,30509]
atom_expr [30489,30509]
===
match
---
operator: = [64879,64880]
operator: = [66827,66828]
===
match
---
comparison [3479,3501]
comparison [3479,3501]
===
match
---
assert_stmt [56441,56477]
assert_stmt [58389,58425]
===
match
---
string: 'task_1' [16795,16803]
string: 'task_1' [16795,16803]
===
match
---
trailer [9973,9986]
trailer [9973,9986]
===
match
---
trailer [45725,45733]
trailer [45725,45733]
===
match
---
string: 'a_child' [7521,7530]
string: 'a_child' [7521,7530]
===
match
---
name: session [17956,17963]
name: session [17956,17963]
===
match
---
param [65727,65730]
param [67675,67678]
===
match
---
trailer [19084,19089]
trailer [19084,19089]
===
match
---
atom [49834,49902]
atom [49834,49902]
===
match
---
atom [26194,26226]
atom [26194,26226]
===
match
---
name: dag [55227,55230]
name: dag [57175,57178]
===
match
---
simple_stmt [51140,51171]
simple_stmt [51140,51171]
===
match
---
operator: = [53841,53842]
operator: = [55789,55790]
===
match
---
name: test_task_id [16915,16927]
name: test_task_id [16915,16927]
===
match
---
operator: , [59658,59659]
operator: , [61606,61607]
===
match
---
simple_stmt [13987,14030]
simple_stmt [13987,14030]
===
match
---
name: dag [52031,52034]
name: dag [53979,53982]
===
match
---
atom_expr [22074,22091]
atom_expr [22074,22091]
===
match
---
funcdef [67809,68765]
funcdef [69757,70713]
===
match
---
atom_expr [26740,26776]
atom_expr [26740,26776]
===
match
---
name: op1 [8735,8738]
name: op1 [8735,8738]
===
match
---
name: b_index [3452,3459]
name: b_index [3452,3459]
===
match
---
name: all [24899,24902]
name: all [24899,24902]
===
match
---
atom_expr [67610,67623]
atom_expr [69558,69571]
===
match
---
operator: } [64860,64861]
operator: } [66808,66809]
===
match
---
operator: , [61895,61896]
operator: , [63843,63844]
===
match
---
trailer [37885,37922]
trailer [37885,37922]
===
match
---
operator: = [60843,60844]
operator: = [62791,62792]
===
match
---
trailer [24898,24902]
trailer [24898,24902]
===
match
---
name: pendulum [22627,22635]
name: pendulum [22627,22635]
===
match
---
operator: == [10531,10533]
operator: == [10531,10533]
===
match
---
arglist [29999,30029]
arglist [29999,30029]
===
match
---
name: test_dag_id [17623,17634]
name: test_dag_id [17623,17634]
===
match
---
name: datetime [59211,59219]
name: datetime [61159,61167]
===
match
---
name: dag_id [66368,66374]
name: dag_id [68316,68322]
===
match
---
operator: , [41180,41181]
operator: , [41180,41181]
===
match
---
name: owner [6689,6694]
name: owner [6689,6694]
===
match
---
assert_stmt [21775,21835]
assert_stmt [21775,21835]
===
match
---
trailer [32652,32654]
trailer [32652,32654]
===
match
---
operator: = [62394,62395]
operator: = [64342,64343]
===
match
---
trailer [20395,20416]
trailer [20395,20416]
===
match
---
name: timedelta [17352,17361]
name: timedelta [17352,17361]
===
match
---
name: task_id [6384,6391]
name: task_id [6384,6391]
===
match
---
trailer [26519,26522]
trailer [26519,26522]
===
match
---
name: DEFAULT_ARGS [67122,67134]
name: DEFAULT_ARGS [69070,69082]
===
match
---
trailer [4731,4735]
trailer [4731,4735]
===
match
---
operator: = [5938,5939]
operator: = [5938,5939]
===
match
---
simple_stmt [6648,6670]
simple_stmt [6648,6670]
===
match
---
number: 1 [14691,14692]
number: 1 [14691,14692]
===
match
---
operator: = [56026,56027]
operator: = [57974,57975]
===
match
---
atom_expr [40501,40567]
atom_expr [40501,40567]
===
match
---
operator: , [59466,59467]
operator: , [61414,61415]
===
match
---
operator: == [18129,18131]
operator: == [18129,18131]
===
match
---
argument [55569,55576]
argument [57517,57524]
===
match
---
suite [68983,69195]
suite [70931,71143]
===
match
---
name: security [1830,1838]
name: security [1830,1838]
===
match
---
trailer [68383,68598]
trailer [70331,70546]
===
match
---
argument [42567,42591]
argument [42567,42591]
===
match
---
atom_expr [49155,49185]
atom_expr [49155,49185]
===
match
---
name: dag2 [5995,5999]
name: dag2 [5995,5999]
===
match
---
simple_stmt [32664,32718]
simple_stmt [32664,32718]
===
match
---
trailer [57739,57748]
trailer [59687,59696]
===
match
---
number: 0 [25305,25306]
number: 0 [25305,25306]
===
match
---
atom_expr [51977,51999]
atom_expr [53925,53947]
===
match
---
trailer [49530,49569]
trailer [49530,49569]
===
match
---
name: dag_id [34674,34680]
name: dag_id [34674,34680]
===
match
---
string: """         Test that when 'params' exists as a key passed to the default_args dict         in addition to params being passed explicitly as an argument to the         dag, that the 'params' key of the default_args dict is merged with the         dict of the params argument.         """ [3906,4193]
string: """         Test that when 'params' exists as a key passed to the default_args dict         in addition to params being passed explicitly as an argument to the         dag, that the 'params' key of the default_args dict is merged with the         dict of the params argument.         """ [3906,4193]
===
match
---
simple_stmt [6151,6196]
simple_stmt [6151,6196]
===
match
---
expr_stmt [36297,36330]
expr_stmt [36297,36330]
===
match
---
operator: , [40644,40645]
operator: , [40644,40645]
===
match
---
arglist [32674,32716]
arglist [32674,32716]
===
match
---
name: DAG [43143,43146]
name: DAG [43143,43146]
===
match
---
name: op2 [7874,7877]
name: op2 [7874,7877]
===
match
---
name: topological_list [8387,8403]
name: topological_list [8387,8403]
===
match
---
param [18882,18886]
param [18882,18886]
===
match
---
param [24097,24101]
param [24097,24101]
===
match
---
atom_expr [29356,29405]
atom_expr [29356,29405]
===
match
---
operator: = [27490,27491]
operator: = [27490,27491]
===
match
---
param [67164,67180]
param [69112,69128]
===
match
---
expr_stmt [59371,59415]
expr_stmt [61319,61363]
===
match
---
name: next_subdag_date [61320,61336]
name: next_subdag_date [63268,63284]
===
match
---
assert_stmt [24745,24918]
assert_stmt [24745,24918]
===
match
---
atom_expr [42710,42726]
atom_expr [42710,42726]
===
match
---
fstring_expr [14242,14245]
fstring_expr [14242,14245]
===
match
---
argument [29066,29081]
argument [29066,29081]
===
match
---
name: AirflowException [5235,5251]
name: AirflowException [5235,5251]
===
match
---
name: local_tz [35015,35023]
name: local_tz [35015,35023]
===
match
---
suite [2839,3136]
suite [2839,3136]
===
match
---
operator: , [59613,59614]
operator: , [61561,61562]
===
match
---
funcdef [65712,65760]
funcdef [67660,67708]
===
match
---
atom [25005,25036]
atom [25005,25036]
===
match
---
argument [37572,37584]
argument [37572,37584]
===
match
---
name: task_id [37218,37225]
name: task_id [37218,37225]
===
match
---
name: commit [17566,17572]
name: commit [17566,17572]
===
match
---
with_stmt [18898,19438]
with_stmt [18898,19438]
===
match
---
simple_stmt [38647,38720]
simple_stmt [38647,38720]
===
match
---
fstring_string: . [15570,15571]
fstring_string: . [15570,15571]
===
match
---
atom_expr [47648,47657]
atom_expr [47648,47657]
===
match
---
trailer [68718,68720]
trailer [70666,70668]
===
match
---
trailer [34530,34532]
trailer [34530,34532]
===
match
---
trailer [63003,63009]
trailer [64951,64957]
===
match
---
trailer [18135,18158]
trailer [18135,18158]
===
match
---
name: topological_list [10160,10176]
name: topological_list [10160,10176]
===
match
---
atom [17636,17648]
atom [17636,17648]
===
match
---
operator: , [31653,31654]
operator: , [31653,31654]
===
match
---
operator: = [20614,20615]
operator: = [20614,20615]
===
match
---
operator: { [24752,24753]
operator: { [24752,24753]
===
match
---
name: permissions [61786,61797]
name: permissions [63734,63745]
===
match
---
operator: = [29935,29936]
operator: = [29935,29936]
===
match
---
name: task_id [23781,23788]
name: task_id [23781,23788]
===
match
---
name: timezone [57683,57691]
name: timezone [59631,59639]
===
match
---
arith_expr [13611,13649]
arith_expr [13611,13649]
===
match
---
operator: , [8145,8146]
operator: , [8145,8146]
===
match
---
string: """         Tests if a start_date of None in default_args         works.         """ [12253,12337]
string: """         Tests if a start_date of None in default_args         works.         """ [12253,12337]
===
match
---
trailer [23345,23347]
trailer [23345,23347]
===
match
---
name: settings [2556,2564]
name: settings [2556,2564]
===
match
---
operator: = [48021,48022]
operator: = [48021,48022]
===
match
---
operator: = [62881,62882]
operator: = [64829,64830]
===
match
---
trailer [7147,7151]
trailer [7147,7151]
===
match
---
operator: == [3371,3373]
operator: == [3371,3373]
===
match
---
string: 'test-dag2' [26848,26859]
string: 'test-dag2' [26848,26859]
===
match
---
name: session [49517,49524]
name: session [49517,49524]
===
match
---
trailer [62579,62586]
trailer [64527,64534]
===
match
---
suite [41589,41653]
suite [41589,41653]
===
match
---
param [51905,51932]
param [53853,53880]
===
match
---
arglist [62757,62767]
arglist [64705,64715]
===
match
---
trailer [27638,27640]
trailer [27638,27640]
===
match
---
atom_expr [49849,49859]
atom_expr [49849,49859]
===
match
---
trailer [8197,8211]
trailer [8197,8211]
===
match
---
name: end_date [52694,52702]
name: end_date [54642,54650]
===
match
---
name: fileloc [29740,29747]
name: fileloc [29740,29747]
===
match
---
string: 'parameter2' [4249,4261]
string: 'parameter2' [4249,4261]
===
match
---
trailer [11593,11715]
trailer [11593,11715]
===
match
---
operator: = [5380,5381]
operator: = [5380,5381]
===
match
---
name: dag_id [2980,2986]
name: dag_id [2980,2986]
===
match
---
string: 'webserver' [33722,33733]
string: 'webserver' [33722,33733]
===
match
---
operator: , [22725,22726]
operator: , [22725,22726]
===
match
---
name: dag_eq [45726,45732]
name: dag_eq [45726,45732]
===
match
---
name: owner [28624,28629]
name: owner [28624,28629]
===
match
---
import_as_name [1498,1516]
import_as_name [1498,1516]
===
match
---
simple_stmt [29244,29269]
simple_stmt [29244,29269]
===
match
---
string: 'value' [68568,68575]
string: 'value' [70516,70523]
===
match
---
funcdef [18445,18839]
funcdef [18445,18839]
===
match
---
name: value [66778,66783]
name: value [68726,68731]
===
match
---
name: depth [14472,14477]
name: depth [14472,14477]
===
match
---
trailer [42257,42275]
trailer [42257,42275]
===
match
---
name: minute [55412,55418]
name: minute [57360,57366]
===
match
---
simple_stmt [64011,64027]
simple_stmt [65959,65975]
===
match
---
name: test_task_id [18331,18343]
name: test_task_id [18331,18343]
===
match
---
name: unittest [1022,1030]
name: unittest [1022,1030]
===
match
---
atom_expr [61523,61550]
atom_expr [63471,63498]
===
match
---
trailer [2484,2486]
trailer [2484,2486]
===
match
---
name: next_date [57605,57614]
name: next_date [59553,59562]
===
match
---
trailer [52886,52893]
trailer [54834,54841]
===
match
---
name: DagModel [30394,30402]
name: DagModel [30394,30402]
===
match
---
name: DAG [4288,4291]
name: DAG [4288,4291]
===
match
---
trailer [41642,41649]
trailer [41642,41649]
===
match
---
operator: * [13651,13652]
operator: * [13651,13652]
===
match
---
name: BACKFILL_JOB [48896,48908]
name: BACKFILL_JOB [48896,48908]
===
match
---
operator: = [20665,20666]
operator: = [20665,20666]
===
match
---
name: timedelta [64834,64843]
name: timedelta [66782,66791]
===
match
---
operator: , [47584,47585]
operator: , [47584,47585]
===
match
---
operator: = [7152,7153]
operator: = [7152,7153]
===
match
---
comparison [18711,18739]
comparison [18711,18739]
===
match
---
name: DEFAULT_DATE [68642,68654]
name: DEFAULT_DATE [70590,70602]
===
match
---
testlist_comp [64153,64156]
testlist_comp [66101,66104]
===
match
---
suite [19591,20099]
suite [19591,20099]
===
match
---
operator: = [19331,19332]
operator: = [19331,19332]
===
match
---
atom_expr [63805,63849]
atom_expr [65753,65797]
===
match
---
trailer [68252,68261]
trailer [70200,70209]
===
match
---
parameters [32551,32557]
parameters [32551,32557]
===
match
---
trailer [63624,63626]
trailer [65572,65574]
===
match
---
expr_stmt [36343,36376]
expr_stmt [36343,36376]
===
match
---
atom_expr [7828,7861]
atom_expr [7828,7861]
===
match
---
atom_expr [63163,63211]
atom_expr [65111,65159]
===
match
---
expr_stmt [19971,20009]
expr_stmt [19971,20009]
===
match
---
atom_expr [68665,68682]
atom_expr [70613,70630]
===
match
---
trailer [62168,62183]
trailer [64116,64131]
===
match
---
operator: == [14563,14565]
operator: == [14563,14565]
===
match
---
atom_expr [48022,48032]
atom_expr [48022,48032]
===
match
---
import_from [2106,2148]
import_from [2106,2148]
===
match
---
arglist [52121,52145]
arglist [54069,54093]
===
match
---
operator: = [34071,34072]
operator: = [34071,34072]
===
match
---
trailer [50726,50739]
trailer [50726,50739]
===
match
---
operator: = [13995,13996]
operator: = [13995,13996]
===
match
---
arglist [5334,5390]
arglist [5334,5390]
===
match
---
atom [46506,46535]
atom [46506,46535]
===
match
---
trailer [10422,10429]
trailer [10422,10429]
===
match
---
name: owner [6726,6731]
name: owner [6726,6731]
===
match
---
atom_expr [25301,25307]
atom_expr [25301,25307]
===
match
---
name: i [47161,47162]
name: i [47161,47162]
===
match
---
operator: = [62685,62686]
operator: = [64633,64634]
===
match
---
name: timezone [12417,12425]
name: timezone [12417,12425]
===
match
---
name: values [14795,14801]
name: values [14795,14801]
===
match
---
name: DAG [35239,35242]
name: DAG [35239,35242]
===
match
---
argument [37424,37478]
argument [37424,37478]
===
match
---
operator: = [50403,50404]
operator: = [50403,50404]
===
match
---
argument [65207,65237]
argument [67155,67185]
===
match
---
expr_stmt [23657,23688]
expr_stmt [23657,23688]
===
match
---
operator: = [40430,40431]
operator: = [40430,40431]
===
match
---
trailer [20762,20769]
trailer [20762,20769]
===
match
---
simple_stmt [33270,33295]
simple_stmt [33270,33295]
===
match
---
trailer [67329,67338]
trailer [69277,69286]
===
match
---
funcdef [47429,47699]
funcdef [47429,47699]
===
match
---
suite [63973,64624]
suite [65921,66572]
===
match
---
operator: , [59595,59596]
operator: , [61543,61544]
===
match
---
operator: = [16956,16957]
operator: = [16956,16957]
===
match
---
string: 'start_date' [60877,60889]
string: 'start_date' [62825,62837]
===
match
---
assert_stmt [45000,45027]
assert_stmt [45000,45027]
===
match
---
arglist [55154,55175]
arglist [57102,57123]
===
match
---
name: strip [66409,66414]
name: strip [68357,68362]
===
match
---
simple_stmt [56441,56478]
simple_stmt [58389,58426]
===
match
---
string: 'hello' [18773,18780]
string: 'hello' [18773,18780]
===
match
---
name: re [12572,12574]
name: re [12572,12574]
===
match
---
name: run_id [68397,68403]
name: run_id [70345,70351]
===
match
---
fstring_expr [47671,47697]
fstring_expr [47671,47697]
===
match
---
with_stmt [30957,31027]
with_stmt [30957,31027]
===
match
---
string: 'DAG' [35048,35053]
string: 'DAG' [35048,35053]
===
match
---
name: dag [35038,35041]
name: dag [35038,35041]
===
match
---
arglist [31425,31460]
arglist [31425,31460]
===
match
---
expr_stmt [37096,37152]
expr_stmt [37096,37152]
===
match
---
number: 5 [57710,57711]
number: 5 [59658,59659]
===
match
---
name: subdag [28998,29004]
name: subdag [28998,29004]
===
match
---
argument [63386,63419]
argument [65334,65367]
===
match
---
atom_expr [44019,44031]
atom_expr [44019,44031]
===
match
---
string: '' [39468,39470]
string: '' [39468,39470]
===
match
---
name: subdag [50218,50224]
name: subdag [50218,50224]
===
match
---
name: DagTag [26377,26383]
name: DagTag [26377,26383]
===
match
---
name: session [30603,30610]
name: session [30603,30610]
===
match
---
name: value [67306,67311]
name: value [69254,69259]
===
match
---
string: 'dag-bulk-sync-3' [25104,25121]
string: 'dag-bulk-sync-3' [25104,25121]
===
match
---
assert_stmt [33632,33667]
assert_stmt [33632,33667]
===
match
---
import_from [2047,2105]
import_from [2047,2105]
===
match
---
simple_stmt [61099,61123]
simple_stmt [63047,63071]
===
match
---
name: task_id [52121,52128]
name: task_id [54069,54076]
===
match
---
name: session [1962,1969]
name: session [1962,1969]
===
match
---
number: 5 [24648,24649]
number: 5 [24648,24649]
===
match
---
simple_stmt [25736,25910]
simple_stmt [25736,25910]
===
match
---
name: compile [12575,12582]
name: compile [12575,12582]
===
match
---
trailer [18961,18967]
trailer [18961,18967]
===
match
---
operator: , [49124,49125]
operator: , [49124,49125]
===
match
---
trailer [68669,68682]
trailer [70617,70630]
===
match
---
name: SubDagOperator [50301,50315]
name: SubDagOperator [50301,50315]
===
match
---
trailer [14342,14351]
trailer [14342,14351]
===
match
---
arglist [28510,28553]
arglist [28510,28553]
===
match
---
name: setUp [63982,63987]
name: setUp [65930,65935]
===
match
---
assert_stmt [20108,20161]
assert_stmt [20108,20161]
===
match
---
name: datetime [21494,21502]
name: datetime [21494,21502]
===
match
---
operator: = [62545,62546]
operator: = [64493,64494]
===
match
---
name: task_id [50184,50191]
name: task_id [50184,50191]
===
match
---
parameters [47471,47477]
parameters [47471,47477]
===
match
---
name: prev_local [22176,22186]
name: prev_local [22176,22186]
===
match
---
trailer [53098,53104]
trailer [55046,55052]
===
match
---
atom_expr [14521,14540]
atom_expr [14521,14540]
===
match
---
comparison [46021,46062]
comparison [46021,46062]
===
match
---
trailer [27750,27765]
trailer [27750,27765]
===
match
---
name: topological_list [8236,8252]
name: topological_list [8236,8252]
===
match
---
decorator [67944,67991]
decorator [69892,69939]
===
match
---
operator: , [32047,32048]
operator: , [32047,32048]
===
match
---
fstring_start: f' [15560,15562]
fstring_start: f' [15560,15562]
===
match
---
atom_expr [65802,65817]
atom_expr [67750,67765]
===
match
---
atom_expr [68637,68654]
atom_expr [70585,70602]
===
match
---
assert_stmt [20843,20903]
assert_stmt [20843,20903]
===
match
---
comparison [47386,47408]
comparison [47386,47408]
===
match
---
string: 'dag-bulk-sync-3' [24810,24827]
string: 'dag-bulk-sync-3' [24810,24827]
===
match
---
name: six_hours_ago_to_the_hour [55726,55751]
name: six_hours_ago_to_the_hour [57674,57699]
===
match
---
simple_stmt [8026,8100]
simple_stmt [8026,8100]
===
match
---
name: ti3 [17255,17258]
name: ti3 [17255,17258]
===
match
---
assert_stmt [54373,54401]
assert_stmt [56321,56349]
===
match
---
simple_stmt [25655,25682]
simple_stmt [25655,25682]
===
match
---
trailer [41821,41833]
trailer [41821,41833]
===
match
---
funcdef [62290,63012]
funcdef [64238,64960]
===
match
---
simple_stmt [39761,39784]
simple_stmt [39761,39784]
===
match
---
name: DummyOperator [38479,38492]
name: DummyOperator [38479,38492]
===
match
---
name: state [51717,51722]
name: state [53665,53670]
===
match
---
operator: == [37703,37705]
operator: == [37703,37705]
===
match
---
param [48547,48560]
param [48547,48560]
===
match
---
name: dag [49220,49223]
name: dag [49220,49223]
===
match
---
operator: = [44674,44675]
operator: = [44674,44675]
===
match
---
name: models [1583,1589]
name: models [1583,1589]
===
match
---
dictorsetmaker [61604,61690]
dictorsetmaker [63552,63638]
===
match
---
operator: = [2932,2933]
operator: = [2932,2933]
===
match
---
simple_stmt [1517,1570]
simple_stmt [1517,1570]
===
match
---
name: op3 [9729,9732]
name: op3 [9729,9732]
===
match
---
trailer [57476,57485]
trailer [59424,59433]
===
match
---
name: dag_id [31615,31621]
name: dag_id [31615,31621]
===
match
---
name: DummyOperator [50370,50383]
name: DummyOperator [50370,50383]
===
match
---
operator: = [32205,32206]
operator: = [32205,32206]
===
match
---
operator: = [52089,52090]
operator: = [54037,54038]
===
match
---
name: dag_subclass_diff_name [45482,45504]
name: dag_subclass_diff_name [45482,45504]
===
match
---
atom_expr [22566,22651]
atom_expr [22566,22651]
===
match
---
trailer [10446,10449]
trailer [10446,10449]
===
match
---
expr_stmt [32193,32393]
expr_stmt [32193,32393]
===
match
---
name: dag [21916,21919]
name: dag [21916,21919]
===
match
---
trailer [35892,35906]
trailer [35892,35906]
===
match
---
atom_expr [37955,37982]
atom_expr [37955,37982]
===
match
---
name: external_trigger [41490,41506]
name: external_trigger [41490,41506]
===
match
---
trailer [32243,32250]
trailer [32243,32250]
===
match
---
funcdef [40840,41968]
funcdef [40840,41968]
===
match
---
operator: , [57244,57245]
operator: , [59192,59193]
===
match
---
name: next_date [58530,58539]
name: next_date [60478,60487]
===
match
---
expr_stmt [33833,33860]
expr_stmt [33833,33860]
===
match
---
name: DummyOperator [9825,9838]
name: DummyOperator [9825,9838]
===
match
---
trailer [61170,61176]
trailer [63118,63124]
===
match
---
return_stmt [66244,66254]
return_stmt [68192,68202]
===
match
---
operator: == [39393,39395]
operator: == [39393,39395]
===
match
---
trailer [22160,22167]
trailer [22160,22167]
===
match
---
operator: = [63161,63162]
operator: = [65109,65110]
===
match
---
trailer [27755,27762]
trailer [27755,27762]
===
match
---
name: commit [33513,33519]
name: commit [33513,33519]
===
match
---
number: 0 [27181,27182]
number: 0 [27181,27182]
===
match
---
simple_stmt [33004,33033]
simple_stmt [33004,33033]
===
match
---
suite [4847,5082]
suite [4847,5082]
===
match
---
expr_stmt [65392,65413]
expr_stmt [67340,67361]
===
match
---
name: current_task [16048,16060]
name: current_task [16048,16060]
===
match
---
name: session [46224,46231]
name: session [46224,46231]
===
match
---
string: "faketastic" [40431,40443]
string: "faketastic" [40431,40443]
===
match
---
atom_expr [67409,67426]
atom_expr [69357,69374]
===
match
---
name: _next [24022,24027]
name: _next [24022,24027]
===
match
---
trailer [33168,33170]
trailer [33168,33170]
===
match
---
simple_stmt [11584,11716]
simple_stmt [11584,11716]
===
match
---
operator: , [60874,60875]
operator: , [62822,62823]
===
match
---
trailer [53945,54027]
trailer [55893,55975]
===
match
---
argument [65611,65641]
argument [67559,67589]
===
match
---
name: __table__ [34640,34649]
name: __table__ [34640,34649]
===
match
---
name: num [66750,66753]
name: num [68698,68701]
===
match
---
assert_stmt [41809,41849]
assert_stmt [41809,41849]
===
match
---
name: default_view [5069,5081]
name: default_view [5069,5081]
===
match
---
number: 0 [6934,6935]
number: 0 [6934,6935]
===
match
---
name: get_num_task_instances [18281,18303]
name: get_num_task_instances [18281,18303]
===
match
---
name: _clean_up [50045,50054]
name: _clean_up [50045,50054]
===
match
---
trailer [49774,49780]
trailer [49774,49780]
===
match
---
name: weight [13653,13659]
name: weight [13653,13659]
===
match
---
assert_stmt [6272,6294]
assert_stmt [6272,6294]
===
match
---
atom_expr [35398,35425]
atom_expr [35398,35425]
===
match
---
operator: = [46087,46088]
operator: = [46087,46088]
===
match
---
simple_stmt [39419,39453]
simple_stmt [39419,39453]
===
match
---
simple_stmt [7544,7577]
simple_stmt [7544,7577]
===
match
---
arith_expr [52703,52744]
arith_expr [54651,54692]
===
match
---
string: 'owner2' [6323,6331]
string: 'owner2' [6323,6331]
===
match
---
string: 'dag_default_view' [29378,29396]
string: 'dag_default_view' [29378,29396]
===
match
---
name: session [25715,25722]
name: session [25715,25722]
===
match
---
name: TI [1514,1516]
name: TI [1514,1516]
===
match
---
operator: = [43518,43519]
operator: = [43518,43519]
===
match
---
name: copy [4389,4393]
name: copy [4389,4393]
===
match
---
name: prev [23394,23398]
name: prev [23394,23398]
===
match
---
name: datetime [55550,55558]
name: datetime [57498,57506]
===
match
---
atom_expr [38572,38638]
atom_expr [38572,38638]
===
match
---
argument [62714,62768]
argument [64662,64716]
===
match
---
name: DAG [40146,40149]
name: DAG [40146,40149]
===
match
---
name: self [35632,35636]
name: self [35632,35636]
===
match
---
argument [41457,41476]
argument [41457,41476]
===
match
---
atom_expr [5065,5081]
atom_expr [5065,5081]
===
match
---
name: return_num [66268,66278]
name: return_num [68216,68226]
===
match
---
operator: = [15355,15356]
operator: = [15355,15356]
===
match
---
testlist_comp [8933,8941]
testlist_comp [8933,8941]
===
match
---
operator: = [42186,42187]
operator: = [42186,42187]
===
match
---
name: run_id [39482,39488]
name: run_id [39482,39488]
===
match
---
operator: = [67116,67117]
operator: = [69064,69065]
===
match
---
name: all [52959,52962]
name: all [54907,54910]
===
match
---
simple_stmt [54518,54645]
simple_stmt [56466,56593]
===
match
---
simple_stmt [13951,13961]
simple_stmt [13951,13961]
===
match
---
name: start_date [55715,55725]
name: start_date [57663,57673]
===
match
---
simple_stmt [59918,60070]
simple_stmt [61866,62018]
===
match
---
name: dag [18672,18675]
name: dag [18672,18675]
===
match
---
dictorsetmaker [61838,61894]
dictorsetmaker [63786,63842]
===
match
---
parameters [65512,65518]
parameters [67460,67466]
===
match
---
trailer [63593,63602]
trailer [65541,65550]
===
match
---
atom_expr [32094,32110]
atom_expr [32094,32110]
===
match
---
simple_stmt [63792,63850]
simple_stmt [65740,65798]
===
match
---
name: self [20204,20208]
name: self [20204,20208]
===
match
---
simple_stmt [50662,50861]
simple_stmt [50662,50861]
===
match
---
trailer [64969,64971]
trailer [66917,66919]
===
match
---
trailer [33115,33122]
trailer [33115,33122]
===
match
---
testlist_comp [31520,31537]
testlist_comp [31520,31537]
===
match
---
expr_stmt [42781,42831]
expr_stmt [42781,42831]
===
match
---
argument [17848,17863]
argument [17848,17863]
===
match
---
name: DAG [25490,25493]
name: DAG [25490,25493]
===
match
---
name: i [60393,60394]
name: i [62341,62342]
===
match
---
name: dag [40397,40400]
name: dag [40397,40400]
===
match
---
arglist [58444,58454]
arglist [60392,60402]
===
match
---
name: timezone [57468,57476]
name: timezone [59416,59424]
===
match
---
argument [43277,43297]
argument [43277,43297]
===
match
---
trailer [53054,53057]
trailer [55002,55005]
===
match
---
trailer [20482,20484]
trailer [20482,20484]
===
match
---
atom_expr [29180,29211]
atom_expr [29180,29211]
===
match
---
atom_expr [22667,22697]
atom_expr [22667,22697]
===
match
---
comparison [48365,48393]
comparison [48365,48393]
===
match
---
operator: == [49621,49623]
operator: == [49621,49623]
===
match
---
operator: , [6012,6013]
operator: , [6012,6013]
===
match
---
operator: , [5926,5927]
operator: , [5926,5927]
===
match
---
param [66481,66485]
param [68429,68433]
===
match
---
atom_expr [11955,12025]
atom_expr [11955,12025]
===
match
---
simple_stmt [5323,5392]
simple_stmt [5323,5392]
===
match
---
comparison [45596,45615]
comparison [45596,45615]
===
match
---
trailer [33690,33707]
trailer [33690,33707]
===
match
---
expr_stmt [16780,16803]
expr_stmt [16780,16803]
===
match
---
name: DAG [17993,17996]
name: DAG [17993,17996]
===
match
---
name: add_task [23759,23767]
name: add_task [23759,23767]
===
match
---
funcdef [65082,65484]
funcdef [67030,67432]
===
match
---
arglist [55616,55779]
arglist [57564,57727]
===
match
---
name: schedule_interval [55669,55686]
name: schedule_interval [57617,57634]
===
match
---
name: state [39301,39306]
name: state [39301,39306]
===
match
---
operator: = [58475,58476]
operator: = [60423,60424]
===
match
---
name: dag_id [32034,32040]
name: dag_id [32034,32040]
===
match
---
trailer [25237,25243]
trailer [25237,25243]
===
match
---
name: next_date [56821,56830]
name: next_date [58769,58778]
===
match
---
simple_stmt [36555,36589]
simple_stmt [36555,36589]
===
match
---
atom [46467,46492]
atom [46467,46492]
===
match
---
operator: = [16932,16933]
operator: = [16932,16933]
===
match
---
string: 'D' [9802,9805]
string: 'D' [9802,9805]
===
match
---
return_stmt [68115,68125]
return_stmt [70063,70073]
===
match
---
number: 5 [57755,57756]
number: 5 [59703,59704]
===
match
---
name: DEFAULT_DATE [63198,63210]
name: DEFAULT_DATE [65146,65158]
===
match
---
atom_expr [14781,14803]
atom_expr [14781,14803]
===
match
---
atom_expr [7144,7151]
atom_expr [7144,7151]
===
match
---
trailer [17806,17864]
trailer [17806,17864]
===
match
---
expr_stmt [63792,63849]
expr_stmt [65740,65797]
===
match
---
factor [3305,3307]
factor [3305,3307]
===
match
---
operator: } [38169,38170]
operator: } [38169,38170]
===
match
---
argument [57312,57347]
argument [59260,59295]
===
match
---
operator: , [32040,32041]
operator: , [32040,32041]
===
match
---
name: correct_weight [16216,16230]
name: correct_weight [16216,16230]
===
match
---
name: dag [62469,62472]
name: dag [64417,64420]
===
match
---
funcdef [54464,56860]
funcdef [56412,58808]
===
match
---
trailer [17511,17517]
trailer [17511,17517]
===
match
---
simple_stmt [9864,9888]
simple_stmt [9864,9888]
===
match
---
simple_stmt [55275,55286]
simple_stmt [57223,57234]
===
match
---
expr_stmt [24136,24214]
expr_stmt [24136,24214]
===
match
---
atom_expr [52634,52784]
atom_expr [54582,54732]
===
match
---
operator: , [8299,8300]
operator: , [8299,8300]
===
match
---
operator: = [27426,27427]
operator: = [27426,27427]
===
match
---
atom_expr [19046,19052]
atom_expr [19046,19052]
===
match
---
expr_stmt [38473,38506]
expr_stmt [38473,38506]
===
match
---
argument [16511,16543]
argument [16511,16543]
===
match
---
name: DEFAULT_DATE [7693,7705]
name: DEFAULT_DATE [7693,7705]
===
match
---
trailer [67174,67180]
trailer [69122,69128]
===
match
---
name: operator [68253,68261]
name: operator [70201,70209]
===
match
---
trailer [38680,38696]
trailer [38680,38696]
===
match
---
name: TEST_DATE [23885,23894]
name: TEST_DATE [23885,23894]
===
match
---
atom_expr [14184,14374]
atom_expr [14184,14374]
===
match
---
trailer [47171,47174]
trailer [47171,47174]
===
match
---
operator: = [48163,48164]
operator: = [48163,48164]
===
match
---
operator: , [24607,24608]
operator: , [24607,24608]
===
match
---
name: dag [44988,44991]
name: dag [44988,44991]
===
match
---
operator: , [22608,22609]
operator: , [22608,22609]
===
match
---
operator: , [20408,20409]
operator: , [20408,20409]
===
match
---
expr_stmt [12562,12604]
expr_stmt [12562,12604]
===
match
---
name: _next [23911,23916]
name: _next [23911,23916]
===
match
---
operator: = [28997,28998]
operator: = [28997,28998]
===
match
---
name: create_dagrun [42522,42535]
name: create_dagrun [42522,42535]
===
match
---
atom [19994,20009]
atom [19994,20009]
===
match
---
assert_stmt [45429,45460]
assert_stmt [45429,45460]
===
match
---
atom [52811,52974]
atom [54759,54922]
===
match
---
name: session [30327,30334]
name: session [30327,30334]
===
match
---
name: next_dagrun [62674,62685]
name: next_dagrun [64622,64633]
===
match
---
name: timezone [55994,56002]
name: timezone [57942,57950]
===
match
---
operator: , [29909,29910]
operator: , [29909,29910]
===
match
---
name: dag [7148,7151]
name: dag [7148,7151]
===
match
---
name: create_dagrun [47544,47557]
name: create_dagrun [47544,47557]
===
match
---
operator: = [37007,37008]
operator: = [37007,37008]
===
match
---
atom_expr [18215,18228]
atom_expr [18215,18228]
===
match
---
operator: } [32479,32480]
operator: } [32479,32480]
===
match
---
name: default_args [34965,34977]
name: default_args [34965,34977]
===
match
---
name: op2 [38098,38101]
name: op2 [38098,38101]
===
match
---
name: next_dagrun_create_after [27895,27919]
name: next_dagrun_create_after [27895,27919]
===
match
---
name: next_date [56224,56233]
name: next_date [58172,58181]
===
match
---
operator: = [17366,17367]
operator: = [17366,17367]
===
match
---
name: subdag [31169,31175]
name: subdag [31169,31175]
===
match
---
name: next_local [23102,23112]
name: next_local [23102,23112]
===
match
---
operator: = [52381,52382]
operator: = [54329,54330]
===
match
---
trailer [18220,18228]
trailer [18220,18228]
===
match
---
name: refresh_from_db [43593,43608]
name: refresh_from_db [43593,43608]
===
match
---
name: pendulum [1083,1091]
name: pendulum [1083,1091]
===
match
---
trailer [23186,23188]
trailer [23186,23188]
===
match
---
arglist [53291,53301]
arglist [55239,55249]
===
match
---
name: dag_id [23606,23612]
name: dag_id [23606,23612]
===
match
---
with_item [35720,35767]
with_item [35720,35767]
===
match
---
name: task_id [35320,35327]
name: task_id [35320,35327]
===
match
---
atom_expr [41060,41087]
atom_expr [41060,41087]
===
match
---
testlist_comp [32062,32078]
testlist_comp [32062,32078]
===
match
---
param [53194,53198]
param [55142,55146]
===
match
---
fstring [60446,60478]
fstring [62394,62426]
===
match
---
trailer [6005,6072]
trailer [6005,6072]
===
match
---
name: dag [65392,65395]
name: dag [67340,67343]
===
match
---
name: schedule_interval [56563,56580]
name: schedule_interval [58511,58528]
===
match
---
name: DEFAULT_DATE [47672,47684]
name: DEFAULT_DATE [47672,47684]
===
match
---
name: parameterized [64090,64103]
name: parameterized [66038,66051]
===
match
---
trailer [26368,26375]
trailer [26368,26375]
===
match
---
name: all [25271,25274]
name: all [25271,25274]
===
match
---
string: 'test-dag' [19773,19783]
string: 'test-dag' [19773,19783]
===
match
---
argument [30327,30342]
argument [30327,30342]
===
match
---
string: """Test that dag param is correctly overwritten when set in dag run""" [67864,67934]
string: """Test that dag param is correctly overwritten when set in dag run""" [69812,69882]
===
match
---
atom_expr [26344,26396]
atom_expr [26344,26396]
===
match
---
trailer [41545,41547]
trailer [41545,41547]
===
match
---
name: orm_dag [29284,29291]
name: orm_dag [29284,29291]
===
match
---
operator: = [8585,8586]
operator: = [8585,8586]
===
match
---
name: test_next_dagrun_after_date_timedelta_schedule_and_catchup_false [56917,56981]
name: test_next_dagrun_after_date_timedelta_schedule_and_catchup_false [58865,58929]
===
match
---
assert_stmt [38803,38856]
assert_stmt [38803,38856]
===
match
---
trailer [55098,55121]
trailer [57046,57069]
===
match
---
operator: , [40538,40539]
operator: , [40538,40539]
===
match
---
funcdef [66640,66785]
funcdef [68588,68733]
===
match
---
trailer [5550,5554]
trailer [5550,5554]
===
match
---
comparison [58745,58787]
comparison [60693,60735]
===
match
---
trailer [33044,33055]
trailer [33044,33055]
===
match
---
trailer [67424,67426]
trailer [69372,69374]
===
match
---
operator: = [50973,50974]
operator: = [50973,50974]
===
match
---
operator: = [48805,48806]
operator: = [48805,48806]
===
match
---
string: """         Test invalid `orientation` of DAG initialization         """ [5135,5207]
string: """         Test invalid `orientation` of DAG initialization         """ [5135,5207]
===
match
---
argument [24572,24589]
argument [24572,24589]
===
match
---
operator: } [14110,14111]
operator: } [14110,14111]
===
match
---
name: dag [32852,32855]
name: dag [32852,32855]
===
match
---
string: 'test-dag' [19129,19139]
string: 'test-dag' [19129,19139]
===
match
---
operator: = [35042,35043]
operator: = [35042,35043]
===
match
---
name: op3 [9091,9094]
name: op3 [9091,9094]
===
match
---
name: dr [47413,47415]
name: dr [47413,47415]
===
match
---
atom_expr [13068,13083]
atom_expr [13068,13083]
===
match
---
expr_stmt [51017,51092]
expr_stmt [51017,51092]
===
match
---
argument [6171,6184]
argument [6171,6184]
===
match
---
name: DAG [17596,17599]
name: DAG [17596,17599]
===
match
---
simple_stmt [31202,31331]
simple_stmt [31202,31331]
===
match
---
argument [35736,35759]
argument [35736,35759]
===
match
---
testlist_comp [19929,19957]
testlist_comp [19929,19957]
===
match
---
operator: , [35734,35735]
operator: , [35734,35735]
===
match
---
trailer [23916,23926]
trailer [23916,23926]
===
match
---
simple_stmt [52101,52147]
simple_stmt [54049,54095]
===
match
---
testlist_comp [20135,20160]
testlist_comp [20135,20160]
===
match
---
assert_stmt [17981,18111]
assert_stmt [17981,18111]
===
match
---
suite [42768,42832]
suite [42768,42832]
===
match
---
name: DEFAULT_DATE [68503,68515]
name: DEFAULT_DATE [70451,70463]
===
match
---
name: access_control [62169,62183]
name: access_control [64117,64131]
===
match
---
operator: } [11704,11705]
operator: } [11704,11705]
===
match
---
name: prev [21851,21855]
name: prev [21851,21855]
===
match
---
name: op1 [35601,35604]
name: op1 [35601,35604]
===
match
---
simple_stmt [55975,56012]
simple_stmt [57923,57960]
===
match
---
string: 'dag' [5921,5926]
string: 'dag' [5921,5926]
===
match
---
operator: , [34149,34150]
operator: , [34149,34150]
===
match
---
atom_expr [18374,18387]
atom_expr [18374,18387]
===
match
---
atom_expr [12429,12446]
atom_expr [12429,12446]
===
match
---
trailer [9658,9671]
trailer [9658,9671]
===
match
---
expr_stmt [17164,17246]
expr_stmt [17164,17246]
===
match
---
operator: = [36522,36523]
operator: = [36522,36523]
===
match
---
string: 'owner' [16525,16532]
string: 'owner' [16525,16532]
===
match
---
operator: { [37213,37214]
operator: { [37213,37214]
===
match
---
argument [37129,37151]
argument [37129,37151]
===
match
---
simple_stmt [1043,1075]
simple_stmt [1043,1075]
===
match
---
operator: , [37127,37128]
operator: , [37127,37128]
===
match
---
trailer [67661,67719]
trailer [69609,69667]
===
match
---
arglist [8364,8403]
arglist [8364,8403]
===
match
---
trailer [10904,10980]
trailer [10904,10980]
===
match
---
expr_stmt [13677,13723]
expr_stmt [13677,13723]
===
match
---
trailer [55837,55843]
trailer [57785,57791]
===
match
---
name: start_date [9469,9479]
name: start_date [9469,9479]
===
match
---
arglist [20378,20450]
arglist [20378,20450]
===
match
---
assert_stmt [62215,62263]
assert_stmt [64163,64211]
===
match
---
argument [17941,17954]
argument [17941,17954]
===
match
---
simple_stmt [41240,41333]
simple_stmt [41240,41333]
===
match
---
trailer [47385,47423]
trailer [47385,47423]
===
match
---
operator: } [18649,18650]
operator: } [18649,18650]
===
match
---
atom_expr [38222,38233]
atom_expr [38222,38233]
===
match
---
trailer [15797,15807]
trailer [15797,15807]
===
match
---
name: prev [22297,22301]
name: prev [22297,22301]
===
match
---
operator: = [34861,34862]
operator: = [34861,34862]
===
match
---
simple_stmt [3044,3136]
simple_stmt [3044,3136]
===
match
---
suite [37029,37180]
suite [37029,37180]
===
match
---
operator: = [37589,37590]
operator: = [37589,37590]
===
match
---
simple_stmt [40491,40568]
simple_stmt [40491,40568]
===
match
---
operator: == [22314,22316]
operator: == [22314,22316]
===
match
---
argument [16486,16509]
argument [16486,16509]
===
match
---
name: set2 [10264,10268]
name: set2 [10264,10268]
===
match
---
number: 0 [9183,9184]
number: 0 [9183,9184]
===
match
---
argument [59141,59177]
argument [61089,61125]
===
match
---
atom_expr [31499,31539]
atom_expr [31499,31539]
===
match
---
trailer [28234,28238]
trailer [28234,28238]
===
match
---
operator: == [23125,23127]
operator: == [23125,23127]
===
match
---
trailer [38841,38856]
trailer [38841,38856]
===
match
---
name: on_failure_callback [40304,40323]
name: on_failure_callback [40304,40323]
===
match
---
assert_stmt [29551,29616]
assert_stmt [29551,29616]
===
match
---
name: needed [63636,63642]
name: needed [65584,65590]
===
match
---
atom_expr [45832,45841]
atom_expr [45832,45841]
===
match
---
trailer [42506,42508]
trailer [42506,42508]
===
match
---
atom_expr [33544,33623]
atom_expr [33544,33623]
===
match
---
name: DagModel [29486,29494]
name: DagModel [29486,29494]
===
match
---
dotted_name [1522,1549]
dotted_name [1522,1549]
===
match
---
argument [50546,50564]
argument [50546,50564]
===
match
---
operator: } [37723,37724]
operator: } [37723,37724]
===
match
---
name: include_parentdag [51404,51421]
name: include_parentdag [51404,51421]
===
match
---
operator: = [17117,17118]
operator: = [17117,17118]
===
match
---
atom_expr [42889,42919]
atom_expr [42889,42919]
===
match
---
simple_stmt [21326,21398]
simple_stmt [21326,21398]
===
match
---
trailer [18772,18781]
trailer [18772,18781]
===
match
---
name: test_dags_needing_dagruns_not_too_early [62294,62333]
name: test_dags_needing_dagruns_not_too_early [64242,64281]
===
match
---
operator: , [36015,36016]
operator: , [36015,36016]
===
match
---
operator: , [60634,60635]
operator: , [62582,62583]
===
match
---
name: state [49775,49780]
name: state [49775,49780]
===
match
---
name: local_tz [21965,21973]
name: local_tz [21965,21973]
===
match
---
trailer [31729,31736]
trailer [31729,31736]
===
match
---
name: state [64547,64552]
name: state [66495,66500]
===
match
---
name: downstream_list [38681,38696]
name: downstream_list [38681,38696]
===
match
---
atom_expr [5605,5645]
atom_expr [5605,5645]
===
match
---
operator: , [28116,28117]
operator: , [28116,28117]
===
match
---
name: DagParam [68164,68172]
name: DagParam [70112,70120]
===
match
---
with_stmt [36976,37180]
with_stmt [36976,37180]
===
match
---
operator: = [67169,67170]
operator: = [69117,69118]
===
match
---
param [47041,47045]
param [47041,47045]
===
match
---
suite [15228,16362]
suite [15228,16362]
===
match
---
name: dag_id [49624,49630]
name: dag_id [49624,49630]
===
match
---
atom_expr [17687,17759]
atom_expr [17687,17759]
===
match
---
expr_stmt [61099,61122]
expr_stmt [63047,63070]
===
match
---
name: correct_weight [13768,13782]
name: correct_weight [13768,13782]
===
match
---
trailer [37571,37594]
trailer [37571,37594]
===
match
---
operator: = [48769,48770]
operator: = [48769,48770]
===
match
---
operator: , [56588,56589]
operator: , [58536,58537]
===
match
---
arglist [20396,20415]
arglist [20396,20415]
===
match
---
trailer [24037,24039]
trailer [24037,24039]
===
match
---
atom_expr [34878,34924]
atom_expr [34878,34924]
===
match
---
argument [66035,66065]
argument [67983,68013]
===
match
---
atom_expr [26377,26388]
atom_expr [26377,26388]
===
match
---
simple_stmt [30275,30304]
simple_stmt [30275,30304]
===
match
---
atom_expr [24664,24690]
atom_expr [24664,24690]
===
match
---
parameters [16708,16714]
parameters [16708,16714]
===
match
---
comparison [56448,56477]
comparison [58396,58425]
===
match
---
atom_expr [37613,37649]
atom_expr [37613,37649]
===
match
---
string: 'stage(\\d*).(\\d*)' [14008,14028]
string: 'stage(\\d*).(\\d*)' [14008,14028]
===
match
---
name: set_is_paused [32154,32167]
name: set_is_paused [32154,32167]
===
match
---
atom_expr [39531,39553]
atom_expr [39531,39553]
===
match
---
comparison [5605,5664]
comparison [5605,5664]
===
match
---
operator: , [64401,64402]
operator: , [66349,66350]
===
match
---
name: minutes [55508,55515]
name: minutes [57456,57463]
===
match
---
trailer [65041,65050]
trailer [66989,66998]
===
match
---
argument [50988,51007]
argument [50988,51007]
===
match
---
name: all [47382,47385]
name: all [47382,47385]
===
match
---
name: set2 [10405,10409]
name: set2 [10405,10409]
===
match
---
suite [30758,30838]
suite [30758,30838]
===
match
---
atom_expr [48845,49029]
atom_expr [48845,49029]
===
match
---
name: weight_rule [2168,2179]
name: weight_rule [2168,2179]
===
match
---
operator: , [49554,49555]
operator: , [49554,49555]
===
match
---
name: noop_pipeline [65398,65411]
name: noop_pipeline [67346,67359]
===
match
---
with_item [2811,2838]
with_item [2811,2838]
===
match
---
comparison [46885,46949]
comparison [46885,46949]
===
match
---
operator: = [60807,60808]
operator: = [62755,62756]
===
match
---
simple_stmt [53403,53453]
simple_stmt [55351,55401]
===
match
---
name: TI [52856,52858]
name: TI [54804,54806]
===
match
---
expr_stmt [44135,44175]
expr_stmt [44135,44175]
===
match
---
name: execution_date [28012,28026]
name: execution_date [28012,28026]
===
match
---
comparison [53527,53544]
comparison [55475,55492]
===
match
---
atom_expr [49304,49330]
atom_expr [49304,49330]
===
match
---
number: 5 [58333,58334]
number: 5 [60281,60282]
===
match
---
operator: = [23684,23685]
operator: = [23684,23685]
===
match
---
name: op3 [55258,55261]
name: op3 [57206,57209]
===
match
---
trailer [16625,16671]
trailer [16625,16671]
===
match
---
name: MagicMock [40059,40068]
name: MagicMock [40059,40068]
===
match
---
arglist [4736,4794]
arglist [4736,4794]
===
match
---
atom_expr [61552,61579]
atom_expr [63500,63527]
===
match
---
atom [26145,26176]
atom [26145,26176]
===
match
---
param [10886,10890]
param [10886,10890]
===
match
---
name: remove [26467,26473]
name: remove [26467,26473]
===
match
---
trailer [46042,46050]
trailer [46042,46050]
===
match
---
arglist [16479,16543]
arglist [16479,16543]
===
match
---
name: ti [67728,67730]
name: ti [69676,69678]
===
match
---
simple_stmt [35919,35953]
simple_stmt [35919,35953]
===
match
---
trailer [28077,28087]
trailer [28077,28087]
===
match
---
name: stdout_lines [36702,36714]
name: stdout_lines [36702,36714]
===
match
---
simple_stmt [35827,35861]
simple_stmt [35827,35861]
===
match
---
expr_stmt [36555,36588]
expr_stmt [36555,36588]
===
match
---
name: session [28109,28116]
name: session [28109,28116]
===
match
---
atom_expr [22583,22616]
atom_expr [22583,22616]
===
match
---
trailer [46029,46042]
trailer [46029,46042]
===
match
---
trailer [24393,24400]
trailer [24393,24400]
===
match
---
operator: } [24917,24918]
operator: } [24917,24918]
===
match
---
atom_expr [65624,65641]
atom_expr [67572,67589]
===
match
---
name: stdout_lines [36616,36628]
name: stdout_lines [36616,36628]
===
match
---
expr_stmt [44235,44290]
expr_stmt [44235,44290]
===
match
---
operator: , [25085,25086]
operator: , [25085,25086]
===
match
---
name: WeightRule [15661,15671]
name: WeightRule [15661,15671]
===
match
---
string: 'value' [69254,69261]
string: 'value' [71202,71209]
===
match
---
suite [18947,19438]
suite [18947,19438]
===
match
---
name: default_args [44442,44454]
name: default_args [44442,44454]
===
match
---
name: hash [45785,45789]
name: hash [45785,45789]
===
match
---
parameters [24096,24102]
parameters [24096,24102]
===
match
---
name: start [21460,21465]
name: start [21460,21465]
===
match
---
trailer [62921,62925]
trailer [64869,64873]
===
match
---
string: 'owner' [15422,15429]
string: 'owner' [15422,15429]
===
match
---
atom_expr [34222,34285]
atom_expr [34222,34285]
===
match
---
atom_expr [67527,67544]
atom_expr [69475,69492]
===
match
---
simple_stmt [67403,67427]
simple_stmt [69351,69375]
===
match
---
simple_stmt [44299,44341]
simple_stmt [44299,44341]
===
match
---
trailer [24875,24881]
trailer [24875,24881]
===
match
---
simple_stmt [68115,68126]
simple_stmt [70063,70074]
===
match
---
name: dag2 [56021,56025]
name: dag2 [57969,57973]
===
match
---
name: mock [1038,1042]
name: mock [1038,1042]
===
match
---
trailer [65074,65076]
trailer [67022,67024]
===
match
---
name: op1 [36012,36015]
name: op1 [36012,36015]
===
match
---
trailer [32576,32590]
trailer [32576,32590]
===
match
---
operator: , [26226,26227]
operator: , [26226,26227]
===
match
---
operator: , [4336,4337]
operator: , [4336,4337]
===
match
---
trailer [45301,45307]
trailer [45301,45307]
===
match
---
operator: , [19346,19347]
operator: , [19346,19347]
===
match
---
assert_stmt [47907,47949]
assert_stmt [47907,47949]
===
match
---
suite [24281,24443]
suite [24281,24443]
===
match
---
name: orm_dag [29184,29191]
name: orm_dag [29184,29191]
===
match
---
expr_stmt [7058,7092]
expr_stmt [7058,7092]
===
match
---
name: params [69247,69253]
name: params [71195,71201]
===
match
---
name: utils [2119,2124]
name: utils [2119,2124]
===
match
---
operator: = [40144,40145]
operator: = [40144,40145]
===
match
---
name: commit [52616,52622]
name: commit [54564,54570]
===
match
---
string: """         Test the subdags are never marked to have dagruns created, as they are         handled by the SubDagOperator, not the scheduler         """ [59918,60069]
string: """         Test the subdags are never marked to have dagruns created, as they are         handled by the SubDagOperator, not the scheduler         """ [61866,62017]
===
match
---
name: task_id [6843,6850]
name: task_id [6843,6850]
===
match
---
name: local_tz [35118,35126]
name: local_tz [35118,35126]
===
match
---
operator: = [22564,22565]
operator: = [22564,22565]
===
match
---
name: test_following_previous_schedule_daily_dag_cest_to_cet [21256,21310]
name: test_following_previous_schedule_daily_dag_cest_to_cet [21256,21310]
===
match
---
expr_stmt [9452,9527]
expr_stmt [9452,9527]
===
match
---
name: dag [18555,18558]
name: dag [18555,18558]
===
match
---
name: op2 [9684,9687]
name: op2 [9684,9687]
===
match
---
argument [29923,29943]
argument [29923,29943]
===
match
---
name: DummyOperator [38387,38400]
name: DummyOperator [38387,38400]
===
match
---
name: dr [47959,47961]
name: dr [47959,47961]
===
match
---
operator: = [19724,19725]
operator: = [19724,19725]
===
match
---
string: 'dag_paused' [32674,32686]
string: 'dag_paused' [32674,32686]
===
match
---
atom [24752,24828]
atom [24752,24828]
===
match
---
operator: = [57164,57165]
operator: = [59112,59113]
===
match
---
simple_stmt [17379,17405]
simple_stmt [17379,17405]
===
match
---
atom [35600,35610]
atom [35600,35610]
===
match
---
suite [14804,15162]
suite [14804,15162]
===
match
---
atom_expr [9864,9887]
atom_expr [9864,9887]
===
match
---
name: DagTag [24372,24378]
name: DagTag [24372,24378]
===
match
---
operator: = [32177,32178]
operator: = [32177,32178]
===
match
---
atom [26095,26127]
atom [26095,26127]
===
match
---
arglist [59319,59360]
arglist [61267,61308]
===
match
---
name: query [46232,46237]
name: query [46232,46237]
===
match
---
name: set_downstream [10008,10022]
name: set_downstream [10008,10022]
===
match
---
name: subdag [28869,28875]
name: subdag [28869,28875]
===
match
---
name: test_dag_id [44429,44440]
name: test_dag_id [44429,44440]
===
match
---
simple_stmt [19710,19751]
simple_stmt [19710,19751]
===
match
---
name: add_task [54040,54048]
name: add_task [55988,55996]
===
match
---
operator: , [55221,55222]
operator: , [57169,57170]
===
match
---
string: b'{{ ds }}' [19612,19623]
string: b'{{ ds }}' [19612,19623]
===
match
---
operator: == [58423,58425]
operator: == [60371,60373]
===
match
---
trailer [60782,60922]
trailer [62730,62870]
===
match
---
name: op2 [35606,35609]
name: op2 [35606,35609]
===
match
---
name: params [4338,4344]
name: params [4338,4344]
===
match
---
atom_expr [67295,67312]
atom_expr [69243,69260]
===
match
---
operator: , [8158,8159]
operator: , [8158,8159]
===
match
---
name: subdag_id [32330,32339]
name: subdag_id [32330,32339]
===
match
---
trailer [11853,11866]
trailer [11853,11866]
===
match
---
operator: = [56696,56697]
operator: = [58644,58645]
===
match
---
trailer [53431,53440]
trailer [55379,55388]
===
match
---
name: delete [31275,31281]
name: delete [31275,31281]
===
match
---
number: 1 [62612,62613]
number: 1 [64560,64561]
===
match
---
name: template_dir [19830,19842]
name: template_dir [19830,19842]
===
match
---
trailer [62131,62151]
trailer [64079,64099]
===
match
---
simple_stmt [63636,63690]
simple_stmt [65584,65638]
===
match
---
trailer [34708,34714]
trailer [34708,34714]
===
match
---
name: op4 [35919,35922]
name: op4 [35919,35922]
===
match
---
operator: = [35992,35993]
operator: = [35992,35993]
===
match
---
with_stmt [6477,6608]
with_stmt [6477,6608]
===
match
---
with_stmt [62114,62207]
with_stmt [64062,64155]
===
match
---
arglist [64497,64609]
arglist [66445,66557]
===
match
---
atom_expr [29632,29652]
atom_expr [29632,29652]
===
match
---
atom_expr [2852,2939]
atom_expr [2852,2939]
===
match
---
testlist_comp [51717,51734]
testlist_comp [53665,53682]
===
match
---
trailer [23257,23264]
trailer [23257,23264]
===
match
---
operator: = [15337,15338]
operator: = [15337,15338]
===
match
---
simple_stmt [949,989]
simple_stmt [949,989]
===
match
---
simple_stmt [44404,44461]
simple_stmt [44404,44461]
===
match
---
simple_stmt [15119,15162]
simple_stmt [15119,15162]
===
match
---
atom_expr [19454,19469]
atom_expr [19454,19469]
===
match
---
arglist [50954,51007]
arglist [50954,51007]
===
match
---
suite [67182,67394]
suite [69130,69342]
===
match
---
atom_expr [10704,10726]
atom_expr [10704,10726]
===
match
---
number: 0 [61235,61236]
number: 0 [63183,63184]
===
match
---
name: catchup [55000,55007]
name: catchup [56948,56955]
===
match
---
name: args [44389,44393]
name: args [44389,44393]
===
match
---
name: params1 [4328,4335]
name: params1 [4328,4335]
===
match
---
name: session [17477,17484]
name: session [17477,17484]
===
match
---
simple_stmt [64348,64412]
simple_stmt [66296,66360]
===
match
---
name: session [33421,33428]
name: session [33421,33428]
===
match
---
name: dag [47841,47844]
name: dag [47841,47844]
===
match
---
fstring_expr [47219,47222]
fstring_expr [47219,47222]
===
match
---
operator: , [59475,59476]
operator: , [61423,61424]
===
match
---
expr_stmt [20913,20946]
expr_stmt [20913,20946]
===
match
---
operator: == [45734,45736]
operator: == [45734,45736]
===
match
---
simple_stmt [20069,20099]
simple_stmt [20069,20099]
===
match
---
name: self [68798,68802]
name: self [70746,70750]
===
match
---
name: start_date [54953,54963]
name: start_date [56901,56911]
===
match
---
name: subdag [31012,31018]
name: subdag [31012,31018]
===
match
---
name: return_num [65369,65379]
name: return_num [67317,67327]
===
match
---
name: create_session [26576,26590]
name: create_session [26576,26590]
===
match
---
name: a_index [3393,3400]
name: a_index [3393,3400]
===
match
---
atom_expr [57330,57347]
atom_expr [59278,59295]
===
match
---
name: dag_id [43094,43100]
name: dag_id [43094,43100]
===
match
---
comparison [56821,56859]
comparison [58769,58807]
===
match
---
name: DAG [46802,46805]
name: DAG [46802,46805]
===
match
---
trailer [21619,21678]
trailer [21619,21678]
===
match
---
name: state [50546,50551]
name: state [50546,50551]
===
match
---
name: value [68019,68024]
name: value [69967,69972]
===
match
---
operator: , [25121,25122]
operator: , [25121,25122]
===
match
---
funcdef [48509,49798]
funcdef [48509,49798]
===
match
---
name: catchup [54992,54999]
name: catchup [56940,56947]
===
match
---
simple_stmt [5538,5590]
simple_stmt [5538,5590]
===
match
---
trailer [2825,2827]
trailer [2825,2827]
===
match
---
simple_stmt [5005,5082]
simple_stmt [5005,5082]
===
match
---
name: models [4281,4287]
name: models [4281,4287]
===
match
---
name: dag_id [24891,24897]
name: dag_id [24891,24897]
===
match
---
name: dag [68306,68309]
name: dag [70254,70257]
===
match
---
atom_expr [16110,16132]
atom_expr [16110,16132]
===
match
---
expr_stmt [10127,10144]
expr_stmt [10127,10144]
===
match
---
atom_expr [8915,8943]
atom_expr [8915,8943]
===
match
---
name: schedule_interval [43174,43191]
name: schedule_interval [43174,43191]
===
match
---
trailer [16123,16130]
trailer [16123,16130]
===
match
---
name: next_dagrun [28033,28044]
name: next_dagrun [28033,28044]
===
match
---
trailer [25675,25681]
trailer [25675,25681]
===
match
---
trailer [63907,63909]
trailer [65855,65857]
===
match
---
arglist [41373,41512]
arglist [41373,41512]
===
match
---
name: timezone [58758,58766]
name: timezone [60706,60714]
===
match
---
name: next_dagrun_create_after [63473,63497]
name: next_dagrun_create_after [65421,65445]
===
match
---
trailer [4291,4353]
trailer [4291,4353]
===
match
---
trailer [21938,21943]
trailer [21938,21943]
===
match
---
name: query [29110,29115]
name: query [29110,29115]
===
match
---
name: needed [63705,63711]
name: needed [65653,65659]
===
match
---
argument [46289,46314]
argument [46289,46314]
===
match
---
operator: , [35555,35556]
operator: , [35555,35556]
===
match
---
operator: == [6320,6322]
operator: == [6320,6322]
===
match
---
number: 3 [13941,13942]
number: 3 [13941,13942]
===
match
---
name: DummyOperator [28594,28607]
name: DummyOperator [28594,28607]
===
match
---
name: orm_dag [30441,30448]
name: orm_dag [30441,30448]
===
match
---
name: bulk_write_to_db [28170,28186]
name: bulk_write_to_db [28170,28186]
===
match
---
trailer [68720,68723]
trailer [70668,70671]
===
match
---
name: is_paused [33285,33294]
name: is_paused [33285,33294]
===
match
---
number: 0 [15895,15896]
number: 0 [15895,15896]
===
match
---
name: dag_id [47497,47503]
name: dag_id [47497,47503]
===
match
---
comparison [33575,33616]
comparison [33575,33616]
===
match
---
atom [54743,54836]
atom [56691,56784]
===
match
---
name: i [60471,60472]
name: i [62419,62420]
===
match
---
name: all [63844,63847]
name: all [65792,65795]
===
match
---
expr_stmt [9729,9761]
expr_stmt [9729,9761]
===
match
---
import_from [1817,1857]
import_from [1817,1857]
===
match
---
operator: = [7878,7879]
operator: = [7878,7879]
===
match
---
name: DagTag [27047,27053]
name: DagTag [27047,27053]
===
match
---
name: dag [7239,7242]
name: dag [7239,7242]
===
match
---
comparison [42889,42927]
comparison [42889,42927]
===
match
---
atom_expr [68452,68469]
atom_expr [70400,70417]
===
match
---
name: utc [23036,23039]
name: utc [23036,23039]
===
match
---
name: pattern [14829,14836]
name: pattern [14829,14836]
===
match
---
trailer [40688,40711]
trailer [40688,40711]
===
match
---
atom_expr [16007,16022]
atom_expr [16007,16022]
===
match
---
atom_expr [4381,4395]
atom_expr [4381,4395]
===
match
---
assert_stmt [58406,58455]
assert_stmt [60354,60403]
===
match
---
trailer [42853,42865]
trailer [42853,42865]
===
match
---
operator: , [48777,48778]
operator: , [48777,48778]
===
match
---
name: DummyOperator [6829,6842]
name: DummyOperator [6829,6842]
===
match
---
number: 0 [55419,55420]
number: 0 [57367,57368]
===
match
---
name: default_args [6039,6051]
name: default_args [6039,6051]
===
match
---
operator: = [28723,28724]
operator: = [28723,28724]
===
match
---
argument [49097,49124]
argument [49097,49124]
===
match
---
atom_expr [17267,17279]
atom_expr [17267,17279]
===
match
---
number: 2 [17988,17989]
number: 2 [17988,17989]
===
match
---
operator: , [26176,26177]
operator: , [26176,26177]
===
match
---
simple_stmt [59489,59670]
simple_stmt [61437,61618]
===
match
---
operator: = [36568,36569]
operator: = [36568,36569]
===
match
---
operator: == [6456,6458]
operator: == [6456,6458]
===
match
---
number: 3 [21517,21518]
number: 3 [21517,21518]
===
match
---
argument [59709,59716]
argument [61657,61664]
===
match
---
atom_expr [67117,67134]
atom_expr [69065,69082]
===
match
---
operator: = [59326,59327]
operator: = [61274,61275]
===
match
---
atom_expr [8193,8253]
atom_expr [8193,8253]
===
match
---
assert_stmt [6303,6331]
assert_stmt [6303,6331]
===
match
---
trailer [60629,60641]
trailer [62577,62589]
===
match
---
suite [5708,7251]
suite [5708,7251]
===
match
---
operator: = [58171,58172]
operator: = [60119,60120]
===
match
---
param [23489,23493]
param [23489,23493]
===
match
---
parameters [48540,48561]
parameters [48540,48561]
===
match
---
name: e [3323,3324]
name: e [3323,3324]
===
match
---
atom_expr [17045,17121]
atom_expr [17045,17121]
===
match
---
operator: = [20308,20309]
operator: = [20308,20309]
===
match
---
name: dates [54321,54326]
name: dates [56269,56274]
===
match
---
name: dag [34029,34032]
name: dag [34029,34032]
===
match
---
argument [48954,48977]
argument [48954,48977]
===
match
---
name: DAG [59124,59127]
name: DAG [61072,61075]
===
match
---
parameters [37304,37310]
parameters [37304,37310]
===
match
---
suite [36466,36542]
suite [36466,36542]
===
match
---
name: datetime [923,931]
name: datetime [923,931]
===
match
---
simple_stmt [31381,31584]
simple_stmt [31381,31584]
===
match
---
operator: , [26946,26947]
operator: , [26946,26947]
===
match
---
trailer [14801,14803]
trailer [14801,14803]
===
match
---
simple_stmt [22221,22282]
simple_stmt [22221,22282]
===
match
---
argument [12845,12868]
argument [12845,12868]
===
match
---
param [24474,24478]
param [24474,24478]
===
match
---
trailer [15738,15748]
trailer [15738,15748]
===
match
---
simple_stmt [63891,63910]
simple_stmt [65839,65858]
===
match
---
name: dag [45933,45936]
name: dag [45933,45936]
===
match
---
atom_expr [39474,39488]
atom_expr [39474,39488]
===
match
---
operator: = [48657,48658]
operator: = [48657,48658]
===
match
---
name: merge [17458,17463]
name: merge [17458,17463]
===
match
---
name: test_task [16881,16890]
name: test_task [16881,16890]
===
match
---
trailer [38207,38215]
trailer [38207,38215]
===
match
---
operator: < [56458,56459]
operator: < [58406,58407]
===
match
---
operator: { [61603,61604]
operator: { [63551,63552]
===
match
---
operator: = [20568,20569]
operator: = [20568,20569]
===
match
---
shift_expr [37169,37179]
shift_expr [37169,37179]
===
match
---
name: DEPRECATED_ACTION_CAN_DAG_EDIT [61660,61690]
name: DEPRECATED_ACTION_CAN_DAG_EDIT [63608,63638]
===
match
---
name: op4 [9987,9990]
name: op4 [9987,9990]
===
match
---
testlist_comp [46468,46491]
testlist_comp [46468,46491]
===
match
---
name: self [47472,47476]
name: self [47472,47476]
===
match
---
name: settings [48807,48815]
name: settings [48807,48815]
===
match
---
funcdef [39828,40835]
funcdef [39828,40835]
===
match
---
name: width [15742,15747]
name: width [15742,15747]
===
match
---
name: t_1 [52468,52471]
name: t_1 [54416,54419]
===
match
---
name: update [4420,4426]
name: update [4420,4426]
===
match
---
name: parameterized [48400,48413]
name: parameterized [48400,48413]
===
match
---
shift_expr [38064,38074]
shift_expr [38064,38074]
===
match
---
atom_expr [23325,23347]
atom_expr [23325,23347]
===
match
---
operator: , [64566,64567]
operator: , [66514,66515]
===
match
---
operator: = [50715,50716]
operator: = [50715,50716]
===
match
---
trailer [34944,34978]
trailer [34944,34978]
===
match
---
trailer [36193,36230]
trailer [36193,36230]
===
match
---
string: 'airflow' [59351,59360]
string: 'airflow' [61299,61308]
===
match
---
shift_expr [38542,38552]
shift_expr [38542,38552]
===
match
---
trailer [62225,62240]
trailer [64173,64188]
===
match
---
name: test_dagtag_repr [24080,24096]
name: test_dagtag_repr [24080,24096]
===
match
---
trailer [14530,14540]
trailer [14530,14540]
===
match
---
assert_stmt [65422,65449]
assert_stmt [67370,67397]
===
match
---
name: dag_id [27054,27060]
name: dag_id [27054,27060]
===
match
---
name: State [48928,48933]
name: State [48928,48933]
===
match
---
operator: } [10679,10680]
operator: } [10679,10680]
===
match
---
operator: = [28963,28964]
operator: = [28963,28964]
===
match
---
with_stmt [19120,19253]
with_stmt [19120,19253]
===
match
---
name: task [16276,16280]
name: task [16276,16280]
===
match
---
operator: = [50259,50260]
operator: = [50259,50260]
===
match
---
with_stmt [42735,42832]
with_stmt [42735,42832]
===
match
---
trailer [18921,18941]
trailer [18921,18941]
===
match
---
atom_expr [29421,29440]
atom_expr [29421,29440]
===
match
---
trailer [33055,33072]
trailer [33055,33072]
===
match
---
trailer [34630,34692]
trailer [34630,34692]
===
match
---
suite [69044,69072]
suite [70992,71020]
===
match
---
atom_expr [59817,59854]
atom_expr [61765,61802]
===
match
---
name: timezone [12045,12053]
name: timezone [12045,12053]
===
match
---
arglist [55209,55230]
arglist [57157,57178]
===
match
---
string: """         Assert that a occurs before b in the list.         """ [3199,3265]
string: """         Assert that a occurs before b in the list.         """ [3199,3265]
===
match
---
operator: = [65800,65801]
operator: = [67748,67749]
===
match
---
operator: = [10132,10133]
operator: = [10132,10133]
===
match
---
assert_stmt [65826,65853]
assert_stmt [67774,67801]
===
match
---
trailer [23884,23895]
trailer [23884,23895]
===
match
---
name: DAGS_FOLDER [34436,34447]
name: DAGS_FOLDER [34436,34447]
===
match
---
suite [16595,16672]
suite [16595,16672]
===
match
---
operator: = [67609,67610]
operator: = [69557,69558]
===
match
---
argument [28713,28736]
argument [28713,28736]
===
match
---
name: dag [5649,5652]
name: dag [5649,5652]
===
match
---
operator: , [30251,30252]
operator: , [30251,30252]
===
match
---
parameters [35631,35637]
parameters [35631,35637]
===
match
---
trailer [50383,50411]
trailer [50383,50411]
===
match
---
simple_stmt [41531,41548]
simple_stmt [41531,41548]
===
match
---
name: DEFAULT_DATE [64866,64878]
name: DEFAULT_DATE [66814,66826]
===
match
---
atom_expr [20427,20450]
atom_expr [20427,20450]
===
match
---
trailer [59691,59734]
trailer [61639,61682]
===
match
---
atom_expr [32309,32349]
atom_expr [32309,32349]
===
match
---
atom [4212,4229]
atom [4212,4229]
===
match
---
name: dag [40669,40672]
name: dag [40669,40672]
===
match
---
operator: , [59230,59231]
operator: , [61178,61179]
===
match
---
name: DagRun [49607,49613]
name: DagRun [49607,49613]
===
match
---
name: topological_list [10467,10483]
name: topological_list [10467,10483]
===
match
---
assert_stmt [30482,30520]
assert_stmt [30482,30520]
===
match
---
operator: { [24938,24939]
operator: { [24938,24939]
===
match
---
name: dag [37196,37199]
name: dag [37196,37199]
===
match
---
name: SubDagOperator [30979,30993]
name: SubDagOperator [30979,30993]
===
match
---
testlist_comp [48444,48488]
testlist_comp [48444,48488]
===
match
---
arglist [65199,65237]
arglist [67147,67185]
===
match
---
trailer [17396,17404]
trailer [17396,17404]
===
match
---
argument [62465,62472]
argument [64413,64420]
===
match
---
arglist [27560,27601]
arglist [27560,27601]
===
match
---
operator: , [12843,12844]
operator: , [12843,12844]
===
match
---
name: dag [5538,5541]
name: dag [5538,5541]
===
match
---
name: dag [21695,21698]
name: dag [21695,21698]
===
match
---
atom [19333,19348]
atom [19333,19348]
===
match
---
argument [60237,60281]
argument [62185,62229]
===
match
---
trailer [19458,19469]
trailer [19458,19469]
===
match
---
name: pickle [45256,45262]
name: pickle [45256,45262]
===
match
---
string: 'dag.subtask' [28682,28695]
string: 'dag.subtask' [28682,28695]
===
match
---
trailer [20791,20801]
trailer [20791,20801]
===
match
---
name: timedelta [55371,55380]
name: timedelta [57319,57328]
===
match
---
name: DagModel [32252,32260]
name: DagModel [32252,32260]
===
match
---
arglist [56050,56204]
arglist [57998,58152]
===
match
---
operator: , [48014,48015]
operator: , [48014,48015]
===
match
---
name: value [68422,68427]
name: value [70370,70375]
===
match
---
operator: , [62700,62701]
operator: , [64648,64649]
===
match
---
operator: , [48545,48546]
operator: , [48545,48546]
===
match
---
simple_stmt [7228,7251]
simple_stmt [7228,7251]
===
match
---
simple_stmt [37046,37080]
simple_stmt [37046,37080]
===
match
---
name: clear_db_runs [64011,64024]
name: clear_db_runs [65959,65972]
===
match
---
operator: , [54779,54780]
operator: , [56727,56728]
===
match
---
name: session [63611,63618]
name: session [65559,65566]
===
match
---
name: dag [50400,50403]
name: dag [50400,50403]
===
match
---
trailer [29183,29211]
trailer [29183,29211]
===
match
---
name: DeprecationWarning [62132,62150]
name: DeprecationWarning [64080,64098]
===
match
---
simple_stmt [10333,10366]
simple_stmt [10333,10366]
===
match
---
trailer [68625,68683]
trailer [70573,70631]
===
match
---
operator: , [30232,30233]
operator: , [30232,30233]
===
match
---
trailer [25156,25205]
trailer [25156,25205]
===
match
---
expr_stmt [62165,62206]
expr_stmt [64113,64154]
===
match
---
name: dag [20697,20700]
name: dag [20697,20700]
===
match
---
simple_stmt [48220,48350]
simple_stmt [48220,48350]
===
match
---
trailer [12181,12190]
trailer [12181,12190]
===
match
---
arglist [60630,60640]
arglist [62578,62588]
===
match
---
simple_stmt [17014,17031]
simple_stmt [17014,17031]
===
match
---
operator: = [23011,23012]
operator: = [23011,23012]
===
match
---
testlist_comp [35552,35560]
testlist_comp [35552,35560]
===
match
---
name: task_dict [38121,38130]
name: task_dict [38121,38130]
===
match
---
atom [49848,49861]
atom [49848,49861]
===
match
---
arglist [35243,35278]
arglist [35243,35278]
===
match
---
name: warns [62126,62131]
name: warns [64074,64079]
===
match
---
operator: = [53743,53744]
operator: = [55691,55692]
===
match
---
name: create_dagrun [67445,67458]
name: create_dagrun [69393,69406]
===
match
---
operator: , [58334,58335]
operator: , [60282,60283]
===
match
---
operator: , [59469,59470]
operator: , [61417,61418]
===
match
---
name: DEFAULT_DATE [10634,10646]
name: DEFAULT_DATE [10634,10646]
===
match
---
simple_stmt [60509,60527]
simple_stmt [62457,62475]
===
match
---
operator: , [36995,36996]
operator: , [36995,36996]
===
match
---
trailer [20369,20377]
trailer [20369,20377]
===
match
---
name: dag_diff_name [44711,44724]
name: dag_diff_name [44711,44724]
===
match
---
atom_expr [25153,25205]
atom_expr [25153,25205]
===
match
---
operator: , [59472,59473]
operator: , [61420,61421]
===
match
---
name: op1 [6104,6107]
name: op1 [6104,6107]
===
match
---
name: DummyOperator [38433,38446]
name: DummyOperator [38433,38446]
===
match
---
operator: = [52016,52017]
operator: = [53964,53965]
===
match
---
argument [48256,48297]
argument [48256,48297]
===
match
---
name: subdag_id [31644,31653]
name: subdag_id [31644,31653]
===
match
---
shift_expr [37662,37672]
shift_expr [37662,37672]
===
match
---
simple_stmt [39651,39689]
simple_stmt [39651,39689]
===
match
---
atom_expr [22792,22818]
atom_expr [22792,22818]
===
match
---
name: TIMEZONE [12182,12190]
name: TIMEZONE [12182,12190]
===
match
---
number: 2 [22614,22615]
number: 2 [22614,22615]
===
match
---
number: 1 [64852,64853]
number: 1 [66800,66801]
===
match
---
name: start_date [68626,68636]
name: start_date [70574,70584]
===
match
---
name: period_end [28290,28300]
name: period_end [28290,28300]
===
match
---
atom_expr [18960,18980]
atom_expr [18960,18980]
===
match
---
trailer [35984,35998]
trailer [35984,35998]
===
match
---
name: hash [45721,45725]
name: hash [45721,45725]
===
match
---
comparison [34500,34525]
comparison [34500,34525]
===
match
---
name: test_replace_outdated_access_control_actions [61416,61460]
name: test_replace_outdated_access_control_actions [63364,63408]
===
match
---
argument [37115,37127]
argument [37115,37127]
===
match
---
name: dag_id [31531,31537]
name: dag_id [31531,31537]
===
match
---
operator: = [62184,62185]
operator: = [64132,64133]
===
match
---
argument [4736,4770]
argument [4736,4770]
===
match
---
comp_op [39355,39361]
comp_op [39355,39361]
===
match
---
name: self [68971,68975]
name: self [70919,70923]
===
match
---
trailer [29536,29540]
trailer [29536,29540]
===
match
---
name: dag_id [31927,31933]
name: dag_id [31927,31933]
===
match
---
param [67238,67241]
param [69186,69189]
===
match
---
name: execution_date [43645,43659]
name: execution_date [43645,43659]
===
match
---
name: sync_to_db [29055,29065]
name: sync_to_db [29055,29065]
===
match
---
param [64045,64049]
param [65993,65997]
===
match
---
operator: { [34863,34864]
operator: { [34863,34864]
===
match
---
name: width [13640,13645]
name: width [13640,13645]
===
match
---
argument [30142,30251]
argument [30142,30251]
===
match
---
expr_stmt [23273,23308]
expr_stmt [23273,23308]
===
match
---
name: default_args [35068,35080]
name: default_args [35068,35080]
===
match
---
arglist [4636,4710]
arglist [4636,4710]
===
match
---
name: session [33505,33512]
name: session [33505,33512]
===
match
---
name: dag [37025,37028]
name: dag [37025,37028]
===
match
---
simple_stmt [9900,9924]
simple_stmt [9900,9924]
===
match
---
name: datetime [52718,52726]
name: datetime [54666,54674]
===
match
---
trailer [19565,19585]
trailer [19565,19585]
===
match
---
name: self [67117,67121]
name: self [69065,69069]
===
match
---
import_from [2149,2197]
import_from [2149,2197]
===
match
---
trailer [41623,41633]
trailer [41623,41633]
===
match
---
name: row [24861,24864]
name: row [24861,24864]
===
match
---
arglist [42536,42612]
arglist [42536,42612]
===
match
---
trailer [31893,31900]
trailer [31893,31900]
===
match
---
trailer [53364,53387]
trailer [55312,55335]
===
match
---
name: orm_dag [29092,29099]
name: orm_dag [29092,29099]
===
match
---
atom_expr [29051,29082]
atom_expr [29051,29082]
===
match
---
expr_stmt [35919,35952]
expr_stmt [35919,35952]
===
match
---
atom_expr [59495,59669]
atom_expr [61443,61617]
===
match
---
name: range [14404,14409]
name: range [14404,14409]
===
match
---
trailer [29125,29132]
trailer [29125,29132]
===
match
---
name: self [24097,24101]
name: self [24097,24101]
===
match
---
simple_stmt [804,814]
simple_stmt [804,814]
===
match
---
name: dag_models [63865,63875]
name: dag_models [65813,65823]
===
match
---
name: dag [26433,26436]
name: dag [26433,26436]
===
match
---
operator: = [44552,44553]
operator: = [44552,44553]
===
match
---
operator: , [59839,59840]
operator: , [61787,61788]
===
match
---
name: dag_subclass [45815,45827]
name: dag_subclass [45815,45827]
===
match
---
atom_expr [50869,50892]
atom_expr [50869,50892]
===
match
---
name: dag_ [44694,44698]
name: dag_ [44694,44698]
===
match
---
atom_expr [34665,34680]
atom_expr [34665,34680]
===
match
---
trailer [47132,47147]
trailer [47132,47147]
===
match
---
suite [66487,66972]
suite [68435,68920]
===
match
---
simple_stmt [16216,16240]
simple_stmt [16216,16240]
===
match
---
trailer [52467,52523]
trailer [54415,54471]
===
match
---
assert_stmt [62936,62959]
assert_stmt [64884,64907]
===
match
---
operator: == [62954,62956]
operator: == [64902,64904]
===
match
---
trailer [54444,54450]
trailer [56392,56398]
===
match
---
name: dag [32142,32145]
name: dag [32142,32145]
===
match
---
name: self [64045,64049]
name: self [65993,65997]
===
match
---
name: self [8345,8349]
name: self [8345,8349]
===
match
---
string: 'test_dagrun_query_count' [64247,64272]
string: 'test_dagrun_query_count' [66195,66220]
===
match
---
dotted_name [1672,1694]
dotted_name [1672,1694]
===
match
---
parameters [43838,43844]
parameters [43838,43844]
===
match
---
name: session [18239,18246]
name: session [18239,18246]
===
match
---
dictorsetmaker [61747,61896]
dictorsetmaker [63695,63844]
===
match
---
trailer [32291,32364]
trailer [32291,32364]
===
match
---
comparison [3420,3434]
comparison [3420,3434]
===
match
---
trailer [37199,37209]
trailer [37199,37209]
===
match
---
funcdef [60079,60527]
funcdef [62027,62475]
===
match
---
simple_stmt [38084,38102]
simple_stmt [38084,38102]
===
match
---
trailer [22856,22862]
trailer [22856,22862]
===
match
---
comparison [58296,58338]
comparison [60244,60286]
===
match
---
funcdef [66451,66972]
funcdef [68399,68920]
===
match
---
trailer [6658,6662]
trailer [6658,6662]
===
match
---
simple_stmt [34987,35029]
simple_stmt [34987,35029]
===
match
---
param [67849,67853]
param [69797,69801]
===
match
---
name: dag [45612,45615]
name: dag [45612,45615]
===
match
---
trailer [38138,38146]
trailer [38138,38146]
===
match
---
atom_expr [64243,64298]
atom_expr [66191,66246]
===
match
---
simple_stmt [43137,43162]
simple_stmt [43137,43162]
===
match
---
operator: = [35746,35747]
operator: = [35746,35747]
===
match
---
name: merge [49163,49168]
name: merge [49163,49168]
===
match
---
operator: -> [64051,64053]
operator: -> [65999,66001]
===
match
---
argument [52297,52316]
argument [54245,54264]
===
match
---
name: utc [20564,20567]
name: utc [20564,20567]
===
match
---
import_from [879,917]
import_from [879,917]
===
match
---
name: VALUE [69271,69276]
name: VALUE [71219,71224]
===
match
---
param [61461,61465]
param [63409,63413]
===
match
---
trailer [19000,19002]
trailer [19000,19002]
===
match
---
operator: = [50204,50205]
operator: = [50204,50205]
===
match
---
name: catchup [58203,58210]
name: catchup [60151,60158]
===
match
---
trailer [64889,64898]
trailer [66837,66846]
===
match
---
trailer [34822,34839]
trailer [34822,34839]
===
match
---
name: DummyOperator [64348,64361]
name: DummyOperator [66296,66309]
===
match
---
string: 'no rule' [16661,16670]
string: 'no rule' [16661,16670]
===
match
---
operator: = [64994,64995]
operator: = [66942,66943]
===
match
---
name: DAG [37499,37502]
name: DAG [37499,37502]
===
match
---
simple_stmt [11724,11794]
simple_stmt [11724,11794]
===
match
---
name: execution_date [39539,39553]
name: execution_date [39539,39553]
===
match
---
atom_expr [45810,45828]
atom_expr [45810,45828]
===
match
---
name: utcnow [56003,56009]
name: utcnow [57951,57957]
===
match
---
funcdef [8485,9401]
funcdef [8485,9401]
===
match
---
operator: = [19829,19830]
operator: = [19829,19830]
===
match
---
expr_stmt [53936,54027]
expr_stmt [55884,55975]
===
match
---
string: 't1' [55107,55111]
string: 't1' [57055,57059]
===
match
---
expr_stmt [32664,32717]
expr_stmt [32664,32717]
===
match
---
name: dag_run [39179,39186]
name: dag_run [39179,39186]
===
match
---
atom_expr [19690,19696]
atom_expr [19690,19696]
===
match
---
name: TI [16958,16960]
name: TI [16958,16960]
===
match
---
atom_expr [10297,10316]
atom_expr [10297,10316]
===
match
---
funcdef [58793,59855]
funcdef [60741,61803]
===
match
---
atom_expr [24341,24348]
atom_expr [24341,24348]
===
match
---
operator: , [62761,62762]
operator: , [64709,64710]
===
match
---
simple_stmt [9819,9852]
simple_stmt [9819,9852]
===
match
---
name: DEFAULT_DATE [53811,53823]
name: DEFAULT_DATE [55759,55771]
===
match
---
name: self [65513,65517]
name: self [67461,67465]
===
match
---
name: test_normalized_schedule_interval [46698,46731]
name: test_normalized_schedule_interval [46698,46731]
===
match
---
trailer [21017,21027]
trailer [21017,21027]
===
match
---
suite [37930,38075]
suite [37930,38075]
===
match
---
name: DEFAULT_DATE [68670,68682]
name: DEFAULT_DATE [70618,70630]
===
match
---
name: start_date [24547,24557]
name: start_date [24547,24557]
===
match
---
simple_stmt [24513,24613]
simple_stmt [24513,24613]
===
match
---
atom_expr [66048,66065]
atom_expr [67996,68013]
===
match
---
name: tags [25580,25584]
name: tags [25580,25584]
===
match
---
param [8516,8520]
param [8516,8520]
===
match
---
suite [64449,64624]
suite [66397,66572]
===
match
---
name: run_id [47206,47212]
name: run_id [47206,47212]
===
match
---
atom_expr [13386,13408]
atom_expr [13386,13408]
===
match
---
testlist_comp [9086,9099]
testlist_comp [9086,9099]
===
match
---
parameters [65101,65107]
parameters [67049,67055]
===
match
---
name: self [65624,65628]
name: self [67572,67576]
===
match
---
suite [64059,64084]
suite [66007,66032]
===
match
---
with_item [6758,6815]
with_item [6758,6815]
===
match
---
parameters [16404,16410]
parameters [16404,16410]
===
match
---
expr_stmt [68338,68352]
expr_stmt [70286,70300]
===
match
---
name: session [34063,34070]
name: session [34063,34070]
===
match
---
atom_expr [16824,16872]
atom_expr [16824,16872]
===
match
---
with_item [18903,18946]
with_item [18903,18946]
===
match
---
trailer [67577,67590]
trailer [69525,69538]
===
match
---
simple_stmt [24489,24505]
simple_stmt [24489,24505]
===
match
---
simple_stmt [52794,52975]
simple_stmt [54742,54923]
===
match
---
name: DAG [44305,44308]
name: DAG [44305,44308]
===
match
---
name: dag [42818,42821]
name: dag [42818,42821]
===
match
---
name: num [69068,69071]
name: num [71016,71019]
===
match
---
operator: == [44072,44074]
operator: == [44072,44074]
===
match
---
name: test_roots [35141,35151]
name: test_roots [35141,35151]
===
match
---
name: utc [21717,21720]
name: utc [21717,21720]
===
match
---
string: 'end_date' [11782,11792]
string: 'end_date' [11782,11792]
===
match
---
operator: , [32071,32072]
operator: , [32071,32072]
===
match
---
operator: = [30148,30149]
operator: = [30148,30149]
===
match
---
trailer [27040,27046]
trailer [27040,27046]
===
match
---
name: updated_permissions [62085,62104]
name: updated_permissions [64033,64052]
===
match
---
trailer [67735,67754]
trailer [69683,69702]
===
match
---
atom_expr [7205,7212]
atom_expr [7205,7212]
===
match
---
name: State [48445,48450]
name: State [48445,48450]
===
match
---
simple_stmt [66743,66754]
simple_stmt [68691,68702]
===
match
---
operator: = [29100,29101]
operator: = [29100,29101]
===
match
---
arglist [68626,68682]
arglist [70574,70630]
===
match
---
trailer [17572,17574]
trailer [17572,17574]
===
match
---
name: is_active [34310,34319]
name: is_active [34310,34319]
===
match
---
operator: = [62611,62612]
operator: = [64559,64560]
===
match
---
trailer [39105,39168]
trailer [39105,39168]
===
match
---
name: clear_db_dags [2326,2339]
name: clear_db_dags [2326,2339]
===
match
---
expr_stmt [44299,44340]
expr_stmt [44299,44340]
===
match
---
arglist [54876,55051]
arglist [56824,56999]
===
match
---
simple_stmt [54156,54167]
simple_stmt [56104,56115]
===
match
---
expr_stmt [42254,42285]
expr_stmt [42254,42285]
===
match
---
name: TEST_DATE [42428,42437]
name: TEST_DATE [42428,42437]
===
match
---
argument [53262,53302]
argument [55210,55250]
===
match
---
trailer [20578,20593]
trailer [20578,20593]
===
match
---
name: tests [2203,2208]
name: tests [2203,2208]
===
match
---
arglist [62413,62423]
arglist [64361,64371]
===
match
---
operator: = [31785,31786]
operator: = [31785,31786]
===
match
---
operator: == [62241,62243]
operator: == [64189,64191]
===
match
---
arglist [8288,8328]
arglist [8288,8328]
===
match
---
name: timezone [21570,21578]
name: timezone [21570,21578]
===
match
---
name: xcom_pass_to_op [68003,68018]
name: xcom_pass_to_op [69951,69966]
===
match
---
name: DagModel [30377,30385]
name: DagModel [30377,30385]
===
match
---
name: dags [25676,25680]
name: dags [25676,25680]
===
match
---
expr_stmt [46796,46868]
expr_stmt [46796,46868]
===
match
---
comparison [32019,32110]
comparison [32019,32110]
===
match
---
operator: = [41084,41085]
operator: = [41084,41085]
===
match
---
expr_stmt [23606,23648]
expr_stmt [23606,23648]
===
match
---
string: 'test-dag' [26066,26076]
string: 'test-dag' [26066,26076]
===
match
---
name: add_task [39084,39092]
name: add_task [39084,39092]
===
match
---
operator: = [35854,35855]
operator: = [35854,35855]
===
match
---
operator: , [63459,63460]
operator: , [65407,65408]
===
match
---
atom_expr [40397,40481]
atom_expr [40397,40481]
===
match
---
fstring [47661,47698]
fstring [47661,47698]
===
match
---
arglist [43236,43297]
arglist [43236,43297]
===
match
---
name: handle_callback [40621,40636]
name: handle_callback [40621,40636]
===
match
---
atom_expr [34805,34839]
atom_expr [34805,34839]
===
match
---
name: enumerate [13126,13135]
name: enumerate [13126,13135]
===
match
---
name: op3 [9919,9922]
name: op3 [9919,9922]
===
match
---
name: RUNNING [67616,67623]
name: RUNNING [69564,69571]
===
match
---
trailer [64961,64963]
trailer [66909,66911]
===
match
---
name: delta [53737,53742]
name: delta [55685,55690]
===
match
---
atom_expr [47621,47631]
atom_expr [47621,47631]
===
match
---
number: 0 [14566,14567]
number: 0 [14566,14567]
===
match
---
simple_stmt [19217,19253]
simple_stmt [19217,19253]
===
match
---
atom_expr [46885,46917]
atom_expr [46885,46917]
===
match
---
name: next_dagrun_after_date [56703,56725]
name: next_dagrun_after_date [58651,58673]
===
match
---
comparison [54380,54401]
comparison [56328,56349]
===
match
---
assert_stmt [11802,11885]
assert_stmt [11802,11885]
===
match
---
expr_stmt [19910,19958]
expr_stmt [19910,19958]
===
match
---
argument [50384,50398]
argument [50384,50398]
===
match
---
trailer [29198,29204]
trailer [29198,29204]
===
match
---
atom_expr [34105,34157]
atom_expr [34105,34157]
===
match
---
name: self [42992,42996]
name: self [42992,42996]
===
match
---
for_stmt [44690,44812]
for_stmt [44690,44812]
===
match
---
string: 'subtask' [28964,28973]
string: 'subtask' [28964,28973]
===
match
---
fstring_end: ' [64386,64387]
fstring_end: ' [66334,66335]
===
match
---
trailer [52308,52316]
trailer [54256,54264]
===
match
---
string: 'dag_paused' [32577,32589]
string: 'dag_paused' [32577,32589]
===
match
---
atom_expr [32852,32871]
atom_expr [32852,32871]
===
match
---
parameters [66221,66226]
parameters [68169,68174]
===
match
---
trailer [24667,24684]
trailer [24667,24684]
===
match
---
atom [26810,27025]
atom [26810,27025]
===
match
---
param [68798,68802]
param [70746,70750]
===
match
---
name: in_ [31515,31518]
name: in_ [31515,31518]
===
match
---
operator: , [5625,5626]
operator: , [5625,5626]
===
match
---
simple_stmt [65773,65787]
simple_stmt [67721,67735]
===
match
---
simple_stmt [53737,53773]
simple_stmt [55685,55721]
===
match
---
simple_stmt [57663,57713]
simple_stmt [59611,59661]
===
match
---
name: conf [5605,5609]
name: conf [5605,5609]
===
match
---
name: parent_dag_name [60247,60262]
name: parent_dag_name [62195,62210]
===
match
---
simple_stmt [52569,52600]
simple_stmt [54517,54548]
===
match
---
name: one [29537,29540]
name: one [29537,29540]
===
match
---
parameters [9436,9442]
parameters [9436,9442]
===
match
---
operator: , [24545,24546]
operator: , [24545,24546]
===
match
---
trailer [27951,27965]
trailer [27951,27965]
===
match
---
expr_stmt [21460,21554]
expr_stmt [21460,21554]
===
match
---
argument [49243,49266]
argument [49243,49266]
===
match
---
operator: = [67731,67732]
operator: = [69679,69680]
===
match
---
name: airflow [1863,1870]
name: airflow [1863,1870]
===
match
---
name: dag [50205,50208]
name: dag [50205,50208]
===
match
---
trailer [14686,14693]
trailer [14686,14693]
===
match
---
name: test_dag_id [44135,44146]
name: test_dag_id [44135,44146]
===
match
---
simple_stmt [47188,47246]
simple_stmt [47188,47246]
===
match
---
name: convert [23295,23302]
name: convert [23295,23302]
===
match
---
funcdef [28452,29791]
funcdef [28452,29791]
===
match
---
with_stmt [28572,29006]
with_stmt [28572,29006]
===
match
---
operator: == [41834,41836]
operator: == [41834,41836]
===
match
---
operator: == [25150,25152]
operator: == [25150,25152]
===
match
---
operator: , [68469,68470]
operator: , [70417,70418]
===
match
---
argument [24165,24188]
argument [24165,24188]
===
match
---
trailer [6123,6138]
trailer [6123,6138]
===
match
---
atom_expr [47493,47526]
atom_expr [47493,47526]
===
match
---
name: task [13448,13452]
name: task [13448,13452]
===
match
---
expr_stmt [40372,40388]
expr_stmt [40372,40388]
===
match
---
simple_stmt [65826,65854]
simple_stmt [67774,67802]
===
match
---
suite [67011,67804]
suite [68959,69752]
===
match
---
assert_stmt [59797,59854]
assert_stmt [61745,61802]
===
match
---
name: StringIO [36444,36452]
name: StringIO [36444,36452]
===
match
---
expr_stmt [6151,6195]
expr_stmt [6151,6195]
===
match
---
argument [19882,19895]
argument [19882,19895]
===
match
---
name: op3 [10023,10026]
name: op3 [10023,10026]
===
match
---
simple_stmt [65392,65414]
simple_stmt [67340,67362]
===
match
---
operator: != [45062,45064]
operator: != [45062,45064]
===
match
---
atom_expr [20378,20416]
atom_expr [20378,20416]
===
match
---
name: range [13068,13073]
name: range [13068,13073]
===
match
---
name: dr [67436,67438]
name: dr [69384,69386]
===
match
---
atom_expr [21570,21600]
atom_expr [21570,21600]
===
match
---
name: test_dag_param_dagrun_parameterized [67813,67848]
name: test_dag_param_dagrun_parameterized [69761,69796]
===
match
---
atom_expr [34171,34202]
atom_expr [34171,34202]
===
match
---
operator: = [4967,4968]
operator: = [4967,4968]
===
match
---
name: dag_run [39708,39715]
name: dag_run [39708,39715]
===
match
---
name: return_num [66211,66221]
name: return_num [68159,68169]
===
match
---
parameters [59902,59908]
parameters [61850,61856]
===
match
---
argument [7078,7091]
argument [7078,7091]
===
match
---
name: ACTION_CAN_READ [61850,61865]
name: ACTION_CAN_READ [63798,63813]
===
match
---
name: start_date [43454,43464]
name: start_date [43454,43464]
===
match
---
assert_stmt [8186,8253]
assert_stmt [8186,8253]
===
match
---
name: op4 [9953,9956]
name: op4 [9953,9956]
===
match
---
string: ', ' [29205,29209]
string: ', ' [29205,29209]
===
match
---
operator: @ [68890,68891]
operator: @ [70838,70839]
===
match
---
simple_stmt [63611,63627]
simple_stmt [65559,65575]
===
match
---
trailer [47684,47694]
trailer [47684,47694]
===
match
---
argument [60714,60723]
argument [62662,62671]
===
match
---
operator: , [61233,61234]
operator: , [63181,63182]
===
match
---
atom_expr [47672,47696]
atom_expr [47672,47696]
===
match
---
return_stmt [69061,69071]
return_stmt [71009,71019]
===
match
---
name: task_id [36271,36278]
name: task_id [36271,36278]
===
match
---
simple_stmt [51179,51196]
simple_stmt [51179,51196]
===
match
---
name: timezone [62739,62747]
name: timezone [64687,64695]
===
match
---
simple_stmt [40617,40661]
simple_stmt [40617,40661]
===
match
---
trailer [66882,66889]
trailer [68830,68837]
===
match
---
simple_stmt [9452,9528]
simple_stmt [9452,9528]
===
match
---
name: default_view [4772,4784]
name: default_view [4772,4784]
===
match
---
operator: = [9823,9824]
operator: = [9823,9824]
===
match
---
atom [46549,46573]
atom [46549,46573]
===
match
---
name: add_task [42354,42362]
name: add_task [42354,42362]
===
match
---
operator: , [65443,65444]
operator: , [67391,67392]
===
match
---
operator: == [21240,21242]
operator: == [21240,21242]
===
match
---
name: e [3420,3421]
name: e [3420,3421]
===
match
---
operator: , [19393,19394]
operator: , [19393,19394]
===
match
---
name: DAG [21616,21619]
name: DAG [21616,21619]
===
match
---
trailer [36714,36717]
trailer [36714,36717]
===
match
---
name: start_date [27480,27490]
name: start_date [27480,27490]
===
match
---
argument [41416,41443]
argument [41416,41443]
===
match
---
testlist_comp [49876,49890]
testlist_comp [49876,49890]
===
match
---
atom_expr [50227,50292]
atom_expr [50227,50292]
===
match
---
suite [45881,46316]
suite [45881,46316]
===
match
---
operator: = [55592,55593]
operator: = [57540,57541]
===
match
---
trailer [15671,15680]
trailer [15671,15680]
===
match
---
operator: , [46453,46454]
operator: , [46453,46454]
===
match
---
name: orm_dag [34335,34342]
name: orm_dag [34335,34342]
===
match
---
atom_expr [62355,62425]
atom_expr [64303,64373]
===
match
---
param [9437,9441]
param [9437,9441]
===
match
---
name: DagRunType [28067,28077]
name: DagRunType [28067,28077]
===
match
---
trailer [63501,63520]
trailer [65449,65468]
===
match
---
operator: = [48146,48147]
operator: = [48146,48147]
===
match
---
operator: = [41317,41318]
operator: = [41317,41318]
===
match
---
name: NONE [48311,48315]
name: NONE [48311,48315]
===
match
---
trailer [19744,19749]
trailer [19744,19749]
===
match
---
operator: , [64787,64788]
operator: , [66735,66736]
===
match
---
name: settings [63296,63304]
name: settings [65244,65252]
===
match
---
string: 'dummy' [59700,59707]
string: 'dummy' [61648,61655]
===
match
---
name: default_args [10648,10660]
name: default_args [10648,10660]
===
match
---
for_stmt [15990,16085]
for_stmt [15990,16085]
===
match
---
name: default_args [5953,5965]
name: default_args [5953,5965]
===
match
---
name: owner [30110,30115]
name: owner [30110,30115]
===
match
---
trailer [44022,44029]
trailer [44022,44029]
===
match
---
trailer [34559,34569]
trailer [34559,34569]
===
match
---
operator: == [17882,17884]
operator: == [17882,17884]
===
match
---
operator: = [16736,16737]
operator: = [16736,16737]
===
match
---
argument [60837,60907]
argument [62785,62855]
===
match
---
arglist [65440,65448]
arglist [67388,67396]
===
match
---
trailer [5329,5333]
trailer [5329,5333]
===
match
---
simple_stmt [17164,17247]
simple_stmt [17164,17247]
===
match
---
operator: = [14230,14231]
operator: = [14230,14231]
===
match
---
name: DummyOperator [36349,36362]
name: DummyOperator [36349,36362]
===
match
---
simple_stmt [50869,50893]
simple_stmt [50869,50893]
===
match
---
atom_expr [21916,21943]
atom_expr [21916,21943]
===
match
---
operator: , [32079,32080]
operator: , [32079,32080]
===
match
---
name: start_date [7427,7437]
name: start_date [7427,7437]
===
match
---
trailer [17102,17112]
trailer [17102,17112]
===
match
---
arglist [47982,48032]
arglist [47982,48032]
===
match
---
name: datetime [60621,60629]
name: datetime [62569,62577]
===
match
---
param [49956,49961]
param [49956,49961]
===
match
---
simple_stmt [31340,31372]
simple_stmt [31340,31372]
===
match
---
expr_stmt [50421,50449]
expr_stmt [50421,50449]
===
match
---
name: xcom_pass_to_op [67409,67424]
name: xcom_pass_to_op [69357,69372]
===
match
---
atom_expr [37689,37702]
atom_expr [37689,37702]
===
match
---
name: _clean_up [39766,39775]
name: _clean_up [39766,39775]
===
match
---
trailer [67458,67634]
trailer [69406,69582]
===
match
---
atom_expr [9116,9135]
atom_expr [9116,9135]
===
match
---
operator: , [62796,62797]
operator: , [64744,64745]
===
match
---
trailer [24881,24898]
trailer [24881,24898]
===
match
---
atom_expr [14463,14478]
atom_expr [14463,14478]
===
match
---
operator: { [61837,61838]
operator: { [63785,63786]
===
match
---
import_from [1267,1305]
import_from [1267,1305]
===
match
---
string: 'owner2' [30116,30124]
string: 'owner2' [30116,30124]
===
match
---
name: default_args [12363,12375]
name: default_args [12363,12375]
===
match
---
operator: = [42403,42404]
operator: = [42403,42404]
===
match
---
arglist [22601,22615]
arglist [22601,22615]
===
match
---
suite [36238,36718]
suite [36238,36718]
===
match
---
argument [11966,12024]
argument [11966,12024]
===
match
---
trailer [43524,43532]
trailer [43524,43532]
===
match
---
atom_expr [29133,29148]
atom_expr [29133,29148]
===
match
---
simple_stmt [63157,63212]
simple_stmt [65105,65160]
===
match
---
param [46738,46756]
param [46738,46756]
===
match
---
arglist [23707,23745]
arglist [23707,23745]
===
match
---
string: "2018-03-24T03:00:00+01:00" [23351,23378]
string: "2018-03-24T03:00:00+01:00" [23351,23378]
===
match
---
argument [52473,52500]
argument [54421,54448]
===
match
---
name: dag_eq [44703,44709]
name: dag_eq [44703,44709]
===
match
---
name: airflow [1365,1372]
name: airflow [1365,1372]
===
match
---
param [11934,11938]
param [11934,11938]
===
match
---
atom_expr [7334,7461]
atom_expr [7334,7461]
===
match
---
name: dag [43170,43173]
name: dag [43170,43173]
===
match
---
trailer [38656,38704]
trailer [38656,38704]
===
match
---
name: filter [2970,2976]
name: filter [2970,2976]
===
match
---
name: one [33165,33168]
name: one [33165,33168]
===
match
---
assert_stmt [35090,35131]
assert_stmt [35090,35131]
===
match
---
name: DAG [23703,23706]
name: DAG [23703,23706]
===
match
---
name: next_dagrun_after_date [54422,54444]
name: next_dagrun_after_date [56370,56392]
===
match
---
string: 'test_field' [19995,20007]
string: 'test_field' [19995,20007]
===
match
---
operator: = [8829,8830]
operator: = [8829,8830]
===
match
---
simple_stmt [50458,50654]
simple_stmt [50458,50654]
===
match
---
name: dates [54380,54385]
name: dates [56328,56333]
===
match
---
string: 'owner' [8587,8594]
string: 'owner' [8587,8594]
===
match
---
trailer [27689,27705]
trailer [27689,27705]
===
match
---
assert_stmt [66321,66348]
assert_stmt [68269,68296]
===
match
---
expr_stmt [47487,47526]
expr_stmt [47487,47526]
===
match
---
simple_stmt [13478,13511]
simple_stmt [13478,13511]
===
match
---
operator: = [37611,37612]
operator: = [37611,37612]
===
match
---
for_stmt [27095,27196]
for_stmt [27095,27196]
===
match
---
argument [43386,43425]
argument [43386,43425]
===
match
---
expr_stmt [16813,16872]
expr_stmt [16813,16872]
===
match
---
trailer [17996,18019]
trailer [17996,18019]
===
match
---
testlist_comp [51716,51792]
testlist_comp [53664,53740]
===
match
---
suite [36963,37180]
suite [36963,37180]
===
match
---
trailer [34499,34526]
trailer [34499,34526]
===
match
---
comparison [34994,35028]
comparison [34994,35028]
===
match
---
arglist [23781,23842]
arglist [23781,23842]
===
match
---
assert_stmt [56352,56384]
assert_stmt [58300,58332]
===
match
---
atom_expr [17130,17139]
atom_expr [17130,17139]
===
match
---
atom [18185,18199]
atom [18185,18199]
===
match
---
name: dag [23697,23700]
name: dag [23697,23700]
===
match
---
string: 'dag-bulk-sync-3' [26245,26262]
string: 'dag-bulk-sync-3' [26245,26262]
===
match
---
operator: , [59609,59610]
operator: , [61557,61558]
===
match
---
operator: , [60672,60673]
operator: , [62620,62621]
===
match
---
suite [68037,68297]
suite [69985,70245]
===
match
---
simple_stmt [44235,44291]
simple_stmt [44235,44291]
===
match
---
simple_stmt [43793,43816]
simple_stmt [43793,43816]
===
match
---
trailer [30542,30544]
trailer [30542,30544]
===
match
---
number: 5 [15339,15340]
number: 5 [15339,15340]
===
match
---
name: DAG [39053,39056]
name: DAG [39053,39056]
===
match
---
not_test [32631,32654]
not_test [32631,32654]
===
match
---
operator: = [23739,23740]
operator: = [23739,23740]
===
match
---
expr_stmt [66291,66312]
expr_stmt [68239,68260]
===
match
---
name: match [5253,5258]
name: match [5253,5258]
===
match
---
name: session [49038,49045]
name: session [49038,49045]
===
match
---
trailer [67615,67623]
trailer [69563,69571]
===
match
---
operator: + [53854,53855]
operator: + [55802,55803]
===
match
---
simple_stmt [42882,42928]
simple_stmt [42882,42928]
===
match
---
name: DAG [24521,24524]
name: DAG [24521,24524]
===
match
---
trailer [5609,5613]
trailer [5609,5613]
===
match
---
atom_expr [2952,3031]
atom_expr [2952,3031]
===
match
---
return_stmt [65749,65759]
return_stmt [67697,67707]
===
match
---
trailer [21919,21938]
trailer [21919,21938]
===
match
---
argument [51043,51070]
argument [51043,51070]
===
match
---
name: t [24353,24354]
name: t [24353,24354]
===
match
---
name: DagModel [34236,34244]
name: DagModel [34236,34244]
===
match
---
expr_stmt [64866,64910]
expr_stmt [66814,66858]
===
match
---
string: """         Tests that a start_date string with a timezone and an end_date string without a timezone         are accepted and that the timezone from the start carries over the end          This test is a little indirect, it works by setting start and end equal except for the         timezone and then testing for equality after the DAG construction.  They'll be equal         only if the same timezone was applied to both.          An explicit check the `tzinfo` attributes for both are the same is an extra check.         """ [11048,11575]
string: """         Tests that a start_date string with a timezone and an end_date string without a timezone         are accepted and that the timezone from the start carries over the end          This test is a little indirect, it works by setting start and end equal except for the         timezone and then testing for equality after the DAG construction.  They'll be equal         only if the same timezone was applied to both.          An explicit check the `tzinfo` attributes for both are the same is an extra check.         """ [11048,11575]
===
match
---
operator: , [59177,59178]
operator: , [61125,61126]
===
match
---
operator: = [6530,6531]
operator: = [6530,6531]
===
match
---
assert_stmt [54411,54458]
assert_stmt [56359,56406]
===
match
---
assert_stmt [55975,56011]
assert_stmt [57923,57959]
===
match
---
simple_stmt [40372,40389]
simple_stmt [40372,40389]
===
match
---
for_stmt [25219,25320]
for_stmt [25219,25320]
===
match
---
operator: -> [63994,63996]
operator: -> [65942,65944]
===
match
---
atom_expr [24489,24504]
atom_expr [24489,24504]
===
match
---
name: current_task [13324,13336]
name: current_task [13324,13336]
===
match
---
expr_stmt [62349,62425]
expr_stmt [64297,64373]
===
match
---
operator: == [12426,12428]
operator: == [12426,12428]
===
match
---
simple_stmt [22067,22123]
simple_stmt [22067,22123]
===
match
---
string: 'owner' [6053,6060]
string: 'owner' [6053,6060]
===
match
---
operator: , [20416,20417]
operator: , [20416,20417]
===
match
---
simple_stmt [47535,47633]
simple_stmt [47535,47633]
===
match
---
name: dag [53474,53477]
name: dag [55422,55425]
===
match
---
atom_expr [67573,67590]
atom_expr [69521,69538]
===
match
---
param [48124,48128]
param [48124,48128]
===
match
---
operator: , [60637,60638]
operator: , [62585,62586]
===
match
---
operator: == [38705,38707]
operator: == [38705,38707]
===
match
---
trailer [19733,19742]
trailer [19733,19742]
===
match
---
for_stmt [15943,16085]
for_stmt [15943,16085]
===
match
---
name: execution_date [51043,51057]
name: execution_date [51043,51057]
===
match
---
name: patcher_dag_code [2524,2540]
name: patcher_dag_code [2524,2540]
===
match
---
name: ACTION_CAN_EDIT [61564,61579]
name: ACTION_CAN_EDIT [63512,63527]
===
match
---
simple_stmt [32933,32996]
simple_stmt [32933,32996]
===
match
---
name: list_ [3338,3343]
name: list_ [3338,3343]
===
match
---
atom [6052,6071]
atom [6052,6071]
===
match
---
trailer [47892,47897]
trailer [47892,47897]
===
match
---
atom_expr [24223,24239]
atom_expr [24223,24239]
===
match
---
name: dag [32726,32729]
name: dag [32726,32729]
===
match
---
atom_expr [49768,49780]
atom_expr [49768,49780]
===
match
---
atom_expr [23013,23040]
atom_expr [23013,23040]
===
match
---
trailer [29204,29210]
trailer [29204,29210]
===
match
---
simple_stmt [2471,2487]
simple_stmt [2471,2487]
===
match
---
name: execution_date [64584,64598]
name: execution_date [66532,66546]
===
match
---
simple_stmt [42015,42171]
simple_stmt [42015,42171]
===
match
---
name: task_id [55099,55106]
name: task_id [57047,57054]
===
match
---
trailer [26347,26396]
trailer [26347,26396]
===
match
---
simple_stmt [44777,44812]
simple_stmt [44777,44812]
===
match
---
trailer [7965,7985]
trailer [7965,7985]
===
match
---
parameters [64940,64946]
parameters [66888,66894]
===
match
---
name: session [50421,50428]
name: session [50421,50428]
===
match
---
atom_expr [6829,6857]
atom_expr [6829,6857]
===
match
---
trailer [68156,68173]
trailer [70104,70121]
===
match
---
arglist [22583,22650]
arglist [22583,22650]
===
match
---
atom_expr [50040,50062]
atom_expr [50040,50062]
===
match
---
trailer [50693,50860]
trailer [50693,50860]
===
match
---
name: DummyOperator [8831,8844]
name: DummyOperator [8831,8844]
===
match
---
trailer [20026,20039]
trailer [20026,20039]
===
match
---
argument [28529,28552]
argument [28529,28552]
===
match
---
expr_stmt [20299,20344]
expr_stmt [20299,20344]
===
match
---
atom_expr [6655,6662]
atom_expr [6655,6662]
===
match
---
arglist [27979,28117]
arglist [27979,28117]
===
match
---
trailer [66052,66065]
trailer [68000,68013]
===
match
---
string: 'subdag' [31002,31010]
string: 'subdag' [31002,31010]
===
match
---
string: 'dag' [15376,15381]
string: 'dag' [15376,15381]
===
match
---
trailer [50908,50914]
trailer [50908,50914]
===
match
---
atom_expr [31425,31440]
atom_expr [31425,31440]
===
match
---
atom_expr [62816,62836]
atom_expr [64764,64784]
===
match
---
operator: = [31814,31815]
operator: = [31814,31815]
===
match
---
trailer [6927,6933]
trailer [6927,6933]
===
match
---
name: dag_id [3094,3100]
name: dag_id [3094,3100]
===
match
---
name: range [15792,15797]
name: range [15792,15797]
===
match
---
trailer [40504,40518]
trailer [40504,40518]
===
match
---
operator: = [64406,64407]
operator: = [66354,66355]
===
match
---
simple_stmt [7322,7462]
simple_stmt [7322,7462]
===
match
---
operator: , [62472,62473]
operator: , [64420,64421]
===
match
---
name: default_view [29923,29935]
name: default_view [29923,29935]
===
match
---
operator: = [30115,30116]
operator: = [30115,30116]
===
match
---
argument [27560,27575]
argument [27560,27575]
===
match
---
trailer [35457,35471]
trailer [35457,35471]
===
match
---
atom_expr [58309,58338]
atom_expr [60257,60286]
===
match
---
arith_expr [50231,50247]
arith_expr [50231,50247]
===
match
---
trailer [61797,61813]
trailer [63745,63761]
===
match
---
name: orm_dag [63716,63723]
name: orm_dag [65664,65671]
===
match
---
name: next_date [58296,58305]
name: next_date [60244,60253]
===
match
---
string: 'parameter1' [4213,4225]
string: 'parameter1' [4213,4225]
===
match
---
name: timezone [58309,58317]
name: timezone [60257,60265]
===
match
---
operator: = [48223,48224]
operator: = [48223,48224]
===
match
---
argument [53764,53771]
argument [55712,55719]
===
match
---
atom_expr [24142,24214]
atom_expr [24142,24214]
===
match
---
operator: , [60907,60908]
operator: , [62855,62856]
===
match
---
parameters [2646,2652]
parameters [2646,2652]
===
match
---
expr_stmt [16724,16771]
expr_stmt [16724,16771]
===
match
---
name: dag_id [42951,42957]
name: dag_id [42951,42957]
===
match
---
name: args [44235,44239]
name: args [44235,44239]
===
match
---
comparison [54418,54458]
comparison [56366,56406]
===
match
---
name: test_duplicate_task_ids_for_same_task_is_allowed [37734,37782]
name: test_duplicate_task_ids_for_same_task_is_allowed [37734,37782]
===
match
---
trailer [40795,40801]
trailer [40795,40801]
===
match
---
operator: , [51390,51391]
operator: , [51390,51391]
===
match
---
name: DagModel [33123,33131]
name: DagModel [33123,33131]
===
match
---
operator: = [22762,22763]
operator: = [22762,22763]
===
match
---
name: warns [61928,61933]
name: warns [63876,63881]
===
match
---
trailer [4419,4426]
trailer [4419,4426]
===
match
---
operator: = [31186,31187]
operator: = [31186,31187]
===
match
---
string: 'role1' [61513,61520]
string: 'role1' [63461,63468]
===
match
---
name: op4 [35438,35441]
name: op4 [35438,35441]
===
match
---
operator: = [48332,48333]
operator: = [48332,48333]
===
match
---
simple_stmt [69236,69277]
simple_stmt [71184,71225]
===
match
---
operator: = [47865,47866]
operator: = [47865,47866]
===
match
---
name: start_date [50112,50122]
name: start_date [50112,50122]
===
match
---
operator: , [18229,18230]
operator: , [18229,18230]
===
match
---
operator: = [55725,55726]
operator: = [57673,57674]
===
match
---
atom_expr [27177,27183]
atom_expr [27177,27183]
===
match
---
operator: = [4659,4660]
operator: = [4659,4660]
===
match
---
name: self [8116,8120]
name: self [8116,8120]
===
match
---
name: dag [55113,55116]
name: dag [57061,57064]
===
match
---
simple_stmt [47346,47367]
simple_stmt [47346,47367]
===
match
---
name: DAG [28166,28169]
name: DAG [28166,28169]
===
match
---
dotted_name [2052,2074]
dotted_name [2052,2074]
===
match
---
name: close [18432,18437]
name: close [18432,18437]
===
match
---
operator: , [57291,57292]
operator: , [59239,59240]
===
match
---
operator: = [35327,35328]
operator: = [35327,35328]
===
match
---
trailer [5059,5061]
trailer [5059,5061]
===
match
---
trailer [23678,23688]
trailer [23678,23688]
===
match
---
atom_expr [32635,32654]
atom_expr [32635,32654]
===
match
---
simple_stmt [17477,17496]
simple_stmt [17477,17496]
===
match
---
trailer [43330,43337]
trailer [43330,43337]
===
match
---
suite [40897,41968]
suite [40897,41968]
===
match
---
atom_expr [33433,33491]
atom_expr [33433,33491]
===
match
---
trailer [9044,9049]
trailer [9044,9049]
===
match
---
arglist [60438,60494]
arglist [62386,62442]
===
match
---
name: op8 [7058,7061]
name: op8 [7058,7061]
===
match
---
name: start_date [36206,36216]
name: start_date [36206,36216]
===
match
---
atom_expr [21743,21765]
atom_expr [21743,21765]
===
match
---
trailer [31852,31859]
trailer [31852,31859]
===
match
---
operator: + [49302,49303]
operator: + [49302,49303]
===
match
---
name: task [14773,14777]
name: task [14773,14777]
===
match
---
argument [9469,9492]
argument [9469,9492]
===
match
---
simple_stmt [62845,62861]
simple_stmt [64793,64809]
===
match
---
simple_stmt [65796,65818]
simple_stmt [67744,67766]
===
match
---
name: datetime [22592,22600]
name: datetime [22592,22600]
===
match
---
dotted_name [64090,64110]
dotted_name [66038,66058]
===
match
---
trailer [43222,43299]
trailer [43222,43299]
===
match
---
operator: { [61756,61757]
operator: { [63704,63705]
===
match
---
expr_stmt [44539,44597]
expr_stmt [44539,44597]
===
match
---
arglist [57749,57759]
arglist [59697,59707]
===
match
---
name: start_date [63449,63459]
name: start_date [65397,65407]
===
match
---
simple_stmt [56487,56677]
simple_stmt [58435,58625]
===
match
---
atom_expr [52414,52437]
atom_expr [54362,54385]
===
match
---
dotted_name [1575,1593]
dotted_name [1575,1593]
===
match
---
simple_stmt [6617,6640]
simple_stmt [6617,6640]
===
match
---
name: dag2 [56236,56240]
name: dag2 [58184,58188]
===
match
---
import_from [1189,1228]
import_from [1189,1228]
===
match
---
argument [40540,40566]
argument [40540,40566]
===
match
---
string: "t5" [35993,35997]
string: "t5" [35993,35997]
===
match
---
name: operator [67649,67657]
name: operator [69597,69605]
===
match
---
argument [48690,48713]
argument [48690,48713]
===
match
---
atom_expr [17993,18111]
atom_expr [17993,18111]
===
match
---
assert_stmt [18120,18256]
assert_stmt [18120,18256]
===
match
---
simple_stmt [21564,21601]
simple_stmt [21564,21601]
===
match
---
name: query [51508,51513]
name: query [51508,51513]
===
match
---
name: timedelta [52727,52736]
name: timedelta [54675,54684]
===
match
---
trailer [31990,31992]
trailer [31990,31992]
===
match
---
operator: , [9492,9493]
operator: , [9492,9493]
===
match
---
assert_stmt [17873,17972]
assert_stmt [17873,17972]
===
match
---
operator: , [14077,14078]
operator: , [14077,14078]
===
match
---
testlist_comp [12954,13041]
testlist_comp [12954,13041]
===
match
---
string: """         Tests that an attempt to schedule a task after the Dag's end_date         does not succeed.         """ [53613,53728]
string: """         Tests that an attempt to schedule a task after the Dag's end_date         does not succeed.         """ [55561,55676]
===
match
---
operator: >> [38523,38525]
operator: >> [38523,38525]
===
match
---
shift_expr [38519,38529]
shift_expr [38519,38529]
===
match
---
name: dag [11731,11734]
name: dag [11731,11734]
===
match
---
name: weight [13009,13015]
name: weight [13009,13015]
===
match
---
comp_op [38815,38821]
comp_op [38815,38821]
===
match
---
trailer [23999,24006]
trailer [23999,24006]
===
match
---
arglist [21620,21677]
arglist [21620,21677]
===
match
---
name: session [26348,26355]
name: session [26348,26355]
===
match
---
operator: = [17421,17422]
operator: = [17421,17422]
===
match
---
operator: = [41217,41218]
operator: = [41217,41218]
===
match
---
operator: + [52716,52717]
operator: + [54664,54665]
===
match
---
name: DummyOperator [35971,35984]
name: DummyOperator [35971,35984]
===
match
---
simple_stmt [27546,27603]
simple_stmt [27546,27603]
===
match
---
name: SubDagOperator [1802,1816]
name: SubDagOperator [1802,1816]
===
match
---
simple_stmt [63323,63574]
simple_stmt [65271,65522]
===
match
---
name: task [20069,20073]
name: task [20069,20073]
===
match
---
name: utcnow [64779,64785]
name: utcnow [66727,66733]
===
match
---
name: io [811,813]
name: io [811,813]
===
match
---
atom_expr [31704,31792]
atom_expr [31704,31792]
===
match
---
name: DagModel [33558,33566]
name: DagModel [33558,33566]
===
match
---
trailer [69150,69159]
trailer [71098,71107]
===
match
---
name: dag_id [3084,3090]
name: dag_id [3084,3090]
===
match
---
trailer [18994,19000]
trailer [18994,19000]
===
match
---
arglist [26362,26388]
arglist [26362,26388]
===
match
---
operator: == [34269,34271]
operator: == [34269,34271]
===
match
---
funcdef [59860,61407]
funcdef [61808,63355]
===
match
---
simple_stmt [35781,35815]
simple_stmt [35781,35815]
===
match
---
operator: , [32339,32340]
operator: , [32339,32340]
===
match
---
operator: = [51484,51485]
operator: = [51484,51485]
===
match
---
expr_stmt [20955,20990]
expr_stmt [20955,20990]
===
match
---
atom_expr [51573,51586]
atom_expr [51573,51586]
===
match
---
operator: , [31621,31622]
operator: , [31621,31622]
===
match
---
param [54675,54693]
param [56623,56641]
===
match
---
operator: , [58215,58216]
operator: , [60163,60164]
===
match
---
name: _next [23969,23974]
name: _next [23969,23974]
===
match
---
operator: , [62417,62418]
operator: , [64365,64366]
===
match
---
name: State [47887,47892]
name: State [47887,47892]
===
match
---
atom_expr [28493,28563]
atom_expr [28493,28563]
===
match
---
decorator [66179,66195]
decorator [68127,68143]
===
match
---
name: setUp [2442,2447]
name: setUp [2442,2447]
===
match
---
trailer [3057,3067]
trailer [3057,3067]
===
match
---
decorator [65184,65239]
decorator [67132,67187]
===
match
---
operator: = [18670,18671]
operator: = [18670,18671]
===
match
---
decorated [39789,40835]
decorated [39789,40835]
===
match
---
suite [6509,6561]
suite [6509,6561]
===
match
---
simple_stmt [28941,29006]
simple_stmt [28941,29006]
===
match
---
string: "graph" [29936,29943]
string: "graph" [29936,29943]
===
match
---
name: self [42000,42004]
name: self [42000,42004]
===
match
---
trailer [46625,46635]
trailer [46625,46635]
===
match
---
arglist [15739,15747]
arglist [15739,15747]
===
match
---
name: DEFAULT_DATE [49289,49301]
name: DEFAULT_DATE [49289,49301]
===
match
---
trailer [6933,6936]
trailer [6933,6936]
===
match
---
operator: = [19185,19186]
operator: = [19185,19186]
===
match
---
name: task_instances [52794,52808]
name: task_instances [54742,54756]
===
match
---
operator: = [42427,42428]
operator: = [42427,42428]
===
match
---
name: self [2599,2603]
name: self [2599,2603]
===
match
---
name: BaseOperator [43223,43235]
name: BaseOperator [43223,43235]
===
match
---
trailer [2722,2739]
trailer [2722,2739]
===
match
---
number: 1 [4227,4228]
number: 1 [4227,4228]
===
match
---
operator: = [62025,62026]
operator: = [63973,63974]
===
match
---
operator: = [9666,9667]
operator: = [9666,9667]
===
match
---
simple_stmt [10784,10838]
simple_stmt [10784,10838]
===
match
---
trailer [63687,63689]
trailer [65635,65637]
===
match
---
simple_stmt [14719,14756]
simple_stmt [14719,14756]
===
match
---
parameters [68964,68982]
parameters [70912,70930]
===
match
---
string: 'dummy' [63242,63249]
string: 'dummy' [65190,65197]
===
match
---
name: ti1 [16952,16955]
name: ti1 [16952,16955]
===
match
---
trailer [50914,50924]
trailer [50914,50924]
===
match
---
param [54503,54507]
param [56451,56455]
===
match
---
simple_stmt [8735,8768]
simple_stmt [8735,8768]
===
match
---
trailer [34309,34319]
trailer [34309,34319]
===
match
---
with_stmt [35715,36093]
with_stmt [35715,36093]
===
match
---
name: isoformat [22080,22089]
name: isoformat [22080,22089]
===
match
---
trailer [54293,54299]
trailer [56241,56247]
===
match
---
suite [37789,38240]
suite [37789,38240]
===
match
---
name: dag_id [40170,40176]
name: dag_id [40170,40176]
===
match
---
string: 'test_pickling' [43868,43883]
string: 'test_pickling' [43868,43883]
===
match
---
operator: , [2387,2388]
operator: , [2387,2388]
===
match
---
parameters [61460,61466]
parameters [63408,63414]
===
match
---
name: parameterized [1194,1207]
name: parameterized [1194,1207]
===
match
---
comparison [45401,45420]
comparison [45401,45420]
===
match
---
simple_stmt [839,853]
simple_stmt [839,853]
===
match
---
name: settings [34073,34081]
name: settings [34073,34081]
===
match
---
name: clear_db_runs [47056,47069]
name: clear_db_runs [47056,47069]
===
match
---
trailer [28664,28751]
trailer [28664,28751]
===
match
---
suite [19532,20162]
suite [19532,20162]
===
match
---
argument [68397,68427]
argument [70345,70375]
===
match
---
name: task_id [36363,36370]
name: task_id [36363,36370]
===
match
---
string: 'start_date' [34864,34876]
string: 'start_date' [34864,34876]
===
match
---
string: 'dag' [29444,29449]
string: 'dag' [29444,29449]
===
match
---
simple_stmt [35167,35226]
simple_stmt [35167,35226]
===
match
---
name: assert_queries_count [24627,24647]
name: assert_queries_count [24627,24647]
===
match
---
argument [30015,30029]
argument [30015,30029]
===
match
---
trailer [9268,9271]
trailer [9268,9271]
===
match
---
with_item [60541,60742]
with_item [62489,62690]
===
match
---
simple_stmt [50040,50063]
simple_stmt [50040,50063]
===
match
---
name: DummyOperator [7828,7841]
name: DummyOperator [7828,7841]
===
match
---
name: dag [6666,6669]
name: dag [6666,6669]
===
match
---
operator: , [20515,20516]
operator: , [20515,20516]
===
match
---
operator: = [4246,4247]
operator: = [4246,4247]
===
match
---
trailer [31252,31273]
trailer [31252,31273]
===
match
---
simple_stmt [15331,15341]
simple_stmt [15331,15341]
===
match
---
param [38901,38905]
param [38901,38905]
===
match
---
name: session [31411,31418]
name: session [31411,31418]
===
match
---
name: permissions [61523,61534]
name: permissions [63471,63482]
===
match
---
suite [46787,47008]
suite [46787,47008]
===
match
---
name: expand [48414,48420]
name: expand [48414,48420]
===
match
---
name: DAG [5917,5920]
name: DAG [5917,5920]
===
match
---
name: DEFAULT_DATE [52060,52072]
name: DEFAULT_DATE [54008,54020]
===
match
---
expr_stmt [49071,49146]
expr_stmt [49071,49146]
===
match
---
trailer [40755,40782]
trailer [40755,40782]
===
match
---
name: prev [22132,22136]
name: prev [22132,22136]
===
match
---
testlist_comp [26047,26076]
testlist_comp [26047,26076]
===
match
---
operator: , [51041,51042]
operator: , [51041,51042]
===
match
---
atom_expr [24882,24897]
atom_expr [24882,24897]
===
match
---
name: MANUAL [67490,67496]
name: MANUAL [69438,69444]
===
match
---
name: dag [4470,4473]
name: dag [4470,4473]
===
match
---
name: session [63582,63589]
name: session [65530,65537]
===
match
---
argument [39147,39167]
argument [39147,39167]
===
match
---
trailer [34261,34268]
trailer [34261,34268]
===
match
---
trailer [10224,10227]
trailer [10224,10227]
===
match
---
name: topological_list [8462,8478]
name: topological_list [8462,8478]
===
match
---
trailer [9986,9991]
trailer [9986,9991]
===
match
---
name: xcom_arg [69142,69150]
name: xcom_arg [71090,71098]
===
match
---
atom_expr [43793,43815]
atom_expr [43793,43815]
===
match
---
operator: = [35067,35068]
operator: = [35067,35068]
===
match
---
decorator [65280,65296]
decorator [67228,67244]
===
match
---
name: TEST_DATE [64599,64608]
name: TEST_DATE [66547,66556]
===
match
---
string: 'dag-test-dagtag' [24146,24163]
string: 'dag-test-dagtag' [24146,24163]
===
match
---
name: DAG [47781,47784]
name: DAG [47781,47784]
===
match
---
arglist [63234,63275]
arglist [65182,65223]
===
match
---
name: self [67849,67853]
name: self [69797,69801]
===
match
---
operator: = [14884,14885]
operator: = [14884,14885]
===
match
---
name: NONE [47404,47408]
name: NONE [47404,47408]
===
match
---
operator: , [68427,68428]
operator: , [70375,70376]
===
match
---
name: state [42593,42598]
name: state [42593,42598]
===
match
---
sync_comp_for [24349,24428]
sync_comp_for [24349,24428]
===
match
---
operator: , [25780,25781]
operator: , [25780,25781]
===
match
---
trailer [42604,42612]
trailer [42604,42612]
===
match
---
name: self [46732,46736]
name: self [46732,46736]
===
match
---
param [32552,32556]
param [32552,32556]
===
match
---
name: e [3361,3362]
name: e [3361,3362]
===
match
---
name: op3 [8956,8959]
name: op3 [8956,8959]
===
match
---
string: "test_dag" [38324,38334]
string: "test_dag" [38324,38334]
===
match
---
atom_expr [58009,58226]
atom_expr [59957,60174]
===
match
---
name: next_date [58504,58513]
name: next_date [60452,60461]
===
match
---
simple_stmt [45429,45461]
simple_stmt [45429,45461]
===
match
---
operator: { [60470,60471]
operator: { [62418,62419]
===
match
---
operator: = [16965,16966]
operator: = [16965,16966]
===
match
---
expr_stmt [4944,4996]
expr_stmt [4944,4996]
===
match
---
string: 'owner1' [9517,9525]
string: 'owner1' [9517,9525]
===
match
---
name: priority_weight [14272,14287]
name: priority_weight [14272,14287]
===
match
---
name: default_view [29292,29304]
name: default_view [29292,29304]
===
match
---
name: dag [27948,27951]
name: dag [27948,27951]
===
match
---
atom [17727,17741]
atom [17727,17741]
===
match
---
argument [49126,49145]
argument [49126,49145]
===
match
---
name: dag_fileloc [34043,34054]
name: dag_fileloc [34043,34054]
===
match
---
import_from [918,948]
import_from [918,948]
===
match
---
name: default_args [43979,43991]
name: default_args [43979,43991]
===
match
---
param [44120,44124]
param [44120,44124]
===
match
---
expr_stmt [28652,28751]
expr_stmt [28652,28751]
===
match
---
name: op1 [9639,9642]
name: op1 [9639,9642]
===
match
---
operator: = [42383,42384]
operator: = [42383,42384]
===
match
---
name: self [68228,68232]
name: self [70176,70180]
===
match
---
name: a_index [3484,3491]
name: a_index [3484,3491]
===
match
---
name: op2 [35827,35830]
name: op2 [35827,35830]
===
match
---
arglist [68157,68172]
arglist [70105,70120]
===
match
---
string: 'end_date' [11867,11877]
string: 'end_date' [11867,11877]
===
match
---
string: 't3' [36694,36698]
string: 't3' [36694,36698]
===
match
---
name: DagTag [24387,24393]
name: DagTag [24387,24393]
===
match
---
string: 'DAG' [12093,12098]
string: 'DAG' [12093,12098]
===
match
---
operator: = [54180,54181]
operator: = [56128,56129]
===
match
---
name: Session [63305,63312]
name: Session [65253,65260]
===
match
---
operator: = [64921,64922]
operator: = [66869,66870]
===
match
---
simple_stmt [23504,23598]
simple_stmt [23504,23598]
===
match
---
name: dag [43355,43358]
name: dag [43355,43358]
===
match
---
name: num [65323,65326]
name: num [67271,67274]
===
match
---
trailer [45295,45301]
trailer [45295,45301]
===
match
---
number: 4 [17775,17776]
number: 4 [17775,17776]
===
match
---
operator: = [63643,63644]
operator: = [65591,65592]
===
match
---
simple_stmt [19659,19698]
simple_stmt [19659,19698]
===
match
---
atom_expr [47887,47897]
atom_expr [47887,47897]
===
match
---
expr_stmt [69085,69113]
expr_stmt [71033,71061]
===
match
---
name: DummyOperator [7064,7077]
name: DummyOperator [7064,7077]
===
match
---
string: 'dag' [12838,12843]
string: 'dag' [12838,12843]
===
match
---
trailer [17237,17245]
trailer [17237,17245]
===
match
---
name: configuration [1280,1293]
name: configuration [1280,1293]
===
match
---
parameters [3176,3189]
parameters [3176,3189]
===
match
---
with_stmt [26571,27196]
with_stmt [26571,27196]
===
match
---
simple_stmt [28905,28929]
simple_stmt [28905,28929]
===
match
---
name: session [49155,49162]
name: session [49155,49162]
===
match
---
arglist [62569,62797]
arglist [64517,64745]
===
match
---
operator: , [59845,59846]
operator: , [61793,61794]
===
match
---
trailer [46281,46288]
trailer [46281,46288]
===
match
---
operator: = [68364,68365]
operator: = [70312,70313]
===
match
---
name: DAGsubclass [44631,44642]
name: DAGsubclass [44631,44642]
===
match
---
simple_stmt [54411,54459]
simple_stmt [56359,56407]
===
match
---
operator: = [50152,50153]
operator: = [50152,50153]
===
match
---
operator: , [35253,35254]
operator: , [35253,35254]
===
match
---
atom [18630,18650]
atom [18630,18650]
===
match
---
argument [28975,28989]
argument [28975,28989]
===
match
---
simple_stmt [27513,27537]
simple_stmt [27513,27537]
===
match
---
trailer [48681,48733]
trailer [48681,48733]
===
match
---
name: xcom_pull [67778,67787]
name: xcom_pull [69726,69735]
===
match
---
trailer [9354,9357]
trailer [9354,9357]
===
match
---
trailer [55568,55577]
trailer [57516,57525]
===
match
---
atom_expr [9458,9527]
atom_expr [9458,9527]
===
match
---
name: op2 [37607,37610]
name: op2 [37607,37610]
===
match
---
name: model [28269,28274]
name: model [28269,28274]
===
match
---
operator: , [1991,1992]
operator: , [1991,1992]
===
match
---
simple_stmt [52447,52524]
simple_stmt [54395,54472]
===
match
---
name: datetime [2082,2090]
name: datetime [2082,2090]
===
match
---
atom_expr [7235,7242]
atom_expr [7235,7242]
===
match
---
name: TEST_DATE [2356,2365]
name: TEST_DATE [2356,2365]
===
match
---
name: add [63590,63593]
name: add [65538,65541]
===
match
---
argument [67662,67690]
argument [69610,69638]
===
match
---
name: session [31202,31209]
name: session [31202,31209]
===
match
---
simple_stmt [62816,62837]
simple_stmt [64764,64785]
===
match
---
atom_expr [33421,33492]
atom_expr [33421,33492]
===
match
---
name: is_paused [32261,32270]
name: is_paused [32261,32270]
===
match
---
expr_stmt [22132,22167]
expr_stmt [22132,22167]
===
match
---
expr_stmt [52101,52146]
expr_stmt [54049,54094]
===
match
---
name: session [29775,29782]
name: session [29775,29782]
===
match
---
string: 'dag-bulk-sync-2' [25782,25799]
string: 'dag-bulk-sync-2' [25782,25799]
===
match
---
operator: = [21963,21964]
operator: = [21963,21964]
===
match
---
trailer [48228,48242]
trailer [48228,48242]
===
match
---
atom_expr [51078,51091]
atom_expr [51078,51091]
===
match
---
name: dag [63157,63160]
name: dag [65105,65108]
===
match
---
atom_expr [9338,9357]
atom_expr [9338,9357]
===
match
---
atom_expr [20115,20130]
atom_expr [20115,20130]
===
match
---
operator: , [60105,60106]
operator: , [62053,62054]
===
match
---
string: 'test_scheduler_verify_max_active_runs' [27439,27478]
string: 'test_scheduler_verify_max_active_runs' [27439,27478]
===
match
---
name: State [49849,49854]
name: State [49849,49854]
===
match
---
atom_expr [40812,40834]
atom_expr [40812,40834]
===
match
---
name: assert_queries_count [2273,2293]
name: assert_queries_count [2273,2293]
===
match
---
trailer [46263,46270]
trailer [46263,46270]
===
match
---
arglist [17623,17665]
arglist [17623,17665]
===
match
---
name: timezone [12161,12169]
name: timezone [12161,12169]
===
match
---
atom_expr [56028,56214]
atom_expr [57976,58162]
===
match
---
import_from [949,988]
import_from [949,988]
===
match
---
name: section_1 [60941,60950]
name: section_1 [62889,62898]
===
match
---
operator: = [63294,63295]
operator: = [65242,65243]
===
match
---
operator: == [24401,24403]
operator: == [24401,24403]
===
match
---
suite [6351,6399]
suite [6351,6399]
===
match
---
name: Session [48816,48823]
name: Session [48816,48823]
===
match
---
name: setUp [64935,64940]
name: setUp [66883,66888]
===
match
---
operator: , [10793,10794]
operator: , [10793,10794]
===
match
---
simple_stmt [1155,1189]
simple_stmt [1155,1189]
===
match
---
name: dag [13386,13389]
name: dag [13386,13389]
===
match
---
name: parent_dag [7586,7596]
name: parent_dag [7586,7596]
===
match
---
operator: = [6000,6001]
operator: = [6000,6001]
===
match
---
operator: } [8604,8605]
operator: } [8604,8605]
===
match
---
argument [54953,54974]
argument [56901,56922]
===
match
---
name: external_trigger [43546,43562]
name: external_trigger [43546,43562]
===
match
---
operator: = [10633,10634]
operator: = [10633,10634]
===
match
---
name: id [38654,38656]
name: id [38654,38656]
===
match
---
atom_expr [57166,57385]
atom_expr [59114,59333]
===
match
---
argument [59692,59707]
argument [61640,61655]
===
match
---
trailer [60620,60629]
trailer [62568,62577]
===
match
---
trailer [47694,47696]
trailer [47694,47696]
===
match
---
name: task [19408,19412]
name: task [19408,19412]
===
match
---
atom_expr [46965,46986]
atom_expr [46965,46986]
===
match
---
argument [17313,17369]
argument [17313,17369]
===
match
---
simple_stmt [50301,50356]
simple_stmt [50301,50356]
===
match
---
name: dag1 [55810,55814]
name: dag1 [57758,57762]
===
match
---
trailer [50519,50532]
trailer [50519,50532]
===
match
---
operator: = [52809,52810]
operator: = [54757,54758]
===
match
---
string: "t4" [35947,35951]
string: "t4" [35947,35951]
===
match
---
string: 'test_scheduler_dagrun_once_with_timedelta_and_catchup_true' [58026,58086]
string: 'test_scheduler_dagrun_once_with_timedelta_and_catchup_true' [59974,60034]
===
match
---
arglist [11959,12024]
arglist [11959,12024]
===
match
---
trailer [39192,39206]
trailer [39192,39206]
===
match
---
dotted_name [1435,1449]
dotted_name [1435,1449]
===
match
---
param [47760,47764]
param [47760,47764]
===
match
---
operator: , [54974,54975]
operator: , [56922,56923]
===
match
---
string: "2018-03-24T03:00:00+01:00" [22905,22932]
string: "2018-03-24T03:00:00+01:00" [22905,22932]
===
match
---
name: dag [3770,3773]
name: dag [3770,3773]
===
match
---
name: task_id [8755,8762]
name: task_id [8755,8762]
===
match
---
suite [34785,35132]
suite [34785,35132]
===
match
---
number: 1 [60671,60672]
number: 1 [62619,62620]
===
match
---
operator: = [43101,43102]
operator: = [43101,43102]
===
match
---
dictorsetmaker [11628,11704]
dictorsetmaker [11628,11704]
===
match
---
name: task_id [9794,9801]
name: task_id [9794,9801]
===
match
---
name: runs [54210,54214]
name: runs [56158,56162]
===
match
---
name: dag [24223,24226]
name: dag [24223,24226]
===
match
---
atom_expr [42936,42958]
atom_expr [42936,42958]
===
match
---
trailer [29158,29162]
trailer [29158,29162]
===
match
---
operator: = [33012,33013]
operator: = [33012,33013]
===
match
---
name: pattern [13434,13441]
name: pattern [13434,13441]
===
match
---
trailer [18075,18083]
trailer [18075,18083]
===
match
---
name: session [17450,17457]
name: session [17450,17457]
===
match
---
name: test_dag_invalid_default_view [4490,4519]
name: test_dag_invalid_default_view [4490,4519]
===
match
---
operator: == [33139,33141]
operator: == [33139,33141]
===
match
---
number: 27 [21513,21515]
number: 27 [21513,21515]
===
match
---
string: 'op5' [6601,6606]
string: 'op5' [6601,6606]
===
match
---
comparison [43717,43745]
comparison [43717,43745]
===
match
---
name: values [13400,13406]
name: values [13400,13406]
===
match
---
atom_expr [61067,61084]
atom_expr [63015,63032]
===
match
---
operator: } [10978,10979]
operator: } [10978,10979]
===
match
---
name: TestDagModel [62272,62284]
name: TestDagModel [64220,64232]
===
match
---
name: self [12492,12496]
name: self [12492,12496]
===
match
---
name: dag [63251,63254]
name: dag [65199,65202]
===
match
---
name: State [18070,18075]
name: State [18070,18075]
===
match
---
name: get [27747,27750]
name: get [27747,27750]
===
match
---
atom [24938,25149]
atom [24938,25149]
===
match
---
simple_stmt [60932,60958]
simple_stmt [62880,62906]
===
match
---
name: dag [50469,50472]
name: dag [50469,50472]
===
match
---
parameters [18474,18480]
parameters [18474,18480]
===
match
---
string: 'dag-bulk-sync-2' [26929,26946]
string: 'dag-bulk-sync-2' [26929,26946]
===
match
---
simple_stmt [55134,55177]
simple_stmt [57082,57125]
===
match
---
argument [17650,17665]
argument [17650,17665]
===
match
---
string: 'test-dag' [25025,25035]
string: 'test-dag' [25025,25035]
===
match
---
name: query [34477,34482]
name: query [34477,34482]
===
match
---
trailer [58443,58455]
trailer [60391,60403]
===
match
---
operator: @ [46321,46322]
operator: @ [46321,46322]
===
match
---
operator: < [45480,45481]
operator: < [45480,45481]
===
match
---
trailer [26725,26728]
trailer [26725,26728]
===
match
---
name: DEFAULT_DATE [50974,50986]
name: DEFAULT_DATE [50974,50986]
===
match
---
simple_stmt [69085,69114]
simple_stmt [71033,71062]
===
match
---
name: start_date [14054,14064]
name: start_date [14054,14064]
===
match
---
atom [28187,28192]
atom [28187,28192]
===
match
---
trailer [32324,32328]
trailer [32324,32328]
===
match
---
operator: = [16914,16915]
operator: = [16914,16915]
===
match
---
name: expand [64104,64110]
name: expand [66052,66058]
===
match
---
string: 'a_child' [8225,8234]
string: 'a_child' [8225,8234]
===
match
---
operator: = [59699,59700]
operator: = [61647,61648]
===
match
---
simple_stmt [34615,34693]
simple_stmt [34615,34693]
===
match
---
operator: , [61550,61551]
operator: , [63498,63499]
===
match
---
trailer [43965,43997]
trailer [43965,43997]
===
match
---
operator: , [25799,25800]
operator: , [25799,25800]
===
match
---
operator: = [55106,55107]
operator: = [57054,57055]
===
match
---
argument [55432,55445]
argument [57380,57393]
===
match
---
name: test_set_dag_id [65086,65101]
name: test_set_dag_id [67034,67049]
===
match
---
number: 0 [24854,24855]
number: 0 [24854,24855]
===
match
---
name: priority_weight [12993,13008]
name: priority_weight [12993,13008]
===
match
---
number: 2 [62766,62767]
number: 2 [64714,64715]
===
match
---
operator: @ [49803,49804]
operator: @ [49803,49804]
===
match
---
arglist [30174,30233]
arglist [30174,30233]
===
match
---
name: local_tz [20299,20307]
name: local_tz [20299,20307]
===
match
---
string: 'test_scheduler_dagrun_once_with_timedelta_and_catchup_false' [57183,57244]
string: 'test_scheduler_dagrun_once_with_timedelta_and_catchup_false' [59131,59192]
===
match
---
name: DAG [44485,44488]
name: DAG [44485,44488]
===
match
---
expr_stmt [14873,14905]
expr_stmt [14873,14905]
===
match
---
trailer [61768,61784]
trailer [63716,63732]
===
match
---
trailer [6313,6319]
trailer [6313,6319]
===
match
---
with_stmt [38315,38553]
with_stmt [38315,38553]
===
match
---
expr_stmt [44404,44460]
expr_stmt [44404,44460]
===
match
---
name: op4 [36083,36086]
name: op4 [36083,36086]
===
match
---
operator: = [55443,55444]
operator: = [57391,57392]
===
match
---
name: _ [54199,54200]
name: _ [56147,56148]
===
match
---
string: "2018-10-26T01:00:00+00:00" [21871,21898]
string: "2018-10-26T01:00:00+00:00" [21871,21898]
===
match
---
operator: = [39063,39064]
operator: = [39063,39064]
===
match
---
name: self [2718,2722]
name: self [2718,2722]
===
match
---
name: DEFAULT_DATE [52382,52394]
name: DEFAULT_DATE [54330,54342]
===
match
---
name: name [25193,25197]
name: name [25193,25197]
===
match
---
funcdef [68078,68126]
funcdef [70026,70074]
===
match
---
name: dr [47386,47388]
name: dr [47386,47388]
===
match
---
argument [55025,55050]
argument [56973,56998]
===
match
---
simple_stmt [44006,44032]
simple_stmt [44006,44032]
===
match
---
name: datetime [57477,57485]
name: datetime [59425,59433]
===
match
---
comparison [29284,29316]
comparison [29284,29316]
===
match
---
name: next_dagrun [42854,42865]
name: next_dagrun [42854,42865]
===
match
---
name: BashOperator [1702,1714]
name: BashOperator [1702,1714]
===
match
---
trailer [28274,28286]
trailer [28274,28286]
===
match
---
name: following_schedule [20701,20719]
name: following_schedule [20701,20719]
===
match
---
name: dag2 [6635,6639]
name: dag2 [6635,6639]
===
match
---
operator: , [68548,68549]
operator: , [70496,70497]
===
match
---
param [58831,58835]
param [60779,60783]
===
match
---
name: dag_id [33961,33967]
name: dag_id [33961,33967]
===
match
---
name: convert_to_utc [22676,22690]
name: convert_to_utc [22676,22690]
===
match
---
name: isoformat [23336,23345]
name: isoformat [23336,23345]
===
match
---
name: session [62996,63003]
name: session [64944,64951]
===
match
---
simple_stmt [52008,52023]
simple_stmt [53956,53971]
===
match
---
trailer [29397,29403]
trailer [29397,29403]
===
match
---
trailer [33099,33105]
trailer [33099,33105]
===
match
---
assert_stmt [22941,22995]
assert_stmt [22941,22995]
===
match
---
operator: = [43991,43992]
operator: = [43991,43992]
===
match
---
operator: , [52471,52472]
operator: , [54419,54420]
===
match
---
trailer [49524,49530]
trailer [49524,49530]
===
match
---
expr_stmt [3274,3286]
expr_stmt [3274,3286]
===
match
---
operator: , [8448,8449]
operator: , [8448,8449]
===
match
---
operator: , [64608,64609]
operator: , [66556,66557]
===
match
---
trailer [34622,34630]
trailer [34622,34630]
===
match
---
expr_stmt [17130,17155]
expr_stmt [17130,17155]
===
match
---
atom_expr [63918,63933]
atom_expr [65866,65881]
===
match
---
simple_stmt [13740,13783]
simple_stmt [13740,13783]
===
match
---
atom_expr [66268,66281]
atom_expr [68216,68229]
===
match
---
string: """         Test that DagModel.next_dagrun_create_after is set to NULL when the dag cannot be created due to max         active runs being hit.         """ [27258,27413]
string: """         Test that DagModel.next_dagrun_create_after is set to NULL when the dag cannot be created due to max         active runs being hit.         """ [27258,27413]
===
match
---
trailer [17457,17463]
trailer [17457,17463]
===
match
---
atom_expr [38654,38704]
atom_expr [38654,38704]
===
match
---
expr_stmt [8825,8857]
expr_stmt [8825,8857]
===
match
---
trailer [43608,43610]
trailer [43608,43610]
===
match
---
fstring_string: stage [15562,15567]
fstring_string: stage [15562,15567]
===
match
---
suite [7313,8480]
suite [7313,8480]
===
match
---
name: session [31363,31370]
name: session [31363,31370]
===
match
---
name: operator [69151,69159]
name: operator [71099,71107]
===
match
---
trailer [26762,26769]
trailer [26762,26769]
===
match
---
name: test_dag_invalid_orientation [5091,5119]
name: test_dag_invalid_orientation [5091,5119]
===
match
---
simple_stmt [66767,66785]
simple_stmt [68715,68733]
===
match
---
simple_stmt [39497,39643]
simple_stmt [39497,39643]
===
match
---
argument [8573,8605]
argument [8573,8605]
===
match
---
name: TI [17294,17296]
name: TI [17294,17296]
===
match
---
with_stmt [15367,16362]
with_stmt [15367,16362]
===
match
---
name: dag [45989,45992]
name: dag [45989,45992]
===
match
---
trailer [69253,69262]
trailer [71201,71210]
===
match
---
atom [10808,10836]
atom [10808,10836]
===
match
---
simple_stmt [62969,62988]
simple_stmt [64917,64936]
===
match
---
name: op1 [37707,37710]
name: op1 [37707,37710]
===
match
---
atom_expr [16563,16594]
atom_expr [16563,16594]
===
match
---
operator: = [13608,13609]
operator: = [13608,13609]
===
match
---
string: 'test-dag2' [26115,26126]
string: 'test-dag2' [26115,26126]
===
match
---
testlist_comp [46430,46452]
testlist_comp [46430,46452]
===
match
---
expr_stmt [50364,50411]
expr_stmt [50364,50411]
===
match
---
name: task_id [37115,37122]
name: task_id [37115,37122]
===
match
---
trailer [29403,29405]
trailer [29403,29405]
===
match
---
expr_stmt [51943,51968]
expr_stmt [53891,53916]
===
match
---
operator: = [27438,27439]
operator: = [27438,27439]
===
match
---
name: _next [23258,23263]
name: _next [23258,23263]
===
match
---
operator: { [15571,15572]
operator: { [15571,15572]
===
match
---
trailer [25893,25895]
trailer [25893,25895]
===
match
---
string: "2015-01-02T02:00:00+00:00" [24043,24070]
string: "2015-01-02T02:00:00+00:00" [24043,24070]
===
match
---
name: jinja_udf [18785,18794]
name: jinja_udf [18785,18794]
===
match
---
operator: = [69094,69095]
operator: = [71042,71043]
===
match
---
name: local_tz [21468,21476]
name: local_tz [21468,21476]
===
match
---
operator: @ [66020,66021]
operator: @ [67968,67969]
===
match
---
atom [13611,13637]
atom [13611,13637]
===
match
---
name: default_view [29340,29352]
name: default_view [29340,29352]
===
match
---
trailer [19644,19646]
trailer [19644,19646]
===
match
---
trailer [39744,39750]
trailer [39744,39750]
===
match
---
simple_stmt [6272,6295]
simple_stmt [6272,6295]
===
match
---
name: RUNNING [18221,18228]
name: RUNNING [18221,18228]
===
match
---
name: all [31568,31571]
name: all [31568,31571]
===
match
---
name: dag_id [31508,31514]
name: dag_id [31508,31514]
===
match
---
atom_expr [60768,60922]
atom_expr [62716,62870]
===
match
---
expr_stmt [36515,36541]
expr_stmt [36515,36541]
===
match
---
name: dag_run_state [49344,49357]
name: dag_run_state [49344,49357]
===
match
---
name: dag [32567,32570]
name: dag [32567,32570]
===
match
---
operator: = [63803,63804]
operator: = [65751,65752]
===
match
---
operator: == [27858,27860]
operator: == [27858,27860]
===
match
---
argument [16907,16927]
argument [16907,16927]
===
match
---
name: query [26356,26361]
name: query [26356,26361]
===
match
---
operator: = [19672,19673]
operator: = [19672,19673]
===
match
---
arglist [27432,27503]
arglist [27432,27503]
===
match
---
operator: = [35465,35466]
operator: = [35465,35466]
===
match
---
operator: = [41506,41507]
operator: = [41506,41507]
===
match
---
atom_expr [59756,59788]
atom_expr [61704,61736]
===
match
---
trailer [58326,58338]
trailer [60274,60286]
===
match
---
expr_stmt [19659,19697]
expr_stmt [19659,19697]
===
match
---
simple_stmt [60142,60191]
simple_stmt [62090,62139]
===
match
---
name: dag [9006,9009]
name: dag [9006,9009]
===
match
---
operator: } [6070,6071]
operator: } [6070,6071]
===
match
---
atom_expr [24600,24611]
atom_expr [24600,24611]
===
match
---
name: args [44335,44339]
name: args [44335,44339]
===
match
---
assert_stmt [24294,24442]
assert_stmt [24294,24442]
===
match
---
funcdef [65489,65897]
funcdef [67437,67845]
===
match
---
simple_stmt [20353,20452]
simple_stmt [20353,20452]
===
match
---
expr_stmt [20610,20680]
expr_stmt [20610,20680]
===
match
---
number: 1 [13296,13297]
number: 1 [13296,13297]
===
match
---
operator: = [57329,57330]
operator: = [59277,59278]
===
match
---
arglist [33961,34010]
arglist [33961,34010]
===
match
---
trailer [36270,36284]
trailer [36270,36284]
===
match
---
operator: { [24301,24302]
operator: { [24301,24302]
===
match
---
operator: = [7692,7693]
operator: = [7692,7693]
===
match
---
name: dag [11809,11812]
name: dag [11809,11812]
===
match
---
trailer [33621,33623]
trailer [33621,33623]
===
match
---
operator: , [28044,28045]
operator: , [28044,28045]
===
match
---
operator: , [46519,46520]
operator: , [46519,46520]
===
match
---
expr_stmt [40079,40131]
expr_stmt [40079,40131]
===
match
---
atom_expr [37558,37594]
atom_expr [37558,37594]
===
match
---
name: session [42760,42767]
name: session [42760,42767]
===
match
---
trailer [54385,54389]
trailer [56333,56337]
===
match
---
name: merge [17485,17490]
name: merge [17485,17490]
===
match
---
name: dag [12041,12044]
name: dag [12041,12044]
===
match
---
operator: = [41161,41162]
operator: = [41161,41162]
===
match
---
argument [17956,17971]
argument [17956,17971]
===
match
---
argument [50316,50330]
argument [50316,50330]
===
match
---
string: """Test that @dag uses function docs as doc_md for DAG object""" [65946,66010]
string: """Test that @dag uses function docs as doc_md for DAG object""" [67894,67958]
===
match
---
simple_stmt [67020,67080]
simple_stmt [68968,69028]
===
match
---
assert_stmt [34541,34569]
assert_stmt [34541,34569]
===
match
---
name: dag [65465,65468]
name: dag [67413,67416]
===
match
---
atom [17948,17954]
atom [17948,17954]
===
match
---
operator: = [8739,8740]
operator: = [8739,8740]
===
match
---
param [18504,18508]
param [18504,18508]
===
match
---
simple_stmt [10127,10145]
simple_stmt [10127,10145]
===
match
---
trailer [52615,52622]
trailer [54563,54570]
===
match
---
name: self [35152,35156]
name: self [35152,35156]
===
match
---
name: TI [52911,52913]
name: TI [54859,54861]
===
match
---
operator: = [36370,36371]
operator: = [36370,36371]
===
match
---
atom_expr [21127,21149]
atom_expr [21127,21149]
===
match
---
comparison [7175,7189]
comparison [7175,7189]
===
match
---
name: end_date [67692,67700]
name: end_date [69640,69648]
===
match
---
name: hash [45737,45741]
name: hash [45737,45741]
===
match
---
trailer [28186,28193]
trailer [28186,28193]
===
match
---
expr_stmt [6364,6398]
expr_stmt [6364,6398]
===
match
---
trailer [8072,8099]
trailer [8072,8099]
===
match
---
simple_stmt [29722,29767]
simple_stmt [29722,29767]
===
match
---
name: task_instance_2 [51154,51169]
name: task_instance_2 [51154,51169]
===
match
---
trailer [48815,48823]
trailer [48815,48823]
===
match
---
operator: = [7922,7923]
operator: = [7922,7923]
===
match
---
simple_stmt [37552,37595]
simple_stmt [37552,37595]
===
match
---
simple_stmt [8987,9029]
simple_stmt [8987,9029]
===
match
---
trailer [23706,23746]
trailer [23706,23746]
===
match
---
name: dag [6419,6422]
name: dag [6419,6422]
===
match
---
name: default_args [67959,67971]
name: default_args [69907,69919]
===
match
---
atom_expr [25157,25204]
atom_expr [25157,25204]
===
match
---
name: start_date [56140,56150]
name: start_date [58088,58098]
===
match
---
trailer [17599,17622]
trailer [17599,17622]
===
match
---
trailer [31433,31440]
trailer [31433,31440]
===
match
---
name: DummyOperator [59305,59318]
name: DummyOperator [61253,61266]
===
match
---
simple_stmt [9936,9958]
simple_stmt [9936,9958]
===
match
---
trailer [37217,37225]
trailer [37217,37225]
===
match
---
decorated [30550,32501]
decorated [30550,32501]
===
match
---
string: 'owner' [14093,14100]
string: 'owner' [14093,14100]
===
match
---
name: period_end [27775,27785]
name: period_end [27775,27785]
===
match
---
dictorsetmaker [60877,60905]
dictorsetmaker [62825,62853]
===
match
---
name: PRE_TRANSITION [21539,21553]
name: PRE_TRANSITION [21539,21553]
===
match
---
expr_stmt [55528,55577]
expr_stmt [57476,57525]
===
match
---
operator: = [38570,38571]
operator: = [38570,38571]
===
match
---
string: 'dag' [30413,30418]
string: 'dag' [30413,30418]
===
match
---
name: DEFAULT_DATE [27861,27873]
name: DEFAULT_DATE [27861,27873]
===
match
---
param [42000,42004]
param [42000,42004]
===
match
---
with_stmt [19542,20099]
with_stmt [19542,20099]
===
match
---
name: split [29580,29585]
name: split [29580,29585]
===
match
---
simple_stmt [33632,33668]
simple_stmt [33632,33668]
===
match
---
argument [47881,47897]
argument [47881,47897]
===
match
---
name: DagModel [29503,29511]
name: DagModel [29503,29511]
===
match
---
name: dag [23862,23865]
name: dag [23862,23865]
===
match
---
atom_expr [34302,34319]
atom_expr [34302,34319]
===
match
---
trailer [19412,19435]
trailer [19412,19435]
===
match
---
name: datetime [53745,53753]
name: datetime [55693,55701]
===
match
---
operator: = [3401,3402]
operator: = [3401,3402]
===
match
---
name: dag [48779,48782]
name: dag [48779,48782]
===
match
---
trailer [11839,11846]
trailer [11839,11846]
===
match
---
name: f [19099,19100]
name: f [19099,19100]
===
match
---
trailer [32260,32270]
trailer [32260,32270]
===
match
---
suite [20210,21247]
suite [20210,21247]
===
match
---
trailer [62403,62412]
trailer [64351,64360]
===
match
---
sync_comp_for [14454,14478]
sync_comp_for [14454,14478]
===
match
---
name: session [34222,34229]
name: session [34222,34229]
===
match
---
trailer [65843,65853]
trailer [67791,67801]
===
match
---
operator: + [60473,60474]
operator: + [62421,62422]
===
match
---
simple_stmt [34029,34055]
simple_stmt [34029,34055]
===
match
---
name: schedule_interval [46969,46986]
name: schedule_interval [46969,46986]
===
match
---
simple_stmt [36056,36093]
simple_stmt [36056,36093]
===
match
---
name: DagModel [32120,32128]
name: DagModel [32120,32128]
===
match
---
name: dag_id [27432,27438]
name: dag_id [27432,27438]
===
match
---
operator: , [32964,32965]
operator: , [32964,32965]
===
match
---
name: DagModel [34375,34383]
name: DagModel [34375,34383]
===
match
---
name: task [17173,17177]
name: task [17173,17177]
===
match
---
expr_stmt [28203,28253]
expr_stmt [28203,28253]
===
match
---
operator: = [68242,68243]
operator: = [70190,70191]
===
match
---
name: parent_dag_name [60090,60105]
name: parent_dag_name [62038,62053]
===
match
---
name: num [68093,68096]
name: num [70041,70044]
===
match
---
arglist [59141,59286]
arglist [61089,61234]
===
match
---
name: session [49465,49472]
name: session [49465,49472]
===
match
---
atom_expr [19910,19925]
atom_expr [19910,19925]
===
match
---
name: priority_weight_total [15081,15102]
name: priority_weight_total [15081,15102]
===
match
---
expr_stmt [22504,22549]
expr_stmt [22504,22549]
===
match
---
operator: , [52500,52501]
operator: , [54448,54449]
===
match
---
name: query [49525,49530]
name: query [49525,49530]
===
match
---
name: test_dag_topological_sort_dag_without_tasks [10547,10590]
name: test_dag_topological_sort_dag_without_tasks [10547,10590]
===
match
---
number: 1 [12021,12022]
number: 1 [12021,12022]
===
match
---
trailer [29642,29652]
trailer [29642,29652]
===
match
---
atom_expr [62547,62807]
atom_expr [64495,64755]
===
match
---
name: timezone [53273,53281]
name: timezone [55221,55229]
===
match
---
name: DEFAULT_DATE [50630,50642]
name: DEFAULT_DATE [50630,50642]
===
match
---
atom_expr [21782,21804]
atom_expr [21782,21804]
===
match
---
operator: , [28622,28623]
operator: , [28622,28623]
===
match
---
string: 'dummy' [59327,59334]
string: 'dummy' [61275,61282]
===
match
---
param [64941,64945]
param [66889,66893]
===
match
---
name: args [60123,60127]
name: args [62071,62075]
===
match
---
operator: = [23860,23861]
operator: = [23860,23861]
===
match
---
name: dag_subclass [44726,44738]
name: dag_subclass [44726,44738]
===
match
---
name: self [64980,64984]
name: self [66928,66932]
===
match
---
name: timedelta [46654,46663]
name: timedelta [46654,46663]
===
match
---
name: merge [52422,52427]
name: merge [54370,54375]
===
match
---
name: op2 [6310,6313]
name: op2 [6310,6313]
===
match
---
name: run_type [41373,41381]
name: run_type [41373,41381]
===
match
---
operator: = [50836,50837]
operator: = [50836,50837]
===
match
---
simple_stmt [58003,58227]
simple_stmt [59951,60175]
===
match
---
name: dag_id [33584,33590]
name: dag_id [33584,33590]
===
match
---
atom_expr [35720,35760]
atom_expr [35720,35760]
===
match
---
simple_stmt [1189,1229]
simple_stmt [1189,1229]
===
match
---
operator: , [52047,52048]
operator: , [53995,53996]
===
match
---
atom_expr [20786,20803]
atom_expr [20786,20803]
===
match
---
trailer [34482,34492]
trailer [34482,34492]
===
match
---
name: task_instance_1 [52583,52598]
name: task_instance_1 [54531,54546]
===
match
---
name: op1 [9936,9939]
name: op1 [9936,9939]
===
match
---
operator: , [24987,24988]
operator: , [24987,24988]
===
match
---
name: self [67972,67976]
name: self [69920,69924]
===
match
---
name: task_id [42376,42383]
name: task_id [42376,42383]
===
match
---
name: width [13035,13040]
name: width [13035,13040]
===
match
---
name: DEFAULT_DATE [50837,50849]
name: DEFAULT_DATE [50837,50849]
===
match
---
operator: == [18274,18276]
operator: == [18274,18276]
===
match
---
name: session [46203,46210]
name: session [46203,46210]
===
match
---
simple_stmt [9774,9807]
simple_stmt [9774,9807]
===
match
---
with_stmt [19764,19897]
with_stmt [19764,19897]
===
match
---
string: "test_dag" [37503,37513]
string: "test_dag" [37503,37513]
===
match
---
name: State [51821,51826]
name: State [53769,53774]
===
match
---
atom_expr [14886,14905]
atom_expr [14886,14905]
===
match
---
name: execution_date [17313,17327]
name: execution_date [17313,17327]
===
match
---
name: FAILED [50765,50771]
name: FAILED [50765,50771]
===
match
---
suite [58837,59855]
suite [60785,61803]
===
match
---
name: task_id [3422,3429]
name: task_id [3422,3429]
===
match
---
trailer [19691,19696]
trailer [19691,19696]
===
match
---
param [54667,54674]
param [56615,56622]
===
match
---
name: weight [12543,12549]
name: weight [12543,12549]
===
match
---
name: test_dag_topological_sort1 [8489,8515]
name: test_dag_topological_sort1 [8489,8515]
===
match
---
name: dag [64462,64465]
name: dag [66410,66413]
===
match
---
operator: , [41402,41403]
operator: , [41402,41403]
===
match
---
operator: , [55430,55431]
operator: , [57378,57379]
===
match
---
trailer [23302,23308]
trailer [23302,23308]
===
match
---
name: get [29361,29364]
name: get [29361,29364]
===
match
---
name: DagModel [1462,1470]
name: DagModel [1462,1470]
===
match
---
name: dag2 [7246,7250]
name: dag2 [7246,7250]
===
match
---
operator: = [34803,34804]
operator: = [34803,34804]
===
match
---
arith_expr [17328,17369]
arith_expr [17328,17369]
===
match
---
name: test_utils [2247,2257]
name: test_utils [2247,2257]
===
match
---
simple_stmt [29277,29317]
simple_stmt [29277,29317]
===
match
---
operator: = [53940,53941]
operator: = [55888,55889]
===
match
---
trailer [13336,13349]
trailer [13336,13349]
===
match
---
atom [36032,36042]
atom [36032,36042]
===
match
---
argument [8890,8901]
argument [8890,8901]
===
match
---
name: filter [29126,29132]
name: filter [29126,29132]
===
match
---
operator: , [24188,24189]
operator: , [24188,24189]
===
match
---
trailer [49662,49664]
trailer [49662,49664]
===
match
---
comparison [27177,27195]
comparison [27177,27195]
===
match
---
name: DAG [44203,44206]
name: DAG [44203,44206]
===
match
---
operator: = [38346,38347]
operator: = [38346,38347]
===
match
---
atom_expr [44305,44340]
atom_expr [44305,44340]
===
match
---
simple_stmt [17531,17550]
simple_stmt [17531,17550]
===
match
---
trailer [57691,57700]
trailer [59639,59648]
===
match
---
atom_expr [28211,28253]
atom_expr [28211,28253]
===
match
---
atom [8586,8605]
atom [8586,8605]
===
match
---
sync_comp_for [14395,14419]
sync_comp_for [14395,14419]
===
match
---
trailer [21176,21186]
trailer [21176,21186]
===
match
---
expr_stmt [48742,48787]
expr_stmt [48742,48787]
===
match
---
name: i [64384,64385]
name: i [66332,66333]
===
match
---
name: delete [3102,3108]
name: delete [3102,3108]
===
match
---
parameters [23488,23494]
parameters [23488,23494]
===
match
---
operator: == [21868,21870]
operator: == [21868,21870]
===
match
---
operator: , [51427,51428]
operator: , [51427,51428]
===
match
---
atom_expr [69243,69262]
atom_expr [71191,71210]
===
match
---
name: DagModel [46021,46029]
name: DagModel [46021,46029]
===
match
---
trailer [39750,39752]
trailer [39750,39752]
===
match
---
operator: , [63249,63250]
operator: , [65197,65198]
===
match
---
name: dag [27513,27516]
name: dag [27513,27516]
===
match
---
dotted_name [1822,1838]
dotted_name [1822,1838]
===
match
---
operator: , [43499,43500]
operator: , [43499,43500]
===
match
---
name: noop_pipeline [65251,65264]
name: noop_pipeline [67199,67212]
===
match
---
name: orm_dag [34302,34309]
name: orm_dag [34302,34309]
===
match
---
name: op5 [10140,10143]
name: op5 [10140,10143]
===
match
---
name: f [18993,18994]
name: f [18993,18994]
===
match
---
operator: = [28491,28492]
operator: = [28491,28492]
===
match
---
name: query [25867,25872]
name: query [25867,25872]
===
match
---
name: schedule_interval [58154,58171]
name: schedule_interval [60102,60119]
===
match
---
argument [35847,35859]
argument [35847,35859]
===
match
---
string: 'owner1' [10671,10679]
string: 'owner1' [10671,10679]
===
match
---
name: self [43839,43843]
name: self [43839,43843]
===
match
---
name: execution_date [50959,50973]
name: execution_date [50959,50973]
===
match
---
operator: = [3128,3129]
operator: = [3128,3129]
===
match
---
name: DagRun [51573,51579]
name: DagRun [51573,51579]
===
match
---
trailer [47626,47631]
trailer [47626,47631]
===
match
---
trailer [52576,52582]
trailer [54524,54530]
===
match
---
name: dag [4944,4947]
name: dag [4944,4947]
===
match
---
name: all [31987,31990]
name: all [31987,31990]
===
match
---
name: dag [51205,51208]
name: dag [51205,51208]
===
match
---
operator: , [59605,59606]
operator: , [61553,61554]
===
match
---
comparison [21782,21835]
comparison [21782,21835]
===
match
---
operator: , [27575,27576]
operator: , [27575,27576]
===
match
---
argument [7642,7668]
argument [7642,7668]
===
match
---
name: run [43731,43734]
name: run [43731,43734]
===
match
---
operator: } [26789,26790]
operator: } [26789,26790]
===
match
---
simple_stmt [48042,48082]
simple_stmt [48042,48082]
===
match
---
name: run_id [47859,47865]
name: run_id [47859,47865]
===
match
---
funcdef [67999,68297]
funcdef [69947,70245]
===
match
---
name: topological_list [10297,10313]
name: topological_list [10297,10313]
===
match
---
name: op5 [6573,6576]
name: op5 [6573,6576]
===
match
---
expr_stmt [50662,50860]
expr_stmt [50662,50860]
===
match
---
trailer [33428,33432]
trailer [33428,33432]
===
match
---
name: merge [49046,49051]
name: merge [49046,49051]
===
match
---
simple_stmt [20564,20601]
simple_stmt [20564,20601]
===
match
---
name: dag_id [46161,46167]
name: dag_id [46161,46167]
===
match
---
operator: = [56492,56493]
operator: = [58440,58441]
===
match
---
simple_stmt [40906,41044]
simple_stmt [40906,41044]
===
match
---
operator: = [8535,8536]
operator: = [8535,8536]
===
match
---
atom [24956,24987]
atom [24956,24987]
===
match
---
operator: { [60264,60265]
operator: { [62212,62213]
===
match
---
trailer [31518,31539]
trailer [31518,31539]
===
match
---
comparison [9202,9230]
comparison [9202,9230]
===
match
---
operator: = [18397,18398]
operator: = [18397,18398]
===
match
---
trailer [25709,25711]
trailer [25709,25711]
===
match
---
trailer [40636,40660]
trailer [40636,40660]
===
match
---
name: add [33429,33432]
name: add [33429,33432]
===
match
---
name: dag [5911,5914]
name: dag [5911,5914]
===
match
---
name: handle_callback [40673,40688]
name: handle_callback [40673,40688]
===
match
---
operator: = [56659,56660]
operator: = [58607,58608]
===
match
---
name: dag_id [46264,46270]
name: dag_id [46264,46270]
===
match
---
name: start_date [64274,64284]
name: start_date [66222,66232]
===
match
---
name: NamedTemporaryFile [18903,18921]
name: NamedTemporaryFile [18903,18921]
===
match
---
comparison [45762,45794]
comparison [45762,45794]
===
match
---
operator: , [59227,59228]
operator: , [61175,61176]
===
match
---
string: 'dag.subtask' [30174,30187]
string: 'dag.subtask' [30174,30187]
===
match
---
trailer [63780,63782]
trailer [65728,65730]
===
match
---
argument [67959,67989]
argument [69907,69937]
===
match
---
name: schedule_interval [53304,53321]
name: schedule_interval [55252,55269]
===
match
---
param [33818,33822]
param [33818,33822]
===
match
---
string: 'DAG' [10788,10793]
string: 'DAG' [10788,10793]
===
match
---
name: State [47284,47289]
name: State [47284,47289]
===
match
---
expr_stmt [59489,59669]
expr_stmt [61437,61617]
===
match
---
simple_stmt [58846,59110]
simple_stmt [60794,61058]
===
match
---
trailer [14007,14029]
trailer [14007,14029]
===
match
---
name: TI [52465,52467]
name: TI [54413,54415]
===
match
---
name: topological_list [8160,8176]
name: topological_list [8160,8176]
===
match
---
param [65102,65106]
param [67050,67054]
===
match
---
operator: , [67623,67624]
operator: , [69571,69572]
===
match
---
trailer [3773,3780]
trailer [3773,3780]
===
match
---
trailer [22582,22651]
trailer [22582,22651]
===
match
---
operator: = [49253,49254]
operator: = [49253,49254]
===
match
---
arglist [41266,41330]
arglist [41266,41330]
===
match
---
exprlist [13114,13122]
exprlist [13114,13122]
===
match
---
atom_expr [61867,61894]
atom_expr [63815,63842]
===
match
---
name: remove [10201,10207]
name: remove [10201,10207]
===
match
---
name: task_id [30075,30082]
name: task_id [30075,30082]
===
match
---
name: dag [63498,63501]
name: dag [65446,65449]
===
match
---
trailer [8754,8767]
trailer [8754,8767]
===
match
---
simple_stmt [19637,19647]
simple_stmt [19637,19647]
===
match
---
name: i [14687,14688]
name: i [14687,14688]
===
match
---
operator: , [61580,61581]
operator: , [63528,63529]
===
match
---
trailer [41392,41402]
trailer [41392,41402]
===
match
---
operator: = [39187,39188]
operator: = [39187,39188]
===
match
---
funcdef [34722,35132]
funcdef [34722,35132]
===
match
---
operator: == [19470,19472]
operator: == [19470,19472]
===
match
---
simple_stmt [22290,22345]
simple_stmt [22290,22345]
===
match
---
param [18475,18479]
param [18475,18479]
===
match
---
with_stmt [29963,30267]
with_stmt [29963,30267]
===
match
---
atom_expr [9735,9761]
atom_expr [9735,9761]
===
match
---
name: dag [48672,48675]
name: dag [48672,48675]
===
match
---
argument [51329,51356]
argument [51329,51356]
===
match
---
name: dag [43137,43140]
name: dag [43137,43140]
===
match
---
atom_expr [43641,43659]
atom_expr [43641,43659]
===
match
---
number: 10 [59603,59605]
number: 10 [61551,61553]
===
match
---
operator: { [10661,10662]
operator: { [10661,10662]
===
match
---
string: "\n" [36583,36587]
string: "\n" [36583,36587]
===
match
---
arglist [30802,30823]
arglist [30802,30823]
===
match
---
simple_stmt [30482,30521]
simple_stmt [30482,30521]
===
match
---
not_test [34548,34569]
not_test [34548,34569]
===
match
---
name: datetime [12120,12128]
name: datetime [12120,12128]
===
match
---
operator: , [16975,16976]
operator: , [16975,16976]
===
match
---
atom [27690,27695]
atom [27690,27695]
===
match
---
comparison [36063,36092]
comparison [36063,36092]
===
match
---
operator: == [21805,21807]
operator: == [21805,21807]
===
match
---
suite [15969,16085]
suite [15969,16085]
===
match
---
trailer [20119,20130]
trailer [20119,20130]
===
match
---
atom_expr [61604,61646]
atom_expr [63552,63594]
===
match
---
operator: } [47221,47222]
operator: } [47221,47222]
===
match
---
parameters [10768,10774]
parameters [10768,10774]
===
match
---
name: QUEUED [17273,17279]
name: QUEUED [17273,17279]
===
match
---
expr_stmt [53737,53772]
expr_stmt [55685,55720]
===
match
---
expr_stmt [29092,29164]
expr_stmt [29092,29164]
===
match
---
operator: = [50079,50080]
operator: = [50079,50080]
===
match
---
name: DagRun [1472,1478]
name: DagRun [1472,1478]
===
match
---
atom_expr [18672,18694]
atom_expr [18672,18694]
===
match
---
name: DummyOperator [9780,9793]
name: DummyOperator [9780,9793]
===
match
---
dictorsetmaker [5967,5984]
dictorsetmaker [5967,5984]
===
match
---
operator: = [52507,52508]
operator: = [54455,54456]
===
match
---
assert_stmt [12406,12446]
assert_stmt [12406,12446]
===
match
---
name: states [17941,17947]
name: states [17941,17947]
===
match
---
trailer [35242,35279]
trailer [35242,35279]
===
match
---
name: task_id [19238,19245]
name: task_id [19238,19245]
===
match
---
name: f [19604,19605]
name: f [19604,19605]
===
match
---
trailer [40409,40481]
trailer [40409,40481]
===
match
---
name: start_date [35736,35746]
name: start_date [35736,35746]
===
match
---
name: clear_db_dags [2495,2508]
name: clear_db_dags [2495,2508]
===
match
---
operator: == [15892,15894]
operator: == [15892,15894]
===
match
---
trailer [6936,6944]
trailer [6936,6944]
===
match
---
name: DAG [63163,63166]
name: DAG [65111,65114]
===
match
---
atom_expr [12157,12169]
atom_expr [12157,12169]
===
match
---
operator: = [33942,33943]
operator: = [33942,33943]
===
match
---
name: task_id [50316,50323]
name: task_id [50316,50323]
===
match
---
name: tasks [9311,9316]
name: tasks [9311,9316]
===
match
---
decorator [68996,69012]
decorator [70944,70960]
===
match
---
trailer [19728,19733]
trailer [19728,19733]
===
match
---
trailer [62976,62985]
trailer [64924,64933]
===
match
---
simple_stmt [30353,30426]
simple_stmt [30353,30426]
===
match
---
trailer [51655,51661]
trailer [51655,51661]
===
match
---
number: 2020 [57701,57705]
number: 2020 [59649,59653]
===
match
---
name: pytest [66876,66882]
name: pytest [68824,68830]
===
match
---
trailer [40518,40567]
trailer [40518,40567]
===
match
---
operator: , [24163,24164]
operator: , [24163,24164]
===
match
---
name: date [54347,54351]
name: date [56295,56299]
===
match
---
name: task_instances [53040,53054]
name: task_instances [54988,55002]
===
match
---
operator: = [67700,67701]
operator: = [69648,69649]
===
match
---
name: dag [34171,34174]
name: dag [34171,34174]
===
match
---
atom_expr [17450,17468]
atom_expr [17450,17468]
===
match
---
atom [12376,12396]
atom [12376,12396]
===
match
---
name: when [40372,40376]
name: when [40372,40376]
===
match
---
name: self [16405,16409]
name: self [16405,16409]
===
match
---
name: task [17048,17052]
name: task [17048,17052]
===
match
---
atom_expr [23665,23688]
atom_expr [23665,23688]
===
match
---
trailer [54048,54103]
trailer [55996,56051]
===
match
---
operator: } [14240,14241]
operator: } [14240,14241]
===
match
---
argument [68483,68515]
argument [70431,70463]
===
match
---
expr_stmt [54229,54268]
expr_stmt [56177,56216]
===
match
---
name: remove [10423,10429]
name: remove [10423,10429]
===
match
---
comparison [61320,61344]
comparison [63268,63292]
===
match
---
trailer [2744,2746]
trailer [2744,2746]
===
match
---
trailer [68751,68753]
trailer [70699,70701]
===
match
---
number: 1 [49707,49708]
number: 1 [49707,49708]
===
match
---
name: State [47231,47236]
name: State [47231,47236]
===
match
---
name: dag_id [49614,49620]
name: dag_id [49614,49620]
===
match
---
trailer [25252,25269]
trailer [25252,25269]
===
match
---
name: types [2125,2130]
name: types [2125,2130]
===
match
---
trailer [19689,19697]
trailer [19689,19697]
===
match
---
name: dag_id [41174,41180]
name: dag_id [41174,41180]
===
match
---
name: task_id [50071,50078]
name: task_id [50071,50078]
===
match
---
suite [65732,65760]
suite [67680,67708]
===
match
---
name: merge [17512,17517]
name: merge [17512,17517]
===
match
---
name: is_subdag [28912,28921]
name: is_subdag [28912,28921]
===
match
---
name: op2 [8780,8783]
name: op2 [8780,8783]
===
match
---
operator: == [23411,23413]
operator: == [23411,23413]
===
match
---
simple_stmt [34848,34926]
simple_stmt [34848,34926]
===
match
---
operator: , [26860,26861]
operator: , [26860,26861]
===
match
---
assert_stmt [6867,6908]
assert_stmt [6867,6908]
===
match
---
string: 't1' [38675,38679]
string: 't1' [38675,38679]
===
match
---
atom_expr [68697,68723]
atom_expr [70645,70671]
===
match
---
operator: , [2393,2394]
operator: , [2393,2394]
===
match
---
operator: , [53982,53983]
operator: , [55930,55931]
===
match
---
trailer [52643,52784]
trailer [54591,54732]
===
match
---
atom_expr [17423,17441]
atom_expr [17423,17441]
===
match
---
name: DagModel [63645,63653]
name: DagModel [65593,65601]
===
match
---
atom_expr [59305,59361]
atom_expr [61253,61309]
===
match
---
operator: , [4302,4303]
operator: , [4302,4303]
===
match
---
funcdef [5087,5392]
funcdef [5087,5392]
===
match
---
dictorsetmaker [25744,25818]
dictorsetmaker [25744,25818]
===
match
---
operator: = [49437,49438]
operator: = [49437,49438]
===
match
---
sync_comp_for [15724,15748]
sync_comp_for [15724,15748]
===
match
---
name: row [25852,25855]
name: row [25852,25855]
===
match
---
comparison [26810,27081]
comparison [26810,27081]
===
match
---
argument [4338,4352]
argument [4338,4352]
===
match
---
number: 0 [61238,61239]
number: 0 [63186,63187]
===
match
---
comparison [45160,45179]
comparison [45160,45179]
===
match
---
atom_expr [27120,27145]
atom_expr [27120,27145]
===
match
---
name: run [43349,43352]
name: run [43349,43352]
===
match
---
name: jinja_udf [18640,18649]
name: jinja_udf [18640,18649]
===
match
---
name: session [52608,52615]
name: session [54556,54563]
===
match
---
argument [38401,38413]
argument [38401,38413]
===
match
---
param [60090,60106]
param [62038,62054]
===
match
---
name: subdag [30751,30757]
name: subdag [30751,30757]
===
match
---
operator: , [16846,16847]
operator: , [16846,16847]
===
match
---
comparison [47914,47949]
comparison [47914,47949]
===
match
---
name: creating_job_id [48368,48383]
name: creating_job_id [48368,48383]
===
match
---
operator: >> [8003,8005]
operator: >> [8003,8005]
===
match
---
simple_stmt [58289,58339]
simple_stmt [60237,60287]
===
match
---
simple_stmt [64068,64084]
simple_stmt [66016,66032]
===
match
---
name: ti_state_begin [52508,52522]
name: ti_state_begin [54456,54470]
===
match
---
argument [41266,41286]
argument [41266,41286]
===
match
---
name: dag [47487,47490]
name: dag [47487,47490]
===
match
---
argument [23803,23820]
argument [23803,23820]
===
match
---
name: test_dag_id [18033,18044]
name: test_dag_id [18033,18044]
===
match
---
name: session [51441,51448]
name: session [51441,51448]
===
match
---
atom_expr [42227,42245]
atom_expr [42227,42245]
===
match
---
simple_stmt [46958,47008]
simple_stmt [46958,47008]
===
match
---
string: 'owner' [9508,9515]
string: 'owner' [9508,9515]
===
match
---
atom_expr [39675,39688]
atom_expr [39675,39688]
===
match
---
assert_stmt [11724,11793]
assert_stmt [11724,11793]
===
match
---
operator: = [39133,39134]
operator: = [39133,39134]
===
match
---
name: op3 [35873,35876]
name: op3 [35873,35876]
===
match
---
simple_stmt [55528,55578]
simple_stmt [57476,57526]
===
match
---
atom_expr [47353,47361]
atom_expr [47353,47361]
===
match
---
string: "dag run execution_date loses precision" [43661,43701]
string: "dag run execution_date loses precision" [43661,43701]
===
match
---
name: session [27033,27040]
name: session [27033,27040]
===
match
---
name: start [21641,21646]
name: start [21641,21646]
===
match
---
atom_expr [48445,48455]
atom_expr [48445,48455]
===
match
---
parameters [33817,33823]
parameters [33817,33823]
===
match
---
simple_stmt [17255,17280]
simple_stmt [17255,17280]
===
match
---
operator: , [13075,13076]
operator: , [13075,13076]
===
match
---
name: dag_id [30893,30899]
name: dag_id [30893,30899]
===
match
---
assert_stmt [10504,10537]
assert_stmt [10504,10537]
===
match
---
comparison [30441,30473]
comparison [30441,30473]
===
match
---
name: DummyOperator [55140,55153]
name: DummyOperator [57088,57101]
===
match
---
name: next_date [57455,57464]
name: next_date [59403,59412]
===
match
---
name: params [3774,3780]
name: params [3774,3780]
===
match
---
assert_stmt [36687,36717]
assert_stmt [36687,36717]
===
match
---
name: _next [22161,22166]
name: _next [22161,22166]
===
match
---
operator: = [32711,32712]
operator: = [32711,32712]
===
match
---
name: template_searchpath [19810,19829]
name: template_searchpath [19810,19829]
===
match
---
trailer [55507,55519]
trailer [57455,57467]
===
match
---
name: datetime [17219,17227]
name: datetime [17219,17227]
===
match
---
simple_stmt [30771,30838]
simple_stmt [30771,30838]
===
match
---
name: return_num [66767,66777]
name: return_num [68715,68725]
===
match
---
trailer [27736,27746]
trailer [27736,27746]
===
match
---
operator: == [34681,34683]
operator: == [34681,34683]
===
match
---
name: task_states [51755,51766]
name: task_states [53703,53714]
===
match
---
arglist [33722,33753]
arglist [33722,33753]
===
match
---
name: DAG [18132,18135]
name: DAG [18132,18135]
===
match
---
trailer [41345,41359]
trailer [41345,41359]
===
match
---
operator: , [49018,49019]
operator: , [49018,49019]
===
match
---
expr_stmt [4275,4353]
expr_stmt [4275,4353]
===
match
---
with_stmt [36185,36718]
with_stmt [36185,36718]
===
match
---
name: os [19030,19032]
name: os [19030,19032]
===
match
---
string: 'start_date' [11980,11992]
string: 'start_date' [11980,11992]
===
match
---
funcdef [23447,24071]
funcdef [23447,24071]
===
match
---
trailer [9838,9851]
trailer [9838,9851]
===
match
---
operator: == [15144,15146]
operator: == [15144,15146]
===
match
---
string: "t3" [35901,35905]
string: "t3" [35901,35905]
===
match
---
for_stmt [25547,25605]
for_stmt [25547,25605]
===
match
---
simple_stmt [42781,42832]
simple_stmt [42781,42832]
===
match
---
operator: = [33881,33882]
operator: = [33881,33882]
===
match
---
name: dag [62349,62352]
name: dag [64297,64300]
===
match
---
simple_stmt [1017,1043]
simple_stmt [1017,1043]
===
match
---
operator: = [56150,56151]
operator: = [58098,58099]
===
match
---
name: run [43589,43592]
name: run [43589,43592]
===
match
---
number: 10 [15320,15322]
number: 10 [15320,15322]
===
match
---
name: test_task [17302,17311]
name: test_task [17302,17311]
===
match
---
trailer [24365,24371]
trailer [24365,24371]
===
match
---
name: start_date [54694,54704]
name: start_date [56642,56652]
===
match
---
string: 'test-dag' [25123,25133]
string: 'test-dag' [25123,25133]
===
match
---
trailer [43413,43423]
trailer [43413,43423]
===
match
---
name: range [14463,14468]
name: range [14463,14468]
===
match
---
argument [55381,55388]
argument [57329,57336]
===
match
---
name: dag [46885,46888]
name: dag [46885,46888]
===
match
---
name: i [13292,13293]
name: i [13292,13293]
===
match
---
trailer [56475,56477]
trailer [58423,58425]
===
match
---
name: delete [46282,46288]
name: delete [46282,46288]
===
match
---
trailer [62925,62927]
trailer [64873,64875]
===
match
---
number: 5 [13977,13978]
number: 5 [13977,13978]
===
match
---
trailer [44029,44031]
trailer [44029,44031]
===
match
---
trailer [40736,40755]
trailer [40736,40755]
===
match
---
string: """Test that @dag uses function name as default dag id.""" [65528,65586]
string: """Test that @dag uses function name as default dag id.""" [67476,67534]
===
match
---
arglist [14469,14477]
arglist [14469,14477]
===
match
---
simple_stmt [49761,49798]
simple_stmt [49761,49798]
===
match
---
simple_stmt [33041,33073]
simple_stmt [33041,33073]
===
match
---
trailer [20318,20327]
trailer [20318,20327]
===
match
---
name: next_date [61132,61141]
name: next_date [63080,63089]
===
match
---
expr_stmt [58236,58280]
expr_stmt [60184,60228]
===
match
---
dotted_name [1311,1329]
dotted_name [1311,1329]
===
match
---
testlist_comp [41639,41650]
testlist_comp [41639,41650]
===
match
---
name: datetime [11994,12002]
name: datetime [11994,12002]
===
match
---
trailer [63304,63312]
trailer [65252,65260]
===
match
---
simple_stmt [35300,35334]
simple_stmt [35300,35334]
===
match
---
string: "test-dag2" [25592,25603]
string: "test-dag2" [25592,25603]
===
match
---
name: current_task [14719,14731]
name: current_task [14719,14731]
===
match
---
name: SCHEDULED [39240,39249]
name: SCHEDULED [39240,39249]
===
match
---
param [51889,51904]
param [53837,53852]
===
match
---
trailer [45268,45273]
trailer [45268,45273]
===
match
---
trailer [64984,64993]
trailer [66932,66941]
===
match
---
trailer [35023,35028]
trailer [35023,35028]
===
match
---
operator: == [3805,3807]
operator: == [3805,3807]
===
match
---
arglist [37886,37921]
arglist [37886,37921]
===
match
---
name: task_id [7121,7128]
name: task_id [7121,7128]
===
match
---
simple_stmt [50218,50293]
simple_stmt [50218,50293]
===
match
---
name: owner [27586,27591]
name: owner [27586,27591]
===
match
---
operator: = [68970,68971]
operator: = [70918,70919]
===
match
---
name: remove [9245,9251]
name: remove [9245,9251]
===
match
---
assert_stmt [39697,39732]
assert_stmt [39697,39732]
===
match
---
atom [44242,44290]
atom [44242,44290]
===
match
---
number: 2020 [58129,58133]
number: 2020 [60077,60081]
===
match
---
name: pipeline [12924,12932]
name: pipeline [12924,12932]
===
match
---
expr_stmt [41602,41652]
expr_stmt [41602,41652]
===
match
---
atom_expr [62119,62151]
atom_expr [64067,64099]
===
match
---
comparison [22948,22995]
comparison [22948,22995]
===
match
---
name: RUNNING [17397,17404]
name: RUNNING [17397,17404]
===
match
---
simple_stmt [32403,32501]
simple_stmt [32403,32501]
===
match
---
operator: = [12855,12856]
operator: = [12855,12856]
===
match
---
atom_expr [2519,2540]
atom_expr [2519,2540]
===
match
---
name: DAG [33944,33947]
name: DAG [33944,33947]
===
match
---
argument [28991,29004]
argument [28991,29004]
===
match
---
comparison [35097,35131]
comparison [35097,35131]
===
match
---
operator: , [29224,29225]
operator: , [29224,29225]
===
match
---
name: tasks [9077,9082]
name: tasks [9077,9082]
===
match
---
trailer [19611,19624]
trailer [19611,19624]
===
match
---
trailer [44362,44394]
trailer [44362,44394]
===
match
---
name: State [50759,50764]
name: State [50759,50764]
===
match
---
classdef [64626,69277]
classdef [66574,71225]
===
match
---
trailer [13701,13723]
trailer [13701,13723]
===
match
---
operator: = [19795,19796]
operator: = [19795,19796]
===
match
---
dictorsetmaker [37214,37230]
dictorsetmaker [37214,37230]
===
match
---
name: self [66481,66485]
name: self [68429,68433]
===
match
---
name: correct_weight [15147,15161]
name: correct_weight [15147,15161]
===
match
---
trailer [26383,26388]
trailer [26383,26388]
===
match
---
name: start_date [36997,37007]
name: start_date [36997,37007]
===
match
---
name: schedule_interval [60299,60316]
name: schedule_interval [62247,62264]
===
match
---
name: dag_diff_load_time [45043,45061]
name: dag_diff_load_time [45043,45061]
===
match
---
simple_stmt [10418,10451]
simple_stmt [10418,10451]
===
match
---
name: dag [48225,48228]
name: dag [48225,48228]
===
match
---
name: dag_id [48633,48639]
name: dag_id [48633,48639]
===
match
---
name: subdag_id [32062,32071]
name: subdag_id [32062,32071]
===
match
---
atom_expr [52166,52184]
atom_expr [54114,54132]
===
match
---
name: include_downstream [38613,38631]
name: include_downstream [38613,38631]
===
match
---
name: dag_run_state [48547,48560]
name: dag_run_state [48547,48560]
===
match
---
string: 'Europe/Zurich' [20328,20343]
string: 'Europe/Zurich' [20328,20343]
===
match
---
name: start_date [39147,39157]
name: start_date [39147,39157]
===
match
---
name: fileloc [29759,29766]
name: fileloc [29759,29766]
===
match
---
name: DagModel [29133,29141]
name: DagModel [29133,29141]
===
match
---
operator: == [38200,38202]
operator: == [38200,38202]
===
match
---
name: following_schedule [41903,41921]
name: following_schedule [41903,41921]
===
match
---
name: dag [52220,52223]
name: dag [54168,54171]
===
match
---
name: next_dagrun_create_after [62714,62738]
name: next_dagrun_create_after [64662,64686]
===
match
---
name: enumerate [15850,15859]
name: enumerate [15850,15859]
===
match
---
name: dag2 [6426,6430]
name: dag2 [6426,6430]
===
match
---
name: DummyOperator [6579,6592]
name: DummyOperator [6579,6592]
===
match
---
simple_stmt [17981,18112]
simple_stmt [17981,18112]
===
match
---
comparison [21166,21219]
comparison [21166,21219]
===
match
---
operator: , [63258,63259]
operator: , [65206,65207]
===
match
---
name: timezone [59444,59452]
name: timezone [61392,61400]
===
match
---
name: calculated_weight [16326,16343]
name: calculated_weight [16326,16343]
===
match
---
name: state [2028,2033]
name: state [2028,2033]
===
match
---
operator: , [32349,32350]
operator: , [32349,32350]
===
match
---
string: 't3' [55217,55221]
string: 't3' [57165,57169]
===
match
---
operator: == [17684,17686]
operator: == [17684,17686]
===
match
---
trailer [2859,2865]
trailer [2859,2865]
===
match
---
operator: , [18388,18389]
operator: , [18388,18389]
===
match
---
name: isoformat [22953,22962]
name: isoformat [22953,22962]
===
match
---
name: ti1 [17464,17467]
name: ti1 [17464,17467]
===
match
---
name: remove [9331,9337]
name: remove [9331,9337]
===
match
---
trailer [8889,8902]
trailer [8889,8902]
===
match
---
simple_stmt [29325,29406]
simple_stmt [29325,29406]
===
match
---
simple_stmt [4275,4354]
simple_stmt [4275,4354]
===
match
---
operator: , [3780,3781]
operator: , [3780,3781]
===
match
---
name: test_dag_task_priority_weight_total_using_upstream [13792,13842]
name: test_dag_task_priority_weight_total_using_upstream [13792,13842]
===
match
---
atom_expr [21695,21721]
atom_expr [21695,21721]
===
match
---
atom_expr [56236,56269]
atom_expr [58184,58217]
===
match
---
name: dag [41342,41345]
name: dag [41342,41345]
===
match
---
trailer [25866,25872]
trailer [25866,25872]
===
match
---
operator: = [64686,64687]
operator: = [66634,66635]
===
match
---
operator: == [35597,35599]
operator: == [35597,35599]
===
match
---
name: session [34615,34622]
name: session [34615,34622]
===
match
---
trailer [35126,35131]
trailer [35126,35131]
===
match
---
operator: == [53011,53013]
operator: == [54959,54961]
===
match
---
name: prev [21688,21692]
name: prev [21688,21692]
===
match
---
name: t_1 [52101,52104]
name: t_1 [54049,54052]
===
match
---
operator: == [10701,10703]
operator: == [10701,10703]
===
match
---
funcdef [24076,24443]
funcdef [24076,24443]
===
match
---
simple_stmt [13194,13203]
simple_stmt [13194,13203]
===
match
---
comparison [29668,29713]
comparison [29668,29713]
===
match
---
operator: , [44320,44321]
operator: , [44320,44321]
===
match
---
trailer [59318,59361]
trailer [61266,61309]
===
match
---
name: execution_date [50822,50836]
name: execution_date [50822,50836]
===
match
---
number: 3 [22607,22608]
number: 3 [22607,22608]
===
match
---
simple_stmt [1306,1360]
simple_stmt [1306,1360]
===
match
---
assert_stmt [7168,7189]
assert_stmt [7168,7189]
===
match
---
trailer [54286,54293]
trailer [56234,56241]
===
match
---
name: task_id [29999,30006]
name: task_id [29999,30006]
===
match
---
trailer [42713,42724]
trailer [42713,42724]
===
match
---
operator: == [36079,36081]
operator: == [36079,36081]
===
match
---
operator: , [54704,54705]
operator: , [56652,56653]
===
match
---
simple_stmt [41602,41653]
simple_stmt [41602,41653]
===
match
---
atom_expr [60704,60724]
atom_expr [62652,62672]
===
match
---
atom_expr [39080,39169]
atom_expr [39080,39169]
===
match
---
with_item [35239,35286]
with_item [35239,35286]
===
match
---
atom_expr [35971,35998]
atom_expr [35971,35998]
===
match
---
string: """         Tests scheduling a dag with no previous runs         """ [38916,38984]
string: """         Tests scheduling a dag with no previous runs         """ [38916,38984]
===
match
---
number: 4 [24609,24610]
number: 4 [24609,24610]
===
match
---
name: DEFAULT_DATE [17204,17216]
name: DEFAULT_DATE [17204,17216]
===
match
---
atom_expr [58758,58787]
atom_expr [60706,60735]
===
match
---
name: DummyOperator [35398,35411]
name: DummyOperator [35398,35411]
===
match
---
operator: = [55542,55543]
operator: = [57490,57491]
===
match
---
name: self [10591,10595]
name: self [10591,10595]
===
match
---
atom_expr [47781,47827]
atom_expr [47781,47827]
===
match
---
funcdef [38245,38857]
funcdef [38245,38857]
===
match
---
argument [49344,49371]
argument [49344,49371]
===
match
---
arith_expr [55544,55577]
arith_expr [57492,57525]
===
match
---
number: 1 [59226,59227]
number: 1 [61174,61175]
===
match
---
argument [56652,56665]
argument [58600,58613]
===
match
---
name: following_schedule [23866,23884]
name: following_schedule [23866,23884]
===
match
---
decorated [66020,66282]
decorated [67968,68230]
===
match
---
string: """         Test DAG as a context manager.         When used as a context manager, Operators are automatically added to         the DAG (unless they specify a different DAG)         """ [5717,5902]
string: """         Test DAG as a context manager.         When used as a context manager, Operators are automatically added to         the DAG (unless they specify a different DAG)         """ [5717,5902]
===
match
---
name: raises [4629,4635]
name: raises [4629,4635]
===
match
---
operator: @ [51684,51685]
operator: @ [53632,53633]
===
match
---
expr_stmt [48159,48211]
expr_stmt [48159,48211]
===
match
---
operator: - [13294,13295]
operator: - [13294,13295]
===
match
---
name: dag_id [63366,63372]
name: dag_id [65314,65320]
===
match
---
trailer [57620,57643]
trailer [59568,59591]
===
match
---
operator: = [7849,7850]
operator: = [7849,7850]
===
match
---
name: all [62922,62925]
name: all [64870,64873]
===
match
---
operator: = [8852,8853]
operator: = [8852,8853]
===
match
---
name: dag [28188,28191]
name: dag [28188,28191]
===
match
---
name: self [5436,5440]
name: self [5436,5440]
===
match
---
name: range [54204,54209]
name: range [56152,56157]
===
match
---
atom_expr [67775,67789]
atom_expr [69723,69737]
===
match
---
name: append [25585,25591]
name: append [25585,25591]
===
match
---
atom_expr [24627,24650]
atom_expr [24627,24650]
===
match
---
name: test_following_previous_schedule_daily_dag_cet_to_cest [22354,22408]
name: test_following_previous_schedule_daily_dag_cet_to_cest [22354,22408]
===
match
---
atom_expr [68535,68548]
atom_expr [70483,70496]
===
match
---
trailer [8055,8072]
trailer [8055,8072]
===
match
---
string: 'tz_dag' [22717,22725]
string: 'tz_dag' [22717,22725]
===
match
---
operator: = [66047,66048]
operator: = [67995,67996]
===
match
---
name: DAG [53215,53218]
name: DAG [55163,55166]
===
match
---
atom [9507,9526]
atom [9507,9526]
===
match
---
arglist [8541,8605]
arglist [8541,8605]
===
match
---
name: next_dagrun_create_after [28414,28438]
name: next_dagrun_create_after [28414,28438]
===
match
---
suite [35158,35611]
suite [35158,35611]
===
match
---
operator: { [60246,60247]
operator: { [62194,62195]
===
match
---
name: weight [15311,15317]
name: weight [15311,15317]
===
match
---
simple_stmt [8413,8480]
simple_stmt [8413,8480]
===
match
---
decorator [65684,65700]
decorator [67632,67648]
===
match
---
trailer [29998,30030]
trailer [29998,30030]
===
match
---
trailer [33316,33318]
trailer [33316,33318]
===
match
---
name: DAG [24664,24667]
name: DAG [24664,24667]
===
match
---
name: DEFAULT_ARGS [64673,64685]
name: DEFAULT_ARGS [66621,66633]
===
match
---
trailer [10022,10027]
trailer [10022,10027]
===
match
---
decorator [3141,3155]
decorator [3141,3155]
===
match
---
string: 'airflow' [4785,4794]
string: 'airflow' [4785,4794]
===
match
---
argument [55765,55778]
argument [57713,57726]
===
match
---
name: set_upstream [8960,8972]
name: set_upstream [8960,8972]
===
match
---
name: DeprecationWarning [61934,61952]
name: DeprecationWarning [63882,63900]
===
match
---
name: TestQueries [63942,63953]
name: TestQueries [65890,65901]
===
match
---
comparison [17988,18111]
comparison [17988,18111]
===
match
---
simple_stmt [7586,7717]
simple_stmt [7586,7717]
===
match
---
operator: = [67407,67408]
operator: = [69355,69356]
===
match
---
name: op3 [35544,35547]
name: op3 [35544,35547]
===
match
---
simple_stmt [2356,2398]
simple_stmt [2356,2398]
===
match
---
parameters [24473,24479]
parameters [24473,24479]
===
match
---
atom_expr [38708,38719]
atom_expr [38708,38719]
===
match
---
operator: { [46160,46161]
operator: { [46160,46161]
===
match
---
atom_expr [20310,20344]
atom_expr [20310,20344]
===
match
---
atom_expr [20616,20680]
atom_expr [20616,20680]
===
match
---
trailer [57700,57712]
trailer [59648,59660]
===
match
---
name: dags [25511,25515]
name: dags [25511,25515]
===
match
---
operator: , [15839,15840]
operator: , [15839,15840]
===
match
---
operator: = [44523,44524]
operator: = [44523,44524]
===
match
---
name: dag [42710,42713]
name: dag [42710,42713]
===
match
---
trailer [32145,32152]
trailer [32145,32152]
===
match
---
decorator [56865,56909]
decorator [58813,58857]
===
match
---
name: args [44592,44596]
name: args [44592,44596]
===
match
---
trailer [29141,29148]
trailer [29141,29148]
===
match
---
name: default_args [15408,15420]
name: default_args [15408,15420]
===
match
---
string: 'role2' [61828,61835]
string: 'role2' [63776,63783]
===
match
---
name: unittest [63954,63962]
name: unittest [65902,65910]
===
match
---
expr_stmt [62537,62807]
expr_stmt [64485,64755]
===
match
---
number: 1 [58187,58188]
number: 1 [60135,60136]
===
match
---
atom_expr [36425,36455]
atom_expr [36425,36455]
===
match
---
dictorsetmaker [18631,18649]
dictorsetmaker [18631,18649]
===
match
---
name: path [19085,19089]
name: path [19085,19089]
===
match
---
expr_stmt [67403,67426]
expr_stmt [69351,69374]
===
match
---
name: create_session [24253,24267]
name: create_session [24253,24267]
===
match
---
trailer [54039,54048]
trailer [55987,55996]
===
match
---
operator: == [7243,7245]
operator: == [7243,7245]
===
match
---
assert_stmt [47375,47423]
assert_stmt [47375,47423]
===
match
---
simple_stmt [59797,59855]
simple_stmt [61745,61803]
===
match
---
assert_stmt [34328,34365]
assert_stmt [34328,34365]
===
match
---
argument [7842,7860]
argument [7842,7860]
===
match
---
operator: = [53472,53473]
operator: = [55420,55421]
===
match
---
atom [10245,10255]
atom [10245,10255]
===
match
---
name: op2 [10251,10254]
name: op2 [10251,10254]
===
match
---
testlist_comp [20043,20055]
testlist_comp [20043,20055]
===
match
---
expr_stmt [52209,52405]
expr_stmt [54157,54353]
===
match
---
name: value [69107,69112]
name: value [71055,71060]
===
match
---
number: 2016 [59591,59595]
number: 2016 [61539,61543]
===
match
---
number: 2 [4263,4264]
number: 2 [4263,4264]
===
match
---
operator: = [6600,6601]
operator: = [6600,6601]
===
match
---
name: pytest [1099,1105]
name: pytest [1099,1105]
===
match
---
comparison [3075,3100]
comparison [3075,3100]
===
match
---
name: section_1 [60756,60765]
name: section_1 [62704,62713]
===
match
---
name: merge [52577,52582]
name: merge [54525,54530]
===
match
---
name: convert_to_utc [20579,20593]
name: convert_to_utc [20579,20593]
===
match
---
simple_stmt [27775,27825]
simple_stmt [27775,27825]
===
match
---
operator: - [3284,3285]
operator: - [3284,3285]
===
match
---
name: DummyOperator [30771,30784]
name: DummyOperator [30771,30784]
===
match
---
param [5436,5440]
param [5436,5440]
===
match
---
operator: { [9507,9508]
operator: { [9507,9508]
===
match
---
simple_stmt [8915,8944]
simple_stmt [8915,8944]
===
match
---
string: 'airflow' [43909,43918]
string: 'airflow' [43909,43918]
===
match
---
name: last_loaded [44800,44811]
name: last_loaded [44800,44811]
===
match
---
simple_stmt [3714,3743]
simple_stmt [3714,3743]
===
match
---
name: parameterized [1215,1228]
name: parameterized [1215,1228]
===
match
---
trailer [6418,6422]
trailer [6418,6422]
===
match
---
name: DummyOperator [19868,19881]
name: DummyOperator [19868,19881]
===
match
---
operator: { [37706,37707]
operator: { [37706,37707]
===
match
---
trailer [52622,52624]
trailer [54570,54572]
===
match
---
operator: = [6051,6052]
operator: = [6051,6052]
===
match
---
trailer [21792,21802]
trailer [21792,21802]
===
match
---
simple_stmt [7144,7159]
simple_stmt [7144,7159]
===
match
---
parameters [65322,65327]
parameters [67270,67275]
===
match
---
assert_stmt [21159,21219]
assert_stmt [21159,21219]
===
match
---
number: 10 [59607,59609]
number: 10 [61555,61557]
===
match
---
name: where [34659,34664]
name: where [34659,34664]
===
match
---
name: state [27979,27984]
name: state [27979,27984]
===
match
---
operator: { [26810,26811]
operator: { [26810,26811]
===
match
---
expr_stmt [14133,14492]
expr_stmt [14133,14492]
===
match
---
atom_expr [22228,22250]
atom_expr [22228,22250]
===
match
---
name: mock_callback_with_exception [40079,40107]
name: mock_callback_with_exception [40079,40107]
===
match
---
name: dag_run [40689,40696]
name: dag_run [40689,40696]
===
match
---
string: 'dag-bulk-sync-1' [26096,26113]
string: 'dag-bulk-sync-1' [26096,26113]
===
match
---
trailer [32234,32271]
trailer [32234,32271]
===
match
---
simple_stmt [32624,32655]
simple_stmt [32624,32655]
===
match
---
expr_stmt [12525,12534]
expr_stmt [12525,12534]
===
match
---
comparison [23102,23155]
comparison [23102,23155]
===
match
---
trailer [8287,8329]
trailer [8287,8329]
===
match
---
trailer [42304,42333]
trailer [42304,42333]
===
match
---
simple_stmt [37169,37180]
simple_stmt [37169,37180]
===
match
---
simple_stmt [65749,65760]
simple_stmt [67697,67708]
===
match
---
name: updated_permissions [62244,62263]
name: updated_permissions [64192,64211]
===
match
---
expr_stmt [33869,33929]
expr_stmt [33869,33929]
===
match
---
atom_expr [47398,47408]
atom_expr [47398,47408]
===
match
---
operator: = [32937,32938]
operator: = [32937,32938]
===
match
---
trailer [58012,58226]
trailer [59960,60174]
===
match
---
operator: , [61784,61785]
operator: , [63732,63733]
===
match
---
atom_expr [68608,68683]
atom_expr [70556,70631]
===
match
---
operator: = [62365,62366]
operator: = [64313,64314]
===
match
---
expr_stmt [48672,48733]
expr_stmt [48672,48733]
===
match
---
name: start_date [53961,53971]
name: start_date [55909,55919]
===
match
---
name: schedule_interval [59627,59644]
name: schedule_interval [61575,61592]
===
match
---
string: """         Test `default_view` default value of DAG initialization         """ [4856,4935]
string: """         Test `default_view` default value of DAG initialization         """ [4856,4935]
===
match
---
number: 0 [59611,59612]
number: 0 [61559,61560]
===
match
---
name: dag [16110,16113]
name: dag [16110,16113]
===
match
---
name: synchronize_session [3005,3024]
name: synchronize_session [3005,3024]
===
match
---
name: set2 [10418,10422]
name: set2 [10418,10422]
===
match
---
arglist [16961,17004]
arglist [16961,17004]
===
match
---
atom_expr [19099,19105]
atom_expr [19099,19105]
===
match
---
name: datetime [34878,34886]
name: datetime [34878,34886]
===
match
---
name: merge [17539,17544]
name: merge [17539,17544]
===
match
---
arglist [37627,37648]
arglist [37627,37648]
===
match
---
trailer [24237,24239]
trailer [24237,24239]
===
match
---
name: self [15222,15226]
name: self [15222,15226]
===
match
---
import_as_names [1250,1266]
import_as_names [1250,1266]
===
match
---
atom_expr [29102,29164]
atom_expr [29102,29164]
===
match
---
atom_expr [18993,19002]
atom_expr [18993,19002]
===
match
---
expr_stmt [54728,54836]
expr_stmt [56676,56784]
===
match
---
expr_stmt [35965,35998]
expr_stmt [35965,35998]
===
match
---
name: now [55295,55298]
name: now [57243,57246]
===
match
---
suite [7486,7577]
suite [7486,7577]
===
match
---
name: bulk_write_to_db [25494,25510]
name: bulk_write_to_db [25494,25510]
===
match
---
trailer [19772,19843]
trailer [19772,19843]
===
match
---
name: task [17297,17301]
name: task [17297,17301]
===
match
---
operator: { [6052,6053]
operator: { [6052,6053]
===
match
---
number: 1 [3285,3286]
number: 1 [3285,3286]
===
match
---
name: session [49194,49201]
name: session [49194,49201]
===
match
---
string: '2' [44657,44660]
string: '2' [44657,44660]
===
match
---
trailer [62891,62912]
trailer [64839,64860]
===
match
---
atom_expr [8786,8812]
atom_expr [8786,8812]
===
match
---
string: 'airflow' [63266,63275]
string: 'airflow' [65214,65223]
===
match
---
expr_stmt [2356,2397]
expr_stmt [2356,2397]
===
match
---
name: execution_date [47586,47600]
name: execution_date [47586,47600]
===
match
---
operator: == [22965,22967]
operator: == [22965,22967]
===
match
---
suite [15449,16362]
suite [15449,16362]
===
match
---
name: start_date [5928,5938]
name: start_date [5928,5938]
===
match
---
trailer [67496,67502]
trailer [69444,69450]
===
match
---
atom_expr [36616,36631]
atom_expr [36616,36631]
===
match
---
trailer [30419,30423]
trailer [30419,30423]
===
match
---
simple_stmt [51101,51132]
simple_stmt [51101,51132]
===
match
---
simple_stmt [12406,12447]
simple_stmt [12406,12447]
===
match
---
name: task_id [62448,62455]
name: task_id [64396,64403]
===
match
---
name: dag [60739,60742]
name: dag [62687,62690]
===
match
---
operator: , [11612,11613]
operator: , [11612,11613]
===
match
---
operator: @ [67089,67090]
operator: @ [69037,69038]
===
match
---
name: settings [34427,34435]
name: settings [34427,34435]
===
match
---
atom [34863,34925]
atom [34863,34925]
===
match
---
string: 'test-dag2' [26313,26324]
string: 'test-dag2' [26313,26324]
===
match
---
dictorsetmaker [32033,32080]
dictorsetmaker [32033,32080]
===
match
---
arglist [12012,12022]
arglist [12012,12022]
===
match
---
atom_expr [6874,6884]
atom_expr [6874,6884]
===
match
---
argument [18346,18388]
argument [18346,18388]
===
match
---
name: prev_local [21114,21124]
name: prev_local [21114,21124]
===
match
---
argument [49280,49330]
argument [49280,49330]
===
match
---
operator: = [32571,32572]
operator: = [32571,32572]
===
match
---
name: end_date [53993,54001]
name: end_date [55941,55949]
===
match
---
argument [56140,56176]
argument [58088,58124]
===
match
---
name: subdag [28905,28911]
name: subdag [28905,28911]
===
match
---
argument [33981,34009]
argument [33981,34009]
===
match
---
operator: = [16274,16275]
operator: = [16274,16275]
===
match
---
name: dag [37926,37929]
name: dag [37926,37929]
===
match
---
expr_stmt [47123,47147]
expr_stmt [47123,47147]
===
match
---
operator: == [67790,67792]
operator: == [69738,69740]
===
match
---
operator: == [20873,20875]
operator: == [20873,20875]
===
match
---
operator: , [64529,64530]
operator: , [66477,66478]
===
match
---
operator: = [8762,8763]
operator: = [8762,8763]
===
match
---
name: dag [33938,33941]
name: dag [33938,33941]
===
match
---
name: timezone [53423,53431]
name: timezone [55371,55379]
===
match
---
funcdef [57766,58788]
funcdef [59714,60736]
===
match
---
trailer [31343,31354]
trailer [31343,31354]
===
match
---
trailer [52547,52554]
trailer [54495,54502]
===
match
---
suite [23495,24071]
suite [23495,24071]
===
match
---
comparison [33123,33163]
comparison [33123,33163]
===
match
---
string: "2018-03-24T02:00:00+00:00" [22968,22995]
string: "2018-03-24T02:00:00+00:00" [22968,22995]
===
match
---
name: DEFAULT_DATE [63521,63533]
name: DEFAULT_DATE [65469,65481]
===
match
---
name: query [41618,41623]
name: query [41618,41623]
===
match
---
name: task_decorator [66679,66693]
name: task_decorator [68627,68641]
===
match
---
operator: = [8093,8094]
operator: = [8093,8094]
===
match
---
trailer [17544,17549]
trailer [17544,17549]
===
match
---
name: task_id [38157,38164]
name: task_id [38157,38164]
===
match
---
name: VALUE [64915,64920]
name: VALUE [66863,66868]
===
match
---
operator: , [17725,17726]
operator: , [17725,17726]
===
match
---
name: test_dag_id [43966,43977]
name: test_dag_id [43966,43977]
===
match
---
expr_stmt [44350,44394]
expr_stmt [44350,44394]
===
match
---
name: start_date [56602,56612]
name: start_date [58550,58560]
===
match
---
parameters [66092,66094]
parameters [68040,68042]
===
match
---
name: session [51179,51186]
name: session [51179,51186]
===
match
---
name: dag [59489,59492]
name: dag [61437,61440]
===
match
---
comparison [47648,47698]
comparison [47648,47698]
===
match
---
trailer [64843,64854]
trailer [66791,66802]
===
match
---
fstring_string: manual__ [47663,47671]
fstring_string: manual__ [47663,47671]
===
match
---
string: 'end_date' [10954,10964]
string: 'end_date' [10954,10964]
===
match
---
name: DagModel [31442,31450]
name: DagModel [31442,31450]
===
match
---
name: start_date [51228,51238]
name: start_date [51228,51238]
===
match
---
argument [53304,53329]
argument [55252,55277]
===
match
---
argument [54062,54082]
argument [56010,56030]
===
match
---
argument [67604,67623]
argument [69552,69571]
===
match
---
operator: , [49095,49096]
operator: , [49095,49096]
===
match
---
name: when [40475,40479]
name: when [40475,40479]
===
match
---
name: test_clear_set_dagrun_state [48513,48540]
name: test_clear_set_dagrun_state [48513,48540]
===
match
---
name: TIMEZONE [12066,12074]
name: TIMEZONE [12066,12074]
===
match
---
comparison [45683,45705]
comparison [45683,45705]
===
match
---
operator: = [49724,49725]
operator: = [49724,49725]
===
match
---
name: session [33400,33407]
name: session [33400,33407]
===
match
---
decorated [66585,66785]
decorated [68533,68733]
===
match
---
operator: , [60641,60642]
operator: , [62589,62590]
===
match
---
argument [5928,5951]
argument [5928,5951]
===
match
---
name: task_id [54062,54069]
name: task_id [56010,56017]
===
match
---
atom_expr [30876,30947]
atom_expr [30876,30947]
===
match
---
funcdef [47704,48082]
funcdef [47704,48082]
===
match
---
operator: = [12350,12351]
operator: = [12350,12351]
===
match
---
name: dag_id [30403,30409]
name: dag_id [30403,30409]
===
match
---
simple_stmt [15311,15323]
simple_stmt [15311,15323]
===
match
---
suite [66227,66255]
suite [68175,68203]
===
match
---
name: dag_id [53953,53959]
name: dag_id [55901,55907]
===
match
---
if_stmt [3417,3464]
if_stmt [3417,3464]
===
match
---
operator: == [47395,47397]
operator: == [47395,47397]
===
match
---
atom_expr [19224,19252]
atom_expr [19224,19252]
===
match
---
trailer [49589,49645]
trailer [49589,49645]
===
match
---
name: isoformat [22302,22311]
name: isoformat [22302,22311]
===
match
---
operator: = [15003,15004]
operator: = [15003,15004]
===
match
---
name: f [19637,19638]
name: f [19637,19638]
===
match
---
simple_stmt [32120,32184]
simple_stmt [32120,32184]
===
match
---
trailer [18280,18303]
trailer [18280,18303]
===
match
---
testlist_comp [46617,46671]
testlist_comp [46617,46671]
===
match
---
name: _clean_up [51982,51991]
name: _clean_up [53930,53939]
===
match
---
expr_stmt [17014,17030]
expr_stmt [17014,17030]
===
match
---
argument [54003,54026]
argument [55951,55974]
===
match
---
operator: == [22028,22030]
operator: == [22028,22030]
===
match
---
expr_stmt [35300,35333]
expr_stmt [35300,35333]
===
match
---
name: datetime [61214,61222]
name: datetime [63162,63170]
===
match
---
argument [53984,54001]
argument [55932,55949]
===
match
---
string: 'should_fail' [16634,16647]
string: 'should_fail' [16634,16647]
===
match
---
parameters [57833,57839]
parameters [59781,59787]
===
match
---
name: WeightRule [2187,2197]
name: WeightRule [2187,2197]
===
match
---
arglist [50500,50643]
arglist [50500,50643]
===
match
---
trailer [9903,9918]
trailer [9903,9918]
===
match
---
simple_stmt [8825,8858]
simple_stmt [8825,8858]
===
match
---
string: """Test that checks you can set dag_id from decorator.""" [65117,65174]
string: """Test that checks you can set dag_id from decorator.""" [67065,67122]
===
match
---
argument [60558,60587]
argument [62506,62535]
===
match
---
name: session [17856,17863]
name: session [17856,17863]
===
match
---
argument [47206,47223]
argument [47206,47223]
===
match
---
suite [33408,33624]
suite [33408,33624]
===
match
---
name: DagTag [27062,27068]
name: DagTag [27062,27068]
===
match
---
name: state [17018,17023]
name: state [17018,17023]
===
match
---
suite [38306,38857]
suite [38306,38857]
===
match
---
argument [61977,62009]
argument [63925,63957]
===
match
---
trailer [17361,17369]
trailer [17361,17369]
===
match
---
operator: , [39563,39564]
operator: , [39563,39564]
===
match
---
assert_stmt [45803,45841]
assert_stmt [45803,45841]
===
match
---
atom_expr [22515,22549]
atom_expr [22515,22549]
===
match
---
trailer [15375,15441]
trailer [15375,15441]
===
match
---
trailer [17463,17468]
trailer [17463,17468]
===
match
---
trailer [56502,56676]
trailer [58450,58624]
===
match
---
name: all [25890,25893]
name: all [25890,25893]
===
match
---
simple_stmt [30847,30862]
simple_stmt [30847,30862]
===
match
---
expr_stmt [30847,30861]
expr_stmt [30847,30861]
===
match
---
argument [8548,8571]
argument [8548,8571]
===
match
---
operator: , [19164,19165]
operator: , [19164,19165]
===
match
---
simple_stmt [52634,52785]
simple_stmt [54582,54733]
===
match
---
arith_expr [53843,53874]
arith_expr [55791,55822]
===
match
---
atom [14162,14437]
atom [14162,14437]
===
match
---
name: range [15733,15738]
name: range [15733,15738]
===
match
---
operator: } [12901,12902]
operator: } [12901,12902]
===
match
---
atom_expr [12413,12425]
atom_expr [12413,12425]
===
match
---
operator: { [4248,4249]
operator: { [4248,4249]
===
match
---
argument [59256,59285]
argument [61204,61233]
===
match
---
operator: , [46415,46416]
operator: , [46415,46416]
===
match
---
name: task_id [7895,7902]
name: task_id [7895,7902]
===
match
---
trailer [26774,26776]
trailer [26774,26776]
===
match
---
name: next_local [20850,20860]
name: next_local [20850,20860]
===
match
---
number: 1 [49328,49329]
number: 1 [49328,49329]
===
match
---
name: isoformat [21018,21027]
name: isoformat [21018,21027]
===
match
---
name: ti3 [17518,17521]
name: ti3 [17518,17521]
===
match
---
name: dag [11584,11587]
name: dag [11584,11587]
===
match
---
name: prev_local [22879,22889]
name: prev_local [22879,22889]
===
match
---
trailer [31175,31185]
trailer [31175,31185]
===
match
---
name: pipeline [13283,13291]
name: pipeline [13283,13291]
===
match
---
expr_stmt [19066,19106]
expr_stmt [19066,19106]
===
match
---
simple_stmt [54036,54104]
simple_stmt [55984,56052]
===
match
---
operator: { [38203,38204]
operator: { [38203,38204]
===
match
---
atom [32033,32047]
atom [32033,32047]
===
match
---
atom_expr [18722,18739]
atom_expr [18722,18739]
===
match
---
simple_stmt [41157,41232]
simple_stmt [41157,41232]
===
match
---
name: xcom_pull [68742,68751]
name: xcom_pull [70690,70699]
===
match
---
expr_stmt [3295,3307]
expr_stmt [3295,3307]
===
match
---
name: start_date [52657,52667]
name: start_date [54605,54615]
===
match
---
operator: = [28922,28923]
operator: = [28922,28923]
===
match
---
trailer [31567,31571]
trailer [31567,31571]
===
match
---
name: dag_diff_name [44469,44482]
name: dag_diff_name [44469,44482]
===
match
---
arglist [12129,12139]
arglist [12129,12139]
===
match
---
operator: , [14246,14247]
operator: , [14246,14247]
===
match
---
expr_stmt [19266,19297]
expr_stmt [19266,19297]
===
match
---
trailer [58766,58775]
trailer [60714,60723]
===
match
---
trailer [3101,3108]
trailer [3101,3108]
===
match
---
operator: == [46987,46989]
operator: == [46987,46989]
===
match
---
name: start_date [29886,29896]
name: start_date [29886,29896]
===
match
---
simple_stmt [67260,67271]
simple_stmt [69208,69219]
===
match
---
operator: = [68196,68197]
operator: = [70144,70145]
===
match
---
operator: == [39672,39674]
operator: == [39672,39674]
===
match
---
comparison [25929,26396]
comparison [25929,26396]
===
match
---
operator: = [41430,41431]
operator: = [41430,41431]
===
match
---
trailer [36628,36631]
trailer [36628,36631]
===
match
---
operator: , [34009,34010]
operator: , [34009,34010]
===
match
---
testlist_comp [31615,31628]
testlist_comp [31615,31628]
===
match
---
operator: , [62586,62587]
operator: , [64534,64535]
===
match
---
name: dag [48845,48848]
name: dag [48845,48848]
===
match
---
name: DagRunType [2138,2148]
name: DagRunType [2138,2148]
===
match
---
argument [55616,55655]
argument [57564,57603]
===
match
---
name: _occur_before [8198,8211]
name: _occur_before [8198,8211]
===
match
---
suite [27249,28447]
suite [27249,28447]
===
match
---
operator: != [51776,51778]
operator: != [53724,53726]
===
match
---
expr_stmt [13969,13978]
expr_stmt [13969,13978]
===
match
---
arglist [15552,15681]
arglist [15552,15681]
===
match
---
number: 0 [13074,13075]
number: 0 [13074,13075]
===
match
---
trailer [34886,34895]
trailer [34886,34895]
===
match
---
trailer [38014,38028]
trailer [38014,38028]
===
match
---
trailer [10483,10486]
trailer [10483,10486]
===
match
---
name: DEFAULT_DATE [51274,51286]
name: DEFAULT_DATE [51274,51286]
===
match
---
operator: , [35604,35605]
operator: , [35604,35605]
===
match
---
funcdef [65902,66446]
funcdef [67850,68394]
===
match
---
simple_stmt [61711,61907]
simple_stmt [63659,63855]
===
match
---
parameters [56981,56987]
parameters [58929,58935]
===
match
---
name: DEFAULT_DATE [19152,19164]
name: DEFAULT_DATE [19152,19164]
===
match
---
operator: = [50338,50339]
operator: = [50338,50339]
===
match
---
name: _next [21099,21104]
name: _next [21099,21104]
===
match
---
trailer [67756,67759]
trailer [69704,69707]
===
match
---
operator: , [46595,46596]
operator: , [46595,46596]
===
match
---
argument [30802,30822]
argument [30802,30822]
===
match
---
name: num [67267,67270]
name: num [69215,69218]
===
match
---
argument [52121,52136]
argument [54069,54084]
===
match
---
name: dag [28889,28892]
name: dag [28889,28892]
===
match
---
string: 'Also fake' [23809,23820]
string: 'Also fake' [23809,23820]
===
match
---
atom_expr [51821,51835]
atom_expr [53769,53783]
===
match
---
name: datetime [57692,57700]
name: datetime [59640,59648]
===
match
---
atom_expr [3770,3780]
atom_expr [3770,3780]
===
match
---
name: dag [37586,37589]
name: dag [37586,37589]
===
match
---
name: task_id [37627,37634]
name: task_id [37627,37634]
===
match
---
suite [36794,37232]
suite [36794,37232]
===
match
---
name: sub_dag [38711,38718]
name: sub_dag [38711,38718]
===
match
---
atom_expr [31137,31154]
atom_expr [31137,31154]
===
match
---
name: stdout_lines [36555,36567]
name: stdout_lines [36555,36567]
===
match
---
string: 'test-dag2' [26016,26027]
string: 'test-dag2' [26016,26027]
===
match
---
operator: , [49472,49473]
operator: , [49472,49473]
===
match
---
string: "t1" [37635,37639]
string: "t1" [37635,37639]
===
match
---
trailer [46231,46237]
trailer [46231,46237]
===
match
---
operator: , [48455,48456]
operator: , [48455,48456]
===
match
---
assert_stmt [52984,53015]
assert_stmt [54932,54963]
===
match
---
operator: , [55166,55167]
operator: , [57114,57115]
===
match
---
operator: = [12882,12883]
operator: = [12882,12883]
===
match
---
trailer [59759,59782]
trailer [61707,61730]
===
match
---
name: self [13843,13847]
name: self [13843,13847]
===
match
---
name: utc [20720,20723]
name: utc [20720,20723]
===
match
---
trailer [44428,44460]
trailer [44428,44460]
===
match
---
param [3177,3179]
param [3177,3179]
===
match
---
name: TI [2977,2979]
name: TI [2977,2979]
===
match
---
trailer [50447,50449]
trailer [50447,50449]
===
match
---
simple_stmt [8186,8254]
simple_stmt [8186,8254]
===
match
---
suite [24480,27196]
suite [24480,27196]
===
match
---
assert_stmt [28136,28157]
assert_stmt [28136,28157]
===
match
---
expr_stmt [43892,43947]
expr_stmt [43892,43947]
===
match
---
operator: , [41286,41287]
operator: , [41286,41287]
===
match
---
assert_stmt [68139,68173]
assert_stmt [70087,70121]
===
match
---
trailer [46968,46986]
trailer [46968,46986]
===
match
---
number: 0 [38697,38698]
number: 0 [38697,38698]
===
match
---
simple_stmt [12346,12398]
simple_stmt [12346,12398]
===
match
---
atom [18069,18084]
atom [18069,18084]
===
match
---
suite [64668,69277]
suite [66616,71225]
===
match
---
operator: == [43728,43730]
operator: == [43728,43730]
===
match
---
name: _next [20763,20768]
name: _next [20763,20768]
===
match
---
name: clear [40796,40801]
name: clear [40796,40801]
===
match
---
operator: , [15623,15624]
operator: , [15623,15624]
===
match
---
name: task_id [55209,55216]
name: task_id [57157,57164]
===
match
---
operator: , [50247,50248]
operator: , [50247,50248]
===
match
---
param [66222,66225]
param [68170,68173]
===
match
---
operator: , [61227,61228]
operator: , [63175,63176]
===
match
---
atom_expr [9825,9851]
atom_expr [9825,9851]
===
match
---
string: 'owner2' [6062,6070]
string: 'owner2' [6062,6070]
===
match
---
argument [49420,49443]
argument [49420,49443]
===
match
---
name: set1 [10196,10200]
name: set1 [10196,10200]
===
match
---
name: run_id [47651,47657]
name: run_id [47651,47657]
===
match
---
testlist_comp [26096,26126]
testlist_comp [26096,26126]
===
match
---
trailer [2626,2628]
trailer [2626,2628]
===
match
---
atom_expr [36190,36230]
atom_expr [36190,36230]
===
match
---
name: State [67610,67615]
name: State [69558,69563]
===
match
---
expr_stmt [61967,62047]
expr_stmt [63915,63995]
===
match
---
operator: = [10054,10055]
operator: = [10054,10055]
===
match
---
name: state [50988,50993]
name: state [50988,50993]
===
match
---
trailer [66889,66900]
trailer [68837,68848]
===
match
---
expr_stmt [50071,50085]
expr_stmt [50071,50085]
===
match
---
operator: , [6782,6783]
operator: , [6782,6783]
===
match
---
simple_stmt [27715,27766]
simple_stmt [27715,27766]
===
match
---
operator: = [59122,59123]
operator: = [61070,61071]
===
match
---
comparison [22297,22344]
comparison [22297,22344]
===
match
---
name: dag_id [2784,2790]
name: dag_id [2784,2790]
===
match
---
name: DummyOperator [8741,8754]
name: DummyOperator [8741,8754]
===
match
---
atom [46160,46168]
atom [46160,46168]
===
match
---
simple_stmt [29661,29714]
simple_stmt [29661,29714]
===
match
---
expr_stmt [52031,52092]
expr_stmt [53979,54040]
===
match
---
assert_stmt [43710,43784]
assert_stmt [43710,43784]
===
match
---
name: sub_dag [38576,38583]
name: sub_dag [38576,38583]
===
match
---
string: '.template' [19382,19393]
string: '.template' [19382,19393]
===
match
---
suite [13173,13203]
suite [13173,13203]
===
match
---
name: self [7307,7311]
name: self [7307,7311]
===
match
---
atom_expr [63296,63314]
atom_expr [65244,65262]
===
match
---
simple_stmt [35530,35562]
simple_stmt [35530,35562]
===
match
---
atom_expr [35833,35860]
atom_expr [35833,35860]
===
match
---
atom_expr [32670,32717]
atom_expr [32670,32717]
===
match
---
arglist [18033,18101]
arglist [18033,18101]
===
match
---
operator: @ [65684,65685]
operator: @ [67632,67633]
===
match
---
name: session [42789,42796]
name: session [42789,42796]
===
match
---
testlist_comp [26979,27009]
testlist_comp [26979,27009]
===
match
---
operator: = [10610,10611]
operator: = [10610,10611]
===
match
---
operator: , [8223,8224]
operator: , [8223,8224]
===
match
---
name: clear_db_runs [2471,2484]
name: clear_db_runs [2471,2484]
===
match
---
funcdef [5670,7251]
funcdef [5670,7251]
===
match
---
expr_stmt [6573,6607]
expr_stmt [6573,6607]
===
match
---
trailer [38664,38674]
trailer [38664,38674]
===
match
---
trailer [45741,45746]
trailer [45741,45746]
===
match
---
trailer [42353,42362]
trailer [42353,42362]
===
match
---
trailer [24371,24379]
trailer [24371,24379]
===
match
---
expr_stmt [23229,23264]
expr_stmt [23229,23264]
===
match
---
comparison [52991,53015]
comparison [54939,54963]
===
match
---
name: self [39863,39867]
name: self [39863,39867]
===
match
---
string: 'test_subdag_operator' [60565,60587]
string: 'test_subdag_operator' [62513,62535]
===
match
---
atom [25103,25134]
atom [25103,25134]
===
match
---
trailer [25243,25270]
trailer [25243,25270]
===
match
---
atom [32452,32469]
atom [32452,32469]
===
match
---
operator: = [17265,17266]
operator: = [17265,17266]
===
match
---
name: task_depth [14873,14883]
name: task_depth [14873,14883]
===
match
---
operator: , [58451,58452]
operator: , [60399,60400]
===
match
---
atom_expr [12352,12397]
atom_expr [12352,12397]
===
match
---
operator: == [51662,51664]
operator: == [51662,51664]
===
match
---
number: 4 [18272,18273]
number: 4 [18272,18273]
===
match
---
simple_stmt [57605,57655]
simple_stmt [59553,59603]
===
match
---
name: len [52991,52994]
name: len [54939,54942]
===
match
---
name: dag_id [47080,47086]
name: dag_id [47080,47086]
===
match
---
name: create_session [24704,24718]
name: create_session [24704,24718]
===
match
---
string: "t2" [35855,35859]
string: "t2" [35855,35859]
===
match
---
name: task_id [8890,8897]
name: task_id [8890,8897]
===
match
---
name: noop_pipeline [65802,65815]
name: noop_pipeline [67750,67763]
===
match
---
name: new_value [68577,68586]
name: new_value [70525,70534]
===
match
---
operator: , [26325,26326]
operator: , [26325,26326]
===
match
---
simple_stmt [863,879]
simple_stmt [863,879]
===
match
---
name: include_upstream [38590,38606]
name: include_upstream [38590,38606]
===
match
---
name: operator [68613,68621]
name: operator [70561,70569]
===
match
---
import_from [1667,1714]
import_from [1667,1714]
===
match
---
atom_expr [49607,49620]
atom_expr [49607,49620]
===
match
---
atom_expr [41945,41967]
atom_expr [41945,41967]
===
match
---
atom_expr [68739,68753]
atom_expr [70687,70701]
===
match
---
operator: , [54001,54002]
operator: , [55949,55950]
===
match
---
funcdef [69024,69072]
funcdef [70972,71020]
===
match
---
name: start_date [24165,24175]
name: start_date [24165,24175]
===
match
---
operator: = [52555,52556]
operator: = [54503,54504]
===
match
---
operator: { [29596,29597]
operator: { [29596,29597]
===
match
---
trailer [32855,32869]
trailer [32855,32869]
===
match
---
simple_stmt [7011,7046]
simple_stmt [7011,7046]
===
match
---
trailer [2865,2873]
trailer [2865,2873]
===
match
---
name: timezone [56460,56468]
name: timezone [58408,58416]
===
match
---
name: get_dagmodel [31713,31725]
name: get_dagmodel [31713,31725]
===
match
---
trailer [33574,33617]
trailer [33574,33617]
===
match
---
name: dag [62686,62689]
name: dag [64634,64637]
===
match
---
simple_stmt [27649,27661]
simple_stmt [27649,27661]
===
match
---
atom_expr [41639,41649]
atom_expr [41639,41649]
===
match
---
name: start_date [53843,53853]
name: start_date [55791,55801]
===
match
---
name: dagrun_1 [50883,50891]
name: dagrun_1 [50883,50891]
===
match
---
name: b_index [3295,3302]
name: b_index [3295,3302]
===
match
---
trailer [36984,37021]
trailer [36984,37021]
===
match
---
name: DagRunType [40549,40559]
name: DagRunType [40549,40559]
===
match
---
name: patch [2543,2548]
name: patch [2543,2548]
===
match
---
string: 'Also fake' [43264,43275]
string: 'Also fake' [43264,43275]
===
match
---
simple_stmt [10606,10682]
simple_stmt [10606,10682]
===
match
---
name: task [13378,13382]
name: task [13378,13382]
===
match
---
name: DAG [42227,42230]
name: DAG [42227,42230]
===
match
---
trailer [33947,34020]
trailer [33947,34020]
===
match
---
name: calculated_weight [16256,16273]
name: calculated_weight [16256,16273]
===
match
---
name: _next [24000,24005]
name: _next [24000,24005]
===
match
---
name: RUNNING [51000,51007]
name: RUNNING [51000,51007]
===
match
---
assert_stmt [45589,45615]
assert_stmt [45589,45615]
===
match
---
operator: = [17855,17856]
operator: = [17855,17856]
===
match
---
string: 'creating_dag_in_cm' [6888,6908]
string: 'creating_dag_in_cm' [6888,6908]
===
match
---
name: DEFAULT_DATE [30220,30232]
name: DEFAULT_DATE [30220,30232]
===
match
---
suite [29972,30267]
suite [29972,30267]
===
match
---
name: dag [64403,64406]
name: dag [66351,66354]
===
match
---
trailer [48051,48060]
trailer [48051,48060]
===
match
---
trailer [23176,23186]
trailer [23176,23186]
===
match
---
name: session [33004,33011]
name: session [33004,33011]
===
match
---
name: op2 [6151,6154]
name: op2 [6151,6154]
===
match
---
string: "Regular DAG documentation" [66418,66445]
string: "Regular DAG documentation" [68366,68393]
===
match
---
atom_expr [12834,12903]
atom_expr [12834,12903]
===
match
---
operator: = [10924,10925]
operator: = [10924,10925]
===
match
---
argument [49385,49406]
argument [49385,49406]
===
match
---
expr_stmt [42221,42245]
expr_stmt [42221,42245]
===
match
---
arith_expr [15006,15028]
arith_expr [15006,15028]
===
match
---
operator: , [66374,66375]
operator: , [68322,68323]
===
match
---
parameters [18881,18887]
parameters [18881,18887]
===
match
---
name: DagModel [31216,31224]
name: DagModel [31216,31224]
===
match
---
operator: @ [67944,67945]
operator: @ [69892,69893]
===
match
---
name: include_parentdag [49420,49437]
name: include_parentdag [49420,49437]
===
match
---
with_stmt [36866,37180]
with_stmt [36866,37180]
===
match
---
operator: = [12550,12551]
operator: = [12550,12551]
===
match
---
number: 1 [14902,14903]
number: 1 [14902,14903]
===
match
---
simple_stmt [46878,46950]
simple_stmt [46878,46950]
===
match
---
name: self [68918,68922]
name: self [70866,70870]
===
match
---
string: """         Make sure DST transitions are properly observed         """ [21326,21397]
string: """         Make sure DST transitions are properly observed         """ [21326,21397]
===
match
---
assert_stmt [24015,24070]
assert_stmt [24015,24070]
===
match
---
argument [55154,55166]
argument [57102,57114]
===
match
---
parameters [67163,67181]
parameters [69111,69129]
===
match
---
name: value [67164,67169]
name: value [69112,69117]
===
match
---
trailer [45789,45794]
trailer [45789,45794]
===
match
---
trailer [35319,35333]
trailer [35319,35333]
===
match
---
string: 'A' [8763,8766]
string: 'A' [8763,8766]
===
match
---
argument [35055,35080]
argument [35055,35080]
===
match
---
name: get_paused_dag_ids [46098,46116]
name: get_paused_dag_ids [46098,46116]
===
match
---
fstring_expr [12983,12986]
fstring_expr [12983,12986]
===
match
---
operator: , [9467,9468]
operator: , [9467,9468]
===
match
---
expr_stmt [35484,35517]
expr_stmt [35484,35517]
===
match
---
simple_stmt [829,839]
simple_stmt [829,839]
===
match
---
name: xcom_pass_to_op [69210,69225]
name: xcom_pass_to_op [71158,71173]
===
match
---
trailer [8799,8812]
trailer [8799,8812]
===
match
---
testlist_comp [26146,26175]
testlist_comp [26146,26175]
===
match
---
arglist [60851,60906]
arglist [62799,62854]
===
match
---
operator: = [50122,50123]
operator: = [50122,50123]
===
match
---
name: dag_id [65873,65879]
name: dag_id [67821,67827]
===
match
---
operator: { [54743,54744]
operator: { [56691,56692]
===
match
---
import_from [2198,2235]
import_from [2198,2235]
===
match
---
trailer [6688,6694]
trailer [6688,6694]
===
match
---
testlist_comp [26929,26959]
testlist_comp [26929,26959]
===
match
---
argument [22745,22774]
argument [22745,22774]
===
match
---
number: 3 [10484,10485]
number: 3 [10484,10485]
===
match
---
operator: , [26661,26662]
operator: , [26661,26662]
===
match
---
operator: = [6577,6578]
operator: = [6577,6578]
===
match
---
name: params_combined [4363,4378]
name: params_combined [4363,4378]
===
match
---
funcdef [38862,39784]
funcdef [38862,39784]
===
match
---
simple_stmt [17450,17469]
simple_stmt [17450,17469]
===
match
---
string: "2018-03-24T02:00:00+00:00" [23414,23441]
string: "2018-03-24T02:00:00+00:00" [23414,23441]
===
match
---
simple_stmt [9037,9068]
simple_stmt [9037,9068]
===
match
---
operator: = [46849,46850]
operator: = [46849,46850]
===
match
---
operator: = [14064,14065]
operator: = [14064,14065]
===
match
---
name: DagRun [2881,2887]
name: DagRun [2881,2887]
===
match
---
name: values [16124,16130]
name: values [16124,16130]
===
match
---
atom_expr [37707,37718]
atom_expr [37707,37718]
===
match
---
name: is_paused [31870,31879]
name: is_paused [31870,31879]
===
match
---
comparison [51649,51678]
comparison [51649,51678]
===
match
---
name: get_task_instances [67736,67754]
name: get_task_instances [69684,69702]
===
match
---
atom_expr [10418,10450]
atom_expr [10418,10450]
===
match
---
dictorsetmaker [36083,36091]
dictorsetmaker [36083,36091]
===
match
---
suite [51934,53152]
suite [53882,55100]
===
match
---
dotted_name [1365,1383]
dotted_name [1365,1383]
===
match
---
name: next_local [22005,22015]
name: next_local [22005,22015]
===
match
---
name: start_date [48690,48700]
name: start_date [48690,48700]
===
match
---
operator: , [52930,52931]
operator: , [54878,54879]
===
match
---
name: State [49132,49137]
name: State [49132,49137]
===
match
---
name: task_id [16907,16914]
name: task_id [16907,16914]
===
match
---
atom [5966,5985]
atom [5966,5985]
===
match
---
trailer [64465,64479]
trailer [66413,66427]
===
match
---
name: dag [55168,55171]
name: dag [57116,57119]
===
match
---
name: topological_list [9166,9182]
name: topological_list [9166,9182]
===
match
---
name: SUCCESS [42605,42612]
name: SUCCESS [42605,42612]
===
match
---
atom_expr [18561,18651]
atom_expr [18561,18651]
===
match
---
operator: , [30899,30900]
operator: , [30899,30900]
===
match
---
name: previous_schedule [23240,23257]
name: previous_schedule [23240,23257]
===
match
---
string: 'op6' [6851,6856]
string: 'op6' [6851,6856]
===
match
---
assert_stmt [9195,9230]
assert_stmt [9195,9230]
===
match
---
name: default_args [4304,4316]
name: default_args [4304,4316]
===
match
---
name: ABSOLUTE [15672,15680]
name: ABSOLUTE [15672,15680]
===
match
---
expr_stmt [65796,65817]
expr_stmt [67744,67765]
===
match
---
name: dag [65869,65872]
name: dag [67817,67820]
===
match
---
argument [62600,62613]
argument [64548,64561]
===
match
---
trailer [62858,62860]
trailer [64806,64808]
===
match
---
trailer [18567,18571]
trailer [18567,18571]
===
match
---
operator: = [35442,35443]
operator: = [35442,35443]
===
match
---
name: timezone [35101,35109]
name: timezone [35101,35109]
===
match
---
string: 'airflow.models.dag.Stats' [39796,39822]
string: 'airflow.models.dag.Stats' [39796,39822]
===
match
---
name: task_id [41266,41273]
name: task_id [41266,41273]
===
match
---
operator: + [23685,23686]
operator: + [23685,23686]
===
match
---
trailer [33567,33574]
trailer [33567,33574]
===
match
---
assert_stmt [44854,44871]
assert_stmt [44854,44871]
===
match
---
operator: = [53786,53787]
operator: = [55734,55735]
===
match
---
atom_expr [8956,8977]
atom_expr [8956,8977]
===
match
---
name: create_dagrun [48229,48242]
name: create_dagrun [48229,48242]
===
match
---
trailer [5652,5664]
trailer [5652,5664]
===
match
---
name: commit [51187,51193]
name: commit [51187,51193]
===
match
---
number: 5 [25639,25640]
number: 5 [25639,25640]
===
match
---
simple_stmt [53936,54028]
simple_stmt [55884,55976]
===
match
---
atom_expr [10196,10228]
atom_expr [10196,10228]
===
match
---
trailer [36440,36455]
trailer [36440,36455]
===
match
---
trailer [58503,58514]
trailer [60451,60462]
===
match
---
comp_if [51767,51792]
comp_if [53715,53740]
===
match
---
trailer [11958,12025]
trailer [11958,12025]
===
match
---
operator: , [39867,39868]
operator: , [39867,39868]
===
match
---
operator: = [15393,15394]
operator: = [15393,15394]
===
match
---
name: dag_id [34684,34690]
name: dag_id [34684,34690]
===
match
---
operator: , [56665,56666]
operator: , [58613,58614]
===
match
---
name: row [26722,26725]
name: row [26722,26725]
===
match
---
trailer [38696,38699]
trailer [38696,38699]
===
match
---
name: session [33303,33310]
name: session [33303,33310]
===
match
---
operator: = [55418,55419]
operator: = [57366,57367]
===
match
---
number: 2016 [59220,59224]
number: 2016 [61168,61172]
===
match
---
string: 't2' [38584,38588]
string: 't2' [38584,38588]
===
match
---
name: bulk_write_to_db [26540,26556]
name: bulk_write_to_db [26540,26556]
===
match
---
arglist [12093,12140]
arglist [12093,12140]
===
match
---
atom_expr [7064,7092]
atom_expr [7064,7092]
===
match
---
name: op3 [6446,6449]
name: op3 [6446,6449]
===
match
---
trailer [32097,32110]
trailer [32097,32110]
===
match
---
name: timedelta [41069,41078]
name: timedelta [41069,41078]
===
match
---
name: test_tree_view [36102,36116]
name: test_tree_view [36102,36116]
===
match
---
name: dag [63255,63258]
name: dag [65203,65206]
===
match
---
trailer [24902,24904]
trailer [24902,24904]
===
match
---
assert_stmt [18748,18794]
assert_stmt [18748,18794]
===
match
---
trailer [55153,55176]
trailer [57101,57124]
===
match
---
arglist [56896,56906]
arglist [58844,58854]
===
match
---
parameters [29828,29834]
parameters [29828,29834]
===
match
---
suite [64002,64027]
suite [65950,65975]
===
match
---
name: test_set_dag_runs_state [47017,47040]
name: test_set_dag_runs_state [47017,47040]
===
match
---
name: prev_local [21007,21017]
name: prev_local [21007,21017]
===
match
---
suite [37311,37725]
suite [37311,37725]
===
match
---
atom_expr [54204,54215]
atom_expr [56152,56163]
===
match
---
trailer [37065,37079]
trailer [37065,37079]
===
match
---
trailer [54239,54262]
trailer [56187,56210]
===
match
---
operator: == [44865,44867]
operator: == [44865,44867]
===
match
---
simple_stmt [13969,13979]
simple_stmt [13969,13979]
===
match
---
trailer [13135,13145]
trailer [13135,13145]
===
match
---
name: session [34186,34193]
name: session [34186,34193]
===
match
---
operator: { [61733,61734]
operator: { [63681,63682]
===
match
---
expr_stmt [53349,53393]
expr_stmt [55297,55341]
===
match
---
param [27243,27247]
param [27243,27247]
===
match
---
trailer [20870,20872]
trailer [20870,20872]
===
match
---
operator: = [50289,50290]
operator: = [50289,50290]
===
match
---
name: creating_job_id [48317,48332]
name: creating_job_id [48317,48332]
===
match
---
name: dag_id [51597,51603]
name: dag_id [51597,51603]
===
match
---
name: self [10886,10890]
name: self [10886,10890]
===
match
---
operator: , [50110,50111]
operator: , [50110,50111]
===
match
---
name: template_fields [19315,19330]
name: template_fields [19315,19330]
===
match
---
simple_stmt [67436,67635]
simple_stmt [69384,69583]
===
match
---
name: op4 [36033,36036]
name: op4 [36033,36036]
===
match
---
trailer [56002,56009]
trailer [57950,57957]
===
match
---
argument [47133,47146]
argument [47133,47146]
===
match
---
name: query [29480,29485]
name: query [29480,29485]
===
match
---
dictorsetmaker [38204,38238]
dictorsetmaker [38204,38238]
===
match
---
trailer [63813,63834]
trailer [65761,65782]
===
match
---
name: safe_dag_id [29429,29440]
name: safe_dag_id [29429,29440]
===
match
---
operator: , [26996,26997]
operator: , [26996,26997]
===
match
---
trailer [19435,19437]
trailer [19435,19437]
===
match
---
name: dag_id [50055,50061]
name: dag_id [50055,50061]
===
match
---
operator: , [42396,42397]
operator: , [42396,42397]
===
match
---
argument [35320,35332]
argument [35320,35332]
===
match
---
arglist [30680,30727]
arglist [30680,30727]
===
match
---
simple_stmt [52608,52625]
simple_stmt [54556,54573]
===
match
---
operator: = [28539,28540]
operator: = [28539,28540]
===
match
---
operator: = [53769,53770]
operator: = [55717,55718]
===
match
---
name: orm_dag [33534,33541]
name: orm_dag [33534,33541]
===
match
---
name: DagModel [46255,46263]
name: DagModel [46255,46263]
===
match
---
fstring_end: " [47222,47223]
fstring_end: " [47222,47223]
===
match
---
simple_stmt [45676,45706]
simple_stmt [45676,45706]
===
match
---
expr_stmt [43956,43997]
expr_stmt [43956,43997]
===
match
---
fstring [18530,18545]
fstring [18530,18545]
===
match
---
import_name [839,852]
import_name [839,852]
===
match
---
assert_stmt [12150,12190]
assert_stmt [12150,12190]
===
match
---
name: DagTag [25171,25177]
name: DagTag [25171,25177]
===
match
---
string: 't1' [50081,50085]
string: 't1' [50081,50085]
===
match
---
operator: , [49406,49407]
operator: , [49406,49407]
===
match
---
trailer [45687,45692]
trailer [45687,45692]
===
match
---
string: 'op1' [19890,19895]
string: 'op1' [19890,19895]
===
match
---
operator: = [43392,43393]
operator: = [43392,43393]
===
match
---
name: params2 [4238,4245]
name: params2 [4238,4245]
===
match
---
string: 'owner2' [29607,29615]
string: 'owner2' [29607,29615]
===
match
---
atom_expr [42350,42439]
atom_expr [42350,42439]
===
match
---
argument [40423,40443]
argument [40423,40443]
===
match
---
name: return_num [65773,65783]
name: return_num [67721,67731]
===
match
---
operator: * [15017,15018]
operator: * [15017,15018]
===
match
---
trailer [51565,51572]
trailer [51565,51572]
===
match
---
operator: , [16509,16510]
operator: , [16509,16510]
===
match
---
trailer [29678,29690]
trailer [29678,29690]
===
match
---
name: a [3177,3178]
name: a [3177,3178]
===
match
---
string: 'owner1' [29216,29224]
string: 'owner1' [29216,29224]
===
match
---
assert_stmt [9109,9144]
assert_stmt [9109,9144]
===
match
---
name: dag [20920,20923]
name: dag [20920,20923]
===
match
---
name: set [31676,31679]
name: set [31676,31679]
===
match
---
name: next_dagrun_after_date [54240,54262]
name: next_dagrun_after_date [56188,56210]
===
match
---
name: dag_subclass [44539,44551]
name: dag_subclass [44539,44551]
===
match
---
assert_stmt [58738,58787]
assert_stmt [60686,60735]
===
match
---
operator: , [7705,7706]
operator: , [7705,7706]
===
match
---
trailer [64778,64785]
trailer [66726,66733]
===
match
---
trailer [42375,42438]
trailer [42375,42438]
===
match
---
trailer [52838,52873]
trailer [54786,54821]
===
match
---
atom_expr [6212,6219]
atom_expr [6212,6219]
===
match
---
assert_stmt [38647,38719]
assert_stmt [38647,38719]
===
match
---
expr_stmt [48220,48349]
expr_stmt [48220,48349]
===
match
---
classdef [44185,44226]
classdef [44185,44226]
===
match
---
arglist [49607,49631]
arglist [49607,49631]
===
match
---
name: subdag [30142,30148]
name: subdag [30142,30148]
===
match
---
name: pytest [61921,61927]
name: pytest [63869,63875]
===
match
---
name: dag_id [29142,29148]
name: dag_id [29142,29148]
===
match
---
arglist [24525,24589]
arglist [24525,24589]
===
match
---
name: isoformat [23177,23186]
name: isoformat [23177,23186]
===
match
---
operator: = [31761,31762]
operator: = [31761,31762]
===
match
---
trailer [17147,17155]
trailer [17147,17155]
===
match
---
atom_expr [62845,62860]
atom_expr [64793,64808]
===
match
---
atom_expr [6279,6286]
atom_expr [6279,6286]
===
match
---
trailer [16906,16942]
trailer [16906,16942]
===
match
---
trailer [61659,61690]
trailer [63607,63638]
===
match
---
name: model [41602,41607]
name: model [41602,41607]
===
match
---
name: models [1443,1449]
name: models [1443,1449]
===
match
---
trailer [38492,38506]
trailer [38492,38506]
===
match
---
name: close [30537,30542]
name: close [30537,30542]
===
match
---
operator: , [17648,17649]
operator: , [17648,17649]
===
match
---
atom_expr [14890,14904]
atom_expr [14890,14904]
===
match
---
name: next_dagrun_after_date [55815,55837]
name: next_dagrun_after_date [57763,57785]
===
match
---
simple_stmt [34375,34450]
simple_stmt [34375,34450]
===
match
---
operator: , [65475,65476]
operator: , [67423,67424]
===
match
---
name: isoformat [23917,23926]
name: isoformat [23917,23926]
===
match
---
operator: , [39320,39321]
operator: , [39320,39321]
===
match
---
trailer [13494,13510]
trailer [13494,13510]
===
match
---
atom_expr [53361,53393]
atom_expr [55309,55341]
===
match
---
atom_expr [48618,48640]
atom_expr [48618,48640]
===
match
---
operator: = [9688,9689]
operator: = [9688,9689]
===
match
---
dictorsetmaker [54761,54822]
dictorsetmaker [56709,56770]
===
match
---
trailer [16113,16123]
trailer [16113,16123]
===
match
---
expr_stmt [24513,24612]
expr_stmt [24513,24612]
===
match
---
simple_stmt [51477,51634]
simple_stmt [51477,51634]
===
match
---
shift_expr [35530,35561]
shift_expr [35530,35561]
===
match
---
name: dag [46965,46968]
name: dag [46965,46968]
===
match
---
simple_stmt [59678,59735]
simple_stmt [61626,61683]
===
match
---
trailer [47784,47827]
trailer [47784,47827]
===
match
---
name: six_hours_ago_to_the_hour [56613,56638]
name: six_hours_ago_to_the_hour [58561,58586]
===
match
---
name: test_task [17178,17187]
name: test_task [17178,17187]
===
match
---
trailer [27113,27119]
trailer [27113,27119]
===
match
---
simple_stmt [50071,50086]
simple_stmt [50071,50086]
===
match
---
param [5120,5124]
param [5120,5124]
===
match
---
name: dst_rule [20418,20426]
name: dst_rule [20418,20426]
===
match
---
name: start_date [43478,43488]
name: start_date [43478,43488]
===
match
---
atom_expr [43143,43161]
atom_expr [43143,43161]
===
match
---
name: set [32094,32097]
name: set [32094,32097]
===
match
---
simple_stmt [48797,48826]
simple_stmt [48797,48826]
===
match
---
operator: = [31155,31156]
operator: = [31155,31156]
===
match
---
atom [31519,31538]
atom [31519,31538]
===
match
---
name: dag [43956,43959]
name: dag [43956,43959]
===
match
---
atom_expr [58111,58140]
atom_expr [60059,60088]
===
match
---
atom_expr [11850,11885]
atom_expr [11850,11885]
===
match
---
trailer [58551,58560]
trailer [60499,60508]
===
match
---
arglist [37503,37538]
arglist [37503,37538]
===
match
---
assert_stmt [39497,39642]
assert_stmt [39497,39642]
===
match
---
number: 1 [15027,15028]
number: 1 [15027,15028]
===
match
---
name: _clean_up [41950,41959]
name: _clean_up [41950,41959]
===
match
---
name: TEST_DATE [43288,43297]
name: TEST_DATE [43288,43297]
===
match
---
name: DAG [28493,28496]
name: DAG [28493,28496]
===
match
---
trailer [47577,47584]
trailer [47577,47584]
===
match
---
atom_expr [33639,33659]
atom_expr [33639,33659]
===
match
---
fstring_end: ' [12990,12991]
fstring_end: ' [12990,12991]
===
match
---
simple_stmt [55587,55790]
simple_stmt [57535,57738]
===
match
---
string: '2019-06-05T00:00:00' [11683,11704]
string: '2019-06-05T00:00:00' [11683,11704]
===
match
---
arglist [7895,7932]
arglist [7895,7932]
===
match
---
suite [25723,26397]
suite [25723,26397]
===
match
---
name: subdag [60951,60957]
name: subdag [62899,62905]
===
match
---
operator: = [45254,45255]
operator: = [45254,45255]
===
match
---
operator: , [10621,10622]
operator: , [10621,10622]
===
match
---
name: subdag [60837,60843]
name: subdag [62785,62791]
===
match
---
string: 'dag' [8541,8546]
string: 'dag' [8541,8546]
===
match
---
operator: = [48730,48731]
operator: = [48730,48731]
===
match
---
trailer [59825,59834]
trailer [61773,61782]
===
match
---
operator: = [35946,35947]
operator: = [35946,35947]
===
match
---
name: DummyOperator [35879,35892]
name: DummyOperator [35879,35892]
===
match
---
operator: = [57268,57269]
operator: = [59216,59217]
===
match
---
name: State [27985,27990]
name: State [27985,27990]
===
match
---
operator: , [33733,33734]
operator: , [33733,33734]
===
match
---
suite [8722,8978]
suite [8722,8978]
===
match
---
dotted_name [2299,2318]
dotted_name [2299,2318]
===
match
---
argument [51265,51315]
argument [51265,51315]
===
match
---
comparison [18272,18415]
comparison [18272,18415]
===
match
---
operator: } [60905,60906]
operator: } [62853,62854]
===
match
---
atom_expr [60844,60907]
atom_expr [62792,62855]
===
match
---
atom_expr [65429,65449]
atom_expr [67377,67397]
===
match
---
name: DAG [17687,17690]
name: DAG [17687,17690]
===
match
---
expr_stmt [51477,51633]
expr_stmt [51477,51633]
===
match
---
atom_expr [34335,34350]
atom_expr [34335,34350]
===
match
---
name: set2 [10320,10324]
name: set2 [10320,10324]
===
match
---
simple_stmt [7058,7093]
simple_stmt [7058,7093]
===
match
---
atom_expr [42363,42438]
atom_expr [42363,42438]
===
match
---
trailer [25304,25307]
trailer [25304,25307]
===
match
---
expr_stmt [34794,34839]
expr_stmt [34794,34839]
===
match
---
operator: , [10910,10911]
operator: , [10910,10911]
===
match
---
name: DAG [45939,45942]
name: DAG [45939,45942]
===
match
---
trailer [18437,18439]
trailer [18437,18439]
===
match
---
number: 1 [56902,56903]
number: 1 [58850,58851]
===
match
---
term [53856,53874]
term [55804,55822]
===
match
---
operator: = [5965,5966]
operator: = [5965,5966]
===
match
---
operator: = [19572,19573]
operator: = [19572,19573]
===
match
---
atom_expr [22948,22964]
atom_expr [22948,22964]
===
match
---
name: dag_pickle [44047,44057]
name: dag_pickle [44047,44057]
===
match
---
name: one [29159,29162]
name: one [29159,29162]
===
match
---
expr_stmt [21610,21678]
expr_stmt [21610,21678]
===
match
---
simple_stmt [61967,62048]
simple_stmt [63915,63996]
===
match
---
name: AirflowException [1391,1407]
name: AirflowException [1391,1407]
===
match
---
trailer [17382,17388]
trailer [17382,17388]
===
match
---
operator: , [40290,40291]
operator: , [40290,40291]
===
match
---
simple_stmt [63858,63882]
simple_stmt [65806,65830]
===
match
---
name: dag_diff_name [45767,45780]
name: dag_diff_name [45767,45780]
===
match
---
name: j [14399,14400]
name: j [14399,14400]
===
match
---
trailer [10094,10099]
trailer [10094,10099]
===
match
---
operator: , [24789,24790]
operator: , [24789,24790]
===
match
---
expr_stmt [13987,14029]
expr_stmt [13987,14029]
===
match
---
expr_stmt [23005,23040]
expr_stmt [23005,23040]
===
match
---
operator: , [2390,2391]
operator: , [2390,2391]
===
match
---
name: dag [3812,3815]
name: dag [3812,3815]
===
match
---
operator: = [6850,6851]
operator: = [6850,6851]
===
match
---
parameters [11032,11038]
parameters [11032,11038]
===
match
---
name: dag [39382,39385]
name: dag [39382,39385]
===
match
---
trailer [35100,35109]
trailer [35100,35109]
===
match
---
simple_stmt [1765,1817]
simple_stmt [1765,1817]
===
match
---
name: query [25165,25170]
name: query [25165,25170]
===
match
---
trailer [63834,63843]
trailer [65782,65791]
===
match
---
name: a [3374,3375]
name: a [3374,3375]
===
match
---
trailer [8363,8404]
trailer [8363,8404]
===
match
---
name: op1 [38041,38044]
name: op1 [38041,38044]
===
match
---
name: test_utils [2305,2315]
name: test_utils [2305,2315]
===
match
---
name: normalized_schedule_interval [42305,42333]
name: normalized_schedule_interval [42305,42333]
===
match
---
operator: = [40548,40549]
operator: = [40548,40549]
===
match
---
parameters [68018,68036]
parameters [69966,69984]
===
match
---
atom_expr [44425,44460]
atom_expr [44425,44460]
===
match
---
operator: , [58783,58784]
operator: , [60731,60732]
===
match
---
name: j [13021,13022]
name: j [13021,13022]
===
match
---
argument [60655,60672]
argument [62603,62620]
===
match
---
name: tasks [9239,9244]
name: tasks [9239,9244]
===
match
---
operator: = [55037,55038]
operator: = [56985,56986]
===
match
---
with_stmt [36420,36542]
with_stmt [36420,36542]
===
match
---
name: dag_run [39396,39403]
name: dag_run [39396,39403]
===
match
---
name: set [29558,29561]
name: set [29558,29561]
===
match
---
name: return_num [66710,66720]
name: return_num [68658,68668]
===
match
---
trailer [64963,64969]
trailer [66911,66917]
===
match
---
operator: } [54835,54836]
operator: } [56783,56784]
===
match
---
name: DEFAULT_DATE [41318,41330]
name: DEFAULT_DATE [41318,41330]
===
match
---
atom_expr [31233,31273]
atom_expr [31233,31273]
===
match
---
assert_stmt [21000,21060]
assert_stmt [21000,21060]
===
match
---
simple_stmt [28262,28301]
simple_stmt [28262,28301]
===
match
---
argument [34952,34977]
argument [34952,34977]
===
match
---
argument [51404,51427]
argument [51404,51427]
===
match
---
argument [63251,63258]
argument [65199,65206]
===
match
---
number: 3 [53788,53789]
number: 3 [55736,55737]
===
match
---
arglist [10788,10836]
arglist [10788,10836]
===
match
---
string: 'tag-1' [24196,24203]
string: 'tag-1' [24196,24203]
===
match
---
param [34779,34783]
param [34779,34783]
===
match
---
name: utcnow [68461,68467]
name: utcnow [70409,70415]
===
match
---
name: self [18882,18886]
name: self [18882,18886]
===
match
---
atom [4317,4336]
atom [4317,4336]
===
match
---
simple_stmt [25576,25605]
simple_stmt [25576,25605]
===
match
---
name: prev_local [23325,23335]
name: prev_local [23325,23335]
===
match
---
name: i [15568,15569]
name: i [15568,15569]
===
match
---
argument [16626,16647]
argument [16626,16647]
===
match
---
simple_stmt [57448,57498]
simple_stmt [59396,59446]
===
match
---
name: dag [66291,66294]
name: dag [68239,68242]
===
match
---
name: dag [44075,44078]
name: dag [44075,44078]
===
match
---
atom_expr [31844,31859]
atom_expr [31844,31859]
===
match
---
name: QUEUED [18366,18372]
name: QUEUED [18366,18372]
===
match
---
string: "test_fractional_seconds" [43103,43128]
string: "test_fractional_seconds" [43103,43128]
===
match
---
name: match [37424,37429]
name: match [37424,37429]
===
match
---
operator: , [54821,54822]
operator: , [56769,56770]
===
match
---
simple_stmt [32599,32616]
simple_stmt [32599,32616]
===
match
---
number: 1 [62422,62423]
number: 1 [64370,64371]
===
match
---
expr_stmt [38993,39038]
expr_stmt [38993,39038]
===
match
---
atom [25054,25085]
atom [25054,25085]
===
match
---
name: TI [17045,17047]
name: TI [17045,17047]
===
match
---
trailer [3083,3090]
trailer [3083,3090]
===
match
---
argument [4654,4710]
argument [4654,4710]
===
match
---
operator: = [69140,69141]
operator: = [71088,71089]
===
match
---
suite [62152,62207]
suite [64100,64155]
===
match
---
trailer [34639,34649]
trailer [34639,34649]
===
match
---
string: 'b_child' [8439,8448]
string: 'b_child' [8439,8448]
===
match
---
argument [40163,40176]
argument [40163,40176]
===
match
---
string: 'owner1' [14102,14110]
string: 'owner1' [14102,14110]
===
match
---
atom [64120,64168]
atom [66068,66116]
===
match
---
atom_expr [32484,32500]
atom_expr [32484,32500]
===
match
---
trailer [38120,38130]
trailer [38120,38130]
===
match
---
trailer [51153,51170]
trailer [51153,51170]
===
match
---
argument [64584,64608]
argument [66532,66556]
===
match
---
operator: = [10243,10244]
operator: = [10243,10244]
===
match
---
name: timezone [34998,35006]
name: timezone [34998,35006]
===
match
---
atom [53856,53866]
atom [55804,55814]
===
match
---
name: dag [27581,27584]
name: dag [27581,27584]
===
match
---
assert_stmt [42294,42341]
assert_stmt [42294,42341]
===
match
---
comparison [53410,53452]
comparison [55358,55400]
===
match
---
name: task_id [43236,43243]
name: task_id [43236,43243]
===
match
---
operator: = [21568,21569]
operator: = [21568,21569]
===
match
---
atom_expr [57269,57298]
atom_expr [59217,59246]
===
match
---
expr_stmt [12346,12397]
expr_stmt [12346,12397]
===
match
---
simple_stmt [40397,40482]
simple_stmt [40397,40482]
===
match
---
name: session [27612,27619]
name: session [27612,27619]
===
match
---
name: DAG [17885,17888]
name: DAG [17885,17888]
===
match
---
decorated [66678,66754]
decorated [68626,68702]
===
match
---
name: end_date [68656,68664]
name: end_date [70604,70612]
===
match
---
trailer [20719,20724]
trailer [20719,20724]
===
match
---
suite [62340,63012]
suite [64288,64960]
===
match
---
atom_expr [66767,66784]
atom_expr [68715,68732]
===
match
---
expr_stmt [11949,12025]
expr_stmt [11949,12025]
===
match
---
argument [6593,6606]
argument [6593,6606]
===
match
---
operator: = [37429,37430]
operator: = [37429,37430]
===
match
---
name: execution_date [41416,41430]
name: execution_date [41416,41430]
===
match
---
name: create_dagrun [47968,47981]
name: create_dagrun [47968,47981]
===
match
---
name: child_dag_name [60449,60463]
name: child_dag_name [62397,62411]
===
match
---
trailer [13073,13083]
trailer [13073,13083]
===
match
---
string: """         Test `orientation` default value of DAG initialization         """ [5451,5529]
string: """         Test `orientation` default value of DAG initialization         """ [5451,5529]
===
match
---
atom_expr [17014,17023]
atom_expr [17014,17023]
===
match
---
name: isoformat [22239,22248]
name: isoformat [22239,22248]
===
match
---
argument [52138,52145]
argument [54086,54093]
===
match
---
trailer [14046,14112]
trailer [14046,14112]
===
match
---
name: session [62913,62920]
name: session [64861,64868]
===
match
---
name: half_an_hour_ago [55950,55966]
name: half_an_hour_ago [57898,57914]
===
match
---
trailer [25584,25591]
trailer [25584,25591]
===
match
---
operator: , [17939,17940]
operator: , [17939,17940]
===
match
---
operator: , [21646,21647]
operator: , [21646,21647]
===
match
---
trailer [9882,9887]
trailer [9882,9887]
===
match
---
atom [8932,8942]
atom [8932,8942]
===
match
---
number: 4 [57495,57496]
number: 4 [59443,59444]
===
match
---
name: models [4950,4956]
name: models [4950,4956]
===
match
---
operator: = [47308,47309]
operator: = [47308,47309]
===
match
---
name: DagTag [1480,1486]
name: DagTag [1480,1486]
===
match
---
name: start_date [40464,40474]
name: start_date [40464,40474]
===
match
---
funcdef [21252,22345]
funcdef [21252,22345]
===
match
---
name: pickle [44058,44064]
name: pickle [44058,44064]
===
match
---
simple_stmt [6235,6264]
simple_stmt [6235,6264]
===
match
---
name: op2 [38204,38207]
name: op2 [38204,38207]
===
match
---
simple_stmt [55244,55262]
simple_stmt [57192,57210]
===
match
---
import_name [1092,1105]
import_name [1092,1105]
===
match
---
name: dag [14781,14784]
name: dag [14781,14784]
===
match
---
name: DAG [52037,52040]
name: DAG [53985,53988]
===
match
---
operator: , [52858,52859]
operator: , [54806,54807]
===
match
---
param [11033,11037]
param [11033,11037]
===
match
---
operator: == [11762,11764]
operator: == [11762,11764]
===
match
---
trailer [37968,37982]
trailer [37968,37982]
===
match
---
name: drs [47304,47307]
name: drs [47304,47307]
===
match
---
arglist [52856,52859]
arglist [54804,54807]
===
match
---
operator: + [43401,43402]
operator: + [43401,43402]
===
match
---
atom_expr [32252,32270]
atom_expr [32252,32270]
===
match
---
atom_expr [26458,26485]
atom_expr [26458,26485]
===
match
---
operator: = [55515,55516]
operator: = [57463,57464]
===
match
---
suite [48562,49798]
suite [48562,49798]
===
match
---
name: dag [6087,6090]
name: dag [6087,6090]
===
match
---
operator: = [19245,19246]
operator: = [19245,19246]
===
match
---
atom [63879,63881]
atom [65827,65829]
===
match
---
arglist [40689,40710]
arglist [40689,40710]
===
match
---
string: "faketastic" [42384,42396]
string: "faketastic" [42384,42396]
===
match
---
name: dag [27422,27425]
name: dag [27422,27425]
===
match
---
operator: , [18344,18345]
operator: , [18344,18345]
===
match
---
funcdef [2770,3136]
funcdef [2770,3136]
===
match
---
simple_stmt [1092,1106]
simple_stmt [1092,1106]
===
match
---
name: next_dagrun_after_date [53478,53500]
name: next_dagrun_after_date [55426,55448]
===
match
---
string: 'dag-bulk-sync-1' [24772,24789]
string: 'dag-bulk-sync-1' [24772,24789]
===
match
---
argument [35458,35470]
argument [35458,35470]
===
match
---
operator: = [15074,15075]
operator: = [15074,15075]
===
match
---
testlist_comp [17821,17845]
testlist_comp [17821,17845]
===
match
---
string: 'test_scheduler_auto_align_1' [59148,59177]
string: 'test_scheduler_auto_align_1' [61096,61125]
===
match
---
operator: , [18199,18200]
operator: , [18199,18200]
===
match
---
operator: = [7597,7598]
operator: = [7597,7598]
===
match
---
trailer [27894,27919]
trailer [27894,27919]
===
match
---
comparison [14561,14567]
comparison [14561,14567]
===
match
---
name: re [860,862]
name: re [860,862]
===
match
---
funcdef [63017,63934]
funcdef [64965,65882]
===
match
---
operator: = [16496,16497]
operator: = [16496,16497]
===
match
---
name: info [10095,10099]
name: info [10095,10099]
===
match
---
operator: = [8897,8898]
operator: = [8897,8898]
===
match
---
name: DEFAULT_ARGS [65225,65237]
name: DEFAULT_ARGS [67173,67185]
===
match
---
name: dag [22139,22142]
name: dag [22139,22142]
===
match
---
trailer [7337,7461]
trailer [7337,7461]
===
match
---
string: "test_schedule_dag_relativedelta" [23615,23648]
string: "test_schedule_dag_relativedelta" [23615,23648]
===
match
---
argument [33056,33071]
argument [33056,33071]
===
match
---
name: next_dagrun_after_date [56241,56263]
name: next_dagrun_after_date [58189,58211]
===
match
---
import_from [989,1016]
import_from [989,1016]
===
match
---
name: State [49876,49881]
name: State [49876,49881]
===
match
---
funcdef [53157,53545]
funcdef [55105,55493]
===
match
---
dictorsetmaker [4213,4228]
dictorsetmaker [4213,4228]
===
match
---
operator: = [62654,62655]
operator: = [64602,64603]
===
match
---
decorated [66179,66255]
decorated [68127,68203]
===
match
---
name: test_existing_dag_default_view [33328,33358]
name: test_existing_dag_default_view [33328,33358]
===
match
---
name: template_dir [19015,19027]
name: template_dir [19015,19027]
===
match
---
string: '2019-06-01' [10823,10835]
string: '2019-06-01' [10823,10835]
===
match
---
atom_expr [45939,45980]
atom_expr [45939,45980]
===
match
---
trailer [39056,39071]
trailer [39056,39071]
===
match
---
name: run_type [50500,50508]
name: run_type [50500,50508]
===
match
---
name: dag_id [56050,56056]
name: dag_id [57998,58004]
===
match
---
simple_stmt [38803,38857]
simple_stmt [38803,38857]
===
match
---
operator: = [47620,47621]
operator: = [47620,47621]
===
match
---
simple_stmt [20955,20991]
simple_stmt [20955,20991]
===
match
---
arglist [60800,60908]
arglist [62748,62856]
===
match
---
trailer [19047,19052]
trailer [19047,19052]
===
match
---
name: start_date [30913,30923]
name: start_date [30913,30923]
===
match
---
name: prev_task [16074,16083]
name: prev_task [16074,16083]
===
match
---
operator: , [49859,49860]
operator: , [49859,49860]
===
match
---
simple_stmt [36297,36331]
simple_stmt [36297,36331]
===
match
---
name: session [28101,28108]
name: session [28101,28108]
===
match
---
with_stmt [4617,4796]
with_stmt [4617,4796]
===
match
---
simple_stmt [28401,28447]
simple_stmt [28401,28447]
===
match
---
expr_stmt [6526,6560]
expr_stmt [6526,6560]
===
match
---
trailer [38189,38199]
trailer [38189,38199]
===
match
---
name: next_date [59431,59440]
name: next_date [61379,61388]
===
match
---
operator: = [9846,9847]
operator: = [9846,9847]
===
match
---
assert_stmt [17768,17864]
assert_stmt [17768,17864]
===
match
---
operator: , [15740,15741]
operator: , [15740,15741]
===
match
---
simple_stmt [3563,3706]
simple_stmt [3563,3706]
===
match
---
arglist [15376,15440]
arglist [15376,15440]
===
match
---
decorated [49803,51679]
decorated [49803,51679]
===
match
---
name: TestDagDecorator [64632,64648]
name: TestDagDecorator [66580,66596]
===
match
---
name: get_is_paused [32639,32652]
name: get_is_paused [32639,32652]
===
match
---
trailer [45942,45980]
trailer [45942,45980]
===
match
---
trailer [47356,47361]
trailer [47356,47361]
===
match
---
operator: = [14142,14143]
operator: = [14142,14143]
===
match
---
suite [65025,65077]
suite [66973,67025]
===
match
---
atom_expr [36702,36717]
atom_expr [36702,36717]
===
match
---
param [65513,65517]
param [67461,67465]
===
match
---
string: 'test-dag2' [26948,26959]
string: 'test-dag2' [26948,26959]
===
match
---
argument [40464,40479]
argument [40464,40479]
===
match
---
operator: == [59814,59816]
operator: == [61762,61764]
===
match
---
name: State [40519,40524]
name: State [40519,40524]
===
match
---
suite [54509,56860]
suite [56457,58808]
===
match
---
operator: = [8784,8785]
operator: = [8784,8785]
===
match
---
name: dates [54281,54286]
name: dates [56229,56234]
===
match
---
expr_stmt [43170,43201]
expr_stmt [43170,43201]
===
match
---
simple_stmt [18748,18839]
simple_stmt [18748,18839]
===
match
---
operator: = [60214,60215]
operator: = [62162,62163]
===
match
---
name: dag_id [60237,60243]
name: dag_id [62185,62191]
===
match
---
simple_stmt [34063,34092]
simple_stmt [34063,34092]
===
match
---
name: op1 [37552,37555]
name: op1 [37552,37555]
===
match
---
name: _next [20689,20694]
name: _next [20689,20694]
===
match
---
operator: , [31629,31630]
operator: , [31629,31630]
===
match
---
name: run [68622,68625]
name: run [70570,70573]
===
match
---
trailer [24647,24650]
trailer [24647,24650]
===
match
---
name: DagRunType [41382,41392]
name: DagRunType [41382,41392]
===
match
---
assert_stmt [38179,38239]
assert_stmt [38179,38239]
===
match
---
simple_stmt [54728,54837]
simple_stmt [56676,56785]
===
match
---
argument [50707,50739]
argument [50707,50739]
===
match
---
operator: , [57298,57299]
operator: , [59246,59247]
===
match
---
operator: , [62764,62765]
operator: , [64712,64713]
===
match
---
name: default_args [44579,44591]
name: default_args [44579,44591]
===
match
---
name: State [18374,18379]
name: State [18374,18379]
===
match
---
name: test_field [19459,19469]
name: test_field [19459,19469]
===
match
---
simple_stmt [35575,35611]
simple_stmt [35575,35611]
===
match
---
trailer [39083,39092]
trailer [39083,39092]
===
match
---
operator: = [61983,61984]
operator: = [63931,63932]
===
match
---
name: dags_needing_dagruns [63654,63674]
name: dags_needing_dagruns [65602,65622]
===
match
---
atom_expr [25576,25604]
atom_expr [25576,25604]
===
match
---
atom [25743,25819]
atom [25743,25819]
===
match
---
name: dag2 [6346,6350]
name: dag2 [6346,6350]
===
match
---
name: timezone [59817,59825]
name: timezone [61765,61773]
===
match
---
trailer [68460,68467]
trailer [70408,70415]
===
match
---
name: next_date [53410,53419]
name: next_date [55358,55367]
===
match
---
name: self [2448,2452]
name: self [2448,2452]
===
match
---
assert_stmt [23318,23378]
assert_stmt [23318,23378]
===
match
---
name: Optional [1008,1016]
name: Optional [1008,1016]
===
match
---
name: session [31355,31362]
name: session [31355,31362]
===
match
---
name: utils [1871,1876]
name: utils [1871,1876]
===
match
---
atom_expr [53474,53511]
atom_expr [55422,55459]
===
match
---
name: DEFAULT_ARGS [67977,67989]
name: DEFAULT_ARGS [69925,69937]
===
match
---
trailer [25396,25399]
trailer [25396,25399]
===
match
---
simple_stmt [15462,15822]
simple_stmt [15462,15822]
===
match
---
funcdef [4486,4796]
funcdef [4486,4796]
===
match
---
dotted_name [1948,1969]
dotted_name [1948,1969]
===
match
---
suite [54216,54300]
suite [56164,56248]
===
match
---
operator: = [23284,23285]
operator: = [23284,23285]
===
match
---
name: datetime [57278,57286]
name: datetime [59226,59234]
===
match
---
name: dagrun_1 [52209,52217]
name: dagrun_1 [54157,54165]
===
match
---
name: orm_dag [33683,33690]
name: orm_dag [33683,33690]
===
match
---
string: 'DAG' [12356,12361]
string: 'DAG' [12356,12361]
===
match
---
simple_stmt [20843,20904]
simple_stmt [20843,20904]
===
match
---
name: dag_id [50104,50110]
name: dag_id [50104,50110]
===
match
---
argument [55412,55420]
argument [57360,57368]
===
match
---
trailer [32128,32141]
trailer [32128,32141]
===
match
---
number: 1 [59844,59845]
number: 1 [61792,61793]
===
match
---
name: dag [45065,45068]
name: dag [45065,45068]
===
match
---
argument [63355,63372]
argument [65303,65320]
===
match
---
name: DEFAULT_DATE [27491,27503]
name: DEFAULT_DATE [27491,27503]
===
match
---
name: timedelta [51298,51307]
name: timedelta [51298,51307]
===
match
---
simple_stmt [4238,4266]
simple_stmt [4238,4266]
===
match
---
name: run_type [47917,47925]
name: run_type [47917,47925]
===
match
---
name: state [67604,67609]
name: state [69552,69557]
===
match
---
operator: == [44985,44987]
operator: == [44985,44987]
===
match
---
string: 'C' [8853,8856]
string: 'C' [8853,8856]
===
match
---
operator: , [26014,26015]
operator: , [26014,26015]
===
match
---
simple_stmt [44606,44681]
simple_stmt [44606,44681]
===
match
---
operator: == [6945,6947]
operator: == [6945,6947]
===
match
---
atom_expr [10208,10227]
atom_expr [10208,10227]
===
match
---
atom [19381,19395]
atom [19381,19395]
===
match
---
name: local_tz [21406,21414]
name: local_tz [21406,21414]
===
match
---
name: DEFAULT_DATE [15394,15406]
name: DEFAULT_DATE [15394,15406]
===
match
---
comparison [29558,29616]
comparison [29558,29616]
===
match
---
simple_stmt [53129,53152]
simple_stmt [55077,55100]
===
match
---
parameters [8515,8521]
parameters [8515,8521]
===
match
---
argument [37627,37639]
argument [37627,37639]
===
match
---
name: all [25199,25202]
name: all [25199,25202]
===
match
---
number: 0 [14469,14470]
number: 0 [14469,14470]
===
match
---
number: 1 [59600,59601]
number: 1 [61548,61549]
===
match
---
factor [23685,23687]
factor [23685,23687]
===
match
---
trailer [21981,21988]
trailer [21981,21988]
===
match
---
expr_stmt [37552,37594]
expr_stmt [37552,37594]
===
match
---
name: dag_id [31265,31271]
name: dag_id [31265,31271]
===
match
---
name: run_id [48256,48262]
name: run_id [48256,48262]
===
match
---
name: unittest [64649,64657]
name: unittest [66597,66605]
===
match
---
name: success [40698,40705]
name: success [40698,40705]
===
match
---
comparison [9374,9400]
comparison [9374,9400]
===
match
---
operator: = [64394,64395]
operator: = [66342,66343]
===
match
---
argument [5369,5390]
argument [5369,5390]
===
match
---
name: calculated_weight [13747,13764]
name: calculated_weight [13747,13764]
===
match
---
name: dag [12346,12349]
name: dag [12346,12349]
===
match
---
name: i [64311,64312]
name: i [66259,66260]
===
match
---
trailer [47316,47321]
trailer [47316,47321]
===
match
---
name: start_date [63187,63197]
name: start_date [65135,65145]
===
match
---
atom [10698,10700]
atom [10698,10700]
===
match
---
trailer [16576,16594]
trailer [16576,16594]
===
match
---
atom_expr [39761,39783]
atom_expr [39761,39783]
===
match
---
name: merge [50909,50914]
name: merge [50909,50914]
===
match
---
import_from [1043,1074]
import_from [1043,1074]
===
match
---
comparison [43627,43659]
comparison [43627,43659]
===
match
---
name: lower [5054,5059]
name: lower [5054,5059]
===
match
---
trailer [9390,9393]
trailer [9390,9393]
===
match
---
expr_stmt [55295,55318]
expr_stmt [57243,57266]
===
match
---
operator: , [17187,17188]
operator: , [17187,17188]
===
match
---
assert_stmt [20779,20834]
assert_stmt [20779,20834]
===
match
---
operator: , [64903,64904]
operator: , [66851,66852]
===
match
---
name: synchronize_session [3109,3128]
name: synchronize_session [3109,3128]
===
match
---
trailer [19676,19681]
trailer [19676,19681]
===
match
---
name: convert [22575,22582]
name: convert [22575,22582]
===
match
---
atom_expr [63498,63534]
atom_expr [65446,65482]
===
match
---
argument [15383,15406]
argument [15383,15406]
===
match
---
name: state [53099,53104]
name: state [55047,55052]
===
match
---
argument [15649,15680]
argument [15649,15680]
===
match
---
name: dag [7209,7212]
name: dag [7209,7212]
===
match
---
argument [57258,57298]
argument [59206,59246]
===
match
---
dictorsetmaker [10926,10978]
dictorsetmaker [10926,10978]
===
match
---
atom_expr [35015,35028]
atom_expr [35015,35028]
===
match
---
argument [6014,6037]
argument [6014,6037]
===
match
---
trailer [48367,48383]
trailer [48367,48383]
===
match
---
simple_stmt [65117,65175]
simple_stmt [67065,67123]
===
match
---
argument [30913,30936]
argument [30913,30936]
===
match
---
name: datetime [21485,21493]
name: datetime [21485,21493]
===
match
---
operator: = [40377,40378]
operator: = [40377,40378]
===
match
---
trailer [50999,51007]
trailer [50999,51007]
===
match
---
argument [27480,27503]
argument [27480,27503]
===
match
---
operator: = [38500,38501]
operator: = [38500,38501]
===
match
---
atom_expr [29472,29542]
atom_expr [29472,29542]
===
match
---
testlist_comp [24521,24611]
testlist_comp [24521,24611]
===
match
---
operator: = [49400,49401]
operator: = [49400,49401]
===
match
---
argument [56099,56126]
argument [58047,58074]
===
match
---
operator: < [3492,3493]
operator: < [3492,3493]
===
match
---
parameters [34778,34784]
parameters [34778,34784]
===
match
---
atom_expr [60941,60957]
atom_expr [62889,62905]
===
match
---
simple_stmt [29051,29083]
simple_stmt [29051,29083]
===
match
---
number: 1 [46641,46642]
number: 1 [46641,46642]
===
match
---
string: 'airflow' [62480,62489]
string: 'airflow' [64428,64437]
===
match
---
simple_stmt [22827,22863]
simple_stmt [22827,22863]
===
match
---
trailer [31900,31973]
trailer [31900,31973]
===
match
---
operator: = [50368,50369]
operator: = [50368,50369]
===
match
---
suite [2433,62264]
suite [2433,64212]
===
match
---
trailer [32141,32153]
trailer [32141,32153]
===
match
---
trailer [50882,50892]
trailer [50882,50892]
===
match
---
suite [29835,30545]
suite [29835,30545]
===
match
---
name: dag_id [44065,44071]
name: dag_id [44065,44071]
===
match
---
name: flush [62853,62858]
name: flush [64801,64806]
===
match
---
operator: = [13939,13940]
operator: = [13939,13940]
===
match
---
simple_stmt [41052,41088]
simple_stmt [41052,41088]
===
match
---
number: 2 [2389,2390]
number: 2 [2389,2390]
===
match
---
name: isoformat [20792,20801]
name: isoformat [20792,20801]
===
match
---
operator: > [45610,45611]
operator: > [45610,45611]
===
match
---
trailer [25416,25433]
trailer [25416,25433]
===
match
---
name: is_paused [31451,31460]
name: is_paused [31451,31460]
===
match
---
arglist [28956,29004]
arglist [28956,29004]
===
match
---
trailer [31354,31371]
trailer [31354,31371]
===
match
---
suite [2462,2629]
suite [2462,2629]
===
match
---
comparison [6310,6331]
comparison [6310,6331]
===
match
---
trailer [23780,23843]
trailer [23780,23843]
===
match
---
assert_stmt [42841,42873]
assert_stmt [42841,42873]
===
match
---
trailer [63962,63971]
trailer [65910,65919]
===
match
---
funcdef [10732,10838]
funcdef [10732,10838]
===
match
---
trailer [61976,62047]
trailer [63924,63995]
===
match
---
trailer [34673,34680]
trailer [34673,34680]
===
match
---
atom_expr [45289,45307]
atom_expr [45289,45307]
===
match
---
expr_stmt [56224,56269]
expr_stmt [58172,58217]
===
match
---
operator: = [17078,17079]
operator: = [17078,17079]
===
match
---
trailer [23112,23122]
trailer [23112,23122]
===
match
---
arglist [12838,12902]
arglist [12838,12902]
===
match
---
trailer [34115,34122]
trailer [34115,34122]
===
match
---
name: dag [23977,23980]
name: dag [23977,23980]
===
match
---
operator: = [37644,37645]
operator: = [37644,37645]
===
match
---
name: filter [30387,30393]
name: filter [30387,30393]
===
match
---
comp_op [25308,25314]
comp_op [25308,25314]
===
match
---
trailer [20386,20395]
trailer [20386,20395]
===
match
---
expr_stmt [42179,42212]
expr_stmt [42179,42212]
===
match
---
operator: = [59712,59713]
operator: = [61660,61661]
===
match
---
operator: } [60279,60280]
operator: } [62227,62228]
===
match
---
trailer [26770,26774]
trailer [26770,26774]
===
match
---
trailer [5554,5589]
trailer [5554,5589]
===
match
---
arglist [12356,12396]
arglist [12356,12396]
===
match
---
trailer [47543,47557]
trailer [47543,47557]
===
match
---
name: State [17142,17147]
name: State [17142,17147]
===
match
---
argument [3109,3134]
argument [3109,3134]
===
match
---
name: DAG [12834,12837]
name: DAG [12834,12837]
===
match
---
dictorsetmaker [31614,31662]
dictorsetmaker [31614,31662]
===
match
---
comparison [17591,17666]
comparison [17591,17666]
===
match
---
atom [15491,15766]
atom [15491,15766]
===
match
---
arglist [63167,63210]
arglist [65115,65158]
===
match
---
simple_stmt [42179,42213]
simple_stmt [42179,42213]
===
match
---
for_stmt [14614,14756]
for_stmt [14614,14756]
===
match
---
assert_stmt [29414,29449]
assert_stmt [29414,29449]
===
match
---
name: DAG [60216,60219]
name: DAG [62164,62167]
===
match
---
trailer [47858,47898]
trailer [47858,47898]
===
match
---
number: 2016 [59462,59466]
number: 2016 [61410,61414]
===
match
---
with_item [19547,19590]
with_item [19547,19590]
===
match
---
simple_stmt [13932,13943]
simple_stmt [13932,13943]
===
match
---
trailer [9304,9307]
trailer [9304,9307]
===
match
---
atom_expr [46089,46126]
atom_expr [46089,46126]
===
match
---
name: prev_task [15994,16003]
name: prev_task [15994,16003]
===
match
---
trailer [30393,30419]
trailer [30393,30419]
===
match
---
name: dag_id [49986,49992]
name: dag_id [49986,49992]
===
match
---
fstring_end: ' [60477,60478]
fstring_end: ' [62425,62426]
===
match
---
string: "2018-10-28T02:00:00+01:00" [20876,20903]
string: "2018-10-28T02:00:00+01:00" [20876,20903]
===
match
---
name: session [27723,27730]
name: session [27723,27730]
===
match
---
trailer [10615,10681]
trailer [10615,10681]
===
match
---
name: get_is_paused [32856,32869]
name: get_is_paused [32856,32869]
===
match
---
classdef [2400,62264]
classdef [2400,64212]
===
match
---
suite [65267,65383]
suite [67215,67331]
===
match
---
name: value [68157,68162]
name: value [70105,70110]
===
match
---
trailer [9793,9806]
trailer [9793,9806]
===
match
---
operator: , [30726,30727]
operator: , [30726,30727]
===
match
---
simple_stmt [34295,34320]
simple_stmt [34295,34320]
===
match
---
atom_expr [14678,14693]
atom_expr [14678,14693]
===
match
---
name: op3 [8013,8016]
name: op3 [8013,8016]
===
match
---
argument [47615,47631]
argument [47615,47631]
===
match
---
name: filter [31475,31481]
name: filter [31475,31481]
===
match
---
name: DummyOperator [1751,1764]
name: DummyOperator [1751,1764]
===
match
---
atom_expr [27033,27080]
atom_expr [27033,27080]
===
match
---
name: DagModel [46089,46097]
name: DagModel [46089,46097]
===
match
---
name: test_dag_naive_start_end_dates_strings [10847,10885]
name: test_dag_naive_start_end_dates_strings [10847,10885]
===
match
---
name: model [42781,42786]
name: model [42781,42786]
===
match
---
name: utils [1906,1911]
name: utils [1906,1911]
===
match
---
atom [54164,54166]
atom [56112,56114]
===
match
---
assert_stmt [42882,42927]
assert_stmt [42882,42927]
===
match
---
atom_expr [56494,56676]
atom_expr [58442,58624]
===
match
---
name: synchronize_session [46289,46308]
name: synchronize_session [46289,46308]
===
match
---
argument [64547,64566]
argument [66495,66514]
===
match
---
name: topological_list [10100,10116]
name: topological_list [10100,10116]
===
match
---
atom_expr [28269,28286]
atom_expr [28269,28286]
===
match
---
name: sync_to_db [32603,32613]
name: sync_to_db [32603,32613]
===
match
---
trailer [34508,34515]
trailer [34508,34515]
===
match
---
name: ti4 [17545,17548]
name: ti4 [17545,17548]
===
match
---
parameters [21310,21316]
parameters [21310,21316]
===
match
---
atom_expr [9645,9671]
atom_expr [9645,9671]
===
match
---
operator: = [41608,41609]
operator: = [41608,41609]
===
match
---
trailer [13452,13460]
trailer [13452,13460]
===
match
---
name: dag [58692,58695]
name: dag [60640,60643]
===
match
---
operator: == [47362,47364]
operator: == [47362,47364]
===
match
---
argument [28956,28973]
argument [28956,28973]
===
match
---
name: DAG [44359,44362]
name: DAG [44359,44362]
===
match
---
simple_stmt [38381,38415]
simple_stmt [38381,38415]
===
match
---
expr_stmt [35392,35425]
expr_stmt [35392,35425]
===
match
---
string: 'Also fake' [40451,40462]
string: 'Also fake' [40451,40462]
===
match
---
name: BaseOperator [41253,41265]
name: BaseOperator [41253,41265]
===
match
---
name: job_id [48387,48393]
name: job_id [48387,48393]
===
match
---
name: DAG [36981,36984]
name: DAG [36981,36984]
===
match
---
operator: = [48964,48965]
operator: = [48964,48965]
===
match
---
name: match [13426,13431]
name: match [13426,13431]
===
match
---
trailer [24684,24690]
trailer [24684,24690]
===
match
---
name: dag_subdag [60203,60213]
name: dag_subdag [62151,62161]
===
match
---
atom_expr [25873,25888]
atom_expr [25873,25888]
===
match
---
arglist [58561,58571]
arglist [60509,60519]
===
match
---
argument [52694,52744]
argument [54642,54692]
===
match
---
simple_stmt [39375,39411]
simple_stmt [39375,39411]
===
match
---
name: execution_date [49097,49111]
name: execution_date [49097,49111]
===
match
---
atom_expr [41561,41577]
atom_expr [41561,41577]
===
match
---
funcdef [33324,33763]
funcdef [33324,33763]
===
match
---
arglist [58776,58786]
arglist [60724,60734]
===
match
---
simple_stmt [12507,12517]
simple_stmt [12507,12517]
===
match
---
operator: , [28989,28990]
operator: , [28989,28990]
===
match
---
trailer [43337,43339]
trailer [43337,43339]
===
match
---
trailer [52040,52092]
trailer [53988,54040]
===
match
---
atom_expr [23171,23188]
atom_expr [23171,23188]
===
match
---
name: start [20594,20599]
name: start [20594,20599]
===
match
---
trailer [10398,10401]
trailer [10398,10401]
===
match
---
assert_stmt [63698,63724]
assert_stmt [65646,65672]
===
match
---
name: op4 [35552,35555]
name: op4 [35552,35555]
===
match
---
atom_expr [17596,17666]
atom_expr [17596,17666]
===
match
---
string: 'a_parent' [8135,8145]
string: 'a_parent' [8135,8145]
===
match
---
name: _occur_before [8350,8363]
name: _occur_before [8350,8363]
===
match
---
argument [35801,35813]
argument [35801,35813]
===
match
---
comparison [4451,4480]
comparison [4451,4480]
===
match
---
assert_stmt [23387,23441]
assert_stmt [23387,23441]
===
match
---
fstring_expr [60448,60464]
fstring_expr [62396,62412]
===
match
---
name: default_args [67104,67116]
name: default_args [69052,69064]
===
match
---
name: test_dag_id [44643,44654]
name: test_dag_id [44643,44654]
===
match
---
dictorsetmaker [26722,26776]
dictorsetmaker [26722,26776]
===
match
---
atom_expr [43223,43298]
atom_expr [43223,43298]
===
match
---
name: permissions [61838,61849]
name: permissions [63786,63797]
===
match
---
simple_stmt [53798,53824]
simple_stmt [55746,55772]
===
match
---
comparison [33683,33762]
comparison [33683,33762]
===
match
---
suite [10892,10981]
suite [10892,10981]
===
match
---
name: dag_id [52914,52920]
name: dag_id [54862,54868]
===
match
---
trailer [65050,65052]
trailer [66998,67000]
===
match
---
name: unpaused_dags [31381,31394]
name: unpaused_dags [31381,31394]
===
match
---
name: op1 [38519,38522]
name: op1 [38519,38522]
===
match
---
trailer [31725,31737]
trailer [31725,31737]
===
match
---
suite [15870,16085]
suite [15870,16085]
===
match
---
trailer [22311,22313]
trailer [22311,22313]
===
match
---
operator: = [51385,51386]
operator: = [51385,51386]
===
match
---
operator: = [43866,43867]
operator: = [43866,43867]
===
match
---
param [13843,13847]
param [13843,13847]
===
match
---
string: 'a_parent' [7850,7860]
string: 'a_parent' [7850,7860]
===
match
---
name: ACTION_CAN_READ [61769,61784]
name: ACTION_CAN_READ [63717,63732]
===
match
---
atom_expr [9006,9028]
atom_expr [9006,9028]
===
match
---
operator: } [27024,27025]
operator: } [27024,27025]
===
match
---
operator: , [48315,48316]
operator: , [48315,48316]
===
match
---
trailer [45262,45268]
trailer [45262,45268]
===
match
---
atom_expr [3420,3429]
atom_expr [3420,3429]
===
match
---
for_stmt [15834,16085]
for_stmt [15834,16085]
===
match
---
funcdef [67144,67394]
funcdef [69092,69342]
===
match
---
assert_stmt [38110,38170]
assert_stmt [38110,38170]
===
match
---
name: DEFAULT_DATE [37008,37020]
name: DEFAULT_DATE [37008,37020]
===
match
---
suite [60407,60496]
suite [62355,62444]
===
match
---
trailer [47205,47245]
trailer [47205,47245]
===
match
---
operator: = [62791,62792]
operator: = [64739,64740]
===
match
---
operator: = [4316,4317]
operator: = [4316,4317]
===
match
---
operator: == [7183,7185]
operator: == [7183,7185]
===
match
---
trailer [59210,59219]
trailer [61158,61167]
===
match
---
operator: = [21614,21615]
operator: = [21614,21615]
===
match
---
atom_expr [42301,42333]
atom_expr [42301,42333]
===
match
---
name: dag [16929,16932]
name: dag [16929,16932]
===
match
---
atom_expr [14843,14855]
atom_expr [14843,14855]
===
match
---
atom_expr [46802,46868]
atom_expr [46802,46868]
===
match
---
atom_expr [44631,44680]
atom_expr [44631,44680]
===
match
---
operator: , [57756,57757]
operator: , [59704,59705]
===
match
---
atom_expr [63611,63626]
atom_expr [65559,65574]
===
match
---
comparison [10698,10726]
comparison [10698,10726]
===
match
---
simple_stmt [62996,63012]
simple_stmt [64944,64960]
===
match
---
string: 'dag-bulk-sync-1' [26047,26064]
string: 'dag-bulk-sync-1' [26047,26064]
===
match
---
name: run_type [47558,47566]
name: run_type [47558,47566]
===
match
---
assert_stmt [65458,65483]
assert_stmt [67406,67431]
===
match
---
atom [24323,24442]
atom [24323,24442]
===
match
---
atom_expr [14829,14856]
atom_expr [14829,14856]
===
match
---
parameters [54502,54508]
parameters [56450,56456]
===
match
---
name: dag [41240,41243]
name: dag [41240,41243]
===
match
---
name: start_date [43489,43499]
name: start_date [43489,43499]
===
match
---
number: 2016 [64899,64903]
number: 2016 [66847,66851]
===
match
---
name: self [47041,47045]
name: self [47041,47045]
===
match
---
name: query [42797,42802]
name: query [42797,42802]
===
match
---
name: flush [63775,63780]
name: flush [65723,65728]
===
match
---
argument [54992,55007]
argument [56940,56955]
===
match
---
string: 'owner2' [6459,6467]
string: 'owner2' [6459,6467]
===
match
---
trailer [6170,6195]
trailer [6170,6195]
===
match
---
name: prev [21760,21764]
name: prev [21760,21764]
===
match
---
trailer [67787,67789]
trailer [69735,69737]
===
match
---
atom_expr [20361,20451]
atom_expr [20361,20451]
===
match
---
name: task_id [9749,9756]
name: task_id [9749,9756]
===
match
---
name: session [24358,24365]
name: session [24358,24365]
===
match
---
trailer [31751,31792]
trailer [31751,31792]
===
match
---
term [13610,13659]
term [13610,13659]
===
match
---
operator: = [43488,43489]
operator: = [43488,43489]
===
match
---
trailer [48895,48908]
trailer [48895,48908]
===
match
---
atom_expr [57731,57760]
atom_expr [59679,59708]
===
match
---
operator: , [57708,57709]
operator: , [59656,59657]
===
match
---
operator: >> [35548,35550]
operator: >> [35548,35550]
===
match
---
expr_stmt [52794,52974]
expr_stmt [54742,54922]
===
match
---
operator: , [1478,1479]
operator: , [1478,1479]
===
match
---
name: session [63918,63925]
name: session [65866,65873]
===
match
---
name: DagModel [32309,32317]
name: DagModel [32309,32317]
===
match
---
name: db [2316,2318]
name: db [2316,2318]
===
match
---
operator: = [21741,21742]
operator: = [21741,21742]
===
match
---
name: weight [15032,15038]
name: weight [15032,15038]
===
match
---
arglist [30994,31025]
arglist [30994,31025]
===
match
---
atom [16524,16543]
atom [16524,16543]
===
match
---
operator: , [41443,41444]
operator: , [41443,41444]
===
match
---
number: 2 [20410,20411]
number: 2 [20410,20411]
===
match
---
name: get_template_env [18676,18692]
name: get_template_env [18676,18692]
===
match
---
trailer [12092,12141]
trailer [12092,12141]
===
match
---
atom_expr [27948,28127]
atom_expr [27948,28127]
===
match
---
simple_stmt [19447,19484]
simple_stmt [19447,19484]
===
match
---
with_stmt [7471,7577]
with_stmt [7471,7577]
===
match
---
atom_expr [49876,49889]
atom_expr [49876,49889]
===
match
---
atom_expr [50759,50771]
atom_expr [50759,50771]
===
match
---
testlist_comp [31939,31956]
testlist_comp [31939,31956]
===
match
---
name: DEFAULT_DATE [14065,14077]
name: DEFAULT_DATE [14065,14077]
===
match
---
dictorsetmaker [24956,25135]
dictorsetmaker [24956,25135]
===
match
---
name: template_file [19710,19723]
name: template_file [19710,19723]
===
match
---
number: 5 [13959,13960]
number: 5 [13959,13960]
===
match
---
name: owner [42398,42403]
name: owner [42398,42403]
===
match
---
string: """         Make sure DST transitions are properly observed         """ [22424,22495]
string: """         Make sure DST transitions are properly observed         """ [22424,22495]
===
match
---
funcdef [46694,47008]
funcdef [46694,47008]
===
match
---
arglist [7616,7706]
arglist [7616,7706]
===
match
---
name: default_args [12870,12882]
name: default_args [12870,12882]
===
match
---
string: 'dag_default_view' [5034,5052]
string: 'dag_default_view' [5034,5052]
===
match
---
atom_expr [43962,43997]
atom_expr [43962,43997]
===
match
---
string: "run_type_is_obtained_from_run_id" [47792,47826]
string: "run_type_is_obtained_from_run_id" [47792,47826]
===
match
---
name: datetime [60612,60620]
name: datetime [62560,62568]
===
match
---
name: i [14239,14240]
name: i [14239,14240]
===
match
---
expr_stmt [21952,21988]
expr_stmt [21952,21988]
===
match
---
simple_stmt [45589,45616]
simple_stmt [45589,45616]
===
match
---
argument [62674,62700]
argument [64622,64648]
===
match
---
simple_stmt [48571,48610]
simple_stmt [48571,48610]
===
match
---
name: concurrency [62600,62611]
name: concurrency [64548,64559]
===
match
---
name: default_args [9494,9506]
name: default_args [9494,9506]
===
match
---
expr_stmt [52447,52523]
expr_stmt [54395,54471]
===
match
---
operator: , [55751,55752]
operator: , [57699,57700]
===
match
---
simple_stmt [22872,22933]
simple_stmt [22872,22933]
===
match
---
name: dag_id [33132,33138]
name: dag_id [33132,33138]
===
match
---
simple_stmt [37320,37375]
simple_stmt [37320,37375]
===
match
---
not_test [39704,39732]
not_test [39704,39732]
===
match
---
assert_stmt [8413,8479]
assert_stmt [8413,8479]
===
match
---
param [66658,66663]
param [68606,68611]
===
match
---
name: test_next_dagrun_after_date_catcup [54468,54502]
name: test_next_dagrun_after_date_catcup [56416,56450]
===
match
---
atom_expr [15372,15441]
atom_expr [15372,15441]
===
match
---
name: dag [38117,38120]
name: dag [38117,38120]
===
match
---
operator: , [64138,64139]
operator: , [66086,66087]
===
match
---
operator: = [7973,7974]
operator: = [7973,7974]
===
match
---
operator: = [55386,55387]
operator: = [57334,57335]
===
match
---
atom_expr [19769,19843]
atom_expr [19769,19843]
===
match
---
simple_stmt [38542,38553]
simple_stmt [38542,38553]
===
match
---
atom_expr [37499,37539]
atom_expr [37499,37539]
===
match
---
operator: , [58331,58332]
operator: , [60279,60280]
===
match
---
operator: = [54069,54070]
operator: = [56017,56018]
===
match
---
dictorsetmaker [61513,61692]
dictorsetmaker [63461,63640]
===
match
---
operator: , [51819,51820]
operator: , [53767,53768]
===
match
---
name: task_dict [38190,38199]
name: task_dict [38190,38199]
===
match
---
operator: , [56900,56901]
operator: , [58848,58849]
===
match
---
argument [42376,42396]
argument [42376,42396]
===
match
---
name: DAG [19125,19128]
name: DAG [19125,19128]
===
match
---
trailer [22899,22901]
trailer [22899,22901]
===
match
---
operator: , [10646,10647]
operator: , [10646,10647]
===
match
---
assert_stmt [3752,3787]
assert_stmt [3752,3787]
===
match
---
trailer [65872,65879]
trailer [67820,67827]
===
match
---
trailer [55390,55398]
trailer [57338,57346]
===
match
---
simple_stmt [36343,36377]
simple_stmt [36343,36377]
===
match
---
operator: = [47503,47504]
operator: = [47503,47504]
===
match
---
trailer [31209,31215]
trailer [31209,31215]
===
match
---
string: "t1" [36279,36283]
string: "t1" [36279,36283]
===
match
---
atom_expr [27649,27660]
atom_expr [27649,27660]
===
match
---
atom_expr [16893,16942]
atom_expr [16893,16942]
===
match
---
argument [59191,59242]
argument [61139,61190]
===
match
---
simple_stmt [62215,62264]
simple_stmt [64163,64212]
===
match
---
fstring [14231,14246]
fstring [14231,14246]
===
match
---
number: 1 [34905,34906]
number: 1 [34905,34906]
===
match
---
operator: , [41649,41650]
operator: , [41649,41650]
===
match
---
string: "0 0 1 1 *" [46561,46572]
string: "0 0 1 1 *" [46561,46572]
===
match
---
operator: = [37999,38000]
operator: = [37999,38000]
===
match
---
param [36788,36792]
param [36788,36792]
===
match
---
name: dag [39080,39083]
name: dag [39080,39083]
===
match
---
operator: @ [57718,57719]
operator: @ [59666,59667]
===
match
---
name: dag2 [7154,7158]
name: dag2 [7154,7158]
===
match
---
name: is_paused_upon_creation [32966,32989]
name: is_paused_upon_creation [32966,32989]
===
match
---
operator: = [19151,19152]
operator: = [19151,19152]
===
match
---
operator: = [15616,15617]
operator: = [15616,15617]
===
match
---
argument [35504,35516]
argument [35504,35516]
===
match
---
operator: = [38606,38607]
operator: = [38606,38607]
===
match
---
operator: = [34964,34965]
operator: = [34964,34965]
===
match
---
name: dag_models [63792,63802]
name: dag_models [65740,65750]
===
match
---
atom_expr [32235,32250]
atom_expr [32235,32250]
===
match
---
name: i [12984,12985]
name: i [12984,12985]
===
match
---
operator: , [7450,7451]
operator: , [7450,7451]
===
match
---
string: "retry_delay" [64819,64832]
string: "retry_delay" [66767,66780]
===
match
---
trailer [51307,51315]
trailer [51307,51315]
===
match
---
argument [42593,42612]
argument [42593,42612]
===
match
---
arglist [19773,19842]
arglist [19773,19842]
===
match
---
simple_stmt [11949,12026]
simple_stmt [11949,12026]
===
match
---
trailer [41359,41522]
trailer [41359,41522]
===
match
---
with_item [41561,41588]
with_item [41561,41588]
===
match
---
atom_expr [11994,12023]
atom_expr [11994,12023]
===
match
---
operator: = [42787,42788]
operator: = [42787,42788]
===
match
---
name: expand [51699,51705]
name: expand [53647,53653]
===
match
---
name: is_active [29643,29652]
name: is_active [29643,29652]
===
match
---
name: start_date [6014,6024]
name: start_date [6014,6024]
===
match
---
name: DAG [62355,62358]
name: DAG [64303,64306]
===
match
---
trailer [29585,29591]
trailer [29585,29591]
===
match
---
atom_expr [16048,16084]
atom_expr [16048,16084]
===
match
---
operator: = [7404,7405]
operator: = [7404,7405]
===
match
---
name: datetime [59826,59834]
name: datetime [61774,61782]
===
match
---
atom_expr [32573,32590]
atom_expr [32573,32590]
===
match
---
operator: = [23663,23664]
operator: = [23663,23664]
===
match
---
name: ti [68692,68694]
name: ti [70640,70642]
===
match
---
atom_expr [42789,42831]
atom_expr [42789,42831]
===
match
---
name: half_an_hour_ago [55464,55480]
name: half_an_hour_ago [57412,57428]
===
match
---
trailer [41534,41545]
trailer [41534,41545]
===
match
---
name: session [63835,63842]
name: session [65783,65790]
===
match
---
name: dag [53936,53939]
name: dag [55884,55887]
===
match
---
name: test_leaves [35620,35631]
name: test_leaves [35620,35631]
===
match
---
atom_expr [48365,48383]
atom_expr [48365,48383]
===
match
---
name: op3 [8825,8828]
name: op3 [8825,8828]
===
match
---
simple_stmt [1858,1893]
simple_stmt [1858,1893]
===
match
---
argument [23722,23745]
argument [23722,23745]
===
match
---
funcdef [47013,47424]
funcdef [47013,47424]
===
match
---
argument [50959,50986]
argument [50959,50986]
===
match
---
trailer [36576,36582]
trailer [36576,36582]
===
match
---
number: 4 [25397,25398]
number: 4 [25397,25398]
===
match
---
name: SCHEDULED [42556,42565]
name: SCHEDULED [42556,42565]
===
match
---
number: 5 [56905,56906]
number: 5 [58853,58854]
===
match
---
name: dag [23755,23758]
name: dag [23755,23758]
===
match
---
name: op1 [37227,37230]
name: op1 [37227,37230]
===
match
---
argument [50137,50154]
argument [50137,50154]
===
match
---
operator: , [50771,50772]
operator: , [50771,50772]
===
match
---
operator: , [58140,58141]
operator: , [60088,60089]
===
match
---
fstring_start: f' [39565,39567]
fstring_start: f' [39565,39567]
===
match
---
operator: @ [66585,66586]
operator: @ [68533,68534]
===
match
---
atom_expr [44796,44811]
atom_expr [44796,44811]
===
match
---
trailer [3074,3101]
trailer [3074,3101]
===
match
---
number: 1 [53014,53015]
number: 1 [54962,54963]
===
match
---
argument [17743,17758]
argument [17743,17758]
===
match
---
name: task_id [6124,6131]
name: task_id [6124,6131]
===
match
---
operator: , [30124,30125]
operator: , [30124,30125]
===
match
---
comparison [62063,62104]
comparison [64011,64052]
===
match
---
name: TIMEZONE [12438,12446]
name: TIMEZONE [12438,12446]
===
match
---
atom_expr [63645,63689]
atom_expr [65593,65637]
===
match
---
with_item [36425,36465]
with_item [36425,36465]
===
match
---
atom_expr [31442,31460]
atom_expr [31442,31460]
===
match
---
name: len [47353,47356]
name: len [47353,47356]
===
match
---
trailer [58718,58729]
trailer [60666,60677]
===
match
---
atom_expr [64834,64854]
atom_expr [66782,66802]
===
match
---
arglist [45943,45979]
arglist [45943,45979]
===
match
---
trailer [67542,67544]
trailer [69490,69492]
===
match
---
atom_expr [47310,47336]
atom_expr [47310,47336]
===
match
---
trailer [12044,12053]
trailer [12044,12053]
===
match
---
name: timezone [59573,59581]
name: timezone [61521,61529]
===
match
---
name: create_dagrun [47845,47858]
name: create_dagrun [47845,47858]
===
match
---
trailer [13406,13408]
trailer [13406,13408]
===
match
---
name: self [2519,2523]
name: self [2519,2523]
===
match
---
atom [51486,51633]
atom [51486,51633]
===
match
---
parameters [22408,22414]
parameters [22408,22414]
===
match
---
expr_stmt [9774,9806]
expr_stmt [9774,9806]
===
match
---
simple_stmt [41809,41850]
simple_stmt [41809,41850]
===
match
---
operator: @ [65184,65185]
operator: @ [67132,67133]
===
match
---
arglist [17714,17758]
arglist [17714,17758]
===
match
---
arglist [51038,51091]
arglist [51038,51091]
===
match
---
name: subdag [28991,28997]
name: subdag [28991,28997]
===
match
---
operator: = [47600,47601]
operator: = [47600,47601]
===
match
---
atom_expr [67644,67719]
atom_expr [69592,69667]
===
match
---
trailer [29495,29502]
trailer [29495,29502]
===
match
---
name: side_effect [40108,40119]
name: side_effect [40108,40119]
===
match
---
arith_expr [44643,44660]
arith_expr [44643,44660]
===
match
---
name: self [49956,49960]
name: self [49956,49960]
===
match
---
comp_op [54352,54358]
comp_op [56300,56306]
===
match
---
simple_stmt [45000,45028]
simple_stmt [45000,45028]
===
match
---
operator: , [46643,46644]
operator: , [46643,46644]
===
match
---
name: op3 [36403,36406]
name: op3 [36403,36406]
===
match
---
operator: = [3282,3283]
operator: = [3282,3283]
===
match
---
atom [32207,32393]
atom [32207,32393]
===
match
---
operator: >> [37173,37175]
operator: >> [37173,37175]
===
match
---
name: last_loaded [44782,44793]
name: last_loaded [44782,44793]
===
match
---
operator: == [33710,33712]
operator: == [33710,33712]
===
match
---
name: state [17134,17139]
name: state [17134,17139]
===
match
---
trailer [30315,30326]
trailer [30315,30326]
===
match
---
name: value [66658,66663]
name: value [68606,68611]
===
match
---
name: dag [11850,11853]
name: dag [11850,11853]
===
match
---
name: is_active [34560,34569]
name: is_active [34560,34569]
===
match
---
trailer [62447,62490]
trailer [64395,64438]
===
match
---
name: dag [58360,58363]
name: dag [60308,60311]
===
match
---
name: flush [63619,63624]
name: flush [65567,65572]
===
match
---
name: dags [26440,26444]
name: dags [26440,26444]
===
match
---
expr_stmt [61067,61090]
expr_stmt [63015,63038]
===
match
---
simple_stmt [62537,62808]
simple_stmt [64485,64756]
===
match
---
name: State [51779,51784]
name: State [53727,53732]
===
match
---
name: task_id [12968,12975]
name: task_id [12968,12975]
===
match
---
operator: = [47566,47567]
operator: = [47566,47567]
===
match
---
comparison [10511,10537]
comparison [10511,10537]
===
match
---
operator: = [63173,63174]
operator: = [65121,65122]
===
match
---
suite [14568,14598]
suite [14568,14598]
===
match
---
atom_expr [58543,58572]
atom_expr [60491,60520]
===
match
---
simple_stmt [45933,45981]
simple_stmt [45933,45981]
===
match
---
name: default_args [10795,10807]
name: default_args [10795,10807]
===
match
---
argument [52330,52353]
argument [54278,54301]
===
match
---
name: dag [47540,47543]
name: dag [47540,47543]
===
match
---
name: task_id [16626,16633]
name: task_id [16626,16633]
===
match
---
simple_stmt [5451,5530]
simple_stmt [5451,5530]
===
match
---
atom_expr [44777,44793]
atom_expr [44777,44793]
===
match
---
name: airflow [2052,2059]
name: airflow [2052,2059]
===
match
---
argument [21648,21677]
argument [21648,21677]
===
match
---
operator: = [12933,12934]
operator: = [12933,12934]
===
match
---
name: DEFAULT_DATE [2223,2235]
name: DEFAULT_DATE [2223,2235]
===
match
---
trailer [8959,8972]
trailer [8959,8972]
===
match
---
name: settings [29024,29032]
name: settings [29024,29032]
===
match
---
simple_stmt [16612,16672]
simple_stmt [16612,16672]
===
match
---
name: model [42889,42894]
name: model [42889,42894]
===
match
---
argument [27577,27584]
argument [27577,27584]
===
match
---
simple_stmt [12150,12191]
simple_stmt [12150,12191]
===
match
---
name: sync_to_db [41535,41545]
name: sync_to_db [41535,41545]
===
match
---
argument [17048,17062]
argument [17048,17062]
===
match
---
testlist_comp [10246,10254]
testlist_comp [10246,10254]
===
match
---
name: topological_sort [10708,10724]
name: topological_sort [10708,10724]
===
match
---
name: convert [22198,22205]
name: convert [22198,22205]
===
match
---
operator: + [13646,13647]
operator: + [13646,13647]
===
match
---
atom_expr [55140,55176]
atom_expr [57088,57124]
===
match
---
atom_expr [2495,2510]
atom_expr [2495,2510]
===
match
---
trailer [10707,10724]
trailer [10707,10724]
===
match
---
expr_stmt [31381,31583]
expr_stmt [31381,31583]
===
match
---
operator: = [9756,9757]
operator: = [9756,9757]
===
match
---
atom_expr [27723,27765]
atom_expr [27723,27765]
===
match
---
expr_stmt [33534,33623]
expr_stmt [33534,33623]
===
match
---
number: 1 [57492,57493]
number: 1 [59440,59441]
===
match
---
atom_expr [62063,62081]
atom_expr [64011,64029]
===
match
---
trailer [65439,65449]
trailer [67387,67397]
===
match
---
name: state [43513,43518]
name: state [43513,43518]
===
match
---
arglist [14410,14418]
arglist [14410,14418]
===
match
---
operator: , [32462,32463]
operator: , [32462,32463]
===
match
---
dictorsetmaker [34864,34924]
dictorsetmaker [34864,34924]
===
match
---
suite [12244,12447]
suite [12244,12447]
===
match
---
operator: = [11588,11589]
operator: = [11588,11589]
===
match
---
name: dag_decorator [1608,1621]
name: dag_decorator [1608,1621]
===
match
---
simple_stmt [1106,1155]
simple_stmt [1106,1155]
===
match
---
name: default_args [54728,54740]
name: default_args [56676,56688]
===
match
---
name: ACTION_CAN_EDIT [61879,61894]
name: ACTION_CAN_EDIT [63827,63842]
===
match
---
decorated [65684,65760]
decorated [67632,67708]
===
match
---
name: owner [39128,39133]
name: owner [39128,39133]
===
match
---
operator: , [52773,52774]
operator: , [54721,54722]
===
match
---
trailer [69225,69227]
trailer [71173,71175]
===
match
---
param [59903,59907]
param [61851,61855]
===
match
---
comparison [10382,10409]
comparison [10382,10409]
===
match
---
name: test_dag_naive_start_date_string [10736,10768]
name: test_dag_naive_start_date_string [10736,10768]
===
match
---
with_stmt [12829,13783]
with_stmt [12829,13783]
===
match
---
simple_stmt [36011,36043]
simple_stmt [36011,36043]
===
match
---
operator: == [17593,17595]
operator: == [17593,17595]
===
match
---
funcdef [24448,27196]
funcdef [24448,27196]
===
match
---
param [20204,20208]
param [20204,20208]
===
match
---
trailer [30152,30251]
trailer [30152,30251]
===
match
---
name: delta [23740,23745]
name: delta [23740,23745]
===
match
---
operator: = [43353,43354]
operator: = [43353,43354]
===
match
---
name: start_date [23822,23832]
name: start_date [23822,23832]
===
match
---
arglist [18172,18246]
arglist [18172,18246]
===
match
---
operator: = [51950,51951]
operator: = [53898,53899]
===
match
---
arglist [66339,66347]
arglist [68287,68295]
===
match
---
atom_expr [31830,31992]
atom_expr [31830,31992]
===
match
---
argument [12968,12991]
argument [12968,12991]
===
match
---
string: 'Also fake' [39134,39145]
string: 'Also fake' [39134,39145]
===
match
---
atom_expr [7952,7985]
atom_expr [7952,7985]
===
match
---
name: i [13063,13064]
name: i [13063,13064]
===
match
---
atom_expr [7107,7135]
atom_expr [7107,7135]
===
match
---
atom_expr [62395,62424]
atom_expr [64343,64372]
===
match
---
trailer [11734,11747]
trailer [11734,11747]
===
match
---
operator: = [14287,14288]
operator: = [14287,14288]
===
match
---
parameters [3890,3896]
parameters [3890,3896]
===
match
---
simple_stmt [2047,2106]
simple_stmt [2047,2106]
===
match
---
name: task_id [14848,14855]
name: task_id [14848,14855]
===
match
---
name: dag_id [23714,23720]
name: dag_id [23714,23720]
===
match
---
trailer [7512,7531]
trailer [7512,7531]
===
match
---
trailer [51826,51835]
trailer [53774,53783]
===
match
---
name: op4 [9096,9099]
name: op4 [9096,9099]
===
match
---
trailer [22523,22532]
trailer [22523,22532]
===
match
---
name: add_task [41244,41252]
name: add_task [41244,41252]
===
match
---
operator: = [4344,4345]
operator: = [4344,4345]
===
match
---
operator: = [13008,13009]
operator: = [13008,13009]
===
match
---
trailer [25881,25888]
trailer [25881,25888]
===
match
---
comparison [29503,29535]
comparison [29503,29535]
===
match
---
not_test [32848,32871]
not_test [32848,32871]
===
match
---
atom_expr [31340,31371]
atom_expr [31340,31371]
===
match
---
name: dag [3714,3717]
name: dag [3714,3717]
===
match
---
name: self [37783,37787]
name: self [37783,37787]
===
match
---
name: DagRunType [39229,39239]
name: DagRunType [39229,39239]
===
match
---
trailer [66927,66929]
trailer [68875,68877]
===
match
---
string: 'b_parent' [8375,8385]
string: 'b_parent' [8375,8385]
===
match
---
trailer [22848,22856]
trailer [22848,22856]
===
match
---
trailer [21578,21593]
trailer [21578,21593]
===
match
---
trailer [37401,37479]
trailer [37401,37479]
===
match
---
with_stmt [61916,62048]
with_stmt [63864,63996]
===
match
---
name: range [24600,24605]
name: range [24600,24605]
===
match
---
simple_stmt [47907,47950]
simple_stmt [47907,47950]
===
match
---
name: hours [55381,55386]
name: hours [57329,57334]
===
match
---
name: prev [20985,20989]
name: prev [20985,20989]
===
match
---
funcdef [10843,10981]
funcdef [10843,10981]
===
match
---
trailer [55316,55318]
trailer [57264,57266]
===
match
---
operator: = [45974,45975]
operator: = [45974,45975]
===
match
---
argument [19785,19808]
argument [19785,19808]
===
match
---
number: 5 [58135,58136]
number: 5 [60083,60084]
===
match
---
trailer [53440,53452]
trailer [55388,55400]
===
match
---
name: task_id [9659,9666]
name: task_id [9659,9666]
===
match
---
trailer [66338,66348]
trailer [68286,68296]
===
match
---
atom_expr [54855,55065]
atom_expr [56803,57013]
===
match
---
simple_stmt [63734,63759]
simple_stmt [65682,65707]
===
match
---
name: DAGsubclass [44554,44565]
name: DAGsubclass [44554,44565]
===
match
---
operator: = [38385,38386]
operator: = [38385,38386]
===
match
---
number: 0 [15739,15740]
number: 0 [15739,15740]
===
match
---
operator: , [56176,56177]
operator: , [58124,58125]
===
match
---
number: 4 [66279,66280]
number: 4 [68227,68228]
===
match
---
simple_stmt [9153,9187]
simple_stmt [9153,9187]
===
match
---
comparison [21851,21898]
comparison [21851,21898]
===
match
---
string: 'webserver' [5614,5625]
string: 'webserver' [5614,5625]
===
match
---
operator: = [35419,35420]
operator: = [35419,35420]
===
match
---
operator: = [54741,54742]
operator: = [56689,56690]
===
match
---
name: dag_id [39386,39392]
name: dag_id [39386,39392]
===
match
---
name: start_date [67516,67526]
name: start_date [69464,69474]
===
match
---
name: b [3180,3181]
name: b [3180,3181]
===
match
---
with_item [33380,33407]
with_item [33380,33407]
===
match
---
expr_stmt [13932,13942]
expr_stmt [13932,13942]
===
match
---
operator: , [26960,26961]
operator: , [26960,26961]
===
match
---
name: start_date [43717,43727]
name: start_date [43717,43727]
===
match
---
string: """Verify tasks with Duplicate task_id raises error""" [37320,37374]
string: """Verify tasks with Duplicate task_id raises error""" [37320,37374]
===
match
---
atom_expr [10333,10365]
atom_expr [10333,10365]
===
match
---
name: DagRun [47310,47316]
name: DagRun [47310,47316]
===
match
---
simple_stmt [40812,40835]
simple_stmt [40812,40835]
===
match
---
atom_expr [6685,6694]
atom_expr [6685,6694]
===
match
---
string: 'dag-bulk-sync-2' [26195,26212]
string: 'dag-bulk-sync-2' [26195,26212]
===
match
---
string: 'dag-bulk-sync-1' [26644,26661]
string: 'dag-bulk-sync-1' [26644,26661]
===
match
---
operator: = [54853,54854]
operator: = [56801,56802]
===
match
---
operator: = [36301,36302]
operator: = [36301,36302]
===
match
---
number: 2038 [62757,62761]
number: 2038 [64705,64709]
===
match
---
number: 1 [48731,48732]
number: 1 [48731,48732]
===
match
---
operator: = [14827,14828]
operator: = [14827,14828]
===
match
---
atom_expr [58360,58397]
atom_expr [60308,60345]
===
match
---
trailer [40058,40068]
trailer [40058,40068]
===
match
---
atom_expr [10160,10179]
atom_expr [10160,10179]
===
match
---
atom_expr [21965,21988]
atom_expr [21965,21988]
===
match
---
atom_expr [39708,39732]
atom_expr [39708,39732]
===
match
---
expr_stmt [64915,64925]
expr_stmt [66863,66873]
===
match
---
name: test_params_passed_and_params_in_default_args_no_override [3833,3890]
name: test_params_passed_and_params_in_default_args_no_override [3833,3890]
===
match
---
name: prev [20913,20917]
name: prev [20913,20917]
===
match
---
argument [28012,28044]
argument [28012,28044]
===
match
---
string: 't1' [38409,38413]
string: 't1' [38409,38413]
===
match
---
operator: , [36905,36906]
operator: , [36905,36906]
===
match
---
name: next_dagrun [28275,28286]
name: next_dagrun [28275,28286]
===
match
---
string: 'old_existing_dag' [33842,33860]
string: 'old_existing_dag' [33842,33860]
===
match
---
string: "0 0 * * 0" [46441,46452]
string: "0 0 * * 0" [46441,46452]
===
match
---
parameters [49955,49976]
parameters [49955,49976]
===
match
---
argument [62384,62424]
argument [64332,64372]
===
match
---
simple_stmt [26536,26563]
simple_stmt [26536,26563]
===
match
---
operator: = [61497,61498]
operator: = [63445,63446]
===
match
---
string: 'DAG' [11959,11964]
string: 'DAG' [11959,11964]
===
match
---
expr_stmt [69204,69227]
expr_stmt [71152,71175]
===
match
---
assert_stmt [26617,26790]
assert_stmt [26617,26790]
===
match
---
name: query [34230,34235]
name: query [34230,34235]
===
match
---
operator: = [7437,7438]
operator: = [7437,7438]
===
match
---
operator: , [52072,52073]
operator: , [54020,54021]
===
match
---
name: dr [48049,48051]
name: dr [48049,48051]
===
match
---
atom_expr [68146,68173]
atom_expr [70094,70121]
===
match
---
operator: = [67293,67294]
operator: = [69241,69242]
===
match
---
trailer [27559,27602]
trailer [27559,27602]
===
match
---
atom [27751,27764]
atom [27751,27764]
===
match
---
name: freezegun [1160,1169]
name: freezegun [1160,1169]
===
match
---
expr_stmt [29844,29954]
expr_stmt [29844,29954]
===
match
---
arith_expr [44489,44509]
arith_expr [44489,44509]
===
match
---
name: dag_subclass_diff_name [44740,44762]
name: dag_subclass_diff_name [44740,44762]
===
match
---
trailer [33441,33491]
trailer [33441,33491]
===
match
---
operator: , [31539,31540]
operator: , [31539,31540]
===
match
---
operator: = [31018,31019]
operator: = [31018,31019]
===
match
---
name: task_id [35939,35946]
name: task_id [35939,35946]
===
match
---
name: set_upstream [16061,16073]
name: set_upstream [16061,16073]
===
match
---
operator: = [34004,34005]
operator: = [34004,34005]
===
match
---
trailer [56009,56011]
trailer [57957,57959]
===
match
---
trailer [54061,54102]
trailer [56009,56050]
===
match
---
string: '@once' [56581,56588]
string: '@once' [58529,58536]
===
match
---
atom_expr [38387,38414]
atom_expr [38387,38414]
===
match
---
name: _next [21982,21987]
name: _next [21982,21987]
===
match
---
trailer [25493,25510]
trailer [25493,25510]
===
match
---
name: row [25841,25844]
name: row [25841,25844]
===
match
---
atom_expr [40410,40480]
atom_expr [40410,40480]
===
match
---
name: dag [60480,60483]
name: dag [62428,62431]
===
match
---
atom_expr [29284,29304]
atom_expr [29284,29304]
===
match
---
suite [68804,69277]
suite [70752,71225]
===
match
---
name: set2 [10490,10494]
name: set2 [10490,10494]
===
match
---
expr_stmt [28869,28892]
expr_stmt [28869,28892]
===
match
---
trailer [67489,67496]
trailer [69437,69444]
===
match
---
operator: == [28287,28289]
operator: == [28287,28289]
===
match
---
trailer [61615,61646]
trailer [63563,63594]
===
match
---
expr_stmt [64237,64298]
expr_stmt [66185,66246]
===
match
---
trailer [51991,51999]
trailer [53939,53947]
===
match
---
operator: , [1256,1257]
operator: , [1256,1257]
===
match
---
name: local_tz [20746,20754]
name: local_tz [20746,20754]
===
match
---
name: datetime [58435,58443]
name: datetime [60383,60391]
===
match
---
operator: = [37100,37101]
operator: = [37100,37101]
===
match
---
arglist [27690,27704]
arglist [27690,27704]
===
match
---
name: test_pickling [43825,43838]
name: test_pickling [43825,43838]
===
match
---
atom_expr [62969,62987]
atom_expr [64917,64935]
===
match
---
operator: , [46492,46493]
operator: , [46492,46493]
===
match
---
name: next_date [56448,56457]
name: next_date [58396,58405]
===
match
---
trailer [9952,9957]
trailer [9952,9957]
===
match
---
operator: { [24541,24542]
operator: { [24541,24542]
===
match
---
name: default_view [33647,33659]
name: default_view [33647,33659]
===
match
---
expr_stmt [43349,43579]
expr_stmt [43349,43579]
===
match
---
simple_stmt [23049,23086]
simple_stmt [23049,23086]
===
match
---
atom_expr [23062,23085]
atom_expr [23062,23085]
===
match
---
comparison [25301,25319]
comparison [25301,25319]
===
match
---
operator: == [22092,22094]
operator: == [22092,22094]
===
match
---
argument [51308,51314]
argument [51308,51314]
===
match
---
simple_stmt [6917,6954]
simple_stmt [6917,6954]
===
match
---
simple_stmt [16881,16943]
simple_stmt [16881,16943]
===
match
---
trailer [27150,27152]
trailer [27150,27152]
===
match
---
atom_expr [64553,64566]
atom_expr [66501,66514]
===
match
---
operator: = [43263,43264]
operator: = [43263,43264]
===
match
---
operator: @ [66678,66679]
operator: @ [68626,68627]
===
match
---
operator: = [64284,64285]
operator: = [66232,66233]
===
match
---
argument [18086,18101]
argument [18086,18101]
===
match
---
operator: == [32091,32093]
operator: == [32091,32093]
===
match
---
expr_stmt [55189,55231]
expr_stmt [57137,57179]
===
match
---
operator: = [61116,61117]
operator: = [63064,63065]
===
match
---
trailer [2959,2965]
trailer [2959,2965]
===
match
---
string: 'dag' [16479,16484]
string: 'dag' [16479,16484]
===
match
---
name: DAG [26536,26539]
name: DAG [26536,26539]
===
match
---
name: get [41634,41637]
name: get [41634,41637]
===
match
---
name: orm_dag [63594,63601]
name: orm_dag [65542,65549]
===
match
---
name: _occur_before [3163,3176]
name: _occur_before [3163,3176]
===
match
---
simple_stmt [22707,22776]
simple_stmt [22707,22776]
===
match
---
name: dag [40617,40620]
name: dag [40617,40620]
===
match
---
name: task_id [6171,6178]
name: task_id [6171,6178]
===
match
---
simple_stmt [64980,65001]
simple_stmt [66928,66949]
===
match
---
name: dag_id [2888,2894]
name: dag_id [2888,2894]
===
match
---
assert_stmt [5598,5664]
assert_stmt [5598,5664]
===
match
---
simple_stmt [20219,20291]
simple_stmt [20219,20291]
===
match
---
comparison [9116,9144]
comparison [9116,9144]
===
match
---
operator: { [24323,24324]
operator: { [24323,24324]
===
match
---
operator: @ [65280,65281]
operator: @ [67228,67229]
===
match
---
name: task_decorator [65281,65295]
name: task_decorator [67229,67243]
===
match
---
trailer [21593,21600]
trailer [21593,21600]
===
match
---
comparison [38117,38170]
comparison [38117,38170]
===
match
---
name: task_id [28956,28963]
name: task_id [28956,28963]
===
match
---
simple_stmt [34459,34533]
simple_stmt [34459,34533]
===
match
---
simple_stmt [41945,41968]
simple_stmt [41945,41968]
===
match
---
with_stmt [64420,64624]
with_stmt [66368,66572]
===
match
---
atom_expr [39426,39440]
atom_expr [39426,39440]
===
match
---
operator: } [44289,44290]
operator: } [44289,44290]
===
match
---
name: dag_id [39776,39782]
name: dag_id [39776,39782]
===
match
---
simple_stmt [29459,29543]
simple_stmt [29459,29543]
===
match
---
trailer [60894,60905]
trailer [62842,62853]
===
match
---
name: isinstance [68146,68156]
name: isinstance [70094,70104]
===
match
---
name: dag_run [39531,39538]
name: dag_run [39531,39538]
===
match
---
operator: = [48262,48263]
operator: = [48262,48263]
===
match
---
atom_expr [57468,57497]
atom_expr [59416,59445]
===
match
---
name: model [27840,27845]
name: model [27840,27845]
===
match
---
name: DummyOperator [37613,37626]
name: DummyOperator [37613,37626]
===
match
---
atom_expr [54036,54103]
atom_expr [55984,56051]
===
match
---
name: dag [61144,61147]
name: dag [63092,63095]
===
match
---
trailer [34426,34448]
trailer [34426,34448]
===
match
---
operator: = [40653,40654]
operator: = [40653,40654]
===
match
---
name: topological_list [9288,9304]
name: topological_list [9288,9304]
===
match
---
name: flush [19639,19644]
name: flush [19639,19644]
===
match
---
arglist [59692,59733]
arglist [61640,61681]
===
match
---
name: session [17531,17538]
name: session [17531,17538]
===
match
---
trailer [58274,58280]
trailer [60222,60228]
===
match
---
number: 1 [9219,9220]
number: 1 [9219,9220]
===
match
---
operator: = [37634,37635]
operator: = [37634,37635]
===
match
---
name: _clean_up [43798,43807]
name: _clean_up [43798,43807]
===
match
---
atom_expr [50301,50355]
atom_expr [50301,50355]
===
match
---
name: dag [47255,47258]
name: dag [47255,47258]
===
match
---
name: DuplicateTaskIdFound [37402,37422]
name: DuplicateTaskIdFound [37402,37422]
===
match
---
name: op2 [37176,37179]
name: op2 [37176,37179]
===
match
---
argument [14079,14111]
argument [14079,14111]
===
match
---
argument [50249,50272]
argument [50249,50272]
===
match
---
name: DagModel [24882,24890]
name: DagModel [24882,24890]
===
match
---
name: t_2 [51038,51041]
name: t_2 [51038,51041]
===
match
---
testlist_comp [10135,10143]
testlist_comp [10135,10143]
===
match
---
trailer [42521,42535]
trailer [42521,42535]
===
match
---
trailer [17484,17490]
trailer [17484,17490]
===
match
---
trailer [38225,38233]
trailer [38225,38233]
===
match
---
funcdef [35616,36093]
funcdef [35616,36093]
===
match
---
name: op1 [55244,55247]
name: op1 [57192,57195]
===
match
---
name: op4 [6624,6627]
name: op4 [6624,6627]
===
match
---
number: 1 [53770,53771]
number: 1 [55718,55719]
===
match
---
atom_expr [50552,50564]
atom_expr [50552,50564]
===
match
---
operator: = [41058,41059]
operator: = [41058,41059]
===
match
---
trailer [49201,49208]
trailer [49201,49208]
===
match
---
operator: , [46602,46603]
operator: , [46602,46603]
===
match
---
trailer [22574,22582]
trailer [22574,22582]
===
match
---
string: 'Invalid values of dag.default_view: only support' [4660,4710]
string: 'Invalid values of dag.default_view: only support' [4660,4710]
===
match
---
atom_expr [9780,9806]
atom_expr [9780,9806]
===
match
---
name: _next [21908,21913]
name: _next [21908,21913]
===
match
---
name: query [31419,31424]
name: query [31419,31424]
===
match
---
trailer [25270,25274]
trailer [25270,25274]
===
match
---
name: DagTag [26362,26368]
name: DagTag [26362,26368]
===
match
---
name: task_id [7078,7085]
name: task_id [7078,7085]
===
match
---
for_stmt [3316,3464]
for_stmt [3316,3464]
===
match
---
name: default_args [8573,8585]
name: default_args [8573,8585]
===
match
---
name: task_dict [37200,37209]
name: task_dict [37200,37209]
===
match
---
name: params [3816,3822]
name: params [3816,3822]
===
match
---
assert_stmt [56814,56859]
assert_stmt [58762,58807]
===
match
---
trailer [21502,21519]
trailer [21502,21519]
===
match
---
name: DAG [30663,30666]
name: DAG [30663,30666]
===
match
---
atom_expr [59202,59242]
atom_expr [61150,61190]
===
match
---
assert_stmt [27833,27873]
assert_stmt [27833,27873]
===
match
---
name: test_task_id [17728,17740]
name: test_task_id [17728,17740]
===
match
---
string: "SubDags should never have DagRuns created by the scheduler" [61346,61406]
string: "SubDags should never have DagRuns created by the scheduler" [63294,63354]
===
match
---
atom_expr [9166,9185]
atom_expr [9166,9185]
===
match
---
operator: } [64385,64386]
operator: } [66333,66334]
===
match
---
comparison [5012,5081]
comparison [5012,5081]
===
match
---
atom_expr [21485,21519]
atom_expr [21485,21519]
===
match
---
atom_expr [51919,51932]
atom_expr [53867,53880]
===
match
---
string: 'test_field' [19334,19346]
string: 'test_field' [19334,19346]
===
match
---
name: DagModel [41624,41632]
name: DagModel [41624,41632]
===
match
---
name: op1 [7822,7825]
name: op1 [7822,7825]
===
match
---
trailer [22015,22025]
trailer [22015,22025]
===
match
---
atom_expr [45256,45273]
atom_expr [45256,45273]
===
match
---
trailer [3004,3031]
trailer [3004,3031]
===
match
---
atom_expr [5917,5986]
atom_expr [5917,5986]
===
match
---
suite [66726,66754]
suite [68674,68702]
===
match
---
name: dag [27577,27580]
name: dag [27577,27580]
===
match
---
argument [38015,38027]
argument [38015,38027]
===
match
---
trailer [59452,59461]
trailer [61400,61409]
===
match
---
simple_stmt [2670,2686]
simple_stmt [2670,2686]
===
match
---
string: 'some_string' [20147,20160]
string: 'some_string' [20147,20160]
===
match
---
name: prev_task [14665,14674]
name: prev_task [14665,14674]
===
match
---
operator: = [17140,17141]
operator: = [17140,17141]
===
match
---
name: name [19048,19052]
name: name [19048,19052]
===
match
---
operator: , [51356,51357]
operator: , [51356,51357]
===
match
---
comparison [6685,6706]
comparison [6685,6706]
===
match
---
arith_expr [43393,43425]
arith_expr [43393,43425]
===
match
---
name: paused_dags [32488,32499]
name: paused_dags [32488,32499]
===
match
---
comparison [27840,27873]
comparison [27840,27873]
===
match
---
parameters [41999,42005]
parameters [41999,42005]
===
match
---
string: "Pre-condition: start date is in DST" [20517,20554]
string: "Pre-condition: start date is in DST" [20517,20554]
===
match
---
number: 5 [12533,12534]
number: 5 [12533,12534]
===
match
---
operator: = [50588,50589]
operator: = [50588,50589]
===
match
---
number: 25 [22610,22612]
number: 25 [22610,22612]
===
match
---
atom [18046,18060]
atom [18046,18060]
===
match
---
name: task_id [8845,8852]
name: task_id [8845,8852]
===
match
---
atom_expr [48678,48733]
atom_expr [48678,48733]
===
match
---
argument [43478,43499]
argument [43478,43499]
===
match
---
param [64209,64214]
param [66157,66162]
===
match
---
operator: == [6885,6887]
operator: == [6885,6887]
===
match
---
name: datetime [56887,56895]
name: datetime [58835,58843]
===
match
---
operator: = [39228,39229]
operator: = [39228,39229]
===
match
---
simple_stmt [47304,47337]
simple_stmt [47304,47337]
===
match
---
name: test_clear_dag [51868,51882]
name: test_clear_dag [53816,53830]
===
match
---
atom [28239,28252]
atom [28239,28252]
===
match
---
name: dag [58248,58251]
name: dag [60196,60199]
===
match
---
name: default_args [34952,34964]
name: default_args [34952,34964]
===
match
---
operator: , [4652,4653]
operator: , [4652,4653]
===
match
---
expr_stmt [27943,28127]
expr_stmt [27943,28127]
===
match
---
operator: { [68567,68568]
operator: { [70515,70516]
===
match
---
trailer [63741,63751]
trailer [65689,65699]
===
match
---
simple_stmt [10153,10188]
simple_stmt [10153,10188]
===
match
---
atom_expr [27622,27640]
atom_expr [27622,27640]
===
match
---
expr_stmt [48797,48825]
expr_stmt [48797,48825]
===
match
---
name: start_date [52049,52059]
name: start_date [53997,54007]
===
match
---
name: dag_id [42231,42237]
name: dag_id [42231,42237]
===
match
---
trailer [27791,27810]
trailer [27791,27810]
===
match
---
name: dag2 [6190,6194]
name: dag2 [6190,6194]
===
match
---
name: self [8420,8424]
name: self [8420,8424]
===
match
---
trailer [30057,30266]
trailer [30057,30266]
===
match
---
name: set [32484,32487]
name: set [32484,32487]
===
match
---
atom [41638,41651]
atom [41638,41651]
===
match
---
operator: , [26077,26078]
operator: , [26077,26078]
===
match
---
operator: = [64503,64504]
operator: = [66451,66452]
===
match
---
atom_expr [62510,62528]
atom_expr [64458,64476]
===
match
---
operator: , [61814,61815]
operator: , [63762,63763]
===
match
---
number: 28 [20406,20408]
number: 28 [20406,20408]
===
match
---
atom_expr [43731,43745]
atom_expr [43731,43745]
===
match
---
atom_expr [2977,2986]
atom_expr [2977,2986]
===
match
---
atom_expr [41610,41652]
atom_expr [41610,41652]
===
match
---
name: DagRunType [68404,68414]
name: DagRunType [70352,70362]
===
match
---
name: ti2 [17491,17494]
name: ti2 [17491,17494]
===
match
---
name: dag [37645,37648]
name: dag [37645,37648]
===
match
---
suite [66095,66282]
suite [68043,68230]
===
match
---
operator: = [56056,56057]
operator: = [58004,58005]
===
match
---
operator: = [50508,50509]
operator: = [50508,50509]
===
match
---
name: dag [7186,7189]
name: dag [7186,7189]
===
match
---
name: updated_permissions [61711,61730]
name: updated_permissions [63659,63678]
===
match
---
name: state [68529,68534]
name: state [70477,70482]
===
match
---
name: dag [57617,57620]
name: dag [59565,59568]
===
match
---
atom_expr [50100,50155]
atom_expr [50100,50155]
===
match
---
atom [24520,24612]
atom [24520,24612]
===
match
---
simple_stmt [4404,4436]
simple_stmt [4404,4436]
===
match
---
operator: = [28629,28630]
operator: = [28629,28630]
===
match
---
trailer [33105,33115]
trailer [33105,33115]
===
match
---
operator: = [7038,7039]
operator: = [7038,7039]
===
match
---
simple_stmt [67728,67760]
simple_stmt [69676,69708]
===
match
---
arith_expr [16016,16021]
arith_expr [16016,16021]
===
match
---
atom_expr [43210,43299]
atom_expr [43210,43299]
===
match
---
operator: = [66612,66613]
operator: = [68560,68561]
===
match
---
name: op1 [36389,36392]
name: op1 [36389,36392]
===
match
---
argument [35985,35997]
argument [35985,35997]
===
match
---
expr_stmt [29459,29542]
expr_stmt [29459,29542]
===
match
---
string: 'test_scheduler_dagrun_once' [53232,53260]
string: 'test_scheduler_dagrun_once' [55180,55208]
===
match
---
name: set1 [10276,10280]
name: set1 [10276,10280]
===
match
---
name: DummyOperator [19224,19237]
name: DummyOperator [19224,19237]
===
match
---
name: task_id [60800,60807]
name: task_id [62748,62755]
===
match
---
argument [47785,47826]
argument [47785,47826]
===
match
---
operator: = [22137,22138]
operator: = [22137,22138]
===
match
---
operator: } [15439,15440]
operator: } [15439,15440]
===
match
---
trailer [3726,3730]
trailer [3726,3730]
===
match
---
name: isoformat [22016,22025]
name: isoformat [22016,22025]
===
match
---
expr_stmt [53462,53511]
expr_stmt [55410,55459]
===
match
---
string: 'owner1' [6735,6743]
string: 'owner1' [6735,6743]
===
match
---
operator: , [50601,50602]
operator: , [50601,50602]
===
match
---
simple_stmt [37662,37673]
simple_stmt [37662,37673]
===
match
---
with_stmt [8713,8978]
with_stmt [8713,8978]
===
match
---
simple_stmt [64956,64972]
simple_stmt [66904,66920]
===
match
---
name: State [47621,47626]
name: State [47621,47626]
===
match
---
name: delta [23657,23662]
name: delta [23657,23662]
===
match
---
arglist [30893,30937]
arglist [30893,30937]
===
match
---
atom_expr [34408,34448]
atom_expr [34408,34448]
===
match
---
trailer [61147,61170]
trailer [63095,63118]
===
match
---
operator: = [68348,68349]
operator: = [70296,70297]
===
match
---
assert_stmt [46135,46168]
assert_stmt [46135,46168]
===
match
---
name: session [24868,24875]
name: session [24868,24875]
===
match
---
for_stmt [13110,13361]
for_stmt [13110,13361]
===
match
---
trailer [54858,55065]
trailer [56806,57013]
===
match
---
argument [36997,37020]
argument [36997,37020]
===
match
---
trailer [11747,11761]
trailer [11747,11761]
===
match
---
atom_expr [68918,68935]
atom_expr [70866,70883]
===
match
---
operator: , [40696,40697]
operator: , [40696,40697]
===
match
---
number: 10 [59847,59849]
number: 10 [61795,61797]
===
match
---
operator: } [31671,31672]
operator: } [31671,31672]
===
match
---
trailer [7602,7716]
trailer [7602,7716]
===
match
---
simple_stmt [51642,51679]
simple_stmt [51642,51679]
===
match
---
string: 'dag_without_catchup_ten_minute' [55623,55655]
string: 'dag_without_catchup_ten_minute' [57571,57603]
===
match
---
name: DagModel [34665,34673]
name: DagModel [34665,34673]
===
match
---
trailer [50679,50693]
trailer [50679,50693]
===
match
---
operator: } [68586,68587]
operator: } [70534,70535]
===
match
---
trailer [66617,66630]
trailer [68565,68578]
===
match
---
operator: == [17990,17992]
operator: == [17990,17992]
===
match
---
name: NONE [47290,47294]
name: NONE [47290,47294]
===
match
---
expr_stmt [56021,56214]
expr_stmt [57969,58162]
===
match
---
name: session [62845,62852]
name: session [64793,64800]
===
match
---
name: one [34527,34530]
name: one [34527,34530]
===
match
---
name: start [20467,20472]
name: start [20467,20472]
===
match
---
string: b'{{ ds }}' [18968,18979]
string: b'{{ ds }}' [18968,18979]
===
match
---
name: test_dag_task_invalid_weight_rule [16371,16404]
name: test_dag_task_invalid_weight_rule [16371,16404]
===
match
---
atom [13620,13636]
atom [13620,13636]
===
match
---
name: DagModel [31861,31869]
name: DagModel [31861,31869]
===
match
---
trailer [27652,27658]
trailer [27652,27658]
===
match
---
trailer [2707,2709]
trailer [2707,2709]
===
match
---
name: local_tz [23062,23070]
name: local_tz [23062,23070]
===
match
---
name: local_tz [20968,20976]
name: local_tz [20968,20976]
===
match
---
parameters [11933,11939]
parameters [11933,11939]
===
match
---
name: query [24876,24881]
name: query [24876,24881]
===
match
---
atom_expr [56460,56477]
atom_expr [58408,58425]
===
match
---
atom_expr [12089,12141]
atom_expr [12089,12141]
===
match
---
name: state [51656,51661]
name: state [51656,51661]
===
match
---
atom_expr [44075,44085]
atom_expr [44075,44085]
===
match
---
suite [18510,18546]
suite [18510,18546]
===
match
---
for_stmt [54195,54300]
for_stmt [56143,56248]
===
match
---
string: 'test' [65477,65483]
string: 'test' [67425,67431]
===
match
---
trailer [34492,34499]
trailer [34492,34499]
===
match
---
name: TaskInstance [1498,1510]
name: TaskInstance [1498,1510]
===
match
---
trailer [33583,33590]
trailer [33583,33590]
===
match
---
simple_stmt [43956,43998]
simple_stmt [43956,43998]
===
match
---
simple_stmt [50164,50210]
simple_stmt [50164,50210]
===
match
---
trailer [55497,55507]
trailer [57445,57455]
===
match
---
name: make_dag [56028,56036]
name: make_dag [57976,57984]
===
match
---
assert_stmt [29277,29316]
assert_stmt [29277,29316]
===
match
---
atom_expr [62739,62768]
atom_expr [64687,64716]
===
match
---
operator: == [47926,47928]
operator: == [47926,47928]
===
match
---
comparison [28269,28300]
comparison [28269,28300]
===
match
---
name: jinja_env [18755,18764]
name: jinja_env [18755,18764]
===
match
---
comparison [13166,13172]
comparison [13166,13172]
===
match
---
trailer [23980,23999]
trailer [23980,23999]
===
match
---
simple_stmt [40140,40364]
simple_stmt [40140,40364]
===
match
---
argument [11614,11705]
argument [11614,11705]
===
match
---
string: 'dummy_task' [30810,30822]
string: 'dummy_task' [30810,30822]
===
match
---
simple_stmt [39697,39733]
simple_stmt [39697,39733]
===
match
---
arglist [36194,36229]
arglist [36194,36229]
===
match
---
comparison [59431,59479]
comparison [61379,61427]
===
match
---
operator: = [34939,34940]
operator: = [34939,34940]
===
match
---
param [12492,12496]
param [12492,12496]
===
match
---
for_stmt [60389,60496]
for_stmt [62337,62444]
===
match
---
operator: = [62455,62456]
operator: = [64403,64404]
===
match
---
string: 'fakename' [17821,17831]
string: 'fakename' [17821,17831]
===
match
---
atom_expr [15661,15680]
atom_expr [15661,15680]
===
match
---
operator: = [40450,40451]
operator: = [40450,40451]
===
match
---
name: dag_id [39404,39410]
name: dag_id [39404,39410]
===
match
---
atom_expr [34073,34091]
atom_expr [34073,34091]
===
match
---
string: 'dummy' [62456,62463]
string: 'dummy' [64404,64411]
===
match
---
name: BACKFILL_JOB [52271,52283]
name: BACKFILL_JOB [54219,54231]
===
match
---
atom_expr [24022,24039]
atom_expr [24022,24039]
===
match
---
operator: = [15660,15661]
operator: = [15660,15661]
===
match
---
operator: = [49005,49006]
operator: = [49005,49006]
===
match
---
name: xcom_arg [68187,68195]
name: xcom_arg [70135,70143]
===
match
---
operator: = [20966,20967]
operator: = [20966,20967]
===
match
---
simple_stmt [30312,30344]
simple_stmt [30312,30344]
===
match
---
operator: } [61579,61580]
operator: } [63527,63528]
===
match
---
name: self [8516,8520]
name: self [8516,8520]
===
match
---
operator: , [14351,14352]
operator: , [14351,14352]
===
match
---
atom_expr [10430,10449]
atom_expr [10430,10449]
===
match
---
name: schedule_interval [54675,54692]
name: schedule_interval [56623,56640]
===
match
---
operator: == [31673,31675]
operator: == [31673,31675]
===
match
---
atom [51805,51836]
atom [53753,53784]
===
match
---
name: DAG [54855,54858]
name: DAG [56803,56806]
===
match
---
simple_stmt [32012,32111]
simple_stmt [32012,32111]
===
match
---
name: DummyOperator [35306,35319]
name: DummyOperator [35306,35319]
===
match
---
expr_stmt [35346,35379]
expr_stmt [35346,35379]
===
match
---
argument [6384,6397]
argument [6384,6397]
===
match
---
operator: , [68654,68655]
operator: , [70602,70603]
===
match
---
trailer [13031,13041]
trailer [13031,13041]
===
match
---
operator: , [24770,24771]
operator: , [24770,24771]
===
match
---
simple_stmt [20913,20947]
simple_stmt [20913,20947]
===
match
---
funcdef [51864,53152]
funcdef [53812,55100]
===
match
---
name: close [63004,63009]
name: close [64952,64957]
===
match
---
operator: , [8571,8572]
operator: , [8571,8572]
===
match
---
name: name [19745,19749]
name: name [19745,19749]
===
match
---
trailer [53387,53393]
trailer [55335,55341]
===
match
---
trailer [48074,48081]
trailer [48074,48081]
===
match
---
operator: { [10808,10809]
operator: { [10808,10809]
===
match
---
name: timezone [43322,43330]
name: timezone [43322,43330]
===
match
---
trailer [58480,58503]
trailer [60428,60451]
===
match
---
trailer [46254,46281]
trailer [46254,46281]
===
match
---
string: 'owner' [12884,12891]
string: 'owner' [12884,12891]
===
match
---
comparison [46965,47007]
comparison [46965,47007]
===
match
---
atom_expr [3075,3090]
atom_expr [3075,3090]
===
match
---
operator: , [52283,52284]
operator: , [54231,54232]
===
match
---
simple_stmt [54175,54187]
simple_stmt [56123,56135]
===
match
---
simple_stmt [879,918]
simple_stmt [879,918]
===
match
---
name: op4 [9774,9777]
name: op4 [9774,9777]
===
match
---
string: "10 10 * * *" [59645,59658]
string: "10 10 * * *" [61593,61606]
===
match
---
name: execution_date [48991,49005]
name: execution_date [48991,49005]
===
match
---
trailer [29054,29065]
trailer [29054,29065]
===
match
---
name: State [17391,17396]
name: State [17391,17396]
===
match
---
argument [17238,17244]
argument [17238,17244]
===
match
---
operator: = [31395,31396]
operator: = [31395,31396]
===
match
---
comparison [45436,45460]
comparison [45436,45460]
===
match
---
operator: = [55161,55162]
operator: = [57109,57110]
===
match
---
funcdef [36098,36718]
funcdef [36098,36718]
===
match
---
operator: , [47879,47880]
operator: , [47879,47880]
===
match
---
operator: == [29691,29693]
operator: == [29691,29693]
===
match
---
trailer [5227,5234]
trailer [5227,5234]
===
match
---
name: used_group_ids [38842,38856]
name: used_group_ids [38842,38856]
===
match
---
name: dag [57407,57410]
name: dag [59355,59358]
===
match
---
atom_expr [66328,66348]
atom_expr [68276,68296]
===
match
---
name: dag_id [50231,50237]
name: dag_id [50231,50237]
===
match
---
atom_expr [5221,5309]
atom_expr [5221,5309]
===
match
---
atom_expr [16475,16544]
atom_expr [16475,16544]
===
match
---
simple_stmt [50933,51009]
simple_stmt [50933,51009]
===
match
---
operator: != [45782,45784]
operator: != [45782,45784]
===
match
---
string: "2018-10-28T02:55:00+02:00" [20488,20515]
string: "2018-10-28T02:55:00+02:00" [20488,20515]
===
match
---
atom_expr [7880,7933]
atom_expr [7880,7933]
===
match
---
atom_expr [53745,53772]
atom_expr [55693,55720]
===
match
---
operator: } [61905,61906]
operator: } [63853,63854]
===
match
---
trailer [31424,31461]
trailer [31424,31461]
===
match
---
trailer [31274,31281]
trailer [31274,31281]
===
match
---
operator: , [68515,68516]
operator: , [70463,70464]
===
match
---
operator: } [37230,37231]
operator: } [37230,37231]
===
match
---
operator: = [16991,16992]
operator: = [16991,16992]
===
match
---
funcdef [45847,46316]
funcdef [45847,46316]
===
match
---
trailer [25192,25197]
trailer [25192,25197]
===
match
---
operator: { [60448,60449]
operator: { [62396,62397]
===
match
---
name: test_dag_id [17714,17725]
name: test_dag_id [17714,17725]
===
match
---
operator: , [17954,17955]
operator: , [17954,17955]
===
match
---
operator: == [16344,16346]
operator: == [16344,16346]
===
match
---
trailer [40672,40688]
trailer [40672,40688]
===
match
---
trailer [28413,28438]
trailer [28413,28438]
===
match
---
operator: , [64854,64855]
operator: , [66802,66803]
===
match
---
name: test_clear_set_dagrun_state_for_subdag [49917,49955]
name: test_clear_set_dagrun_state_for_subdag [49917,49955]
===
match
---
trailer [34235,34245]
trailer [34235,34245]
===
match
---
arith_expr [17079,17120]
arith_expr [17079,17120]
===
match
---
name: states [18346,18352]
name: states [18346,18352]
===
match
---
param [12238,12242]
param [12238,12242]
===
match
---
expr_stmt [56487,56676]
expr_stmt [58435,58624]
===
match
---
operator: , [68162,68163]
operator: , [70110,70111]
===
match
---
string: 'test_clear_set_dagrun_state_subdag' [49995,50031]
string: 'test_clear_set_dagrun_state_subdag' [49995,50031]
===
match
---
name: dag [9622,9625]
name: dag [9622,9625]
===
match
---
arith_expr [51274,51315]
arith_expr [51274,51315]
===
match
---
trailer [28875,28886]
trailer [28875,28886]
===
match
---
trailer [20700,20719]
trailer [20700,20719]
===
match
---
funcdef [2438,2629]
funcdef [2438,2629]
===
match
---
name: run_type [52251,52259]
name: run_type [54199,54207]
===
match
---
simple_stmt [16256,16303]
simple_stmt [16256,16303]
===
match
---
atom_expr [12057,12074]
atom_expr [12057,12074]
===
match
---
trailer [10337,10344]
trailer [10337,10344]
===
match
---
trailer [9337,9358]
trailer [9337,9358]
===
match
---
trailer [60713,60724]
trailer [62661,62672]
===
match
---
name: FAILED [50558,50564]
name: FAILED [50558,50564]
===
match
---
trailer [17538,17544]
trailer [17538,17544]
===
match
---
operator: , [48688,48689]
operator: , [48688,48689]
===
match
---
operator: { [47219,47220]
operator: { [47219,47220]
===
match
---
suite [44764,44812]
suite [44764,44812]
===
match
---
operator: = [17024,17025]
operator: = [17024,17025]
===
match
---
expr_stmt [21406,21451]
expr_stmt [21406,21451]
===
match
---
atom_expr [39618,39640]
atom_expr [39618,39640]
===
match
---
trailer [66367,66374]
trailer [68315,68322]
===
match
---
operator: , [63185,63186]
operator: , [65133,65134]
===
match
---
operator: >> [55255,55257]
operator: >> [57203,57205]
===
match
---
name: six_hours_ago_to_the_hour [56834,56859]
name: six_hours_ago_to_the_hour [58782,58807]
===
match
---
trailer [21143,21149]
trailer [21143,21149]
===
match
---
name: DagRun [2866,2872]
name: DagRun [2866,2872]
===
match
---
suite [3435,3464]
suite [3435,3464]
===
match
---
decorator [49803,49909]
decorator [49803,49909]
===
match
---
trailer [44642,44680]
trailer [44642,44680]
===
match
---
name: session [34194,34201]
name: session [34194,34201]
===
match
---
expr_stmt [35827,35860]
expr_stmt [35827,35860]
===
match
---
trailer [29065,29082]
trailer [29065,29082]
===
match
---
name: RUNNING [48478,48485]
name: RUNNING [48478,48485]
===
match
---
arglist [30075,30252]
arglist [30075,30252]
===
match
---
trailer [8211,8253]
trailer [8211,8253]
===
match
---
funcdef [67223,67271]
funcdef [69171,69219]
===
match
---
name: two_hours_ago [55528,55541]
name: two_hours_ago [57476,57489]
===
match
---
simple_stmt [43170,43202]
simple_stmt [43170,43202]
===
match
---
name: dag_id [31853,31859]
name: dag_id [31853,31859]
===
match
---
string: 'airflow' [5381,5390]
string: 'airflow' [5381,5390]
===
match
---
name: synchronize_session [2913,2932]
name: synchronize_session [2913,2932]
===
match
---
operator: } [12395,12396]
operator: } [12395,12396]
===
match
---
trailer [43358,43372]
trailer [43358,43372]
===
match
---
atom_expr [13997,14029]
atom_expr [13997,14029]
===
match
---
parameters [40890,40896]
parameters [40890,40896]
===
match
---
trailer [10076,10078]
trailer [10076,10078]
===
match
---
operator: = [28026,28027]
operator: = [28026,28027]
===
match
---
name: next_dagrun_after_date [59760,59782]
name: next_dagrun_after_date [61708,61730]
===
match
---
testlist_comp [18209,18228]
testlist_comp [18209,18228]
===
match
---
simple_stmt [44040,44086]
simple_stmt [44040,44086]
===
match
---
name: sync_to_db [45993,46003]
name: sync_to_db [45993,46003]
===
match
---
atom [26293,26325]
atom [26293,26325]
===
match
---
name: dag [11765,11768]
name: dag [11765,11768]
===
match
---
name: DummyOperator [15513,15526]
name: DummyOperator [15513,15526]
===
match
---
name: split [29199,29204]
name: split [29199,29204]
===
match
---
name: test_field [19915,19925]
name: test_field [19915,19925]
===
match
---
trailer [61073,61084]
trailer [63021,63032]
===
match
---
arglist [28608,28638]
arglist [28608,28638]
===
match
---
name: DEFAULT_DATE [30924,30936]
name: DEFAULT_DATE [30924,30936]
===
match
---
operator: , [64713,64714]
operator: , [66661,66662]
===
match
---
name: DummyOperator [8876,8889]
name: DummyOperator [8876,8889]
===
match
---
for_stmt [64307,64412]
for_stmt [66255,66360]
===
match
---
string: 'airflow' [54770,54779]
string: 'airflow' [56718,56727]
===
match
---
name: DummyOperator [16612,16625]
name: DummyOperator [16612,16625]
===
match
---
name: dag [55282,55285]
name: dag [57230,57233]
===
match
---
name: drs [47419,47422]
name: drs [47419,47422]
===
match
---
trailer [31281,31330]
trailer [31281,31330]
===
match
---
name: dag_id [39064,39070]
name: dag_id [39064,39070]
===
match
---
name: DEFAULT_DATE [28540,28552]
name: DEFAULT_DATE [28540,28552]
===
match
---
trailer [35411,35425]
trailer [35411,35425]
===
match
---
trailer [55814,55837]
trailer [57762,57785]
===
match
---
operator: = [47779,47780]
operator: = [47779,47780]
===
match
---
comparison [28408,28446]
comparison [28408,28446]
===
match
---
atom_expr [42599,42612]
atom_expr [42599,42612]
===
match
---
operator: , [46371,46372]
operator: , [46371,46372]
===
match
---
simple_stmt [19066,19107]
simple_stmt [19066,19107]
===
match
---
arglist [60558,60725]
arglist [62506,62673]
===
match
---
name: topological_list [8312,8328]
name: topological_list [8312,8328]
===
match
---
number: 2016 [59835,59839]
number: 2016 [61783,61787]
===
match
---
name: start_date [53798,53808]
name: start_date [55746,55756]
===
match
---
atom_expr [34375,34449]
atom_expr [34375,34449]
===
match
---
assert_stmt [17584,17666]
assert_stmt [17584,17666]
===
match
---
number: 1 [59597,59598]
number: 1 [61545,61546]
===
match
---
trailer [36066,36078]
trailer [36066,36078]
===
match
---
operator: - [16018,16019]
operator: - [16018,16019]
===
match
---
arglist [64362,64410]
arglist [66310,66358]
===
match
---
trailer [17911,17972]
trailer [17911,17972]
===
match
---
arglist [13032,13040]
arglist [13032,13040]
===
match
---
name: args [43892,43896]
name: args [43892,43896]
===
match
---
operator: , [31263,31264]
operator: , [31263,31264]
===
match
---
string: "start_date" [64756,64768]
string: "start_date" [66704,66716]
===
match
---
operator: , [50532,50533]
operator: , [50532,50533]
===
match
---
name: create_session [46183,46197]
name: create_session [46183,46197]
===
match
---
string: """         Test that when 'params' is _not_ passed to a new Dag, that the params         attribute is set to an empty dictionary.         """ [3563,3705]
string: """         Test that when 'params' is _not_ passed to a new Dag, that the params         attribute is set to an empty dictionary.         """ [3563,3705]
===
match
---
operator: = [37579,37580]
operator: = [37579,37580]
===
match
---
operator: , [39249,39250]
operator: , [39249,39250]
===
match
---
argument [12993,13015]
argument [12993,13015]
===
match
---
simple_stmt [24294,24443]
simple_stmt [24294,24443]
===
match
---
assert_stmt [29661,29713]
assert_stmt [29661,29713]
===
match
---
trailer [32729,32740]
trailer [32729,32740]
===
match
---
name: DEFAULT_ARGS [65629,65641]
name: DEFAULT_ARGS [67577,67589]
===
match
---
name: dag [52142,52145]
name: dag [54090,54093]
===
match
---
funcdef [68770,69277]
funcdef [70718,71225]
===
match
---
name: datetime [46645,46653]
name: datetime [46645,46653]
===
match
---
name: state [52297,52302]
name: state [54245,54250]
===
match
---
suite [5126,5392]
suite [5126,5392]
===
match
---
name: dags_needing_dagruns [63814,63834]
name: dags_needing_dagruns [65762,65782]
===
match
---
operator: = [53359,53360]
operator: = [55307,55308]
===
match
---
atom_expr [3759,3787]
atom_expr [3759,3787]
===
match
---
trailer [5613,5645]
trailer [5613,5645]
===
match
---
name: noop_pipeline [65655,65668]
name: noop_pipeline [67603,67616]
===
match
---
string: 'task' [50392,50398]
string: 'task' [50392,50398]
===
match
---
argument [32966,32994]
argument [32966,32994]
===
match
---
string: 'test_' [43393,43400]
string: 'test_' [43393,43400]
===
match
---
name: timezone [22524,22532]
name: timezone [22524,22532]
===
match
---
argument [47497,47525]
argument [47497,47525]
===
match
---
testlist_comp [51806,51835]
testlist_comp [53754,53783]
===
match
---
operator: , [10952,10953]
operator: , [10952,10953]
===
match
---
testlist_comp [14184,14419]
testlist_comp [14184,14419]
===
match
---
arglist [52251,52395]
arglist [54199,54343]
===
match
---
trailer [21759,21765]
trailer [21759,21765]
===
match
---
name: dag [45269,45272]
name: dag [45269,45272]
===
match
---
argument [10648,10680]
argument [10648,10680]
===
match
---
simple_stmt [49194,49211]
simple_stmt [49194,49211]
===
match
---
name: dr [67733,67735]
name: dr [69681,69683]
===
match
---
string: '.template' [19573,19584]
string: '.template' [19573,19584]
===
match
---
name: self [67673,67677]
name: self [69621,69625]
===
match
---
name: default_args [11813,11825]
name: default_args [11813,11825]
===
match
---
name: settings [62510,62518]
name: settings [64458,64466]
===
match
---
name: dag [28577,28580]
name: dag [28577,28580]
===
match
---
string: 'op2' [6179,6184]
string: 'op2' [6179,6184]
===
match
---
operator: == [7213,7215]
operator: == [7213,7215]
===
match
---
name: orm_dag [29251,29258]
name: orm_dag [29251,29258]
===
match
---
trailer [2739,2744]
trailer [2739,2744]
===
match
---
suite [64228,64624]
suite [66176,66572]
===
match
---
expr_stmt [55587,55789]
expr_stmt [57535,57737]
===
match
---
operator: , [65847,65848]
operator: , [67795,67796]
===
match
---
argument [5334,5367]
argument [5334,5367]
===
match
---
name: isoformat [20473,20482]
name: isoformat [20473,20482]
===
match
---
atom_expr [52037,52092]
atom_expr [53985,54040]
===
match
---
arith_expr [51715,51837]
arith_expr [53663,53785]
===
match
---
expr_stmt [9639,9671]
expr_stmt [9639,9671]
===
match
---
string: 'new_nonexisting_dag' [32943,32964]
string: 'new_nonexisting_dag' [32943,32964]
===
match
---
atom_expr [34427,34447]
atom_expr [34427,34447]
===
match
---
operator: = [16523,16524]
operator: = [16523,16524]
===
match
---
name: dag [57160,57163]
name: dag [59108,59111]
===
match
---
simple_stmt [47056,47072]
simple_stmt [47056,47072]
===
match
---
expr_stmt [21688,21721]
expr_stmt [21688,21721]
===
match
---
name: outdated_permissions [62186,62206]
name: outdated_permissions [64134,64154]
===
match
---
testlist_comp [42818,42829]
testlist_comp [42818,42829]
===
match
---
arglist [32309,32350]
arglist [32309,32350]
===
match
---
trailer [51754,51766]
trailer [53702,53714]
===
match
---
name: query [27041,27046]
name: query [27041,27046]
===
match
---
name: op4 [6685,6688]
name: op4 [6685,6688]
===
match
---
operator: = [59381,59382]
operator: = [61329,61330]
===
match
---
argument [14223,14246]
argument [14223,14246]
===
match
---
trailer [51811,51819]
trailer [53759,53767]
===
match
---
simple_stmt [2149,2198]
simple_stmt [2149,2198]
===
match
---
name: RUNNING [49882,49889]
name: RUNNING [49882,49889]
===
match
---
trailer [51621,51623]
trailer [51621,51623]
===
match
---
operator: { [29215,29216]
operator: { [29215,29216]
===
match
---
comparison [10297,10324]
comparison [10297,10324]
===
match
---
name: topological_list [9116,9132]
name: topological_list [9116,9132]
===
match
---
atom_expr [41253,41331]
atom_expr [41253,41331]
===
match
---
atom_expr [29024,29042]
atom_expr [29024,29042]
===
match
---
name: filter [31894,31900]
name: filter [31894,31900]
===
match
---
operator: = [53321,53322]
operator: = [55269,55270]
===
match
---
simple_stmt [10196,10229]
simple_stmt [10196,10229]
===
match
---
trailer [32602,32613]
trailer [32602,32613]
===
match
---
arglist [48682,48732]
arglist [48682,48732]
===
match
---
name: weight [15617,15623]
name: weight [15617,15623]
===
match
---
name: DAG [50227,50230]
name: DAG [50227,50230]
===
match
---
atom_expr [30363,30425]
atom_expr [30363,30425]
===
match
---
name: timezone [64770,64778]
name: timezone [66718,66726]
===
match
---
trailer [2912,2939]
trailer [2912,2939]
===
match
---
atom_expr [60424,60495]
atom_expr [62372,62443]
===
match
---
trailer [50439,50447]
trailer [50439,50447]
===
match
---
arglist [32235,32270]
arglist [32235,32270]
===
match
---
name: dag_id [46274,46280]
name: dag_id [46274,46280]
===
match
---
name: max_active_runs [50137,50152]
name: max_active_runs [50137,50152]
===
match
---
expr_stmt [67284,67312]
expr_stmt [69232,69260]
===
match
---
assert_stmt [63858,63881]
assert_stmt [65806,65829]
===
match
---
string: 'dag-bulk-sync-0' [25997,26014]
string: 'dag-bulk-sync-0' [25997,26014]
===
match
---
trailer [30423,30425]
trailer [30423,30425]
===
match
---
name: prev [23303,23307]
name: prev [23303,23307]
===
match
---
comparison [12157,12190]
comparison [12157,12190]
===
match
---
param [3183,3188]
param [3183,3188]
===
match
---
simple_stmt [36483,36499]
simple_stmt [36483,36499]
===
match
---
atom [48471,48487]
atom [48471,48487]
===
match
---
suite [12498,13783]
suite [12498,13783]
===
match
---
param [4520,4524]
param [4520,4524]
===
match
---
operator: == [49781,49783]
operator: == [49781,49783]
===
match
---
simple_stmt [66108,66166]
simple_stmt [68056,68114]
===
match
---
operator: = [23788,23789]
operator: = [23788,23789]
===
match
---
trailer [58386,58397]
trailer [60334,60345]
===
match
---
string: '{{ ds }}' [20135,20145]
string: '{{ ds }}' [20135,20145]
===
match
---
string: '2019-06-05' [10966,10978]
string: '2019-06-05' [10966,10978]
===
match
---
operator: == [2895,2897]
operator: == [2895,2897]
===
match
---
suite [2797,3136]
suite [2797,3136]
===
match
---
dictorsetmaker [44243,44289]
dictorsetmaker [44243,44289]
===
match
---
operator: = [4279,4280]
operator: = [4279,4280]
===
match
---
atom_expr [26722,26728]
atom_expr [26722,26728]
===
match
---
name: query [31838,31843]
name: query [31838,31843]
===
match
---
suite [30966,31027]
suite [30966,31027]
===
match
---
name: dateutil [1111,1119]
name: dateutil [1111,1119]
===
match
---
operator: = [44591,44592]
operator: = [44591,44592]
===
match
---
name: logging [10087,10094]
name: logging [10087,10094]
===
match
---
trailer [25164,25170]
trailer [25164,25170]
===
match
---
expr_stmt [43854,43883]
expr_stmt [43854,43883]
===
match
---
name: local_tz [22566,22574]
name: local_tz [22566,22574]
===
match
---
atom_expr [50431,50449]
atom_expr [50431,50449]
===
match
---
trailer [62066,62081]
trailer [64014,64029]
===
match
---
atom_expr [59678,59734]
atom_expr [61626,61682]
===
match
---
arglist [8135,8176]
arglist [8135,8176]
===
match
---
atom_expr [55594,55789]
atom_expr [57542,57737]
===
match
---
simple_stmt [10504,10538]
simple_stmt [10504,10538]
===
match
---
fstring [47213,47223]
fstring [47213,47223]
===
match
---
operator: = [6189,6190]
operator: = [6189,6190]
===
match
---
name: RUNNING [39664,39671]
name: RUNNING [39664,39671]
===
match
---
operator: = [56580,56581]
operator: = [58528,58529]
===
match
---
atom_expr [38822,38856]
atom_expr [38822,38856]
===
match
---
name: test_dag_id [44566,44577]
name: test_dag_id [44566,44577]
===
match
---
name: session [49457,49464]
name: session [49457,49464]
===
match
---
name: dr [48220,48222]
name: dr [48220,48222]
===
match
---
name: start_date [52330,52340]
name: start_date [54278,54288]
===
match
---
name: Session [62519,62526]
name: Session [64467,64474]
===
match
---
number: 3 [47172,47173]
number: 3 [47172,47173]
===
match
---
name: DEFAULT_DATE [67678,67690]
name: DEFAULT_DATE [69626,69638]
===
match
---
name: next_dagrun_after_date [57411,57433]
name: next_dagrun_after_date [59359,59381]
===
match
---
name: unpaused_dags [31680,31693]
name: unpaused_dags [31680,31693]
===
match
---
simple_stmt [29551,29617]
simple_stmt [29551,29617]
===
match
---
name: paused_dag_ids [46142,46156]
name: paused_dag_ids [46142,46156]
===
match
---
name: parent_dag [61074,61084]
name: parent_dag [63022,63032]
===
match
---
name: object [34116,34122]
name: object [34116,34122]
===
match
---
operator: = [16834,16835]
operator: = [16834,16835]
===
match
---
operator: - [3305,3306]
operator: - [3305,3306]
===
match
---
arglist [44309,44339]
arglist [44309,44339]
===
match
---
trailer [61927,61933]
trailer [63875,63881]
===
match
---
simple_stmt [21775,21836]
simple_stmt [21775,21836]
===
match
---
name: task [19310,19314]
name: task [19310,19314]
===
match
---
name: schedule_interval [54918,54935]
name: schedule_interval [56866,56883]
===
match
---
name: schedule_interval [22745,22762]
name: schedule_interval [22745,22762]
===
match
---
name: next_date [58680,58689]
name: next_date [60628,60637]
===
match
---
arglist [52041,52091]
arglist [53989,54039]
===
match
---
simple_stmt [41858,41936]
simple_stmt [41858,41936]
===
match
---
name: timezone [34814,34822]
name: timezone [34814,34822]
===
match
---
suite [13245,13361]
suite [13245,13361]
===
match
---
atom_expr [44359,44394]
atom_expr [44359,44394]
===
match
---
parameters [13842,13848]
parameters [13842,13848]
===
match
---
atom_expr [4725,4795]
atom_expr [4725,4795]
===
match
---
trailer [65379,65382]
trailer [67327,67330]
===
match
---
name: start_date [59562,59572]
name: start_date [61510,61520]
===
match
---
param [19526,19530]
param [19526,19530]
===
match
---
operator: } [61701,61702]
operator: } [63649,63650]
===
match
---
expr_stmt [40023,40070]
expr_stmt [40023,40070]
===
match
---
atom_expr [39658,39671]
atom_expr [39658,39671]
===
match
---
comparison [23325,23378]
comparison [23325,23378]
===
match
---
arglist [20620,20679]
arglist [20620,20679]
===
match
---
atom_expr [18360,18372]
atom_expr [18360,18372]
===
match
---
operator: = [60703,60704]
operator: = [62651,62652]
===
match
---
operator: != [39471,39473]
operator: != [39471,39473]
===
match
---
name: dag [6216,6219]
name: dag [6216,6219]
===
match
---
trailer [25202,25204]
trailer [25202,25204]
===
match
---
operator: = [50098,50099]
operator: = [50098,50099]
===
match
---
operator: == [63876,63878]
operator: == [65824,65826]
===
match
---
atom [20042,20056]
atom [20042,20056]
===
match
---
name: filter [46248,46254]
name: filter [46248,46254]
===
match
---
operator: >> [55248,55250]
operator: >> [57196,57198]
===
match
---
name: dag_run [40491,40498]
name: dag_run [40491,40498]
===
match
---
number: 2 [60404,60405]
number: 2 [62352,62353]
===
match
---
name: next_date [56686,56695]
name: next_date [58634,58643]
===
match
---
comparison [24938,25205]
comparison [24938,25205]
===
match
---
suite [56988,57713]
suite [58936,59661]
===
match
---
name: session [51101,51108]
name: session [51101,51108]
===
match
---
trailer [25889,25893]
trailer [25889,25893]
===
match
---
simple_stmt [15918,15927]
simple_stmt [15918,15927]
===
match
---
simple_stmt [6205,6227]
simple_stmt [6205,6227]
===
match
---
name: self [3891,3895]
name: self [3891,3895]
===
match
---
assert_stmt [38084,38101]
assert_stmt [38084,38101]
===
match
---
name: models [5323,5329]
name: models [5323,5329]
===
match
---
operator: = [46308,46309]
operator: = [46308,46309]
===
match
---
name: dag [50201,50204]
name: dag [50201,50204]
===
match
---
atom_expr [29251,29268]
atom_expr [29251,29268]
===
match
---
name: previous_schedule [21081,21098]
name: previous_schedule [21081,21098]
===
match
---
trailer [43213,43222]
trailer [43213,43222]
===
match
---
argument [19566,19584]
argument [19566,19584]
===
match
---
operator: { [11979,11980]
operator: { [11979,11980]
===
match
---
simple_stmt [50901,50925]
simple_stmt [50901,50925]
===
match
---
trailer [34185,34202]
trailer [34185,34202]
===
match
---
trailer [51981,51991]
trailer [53929,53939]
===
match
---
name: len [3808,3811]
name: len [3808,3811]
===
match
---
trailer [34895,34924]
trailer [34895,34924]
===
match
---
name: dr [47836,47838]
name: dr [47836,47838]
===
match
---
fstring_end: ' [15574,15575]
fstring_end: ' [15574,15575]
===
match
---
comparison [55938,55966]
comparison [57886,57914]
===
match
---
name: DagRun [51531,51537]
name: DagRun [51531,51537]
===
match
---
operator: == [13168,13170]
operator: == [13168,13170]
===
match
---
operator: = [57405,57406]
operator: = [59353,59354]
===
match
---
atom_expr [7544,7576]
atom_expr [7544,7576]
===
match
---
suite [62285,63934]
suite [64233,65882]
===
match
---
simple_stmt [53883,53928]
simple_stmt [55831,55876]
===
match
---
operator: = [39113,39114]
operator: = [39113,39114]
===
match
---
name: local_tz [22504,22512]
name: local_tz [22504,22512]
===
match
---
name: template_searchpath [19166,19185]
name: template_searchpath [19166,19185]
===
match
---
operator: , [31440,31441]
operator: , [31440,31441]
===
match
---
name: default_args [11614,11626]
name: default_args [11614,11626]
===
match
---
trailer [13506,13509]
trailer [13506,13509]
===
match
---
operator: } [9525,9526]
operator: } [9525,9526]
===
match
---
operator: == [6695,6697]
operator: == [6695,6697]
===
match
---
name: DEFAULT_DATE [30714,30726]
name: DEFAULT_DATE [30714,30726]
===
match
---
atom_expr [33575,33590]
atom_expr [33575,33590]
===
match
---
operator: = [23613,23614]
operator: = [23613,23614]
===
match
---
operator: , [28552,28553]
operator: , [28552,28553]
===
match
---
operator: == [43638,43640]
operator: == [43638,43640]
===
match
---
atom_expr [38117,38130]
atom_expr [38117,38130]
===
match
---
name: DEFAULT_ARGS [68923,68935]
name: DEFAULT_ARGS [70871,70883]
===
match
---
operator: , [32250,32251]
operator: , [32250,32251]
===
match
---
name: dag_id [46043,46049]
name: dag_id [46043,46049]
===
match
---
simple_stmt [17413,17442]
simple_stmt [17413,17442]
===
match
---
name: convert [23071,23078]
name: convert [23071,23078]
===
match
---
expr_stmt [17039,17121]
expr_stmt [17039,17121]
===
match
---
operator: = [17168,17169]
operator: = [17168,17169]
===
match
---
name: settings [52166,52174]
name: settings [54114,54122]
===
match
---
name: subdag [61099,61105]
name: subdag [63047,63053]
===
match
---
assert_stmt [61313,61406]
assert_stmt [63261,63354]
===
match
---
assert_stmt [46014,46062]
assert_stmt [46014,46062]
===
match
---
operator: , [59234,59235]
operator: , [61182,61183]
===
match
---
testlist_comp [26195,26225]
testlist_comp [26195,26225]
===
match
---
simple_stmt [39980,40015]
simple_stmt [39980,40015]
===
match
---
trailer [40801,40803]
trailer [40801,40803]
===
match
---
number: 1 [60722,60723]
number: 1 [62670,62671]
===
match
---
trailer [33519,33521]
trailer [33519,33521]
===
match
---
simple_stmt [2718,2747]
simple_stmt [2718,2747]
===
match
---
simple_stmt [68187,68216]
simple_stmt [70135,70164]
===
match
---
name: dag_id [25178,25184]
name: dag_id [25178,25184]
===
match
---
simple_stmt [33421,33493]
simple_stmt [33421,33493]
===
match
---
funcdef [36723,37232]
funcdef [36723,37232]
===
match
---
name: query [27731,27736]
name: query [27731,27736]
===
match
---
trailer [41959,41967]
trailer [41959,41967]
===
match
---
name: patch [39790,39795]
name: patch [39790,39795]
===
match
---
simple_stmt [57395,57440]
simple_stmt [59343,59388]
===
match
---
trailer [63365,63372]
trailer [65313,65320]
===
match
---
name: DAG [24142,24145]
name: DAG [24142,24145]
===
match
---
name: op2 [35536,35539]
name: op2 [35536,35539]
===
match
---
comp_op [39441,39447]
comp_op [39441,39447]
===
match
---
arglist [56516,56666]
arglist [58464,58614]
===
match
---
operator: , [2564,2565]
operator: , [2564,2565]
===
match
---
dotted_name [1111,1133]
dotted_name [1111,1133]
===
match
---
simple_stmt [23854,23896]
simple_stmt [23854,23896]
===
match
---
suite [61954,62048]
suite [63902,63996]
===
match
---
trailer [34526,34530]
trailer [34526,34530]
===
match
---
operator: = [13957,13958]
operator: = [13957,13958]
===
match
---
string: "dag.callback_exceptions" [40756,40781]
string: "dag.callback_exceptions" [40756,40781]
===
match
---
operator: = [40169,40170]
operator: = [40169,40170]
===
match
---
operator: , [58133,58134]
operator: , [60081,60082]
===
match
---
name: session [29066,29073]
name: session [29066,29073]
===
match
---
comparison [63705,63724]
comparison [65653,65672]
===
match
---
simple_stmt [44971,44992]
simple_stmt [44971,44992]
===
match
---
arglist [31499,31540]
arglist [31499,31540]
===
match
---
atom_expr [6446,6455]
atom_expr [6446,6455]
===
match
---
atom_expr [28027,28044]
atom_expr [28027,28044]
===
match
---
name: test_dag_id [16724,16735]
name: test_dag_id [16724,16735]
===
match
---
name: dag_run_state [51343,51356]
name: dag_run_state [51343,51356]
===
match
---
name: ti1 [17014,17017]
name: ti1 [17014,17017]
===
match
---
name: airflow [1522,1529]
name: airflow [1522,1529]
===
match
---
name: dag3 [56487,56491]
name: dag3 [58435,58439]
===
match
---
name: self [68025,68029]
name: self [69973,69977]
===
match
---
trailer [56263,56269]
trailer [58211,58217]
===
match
---
name: dump [45302,45306]
name: dump [45302,45306]
===
match
---
atom_expr [38657,38703]
atom_expr [38657,38703]
===
match
---
trailer [22690,22697]
trailer [22690,22697]
===
match
---
atom_expr [22005,22027]
atom_expr [22005,22027]
===
match
---
operator: @ [68996,68997]
operator: @ [70944,70945]
===
match
---
trailer [2523,2540]
trailer [2523,2540]
===
match
---
trailer [51114,51131]
trailer [51114,51131]
===
match
---
simple_stmt [54849,55066]
simple_stmt [56797,57014]
===
match
---
string: 'test' [65199,65205]
string: 'test' [67147,67153]
===
match
---
name: i [14561,14562]
name: i [14561,14562]
===
match
---
name: task_instance_2 [51017,51032]
name: task_instance_2 [51017,51032]
===
match
---
atom [61837,61895]
atom [63785,63843]
===
match
---
operator: , [49266,49267]
operator: , [49266,49267]
===
match
---
assert_stmt [17675,17759]
assert_stmt [17675,17759]
===
match
---
name: end_date [53832,53840]
name: end_date [55780,55788]
===
match
---
name: DAG [53942,53945]
name: DAG [55890,55893]
===
match
---
name: topological_list [9252,9268]
name: topological_list [9252,9268]
===
match
---
operator: } [24318,24319]
operator: } [24318,24319]
===
match
---
trailer [35503,35517]
trailer [35503,35517]
===
match
---
trailer [31937,31958]
trailer [31937,31958]
===
match
---
atom_expr [51806,51819]
atom_expr [53754,53767]
===
match
---
name: days [17238,17242]
name: days [17238,17242]
===
match
---
expr_stmt [30275,30303]
expr_stmt [30275,30303]
===
match
---
name: set [26344,26347]
name: set [26344,26347]
===
match
---
simple_stmt [18120,18257]
simple_stmt [18120,18257]
===
match
---
parameters [64044,64050]
parameters [65992,65998]
===
match
---
atom_expr [19361,19378]
atom_expr [19361,19378]
===
match
---
arith_expr [13612,13636]
arith_expr [13612,13636]
===
match
---
decorated [48399,49798]
decorated [48399,49798]
===
match
---
name: dag_decorator [65185,65198]
name: dag_decorator [67133,67146]
===
match
---
name: test_dag_task_priority_weight_total_using_absolute [15171,15221]
name: test_dag_task_priority_weight_total_using_absolute [15171,15221]
===
match
---
name: query [2860,2865]
name: query [2860,2865]
===
match
---
name: op1 [6242,6245]
name: op1 [6242,6245]
===
match
---
name: self [53194,53198]
name: self [55142,55146]
===
match
---
trailer [61298,61304]
trailer [63246,63252]
===
match
---
arglist [53441,53451]
arglist [55389,55399]
===
match
---
name: DagModel [33106,33114]
name: DagModel [33106,33114]
===
match
---
operator: , [27478,27479]
operator: , [27478,27479]
===
match
---
name: test_dag_id [17807,17818]
name: test_dag_id [17807,17818]
===
match
---
argument [43546,43568]
argument [43546,43568]
===
match
---
name: session [17964,17971]
name: session [17964,17971]
===
match
---
expr_stmt [20733,20769]
expr_stmt [20733,20769]
===
match
---
name: dag_fileloc [33869,33880]
name: dag_fileloc [33869,33880]
===
match
---
simple_stmt [68306,68330]
simple_stmt [70254,70278]
===
match
---
trailer [12967,13016]
trailer [12967,13016]
===
match
---
suite [11940,12191]
suite [11940,12191]
===
match
---
simple_stmt [14988,15039]
simple_stmt [14988,15039]
===
match
---
string: 'dag-bulk-sync-2' [26663,26680]
string: 'dag-bulk-sync-2' [26663,26680]
===
match
---
trailer [34089,34091]
trailer [34089,34091]
===
match
---
trailer [49694,49703]
trailer [49694,49703]
===
match
---
atom [43899,43947]
atom [43899,43947]
===
match
---
fstring_end: ' [24544,24545]
fstring_end: ' [24544,24545]
===
match
---
name: dag [63362,63365]
name: dag [65310,65313]
===
match
---
name: create_session [2811,2825]
name: create_session [2811,2825]
===
match
---
parameters [68797,68803]
parameters [70745,70751]
===
match
---
string: 'B' [8808,8811]
string: 'B' [8808,8811]
===
match
---
name: session [52825,52832]
name: session [54773,54780]
===
match
---
trailer [2555,2590]
trailer [2555,2590]
===
match
---
atom [46429,46453]
atom [46429,46453]
===
match
---
name: dag [58477,58480]
name: dag [60425,60428]
===
match
---
name: convert [21752,21759]
name: convert [21752,21759]
===
match
---
string: """         Tests following_schedule a dag with a relativedelta schedule_interval         """ [23504,23597]
string: """         Tests following_schedule a dag with a relativedelta schedule_interval         """ [23504,23597]
===
match
---
string: 'role1' [61747,61754]
string: 'role1' [63695,63702]
===
match
---
name: task_depth [13478,13488]
name: task_depth [13478,13488]
===
match
---
name: name [26384,26388]
name: name [26384,26388]
===
match
---
name: RUNNING [18380,18387]
name: RUNNING [18380,18387]
===
match
---
funcdef [41973,42959]
funcdef [41973,42959]
===
match
---
trailer [63166,63211]
trailer [65114,65159]
===
match
---
name: child_dag [7322,7331]
name: child_dag [7322,7331]
===
match
---
arglist [5921,5985]
arglist [5921,5985]
===
match
---
name: dag_run_state [49962,49975]
name: dag_run_state [49962,49975]
===
match
---
trailer [13399,13406]
trailer [13399,13406]
===
match
---
operator: == [5062,5064]
operator: == [5062,5064]
===
match
---
name: convert [20755,20762]
name: convert [20755,20762]
===
match
---
number: 1 [9269,9270]
number: 1 [9269,9270]
===
match
---
name: bulk_write_to_db [24668,24684]
name: bulk_write_to_db [24668,24684]
===
match
---
name: op3 [55189,55192]
name: op3 [57137,57140]
===
match
---
name: op2 [37669,37672]
name: op2 [37669,37672]
===
match
---
parameters [7306,7312]
parameters [7306,7312]
===
match
---
trailer [34174,34185]
trailer [34174,34185]
===
match
---
name: one [34280,34283]
name: one [34280,34283]
===
match
---
if_stmt [3358,3405]
if_stmt [3358,3405]
===
match
---
trailer [66278,66281]
trailer [68226,68229]
===
match
---
fstring_string: stage [12978,12983]
fstring_string: stage [12978,12983]
===
match
---
operator: = [24518,24519]
operator: = [24518,24519]
===
match
---
comparison [55982,56011]
comparison [57930,57959]
===
match
---
string: '*/5 * * * *' [20666,20679]
string: '*/5 * * * *' [20666,20679]
===
match
---
simple_stmt [58348,58398]
simple_stmt [60296,60346]
===
match
---
arglist [5614,5644]
arglist [5614,5644]
===
match
---
name: unittest [870,878]
name: unittest [870,878]
===
match
---
name: dagrun [51477,51483]
name: dagrun [51477,51483]
===
match
---
name: dag_id [31242,31248]
name: dag_id [31242,31248]
===
match
---
simple_stmt [51943,51969]
simple_stmt [53891,53917]
===
match
---
with_stmt [24699,25320]
with_stmt [24699,25320]
===
match
---
trailer [23335,23345]
trailer [23335,23345]
===
match
---
name: start_date [30703,30713]
name: start_date [30703,30713]
===
match
---
name: f [19046,19047]
name: f [19046,19047]
===
match
---
name: owner [41288,41293]
name: owner [41288,41293]
===
match
---
name: op5 [6655,6658]
name: op5 [6655,6658]
===
match
---
name: num [67238,67241]
name: num [69186,69189]
===
match
---
name: dag [62576,62579]
name: dag [64524,64527]
===
match
---
name: dag [64407,64410]
name: dag [66355,66358]
===
match
---
with_stmt [16470,16672]
with_stmt [16470,16672]
===
match
---
atom [25947,25978]
atom [25947,25978]
===
match
---
trailer [21716,21721]
trailer [21716,21721]
===
match
---
operator: = [15318,15319]
operator: = [15318,15319]
===
match
---
name: test_task_id [18047,18059]
name: test_task_id [18047,18059]
===
match
---
operator: , [52316,52317]
operator: , [54264,54265]
===
match
---
funcdef [16367,16672]
funcdef [16367,16672]
===
match
---
name: state [48299,48304]
name: state [48299,48304]
===
match
---
trailer [34081,34089]
trailer [34081,34089]
===
match
---
assert_stmt [61185,61240]
assert_stmt [63133,63188]
===
match
---
name: RUNNING [18076,18083]
name: RUNNING [18076,18083]
===
match
---
operator: , [15680,15681]
operator: , [15680,15681]
===
match
---
name: utils [1956,1961]
name: utils [1956,1961]
===
match
---
name: State [18215,18220]
name: State [18215,18220]
===
match
---
name: op8 [7205,7208]
name: op8 [7205,7208]
===
match
---
operator: , [35053,35054]
operator: , [35053,35054]
===
match
---
operator: = [5340,5341]
operator: = [5340,5341]
===
match
---
operator: , [11964,11965]
operator: , [11964,11965]
===
match
---
name: dag_id [52924,52930]
name: dag_id [54872,54878]
===
match
---
simple_stmt [24931,25206]
simple_stmt [24931,25206]
===
match
---
argument [12870,12902]
argument [12870,12902]
===
match
---
name: BACKFILL_JOB [50520,50532]
name: BACKFILL_JOB [50520,50532]
===
match
---
string: 'start_date' [12377,12389]
string: 'start_date' [12377,12389]
===
match
---
testlist_comp [26829,26859]
testlist_comp [26829,26859]
===
match
---
number: 2020 [56896,56900]
number: 2020 [58844,58848]
===
match
---
operator: @ [66179,66180]
operator: @ [68127,68128]
===
match
---
name: isoformat [43414,43423]
name: isoformat [43414,43423]
===
match
---
name: catchup [56652,56659]
name: catchup [58600,58607]
===
match
---
atom_expr [57683,57712]
atom_expr [59631,59660]
===
match
---
comparison [63865,63881]
comparison [65813,65829]
===
match
---
expr_stmt [43137,43161]
expr_stmt [43137,43161]
===
match
---
parameters [53597,53603]
parameters [55545,55551]
===
match
---
atom_expr [54281,54299]
atom_expr [56229,56247]
===
match
---
trailer [32317,32324]
trailer [32317,32324]
===
match
---
operator: == [6732,6734]
operator: == [6732,6734]
===
match
---
arglist [67662,67718]
arglist [69610,69666]
===
match
---
number: 1 [57345,57346]
number: 1 [59293,59294]
===
match
---
name: timezone [62395,62403]
name: timezone [64343,64351]
===
match
---
name: session [62500,62507]
name: session [64448,64455]
===
match
---
argument [31768,31791]
argument [31768,31791]
===
match
---
number: 1 [40289,40290]
number: 1 [40289,40290]
===
match
---
name: task_id [59692,59699]
name: task_id [61640,61647]
===
match
---
name: decorators [1319,1329]
name: decorators [1319,1329]
===
match
---
operator: = [7826,7827]
operator: = [7826,7827]
===
match
---
atom_expr [7499,7531]
atom_expr [7499,7531]
===
match
---
operator: = [28659,28660]
operator: = [28659,28660]
===
match
---
funcdef [65651,65787]
funcdef [67599,67735]
===
match
---
name: str [2792,2795]
name: str [2792,2795]
===
match
---
assert_stmt [62056,62104]
assert_stmt [64004,64052]
===
match
---
trailer [39206,39331]
trailer [39206,39331]
===
match
---
name: dict [3782,3786]
name: dict [3782,3786]
===
match
---
trailer [55558,55568]
trailer [57506,57516]
===
match
---
comparison [20786,20834]
comparison [20786,20834]
===
match
---
argument [54084,54101]
argument [56032,56049]
===
match
---
param [65323,65326]
param [67271,67274]
===
match
---
name: op7 [7175,7178]
name: op7 [7175,7178]
===
match
---
name: start_date [12845,12855]
name: start_date [12845,12855]
===
match
---
name: models [4725,4731]
name: models [4725,4731]
===
match
---
name: path [19677,19681]
name: path [19677,19681]
===
match
---
param [46732,46737]
param [46732,46737]
===
match
---
name: op2 [36396,36399]
name: op2 [36396,36399]
===
match
---
trailer [8844,8857]
trailer [8844,8857]
===
match
---
number: 0 [9133,9134]
number: 0 [9133,9134]
===
match
---
atom_expr [48165,48211]
atom_expr [48165,48211]
===
match
---
operator: = [18594,18595]
operator: = [18594,18595]
===
match
---
name: test_following_previous_schedule [20171,20203]
name: test_following_previous_schedule [20171,20203]
===
match
---
name: group [13501,13506]
name: group [13501,13506]
===
match
---
operator: == [46271,46273]
operator: == [46271,46273]
===
match
---
assert_stmt [66391,66445]
assert_stmt [68339,68393]
===
match
---
funcdef [48087,48394]
funcdef [48087,48394]
===
match
---
trailer [35365,35379]
trailer [35365,35379]
===
match
---
expr_stmt [61132,61176]
expr_stmt [63080,63124]
===
match
---
argument [47278,47294]
argument [47278,47294]
===
match
---
operator: , [62463,62464]
operator: , [64411,64412]
===
match
---
trailer [47069,47071]
trailer [47069,47071]
===
match
---
name: test_user_defined_filters [18449,18474]
name: test_user_defined_filters [18449,18474]
===
match
---
name: session [27697,27704]
name: session [27697,27704]
===
match
---
name: utils [2162,2167]
name: utils [2162,2167]
===
match
---
argument [59718,59733]
argument [61666,61681]
===
match
---
simple_stmt [12562,12605]
simple_stmt [12562,12605]
===
match
---
name: test_sync_to_db [28456,28471]
name: test_sync_to_db [28456,28471]
===
match
---
name: BashOperator [37102,37114]
name: BashOperator [37102,37114]
===
match
---
trailer [8918,8931]
trailer [8918,8931]
===
match
---
trailer [18379,18387]
trailer [18379,18387]
===
match
---
trailer [36316,36330]
trailer [36316,36330]
===
match
---
name: RUNNING [68541,68548]
name: RUNNING [70489,70496]
===
match
---
return_stmt [67260,67270]
return_stmt [69208,69218]
===
match
---
atom_expr [8741,8767]
atom_expr [8741,8767]
===
match
---
name: DAG [25413,25416]
name: DAG [25413,25416]
===
match
---
name: orm_dag [34212,34219]
name: orm_dag [34212,34219]
===
match
---
expr_stmt [21564,21600]
expr_stmt [21564,21600]
===
match
---
operator: = [52128,52129]
operator: = [54076,54077]
===
match
---
name: parent_dag [31144,31154]
name: parent_dag [31144,31154]
===
match
---
decorator [67195,67211]
decorator [69143,69159]
===
match
---
name: dr [47535,47537]
name: dr [47535,47537]
===
match
---
atom_expr [34552,34569]
atom_expr [34552,34569]
===
match
---
string: 'section-1' [60808,60819]
string: 'section-1' [62756,62767]
===
match
---
name: DAG [20616,20619]
name: DAG [20616,20619]
===
match
---
operator: >> [38546,38548]
operator: >> [38546,38548]
===
match
---
name: self [39761,39765]
name: self [39761,39765]
===
match
---
assert_stmt [37189,37231]
assert_stmt [37189,37231]
===
match
---
number: 5 [12515,12516]
number: 5 [12515,12516]
===
match
---
testlist_comp [48445,48456]
testlist_comp [48445,48456]
===
match
---
param [16709,16713]
param [16709,16713]
===
match
---
number: 0 [13032,13033]
number: 0 [13032,13033]
===
match
---
operator: , [50986,50987]
operator: , [50986,50987]
===
match
---
operator: = [6155,6156]
operator: = [6155,6156]
===
match
---
argument [51228,51251]
argument [51228,51251]
===
match
---
name: self [33818,33822]
name: self [33818,33822]
===
match
---
trailer [33646,33659]
trailer [33646,33659]
===
match
---
name: op1 [38091,38094]
name: op1 [38091,38094]
===
match
---
simple_stmt [2519,2591]
simple_stmt [2519,2591]
===
match
---
name: datetime [58552,58560]
name: datetime [60500,60508]
===
match
---
operator: = [19028,19029]
operator: = [19028,19029]
===
match
---
operator: = [68695,68696]
operator: = [70643,70644]
===
match
---
string: 'stage(\\d*).(\\d*)' [12583,12603]
string: 'stage(\\d*).(\\d*)' [12583,12603]
===
match
---
atom_expr [49038,49061]
atom_expr [49038,49061]
===
match
---
name: hash [45832,45836]
name: hash [45832,45836]
===
match
---
arglist [9462,9526]
arglist [9462,9526]
===
match
---
simple_stmt [17584,17667]
simple_stmt [17584,17667]
===
match
---
name: default_args [11735,11747]
name: default_args [11735,11747]
===
match
---
simple_stmt [25490,25517]
simple_stmt [25490,25517]
===
match
---
trailer [31481,31554]
trailer [31481,31554]
===
match
---
name: self [67793,67797]
name: self [69741,69745]
===
match
---
simple_stmt [35438,35472]
simple_stmt [35438,35472]
===
match
---
number: 6 [55387,55388]
number: 6 [57335,57336]
===
match
---
name: local_tz [22189,22197]
name: local_tz [22189,22197]
===
match
---
trailer [14794,14801]
trailer [14794,14801]
===
match
---
trailer [53753,53763]
trailer [55701,55711]
===
match
---
simple_stmt [66914,66972]
simple_stmt [68862,68920]
===
match
---
trailer [8972,8977]
trailer [8972,8977]
===
match
---
atom_expr [29503,29518]
atom_expr [29503,29518]
===
match
---
name: self [4520,4524]
name: self [4520,4524]
===
match
---
name: dag [37590,37593]
name: dag [37590,37593]
===
match
---
operator: = [7085,7086]
operator: = [7085,7086]
===
match
---
with_stmt [25371,25440]
with_stmt [25371,25440]
===
match
---
operator: , [58136,58137]
operator: , [60084,60085]
===
match
---
assert_stmt [3796,3823]
assert_stmt [3796,3823]
===
match
---
name: start_date [15383,15393]
name: start_date [15383,15393]
===
match
---
expr_stmt [53209,53339]
expr_stmt [55157,55287]
===
match
---
name: prev_local [20955,20965]
name: prev_local [20955,20965]
===
match
---
name: set_downstream [9904,9918]
name: set_downstream [9904,9918]
===
match
---
string: 'dag_orientation' [5627,5644]
string: 'dag_orientation' [5627,5644]
===
match
---
simple_stmt [66291,66313]
simple_stmt [68239,68261]
===
match
---
string: 'tag-2' [24311,24318]
string: 'tag-2' [24311,24318]
===
match
---
operator: , [7413,7414]
operator: , [7413,7414]
===
match
---
with_item [14043,14119]
with_item [14043,14119]
===
match
---
string: '.template' [18929,18940]
string: '.template' [18929,18940]
===
match
---
name: list_py_file_paths [1924,1942]
name: list_py_file_paths [1924,1942]
===
match
---
simple_stmt [16048,16085]
simple_stmt [16048,16085]
===
match
---
name: DagModel [26754,26762]
name: DagModel [26754,26762]
===
match
---
name: session [18094,18101]
name: session [18094,18101]
===
match
---
trailer [9026,9028]
trailer [9026,9028]
===
match
---
operator: , [18582,18583]
operator: , [18582,18583]
===
match
---
atom_expr [67479,67502]
atom_expr [69427,69450]
===
match
---
name: params1 [4202,4209]
name: params1 [4202,4209]
===
match
---
expr_stmt [40140,40363]
expr_stmt [40140,40363]
===
match
---
trailer [38446,38460]
trailer [38446,38460]
===
match
---
comparison [62943,62959]
comparison [64891,64907]
===
match
---
suite [46211,46316]
suite [46211,46316]
===
match
---
atom_expr [37102,37152]
atom_expr [37102,37152]
===
match
---
dotted_name [51685,51705]
dotted_name [53633,53653]
===
match
---
simple_stmt [29173,29236]
simple_stmt [29173,29236]
===
match
---
operator: = [65623,65624]
operator: = [67571,67572]
===
match
---
operator: = [34041,34042]
operator: = [34041,34042]
===
match
---
operator: , [58568,58569]
operator: , [60516,60517]
===
match
---
arglist [49548,49555]
arglist [49548,49555]
===
match
---
expr_stmt [55079,55121]
expr_stmt [57027,57069]
===
match
---
trailer [29485,29495]
trailer [29485,29495]
===
match
---
atom_expr [7599,7716]
atom_expr [7599,7716]
===
match
---
name: self [36117,36121]
name: self [36117,36121]
===
match
---
operator: = [17963,17964]
operator: = [17963,17964]
===
match
---
comparison [11731,11793]
comparison [11731,11793]
===
match
---
trailer [34252,34279]
trailer [34252,34279]
===
match
---
operator: = [3460,3461]
operator: = [3460,3461]
===
match
---
funcdef [64032,64084]
funcdef [65980,66032]
===
match
---
name: DEFAULT_DATE [18595,18607]
name: DEFAULT_DATE [18595,18607]
===
match
---
name: ti2 [17130,17133]
name: ti2 [17130,17133]
===
match
---
operator: = [8043,8044]
operator: = [8043,8044]
===
match
---
atom_expr [47255,47295]
atom_expr [47255,47295]
===
match
---
name: AirflowException [4636,4652]
name: AirflowException [4636,4652]
===
match
---
expr_stmt [58465,58514]
expr_stmt [60413,60462]
===
match
---
simple_stmt [36644,36675]
simple_stmt [36644,36675]
===
match
---
atom [19928,19958]
atom [19928,19958]
===
match
---
string: 'A' [9667,9670]
string: 'A' [9667,9670]
===
match
---
expr_stmt [13951,13960]
expr_stmt [13951,13960]
===
match
---
testlist_comp [31254,31271]
testlist_comp [31254,31271]
===
match
---
assert_stmt [6917,6953]
assert_stmt [6917,6953]
===
match
---
assert_stmt [46958,47007]
assert_stmt [46958,47007]
===
match
---
expr_stmt [16952,17005]
expr_stmt [16952,17005]
===
match
---
operator: == [46918,46920]
operator: == [46918,46920]
===
match
---
trailer [42950,42958]
trailer [42950,42958]
===
match
---
operator: { [47671,47672]
operator: { [47671,47672]
===
match
---
arglist [59591,59612]
arglist [61539,61560]
===
match
---
operator: , [62613,62614]
operator: , [64561,64562]
===
match
---
operator: = [6368,6369]
operator: = [6368,6369]
===
match
---
operator: = [33485,33486]
operator: = [33485,33486]
===
match
---
argument [39263,39287]
argument [39263,39287]
===
match
---
name: dag [10606,10609]
name: dag [10606,10609]
===
match
---
name: NONE [48028,48032]
name: NONE [48028,48032]
===
match
---
operator: , [62768,62769]
operator: , [64716,64717]
===
match
---
argument [55113,55120]
argument [57061,57068]
===
match
---
argument [41307,41330]
argument [41307,41330]
===
match
---
name: dag [39047,39050]
name: dag [39047,39050]
===
match
---
atom_expr [22189,22211]
atom_expr [22189,22211]
===
match
---
arglist [34945,34977]
arglist [34945,34977]
===
match
---
name: next_date [55982,55991]
name: next_date [57930,57939]
===
match
---
name: orm_subdag [29632,29642]
name: orm_subdag [29632,29642]
===
match
---
suite [6994,7046]
suite [6994,7046]
===
match
---
trailer [23758,23767]
trailer [23758,23767]
===
match
---
name: weight_rule [14320,14331]
name: weight_rule [14320,14331]
===
match
---
trailer [7030,7045]
trailer [7030,7045]
===
match
---
expr_stmt [55327,55455]
expr_stmt [57275,57403]
===
match
---
argument [16828,16846]
argument [16828,16846]
===
match
---
atom_expr [44485,44529]
atom_expr [44485,44529]
===
match
---
trailer [33022,33030]
trailer [33022,33030]
===
match
---
operator: == [38095,38097]
operator: == [38095,38097]
===
match
---
argument [68626,68654]
argument [70574,70602]
===
match
---
simple_stmt [10238,10256]
simple_stmt [10238,10256]
===
match
---
comp_op [30462,30468]
comp_op [30462,30468]
===
match
---
comparison [29421,29449]
comparison [29421,29449]
===
match
---
with_item [36190,36237]
with_item [36190,36237]
===
match
---
name: self [67644,67648]
name: self [69592,69596]
===
match
---
operator: = [63265,63266]
operator: = [65213,65214]
===
match
---
expr_stmt [17379,17404]
expr_stmt [17379,17404]
===
match
---
name: success [40646,40653]
name: success [40646,40653]
===
match
---
name: xcom_pass_to_op [68949,68964]
name: xcom_pass_to_op [70897,70912]
===
match
---
simple_stmt [67864,67935]
simple_stmt [69812,69883]
===
match
---
operator: = [52218,52219]
operator: = [54166,54167]
===
match
---
operator: , [23801,23802]
operator: , [23801,23802]
===
match
---
arglist [67472,67624]
arglist [69420,69572]
===
match
---
atom_expr [60891,60905]
atom_expr [62839,62853]
===
match
---
string: '@hourly' [56117,56126]
string: '@hourly' [58065,58074]
===
match
---
name: dag_id [32341,32347]
name: dag_id [32341,32347]
===
match
---
name: next_subdag_date [61250,61266]
name: next_subdag_date [63198,63214]
===
match
---
atom_expr [25186,25197]
atom_expr [25186,25197]
===
match
---
name: template_dir [19659,19671]
name: template_dir [19659,19671]
===
match
---
atom_expr [37214,37225]
atom_expr [37214,37225]
===
match
---
name: self [12238,12242]
name: self [12238,12242]
===
match
---
expr_stmt [3714,3742]
expr_stmt [3714,3742]
===
match
---
atom_expr [63445,63459]
atom_expr [65393,65407]
===
match
---
name: stage [13239,13244]
name: stage [13239,13244]
===
match
---
arglist [6006,6071]
arglist [6006,6071]
===
match
---
trailer [33284,33294]
trailer [33284,33294]
===
match
---
operator: , [60121,60122]
operator: , [62069,62070]
===
match
---
atom_expr [54418,54450]
atom_expr [56366,56398]
===
match
---
trailer [43235,43298]
trailer [43235,43298]
===
match
---
assert_stmt [18265,18415]
assert_stmt [18265,18415]
===
match
---
trailer [31232,31274]
trailer [31232,31274]
===
match
---
atom_expr [9153,9186]
atom_expr [9153,9186]
===
match
---
name: task_id [64362,64369]
name: task_id [66310,66317]
===
match
---
name: get_dagmodel [32129,32141]
name: get_dagmodel [32129,32141]
===
match
---
operator: , [28695,28696]
operator: , [28695,28696]
===
match
---
name: dag [21077,21080]
name: dag [21077,21080]
===
match
---
testlist_comp [24957,24986]
testlist_comp [24957,24986]
===
match
---
name: default_args [35055,35067]
name: default_args [35055,35067]
===
match
---
string: "test_dag" [36985,36995]
string: "test_dag" [36985,36995]
===
match
---
name: timezone [1884,1892]
name: timezone [1884,1892]
===
match
---
operator: = [30713,30714]
operator: = [30713,30714]
===
match
---
trailer [8424,8438]
trailer [8424,8438]
===
match
---
name: DummyOperator [50170,50183]
name: DummyOperator [50170,50183]
===
match
---
argument [17189,17245]
argument [17189,17245]
===
match
---
dictorsetmaker [24753,24827]
dictorsetmaker [24753,24827]
===
match
---
trailer [52427,52437]
trailer [54375,54385]
===
match
---
operator: = [5542,5543]
operator: = [5542,5543]
===
match
---
trailer [7841,7861]
trailer [7841,7861]
===
match
---
trailer [54262,54268]
trailer [56210,56216]
===
match
---
import_as_names [1977,2008]
import_as_names [1977,2008]
===
match
---
operator: , [1486,1487]
operator: , [1486,1487]
===
match
---
name: states [18201,18207]
name: states [18201,18207]
===
match
---
operator: { [32019,32020]
operator: { [32019,32020]
===
match
---
trailer [20327,20344]
trailer [20327,20344]
===
match
---
name: dag_id [59512,59518]
name: dag_id [61460,61466]
===
match
---
expr_stmt [68361,68598]
expr_stmt [70309,70546]
===
match
---
arglist [36985,37020]
arglist [36985,37020]
===
match
---
simple_stmt [1622,1667]
simple_stmt [1622,1667]
===
match
---
name: width [12507,12512]
name: width [12507,12512]
===
match
---
argument [39057,39070]
argument [39057,39070]
===
match
---
trailer [59461,59479]
trailer [61409,61427]
===
match
---
name: next_local [21952,21962]
name: next_local [21952,21962]
===
match
---
trailer [27965,28127]
trailer [27965,28127]
===
match
---
string: 'start_date' [10926,10938]
string: 'start_date' [10926,10938]
===
match
---
name: provide_session [30551,30566]
name: provide_session [30551,30566]
===
match
---
name: DAG [50100,50103]
name: DAG [50100,50103]
===
match
---
name: execution_date [43439,43453]
name: execution_date [43439,43453]
===
match
---
name: dirname [19682,19689]
name: dirname [19682,19689]
===
match
---
number: 1 [60475,60476]
number: 1 [62423,62424]
===
match
---
suite [54715,55286]
suite [56663,57234]
===
match
---
operator: == [27920,27922]
operator: == [27920,27922]
===
match
---
funcdef [5397,5665]
funcdef [5397,5665]
===
match
---
trailer [41068,41078]
trailer [41068,41078]
===
match
---
operator: = [50467,50468]
operator: = [50467,50468]
===
match
---
atom [46117,46125]
atom [46117,46125]
===
match
---
name: dag_id [26369,26375]
name: dag_id [26369,26375]
===
match
---
simple_stmt [33505,33522]
simple_stmt [33505,33522]
===
match
---
name: j [15728,15729]
name: j [15728,15729]
===
match
---
operator: = [34467,34468]
operator: = [34467,34468]
===
match
---
name: DEFAULT_DATE [24176,24188]
name: DEFAULT_DATE [24176,24188]
===
match
---
simple_stmt [57849,57995]
simple_stmt [59797,59943]
===
match
---
simple_stmt [55931,55967]
simple_stmt [57879,57915]
===
match
---
comparison [17682,17759]
comparison [17682,17759]
===
match
---
name: conf [5012,5016]
name: conf [5012,5016]
===
match
---
comparison [36608,36631]
comparison [36608,36631]
===
match
---
operator: == [45693,45695]
operator: == [45693,45695]
===
match
---
name: catchup [56190,56197]
name: catchup [58138,58145]
===
match
---
trailer [6282,6286]
trailer [6282,6286]
===
match
---
name: self [53598,53602]
name: self [55546,55550]
===
match
---
expr_stmt [53798,53823]
expr_stmt [55746,55771]
===
match
---
name: dag [68366,68369]
name: dag [70314,70317]
===
match
---
name: DagModel [31425,31433]
name: DagModel [31425,31433]
===
match
---
trailer [64024,64026]
trailer [65972,65974]
===
match
---
string: """         Test to check that a DAG with catchup = False only schedules beginning now, not back to the start date         """ [54518,54644]
string: """         Test to check that a DAG with catchup = False only schedules beginning now, not back to the start date         """ [56466,56592]
===
match
---
trailer [61933,61953]
trailer [63881,63901]
===
match
---
simple_stmt [18704,18740]
simple_stmt [18704,18740]
===
match
---
name: args [44524,44528]
name: args [44524,44528]
===
match
---
atom [10925,10979]
atom [10925,10979]
===
match
---
simple_stmt [37798,37869]
simple_stmt [37798,37869]
===
match
---
assert_stmt [19447,19483]
assert_stmt [19447,19483]
===
match
---
atom_expr [62686,62700]
atom_expr [64634,64648]
===
match
---
trailer [21855,21865]
trailer [21855,21865]
===
match
---
operator: == [29149,29151]
operator: == [29149,29151]
===
match
---
argument [56563,56588]
argument [58511,58536]
===
match
---
operator: { [25823,25824]
operator: { [25823,25824]
===
match
---
operator: } [60262,60263]
operator: } [62210,62211]
===
match
---
trailer [22635,22650]
trailer [22635,22650]
===
match
---
operator: , [5251,5252]
operator: , [5251,5252]
===
match
---
name: subdag [7916,7922]
name: subdag [7916,7922]
===
match
---
trailer [36671,36674]
trailer [36671,36674]
===
match
---
name: DAG [32670,32673]
name: DAG [32670,32673]
===
match
---
number: 1 [57293,57294]
number: 1 [59241,59242]
===
match
---
name: paused_dags [31802,31813]
name: paused_dags [31802,31813]
===
match
---
fstring_end: ' [14245,14246]
fstring_end: ' [14245,14246]
===
match
---
atom_expr [23286,23308]
atom_expr [23286,23308]
===
match
---
for_stmt [14769,15162]
for_stmt [14769,15162]
===
match
---
trailer [23926,23928]
trailer [23926,23928]
===
match
---
name: delta [41200,41205]
name: delta [41200,41205]
===
match
---
name: op5 [9819,9822]
name: op5 [9819,9822]
===
match
---
name: session [34701,34708]
name: session [34701,34708]
===
match
---
operator: } [29234,29235]
operator: } [29234,29235]
===
match
---
argument [48991,49018]
argument [48991,49018]
===
match
---
testlist_comp [64135,64137]
testlist_comp [66083,66085]
===
match
---
name: days [52737,52741]
name: days [54685,54689]
===
match
---
trailer [61105,61115]
trailer [63053,63063]
===
match
---
trailer [38156,38164]
trailer [38156,38164]
===
match
---
testlist_comp [14162,14478]
testlist_comp [14162,14478]
===
match
---
operator: == [69263,69265]
operator: == [71211,71213]
===
match
---
expr_stmt [60932,60957]
expr_stmt [62880,62905]
===
match
---
name: DagModel [25873,25881]
name: DagModel [25873,25881]
===
match
---
atom_expr [45696,45705]
atom_expr [45696,45705]
===
match
---
operator: , [44660,44661]
operator: , [44660,44661]
===
match
---
name: dag_subdag [60484,60494]
name: dag_subdag [62432,62442]
===
match
---
fstring_string: stage [14233,14238]
fstring_string: stage [14233,14238]
===
match
---
number: 3 [17367,17368]
number: 3 [17367,17368]
===
match
---
fstring [15560,15575]
fstring [15560,15575]
===
match
---
operator: } [4335,4336]
operator: } [4335,4336]
===
match
---
operator: , [21519,21520]
operator: , [21519,21520]
===
match
---
name: task_id [37066,37073]
name: task_id [37066,37073]
===
match
---
simple_stmt [53781,53790]
simple_stmt [55729,55738]
===
match
---
trailer [55380,55389]
trailer [57328,57337]
===
match
---
simple_stmt [48672,48734]
simple_stmt [48672,48734]
===
match
---
trailer [49322,49330]
trailer [49322,49330]
===
match
---
funcdef [33768,34717]
funcdef [33768,34717]
===
match
---
name: DummyOperator [36303,36316]
name: DummyOperator [36303,36316]
===
match
---
assert_stmt [6439,6467]
assert_stmt [6439,6467]
===
match
---
atom_expr [60612,60641]
atom_expr [62560,62589]
===
match
---
expr_stmt [55798,55843]
expr_stmt [57746,57791]
===
match
---
trailer [58560,58572]
trailer [60508,60520]
===
match
---
trailer [24125,24127]
trailer [24125,24127]
===
match
---
argument [62569,62586]
argument [64517,64534]
===
match
---
expr_stmt [47836,47898]
expr_stmt [47836,47898]
===
match
---
name: correct_weight [14988,15002]
name: correct_weight [14988,15002]
===
match
---
name: DEFAULT_DATE [48701,48713]
name: DEFAULT_DATE [48701,48713]
===
match
---
name: ti_state_end [51905,51917]
name: ti_state_end [53853,53865]
===
match
---
name: State [39307,39312]
name: State [39307,39312]
===
match
---
trailer [22025,22027]
trailer [22025,22027]
===
match
---
assert_stmt [49761,49797]
assert_stmt [49761,49797]
===
match
---
name: TaskFail [3075,3083]
name: TaskFail [3075,3083]
===
match
---
simple_stmt [21610,21679]
simple_stmt [21610,21679]
===
match
---
trailer [58128,58140]
trailer [60076,60088]
===
match
---
with_stmt [24622,24691]
with_stmt [24622,24691]
===
match
---
name: dr [47648,47650]
name: dr [47648,47650]
===
match
---
argument [33473,33490]
argument [33473,33490]
===
match
---
import_from [1106,1154]
import_from [1106,1154]
===
match
---
name: dag [60891,60894]
name: dag [62839,62842]
===
match
---
name: utcnow [43331,43337]
name: utcnow [43331,43337]
===
match
---
atom_expr [36981,37021]
atom_expr [36981,37021]
===
match
---
name: DEFAULT_DATE [49112,49124]
name: DEFAULT_DATE [49112,49124]
===
match
---
name: default_args [60343,60355]
name: default_args [62291,62303]
===
match
---
name: start_date [59191,59201]
name: start_date [61139,61149]
===
match
---
name: create_session [33380,33394]
name: create_session [33380,33394]
===
match
---
trailer [33432,33492]
trailer [33432,33492]
===
match
---
name: session [50901,50908]
name: session [50901,50908]
===
match
---
trailer [28224,28234]
trailer [28224,28234]
===
match
---
name: get [42813,42816]
name: get [42813,42816]
===
match
---
arglist [55099,55120]
arglist [57047,57068]
===
match
---
expr_stmt [49986,50031]
expr_stmt [49986,50031]
===
match
---
name: width [14413,14418]
name: width [14413,14418]
===
match
---
operator: , [30092,30093]
operator: , [30092,30093]
===
match
---
assert_stmt [31593,31694]
assert_stmt [31593,31694]
===
match
---
trailer [14901,14904]
trailer [14901,14904]
===
match
---
name: ti [67775,67777]
name: ti [69723,69725]
===
match
---
parameters [18503,18509]
parameters [18503,18509]
===
match
---
number: 55 [20413,20415]
number: 55 [20413,20415]
===
match
---
argument [44376,44393]
argument [44376,44393]
===
match
---
operator: = [23808,23809]
operator: = [23808,23809]
===
match
---
name: DagModel [46238,46246]
name: DagModel [46238,46246]
===
match
---
funcdef [18490,18546]
funcdef [18490,18546]
===
match
---
operator: = [24140,24141]
operator: = [24140,24141]
===
match
---
trailer [13441,13447]
trailer [13441,13447]
===
match
---
string: 'op8' [7129,7134]
string: 'op8' [7129,7134]
===
match
---
comparison [59804,59854]
comparison [61752,61802]
===
match
---
name: DEFAULT_DATE [50796,50808]
name: DEFAULT_DATE [50796,50808]
===
match
---
string: 't2' [55162,55166]
string: 't2' [57110,57114]
===
match
---
name: DEFAULT_DATE [49254,49266]
name: DEFAULT_DATE [49254,49266]
===
match
---
operator: , [43256,43257]
operator: , [43256,43257]
===
match
---
operator: , [50739,50740]
operator: , [50739,50740]
===
match
---
name: op1 [38381,38384]
name: op1 [38381,38384]
===
match
---
operator: = [57344,57345]
operator: = [59292,59293]
===
match
---
simple_stmt [43892,43948]
simple_stmt [43892,43948]
===
match
---
name: dag [45311,45314]
name: dag [45311,45314]
===
match
---
name: DagRunType [48064,48074]
name: DagRunType [48064,48074]
===
match
---
argument [51370,51390]
argument [51370,51390]
===
match
---
trailer [19605,19611]
trailer [19605,19611]
===
match
---
simple_stmt [19310,19349]
simple_stmt [19310,19349]
===
match
---
name: dag [6482,6485]
name: dag [6482,6485]
===
match
---
param [3180,3182]
param [3180,3182]
===
match
---
name: get_num_task_instances [17889,17911]
name: get_num_task_instances [17889,17911]
===
match
---
name: owner [28975,28980]
name: owner [28975,28980]
===
match
---
operator: = [62353,62354]
operator: = [64301,64302]
===
match
---
simple_stmt [52984,53016]
simple_stmt [54932,54964]
===
match
---
name: utils [2060,2065]
name: utils [2060,2065]
===
match
---
name: i [15890,15891]
name: i [15890,15891]
===
match
---
name: DAG [6002,6005]
name: DAG [6002,6005]
===
match
---
argument [55168,55175]
argument [57116,57123]
===
match
---
name: SubDagOperator [7880,7894]
name: SubDagOperator [7880,7894]
===
match
---
operator: { [26624,26625]
operator: { [26624,26625]
===
match
---
name: query [33552,33557]
name: query [33552,33557]
===
match
---
name: op2 [35346,35349]
name: op2 [35346,35349]
===
match
---
number: 1 [59841,59842]
number: 1 [61789,61790]
===
match
---
trailer [52120,52146]
trailer [54068,54094]
===
match
---
trailer [48622,48632]
trailer [48622,48632]
===
match
---
name: i [16016,16017]
name: i [16016,16017]
===
match
---
expr_stmt [20564,20600]
expr_stmt [20564,20600]
===
match
---
atom_expr [22139,22167]
atom_expr [22139,22167]
===
match
---
atom_expr [3720,3742]
atom_expr [3720,3742]
===
match
---
atom_expr [68971,68981]
atom_expr [70919,70929]
===
match
---
assert_stmt [18704,18739]
assert_stmt [18704,18739]
===
match
---
comparison [20115,20161]
comparison [20115,20161]
===
match
---
argument [7387,7413]
argument [7387,7413]
===
match
---
number: 1 [34902,34903]
number: 1 [34902,34903]
===
match
---
simple_stmt [4944,4997]
simple_stmt [4944,4997]
===
match
---
operator: , [51903,51904]
operator: , [53851,53852]
===
match
---
trailer [49613,49620]
trailer [49613,49620]
===
match
---
atom_expr [52991,53010]
atom_expr [54939,54958]
===
match
---
with_item [42740,42767]
with_item [42740,42767]
===
match
---
atom_expr [24358,24428]
atom_expr [24358,24428]
===
match
---
trailer [58181,58189]
trailer [60129,60137]
===
match
---
name: DAG [19769,19772]
name: DAG [19769,19772]
===
match
---
string: 'section-1' [60863,60874]
string: 'section-1' [62811,62822]
===
match
---
name: timezone [59202,59210]
name: timezone [61150,61158]
===
match
---
number: 10 [59232,59234]
number: 10 [61180,61182]
===
match
---
assert_stmt [23164,23219]
assert_stmt [23164,23219]
===
match
---
name: filter [49583,49589]
name: filter [49583,49589]
===
match
---
name: DEFAULT_DATE [8559,8571]
name: DEFAULT_DATE [8559,8571]
===
match
---
argument [62627,62660]
argument [64575,64608]
===
match
---
simple_stmt [12083,12142]
simple_stmt [12083,12142]
===
match
---
argument [36363,36375]
argument [36363,36375]
===
match
---
string: 'dag_with_outdated_perms' [61984,62009]
string: 'dag_with_outdated_perms' [63932,63957]
===
match
---
trailer [22962,22964]
trailer [22962,22964]
===
match
---
name: op9 [7144,7147]
name: op9 [7144,7147]
===
match
---
funcdef [12452,13783]
funcdef [12452,13783]
===
match
---
name: DAG [59495,59498]
name: DAG [61443,61446]
===
match
---
name: BaseOperator [23768,23780]
name: BaseOperator [23768,23780]
===
match
---
trailer [2979,2986]
trailer [2979,2986]
===
match
---
operator: = [60564,60565]
operator: = [62512,62513]
===
match
---
name: remove [10338,10344]
name: remove [10338,10344]
===
match
---
name: State [17267,17272]
name: State [17267,17272]
===
match
---
string: "test_schedule_dag_no_previous_runs" [39002,39038]
string: "test_schedule_dag_no_previous_runs" [39002,39038]
===
match
---
argument [33442,33471]
argument [33442,33471]
===
match
---
simple_stmt [21114,21150]
simple_stmt [21114,21150]
===
match
---
atom [29596,29616]
atom [29596,29616]
===
match
---
operator: , [48487,48488]
operator: , [48487,48488]
===
match
---
arglist [4292,4352]
arglist [4292,4352]
===
match
---
simple_stmt [6526,6561]
simple_stmt [6526,6561]
===
match
---
suite [3376,3405]
suite [3376,3405]
===
match
---
argument [51441,51456]
argument [51441,51456]
===
match
---
name: op3 [36025,36028]
name: op3 [36025,36028]
===
match
---
string: 'start_date' [11628,11640]
string: 'start_date' [11628,11640]
===
match
---
name: NamedTemporaryFile [970,988]
name: NamedTemporaryFile [970,988]
===
match
---
name: clear [39745,39750]
name: clear [39745,39750]
===
match
---
simple_stmt [37995,38029]
simple_stmt [37995,38029]
===
match
---
argument [39106,39126]
argument [39106,39126]
===
match
---
trailer [9158,9165]
trailer [9158,9165]
===
match
---
argument [14272,14294]
argument [14272,14294]
===
match
---
simple_stmt [33082,33171]
simple_stmt [33082,33171]
===
match
---
name: topological_list [10345,10361]
name: topological_list [10345,10361]
===
match
---
operator: , [46535,46536]
operator: , [46535,46536]
===
match
---
trailer [41637,41652]
trailer [41637,41652]
===
match
---
name: file [1912,1916]
name: file [1912,1916]
===
match
---
name: dagrun_2 [50662,50670]
name: dagrun_2 [50662,50670]
===
match
---
name: dag_decorator [67945,67958]
name: dag_decorator [69893,69906]
===
match
---
name: match [14837,14842]
name: match [14837,14842]
===
match
---
operator: = [8807,8808]
operator: = [8807,8808]
===
match
---
trailer [17565,17572]
trailer [17565,17572]
===
match
---
operator: = [55574,55575]
operator: = [57522,57523]
===
match
---
name: State [52303,52308]
name: State [54251,54256]
===
match
---
number: 4 [65784,65785]
number: 4 [67732,67733]
===
match
---
name: get_task_instances [68700,68718]
name: get_task_instances [70648,70666]
===
match
---
string: 'owner2' [29226,29234]
string: 'owner2' [29226,29234]
===
match
---
name: dag [59756,59759]
name: dag [61704,61707]
===
match
---
argument [32688,32716]
argument [32688,32716]
===
match
---
operator: , [32431,32432]
operator: , [32431,32432]
===
match
---
name: hash [45683,45687]
name: hash [45683,45687]
===
match
---
string: 'dag-bulk-sync-1' [25763,25780]
string: 'dag-bulk-sync-1' [25763,25780]
===
match
---
expr_stmt [53883,53927]
expr_stmt [55831,55875]
===
match
---
trailer [20096,20098]
trailer [20096,20098]
===
match
---
name: dag [62222,62225]
name: dag [64170,64173]
===
match
---
trailer [18675,18692]
trailer [18675,18692]
===
match
---
name: session [62969,62976]
name: session [64917,64924]
===
match
---
atom_expr [6310,6319]
atom_expr [6310,6319]
===
match
---
name: VALUE [68030,68035]
name: VALUE [69978,69983]
===
match
---
simple_stmt [989,1017]
simple_stmt [989,1017]
===
match
---
trailer [29502,29536]
trailer [29502,29536]
===
match
---
assert_stmt [33270,33294]
assert_stmt [33270,33294]
===
match
---
operator: , [54935,54936]
operator: , [56883,56884]
===
match
---
atom [46616,46672]
atom [46616,46672]
===
match
---
expr_stmt [22707,22775]
expr_stmt [22707,22775]
===
match
---
trailer [47403,47408]
trailer [47403,47408]
===
match
---
string: 'role2' [61594,61601]
string: 'role2' [63542,63549]
===
match
---
number: 52 [68350,68352]
number: 52 [70298,70300]
===
match
---
arglist [59462,59478]
arglist [61410,61426]
===
match
---
operator: + [15025,15026]
operator: + [15025,15026]
===
match
---
simple_stmt [24664,24691]
simple_stmt [24664,24691]
===
match
---
atom_expr [31726,31736]
atom_expr [31726,31736]
===
match
---
name: dag_id [40827,40833]
name: dag_id [40827,40833]
===
match
---
argument [50785,50808]
argument [50785,50808]
===
match
---
name: model [27715,27720]
name: model [27715,27720]
===
match
---
simple_stmt [24136,24215]
simple_stmt [24136,24215]
===
match
---
operator: = [58690,58691]
operator: = [60638,60639]
===
match
---
name: start_date [21630,21640]
name: start_date [21630,21640]
===
match
---
argument [48299,48315]
argument [48299,48315]
===
match
---
name: airflow [1272,1279]
name: airflow [1272,1279]
===
match
---
fstring_expr [64383,64386]
fstring_expr [66331,66334]
===
match
---
operator: = [54999,55000]
operator: = [56947,56948]
===
match
---
name: op5 [36038,36041]
name: op5 [36038,36041]
===
match
---
atom [46366,46378]
atom [46366,46378]
===
match
---
expr_stmt [33082,33170]
expr_stmt [33082,33170]
===
match
---
trailer [7894,7933]
trailer [7894,7933]
===
match
---
operator: = [35900,35901]
operator: = [35900,35901]
===
match
---
name: topological_sort [8056,8072]
name: topological_sort [8056,8072]
===
match
---
name: session [18424,18431]
name: session [18424,18431]
===
match
---
simple_stmt [12034,12075]
simple_stmt [12034,12075]
===
match
---
simple_stmt [44350,44395]
simple_stmt [44350,44395]
===
match
---
atom_expr [65465,65475]
atom_expr [67413,67423]
===
match
---
operator: > [56369,56370]
operator: > [58317,58318]
===
match
---
operator: , [38334,38335]
operator: , [38334,38335]
===
match
---
operator: , [65879,65880]
operator: , [67827,67828]
===
match
---
simple_stmt [7874,7934]
simple_stmt [7874,7934]
===
match
---
operator: = [57615,57616]
operator: = [59563,59564]
===
match
---
atom_expr [46255,46270]
atom_expr [46255,46270]
===
match
---
trailer [18365,18372]
trailer [18365,18372]
===
match
---
assert_stmt [13740,13782]
assert_stmt [13740,13782]
===
match
---
import_name [814,828]
import_name [814,828]
===
match
---
name: outdated_permissions [62026,62046]
name: outdated_permissions [63974,63994]
===
match
---
expr_stmt [47304,47336]
expr_stmt [47304,47336]
===
match
---
parameters [4840,4846]
parameters [4840,4846]
===
match
---
string: "@weekly" [46430,46439]
string: "@weekly" [46430,46439]
===
match
---
operator: = [49357,49358]
operator: = [49357,49358]
===
match
---
expr_stmt [6104,6138]
expr_stmt [6104,6138]
===
match
---
sync_comp_for [26729,26776]
sync_comp_for [26729,26776]
===
match
---
operator: = [42276,42277]
operator: = [42276,42277]
===
match
---
trailer [29853,29954]
trailer [29853,29954]
===
match
---
name: MANUAL [68415,68421]
name: MANUAL [70363,70369]
===
match
---
atom_expr [41382,41402]
atom_expr [41382,41402]
===
match
---
trailer [41575,41577]
trailer [41575,41577]
===
match
---
trailer [57485,57497]
trailer [59433,59445]
===
match
---
name: op3 [7946,7949]
name: op3 [7946,7949]
===
match
---
fstring_start: f" [47661,47663]
fstring_start: f" [47661,47663]
===
match
---
atom [61499,61702]
atom [63447,63650]
===
match
---
trailer [51617,51621]
trailer [51617,51621]
===
match
---
name: timezone [64881,64889]
name: timezone [66829,66837]
===
match
---
name: params2 [4345,4352]
name: params2 [4345,4352]
===
match
---
name: DagModel [33575,33583]
name: DagModel [33575,33583]
===
match
---
trailer [39775,39783]
trailer [39775,39783]
===
match
---
atom_expr [30312,30343]
atom_expr [30312,30343]
===
match
---
simple_stmt [4535,4609]
simple_stmt [4535,4609]
===
match
---
name: session [33056,33063]
name: session [33056,33063]
===
match
---
number: 2015 [53291,53295]
number: 2015 [55239,55243]
===
match
---
atom_expr [54236,54268]
atom_expr [56184,56216]
===
match
---
argument [43147,43160]
argument [43147,43160]
===
match
---
name: match [14890,14895]
name: match [14890,14895]
===
match
---
arglist [57701,57711]
arglist [59649,59659]
===
match
---
operator: = [4948,4949]
operator: = [4948,4949]
===
match
---
arglist [48876,49019]
arglist [48876,49019]
===
match
---
operator: } [24441,24442]
operator: } [24441,24442]
===
match
---
simple_stmt [1570,1622]
simple_stmt [1570,1622]
===
match
---
arglist [10905,10979]
arglist [10905,10979]
===
match
---
simple_stmt [10460,10495]
simple_stmt [10460,10495]
===
match
---
comparison [15126,15161]
comparison [15126,15161]
===
match
---
atom_expr [35925,35952]
atom_expr [35925,35952]
===
match
---
operator: , [60478,60479]
operator: , [62426,62427]
===
match
---
name: next_local [23049,23059]
name: next_local [23049,23059]
===
match
---
operator: = [6131,6132]
operator: = [6131,6132]
===
match
---
operator: == [29593,29595]
operator: == [29593,29595]
===
match
---
name: NamedTemporaryFile [19547,19565]
name: NamedTemporaryFile [19547,19565]
===
match
---
expr_stmt [31169,31192]
expr_stmt [31169,31192]
===
match
---
name: DummyOperator [35787,35800]
name: DummyOperator [35787,35800]
===
match
---
name: op1 [7999,8002]
name: op1 [7999,8002]
===
match
---
expr_stmt [44006,44031]
expr_stmt [44006,44031]
===
match
---
operator: == [46157,46159]
operator: == [46157,46159]
===
match
---
expr_stmt [33004,33032]
expr_stmt [33004,33032]
===
match
---
name: DEFAULT_DATE [24558,24570]
name: DEFAULT_DATE [24558,24570]
===
match
---
number: 1 [60636,60637]
number: 1 [62584,62585]
===
match
---
name: datetime [53432,53440]
name: datetime [55380,55388]
===
match
---
atom_expr [33092,33170]
atom_expr [33092,33170]
===
match
---
operator: , [25965,25966]
operator: , [25965,25966]
===
match
---
operator: , [42828,42829]
operator: , [42828,42829]
===
match
---
operator: , [36036,36037]
operator: , [36036,36037]
===
match
---
return_stmt [60509,60526]
return_stmt [62457,62474]
===
match
---
name: fileloc [34343,34350]
name: fileloc [34343,34350]
===
match
---
name: create_dagrun [40505,40518]
name: create_dagrun [40505,40518]
===
match
---
string: 'E' [9847,9850]
string: 'E' [9847,9850]
===
match
---
simple_stmt [64866,64911]
simple_stmt [66814,66859]
===
match
---
operator: = [53809,53810]
operator: = [55757,55758]
===
match
---
name: run_type [48876,48884]
name: run_type [48876,48884]
===
match
---
atom_expr [15733,15748]
atom_expr [15733,15748]
===
match
---
arglist [2556,2589]
arglist [2556,2589]
===
match
---
number: 2 [17243,17244]
number: 2 [17243,17244]
===
match
---
operator: = [44388,44389]
operator: = [44388,44389]
===
match
---
simple_stmt [3295,3308]
simple_stmt [3295,3308]
===
match
---
name: dag [32599,32602]
name: dag [32599,32602]
===
match
---
atom_expr [8269,8329]
atom_expr [8269,8329]
===
match
---
name: DEFAULT_DATE [51058,51070]
name: DEFAULT_DATE [51058,51070]
===
match
---
dictorsetmaker [61523,61579]
dictorsetmaker [63471,63527]
===
match
---
name: self [67701,67705]
name: self [69649,69653]
===
match
---
expr_stmt [21114,21149]
expr_stmt [21114,21149]
===
match
---
name: self [64209,64213]
name: self [66157,66161]
===
match
---
trailer [15859,15869]
trailer [15859,15869]
===
match
---
atom_expr [37388,37479]
atom_expr [37388,37479]
===
match
---
arglist [17807,17863]
arglist [17807,17863]
===
match
---
trailer [17227,17237]
trailer [17227,17237]
===
match
---
suite [8522,9401]
suite [8522,9401]
===
match
---
trailer [7178,7182]
trailer [7178,7182]
===
match
---
name: test_dag_topological_sort_include_subdag_tasks [7260,7306]
name: test_dag_topological_sort_include_subdag_tasks [7260,7306]
===
match
---
name: DAG [17780,17783]
name: DAG [17780,17783]
===
match
---
name: dag_id [41167,41173]
name: dag_id [41167,41173]
===
match
---
name: i [3403,3404]
name: i [3403,3404]
===
match
---
trailer [51108,51114]
trailer [51108,51114]
===
match
---
operator: = [30006,30007]
operator: = [30006,30007]
===
match
---
name: isinstance [65833,65843]
name: isinstance [67781,67791]
===
match
---
string: "test_schedule_dag_start_end_dates" [53892,53927]
string: "test_schedule_dag_start_end_dates" [55840,55875]
===
match
---
name: default_args [44322,44334]
name: default_args [44322,44334]
===
match
---
import_as_name [2082,2105]
import_as_name [2082,2105]
===
match
---
simple_stmt [47123,47148]
simple_stmt [47123,47148]
===
match
---
name: dagruns [49695,49702]
name: dagruns [49695,49702]
===
match
---
name: dag [37641,37644]
name: dag [37641,37644]
===
match
---
parameters [67004,67010]
parameters [68952,68958]
===
match
---
operator: , [67690,67691]
operator: , [69638,69639]
===
match
---
argument [38447,38459]
argument [38447,38459]
===
match
---
fstring_expr [60264,60280]
fstring_expr [62212,62228]
===
match
---
operator: = [50671,50672]
operator: = [50671,50672]
===
match
---
operator: , [41205,41206]
operator: , [41205,41206]
===
match
---
simple_stmt [24745,24919]
simple_stmt [24745,24919]
===
match
---
expr_stmt [47535,47632]
expr_stmt [47535,47632]
===
match
---
trailer [39682,39688]
trailer [39682,39688]
===
match
---
arglist [63355,63563]
arglist [65303,65511]
===
match
---
atom_expr [23236,23264]
atom_expr [23236,23264]
===
match
---
atom_expr [13026,13041]
atom_expr [13026,13041]
===
match
---
name: template_ext [19366,19378]
name: template_ext [19366,19378]
===
match
---
operator: , [59548,59549]
operator: , [61496,61497]
===
match
---
expr_stmt [52156,52184]
expr_stmt [54104,54132]
===
match
---
trailer [9251,9272]
trailer [9251,9272]
===
match
---
comparison [10467,10494]
comparison [10467,10494]
===
match
---
parameters [47759,47765]
parameters [47759,47765]
===
match
---
name: datetime_tz [2368,2379]
name: datetime_tz [2368,2379]
===
match
---
operator: @ [56865,56866]
operator: @ [58813,58814]
===
match
---
trailer [23294,23302]
trailer [23294,23302]
===
match
---
name: operator [64985,64993]
name: operator [66933,66941]
===
match
---
name: isoformat [21856,21865]
name: isoformat [21856,21865]
===
match
---
name: op3 [8938,8941]
name: op3 [8938,8941]
===
match
---
name: compile [14000,14007]
name: compile [14000,14007]
===
match
---
operator: = [35511,35512]
operator: = [35511,35512]
===
match
---
funcdef [2634,2747]
funcdef [2634,2747]
===
match
---
trailer [31507,31514]
trailer [31507,31514]
===
match
---
name: task_decorator [68051,68065]
name: task_decorator [69999,70013]
===
match
---
argument [22618,22650]
argument [22618,22650]
===
match
---
string: 't2' [38455,38459]
string: 't2' [38455,38459]
===
match
---
trailer [12416,12425]
trailer [12416,12425]
===
match
---
atom_expr [67733,67759]
atom_expr [69681,69707]
===
match
---
suite [14120,15162]
suite [14120,15162]
===
match
---
name: orm_subdag [29668,29678]
name: orm_subdag [29668,29678]
===
match
---
number: 1 [54387,54388]
number: 1 [56335,56336]
===
match
---
argument [55422,55430]
argument [57370,57378]
===
match
---
name: dag [34935,34938]
name: dag [34935,34938]
===
match
---
shift_expr [7999,8016]
shift_expr [7999,8016]
===
match
---
name: dag_id [56516,56522]
name: dag_id [58464,58470]
===
match
---
simple_stmt [814,829]
simple_stmt [814,829]
===
match
---
simple_stmt [40023,40071]
simple_stmt [40023,40071]
===
match
---
simple_stmt [6715,6744]
simple_stmt [6715,6744]
===
match
---
arglist [32943,32994]
arglist [32943,32994]
===
match
---
name: subdag [51590,51596]
name: subdag [51590,51596]
===
match
---
dictorsetmaker [26828,27011]
dictorsetmaker [26828,27011]
===
match
---
suite [47766,48082]
suite [47766,48082]
===
match
---
trailer [24422,24426]
trailer [24422,24426]
===
match
---
trailer [64558,64566]
trailer [66506,66514]
===
match
---
argument [18390,18405]
argument [18390,18405]
===
match
---
operator: = [57368,57369]
operator: = [59316,59317]
===
match
---
operator: = [12570,12571]
operator: = [12570,12571]
===
match
---
name: op1 [9864,9867]
name: op1 [9864,9867]
===
match
---
trailer [31450,31460]
trailer [31450,31460]
===
match
---
operator: = [60766,60767]
operator: = [62714,62715]
===
match
---
name: dagrun_1 [48834,48842]
name: dagrun_1 [48834,48842]
===
match
---
trailer [68232,68241]
trailer [70180,70189]
===
match
---
name: drs [47357,47360]
name: drs [47357,47360]
===
match
---
operator: = [38431,38432]
operator: = [38431,38432]
===
match
---
argument [60480,60494]
argument [62428,62442]
===
match
---
name: schedule_interval [57312,57329]
name: schedule_interval [59260,59277]
===
match
---
argument [47982,48014]
argument [47982,48014]
===
match
---
name: datetime [58767,58775]
name: datetime [60715,60723]
===
match
---
operator: = [36278,36279]
operator: = [36278,36279]
===
match
---
string: 'Europe/Zurich' [34823,34838]
string: 'Europe/Zurich' [34823,34838]
===
match
---
string: "hello" [18631,18638]
string: "hello" [18631,18638]
===
match
---
name: start_date [62690,62700]
name: start_date [64638,64648]
===
match
---
atom_expr [52107,52146]
atom_expr [54055,54094]
===
match
---
suite [30612,32501]
suite [30612,32501]
===
match
---
comparison [6242,6263]
comparison [6242,6263]
===
match
---
name: date [54294,54298]
name: date [56242,56246]
===
match
---
operator: -> [2454,2456]
operator: -> [2454,2456]
===
match
---
name: next_dagrun_create_after [41871,41895]
name: next_dagrun_create_after [41871,41895]
===
match
---
atom_expr [47841,47898]
atom_expr [47841,47898]
===
match
---
operator: = [11626,11627]
operator: = [11626,11627]
===
match
---
string: '@daily' [7405,7413]
string: '@daily' [7405,7413]
===
match
---
operator: - [55548,55549]
operator: - [57496,57497]
===
match
---
name: airflow [2111,2118]
name: airflow [2111,2118]
===
match
---
name: test_next_dagrun_after_date_timedelta_schedule_and_catchup_true [57770,57833]
name: test_next_dagrun_after_date_timedelta_schedule_and_catchup_true [59718,59781]
===
match
---
simple_stmt [58680,58730]
simple_stmt [60628,60678]
===
match
---
trailer [9009,9026]
trailer [9009,9026]
===
match
---
name: permissions [61604,61615]
name: permissions [63552,63563]
===
match
---
argument [47586,47613]
argument [47586,47613]
===
match
---
dotted_name [2154,2179]
dotted_name [2154,2179]
===
match
---
atom [25823,25909]
atom [25823,25909]
===
match
---
name: DAG [66344,66347]
name: DAG [68292,68295]
===
match
---
expr_stmt [17413,17441]
expr_stmt [17413,17441]
===
match
---
operator: = [28887,28888]
operator: = [28887,28888]
===
match
---
suite [57840,58788]
suite [59788,60736]
===
match
---
name: op4 [6526,6529]
name: op4 [6526,6529]
===
match
---
operator: , [12133,12134]
operator: , [12133,12134]
===
match
---
atom_expr [3044,3135]
atom_expr [3044,3135]
===
match
---
operator: { [38134,38135]
operator: { [38134,38135]
===
match
---
name: op4 [8973,8976]
name: op4 [8973,8976]
===
match
---
operator: = [59201,59202]
operator: = [61149,61150]
===
match
---
atom_expr [8045,8099]
atom_expr [8045,8099]
===
match
---
trailer [29788,29790]
trailer [29788,29790]
===
match
---
string: "t1" [35328,35332]
string: "t1" [35328,35332]
===
match
---
parameters [46731,46786]
parameters [46731,46786]
===
match
---
trailer [30301,30303]
trailer [30301,30303]
===
match
---
name: default_args [55038,55050]
name: default_args [56986,56998]
===
match
---
fstring_end: ' [60280,60281]
fstring_end: ' [62228,62229]
===
match
---
name: DummyOperator [37558,37571]
name: DummyOperator [37558,37571]
===
match
---
operator: == [29212,29214]
operator: == [29212,29214]
===
match
---
operator: = [8874,8875]
operator: = [8874,8875]
===
match
---
trailer [24345,24348]
trailer [24345,24348]
===
match
---
name: task_instance [53085,53098]
name: task_instance [55033,55046]
===
match
---
operator: = [37525,37526]
operator: = [37525,37526]
===
match
---
name: dag_id [40163,40169]
name: dag_id [40163,40169]
===
match
---
name: dag_id [5334,5340]
name: dag_id [5334,5340]
===
match
---
operator: } [35609,35610]
operator: } [35609,35610]
===
match
---
testlist_comp [36033,36041]
testlist_comp [36033,36041]
===
match
---
operator: , [49891,49892]
operator: , [49891,49892]
===
match
---
operator: = [9801,9802]
operator: = [9801,9802]
===
match
---
trailer [20976,20984]
trailer [20976,20984]
===
match
---
name: DEFAULT_DATE [17079,17091]
name: DEFAULT_DATE [17079,17091]
===
match
---
name: models [5544,5550]
name: models [5544,5550]
===
match
---
name: template_ext [20027,20039]
name: template_ext [20027,20039]
===
match
---
name: dag [5065,5068]
name: dag [5065,5068]
===
match
---
comparison [6212,6226]
comparison [6212,6226]
===
match
---
operator: == [48384,48386]
operator: == [48384,48386]
===
match
---
name: default_args [44662,44674]
name: default_args [44662,44674]
===
match
---
operator: , [61344,61345]
operator: , [63292,63293]
===
match
---
argument [35366,35378]
argument [35366,35378]
===
match
---
operator: , [1460,1461]
operator: , [1460,1461]
===
match
---
name: start_date [42417,42427]
name: start_date [42417,42427]
===
match
---
name: schedule_interval [21648,21665]
name: schedule_interval [21648,21665]
===
match
---
name: dag_run_state [51329,51342]
name: dag_run_state [51329,51342]
===
match
---
name: session [26596,26603]
name: session [26596,26603]
===
match
---
trailer [22813,22818]
trailer [22813,22818]
===
match
---
name: num [65727,65730]
name: num [67675,67678]
===
match
---
name: test_documentation_added [65906,65930]
name: test_documentation_added [67854,67878]
===
match
---
trailer [63589,63593]
trailer [65537,65541]
===
match
---
name: pipeline [13136,13144]
name: pipeline [13136,13144]
===
match
---
string: "test_dag" [36194,36204]
string: "test_dag" [36194,36204]
===
match
---
argument [55223,55230]
argument [57171,57178]
===
match
---
atom_expr [3812,3822]
atom_expr [3812,3822]
===
match
---
trailer [6592,6607]
trailer [6592,6607]
===
match
---
name: exceptions [1373,1383]
name: exceptions [1373,1383]
===
match
---
trailer [19638,19644]
trailer [19638,19644]
===
match
---
operator: = [63254,63255]
operator: = [65202,65203]
===
match
---
atom_expr [45989,46005]
atom_expr [45989,46005]
===
match
---
name: task [19361,19365]
name: task [19361,19365]
===
match
---
trailer [51579,51586]
trailer [51579,51586]
===
match
---
simple_stmt [45282,45315]
simple_stmt [45282,45315]
===
match
---
operator: , [1470,1471]
operator: , [1470,1471]
===
match
---
comparison [42301,42341]
comparison [42301,42341]
===
match
---
operator: = [10807,10808]
operator: = [10807,10808]
===
match
---
name: owner [6450,6455]
name: owner [6450,6455]
===
match
---
trailer [67705,67718]
trailer [69653,69666]
===
match
---
name: BACKFILL_JOB [50727,50739]
name: BACKFILL_JOB [50727,50739]
===
match
---
parameters [69038,69043]
parameters [70986,70991]
===
match
---
trailer [42802,42812]
trailer [42802,42812]
===
match
---
suite [37480,37673]
suite [37480,37673]
===
match
---
name: name [35007,35011]
name: name [35007,35011]
===
match
---
tfpdef [51905,51932]
tfpdef [53853,53880]
===
match
---
name: execution_date [67558,67572]
name: execution_date [69506,69520]
===
match
---
simple_stmt [38562,38639]
simple_stmt [38562,38639]
===
match
---
trailer [49582,49589]
trailer [49582,49589]
===
match
---
with_stmt [24248,24443]
with_stmt [24248,24443]
===
match
---
operator: = [3718,3719]
operator: = [3718,3719]
===
match
---
atom_expr [48748,48787]
atom_expr [48748,48787]
===
match
---
simple_stmt [25922,26397]
simple_stmt [25922,26397]
===
match
---
argument [59562,59613]
argument [61510,61561]
===
match
---
with_stmt [25613,25682]
with_stmt [25613,25682]
===
match
---
name: session [41610,41617]
name: session [41610,41617]
===
match
---
assert_stmt [53403,53452]
assert_stmt [55351,55400]
===
match
---
trailer [25844,25847]
trailer [25844,25847]
===
match
---
name: parameterized [46322,46335]
name: parameterized [46322,46335]
===
match
---
number: 1 [61229,61230]
number: 1 [63177,63178]
===
match
---
with_stmt [25690,26397]
with_stmt [25690,26397]
===
match
---
name: settings [30285,30293]
name: settings [30285,30293]
===
match
---
name: split [36577,36582]
name: split [36577,36582]
===
match
---
name: DagModel [31499,31507]
name: DagModel [31499,31507]
===
match
---
name: set [29180,29183]
name: set [29180,29183]
===
match
---
string: 'test-default_default_view' [4968,4995]
string: 'test-default_default_view' [4968,4995]
===
match
---
name: job_id [48139,48145]
name: job_id [48139,48145]
===
match
---
name: dag [62063,62066]
name: dag [64011,64014]
===
match
---
simple_stmt [42294,42342]
simple_stmt [42294,42342]
===
match
---
operator: = [50191,50192]
operator: = [50191,50192]
===
match
---
fstring_start: f' [18530,18532]
fstring_start: f' [18530,18532]
===
match
---
trailer [28911,28921]
trailer [28911,28921]
===
match
---
fstring_start: f' [24525,24527]
fstring_start: f' [24525,24527]
===
match
---
trailer [29339,29352]
trailer [29339,29352]
===
match
---
string: "t2" [35374,35378]
string: "t2" [35374,35378]
===
match
---
simple_stmt [19361,19396]
simple_stmt [19361,19396]
===
match
---
simple_stmt [30870,30948]
simple_stmt [30870,30948]
===
match
---
decorator [46321,46690]
decorator [46321,46690]
===
match
---
name: op2 [8933,8936]
name: op2 [8933,8936]
===
match
---
name: match [13495,13500]
name: match [13495,13500]
===
match
---
trailer [10527,10530]
trailer [10527,10530]
===
match
---
simple_stmt [38473,38507]
simple_stmt [38473,38507]
===
match
---
trailer [7077,7092]
trailer [7077,7092]
===
match
---
arglist [43386,43569]
arglist [43386,43569]
===
match
---
operator: = [9711,9712]
operator: = [9711,9712]
===
match
---
decorator [68050,68066]
decorator [69998,70014]
===
match
---
atom_expr [51724,51734]
atom_expr [53672,53682]
===
match
---
atom_expr [35352,35379]
atom_expr [35352,35379]
===
match
---
argument [50400,50410]
argument [50400,50410]
===
match
---
simple_stmt [68228,68297]
simple_stmt [70176,70245]
===
match
---
name: clear_db_runs [64068,64081]
name: clear_db_runs [66016,66029]
===
match
---
operator: , [36204,36205]
operator: , [36204,36205]
===
match
---
name: staticmethod [2753,2765]
name: staticmethod [2753,2765]
===
match
---
trailer [10429,10450]
trailer [10429,10450]
===
match
---
name: session [17848,17855]
name: session [17848,17855]
===
match
---
string: 'task' [28616,28622]
string: 'task' [28616,28622]
===
match
---
name: task [19861,19865]
name: task [19861,19865]
===
match
---
name: DAG [48165,48168]
name: DAG [48165,48168]
===
match
---
simple_stmt [60424,60496]
simple_stmt [62372,62444]
===
match
---
name: dagruns [49726,49733]
name: dagruns [49726,49733]
===
match
---
name: assert_queries_count [26499,26519]
name: assert_queries_count [26499,26519]
===
match
---
name: task_id [14223,14230]
name: task_id [14223,14230]
===
match
---
operator: = [55116,55117]
operator: = [57064,57065]
===
match
---
name: os [19726,19728]
name: os [19726,19728]
===
match
---
atom [38203,38239]
atom [38203,38239]
===
match
---
dictorsetmaker [32424,32470]
dictorsetmaker [32424,32470]
===
match
---
name: datetime [58120,58128]
name: datetime [60068,60076]
===
match
---
name: state [47278,47283]
name: state [47278,47283]
===
match
---
comparison [32410,32500]
comparison [32410,32500]
===
match
---
name: MANUAL [48075,48081]
name: MANUAL [48075,48081]
===
match
---
expr_stmt [19015,19053]
expr_stmt [19015,19053]
===
match
---
assert_stmt [27170,27195]
assert_stmt [27170,27195]
===
match
---
trailer [42816,42831]
trailer [42816,42831]
===
match
---
comparison [44978,44991]
comparison [44978,44991]
===
match
---
expr_stmt [35438,35471]
expr_stmt [35438,35471]
===
match
---
name: task_id [15552,15559]
name: task_id [15552,15559]
===
match
---
expr_stmt [22176,22211]
expr_stmt [22176,22211]
===
match
---
parameters [45874,45880]
parameters [45874,45880]
===
match
---
name: lower [33755,33760]
name: lower [33755,33760]
===
match
---
operator: = [33542,33543]
operator: = [33542,33543]
===
match
---
comparison [26624,26790]
comparison [26624,26790]
===
match
---
simple_stmt [11048,11576]
simple_stmt [11048,11576]
===
match
---
decorator [48399,48505]
decorator [48399,48505]
===
match
---
trailer [6215,6219]
trailer [6215,6219]
===
match
---
trailer [29032,29040]
trailer [29032,29040]
===
match
---
argument [63260,63275]
argument [65208,65223]
===
match
---
name: in_ [31249,31252]
name: in_ [31249,31252]
===
match
---
atom_expr [52608,52624]
atom_expr [54556,54572]
===
match
---
testlist_comp [49849,49860]
testlist_comp [49849,49860]
===
match
---
trailer [34714,34716]
trailer [34714,34716]
===
match
---
simple_stmt [39461,39489]
simple_stmt [39461,39489]
===
match
---
assert_stmt [7228,7250]
assert_stmt [7228,7250]
===
match
---
argument [52049,52072]
argument [53997,54020]
===
match
---
operator: = [12087,12088]
operator: = [12087,12088]
===
match
---
name: settings [12429,12437]
name: settings [12429,12437]
===
match
---
param [57834,57838]
param [59782,59786]
===
match
---
name: delete [2906,2912]
name: delete [2906,2912]
===
match
---
trailer [47967,47981]
trailer [47967,47981]
===
match
---
funcdef [9406,10538]
funcdef [9406,10538]
===
match
---
import_from [1017,1042]
import_from [1017,1042]
===
match
---
name: next_dagrun_after_date [58252,58274]
name: next_dagrun_after_date [60200,60222]
===
match
---
parameters [5435,5441]
parameters [5435,5441]
===
match
---
atom_expr [23768,23843]
atom_expr [23768,23843]
===
match
---
trailer [40816,40826]
trailer [40816,40826]
===
match
---
trailer [28243,28250]
trailer [28243,28250]
===
match
---
name: airflow [1235,1242]
name: airflow [1235,1242]
===
match
---
for_stmt [13266,13361]
for_stmt [13266,13361]
===
match
---
name: permissions [61867,61878]
name: permissions [63815,63826]
===
match
---
number: 5 [12552,12553]
number: 5 [12552,12553]
===
match
---
name: start_date [48954,48964]
name: start_date [48954,48964]
===
match
---
name: task_id [35458,35465]
name: task_id [35458,35465]
===
match
---
string: '{{ ds }}' [19473,19483]
string: '{{ ds }}' [19473,19483]
===
match
---
name: timedelta [49313,49322]
name: timedelta [49313,49322]
===
match
---
name: start_date [16486,16496]
name: start_date [16486,16496]
===
match
---
dictorsetmaker [38135,38169]
dictorsetmaker [38135,38169]
===
match
---
atom_expr [40146,40363]
atom_expr [40146,40363]
===
match
---
trailer [32284,32291]
trailer [32284,32291]
===
match
---
dictorsetmaker [14093,14110]
dictorsetmaker [14093,14110]
===
match
---
string: "test-dag" [26474,26484]
string: "test-dag" [26474,26484]
===
match
---
string: 'dag.subdag' [30633,30645]
string: 'dag.subdag' [30633,30645]
===
match
---
param [39863,39868]
param [39863,39868]
===
match
---
name: width [13951,13956]
name: width [13951,13956]
===
match
---
expr_stmt [31802,32002]
expr_stmt [31802,32002]
===
match
---
name: tasks_count [64322,64333]
name: tasks_count [66270,66281]
===
match
---
trailer [66401,66408]
trailer [68349,68356]
===
match
---
name: has_task_concurrency_limits [63386,63413]
name: has_task_concurrency_limits [65334,65361]
===
match
---
simple_stmt [67284,67313]
simple_stmt [69232,69261]
===
match
---
name: dag_id [42238,42244]
name: dag_id [42238,42244]
===
match
---
atom_expr [25695,25711]
atom_expr [25695,25711]
===
match
---
suite [9443,10538]
suite [9443,10538]
===
match
---
trailer [30536,30542]
trailer [30536,30542]
===
match
---
decorator [66020,66067]
decorator [67968,68015]
===
match
---
operator: , [31766,31767]
operator: , [31766,31767]
===
match
---
argument [48876,48908]
argument [48876,48908]
===
match
---
atom_expr [49726,49736]
atom_expr [49726,49736]
===
match
---
name: op3 [38235,38238]
name: op3 [38235,38238]
===
match
---
trailer [40620,40636]
trailer [40620,40636]
===
match
---
operator: = [43141,43142]
operator: = [43141,43142]
===
match
---
trailer [53500,53511]
trailer [55448,55459]
===
match
---
testlist_comp [18354,18387]
testlist_comp [18354,18387]
===
match
---
operator: { [18630,18631]
operator: { [18630,18631]
===
match
---
trailer [10007,10022]
trailer [10007,10022]
===
match
---
string: "0 0 1 * *" [46480,46491]
string: "0 0 1 * *" [46480,46491]
===
match
---
simple_stmt [61132,61177]
simple_stmt [63080,63125]
===
match
---
simple_stmt [31802,32003]
simple_stmt [31802,32003]
===
match
---
operator: = [61971,61972]
operator: = [63919,63920]
===
match
---
trailer [12128,12140]
trailer [12128,12140]
===
match
---
trailer [47277,47295]
trailer [47277,47295]
===
match
---
simple_stmt [50421,50450]
simple_stmt [50421,50450]
===
match
---
operator: = [8558,8559]
operator: = [8558,8559]
===
match
---
dotted_name [2241,2265]
dotted_name [2241,2265]
===
match
---
name: tzinfo [34908,34914]
name: tzinfo [34908,34914]
===
match
---
fstring_end: ' [39641,39642]
fstring_end: ' [39641,39642]
===
match
---
expr_stmt [8987,9028]
expr_stmt [8987,9028]
===
match
---
operator: = [7902,7903]
operator: = [7902,7903]
===
match
---
name: start_date [50785,50795]
name: start_date [50785,50795]
===
match
---
argument [64403,64410]
argument [66351,66358]
===
match
---
trailer [19314,19330]
trailer [19314,19330]
===
match
---
atom_expr [50901,50924]
atom_expr [50901,50924]
===
match
---
name: self [41945,41949]
name: self [41945,41949]
===
match
---
name: orm_dag [63323,63330]
name: orm_dag [65271,65278]
===
match
---
simple_stmt [20610,20681]
simple_stmt [20610,20681]
===
match
---
name: self [61461,61465]
name: self [63409,63413]
===
match
---
trailer [67444,67458]
trailer [69392,69406]
===
match
---
name: dag [59709,59712]
name: dag [61657,61660]
===
match
---
name: get_num_task_instances [18136,18158]
name: get_num_task_instances [18136,18158]
===
match
---
name: task_instance [53024,53037]
name: task_instance [54972,54985]
===
match
---
name: has_task_concurrency_limits [62627,62654]
name: has_task_concurrency_limits [64575,64602]
===
match
---
expr_stmt [68306,68329]
expr_stmt [70254,70277]
===
match
---
simple_stmt [21070,21106]
simple_stmt [21070,21106]
===
match
---
name: new_value [68755,68764]
name: new_value [70703,70712]
===
match
---
number: 1 [50153,50154]
number: 1 [50153,50154]
===
match
---
string: 'test-dag' [26165,26175]
string: 'test-dag' [26165,26175]
===
match
---
name: previous_schedule [22796,22813]
name: previous_schedule [22796,22813]
===
match
---
assert_stmt [21844,21898]
assert_stmt [21844,21898]
===
match
---
name: dag [59383,59386]
name: dag [61331,61334]
===
match
---
trailer [59219,59242]
trailer [61167,61190]
===
match
---
simple_stmt [55464,55520]
simple_stmt [57412,57468]
===
match
---
name: session [2952,2959]
name: session [2952,2959]
===
match
---
atom_expr [11590,11715]
atom_expr [11590,11715]
===
match
---
name: dag [35097,35100]
name: dag [35097,35100]
===
match
---
name: dag [38700,38703]
name: dag [38700,38703]
===
match
---
name: dags [25434,25438]
name: dags [25434,25438]
===
match
---
argument [27586,27601]
argument [27586,27601]
===
match
---
operator: , [56549,56550]
operator: , [58497,58498]
===
match
---
simple_stmt [38916,38985]
simple_stmt [38916,38985]
===
match
---
name: hash [45810,45814]
name: hash [45810,45814]
===
match
---
operator: , [39145,39146]
operator: , [39145,39146]
===
match
---
operator: = [6024,6025]
operator: = [6024,6025]
===
match
---
trailer [27845,27857]
trailer [27845,27857]
===
match
---
atom_expr [39396,39410]
atom_expr [39396,39410]
===
match
---
name: add_task [40401,40409]
name: add_task [40401,40409]
===
match
---
atom_expr [33277,33294]
atom_expr [33277,33294]
===
match
---
name: utcnow [67536,67542]
name: utcnow [69484,69490]
===
match
---
funcdef [37237,37725]
funcdef [37237,37725]
===
match
---
name: SCHEDULED [28078,28087]
name: SCHEDULED [28078,28087]
===
match
---
name: pendulum [21417,21425]
name: pendulum [21417,21425]
===
match
---
name: task_id [28608,28615]
name: task_id [28608,28615]
===
match
---
simple_stmt [68361,68599]
simple_stmt [70309,70547]
===
match
---
operator: = [34193,34194]
operator: = [34193,34194]
===
match
---
name: DEFAULT_DATE [52668,52680]
name: DEFAULT_DATE [54616,54628]
===
match
---
atom_expr [15513,15703]
atom_expr [15513,15703]
===
match
---
arglist [52911,52931]
arglist [54859,54879]
===
match
---
atom_expr [36659,36674]
atom_expr [36659,36674]
===
match
---
trailer [61563,61579]
trailer [63511,63527]
===
match
---
trailer [27730,27736]
trailer [27730,27736]
===
match
---
trailer [8540,8606]
trailer [8540,8606]
===
match
---
trailer [27128,27145]
trailer [27128,27145]
===
match
---
expr_stmt [54156,54166]
expr_stmt [56104,56114]
===
match
---
operator: = [55171,55172]
operator: = [57119,57120]
===
match
---
name: filter [33568,33574]
name: filter [33568,33574]
===
match
---
arglist [21485,21553]
arglist [21485,21553]
===
match
---
param [30603,30610]
param [30603,30610]
===
match
---
atom_expr [53423,53452]
atom_expr [55371,55400]
===
match
---
trailer [5016,5020]
trailer [5016,5020]
===
match
---
string: 'owner' [54761,54768]
string: 'owner' [56709,56716]
===
match
---
name: DEFAULT_DATE [7438,7450]
name: DEFAULT_DATE [7438,7450]
===
match
---
name: dag_id [41643,41649]
name: dag_id [41643,41649]
===
match
---
name: dag [9452,9455]
name: dag [9452,9455]
===
match
---
simple_stmt [65422,65450]
simple_stmt [67370,67398]
===
match
---
atom_expr [34994,35011]
atom_expr [34994,35011]
===
match
---
arglist [61223,61239]
arglist [63171,63187]
===
match
---
name: filter [34493,34499]
name: filter [34493,34499]
===
match
---
trailer [63847,63849]
trailer [65795,65797]
===
match
---
operator: = [19080,19081]
operator: = [19080,19081]
===
match
---
arglist [50707,50850]
arglist [50707,50850]
===
match
---
atom_expr [68228,68241]
atom_expr [70176,70189]
===
match
---
argument [59512,59548]
argument [61460,61496]
===
match
---
name: path [19033,19037]
name: path [19033,19037]
===
match
---
atom_expr [63220,63276]
atom_expr [65168,65224]
===
match
---
name: sync_to_db [30316,30326]
name: sync_to_db [30316,30326]
===
match
---
name: dag_id [60855,60861]
name: dag_id [62803,62809]
===
match
---
simple_stmt [39080,39170]
simple_stmt [39080,39170]
===
match
---
simple_stmt [30654,30738]
simple_stmt [30654,30738]
===
match
---
number: 10 [59236,59238]
number: 10 [61184,61186]
===
match
---
if_stmt [15887,15927]
if_stmt [15887,15927]
===
match
---
simple_stmt [63698,63725]
simple_stmt [65646,65673]
===
match
---
trailer [56886,56895]
trailer [58834,58843]
===
match
---
expr_stmt [35873,35906]
expr_stmt [35873,35906]
===
match
---
argument [38613,38637]
argument [38613,38637]
===
match
---
arglist [8212,8252]
arglist [8212,8252]
===
match
---
name: task_id [63234,63241]
name: task_id [65182,65189]
===
match
---
comparison [6446,6467]
comparison [6446,6467]
===
match
---
expr_stmt [12507,12516]
expr_stmt [12507,12516]
===
match
---
name: freeze_time [1177,1188]
name: freeze_time [1177,1188]
===
match
---
operator: = [19992,19993]
operator: = [19992,19993]
===
match
---
simple_stmt [47375,47424]
simple_stmt [47375,47424]
===
match
---
atom_expr [53085,53104]
atom_expr [55033,55052]
===
match
---
name: TEST_DATE [23833,23842]
name: TEST_DATE [23833,23842]
===
match
---
atom_expr [69266,69276]
atom_expr [71214,71224]
===
match
---
atom_expr [6579,6607]
atom_expr [6579,6607]
===
match
---
operator: = [64851,64852]
operator: = [66799,66800]
===
match
---
trailer [62985,62987]
trailer [64933,64935]
===
match
---
operator: , [34906,34907]
operator: , [34906,34907]
===
match
---
comparison [45810,45841]
comparison [45810,45841]
===
match
---
name: sub_dag [38822,38829]
name: sub_dag [38822,38829]
===
match
---
name: args [60356,60360]
name: args [62304,62308]
===
match
---
string: 'owner1' [5976,5984]
string: 'owner1' [5976,5984]
===
match
---
trailer [6627,6631]
trailer [6627,6631]
===
match
---
simple_stmt [57160,57386]
simple_stmt [59108,59334]
===
match
---
operator: = [55216,55217]
operator: = [57164,57165]
===
match
---
operator: = [29848,29849]
operator: = [29848,29849]
===
match
---
operator: } [16542,16543]
operator: } [16542,16543]
===
match
---
trailer [47191,47205]
trailer [47191,47205]
===
match
---
name: self [56982,56986]
name: self [58930,58934]
===
match
---
operator: = [63197,63198]
operator: = [65145,65146]
===
match
---
trailer [51083,51091]
trailer [51083,51091]
===
match
---
argument [32168,32182]
argument [32168,32182]
===
match
---
argument [6546,6559]
argument [6546,6559]
===
match
---
operator: , [24570,24571]
operator: , [24570,24571]
===
match
---
name: start_date [38336,38346]
name: start_date [38336,38346]
===
match
---
name: DAG [57166,57169]
name: DAG [59114,59117]
===
match
---
name: dag_id [5555,5561]
name: dag_id [5555,5561]
===
match
---
sync_comp_for [15783,15807]
sync_comp_for [15783,15807]
===
match
---
expr_stmt [19310,19348]
expr_stmt [19310,19348]
===
match
---
trailer [29739,29747]
trailer [29739,29747]
===
match
---
operator: , [8546,8547]
operator: , [8546,8547]
===
match
---
atom_expr [22840,22862]
atom_expr [22840,22862]
===
match
---
trailer [34229,34235]
trailer [34229,34235]
===
match
---
trailer [61849,61865]
trailer [63797,63813]
===
match
---
suite [42006,42959]
suite [42006,42959]
===
match
---
atom_expr [21851,21867]
atom_expr [21851,21867]
===
match
---
name: dag [52138,52141]
name: dag [54086,54089]
===
match
---
name: tempfile [954,962]
name: tempfile [954,962]
===
match
---
expr_stmt [3393,3404]
expr_stmt [3393,3404]
===
match
---
comparison [21007,21060]
comparison [21007,21060]
===
match
---
name: all [27147,27150]
name: all [27147,27150]
===
match
---
comp_op [46051,46057]
comp_op [46051,46057]
===
match
---
with_stmt [6082,6196]
with_stmt [6082,6196]
===
match
---
operator: = [45897,45898]
operator: = [45897,45898]
===
match
---
argument [20630,20646]
argument [20630,20646]
===
match
---
arglist [48762,48786]
arglist [48762,48786]
===
match
---
comparison [29332,29405]
comparison [29332,29405]
===
match
---
string: 'owner2' [28981,28989]
string: 'owner2' [28981,28989]
===
match
---
comparison [22228,22281]
comparison [22228,22281]
===
match
---
operator: , [1496,1497]
operator: , [1496,1497]
===
match
---
operator: , [27762,27763]
operator: , [27762,27763]
===
match
---
name: dag_id [41096,41102]
name: dag_id [41096,41102]
===
match
---
trailer [67657,67661]
trailer [69605,69609]
===
match
---
suite [47047,47424]
suite [47047,47424]
===
match
---
string: '@daily' [7660,7668]
string: '@daily' [7660,7668]
===
match
---
name: filter [24380,24386]
name: filter [24380,24386]
===
match
---
trailer [27658,27660]
trailer [27658,27660]
===
match
---
suite [25277,25320]
suite [25277,25320]
===
match
---
argument [41490,41511]
argument [41490,41511]
===
match
---
trailer [51572,51604]
trailer [51572,51604]
===
match
---
trailer [68612,68621]
trailer [70560,70569]
===
match
---
assert_stmt [37682,37724]
assert_stmt [37682,37724]
===
match
---
name: session [51140,51147]
name: session [51140,51147]
===
match
---
operator: = [12513,12514]
operator: = [12513,12514]
===
match
---
operator: = [50225,50226]
operator: = [50225,50226]
===
match
---
expr_stmt [13478,13510]
expr_stmt [13478,13510]
===
match
---
expr_stmt [13593,13659]
expr_stmt [13593,13659]
===
match
---
name: op3 [38166,38169]
name: op3 [38166,38169]
===
match
---
operator: , [42591,42592]
operator: , [42591,42592]
===
match
---
name: test_dag_is_deactivated_upon_dagfile_deletion [33772,33817]
name: test_dag_is_deactivated_upon_dagfile_deletion [33772,33817]
===
match
---
operator: { [5966,5967]
operator: { [5966,5967]
===
match
---
operator: , [44577,44578]
operator: , [44577,44578]
===
match
---
number: 0 [36629,36630]
number: 0 [36629,36630]
===
match
---
trailer [35589,35595]
trailer [35589,35595]
===
match
---
atom_expr [8345,8404]
atom_expr [8345,8404]
===
match
---
arith_expr [13621,13635]
arith_expr [13621,13635]
===
match
---
operator: = [38022,38023]
operator: = [38022,38023]
===
match
---
funcdef [37730,38240]
funcdef [37730,38240]
===
match
---
funcdef [19489,20162]
funcdef [19489,20162]
===
match
---
name: topological_list [10511,10527]
name: topological_list [10511,10527]
===
match
---
argument [53961,53982]
argument [55909,55930]
===
match
---
arglist [22717,22774]
arglist [22717,22774]
===
match
---
expr_stmt [34935,34978]
expr_stmt [34935,34978]
===
match
---
name: dag_id [62580,62586]
name: dag_id [64528,64534]
===
match
---
expr_stmt [55464,55519]
expr_stmt [57412,57467]
===
match
---
string: 'dag-bulk-sync-3' [26979,26996]
string: 'dag-bulk-sync-3' [26979,26996]
===
match
---
argument [52737,52743]
argument [54685,54691]
===
match
---
with_item [25695,25722]
with_item [25695,25722]
===
match
---
name: jinja_env [18722,18731]
name: jinja_env [18722,18731]
===
match
---
operator: = [68566,68567]
operator: = [70514,70515]
===
match
---
name: airflow [1435,1442]
name: airflow [1435,1442]
===
match
---
testlist_comp [26879,26909]
testlist_comp [26879,26909]
===
match
---
trailer [51147,51153]
trailer [51147,51153]
===
match
---
atom_expr [61648,61690]
atom_expr [63596,63638]
===
match
---
name: op1 [37169,37172]
name: op1 [37169,37172]
===
match
---
name: dag [44868,44871]
name: dag [44868,44871]
===
match
---
string: 'test-default_orientation' [5562,5588]
string: 'test-default_orientation' [5562,5588]
===
match
---
trailer [45700,45705]
trailer [45700,45705]
===
match
---
trailer [67121,67134]
trailer [69069,69082]
===
match
---
sync_comp_for [47409,47422]
sync_comp_for [47409,47422]
===
match
---
trailer [21751,21759]
trailer [21751,21759]
===
match
---
operator: , [20400,20401]
operator: , [20400,20401]
===
match
---
operator: , [2339,2340]
operator: , [2339,2340]
===
match
---
simple_stmt [16780,16804]
simple_stmt [16780,16804]
===
match
---
param [30597,30602]
param [30597,30602]
===
match
---
expr_stmt [9684,9716]
expr_stmt [9684,9716]
===
match
---
number: 3 [47365,47366]
number: 3 [47365,47366]
===
match
---
simple_stmt [31593,31695]
simple_stmt [31593,31695]
===
match
---
atom [15421,15440]
atom [15421,15440]
===
match
---
trailer [32740,32742]
trailer [32740,32742]
===
match
---
name: list_ [3183,3188]
name: list_ [3183,3188]
===
match
---
name: op3 [38071,38074]
name: op3 [38071,38074]
===
match
---
funcdef [10986,11886]
funcdef [10986,11886]
===
match
---
name: create_session [25695,25709]
name: create_session [25695,25709]
===
match
---
name: max_active_runs [27517,27532]
name: max_active_runs [27517,27532]
===
match
---
atom_expr [63734,63751]
atom_expr [65682,65699]
===
match
---
atom_expr [19674,19697]
atom_expr [19674,19697]
===
match
---
parameters [67848,67854]
parameters [69796,69802]
===
match
---
argument [56050,56085]
argument [57998,58033]
===
match
---
name: next_date [57395,57404]
name: next_date [59343,59352]
===
match
---
name: tasks [9139,9144]
name: tasks [9139,9144]
===
match
---
string: 'op1' [6132,6137]
string: 'op1' [6132,6137]
===
match
---
operator: , [36086,36087]
operator: , [36086,36087]
===
match
---
name: depth [13077,13082]
name: depth [13077,13082]
===
match
---
funcdef [66207,66255]
funcdef [68155,68203]
===
match
---
simple_stmt [16319,16362]
simple_stmt [16319,16362]
===
match
---
trailer [57643,57654]
trailer [59591,59602]
===
match
---
name: TestCase [2423,2431]
name: TestCase [2423,2431]
===
match
---
atom_expr [18755,18781]
atom_expr [18755,18781]
===
match
---
name: next_date [56359,56368]
name: next_date [58307,58316]
===
match
---
trailer [63931,63933]
trailer [65879,65881]
===
match
---
trailer [12582,12604]
trailer [12582,12604]
===
match
---
name: current_task [13223,13235]
name: current_task [13223,13235]
===
match
---
name: DummyOperator [9645,9658]
name: DummyOperator [9645,9658]
===
match
---
name: dag [40140,40143]
name: dag [40140,40143]
===
match
---
name: create_dagrun [41346,41359]
name: create_dagrun [41346,41359]
===
match
---
operator: } [12985,12986]
operator: } [12985,12986]
===
match
---
trailer [24426,24428]
trailer [24426,24428]
===
match
---
assert_stmt [32624,32654]
assert_stmt [32624,32654]
===
match
---
trailer [18731,18739]
trailer [18731,18739]
===
match
---
operator: == [20485,20487]
operator: == [20485,20487]
===
match
---
trailer [27074,27078]
trailer [27074,27078]
===
match
---
assert_stmt [36644,36674]
assert_stmt [36644,36674]
===
match
---
operator: >> [8010,8012]
operator: >> [8010,8012]
===
match
---
atom_expr [29985,30030]
atom_expr [29985,30030]
===
match
---
name: delete [34650,34656]
name: delete [34650,34656]
===
match
---
operator: - [55360,55361]
operator: - [57308,57309]
===
match
---
name: start [20641,20646]
name: start [20641,20646]
===
match
---
operator: { [25743,25744]
operator: { [25743,25744]
===
match
---
name: set_upstream [14732,14744]
name: set_upstream [14732,14744]
===
match
---
simple_stmt [23969,24007]
simple_stmt [23969,24007]
===
match
---
argument [43979,43996]
argument [43979,43996]
===
match
---
operator: = [33090,33091]
operator: = [33090,33091]
===
match
---
operator: <= [3481,3483]
operator: <= [3481,3483]
===
match
---
trailer [46247,46254]
trailer [46247,46254]
===
match
---
operator: , [5951,5952]
operator: , [5951,5952]
===
match
---
operator: = [55686,55687]
operator: = [57634,57635]
===
match
---
atom_expr [17379,17388]
atom_expr [17379,17388]
===
match
---
atom_expr [46224,46315]
atom_expr [46224,46315]
===
match
---
name: prev_task [13270,13279]
name: prev_task [13270,13279]
===
match
---
name: j [14243,14244]
name: j [14243,14244]
===
match
---
trailer [64898,64910]
trailer [66846,66858]
===
match
---
name: prev_task [14745,14754]
name: prev_task [14745,14754]
===
match
---
name: priority_weight [15601,15616]
name: priority_weight [15601,15616]
===
match
---
trailer [22532,22549]
trailer [22532,22549]
===
match
---
name: orm_dag [30489,30496]
name: orm_dag [30489,30496]
===
match
---
name: DummyOperator [35352,35365]
name: DummyOperator [35352,35365]
===
match
---
expr_stmt [4363,4395]
expr_stmt [4363,4395]
===
match
---
number: 2 [64446,64447]
number: 2 [66394,66395]
===
match
---
name: is_paused_upon_creation [45951,45974]
name: is_paused_upon_creation [45951,45974]
===
match
---
simple_stmt [65061,65077]
simple_stmt [67009,67025]
===
match
---
param [35152,35156]
param [35152,35156]
===
match
---
simple_stmt [31137,31161]
simple_stmt [31137,31161]
===
match
---
trailer [42754,42756]
trailer [42754,42756]
===
match
---
operator: == [29519,29521]
operator: == [29519,29521]
===
match
---
suite [26445,26486]
suite [26445,26486]
===
match
---
name: RUNNING [27991,27998]
name: RUNNING [27991,27998]
===
match
---
operator: , [57347,57348]
operator: , [59295,59296]
===
match
---
atom [25929,26340]
atom [25929,26340]
===
match
---
name: params1 [4381,4388]
name: params1 [4381,4388]
===
match
---
argument [47558,47584]
argument [47558,47584]
===
match
---
name: dag_models [62943,62953]
name: dag_models [64891,64901]
===
match
---
trailer [64479,64623]
trailer [66427,66571]
===
match
---
operator: = [21529,21530]
operator: = [21529,21530]
===
match
---
suite [48130,48394]
suite [48130,48394]
===
match
---
decorator [65596,65643]
decorator [67544,67591]
===
match
---
number: 2015 [57287,57291]
number: 2015 [59235,59239]
===
match
---
operator: = [51033,51034]
operator: = [51033,51034]
===
match
---
simple_stmt [8109,8178]
simple_stmt [8109,8178]
===
match
---
simple_stmt [6104,6139]
simple_stmt [6104,6139]
===
match
---
name: DagModel [34500,34508]
name: DagModel [34500,34508]
===
match
---
simple_stmt [23657,23689]
simple_stmt [23657,23689]
===
match
---
name: hours [55569,55574]
name: hours [57517,57522]
===
match
---
name: dag [53361,53364]
name: dag [55309,55312]
===
match
---
name: RUNNING [52309,52316]
name: RUNNING [54257,54264]
===
match
---
operator: , [50199,50200]
operator: , [50199,50200]
===
match
---
trailer [29191,29198]
trailer [29191,29198]
===
match
---
name: dag [1590,1593]
name: dag [1590,1593]
===
match
---
operator: , [55420,55421]
operator: , [57368,57369]
===
match
---
trailer [16073,16084]
trailer [16073,16084]
===
match
---
simple_stmt [34794,34840]
simple_stmt [34794,34840]
===
match
---
suite [14694,14756]
suite [14694,14756]
===
match
---
trailer [53763,53772]
trailer [55711,55720]
===
match
---
number: 1 [57296,57297]
number: 1 [59244,59245]
===
match
---
parameters [10590,10596]
parameters [10590,10596]
===
match
---
name: PRE_TRANSITION [22636,22650]
name: PRE_TRANSITION [22636,22650]
===
match
---
name: pendulum [34805,34813]
name: pendulum [34805,34813]
===
match
---
name: task_instance_1 [50933,50948]
name: task_instance_1 [50933,50948]
===
match
---
string: 'test_clear_set_dagrun_state' [48580,48609]
string: 'test_clear_set_dagrun_state' [48580,48609]
===
match
---
operator: = [22513,22514]
operator: = [22513,22514]
===
match
---
simple_stmt [30434,30474]
simple_stmt [30434,30474]
===
match
---
expr_stmt [7322,7461]
expr_stmt [7322,7461]
===
match
---
name: Session [17432,17439]
name: Session [17432,17439]
===
match
---
trailer [58695,58718]
trailer [60643,60666]
===
match
---
name: VALUE [67175,67180]
name: VALUE [69123,69128]
===
match
---
operator: = [46640,46641]
operator: = [46640,46641]
===
match
---
name: self [69266,69270]
name: self [71214,71218]
===
match
---
name: normalized_schedule_interval [46889,46917]
name: normalized_schedule_interval [46889,46917]
===
match
---
name: super [65034,65039]
name: super [66982,66987]
===
match
---
argument [43513,43532]
argument [43513,43532]
===
match
---
operator: = [47491,47492]
operator: = [47491,47492]
===
match
---
name: isoformat [21793,21802]
name: isoformat [21793,21802]
===
match
---
name: Session [33023,33030]
name: Session [33023,33030]
===
match
---
atom_expr [17885,17972]
atom_expr [17885,17972]
===
match
---
name: DEFAULT_DATE [52703,52715]
name: DEFAULT_DATE [54651,54663]
===
match
---
string: 'op4' [6554,6559]
string: 'op4' [6554,6559]
===
match
---
operator: , [23820,23821]
operator: , [23820,23821]
===
match
---
argument [48169,48210]
argument [48169,48210]
===
match
---
name: task [19971,19975]
name: task [19971,19975]
===
match
---
name: self [32918,32922]
name: self [32918,32922]
===
match
---
trailer [63674,63683]
trailer [65622,65631]
===
match
---
atom_expr [60216,60375]
atom_expr [62164,62323]
===
match
---
atom_expr [66876,66900]
atom_expr [68824,68848]
===
match
---
operator: , [53448,53449]
operator: , [55396,55397]
===
match
---
operator: = [36912,36913]
operator: = [36912,36913]
===
match
---
name: dumps [45263,45268]
name: dumps [45263,45268]
===
match
---
atom [61522,61580]
atom [63470,63528]
===
match
---
trailer [17431,17439]
trailer [17431,17439]
===
match
---
simple_stmt [22424,22496]
simple_stmt [22424,22496]
===
match
---
operator: = [48927,48928]
operator: = [48927,48928]
===
match
---
trailer [49137,49145]
trailer [49137,49145]
===
match
---
name: DagModel [31844,31852]
name: DagModel [31844,31852]
===
match
---
operator: { [12987,12988]
operator: { [12987,12988]
===
match
---
atom_expr [58477,58514]
atom_expr [60425,60462]
===
match
---
string: '*/10 * * * *' [55687,55701]
string: '*/10 * * * *' [57635,57649]
===
match
---
with_stmt [6341,6399]
with_stmt [6341,6399]
===
match
---
string: 'dag-bulk-sync-1' [25006,25023]
string: 'dag-bulk-sync-1' [25006,25023]
===
match
---
name: topological_list [9202,9218]
name: topological_list [9202,9218]
===
match
---
name: timedelta [58172,58181]
name: timedelta [60120,60129]
===
match
---
name: roots [35590,35595]
name: roots [35590,35595]
===
match
---
name: prev_local [21782,21792]
name: prev_local [21782,21792]
===
match
---
operator: , [60281,60282]
operator: , [62229,62230]
===
match
---
operator: , [62382,62383]
operator: , [64330,64331]
===
match
---
name: test_is_paused_subdag [30575,30596]
name: test_is_paused_subdag [30575,30596]
===
match
---
name: DAG [29850,29853]
name: DAG [29850,29853]
===
match
---
name: dag [47775,47778]
name: dag [47775,47778]
===
match
---
name: task [1337,1341]
name: task [1337,1341]
===
match
---
comparison [33639,33667]
comparison [33639,33667]
===
match
---
comparison [47353,47366]
comparison [47353,47366]
===
match
---
param [36117,36121]
param [36117,36121]
===
match
---
atom_expr [38204,38215]
atom_expr [38204,38215]
===
match
---
atom_expr [30771,30837]
atom_expr [30771,30837]
===
match
---
trailer [21080,21098]
trailer [21080,21098]
===
match
---
operator: - [54386,54387]
operator: - [56334,56335]
===
match
---
name: BaseOperator [42363,42375]
name: BaseOperator [42363,42375]
===
match
---
name: test_task_id [18186,18198]
name: test_task_id [18186,18198]
===
match
---
name: self [37305,37309]
name: self [37305,37309]
===
match
---
atom_expr [54380,54389]
atom_expr [56328,56337]
===
match
---
atom [32424,32438]
atom [32424,32438]
===
match
---
simple_stmt [32567,32591]
simple_stmt [32567,32591]
===
match
---
name: task [19910,19914]
name: task [19910,19914]
===
match
---
name: isinstance [3759,3769]
name: isinstance [3759,3769]
===
match
---
trailer [58775,58787]
trailer [60723,60735]
===
match
---
argument [68905,68935]
argument [70853,70883]
===
match
---
name: execution_date [17064,17078]
name: execution_date [17064,17078]
===
match
---
trailer [32638,32652]
trailer [32638,32652]
===
match
---
number: 1 [13648,13649]
number: 1 [13648,13649]
===
match
---
atom_expr [6722,6731]
atom_expr [6722,6731]
===
match
---
comparison [22005,22058]
comparison [22005,22058]
===
match
---
name: i [24595,24596]
name: i [24595,24596]
===
match
---
name: task_id [59319,59326]
name: task_id [61267,61274]
===
match
---
argument [43439,43464]
argument [43439,43464]
===
match
---
name: next_date [53349,53358]
name: next_date [55297,55306]
===
match
---
expr_stmt [10037,10078]
expr_stmt [10037,10078]
===
match
---
operator: == [30510,30512]
operator: == [30510,30512]
===
match
---
name: RUNNING [43525,43532]
name: RUNNING [43525,43532]
===
match
---
operator: { [18538,18539]
operator: { [18538,18539]
===
match
---
operator: , [60861,60862]
operator: , [62809,62810]
===
match
---
atom_expr [47929,47949]
atom_expr [47929,47949]
===
match
---
operator: , [61865,61866]
operator: , [63813,63814]
===
match
---
operator: = [59273,59274]
operator: = [61221,61222]
===
match
---
operator: { [25929,25930]
operator: { [25929,25930]
===
match
---
operator: = [56234,56235]
operator: = [58182,58183]
===
match
---
trailer [23016,23035]
trailer [23016,23035]
===
match
---
operator: = [18238,18239]
operator: = [18238,18239]
===
match
---
comparison [52911,52930]
comparison [54859,54878]
===
match
---
trailer [42821,42828]
trailer [42821,42828]
===
match
---
name: dag_id [42179,42185]
name: dag_id [42179,42185]
===
match
---
operator: = [16660,16661]
operator: = [16660,16661]
===
match
---
name: DEFAULT_DATE [9480,9492]
name: DEFAULT_DATE [9480,9492]
===
match
---
fstring_expr [60470,60477]
fstring_expr [62418,62425]
===
match
---
atom_expr [24112,24127]
atom_expr [24112,24127]
===
match
---
trailer [59834,59854]
trailer [61782,61802]
===
match
---
name: rollback [62977,62985]
name: rollback [64925,64933]
===
match
---
name: task_depth [13621,13631]
name: task_depth [13621,13631]
===
match
---
comparison [2977,2996]
comparison [2977,2996]
===
match
---
trailer [8134,8177]
trailer [8134,8177]
===
match
---
trailer [66408,66414]
trailer [68356,68362]
===
match
---
simple_stmt [42492,42509]
simple_stmt [42492,42509]
===
match
---
name: getvalue [36531,36539]
name: getvalue [36531,36539]
===
match
---
name: owners [29192,29198]
name: owners [29192,29198]
===
match
---
operator: , [50398,50399]
operator: , [50398,50399]
===
match
---
trailer [53218,53339]
trailer [55166,55287]
===
match
---
atom_expr [65369,65382]
atom_expr [67317,67330]
===
match
---
trailer [55602,55789]
trailer [57550,57737]
===
match
---
arglist [37402,37478]
arglist [37402,37478]
===
match
---
name: DAG [25655,25658]
name: DAG [25655,25658]
===
match
---
trailer [63774,63780]
trailer [65722,65728]
===
match
---
simple_stmt [41342,41523]
simple_stmt [41342,41523]
===
match
---
simple_stmt [9367,9401]
simple_stmt [9367,9401]
===
match
---
name: DEFAULT_DATE [17328,17340]
name: DEFAULT_DATE [17328,17340]
===
match
---
simple_stmt [12253,12338]
simple_stmt [12253,12338]
===
match
---
name: jinja_env [18660,18669]
name: jinja_env [18660,18669]
===
match
---
simple_stmt [28487,28564]
simple_stmt [28487,28564]
===
match
---
operator: = [64598,64599]
operator: = [66546,66547]
===
match
---
simple_stmt [18424,18440]
simple_stmt [18424,18440]
===
match
---
name: TEST_DATE [39518,39527]
name: TEST_DATE [39518,39527]
===
match
---
number: 1 [17118,17119]
number: 1 [17118,17119]
===
match
---
import_from [2236,2293]
import_from [2236,2293]
===
match
---
trailer [14409,14419]
trailer [14409,14419]
===
match
---
operator: = [37947,37948]
operator: = [37947,37948]
===
match
---
argument [47386,47422]
argument [47386,47422]
===
match
---
name: dag [44796,44799]
name: dag [44796,44799]
===
match
---
operator: , [46755,46756]
operator: , [46755,46756]
===
match
---
operator: = [48782,48783]
operator: = [48782,48783]
===
match
---
atom_expr [27106,27152]
atom_expr [27106,27152]
===
match
---
operator: , [13115,13116]
operator: , [13115,13116]
===
match
---
trailer [3769,3787]
trailer [3769,3787]
===
match
---
number: 4 [59477,59478]
number: 4 [61425,61426]
===
match
---
operator: = [47791,47792]
operator: = [47791,47792]
===
match
---
operator: , [43425,43426]
operator: , [43425,43426]
===
match
---
operator: = [21415,21416]
operator: = [21415,21416]
===
match
---
name: default_args [66035,66047]
name: default_args [67983,67995]
===
match
---
name: settings [17423,17431]
name: settings [17423,17431]
===
match
---
operator: , [50642,50643]
operator: , [50642,50643]
===
match
---
name: session [25859,25866]
name: session [25859,25866]
===
match
---
number: 1 [13507,13508]
number: 1 [13507,13508]
===
match
---
trailer [44781,44793]
trailer [44781,44793]
===
match
---
number: 2018 [12129,12133]
number: 2018 [12129,12133]
===
match
---
expr_stmt [52532,52560]
expr_stmt [54480,54508]
===
match
---
trailer [17783,17806]
trailer [17783,17806]
===
match
---
name: suffix [18922,18928]
name: suffix [18922,18928]
===
match
---
name: session [17504,17511]
name: session [17504,17511]
===
match
---
atom_expr [43403,43425]
atom_expr [43403,43425]
===
match
---
operator: = [16822,16823]
operator: = [16822,16823]
===
match
---
arglist [15798,15806]
arglist [15798,15806]
===
match
---
name: dag_id [51943,51949]
name: dag_id [53891,53897]
===
match
---
string: 'test-dag' [25074,25084]
string: 'test-dag' [25074,25084]
===
match
---
atom_expr [52465,52523]
atom_expr [54413,54471]
===
match
---
argument [62448,62463]
argument [64396,64411]
===
match
---
trailer [43423,43425]
trailer [43423,43425]
===
match
---
name: self [67005,67009]
name: self [68953,68957]
===
match
---
simple_stmt [43349,43580]
simple_stmt [43349,43580]
===
match
---
name: dag [41157,41160]
name: dag [41157,41160]
===
match
---
operator: , [38220,38221]
operator: , [38220,38221]
===
match
---
operator: = [34914,34915]
operator: = [34914,34915]
===
match
---
dotted_name [46322,46342]
dotted_name [46322,46342]
===
match
---
atom_expr [41342,41522]
atom_expr [41342,41522]
===
match
---
name: isoformat [22890,22899]
name: isoformat [22890,22899]
===
match
---
operator: = [44017,44018]
operator: = [44017,44018]
===
match
---
name: run_type [40540,40548]
name: run_type [40540,40548]
===
match
---
trailer [41617,41623]
trailer [41617,41623]
===
match
---
operator: = [50391,50392]
operator: = [50391,50392]
===
match
---
name: dag [61967,61970]
name: dag [63915,63918]
===
match
---
trailer [66310,66312]
trailer [68258,68260]
===
match
---
name: permissions [61648,61659]
name: permissions [63596,63607]
===
match
---
operator: , [56638,56639]
operator: , [58586,58587]
===
match
---
atom_expr [50994,51007]
atom_expr [50994,51007]
===
match
---
name: DEFAULT_DATE [67706,67718]
name: DEFAULT_DATE [69654,69666]
===
match
---
parameters [63987,63993]
parameters [65935,65941]
===
match
---
name: tests [2241,2246]
name: tests [2241,2246]
===
match
---
name: DEFAULT_DATE [50123,50135]
name: DEFAULT_DATE [50123,50135]
===
match
---
name: DagModel [33433,33441]
name: DagModel [33433,33441]
===
match
---
atom_expr [40721,40782]
atom_expr [40721,40782]
===
match
---
name: RUNNING [51084,51091]
name: RUNNING [51084,51091]
===
match
---
atom_expr [40519,40532]
atom_expr [40519,40532]
===
match
---
atom_expr [62222,62240]
atom_expr [64170,64188]
===
match
---
trailer [63653,63674]
trailer [65601,65622]
===
match
---
name: prev_local [21730,21740]
name: prev_local [21730,21740]
===
match
---
name: create_dagrun [50473,50486]
name: create_dagrun [50473,50486]
===
match
---
atom_expr [44047,44071]
atom_expr [44047,44071]
===
match
---
name: test_set_params_for_dag [68774,68797]
name: test_set_params_for_dag [70722,70745]
===
match
---
operator: = [42237,42238]
operator: = [42237,42238]
===
match
---
atom_expr [30394,30409]
atom_expr [30394,30409]
===
match
---
operator: = [40323,40324]
operator: = [40323,40324]
===
match
---
operator: = [20640,20641]
operator: = [20640,20641]
===
match
---
simple_stmt [10037,10079]
simple_stmt [10037,10079]
===
match
---
name: hours [53764,53769]
name: hours [55712,55717]
===
match
---
name: dag_id [59141,59147]
name: dag_id [61089,61095]
===
match
---
name: test_schedule_dag_once [41977,41999]
name: test_schedule_dag_once [41977,41999]
===
match
---
arglist [62359,62424]
arglist [64307,64372]
===
match
---
simple_stmt [59118,59297]
simple_stmt [61066,61245]
===
match
---
name: test_dag_id [18172,18183]
name: test_dag_id [18172,18183]
===
match
---
trailer [28955,29005]
trailer [28955,29005]
===
match
---
name: task_decorator [65685,65699]
name: task_decorator [67633,67647]
===
match
---
name: add_task [43214,43222]
name: add_task [43214,43222]
===
match
---
simple_stmt [17504,17523]
simple_stmt [17504,17523]
===
match
---
trailer [17690,17713]
trailer [17690,17713]
===
match
---
name: default_args [66600,66612]
name: default_args [68548,68560]
===
match
---
operator: , [58565,58566]
operator: , [60513,60514]
===
match
---
trailer [48933,48940]
trailer [48933,48940]
===
match
---
fstring_start: f' [64370,64372]
fstring_start: f' [66318,66320]
===
match
---
name: dag [66339,66342]
name: dag [68287,68290]
===
match
---
string: 't3' [38810,38814]
string: 't3' [38810,38814]
===
match
---
trailer [33717,33721]
trailer [33717,33721]
===
match
---
operator: @ [2752,2753]
operator: @ [2752,2753]
===
match
---
comparison [21235,21246]
comparison [21235,21246]
===
match
---
name: datetime [51289,51297]
name: datetime [51289,51297]
===
match
---
name: dirname [19038,19045]
name: dirname [19038,19045]
===
match
---
atom_expr [48928,48940]
atom_expr [48928,48940]
===
match
---
parameters [10885,10891]
parameters [10885,10891]
===
match
---
operator: = [60316,60317]
operator: = [62264,62265]
===
match
---
atom [31938,31957]
atom [31938,31957]
===
match
---
operator: == [20804,20806]
operator: == [20804,20806]
===
match
---
trailer [12160,12169]
trailer [12160,12169]
===
match
---
fstring_string: . [14241,14242]
fstring_string: . [14241,14242]
===
match
---
simple_stmt [788,804]
simple_stmt [788,804]
===
match
---
name: TEST_DATE [39158,39167]
name: TEST_DATE [39158,39167]
===
match
---
operator: = [47230,47231]
operator: = [47230,47231]
===
match
---
name: create_dagrun [43359,43372]
name: create_dagrun [43359,43372]
===
match
---
operator: = [54917,54918]
operator: = [56865,56866]
===
match
---
operator: = [18207,18208]
operator: = [18207,18208]
===
match
---
name: DagModel [34253,34261]
name: DagModel [34253,34261]
===
match
---
operator: = [37953,37954]
operator: = [37953,37954]
===
match
---
name: DagTag [25186,25192]
name: DagTag [25186,25192]
===
match
---
operator: , [37513,37514]
operator: , [37513,37514]
===
match
---
simple_stmt [9281,9317]
simple_stmt [9281,9317]
===
match
---
atom_expr [20920,20946]
atom_expr [20920,20946]
===
match
---
import_as_names [2326,2354]
import_as_names [2326,2354]
===
match
---
name: session [24273,24280]
name: session [24273,24280]
===
match
---
simple_stmt [65369,65383]
simple_stmt [67317,67331]
===
match
---
name: orm_dag [62828,62835]
name: orm_dag [64776,64783]
===
match
---
string: """Test that dag param is correctly resolved by operator""" [67020,67079]
string: """Test that dag param is correctly resolved by operator""" [68968,69027]
===
match
---
string: 'owner' [44243,44250]
string: 'owner' [44243,44250]
===
match
---
atom [15473,15821]
atom [15473,15821]
===
match
---
comparison [24387,24421]
comparison [24387,24421]
===
match
---
trailer [23239,23257]
trailer [23239,23257]
===
match
---
name: tearDown [64036,64044]
name: tearDown [65984,65992]
===
match
---
name: start_date [18584,18594]
name: start_date [18584,18594]
===
match
---
operator: = [17177,17178]
operator: = [17177,17178]
===
match
---
name: test_sub_dag_updates_all_references_while_deepcopy [38249,38299]
name: test_sub_dag_updates_all_references_while_deepcopy [38249,38299]
===
match
---
trailer [39481,39488]
trailer [39481,39488]
===
match
---
operator: = [54089,54090]
operator: = [56037,56038]
===
match
---
atom_expr [3328,3344]
atom_expr [3328,3344]
===
match
---
atom [44702,44763]
atom [44702,44763]
===
match
---
name: all [26771,26774]
name: all [26771,26774]
===
match
---
trailer [19975,19991]
trailer [19975,19991]
===
match
---
trailer [31933,31937]
trailer [31933,31937]
===
match
---
trailer [50315,50355]
trailer [50315,50355]
===
match
---
trailer [49223,49229]
trailer [49223,49229]
===
match
---
name: task_id [6546,6553]
name: task_id [6546,6553]
===
match
---
name: dag_id [47140,47146]
name: dag_id [47140,47146]
===
match
---
name: DAG [43962,43965]
name: DAG [43962,43965]
===
match
---
operator: , [17818,17819]
operator: , [17818,17819]
===
match
---
string: 'owner1' [12893,12901]
string: 'owner1' [12893,12901]
===
match
---
trailer [16960,17005]
trailer [16960,17005]
===
match
---
atom [68567,68587]
atom [70515,70535]
===
match
---
trailer [47557,47632]
trailer [47557,47632]
===
match
---
simple_stmt [34212,34286]
simple_stmt [34212,34286]
===
match
---
simple_stmt [21952,21989]
simple_stmt [21952,21989]
===
match
---
name: datetime [62748,62756]
name: datetime [64696,64704]
===
match
---
name: is_active [29259,29268]
name: is_active [29259,29268]
===
match
---
operator: } [10835,10836]
operator: } [10835,10836]
===
match
---
trailer [63341,63573]
trailer [65289,65521]
===
match
---
trailer [44064,44071]
trailer [44064,44071]
===
match
---
simple_stmt [59744,59789]
simple_stmt [61692,61737]
===
match
---
atom_expr [45683,45692]
atom_expr [45683,45692]
===
match
---
funcdef [16677,18440]
funcdef [16677,18440]
===
match
---
simple_stmt [61313,61407]
simple_stmt [63261,63355]
===
match
---
argument [6784,6807]
argument [6784,6807]
===
match
---
decorated [68996,69072]
decorated [70944,71020]
===
match
---
atom_expr [19971,19991]
atom_expr [19971,19991]
===
match
---
name: DagRunType [52260,52270]
name: DagRunType [54208,54218]
===
match
---
simple_stmt [65528,65587]
simple_stmt [67476,67535]
===
match
---
operator: } [24543,24544]
operator: } [24543,24544]
===
match
---
atom_expr [33303,33318]
atom_expr [33303,33318]
===
match
---
atom_expr [6532,6560]
atom_expr [6532,6560]
===
match
---
comparison [23911,23959]
comparison [23911,23959]
===
match
---
trailer [50876,50882]
trailer [50876,50882]
===
match
---
atom_expr [25490,25516]
atom_expr [25490,25516]
===
match
---
name: dags [26557,26561]
name: dags [26557,26561]
===
match
---
arith_expr [49289,49330]
arith_expr [49289,49330]
===
match
---
name: session [52414,52421]
name: session [54362,54369]
===
match
---
atom_expr [64770,64787]
atom_expr [66718,66735]
===
match
---
name: clear_db_runs [2670,2683]
name: clear_db_runs [2670,2683]
===
match
---
string: "t3" [36371,36375]
string: "t3" [36371,36375]
===
match
---
parameters [53193,53199]
parameters [55141,55147]
===
match
---
atom_expr [4281,4353]
atom_expr [4281,4353]
===
match
---
expr_stmt [19710,19750]
expr_stmt [19710,19750]
===
match
---
argument [38590,38611]
argument [38590,38611]
===
match
---
atom_expr [27752,27762]
atom_expr [27752,27762]
===
match
---
operator: = [24194,24195]
operator: = [24194,24195]
===
match
---
operator: , [17831,17832]
operator: , [17831,17832]
===
match
---
name: dag [7179,7182]
name: dag [7179,7182]
===
match
---
name: path [19729,19733]
name: path [19729,19733]
===
match
---
name: DAG [10612,10615]
name: DAG [10612,10615]
===
match
---
expr_stmt [30654,30737]
expr_stmt [30654,30737]
===
match
---
simple_stmt [1817,1858]
simple_stmt [1817,1858]
===
match
---
name: settings [12057,12065]
name: settings [12057,12065]
===
match
---
name: run_type [50707,50715]
name: run_type [50707,50715]
===
match
---
operator: , [51251,51252]
operator: , [51251,51252]
===
match
---
name: State [39658,39663]
name: State [39658,39663]
===
match
---
comparison [39382,39410]
comparison [39382,39410]
===
match
---
trailer [9132,9135]
trailer [9132,9135]
===
match
---
operator: = [56197,56198]
operator: = [58145,58146]
===
match
---
name: sub_dag [38657,38664]
name: sub_dag [38657,38664]
===
match
---
comparison [28143,28157]
comparison [28143,28157]
===
match
---
argument [60601,60641]
argument [62549,62589]
===
match
---
name: TI [49089,49091]
name: TI [49089,49091]
===
match
---
name: subdag [50404,50410]
name: subdag [50404,50410]
===
match
---
expr_stmt [11584,11715]
expr_stmt [11584,11715]
===
match
---
name: next_dagrun_after_date [59387,59409]
name: next_dagrun_after_date [61335,61357]
===
match
---
simple_stmt [52414,52438]
simple_stmt [54362,54386]
===
match
---
name: utils [2022,2027]
name: utils [2022,2027]
===
match
---
atom_expr [19125,19199]
atom_expr [19125,19199]
===
match
---
atom_expr [58172,58189]
atom_expr [60120,60137]
===
match
---
file_input [788,69277]
file_input [788,71225]
===
match
---
dictorsetmaker [26625,26699]
dictorsetmaker [26625,26699]
===
match
---
suite [22415,23442]
suite [22415,23442]
===
match
---
funcdef [3159,3502]
funcdef [3159,3502]
===
match
---
number: 1 [23686,23687]
number: 1 [23686,23687]
===
match
---
assert_stmt [59424,59479]
assert_stmt [61372,61427]
===
match
---
operator: , [14294,14295]
operator: , [14294,14295]
===
match
---
operator: , [47613,47614]
operator: , [47613,47614]
===
match
---
operator: , [17846,17847]
operator: , [17846,17847]
===
match
---
name: dag [29968,29971]
name: dag [29968,29971]
===
match
---
parameters [68092,68097]
parameters [70040,70045]
===
match
---
atom_expr [23703,23746]
atom_expr [23703,23746]
===
match
---
string: "test_dagrun_query_count" [64504,64529]
string: "test_dagrun_query_count" [66452,66477]
===
match
---
funcdef [65308,65356]
funcdef [67256,67304]
===
match
---
operator: = [31001,31002]
operator: = [31001,31002]
===
match
---
atom_expr [29751,29766]
atom_expr [29751,29766]
===
match
---
name: run_type [39220,39228]
name: run_type [39220,39228]
===
match
---
trailer [22238,22248]
trailer [22238,22248]
===
match
---
name: dag_run [40637,40644]
name: dag_run [40637,40644]
===
match
---
operator: = [58358,58359]
operator: = [60306,60307]
===
match
---
name: DummyOperator [59678,59691]
name: DummyOperator [61626,61639]
===
match
---
name: _occur_before [8425,8438]
name: _occur_before [8425,8438]
===
match
---
name: local_tz [21127,21135]
name: local_tz [21127,21135]
===
match
---
atom_expr [55085,55121]
atom_expr [57033,57069]
===
match
---
name: session [41581,41588]
name: session [41581,41588]
===
match
---
string: "test_dag_callback_crash" [39989,40014]
string: "test_dag_callback_crash" [39989,40014]
===
match
---
argument [62474,62489]
argument [64422,64437]
===
match
---
argument [12363,12396]
argument [12363,12396]
===
match
---
expr_stmt [21730,21765]
expr_stmt [21730,21765]
===
match
---
name: test_next_dagrun_after_fake_scheduled_previous [40844,40890]
name: test_next_dagrun_after_fake_scheduled_previous [40844,40890]
===
match
---
trailer [37502,37539]
trailer [37502,37539]
===
match
---
dictorsetmaker [12884,12901]
dictorsetmaker [12884,12901]
===
match
---
param [63061,63065]
param [65009,65013]
===
match
---
atom [24832,24918]
atom [24832,24918]
===
match
---
atom_expr [24253,24269]
atom_expr [24253,24269]
===
match
---
name: op2 [55251,55254]
name: op2 [57199,57202]
===
match
---
string: '0 3 * * *' [21666,21677]
string: '0 3 * * *' [21666,21677]
===
match
---
name: set_is_paused [31738,31751]
name: set_is_paused [31738,31751]
===
match
---
arglist [60237,60361]
arglist [62185,62309]
===
match
---
argument [60800,60819]
argument [62748,62767]
===
match
---
string: 'test_scheduler_auto_align_2' [59519,59548]
string: 'test_scheduler_auto_align_2' [61467,61496]
===
match
---
name: access_control [62011,62025]
name: access_control [63959,63973]
===
match
---
atom_expr [63954,63971]
atom_expr [65902,65919]
===
match
---
trailer [2620,2626]
trailer [2620,2626]
===
match
---
name: pipeline [14531,14539]
name: pipeline [14531,14539]
===
match
---
suite [28581,29006]
suite [28581,29006]
===
match
---
atom [51804,51837]
atom [53752,53785]
===
match
---
simple_stmt [61476,61703]
simple_stmt [63424,63651]
===
match
---
name: owner [63260,63265]
name: owner [65208,65213]
===
match
---
trailer [21698,21716]
trailer [21698,21716]
===
match
---
name: settings [12173,12181]
name: settings [12173,12181]
===
match
---
name: model [28203,28208]
name: model [28203,28208]
===
match
---
parameters [62333,62339]
parameters [64281,64287]
===
match
---
param [53598,53602]
param [55546,55550]
===
match
---
import_as_name [1337,1359]
import_as_name [1337,1359]
===
match
---
name: dag_id [34509,34515]
name: dag_id [34509,34515]
===
match
---
trailer [68327,68329]
trailer [70275,70277]
===
match
---
atom_expr [38320,38360]
atom_expr [38320,38360]
===
match
---
assert_stmt [5005,5081]
assert_stmt [5005,5081]
===
match
---
name: xcom_pass_to_op [68312,68327]
name: xcom_pass_to_op [70260,70275]
===
match
---
name: utcnow [56469,56475]
name: utcnow [58417,58423]
===
match
---
operator: { [14242,14243]
operator: { [14242,14243]
===
match
---
string: 'creating_dag_in_cm' [6762,6782]
string: 'creating_dag_in_cm' [6762,6782]
===
match
---
atom_expr [65869,65879]
atom_expr [67817,67827]
===
match
---
number: 2015 [53441,53445]
number: 2015 [55389,55393]
===
match
---
testlist_comp [15513,15748]
testlist_comp [15513,15748]
===
match
---
exprlist [3320,3324]
exprlist [3320,3324]
===
match
---
name: orm_dag [33639,33646]
name: orm_dag [33639,33646]
===
match
---
expr_stmt [39179,39331]
expr_stmt [39179,39331]
===
match
---
with_stmt [25448,25517]
with_stmt [25448,25517]
===
match
---
arglist [3770,3786]
arglist [3770,3786]
===
match
---
name: last_parsed_time [27129,27145]
name: last_parsed_time [27129,27145]
===
match
---
trailer [21973,21981]
trailer [21973,21981]
===
match
---
operator: = [43192,43193]
operator: = [43192,43193]
===
match
---
funcdef [53550,54459]
funcdef [55498,56407]
===
match
---
name: DagModel [62547,62555]
name: DagModel [64495,64503]
===
match
---
number: 2020 [58327,58331]
number: 2020 [60275,60279]
===
match
---
expr_stmt [56686,56731]
expr_stmt [58634,58679]
===
match
---
atom [31816,32002]
atom [31816,32002]
===
match
---
operator: , [33967,33968]
operator: , [33967,33968]
===
match
---
name: session [18086,18093]
name: session [18086,18093]
===
match
---
operator: = [63241,63242]
operator: = [65189,65190]
===
match
---
name: airflow [1822,1829]
name: airflow [1822,1829]
===
match
---
suite [25477,25517]
suite [25477,25517]
===
match
---
comparison [44861,44871]
comparison [44861,44871]
===
match
---
operator: = [64241,64242]
operator: = [66189,66190]
===
match
---
trailer [6383,6398]
trailer [6383,6398]
===
match
---
suite [6972,7093]
suite [6972,7093]
===
match
---
name: dag [45701,45704]
name: dag [45701,45704]
===
match
---
trailer [46635,46643]
trailer [46635,46643]
===
match
---
name: dag [12413,12416]
name: dag [12413,12416]
===
match
---
name: op2 [38542,38545]
name: op2 [38542,38545]
===
match
---
comparison [38654,38719]
comparison [38654,38719]
===
match
---
operator: = [22187,22188]
operator: = [22187,22188]
===
match
---
atom_expr [23862,23895]
atom_expr [23862,23895]
===
match
---
name: next_dagrun_after_date [61148,61170]
name: next_dagrun_after_date [63096,63118]
===
match
---
operator: = [59518,59519]
operator: = [61466,61467]
===
match
---
name: subdag [50673,50679]
name: subdag [50673,50679]
===
match
---
name: schedule_interval [23722,23739]
name: schedule_interval [23722,23739]
===
match
---
atom_expr [17094,17120]
atom_expr [17094,17120]
===
match
---
simple_stmt [24112,24128]
simple_stmt [24112,24128]
===
match
---
operator: , [54882,54883]
operator: , [56830,56831]
===
match
---
name: DAG [4732,4735]
name: DAG [4732,4735]
===
match
---
name: operator [67350,67358]
name: operator [69298,69306]
===
match
---
operator: , [59707,59708]
operator: , [61655,61656]
===
match
---
operator: = [14091,14092]
operator: = [14091,14092]
===
match
---
expr_stmt [8026,8099]
expr_stmt [8026,8099]
===
match
---
name: default_args [34848,34860]
name: default_args [34848,34860]
===
match
---
argument [59336,59343]
argument [61284,61291]
===
match
---
name: topological_list [8026,8042]
name: topological_list [8026,8042]
===
match
---
operator: = [43562,43563]
operator: = [43562,43563]
===
match
---
expr_stmt [27513,27536]
expr_stmt [27513,27536]
===
match
---
name: dag [59713,59716]
name: dag [61661,61664]
===
match
---
trailer [8273,8287]
trailer [8273,8287]
===
match
---
trailer [34649,34656]
trailer [34649,34656]
===
match
---
trailer [14197,14374]
trailer [14197,14374]
===
match
---
factor [54386,54388]
factor [56334,56336]
===
match
---
trailer [30993,31026]
trailer [30993,31026]
===
match
---
operator: = [60670,60671]
operator: = [62618,62619]
===
match
---
name: access_control [62067,62081]
name: access_control [64015,64029]
===
match
---
trailer [42940,42950]
trailer [42940,42950]
===
match
---
atom_expr [33944,34020]
atom_expr [33944,34020]
===
match
---
trailer [56702,56725]
trailer [58650,58673]
===
match
---
atom_expr [66364,66374]
atom_expr [68312,68322]
===
match
---
name: dag_fileloc [34354,34365]
name: dag_fileloc [34354,34365]
===
match
---
trailer [39385,39392]
trailer [39385,39392]
===
match
---
comparison [17775,17864]
comparison [17775,17864]
===
match
---
expr_stmt [58003,58226]
expr_stmt [59951,60174]
===
match
---
name: task [20022,20026]
name: task [20022,20026]
===
match
---
operator: = [44794,44795]
operator: = [44794,44795]
===
match
---
name: dag_pickle [44006,44016]
name: dag_pickle [44006,44016]
===
match
---
operator: } [43946,43947]
operator: } [43946,43947]
===
match
---
simple_stmt [40792,40804]
simple_stmt [40792,40804]
===
match
---
name: dag [6223,6226]
name: dag [6223,6226]
===
match
---
name: six_hours_ago_to_the_hour [56151,56176]
name: six_hours_ago_to_the_hour [58099,58124]
===
match
---
operator: == [4467,4469]
operator: == [4467,4469]
===
match
---
argument [58182,58188]
argument [60130,60136]
===
match
---
trailer [68029,68035]
trailer [69977,69983]
===
match
---
name: task_id [27560,27567]
name: task_id [27560,27567]
===
match
---
string: 'airflow' [27592,27601]
string: 'airflow' [27592,27601]
===
match
---
name: filters [18732,18739]
name: filters [18732,18739]
===
match
---
name: child_dag_name [60107,60121]
name: child_dag_name [62055,62069]
===
match
---
suite [14541,14756]
suite [14541,14756]
===
match
---
simple_stmt [43007,43086]
simple_stmt [43007,43086]
===
match
---
name: test_task_id [17926,17938]
name: test_task_id [17926,17938]
===
match
---
name: _next [23079,23084]
name: _next [23079,23084]
===
match
---
dictorsetmaker [37707,37723]
dictorsetmaker [37707,37723]
===
match
---
trailer [7238,7242]
trailer [7238,7242]
===
match
---
assert_stmt [15119,15161]
assert_stmt [15119,15161]
===
match
---
trailer [47981,48033]
trailer [47981,48033]
===
match
---
string: 'dag-bulk-sync-3' [26682,26699]
string: 'dag-bulk-sync-3' [26682,26699]
===
match
---
testlist_comp [15491,15807]
testlist_comp [15491,15807]
===
match
---
funcdef [10543,10727]
funcdef [10543,10727]
===
match
---
name: topological_list [8987,9003]
name: topological_list [8987,9003]
===
match
---
trailer [51193,51195]
trailer [51193,51195]
===
match
---
trailer [43173,43191]
trailer [43173,43191]
===
match
---
operator: = [61142,61143]
operator: = [63090,63091]
===
match
---
name: t_1 [48742,48745]
name: t_1 [48742,48745]
===
match
---
trailer [27990,27998]
trailer [27990,27998]
===
match
---
trailer [20860,20870]
trailer [20860,20870]
===
match
---
name: task_id [38226,38233]
name: task_id [38226,38233]
===
match
---
simple_stmt [2236,2294]
simple_stmt [2236,2294]
===
match
---
name: task_id [7558,7565]
name: task_id [7558,7565]
===
match
---
operator: = [61731,61732]
operator: = [63679,63680]
===
match
---
operator: == [23929,23931]
operator: == [23929,23931]
===
match
---
trailer [31474,31481]
trailer [31474,31481]
===
match
---
string: "2018-10-28T01:00:00+00:00" [20807,20834]
string: "2018-10-28T01:00:00+00:00" [20807,20834]
===
match
---
trailer [20923,20941]
trailer [20923,20941]
===
match
---
import_from [1230,1266]
import_from [1230,1266]
===
match
---
name: mock [1057,1061]
name: mock [1057,1061]
===
match
---
string: 'far_future_dag' [62366,62382]
string: 'far_future_dag' [64314,64330]
===
match
---
atom_expr [35239,35279]
atom_expr [35239,35279]
===
match
---
name: datetime [46617,46625]
name: datetime [46617,46625]
===
match
---
trailer [35109,35114]
trailer [35109,35114]
===
match
---
decorator [39789,39824]
decorator [39789,39824]
===
match
---
string: 'dag2' [6006,6012]
string: 'dag2' [6006,6012]
===
match
---
operator: = [49131,49132]
operator: = [49131,49132]
===
match
---
trailer [20435,20450]
trailer [20435,20450]
===
match
---
trailer [22889,22899]
trailer [22889,22899]
===
match
---
atom_expr [6242,6251]
atom_expr [6242,6251]
===
match
---
name: State [18360,18365]
name: State [18360,18365]
===
match
---
operator: = [68310,68311]
operator: = [70258,70259]
===
match
---
name: is_paused [32168,32177]
name: is_paused [32168,32177]
===
match
---
string: 'Also fake' [54090,54101]
string: 'Also fake' [56038,56049]
===
match
---
simple_stmt [48139,48151]
simple_stmt [48139,48151]
===
match
---
trailer [32487,32500]
trailer [32487,32500]
===
match
---
trailer [66777,66784]
trailer [68725,68732]
===
match
---
name: relativedelta [1141,1154]
name: relativedelta [1141,1154]
===
match
---
name: return_num [69096,69106]
name: return_num [71044,71054]
===
match
---
operator: == [12054,12056]
operator: == [12054,12056]
===
match
---
assert_stmt [34987,35028]
assert_stmt [34987,35028]
===
match
---
arglist [31918,31959]
arglist [31918,31959]
===
match
---
name: dag_id [31434,31440]
name: dag_id [31434,31440]
===
match
---
name: self [28472,28476]
name: self [28472,28476]
===
match
---
assert_stmt [8109,8177]
assert_stmt [8109,8177]
===
match
---
name: raises [16570,16576]
name: raises [16570,16576]
===
match
---
atom_expr [9239,9272]
atom_expr [9239,9272]
===
match
---
name: DAG [32939,32942]
name: DAG [32939,32942]
===
match
---
fstring_string: . [12986,12987]
fstring_string: . [12986,12987]
===
match
---
operator: , [67590,67591]
operator: , [69538,69539]
===
match
---
trailer [30879,30947]
trailer [30879,30947]
===
match
---
trailer [49658,49662]
trailer [49658,49662]
===
match
---
trailer [42724,42726]
trailer [42724,42726]
===
match
---
name: now [55356,55359]
name: now [57304,57307]
===
match
---
expr_stmt [19217,19252]
expr_stmt [19217,19252]
===
match
---
operator: = [55193,55194]
operator: = [57141,57142]
===
match
---
name: dag [50351,50354]
name: dag [50351,50354]
===
match
---
expr_stmt [10238,10255]
expr_stmt [10238,10255]
===
match
---
name: convert [21136,21143]
name: convert [21136,21143]
===
match
---
name: dag [40501,40504]
name: dag [40501,40504]
===
match
---
name: dag_id [54876,54882]
name: dag_id [56824,56830]
===
match
---
atom_expr [62883,62927]
atom_expr [64831,64875]
===
match
---
atom_expr [40549,40566]
atom_expr [40549,40566]
===
match
---
return_stmt [66743,66753]
return_stmt [68691,68701]
===
match
---
simple_stmt [10087,10118]
simple_stmt [10087,10118]
===
match
---
name: commit [49202,49208]
name: commit [49202,49208]
===
match
---
name: job_id [48333,48339]
name: job_id [48333,48339]
===
match
---
operator: , [48940,48941]
operator: , [48940,48941]
===
match
---
operator: , [43568,43569]
operator: , [43568,43569]
===
match
---
atom_expr [26754,26769]
atom_expr [26754,26769]
===
match
---
simple_stmt [45469,45505]
simple_stmt [45469,45505]
===
match
---
operator: } [18543,18544]
operator: } [18543,18544]
===
match
---
string: "0 0 * * *" [46403,46414]
string: "0 0 * * *" [46403,46414]
===
match
---
suite [2661,2747]
suite [2661,2747]
===
match
---
operator: == [34351,34353]
operator: == [34351,34353]
===
match
---
atom_expr [35118,35131]
atom_expr [35118,35131]
===
match
---
name: op1 [37046,37049]
name: op1 [37046,37049]
===
match
---
operator: = [49111,49112]
operator: = [49111,49112]
===
match
---
suite [47175,47246]
suite [47175,47246]
===
match
---
name: calculated_weight [15056,15073]
name: calculated_weight [15056,15073]
===
match
---
argument [34186,34201]
argument [34186,34201]
===
match
---
simple_stmt [6439,6468]
simple_stmt [6439,6468]
===
match
---
assert_stmt [25736,25909]
assert_stmt [25736,25909]
===
match
---
operator: , [12016,12017]
operator: , [12016,12017]
===
match
---
trailer [36486,36496]
trailer [36486,36496]
===
match
---
name: DEFAULT_DATE [16859,16871]
name: DEFAULT_DATE [16859,16871]
===
match
---
trailer [29360,29364]
trailer [29360,29364]
===
match
---
name: isoformat [20861,20870]
name: isoformat [20861,20870]
===
match
---
operator: == [61202,61204]
operator: == [63150,63152]
===
match
---
simple_stmt [26458,26486]
simple_stmt [26458,26486]
===
match
---
atom_expr [64068,64083]
atom_expr [66016,66031]
===
match
---
expr_stmt [17255,17279]
expr_stmt [17255,17279]
===
match
---
operator: = [7565,7566]
operator: = [7565,7566]
===
match
---
trailer [47496,47526]
trailer [47496,47526]
===
match
---
name: orm_dag [30353,30360]
name: orm_dag [30353,30360]
===
match
---
argument [67472,67502]
argument [69420,69450]
===
match
---
atom_expr [20968,20990]
atom_expr [20968,20990]
===
match
---
atom_expr [12954,13016]
atom_expr [12954,13016]
===
match
---
assert_stmt [29625,29652]
assert_stmt [29625,29652]
===
match
---
name: session [27106,27113]
name: session [27106,27113]
===
match
---
argument [63234,63249]
argument [65182,65197]
===
match
---
string: ', ' [29586,29590]
string: ', ' [29586,29590]
===
match
---
operator: = [17203,17204]
operator: = [17203,17204]
===
match
---
atom_expr [44554,44597]
atom_expr [44554,44597]
===
match
---
argument [52251,52283]
argument [54199,54231]
===
match
---
name: DEFAULT_DATE [35266,35278]
name: DEFAULT_DATE [35266,35278]
===
match
---
fstring_expr [12987,12990]
fstring_expr [12987,12990]
===
match
---
string: 'new_nonexisting_dag' [33142,33163]
string: 'new_nonexisting_dag' [33142,33163]
===
match
---
expr_stmt [8735,8767]
expr_stmt [8735,8767]
===
match
---
argument [37515,37538]
argument [37515,37538]
===
match
---
atom_expr [64649,64666]
atom_expr [66597,66614]
===
match
---
atom_expr [5544,5589]
atom_expr [5544,5589]
===
match
---
operator: = [68664,68665]
operator: = [70612,70613]
===
match
---
assert_stmt [23904,23959]
assert_stmt [23904,23959]
===
match
---
expr_stmt [30353,30425]
expr_stmt [30353,30425]
===
match
---
string: 'some_string' [19944,19957]
string: 'some_string' [19944,19957]
===
match
---
atom_expr [28408,28438]
atom_expr [28408,28438]
===
match
---
simple_stmt [54281,54300]
simple_stmt [56229,56248]
===
match
---
name: DEFAULT_DATE [49006,49018]
name: DEFAULT_DATE [49006,49018]
===
match
---
dotted_name [1272,1293]
dotted_name [1272,1293]
===
match
---
trailer [22795,22813]
trailer [22795,22813]
===
match
---
name: test_dag_id [43854,43865]
name: test_dag_id [43854,43865]
===
match
---
operator: = [50993,50994]
operator: = [50993,50994]
===
match
---
name: dag [42350,42353]
name: dag [42350,42353]
===
match
---
name: six_hours_ago_to_the_hour [55327,55352]
name: six_hours_ago_to_the_hour [57275,57300]
===
match
---
atom [18330,18344]
atom [18330,18344]
===
match
---
simple_stmt [21730,21766]
simple_stmt [21730,21766]
===
match
---
atom_expr [50716,50739]
atom_expr [50716,50739]
===
match
---
name: dag_decorator [66021,66034]
name: dag_decorator [67969,67982]
===
match
---
trailer [69106,69113]
trailer [71054,71061]
===
match
---
operator: = [30219,30220]
operator: = [30219,30220]
===
match
---
name: dag [26458,26461]
name: dag [26458,26461]
===
match
---
fstring_string: dag-bulk-sync- [24527,24541]
fstring_string: dag-bulk-sync- [24527,24541]
===
match
---
string: 'test' [64395,64401]
string: 'test' [66343,66349]
===
match
---
argument [20418,20450]
argument [20418,20450]
===
match
---
trailer [25658,25675]
trailer [25658,25675]
===
match
---
expr_stmt [64980,65000]
expr_stmt [66928,66948]
===
match
---
string: 'dag-bulk-sync-2' [25055,25072]
string: 'dag-bulk-sync-2' [25055,25072]
===
match
---
name: TaskFail [3058,3066]
name: TaskFail [3058,3066]
===
match
---
name: test_dag_default_view_default_value [4805,4840]
name: test_dag_default_view_default_value [4805,4840]
===
match
---
arglist [44643,44679]
arglist [44643,44679]
===
match
---
number: 2020 [58776,58780]
number: 2020 [60724,60728]
===
match
---
name: subdag_id [32453,32462]
name: subdag_id [32453,32462]
===
match
---
operator: { [44242,44243]
operator: { [44242,44243]
===
match
---
operator: == [24320,24322]
operator: == [24320,24322]
===
match
---
trailer [53133,53143]
trailer [55081,55091]
===
match
---
atom_expr [32726,32742]
atom_expr [32726,32742]
===
match
---
trailer [53143,53151]
trailer [55091,55099]
===
match
---
suite [33824,34717]
suite [33824,34717]
===
match
---
testlist_comp [26294,26324]
testlist_comp [26294,26324]
===
match
---
name: relativedelta [1120,1133]
name: relativedelta [1120,1133]
===
match
---
name: subdag [31137,31143]
name: subdag [31137,31143]
===
match
---
comparison [34665,34690]
comparison [34665,34690]
===
match
---
operator: = [35808,35809]
operator: = [35808,35809]
===
match
---
argument [22727,22743]
argument [22727,22743]
===
match
---
operator: , [14470,14471]
operator: , [14470,14471]
===
match
---
arglist [50184,50208]
arglist [50184,50208]
===
match
---
operator: , [49371,49372]
operator: , [49371,49372]
===
match
---
string: "faketastic" [43244,43256]
string: "faketastic" [43244,43256]
===
match
---
name: isoformat [24028,24037]
name: isoformat [24028,24037]
===
match
---
comparison [39468,39488]
comparison [39468,39488]
===
match
---
simple_stmt [5717,5903]
simple_stmt [5717,5903]
===
match
---
string: 'op1' [19246,19251]
string: 'op1' [19246,19251]
===
match
---
operator: } [14244,14245]
operator: } [14244,14245]
===
match
---
operator: , [50808,50809]
operator: , [50808,50809]
===
match
---
trailer [38829,38841]
trailer [38829,38841]
===
match
---
name: task_instance_1 [52532,52547]
name: task_instance_1 [54480,54495]
===
match
---
param [3548,3552]
param [3548,3552]
===
match
---
comparison [29180,29235]
comparison [29180,29235]
===
match
---
trailer [6725,6731]
trailer [6725,6731]
===
match
---
operator: { [14092,14093]
operator: { [14092,14093]
===
match
---
string: """Verify that same tasks with Duplicate task_id do not raise error""" [37798,37868]
string: """Verify that same tasks with Duplicate task_id do not raise error""" [37798,37868]
===
match
---
name: patcher_dag_code [2723,2739]
name: patcher_dag_code [2723,2739]
===
match
---
name: freeze_time [56866,56877]
name: freeze_time [58814,58825]
===
match
---
simple_stmt [2106,2149]
simple_stmt [2106,2149]
===
match
---
name: task_id [7966,7973]
name: task_id [7966,7973]
===
match
---
operator: = [62575,62576]
operator: = [64523,64524]
===
match
---
trailer [31225,31232]
trailer [31225,31232]
===
match
---
argument [48779,48786]
argument [48779,48786]
===
match
---
name: operators [1778,1787]
name: operators [1778,1787]
===
match
---
operator: = [59350,59351]
operator: = [61298,61299]
===
match
---
atom_expr [64425,64448]
atom_expr [66373,66396]
===
match
---
name: query [31210,31215]
name: query [31210,31215]
===
match
---
expr_stmt [5538,5589]
expr_stmt [5538,5589]
===
match
---
name: dag [42518,42521]
name: dag [42518,42521]
===
match
---
trailer [4473,4480]
trailer [4473,4480]
===
match
---
name: subdag [31019,31025]
name: subdag [31019,31025]
===
match
---
operator: = [58110,58111]
operator: = [60058,60059]
===
match
---
arglist [17912,17971]
arglist [17912,17971]
===
match
---
argument [44511,44528]
argument [44511,44528]
===
match
---
trailer [3337,3344]
trailer [3337,3344]
===
match
---
operator: = [43153,43154]
operator: = [43153,43154]
===
match
---
simple_stmt [48834,49030]
simple_stmt [48834,49030]
===
match
---
assert_stmt [6408,6430]
assert_stmt [6408,6430]
===
match
---
name: name [18504,18508]
name: name [18504,18508]
===
match
---
trailer [34658,34664]
trailer [34658,34664]
===
match
---
name: stage [13117,13122]
name: stage [13117,13122]
===
match
---
name: set_upstream [9940,9952]
name: set_upstream [9940,9952]
===
match
---
dictorsetmaker [15422,15439]
dictorsetmaker [15422,15439]
===
match
---
operator: , [57374,57375]
operator: , [59322,59323]
===
match
---
name: DAG [35720,35723]
name: DAG [35720,35723]
===
match
---
simple_stmt [60756,60923]
simple_stmt [62704,62871]
===
match
---
name: dag_id [51992,51998]
name: dag_id [53940,53946]
===
match
---
name: orm_subdag [29562,29572]
name: orm_subdag [29562,29572]
===
match
---
operator: { [61499,61500]
operator: { [63447,63448]
===
match
---
operator: , [59238,59239]
operator: , [61186,61187]
===
match
---
name: days [46664,46668]
name: days [46664,46668]
===
match
---
atom [18353,18388]
atom [18353,18388]
===
match
---
comparison [24022,24070]
comparison [24022,24070]
===
match
---
simple_stmt [62434,62491]
simple_stmt [64382,64439]
===
match
---
atom [31397,31583]
atom [31397,31583]
===
match
---
name: DAG [58009,58012]
name: DAG [59957,59960]
===
match
---
name: datetime [64890,64898]
name: datetime [66838,66846]
===
match
---
trailer [33551,33557]
trailer [33551,33557]
===
match
---
atom_expr [19030,19053]
atom_expr [19030,19053]
===
match
---
operator: = [37122,37123]
operator: = [37122,37123]
===
match
---
atom_expr [10056,10078]
atom_expr [10056,10078]
===
match
---
name: enumerate [3328,3337]
name: enumerate [3328,3337]
===
match
---
name: dag [6186,6189]
name: dag [6186,6189]
===
match
---
simple_stmt [61250,61305]
simple_stmt [63198,63253]
===
match
---
name: f [18945,18946]
name: f [18945,18946]
===
match
---
name: DAG [36190,36193]
name: DAG [36190,36193]
===
match
---
assert_stmt [45469,45504]
assert_stmt [45469,45504]
===
match
---
name: dag [55117,55120]
name: dag [57065,57068]
===
match
---
name: append [54287,54293]
name: append [56235,56241]
===
match
---
operator: , [30689,30690]
operator: , [30689,30690]
===
match
---
name: DagModel [32235,32243]
name: DagModel [32235,32243]
===
match
---
expr_stmt [20353,20451]
expr_stmt [20353,20451]
===
match
---
simple_stmt [9109,9145]
simple_stmt [9109,9145]
===
match
---
name: DummyOperator [8786,8799]
name: DummyOperator [8786,8799]
===
match
---
trailer [5920,5986]
trailer [5920,5986]
===
match
---
string: 'owner1' [30021,30029]
string: 'owner1' [30021,30029]
===
match
---
name: os [19674,19676]
name: os [19674,19676]
===
match
---
name: state [51740,51745]
name: state [53688,53693]
===
match
---
simple_stmt [49717,49753]
simple_stmt [49717,49753]
===
match
---
name: days [17113,17117]
name: days [17113,17117]
===
match
---
expr_stmt [23049,23085]
expr_stmt [23049,23085]
===
match
---
name: self [36788,36792]
name: self [36788,36792]
===
match
---
name: j [12988,12989]
name: j [12988,12989]
===
match
---
string: 'b_child' [7566,7575]
string: 'b_child' [7566,7575]
===
match
---
trailer [25872,25889]
trailer [25872,25889]
===
match
---
simple_stmt [49493,49675]
simple_stmt [49493,49675]
===
match
---
atom_expr [51179,51195]
atom_expr [51179,51195]
===
match
---
name: tasks_count [64215,64226]
name: tasks_count [66163,66174]
===
match
---
operator: == [56831,56833]
operator: == [58779,58781]
===
match
---
trailer [25591,25604]
trailer [25591,25604]
===
match
---
trailer [27053,27060]
trailer [27053,27060]
===
match
---
simple_stmt [38519,38530]
simple_stmt [38519,38530]
===
match
---
name: airflow [2154,2161]
name: airflow [2154,2161]
===
match
---
trailer [21865,21867]
trailer [21865,21867]
===
match
---
operator: = [40499,40500]
operator: = [40499,40500]
===
match
---
atom [46587,46602]
atom [46587,46602]
===
match
---
trailer [44799,44811]
trailer [44799,44811]
===
match
---
name: op4 [8870,8873]
name: op4 [8870,8873]
===
match
---
simple_stmt [33938,34021]
simple_stmt [33938,34021]
===
match
---
name: schedule_interval [46990,47007]
name: schedule_interval [46990,47007]
===
match
---
name: dag_id [48169,48175]
name: dag_id [48169,48175]
===
match
---
simple_stmt [2294,2355]
simple_stmt [2294,2355]
===
match
---
trailer [52421,52427]
trailer [54369,54375]
===
match
---
expr_stmt [67325,67358]
expr_stmt [69273,69306]
===
match
---
trailer [5020,5053]
trailer [5020,5053]
===
match
---
number: 0 [3479,3480]
number: 0 [3479,3480]
===
match
---
atom_expr [18424,18439]
atom_expr [18424,18439]
===
match
---
atom_expr [9690,9716]
atom_expr [9690,9716]
===
match
---
name: bash [1690,1694]
name: bash [1690,1694]
===
match
---
operator: = [21125,21126]
operator: = [21125,21126]
===
match
---
name: next_date [57670,57679]
name: next_date [59618,59627]
===
match
---
name: previous_schedule [20924,20941]
name: previous_schedule [20924,20941]
===
match
---
name: NONE [51730,51734]
name: NONE [53678,53682]
===
match
---
import_from [1517,1569]
import_from [1517,1569]
===
match
---
arith_expr [55483,55519]
arith_expr [57431,57467]
===
match
---
trailer [18764,18772]
trailer [18764,18772]
===
match
---
trailer [4635,4711]
trailer [4635,4711]
===
match
---
atom_expr [55550,55577]
atom_expr [57498,57525]
===
match
---
name: hash [45696,45700]
name: hash [45696,45700]
===
match
---
name: filter [31226,31232]
name: filter [31226,31232]
===
match
---
atom_expr [69126,69139]
atom_expr [71074,71087]
===
match
---
name: RUNNING [51812,51819]
name: RUNNING [53760,53767]
===
match
---
argument [28608,28622]
argument [28608,28622]
===
match
---
operator: = [33063,33064]
operator: = [33063,33064]
===
match
---
operator: == [33591,33593]
operator: == [33591,33593]
===
match
---
name: paused_dag_ids [46072,46086]
name: paused_dag_ids [46072,46086]
===
match
---
simple_stmt [67644,67720]
simple_stmt [69592,69668]
===
match
---
name: b_index [3494,3501]
name: b_index [3494,3501]
===
match
---
decorated [68050,68126]
decorated [69998,70074]
===
match
---
arith_expr [13292,13297]
arith_expr [13292,13297]
===
match
---
argument [52657,52680]
argument [54605,54628]
===
match
---
arglist [42376,42437]
arglist [42376,42437]
===
match
---
simple_stmt [66321,66349]
simple_stmt [68269,68297]
===
match
---
name: two_hours_ago [56371,56384]
name: two_hours_ago [58319,58332]
===
match
---
operator: = [4379,4380]
operator: = [4379,4380]
===
match
---
operator: = [45937,45938]
operator: = [45937,45938]
===
match
---
name: DAG [34941,34944]
name: DAG [34941,34944]
===
match
---
name: days [58182,58186]
name: days [60130,60134]
===
match
---
atom_expr [66398,66416]
atom_expr [68346,68364]
===
match
---
name: DEFAULT_DATE [37526,37538]
name: DEFAULT_DATE [37526,37538]
===
match
---
trailer [6842,6857]
trailer [6842,6857]
===
match
---
name: tearDown [2638,2646]
name: tearDown [2638,2646]
===
match
---
number: 2018 [34896,34900]
number: 2018 [34896,34900]
===
match
---
simple_stmt [42936,42959]
simple_stmt [42936,42959]
===
match
---
operator: , [56126,56127]
operator: , [58074,58075]
===
match
---
name: DAG [4957,4960]
name: DAG [4957,4960]
===
match
---
operator: == [9394,9396]
operator: == [9394,9396]
===
match
---
parameters [2783,2796]
parameters [2783,2796]
===
match
---
operator: { [12376,12377]
operator: { [12376,12377]
===
match
---
simple_stmt [64462,64624]
simple_stmt [66410,66572]
===
match
---
operator: = [18068,18069]
operator: = [18068,18069]
===
match
---
atom_expr [60541,60735]
atom_expr [62489,62683]
===
match
---
dictorsetmaker [12377,12395]
dictorsetmaker [12377,12395]
===
match
---
name: State [2041,2046]
name: State [2041,2046]
===
match
---
term [15005,15038]
term [15005,15038]
===
match
---
operator: + [50238,50239]
operator: + [50238,50239]
===
match
---
trailer [12355,12397]
trailer [12355,12397]
===
match
---
simple_stmt [23387,23442]
simple_stmt [23387,23442]
===
match
---
expr_stmt [4202,4229]
expr_stmt [4202,4229]
===
match
---
name: t_1 [50164,50167]
name: t_1 [50164,50167]
===
match
---
name: in_ [32325,32328]
name: in_ [32325,32328]
===
match
---
simple_stmt [27882,27934]
simple_stmt [27882,27934]
===
match
---
atom_expr [30441,30461]
atom_expr [30441,30461]
===
match
---
expr_stmt [8531,8606]
expr_stmt [8531,8606]
===
match
---
simple_stmt [21688,21722]
simple_stmt [21688,21722]
===
match
---
trailer [2548,2555]
trailer [2548,2555]
===
match
---
number: 2018 [22601,22605]
number: 2018 [22601,22605]
===
match
---
number: 1 [36672,36673]
number: 1 [36672,36673]
===
match
---
name: session [25230,25237]
name: session [25230,25237]
===
match
---
comparison [25743,25909]
comparison [25743,25909]
===
match
---
operator: = [35785,35786]
operator: = [35785,35786]
===
match
---
atom_expr [31918,31958]
atom_expr [31918,31958]
===
match
---
trailer [29162,29164]
trailer [29162,29164]
===
match
---
name: when [40534,40538]
name: when [40534,40538]
===
match
---
trailer [46888,46917]
trailer [46888,46917]
===
match
---
operator: , [20628,20629]
operator: , [20628,20629]
===
match
---
trailer [67754,67756]
trailer [69702,69704]
===
match
---
testlist_comp [46550,46572]
testlist_comp [46550,46572]
===
match
---
name: DummyOperator [6157,6170]
name: DummyOperator [6157,6170]
===
match
---
name: State [48472,48477]
name: State [48472,48477]
===
match
---
atom_expr [65034,65052]
atom_expr [66982,67000]
===
match
---
name: end_date [53984,53992]
name: end_date [55932,55940]
===
match
---
trailer [43644,43659]
trailer [43644,43659]
===
match
---
trailer [9918,9923]
trailer [9918,9923]
===
match
---
operator: = [42598,42599]
operator: = [42598,42599]
===
match
---
arglist [34896,34923]
arglist [34896,34923]
===
match
---
assert_stmt [39375,39410]
assert_stmt [39375,39410]
===
match
---
atom_expr [29775,29790]
atom_expr [29775,29790]
===
match
---
operator: , [40176,40177]
operator: , [40176,40177]
===
match
---
simple_stmt [22176,22212]
simple_stmt [22176,22212]
===
match
---
operator: = [16858,16859]
operator: = [16858,16859]
===
match
---
name: DagRunType [42545,42555]
name: DagRunType [42545,42555]
===
match
---
string: """         We should never create dagruns for unpaused DAGs         """ [63076,63148]
string: """         We should never create dagruns for unpaused DAGs         """ [65024,65096]
===
match
---
operator: < [45405,45406]
operator: < [45405,45406]
===
match
---
atom_expr [38153,38164]
atom_expr [38153,38164]
===
match
---
number: 1 [41085,41086]
number: 1 [41085,41086]
===
match
---
name: self [10769,10773]
name: self [10769,10773]
===
match
---
name: dag [69204,69207]
name: dag [71152,71155]
===
match
---
name: days [17362,17366]
name: days [17362,17366]
===
match
---
expr_stmt [16256,16302]
expr_stmt [16256,16302]
===
match
---
simple_stmt [19604,19625]
simple_stmt [19604,19625]
===
match
---
trailer [40731,40736]
trailer [40731,40736]
===
match
---
name: op1 [38148,38151]
name: op1 [38148,38151]
===
match
---
name: dag [24136,24139]
name: dag [24136,24139]
===
match
---
with_item [26576,26603]
with_item [26576,26603]
===
match
---
name: DEFAULT_DATE [36217,36229]
name: DEFAULT_DATE [36217,36229]
===
match
---
dotted_name [49804,49824]
dotted_name [49804,49824]
===
match
---
dotted_name [2111,2130]
dotted_name [2111,2130]
===
match
---
name: dagrun_1 [52428,52436]
name: dagrun_1 [54376,54384]
===
match
---
operator: = [48700,48701]
operator: = [48700,48701]
===
match
---
simple_stmt [17768,17865]
simple_stmt [17768,17865]
===
match
---
name: task_id [7031,7038]
name: task_id [7031,7038]
===
match
---
name: MANUAL [47578,47584]
name: MANUAL [47578,47584]
===
match
---
assert_stmt [48358,48393]
assert_stmt [48358,48393]
===
match
---
argument [29999,30013]
argument [29999,30013]
===
match
---
name: dag [31340,31343]
name: dag [31340,31343]
===
match
---
suite [19844,19897]
suite [19844,19897]
===
match
---
comparison [69243,69276]
comparison [71191,71224]
===
match
---
name: repr [24341,24345]
name: repr [24341,24345]
===
match
---
with_stmt [6753,6858]
with_stmt [6753,6858]
===
match
---
trailer [30370,30376]
trailer [30370,30376]
===
match
---
number: 2020 [58444,58448]
number: 2020 [60392,60396]
===
match
---
trailer [40559,40566]
trailer [40559,40566]
===
match
---
atom_expr [30149,30251]
atom_expr [30149,30251]
===
match
---
operator: == [58755,58757]
operator: == [60703,60705]
===
match
---
atom_expr [6157,6195]
atom_expr [6157,6195]
===
match
---
trailer [65783,65786]
trailer [67731,67734]
===
match
---
argument [46664,46670]
argument [46664,46670]
===
match
---
name: owner [59718,59723]
name: owner [61666,61671]
===
match
---
arglist [12968,13015]
arglist [12968,13015]
===
match
---
atom_expr [4950,4996]
atom_expr [4950,4996]
===
match
---
operator: >> [35541,35543]
operator: >> [35541,35543]
===
match
---
with_item [24704,24731]
with_item [24704,24731]
===
match
---
arglist [14223,14352]
arglist [14223,14352]
===
match
---
simple_stmt [46072,46127]
simple_stmt [46072,46127]
===
match
---
name: dag2 [6504,6508]
name: dag2 [6504,6508]
===
match
---
simple_stmt [68813,68881]
simple_stmt [70761,70829]
===
match
---
name: dag [29051,29054]
name: dag [29051,29054]
===
match
---
import_from [2294,2354]
import_from [2294,2354]
===
match
---
trailer [31679,31694]
trailer [31679,31694]
===
match
---
operator: = [58186,58187]
operator: = [60134,60135]
===
match
---
trailer [29132,29158]
trailer [29132,29158]
===
match
---
name: test_dag_id [44363,44374]
name: test_dag_id [44363,44374]
===
match
---
assert_stmt [22067,22122]
assert_stmt [22067,22122]
===
match
---
operator: = [20359,20360]
operator: = [20359,20360]
===
match
---
operator: , [40532,40533]
operator: , [40532,40533]
===
match
---
trailer [19128,19199]
trailer [19128,19199]
===
match
---
atom_expr [34941,34978]
atom_expr [34941,34978]
===
match
---
argument [41182,41205]
argument [41182,41205]
===
match
---
operator: = [37050,37051]
operator: = [37050,37051]
===
match
---
operator: , [60819,60820]
operator: , [62767,62768]
===
match
---
name: dag [25551,25554]
name: dag [25551,25554]
===
match
---
operator: , [44724,44725]
operator: , [44724,44725]
===
match
---
operator: = [6553,6554]
operator: = [6553,6554]
===
match
---
name: filter [32285,32291]
name: filter [32285,32291]
===
match
---
name: op3 [37995,37998]
name: op3 [37995,37998]
===
match
---
operator: = [14331,14332]
operator: = [14331,14332]
===
match
---
atom_expr [47567,47584]
atom_expr [47567,47584]
===
match
---
operator: = [50350,50351]
operator: = [50350,50351]
===
match
---
operator: = [40474,40475]
operator: = [40474,40475]
===
match
---
trailer [17622,17666]
trailer [17622,17666]
===
match
---
argument [27432,27478]
argument [27432,27478]
===
match
---
simple_stmt [53024,53070]
simple_stmt [54972,55018]
===
match
---
name: op1 [35531,35534]
name: op1 [35531,35534]
===
match
---
name: filters [18765,18772]
name: filters [18765,18772]
===
match
---
name: dag [62165,62168]
name: dag [64113,64116]
===
match
---
simple_stmt [47255,47296]
simple_stmt [47255,47296]
===
match
---
import_as_name [1601,1621]
import_as_name [1601,1621]
===
match
---
operator: > [45440,45441]
operator: > [45440,45441]
===
match
---
simple_stmt [5911,5987]
simple_stmt [5911,5987]
===
match
---
dictorsetmaker [35601,35609]
dictorsetmaker [35601,35609]
===
match
---
name: pytest [16563,16569]
name: pytest [16563,16569]
===
match
---
simple_stmt [1230,1267]
simple_stmt [1230,1267]
===
match
---
trailer [31869,31879]
trailer [31869,31879]
===
match
---
simple_stmt [32193,32394]
simple_stmt [32193,32394]
===
match
---
trailer [27032,27081]
trailer [27032,27081]
===
match
---
with_item [12834,12910]
with_item [12834,12910]
===
match
---
name: dag_id [33833,33839]
name: dag_id [33833,33839]
===
match
---
dictorsetmaker [61757,61813]
dictorsetmaker [63705,63761]
===
match
---
expr_stmt [37995,38028]
expr_stmt [37995,38028]
===
match
---
name: dag_id [60558,60564]
name: dag_id [62506,62512]
===
match
---
number: 1 [64808,64809]
number: 1 [66756,66757]
===
match
---
simple_stmt [27170,27196]
simple_stmt [27170,27196]
===
match
---
trailer [56725,56731]
trailer [58673,58679]
===
match
---
simple_stmt [64915,64926]
simple_stmt [66863,66874]
===
match
---
simple_stmt [51977,52000]
simple_stmt [53925,53948]
===
match
---
name: dag [35586,35589]
name: dag [35586,35589]
===
match
---
trailer [60950,60957]
trailer [62898,62905]
===
match
---
atom_expr [32939,32995]
atom_expr [32939,32995]
===
match
---
name: num [66222,66225]
name: num [68170,68173]
===
match
---
simple_stmt [45036,45069]
simple_stmt [45036,45069]
===
match
---
name: task_id [9704,9711]
name: task_id [9704,9711]
===
match
---
name: dr [47914,47916]
name: dr [47914,47916]
===
match
---
number: 1 [59229,59230]
number: 1 [61177,61178]
===
match
---
operator: , [64157,64158]
operator: , [66105,66106]
===
match
---
string: 'a_child' [8364,8373]
string: 'a_child' [8364,8373]
===
match
---
name: dag_id [55616,55622]
name: dag_id [57564,57570]
===
match
---
trailer [47321,47336]
trailer [47321,47336]
===
match
---
trailer [48242,48349]
trailer [48242,48349]
===
match
---
name: state [51770,51775]
name: state [53718,53723]
===
match
---
name: settings [1258,1266]
name: settings [1258,1266]
===
match
---
name: TI [50951,50953]
name: TI [50951,50953]
===
match
---
trailer [23035,23040]
trailer [23035,23040]
===
match
---
string: 'hello' [18711,18718]
string: 'hello' [18711,18718]
===
match
---
name: DAG [14043,14046]
name: DAG [14043,14046]
===
match
---
name: clear_db_runs [65061,65074]
name: clear_db_runs [67009,67022]
===
match
---
operator: = [43453,43454]
operator: = [43453,43454]
===
match
---
expr_stmt [41096,41148]
expr_stmt [41096,41148]
===
match
---
name: DEFAULT_DATE [52488,52500]
name: DEFAULT_DATE [54436,54448]
===
match
---
trailer [52994,53010]
trailer [54942,54958]
===
match
---
operator: , [28515,28516]
operator: , [28515,28516]
===
match
---
name: lower [29398,29403]
name: lower [29398,29403]
===
match
---
atom [26878,26910]
atom [26878,26910]
===
match
---
atom_expr [47231,47244]
atom_expr [47231,47244]
===
match
---
parameters [65930,65936]
parameters [67878,67884]
===
match
---
simple_stmt [4725,4796]
simple_stmt [4725,4796]
===
match
---
operator: = [18928,18929]
operator: = [18928,18929]
===
match
---
comparison [58413,58455]
comparison [60361,60403]
===
match
---
name: DAG [61973,61976]
name: DAG [63921,63924]
===
match
---
operator: = [38631,38632]
operator: = [38631,38632]
===
match
---
param [32918,32922]
param [32918,32922]
===
match
---
argument [42398,42415]
argument [42398,42415]
===
match
---
operator: = [35304,35305]
operator: = [35304,35305]
===
match
---
operator: , [52136,52137]
operator: , [54084,54085]
===
match
---
string: 'parent_dag' [7616,7628]
string: 'parent_dag' [7616,7628]
===
match
---
operator: = [27721,27722]
operator: = [27721,27722]
===
match
---
name: session [63286,63293]
name: session [65234,65241]
===
match
---
name: dag [7216,7219]
name: dag [7216,7219]
===
match
---
expr_stmt [38427,38460]
expr_stmt [38427,38460]
===
match
---
operator: = [67971,67972]
operator: = [69919,69920]
===
match
---
operator: = [9479,9480]
operator: = [9479,9480]
===
match
---
parameters [38299,38305]
parameters [38299,38305]
===
match
---
name: DAG [28661,28664]
name: DAG [28661,28664]
===
match
---
name: is_active [63548,63557]
name: is_active [65496,65505]
===
match
---
name: FAILED [48934,48940]
name: FAILED [48934,48940]
===
match
---
string: "run_id_is_generated" [47504,47525]
string: "run_id_is_generated" [47504,47525]
===
match
---
name: DEFAULT_DATE [27811,27823]
name: DEFAULT_DATE [27811,27823]
===
match
---
expr_stmt [62500,62528]
expr_stmt [64448,64476]
===
match
---
atom [61603,61691]
atom [63551,63639]
===
match
---
trailer [45836,45841]
trailer [45836,45841]
===
match
---
atom_expr [49517,49664]
atom_expr [49517,49664]
===
match
---
simple_stmt [19861,19897]
simple_stmt [19861,19897]
===
match
---
name: dag [29844,29847]
name: dag [29844,29847]
===
match
---
string: 'test' [50324,50330]
string: 'test' [50324,50330]
===
match
---
with_stmt [16558,16672]
with_stmt [16558,16672]
===
match
---
name: find [47317,47321]
name: find [47317,47321]
===
match
---
name: session [32221,32228]
name: session [32221,32228]
===
match
---
simple_stmt [62349,62426]
simple_stmt [64297,64374]
===
match
---
name: dag [45436,45439]
name: dag [45436,45439]
===
match
---
name: pytest [4622,4628]
name: pytest [4622,4628]
===
match
---
trailer [64246,64298]
trailer [66194,66246]
===
match
---
operator: = [44240,44241]
operator: = [44240,44241]
===
match
---
assert_stmt [39651,39688]
assert_stmt [39651,39688]
===
match
---
operator: = [44483,44484]
operator: = [44483,44484]
===
match
---
name: conf [29356,29360]
name: conf [29356,29360]
===
match
---
name: model [28408,28413]
name: model [28408,28413]
===
match
---
number: 2 [10399,10400]
number: 2 [10399,10400]
===
match
---
trailer [10313,10316]
trailer [10313,10316]
===
match
---
parameters [47040,47046]
parameters [47040,47046]
===
match
---
name: start_date [8548,8558]
name: start_date [8548,8558]
===
match
---
operator: , [18328,18329]
operator: , [18328,18329]
===
match
---
operator: = [44629,44630]
operator: = [44629,44630]
===
match
---
suite [5310,5392]
suite [5310,5392]
===
match
---
suite [28478,29791]
suite [28478,29791]
===
match
---
trailer [59581,59590]
trailer [61529,61538]
===
match
---
arglist [50231,50291]
arglist [50231,50291]
===
match
---
atom_expr [48064,48081]
atom_expr [48064,48081]
===
match
---
trailer [49168,49185]
trailer [49168,49185]
===
match
---
arglist [33442,33490]
arglist [33442,33490]
===
match
---
name: self [64941,64945]
name: self [66889,66893]
===
match
---
atom_expr [19408,19437]
atom_expr [19408,19437]
===
match
---
name: op2 [9086,9089]
name: op2 [9086,9089]
===
match
---
name: topological_list [9374,9390]
name: topological_list [9374,9390]
===
match
---
argument [59319,59334]
argument [61267,61282]
===
match
---
with_item [15372,15448]
with_item [15372,15448]
===
match
---
trailer [31418,31424]
trailer [31418,31424]
===
match
---
trailer [2379,2397]
trailer [2379,2397]
===
match
---
operator: = [61267,61268]
operator: = [63215,63216]
===
match
---
simple_stmt [18265,18416]
simple_stmt [18265,18416]
===
match
---
name: DAG [5330,5333]
name: DAG [5330,5333]
===
match
---
argument [42417,42437]
argument [42417,42437]
===
match
---
trailer [9049,9067]
trailer [9049,9067]
===
match
---
atom_expr [45762,45781]
atom_expr [45762,45781]
===
match
---
string: 'test_get_num_task_instances_dag' [16738,16771]
string: 'test_get_num_task_instances_dag' [16738,16771]
===
match
---
string: 'test_clear_dag' [51952,51968]
string: 'test_clear_dag' [53900,53916]
===
match
---
operator: , [48713,48714]
operator: , [48713,48714]
===
match
---
name: op4 [10135,10138]
name: op4 [10135,10138]
===
match
---
name: start [22691,22696]
name: start [22691,22696]
===
match
---
name: datetime [17094,17102]
name: datetime [17094,17102]
===
match
---
argument [56190,56203]
argument [58138,58151]
===
match
---
operator: , [43275,43276]
operator: , [43275,43276]
===
match
---
funcdef [27201,28447]
funcdef [27201,28447]
===
match
---
number: 1 [17880,17881]
number: 1 [17880,17881]
===
match
---
operator: , [50272,50273]
operator: , [50272,50273]
===
match
---
name: next_date [59371,59380]
name: next_date [61319,61328]
===
match
---
decorator [2752,2766]
decorator [2752,2766]
===
match
---
string: 'owner' [10662,10669]
string: 'owner' [10662,10669]
===
match
---
simple_stmt [52209,52406]
simple_stmt [54157,54354]
===
match
---
name: NONE [49855,49859]
name: NONE [49855,49859]
===
match
---
name: dagrun_2 [50915,50923]
name: dagrun_2 [50915,50923]
===
match
---
operator: = [12975,12976]
operator: = [12975,12976]
===
match
---
operator: = [52487,52488]
operator: = [54435,54436]
===
match
---
operator: = [38454,38455]
operator: = [38454,38455]
===
match
---
trailer [53281,53290]
trailer [55229,55238]
===
match
---
string: "dag run start_date loses precision " [43747,43784]
string: "dag run start_date loses precision " [43747,43784]
===
match
---
simple_stmt [48159,48212]
simple_stmt [48159,48212]
===
match
---
operator: = [68534,68535]
operator: = [70482,70483]
===
match
---
name: session [51449,51456]
name: session [51449,51456]
===
match
---
string: 'dag.subtask' [29522,29535]
string: 'dag.subtask' [29522,29535]
===
match
---
name: weight_rule [16649,16660]
name: weight_rule [16649,16660]
===
match
---
trailer [25170,25198]
trailer [25170,25198]
===
match
---
trailer [42796,42802]
trailer [42796,42802]
===
match
---
operator: , [56085,56086]
operator: , [58033,58034]
===
match
---
testlist_comp [24196,24212]
testlist_comp [24196,24212]
===
match
---
comparison [29729,29766]
comparison [29729,29766]
===
match
---
name: run_id [64497,64503]
name: run_id [66445,66451]
===
match
---
name: DagModel [63333,63341]
name: DagModel [65281,65289]
===
match
---
name: DagRun [49548,49554]
name: DagRun [49548,49554]
===
match
---
trailer [29782,29788]
trailer [29782,29788]
===
match
---
trailer [59127,59296]
trailer [61075,61244]
===
match
---
atom_expr [30285,30303]
atom_expr [30285,30303]
===
match
---
name: bulk_write_to_db [25417,25433]
name: bulk_write_to_db [25417,25433]
===
match
---
name: task_dict [14785,14794]
name: task_dict [14785,14794]
===
match
---
simple_stmt [37493,37540]
simple_stmt [37493,37540]
===
match
---
name: child_dag [7476,7485]
name: child_dag [7476,7485]
===
match
---
name: dag [23236,23239]
name: dag [23236,23239]
===
match
---
dictorsetmaker [43900,43946]
dictorsetmaker [43900,43946]
===
match
---
string: "/usr/local/airflow/dags/non_existing_path.py" [33883,33929]
string: "/usr/local/airflow/dags/non_existing_path.py" [33883,33929]
===
match
---
name: test_dag_handle_callback_crash [39832,39862]
name: test_dag_handle_callback_crash [39832,39862]
===
match
---
trailer [35585,35596]
trailer [35585,35596]
===
match
---
name: session [29014,29021]
name: session [29014,29021]
===
match
---
trailer [68414,68421]
trailer [70362,70369]
===
match
---
atom_expr [12111,12140]
atom_expr [12111,12140]
===
match
---
trailer [27810,27824]
trailer [27810,27824]
===
match
---
arglist [24146,24213]
arglist [24146,24213]
===
match
---
atom_expr [10345,10364]
atom_expr [10345,10364]
===
match
---
argument [50184,50199]
argument [50184,50199]
===
match
---
fstring_string: Hello  [18532,18538]
fstring_string: Hello  [18532,18538]
===
match
---
operator: , [12868,12869]
operator: , [12868,12869]
===
match
---
trailer [2965,2969]
trailer [2965,2969]
===
match
---
parameters [36116,36122]
parameters [36116,36122]
===
match
---
name: dag_id [62569,62575]
name: dag_id [64517,64523]
===
match
---
string: 'Invalid values of dag.orientation: only support' [5259,5308]
string: 'Invalid values of dag.orientation: only support' [5259,5308]
===
match
---
trailer [24145,24214]
trailer [24145,24214]
===
match
---
operator: , [11669,11670]
operator: , [11669,11670]
===
match
---
trailer [11768,11781]
trailer [11768,11781]
===
match
---
trailer [32381,32383]
trailer [32381,32383]
===
match
---
name: dag_diff_name [45407,45420]
name: dag_diff_name [45407,45420]
===
match
---
simple_stmt [3472,3502]
simple_stmt [3472,3502]
===
match
---
operator: , [48297,48298]
operator: , [48297,48298]
===
match
---
operator: , [30822,30823]
operator: , [30822,30823]
===
match
---
name: task_instance_1 [49071,49086]
name: task_instance_1 [49071,49086]
===
match
---
simple_stmt [46796,46869]
simple_stmt [46796,46869]
===
match
---
name: get [5610,5613]
name: get [5610,5613]
===
match
---
simple_stmt [43094,43129]
simple_stmt [43094,43129]
===
match
---
string: 'end_date' [11671,11681]
string: 'end_date' [11671,11681]
===
match
---
atom_expr [47964,48033]
atom_expr [47964,48033]
===
match
---
name: delta [53869,53874]
name: delta [55817,55822]
===
match
---
name: airflow [1672,1679]
name: airflow [1672,1679]
===
match
---
name: next_date [58348,58357]
name: next_date [60296,60305]
===
match
---
param [60107,60122]
param [62055,62070]
===
match
---
string: "t4" [35466,35470]
string: "t4" [35466,35470]
===
match
---
operator: } [36091,36092]
operator: } [36091,36092]
===
match
---
string: 'webserver' [29365,29376]
string: 'webserver' [29365,29376]
===
match
---
name: days [49323,49327]
name: days [49323,49327]
===
match
---
operator: == [22902,22904]
operator: == [22902,22904]
===
match
---
trailer [62912,62921]
trailer [64860,64869]
===
match
---
name: row [25301,25304]
name: row [25301,25304]
===
match
---
argument [55209,55221]
argument [57157,57169]
===
match
---
operator: , [14411,14412]
operator: , [14411,14412]
===
match
---
expr_stmt [57160,57385]
expr_stmt [59108,59333]
===
match
---
string: """Test that @dag decorated function fails if positional argument is not set""" [66496,66575]
string: """Test that @dag decorated function fails if positional argument is not set""" [68444,68523]
===
match
---
name: num [65756,65759]
name: num [67704,67707]
===
match
---
name: create_dagrun [68370,68383]
name: create_dagrun [70318,70331]
===
match
---
suite [18888,19484]
suite [18888,19484]
===
match
---
simple_stmt [29092,29165]
simple_stmt [29092,29165]
===
match
---
operator: = [64369,64370]
operator: = [66317,66318]
===
match
---
name: VALUE [67798,67803]
name: VALUE [69746,69751]
===
match
---
name: ACTION_CAN_READ [61535,61550]
name: ACTION_CAN_READ [63483,63498]
===
match
---
string: '0 3 * * *' [22763,22774]
string: '0 3 * * *' [22763,22774]
===
match
---
atom_expr [2811,2827]
atom_expr [2811,2827]
===
match
---
name: task_id [13453,13460]
name: task_id [13453,13460]
===
match
---
name: i [3320,3321]
name: i [3320,3321]
===
match
---
simple_stmt [28652,28752]
simple_stmt [28652,28752]
===
match
---
trailer [59386,59409]
trailer [61334,61357]
===
match
---
name: prev [21144,21148]
name: prev [21144,21148]
===
match
---
name: DagRunType [67479,67489]
name: DagRunType [69427,69437]
===
match
---
name: is_paused [63742,63751]
name: is_paused [65690,65699]
===
match
---
arglist [35724,35759]
arglist [35724,35759]
===
match
---
name: models [2209,2215]
name: models [2209,2215]
===
match
---
name: models [1530,1536]
name: models [1530,1536]
===
match
---
name: return_num [67295,67305]
name: return_num [69243,69253]
===
match
---
number: 10 [21509,21511]
number: 10 [21509,21511]
===
match
---
operator: + [17217,17218]
operator: + [17217,17218]
===
match
---
suite [54327,54364]
suite [56275,56312]
===
match
---
simple_stmt [55189,55232]
simple_stmt [57137,57180]
===
match
---
argument [41288,41305]
argument [41288,41305]
===
match
---
trailer [51186,51193]
trailer [51186,51193]
===
match
---
argument [34908,34923]
argument [34908,34923]
===
match
---
trailer [18571,18651]
trailer [18571,18651]
===
match
---
operator: , [26680,26681]
operator: , [26680,26681]
===
match
---
name: create_dagrun [50680,50693]
name: create_dagrun [50680,50693]
===
match
---
name: dag_run_state [49784,49797]
name: dag_run_state [49784,49797]
===
match
---
trailer [62526,62528]
trailer [64474,64476]
===
match
---
decorator [30550,30567]
decorator [30550,30567]
===
match
---
name: add [62824,62827]
name: add [64772,64775]
===
match
---
simple_stmt [46224,46316]
simple_stmt [46224,46316]
===
match
---
name: test_dag_id [18317,18328]
name: test_dag_id [18317,18328]
===
match
---
simple_stmt [1893,1943]
simple_stmt [1893,1943]
===
match
---
name: isoformat [21177,21186]
name: isoformat [21177,21186]
===
match
---
name: replace [55391,55398]
name: replace [57339,57346]
===
match
---
operator: , [27010,27011]
operator: , [27010,27011]
===
match
---
name: next_dagrun [63433,63444]
name: next_dagrun [65381,65392]
===
match
---
import_name [804,813]
import_name [804,813]
===
match
---
comparison [18127,18256]
comparison [18127,18256]
===
match
---
operator: = [52141,52142]
operator: = [54089,54090]
===
match
---
dotted_name [1720,1743]
dotted_name [1720,1743]
===
match
---
argument [67516,67544]
argument [69464,69492]
===
match
---
simple_stmt [45249,45274]
simple_stmt [45249,45274]
===
match
---
name: self [5702,5706]
name: self [5702,5706]
===
match
---
name: patch [34110,34115]
name: patch [34110,34115]
===
match
---
name: synchronize_session [31295,31314]
name: synchronize_session [31295,31314]
===
match
---
operator: , [54673,54674]
operator: , [56621,56622]
===
match
---
with_stmt [60536,60923]
with_stmt [62484,62871]
===
match
---
atom_expr [51749,51766]
atom_expr [53697,53714]
===
match
---
name: create_session [41561,41575]
name: create_session [41561,41575]
===
match
---
trailer [63618,63624]
trailer [65566,65572]
===
match
---
trailer [68540,68548]
trailer [70488,70496]
===
match
---
assert_stmt [6205,6226]
assert_stmt [6205,6226]
===
match
---
operator: , [33471,33472]
operator: , [33471,33472]
===
match
---
trailer [34122,34157]
trailer [34122,34157]
===
match
---
name: next_dagrun_after_date [61276,61298]
name: next_dagrun_after_date [63224,63246]
===
match
---
expr_stmt [28905,28928]
expr_stmt [28905,28928]
===
match
---
atom_expr [45785,45794]
atom_expr [45785,45794]
===
match
---
arglist [27047,27073]
arglist [27047,27073]
===
match
---
simple_stmt [23164,23220]
simple_stmt [23164,23220]
===
match
---
operator: = [6391,6392]
operator: = [6391,6392]
===
match
---
expr_stmt [40491,40567]
expr_stmt [40491,40567]
===
match
---
trailer [34279,34283]
trailer [34279,34283]
===
match
---
param [46757,46785]
param [46757,46785]
===
match
---
arglist [39106,39167]
arglist [39106,39167]
===
match
---
number: 42 [48148,48150]
number: 42 [48148,48150]
===
match
---
operator: } [60463,60464]
operator: } [62411,62412]
===
match
---
atom [46392,46415]
atom [46392,46415]
===
match
---
name: group [14896,14901]
name: group [14896,14901]
===
match
---
operator: = [13432,13433]
operator: = [13432,13433]
===
match
---
name: _next [22074,22079]
name: _next [22074,22079]
===
match
---
string: 'dag' [29152,29157]
string: 'dag' [29152,29157]
===
match
---
operator: , [57294,57295]
operator: , [59242,59243]
===
match
---
for_stmt [16098,16362]
for_stmt [16098,16362]
===
match
---
name: DummyOperator [37955,37968]
name: DummyOperator [37955,37968]
===
match
---
string: 'test-dag2' [26214,26225]
string: 'test-dag2' [26214,26225]
===
match
---
operator: , [7914,7915]
operator: , [7914,7915]
===
match
---
atom_expr [6110,6138]
atom_expr [6110,6138]
===
match
---
operator: , [26064,26065]
operator: , [26064,26065]
===
match
---
trailer [16060,16073]
trailer [16060,16073]
===
match
---
trailer [37114,37152]
trailer [37114,37152]
===
match
---
simple_stmt [2009,2047]
simple_stmt [2009,2047]
===
match
---
atom_expr [57407,57439]
atom_expr [59355,59387]
===
match
---
trailer [62689,62700]
trailer [64637,64648]
===
match
---
operator: , [44261,44262]
operator: , [44261,44262]
===
match
---
name: default_args [16511,16523]
name: default_args [16511,16523]
===
match
---
trailer [56468,56475]
trailer [58416,58423]
===
match
---
name: xcom_arg [69085,69093]
name: xcom_arg [71033,71041]
===
match
---
funcdef [29796,30545]
funcdef [29796,30545]
===
match
---
name: template_dir [19186,19198]
name: template_dir [19186,19198]
===
match
---
name: DummyOperator [36257,36270]
name: DummyOperator [36257,36270]
===
match
---
trailer [33707,33709]
trailer [33707,33709]
===
match
---
trailer [58251,58274]
trailer [60199,60222]
===
match
---
atom_expr [38433,38460]
atom_expr [38433,38460]
===
match
---
name: all [27075,27078]
name: all [27075,27078]
===
match
---
name: run [43641,43644]
name: run [43641,43644]
===
match
---
name: state [52502,52507]
name: state [54450,54455]
===
match
---
operator: = [30020,30021]
operator: = [30020,30021]
===
match
---
operator: = [4210,4211]
operator: = [4210,4211]
===
match
---
trailer [23398,23408]
trailer [23398,23408]
===
match
---
fstring_expr [15571,15574]
fstring_expr [15571,15574]
===
match
---
atom_expr [48807,48825]
atom_expr [48807,48825]
===
match
---
argument [14054,14077]
argument [14054,14077]
===
match
---
simple_stmt [35965,35999]
simple_stmt [35965,35999]
===
match
---
operator: { [16524,16525]
operator: { [16524,16525]
===
match
---
expr_stmt [53781,53789]
expr_stmt [55729,55737]
===
match
---
assert_stmt [47346,47366]
assert_stmt [47346,47366]
===
match
---
trailer [21476,21484]
trailer [21476,21484]
===
match
---
name: close [29783,29788]
name: close [29783,29788]
===
match
---
trailer [63312,63314]
trailer [65260,65262]
===
match
---
string: "2018-10-26T03:00:00+02:00" [21808,21835]
string: "2018-10-26T03:00:00+02:00" [21808,21835]
===
match
---
string: "2018-10-28T02:50:00+02:00" [21033,21060]
string: "2018-10-28T02:50:00+02:00" [21033,21060]
===
match
---
simple_stmt [34701,34717]
simple_stmt [34701,34717]
===
match
---
name: pickle [846,852]
name: pickle [846,852]
===
match
---
trailer [23865,23884]
trailer [23865,23884]
===
match
---
name: on_success_callback [40261,40280]
name: on_success_callback [40261,40280]
===
match
---
name: params [4474,4480]
name: params [4474,4480]
===
match
---
trailer [35006,35011]
trailer [35006,35011]
===
match
---
expr_stmt [52008,52022]
expr_stmt [53956,53970]
===
match
---
operator: = [12375,12376]
operator: = [12375,12376]
===
match
---
name: timedelta [46626,46635]
name: timedelta [46626,46635]
===
match
---
atom [18208,18229]
atom [18208,18229]
===
match
---
decorator [67089,67136]
decorator [69037,69084]
===
match
---
expr_stmt [47080,47114]
expr_stmt [47080,47114]
===
match
---
param [67005,67009]
param [68953,68957]
===
match
---
operator: * [15030,15031]
operator: * [15030,15031]
===
match
---
argument [39220,39249]
argument [39220,39249]
===
match
---
atom_expr [40054,40070]
atom_expr [40054,40070]
===
match
---
simple_stmt [8780,8813]
simple_stmt [8780,8813]
===
match
---
trailer [12065,12074]
trailer [12065,12074]
===
match
---
trailer [66414,66416]
trailer [68362,68364]
===
match
---
trailer [46097,46116]
trailer [46097,46116]
===
match
---
operator: , [14510,14511]
operator: , [14510,14511]
===
match
---
operator: } [15569,15570]
operator: } [15569,15570]
===
match
---
simple_stmt [43210,43300]
simple_stmt [43210,43300]
===
match
---
atom_expr [61269,61304]
atom_expr [63217,63252]
===
match
---
trailer [40422,40480]
trailer [40422,40480]
===
match
---
operator: >> [36400,36402]
operator: >> [36400,36402]
===
match
---
argument [44579,44596]
argument [44579,44596]
===
match
---
atom_expr [2414,2431]
atom_expr [2414,2431]
===
match
---
atom_expr [20570,20600]
atom_expr [20570,20600]
===
match
---
trailer [49229,49483]
trailer [49229,49483]
===
match
---
trailer [35723,35760]
trailer [35723,35760]
===
match
---
atom_expr [33041,33072]
atom_expr [33041,33072]
===
match
---
name: dag_id [34272,34278]
name: dag_id [34272,34278]
===
match
---
decorated [46321,47008]
decorated [46321,47008]
===
match
---
operator: = [31314,31315]
operator: = [31314,31315]
===
match
---
arglist [53232,53329]
arglist [55180,55277]
===
match
---
operator: = [28980,28981]
operator: = [28980,28981]
===
match
---
simple_stmt [49220,49484]
simple_stmt [49220,49484]
===
match
---
simple_stmt [9077,9101]
simple_stmt [9077,9101]
===
match
---
param [2448,2452]
param [2448,2452]
===
match
---
trailer [29258,29268]
trailer [29258,29268]
===
match
---
name: minutes [64844,64851]
name: minutes [66792,66799]
===
match
---
trailer [48823,48825]
trailer [48823,48825]
===
match
---
argument [7031,7044]
argument [7031,7044]
===
match
---
argument [4961,4995]
argument [4961,4995]
===
match
---
atom_expr [43355,43579]
atom_expr [43355,43579]
===
match
---
name: Session [50440,50447]
name: Session [50440,50447]
===
match
---
simple_stmt [23318,23379]
simple_stmt [23318,23379]
===
match
---
operator: , [30187,30188]
operator: , [30187,30188]
===
match
---
argument [52367,52394]
argument [54315,54342]
===
match
---
operator: = [39277,39278]
operator: = [39277,39278]
===
match
---
argument [36206,36229]
argument [36206,36229]
===
match
---
operator: == [5646,5648]
operator: == [5646,5648]
===
match
---
argument [6039,6071]
argument [6039,6071]
===
match
---
name: datetime [12111,12119]
name: datetime [12111,12119]
===
match
---
operator: , [50849,50850]
operator: , [50849,50850]
===
match
---
operator: , [63419,63420]
operator: , [65367,65368]
===
match
---
testlist_comp [46393,46414]
testlist_comp [46393,46414]
===
match
---
trailer [21425,21434]
trailer [21425,21434]
===
match
---
operator: { [36082,36083]
operator: { [36082,36083]
===
match
---
argument [48317,48339]
argument [48317,48339]
===
match
---
arglist [16626,16670]
arglist [16626,16670]
===
match
---
comparison [17880,17972]
comparison [17880,17972]
===
match
---
atom_expr [15850,15869]
atom_expr [15850,15869]
===
match
---
operator: - [13618,13619]
operator: - [13618,13619]
===
match
---
string: "custom_is_set_to_manual" [47989,48014]
string: "custom_is_set_to_manual" [47989,48014]
===
match
---
simple_stmt [62500,62529]
simple_stmt [64448,64477]
===
match
---
assert_stmt [55931,55966]
assert_stmt [57879,57914]
===
match
---
string: "2018-10-27T03:00:00+02:00" [22254,22281]
string: "2018-10-27T03:00:00+02:00" [22254,22281]
===
match
---
param [29829,29833]
param [29829,29833]
===
match
---
expr_stmt [20022,20056]
expr_stmt [20022,20056]
===
match
---
operator: = [29470,29471]
operator: = [29470,29471]
===
match
---
decorated [2752,3136]
decorated [2752,3136]
===
match
---
arglist [65844,65852]
arglist [67792,67800]
===
match
---
trailer [47258,47277]
trailer [47258,47277]
===
match
---
operator: = [9456,9457]
operator: = [9456,9457]
===
match
---
trailer [65468,65475]
trailer [67416,67423]
===
match
---
name: Session [34082,34089]
name: Session [34082,34089]
===
match
---
arglist [37115,37151]
arglist [37115,37151]
===
match
---
name: session [52758,52765]
name: session [54706,54713]
===
match
---
number: 3 [18127,18128]
number: 3 [18127,18128]
===
match
---
name: dag_id [2898,2904]
name: dag_id [2898,2904]
===
match
---
trailer [2422,2431]
trailer [2422,2431]
===
match
---
name: NONE [48451,48455]
name: NONE [48451,48455]
===
match
---
string: """         Test scheduling a dag where there is a prior DagRun         which has the same run_id as the next run should have         """ [40906,41043]
string: """         Test scheduling a dag where there is a prior DagRun         which has the same run_id as the next run should have         """ [40906,41043]
===
match
---
name: dag [47123,47126]
name: dag [47123,47126]
===
match
---
number: 5 [15357,15358]
number: 5 [15357,15358]
===
match
---
name: self [68665,68669]
name: self [70613,70617]
===
match
---
dictorsetmaker [6053,6070]
dictorsetmaker [6053,6070]
===
match
---
trailer [57277,57286]
trailer [59225,59234]
===
match
---
name: _clean_up [40817,40826]
name: _clean_up [40817,40826]
===
match
---
string: 'airflow' [44252,44261]
string: 'airflow' [44252,44261]
===
match
---
number: 1 [53864,53865]
number: 1 [55812,55813]
===
match
---
operator: , [10138,10139]
operator: , [10138,10139]
===
match
---
name: session [18398,18405]
name: session [18398,18405]
===
match
---
name: name [19101,19105]
name: name [19101,19105]
===
match
---
suite [16133,16362]
suite [16133,16362]
===
match
---
trailer [33512,33519]
trailer [33512,33519]
===
match
---
atom_expr [67701,67718]
atom_expr [69649,69666]
===
match
---
atom_expr [19868,19896]
atom_expr [19868,19896]
===
match
---
name: paused_dags [32193,32204]
name: paused_dags [32193,32204]
===
match
---
trailer [41468,41476]
trailer [41468,41476]
===
match
---
number: 4 [65380,65381]
number: 4 [67328,67329]
===
match
---
for_stmt [54309,54364]
for_stmt [56257,56312]
===
match
---
atom [55355,55390]
atom [57303,57338]
===
match
---
name: next_date [53501,53510]
name: next_date [55449,55458]
===
match
---
operator: , [24203,24204]
operator: , [24203,24204]
===
match
---
name: dag [33041,33044]
name: dag [33041,33044]
===
match
---
dotted_name [1627,1650]
dotted_name [1627,1650]
===
match
---
name: prev [21070,21074]
name: prev [21070,21074]
===
match
---
atom [12935,13097]
atom [12935,13097]
===
match
---
simple_stmt [45755,45795]
simple_stmt [45755,45795]
===
match
---
simple_stmt [10901,10981]
simple_stmt [10901,10981]
===
match
---
simple_stmt [66268,66282]
simple_stmt [68216,68230]
===
match
---
simple_stmt [55327,55456]
simple_stmt [57275,57404]
===
match
---
operator: , [51070,51071]
operator: , [51070,51071]
===
match
---
name: timedelta [939,948]
name: timedelta [939,948]
===
match
---
assert_stmt [22290,22344]
assert_stmt [22290,22344]
===
match
---
operator: = [49327,49328]
operator: = [49327,49328]
===
match
---
trailer [30326,30343]
trailer [30326,30343]
===
match
---
arglist [8439,8478]
arglist [8439,8478]
===
match
---
name: query [28219,28224]
name: query [28219,28224]
===
match
---
name: dummy [1738,1743]
name: dummy [1738,1743]
===
match
---
simple_stmt [21406,21452]
simple_stmt [21406,21452]
===
match
---
argument [7966,7984]
argument [7966,7984]
===
match
---
testlist_comp [46366,46673]
testlist_comp [46366,46673]
===
match
---
name: self [47760,47764]
name: self [47760,47764]
===
match
---
operator: , [46378,46379]
operator: , [46378,46379]
===
match
---
name: airflow [1627,1634]
name: airflow [1627,1634]
===
match
---
fstring_start: f' [60446,60448]
fstring_start: f' [62394,62396]
===
match
---
atom_expr [15076,15102]
atom_expr [15076,15102]
===
match
---
name: orm_dag [33277,33284]
name: orm_dag [33277,33284]
===
match
---
simple_stmt [51017,51093]
simple_stmt [51017,51093]
===
match
---
name: state [51072,51077]
name: state [51072,51077]
===
match
---
expr_stmt [63636,63689]
expr_stmt [65584,65637]
===
match
---
operator: , [16647,16648]
operator: , [16647,16648]
===
match
---
trailer [52182,52184]
trailer [54130,54132]
===
match
---
atom_expr [10901,10980]
atom_expr [10901,10980]
===
match
---
operator: + [17341,17342]
operator: + [17341,17342]
===
match
---
operator: = [62479,62480]
operator: = [64427,64428]
===
match
---
string: 'test-dag' [18572,18582]
string: 'test-dag' [18572,18582]
===
match
---
name: return_num [65716,65726]
name: return_num [67664,67674]
===
match
---
trailer [29561,29592]
trailer [29561,29592]
===
match
---
number: 0 [10225,10226]
number: 0 [10225,10226]
===
match
---
trailer [48632,48640]
trailer [48632,48640]
===
match
---
atom_expr [67441,67634]
atom_expr [69389,69582]
===
match
---
name: weight_rule [15649,15660]
name: weight_rule [15649,15660]
===
match
---
atom_expr [35044,35081]
atom_expr [35044,35081]
===
match
---
assert_stmt [26803,27081]
assert_stmt [26803,27081]
===
match
---
trailer [2969,2976]
trailer [2969,2976]
===
match
---
trailer [2976,2997]
trailer [2976,2997]
===
match
---
simple_stmt [53832,53875]
simple_stmt [55780,55823]
===
match
---
name: model [42848,42853]
name: model [42848,42853]
===
match
---
name: datetime [58318,58326]
name: datetime [60266,60274]
===
match
---
trailer [29040,29042]
trailer [29040,29042]
===
match
---
name: DagModel [34631,34639]
name: DagModel [34631,34639]
===
match
---
trailer [37692,37702]
trailer [37692,37702]
===
match
---
atom_expr [51140,51170]
atom_expr [51140,51170]
===
match
---
name: mock_callback_with_exception [40023,40051]
name: mock_callback_with_exception [40023,40051]
===
match
---
expr_stmt [68692,68723]
expr_stmt [70640,70671]
===
match
---
name: execution_date [39626,39640]
name: execution_date [39626,39640]
===
match
---
operator: , [53959,53960]
operator: , [55907,55908]
===
match
---
operator: = [16633,16634]
operator: = [16633,16634]
===
match
---
string: 'airflow' [59724,59733]
string: 'airflow' [61672,61681]
===
match
---
trailer [3362,3370]
trailer [3362,3370]
===
match
---
operator: , [42565,42566]
operator: , [42565,42566]
===
match
---
comparison [20467,20515]
comparison [20467,20515]
===
match
---
name: dag [53209,53212]
name: dag [55157,55160]
===
match
---
simple_stmt [48649,48664]
simple_stmt [48649,48664]
===
match
---
operator: , [55111,55112]
operator: , [57059,57060]
===
match
---
name: default_args [11769,11781]
name: default_args [11769,11781]
===
match
---
operator: , [7628,7629]
operator: , [7628,7629]
===
match
---
operator: = [35265,35266]
operator: = [35265,35266]
===
match
---
atom_expr [28594,28639]
atom_expr [28594,28639]
===
match
---
name: close [33311,33316]
name: close [33311,33316]
===
match
---
trailer [5068,5081]
trailer [5068,5081]
===
match
---
name: test_sync_to_db_default_view [29800,29828]
name: test_sync_to_db_default_view [29800,29828]
===
match
---
suite [3345,3464]
suite [3345,3464]
===
match
---
comparison [38186,38239]
comparison [38186,38239]
===
match
---
name: dag [54036,54039]
name: dag [55984,55987]
===
match
---
operator: = [4742,4743]
operator: = [4742,4743]
===
match
---
trailer [31712,31725]
trailer [31712,31725]
===
match
---
trailer [24605,24611]
trailer [24605,24611]
===
match
---
trailer [34476,34482]
trailer [34476,34482]
===
match
---
atom [26978,27010]
atom [26978,27010]
===
match
---
argument [39128,39145]
argument [39128,39145]
===
match
---
name: create_dagrun [48849,48862]
name: create_dagrun [48849,48862]
===
match
---
trailer [14468,14478]
trailer [14468,14478]
===
match
---
string: 'tz_dag' [21620,21628]
string: 'tz_dag' [21620,21628]
===
match
---
atom_expr [20069,20098]
atom_expr [20069,20098]
===
match
---
fstring_string: -task- [60464,60470]
fstring_string: -task- [62412,62418]
===
match
---
parameters [20203,20209]
parameters [20203,20209]
===
match
---
string: 'owner' [43900,43907]
string: 'owner' [43900,43907]
===
match
---
name: fileloc [34033,34040]
name: fileloc [34033,34040]
===
match
---
name: f [18960,18961]
name: f [18960,18961]
===
match
---
trailer [68421,68427]
trailer [70369,70375]
===
match
---
operator: , [47223,47224]
operator: , [47223,47224]
===
match
---
trailer [68369,68383]
trailer [70317,70331]
===
match
---
name: start_date [22727,22737]
name: start_date [22727,22737]
===
match
---
name: DEFAULT_DATE [37909,37921]
name: DEFAULT_DATE [37909,37921]
===
match
---
trailer [10207,10228]
trailer [10207,10228]
===
match
---
name: dag [55172,55175]
name: dag [57120,57123]
===
match
---
trailer [18158,18256]
trailer [18158,18256]
===
match
---
simple_stmt [2852,2940]
simple_stmt [2852,2940]
===
match
---
atom_expr [29850,29954]
atom_expr [29850,29954]
===
match
---
assert_stmt [36601,36631]
assert_stmt [36601,36631]
===
match
---
assert_stmt [10691,10726]
assert_stmt [10691,10726]
===
match
---
trailer [41243,41252]
trailer [41243,41252]
===
match
---
name: execution_date [42567,42581]
name: execution_date [42567,42581]
===
match
---
decorator [64089,64175]
decorator [66037,66123]
===
match
---
name: stage [14512,14517]
name: stage [14512,14517]
===
match
---
name: id [38708,38710]
name: id [38708,38710]
===
match
---
name: execution_date [52367,52381]
name: execution_date [54315,54329]
===
match
---
trailer [25473,25476]
trailer [25473,25476]
===
match
---
trailer [46003,46005]
trailer [46003,46005]
===
match
---
name: patcher_dag_code [2604,2620]
name: patcher_dag_code [2604,2620]
===
match
---
operator: = [54020,54021]
operator: = [55968,55969]
===
match
---
import_name [829,838]
import_name [829,838]
===
match
---
string: 'subtask' [30083,30092]
string: 'subtask' [30083,30092]
===
match
---
name: pipeline [15462,15470]
name: pipeline [15462,15470]
===
match
---
with_stmt [14038,15162]
with_stmt [14038,15162]
===
match
---
import_name [1076,1091]
import_name [1076,1091]
===
match
---
string: 'dag' [14047,14052]
string: 'dag' [14047,14052]
===
match
---
import_name [863,878]
import_name [863,878]
===
match
---
number: 2020 [57749,57753]
number: 2020 [59697,59701]
===
match
---
name: datetime [59582,59590]
name: datetime [61530,61538]
===
match
---
operator: = [24576,24577]
operator: = [24576,24577]
===
match
---
name: RUNNING [47237,47244]
name: RUNNING [47237,47244]
===
match
---
arglist [59835,59853]
arglist [61783,61801]
===
match
---
atom_expr [2368,2397]
atom_expr [2368,2397]
===
match
---
name: self [65931,65935]
name: self [67879,67883]
===
match
---
name: dag [54849,54852]
name: dag [56797,56800]
===
match
---
argument [8755,8766]
argument [8755,8766]
===
match
---
operator: + [13632,13633]
operator: + [13632,13633]
===
match
---
trailer [3815,3822]
trailer [3815,3822]
===
match
---
string: 'test-invalid-orientation' [5341,5367]
string: 'test-invalid-orientation' [5341,5367]
===
match
---
simple_stmt [66496,66576]
simple_stmt [68444,68524]
===
match
---
atom_expr [36441,36454]
atom_expr [36441,36454]
===
match
---
name: task_depth [15006,15016]
name: task_depth [15006,15016]
===
match
---
operator: , [44738,44739]
operator: , [44738,44739]
===
match
---
param [65019,65023]
param [66967,66971]
===
match
---
trailer [68975,68981]
trailer [70923,70929]
===
match
---
trailer [9182,9185]
trailer [9182,9185]
===
match
---
atom_expr [33505,33521]
atom_expr [33505,33521]
===
match
---
name: state [47881,47886]
name: state [47881,47886]
===
match
---
atom [26828,26860]
atom [26828,26860]
===
match
---
atom_expr [2543,2590]
atom_expr [2543,2590]
===
match
---
simple_stmt [10375,10410]
simple_stmt [10375,10410]
===
match
---
string: "2018-03-25T03:00:00+02:00" [23128,23155]
string: "2018-03-25T03:00:00+02:00" [23128,23155]
===
match
---
name: clear [49224,49229]
name: clear [49224,49229]
===
match
---
dotted_name [1898,1916]
dotted_name [1898,1916]
===
match
---
name: _task_group [38830,38841]
name: _task_group [38830,38841]
===
match
---
simple_stmt [4363,4396]
simple_stmt [4363,4396]
===
match
---
name: DAG [8537,8540]
name: DAG [8537,8540]
===
match
---
funcdef [32506,32872]
funcdef [32506,32872]
===
match
---
atom_expr [37052,37079]
atom_expr [37052,37079]
===
match
---
name: dag [10704,10707]
name: dag [10704,10707]
===
match
---
with_item [36981,37028]
with_item [36981,37028]
===
match
---
operator: , [43659,43660]
operator: , [43659,43660]
===
match
---
name: SubDagOperator [60768,60782]
name: SubDagOperator [62716,62730]
===
match
---
name: start_date [41307,41317]
name: start_date [41307,41317]
===
match
---
argument [15601,15623]
argument [15601,15623]
===
match
---
suite [25400,25440]
suite [25400,25440]
===
match
---
trailer [64321,64334]
trailer [66269,66282]
===
match
---
simple_stmt [29414,29450]
simple_stmt [29414,29450]
===
match
---
atom_expr [27840,27857]
atom_expr [27840,27857]
===
match
---
name: dag [1601,1604]
name: dag [1601,1604]
===
match
---
name: calculated_weight [13677,13694]
name: calculated_weight [13677,13694]
===
match
---
operator: , [49861,49862]
operator: , [49861,49862]
===
match
---
simple_stmt [28136,28158]
simple_stmt [28136,28158]
===
match
---
atom_expr [29668,29690]
atom_expr [29668,29690]
===
match
---
trailer [29540,29542]
trailer [29540,29542]
===
match
---
funcdef [43821,44086]
funcdef [43821,44086]
===
match
---
atom_expr [42848,42865]
atom_expr [42848,42865]
===
match
---
trailer [27672,27689]
trailer [27672,27689]
===
match
---
operator: = [41462,41463]
operator: = [41462,41463]
===
match
---
name: max_active_runs [60655,60670]
name: max_active_runs [62603,62618]
===
match
---
name: all [24423,24426]
name: all [24423,24426]
===
match
---
name: DAG [16824,16827]
name: DAG [16824,16827]
===
match
---
operator: } [47696,47697]
operator: } [47696,47697]
===
match
---
name: op2 [8006,8009]
name: op2 [8006,8009]
===
match
---
operator: , [13033,13034]
operator: , [13033,13034]
===
match
---
name: op1 [37720,37723]
name: op1 [37720,37723]
===
match
---
name: DagModel [25244,25252]
name: DagModel [25244,25252]
===
match
---
atom_expr [38001,38028]
atom_expr [38001,38028]
===
match
---
name: session [31830,31837]
name: session [31830,31837]
===
match
---
param [5702,5706]
param [5702,5706]
===
match
---
name: all [26390,26393]
name: all [26390,26393]
===
match
---
string: 'dag-bulk-sync-0' [24753,24770]
string: 'dag-bulk-sync-0' [24753,24770]
===
match
---
trailer [13389,13399]
trailer [13389,13399]
===
match
---
name: State [51078,51083]
name: State [51078,51083]
===
match
---
operator: , [34900,34901]
operator: , [34900,34901]
===
match
---
trailer [40107,40119]
trailer [40107,40119]
===
match
---
expr_stmt [59118,59296]
expr_stmt [61066,61244]
===
match
---
name: DEFAULT_DATE [16992,17004]
name: DEFAULT_DATE [16992,17004]
===
match
---
trailer [64445,64448]
trailer [66393,66396]
===
match
---
operator: = [55353,55354]
operator: = [57301,57302]
===
match
---
simple_stmt [33534,33624]
simple_stmt [33534,33624]
===
match
---
operator: = [48175,48176]
operator: = [48175,48176]
===
match
---
argument [7916,7932]
argument [7916,7932]
===
match
---
operator: == [29441,29443]
operator: == [29441,29443]
===
match
---
comp_op [27184,27190]
comp_op [27184,27190]
===
match
---
operator: , [68587,68588]
operator: , [70535,70536]
===
match
---
trailer [69270,69276]
trailer [71218,71224]
===
match
---
assert_stmt [33676,33762]
assert_stmt [33676,33762]
===
match
---
number: 0 [3803,3804]
number: 0 [3803,3804]
===
match
---
operator: , [61691,61692]
operator: , [63639,63640]
===
match
---
name: dag [65440,65443]
name: dag [67388,67391]
===
match
---
operator: , [26262,26263]
operator: , [26262,26263]
===
match
---
name: make_dag [55594,55602]
name: make_dag [57542,57550]
===
match
---
string: 'dag' [10616,10621]
string: 'dag' [10616,10621]
===
match
---
comparison [7235,7250]
comparison [7235,7250]
===
match
---
name: dag [31157,31160]
name: dag [31157,31160]
===
match
---
name: dr [68697,68699]
name: dr [70645,70647]
===
match
---
string: 'op3' [6392,6397]
string: 'op3' [6392,6397]
===
match
---
name: DummyOperator [16893,16906]
name: DummyOperator [16893,16906]
===
match
---
name: self [34779,34783]
name: self [34779,34783]
===
match
---
assert_stmt [45676,45705]
assert_stmt [45676,45705]
===
match
---
operator: , [21511,21512]
operator: , [21511,21512]
===
match
---
operator: , [18084,18085]
operator: , [18084,18085]
===
match
---
name: state [48922,48927]
name: state [48922,48927]
===
match
---
name: raises [5228,5234]
name: raises [5228,5234]
===
match
---
trailer [30402,30409]
trailer [30402,30409]
===
match
---
trailer [4735,4795]
trailer [4735,4795]
===
match
---
atom [15005,15029]
atom [15005,15029]
===
match
---
argument [9749,9760]
argument [9749,9760]
===
match
---
atom_expr [26536,26562]
atom_expr [26536,26562]
===
match
---
trailer [37394,37401]
trailer [37394,37401]
===
match
---
trailer [21186,21188]
trailer [21186,21188]
===
match
---
comparison [6722,6743]
comparison [6722,6743]
===
match
---
operator: = [53992,53993]
operator: = [55940,55941]
===
match
---
argument [42536,42565]
argument [42536,42565]
===
match
---
operator: , [16484,16485]
operator: , [16484,16485]
===
match
---
operator: = [3303,3304]
operator: = [3303,3304]
===
match
---
name: dag [30870,30873]
name: dag [30870,30873]
===
match
---
name: tree_view [36487,36496]
name: tree_view [36487,36496]
===
match
---
name: owner [43258,43263]
name: owner [43258,43263]
===
match
---
name: dag [14116,14119]
name: dag [14116,14119]
===
match
---
argument [4772,4794]
argument [4772,4794]
===
match
---
trailer [19881,19896]
trailer [19881,19896]
===
match
---
with_stmt [9617,10028]
with_stmt [9617,10028]
===
match
---
operator: = [9643,9644]
operator: = [9643,9644]
===
match
---
atom [60876,60906]
atom [62824,62854]
===
match
---
trailer [52582,52599]
trailer [54530,54547]
===
match
---
operator: = [47886,47887]
operator: = [47886,47887]
===
match
---
simple_stmt [62165,62207]
simple_stmt [64113,64155]
===
match
---
trailer [27746,27750]
trailer [27746,27750]
===
match
---
name: dagrun [51649,51655]
name: dagrun [51649,51655]
===
match
---
name: convert_to_utc [21579,21593]
name: convert_to_utc [21579,21593]
===
match
---
operator: = [47988,47989]
operator: = [47988,47989]
===
match
---
suite [16715,18440]
suite [16715,18440]
===
match
---
operator: , [12136,12137]
operator: , [12136,12137]
===
match
---
simple_stmt [22661,22698]
simple_stmt [22661,22698]
===
match
---
assert_stmt [57448,57497]
assert_stmt [59396,59445]
===
match
---
name: following_schedule [23017,23035]
name: following_schedule [23017,23035]
===
match
---
trailer [46237,46247]
trailer [46237,46247]
===
match
---
suite [36123,36718]
suite [36123,36718]
===
match
---
trailer [62518,62526]
trailer [64466,64474]
===
match
---
string: "test_dag" [35724,35734]
string: "test_dag" [35724,35734]
===
match
---
atom [10661,10680]
atom [10661,10680]
===
match
---
name: test_create_dagrun_run_type_is_obtained_from_run_id [47708,47759]
name: test_create_dagrun_run_type_is_obtained_from_run_id [47708,47759]
===
match
---
trailer [25638,25641]
trailer [25638,25641]
===
match
---
argument [44322,44339]
argument [44322,44339]
===
match
---
name: default_view [30497,30509]
name: default_view [30497,30509]
===
match
---
simple_stmt [9970,9992]
simple_stmt [9970,9992]
===
match
---
name: TaskFail [1488,1496]
name: TaskFail [1488,1496]
===
match
---
dictorsetmaker [24850,24904]
dictorsetmaker [24850,24904]
===
match
---
operator: = [37976,37977]
operator: = [37976,37977]
===
match
---
assert_stmt [45714,45746]
assert_stmt [45714,45746]
===
match
---
trailer [16478,16544]
trailer [16478,16544]
===
match
---
trailer [62747,62756]
trailer [64695,64704]
===
match
---
name: dagparam [1642,1650]
name: dagparam [1642,1650]
===
match
---
trailer [67535,67542]
trailer [69483,69490]
===
match
---
trailer [64785,64787]
trailer [66733,66735]
===
match
---
operator: , [49443,49444]
operator: , [49443,49444]
===
match
---
expr_stmt [21908,21943]
expr_stmt [21908,21943]
===
match
---
operator: = [40705,40706]
operator: = [40705,40706]
===
match
---
name: new_value [68338,68347]
name: new_value [70286,70295]
===
match
---
operator: = [48746,48747]
operator: = [48746,48747]
===
match
---
name: owner [40445,40450]
name: owner [40445,40450]
===
match
---
name: dag_id [63355,63361]
name: dag_id [65303,65309]
===
match
---
operator: , [37896,37897]
operator: , [37896,37897]
===
match
---
operator: , [44440,44441]
operator: , [44440,44441]
===
match
---
name: asserts [2258,2265]
name: asserts [2258,2265]
===
match
---
name: start [22738,22743]
name: start [22738,22743]
===
match
---
argument [7121,7134]
argument [7121,7134]
===
match
---
name: DAG [27669,27672]
name: DAG [27669,27672]
===
match
---
simple_stmt [29625,29653]
simple_stmt [29625,29653]
===
match
---
simple_stmt [1076,1092]
simple_stmt [1076,1092]
===
match
---
string: "t1" [37074,37078]
string: "t1" [37074,37078]
===
match
---
atom_expr [18132,18256]
atom_expr [18132,18256]
===
match
---
operator: = [9778,9779]
operator: = [9778,9779]
===
match
---
dictorsetmaker [16525,16542]
dictorsetmaker [16525,16542]
===
match
---
string: 'start_date' [43920,43932]
string: 'start_date' [43920,43932]
===
match
---
name: models [18561,18567]
name: models [18561,18567]
===
match
---
arglist [44429,44459]
arglist [44429,44459]
===
match
---
assert_stmt [46878,46949]
assert_stmt [46878,46949]
===
match
---
atom_expr [34029,34040]
atom_expr [34029,34040]
===
match
---
name: op1 [37662,37665]
name: op1 [37662,37665]
===
match
---
atom_expr [62165,62183]
atom_expr [64113,64131]
===
match
---
name: DAG [60541,60544]
name: DAG [62489,62492]
===
match
---
name: dags [24513,24517]
name: dags [24513,24517]
===
match
---
name: dag [12083,12086]
name: dag [12083,12086]
===
match
---
simple_stmt [44854,44914]
simple_stmt [44854,44914]
===
match
---
name: start_date [50578,50588]
name: start_date [50578,50588]
===
match
---
argument [48922,48940]
argument [48922,48940]
===
match
---
testlist_comp [46367,46377]
testlist_comp [46367,46377]
===
match
---
simple_stmt [26803,27082]
simple_stmt [26803,27082]
===
match
---
simple_stmt [22941,22996]
simple_stmt [22941,22996]
===
match
---
string: 'noop_pipeline' [65881,65896]
string: 'noop_pipeline' [67829,67844]
===
match
---
name: _clean_up [48623,48632]
name: _clean_up [48623,48632]
===
match
---
operator: = [7950,7951]
operator: = [7950,7951]
===
match
---
decorated [67089,67394]
decorated [69037,69342]
===
match
---
name: max_active_runs [48715,48730]
name: max_active_runs [48715,48730]
===
match
---
param [10769,10773]
param [10769,10773]
===
match
---
simple_stmt [62056,62105]
simple_stmt [64004,64053]
===
match
---
atom_expr [68312,68329]
atom_expr [70260,70277]
===
match
---
trailer [33617,33621]
trailer [33617,33621]
===
match
---
simple_stmt [9195,9231]
simple_stmt [9195,9231]
===
match
---
argument [43236,43256]
argument [43236,43256]
===
match
---
argument [23707,23720]
argument [23707,23720]
===
match
---
comparison [53085,53120]
comparison [55033,55068]
===
match
---
with_stmt [26494,26563]
with_stmt [26494,26563]
===
match
---
name: dag_id [32318,32324]
name: dag_id [32318,32324]
===
match
---
operator: , [19942,19943]
operator: , [19942,19943]
===
match
---
suite [39881,40835]
suite [39881,40835]
===
match
---
operator: { [8586,8587]
operator: { [8586,8587]
===
match
---
param [64215,64226]
param [66163,66174]
===
match
---
name: state [41457,41462]
name: state [41457,41462]
===
match
---
trailer [67305,67312]
trailer [69253,69260]
===
match
---
atom [36082,36092]
atom [36082,36092]
===
match
---
name: dag_run_state [49358,49371]
name: dag_run_state [49358,49371]
===
match
---
name: owner [30015,30020]
name: owner [30015,30020]
===
match
---
suite [53604,54459]
suite [55552,56407]
===
match
---
atom [32019,32090]
atom [32019,32090]
===
match
---
decorated [64089,64624]
decorated [66037,66572]
===
match
---
name: DAG [16475,16478]
name: DAG [16475,16478]
===
match
---
name: datetime_tz [2094,2105]
name: datetime_tz [2094,2105]
===
match
---
trailer [41265,41331]
trailer [41265,41331]
===
match
---
name: dag_id [6878,6884]
name: dag_id [6878,6884]
===
match
---
operator: , [37422,37423]
operator: , [37422,37423]
===
match
---
argument [63433,63459]
argument [65381,65407]
===
match
---
atom_expr [30663,30737]
atom_expr [30663,30737]
===
match
---
simple_stmt [47775,47828]
simple_stmt [47775,47828]
===
match
---
name: tzinfo [11840,11846]
name: tzinfo [11840,11846]
===
match
---
operator: , [53302,53303]
operator: , [55250,55251]
===
match
---
name: default_view [30449,30461]
name: default_view [30449,30461]
===
match
---
atom_expr [26499,26522]
atom_expr [26499,26522]
===
match
---
name: local_tz [21743,21751]
name: local_tz [21743,21751]
===
match
---
operator: , [32469,32470]
operator: , [32469,32470]
===
match
---
trailer [32869,32871]
trailer [32869,32871]
===
match
---
param [49962,49975]
param [49962,49975]
===
match
---
simple_stmt [54340,54364]
simple_stmt [56288,56312]
===
match
---
operator: == [17777,17779]
operator: == [17777,17779]
===
match
---
operator: , [8460,8461]
operator: , [8460,8461]
===
match
---
name: session [30275,30282]
name: session [30275,30282]
===
match
---
name: schedule_interval [46832,46849]
name: schedule_interval [46832,46849]
===
match
---
argument [48016,48032]
argument [48016,48032]
===
match
---
operator: , [40462,40463]
operator: , [40462,40463]
===
match
---
operator: , [43918,43919]
operator: , [43918,43919]
===
match
---
param [54706,54713]
param [56654,56661]
===
match
---
name: following_schedule [27792,27810]
name: following_schedule [27792,27810]
===
match
---
argument [28624,28638]
argument [28624,28638]
===
match
---
arglist [25171,25197]
arglist [25171,25197]
===
match
---
name: dag_run [39675,39682]
name: dag_run [39675,39682]
===
match
---
trailer [16280,16302]
trailer [16280,16302]
===
match
---
operator: = [23832,23833]
operator: = [23832,23833]
===
match
---
name: DEFAULT_DATE [50260,50272]
name: DEFAULT_DATE [50260,50272]
===
match
---
name: range [60398,60403]
name: range [62346,62351]
===
match
---
trailer [50764,50771]
trailer [50764,50771]
===
match
---
operator: == [12170,12172]
operator: == [12170,12172]
===
match
---
atom_expr [68498,68515]
atom_expr [70446,70463]
===
match
---
operator: = [18093,18094]
operator: = [18093,18094]
===
match
---
import_from [1360,1429]
import_from [1360,1429]
===
match
---
operator: , [29605,29606]
operator: , [29605,29606]
===
match
---
string: 'dag_without_catchup_hourly' [56057,56085]
string: 'dag_without_catchup_hourly' [58005,58033]
===
match
---
trailer [47236,47244]
trailer [47236,47244]
===
match
---
import_from [1430,1516]
import_from [1430,1516]
===
match
---
argument [28101,28116]
argument [28101,28116]
===
match
---
operator: , [20145,20146]
operator: , [20145,20146]
===
match
---
string: 'tag-2' [24205,24212]
string: 'tag-2' [24205,24212]
===
match
---
operator: , [39287,39288]
operator: , [39287,39288]
===
match
---
comparison [46255,46280]
comparison [46255,46280]
===
match
---
name: dag_id [39057,39063]
name: dag_id [39057,39063]
===
match
---
trailer [19742,19750]
trailer [19742,19750]
===
match
---
atom_expr [47382,47423]
atom_expr [47382,47423]
===
match
---
simple_stmt [36251,36285]
simple_stmt [36251,36285]
===
match
---
operator: , [46439,46440]
operator: , [46439,46440]
===
match
---
operator: , [22616,22617]
operator: , [22616,22617]
===
match
---
operator: , [49630,49631]
operator: , [49630,49631]
===
match
---
atom_expr [47540,47632]
atom_expr [47540,47632]
===
match
---
expr_stmt [27775,27824]
expr_stmt [27775,27824]
===
match
---
trailer [10344,10365]
trailer [10344,10365]
===
match
---
name: task_dict [13390,13399]
name: task_dict [13390,13399]
===
match
---
name: now [55544,55547]
name: now [57492,57495]
===
match
---
expr_stmt [63734,63758]
expr_stmt [65682,65706]
===
match
---
simple_stmt [6303,6332]
simple_stmt [6303,6332]
===
match
---
name: query [32229,32234]
name: query [32229,32234]
===
match
---
name: str [51928,51931]
name: str [53876,53879]
===
match
---
name: dag [59118,59121]
name: dag [61066,61069]
===
match
---
name: priority_weight_total [13702,13723]
name: priority_weight_total [13702,13723]
===
match
---
name: datetime [53282,53290]
name: datetime [55230,55238]
===
match
---
expr_stmt [8870,8902]
expr_stmt [8870,8902]
===
match
---
expr_stmt [44469,44529]
expr_stmt [44469,44529]
===
match
---
name: DEFAULT_ARGS [66618,66630]
name: DEFAULT_ARGS [68566,68578]
===
match
---
name: DummyOperator [14184,14197]
name: DummyOperator [14184,14197]
===
match
---
argument [24547,24570]
argument [24547,24570]
===
match
---
operator: = [51238,51239]
operator: = [51238,51239]
===
match
---
trailer [52726,52736]
trailer [54674,54684]
===
match
---
operator: { [60876,60877]
operator: { [62824,62825]
===
match
---
atom_expr [29558,29592]
atom_expr [29558,29592]
===
match
---
atom_expr [10511,10530]
atom_expr [10511,10530]
===
match
---
name: start_date [10623,10633]
name: start_date [10623,10633]
===
match
---
arglist [10616,10680]
arglist [10616,10680]
===
match
---
name: start_date [6784,6794]
name: start_date [6784,6794]
===
match
---
name: VALUE [68976,68981]
name: VALUE [70924,70929]
===
match
---
trailer [14889,14905]
trailer [14889,14905]
===
match
---
trailer [44308,44340]
trailer [44308,44340]
===
match
---
operator: = [27533,27534]
operator: = [27533,27534]
===
match
---
operator: , [51722,51723]
operator: , [53670,53671]
===
match
---
name: pendulum [20427,20435]
name: pendulum [20427,20435]
===
match
---
comparison [6924,6953]
comparison [6924,6953]
===
match
---
name: settings [50431,50439]
name: settings [50431,50439]
===
match
---
name: DummyOperator [48748,48761]
name: DummyOperator [48748,48761]
===
match
---
decorated [67195,67271]
decorated [69143,69219]
===
match
---
name: topological_list [9050,9066]
name: topological_list [9050,9066]
===
match
---
return_stmt [3472,3501]
return_stmt [3472,3501]
===
match
---
comparison [48049,48081]
comparison [48049,48081]
===
match
---
simple_stmt [8531,8607]
simple_stmt [8531,8607]
===
match
---
name: dag_id [4736,4742]
name: dag_id [4736,4742]
===
match
---
suite [47478,47699]
suite [47478,47699]
===
match
---
name: isinstance [65429,65439]
name: isinstance [67377,67387]
===
match
---
name: task_id [50192,50199]
name: task_id [50192,50199]
===
match
---
argument [30209,30232]
argument [30209,30232]
===
match
---
trailer [11812,11825]
trailer [11812,11825]
===
match
---
expr_stmt [15462,15821]
expr_stmt [15462,15821]
===
match
---
trailer [16569,16576]
trailer [16569,16576]
===
match
---
operator: , [31529,31530]
operator: , [31529,31530]
===
match
---
atom_expr [66297,66312]
atom_expr [68245,68260]
===
match
---
name: enumerate [14521,14530]
name: enumerate [14521,14530]
===
match
---
name: DAG [11955,11958]
name: DAG [11955,11958]
===
match
---
atom_expr [62996,63011]
atom_expr [64944,64959]
===
match
---
param [43839,43843]
param [43839,43843]
===
match
---
name: Session [52175,52182]
name: Session [54123,54130]
===
match
---
atom_expr [40617,40660]
atom_expr [40617,40660]
===
match
---
string: """         Test if the schedule_interval will be auto aligned with the start_date         such that if the start_date coincides with the schedule the first         execution_date will be start_date, otherwise it will be start_date +         interval.         """ [58846,59109]
string: """         Test if the schedule_interval will be auto aligned with the start_date         such that if the start_date coincides with the schedule the first         execution_date will be start_date, otherwise it will be start_date +         interval.         """ [60794,61057]
===
match
---
name: test_create_dagrun_job_id_is_set [48091,48123]
name: test_create_dagrun_job_id_is_set [48091,48123]
===
match
---
atom_expr [32221,32383]
atom_expr [32221,32383]
===
match
---
name: task_dict [16114,16123]
name: task_dict [16114,16123]
===
match
---
assert_stmt [44040,44085]
assert_stmt [44040,44085]
===
match
---
operator: = [65219,65220]
operator: = [67167,67168]
===
match
---
for_stmt [14505,14756]
for_stmt [14505,14756]
===
match
---
atom_expr [3808,3823]
atom_expr [3808,3823]
===
match
---
classdef [62266,63934]
classdef [64214,65882]
===
match
---
name: minutes [60714,60721]
name: minutes [62662,62669]
===
match
---
operator: , [67544,67545]
operator: , [69492,69493]
===
match
---
simple_stmt [21460,21555]
simple_stmt [21460,21555]
===
match
---
trailer [55398,55455]
trailer [57346,57403]
===
match
---
name: dag [6924,6927]
name: dag [6924,6927]
===
match
---
name: DagRunType [47929,47939]
name: DagRunType [47929,47939]
===
match
---
name: self [51883,51887]
name: self [53831,53835]
===
match
---
name: DummyOperator [9690,9703]
name: DummyOperator [9690,9703]
===
match
---
atom_expr [42492,42508]
atom_expr [42492,42508]
===
match
---
trailer [48848,48862]
trailer [48848,48862]
===
match
---
operator: == [53105,53107]
operator: == [55053,55055]
===
match
---
trailer [26753,26770]
trailer [26753,26770]
===
match
---
trailer [40400,40409]
trailer [40400,40409]
===
match
---
string: 't1' [36608,36612]
string: 't1' [36608,36612]
===
match
---
name: loads [45296,45301]
name: loads [45296,45301]
===
match
---
operator: = [58007,58008]
operator: = [59955,59956]
===
match
---
simple_stmt [62870,62928]
simple_stmt [64818,64876]
===
match
---
dictorsetmaker [29216,29234]
dictorsetmaker [29216,29234]
===
match
---
testlist_comp [46507,46534]
testlist_comp [46507,46534]
===
match
---
atom [24301,24319]
atom [24301,24319]
===
match
---
name: sync_to_db [34175,34185]
name: sync_to_db [34175,34185]
===
match
---
operator: = [33448,33449]
operator: = [33448,33449]
===
match
---
atom [11627,11705]
atom [11627,11705]
===
match
---
atom_expr [63362,63372]
atom_expr [65310,65320]
===
match
---
trailer [51927,51932]
trailer [53875,53880]
===
match
---
name: dag_id [16828,16834]
name: dag_id [16828,16834]
===
match
---
trailer [4393,4395]
trailer [4393,4395]
===
match
---
name: timezone [58426,58434]
name: timezone [60374,60382]
===
match
---
simple_stmt [7499,7532]
simple_stmt [7499,7532]
===
match
---
name: DummyOperator [7544,7557]
name: DummyOperator [7544,7557]
===
match
---
name: timezone [67527,67535]
name: timezone [69475,69483]
===
match
---
operator: == [25820,25822]
operator: == [25820,25822]
===
match
---
atom_expr [8420,8479]
atom_expr [8420,8479]
===
match
---
trailer [38400,38414]
trailer [38400,38414]
===
match
---
arglist [61977,62046]
arglist [63925,63994]
===
match
---
argument [31752,31766]
argument [31752,31766]
===
match
---
name: DEFAULT_DATE [12856,12868]
name: DEFAULT_DATE [12856,12868]
===
match
---
atom_expr [51035,51092]
atom_expr [51035,51092]
===
match
---
name: owner [59345,59350]
name: owner [61293,61298]
===
match
---
expr_stmt [22827,22862]
expr_stmt [22827,22862]
===
match
---
trailer [14744,14755]
trailer [14744,14755]
===
match
---
funcdef [64931,65001]
funcdef [66879,66949]
===
match
---
atom_expr [13448,13460]
atom_expr [13448,13460]
===
match
---
atom_expr [67170,67180]
atom_expr [69118,69128]
===
match
---
name: dag [25576,25579]
name: dag [25576,25579]
===
match
---
name: dag_run [39618,39625]
name: dag_run [39618,39625]
===
match
---
name: raises [66883,66889]
name: raises [68831,68837]
===
match
---
atom_expr [25618,25641]
atom_expr [25618,25641]
===
match
---
trailer [20593,20600]
trailer [20593,20600]
===
match
---
trailer [41902,41921]
trailer [41902,41921]
===
match
---
atom_expr [8876,8902]
atom_expr [8876,8902]
===
match
---
operator: = [40280,40281]
operator: = [40280,40281]
===
match
---
name: dag_id [54667,54673]
name: dag_id [56615,56621]
===
match
---
operator: = [7105,7106]
operator: = [7105,7106]
===
match
---
arglist [21503,21518]
arglist [21503,21518]
===
match
---
name: DagModel [31233,31241]
name: DagModel [31233,31241]
===
match
---
operator: = [22626,22627]
operator: = [22626,22627]
===
match
---
name: schedule_interval [54003,54020]
name: schedule_interval [55951,55968]
===
match
---
atom_expr [12572,12604]
atom_expr [12572,12604]
===
match
---
testlist_comp [27752,27763]
testlist_comp [27752,27763]
===
match
---
trailer [36496,36498]
trailer [36496,36498]
===
match
---
simple_stmt [5135,5208]
simple_stmt [5135,5208]
===
match
---
name: datetime [55489,55497]
name: datetime [57437,57445]
===
match
---
simple_stmt [24015,24071]
simple_stmt [24015,24071]
===
match
---
name: i [13114,13115]
name: i [13114,13115]
===
match
---
operator: , [43532,43533]
operator: , [43532,43533]
===
match
---
name: return_num [65312,65322]
name: return_num [67260,67270]
===
match
---
name: dag_subclass_diff_name [44606,44628]
name: dag_subclass_diff_name [44606,44628]
===
match
---
expr_stmt [49717,49736]
expr_stmt [49717,49736]
===
match
---
expr_stmt [60203,60375]
expr_stmt [62151,62323]
===
match
---
trailer [34664,34691]
trailer [34664,34691]
===
match
---
name: dag [54418,54421]
name: dag [56366,56369]
===
match
---
name: sync_to_db [42714,42724]
name: sync_to_db [42714,42724]
===
match
---
name: logging [821,828]
name: logging [821,828]
===
match
---
name: pickle [44023,44029]
name: pickle [44023,44029]
===
match
---
trailer [10724,10726]
trailer [10724,10726]
===
match
---
expr_stmt [23969,24006]
expr_stmt [23969,24006]
===
match
---
name: schedule_interval [41182,41199]
name: schedule_interval [41182,41199]
===
match
---
name: current_task [15947,15959]
name: current_task [15947,15959]
===
match
---
operator: = [41381,41382]
operator: = [41381,41382]
===
match
---
name: op3 [38153,38156]
name: op3 [38153,38156]
===
match
---
argument [63167,63185]
argument [65115,65133]
===
match
---
trailer [38674,38680]
trailer [38674,38680]
===
match
---
arith_expr [60471,60476]
arith_expr [62419,62424]
===
match
---
trailer [17272,17279]
trailer [17272,17279]
===
match
---
argument [15408,15440]
argument [15408,15440]
===
match
---
fstring_start: f' [12976,12978]
fstring_start: f' [12976,12978]
===
match
---
trailer [65039,65041]
trailer [66987,66989]
===
match
---
testlist_comp [32453,32468]
testlist_comp [32453,32468]
===
match
---
name: DagModel [63805,63813]
name: DagModel [65753,65761]
===
match
---
trailer [42535,42613]
trailer [42535,42613]
===
match
---
number: 1 [50290,50291]
number: 1 [50290,50291]
===
match
---
simple_stmt [7946,7986]
simple_stmt [7946,7986]
===
match
---
name: datetime [795,803]
name: datetime [795,803]
===
match
---
name: days [51308,51312]
name: days [51308,51312]
===
match
---
trailer [6761,6808]
trailer [6761,6808]
===
match
---
name: list_py_file_paths [34408,34426]
name: list_py_file_paths [34408,34426]
===
match
---
name: ti [68739,68741]
name: ti [70687,70689]
===
match
---
trailer [59590,59613]
trailer [61538,61561]
===
match
---
expr_stmt [53832,53874]
expr_stmt [55780,55822]
===
match
---
name: WeightRule [14332,14342]
name: WeightRule [14332,14342]
===
match
---
argument [62359,62382]
argument [64307,64330]
===
match
---
simple_stmt [15056,15103]
simple_stmt [15056,15103]
===
match
---
assert_stmt [8338,8404]
assert_stmt [8338,8404]
===
match
---
name: subdag [28652,28658]
name: subdag [28652,28658]
===
match
---
operator: = [35831,35832]
operator: = [35831,35832]
===
match
---
funcdef [18844,19484]
funcdef [18844,19484]
===
match
---
trailer [30784,30837]
trailer [30784,30837]
===
match
---
number: 1 [58138,58139]
number: 1 [60086,60087]
===
match
---
name: set_upstream [13337,13349]
name: set_upstream [13337,13349]
===
match
---
parameters [15221,15227]
parameters [15221,15227]
===
match
---
name: task_instance_1 [51115,51130]
name: task_instance_1 [51115,51130]
===
match
---
atom_expr [6924,6944]
atom_expr [6924,6944]
===
match
---
name: op2 [36017,36020]
name: op2 [36017,36020]
===
match
---
atom_expr [55301,55318]
atom_expr [57249,57266]
===
match
---
param [63988,63992]
param [65936,65940]
===
match
---
name: close [63926,63931]
name: close [65874,65879]
===
match
---
operator: = [35923,35924]
operator: = [35923,35924]
===
match
---
fstring [12976,12991]
fstring [12976,12991]
===
match
---
param [35632,35636]
param [35632,35636]
===
match
---
expr_stmt [41157,41231]
expr_stmt [41157,41231]
===
match
---
param [66721,66724]
param [68669,68672]
===
match
---
name: stop [2740,2744]
name: stop [2740,2744]
===
match
---
operator: = [51273,51274]
operator: = [51273,51274]
===
match
---
argument [8073,8098]
argument [8073,8098]
===
match
---
suite [21317,22345]
suite [21317,22345]
===
match
---
comparison [34335,34365]
comparison [34335,34365]
===
match
---
trailer [14784,14794]
trailer [14784,14794]
===
match
---
shift_expr [36389,36406]
shift_expr [36389,36406]
===
match
---
simple_stmt [65345,65356]
simple_stmt [67293,67304]
===
match
---
atom_expr [67793,67803]
atom_expr [69741,69751]
===
match
---
trailer [51208,51214]
trailer [51208,51214]
===
match
---
operator: , [19139,19140]
operator: , [19139,19140]
===
match
---
comparison [30394,30418]
comparison [30394,30418]
===
match
---
argument [19166,19198]
argument [19166,19198]
===
match
---
operator: = [36324,36325]
operator: = [36324,36325]
===
match
---
trailer [6245,6251]
trailer [6245,6251]
===
match
---
expr_stmt [15331,15340]
expr_stmt [15331,15340]
===
match
---
string: "2018-10-28T03:00:00+01:00" [22031,22058]
string: "2018-10-28T03:00:00+01:00" [22031,22058]
===
match
---
operator: + [44655,44656]
operator: + [44655,44656]
===
match
---
name: is_active [62782,62791]
name: is_active [64730,64739]
===
match
---
atom_expr [45721,45733]
atom_expr [45721,45733]
===
match
---
operator: = [23234,23235]
operator: = [23234,23235]
===
match
---
name: utc [22814,22817]
name: utc [22814,22817]
===
match
---
name: DEFAULT_DATE [41837,41849]
name: DEFAULT_DATE [41837,41849]
===
match
---
operator: , [8234,8235]
operator: , [8234,8235]
===
match
---
name: dag [61087,61090]
name: dag [63035,63038]
===
match
---
trailer [36884,36962]
trailer [36884,36962]
===
match
---
trailer [2905,2912]
trailer [2905,2912]
===
match
---
trailer [4426,4435]
trailer [4426,4435]
===
match
---
operator: , [17634,17635]
operator: , [17634,17635]
===
match
---
name: execution_date [68483,68497]
name: execution_date [70431,70445]
===
match
---
atom_expr [24387,24400]
atom_expr [24387,24400]
===
match
---
name: DAG [41163,41166]
name: DAG [41163,41166]
===
match
---
operator: + [17092,17093]
operator: + [17092,17093]
===
match
---
trailer [62125,62131]
trailer [64073,64079]
===
match
---
name: dag_id [29512,29518]
name: dag_id [29512,29518]
===
match
---
operator: , [27584,27585]
operator: , [27584,27585]
===
match
---
atom_expr [68198,68215]
atom_expr [70146,70163]
===
match
---
operator: = [28066,28067]
operator: = [28066,28067]
===
match
---
with_stmt [35234,35611]
with_stmt [35234,35611]
===
match
---
operator: = [17052,17053]
operator: = [17052,17053]
===
match
---
exprlist [14509,14517]
exprlist [14509,14517]
===
match
---
name: pendulum [21530,21538]
name: pendulum [21530,21538]
===
match
---
name: io [36441,36443]
name: io [36441,36443]
===
match
---
name: schedule_interval [46738,46755]
name: schedule_interval [46738,46755]
===
match
---
string: 'start_date' [11826,11838]
string: 'start_date' [11826,11838]
===
match
---
name: self [68498,68502]
name: self [70446,70450]
===
match
---
name: DAG [18277,18280]
name: DAG [18277,18280]
===
match
---
operator: = [52340,52341]
operator: = [54288,54289]
===
match
---
argument [38493,38505]
argument [38493,38505]
===
match
---
string: "test_schedule_dag_fake_scheduled_previous" [41105,41148]
string: "test_schedule_dag_fake_scheduled_previous" [41105,41148]
===
match
---
atom_expr [36303,36330]
atom_expr [36303,36330]
===
match
---
operator: , [46830,46831]
operator: , [46830,46831]
===
match
---
atom_expr [14719,14755]
atom_expr [14719,14755]
===
match
---
name: task [16102,16106]
name: task [16102,16106]
===
match
---
name: task_decorator [68997,69011]
name: task_decorator [70945,70959]
===
match
---
fstring [64370,64387]
fstring [66318,66335]
===
match
---
trailer [7208,7212]
trailer [7208,7212]
===
match
---
atom_expr [43589,43610]
atom_expr [43589,43610]
===
match
---
atom_expr [62576,62586]
atom_expr [64524,64534]
===
match
---
parameters [37782,37788]
parameters [37782,37788]
===
match
---
atom_expr [14404,14419]
atom_expr [14404,14419]
===
match
---
atom_expr [25859,25895]
atom_expr [25859,25895]
===
match
---
name: prev [21235,21239]
name: prev [21235,21239]
===
match
---
operator: , [8373,8374]
operator: , [8373,8374]
===
match
---
name: State [51724,51729]
name: State [53672,53677]
===
match
---
trailer [49162,49168]
trailer [49162,49168]
===
match
---
operator: = [62738,62739]
operator: = [64686,64687]
===
match
---
dictorsetmaker [4318,4335]
dictorsetmaker [4318,4335]
===
match
---
operator: = [53971,53972]
operator: = [55919,55920]
===
match
---
operator: , [3321,3322]
operator: , [3321,3322]
===
match
---
name: test_dag_id [16835,16846]
name: test_dag_id [16835,16846]
===
match
---
atom_expr [21616,21678]
atom_expr [21616,21678]
===
match
---
argument [45951,45979]
argument [45951,45979]
===
match
---
simple_stmt [42518,42614]
simple_stmt [42518,42614]
===
match
---
atom_expr [41463,41476]
atom_expr [41463,41476]
===
match
---
operator: , [41305,41306]
operator: , [41305,41306]
===
match
---
string: 'test-dag' [3731,3741]
string: 'test-dag' [3731,3741]
===
match
---
atom_expr [5012,5061]
atom_expr [5012,5061]
===
match
---
argument [68656,68682]
argument [70604,70630]
===
match
---
trailer [65411,65413]
trailer [67359,67361]
===
match
---
atom_expr [31202,31330]
atom_expr [31202,31330]
===
match
---
name: session [28211,28218]
name: session [28211,28218]
===
match
---
decorated [68890,69195]
decorated [70838,71143]
===
match
---
comparison [18755,18794]
comparison [18755,18794]
===
match
---
name: run_type [42536,42544]
name: run_type [42536,42544]
===
match
---
operator: , [26311,26312]
operator: , [26311,26312]
===
match
---
number: 3 [64135,64136]
number: 3 [66083,66084]
===
match
---
operator: , [15575,15576]
operator: , [15575,15576]
===
match
---
operator: = [50795,50796]
operator: = [50795,50796]
===
match
---
atom_expr [4622,4711]
atom_expr [4622,4711]
===
match
---
operator: = [35969,35970]
operator: = [35969,35970]
===
match
---
arglist [31844,31879]
arglist [31844,31879]
===
match
---
string: 'test-dag' [4292,4302]
string: 'test-dag' [4292,4302]
===
match
---
operator: == [58540,58542]
operator: == [60488,60490]
===
match
---
name: dag [60851,60854]
name: dag [62799,62802]
===
match
---
name: start_date [54964,54974]
name: start_date [56912,56922]
===
match
---
name: test_dag_naive_default_args_start_date [11895,11933]
name: test_dag_naive_default_args_start_date [11895,11933]
===
match
---
name: include_subdags [51370,51385]
name: include_subdags [51370,51385]
===
match
---
name: next_dagrun_create_after [42895,42919]
name: next_dagrun_create_after [42895,42919]
===
match
---
arglist [68397,68588]
arglist [70345,70536]
===
match
---
name: DEFAULT_DATE [51239,51251]
name: DEFAULT_DATE [51239,51251]
===
match
---
operator: , [30013,30014]
operator: , [30013,30014]
===
match
---
parameters [12491,12497]
parameters [12491,12497]
===
match
---
name: self [40812,40816]
name: self [40812,40816]
===
match
---
simple_stmt [3393,3405]
simple_stmt [3393,3405]
===
match
---
name: filter [29496,29502]
name: filter [29496,29502]
===
match
---
name: tearDown [65042,65050]
name: tearDown [66990,66998]
===
match
---
fstring_end: " [47697,47698]
fstring_end: " [47697,47698]
===
match
---
operator: , [46401,46402]
operator: , [46401,46402]
===
match
---
atom [17925,17939]
atom [17925,17939]
===
match
---
atom_expr [51649,51661]
atom_expr [51649,51661]
===
match
---
name: dag [44299,44302]
name: dag [44299,44302]
===
match
---
atom_expr [27889,27919]
atom_expr [27889,27919]
===
match
---
trailer [19037,19045]
trailer [19037,19045]
===
match
---
name: dag [48783,48786]
name: dag [48783,48786]
===
match
---
arglist [6762,6807]
arglist [6762,6807]
===
match
---
name: execute [34623,34630]
name: execute [34623,34630]
===
match
---
name: task_id [35801,35808]
name: task_id [35801,35808]
===
match
---
trailer [65815,65817]
trailer [67763,67765]
===
match
---
name: return_num [68082,68092]
name: return_num [70030,70040]
===
match
---
name: next_dagrun_after_date [57621,57643]
name: next_dagrun_after_date [59569,59591]
===
match
---
name: tests [2299,2304]
name: tests [2299,2304]
===
match
---
operator: = [49464,49465]
operator: = [49464,49465]
===
match
---
atom_expr [43170,43191]
atom_expr [43170,43191]
===
match
---
trailer [19100,19105]
trailer [19100,19105]
===
match
---
operator: = [48884,48885]
operator: = [48884,48885]
===
match
---
name: set [35582,35585]
name: set [35582,35585]
===
match
---
name: bulk_write_to_db [25659,25675]
name: bulk_write_to_db [25659,25675]
===
match
---
operator: , [26163,26164]
operator: , [26163,26164]
===
match
---
operator: , [37639,37640]
operator: , [37639,37640]
===
match
---
parameters [4519,4525]
parameters [4519,4525]
===
match
---
name: dag [12907,12910]
name: dag [12907,12910]
===
match
---
name: test_dags_needing_dagruns_only_unpaused [63021,63060]
name: test_dags_needing_dagruns_only_unpaused [64969,65008]
===
match
---
name: datetime [49304,49312]
name: datetime [49304,49312]
===
match
---
parameters [39862,39880]
parameters [39862,39880]
===
match
---
operator: = [44454,44455]
operator: = [44454,44455]
===
match
---
name: next_date [59804,59813]
name: next_date [61752,61761]
===
match
---
name: match [36907,36912]
name: match [36907,36912]
===
match
---
name: task_id [6593,6600]
name: task_id [6593,6600]
===
match
---
operator: = [51077,51078]
operator: = [51077,51078]
===
match
---
parameters [65726,65731]
parameters [67674,67679]
===
match
---
operator: = [56522,56523]
operator: = [58470,58471]
===
match
---
trailer [22591,22600]
trailer [22591,22600]
===
match
---
operator: , [64746,64747]
operator: , [66694,66695]
===
match
---
name: parameterized [51685,51698]
name: parameterized [53633,53646]
===
match
---
simple_stmt [63582,63603]
simple_stmt [65530,65551]
===
match
---
atom_expr [49220,49483]
atom_expr [49220,49483]
===
match
---
trailer [4628,4635]
trailer [4628,4635]
===
match
---
argument [6124,6137]
argument [6124,6137]
===
match
---
atom_expr [29332,29352]
atom_expr [29332,29352]
===
match
---
name: SCHEDULED [41393,41402]
name: SCHEDULED [41393,41402]
===
match
---
operator: = [50758,50759]
operator: = [50758,50759]
===
match
---
atom_expr [33713,33762]
atom_expr [33713,33762]
===
match
---
name: task_id [38447,38454]
name: task_id [38447,38454]
===
match
---
name: model [27889,27894]
name: model [27889,27894]
===
match
---
name: local_tz [20361,20369]
name: local_tz [20361,20369]
===
match
---
name: op1 [8915,8918]
name: op1 [8915,8918]
===
match
---
param [65931,65935]
param [67879,67883]
===
match
---
if_stmt [14558,14598]
if_stmt [14558,14598]
===
match
---
decorated [65184,65383]
decorated [67132,67331]
===
match
---
operator: , [55778,55779]
operator: , [57726,57727]
===
match
---
fstring_string: . [60263,60264]
fstring_string: . [62211,62212]
===
match
---
operator: } [26699,26700]
operator: } [26699,26700]
===
match
---
name: op2 [37949,37952]
name: op2 [37949,37952]
===
match
---
operator: = [36216,36217]
operator: = [36216,36217]
===
match
---
name: TestCase [64658,64666]
name: TestCase [66606,66614]
===
match
---
name: subdag_id [31520,31529]
name: subdag_id [31520,31529]
===
match
---
name: task_id [30802,30809]
name: task_id [30802,30809]
===
match
---
arglist [40637,40659]
arglist [40637,40659]
===
match
---
trailer [27046,27074]
trailer [27046,27074]
===
match
---
simple_stmt [15349,15359]
simple_stmt [15349,15359]
===
match
---
trailer [51214,51467]
trailer [51214,51467]
===
match
---
comparison [22074,22122]
comparison [22074,22122]
===
match
---
string: 'op7' [7039,7044]
string: 'op7' [7039,7044]
===
match
---
assert_stmt [21998,22058]
assert_stmt [21998,22058]
===
match
---
name: name [27069,27073]
name: name [27069,27073]
===
match
---
arglist [5021,5052]
arglist [5021,5052]
===
match
---
string: 'dag' [9462,9467]
string: 'dag' [9462,9467]
===
match
---
name: start_date [35255,35265]
name: start_date [35255,35265]
===
match
---
simple_stmt [9684,9717]
simple_stmt [9684,9717]
===
match
---
sync_comp_for [13017,13041]
sync_comp_for [13017,13041]
===
match
---
name: num [68122,68125]
name: num [70070,70073]
===
match
---
testlist_comp [44703,44762]
testlist_comp [44703,44762]
===
match
---
name: dag_run [39426,39433]
name: dag_run [39426,39433]
===
match
---
operator: = [59493,59494]
operator: = [61441,61442]
===
match
---
operator: , [5367,5368]
operator: , [5367,5368]
===
match
---
name: _occur_before [8121,8134]
name: _occur_before [8121,8134]
===
match
---
name: merge [51148,51153]
name: merge [51148,51153]
===
match
---
argument [10623,10646]
argument [10623,10646]
===
match
---
suite [16023,16085]
suite [16023,16085]
===
match
---
operator: = [43897,43898]
operator: = [43897,43898]
===
match
---
argument [41079,41086]
argument [41079,41086]
===
match
---
name: mock_stats [40721,40731]
name: mock_stats [40721,40731]
===
match
---
name: datetime [62404,62412]
name: datetime [64352,64360]
===
match
---
name: task_instances [52995,53009]
name: task_instances [54943,54957]
===
match
---
argument [7682,7705]
argument [7682,7705]
===
match
---
number: 0 [49734,49735]
number: 0 [49734,49735]
===
match
---
assert_stmt [9281,9316]
assert_stmt [9281,9316]
===
match
---
trailer [41078,41087]
trailer [41078,41087]
===
match
---
param [62334,62338]
param [64282,64286]
===
match
---
operator: { [11627,11628]
operator: { [11627,11628]
===
match
---
argument [37641,37648]
argument [37641,37648]
===
match
---
operator: , [56903,56904]
operator: , [58851,58852]
===
match
---
string: 'dag-bulk-sync-1' [26879,26896]
string: 'dag-bulk-sync-1' [26879,26896]
===
match
---
trailer [13999,14007]
trailer [13999,14007]
===
match
---
trailer [3811,3823]
trailer [3811,3823]
===
match
---
suite [53200,53545]
suite [55148,55493]
===
match
---
name: dag [27649,27652]
name: dag [27649,27652]
===
match
---
name: dag [42301,42304]
name: dag [42301,42304]
===
match
---
operator: , [21628,21629]
operator: , [21628,21629]
===
match
---
name: self [38901,38905]
name: self [38901,38905]
===
match
---
name: dag_id [31950,31956]
name: dag_id [31950,31956]
===
match
---
arglist [7351,7451]
arglist [7351,7451]
===
match
---
name: start_date [43277,43287]
name: start_date [43277,43287]
===
match
---
simple_stmt [27943,28128]
simple_stmt [27943,28128]
===
match
---
argument [17064,17120]
argument [17064,17120]
===
match
---
name: dst_rule [22618,22626]
name: dst_rule [22618,22626]
===
match
---
name: typing [994,1000]
name: typing [994,1000]
===
match
---
testlist_comp [28240,28251]
testlist_comp [28240,28251]
===
match
---
name: owners [29573,29579]
name: owners [29573,29579]
===
match
---
atom [35530,35540]
atom [35530,35540]
===
match
---
name: start_date [57258,57268]
name: start_date [59206,59216]
===
match
---
name: self [48618,48622]
name: self [48618,48622]
===
match
---
name: dag [65796,65799]
name: dag [67744,67747]
===
match
---
operator: , [59242,59243]
operator: , [61190,61191]
===
match
---
argument [36907,36961]
argument [36907,36961]
===
match
---
trailer [43797,43807]
trailer [43797,43807]
===
match
---
operator: { [4212,4213]
operator: { [4212,4213]
===
match
---
trailer [5333,5391]
trailer [5333,5391]
===
match
---
trailer [26466,26473]
trailer [26466,26473]
===
match
---
atom_expr [33123,33138]
atom_expr [33123,33138]
===
match
---
atom_expr [28661,28751]
atom_expr [28661,28751]
===
match
---
operator: = [27984,27985]
operator: = [27984,27985]
===
match
---
shift_expr [38041,38051]
shift_expr [38041,38051]
===
match
---
name: stdout [36515,36521]
name: stdout [36515,36521]
===
match
---
comparison [15890,15896]
comparison [15890,15896]
===
match
---
atom_expr [58692,58729]
atom_expr [60640,60677]
===
match
---
name: dag [41899,41902]
name: dag [41899,41902]
===
match
---
parameters [3547,3553]
parameters [3547,3553]
===
match
---
atom_expr [64462,64623]
atom_expr [66410,66571]
===
match
---
operator: , [22612,22613]
operator: , [22612,22613]
===
match
---
expr_stmt [7144,7158]
expr_stmt [7144,7158]
===
match
---
operator: , [62420,62421]
operator: , [64368,64369]
===
match
---
operator: @ [68050,68051]
operator: @ [69998,69999]
===
match
---
simple_stmt [42710,42727]
simple_stmt [42710,42727]
===
match
---
atom_expr [28905,28921]
atom_expr [28905,28921]
===
match
---
simple_stmt [3274,3287]
simple_stmt [3274,3287]
===
match
---
name: State [41463,41468]
name: State [41463,41468]
===
match
---
simple_stmt [1430,1517]
simple_stmt [1430,1517]
===
match
---
trailer [65224,65237]
trailer [67172,67185]
===
match
---
operator: , [20007,20008]
operator: , [20007,20008]
===
match
---
trailer [49091,49146]
trailer [49091,49146]
===
match
---
parameters [65018,65024]
parameters [66966,66972]
===
match
---
name: self [23489,23493]
name: self [23489,23493]
===
match
---
name: session [62816,62823]
name: session [64764,64771]
===
match
---
name: name [19692,19696]
name: name [19692,19696]
===
match
---
argument [35939,35951]
argument [35939,35951]
===
match
---
name: hours [23679,23684]
name: hours [23679,23684]
===
match
---
name: delete [2998,3004]
name: delete [2998,3004]
===
match
---
name: session [33544,33551]
name: session [33544,33551]
===
match
---
name: last_parsed_time [25253,25269]
name: last_parsed_time [25253,25269]
===
match
---
operator: } [46167,46168]
operator: } [46167,46168]
===
match
---
name: dag [59336,59339]
name: dag [61284,61287]
===
match
---
name: op7 [7011,7014]
name: op7 [7011,7014]
===
match
---
name: pytest [37388,37394]
name: pytest [37388,37394]
===
match
---
name: test_new_dag_is_paused_upon_creation [32881,32917]
name: test_new_dag_is_paused_upon_creation [32881,32917]
===
match
---
operator: , [45949,45950]
operator: , [45949,45950]
===
match
---
operator: , [64387,64388]
operator: , [66335,66336]
===
match
---
name: self [33359,33363]
name: self [33359,33363]
===
match
---
name: pipeline [15860,15868]
name: pipeline [15860,15868]
===
match
---
number: 4 [25474,25475]
number: 4 [25474,25475]
===
match
---
trailer [34407,34449]
trailer [34407,34449]
===
match
---
name: DAG [22713,22716]
name: DAG [22713,22716]
===
match
---
name: catchup [55765,55772]
name: catchup [57713,57720]
===
match
---
string: 'test-invalid-default_view' [4743,4770]
string: 'test-invalid-default_view' [4743,4770]
===
match
---
simple_stmt [21998,22059]
simple_stmt [21998,22059]
===
match
---
trailer [33394,33396]
trailer [33394,33396]
===
match
---
name: params2 [4427,4434]
name: params2 [4427,4434]
===
match
---
name: DummyOperator [63220,63233]
name: DummyOperator [65168,65181]
===
match
---
atom_expr [42518,42613]
atom_expr [42518,42613]
===
match
---
comparison [51573,51603]
comparison [51573,51603]
===
match
---
expr_stmt [63157,63211]
expr_stmt [65105,65159]
===
match
---
argument [18231,18246]
argument [18231,18246]
===
match
---
trailer [9244,9251]
trailer [9244,9251]
===
match
---
atom_expr [26348,26395]
atom_expr [26348,26395]
===
match
---
number: 1 [57707,57708]
number: 1 [59655,59656]
===
match
---
name: int [14886,14889]
name: int [14886,14889]
===
match
---
comparison [10160,10187]
comparison [10160,10187]
===
match
---
operator: = [44423,44424]
operator: = [44423,44424]
===
match
---
name: orm_dag [29751,29758]
name: orm_dag [29751,29758]
===
match
---
simple_stmt [3199,3266]
simple_stmt [3199,3266]
===
match
---
atom_expr [68025,68035]
atom_expr [69973,69983]
===
match
---
simple_stmt [22558,22652]
simple_stmt [22558,22652]
===
match
---
simple_stmt [65862,65897]
simple_stmt [67810,67845]
===
match
---
name: dag_run_state [51665,51678]
name: dag_run_state [51665,51678]
===
match
---
name: session [17650,17657]
name: session [17650,17657]
===
match
---
expr_stmt [9819,9851]
expr_stmt [9819,9851]
===
match
---
name: dst_rule [21521,21529]
name: dst_rule [21521,21529]
===
match
---
argument [27979,27998]
argument [27979,27998]
===
match
---
simple_stmt [35090,35132]
simple_stmt [35090,35132]
===
match
---
atom_expr [69210,69227]
atom_expr [71158,71175]
===
match
---
name: subdag [1788,1794]
name: subdag [1788,1794]
===
match
---
atom_expr [69142,69159]
atom_expr [71090,71107]
===
match
---
name: TI [17170,17172]
name: TI [17170,17172]
===
match
---
operator: = [50323,50324]
operator: = [50323,50324]
===
match
---
name: self [63061,63065]
name: self [65009,65013]
===
match
---
name: task_id [37572,37579]
name: task_id [37572,37579]
===
match
---
assert_stmt [58523,58572]
assert_stmt [60471,60520]
===
match
---
expr_stmt [63286,63314]
expr_stmt [65234,65262]
===
match
---
name: query [52833,52838]
name: query [54781,54786]
===
match
---
atom_expr [28240,28250]
atom_expr [28240,28250]
===
match
---
atom [24195,24213]
atom [24195,24213]
===
match
---
trailer [47844,47858]
trailer [47844,47858]
===
match
---
name: op3 [38549,38552]
name: op3 [38549,38552]
===
match
---
expr_stmt [7874,7933]
expr_stmt [7874,7933]
===
match
---
atom_expr [50170,50209]
atom_expr [50170,50209]
===
match
---
name: dag [45742,45745]
name: dag [45742,45745]
===
match
---
dictorsetmaker [64698,64855]
dictorsetmaker [66646,66803]
===
match
---
string: """Test that dag param is correctly set when using dag decorator""" [68813,68880]
string: """Test that dag param is correctly set when using dag decorator""" [70761,70828]
===
match
---
atom_expr [13126,13145]
atom_expr [13126,13145]
===
match
---
simple_stmt [9325,9359]
simple_stmt [9325,9359]
===
match
---
argument [64362,64387]
argument [66310,66335]
===
match
---
string: 'D' [8898,8901]
string: 'D' [8898,8901]
===
match
---
trailer [9461,9527]
trailer [9461,9527]
===
match
---
name: utc [21243,21246]
name: utc [21243,21246]
===
match
---
number: 2 [55575,55576]
number: 2 [57523,57524]
===
match
---
comparison [6279,6294]
comparison [6279,6294]
===
match
---
argument [40445,40462]
argument [40445,40462]
===
match
---
string: """             Regular DAG documentation             """ [66108,66165]
string: """             Regular DAG documentation             """ [68056,68113]
===
match
---
trailer [28032,28044]
trailer [28032,28044]
===
match
---
expr_stmt [35038,35081]
expr_stmt [35038,35081]
===
match
---
expr_stmt [5995,6072]
expr_stmt [5995,6072]
===
match
---
trailer [68467,68469]
trailer [70415,70417]
===
match
---
string: 'dag-bulk-sync-3' [25801,25818]
string: 'dag-bulk-sync-3' [25801,25818]
===
match
---
number: 1 [61232,61233]
number: 1 [63180,63181]
===
match
---
expr_stmt [22661,22697]
expr_stmt [22661,22697]
===
match
---
name: schedule_interval [46850,46867]
name: schedule_interval [46850,46867]
===
match
---
atom_expr [16958,17005]
atom_expr [16958,17005]
===
match
---
name: test_task [16966,16975]
name: test_task [16966,16975]
===
match
---
argument [47322,47335]
argument [47322,47335]
===
match
---
name: DummyOperator [7952,7965]
name: DummyOperator [7952,7965]
===
match
---
name: noop_pipeline [66914,66927]
name: noop_pipeline [68862,68875]
===
match
---
name: op3 [38222,38225]
name: op3 [38222,38225]
===
match
---
expr_stmt [27612,27640]
expr_stmt [27612,27640]
===
match
---
trailer [20801,20803]
trailer [20801,20803]
===
match
---
name: xcom_arg [67284,67292]
name: xcom_arg [69232,69240]
===
match
---
name: start_date [60601,60611]
name: start_date [62549,62559]
===
match
---
arglist [16907,16941]
arglist [16907,16941]
===
match
---
arglist [57183,57375]
arglist [59131,59323]
===
match
---
name: dag [47188,47191]
name: dag [47188,47191]
===
match
---
operator: == [38131,38133]
operator: == [38131,38133]
===
match
---
simple_stmt [45890,45925]
simple_stmt [45890,45925]
===
match
---
string: 'test-dag' [26264,26274]
string: 'test-dag' [26264,26274]
===
match
---
suite [13849,15162]
suite [13849,15162]
===
match
---
operator: = [20695,20696]
operator: = [20695,20696]
===
match
---
string: "2018-10-28T02:55:00+02:00" [21192,21219]
string: "2018-10-28T02:55:00+02:00" [21192,21219]
===
match
---
funcdef [56913,57713]
funcdef [58861,59661]
===
match
---
simple_stmt [20779,20835]
simple_stmt [20779,20835]
===
match
---
name: test_next_dagrun_after_not_for_subdags [59864,59902]
name: test_next_dagrun_after_not_for_subdags [61812,61850]
===
match
---
string: 'depends_on_past' [54797,54814]
string: 'depends_on_past' [56745,56762]
===
match
---
trailer [60437,60495]
trailer [62385,62443]
===
match
---
name: dag [44019,44022]
name: dag [44019,44022]
===
match
---
comparison [19454,19483]
comparison [19454,19483]
===
match
---
trailer [8349,8363]
trailer [8349,8363]
===
match
---
name: DEFAULT_DATE [41218,41230]
name: DEFAULT_DATE [41218,41230]
===
match
---
name: DAG [44425,44428]
name: DAG [44425,44428]
===
match
---
string: "t1" [37580,37584]
string: "t1" [37580,37584]
===
match
---
operator: @ [65596,65597]
operator: @ [67544,67545]
===
match
---
suite [9626,10028]
suite [9626,10028]
===
match
---
name: State [68535,68540]
name: State [70483,70488]
===
match
---
name: session [29472,29479]
name: session [29472,29479]
===
match
---
atom_expr [25244,25269]
atom_expr [25244,25269]
===
match
---
argument [50615,50642]
argument [50615,50642]
===
match
---
arglist [52657,52774]
arglist [54605,54722]
===
match
---
simple_stmt [63767,63783]
simple_stmt [65715,65731]
===
match
---
name: schedule_interval [59256,59273]
name: schedule_interval [61204,61221]
===
match
---
name: next_dagrun [41822,41833]
name: next_dagrun [41822,41833]
===
match
---
trailer [2508,2510]
trailer [2508,2510]
===
match
---
trailer [57433,57439]
trailer [59381,59387]
===
match
---
operator: , [20054,20055]
operator: , [20054,20055]
===
match
---
name: dag [22707,22710]
name: dag [22707,22710]
===
match
---
funcdef [20167,21247]
funcdef [20167,21247]
===
match
---
name: dag_diff_load_time [44404,44422]
name: dag_diff_load_time [44404,44422]
===
match
---
arglist [29365,29396]
arglist [29365,29396]
===
match
---
operator: , [48485,48486]
operator: , [48485,48486]
===
match
---
simple_stmt [7822,7862]
simple_stmt [7822,7862]
===
match
---
name: task_instance_1 [49169,49184]
name: task_instance_1 [49169,49184]
===
match
---
name: op1 [55079,55082]
name: op1 [57027,57030]
===
match
---
name: state [47389,47394]
name: state [47389,47394]
===
match
---
trailer [44078,44085]
trailer [44078,44085]
===
match
---
name: op5 [35965,35968]
name: op5 [35965,35968]
===
match
---
trailer [31843,31880]
trailer [31843,31880]
===
match
---
name: timezone [68452,68460]
name: timezone [70400,70408]
===
match
---
name: query [25238,25243]
name: query [25238,25243]
===
match
---
operator: = [9733,9734]
operator: = [9733,9734]
===
match
---
decorated [57718,58788]
decorated [59666,60736]
===
match
---
name: task_id [35985,35992]
name: task_id [35985,35992]
===
match
---
operator: , [19783,19784]
operator: , [19783,19784]
===
match
---
parameters [66657,66664]
parameters [68605,68612]
===
match
---
operator: = [30631,30632]
operator: = [30631,30632]
===
match
---
dictorsetmaker [11980,12023]
dictorsetmaker [11980,12023]
===
match
---
suite [14640,14756]
suite [14640,14756]
===
match
---
trailer [3730,3742]
trailer [3730,3742]
===
match
---
name: dag [45837,45840]
name: dag [45837,45840]
===
match
---
arglist [51228,51457]
arglist [51228,51457]
===
match
---
assert_stmt [44971,44991]
assert_stmt [44971,44991]
===
match
---
atom [61733,61906]
atom [63681,63854]
===
match
---
expr_stmt [47959,48033]
expr_stmt [47959,48033]
===
match
---
expr_stmt [4238,4265]
expr_stmt [4238,4265]
===
match
---
operator: < [55992,55993]
operator: < [57940,57941]
===
match
---
name: expected_n_schedule_interval [46757,46785]
name: expected_n_schedule_interval [46757,46785]
===
match
---
trailer [50486,50653]
trailer [50486,50653]
===
match
---
name: start_date [37898,37908]
name: start_date [37898,37908]
===
match
---
fstring_expr [39617,39641]
fstring_expr [39617,39641]
===
match
---
name: task_id [37711,37718]
name: task_id [37711,37718]
===
match
---
name: timedelta [60704,60713]
name: timedelta [62652,62661]
===
match
---
atom_expr [48049,48060]
atom_expr [48049,48060]
===
match
---
name: State [51806,51811]
name: State [53754,53759]
===
match
---
operator: , [31661,31662]
operator: , [31661,31662]
===
match
---
assert_stmt [39340,39366]
assert_stmt [39340,39366]
===
match
---
name: start_date [7682,7692]
name: start_date [7682,7692]
===
match
---
trailer [57748,57760]
trailer [59696,59708]
===
match
---
name: next_dagrun_after_date [58364,58386]
name: next_dagrun_after_date [60312,60334]
===
match
---
argument [9794,9805]
argument [9794,9805]
===
match
---
simple_stmt [39047,39072]
simple_stmt [39047,39072]
===
match
---
operator: , [25072,25073]
operator: , [25072,25073]
===
match
---
number: 0 [24606,24607]
number: 0 [24606,24607]
===
match
---
simple_stmt [38110,38171]
simple_stmt [38110,38171]
===
match
---
name: dag [31726,31729]
name: dag [31726,31729]
===
match
---
operator: = [6794,6795]
operator: = [6794,6795]
===
match
---
atom_expr [24704,24720]
atom_expr [24704,24720]
===
match
---
trailer [20472,20482]
trailer [20472,20482]
===
match
---
operator: = [48578,48579]
operator: = [48578,48579]
===
match
---
name: b [3433,3434]
name: b [3433,3434]
===
match
---
name: task [16961,16965]
name: task [16961,16965]
===
match
---
simple_stmt [28594,28640]
simple_stmt [28594,28640]
===
match
---
string: 'test' [66376,66382]
string: 'test' [68324,68330]
===
match
---
atom_expr [64316,64334]
atom_expr [66264,66282]
===
match
---
comparison [24752,24918]
comparison [24752,24918]
===
match
---
name: stdout [36570,36576]
name: stdout [36570,36576]
===
match
---
trailer [8120,8134]
trailer [8120,8134]
===
match
---
name: self [58831,58835]
name: self [60779,60783]
===
match
---
argument [58203,58215]
argument [60151,60163]
===
match
---
simple_stmt [39741,39753]
simple_stmt [39741,39753]
===
match
---
operator: , [52353,52354]
operator: , [54301,54302]
===
match
---
atom_expr [39229,39249]
atom_expr [39229,39249]
===
match
---
name: DEFAULT_DATE [19796,19808]
name: DEFAULT_DATE [19796,19808]
===
match
---
name: assert_queries_count [64425,64445]
name: assert_queries_count [66373,66393]
===
match
---
operator: = [18559,18560]
operator: = [18559,18560]
===
match
---
name: op3 [10534,10537]
name: op3 [10534,10537]
===
match
---
trailer [46197,46199]
trailer [46197,46199]
===
match
---
name: t_2 [50364,50367]
name: t_2 [50364,50367]
===
match
---
operator: = [52463,52464]
operator: = [54411,54412]
===
match
---
fstring_start: f' [14231,14233]
fstring_start: f' [14231,14233]
===
match
---
name: test_task_id [16780,16792]
name: test_task_id [16780,16792]
===
match
---
operator: , [20646,20647]
operator: , [20646,20647]
===
match
---
import_from [1155,1188]
import_from [1155,1188]
===
match
---
operator: == [11847,11849]
operator: == [11847,11849]
===
match
---
argument [19141,19164]
argument [19141,19164]
===
match
---
name: dag [54236,54239]
name: dag [56184,56187]
===
match
---
suite [65937,66446]
suite [67885,68394]
===
match
---
trailer [24379,24386]
trailer [24379,24386]
===
match
---
import_name [853,862]
import_name [853,862]
===
match
---
comparison [20850,20903]
comparison [20850,20903]
===
match
---
name: start_date [20630,20640]
name: start_date [20630,20640]
===
match
---
atom_expr [52303,52316]
atom_expr [54251,54264]
===
match
---
simple_stmt [3906,4194]
simple_stmt [3906,4194]
===
match
---
assert_stmt [28401,28446]
assert_stmt [28401,28446]
===
match
---
operator: = [21665,21666]
operator: = [21665,21666]
===
match
---
atom [62957,62959]
atom [64905,64907]
===
match
---
trailer [35047,35081]
trailer [35047,35081]
===
match
---
expr_stmt [16216,16239]
expr_stmt [16216,16239]
===
match
---
operator: == [18782,18784]
operator: == [18782,18784]
===
match
---
simple_stmt [58465,58515]
simple_stmt [60413,60463]
===
match
---
suite [4526,4796]
suite [4526,4796]
===
match
---
simple_stmt [49986,50032]
simple_stmt [49986,50032]
===
match
---
name: task_id [3363,3370]
name: task_id [3363,3370]
===
match
---
operator: - [55487,55488]
operator: - [57435,57436]
===
match
---
expr_stmt [45890,45924]
expr_stmt [45890,45924]
===
match
---
name: local_tz [22840,22848]
name: local_tz [22840,22848]
===
match
---
operator: } [38238,38239]
operator: } [38238,38239]
===
match
---
name: dag [6659,6662]
name: dag [6659,6662]
===
match
---
arglist [49092,49145]
arglist [49092,49145]
===
match
---
atom_expr [14332,14351]
atom_expr [14332,14351]
===
match
---
name: task_id [35847,35854]
name: task_id [35847,35854]
===
match
---
operator: } [4264,4265]
operator: } [4264,4265]
===
match
---
argument [2913,2938]
argument [2913,2938]
===
match
---
suite [33365,33763]
suite [33365,33763]
===
match
---
name: subdag [60932,60938]
name: subdag [62880,62886]
===
match
---
name: weight [13932,13938]
name: weight [13932,13938]
===
match
---
name: State [64553,64558]
name: State [66501,66506]
===
match
---
name: DEFAULT_DATE [6025,6037]
name: DEFAULT_DATE [6025,6037]
===
match
---
trailer [67976,67989]
trailer [69924,69937]
===
match
---
atom_expr [9252,9271]
atom_expr [9252,9271]
===
match
---
trailer [40826,40834]
trailer [40826,40834]
===
match
---
argument [31355,31370]
argument [31355,31370]
===
match
---
name: test_duplicate_task_ids_not_allowed_without_dag_context_manager [37241,37304]
name: test_duplicate_task_ids_not_allowed_without_dag_context_manager [37241,37304]
===
match
---
string: """         Test that the dag file processor does not create multiple dagruns         if a dag is scheduled with 'timedelta' and catchup=False         """ [56997,57151]
string: """         Test that the dag file processor does not create multiple dagruns         if a dag is scheduled with 'timedelta' and catchup=False         """ [58945,59099]
===
match
---
trailer [26361,26389]
trailer [26361,26389]
===
match
---
arglist [44566,44596]
arglist [44566,44596]
===
match
---
name: is_paused [31752,31761]
name: is_paused [31752,31761]
===
match
---
string: "test_create_dagrun_job_id_is_set" [48263,48297]
string: "test_create_dagrun_job_id_is_set" [48263,48297]
===
match
---
operator: == [45308,45310]
operator: == [45308,45310]
===
match
---
trailer [17713,17759]
trailer [17713,17759]
===
match
---
atom_expr [58426,58455]
atom_expr [60374,60403]
===
match
---
simple_stmt [1360,1430]
simple_stmt [1360,1430]
===
match
---
name: self [22409,22413]
name: self [22409,22413]
===
match
---
name: create_dagrun [27952,27965]
name: create_dagrun [27952,27965]
===
match
---
operator: , [50345,50346]
operator: , [50345,50346]
===
match
---
atom_expr [10004,10027]
atom_expr [10004,10027]
===
match
---
expr_stmt [37607,37649]
expr_stmt [37607,37649]
===
match
---
name: SCHEDULED [47940,47949]
name: SCHEDULED [47940,47949]
===
match
---
atom_expr [22713,22775]
atom_expr [22713,22775]
===
match
---
operator: = [52667,52668]
operator: = [54615,54616]
===
match
---
operator: , [49960,49961]
operator: , [49960,49961]
===
match
---
name: op2 [38526,38529]
name: op2 [38526,38529]
===
match
---
atom_expr [9288,9307]
atom_expr [9288,9307]
===
match
---
atom_expr [51101,51131]
atom_expr [51101,51131]
===
match
---
name: TI [2966,2968]
name: TI [2966,2968]
===
match
---
with_stmt [33375,33624]
with_stmt [33375,33624]
===
match
---
with_stmt [37383,37673]
with_stmt [37383,37673]
===
match
---
argument [60438,60478]
argument [62386,62426]
===
match
---
trailer [51037,51092]
trailer [51037,51092]
===
match
---
comparison [6624,6639]
comparison [6624,6639]
===
match
---
comparison [56359,56384]
comparison [58307,58332]
===
match
---
name: run_id [67472,67478]
name: run_id [69420,69426]
===
match
---
number: 1 [60639,60640]
number: 1 [62587,62588]
===
match
---
name: dag [21610,21613]
name: dag [21610,21613]
===
match
---
operator: == [59441,59443]
operator: == [61389,61391]
===
match
---
number: 1 [52742,52743]
number: 1 [54690,54691]
===
match
---
expr_stmt [44777,44811]
expr_stmt [44777,44811]
===
match
---
trailer [9218,9221]
trailer [9218,9221]
===
match
---
name: test_field [20120,20130]
name: test_field [20120,20130]
===
match
---
name: next_date [58236,58245]
name: next_date [60184,60193]
===
match
---
simple_stmt [43620,43702]
simple_stmt [43620,43702]
===
match
---
name: DAG [65445,65448]
name: DAG [67393,67396]
===
match
---
operator: , [34131,34132]
operator: , [34131,34132]
===
match
---
name: op2 [38427,38430]
name: op2 [38427,38430]
===
match
---
testlist_comp [48472,48486]
testlist_comp [48472,48486]
===
match
---
trailer [51729,51734]
trailer [53677,53682]
===
match
---
argument [9839,9850]
argument [9839,9850]
===
match
---
operator: , [63534,63535]
operator: , [65482,65483]
===
match
---
expr_stmt [39980,40014]
expr_stmt [39980,40014]
===
match
---
name: re [13997,13999]
name: re [13997,13999]
===
match
---
name: state [47615,47620]
name: state [47615,47620]
===
match
---
expr_stmt [23854,23895]
expr_stmt [23854,23895]
===
match
---
operator: == [27026,27028]
operator: == [27026,27028]
===
match
---
name: State [42599,42604]
name: State [42599,42604]
===
match
---
trailer [6877,6884]
trailer [6877,6884]
===
match
---
name: dag [6812,6815]
name: dag [6812,6815]
===
match
---
name: tearDown [65010,65018]
name: tearDown [66958,66966]
===
match
---
operator: = [64552,64553]
operator: = [66500,66501]
===
match
---
argument [40304,40352]
argument [40304,40352]
===
match
---
trailer [22197,22205]
trailer [22197,22205]
===
match
---
operator: , [51537,51538]
operator: , [51537,51538]
===
match
---
name: state [17383,17388]
name: state [17383,17388]
===
match
---
operator: = [59644,59645]
operator: = [61592,61593]
===
match
---
suite [3897,4481]
suite [3897,4481]
===
match
---
simple_stmt [45803,45842]
simple_stmt [45803,45842]
===
match
---
operator: = [35373,35374]
operator: = [35373,35374]
===
match
---
comparison [44047,44085]
comparison [44047,44085]
===
match
---
assert_stmt [7198,7219]
assert_stmt [7198,7219]
===
match
---
atom [61756,61814]
atom [63704,63762]
===
match
---
argument [30703,30726]
argument [30703,30726]
===
match
---
operator: = [59339,59340]
operator: = [61287,61288]
===
match
---
name: timedelta [53754,53763]
name: timedelta [55702,55711]
===
match
---
name: op1 [9397,9400]
name: op1 [9397,9400]
===
match
---
operator: , [25036,25037]
operator: , [25036,25037]
===
match
---
simple_stmt [9639,9672]
simple_stmt [9639,9672]
===
match
---
operator: = [21914,21915]
operator: = [21914,21915]
===
match
---
suite [34158,34203]
suite [34158,34203]
===
match
---
operator: , [27060,27061]
operator: , [27060,27061]
===
match
---
operator: { [15421,15422]
operator: { [15421,15422]
===
match
---
name: dag_id [48682,48688]
name: dag_id [48682,48688]
===
match
---
operator: = [24557,24558]
operator: = [24557,24558]
===
match
---
name: tags [24572,24576]
name: tags [24572,24576]
===
match
---
simple_stmt [55079,55122]
simple_stmt [57027,57070]
===
match
---
string: 'owner1' [15431,15439]
string: 'owner1' [15431,15439]
===
match
---
simple_stmt [52156,52201]
simple_stmt [54104,54149]
===
match
---
name: is_subdag [31176,31185]
name: is_subdag [31176,31185]
===
match
---
name: next_date [58719,58728]
name: next_date [60667,60676]
===
match
---
operator: = [54234,54235]
operator: = [56182,56183]
===
match
---
name: date [54313,54317]
name: date [56261,56265]
===
match
---
argument [37586,37593]
argument [37586,37593]
===
match
---
name: state [48016,48021]
name: state [48016,48021]
===
match
---
trailer [26461,26466]
trailer [26461,26466]
===
match
---
expr_stmt [57395,57439]
expr_stmt [59343,59387]
===
match
---
name: dag_models [62870,62880]
name: dag_models [64818,64828]
===
match
---
name: dag_run [39474,39481]
name: dag_run [39474,39481]
===
match
---
name: create_dagrun [52224,52237]
name: create_dagrun [54172,54185]
===
match
---
simple_stmt [4202,4230]
simple_stmt [4202,4230]
===
match
---
string: "@once" [53322,53329]
string: "@once" [55270,55277]
===
match
---
suite [27153,27196]
suite [27153,27196]
===
match
---
atom_expr [42545,42565]
atom_expr [42545,42565]
===
match
---
atom_expr [29562,29591]
atom_expr [29562,29591]
===
match
---
trailer [38699,38703]
trailer [38699,38703]
===
match
---
trailer [36452,36454]
trailer [36452,36454]
===
match
---
name: DAG [5551,5554]
name: DAG [5551,5554]
===
match
---
operator: , [32686,32687]
operator: , [32686,32687]
===
match
---
name: task_id [38493,38500]
name: task_id [38493,38500]
===
match
---
simple_stmt [64673,64862]
simple_stmt [66621,66810]
===
match
---
atom [49503,49674]
atom [49503,49674]
===
match
---
arglist [35048,35080]
arglist [35048,35080]
===
match
---
atom [32410,32480]
atom [32410,32480]
===
match
---
name: os [836,838]
name: os [836,838]
===
match
---
expr_stmt [34459,34532]
expr_stmt [34459,34532]
===
match
---
name: dag [15445,15448]
name: dag [15445,15448]
===
match
---
expr_stmt [14821,14856]
expr_stmt [14821,14856]
===
match
---
atom_expr [17219,17245]
atom_expr [17219,17245]
===
match
---
operator: = [30854,30855]
operator: = [30854,30855]
===
match
---
simple_stmt [69061,69072]
simple_stmt [71009,71020]
===
match
---
name: execution_date [39263,39277]
name: execution_date [39263,39277]
===
match
---
assert_stmt [53078,53120]
assert_stmt [55026,55068]
===
match
---
atom_expr [27546,27602]
atom_expr [27546,27602]
===
match
---
argument [50578,50601]
argument [50578,50601]
===
match
---
name: topological_list [9338,9354]
name: topological_list [9338,9354]
===
match
---
atom [4248,4265]
atom [4248,4265]
===
match
---
simple_stmt [53078,53121]
simple_stmt [55026,55069]
===
match
---
name: next_dagrun [27846,27857]
name: next_dagrun [27846,27857]
===
match
---
trailer [49312,49322]
trailer [49312,49322]
===
match
---
atom_expr [52532,52554]
atom_expr [54480,54502]
===
match
---
trailer [34342,34350]
trailer [34342,34350]
===
match
---
name: dag_subclass [45160,45172]
name: dag_subclass [45160,45172]
===
match
---
simple_stmt [38993,39039]
simple_stmt [38993,39039]
===
match
---
name: row [26733,26736]
name: row [26733,26736]
===
match
---
atom_expr [13324,13360]
atom_expr [13324,13360]
===
match
---
arglist [40519,40566]
arglist [40519,40566]
===
match
---
trailer [32167,32183]
trailer [32167,32183]
===
match
---
name: patch [1069,1074]
name: patch [1069,1074]
===
match
---
atom_expr [4404,4435]
atom_expr [4404,4435]
===
match
---
atom_expr [26362,26375]
atom_expr [26362,26375]
===
match
---
operator: = [60243,60244]
operator: = [62191,62192]
===
match
---
operator: , [16927,16928]
operator: , [16927,16928]
===
match
---
atom_expr [21468,21554]
atom_expr [21468,21554]
===
match
---
simple_stmt [58406,58456]
simple_stmt [60354,60404]
===
match
---
name: i [47220,47221]
name: i [47220,47221]
===
match
---
name: dag_id [48571,48577]
name: dag_id [48571,48577]
===
match
---
name: DagModel [27737,27745]
name: DagModel [27737,27745]
===
match
---
argument [53946,53959]
argument [55894,55907]
===
match
---
number: 2020 [57486,57490]
number: 2020 [59434,59438]
===
match
---
trailer [68502,68515]
trailer [70450,70463]
===
match
---
expr_stmt [37943,37982]
expr_stmt [37943,37982]
===
match
---
comparison [45007,45027]
comparison [45007,45027]
===
match
---
string: 'B' [9712,9715]
string: 'B' [9712,9715]
===
match
---
trailer [14731,14744]
trailer [14731,14744]
===
match
---
trailer [34109,34115]
trailer [34109,34115]
===
match
---
atom [20134,20161]
atom [20134,20161]
===
match
---
assert_stmt [25294,25319]
assert_stmt [25294,25319]
===
match
---
atom_expr [55355,55455]
atom_expr [57303,57403]
===
match
---
name: DAG [30149,30152]
name: DAG [30149,30152]
===
match
---
string: '@once' [42278,42285]
string: '@once' [42278,42285]
===
match
---
operator: , [9094,9095]
operator: , [9094,9095]
===
match
---
atom_expr [68404,68427]
atom_expr [70352,70375]
===
match
---
operator: = [17043,17044]
operator: = [17043,17044]
===
match
---
atom_expr [7175,7182]
atom_expr [7175,7182]
===
match
---
expr_stmt [44606,44680]
expr_stmt [44606,44680]
===
match
---
testlist_comp [25948,25977]
testlist_comp [25948,25977]
===
match
---
operator: , [27998,27999]
operator: , [27998,27999]
===
match
---
argument [7558,7575]
argument [7558,7575]
===
match
---
atom_expr [63891,63909]
atom_expr [65839,65857]
===
match
---
simple_stmt [53349,53394]
simple_stmt [55297,55342]
===
match
---
dictorsetmaker [68568,68586]
dictorsetmaker [70516,70534]
===
match
---
simple_stmt [36515,36542]
simple_stmt [36515,36542]
===
match
---
name: f [19589,19590]
name: f [19589,19590]
===
match
---
trailer [44488,44529]
trailer [44488,44529]
===
match
---
name: owner [54084,54089]
name: owner [56032,56037]
===
match
---
name: orm_dag [62537,62544]
name: orm_dag [64485,64492]
===
match
---
name: session [17558,17565]
name: session [17558,17565]
===
match
---
name: DEFAULT_DATE [5939,5951]
name: DEFAULT_DATE [5939,5951]
===
match
---
trailer [57410,57433]
trailer [59358,59381]
===
match
---
name: timedelta [55559,55568]
name: timedelta [57507,57516]
===
match
---
simple_stmt [37189,37232]
simple_stmt [37189,37232]
===
match
---
name: DagModel [42803,42811]
name: DagModel [42803,42811]
===
match
---
trailer [22600,22616]
trailer [22600,22616]
===
match
---
argument [50822,50849]
argument [50822,50849]
===
match
---
name: self [27243,27247]
name: self [27243,27247]
===
match
---
operator: , [12361,12362]
operator: , [12361,12362]
===
match
---
name: assert_called_with [40737,40755]
name: assert_called_with [40737,40755]
===
match
---
name: test_bulk_write_to_db [24452,24473]
name: test_bulk_write_to_db [24452,24473]
===
match
---
operator: , [64213,64214]
operator: , [66161,66162]
===
match
---
operator: = [43960,43961]
operator: = [43960,43961]
===
match
---
operator: = [37141,37142]
operator: = [37141,37142]
===
match
---
trailer [68641,68654]
trailer [70589,70602]
===
match
---
name: self [57834,57838]
name: self [59782,59786]
===
match
---
argument [5953,5985]
argument [5953,5985]
===
match
---
simple_stmt [35484,35518]
simple_stmt [35484,35518]
===
match
---
name: dags [24685,24689]
name: dags [24685,24689]
===
match
---
name: dag [27752,27755]
name: dag [27752,27755]
===
match
---
name: next_date [59744,59753]
name: next_date [61692,61701]
===
match
---
trailer [38323,38360]
trailer [38323,38360]
===
match
---
expr_stmt [23697,23746]
expr_stmt [23697,23746]
===
match
---
name: TI [51035,51037]
name: TI [51035,51037]
===
match
---
simple_stmt [35392,35426]
simple_stmt [35392,35426]
===
match
---
operator: { [31600,31601]
operator: { [31600,31601]
===
match
---
trailer [26556,26562]
trailer [26556,26562]
===
match
---
trailer [55208,55231]
trailer [57156,57179]
===
match
---
atom_expr [30529,30544]
atom_expr [30529,30544]
===
match
---
import_from [1715,1764]
import_from [1715,1764]
===
match
---
expr_stmt [38381,38414]
expr_stmt [38381,38414]
===
match
---
atom [13610,13650]
atom [13610,13650]
===
match
---
operator: = [52702,52703]
operator: = [54650,54651]
===
match
---
name: test_fails_if_arg_not_set [66455,66480]
name: test_fails_if_arg_not_set [68403,68428]
===
match
---
simple_stmt [53209,53340]
simple_stmt [55157,55288]
===
match
---
name: DummyOperator [7107,7120]
name: DummyOperator [7107,7120]
===
match
---
name: DAGsubclass [44191,44202]
name: DAGsubclass [44191,44202]
===
match
---
simple_stmt [56997,57152]
simple_stmt [58945,59100]
===
match
---
fstring_expr [18538,18544]
fstring_expr [18538,18544]
===
match
---
with_stmt [2806,3136]
with_stmt [2806,3136]
===
match
---
name: dag [28487,28490]
name: dag [28487,28490]
===
match
---
name: state [47225,47230]
name: state [47225,47230]
===
match
---
name: dag_id [53883,53889]
name: dag_id [55831,55837]
===
match
---
name: start_date [28713,28723]
name: start_date [28713,28723]
===
match
---
expr_stmt [17288,17370]
expr_stmt [17288,17370]
===
match
---
name: run_id [47982,47988]
name: run_id [47982,47988]
===
match
---
suite [3554,3824]
suite [3554,3824]
===
match
---
suite [10597,10727]
suite [10597,10727]
===
match
---
argument [6186,6194]
argument [6186,6194]
===
match
---
name: DAG [37882,37885]
name: DAG [37882,37885]
===
match
---
trailer [29291,29304]
trailer [29291,29304]
===
match
---
simple_stmt [37682,37725]
simple_stmt [37682,37725]
===
match
---
name: dag [45476,45479]
name: dag [45476,45479]
===
match
---
number: 0 [67757,67758]
number: 0 [69705,69706]
===
match
---
name: next_dagrun_after_date [58696,58718]
name: next_dagrun_after_date [60644,60666]
===
match
---
atom_expr [36483,36498]
atom_expr [36483,36498]
===
match
---
simple_stmt [62936,62960]
simple_stmt [64884,64908]
===
match
---
trailer [63898,63907]
trailer [65846,65855]
===
match
---
operator: + [44501,44502]
operator: + [44501,44502]
===
match
---
string: 'b_parent' [7974,7984]
string: 'b_parent' [7974,7984]
===
match
---
name: basename [19734,19742]
name: basename [19734,19742]
===
match
---
trailer [17017,17023]
trailer [17017,17023]
===
match
---
operator: = [30082,30083]
operator: = [30082,30083]
===
match
---
name: dag [35283,35286]
name: dag [35283,35286]
===
match
---
name: parameterized [49804,49817]
name: parameterized [49804,49817]
===
match
---
atom_expr [17343,17369]
atom_expr [17343,17369]
===
match
---
name: timedelta [55498,55507]
name: timedelta [57446,57455]
===
match
---
suite [64947,65001]
suite [66895,66949]
===
match
---
trailer [42894,42919]
trailer [42894,42919]
===
match
---
name: clear_db_dags [24112,24125]
name: clear_db_dags [24112,24125]
===
match
---
number: 5 [58450,58451]
number: 5 [60398,60399]
===
match
---
operator: , [51887,51888]
operator: , [53835,53836]
===
match
---
name: num [69039,69042]
name: num [70987,70990]
===
match
---
operator: = [30361,30362]
operator: = [30361,30362]
===
match
---
trailer [64657,64666]
trailer [66605,66614]
===
match
---
atom_expr [25171,25184]
atom_expr [25171,25184]
===
match
---
fstring_expr [15567,15570]
fstring_expr [15567,15570]
===
match
---
decorator [57718,57762]
decorator [59666,59710]
===
match
---
operator: != [45173,45175]
operator: != [45173,45175]
===
match
---
atom_expr [18277,18415]
atom_expr [18277,18415]
===
match
---
atom_expr [61838,61865]
atom_expr [63786,63813]
===
match
---
name: _next [23005,23010]
name: _next [23005,23010]
===
match
---
string: 'test-dag2' [26898,26909]
string: 'test-dag2' [26898,26909]
===
match
---
for_stmt [13374,13783]
for_stmt [13374,13783]
===
match
---
operator: = [18629,18630]
operator: = [18629,18630]
===
match
---
name: orm_subdag [29459,29469]
name: orm_subdag [29459,29469]
===
match
---
string: 'tag-1' [24302,24309]
string: 'tag-1' [24302,24309]
===
match
---
expr_stmt [30621,30645]
expr_stmt [30621,30645]
===
match
---
dictorsetmaker [4249,4264]
dictorsetmaker [4249,4264]
===
match
---
atom_expr [34253,34268]
atom_expr [34253,34268]
===
match
---
operator: , [46672,46673]
operator: , [46672,46673]
===
match
---
arglist [14047,14111]
arglist [14047,14111]
===
match
---
testlist_comp [19995,20008]
testlist_comp [19995,20008]
===
match
---
operator: = [55138,55139]
operator: = [57086,57087]
===
match
---
operator: = [63444,63445]
operator: = [65392,65393]
===
match
---
name: op3 [38473,38476]
name: op3 [38473,38476]
===
match
---
simple_stmt [7999,8017]
simple_stmt [7999,8017]
===
match
---
name: dag [47964,47967]
name: dag [47964,47967]
===
match
---
simple_stmt [7198,7220]
simple_stmt [7198,7220]
===
match
---
name: op2 [9970,9973]
name: op2 [9970,9973]
===
match
---
operator: = [53890,53891]
operator: = [55838,55839]
===
match
---
operator: , [24808,24809]
operator: , [24808,24809]
===
match
---
simple_stmt [8870,8903]
simple_stmt [8870,8903]
===
match
---
name: dag [22792,22795]
name: dag [22792,22795]
===
match
---
operator: , [26642,26643]
operator: , [26642,26643]
===
match
---
simple_stmt [36132,36177]
simple_stmt [36132,36177]
===
match
---
trailer [52893,52945]
trailer [54841,54893]
===
match
---
number: 0 [55444,55445]
number: 0 [57392,57393]
===
match
---
name: convert [21974,21981]
name: convert [21974,21981]
===
match
---
number: 2038 [62413,62417]
number: 2038 [64361,64365]
===
match
---
trailer [47939,47949]
trailer [47939,47949]
===
match
---
simple_stmt [68608,68684]
simple_stmt [70556,70632]
===
match
---
argument [39301,39320]
argument [39301,39320]
===
match
---
atom_expr [50509,50532]
atom_expr [50509,50532]
===
match
---
simple_stmt [39179,39332]
simple_stmt [39179,39332]
===
match
---
operator: = [49993,49994]
operator: = [49993,49994]
===
match
---
name: catchup [57361,57368]
name: catchup [59309,59316]
===
match
---
expr_stmt [48139,48150]
expr_stmt [48139,48150]
===
match
---
operator: -> [2653,2655]
operator: -> [2653,2655]
===
match
---
operator: , [55007,55008]
operator: , [56955,56956]
===
match
---
comparison [45721,45746]
comparison [45721,45746]
===
match
---
trailer [9703,9716]
trailer [9703,9716]
===
match
---
name: next_dagrun_after_date [58481,58503]
name: next_dagrun_after_date [60429,60451]
===
match
---
trailer [17439,17441]
trailer [17439,17441]
===
match
---
name: incr [40732,40736]
name: incr [40732,40736]
===
match
---
simple_stmt [56686,56732]
simple_stmt [58634,58680]
===
match
---
name: t_1 [50954,50957]
name: t_1 [50954,50957]
===
match
---
atom_expr [61144,61176]
atom_expr [63092,63124]
===
match
---
name: pytest [62119,62125]
name: pytest [64067,64073]
===
match
---
operator: , [30601,30602]
operator: , [30601,30602]
===
match
---
number: 1 [2386,2387]
number: 1 [2386,2387]
===
match
---
argument [18062,18084]
argument [18062,18084]
===
match
---
name: timezone [57731,57739]
name: timezone [59679,59687]
===
match
---
atom_expr [61757,61784]
atom_expr [63705,63732]
===
match
---
operator: , [54082,54083]
operator: , [56030,56031]
===
match
---
argument [55715,55751]
argument [57663,57699]
===
match
---
argument [63473,63534]
argument [65421,65482]
===
match
---
operator: = [28108,28109]
operator: = [28108,28109]
===
match
---
name: convert [21477,21484]
name: convert [21477,21484]
===
match
---
operator: * [53867,53868]
operator: * [55815,55816]
===
match
---
trailer [36443,36452]
trailer [36443,36452]
===
match
---
fstring_start: f' [60244,60246]
fstring_start: f' [62192,62194]
===
match
---
name: session [2852,2859]
name: session [2852,2859]
===
match
---
simple_stmt [44221,44226]
simple_stmt [44221,44226]
===
match
---
atom_expr [10382,10401]
atom_expr [10382,10401]
===
match
---
name: dag [37493,37496]
name: dag [37493,37496]
===
match
---
suite [26604,27196]
suite [26604,27196]
===
match
---
trailer [25177,25184]
trailer [25177,25184]
===
match
---
simple_stmt [35647,35707]
simple_stmt [35647,35707]
===
match
---
trailer [23767,23844]
trailer [23767,23844]
===
match
---
name: next_date [55938,55947]
name: next_date [57886,57895]
===
match
---
name: clear [52638,52643]
name: clear [54586,54591]
===
match
---
name: task_dict [38665,38674]
name: task_dict [38665,38674]
===
match
---
simple_stmt [39890,39972]
simple_stmt [39890,39972]
===
match
---
expr_stmt [61250,61304]
expr_stmt [63198,63252]
===
match
---
operator: , [59598,59599]
operator: , [61546,61547]
===
match
---
name: self [19526,19530]
name: self [19526,19530]
===
match
---
string: 'owner1' [29597,29605]
string: 'owner1' [29597,29605]
===
match
---
simple_stmt [23095,23156]
simple_stmt [23095,23156]
===
match
---
name: dag_id [32146,32152]
name: dag_id [32146,32152]
===
match
---
operator: == [13765,13767]
operator: == [13765,13767]
===
match
---
trailer [52637,52643]
trailer [54585,54591]
===
match
---
name: _clean_up [42941,42950]
name: _clean_up [42941,42950]
===
match
---
operator: = [32668,32669]
operator: = [32668,32669]
===
match
---
trailer [29115,29125]
trailer [29115,29125]
===
match
---
funcdef [12196,12447]
funcdef [12196,12447]
===
match
---
trailer [6449,6455]
trailer [6449,6455]
===
match
---
name: make_dag [56494,56502]
name: make_dag [58442,58450]
===
match
---
atom_expr [67325,67338]
atom_expr [69273,69286]
===
match
---
expr_stmt [30870,30947]
expr_stmt [30870,30947]
===
match
---
suite [6816,6858]
suite [6816,6858]
===
match
---
operator: , [26375,26376]
operator: , [26375,26376]
===
match
---
name: self [62334,62338]
name: self [64282,64286]
===
match
---
trailer [2683,2685]
trailer [2683,2685]
===
match
---
arglist [51531,51538]
arglist [51531,51538]
===
match
---
expr_stmt [13426,13461]
expr_stmt [13426,13461]
===
match
---
atom_expr [53040,53057]
atom_expr [54988,55005]
===
match
---
trailer [56240,56263]
trailer [58188,58211]
===
match
---
trailer [38710,38719]
trailer [38710,38719]
===
match
---
name: create_session [42740,42754]
name: create_session [42740,42754]
===
match
---
trailer [54421,54444]
trailer [56369,56392]
===
match
---
name: self [45875,45879]
name: self [45875,45879]
===
match
---
dictorsetmaker [24341,24428]
dictorsetmaker [24341,24428]
===
match
---
parameters [38900,38906]
parameters [38900,38906]
===
match
---
simple_stmt [1267,1306]
simple_stmt [1267,1306]
===
match
---
string: 'DAG' [10905,10910]
string: 'DAG' [10905,10910]
===
match
---
with_stmt [66871,66972]
with_stmt [68819,68920]
===
match
---
tfpdef [2784,2795]
tfpdef [2784,2795]
===
match
---
funcdef [4801,5082]
funcdef [4801,5082]
===
match
---
expr_stmt [67728,67759]
expr_stmt [69676,69707]
===
match
---
argument [28058,28087]
argument [28058,28087]
===
match
---
comp_op [28146,28152]
comp_op [28146,28152]
===
match
---
name: default_args [44511,44523]
name: default_args [44511,44523]
===
match
---
simple_stmt [31704,31793]
simple_stmt [31704,31793]
===
match
---
name: include_subdags [49385,49400]
name: include_subdags [49385,49400]
===
match
---
name: dag [55223,55226]
name: dag [57171,57174]
===
match
---
operator: , [8385,8386]
operator: , [8385,8386]
===
match
---
name: task [20115,20119]
name: task [20115,20119]
===
match
---
operator: , [64155,64156]
operator: , [66103,66104]
===
match
---
operator: , [59601,59602]
operator: , [61549,61550]
===
match
---
name: dag_diff_load_time [45442,45460]
name: dag_diff_load_time [45442,45460]
===
match
---
name: depth [12525,12530]
name: depth [12525,12530]
===
match
---
atom_expr [6370,6398]
atom_expr [6370,6398]
===
match
---
comparison [49768,49797]
comparison [49768,49797]
===
match
---
name: local_tz [34794,34802]
name: local_tz [34794,34802]
===
match
---
operator: = [12531,12532]
operator: = [12531,12532]
===
match
---
name: freeze_time [57719,57730]
name: freeze_time [59667,59678]
===
match
---
simple_stmt [42841,42874]
simple_stmt [42841,42874]
===
match
---
name: stdout_lines [36659,36671]
name: stdout_lines [36659,36671]
===
match
---
param [68019,68035]
param [69967,69983]
===
match
---
name: run_id [43386,43392]
name: run_id [43386,43392]
===
match
---
testlist_comp [46588,46601]
testlist_comp [46588,46601]
===
match
---
number: 2018 [21503,21507]
number: 2018 [21503,21507]
===
match
---
operator: , [57705,57706]
operator: , [59653,59654]
===
match
---
operator: = [30874,30875]
operator: = [30874,30875]
===
match
---
string: "STORE_DAG_CODE" [34133,34149]
string: "STORE_DAG_CODE" [34133,34149]
===
match
---
atom_expr [55489,55519]
atom_expr [57437,57467]
===
match
---
expr_stmt [59744,59788]
expr_stmt [61692,61736]
===
match
---
parameters [51882,51933]
parameters [53830,53881]
===
match
---
name: airflow [1575,1582]
name: airflow [1575,1582]
===
match
---
argument [64389,64401]
argument [66337,66349]
===
match
---
atom [51716,51735]
atom [53664,53683]
===
match
---
operator: = [13975,13976]
operator: = [13975,13976]
===
match
---
name: dag_decorator [67090,67103]
name: dag_decorator [69038,69051]
===
match
---
trailer [19098,19106]
trailer [19098,19106]
===
match
---
decorator [66585,66632]
decorator [68533,68580]
===
match
---
name: test_dag_id [44309,44320]
name: test_dag_id [44309,44320]
===
match
---
name: DAG [47129,47132]
name: DAG [47129,47132]
===
match
---
number: 1 [12138,12139]
number: 1 [12138,12139]
===
match
---
name: num [66721,66724]
name: num [68669,68672]
===
match
---
operator: = [13489,13490]
operator: = [13489,13490]
===
match
---
trailer [41633,41637]
trailer [41633,41637]
===
match
---
operator: , [29943,29944]
operator: , [29943,29944]
===
match
---
operator: = [3024,3025]
operator: = [3024,3025]
===
match
---
operator: } [39640,39641]
operator: } [39640,39641]
===
match
---
name: DummyOperator [35444,35457]
name: DummyOperator [35444,35457]
===
match
---
operator: , [29872,29873]
operator: , [29872,29873]
===
match
---
shift_expr [36011,36042]
shift_expr [36011,36042]
===
match
---
atom_expr [39093,39168]
atom_expr [39093,39168]
===
match
---
simple_stmt [49038,49062]
simple_stmt [49038,49062]
===
match
---
with_stmt [6499,6561]
with_stmt [6499,6561]
===
match
---
name: value [67497,67502]
name: value [69445,69450]
===
match
---
assert_stmt [68732,68764]
assert_stmt [70680,70712]
===
match
---
atom_expr [49194,49210]
atom_expr [49194,49210]
===
match
---
operator: , [38588,38589]
operator: , [38588,38589]
===
match
---
operator: = [41273,41274]
operator: = [41273,41274]
===
match
---
atom_expr [6758,6808]
atom_expr [6758,6808]
===
match
---
arith_expr [14687,14692]
arith_expr [14687,14692]
===
match
---
operator: , [25184,25185]
operator: , [25184,25185]
===
match
---
string: "depends_on_past" [64723,64740]
string: "depends_on_past" [66671,66688]
===
match
---
operator: , [9089,9090]
operator: , [9089,9090]
===
match
---
name: dag_id [47322,47328]
name: dag_id [47322,47328]
===
match
---
suite [49977,51679]
suite [49977,51679]
===
match
---
trailer [47388,47394]
trailer [47388,47394]
===
match
---
operator: , [66416,66417]
operator: , [68364,68365]
===
match
---
name: op3 [6415,6418]
name: op3 [6415,6418]
===
match
---
param [54694,54705]
param [56642,56653]
===
match
---
name: self [43793,43797]
name: self [43793,43797]
===
match
---
parameters [58830,58836]
parameters [60778,60784]
===
match
---
trailer [50054,50062]
trailer [50054,50062]
===
match
---
name: subdag_id [30621,30630]
name: subdag_id [30621,30630]
===
match
---
number: 30 [55516,55518]
number: 30 [57464,57466]
===
match
---
name: next_date [58387,58396]
name: next_date [60335,60344]
===
match
---
trailer [11825,11839]
trailer [11825,11839]
===
match
---
simple_stmt [20460,20555]
simple_stmt [20460,20555]
===
match
---
name: start_date [60895,60905]
name: start_date [62843,62853]
===
match
---
trailer [52237,52405]
trailer [54185,54353]
===
match
---
name: dag [36234,36237]
name: dag [36234,36237]
===
match
---
simple_stmt [53613,53729]
simple_stmt [55561,55677]
===
match
---
name: runs [53781,53785]
name: runs [55729,55733]
===
match
---
name: orm_subdag [29729,29739]
name: orm_subdag [29729,29739]
===
match
---
suite [64335,64412]
suite [66283,66360]
===
match
---
operator: = [41293,41294]
operator: = [41293,41294]
===
match
---
name: DagParam [1658,1666]
name: DagParam [1658,1666]
===
match
---
argument [55669,55701]
argument [57617,57649]
===
match
---
trailer [25433,25439]
trailer [25433,25439]
===
match
---
parameters [54666,54714]
parameters [56614,56662]
===
match
---
expr_stmt [48649,48663]
expr_stmt [48649,48663]
===
match
---
number: 3 [58570,58571]
number: 3 [60518,60519]
===
match
---
operator: , [25978,25979]
operator: , [25978,25979]
===
match
---
name: op3 [35392,35395]
name: op3 [35392,35395]
===
match
---
operator: = [41103,41104]
operator: = [41103,41104]
===
match
---
atom_expr [56698,56731]
atom_expr [58646,58679]
===
match
---
comparison [30489,30520]
comparison [30489,30520]
===
match
---
name: op3 [6364,6367]
name: op3 [6364,6367]
===
match
---
operator: , [48977,48978]
operator: , [48977,48978]
===
match
---
atom_expr [48225,48349]
atom_expr [48225,48349]
===
match
---
trailer [35938,35952]
trailer [35938,35952]
===
match
---
simple_stmt [21000,21061]
simple_stmt [21000,21061]
===
match
---
name: self [8193,8197]
name: self [8193,8197]
===
match
---
trailer [28607,28639]
trailer [28607,28639]
===
match
---
name: range [47166,47171]
name: range [47166,47171]
===
match
---
trailer [67777,67787]
trailer [69725,69735]
===
match
---
name: dag [41639,41642]
name: dag [41639,41642]
===
match
---
fstring_string: dummy_task_ [64372,64383]
fstring_string: dummy_task_ [66320,66331]
===
match
---
name: name [35110,35114]
name: name [35110,35114]
===
match
---
argument [30110,30124]
argument [30110,30124]
===
match
---
name: dag [35764,35767]
name: dag [35764,35767]
===
match
---
param [60123,60127]
param [62071,62075]
===
match
---
name: operator [69131,69139]
name: operator [71079,71087]
===
match
---
string: '2019-06-01' [10940,10952]
string: '2019-06-01' [10940,10952]
===
match
---
operator: = [29896,29897]
operator: = [29896,29897]
===
match
---
name: session [34469,34476]
name: session [34469,34476]
===
match
---
operator: = [38477,38478]
operator: = [38477,38478]
===
match
---
operator: == [52921,52923]
operator: == [54869,54871]
===
match
---
operator: = [68497,68498]
operator: = [70445,70446]
===
match
---
funcdef [11891,12191]
funcdef [11891,12191]
===
match
---
string: 'owner1' [6255,6263]
string: 'owner1' [6255,6263]
===
match
---
decorator [51684,51860]
decorator [53632,53808]
===
match
---
atom_expr [25376,25399]
atom_expr [25376,25399]
===
match
---
name: xcom_pass_to_op [67148,67163]
name: xcom_pass_to_op [69096,69111]
===
match
---
atom_expr [18903,18941]
atom_expr [18903,18941]
===
match
---
name: dag_id [45943,45949]
name: dag_id [45943,45949]
===
match
---
operator: , [22743,22744]
operator: , [22743,22744]
===
match
---
param [68965,68981]
param [70913,70929]
===
match
---
arglist [2380,2396]
arglist [2380,2396]
===
match
---
argument [62011,62046]
argument [63959,63994]
===
match
---
operator: = [53952,53953]
operator: = [55900,55901]
===
match
---
trailer [4388,4393]
trailer [4388,4393]
===
match
---
comparison [58530,58572]
comparison [60478,60520]
===
match
---
name: op3 [38048,38051]
name: op3 [38048,38051]
===
match
---
name: schedule_interval [7387,7404]
name: schedule_interval [7387,7404]
===
match
---
atom_expr [21166,21188]
atom_expr [21166,21188]
===
match
---
operator: = [52741,52742]
operator: = [54689,54690]
===
match
---
name: expand [46336,46342]
name: expand [46336,46342]
===
match
---
string: "t3" [38023,38027]
string: "t3" [38023,38027]
===
match
---
name: session [26740,26747]
name: session [26740,26747]
===
match
---
operator: = [67672,67673]
operator: = [69620,69621]
===
match
---
atom_expr [21417,21451]
atom_expr [21417,21451]
===
match
---
name: start_date [49243,49253]
name: start_date [49243,49253]
===
match
---
string: 'test-dag' [24976,24986]
string: 'test-dag' [24976,24986]
===
match
---
expr_stmt [34029,34054]
expr_stmt [34029,34054]
===
match
---
operator: = [51312,51313]
operator: = [51312,51313]
===
match
---
operator: = [39987,39988]
operator: = [39987,39988]
===
match
---
param [68093,68096]
param [70041,70044]
===
match
---
operator: == [23348,23350]
operator: == [23348,23350]
===
match
---
trailer [36877,36884]
trailer [36877,36884]
===
match
---
name: set2 [10333,10337]
name: set2 [10333,10337]
===
match
---
name: hash [45762,45766]
name: hash [45762,45766]
===
match
---
name: orientation [5369,5380]
name: orientation [5369,5380]
===
match
---
name: dag [45790,45793]
name: dag [45790,45793]
===
match
---
assert_stmt [54340,54363]
assert_stmt [56288,56311]
===
match
---
operator: } [15573,15574]
operator: } [15573,15574]
===
match
---
simple_stmt [36389,36407]
simple_stmt [36389,36407]
===
match
---
name: models [3720,3726]
name: models [3720,3726]
===
match
---
with_stmt [6985,7046]
with_stmt [6985,7046]
===
match
---
trailer [61275,61298]
trailer [63223,63246]
===
match
---
trailer [10200,10207]
trailer [10200,10207]
===
match
---
testlist_comp [25997,26027]
testlist_comp [25997,26027]
===
match
---
name: timedelta [17103,17112]
name: timedelta [17103,17112]
===
match
---
fstring_string: dag_run.execution_date did not match expectation:  [39567,39617]
fstring_string: dag_run.execution_date did not match expectation:  [39567,39617]
===
match
---
expr_stmt [7586,7716]
expr_stmt [7586,7716]
===
match
---
atom_expr [31169,31185]
atom_expr [31169,31185]
===
match
---
argument [52074,52091]
argument [54022,54039]
===
match
---
atom_expr [61205,61240]
atom_expr [63153,63188]
===
match
---
atom_expr [25453,25476]
atom_expr [25453,25476]
===
match
---
name: task [13697,13701]
name: task [13697,13701]
===
match
---
decorated [51684,53152]
decorated [53632,55100]
===
match
---
operator: = [22790,22791]
operator: = [22790,22791]
===
match
---
name: job_id [52548,52554]
name: job_id [54496,54502]
===
match
---
number: 4 [17682,17683]
number: 4 [17682,17683]
===
match
---
name: test_following_schedule_relativedelta [23451,23488]
name: test_following_schedule_relativedelta [23451,23488]
===
match
---
name: resolve_template_files [19413,19435]
name: resolve_template_files [19413,19435]
===
match
---
name: dag [64237,64240]
name: dag [66185,66188]
===
match
---
name: stdout [36524,36530]
name: stdout [36524,36530]
===
match
---
number: 0 [17591,17592]
number: 0 [17591,17592]
===
match
---
simple_stmt [33676,33763]
simple_stmt [33676,33763]
===
match
---
comparison [39658,39688]
comparison [39658,39688]
===
match
---
trailer [12574,12582]
trailer [12574,12582]
===
match
---
string: 't3' [38501,38505]
string: 't3' [38501,38505]
===
match
---
trailer [30496,30509]
trailer [30496,30509]
===
match
---
name: flush [18995,19000]
name: flush [18995,19000]
===
match
---
argument [52758,52773]
argument [54706,54721]
===
match
---
string: '2019-06-05T00:00:00+05:00' [11642,11669]
string: '2019-06-05T00:00:00+05:00' [11642,11669]
===
match
---
atom_expr [52911,52920]
atom_expr [54859,54868]
===
match
---
name: isinstance [66328,66338]
name: isinstance [68276,68286]
===
match
---
operator: = [7062,7063]
operator: = [7062,7063]
===
match
---
simple_stmt [4856,4936]
simple_stmt [4856,4936]
===
match
---
atom_expr [42740,42756]
atom_expr [42740,42756]
===
match
---
name: dag_id [34262,34268]
name: dag_id [34262,34268]
===
match
---
name: DEFAULT_DATE [48965,48977]
name: DEFAULT_DATE [48965,48977]
===
match
---
simple_stmt [46135,46169]
simple_stmt [46135,46169]
===
match
---
name: airflow [1898,1905]
name: airflow [1898,1905]
===
match
---
operator: } [12023,12024]
operator: } [12023,12024]
===
match
---
operator: == [62082,62084]
operator: == [64030,64032]
===
match
---
simple_stmt [36687,36718]
simple_stmt [36687,36718]
===
match
---
trailer [21802,21804]
trailer [21802,21804]
===
match
---
expr_stmt [15349,15358]
expr_stmt [15349,15358]
===
match
---
trailer [53477,53500]
trailer [55425,55448]
===
match
---
operator: , [53445,53446]
operator: , [55393,55394]
===
match
---
operator: { [43899,43900]
operator: { [43899,43900]
===
match
---
name: DAG [48678,48681]
name: DAG [48678,48681]
===
match
---
trailer [24027,24037]
trailer [24027,24037]
===
match
---
operator: = [10660,10661]
operator: = [10660,10661]
===
match
---
operator: = [22737,22738]
operator: = [22737,22738]
===
match
---
name: permissions [61552,61563]
name: permissions [63500,63511]
===
match
---
trailer [13447,13461]
trailer [13447,13461]
===
match
---
assert_stmt [10460,10494]
assert_stmt [10460,10494]
===
match
---
name: op5 [6722,6725]
name: op5 [6722,6725]
===
match
---
name: start [20353,20358]
name: start [20353,20358]
===
match
---
operator: , [28087,28088]
operator: , [28087,28088]
===
match
---
decorator [66678,66694]
decorator [68626,68642]
===
match
---
name: op2 [38217,38220]
name: op2 [38217,38220]
===
match
---
name: test_next_dagrun_after_date_once [53161,53193]
name: test_next_dagrun_after_date_once [55109,55141]
===
match
---
name: self [3548,3552]
name: self [3548,3552]
===
match
---
atom_expr [9374,9393]
atom_expr [9374,9393]
===
match
---
name: ti_state_begin [51889,51903]
name: ti_state_begin [53837,53851]
===
match
---
operator: = [47283,47284]
operator: = [47283,47284]
===
match
---
trailer [48168,48211]
trailer [48168,48211]
===
match
---
atom_expr [33380,33396]
atom_expr [33380,33396]
===
match
---
operator: , [46478,46479]
operator: , [46478,46479]
===
match
---
trailer [46805,46868]
trailer [46805,46868]
===
match
---
parameters [48123,48129]
parameters [48123,48129]
===
match
---
arglist [49243,49473]
arglist [49243,49473]
===
match
---
name: dag_id [43147,43153]
name: dag_id [43147,43153]
===
match
---
name: deactivate_deleted_dags [34384,34407]
name: deactivate_deleted_dags [34384,34407]
===
match
---
arglist [31752,31791]
arglist [31752,31791]
===
match
---
name: convert [20977,20984]
name: convert [20977,20984]
===
match
---
string: "Task id 't1' has already been added to the DAG" [36913,36961]
string: "Task id 't1' has already been added to the DAG" [36913,36961]
===
match
---
operator: = [51057,51058]
operator: = [51057,51058]
===
match
---
simple_stmt [53520,53545]
simple_stmt [55468,55493]
===
match
---
decorated [3141,3502]
decorated [3141,3502]
===
match
---
operator: , [30936,30937]
operator: , [30936,30937]
===
match
---
atom_expr [19082,19106]
atom_expr [19082,19106]
===
match
---
operator: } [34924,34925]
operator: } [34924,34925]
===
match
---
name: op1 [36251,36254]
name: op1 [36251,36254]
===
match
---
trailer [60544,60735]
trailer [62492,62683]
===
match
---
atom [51715,51793]
atom [53663,53741]
===
match
---
name: _clean_up [53134,53143]
name: _clean_up [55082,55091]
===
match
---
name: prev_local [22228,22238]
name: prev_local [22228,22238]
===
match
---
trailer [61222,61240]
trailer [63170,63188]
===
match
---
name: dag [63445,63448]
name: dag [65393,65396]
===
match
---
trailer [9165,9186]
trailer [9165,9186]
===
match
---
dictorsetmaker [10809,10835]
dictorsetmaker [10809,10835]
===
match
---
trailer [69246,69253]
trailer [71194,71201]
===
match
---
atom_expr [49132,49145]
atom_expr [49132,49145]
===
match
---
name: depth [15349,15354]
name: depth [15349,15354]
===
match
---
suite [16545,16672]
suite [16545,16672]
===
match
---
name: DEFAULT_DATE [28724,28736]
name: DEFAULT_DATE [28724,28736]
===
match
---
argument [58154,58189]
argument [60102,60137]
===
match
---
name: session [30529,30536]
name: session [30529,30536]
===
match
---
name: start_date [43627,43637]
name: start_date [43627,43637]
===
match
---
trailer [4960,4996]
trailer [4960,4996]
===
match
---
name: DagModel [34483,34491]
name: DagModel [34483,34491]
===
match
---
name: dag [66364,66367]
name: dag [68312,68315]
===
match
---
name: test_task [17053,17062]
name: test_task [17053,17062]
===
match
---
atom_expr [23102,23124]
atom_expr [23102,23124]
===
match
---
trailer [35800,35814]
trailer [35800,35814]
===
match
---
funcdef [22350,23442]
funcdef [22350,23442]
===
match
---
atom_expr [6415,6422]
atom_expr [6415,6422]
===
match
---
arglist [57287,57297]
arglist [59235,59245]
===
match
---
dictorsetmaker [9508,9525]
dictorsetmaker [9508,9525]
===
match
---
operator: = [15559,15560]
operator: = [15559,15560]
===
match
---
name: setUp [64964,64969]
name: setUp [66912,66917]
===
match
---
trailer [10361,10364]
trailer [10361,10364]
===
match
---
dictorsetmaker [25947,26326]
dictorsetmaker [25947,26326]
===
match
---
operator: >> [36393,36395]
operator: >> [36393,36395]
===
match
---
name: dag [40792,40795]
name: dag [40792,40795]
===
match
---
name: Session [30294,30301]
name: Session [30294,30301]
===
match
---
operator: = [67439,67440]
operator: = [69387,69388]
===
match
---
name: dag [30312,30315]
name: dag [30312,30315]
===
match
---
atom [26704,26790]
atom [26704,26790]
===
match
---
operator: == [26341,26343]
operator: == [26341,26343]
===
match
---
operator: = [27591,27592]
operator: = [27591,27592]
===
match
---
atom_expr [49691,49703]
atom_expr [49691,49703]
===
match
---
atom [26244,26275]
atom [26244,26275]
===
match
---
assert_stmt [6617,6639]
assert_stmt [6617,6639]
===
match
---
number: 1 [64908,64909]
number: 1 [66856,66857]
===
match
---
operator: , [17062,17063]
operator: , [17062,17063]
===
match
---
simple_stmt [58523,58573]
simple_stmt [60471,60521]
===
match
---
arglist [5235,5308]
arglist [5235,5308]
===
match
---
operator: = [20744,20745]
operator: = [20744,20745]
===
match
---
name: timezone [55301,55309]
name: timezone [57249,57257]
===
match
---
atom [37213,37231]
atom [37213,37231]
===
match
---
number: 2 [9305,9306]
number: 2 [9305,9306]
===
match
---
argument [47859,47879]
argument [47859,47879]
===
match
---
name: num [66251,66254]
name: num [68199,68202]
===
match
---
simple_stmt [47487,47527]
simple_stmt [47487,47527]
===
match
---
name: depth [15801,15806]
name: depth [15801,15806]
===
match
---
name: test_dag_param_resolves [66981,67004]
name: test_dag_param_resolves [68929,68952]
===
match
---
name: dag_id [26763,26769]
name: dag_id [26763,26769]
===
match
---
testlist_comp [12953,13083]
testlist_comp [12953,13083]
===
match
---
name: prev [22948,22952]
name: prev [22948,22952]
===
match
---
argument [30994,31010]
argument [30994,31010]
===
match
---
name: start_date [67662,67672]
name: start_date [69610,69620]
===
match
---
name: model [28027,28032]
name: model [28027,28032]
===
match
---
operator: , [20404,20405]
operator: , [20404,20405]
===
match
---
operator: = [52164,52165]
operator: = [54112,54113]
===
match
---
name: catchup [54706,54713]
name: catchup [56654,56661]
===
match
---
atom_expr [28166,28193]
atom_expr [28166,28193]
===
match
---
operator: = [20426,20427]
operator: = [20426,20427]
===
match
---
decorated [56865,57713]
decorated [58813,59661]
===
match
---
operator: = [62468,62469]
operator: = [64416,64417]
===
match
---
string: "t1" [37977,37981]
string: "t1" [37977,37981]
===
match
---
assert_stmt [16319,16361]
assert_stmt [16319,16361]
===
match
---
name: task_id [40423,40430]
name: task_id [40423,40430]
===
match
---
name: sync_to_db [42496,42506]
name: sync_to_db [42496,42506]
===
match
---
name: pattern [13987,13994]
name: pattern [13987,13994]
===
match
---
name: dag_id [47133,47139]
name: dag_id [47133,47139]
===
match
---
name: schedule_interval [42258,42275]
name: schedule_interval [42258,42275]
===
match
---
trailer [17047,17121]
trailer [17047,17121]
===
match
---
atom_expr [41899,41935]
atom_expr [41899,41935]
===
match
---
name: task [15076,15080]
name: task [15076,15080]
===
match
---
operator: = [56612,56613]
operator: = [58560,58561]
===
match
---
name: timedelta [57330,57339]
name: timedelta [59278,59287]
===
match
---
name: self [16709,16713]
name: self [16709,16713]
===
match
---
trailer [19365,19378]
trailer [19365,19378]
===
match
---
atom_expr [40079,40119]
atom_expr [40079,40119]
===
match
---
simple_stmt [16952,17006]
simple_stmt [16952,17006]
===
match
---
simple_stmt [17558,17575]
simple_stmt [17558,17575]
===
match
---
funcdef [49913,51679]
funcdef [49913,51679]
===
match
---
name: op9 [7235,7238]
name: op9 [7235,7238]
===
match
---
trailer [8931,8943]
trailer [8931,8943]
===
match
---
name: contextlib [884,894]
name: contextlib [884,894]
===
match
---
simple_stmt [3752,3788]
simple_stmt [3752,3788]
===
match
---
name: dags_needing_dagruns [62892,62912]
name: dags_needing_dagruns [64840,64860]
===
match
---
comparison [38091,38101]
comparison [38091,38101]
===
match
---
decorated [65280,65356]
decorated [67228,67304]
===
match
---
name: row [24850,24853]
name: row [24850,24853]
===
match
---
trailer [42555,42565]
trailer [42555,42565]
===
match
---
string: 'dag-test-dagtag' [24404,24421]
string: 'dag-test-dagtag' [24404,24421]
===
match
---
operator: , [34950,34951]
operator: , [34950,34951]
===
match
---
assert_stmt [39419,39452]
assert_stmt [39419,39452]
===
match
---
name: DAG [32573,32576]
name: DAG [32573,32576]
===
match
---
atom_expr [63333,63573]
atom_expr [65281,65521]
===
match
---
atom_expr [19547,19585]
atom_expr [19547,19585]
===
match
---
operator: , [46736,46737]
operator: , [46736,46737]
===
match
---
atom_expr [20850,20872]
atom_expr [20850,20872]
===
match
---
operator: { [14238,14239]
operator: { [14238,14239]
===
match
---
name: jinja_udf [18494,18503]
name: jinja_udf [18494,18503]
===
match
---
param [21311,21315]
param [21311,21315]
===
match
---
trailer [20941,20946]
trailer [20941,20946]
===
match
---
operator: >> [36022,36024]
operator: >> [36022,36024]
===
match
---
name: tzinfo [11879,11885]
name: tzinfo [11879,11885]
===
match
---
string: "test" [64707,64713]
string: "test" [66655,66661]
===
match
---
number: 4 [57758,57759]
number: 4 [59706,59707]
===
match
---
simple_stmt [10004,10028]
simple_stmt [10004,10028]
===
match
---
string: "@once" [46588,46595]
string: "@once" [46588,46595]
===
match
---
operator: , [18183,18184]
operator: , [18183,18184]
===
match
---
name: set_downstream [9868,9882]
name: set_downstream [9868,9882]
===
match
---
name: dag [62465,62468]
name: dag [64413,64416]
===
match
---
simple_stmt [43309,43340]
simple_stmt [43309,43340]
===
match
---
simple_stmt [11802,11886]
simple_stmt [11802,11886]
===
match
---
trailer [25579,25584]
trailer [25579,25584]
===
match
---
name: dag [38572,38575]
name: dag [38572,38575]
===
match
---
simple_stmt [34935,34979]
simple_stmt [34935,34979]
===
match
---
trailer [55370,55380]
trailer [57318,57328]
===
match
---
name: date [54263,54267]
name: date [56211,56215]
===
match
---
name: convert [20370,20377]
name: convert [20370,20377]
===
match
---
argument [31295,31320]
argument [31295,31320]
===
match
---
name: max_active_runs [50274,50289]
name: max_active_runs [50274,50289]
===
match
---
trailer [45814,45828]
trailer [45814,45828]
===
match
---
name: task [19217,19221]
name: task [19217,19221]
===
match
---
operator: , [57490,57491]
operator: , [59438,59439]
===
match
---
arglist [44489,44528]
arglist [44489,44528]
===
match
---
factor [3284,3286]
factor [3284,3286]
===
match
---
name: pendulum [20310,20318]
name: pendulum [20310,20318]
===
match
---
import_as_names [1391,1429]
import_as_names [1391,1429]
===
match
---
name: self [65102,65106]
name: self [67050,67054]
===
match
---
simple_stmt [56352,56385]
simple_stmt [58300,58333]
===
match
---
atom_expr [67341,67358]
atom_expr [69289,69306]
===
match
---
import_from [1765,1816]
import_from [1765,1816]
===
match
---
string: 'dummy' [27568,27575]
string: 'dummy' [27568,27575]
===
match
---
arith_expr [55356,55389]
arith_expr [57304,57337]
===
match
---
assert_stmt [29325,29405]
assert_stmt [29325,29405]
===
match
---
simple_stmt [44135,44176]
simple_stmt [44135,44176]
===
match
---
name: calculated_weight [15126,15143]
name: calculated_weight [15126,15143]
===
match
---
simple_stmt [36803,36858]
simple_stmt [36803,36858]
===
match
---
operator: = [61085,61086]
operator: = [63033,63034]
===
match
---
argument [23679,23687]
argument [23679,23687]
===
match
---
operator: = [49501,49502]
operator: = [49501,49502]
===
match
---
number: 1 [52090,52091]
number: 1 [54038,54039]
===
match
---
operator: == [39528,39530]
operator: == [39528,39530]
===
match
---
operator: = [67478,67479]
operator: = [69426,69427]
===
match
---
simple_stmt [17873,17973]
simple_stmt [17873,17973]
===
match
---
operator: , [40352,40353]
operator: , [40352,40353]
===
match
---
operator: } [5984,5985]
operator: } [5984,5985]
===
match
---
name: self [53129,53133]
name: self [55077,55081]
===
match
---
simple_stmt [22504,22550]
simple_stmt [22504,22550]
===
match
---
name: topological_sort [10060,10076]
name: topological_sort [10060,10076]
===
match
---
atom_expr [9325,9358]
atom_expr [9325,9358]
===
match
---
sync_comp_for [51736,51792]
sync_comp_for [53684,53740]
===
match
---
atom_expr [68366,68598]
atom_expr [70314,70546]
===
match
---
name: dag [27788,27791]
name: dag [27788,27791]
===
match
---
expr_stmt [39047,39071]
expr_stmt [39047,39071]
===
match
---
atom_expr [20022,20039]
atom_expr [20022,20039]
===
match
---
assert_stmt [51642,51678]
assert_stmt [51642,51678]
===
match
---
trailer [41870,41895]
trailer [41870,41895]
===
match
---
argument [16929,16941]
argument [16929,16941]
===
match
---
funcdef [42964,43816]
funcdef [42964,43816]
===
match
---
atom_expr [17504,17522]
atom_expr [17504,17522]
===
match
---
operator: + [51287,51288]
operator: + [51287,51288]
===
match
---
name: session [33064,33071]
name: session [33064,33071]
===
match
---
name: BaseOperator [40410,40422]
name: BaseOperator [40410,40422]
===
match
---
expr_stmt [9077,9100]
expr_stmt [9077,9100]
===
match
---
name: dag_id [4961,4967]
name: dag_id [4961,4967]
===
match
---
string: "4 5 * * *" [59274,59285]
string: "4 5 * * *" [61222,61233]
===
match
---
operator: } [60476,60477]
operator: } [62424,62425]
===
match
---
name: DummyOperator [52107,52120]
name: DummyOperator [54055,54068]
===
match
---
name: DuplicateTaskIdFound [36885,36905]
name: DuplicateTaskIdFound [36885,36905]
===
match
---
trailer [52832,52838]
trailer [54780,54786]
===
match
---
number: 1 [10362,10363]
number: 1 [10362,10363]
===
match
---
simple_stmt [2495,2511]
simple_stmt [2495,2511]
===
match
---
atom_expr [46183,46199]
atom_expr [46183,46199]
===
match
---
name: task_id [48649,48656]
name: task_id [48649,48656]
===
match
---
name: DAG [38320,38323]
name: DAG [38320,38323]
===
match
---
simple_stmt [25294,25320]
simple_stmt [25294,25320]
===
match
---
operator: == [3091,3093]
operator: == [3091,3093]
===
match
---
suite [67243,67271]
suite [69191,69219]
===
match
---
name: DAG [3727,3730]
name: DAG [3727,3730]
===
match
---
simple_stmt [37096,37153]
simple_stmt [37096,37153]
===
match
---
name: set2 [10238,10242]
name: set2 [10238,10242]
===
match
---
expr_stmt [18660,18694]
expr_stmt [18660,18694]
===
match
---
argument [40698,40710]
argument [40698,40710]
===
match
---
operator: == [58306,58308]
operator: == [60254,60256]
===
match
---
trailer [43734,43745]
trailer [43734,43745]
===
match
---
arglist [47558,47631]
arglist [47558,47631]
===
match
---
operator: == [22251,22253]
operator: == [22251,22253]
===
match
---
name: start_date [53262,53272]
name: start_date [55210,55220]
===
match
---
name: self [5120,5124]
name: self [5120,5124]
===
match
---
operator: = [49288,49289]
operator: = [49288,49289]
===
match
---
comparison [23394,23441]
comparison [23394,23441]
===
match
---
atom_expr [49089,49146]
atom_expr [49089,49146]
===
match
---
name: State [51749,51754]
name: State [53697,53702]
===
match
---
atom_expr [16276,16302]
atom_expr [16276,16302]
===
match
---
trailer [62827,62836]
trailer [64775,64784]
===
match
---
expr_stmt [45933,45980]
expr_stmt [45933,45980]
===
match
---
atom_expr [8116,8177]
atom_expr [8116,8177]
===
match
---
trailer [63233,63276]
trailer [65181,65224]
===
match
---
operator: , [50135,50136]
operator: , [50135,50136]
===
match
---
operator: == [24829,24831]
operator: == [24829,24831]
===
match
---
name: access_control [62226,62240]
name: access_control [64174,64188]
===
match
---
trailer [24386,24422]
trailer [24386,24422]
===
match
---
name: DAG [35044,35047]
name: DAG [35044,35047]
===
match
---
name: isoformat [23399,23408]
name: isoformat [23399,23408]
===
match
---
name: dag_id [53144,53150]
name: dag_id [55092,55098]
===
match
---
argument [64844,64853]
argument [66792,66801]
===
match
---
simple_stmt [19015,19054]
simple_stmt [19015,19054]
===
match
---
simple_stmt [42254,42286]
simple_stmt [42254,42286]
===
match
---
atom_expr [39741,39752]
atom_expr [39741,39752]
===
match
---
simple_stmt [13324,13361]
simple_stmt [13324,13361]
===
match
---
name: DAG [10901,10904]
name: DAG [10901,10904]
===
match
---
atom_expr [30979,31026]
atom_expr [30979,31026]
===
match
---
name: test_next_dagrun_after_auto_align [58797,58830]
name: test_next_dagrun_after_auto_align [60745,60778]
===
match
---
trailer [36539,36541]
trailer [36539,36541]
===
match
---
name: DummyOperator [6110,6123]
name: DummyOperator [6110,6123]
===
match
---
trailer [59409,59415]
trailer [61357,61363]
===
match
---
number: 1 [53450,53451]
number: 1 [55398,55399]
===
match
---
testlist_comp [25104,25133]
testlist_comp [25104,25133]
===
match
---
trailer [2997,3004]
trailer [2997,3004]
===
match
---
name: self [51977,51981]
name: self [53925,53929]
===
match
---
testlist_comp [64134,64158]
testlist_comp [66082,66106]
===
match
---
operator: , [26910,26911]
operator: , [26910,26911]
===
match
---
atom_expr [35444,35471]
atom_expr [35444,35471]
===
match
---
name: dag [10056,10059]
name: dag [10056,10059]
===
match
---
argument [49457,49472]
argument [49457,49472]
===
match
---
funcdef [30571,32501]
funcdef [30571,32501]
===
match
---
simple_stmt [47836,47899]
simple_stmt [47836,47899]
===
match
---
name: RUNNING [49138,49145]
name: RUNNING [49138,49145]
===
match
---
dotted_name [2014,2033]
dotted_name [2014,2033]
===
match
---
name: default_args [10912,10924]
name: default_args [10912,10924]
===
match
---
argument [43258,43275]
argument [43258,43275]
===
match
---
operator: = [48304,48305]
operator: = [48304,48305]
===
match
---
import_as_names [1457,1516]
import_as_names [1457,1516]
===
match
---
atom_expr [47166,47174]
atom_expr [47166,47174]
===
match
---
name: second [55422,55428]
name: second [57370,57376]
===
match
---
argument [57340,57346]
argument [59288,59294]
===
match
---
string: "test_set_dag_runs_state" [47089,47114]
string: "test_set_dag_runs_state" [47089,47114]
===
match
---
comparison [57670,57712]
comparison [59618,59660]
===
match
---
argument [52502,52522]
argument [54450,54470]
===
match
---
simple_stmt [66244,66255]
simple_stmt [68192,68203]
===
match
---
simple_stmt [56021,56215]
simple_stmt [57969,58163]
===
match
---
suite [38368,38553]
suite [38368,38553]
===
match
---
atom_expr [31411,31573]
atom_expr [31411,31573]
===
match
---
suite [6486,6608]
suite [6486,6608]
===
match
---
arglist [38584,38637]
arglist [38584,38637]
===
match
---
operator: = [16231,16232]
operator: = [16231,16232]
===
match
---
arglist [17297,17369]
arglist [17297,17369]
===
match
---
trailer [33131,33138]
trailer [33131,33138]
===
match
---
string: 'dag-bulk-sync-0' [25744,25761]
string: 'dag-bulk-sync-0' [25744,25761]
===
match
---
name: correct_weight [13593,13607]
name: correct_weight [13593,13607]
===
match
---
simple_stmt [69204,69228]
simple_stmt [71152,71176]
===
match
---
name: test_dag_as_context_manager [5674,5701]
name: test_dag_as_context_manager [5674,5701]
===
match
---
argument [18584,18607]
argument [18584,18607]
===
match
---
param [4841,4845]
param [4841,4845]
===
match
---
name: args [44675,44679]
name: args [44675,44679]
===
match
---
simple_stmt [8338,8405]
simple_stmt [8338,8405]
===
match
---
simple_stmt [2694,2710]
simple_stmt [2694,2710]
===
match
---
operator: , [59343,59344]
operator: , [61291,61292]
===
match
---
name: all [32378,32381]
name: all [32378,32381]
===
match
---
operator: } [25818,25819]
operator: } [25818,25819]
===
match
---
atom_expr [52718,52744]
atom_expr [54666,54692]
===
match
---
argument [44442,44459]
argument [44442,44459]
===
match
---
simple_stmt [30043,30267]
simple_stmt [30043,30267]
===
match
---
arglist [13074,13082]
arglist [13074,13082]
===
match
---
arglist [53946,54026]
arglist [55894,55974]
===
match
---
name: dag_id [43154,43160]
name: dag_id [43154,43160]
===
match
---
operator: , [55655,55656]
operator: , [57603,57604]
===
match
---
number: 1 [3306,3307]
number: 1 [3306,3307]
===
match
---
simple_stmt [1715,1765]
simple_stmt [1715,1765]
===
match
---
atom_expr [47914,47925]
atom_expr [47914,47925]
===
match
---
operator: , [58086,58087]
operator: , [60034,60035]
===
match
---
fstring [39565,39642]
fstring [39565,39642]
===
match
---
suite [35638,36093]
suite [35638,36093]
===
match
---
trailer [36070,36077]
trailer [36070,36077]
===
match
---
simple_stmt [32726,32743]
simple_stmt [32726,32743]
===
match
---
operator: , [46559,46560]
operator: , [46559,46560]
===
match
---
name: task [14843,14847]
name: task [14843,14847]
===
match
---
assert_stmt [12034,12074]
assert_stmt [12034,12074]
===
match
---
argument [40261,40290]
argument [40261,40290]
===
match
---
operator: , [26275,26276]
operator: , [26275,26276]
===
match
---
simple_stmt [38041,38052]
simple_stmt [38041,38052]
===
match
---
operator: = [39306,39307]
operator: = [39306,39307]
===
match
---
string: 'parent_dag.child_dag' [7351,7373]
string: 'parent_dag.child_dag' [7351,7373]
===
match
---
trailer [24524,24590]
trailer [24524,24590]
===
match
---
name: test_dag [16813,16821]
name: test_dag [16813,16821]
===
match
---
arglist [57486,57496]
arglist [59434,59444]
===
match
---
name: template_fields [19976,19991]
name: template_fields [19976,19991]
===
match
---
expr_stmt [12543,12553]
expr_stmt [12543,12553]
===
match
---
name: State [48022,48027]
name: State [48022,48027]
===
match
---
parameters [28471,28477]
parameters [28471,28477]
===
match
---
string: 'dag__dot__subtask' [29694,29713]
string: 'dag__dot__subtask' [29694,29713]
===
match
---
trailer [34245,34252]
trailer [34245,34252]
===
match
---
arglist [54062,54101]
arglist [56010,56049]
===
match
---
atom_expr [46645,46671]
atom_expr [46645,46671]
===
match
---
trailer [26539,26556]
trailer [26539,26556]
===
match
---
arglist [38324,38359]
arglist [38324,38359]
===
match
---
string: 'dag_default_view_old' [33594,33616]
string: 'dag_default_view_old' [33594,33616]
===
match
---
name: dagruns [49493,49500]
name: dagruns [49493,49500]
===
match
---
comparison [6874,6908]
comparison [6874,6908]
===
match
---
funcdef [65247,65383]
funcdef [67195,67331]
===
match
---
operator: == [23189,23191]
operator: == [23189,23191]
===
match
---
name: session [50869,50876]
name: session [50869,50876]
===
match
---
atom_expr [22297,22313]
atom_expr [22297,22313]
===
match
---
operator: , [44709,44710]
operator: , [44709,44710]
===
match
---
with_item [46183,46210]
with_item [46183,46210]
===
match
---
operator: = [35488,35489]
operator: = [35488,35489]
===
match
---
number: 1 [53300,53301]
number: 1 [55248,55249]
===
match
---
operator: @ [67195,67196]
operator: @ [69143,69144]
===
match
---
simple_stmt [27258,27414]
simple_stmt [27258,27414]
===
match
---
name: query [26748,26753]
name: query [26748,26753]
===
match
---
funcdef [63978,64027]
funcdef [65926,65975]
===
match
---
suite [24103,24443]
suite [24103,24443]
===
match
---
operator: = [23060,23061]
operator: = [23060,23061]
===
match
---
name: get_num_task_instances [17600,17622]
name: get_num_task_instances [17600,17622]
===
match
---
operator: } [29615,29616]
operator: } [29615,29616]
===
match
---
simple_stmt [19971,20010]
simple_stmt [19971,20010]
===
match
---
testlist_comp [25055,25084]
testlist_comp [25055,25084]
===
match
---
simple_stmt [45714,45747]
simple_stmt [45714,45747]
===
match
---
trailer [61534,61550]
trailer [63482,63498]
===
match
---
name: i [14458,14459]
name: i [14458,14459]
===
match
---
name: timezone [20570,20578]
name: timezone [20570,20578]
===
match
---
trailer [34656,34658]
trailer [34656,34658]
===
match
---
simple_stmt [6829,6858]
simple_stmt [6829,6858]
===
match
---
string: "@daily" [60317,60325]
string: "@daily" [62265,62273]
===
match
---
testlist_comp [19334,19347]
testlist_comp [19334,19347]
===
match
---
param [3891,3895]
param [3891,3895]
===
match
---
simple_stmt [10691,10727]
simple_stmt [10691,10727]
===
match
---
name: set [36063,36066]
name: set [36063,36066]
===
match
---
operator: = [52302,52303]
operator: = [54250,54251]
===
match
---
assert_stmt [45153,45179]
assert_stmt [45153,45179]
===
match
---
comparison [27889,27933]
comparison [27889,27933]
===
match
---
operator: = [63557,63558]
operator: = [65505,65506]
===
match
---
name: op1 [6212,6215]
name: op1 [6212,6215]
===
match
---
name: subdag [61067,61073]
name: subdag [63015,63021]
===
match
---
name: tasks [6928,6933]
name: tasks [6928,6933]
===
match
---
expr_stmt [32933,32995]
expr_stmt [32933,32995]
===
match
---
trailer [33721,33754]
trailer [33721,33754]
===
match
---
suite [65108,65484]
suite [67056,67432]
===
match
---
string: "@yearly" [46550,46559]
string: "@yearly" [46550,46559]
===
match
---
trailer [22952,22962]
trailer [22952,22962]
===
match
---
comparison [67775,67803]
comparison [69723,69751]
===
match
---
name: default_args [68905,68917]
name: default_args [70853,70865]
===
match
---
name: test_resolve_template_files_value [18848,18881]
name: test_resolve_template_files_value [18848,18881]
===
match
---
simple_stmt [40669,40712]
simple_stmt [40669,40712]
===
match
---
name: isoformat [23113,23122]
name: isoformat [23113,23122]
===
match
---
operator: = [52035,52036]
operator: = [53983,53984]
===
match
---
suite [32924,33319]
suite [32924,33319]
===
match
---
name: return_num [69028,69038]
name: return_num [70976,70986]
===
match
---
operator: = [33840,33841]
operator: = [33840,33841]
===
match
---
name: i [15787,15788]
name: i [15787,15788]
===
match
---
operator: , [55050,55051]
operator: , [56998,56999]
===
match
---
name: expand [49818,49824]
name: expand [49818,49824]
===
match
---
expr_stmt [8780,8812]
expr_stmt [8780,8812]
===
match
---
name: bulk_write_to_db [27673,27689]
name: bulk_write_to_db [27673,27689]
===
match
---
string: """Verify if dag.leaves returns the leaf tasks of a DAG.""" [35647,35706]
string: """Verify if dag.leaves returns the leaf tasks of a DAG.""" [35647,35706]
===
match
---
number: 2020 [58561,58565]
number: 2020 [60509,60513]
===
match
---
comparison [13747,13782]
comparison [13747,13782]
===
match
---
name: raises [37395,37401]
name: raises [37395,37401]
===
match
---
suite [25642,25682]
suite [25642,25682]
===
match
---
name: Session [27631,27638]
name: Session [27631,27638]
===
match
---
argument [46832,46867]
argument [46832,46867]
===
match
---
expr_stmt [54175,54186]
expr_stmt [56123,56134]
===
match
---
trailer [16130,16132]
trailer [16130,16132]
===
match
---
string: 'dag' [30856,30861]
string: 'dag' [30856,30861]
===
match
---
trailer [34032,34040]
trailer [34032,34040]
===
match
---
expr_stmt [19361,19395]
expr_stmt [19361,19395]
===
match
---
comparison [22879,22932]
comparison [22879,22932]
===
match
---
name: DummyOperator [6532,6545]
name: DummyOperator [6532,6545]
===
match
---
name: DEFAULT_DATE [38347,38359]
name: DEFAULT_DATE [38347,38359]
===
match
---
simple_stmt [22132,22168]
simple_stmt [22132,22168]
===
match
---
operator: { [64688,64689]
operator: { [66636,66637]
===
match
---
operator: = [17657,17658]
operator: = [17657,17658]
===
match
---
name: session [3044,3051]
name: session [3044,3051]
===
match
---
operator: = [22665,22666]
operator: = [22665,22666]
===
match
---
comparison [57455,57497]
comparison [59403,59445]
===
match
---
operator: = [48843,48844]
operator: = [48843,48844]
===
match
---
operator: = [53272,53273]
operator: = [55220,55221]
===
match
---
name: dag [67441,67444]
name: dag [69389,69392]
===
match
---
name: op5 [36088,36091]
name: op5 [36088,36091]
===
match
---
simple_stmt [45394,45421]
simple_stmt [45394,45421]
===
match
---
argument [42231,42244]
argument [42231,42244]
===
match
---
atom_expr [24850,24856]
atom_expr [24850,24856]
===
match
---
expr_stmt [57605,57654]
expr_stmt [59553,59602]
===
match
---
name: start_date [30209,30219]
name: start_date [30209,30219]
===
match
---
name: dag [42254,42257]
name: dag [42254,42257]
===
match
---
operator: } [26339,26340]
operator: } [26339,26340]
===
match
---
simple_stmt [918,949]
simple_stmt [918,949]
===
match
---
argument [60343,60360]
argument [62291,62308]
===
match
---
dictorsetmaker [8587,8604]
dictorsetmaker [8587,8604]
===
match
---
trailer [19089,19098]
trailer [19089,19098]
===
match
---
name: RUNNING [17148,17155]
name: RUNNING [17148,17155]
===
match
---
simple_stmt [23755,23845]
simple_stmt [23755,23845]
===
match
---
operator: = [37497,37498]
operator: = [37497,37498]
===
match
---
trailer [69130,69139]
trailer [71078,71087]
===
match
---
operator: = [52259,52260]
operator: = [54207,54208]
===
match
---
name: DEFAULT_DATE [44277,44289]
name: DEFAULT_DATE [44277,44289]
===
match
---
name: bash_command [37129,37141]
name: bash_command [37129,37141]
===
match
---
arglist [6171,6194]
arglist [6171,6194]
===
match
---
simple_stmt [22785,22819]
simple_stmt [22785,22819]
===
match
---
operator: , [31010,31011]
operator: , [31010,31011]
===
match
---
name: test_dag_task_priority_weight_total [12456,12491]
name: test_dag_task_priority_weight_total [12456,12491]
===
match
---
name: op9 [7101,7104]
name: op9 [7101,7104]
===
match
---
argument [36317,36329]
argument [36317,36329]
===
match
---
suite [65519,65897]
suite [67467,67845]
===
match
---
atom_expr [35490,35517]
atom_expr [35490,35517]
===
match
---
parameters [36787,36793]
parameters [36787,36793]
===
match
---
param [47472,47476]
param [47472,47476]
===
match
---
operator: , [59716,59717]
operator: , [61664,61665]
===
match
---
operator: = [7332,7333]
operator: = [7332,7333]
===
match
---
parameters [60089,60128]
parameters [62037,62076]
===
match
---
atom_expr [53129,53151]
atom_expr [55077,55099]
===
match
---
operator: , [21515,21516]
operator: , [21515,21516]
===
match
---
argument [55099,55111]
argument [57047,57059]
===
match
---
atom_expr [59383,59415]
atom_expr [61331,61363]
===
match
---
name: get [33718,33721]
name: get [33718,33721]
===
match
---
atom [37706,37724]
atom [37706,37724]
===
match
---
name: days [46636,46640]
name: days [46636,46640]
===
match
---
operator: , [14052,14053]
operator: , [14052,14053]
===
match
---
atom_expr [52260,52283]
atom_expr [54208,54231]
===
match
---
trailer [18967,18980]
trailer [18967,18980]
===
match
---
parameters [32917,32923]
parameters [32917,32923]
===
match
---
arglist [16828,16871]
arglist [16828,16871]
===
match
---
simple_stmt [27833,27874]
simple_stmt [27833,27874]
===
match
---
name: dag [30962,30965]
name: dag [30962,30965]
===
match
---
operator: = [50168,50169]
operator: = [50168,50169]
===
match
---
assert_stmt [57663,57712]
assert_stmt [59611,59660]
===
match
---
trailer [52958,52962]
trailer [54906,54910]
===
match
---
name: BaseOperator [54049,54061]
name: BaseOperator [55997,56009]
===
match
---
simple_stmt [68692,68724]
simple_stmt [70640,70672]
===
match
---
simple_stmt [52031,52093]
simple_stmt [53979,54041]
===
match
---
name: DAG [30876,30879]
name: DAG [30876,30879]
===
match
---
expr_stmt [7946,7985]
expr_stmt [7946,7985]
===
match
---
atom_expr [27669,27705]
atom_expr [27669,27705]
===
match
---
trailer [33760,33762]
trailer [33760,33762]
===
match
---
atom_expr [42254,42275]
atom_expr [42254,42275]
===
match
---
operator: , [6037,6038]
operator: , [6037,6038]
===
match
---
name: DEFAULT_DATE [52341,52353]
name: DEFAULT_DATE [54289,54301]
===
match
---
comparison [29133,29157]
comparison [29133,29157]
===
match
---
string: "test-dag" [24578,24588]
string: "test-dag" [24578,24588]
===
match
---
operator: = [56116,56117]
operator: = [58064,58065]
===
match
---
operator: = [17947,17948]
operator: = [17947,17948]
===
match
---
operator: = [23975,23976]
operator: = [23975,23976]
===
match
---
trailer [10176,10179]
trailer [10176,10179]
===
match
---
name: task [19266,19270]
name: task [19266,19270]
===
match
---
atom_expr [15792,15807]
atom_expr [15792,15807]
===
match
---
atom_expr [58248,58280]
atom_expr [60196,60228]
===
match
---
decorated [67944,68297]
decorated [69892,70245]
===
match
---
name: prev_local [23273,23283]
name: prev_local [23273,23283]
===
match
---
trailer [20073,20096]
trailer [20073,20096]
===
match
---
atom_expr [46021,46050]
atom_expr [46021,46050]
===
match
---
parameters [67237,67242]
parameters [69185,69190]
===
match
---
atom_expr [53215,53339]
atom_expr [55163,55287]
===
match
---
name: State [43519,43524]
name: State [43519,43524]
===
match
---
name: TEST_DATE [39278,39287]
name: TEST_DATE [39278,39287]
===
match
---
expr_stmt [50933,51008]
expr_stmt [50933,51008]
===
match
---
simple_stmt [28166,28194]
simple_stmt [28166,28194]
===
match
---
simple_stmt [16813,16873]
simple_stmt [16813,16873]
===
match
---
simple_stmt [6573,6608]
simple_stmt [6573,6608]
===
match
---
suite [3190,3502]
suite [3190,3502]
===
match
---
name: task [19454,19458]
name: task [19454,19458]
===
match
---
operator: { [12883,12884]
operator: { [12883,12884]
===
match
---
trailer [47289,47294]
trailer [47289,47294]
===
match
---
comparison [16326,16361]
comparison [16326,16361]
===
match
---
with_stmt [5216,5392]
with_stmt [5216,5392]
===
match
---
suite [15897,15927]
suite [15897,15927]
===
match
---
assert_stmt [6715,6743]
assert_stmt [6715,6743]
===
match
---
name: dag_id [42822,42828]
name: dag_id [42822,42828]
===
match
---
number: 123 [52557,52560]
number: 123 [54505,54508]
===
match
---
string: "retries" [64797,64806]
string: "retries" [66745,66754]
===
match
---
name: assert_queries_count [25376,25396]
name: assert_queries_count [25376,25396]
===
match
---
operator: = [36255,36256]
operator: = [36255,36256]
===
match
---
funcdef [61412,62264]
funcdef [63360,64212]
===
match
---
name: query [2960,2965]
name: query [2960,2965]
===
match
---
arglist [64247,64297]
arglist [66195,66245]
===
match
---
trailer [24226,24237]
trailer [24226,24237]
===
match
---
trailer [63009,63011]
trailer [64957,64959]
===
match
---
atom [12883,12902]
atom [12883,12902]
===
match
---
name: start_date [68441,68451]
name: start_date [70389,70399]
===
match
---
name: task_id [52008,52015]
name: task_id [53956,53963]
===
match
---
string: "graph" [30513,30520]
string: "graph" [30513,30520]
===
match
---
name: self [48541,48545]
name: self [48541,48545]
===
match
---
string: "@monthly" [46468,46478]
string: "@monthly" [46468,46478]
===
match
---
string: 'op6' [6948,6953]
string: 'op6' [6948,6953]
===
match
---
operator: == [3430,3432]
operator: == [3430,3432]
===
match
---
name: days [57340,57344]
name: days [59288,59292]
===
match
---
atom_expr [9037,9067]
atom_expr [9037,9067]
===
match
---
operator: } [32089,32090]
operator: } [32089,32090]
===
match
---
simple_stmt [49155,49186]
simple_stmt [49155,49186]
===
match
---
operator: = [30334,30335]
operator: = [30334,30335]
===
match
---
name: DEFAULT_DATE [67578,67590]
name: DEFAULT_DATE [69526,69538]
===
match
---
atom_expr [36067,36077]
atom_expr [36067,36077]
===
match
---
name: task_id [30994,31001]
name: task_id [30994,31001]
===
match
---
atom_expr [48885,48908]
atom_expr [48885,48908]
===
match
---
name: airflow [2014,2021]
name: airflow [2014,2021]
===
match
---
trailer [46663,46671]
trailer [46663,46671]
===
match
---
name: previous_schedule [21699,21716]
name: previous_schedule [21699,21716]
===
match
---
name: NONE [47627,47631]
name: NONE [47627,47631]
===
match
---
name: prev [22785,22789]
name: prev [22785,22789]
===
match
---
expr_stmt [2519,2590]
expr_stmt [2519,2590]
===
match
---
assert_stmt [6648,6669]
assert_stmt [6648,6669]
===
match
---
operator: , [35534,35535]
operator: , [35534,35535]
===
match
---
trailer [57286,57298]
trailer [59234,59246]
===
match
---
trailer [62756,62768]
trailer [64704,64716]
===
match
---
name: tasks [9325,9330]
name: tasks [9325,9330]
===
match
---
atom_expr [55195,55231]
atom_expr [57143,57179]
===
match
---
arglist [19129,19198]
arglist [19129,19198]
===
match
---
name: dr [27943,27945]
name: dr [27943,27945]
===
match
---
string: 't1' [48659,48663]
string: 't1' [48659,48663]
===
match
---
argument [18201,18229]
argument [18201,18229]
===
match
---
name: dag_decorator [68891,68904]
name: dag_decorator [70839,70852]
===
match
---
name: timezone [21426,21434]
name: timezone [21426,21434]
===
match
---
operator: = [21640,21641]
operator: = [21640,21641]
===
match
---
string: 'dag-bulk-sync-2' [24791,24808]
string: 'dag-bulk-sync-2' [24791,24808]
===
match
---
operator: , [18044,18045]
operator: , [18044,18045]
===
match
---
operator: , [31958,31959]
operator: , [31958,31959]
===
match
---
operator: = [35396,35397]
operator: = [35396,35397]
===
match
---
trailer [26355,26361]
trailer [26355,26361]
===
match
---
atom_expr [66613,66630]
atom_expr [68561,68578]
===
match
---
trailer [33557,33567]
trailer [33557,33567]
===
match
---
atom_expr [10784,10837]
atom_expr [10784,10837]
===
match
---
operator: = [55772,55773]
operator: = [57720,57721]
===
match
---
simple_stmt [6678,6707]
simple_stmt [6678,6707]
===
match
---
name: task_id [38015,38022]
name: task_id [38015,38022]
===
match
---
name: width [15019,15024]
name: width [15019,15024]
===
match
---
atom_expr [62434,62490]
atom_expr [64382,64438]
===
match
---
name: utc [21564,21567]
name: utc [21564,21567]
===
match
---
simple_stmt [33833,33861]
simple_stmt [33833,33861]
===
match
---
name: dag [6990,6993]
name: dag [6990,6993]
===
match
---
number: 0 [13171,13172]
number: 0 [13171,13172]
===
match
---
argument [18609,18650]
argument [18609,18650]
===
match
---
suite [13299,13361]
suite [13299,13361]
===
match
---
name: DagRunType [48885,48895]
name: DagRunType [48885,48895]
===
match
---
simple_stmt [53462,53512]
simple_stmt [55410,55460]
===
match
---
trailer [56895,56907]
trailer [58843,58855]
===
match
---
suite [32558,32872]
suite [32558,32872]
===
match
---
param [56982,56986]
param [58930,58934]
===
match
---
trailer [21027,21029]
trailer [21027,21029]
===
match
---
name: session [17413,17420]
name: session [17413,17420]
===
match
---
operator: = [6178,6179]
operator: = [6178,6179]
===
match
---
name: query [33100,33105]
name: query [33100,33105]
===
match
---
name: next_local [20733,20743]
name: next_local [20733,20743]
===
match
---
trailer [36530,36539]
trailer [36530,36539]
===
match
---
suite [44208,44226]
suite [44208,44226]
===
match
---
atom_expr [35582,35596]
atom_expr [35582,35596]
===
match
---
name: topological_sort [9010,9026]
name: topological_sort [9010,9026]
===
match
---
name: next_date [53527,53536]
name: next_date [55475,55484]
===
match
---
expr_stmt [43094,43128]
expr_stmt [43094,43128]
===
match
---
number: 1 [10314,10315]
number: 1 [10314,10315]
===
match
---
atom_expr [17780,17864]
atom_expr [17780,17864]
===
match
---
name: test_resolve_template_files_list [19493,19525]
name: test_resolve_template_files_list [19493,19525]
===
match
---
name: operators [1728,1737]
name: operators [1728,1737]
===
match
---
trailer [13291,13298]
trailer [13291,13298]
===
match
---
suite [38907,39784]
suite [38907,39784]
===
match
---
simple_stmt [64237,64299]
simple_stmt [66185,66247]
===
match
---
operator: , [64272,64273]
operator: , [66220,66221]
===
match
---
name: topological_list [10382,10398]
name: topological_list [10382,10398]
===
match
---
name: default_view [33473,33485]
name: default_view [33473,33485]
===
match
---
name: i [14509,14510]
name: i [14509,14510]
===
match
---
argument [23781,23801]
argument [23781,23801]
===
match
---
operator: = [5561,5562]
operator: = [5561,5562]
===
match
---
name: DagRunType [50716,50726]
name: DagRunType [50716,50726]
===
match
---
name: conf [68562,68566]
name: conf [70510,70514]
===
match
---
arglist [64899,64909]
arglist [66847,66857]
===
match
---
name: self [21311,21315]
name: self [21311,21315]
===
match
---
operator: == [35012,35014]
operator: == [35012,35014]
===
match
---
name: tags [26462,26466]
name: tags [26462,26466]
===
match
---
operator: , [34903,34904]
operator: , [34903,34904]
===
match
---
argument [62782,62796]
argument [64730,64744]
===
match
---
name: dag_eq [44350,44356]
name: dag_eq [44350,44356]
===
match
---
atom_expr [36257,36284]
atom_expr [36257,36284]
===
match
---
trailer [57339,57347]
trailer [59287,59295]
===
match
---
argument [5555,5588]
argument [5555,5588]
===
match
---
string: "0 0 1 */3 *" [46521,46534]
string: "0 0 1 */3 *" [46521,46534]
===
match
---
name: self [32552,32556]
name: self [32552,32556]
===
match
---
number: 2 [9355,9356]
number: 2 [9355,9356]
===
match
---
name: next_date [58413,58422]
name: next_date [60361,60370]
===
match
---
name: subdag [60083,60089]
name: subdag [62031,62037]
===
match
---
operator: == [30410,30412]
operator: == [30410,30412]
===
match
---
operator: = [68403,68404]
operator: = [70351,70352]
===
match
---
trailer [32377,32381]
trailer [32377,32381]
===
match
---
string: 'dag-bulk-sync-2' [26146,26163]
string: 'dag-bulk-sync-2' [26146,26163]
===
match
---
assert_stmt [22872,22932]
assert_stmt [22872,22932]
===
match
---
atom_expr [19266,19281]
atom_expr [19266,19281]
===
match
---
string: 'dag' [29867,29872]
string: 'dag' [29867,29872]
===
match
---
atom_expr [27788,27824]
atom_expr [27788,27824]
===
match
---
argument [50201,50208]
argument [50201,50208]
===
match
---
operator: = [5915,5916]
operator: = [5915,5916]
===
match
---
name: pickle [45289,45295]
name: pickle [45289,45295]
===
match
---
trailer [19237,19252]
trailer [19237,19252]
===
match
---
name: airflow [1770,1777]
name: airflow [1770,1777]
===
match
---
operator: = [16793,16794]
operator: = [16793,16794]
===
match
---
name: dag [42492,42495]
name: dag [42492,42495]
===
match
---
funcdef [65006,65077]
funcdef [66954,67025]
===
match
---
simple_stmt [3452,3464]
simple_stmt [3452,3464]
===
match
---
name: session [18390,18397]
name: session [18390,18397]
===
match
---
atom_expr [50951,51008]
atom_expr [50951,51008]
===
match
---
name: start_date [12100,12110]
name: start_date [12100,12110]
===
match
---
assert_stmt [35575,35610]
assert_stmt [35575,35610]
===
match
---
parameters [30596,30611]
parameters [30596,30611]
===
match
---
string: "faketastic" [23789,23801]
string: "faketastic" [23789,23801]
===
match
---
trailer [45992,46003]
trailer [45992,46003]
===
match
---
operator: , [62660,62661]
operator: , [64608,64609]
===
match
---
trailer [15526,15703]
trailer [15526,15703]
===
match
---
name: dag [34994,34997]
name: dag [34994,34997]
===
match
---
operator: , [2582,2583]
operator: , [2582,2583]
===
match
---
name: i [15838,15839]
name: i [15838,15839]
===
match
---
name: dag [23013,23016]
name: dag [23013,23016]
===
match
---
atom [38134,38170]
atom [38134,38170]
===
match
---
operator: , [46573,46574]
operator: , [46573,46574]
===
match
---
name: op1 [37943,37946]
name: op1 [37943,37946]
===
match
---
name: op5 [35484,35487]
name: op5 [35484,35487]
===
match
---
argument [37066,37078]
argument [37066,37078]
===
match
---
name: num [65352,65355]
name: num [67300,67303]
===
match
---
operator: = [44147,44148]
operator: = [44147,44148]
===
match
---
operator: = [27567,27568]
operator: = [27567,27568]
===
match
---
name: self [11934,11938]
name: self [11934,11938]
===
match
---
suite [24651,24691]
suite [24651,24691]
===
match
---
param [28472,28476]
param [28472,28476]
===
match
---
suite [44126,45842]
suite [44126,45842]
===
match
---
trailer [59498,59669]
trailer [61446,61617]
===
match
---
trailer [34435,34447]
trailer [34435,34447]
===
match
---
name: DagRunType [50509,50519]
name: DagRunType [50509,50519]
===
match
---
operator: , [59285,59286]
operator: , [61233,61234]
===
match
---
name: op1 [10246,10249]
name: op1 [10246,10249]
===
match
---
atom_expr [6624,6631]
atom_expr [6624,6631]
===
match
---
argument [10912,10979]
argument [10912,10979]
===
match
---
name: datetime [41060,41068]
name: datetime [41060,41068]
===
match
---
operator: = [17750,17751]
operator: = [17750,17751]
===
match
---
suite [66901,66972]
suite [68849,68920]
===
match
---
operator: , [64136,64137]
operator: , [66084,66085]
===
match
---
operator: == [35115,35117]
operator: == [35115,35117]
===
match
---
number: 1 [62763,62764]
number: 1 [64711,64712]
===
match
---
name: start_date [16848,16858]
name: start_date [16848,16858]
===
match
---
simple_stmt [17675,17760]
simple_stmt [17675,17760]
===
match
---
assert_stmt [66357,66382]
assert_stmt [68305,68330]
===
match
---
trailer [42362,42439]
trailer [42362,42439]
===
match
---
operator: == [29353,29355]
operator: == [29353,29355]
===
match
---
name: dag [58003,58006]
name: dag [59951,59954]
===
match
---
assert_stmt [48042,48081]
assert_stmt [48042,48081]
===
match
---
operator: = [9004,9005]
operator: = [9004,9005]
===
match
---
number: 0 [15798,15799]
number: 0 [15798,15799]
===
match
---
operator: , [2384,2385]
operator: , [2384,2385]
===
match
---
number: 5 [58782,58783]
number: 5 [60730,60731]
===
match
---
argument [51072,51091]
argument [51072,51091]
===
match
---
operator: , [58189,58190]
operator: , [60137,60138]
===
match
---
number: 0 [2392,2393]
number: 0 [2392,2393]
===
match
---
operator: , [44509,44510]
operator: , [44509,44510]
===
match
---
simple_stmt [29014,29043]
simple_stmt [29014,29043]
===
match
---
simple_stmt [29775,29791]
simple_stmt [29775,29791]
===
match
---
trailer [27516,27532]
trailer [27516,27532]
===
match
---
operator: = [55083,55084]
operator: = [57031,57032]
===
match
---
name: self [54503,54507]
name: self [56451,56455]
===
match
---
string: 'tz_dag' [20620,20628]
string: 'tz_dag' [20620,20628]
===
match
---
name: suffix [19566,19572]
name: suffix [19566,19572]
===
match
---
trailer [26473,26485]
trailer [26473,26485]
===
match
---
operator: = [60611,60612]
operator: = [62559,62560]
===
match
---
name: dates [54156,54161]
name: dates [56104,56109]
===
match
---
suite [25563,25605]
suite [25563,25605]
===
match
---
argument [24190,24213]
argument [24190,24213]
===
match
---
simple_stmt [24223,24240]
simple_stmt [24223,24240]
===
match
---
operator: , [18372,18373]
operator: , [18372,18373]
===
match
---
name: datetime [55362,55370]
name: datetime [57310,57318]
===
match
---
argument [17173,17187]
argument [17173,17187]
===
match
---
name: topological_list [10208,10224]
name: topological_list [10208,10224]
===
match
---
expr_stmt [27715,27765]
expr_stmt [27715,27765]
===
match
---
simple_stmt [67325,67394]
simple_stmt [69273,69342]
===
match
---
testlist_comp [35531,35539]
testlist_comp [35531,35539]
===
match
---
name: provide_session [1993,2008]
name: provide_session [1993,2008]
===
match
---
arglist [58327,58337]
arglist [60275,60285]
===
match
---
atom_expr [33683,33709]
atom_expr [33683,33709]
===
match
---
atom_expr [55994,56011]
atom_expr [57942,57959]
===
match
---
name: op2 [36297,36300]
name: op2 [36297,36300]
===
match
---
atom_expr [22879,22901]
atom_expr [22879,22901]
===
match
---
operator: , [12098,12099]
operator: , [12098,12099]
===
match
---
operator: = [63497,63498]
operator: = [65445,65446]
===
match
---
name: test_dag_orientation_default_value [5401,5435]
name: test_dag_orientation_default_value [5401,5435]
===
match
---
atom_expr [13495,13509]
atom_expr [13495,13509]
===
match
---
simple_stmt [2599,2629]
simple_stmt [2599,2629]
===
match
---
name: dag [41531,41534]
name: dag [41531,41534]
===
match
---
trailer [48450,48455]
trailer [48450,48455]
===
match
---
operator: , [18060,18061]
operator: , [18060,18061]
===
match
---
operator: , [10249,10250]
operator: , [10249,10250]
===
match
---
operator: == [6252,6254]
operator: == [6252,6254]
===
match
---
expr_stmt [32567,32590]
expr_stmt [32567,32590]
===
match
---
operator: = [44357,44358]
operator: = [44357,44358]
===
match
---
name: args [44455,44459]
name: args [44455,44459]
===
match
---
name: f [19690,19691]
name: f [19690,19691]
===
match
---
name: dag_id [44079,44085]
name: dag_id [44079,44085]
===
match
---
simple_stmt [31169,31193]
simple_stmt [31169,31193]
===
match
---
trailer [23408,23410]
trailer [23408,23410]
===
match
---
trailer [61878,61894]
trailer [63826,63842]
===
match
---
name: op2 [37096,37099]
name: op2 [37096,37099]
===
match
---
operator: >> [36029,36031]
operator: >> [36029,36031]
===
match
---
atom_expr [18070,18083]
atom_expr [18070,18083]
===
match
---
trailer [67797,67803]
trailer [69745,69751]
===
match
---
assert_stmt [58289,58338]
assert_stmt [60237,60286]
===
match
---
trailer [58363,58386]
trailer [60311,60334]
===
match
---
expr_stmt [20689,20724]
expr_stmt [20689,20724]
===
match
---
name: task_id [52129,52136]
name: task_id [54077,54084]
===
match
---
operator: , [66342,66343]
operator: , [68290,68291]
===
match
---
string: 'DAG' [11607,11612]
string: 'DAG' [11607,11612]
===
match
---
trailer [22301,22311]
trailer [22301,22311]
===
match
---
atom_expr [17255,17264]
atom_expr [17255,17264]
===
match
---
name: session [30363,30370]
name: session [30363,30370]
===
match
---
name: assert_queries_count [25618,25638]
name: assert_queries_count [25618,25638]
===
match
---
atom [32061,32079]
atom [32061,32079]
===
match
---
param [2647,2651]
param [2647,2651]
===
match
---
name: get [5017,5020]
name: get [5017,5020]
===
match
---
operator: = [58246,58247]
operator: = [60194,60195]
===
match
---
operator: >> [38068,38070]
operator: >> [38068,38070]
===
match
---
string: "@quarterly" [46507,46519]
string: "@quarterly" [46507,46519]
===
match
---
trailer [37626,37649]
trailer [37626,37649]
===
match
---
trailer [40149,40363]
trailer [40149,40363]
===
match
---
argument [6843,6856]
argument [6843,6856]
===
match
---
operator: = [60939,60940]
operator: = [62887,62888]
===
match
---
name: template_file [19066,19079]
name: template_file [19066,19079]
===
match
---
expr_stmt [50094,50155]
expr_stmt [50094,50155]
===
match
---
comparison [41816,41849]
comparison [41816,41849]
===
match
---
comparison [62222,62263]
comparison [64170,64211]
===
match
---
atom [35551,35561]
atom [35551,35561]
===
match
---
argument [41207,41230]
argument [41207,41230]
===
match
---
comparison [6655,6669]
comparison [6655,6669]
===
match
---
simple_stmt [41096,41149]
simple_stmt [41096,41149]
===
match
---
name: subdag [50339,50345]
name: subdag [50339,50345]
===
match
---
trailer [51596,51603]
trailer [51596,51603]
===
match
---
operator: , [26846,26847]
operator: , [26846,26847]
===
match
---
name: session [29102,29109]
name: session [29102,29109]
===
match
---
atom_expr [59444,59479]
atom_expr [61392,61427]
===
match
---
trailer [27146,27150]
trailer [27146,27150]
===
match
---
atom_expr [46617,46643]
atom_expr [46617,46643]
===
match
---
name: schedule_interval [20648,20665]
name: schedule_interval [20648,20665]
===
match
---
atom_expr [10264,10281]
atom_expr [10264,10281]
===
match
---
name: isoformat [47685,47694]
name: isoformat [47685,47694]
===
match
---
operator: , [51456,51457]
operator: , [51456,51457]
===
match
---
name: DAG [65849,65852]
name: DAG [67797,67800]
===
match
---
name: dag [48159,48162]
name: dag [48159,48162]
===
match
---
name: is_paused_upon_creation [33981,34004]
name: is_paused_upon_creation [33981,34004]
===
match
---
name: owner [64389,64394]
name: owner [66337,66342]
===
match
---
trailer [46653,46663]
trailer [46653,46663]
===
match
---
operator: , [26127,26128]
operator: , [26127,26128]
===
match
---
atom_expr [34615,34692]
atom_expr [34615,34692]
===
match
---
import_from [1306,1359]
import_from [1306,1359]
===
match
---
atom_expr [51590,51603]
atom_expr [51590,51603]
===
match
---
import_from [1622,1666]
import_from [1622,1666]
===
match
---
operator: , [53295,53296]
operator: , [55243,55244]
===
match
---
operator: { [15567,15568]
operator: { [15567,15568]
===
match
---
expr_stmt [53024,53057]
expr_stmt [54972,55005]
===
match
---
operator: , [64809,64810]
operator: , [66757,66758]
===
match
---
name: noop_pipeline [66297,66310]
name: noop_pipeline [68245,68258]
===
match
---
trailer [20754,20762]
trailer [20754,20762]
===
match
---
atom_expr [53273,53302]
atom_expr [55221,55250]
===
match
---
name: local_tz [23286,23294]
name: local_tz [23286,23294]
===
match
---
name: owner [62474,62479]
name: owner [64422,64427]
===
match
---
string: """         Make sure DST transitions are properly observed         """ [20219,20290]
string: """         Make sure DST transitions are properly observed         """ [20219,20290]
===
match
---
name: DEFAULT_DATE [6795,6807]
name: DEFAULT_DATE [6795,6807]
===
match
---
trailer [52736,52744]
trailer [54684,54692]
===
match
---
trailer [63683,63687]
trailer [65631,65635]
===
match
---
operator: = [32989,32990]
operator: = [32989,32990]
===
match
---
atom_expr [47284,47294]
atom_expr [47284,47294]
===
match
---
suite [35287,35611]
suite [35287,35611]
===
match
---
string: 'op8' [7086,7091]
string: 'op8' [7086,7091]
===
match
---
operator: == [21189,21191]
operator: == [21189,21191]
===
match
---
trailer [39538,39553]
trailer [39538,39553]
===
match
---
trailer [60850,60907]
trailer [62798,62855]
===
match
---
name: task_dict [37693,37702]
name: task_dict [37693,37702]
===
match
---
operator: = [43320,43321]
operator: = [43320,43321]
===
match
---
atom_expr [36871,36962]
atom_expr [36871,36962]
===
match
---
trailer [17133,17139]
trailer [17133,17139]
===
match
---
operator: , [21507,21508]
operator: , [21507,21508]
===
match
---
operator: , [61230,61231]
operator: , [63178,63179]
===
match
---
trailer [30448,30461]
trailer [30448,30461]
===
match
---
expr_stmt [21070,21105]
expr_stmt [21070,21105]
===
match
---
trailer [22248,22250]
trailer [22248,22250]
===
match
---
name: dag_id [32244,32250]
name: dag_id [32244,32250]
===
match
---
param [7307,7311]
param [7307,7311]
===
match
---
name: utc [20942,20945]
name: utc [20942,20945]
===
match
---
name: start [2621,2626]
name: start [2621,2626]
===
match
---
simple_stmt [65034,65053]
simple_stmt [66982,67001]
===
match
---
atom [17820,17846]
atom [17820,17846]
===
match
---
arglist [50316,50354]
arglist [50316,50354]
===
match
---
name: DAG [15372,15375]
name: DAG [15372,15375]
===
match
---
operator: >> [37666,37668]
operator: >> [37666,37668]
===
match
---
operator: = [17292,17293]
operator: = [17292,17293]
===
match
---
atom_expr [2718,2746]
atom_expr [2718,2746]
===
match
---
assert_stmt [36056,36092]
assert_stmt [36056,36092]
===
match
---
number: 1 [59468,59469]
number: 1 [61416,61417]
===
match
---
atom_expr [2599,2628]
atom_expr [2599,2628]
===
match
---
name: DummyOperator [62434,62447]
name: DummyOperator [64382,64395]
===
match
---
name: prev [23229,23233]
name: prev [23229,23233]
===
match
---
name: DAG [10784,10787]
name: DAG [10784,10787]
===
match
---
string: 'Also fake' [41294,41305]
string: 'Also fake' [41294,41305]
===
match
---
operator: = [27620,27621]
operator: = [27620,27621]
===
match
---
operator: = [30661,30662]
operator: = [30661,30662]
===
match
---
atom_expr [51205,51467]
atom_expr [51205,51467]
===
match
---
trailer [52174,52182]
trailer [54122,54130]
===
match
---
trailer [39092,39169]
trailer [39092,39169]
===
match
---
name: test_dag_topological_sort2 [9410,9436]
name: test_dag_topological_sort2 [9410,9436]
===
match
---
name: self [42936,42940]
name: self [42936,42940]
===
match
---
name: self [68637,68641]
name: self [70585,70589]
===
match
---
simple_stmt [21159,21220]
simple_stmt [21159,21220]
===
match
---
trailer [29428,29440]
trailer [29428,29440]
===
match
---
expr_stmt [37493,37539]
expr_stmt [37493,37539]
===
match
---
string: """         Test that the dag file processor creates multiple dagruns         if a dag is scheduled with 'timedelta' and catchup=True         """ [57849,57994]
string: """         Test that the dag file processor creates multiple dagruns         if a dag is scheduled with 'timedelta' and catchup=True         """ [59797,59942]
===
match
---
name: create_session [1977,1991]
name: create_session [1977,1991]
===
match
---
fstring [24525,24545]
fstring [24525,24545]
===
match
---
trailer [22079,22089]
trailer [22079,22089]
===
match
---
name: dag_decorator [65597,65610]
name: dag_decorator [67545,67558]
===
match
---
assert_stmt [45282,45314]
assert_stmt [45282,45314]
===
match
---
simple_stmt [28203,28254]
simple_stmt [28203,28254]
===
match
---
operator: = [63361,63362]
operator: = [65309,65310]
===
match
---
atom_expr [35097,35114]
atom_expr [35097,35114]
===
match
---
atom [49875,49891]
atom [49875,49891]
===
match
---
trailer [52913,52920]
trailer [54861,54868]
===
match
---
name: test_count_number_queries [64183,64208]
name: test_count_number_queries [66131,66156]
===
match
---
simple_stmt [12924,13098]
simple_stmt [12924,13098]
===
match
---
trailer [36582,36588]
trailer [36582,36588]
===
match
---
name: task_id [7842,7849]
name: task_id [7842,7849]
===
match
---
string: 'owner' [5967,5974]
string: 'owner' [5967,5974]
===
match
---
simple_stmt [48742,48788]
simple_stmt [48742,48788]
===
match
---
operator: = [63752,63753]
operator: = [65700,65701]
===
match
---
operator: = [27786,27787]
operator: = [27786,27787]
===
match
---
operator: = [30809,30810]
operator: = [30809,30810]
===
match
---
expr_stmt [58680,58729]
expr_stmt [60628,60677]
===
match
---
operator: , [8310,8311]
operator: , [8310,8311]
===
match
---
parameters [66480,66486]
parameters [68428,68434]
===
match
---
atom_expr [14043,14112]
atom_expr [14043,14112]
===
match
---
name: prev [22857,22861]
name: prev [22857,22861]
===
match
---
name: subdag [60844,60850]
name: subdag [62792,62798]
===
match
---
expr_stmt [36251,36284]
expr_stmt [36251,36284]
===
match
---
name: self [69126,69130]
name: self [71074,71078]
===
match
---
name: create_dagrun [64466,64479]
name: create_dagrun [66414,66427]
===
match
---
fstring_expr [24541,24544]
fstring_expr [24541,24544]
===
match
---
operator: != [45829,45831]
operator: != [45829,45831]
===
match
---
param [10591,10595]
param [10591,10595]
===
match
---
parameters [33358,33364]
parameters [33358,33364]
===
match
---
string: 'C' [9757,9760]
string: 'C' [9757,9760]
===
match
---
assert_stmt [10153,10187]
assert_stmt [10153,10187]
===
match
---
name: timezone [57269,57277]
name: timezone [59217,59225]
===
match
---
name: i [3462,3463]
name: i [3462,3463]
===
match
---
trailer [10099,10117]
trailer [10099,10117]
===
match
---
operator: = [7659,7660]
operator: = [7659,7660]
===
match
---
atom_expr [27047,27060]
atom_expr [27047,27060]
===
match
---
atom_expr [27062,27073]
atom_expr [27062,27073]
===
match
---
atom_expr [47386,47394]
atom_expr [47386,47394]
===
match
---
operator: , [26113,26114]
operator: , [26113,26114]
===
match
---
dictorsetmaker [29597,29615]
dictorsetmaker [29597,29615]
===
match
---
name: start [22558,22563]
name: start [22558,22563]
===
match
---
atom_expr [33014,33032]
atom_expr [33014,33032]
===
match
---
simple_stmt [25413,25440]
simple_stmt [25413,25440]
===
match
---
name: in_ [31934,31937]
name: in_ [31934,31937]
===
match
---
name: dag [28240,28243]
name: dag [28240,28243]
===
match
---
param [38300,38304]
param [38300,38304]
===
match
---
name: local_tz [34915,34923]
name: local_tz [34915,34923]
===
match
---
name: stdout [36459,36465]
name: stdout [36459,36465]
===
match
---
arglist [62448,62489]
arglist [64396,64437]
===
match
---
suite [35768,36093]
suite [35768,36093]
===
match
---
operator: = [60445,60446]
operator: = [62393,62394]
===
match
---
simple_stmt [50364,50412]
simple_stmt [50364,50412]
===
match
---
assert_stmt [45036,45068]
assert_stmt [45036,45068]
===
match
---
name: dag [6283,6286]
name: dag [6283,6286]
===
match
---
return_stmt [65345,65355]
return_stmt [67293,67303]
===
match
---
name: dag_diff_name [45596,45609]
name: dag_diff_name [45596,45609]
===
match
---
trailer [28238,28253]
trailer [28238,28253]
===
match
---
name: dag3 [56698,56702]
name: dag3 [58646,58650]
===
match
---
simple_stmt [69126,69195]
simple_stmt [71074,71143]
===
match
---
expr_stmt [33938,34020]
expr_stmt [33938,34020]
===
match
---
name: session [63891,63898]
name: session [65839,65846]
===
match
---
atom_expr [19604,19624]
atom_expr [19604,19624]
===
match
---
atom_expr [59124,59296]
atom_expr [61072,61244]
===
match
---
arglist [39220,39321]
arglist [39220,39321]
===
match
---
name: sync_to_db [33045,33055]
name: sync_to_db [33045,33055]
===
match
---
atom_expr [29729,29747]
atom_expr [29729,29747]
===
match
---
name: DummyOperator [38001,38014]
name: DummyOperator [38001,38014]
===
match
---
name: end_date [51265,51273]
name: end_date [51265,51273]
===
match
---
name: default_args [11854,11866]
name: default_args [11854,11866]
===
match
---
name: self [18475,18479]
name: self [18475,18479]
===
match
---
dotted_name [48400,48420]
dotted_name [48400,48420]
===
match
---
name: session [52766,52773]
name: session [54714,54721]
===
match
---
atom_expr [53942,54027]
atom_expr [55890,55975]
===
match
---
assert_stmt [21228,21246]
assert_stmt [21228,21246]
===
match
---
trailer [51297,51307]
trailer [51297,51307]
===
match
---
name: _next [23171,23176]
name: _next [23171,23176]
===
match
---
operator: , [42415,42416]
operator: , [42415,42416]
===
match
---
comparison [31600,31694]
comparison [31600,31694]
===
match
---
name: dag [6628,6631]
name: dag [6628,6631]
===
match
---
trailer [11781,11793]
trailer [11781,11793]
===
match
---
trailer [47916,47925]
trailer [47916,47925]
===
match
---
name: test_fractional_seconds [42968,42991]
name: test_fractional_seconds [42968,42991]
===
match
---
name: session [17743,17750]
name: session [17743,17750]
===
match
---
funcdef [66075,66282]
funcdef [68023,68230]
===
match
---
name: set1 [10183,10187]
name: set1 [10183,10187]
===
match
---
import_from [1893,1942]
import_from [1893,1942]
===
match
---
name: DummyOperator [7017,7030]
name: DummyOperator [7017,7030]
===
match
---
operator: = [43287,43288]
operator: = [43287,43288]
===
match
---
number: 0 [26726,26727]
number: 0 [26726,26727]
===
match
---
atom_expr [21530,21553]
atom_expr [21530,21553]
===
match
---
simple_stmt [35873,35907]
simple_stmt [35873,35907]
===
match
---
operator: == [51587,51589]
operator: == [51587,51589]
===
match
---
operator: , [15799,15800]
operator: , [15799,15800]
===
match
---
name: DummyOperator [37052,37065]
name: DummyOperator [37052,37065]
===
match
---
simple_stmt [45153,45180]
simple_stmt [45153,45180]
===
match
---
name: dag [45176,45179]
name: dag [45176,45179]
===
match
---
number: 0 [55429,55430]
number: 0 [57377,57378]
===
match
---
argument [50753,50771]
argument [50753,50771]
===
match
---
operator: , [17741,17742]
operator: , [17741,17742]
===
match
---
name: filter [51566,51572]
name: filter [51566,51572]
===
match
---
comparison [3361,3375]
comparison [3361,3375]
===
match
---
operator: , [25761,25762]
operator: , [25761,25762]
===
match
---
operator: = [47328,47329]
operator: = [47328,47329]
===
match
---
argument [57361,57374]
argument [59309,59322]
===
match
---
name: session [18231,18238]
name: session [18231,18238]
===
match
---
operator: , [28973,28974]
operator: , [28973,28974]
===
match
---
operator: = [51421,51422]
operator: = [51421,51422]
===
match
---
trailer [49881,49889]
trailer [49881,49889]
===
match
---
simple_stmt [50094,50156]
simple_stmt [50094,50156]
===
match
---
name: owner [23803,23808]
name: owner [23803,23808]
===
match
---
argument [41373,41402]
argument [41373,41402]
===
match
---
trailer [19045,19053]
trailer [19045,19053]
===
match
---
for_stmt [14661,14756]
for_stmt [14661,14756]
===
match
---
expr_stmt [14988,15038]
expr_stmt [14988,15038]
===
match
---
comparison [37196,37231]
comparison [37196,37231]
===
match
---
name: pipeline [14678,14686]
name: pipeline [14678,14686]
===
match
---
name: dag_id [25882,25888]
name: dag_id [25882,25888]
===
match
---
param [37305,37309]
param [37305,37309]
===
match
---
trailer [39625,39640]
trailer [39625,39640]
===
match
---
name: execution_date [17189,17203]
name: execution_date [17189,17203]
===
match
---
trailer [31571,31573]
trailer [31571,31573]
===
match
---
simple_stmt [6408,6431]
simple_stmt [6408,6431]
===
match
---
argument [35255,35278]
argument [35255,35278]
===
match
---
string: 'Europe/Zurich' [22533,22548]
string: 'Europe/Zurich' [22533,22548]
===
match
---
atom [12953,13042]
atom [12953,13042]
===
match
---
atom_expr [34469,34532]
atom_expr [34469,34532]
===
match
---
trailer [62852,62858]
trailer [64800,64806]
===
match
---
argument [21630,21646]
argument [21630,21646]
===
match
---
name: query [24366,24371]
name: query [24366,24371]
===
match
---
trailer [58317,58326]
trailer [60265,60274]
===
match
---
trailer [60219,60375]
trailer [62167,62323]
===
match
---
expr_stmt [48571,48609]
expr_stmt [48571,48609]
===
match
---
trailer [17490,17495]
trailer [17490,17495]
===
match
---
name: ACTION_CAN_EDIT [61798,61813]
name: ACTION_CAN_EDIT [63746,63761]
===
match
---
number: 2019 [60630,60634]
number: 2019 [62578,62582]
===
match
---
simple_stmt [18555,18652]
simple_stmt [18555,18652]
===
match
---
atom_expr [4470,4480]
atom_expr [4470,4480]
===
match
---
assert_stmt [9367,9400]
assert_stmt [9367,9400]
===
match
---
name: dag [65844,65847]
name: dag [67792,67795]
===
match
---
simple_stmt [8262,8330]
simple_stmt [8262,8330]
===
match
---
funcdef [13788,15162]
funcdef [13788,15162]
===
match
---
name: DAG [1457,1460]
name: DAG [1457,1460]
===
match
---
operator: = [43243,43244]
operator: = [43243,43244]
===
match
---
name: dag_eq [44978,44984]
name: dag_eq [44978,44984]
===
match
---
name: run [67658,67661]
name: run [69606,69609]
===
match
---
operator: , [57753,57754]
operator: , [59701,59702]
===
match
---
name: state [50753,50758]
name: state [50753,50758]
===
match
---
simple_stmt [12525,12535]
simple_stmt [12525,12535]
===
match
---
operator: , [22605,22606]
operator: , [22605,22606]
===
match
---
name: task_instance_1 [52447,52462]
name: task_instance_1 [54395,54410]
===
match
---
comparison [3803,3823]
comparison [3803,3823]
===
match
---
simple_stmt [13426,13462]
simple_stmt [13426,13462]
===
match
---
funcdef [68945,69195]
funcdef [70893,71143]
===
match
---
name: settings [27622,27630]
name: settings [27622,27630]
===
match
---
operator: = [39000,39001]
operator: = [39000,39001]
===
match
---
assert_stmt [32403,32500]
assert_stmt [32403,32500]
===
match
---
operator: , [15406,15407]
operator: , [15406,15407]
===
match
---
trailer [28218,28224]
trailer [28218,28224]
===
match
---
name: t [24346,24347]
name: t [24346,24347]
===
match
---
name: correct_weight [16347,16361]
name: correct_weight [16347,16361]
===
match
---
name: prev [22206,22210]
name: prev [22206,22210]
===
match
---
assert_stmt [28262,28300]
assert_stmt [28262,28300]
===
match
---
name: DEFAULT_DATE [16497,16509]
name: DEFAULT_DATE [16497,16509]
===
match
---
name: dag_id [47785,47791]
name: dag_id [47785,47791]
===
match
---
simple_stmt [29844,29955]
simple_stmt [29844,29955]
===
match
---
operator: = [15420,15421]
operator: = [15420,15421]
===
match
---
name: op3 [36343,36346]
name: op3 [36343,36346]
===
match
---
name: state [49126,49131]
name: state [49126,49131]
===
match
---
name: priority_weight_total [16281,16302]
name: priority_weight_total [16281,16302]
===
match
---
name: TypeError [66890,66899]
name: TypeError [68838,68847]
===
match
---
param [15222,15226]
param [15222,15226]
===
match
---
assert_stmt [25922,26396]
assert_stmt [25922,26396]
===
match
---
assert_stmt [32012,32110]
assert_stmt [32012,32110]
===
match
---
name: timezone [22667,22675]
name: timezone [22667,22675]
===
match
---
operator: , [67502,67503]
operator: , [69450,69451]
===
match
---
simple_stmt [7101,7136]
simple_stmt [7101,7136]
===
match
---
comparison [35582,35610]
comparison [35582,35610]
===
match
---
operator: = [37908,37909]
operator: = [37908,37909]
===
match
---
argument [46636,46642]
argument [46636,46642]
===
match
---
name: airflow [1720,1727]
name: airflow [1720,1727]
===
match
---
assert_stmt [29244,29268]
assert_stmt [29244,29268]
===
match
---
name: tasks [9153,9158]
name: tasks [9153,9158]
===
match
---
operator: = [39051,39052]
operator: = [39051,39052]
===
match
---
comparison [39518,39553]
comparison [39518,39553]
===
match
---
trailer [27431,27504]
trailer [27431,27504]
===
match
---
simple_stmt [45989,46006]
simple_stmt [45989,46006]
===
match
---
name: tags [24190,24194]
name: tags [24190,24194]
===
match
---
trailer [23122,23124]
trailer [23122,23124]
===
match
---
assert_stmt [20460,20554]
assert_stmt [20460,20554]
===
match
---
trailer [31737,31751]
trailer [31737,31751]
===
match
---
name: name [35127,35131]
name: name [35127,35131]
===
match
---
operator: { [35600,35601]
operator: { [35600,35601]
===
match
---
trailer [33122,33164]
trailer [33122,33164]
===
match
---
name: test_create_dagrun_run_id_is_generated [47433,47471]
name: test_create_dagrun_run_id_is_generated [47433,47471]
===
match
---
name: one [33618,33621]
name: one [33618,33621]
===
match
---
return_stmt [18523,18545]
return_stmt [18523,18545]
===
match
---
name: airflow [1948,1955]
name: airflow [1948,1955]
===
match
---
name: sync_to_db [32730,32740]
name: sync_to_db [32730,32740]
===
match
---
operator: = [40052,40053]
operator: = [40052,40053]
===
match
---
name: ti2 [17039,17042]
name: ti2 [17039,17042]
===
match
---
name: dag [27691,27694]
name: dag [27691,27694]
===
match
---
atom_expr [35306,35333]
atom_expr [35306,35333]
===
match
---
arglist [28682,28737]
arglist [28682,28737]
===
match
---
name: mock_stats [39869,39879]
name: mock_stats [39869,39879]
===
match
---
argument [41167,41180]
argument [41167,41180]
===
match
---
trailer [41921,41935]
trailer [41921,41935]
===
match
---
comp_op [29305,29311]
comp_op [29305,29311]
===
match
---
argument [37969,37981]
argument [37969,37981]
===
match
---
name: is_subdag [61106,61115]
name: is_subdag [63054,63063]
===
match
---
trailer [29758,29766]
trailer [29758,29766]
===
match
---
name: datetime [20387,20395]
name: datetime [20387,20395]
===
match
---
trailer [12837,12903]
trailer [12837,12903]
===
match
---
name: assert_queries_count [25453,25473]
name: assert_queries_count [25453,25473]
===
match
---
trailer [17296,17370]
trailer [17296,17370]
===
match
---
expr_stmt [22785,22818]
expr_stmt [22785,22818]
===
match
---
arglist [47859,47897]
arglist [47859,47897]
===
match
---
operator: , [15381,15382]
operator: , [15381,15382]
===
match
---
simple_stmt [42350,42440]
simple_stmt [42350,42440]
===
match
---
operator: , [48457,48458]
operator: , [48457,48458]
===
match
---
with_stmt [37877,38075]
with_stmt [37877,38075]
===
match
---
argument [7427,7450]
argument [7427,7450]
===
match
---
name: dr [68361,68363]
name: dr [70309,70311]
===
match
---
atom_expr [25655,25681]
atom_expr [25655,25681]
===
match
---
atom_expr [65220,65237]
atom_expr [67168,67185]
===
match
---
name: baseoperator [1537,1549]
name: baseoperator [1537,1549]
===
match
---
name: subdag [61269,61275]
name: subdag [63217,63223]
===
match
---
atom_expr [51779,51792]
atom_expr [53727,53740]
===
match
---
string: "owner" [64698,64705]
string: "owner" [66646,66653]
===
match
---
testlist_comp [36012,36020]
testlist_comp [36012,36020]
===
match
---
name: Optional [51919,51927]
name: Optional [53867,53875]
===
match
---
atom_expr [19310,19330]
atom_expr [19310,19330]
===
match
---
sync_comp_for [24591,24611]
sync_comp_for [24591,24611]
===
match
---
comparison [54347,54363]
comparison [56295,56311]
===
match
---
argument [64497,64529]
argument [66445,66477]
===
match
---
name: run_type [28058,28066]
name: run_type [28058,28066]
===
match
---
trailer [43592,43608]
trailer [43592,43608]
===
match
---
name: timezone [58543,58551]
name: timezone [60491,60499]
===
match
---
arglist [17173,17245]
arglist [17173,17245]
===
match
---
string: 'fakename' [17637,17647]
string: 'fakename' [17637,17647]
===
match
---
decorator [68890,68937]
decorator [70838,70885]
===
match
---
string: """Verify if dag.roots returns the root tasks of a DAG.""" [35167,35225]
string: """Verify if dag.roots returns the root tasks of a DAG.""" [35167,35225]
===
match
---
simple_stmt [66357,66383]
simple_stmt [68305,68331]
===
match
---
name: RUNNING [40525,40532]
name: RUNNING [40525,40532]
===
match
---
name: dag_id [51580,51586]
name: dag_id [51580,51586]
===
match
---
name: dag_id [32425,32431]
name: dag_id [32425,32431]
===
match
---
atom_expr [2694,2709]
atom_expr [2694,2709]
===
match
---
name: datetime [17343,17351]
name: datetime [17343,17351]
===
match
---
trailer [24267,24269]
trailer [24267,24269]
===
match
---
import_from [1570,1621]
import_from [1570,1621]
===
match
---
assert_stmt [65862,65896]
assert_stmt [67810,67844]
===
match
---
name: DAG [27428,27431]
name: DAG [27428,27431]
===
match
---
name: start_date [50249,50259]
name: start_date [50249,50259]
===
match
---
atom_expr [37882,37922]
atom_expr [37882,37922]
===
match
---
name: DummyOperator [55085,55098]
name: DummyOperator [57033,57046]
===
match
---
fstring_start: f" [47213,47215]
fstring_start: f" [47213,47215]
===
match
---
atom_expr [50469,50653]
atom_expr [50469,50653]
===
match
---
suite [59909,61407]
suite [61857,63355]
===
match
---
trailer [49051,49061]
trailer [49051,49061]
===
match
---
atom_expr [31676,31694]
atom_expr [31676,31694]
===
match
---
atom_expr [2881,2894]
atom_expr [2881,2894]
===
match
---
name: test_bulk_write_to_db_max_active_runs [27205,27242]
name: test_bulk_write_to_db_max_active_runs [27205,27242]
===
match
---
argument [7895,7914]
argument [7895,7914]
===
match
---
operator: , [40443,40444]
operator: , [40443,40444]
===
match
---
name: a_index [3274,3281]
name: a_index [3274,3281]
===
match
---
trailer [32153,32167]
trailer [32153,32167]
===
match
---
operator: , [61646,61647]
operator: , [63594,63595]
===
match
---
name: DEPRECATED_ACTION_CAN_DAG_READ [61616,61646]
name: DEPRECATED_ACTION_CAN_DAG_READ [63564,63594]
===
match
---
name: test_get_paused_dag_ids [45851,45874]
name: test_get_paused_dag_ids [45851,45874]
===
match
---
expr_stmt [28487,28563]
expr_stmt [28487,28563]
===
match
---
name: DagRunType [47567,47577]
name: DagRunType [47567,47577]
===
match
---
name: utcnow [55310,55316]
name: utcnow [57258,57264]
===
match
---
string: "STORE_DAG_CODE" [2566,2582]
string: "STORE_DAG_CODE" [2566,2582]
===
match
---
string: "test_schedule_interval" [46806,46830]
string: "test_schedule_interval" [46806,46830]
===
match
---
trailer [32942,32995]
trailer [32942,32995]
===
match
---
simple_stmt [40079,40132]
simple_stmt [40079,40132]
===
match
---
simple_stmt [5995,6073]
simple_stmt [5995,6073]
===
match
---
operator: { [12983,12984]
operator: { [12983,12984]
===
match
---
atom_expr [13491,13510]
atom_expr [13491,13510]
===
match
---
string: '.test' [50240,50247]
string: '.test' [50240,50247]
===
match
---
name: State [50552,50557]
name: State [50552,50557]
===
match
---
operator: - [53862,53863]
operator: - [55810,55811]
===
match
---
name: session [17751,17758]
name: session [17751,17758]
===
match
---
simple_stmt [5598,5665]
simple_stmt [5598,5665]
===
match
---
operator: = [53038,53039]
operator: = [54986,54987]
===
match
---
operator: == [20131,20133]
operator: == [20131,20133]
===
match
---
name: RUNNING [39313,39320]
name: RUNNING [39313,39320]
===
match
---
expr_stmt [38562,38638]
expr_stmt [38562,38638]
===
match
---
trailer [44057,44064]
trailer [44057,44064]
===
match
---
argument [23822,23842]
argument [23822,23842]
===
match
---
comparison [36694,36717]
comparison [36694,36717]
===
match
---
name: timezone [56878,56886]
name: timezone [58826,58834]
===
match
---
operator: == [63712,63714]
operator: == [65660,65662]
===
match
---
name: dag [45401,45404]
name: dag [45401,45404]
===
match
---
name: orm_dag [29421,29428]
name: orm_dag [29421,29428]
===
match
---
import_from [1943,2008]
import_from [1943,2008]
===
match
---
name: return_num [68198,68208]
name: return_num [70146,70156]
===
match
---
arglist [18572,18650]
arglist [18572,18650]
===
match
---
expr_stmt [50458,50653]
expr_stmt [50458,50653]
===
match
---
testlist_comp [32425,32437]
testlist_comp [32425,32437]
===
match
---
atom_expr [54049,54102]
atom_expr [55997,56050]
===
match
---
atom_expr [40669,40711]
atom_expr [40669,40711]
===
match
---
operator: , [29376,29377]
operator: , [29376,29377]
===
match
---
trailer [14842,14856]
trailer [14842,14856]
===
match
---
name: range [64316,64321]
name: range [66264,66269]
===
match
---
name: task_id [38208,38215]
name: task_id [38208,38215]
===
match
---
simple_stmt [30529,30545]
simple_stmt [30529,30545]
===
match
---
atom [24577,24589]
atom [24577,24589]
===
match
---
atom_expr [11731,11761]
atom_expr [11731,11761]
===
match
---
name: delta [41052,41057]
name: delta [41052,41057]
===
match
---
trailer [52223,52237]
trailer [54171,54185]
===
match
---
name: write [19606,19611]
name: write [19606,19611]
===
match
---
name: self [44120,44124]
name: self [44120,44124]
===
match
---
argument [50500,50532]
argument [50500,50532]
===
match
---
operator: , [24974,24975]
operator: , [24974,24975]
===
match
---
number: 1 [27535,27536]
number: 1 [27535,27536]
===
match
---
comparison [41865,41935]
comparison [41865,41935]
===
match
---
name: execution_date [16977,16991]
name: execution_date [16977,16991]
===
match
---
name: TestCase [63963,63971]
name: TestCase [65911,65919]
===
match
---
trailer [67349,67358]
trailer [69297,69306]
===
match
---
fstring_string: test [47215,47219]
fstring_string: test [47215,47219]
===
match
---
trailer [63448,63459]
trailer [65396,65407]
===
match
---
arglist [40163,40353]
arglist [40163,40353]
===
match
---
argument [67104,67134]
argument [69052,69082]
===
match
---
simple_stmt [13677,13724]
simple_stmt [13677,13724]
===
match
---
operator: , [58780,58781]
operator: , [60728,60729]
===
match
---
simple_stmt [28869,28893]
simple_stmt [28869,28893]
===
match
---
name: DummyOperator [6370,6383]
name: DummyOperator [6370,6383]
===
match
---
operator: = [35877,35878]
operator: = [35877,35878]
===
match
---
atom_expr [5649,5664]
atom_expr [5649,5664]
===
match
---
name: session [25157,25164]
name: session [25157,25164]
===
match
---
name: DagModel [27120,27128]
name: DagModel [27120,27128]
===
match
---
operator: = [19926,19927]
operator: = [19926,19927]
===
match
---
operator: } [4228,4229]
operator: } [4228,4229]
===
match
---
operator: = [23701,23702]
operator: = [23701,23702]
===
match
---
atom [10134,10144]
atom [10134,10144]
===
match
---
operator: = [18352,18353]
operator: = [18352,18353]
===
match
---
operator: , [60724,60725]
operator: , [62672,62673]
===
match
---
trailer [25274,25276]
trailer [25274,25276]
===
match
---
classdef [63936,64624]
classdef [65884,66572]
===
match
---
name: max_active_runs [52074,52089]
name: max_active_runs [54022,54037]
===
match
---
name: session [48797,48804]
name: session [48797,48804]
===
match
---
arglist [58026,58216]
arglist [59974,60164]
===
match
---
expr_stmt [46072,46126]
expr_stmt [46072,46126]
===
match
---
assert_stmt [32841,32871]
assert_stmt [32841,32871]
===
match
---
expr_stmt [61476,61702]
expr_stmt [63424,63650]
===
match
---
name: start_date [58100,58110]
name: start_date [60048,60058]
===
match
---
string: "scheduled__" [47866,47879]
string: "scheduled__" [47866,47879]
===
match
---
operator: == [21030,21032]
operator: == [21030,21032]
===
match
---
string: 'DAG' [34945,34950]
string: 'DAG' [34945,34950]
===
match
---
name: default_args [65611,65623]
name: default_args [67559,67571]
===
match
---
operator: , [31948,31949]
operator: , [31948,31949]
===
match
---
simple_stmt [27422,27505]
simple_stmt [27422,27505]
===
match
---
string: "t3" [35420,35424]
string: "t3" [35420,35424]
===
match
---
name: utc [21939,21942]
name: utc [21939,21942]
===
match
---
name: test_default_dag_id [65493,65512]
name: test_default_dag_id [67441,67460]
===
match
---
atom_expr [52569,52599]
atom_expr [54517,54547]
===
match
---
atom [64134,64138]
atom [66082,66086]
===
match
---
name: task_id [55154,55161]
name: task_id [57102,57109]
===
match
---
trailer [47650,47657]
trailer [47650,47657]
===
match
---
name: start_date [19785,19795]
name: start_date [19785,19795]
===
match
---
string: 'child_dag' [7903,7914]
string: 'child_dag' [7903,7914]
===
match
---
name: mock [40054,40058]
name: mock [40054,40058]
===
match
---
trailer [50953,51008]
trailer [50953,51008]
===
match
---
name: topological_list [10430,10446]
name: topological_list [10430,10446]
===
match
---
name: set_upstream [8919,8931]
name: set_upstream [8919,8931]
===
match
---
name: self [66613,66617]
name: self [68561,68565]
===
match
---
string: 'dag_default_view_old' [33449,33471]
string: 'dag_default_view_old' [33449,33471]
===
match
---
name: DAG [12089,12092]
name: DAG [12089,12092]
===
match
---
name: filter [52887,52893]
name: filter [54835,54841]
===
match
---
param [39869,39879]
param [39869,39879]
===
match
---
name: template_file [19284,19297]
name: template_file [19284,19297]
===
match
---
name: dag_id [61977,61983]
name: dag_id [63925,63931]
===
match
---
operator: , [17311,17312]
operator: , [17311,17312]
===
match
---
simple_stmt [43710,43785]
simple_stmt [43710,43785]
===
match
---
string: "t5" [35512,35516]
string: "t5" [35512,35516]
===
match
---
name: subdag [30654,30660]
name: subdag [30654,30660]
===
match
---
operator: = [21075,21076]
operator: = [21075,21076]
===
match
---
string: "faketastic" [39114,39126]
string: "faketastic" [39114,39126]
===
match
---
expr_stmt [18555,18651]
expr_stmt [18555,18651]
===
match
---
name: raises [36878,36884]
name: raises [36878,36884]
===
match
---
dotted_name [1770,1794]
dotted_name [1770,1794]
===
match
---
operator: = [69208,69209]
operator: = [71156,71157]
===
match
---
name: state [17259,17264]
name: state [17259,17264]
===
match
---
parameters [35151,35157]
parameters [35151,35157]
===
match
---
name: settings [34123,34131]
name: settings [34123,34131]
===
match
---
name: task_id [35366,35373]
name: task_id [35366,35373]
===
match
---
expr_stmt [29014,29042]
expr_stmt [29014,29042]
===
match
---
number: 4 [58785,58786]
number: 4 [60733,60734]
===
match
---
trailer [67648,67657]
trailer [69596,69605]
===
match
---
number: 42 [64923,64925]
number: 42 [66871,66873]
===
match
---
simple_stmt [67768,67804]
simple_stmt [69716,69752]
===
match
---
name: DAG [18568,18571]
name: DAG [18568,18571]
===
match
---
arglist [17048,17120]
arglist [17048,17120]
===
match
---
operator: = [52105,52106]
operator: = [54053,54054]
===
match
---
name: test_get_num_task_instances [16681,16708]
name: test_get_num_task_instances [16681,16708]
===
match
---
atom_expr [27428,27504]
atom_expr [27428,27504]
===
match
---
trailer [31986,31990]
trailer [31986,31990]
===
match
---
argument [17362,17368]
argument [17362,17368]
===
match
---
name: start_date [37515,37525]
name: start_date [37515,37525]
===
match
---
trailer [33754,33760]
trailer [33754,33760]
===
match
---
trailer [12119,12128]
trailer [12119,12128]
===
match
---
trailer [49045,49051]
trailer [49045,49051]
===
match
---
name: sync_to_db [31344,31354]
name: sync_to_db [31344,31354]
===
match
---
assert_stmt [27882,27933]
assert_stmt [27882,27933]
===
match
---
arglist [55412,55445]
arglist [57360,57393]
===
match
---
operator: , [68753,68754]
operator: , [70701,70702]
===
match
---
name: dag_id [28244,28250]
name: dag_id [28244,28250]
===
match
---
string: 'dag-bulk-sync-3' [26294,26311]
string: 'dag-bulk-sync-3' [26294,26311]
===
match
---
dictorsetmaker [10662,10679]
dictorsetmaker [10662,10679]
===
match
---
name: run_id [39434,39440]
name: run_id [39434,39440]
===
match
---
atom_expr [5323,5391]
atom_expr [5323,5391]
===
match
---
name: owner [6246,6251]
name: owner [6246,6251]
===
match
---
name: one [30420,30423]
name: one [30420,30423]
===
match
---
argument [16848,16871]
argument [16848,16871]
===
match
---
atom [32329,32348]
atom [32329,32348]
===
match
---
name: create_dagrun [39193,39206]
name: create_dagrun [39193,39206]
===
match
---
term [13611,13645]
term [13611,13645]
===
match
---
name: subdag_id [31254,31263]
name: subdag_id [31254,31263]
===
match
---
simple_stmt [12543,12554]
simple_stmt [12543,12554]
===
match
---
name: datetime [20378,20386]
name: datetime [20378,20386]
===
match
---
atom_expr [36570,36588]
atom_expr [36570,36588]
===
match
---
name: external_trigger [39716,39732]
name: external_trigger [39716,39732]
===
match
---
trailer [50472,50486]
trailer [50472,50486]
===
match
---
name: session [52569,52576]
name: session [54517,54524]
===
match
---
name: session [63767,63774]
name: session [65715,65722]
===
match
---
name: filter [2874,2880]
name: filter [2874,2880]
===
match
---
trailer [5234,5309]
trailer [5234,5309]
===
match
---
name: DagModel [31918,31926]
name: DagModel [31918,31926]
===
match
---
operator: = [20918,20919]
operator: = [20918,20919]
===
match
---
name: pendulum [22515,22523]
name: pendulum [22515,22523]
===
match
---
atom_expr [25841,25847]
atom_expr [25841,25847]
===
match
---
name: dag [42221,42224]
name: dag [42221,42224]
===
match
---
name: DAG [64243,64246]
name: DAG [66191,66194]
===
match
---
expr_stmt [10606,10681]
expr_stmt [10606,10681]
===
match
---
operator: , [12019,12020]
operator: , [12019,12020]
===
match
---
operator: , [23720,23721]
operator: , [23720,23721]
===
match
---
trailer [39715,39732]
trailer [39715,39732]
===
match
---
argument [16961,16975]
argument [16961,16975]
===
match
---
atom_expr [42818,42828]
atom_expr [42818,42828]
===
match
---
param [2784,2795]
param [2784,2795]
===
match
---
argument [58100,58140]
argument [60048,60088]
===
match
---
name: dagrun_1 [49052,49060]
name: dagrun_1 [49052,49060]
===
match
---
operator: = [7128,7129]
operator: = [7128,7129]
===
match
---
simple_stmt [54229,54269]
simple_stmt [56177,56217]
===
match
---
operator: , [48908,48909]
operator: , [48908,48909]
===
match
---
name: logging [9037,9044]
name: logging [9037,9044]
===
match
---
name: dag [46796,46799]
name: dag [46796,46799]
===
match
---
operator: } [61813,61814]
operator: } [63761,63762]
===
match
---
atom_expr [51289,51315]
atom_expr [51289,51315]
===
match
---
number: 4 [10528,10529]
number: 4 [10528,10529]
===
match
---
operator: , [7668,7669]
operator: , [7668,7669]
===
match
---
string: 'dag' [28510,28515]
string: 'dag' [28510,28515]
===
match
---
name: DAG [47493,47496]
name: DAG [47493,47496]
===
match
---
name: dag [32664,32667]
name: dag [32664,32667]
===
match
---
comparison [36651,36674]
comparison [36651,36674]
===
match
---
argument [50347,50354]
argument [50347,50354]
===
match
---
name: dag [45688,45691]
name: dag [45688,45691]
===
match
---
trailer [31241,31248]
trailer [31241,31248]
===
match
---
string: """Verify tasks with Duplicate task_id raises error""" [36803,36857]
string: """Verify tasks with Duplicate task_id raises error""" [36803,36857]
===
match
---
simple_stmt [47959,48034]
simple_stmt [47959,48034]
===
match
---
operator: = [48676,48677]
operator: = [48676,48677]
===
match
---
trailer [42495,42506]
trailer [42495,42506]
===
match
---
operator: = [67339,67340]
operator: = [69287,69288]
===
match
---
atom_expr [64348,64411]
atom_expr [66296,66359]
===
match
---
suite [68098,68126]
suite [70046,70074]
===
match
---
name: AirflowException [16577,16593]
name: AirflowException [16577,16593]
===
match
---
name: BaseOperator [39093,39105]
name: BaseOperator [39093,39105]
===
match
---
trailer [30293,30301]
trailer [30293,30301]
===
match
---
atom_expr [19726,19750]
atom_expr [19726,19750]
===
match
---
trailer [54209,54215]
trailer [56157,56163]
===
match
---
string: '@once' [43194,43201]
string: '@once' [43194,43201]
===
match
---
simple_stmt [59371,59416]
simple_stmt [61319,61364]
===
match
---
expr_stmt [50164,50209]
expr_stmt [50164,50209]
===
match
---
operator: , [6184,6185]
operator: , [6184,6185]
===
match
---
name: State [48305,48310]
name: State [48305,48310]
===
match
---
operator: { [26704,26705]
operator: { [26704,26705]
===
match
---
name: filter [34246,34252]
name: filter [34246,34252]
===
match
---
name: set [27029,27032]
name: set [27029,27032]
===
match
---
suite [5442,5665]
suite [5442,5665]
===
match
---
atom_expr [65773,65786]
atom_expr [67721,67734]
===
match
---
arglist [37572,37593]
arglist [37572,37593]
===
match
---
name: dag [39189,39192]
name: dag [39189,39192]
===
match
---
suite [10775,10838]
suite [10775,10838]
===
match
---
name: dag1 [55587,55591]
name: dag1 [57535,57539]
===
match
---
trailer [26590,26592]
trailer [26590,26592]
===
match
---
simple_stmt [16724,16772]
simple_stmt [16724,16772]
===
match
---
atom_expr [64881,64910]
atom_expr [66829,66858]
===
match
---
string: "test_dag" [37886,37896]
string: "test_dag" [37886,37896]
===
match
---
name: start_date [43309,43319]
name: start_date [43309,43319]
===
match
---
name: next_date [53462,53471]
name: next_date [55410,55419]
===
match
---
arglist [44363,44393]
arglist [44363,44393]
===
match
---
name: dag [44861,44864]
name: dag [44861,44864]
===
match
---
arglist [36885,36961]
arglist [36885,36961]
===
match
---
operator: = [24175,24176]
operator: = [24175,24176]
===
match
---
argument [67692,67718]
argument [69640,69666]
===
match
---
name: convert [22849,22856]
name: convert [22849,22856]
===
match
---
trailer [14847,14855]
trailer [14847,14855]
===
match
---
operator: = [50551,50552]
operator: = [50551,50552]
===
match
---
name: orm_dag [29332,29339]
name: orm_dag [29332,29339]
===
match
---
name: leaves [36071,36077]
name: leaves [36071,36077]
===
match
---
name: pattern [12562,12569]
name: pattern [12562,12569]
===
match
---
trailer [12011,12023]
trailer [12011,12023]
===
match
---
expr_stmt [7101,7135]
expr_stmt [7101,7135]
===
match
---
operator: = [30283,30284]
operator: = [30283,30284]
===
match
---
trailer [18303,18415]
trailer [18303,18415]
===
match
---
arglist [18317,18405]
arglist [18317,18405]
===
match
---
name: dag_id [43808,43814]
name: dag_id [43808,43814]
===
match
---
atom_expr [32599,32615]
atom_expr [32599,32615]
===
match
---
suite [65328,65356]
suite [67276,67304]
===
match
---
argument [50112,50135]
argument [50112,50135]
===
match
---
argument [59627,59658]
argument [61575,61606]
===
match
---
trailer [44565,44597]
trailer [44565,44597]
===
match
---
name: op1 [37214,37217]
name: op1 [37214,37217]
===
match
---
atom [31643,31661]
atom [31643,31661]
===
match
---
trailer [25198,25202]
trailer [25198,25202]
===
match
---
funcdef [54654,55286]
funcdef [56602,57234]
===
match
---
suite [4712,4796]
suite [4712,4796]
===
match
---
expr_stmt [54849,55065]
expr_stmt [56797,57013]
===
match
---
name: pytest [36871,36877]
name: pytest [36871,36877]
===
match
---
name: DummyOperator [35490,35503]
name: DummyOperator [35490,35503]
===
match
---
simple_stmt [52532,52561]
simple_stmt [54480,54509]
===
match
---
trailer [46288,46315]
trailer [46288,46315]
===
match
---
dictorsetmaker [24302,24318]
dictorsetmaker [24302,24318]
===
match
---
arglist [41167,41230]
arglist [41167,41230]
===
match
---
operator: = [38408,38409]
operator: = [38408,38409]
===
match
---
name: redirect_stdout [36425,36440]
name: redirect_stdout [36425,36440]
===
match
---
simple_stmt [65946,66011]
simple_stmt [67894,67959]
===
match
---
name: dag [43210,43213]
name: dag [43210,43213]
===
match
---
name: get_num_task_instances [17691,17713]
name: get_num_task_instances [17691,17713]
===
match
---
atom_expr [55810,55843]
atom_expr [57758,57791]
===
match
---
operator: , [26212,26213]
operator: , [26212,26213]
===
match
---
name: self [11033,11037]
name: self [11033,11037]
===
match
---
operator: = [19222,19223]
operator: = [19222,19223]
===
match
---
atom_expr [20746,20769]
atom_expr [20746,20769]
===
match
---
simple_stmt [4444,4481]
simple_stmt [4444,4481]
===
match
---
operator: , [49889,49890]
operator: , [49889,49890]
===
match
---
arglist [58129,58139]
arglist [60077,60087]
===
match
---
trailer [46116,46126]
trailer [46116,46126]
===
match
---
operator: = [34220,34221]
operator: = [34220,34221]
===
match
---
argument [7513,7530]
argument [7513,7530]
===
match
---
with_item [37882,37929]
with_item [37882,37929]
===
match
---
name: mock [34105,34109]
name: mock [34105,34109]
===
match
---
trailer [2873,2880]
trailer [2873,2880]
===
match
---
operator: , [57493,57494]
operator: , [59441,59442]
===
match
---
name: _clean_up [2774,2783]
name: _clean_up [2774,2783]
===
match
---
operator: == [48061,48063]
operator: == [48061,48063]
===
match
---
operator: == [57680,57682]
operator: == [59628,59630]
===
match
---
trailer [11878,11885]
trailer [11878,11885]
===
match
---
comparison [37689,37724]
comparison [37689,37724]
===
match
---
name: execution_date [50615,50629]
name: execution_date [50615,50629]
===
match
---
operator: == [54390,54392]
operator: == [56338,56340]
===
match
---
name: op5 [35557,35560]
name: op5 [35557,35560]
===
match
---
string: 'b_child' [8301,8310]
string: 'b_child' [8301,8310]
===
match
---
name: start_date [43403,43413]
name: start_date [43403,43413]
===
match
---
param [51883,51888]
param [53831,53836]
===
match
---
atom_expr [32142,32152]
atom_expr [32142,32152]
===
match
---
atom_expr [35586,35595]
atom_expr [35586,35595]
===
match
---
number: 1 [64905,64906]
number: 1 [66853,66854]
===
match
---
name: test_field [19271,19281]
name: test_field [19271,19281]
===
match
---
assert_stmt [8262,8329]
assert_stmt [8262,8329]
===
match
---
trailer [39663,39671]
trailer [39663,39671]
===
match
---
string: 'webserver' [5021,5032]
string: 'webserver' [5021,5032]
===
match
---
dotted_name [2203,2215]
dotted_name [2203,2215]
===
match
---
name: dag_id [39980,39986]
name: dag_id [39980,39986]
===
match
---
name: extend [10269,10275]
name: extend [10269,10275]
===
match
---
atom_expr [2471,2486]
atom_expr [2471,2486]
===
match
---
expr_stmt [7822,7861]
expr_stmt [7822,7861]
===
match
---
operator: , [50957,50958]
operator: , [50957,50958]
===
match
---
name: task_id [8800,8807]
name: task_id [8800,8807]
===
match
---
string: 'child_dag' [8147,8158]
string: 'child_dag' [8147,8158]
===
match
---
suite [65671,65787]
suite [67619,67735]
===
match
---
name: dag_run [39347,39354]
name: dag_run [39347,39354]
===
match
---
trailer [43146,43161]
trailer [43146,43161]
===
match
---
param [48541,48546]
param [48541,48546]
===
match
---
name: DAG [6758,6761]
name: DAG [6758,6761]
===
match
---
atom_expr [63582,63602]
atom_expr [65530,65550]
===
match
---
operator: } [25908,25909]
operator: } [25908,25909]
===
match
---
trailer [21098,21105]
trailer [21098,21105]
===
match
---
operator: = [47839,47840]
operator: = [47839,47840]
===
match
---
trailer [30386,30393]
trailer [30386,30393]
===
match
---
name: dag_id [27756,27762]
name: dag_id [27756,27762]
===
match
---
operator: = [55481,55482]
operator: = [57429,57430]
===
match
---
funcdef [3829,4481]
funcdef [3829,4481]
===
match
---
operator: = [59723,59724]
operator: = [61671,61672]
===
match
---
trailer [20619,20680]
trailer [20619,20680]
===
match
---
string: 'task' [30007,30013]
string: 'task' [30007,30013]
===
match
---
number: 0 [53055,53056]
number: 0 [55003,55004]
===
match
---
trailer [68699,68718]
trailer [70647,70666]
===
match
---
atom_expr [17391,17404]
atom_expr [17391,17404]
===
match
---
atom_expr [48472,48485]
atom_expr [48472,48485]
===
match
---
atom_expr [36063,36078]
atom_expr [36063,36078]
===
match
---
simple_stmt [55295,55319]
simple_stmt [57243,57267]
===
match
---
name: dag_id [2990,2996]
name: dag_id [2990,2996]
===
match
---
name: test_next_dagrun_after_date_start_end_dates [53554,53597]
name: test_next_dagrun_after_date_start_end_dates [55502,55545]
===
match
---
simple_stmt [48358,48394]
simple_stmt [48358,48394]
===
match
---
number: 5 [26520,26521]
number: 5 [26520,26521]
===
match
---
trailer [16015,16022]
trailer [16015,16022]
===
match
---
atom_expr [7017,7045]
atom_expr [7017,7045]
===
match
---
trailer [27180,27183]
trailer [27180,27183]
===
match
---
name: timezone [61205,61213]
name: timezone [63153,63161]
===
match
---
simple_stmt [20108,20162]
simple_stmt [20108,20162]
===
match
---
operator: = [55299,55300]
operator: = [57247,57248]
===
match
---
argument [35412,35424]
argument [35412,35424]
===
match
---
name: i [13166,13167]
name: i [13166,13167]
===
match
---
expr_stmt [12083,12141]
expr_stmt [12083,12141]
===
match
---
operator: = [19379,19380]
operator: = [19379,19380]
===
match
---
trailer [32613,32615]
trailer [32613,32615]
===
match
---
argument [29886,29909]
argument [29886,29909]
===
match
---
trailer [39312,39320]
trailer [39312,39320]
===
match
---
name: match [4654,4659]
name: match [4654,4659]
===
match
---
import_name [788,803]
import_name [788,803]
===
match
---
operator: , [3178,3179]
operator: , [3178,3179]
===
match
---
operator: = [54162,54163]
operator: = [56110,56111]
===
match
---
trailer [30666,30737]
trailer [30666,30737]
===
match
---
simple_stmt [35346,35380]
simple_stmt [35346,35380]
===
match
---
name: dag [36067,36070]
name: dag [36067,36070]
===
match
---
operator: , [28736,28737]
operator: , [28736,28737]
===
match
---
number: 1 [53447,53448]
number: 1 [55395,55396]
===
match
---
atom [63715,63724]
atom [65663,65672]
===
match
---
name: noop_pipeline [66079,66092]
name: noop_pipeline [68027,68040]
===
match
---
atom_expr [13697,13723]
atom_expr [13697,13723]
===
match
---
argument [17113,17119]
argument [17113,17119]
===
match
---
suite [61467,62264]
suite [63415,64212]
===
match
---
trailer [31143,31154]
trailer [31143,31154]
===
match
---
expr_stmt [67436,67634]
expr_stmt [69384,69582]
===
match
---
trailer [19270,19281]
trailer [19270,19281]
===
match
---
name: dag_id [47329,47335]
name: dag_id [47329,47335]
===
match
---
fstring_expr [60246,60263]
fstring_expr [62194,62211]
===
match
---
simple_stmt [18960,18981]
simple_stmt [18960,18981]
===
match
---
trailer [19032,19037]
trailer [19032,19037]
===
match
---
operator: , [5032,5033]
operator: , [5032,5033]
===
match
---
name: dag [6874,6877]
name: dag [6874,6877]
===
match
---
name: t_1 [49092,49095]
name: t_1 [49092,49095]
===
match
---
name: timezone [58111,58119]
name: timezone [60059,60067]
===
match
---
atom [29215,29235]
atom [29215,29235]
===
match
---
trailer [20984,20990]
trailer [20984,20990]
===
match
---
argument [44662,44679]
argument [44662,44679]
===
match
---
name: row [27177,27180]
name: row [27177,27180]
===
match
---
name: stage [14634,14639]
name: stage [14634,14639]
===
match
---
argument [4304,4336]
argument [4304,4336]
===
match
---
name: owner [6314,6319]
name: owner [6314,6319]
===
match
---
trailer [15080,15102]
trailer [15080,15102]
===
match
---
atom_expr [28941,29005]
atom_expr [28941,29005]
===
match
---
name: start_date [53972,53982]
name: start_date [55920,55930]
===
match
---
name: name [35024,35028]
name: name [35024,35028]
===
match
---
parameters [44119,44125]
parameters [44119,44125]
===
match
---
string: 'dag_default_view' [33735,33753]
string: 'dag_default_view' [33735,33753]
===
match
---
trailer [17258,17264]
trailer [17258,17264]
===
match
---
operator: = [44303,44304]
operator: = [44303,44304]
===
match
---
operator: } [24827,24828]
operator: } [24827,24828]
===
match
---
name: date [54445,54449]
name: date [56393,56397]
===
match
---
name: hours [41079,41084]
name: hours [41079,41084]
===
match
---
atom [26046,26077]
atom [26046,26077]
===
match
---
name: op2 [55134,55137]
name: op2 [57082,57085]
===
match
---
name: DAG [7599,7602]
name: DAG [7599,7602]
===
match
---
suite [24732,25320]
suite [24732,25320]
===
match
---
operator: , [60587,60588]
operator: , [62535,62536]
===
match
---
simple_stmt [23904,23960]
simple_stmt [23904,23960]
===
match
---
name: test_dag_id [44489,44500]
name: test_dag_id [44489,44500]
===
match
---
name: relativedelta [23665,23678]
name: relativedelta [23665,23678]
===
match
---
name: task_id [39106,39113]
name: task_id [39106,39113]
===
match
---
operator: , [24309,24310]
operator: , [24309,24310]
===
match
---
trailer [2887,2894]
trailer [2887,2894]
===
match
---
name: subdag_id [31939,31948]
name: subdag_id [31939,31948]
===
match
---
funcdef [32877,33319]
funcdef [32877,33319]
===
match
---
argument [60686,60724]
argument [62634,62672]
===
match
---
operator: , [59334,59335]
operator: , [61282,61283]
===
match
---
simple_stmt [27612,27641]
simple_stmt [27612,27641]
===
match
---
string: "sleep 1" [37142,37151]
string: "sleep 1" [37142,37151]
===
match
---
string: """         Tests avoid crashes from calling dag callbacks exceptions         """ [39890,39971]
string: """         Tests avoid crashes from calling dag callbacks exceptions         """ [39890,39971]
===
match
---
trailer [35846,35860]
trailer [35846,35860]
===
match
---
atom [26928,26960]
atom [26928,26960]
===
match
---
name: expected_n_schedule_interval [46921,46949]
name: expected_n_schedule_interval [46921,46949]
===
match
---
simple_stmt [63076,63149]
simple_stmt [65024,65097]
===
match
---
atom_expr [30043,30266]
atom_expr [30043,30266]
===
match
---
operator: = [47538,47539]
operator: = [47538,47539]
===
match
---
argument [17297,17311]
argument [17297,17311]
===
match
---
operator: = [9083,9084]
operator: = [9083,9084]
===
match
---
number: 1 [51313,51314]
number: 1 [51313,51314]
===
match
---
expr_stmt [68187,68215]
expr_stmt [70135,70163]
===
match
---
operator: , [64906,64907]
operator: , [66854,66855]
===
match
---
name: TEST_DATE [40379,40388]
name: TEST_DATE [40379,40388]
===
match
---
name: DEFAULT_DATE [64285,64297]
name: DEFAULT_DATE [66233,66245]
===
match
---
name: self [4841,4845]
name: self [4841,4845]
===
match
---
atom [14144,14492]
atom [14144,14492]
===
match
---
string: 'owner2' [6698,6706]
string: 'owner2' [6698,6706]
===
match
---
name: DEFAULT_DATE [47601,47613]
name: DEFAULT_DATE [47601,47613]
===
match
---
simple_stmt [13593,13660]
simple_stmt [13593,13660]
===
match
---
suite [42998,43816]
suite [42998,43816]
===
match
---
name: dag [11949,11952]
name: dag [11949,11952]
===
match
---
name: DEFAULT_DATE [50589,50601]
name: DEFAULT_DATE [50589,50601]
===
match
---
trailer [14895,14901]
trailer [14895,14901]
===
match
---
comparison [45476,45504]
comparison [45476,45504]
===
match
---
simple_stmt [63220,63277]
simple_stmt [65168,65225]
===
match
---
name: resolve_template_files [20074,20096]
name: resolve_template_files [20074,20096]
===
match
---
name: set1 [10127,10131]
name: set1 [10127,10131]
===
match
---
name: set [25153,25156]
name: set [25153,25156]
===
match
---
string: 'start_date' [10809,10821]
string: 'start_date' [10809,10821]
===
match
---
operator: , [63562,63563]
operator: , [65510,65511]
===
match
---
name: default_args [65207,65219]
name: default_args [67155,67167]
===
match
---
atom_expr [55362,55389]
atom_expr [57310,57337]
===
match
---
atom [26624,26700]
atom [26624,26700]
===
match
---
with_item [24253,24280]
with_item [24253,24280]
===
match
---
expr_stmt [15311,15322]
expr_stmt [15311,15322]
===
match
---
operator: + [51802,51803]
operator: + [53750,53751]
===
match
---
suite [11039,11886]
suite [11039,11886]
===
match
---
name: self [24474,24478]
name: self [24474,24478]
===
match
---
name: clear_db_runs [2341,2354]
name: clear_db_runs [2341,2354]
===
match
---
dotted_name [1048,1061]
dotted_name [1048,1061]
===
match
---
argument [19238,19251]
argument [19238,19251]
===
match
---
comparison [46142,46168]
comparison [46142,46168]
===
match
---
simple_stmt [44539,44598]
simple_stmt [44539,44598]
===
match
---
name: get_default_view [33691,33707]
name: get_default_view [33691,33707]
===
match
---
number: 1 [53297,53298]
number: 1 [55245,55246]
===
match
---
string: 'child_dag' [8288,8299]
string: 'child_dag' [8288,8299]
===
match
---
trailer [10275,10281]
trailer [10275,10281]
===
match
---
operator: , [51315,51316]
operator: , [51315,51316]
===
match
---
name: test_duplicate_task_ids_not_allowed_with_dag_context_manager [36727,36787]
name: test_duplicate_task_ids_not_allowed_with_dag_context_manager [36727,36787]
===
match
---
name: ti4 [17288,17291]
name: ti4 [17288,17291]
===
match
---
trailer [62555,62807]
trailer [64503,64755]
===
match
---
name: all [63684,63687]
name: all [65632,65635]
===
match
---
assert_stmt [29173,29235]
assert_stmt [29173,29235]
===
match
---
argument [40646,40659]
argument [40646,40659]
===
match
---
atom_expr [69096,69113]
atom_expr [71044,71061]
===
match
---
trailer [45766,45781]
trailer [45766,45781]
===
match
---
operator: = [47212,47213]
operator: = [47212,47213]
===
match
---
name: paused_dags [32098,32109]
name: paused_dags [32098,32109]
===
match
---
with_stmt [41556,41653]
with_stmt [41556,41653]
===
match
---
expr_stmt [15056,15102]
expr_stmt [15056,15102]
===
match
---
atom_expr [41240,41332]
atom_expr [41240,41332]
===
match
---
name: child_dag [7923,7932]
name: child_dag [7923,7932]
===
match
---
trailer [7557,7576]
trailer [7557,7576]
===
match
---
name: SUCCESS [41469,41476]
name: SUCCESS [41469,41476]
===
match
---
name: info [9045,9049]
name: info [9045,9049]
===
match
---
atom_expr [22627,22650]
atom_expr [22627,22650]
===
match
---
name: period_end [27923,27933]
name: period_end [27923,27933]
===
match
---
name: previous_schedule [22143,22160]
name: previous_schedule [22143,22160]
===
match
---
name: args [43992,43996]
name: args [43992,43996]
===
match
---
expr_stmt [22558,22651]
expr_stmt [22558,22651]
===
match
---
name: dag [4275,4278]
name: dag [4275,4278]
===
match
---
suite [63067,63934]
suite [65015,65882]
===
match
---
trailer [25510,25516]
trailer [25510,25516]
===
match
---
trailer [21135,21143]
trailer [21135,21143]
===
match
---
name: get_dagmodel [46030,46042]
name: get_dagmodel [46030,46042]
===
match
---
fstring_end: ' [18544,18545]
fstring_end: ' [18544,18545]
===
match
---
for_stmt [47157,47246]
for_stmt [47157,47246]
===
match
---
atom_expr [31861,31879]
atom_expr [31861,31879]
===
match
---
argument [68562,68587]
argument [70510,70535]
===
match
---
funcdef [15167,16362]
funcdef [15167,16362]
===
match
---
simple_stmt [18993,19003]
simple_stmt [18993,19003]
===
match
---
string: "t1" [37123,37127]
string: "t1" [37123,37127]
===
match
---
operator: = [67572,67573]
operator: = [69520,69521]
===
match
---
argument [15552,15575]
argument [15552,15575]
===
match
---
name: next_date [58465,58474]
name: next_date [60413,60422]
===
match
---
name: runs [53857,53861]
name: runs [55805,55809]
===
match
---
string: '_neq' [44503,44509]
string: '_neq' [44503,44509]
===
match
---
simple_stmt [61067,61091]
simple_stmt [63015,63039]
===
match
---
name: self [9437,9441]
name: self [9437,9441]
===
match
---
name: filter [33116,33122]
name: filter [33116,33122]
===
match
---
name: pipeline [14133,14141]
name: pipeline [14133,14141]
===
match
---
atom_expr [57617,57654]
atom_expr [59565,59602]
===
match
---
fstring_expr [14238,14241]
fstring_expr [14238,14241]
===
match
---
name: i [24542,24543]
name: i [24542,24543]
===
match
---
assert_stmt [45755,45794]
assert_stmt [45755,45794]
===
match
---
name: task_id [35412,35419]
name: task_id [35412,35419]
===
match
---
name: op2 [38064,38067]
name: op2 [38064,38067]
===
match
---
trailer [58434,58443]
trailer [60382,60391]
===
match
---
trailer [9939,9952]
trailer [9939,9952]
===
match
---
simple_stmt [6867,6909]
simple_stmt [6867,6909]
===
match
---
operator: , [26896,26897]
operator: , [26896,26897]
===
match
---
operator: , [4770,4771]
operator: , [4770,4771]
===
match
---
name: orm_dag [34552,34559]
name: orm_dag [34552,34559]
===
match
---
name: DEFAULT_DATE [43934,43946]
name: DEFAULT_DATE [43934,43946]
===
match
---
name: self [65019,65023]
name: self [66967,66971]
===
match
---
operator: = [29073,29074]
operator: = [29073,29074]
===
match
---
atom [39504,39563]
atom [39504,39563]
===
match
---
operator: } [61690,61691]
operator: } [63638,63639]
===
match
---
operator: = [19889,19890]
operator: = [19889,19890]
===
match
---
operator: , [41511,41512]
operator: , [41511,41512]
===
match
---
operator: = [63331,63332]
operator: = [65279,65280]
===
match
---
simple_stmt [3796,3824]
simple_stmt [3796,3824]
===
match
---
param [69039,69042]
param [70987,70990]
===
match
---
trailer [3421,3429]
trailer [3421,3429]
===
match
---
atom_expr [47056,47071]
atom_expr [47056,47071]
===
match
---
trailer [41166,41231]
trailer [41166,41231]
===
match
---
name: unittest [2414,2422]
name: unittest [2414,2422]
===
match
---
name: clear_db_dags [2694,2707]
name: clear_db_dags [2694,2707]
===
match
---
operator: = [29022,29023]
operator: = [29022,29023]
===
match
---
name: staticmethod [3142,3154]
name: staticmethod [3142,3154]
===
match
---
name: default_args [11966,11978]
name: default_args [11966,11978]
===
match
---
trailer [24853,24856]
trailer [24853,24856]
===
match
---
operator: = [51448,51449]
operator: = [51448,51449]
===
match
---
string: 'dag-bulk-sync-0' [26625,26642]
string: 'dag-bulk-sync-0' [26625,26642]
===
match
---
number: 1 [58336,58337]
number: 1 [60284,60285]
===
match
---
atom_expr [10467,10486]
atom_expr [10467,10486]
===
match
---
atom [31253,31272]
atom [31253,31272]
===
match
---
name: row [27099,27102]
name: row [27099,27102]
===
match
---
trailer [36362,36376]
trailer [36362,36376]
===
match
---
simple_stmt [68139,68174]
simple_stmt [70087,70122]
===
match
---
operator: = [27946,27947]
operator: = [27946,27947]
===
match
---
trailer [27078,27080]
trailer [27078,27080]
===
match
---
simple_stmt [44469,44530]
simple_stmt [44469,44530]
===
match
---
trailer [34383,34407]
trailer [34383,34407]
===
match
---
suite [19200,19253]
suite [19200,19253]
===
match
---
parameters [5701,5707]
parameters [5701,5707]
===
match
---
trailer [18019,18111]
trailer [18019,18111]
===
match
---
arglist [47206,47244]
arglist [47206,47244]
===
match
---
with_stmt [46178,46316]
with_stmt [46178,46316]
===
match
---
simple_stmt [10264,10282]
simple_stmt [10264,10282]
===
match
---
name: get [28235,28238]
name: get [28235,28238]
===
match
---
number: 2018 [12012,12016]
number: 2018 [12012,12016]
===
match
---
simple_stmt [47080,47115]
simple_stmt [47080,47115]
===
match
---
operator: , [17923,17924]
operator: , [17923,17924]
===
match
---
trailer [49854,49859]
trailer [49854,49859]
===
match
---
number: 1 [12135,12136]
number: 1 [12135,12136]
===
match
---
atom_expr [9900,9923]
atom_expr [9900,9923]
===
match
---
trailer [11866,11878]
trailer [11866,11878]
===
match
---
name: self [30597,30601]
name: self [30597,30601]
===
match
---
arglist [59512,59659]
arglist [61460,61607]
===
match
---
param [33359,33363]
param [33359,33363]
===
match
---
operator: @ [48399,48400]
operator: @ [48399,48400]
===
match
---
operator: == [49704,49706]
operator: == [49704,49706]
===
match
---
expr_stmt [27422,27504]
expr_stmt [27422,27504]
===
match
---
name: test_dag [16933,16941]
name: test_dag [16933,16941]
===
match
---
operator: , [31859,31860]
operator: , [31859,31860]
===
match
---
comparison [39426,39452]
comparison [39426,39452]
===
match
---
simple_stmt [48618,48641]
simple_stmt [48618,48641]
===
match
---
comparison [24301,24442]
comparison [24301,24442]
===
match
---
comparison [38810,38856]
comparison [38810,38856]
===
match
---
number: 1 [12018,12019]
number: 1 [12018,12019]
===
match
---
number: 0 [14410,14411]
number: 0 [14410,14411]
===
match
---
param [40891,40895]
param [40891,40895]
===
match
---
atom_expr [61921,61953]
atom_expr [63869,63901]
===
match
---
trailer [8438,8479]
trailer [8438,8479]
===
match
---
name: dag [69243,69246]
name: dag [71191,71194]
===
match
---
comparison [2881,2904]
comparison [2881,2904]
===
match
---
operator: = [11978,11979]
operator: = [11978,11979]
===
match
---
argument [37898,37921]
argument [37898,37921]
===
match
---
atom_expr [40792,40803]
atom_expr [40792,40803]
===
match
---
operator: = [51342,51343]
operator: = [51342,51343]
===
match
---
simple_stmt [65458,65484]
simple_stmt [67406,67432]
===
match
---
name: task_id [37969,37976]
name: task_id [37969,37976]
===
match
---
atom_expr [45737,45746]
atom_expr [45737,45746]
===
match
---
trailer [52270,52283]
trailer [54218,54231]
===
match
---
name: _next [23854,23859]
name: _next [23854,23859]
===
match
---
string: """         Tests scheduling a dag scheduled for @once - should be scheduled the first time         it is called, and not scheduled the second.         """ [42015,42170]
string: """         Tests scheduling a dag scheduled for @once - should be scheduled the first time         it is called, and not scheduled the second.         """ [42015,42170]
===
match
---
name: run_type [48052,48060]
name: run_type [48052,48060]
===
match
---
atom [31614,31629]
atom [31614,31629]
===
match
---
trailer [19681,19689]
trailer [19681,19689]
===
match
---
operator: @ [39789,39790]
operator: @ [39789,39790]
===
match
---
term [15006,15024]
term [15006,15024]
===
match
---
simple_stmt [6364,6399]
simple_stmt [6364,6399]
===
match
---
argument [18922,18940]
argument [18922,18940]
===
match
---
number: 2 [58453,58454]
number: 2 [60401,60402]
===
match
---
operator: = [47139,47140]
operator: = [47139,47140]
===
match
---
name: sub_dag [38562,38569]
name: sub_dag [38562,38569]
===
match
---
argument [68441,68469]
argument [70389,70417]
===
match
---
number: 1 [13634,13635]
number: 1 [13634,13635]
===
match
---
trailer [49733,49736]
trailer [49733,49736]
===
match
---
trailer [48310,48315]
trailer [48310,48315]
===
match
---
name: start_date [28529,28539]
name: start_date [28529,28539]
===
match
---
string: "t1" [35809,35813]
string: "t1" [35809,35813]
===
match
---
operator: , [18358,18359]
operator: , [18358,18359]
===
match
---
trailer [34997,35006]
trailer [34997,35006]
===
match
---
name: DEFAULT_DATE [41922,41934]
name: DEFAULT_DATE [41922,41934]
===
match
---
string: 'start_date' [44263,44275]
string: 'start_date' [44263,44275]
===
match
---
name: Session [29033,29040]
name: Session [29033,29040]
===
match
---
atom_expr [9936,9957]
atom_expr [9936,9957]
===
match
---
parameters [65264,65266]
parameters [67212,67214]
===
match
---
trailer [22716,22775]
trailer [22716,22775]
===
match
---
operator: = [54963,54964]
operator: = [56911,56912]
===
match
---
trailer [7120,7135]
trailer [7120,7135]
===
match
---
name: clear [27653,27658]
name: clear [27653,27658]
===
match
---
comparison [42848,42873]
comparison [42848,42873]
===
match
---
operator: = [27580,27581]
operator: = [27580,27581]
===
match
---
atom_expr [20697,20724]
atom_expr [20697,20724]
===
match
---
atom_expr [6002,6072]
atom_expr [6002,6072]
===
match
---
atom_expr [13283,13298]
atom_expr [13283,13298]
===
match
---
trailer [52962,52964]
trailer [54910,54912]
===
match
---
atom_expr [11765,11793]
atom_expr [11765,11793]
===
match
---
simple_stmt [60203,60376]
simple_stmt [62151,62324]
===
match
---
atom_expr [8537,8606]
atom_expr [8537,8606]
===
match
---
name: dag_id [24394,24400]
name: dag_id [24394,24400]
===
match
---
operator: = [68636,68637]
operator: = [70584,70585]
===
match
---
suite [43845,44086]
suite [43845,44086]
===
match
---
trailer [48862,49029]
trailer [48862,49029]
===
match
---
with_item [38320,38367]
with_item [38320,38367]
===
match
---
name: following_schedule [63502,63520]
name: following_schedule [65450,65468]
===
match
---
name: task_decorator [66180,66194]
name: task_decorator [68128,68142]
===
match
---
name: unittest [1048,1056]
name: unittest [1048,1056]
===
match
---
testlist_comp [19382,19394]
testlist_comp [19382,19394]
===
match
---
funcdef [35137,35611]
funcdef [35137,35611]
===
match
---
atom_expr [60398,60406]
atom_expr [62346,62354]
===
match
---
argument [67558,67590]
argument [69506,69538]
===
match
---
atom_expr [27029,27081]
atom_expr [27029,27081]
===
match
---
operator: , [12991,12992]
operator: , [12991,12992]
===
match
---
trailer [51784,51792]
trailer [53732,53740]
===
match
---
operator: = [30923,30924]
operator: = [30923,30924]
===
match
---
name: DAG [11590,11593]
name: DAG [11590,11593]
===
match
---
operator: { [32410,32411]
operator: { [32410,32411]
===
match
---
name: model [41816,41821]
name: model [41816,41821]
===
match
---
atom_expr [34701,34716]
atom_expr [34701,34716]
===
match
---
trailer [68208,68215]
trailer [70156,70163]
===
match
---
simple_stmt [14821,14857]
simple_stmt [14821,14857]
===
match
---
assert_stmt [69236,69276]
assert_stmt [71184,71224]
===
match
---
name: self [65220,65224]
name: self [67168,67172]
===
match
---
operator: = [17301,17302]
operator: = [17301,17302]
===
match
---
operator: , [26028,26029]
operator: , [26028,26029]
===
match
---
expr_stmt [35781,35814]
expr_stmt [35781,35814]
===
match
---
name: all [49659,49662]
name: all [49659,49662]
===
match
---
name: DEFAULT_ARGS [66053,66065]
name: DEFAULT_ARGS [68001,68013]
===
match
---
simple_stmt [1943,2009]
simple_stmt [1943,2009]
===
match
---
atom_expr [64980,64993]
atom_expr [66928,66941]
===
match
---
simple_stmt [27669,27706]
simple_stmt [27669,27706]
===
match
---
trailer [31514,31518]
trailer [31514,31518]
===
match
---
name: session [33092,33099]
name: session [33092,33099]
===
match
---
name: op1 [35300,35303]
name: op1 [35300,35303]
===
match
---
operator: = [60355,60356]
operator: = [62303,62304]
===
match
---
atom_expr [17142,17155]
atom_expr [17142,17155]
===
match
---
name: value [68965,68970]
name: value [70913,70918]
===
match
---
trailer [13349,13360]
trailer [13349,13360]
===
match
---
trailer [50557,50564]
trailer [50557,50564]
===
match
---
suite [7809,8017]
suite [7809,8017]
===
match
---
name: schedule_interval [60686,60703]
name: schedule_interval [62634,62651]
===
match
---
operator: , [19808,19809]
operator: , [19808,19809]
===
match
---
atom_expr [9970,9991]
atom_expr [9970,9991]
===
match
---
name: dag [38186,38189]
name: dag [38186,38189]
===
match
---
name: conf [1301,1305]
name: conf [1301,1305]
===
match
---
arglist [34123,34156]
arglist [34123,34156]
===
match
---
argument [35893,35905]
argument [35893,35905]
===
match
---
operator: , [28250,28251]
operator: , [28250,28251]
===
match
---
operator: , [25023,25024]
operator: , [25023,25024]
===
match
---
trailer [49208,49210]
trailer [49208,49210]
===
match
---
funcdef [66977,67804]
funcdef [68925,69752]
===
match
---
name: DummyOperator [29985,29998]
name: DummyOperator [29985,29998]
===
match
---
trailer [38575,38583]
trailer [38575,38583]
===
match
---
operator: = [42225,42226]
operator: = [42225,42226]
===
match
---
suite [6091,6196]
suite [6091,6196]
===
match
---
name: op1 [38135,38138]
name: op1 [38135,38138]
===
match
---
testlist_comp [31644,31660]
testlist_comp [31644,31660]
===
match
---
suite [26523,26563]
suite [26523,26563]
===
match
---
name: DEFAULT_DATE [41431,41443]
name: DEFAULT_DATE [41431,41443]
===
match
---
name: session [52156,52163]
name: session [54104,54111]
===
match
---
operator: = [36347,36348]
operator: = [36347,36348]
===
match
---
atom_expr [65833,65853]
atom_expr [67781,67801]
===
match
---
parameters [66720,66725]
parameters [68668,68673]
===
match
---
name: weight [14288,14294]
name: weight [14288,14294]
===
match
---
trailer [41949,41959]
trailer [41949,41959]
===
match
---
atom_expr [64011,64026]
atom_expr [65959,65974]
===
match
---
name: self [67170,67174]
name: self [69118,69122]
===
match
---
trailer [57169,57385]
trailer [59117,59333]
===
match
---
name: schedule_interval [56099,56116]
name: schedule_interval [58047,58064]
===
match
---
name: task_decorator [67196,67210]
name: task_decorator [69144,69158]
===
match
---
operator: = [40120,40121]
operator: = [40120,40121]
===
match
---
name: delta [54021,54026]
name: delta [55969,55974]
===
match
---
atom_expr [41163,41231]
atom_expr [41163,41231]
===
match
---
name: close [34709,34714]
name: close [34709,34714]
===
match
---
name: test_existing_dag_is_paused_upon_creation [32510,32551]
name: test_existing_dag_is_paused_upon_creation [32510,32551]
===
match
---
name: test_dag_start_date_propagates_to_end_date [10990,11032]
name: test_dag_start_date_propagates_to_end_date [10990,11032]
===
match
---
atom_expr [19637,19646]
atom_expr [19637,19646]
===
match
---
trailer [38583,38638]
trailer [38583,38638]
===
match
---
simple_stmt [1667,1715]
simple_stmt [1667,1715]
===
match
---
name: including_subdags [31768,31785]
name: including_subdags [31768,31785]
===
match
---
name: DEFAULT_DATE [35747,35759]
name: DEFAULT_DATE [35747,35759]
===
match
---
atom_expr [12173,12190]
atom_expr [12173,12190]
===
match
---
trailer [39403,39410]
trailer [39403,39410]
===
match
---
simple_stmt [63918,63934]
simple_stmt [65866,65882]
===
match
---
name: next_dagrun_after_date [53365,53387]
name: next_dagrun_after_date [55313,55335]
===
match
---
operator: , [53260,53261]
operator: , [55208,55209]
===
match
---
name: self [8269,8273]
name: self [8269,8273]
===
match
---
simple_stmt [29985,30031]
simple_stmt [29985,30031]
===
match
---
trailer [48477,48485]
trailer [48477,48485]
===
match
---
parameters [42991,42997]
parameters [42991,42997]
===
match
---
name: test_dag_id [17912,17923]
name: test_dag_id [17912,17923]
===
match
---
name: dag [52634,52637]
name: dag [54582,54585]
===
match
---
atom_expr [23394,23410]
atom_expr [23394,23410]
===
match
---
atom_expr [11809,11846]
atom_expr [11809,11846]
===
match
---
name: DummyOperator [60424,60437]
name: DummyOperator [62372,62385]
===
match
---
atom_expr [19743,19749]
atom_expr [19743,19749]
===
match
---
comparison [39347,39366]
comparison [39347,39366]
===
match
---
sync_comp_for [24857,24904]
sync_comp_for [24857,24904]
===
match
---
simple_stmt [49071,49147]
simple_stmt [49071,49147]
===
match
---
trailer [5053,5059]
trailer [5053,5059]
===
match
---
suite [13409,13783]
suite [13409,13783]
===
match
---
number: 0 [59240,59241]
number: 0 [61188,61189]
===
match
---
trailer [29511,29518]
trailer [29511,29518]
===
match
---
operator: , [49330,49331]
operator: , [49330,49331]
===
match
---
string: "faketastic" [41274,41286]
string: "faketastic" [41274,41286]
===
match
---
trailer [17112,17120]
trailer [17112,17120]
===
match
---
funcdef [7256,8480]
funcdef [7256,8480]
===
match
---
name: return_num [67227,67237]
name: return_num [69175,69185]
===
match
---
name: self [67325,67329]
name: self [69273,69277]
===
match
---
trailer [27630,27638]
trailer [27630,27638]
===
match
---
number: 5 [59474,59475]
number: 5 [61422,61423]
===
match
---
name: self [50040,50044]
name: self [50040,50044]
===
match
---
simple_stmt [2198,2236]
simple_stmt [2198,2236]
===
match
---
trailer [9330,9337]
trailer [9330,9337]
===
match
---
trailer [27068,27073]
trailer [27068,27073]
===
match
---
number: 3 [9391,9392]
number: 3 [9391,9392]
===
match
---
name: template_file [19929,19942]
name: template_file [19929,19942]
===
match
---
expr_stmt [34063,34091]
expr_stmt [34063,34091]
===
match
---
name: self [67573,67577]
name: self [69521,69525]
===
match
---
assert_stmt [47641,47698]
assert_stmt [47641,47698]
===
match
---
trailer [68922,68935]
trailer [70870,70883]
===
match
---
string: "2018-10-28T02:00:00+00:00" [22095,22122]
string: "2018-10-28T02:00:00+00:00" [22095,22122]
===
match
---
number: 0 [2395,2396]
number: 0 [2395,2396]
===
match
---
atom [14092,14111]
atom [14092,14111]
===
match
---
name: TEST_DATE [42582,42591]
name: TEST_DATE [42582,42591]
===
match
---
argument [47225,47244]
argument [47225,47244]
===
match
---
name: params_combined [4404,4419]
name: params_combined [4404,4419]
===
match
---
trailer [32328,32349]
trailer [32328,32349]
===
match
---
name: ti_state_end [53108,53120]
name: ti_state_end [55056,55068]
===
match
---
arglist [11607,11705]
arglist [11607,11705]
===
match
---
name: dag [66398,66401]
name: dag [68346,68349]
===
match
---
name: airflow [1311,1318]
name: airflow [1311,1318]
===
match
---
name: State [47398,47403]
name: State [47398,47403]
===
match
---
exprlist [15838,15846]
exprlist [15838,15846]
===
match
---
name: state [39683,39688]
name: state [39683,39688]
===
match
---
operator: } [61894,61895]
operator: } [63842,63843]
===
match
---
return_stmt [55275,55285]
return_stmt [57223,57233]
===
match
---
simple_stmt [7168,7190]
simple_stmt [7168,7190]
===
match
---
name: orientation [5653,5664]
name: orientation [5653,5664]
===
match
---
name: orm_dag [63734,63741]
name: orm_dag [65682,65689]
===
match
---
simple_stmt [20689,20725]
simple_stmt [20689,20725]
===
match
---
trailer [28496,28563]
trailer [28496,28563]
===
match
---
name: dag [45024,45027]
name: dag [45024,45027]
===
match
---
name: dr [28143,28145]
name: dr [28143,28145]
===
match
---
name: dags [25558,25562]
name: dags [25558,25562]
===
match
---
trailer [22205,22211]
trailer [22205,22211]
===
match
---
operator: = [42581,42582]
operator: = [42581,42582]
===
match
---
trailer [60403,60406]
trailer [62351,62354]
===
match
---
name: datetime [59453,59461]
name: datetime [61401,61409]
===
match
---
assert_stmt [30434,30473]
assert_stmt [30434,30473]
===
match
---
atom [9085,9100]
atom [9085,9100]
===
match
---
atom_expr [59573,59613]
atom_expr [61521,61561]
===
match
---
name: start_date [41207,41217]
name: start_date [41207,41217]
===
match
---
atom [11979,12024]
atom [11979,12024]
===
match
---
trailer [31926,31933]
trailer [31926,31933]
===
match
---
simple_stmt [20733,20770]
simple_stmt [20733,20770]
===
match
---
name: dag [12157,12160]
name: dag [12157,12160]
===
match
---
name: dag [50347,50350]
name: dag [50347,50350]
===
match
---
operator: > [55948,55949]
operator: > [57896,57897]
===
match
---
expr_stmt [50218,50292]
expr_stmt [50218,50292]
===
match
---
operator: { [24832,24833]
operator: { [24832,24833]
===
match
---
trailer [50044,50054]
trailer [50044,50054]
===
match
---
name: is_paused_upon_creation [32688,32711]
name: is_paused_upon_creation [32688,32711]
===
match
---
param [22409,22413]
param [22409,22413]
===
match
---
decorated [65596,65787]
decorated [67544,67735]
===
match
---
argument [66600,66630]
argument [68548,68578]
===
match
---
name: UPSTREAM [14343,14351]
name: UPSTREAM [14343,14351]
===
match
---
name: BaseOperator [1557,1569]
name: BaseOperator [1557,1569]
===
match
---
atom [46352,46683]
atom [46352,46683]
===
match
---
argument [38336,38359]
argument [38336,38359]
===
match
---
name: dag [6968,6971]
name: dag [6968,6971]
===
match
---
simple_stmt [14133,14493]
simple_stmt [14133,14493]
===
match
---
trailer [68741,68751]
trailer [70689,70699]
===
match
---
atom_expr [61973,62047]
atom_expr [63921,63995]
===
match
---
assert_stmt [49684,49708]
assert_stmt [49684,49708]
===
match
---
name: outdated_permissions [61476,61496]
name: outdated_permissions [63424,63444]
===
match
---
funcdef [44091,45842]
funcdef [44091,45842]
===
match
---
trailer [37710,37718]
trailer [37710,37718]
===
match
---
name: child_dag_name [60265,60279]
name: child_dag_name [62213,62227]
===
match
---
dictorsetmaker [25841,25895]
dictorsetmaker [25841,25895]
===
match
---
operator: = [68917,68918]
operator: = [70865,70866]
===
match
---
trailer [56036,56214]
trailer [57984,58162]
===
match
---
param [45875,45879]
param [45875,45879]
===
match
---
name: super [64956,64961]
name: super [66904,66909]
===
match
---
name: prev_local [22827,22837]
name: prev_local [22827,22837]
===
match
---
simple_stmt [56814,56860]
simple_stmt [58762,58808]
===
match
---
trailer [43372,43579]
trailer [43372,43579]
===
match
---
operator: , [55701,55702]
operator: , [57649,57650]
===
match
---
name: session [24724,24731]
name: session [24724,24731]
===
match
---
name: row [25223,25226]
name: row [25223,25226]
===
match
---
string: """             Create a subdag.             """ [60142,60190]
string: """             Create a subdag.             """ [62090,62138]
===
match
---
operator: = [62508,62509]
operator: = [64456,64457]
===
match
---
number: 2 [10447,10448]
number: 2 [10447,10448]
===
match
---
assert_stmt [29722,29766]
assert_stmt [29722,29766]
===
match
---
operator: = [52059,52060]
operator: = [54007,54008]
===
match
---
operator: , [43464,43465]
operator: , [43464,43465]
===
match
---
assert_stmt [45394,45420]
assert_stmt [45394,45420]
===
match
---
operator: @ [3141,3142]
operator: @ [3141,3142]
===
match
---
name: op3 [9883,9886]
name: op3 [9883,9886]
===
match
---
atom_expr [66914,66929]
atom_expr [68862,68877]
===
match
---
string: """         Tests if fractional seconds are stored in the database         """ [43007,43085]
string: """         Tests if fractional seconds are stored in the database         """ [43007,43085]
===
match
---
argument [16977,17004]
argument [16977,17004]
===
match
---
operator: , [65205,65206]
operator: , [67153,67154]
===
match
---
atom_expr [50370,50411]
atom_expr [50370,50411]
===
match
---
trailer [41252,41332]
trailer [41252,41332]
===
match
---
trailer [6545,6560]
trailer [6545,6560]
===
match
---
number: 0 [25845,25846]
number: 0 [25845,25846]
===
match
---
name: RUNNING [64559,64566]
name: RUNNING [66507,66514]
===
match
---
trailer [40068,40070]
trailer [40068,40070]
===
match
---
name: xcom_arg [67341,67349]
name: xcom_arg [69289,69297]
===
match
---
trailer [22089,22091]
trailer [22089,22091]
===
match
---
name: datetime [57740,57748]
name: datetime [59688,59696]
===
match
---
string: """Verify correctness of dag.tree_view().""" [36132,36176]
string: """Verify correctness of dag.tree_view().""" [36132,36176]
===
match
---
trailer [48027,48032]
trailer [48027,48032]
===
match
---
name: query [30371,30376]
name: query [30371,30376]
===
match
---
name: date [54175,54179]
name: date [56123,56127]
===
match
---
simple_stmt [38179,38240]
simple_stmt [38179,38240]
===
match
---
name: self [59903,59907]
name: self [61851,61855]
===
match
---
number: 10 [20402,20404]
number: 10 [20402,20404]
===
match
---
name: stage [15963,15968]
name: stage [15963,15968]
===
match
---
name: noop_pipeline [66644,66657]
name: noop_pipeline [68592,68605]
===
match
---
number: 1 [16020,16021]
number: 1 [16020,16021]
===
match
---
atom [25996,26028]
atom [25996,26028]
===
match
---
name: models [1635,1641]
name: models [1635,1641]
===
match
---
name: test_rich_comparison_ops [44095,44119]
name: test_rich_comparison_ops [44095,44119]
===
match
---
name: dag_id [33442,33448]
name: dag_id [33442,33448]
===
match
---
atom_expr [61786,61813]
atom_expr [63734,63761]
===
match
---
assert_stmt [39461,39488]
assert_stmt [39461,39488]
===
match
---
atom_expr [56878,56907]
atom_expr [58826,58855]
===
match
---
name: dag_id [52041,52047]
name: dag_id [53989,53995]
===
match
---
expr_stmt [69126,69159]
expr_stmt [71074,71107]
===
match
---
name: dag_id [62359,62365]
name: dag_id [64307,64313]
===
match
---
name: task_id [19882,19889]
name: task_id [19882,19889]
===
match
---
name: DuplicateTaskIdFound [1409,1429]
name: DuplicateTaskIdFound [1409,1429]
===
match
---
arglist [29867,29944]
arglist [29867,29944]
===
match
---
atom [64688,64861]
atom [66636,66809]
===
match
---
simple_stmt [36601,36632]
simple_stmt [36601,36632]
===
match
---
expr_stmt [68228,68261]
expr_stmt [70176,70209]
===
match
---
name: pipeline [16007,16015]
name: pipeline [16007,16015]
===
match
---
argument [20648,20679]
argument [20648,20679]
===
match
---
simple_stmt [19266,19298]
simple_stmt [19266,19298]
===
match
---
simple_stmt [853,863]
simple_stmt [853,863]
===
match
---
trailer [59782,59788]
trailer [61730,61736]
===
match
---
simple_stmt [43589,43611]
simple_stmt [43589,43611]
===
match
---
name: get_num_task_instances [17997,18019]
name: get_num_task_instances [17997,18019]
===
match
---
string: "test_dag" [35243,35253]
string: "test_dag" [35243,35253]
===
match
---
atom [48444,48457]
atom [48444,48457]
===
match
---
name: start_date [43735,43745]
name: start_date [43735,43745]
===
match
---
name: State [50994,50999]
name: State [50994,50999]
===
match
---
simple_stmt [51205,51468]
simple_stmt [51205,51468]
===
match
---
arglist [59220,59241]
arglist [61168,61189]
===
match
---
name: dag_ [44777,44781]
name: dag_ [44777,44781]
===
match
---
operator: = [19866,19867]
operator: = [19866,19867]
===
match
---
name: clear_db_dags [24489,24502]
name: clear_db_dags [24489,24502]
===
match
---
operator: = [47962,47963]
operator: = [47962,47963]
===
match
---
name: safe_dag_id [29679,29690]
name: safe_dag_id [29679,29690]
===
match
---
trailer [62823,62827]
trailer [64771,64775]
===
match
---
name: stage [15841,15846]
name: stage [15841,15846]
===
match
---
operator: , [18607,18608]
operator: , [18607,18608]
===
match
---
trailer [23078,23085]
trailer [23078,23085]
===
match
---
operator: = [9506,9507]
operator: = [9506,9507]
===
match
---
trailer [24502,24504]
trailer [24502,24504]
===
match
---
name: conf [33713,33717]
name: conf [33713,33717]
===
match
---
atom_expr [28067,28087]
atom_expr [28067,28087]
===
match
---
testlist_comp [49848,49892]
testlist_comp [49848,49892]
===
match
---
trailer [29572,29579]
trailer [29572,29579]
===
match
---
name: ti4 [17379,17382]
name: ti4 [17379,17382]
===
match
---
operator: = [63413,63414]
operator: = [65361,65362]
===
match
---
name: pytest [5221,5227]
name: pytest [5221,5227]
===
match
---
trailer [17172,17246]
trailer [17172,17246]
===
match
---
simple_stmt [46014,46063]
simple_stmt [46014,46063]
===
match
---
simple_stmt [54373,54402]
simple_stmt [56321,56350]
===
match
---
operator: { [4317,4318]
operator: { [4317,4318]
===
match
---
name: self [68608,68612]
name: self [70556,70560]
===
match
---
name: end_date [49280,49288]
name: end_date [49280,49288]
===
match
---
trailer [42812,42816]
trailer [42812,42816]
===
match
---
operator: = [59147,59148]
operator: = [61095,61096]
===
match
---
param [37783,37787]
param [37783,37787]
===
match
---
operator: , [38151,38152]
operator: , [38151,38152]
===
match
---
name: name [18539,18543]
name: name [18539,18543]
===
match
---
string: 'dag_without_catchup_once' [56523,56549]
string: 'dag_without_catchup_once' [58471,58497]
===
match
---
atom_expr [2670,2685]
atom_expr [2670,2685]
===
match
---
argument [21521,21553]
argument [21521,21553]
===
match
---
fstring [60244,60281]
fstring [62192,62229]
===
match
---
operator: = [68451,68452]
operator: = [70399,70400]
===
match
---
name: dag_id [46118,46124]
name: dag_id [46118,46124]
===
match
---
simple_stmt [61185,61241]
simple_stmt [63133,63189]
===
match
---
operator: = [58210,58211]
operator: = [60158,60159]
===
match
---
argument [48715,48732]
argument [48715,48732]
===
match
---
suite [60129,60527]
suite [62077,62475]
===
match
---
atom_expr [21007,21029]
atom_expr [21007,21029]
===
match
---
simple_stmt [9239,9273]
simple_stmt [9239,9273]
===
match
---
name: dagrun_1 [50458,50466]
name: dagrun_1 [50458,50466]
===
match
---
operator: , [53298,53299]
operator: , [55246,55247]
===
match
---
simple_stmt [49684,49709]
simple_stmt [49684,49709]
===
match
---
expr_stmt [55134,55176]
expr_stmt [57082,57124]
===
match
---
operator: = [41199,41200]
operator: = [41199,41200]
===
match
---
operator: = [59754,59755]
operator: = [61702,61703]
===
match
---
operator: , [27695,27696]
operator: , [27695,27696]
===
match
---
trailer [4287,4291]
trailer [4287,4291]
===
match
---
number: 0 [68721,68722]
number: 0 [70669,70670]
===
match
---
atom_expr [67972,67989]
atom_expr [69920,69937]
===
match
---
string: 't1' [52018,52022]
string: 't1' [53966,53970]
===
match
---
trailer [24890,24897]
trailer [24890,24897]
===
match
---
simple_stmt [59424,59480]
simple_stmt [61372,61428]
===
match
---
name: current_task [14618,14630]
name: current_task [14618,14630]
===
match
---
name: dag_subdag [60516,60526]
name: dag_subdag [62464,62474]
===
match
---
operator: = [22838,22839]
operator: = [22838,22839]
===
match
---
trailer [2880,2905]
trailer [2880,2905]
===
match
---
name: subdag_id [30680,30689]
name: subdag_id [30680,30689]
===
match
---
name: params_combined [4451,4466]
name: params_combined [4451,4466]
===
match
---
atom_expr [24521,24590]
atom_expr [24521,24590]
===
match
---
param [42992,42996]
param [42992,42996]
===
match
---
name: DagModel [28225,28233]
name: DagModel [28225,28233]
===
match
---
name: width [15331,15336]
name: width [15331,15336]
===
match
---
operator: { [10925,10926]
operator: { [10925,10926]
===
match
---
argument [50332,50345]
argument [50332,50345]
===
match
---
atom_expr [17531,17549]
atom_expr [17531,17549]
===
match
---
assert_stmt [10375,10409]
assert_stmt [10375,10409]
===
match
---
operator: = [31362,31363]
operator: = [31362,31363]
===
match
---
name: SubDagOperator [30043,30057]
name: SubDagOperator [30043,30057]
===
match
---
simple_stmt [59305,59362]
simple_stmt [61253,61310]
===
match
---
trailer [22675,22690]
trailer [22675,22690]
===
match
---
expr_stmt [41052,41087]
expr_stmt [41052,41087]
===
match
---
atom_expr [23977,24006]
atom_expr [23977,24006]
===
match
---
name: session [63675,63682]
name: session [65623,65630]
===
match
---
expr_stmt [45249,45273]
expr_stmt [45249,45273]
===
match
---
name: dag [37689,37692]
name: dag [37689,37692]
===
match
---
name: permissions [61757,61768]
name: permissions [63705,63716]
===
match
---
parameters [12237,12243]
parameters [12237,12243]
===
match
---
name: task_id [48762,48769]
name: task_id [48762,48769]
===
match
---
trailer [10787,10837]
trailer [10787,10837]
===
match
---
arglist [40423,40479]
arglist [40423,40479]
===
match
---
expr_stmt [7011,7045]
expr_stmt [7011,7045]
===
match
---
operator: = [16891,16892]
operator: = [16891,16892]
===
match
---
name: op2 [9900,9903]
name: op2 [9900,9903]
===
match
---
trailer [31837,31843]
trailer [31837,31843]
===
match
---
atom_expr [60851,60861]
atom_expr [62799,62809]
===
match
---
string: 'Europe/Zurich' [21435,21450]
string: 'Europe/Zurich' [21435,21450]
===
match
---
suite [13146,13361]
suite [13146,13361]
===
match
---
name: query [3052,3057]
name: query [3052,3057]
===
match
---
string: "test_create_dagrun_job_id_is_set" [48176,48210]
string: "test_create_dagrun_job_id_is_set" [48176,48210]
===
match
---
name: create_dagrun [47192,47205]
name: create_dagrun [47192,47205]
===
match
---
name: topological_list [10037,10053]
name: topological_list [10037,10053]
===
match
---
simple_stmt [23273,23309]
simple_stmt [23273,23309]
===
match
---
trailer [42230,42245]
trailer [42230,42245]
===
match
---
argument [14320,14351]
argument [14320,14351]
===
match
---
simple_stmt [39340,39367]
simple_stmt [39340,39367]
===
match
---
operator: == [53420,53422]
operator: == [55368,55370]
===
match
---
if_stmt [13163,13203]
if_stmt [13163,13203]
===
match
---
name: SHUTDOWN [51827,51835]
name: SHUTDOWN [53775,53783]
===
match
---
operator: * [13638,13639]
operator: * [13638,13639]
===
match
---
operator: = [17327,17328]
operator: = [17327,17328]
===
match
---
string: 'dag-bulk-sync-0' [24957,24974]
string: 'dag-bulk-sync-0' [24957,24974]
===
match
---
name: DummyOperator [35833,35846]
name: DummyOperator [35833,35846]
===
match
---
atom_expr [27985,27998]
atom_expr [27985,27998]
===
match
---
parameters [2447,2453]
parameters [2447,2453]
===
match
---
operator: , [60360,60361]
operator: , [62308,62309]
===
match
---
string: "Task id 't1' has already been added to the DAG" [37430,37478]
string: "Task id 't1' has already been added to the DAG" [37430,37478]
===
match
---
operator: , [61236,61237]
operator: , [63184,63185]
===
match
---
operator: = [13695,13696]
operator: = [13695,13696]
===
match
---
atom_expr [13434,13461]
atom_expr [13434,13461]
===
match
---
simple_stmt [55798,55844]
simple_stmt [57746,57792]
===
match
---
name: dag_id [41960,41966]
name: dag_id [41960,41966]
===
match
---
name: SubDagOperator [28941,28955]
name: SubDagOperator [28941,28955]
===
match
---
name: depth [13969,13974]
name: depth [13969,13974]
===
match
---
operator: , [41476,41477]
operator: , [41476,41477]
===
match
---
with_stmt [7793,8017]
with_stmt [7793,8017]
===
match
---
name: task_id [9839,9846]
name: task_id [9839,9846]
===
match
---
simple_stmt [2952,3032]
simple_stmt [2952,3032]
===
match
---
name: parent_dag [28876,28886]
name: parent_dag [28876,28886]
===
match
---
trailer [34283,34285]
trailer [34283,34285]
===
match
---
atom_expr [43519,43532]
atom_expr [43519,43532]
===
match
---
trailer [62412,62424]
trailer [64360,64372]
===
match
---
atom_expr [39307,39320]
atom_expr [39307,39320]
===
match
---
operator: == [47658,47660]
operator: == [47658,47660]
===
match
---
argument [19810,19842]
argument [19810,19842]
===
insert-node
---
name: TestDag [2406,2413]
to
classdef [2400,62264]
at 0
===
insert-tree
---
decorated [51684,53627]
    decorator [51684,51790]
        operator: @ [51684,51685]
        dotted_name [51685,51705]
            name: parameterized [51685,51698]
            name: expand [51699,51705]
        atom [51715,51783]
            testlist_comp [51729,51773]
                atom [51729,51742]
                    testlist_comp [51730,51741]
                        atom_expr [51730,51740]
                            name: State [51730,51735]
                            trailer [51735,51740]
                                name: NONE [51736,51740]
                        operator: , [51740,51741]
                operator: , [51742,51743]
                atom [51756,51772]
                    testlist_comp [51757,51771]
                        atom_expr [51757,51770]
                            name: State [51757,51762]
                            trailer [51762,51770]
                                name: RUNNING [51763,51770]
                        operator: , [51770,51771]
                operator: , [51772,51773]
    funcdef [51794,53627]
        name: test_clear_set_dagrun_state_for_parent_dag [51798,51840]
        parameters [51840,51861]
            param [51841,51846]
                name: self [51841,51845]
                operator: , [51845,51846]
            param [51847,51860]
                name: dag_run_state [51847,51860]
        suite [51862,53627]
            simple_stmt [51871,51921]
                expr_stmt [51871,51920]
                    name: dag_id [51871,51877]
                    operator: = [51878,51879]
                    string: 'test_clear_set_dagrun_state_parent_dag' [51880,51920]
            simple_stmt [51929,51952]
                atom_expr [51929,51951]
                    name: self [51929,51933]
                    trailer [51933,51943]
                        name: _clean_up [51934,51943]
                    trailer [51943,51951]
                        name: dag_id [51944,51950]
            simple_stmt [51960,51975]
                expr_stmt [51960,51974]
                    name: task_id [51960,51967]
                    operator: = [51968,51969]
                    string: 't1' [51970,51974]
            simple_stmt [51983,52045]
                expr_stmt [51983,52044]
                    name: dag [51983,51986]
                    operator: = [51987,51988]
                    atom_expr [51989,52044]
                        name: DAG [51989,51992]
                        trailer [51992,52044]
                            arglist [51993,52043]
                                name: dag_id [51993,51999]
                                operator: , [51999,52000]
                                argument [52001,52024]
                                    name: start_date [52001,52011]
                                    operator: = [52011,52012]
                                    name: DEFAULT_DATE [52012,52024]
                                operator: , [52024,52025]
                                argument [52026,52043]
                                    name: max_active_runs [52026,52041]
                                    operator: = [52041,52042]
                                    number: 1 [52042,52043]
            simple_stmt [52053,52099]
                expr_stmt [52053,52098]
                    name: t_1 [52053,52056]
                    operator: = [52057,52058]
                    atom_expr [52059,52098]
                        name: DummyOperator [52059,52072]
                        trailer [52072,52098]
                            arglist [52073,52097]
                                argument [52073,52088]
                                    name: task_id [52073,52080]
                                    operator: = [52080,52081]
                                    name: task_id [52081,52088]
                                operator: , [52088,52089]
                                argument [52090,52097]
                                    name: dag [52090,52093]
                                    operator: = [52093,52094]
                                    name: dag [52094,52097]
            simple_stmt [52107,52182]
                expr_stmt [52107,52181]
                    name: subdag [52107,52113]
                    operator: = [52114,52115]
                    atom_expr [52116,52181]
                        name: DAG [52116,52119]
                        trailer [52119,52181]
                            arglist [52120,52180]
                                arith_expr [52120,52136]
                                    name: dag_id [52120,52126]
                                    operator: + [52127,52128]
                                    string: '.test' [52129,52136]
                                operator: , [52136,52137]
                                argument [52138,52161]
                                    name: start_date [52138,52148]
                                    operator: = [52148,52149]
                                    name: DEFAULT_DATE [52149,52161]
                                operator: , [52161,52162]
                                argument [52163,52180]
                                    name: max_active_runs [52163,52178]
                                    operator: = [52178,52179]
                                    number: 1 [52179,52180]
            simple_stmt [52190,52245]
                atom_expr [52190,52244]
                    name: SubDagOperator [52190,52204]
                    trailer [52204,52244]
                        arglist [52205,52243]
                            argument [52205,52219]
                                name: task_id [52205,52212]
                                operator: = [52212,52213]
                                string: 'test' [52213,52219]
                            operator: , [52219,52220]
                            argument [52221,52234]
                                name: subdag [52221,52227]
                                operator: = [52227,52228]
                                name: subdag [52228,52234]
                            operator: , [52234,52235]
                            argument [52236,52243]
                                name: dag [52236,52239]
                                operator: = [52239,52240]
                                name: dag [52240,52243]
            simple_stmt [52253,52301]
                expr_stmt [52253,52300]
                    name: t_2 [52253,52256]
                    operator: = [52257,52258]
                    atom_expr [52259,52300]
                        name: DummyOperator [52259,52272]
                        trailer [52272,52300]
                            arglist [52273,52299]
                                argument [52273,52287]
                                    name: task_id [52273,52280]
                                    operator: = [52280,52281]
                                    string: 'task' [52281,52287]
                                operator: , [52287,52288]
                                argument [52289,52299]
                                    name: dag [52289,52292]
                                    operator: = [52292,52293]
                                    name: subdag [52293,52299]
            simple_stmt [52309,52333]
                expr_stmt [52309,52332]
                    atom_expr [52309,52326]
                        name: subdag [52309,52315]
                        trailer [52315,52326]
                            name: parent_dag [52316,52326]
                    operator: = [52327,52328]
                    name: dag [52329,52332]
            simple_stmt [52341,52365]
                expr_stmt [52341,52364]
                    atom_expr [52341,52357]
                        name: subdag [52341,52347]
                        trailer [52347,52357]
                            name: is_subdag [52348,52357]
                    operator: = [52358,52359]
            simple_stmt [52374,52403]
                expr_stmt [52374,52402]
                    name: session [52374,52381]
                    operator: = [52382,52383]
                    atom_expr [52384,52402]
                        name: settings [52384,52392]
                        trailer [52392,52400]
                            name: Session [52393,52400]
                        trailer [52400,52402]
            simple_stmt [52411,52607]
                expr_stmt [52411,52606]
                    name: dagrun_1 [52411,52419]
                    operator: = [52420,52421]
                    atom_expr [52422,52606]
                        name: dag [52422,52425]
                        trailer [52425,52439]
                            name: create_dagrun [52426,52439]
                        trailer [52439,52606]
                            arglist [52453,52596]
                                argument [52453,52485]
                                    name: run_type [52453,52461]
                                    operator: = [52461,52462]
                                    atom_expr [52462,52485]
                                        name: DagRunType [52462,52472]
                                        trailer [52472,52485]
                                            name: BACKFILL_JOB [52473,52485]
                                operator: , [52485,52486]
                                argument [52499,52517]
                                    name: state [52499,52504]
                                    operator: = [52504,52505]
                                    atom_expr [52505,52517]
                                        name: State [52505,52510]
                                        trailer [52510,52517]
                                            name: FAILED [52511,52517]
                                operator: , [52517,52518]
                                argument [52531,52554]
                                    name: start_date [52531,52541]
                                    operator: = [52541,52542]
                                    name: DEFAULT_DATE [52542,52554]
                                operator: , [52554,52555]
                                argument [52568,52595]
                                    name: execution_date [52568,52582]
                                    operator: = [52582,52583]
                                    name: DEFAULT_DATE [52583,52595]
                                operator: , [52595,52596]
            simple_stmt [52615,52814]
                expr_stmt [52615,52813]
                    name: dagrun_2 [52615,52623]
                    operator: = [52624,52625]
                    atom_expr [52626,52813]
                        name: subdag [52626,52632]
                        trailer [52632,52646]
                            name: create_dagrun [52633,52646]
                        trailer [52646,52813]
                            arglist [52660,52803]
                                argument [52660,52692]
                                    name: run_type [52660,52668]
                                    operator: = [52668,52669]
                                    atom_expr [52669,52692]
                                        name: DagRunType [52669,52679]
                                        trailer [52679,52692]
                                            name: BACKFILL_JOB [52680,52692]
                                operator: , [52692,52693]
                                argument [52706,52724]
                                    name: state [52706,52711]
                                    operator: = [52711,52712]
                                    atom_expr [52712,52724]
                                        name: State [52712,52717]
                                        trailer [52717,52724]
                                            name: FAILED [52718,52724]
                                operator: , [52724,52725]
                                argument [52738,52761]
                                    name: start_date [52738,52748]
                                    operator: = [52748,52749]
                                    name: DEFAULT_DATE [52749,52761]
                                operator: , [52761,52762]
                                argument [52775,52802]
                                    name: execution_date [52775,52789]
                                    operator: = [52789,52790]
                                    name: DEFAULT_DATE [52790,52802]
                                operator: , [52802,52803]
            simple_stmt [52822,52846]
                atom_expr [52822,52845]
                    name: session [52822,52829]
                    trailer [52829,52835]
                        name: merge [52830,52835]
                    trailer [52835,52845]
                        name: dagrun_1 [52836,52844]
            simple_stmt [52854,52878]
                atom_expr [52854,52877]
                    name: session [52854,52861]
                    trailer [52861,52867]
                        name: merge [52862,52867]
                    trailer [52867,52877]
                        name: dagrun_2 [52868,52876]
            simple_stmt [52886,52962]
                expr_stmt [52886,52961]
                    name: task_instance_1 [52886,52901]
                    operator: = [52902,52903]
                    atom_expr [52904,52961]
                        name: TI [52904,52906]
                        trailer [52906,52961]
                            arglist [52907,52960]
                                name: t_1 [52907,52910]
                                operator: , [52910,52911]
                                argument [52912,52939]
                                    name: execution_date [52912,52926]
                                    operator: = [52926,52927]
                                    name: DEFAULT_DATE [52927,52939]
                                operator: , [52939,52940]
                                argument [52941,52960]
                                    name: state [52941,52946]
                                    operator: = [52946,52947]
                                    atom_expr [52947,52960]
                                        name: State [52947,52952]
                                        trailer [52952,52960]
                                            name: RUNNING [52953,52960]
            simple_stmt [52970,53046]
                expr_stmt [52970,53045]
                    name: task_instance_2 [52970,52985]
                    operator: = [52986,52987]
                    atom_expr [52988,53045]
                        name: TI [52988,52990]
                        trailer [52990,53045]
                            arglist [52991,53044]
                                name: t_2 [52991,52994]
                                operator: , [52994,52995]
                                argument [52996,53023]
                                    name: execution_date [52996,53010]
                                    operator: = [53010,53011]
                                    name: DEFAULT_DATE [53011,53023]
                                operator: , [53023,53024]
                                argument [53025,53044]
                                    name: state [53025,53030]
                                    operator: = [53030,53031]
                                    atom_expr [53031,53044]
                                        name: State [53031,53036]
                                        trailer [53036,53044]
                                            name: RUNNING [53037,53044]
            simple_stmt [53054,53085]
                atom_expr [53054,53084]
                    name: session [53054,53061]
                    trailer [53061,53067]
                        name: merge [53062,53067]
                    trailer [53067,53084]
                        name: task_instance_1 [53068,53083]
            simple_stmt [53093,53124]
                atom_expr [53093,53123]
                    name: session [53093,53100]
                    trailer [53100,53106]
                        name: merge [53101,53106]
                    trailer [53106,53123]
                        name: task_instance_2 [53107,53122]
            simple_stmt [53132,53149]
                atom_expr [53132,53148]
                    name: session [53132,53139]
                    trailer [53139,53146]
                        name: commit [53140,53146]
                    trailer [53146,53148]
            simple_stmt [53158,53423]
                atom_expr [53158,53422]
                    name: subdag [53158,53164]
                    trailer [53164,53170]
                        name: clear [53165,53170]
                    trailer [53170,53422]
                        arglist [53184,53412]
                            argument [53184,53207]
                                name: start_date [53184,53194]
                                operator: = [53194,53195]
                                name: DEFAULT_DATE [53195,53207]
                            operator: , [53207,53208]
                            argument [53221,53271]
                                name: end_date [53221,53229]
                                operator: = [53229,53230]
                                arith_expr [53230,53271]
                                    name: DEFAULT_DATE [53230,53242]
                                    operator: + [53243,53244]
                                    atom_expr [53245,53271]
                                        name: datetime [53245,53253]
                                        trailer [53253,53263]
                                            name: timedelta [53254,53263]
                                        trailer [53263,53271]
                                            argument [53264,53270]
                                                name: days [53264,53268]
                                                operator: = [53268,53269]
                                                number: 1 [53269,53270]
                            operator: , [53271,53272]
                            argument [53285,53312]
                                name: dag_run_state [53285,53298]
                                operator: = [53298,53299]
                                name: dag_run_state [53299,53312]
                            operator: , [53312,53313]
                            argument [53326,53346]
                                name: include_subdags [53326,53341]
                                operator: = [53341,53342]
                            operator: , [53346,53347]
                            argument [53360,53382]
                                name: include_parentdag [53360,53377]
                                operator: = [53377,53378]
                            operator: , [53382,53383]
                            argument [53396,53411]
                                name: session [53396,53403]
                                operator: = [53403,53404]
                                name: session [53404,53411]
                            operator: , [53411,53412]
            simple_stmt [53432,53582]
                expr_stmt [53432,53581]
                    name: dagrun [53432,53438]
                    operator: = [53439,53440]
                    atom [53441,53581]
                        atom_expr [53455,53571]
                            name: session [53455,53462]
                            trailer [53462,53468]
                                name: query [53463,53468]
                            trailer [53468,53507]
                                arglist [53486,53493]
                                    name: DagRun [53486,53492]
                                    operator: , [53492,53493]
                            trailer [53520,53527]
                                name: filter [53521,53527]
                            trailer [53527,53552]
                                comparison [53528,53551]
                                    atom_expr [53528,53541]
                                        name: DagRun [53528,53534]
                                        trailer [53534,53541]
                                            name: dag_id [53535,53541]
                                    operator: == [53542,53544]
                                    name: dag_id [53545,53551]
                            trailer [53565,53569]
                                name: one [53566,53569]
                            trailer [53569,53571]
            simple_stmt [53590,53627]
                assert_stmt [53590,53626]
                    comparison [53597,53626]
                        atom_expr [53597,53609]
                            name: dagrun [53597,53603]
                            trailer [53603,53609]
                                name: state [53604,53609]
                        operator: == [53610,53612]
                        name: dag_run_state [53613,53626]
to
suite [2433,62264]
at 65
===
delete-node
---
name: TestDag [2406,2413]
===
