===
match
---
name: orm_tag [77012,77019]
name: orm_tag [77063,77070]
===
match
---
operator: = [19915,19916]
operator: = [19915,19916]
===
match
---
return_stmt [78239,78295]
return_stmt [78290,78346]
===
match
---
trailer [49128,49137]
trailer [49128,49137]
===
match
---
operator: , [9748,9749]
operator: , [9748,9749]
===
match
---
name: setter [29038,29044]
name: setter [29038,29044]
===
match
---
name: t [26509,26510]
name: t [26509,26510]
===
match
---
name: resolve_template_files [39163,39185]
name: resolve_template_files [39163,39185]
===
match
---
param [28455,28468]
param [28455,28468]
===
match
---
trailer [74666,74675]
trailer [74717,74726]
===
match
---
name: get_dagmodel [86482,86494]
name: get_dagmodel [86533,86545]
===
match
---
trailer [87982,87984]
trailer [88033,88035]
===
match
---
trailer [91131,91140]
trailer [91182,91191]
===
match
---
trailer [48796,48804]
trailer [48796,48804]
===
match
---
name: session [3445,3452]
name: session [3445,3452]
===
match
---
operator: = [85821,85822]
operator: = [85872,85873]
===
match
---
atom_expr [52866,52896]
atom_expr [52917,52947]
===
match
---
name: is_active [79505,79514]
name: is_active [79556,79565]
===
match
---
testlist_comp [77467,77498]
testlist_comp [77518,77549]
===
match
---
trailer [32005,32093]
trailer [32005,32093]
===
match
---
name: start_date [55854,55864]
name: start_date [55905,55915]
===
match
---
operator: } [16158,16159]
operator: } [16158,16159]
===
match
---
name: property [29495,29503]
name: property [29495,29503]
===
match
---
operator: = [93394,93395]
operator: = [93445,93446]
===
match
---
name: fileloc [84914,84921]
name: fileloc [84965,84972]
===
match
---
operator: = [83340,83341]
operator: = [83391,83392]
===
match
---
simple_stmt [19509,19522]
simple_stmt [19509,19522]
===
match
---
expr_stmt [74528,74545]
expr_stmt [74579,74596]
===
match
---
name: now [24623,24626]
name: now [24623,24626]
===
match
---
name: dag [56142,56145]
name: dag [56193,56196]
===
match
---
name: convert_to_utc [20739,20753]
name: convert_to_utc [20739,20753]
===
match
---
atom_expr [62819,62875]
atom_expr [62870,62926]
===
match
---
operator: , [20827,20828]
operator: , [20827,20828]
===
match
---
name: task [42771,42775]
name: task [42771,42775]
===
match
---
name: task_dict [59900,59909]
name: task_dict [59951,59960]
===
match
---
name: dttm [21181,21185]
name: dttm [21181,21185]
===
match
---
trailer [37044,37050]
trailer [37044,37050]
===
match
---
return_stmt [32102,32141]
return_stmt [32102,32141]
===
match
---
name: self [29923,29927]
name: self [29923,29927]
===
match
---
arglist [85433,85456]
arglist [85484,85507]
===
match
---
trailer [73732,73737]
trailer [73783,73788]
===
match
---
param [88831,88861]
param [88882,88912]
===
match
---
param [34095,34107]
param [34095,34107]
===
match
---
name: _dag_id [29100,29107]
name: _dag_id [29100,29107]
===
match
---
name: __eq__ [16171,16177]
name: __eq__ [16171,16177]
===
match
---
simple_stmt [95332,95363]
simple_stmt [95383,95414]
===
match
---
atom_expr [66266,66274]
atom_expr [66317,66325]
===
match
---
name: Integer [85366,85373]
name: Integer [85417,85424]
===
match
---
operator: -> [42589,42591]
operator: -> [42589,42591]
===
match
---
atom [36905,37062]
atom [36905,37062]
===
match
---
suite [42374,42553]
suite [42374,42553]
===
match
---
operator: = [25265,25266]
operator: = [25265,25266]
===
match
---
simple_stmt [51764,51807]
simple_stmt [51815,51858]
===
match
---
trailer [10639,10646]
trailer [10639,10646]
===
match
---
operator: = [46288,46289]
operator: = [46288,46289]
===
match
---
name: task_id [63432,63439]
name: task_id [63483,63490]
===
match
---
parameters [60906,60927]
parameters [60957,60978]
===
match
---
trailer [75490,75498]
trailer [75541,75549]
===
match
---
atom_expr [13927,13951]
atom_expr [13927,13951]
===
match
---
suite [80800,80868]
suite [80851,80919]
===
match
---
name: only_failed [53648,53659]
name: only_failed [53699,53710]
===
match
---
operator: , [82112,82113]
operator: , [82163,82164]
===
match
---
name: description [29737,29748]
name: description [29737,29748]
===
match
---
trailer [74830,74879]
trailer [74881,74930]
===
match
---
operator: - [63722,63723]
operator: - [63773,63774]
===
match
---
name: cls [95490,95493]
name: cls [95541,95544]
===
match
---
name: following [20322,20331]
name: following [20322,20331]
===
match
---
operator: , [81915,81916]
operator: , [81966,81967]
===
match
---
name: start_date [10102,10112]
name: start_date [10102,10112]
===
match
---
arith_expr [21545,21576]
arith_expr [21545,21576]
===
match
---
name: Optional [69988,69996]
name: Optional [70039,70047]
===
match
---
operator: == [52664,52666]
operator: == [52715,52717]
===
match
---
comparison [41068,41102]
comparison [41068,41102]
===
match
---
atom_expr [11558,11583]
atom_expr [11558,11583]
===
match
---
trailer [95568,95599]
trailer [95619,95650]
===
match
---
argument [57346,57377]
argument [57397,57428]
===
match
---
name: start_date [41147,41157]
name: start_date [41147,41157]
===
match
---
argument [72311,72344]
argument [72362,72395]
===
match
---
trailer [78921,78926]
trailer [78972,78977]
===
match
---
suite [65668,65711]
suite [65719,65762]
===
match
---
atom_expr [41844,41884]
atom_expr [41844,41884]
===
match
---
name: EdgeInfoType [82903,82915]
name: EdgeInfoType [82954,82966]
===
match
---
name: dag_id [93287,93293]
name: dag_id [93338,93344]
===
match
---
tfpdef [23303,23358]
tfpdef [23303,23358]
===
match
---
trailer [41486,41527]
trailer [41486,41527]
===
match
---
simple_stmt [69826,69853]
simple_stmt [69877,69904]
===
match
---
name: cls [95454,95457]
name: cls [95505,95508]
===
match
---
atom_expr [41197,41206]
atom_expr [41197,41206]
===
match
---
argument [55470,55485]
argument [55521,55536]
===
match
---
name: DeprecationWarning [33093,33111]
name: DeprecationWarning [33093,33111]
===
match
---
not_test [12879,12896]
not_test [12879,12896]
===
match
---
name: LocalExecutor [68885,68898]
name: LocalExecutor [68936,68949]
===
match
---
operator: @ [36546,36547]
operator: @ [36546,36547]
===
match
---
atom_expr [93296,93346]
atom_expr [93347,93397]
===
match
---
simple_stmt [15961,16018]
simple_stmt [15961,16018]
===
match
---
trailer [10903,10935]
trailer [10903,10935]
===
match
---
trailer [16942,16947]
trailer [16942,16947]
===
match
---
string: 'core' [10576,10582]
string: 'core' [10576,10582]
===
match
---
name: len [73754,73757]
name: len [73805,73808]
===
match
---
suite [30742,30786]
suite [30742,30786]
===
match
---
name: dag [91606,91609]
name: dag [91657,91660]
===
match
---
name: property [29315,29323]
name: property [29315,29323]
===
match
---
name: merge [79805,79810]
name: merge [79856,79861]
===
match
---
trailer [19386,19396]
trailer [19386,19396]
===
match
---
comparison [13033,13064]
comparison [13033,13064]
===
match
---
atom_expr [71768,71800]
atom_expr [71819,71851]
===
match
---
trailer [40962,40970]
trailer [40962,40970]
===
match
---
string: 'core' [10647,10653]
string: 'core' [10647,10653]
===
match
---
decorator [33190,33200]
decorator [33190,33200]
===
match
---
name: tuple [16813,16818]
name: tuple [16813,16818]
===
match
---
name: template_undefined [14008,14026]
name: template_undefined [14008,14026]
===
match
---
name: count [55117,55122]
name: count [55168,55173]
===
match
---
trailer [27925,27932]
trailer [27925,27932]
===
match
---
operator: , [85926,85927]
operator: , [85977,85978]
===
match
---
name: Column [84995,85001]
name: Column [85046,85052]
===
match
---
string: 'start_date' [12648,12660]
string: 'start_date' [12648,12660]
===
match
---
simple_stmt [85663,85836]
simple_stmt [85714,85887]
===
match
---
trailer [60188,60196]
trailer [60239,60247]
===
match
---
trailer [51418,51445]
trailer [51469,51496]
===
match
---
name: _downstream_task_ids [62796,62816]
name: _downstream_task_ids [62847,62867]
===
match
---
atom_expr [76434,76459]
atom_expr [76485,76510]
===
match
---
suite [56724,56785]
suite [56775,56836]
===
match
---
name: TaskInstance [81072,81084]
name: TaskInstance [81123,81135]
===
match
---
name: clear [57103,57108]
name: clear [57154,57159]
===
match
---
name: only_failed [55902,55913]
name: only_failed [55953,55964]
===
match
---
trailer [41054,41239]
trailer [41054,41239]
===
match
---
name: confirm_prompt [53772,53786]
name: confirm_prompt [53823,53837]
===
match
---
simple_stmt [74126,74186]
simple_stmt [74177,74237]
===
match
---
trailer [71884,71894]
trailer [71935,71945]
===
match
---
name: end_date [46044,46052]
name: end_date [46044,46052]
===
match
---
trailer [81451,81484]
trailer [81502,81535]
===
match
---
atom_expr [95068,95081]
atom_expr [95119,95132]
===
match
---
name: orm_dags [77490,77498]
name: orm_dags [77541,77549]
===
match
---
name: timedelta [40887,40896]
name: timedelta [40887,40896]
===
match
---
comparison [37708,37741]
comparison [37708,37741]
===
match
---
trailer [15416,15426]
trailer [15416,15426]
===
match
---
fstring [14807,14858]
fstring [14807,14858]
===
match
---
operator: = [67157,67158]
operator: = [67208,67209]
===
match
---
name: task_ids [49129,49137]
name: task_ids [49129,49137]
===
match
---
expr_stmt [21824,21865]
expr_stmt [21824,21865]
===
match
---
name: next_execution_date [23160,23179]
name: next_execution_date [23160,23179]
===
match
---
trailer [75566,75583]
trailer [75617,75634]
===
match
---
operator: = [32486,32487]
operator: = [32486,32487]
===
match
---
simple_stmt [41470,41528]
simple_stmt [41470,41528]
===
match
---
name: only_running [49658,49670]
name: only_running [49709,49721]
===
match
---
argument [72711,72726]
argument [72762,72777]
===
match
---
fstring_start: f" [66129,66131]
fstring_start: f" [66180,66182]
===
match
---
trailer [85155,85159]
trailer [85206,85210]
===
match
---
param [92776,92784]
param [92827,92835]
===
match
---
name: filter [80995,81001]
name: filter [81046,81052]
===
match
---
name: last_parsed_time [79460,79476]
name: last_parsed_time [79511,79527]
===
match
---
name: DagParam [30397,30405]
name: DagParam [30397,30405]
===
match
---
trailer [33757,33781]
trailer [33757,33781]
===
match
---
funcdef [32840,33185]
funcdef [32840,33185]
===
match
---
trailer [64192,64194]
trailer [64243,64245]
===
match
---
suite [57494,57570]
suite [57545,57621]
===
match
---
decorated [31144,31305]
decorated [31144,31305]
===
match
---
simple_stmt [60431,60483]
simple_stmt [60482,60534]
===
match
---
argument [49400,49423]
argument [49451,49474]
===
match
---
name: dag_id [88572,88578]
name: dag_id [88623,88629]
===
match
---
name: self [64229,64233]
name: self [64280,64284]
===
match
---
trailer [69800,69817]
trailer [69851,69868]
===
match
---
return_stmt [28024,28040]
return_stmt [28024,28040]
===
match
---
atom_expr [66441,66456]
atom_expr [66492,66507]
===
match
---
name: Optional [11254,11262]
name: Optional [11254,11262]
===
match
---
suite [19777,20651]
suite [19777,20651]
===
match
---
name: session [64362,64369]
name: session [64413,64420]
===
match
---
atom_expr [21188,21211]
atom_expr [21188,21211]
===
match
---
name: include_subdags [63108,63123]
name: include_subdags [63159,63174]
===
match
---
trailer [22639,22657]
trailer [22639,22657]
===
match
---
for_stmt [44631,45132]
for_stmt [44631,45132]
===
match
---
operator: , [1393,1394]
operator: , [1393,1394]
===
match
---
name: template_searchpath [13898,13917]
name: template_searchpath [13898,13917]
===
match
---
operator: = [74210,74211]
operator: = [74261,74262]
===
match
---
atom_expr [78043,78081]
atom_expr [78094,78132]
===
match
---
trailer [10268,10295]
trailer [10268,10295]
===
match
---
string: '_pickle_id' [81782,81794]
string: '_pickle_id' [81833,81845]
===
match
---
name: dag [64262,64265]
name: dag [64313,64316]
===
match
---
argument [93113,93121]
argument [93164,93172]
===
match
---
name: str [10289,10292]
name: str [10289,10292]
===
match
---
name: State [35665,35670]
name: State [35665,35670]
===
match
---
expr_stmt [62934,62952]
expr_stmt [62985,63003]
===
match
---
if_stmt [40822,41005]
if_stmt [40822,41005]
===
match
---
atom_expr [10209,10222]
atom_expr [10209,10222]
===
match
---
trailer [57767,57775]
trailer [57818,57826]
===
match
---
string: "Deactivating DAGs (for which DAG files are deleted) from %s table " [89187,89255]
string: "Deactivating DAGs (for which DAG files are deleted) from %s table " [89238,89306]
===
match
---
operator: < [62903,62904]
operator: < [62954,62955]
===
match
---
trailer [53595,53610]
trailer [53646,53661]
===
match
---
trailer [49338,49341]
trailer [49389,49392]
===
match
---
name: self [86060,86064]
name: self [86111,86115]
===
match
---
atom [60002,60020]
atom [60053,60071]
===
match
---
trailer [43611,43617]
trailer [43611,43617]
===
match
---
name: parent_dag [75973,75983]
name: parent_dag [76024,76034]
===
match
---
name: timezone [20616,20624]
name: timezone [20616,20624]
===
match
---
trailer [81001,81123]
trailer [81052,81174]
===
match
---
name: filter [50597,50603]
name: filter [50648,50654]
===
match
---
trailer [50325,50340]
trailer [50376,50391]
===
match
---
simple_stmt [23002,23022]
simple_stmt [23002,23022]
===
match
---
param [42583,42587]
param [42583,42587]
===
match
---
name: name [83454,83458]
name: name [83505,83509]
===
match
---
name: FrozenSet [1101,1110]
name: FrozenSet [1101,1110]
===
match
---
name: include_externally_triggered [28469,28497]
name: include_externally_triggered [28469,28497]
===
match
---
suite [26667,26696]
suite [26667,26696]
===
match
---
simple_stmt [1218,1234]
simple_stmt [1218,1234]
===
match
---
name: orm_dag [76275,76282]
name: orm_dag [76326,76333]
===
match
---
operator: -> [64458,64460]
operator: -> [64509,64511]
===
match
---
trailer [62504,62524]
trailer [62555,62575]
===
match
---
atom_expr [12619,12667]
atom_expr [12619,12667]
===
match
---
trailer [39467,39487]
trailer [39467,39487]
===
match
---
funcdef [69909,72748]
funcdef [69960,72799]
===
match
---
name: date_last_automated_dagrun [25582,25608]
name: date_last_automated_dagrun [25582,25608]
===
match
---
name: downstream [53136,53146]
name: downstream [53187,53197]
===
match
---
name: default [84065,84072]
name: default [84116,84123]
===
match
---
trailer [83084,83094]
trailer [83135,83145]
===
match
---
operator: , [3090,3091]
operator: , [3090,3091]
===
match
---
name: date_last_automated_dagrun [25501,25527]
name: date_last_automated_dagrun [25501,25527]
===
match
---
name: graph_unsorted [43728,43742]
name: graph_unsorted [43728,43742]
===
match
---
trailer [10288,10293]
trailer [10288,10293]
===
match
---
string: 'safe_dag_id' [81580,81593]
string: 'safe_dag_id' [81631,81644]
===
match
---
operator: , [56427,56428]
operator: , [56478,56479]
===
match
---
parameters [19549,19561]
parameters [19549,19561]
===
match
---
name: self [16658,16662]
name: self [16658,16662]
===
match
---
name: matched_tasks [60263,60276]
name: matched_tasks [60314,60327]
===
match
---
name: self [57613,57617]
name: self [57664,57668]
===
match
---
name: dttm [28347,28351]
name: dttm [28347,28351]
===
match
---
for_stmt [78775,78927]
for_stmt [78826,78978]
===
match
---
name: run_id [71910,71916]
name: run_id [71961,71967]
===
match
---
atom_expr [25642,25680]
atom_expr [25642,25680]
===
match
---
if_stmt [61264,61826]
if_stmt [61315,61877]
===
match
---
return_stmt [78322,78346]
return_stmt [78373,78397]
===
match
---
name: self [36582,36586]
name: self [36582,36586]
===
match
---
string: 'start_date' [12589,12601]
string: 'start_date' [12589,12601]
===
match
---
name: airflow [50676,50683]
name: airflow [50727,50734]
===
match
---
name: include_subdags [46152,46167]
name: include_subdags [46152,46167]
===
match
---
testlist_comp [3002,3055]
testlist_comp [3002,3055]
===
match
---
name: query [63992,63997]
name: query [64043,64048]
===
match
---
atom_expr [52940,52967]
atom_expr [52991,53018]
===
match
---
name: _concurrency [29378,29390]
name: _concurrency [29378,29390]
===
match
---
operator: , [56340,56341]
operator: , [56391,56392]
===
match
---
trailer [75732,75739]
trailer [75783,75790]
===
match
---
name: result [58254,58260]
name: result [58305,58311]
===
match
---
atom_expr [58141,58154]
atom_expr [58192,58205]
===
match
---
trailer [40669,40678]
trailer [40669,40678]
===
match
---
parameters [63935,63955]
parameters [63986,64006]
===
match
---
name: query [45717,45722]
name: query [45717,45722]
===
match
---
operator: = [69268,69269]
operator: = [69319,69320]
===
match
---
atom_expr [14413,14431]
atom_expr [14413,14431]
===
match
---
name: orm_tag [76967,76974]
name: orm_tag [77018,77025]
===
match
---
trailer [89311,89316]
trailer [89362,89367]
===
match
---
trailer [51987,52378]
trailer [52038,52429]
===
match
---
name: last_loaded [14119,14130]
name: last_loaded [14119,14130]
===
match
---
suite [40813,42317]
suite [40813,42317]
===
match
---
operator: = [85450,85451]
operator: = [85501,85502]
===
match
---
trailer [80830,80837]
trailer [80881,80888]
===
match
---
atom_expr [74369,74395]
atom_expr [74420,74446]
===
match
---
param [92147,92157]
param [92198,92208]
===
match
---
atom_expr [27489,27499]
atom_expr [27489,27499]
===
match
---
trailer [76688,76830]
trailer [76739,76881]
===
match
---
name: filter [64008,64014]
name: filter [64059,64065]
===
match
---
suite [21464,21644]
suite [21464,21644]
===
match
---
operator: = [51074,51075]
operator: = [51125,51126]
===
match
---
operator: @ [81240,81241]
operator: @ [81291,81292]
===
match
---
name: update [11848,11854]
name: update [11848,11854]
===
match
---
operator: -> [30487,30489]
operator: -> [30487,30489]
===
match
---
operator: -> [32610,32612]
operator: -> [32610,32612]
===
match
---
name: conf [70158,70162]
name: conf [70209,70213]
===
match
---
name: task [65113,65117]
name: task [65164,65168]
===
match
---
argument [69801,69816]
argument [69852,69867]
===
match
---
name: self [24546,24550]
name: self [24546,24550]
===
match
---
name: confirm_prompt [49707,49721]
name: confirm_prompt [49758,49772]
===
match
---
tfpdef [9984,10010]
tfpdef [9984,10010]
===
match
---
name: pendulum [20500,20508]
name: pendulum [20500,20508]
===
match
---
string: "DAG" [73263,73268]
string: "DAG" [73314,73319]
===
match
---
atom [83124,83126]
atom [83175,83177]
===
match
---
trailer [16091,16097]
trailer [16091,16097]
===
match
---
name: execution_date [74863,74877]
name: execution_date [74914,74928]
===
match
---
name: str [29767,29770]
name: str [29767,29770]
===
match
---
operator: , [70051,70052]
operator: , [70102,70103]
===
match
---
atom_expr [27976,28014]
atom_expr [27976,28014]
===
match
---
param [30019,30024]
param [30019,30024]
===
match
---
param [46152,46173]
param [46152,46173]
===
match
---
trailer [88462,88469]
trailer [88513,88520]
===
match
---
atom_expr [83342,83408]
atom_expr [83393,83459]
===
match
---
name: utils [2154,2159]
name: utils [2154,2159]
===
match
---
name: TaskInstance [42205,42217]
name: TaskInstance [42205,42217]
===
match
---
trailer [76441,76459]
trailer [76492,76510]
===
match
---
if_stmt [19406,19500]
if_stmt [19406,19500]
===
match
---
atom [60243,60245]
atom [60294,60296]
===
match
---
return_stmt [82708,82783]
return_stmt [82759,82834]
===
match
---
funcdef [29049,29116]
funcdef [29049,29116]
===
match
---
operator: } [11702,11703]
operator: } [11702,11703]
===
match
---
trailer [76503,76515]
trailer [76554,76566]
===
match
---
trailer [38932,38941]
trailer [38932,38941]
===
match
---
atom_expr [61862,61877]
atom_expr [61913,61928]
===
match
---
name: ti_list [56824,56831]
name: ti_list [56875,56882]
===
match
---
atom_expr [25798,25813]
atom_expr [25798,25813]
===
match
---
trailer [13545,13559]
trailer [13545,13559]
===
match
---
param [78108,78112]
param [78159,78163]
===
match
---
name: hash_components [17038,17053]
name: hash_components [17038,17053]
===
match
---
atom_expr [90626,90924]
atom_expr [90677,90975]
===
match
---
trailer [73757,73763]
trailer [73808,73814]
===
match
---
param [86394,86398]
param [86445,86449]
===
match
---
name: provide_session [28654,28669]
name: provide_session [28654,28669]
===
match
---
operator: = [85520,85521]
operator: = [85571,85572]
===
match
---
name: concurrency [29332,29343]
name: concurrency [29332,29343]
===
match
---
atom_expr [48792,48804]
atom_expr [48792,48804]
===
match
---
name: get [93321,93324]
name: get [93372,93375]
===
match
---
trailer [75065,75074]
trailer [75116,75125]
===
match
---
param [64941,64945]
param [64992,64996]
===
match
---
name: c [16387,16388]
name: c [16387,16388]
===
match
---
name: partial_subset [58588,58602]
name: partial_subset [58639,58653]
===
match
---
trailer [3560,3590]
trailer [3560,3590]
===
match
---
name: safe_dag_id [14164,14175]
name: safe_dag_id [14164,14175]
===
match
---
trailer [41000,41002]
trailer [41000,41002]
===
match
---
trailer [55180,55190]
trailer [55231,55241]
===
match
---
suite [76878,77021]
suite [76929,77072]
===
match
---
expr_stmt [85257,85339]
expr_stmt [85308,85390]
===
match
---
atom [37536,37785]
atom [37536,37785]
===
match
---
operator: = [46078,46079]
operator: = [46078,46079]
===
match
---
name: task [64901,64905]
name: task [64952,64956]
===
match
---
name: t [60779,60780]
name: t [60830,60831]
===
match
---
trailer [85276,85339]
trailer [85327,85390]
===
match
---
name: classmethod [73183,73194]
name: classmethod [73234,73245]
===
match
---
return_stmt [33157,33184]
return_stmt [33157,33184]
===
match
---
operator: = [64122,64123]
operator: = [64173,64174]
===
match
---
name: provide_session [86622,86637]
name: provide_session [86673,86688]
===
match
---
argument [72468,72499]
argument [72519,72550]
===
match
---
trailer [34807,34827]
trailer [34807,34827]
===
match
---
string: """         Deactivate any DAGs that were last touched by the scheduler before         the expiration date. These DAGs were likely deleted.          :param expiration_date: set inactive DAGs that were touched before this             time         :type expiration_date: datetime         :return: None         """ [79062,79373]
string: """         Deactivate any DAGs that were last touched by the scheduler before         the expiration date. These DAGs were likely deleted.          :param expiration_date: set inactive DAGs that were touched before this             time         :type expiration_date: datetime         :return: None         """ [79113,79424]
===
match
---
import_from [910,945]
import_from [910,945]
===
match
---
name: dag [78922,78925]
name: dag [78973,78976]
===
match
---
name: downstream_task_ids [62477,62496]
name: downstream_task_ids [62528,62547]
===
match
---
name: arguments [93311,93320]
name: arguments [93362,93371]
===
match
---
operator: , [20591,20592]
operator: , [20591,20592]
===
match
---
operator: , [79922,79923]
operator: , [79973,79974]
===
match
---
operator: , [23158,23159]
operator: , [23158,23159]
===
match
---
name: execution_date [41129,41143]
name: execution_date [41129,41143]
===
match
---
simple_stmt [14976,15056]
simple_stmt [14976,15056]
===
match
---
suite [50658,54504]
suite [50709,54555]
===
match
---
param [32596,32608]
param [32596,32608]
===
match
---
tfpdef [91083,91091]
tfpdef [91134,91142]
===
match
---
simple_stmt [61777,61826]
simple_stmt [61828,61877]
===
match
---
atom [82817,82819]
atom [82868,82870]
===
match
---
name: DR [3459,3461]
name: DR [3459,3461]
===
match
---
name: Column [84152,84158]
name: Column [84203,84209]
===
match
---
suite [73285,77758]
suite [73336,77809]
===
match
---
name: Optional [70031,70039]
name: Optional [70082,70090]
===
match
---
name: fallback [85928,85936]
name: fallback [85979,85987]
===
match
---
name: dag_model [89471,89480]
name: dag_model [89522,89531]
===
match
---
argument [49692,49721]
argument [49743,49772]
===
match
---
name: self [59881,59885]
name: self [59932,59936]
===
match
---
name: provide_session [86763,86778]
name: provide_session [86814,86829]
===
match
---
name: utils_date_range [2236,2252]
name: utils_date_range [2236,2252]
===
match
---
operator: , [49342,49343]
operator: , [49393,49394]
===
match
---
atom_expr [10075,10092]
atom_expr [10075,10092]
===
match
---
operator: , [33079,33080]
operator: , [33079,33080]
===
match
---
suite [86322,86362]
suite [86373,86413]
===
match
---
trailer [76863,76877]
trailer [76914,76928]
===
match
---
name: conf [10564,10568]
name: conf [10564,10568]
===
match
---
atom_expr [19429,19441]
atom_expr [19429,19441]
===
match
---
trailer [51082,51090]
trailer [51133,51141]
===
match
---
name: t [27467,27468]
name: t [27467,27468]
===
match
---
number: 0 [78745,78746]
number: 0 [78796,78797]
===
match
---
name: end_date [45854,45862]
name: end_date [45854,45862]
===
match
---
name: dag [76801,76804]
name: dag [76852,76855]
===
match
---
argument [49890,49902]
argument [49941,49953]
===
match
---
trailer [13251,13264]
trailer [13251,13264]
===
match
---
trailer [91555,91572]
trailer [91606,91623]
===
match
---
comp_op [89490,89496]
comp_op [89541,89547]
===
match
---
name: filter_query [88410,88422]
name: filter_query [88461,88473]
===
match
---
name: val [16987,16990]
name: val [16987,16990]
===
match
---
comparison [52646,52702]
comparison [52697,52753]
===
match
---
simple_stmt [56776,56785]
simple_stmt [56827,56836]
===
match
---
name: count [55671,55676]
name: count [55722,55727]
===
match
---
operator: , [57377,57378]
operator: , [57428,57429]
===
match
---
name: nullable [85442,85450]
name: nullable [85493,85501]
===
match
---
name: not_none_state [42073,42087]
name: not_none_state [42073,42087]
===
match
---
name: _dag_id [11972,11979]
name: _dag_id [11972,11979]
===
match
---
trailer [24818,24830]
trailer [24818,24830]
===
match
---
name: set [61088,61091]
name: set [61139,61142]
===
match
---
name: recursion_depth [51539,51554]
name: recursion_depth [51590,51605]
===
match
---
for_stmt [63277,63397]
for_stmt [63328,63448]
===
match
---
trailer [68898,68900]
trailer [68949,68951]
===
match
---
trailer [74597,74604]
trailer [74648,74655]
===
match
---
test [12296,12335]
test [12296,12335]
===
match
---
operator: * [93106,93107]
operator: * [93157,93158]
===
match
---
name: utcnow [18778,18784]
name: utcnow [18778,18784]
===
match
---
arglist [10904,10934]
arglist [10904,10934]
===
match
---
parameters [30722,30728]
parameters [30722,30728]
===
match
---
trailer [44888,44902]
trailer [44888,44902]
===
match
---
name: dp [64063,64065]
name: dp [64114,64116]
===
match
---
name: cron_presets [33694,33706]
name: cron_presets [33694,33706]
===
match
---
return_stmt [28391,28402]
return_stmt [28391,28402]
===
match
---
trailer [62728,62746]
trailer [62779,62797]
===
match
---
operator: , [67025,67026]
operator: , [67076,67077]
===
match
---
param [63942,63954]
param [63993,64005]
===
match
---
import_from [1017,1202]
import_from [1017,1202]
===
match
---
name: int [30032,30035]
name: int [30032,30035]
===
match
---
name: next_dagrun_create_after [91525,91549]
name: next_dagrun_create_after [91576,91600]
===
match
---
name: start_date [56200,56210]
name: start_date [56251,56261]
===
match
---
param [95413,95416]
param [95464,95467]
===
match
---
name: user_defined_filters [10447,10467]
name: user_defined_filters [10447,10467]
===
match
---
argument [56445,56480]
argument [56496,56531]
===
match
---
name: self [69877,69881]
name: self [69928,69932]
===
match
---
name: dag_parser [69801,69811]
name: dag_parser [69852,69862]
===
match
---
operator: = [76353,76354]
operator: = [76404,76405]
===
match
---
fstring_start: f' [14587,14589]
fstring_start: f' [14587,14589]
===
match
---
trailer [13501,13514]
trailer [13501,13514]
===
match
---
atom_expr [35028,35035]
atom_expr [35028,35035]
===
match
---
not_test [16511,16528]
not_test [16511,16528]
===
match
---
suite [51560,51807]
suite [51611,51858]
===
match
---
name: find [35634,35638]
name: find [35634,35638]
===
match
---
suite [44614,45132]
suite [44614,45132]
===
match
---
param [78435,78447]
param [78486,78498]
===
match
---
string: """         Pause/Un-pause a DAG.          :param is_paused: Is the DAG paused         :param including_subdags: whether to include the DAG's subdags         :param session: session         """ [88208,88401]
string: """         Pause/Un-pause a DAG.          :param is_paused: Is the DAG paused         :param including_subdags: whether to include the DAG's subdags         :param session: session         """ [88259,88452]
===
match
---
name: t [76588,76589]
name: t [76639,76640]
===
match
---
name: dag_run_state [56512,56525]
name: dag_run_state [56563,56576]
===
match
---
operator: = [27440,27441]
operator: = [27440,27441]
===
match
---
if_stmt [22618,22863]
if_stmt [22618,22863]
===
match
---
name: end_date [41518,41526]
name: end_date [41518,41526]
===
match
---
name: DagModel [74000,74008]
name: DagModel [74051,74059]
===
match
---
if_stmt [89447,89835]
if_stmt [89498,89886]
===
match
---
name: DateTime [22203,22211]
name: DateTime [22203,22211]
===
match
---
expr_stmt [83530,83551]
expr_stmt [83581,83602]
===
match
---
subscriptlist [10275,10293]
subscriptlist [10275,10293]
===
match
---
operator: = [69075,69076]
operator: = [69126,69127]
===
match
---
operator: , [56077,56078]
operator: , [56128,56129]
===
match
---
name: count [55775,55780]
name: count [55826,55831]
===
match
---
operator: , [34066,34067]
operator: , [34066,34067]
===
match
---
trailer [22222,22241]
trailer [22222,22241]
===
match
---
tfpdef [18738,18766]
tfpdef [18738,18766]
===
match
---
name: _comps [9657,9663]
name: _comps [9657,9663]
===
match
---
name: max_recursion_depth [52254,52273]
name: max_recursion_depth [52305,52324]
===
match
---
atom_expr [14159,14175]
atom_expr [14159,14175]
===
match
---
expr_stmt [92615,92648]
expr_stmt [92666,92699]
===
match
---
name: dag_tag_orm [77331,77342]
name: dag_tag_orm [77382,77393]
===
match
---
suite [29855,29890]
suite [29855,29890]
===
match
---
name: DAG [95077,95080]
name: DAG [95128,95131]
===
match
---
name: child [61793,61798]
name: child [61844,61849]
===
match
---
name: local [66835,66840]
name: local [66886,66891]
===
match
---
name: session [37550,37557]
name: session [37550,37557]
===
match
---
simple_stmt [43268,43345]
simple_stmt [43268,43345]
===
match
---
name: state [69950,69955]
name: state [70001,70006]
===
match
---
operator: @ [38488,38489]
operator: @ [38488,38489]
===
match
---
classdef [3742,83155]
classdef [3742,83206]
===
match
---
trailer [78854,78858]
trailer [78905,78909]
===
match
---
trailer [11840,11847]
trailer [11840,11847]
===
match
---
expr_stmt [35689,35706]
expr_stmt [35689,35706]
===
match
---
name: t [62794,62795]
name: t [62845,62846]
===
match
---
trailer [75587,75594]
trailer [75638,75645]
===
match
---
operator: { [63493,63494]
operator: { [63544,63545]
===
match
---
parameters [82373,82427]
parameters [82424,82478]
===
match
---
trailer [56848,56851]
trailer [56899,56902]
===
match
---
name: include_subdags [63248,63263]
name: include_subdags [63299,63314]
===
match
---
name: Column [85063,85069]
name: Column [85114,85120]
===
match
---
name: set_is_paused [88108,88121]
name: set_is_paused [88159,88172]
===
match
---
arglist [75707,75739]
arglist [75758,75790]
===
match
---
name: warn [18349,18353]
name: warn [18349,18353]
===
match
---
trailer [66896,66907]
trailer [66947,66958]
===
match
---
trailer [75475,75481]
trailer [75526,75532]
===
match
---
simple_stmt [25626,25681]
simple_stmt [25626,25681]
===
match
---
name: start_date [45763,45773]
name: start_date [45763,45773]
===
match
---
operator: = [35173,35174]
operator: = [35173,35174]
===
match
---
trailer [84250,84263]
trailer [84301,84314]
===
match
---
name: add [54492,54495]
name: add [54543,54546]
===
match
---
atom [15465,15467]
atom [15465,15467]
===
match
---
trailer [43505,43511]
trailer [43505,43511]
===
match
---
atom [24244,24295]
atom [24244,24295]
===
match
---
trailer [29647,29663]
trailer [29647,29663]
===
match
---
trailer [84055,84079]
trailer [84106,84130]
===
match
---
simple_stmt [76111,76137]
simple_stmt [76162,76188]
===
match
---
not_test [23937,23963]
not_test [23937,23963]
===
match
---
name: query [45816,45821]
name: query [45816,45821]
===
match
---
atom_expr [76040,76060]
atom_expr [76091,76111]
===
match
---
name: vars [81452,81456]
name: vars [81503,81507]
===
match
---
name: end_date [45786,45794]
name: end_date [45786,45794]
===
match
---
expr_stmt [65681,65710]
expr_stmt [65732,65761]
===
match
---
string: 'duration' [3019,3029]
string: 'duration' [3019,3029]
===
match
---
name: session [74817,74824]
name: session [74868,74875]
===
match
---
name: val [17066,17069]
name: val [17066,17069]
===
match
---
trailer [94340,94346]
trailer [94391,94397]
===
match
---
atom_expr [61323,61336]
atom_expr [61374,61387]
===
match
---
name: provide_session [88084,88099]
name: provide_session [88135,88150]
===
match
---
trailer [36305,36312]
trailer [36305,36312]
===
match
---
param [46258,46272]
param [46258,46272]
===
match
---
expr_stmt [25626,25680]
expr_stmt [25626,25680]
===
match
---
atom_expr [38001,38022]
atom_expr [38001,38022]
===
match
---
if_stmt [71484,72139]
if_stmt [71535,72190]
===
match
---
simple_stmt [54471,54504]
simple_stmt [54522,54555]
===
match
---
expr_stmt [79763,79784]
expr_stmt [79814,79835]
===
match
---
name: Callable [3130,3138]
name: Callable [3130,3138]
===
match
---
trailer [57995,58004]
trailer [58046,58055]
===
match
---
atom_expr [65552,65567]
atom_expr [65603,65618]
===
match
---
string: r"^{}$" [49301,49308]
string: r"^{}$" [49352,49359]
===
match
---
atom_expr [89298,89322]
atom_expr [89349,89373]
===
match
---
for_stmt [57066,57481]
for_stmt [57117,57532]
===
match
---
name: all [41783,41786]
name: all [41783,41786]
===
match
---
name: self [29251,29255]
name: self [29251,29255]
===
match
---
name: last_start [24587,24597]
name: last_start [24587,24597]
===
match
---
suite [29454,29489]
suite [29454,29489]
===
match
---
simple_stmt [31191,31254]
simple_stmt [31191,31254]
===
match
---
trailer [45074,45131]
trailer [45074,45131]
===
match
---
argument [84065,84078]
argument [84116,84129]
===
match
---
atom_expr [16369,16444]
atom_expr [16369,16444]
===
match
---
atom [39438,39451]
atom [39438,39451]
===
match
---
name: orm_dag [75833,75840]
name: orm_dag [75884,75891]
===
match
---
param [64452,64456]
param [64503,64507]
===
match
---
name: conf [1580,1584]
name: conf [1580,1584]
===
match
---
param [46122,46143]
param [46122,46143]
===
match
---
name: memo [57789,57793]
name: memo [57840,57844]
===
match
---
operator: @ [29719,29720]
operator: @ [29719,29720]
===
match
---
operator: , [66749,66750]
operator: , [66800,66801]
===
match
---
simple_stmt [42383,42482]
simple_stmt [42383,42482]
===
match
---
if_stmt [93619,93680]
if_stmt [93670,93731]
===
match
---
trailer [21305,21334]
trailer [21305,21334]
===
match
---
name: get_task [51424,51432]
name: get_task [51475,51483]
===
match
---
operator: , [10787,10788]
operator: , [10787,10788]
===
match
---
operator: = [46233,46234]
operator: = [46233,46234]
===
match
---
atom_expr [31534,31541]
atom_expr [31534,31541]
===
match
---
operator: = [33135,33136]
operator: = [33135,33136]
===
match
---
param [36582,36587]
param [36582,36587]
===
match
---
atom [74145,74185]
atom [74196,74236]
===
match
---
trailer [30405,30451]
trailer [30405,30451]
===
match
---
expr_stmt [21593,21643]
expr_stmt [21593,21643]
===
match
---
expr_stmt [83333,83408]
expr_stmt [83384,83459]
===
match
---
parameters [30819,30825]
parameters [30819,30825]
===
match
---
trailer [66386,66398]
trailer [66437,66449]
===
match
---
atom_expr [31975,31997]
atom_expr [31975,31997]
===
match
---
operator: , [45549,45550]
operator: , [45549,45550]
===
match
---
operator: , [93495,93496]
operator: , [93546,93547]
===
match
---
operator: = [28497,28498]
operator: = [28497,28498]
===
match
---
name: val [16876,16879]
name: val [16876,16879]
===
match
---
name: ti [50861,50863]
name: ti [50912,50914]
===
match
---
name: isinstance [13115,13125]
name: isinstance [13115,13125]
===
match
---
name: default_view [78205,78217]
name: default_view [78256,78268]
===
match
---
trailer [57534,57569]
trailer [57585,57620]
===
match
---
operator: , [40797,40798]
operator: , [40797,40798]
===
match
---
trailer [45646,45653]
trailer [45646,45653]
===
match
---
param [17321,17324]
param [17321,17324]
===
match
---
trailer [17255,17261]
trailer [17255,17261]
===
match
---
param [20829,20833]
param [20829,20833]
===
match
---
operator: = [13794,13795]
operator: = [13794,13795]
===
match
---
name: TI [48572,48574]
name: TI [48572,48574]
===
match
---
trailer [75372,75377]
trailer [75423,75428]
===
match
---
name: filter [3463,3469]
name: filter [3463,3469]
===
match
---
parameters [28982,28988]
parameters [28982,28988]
===
match
---
atom_expr [10895,10935]
atom_expr [10895,10935]
===
match
---
trailer [13679,13692]
trailer [13679,13692]
===
match
---
name: doc_md [15784,15790]
name: doc_md [15784,15790]
===
match
---
name: settings [86416,86424]
name: settings [86467,86475]
===
match
---
if_stmt [33621,33974]
if_stmt [33621,33974]
===
match
---
name: self [17205,17209]
name: self [17205,17209]
===
match
---
atom_expr [10564,10602]
atom_expr [10564,10602]
===
match
---
name: tasks [63063,63068]
name: tasks [63114,63119]
===
match
---
expr_stmt [51764,51806]
expr_stmt [51815,51857]
===
match
---
trailer [34910,34915]
trailer [34910,34915]
===
match
---
name: naive [19953,19958]
name: naive [19953,19958]
===
match
---
expr_stmt [74126,74185]
expr_stmt [74177,74236]
===
match
---
atom_expr [72933,73125]
atom_expr [72984,73176]
===
match
---
name: TaskNotFound [63411,63423]
name: TaskNotFound [63462,63474]
===
match
---
suite [78226,78296]
suite [78277,78347]
===
match
---
name: TaskInstance [42090,42102]
name: TaskInstance [42090,42102]
===
match
---
comparison [14363,14399]
comparison [14363,14399]
===
match
---
name: self [29962,29966]
name: self [29962,29966]
===
match
---
expr_stmt [83699,83735]
expr_stmt [83750,83786]
===
match
---
trailer [89969,89971]
trailer [90020,90022]
===
match
---
atom [18124,18126]
atom [18124,18126]
===
match
---
name: dag [76216,76219]
name: dag [76267,76270]
===
match
---
atom_expr [66892,66931]
atom_expr [66943,66982]
===
match
---
name: self [86394,86398]
name: self [86445,86449]
===
match
---
name: len [43603,43606]
name: len [43603,43606]
===
match
---
expr_stmt [15779,15799]
expr_stmt [15779,15799]
===
match
---
string: 'pickle_len' [63634,63646]
string: 'pickle_len' [63685,63697]
===
match
---
name: conf [87935,87939]
name: conf [87986,87990]
===
match
---
expr_stmt [3540,3590]
expr_stmt [3540,3590]
===
match
---
atom_expr [43603,43618]
atom_expr [43603,43618]
===
match
---
trailer [16221,16228]
trailer [16221,16228]
===
match
---
atom_expr [11207,11221]
atom_expr [11207,11221]
===
match
---
atom_expr [13179,13208]
atom_expr [13179,13208]
===
match
---
operator: = [64330,64331]
operator: = [64381,64382]
===
match
---
trailer [50322,50353]
trailer [50373,50404]
===
match
---
trailer [20585,20596]
trailer [20585,20596]
===
match
---
if_stmt [24844,25023]
if_stmt [24844,25023]
===
match
---
trailer [12307,12319]
trailer [12307,12319]
===
match
---
expr_stmt [75947,75990]
expr_stmt [75998,76041]
===
match
---
trailer [79766,79776]
trailer [79817,79827]
===
match
---
trailer [61798,61807]
trailer [61849,61858]
===
match
---
param [69950,69963]
param [70001,70014]
===
match
---
operator: = [64066,64067]
operator: = [64117,64118]
===
match
---
simple_stmt [11967,11989]
simple_stmt [11967,11989]
===
match
---
operator: = [83402,83403]
operator: = [83453,83454]
===
match
---
name: replace [31020,31027]
name: replace [31020,31027]
===
match
---
name: mark_success [69186,69198]
name: mark_success [69237,69249]
===
match
---
name: bool [11319,11323]
name: bool [11319,11323]
===
match
---
trailer [12265,12272]
trailer [12265,12272]
===
match
---
funcdef [45963,55781]
funcdef [45963,55832]
===
match
---
name: DateTime [91132,91140]
name: DateTime [91183,91191]
===
match
---
parameters [30587,30598]
parameters [30587,30598]
===
match
---
expr_stmt [31955,32093]
expr_stmt [31955,32093]
===
match
---
operator: >= [37677,37679]
operator: >= [37677,37679]
===
match
---
name: get_task [35099,35107]
name: get_task [35099,35107]
===
match
---
simple_stmt [22871,22949]
simple_stmt [22871,22949]
===
match
---
name: run_dates [27916,27925]
name: run_dates [27916,27925]
===
match
---
name: self [38514,38518]
name: self [38514,38518]
===
match
---
trailer [45381,45389]
trailer [45381,45389]
===
match
---
name: tags [11398,11402]
name: tags [11398,11402]
===
match
---
name: is_active [79767,79776]
name: is_active [79818,79827]
===
match
---
expr_stmt [64633,64643]
expr_stmt [64684,64694]
===
match
---
name: node [45008,45012]
name: node [45008,45012]
===
match
---
name: permissions [18008,18019]
name: permissions [18008,18019]
===
match
---
name: in_ [45668,45671]
name: in_ [45668,45671]
===
match
---
argument [85728,85740]
argument [85779,85791]
===
match
---
name: run_id [71985,71991]
name: run_id [72036,72042]
===
match
---
atom_expr [11615,11632]
atom_expr [11615,11632]
===
match
---
name: self [49316,49320]
name: self [49367,49371]
===
match
---
name: self [32032,32036]
name: self [32032,32036]
===
match
---
trailer [79810,79815]
trailer [79861,79866]
===
match
---
name: delay_on_limit_secs [69436,69455]
name: delay_on_limit_secs [69487,69506]
===
match
---
name: render_templates [52406,52422]
name: render_templates [52457,52473]
===
match
---
fstring_string: Could not find dag  [53074,53093]
fstring_string: Could not find dag  [53125,53144]
===
match
---
name: options [73928,73935]
name: options [73979,73986]
===
match
---
name: param [94024,94029]
name: param [94075,94080]
===
match
---
trailer [60769,60778]
trailer [60820,60829]
===
match
---
simple_stmt [39425,39452]
simple_stmt [39425,39452]
===
match
---
atom_expr [31028,31048]
atom_expr [31028,31048]
===
match
---
trailer [37584,37591]
trailer [37584,37591]
===
match
---
name: dags [72816,72820]
name: dags [72867,72871]
===
match
---
name: operators [43281,43290]
name: operators [43281,43290]
===
match
---
name: subdag_lst [38728,38738]
name: subdag_lst [38728,38738]
===
match
---
name: func [90797,90801]
name: func [90848,90852]
===
match
---
comparison [60187,60217]
comparison [60238,60268]
===
match
---
operator: , [85892,85893]
operator: , [85943,85944]
===
match
---
trailer [21801,21806]
trailer [21801,21806]
===
match
---
name: session [72711,72718]
name: session [72762,72769]
===
match
---
operator: , [83675,83676]
operator: , [83726,83727]
===
match
---
name: dttm [19935,19939]
name: dttm [19935,19939]
===
match
---
while_stmt [43722,45255]
while_stmt [43722,45255]
===
match
---
trailer [27465,27501]
trailer [27465,27501]
===
match
---
name: dry_run [57448,57455]
name: dry_run [57499,57506]
===
match
---
simple_stmt [64284,64300]
simple_stmt [64335,64351]
===
match
---
name: joinedload [73936,73946]
name: joinedload [73987,73997]
===
match
---
name: DagRunType [75078,75088]
name: DagRunType [75129,75139]
===
match
---
name: DagBag [1801,1807]
name: DagBag [1801,1807]
===
match
---
operator: , [57997,57998]
operator: , [58048,58049]
===
match
---
name: next_dagrun [85508,85519]
name: next_dagrun [85559,85570]
===
match
---
trailer [62705,62724]
trailer [62756,62775]
===
match
---
name: ti [35108,35110]
name: ti [35108,35110]
===
match
---
name: Callable [10771,10779]
name: Callable [10771,10779]
===
match
---
name: timezone [64332,64340]
name: timezone [64383,64391]
===
match
---
trailer [77413,77428]
trailer [77464,77479]
===
match
---
atom_expr [70164,70178]
atom_expr [70215,70229]
===
match
---
simple_stmt [43439,43513]
simple_stmt [43439,43513]
===
match
---
name: timezone [63561,63569]
name: timezone [63612,63620]
===
match
---
name: self [13126,13130]
name: self [13126,13130]
===
match
---
name: extend [56591,56597]
name: extend [56642,56648]
===
match
---
operator: @ [64793,64794]
operator: @ [64844,64845]
===
match
---
trailer [50838,50842]
trailer [50889,50893]
===
match
---
for_stmt [52755,54447]
for_stmt [52806,54498]
===
match
---
trailer [16833,16838]
trailer [16833,16838]
===
match
---
trailer [73852,73857]
trailer [73903,73908]
===
match
---
operator: , [53671,53672]
operator: , [53722,53723]
===
match
---
import_from [1851,1895]
import_from [1851,1895]
===
match
---
atom_expr [62499,62559]
atom_expr [62550,62610]
===
match
---
name: default_args [12800,12812]
name: default_args [12800,12812]
===
match
---
fstring_start: f" [86338,86340]
fstring_start: f" [86389,86391]
===
match
---
name: delay_on_limit_secs [67035,67054]
name: delay_on_limit_secs [67086,67105]
===
match
---
trailer [45660,45667]
trailer [45660,45667]
===
match
---
trailer [62213,62226]
trailer [62264,62277]
===
match
---
atom_expr [25330,25394]
atom_expr [25330,25394]
===
match
---
operator: = [17907,17908]
operator: = [17907,17908]
===
match
---
expr_stmt [62374,62458]
expr_stmt [62425,62509]
===
match
---
operator: , [39682,39683]
operator: , [39682,39683]
===
match
---
trailer [72946,73125]
trailer [72997,73176]
===
match
---
simple_stmt [52856,52897]
simple_stmt [52907,52948]
===
match
---
simple_stmt [31262,31305]
simple_stmt [31262,31305]
===
match
---
suite [61247,61826]
suite [61298,61877]
===
match
---
operator: = [72180,72181]
operator: = [72231,72232]
===
match
---
atom_expr [16588,16600]
atom_expr [16588,16600]
===
match
---
trailer [85991,86000]
trailer [86042,86051]
===
match
---
param [46044,46058]
param [46044,46058]
===
match
---
name: get_default_view [87638,87654]
name: get_default_view [87689,87705]
===
match
---
arglist [16407,16421]
arglist [16407,16421]
===
match
---
name: STATICA_HACK [94361,94373]
name: STATICA_HACK [94412,94424]
===
match
---
name: self [59895,59899]
name: self [59946,59950]
===
match
---
name: re [2866,2868]
name: re [2866,2868]
===
match
---
name: also_include [60541,60553]
name: also_include [60592,60604]
===
match
---
funcdef [63458,63899]
funcdef [63509,63950]
===
match
---
trailer [9908,9913]
trailer [9908,9913]
===
match
---
operator: , [90996,90997]
operator: , [91047,91048]
===
match
---
atom_expr [42533,42551]
atom_expr [42533,42551]
===
match
---
atom_expr [22185,22212]
atom_expr [22185,22212]
===
match
---
suite [92786,94244]
suite [92837,94295]
===
match
---
simple_stmt [35327,35392]
simple_stmt [35327,35392]
===
match
---
not_test [25817,25834]
not_test [25817,25834]
===
match
---
trailer [38007,38022]
trailer [38007,38022]
===
match
---
operator: = [53526,53527]
operator: = [53577,53578]
===
match
---
trailer [26601,26617]
trailer [26601,26617]
===
match
---
name: partial_subset [58629,58643]
name: partial_subset [58680,58694]
===
match
---
trailer [13585,13618]
trailer [13585,13618]
===
match
---
operator: , [72219,72220]
operator: , [72270,72271]
===
match
---
trailer [25441,25460]
trailer [25441,25460]
===
match
---
name: ExternalTaskMarker [50912,50930]
name: ExternalTaskMarker [50963,50981]
===
match
---
name: max_recursion_depth [50014,50033]
name: max_recursion_depth [50065,50084]
===
match
---
operator: , [70232,70233]
operator: , [70283,70284]
===
match
---
comparison [15733,15769]
comparison [15733,15769]
===
match
---
simple_stmt [57963,58006]
simple_stmt [58014,58057]
===
match
---
string: 'start_date' [12813,12825]
string: 'start_date' [12813,12825]
===
match
---
trailer [83127,83147]
trailer [83178,83198]
===
match
---
operator: = [93294,93295]
operator: = [93345,93346]
===
match
---
argument [88623,88636]
argument [88674,88687]
===
match
---
trailer [74414,74438]
trailer [74465,74489]
===
match
---
decorator [95368,95381]
decorator [95419,95432]
===
match
---
atom_expr [79558,79750]
atom_expr [79609,79801]
===
match
---
funcdef [95162,95363]
funcdef [95213,95414]
===
match
---
name: include_upstream [49360,49376]
name: include_upstream [49411,49427]
===
match
---
operator: , [52302,52303]
operator: , [52353,52354]
===
match
---
name: keys [62774,62778]
name: keys [62825,62829]
===
match
---
name: dag_models [89365,89375]
name: dag_models [89416,89426]
===
match
---
trailer [63842,63856]
trailer [63893,63907]
===
match
---
name: self [91077,91081]
name: self [91128,91132]
===
match
---
dotted_name [1856,1879]
dotted_name [1856,1879]
===
match
---
decorators [87007,87042]
decorators [87058,87093]
===
match
---
atom_expr [18222,18254]
atom_expr [18222,18254]
===
match
---
atom_expr [84670,84685]
atom_expr [84721,84736]
===
match
---
name: str [41580,41583]
name: str [41580,41583]
===
match
---
decorator [89995,90008]
decorator [90046,90059]
===
match
---
param [85965,85973]
param [86016,86024]
===
match
---
atom_expr [36365,36378]
atom_expr [36365,36378]
===
match
---
operator: , [11081,11082]
operator: , [11081,11082]
===
match
---
name: task_dict [12349,12358]
name: task_dict [12349,12358]
===
match
---
name: isinstance [44997,45007]
name: isinstance [44997,45007]
===
match
---
suite [36618,37086]
suite [36618,37086]
===
match
---
operator: = [62293,62294]
operator: = [62344,62345]
===
match
---
name: hash_components [16964,16979]
name: hash_components [16964,16979]
===
match
---
name: next_dagrun [91507,91518]
name: next_dagrun [91558,91569]
===
match
---
name: session [86533,86540]
name: session [86584,86591]
===
match
---
operator: = [26775,26776]
operator: = [26775,26776]
===
match
---
trailer [41191,41195]
trailer [41191,41195]
===
match
---
name: tis [50229,50232]
name: tis [50280,50283]
===
match
---
operator: = [56247,56248]
operator: = [56298,56299]
===
match
---
name: self [31763,31767]
name: self [31763,31767]
===
match
---
name: int [70330,70333]
name: int [70381,70384]
===
match
---
name: timezone [14133,14141]
name: timezone [14133,14141]
===
match
---
name: fn [31136,31138]
name: fn [31136,31138]
===
match
---
classdef [83157,83459]
classdef [83208,83510]
===
match
---
parameters [92768,92785]
parameters [92819,92836]
===
match
---
name: dag_id [83645,83651]
name: dag_id [83696,83702]
===
match
---
arglist [55270,55366]
arglist [55321,55417]
===
match
---
expr_stmt [3640,3688]
expr_stmt [3640,3688]
===
match
---
atom_expr [49124,49137]
atom_expr [49124,49137]
===
match
---
trailer [81225,81232]
trailer [81276,81283]
===
match
---
name: convert_to_utc [20625,20639]
name: convert_to_utc [20625,20639]
===
match
---
string: """         Returns Normalized Schedule Interval. This is used internally by the Scheduler to         schedule DAGs.          1. Converts Cron Preset to a Cron Expression (e.g ``@monthly`` to ``0 0 1 * *``)         2. If Schedule Interval is "@once" return "None"         3. If not (1) or (2) returns schedule_interval         """ [33282,33612]
string: """         Returns Normalized Schedule Interval. This is used internally by the Scheduler to         schedule DAGs.          1. Converts Cron Preset to a Cron Expression (e.g ``@monthly`` to ``0 0 1 * *``)         2. If Schedule Interval is "@once" return "None"         3. If not (1) or (2) returns schedule_interval         """ [33282,33612]
===
match
---
name: session [37872,37879]
name: session [37872,37879]
===
match
---
atom_expr [19263,19311]
atom_expr [19263,19311]
===
match
---
operator: = [58042,58043]
operator: = [58093,58094]
===
match
---
trailer [76800,76815]
trailer [76851,76866]
===
match
---
arglist [21855,21864]
arglist [21855,21864]
===
match
---
operator: = [21833,21834]
operator: = [21833,21834]
===
match
---
comparison [77179,77207]
comparison [77230,77258]
===
match
---
argument [57130,57151]
argument [57181,57202]
===
match
---
import_from [64831,64866]
import_from [64882,64917]
===
match
---
name: task_id [60109,60116]
name: task_id [60160,60167]
===
match
---
param [28983,28987]
param [28983,28987]
===
match
---
operator: , [64560,64561]
operator: , [64611,64612]
===
match
---
name: self [23967,23971]
name: self [23967,23971]
===
match
---
name: make_aware [40943,40953]
name: make_aware [40943,40953]
===
match
---
name: primary_key [83311,83322]
name: primary_key [83362,83373]
===
match
---
atom_expr [76496,76515]
atom_expr [76547,76566]
===
match
---
string: '/' [31112,31115]
string: '/' [31112,31115]
===
match
---
trailer [44603,44610]
trailer [44603,44610]
===
match
---
trailer [87503,87507]
trailer [87554,87558]
===
match
---
expr_stmt [84140,84182]
expr_stmt [84191,84233]
===
match
---
operator: @ [32826,32827]
operator: @ [32826,32827]
===
match
---
trailer [18238,18242]
trailer [18238,18242]
===
match
---
name: _schedule_interval [33989,34007]
name: _schedule_interval [33989,34007]
===
match
---
name: topological_sort [42802,42818]
name: topological_sort [42802,42818]
===
match
---
and_test [31641,31708]
and_test [31641,31708]
===
match
---
trailer [19271,19311]
trailer [19271,19311]
===
match
---
atom_expr [74000,74028]
atom_expr [74051,74079]
===
match
---
name: self [45349,45353]
name: self [45349,45353]
===
match
---
name: session [41020,41027]
name: session [41020,41027]
===
match
---
name: cls [90894,90897]
name: cls [90945,90948]
===
match
---
operator: { [59802,59803]
operator: { [59853,59854]
===
match
---
operator: * [92769,92770]
operator: * [92820,92821]
===
match
---
operator: = [89561,89562]
operator: = [89612,89613]
===
match
---
operator: , [75594,75595]
operator: , [75645,75646]
===
match
---
expr_stmt [62162,62253]
expr_stmt [62213,62304]
===
match
---
trailer [40901,40906]
trailer [40901,40906]
===
match
---
name: id [57794,57796]
name: id [57845,57847]
===
match
---
trailer [76310,76317]
trailer [76361,76368]
===
match
---
expr_stmt [59712,59738]
expr_stmt [59763,59789]
===
match
---
argument [91012,91027]
argument [91063,91078]
===
match
---
atom_expr [65876,65889]
atom_expr [65927,65940]
===
match
---
name: jinja_environment_kwargs [39902,39926]
name: jinja_environment_kwargs [39902,39926]
===
match
---
name: read_dags_from_db [52873,52890]
name: read_dags_from_db [52924,52941]
===
match
---
operator: , [55128,55129]
operator: , [55179,55180]
===
match
---
name: value [29303,29308]
name: value [29303,29308]
===
match
---
expr_stmt [20014,20071]
expr_stmt [20014,20071]
===
match
---
not_test [71527,71554]
not_test [71578,71605]
===
match
---
comparison [50527,50552]
comparison [50578,50603]
===
match
---
atom [43468,43488]
atom [43468,43488]
===
match
---
operator: == [23057,23059]
operator: == [23057,23059]
===
match
---
atom_expr [52595,52616]
atom_expr [52646,52667]
===
match
---
suite [63969,64433]
suite [64020,64484]
===
match
---
name: self [15149,15153]
name: self [15149,15153]
===
match
---
name: jinja2 [1211,1217]
name: jinja2 [1211,1217]
===
match
---
suite [25546,25681]
suite [25546,25681]
===
match
---
name: filter_task_group [61595,61612]
name: filter_task_group [61646,61663]
===
match
---
name: now [24570,24573]
name: now [24570,24573]
===
match
---
trailer [74892,74899]
trailer [74943,74950]
===
match
---
suite [28274,28299]
suite [28274,28299]
===
match
---
trailer [27805,27815]
trailer [27805,27815]
===
match
---
name: cls [95729,95732]
name: cls [95780,95783]
===
match
---
trailer [45452,45462]
trailer [45452,45462]
===
match
---
expr_stmt [49023,49079]
expr_stmt [49023,49079]
===
match
---
argument [28563,28578]
argument [28563,28578]
===
match
---
name: dag_id [38054,38060]
name: dag_id [38054,38060]
===
match
---
trailer [66707,66716]
trailer [66758,66767]
===
match
---
decorated [29207,29309]
decorated [29207,29309]
===
match
---
operator: , [10278,10279]
operator: , [10278,10279]
===
match
---
if_stmt [26529,26696]
if_stmt [26529,26696]
===
match
---
name: add [77376,77379]
name: add [77427,77430]
===
match
---
name: TaskInstance [41116,41128]
name: TaskInstance [41116,41128]
===
match
---
param [29842,29846]
param [29842,29846]
===
match
---
expr_stmt [18190,18273]
expr_stmt [18190,18273]
===
match
---
parameters [62990,63010]
parameters [63041,63061]
===
match
---
argument [18965,19004]
argument [18965,19004]
===
match
---
name: Optional [11112,11120]
name: Optional [11112,11120]
===
match
---
name: default_view [29829,29841]
name: default_view [29829,29841]
===
match
---
name: owner [76055,76060]
name: owner [76106,76111]
===
match
---
name: downstream_list [42776,42791]
name: downstream_list [42776,42791]
===
match
---
name: safe_dag_id [88008,88019]
name: safe_dag_id [88059,88070]
===
match
---
suite [25234,25395]
suite [25234,25395]
===
match
---
name: _default_view [29876,29889]
name: _default_view [29876,29889]
===
match
---
decorated [55786,57591]
decorated [55837,57642]
===
match
---
arglist [26026,26097]
arglist [26026,26097]
===
match
---
name: staticmethod [78353,78365]
name: staticmethod [78404,78416]
===
match
---
name: last_parsed_time [84225,84241]
name: last_parsed_time [84276,84292]
===
match
---
name: user_defined_macros [10395,10414]
name: user_defined_macros [10395,10414]
===
match
---
trailer [32980,33148]
trailer [32980,33148]
===
match
---
name: cron [20455,20459]
name: cron [20455,20459]
===
match
---
trailer [23339,23358]
trailer [23339,23358]
===
match
---
name: last_parsed_time [76283,76299]
name: last_parsed_time [76334,76350]
===
match
---
trailer [62773,62778]
trailer [62824,62829]
===
match
---
atom_expr [39943,39982]
atom_expr [39943,39982]
===
match
---
trailer [87373,87390]
trailer [87424,87441]
===
match
---
atom_expr [69025,69062]
atom_expr [69076,69113]
===
match
---
simple_stmt [13875,13919]
simple_stmt [13875,13919]
===
match
---
return_stmt [31516,31563]
return_stmt [31516,31563]
===
match
---
return_stmt [30390,30451]
return_stmt [30390,30451]
===
match
---
name: warnings [58377,58385]
name: warnings [58428,58436]
===
match
---
atom_expr [66002,66014]
atom_expr [66053,66065]
===
match
---
operator: , [31767,31768]
operator: , [31767,31768]
===
match
---
atom [56844,56869]
atom [56895,56920]
===
match
---
atom_expr [14133,14150]
atom_expr [14133,14150]
===
match
---
comparison [16574,16600]
comparison [16574,16600]
===
match
---
trailer [3563,3580]
trailer [3563,3580]
===
match
---
fstring_string: Invalid values of dag.default_view: only support  [14520,14569]
fstring_string: Invalid values of dag.default_view: only support  [14520,14569]
===
match
---
name: self [19737,19741]
name: self [19737,19741]
===
match
---
operator: = [85678,85679]
operator: = [85729,85730]
===
match
---
atom_expr [9890,9914]
atom_expr [9890,9914]
===
match
---
if_stmt [25498,25681]
if_stmt [25498,25681]
===
match
---
param [9984,10018]
param [9984,10018]
===
match
---
name: default_args [12576,12588]
name: default_args [12576,12588]
===
match
---
name: callback [35263,35271]
name: callback [35263,35271]
===
match
---
name: start_date [40755,40765]
name: start_date [40755,40765]
===
match
---
simple_stmt [45872,45937]
simple_stmt [45872,45937]
===
match
---
trailer [50930,50939]
trailer [50981,50990]
===
match
---
simple_stmt [11836,11884]
simple_stmt [11836,11884]
===
match
---
operator: = [86678,86679]
operator: = [86729,86730]
===
match
---
trailer [65900,65909]
trailer [65951,65960]
===
match
---
suite [23360,26726]
suite [23360,26726]
===
match
---
name: max_recursion_depth [51764,51783]
name: max_recursion_depth [51815,51834]
===
match
---
atom_expr [31269,31304]
atom_expr [31269,31304]
===
match
---
del_stmt [11896,11927]
del_stmt [11896,11927]
===
match
---
dictorsetmaker [60783,60797]
dictorsetmaker [60834,60848]
===
match
---
simple_stmt [31634,31709]
simple_stmt [31634,31709]
===
match
---
name: compile [2869,2876]
name: compile [2869,2876]
===
match
---
trailer [32809,32819]
trailer [32809,32819]
===
match
---
argument [72406,72423]
argument [72457,72474]
===
match
---
atom [73877,74039]
atom [73928,74090]
===
match
---
return_stmt [22843,22862]
return_stmt [22843,22862]
===
match
---
trailer [75001,75010]
trailer [75052,75061]
===
match
---
name: intersection [62322,62334]
name: intersection [62373,62385]
===
match
---
name: self [32515,32519]
name: self [32515,32519]
===
match
---
arglist [92071,92135]
arglist [92122,92186]
===
match
---
trailer [25178,25184]
trailer [25178,25184]
===
match
---
name: dag_id [9963,9969]
name: dag_id [9963,9969]
===
match
---
name: datetime [20469,20477]
name: datetime [20469,20477]
===
match
---
operator: , [50435,50436]
operator: , [50486,50487]
===
match
---
name: BaseOperator [42360,42372]
name: BaseOperator [42360,42372]
===
match
---
return_stmt [23995,24006]
return_stmt [23995,24006]
===
match
---
name: self [31001,31005]
name: self [31001,31005]
===
match
---
operator: , [58695,58696]
operator: , [58746,58747]
===
match
---
sync_comp_for [80783,80798]
sync_comp_for [80834,80849]
===
match
---
name: commit [89906,89912]
name: commit [89957,89963]
===
match
---
trailer [23038,23056]
trailer [23038,23056]
===
match
---
name: include_parentdag [53908,53925]
name: include_parentdag [53959,53976]
===
match
---
arglist [83106,83126]
arglist [83157,83177]
===
match
---
atom_expr [63601,63619]
atom_expr [63652,63670]
===
match
---
name: dttm [19556,19560]
name: dttm [19556,19560]
===
match
---
name: DAG [95130,95133]
name: DAG [95181,95184]
===
match
---
operator: = [55165,55166]
operator: = [55216,55217]
===
match
---
name: _context_managed_dag [95336,95356]
name: _context_managed_dag [95387,95407]
===
match
---
simple_stmt [27960,28015]
simple_stmt [27960,28015]
===
match
---
name: TaskInstance [41487,41499]
name: TaskInstance [41487,41499]
===
match
---
name: jinja_environment_kwargs [15966,15990]
name: jinja_environment_kwargs [15966,15990]
===
match
---
atom_expr [14052,14065]
atom_expr [14052,14065]
===
match
---
name: dag [77275,77278]
name: dag [77326,77329]
===
match
---
atom_expr [38809,38841]
atom_expr [38809,38841]
===
match
---
operator: = [34102,34103]
operator: = [34102,34103]
===
match
---
suite [45160,45255]
suite [45160,45255]
===
match
---
name: sync_to_db [77788,77798]
name: sync_to_db [77839,77849]
===
match
---
name: self [30857,30861]
name: self [30857,30861]
===
match
---
atom_expr [29643,29663]
atom_expr [29643,29663]
===
match
---
name: end_date [26511,26519]
name: end_date [26511,26519]
===
match
---
name: get_is_paused [32576,32589]
name: get_is_paused [32576,32589]
===
match
---
name: include_direct_upstream [58799,58822]
name: include_direct_upstream [58850,58873]
===
match
---
atom_expr [70073,70091]
atom_expr [70124,70142]
===
match
---
if_stmt [60394,60573]
if_stmt [60445,60624]
===
match
---
trailer [16372,16444]
trailer [16372,16444]
===
match
---
simple_stmt [66441,66479]
simple_stmt [66492,66530]
===
match
---
name: filter [45731,45737]
name: filter [45731,45737]
===
match
---
name: str [11418,11421]
name: str [11418,11421]
===
match
---
atom_expr [11310,11324]
atom_expr [11310,11324]
===
match
---
name: normalized_schedule_interval [20669,20697]
name: normalized_schedule_interval [20669,20697]
===
match
---
name: all [78855,78858]
name: all [78906,78909]
===
match
---
funcdef [85946,86298]
funcdef [85997,86349]
===
match
---
operator: , [62995,62996]
operator: , [63046,63047]
===
match
---
sync_comp_for [87561,87597]
sync_comp_for [87612,87648]
===
match
---
name: __enter__ [17195,17204]
name: __enter__ [17195,17204]
===
match
---
name: tis [34977,34980]
name: tis [34977,34980]
===
match
---
name: dry_run [56543,56550]
name: dry_run [56594,56601]
===
match
---
name: tis [48598,48601]
name: tis [48598,48601]
===
match
---
comparison [22961,22988]
comparison [22961,22988]
===
match
---
operator: , [23014,23015]
operator: , [23014,23015]
===
match
---
operator: , [1157,1158]
operator: , [1157,1158]
===
match
---
trailer [29706,29713]
trailer [29706,29713]
===
match
---
operator: = [55122,55123]
operator: = [55173,55174]
===
match
---
name: node [44889,44893]
name: node [44889,44893]
===
match
---
operator: = [33949,33950]
operator: = [33949,33950]
===
match
---
operator: = [55941,55942]
operator: = [55992,55993]
===
match
---
comparison [36349,36378]
comparison [36349,36378]
===
match
---
suite [55219,55645]
suite [55270,55696]
===
match
---
name: jinja2 [10363,10369]
name: jinja2 [10363,10369]
===
match
---
atom_expr [64665,64685]
atom_expr [64716,64736]
===
match
---
name: downstream_task_ids [62821,62840]
name: downstream_task_ids [62872,62891]
===
match
---
expr_stmt [91502,91593]
expr_stmt [91553,91644]
===
match
---
name: self [12795,12799]
name: self [12795,12799]
===
match
---
param [34068,34081]
param [34068,34081]
===
match
---
operator: = [95357,95358]
operator: = [95408,95409]
===
match
---
trailer [86133,86161]
trailer [86184,86212]
===
match
---
name: dag_id [88448,88454]
name: dag_id [88499,88505]
===
match
---
comparison [26230,26259]
comparison [26230,26259]
===
match
---
name: count [55123,55128]
name: count [55174,55179]
===
match
---
name: self [58583,58587]
name: self [58634,58638]
===
match
---
name: subdag_task_groups [62042,62060]
name: subdag_task_groups [62093,62111]
===
match
---
funcdef [22069,23265]
funcdef [22069,23265]
===
match
---
name: pickle [64219,64225]
name: pickle [64270,64276]
===
match
---
operator: , [10437,10438]
operator: , [10437,10438]
===
match
---
arglist [78255,78286]
arglist [78306,78337]
===
match
---
name: f [94132,94133]
name: f [94183,94184]
===
match
---
operator: @ [31144,31145]
operator: @ [31144,31145]
===
match
---
trailer [52955,52967]
trailer [53006,53018]
===
match
---
name: get_template_env [39270,39286]
name: get_template_env [39270,39286]
===
match
---
name: DagModel [74084,74092]
name: DagModel [74135,74143]
===
match
---
atom_expr [74856,74877]
atom_expr [74907,74928]
===
match
---
atom [81487,82311]
atom [81538,82362]
===
match
---
name: format [52210,52216]
name: format [52261,52267]
===
match
---
string: '/' [31051,31054]
string: '/' [31051,31054]
===
match
---
trailer [75182,75186]
trailer [75233,75237]
===
match
---
comparison [56713,56723]
comparison [56764,56774]
===
match
---
atom_expr [90724,90747]
atom_expr [90775,90798]
===
match
---
simple_stmt [36896,37063]
simple_stmt [36896,37063]
===
match
---
fstring_end: " [66189,66190]
fstring_end: " [66240,66241]
===
match
---
name: in_ [49120,49123]
name: in_ [49120,49123]
===
match
---
simple_stmt [94290,94310]
simple_stmt [94341,94361]
===
match
---
if_stmt [16200,16445]
if_stmt [16200,16445]
===
match
---
name: execution_date [69972,69986]
name: execution_date [70023,70037]
===
match
---
simple_stmt [19256,19312]
simple_stmt [19256,19312]
===
match
---
simple_stmt [56737,56764]
simple_stmt [56788,56815]
===
match
---
trailer [60108,60116]
trailer [60159,60167]
===
match
---
import_as_names [967,986]
import_as_names [967,986]
===
match
---
trailer [89405,89413]
trailer [89456,89464]
===
match
---
name: resolve_template_files [39236,39258]
name: resolve_template_files [39236,39258]
===
match
---
trailer [29766,29771]
trailer [29766,29771]
===
match
---
atom_expr [13497,13514]
atom_expr [13497,13514]
===
match
---
name: downstream_group_ids [62272,62292]
name: downstream_group_ids [62323,62343]
===
match
---
decorator [30560,30574]
decorator [30560,30574]
===
match
---
trailer [13125,13161]
trailer [13125,13161]
===
match
---
trailer [12812,12826]
trailer [12812,12826]
===
match
---
atom [57880,57945]
atom [57931,57996]
===
match
---
trailer [57024,57034]
trailer [57075,57085]
===
match
---
name: session [35174,35181]
name: session [35174,35181]
===
match
---
trailer [79504,79514]
trailer [79555,79565]
===
match
---
expr_stmt [21765,21807]
expr_stmt [21765,21807]
===
match
---
param [88145,88176]
param [88196,88227]
===
match
---
name: self [40281,40285]
name: self [40281,40285]
===
match
---
name: property [33191,33199]
name: property [33191,33199]
===
match
---
atom_expr [64092,64105]
atom_expr [64143,64156]
===
match
---
trailer [76925,76930]
trailer [76976,76981]
===
match
---
if_stmt [73688,73720]
if_stmt [73739,73771]
===
match
---
name: DagRun [35627,35633]
name: DagRun [35627,35633]
===
match
---
atom_expr [35195,35229]
atom_expr [35195,35229]
===
match
---
name: __deepcopy__ [57600,57612]
name: __deepcopy__ [57651,57663]
===
match
---
simple_stmt [84140,84183]
simple_stmt [84191,84234]
===
match
---
operator: , [73752,73753]
operator: , [73803,73804]
===
match
---
trailer [65117,65128]
trailer [65168,65179]
===
match
---
name: start_date [56211,56221]
name: start_date [56262,56272]
===
match
---
trailer [92110,92117]
trailer [92161,92168]
===
match
---
decorators [86604,86638]
decorators [86655,86689]
===
match
---
name: isinstance [24664,24674]
name: isinstance [24664,24674]
===
match
---
name: ti_list [55130,55137]
name: ti_list [55181,55188]
===
match
---
name: DagPickle [1933,1942]
name: DagPickle [1933,1942]
===
match
---
trailer [78047,78064]
trailer [78098,78115]
===
match
---
atom_expr [11413,11422]
atom_expr [11413,11422]
===
match
---
atom_expr [30397,30451]
atom_expr [30397,30451]
===
match
---
atom_expr [33741,33781]
atom_expr [33741,33781]
===
match
---
trailer [58048,58068]
trailer [58099,58119]
===
match
---
name: kwargs [93115,93121]
name: kwargs [93166,93172]
===
match
---
trailer [83304,83309]
trailer [83355,83360]
===
match
---
trailer [44942,44948]
trailer [44942,44948]
===
match
---
param [88862,88874]
param [88913,88925]
===
match
---
string: 'start_date' [13481,13493]
string: 'start_date' [13481,13493]
===
match
---
string: "dag_tag" [83270,83279]
string: "dag_tag" [83321,83330]
===
match
---
name: normalize_schedule [25272,25290]
name: normalize_schedule [25272,25290]
===
match
---
trailer [60727,60737]
trailer [60778,60788]
===
match
---
name: self [25957,25961]
name: self [25957,25961]
===
match
---
trailer [75340,75346]
trailer [75391,75397]
===
match
---
operator: = [81162,81163]
operator: = [81213,81214]
===
match
---
trailer [31985,31997]
trailer [31985,31997]
===
match
---
name: normalized_schedule_interval [20766,20794]
name: normalized_schedule_interval [20766,20794]
===
match
---
atom_expr [53226,53237]
atom_expr [53277,53288]
===
match
---
simple_stmt [78760,78767]
simple_stmt [78811,78818]
===
match
---
operator: = [13952,13953]
operator: = [13952,13953]
===
match
---
trailer [41873,41877]
trailer [41873,41877]
===
match
---
operator: = [49813,49814]
operator: = [49864,49865]
===
match
---
operator: = [85867,85868]
operator: = [85918,85919]
===
match
---
name: filter [90658,90664]
name: filter [90709,90715]
===
match
---
expr_stmt [50390,50472]
expr_stmt [50441,50523]
===
match
---
simple_stmt [817,832]
simple_stmt [817,832]
===
match
---
simple_stmt [74194,74249]
simple_stmt [74245,74300]
===
match
---
atom_expr [21835,21865]
atom_expr [21835,21865]
===
match
---
parameters [16544,16557]
parameters [16544,16557]
===
match
---
suite [30045,30078]
suite [30045,30078]
===
match
---
sync_comp_for [41955,41974]
sync_comp_for [41955,41974]
===
match
---
name: deepcopy [11640,11648]
name: deepcopy [11640,11648]
===
match
---
expr_stmt [64312,64349]
expr_stmt [64363,64400]
===
match
---
atom_expr [76952,76975]
atom_expr [77003,77026]
===
match
---
import_name [894,909]
import_name [894,909]
===
match
---
trailer [89320,89322]
trailer [89371,89373]
===
match
---
name: next_dagrun [92124,92135]
name: next_dagrun [92175,92186]
===
match
---
atom_expr [56737,56763]
atom_expr [56788,56814]
===
match
---
name: updated_access_control [18190,18212]
name: updated_access_control [18190,18212]
===
match
---
suite [89779,89835]
suite [89830,89886]
===
match
---
string: 'Executing dag callback function: %s' [34916,34953]
string: 'Executing dag callback function: %s' [34916,34953]
===
match
---
atom [38791,39029]
atom [38791,39029]
===
match
---
string: 'stacktrace' [63843,63855]
string: 'stacktrace' [63894,63906]
===
match
---
tfpdef [18703,18721]
tfpdef [18703,18721]
===
match
---
expr_stmt [76023,76060]
expr_stmt [76074,76111]
===
match
---
name: include_externally_triggered [86934,86962]
name: include_externally_triggered [86985,87013]
===
match
---
name: next_execution_date [23243,23262]
name: next_execution_date [23243,23262]
===
match
---
name: is_paused_upon_creation [11285,11308]
name: is_paused_upon_creation [11285,11308]
===
match
---
operator: = [84993,84994]
operator: = [85044,85045]
===
match
---
name: incr [35414,35418]
name: incr [35414,35418]
===
match
---
name: append [16980,16986]
name: append [16980,16986]
===
match
---
name: full_filepath [10194,10207]
name: full_filepath [10194,10207]
===
match
---
operator: @ [29314,29315]
operator: @ [29314,29315]
===
match
---
param [55902,55920]
param [55953,55971]
===
match
---
operator: , [81562,81563]
operator: , [81613,81614]
===
match
---
name: dag_run_state [57399,57412]
name: dag_run_state [57450,57463]
===
match
---
operator: = [57223,57224]
operator: = [57274,57275]
===
match
---
simple_stmt [49452,50187]
simple_stmt [49503,50238]
===
match
---
name: only_failed [57212,57223]
name: only_failed [57263,57274]
===
match
---
atom_expr [53055,53107]
atom_expr [53106,53158]
===
match
---
trailer [80661,80669]
trailer [80712,80720]
===
match
---
suite [50940,54504]
suite [50991,54555]
===
match
---
name: next_execution_date [23198,23217]
name: next_execution_date [23198,23217]
===
match
---
number: 1 [10090,10091]
number: 1 [10090,10091]
===
match
---
name: create_dagrun [69913,69926]
name: create_dagrun [69964,69977]
===
match
---
trailer [63868,63879]
trailer [63919,63930]
===
match
---
suite [34889,35446]
suite [34889,35446]
===
match
---
atom_expr [24896,24911]
atom_expr [24896,24911]
===
match
---
name: filter [50520,50526]
name: filter [50571,50577]
===
match
---
name: self [83080,83084]
name: self [83131,83135]
===
match
---
name: DagModel [88543,88551]
name: DagModel [88594,88602]
===
match
---
argument [28830,28845]
argument [28830,28845]
===
match
---
name: dag [76406,76409]
name: dag [76457,76460]
===
match
---
operator: - [21551,21552]
operator: - [21551,21552]
===
match
---
name: only_running [46094,46106]
name: only_running [46094,46106]
===
match
---
name: do_it [57047,57052]
name: do_it [57098,57103]
===
match
---
sync_comp_for [27480,27499]
sync_comp_for [27480,27499]
===
match
---
name: TI [31929,31931]
name: TI [31929,31931]
===
match
---
expr_stmt [76434,76483]
expr_stmt [76485,76534]
===
match
---
string: 'test' [81468,81474]
string: 'test' [81519,81525]
===
match
---
operator: = [10893,10894]
operator: = [10893,10894]
===
match
---
name: Base [1709,1713]
name: Base [1709,1713]
===
match
---
name: name [77254,77258]
name: name [77305,77309]
===
match
---
name: self [30763,30767]
name: self [30763,30767]
===
match
---
simple_stmt [73713,73720]
simple_stmt [73764,73771]
===
match
---
operator: , [75360,75361]
operator: , [75411,75412]
===
match
---
funcdef [30805,30874]
funcdef [30805,30874]
===
match
---
name: group [61045,61050]
name: group [61096,61101]
===
match
---
param [95191,95195]
param [95242,95246]
===
match
---
name: _type [17306,17311]
name: _type [17306,17311]
===
match
---
name: DuplicateTaskIdFound [1634,1654]
name: DuplicateTaskIdFound [1634,1654]
===
match
---
name: filter [87404,87410]
name: filter [87455,87461]
===
match
---
operator: , [60912,60913]
operator: , [60963,60964]
===
match
---
name: run [72531,72534]
name: run [72582,72585]
===
match
---
or_test [41428,41457]
or_test [41428,41457]
===
match
---
name: using_end_date [27888,27902]
name: using_end_date [27888,27902]
===
match
---
import_from [69726,69760]
import_from [69777,69811]
===
match
---
simple_stmt [55671,55681]
simple_stmt [55722,55732]
===
match
---
trailer [39064,39077]
trailer [39064,39077]
===
match
---
trailer [75422,75429]
trailer [75473,75480]
===
match
---
param [37872,37884]
param [37872,37884]
===
match
---
trailer [61612,61627]
trailer [61663,61678]
===
match
---
atom_expr [92625,92648]
atom_expr [92676,92699]
===
match
---
name: session [3186,3193]
name: session [3186,3193]
===
match
---
atom_expr [45872,45936]
atom_expr [45872,45936]
===
match
---
expr_stmt [76153,76182]
expr_stmt [76204,76233]
===
match
---
name: dag [77483,77486]
name: dag [77534,77537]
===
match
---
trailer [93969,93975]
trailer [94020,94026]
===
match
---
name: all [75183,75186]
name: all [75234,75237]
===
match
---
operator: = [53290,53291]
operator: = [53341,53342]
===
match
---
import_as_names [1530,1545]
import_as_names [1530,1545]
===
match
---
simple_stmt [56993,57035]
simple_stmt [57044,57086]
===
match
---
trailer [31036,31048]
trailer [31036,31048]
===
match
---
operator: = [28608,28609]
operator: = [28608,28609]
===
match
---
atom_expr [50407,50471]
atom_expr [50458,50522]
===
match
---
trailer [45737,45774]
trailer [45737,45774]
===
match
---
atom_expr [64391,64405]
atom_expr [64442,64456]
===
match
---
name: property [32827,32835]
name: property [32827,32835]
===
match
---
simple_stmt [51067,51091]
simple_stmt [51118,51142]
===
match
---
atom_expr [27462,27501]
atom_expr [27462,27501]
===
match
---
operator: = [49706,49707]
operator: = [49757,49758]
===
match
---
name: get [33754,33757]
name: get [33754,33757]
===
match
---
tfpdef [69950,69962]
tfpdef [70001,70013]
===
match
---
name: str [56845,56848]
name: str [56896,56899]
===
match
---
trailer [21566,21576]
trailer [21566,21576]
===
match
---
operator: - [20298,20299]
operator: - [20298,20299]
===
match
---
argument [83311,83327]
argument [83362,83378]
===
match
---
simple_stmt [13390,13440]
simple_stmt [13390,13440]
===
match
---
name: self [42819,42823]
name: self [42819,42823]
===
match
---
operator: , [82253,82254]
operator: , [82304,82305]
===
match
---
and_test [33624,33706]
and_test [33624,33706]
===
match
---
simple_stmt [27510,27563]
simple_stmt [27510,27563]
===
match
---
param [90037,90041]
param [90088,90092]
===
match
---
import_name [788,799]
import_name [788,799]
===
match
---
name: schedule_interval [24061,24078]
name: schedule_interval [24061,24078]
===
match
---
name: include_upstream [53274,53290]
name: include_upstream [53325,53341]
===
match
---
name: dag_obj [93653,93660]
name: dag_obj [93704,93711]
===
match
---
name: schedule_interval [22640,22657]
name: schedule_interval [22640,22657]
===
match
---
atom_expr [16070,16097]
atom_expr [16070,16097]
===
match
---
suite [41910,42146]
suite [41910,42146]
===
match
---
trailer [50519,50526]
trailer [50570,50577]
===
match
---
name: Optional [11042,11050]
name: Optional [11042,11050]
===
match
---
name: task_concurrency [76590,76606]
name: task_concurrency [76641,76657]
===
match
---
operator: , [49902,49903]
operator: , [49953,49954]
===
match
---
trailer [21300,21342]
trailer [21300,21342]
===
match
---
if_stmt [45690,45775]
if_stmt [45690,45775]
===
match
---
arglist [30406,30450]
arglist [30406,30450]
===
match
---
name: run [72690,72693]
name: run [72741,72744]
===
match
---
string: """Stringified DAGs and operators contain exactly these fields.""" [81297,81363]
string: """Stringified DAGs and operators contain exactly these fields.""" [81348,81414]
===
match
---
if_stmt [3495,3636]
if_stmt [3495,3636]
===
match
---
name: start_date [65331,65341]
name: start_date [65382,65392]
===
match
---
trailer [29792,29805]
trailer [29792,29805]
===
match
---
name: user_defined_filters [58112,58132]
name: user_defined_filters [58163,58183]
===
match
---
name: log [2887,2890]
name: log [2887,2890]
===
match
---
name: self [65552,65556]
name: self [65603,65607]
===
match
---
atom_expr [45533,45542]
atom_expr [45533,45542]
===
match
---
operator: } [82781,82782]
operator: } [82832,82833]
===
match
---
argument [56315,56340]
argument [56366,56391]
===
match
---
trailer [78254,78287]
trailer [78305,78338]
===
match
---
string: '_log' [81812,81818]
string: '_log' [81863,81869]
===
match
---
name: warn [32317,32321]
name: warn [32317,32321]
===
match
---
operator: , [69211,69212]
operator: , [69262,69263]
===
match
---
comparison [38032,38060]
comparison [38032,38060]
===
match
---
name: task_dict [63378,63387]
name: task_dict [63429,63438]
===
match
---
trailer [80624,80631]
trailer [80675,80682]
===
match
---
name: ForeignKey [83365,83375]
name: ForeignKey [83416,83426]
===
match
---
atom_expr [65892,65925]
atom_expr [65943,65976]
===
match
---
argument [81461,81474]
argument [81512,81525]
===
match
---
import_from [987,1016]
import_from [987,1016]
===
match
---
name: types [2604,2609]
name: types [2604,2609]
===
match
---
atom [56127,56129]
atom [56178,56180]
===
match
---
string: """Return nodes with no children. These are last to execute and are called leaves or leaf nodes.""" [42620,42719]
string: """Return nodes with no children. These are last to execute and are called leaves or leaf nodes.""" [42620,42719]
===
match
---
operator: , [55947,55948]
operator: , [55998,55999]
===
match
---
name: airflow [1515,1522]
name: airflow [1515,1522]
===
match
---
name: normalized_schedule_interval [18976,19004]
name: normalized_schedule_interval [18976,19004]
===
match
---
name: end_date [65881,65889]
name: end_date [65932,65940]
===
match
---
name: dag_id [80554,80560]
name: dag_id [80605,80611]
===
match
---
atom_expr [43607,43617]
atom_expr [43607,43617]
===
match
---
operator: , [19770,19771]
operator: , [19770,19771]
===
match
---
name: dag_run_state [56050,56063]
name: dag_run_state [56101,56114]
===
match
---
trailer [58161,58168]
trailer [58212,58219]
===
match
---
trailer [44588,44613]
trailer [44588,44613]
===
match
---
operator: = [28739,28740]
operator: = [28739,28740]
===
match
---
operator: = [73971,73972]
operator: = [74022,74023]
===
match
---
comparison [48850,48873]
comparison [48850,48873]
===
match
---
operator: = [94490,94491]
operator: = [94541,94542]
===
match
---
trailer [94023,94029]
trailer [94074,94080]
===
match
---
name: State [75485,75490]
name: State [75536,75541]
===
match
---
atom_expr [62538,62558]
atom_expr [62589,62609]
===
match
---
operator: @ [29207,29208]
operator: @ [29207,29208]
===
match
---
simple_stmt [85127,85161]
simple_stmt [85178,85212]
===
match
---
expr_stmt [58215,58238]
expr_stmt [58266,58289]
===
match
---
simple_stmt [43522,43568]
simple_stmt [43522,43568]
===
match
---
name: tasks [30582,30587]
name: tasks [30582,30587]
===
match
---
name: next_run_date [25821,25834]
name: next_run_date [25821,25834]
===
match
---
expr_stmt [48598,48621]
expr_stmt [48598,48621]
===
match
---
operator: = [92623,92624]
operator: = [92674,92675]
===
match
---
trailer [79678,79685]
trailer [79729,79736]
===
match
---
fstring_expr [63431,63440]
fstring_expr [63482,63491]
===
match
---
name: external_trigger [72328,72344]
name: external_trigger [72379,72395]
===
match
---
for_stmt [39201,39261]
for_stmt [39201,39261]
===
match
---
simple_stmt [74468,74516]
simple_stmt [74519,74567]
===
match
---
trailer [94346,94348]
trailer [94397,94399]
===
match
---
operator: , [79950,79951]
operator: , [80001,80002]
===
match
---
expr_stmt [60431,60482]
expr_stmt [60482,60533]
===
match
---
name: default_args [12690,12702]
name: default_args [12690,12702]
===
match
---
name: staticmethod [87008,87020]
name: staticmethod [87059,87071]
===
match
---
return_stmt [32508,32545]
return_stmt [32508,32545]
===
match
---
import_name [800,816]
import_name [800,816]
===
match
---
operator: = [53925,53926]
operator: = [53976,53977]
===
match
---
expr_stmt [12486,12519]
expr_stmt [12486,12519]
===
match
---
comp_op [21966,21972]
comp_op [21966,21972]
===
match
---
operator: , [18963,18964]
operator: , [18963,18964]
===
match
---
name: filter [75392,75398]
name: filter [75443,75449]
===
match
---
name: Optional [10046,10054]
name: Optional [10046,10054]
===
match
---
param [82843,82848]
param [82894,82899]
===
match
---
param [10239,10303]
param [10239,10303]
===
match
---
arglist [13126,13160]
arglist [13126,13160]
===
match
---
name: dict [74799,74803]
name: dict [74850,74854]
===
match
---
import_from [2459,2546]
import_from [2459,2546]
===
match
---
decorator [88777,88794]
decorator [88828,88845]
===
match
---
name: dag [79811,79814]
name: dag [79862,79865]
===
match
---
name: SubDagOperator [43305,43319]
name: SubDagOperator [43305,43319]
===
match
---
name: self [26011,26015]
name: self [26011,26015]
===
match
---
trailer [64095,64105]
trailer [64146,64156]
===
match
---
name: session [86925,86932]
name: session [86976,86983]
===
match
---
atom_expr [91520,91549]
atom_expr [91571,91600]
===
match
---
param [10447,10491]
param [10447,10491]
===
match
---
name: filter [80521,80527]
name: filter [80572,80578]
===
match
---
name: property [29812,29820]
name: property [29812,29820]
===
match
---
suite [63346,63397]
suite [63397,63448]
===
match
---
name: session [37164,37171]
name: session [37164,37171]
===
match
---
trailer [66006,66014]
trailer [66057,66065]
===
match
---
string: 'dag_concurrency' [10584,10601]
string: 'dag_concurrency' [10584,10601]
===
match
---
testlist_comp [60003,60019]
testlist_comp [60054,60070]
===
match
---
trailer [48848,48906]
trailer [48848,48906]
===
match
---
decorator [88760,88773]
decorator [88811,88824]
===
match
---
operator: = [14727,14728]
operator: = [14727,14728]
===
match
---
atom_expr [78200,78217]
atom_expr [78251,78268]
===
match
---
atom [88659,88690]
atom [88710,88741]
===
match
---
operator: , [29625,29626]
operator: , [29625,29626]
===
match
---
trailer [3472,3479]
trailer [3472,3479]
===
match
---
name: include_externally_triggered [86963,86991]
name: include_externally_triggered [87014,87042]
===
match
---
argument [72358,72367]
argument [72409,72418]
===
match
---
trailer [31099,31109]
trailer [31099,31109]
===
match
---
name: external_tis [52766,52778]
name: external_tis [52817,52829]
===
match
---
for_stmt [79382,79845]
for_stmt [79433,79896]
===
match
---
comp_op [18828,18834]
comp_op [18828,18834]
===
match
---
suite [33865,33904]
suite [33865,33904]
===
match
---
name: self [65484,65488]
name: self [65535,65539]
===
match
---
name: orm_tag_names [77062,77075]
name: orm_tag_names [77113,77126]
===
match
---
name: keys [62246,62250]
name: keys [62297,62301]
===
match
---
name: debug [89181,89186]
name: debug [89232,89237]
===
match
---
trailer [63804,63820]
trailer [63855,63871]
===
match
---
name: push_context_managed_dag [95166,95190]
name: push_context_managed_dag [95217,95241]
===
match
---
trailer [85756,85828]
trailer [85807,85879]
===
match
---
name: signature [1007,1016]
name: signature [1007,1016]
===
match
---
name: f [92487,92488]
name: f [92538,92539]
===
match
---
expr_stmt [12066,12097]
expr_stmt [12066,12097]
===
match
---
name: e [63788,63789]
name: e [63839,63840]
===
match
---
name: name [93939,93943]
name: name [93990,93994]
===
match
---
simple_stmt [61176,61197]
simple_stmt [61227,61248]
===
match
---
name: session [72719,72726]
name: session [72770,72777]
===
match
---
name: following [28264,28273]
name: following [28264,28273]
===
match
---
dictorsetmaker [73787,73818]
dictorsetmaker [73838,73869]
===
match
---
operator: == [50420,50422]
operator: == [50471,50473]
===
match
---
simple_stmt [2887,2921]
simple_stmt [2887,2921]
===
match
---
atom [48807,48813]
atom [48807,48813]
===
match
---
trailer [92020,92045]
trailer [92071,92096]
===
match
---
name: log [74558,74561]
name: log [74609,74612]
===
match
---
trailer [41854,41884]
trailer [41854,41884]
===
match
---
string: '' [31056,31058]
string: '' [31056,31058]
===
match
---
operator: = [36235,36236]
operator: = [36235,36236]
===
match
---
decorators [72753,72787]
decorators [72804,72838]
===
match
---
name: not_none_states [81054,81069]
name: not_none_states [81105,81120]
===
match
---
operator: + [48805,48806]
operator: + [48805,48806]
===
match
---
name: external_trigger [72311,72327]
name: external_trigger [72362,72378]
===
match
---
if_stmt [64203,64414]
if_stmt [64254,64465]
===
match
---
name: dag_bound_args [93476,93490]
name: dag_bound_args [93527,93541]
===
match
---
name: session [87089,87096]
name: session [87140,87147]
===
match
---
trailer [30544,30551]
trailer [30544,30551]
===
match
---
atom_expr [36961,36974]
atom_expr [36961,36974]
===
match
---
trailer [37714,37729]
trailer [37714,37729]
===
match
---
raise_stmt [71572,71640]
raise_stmt [71623,71691]
===
match
---
suite [94394,94525]
suite [94445,94576]
===
match
---
suite [89516,89569]
suite [89567,89620]
===
match
---
atom_expr [81031,81070]
atom_expr [81082,81121]
===
match
---
atom_expr [76864,76876]
atom_expr [76915,76927]
===
match
---
suite [30136,30452]
suite [30136,30452]
===
match
---
name: run [66732,66735]
name: run [66783,66786]
===
match
---
name: self [86347,86351]
name: self [86398,86402]
===
match
---
atom_expr [26246,26259]
atom_expr [26246,26259]
===
match
---
name: ignore_first_depends_on_past [69371,69399]
name: ignore_first_depends_on_past [69422,69450]
===
match
---
name: _schedule_interval [33930,33948]
name: _schedule_interval [33930,33948]
===
match
---
name: value [29110,29115]
name: value [29110,29115]
===
match
---
atom_expr [75760,75786]
atom_expr [75811,75837]
===
match
---
name: end_date [41428,41436]
name: end_date [41428,41436]
===
match
---
name: values [44604,44610]
name: values [44604,44610]
===
match
---
operator: @ [95692,95693]
operator: @ [95743,95744]
===
match
---
name: in_ [81050,81053]
name: in_ [81101,81104]
===
match
---
operator: = [53220,53221]
operator: = [53271,53272]
===
match
---
trailer [72710,72727]
trailer [72761,72778]
===
match
---
name: self [31551,31555]
name: self [31551,31555]
===
match
---
operator: = [72212,72213]
operator: = [72263,72264]
===
match
---
comparison [43603,43623]
comparison [43603,43623]
===
match
---
name: DeprecationWarning [58512,58530]
name: DeprecationWarning [58563,58581]
===
match
---
atom_expr [10707,10726]
atom_expr [10707,10726]
===
match
---
operator: = [69522,69523]
operator: = [69573,69574]
===
match
---
operator: = [58554,58555]
operator: = [58605,58606]
===
match
---
name: getLogger [2901,2910]
name: getLogger [2901,2910]
===
match
---
name: allow_future_exec_dates [31587,31610]
name: allow_future_exec_dates [31587,31610]
===
match
---
trailer [95457,95478]
trailer [95508,95529]
===
match
---
simple_stmt [25132,25202]
simple_stmt [25132,25202]
===
match
---
name: session [78786,78793]
name: session [78837,78844]
===
match
---
simple_stmt [94549,95041]
simple_stmt [94600,95092]
===
match
---
argument [72233,72262]
argument [72284,72313]
===
match
---
expr_stmt [76111,76136]
expr_stmt [76162,76187]
===
match
---
for_stmt [60254,60573]
for_stmt [60305,60624]
===
match
---
simple_stmt [95256,95324]
simple_stmt [95307,95375]
===
match
---
simple_stmt [66102,66192]
simple_stmt [66153,66243]
===
match
---
return_stmt [86868,87001]
return_stmt [86919,87052]
===
match
---
simple_stmt [11896,11928]
simple_stmt [11896,11928]
===
match
---
trailer [89905,89912]
trailer [89956,89963]
===
match
---
atom_expr [59867,59886]
atom_expr [59918,59937]
===
match
---
trailer [13648,13661]
trailer [13648,13661]
===
match
---
param [30723,30727]
param [30723,30727]
===
match
---
expr_stmt [14159,14208]
expr_stmt [14159,14208]
===
match
---
return_stmt [54640,54650]
return_stmt [54691,54701]
===
match
---
trailer [57837,57846]
trailer [57888,57897]
===
match
---
trailer [87453,87460]
trailer [87504,87511]
===
match
---
simple_stmt [80910,80965]
simple_stmt [80961,81016]
===
match
---
param [16482,16487]
param [16482,16487]
===
match
---
name: cls [95413,95416]
name: cls [95464,95467]
===
match
---
name: str [10275,10278]
name: str [10275,10278]
===
match
---
suite [27903,28015]
suite [27903,28015]
===
match
---
trailer [52422,52424]
trailer [52473,52475]
===
match
---
not_test [68766,68778]
not_test [68817,68829]
===
match
---
atom_expr [12926,12943]
atom_expr [12926,12943]
===
match
---
name: append [39058,39064]
name: append [39058,39064]
===
match
---
operator: , [73244,73245]
operator: , [73295,73296]
===
match
---
name: dag [91552,91555]
name: dag [91603,91606]
===
match
---
operator: == [32066,32068]
operator: == [32066,32068]
===
match
---
name: args [58285,58289]
name: args [58336,58340]
===
match
---
operator: = [72386,72387]
operator: = [72437,72438]
===
match
---
parameters [29620,29633]
parameters [29620,29633]
===
match
---
simple_stmt [39047,39078]
simple_stmt [39047,39078]
===
match
---
operator: , [49721,49722]
operator: , [49772,49773]
===
match
---
name: tzinfo [12466,12472]
name: tzinfo [12466,12472]
===
match
---
trailer [22193,22212]
trailer [22193,22212]
===
match
---
name: airflow [11452,11459]
name: airflow [11452,11459]
===
match
---
name: isinstance [59972,59982]
name: isinstance [60023,60033]
===
match
---
funcdef [45317,45937]
funcdef [45317,45937]
===
match
---
operator: = [63982,63983]
operator: = [64033,64034]
===
match
---
name: callback [34955,34963]
name: callback [34955,34963]
===
match
---
atom_expr [63411,63452]
atom_expr [63462,63503]
===
match
---
operator: <= [37730,37732]
operator: <= [37730,37732]
===
match
---
name: confirm_prompt [55957,55971]
name: confirm_prompt [56008,56022]
===
match
---
string: '' [12055,12057]
string: '' [12055,12057]
===
match
---
name: all [75660,75663]
name: all [75711,75714]
===
match
---
expr_stmt [83857,83935]
expr_stmt [83908,83986]
===
match
---
trailer [31005,31019]
trailer [31005,31019]
===
match
---
simple_stmt [37187,37518]
simple_stmt [37187,37518]
===
match
---
name: dag_bag [52815,52822]
name: dag_bag [52866,52873]
===
match
---
atom_expr [11855,11882]
atom_expr [11855,11882]
===
match
---
name: dag_id [3178,3184]
name: dag_id [3178,3184]
===
match
---
param [11238,11276]
param [11238,11276]
===
match
---
name: str [82423,82426]
name: str [82474,82477]
===
match
---
trailer [56176,56182]
trailer [56227,56233]
===
match
---
funcdef [95709,95792]
funcdef [95760,95843]
===
match
---
trailer [86262,86290]
trailer [86313,86341]
===
match
---
operator: , [55485,55486]
operator: , [55536,55537]
===
match
---
name: following_schedule [27981,27999]
name: following_schedule [27981,27999]
===
match
---
name: self [15094,15098]
name: self [15094,15098]
===
match
---
atom_expr [84596,84611]
atom_expr [84647,84662]
===
match
---
name: visited_external_tis [50112,50132]
name: visited_external_tis [50163,50183]
===
match
---
import_as_names [1701,1713]
import_as_names [1701,1713]
===
match
---
atom_expr [55743,55759]
atom_expr [55794,55810]
===
match
---
name: dags [55840,55844]
name: dags [55891,55895]
===
match
---
simple_stmt [16131,16162]
simple_stmt [16131,16162]
===
match
---
name: dag_tag [77129,77136]
name: dag_tag [77180,77187]
===
match
---
operator: , [67100,67101]
operator: , [67151,67152]
===
match
---
operator: , [91518,91519]
operator: , [91569,91570]
===
match
---
name: default_view [76340,76352]
name: default_view [76391,76403]
===
match
---
operator: = [19327,19328]
operator: = [19327,19328]
===
match
---
atom_expr [28784,28918]
atom_expr [28784,28918]
===
match
---
and_test [49152,49220]
and_test [49152,49220]
===
match
---
expr_stmt [95444,95478]
expr_stmt [95495,95529]
===
match
---
trailer [65685,65694]
trailer [65736,65745]
===
match
---
name: is_subdag [23972,23981]
name: is_subdag [23972,23981]
===
match
---
trailer [49461,49467]
trailer [49512,49518]
===
match
---
trailer [64175,64185]
trailer [64226,64236]
===
match
---
operator: -> [29929,29931]
operator: -> [29929,29931]
===
match
---
name: append [88536,88542]
name: append [88587,88593]
===
match
---
name: isinstance [33624,33634]
name: isinstance [33624,33634]
===
match
---
trailer [38053,38060]
trailer [38053,38060]
===
match
---
name: external_trigger [70108,70124]
name: external_trigger [70159,70175]
===
match
---
operator: = [57269,57270]
operator: = [57320,57321]
===
match
---
simple_stmt [63489,63496]
simple_stmt [63540,63547]
===
match
---
name: getint [10569,10575]
name: getint [10569,10575]
===
match
---
atom_expr [36349,36361]
atom_expr [36349,36361]
===
match
---
name: self [57797,57801]
name: self [57848,57852]
===
match
---
argument [49841,49868]
argument [49892,49919]
===
match
---
name: state [45893,45898]
name: state [45893,45898]
===
match
---
atom_expr [28817,28828]
atom_expr [28817,28828]
===
match
---
trailer [35670,35678]
trailer [35670,35678]
===
match
---
name: dag_hash [72437,72445]
name: dag_hash [72488,72496]
===
match
---
atom_expr [95565,95605]
atom_expr [95616,95656]
===
match
---
parameters [88121,88190]
parameters [88172,88241]
===
match
---
name: set [73838,73841]
name: set [73889,73892]
===
match
---
atom_expr [93999,94013]
atom_expr [94050,94064]
===
match
---
arglist [41573,41583]
arglist [41573,41583]
===
match
---
atom_expr [21725,21748]
atom_expr [21725,21748]
===
match
---
trailer [22033,22062]
trailer [22033,22062]
===
match
---
trailer [37563,37571]
trailer [37563,37571]
===
match
---
operator: , [74952,74953]
operator: , [75003,75004]
===
match
---
return_stmt [63890,63898]
return_stmt [63941,63949]
===
match
---
name: dag_obj [94016,94023]
name: dag_obj [94067,94074]
===
match
---
operator: = [91019,91020]
operator: = [91070,91071]
===
match
---
operator: = [30417,30418]
operator: = [30417,30418]
===
match
---
name: local [68783,68788]
name: local [68834,68839]
===
match
---
operator: = [50082,50083]
operator: = [50133,50134]
===
match
---
suite [35906,36541]
suite [35906,36541]
===
match
---
atom_expr [60077,60117]
atom_expr [60128,60168]
===
match
---
name: dag_id [74154,74160]
name: dag_id [74205,74211]
===
match
---
operator: , [58608,58609]
operator: , [58659,58660]
===
match
---
name: min [40992,40995]
name: min [40992,40995]
===
match
---
atom_expr [38764,38774]
atom_expr [38764,38774]
===
match
---
name: DagModel [73947,73955]
name: DagModel [73998,74006]
===
match
---
name: dag [60788,60791]
name: dag [60839,60842]
===
match
---
simple_stmt [13982,14027]
simple_stmt [13982,14027]
===
match
---
name: UtcDateTime [85645,85656]
name: UtcDateTime [85696,85707]
===
match
---
name: default [83968,83975]
name: default [84019,84026]
===
match
---
simple_stmt [20844,20986]
simple_stmt [20844,20986]
===
match
---
suite [78114,78347]
suite [78165,78398]
===
match
---
name: conf [86079,86083]
name: conf [86130,86134]
===
match
---
simple_stmt [20014,20072]
simple_stmt [20014,20072]
===
match
---
trailer [10715,10726]
trailer [10715,10726]
===
match
---
name: croniter [20021,20029]
name: croniter [20021,20029]
===
match
---
if_stmt [56710,56785]
if_stmt [56761,56836]
===
match
---
name: Column [85359,85365]
name: Column [85410,85416]
===
match
---
string: 'partial' [81755,81764]
string: 'partial' [81806,81815]
===
match
---
if_stmt [59969,60219]
if_stmt [60020,60270]
===
match
---
name: tis [53419,53422]
name: tis [53470,53473]
===
match
---
name: start_date [13370,13380]
name: start_date [13370,13380]
===
match
---
name: info [92066,92070]
name: info [92117,92121]
===
match
---
trailer [41128,41143]
trailer [41128,41143]
===
match
---
name: next_run_date [25251,25264]
name: next_run_date [25251,25264]
===
match
---
trailer [15783,15790]
trailer [15783,15790]
===
match
---
tfpdef [70023,70044]
tfpdef [70074,70095]
===
match
---
name: Column [83713,83719]
name: Column [83764,83770]
===
match
---
param [79022,79038]
param [79073,79089]
===
match
---
name: AirflowException [72011,72027]
name: AirflowException [72062,72078]
===
match
---
name: TI [32057,32059]
name: TI [32057,32059]
===
match
---
decorator [37091,37108]
decorator [37091,37108]
===
match
---
atom_expr [45725,45774]
atom_expr [45725,45774]
===
match
---
tfpdef [11161,11182]
tfpdef [11161,11182]
===
match
---
atom_expr [13675,13704]
atom_expr [13675,13704]
===
match
---
number: 0 [43622,43623]
number: 0 [43622,43623]
===
match
---
name: include_subdags [57346,57361]
name: include_subdags [57397,57412]
===
match
---
name: dag_id [76805,76811]
name: dag_id [76856,76862]
===
match
---
name: _previous_context_managed_dags [95569,95599]
name: _previous_context_managed_dags [95620,95650]
===
match
---
name: tis [50223,50226]
name: tis [50274,50277]
===
match
---
trailer [64131,64137]
trailer [64182,64188]
===
match
---
operator: , [61914,61915]
operator: , [61965,61966]
===
match
---
suite [39488,39540]
suite [39488,39540]
===
match
---
name: start [19321,19326]
name: start [19321,19326]
===
match
---
fstring_start: fr" [53221,53224]
fstring_start: fr" [53272,53275]
===
match
---
name: is_subdag [75841,75850]
name: is_subdag [75892,75901]
===
match
---
name: is_paused_upon_creation [74415,74438]
name: is_paused_upon_creation [74466,74489]
===
match
---
operator: , [54172,54173]
operator: , [54223,54224]
===
match
---
name: info [74562,74566]
name: info [74613,74617]
===
match
---
string: 'full_filepath' [9787,9802]
string: 'full_filepath' [9787,9802]
===
match
---
operator: = [59947,59948]
operator: = [59998,59999]
===
match
---
and_test [71487,71510]
and_test [71538,71561]
===
match
---
trailer [22149,22168]
trailer [22149,22168]
===
match
---
name: staticmethod [78958,78970]
name: staticmethod [79009,79021]
===
match
---
param [30594,30597]
param [30594,30597]
===
match
---
name: with_row_locks [2532,2546]
name: with_row_locks [2532,2546]
===
match
---
trailer [62321,62334]
trailer [62372,62385]
===
match
---
param [95729,95732]
param [95780,95783]
===
match
---
expr_stmt [12910,12943]
expr_stmt [12910,12943]
===
match
---
suite [57053,57481]
suite [57104,57532]
===
match
---
expr_stmt [93080,93122]
expr_stmt [93131,93173]
===
match
---
testlist_comp [80929,80963]
testlist_comp [80980,81014]
===
match
---
decorator [95145,95158]
decorator [95196,95209]
===
match
---
name: task_id [41184,41191]
name: task_id [41184,41191]
===
match
---
suite [60414,60483]
suite [60465,60534]
===
match
---
string: 'is_picklable' [63805,63819]
string: 'is_picklable' [63856,63870]
===
match
---
name: catchup [10945,10952]
name: catchup [10945,10952]
===
match
---
trailer [13369,13381]
trailer [13369,13381]
===
match
---
trailer [44647,44661]
trailer [44647,44661]
===
match
---
expr_stmt [63841,63881]
expr_stmt [63892,63932]
===
match
---
name: dag_hash [70264,70272]
name: dag_hash [70315,70323]
===
match
---
trailer [66232,66246]
trailer [66283,66297]
===
match
---
simple_stmt [21285,21343]
simple_stmt [21285,21343]
===
match
---
operator: , [3184,3185]
operator: , [3184,3185]
===
match
---
simple_stmt [55429,55645]
simple_stmt [55480,55696]
===
match
---
name: provide_session [73200,73215]
name: provide_session [73251,73266]
===
match
---
suite [86859,87002]
suite [86910,87053]
===
match
---
name: session [88177,88184]
name: session [88228,88235]
===
match
---
trailer [72941,72946]
trailer [72992,72997]
===
match
---
name: query [86541,86546]
name: query [86592,86597]
===
match
---
name: d [63803,63804]
name: d [63854,63855]
===
match
---
atom_expr [14217,14237]
atom_expr [14217,14237]
===
match
---
suite [82797,82820]
suite [82848,82871]
===
match
---
operator: , [37690,37691]
operator: , [37690,37691]
===
match
---
param [35863,35868]
param [35863,35868]
===
match
---
name: self [16515,16519]
name: self [16515,16519]
===
match
---
name: helpers [57007,57014]
name: helpers [57058,57065]
===
match
---
operator: @ [69888,69889]
operator: @ [69939,69940]
===
match
---
name: TI [49043,49045]
name: TI [49043,49045]
===
match
---
atom_expr [44643,44661]
atom_expr [44643,44661]
===
match
---
atom_expr [37708,37729]
atom_expr [37708,37729]
===
match
---
expr_stmt [11558,11606]
expr_stmt [11558,11606]
===
match
---
name: dag_id [74838,74844]
name: dag_id [74889,74895]
===
match
---
simple_stmt [18099,18127]
simple_stmt [18099,18127]
===
match
---
name: task [66266,66270]
name: task [66317,66321]
===
match
---
name: settings [77405,77413]
name: settings [77456,77464]
===
match
---
operator: = [27750,27751]
operator: = [27750,27751]
===
match
---
atom_expr [24261,24283]
atom_expr [24261,24283]
===
match
---
operator: @ [38076,38077]
operator: @ [38076,38077]
===
match
---
expr_stmt [21285,21342]
expr_stmt [21285,21342]
===
match
---
name: type [16203,16207]
name: type [16203,16207]
===
match
---
comp_op [15758,15764]
comp_op [15758,15764]
===
match
---
name: str [29162,29165]
name: str [29162,29165]
===
match
---
name: filter [73993,73999]
name: filter [74044,74050]
===
match
---
parameters [92486,92499]
parameters [92537,92550]
===
match
---
trailer [63062,63068]
trailer [63113,63119]
===
match
---
trailer [85432,85457]
trailer [85483,85508]
===
match
---
simple_stmt [37895,37963]
simple_stmt [37895,37963]
===
match
---
operator: = [57181,57182]
operator: = [57232,57233]
===
match
---
simple_stmt [77311,77344]
simple_stmt [77362,77395]
===
match
---
operator: = [63857,63858]
operator: = [63908,63909]
===
match
---
argument [69225,69242]
argument [69276,69293]
===
match
---
param [23297,23302]
param [23297,23302]
===
match
---
name: copy [61035,61039]
name: copy [61086,61090]
===
match
---
testlist_comp [54947,54966]
testlist_comp [54998,55017]
===
match
---
name: replace [31076,31083]
name: replace [31076,31083]
===
match
---
name: cls [57726,57729]
name: cls [57777,57780]
===
match
---
name: tasks [60178,60183]
name: tasks [60229,60234]
===
match
---
trailer [93097,93100]
trailer [93148,93151]
===
match
---
name: cron [21553,21557]
name: cron [21553,21557]
===
match
---
name: operator [50900,50908]
name: operator [50951,50959]
===
match
---
trailer [13291,13300]
trailer [13291,13300]
===
match
---
trailer [73790,73797]
trailer [73841,73848]
===
match
---
return_stmt [21878,21918]
return_stmt [21878,21918]
===
match
---
argument [69120,69141]
argument [69171,69192]
===
match
---
trailer [87367,87373]
trailer [87418,87424]
===
match
---
if_stmt [57044,57570]
if_stmt [57095,57621]
===
match
---
name: Dict [10478,10482]
name: Dict [10478,10482]
===
match
---
trailer [31276,31284]
trailer [31276,31284]
===
match
---
trailer [88611,88618]
trailer [88662,88669]
===
match
---
name: full_filepath [31006,31019]
name: full_filepath [31006,31019]
===
match
---
name: cron [21285,21289]
name: cron [21285,21289]
===
match
---
operator: , [25378,25379]
operator: , [25378,25379]
===
match
---
name: self [43501,43505]
name: self [43501,43505]
===
match
---
operator: , [975,976]
operator: , [975,976]
===
match
---
operator: = [54934,54935]
operator: = [54985,54986]
===
match
---
atom_expr [65326,65341]
atom_expr [65377,65392]
===
match
---
simple_stmt [60228,60246]
simple_stmt [60279,60297]
===
match
---
atom_expr [60173,60183]
atom_expr [60224,60234]
===
match
---
name: inspect [992,999]
name: inspect [992,999]
===
match
---
name: all [37770,37773]
name: all [37770,37773]
===
match
---
name: with_row_locks [90951,90965]
name: with_row_locks [91002,91016]
===
match
---
suite [60277,60573]
suite [60328,60624]
===
match
---
trailer [94029,94042]
trailer [94080,94093]
===
match
---
funcdef [16471,16529]
funcdef [16471,16529]
===
match
---
name: DAG [95430,95433]
name: DAG [95481,95484]
===
match
---
name: Column [83342,83348]
name: Column [83393,83399]
===
match
---
atom_expr [48923,48949]
atom_expr [48923,48949]
===
match
---
atom_expr [84049,84079]
atom_expr [84100,84130]
===
match
---
operator: , [17304,17305]
operator: , [17304,17305]
===
match
---
suite [41759,42146]
suite [41759,42146]
===
match
---
atom_expr [49029,49079]
atom_expr [49029,49079]
===
match
---
operator: , [85713,85714]
operator: , [85764,85765]
===
match
---
param [36588,36603]
param [36588,36603]
===
match
---
suite [20710,20796]
suite [20710,20796]
===
match
---
return_stmt [58576,58619]
return_stmt [58627,58670]
===
match
---
atom_expr [35665,35678]
atom_expr [35665,35678]
===
match
---
trailer [62551,62556]
trailer [62602,62607]
===
match
---
for_stmt [62569,62876]
for_stmt [62620,62927]
===
match
---
operator: , [15436,15437]
operator: , [15436,15437]
===
match
---
name: sqlalchemy [1471,1481]
name: sqlalchemy [1471,1481]
===
match
---
name: f [93098,93099]
name: f [93149,93150]
===
match
---
name: external_dag [53003,53015]
name: external_dag [53054,53066]
===
match
---
trailer [93383,93393]
trailer [93434,93444]
===
match
---
operator: = [25796,25797]
operator: = [25796,25797]
===
match
---
operator: = [46265,46266]
operator: = [46265,46266]
===
match
---
operator: { [35210,35211]
operator: { [35210,35211]
===
match
---
name: d [63504,63505]
name: d [63555,63556]
===
match
---
name: deactivate_stale_dags [79000,79021]
name: deactivate_stale_dags [79051,79072]
===
match
---
fstring_string: > [86359,86360]
fstring_string: > [86410,86411]
===
match
---
operator: = [57361,57362]
operator: = [57412,57413]
===
match
---
operator: , [53931,53932]
operator: , [53982,53983]
===
match
---
param [88128,88144]
param [88179,88195]
===
match
---
name: warn [38250,38254]
name: warn [38250,38254]
===
match
---
atom [82752,82754]
atom [82803,82805]
===
match
---
atom_expr [20664,20697]
atom_expr [20664,20697]
===
match
---
name: self [12281,12285]
name: self [12281,12285]
===
match
---
name: tz [21765,21767]
name: tz [21765,21767]
===
match
---
name: task_id [62997,63004]
name: task_id [63048,63055]
===
match
---
expr_stmt [88410,88480]
expr_stmt [88461,88531]
===
match
---
atom_expr [93359,93393]
atom_expr [93410,93444]
===
match
---
name: pool [69413,69417]
name: pool [69464,69468]
===
match
---
decorator [42558,42568]
decorator [42558,42568]
===
match
---
param [45399,45423]
param [45399,45423]
===
match
---
trailer [93100,93105]
trailer [93151,93156]
===
match
---
simple_stmt [18600,18630]
simple_stmt [18600,18630]
===
match
---
tfpdef [70108,70140]
tfpdef [70159,70191]
===
match
---
name: RUNNING [46241,46248]
name: RUNNING [46241,46248]
===
match
---
simple_stmt [37971,38071]
simple_stmt [37971,38071]
===
match
---
expr_stmt [74048,74116]
expr_stmt [74099,74167]
===
match
---
operator: = [40932,40933]
operator: = [40932,40933]
===
match
---
name: edge_info [82685,82694]
name: edge_info [82736,82745]
===
match
---
simple_stmt [15809,15889]
simple_stmt [15809,15889]
===
match
---
expr_stmt [21537,21576]
expr_stmt [21537,21576]
===
match
---
name: args [93491,93495]
name: args [93542,93546]
===
match
---
string: 'on_success_callback' [81970,81991]
string: 'on_success_callback' [82021,82042]
===
match
---
trailer [16030,16035]
trailer [16030,16035]
===
match
---
expr_stmt [27321,27350]
expr_stmt [27321,27350]
===
match
---
name: num [18703,18706]
name: num [18703,18706]
===
match
---
name: date_last_automated_dagrun [24094,24120]
name: date_last_automated_dagrun [24094,24120]
===
match
---
parameters [17299,17325]
parameters [17299,17325]
===
match
---
dotted_name [30561,30573]
dotted_name [30561,30573]
===
match
---
decorated [30879,31139]
decorated [30879,31139]
===
match
---
trailer [89180,89186]
trailer [89231,89237]
===
match
---
name: AirflowException [14484,14500]
name: AirflowException [14484,14500]
===
match
---
trailer [81174,81206]
trailer [81225,81257]
===
match
---
operator: = [79777,79778]
operator: = [79828,79829]
===
match
---
name: Context [3140,3147]
name: Context [3140,3147]
===
match
---
name: commit [88746,88752]
name: commit [88797,88803]
===
match
---
operator: , [55273,55274]
operator: , [55324,55325]
===
match
---
operator: , [10915,10916]
operator: , [10915,10916]
===
match
---
if_stmt [48651,49140]
if_stmt [48651,49140]
===
match
---
trailer [80486,80520]
trailer [80537,80571]
===
match
---
name: group [62374,62379]
name: group [62425,62430]
===
match
---
trailer [10369,10385]
trailer [10369,10385]
===
match
---
name: sla_miss_callback [14314,14331]
name: sla_miss_callback [14314,14331]
===
match
---
simple_stmt [19571,19715]
simple_stmt [19571,19715]
===
match
---
param [29060,29065]
param [29060,29065]
===
match
---
name: from_run_id [71687,71698]
name: from_run_id [71738,71749]
===
match
---
name: lower [87977,87982]
name: lower [88028,88033]
===
match
---
simple_stmt [2585,2642]
simple_stmt [2585,2642]
===
match
---
simple_stmt [1510,1546]
simple_stmt [1510,1546]
===
match
---
expr_stmt [20322,20373]
expr_stmt [20322,20373]
===
match
---
trailer [45244,45251]
trailer [45244,45251]
===
match
---
name: f_kwargs [93905,93913]
name: f_kwargs [93956,93964]
===
match
---
trailer [36953,36960]
trailer [36953,36960]
===
match
---
atom_expr [29463,29480]
atom_expr [29463,29480]
===
match
---
atom_expr [48604,48621]
atom_expr [48604,48621]
===
match
---
name: str [19772,19775]
name: str [19772,19775]
===
match
---
name: bind [93101,93105]
name: bind [93152,93156]
===
match
---
trailer [12364,12383]
trailer [12364,12383]
===
match
---
name: frozenset [81442,81451]
name: frozenset [81493,81502]
===
match
---
operator: = [84668,84669]
operator: = [84719,84720]
===
match
---
trailer [17230,17255]
trailer [17230,17255]
===
match
---
trailer [73946,73978]
trailer [73997,74029]
===
match
---
simple_stmt [1264,1313]
simple_stmt [1264,1313]
===
match
---
name: self [29749,29753]
name: self [29749,29753]
===
match
---
operator: = [58227,58228]
operator: = [58278,58279]
===
match
---
string: 'SubDagOperator' [38945,38961]
string: 'SubDagOperator' [38945,38961]
===
match
---
operator: * [64595,64596]
operator: * [64646,64647]
===
match
---
param [86495,86502]
param [86546,86553]
===
match
---
atom_expr [75874,75889]
atom_expr [75925,75940]
===
match
---
atom_expr [18769,18786]
atom_expr [18769,18786]
===
match
---
name: ti_list [55138,55145]
name: ti_list [55189,55196]
===
match
---
simple_stmt [13328,13382]
simple_stmt [13328,13382]
===
match
---
name: jobs [68717,68721]
name: jobs [68768,68772]
===
match
---
trailer [63787,63790]
trailer [63838,63841]
===
match
---
atom_expr [12883,12896]
atom_expr [12883,12896]
===
match
---
suite [95619,95664]
suite [95670,95715]
===
match
---
name: __serialized_fields [9869,9888]
name: __serialized_fields [9869,9888]
===
match
---
expr_stmt [60228,60245]
expr_stmt [60279,60296]
===
match
---
atom_expr [64284,64299]
atom_expr [64335,64350]
===
match
---
name: relationship [85264,85276]
name: relationship [85315,85327]
===
match
---
trailer [62245,62250]
trailer [62296,62301]
===
match
---
operator: = [3077,3078]
operator: = [3077,3078]
===
match
---
atom_expr [25859,25874]
atom_expr [25859,25874]
===
match
---
atom_expr [58215,58226]
atom_expr [58266,58277]
===
match
---
atom_expr [80991,81123]
atom_expr [81042,81174]
===
match
---
fstring_expr [14877,14898]
fstring_expr [14877,14898]
===
match
---
name: tasks [42520,42525]
name: tasks [42520,42525]
===
match
---
dotted_name [1590,1608]
dotted_name [1590,1608]
===
match
---
not_test [65085,65104]
not_test [65136,65155]
===
match
---
trailer [70134,70140]
trailer [70185,70191]
===
match
---
operator: , [72839,72840]
operator: , [72890,72891]
===
match
---
name: copied [61846,61852]
name: copied [61897,61903]
===
match
---
simple_stmt [77707,77758]
simple_stmt [77758,77809]
===
match
---
decorator [30457,30467]
decorator [30457,30467]
===
match
---
trailer [52947,52955]
trailer [52998,53006]
===
match
---
param [75728,75729]
param [75779,75780]
===
match
---
string: 'start_date' [13546,13558]
string: 'start_date' [13546,13558]
===
match
---
parameters [31610,31616]
parameters [31610,31616]
===
match
---
name: self [29095,29099]
name: self [29095,29099]
===
match
---
trailer [55109,55116]
trailer [55160,55167]
===
match
---
operator: , [24697,24698]
operator: , [24697,24698]
===
match
---
operator: = [56210,56211]
operator: = [56261,56262]
===
match
---
trailer [63335,63345]
trailer [63386,63396]
===
match
---
trailer [29553,29569]
trailer [29553,29569]
===
match
---
name: self [42753,42757]
name: self [42753,42757]
===
match
---
name: DagContext [94533,94543]
name: DagContext [94584,94594]
===
match
---
atom_expr [30857,30873]
atom_expr [30857,30873]
===
match
---
name: result [58015,58021]
name: result [58066,58072]
===
match
---
operator: , [69619,69620]
operator: , [69670,69671]
===
match
---
trailer [32021,32028]
trailer [32021,32028]
===
match
---
name: is_fixed_time_schedule [21439,21461]
name: is_fixed_time_schedule [21439,21461]
===
match
---
name: state [2566,2571]
name: state [2566,2571]
===
match
---
atom_expr [10514,10528]
atom_expr [10514,10528]
===
match
---
atom_expr [15961,15990]
atom_expr [15961,15990]
===
match
---
expr_stmt [14217,14255]
expr_stmt [14217,14255]
===
match
---
atom_expr [57982,58004]
atom_expr [58033,58055]
===
match
---
operator: , [91081,91082]
operator: , [91132,91133]
===
match
---
name: missing_dag_ids [74280,74295]
name: missing_dag_ids [74331,74346]
===
match
---
if_stmt [81372,82312]
if_stmt [81423,82363]
===
match
---
operator: = [33897,33898]
operator: = [33897,33898]
===
match
---
trailer [15153,15173]
trailer [15153,15173]
===
match
---
trailer [18777,18784]
trailer [18777,18784]
===
match
---
name: session [89298,89305]
name: session [89349,89356]
===
match
---
operator: >= [41144,41146]
operator: >= [41144,41146]
===
match
---
atom_expr [60447,60482]
atom_expr [60498,60533]
===
match
---
operator: = [84922,84923]
operator: = [84973,84974]
===
match
---
operator: = [69311,69312]
operator: = [69362,69363]
===
match
---
operator: = [49027,49028]
operator: = [49027,49028]
===
match
---
name: re [60077,60079]
name: re [60128,60130]
===
match
---
trailer [93623,93631]
trailer [93674,93682]
===
match
---
param [35471,35475]
param [35471,35475]
===
match
---
name: dag_id [79679,79685]
name: dag_id [79730,79736]
===
match
---
simple_stmt [50390,50473]
simple_stmt [50441,50524]
===
match
---
simple_stmt [20447,20479]
simple_stmt [20447,20479]
===
match
---
param [42825,42859]
param [42825,42859]
===
match
---
operator: = [67001,67002]
operator: = [67052,67053]
===
match
---
name: dag_id [77268,77274]
name: dag_id [77319,77325]
===
match
---
expr_stmt [53413,54446]
expr_stmt [53464,54497]
===
match
---
trailer [19980,20001]
trailer [19980,20001]
===
match
---
string: '__dot__' [14198,14207]
string: '__dot__' [14198,14207]
===
match
---
simple_stmt [26684,26696]
simple_stmt [26684,26696]
===
match
---
operator: , [53296,53297]
operator: , [53347,53348]
===
match
---
name: dag_bag [54287,54294]
name: dag_bag [54338,54345]
===
match
---
trailer [35767,35782]
trailer [35767,35782]
===
match
---
trailer [61039,61044]
trailer [61090,61095]
===
match
---
operator: , [10017,10018]
operator: , [10017,10018]
===
match
---
trailer [40331,40338]
trailer [40331,40338]
===
match
---
simple_stmt [2459,2547]
simple_stmt [2459,2547]
===
match
---
atom_expr [75485,75498]
atom_expr [75536,75549]
===
match
---
tfpdef [45479,45507]
tfpdef [45479,45507]
===
match
---
suite [28505,28648]
suite [28505,28648]
===
match
---
atom_expr [40934,41004]
atom_expr [40934,41004]
===
match
---
trailer [91122,91141]
trailer [91173,91192]
===
match
---
simple_stmt [58141,58169]
simple_stmt [58192,58220]
===
match
---
operator: = [36903,36904]
operator: = [36903,36904]
===
match
---
operator: } [73818,73819]
operator: } [73869,73870]
===
match
---
funcdef [35451,35813]
funcdef [35451,35813]
===
match
---
operator: = [59830,59831]
operator: = [59881,59882]
===
match
---
comparison [25565,25608]
comparison [25565,25608]
===
match
---
name: edge [44635,44639]
name: edge [44635,44639]
===
match
---
return_stmt [94253,94267]
return_stmt [94304,94318]
===
match
---
name: user_defined_filters [11563,11583]
name: user_defined_filters [11563,11583]
===
match
---
operator: , [57826,57827]
operator: , [57877,57878]
===
match
---
name: TI [50604,50606]
name: TI [50655,50657]
===
match
---
operator: -> [30826,30828]
operator: -> [30826,30828]
===
match
---
atom_expr [20021,20071]
atom_expr [20021,20071]
===
match
---
name: str [30915,30918]
name: str [30915,30918]
===
match
---
arglist [83959,83997]
arglist [84010,84048]
===
match
---
name: cls [55827,55830]
name: cls [55878,55881]
===
match
---
name: self [11615,11619]
name: self [11615,11619]
===
match
---
simple_stmt [89285,89323]
simple_stmt [89336,89374]
===
match
---
param [10612,10682]
param [10612,10682]
===
match
---
simple_stmt [30390,30452]
simple_stmt [30390,30452]
===
match
---
atom [9666,9863]
atom [9666,9863]
===
match
---
parameters [69926,70348]
parameters [69977,70399]
===
match
---
simple_stmt [30054,30078]
simple_stmt [30054,30078]
===
match
---
string: """         Clears a set of task instances associated with the current dag for         a specified date range.          :param task_ids: List of task ids to clear         :type task_ids: List[str]         :param start_date: The minimum execution_date to clear         :type start_date: datetime.datetime or None         :param end_date: The maximum execution_date to clear         :type end_date: datetime.datetime or None         :param only_failed: Only clear failed tasks         :type only_failed: bool         :param only_running: Only clear running tasks.         :type only_running: bool         :param confirm_prompt: Ask for confirmation         :type confirm_prompt: bool         :param include_subdags: Clear tasks in subdags and clear external tasks             indicated by ExternalTaskMarker         :type include_subdags: bool         :param include_parentdag: Clear tasks in the parent dag of the subdag.         :type include_parentdag: bool         :param dag_run_state: state to set DagRun to         :param dry_run: Find the tasks to clear but don't clear them.         :type dry_run: bool         :param session: The sqlalchemy session to use         :type session: sqlalchemy.orm.session.Session         :param get_tis: Return the sqlalchemy query for finding the TaskInstance without clearing the tasks         :type get_tis: bool         :param recursion_depth: The recursion depth of nested calls to DAG.clear().         :type recursion_depth: int         :param max_recursion_depth: The maximum recursion depth allowed. This is determined by the             first encountered ExternalTaskMarker. Default is None indicating no ExternalTaskMarker             has been encountered.         :type max_recursion_depth: int         :param dag_bag: The DagBag used to find the dags         :type dag_bag: airflow.models.dagbag.DagBag         :param visited_external_tis: A set used internally to keep track of the visited TaskInstance when             clearing tasks across multiple DAGs linked by ExternalTaskMarker to avoid redundant work.         :type visited_external_tis: set         """ [46451,48563]
string: """         Clears a set of task instances associated with the current dag for         a specified date range.          :param task_ids: List of task ids to clear         :type task_ids: List[str]         :param start_date: The minimum execution_date to clear         :type start_date: datetime.datetime or None         :param end_date: The maximum execution_date to clear         :type end_date: datetime.datetime or None         :param only_failed: Only clear failed tasks         :type only_failed: bool         :param only_running: Only clear running tasks.         :type only_running: bool         :param confirm_prompt: Ask for confirmation         :type confirm_prompt: bool         :param include_subdags: Clear tasks in subdags and clear external tasks             indicated by ExternalTaskMarker         :type include_subdags: bool         :param include_parentdag: Clear tasks in the parent dag of the subdag.         :type include_parentdag: bool         :param dag_run_state: state to set DagRun to         :param dry_run: Find the tasks to clear but don't clear them.         :type dry_run: bool         :param session: The sqlalchemy session to use         :type session: sqlalchemy.orm.session.Session         :param get_tis: Return the sqlalchemy query for finding the TaskInstance without clearing the tasks         :type get_tis: bool         :param recursion_depth: The recursion depth of nested calls to DAG.clear().         :type recursion_depth: int         :param max_recursion_depth: The maximum recursion depth allowed. This is determined by the             first encountered ExternalTaskMarker. Default is None indicating no ExternalTaskMarker             has been encountered.         :type max_recursion_depth: int         :param dag_bag: The DagBag used to find the dags         :type dag_bag: airflow.models.dagbag.DagBag         :param visited_external_tis: A set used internally to keep track of the visited TaskInstance when             clearing tasks across multiple DAGs linked by ExternalTaskMarker to avoid redundant work.         :type visited_external_tis: set         """ [46451,48563]
===
match
---
lambdef [75721,75739]
lambdef [75772,75790]
===
match
---
trailer [85001,85015]
trailer [85052,85066]
===
match
---
name: t [31546,31547]
name: t [31546,31547]
===
match
---
simple_stmt [24533,24575]
simple_stmt [24533,24575]
===
match
---
suite [20391,20597]
suite [20391,20597]
===
match
---
operator: = [53854,53855]
operator: = [53905,53906]
===
match
---
trailer [12727,12733]
trailer [12727,12733]
===
match
---
trailer [63613,63619]
trailer [63664,63670]
===
match
---
simple_stmt [32784,32821]
simple_stmt [32784,32821]
===
match
---
not_test [52811,52822]
not_test [52862,52873]
===
match
---
tfpdef [10545,10561]
tfpdef [10545,10561]
===
match
---
name: get_flat_relatives [60449,60467]
name: get_flat_relatives [60500,60518]
===
match
---
atom [95137,95139]
atom [95188,95190]
===
match
---
name: user_defined_macros [58049,58068]
name: user_defined_macros [58100,58119]
===
match
---
operator: = [3443,3444]
operator: = [3443,3444]
===
match
---
trailer [33182,33184]
trailer [33182,33184]
===
match
---
name: self [58044,58048]
name: self [58095,58099]
===
match
---
trailer [49308,49315]
trailer [49359,49366]
===
match
---
simple_stmt [42188,42236]
simple_stmt [42188,42236]
===
match
---
trailer [62353,62358]
trailer [62404,62409]
===
match
---
arglist [32019,32083]
arglist [32019,32083]
===
match
---
dotted_name [2414,2435]
dotted_name [2414,2435]
===
match
---
atom_expr [10046,10072]
atom_expr [10046,10072]
===
match
---
name: donot_pickle [69256,69268]
name: donot_pickle [69307,69319]
===
match
---
param [10395,10438]
param [10395,10438]
===
match
---
name: external_trigger [36402,36418]
name: external_trigger [36402,36418]
===
match
---
simple_stmt [40463,40610]
simple_stmt [40463,40610]
===
match
---
name: name [30429,30433]
name: name [30429,30433]
===
match
---
trailer [71925,71941]
trailer [71976,71992]
===
match
---
decorated [86367,86434]
decorated [86418,86485]
===
match
---
simple_stmt [74528,74546]
simple_stmt [74579,74597]
===
match
---
operator: = [75758,75759]
operator: = [75809,75810]
===
match
---
for_stmt [56138,56603]
for_stmt [56189,56654]
===
match
---
string: """Build a Jinja2 environment.""" [39324,39357]
string: """Build a Jinja2 environment.""" [39324,39357]
===
match
---
name: start_date [25154,25164]
name: start_date [25154,25164]
===
match
---
name: stacklevel [73102,73112]
name: stacklevel [73153,73163]
===
match
---
atom_expr [40954,41003]
atom_expr [40954,41003]
===
match
---
name: task [65654,65658]
name: task [65705,65709]
===
match
---
name: next_dagrun_after_date [22898,22920]
name: next_dagrun_after_date [22898,22920]
===
match
---
operator: -> [28746,28748]
operator: -> [28746,28748]
===
match
---
trailer [36348,36379]
trailer [36348,36379]
===
match
---
argument [85287,85314]
argument [85338,85365]
===
match
---
name: children [61743,61751]
name: children [61794,61802]
===
match
---
param [10027,10093]
param [10027,10093]
===
match
---
name: utils [2598,2603]
name: utils [2598,2603]
===
match
---
name: _context_managed_dag [95046,95066]
name: _context_managed_dag [95097,95117]
===
match
---
name: task [66141,66145]
name: task [66192,66196]
===
match
---
simple_stmt [25032,25053]
simple_stmt [25032,25053]
===
match
---
name: used_group_ids [66399,66413]
name: used_group_ids [66450,66464]
===
match
---
tfpdef [88831,88860]
tfpdef [88882,88911]
===
match
---
expr_stmt [15702,15769]
expr_stmt [15702,15769]
===
match
---
name: self [62909,62913]
name: self [62960,62964]
===
match
---
name: ID_LEN [83727,83733]
name: ID_LEN [83778,83784]
===
match
---
param [35869,35891]
param [35869,35891]
===
match
---
param [58284,58290]
param [58335,58341]
===
match
---
tfpdef [11341,11381]
tfpdef [11341,11381]
===
match
---
name: timezone [13278,13286]
name: timezone [13278,13286]
===
match
---
name: level [64562,64567]
name: level [64613,64618]
===
match
---
simple_stmt [85611,85658]
simple_stmt [85662,85709]
===
match
---
test [34803,34868]
test [34803,34868]
===
match
---
name: cls [82327,82330]
name: cls [82378,82381]
===
match
---
suite [3531,3636]
suite [3531,3636]
===
match
---
name: name [30424,30428]
name: name [30424,30428]
===
match
---
param [85959,85964]
param [86010,86015]
===
match
---
decorator [29314,29324]
decorator [29314,29324]
===
match
---
trailer [90741,90747]
trailer [90792,90798]
===
match
---
name: include_downstream [49400,49418]
name: include_downstream [49451,49469]
===
match
---
name: state [41753,41758]
name: state [41753,41758]
===
match
---
trailer [76054,76060]
trailer [76105,76111]
===
match
---
simple_stmt [55159,55201]
simple_stmt [55210,55252]
===
match
---
expr_stmt [51496,51510]
expr_stmt [51547,51561]
===
match
---
name: dag_ids [55614,55621]
name: dag_ids [55665,55672]
===
match
---
operator: , [2504,2505]
operator: , [2504,2505]
===
match
---
param [3178,3185]
param [3178,3185]
===
match
---
trailer [73161,73176]
trailer [73212,73227]
===
match
---
name: t [77079,77080]
name: t [77130,77131]
===
match
---
atom [41196,41227]
atom [41196,41227]
===
match
---
name: using_start_date [27776,27792]
name: using_start_date [27776,27792]
===
match
---
operator: = [24598,24599]
operator: = [24598,24599]
===
match
---
trailer [62423,62436]
trailer [62474,62487]
===
match
---
name: graph_sorted [43522,43534]
name: graph_sorted [43522,43534]
===
match
---
name: cls [90976,90979]
name: cls [91027,91030]
===
match
---
operator: = [63599,63600]
operator: = [63650,63651]
===
match
---
suite [95525,95606]
suite [95576,95657]
===
match
---
atom_expr [13287,13300]
atom_expr [13287,13300]
===
match
---
name: self [16890,16894]
name: self [16890,16894]
===
match
---
name: self [40665,40669]
name: self [40665,40669]
===
match
---
operator: , [16182,16183]
operator: , [16182,16183]
===
match
---
trailer [49257,49265]
trailer [49308,49316]
===
match
---
name: dag [78874,78877]
name: dag [78925,78928]
===
match
---
name: ScheduleInterval [2922,2938]
name: ScheduleInterval [2922,2938]
===
match
---
simple_stmt [60329,60382]
simple_stmt [60380,60433]
===
match
---
name: dag [62760,62763]
name: dag [62811,62814]
===
match
---
name: value [29066,29071]
name: value [29066,29071]
===
match
---
operator: = [56411,56412]
operator: = [56462,56463]
===
match
---
trailer [73857,73859]
trailer [73908,73910]
===
match
---
simple_stmt [35689,35707]
simple_stmt [35689,35707]
===
match
---
name: query [49037,49042]
name: query [49037,49042]
===
match
---
decorator [86457,86474]
decorator [86508,86525]
===
match
---
trailer [78826,78833]
trailer [78877,78884]
===
match
---
name: copy [51414,51418]
name: copy [51465,51469]
===
match
---
argument [69518,69527]
argument [69569,69578]
===
match
---
trailer [75145,75154]
trailer [75196,75205]
===
match
---
operator: = [46004,46005]
operator: = [46004,46005]
===
match
---
operator: = [14131,14132]
operator: = [14131,14132]
===
match
---
name: timezone [21885,21893]
name: timezone [21885,21893]
===
match
---
argument [56396,56427]
argument [56447,56478]
===
match
---
name: str [15433,15436]
name: str [15433,15436]
===
match
---
comp_op [89414,89420]
comp_op [89465,89471]
===
match
---
atom_expr [41216,41226]
atom_expr [41216,41226]
===
match
---
operator: = [15174,15175]
operator: = [15174,15175]
===
match
---
number: 0 [39805,39806]
number: 0 [39805,39806]
===
match
---
name: self [20518,20522]
name: self [20518,20522]
===
match
---
for_stmt [57821,58006]
for_stmt [57872,58057]
===
match
---
trailer [50614,50618]
trailer [50665,50669]
===
match
---
name: tasks [27494,27499]
name: tasks [27494,27499]
===
match
---
simple_stmt [68874,68901]
simple_stmt [68925,68952]
===
match
---
trailer [32726,32736]
trailer [32726,32736]
===
match
---
simple_stmt [17220,17262]
simple_stmt [17220,17262]
===
match
---
operator: = [34981,34982]
operator: = [34981,34982]
===
match
---
if_stmt [28257,28299]
if_stmt [28257,28299]
===
match
---
fstring_end: " [56979,56980]
fstring_end: " [57030,57031]
===
match
---
name: Column [85426,85432]
name: Column [85477,85483]
===
match
---
atom_expr [21770,21807]
atom_expr [21770,21807]
===
match
---
name: all_tis [56583,56590]
name: all_tis [56634,56641]
===
match
---
name: Optional [33246,33254]
name: Optional [33246,33254]
===
match
---
number: 0 [55679,55680]
number: 0 [55730,55731]
===
match
---
operator: = [35140,35141]
operator: = [35140,35141]
===
match
---
name: confirm_prompt [56358,56372]
name: confirm_prompt [56409,56423]
===
match
---
operator: } [63439,63440]
operator: } [63490,63491]
===
match
---
trailer [83667,83675]
trailer [83718,83726]
===
match
---
expr_stmt [3421,3432]
expr_stmt [3421,3432]
===
match
---
name: self [58157,58161]
name: self [58208,58212]
===
match
---
trailer [57775,57780]
trailer [57826,57831]
===
match
---
name: self [13731,13735]
name: self [13731,13735]
===
match
---
atom_expr [50423,50435]
atom_expr [50474,50486]
===
match
---
funcdef [29508,29570]
funcdef [29508,29570]
===
match
---
operator: , [79735,79736]
operator: , [79786,79787]
===
match
---
argument [56498,56525]
argument [56549,56576]
===
match
---
operator: = [20498,20499]
operator: = [20498,20499]
===
match
---
argument [85928,85939]
argument [85979,85990]
===
match
---
operator: , [1363,1364]
operator: , [1363,1364]
===
match
---
suite [14400,14452]
suite [14400,14452]
===
match
---
name: subdag_lst [39047,39057]
name: subdag_lst [39047,39057]
===
match
---
simple_stmt [1851,1896]
simple_stmt [1851,1896]
===
match
---
argument [53330,53353]
argument [53381,53404]
===
match
---
trailer [66716,66722]
trailer [66767,66773]
===
match
---
trailer [19969,19980]
trailer [19969,19980]
===
match
---
suite [76094,76226]
suite [76145,76277]
===
match
---
atom_expr [42006,42145]
atom_expr [42006,42145]
===
match
---
trailer [80497,80519]
trailer [80548,80570]
===
match
---
name: Column [85142,85148]
name: Column [85193,85199]
===
match
---
name: self [15779,15783]
name: self [15779,15783]
===
match
---
return_stmt [16567,16600]
return_stmt [16567,16600]
===
match
---
expr_stmt [50306,50353]
expr_stmt [50357,50404]
===
match
---
atom_expr [12106,12121]
atom_expr [12106,12121]
===
match
---
annassign [15426,15467]
annassign [15426,15467]
===
match
---
import_from [1264,1312]
import_from [1264,1312]
===
match
---
name: self [30820,30824]
name: self [30820,30824]
===
match
---
atom_expr [44874,44902]
atom_expr [44874,44902]
===
match
---
operator: ** [92776,92778]
operator: ** [92827,92829]
===
match
---
param [29442,29452]
param [29442,29452]
===
match
---
simple_stmt [1313,1405]
simple_stmt [1313,1405]
===
match
---
atom_expr [61728,61751]
atom_expr [61779,61802]
===
match
---
trailer [16979,16986]
trailer [16979,16986]
===
match
---
name: owners [76207,76213]
name: owners [76258,76264]
===
match
---
expr_stmt [11503,11549]
expr_stmt [11503,11549]
===
match
---
name: datetime [69997,70005]
name: datetime [70048,70056]
===
match
---
name: items [57847,57852]
name: items [57898,57903]
===
match
---
arglist [65535,65567]
arglist [65586,65618]
===
match
---
fstring [66129,66190]
fstring [66180,66241]
===
match
---
param [3195,3229]
param [3195,3229]
===
match
---
operator: = [75313,75314]
operator: = [75364,75365]
===
match
---
parameters [88825,88875]
parameters [88876,88926]
===
match
---
parameters [58277,58300]
parameters [58328,58351]
===
match
---
name: tis [42006,42009]
name: tis [42006,42009]
===
match
---
name: tii [53592,53595]
name: tii [53643,53646]
===
match
---
trailer [38038,38045]
trailer [38038,38045]
===
match
---
trailer [13775,13793]
trailer [13775,13793]
===
match
---
name: __repr__ [86307,86315]
name: __repr__ [86358,86366]
===
match
---
name: task_group [11466,11476]
name: task_group [11466,11476]
===
match
---
number: 1 [94338,94339]
number: 1 [94389,94390]
===
match
---
parameters [79915,79965]
parameters [79966,80016]
===
match
---
import_from [1546,1584]
import_from [1546,1584]
===
match
---
operator: <= [45851,45853]
operator: <= [45851,45853]
===
match
---
funcdef [73220,77758]
funcdef [73271,77809]
===
match
---
trailer [60448,60467]
trailer [60499,60518]
===
match
---
arglist [53516,54382]
arglist [53567,54433]
===
match
---
trailer [94007,94013]
trailer [94058,94064]
===
match
---
name: self [42346,42350]
name: self [42346,42350]
===
match
---
trailer [81167,81174]
trailer [81218,81225]
===
match
---
expr_stmt [83284,83328]
expr_stmt [83335,83379]
===
match
---
name: TI [49054,49056]
name: TI [49054,49056]
===
match
---
operator: == [52528,52530]
operator: == [52579,52581]
===
match
---
name: self [15897,15901]
name: self [15897,15901]
===
match
---
testlist_comp [41197,41226]
testlist_comp [41197,41226]
===
match
---
trailer [12465,12472]
trailer [12465,12472]
===
match
---
trailer [18975,19004]
trailer [18975,19004]
===
match
---
name: self [40749,40753]
name: self [40749,40753]
===
match
---
if_stmt [41559,42236]
if_stmt [41559,42236]
===
match
---
trailer [89470,89489]
trailer [89521,89540]
===
match
---
expr_stmt [59813,59836]
expr_stmt [59864,59887]
===
match
---
name: self [27976,27980]
name: self [27976,27980]
===
match
---
expr_stmt [12281,12335]
expr_stmt [12281,12335]
===
match
---
atom_expr [40339,40364]
atom_expr [40339,40364]
===
match
---
operator: = [20332,20333]
operator: = [20332,20333]
===
match
---
atom_expr [76859,76877]
atom_expr [76910,76928]
===
match
---
name: State [50449,50454]
name: State [50500,50505]
===
match
---
name: x [41801,41802]
name: x [41801,41802]
===
match
---
name: dag_tag [77179,77186]
name: dag_tag [77230,77237]
===
match
---
trailer [62436,62458]
trailer [62487,62509]
===
match
---
name: bulk_write_to_db [77711,77727]
name: bulk_write_to_db [77762,77778]
===
match
---
atom_expr [12571,12602]
atom_expr [12571,12602]
===
match
---
tfpdef [46214,46232]
tfpdef [46214,46232]
===
match
---
operator: , [28828,28829]
operator: , [28828,28829]
===
match
---
operator: = [31959,31960]
operator: = [31959,31960]
===
match
---
operator: = [93668,93669]
operator: = [93719,93720]
===
match
---
operator: , [51407,51408]
operator: , [51458,51459]
===
match
---
operator: = [62061,62062]
operator: = [62112,62113]
===
match
---
atom_expr [13126,13155]
atom_expr [13126,13155]
===
match
---
operator: = [13286,13287]
operator: = [13286,13287]
===
match
---
simple_stmt [39501,39540]
simple_stmt [39501,39540]
===
match
---
comparison [86727,86747]
comparison [86778,86798]
===
match
---
trailer [82755,82759]
trailer [82806,82810]
===
match
---
trailer [40970,41003]
trailer [40970,41003]
===
match
---
trailer [63569,63576]
trailer [63620,63627]
===
match
---
trailer [95259,95290]
trailer [95310,95341]
===
match
---
operator: { [82752,82753]
operator: { [82803,82804]
===
match
---
simple_stmt [72148,72511]
simple_stmt [72199,72562]
===
match
---
name: get [82756,82759]
name: get [82807,82810]
===
match
---
trailer [66237,66245]
trailer [66288,66296]
===
match
---
simple_stmt [14264,14301]
simple_stmt [14264,14301]
===
match
---
operator: ** [94134,94136]
operator: ** [94185,94187]
===
match
---
name: order_by [3654,3662]
name: order_by [3654,3662]
===
match
---
name: type [16653,16657]
name: type [16653,16657]
===
match
---
return_stmt [82320,82350]
return_stmt [82371,82401]
===
match
---
name: task [39108,39112]
name: task [39108,39112]
===
match
---
name: params [58162,58168]
name: params [58213,58219]
===
match
---
atom_expr [15428,15462]
atom_expr [15428,15462]
===
match
---
suite [87668,87985]
suite [87719,88036]
===
match
---
decorator [31310,31320]
decorator [31310,31320]
===
match
---
string: """Exposes a CLI specific to this DAG""" [69677,69717]
string: """Exposes a CLI specific to this DAG""" [69728,69768]
===
match
---
simple_stmt [14114,14151]
simple_stmt [14114,14151]
===
match
---
name: self [16432,16436]
name: self [16432,16436]
===
match
---
simple_stmt [63675,63730]
simple_stmt [63726,63781]
===
match
---
argument [72437,72454]
argument [72488,72505]
===
match
---
simple_stmt [76952,76976]
simple_stmt [77003,77027]
===
match
---
name: max [37997,38000]
name: max [37997,38000]
===
match
---
name: cls [86715,86718]
name: cls [86766,86769]
===
match
---
atom_expr [66418,66430]
atom_expr [66469,66481]
===
match
---
trailer [94319,94349]
trailer [94370,94400]
===
match
---
simple_stmt [40853,40909]
simple_stmt [40853,40909]
===
match
---
trailer [35202,35209]
trailer [35202,35209]
===
match
---
name: schedule_interval [23039,23056]
name: schedule_interval [23039,23056]
===
match
---
expr_stmt [69014,69062]
expr_stmt [69065,69113]
===
match
---
argument [69155,69172]
argument [69206,69223]
===
match
---
trailer [52681,52702]
trailer [52732,52753]
===
match
---
trailer [81187,81193]
trailer [81238,81244]
===
match
---
operator: , [1439,1440]
operator: , [1439,1440]
===
match
---
name: task_ids [30714,30722]
name: task_ids [30714,30722]
===
match
---
name: is_active [84140,84149]
name: is_active [84191,84200]
===
match
---
name: session [28455,28462]
name: session [28455,28462]
===
match
---
name: next_run_date [26194,26207]
name: next_run_date [26194,26207]
===
match
---
decorator [86604,86617]
decorator [86655,86668]
===
match
---
param [9963,9975]
param [9963,9975]
===
match
---
operator: = [56285,56286]
operator: = [56336,56337]
===
match
---
simple_stmt [79763,79785]
simple_stmt [79814,79836]
===
match
---
name: first [64187,64192]
name: first [64238,64243]
===
match
---
name: Optional [32613,32621]
name: Optional [32613,32621]
===
match
---
if_stmt [24640,24831]
if_stmt [24640,24831]
===
match
---
atom_expr [87117,87125]
atom_expr [87168,87176]
===
match
---
string: """         Save attributes about this DAG to the DB. Note that this method         can be called for both DAGs and SubDAGs. A SubDag is actually a         SubDagOperator.          :return: None         """ [77828,78034]
string: """         Save attributes about this DAG to the DB. Note that this method         can be called for both DAGs and SubDAGs. A SubDag is actually a         SubDagOperator.          :return: None         """ [77879,78085]
===
match
---
trailer [12702,12716]
trailer [12702,12716]
===
match
---
atom_expr [49242,49438]
atom_expr [49293,49489]
===
match
---
atom_expr [75892,75914]
atom_expr [75943,75965]
===
match
---
operator: = [77748,77749]
operator: = [77799,77800]
===
match
---
name: dag_ids [45524,45531]
name: dag_ids [45524,45531]
===
match
---
simple_stmt [91502,91594]
simple_stmt [91553,91645]
===
match
---
operator: = [10089,10090]
operator: = [10089,10090]
===
match
---
name: keys [62451,62455]
name: keys [62502,62506]
===
match
---
name: self [19987,19991]
name: self [19987,19991]
===
match
---
param [16178,16183]
param [16178,16183]
===
match
---
operator: ** [93113,93115]
operator: ** [93164,93166]
===
match
---
argument [69592,69619]
argument [69643,69670]
===
match
---
operator: = [63522,63523]
operator: = [63573,63574]
===
match
---
name: task_ids [48896,48904]
name: task_ids [48896,48904]
===
match
---
number: 1 [64642,64643]
number: 1 [64693,64694]
===
match
---
name: _dag_id [29017,29024]
name: _dag_id [29017,29024]
===
match
---
name: schedule_interval [33640,33657]
name: schedule_interval [33640,33657]
===
match
---
arglist [35639,35678]
arglist [35639,35678]
===
match
---
name: dag_id [28555,28561]
name: dag_id [28555,28561]
===
match
---
expr_stmt [12243,12272]
expr_stmt [12243,12272]
===
match
---
parameters [33236,33242]
parameters [33236,33242]
===
match
---
annassign [51332,51471]
annassign [51383,51522]
===
match
---
atom_expr [31986,31996]
atom_expr [31986,31996]
===
match
---
name: Callable [92490,92498]
name: Callable [92541,92549]
===
match
---
name: start_date [49529,49539]
name: start_date [49580,49590]
===
match
---
expr_stmt [34977,35010]
expr_stmt [34977,35010]
===
match
---
atom_expr [35094,35119]
atom_expr [35094,35119]
===
match
---
operator: , [75715,75716]
operator: , [75766,75767]
===
match
---
operator: = [69811,69812]
operator: = [69862,69863]
===
match
---
trailer [31284,31304]
trailer [31284,31304]
===
match
---
atom_expr [54992,55146]
atom_expr [55043,55197]
===
match
---
tfpdef [10102,10132]
tfpdef [10102,10132]
===
match
---
expr_stmt [34792,34868]
expr_stmt [34792,34868]
===
match
---
operator: = [90610,90611]
operator: = [90661,90662]
===
match
---
name: minute [19419,19425]
name: minute [19419,19425]
===
match
---
operator: , [14196,14197]
operator: , [14196,14197]
===
match
---
name: in_ [74931,74934]
name: in_ [74982,74985]
===
match
---
name: dag_id [74924,74930]
name: dag_id [74975,74981]
===
match
---
name: int [18717,18720]
name: int [18717,18720]
===
match
---
name: setter [29994,30000]
name: setter [29994,30000]
===
match
---
arglist [75347,75377]
arglist [75398,75428]
===
match
---
operator: = [56832,56833]
operator: = [56883,56884]
===
match
---
name: dag_by_ids [75760,75770]
name: dag_by_ids [75811,75821]
===
match
---
operator: = [83289,83290]
operator: = [83340,83341]
===
match
---
name: filter [64149,64155]
name: filter [64200,64206]
===
match
---
name: new_start [24883,24892]
name: new_start [24883,24892]
===
match
---
trailer [31271,31276]
trailer [31271,31276]
===
match
---
name: wrapper [92479,92486]
name: wrapper [92530,92537]
===
match
---
atom_expr [39463,39487]
atom_expr [39463,39487]
===
match
---
name: filtered_child [61578,61592]
name: filtered_child [61629,61643]
===
match
---
simple_stmt [62934,62953]
simple_stmt [62985,63004]
===
match
---
expr_stmt [89541,89568]
expr_stmt [89592,89619]
===
match
---
comp_op [15682,15688]
comp_op [15682,15688]
===
match
---
name: task [51328,51332]
name: task [51379,51383]
===
match
---
atom [77466,77499]
atom [77517,77550]
===
match
---
name: is_paused [87420,87429]
name: is_paused [87471,87480]
===
match
---
operator: , [46204,46205]
operator: , [46204,46205]
===
match
---
name: dag_ids [74020,74027]
name: dag_ids [74071,74078]
===
match
---
arglist [83298,83327]
arglist [83349,83378]
===
match
---
operator: = [85207,85208]
operator: = [85258,85259]
===
match
---
decorated [40705,42317]
decorated [40705,42317]
===
match
---
name: leaves [42576,42582]
name: leaves [42576,42582]
===
match
---
name: dag [79386,79389]
name: dag [79437,79440]
===
match
---
trailer [69789,69800]
trailer [69840,69851]
===
match
---
name: type [71625,71629]
name: type [71676,71680]
===
match
---
trailer [69850,69852]
trailer [69901,69903]
===
match
---
trailer [77379,77392]
trailer [77430,77443]
===
match
---
atom_expr [80827,80867]
atom_expr [80878,80918]
===
match
---
simple_stmt [82708,82784]
simple_stmt [82759,82835]
===
match
---
if_stmt [56793,57035]
if_stmt [56844,57086]
===
match
---
expr_stmt [61862,61921]
expr_stmt [61913,61972]
===
match
---
operator: - [94337,94338]
operator: - [94388,94389]
===
match
---
name: task_dict [59790,59799]
name: task_dict [59841,59850]
===
match
---
trailer [20355,20364]
trailer [20355,20364]
===
match
---
trailer [53428,54446]
trailer [53479,54497]
===
match
---
operator: = [46136,46137]
operator: = [46136,46137]
===
match
---
suite [50210,50273]
suite [50261,50324]
===
match
---
name: setdefault [83095,83105]
name: setdefault [83146,83156]
===
match
---
decorated [45296,45937]
decorated [45296,45937]
===
match
---
operator: = [12084,12085]
operator: = [12084,12085]
===
match
---
sync_comp_for [60054,60117]
sync_comp_for [60105,60168]
===
match
---
trailer [13130,13143]
trailer [13130,13143]
===
match
---
parameters [42345,42351]
parameters [42345,42351]
===
match
---
trailer [36471,36488]
trailer [36471,36488]
===
match
---
name: get_last_dagrun [28784,28799]
name: get_last_dagrun [28784,28799]
===
match
---
tfpdef [45524,45542]
tfpdef [45524,45542]
===
match
---
trailer [12575,12588]
trailer [12575,12588]
===
match
---
name: existing_dag_ids [74231,74247]
name: existing_dag_ids [74282,74298]
===
match
---
atom_expr [29758,29771]
atom_expr [29758,29771]
===
match
---
import_from [1585,1668]
import_from [1585,1668]
===
match
---
argument [53772,53801]
argument [53823,53852]
===
match
---
operator: = [69605,69606]
operator: = [69656,69657]
===
match
---
simple_stmt [16807,16842]
simple_stmt [16807,16842]
===
match
---
expr_stmt [72148,72510]
expr_stmt [72199,72561]
===
match
---
name: Exception [63745,63754]
name: Exception [63796,63805]
===
match
---
trailer [10217,10222]
trailer [10217,10222]
===
match
---
return_stmt [64876,64916]
return_stmt [64927,64967]
===
match
---
name: cls [95218,95221]
name: cls [95269,95272]
===
match
---
param [91143,91166]
param [91194,91217]
===
match
---
name: keys [62868,62872]
name: keys [62919,62923]
===
match
---
trailer [55252,55415]
trailer [55303,55466]
===
match
---
suite [41813,41885]
suite [41813,41885]
===
match
---
argument [80773,80798]
argument [80824,80849]
===
match
---
atom_expr [85264,85339]
atom_expr [85315,85390]
===
match
---
name: dag [92107,92110]
name: dag [92158,92161]
===
match
---
simple_stmt [76238,76263]
simple_stmt [76289,76314]
===
match
---
operator: = [15078,15079]
operator: = [15078,15079]
===
match
---
return_stmt [87907,87984]
return_stmt [87958,88035]
===
match
---
name: airflow [2258,2265]
name: airflow [2258,2265]
===
match
---
operator: = [46310,46311]
operator: = [46310,46311]
===
match
---
comparison [51114,51148]
comparison [51165,51199]
===
match
---
string: """Returns the latest date for which at least one dag run exists""" [37895,37962]
string: """Returns the latest date for which at least one dag run exists""" [37895,37962]
===
match
---
name: ExternalTaskMarker [51334,51352]
name: ExternalTaskMarker [51385,51403]
===
match
---
simple_stmt [2922,2978]
simple_stmt [2922,2978]
===
match
---
suite [39221,39261]
suite [39221,39261]
===
match
---
trailer [84676,84685]
trailer [84727,84736]
===
match
---
name: utils [2365,2370]
name: utils [2365,2370]
===
match
---
trailer [59934,59946]
trailer [59985,59997]
===
match
---
name: session [88588,88595]
name: session [88639,88646]
===
match
---
import_from [1984,2067]
import_from [1984,2067]
===
match
---
name: get_prev [21558,21566]
name: get_prev [21558,21566]
===
match
---
arith_expr [60837,60865]
arith_expr [60888,60916]
===
match
---
operator: = [86510,86511]
operator: = [86561,86562]
===
match
---
simple_stmt [54830,54843]
simple_stmt [54881,54894]
===
match
---
operator: = [13209,13210]
operator: = [13209,13210]
===
match
---
suite [54524,54548]
suite [54575,54599]
===
match
---
param [40749,40754]
param [40749,40754]
===
match
---
atom_expr [52304,52314]
atom_expr [52355,52365]
===
match
---
name: fileloc [12286,12293]
name: fileloc [12286,12293]
===
match
---
name: datetime [70082,70090]
name: datetime [70133,70141]
===
match
---
trailer [72160,72510]
trailer [72211,72561]
===
match
---
atom_expr [77036,77044]
atom_expr [77087,77095]
===
match
---
name: TI [50411,50413]
name: TI [50462,50464]
===
match
---
expr_stmt [57507,57516]
expr_stmt [57558,57567]
===
match
---
trailer [77148,77153]
trailer [77199,77204]
===
match
---
name: execution_date [38008,38022]
name: execution_date [38008,38022]
===
match
---
expr_stmt [29095,29115]
expr_stmt [29095,29115]
===
match
---
name: cls [95565,95568]
name: cls [95616,95619]
===
match
---
operator: , [11275,11276]
operator: , [11275,11276]
===
match
---
name: items [18169,18174]
name: items [18169,18174]
===
match
---
operator: , [1387,1388]
operator: , [1387,1388]
===
match
---
operator: >= [32122,32124]
operator: >= [32122,32124]
===
match
---
operator: = [76256,76257]
operator: = [76307,76308]
===
match
---
name: task_id [63321,63328]
name: task_id [63372,63379]
===
match
---
operator: = [42004,42005]
operator: = [42004,42005]
===
match
---
operator: = [43535,43536]
operator: = [43535,43536]
===
match
---
simple_stmt [72519,72536]
simple_stmt [72570,72587]
===
match
---
atom_expr [95125,95134]
atom_expr [95176,95185]
===
match
---
simple_stmt [46451,48564]
simple_stmt [46451,48564]
===
match
---
operator: = [3128,3129]
operator: = [3128,3129]
===
match
---
expr_stmt [85189,85225]
expr_stmt [85240,85276]
===
match
---
trailer [10825,10858]
trailer [10825,10858]
===
match
---
atom_expr [53149,53384]
atom_expr [53200,53435]
===
match
---
trailer [10568,10575]
trailer [10568,10575]
===
match
---
name: cls [57776,57779]
name: cls [57827,57830]
===
match
---
simple_stmt [21878,21919]
simple_stmt [21878,21919]
===
match
---
parameters [30092,30123]
parameters [30092,30123]
===
match
---
operator: = [94014,94015]
operator: = [94065,94066]
===
match
---
name: dag_obj [94236,94243]
name: dag_obj [94287,94294]
===
match
---
name: BaseOperator [30495,30507]
name: BaseOperator [30495,30507]
===
match
---
name: dag [62854,62857]
name: dag [62905,62908]
===
match
---
comparison [91630,91671]
comparison [91681,91722]
===
match
---
name: RUNNING [50545,50552]
name: RUNNING [50596,50603]
===
match
---
dotted_name [38672,38696]
dotted_name [38672,38696]
===
match
---
name: count [80492,80497]
name: count [80543,80548]
===
match
---
name: schedule_interval [31683,31700]
name: schedule_interval [31683,31700]
===
match
---
name: SubDagOperator [38704,38718]
name: SubDagOperator [38704,38718]
===
match
---
param [29066,29076]
param [29066,29076]
===
match
---
name: log [79558,79561]
name: log [79609,79612]
===
match
---
simple_stmt [86331,86362]
simple_stmt [86382,86413]
===
match
---
name: orm_dag [74630,74637]
name: orm_dag [74681,74688]
===
match
---
atom_expr [64746,64756]
atom_expr [64797,64807]
===
match
---
name: permissions [2097,2108]
name: permissions [2097,2108]
===
match
---
trailer [39235,39258]
trailer [39235,39258]
===
match
---
name: __ne__ [16475,16481]
name: __ne__ [16475,16481]
===
match
---
operator: = [55319,55320]
operator: = [55370,55371]
===
match
---
name: join [31528,31532]
name: join [31528,31532]
===
match
---
param [10149,10185]
param [10149,10185]
===
match
---
trailer [90844,90874]
trailer [90895,90925]
===
match
---
operator: = [60738,60739]
operator: = [60789,60790]
===
match
---
name: filters [40324,40331]
name: filters [40324,40331]
===
match
---
name: id [64411,64413]
name: id [64462,64464]
===
match
---
operator: , [45353,45354]
operator: , [45353,45354]
===
match
---
simple_stmt [84658,84686]
simple_stmt [84709,84737]
===
match
---
suite [16122,16162]
suite [16122,16162]
===
match
---
simple_stmt [64475,64528]
simple_stmt [64526,64579]
===
match
---
operator: = [58105,58106]
operator: = [58156,58157]
===
match
---
name: task_dict [59912,59921]
name: task_dict [59963,59972]
===
match
---
operator: = [10178,10179]
operator: = [10178,10179]
===
match
---
name: upstream_task_id [40632,40648]
name: upstream_task_id [40632,40648]
===
match
---
decorated [86439,86599]
decorated [86490,86650]
===
match
---
return_stmt [42728,42792]
return_stmt [42728,42792]
===
match
---
expr_stmt [18853,18868]
expr_stmt [18853,18868]
===
match
---
name: all_tis [56117,56124]
name: all_tis [56168,56175]
===
match
---
trailer [80553,80560]
trailer [80604,80611]
===
match
---
simple_stmt [21181,21212]
simple_stmt [21181,21212]
===
match
---
operator: } [14920,14921]
operator: } [14920,14921]
===
match
---
name: tasks [62914,62919]
name: tasks [62965,62970]
===
match
---
name: access_control [15873,15887]
name: access_control [15873,15887]
===
match
---
arglist [56200,56556]
arglist [56251,56607]
===
match
---
operator: = [32711,32712]
operator: = [32711,32712]
===
match
---
name: str [30105,30108]
name: str [30105,30108]
===
match
---
name: self [39186,39190]
name: self [39186,39190]
===
match
---
param [34054,34059]
param [34054,34059]
===
match
---
name: cls [95191,95194]
name: cls [95242,95245]
===
match
---
name: is_paused [88680,88689]
name: is_paused [88731,88740]
===
match
---
factor [94337,94339]
factor [94388,94390]
===
match
---
atom_expr [12719,12766]
atom_expr [12719,12766]
===
match
---
expr_stmt [19321,19352]
expr_stmt [19321,19352]
===
match
---
param [63936,63941]
param [63987,63992]
===
match
---
atom_expr [95538,95562]
atom_expr [95589,95613]
===
match
---
trailer [86026,86038]
trailer [86077,86089]
===
match
---
name: self [83449,83453]
name: self [83500,83504]
===
match
---
simple_stmt [60035,60119]
simple_stmt [60086,60170]
===
match
---
name: RUNNING [45382,45389]
name: RUNNING [45382,45389]
===
match
---
name: upstream_group_ids [62168,62186]
name: upstream_group_ids [62219,62237]
===
match
---
name: Boolean [84056,84063]
name: Boolean [84107,84114]
===
match
---
trailer [66073,66088]
trailer [66124,66139]
===
match
---
name: filter [48972,48978]
name: filter [48972,48978]
===
match
---
name: edge_info [15417,15426]
name: edge_info [15417,15426]
===
match
---
arith_expr [40867,40900]
arith_expr [40867,40900]
===
match
---
name: DagModel [86547,86555]
name: DagModel [86598,86606]
===
match
---
simple_stmt [82926,83072]
simple_stmt [82977,83123]
===
match
---
name: findall [60080,60087]
name: findall [60131,60138]
===
match
---
name: searchpath [39425,39435]
name: searchpath [39425,39435]
===
match
---
arglist [49518,50154]
arglist [49569,50205]
===
match
---
operator: , [22855,22856]
operator: , [22855,22856]
===
match
---
operator: = [10073,10074]
operator: = [10073,10074]
===
match
---
trailer [27493,27499]
trailer [27493,27499]
===
match
---
parameters [29152,29158]
parameters [29152,29158]
===
match
---
param [16116,16120]
param [16116,16120]
===
match
---
trailer [35650,35657]
trailer [35650,35657]
===
match
---
arglist [84159,84181]
arglist [84210,84232]
===
match
---
trailer [12914,12923]
trailer [12914,12923]
===
match
---
name: ti_key [51067,51073]
name: ti_key [51118,51124]
===
match
---
trailer [95129,95134]
trailer [95180,95185]
===
match
---
suite [46442,55781]
suite [46442,55832]
===
match
---
trailer [76959,76966]
trailer [77010,77017]
===
match
---
name: intersection [62424,62436]
name: intersection [62475,62487]
===
match
---
tfpdef [87089,87105]
tfpdef [87140,87156]
===
match
---
operator: @ [78975,78976]
operator: @ [79026,79027]
===
match
---
name: is_active [76246,76255]
name: is_active [76297,76306]
===
match
---
trailer [18212,18218]
trailer [18212,18218]
===
match
---
name: BaseOperator [61285,61297]
name: BaseOperator [61336,61348]
===
match
---
name: get_task [63079,63087]
name: get_task [63130,63138]
===
match
---
operator: = [76129,76130]
operator: = [76180,76181]
===
match
---
name: task [66249,66253]
name: task [66300,66304]
===
match
---
arglist [42050,42118]
arglist [42050,42118]
===
match
---
name: task_dict [62764,62773]
name: task_dict [62815,62824]
===
match
---
if_stmt [89752,89835]
if_stmt [89803,89886]
===
match
---
operator: , [53996,53997]
operator: , [54047,54048]
===
match
---
name: Environment [39303,39314]
name: Environment [39303,39314]
===
match
---
arglist [72960,73115]
arglist [73011,73166]
===
match
---
name: owner [31328,31333]
name: owner [31328,31333]
===
match
---
name: self [28550,28554]
name: self [28550,28554]
===
match
---
atom_expr [66057,66088]
atom_expr [66108,66139]
===
match
---
name: last_pickled [64317,64329]
name: last_pickled [64368,64380]
===
match
---
atom_expr [21258,21271]
atom_expr [21258,21271]
===
match
---
param [30588,30593]
param [30588,30593]
===
match
---
trailer [86000,86010]
trailer [86051,86061]
===
match
---
trailer [3680,3685]
trailer [3680,3685]
===
match
---
trailer [62908,62920]
trailer [62959,62971]
===
match
---
name: dag_id [80564,80570]
name: dag_id [80615,80621]
===
match
---
trailer [11904,11917]
trailer [11904,11917]
===
match
---
operator: = [49854,49855]
operator: = [49905,49906]
===
match
---
atom_expr [15897,15925]
atom_expr [15897,15925]
===
match
---
arglist [64901,64915]
arglist [64952,64966]
===
match
---
simple_stmt [48598,48622]
simple_stmt [48598,48622]
===
match
---
name: self [29463,29467]
name: self [29463,29467]
===
match
---
operator: + [51851,51852]
operator: + [51902,51903]
===
match
---
atom_expr [11404,11423]
atom_expr [11404,11423]
===
match
---
arglist [81031,81100]
arglist [81082,81151]
===
match
---
trailer [2946,2977]
trailer [2946,2977]
===
match
---
parameters [35862,35905]
parameters [35862,35905]
===
match
---
operator: , [75117,75118]
operator: , [75168,75169]
===
match
---
trailer [26015,26019]
trailer [26015,26019]
===
match
---
atom_expr [83720,83734]
atom_expr [83771,83785]
===
match
---
parameters [3177,3230]
parameters [3177,3230]
===
match
---
expr_stmt [58077,58132]
expr_stmt [58128,58183]
===
match
---
name: orm_dag [74528,74535]
name: orm_dag [74579,74586]
===
match
---
atom_expr [81416,81439]
atom_expr [81467,81490]
===
match
---
name: self [64034,64038]
name: self [64085,64089]
===
match
---
operator: = [41018,41019]
operator: = [41018,41019]
===
match
---
return_stmt [23190,23264]
return_stmt [23190,23264]
===
match
---
expr_stmt [41417,41457]
expr_stmt [41417,41457]
===
match
---
name: Optional [29758,29766]
name: Optional [29758,29766]
===
match
---
operator: ** [92158,92160]
operator: ** [92209,92211]
===
match
---
suite [64757,64788]
suite [64808,64839]
===
match
---
simple_stmt [78874,78896]
simple_stmt [78925,78947]
===
match
---
import_as_names [1042,1200]
import_as_names [1042,1200]
===
match
---
import_as_name [2784,2806]
import_as_name [2784,2806]
===
match
---
name: tasks [30475,30480]
name: tasks [30475,30480]
===
match
---
name: state [81044,81049]
name: state [81095,81100]
===
match
---
operator: , [38423,38424]
operator: , [38423,38424]
===
match
---
name: task_dict [61416,61425]
name: task_dict [61467,61476]
===
match
---
if_stmt [21427,21866]
if_stmt [21427,21866]
===
match
---
simple_stmt [3421,3433]
simple_stmt [3421,3433]
===
match
---
operator: , [69399,69400]
operator: , [69450,69451]
===
match
---
param [18673,18694]
param [18673,18694]
===
match
---
operator: = [10361,10362]
operator: = [10361,10362]
===
match
---
trailer [14949,14957]
trailer [14949,14957]
===
match
---
param [79916,79923]
param [79967,79974]
===
match
---
simple_stmt [39094,39128]
simple_stmt [39094,39128]
===
match
---
trailer [60346,60365]
trailer [60397,60416]
===
match
---
operator: = [13895,13896]
operator: = [13895,13896]
===
match
---
name: tis [50593,50596]
name: tis [50644,50647]
===
match
---
number: 1 [35033,35034]
number: 1 [35033,35034]
===
match
---
atom_expr [64172,64185]
atom_expr [64223,64236]
===
match
---
trailer [69039,69060]
trailer [69090,69111]
===
match
---
name: self [14114,14118]
name: self [14114,14118]
===
match
---
name: dag_id [75639,75645]
name: dag_id [75690,75696]
===
match
---
simple_stmt [12243,12273]
simple_stmt [12243,12273]
===
match
---
name: __class__ [57737,57746]
name: __class__ [57788,57797]
===
match
---
name: value [29483,29488]
name: value [29483,29488]
===
match
---
atom_expr [3700,3713]
atom_expr [3700,3713]
===
match
---
atom_expr [80769,80799]
atom_expr [80820,80850]
===
match
---
operator: = [61593,61594]
operator: = [61644,61645]
===
match
---
operator: , [2879,2880]
operator: , [2879,2880]
===
match
---
comparison [62888,62920]
comparison [62939,62971]
===
match
---
operator: - [35032,35033]
operator: - [35032,35033]
===
match
---
trailer [39901,39926]
trailer [39901,39926]
===
match
---
operator: == [43619,43621]
operator: == [43619,43621]
===
match
---
trailer [3662,3688]
trailer [3662,3688]
===
match
---
if_stmt [41356,41528]
if_stmt [41356,41528]
===
match
---
suite [17021,17072]
suite [17021,17072]
===
match
---
operator: = [67095,67096]
operator: = [67146,67147]
===
match
---
name: in_ [81194,81197]
name: in_ [81245,81248]
===
match
---
trailer [64347,64349]
trailer [64398,64400]
===
match
---
expr_stmt [44544,44559]
expr_stmt [44544,44559]
===
match
---
simple_stmt [85396,85458]
simple_stmt [85447,85509]
===
match
---
expr_stmt [29643,29713]
expr_stmt [29643,29713]
===
match
---
trailer [36264,36278]
trailer [36264,36278]
===
match
---
name: has_task [62982,62990]
name: has_task [63033,63041]
===
match
---
operator: , [66869,66870]
operator: , [66920,66921]
===
match
---
name: is_ [41874,41877]
name: is_ [41874,41877]
===
match
---
simple_stmt [90604,90935]
simple_stmt [90655,90986]
===
match
---
operator: -> [30729,30731]
operator: -> [30729,30731]
===
match
---
name: session [79039,79046]
name: session [79090,79097]
===
match
---
atom_expr [29962,29977]
atom_expr [29962,29977]
===
match
---
simple_stmt [93198,93221]
simple_stmt [93249,93272]
===
match
---
trailer [52872,52896]
trailer [52923,52947]
===
match
---
trailer [83726,83734]
trailer [83777,83785]
===
match
---
name: next_dagrun_create_after [85611,85635]
name: next_dagrun_create_after [85662,85686]
===
match
---
trailer [38031,38061]
trailer [38031,38061]
===
match
---
parameters [64451,64457]
parameters [64502,64508]
===
match
---
parameters [63087,63138]
parameters [63138,63189]
===
match
---
name: filter [81168,81174]
name: filter [81219,81225]
===
match
---
name: Optional [22214,22222]
name: Optional [22214,22222]
===
match
---
operator: = [48602,48603]
operator: = [48602,48603]
===
match
---
name: task [43493,43497]
name: task [43493,43497]
===
match
---
dotted_name [29984,30000]
dotted_name [29984,30000]
===
match
---
operator: = [62398,62399]
operator: = [62449,62450]
===
match
---
suite [72855,73177]
suite [72906,73228]
===
match
---
trailer [13332,13343]
trailer [13332,13343]
===
match
---
trailer [27980,27999]
trailer [27980,27999]
===
match
---
trailer [26025,26098]
trailer [26025,26098]
===
match
---
trailer [48866,48873]
trailer [48866,48873]
===
match
---
trailer [91609,91625]
trailer [91660,91676]
===
match
---
expr_stmt [63554,63578]
expr_stmt [63605,63629]
===
match
---
trailer [11872,11882]
trailer [11872,11882]
===
match
---
simple_stmt [74618,74639]
simple_stmt [74669,74690]
===
match
---
name: self [48808,48812]
name: self [48808,48812]
===
match
---
decorated [92729,94244]
decorated [92780,94295]
===
match
---
atom_expr [22223,22240]
atom_expr [22223,22240]
===
match
---
simple_stmt [14945,14968]
simple_stmt [14945,14968]
===
match
---
operator: = [76038,76039]
operator: = [76089,76090]
===
match
---
name: self [29527,29531]
name: self [29527,29531]
===
match
---
suite [16790,16842]
suite [16790,16842]
===
match
---
trailer [35633,35638]
trailer [35633,35638]
===
match
---
name: acyclic [44835,44842]
name: acyclic [44835,44842]
===
match
---
name: TI [50527,50529]
name: TI [50578,50580]
===
match
---
atom_expr [81072,81100]
atom_expr [81123,81151]
===
match
---
name: get_downstream [64541,64555]
name: get_downstream [64592,64606]
===
match
---
and_test [26532,26564]
and_test [26532,26564]
===
match
---
atom_expr [60724,60737]
atom_expr [60775,60788]
===
match
---
atom_expr [39047,39077]
atom_expr [39047,39077]
===
match
---
trailer [25802,25813]
trailer [25802,25813]
===
match
---
param [29153,29157]
param [29153,29157]
===
match
---
name: Optional [70274,70282]
name: Optional [70325,70333]
===
match
---
trailer [12263,12265]
trailer [12263,12265]
===
match
---
trailer [39119,39127]
trailer [39119,39127]
===
match
---
operator: = [84478,84479]
operator: = [84529,84530]
===
match
---
atom_expr [16373,16395]
atom_expr [16373,16395]
===
match
---
name: dag_by_ids [73842,73852]
name: dag_by_ids [73893,73903]
===
match
---
name: t [62704,62705]
name: t [62755,62756]
===
match
---
name: ACTION_CAN_EDIT [18064,18079]
name: ACTION_CAN_EDIT [18064,18079]
===
match
---
atom_expr [60783,60792]
atom_expr [60834,60843]
===
match
---
name: self [14035,14039]
name: self [14035,14039]
===
match
---
return_stmt [38443,38482]
return_stmt [38443,38482]
===
match
---
string: """Print an ASCII tree representation of the DAG.""" [64475,64527]
string: """Print an ASCII tree representation of the DAG.""" [64526,64578]
===
match
---
name: RUNNING [35671,35678]
name: RUNNING [35671,35678]
===
match
---
name: dag_id [45661,45667]
name: dag_id [45661,45667]
===
match
---
name: getint [86084,86090]
name: getint [86135,86141]
===
match
---
expr_stmt [53136,53384]
expr_stmt [53187,53435]
===
match
---
atom_expr [94016,94042]
atom_expr [94067,94093]
===
match
---
name: Column [85638,85644]
name: Column [85689,85695]
===
match
---
operator: = [55677,55678]
operator: = [55728,55729]
===
match
---
if_stmt [95487,95664]
if_stmt [95538,95715]
===
match
---
name: visited_external_tis [51018,51038]
name: visited_external_tis [51069,51089]
===
match
---
trailer [20468,20478]
trailer [20468,20478]
===
match
---
name: DagContext [17335,17345]
name: DagContext [17335,17345]
===
match
---
name: dag [64172,64175]
name: dag [64223,64226]
===
match
---
operator: , [75098,75099]
operator: , [75149,75150]
===
match
---
parameters [57612,57624]
parameters [57663,57675]
===
match
---
import_from [1767,1807]
import_from [1767,1807]
===
match
---
name: ExternalTaskMarker [51389,51407]
name: ExternalTaskMarker [51440,51458]
===
match
---
for_stmt [77125,77393]
for_stmt [77176,77444]
===
match
---
operator: , [66914,66915]
operator: , [66965,66966]
===
match
---
name: unique [85815,85821]
name: unique [85866,85872]
===
match
---
name: Optional [9890,9898]
name: Optional [9890,9898]
===
match
---
if_stmt [24053,24146]
if_stmt [24053,24146]
===
match
---
trailer [64014,64046]
trailer [64065,64097]
===
match
---
atom_expr [50437,50445]
atom_expr [50488,50496]
===
match
---
name: self [65849,65853]
name: self [65900,65904]
===
match
---
name: dag [64907,64910]
name: dag [64958,64961]
===
match
---
atom_expr [62578,62587]
atom_expr [62629,62638]
===
match
---
name: next_run_date [27853,27866]
name: next_run_date [27853,27866]
===
match
---
string: '_full_filepath' [81642,81658]
string: '_full_filepath' [81693,81709]
===
match
---
operator: = [50833,50834]
operator: = [50884,50885]
===
match
---
name: dag [63374,63377]
name: dag [63425,63428]
===
match
---
trailer [36320,36327]
trailer [36320,36327]
===
match
---
name: dag_id [41096,41102]
name: dag_id [41096,41102]
===
match
---
name: end_date [57182,57190]
name: end_date [57233,57241]
===
match
---
trailer [60785,60792]
trailer [60836,60843]
===
match
---
name: permissions [17967,17978]
name: permissions [17967,17978]
===
match
---
trailer [39302,39314]
trailer [39302,39314]
===
match
---
atom_expr [73787,73797]
atom_expr [73838,73848]
===
match
---
operator: @ [28653,28654]
operator: @ [28653,28654]
===
match
---
suite [63193,63237]
suite [63244,63288]
===
match
---
name: t [56849,56850]
name: t [56900,56901]
===
match
---
suite [37886,38071]
suite [37886,38071]
===
match
---
operator: , [75498,75499]
operator: , [75549,75550]
===
match
---
trailer [20287,20297]
trailer [20287,20297]
===
match
---
trailer [50842,50844]
trailer [50893,50895]
===
match
---
atom_expr [60765,60799]
atom_expr [60816,60850]
===
match
---
name: is_paused [88669,88678]
name: is_paused [88720,88729]
===
match
---
trailer [24550,24569]
trailer [24550,24569]
===
match
---
suite [11823,11928]
suite [11823,11928]
===
match
---
name: context [35195,35202]
name: context [35195,35202]
===
match
---
trailer [77318,77323]
trailer [77369,77374]
===
match
---
operator: , [77266,77267]
operator: , [77317,77318]
===
match
---
atom_expr [3470,3479]
atom_expr [3470,3479]
===
match
---
operator: = [55887,55888]
operator: = [55938,55939]
===
match
---
operator: = [45582,45583]
operator: = [45582,45583]
===
match
---
string: "Deactivating DAG ID %s since it was last touched by the scheduler at %s" [79584,79657]
string: "Deactivating DAG ID %s since it was last touched by the scheduler at %s" [79635,79708]
===
match
---
decorated [95368,95687]
decorated [95419,95738]
===
match
---
name: update [40237,40243]
name: update [40237,40243]
===
match
---
simple_stmt [29955,29978]
simple_stmt [29955,29978]
===
match
---
name: Column [83291,83297]
name: Column [83342,83348]
===
match
---
argument [88692,88719]
argument [88743,88770]
===
match
---
operator: -> [39293,39295]
operator: -> [39293,39295]
===
match
---
trailer [86730,86737]
trailer [86781,86788]
===
match
---
simple_stmt [25251,25314]
simple_stmt [25251,25314]
===
match
---
expr_stmt [83940,83998]
expr_stmt [83991,84049]
===
match
---
name: downstream_task_id [82760,82778]
name: downstream_task_id [82811,82829]
===
match
---
operator: } [88689,88690]
operator: } [88740,88741]
===
match
---
operator: = [54091,54092]
operator: = [54142,54143]
===
match
---
name: self [11503,11507]
name: self [11503,11507]
===
match
---
simple_stmt [910,946]
simple_stmt [910,946]
===
match
---
name: include_subdags [48654,48669]
name: include_subdags [48654,48669]
===
match
---
name: session [79952,79959]
name: session [80003,80010]
===
match
---
operator: , [19554,19555]
operator: , [19554,19555]
===
match
---
name: os [839,841]
name: os [839,841]
===
match
---
tfpdef [70158,70178]
tfpdef [70209,70229]
===
match
---
parameters [29435,29453]
parameters [29435,29453]
===
match
---
operator: > [26244,26245]
operator: > [26244,26245]
===
match
---
name: last_expired [84465,84477]
name: last_expired [84516,84528]
===
match
---
atom_expr [49301,49342]
atom_expr [49352,49393]
===
match
---
simple_stmt [79975,80459]
simple_stmt [80026,80510]
===
match
---
trailer [52209,52216]
trailer [52260,52267]
===
match
---
operator: , [18786,18787]
operator: , [18786,18787]
===
match
---
trailer [87480,87489]
trailer [87531,87540]
===
match
---
trailer [2910,2920]
trailer [2910,2920]
===
match
---
name: RUNNING [36371,36378]
name: RUNNING [36371,36378]
===
match
---
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_concurrency_reached` method." [32335,32430]
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_concurrency_reached` method." [32335,32430]
===
match
---
or_test [27442,27501]
or_test [27442,27501]
===
match
---
if_stmt [38788,39128]
if_stmt [38788,39128]
===
match
---
name: on_failure_callback [15176,15195]
name: on_failure_callback [15176,15195]
===
match
---
not_test [64206,64212]
not_test [64257,64263]
===
match
---
name: dttm [20829,20833]
name: dttm [20829,20833]
===
match
---
expr_stmt [24784,24830]
expr_stmt [24784,24830]
===
match
---
name: log [34907,34910]
name: log [34907,34910]
===
match
---
trailer [41033,41047]
trailer [41033,41047]
===
match
---
name: cron [20274,20278]
name: cron [20274,20278]
===
match
---
suite [30919,31139]
suite [30919,31139]
===
match
---
atom_expr [85522,85541]
atom_expr [85573,85592]
===
match
---
name: default [30443,30450]
name: default [30443,30450]
===
match
---
name: self [34902,34906]
name: self [34902,34906]
===
match
---
atom_expr [17061,17070]
atom_expr [17061,17070]
===
match
---
name: dagrun_timeout [10691,10705]
name: dagrun_timeout [10691,10705]
===
match
---
name: BaseOperator [1754,1766]
name: BaseOperator [1754,1766]
===
match
---
param [86503,86515]
param [86554,86566]
===
match
---
tfpdef [58667,58724]
tfpdef [58718,58775]
===
match
---
dotted_name [1989,2016]
dotted_name [1989,2016]
===
match
---
atom_expr [71824,71897]
atom_expr [71875,71948]
===
match
---
or_test [12846,12896]
or_test [12846,12896]
===
match
---
import_from [94400,94460]
import_from [94451,94511]
===
match
---
name: self [30723,30727]
name: self [30723,30727]
===
match
---
trailer [11917,11927]
trailer [11917,11927]
===
match
---
trailer [52648,52663]
trailer [52699,52714]
===
match
---
name: group [61223,61228]
name: group [61274,61279]
===
match
---
suite [42167,42236]
suite [42167,42236]
===
match
---
name: dag_run_state [49841,49854]
name: dag_run_state [49892,49905]
===
match
---
name: filter [52482,52488]
name: filter [52533,52539]
===
match
---
simple_stmt [27423,27502]
simple_stmt [27423,27502]
===
match
---
name: include_subdags [56396,56411]
name: include_subdags [56447,56462]
===
match
---
expr_stmt [11997,12057]
expr_stmt [11997,12057]
===
match
---
name: upstream_list [44648,44661]
name: upstream_list [44648,44661]
===
match
---
name: utils [2189,2194]
name: utils [2189,2194]
===
match
---
atom_expr [64312,64329]
atom_expr [64363,64380]
===
match
---
name: orm_tag_names [77194,77207]
name: orm_tag_names [77245,77258]
===
match
---
operator: , [37162,37163]
operator: , [37162,37163]
===
match
---
name: Optional [10514,10522]
name: Optional [10514,10522]
===
match
---
argument [57448,57461]
argument [57499,57512]
===
match
---
funcdef [16167,16466]
funcdef [16167,16466]
===
match
---
name: cls [90640,90643]
name: cls [90691,90694]
===
match
---
argument [39962,39981]
argument [39962,39981]
===
match
---
simple_stmt [3640,3689]
simple_stmt [3640,3689]
===
match
---
name: orm_dags [75707,75715]
name: orm_dags [75758,75766]
===
match
---
comparison [22713,22743]
comparison [22713,22743]
===
match
---
name: DagRun [74995,75001]
name: DagRun [75046,75052]
===
match
---
name: default_args [13591,13603]
name: default_args [13591,13603]
===
match
---
trailer [40243,40269]
trailer [40243,40269]
===
match
---
name: roots [42340,42345]
name: roots [42340,42345]
===
match
---
trailer [88595,88601]
trailer [88646,88652]
===
match
---
trailer [61091,61114]
trailer [61142,61165]
===
match
---
name: dag_ids [87481,87488]
name: dag_ids [87532,87539]
===
match
---
trailer [94334,94340]
trailer [94385,94391]
===
match
---
simple_stmt [61026,61052]
simple_stmt [61077,61103]
===
match
---
expr_stmt [56689,56701]
expr_stmt [56740,56752]
===
match
---
name: tags [85257,85261]
name: tags [85308,85312]
===
match
---
trailer [74535,74540]
trailer [74586,74591]
===
match
---
trailer [14221,14237]
trailer [14221,14237]
===
match
---
trailer [86351,86358]
trailer [86402,86409]
===
match
---
name: include_subdags [49743,49758]
name: include_subdags [49794,49809]
===
match
---
name: datetime [18802,18810]
name: datetime [18802,18810]
===
match
---
atom_expr [74146,74160]
atom_expr [74197,74211]
===
match
---
decorator [78975,78992]
decorator [79026,79043]
===
match
---
expr_stmt [27960,28014]
expr_stmt [27960,28014]
===
match
---
name: filtered_child [61811,61825]
name: filtered_child [61862,61876]
===
match
---
name: of [90973,90975]
name: of [91024,91026]
===
match
---
expr_stmt [85127,85160]
expr_stmt [85178,85211]
===
match
---
atom_expr [20030,20063]
atom_expr [20030,20063]
===
match
---
name: self [16482,16486]
name: self [16482,16486]
===
match
---
expr_stmt [84579,84611]
expr_stmt [84630,84662]
===
match
---
name: __serialized_fields [81420,81439]
name: __serialized_fields [81471,81490]
===
match
---
operator: = [92672,92673]
operator: = [92723,92724]
===
match
---
name: ask_yesno [55181,55190]
name: ask_yesno [55232,55241]
===
match
---
name: jinja2 [39296,39302]
name: jinja2 [39296,39302]
===
match
---
name: template_searchpath [13836,13855]
name: template_searchpath [13836,13855]
===
match
---
operator: = [85323,85324]
operator: = [85374,85375]
===
match
---
name: int [29353,29356]
name: int [29353,29356]
===
match
---
trailer [30736,30741]
trailer [30736,30741]
===
match
---
name: dag_run_state [53983,53996]
name: dag_run_state [54034,54047]
===
match
---
operator: , [1707,1708]
operator: , [1707,1708]
===
match
---
name: query [45633,45638]
name: query [45633,45638]
===
match
---
trailer [89305,89311]
trailer [89356,89362]
===
match
---
name: self [92016,92020]
name: self [92067,92071]
===
match
---
operator: = [18924,18925]
operator: = [18924,18925]
===
match
---
atom [35704,35706]
atom [35704,35706]
===
match
---
trailer [45667,45671]
trailer [45667,45671]
===
match
---
fstring [16138,16161]
fstring [16138,16161]
===
match
---
name: previous_schedule [20805,20822]
name: previous_schedule [20805,20822]
===
match
---
atom_expr [61176,61191]
atom_expr [61227,61242]
===
match
---
atom_expr [62162,62186]
atom_expr [62213,62237]
===
match
---
name: start_date [65094,65104]
name: start_date [65145,65155]
===
match
---
comparison [41487,41526]
comparison [41487,41526]
===
match
---
name: orm_dag [75947,75954]
name: orm_dag [75998,76005]
===
match
---
expr_stmt [59895,59921]
expr_stmt [59946,59972]
===
match
---
string: """         Returns the list of dag runs between start_date (inclusive) and end_date (inclusive).          :param start_date: The starting execution date of the DagRun to find.         :param end_date: The ending execution date of the DagRun to find.         :param session:         :return: The list of DagRuns found.         """ [37187,37517]
string: """         Returns the list of dag runs between start_date (inclusive) and end_date (inclusive).          :param start_date: The starting execution date of the DagRun to find.         :param end_date: The ending execution date of the DagRun to find.         :param session:         :return: The list of DagRuns found.         """ [37187,37517]
===
match
---
trailer [15901,15925]
trailer [15901,15925]
===
match
---
argument [54084,54099]
argument [54135,54150]
===
match
---
name: all_tis [56672,56679]
name: all_tis [56723,56730]
===
match
---
name: filter [49047,49053]
name: filter [49047,49053]
===
match
---
expr_stmt [16026,16042]
expr_stmt [16026,16042]
===
match
---
decorator [29030,29045]
decorator [29030,29045]
===
match
---
operator: = [35645,35646]
operator: = [35645,35646]
===
match
---
name: default_args [11860,11872]
name: default_args [11860,11872]
===
match
---
name: task_start_dates [25132,25148]
name: task_start_dates [25132,25148]
===
match
---
suite [41665,42236]
suite [41665,42236]
===
match
---
operator: , [64719,64720]
operator: , [64770,64771]
===
match
---
name: DagModel [87461,87469]
name: DagModel [87512,87520]
===
match
---
name: dag_id [92111,92117]
name: dag_id [92162,92168]
===
match
---
if_stmt [54513,54548]
if_stmt [54564,54599]
===
match
---
name: perms [18145,18150]
name: perms [18145,18150]
===
match
---
string: """         Creates a dag run from this dag including the tasks associated with this dag.         Returns the dag run.          :param run_id: defines the run id for this dag run         :type run_id: str         :param run_type: type of DagRun         :type run_type: airflow.utils.types.DagRunType         :param execution_date: the execution date of this dag run         :type execution_date: datetime.datetime         :param state: the state of the dag run         :type state: airflow.utils.state.State         :param start_date: the date this dag run should be evaluated         :type start_date: datetime         :param external_trigger: whether this dag run is externally triggered         :type external_trigger: bool         :param conf: Dict containing configuration/parameters to pass to the DAG         :type conf: dict         :param creating_job_id: id of the job creating this DagRun         :type creating_job_id: int         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param dag_hash: Hash of Serialized DAG         :type dag_hash: str         """ [70358,71475]
string: """         Creates a dag run from this dag including the tasks associated with this dag.         Returns the dag run.          :param run_id: defines the run id for this dag run         :type run_id: str         :param run_type: type of DagRun         :type run_type: airflow.utils.types.DagRunType         :param execution_date: the execution date of this dag run         :type execution_date: datetime.datetime         :param state: the state of the dag run         :type state: airflow.utils.state.State         :param start_date: the date this dag run should be evaluated         :type start_date: datetime         :param external_trigger: whether this dag run is externally triggered         :type external_trigger: bool         :param conf: Dict containing configuration/parameters to pass to the DAG         :type conf: dict         :param creating_job_id: id of the job creating this DagRun         :type creating_job_id: int         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param dag_hash: Hash of Serialized DAG         :type dag_hash: str         """ [70409,71526]
===
match
---
expr_stmt [85396,85457]
expr_stmt [85447,85508]
===
match
---
dotted_name [1719,1746]
dotted_name [1719,1746]
===
match
---
name: Dict [10523,10527]
name: Dict [10523,10527]
===
match
---
name: graph_sorted [43650,43662]
name: graph_sorted [43650,43662]
===
match
---
trailer [40631,40649]
trailer [40631,40649]
===
match
---
name: value [30025,30030]
name: value [30025,30030]
===
match
---
if_stmt [41742,42236]
if_stmt [41742,42236]
===
match
---
try_stmt [35242,35446]
try_stmt [35242,35446]
===
match
---
name: self [65987,65991]
name: self [66038,66042]
===
match
---
name: template_undefined [10312,10330]
name: template_undefined [10312,10330]
===
match
---
atom_expr [88851,88860]
atom_expr [88902,88911]
===
match
---
name: start_date [27340,27350]
name: start_date [27340,27350]
===
match
---
suite [17528,18630]
suite [17528,18630]
===
match
---
name: active_runs_of_dag [91630,91648]
name: active_runs_of_dag [91681,91699]
===
match
---
trailer [64038,64045]
trailer [64089,64096]
===
match
---
name: filter [41612,41618]
name: filter [41612,41618]
===
match
---
simple_stmt [39136,39154]
simple_stmt [39136,39154]
===
match
---
operator: @ [86367,86368]
operator: @ [86418,86419]
===
match
---
decorated [88760,89990]
decorated [88811,90041]
===
match
---
expr_stmt [80821,80867]
expr_stmt [80872,80918]
===
match
---
name: datetime [19233,19241]
name: datetime [19233,19241]
===
match
---
operator: { [93916,93917]
operator: { [93967,93968]
===
match
---
trailer [25153,25164]
trailer [25153,25164]
===
match
---
atom_expr [22214,22241]
atom_expr [22214,22241]
===
match
---
simple_stmt [73828,73861]
simple_stmt [73879,73912]
===
match
---
arglist [60779,60798]
arglist [60830,60849]
===
match
---
simple_stmt [2847,2885]
simple_stmt [2847,2885]
===
match
---
trailer [12934,12943]
trailer [12934,12943]
===
match
---
trailer [21438,21461]
trailer [21438,21461]
===
match
---
trailer [64046,64052]
trailer [64097,64103]
===
match
---
arglist [28550,28637]
arglist [28550,28637]
===
match
---
simple_stmt [60724,60876]
simple_stmt [60775,60927]
===
match
---
strings [14518,14636]
strings [14518,14636]
===
match
---
tfpdef [29442,29452]
tfpdef [29442,29452]
===
match
---
trailer [92638,92647]
trailer [92689,92698]
===
match
---
if_stmt [60290,60382]
if_stmt [60341,60433]
===
match
---
name: wrapper [94280,94287]
name: wrapper [94331,94338]
===
match
---
trailer [45744,45759]
trailer [45744,45759]
===
match
---
simple_stmt [69014,69063]
simple_stmt [69065,69114]
===
match
---
name: params [58148,58154]
name: params [58199,58205]
===
match
---
trailer [74659,74666]
trailer [74710,74717]
===
match
---
name: _log [58222,58226]
name: _log [58273,58277]
===
match
---
simple_stmt [64247,64272]
simple_stmt [64298,64323]
===
match
---
name: property [64794,64802]
name: property [64845,64853]
===
match
---
simple_stmt [30751,30786]
simple_stmt [30751,30786]
===
match
---
simple_stmt [90944,91030]
simple_stmt [90995,91081]
===
match
---
name: run_type [71885,71893]
name: run_type [71936,71944]
===
match
---
name: only_failed [49612,49623]
name: only_failed [49663,49674]
===
match
---
atom_expr [93622,93631]
atom_expr [93673,93682]
===
match
---
name: str [46229,46232]
name: str [46229,46232]
===
match
---
name: dag [56173,56176]
name: dag [56224,56227]
===
match
---
name: owners [76031,76037]
name: owners [76082,76088]
===
match
---
name: airflow [69731,69738]
name: airflow [69782,69789]
===
match
---
trailer [65880,65889]
trailer [65931,65940]
===
match
---
trailer [24569,24574]
trailer [24569,24574]
===
match
---
trailer [62872,62874]
trailer [62923,62925]
===
match
---
atom_expr [39439,39450]
atom_expr [39439,39450]
===
match
---
simple_stmt [27916,27948]
simple_stmt [27916,27948]
===
match
---
trailer [32800,32820]
trailer [32800,32820]
===
match
---
name: execution_date [50243,50257]
name: execution_date [50294,50308]
===
match
---
operator: = [85262,85263]
operator: = [85313,85314]
===
match
---
tfpdef [10743,10780]
tfpdef [10743,10780]
===
match
---
trailer [74019,74028]
trailer [74070,74079]
===
match
---
trailer [59789,59799]
trailer [59840,59850]
===
match
---
suite [63155,63453]
suite [63206,63504]
===
match
---
name: downstream_task_id [82403,82421]
name: downstream_task_id [82454,82472]
===
match
---
name: task [42745,42749]
name: task [42745,42749]
===
match
---
operator: = [35899,35900]
operator: = [35899,35900]
===
match
---
param [46281,46294]
param [46281,46294]
===
match
---
name: state [41868,41873]
name: state [41868,41873]
===
match
---
trailer [46240,46248]
trailer [46240,46248]
===
match
---
simple_stmt [69861,69883]
simple_stmt [69912,69934]
===
match
---
trailer [57986,57995]
trailer [58037,58046]
===
match
---
return_stmt [35793,35812]
return_stmt [35793,35812]
===
match
---
trailer [31532,31563]
trailer [31532,31563]
===
match
---
operator: = [54990,54991]
operator: = [55041,55042]
===
match
---
trailer [42204,42235]
trailer [42204,42235]
===
match
---
atom_expr [83661,83675]
atom_expr [83712,83726]
===
match
---
atom_expr [75947,75966]
atom_expr [75998,76017]
===
match
---
atom_expr [39515,39539]
atom_expr [39515,39539]
===
match
---
name: AirflowException [51971,51987]
name: AirflowException [52022,52038]
===
match
---
operator: = [57762,57763]
operator: = [57813,57814]
===
match
---
operator: = [66957,66958]
operator: = [67008,67009]
===
match
---
name: DagParam [1887,1895]
name: DagParam [1887,1895]
===
match
---
trailer [94317,94319]
trailer [94368,94370]
===
match
---
string: 'dag_orientation' [10917,10934]
string: 'dag_orientation' [10917,10934]
===
match
---
simple_stmt [12153,12185]
simple_stmt [12153,12185]
===
match
---
trailer [41499,41514]
trailer [41499,41514]
===
match
---
name: Session [87098,87105]
name: Session [87149,87156]
===
match
---
operator: , [1370,1371]
operator: , [1370,1371]
===
match
---
operator: , [70098,70099]
operator: , [70149,70150]
===
match
---
name: task_id [65957,65964]
name: task_id [66008,66015]
===
match
---
comparison [33668,33706]
comparison [33668,33706]
===
match
---
or_test [24643,24709]
or_test [24643,24709]
===
match
---
simple_stmt [43637,43664]
simple_stmt [43637,43664]
===
match
---
argument [54340,54381]
argument [54391,54432]
===
match
---
operator: = [77274,77275]
operator: = [77325,77326]
===
match
---
name: get_last_dagrun [28433,28448]
name: get_last_dagrun [28433,28448]
===
match
---
suite [31625,31709]
suite [31625,31709]
===
match
---
name: dag_id [32022,32028]
name: dag_id [32022,32028]
===
match
---
operator: = [87106,87107]
operator: = [87157,87158]
===
match
---
trailer [11262,11268]
trailer [11262,11268]
===
match
---
name: state [32060,32065]
name: state [32060,32065]
===
match
---
name: self [33831,33835]
name: self [33831,33835]
===
match
---
name: self [66057,66061]
name: self [66108,66112]
===
match
---
name: dag_id [93396,93402]
name: dag_id [93447,93453]
===
match
---
atom_expr [73947,73960]
atom_expr [73998,74011]
===
match
---
name: SerializedDagModel [94442,94460]
name: SerializedDagModel [94493,94511]
===
match
---
operator: <= [50341,50343]
operator: <= [50392,50394]
===
match
---
name: start_date [13333,13343]
name: start_date [13333,13343]
===
match
---
trailer [95335,95356]
trailer [95386,95407]
===
match
---
string: "Task is missing the start_date parameter" [65165,65207]
string: "Task is missing the start_date parameter" [65216,65258]
===
match
---
name: default [84168,84175]
name: default [84219,84226]
===
match
---
trailer [64900,64916]
trailer [64951,64967]
===
match
---
import_from [1943,1983]
import_from [1943,1983]
===
match
---
name: end_date [37733,37741]
name: end_date [37733,37741]
===
match
---
return_stmt [39136,39153]
return_stmt [39136,39153]
===
match
---
parameters [90036,90059]
parameters [90087,90110]
===
match
---
operator: = [35664,35665]
operator: = [35664,35665]
===
match
---
suite [52779,54447]
suite [52830,54498]
===
match
---
name: session [48604,48611]
name: session [48604,48611]
===
match
---
trailer [61425,61440]
trailer [61476,61491]
===
match
---
name: self [18971,18975]
name: self [18971,18975]
===
match
---
atom_expr [45489,45507]
atom_expr [45489,45507]
===
match
---
trailer [24937,24948]
trailer [24937,24948]
===
match
---
name: value [30072,30077]
name: value [30072,30077]
===
match
---
simple_stmt [63632,63663]
simple_stmt [63683,63714]
===
match
---
atom_expr [10817,10866]
atom_expr [10817,10866]
===
match
---
name: default_args [13252,13264]
name: default_args [13252,13264]
===
match
---
expr_stmt [95046,95088]
expr_stmt [95097,95139]
===
match
---
operator: { [88659,88660]
operator: { [88710,88711]
===
match
---
name: pendulum [91123,91131]
name: pendulum [91174,91182]
===
match
---
operator: == [38046,38048]
operator: == [38046,38048]
===
match
---
atom_expr [25152,25164]
atom_expr [25152,25164]
===
match
---
operator: , [3148,3149]
operator: , [3148,3149]
===
match
---
funcdef [64438,64788]
funcdef [64489,64839]
===
match
---
arglist [74567,74604]
arglist [74618,74655]
===
match
---
trailer [76391,76403]
trailer [76442,76454]
===
match
---
simple_stmt [17038,17072]
simple_stmt [17038,17072]
===
match
---
trailer [13143,13155]
trailer [13143,13155]
===
match
---
name: Iterable [10280,10288]
name: Iterable [10280,10288]
===
match
---
name: p_dag [49485,49490]
name: p_dag [49536,49541]
===
match
---
return_stmt [42306,42316]
return_stmt [42306,42316]
===
match
---
name: pool [69418,69422]
name: pool [69469,69473]
===
match
---
suite [57625,58261]
suite [57676,58312]
===
match
---
arglist [83661,83693]
arglist [83712,83744]
===
match
---
operator: , [35890,35891]
operator: , [35890,35891]
===
match
---
operator: , [56007,56008]
operator: , [56058,56059]
===
match
---
name: dag [76628,76631]
name: dag [76679,76682]
===
match
---
expr_stmt [13675,13761]
expr_stmt [13675,13761]
===
match
---
name: Column [85522,85528]
name: Column [85573,85579]
===
match
---
trailer [21205,21211]
trailer [21205,21211]
===
match
---
operator: , [55324,55325]
operator: , [55375,55376]
===
match
---
operator: } [39816,39817]
operator: } [39816,39817]
===
match
---
name: dag_sig [92674,92681]
name: dag_sig [92725,92732]
===
match
---
name: dag [75969,75972]
name: dag [76020,76023]
===
match
---
operator: , [58282,58283]
operator: , [58333,58334]
===
match
---
atom_expr [89759,89778]
atom_expr [89810,89829]
===
match
---
trailer [38061,38068]
trailer [38061,38068]
===
match
---
name: dag_id [36968,36974]
name: dag_id [36968,36974]
===
match
---
name: airflow [64836,64843]
name: airflow [64887,64894]
===
match
---
trailer [63991,63997]
trailer [64042,64048]
===
match
---
simple_stmt [14217,14256]
simple_stmt [14217,14256]
===
match
---
name: task_ids_or_regex [60200,60217]
name: task_ids_or_regex [60251,60268]
===
match
---
operator: , [40785,40786]
operator: , [40785,40786]
===
match
---
name: PatternType [2847,2858]
name: PatternType [2847,2858]
===
match
---
trailer [83105,83127]
trailer [83156,83178]
===
match
---
name: jinja2 [10337,10343]
name: jinja2 [10337,10343]
===
match
---
trailer [11375,11381]
trailer [11375,11381]
===
match
---
name: runs [35726,35730]
name: runs [35726,35730]
===
match
---
name: hash [16938,16942]
name: hash [16938,16942]
===
match
---
simple_stmt [34902,34965]
simple_stmt [34902,34965]
===
match
---
trailer [86540,86546]
trailer [86591,86597]
===
match
---
trailer [74327,74350]
trailer [74378,74401]
===
match
---
trailer [88638,88645]
trailer [88689,88696]
===
match
---
decorator [31714,31731]
decorator [31714,31731]
===
match
---
name: warnings [901,909]
name: warnings [901,909]
===
match
---
trailer [53530,53545]
trailer [53581,53596]
===
match
---
simple_stmt [54640,54651]
simple_stmt [54691,54702]
===
match
---
trailer [12588,12602]
trailer [12588,12602]
===
match
---
trailer [62778,62780]
trailer [62829,62831]
===
match
---
arglist [21252,21271]
arglist [21252,21271]
===
match
---
trailer [84326,84339]
trailer [84377,84390]
===
match
---
name: TaskInstance [41034,41046]
name: TaskInstance [41034,41046]
===
match
---
funcdef [88798,89990]
funcdef [88849,90041]
===
match
---
name: tasks [62582,62587]
name: tasks [62633,62638]
===
match
---
name: default_args [13502,13514]
name: default_args [13502,13514]
===
match
---
expr_stmt [16634,16664]
expr_stmt [16634,16664]
===
match
---
param [64816,64820]
param [64867,64871]
===
match
---
import_from [2409,2458]
import_from [2409,2458]
===
match
---
name: session [31961,31968]
name: session [31961,31968]
===
match
---
simple_stmt [94253,94268]
simple_stmt [94304,94319]
===
match
---
simple_stmt [15149,15196]
simple_stmt [15149,15196]
===
match
---
param [58799,58829]
param [58850,58880]
===
match
---
atom_expr [85002,85014]
atom_expr [85053,85065]
===
match
---
operator: == [64169,64171]
operator: == [64220,64222]
===
match
---
name: c [16896,16897]
name: c [16896,16897]
===
match
---
string: "TaskGroup" [30829,30840]
string: "TaskGroup" [30829,30840]
===
match
---
atom_expr [81452,81483]
atom_expr [81503,81534]
===
match
---
operator: , [55524,55525]
operator: , [55575,55576]
===
match
---
argument [56274,56297]
argument [56325,56348]
===
match
---
name: orientation [14729,14740]
name: orientation [14729,14740]
===
match
---
operator: <= [90794,90796]
operator: <= [90845,90847]
===
match
---
name: catchup [14960,14967]
name: catchup [14960,14967]
===
match
---
param [11091,11152]
param [11091,11152]
===
match
---
tfpdef [72816,72839]
tfpdef [72867,72890]
===
match
---
atom_expr [16813,16841]
atom_expr [16813,16841]
===
match
---
name: query [45808,45813]
name: query [45808,45813]
===
match
---
comparison [36991,37030]
comparison [36991,37030]
===
match
---
trailer [45730,45737]
trailer [45730,45737]
===
match
---
name: graph_sorted [44923,44935]
name: graph_sorted [44923,44935]
===
match
---
decorator [87025,87042]
decorator [87076,87093]
===
match
---
trailer [88745,88752]
trailer [88796,88803]
===
match
---
name: last_start [24819,24829]
name: last_start [24819,24829]
===
match
---
operator: = [40780,40781]
operator: = [40780,40781]
===
match
---
atom_expr [19961,20001]
atom_expr [19961,20001]
===
match
---
operator: != [64226,64228]
operator: != [64277,64279]
===
match
---
testlist_comp [60052,60117]
testlist_comp [60103,60168]
===
match
---
name: query [73899,73904]
name: query [73950,73955]
===
match
---
operator: = [21543,21544]
operator: = [21543,21544]
===
match
---
operator: = [67054,67055]
operator: = [67105,67106]
===
match
---
name: timezone [12491,12499]
name: timezone [12491,12499]
===
match
---
name: dag_id [75162,75168]
name: dag_id [75213,75219]
===
match
---
suite [51149,54504]
suite [51200,54555]
===
match
---
name: default_view [14622,14634]
name: default_view [14622,14634]
===
match
---
parameters [31168,31174]
parameters [31168,31174]
===
match
---
trailer [64155,64186]
trailer [64206,64237]
===
match
---
param [95196,95204]
param [95247,95255]
===
match
---
name: end_date [37154,37162]
name: end_date [37154,37162]
===
match
---
name: execution_date [72248,72262]
name: execution_date [72299,72313]
===
match
---
funcdef [39266,40386]
funcdef [39266,40386]
===
match
---
comparison [31678,31708]
comparison [31678,31708]
===
match
---
name: query [45617,45622]
name: query [45617,45622]
===
match
---
simple_stmt [28763,28953]
simple_stmt [28763,28953]
===
match
---
name: bool [63125,63129]
name: bool [63176,63180]
===
match
---
name: ignore_first_depends_on_past [66973,67001]
name: ignore_first_depends_on_past [67024,67052]
===
match
---
operator: , [72344,72345]
operator: , [72395,72396]
===
match
---
operator: @ [72753,72754]
operator: @ [72804,72805]
===
match
---
operator: , [9684,9685]
operator: , [9684,9685]
===
match
---
not_test [68914,68926]
not_test [68965,68977]
===
match
---
simple_stmt [32707,32776]
simple_stmt [32707,32776]
===
match
---
atom_expr [83080,83147]
atom_expr [83131,83198]
===
match
---
name: baseoperator [1734,1746]
name: baseoperator [1734,1746]
===
match
---
atom_expr [74817,75188]
atom_expr [74868,75239]
===
match
---
operator: = [53982,53983]
operator: = [54033,54034]
===
match
---
trailer [76589,76606]
trailer [76640,76657]
===
match
---
operator: @ [29895,29896]
operator: @ [29895,29896]
===
match
---
operator: = [94350,94351]
operator: = [94401,94402]
===
match
---
trailer [66445,66456]
trailer [66496,66507]
===
match
---
name: TI [52581,52583]
name: TI [52632,52634]
===
match
---
name: upstream_task_id [82734,82750]
name: upstream_task_id [82785,82801]
===
match
---
trailer [93105,93122]
trailer [93156,93173]
===
match
---
suite [35731,35784]
suite [35731,35784]
===
match
---
name: start_date [24938,24948]
name: start_date [24938,24948]
===
match
---
exprlist [57825,57829]
exprlist [57876,57880]
===
match
---
name: dry_run [56615,56622]
name: dry_run [56666,56673]
===
match
---
name: get_task_instances [34990,35008]
name: get_task_instances [34990,35008]
===
match
---
name: cli_parser [69750,69760]
name: cli_parser [69801,69811]
===
match
---
atom [42497,42552]
atom [42497,42552]
===
match
---
suite [81403,82312]
suite [81454,82363]
===
match
---
operator: , [10139,10140]
operator: , [10139,10140]
===
match
---
expr_stmt [24497,24520]
expr_stmt [24497,24520]
===
match
---
atom_expr [18708,18721]
atom_expr [18708,18721]
===
match
---
string: 'BT' [3098,3102]
string: 'BT' [3098,3102]
===
match
---
not_test [42767,42791]
not_test [42767,42791]
===
match
---
name: date_last_automated_dagrun [22673,22699]
name: date_last_automated_dagrun [22673,22699]
===
match
---
name: relationship [1453,1465]
name: relationship [1453,1465]
===
match
---
atom_expr [57732,57746]
atom_expr [57783,57797]
===
match
---
name: airflow [68709,68716]
name: airflow [68760,68767]
===
match
---
if_stmt [75799,76226]
if_stmt [75850,76277]
===
match
---
trailer [95603,95605]
trailer [95654,95656]
===
match
---
argument [84168,84181]
argument [84219,84232]
===
match
---
operator: = [63949,63950]
operator: = [64000,64001]
===
match
---
trailer [30058,30069]
trailer [30058,30069]
===
match
---
trailer [76755,76762]
trailer [76806,76813]
===
match
---
name: str [11178,11181]
name: str [11178,11181]
===
match
---
atom_expr [13644,13661]
atom_expr [13644,13661]
===
match
---
atom_expr [81222,81234]
atom_expr [81273,81285]
===
match
---
atom_expr [26509,26519]
atom_expr [26509,26519]
===
match
---
atom_expr [61426,61439]
atom_expr [61477,61490]
===
match
---
simple_stmt [56117,56130]
simple_stmt [56168,56181]
===
match
---
operator: = [76300,76301]
operator: = [76351,76352]
===
match
---
trailer [79835,79842]
trailer [79886,79893]
===
match
---
name: log [89177,89180]
name: log [89228,89231]
===
match
---
name: self [22635,22639]
name: self [22635,22639]
===
match
---
funcdef [63925,64433]
funcdef [63976,64484]
===
match
---
comp_op [76607,76613]
comp_op [76658,76664]
===
match
---
atom_expr [9899,9913]
atom_expr [9899,9913]
===
match
---
trailer [39896,39927]
trailer [39896,39927]
===
match
---
name: unique [85728,85734]
name: unique [85779,85785]
===
match
---
name: following [28333,28342]
name: following [28333,28342]
===
match
---
funcdef [87634,87985]
funcdef [87685,88036]
===
match
---
atom_expr [35108,35118]
atom_expr [35108,35118]
===
match
---
not_test [25064,25094]
not_test [25064,25094]
===
match
---
name: Column [1345,1351]
name: Column [1345,1351]
===
match
---
name: dag_id [72186,72192]
name: dag_id [72237,72243]
===
match
---
name: dttm [22022,22026]
name: dttm [22022,22026]
===
match
---
arglist [74074,74109]
arglist [74125,74160]
===
match
---
decorated [78352,78952]
decorated [78403,79003]
===
match
---
name: session [78908,78915]
name: session [78959,78966]
===
match
---
atom_expr [10416,10430]
atom_expr [10416,10430]
===
match
---
atom_expr [92062,92136]
atom_expr [92113,92187]
===
match
---
name: TaskInstance [48577,48589]
name: TaskInstance [48577,48589]
===
match
---
trailer [45199,45254]
trailer [45199,45254]
===
match
---
or_test [38809,39015]
or_test [38809,39015]
===
match
---
expr_stmt [84305,84339]
expr_stmt [84356,84390]
===
match
---
name: filtered_child [61728,61742]
name: filtered_child [61779,61793]
===
match
---
simple_stmt [3057,3104]
simple_stmt [3057,3104]
===
match
---
name: dates [2195,2200]
name: dates [2195,2200]
===
match
---
operator: , [2961,2962]
operator: , [2961,2962]
===
match
---
atom_expr [50411,50419]
atom_expr [50462,50470]
===
match
---
operator: == [64031,64033]
operator: == [64082,64084]
===
match
---
trailer [80510,80518]
trailer [80561,80569]
===
match
---
trailer [80837,80867]
trailer [80888,80918]
===
match
---
trailer [44610,44612]
trailer [44610,44612]
===
match
---
trailer [32752,32759]
trailer [32752,32759]
===
match
---
operator: , [90979,90980]
operator: , [91030,91031]
===
match
---
name: pendulum [22150,22158]
name: pendulum [22150,22158]
===
match
---
not_test [81375,81402]
not_test [81426,81453]
===
match
---
funcdef [29420,29489]
funcdef [29420,29489]
===
match
---
trailer [33639,33657]
trailer [33639,33657]
===
match
---
name: used_group_ids [66074,66088]
name: used_group_ids [66125,66139]
===
match
---
trailer [62541,62551]
trailer [62592,62602]
===
match
---
name: rollback [89961,89969]
name: rollback [90012,90020]
===
match
---
number: 0 [64568,64569]
number: 0 [64619,64620]
===
match
---
name: scalar [32113,32119]
name: scalar [32113,32119]
===
match
---
atom_expr [19726,19776]
atom_expr [19726,19776]
===
match
---
name: session [90981,90988]
name: session [91032,91039]
===
match
---
name: DagRun [45829,45835]
name: DagRun [45829,45835]
===
match
---
name: self [13927,13931]
name: self [13927,13931]
===
match
---
simple_stmt [28024,28041]
simple_stmt [28024,28041]
===
match
---
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_is_paused` method.""" [32869,32958]
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_is_paused` method.""" [32869,32958]
===
match
---
atom_expr [82715,82783]
atom_expr [82766,82834]
===
match
---
string: 'on_failure_callback' [82009,82030]
string: 'on_failure_callback' [82060,82081]
===
match
---
operator: = [25435,25436]
operator: = [25435,25436]
===
match
---
name: merge [78916,78921]
name: merge [78967,78972]
===
match
---
trailer [62913,62919]
trailer [62964,62970]
===
match
---
trailer [86572,86579]
trailer [86623,86630]
===
match
---
simple_stmt [45264,45291]
simple_stmt [45264,45291]
===
match
---
name: active_runs_of_dag [91143,91161]
name: active_runs_of_dag [91194,91212]
===
match
---
operator: , [1110,1111]
operator: , [1110,1111]
===
match
---
simple_stmt [17890,18091]
simple_stmt [17890,18091]
===
match
---
operator: , [9833,9834]
operator: , [9833,9834]
===
match
---
atom_expr [16026,16035]
atom_expr [16026,16035]
===
match
---
name: name [21802,21806]
name: name [21802,21806]
===
match
---
name: copied [61491,61497]
name: copied [61542,61548]
===
match
---
trailer [87939,87943]
trailer [87990,87994]
===
match
---
name: self [12779,12783]
name: self [12779,12783]
===
match
---
name: timezone [40934,40942]
name: timezone [40934,40942]
===
match
---
operator: = [39621,39622]
operator: = [39621,39622]
===
match
---
trailer [24511,24518]
trailer [24511,24518]
===
match
---
atom_expr [58180,58201]
atom_expr [58231,58252]
===
match
---
param [82380,82402]
param [82431,82453]
===
match
---
and_test [19409,19474]
and_test [19409,19474]
===
match
---
trailer [25334,25338]
trailer [25334,25338]
===
match
---
simple_stmt [63803,63829]
simple_stmt [63854,63880]
===
match
---
atom_expr [38450,38482]
atom_expr [38450,38482]
===
match
---
name: query [64132,64137]
name: query [64183,64188]
===
match
---
trailer [79420,79430]
trailer [79471,79481]
===
match
---
name: cron [19329,19333]
name: cron [19329,19333]
===
match
---
name: end_date [53583,53591]
name: end_date [53634,53642]
===
match
---
simple_stmt [84465,84500]
simple_stmt [84516,84551]
===
match
---
atom_expr [60107,60116]
atom_expr [60158,60167]
===
match
---
trailer [21893,21908]
trailer [21893,21908]
===
match
---
suite [60524,60573]
suite [60575,60624]
===
match
---
arglist [88659,88719]
arglist [88710,88770]
===
match
---
for_stmt [48781,48950]
for_stmt [48781,48950]
===
match
---
name: tis [41608,41611]
name: tis [41608,41611]
===
match
---
funcdef [19527,20796]
funcdef [19527,20796]
===
match
---
simple_stmt [51018,51047]
simple_stmt [51069,51098]
===
match
---
simple_stmt [88885,89169]
simple_stmt [88936,89220]
===
match
---
operator: = [57412,57413]
operator: = [57463,57464]
===
match
---
comp_op [20698,20704]
comp_op [20698,20704]
===
match
---
name: log [92062,92065]
name: log [92113,92116]
===
match
---
operator: = [83322,83323]
operator: = [83373,83374]
===
match
---
name: ask_yesno [57015,57024]
name: ask_yesno [57066,57075]
===
match
---
atom_expr [54471,54503]
atom_expr [54522,54554]
===
match
---
operator: = [9664,9665]
operator: = [9664,9665]
===
match
---
trailer [11050,11074]
trailer [11050,11074]
===
match
---
operator: = [66247,66248]
operator: = [66298,66299]
===
match
---
name: tis [49452,49455]
name: tis [49503,49506]
===
match
---
operator: = [55137,55138]
operator: = [55188,55189]
===
match
---
comparison [18286,18326]
comparison [18286,18326]
===
match
---
operator: == [75075,75077]
operator: == [75126,75128]
===
match
---
operator: -> [95734,95736]
operator: -> [95785,95787]
===
match
---
import_name [832,841]
import_name [832,841]
===
match
---
atom_expr [3130,3155]
atom_expr [3130,3155]
===
match
---
arglist [61278,61297]
arglist [61329,61348]
===
match
---
expr_stmt [60329,60381]
expr_stmt [60380,60432]
===
match
---
name: including_subdags [88492,88509]
name: including_subdags [88543,88560]
===
match
---
trailer [25665,25680]
trailer [25665,25680]
===
match
---
trailer [18353,18590]
trailer [18353,18590]
===
match
---
trailer [62334,62361]
trailer [62385,62412]
===
match
---
suite [54593,54651]
suite [54644,54702]
===
match
---
atom_expr [11997,12016]
atom_expr [11997,12016]
===
match
---
name: self [12153,12157]
name: self [12153,12157]
===
match
---
arglist [34916,34963]
arglist [34916,34963]
===
match
---
atom_expr [71880,71894]
atom_expr [71931,71945]
===
match
---
trailer [62891,62902]
trailer [62942,62953]
===
match
---
operator: , [37637,37638]
operator: , [37637,37638]
===
match
---
name: airflow [2310,2317]
name: airflow [2310,2317]
===
match
---
trailer [10005,10010]
trailer [10005,10010]
===
match
---
atom_expr [79407,79534]
atom_expr [79458,79585]
===
match
---
comparison [78200,78225]
comparison [78251,78276]
===
match
---
expr_stmt [64391,64413]
expr_stmt [64442,64464]
===
match
---
return_stmt [72737,72747]
return_stmt [72788,72798]
===
match
---
operator: @ [28408,28409]
operator: @ [28408,28409]
===
match
---
trailer [38480,38482]
trailer [38480,38482]
===
match
---
trailer [64186,64192]
trailer [64237,64243]
===
match
---
operator: { [60740,60741]
operator: { [60791,60792]
===
match
---
trailer [72185,72192]
trailer [72236,72243]
===
match
---
name: child [61426,61431]
name: child [61477,61482]
===
match
---
name: dag_model [89808,89817]
name: dag_model [89859,89868]
===
match
---
trailer [75840,75850]
trailer [75891,75901]
===
match
---
name: normalized_schedule_interval [33208,33236]
name: normalized_schedule_interval [33208,33236]
===
match
---
if_stmt [25061,25489]
if_stmt [25061,25489]
===
match
---
name: BaseOperator [63142,63154]
name: BaseOperator [63193,63205]
===
match
---
operator: } [15466,15467]
operator: } [15466,15467]
===
match
---
operator: = [86924,86925]
operator: = [86975,86976]
===
match
---
atom_expr [85638,85657]
atom_expr [85689,85708]
===
match
---
suite [21978,22064]
suite [21978,22064]
===
match
---
name: include_downstream [58734,58752]
name: include_downstream [58785,58803]
===
match
---
atom_expr [75833,75850]
atom_expr [75884,75901]
===
match
---
name: role [18213,18217]
name: role [18213,18217]
===
match
---
name: query [36229,36234]
name: query [36229,36234]
===
match
---
decorated [79850,81235]
decorated [79901,81286]
===
match
---
name: airflow [2146,2153]
name: airflow [2146,2153]
===
match
---
operator: = [61192,61193]
operator: = [61243,61244]
===
match
---
name: _log [58234,58238]
name: _log [58285,58289]
===
match
---
param [37164,37176]
param [37164,37176]
===
match
---
name: state [41641,41646]
name: state [41641,41646]
===
match
---
suite [16191,16466]
suite [16191,16466]
===
match
---
decorated [29030,29116]
decorated [29030,29116]
===
match
---
if_stmt [12843,12944]
if_stmt [12843,12944]
===
match
---
trailer [15069,15077]
trailer [15069,15077]
===
match
---
trailer [13183,13196]
trailer [13183,13196]
===
match
---
atom [38741,38743]
atom [38741,38743]
===
match
---
operator: , [92704,92705]
operator: , [92755,92756]
===
match
---
atom_expr [80838,80866]
atom_expr [80889,80917]
===
match
---
name: self [25330,25334]
name: self [25330,25334]
===
match
---
simple_stmt [3437,3491]
simple_stmt [3437,3491]
===
match
---
return_stmt [29542,29569]
return_stmt [29542,29569]
===
match
---
return_stmt [86526,86598]
return_stmt [86577,86649]
===
match
---
funcdef [92475,94268]
funcdef [92526,94319]
===
match
---
simple_stmt [57529,57570]
simple_stmt [57580,57621]
===
match
---
decorator [63904,63921]
decorator [63955,63972]
===
match
---
decorator [3716,3742]
decorator [3716,3742]
===
match
---
atom_expr [78786,78860]
atom_expr [78837,78911]
===
match
---
suite [86685,86757]
suite [86736,86808]
===
match
---
name: self [22713,22717]
name: self [22713,22717]
===
match
---
fstring_expr [16146,16159]
fstring_expr [16146,16159]
===
match
---
trailer [30494,30508]
trailer [30494,30508]
===
match
---
if_stmt [50481,50554]
if_stmt [50532,50605]
===
match
---
name: dag_ids [45574,45581]
name: dag_ids [45574,45581]
===
match
---
trailer [22717,22735]
trailer [22717,22735]
===
match
---
name: execution_date [50326,50340]
name: execution_date [50377,50391]
===
match
---
comparison [33831,33864]
comparison [33831,33864]
===
match
---
operator: = [56695,56696]
operator: = [56746,56747]
===
match
---
trailer [20278,20287]
trailer [20278,20287]
===
match
---
name: access_control [11238,11252]
name: access_control [11238,11252]
===
match
---
name: self [69102,69106]
name: self [69153,69157]
===
match
---
atom_expr [28191,28220]
atom_expr [28191,28220]
===
match
---
operator: } [66153,66154]
operator: } [66204,66205]
===
match
---
name: concurrency [29424,29435]
name: concurrency [29424,29435]
===
match
---
name: dag_id [28976,28982]
name: dag_id [28976,28982]
===
match
---
name: next_run_date [26633,26646]
name: next_run_date [26633,26646]
===
match
---
simple_stmt [52403,52425]
simple_stmt [52454,52476]
===
match
---
name: dag [62538,62541]
name: dag [62589,62592]
===
match
---
atom_expr [30732,30741]
atom_expr [30732,30741]
===
match
---
trailer [53169,53384]
trailer [53220,53435]
===
match
---
atom_expr [14945,14957]
atom_expr [14945,14957]
===
match
---
operator: } [45251,45252]
operator: } [45251,45252]
===
match
---
simple_stmt [18877,19015]
simple_stmt [18877,19015]
===
match
---
simple_stmt [48630,48643]
simple_stmt [48630,48643]
===
match
---
atom_expr [52646,52663]
atom_expr [52697,52714]
===
match
---
trailer [16406,16422]
trailer [16406,16422]
===
match
---
simple_stmt [20322,20374]
simple_stmt [20322,20374]
===
match
---
suite [64947,66479]
suite [64998,66530]
===
match
---
trailer [10122,10132]
trailer [10122,10132]
===
match
---
name: _full_filepath [29187,29201]
name: _full_filepath [29187,29201]
===
match
---
name: session [86503,86510]
name: session [86554,86561]
===
match
---
argument [54287,54302]
argument [54338,54353]
===
match
---
arglist [50411,50470]
arglist [50462,50521]
===
match
---
fstring_expr [53093,53105]
fstring_expr [53144,53156]
===
match
---
trailer [19925,19934]
trailer [19925,19934]
===
match
---
expr_stmt [13179,13318]
expr_stmt [13179,13318]
===
match
---
atom_expr [14178,14208]
atom_expr [14178,14208]
===
match
---
operator: , [42823,42824]
operator: , [42823,42824]
===
match
---
operator: { [15465,15466]
operator: { [15465,15466]
===
match
---
operator: , [10602,10603]
operator: , [10602,10603]
===
match
---
name: kwargs [86003,86009]
name: kwargs [86054,86060]
===
match
---
name: donot_pickle [69269,69281]
name: donot_pickle [69320,69332]
===
match
---
suite [23068,23181]
suite [23068,23181]
===
match
---
atom_expr [63675,63697]
atom_expr [63726,63748]
===
match
---
name: functools [92730,92739]
name: functools [92781,92790]
===
match
---
operator: , [34953,34954]
operator: , [34953,34954]
===
match
---
arith_expr [51835,51854]
arith_expr [51886,51905]
===
match
---
param [86823,86857]
param [86874,86908]
===
match
---
decorated [77763,78082]
decorated [77814,78133]
===
match
---
atom_expr [75315,75675]
atom_expr [75366,75726]
===
match
---
if_stmt [54851,54887]
if_stmt [54902,54938]
===
match
---
trailer [65956,65964]
trailer [66007,66015]
===
match
---
trailer [27999,28014]
trailer [27999,28014]
===
match
---
name: Optional [70164,70172]
name: Optional [70215,70223]
===
match
---
name: task [64811,64815]
name: task [64862,64866]
===
match
---
name: AirflowException [45183,45199]
name: AirflowException [45183,45199]
===
match
---
name: include_externally_triggered [28876,28904]
name: include_externally_triggered [28876,28904]
===
match
---
atom_expr [48892,48904]
atom_expr [48892,48904]
===
match
---
operator: = [38739,38740]
operator: = [38739,38740]
===
match
---
name: orm [1482,1485]
name: orm [1482,1485]
===
match
---
name: start_date [25864,25874]
name: start_date [25864,25874]
===
match
---
expr_stmt [48962,48996]
expr_stmt [48962,48996]
===
match
---
name: also_include [60329,60341]
name: also_include [60380,60392]
===
match
---
name: airflow [2670,2677]
name: airflow [2670,2677]
===
match
---
expr_stmt [63591,63619]
expr_stmt [63642,63670]
===
match
---
name: f [92746,92747]
name: f [92797,92798]
===
match
---
suite [62149,62560]
suite [62200,62611]
===
match
---
atom_expr [82680,82694]
atom_expr [82731,82745]
===
match
---
operator: @ [55786,55787]
operator: @ [55837,55838]
===
match
---
simple_stmt [83080,83155]
simple_stmt [83131,83206]
===
match
---
name: existing_dag_ids [74126,74142]
name: existing_dag_ids [74177,74193]
===
match
---
param [79939,79951]
param [79990,80002]
===
match
---
name: orientation [14715,14726]
name: orientation [14715,14726]
===
match
---
name: settings [12926,12934]
name: settings [12926,12934]
===
match
---
atom_expr [50516,50553]
atom_expr [50567,50604]
===
match
---
trailer [83958,83998]
trailer [84009,84049]
===
match
---
arglist [85277,85338]
arglist [85328,85389]
===
match
---
trailer [52306,52314]
trailer [52357,52365]
===
match
---
name: max [65531,65534]
name: max [65582,65585]
===
match
---
name: lower [10859,10864]
name: lower [10859,10864]
===
match
---
tfpdef [10876,10892]
tfpdef [10876,10892]
===
match
---
name: fileloc [89481,89488]
name: fileloc [89532,89539]
===
match
---
atom_expr [18340,18590]
atom_expr [18340,18590]
===
match
---
expr_stmt [83645,83694]
expr_stmt [83696,83745]
===
match
---
atom_expr [72181,72192]
atom_expr [72232,72243]
===
match
---
name: description [12173,12184]
name: description [12173,12184]
===
match
---
name: self [21301,21305]
name: self [21301,21305]
===
match
---
operator: , [46172,46173]
operator: , [46172,46173]
===
match
---
trailer [3469,3490]
trailer [3469,3490]
===
match
---
name: active_dates [35800,35812]
name: active_dates [35800,35812]
===
match
---
name: bool [70135,70139]
name: bool [70186,70190]
===
match
---
name: Environment [39950,39961]
name: Environment [39950,39961]
===
match
---
operator: , [86097,86098]
operator: , [86148,86149]
===
match
---
name: t [76623,76624]
name: t [76674,76675]
===
match
---
name: sub_dag [53162,53169]
name: sub_dag [53213,53220]
===
match
---
name: datetime [10123,10131]
name: datetime [10123,10131]
===
match
---
operator: = [46372,46373]
operator: = [46372,46373]
===
match
---
name: tis [49092,49095]
name: tis [49092,49095]
===
match
---
name: task_dict [61344,61353]
name: task_dict [61395,61404]
===
match
---
operator: = [51353,51354]
operator: = [51404,51405]
===
match
---
simple_stmt [11997,12058]
simple_stmt [11997,12058]
===
match
---
trailer [89260,89274]
trailer [89311,89325]
===
match
---
name: using_start_date [27821,27837]
name: using_start_date [27821,27837]
===
match
---
name: functools [807,816]
name: functools [807,816]
===
match
---
name: utils [11460,11465]
name: utils [11460,11465]
===
match
---
name: root_dag_id [75955,75966]
name: root_dag_id [76006,76017]
===
match
---
operator: = [12793,12794]
operator: = [12793,12794]
===
match
---
tfpdef [30099,30108]
tfpdef [30099,30108]
===
match
---
operator: { [71879,71880]
operator: { [71930,71931]
===
match
---
name: String [83661,83667]
name: String [83712,83718]
===
match
---
trailer [85695,85741]
trailer [85746,85792]
===
match
---
trailer [40343,40364]
trailer [40343,40364]
===
match
---
operator: , [67006,67007]
operator: , [67057,67058]
===
match
---
name: cls [90682,90685]
name: cls [90733,90736]
===
match
---
name: dag [76355,76358]
name: dag [76406,76409]
===
match
---
name: DeprecationWarning [32444,32462]
name: DeprecationWarning [32444,32462]
===
match
---
name: State [32069,32074]
name: State [32069,32074]
===
match
---
return_stmt [63367,63396]
return_stmt [63418,63447]
===
match
---
return_stmt [29864,29889]
return_stmt [29864,29889]
===
match
---
name: isoformat [79724,79733]
name: isoformat [79775,79784]
===
match
---
string: """         Figures out if the DAG schedule has a fixed time (e.g. 3 AM).          :return: True if the schedule has a fixed time, False if not.         """ [19062,19218]
string: """         Figures out if the DAG schedule has a fixed time (e.g. 3 AM).          :return: True if the schedule has a fixed time, False if not.         """ [19062,19218]
===
match
---
simple_stmt [73294,73680]
simple_stmt [73345,73731]
===
match
---
name: dag_bag [52940,52947]
name: dag_bag [52991,52998]
===
match
---
param [40416,40433]
param [40416,40433]
===
match
---
name: only_running [57257,57269]
name: only_running [57308,57320]
===
match
---
name: timezone [19961,19969]
name: timezone [19961,19969]
===
match
---
operator: @ [30457,30458]
operator: @ [30457,30458]
===
match
---
name: UtcDateTime [84251,84262]
name: UtcDateTime [84302,84313]
===
match
---
atom_expr [50539,50552]
atom_expr [50590,50603]
===
match
---
name: schedule_interval [13796,13813]
name: schedule_interval [13796,13813]
===
match
---
trailer [64750,64756]
trailer [64801,64807]
===
match
---
operator: = [63559,63560]
operator: = [63610,63611]
===
match
---
trailer [61783,61792]
trailer [61834,61843]
===
match
---
atom_expr [49485,50172]
atom_expr [49536,50223]
===
match
---
fstring_string: , but get  [14611,14621]
fstring_string: , but get  [14611,14621]
===
match
---
name: primary_key [83677,83688]
name: primary_key [83728,83739]
===
match
---
string: ", " [31523,31527]
string: ", " [31523,31527]
===
match
---
name: ID_LEN [83668,83674]
name: ID_LEN [83719,83725]
===
match
---
operator: , [58530,58531]
operator: , [58581,58582]
===
match
---
operator: , [46084,46085]
operator: , [46084,46085]
===
match
---
operator: = [11075,11076]
operator: = [11075,11076]
===
match
---
operator: , [55298,55299]
operator: , [55349,55350]
===
match
---
dictorsetmaker [74146,74184]
dictorsetmaker [74197,74235]
===
match
---
name: datetime [21567,21575]
name: datetime [21567,21575]
===
match
---
atom_expr [64252,64271]
atom_expr [64303,64322]
===
match
---
operator: = [27525,27526]
operator: = [27525,27526]
===
match
---
param [79924,79938]
param [79975,79989]
===
match
---
trailer [50406,50472]
trailer [50457,50523]
===
match
---
name: count [75367,75372]
name: count [75418,75423]
===
match
---
name: also_include [60228,60240]
name: also_include [60279,60291]
===
match
---
name: in_ [74016,74019]
name: in_ [74067,74070]
===
match
---
name: is_ [80857,80860]
name: is_ [80908,80911]
===
match
---
suite [92172,94288]
suite [92223,94339]
===
match
---
name: lower [78288,78293]
name: lower [78339,78344]
===
match
---
name: task [51506,51510]
name: task [51557,51561]
===
match
---
raise_stmt [45177,45254]
raise_stmt [45177,45254]
===
match
---
name: str [88856,88859]
name: str [88907,88910]
===
match
---
trailer [64023,64030]
trailer [64074,64081]
===
match
---
name: TaskGroup [11484,11493]
name: TaskGroup [11484,11493]
===
match
---
string: 'dag_concurrency' [86099,86116]
string: 'dag_concurrency' [86150,86167]
===
match
---
operator: , [45422,45423]
operator: , [45422,45423]
===
match
---
operator: * [48983,48984]
operator: * [48983,48984]
===
match
---
name: downstream_task_ids [62505,62524]
name: downstream_task_ids [62556,62575]
===
match
---
name: tasks [62896,62901]
name: tasks [62947,62952]
===
match
---
expr_stmt [51067,51090]
expr_stmt [51118,51141]
===
match
---
name: setattr [57963,57970]
name: setattr [58014,58021]
===
match
---
decorator [73182,73195]
decorator [73233,73246]
===
match
---
funcdef [29233,29309]
funcdef [29233,29309]
===
match
---
trailer [11318,11324]
trailer [11318,11324]
===
match
---
param [56050,56078]
param [56101,56129]
===
match
---
trailer [13603,13617]
trailer [13603,13617]
===
match
---
name: state [42063,42068]
name: state [42063,42068]
===
match
---
atom_expr [16938,16947]
atom_expr [16938,16947]
===
match
---
atom_expr [61898,61914]
atom_expr [61949,61965]
===
match
---
trailer [3458,3462]
trailer [3458,3462]
===
match
---
name: dag_id [16594,16600]
name: dag_id [16594,16600]
===
match
---
expr_stmt [30996,31059]
expr_stmt [30996,31059]
===
match
---
operator: = [85357,85358]
operator: = [85408,85409]
===
match
---
atom_expr [21553,21576]
atom_expr [21553,21576]
===
match
---
simple_stmt [83254,83280]
simple_stmt [83305,83331]
===
match
---
arglist [55117,55145]
arglist [55168,55196]
===
match
---
atom_expr [78935,78951]
atom_expr [78986,79002]
===
match
---
atom_expr [12502,12519]
atom_expr [12502,12519]
===
match
---
name: self [35327,35331]
name: self [35327,35331]
===
match
---
simple_stmt [71818,71898]
simple_stmt [71869,71949]
===
match
---
name: datetime [45498,45506]
name: datetime [45498,45506]
===
match
---
operator: , [79657,79658]
operator: , [79708,79709]
===
match
---
comparison [14662,14696]
comparison [14662,14696]
===
match
---
name: airflow [2181,2188]
name: airflow [2181,2188]
===
match
---
operator: = [60049,60050]
operator: = [60100,60101]
===
match
---
name: Column [84480,84486]
name: Column [84531,84537]
===
match
---
operator: * [58603,58604]
operator: * [58654,58655]
===
match
---
trailer [87976,87982]
trailer [88027,88033]
===
match
---
name: get_dagrun [36571,36581]
name: get_dagrun [36571,36581]
===
match
---
name: str [71550,71553]
name: str [71601,71604]
===
match
---
trailer [93959,93969]
trailer [94010,94020]
===
match
---
name: Column [84320,84326]
name: Column [84371,84377]
===
match
---
atom_expr [65484,65499]
atom_expr [65535,65550]
===
match
---
name: downstream_list [64670,64685]
name: downstream_list [64721,64736]
===
match
---
sync_comp_for [77086,77107]
sync_comp_for [77137,77158]
===
match
---
name: append [35757,35763]
name: append [35757,35763]
===
match
---
trailer [56182,56570]
trailer [56233,56621]
===
match
---
name: DAG [14061,14064]
name: DAG [14061,14064]
===
match
---
operator: @ [73182,73183]
operator: @ [73233,73234]
===
match
---
name: Optional [95068,95076]
name: Optional [95119,95127]
===
match
---
string: "Next run date based on tasks %s" [25345,25378]
string: "Next run date based on tasks %s" [25345,25378]
===
match
---
operator: , [3017,3018]
operator: , [3017,3018]
===
match
---
atom_expr [52667,52702]
atom_expr [52718,52753]
===
match
---
name: DagPickle [64252,64261]
name: DagPickle [64303,64312]
===
match
---
name: DagModel [88439,88447]
name: DagModel [88490,88498]
===
match
---
trailer [15872,15888]
trailer [15872,15888]
===
match
---
trailer [64410,64413]
trailer [64461,64464]
===
match
---
name: self [64452,64456]
name: self [64503,64507]
===
match
---
simple_stmt [48753,48769]
simple_stmt [48753,48769]
===
match
---
atom_expr [33758,33780]
atom_expr [33758,33780]
===
match
---
trailer [20338,20350]
trailer [20338,20350]
===
match
---
name: tis [42188,42191]
name: tis [42188,42191]
===
match
---
operator: , [37741,37742]
operator: , [37741,37742]
===
match
---
name: v [57996,57997]
name: v [58047,58048]
===
match
---
atom_expr [15733,15757]
atom_expr [15733,15757]
===
match
---
name: user_defined_macros [58022,58041]
name: user_defined_macros [58073,58092]
===
match
---
suite [80749,81124]
suite [80800,81175]
===
match
---
name: dag_tag_orm [77233,77244]
name: dag_tag_orm [77284,77295]
===
match
---
name: in_ [42224,42227]
name: in_ [42224,42227]
===
match
---
trailer [65164,65208]
trailer [65215,65259]
===
match
---
name: AirflowException [14773,14789]
name: AirflowException [14773,14789]
===
match
---
name: provide_session [45297,45312]
name: provide_session [45297,45312]
===
match
---
expr_stmt [31929,31946]
expr_stmt [31929,31946]
===
match
---
name: classmethod [95693,95704]
name: classmethod [95744,95755]
===
match
---
trailer [21007,21047]
trailer [21007,21047]
===
match
---
simple_stmt [63020,63070]
simple_stmt [63071,63121]
===
match
---
trailer [45821,45828]
trailer [45821,45828]
===
match
---
name: str [87083,87086]
name: str [87134,87137]
===
match
---
atom_expr [20730,20795]
atom_expr [20730,20795]
===
match
---
operator: = [3223,3224]
operator: = [3223,3224]
===
match
---
name: Optional [11310,11318]
name: Optional [11310,11318]
===
match
---
trailer [14789,14936]
trailer [14789,14936]
===
match
---
name: get [76748,76751]
name: get [76799,76802]
===
match
---
simple_stmt [94310,94358]
simple_stmt [94361,94409]
===
match
---
simple_stmt [16876,16905]
simple_stmt [16876,16905]
===
match
---
name: self [13586,13590]
name: self [13586,13590]
===
match
---
name: or_ [50407,50410]
name: or_ [50458,50461]
===
match
---
operator: = [20453,20454]
operator: = [20453,20454]
===
match
---
operator: { [14589,14590]
operator: { [14589,14590]
===
match
---
operator: } [86358,86359]
operator: } [86409,86410]
===
match
---
operator: == [50536,50538]
operator: == [50587,50589]
===
match
---
name: orm_dag [74309,74316]
name: orm_dag [74360,74367]
===
match
---
simple_stmt [45717,45775]
simple_stmt [45717,45775]
===
match
---
name: description [76410,76421]
name: description [76461,76472]
===
match
---
trailer [91789,92003]
trailer [91840,92054]
===
match
---
atom_expr [88660,88678]
atom_expr [88711,88729]
===
match
---
name: helpers [55173,55180]
name: helpers [55224,55231]
===
match
---
atom_expr [35263,35280]
atom_expr [35263,35280]
===
match
---
comparison [36465,36508]
comparison [36465,36508]
===
match
---
atom_expr [18052,18079]
atom_expr [18052,18079]
===
match
---
atom_expr [55429,55644]
atom_expr [55480,55695]
===
match
---
name: ORIENTATION_PRESETS [14677,14696]
name: ORIENTATION_PRESETS [14677,14696]
===
match
---
name: orm_dag [76199,76206]
name: orm_dag [76250,76257]
===
match
---
name: dag_id [86573,86579]
name: dag_id [86624,86630]
===
match
---
number: 2 [33136,33137]
number: 2 [33136,33137]
===
match
---
operator: } [14634,14635]
operator: } [14634,14635]
===
match
---
operator: , [81876,81877]
operator: , [81927,81928]
===
match
---
simple_stmt [64703,64728]
simple_stmt [64754,64779]
===
match
---
arglist [21301,21341]
arglist [21301,21341]
===
match
---
atom_expr [41375,41403]
atom_expr [41375,41403]
===
match
---
param [10500,10536]
param [10500,10536]
===
match
---
name: TI [48618,48620]
name: TI [48618,48620]
===
match
---
name: logging [824,831]
name: logging [824,831]
===
match
---
string: """         Triggers the appropriate callback depending on the value of success, namely the         on_failure_callback or on_success_callback. This method gets the context of a         single TaskInstance part of this DagRun and passes that to the callable along         with a 'reason', primarily to differentiate DagRun failures.          .. note: The logs end up in             ``$AIRFLOW_HOME/logs/scheduler/latest/PROJECT/DAG_FILE.py.log``          :param dagrun: DagRun object         :param success: Flag to specify if failure or success callback should be called         :param reason: Completion reason         :param session: Database session         """ [34118,34783]
string: """         Triggers the appropriate callback depending on the value of success, namely the         on_failure_callback or on_success_callback. This method gets the context of a         single TaskInstance part of this DagRun and passes that to the callable along         with a 'reason', primarily to differentiate DagRun failures.          .. note: The logs end up in             ``$AIRFLOW_HOME/logs/scheduler/latest/PROJECT/DAG_FILE.py.log``          :param dagrun: DagRun object         :param success: Flag to specify if failure or success callback should be called         :param reason: Completion reason         :param session: Database session         """ [34118,34783]
===
match
---
name: DagRun [36933,36939]
name: DagRun [36933,36939]
===
match
---
operator: , [87087,87088]
operator: , [87138,87139]
===
match
---
import_from [68802,68860]
import_from [68853,68911]
===
match
---
trailer [55452,55644]
trailer [55503,55695]
===
match
---
name: dag_id [74598,74604]
name: dag_id [74649,74655]
===
match
---
name: timezone [63704,63712]
name: timezone [63755,63763]
===
match
---
if_stmt [64081,64195]
if_stmt [64132,64246]
===
match
---
suite [24121,24146]
suite [24121,24146]
===
match
---
name: SerializedDagModel [94505,94523]
name: SerializedDagModel [94556,94574]
===
match
---
argument [18937,18954]
argument [18937,18954]
===
match
---
operator: == [50446,50448]
operator: == [50497,50499]
===
match
---
name: pickle_id [64176,64185]
name: pickle_id [64227,64236]
===
match
---
trailer [33672,33690]
trailer [33672,33690]
===
match
---
name: task_dict [63183,63192]
name: task_dict [63234,63243]
===
match
---
trailer [76659,76688]
trailer [76710,76739]
===
match
---
name: calculate_dagrun_date_fields [76660,76688]
name: calculate_dagrun_date_fields [76711,76739]
===
match
---
trailer [74219,74230]
trailer [74270,74281]
===
match
---
decorator [31144,31154]
decorator [31144,31154]
===
match
---
name: default_view [14363,14375]
name: default_view [14363,14375]
===
match
---
trailer [90699,90706]
trailer [90750,90757]
===
match
---
comparison [28784,28942]
comparison [28784,28942]
===
match
---
trailer [19377,19386]
trailer [19377,19386]
===
match
---
name: val [16943,16946]
name: val [16943,16946]
===
match
---
argument [72174,72192]
argument [72225,72243]
===
match
---
name: self [37136,37140]
name: self [37136,37140]
===
match
---
atom_expr [36316,36327]
atom_expr [36316,36327]
===
match
---
name: session [52464,52471]
name: session [52515,52522]
===
match
---
name: ignore_task_deps [66941,66957]
name: ignore_task_deps [66992,67008]
===
match
---
trailer [71541,71554]
trailer [71592,71605]
===
match
---
simple_stmt [45574,45609]
simple_stmt [45574,45609]
===
match
---
trailer [71698,71706]
trailer [71749,71757]
===
match
---
suite [64234,64414]
suite [64285,64465]
===
match
---
name: self [16574,16578]
name: self [16574,16578]
===
match
---
operator: , [38397,38398]
operator: , [38397,38398]
===
match
---
name: tags [76926,76930]
name: tags [76977,76981]
===
match
---
dotted_name [29397,29415]
dotted_name [29397,29415]
===
match
---
name: session [74102,74109]
name: session [74153,74160]
===
match
---
atom_expr [14710,14726]
atom_expr [14710,14726]
===
match
---
simple_stmt [88523,88580]
simple_stmt [88574,88631]
===
match
---
argument [55117,55128]
argument [55168,55179]
===
match
---
operator: = [83148,83149]
operator: = [83199,83200]
===
match
---
name: last_start [24739,24749]
name: last_start [24739,24749]
===
match
---
comparison [86129,86169]
comparison [86180,86220]
===
match
---
operator: -> [31175,31177]
operator: -> [31175,31177]
===
match
---
name: t [60052,60053]
name: t [60103,60104]
===
match
---
name: orm_dag [77311,77318]
name: orm_dag [77362,77369]
===
match
---
operator: == [48860,48862]
operator: == [48860,48862]
===
match
---
simple_stmt [21224,21273]
simple_stmt [21224,21273]
===
match
---
trailer [90835,90844]
trailer [90886,90895]
===
match
---
name: missing_dag_id [74335,74349]
name: missing_dag_id [74386,74400]
===
match
---
trailer [78793,78799]
trailer [78844,78850]
===
match
---
name: dag_run_state [46214,46227]
name: dag_run_state [46214,46227]
===
match
---
operator: = [81440,81441]
operator: = [81491,81492]
===
match
---
if_stmt [13112,13319]
if_stmt [13112,13319]
===
match
---
arith_expr [31084,31115]
arith_expr [31084,31115]
===
match
---
simple_stmt [24497,24521]
simple_stmt [24497,24521]
===
match
---
name: self [63213,63217]
name: self [63264,63268]
===
match
---
name: t [25169,25170]
name: t [25169,25170]
===
match
---
operator: = [56063,56064]
operator: = [56114,56115]
===
match
---
simple_stmt [84579,84612]
simple_stmt [84630,84663]
===
match
---
trailer [77375,77379]
trailer [77426,77430]
===
match
---
trailer [62226,62253]
trailer [62277,62304]
===
match
---
argument [49924,49939]
argument [49975,49990]
===
match
---
operator: @ [87025,87026]
operator: @ [87076,87077]
===
match
---
name: next_execution_date [22961,22980]
name: next_execution_date [22961,22980]
===
match
---
expr_stmt [52856,52896]
expr_stmt [52907,52947]
===
match
---
simple_stmt [17335,17372]
simple_stmt [17335,17372]
===
match
---
simple_stmt [28365,28382]
simple_stmt [28365,28382]
===
match
---
atom_expr [89953,89971]
atom_expr [90004,90022]
===
match
---
atom_expr [29281,29300]
atom_expr [29281,29300]
===
match
---
name: self [30054,30058]
name: self [30054,30058]
===
match
---
simple_stmt [21593,21644]
simple_stmt [21593,21644]
===
match
---
trailer [88061,88077]
trailer [88112,88128]
===
match
---
name: doc_md [11161,11167]
name: doc_md [11161,11167]
===
match
---
name: tis [42250,42253]
name: tis [42250,42253]
===
match
---
operator: = [86962,86963]
operator: = [87013,87014]
===
match
---
suite [20193,20374]
suite [20193,20374]
===
match
---
atom [63493,63495]
atom [63544,63546]
===
match
---
trailer [25961,25980]
trailer [25961,25980]
===
match
---
name: dag_ids [74212,74219]
name: dag_ids [74263,74270]
===
match
---
atom_expr [41068,41087]
atom_expr [41068,41087]
===
match
---
operator: , [71787,71788]
operator: , [71838,71839]
===
match
---
trailer [36457,36464]
trailer [36457,36464]
===
match
---
trailer [76631,76637]
trailer [76682,76688]
===
match
---
name: os [31084,31086]
name: os [31084,31086]
===
match
---
name: new_perm_mapping [18222,18238]
name: new_perm_mapping [18222,18238]
===
match
---
suite [60022,60119]
suite [60073,60170]
===
match
---
return_stmt [56636,56650]
return_stmt [56687,56701]
===
match
---
operator: = [17521,17522]
operator: = [17521,17522]
===
match
---
funcdef [64807,64917]
funcdef [64858,64968]
===
match
---
trailer [61415,61425]
trailer [61466,61476]
===
match
---
name: start_date [27469,27479]
name: start_date [27469,27479]
===
match
---
name: using_end_date [27527,27541]
name: using_end_date [27527,27541]
===
match
---
expr_stmt [56883,56980]
expr_stmt [56934,57031]
===
match
---
atom_expr [75333,75665]
atom_expr [75384,75716]
===
match
---
if_stmt [76895,76976]
if_stmt [76946,77027]
===
match
---
param [55957,55978]
param [56008,56029]
===
match
---
suite [63301,63397]
suite [63352,63448]
===
match
---
trailer [45638,45646]
trailer [45638,45646]
===
match
---
name: timezone [27545,27553]
name: timezone [27545,27553]
===
match
---
name: task [66002,66006]
name: task [66053,66057]
===
match
---
atom_expr [95632,95656]
atom_expr [95683,95707]
===
match
---
atom_expr [58710,58723]
atom_expr [58761,58774]
===
match
---
expr_stmt [54557,54572]
expr_stmt [54608,54623]
===
match
---
simple_stmt [19361,19397]
simple_stmt [19361,19397]
===
match
---
operator: = [83950,83951]
operator: = [84001,84002]
===
match
---
operator: = [89828,89829]
operator: = [89879,89880]
===
match
---
name: str [70283,70286]
name: str [70334,70337]
===
match
---
trailer [48841,48848]
trailer [48841,48848]
===
match
---
name: concurrency [86027,86038]
name: concurrency [86078,86089]
===
match
---
operator: = [46029,46030]
operator: = [46029,46030]
===
match
---
name: t [41211,41212]
name: t [41211,41212]
===
match
---
if_stmt [52808,52897]
if_stmt [52859,52948]
===
match
---
operator: , [1538,1539]
operator: , [1538,1539]
===
match
---
param [46326,46344]
param [46326,46344]
===
match
---
simple_stmt [1017,1203]
simple_stmt [1017,1203]
===
match
---
simple_stmt [24995,25023]
simple_stmt [24995,25023]
===
match
---
trailer [81419,81439]
trailer [81470,81490]
===
match
---
simple_stmt [75297,75676]
simple_stmt [75348,75727]
===
match
---
name: keys [16834,16838]
name: keys [16834,16838]
===
match
---
trailer [35031,35035]
trailer [35031,35035]
===
match
---
name: EdgeInfoType [15448,15460]
name: EdgeInfoType [15448,15460]
===
match
---
expr_stmt [57755,57780]
expr_stmt [57806,57831]
===
match
---
operator: = [70335,70336]
operator: = [70386,70387]
===
match
---
operator: @ [31310,31311]
operator: @ [31310,31311]
===
match
---
name: session [28697,28704]
name: session [28697,28704]
===
match
---
string: """This is only there for backward compatible jinja2 templates""" [78123,78188]
string: """This is only there for backward compatible jinja2 templates""" [78174,78239]
===
match
---
atom_expr [40983,41002]
atom_expr [40983,41002]
===
match
---
expr_stmt [20447,20478]
expr_stmt [20447,20478]
===
match
---
atom_expr [33164,33184]
atom_expr [33164,33184]
===
match
---
tfpdef [10395,10430]
tfpdef [10395,10430]
===
match
---
atom_expr [11503,11527]
atom_expr [11503,11527]
===
match
---
simple_stmt [45617,45682]
simple_stmt [45617,45682]
===
match
---
name: str [10811,10814]
name: str [10811,10814]
===
match
---
expr_stmt [58015,58068]
expr_stmt [58066,58119]
===
match
---
simple_stmt [63367,63397]
simple_stmt [63418,63448]
===
match
---
argument [53839,53870]
argument [53890,53921]
===
match
---
atom_expr [22029,22062]
atom_expr [22029,22062]
===
match
---
string: 'pickling_duration' [63677,63696]
string: 'pickling_duration' [63728,63747]
===
match
---
operator: = [10633,10634]
operator: = [10633,10634]
===
match
---
simple_stmt [41935,41976]
simple_stmt [41935,41976]
===
match
---
name: utils [2422,2427]
name: utils [2422,2427]
===
match
---
name: end_date [40772,40780]
name: end_date [40772,40780]
===
match
---
atom [12386,12388]
atom [12386,12388]
===
match
---
trailer [39833,39858]
trailer [39833,39858]
===
match
---
name: models [1682,1688]
name: models [1682,1688]
===
match
---
operator: = [76404,76405]
operator: = [76455,76456]
===
match
---
operator: = [72577,72578]
operator: = [72628,72629]
===
match
---
name: task [65952,65956]
name: task [66003,66007]
===
match
---
trailer [61182,61191]
trailer [61233,61242]
===
match
---
operator: = [18122,18123]
operator: = [18122,18123]
===
match
---
trailer [57736,57746]
trailer [57787,57797]
===
match
---
atom_expr [75014,75037]
atom_expr [75065,75088]
===
match
---
name: is_paused_upon_creation [74492,74515]
name: is_paused_upon_creation [74543,74566]
===
match
---
dotted_name [2146,2159]
dotted_name [2146,2159]
===
match
---
arglist [51389,51445]
arglist [51440,51496]
===
match
---
atom_expr [62909,62919]
atom_expr [62960,62970]
===
match
---
parameters [86802,86858]
parameters [86853,86909]
===
match
---
testlist_comp [42736,42791]
testlist_comp [42736,42791]
===
match
---
name: session [79797,79804]
name: session [79848,79855]
===
match
---
trailer [34989,35008]
trailer [34989,35008]
===
match
---
name: instance [19926,19934]
name: instance [19926,19934]
===
match
---
name: task [38820,38824]
name: task [38820,38824]
===
match
---
operator: , [67134,67135]
operator: , [67185,67186]
===
match
---
name: dag_id [16152,16158]
name: dag_id [16152,16158]
===
match
---
name: DagBag [52866,52872]
name: DagBag [52917,52923]
===
match
---
name: start_date [53516,53526]
name: start_date [53567,53577]
===
match
---
decorated [31310,31564]
decorated [31310,31564]
===
match
---
operator: = [12137,12138]
operator: = [12137,12138]
===
match
---
atom_expr [75155,75168]
atom_expr [75206,75219]
===
match
---
dotted_name [94405,94434]
dotted_name [94456,94485]
===
match
---
suite [40454,40700]
suite [40454,40700]
===
match
---
trailer [80520,80527]
trailer [80571,80578]
===
match
---
name: dags [73758,73762]
name: dags [73809,73813]
===
match
---
name: Iterable [58710,58718]
name: Iterable [58761,58769]
===
match
---
argument [45908,45935]
argument [45908,45935]
===
match
---
operator: == [54860,54862]
operator: == [54911,54913]
===
match
---
atom_expr [44589,44612]
atom_expr [44589,44612]
===
match
---
name: task_id [44894,44901]
name: task_id [44894,44901]
===
match
---
operator: < [79477,79478]
operator: < [79528,79529]
===
match
---
name: dag [63978,63981]
name: dag [64029,64032]
===
match
---
name: max_active_runs [91610,91625]
name: max_active_runs [91661,91676]
===
match
---
operator: = [29664,29665]
operator: = [29664,29665]
===
match
---
expr_stmt [16876,16904]
expr_stmt [16876,16904]
===
match
---
operator: = [16650,16651]
operator: = [16650,16651]
===
match
---
operator: } [35227,35228]
operator: } [35227,35228]
===
match
---
atom_expr [26598,26617]
atom_expr [26598,26617]
===
match
---
name: str [58719,58722]
name: str [58770,58773]
===
match
---
decorator [36546,36563]
decorator [36546,36563]
===
match
---
string: """         Sorts tasks in topographical order, such that a task comes after any of its         upstream dependencies.          Heavily inspired by:         http://blog.jupo.org/2012/04/06/topological-sorting-acyclic-directed-graphs/          :param include_subdag_tasks: whether to include tasks in subdags, default to False         :return: list of tasks in topological order         """ [42870,43259]
string: """         Sorts tasks in topographical order, such that a task comes after any of its         upstream dependencies.          Heavily inspired by:         http://blog.jupo.org/2012/04/06/topological-sorting-acyclic-directed-graphs/          :param include_subdag_tasks: whether to include tasks in subdags, default to False         :return: list of tasks in topological order         """ [42870,43259]
===
match
---
trailer [42757,42763]
trailer [42757,42763]
===
match
---
name: cron [20014,20018]
name: cron [20014,20018]
===
match
---
expr_stmt [83254,83279]
expr_stmt [83305,83330]
===
match
---
funcdef [17287,17372]
funcdef [17287,17372]
===
match
---
atom_expr [75059,75074]
atom_expr [75110,75125]
===
match
---
name: next_run_date [25782,25795]
name: next_run_date [25782,25795]
===
match
---
operator: = [45723,45724]
operator: = [45723,45724]
===
match
---
name: self [25753,25757]
name: self [25753,25757]
===
match
---
name: orientation [14662,14673]
name: orientation [14662,14673]
===
match
---
name: factory [94260,94267]
name: factory [94311,94318]
===
match
---
atom_expr [35764,35782]
atom_expr [35764,35782]
===
match
---
simple_stmt [61127,61163]
simple_stmt [61178,61214]
===
match
---
name: tis [50390,50393]
name: tis [50441,50444]
===
match
---
trailer [12634,12647]
trailer [12634,12647]
===
match
---
name: add_tasks [66488,66497]
name: add_tasks [66539,66548]
===
match
---
arglist [33635,33662]
arglist [33635,33662]
===
match
---
name: dag [77467,77470]
name: dag [77518,77521]
===
match
---
trailer [87433,87439]
trailer [87484,87490]
===
match
---
name: group [62295,62300]
name: group [62346,62351]
===
match
---
string: 'undefined' [39696,39707]
string: 'undefined' [39696,39707]
===
match
---
atom_expr [25437,25488]
atom_expr [25437,25488]
===
match
---
name: DEFAULT_VIEW_PRESETS [14379,14399]
name: DEFAULT_VIEW_PRESETS [14379,14399]
===
match
---
argument [41787,41811]
argument [41787,41811]
===
match
---
atom_expr [86129,86161]
atom_expr [86180,86212]
===
match
---
atom_expr [57001,57034]
atom_expr [57052,57085]
===
match
---
trailer [31998,32005]
trailer [31998,32005]
===
match
---
operator: , [53610,53611]
operator: , [53661,53662]
===
match
---
name: provide_session [32552,32567]
name: provide_session [32552,32567]
===
match
---
atom_expr [16147,16158]
atom_expr [16147,16158]
===
match
---
expr_stmt [29463,29488]
expr_stmt [29463,29488]
===
match
---
testlist_comp [42498,42551]
testlist_comp [42498,42551]
===
match
---
expr_stmt [84465,84499]
expr_stmt [84516,84550]
===
match
---
argument [58603,58608]
argument [58654,58659]
===
match
---
atom_expr [56834,56870]
atom_expr [56885,56921]
===
match
---
testlist_comp [41953,41974]
testlist_comp [41953,41974]
===
match
---
name: self [62991,62995]
name: self [63042,63046]
===
match
---
simple_stmt [34118,34784]
simple_stmt [34118,34784]
===
match
---
comparison [12533,12566]
comparison [12533,12566]
===
match
---
name: convert_to_utc [13355,13369]
name: convert_to_utc [13355,13369]
===
match
---
operator: , [13155,13156]
operator: , [13155,13156]
===
match
---
name: doc_md [93661,93667]
name: doc_md [93712,93718]
===
match
---
operator: , [28073,28074]
operator: , [28073,28074]
===
match
---
arglist [73738,73763]
arglist [73789,73814]
===
match
---
name: template_searchpath [13875,13894]
name: template_searchpath [13875,13894]
===
match
---
trailer [11619,11632]
trailer [11619,11632]
===
match
---
comparison [20664,20709]
comparison [20664,20709]
===
match
---
name: normalized_schedule_interval [19277,19305]
name: normalized_schedule_interval [19277,19305]
===
match
---
operator: , [80683,80684]
operator: , [80734,80735]
===
match
---
atom_expr [45596,45607]
atom_expr [45596,45607]
===
match
---
string: """Return nodes with no parents. These are first to execute and are called roots or root nodes.""" [42383,42481]
string: """Return nodes with no parents. These are first to execute and are called roots or root nodes.""" [42383,42481]
===
match
---
operator: , [91887,91888]
operator: , [91938,91939]
===
match
---
arglist [20586,20595]
arglist [20586,20595]
===
match
---
trailer [73927,73935]
trailer [73978,73986]
===
match
---
simple_stmt [76992,77021]
simple_stmt [77043,77072]
===
match
---
expr_stmt [45617,45681]
expr_stmt [45617,45681]
===
match
---
fstring [56894,56980]
fstring [56945,57031]
===
match
---
trailer [19241,19245]
trailer [19241,19245]
===
match
---
atom_expr [91780,92003]
atom_expr [91831,92054]
===
match
---
suite [81288,82351]
suite [81339,82402]
===
match
---
name: dag_id [75423,75429]
name: dag_id [75474,75480]
===
match
---
trailer [56838,56843]
trailer [56889,56894]
===
match
---
name: scalar [81226,81232]
name: scalar [81277,81283]
===
match
---
arith_expr [31028,31054]
arith_expr [31028,31054]
===
match
---
name: settings [31028,31036]
name: settings [31028,31036]
===
match
---
atom_expr [94492,94524]
atom_expr [94543,94575]
===
match
---
trailer [86596,86598]
trailer [86647,86649]
===
match
---
operator: , [21860,21861]
operator: , [21860,21861]
===
match
---
name: self [65911,65915]
name: self [65962,65966]
===
match
---
operator: == [19461,19463]
operator: == [19461,19463]
===
match
---
name: days [10085,10089]
name: days [10085,10089]
===
match
---
name: dag_id [86741,86747]
name: dag_id [86792,86798]
===
match
---
if_stmt [2643,2712]
if_stmt [2643,2712]
===
match
---
trailer [63387,63396]
trailer [63438,63447]
===
match
---
name: query [3548,3553]
name: query [3548,3553]
===
match
---
expr_stmt [40853,40908]
expr_stmt [40853,40908]
===
match
---
trailer [20167,20190]
trailer [20167,20190]
===
match
---
expr_stmt [80910,80964]
expr_stmt [80961,81015]
===
match
---
trailer [72832,72839]
trailer [72883,72890]
===
match
---
name: f_code [12301,12307]
name: f_code [12301,12307]
===
match
---
name: conf [67091,67095]
name: conf [67142,67146]
===
match
---
name: c [16427,16428]
name: c [16427,16428]
===
match
---
atom_expr [11169,11182]
atom_expr [11169,11182]
===
match
---
param [66807,66826]
param [66858,66877]
===
match
---
expr_stmt [12153,12184]
expr_stmt [12153,12184]
===
match
---
argument [72381,72392]
argument [72432,72443]
===
match
---
simple_stmt [49234,49439]
simple_stmt [49285,49490]
===
match
---
name: id [64166,64168]
name: id [64217,64219]
===
match
---
trailer [73904,73914]
trailer [73955,73965]
===
match
---
param [81283,81286]
param [81334,81337]
===
match
---
expr_stmt [90604,90934]
expr_stmt [90655,90985]
===
match
---
suite [66511,66723]
suite [66562,66774]
===
match
---
number: 2 [58555,58556]
number: 2 [58606,58607]
===
match
---
and_test [27853,27902]
and_test [27853,27902]
===
match
---
name: ti_list [54926,54933]
name: ti_list [54977,54984]
===
match
---
name: self [16619,16623]
name: self [16619,16623]
===
match
---
name: DagStateChangeCallback [11051,11073]
name: DagStateChangeCallback [11051,11073]
===
match
---
name: dag_kwargs [92708,92718]
name: dag_kwargs [92759,92769]
===
match
---
name: DEPRECATED_ACTION_CAN_DAG_READ [17935,17965]
name: DEPRECATED_ACTION_CAN_DAG_READ [17935,17965]
===
match
---
name: staticmethod [86440,86452]
name: staticmethod [86491,86503]
===
match
---
name: fileloc [76175,76182]
name: fileloc [76226,76233]
===
match
---
operator: , [49539,49540]
operator: , [49590,49591]
===
match
---
subscriptlist [58692,58723]
subscriptlist [58743,58774]
===
match
---
name: str [45370,45373]
name: str [45370,45373]
===
match
---
return_stmt [29955,29977]
return_stmt [29955,29977]
===
match
---
atom_expr [11367,11381]
atom_expr [11367,11381]
===
match
---
operator: } [93917,93918]
operator: } [93968,93969]
===
match
---
operator: = [54561,54562]
operator: = [54612,54613]
===
match
---
simple_stmt [38728,38744]
simple_stmt [38728,38744]
===
match
---
operator: , [82847,82848]
operator: , [82898,82899]
===
match
---
name: dag_id [76756,76762]
name: dag_id [76807,76813]
===
match
---
operator: { [73786,73787]
operator: { [73837,73838]
===
match
---
name: self [12486,12490]
name: self [12486,12490]
===
match
---
argument [72276,72297]
argument [72327,72348]
===
match
---
name: bool [28749,28753]
name: bool [28749,28753]
===
match
---
trailer [19991,20000]
trailer [19991,20000]
===
match
---
atom_expr [20163,20192]
atom_expr [20163,20192]
===
match
---
atom_expr [62227,62252]
atom_expr [62278,62303]
===
match
---
name: group [62471,62476]
name: group [62522,62527]
===
match
---
tfpdef [82849,82870]
tfpdef [82900,82921]
===
match
---
trailer [86719,86726]
trailer [86770,86777]
===
match
---
comparison [21932,21977]
comparison [21932,21977]
===
match
---
trailer [45892,45898]
trailer [45892,45898]
===
match
---
operator: = [24949,24950]
operator: = [24949,24950]
===
match
---
operator: = [56327,56328]
operator: = [56378,56379]
===
match
---
trailer [87429,87433]
trailer [87480,87484]
===
match
---
atom_expr [49098,49139]
atom_expr [49098,49139]
===
match
---
name: dagrun_timeout [14286,14300]
name: dagrun_timeout [14286,14300]
===
match
---
simple_stmt [66266,66282]
simple_stmt [66317,66333]
===
match
---
trailer [53422,53428]
trailer [53473,53479]
===
match
---
atom_expr [42194,42235]
atom_expr [42194,42235]
===
match
---
name: graph_sorted [45277,45289]
name: graph_sorted [45277,45289]
===
match
---
atom_expr [14484,14650]
atom_expr [14484,14650]
===
match
---
name: default_view [10797,10809]
name: default_view [10797,10809]
===
match
---
funcdef [55803,57591]
funcdef [55854,57642]
===
match
---
name: security [2081,2089]
name: security [2081,2089]
===
match
---
operator: != [28344,28346]
operator: != [28344,28346]
===
match
---
suite [78861,78927]
suite [78912,78978]
===
match
---
name: synchronize_session [45908,45927]
name: synchronize_session [45908,45927]
===
match
---
suite [2660,2712]
suite [2660,2712]
===
match
---
operator: = [85734,85735]
operator: = [85785,85786]
===
match
---
trailer [33835,33853]
trailer [33835,33853]
===
match
---
operator: = [66864,66865]
operator: = [66915,66916]
===
match
---
trailer [75186,75188]
trailer [75237,75239]
===
match
---
trailer [14163,14175]
trailer [14163,14175]
===
match
---
name: Optional [22185,22193]
name: Optional [22185,22193]
===
match
---
name: TI [50323,50325]
name: TI [50374,50376]
===
match
---
name: BACKFILL_JOB [75025,75037]
name: BACKFILL_JOB [75076,75088]
===
match
---
simple_stmt [83442,83459]
simple_stmt [83493,83510]
===
match
---
suite [21048,21919]
suite [21048,21919]
===
match
---
operator: = [12717,12718]
operator: = [12717,12718]
===
match
---
test [12019,12057]
test [12019,12057]
===
match
---
name: utils [55167,55172]
name: utils [55218,55223]
===
match
---
atom_expr [24675,24697]
atom_expr [24675,24697]
===
match
---
return_stmt [21991,22063]
return_stmt [21991,22063]
===
match
---
name: len [62888,62891]
name: len [62939,62942]
===
match
---
trailer [43606,43618]
trailer [43606,43618]
===
match
---
funcdef [37836,38071]
funcdef [37836,38071]
===
match
---
name: qry [81222,81225]
name: qry [81273,81276]
===
match
---
name: start_date [25913,25923]
name: start_date [25913,25923]
===
match
---
if_stmt [13030,13319]
if_stmt [13030,13319]
===
match
---
name: kwargs [92778,92784]
name: kwargs [92829,92835]
===
match
---
argument [28580,28637]
argument [28580,28637]
===
match
---
trailer [71686,71698]
trailer [71737,71749]
===
match
---
name: commit [55751,55757]
name: commit [55802,55808]
===
match
---
expr_stmt [14945,14967]
expr_stmt [14945,14967]
===
match
---
atom_expr [57099,57480]
atom_expr [57150,57531]
===
match
---
trailer [14980,14990]
trailer [14980,14990]
===
match
---
name: filter [49102,49108]
name: filter [49102,49108]
===
match
---
simple_stmt [89953,89972]
simple_stmt [90004,90023]
===
match
---
name: State [2579,2584]
name: State [2579,2584]
===
match
---
expr_stmt [85049,85075]
expr_stmt [85100,85126]
===
match
---
atom_expr [63504,63521]
atom_expr [63555,63572]
===
match
---
trailer [65301,65312]
trailer [65352,65363]
===
match
---
name: _tb [17321,17324]
name: _tb [17321,17324]
===
match
---
operator: , [71548,71549]
operator: , [71599,71600]
===
match
---
expr_stmt [41014,41239]
expr_stmt [41014,41239]
===
match
---
trailer [66417,66431]
trailer [66468,66482]
===
match
---
name: args [69871,69875]
name: args [69922,69926]
===
match
---
name: filter [80625,80631]
name: filter [80676,80682]
===
match
---
name: start_date [40829,40839]
name: start_date [40829,40839]
===
match
---
name: dag [74411,74414]
name: dag [74462,74465]
===
match
---
simple_stmt [92657,92720]
simple_stmt [92708,92771]
===
match
---
operator: @ [30560,30561]
operator: @ [30560,30561]
===
match
---
name: execution_date [36588,36602]
name: execution_date [36588,36602]
===
match
---
param [60907,60913]
param [60958,60964]
===
match
---
atom_expr [88523,88579]
atom_expr [88574,88630]
===
match
---
name: classmethod [95369,95380]
name: classmethod [95420,95431]
===
match
---
sync_comp_for [60828,60865]
sync_comp_for [60879,60916]
===
match
---
name: run_backwards [67144,67157]
name: run_backwards [67195,67208]
===
match
---
operator: = [74541,74542]
operator: = [74592,74593]
===
match
---
operator: , [40770,40771]
operator: , [40770,40771]
===
match
---
name: set_downstream [40650,40664]
name: set_downstream [40650,40664]
===
match
---
decorated [86604,86757]
decorated [86655,86808]
===
match
---
name: has_task_concurrency_limits [76554,76581]
name: has_task_concurrency_limits [76605,76632]
===
match
---
name: airflow [1719,1726]
name: airflow [1719,1726]
===
match
---
name: self [59813,59817]
name: self [59864,59868]
===
match
---
atom_expr [14264,14283]
atom_expr [14264,14283]
===
match
---
name: dag_id [87383,87389]
name: dag_id [87434,87440]
===
match
---
name: task_id [66046,66053]
name: task_id [66097,66104]
===
match
---
operator: == [36975,36977]
operator: == [36975,36977]
===
match
---
name: str [63006,63009]
name: str [63057,63060]
===
match
---
param [46409,46435]
param [46409,46435]
===
match
---
return_stmt [17080,17115]
return_stmt [17080,17115]
===
match
---
decorator [42322,42332]
decorator [42322,42332]
===
match
---
name: make_naive [21241,21251]
name: make_naive [21241,21251]
===
match
---
name: task_id [44691,44698]
name: task_id [44691,44698]
===
match
---
param [40787,40798]
param [40787,40798]
===
match
---
name: dag_id [45601,45607]
name: dag_id [45601,45607]
===
match
---
name: task_id [63027,63034]
name: task_id [63078,63085]
===
match
---
operator: = [89296,89297]
operator: = [89347,89348]
===
match
---
trailer [32736,32743]
trailer [32736,32743]
===
match
---
name: DagRun [72154,72160]
name: DagRun [72205,72211]
===
match
---
trailer [61133,61147]
trailer [61184,61198]
===
match
---
param [40434,40452]
param [40434,40452]
===
match
---
parameters [31762,31782]
parameters [31762,31782]
===
match
---
name: dttm [19981,19985]
name: dttm [19981,19985]
===
match
---
trailer [91908,91915]
trailer [91959,91966]
===
match
---
atom_expr [69833,69852]
atom_expr [69884,69903]
===
match
---
operator: - [81485,81486]
operator: - [81536,81537]
===
match
---
operator: } [61195,61196]
operator: } [61246,61247]
===
match
---
suite [86047,86118]
suite [86098,86169]
===
match
---
name: include_direct_upstream [60500,60523]
name: include_direct_upstream [60551,60574]
===
match
---
fstring [71589,71639]
fstring [71640,71690]
===
match
---
name: DagCode [77442,77449]
name: DagCode [77493,77500]
===
match
---
name: is_subdag [14981,14990]
name: is_subdag [14981,14990]
===
match
---
simple_stmt [48923,48950]
simple_stmt [48923,48950]
===
match
---
suite [78747,78767]
suite [78798,78818]
===
match
---
trailer [52216,52348]
trailer [52267,52399]
===
match
---
name: on_success_callback [15662,15681]
name: on_success_callback [15662,15681]
===
match
---
name: self [40618,40622]
name: self [40618,40622]
===
match
---
atom_expr [29788,29805]
atom_expr [29788,29805]
===
match
---
name: params [11682,11688]
name: params [11682,11688]
===
match
---
trailer [75088,75098]
trailer [75139,75149]
===
match
---
atom_expr [66233,66245]
atom_expr [66284,66296]
===
match
---
name: result [58141,58147]
name: result [58192,58198]
===
match
---
expr_stmt [45717,45774]
expr_stmt [45717,45774]
===
match
---
name: timezone [13292,13300]
name: timezone [13292,13300]
===
match
---
trailer [63653,63662]
trailer [63704,63713]
===
match
---
operator: += [60342,60344]
operator: += [60393,60395]
===
match
---
simple_stmt [1943,1984]
simple_stmt [1943,1984]
===
match
---
string: "Sync %s DAGs" [73738,73752]
string: "Sync %s DAGs" [73789,73803]
===
match
---
for_stmt [77678,77758]
for_stmt [77729,77809]
===
match
---
name: STATICA_HACK [94290,94302]
name: STATICA_HACK [94341,94353]
===
match
---
trailer [62455,62457]
trailer [62506,62508]
===
match
---
name: self [11836,11840]
name: self [11836,11840]
===
match
---
name: int [29941,29944]
name: int [29941,29944]
===
match
---
suite [63480,63899]
suite [63531,63950]
===
match
---
name: log [25335,25338]
name: log [25335,25338]
===
match
---
name: PatternType [2795,2806]
name: PatternType [2795,2806]
===
match
---
name: filter [74893,74899]
name: filter [74944,74950]
===
match
---
atom_expr [13731,13760]
atom_expr [13731,13760]
===
match
---
name: utcnow [64341,64347]
name: utcnow [64392,64398]
===
match
---
name: dag [91652,91655]
name: dag [91703,91706]
===
match
---
testlist_comp [23198,23263]
testlist_comp [23198,23263]
===
match
---
argument [85316,85338]
argument [85367,85389]
===
match
---
param [19550,19555]
param [19550,19555]
===
match
---
name: print [56737,56742]
name: print [56788,56793]
===
match
---
operator: , [1189,1190]
operator: , [1189,1190]
===
match
---
simple_stmt [50671,50732]
simple_stmt [50722,50783]
===
match
---
simple_stmt [65326,65360]
simple_stmt [65377,65411]
===
match
---
atom_expr [95767,95791]
atom_expr [95818,95842]
===
match
---
tfpdef [10239,10295]
tfpdef [10239,10295]
===
match
---
name: not_none_states [80910,80925]
name: not_none_states [80961,80976]
===
match
---
argument [58544,58556]
argument [58595,58607]
===
match
---
simple_stmt [1546,1585]
simple_stmt [1546,1585]
===
match
---
operator: = [69777,69778]
operator: = [69828,69829]
===
match
---
param [86803,86808]
param [86854,86859]
===
match
---
name: cls [81416,81419]
name: cls [81467,81470]
===
match
---
name: root_dag_id [83699,83710]
name: root_dag_id [83750,83761]
===
match
---
suite [30509,30555]
suite [30509,30555]
===
match
---
trailer [33762,33780]
trailer [33762,33780]
===
match
---
simple_stmt [29366,29391]
simple_stmt [29366,29391]
===
match
---
atom_expr [68885,68900]
atom_expr [68936,68951]
===
match
---
param [40772,40786]
param [40772,40786]
===
match
---
operator: , [85828,85829]
operator: , [85879,85880]
===
match
---
operator: , [70013,70014]
operator: , [70064,70065]
===
match
---
name: qry [32791,32794]
name: qry [32791,32794]
===
match
---
argument [69436,69475]
argument [69487,69526]
===
match
---
atom_expr [55167,55200]
atom_expr [55218,55251]
===
match
---
operator: , [49774,49775]
operator: , [49825,49826]
===
match
---
trailer [76905,76910]
trailer [76956,76961]
===
match
---
atom_expr [77275,77285]
atom_expr [77326,77336]
===
match
---
name: visited_external_tis [46409,46429]
name: visited_external_tis [46409,46429]
===
match
---
name: t [64785,64786]
name: t [64836,64837]
===
match
---
comparison [18824,18839]
comparison [18824,18839]
===
match
---
funcdef [78391,78952]
funcdef [78442,79003]
===
match
---
operator: = [27338,27339]
operator: = [27338,27339]
===
match
---
and_test [24056,24120]
and_test [24056,24120]
===
match
---
name: active_runs_of_dag [91933,91951]
name: active_runs_of_dag [91984,92002]
===
match
---
suite [25769,26099]
suite [25769,26099]
===
match
---
name: self [32590,32594]
name: self [32590,32594]
===
match
---
operator: = [59800,59801]
operator: = [59851,59852]
===
match
---
string: '_log' [57938,57944]
string: '_log' [57989,57995]
===
match
---
trailer [87507,87509]
trailer [87558,87560]
===
match
---
return_stmt [19509,19521]
return_stmt [19509,19521]
===
match
---
atom_expr [22893,22948]
atom_expr [22893,22948]
===
match
---
param [18703,18729]
param [18703,18729]
===
match
---
operator: = [52462,52463]
operator: = [52513,52514]
===
match
---
return_stmt [31634,31708]
return_stmt [31634,31708]
===
match
---
trailer [3685,3687]
trailer [3685,3687]
===
match
---
string: 'schedule_interval' [9758,9777]
string: 'schedule_interval' [9758,9777]
===
match
---
name: provide_session [35819,35834]
name: provide_session [35819,35834]
===
match
---
simple_stmt [3540,3636]
simple_stmt [3540,3636]
===
match
---
argument [49600,49623]
argument [49651,49674]
===
match
---
name: is_paused_at_creation [83976,83997]
name: is_paused_at_creation [84027,84048]
===
match
---
param [92158,92170]
param [92209,92221]
===
match
---
trailer [42775,42791]
trailer [42775,42791]
===
match
---
atom_expr [26067,26082]
atom_expr [26067,26082]
===
match
---
return_stmt [40375,40385]
return_stmt [40375,40385]
===
match
---
parameters [87654,87660]
parameters [87705,87711]
===
match
---
name: max [25840,25843]
name: max [25840,25843]
===
match
---
expr_stmt [42244,42297]
expr_stmt [42244,42297]
===
match
---
name: reason [35221,35227]
name: reason [35221,35227]
===
match
---
trailer [3653,3662]
trailer [3653,3662]
===
match
---
name: query [3540,3545]
name: query [3540,3545]
===
match
---
name: self [30418,30422]
name: self [30418,30422]
===
match
---
name: self [64391,64395]
name: self [64442,64446]
===
match
---
atom_expr [69779,69817]
atom_expr [69830,69868]
===
match
---
operator: , [85285,85286]
operator: , [85336,85337]
===
match
---
tfpdef [10945,10958]
tfpdef [10945,10958]
===
match
---
trailer [12689,12702]
trailer [12689,12702]
===
match
---
simple_stmt [40618,40700]
simple_stmt [40618,40700]
===
match
---
arglist [45008,45028]
arglist [45008,45028]
===
match
---
atom_expr [21434,21463]
atom_expr [21434,21463]
===
match
---
name: in_ [80670,80673]
name: in_ [80721,80724]
===
match
---
atom_expr [65697,65710]
atom_expr [65748,65761]
===
match
---
operator: = [28462,28463]
operator: = [28462,28463]
===
match
---
expr_stmt [25941,25997]
expr_stmt [25941,25997]
===
match
---
simple_stmt [14413,14452]
simple_stmt [14413,14452]
===
match
---
name: jinja_environment_kwargs [11341,11365]
name: jinja_environment_kwargs [11341,11365]
===
match
---
atom_expr [88619,88637]
atom_expr [88670,88688]
===
match
---
name: self [38450,38454]
name: self [38450,38454]
===
match
---
trailer [64589,64620]
trailer [64640,64671]
===
match
---
name: get_flat_relatives [60347,60365]
name: get_flat_relatives [60398,60416]
===
match
---
suite [75741,77393]
suite [75792,77444]
===
match
---
trailer [63676,63697]
trailer [63727,63748]
===
match
---
funcdef [86478,86599]
funcdef [86529,86650]
===
match
---
expr_stmt [64119,64194]
expr_stmt [64170,64245]
===
match
---
operator: @ [30791,30792]
operator: @ [30791,30792]
===
match
---
atom_expr [95421,95434]
atom_expr [95472,95485]
===
match
---
name: DagModel [94466,94474]
name: DagModel [94517,94525]
===
match
---
return_stmt [90944,91029]
return_stmt [90995,91080]
===
match
---
string: 'max_active_runs_per_dag' [10655,10680]
string: 'max_active_runs_per_dag' [10655,10680]
===
match
---
name: OrderedDict [43456,43467]
name: OrderedDict [43456,43467]
===
match
---
simple_stmt [89984,89990]
simple_stmt [90035,90041]
===
match
---
decorator [73199,73216]
decorator [73250,73267]
===
match
---
comp_op [51121,51127]
comp_op [51172,51178]
===
match
---
trailer [61520,61535]
trailer [61571,61586]
===
match
---
atom_expr [12486,12499]
atom_expr [12486,12499]
===
match
---
operator: , [16549,16550]
operator: , [16549,16550]
===
match
---
name: date_last_automated_dagrun [23303,23329]
name: date_last_automated_dagrun [23303,23329]
===
match
---
name: previous [21909,21917]
name: previous [21909,21917]
===
match
---
decorated [29719,29806]
decorated [29719,29806]
===
match
---
comparison [44686,44716]
comparison [44686,44716]
===
match
---
name: pop_context_managed_dag [95389,95412]
name: pop_context_managed_dag [95440,95463]
===
match
---
fstring_string: <DAG:  [86340,86346]
fstring_string: <DAG:  [86391,86397]
===
match
---
raise_stmt [53049,53107]
raise_stmt [53100,53158]
===
match
---
operator: @ [88083,88084]
operator: @ [88134,88135]
===
match
---
arglist [25844,25874]
arglist [25844,25874]
===
match
---
name: upstream_task_id [40416,40432]
name: upstream_task_id [40416,40432]
===
match
---
trailer [31988,31996]
trailer [31988,31996]
===
match
---
atom_expr [48831,48906]
atom_expr [48831,48906]
===
match
---
factor [78817,78853]
factor [78868,78904]
===
match
---
name: pickle_id [30009,30018]
name: pickle_id [30009,30018]
===
match
---
suite [3231,3714]
suite [3231,3714]
===
match
---
trailer [81084,81090]
trailer [81135,81141]
===
match
---
name: clear_task_instances [2047,2067]
name: clear_task_instances [2047,2067]
===
match
---
name: pendulum [23340,23348]
name: pendulum [23340,23348]
===
match
---
atom_expr [61064,61085]
atom_expr [61115,61136]
===
match
---
operator: , [3029,3030]
operator: , [3029,3030]
===
match
---
name: self [15961,15965]
name: self [15961,15965]
===
match
---
name: state [80939,80944]
name: state [80990,80995]
===
match
---
expr_stmt [25032,25052]
expr_stmt [25032,25052]
===
match
---
name: tags [77000,77004]
name: tags [77051,77055]
===
match
---
operator: = [71674,71675]
operator: = [71725,71726]
===
match
---
operator: @ [29121,29122]
operator: @ [29121,29122]
===
match
---
trailer [21738,21748]
trailer [21738,21748]
===
match
---
simple_stmt [69726,69761]
simple_stmt [69777,69812]
===
match
---
if_stmt [62885,62953]
if_stmt [62936,63004]
===
match
---
simple_stmt [14309,14352]
simple_stmt [14309,14352]
===
match
---
name: partial [64893,64900]
name: partial [64944,64951]
===
match
---
operator: @ [79868,79869]
operator: @ [79919,79920]
===
match
---
operator: , [21334,21335]
operator: , [21334,21335]
===
match
---
trailer [73935,73979]
trailer [73986,74030]
===
match
---
operator: = [72286,72287]
operator: = [72337,72338]
===
match
---
fstring_expr [45239,45252]
fstring_expr [45239,45252]
===
match
---
trailer [73841,73860]
trailer [73892,73911]
===
match
---
name: models [1780,1786]
name: models [1780,1786]
===
match
---
string: 'is_subdag' [81836,81847]
string: 'is_subdag' [81887,81898]
===
match
---
trailer [26499,26505]
trailer [26499,26505]
===
match
---
atom_expr [20500,20537]
atom_expr [20500,20537]
===
match
---
operator: * [64603,64604]
operator: * [64654,64655]
===
match
---
argument [77741,77756]
argument [77792,77807]
===
match
---
name: Stats [35408,35413]
name: Stats [35408,35413]
===
match
---
argument [69413,69422]
argument [69464,69473]
===
match
---
suite [26782,28041]
suite [26782,28041]
===
match
---
sync_comp_for [80935,80963]
sync_comp_for [80986,81014]
===
match
---
operator: , [79685,79686]
operator: , [79736,79737]
===
match
---
trailer [61865,61877]
trailer [61916,61928]
===
match
---
name: print [57529,57534]
name: print [57580,57585]
===
match
---
operator: = [44552,44553]
operator: = [44552,44553]
===
match
---
argument [55503,55524]
argument [55554,55575]
===
match
---
operator: = [46199,46200]
operator: = [46199,46200]
===
match
---
name: start_date [69131,69141]
name: start_date [69182,69192]
===
match
---
operator: = [63821,63822]
operator: = [63872,63873]
===
match
---
name: __table_args__ [85663,85677]
name: __table_args__ [85714,85728]
===
match
---
simple_stmt [53136,53385]
simple_stmt [53187,53436]
===
match
---
trailer [32543,32545]
trailer [32543,32545]
===
match
---
trailer [90657,90664]
trailer [90708,90715]
===
match
---
atom_expr [93198,93220]
atom_expr [93249,93271]
===
match
---
trailer [79528,79532]
trailer [79579,79583]
===
match
---
param [88177,88189]
param [88228,88240]
===
match
---
trailer [42112,42118]
trailer [42112,42118]
===
match
---
name: f_kwargs [93999,94007]
name: f_kwargs [94050,94058]
===
match
---
trailer [10858,10864]
trailer [10858,10864]
===
match
---
trailer [21787,21807]
trailer [21787,21807]
===
match
---
expr_stmt [14413,14451]
expr_stmt [14413,14451]
===
match
---
simple_stmt [39603,39818]
simple_stmt [39603,39818]
===
match
---
parameters [40409,40453]
parameters [40409,40453]
===
match
---
atom_expr [65344,65359]
atom_expr [65395,65410]
===
match
---
atom_expr [69639,69648]
atom_expr [69690,69699]
===
match
---
operator: = [75720,75721]
operator: = [75771,75772]
===
match
---
name: self [26067,26071]
name: self [26067,26071]
===
match
---
trailer [16838,16840]
trailer [16838,16840]
===
match
---
return_stmt [30850,30873]
return_stmt [30850,30873]
===
match
---
atom_expr [39647,39682]
atom_expr [39647,39682]
===
match
---
name: self [34803,34807]
name: self [34803,34807]
===
match
---
string: 'tree' [3002,3008]
string: 'tree' [3002,3008]
===
match
---
trailer [70282,70287]
trailer [70333,70338]
===
match
---
name: copied [61620,61626]
name: copied [61671,61677]
===
match
---
trailer [9898,9914]
trailer [9898,9914]
===
match
---
trailer [78837,78853]
trailer [78888,78904]
===
match
---
name: _description [12158,12170]
name: _description [12158,12170]
===
match
---
simple_stmt [26791,27289]
simple_stmt [26791,27289]
===
match
---
sync_comp_for [25165,25200]
sync_comp_for [25165,25200]
===
match
---
import_as_names [2496,2546]
import_as_names [2496,2546]
===
match
---
atom [78065,78071]
atom [78116,78122]
===
match
---
expr_stmt [30054,30077]
expr_stmt [30054,30077]
===
match
---
name: task_ids_or_regex [53203,53220]
name: task_ids_or_regex [53254,53271]
===
match
---
name: self [55429,55433]
name: self [55480,55484]
===
match
---
simple_stmt [76384,76422]
simple_stmt [76435,76473]
===
match
---
name: perm [18243,18247]
name: perm [18243,18247]
===
match
---
name: session [90042,90049]
name: session [90093,90100]
===
match
---
trailer [62537,62559]
trailer [62588,62610]
===
match
---
trailer [23242,23263]
trailer [23242,23263]
===
match
---
name: dag_id [45245,45251]
name: dag_id [45245,45251]
===
match
---
name: callback [34880,34888]
name: callback [34880,34888]
===
match
---
atom_expr [75802,75815]
atom_expr [75853,75866]
===
match
---
name: Optional [10469,10477]
name: Optional [10469,10477]
===
match
---
operator: = [26596,26597]
operator: = [26596,26597]
===
match
---
dictorsetmaker [31534,31561]
dictorsetmaker [31534,31561]
===
match
---
operator: @ [3716,3717]
operator: @ [3716,3717]
===
match
---
atom_expr [2861,2884]
atom_expr [2861,2884]
===
match
---
string: """         Returns a boolean indicating whether the concurrency limit for this DAG         has been reached         """ [31800,31920]
string: """         Returns a boolean indicating whether the concurrency limit for this DAG         has been reached         """ [31800,31920]
===
match
---
funcdef [18635,19015]
funcdef [18635,19015]
===
match
---
atom [64590,64607]
atom [64641,64658]
===
match
---
operator: { [11701,11702]
operator: { [11701,11702]
===
match
---
trailer [88535,88542]
trailer [88586,88593]
===
match
---
simple_stmt [78239,78296]
simple_stmt [78290,78347]
===
match
---
atom_expr [21301,21334]
atom_expr [21301,21334]
===
match
---
testlist_star_expr [91502,91549]
testlist_star_expr [91553,91600]
===
match
---
for_stmt [18135,18274]
for_stmt [18135,18274]
===
match
---
name: _description [29793,29805]
name: _description [29793,29805]
===
match
---
param [16551,16556]
param [16551,16556]
===
match
---
name: end_date [18738,18746]
name: end_date [18738,18746]
===
match
---
param [88020,88024]
param [88071,88075]
===
match
---
name: DagRun [1977,1983]
name: DagRun [1977,1983]
===
match
---
name: self [29788,29792]
name: self [29788,29792]
===
match
---
comparison [32744,32774]
comparison [32744,32774]
===
match
---
operator: @ [78957,78958]
operator: @ [79008,79009]
===
match
---
name: String [83349,83355]
name: String [83400,83406]
===
match
---
operator: == [22658,22660]
operator: == [22658,22660]
===
match
---
atom_expr [95737,95750]
atom_expr [95788,95801]
===
match
---
name: user_defined_macros [11508,11527]
name: user_defined_macros [11508,11527]
===
match
---
argument [74328,74349]
argument [74379,74400]
===
match
---
simple_stmt [95444,95479]
simple_stmt [95495,95530]
===
match
---
atom_expr [32069,32082]
atom_expr [32069,32082]
===
match
---
trailer [40649,40664]
trailer [40649,40664]
===
match
---
trailer [17369,17371]
trailer [17369,17371]
===
match
---
atom_expr [35327,35391]
atom_expr [35327,35391]
===
match
---
expr_stmt [72569,72583]
expr_stmt [72620,72634]
===
match
---
parameters [45972,46441]
parameters [45972,46441]
===
match
---
name: task [65535,65539]
name: task [65586,65590]
===
match
---
atom_expr [43456,43512]
atom_expr [43456,43512]
===
match
---
atom_expr [86727,86737]
atom_expr [86778,86788]
===
match
---
operator: , [91988,91989]
operator: , [92039,92040]
===
match
---
name: reason [34082,34088]
name: reason [34082,34088]
===
match
---
simple_stmt [50306,50354]
simple_stmt [50357,50405]
===
match
---
name: ti [35142,35144]
name: ti [35142,35144]
===
match
---
number: 1 [51853,51854]
number: 1 [51904,51905]
===
match
---
atom_expr [40281,40306]
atom_expr [40281,40306]
===
match
---
parameters [91067,91172]
parameters [91118,91223]
===
match
---
param [28469,28503]
param [28469,28503]
===
match
---
atom_expr [62727,62781]
atom_expr [62778,62832]
===
match
---
name: keys [81477,81481]
name: keys [81528,81532]
===
match
---
operator: , [10681,10682]
operator: , [10681,10682]
===
match
---
name: TI [50240,50242]
name: TI [50291,50293]
===
match
---
atom_expr [76275,76299]
atom_expr [76326,76350]
===
match
---
atom_expr [51419,51444]
atom_expr [51470,51495]
===
match
---
argument [56239,56256]
argument [56290,56307]
===
match
---
expr_stmt [13982,14026]
expr_stmt [13982,14026]
===
match
---
name: self [33237,33241]
name: self [33237,33241]
===
match
---
number: 2 [73113,73114]
number: 2 [73164,73165]
===
match
---
funcdef [64922,66479]
funcdef [64973,66530]
===
match
---
string: "Creating DagRun needs either `run_id` or both `run_type` and `execution_date`" [72045,72124]
string: "Creating DagRun needs either `run_id` or both `run_type` and `execution_date`" [72096,72175]
===
match
---
atom_expr [62266,62292]
atom_expr [62317,62343]
===
match
---
name: self [20351,20355]
name: self [20351,20355]
===
match
---
name: provide_session [87026,87041]
name: provide_session [87077,87092]
===
match
---
atom_expr [74059,74116]
atom_expr [74110,74167]
===
match
---
dotted_name [1901,1925]
dotted_name [1901,1925]
===
match
---
operator: = [65695,65696]
operator: = [65746,65747]
===
match
---
name: access_control [29512,29526]
name: access_control [29512,29526]
===
match
---
trailer [41379,41403]
trailer [41379,41403]
===
match
---
suite [30599,30691]
suite [30599,30691]
===
match
---
name: session [75333,75340]
name: session [75384,75391]
===
match
---
operator: , [57980,57981]
operator: , [58031,58032]
===
match
---
atom_expr [71625,71637]
atom_expr [71676,71688]
===
match
---
name: dag_id [3473,3479]
name: dag_id [3473,3479]
===
match
---
argument [74094,74109]
argument [74145,74160]
===
match
---
atom_expr [76781,76815]
atom_expr [76832,76866]
===
match
---
arglist [58404,58557]
arglist [58455,58608]
===
match
---
name: DeprecationWarning [73070,73088]
name: DeprecationWarning [73121,73139]
===
match
---
atom_expr [49316,49341]
atom_expr [49367,49392]
===
match
---
name: EdgeInfoType [2629,2641]
name: EdgeInfoType [2629,2641]
===
match
---
atom_expr [69077,69630]
atom_expr [69128,69681]
===
match
---
suite [29166,29202]
suite [29166,29202]
===
match
---
simple_stmt [12106,12144]
simple_stmt [12106,12144]
===
match
---
operator: , [88469,88470]
operator: , [88520,88521]
===
match
---
name: self [37626,37630]
name: self [37626,37630]
===
match
---
name: Dict [10425,10429]
name: Dict [10425,10429]
===
match
---
name: handle_callback [34038,34053]
name: handle_callback [34038,34053]
===
match
---
arglist [28817,28904]
arglist [28817,28904]
===
match
---
name: dag [61340,61343]
name: dag [61391,61394]
===
match
---
atom_expr [50449,50470]
atom_expr [50500,50521]
===
match
---
funcdef [16606,17116]
funcdef [16606,17116]
===
match
---
name: Dict [15438,15442]
name: Dict [15438,15442]
===
match
---
name: dag [79763,79766]
name: dag [79814,79817]
===
match
---
name: self [65697,65701]
name: self [65748,65752]
===
match
---
suite [50497,50554]
suite [50548,50605]
===
match
---
name: is_paused [90686,90695]
name: is_paused [90737,90746]
===
match
---
atom_expr [16051,16067]
atom_expr [16051,16067]
===
match
---
operator: = [56125,56126]
operator: = [56176,56177]
===
match
---
suite [19562,20796]
suite [19562,20796]
===
match
---
param [67110,67135]
param [67161,67186]
===
match
---
simple_stmt [31800,31921]
simple_stmt [31800,31921]
===
match
---
argument [83968,83997]
argument [84019,84048]
===
match
---
trailer [31974,31998]
trailer [31974,31998]
===
match
---
name: x [80773,80774]
name: x [80824,80825]
===
match
---
name: self [15065,15069]
name: self [15065,15069]
===
match
---
name: verbose [69497,69504]
name: verbose [69548,69555]
===
match
---
name: provide_session [37816,37831]
name: provide_session [37816,37831]
===
match
---
operator: = [54152,54153]
operator: = [54203,54204]
===
match
---
argument [54210,54249]
argument [54261,54300]
===
match
---
expr_stmt [84658,84685]
expr_stmt [84709,84736]
===
match
---
name: using_start_date [27423,27439]
name: using_start_date [27423,27439]
===
match
---
operator: , [70254,70255]
operator: , [70305,70306]
===
match
---
name: dag_tag_orm [77380,77391]
name: dag_tag_orm [77431,77442]
===
match
---
simple_stmt [55768,55781]
simple_stmt [55819,55832]
===
match
---
testlist_comp [25152,25200]
testlist_comp [25152,25200]
===
match
---
atom_expr [88458,88469]
atom_expr [88509,88520]
===
match
---
trailer [80856,80860]
trailer [80907,80911]
===
match
---
name: isinstance [41562,41572]
name: isinstance [41562,41572]
===
match
---
name: end_date [26217,26225]
name: end_date [26217,26225]
===
match
---
name: upstream_task_ids [62380,62397]
name: upstream_task_ids [62431,62448]
===
match
---
name: dag_id [48942,48948]
name: dag_id [48942,48948]
===
match
---
trailer [35418,35445]
trailer [35418,35445]
===
match
---
trailer [74566,74605]
trailer [74617,74656]
===
match
---
name: get_last_dagrun [86875,86890]
name: get_last_dagrun [86926,86941]
===
match
---
name: self [29549,29553]
name: self [29549,29553]
===
match
---
name: utcnow [63713,63719]
name: utcnow [63764,63770]
===
match
---
name: dag [95196,95199]
name: dag [95247,95250]
===
match
---
operator: { [45239,45240]
operator: { [45239,45240]
===
match
---
trailer [31649,31673]
trailer [31649,31673]
===
match
---
name: self [11900,11904]
name: self [11900,11904]
===
match
---
operator: = [83975,83976]
operator: = [84026,84027]
===
match
---
name: self [65344,65348]
name: self [65395,65399]
===
match
---
trailer [53472,53478]
trailer [53523,53529]
===
match
---
operator: = [73836,73837]
operator: = [73887,73888]
===
match
---
trailer [77102,77107]
trailer [77153,77158]
===
match
---
simple_stmt [28514,28648]
simple_stmt [28514,28648]
===
match
---
trailer [65534,65568]
trailer [65585,65619]
===
match
---
atom_expr [45055,45131]
atom_expr [45055,45131]
===
match
---
name: full_filepath [29237,29250]
name: full_filepath [29237,29250]
===
match
---
decorated [31569,31709]
decorated [31569,31709]
===
match
---
name: schedule_interval [33956,33973]
name: schedule_interval [33956,33973]
===
match
---
name: catchup [14950,14957]
name: catchup [14950,14957]
===
match
---
name: dag [73799,73802]
name: dag [73850,73853]
===
match
---
operator: , [26082,26083]
operator: , [26082,26083]
===
match
---
name: warnings [18340,18348]
name: warnings [18340,18348]
===
match
---
name: paused_dag_id [87547,87560]
name: paused_dag_id [87598,87611]
===
match
---
name: getattr [16882,16889]
name: getattr [16882,16889]
===
match
---
if_stmt [71524,71641]
if_stmt [71575,71692]
===
match
---
not_test [40825,40839]
not_test [40825,40839]
===
match
---
subscriptlist [22185,22241]
subscriptlist [22185,22241]
===
match
---
trailer [55190,55200]
trailer [55241,55251]
===
match
---
arglist [84056,84078]
arglist [84107,84129]
===
match
---
operator: { [9666,9667]
operator: { [9666,9667]
===
match
---
return_stmt [62962,62972]
return_stmt [63013,63023]
===
match
---
expr_stmt [39425,39451]
expr_stmt [39425,39451]
===
match
---
name: TaskInstance [42263,42275]
name: TaskInstance [42263,42275]
===
match
---
operator: = [72152,72153]
operator: = [72203,72204]
===
match
---
trailer [49178,49188]
trailer [49178,49188]
===
match
---
trailer [49119,49123]
trailer [49119,49123]
===
match
---
name: subdags [63293,63300]
name: subdags [63344,63351]
===
match
---
name: tis [48962,48965]
name: tis [48962,48965]
===
match
---
suite [12603,12834]
suite [12603,12834]
===
match
---
trailer [10821,10825]
trailer [10821,10825]
===
match
---
name: dag [74488,74491]
name: dag [74539,74542]
===
match
---
trailer [75433,75451]
trailer [75484,75502]
===
match
---
simple_stmt [2665,2712]
simple_stmt [2665,2712]
===
match
---
simple_stmt [61064,61115]
simple_stmt [61115,61166]
===
match
---
name: self [59724,59728]
name: self [59775,59779]
===
match
---
or_test [27527,27562]
or_test [27527,27562]
===
match
---
simple_stmt [44870,44903]
simple_stmt [44870,44903]
===
match
---
operator: = [90988,90989]
operator: = [91039,91040]
===
match
---
name: Column [83654,83660]
name: Column [83705,83711]
===
match
---
name: only_running [56315,56327]
name: only_running [56366,56378]
===
match
---
trailer [76160,76168]
trailer [76211,76219]
===
match
---
expr_stmt [27423,27501]
expr_stmt [27423,27501]
===
match
---
simple_stmt [77062,77109]
simple_stmt [77113,77160]
===
match
---
trailer [66270,66274]
trailer [66321,66325]
===
match
---
subscriptlist [15443,15460]
subscriptlist [15443,15460]
===
match
---
operator: , [32082,32083]
operator: , [32082,32083]
===
match
---
expr_stmt [93653,93679]
expr_stmt [93704,93730]
===
match
---
name: super [85984,85989]
name: super [86035,86040]
===
match
---
name: set [51041,51044]
name: set [51092,51095]
===
match
---
suite [16859,16905]
suite [16859,16905]
===
match
---
name: DAG [93471,93474]
name: DAG [93522,93525]
===
match
---
name: total_ordering [3727,3741]
name: total_ordering [3727,3741]
===
match
---
name: t [62819,62820]
name: t [62870,62871]
===
match
---
expr_stmt [36229,36389]
expr_stmt [36229,36389]
===
match
---
string: 'user_defined_macros' [81716,81737]
string: 'user_defined_macros' [81767,81788]
===
match
---
simple_stmt [24587,24628]
simple_stmt [24587,24628]
===
match
---
name: state [41806,41811]
name: state [41806,41811]
===
match
---
name: update [45878,45884]
name: update [45878,45884]
===
match
---
operator: , [57617,57618]
operator: , [57668,57669]
===
match
---
operator: , [9953,9954]
operator: , [9953,9954]
===
match
---
trailer [78287,78293]
trailer [78338,78344]
===
match
---
return_stmt [29366,29390]
return_stmt [29366,29390]
===
match
---
suite [70349,72748]
suite [70400,72799]
===
match
---
name: _access_control [15814,15829]
name: _access_control [15814,15829]
===
match
---
name: State [46235,46240]
name: State [46235,46240]
===
match
---
string: 'fetch' [88712,88719]
string: 'fetch' [88763,88770]
===
match
---
atom_expr [18971,19004]
atom_expr [18971,19004]
===
match
---
simple_stmt [95046,95089]
simple_stmt [95097,95140]
===
match
---
name: UPSTREAM_FAILED [50455,50470]
name: UPSTREAM_FAILED [50506,50521]
===
match
---
name: task_dict [59712,59721]
name: task_dict [59763,59772]
===
match
---
operator: = [28704,28705]
operator: = [28704,28705]
===
match
---
name: timezone [12888,12896]
name: timezone [12888,12896]
===
match
---
string: "Dag start date: %s. Next run date: %s" [26026,26065]
string: "Dag start date: %s. Next run date: %s" [26026,26065]
===
match
---
suite [80718,81207]
suite [80769,81258]
===
match
---
name: timezone [21793,21801]
name: timezone [21793,21801]
===
match
---
operator: = [11424,11425]
operator: = [11424,11425]
===
match
---
name: self [66441,66445]
name: self [66492,66496]
===
match
---
trailer [48617,48621]
trailer [48617,48621]
===
match
---
operator: , [76763,76764]
operator: , [76814,76815]
===
match
---
name: is_ [75584,75587]
name: is_ [75635,75638]
===
match
---
suite [30841,30874]
suite [30841,30874]
===
match
---
atom [41952,41975]
atom [41952,41975]
===
match
---
simple_stmt [39324,39358]
simple_stmt [39324,39358]
===
match
---
atom_expr [74917,74952]
atom_expr [74968,75003]
===
match
---
funcdef [60885,61853]
funcdef [60936,61904]
===
match
---
simple_stmt [1767,1808]
simple_stmt [1767,1808]
===
match
---
trailer [45600,45607]
trailer [45600,45607]
===
match
---
name: AttributeError [30614,30628]
name: AttributeError [30614,30628]
===
match
---
decorators [86439,86474]
decorators [86490,86525]
===
match
---
name: normalized_schedule_interval [21306,21334]
name: normalized_schedule_interval [21306,21334]
===
match
---
name: execution_date [3666,3680]
name: execution_date [3666,3680]
===
match
---
name: t [60168,60169]
name: t [60219,60220]
===
match
---
atom_expr [36526,36540]
atom_expr [36526,36540]
===
match
---
name: task_group [62067,62077]
name: task_group [62118,62128]
===
match
---
name: self [38116,38120]
name: self [38116,38120]
===
match
---
string: "\n" [54936,54940]
string: "\n" [54987,54991]
===
match
---
comparison [41116,41157]
comparison [41116,41157]
===
match
---
import_from [1466,1508]
import_from [1466,1508]
===
match
---
trailer [41786,41812]
trailer [41786,41812]
===
match
---
string: 'end_date' [13033,13043]
string: 'end_date' [13033,13043]
===
match
---
string: " " [64591,64594]
string: " " [64642,64645]
===
match
---
atom_expr [62471,62496]
atom_expr [62522,62547]
===
match
---
name: session [89898,89905]
name: session [89949,89956]
===
match
---
name: next_start [24643,24653]
name: next_start [24643,24653]
===
match
---
name: ti_key [51114,51120]
name: ti_key [51165,51171]
===
match
---
name: run_id [71487,71493]
name: run_id [71538,71544]
===
match
---
tfpdef [62997,63009]
tfpdef [63048,63060]
===
match
---
name: node [45075,45079]
name: node [45075,45079]
===
match
---
atom_expr [77247,77286]
atom_expr [77298,77337]
===
match
---
trailer [60067,60073]
trailer [60118,60124]
===
match
---
atom_expr [77095,77107]
atom_expr [77146,77158]
===
match
---
trailer [53478,54416]
trailer [53529,54467]
===
match
---
name: self [11855,11859]
name: self [11855,11859]
===
match
---
atom_expr [56583,56602]
atom_expr [56634,56653]
===
match
---
name: task_type [38986,38995]
name: task_type [38986,38995]
===
match
---
funcdef [92757,94244]
funcdef [92808,94295]
===
match
---
decorated [64793,64917]
decorated [64844,64968]
===
match
---
arith_expr [63704,63728]
arith_expr [63755,63779]
===
match
---
operator: , [85726,85727]
operator: , [85777,85778]
===
match
---
parameters [39185,39191]
parameters [39185,39191]
===
match
---
operator: @ [33190,33191]
operator: @ [33190,33191]
===
match
---
argument [55577,55596]
argument [55628,55647]
===
match
---
not_test [73691,73699]
not_test [73742,73750]
===
match
---
simple_stmt [19321,19353]
simple_stmt [19321,19353]
===
match
---
atom_expr [84931,84943]
atom_expr [84982,84994]
===
match
---
simple_stmt [56824,56871]
simple_stmt [56875,56922]
===
match
---
simple_stmt [27736,27838]
simple_stmt [27736,27838]
===
match
---
atom_expr [13562,13618]
atom_expr [13562,13618]
===
match
---
operator: , [45012,45013]
operator: , [45012,45013]
===
match
---
name: self [69936,69940]
name: self [69987,69991]
===
match
---
name: List [42355,42359]
name: List [42355,42359]
===
match
---
operator: = [83879,83880]
operator: = [83930,83931]
===
match
---
operator: = [54360,54361]
operator: = [54411,54412]
===
match
---
operator: , [66931,66932]
operator: , [66982,66983]
===
match
---
trailer [53229,53237]
trailer [53280,53288]
===
match
---
atom_expr [16882,16904]
atom_expr [16882,16904]
===
match
---
comp_op [57873,57879]
comp_op [57924,57930]
===
match
---
expr_stmt [94290,94309]
expr_stmt [94341,94360]
===
match
---
atom_expr [46235,46248]
atom_expr [46235,46248]
===
match
---
operator: , [19305,19306]
operator: , [19305,19306]
===
match
---
atom_expr [77368,77392]
atom_expr [77419,77443]
===
match
---
name: add [64292,64295]
name: add [64343,64346]
===
match
---
name: value [29257,29262]
name: value [29257,29262]
===
match
---
expr_stmt [62794,62875]
expr_stmt [62845,62926]
===
match
---
atom_expr [42355,42373]
atom_expr [42355,42373]
===
match
---
name: dag [91083,91086]
name: dag [91134,91137]
===
match
---
name: t [60786,60787]
name: t [60837,60838]
===
match
---
name: recursion_depth [54153,54168]
name: recursion_depth [54204,54219]
===
match
---
expr_stmt [94310,94357]
expr_stmt [94361,94408]
===
match
---
name: execution_date [37662,37676]
name: execution_date [37662,37676]
===
match
---
name: query [88596,88601]
name: query [88647,88652]
===
match
---
simple_stmt [89877,89886]
simple_stmt [89928,89937]
===
match
---
name: end_date [65901,65909]
name: end_date [65952,65960]
===
match
---
operator: * [58284,58285]
operator: * [58335,58336]
===
match
---
name: timezone [13562,13570]
name: timezone [13562,13570]
===
match
---
funcdef [40726,42317]
funcdef [40726,42317]
===
match
---
name: other [16488,16493]
name: other [16488,16493]
===
match
---
suite [71555,71641]
suite [71606,71692]
===
match
---
name: jinja_env_options [39872,39889]
name: jinja_env_options [39872,39889]
===
match
---
fstring_end: " [16160,16161]
fstring_end: " [16160,16161]
===
match
---
operator: = [50394,50395]
operator: = [50445,50446]
===
match
---
name: start_date [50261,50271]
name: start_date [50312,50322]
===
match
---
trailer [10343,10359]
trailer [10343,10359]
===
match
---
atom_expr [76588,76606]
atom_expr [76639,76657]
===
match
---
simple_stmt [85257,85340]
simple_stmt [85308,85391]
===
match
---
atom_expr [91114,91141]
atom_expr [91165,91192]
===
match
---
operator: == [52592,52594]
operator: == [52643,52645]
===
match
---
operator: , [57977,57978]
operator: , [58028,58029]
===
match
---
trailer [77253,77286]
trailer [77304,77337]
===
match
---
operator: = [56171,56172]
operator: = [56222,56223]
===
match
---
dotted_name [68709,68734]
dotted_name [68760,68785]
===
match
---
operator: , [65909,65910]
operator: , [65960,65961]
===
match
---
atom_expr [80621,80698]
atom_expr [80672,80749]
===
match
---
name: isinstance [38809,38819]
name: isinstance [38809,38819]
===
match
---
atom_expr [66463,66477]
atom_expr [66514,66528]
===
match
---
fstring_string: , but get  [14898,14908]
fstring_string: , but get  [14898,14908]
===
match
---
trailer [39057,39064]
trailer [39057,39064]
===
match
---
atom_expr [33668,33690]
atom_expr [33668,33690]
===
match
---
raise_stmt [66102,66191]
raise_stmt [66153,66242]
===
match
---
name: arguments [93960,93969]
name: arguments [94011,94020]
===
match
---
tfpdef [10691,10726]
tfpdef [10691,10726]
===
match
---
name: full_filepath [29139,29152]
name: full_filepath [29139,29152]
===
match
---
name: last_parsed_time [79707,79723]
name: last_parsed_time [79758,79774]
===
match
---
operator: , [85440,85441]
operator: , [85491,85492]
===
match
---
trailer [64261,64271]
trailer [64312,64322]
===
match
---
trailer [75398,75609]
trailer [75449,75660]
===
match
---
param [10194,10230]
param [10194,10230]
===
match
---
trailer [25338,25344]
trailer [25338,25344]
===
match
---
trailer [50606,50614]
trailer [50657,50665]
===
match
---
atom_expr [78722,78741]
atom_expr [78773,78792]
===
match
---
expr_stmt [50510,50553]
expr_stmt [50561,50604]
===
match
---
name: tasks [60068,60073]
name: tasks [60119,60124]
===
match
---
atom [48766,48768]
atom [48766,48768]
===
match
---
simple_stmt [74776,75199]
simple_stmt [74827,75250]
===
match
---
operator: , [86669,86670]
operator: , [86720,86721]
===
match
---
name: bool [31786,31790]
name: bool [31786,31790]
===
match
---
atom_expr [24933,24948]
atom_expr [24933,24948]
===
match
---
operator: = [66457,66458]
operator: = [66508,66509]
===
match
---
operator: = [56999,57000]
operator: = [57050,57051]
===
match
---
name: visited_external_tis [50133,50153]
name: visited_external_tis [50184,50204]
===
match
---
name: tis [50587,50590]
name: tis [50638,50641]
===
match
---
name: include_subdag_tasks [42825,42845]
name: include_subdag_tasks [42825,42845]
===
match
---
name: recursion_depth [54137,54152]
name: recursion_depth [54188,54203]
===
match
---
comparison [63167,63192]
comparison [63218,63243]
===
match
---
param [78419,78434]
param [78470,78485]
===
match
---
string: """Folder location of where the DAG object is instantiated.""" [31191,31253]
string: """Folder location of where the DAG object is instantiated.""" [31191,31253]
===
match
---
name: self [23297,23301]
name: self [23297,23301]
===
match
---
name: set_dag_runs_state [45321,45339]
name: set_dag_runs_state [45321,45339]
===
match
---
name: min [25291,25294]
name: min [25291,25294]
===
match
---
decorated [38488,39154]
decorated [38488,39154]
===
match
---
name: DagModel [78800,78808]
name: DagModel [78851,78859]
===
match
---
name: is_fixed_time_schedule [19024,19046]
name: is_fixed_time_schedule [19024,19046]
===
match
---
operator: , [60105,60106]
operator: , [60156,60157]
===
match
---
suite [32628,32821]
suite [32628,32821]
===
match
---
exprlist [18139,18150]
exprlist [18139,18150]
===
match
---
name: info [73733,73737]
name: info [73784,73788]
===
match
---
operator: , [70148,70149]
operator: , [70199,70200]
===
match
---
name: on_success_callback [11021,11040]
name: on_success_callback [11021,11040]
===
match
---
name: _context_managed_dag [95222,95242]
name: _context_managed_dag [95273,95293]
===
match
---
simple_stmt [86868,87002]
simple_stmt [86919,87053]
===
match
---
simple_stmt [64312,64350]
simple_stmt [64363,64401]
===
match
---
operator: , [52702,52703]
operator: , [52753,52754]
===
match
---
simple_stmt [53049,53108]
simple_stmt [53100,53159]
===
match
---
trailer [42596,42610]
trailer [42596,42610]
===
match
---
name: creating_job_id [72468,72483]
name: creating_job_id [72519,72534]
===
match
---
expr_stmt [73869,74039]
expr_stmt [73920,74090]
===
match
---
trailer [78064,78081]
trailer [78115,78132]
===
match
---
atom_expr [31001,31059]
atom_expr [31001,31059]
===
match
---
trailer [48982,48995]
trailer [48982,48995]
===
match
---
param [66856,66870]
param [66907,66921]
===
match
---
name: run_backwards [69592,69605]
name: run_backwards [69643,69656]
===
match
---
trailer [63607,63613]
trailer [63658,63664]
===
match
---
expr_stmt [14309,14351]
expr_stmt [14309,14351]
===
match
---
operator: { [87546,87547]
operator: { [87597,87598]
===
match
---
trailer [80631,80698]
trailer [80682,80749]
===
match
---
atom_expr [58686,58724]
atom_expr [58737,58775]
===
match
---
trailer [16079,16091]
trailer [16079,16091]
===
match
---
name: list [77140,77144]
name: list [77191,77195]
===
match
---
trailer [74930,74934]
trailer [74981,74985]
===
match
---
trailer [77470,77478]
trailer [77521,77529]
===
match
---
name: session [54606,54613]
name: session [54657,54664]
===
match
---
simple_stmt [76434,76484]
simple_stmt [76485,76535]
===
match
---
simple_stmt [69677,69718]
simple_stmt [69728,69769]
===
match
---
name: get_tis [46303,46310]
name: get_tis [46303,46310]
===
match
---
name: is_active [89818,89827]
name: is_active [89869,89878]
===
match
---
atom_expr [52403,52424]
atom_expr [52454,52475]
===
match
---
name: dttm [63554,63558]
name: dttm [63605,63609]
===
match
---
suite [67171,69649]
suite [67222,69700]
===
match
---
trailer [66413,66417]
trailer [66464,66468]
===
match
---
operator: , [9802,9803]
operator: , [9802,9803]
===
match
---
fstring_end: " [86360,86361]
fstring_end: " [86411,86412]
===
match
---
argument [28847,28904]
argument [28847,28904]
===
match
---
trailer [31027,31059]
trailer [31027,31059]
===
match
---
name: including_subdags [88145,88162]
name: including_subdags [88196,88213]
===
match
---
name: question [57025,57033]
name: question [57076,57084]
===
match
---
param [77805,77817]
param [77856,77868]
===
match
---
name: query [36927,36932]
name: query [36927,36932]
===
match
---
name: upstream_task_ids [62406,62423]
name: upstream_task_ids [62457,62474]
===
match
---
name: start_date [72276,72286]
name: start_date [72327,72337]
===
match
---
arglist [12858,12874]
arglist [12858,12874]
===
match
---
name: filter [50316,50322]
name: filter [50367,50373]
===
match
---
expr_stmt [75754,75786]
expr_stmt [75805,75837]
===
match
---
name: self [40410,40414]
name: self [40410,40414]
===
match
---
name: do_it [55213,55218]
name: do_it [55264,55269]
===
match
---
name: most_recent_dag_run [91573,91592]
name: most_recent_dag_run [91624,91643]
===
match
---
operator: = [29108,29109]
operator: = [29108,29109]
===
match
---
trailer [48971,48978]
trailer [48971,48978]
===
match
---
name: task [64665,64669]
name: task [64716,64720]
===
match
---
decorated [95145,95363]
decorated [95196,95414]
===
match
---
simple_stmt [36229,36390]
simple_stmt [36229,36390]
===
match
---
expr_stmt [62704,62781]
expr_stmt [62755,62832]
===
match
---
atom_expr [63332,63345]
atom_expr [63383,63396]
===
match
---
string: 'user_defined_filters' [57904,57926]
string: 'user_defined_filters' [57955,57977]
===
match
---
name: default [30435,30442]
name: default [30435,30442]
===
match
---
name: session [80473,80480]
name: session [80524,80531]
===
match
---
atom_expr [91552,91593]
atom_expr [91603,91644]
===
match
---
trailer [80772,80799]
trailer [80823,80850]
===
match
---
trailer [24900,24911]
trailer [24900,24911]
===
match
---
name: value [32795,32800]
name: value [32795,32800]
===
match
---
trailer [15813,15829]
trailer [15813,15829]
===
match
---
name: include_externally_triggered [28609,28637]
name: include_externally_triggered [28609,28637]
===
match
---
name: SubDagOperator [38826,38840]
name: SubDagOperator [38826,38840]
===
match
---
name: cls [95332,95335]
name: cls [95383,95386]
===
match
---
trailer [81049,81053]
trailer [81100,81104]
===
match
---
simple_stmt [12066,12098]
simple_stmt [12066,12098]
===
match
---
name: copy [11635,11639]
name: copy [11635,11639]
===
match
---
name: fileloc [75907,75914]
name: fileloc [75958,75965]
===
match
---
atom [48640,48642]
atom [48640,48642]
===
match
---
operator: , [10302,10303]
operator: , [10302,10303]
===
match
---
name: TaskInstance [80498,80510]
name: TaskInstance [80549,80561]
===
match
---
name: session [77653,77660]
name: session [77704,77711]
===
match
---
atom_expr [50835,50844]
atom_expr [50886,50895]
===
match
---
trailer [32794,32800]
trailer [32794,32800]
===
match
---
argument [50014,50053]
argument [50065,50104]
===
match
---
name: task [64614,64618]
name: task [64665,64669]
===
match
---
simple_stmt [64831,64867]
simple_stmt [64882,64918]
===
match
---
name: include_externally_triggered [86823,86851]
name: include_externally_triggered [86874,86902]
===
match
---
operator: -> [29755,29757]
operator: -> [29755,29757]
===
match
---
operator: = [2859,2860]
operator: = [2859,2860]
===
match
---
atom_expr [95490,95524]
atom_expr [95541,95575]
===
match
---
name: expiration_date [79022,79037]
name: expiration_date [79073,79088]
===
match
---
name: next_run_date [25844,25857]
name: next_run_date [25844,25857]
===
match
---
operator: = [75890,75891]
operator: = [75941,75942]
===
match
---
atom_expr [91969,91988]
atom_expr [92020,92039]
===
match
---
number: 0 [76813,76814]
number: 0 [76864,76865]
===
match
---
string: 'parent_dag' [81505,81517]
string: 'parent_dag' [81556,81568]
===
match
---
name: self [25174,25178]
name: self [25174,25178]
===
match
---
atom_expr [69988,70006]
atom_expr [70039,70057]
===
match
---
operator: , [83122,83123]
operator: , [83173,83174]
===
match
---
name: str [21043,21046]
name: str [21043,21046]
===
match
---
trailer [40323,40331]
trailer [40323,40331]
===
match
---
atom [74543,74545]
atom [74594,74596]
===
match
---
name: task [51499,51503]
name: task [51550,51554]
===
match
---
operator: = [73112,73113]
operator: = [73163,73164]
===
match
---
atom_expr [41608,41647]
atom_expr [41608,41647]
===
match
---
sync_comp_for [54954,54966]
sync_comp_for [55005,55017]
===
match
---
name: query [90604,90609]
name: query [90655,90660]
===
match
---
suite [43624,43664]
suite [43624,43664]
===
match
---
name: classmethod [88761,88772]
name: classmethod [88812,88823]
===
match
---
suite [89940,89990]
suite [89991,90041]
===
match
---
atom_expr [40665,40698]
atom_expr [40665,40698]
===
match
---
argument [18914,18935]
argument [18914,18935]
===
match
---
parameters [29059,29077]
parameters [29059,29077]
===
match
---
simple_stmt [51965,52379]
simple_stmt [52016,52430]
===
match
---
name: datetime [19343,19351]
name: datetime [19343,19351]
===
match
---
param [9949,9954]
param [9949,9954]
===
match
---
operator: , [46434,46435]
operator: , [46434,46435]
===
match
---
name: list [30525,30529]
name: list [30525,30529]
===
match
---
name: get_last_dagrun [3162,3177]
name: get_last_dagrun [3162,3177]
===
match
---
name: next_dagrun_create_after [90769,90793]
name: next_dagrun_create_after [90820,90844]
===
match
---
trailer [76118,76128]
trailer [76169,76179]
===
match
---
param [62991,62996]
param [63042,63047]
===
match
---
trailer [62271,62292]
trailer [62322,62343]
===
match
---
name: Optional [95737,95745]
name: Optional [95788,95796]
===
match
---
name: subdag_task_groups [62227,62245]
name: subdag_task_groups [62278,62296]
===
match
---
atom_expr [10114,10132]
atom_expr [10114,10132]
===
match
---
name: dag_id [35651,35657]
name: dag_id [35651,35657]
===
match
---
string: "@once" [23060,23067]
string: "@once" [23060,23067]
===
match
---
arglist [38268,38424]
arglist [38268,38424]
===
match
---
atom_expr [14114,14130]
atom_expr [14114,14130]
===
match
---
trailer [55757,55759]
trailer [55808,55810]
===
match
---
name: utcnow [24512,24518]
name: utcnow [24512,24518]
===
match
---
operator: { [53093,53094]
operator: { [53144,53145]
===
match
---
operator: = [2999,3000]
operator: = [2999,3000]
===
match
---
name: all [80769,80772]
name: all [80820,80823]
===
match
---
trailer [50439,50445]
trailer [50490,50496]
===
match
---
operator: , [88175,88176]
operator: , [88226,88227]
===
match
---
expr_stmt [93287,93346]
expr_stmt [93338,93397]
===
match
---
trailer [52535,52551]
trailer [52586,52602]
===
match
---
name: DateTime [22159,22167]
name: DateTime [22159,22167]
===
match
---
name: List [88851,88855]
name: List [88902,88906]
===
match
---
name: existing_dag_ids [74935,74951]
name: existing_dag_ids [74986,75002]
===
match
---
simple_stmt [27321,27351]
simple_stmt [27321,27351]
===
match
---
operator: { [82780,82781]
operator: { [82831,82832]
===
match
---
strings [14807,14922]
strings [14807,14922]
===
match
---
trailer [37996,38000]
trailer [37996,38000]
===
match
---
name: access_control [17507,17521]
name: access_control [17507,17521]
===
match
---
if_stmt [88489,88580]
if_stmt [88540,88631]
===
match
---
simple_stmt [25941,25998]
simple_stmt [25941,25998]
===
match
---
name: get_task [40623,40631]
name: get_task [40623,40631]
===
match
---
name: orm_dag [74165,74172]
name: orm_dag [74216,74223]
===
match
---
operator: = [38421,38422]
operator: = [38421,38422]
===
match
---
name: self [35863,35867]
name: self [35863,35867]
===
match
---
trailer [61400,61408]
trailer [61451,61459]
===
match
---
name: self [20163,20167]
name: self [20163,20167]
===
match
---
operator: -> [22176,22178]
operator: -> [22176,22178]
===
match
---
argument [49360,49382]
argument [49411,49433]
===
match
---
name: __dict__ [57838,57846]
name: __dict__ [57889,57897]
===
match
---
name: delete [76960,76966]
name: delete [77011,77017]
===
match
---
trailer [49315,49342]
trailer [49366,49393]
===
match
---
atom_expr [39709,39732]
atom_expr [39709,39732]
===
match
---
name: Optional [29932,29940]
name: Optional [29932,29940]
===
match
---
name: tis [50306,50309]
name: tis [50357,50360]
===
match
---
name: traceback [63859,63868]
name: traceback [63910,63919]
===
match
---
operator: , [90747,90748]
operator: , [90798,90799]
===
match
---
name: in_timezone [21609,21620]
name: in_timezone [21609,21620]
===
match
---
trailer [25460,25488]
trailer [25460,25488]
===
match
---
expr_stmt [36444,36509]
expr_stmt [36444,36509]
===
match
---
name: dag_id [88047,88053]
name: dag_id [88098,88104]
===
match
---
name: all_tis [56861,56868]
name: all_tis [56912,56919]
===
match
---
atom_expr [29549,29569]
atom_expr [29549,29569]
===
match
---
name: str [64610,64613]
name: str [64661,64664]
===
match
---
trailer [12826,12833]
trailer [12826,12833]
===
match
---
name: str [13857,13860]
name: str [13857,13860]
===
match
---
atom_expr [74212,74248]
atom_expr [74263,74299]
===
match
---
operator: , [28695,28696]
operator: , [28695,28696]
===
match
---
operator: @ [86762,86763]
operator: @ [86813,86814]
===
match
---
name: DagRun [75059,75065]
name: DagRun [75110,75116]
===
match
---
simple_stmt [21765,21808]
simple_stmt [21765,21808]
===
match
---
name: dag [95359,95362]
name: dag [95410,95413]
===
match
---
name: self [29871,29875]
name: self [29871,29875]
===
match
---
name: start [19464,19469]
name: start [19464,19469]
===
match
---
trailer [51498,51503]
trailer [51549,51554]
===
match
---
name: has_on_failure_callback [15707,15730]
name: has_on_failure_callback [15707,15730]
===
match
---
trailer [42275,42290]
trailer [42275,42290]
===
match
---
import_from [38667,38718]
import_from [38667,38718]
===
match
---
operator: , [88860,88861]
operator: , [88911,88912]
===
match
---
name: in_ [78834,78837]
name: in_ [78885,78888]
===
match
---
suite [25095,25395]
suite [25095,25395]
===
match
---
atom_expr [25291,25312]
atom_expr [25291,25312]
===
match
---
trailer [78915,78921]
trailer [78966,78972]
===
match
---
trailer [38819,38841]
trailer [38819,38841]
===
match
---
name: following_schedule [28196,28214]
name: following_schedule [28196,28214]
===
match
---
name: copied [61176,61182]
name: copied [61227,61233]
===
match
---
operator: , [11430,11431]
operator: , [11430,11431]
===
match
---
suite [61752,61826]
suite [61803,61877]
===
match
---
atom_expr [61092,61113]
atom_expr [61143,61164]
===
match
---
atom_expr [58377,58567]
atom_expr [58428,58618]
===
match
---
name: ti [51433,51435]
name: ti [51484,51486]
===
match
---
simple_stmt [84037,84080]
simple_stmt [84088,84131]
===
match
---
atom_expr [79675,79685]
atom_expr [79726,79736]
===
match
---
operator: , [56256,56257]
operator: , [56307,56308]
===
match
---
arglist [38820,38840]
arglist [38820,38840]
===
match
---
suite [22243,23265]
suite [22243,23265]
===
match
---
name: self [25267,25271]
name: self [25267,25271]
===
match
---
parameters [95412,95417]
parameters [95463,95468]
===
match
---
trailer [14500,14650]
trailer [14500,14650]
===
match
---
trailer [92065,92070]
trailer [92116,92121]
===
match
---
expr_stmt [66441,66478]
expr_stmt [66492,66529]
===
match
---
decorated [29895,29978]
decorated [29895,29978]
===
match
---
name: include_parentdag [56463,56480]
name: include_parentdag [56514,56531]
===
match
---
decorated [63904,64433]
decorated [63955,64484]
===
match
---
trailer [41867,41873]
trailer [41867,41873]
===
match
---
param [55987,56008]
param [56038,56059]
===
match
---
name: graph_sorted [45055,45067]
name: graph_sorted [45055,45067]
===
match
---
parameters [38513,38519]
parameters [38513,38519]
===
match
---
operator: = [25955,25956]
operator: = [25955,25956]
===
match
---
operator: , [56525,56526]
operator: , [56576,56577]
===
match
---
operator: = [57455,57456]
operator: = [57506,57507]
===
match
---
atom_expr [40866,40908]
atom_expr [40866,40908]
===
match
---
trailer [41618,41647]
trailer [41618,41647]
===
match
---
param [82403,82426]
param [82454,82477]
===
match
---
return_stmt [24134,24145]
return_stmt [24134,24145]
===
match
---
trailer [20738,20753]
trailer [20738,20753]
===
match
---
name: dag_id [49072,49078]
name: dag_id [49072,49078]
===
match
---
operator: = [46167,46168]
operator: = [46167,46168]
===
match
---
operator: = [58752,58753]
operator: = [58803,58804]
===
match
---
name: dp [64430,64432]
name: dp [64481,64483]
===
match
---
name: user_defined_filters [11586,11606]
name: user_defined_filters [11586,11606]
===
match
---
name: self [13287,13291]
name: self [13287,13291]
===
match
---
atom_expr [63773,63790]
atom_expr [63824,63841]
===
match
---
except_clause [17004,17020]
except_clause [17004,17020]
===
match
---
operator: , [95194,95195]
operator: , [95245,95246]
===
match
---
decorator [55786,55799]
decorator [55837,55850]
===
match
---
expr_stmt [77233,77286]
expr_stmt [77284,77337]
===
match
---
name: only_running [50484,50496]
name: only_running [50535,50547]
===
match
---
name: active_dag_ids [78726,78740]
name: active_dag_ids [78777,78791]
===
match
---
operator: = [15731,15732]
operator: = [15731,15732]
===
match
---
trailer [65701,65710]
trailer [65752,65761]
===
match
---
dotted_name [3717,3741]
dotted_name [3717,3741]
===
match
---
suite [20835,22064]
suite [20835,22064]
===
match
---
operator: = [83544,83545]
operator: = [83595,83596]
===
match
---
trailer [30551,30553]
trailer [30551,30553]
===
match
---
name: task_ids [50565,50573]
name: task_ids [50616,50624]
===
match
---
operator: = [53591,53592]
operator: = [53642,53643]
===
match
---
name: get_parser [69790,69800]
name: get_parser [69841,69851]
===
match
---
return_stmt [18877,19014]
return_stmt [18877,19014]
===
match
---
atom_expr [10332,10360]
atom_expr [10332,10360]
===
match
---
name: date_last_automated_dagrun [25461,25487]
name: date_last_automated_dagrun [25461,25487]
===
match
---
simple_stmt [50223,50273]
simple_stmt [50274,50324]
===
match
---
atom_expr [64408,64413]
atom_expr [64459,64464]
===
match
---
expr_stmt [42000,42145]
expr_stmt [42000,42145]
===
match
---
name: t [60107,60108]
name: t [60158,60159]
===
match
---
trailer [57970,58005]
trailer [58021,58056]
===
match
---
param [60914,60926]
param [60965,60977]
===
match
---
argument [32476,32488]
argument [32476,32488]
===
match
---
name: or_ [48979,48982]
name: or_ [48979,48982]
===
match
---
arglist [73162,73175]
arglist [73213,73226]
===
match
---
expr_stmt [15149,15195]
expr_stmt [15149,15195]
===
match
---
trailer [49123,49138]
trailer [49123,49138]
===
match
---
name: query [36526,36531]
name: query [36526,36531]
===
match
---
operator: , [2045,2046]
operator: , [2045,2046]
===
match
---
arglist [86091,86116]
arglist [86142,86167]
===
match
---
name: self [29842,29846]
name: self [29842,29846]
===
match
---
operator: , [57282,57283]
operator: , [57333,57334]
===
match
---
name: self [49067,49071]
name: self [49067,49071]
===
match
---
operator: , [87578,87579]
operator: , [87629,87630]
===
match
---
name: print [55693,55698]
name: print [55744,55749]
===
match
---
name: end_date [13430,13438]
name: end_date [13430,13438]
===
match
---
atom [3001,3056]
atom [3001,3056]
===
match
---
name: num [18824,18827]
name: num [18824,18827]
===
match
---
expr_stmt [85611,85657]
expr_stmt [85662,85708]
===
match
---
name: filter_task_group [61880,61897]
name: filter_task_group [61931,61948]
===
match
---
operator: @ [29575,29576]
operator: @ [29575,29576]
===
match
---
name: classmethod [95146,95157]
name: classmethod [95197,95208]
===
match
---
trailer [83348,83408]
trailer [83399,83459]
===
match
---
return_stmt [3693,3713]
return_stmt [3693,3713]
===
match
---
trailer [62146,62148]
trailer [62197,62199]
===
match
---
name: following [28372,28381]
name: following [28372,28381]
===
match
---
comparison [19446,19474]
comparison [19446,19474]
===
match
---
operator: , [57926,57927]
operator: , [57977,57978]
===
match
---
operator: = [11183,11184]
operator: = [11183,11184]
===
match
---
trailer [62795,62816]
trailer [62846,62867]
===
match
---
param [91083,91092]
param [91134,91143]
===
match
---
operator: @ [78370,78371]
operator: @ [78421,78422]
===
match
---
atom_expr [65681,65694]
atom_expr [65732,65745]
===
match
---
operator: , [64905,64906]
operator: , [64956,64957]
===
match
---
simple_stmt [35486,35612]
simple_stmt [35486,35612]
===
match
---
name: k [57871,57872]
name: k [57922,57923]
===
match
---
operator: , [81847,81848]
operator: , [81898,81899]
===
match
---
argument [53203,53240]
argument [53254,53291]
===
match
---
name: dag_id [49057,49063]
name: dag_id [49057,49063]
===
match
---
operator: = [84150,84151]
operator: = [84201,84202]
===
match
---
name: dag [75802,75805]
name: dag [75853,75856]
===
match
---
comparison [19409,19441]
comparison [19409,19441]
===
match
---
name: session [72841,72848]
name: session [72892,72899]
===
match
---
atom [60161,60218]
atom [60212,60269]
===
match
---
operator: , [81764,81765]
operator: , [81815,81816]
===
match
---
atom_expr [39065,39076]
atom_expr [39065,39076]
===
match
---
name: self [39515,39519]
name: self [39515,39519]
===
match
---
trailer [21240,21251]
trailer [21240,21251]
===
match
---
trailer [25271,25290]
trailer [25271,25290]
===
match
---
name: start_date [55514,55524]
name: start_date [55565,55575]
===
match
---
trailer [10864,10866]
trailer [10864,10866]
===
match
---
name: session [36251,36258]
name: session [36251,36258]
===
match
---
atom_expr [76332,76352]
atom_expr [76383,76403]
===
match
---
operator: == [50909,50911]
operator: == [50960,50962]
===
match
---
return_stmt [81215,81234]
return_stmt [81266,81285]
===
match
---
name: tii [53527,53530]
name: tii [53578,53581]
===
match
---
atom_expr [36251,36379]
atom_expr [36251,36379]
===
match
---
atom_expr [77140,77154]
atom_expr [77191,77205]
===
match
---
param [10312,10386]
param [10312,10386]
===
match
---
atom_expr [39872,39927]
atom_expr [39872,39927]
===
match
---
trailer [87382,87389]
trailer [87433,87440]
===
match
---
expr_stmt [26578,26617]
expr_stmt [26578,26617]
===
match
---
name: self [63773,63777]
name: self [63824,63828]
===
match
---
argument [30424,30433]
argument [30424,30433]
===
match
---
name: DagModel [32801,32809]
name: DagModel [32801,32809]
===
match
---
arglist [90966,91028]
arglist [91017,91079]
===
match
---
atom_expr [79496,79514]
atom_expr [79547,79565]
===
match
---
trailer [21557,21566]
trailer [21557,21566]
===
match
---
trailer [16823,16833]
trailer [16823,16833]
===
match
---
trailer [16578,16585]
trailer [16578,16585]
===
match
---
operator: , [28578,28579]
operator: , [28578,28579]
===
match
---
simple_stmt [9869,9922]
simple_stmt [9869,9922]
===
match
---
trailer [80860,80866]
trailer [80911,80917]
===
match
---
name: d [63632,63633]
name: d [63683,63684]
===
match
---
name: pendulum [19917,19925]
name: pendulum [19917,19925]
===
match
---
operator: , [3096,3097]
operator: , [3096,3097]
===
match
---
param [29749,29753]
param [29749,29753]
===
match
---
name: include_subdags [53855,53870]
name: include_subdags [53906,53921]
===
match
---
operator: , [11011,11012]
operator: , [11011,11012]
===
match
---
dotted_name [64836,64854]
dotted_name [64887,64905]
===
match
---
name: self [19272,19276]
name: self [19272,19276]
===
match
---
suite [92500,94268]
suite [92551,94319]
===
match
---
name: dp [64296,64298]
name: dp [64347,64349]
===
match
---
funcdef [42798,45291]
funcdef [42798,45291]
===
match
---
name: next_run_date [27933,27946]
name: next_run_date [27933,27946]
===
match
---
name: self [13328,13332]
name: self [13328,13332]
===
match
---
name: dag_run_state [56498,56511]
name: dag_run_state [56549,56562]
===
match
---
expr_stmt [32707,32775]
expr_stmt [32707,32775]
===
match
---
expr_stmt [56660,56680]
expr_stmt [56711,56731]
===
match
---
simple_stmt [35132,35183]
simple_stmt [35132,35183]
===
match
---
name: ACTION_CAN_READ [17979,17994]
name: ACTION_CAN_READ [17979,17994]
===
match
---
name: name [20532,20536]
name: name [20532,20536]
===
match
---
arglist [77728,77756]
arglist [77779,77807]
===
match
---
name: minute [19435,19441]
name: minute [19435,19441]
===
match
---
expr_stmt [3105,3155]
expr_stmt [3105,3155]
===
match
---
trailer [52520,52527]
trailer [52571,52578]
===
match
---
operator: -> [30037,30039]
operator: -> [30037,30039]
===
match
---
string: 'start_date' [12752,12764]
string: 'start_date' [12752,12764]
===
match
---
name: group_id [61799,61807]
name: group_id [61850,61858]
===
match
---
operator: = [18722,18723]
operator: = [18722,18723]
===
match
---
atom_expr [90845,90873]
atom_expr [90896,90924]
===
match
---
arglist [71942,71966]
arglist [71993,72017]
===
match
---
funcdef [39159,39261]
funcdef [39159,39261]
===
match
---
atom_expr [91606,91625]
atom_expr [91657,91676]
===
match
---
name: include_parentdag [56445,56462]
name: include_parentdag [56496,56513]
===
match
---
operator: == [51555,51557]
operator: == [51606,51608]
===
match
---
simple_stmt [17537,17827]
simple_stmt [17537,17827]
===
match
---
operator: = [18945,18946]
operator: = [18945,18946]
===
match
---
suite [24912,24961]
suite [24912,24961]
===
match
---
name: conf [72358,72362]
name: conf [72409,72413]
===
match
---
name: pickle_id [29984,29993]
name: pickle_id [29984,29993]
===
match
---
atom_expr [63178,63192]
atom_expr [63229,63243]
===
match
---
simple_stmt [60941,61014]
simple_stmt [60992,61065]
===
match
---
suite [50377,50473]
suite [50428,50524]
===
match
---
trailer [77080,77085]
trailer [77131,77136]
===
match
---
simple_stmt [61379,61441]
simple_stmt [61430,61492]
===
match
---
simple_stmt [87907,87985]
simple_stmt [87958,88036]
===
match
---
operator: , [1095,1096]
operator: , [1095,1096]
===
match
---
funcdef [30893,31139]
funcdef [30893,31139]
===
match
---
fstring [53072,53106]
fstring [53123,53157]
===
match
---
name: warnings [38241,38249]
name: warnings [38241,38249]
===
match
---
name: d [75728,75729]
name: d [75779,75780]
===
match
---
name: start_date [26755,26765]
name: start_date [26755,26765]
===
match
---
atom_expr [63650,63662]
atom_expr [63701,63713]
===
match
---
simple_stmt [987,1017]
simple_stmt [987,1017]
===
match
---
name: upper [94341,94346]
name: upper [94392,94397]
===
match
---
trailer [22158,22167]
trailer [22158,22167]
===
match
---
annassign [71661,71706]
annassign [71712,71757]
===
match
---
funcdef [78087,78347]
funcdef [78138,78398]
===
match
---
name: self [78329,78333]
name: self [78380,78384]
===
match
---
trailer [65835,65844]
trailer [65886,65895]
===
match
---
operator: = [88869,88870]
operator: = [88920,88921]
===
match
---
name: upstream_task_id [82380,82396]
name: upstream_task_id [82431,82447]
===
match
---
name: start_date [65489,65499]
name: start_date [65540,65550]
===
match
---
name: Optional [10209,10217]
name: Optional [10209,10217]
===
match
---
trailer [20531,20536]
trailer [20531,20536]
===
match
---
expr_stmt [80985,81123]
expr_stmt [81036,81174]
===
match
---
name: _previous_context_managed_dags [95260,95290]
name: _previous_context_managed_dags [95311,95341]
===
match
---
trailer [48930,48937]
trailer [48930,48937]
===
match
---
operator: = [74797,74798]
operator: = [74848,74849]
===
match
---
trailer [28799,28918]
trailer [28799,28918]
===
match
---
name: cron_presets [2208,2220]
name: cron_presets [2208,2220]
===
match
---
expr_stmt [20495,20537]
expr_stmt [20495,20537]
===
match
---
name: dag_id [75984,75990]
name: dag_id [76035,76041]
===
match
---
simple_stmt [53413,54447]
simple_stmt [53464,54498]
===
match
---
name: session [86701,86708]
name: session [86752,86759]
===
match
---
suite [80889,81124]
suite [80940,81175]
===
match
---
name: Optional [23331,23339]
name: Optional [23331,23339]
===
match
---
atom_expr [86060,86076]
atom_expr [86111,86127]
===
match
---
name: dag_ids [87069,87076]
name: dag_ids [87120,87127]
===
match
---
simple_stmt [89898,89915]
simple_stmt [89949,89966]
===
match
---
name: rerun_failed_tasks [67110,67128]
name: rerun_failed_tasks [67161,67179]
===
match
---
simple_stmt [57755,57781]
simple_stmt [57806,57832]
===
match
---
name: get_run_dates [26735,26748]
name: get_run_dates [26735,26748]
===
match
---
name: bool [10954,10958]
name: bool [10954,10958]
===
match
---
name: functools [3717,3726]
name: functools [3717,3726]
===
match
---
funcdef [31324,31564]
funcdef [31324,31564]
===
match
---
name: back [12296,12300]
name: back [12296,12300]
===
match
---
fstring [63424,63451]
fstring [63475,63502]
===
match
---
operator: , [66797,66798]
operator: , [66848,66849]
===
match
---
simple_stmt [80985,81124]
simple_stmt [81036,81175]
===
match
---
name: dag_id [49321,49327]
name: dag_id [49372,49378]
===
match
---
atom_expr [62374,62397]
atom_expr [62425,62448]
===
match
---
name: only_failed [49600,49611]
name: only_failed [49651,49662]
===
match
---
operator: = [91550,91551]
operator: = [91601,91602]
===
match
---
decorator [29575,29598]
decorator [29575,29598]
===
match
---
trailer [32316,32321]
trailer [32316,32321]
===
match
---
trailer [10770,10780]
trailer [10770,10780]
===
match
---
simple_stmt [76153,76183]
simple_stmt [76204,76234]
===
match
---
trailer [24518,24520]
trailer [24518,24520]
===
match
---
name: _upgrade_outdated_dag_access_control [15836,15872]
name: _upgrade_outdated_dag_access_control [15836,15872]
===
match
---
trailer [71941,71967]
trailer [71992,72018]
===
match
---
atom_expr [71578,71640]
atom_expr [71629,71691]
===
match
---
expr_stmt [2887,2920]
expr_stmt [2887,2920]
===
match
---
name: query [74825,74830]
name: query [74876,74881]
===
match
---
fstring_expr [56942,56951]
fstring_expr [56993,57002]
===
match
---
name: self [29153,29157]
name: self [29153,29157]
===
match
---
name: Column [84244,84250]
name: Column [84295,84301]
===
match
---
name: filter [36342,36348]
name: filter [36342,36348]
===
match
---
name: bulk_write_to_db [73145,73161]
name: bulk_write_to_db [73196,73212]
===
match
---
atom_expr [61793,61807]
atom_expr [61844,61858]
===
match
---
parameters [83426,83432]
parameters [83477,83483]
===
match
---
trailer [37991,38024]
trailer [37991,38024]
===
match
---
expr_stmt [78874,78895]
expr_stmt [78925,78946]
===
match
---
param [66759,66775]
param [66810,66826]
===
match
---
operator: = [85140,85141]
operator: = [85191,85192]
===
match
---
atom_expr [51496,51503]
atom_expr [51547,51554]
===
match
---
trailer [18174,18176]
trailer [18174,18176]
===
match
---
name: self [28069,28073]
name: self [28069,28073]
===
match
---
name: dirname [31092,31099]
name: dirname [31092,31099]
===
match
---
name: template_searchpath [39468,39487]
name: template_searchpath [39468,39487]
===
match
---
simple_stmt [39937,39999]
simple_stmt [39937,39999]
===
match
---
name: default_args [13736,13748]
name: default_args [13736,13748]
===
match
---
name: self [13047,13051]
name: self [13047,13051]
===
match
---
atom_expr [48877,48905]
atom_expr [48877,48905]
===
match
---
comparison [49054,49078]
comparison [49054,49078]
===
match
---
trailer [87120,87125]
trailer [87171,87176]
===
match
---
atom_expr [77311,77343]
atom_expr [77362,77394]
===
match
---
name: orm_dag [76864,76871]
name: orm_dag [76915,76922]
===
match
---
operator: , [92156,92157]
operator: , [92207,92208]
===
match
---
name: warn [58386,58390]
name: warn [58437,58441]
===
match
---
name: UtcDateTime [84487,84498]
name: UtcDateTime [84538,84549]
===
match
---
name: tasks [30561,30566]
name: tasks [30561,30566]
===
match
---
raise_stmt [14767,14936]
raise_stmt [14767,14936]
===
match
---
trailer [33753,33757]
trailer [33753,33757]
===
match
---
atom_expr [74799,75198]
atom_expr [74850,75249]
===
match
---
name: fileloc [76161,76168]
name: fileloc [76212,76219]
===
match
---
simple_stmt [45177,45255]
simple_stmt [45177,45255]
===
match
---
operator: , [63106,63107]
operator: , [63157,63158]
===
match
---
operator: @ [31714,31715]
operator: @ [31714,31715]
===
match
---
return_stmt [16504,16528]
return_stmt [16504,16528]
===
match
---
name: dag [60724,60727]
name: dag [60775,60778]
===
match
---
name: Optional [11169,11177]
name: Optional [11169,11177]
===
match
---
operator: , [60000,60001]
operator: , [60051,60052]
===
match
---
operator: -> [29159,29161]
operator: -> [29159,29161]
===
match
---
trailer [38068,38070]
trailer [38068,38070]
===
match
---
name: __name__ [93337,93345]
name: __name__ [93388,93396]
===
match
---
name: permissions [18052,18063]
name: permissions [18052,18063]
===
match
---
string: '*' [75373,75376]
string: '*' [75424,75427]
===
match
---
atom_expr [70321,70334]
atom_expr [70372,70385]
===
match
---
simple_stmt [29643,29714]
simple_stmt [29643,29714]
===
match
---
operator: = [57140,57141]
operator: = [57191,57192]
===
match
---
operator: , [39806,39807]
operator: , [39806,39807]
===
match
---
name: dry_run [46258,46265]
name: dry_run [46258,46265]
===
match
---
name: dag [62578,62581]
name: dag [62629,62632]
===
match
---
operator: == [36362,36364]
operator: == [36362,36364]
===
match
---
atom_expr [33624,33663]
atom_expr [33624,33663]
===
match
---
param [10545,10603]
param [10545,10603]
===
match
---
simple_stmt [2253,2305]
simple_stmt [2253,2305]
===
match
---
name: paused_dag_ids [87529,87543]
name: paused_dag_ids [87580,87594]
===
match
---
string: """Returns a boolean indicating whether this DAG is paused""" [32637,32698]
string: """Returns a boolean indicating whether this DAG is paused""" [32637,32698]
===
match
---
param [73246,73270]
param [73297,73321]
===
match
---
name: Collection [73252,73262]
name: Collection [73303,73313]
===
match
---
atom_expr [44997,45029]
atom_expr [44997,45029]
===
match
---
atom_expr [76238,76255]
atom_expr [76289,76306]
===
match
---
name: execution_date [42276,42290]
name: execution_date [42276,42290]
===
match
---
string: 'start_date' [12533,12545]
string: 'start_date' [12533,12545]
===
match
---
param [29923,29927]
param [29923,29927]
===
match
---
name: airflow [68945,68952]
name: airflow [68996,69003]
===
match
---
trailer [93975,93977]
trailer [94026,94028]
===
match
---
operator: @ [32551,32552]
operator: @ [32551,32552]
===
match
---
string: 'graph' [3010,3017]
string: 'graph' [3010,3017]
===
match
---
with_stmt [93466,94146]
with_stmt [93517,94197]
===
match
---
atom_expr [35084,35091]
atom_expr [35084,35091]
===
match
---
name: do_it [55159,55164]
name: do_it [55210,55215]
===
match
---
name: all [54567,54570]
name: all [54618,54621]
===
match
---
name: self [32854,32858]
name: self [32854,32858]
===
match
---
param [45982,45987]
param [45982,45987]
===
match
---
name: dag_id [81461,81467]
name: dag_id [81512,81518]
===
match
---
name: self [83427,83431]
name: self [83478,83482]
===
match
---
simple_stmt [25421,25489]
simple_stmt [25421,25489]
===
match
---
operator: = [95135,95136]
operator: = [95186,95187]
===
match
---
name: self [86022,86026]
name: self [86073,86077]
===
match
---
arglist [16381,16394]
arglist [16381,16394]
===
match
---
atom_expr [32019,32028]
atom_expr [32019,32028]
===
match
---
trailer [11648,11668]
trailer [11648,11668]
===
match
---
operator: = [15991,15992]
operator: = [15991,15992]
===
match
---
string: """         Add a list of tasks to the DAG          :param tasks: a lit of tasks you want to add         :type tasks: list of tasks         """ [66520,66663]
string: """         Add a list of tasks to the DAG          :param tasks: a lit of tasks you want to add         :type tasks: list of tasks         """ [66571,66714]
===
match
---
argument [53274,53296]
argument [53325,53347]
===
match
---
name: next_run_date [27960,27973]
name: next_run_date [27960,27973]
===
match
---
trailer [80480,80486]
trailer [80531,80537]
===
match
---
param [30093,30098]
param [30093,30098]
===
match
---
name: self [30093,30097]
name: self [30093,30097]
===
match
---
name: d [75731,75732]
name: d [75782,75783]
===
match
---
name: bool [88164,88168]
name: bool [88215,88219]
===
match
---
comp_if [60074,60117]
comp_if [60125,60168]
===
match
---
trailer [85365,85390]
trailer [85416,85441]
===
match
---
atom_expr [25753,25768]
atom_expr [25753,25768]
===
match
---
name: f [93670,93671]
name: f [93721,93722]
===
match
---
if_stmt [23934,24007]
if_stmt [23934,24007]
===
match
---
simple_stmt [58215,58239]
simple_stmt [58266,58290]
===
match
---
name: self [24600,24604]
name: self [24600,24604]
===
match
---
name: matched_tasks [60837,60850]
name: matched_tasks [60888,60901]
===
match
---
atom_expr [3648,3688]
atom_expr [3648,3688]
===
match
---
operator: == [24079,24081]
operator: == [24079,24081]
===
match
---
name: dag [66271,66274]
name: dag [66322,66325]
===
match
---
trailer [26510,26519]
trailer [26510,26519]
===
match
---
trailer [40228,40236]
trailer [40228,40236]
===
match
---
expr_stmt [27510,27562]
expr_stmt [27510,27562]
===
match
---
name: self [14710,14714]
name: self [14710,14714]
===
match
---
name: warnings [32967,32975]
name: warnings [32967,32975]
===
match
---
expr_stmt [85345,85390]
expr_stmt [85396,85441]
===
match
---
operator: , [32043,32044]
operator: , [32043,32044]
===
match
---
trailer [88668,88678]
trailer [88719,88729]
===
match
---
trailer [83719,83735]
trailer [83770,83786]
===
match
---
name: dp [64247,64249]
name: dp [64298,64300]
===
match
---
arglist [82734,82754]
arglist [82785,82805]
===
match
---
atom_expr [27545,27562]
atom_expr [27545,27562]
===
match
---
atom_expr [57789,57803]
atom_expr [57840,57854]
===
match
---
atom_expr [41020,41239]
atom_expr [41020,41239]
===
match
---
operator: == [37013,37015]
operator: == [37013,37015]
===
match
---
param [26767,26780]
param [26767,26780]
===
match
---
argument [57304,57324]
argument [57355,57375]
===
match
---
atom [90612,90934]
atom [90663,90985]
===
match
---
name: datetime [40983,40991]
name: datetime [40983,40991]
===
match
---
atom [43537,43539]
atom [43537,43539]
===
match
---
name: tis [42000,42003]
name: tis [42000,42003]
===
match
---
operator: = [10727,10728]
operator: = [10727,10728]
===
match
---
name: datetime [951,959]
name: datetime [951,959]
===
match
---
or_test [64206,64233]
or_test [64257,64284]
===
match
---
name: root_dag_id [88552,88563]
name: root_dag_id [88603,88614]
===
match
---
decorated [42558,42793]
decorated [42558,42793]
===
match
---
atom_expr [78246,78295]
atom_expr [78297,78346]
===
match
---
name: sys [12250,12253]
name: sys [12250,12253]
===
match
---
name: self [14264,14268]
name: self [14264,14268]
===
match
---
name: timezone [41440,41448]
name: timezone [41440,41448]
===
match
---
atom_expr [24664,24709]
atom_expr [24664,24709]
===
match
---
param [45432,45470]
param [45432,45470]
===
match
---
name: filter [36458,36464]
name: filter [36458,36464]
===
match
---
operator: = [18970,18971]
operator: = [18970,18971]
===
match
---
name: end_date [69155,69163]
name: end_date [69206,69214]
===
match
---
atom_expr [10337,10359]
atom_expr [10337,10359]
===
match
---
trailer [76043,76054]
trailer [76094,76105]
===
match
---
suite [77155,77393]
suite [77206,77444]
===
match
---
name: append [44936,44942]
name: append [44936,44942]
===
match
---
name: String [83298,83304]
name: String [83349,83355]
===
match
---
name: parse [12728,12733]
name: parse [12728,12733]
===
match
---
simple_stmt [86258,86298]
simple_stmt [86309,86349]
===
match
---
name: include_subdags [57362,57377]
name: include_subdags [57413,57428]
===
match
---
name: child [61521,61526]
name: child [61572,61577]
===
match
---
expr_stmt [33930,33973]
expr_stmt [33930,33973]
===
match
---
trailer [75622,75631]
trailer [75673,75682]
===
match
---
name: orm_dag [76546,76553]
name: orm_dag [76597,76604]
===
match
---
name: tis [50312,50315]
name: tis [50363,50366]
===
match
---
simple_stmt [40225,40270]
simple_stmt [40225,40270]
===
match
---
simple_stmt [64423,64433]
simple_stmt [64474,64484]
===
match
---
name: Collection [72822,72832]
name: Collection [72873,72883]
===
match
---
name: f [93622,93623]
name: f [93673,93674]
===
match
---
name: tasks [31556,31561]
name: tasks [31556,31561]
===
match
---
trailer [75583,75587]
trailer [75634,75638]
===
match
---
dictorsetmaker [17923,18080]
dictorsetmaker [17923,18080]
===
match
---
suite [74451,74516]
suite [74502,74567]
===
match
---
name: next_run_date [25380,25393]
name: next_run_date [25380,25393]
===
match
---
trailer [52293,52302]
trailer [52344,52353]
===
match
---
simple_stmt [76199,76226]
simple_stmt [76250,76277]
===
match
---
operator: , [9777,9778]
operator: , [9777,9778]
===
match
---
name: only_failed [46067,46078]
name: only_failed [46067,46078]
===
match
---
operator: = [11269,11270]
operator: = [11269,11270]
===
match
---
expr_stmt [9869,9921]
expr_stmt [9869,9921]
===
match
---
trailer [39519,39539]
trailer [39519,39539]
===
match
---
arglist [88062,88076]
arglist [88113,88127]
===
match
---
comparison [37655,37690]
comparison [37655,37690]
===
match
---
atom_expr [16682,16693]
atom_expr [16682,16693]
===
match
---
atom_expr [89808,89827]
atom_expr [89859,89878]
===
match
---
name: most_recent_dag_run [91093,91112]
name: most_recent_dag_run [91144,91163]
===
match
---
trailer [55698,55733]
trailer [55749,55784]
===
match
---
name: session [74094,74101]
name: session [74145,74152]
===
match
---
param [69662,69666]
param [69713,69717]
===
match
---
atom_expr [12296,12319]
atom_expr [12296,12319]
===
match
---
name: filter [32737,32743]
name: filter [32737,32743]
===
match
---
suite [79545,79845]
suite [79596,79896]
===
match
---
atom_expr [40225,40269]
atom_expr [40225,40269]
===
match
---
funcdef [42336,42553]
funcdef [42336,42553]
===
match
---
operator: = [70092,70093]
operator: = [70143,70144]
===
match
---
name: now [19227,19230]
name: now [19227,19230]
===
match
---
operator: = [41474,41475]
operator: = [41474,41475]
===
match
---
comparison [16203,16228]
comparison [16203,16228]
===
match
---
simple_stmt [35023,35072]
simple_stmt [35023,35072]
===
match
---
name: clear [49491,49496]
name: clear [49542,49547]
===
match
---
atom_expr [32791,32820]
atom_expr [32791,32820]
===
match
---
trailer [93324,93346]
trailer [93375,93397]
===
match
---
and_test [12533,12602]
and_test [12533,12602]
===
match
---
name: self [25908,25912]
name: self [25908,25912]
===
match
---
operator: , [1085,1086]
operator: , [1085,1086]
===
match
---
name: models [1956,1962]
name: models [1956,1962]
===
match
---
not_test [17838,17856]
not_test [17838,17856]
===
match
---
trailer [30777,30782]
trailer [30777,30782]
===
match
---
trailer [82729,82733]
trailer [82780,82784]
===
match
---
name: datetime [21739,21747]
name: datetime [21739,21747]
===
match
---
operator: = [69130,69131]
operator: = [69181,69182]
===
match
---
simple_stmt [40320,40366]
simple_stmt [40320,40366]
===
match
---
atom_expr [95298,95322]
atom_expr [95349,95373]
===
match
---
name: sla_miss_callback [10743,10760]
name: sla_miss_callback [10743,10760]
===
match
---
trailer [39653,39670]
trailer [39653,39670]
===
match
---
argument [49796,49819]
argument [49847,49870]
===
match
---
name: access_control [18154,18168]
name: access_control [18154,18168]
===
match
---
name: task [42507,42511]
name: task [42507,42511]
===
match
---
atom_expr [40187,40211]
atom_expr [40187,40211]
===
match
---
expr_stmt [11677,11703]
expr_stmt [11677,11703]
===
match
---
name: tii [53094,53097]
name: tii [53145,53148]
===
match
---
atom_expr [13247,13276]
atom_expr [13247,13276]
===
match
---
name: all [79529,79532]
name: all [79580,79583]
===
match
---
name: next_run_date [25421,25434]
name: next_run_date [25421,25434]
===
match
---
name: task_dict [63336,63345]
name: task_dict [63387,63396]
===
match
---
atom_expr [93954,93977]
atom_expr [94005,94028]
===
match
---
name: group [62112,62117]
name: group [62163,62168]
===
match
---
simple_stmt [63591,63620]
simple_stmt [63642,63671]
===
match
---
tfpdef [69972,70006]
tfpdef [70023,70057]
===
match
---
name: result [57755,57761]
name: result [57806,57812]
===
match
---
name: start_date [46019,46029]
name: start_date [46019,46029]
===
match
---
name: debug [25339,25344]
name: debug [25339,25344]
===
match
---
comparison [64216,64233]
comparison [64267,64284]
===
match
---
expr_stmt [27736,27837]
expr_stmt [27736,27837]
===
match
---
name: in_timezone [20339,20350]
name: in_timezone [20339,20350]
===
match
---
simple_stmt [30608,30691]
simple_stmt [30608,30691]
===
match
---
name: allow_future_exec_dates [41380,41403]
name: allow_future_exec_dates [41380,41403]
===
match
---
name: self [12858,12862]
name: self [12858,12862]
===
match
---
operator: } [63494,63495]
operator: } [63545,63546]
===
match
---
comparison [26633,26666]
comparison [26633,26666]
===
match
---
name: session [40799,40806]
name: session [40799,40806]
===
match
---
simple_stmt [1714,1767]
simple_stmt [1714,1767]
===
match
---
operator: = [72414,72415]
operator: = [72465,72466]
===
match
---
trailer [59899,59909]
trailer [59950,59960]
===
match
---
name: parent_dag [14040,14050]
name: parent_dag [14040,14050]
===
match
---
atom_expr [12685,12716]
atom_expr [12685,12716]
===
match
---
operator: ** [58291,58293]
operator: ** [58342,58344]
===
match
---
name: rerun_failed_tasks [69541,69559]
name: rerun_failed_tasks [69592,69610]
===
match
---
name: dttm [20754,20758]
name: dttm [20754,20758]
===
match
---
import_as_names [2024,2067]
import_as_names [2024,2067]
===
match
---
param [92487,92498]
param [92538,92549]
===
match
---
operator: + [60851,60852]
operator: + [60902,60903]
===
match
---
if_stmt [65082,65569]
if_stmt [65133,65620]
===
match
---
name: get [10900,10903]
name: get [10900,10903]
===
match
---
operator: = [74317,74318]
operator: = [74368,74369]
===
match
---
name: dag_id [3483,3489]
name: dag_id [3483,3489]
===
match
---
simple_stmt [30518,30555]
simple_stmt [30518,30555]
===
match
---
simple_stmt [76275,76320]
simple_stmt [76326,76371]
===
match
---
name: full_filepath [29208,29221]
name: full_filepath [29208,29221]
===
match
---
trailer [61385,61394]
trailer [61436,61445]
===
match
---
expr_stmt [76199,76225]
expr_stmt [76250,76276]
===
match
---
operator: = [65529,65530]
operator: = [65580,65581]
===
match
---
atom_expr [12360,12383]
atom_expr [12360,12383]
===
match
---
name: tis [41476,41479]
name: tis [41476,41479]
===
match
---
name: next_run_date [27736,27749]
name: next_run_date [27736,27749]
===
match
---
name: is_paused_upon_creation [15928,15951]
name: is_paused_upon_creation [15928,15951]
===
match
---
name: copy [57982,57986]
name: copy [58033,58037]
===
match
---
name: end_date [56248,56256]
name: end_date [56299,56307]
===
match
---
name: dag [76752,76755]
name: dag [76803,76806]
===
match
---
string: 'dag' [85332,85337]
string: 'dag' [85383,85388]
===
match
---
trailer [32975,32980]
trailer [32975,32980]
===
match
---
atom [65938,66037]
atom [65989,66088]
===
match
---
name: tasks [43506,43511]
name: tasks [43506,43511]
===
match
---
operator: = [30070,30071]
operator: = [30070,30071]
===
match
---
operator: = [80989,80990]
operator: = [81040,81041]
===
match
---
trailer [57014,57024]
trailer [57065,57075]
===
match
---
param [18738,18787]
param [18738,18787]
===
match
---
trailer [32074,32082]
trailer [32074,32082]
===
match
---
operator: , [84063,84064]
operator: , [84114,84115]
===
match
---
suite [77429,77501]
suite [77480,77552]
===
match
---
suite [51877,52379]
suite [51928,52430]
===
match
---
parameters [16618,16624]
parameters [16618,16624]
===
match
---
return_stmt [23002,23021]
return_stmt [23002,23021]
===
match
---
name: root_dag_id [85715,85726]
name: root_dag_id [85766,85777]
===
match
---
name: state [41540,41545]
name: state [41540,41545]
===
match
---
name: self [20761,20765]
name: self [20761,20765]
===
match
---
simple_stmt [34977,35011]
simple_stmt [34977,35011]
===
match
---
name: airflow [1948,1955]
name: airflow [1948,1955]
===
match
---
funcdef [30578,30691]
funcdef [30578,30691]
===
match
---
simple_stmt [62471,62560]
simple_stmt [62522,62611]
===
match
---
expr_stmt [85508,85541]
expr_stmt [85559,85592]
===
match
---
param [70061,70099]
param [70112,70150]
===
match
---
name: dag_id [74009,74015]
name: dag_id [74060,74066]
===
match
---
atom_expr [81442,81484]
atom_expr [81493,81535]
===
match
---
suite [50877,54504]
suite [50928,54555]
===
match
---
simple_stmt [54926,54969]
simple_stmt [54977,55020]
===
match
---
trailer [39713,39732]
trailer [39713,39732]
===
match
---
name: c [16774,16775]
name: c [16774,16775]
===
match
---
trailer [73262,73269]
trailer [73313,73320]
===
match
---
fstring_end: " [71638,71639]
fstring_end: " [71689,71690]
===
match
---
name: DagModel [78818,78826]
name: DagModel [78869,78877]
===
match
---
expr_stmt [43522,43539]
expr_stmt [43522,43539]
===
match
---
trailer [33634,33663]
trailer [33634,33663]
===
match
---
name: normalized_schedule_interval [21013,21041]
name: normalized_schedule_interval [21013,21041]
===
match
---
name: hash_components [16634,16649]
name: hash_components [16634,16649]
===
match
---
name: level [64597,64602]
name: level [64648,64653]
===
match
---
trailer [17065,17070]
trailer [17065,17070]
===
match
---
fstring_end: ' [14921,14922]
fstring_end: ' [14921,14922]
===
match
---
name: self [19550,19554]
name: self [19550,19554]
===
match
---
operator: = [85424,85425]
operator: = [85475,85476]
===
match
---
trailer [2868,2876]
trailer [2868,2876]
===
match
---
atom_expr [87461,87489]
atom_expr [87512,87540]
===
match
---
operator: , [46399,46400]
operator: , [46399,46400]
===
match
---
name: timezone [40867,40875]
name: timezone [40867,40875]
===
match
---
comparison [22635,22668]
comparison [22635,22668]
===
match
---
name: self [30588,30592]
name: self [30588,30592]
===
match
---
expr_stmt [60724,60875]
expr_stmt [60775,60926]
===
match
---
name: subdag_task_groups [62335,62353]
name: subdag_task_groups [62386,62404]
===
match
---
name: is_subdag [49179,49188]
name: is_subdag [49179,49188]
===
match
---
funcdef [29135,29202]
funcdef [29135,29202]
===
match
---
param [37866,37871]
param [37866,37871]
===
match
---
name: models [1821,1827]
name: models [1821,1827]
===
match
---
expr_stmt [56824,56870]
expr_stmt [56875,56921]
===
match
---
number: 2 [32487,32488]
number: 2 [32487,32488]
===
match
---
name: date_range [18639,18649]
name: date_range [18639,18649]
===
match
---
atom_expr [76652,76830]
atom_expr [76703,76881]
===
match
---
name: timezone [24503,24511]
name: timezone [24503,24511]
===
match
---
name: normalized_schedule_interval [22034,22062]
name: normalized_schedule_interval [22034,22062]
===
match
---
atom_expr [37626,37637]
atom_expr [37626,37637]
===
match
---
expr_stmt [21717,21748]
expr_stmt [21717,21748]
===
match
---
string: '' [2877,2879]
string: '' [2877,2879]
===
match
---
funcdef [77784,78082]
funcdef [77835,78133]
===
match
---
name: self [61898,61902]
name: self [61949,61953]
===
match
---
operator: = [34088,34089]
operator: = [34088,34089]
===
match
---
name: include_externally_triggered [28711,28739]
name: include_externally_triggered [28711,28739]
===
match
---
operator: -> [31783,31785]
operator: -> [31783,31785]
===
match
---
name: DateTime [23349,23357]
name: DateTime [23349,23357]
===
match
---
name: Column [84670,84676]
name: Column [84721,84727]
===
match
---
trailer [61902,61914]
trailer [61953,61965]
===
match
---
number: 3 [18574,18575]
number: 3 [18574,18575]
===
match
---
trailer [56843,56870]
trailer [56894,56921]
===
match
---
param [28711,28744]
param [28711,28744]
===
match
---
name: Boolean [1336,1343]
name: Boolean [1336,1343]
===
match
---
name: run_id [71630,71636]
name: run_id [71681,71687]
===
match
---
trailer [13414,13429]
trailer [13414,13429]
===
match
---
name: dag_id [38039,38045]
name: dag_id [38039,38045]
===
match
---
name: NUM_DAGS_PER_DAGRUN_QUERY [90898,90923]
name: NUM_DAGS_PER_DAGRUN_QUERY [90949,90974]
===
match
---
name: on_failure_callback [11091,11110]
name: on_failure_callback [11091,11110]
===
match
---
name: qry [80827,80830]
name: qry [80878,80881]
===
match
---
simple_stmt [77442,77501]
simple_stmt [77493,77552]
===
match
---
operator: @ [17448,17449]
operator: @ [17448,17449]
===
match
---
name: qry [80985,80988]
name: qry [81036,81039]
===
match
---
atom [54992,55109]
atom [55043,55160]
===
match
---
name: first [86591,86596]
name: first [86642,86647]
===
match
---
decorator [86621,86638]
decorator [86672,86689]
===
match
---
name: dag_id [11950,11956]
name: dag_id [11950,11956]
===
match
---
name: self [30019,30023]
name: self [30019,30023]
===
match
---
operator: = [43454,43455]
operator: = [43454,43455]
===
match
---
simple_stmt [71572,71641]
simple_stmt [71623,71692]
===
match
---
if_stmt [17835,17882]
if_stmt [17835,17882]
===
match
---
name: _upstream_task_ids [62706,62724]
name: _upstream_task_ids [62757,62775]
===
match
---
name: alive_dag_filelocs [88831,88849]
name: alive_dag_filelocs [88882,88900]
===
match
---
trailer [65330,65341]
trailer [65381,65392]
===
match
---
string: """Returns dttm + interval unless dttm is first interval then it returns dttm""" [28090,28170]
string: """Returns dttm + interval unless dttm is first interval then it returns dttm""" [28090,28170]
===
match
---
operator: = [64910,64911]
operator: = [64961,64962]
===
match
---
atom_expr [32613,32627]
atom_expr [32613,32627]
===
match
---
dotted_name [2073,2089]
dotted_name [2073,2089]
===
match
---
atom_expr [66041,66053]
atom_expr [66092,66104]
===
match
---
atom_expr [19373,19396]
atom_expr [19373,19396]
===
match
---
expr_stmt [81416,82311]
expr_stmt [81467,82362]
===
match
---
param [46182,46205]
param [46182,46205]
===
match
---
operator: , [18575,18576]
operator: , [18575,18576]
===
match
---
fstring_expr [14908,14921]
fstring_expr [14908,14921]
===
match
---
if_stmt [54582,54651]
if_stmt [54633,54702]
===
match
---
name: Type [10332,10336]
name: Type [10332,10336]
===
match
---
simple_stmt [83699,83736]
simple_stmt [83750,83787]
===
match
---
import_as_names [1336,1404]
import_as_names [1336,1404]
===
match
---
trailer [60177,60183]
trailer [60228,60234]
===
match
---
name: session [64124,64131]
name: session [64175,64182]
===
match
---
name: self [63936,63940]
name: self [63987,63991]
===
match
---
trailer [77144,77154]
trailer [77195,77205]
===
match
---
trailer [39258,39260]
trailer [39258,39260]
===
match
---
import_name [842,855]
import_name [842,855]
===
match
---
funcdef [82356,82820]
funcdef [82407,82871]
===
match
---
string: 'kcah_acitats' [94320,94334]
string: 'kcah_acitats' [94371,94385]
===
match
---
name: child [61214,61219]
name: child [61265,61270]
===
match
---
name: getint [85874,85880]
name: getint [85925,85931]
===
match
---
atom_expr [75362,75377]
atom_expr [75413,75428]
===
match
---
sync_comp_for [26486,26519]
sync_comp_for [26486,26519]
===
match
---
trailer [20522,20531]
trailer [20522,20531]
===
match
---
arglist [40971,41002]
arglist [40971,41002]
===
match
---
name: conf [85869,85873]
name: conf [85920,85924]
===
match
---
atom_expr [81457,81475]
atom_expr [81508,81526]
===
match
---
expr_stmt [41838,41884]
expr_stmt [41838,41884]
===
match
---
trailer [94474,94489]
trailer [94525,94540]
===
match
---
trailer [70081,70091]
trailer [70132,70142]
===
match
---
simple_stmt [52449,52730]
simple_stmt [52500,52781]
===
match
---
name: self [14217,14221]
name: self [14217,14221]
===
match
---
operator: = [63648,63649]
operator: = [63699,63700]
===
match
---
if_stmt [77176,77393]
if_stmt [77227,77444]
===
match
---
expr_stmt [77062,77108]
expr_stmt [77113,77159]
===
match
---
operator: , [57461,57462]
operator: , [57512,57513]
===
match
---
operator: = [55359,55360]
operator: = [55410,55411]
===
match
---
try_stmt [2760,2885]
try_stmt [2760,2885]
===
match
---
expr_stmt [44835,44849]
expr_stmt [44835,44849]
===
match
---
arglist [78065,78080]
arglist [78116,78131]
===
match
---
name: dp [64408,64410]
name: dp [64459,64461]
===
match
---
trailer [34906,34910]
trailer [34906,34910]
===
match
---
name: utils [2318,2323]
name: utils [2318,2323]
===
match
---
trailer [32059,32065]
trailer [32059,32065]
===
match
---
trailer [29186,29201]
trailer [29186,29201]
===
match
---
simple_stmt [15779,15800]
simple_stmt [15779,15800]
===
match
---
trailer [73144,73161]
trailer [73195,73212]
===
match
---
atom_expr [85142,85160]
atom_expr [85193,85211]
===
match
---
name: state [55577,55582]
name: state [55628,55633]
===
match
---
trailer [35331,35335]
trailer [35331,35335]
===
match
---
atom_expr [16819,16840]
atom_expr [16819,16840]
===
match
---
operator: , [33657,33658]
operator: , [33657,33658]
===
match
---
parameters [40748,40812]
parameters [40748,40812]
===
match
---
atom_expr [10159,10177]
atom_expr [10159,10177]
===
match
---
atom_expr [42250,42297]
atom_expr [42250,42297]
===
match
---
name: str [60003,60006]
name: str [60054,60057]
===
match
---
atom_expr [70274,70287]
atom_expr [70325,70338]
===
match
---
decorated [72753,73177]
decorated [72804,73228]
===
match
---
name: DeprecationWarning [18527,18545]
name: DeprecationWarning [18527,18545]
===
match
---
trailer [58602,58619]
trailer [58653,58670]
===
match
---
if_stmt [20994,22064]
if_stmt [20994,22064]
===
match
---
atom_expr [10961,11011]
atom_expr [10961,11011]
===
match
---
name: query [3437,3442]
name: query [3437,3442]
===
match
---
trailer [41455,41457]
trailer [41455,41457]
===
match
---
operator: = [64250,64251]
operator: = [64301,64302]
===
match
---
operator: = [49528,49529]
operator: = [49579,49580]
===
match
---
name: DagRun [36961,36967]
name: DagRun [36961,36967]
===
match
---
atom_expr [49054,49063]
atom_expr [49054,49063]
===
match
---
arglist [55470,55630]
arglist [55521,55681]
===
match
---
name: in_ [75430,75433]
name: in_ [75481,75484]
===
match
---
or_test [24245,24294]
or_test [24245,24294]
===
match
---
name: make_aware [20575,20585]
name: make_aware [20575,20585]
===
match
---
operator: = [62817,62818]
operator: = [62868,62869]
===
match
---
name: get [78251,78254]
name: get [78302,78305]
===
match
---
name: self [33951,33955]
name: self [33951,33955]
===
match
---
fstring_start: f" [71835,71837]
fstring_start: f" [71886,71888]
===
match
---
parameters [66497,66510]
parameters [66548,66561]
===
match
---
name: timezone [86385,86393]
name: timezone [86436,86444]
===
match
---
operator: = [72848,72849]
operator: = [72899,72900]
===
match
---
trailer [48978,48996]
trailer [48978,48996]
===
match
---
operator: = [85061,85062]
operator: = [85112,85113]
===
match
---
simple_stmt [42728,42793]
simple_stmt [42728,42793]
===
match
---
comp_if [60184,60217]
comp_if [60235,60268]
===
match
---
name: old_dag [95679,95686]
name: old_dag [95730,95737]
===
match
---
name: self [13247,13251]
name: self [13247,13251]
===
match
---
name: dag_bag [52856,52863]
name: dag_bag [52907,52914]
===
match
---
atom_expr [31073,31120]
atom_expr [31073,31120]
===
match
---
atom_expr [22713,22735]
atom_expr [22713,22735]
===
match
---
operator: = [69496,69497]
operator: = [69547,69548]
===
match
---
name: session [77749,77756]
name: session [77800,77807]
===
match
---
name: __init__ [85992,86000]
name: __init__ [86043,86051]
===
match
---
name: self [66703,66707]
name: self [66754,66758]
===
match
---
simple_stmt [16938,16948]
simple_stmt [16938,16948]
===
match
---
atom_expr [32713,32775]
atom_expr [32713,32775]
===
match
---
operator: @ [89995,89996]
operator: @ [90046,90047]
===
match
---
name: previous_schedule [24605,24622]
name: previous_schedule [24605,24622]
===
match
---
trailer [10646,10681]
trailer [10646,10681]
===
match
---
operator: = [2891,2892]
operator: = [2891,2892]
===
match
---
atom_expr [83952,83998]
atom_expr [84003,84049]
===
match
---
name: session [35166,35173]
name: session [35166,35173]
===
match
---
suite [64571,64728]
suite [64622,64779]
===
match
---
name: end_date [65854,65862]
name: end_date [65905,65913]
===
match
---
name: Base [83170,83174]
name: Base [83221,83225]
===
match
---
name: Optional [18748,18756]
name: Optional [18748,18756]
===
match
---
simple_stmt [29281,29309]
simple_stmt [29281,29309]
===
match
---
name: t [60447,60448]
name: t [60498,60499]
===
match
---
name: cls [89312,89315]
name: cls [89363,89366]
===
match
---
trailer [3705,3711]
trailer [3705,3711]
===
match
---
trailer [59871,59880]
trailer [59922,59931]
===
match
---
trailer [76796,76800]
trailer [76847,76851]
===
match
---
name: has_on_success_callback [15631,15654]
name: has_on_success_callback [15631,15654]
===
match
---
atom_expr [93471,93521]
atom_expr [93522,93572]
===
match
---
atom [80928,80964]
atom [80979,81015]
===
match
---
operator: , [81794,81795]
operator: , [81845,81846]
===
match
---
operator: , [78266,78267]
operator: , [78317,78318]
===
match
---
param [16545,16550]
param [16545,16550]
===
match
---
operator: = [77076,77077]
operator: = [77127,77128]
===
match
---
suite [29533,29570]
suite [29533,29570]
===
match
---
trailer [59817,59829]
trailer [59868,59880]
===
match
---
simple_stmt [86694,86757]
simple_stmt [86745,86808]
===
match
---
atom [23197,23264]
atom [23197,23264]
===
match
---
name: List [30490,30494]
name: List [30490,30494]
===
match
---
return_stmt [29175,29201]
return_stmt [29175,29201]
===
match
---
name: operators [38680,38689]
name: operators [38680,38689]
===
match
---
trailer [36298,36328]
trailer [36298,36328]
===
match
---
operator: = [74101,74102]
operator: = [74152,74153]
===
match
---
import_name [817,831]
import_name [817,831]
===
match
---
trailer [52959,52966]
trailer [53010,53017]
===
match
---
operator: = [84047,84048]
operator: = [84098,84099]
===
match
---
name: self [14309,14313]
name: self [14309,14313]
===
match
---
name: backref [85316,85323]
name: backref [85367,85374]
===
match
---
trailer [64291,64295]
trailer [64342,64346]
===
match
---
operator: = [83652,83653]
operator: = [83703,83704]
===
match
---
trailer [92694,92719]
trailer [92745,92770]
===
match
---
suite [58301,58620]
suite [58352,58671]
===
match
---
argument [93497,93520]
argument [93548,93571]
===
match
---
name: success [34831,34838]
name: success [34831,34838]
===
match
---
operator: , [30023,30024]
operator: , [30023,30024]
===
match
---
name: recursion_depth [46326,46341]
name: recursion_depth [46326,46341]
===
match
---
suite [77045,77393]
suite [77096,77444]
===
match
---
atom_expr [15657,15681]
atom_expr [15657,15681]
===
match
---
operator: = [41426,41427]
operator: = [41426,41427]
===
match
---
comparison [65987,66027]
comparison [66038,66078]
===
match
---
trailer [61343,61353]
trailer [61394,61404]
===
match
---
testlist_comp [27467,27499]
testlist_comp [27467,27499]
===
match
---
name: Iterable [1116,1124]
name: Iterable [1116,1124]
===
match
---
operator: @ [29983,29984]
operator: @ [29983,29984]
===
match
---
param [79952,79964]
param [80003,80015]
===
match
---
name: children [61183,61191]
name: children [61234,61242]
===
match
---
dotted_name [1551,1572]
dotted_name [1551,1572]
===
match
---
simple_stmt [19910,19941]
simple_stmt [19910,19941]
===
match
---
sync_comp_for [18255,18272]
sync_comp_for [18255,18272]
===
match
---
name: scalar [36532,36538]
name: scalar [36532,36538]
===
match
---
return_stmt [18600,18629]
return_stmt [18600,18629]
===
match
---
expr_stmt [85841,85940]
expr_stmt [85892,85991]
===
match
---
funcdef [95385,95687]
funcdef [95436,95738]
===
match
---
suite [65313,65360]
suite [65364,65411]
===
match
---
name: task_id [61401,61408]
name: task_id [61452,61459]
===
match
---
operator: = [53348,53349]
operator: = [53399,53400]
===
match
---
name: dttm [19910,19914]
name: dttm [19910,19914]
===
match
---
atom_expr [41171,41228]
atom_expr [41171,41228]
===
match
---
operator: , [13855,13856]
operator: , [13855,13856]
===
match
---
trailer [32743,32775]
trailer [32743,32775]
===
match
---
name: end_date [18946,18954]
name: end_date [18946,18954]
===
match
---
name: self [57833,57837]
name: self [57884,57888]
===
match
---
name: staticmethod [17449,17461]
name: staticmethod [17449,17461]
===
match
---
name: states [80742,80748]
name: states [80793,80799]
===
match
---
operator: , [90706,90707]
operator: , [90757,90758]
===
match
---
string: "Please use 'can_read' and 'can_edit', respectively." [18456,18509]
string: "Please use 'can_read' and 'can_edit', respectively." [18456,18509]
===
match
---
trailer [75906,75914]
trailer [75957,75965]
===
match
---
string: 'last_loaded' [9843,9856]
string: 'last_loaded' [9843,9856]
===
match
---
operator: , [35867,35868]
operator: , [35867,35868]
===
match
---
name: Session [45408,45415]
name: Session [45408,45415]
===
match
---
name: or_ [88619,88622]
name: or_ [88670,88673]
===
match
---
file_input [788,95792]
file_input [788,95843]
===
match
---
atom_expr [18797,18811]
atom_expr [18797,18811]
===
match
---
atom_expr [62121,62148]
atom_expr [62172,62199]
===
match
---
simple_stmt [59861,59887]
simple_stmt [59912,59938]
===
match
---
name: default_args [11649,11661]
name: default_args [11649,11661]
===
match
---
suite [12897,12944]
suite [12897,12944]
===
match
---
name: t [60557,60558]
name: t [60608,60609]
===
match
---
name: val [16807,16810]
name: val [16807,16810]
===
match
---
name: f [93335,93336]
name: f [93386,93387]
===
match
---
name: self [22893,22897]
name: self [22893,22897]
===
match
---
name: normalized_schedule_interval [20035,20063]
name: normalized_schedule_interval [20035,20063]
===
match
---
operator: ** [85965,85967]
operator: ** [86016,86018]
===
match
---
name: start_date [70061,70071]
name: start_date [70112,70122]
===
match
---
operator: } [18125,18126]
operator: } [18125,18126]
===
match
---
trailer [28214,28220]
trailer [28214,28220]
===
match
---
name: datetime [10168,10176]
name: datetime [10168,10176]
===
match
---
arglist [13836,13860]
arglist [13836,13860]
===
match
---
name: concurrency [85345,85356]
name: concurrency [85396,85407]
===
match
---
dictorsetmaker [81505,82297]
dictorsetmaker [81556,82348]
===
match
---
atom_expr [26011,26098]
atom_expr [26011,26098]
===
match
---
dotted_name [2357,2388]
dotted_name [2357,2388]
===
match
---
expr_stmt [75833,75857]
expr_stmt [75884,75908]
===
match
---
atom_expr [63859,63881]
atom_expr [63910,63932]
===
match
---
name: __name__ [38933,38941]
name: __name__ [38933,38941]
===
match
---
parameters [79021,79052]
parameters [79072,79103]
===
match
---
trailer [28332,28343]
trailer [28332,28343]
===
match
---
name: backfill_job [68722,68734]
name: backfill_job [68773,68785]
===
match
---
trailer [12300,12307]
trailer [12300,12307]
===
match
---
trailer [37591,37756]
trailer [37591,37756]
===
match
---
trailer [90737,90741]
trailer [90788,90792]
===
match
---
parameters [17506,17527]
parameters [17506,17527]
===
match
---
funcdef [66484,66723]
funcdef [66535,66774]
===
match
---
simple_stmt [73134,73177]
simple_stmt [73185,73228]
===
match
---
name: __hash__ [16610,16618]
name: __hash__ [16610,16618]
===
match
---
name: upstream [60468,60476]
name: upstream [60519,60527]
===
match
---
string: 'webserver' [10904,10915]
string: 'webserver' [10904,10915]
===
match
---
expr_stmt [24933,24960]
expr_stmt [24933,24960]
===
match
---
operator: = [60159,60160]
operator: = [60210,60211]
===
match
---
atom_expr [54936,54968]
atom_expr [54987,55019]
===
match
---
not_test [65293,65312]
not_test [65344,65363]
===
match
---
tfpdef [10797,10814]
tfpdef [10797,10814]
===
match
---
decorated [3716,83155]
decorated [3716,83206]
===
match
---
trailer [79706,79723]
trailer [79757,79774]
===
match
---
argument [49518,49539]
argument [49569,49590]
===
match
---
param [28697,28710]
param [28697,28710]
===
match
---
name: datetime [40954,40962]
name: datetime [40954,40962]
===
match
---
atom_expr [13528,13559]
atom_expr [13528,13559]
===
match
---
trailer [15661,15681]
trailer [15661,15681]
===
match
---
simple_stmt [66703,66723]
simple_stmt [66754,66774]
===
match
---
operator: = [77812,77813]
operator: = [77863,77864]
===
match
---
name: task_id [41199,41206]
name: task_id [41199,41206]
===
match
---
atom_expr [29871,29889]
atom_expr [29871,29889]
===
match
---
name: _task_group [66062,66073]
name: _task_group [66113,66124]
===
match
---
atom [40866,40901]
atom [40866,40901]
===
match
---
name: path [31087,31091]
name: path [31087,31091]
===
match
---
name: Optional [95421,95429]
name: Optional [95472,95480]
===
match
---
trailer [63292,63300]
trailer [63343,63351]
===
match
---
if_stmt [13627,13762]
if_stmt [13627,13762]
===
match
---
expr_stmt [73828,73860]
expr_stmt [73879,73911]
===
match
---
trailer [21251,21272]
trailer [21251,21272]
===
match
---
trailer [86064,86076]
trailer [86115,86127]
===
match
---
operator: , [55844,55845]
operator: , [55895,55896]
===
match
---
trailer [95635,95656]
trailer [95686,95707]
===
match
---
number: 0 [2881,2882]
number: 0 [2881,2882]
===
match
---
trailer [69060,69062]
trailer [69111,69113]
===
match
---
name: query [45872,45877]
name: query [45872,45877]
===
match
---
trailer [20350,20365]
trailer [20350,20365]
===
match
---
trailer [56597,56602]
trailer [56648,56653]
===
match
---
name: setter [29591,29597]
name: setter [29591,29597]
===
match
---
simple_stmt [89808,89835]
simple_stmt [89859,89886]
===
match
---
if_stmt [80766,81124]
if_stmt [80817,81175]
===
match
---
for_stmt [66672,66723]
for_stmt [66723,66774]
===
match
---
simple_stmt [72690,72728]
simple_stmt [72741,72779]
===
match
---
trailer [58187,58201]
trailer [58238,58252]
===
match
---
argument [72206,72219]
argument [72257,72270]
===
match
---
name: executor [66856,66864]
name: executor [66907,66915]
===
match
---
trailer [77731,77739]
trailer [77782,77790]
===
match
---
atom_expr [76801,76811]
atom_expr [76852,76862]
===
match
---
simple_stmt [48962,48997]
simple_stmt [48962,48997]
===
match
---
operator: , [10653,10654]
operator: , [10653,10654]
===
match
---
if_stmt [44683,44748]
if_stmt [44683,44748]
===
match
---
operator: , [46293,46294]
operator: , [46293,46294]
===
match
---
name: delta [18965,18970]
name: delta [18965,18970]
===
match
---
name: t [41197,41198]
name: t [41197,41198]
===
match
---
name: log [63778,63781]
name: log [63829,63832]
===
match
---
operator: = [83711,83712]
operator: = [83762,83763]
===
match
---
name: execution_date [52687,52701]
name: execution_date [52738,52752]
===
match
---
trailer [22920,22948]
trailer [22920,22948]
===
match
---
trailer [11177,11182]
trailer [11177,11182]
===
match
---
trailer [36960,37031]
trailer [36960,37031]
===
match
---
simple_stmt [11677,11704]
simple_stmt [11677,11704]
===
match
---
suite [24296,25023]
suite [24296,25023]
===
match
---
name: cron_presets [33741,33753]
name: cron_presets [33741,33753]
===
match
---
atom_expr [75347,75360]
atom_expr [75398,75411]
===
match
---
atom_expr [48938,48948]
atom_expr [48938,48948]
===
match
---
name: session [45625,45632]
name: session [45625,45632]
===
match
---
name: task [66233,66237]
name: task [66284,66288]
===
match
---
string: """         Returns a list of dag run execution dates currently running          :return: List of execution dates         """ [35486,35611]
string: """         Returns a list of dag run execution dates currently running          :return: List of execution dates         """ [35486,35611]
===
match
---
trailer [62139,62146]
trailer [62190,62197]
===
match
---
expr_stmt [36896,37062]
expr_stmt [36896,37062]
===
match
---
atom_expr [26495,26505]
atom_expr [26495,26505]
===
match
---
name: bulk_sync_to_db [77450,77465]
name: bulk_sync_to_db [77501,77516]
===
match
---
trailer [61044,61051]
trailer [61095,61102]
===
match
---
comparison [65952,65982]
comparison [66003,66033]
===
match
---
name: first [3706,3711]
name: first [3706,3711]
===
match
---
name: String [84931,84937]
name: String [84982,84988]
===
match
---
name: self [17277,17281]
name: self [17277,17281]
===
match
---
name: has_task_concurrency_limits [86134,86161]
name: has_task_concurrency_limits [86185,86212]
===
match
---
name: self [58229,58233]
name: self [58280,58284]
===
match
---
name: pickled [63654,63661]
name: pickled [63705,63712]
===
match
---
simple_stmt [75947,76007]
simple_stmt [75998,76058]
===
match
---
comparison [74411,74450]
comparison [74462,74501]
===
match
---
name: or_ [81027,81030]
name: or_ [81078,81081]
===
match
---
atom_expr [16432,16443]
atom_expr [16432,16443]
===
match
---
string: """         Given a list of known DAGs, deactivate any other DAGs that are         marked as active in the ORM          :param active_dag_ids: list of DAG IDs that are active         :type active_dag_ids: list[unicode]         :return: None         """ [78458,78710]
string: """         Given a list of known DAGs, deactivate any other DAGs that are         marked as active in the ORM          :param active_dag_ids: list of DAG IDs that are active         :type active_dag_ids: list[unicode]         :return: None         """ [78509,78761]
===
match
---
name: role [18139,18143]
name: role [18139,18143]
===
match
---
operator: <= [25579,25581]
operator: <= [25579,25581]
===
match
---
simple_stmt [21537,21577]
simple_stmt [21537,21577]
===
match
---
name: croniter [1239,1247]
name: croniter [1239,1247]
===
match
---
operator: = [48764,48765]
operator: = [48764,48765]
===
match
---
trailer [89817,89827]
trailer [89868,89878]
===
match
---
operator: , [69172,69173]
operator: , [69223,69224]
===
match
---
simple_stmt [30145,30382]
simple_stmt [30145,30382]
===
match
---
simple_stmt [83530,83552]
simple_stmt [83581,83603]
===
match
---
simple_stmt [88588,88730]
simple_stmt [88639,88781]
===
match
---
operator: = [63491,63492]
operator: = [63542,63543]
===
match
---
simple_stmt [32200,32300]
simple_stmt [32200,32300]
===
match
---
name: schedule_interval [24266,24283]
name: schedule_interval [24266,24283]
===
match
---
atom_expr [73838,73860]
atom_expr [73889,73911]
===
match
---
operator: = [70179,70180]
operator: = [70230,70231]
===
match
---
string: "failed to invoke dag state update callback" [35346,35390]
string: "failed to invoke dag state update callback" [35346,35390]
===
match
---
name: DagRun [3426,3432]
name: DagRun [3426,3432]
===
match
---
trailer [23971,23981]
trailer [23971,23981]
===
match
---
name: params [11691,11697]
name: params [11691,11697]
===
match
---
del_stmt [44870,44902]
del_stmt [44870,44902]
===
match
---
param [40799,40811]
param [40799,40811]
===
match
---
suite [95435,95687]
suite [95486,95738]
===
match
---
trailer [89480,89488]
trailer [89531,89539]
===
match
---
comparison [66041,66088]
comparison [66092,66139]
===
match
---
name: conf [78246,78250]
name: conf [78297,78301]
===
match
---
name: TaskInstance [31934,31946]
name: TaskInstance [31934,31946]
===
match
---
operator: , [77803,77804]
operator: , [77854,77855]
===
match
---
string: '@once' [33857,33864]
string: '@once' [33857,33864]
===
match
---
name: tasks [43612,43617]
name: tasks [43612,43617]
===
match
---
atom_expr [25981,25996]
atom_expr [25981,25996]
===
match
---
name: in_ [42069,42072]
name: in_ [42069,42072]
===
match
---
trailer [63182,63192]
trailer [63233,63243]
===
match
---
name: sub_dag [58270,58277]
name: sub_dag [58321,58328]
===
match
---
atom_expr [11677,11688]
atom_expr [11677,11688]
===
match
---
operator: , [71950,71951]
operator: , [72001,72002]
===
match
---
tfpdef [88128,88143]
tfpdef [88179,88194]
===
match
---
parameters [85958,85974]
parameters [86009,86025]
===
match
---
atom_expr [66108,66191]
atom_expr [66159,66242]
===
match
---
name: start_date [40921,40931]
name: start_date [40921,40931]
===
match
---
atom_expr [60557,60572]
atom_expr [60608,60623]
===
match
---
arglist [71779,71799]
arglist [71830,71850]
===
match
---
name: rerun_failed_tasks [69560,69578]
name: rerun_failed_tasks [69611,69629]
===
match
---
name: filter [88612,88618]
name: filter [88663,88669]
===
match
---
simple_stmt [78908,78927]
simple_stmt [78959,78978]
===
match
---
comparison [41787,41796]
comparison [41787,41796]
===
match
---
number: 2000 [85009,85013]
number: 2000 [85060,85064]
===
match
---
name: DEPRECATED_ACTION_CAN_DAG_EDIT [18020,18050]
name: DEPRECATED_ACTION_CAN_DAG_EDIT [18020,18050]
===
match
---
name: used_group_ids [61498,61512]
name: used_group_ids [61549,61563]
===
match
---
name: previous [21593,21601]
name: previous [21593,21601]
===
match
---
name: self [30530,30534]
name: self [30530,30534]
===
match
---
name: has_dag_runs [28678,28690]
name: has_dag_runs [28678,28690]
===
match
---
name: self [23219,23223]
name: self [23219,23223]
===
match
---
name: args [69826,69830]
name: args [69877,69881]
===
match
---
name: DagCode [1843,1850]
name: DagCode [1843,1850]
===
match
---
trailer [26476,26485]
trailer [26476,26485]
===
match
---
operator: = [51784,51785]
operator: = [51835,51836]
===
match
---
atom_expr [61595,61627]
atom_expr [61646,61678]
===
match
---
operator: = [14437,14438]
operator: = [14437,14438]
===
match
---
operator: , [3084,3085]
operator: , [3084,3085]
===
match
---
name: start_date [18925,18935]
name: start_date [18925,18935]
===
match
---
trailer [74230,74248]
trailer [74281,74299]
===
match
---
simple_stmt [77233,77287]
simple_stmt [77284,77338]
===
match
---
parameters [18649,18793]
parameters [18649,18793]
===
match
---
name: external_task [50692,50705]
name: external_task [50743,50756]
===
match
---
tfpdef [10149,10177]
tfpdef [10149,10177]
===
match
---
name: co_filename [12308,12319]
name: co_filename [12308,12319]
===
match
---
comparison [76588,76618]
comparison [76639,76669]
===
match
---
name: filter [87454,87460]
name: filter [87505,87511]
===
match
---
operator: , [56221,56222]
operator: , [56272,56273]
===
match
---
name: _task_group [59818,59829]
name: _task_group [59869,59880]
===
match
---
name: memo [57619,57623]
name: memo [57670,57674]
===
match
---
operator: = [88169,88170]
operator: = [88220,88221]
===
match
---
decorator [78957,78971]
decorator [79008,79022]
===
match
---
name: min [65892,65895]
name: min [65943,65946]
===
match
---
trailer [64137,64148]
trailer [64188,64199]
===
match
---
operator: , [73269,73270]
operator: , [73320,73321]
===
match
---
name: session [55470,55477]
name: session [55521,55528]
===
match
---
funcdef [29328,29391]
funcdef [29328,29391]
===
match
---
name: access_control [18286,18300]
name: access_control [18286,18300]
===
match
---
name: is_paused [32844,32853]
name: is_paused [32844,32853]
===
match
---
param [72816,72840]
param [72867,72891]
===
match
---
expr_stmt [65876,65925]
expr_stmt [65927,65976]
===
match
---
name: provide_session [37092,37107]
name: provide_session [37092,37107]
===
match
---
trailer [63423,63452]
trailer [63474,63503]
===
match
---
funcdef [32161,32546]
funcdef [32161,32546]
===
match
---
name: property [31311,31319]
name: property [31311,31319]
===
match
---
trailer [3452,3458]
trailer [3452,3458]
===
match
---
atom_expr [87374,87389]
atom_expr [87425,87440]
===
match
---
operator: == [16776,16778]
operator: == [16776,16778]
===
match
---
suite [44717,44748]
suite [44717,44748]
===
match
---
param [87089,87112]
param [87140,87163]
===
match
---
funcdef [20801,22064]
funcdef [20801,22064]
===
match
---
name: update [39890,39896]
name: update [39890,39896]
===
match
---
simple_stmt [25782,25876]
simple_stmt [25782,25876]
===
match
---
name: DagRun [45886,45892]
name: DagRun [45886,45892]
===
match
---
testlist_comp [26475,26519]
testlist_comp [26475,26519]
===
match
---
funcdef [28972,29025]
funcdef [28972,29025]
===
match
---
name: f_kwargs [94136,94144]
name: f_kwargs [94187,94195]
===
match
---
operator: = [86816,86817]
operator: = [86867,86868]
===
match
---
name: self [23941,23945]
name: self [23941,23945]
===
match
---
name: schedule_interval [33673,33690]
name: schedule_interval [33673,33690]
===
match
---
argument [53709,53734]
argument [53760,53785]
===
match
---
atom_expr [56668,56680]
atom_expr [56719,56731]
===
match
---
name: d [63675,63676]
name: d [63726,63727]
===
match
---
simple_stmt [85508,85542]
simple_stmt [85559,85593]
===
match
---
name: Exception [89930,89939]
name: Exception [89981,89990]
===
match
---
atom_expr [32125,32141]
atom_expr [32125,32141]
===
match
---
dotted_name [2258,2276]
dotted_name [2258,2276]
===
match
---
tfpdef [82380,82401]
tfpdef [82431,82452]
===
match
---
atom_expr [60187,60196]
atom_expr [60238,60247]
===
match
---
suite [95243,95324]
suite [95294,95375]
===
match
---
atom_expr [49109,49138]
atom_expr [49109,49138]
===
match
---
argument [77254,77266]
argument [77305,77317]
===
match
---
operator: = [12017,12018]
operator: = [12017,12018]
===
match
---
atom_expr [2893,2920]
atom_expr [2893,2920]
===
match
---
atom_expr [82327,82350]
atom_expr [82378,82401]
===
match
---
parameters [69661,69667]
parameters [69712,69718]
===
match
---
trailer [55433,55452]
trailer [55484,55503]
===
match
---
simple_stmt [72544,72560]
simple_stmt [72595,72611]
===
match
---
name: str [33659,33662]
name: str [33659,33662]
===
match
---
operator: -> [33243,33245]
operator: -> [33243,33245]
===
match
---
name: t [39205,39206]
name: t [39205,39206]
===
match
---
name: group_by [75146,75154]
name: group_by [75197,75205]
===
match
---
name: getattr [16373,16380]
name: getattr [16373,16380]
===
match
---
trailer [76174,76182]
trailer [76225,76233]
===
match
---
atom_expr [53592,53610]
atom_expr [53643,53661]
===
match
---
operator: , [42088,42089]
operator: , [42088,42089]
===
match
---
name: states [80948,80954]
name: states [80999,81005]
===
match
---
operator: = [50227,50228]
operator: = [50278,50279]
===
match
---
param [91077,91082]
param [91128,91133]
===
match
---
name: s [41959,41960]
name: s [41959,41960]
===
match
---
name: pickled [63591,63598]
name: pickled [63642,63649]
===
match
---
trailer [45497,45507]
trailer [45497,45507]
===
match
---
name: commit [64370,64376]
name: commit [64421,64427]
===
match
---
if_stmt [14360,14651]
if_stmt [14360,14651]
===
match
---
fstring_start: f' [14518,14520]
fstring_start: f' [14518,14520]
===
match
---
operator: = [80471,80472]
operator: = [80522,80523]
===
match
---
decorator [86762,86779]
decorator [86813,86830]
===
match
---
trailer [54950,54953]
trailer [55001,55004]
===
match
---
funcdef [17466,18630]
funcdef [17466,18630]
===
match
---
operator: , [63940,63941]
operator: , [63991,63992]
===
match
---
expr_stmt [13390,13439]
expr_stmt [13390,13439]
===
match
---
simple_stmt [83284,83329]
simple_stmt [83335,83380]
===
match
---
operator: = [35092,35093]
operator: = [35092,35093]
===
match
---
name: signature [93088,93097]
name: signature [93139,93148]
===
match
---
name: orm_dag [74468,74475]
name: orm_dag [74519,74526]
===
match
---
for_stmt [50857,54504]
for_stmt [50908,54555]
===
match
---
classdef [94527,95792]
classdef [94578,95843]
===
match
---
expr_stmt [50223,50272]
expr_stmt [50274,50323]
===
match
---
name: tis [50396,50399]
name: tis [50447,50450]
===
match
---
name: run [72744,72747]
name: run [72795,72798]
===
match
---
string: 'params' [11793,11801]
string: 'params' [11793,11801]
===
match
---
name: add_task [64926,64934]
name: add_task [64977,64985]
===
match
---
name: cls [72811,72814]
name: cls [72862,72865]
===
match
---
suite [65500,65569]
suite [65551,65620]
===
match
---
annassign [14050,14072]
annassign [14050,14072]
===
match
---
suite [39315,40386]
suite [39315,40386]
===
match
---
operator: = [34075,34076]
operator: = [34075,34076]
===
match
---
name: Union [2941,2946]
name: Union [2941,2946]
===
match
---
trailer [34915,34964]
trailer [34915,34964]
===
match
---
operator: , [70294,70295]
operator: , [70345,70346]
===
match
---
simple_stmt [84305,84340]
simple_stmt [84356,84391]
===
match
---
name: start [19429,19434]
name: start [19429,19434]
===
match
---
trailer [78833,78837]
trailer [78884,78888]
===
match
---
name: log [91780,91783]
name: log [91831,91834]
===
match
---
name: mark_success [66807,66819]
name: mark_success [66858,66870]
===
match
---
expr_stmt [84914,84944]
expr_stmt [84965,84995]
===
match
---
suite [45795,45864]
suite [45795,45864]
===
match
---
number: 0 [46342,46343]
number: 0 [46342,46343]
===
match
---
name: property [28959,28967]
name: property [28959,28967]
===
match
---
simple_stmt [2409,2459]
simple_stmt [2409,2459]
===
match
---
name: verify_integrity [72694,72710]
name: verify_integrity [72745,72761]
===
match
---
suite [29772,29806]
suite [29772,29806]
===
match
---
operator: = [53659,53660]
operator: = [53710,53711]
===
match
---
name: self [36316,36320]
name: self [36316,36320]
===
match
---
import_from [2068,2108]
import_from [2068,2108]
===
match
---
name: parent_dag [75896,75906]
name: parent_dag [75947,75957]
===
match
---
argument [56200,56221]
argument [56251,56272]
===
match
---
trailer [63505,63521]
trailer [63556,63572]
===
match
---
trailer [50618,50628]
trailer [50669,50679]
===
match
---
simple_stmt [83333,83409]
simple_stmt [83384,83460]
===
match
---
decorator [28408,28425]
decorator [28408,28425]
===
match
---
funcdef [57596,58261]
funcdef [57647,58312]
===
match
---
simple_stmt [62794,62876]
simple_stmt [62845,62927]
===
match
---
name: copy [51409,51413]
name: copy [51460,51464]
===
match
---
tfpdef [11285,11324]
tfpdef [11285,11324]
===
match
---
name: session [73168,73175]
name: session [73219,73226]
===
match
---
operator: = [29481,29482]
operator: = [29481,29482]
===
match
---
tfpdef [9963,9974]
tfpdef [9963,9974]
===
match
---
trailer [70329,70334]
trailer [70380,70385]
===
match
---
tfpdef [42825,42851]
tfpdef [42825,42851]
===
match
---
trailer [54570,54572]
trailer [54621,54623]
===
match
---
name: self [27752,27756]
name: self [27752,27756]
===
match
---
name: cast [51355,51359]
name: cast [51406,51410]
===
match
---
name: String [85002,85008]
name: String [85053,85059]
===
match
---
trailer [85215,85225]
trailer [85266,85276]
===
match
---
param [86316,86320]
param [86367,86371]
===
match
---
simple_stmt [20495,20538]
simple_stmt [20495,20538]
===
match
---
name: hour [19456,19460]
name: hour [19456,19460]
===
match
---
simple_stmt [1669,1714]
simple_stmt [1669,1714]
===
match
---
dotted_name [1269,1291]
dotted_name [1269,1291]
===
match
---
param [70242,70255]
param [70293,70306]
===
match
---
return_stmt [82810,82819]
return_stmt [82861,82870]
===
match
---
operator: , [53353,53354]
operator: , [53404,53405]
===
match
---
argument [85815,85827]
argument [85866,85878]
===
match
---
name: cli_parser [69779,69789]
name: cli_parser [69830,69840]
===
match
---
trailer [77011,77020]
trailer [77062,77071]
===
match
---
atom_expr [17967,17994]
atom_expr [17967,17994]
===
match
---
operator: = [42852,42853]
operator: = [42852,42853]
===
match
---
atom_expr [73842,73859]
atom_expr [73893,73910]
===
match
---
trailer [76587,76638]
trailer [76638,76689]
===
match
---
operator: , [74092,74093]
operator: , [74143,74144]
===
match
---
atom_expr [24995,25010]
atom_expr [24995,25010]
===
match
---
atom_expr [12281,12293]
atom_expr [12281,12293]
===
match
---
trailer [31083,31120]
trailer [31083,31120]
===
match
---
name: upstream_group_ids [62195,62213]
name: upstream_group_ids [62246,62264]
===
match
---
atom_expr [93670,93679]
atom_expr [93721,93730]
===
match
---
trailer [81456,81476]
trailer [81507,81527]
===
match
---
name: task_id [63228,63235]
name: task_id [63279,63286]
===
match
---
expr_stmt [75874,75914]
expr_stmt [75925,75965]
===
match
---
comparison [50411,50435]
comparison [50462,50486]
===
match
---
expr_stmt [35023,35035]
expr_stmt [35023,35035]
===
match
---
suite [35477,35813]
suite [35477,35813]
===
match
---
decorated [35818,36541]
decorated [35818,36541]
===
match
---
atom_expr [66382,66431]
atom_expr [66433,66482]
===
match
---
name: Integer [84677,84684]
name: Integer [84728,84735]
===
match
---
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_is_paused` method." [32994,33079]
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_is_paused` method." [32994,33079]
===
match
---
simple_stmt [35084,35120]
simple_stmt [35084,35120]
===
match
---
suite [28754,28953]
suite [28754,28953]
===
match
---
return_stmt [33982,34007]
return_stmt [33982,34007]
===
match
---
simple_stmt [35195,35230]
simple_stmt [35195,35230]
===
match
---
name: self [12883,12887]
name: self [12883,12887]
===
match
---
name: naive [21855,21860]
name: naive [21855,21860]
===
match
---
suite [85975,86298]
suite [86026,86349]
===
match
---
atom_expr [78874,78887]
atom_expr [78925,78938]
===
match
---
trailer [58691,58724]
trailer [58742,58775]
===
match
---
name: self [43607,43611]
name: self [43607,43611]
===
match
---
trailer [19342,19352]
trailer [19342,19352]
===
match
---
name: end_date [41417,41425]
name: end_date [41417,41425]
===
match
---
suite [16921,16992]
suite [16921,16992]
===
match
---
operator: = [67020,67021]
operator: = [67071,67072]
===
match
---
suite [25924,25998]
suite [25924,25998]
===
match
---
name: timezone [20356,20364]
name: timezone [20356,20364]
===
match
---
name: dag_id [32753,32759]
name: dag_id [32753,32759]
===
match
---
atom_expr [33831,33853]
atom_expr [33831,33853]
===
match
---
decorator [64793,64803]
decorator [64844,64854]
===
match
---
trailer [95429,95434]
trailer [95480,95485]
===
match
---
operator: = [69417,69418]
operator: = [69468,69469]
===
match
---
trailer [14184,14192]
trailer [14184,14192]
===
match
---
atom_expr [15065,15077]
atom_expr [15065,15077]
===
match
---
operator: , [79037,79038]
operator: , [79088,79089]
===
match
---
annassign [12358,12388]
annassign [12358,12388]
===
match
---
return_stmt [26273,26284]
return_stmt [26273,26284]
===
match
---
operator: = [61809,61810]
operator: = [61860,61861]
===
match
---
trailer [62097,62099]
trailer [62148,62150]
===
match
---
name: dags [77689,77693]
name: dags [77740,77744]
===
match
---
decorator [30791,30801]
decorator [30791,30801]
===
match
---
name: String [83720,83726]
name: String [83771,83777]
===
match
---
string: 'template_undefined' [82048,82068]
string: 'template_undefined' [82099,82119]
===
match
---
name: __name__ [52294,52302]
name: __name__ [52345,52353]
===
match
---
comparison [51539,51559]
comparison [51590,51610]
===
match
---
expr_stmt [59930,59959]
expr_stmt [59981,60010]
===
match
---
expr_stmt [19910,19940]
expr_stmt [19910,19940]
===
match
---
name: self [72579,72583]
name: self [72630,72634]
===
match
---
simple_stmt [63773,63791]
simple_stmt [63824,63842]
===
match
---
operator: , [1055,1056]
operator: , [1055,1056]
===
match
---
trailer [61431,61439]
trailer [61482,61490]
===
match
---
atom [22850,22862]
atom [22850,22862]
===
match
---
simple_stmt [70358,71476]
simple_stmt [70409,71527]
===
match
---
fstring_string: Invalid values of dag.orientation: only support  [14809,14857]
fstring_string: Invalid values of dag.orientation: only support  [14809,14857]
===
match
---
name: name [30099,30103]
name: name [30099,30103]
===
match
---
atom_expr [12850,12875]
atom_expr [12850,12875]
===
match
---
atom_expr [19329,19352]
atom_expr [19329,19352]
===
match
---
argument [69186,69211]
argument [69237,69262]
===
match
---
simple_stmt [88738,88755]
simple_stmt [88789,88806]
===
match
---
operator: , [29064,29065]
operator: , [29064,29065]
===
match
---
operator: , [2031,2032]
operator: , [2031,2032]
===
match
---
suite [66205,66432]
suite [66256,66483]
===
match
---
operator: , [82895,82896]
operator: , [82946,82947]
===
match
---
name: append [27926,27932]
name: append [27926,27932]
===
match
---
name: sensors [50684,50691]
name: sensors [50735,50742]
===
match
---
trailer [66061,66073]
trailer [66112,66124]
===
match
---
name: tz [20593,20595]
name: tz [20593,20595]
===
match
---
funcdef [19020,19522]
funcdef [19020,19522]
===
match
---
parameters [86657,86684]
parameters [86708,86735]
===
match
---
simple_stmt [32869,32959]
simple_stmt [32869,32959]
===
match
---
trailer [37050,37052]
trailer [37050,37052]
===
match
---
name: _task_group [61903,61914]
name: _task_group [61954,61965]
===
match
---
name: log [2371,2374]
name: log [2371,2374]
===
match
---
name: TypeError [17011,17020]
name: TypeError [17011,17020]
===
match
---
name: self [39829,39833]
name: self [39829,39833]
===
match
---
name: croniter [21292,21300]
name: croniter [21292,21300]
===
match
---
trailer [83885,83896]
trailer [83936,83947]
===
match
---
trailer [19245,19247]
trailer [19245,19247]
===
match
---
atom_expr [59760,59776]
atom_expr [59811,59827]
===
match
---
operator: , [57151,57152]
operator: , [57202,57203]
===
match
---
string: "dag.callback_exceptions" [35419,35444]
string: "dag.callback_exceptions" [35419,35444]
===
match
---
trailer [49333,49338]
trailer [49384,49389]
===
match
---
atom_expr [31084,31109]
atom_expr [31084,31109]
===
match
---
atom_expr [45075,45130]
atom_expr [45075,45130]
===
match
---
trailer [85069,85075]
trailer [85120,85126]
===
match
---
argument [75717,75739]
argument [75768,75790]
===
match
---
name: get [18239,18242]
name: get [18239,18242]
===
match
---
name: orm_tag [76898,76905]
name: orm_tag [76949,76956]
===
match
---
expr_stmt [31068,31120]
expr_stmt [31068,31120]
===
match
---
suite [57855,58006]
suite [57906,58057]
===
match
---
trailer [85528,85541]
trailer [85579,85592]
===
match
---
not_test [3498,3530]
not_test [3498,3530]
===
match
---
trailer [70172,70178]
trailer [70223,70229]
===
match
---
name: or_ [74970,74973]
name: or_ [75021,75024]
===
match
---
expr_stmt [24587,24627]
expr_stmt [24587,24627]
===
match
---
operator: = [57318,57319]
operator: = [57369,57370]
===
match
---
suite [19053,19522]
suite [19053,19522]
===
match
---
name: pop [95600,95603]
name: pop [95651,95654]
===
match
---
string: 'has_on_failure_callback' [82271,82296]
string: 'has_on_failure_callback' [82322,82347]
===
match
---
param [30025,30035]
param [30025,30035]
===
match
---
trailer [41877,41883]
trailer [41877,41883]
===
match
---
name: default_args [11620,11632]
name: default_args [11620,11632]
===
match
---
trailer [42223,42227]
trailer [42223,42227]
===
match
---
operator: = [84175,84176]
operator: = [84226,84227]
===
match
---
expr_stmt [87529,87598]
expr_stmt [87580,87649]
===
match
---
name: bool [88139,88143]
name: bool [88190,88194]
===
match
---
operator: , [53545,53546]
operator: , [53596,53597]
===
match
---
name: deactivate_unknown_dags [78395,78418]
name: deactivate_unknown_dags [78446,78469]
===
match
---
name: with_row_locks [74059,74073]
name: with_row_locks [74110,74124]
===
match
---
atom_expr [19272,19305]
atom_expr [19272,19305]
===
match
---
name: ForeignKey [1353,1363]
name: ForeignKey [1353,1363]
===
match
---
operator: , [17311,17312]
operator: , [17311,17312]
===
match
---
trailer [10084,10092]
trailer [10084,10092]
===
match
---
name: session [64284,64291]
name: session [64335,64342]
===
match
---
operator: , [18728,18729]
operator: , [18728,18729]
===
match
---
not_test [45148,45159]
not_test [45148,45159]
===
match
---
arglist [77254,77285]
arglist [77305,77336]
===
match
---
name: query [86709,86714]
name: query [86760,86765]
===
match
---
operator: , [22168,22169]
operator: , [22168,22169]
===
match
---
simple_stmt [76332,76372]
simple_stmt [76383,76423]
===
match
---
trailer [91506,91518]
trailer [91557,91569]
===
match
---
name: max_active_runs [14222,14237]
name: max_active_runs [14222,14237]
===
match
---
decorator [30879,30889]
decorator [30879,30889]
===
match
---
string: """Exclude tasks not included in the subdag from the given TaskGroup.""" [60941,61013]
string: """Exclude tasks not included in the subdag from the given TaskGroup.""" [60992,61064]
===
match
---
simple_stmt [69071,69631]
simple_stmt [69122,69682]
===
match
---
name: t [27484,27485]
name: t [27484,27485]
===
match
---
trailer [12733,12766]
trailer [12733,12766]
===
match
---
name: SubDagOperator [45014,45028]
name: SubDagOperator [45014,45028]
===
match
---
name: str [82398,82401]
name: str [82449,82452]
===
match
---
suite [61466,61536]
suite [61517,61587]
===
match
---
name: TYPE_CHECKING [2646,2659]
name: TYPE_CHECKING [2646,2659]
===
match
---
name: self [64935,64939]
name: self [64986,64990]
===
match
---
trailer [71629,71637]
trailer [71680,71688]
===
match
---
tfpdef [10500,10528]
tfpdef [10500,10528]
===
match
---
name: tis [53413,53416]
name: tis [53464,53467]
===
match
---
name: tz [20495,20497]
name: tz [20495,20497]
===
match
---
name: qry [80467,80470]
name: qry [80518,80521]
===
match
---
name: task_id [51436,51443]
name: task_id [51487,51494]
===
match
---
operator: , [90040,90041]
operator: , [90091,90092]
===
match
---
argument [73962,73977]
argument [74013,74028]
===
match
---
trailer [66467,66477]
trailer [66518,66528]
===
match
---
simple_stmt [58377,58568]
simple_stmt [58428,58619]
===
match
---
string: 'core' [66908,66914]
string: 'core' [66959,66965]
===
match
---
name: task [35087,35091]
name: task [35087,35091]
===
match
---
tfpdef [82872,82895]
tfpdef [82923,82946]
===
match
---
raise_stmt [72005,72138]
raise_stmt [72056,72189]
===
match
---
operator: , [32488,32489]
operator: , [32488,32489]
===
match
---
operator: , [74844,74845]
operator: , [74895,74896]
===
match
---
name: keys [62552,62556]
name: keys [62603,62607]
===
match
---
trailer [65991,66001]
trailer [66042,66052]
===
match
---
name: start_date [57141,57151]
name: start_date [57192,57202]
===
match
---
name: self [28191,28195]
name: self [28191,28195]
===
match
---
argument [60366,60380]
argument [60417,60431]
===
match
---
name: normalized_schedule_interval [19742,19770]
name: normalized_schedule_interval [19742,19770]
===
match
---
name: Boolean [84603,84610]
name: Boolean [84654,84661]
===
match
---
name: session [78435,78442]
name: session [78486,78493]
===
match
---
trailer [45671,45680]
trailer [45671,45680]
===
match
---
trailer [81094,81100]
trailer [81145,81151]
===
match
---
name: group [60907,60912]
name: group [60958,60963]
===
match
---
operator: > [51855,51856]
operator: > [51906,51907]
===
match
---
trailer [22006,22021]
trailer [22006,22021]
===
match
---
name: info [34911,34915]
name: info [34911,34915]
===
match
---
name: Optional [18708,18716]
name: Optional [18708,18716]
===
match
---
name: String [85149,85155]
name: String [85200,85206]
===
match
---
suite [86400,86434]
suite [86451,86485]
===
match
---
operator: = [93086,93087]
operator: = [93137,93138]
===
match
---
param [82897,82915]
param [82948,82966]
===
match
---
simple_stmt [55693,55734]
simple_stmt [55744,55785]
===
match
---
name: external_task_id [52600,52616]
name: external_task_id [52651,52667]
===
match
---
name: execution_date [36998,37012]
name: execution_date [36998,37012]
===
match
---
name: start_date [69120,69130]
name: start_date [69171,69181]
===
match
---
trailer [29669,29706]
trailer [29669,29706]
===
match
---
name: State [56064,56069]
name: State [56115,56120]
===
match
---
name: all [89317,89320]
name: all [89368,89371]
===
match
---
name: str [10218,10221]
name: str [10218,10221]
===
match
---
trailer [89912,89914]
trailer [89963,89965]
===
match
---
trailer [77039,77044]
trailer [77090,77095]
===
match
---
atom_expr [12549,12566]
atom_expr [12549,12566]
===
match
---
simple_stmt [81416,82312]
simple_stmt [81467,82363]
===
match
---
name: clear_task_instances [55232,55252]
name: clear_task_instances [55283,55303]
===
match
---
trailer [81382,81402]
trailer [81433,81453]
===
match
---
atom_expr [39108,39127]
atom_expr [39108,39127]
===
match
---
atom_expr [58044,58068]
atom_expr [58095,58119]
===
match
---
simple_stmt [83645,83695]
simple_stmt [83696,83746]
===
match
---
trailer [62250,62252]
trailer [62301,62303]
===
match
---
simple_stmt [11937,11958]
simple_stmt [11937,11958]
===
match
---
atom [87346,87519]
atom [87397,87570]
===
match
---
operator: , [1124,1125]
operator: , [1124,1125]
===
match
---
trailer [16151,16158]
trailer [16151,16158]
===
match
---
name: dagparam [1871,1879]
name: dagparam [1871,1879]
===
match
---
atom_expr [62400,62458]
atom_expr [62451,62509]
===
match
---
name: TaskInstance [81175,81187]
name: TaskInstance [81226,81238]
===
match
---
operator: = [25011,25012]
operator: = [25011,25012]
===
match
---
decorator [29494,29504]
decorator [29494,29504]
===
match
---
trailer [76317,76319]
trailer [76368,76370]
===
match
---
name: cron [21725,21729]
name: cron [21725,21729]
===
match
---
name: dateutil [1269,1277]
name: dateutil [1269,1277]
===
match
---
expr_stmt [61176,61196]
expr_stmt [61227,61247]
===
match
---
name: self [12630,12634]
name: self [12630,12634]
===
match
---
argument [56543,56555]
argument [56594,56606]
===
match
---
trailer [90887,90893]
trailer [90938,90944]
===
match
---
suite [12668,12767]
suite [12668,12767]
===
match
---
name: default_view [78334,78346]
name: default_view [78385,78397]
===
match
---
simple_stmt [17270,17282]
simple_stmt [17270,17282]
===
match
---
name: dag [48863,48866]
name: dag [48863,48866]
===
match
---
simple_stmt [13927,13974]
simple_stmt [13927,13974]
===
match
---
operator: , [88143,88144]
operator: , [88194,88195]
===
match
---
string: 'webserver' [10826,10837]
string: 'webserver' [10826,10837]
===
match
---
simple_stmt [13675,13762]
simple_stmt [13675,13762]
===
match
---
trailer [60787,60791]
trailer [60838,60842]
===
match
---
operator: - [22027,22028]
operator: - [22027,22028]
===
match
---
trailer [62895,62901]
trailer [62946,62952]
===
match
---
name: pickle_id [64096,64105]
name: pickle_id [64147,64156]
===
match
---
name: dag_id [32037,32043]
name: dag_id [32037,32043]
===
match
---
trailer [18348,18353]
trailer [18348,18353]
===
match
---
if_stmt [56612,56651]
if_stmt [56663,56702]
===
match
---
name: query [3640,3645]
name: query [3640,3645]
===
match
---
import_from [2176,2252]
import_from [2176,2252]
===
match
---
atom [79393,79544]
atom [79444,79595]
===
match
---
operator: @ [72770,72771]
operator: @ [72821,72822]
===
match
---
suite [44814,45132]
suite [44814,45132]
===
match
---
operator: , [88690,88691]
operator: , [88741,88742]
===
match
---
name: dag_run_state [57413,57426]
name: dag_run_state [57464,57477]
===
match
---
name: self [16819,16823]
name: self [16819,16823]
===
match
---
suite [61354,61441]
suite [61405,61492]
===
match
---
atom_expr [29012,29024]
atom_expr [29012,29024]
===
match
---
import_from [1234,1263]
import_from [1234,1263]
===
match
---
name: List [11413,11417]
name: List [11413,11417]
===
match
---
simple_stmt [14159,14209]
simple_stmt [14159,14209]
===
match
---
operator: = [54041,54042]
operator: = [54092,54093]
===
match
---
name: Dict [15428,15432]
name: Dict [15428,15432]
===
match
---
name: run_backwards [69606,69619]
name: run_backwards [69657,69670]
===
match
---
string: 'reason' [35211,35219]
string: 'reason' [35211,35219]
===
match
---
trailer [76999,77004]
trailer [77050,77055]
===
match
---
atom_expr [93499,93520]
atom_expr [93550,93571]
===
match
---
name: question [55191,55199]
name: question [55242,55250]
===
match
---
name: task_group [59949,59959]
name: task_group [60000,60010]
===
match
---
name: isinstance [71768,71778]
name: isinstance [71819,71829]
===
match
---
return_stmt [43637,43663]
return_stmt [43637,43663]
===
match
---
name: tz [21862,21864]
name: tz [21862,21864]
===
match
---
trailer [57006,57014]
trailer [57057,57065]
===
match
---
return_stmt [28514,28647]
return_stmt [28514,28647]
===
match
---
argument [76588,76637]
argument [76639,76688]
===
match
---
trailer [53097,53104]
trailer [53148,53155]
===
match
---
atom_expr [40887,40900]
atom_expr [40887,40900]
===
match
---
atom_expr [29373,29390]
atom_expr [29373,29390]
===
match
---
expr_stmt [43439,43512]
expr_stmt [43439,43512]
===
match
---
atom_expr [35646,35657]
atom_expr [35646,35657]
===
match
---
fstring_string: ^ [53224,53225]
fstring_string: ^ [53275,53276]
===
match
---
name: ti [52304,52306]
name: ti [52355,52357]
===
match
---
operator: = [14991,14992]
operator: = [14991,14992]
===
match
---
name: __repr__ [16107,16115]
name: __repr__ [16107,16115]
===
match
---
name: type [2861,2865]
name: type [2861,2865]
===
match
---
name: get_template_context [35145,35165]
name: get_template_context [35145,35165]
===
match
---
trailer [55116,55146]
trailer [55167,55197]
===
match
---
name: run_dates [28031,28040]
name: run_dates [28031,28040]
===
match
---
name: DagModel [83467,83475]
name: DagModel [83518,83526]
===
match
---
name: utils [57001,57006]
name: utils [57052,57057]
===
match
---
decorated [29396,29489]
decorated [29396,29489]
===
match
---
param [19047,19051]
param [19047,19051]
===
match
---
parameters [29526,29532]
parameters [29526,29532]
===
match
---
name: DagRun [37655,37661]
name: DagRun [37655,37661]
===
match
---
name: is_subdag [76119,76128]
name: is_subdag [76170,76179]
===
match
---
trailer [40338,40365]
trailer [40338,40365]
===
match
---
if_stmt [80731,81207]
if_stmt [80782,81258]
===
match
---
name: schedule_interval [76442,76459]
name: schedule_interval [76493,76510]
===
match
---
operator: = [40806,40807]
operator: = [40806,40807]
===
match
---
trailer [32767,32774]
trailer [32767,32774]
===
match
---
name: session [88738,88745]
name: session [88789,88796]
===
match
---
operator: , [16486,16487]
operator: , [16486,16487]
===
match
---
name: state [80851,80856]
name: state [80902,80907]
===
match
---
trailer [40285,40306]
trailer [40285,40306]
===
match
---
decorated [32826,33185]
decorated [32826,33185]
===
match
---
arglist [24675,24708]
arglist [24675,24708]
===
match
---
name: tasks [41221,41226]
name: tasks [41221,41226]
===
match
---
name: end_date [65916,65924]
name: end_date [65967,65975]
===
match
---
number: 100 [83305,83308]
number: 100 [83356,83359]
===
match
---
atom_expr [87360,87509]
atom_expr [87411,87560]
===
match
---
return_stmt [28763,28952]
return_stmt [28763,28952]
===
match
---
operator: , [85373,85374]
operator: , [85424,85425]
===
match
---
return_stmt [94273,94287]
return_stmt [94324,94338]
===
match
---
arglist [64718,64726]
arglist [64769,64777]
===
match
---
operator: , [23217,23218]
operator: , [23217,23218]
===
match
---
trailer [64376,64378]
trailer [64427,64429]
===
match
---
import_from [2109,2140]
import_from [2109,2140]
===
match
---
operator: = [56034,56035]
operator: = [56085,56086]
===
match
---
testlist_comp [63039,63068]
testlist_comp [63090,63119]
===
match
---
import_as_name [2222,2252]
import_as_name [2222,2252]
===
match
---
name: params [11841,11847]
name: params [11841,11847]
===
match
---
trailer [14192,14208]
trailer [14192,14208]
===
match
---
atom_expr [14309,14331]
atom_expr [14309,14331]
===
match
---
comp_op [77187,77193]
comp_op [77238,77244]
===
match
---
name: f_sig [93080,93085]
name: f_sig [93131,93136]
===
match
---
name: x [80787,80788]
name: x [80838,80839]
===
match
---
expr_stmt [63675,63729]
expr_stmt [63726,63780]
===
match
---
operator: { [83124,83125]
operator: { [83175,83176]
===
match
---
name: dag [48892,48895]
name: dag [48892,48895]
===
match
---
if_stmt [80708,81207]
if_stmt [80759,81258]
===
match
---
or_test [87914,87984]
or_test [87965,88035]
===
match
---
simple_stmt [74558,74606]
simple_stmt [74609,74657]
===
match
---
atom_expr [62295,62361]
atom_expr [62346,62412]
===
match
---
atom_expr [76023,76037]
atom_expr [76074,76088]
===
match
---
atom_expr [60345,60381]
atom_expr [60396,60432]
===
match
---
operator: = [33739,33740]
operator: = [33739,33740]
===
match
---
tfpdef [63094,63106]
tfpdef [63145,63157]
===
match
---
operator: = [54294,54295]
operator: = [54345,54346]
===
match
---
name: other [16222,16227]
name: other [16222,16227]
===
match
---
string: 'max_dagruns_to_create_per_loop' [85894,85926]
string: 'max_dagruns_to_create_per_loop' [85945,85977]
===
match
---
trailer [52481,52488]
trailer [52532,52539]
===
match
---
operator: = [56094,56095]
operator: = [56145,56146]
===
match
---
trailer [79804,79810]
trailer [79855,79861]
===
match
---
atom_expr [26212,26225]
atom_expr [26212,26225]
===
match
---
trailer [77710,77727]
trailer [77761,77778]
===
match
---
operator: , [90807,90808]
operator: , [90858,90859]
===
match
---
sync_comp_for [73803,73818]
sync_comp_for [73854,73869]
===
match
---
string: """         Calculate ``next_dagrun`` and `next_dagrun_create_after``          :param dag: The DAG object         :param most_recent_dag_run: DateTime of most recent run of this dag, or none if not yet scheduled.         :param active_runs_of_dag: Number of currently active runs of this dag         """ [91190,91493]
string: """         Calculate ``next_dagrun`` and `next_dagrun_create_after``          :param dag: The DAG object         :param most_recent_dag_run: DateTime of most recent run of this dag, or none if not yet scheduled.         :param active_runs_of_dag: Number of currently active runs of this dag         """ [91241,91544]
===
match
---
trailer [56742,56763]
trailer [56793,56814]
===
match
---
name: start_date [24852,24862]
name: start_date [24852,24862]
===
match
---
operator: , [10385,10386]
operator: , [10385,10386]
===
match
---
name: Index [85751,85756]
name: Index [85802,85807]
===
match
---
expr_stmt [60541,60572]
expr_stmt [60592,60623]
===
match
---
name: sqlalchemy [1318,1328]
name: sqlalchemy [1318,1328]
===
match
---
name: apply_defaults [93204,93218]
name: apply_defaults [93255,93269]
===
match
---
trailer [31289,31303]
trailer [31289,31303]
===
match
---
parameters [32853,32859]
parameters [32853,32859]
===
match
---
atom_expr [88439,88454]
atom_expr [88490,88505]
===
match
---
name: is_ [90696,90699]
name: is_ [90747,90750]
===
match
---
atom_expr [3663,3687]
atom_expr [3663,3687]
===
match
---
name: task_id [63167,63174]
name: task_id [63218,63225]
===
match
---
atom_expr [63039,63048]
atom_expr [63090,63099]
===
match
---
name: conditions [48984,48994]
name: conditions [48984,48994]
===
match
---
comparison [16515,16528]
comparison [16515,16528]
===
match
---
atom_expr [90765,90793]
atom_expr [90816,90844]
===
match
---
name: dag [64092,64095]
name: dag [64143,64146]
===
match
---
operator: = [29301,29302]
operator: = [29301,29302]
===
match
---
operator: = [72327,72328]
operator: = [72378,72379]
===
match
---
trailer [75663,75665]
trailer [75714,75716]
===
match
---
trailer [57102,57108]
trailer [57153,57159]
===
match
---
trailer [14268,14283]
trailer [14268,14283]
===
match
---
atom_expr [22150,22167]
atom_expr [22150,22167]
===
match
---
trailer [49467,50186]
trailer [49518,50237]
===
match
---
operator: = [45543,45544]
operator: = [45543,45544]
===
match
---
funcdef [62978,63070]
funcdef [63029,63121]
===
match
---
name: split [49328,49333]
name: split [49379,49384]
===
match
---
trailer [12001,12016]
trailer [12001,12016]
===
match
---
number: 0 [54885,54886]
number: 0 [54936,54937]
===
match
---
name: next_execution_date [23139,23158]
name: next_execution_date [23139,23158]
===
match
---
parameters [78418,78448]
parameters [78469,78499]
===
match
---
simple_stmt [94132,94146]
simple_stmt [94183,94197]
===
match
---
operator: = [62187,62188]
operator: = [62238,62239]
===
match
---
atom_expr [30530,30553]
atom_expr [30530,30553]
===
match
---
name: debug [91784,91789]
name: debug [91835,91840]
===
match
---
name: end_date [49561,49569]
name: end_date [49612,49620]
===
match
---
operator: { [17909,17910]
operator: { [17909,17910]
===
match
---
name: Type [1174,1178]
name: Type [1174,1178]
===
match
---
atom_expr [76199,76213]
atom_expr [76250,76264]
===
match
---
trailer [45835,45850]
trailer [45835,45850]
===
match
---
name: include_parentdag [46182,46199]
name: include_parentdag [46182,46199]
===
match
---
name: dag_id [75733,75739]
name: dag_id [75784,75790]
===
match
---
name: self [82374,82378]
name: self [82425,82429]
===
match
---
simple_stmt [48572,48590]
simple_stmt [48572,48590]
===
match
---
name: memo [57999,58003]
name: memo [58050,58054]
===
match
---
name: paused_dag_ids [87329,87343]
name: paused_dag_ids [87380,87394]
===
match
---
operator: = [3646,3647]
operator: = [3646,3647]
===
match
---
trailer [32621,32627]
trailer [32621,32627]
===
match
---
name: do_it [56993,56998]
name: do_it [57044,57049]
===
match
---
param [45349,45354]
param [45349,45354]
===
match
---
name: ti_key [54496,54502]
name: ti_key [54547,54553]
===
match
---
operator: = [50310,50311]
operator: = [50361,50362]
===
match
---
name: List [87078,87082]
name: List [87129,87133]
===
match
---
operator: -> [87114,87116]
operator: -> [87165,87167]
===
match
---
sync_comp_for [41797,41811]
sync_comp_for [41797,41811]
===
match
---
trailer [30762,30785]
trailer [30762,30785]
===
match
---
trailer [38926,38932]
trailer [38926,38932]
===
match
---
atom_expr [81164,81206]
atom_expr [81215,81257]
===
match
---
name: provide_session [40706,40721]
name: provide_session [40706,40721]
===
match
---
argument [90973,90979]
argument [91024,91030]
===
match
---
operator: , [13276,13277]
operator: , [13276,13277]
===
match
---
name: append [77324,77330]
name: append [77375,77381]
===
match
---
simple_stmt [91780,92004]
simple_stmt [91831,92055]
===
match
---
trailer [17060,17071]
trailer [17060,17071]
===
match
---
trailer [69996,70006]
trailer [70047,70057]
===
match
---
name: self [48792,48796]
name: self [48792,48796]
===
match
---
simple_stmt [56636,56651]
simple_stmt [56687,56702]
===
match
---
comp_op [66016,66022]
comp_op [66067,66073]
===
match
---
trailer [17053,17060]
trailer [17053,17060]
===
match
---
argument [94134,94144]
argument [94185,94195]
===
match
---
trailer [50596,50603]
trailer [50647,50654]
===
match
---
name: timezone [12784,12792]
name: timezone [12784,12792]
===
match
---
name: Boolean [83959,83966]
name: Boolean [84010,84017]
===
match
---
trailer [41631,41637]
trailer [41631,41637]
===
match
---
name: pickle [849,855]
name: pickle [849,855]
===
match
---
name: Optional [45489,45497]
name: Optional [45489,45497]
===
match
---
name: run [69643,69646]
name: run [69694,69697]
===
match
---
simple_stmt [41602,41648]
simple_stmt [41602,41648]
===
match
---
name: most_recent_dag_runs [74776,74796]
name: most_recent_dag_runs [74827,74847]
===
match
---
simple_stmt [26273,26285]
simple_stmt [26273,26285]
===
match
---
operator: , [46316,46317]
operator: , [46316,46317]
===
match
---
name: self [39210,39214]
name: self [39210,39214]
===
match
---
simple_stmt [28090,28171]
simple_stmt [28090,28171]
===
match
---
name: self [69662,69666]
name: self [69713,69717]
===
match
---
name: update [88639,88645]
name: update [88690,88696]
===
match
---
trailer [74379,74395]
trailer [74430,74446]
===
match
---
atom_expr [12066,12083]
atom_expr [12066,12083]
===
match
---
expr_stmt [86060,86117]
expr_stmt [86111,86168]
===
match
---
name: on_success_callback [34808,34827]
name: on_success_callback [34808,34827]
===
match
---
trailer [60087,60117]
trailer [60138,60168]
===
match
---
trailer [61742,61751]
trailer [61793,61802]
===
match
---
operator: , [58708,58709]
operator: , [58759,58760]
===
match
---
atom_expr [84152,84182]
atom_expr [84203,84233]
===
match
---
trailer [54625,54627]
trailer [54676,54678]
===
match
---
trailer [11412,11423]
trailer [11412,11423]
===
match
---
name: tis [54557,54560]
name: tis [54608,54611]
===
match
---
expr_stmt [52449,52729]
expr_stmt [52500,52780]
===
match
---
operator: , [66774,66775]
operator: , [66825,66826]
===
match
---
name: DagModel [87411,87419]
name: DagModel [87462,87470]
===
match
---
operator: @ [86621,86622]
operator: @ [86672,86673]
===
match
---
name: Column [84049,84055]
name: Column [84100,84106]
===
match
---
dictorsetmaker [18222,18272]
dictorsetmaker [18222,18272]
===
match
---
trailer [95770,95791]
trailer [95821,95842]
===
match
---
name: kwargs [58293,58299]
name: kwargs [58344,58350]
===
match
---
param [70108,70149]
param [70159,70200]
===
match
---
expr_stmt [76275,76319]
expr_stmt [76326,76370]
===
match
---
atom_expr [61379,61409]
atom_expr [61430,61460]
===
match
---
operator: } [83125,83126]
operator: } [83176,83177]
===
match
---
suite [89594,89835]
suite [89645,89886]
===
match
---
trailer [51432,51444]
trailer [51483,51495]
===
match
---
name: dttm [21604,21608]
name: dttm [21604,21608]
===
match
---
trailer [31527,31532]
trailer [31527,31532]
===
match
---
name: new_perm_mapping [17890,17906]
name: new_perm_mapping [17890,17906]
===
match
---
name: query [45725,45730]
name: query [45725,45730]
===
match
---
trailer [58718,58723]
trailer [58769,58774]
===
match
---
name: self [38764,38768]
name: self [38764,38768]
===
match
---
atom_expr [80498,80518]
atom_expr [80549,80569]
===
match
---
suite [82444,82820]
suite [82495,82871]
===
match
---
trailer [88855,88860]
trailer [88906,88911]
===
match
---
name: DR [3561,3563]
name: DR [3561,3563]
===
match
---
trailer [50315,50322]
trailer [50366,50373]
===
match
---
operator: @ [37091,37092]
operator: @ [37091,37092]
===
match
---
name: log [73729,73732]
name: log [73780,73783]
===
match
---
suite [45704,45775]
suite [45704,45775]
===
match
---
simple_stmt [62266,62362]
simple_stmt [62317,62413]
===
match
---
arglist [21008,21046]
arglist [21008,21046]
===
match
---
operator: , [49423,49424]
operator: , [49474,49475]
===
match
---
trailer [63719,63721]
trailer [63770,63772]
===
match
---
decorators [73182,73216]
decorators [73233,73267]
===
match
---
trailer [12799,12812]
trailer [12799,12812]
===
match
---
if_stmt [50639,54504]
if_stmt [50690,54555]
===
match
---
trailer [37773,37775]
trailer [37773,37775]
===
match
---
simple_stmt [56583,56603]
simple_stmt [56634,56654]
===
match
---
operator: , [46034,46035]
operator: , [46034,46035]
===
match
---
name: count [54854,54859]
name: count [54905,54910]
===
match
---
name: conf [10961,10965]
name: conf [10961,10965]
===
match
---
atom_expr [63984,64054]
atom_expr [64035,64105]
===
match
---
simple_stmt [57578,57591]
simple_stmt [57629,57642]
===
match
---
suite [87126,87629]
suite [87177,87680]
===
match
---
name: DagRunType [71789,71799]
name: DagRunType [71840,71850]
===
match
---
name: used_group_ids [61099,61113]
name: used_group_ids [61150,61164]
===
match
---
decorator [95692,95705]
decorator [95743,95756]
===
match
---
name: execution_date [72233,72247]
name: execution_date [72284,72298]
===
match
---
name: concurrency [12086,12097]
name: concurrency [12086,12097]
===
match
---
fstring_expr [86346,86359]
fstring_expr [86397,86410]
===
match
---
name: cli [69739,69742]
name: cli [69790,69793]
===
match
---
atom_expr [92635,92647]
atom_expr [92686,92698]
===
match
---
tfpdef [18673,18693]
tfpdef [18673,18693]
===
match
---
operator: ** [86001,86003]
operator: ** [86052,86054]
===
match
---
name: following_schedule [24551,24569]
name: following_schedule [24551,24569]
===
match
---
atom_expr [88042,88077]
atom_expr [88093,88128]
===
match
---
testlist_comp [3080,3102]
testlist_comp [3080,3102]
===
match
---
name: order_by [90836,90844]
name: order_by [90887,90895]
===
match
---
name: template_undefined [13987,14005]
name: template_undefined [13987,14005]
===
match
---
trailer [10976,11011]
trailer [10976,11011]
===
match
---
comparison [36402,36430]
comparison [36402,36430]
===
match
---
expr_stmt [25421,25488]
expr_stmt [25421,25488]
===
match
---
name: self [66463,66467]
name: self [66514,66518]
===
match
---
name: execution_date [41500,41514]
name: execution_date [41500,41514]
===
match
---
name: next_dagrun_info [91556,91572]
name: next_dagrun_info [91607,91623]
===
match
---
name: self [64266,64270]
name: self [64317,64321]
===
match
---
name: next_execution_date [22871,22890]
name: next_execution_date [22871,22890]
===
match
---
parameters [35470,35476]
parameters [35470,35476]
===
match
---
atom_expr [19987,20000]
atom_expr [19987,20000]
===
match
---
simple_stmt [60541,60573]
simple_stmt [60592,60624]
===
match
---
name: is_paused [83940,83949]
name: is_paused [83991,84000]
===
match
---
atom_expr [79828,79844]
atom_expr [79879,79895]
===
match
---
trailer [79459,79476]
trailer [79510,79527]
===
match
---
comparison [63027,63069]
comparison [63078,63120]
===
match
---
trailer [31682,31700]
trailer [31682,31700]
===
match
---
name: default_view [14439,14451]
name: default_view [14439,14451]
===
match
---
trailer [89550,89560]
trailer [89601,89611]
===
match
---
simple_stmt [63890,63899]
simple_stmt [63941,63950]
===
match
---
name: upstream_task_id [83106,83122]
name: upstream_task_id [83157,83173]
===
match
---
trailer [62581,62587]
trailer [62632,62638]
===
match
---
trailer [11859,11872]
trailer [11859,11872]
===
match
---
simple_stmt [2978,3057]
simple_stmt [2978,3057]
===
match
---
suite [60928,61853]
suite [60979,61904]
===
match
---
trailer [14141,14148]
trailer [14141,14148]
===
match
---
trailer [81030,81101]
trailer [81081,81152]
===
match
---
trailer [36464,36509]
trailer [36464,36509]
===
match
---
name: self [16381,16385]
name: self [16381,16385]
===
match
---
trailer [50544,50552]
trailer [50595,50603]
===
match
---
atom_expr [38049,38060]
atom_expr [38049,38060]
===
match
---
trailer [37661,37676]
trailer [37661,37676]
===
match
---
operator: , [91915,91916]
operator: , [91966,91967]
===
match
---
param [42819,42824]
param [42819,42824]
===
match
---
name: fileloc [77471,77478]
name: fileloc [77522,77529]
===
match
---
name: str [31343,31346]
name: str [31343,31346]
===
match
---
comparison [41619,41646]
comparison [41619,41646]
===
match
---
suite [39859,39928]
suite [39859,39928]
===
match
---
atom_expr [94132,94145]
atom_expr [94183,94196]
===
match
---
if_stmt [78719,78767]
if_stmt [78770,78818]
===
match
---
trailer [75778,75785]
trailer [75829,75836]
===
match
---
simple_stmt [66382,66432]
simple_stmt [66433,66483]
===
match
---
expr_stmt [95538,95605]
expr_stmt [95589,95656]
===
match
---
suite [93533,94146]
suite [93584,94197]
===
match
---
trailer [81053,81070]
trailer [81104,81121]
===
match
---
name: dag_bound_args [92657,92671]
name: dag_bound_args [92708,92722]
===
match
---
trailer [36291,36298]
trailer [36291,36298]
===
match
---
operator: = [14006,14007]
operator: = [14006,14007]
===
match
---
name: external_tis [52449,52461]
name: external_tis [52500,52512]
===
match
---
operator: = [48575,48576]
operator: = [48575,48576]
===
match
---
name: TI [52646,52648]
name: TI [52697,52699]
===
match
---
operator: , [28453,28454]
operator: , [28453,28454]
===
match
---
param [20823,20828]
param [20823,20828]
===
match
---
suite [48670,48997]
suite [48670,48997]
===
match
---
operator: = [30442,30443]
operator: = [30442,30443]
===
match
---
suite [33273,34008]
suite [33273,34008]
===
match
---
simple_stmt [74651,74676]
simple_stmt [74702,74727]
===
match
---
name: is_fixed_time_schedule [20168,20190]
name: is_fixed_time_schedule [20168,20190]
===
match
---
name: ti [52403,52405]
name: ti [52454,52456]
===
match
---
name: task_end_dates [26602,26616]
name: task_end_dates [26602,26616]
===
match
---
trailer [66045,66053]
trailer [66096,66104]
===
match
---
atom_expr [35408,35445]
atom_expr [35408,35445]
===
match
---
operator: = [51039,51040]
operator: = [51090,51091]
===
match
---
expr_stmt [28179,28220]
expr_stmt [28179,28220]
===
match
---
name: e [63758,63759]
name: e [63809,63810]
===
match
---
name: dagrun [1963,1969]
name: dagrun [1963,1969]
===
match
---
simple_stmt [31356,31508]
simple_stmt [31356,31508]
===
match
---
name: dag_id [36321,36327]
name: dag_id [36321,36327]
===
match
---
or_test [45584,45608]
or_test [45584,45608]
===
match
---
simple_stmt [11558,11607]
simple_stmt [11558,11607]
===
match
---
name: donot_pickle [66879,66891]
name: donot_pickle [66930,66942]
===
match
---
trailer [42537,42551]
trailer [42537,42551]
===
match
---
trailer [13073,13086]
trailer [13073,13086]
===
match
---
atom [25151,25201]
atom [25151,25201]
===
match
---
name: task_start_dates [25295,25311]
name: task_start_dates [25295,25311]
===
match
---
name: task_end_dates [26532,26546]
name: task_end_dates [26532,26546]
===
match
---
atom_expr [52518,52527]
atom_expr [52569,52578]
===
match
---
trailer [58021,58041]
trailer [58072,58092]
===
match
---
atom_expr [37992,38023]
atom_expr [37992,38023]
===
match
---
operator: , [69875,69876]
operator: , [69926,69927]
===
match
---
name: doc_md [15793,15799]
name: doc_md [15793,15799]
===
match
---
operator: = [72362,72363]
operator: = [72413,72414]
===
match
---
trailer [87460,87490]
trailer [87511,87541]
===
match
---
atom_expr [24600,24627]
atom_expr [24600,24627]
===
match
---
name: convert_to_utc [13415,13429]
name: convert_to_utc [13415,13429]
===
match
---
name: job [69071,69074]
name: job [69122,69125]
===
match
---
atom_expr [13982,14005]
atom_expr [13982,14005]
===
match
---
name: start_date [65118,65128]
name: start_date [65169,65179]
===
match
---
atom_expr [14976,14990]
atom_expr [14976,14990]
===
match
---
name: delay_on_limit_secs [69456,69475]
name: delay_on_limit_secs [69507,69526]
===
match
---
trailer [91655,91671]
trailer [91706,91722]
===
match
---
parameters [64815,64821]
parameters [64866,64872]
===
match
---
atom [31533,31562]
atom [31533,31562]
===
match
---
operator: , [49939,49940]
operator: , [49990,49991]
===
match
---
simple_stmt [80615,80699]
simple_stmt [80666,80750]
===
match
---
decorated [29314,29391]
decorated [29314,29391]
===
match
---
name: task_id [80662,80669]
name: task_id [80713,80720]
===
match
---
name: DagStateChangeCallback [11121,11143]
name: DagStateChangeCallback [11121,11143]
===
match
---
operator: = [92046,92047]
operator: = [92097,92098]
===
match
---
parameters [92146,92171]
parameters [92197,92222]
===
match
---
suite [16495,16529]
suite [16495,16529]
===
match
---
name: dags [73246,73250]
name: dags [73297,73301]
===
match
---
simple_stmt [11615,11669]
simple_stmt [11615,11669]
===
match
---
trailer [61098,61113]
trailer [61149,61164]
===
match
---
name: DagModel [88602,88610]
name: DagModel [88653,88661]
===
match
---
atom_expr [76918,76930]
atom_expr [76969,76981]
===
match
---
atom_expr [42592,42610]
atom_expr [42592,42610]
===
match
---
atom_expr [52581,52591]
atom_expr [52632,52642]
===
match
---
parameters [64555,64570]
parameters [64606,64621]
===
match
---
atom_expr [65952,65964]
atom_expr [66003,66015]
===
match
---
expr_stmt [13875,13918]
expr_stmt [13875,13918]
===
match
---
simple_stmt [788,800]
simple_stmt [788,800]
===
match
---
operator: , [3193,3194]
operator: , [3193,3194]
===
match
---
trailer [65488,65499]
trailer [65539,65550]
===
match
---
expr_stmt [14035,14072]
expr_stmt [14035,14072]
===
match
---
suite [63264,63397]
suite [63315,63448]
===
match
---
name: task [38981,38985]
name: task [38981,38985]
===
match
---
expr_stmt [92657,92719]
expr_stmt [92708,92770]
===
match
---
operator: == [16520,16522]
operator: == [16520,16522]
===
match
---
operator: = [85294,85295]
operator: = [85345,85346]
===
match
---
atom_expr [31961,32093]
atom_expr [31961,32093]
===
match
---
operator: = [10431,10432]
operator: = [10431,10432]
===
match
---
atom_expr [15779,15790]
atom_expr [15779,15790]
===
match
---
trailer [14313,14331]
trailer [14313,14331]
===
match
---
name: recursion_depth [49961,49976]
name: recursion_depth [50012,50027]
===
match
---
atom [28770,28952]
atom [28770,28952]
===
match
---
name: only_failed [53660,53671]
name: only_failed [53711,53722]
===
match
---
name: session [63942,63949]
name: session [63993,64000]
===
match
---
name: subdags [48797,48804]
name: subdags [48797,48804]
===
match
---
if_stmt [86126,86298]
if_stmt [86177,86349]
===
match
---
name: dag [79703,79706]
name: dag [79754,79757]
===
match
---
expr_stmt [52925,52967]
expr_stmt [52976,53018]
===
match
---
name: filter [42010,42016]
name: filter [42010,42016]
===
match
---
name: DagRun [38001,38007]
name: DagRun [38001,38007]
===
match
---
suite [71801,71898]
suite [71852,71949]
===
match
---
arglist [93325,93345]
arglist [93376,93396]
===
match
---
simple_stmt [54606,54628]
simple_stmt [54657,54679]
===
match
---
param [26749,26754]
param [26749,26754]
===
match
---
name: success [34068,34075]
name: success [34068,34075]
===
match
---
name: pickle [63929,63935]
name: pickle [63980,63986]
===
match
---
name: hasattr [12850,12857]
name: hasattr [12850,12857]
===
match
---
atom_expr [51355,51471]
atom_expr [51406,51522]
===
match
---
param [34060,34067]
param [34060,34067]
===
match
---
name: previous_schedule [24801,24818]
name: previous_schedule [24801,24818]
===
match
---
name: dag_id [86352,86358]
name: dag_id [86403,86409]
===
match
---
trailer [42072,42088]
trailer [42072,42088]
===
match
---
name: default_args [13184,13196]
name: default_args [13184,13196]
===
match
---
arglist [20030,20070]
arglist [20030,20070]
===
match
---
raise_stmt [14478,14650]
raise_stmt [14478,14650]
===
match
---
return_stmt [58247,58260]
return_stmt [58298,58311]
===
match
---
trailer [84158,84182]
trailer [84209,84233]
===
match
---
funcdef [36567,37086]
funcdef [36567,37086]
===
match
---
simple_stmt [45808,45864]
simple_stmt [45808,45864]
===
match
---
trailer [27560,27562]
trailer [27560,27562]
===
match
---
param [30906,30910]
param [30906,30910]
===
match
---
atom_expr [74846,74878]
atom_expr [74897,74929]
===
match
---
operator: , [54302,54303]
operator: , [54353,54354]
===
match
---
operator: <= [41515,41517]
operator: <= [41515,41517]
===
match
---
suite [24863,24961]
suite [24863,24961]
===
match
---
name: airflow [43273,43280]
name: airflow [43273,43280]
===
match
---
trailer [57852,57854]
trailer [57903,57905]
===
match
---
operator: = [24501,24502]
operator: = [24501,24502]
===
match
---
simple_stmt [62962,62973]
simple_stmt [63013,63024]
===
match
---
name: dag_by_ids [73773,73783]
name: dag_by_ids [73824,73834]
===
match
---
parameters [30018,30036]
parameters [30018,30036]
===
match
---
operator: = [74486,74487]
operator: = [74537,74538]
===
match
---
simple_stmt [83487,83525]
simple_stmt [83538,83576]
===
match
---
name: perms [18267,18272]
name: perms [18267,18272]
===
match
---
operator: , [11151,11152]
operator: , [11151,11152]
===
match
---
funcdef [30471,30555]
funcdef [30471,30555]
===
match
---
name: ti [51076,51078]
name: ti [51127,51129]
===
match
---
if_stmt [25888,25998]
if_stmt [25888,25998]
===
match
---
name: dags [73814,73818]
name: dags [73865,73869]
===
match
---
name: self [16026,16030]
name: self [16026,16030]
===
match
---
name: orm_dag [76023,76030]
name: orm_dag [76074,76081]
===
match
---
name: dags_needing_dagruns [90016,90036]
name: dags_needing_dagruns [90067,90087]
===
match
---
funcdef [86783,87002]
funcdef [86834,87053]
===
match
---
funcdef [82825,83155]
funcdef [82876,83206]
===
match
---
name: dag_tag [77259,77266]
name: dag_tag [77310,77317]
===
match
---
name: self [16208,16212]
name: self [16208,16212]
===
match
---
name: max_ [74851,74855]
name: max_ [74902,74906]
===
match
---
atom_expr [16964,16991]
atom_expr [16964,16991]
===
match
---
arglist [90682,90808]
arglist [90733,90859]
===
match
---
operator: { [61194,61195]
operator: { [61245,61246]
===
match
---
atom_expr [15412,15426]
atom_expr [15412,15426]
===
match
---
name: pendulum [22194,22202]
name: pendulum [22194,22202]
===
match
---
simple_stmt [21717,21749]
simple_stmt [21717,21749]
===
match
---
comparison [52581,52616]
comparison [52632,52667]
===
match
---
suite [33707,33818]
suite [33707,33818]
===
match
---
funcdef [28046,28403]
funcdef [28046,28403]
===
match
---
suite [32191,32546]
suite [32191,32546]
===
match
---
string: "" [12333,12335]
string: "" [12333,12335]
===
match
---
trailer [13835,13861]
trailer [13835,13861]
===
match
---
trailer [69870,69882]
trailer [69921,69933]
===
match
---
param [67016,67026]
param [67067,67077]
===
match
---
param [30481,30485]
param [30481,30485]
===
match
---
if_stmt [80590,80699]
if_stmt [80641,80750]
===
match
---
simple_stmt [93999,94043]
simple_stmt [94050,94094]
===
match
---
name: provide_session [28409,28424]
name: provide_session [28409,28424]
===
match
---
operator: = [26472,26473]
operator: = [26472,26473]
===
match
---
name: cron [19256,19260]
name: cron [19256,19260]
===
match
---
tfpdef [10447,10483]
tfpdef [10447,10483]
===
match
---
operator: = [77245,77246]
operator: = [77296,77297]
===
match
---
comparison [3470,3489]
comparison [3470,3489]
===
match
---
name: get_tis [49890,49897]
name: get_tis [49941,49948]
===
match
---
simple_stmt [50510,50554]
simple_stmt [50561,50605]
===
match
---
name: DagRun [74831,74837]
name: DagRun [74882,74888]
===
match
---
simple_stmt [16504,16529]
simple_stmt [16504,16529]
===
match
---
name: next_run_date [26230,26243]
name: next_run_date [26230,26243]
===
match
---
name: UtcDateTime [2506,2517]
name: UtcDateTime [2506,2517]
===
match
---
name: query [78794,78799]
name: query [78845,78850]
===
match
---
name: format [49309,49315]
name: format [49360,49366]
===
match
---
name: delta [21537,21542]
name: delta [21537,21542]
===
match
---
expr_stmt [83080,83154]
expr_stmt [83131,83205]
===
match
---
name: downstream_group_ids [62301,62321]
name: downstream_group_ids [62352,62372]
===
match
---
atom [18221,18273]
atom [18221,18273]
===
match
---
name: orm_dag [76496,76503]
name: orm_dag [76547,76554]
===
match
---
if_stmt [11790,11928]
if_stmt [11790,11928]
===
match
---
simple_stmt [15094,15141]
simple_stmt [15094,15141]
===
match
---
name: clear [53473,53478]
name: clear [53524,53529]
===
match
---
operator: = [25640,25641]
operator: = [25640,25641]
===
match
---
name: task_dict [30535,30544]
name: task_dict [30535,30544]
===
match
---
param [18659,18664]
param [18659,18664]
===
match
---
trailer [51435,51443]
trailer [51486,51494]
===
match
---
suite [22744,22863]
suite [22744,22863]
===
match
---
operator: @ [87007,87008]
operator: @ [87058,87059]
===
match
---
suite [64686,64728]
suite [64737,64779]
===
match
---
suite [78449,78952]
suite [78500,79003]
===
match
---
name: scalar [38062,38068]
name: scalar [38062,38068]
===
match
---
atom_expr [57963,58005]
atom_expr [58014,58056]
===
match
---
operator: = [21290,21291]
operator: = [21290,21291]
===
match
---
param [63094,63107]
param [63145,63158]
===
match
---
name: following [20554,20563]
name: following [20554,20563]
===
match
---
name: DagPickle [64138,64147]
name: DagPickle [64189,64198]
===
match
---
name: PatternType [60008,60019]
name: PatternType [60059,60070]
===
match
---
trailer [64717,64727]
trailer [64768,64778]
===
match
---
expr_stmt [12106,12143]
expr_stmt [12106,12143]
===
match
---
name: naive [21224,21229]
name: naive [21224,21229]
===
match
---
operator: = [46106,46107]
operator: = [46106,46107]
===
match
---
suite [88199,88755]
suite [88250,88806]
===
match
---
atom_expr [50312,50353]
atom_expr [50363,50404]
===
match
---
operator: , [52616,52617]
operator: , [52667,52668]
===
match
---
comparison [61323,61353]
comparison [61374,61404]
===
match
---
operator: @ [86604,86605]
operator: @ [86655,86656]
===
match
---
name: self [29060,29064]
name: self [29060,29064]
===
match
---
name: timezone [13406,13414]
name: timezone [13406,13414]
===
match
---
name: state [81085,81090]
name: state [81136,81141]
===
match
---
name: visited_external_tis [54361,54381]
name: visited_external_tis [54412,54432]
===
match
---
name: using_start_date [27442,27458]
name: using_start_date [27442,27458]
===
match
---
trailer [60467,60482]
trailer [60518,60533]
===
match
---
name: func [80487,80491]
name: func [80538,80542]
===
match
---
simple_stmt [59712,59739]
simple_stmt [59763,59790]
===
match
---
operator: = [27374,27375]
operator: = [27374,27375]
===
match
---
import_from [2253,2304]
import_from [2253,2304]
===
match
---
name: kwargs [85967,85973]
name: kwargs [86018,86024]
===
match
---
decorated [87007,87629]
decorated [87058,87680]
===
match
---
name: __init__ [92639,92647]
name: __init__ [92690,92698]
===
match
---
atom_expr [73141,73176]
atom_expr [73192,73227]
===
match
---
atom_expr [10363,10385]
atom_expr [10363,10385]
===
match
---
simple_stmt [71653,71707]
simple_stmt [71704,71758]
===
match
---
operator: = [55582,55583]
operator: = [55633,55634]
===
match
---
operator: { [53225,53226]
operator: { [53276,53277]
===
match
---
atom_expr [89471,89488]
atom_expr [89522,89539]
===
match
---
name: str [9971,9974]
name: str [9971,9974]
===
match
---
trailer [11681,11688]
trailer [11681,11688]
===
match
---
name: task_count [66446,66456]
name: task_count [66497,66507]
===
match
---
simple_stmt [49023,49080]
simple_stmt [49023,49080]
===
match
---
atom_expr [72822,72839]
atom_expr [72873,72890]
===
match
---
param [86658,86662]
param [86709,86713]
===
match
---
suite [2842,2885]
suite [2842,2885]
===
match
---
name: downstream_task_id [40679,40697]
name: downstream_task_id [40679,40697]
===
match
---
trailer [75805,75815]
trailer [75856,75866]
===
match
---
name: tis [42313,42316]
name: tis [42313,42316]
===
match
---
param [66745,66750]
param [66796,66801]
===
match
---
parameters [38115,38121]
parameters [38115,38121]
===
match
---
operator: = [19959,19960]
operator: = [19959,19960]
===
match
---
simple_stmt [20266,20306]
simple_stmt [20266,20306]
===
match
---
name: List [95125,95129]
name: List [95176,95180]
===
match
---
import_from [1808,1850]
import_from [1808,1850]
===
match
---
expr_stmt [49234,49438]
expr_stmt [49285,49489]
===
match
---
name: self [78200,78204]
name: self [78251,78255]
===
match
---
name: discard [61513,61520]
name: discard [61564,61571]
===
match
---
trailer [12157,12170]
trailer [12157,12170]
===
match
---
operator: @ [86457,86458]
operator: @ [86508,86509]
===
match
---
name: DagModel [88660,88668]
name: DagModel [88711,88719]
===
match
---
atom_expr [62888,62902]
atom_expr [62939,62953]
===
match
---
atom_expr [65849,65862]
atom_expr [65900,65913]
===
match
---
trailer [74475,74485]
trailer [74526,74536]
===
match
---
atom_expr [69861,69882]
atom_expr [69912,69933]
===
match
---
operator: , [9856,9857]
operator: , [9856,9857]
===
match
---
expr_stmt [2847,2884]
expr_stmt [2847,2884]
===
match
---
param [40410,40415]
param [40410,40415]
===
match
---
argument [64907,64915]
argument [64958,64966]
===
match
---
name: full_filepath [12036,12049]
name: full_filepath [12036,12049]
===
match
---
suite [41585,41648]
suite [41585,41648]
===
match
---
comparison [38922,38961]
comparison [38922,38961]
===
match
---
simple_stmt [27297,27312]
simple_stmt [27297,27312]
===
match
---
name: self [21788,21792]
name: self [21788,21792]
===
match
---
atom [17909,18090]
atom [17909,18090]
===
match
---
arglist [74995,75099]
arglist [75046,75150]
===
match
---
name: start_date [45693,45703]
name: start_date [45693,45703]
===
match
---
name: task_ids [79924,79932]
name: task_ids [79975,79983]
===
match
---
expr_stmt [61379,61440]
expr_stmt [61430,61491]
===
match
---
name: only_running [49645,49657]
name: only_running [49696,49708]
===
match
---
return_stmt [63206,63236]
return_stmt [63257,63287]
===
match
---
string: """Table containing DAG properties""" [83487,83524]
string: """Table containing DAG properties""" [83538,83575]
===
match
---
return_stmt [45264,45290]
return_stmt [45264,45290]
===
match
---
trailer [25344,25394]
trailer [25344,25394]
===
match
---
operator: = [65342,65343]
operator: = [65393,65394]
===
match
---
param [63108,63137]
param [63159,63188]
===
match
---
name: func [36265,36269]
name: func [36265,36269]
===
match
---
name: self [33164,33168]
name: self [33164,33168]
===
match
---
param [31611,31615]
param [31611,31615]
===
match
---
name: end_date [13395,13403]
name: end_date [13395,13403]
===
match
---
name: include_subdags [55987,56002]
name: include_subdags [56038,56053]
===
match
---
operator: = [77258,77259]
operator: = [77309,77310]
===
match
---
name: include_upstream [60397,60413]
name: include_upstream [60448,60464]
===
match
---
atom_expr [31551,31561]
atom_expr [31551,31561]
===
match
---
atom_expr [66141,66153]
atom_expr [66192,66204]
===
match
---
trailer [63777,63781]
trailer [63828,63832]
===
match
---
name: set_dependency [40395,40409]
name: set_dependency [40395,40409]
===
match
---
name: date [40902,40906]
name: date [40902,40906]
===
match
---
atom_expr [17087,17115]
atom_expr [17087,17115]
===
match
---
atom [60051,60118]
atom [60102,60169]
===
match
---
simple_stmt [2068,2109]
simple_stmt [2068,2109]
===
match
---
name: task_id [60756,60763]
name: task_id [60807,60814]
===
match
---
param [86663,86670]
param [86714,86721]
===
match
---
expr_stmt [74468,74515]
expr_stmt [74519,74566]
===
match
---
operator: , [76709,76710]
operator: , [76760,76761]
===
match
---
name: query [36259,36264]
name: query [36259,36264]
===
match
---
dotted_name [50676,50705]
dotted_name [50727,50756]
===
match
---
tfpdef [11199,11221]
tfpdef [11199,11221]
===
match
---
trailer [74855,74878]
trailer [74906,74929]
===
match
---
name: timezone [12719,12727]
name: timezone [12719,12727]
===
match
---
name: query [32721,32726]
name: query [32721,32726]
===
match
---
name: Union [10269,10274]
name: Union [10269,10274]
===
match
---
return_stmt [28287,28298]
return_stmt [28287,28298]
===
match
---
funcdef [86642,86757]
funcdef [86693,86808]
===
match
---
trailer [41183,41191]
trailer [41183,41191]
===
match
---
argument [93106,93111]
argument [93157,93162]
===
match
---
name: p_dag [49234,49239]
name: p_dag [49285,49290]
===
match
---
simple_stmt [72569,72584]
simple_stmt [72620,72635]
===
match
---
tfpdef [11091,11144]
tfpdef [11091,11144]
===
match
---
suite [34109,35446]
suite [34109,35446]
===
match
---
simple_stmt [59895,59922]
simple_stmt [59946,59973]
===
match
---
operator: , [89255,89256]
operator: , [89306,89307]
===
match
---
simple_stmt [66218,66254]
simple_stmt [66269,66305]
===
match
---
name: session [77805,77812]
name: session [77856,77863]
===
match
---
trailer [45828,45863]
trailer [45828,45863]
===
match
---
name: primary_key [83391,83402]
name: primary_key [83442,83453]
===
match
---
name: is_ [90738,90741]
name: is_ [90789,90792]
===
match
---
name: state [81188,81193]
name: state [81239,81244]
===
match
---
name: provide_session [88778,88793]
name: provide_session [88829,88844]
===
match
---
suite [88510,88580]
suite [88561,88631]
===
match
---
arglist [79451,79514]
arglist [79502,79565]
===
match
---
param [82374,82379]
param [82425,82430]
===
match
---
simple_stmt [37072,37086]
simple_stmt [37072,37086]
===
match
---
trailer [79443,79450]
trailer [79494,79501]
===
match
---
simple_stmt [28179,28221]
simple_stmt [28179,28221]
===
match
---
operator: = [74057,74058]
operator: = [74108,74109]
===
match
---
name: ExecutorLoader [68986,69000]
name: ExecutorLoader [69037,69051]
===
match
---
name: task [38927,38931]
name: task [38927,38931]
===
match
---
trailer [49111,49119]
trailer [49111,49119]
===
match
---
trailer [86714,86719]
trailer [86765,86770]
===
match
---
trailer [29285,29300]
trailer [29285,29300]
===
match
---
name: timezone [76302,76310]
name: timezone [76353,76361]
===
match
---
if_stmt [65647,65926]
if_stmt [65698,65977]
===
match
---
operator: -> [87661,87663]
operator: -> [87712,87714]
===
match
---
trailer [87403,87410]
trailer [87454,87461]
===
match
---
name: start_date [66759,66769]
name: start_date [66810,66820]
===
match
---
simple_stmt [16567,16601]
simple_stmt [16567,16601]
===
match
---
trailer [95541,95562]
trailer [95592,95613]
===
match
---
or_test [11691,11703]
or_test [11691,11703]
===
match
---
testlist_comp [60162,60217]
testlist_comp [60213,60268]
===
match
---
atom_expr [62892,62901]
atom_expr [62943,62952]
===
match
---
if_stmt [77033,77393]
if_stmt [77084,77444]
===
match
---
name: models [1727,1733]
name: models [1727,1733]
===
match
---
name: warn [72942,72946]
name: warn [72993,72997]
===
match
---
string: 'idx_next_dagrun_create_after' [85757,85787]
string: 'idx_next_dagrun_create_after' [85808,85838]
===
match
---
trailer [23945,23963]
trailer [23945,23963]
===
match
---
atom_expr [12910,12923]
atom_expr [12910,12923]
===
match
---
atom_expr [18154,18176]
atom_expr [18154,18176]
===
match
---
trailer [21012,21041]
trailer [21012,21041]
===
match
---
trailer [16986,16991]
trailer [16986,16991]
===
match
---
atom_expr [64703,64727]
atom_expr [64754,64778]
===
match
---
suite [66690,66723]
suite [66741,66774]
===
match
---
name: sqlalchemy [2478,2488]
name: sqlalchemy [2478,2488]
===
match
---
decorated [31714,32142]
decorated [31714,32142]
===
match
---
name: start_date [25803,25813]
name: start_date [25803,25813]
===
match
---
trailer [82733,82755]
trailer [82784,82806]
===
match
---
trailer [53161,53169]
trailer [53212,53220]
===
match
---
operator: , [56555,56556]
operator: , [56606,56607]
===
match
---
param [31334,31338]
param [31334,31338]
===
match
---
name: do_it [54830,54835]
name: do_it [54881,54886]
===
match
---
trailer [75366,75372]
trailer [75417,75423]
===
match
---
name: croniter [1255,1263]
name: croniter [1255,1263]
===
match
---
expr_stmt [63632,63662]
expr_stmt [63683,63713]
===
match
---
name: now [19242,19245]
name: now [19242,19245]
===
match
---
operator: = [50132,50133]
operator: = [50183,50184]
===
match
---
name: cls [86727,86730]
name: cls [86778,86781]
===
match
---
string: "Creating ORM DAG for %s" [74567,74592]
string: "Creating ORM DAG for %s" [74618,74643]
===
match
---
name: str [45538,45541]
name: str [45538,45541]
===
match
---
trailer [81476,81481]
trailer [81527,81532]
===
match
---
simple_stmt [88208,88402]
simple_stmt [88259,88453]
===
match
---
atom_expr [32515,32545]
atom_expr [32515,32545]
===
match
---
name: provide_session [78976,78991]
name: provide_session [79027,79042]
===
match
---
trailer [90639,90644]
trailer [90690,90695]
===
match
---
string: 'dag.dag_id' [83376,83388]
string: 'dag.dag_id' [83427,83439]
===
match
---
name: dag [76518,76521]
name: dag [76569,76572]
===
match
---
operator: , [45906,45907]
operator: , [45906,45907]
===
match
---
except_clause [89923,89939]
except_clause [89974,89990]
===
match
---
name: cls [77707,77710]
name: cls [77758,77761]
===
match
---
operator: * [93475,93476]
operator: * [93526,93527]
===
match
---
atom_expr [20616,20650]
atom_expr [20616,20650]
===
match
---
name: self [28983,28987]
name: self [28983,28987]
===
match
---
trailer [31086,31091]
trailer [31086,31091]
===
match
---
name: self [42515,42519]
name: self [42515,42519]
===
match
---
operator: -> [31617,31619]
operator: -> [31617,31619]
===
match
---
name: schedule_interval [10027,10044]
name: schedule_interval [10027,10044]
===
match
---
trailer [13730,13761]
trailer [13730,13761]
===
match
---
name: get_next [20279,20287]
name: get_next [20279,20287]
===
match
---
name: dag [77682,77685]
name: dag [77733,77736]
===
match
---
argument [49961,49992]
argument [50012,50043]
===
match
---
name: filter [45822,45828]
name: filter [45822,45828]
===
match
---
atom_expr [88567,88578]
atom_expr [88618,88629]
===
match
---
name: TI [32019,32021]
name: TI [32019,32021]
===
match
---
operator: , [69422,69423]
operator: , [69473,69474]
===
match
---
trailer [65539,65550]
trailer [65590,65601]
===
match
---
name: exception [35336,35345]
name: exception [35336,35345]
===
match
---
string: """         Sets the given edge information on the DAG. Note that this will overwrite,         rather than merge with, existing info.         """ [82926,83071]
string: """         Sets the given edge information on the DAG. Note that this will overwrite,         rather than merge with, existing info.         """ [82977,83122]
===
match
---
operator: , [10582,10583]
operator: , [10582,10583]
===
match
---
name: state [36356,36361]
name: state [36356,36361]
===
match
---
suite [32860,33185]
suite [32860,33185]
===
match
---
atom_expr [77707,77757]
atom_expr [77758,77808]
===
match
---
atom_expr [63700,63729]
atom_expr [63751,63780]
===
match
---
name: dttm [21206,21210]
name: dttm [21206,21210]
===
match
---
name: first [37045,37050]
name: first [37045,37050]
===
match
---
trailer [41195,41228]
trailer [41195,41228]
===
match
---
name: get_last_dagrun [28521,28536]
name: get_last_dagrun [28521,28536]
===
match
---
name: self [21621,21625]
name: self [21621,21625]
===
match
---
comparison [24261,24294]
comparison [24261,24294]
===
match
---
trailer [52471,52477]
trailer [52522,52528]
===
match
---
atom_expr [41619,41637]
atom_expr [41619,41637]
===
match
---
trailer [93660,93667]
trailer [93711,93718]
===
match
---
atom_expr [74411,74438]
atom_expr [74462,74489]
===
match
---
name: x [41787,41788]
name: x [41787,41788]
===
match
---
trailer [25757,25768]
trailer [25757,25768]
===
match
---
atom_expr [62934,62945]
atom_expr [62985,62996]
===
match
---
param [70158,70186]
param [70209,70237]
===
match
---
return_stmt [37971,38070]
return_stmt [37971,38070]
===
match
---
name: is_paused_at_creation [83857,83878]
name: is_paused_at_creation [83908,83929]
===
match
---
trailer [35110,35118]
trailer [35110,35118]
===
match
---
name: include_upstream [58768,58784]
name: include_upstream [58819,58835]
===
match
---
expr_stmt [62266,62361]
expr_stmt [62317,62412]
===
match
---
name: execution_date [71733,71747]
name: execution_date [71784,71798]
===
match
---
atom_expr [40867,40884]
atom_expr [40867,40884]
===
match
---
raise_stmt [63405,63452]
raise_stmt [63456,63503]
===
match
---
name: latest_execution_date [38094,38115]
name: latest_execution_date [38094,38115]
===
match
---
trailer [75983,75990]
trailer [76034,76041]
===
match
---
comparison [37609,37637]
comparison [37609,37637]
===
match
---
comparison [50323,50352]
comparison [50374,50403]
===
match
---
trailer [22231,22240]
trailer [22231,22240]
===
match
---
name: task [66717,66721]
name: task [66768,66772]
===
match
---
name: dag_id [16579,16585]
name: dag_id [16579,16585]
===
match
---
trailer [21908,21918]
trailer [21908,21918]
===
match
---
name: num_active_runs [75297,75312]
name: num_active_runs [75348,75363]
===
match
---
trailer [45086,45103]
trailer [45086,45103]
===
match
---
name: jinja_env_options [39603,39620]
name: jinja_env_options [39603,39620]
===
match
---
name: _schedule_interval [33720,33738]
name: _schedule_interval [33720,33738]
===
match
---
number: 0 [57515,57516]
number: 0 [57566,57567]
===
match
---
param [17300,17305]
param [17300,17305]
===
match
---
name: DagStateChangeCallback [3105,3127]
name: DagStateChangeCallback [3105,3127]
===
match
---
suite [11438,16098]
suite [11438,16098]
===
match
---
name: globals [40229,40236]
name: globals [40229,40236]
===
match
---
atom_expr [23340,23357]
atom_expr [23340,23357]
===
match
---
name: _task_group [30862,30873]
name: _task_group [30862,30873]
===
match
---
name: utcnow [14142,14148]
name: utcnow [14142,14148]
===
match
---
if_stmt [54895,55201]
if_stmt [54946,55252]
===
match
---
import_as_names [2617,2641]
import_as_names [2617,2641]
===
match
---
comparison [75469,75498]
comparison [75520,75549]
===
match
---
trailer [59880,59886]
trailer [59931,59937]
===
match
---
name: description [85049,85060]
name: description [85100,85111]
===
match
---
suite [31182,31305]
suite [31182,31305]
===
match
---
suite [29272,29309]
suite [29272,29309]
===
match
---
name: self [58653,58657]
name: self [58704,58708]
===
match
---
param [56087,56101]
param [56138,56152]
===
match
---
name: DagRun [38032,38038]
name: DagRun [38032,38038]
===
match
---
trailer [39889,39896]
trailer [39889,39896]
===
match
---
suite [68927,69063]
suite [68978,69114]
===
match
---
operator: { [14877,14878]
operator: { [14877,14878]
===
match
---
atom_expr [54563,54572]
atom_expr [54614,54623]
===
match
---
name: is_ [87430,87433]
name: is_ [87481,87484]
===
match
---
name: external_trigger [75567,75583]
name: external_trigger [75618,75634]
===
match
---
expr_stmt [76496,76533]
expr_stmt [76547,76584]
===
match
---
name: start_date [65349,65359]
name: start_date [65400,65410]
===
match
---
dotted_name [2114,2127]
dotted_name [2114,2127]
===
match
---
operator: = [80926,80927]
operator: = [80977,80978]
===
match
---
name: ti [51496,51498]
name: ti [51547,51549]
===
match
---
name: following_schedule [25442,25460]
name: following_schedule [25442,25460]
===
match
---
trailer [10054,10072]
trailer [10054,10072]
===
match
---
name: current_dag [30406,30417]
name: current_dag [30406,30417]
===
match
---
name: pendulum [21770,21778]
name: pendulum [21770,21778]
===
match
---
simple_stmt [33157,33185]
simple_stmt [33157,33185]
===
match
---
atom_expr [85426,85457]
atom_expr [85477,85508]
===
match
---
operator: -> [95418,95420]
operator: -> [95469,95471]
===
match
---
name: all [74111,74114]
name: all [74162,74165]
===
match
---
atom_expr [41562,41584]
atom_expr [41562,41584]
===
match
---
name: dagruns [37802,37809]
name: dagruns [37802,37809]
===
match
---
operator: , [74079,74080]
operator: , [74130,74131]
===
match
---
name: intersection [62841,62853]
name: intersection [62892,62904]
===
match
---
if_stmt [13478,13619]
if_stmt [13478,13619]
===
match
---
comparison [3561,3589]
comparison [3561,3589]
===
match
---
simple_stmt [29542,29570]
simple_stmt [29542,29570]
===
match
---
trailer [76521,76533]
trailer [76572,76584]
===
match
---
funcdef [37112,37810]
funcdef [37112,37810]
===
match
---
trailer [54613,54625]
trailer [54664,54676]
===
match
---
trailer [95221,95242]
trailer [95272,95293]
===
match
---
atom_expr [25908,25923]
atom_expr [25908,25923]
===
match
---
comp_if [42764,42791]
comp_if [42764,42791]
===
match
---
name: run_type [75066,75074]
name: run_type [75117,75125]
===
match
---
operator: = [52864,52865]
operator: = [52915,52916]
===
match
---
name: task_dict [62858,62867]
name: task_dict [62909,62918]
===
match
---
name: _full_filepath [12002,12016]
name: _full_filepath [12002,12016]
===
match
---
parameters [19046,19052]
parameters [19046,19052]
===
match
---
trailer [13748,13760]
trailer [13748,13760]
===
match
---
name: dag_model [89396,89405]
name: dag_model [89447,89456]
===
match
---
operator: = [50514,50515]
operator: = [50565,50566]
===
match
---
string: """         Returns a subset of the current dag as a deep copy of the current dag         based on a regex that should match one or many tasks, and includes         upstream and downstream neighbours based on the flag passed.          :param task_ids_or_regex: Either a list of task_ids, or a regex to             match against task ids (as a string, or compiled regex pattern).         :type task_ids_or_regex: [str] or str or re.Pattern         :param include_downstream: Include all downstream tasks of matched             tasks, in addition to matched tasks.         :param include_upstream: Include all upstream tasks of matched tasks,             in addition to matched tasks.         """ [58845,59539]
string: """         Returns a subset of the current dag as a deep copy of the current dag         based on a regex that should match one or many tasks, and includes         upstream and downstream neighbours based on the flag passed.          :param task_ids_or_regex: Either a list of task_ids, or a regex to             match against task ids (as a string, or compiled regex pattern).         :type task_ids_or_regex: [str] or str or re.Pattern         :param include_downstream: Include all downstream tasks of matched             tasks, in addition to matched tasks.         :param include_upstream: Include all upstream tasks of matched tasks,             in addition to matched tasks.         """ [58896,59590]
===
match
---
operator: = [56666,56667]
operator: = [56717,56718]
===
match
---
atom_expr [12153,12170]
atom_expr [12153,12170]
===
match
---
name: on_failure_callback [15738,15757]
name: on_failure_callback [15738,15757]
===
match
---
simple_stmt [62704,62782]
simple_stmt [62755,62833]
===
match
---
trailer [21620,21635]
trailer [21620,21635]
===
match
---
name: __exit__ [17291,17299]
name: __exit__ [17291,17299]
===
match
---
name: DagRun [75347,75353]
name: DagRun [75398,75404]
===
match
---
operator: @ [77763,77764]
operator: @ [77814,77815]
===
match
---
operator: = [11382,11383]
operator: = [11382,11383]
===
match
---
trailer [12253,12263]
trailer [12253,12263]
===
match
---
name: start_date [25986,25996]
name: start_date [25986,25996]
===
match
---
if_stmt [78197,78347]
if_stmt [78248,78398]
===
match
---
name: default_args [13052,13064]
name: default_args [13052,13064]
===
match
---
operator: , [81593,81594]
operator: , [81644,81645]
===
match
---
name: session [36919,36926]
name: session [36919,36926]
===
match
---
trailer [25980,25997]
trailer [25980,25997]
===
match
---
trailer [62820,62840]
trailer [62871,62891]
===
match
---
name: TaskInstance [42050,42062]
name: TaskInstance [42050,42062]
===
match
---
decorator [29811,29821]
decorator [29811,29821]
===
match
---
annassign [12121,12143]
annassign [12121,12143]
===
match
---
simple_stmt [800,817]
simple_stmt [800,817]
===
match
---
name: orm_dags [74651,74659]
name: orm_dags [74702,74710]
===
match
---
name: log [26016,26019]
name: log [26016,26019]
===
match
---
operator: } [53237,53238]
operator: } [53288,53289]
===
match
---
name: self [28817,28821]
name: self [28817,28821]
===
match
---
name: missing_dag_id [74380,74394]
name: missing_dag_id [74431,74445]
===
match
---
trailer [61244,61246]
trailer [61295,61297]
===
match
---
simple_stmt [38241,38435]
simple_stmt [38241,38435]
===
match
---
name: default_view [85127,85139]
name: default_view [85178,85190]
===
match
---
name: dumps [63608,63613]
name: dumps [63659,63664]
===
match
---
param [42346,42350]
param [42346,42350]
===
match
---
simple_stmt [76023,76077]
simple_stmt [76074,76128]
===
match
---
operator: , [18247,18248]
operator: , [18247,18248]
===
match
---
argument [86001,86009]
argument [86052,86060]
===
match
---
atom_expr [86347,86358]
atom_expr [86398,86409]
===
match
---
atom_expr [71676,71706]
atom_expr [71727,71757]
===
match
---
dotted_name [68945,68978]
dotted_name [68996,69029]
===
match
---
trailer [65895,65925]
trailer [65946,65976]
===
match
---
trailer [11507,11527]
trailer [11507,11527]
===
match
---
simple_stmt [65681,65711]
simple_stmt [65732,65762]
===
match
---
tfpdef [70195,70225]
tfpdef [70246,70276]
===
match
---
operator: , [49670,49671]
operator: , [49721,49722]
===
match
---
atom_expr [60754,60763]
atom_expr [60805,60814]
===
match
---
name: task_ids_or_regex [60088,60105]
name: task_ids_or_regex [60139,60156]
===
match
---
atom_expr [76355,76371]
atom_expr [76406,76422]
===
match
---
atom_expr [2866,2883]
atom_expr [2866,2883]
===
match
---
trailer [39949,39961]
trailer [39949,39961]
===
match
---
expr_stmt [24727,24749]
expr_stmt [24727,24749]
===
match
---
import_from [2352,2408]
import_from [2352,2408]
===
match
---
strings [52021,52209]
strings [52072,52260]
===
match
---
arglist [80541,80571]
arglist [80592,80622]
===
match
---
operator: , [39732,39733]
operator: , [39732,39733]
===
match
---
if_stmt [44969,45132]
if_stmt [44969,45132]
===
match
---
name: task_start_dates [25217,25233]
name: task_start_dates [25217,25233]
===
match
---
trailer [69839,69850]
trailer [69890,69901]
===
match
---
name: normalize_schedule [27757,27775]
name: normalize_schedule [27757,27775]
===
match
---
name: state [42103,42108]
name: state [42103,42108]
===
match
---
name: self [19047,19051]
name: self [19047,19051]
===
match
---
trailer [40953,41004]
trailer [40953,41004]
===
match
---
name: in_ [50615,50618]
name: in_ [50666,50669]
===
match
---
expr_stmt [50823,50844]
expr_stmt [50874,50895]
===
match
---
trailer [88447,88454]
trailer [88498,88505]
===
match
---
simple_stmt [38667,38719]
simple_stmt [38667,38719]
===
match
---
operator: , [84166,84167]
operator: , [84217,84218]
===
match
---
name: Optional [11367,11375]
name: Optional [11367,11375]
===
match
---
name: dag [48938,48941]
name: dag [48938,48941]
===
match
---
atom_expr [56064,56077]
atom_expr [56115,56128]
===
match
---
argument [86917,86932]
argument [86968,86983]
===
match
---
not_test [52999,53015]
not_test [53050,53066]
===
match
---
if_stmt [50894,54504]
if_stmt [50945,54555]
===
match
---
operator: , [88065,88066]
operator: , [88116,88117]
===
match
---
if_stmt [50281,50354]
if_stmt [50332,50405]
===
match
---
decorated [37091,37810]
decorated [37091,37810]
===
match
---
param [11199,11229]
param [11199,11229]
===
match
---
operator: } [14610,14611]
operator: } [14610,14611]
===
match
---
name: getattr [16399,16406]
name: getattr [16399,16406]
===
match
---
suite [21661,21866]
suite [21661,21866]
===
match
---
name: intersection [62214,62226]
name: intersection [62265,62277]
===
match
---
name: DateTime [22232,22240]
name: DateTime [22232,22240]
===
match
---
param [67144,67164]
param [67195,67215]
===
match
---
name: self [31285,31289]
name: self [31285,31289]
===
match
---
name: self [31611,31615]
name: self [31611,31615]
===
match
---
name: info [83150,83154]
name: info [83201,83205]
===
match
---
name: Pattern [2784,2791]
name: Pattern [2784,2791]
===
match
---
operator: , [67058,67059]
operator: , [67109,67110]
===
match
---
trailer [42108,42112]
trailer [42108,42112]
===
match
---
param [63474,63478]
param [63525,63529]
===
match
---
name: only_running [57270,57282]
name: only_running [57321,57333]
===
match
---
trailer [49108,49139]
trailer [49108,49139]
===
match
---
fstring_end: " [53239,53240]
fstring_end: " [53290,53291]
===
match
---
trailer [63040,63048]
trailer [63091,63099]
===
match
---
trailer [31019,31027]
trailer [31019,31027]
===
match
---
name: __lt__ [16538,16544]
name: __lt__ [16538,16544]
===
match
---
trailer [75895,75906]
trailer [75946,75957]
===
match
---
name: State [69957,69962]
name: State [70008,70013]
===
match
---
name: self [25859,25863]
name: self [25859,25863]
===
match
---
name: __serialized_fields [82331,82350]
name: __serialized_fields [82382,82401]
===
match
---
trailer [76465,76483]
trailer [76516,76534]
===
match
---
operator: , [10229,10230]
operator: , [10229,10230]
===
match
---
name: tis [50510,50513]
name: tis [50561,50564]
===
match
---
trailer [77323,77330]
trailer [77374,77381]
===
match
---
name: task_group [2684,2694]
name: task_group [2684,2694]
===
match
---
name: configuration [1559,1572]
name: configuration [1559,1572]
===
match
---
name: concurrency [86065,86076]
name: concurrency [86116,86127]
===
match
---
operator: , [88126,88127]
operator: , [88177,88178]
===
match
---
decorated [34013,35446]
decorated [34013,35446]
===
match
---
name: bool [31620,31624]
name: bool [31620,31624]
===
match
---
trailer [39443,39450]
trailer [39443,39450]
===
match
---
name: append [95291,95297]
name: append [95342,95348]
===
match
---
name: synchronize_session [88692,88711]
name: synchronize_session [88743,88762]
===
match
---
name: val [30594,30597]
name: val [30594,30597]
===
match
---
name: t [26475,26476]
name: t [26475,26476]
===
match
---
expr_stmt [11615,11668]
expr_stmt [11615,11668]
===
match
---
decorator [92729,92749]
decorator [92780,92800]
===
match
---
name: _pickle_id [30059,30069]
name: _pickle_id [30059,30069]
===
match
---
name: delta [20368,20373]
name: delta [20368,20373]
===
match
---
name: kwargs [58612,58618]
name: kwargs [58663,58669]
===
match
---
name: min_task_end_date [26649,26666]
name: min_task_end_date [26649,26666]
===
match
---
operator: = [80619,80620]
operator: = [80670,80671]
===
match
---
parameters [37865,37885]
parameters [37865,37885]
===
match
---
name: ScheduleInterval [33255,33271]
name: ScheduleInterval [33255,33271]
===
match
---
name: _previous_context_managed_dags [95494,95524]
name: _previous_context_managed_dags [95545,95575]
===
match
---
arglist [19272,19310]
arglist [19272,19310]
===
match
---
name: timezone [2167,2175]
name: timezone [2167,2175]
===
match
---
tfpdef [10194,10222]
tfpdef [10194,10222]
===
match
---
simple_stmt [32508,32546]
simple_stmt [32508,32546]
===
match
---
name: date_last_automated_dagrun [25068,25094]
name: date_last_automated_dagrun [25068,25094]
===
match
---
trailer [19469,19474]
trailer [19469,19474]
===
match
---
suite [80602,80699]
suite [80653,80750]
===
match
---
trailer [79733,79735]
trailer [79784,79786]
===
match
---
decorator [37815,37832]
decorator [37815,37832]
===
match
---
name: Optional [70073,70081]
name: Optional [70124,70132]
===
match
---
name: executors [68815,68824]
name: executors [68866,68875]
===
match
---
trailer [56069,56077]
trailer [56120,56128]
===
match
---
name: task_id [52584,52591]
name: task_id [52635,52642]
===
match
---
suite [13162,13319]
suite [13162,13319]
===
match
---
testlist_comp [85690,85829]
testlist_comp [85741,85880]
===
match
---
tfpdef [22113,22168]
tfpdef [22113,22168]
===
match
---
name: Optional [70205,70213]
name: Optional [70256,70264]
===
match
---
name: ALLOW_FUTURE_EXEC_DATES [31650,31673]
name: ALLOW_FUTURE_EXEC_DATES [31650,31673]
===
match
---
operator: -> [91173,91175]
operator: -> [91224,91226]
===
match
---
return_stmt [56776,56784]
return_stmt [56827,56835]
===
match
---
suite [64466,64788]
suite [64517,64839]
===
match
---
simple_stmt [14035,14106]
simple_stmt [14035,14106]
===
match
---
name: TIMEZONE [86425,86433]
name: TIMEZONE [86476,86484]
===
match
---
name: task [66023,66027]
name: task [66074,66078]
===
match
---
operator: , [11331,11332]
operator: , [11331,11332]
===
match
---
if_stmt [23031,23181]
if_stmt [23031,23181]
===
match
---
suite [64106,64195]
suite [64157,64246]
===
match
---
trailer [66001,66015]
trailer [66052,66066]
===
match
---
decorator [29396,29416]
decorator [29396,29416]
===
match
---
name: now [90802,90805]
name: now [90853,90856]
===
match
---
atom_expr [15809,15829]
atom_expr [15809,15829]
===
match
---
simple_stmt [91190,91494]
simple_stmt [91241,91545]
===
match
---
name: self [28691,28695]
name: self [28691,28695]
===
match
---
operator: , [18954,18955]
operator: , [18954,18955]
===
match
---
name: default_args [13680,13692]
name: default_args [13680,13692]
===
match
---
name: get_current [86646,86657]
name: get_current [86697,86708]
===
match
---
operator: , [72367,72368]
operator: , [72418,72419]
===
match
---
expr_stmt [93905,93918]
expr_stmt [93956,93969]
===
match
---
name: task [65831,65835]
name: task [65882,65886]
===
match
---
name: create_root [16080,16091]
name: create_root [16080,16091]
===
match
---
operator: , [86501,86502]
operator: , [86552,86553]
===
match
---
name: tags [76872,76876]
name: tags [76923,76927]
===
match
---
suite [38775,39128]
suite [38775,39128]
===
match
---
operator: = [61033,61034]
operator: = [61084,61085]
===
match
---
arglist [83349,83407]
arglist [83400,83458]
===
match
---
import_name [1218,1233]
import_name [1218,1233]
===
match
---
simple_stmt [26457,26521]
simple_stmt [26457,26521]
===
match
---
trailer [63217,63227]
trailer [63268,63278]
===
match
---
name: state [72387,72392]
name: state [72438,72443]
===
match
---
operator: , [57902,57903]
operator: , [57953,57954]
===
match
---
trailer [62556,62558]
trailer [62607,62609]
===
match
---
exprlist [93939,93950]
exprlist [93990,94001]
===
match
---
atom_expr [75700,75740]
atom_expr [75751,75791]
===
match
---
fstring_string: Task id ' [66131,66140]
fstring_string: Task id ' [66182,66191]
===
match
---
trailer [19736,19776]
trailer [19736,19776]
===
match
---
and_test [26194,26259]
and_test [26194,26259]
===
match
---
name: state [41964,41969]
name: state [41964,41969]
===
match
---
name: pendulum [52667,52675]
name: pendulum [52718,52726]
===
match
---
name: user_defined_macros [11530,11549]
name: user_defined_macros [11530,11549]
===
match
---
name: Boolean [85433,85440]
name: Boolean [85484,85491]
===
match
---
name: end_date [56239,56247]
name: end_date [56290,56298]
===
match
---
expr_stmt [22871,22948]
expr_stmt [22871,22948]
===
match
---
expr_stmt [65326,65359]
expr_stmt [65377,65410]
===
match
---
name: self [35471,35475]
name: self [35471,35475]
===
match
---
simple_stmt [40921,41005]
simple_stmt [40921,41005]
===
match
---
name: also_include [60431,60443]
name: also_include [60482,60494]
===
match
---
name: session [28563,28570]
name: session [28563,28570]
===
match
---
atom_expr [22194,22211]
atom_expr [22194,22211]
===
match
---
trailer [58390,58567]
trailer [58441,58618]
===
match
---
not_test [21430,21463]
not_test [21430,21463]
===
match
---
operator: , [91141,91142]
operator: , [91192,91193]
===
match
---
name: max_active_runs [14240,14255]
name: max_active_runs [14240,14255]
===
match
---
trailer [26216,26225]
trailer [26216,26225]
===
match
---
fstring_start: f" [16138,16140]
fstring_start: f" [16138,16140]
===
match
---
suite [16229,16445]
suite [16229,16445]
===
match
---
trailer [21461,21463]
trailer [21461,21463]
===
match
---
operator: = [41842,41843]
operator: = [41842,41843]
===
match
---
simple_stmt [95760,95792]
simple_stmt [95811,95843]
===
match
---
operator: , [18935,18936]
operator: , [18935,18936]
===
match
---
comparison [13630,13661]
comparison [13630,13661]
===
match
---
atom_expr [51409,51445]
atom_expr [51460,51496]
===
match
---
name: DagPickle [64156,64165]
name: DagPickle [64207,64216]
===
match
---
name: len [78722,78725]
name: len [78773,78776]
===
match
---
operator: , [31054,31055]
operator: , [31054,31055]
===
match
---
return_stmt [36519,36540]
return_stmt [36519,36540]
===
match
---
name: cls [81379,81382]
name: cls [81430,81433]
===
match
---
name: _task_group [16056,16067]
name: _task_group [16056,16067]
===
match
---
atom_expr [32801,32819]
atom_expr [32801,32819]
===
match
---
name: k [57825,57826]
name: k [57876,57877]
===
match
---
operator: = [75967,75968]
operator: = [76018,76019]
===
match
---
expr_stmt [13927,13973]
expr_stmt [13927,13973]
===
match
---
atom_expr [34803,34827]
atom_expr [34803,34827]
===
match
---
name: os [31269,31271]
name: os [31269,31271]
===
match
---
trailer [12131,12136]
trailer [12131,12136]
===
match
---
name: all_tis [56643,56650]
name: all_tis [56694,56701]
===
match
---
atom_expr [66218,66246]
atom_expr [66269,66297]
===
match
---
if_stmt [89393,89886]
if_stmt [89444,89937]
===
match
---
atom_expr [13771,13793]
atom_expr [13771,13793]
===
match
---
name: DAG [95201,95204]
name: DAG [95252,95255]
===
match
---
arith_expr [54153,54172]
arith_expr [54204,54223]
===
match
---
operator: = [9915,9916]
operator: = [9915,9916]
===
match
---
name: task [65513,65517]
name: task [65564,65568]
===
match
---
operator: } [56950,56951]
operator: } [57001,57002]
===
match
---
string: 'template_searchpath' [9812,9833]
string: 'template_searchpath' [9812,9833]
===
match
---
trailer [38000,38023]
trailer [38000,38023]
===
match
---
atom_expr [64156,64168]
atom_expr [64207,64219]
===
match
---
arglist [18914,19004]
arglist [18914,19004]
===
match
---
argument [50075,50090]
argument [50126,50141]
===
match
---
operator: = [45374,45375]
operator: = [45374,45375]
===
match
---
name: session [77741,77748]
name: session [77792,77799]
===
match
---
simple_stmt [19488,19500]
simple_stmt [19488,19500]
===
match
---
name: value [29707,29712]
name: value [29707,29712]
===
match
---
comparison [23034,23067]
comparison [23034,23067]
===
match
---
atom_expr [11900,11927]
atom_expr [11900,11927]
===
match
---
suite [43743,45255]
suite [43743,45255]
===
match
---
name: EdgeInfoType [82431,82443]
name: EdgeInfoType [82482,82494]
===
match
---
name: session [86917,86924]
name: session [86968,86975]
===
match
---
trailer [75954,75966]
trailer [76005,76017]
===
match
---
operator: , [54381,54382]
operator: , [54432,54433]
===
match
---
trailer [61792,61808]
trailer [61843,61859]
===
match
---
atom_expr [76462,76483]
atom_expr [76513,76534]
===
match
---
name: self [13069,13073]
name: self [13069,13073]
===
match
---
atom_expr [30490,30508]
atom_expr [30490,30508]
===
match
---
string: 'jinja_environment_kwargs' [82086,82112]
string: 'jinja_environment_kwargs' [82137,82163]
===
match
---
name: all [87504,87507]
name: all [87555,87558]
===
match
---
operator: , [1451,1452]
operator: , [1451,1452]
===
match
---
name: timezone [21998,22006]
name: timezone [21998,22006]
===
match
---
name: filter_query [88523,88535]
name: filter_query [88574,88586]
===
match
---
sync_comp_for [76619,76637]
sync_comp_for [76670,76688]
===
match
---
trailer [71778,71800]
trailer [71829,71851]
===
match
---
expr_stmt [15412,15467]
expr_stmt [15412,15467]
===
match
---
atom_expr [40618,40699]
atom_expr [40618,40699]
===
match
---
atom_expr [35142,35182]
atom_expr [35142,35182]
===
match
---
trailer [55750,55757]
trailer [55801,55808]
===
match
---
name: on_failure_callback [15154,15173]
name: on_failure_callback [15154,15173]
===
match
---
comparison [79451,79494]
comparison [79502,79545]
===
match
---
trailer [79566,79750]
trailer [79617,79801]
===
match
---
name: query [89306,89311]
name: query [89357,89362]
===
match
---
operator: = [61410,61411]
operator: = [61461,61462]
===
match
---
trailer [78799,78809]
trailer [78850,78860]
===
match
---
operator: , [55559,55560]
operator: , [55610,55611]
===
match
---
atom_expr [79763,79776]
atom_expr [79814,79827]
===
match
---
atom_expr [50912,50939]
atom_expr [50963,50990]
===
match
---
atom_expr [12344,12358]
atom_expr [12344,12358]
===
match
---
name: dag [76171,76174]
name: dag [76222,76225]
===
match
---
suite [37178,37810]
suite [37178,37810]
===
match
---
simple_stmt [894,910]
simple_stmt [894,910]
===
match
---
name: self [32763,32767]
name: self [32763,32767]
===
match
---
name: start_date [65302,65312]
name: start_date [65353,65363]
===
match
---
name: max_active_runs [10612,10627]
name: max_active_runs [10612,10627]
===
match
---
operator: = [13705,13706]
operator: = [13705,13706]
===
match
---
operator: = [2939,2940]
operator: = [2939,2940]
===
match
---
atom_expr [17092,17114]
atom_expr [17092,17114]
===
match
---
atom_expr [3561,3580]
atom_expr [3561,3580]
===
match
---
comparison [49193,49220]
comparison [49193,49220]
===
match
---
name: self [63614,63618]
name: self [63665,63669]
===
match
---
param [37142,37153]
param [37142,37153]
===
match
---
name: task_dict [63218,63227]
name: task_dict [63269,63278]
===
match
---
funcdef [33204,34008]
funcdef [33204,34008]
===
match
---
parameters [73240,73284]
parameters [73291,73335]
===
match
---
atom [35210,35228]
atom [35210,35228]
===
match
---
operator: , [58657,58658]
operator: , [58708,58709]
===
match
---
comparison [38981,39015]
comparison [38981,39015]
===
match
---
trailer [42359,42373]
trailer [42359,42373]
===
match
---
operator: , [81952,81953]
operator: , [82003,82004]
===
match
---
param [10102,10140]
param [10102,10140]
===
match
---
name: session [78073,78080]
name: session [78124,78131]
===
match
---
operator: , [94034,94035]
operator: , [94085,94086]
===
match
---
expr_stmt [84037,84079]
expr_stmt [84088,84130]
===
match
---
suite [62588,62876]
suite [62639,62927]
===
match
---
comparison [50897,50939]
comparison [50948,50990]
===
match
---
param [46019,46035]
param [46019,46035]
===
match
---
trailer [52686,52701]
trailer [52737,52752]
===
match
---
trailer [20624,20639]
trailer [20624,20639]
===
match
---
name: airflow [1590,1597]
name: airflow [1590,1597]
===
match
---
param [55929,55948]
param [55980,55999]
===
match
---
operator: += [60444,60446]
operator: += [60495,60497]
===
match
---
name: TaskInstance [41171,41183]
name: TaskInstance [41171,41183]
===
match
---
simple_stmt [64956,65074]
simple_stmt [65007,65125]
===
match
---
name: DagParam [30127,30135]
name: DagParam [30127,30135]
===
match
---
if_stmt [22958,23022]
if_stmt [22958,23022]
===
match
---
operator: , [26765,26766]
operator: , [26765,26766]
===
match
---
operator: @ [31569,31570]
operator: @ [31569,31570]
===
match
---
atom_expr [95332,95356]
atom_expr [95383,95407]
===
match
---
name: next_run_date [25032,25045]
name: next_run_date [25032,25045]
===
match
---
name: first [64047,64052]
name: first [64098,64103]
===
match
---
name: task_dict [16824,16833]
name: task_dict [16824,16833]
===
match
---
trailer [83094,83105]
trailer [83145,83156]
===
match
---
expr_stmt [59785,59804]
expr_stmt [59836,59855]
===
match
---
name: name [94008,94012]
name: name [94059,94063]
===
match
---
param [28449,28454]
param [28449,28454]
===
match
---
name: self [24056,24060]
name: self [24056,24060]
===
match
---
expr_stmt [55671,55680]
expr_stmt [55722,55731]
===
match
---
atom_expr [28521,28647]
atom_expr [28521,28647]
===
match
---
trailer [90965,91029]
trailer [91016,91080]
===
match
---
operator: @ [87990,87991]
operator: @ [88041,88042]
===
match
---
trailer [50526,50553]
trailer [50577,50604]
===
match
---
simple_stmt [49092,49140]
simple_stmt [49092,49140]
===
match
---
operator: -> [29078,29080]
operator: -> [29078,29080]
===
match
---
operator: = [49758,49759]
operator: = [49809,49810]
===
match
---
name: executor [68874,68882]
name: executor [68925,68933]
===
match
---
dotted_name [2552,2571]
dotted_name [2552,2571]
===
match
---
atom_expr [61412,61440]
atom_expr [61463,61491]
===
match
---
name: execution_date [37715,37729]
name: execution_date [37715,37729]
===
match
---
atom_expr [30525,30554]
atom_expr [30525,30554]
===
match
---
atom_expr [32763,32774]
atom_expr [32763,32774]
===
match
---
name: existing_dag_ids [75434,75450]
name: existing_dag_ids [75485,75501]
===
match
---
name: naive [20300,20305]
name: naive [20300,20305]
===
match
---
comparison [64156,64185]
comparison [64207,64236]
===
match
---
atom_expr [41487,41514]
atom_expr [41487,41514]
===
match
---
operator: -> [63139,63141]
operator: -> [63190,63192]
===
match
---
name: ExternalTaskMarker [50713,50731]
name: ExternalTaskMarker [50764,50782]
===
match
---
atom_expr [49067,49078]
atom_expr [49067,49078]
===
match
---
expr_stmt [21224,21272]
expr_stmt [21224,21272]
===
match
---
atom_expr [35744,35783]
atom_expr [35744,35783]
===
match
---
name: dagrun [34060,34066]
name: dagrun [34060,34066]
===
match
---
name: tags [73956,73960]
name: tags [74007,74011]
===
match
---
trailer [64218,64225]
trailer [64269,64276]
===
match
---
atom_expr [32744,32759]
atom_expr [32744,32759]
===
match
---
name: DagContext [17220,17230]
name: DagContext [17220,17230]
===
match
---
name: session [28830,28837]
name: session [28830,28837]
===
match
---
trailer [17978,17994]
trailer [17978,17994]
===
match
---
name: list [44584,44588]
name: list [44584,44588]
===
match
---
name: state [35659,35664]
name: state [35659,35664]
===
match
---
arglist [61898,61920]
arglist [61949,61971]
===
match
---
operator: == [32760,32762]
operator: == [32760,32762]
===
match
---
operator: -> [30912,30914]
operator: -> [30912,30914]
===
match
---
simple_stmt [32637,32699]
simple_stmt [32637,32699]
===
match
---
simple_stmt [24784,24831]
simple_stmt [24784,24831]
===
match
---
atom_expr [88543,88563]
atom_expr [88594,88614]
===
match
---
trailer [21625,21634]
trailer [21625,21634]
===
match
---
atom_expr [36265,36277]
atom_expr [36265,36277]
===
match
---
operator: = [25046,25047]
operator: = [25046,25047]
===
match
---
name: stacklevel [38411,38421]
name: stacklevel [38411,38421]
===
match
---
name: task [64556,64560]
name: task [64607,64611]
===
match
---
name: TI [31986,31988]
name: TI [31986,31988]
===
match
---
arglist [25345,25393]
arglist [25345,25393]
===
match
---
operator: , [41157,41158]
operator: , [41157,41158]
===
match
---
operator: = [63698,63699]
operator: = [63749,63750]
===
match
---
trailer [20517,20537]
trailer [20517,20537]
===
match
---
name: self [63474,63478]
name: self [63525,63529]
===
match
---
name: schedule_interval [33763,33780]
name: schedule_interval [33763,33780]
===
match
---
name: not_none_state [41935,41949]
name: not_none_state [41935,41949]
===
match
---
name: args [92770,92774]
name: args [92821,92825]
===
match
---
trailer [28536,28647]
trailer [28536,28647]
===
match
---
name: start_date [40853,40863]
name: start_date [40853,40863]
===
match
---
name: Set [87117,87120]
name: Set [87168,87171]
===
match
---
comparison [32109,32141]
comparison [32109,32141]
===
match
---
trailer [42062,42068]
trailer [42062,42068]
===
match
---
name: query [31969,31974]
name: query [31969,31974]
===
match
---
trailer [63879,63881]
trailer [63930,63932]
===
match
---
tfpdef [95196,95204]
tfpdef [95247,95255]
===
match
---
name: fileloc [75882,75889]
name: fileloc [75933,75940]
===
match
---
name: end_date [41359,41367]
name: end_date [41359,41367]
===
match
---
name: print [64584,64589]
name: print [64635,64640]
===
match
---
atom_expr [42515,42525]
atom_expr [42515,42525]
===
match
---
name: convert_to_utc [13571,13585]
name: convert_to_utc [13571,13585]
===
match
---
name: task_group [30809,30819]
name: task_group [30809,30819]
===
match
---
atom_expr [70205,70225]
atom_expr [70256,70276]
===
match
---
tfpdef [10612,10632]
tfpdef [10612,10632]
===
match
---
expr_stmt [14264,14300]
expr_stmt [14264,14300]
===
match
---
name: end_date [50284,50292]
name: end_date [50335,50343]
===
match
---
name: property [42323,42331]
name: property [42323,42331]
===
match
---
expr_stmt [61777,61825]
expr_stmt [61828,61876]
===
match
---
import_from [1669,1713]
import_from [1669,1713]
===
match
---
expr_stmt [35132,35182]
expr_stmt [35132,35182]
===
match
---
name: self [60063,60067]
name: self [60114,60118]
===
match
---
trailer [19934,19940]
trailer [19934,19940]
===
match
---
operator: , [69578,69579]
operator: , [69629,69630]
===
match
---
atom_expr [64216,64225]
atom_expr [64267,64276]
===
match
---
trailer [64395,64405]
trailer [64446,64456]
===
match
---
arith_expr [20754,20794]
arith_expr [20754,20794]
===
match
---
operator: , [78433,78434]
operator: , [78484,78485]
===
match
---
name: dag_bag [50083,50090]
name: dag_bag [50134,50141]
===
match
---
name: kwargs [93514,93520]
name: kwargs [93565,93571]
===
match
---
simple_stmt [20554,20597]
simple_stmt [20554,20597]
===
match
---
trailer [75346,75378]
trailer [75397,75429]
===
match
---
simple_stmt [87607,87629]
simple_stmt [87658,87680]
===
match
---
trailer [72557,72559]
trailer [72608,72610]
===
match
---
atom_expr [71919,71967]
atom_expr [71970,72018]
===
match
---
trailer [42262,42291]
trailer [42262,42291]
===
match
---
name: of [74081,74083]
name: of [74132,74134]
===
match
---
name: dag_bag [50075,50082]
name: dag_bag [50126,50133]
===
match
---
name: qry [80621,80624]
name: qry [80672,80675]
===
match
---
name: visited_external_tis [54471,54491]
name: visited_external_tis [54522,54542]
===
match
---
name: t [54951,54952]
name: t [55002,55003]
===
match
---
name: run_type [71502,71510]
name: run_type [71553,71561]
===
match
---
operator: , [21256,21257]
operator: , [21256,21257]
===
match
---
atom_expr [90797,90807]
atom_expr [90848,90858]
===
match
---
if_stmt [94358,94525]
if_stmt [94409,94576]
===
match
---
trailer [3138,3155]
trailer [3138,3155]
===
match
---
name: dag_id [36983,36989]
name: dag_id [36983,36989]
===
match
---
name: session [32713,32720]
name: session [32713,32720]
===
match
---
atom_expr [81027,81101]
atom_expr [81078,81152]
===
match
---
trailer [35165,35182]
trailer [35165,35182]
===
match
---
simple_stmt [85189,85226]
simple_stmt [85240,85277]
===
match
---
funcdef [88004,88078]
funcdef [88055,88129]
===
match
---
simple_stmt [44835,44850]
simple_stmt [44835,44850]
===
match
---
simple_stmt [27359,27385]
simple_stmt [27359,27385]
===
match
---
trailer [71588,71640]
trailer [71639,71691]
===
match
---
operator: , [25857,25858]
operator: , [25857,25858]
===
match
---
operator: = [79945,79946]
operator: = [79996,79997]
===
match
---
operator: -> [30124,30126]
operator: -> [30124,30126]
===
match
---
trailer [62450,62455]
trailer [62501,62506]
===
match
---
simple_stmt [30928,30988]
simple_stmt [30928,30988]
===
match
---
arglist [58188,58200]
arglist [58239,58251]
===
match
---
operator: , [29255,29256]
operator: , [29255,29256]
===
match
---
atom_expr [80541,80560]
atom_expr [80592,80611]
===
match
---
atom [73786,73819]
atom [73837,73870]
===
match
---
atom_expr [93088,93122]
atom_expr [93139,93173]
===
match
---
name: str [82892,82895]
name: str [82943,82946]
===
match
---
suite [29357,29391]
suite [29357,29391]
===
match
---
operator: , [74592,74593]
operator: , [74643,74644]
===
match
---
simple_stmt [23995,24007]
simple_stmt [23995,24007]
===
match
---
fstring [14875,14922]
fstring [14875,14922]
===
match
---
name: has_task_concurrency_limits [86263,86290]
name: has_task_concurrency_limits [86314,86341]
===
match
---
name: session [49029,49036]
name: session [49029,49036]
===
match
---
param [66941,66964]
param [66992,67015]
===
match
---
comparison [89396,89425]
comparison [89447,89476]
===
match
---
atom_expr [54947,54953]
atom_expr [54998,55004]
===
match
---
trailer [41027,41033]
trailer [41027,41033]
===
match
---
name: datetime [45453,45461]
name: datetime [45453,45461]
===
match
---
atom_expr [12123,12136]
atom_expr [12123,12136]
===
match
---
name: session [36604,36611]
name: session [36604,36611]
===
match
---
name: tree_view [64442,64451]
name: tree_view [64493,64502]
===
match
---
operator: , [34080,34081]
operator: , [34080,34081]
===
match
---
name: cron [19373,19377]
name: cron [19373,19377]
===
match
---
name: session [55291,55298]
name: session [55342,55349]
===
match
---
testlist_comp [57881,57944]
testlist_comp [57932,57995]
===
match
---
atom_expr [85063,85075]
atom_expr [85114,85126]
===
match
---
name: orm_dag [76111,76118]
name: orm_dag [76162,76169]
===
match
---
trailer [62358,62360]
trailer [62409,62411]
===
match
---
name: upstream_list [60559,60572]
name: upstream_list [60610,60623]
===
match
---
name: airflow [1901,1908]
name: airflow [1901,1908]
===
match
---
operator: = [62946,62947]
operator: = [62997,62998]
===
match
---
term [64591,64606]
term [64642,64657]
===
match
---
string: 'core' [83897,83903]
string: 'core' [83948,83954]
===
match
---
return_stmt [63020,63069]
return_stmt [63071,63120]
===
match
---
decorated [81240,82351]
decorated [81291,82402]
===
match
---
operator: , [72814,72815]
operator: , [72865,72866]
===
match
---
operator: { [12386,12387]
operator: { [12386,12387]
===
match
---
suite [89376,89886]
suite [89427,89937]
===
match
---
name: stacklevel [18563,18573]
name: stacklevel [18563,18573]
===
match
---
if_stmt [19723,20796]
if_stmt [19723,20796]
===
match
---
simple_stmt [2352,2409]
simple_stmt [2352,2409]
===
match
---
name: self [14159,14163]
name: self [14159,14163]
===
match
---
name: self [12106,12110]
name: self [12106,12110]
===
match
---
number: 0 [56722,56723]
number: 0 [56773,56774]
===
match
---
atom_expr [41783,41812]
atom_expr [41783,41812]
===
match
---
name: acyclic [45152,45159]
name: acyclic [45152,45159]
===
match
---
atom_expr [83449,83458]
atom_expr [83500,83509]
===
match
---
param [45524,45550]
param [45524,45550]
===
match
---
argument [35639,35657]
argument [35639,35657]
===
match
---
name: self [15657,15661]
name: self [15657,15661]
===
match
---
trailer [16686,16693]
trailer [16686,16693]
===
match
---
name: airflow [1989,1996]
name: airflow [1989,1996]
===
match
---
name: dagpickle [1916,1925]
name: dagpickle [1916,1925]
===
match
---
name: run_id [72206,72212]
name: run_id [72257,72263]
===
match
---
operator: @ [88760,88761]
operator: @ [88811,88812]
===
match
---
comparison [75059,75098]
comparison [75110,75149]
===
match
---
name: env [39937,39940]
name: env [39937,39940]
===
match
---
operator: @ [79850,79851]
operator: @ [79901,79902]
===
match
---
operator: , [34093,34094]
operator: , [34093,34094]
===
match
---
trailer [12857,12875]
trailer [12857,12875]
===
match
---
name: deactivate_deleted_dags [88802,88825]
name: deactivate_deleted_dags [88853,88876]
===
match
---
fstring_string: > [16159,16160]
fstring_string: > [16159,16160]
===
match
---
name: concurrency [76522,76533]
name: concurrency [76573,76584]
===
match
---
decorated [29811,29890]
decorated [29811,29890]
===
match
---
atom_expr [20997,21047]
atom_expr [20997,21047]
===
match
---
trailer [41572,41584]
trailer [41572,41584]
===
match
---
simple_stmt [42244,42298]
simple_stmt [42244,42298]
===
match
---
operator: == [24284,24286]
operator: == [24284,24286]
===
match
---
param [23303,23358]
param [23303,23358]
===
match
---
name: date_range [2222,2232]
name: date_range [2222,2232]
===
match
---
trailer [75154,75169]
trailer [75205,75220]
===
match
---
name: utils [1540,1545]
name: utils [1540,1545]
===
match
---
suite [54865,54887]
suite [54916,54938]
===
match
---
operator: , [1399,1400]
operator: , [1399,1400]
===
match
---
name: in_ [41192,41195]
name: in_ [41192,41195]
===
match
---
atom_expr [16574,16585]
atom_expr [16574,16585]
===
match
---
name: DagRun [37609,37615]
name: DagRun [37609,37615]
===
match
---
trailer [35638,35679]
trailer [35638,35679]
===
match
---
name: Optional [9997,10005]
name: Optional [9997,10005]
===
match
---
sync_comp_for [74161,74184]
sync_comp_for [74212,74235]
===
match
---
operator: -> [82428,82430]
operator: -> [82479,82481]
===
match
---
param [66784,66798]
param [66835,66849]
===
match
---
trailer [18900,19014]
trailer [18900,19014]
===
match
---
atom_expr [86022,86038]
atom_expr [86073,86089]
===
match
---
name: only_running [56328,56340]
name: only_running [56379,56391]
===
match
---
operator: == [37623,37625]
operator: == [37623,37625]
===
match
---
trailer [90848,90873]
trailer [90899,90924]
===
match
---
name: result [57971,57977]
name: result [58022,58028]
===
match
---
name: session [34095,34102]
name: session [34095,34102]
===
match
---
string: 'end_date' [13144,13154]
string: 'end_date' [13144,13154]
===
match
---
operator: , [56378,56379]
operator: , [56429,56430]
===
match
---
name: f_sig [93954,93959]
name: f_sig [94005,94010]
===
match
---
operator: , [30097,30098]
operator: , [30097,30098]
===
match
---
name: orm_tag [76848,76855]
name: orm_tag [76899,76906]
===
match
---
atom_expr [61267,61298]
atom_expr [61318,61349]
===
match
---
name: Collection [1075,1085]
name: Collection [1075,1085]
===
match
---
name: default_view [76359,76371]
name: default_view [76410,76422]
===
match
---
atom_expr [32032,32043]
atom_expr [32032,32043]
===
match
---
operator: } [82818,82819]
operator: } [82869,82870]
===
match
---
atom_expr [83713,83735]
atom_expr [83764,83786]
===
match
---
name: dag_id [53098,53104]
name: dag_id [53149,53155]
===
match
---
name: ValueError [71824,71834]
name: ValueError [71875,71885]
===
match
---
expr_stmt [81158,81206]
expr_stmt [81209,81257]
===
match
---
simple_stmt [25330,25395]
simple_stmt [25330,25395]
===
match
---
name: self [32185,32189]
name: self [32185,32189]
===
match
---
atom_expr [62063,62099]
atom_expr [62114,62150]
===
match
---
arglist [16890,16903]
arglist [16890,16903]
===
match
---
trailer [75881,75889]
trailer [75932,75940]
===
match
---
trailer [24604,24622]
trailer [24604,24622]
===
match
---
name: using_start_date [27321,27337]
name: using_start_date [27321,27337]
===
match
---
operator: = [19371,19372]
operator: = [19371,19372]
===
match
---
name: upstream_task_ids [62729,62746]
name: upstream_task_ids [62780,62797]
===
match
---
name: task [43469,43473]
name: task [43469,43473]
===
match
---
operator: , [79937,79938]
operator: , [79988,79989]
===
match
---
trailer [78250,78254]
trailer [78301,78305]
===
match
---
suite [75816,76077]
suite [75867,76128]
===
match
---
atom_expr [77653,77668]
atom_expr [77704,77719]
===
match
---
number: 1 [54171,54172]
number: 1 [54222,54223]
===
match
---
operator: == [3480,3482]
operator: == [3480,3482]
===
match
---
suite [83482,92137]
suite [83533,92188]
===
match
---
except_clause [63738,63759]
except_clause [63789,63810]
===
match
---
name: wraps [92740,92745]
name: wraps [92791,92796]
===
match
---
name: confirm_prompt [53787,53801]
name: confirm_prompt [53838,53852]
===
match
---
name: session [91020,91027]
name: session [91071,91078]
===
match
---
expr_stmt [59861,59886]
expr_stmt [59912,59937]
===
match
---
decorator [17448,17462]
decorator [17448,17462]
===
match
---
name: session [37978,37985]
name: session [37978,37985]
===
match
---
name: dag [62892,62895]
name: dag [62943,62946]
===
match
---
operator: = [75851,75852]
operator: = [75902,75903]
===
match
---
name: timezone [21263,21271]
name: timezone [21263,21271]
===
match
---
name: str [30737,30740]
name: str [30737,30740]
===
match
---
arglist [61613,61626]
arglist [61664,61677]
===
match
---
name: replace [14185,14192]
name: replace [14185,14192]
===
match
---
operator: , [82068,82069]
operator: , [82119,82120]
===
match
---
argument [85442,85456]
argument [85493,85507]
===
match
---
name: session [74618,74625]
name: session [74669,74676]
===
match
---
trailer [31555,31561]
trailer [31555,31561]
===
match
---
name: self [33635,33639]
name: self [33635,33639]
===
match
---
trailer [90801,90805]
trailer [90852,90856]
===
match
---
operator: = [12384,12385]
operator: = [12384,12385]
===
match
---
not_test [20159,20192]
not_test [20159,20192]
===
match
---
simple_stmt [65513,65569]
simple_stmt [65564,65620]
===
match
---
operator: -> [29264,29266]
operator: -> [29264,29266]
===
match
---
expr_stmt [86258,86297]
expr_stmt [86309,86348]
===
match
---
simple_stmt [87529,87599]
simple_stmt [87580,87650]
===
match
---
atom [3139,3148]
atom [3139,3148]
===
match
---
name: topological_sort [45087,45103]
name: topological_sort [45087,45103]
===
match
---
name: dag [61412,61415]
name: dag [61463,61466]
===
match
---
simple_stmt [68940,69001]
simple_stmt [68991,69052]
===
match
---
atom_expr [76153,76168]
atom_expr [76204,76219]
===
match
---
name: conf [69523,69527]
name: conf [69574,69578]
===
match
---
funcdef [30083,30452]
funcdef [30083,30452]
===
match
---
name: group [62162,62167]
name: group [62213,62218]
===
match
---
atom [82780,82782]
atom [82831,82833]
===
match
---
operator: == [33854,33856]
operator: == [33854,33856]
===
match
---
trailer [77727,77757]
trailer [77778,77808]
===
match
---
atom_expr [84480,84499]
atom_expr [84531,84550]
===
match
---
name: ti [35084,35086]
name: ti [35084,35086]
===
match
---
trailer [62867,62872]
trailer [62918,62923]
===
match
---
atom_expr [27916,27947]
atom_expr [27916,27947]
===
match
---
if_stmt [45145,45255]
if_stmt [45145,45255]
===
match
---
name: tis [49098,49101]
name: tis [49098,49101]
===
match
---
expr_stmt [93359,93402]
expr_stmt [93410,93453]
===
match
---
trailer [11949,11957]
trailer [11949,11957]
===
match
---
trailer [12629,12667]
trailer [12629,12667]
===
match
---
name: task_id [63041,63048]
name: task_id [63092,63099]
===
match
---
operator: == [36489,36491]
operator: == [36489,36491]
===
match
---
simple_stmt [16964,16992]
simple_stmt [16964,16992]
===
match
---
atom_expr [74970,75117]
atom_expr [75021,75168]
===
match
---
name: SCHEDULED [75089,75098]
name: SCHEDULED [75140,75149]
===
match
---
name: utcnow [76311,76317]
name: utcnow [76362,76368]
===
match
---
simple_stmt [56689,56702]
simple_stmt [56740,56753]
===
match
---
name: warn [32976,32980]
name: warn [32976,32980]
===
match
---
name: Base [83476,83480]
name: Base [83527,83531]
===
match
---
if_stmt [41537,42236]
if_stmt [41537,42236]
===
match
---
operator: , [56480,56481]
operator: , [56531,56532]
===
match
---
operator: , [55596,55597]
operator: , [55647,55648]
===
match
---
name: name [94030,94034]
name: name [94081,94085]
===
match
---
trailer [80994,81001]
trailer [81045,81052]
===
match
---
operator: = [69198,69199]
operator: = [69249,69250]
===
match
---
simple_stmt [83857,83936]
simple_stmt [83908,83987]
===
match
---
name: session [90626,90633]
name: session [90677,90684]
===
match
---
name: task [52595,52599]
name: task [52646,52650]
===
match
---
name: naive [21545,21550]
name: naive [21545,21550]
===
match
---
expr_stmt [37526,37785]
expr_stmt [37526,37785]
===
match
---
trailer [52599,52616]
trailer [52650,52667]
===
match
---
subscriptlist [2947,2976]
subscriptlist [2947,2976]
===
match
---
operator: = [39436,39437]
operator: = [39436,39437]
===
match
---
atom_expr [83881,83935]
atom_expr [83932,83986]
===
match
---
operator: = [52938,52939]
operator: = [52989,52990]
===
match
---
atom [85680,85835]
atom [85731,85886]
===
match
---
trailer [90727,90737]
trailer [90778,90788]
===
match
---
simple_stmt [15412,15468]
simple_stmt [15412,15468]
===
match
---
operator: , [76811,76812]
operator: , [76862,76863]
===
match
---
string: """     Returns the last dag run for a dag, None if there was none.     Last dag run can be any type of run eg. scheduled or backfilled.     Overridden DagRuns are ignored.     """ [3236,3416]
string: """     Returns the last dag run for a dag, None if there was none.     Last dag run can be any type of run eg. scheduled or backfilled.     Overridden DagRuns are ignored.     """ [3236,3416]
===
match
---
trailer [63781,63787]
trailer [63832,63838]
===
match
---
name: subdag_lst [39094,39104]
name: subdag_lst [39094,39104]
===
match
---
name: UtcDateTime [84327,84338]
name: UtcDateTime [84378,84389]
===
match
---
name: _schedule_interval [33878,33896]
name: _schedule_interval [33878,33896]
===
match
---
name: timezone [20566,20574]
name: timezone [20566,20574]
===
match
---
operator: , [85314,85315]
operator: , [85365,85366]
===
match
---
atom_expr [23331,23358]
atom_expr [23331,23358]
===
match
---
parameters [34053,34108]
parameters [34053,34108]
===
match
---
name: level [64721,64726]
name: level [64772,64777]
===
match
---
name: correct_maybe_zipped [89450,89470]
name: correct_maybe_zipped [89501,89521]
===
match
---
trailer [49071,49078]
trailer [49071,49078]
===
match
---
param [64556,64561]
param [64607,64612]
===
match
---
operator: = [46394,46395]
operator: = [46394,46395]
===
match
---
name: self [32125,32129]
name: self [32125,32129]
===
match
---
atom [11701,11703]
atom [11701,11703]
===
match
---
import_as_names [2208,2252]
import_as_names [2208,2252]
===
match
---
name: creating_job_id [72484,72499]
name: creating_job_id [72535,72550]
===
match
---
simple_stmt [82453,82587]
simple_stmt [82504,82638]
===
match
---
expr_stmt [39501,39539]
expr_stmt [39501,39539]
===
match
---
operator: { [39623,39624]
operator: { [39623,39624]
===
match
---
operator: @ [37815,37816]
operator: @ [37815,37816]
===
match
---
name: get_tis [54034,54041]
name: get_tis [54085,54092]
===
match
---
funcdef [91035,92137]
funcdef [91086,92188]
===
match
---
operator: , [69328,69329]
operator: , [69379,69380]
===
match
---
if_stmt [34877,35446]
if_stmt [34877,35446]
===
match
---
name: session [73271,73278]
name: session [73322,73329]
===
match
---
while_stmt [27847,28015]
while_stmt [27847,28015]
===
match
---
operator: = [12924,12925]
operator: = [12924,12925]
===
match
---
name: next_dagrun_create_after [92021,92045]
name: next_dagrun_create_after [92072,92096]
===
match
---
name: Interval [2496,2504]
name: Interval [2496,2504]
===
match
---
operator: , [66825,66826]
operator: , [66876,66877]
===
match
---
param [29257,29262]
param [29257,29262]
===
match
---
decorated [33190,34008]
decorated [33190,34008]
===
match
---
name: tis [42194,42197]
name: tis [42194,42197]
===
match
---
name: conf [69518,69522]
name: conf [69569,69573]
===
match
---
simple_stmt [32967,33149]
simple_stmt [32967,33149]
===
match
---
operator: , [49623,49624]
operator: , [49674,49675]
===
match
---
name: env [40382,40385]
name: env [40382,40385]
===
match
---
arglist [71542,71553]
arglist [71593,71604]
===
match
---
operator: == [88564,88566]
operator: == [88615,88617]
===
match
---
if_stmt [55210,55734]
if_stmt [55261,55785]
===
match
---
name: recursion_depth [51791,51806]
name: recursion_depth [51842,51857]
===
match
---
simple_stmt [63504,63529]
simple_stmt [63555,63580]
===
match
---
string: "Nothing to clear." [56743,56762]
string: "Nothing to clear." [56794,56813]
===
match
---
name: DagTag [77247,77253]
name: DagTag [77298,77304]
===
match
---
suite [71511,71707]
suite [71562,71758]
===
match
---
fstring_start: f" [71589,71591]
fstring_start: f" [71640,71642]
===
match
---
name: func [75362,75366]
name: func [75413,75417]
===
match
---
atom [45885,45906]
atom [45885,45906]
===
match
---
name: children [61784,61792]
name: children [61835,61843]
===
match
---
atom_expr [86533,86598]
atom_expr [86584,86649]
===
match
---
name: DagRun [36465,36471]
name: DagRun [36465,36471]
===
match
---
atom_expr [21932,21965]
atom_expr [21932,21965]
===
match
---
dictorsetmaker [45886,45905]
dictorsetmaker [45886,45905]
===
match
---
trailer [11417,11422]
trailer [11417,11422]
===
match
---
tfpdef [45363,45373]
tfpdef [45363,45373]
===
match
---
atom_expr [70031,70044]
atom_expr [70082,70095]
===
match
---
argument [38411,38423]
argument [38411,38423]
===
match
---
comparison [11793,11822]
comparison [11793,11822]
===
match
---
simple_stmt [35408,35446]
simple_stmt [35408,35446]
===
match
---
operator: @ [29811,29812]
operator: @ [29811,29812]
===
match
---
fstring_start: f' [14875,14877]
fstring_start: f' [14875,14877]
===
match
---
fstring_expr [66140,66154]
fstring_expr [66191,66205]
===
match
---
trailer [79532,79534]
trailer [79583,79585]
===
match
---
name: FrozenSet [9899,9908]
name: FrozenSet [9899,9908]
===
match
---
string: """         Calculates the previous schedule for this dag in UTC          :param dttm: utc datetime         :return: utc datetime         """ [20844,20985]
string: """         Calculates the previous schedule for this dag in UTC          :param dttm: utc datetime         :return: utc datetime         """ [20844,20985]
===
match
---
operator: = [21768,21769]
operator: = [21768,21769]
===
match
---
trailer [54940,54945]
trailer [54991,54996]
===
match
---
suite [77208,77393]
suite [77259,77444]
===
match
---
name: _task_group [59765,59776]
name: _task_group [59816,59827]
===
match
---
trailer [52675,52681]
trailer [52726,52732]
===
match
---
operator: , [81698,81699]
operator: , [81749,81750]
===
match
---
atom_expr [13825,13861]
atom_expr [13825,13861]
===
match
---
name: hour [19470,19474]
name: hour [19470,19474]
===
match
---
atom_expr [76752,76762]
atom_expr [76803,76813]
===
match
---
atom_expr [45738,45759]
atom_expr [45738,45759]
===
match
---
name: task [38756,38760]
name: task [38756,38760]
===
match
---
param [22113,22169]
param [22113,22169]
===
match
---
suite [74296,74676]
suite [74347,74727]
===
match
---
name: get_default_view [78091,78107]
name: get_default_view [78142,78158]
===
match
---
name: self [41091,41095]
name: self [41091,41095]
===
match
---
operator: , [10837,10838]
operator: , [10837,10838]
===
match
---
fstring [71835,71896]
fstring [71886,71947]
===
match
---
name: qry [31955,31958]
name: qry [31955,31958]
===
match
---
name: qry [80991,80994]
name: qry [81042,81045]
===
match
---
name: group [62499,62504]
name: group [62550,62555]
===
match
---
name: task_id [31989,31996]
name: task_id [31989,31996]
===
match
---
annassign [9888,9921]
annassign [9888,9921]
===
match
---
arglist [10647,10680]
arglist [10647,10680]
===
match
---
tfpdef [45432,45462]
tfpdef [45432,45462]
===
match
---
name: task [66418,66422]
name: task [66469,66473]
===
match
---
argument [50112,50153]
argument [50163,50204]
===
match
---
name: str [2947,2950]
name: str [2947,2950]
===
match
---
arglist [66908,66930]
arglist [66959,66981]
===
match
---
atom_expr [54813,54821]
atom_expr [54864,54872]
===
match
---
trailer [17097,17114]
trailer [17097,17114]
===
match
---
operator: == [36313,36315]
operator: == [36313,36315]
===
match
---
name: c [16677,16678]
name: c [16677,16678]
===
match
---
string: 'all,delete-orphan' [85295,85314]
string: 'all,delete-orphan' [85346,85365]
===
match
---
name: normalized_schedule_interval [21937,21965]
name: normalized_schedule_interval [21937,21965]
===
match
---
name: dag [57070,57073]
name: dag [57121,57124]
===
match
---
parameters [45339,45556]
parameters [45339,45556]
===
match
---
name: dagrun [36896,36902]
name: dagrun [36896,36902]
===
match
---
name: max_active_runs [91973,91988]
name: max_active_runs [92024,92039]
===
match
---
simple_stmt [85049,85076]
simple_stmt [85100,85127]
===
match
---
name: self [11997,12001]
name: self [11997,12001]
===
match
---
atom_expr [31641,31673]
atom_expr [31641,31673]
===
match
---
trailer [78942,78949]
trailer [78993,79000]
===
match
---
operator: = [55864,55865]
operator: = [55915,55916]
===
match
---
parameters [29922,29928]
parameters [29922,29928]
===
match
---
trailer [60778,60799]
trailer [60829,60850]
===
match
---
name: run_id [71542,71548]
name: run_id [71593,71599]
===
match
---
operator: , [33111,33112]
operator: , [33111,33112]
===
match
---
atom_expr [83349,83363]
atom_expr [83400,83414]
===
match
---
arglist [93106,93121]
arglist [93157,93172]
===
match
---
operator: -> [63956,63958]
operator: -> [64007,64009]
===
match
---
if_stmt [51832,52379]
if_stmt [51883,52430]
===
match
---
atom_expr [57833,57854]
atom_expr [57884,57905]
===
match
---
simple_stmt [13528,13619]
simple_stmt [13528,13619]
===
match
---
operator: } [71637,71638]
operator: } [71688,71689]
===
match
---
operator: == [19426,19428]
operator: == [19426,19428]
===
match
---
name: parent_group [61150,61162]
name: parent_group [61201,61213]
===
match
---
operator: = [68883,68884]
operator: = [68934,68935]
===
match
---
trailer [62857,62867]
trailer [62908,62918]
===
match
---
name: copied [61092,61098]
name: copied [61143,61149]
===
match
---
trailer [29377,29390]
trailer [29377,29390]
===
match
---
name: dag_ids [48923,48930]
name: dag_ids [48923,48930]
===
match
---
operator: , [18509,18510]
operator: , [18509,18510]
===
match
---
comparison [86564,86589]
comparison [86615,86640]
===
match
---
suite [19475,19500]
suite [19475,19500]
===
match
---
trailer [14118,14130]
trailer [14118,14130]
===
match
---
expr_stmt [27359,27384]
expr_stmt [27359,27384]
===
match
---
trailer [15442,15461]
trailer [15442,15461]
===
match
---
fstring_expr [53225,53238]
fstring_expr [53276,53289]
===
match
---
operator: == [56719,56721]
operator: == [56770,56772]
===
match
---
suite [13515,13619]
suite [13515,13619]
===
match
---
for_stmt [89348,89886]
for_stmt [89399,89937]
===
match
---
atom_expr [29182,29201]
atom_expr [29182,29201]
===
match
---
expr_stmt [15065,15085]
expr_stmt [15065,15085]
===
match
---
operator: , [1343,1344]
operator: , [1343,1344]
===
match
---
simple_stmt [95538,95606]
simple_stmt [95589,95657]
===
match
---
funcdef [38090,38483]
funcdef [38090,38483]
===
match
---
param [46303,46317]
param [46303,46317]
===
match
---
expr_stmt [41935,41975]
expr_stmt [41935,41975]
===
match
---
name: downstream_task_id [40434,40452]
name: downstream_task_id [40434,40452]
===
match
---
name: next_dagrun_info [22073,22089]
name: next_dagrun_info [22073,22089]
===
match
---
suite [35310,35446]
suite [35310,35446]
===
match
---
name: orm_dag [75874,75881]
name: orm_dag [75925,75932]
===
match
---
name: state [41573,41578]
name: state [41573,41578]
===
match
---
name: datetime [20288,20296]
name: datetime [20288,20296]
===
match
---
trailer [13354,13369]
trailer [13354,13369]
===
match
---
trailer [83355,83363]
trailer [83406,83414]
===
match
---
simple_stmt [2109,2141]
simple_stmt [2109,2141]
===
match
---
atom_expr [93653,93667]
atom_expr [93704,93718]
===
match
---
operator: = [70007,70008]
operator: = [70058,70059]
===
match
---
name: property [31570,31578]
name: property [31570,31578]
===
match
---
name: jinja_environment_kwargs [15993,16017]
name: jinja_environment_kwargs [15993,16017]
===
match
---
name: node [44576,44580]
name: node [44576,44580]
===
match
---
operator: , [46142,46143]
operator: , [46142,46143]
===
match
---
suite [31347,31564]
suite [31347,31564]
===
match
---
atom_expr [48979,48995]
atom_expr [48979,48995]
===
match
---
trailer [78809,78816]
trailer [78860,78867]
===
match
---
operator: , [79494,79495]
operator: , [79545,79546]
===
match
---
name: hasattr [58180,58187]
name: hasattr [58231,58238]
===
match
---
atom_expr [80473,80581]
atom_expr [80524,80632]
===
match
---
simple_stmt [59747,59777]
simple_stmt [59798,59828]
===
match
---
trailer [79842,79844]
trailer [79893,79895]
===
match
---
name: task_group [59747,59757]
name: task_group [59798,59808]
===
match
---
simple_stmt [84225,84264]
simple_stmt [84276,84315]
===
match
---
suite [83176,83459]
suite [83227,83510]
===
match
---
comparison [76898,76930]
comparison [76949,76981]
===
match
---
string: 'idx_root_dag_id' [85696,85713]
string: 'idx_root_dag_id' [85747,85764]
===
match
---
suite [42611,42793]
suite [42611,42793]
===
match
---
name: other [16407,16412]
name: other [16407,16412]
===
match
---
name: session [90989,90996]
name: session [91040,91047]
===
match
---
trailer [40896,40900]
trailer [40896,40900]
===
match
---
atom [45595,45608]
atom [45595,45608]
===
match
---
trailer [69642,69646]
trailer [69693,69697]
===
match
---
atom_expr [56845,56851]
atom_expr [56896,56902]
===
match
---
atom_expr [23967,23981]
atom_expr [23967,23981]
===
match
---
tfpdef [11238,11268]
tfpdef [11238,11268]
===
match
---
name: dag_id [74328,74334]
name: dag_id [74379,74385]
===
match
---
trailer [90805,90807]
trailer [90856,90858]
===
match
---
name: state [41632,41637]
name: state [41632,41637]
===
match
---
trailer [75353,75360]
trailer [75404,75411]
===
match
---
trailer [35756,35763]
trailer [35756,35763]
===
match
---
trailer [61328,61336]
trailer [61379,61387]
===
match
---
operator: = [60374,60375]
operator: = [60425,60426]
===
match
---
trailer [12348,12358]
trailer [12348,12358]
===
match
---
name: query [90634,90639]
name: query [90685,90690]
===
match
---
atom_expr [87914,87931]
atom_expr [87965,87982]
===
match
---
expr_stmt [16807,16841]
expr_stmt [16807,16841]
===
match
---
comparison [25891,25923]
comparison [25891,25923]
===
match
---
funcdef [40391,40700]
funcdef [40391,40700]
===
match
---
name: task [52531,52535]
name: task [52582,52586]
===
match
---
name: group [62189,62194]
name: group [62240,62245]
===
match
---
atom_expr [76992,77020]
atom_expr [77043,77071]
===
match
---
argument [49743,49774]
argument [49794,49825]
===
match
---
simple_stmt [61578,61628]
simple_stmt [61629,61679]
===
match
---
name: query [37558,37563]
name: query [37558,37563]
===
match
---
trailer [93671,93679]
trailer [93722,93730]
===
match
---
trailer [76966,76975]
trailer [77017,77026]
===
match
---
fstring [53221,53240]
fstring [53272,53291]
===
match
---
import_from [946,986]
import_from [946,986]
===
match
---
atom_expr [72519,72535]
atom_expr [72570,72586]
===
match
---
trailer [76871,76876]
trailer [76922,76927]
===
match
---
trailer [64784,64787]
trailer [64835,64838]
===
match
---
atom_expr [34844,34868]
atom_expr [34844,34868]
===
match
---
name: in_ [48888,48891]
name: in_ [48888,48891]
===
match
---
funcdef [86303,86362]
funcdef [86354,86413]
===
match
---
argument [69489,69504]
argument [69540,69555]
===
match
---
operator: , [49868,49869]
operator: , [49919,49920]
===
match
---
trailer [11971,11979]
trailer [11971,11979]
===
match
---
name: repr [17061,17065]
name: repr [17061,17065]
===
match
---
name: Index [85690,85695]
name: Index [85741,85746]
===
match
---
name: airflow [2552,2559]
name: airflow [2552,2559]
===
match
---
operator: , [10535,10536]
operator: , [10535,10536]
===
match
---
decorator [29207,29229]
decorator [29207,29229]
===
match
---
atom [26474,26520]
atom [26474,26520]
===
match
---
operator: , [92117,92118]
operator: , [92168,92169]
===
match
---
trailer [3462,3469]
trailer [3462,3469]
===
match
---
trailer [18063,18079]
trailer [18063,18079]
===
match
---
name: used_group_ids [61071,61085]
name: used_group_ids [61122,61136]
===
match
---
name: func [37992,37996]
name: func [37992,37996]
===
match
---
name: get_dagruns_between [37116,37135]
name: get_dagruns_between [37116,37135]
===
match
---
name: dag_id [29031,29037]
name: dag_id [29031,29037]
===
match
---
trailer [35335,35345]
trailer [35335,35345]
===
match
---
name: join [56839,56843]
name: join [56890,56894]
===
match
---
name: _task_group [61866,61877]
name: _task_group [61917,61928]
===
match
---
atom_expr [77145,77153]
atom_expr [77196,77204]
===
match
---
name: self [64746,64750]
name: self [64797,64801]
===
match
---
expr_stmt [15809,15888]
expr_stmt [15809,15888]
===
match
---
atom_expr [87411,87439]
atom_expr [87462,87490]
===
match
---
trailer [74073,74110]
trailer [74124,74161]
===
match
---
operator: , [57190,57191]
operator: , [57241,57242]
===
match
---
atom_expr [10635,10681]
atom_expr [10635,10681]
===
match
---
operator: = [86291,86292]
operator: = [86342,86343]
===
match
---
operator: } [11666,11667]
operator: } [11666,11667]
===
match
---
name: classmethod [72754,72765]
name: classmethod [72805,72816]
===
match
---
name: innerjoin [73962,73971]
name: innerjoin [74013,74022]
===
match
---
name: self [22029,22033]
name: self [22029,22033]
===
match
---
name: len [54813,54816]
name: len [54864,54867]
===
match
---
trailer [81193,81197]
trailer [81244,81248]
===
match
---
name: partial [15070,15077]
name: partial [15070,15077]
===
match
---
atom_expr [76584,76638]
atom_expr [76635,76689]
===
match
---
trailer [29875,29889]
trailer [29875,29889]
===
match
---
expr_stmt [48630,48642]
expr_stmt [48630,48642]
===
match
---
param [11285,11332]
param [11285,11332]
===
match
---
trailer [13219,13225]
trailer [13219,13225]
===
match
---
operator: = [88711,88712]
operator: = [88762,88763]
===
match
---
name: self [28310,28314]
name: self [28310,28314]
===
match
---
operator: = [45814,45815]
operator: = [45814,45815]
===
match
---
suite [55658,55734]
suite [55709,55785]
===
match
---
tfpdef [73246,73269]
tfpdef [73297,73320]
===
match
---
simple_stmt [56883,56981]
simple_stmt [56934,57032]
===
match
---
return_stmt [19488,19499]
return_stmt [19488,19499]
===
match
---
comparison [51835,51876]
comparison [51886,51927]
===
match
---
if_stmt [63164,63237]
if_stmt [63215,63288]
===
match
---
name: DagRun [45639,45645]
name: DagRun [45639,45645]
===
match
---
expr_stmt [42188,42235]
expr_stmt [42188,42235]
===
match
---
atom_expr [93335,93345]
atom_expr [93386,93396]
===
match
---
atom_expr [33951,33973]
atom_expr [33951,33973]
===
match
---
fstring_end: " [45252,45253]
fstring_end: " [45252,45253]
===
match
---
name: executor [68770,68778]
name: executor [68821,68829]
===
match
---
trailer [74923,74930]
trailer [74974,74981]
===
match
---
atom_expr [21292,21342]
atom_expr [21292,21342]
===
match
---
trailer [76030,76037]
trailer [76081,76088]
===
match
---
simple_stmt [31955,32094]
simple_stmt [31955,32094]
===
match
---
operator: = [36450,36451]
operator: = [36450,36451]
===
match
---
expr_stmt [49092,49139]
expr_stmt [49092,49139]
===
match
---
operator: = [84318,84319]
operator: = [84369,84370]
===
match
---
arith_expr [81442,82311]
arith_expr [81493,82362]
===
match
---
name: self [66218,66222]
name: self [66269,66273]
===
match
---
simple_stmt [3105,3156]
simple_stmt [3105,3156]
===
match
---
name: dag_id [35639,35645]
name: dag_id [35639,35645]
===
match
---
string: '' [31117,31119]
string: '' [31117,31119]
===
match
---
name: stats [2122,2127]
name: stats [2122,2127]
===
match
---
trailer [86424,86433]
trailer [86475,86484]
===
match
---
name: self [28449,28453]
name: self [28449,28453]
===
match
---
name: template_searchpath [10239,10258]
name: template_searchpath [10239,10258]
===
match
---
name: self [25798,25802]
name: self [25798,25802]
===
match
---
raise_stmt [71818,71897]
raise_stmt [71869,71948]
===
match
---
return_stmt [26705,26725]
return_stmt [26705,26725]
===
match
---
fstring_string: `run_id` expected to be a str is  [71591,71624]
fstring_string: `run_id` expected to be a str is  [71642,71675]
===
match
---
comparison [28310,28351]
comparison [28310,28351]
===
match
---
trailer [72530,72535]
trailer [72581,72586]
===
match
---
string: """         Get information about the next DagRun of this dag after ``date_last_automated_dagrun`` -- the         execution date, and the earliest it could be scheduled          :param date_last_automated_dagrun: The max(execution_date) of existing             "automated" DagRuns for this dag (scheduled or backfill, but not             manual)         """ [22252,22609]
string: """         Get information about the next DagRun of this dag after ``date_last_automated_dagrun`` -- the         execution date, and the earliest it could be scheduled          :param date_last_automated_dagrun: The max(execution_date) of existing             "automated" DagRuns for this dag (scheduled or backfill, but not             manual)         """ [22252,22609]
===
match
---
name: self [37866,37870]
name: self [37866,37870]
===
match
---
operator: , [69106,69107]
operator: , [69157,69158]
===
match
---
simple_stmt [22843,22863]
simple_stmt [22843,22863]
===
match
---
name: t [63039,63040]
name: t [63090,63091]
===
match
---
name: orm_dag [76992,76999]
name: orm_dag [77043,77050]
===
match
---
param [17507,17526]
param [17507,17526]
===
match
---
name: deepcopy [59872,59880]
name: deepcopy [59923,59931]
===
match
---
name: self [13982,13986]
name: self [13982,13986]
===
match
---
trailer [87469,87476]
trailer [87520,87527]
===
match
---
name: task [65896,65900]
name: task [65947,65951]
===
match
---
decorator [86439,86453]
decorator [86490,86504]
===
match
---
name: setter [29409,29415]
name: setter [29409,29415]
===
match
---
name: self [31169,31173]
name: self [31169,31173]
===
match
---
trailer [40622,40631]
trailer [40622,40631]
===
match
---
atom_expr [20518,20536]
atom_expr [20518,20536]
===
match
---
simple_stmt [33282,33613]
simple_stmt [33282,33613]
===
match
---
name: state [72381,72386]
name: state [72432,72437]
===
match
---
name: end_date [65686,65694]
name: end_date [65737,65745]
===
match
---
operator: = [21723,21724]
operator: = [21723,21724]
===
match
---
string: """         Returns edge information for the given pair of tasks if present, and         None if there is no information.         """ [82453,82586]
string: """         Returns edge information for the given pair of tasks if present, and         None if there is no information.         """ [82504,82637]
===
match
---
simple_stmt [20609,20651]
simple_stmt [20609,20651]
===
match
---
name: end_date [27376,27384]
name: end_date [27376,27384]
===
match
---
suite [12473,12520]
suite [12473,12520]
===
match
---
atom_expr [16653,16663]
atom_expr [16653,16663]
===
match
---
arith_expr [21604,21643]
arith_expr [21604,21643]
===
match
---
name: subdag [39070,39076]
name: subdag [39070,39076]
===
match
---
dotted_name [2181,2200]
dotted_name [2181,2200]
===
match
---
name: t [31534,31535]
name: t [31534,31535]
===
match
---
name: run [72569,72572]
name: run [72620,72623]
===
match
---
operator: , [16897,16898]
operator: , [16897,16898]
===
match
---
operator: = [93914,93915]
operator: = [93965,93966]
===
match
---
name: tis [35028,35031]
name: tis [35028,35031]
===
match
---
simple_stmt [54537,54548]
simple_stmt [54588,54599]
===
match
---
try_stmt [16917,17072]
try_stmt [16917,17072]
===
match
---
name: str [10006,10009]
name: str [10006,10009]
===
match
---
arglist [91807,91989]
arglist [91858,92040]
===
match
---
name: start_date [40971,40981]
name: start_date [40971,40981]
===
match
---
operator: = [16880,16881]
operator: = [16880,16881]
===
match
---
simple_stmt [73869,74040]
simple_stmt [73920,74091]
===
match
---
simple_stmt [72005,72139]
simple_stmt [72056,72190]
===
match
---
name: utcnow [40876,40882]
name: utcnow [40876,40882]
===
match
---
operator: = [79046,79047]
operator: = [79097,79098]
===
match
---
atom_expr [40244,40268]
atom_expr [40244,40268]
===
match
---
name: self [13644,13648]
name: self [13644,13648]
===
match
---
simple_stmt [75833,75858]
simple_stmt [75884,75909]
===
match
---
argument [53648,53671]
argument [53699,53722]
===
match
---
param [16184,16189]
param [16184,16189]
===
match
---
operator: , [56100,56101]
operator: , [56151,56152]
===
match
---
atom_expr [44889,44901]
atom_expr [44889,44901]
===
match
---
name: settings [31641,31649]
name: settings [31641,31649]
===
match
---
name: self [42583,42587]
name: self [42583,42587]
===
match
---
name: join [54941,54945]
name: join [54992,54996]
===
match
---
trailer [60365,60381]
trailer [60416,60432]
===
match
---
name: count [31980,31985]
name: count [31980,31985]
===
match
---
atom_expr [81379,81402]
atom_expr [81430,81453]
===
match
---
param [70195,70233]
param [70246,70284]
===
match
---
comp_op [36419,36425]
comp_op [36419,36425]
===
match
---
atom_expr [11635,11668]
atom_expr [11635,11668]
===
match
---
simple_stmt [95672,95687]
simple_stmt [95723,95738]
===
match
---
trailer [16055,16067]
trailer [16055,16067]
===
match
---
fstring_end: ' [14635,14636]
fstring_end: ' [14635,14636]
===
match
---
expr_stmt [57726,57746]
expr_stmt [57777,57797]
===
match
---
name: default_args [10500,10512]
name: default_args [10500,10512]
===
match
---
name: airflow [38672,38679]
name: airflow [38672,38679]
===
match
---
operator: = [21602,21603]
operator: = [21602,21603]
===
match
---
operator: , [23301,23302]
operator: , [23301,23302]
===
match
---
operator: , [61283,61284]
operator: , [61334,61335]
===
match
---
name: utils [2266,2271]
name: utils [2266,2271]
===
match
---
atom_expr [76302,76319]
atom_expr [76353,76370]
===
match
---
name: pickle_id [29913,29922]
name: pickle_id [29913,29922]
===
match
---
funcdef [38502,39154]
funcdef [38502,39154]
===
match
---
atom_expr [62760,62780]
atom_expr [62811,62831]
===
match
---
atom_expr [39234,39260]
atom_expr [39234,39260]
===
match
---
testlist_comp [88439,88470]
testlist_comp [88490,88521]
===
match
---
name: timedelta [24699,24708]
name: timedelta [24699,24708]
===
match
---
name: task [64862,64866]
name: task [64913,64917]
===
match
---
name: dag [64084,64087]
name: dag [64135,64138]
===
match
---
arglist [58603,58618]
arglist [58654,58669]
===
match
---
operator: * [88623,88624]
operator: * [88674,88675]
===
match
---
name: qry [32109,32112]
name: qry [32109,32112]
===
match
---
operator: = [88423,88424]
operator: = [88474,88475]
===
match
---
trailer [94133,94145]
trailer [94184,94196]
===
match
---
trailer [83453,83458]
trailer [83504,83509]
===
match
---
trailer [49246,49257]
trailer [49297,49308]
===
match
---
simple_stmt [72864,72925]
simple_stmt [72915,72976]
===
match
---
decorator [87007,87021]
decorator [87058,87072]
===
match
---
name: self [35646,35650]
name: self [35646,35650]
===
match
---
argument [49561,49578]
argument [49612,49629]
===
match
---
funcdef [34034,35446]
funcdef [34034,35446]
===
match
---
expr_stmt [12685,12766]
expr_stmt [12685,12766]
===
match
---
suite [57946,58006]
suite [57997,58057]
===
match
---
name: task_id [66423,66430]
name: task_id [66474,66481]
===
match
---
name: self [13179,13183]
name: self [13179,13183]
===
match
---
name: name [77081,77085]
name: name [77132,77136]
===
match
---
trailer [89186,89275]
trailer [89237,89326]
===
match
---
atom_expr [80487,80519]
atom_expr [80538,80570]
===
match
---
name: Dict [12360,12364]
name: Dict [12360,12364]
===
match
---
trailer [13532,13545]
trailer [13532,13545]
===
match
---
name: self [29643,29647]
name: self [29643,29647]
===
match
---
name: filter [31999,32005]
name: filter [31999,32005]
===
match
---
expr_stmt [13328,13381]
expr_stmt [13328,13381]
===
match
---
name: dag [78779,78782]
name: dag [78830,78833]
===
match
---
operator: = [11633,11634]
operator: = [11633,11634]
===
match
---
operator: , [19985,19986]
operator: , [19985,19986]
===
match
---
dotted_name [29031,29044]
dotted_name [29031,29044]
===
match
---
name: getboolean [83886,83896]
name: getboolean [83937,83947]
===
match
---
trailer [19434,19441]
trailer [19434,19441]
===
match
---
operator: { [31533,31534]
operator: { [31533,31534]
===
match
---
operator: , [86821,86822]
operator: , [86872,86873]
===
match
---
suite [42861,45291]
suite [42861,45291]
===
match
---
name: is_active [90728,90737]
name: is_active [90779,90788]
===
match
---
arglist [65896,65924]
arglist [65947,65975]
===
match
---
name: _concurrency [12071,12083]
name: _concurrency [12071,12083]
===
match
---
name: self [60173,60177]
name: self [60224,60228]
===
match
---
atom_expr [25840,25875]
atom_expr [25840,25875]
===
match
---
trailer [77449,77465]
trailer [77500,77516]
===
match
---
if_stmt [82677,82820]
if_stmt [82728,82871]
===
match
---
name: include_downstream [60293,60311]
name: include_downstream [60344,60362]
===
match
---
arith_expr [48792,48813]
arith_expr [48792,48813]
===
match
---
operator: = [76214,76215]
operator: = [76265,76266]
===
match
---
operator: = [48638,48639]
operator: = [48638,48639]
===
match
---
trailer [31979,31985]
trailer [31979,31985]
===
match
---
name: orm_dags [74176,74184]
name: orm_dags [74227,74235]
===
match
---
name: naive [21717,21722]
name: naive [21717,21722]
===
match
---
atom_expr [24847,24862]
atom_expr [24847,24862]
===
match
---
name: dags [57077,57081]
name: dags [57128,57132]
===
match
---
name: include_externally_triggered [3502,3530]
name: include_externally_triggered [3502,3530]
===
match
---
fstring [45200,45253]
fstring [45200,45253]
===
match
---
trailer [49046,49053]
trailer [49046,49053]
===
match
---
name: Optional [12123,12131]
name: Optional [12123,12131]
===
match
---
funcdef [78996,79845]
funcdef [79047,79896]
===
match
---
trailer [88046,88053]
trailer [88097,88104]
===
match
---
name: limit [90888,90893]
name: limit [90939,90944]
===
match
---
string: 'params' [57928,57936]
string: 'params' [57979,57987]
===
match
---
atom_expr [41091,41102]
atom_expr [41091,41102]
===
match
---
simple_stmt [31929,31947]
simple_stmt [31929,31947]
===
match
---
trailer [64316,64329]
trailer [64367,64380]
===
match
---
atom_expr [39296,39314]
atom_expr [39296,39314]
===
match
---
operator: , [58758,58759]
operator: , [58809,58810]
===
match
---
param [86809,86822]
param [86860,86873]
===
match
---
operator: , [37870,37871]
operator: , [37870,37871]
===
match
---
name: d [63841,63842]
name: d [63892,63893]
===
match
---
trailer [36997,37012]
trailer [36997,37012]
===
match
---
operator: = [28570,28571]
operator: = [28570,28571]
===
match
---
name: count [54805,54810]
name: count [54856,54861]
===
match
---
atom_expr [11254,11268]
atom_expr [11254,11268]
===
match
---
argument [86934,86991]
argument [86985,87042]
===
match
---
operator: , [81658,81659]
operator: , [81709,81710]
===
match
---
funcdef [16534,16601]
funcdef [16534,16601]
===
match
---
expr_stmt [54926,54968]
expr_stmt [54977,55019]
===
match
---
funcdef [29825,29890]
funcdef [29825,29890]
===
match
---
import_from [68704,68753]
import_from [68755,68804]
===
match
---
trailer [19276,19305]
trailer [19276,19305]
===
match
---
operator: = [84242,84243]
operator: = [84293,84294]
===
match
---
try_stmt [63537,63882]
try_stmt [63588,63933]
===
match
---
name: self [88042,88046]
name: self [88093,88097]
===
match
---
comparison [54854,54864]
comparison [54905,54915]
===
match
---
name: self [15702,15706]
name: self [15702,15706]
===
match
---
name: executor_loader [68963,68978]
name: executor_loader [69014,69029]
===
match
---
suite [33917,33974]
suite [33917,33974]
===
match
---
trailer [15835,15872]
trailer [15835,15872]
===
match
---
atom_expr [18008,18050]
atom_expr [18008,18050]
===
match
---
operator: , [86915,86916]
operator: , [86966,86967]
===
match
---
name: desc [3681,3685]
name: desc [3681,3685]
===
match
---
if_stmt [13822,13919]
if_stmt [13822,13919]
===
match
---
name: naive [20447,20452]
name: naive [20447,20452]
===
match
---
name: re [863,865]
name: re [863,865]
===
match
---
atom_expr [10269,10294]
atom_expr [10269,10294]
===
match
---
atom_expr [49174,49188]
atom_expr [49174,49188]
===
match
---
name: end_date [50344,50352]
name: end_date [50395,50403]
===
match
---
trailer [93310,93320]
trailer [93361,93371]
===
match
---
name: AirflowException [53055,53071]
name: AirflowException [53106,53122]
===
match
---
suite [22989,23022]
suite [22989,23022]
===
match
---
dotted_name [1410,1424]
dotted_name [1410,1424]
===
match
---
expr_stmt [66266,66281]
expr_stmt [66317,66332]
===
match
---
suite [28352,28382]
suite [28352,28382]
===
match
---
trailer [75391,75398]
trailer [75442,75449]
===
match
---
trailer [41847,41854]
trailer [41847,41854]
===
match
---
name: cls [73241,73244]
name: cls [73292,73295]
===
match
---
name: downstream_task_id [83128,83146]
name: downstream_task_id [83179,83197]
===
match
---
tfpdef [90042,90058]
tfpdef [90093,90109]
===
match
---
name: self [16092,16096]
name: self [16092,16096]
===
match
---
name: dag_id [32768,32774]
name: dag_id [32768,32774]
===
match
---
simple_stmt [24727,24750]
simple_stmt [24727,24750]
===
match
---
operator: = [35702,35703]
operator: = [35702,35703]
===
match
---
operator: , [58724,58725]
operator: , [58775,58776]
===
match
---
simple_stmt [59813,59853]
simple_stmt [59864,59904]
===
match
---
name: id [60783,60785]
name: id [60834,60836]
===
match
---
number: 1.0 [67055,67058]
number: 1.0 [67106,67109]
===
match
---
operator: , [36989,36990]
operator: , [36989,36990]
===
match
---
expr_stmt [20266,20305]
expr_stmt [20266,20305]
===
match
---
name: end_date [69164,69172]
name: end_date [69215,69223]
===
match
---
operator: , [73960,73961]
operator: , [74011,74012]
===
match
---
param [29621,29626]
param [29621,29626]
===
match
---
trailer [63703,63729]
trailer [63754,63780]
===
match
---
atom_expr [75078,75098]
atom_expr [75129,75149]
===
match
---
expr_stmt [13771,13813]
expr_stmt [13771,13813]
===
match
---
trailer [40664,40699]
trailer [40664,40699]
===
match
---
name: dag_id [86583,86589]
name: dag_id [86634,86640]
===
match
---
arglist [18243,18253]
arglist [18243,18253]
===
match
---
raise_stmt [51965,52378]
raise_stmt [52016,52429]
===
match
---
simple_stmt [39872,39928]
simple_stmt [39872,39928]
===
match
---
name: len [62905,62908]
name: len [62956,62959]
===
match
---
simple_stmt [12910,12944]
simple_stmt [12910,12944]
===
match
---
arglist [74831,74878]
arglist [74882,74929]
===
match
---
operator: , [10092,10093]
operator: , [10092,10093]
===
match
---
atom_expr [74594,74604]
atom_expr [74645,74655]
===
match
---
name: self [59930,59934]
name: self [59981,59985]
===
match
---
operator: = [95082,95083]
operator: = [95133,95134]
===
match
---
operator: , [50090,50091]
operator: , [50141,50142]
===
match
---
trailer [57846,57852]
trailer [57897,57903]
===
match
---
name: user_defined_macros [40192,40211]
name: user_defined_macros [40192,40211]
===
match
---
name: get_task_group_dict [62078,62097]
name: get_task_group_dict [62129,62148]
===
match
---
name: self [38049,38053]
name: self [38049,38053]
===
match
---
param [17313,17320]
param [17313,17320]
===
match
---
name: DagRun [45654,45660]
name: DagRun [45654,45660]
===
match
---
arglist [89187,89274]
arglist [89238,89325]
===
match
---
trailer [13051,13064]
trailer [13051,13064]
===
match
---
name: filter [41048,41054]
name: filter [41048,41054]
===
match
---
operator: , [81624,81625]
operator: , [81675,81676]
===
match
---
import_from [1405,1465]
import_from [1405,1465]
===
match
---
name: str [29851,29854]
name: str [29851,29854]
===
match
---
if_stmt [61725,61826]
if_stmt [61776,61877]
===
match
---
expr_stmt [54805,54821]
expr_stmt [54856,54872]
===
match
---
trailer [69088,69630]
trailer [69139,69681]
===
match
---
trailer [93373,93383]
trailer [93424,93434]
===
match
---
if_stmt [58177,58239]
if_stmt [58228,58290]
===
match
---
name: self [24261,24265]
name: self [24261,24265]
===
match
---
atom_expr [48863,48873]
atom_expr [48863,48873]
===
match
---
name: deepcopy [60770,60778]
name: deepcopy [60821,60829]
===
match
---
name: self [29182,29186]
name: self [29182,29186]
===
match
---
atom_expr [11042,11074]
atom_expr [11042,11074]
===
match
---
operator: , [10935,10936]
operator: , [10935,10936]
===
match
---
name: include_externally_triggered [28580,28608]
name: include_externally_triggered [28580,28608]
===
match
---
name: Exception [35300,35309]
name: Exception [35300,35309]
===
match
---
name: tis [48968,48971]
name: tis [48968,48971]
===
match
---
number: 10 [85937,85939]
number: 10 [85988,85990]
===
match
---
simple_stmt [59785,59805]
simple_stmt [59836,59856]
===
match
---
string: "dag" [83546,83551]
string: "dag" [83597,83602]
===
match
---
name: combine [40963,40970]
name: combine [40963,40970]
===
match
---
suite [28081,28403]
suite [28081,28403]
===
match
---
tfpdef [45399,45415]
tfpdef [45399,45415]
===
match
---
name: str [87121,87124]
name: str [87172,87175]
===
match
---
name: is_paused_upon_creation [15902,15925]
name: is_paused_upon_creation [15902,15925]
===
match
---
atom_expr [74528,74540]
atom_expr [74579,74591]
===
match
---
operator: = [37171,37172]
operator: = [37171,37172]
===
match
---
name: TI [50437,50439]
name: TI [50488,50490]
===
match
---
name: tags [77149,77153]
name: tags [77200,77204]
===
match
---
trailer [51078,51082]
trailer [51129,51133]
===
match
---
name: provide_session [72771,72786]
name: provide_session [72822,72837]
===
match
---
dictorsetmaker [35211,35227]
dictorsetmaker [35211,35227]
===
match
---
name: self [85959,85963]
name: self [86010,86014]
===
match
---
trailer [40678,40698]
trailer [40678,40698]
===
match
---
simple_stmt [94466,94525]
simple_stmt [94517,94576]
===
match
---
trailer [82330,82350]
trailer [82381,82401]
===
match
---
operator: , [17994,17995]
operator: , [17994,17995]
===
match
---
operator: = [49569,49570]
operator: = [49620,49621]
===
match
---
operator: , [10733,10734]
operator: , [10733,10734]
===
match
---
trailer [16380,16395]
trailer [16380,16395]
===
match
---
argument [55614,55629]
argument [55665,55680]
===
match
---
operator: , [2220,2221]
operator: , [2220,2221]
===
match
---
funcdef [32572,32821]
funcdef [32572,32821]
===
match
---
decorated [32551,32821]
decorated [32551,32821]
===
match
---
operator: = [34801,34802]
operator: = [34801,34802]
===
match
---
name: time [40996,41000]
name: time [40996,41000]
===
match
---
name: filter [37585,37591]
name: filter [37585,37591]
===
match
---
name: flush [72552,72557]
name: flush [72603,72608]
===
match
---
name: session [35892,35899]
name: session [35892,35899]
===
match
---
simple_stmt [18340,18591]
simple_stmt [18340,18591]
===
match
---
operator: , [73056,73057]
operator: , [73107,73108]
===
match
---
simple_stmt [41838,41885]
simple_stmt [41838,41885]
===
match
---
atom_expr [19446,19460]
atom_expr [19446,19460]
===
match
---
name: active_dates [35689,35701]
name: active_dates [35689,35701]
===
match
---
trailer [74850,74855]
trailer [74901,74906]
===
match
---
not_test [65109,65128]
not_test [65160,65179]
===
match
---
name: __new__ [57768,57775]
name: __new__ [57819,57826]
===
match
---
name: task_id [66146,66153]
name: task_id [66197,66204]
===
match
---
expr_stmt [69770,69817]
expr_stmt [69821,69868]
===
match
---
atom_expr [61035,61051]
atom_expr [61086,61102]
===
match
---
string: 'sla_miss_callback' [81933,81952]
string: 'sla_miss_callback' [81984,82003]
===
match
---
atom_expr [44686,44698]
atom_expr [44686,44698]
===
match
---
operator: , [38824,38825]
operator: , [38824,38825]
===
match
---
atom_expr [30614,30690]
atom_expr [30614,30690]
===
match
---
decorator [79868,79885]
decorator [79919,79936]
===
match
---
name: children [61229,61237]
name: children [61280,61288]
===
match
---
name: value [93945,93950]
name: value [93996,94001]
===
match
---
name: partial [62938,62945]
name: partial [62989,62996]
===
match
---
name: dag_ids [45672,45679]
name: dag_ids [45672,45679]
===
match
---
suite [61299,61536]
suite [61350,61587]
===
match
---
name: ID_LEN [1701,1707]
name: ID_LEN [1701,1707]
===
match
---
trailer [13394,13403]
trailer [13394,13403]
===
match
---
trailer [45079,45086]
trailer [45079,45086]
===
match
---
name: self [91502,91506]
name: self [91553,91557]
===
match
---
expr_stmt [27297,27311]
expr_stmt [27297,27311]
===
match
---
operator: = [51504,51505]
operator: = [51555,51556]
===
match
---
operator: = [73784,73785]
operator: = [73835,73836]
===
match
---
param [46353,46378]
param [46353,46378]
===
match
---
name: last_pickled [84305,84317]
name: last_pickled [84356,84368]
===
match
---
name: state [45900,45905]
name: state [45900,45905]
===
match
---
trailer [86908,86915]
trailer [86959,86966]
===
match
---
expr_stmt [60145,60218]
expr_stmt [60196,60269]
===
match
---
name: pendulum [21188,21196]
name: pendulum [21188,21196]
===
match
---
trailer [40191,40211]
trailer [40191,40211]
===
match
---
return_stmt [94229,94243]
return_stmt [94280,94294]
===
match
---
name: getboolean [10966,10976]
name: getboolean [10966,10976]
===
match
---
number: 30 [40897,40899]
number: 30 [40897,40899]
===
match
---
name: hash [17087,17091]
name: hash [17087,17091]
===
match
---
name: get_next [19334,19342]
name: get_next [19334,19342]
===
match
---
operator: , [45986,45987]
operator: , [45986,45987]
===
match
---
atom_expr [21998,22063]
atom_expr [21998,22063]
===
match
---
atom_expr [62189,62253]
atom_expr [62240,62304]
===
match
---
operator: = [85936,85937]
operator: = [85987,85988]
===
match
---
simple_stmt [94229,94244]
simple_stmt [94280,94295]
===
match
---
name: datetime [18685,18693]
name: datetime [18685,18693]
===
match
---
trailer [18756,18766]
trailer [18756,18766]
===
match
---
name: query [79415,79420]
name: query [79466,79471]
===
match
---
name: t [39234,39235]
name: t [39234,39235]
===
match
---
return_stmt [86409,86433]
return_stmt [86460,86484]
===
match
---
name: self [66277,66281]
name: self [66328,66332]
===
match
---
name: orm_dag [76652,76659]
name: orm_dag [76703,76710]
===
match
---
name: Text [1389,1393]
name: Text [1389,1393]
===
match
---
atom_expr [29095,29107]
atom_expr [29095,29107]
===
match
---
name: include_downstream [53330,53348]
name: include_downstream [53381,53399]
===
match
---
name: ignore_first_depends_on_past [69342,69370]
name: ignore_first_depends_on_past [69393,69421]
===
match
---
operator: , [18693,18694]
operator: , [18693,18694]
===
match
---
name: airflow [2464,2471]
name: airflow [2464,2471]
===
match
---
name: str [14433,14436]
name: str [14433,14436]
===
match
---
test [25798,25875]
test [25798,25875]
===
match
---
operator: { [82817,82818]
operator: { [82868,82869]
===
match
---
argument [54034,54046]
argument [54085,54097]
===
match
---
name: dag_id [86731,86737]
name: dag_id [86782,86788]
===
match
---
dotted_name [92730,92745]
dotted_name [92781,92796]
===
match
---
atom [60782,60798]
atom [60833,60849]
===
match
---
operator: -> [45557,45559]
operator: -> [45557,45559]
===
match
---
number: 2 [38422,38423]
number: 2 [38422,38423]
===
match
---
name: intersection [62525,62537]
name: intersection [62576,62588]
===
match
---
trailer [45007,45029]
trailer [45007,45029]
===
match
---
simple_stmt [78123,78189]
simple_stmt [78174,78240]
===
match
---
operator: , [90971,90972]
operator: , [91022,91023]
===
match
---
simple_stmt [26011,26099]
simple_stmt [26011,26099]
===
match
---
return_stmt [20723,20795]
return_stmt [20723,20795]
===
match
---
name: make_naive [19970,19980]
name: make_naive [19970,19980]
===
match
---
atom_expr [73936,73978]
atom_expr [73987,74029]
===
match
---
name: task_id [60189,60196]
name: task_id [60240,60247]
===
match
---
name: dag_bound_args [93499,93513]
name: dag_bound_args [93550,93564]
===
match
---
name: filter [38025,38031]
name: filter [38025,38031]
===
match
---
trailer [16436,16443]
trailer [16436,16443]
===
match
---
trailer [72693,72710]
trailer [72744,72761]
===
match
---
name: task_id [50607,50614]
name: task_id [50658,50665]
===
match
---
atom_expr [86258,86290]
atom_expr [86309,86341]
===
match
---
operator: = [59910,59911]
operator: = [59961,59962]
===
match
---
atom_expr [37609,37622]
atom_expr [37609,37622]
===
match
---
fstring_string: `run_type` expected to be a DagRunType is  [71837,71879]
fstring_string: `run_type` expected to be a DagRunType is  [71888,71930]
===
match
---
name: cls [95298,95301]
name: cls [95349,95352]
===
match
---
name: self [92119,92123]
name: self [92170,92174]
===
match
---
param [72841,72853]
param [72892,72904]
===
match
---
atom_expr [72544,72559]
atom_expr [72595,72610]
===
match
---
name: __file__ [31100,31108]
name: __file__ [31100,31108]
===
match
---
name: DagRun [75632,75638]
name: DagRun [75683,75689]
===
match
---
operator: @ [63904,63905]
operator: @ [63955,63956]
===
match
---
trailer [15098,15118]
trailer [15098,15118]
===
match
---
trailer [54566,54570]
trailer [54617,54621]
===
match
---
expr_stmt [24995,25022]
expr_stmt [24995,25022]
===
match
---
operator: = [42192,42193]
operator: = [42192,42193]
===
match
---
atom_expr [21621,21634]
atom_expr [21621,21634]
===
match
---
name: str [82867,82870]
name: str [82918,82921]
===
match
---
operator: = [66819,66820]
operator: = [66870,66871]
===
match
---
suite [41546,42236]
suite [41546,42236]
===
match
---
trailer [45877,45884]
trailer [45877,45884]
===
match
---
name: values [62140,62146]
name: values [62191,62197]
===
match
---
name: orm_dag [76434,76441]
name: orm_dag [76485,76492]
===
match
---
trailer [62440,62450]
trailer [62491,62501]
===
match
---
name: task_dict [65992,66001]
name: task_dict [66043,66052]
===
match
---
except_clause [35293,35309]
except_clause [35293,35309]
===
match
---
decorated [29983,30078]
decorated [29983,30078]
===
match
---
operator: } [71894,71895]
operator: } [71945,71946]
===
match
---
atom_expr [22179,22242]
atom_expr [22179,22242]
===
match
---
operator: , [67163,67164]
operator: , [67214,67215]
===
match
---
simple_stmt [29005,29025]
simple_stmt [29005,29025]
===
match
---
expr_stmt [51328,51471]
expr_stmt [51379,51522]
===
match
---
name: self [35094,35098]
name: self [35094,35098]
===
match
---
name: perm [18249,18253]
name: perm [18249,18253]
===
match
---
suite [56154,56603]
suite [56205,56654]
===
match
---
operator: , [9726,9727]
operator: , [9726,9727]
===
match
---
operator: , [11228,11229]
operator: , [11228,11229]
===
match
---
trailer [84930,84944]
trailer [84981,84995]
===
match
---
testlist_comp [77079,77107]
testlist_comp [77130,77158]
===
match
---
operator: = [80825,80826]
operator: = [80876,80877]
===
match
---
name: get_tis [54516,54523]
name: get_tis [54567,54574]
===
match
---
trailer [28314,28332]
trailer [28314,28332]
===
match
---
trailer [25294,25312]
trailer [25294,25312]
===
match
---
operator: @ [95145,95146]
operator: @ [95196,95197]
===
match
---
name: self [11677,11681]
name: self [11677,11681]
===
match
---
expr_stmt [87329,87519]
expr_stmt [87380,87570]
===
match
---
trailer [84937,84943]
trailer [84988,84994]
===
match
---
param [72811,72815]
param [72862,72866]
===
match
---
expr_stmt [60035,60118]
expr_stmt [60086,60169]
===
match
---
name: serialized_dag [94475,94489]
name: serialized_dag [94526,94540]
===
match
---
if_stmt [68763,69063]
if_stmt [68814,69114]
===
match
---
atom_expr [73729,73764]
atom_expr [73780,73815]
===
match
---
expr_stmt [11967,11988]
expr_stmt [11967,11988]
===
match
---
operator: = [31932,31933]
operator: = [31932,31933]
===
match
---
name: Column [85209,85215]
name: Column [85260,85266]
===
match
---
suite [29086,29116]
suite [29086,29116]
===
match
---
atom [3079,3103]
atom [3079,3103]
===
match
---
trailer [66145,66153]
trailer [66196,66204]
===
match
---
name: self [78066,78070]
name: self [78117,78121]
===
match
---
atom_expr [36299,36312]
atom_expr [36299,36312]
===
match
---
suite [91672,92053]
suite [91723,92104]
===
match
---
operator: = [50591,50592]
operator: = [50642,50643]
===
match
---
trailer [76219,76225]
trailer [76270,76276]
===
match
---
name: t [60345,60346]
name: t [60396,60397]
===
match
---
name: self [26212,26216]
name: self [26212,26216]
===
match
---
string: "This method is deprecated and will be removed in a future version. Please use partial_subset" [58404,58498]
string: "This method is deprecated and will be removed in a future version. Please use partial_subset" [58455,58549]
===
match
---
parameters [88019,88025]
parameters [88070,88076]
===
match
---
fstring_string: Task  [63426,63431]
fstring_string: Task  [63477,63482]
===
match
---
trailer [52477,52481]
trailer [52528,52532]
===
match
---
name: self [11558,11562]
name: self [11558,11562]
===
match
---
name: dag [63332,63335]
name: dag [63383,63386]
===
match
---
trailer [58385,58390]
trailer [58436,58441]
===
match
---
argument [57173,57190]
argument [57224,57241]
===
match
---
decorated [30791,30874]
decorated [30791,30874]
===
match
---
name: end_date [26477,26485]
name: end_date [26477,26485]
===
match
---
trailer [62300,62321]
trailer [62351,62372]
===
match
---
operator: , [58192,58193]
operator: , [58243,58244]
===
match
---
operator: { [81487,81488]
operator: { [81538,81539]
===
match
---
atom_expr [33635,33657]
atom_expr [33635,33657]
===
match
---
funcdef [9927,16098]
funcdef [9927,16098]
===
match
---
for_stmt [74258,74676]
for_stmt [74309,74727]
===
match
---
operator: = [49300,49301]
operator: = [49351,49352]
===
match
---
name: paused_dag_id [87565,87578]
name: paused_dag_id [87616,87629]
===
match
---
name: get [82730,82733]
name: get [82781,82784]
===
match
---
trailer [74837,74844]
trailer [74888,74895]
===
match
---
name: local_executor [68825,68839]
name: local_executor [68876,68890]
===
match
---
simple_stmt [57726,57747]
simple_stmt [57777,57798]
===
match
---
name: run [35719,35722]
name: run [35719,35722]
===
match
---
name: timezone [13211,13219]
name: timezone [13211,13219]
===
match
---
atom_expr [72011,72138]
atom_expr [72062,72189]
===
match
---
atom_expr [73891,74029]
atom_expr [73942,74080]
===
match
---
decorator [28653,28670]
decorator [28653,28670]
===
match
---
operator: , [49819,49820]
operator: , [49870,49871]
===
match
---
string: """         Return (and lock) a list of Dag objects that are due to create a new DagRun.          This will return a resultset of rows  that is row-level-locked with a "SELECT ... FOR UPDATE" query,         you should ensure that any scheduling decisions are made in a single transaction -- as soon as the         transaction is committed it will be unlocked.         """ [90069,90440]
string: """         Return (and lock) a list of Dag objects that are due to create a new DagRun.          This will return a resultset of rows  that is row-level-locked with a "SELECT ... FOR UPDATE" query,         you should ensure that any scheduling decisions are made in a single transaction -- as soon as the         transaction is committed it will be unlocked.         """ [90120,90491]
===
match
---
name: dag_kwargs [92160,92170]
name: dag_kwargs [92211,92221]
===
match
---
operator: , [81517,81518]
operator: , [81568,81569]
===
match
---
name: dagrun_timeout [14269,14283]
name: dagrun_timeout [14269,14283]
===
match
---
name: joinedload [1441,1451]
name: joinedload [1441,1451]
===
match
---
atom_expr [75560,75594]
atom_expr [75611,75645]
===
match
---
if_stmt [61320,61536]
if_stmt [61371,61587]
===
match
---
suite [62921,62953]
suite [62972,63004]
===
match
---
trailer [75972,75983]
trailer [76023,76034]
===
match
---
name: run_type [71720,71728]
name: run_type [71771,71779]
===
match
---
operator: , [85741,85742]
operator: , [85792,85793]
===
match
---
operator: @ [42322,42323]
operator: @ [42322,42323]
===
match
---
name: do_it [56689,56694]
name: do_it [56740,56745]
===
match
---
name: correct_maybe_zipped [2284,2304]
name: correct_maybe_zipped [2284,2304]
===
match
---
name: session [72519,72526]
name: session [72570,72577]
===
match
---
atom_expr [21788,21806]
atom_expr [21788,21806]
===
match
---
operator: , [18079,18080]
operator: , [18079,18080]
===
match
---
operator: , [16894,16895]
operator: , [16894,16895]
===
match
---
name: external_trigger [36472,36488]
name: external_trigger [36472,36488]
===
match
---
argument [35166,35181]
argument [35166,35181]
===
match
---
simple_stmt [30996,31060]
simple_stmt [30996,31060]
===
match
---
name: LoggingMixin [2396,2408]
name: LoggingMixin [2396,2408]
===
match
---
name: self [30906,30910]
name: self [30906,30910]
===
match
---
operator: , [91951,91952]
operator: , [92002,92003]
===
match
---
operator: , [1069,1070]
operator: , [1069,1070]
===
match
---
atom_expr [32308,32499]
atom_expr [32308,32499]
===
match
---
name: isinstance [20997,21007]
name: isinstance [20997,21007]
===
match
---
trailer [20639,20650]
trailer [20639,20650]
===
match
---
atom_expr [65911,65924]
atom_expr [65962,65975]
===
match
---
name: skip_locked [91000,91011]
name: skip_locked [91051,91062]
===
match
---
name: dagbag [1787,1793]
name: dagbag [1787,1793]
===
match
---
argument [69541,69578]
argument [69592,69629]
===
match
---
funcdef [72791,73177]
funcdef [72842,73228]
===
match
---
funcdef [31735,32142]
funcdef [31735,32142]
===
match
---
name: TaskInstance [2033,2045]
name: TaskInstance [2033,2045]
===
match
---
trailer [48941,48948]
trailer [48941,48948]
===
match
---
simple_stmt [54557,54573]
simple_stmt [54608,54624]
===
match
---
atom_expr [70126,70140]
atom_expr [70177,70191]
===
match
---
operator: , [45469,45470]
operator: , [45469,45470]
===
match
---
atom_expr [92119,92135]
atom_expr [92170,92186]
===
match
---
trailer [13931,13951]
trailer [13931,13951]
===
match
---
atom_expr [85209,85225]
atom_expr [85260,85276]
===
match
---
funcdef [16103,16162]
funcdef [16103,16162]
===
match
---
atom_expr [77079,77085]
atom_expr [77130,77136]
===
match
---
string: """         Add a task to the DAG          :param task: the task you want to add         :type task: task         """ [64956,65073]
string: """         Add a task to the DAG          :param task: the task you want to add         :type task: task         """ [65007,65124]
===
match
---
arglist [60088,60116]
arglist [60139,60167]
===
match
---
atom_expr [45444,45462]
atom_expr [45444,45462]
===
match
---
name: downstream [53462,53472]
name: downstream [53513,53523]
===
match
---
trailer [60558,60572]
trailer [60609,60623]
===
match
---
trailer [15737,15757]
trailer [15737,15757]
===
match
---
name: dag_run_state [49855,49868]
name: dag_run_state [49906,49919]
===
match
---
simple_stmt [12685,12767]
simple_stmt [12685,12767]
===
match
---
name: owner [31536,31541]
name: owner [31536,31541]
===
match
---
name: qry [32707,32710]
name: qry [32707,32710]
===
match
---
sync_comp_for [41207,41226]
sync_comp_for [41207,41226]
===
match
---
name: dag_ids [73828,73835]
name: dag_ids [73879,73886]
===
match
---
operator: = [13344,13345]
operator: = [13344,13345]
===
match
---
operator: = [35625,35626]
operator: = [35625,35626]
===
match
---
operator: , [1134,1135]
operator: , [1134,1135]
===
match
---
operator: = [49240,49241]
operator: = [49291,49292]
===
match
---
operator: = [53417,53418]
operator: = [53468,53469]
===
match
---
dotted_name [11452,11476]
dotted_name [11452,11476]
===
match
---
trailer [21196,21205]
trailer [21196,21205]
===
match
---
comparison [41745,41758]
comparison [41745,41758]
===
match
---
name: str [28992,28995]
name: str [28992,28995]
===
match
---
name: DagRun [36299,36305]
name: DagRun [36299,36305]
===
match
---
atom_expr [75469,75481]
atom_expr [75520,75532]
===
match
---
operator: ** [92706,92708]
operator: ** [92757,92759]
===
match
---
name: add [66414,66417]
name: add [66465,66468]
===
match
---
operator: , [81818,81819]
operator: , [81869,81870]
===
match
---
name: callback [34792,34800]
name: callback [34792,34800]
===
match
---
name: dry_run [54585,54592]
name: dry_run [54636,54643]
===
match
---
name: instances [50867,50876]
name: instances [50918,50927]
===
match
---
operator: , [2530,2531]
operator: , [2530,2531]
===
match
---
trailer [62077,62097]
trailer [62128,62148]
===
match
---
atom_expr [23219,23263]
atom_expr [23219,23263]
===
match
---
name: orm_dag [76384,76391]
name: orm_dag [76435,76442]
===
match
---
and_test [13033,13098]
and_test [13033,13098]
===
match
---
comparison [89450,89515]
comparison [89501,89566]
===
match
---
operator: } [60874,60875]
operator: } [60925,60926]
===
match
---
decorated [28653,28953]
decorated [28653,28953]
===
match
---
name: self [20030,20034]
name: self [20030,20034]
===
match
---
name: execution_date [37016,37030]
name: execution_date [37016,37030]
===
match
---
name: ScheduleInterval [10055,10071]
name: ScheduleInterval [10055,10071]
===
match
---
name: following_schedule [19531,19549]
name: following_schedule [19531,19549]
===
match
---
simple_stmt [84914,84945]
simple_stmt [84965,84996]
===
match
---
name: end_date [57173,57181]
name: end_date [57224,57232]
===
match
---
funcdef [29733,29806]
funcdef [29733,29806]
===
match
---
trailer [35098,35107]
trailer [35098,35107]
===
match
---
name: task [66676,66680]
name: task [66727,66731]
===
match
---
name: qry [80615,80618]
name: qry [80666,80669]
===
match
---
expr_stmt [95632,95663]
expr_stmt [95683,95714]
===
match
---
comparison [24643,24660]
comparison [24643,24660]
===
match
---
parameters [36581,36617]
parameters [36581,36617]
===
match
---
comparison [50437,50470]
comparison [50488,50521]
===
match
---
simple_stmt [11503,11550]
simple_stmt [11503,11550]
===
match
---
name: start_date [26072,26082]
name: start_date [26072,26082]
===
match
---
name: self [31334,31338]
name: self [31334,31338]
===
match
---
name: self [58188,58192]
name: self [58239,58243]
===
match
---
name: _default_view [14418,14431]
name: _default_view [14418,14431]
===
match
---
param [10743,10788]
param [10743,10788]
===
match
---
parameters [28448,28504]
parameters [28448,28504]
===
match
---
trailer [74153,74160]
trailer [74204,74211]
===
match
---
simple_stmt [58576,58620]
simple_stmt [58627,58671]
===
match
---
name: query [87368,87373]
name: query [87419,87424]
===
match
---
name: cls [89257,89260]
name: cls [89308,89311]
===
match
---
parameters [29841,29847]
parameters [29841,29847]
===
match
---
trailer [25189,25200]
trailer [25189,25200]
===
match
---
string: """         Return a DagParam object for current dag.          :param name: dag parameter name.         :param default: fallback value for dag parameter.         :return: DagParam instance for specified name and current dag.         """ [30145,30381]
string: """         Return a DagParam object for current dag.          :param name: dag parameter name.         :param default: fallback value for dag parameter.         :return: DagParam instance for specified name and current dag.         """ [30145,30381]
===
match
---
expr_stmt [15094,15140]
expr_stmt [15094,15140]
===
match
---
name: self [22099,22103]
name: self [22099,22103]
===
match
---
name: start_date [65540,65550]
name: start_date [65591,65601]
===
match
---
name: provide_session [79869,79884]
name: provide_session [79920,79935]
===
match
---
name: template_searchpath [13932,13951]
name: template_searchpath [13932,13951]
===
match
---
import_name [866,876]
import_name [866,876]
===
match
---
if_stmt [71761,71898]
if_stmt [71812,71949]
===
match
---
atom_expr [19409,19425]
atom_expr [19409,19425]
===
match
---
name: models [94413,94419]
name: models [94464,94470]
===
match
---
arglist [80649,80684]
arglist [80700,80735]
===
match
---
name: get_next [20460,20468]
name: get_next [20460,20468]
===
match
---
trailer [78333,78346]
trailer [78384,78397]
===
match
---
trailer [42016,42145]
trailer [42016,42145]
===
match
---
return_stmt [16131,16161]
return_stmt [16131,16161]
===
match
---
name: description [76392,76403]
name: description [76443,76454]
===
match
---
suite [45565,45937]
suite [45565,45937]
===
match
---
comparison [13481,13514]
comparison [13481,13514]
===
match
---
fstring_end: " [53105,53106]
fstring_end: " [53156,53157]
===
match
---
name: list [30758,30762]
name: list [30758,30762]
===
match
---
name: tis [56167,56170]
name: tis [56218,56221]
===
match
---
trailer [75429,75433]
trailer [75480,75484]
===
match
---
atom_expr [52531,52551]
atom_expr [52582,52602]
===
match
---
trailer [36275,36277]
trailer [36275,36277]
===
match
---
parameters [30480,30486]
parameters [30480,30486]
===
match
---
comparison [36299,36327]
comparison [36299,36327]
===
match
---
name: sys [873,876]
name: sys [873,876]
===
match
---
name: bulk_write_to_db [78048,78064]
name: bulk_write_to_db [78099,78115]
===
match
---
simple_stmt [92016,92053]
simple_stmt [92067,92104]
===
match
---
trailer [14148,14150]
trailer [14148,14150]
===
match
---
name: s [41953,41954]
name: s [41953,41954]
===
match
---
name: or_ [42046,42049]
name: or_ [42046,42049]
===
match
---
parameters [95190,95205]
parameters [95241,95256]
===
match
---
string: 'template_searchpath' [81894,81915]
string: 'template_searchpath' [81945,81966]
===
match
---
suite [18327,18591]
suite [18327,18591]
===
match
---
atom_expr [80649,80683]
atom_expr [80700,80734]
===
match
---
trailer [64052,64054]
trailer [64103,64105]
===
match
---
trailer [62066,62077]
trailer [62117,62128]
===
match
---
param [82872,82896]
param [82923,82947]
===
match
---
simple_stmt [19953,20002]
simple_stmt [19953,20002]
===
match
---
name: copied [61064,61070]
name: copied [61115,61121]
===
match
---
arglist [10826,10857]
arglist [10826,10857]
===
match
---
expr_stmt [49452,50186]
expr_stmt [49503,50237]
===
match
---
operator: , [28709,28710]
operator: , [28709,28710]
===
match
---
name: timezone [21835,21843]
name: timezone [21835,21843]
===
match
---
param [66973,67007]
param [67024,67058]
===
match
---
name: task_ids [45996,46004]
name: task_ids [45996,46004]
===
match
---
operator: , [46009,46010]
operator: , [46009,46010]
===
match
---
operator: = [14332,14333]
operator: = [14332,14333]
===
match
---
suite [39030,39128]
suite [39030,39128]
===
match
---
arglist [82760,82782]
arglist [82811,82833]
===
match
---
sync_comp_for [60164,60217]
sync_comp_for [60215,60268]
===
match
---
expr_stmt [85663,85835]
expr_stmt [85714,85886]
===
match
---
atom_expr [27801,27815]
atom_expr [27801,27815]
===
match
---
trailer [42102,42108]
trailer [42102,42108]
===
match
---
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_concurrency_reached` method.""" [32200,32299]
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_concurrency_reached` method.""" [32200,32299]
===
match
---
trailer [24249,24257]
trailer [24249,24257]
===
match
---
name: DEFAULT_VIEW_PRESETS [14590,14610]
name: DEFAULT_VIEW_PRESETS [14590,14610]
===
match
---
string: 'task_dict' [81865,81876]
string: 'task_dict' [81916,81927]
===
match
---
arglist [83897,83934]
arglist [83948,83985]
===
match
---
return_stmt [86331,86361]
return_stmt [86382,86412]
===
match
---
param [38514,38518]
param [38514,38518]
===
match
---
operator: = [70045,70046]
operator: = [70096,70097]
===
match
---
operator: , [64939,64940]
operator: , [64990,64991]
===
match
---
operator: = [49456,49457]
operator: = [49507,49508]
===
match
---
atom_expr [81175,81205]
atom_expr [81226,81256]
===
match
---
name: datetime [18757,18765]
name: datetime [18757,18765]
===
match
---
atom_expr [51971,52378]
atom_expr [52022,52429]
===
match
---
trailer [86563,86590]
trailer [86614,86641]
===
match
---
operator: = [59865,59866]
operator: = [59916,59917]
===
match
---
operator: = [14176,14177]
operator: = [14176,14177]
===
match
---
operator: , [9974,9975]
operator: , [9974,9975]
===
match
---
name: TIMEZONE [12935,12943]
name: TIMEZONE [12935,12943]
===
match
---
parameters [86315,86321]
parameters [86366,86372]
===
match
---
name: self [88458,88462]
name: self [88509,88513]
===
match
---
trailer [14714,14726]
trailer [14714,14726]
===
match
---
operator: = [69233,69234]
operator: = [69284,69285]
===
match
---
atom_expr [77467,77478]
atom_expr [77518,77529]
===
match
---
simple_stmt [1204,1218]
simple_stmt [1204,1218]
===
match
---
operator: = [85383,85384]
operator: = [85434,85435]
===
match
---
operator: = [67128,67129]
operator: = [67179,67180]
===
match
---
string: 'RL' [3092,3096]
string: 'RL' [3092,3096]
===
match
---
operator: = [49931,49932]
operator: = [49982,49983]
===
match
---
argument [90981,90996]
argument [91032,91047]
===
match
---
trailer [75770,75786]
trailer [75821,75837]
===
match
---
simple_stmt [89541,89569]
simple_stmt [89592,89620]
===
match
---
operator: , [78071,78072]
operator: , [78122,78123]
===
match
---
trailer [27932,27947]
trailer [27932,27947]
===
match
---
name: max_recursion_depth [46353,46372]
name: max_recursion_depth [46353,46372]
===
match
---
trailer [84602,84611]
trailer [84653,84662]
===
match
---
trailer [73999,74029]
trailer [74050,74080]
===
match
---
atom_expr [36978,36989]
atom_expr [36978,36989]
===
match
---
operator: , [16412,16413]
operator: , [16412,16413]
===
match
---
string: 'dag_default_view' [87957,87975]
string: 'dag_default_view' [88008,88026]
===
match
---
name: conf [10817,10821]
name: conf [10817,10821]
===
match
---
name: tis [54563,54566]
name: tis [54614,54617]
===
match
---
name: task_id [35111,35118]
name: task_id [35111,35118]
===
match
---
operator: = [72718,72719]
operator: = [72769,72770]
===
match
---
atom_expr [13069,13098]
atom_expr [13069,13098]
===
match
---
name: include_parentdag [56017,56034]
name: include_parentdag [56068,56085]
===
match
---
string: """         Returns the number of active "running" dag runs          :param external_trigger: True for externally triggered active dag runs         :type external_trigger: bool         :param session:         :return: number greater than 0 for active dag runs         """ [35915,36186]
string: """         Returns the number of active "running" dag runs          :param external_trigger: True for externally triggered active dag runs         :type external_trigger: bool         :param session:         :return: number greater than 0 for active dag runs         """ [35915,36186]
===
match
---
name: start_date [24901,24911]
name: start_date [24901,24911]
===
match
---
suite [38520,39154]
suite [38520,39154]
===
match
---
operator: , [93111,93112]
operator: , [93162,93163]
===
match
---
trailer [91011,91028]
trailer [91062,91079]
===
match
---
name: dict [75315,75319]
name: dict [75366,75370]
===
match
---
atom_expr [35627,35679]
atom_expr [35627,35679]
===
match
---
name: include_subdag_tasks [45104,45124]
name: include_subdag_tasks [45104,45124]
===
match
---
suite [65863,65926]
suite [65914,65977]
===
match
---
operator: = [53786,53787]
operator: = [53837,53838]
===
match
---
simple_stmt [14710,14741]
simple_stmt [14710,14741]
===
match
---
trailer [72526,72530]
trailer [72577,72581]
===
match
---
string: 'end_date' [13265,13275]
string: 'end_date' [13265,13275]
===
match
---
param [29251,29256]
param [29251,29256]
===
match
---
name: cls [90037,90040]
name: cls [90088,90091]
===
match
---
operator: = [84072,84073]
operator: = [84123,84124]
===
match
---
suite [90060,91030]
suite [90111,91081]
===
match
---
operator: , [85813,85814]
operator: , [85864,85865]
===
match
---
for_stmt [64656,64728]
for_stmt [64707,64779]
===
match
---
simple_stmt [83556,83641]
simple_stmt [83607,83692]
===
match
---
simple_stmt [842,856]
simple_stmt [842,856]
===
match
---
name: DagRun [36991,36997]
name: DagRun [36991,36997]
===
match
---
name: is_subdag [84037,84046]
name: is_subdag [84088,84097]
===
match
---
atom_expr [51076,51090]
atom_expr [51127,51141]
===
match
---
operator: = [20272,20273]
operator: = [20272,20273]
===
match
---
name: state [80958,80963]
name: state [81009,81014]
===
match
---
atom_expr [50897,50908]
atom_expr [50948,50959]
===
match
---
atom_expr [61521,61534]
atom_expr [61572,61585]
===
match
---
simple_stmt [85984,86011]
simple_stmt [86035,86062]
===
match
---
simple_stmt [20723,20796]
simple_stmt [20723,20796]
===
match
---
name: clear_dags [55807,55817]
name: clear_dags [55858,55868]
===
match
---
name: dag [91905,91908]
name: dag [91956,91959]
===
match
---
trailer [49053,49079]
trailer [49053,49079]
===
match
---
simple_stmt [16051,16098]
simple_stmt [16051,16098]
===
match
---
name: session [87360,87367]
name: session [87411,87418]
===
match
---
subscript [94335,94339]
subscript [94386,94390]
===
match
---
name: pool [67016,67020]
name: pool [67067,67071]
===
match
---
name: execution_date [53596,53610]
name: execution_date [53647,53661]
===
match
---
operator: , [10988,10989]
operator: , [10988,10989]
===
match
---
simple_stmt [73729,73765]
simple_stmt [73780,73816]
===
match
---
operator: = [45463,45464]
operator: = [45463,45464]
===
match
---
name: len [66459,66462]
name: len [66510,66513]
===
match
---
name: dag_id [75354,75360]
name: dag_id [75405,75411]
===
match
---
name: conf [72363,72367]
name: conf [72414,72418]
===
match
---
decorated [38076,38483]
decorated [38076,38483]
===
match
---
suite [57082,57481]
suite [57133,57532]
===
match
---
atom [36237,36389]
atom [36237,36389]
===
match
---
expr_stmt [56993,57034]
expr_stmt [57044,57085]
===
match
---
operator: = [57730,57731]
operator: = [57781,57782]
===
match
---
name: DR [3470,3472]
name: DR [3470,3472]
===
match
---
name: new_start [25013,25022]
name: new_start [25013,25022]
===
match
---
param [28691,28696]
param [28691,28696]
===
match
---
trailer [45067,45074]
trailer [45067,45074]
===
match
---
argument [93475,93495]
argument [93526,93546]
===
match
---
atom_expr [60786,60791]
atom_expr [60837,60842]
===
match
---
name: env [40225,40228]
name: env [40225,40228]
===
match
---
name: session [28571,28578]
name: session [28571,28578]
===
match
---
if_stmt [50961,51047]
if_stmt [51012,51098]
===
match
---
operator: , [73088,73089]
operator: , [73139,73140]
===
match
---
name: settings [1530,1538]
name: settings [1530,1538]
===
match
---
atom [61194,61196]
atom [61245,61247]
===
match
---
name: copy [61040,61044]
name: copy [61091,61095]
===
match
---
funcdef [58266,58620]
funcdef [58317,58671]
===
match
---
string: 'SubDagOperator' [38999,39015]
string: 'SubDagOperator' [38999,39015]
===
match
---
operator: , [39777,39778]
operator: , [39777,39778]
===
match
---
comp_if [25185,25200]
comp_if [25185,25200]
===
match
---
simple_stmt [3236,3417]
simple_stmt [3236,3417]
===
match
---
name: task_ids [80593,80601]
name: task_ids [80644,80652]
===
match
---
name: push_context_managed_dag [17231,17255]
name: push_context_managed_dag [17231,17255]
===
match
---
atom_expr [58077,58104]
atom_expr [58128,58155]
===
match
---
trailer [52583,52591]
trailer [52634,52642]
===
match
---
tfpdef [30025,30035]
tfpdef [30025,30035]
===
match
---
operator: <= [27885,27887]
operator: <= [27885,27887]
===
match
---
atom_expr [44923,44948]
atom_expr [44923,44948]
===
match
---
trailer [88053,88061]
trailer [88104,88112]
===
match
---
atom_expr [77728,77739]
atom_expr [77779,77790]
===
match
---
operator: = [11222,11223]
operator: = [11222,11223]
===
match
---
name: dag_id [83333,83339]
name: dag_id [83384,83390]
===
match
---
name: graph_unsorted [43439,43453]
name: graph_unsorted [43439,43453]
===
match
---
trailer [29467,29480]
trailer [29467,29480]
===
match
---
atom_expr [42050,42088]
atom_expr [42050,42088]
===
match
---
atom_expr [21604,21635]
atom_expr [21604,21635]
===
match
---
operator: , [32462,32463]
operator: , [32462,32463]
===
match
---
dotted_name [1674,1693]
dotted_name [1674,1693]
===
match
---
operator: , [55365,55366]
operator: , [55416,55417]
===
match
---
simple_stmt [93905,93919]
simple_stmt [93956,93970]
===
match
---
parameters [22089,22175]
parameters [22089,22175]
===
match
---
name: DagModel [87374,87382]
name: DagModel [87425,87433]
===
match
---
trailer [66222,66232]
trailer [66273,66283]
===
match
---
name: TI [52478,52480]
name: TI [52529,52531]
===
match
---
name: t [60832,60833]
name: t [60883,60884]
===
match
---
name: ExecutorLoader [69025,69039]
name: ExecutorLoader [69076,69090]
===
match
---
atom [87546,87598]
atom [87597,87649]
===
match
---
atom_expr [61491,61535]
atom_expr [61542,61586]
===
match
---
name: d [63489,63490]
name: d [63540,63541]
===
match
---
operator: = [30428,30429]
operator: = [30428,30429]
===
match
---
fstring_string:  not found [63440,63450]
fstring_string:  not found [63491,63501]
===
match
---
name: date_last_automated_dagrun [22921,22947]
name: date_last_automated_dagrun [22921,22947]
===
match
---
operator: @ [35818,35819]
operator: @ [35818,35819]
===
match
---
name: self [12910,12914]
name: self [12910,12914]
===
match
---
name: name [76906,76910]
name: name [76957,76961]
===
match
---
atom_expr [11967,11979]
atom_expr [11967,11979]
===
match
---
trailer [29940,29945]
trailer [29940,29945]
===
match
---
name: naive [21336,21341]
name: naive [21336,21341]
===
match
---
suite [63011,63070]
suite [63062,63121]
===
match
---
trailer [75638,75645]
trailer [75689,75696]
===
match
---
expr_stmt [35084,35119]
expr_stmt [35084,35119]
===
match
---
operator: , [50053,50054]
operator: , [50104,50105]
===
match
---
trailer [85880,85940]
trailer [85931,85991]
===
match
---
atom_expr [13586,13617]
atom_expr [13586,13617]
===
match
---
name: mark_success [69199,69211]
name: mark_success [69250,69262]
===
match
---
string: "DAG %s is at (or above) max_active_runs (%d of %d), not creating any more runs" [91807,91887]
string: "DAG %s is at (or above) max_active_runs (%d of %d), not creating any more runs" [91858,91938]
===
match
---
operator: = [10296,10297]
operator: = [10296,10297]
===
match
---
param [83427,83431]
param [83478,83482]
===
match
---
operator: , [26753,26754]
operator: , [26753,26754]
===
match
---
fstring_end: " [71895,71896]
fstring_end: " [71946,71947]
===
match
---
expr_stmt [12344,12388]
expr_stmt [12344,12388]
===
match
---
if_stmt [14659,14937]
if_stmt [14659,14937]
===
match
---
name: timedelta [977,986]
name: timedelta [977,986]
===
match
---
operator: = [81467,81468]
operator: = [81518,81519]
===
match
---
name: self [86129,86133]
name: self [86180,86184]
===
match
---
name: most_recent_dag_runs [76727,76747]
name: most_recent_dag_runs [76778,76798]
===
match
---
operator: , [55869,55870]
operator: , [55920,55921]
===
match
---
decorator [32551,32568]
decorator [32551,32568]
===
match
---
trailer [90664,90822]
trailer [90715,90873]
===
match
---
argument [69256,69281]
argument [69307,69332]
===
match
---
name: __tablename__ [89261,89274]
name: __tablename__ [89312,89325]
===
match
---
name: end_date [10149,10157]
name: end_date [10149,10157]
===
match
---
operator: , [10184,10185]
operator: , [10184,10185]
===
match
---
name: external_trigger [3564,3580]
name: external_trigger [3564,3580]
===
match
---
import_from [1714,1766]
import_from [1714,1766]
===
match
---
sliceop [94336,94339]
sliceop [94387,94390]
===
match
---
simple_stmt [63841,63882]
simple_stmt [63892,63933]
===
match
---
name: self [39897,39901]
name: self [39897,39901]
===
match
---
simple_stmt [16634,16665]
simple_stmt [16634,16665]
===
match
---
atom_expr [75731,75739]
atom_expr [75782,75790]
===
match
---
name: skip_locked [2519,2530]
name: skip_locked [2519,2530]
===
match
---
operator: } [82310,82311]
operator: } [82361,82362]
===
match
---
atom_expr [21232,21272]
atom_expr [21232,21272]
===
match
---
simple_stmt [16362,16445]
simple_stmt [16362,16445]
===
match
---
name: tasks [26500,26505]
name: tasks [26500,26505]
===
match
---
param [73241,73245]
param [73292,73296]
===
match
---
name: task_id [66007,66014]
name: task_id [66058,66065]
===
match
---
name: convert_to_utc [22007,22021]
name: convert_to_utc [22007,22021]
===
match
---
name: subdag_task_groups [62121,62139]
name: subdag_task_groups [62172,62190]
===
match
---
trailer [92123,92135]
trailer [92174,92186]
===
match
---
operator: = [35885,35886]
operator: = [35885,35886]
===
match
---
name: property [30458,30466]
name: property [30458,30466]
===
match
---
trailer [45276,45290]
trailer [45276,45290]
===
match
---
simple_stmt [58247,58261]
simple_stmt [58298,58312]
===
match
---
string: 'end_date' [13693,13703]
string: 'end_date' [13693,13703]
===
match
---
name: concurrency [10545,10556]
name: concurrency [10545,10556]
===
match
---
trailer [2865,2884]
trailer [2865,2884]
===
match
---
name: task_id [43474,43481]
name: task_id [43474,43481]
===
match
---
simple_stmt [88035,88078]
simple_stmt [88086,88129]
===
match
---
name: t [63053,63054]
name: t [63104,63105]
===
match
---
trailer [81460,81475]
trailer [81511,81526]
===
match
---
name: keys [62354,62358]
name: keys [62405,62409]
===
match
---
simple_stmt [2769,2823]
simple_stmt [2769,2823]
===
match
---
simple_stmt [15702,15770]
simple_stmt [15702,15770]
===
match
---
operator: = [45623,45624]
operator: = [45623,45624]
===
match
---
name: dag [76040,76043]
name: dag [76091,76094]
===
match
---
simple_stmt [32102,32142]
simple_stmt [32102,32142]
===
match
---
argument [49645,49670]
argument [49696,49721]
===
match
---
operator: = [31776,31777]
operator: = [31776,31777]
===
match
---
name: dag [62969,62972]
name: dag [63020,63023]
===
match
---
trailer [87943,87976]
trailer [87994,88027]
===
match
---
and_expr [48849,48905]
and_expr [48849,48905]
===
match
---
atom_expr [28550,28561]
atom_expr [28550,28561]
===
match
---
operator: , [16415,16416]
operator: , [16415,16416]
===
match
---
atom_expr [12779,12792]
atom_expr [12779,12792]
===
match
---
string: "jinja2.ext.do" [39761,39776]
string: "jinja2.ext.do" [39761,39776]
===
match
---
operator: = [61148,61149]
operator: = [61199,61200]
===
match
---
simple_stmt [9657,9864]
simple_stmt [9657,9864]
===
match
---
trailer [57108,57480]
trailer [57159,57531]
===
match
---
trailer [35107,35119]
trailer [35107,35119]
===
match
---
trailer [10336,10360]
trailer [10336,10360]
===
match
---
string: '_old_context_manager_dags' [81535,81562]
string: '_old_context_manager_dags' [81586,81613]
===
match
---
param [46387,46400]
param [46387,46400]
===
match
---
param [82849,82871]
param [82900,82922]
===
match
---
name: append [48842,48848]
name: append [48842,48848]
===
match
---
simple_stmt [81297,81364]
simple_stmt [81348,81415]
===
match
---
operator: = [84594,84595]
operator: = [84645,84646]
===
match
---
test [27752,27837]
test [27752,27837]
===
match
---
atom_expr [63841,63856]
atom_expr [63892,63907]
===
match
---
return_stmt [54537,54547]
return_stmt [54588,54598]
===
match
---
simple_stmt [1585,1669]
simple_stmt [1585,1669]
===
match
---
name: self [21008,21012]
name: self [21008,21012]
===
match
---
operator: = [49096,49097]
operator: = [49096,49097]
===
match
---
name: tis [41470,41473]
name: tis [41470,41473]
===
match
---
name: max_recursion_depth [50034,50053]
name: max_recursion_depth [50085,50104]
===
match
---
name: filter [36292,36298]
name: filter [36292,36298]
===
match
---
operator: , [66963,66964]
operator: , [67014,67015]
===
match
---
simple_stmt [38443,38483]
simple_stmt [38443,38483]
===
match
---
trailer [20190,20192]
trailer [20190,20192]
===
match
---
name: _context_managed_dag [95771,95791]
name: _context_managed_dag [95822,95842]
===
match
---
name: TI [52518,52520]
name: TI [52569,52571]
===
match
---
string: """File location of where the dag object is instantiated""" [30928,30987]
string: """File location of where the dag object is instantiated""" [30928,30987]
===
match
---
operator: , [49578,49579]
operator: , [49629,49630]
===
match
---
name: decorators [64844,64854]
name: decorators [64895,64905]
===
match
---
suite [63760,63882]
suite [63811,63933]
===
match
---
trailer [87476,87480]
trailer [87527,87531]
===
match
---
simple_stmt [69639,69649]
simple_stmt [69690,69700]
===
match
---
name: include_subdags [56412,56427]
name: include_subdags [56463,56478]
===
match
---
simple_stmt [58845,59540]
simple_stmt [58896,59591]
===
match
---
operator: , [83389,83390]
operator: , [83440,83441]
===
match
---
param [79039,79051]
param [79090,79102]
===
match
---
suite [89335,89915]
suite [89386,89966]
===
match
---
decorator [32147,32157]
decorator [32147,32157]
===
match
---
operator: , [93333,93334]
operator: , [93384,93385]
===
match
---
name: tasks [25179,25184]
name: tasks [25179,25184]
===
match
---
operator: + [31110,31111]
operator: + [31110,31111]
===
match
---
argument [92706,92718]
argument [92757,92769]
===
match
---
name: dag_ids [45584,45591]
name: dag_ids [45584,45591]
===
match
---
atom_expr [13211,13318]
atom_expr [13211,13318]
===
match
---
arglist [14193,14207]
arglist [14193,14207]
===
match
---
name: format [55110,55116]
name: format [55161,55167]
===
match
---
name: args [93107,93111]
name: args [93158,93162]
===
match
---
name: DAG [81457,81460]
name: DAG [81508,81511]
===
match
---
name: Boolean [84159,84166]
name: Boolean [84210,84217]
===
match
---
name: self [24933,24937]
name: self [24933,24937]
===
match
---
name: tzinfo [12513,12519]
name: tzinfo [12513,12519]
===
match
---
name: end_date [26767,26775]
name: end_date [26767,26775]
===
match
---
suite [28996,29025]
suite [28996,29025]
===
match
---
atom_expr [76546,76581]
atom_expr [76597,76632]
===
match
---
name: self [30481,30485]
name: self [30481,30485]
===
match
---
suite [18812,19015]
suite [18812,19015]
===
match
---
name: AirflowException [65148,65164]
name: AirflowException [65199,65215]
===
match
---
suite [13662,13762]
suite [13662,13762]
===
match
---
argument [83391,83407]
argument [83442,83458]
===
match
---
name: dag [75892,75895]
name: dag [75943,75946]
===
match
---
name: DagModel [79496,79504]
name: DagModel [79547,79555]
===
match
---
atom_expr [50396,50472]
atom_expr [50447,50523]
===
match
---
operator: , [73166,73167]
operator: , [73217,73218]
===
match
---
name: on_success_callback [15099,15118]
name: on_success_callback [15099,15118]
===
match
---
name: self [34054,34058]
name: self [34054,34058]
===
match
---
operator: = [53147,53148]
operator: = [53198,53199]
===
match
---
atom_expr [13390,13403]
atom_expr [13390,13403]
===
match
---
parameters [81282,81287]
parameters [81333,81338]
===
match
---
import_name [877,893]
import_name [877,893]
===
match
---
suite [31791,32142]
suite [31791,32142]
===
match
---
operator: , [46377,46378]
operator: , [46377,46378]
===
match
---
name: TaskInstance [80838,80850]
name: TaskInstance [80889,80901]
===
match
---
name: self [40187,40191]
name: self [40187,40191]
===
match
---
atom_expr [59895,59909]
atom_expr [59946,59960]
===
match
---
name: edge [44686,44690]
name: edge [44686,44690]
===
match
---
name: now [24497,24500]
name: now [24497,24500]
===
match
---
argument [58610,58618]
argument [58661,58669]
===
match
---
name: count [56660,56665]
name: count [56711,56716]
===
match
---
trailer [40995,41000]
trailer [40995,41000]
===
match
---
param [77799,77804]
param [77850,77855]
===
match
---
trailer [41611,41618]
trailer [41611,41618]
===
match
---
name: self [21258,21262]
name: self [21258,21262]
===
match
---
trailer [35086,35091]
trailer [35086,35091]
===
match
---
operator: @ [86439,86440]
operator: @ [86490,86491]
===
match
---
name: copied [61127,61133]
name: copied [61178,61184]
===
match
---
raise_stmt [30608,30690]
raise_stmt [30608,30690]
===
match
---
atom_expr [36991,37012]
atom_expr [36991,37012]
===
match
---
name: re [2774,2776]
name: re [2774,2776]
===
match
---
operator: , [2627,2628]
operator: , [2627,2628]
===
match
---
expr_stmt [89808,89834]
expr_stmt [89859,89885]
===
match
---
funcdef [79889,81235]
funcdef [79940,81286]
===
match
---
operator: , [1148,1149]
operator: , [1148,1149]
===
match
---
name: task [66041,66045]
name: task [66092,66096]
===
match
---
param [29527,29531]
param [29527,29531]
===
match
---
name: cls [88826,88829]
name: cls [88877,88880]
===
match
---
name: tis [50516,50519]
name: tis [50567,50570]
===
match
---
name: sub_dag [49258,49265]
name: sub_dag [49309,49316]
===
match
---
trailer [36341,36348]
trailer [36341,36348]
===
match
---
trailer [16207,16213]
trailer [16207,16213]
===
match
---
comparison [45738,45773]
comparison [45738,45773]
===
match
---
comparison [57871,57945]
comparison [57922,57996]
===
match
---
trailer [39961,39982]
trailer [39961,39982]
===
match
---
trailer [10965,10976]
trailer [10965,10976]
===
match
---
name: _concurrency [29468,29480]
name: _concurrency [29468,29480]
===
match
---
name: schedule_interval [22718,22735]
name: schedule_interval [22718,22735]
===
match
---
trailer [95290,95297]
trailer [95341,95348]
===
match
---
trailer [11854,11883]
trailer [11854,11883]
===
match
---
simple_stmt [29864,29890]
simple_stmt [29864,29890]
===
match
---
trailer [17934,17965]
trailer [17934,17965]
===
match
---
name: airflow [1674,1681]
name: airflow [1674,1681]
===
match
---
expr_stmt [51018,51046]
expr_stmt [51069,51097]
===
match
---
atom_expr [65113,65128]
atom_expr [65164,65179]
===
match
---
name: dag_id [48853,48859]
name: dag_id [48853,48859]
===
match
---
trailer [20765,20794]
trailer [20765,20794]
===
match
---
name: cls [90724,90727]
name: cls [90775,90778]
===
match
---
simple_stmt [2547,2585]
simple_stmt [2547,2585]
===
match
---
trailer [42227,42234]
trailer [42227,42234]
===
match
---
name: dirname [31277,31284]
name: dirname [31277,31284]
===
match
---
operator: == [3581,3583]
operator: == [3581,3583]
===
match
---
expr_stmt [61064,61114]
expr_stmt [61115,61165]
===
match
---
operator: , [11189,11190]
operator: , [11189,11190]
===
match
---
name: get_num_active_runs [35843,35862]
name: get_num_active_runs [35843,35862]
===
match
---
decorator [35818,35835]
decorator [35818,35835]
===
match
---
operator: } [12387,12388]
operator: } [12387,12388]
===
match
---
atom_expr [91652,91671]
atom_expr [91703,91722]
===
match
---
atom_expr [58229,58238]
atom_expr [58280,58289]
===
match
---
name: folder [39444,39450]
name: folder [39444,39450]
===
match
---
simple_stmt [28287,28299]
simple_stmt [28287,28299]
===
match
---
name: run_id [70023,70029]
name: run_id [70074,70080]
===
match
---
name: self [12549,12553]
name: self [12549,12553]
===
match
---
trailer [41198,41206]
trailer [41198,41206]
===
match
---
operator: = [49657,49658]
operator: = [49708,49709]
===
match
---
simple_stmt [31068,31121]
simple_stmt [31068,31121]
===
match
---
atom_expr [86416,86433]
atom_expr [86467,86484]
===
match
---
parameters [28068,28080]
parameters [28068,28080]
===
match
---
name: executor [69225,69233]
name: executor [69276,69284]
===
match
---
operator: = [57804,57805]
operator: = [57855,57856]
===
match
---
operator: , [30422,30423]
operator: , [30422,30423]
===
match
---
trailer [40906,40908]
trailer [40906,40908]
===
match
---
atom_expr [13346,13381]
atom_expr [13346,13381]
===
match
---
operator: -> [18794,18796]
operator: -> [18794,18796]
===
match
---
parameters [29250,29263]
parameters [29250,29263]
===
match
---
string: 'user_defined_filters' [81676,81698]
string: 'user_defined_filters' [81727,81749]
===
match
---
name: dag_id [77279,77285]
name: dag_id [77330,77336]
===
match
---
trailer [20508,20517]
trailer [20508,20517]
===
match
---
name: session [91012,91019]
name: session [91063,91070]
===
match
---
trailer [78858,78860]
trailer [78909,78911]
===
match
---
atom_expr [62704,62724]
atom_expr [62755,62775]
===
match
---
operator: , [46271,46272]
operator: , [46271,46272]
===
match
---
name: updated_access_control [18304,18326]
name: updated_access_control [18304,18326]
===
match
---
comparison [32019,32043]
comparison [32019,32043]
===
match
---
name: subdag_lst [39143,39153]
name: subdag_lst [39143,39153]
===
match
---
name: DuplicateTaskIdFound [66108,66128]
name: DuplicateTaskIdFound [66159,66179]
===
match
---
operator: -> [29848,29850]
operator: -> [29848,29850]
===
match
---
name: stacklevel [58544,58554]
name: stacklevel [58595,58605]
===
match
---
simple_stmt [64584,64621]
simple_stmt [64635,64672]
===
match
---
name: filter [50233,50239]
name: filter [50284,50290]
===
match
---
argument [90998,91028]
argument [91049,91079]
===
match
---
trailer [61497,61512]
trailer [61548,61563]
===
match
---
funcdef [58625,62973]
funcdef [58676,63024]
===
match
---
atom_expr [3445,3490]
atom_expr [3445,3490]
===
match
---
operator: == [75482,75484]
operator: == [75533,75535]
===
match
---
name: Tuple [22179,22184]
name: Tuple [22179,22184]
===
match
---
name: default_args [12554,12566]
name: default_args [12554,12566]
===
match
---
atom_expr [49193,49208]
atom_expr [49193,49208]
===
match
---
simple_stmt [17870,17882]
simple_stmt [17870,17882]
===
match
---
atom_expr [10260,10295]
atom_expr [10260,10295]
===
match
---
name: exceptions [1598,1608]
name: exceptions [1598,1608]
===
match
---
name: session [49924,49931]
name: session [49975,49982]
===
match
---
operator: = [59722,59723]
operator: = [59773,59774]
===
match
---
trailer [66907,66931]
trailer [66958,66982]
===
match
---
trailer [30861,30873]
trailer [30861,30873]
===
match
---
operator: , [56040,56041]
operator: , [56091,56092]
===
match
---
suite [39192,39261]
suite [39192,39261]
===
match
---
name: t [64741,64742]
name: t [64792,64793]
===
match
---
trailer [62476,62496]
trailer [62527,62547]
===
match
---
operator: = [60476,60477]
operator: = [60527,60528]
===
match
---
name: State [36365,36370]
name: State [36365,36370]
===
match
---
suite [79966,81235]
suite [80017,81286]
===
match
---
trailer [85008,85014]
trailer [85059,85065]
===
match
---
string: """         Given a list of dag_ids, get a set of Paused Dag Ids          :param dag_ids: List of Dag ids         :param session: ORM Session         :return: Paused Dag_ids         """ [87135,87320]
string: """         Given a list of dag_ids, get a set of Paused Dag Ids          :param dag_ids: List of Dag ids         :param session: ORM Session         :return: Paused Dag_ids         """ [87186,87371]
===
match
---
name: self [18659,18663]
name: self [18659,18663]
===
match
---
operator: @ [28958,28959]
operator: @ [28958,28959]
===
match
---
name: permissions [17923,17934]
name: permissions [17923,17934]
===
match
---
return_stmt [17270,17281]
return_stmt [17270,17281]
===
match
---
name: run_type [72406,72414]
name: run_type [72457,72465]
===
match
---
name: value [29627,29632]
name: value [29627,29632]
===
match
---
if_stmt [51536,51807]
if_stmt [51587,51858]
===
match
---
atom_expr [51786,51806]
atom_expr [51837,51857]
===
match
---
operator: , [63092,63093]
operator: , [63143,63144]
===
match
---
atom_expr [53094,53104]
atom_expr [53145,53155]
===
match
---
trailer [74803,75198]
trailer [74854,75249]
===
match
---
atom_expr [63704,63721]
atom_expr [63755,63772]
===
match
---
name: flush [77661,77666]
name: flush [77712,77717]
===
match
---
trailer [19333,19342]
trailer [19333,19342]
===
match
---
comp_if [41970,41974]
comp_if [41970,41974]
===
match
---
trailer [37557,37563]
trailer [37557,37563]
===
match
---
suite [38122,38483]
suite [38122,38483]
===
match
---
suite [91181,92137]
suite [91232,92188]
===
match
---
expr_stmt [15897,15951]
expr_stmt [15897,15951]
===
match
---
atom_expr [50604,50628]
atom_expr [50655,50679]
===
match
---
name: DAGS_FOLDER [31037,31048]
name: DAGS_FOLDER [31037,31048]
===
match
---
atom_expr [45240,45251]
atom_expr [45240,45251]
===
match
---
atom_expr [24245,24257]
atom_expr [24245,24257]
===
match
---
name: airflow [2414,2421]
name: airflow [2414,2421]
===
match
---
atom_expr [45271,45290]
atom_expr [45271,45290]
===
match
---
operator: = [70141,70142]
operator: = [70192,70193]
===
match
---
name: following_schedule [25647,25665]
name: following_schedule [25647,25665]
===
match
---
return_stmt [55768,55780]
return_stmt [55819,55831]
===
match
---
name: qry [80821,80824]
name: qry [80872,80875]
===
match
---
trailer [12751,12765]
trailer [12751,12765]
===
match
---
name: group_by [75623,75631]
name: group_by [75674,75682]
===
match
---
trailer [77004,77011]
trailer [77055,77062]
===
match
---
atom_expr [16217,16228]
atom_expr [16217,16228]
===
match
---
suite [14697,14741]
suite [14697,14741]
===
match
---
operator: = [19261,19262]
operator: = [19261,19262]
===
match
---
expr_stmt [39937,39982]
expr_stmt [39937,39982]
===
match
---
param [55879,55893]
param [55930,55944]
===
match
---
name: NUM_DAGS_PER_DAGRUN_QUERY [85841,85866]
name: NUM_DAGS_PER_DAGRUN_QUERY [85892,85917]
===
match
---
and_test [22635,22699]
and_test [22635,22699]
===
match
---
string: "\n" [56834,56838]
string: "\n" [56885,56889]
===
match
---
import_from [2547,2584]
import_from [2547,2584]
===
match
---
atom_expr [2941,2977]
atom_expr [2941,2977]
===
match
---
param [30099,30109]
param [30099,30109]
===
match
---
atom_expr [48968,48996]
atom_expr [48968,48996]
===
match
---
atom_expr [45816,45863]
atom_expr [45816,45863]
===
match
---
argument [54137,54172]
argument [54188,54223]
===
match
---
arglist [85696,85740]
arglist [85747,85791]
===
match
---
trailer [15432,15462]
trailer [15432,15462]
===
match
---
for_stmt [38752,39128]
for_stmt [38752,39128]
===
match
---
name: following [28179,28188]
name: following [28179,28188]
===
match
---
operator: = [64567,64568]
operator: = [64618,64619]
===
match
---
trailer [36258,36264]
trailer [36258,36264]
===
match
---
number: 0 [56783,56784]
number: 0 [56834,56835]
===
match
---
name: self [24847,24851]
name: self [24847,24851]
===
match
---
param [58278,58283]
param [58329,58334]
===
match
---
operator: = [25149,25150]
operator: = [25149,25150]
===
match
---
comparison [88439,88469]
comparison [88490,88520]
===
match
---
atom_expr [62794,62816]
atom_expr [62845,62867]
===
match
---
trailer [75161,75168]
trailer [75212,75219]
===
match
---
parameters [16481,16494]
parameters [16481,16494]
===
match
---
name: session [63984,63991]
name: session [64035,64042]
===
match
---
dotted_name [2670,2694]
dotted_name [2670,2694]
===
match
---
trailer [19455,19460]
trailer [19455,19460]
===
match
---
operator: = [16068,16069]
operator: = [16068,16069]
===
match
---
name: expiration_date [79479,79494]
name: expiration_date [79530,79545]
===
match
---
operator: @ [95368,95369]
operator: @ [95419,95420]
===
match
---
name: datetime [967,975]
name: datetime [967,975]
===
match
---
name: tis [41014,41017]
name: tis [41014,41017]
===
match
---
arglist [52518,52703]
arglist [52569,52754]
===
match
---
name: next_dagrun_create_after [85789,85813]
name: next_dagrun_create_after [85840,85864]
===
match
---
trailer [42291,42295]
trailer [42291,42295]
===
match
---
operator: , [12368,12369]
operator: , [12368,12369]
===
match
---
simple_stmt [85345,85391]
simple_stmt [85396,85442]
===
match
---
string: """     These items are stored in the database for state related information     """ [83556,83640]
string: """     These items are stored in the database for state related information     """ [83607,83691]
===
match
---
name: sla_miss_callback [14334,14351]
name: sla_miss_callback [14334,14351]
===
match
---
atom_expr [90894,90923]
atom_expr [90945,90974]
===
match
---
atom_expr [61777,61808]
atom_expr [61828,61859]
===
match
---
name: dag [91969,91972]
name: dag [92020,92023]
===
match
---
if_stmt [52996,53108]
if_stmt [53047,53159]
===
match
---
simple_stmt [59930,59960]
simple_stmt [59981,60011]
===
match
---
atom [42735,42792]
atom [42735,42792]
===
match
---
decorated [36546,37086]
decorated [36546,37086]
===
match
---
atom_expr [76628,76637]
atom_expr [76679,76688]
===
match
---
operator: , [82401,82402]
operator: , [82452,82453]
===
match
---
name: value [29442,29447]
name: value [29442,29447]
===
match
---
trailer [50399,50406]
trailer [50450,50457]
===
match
---
atom_expr [42090,42118]
atom_expr [42090,42118]
===
match
---
trailer [12553,12566]
trailer [12553,12566]
===
match
---
name: signature [92625,92634]
name: signature [92676,92685]
===
match
---
suite [78309,78347]
suite [78360,78398]
===
match
---
operator: , [92774,92775]
operator: , [92825,92826]
===
match
---
trailer [95493,95524]
trailer [95544,95575]
===
match
---
name: dag [92143,92146]
name: dag [92194,92197]
===
match
---
name: cron_next [19446,19455]
name: cron_next [19446,19455]
===
match
---
trailer [92070,92136]
trailer [92121,92187]
===
match
---
suite [24767,24831]
suite [24767,24831]
===
match
---
operator: , [3038,3039]
operator: , [3038,3039]
===
match
---
operator: = [16811,16812]
operator: = [16811,16812]
===
match
---
operator: = [42248,42249]
operator: = [42248,42249]
===
match
---
name: execution_date [52649,52663]
name: execution_date [52700,52714]
===
match
---
name: DagRun [75416,75422]
name: DagRun [75467,75473]
===
match
---
string: 'DagTag' [85277,85285]
string: 'DagTag' [85328,85336]
===
match
---
atom_expr [91502,91518]
atom_expr [91553,91569]
===
match
---
name: taskinstance [2004,2016]
name: taskinstance [2004,2016]
===
match
---
param [30110,30122]
param [30110,30122]
===
match
---
atom_expr [42205,42234]
atom_expr [42205,42234]
===
match
---
expr_stmt [74194,74248]
expr_stmt [74245,74299]
===
match
---
trailer [13570,13585]
trailer [13570,13585]
===
match
---
name: difference [74220,74230]
name: difference [74271,74281]
===
match
---
number: 1 [49339,49340]
number: 1 [49390,49391]
===
match
---
atom_expr [11805,11822]
atom_expr [11805,11822]
===
match
---
trailer [50413,50419]
trailer [50464,50470]
===
match
---
trailer [76206,76213]
trailer [76257,76264]
===
match
---
argument [48983,48994]
argument [48983,48994]
===
match
---
trailer [62405,62423]
trailer [62456,62474]
===
match
---
name: self [63058,63062]
name: self [63109,63113]
===
match
---
expr_stmt [73773,73819]
expr_stmt [73824,73870]
===
match
---
param [38116,38120]
param [38116,38120]
===
match
---
name: next_run_date [25565,25578]
name: next_run_date [25565,25578]
===
match
---
argument [52873,52895]
argument [52924,52946]
===
match
---
decorator [32826,32836]
decorator [32826,32836]
===
match
---
name: count [56927,56932]
name: count [56978,56983]
===
match
---
name: tasks [66684,66689]
name: tasks [66735,66740]
===
match
---
operator: = [72445,72446]
operator: = [72496,72497]
===
match
---
atom_expr [64332,64349]
atom_expr [64383,64400]
===
match
---
name: TaskInstance [80541,80553]
name: TaskInstance [80592,80604]
===
match
---
operator: = [24794,24795]
operator: = [24794,24795]
===
match
---
name: dag_run_state [55583,55596]
name: dag_run_state [55634,55647]
===
match
---
atom_expr [63803,63820]
atom_expr [63854,63871]
===
match
---
name: copied [61026,61032]
name: copied [61077,61083]
===
match
---
expr_stmt [39603,39817]
expr_stmt [39603,39817]
===
match
---
dotted_name [2590,2609]
dotted_name [2590,2609]
===
match
---
simple_stmt [86526,86599]
simple_stmt [86577,86650]
===
match
---
argument [55542,55559]
argument [55593,55610]
===
match
---
operator: ** [90998,91000]
operator: ** [91049,91051]
===
match
---
trailer [75706,75740]
trailer [75757,75791]
===
match
---
parameters [55817,56107]
parameters [55868,56158]
===
match
---
name: str [29073,29076]
name: str [29073,29076]
===
match
---
trailer [18801,18811]
trailer [18801,18811]
===
match
---
simple_stmt [35263,35281]
simple_stmt [35263,35281]
===
match
---
simple_stmt [35620,35680]
simple_stmt [35620,35680]
===
match
---
trailer [74899,75132]
trailer [74950,75183]
===
match
---
operator: = [24737,24738]
operator: = [24737,24738]
===
match
---
trailer [49327,49333]
trailer [49378,49384]
===
match
---
funcdef [81257,82351]
funcdef [81308,82402]
===
match
---
tfpdef [91143,91166]
tfpdef [91194,91217]
===
match
---
operator: , [58498,58499]
operator: , [58549,58550]
===
match
---
trailer [93513,93520]
trailer [93564,93571]
===
match
---
trailer [12887,12896]
trailer [12887,12896]
===
match
---
name: timedelta [2952,2961]
name: timedelta [2952,2961]
===
match
---
trailer [62194,62213]
trailer [62245,62264]
===
match
---
simple_stmt [87677,87802]
simple_stmt [87728,87853]
===
match
---
atom_expr [90951,91029]
atom_expr [91002,91080]
===
match
---
operator: = [63130,63131]
operator: = [63181,63182]
===
match
---
name: DagRun [71919,71925]
name: DagRun [71970,71976]
===
match
---
trailer [53071,53107]
trailer [53122,53158]
===
match
---
name: dttm [28294,28298]
name: dttm [28294,28298]
===
match
---
operator: , [45389,45390]
operator: , [45389,45390]
===
match
---
atom_expr [62335,62360]
atom_expr [62386,62411]
===
match
---
operator: , [72297,72298]
operator: , [72348,72349]
===
match
---
fstring_expr [14621,14635]
fstring_expr [14621,14635]
===
match
---
name: self [86258,86262]
name: self [86309,86313]
===
match
---
decorator [29895,29905]
decorator [29895,29905]
===
match
---
name: dag [75754,75757]
name: dag [75805,75808]
===
match
---
atom_expr [65831,65844]
atom_expr [65882,65895]
===
match
---
operator: , [1654,1655]
operator: , [1654,1655]
===
match
---
atom_expr [25188,25200]
atom_expr [25188,25200]
===
match
---
name: start_date [25000,25010]
name: start_date [25000,25010]
===
match
---
atom_expr [61395,61408]
atom_expr [61446,61459]
===
match
---
operator: } [31561,31562]
operator: } [31561,31562]
===
match
---
argument [30406,30422]
argument [30406,30422]
===
match
---
name: session [76952,76959]
name: session [77003,77010]
===
match
---
return_stmt [30751,30785]
return_stmt [30751,30785]
===
match
---
name: get_latest_execution_date [37840,37865]
name: get_latest_execution_date [37840,37865]
===
match
---
decorator [38488,38498]
decorator [38488,38498]
===
match
---
string: """A tag name per dag, to allow quick filtering in the DAG view.""" [83181,83248]
string: """A tag name per dag, to allow quick filtering in the DAG view.""" [83232,83299]
===
match
---
trailer [93218,93220]
trailer [93269,93271]
===
match
---
parameters [28690,28745]
parameters [28690,28745]
===
match
---
name: TaskInstance [41619,41631]
name: TaskInstance [41619,41631]
===
match
---
name: BackfillJob [69077,69088]
name: BackfillJob [69128,69139]
===
match
---
string: """     Python dag decorator. Wraps a function into an Airflow DAG.     Accepts kwargs for operator kwarg. Can be used to parametrize DAGs.      :param dag_args: Arguments for DAG object     :type dag_args: list     :param dag_kwargs: Kwargs for DAG object.     :type dag_kwargs: dict     """ [92177,92469]
string: """     Python dag decorator. Wraps a function into an Airflow DAG.     Accepts kwargs for operator kwarg. Can be used to parametrize DAGs.      :param dag_args: Arguments for DAG object     :type dag_args: list     :param dag_kwargs: Kwargs for DAG object.     :type dag_kwargs: dict     """ [92228,92520]
===
match
---
operator: , [77739,77740]
operator: , [77790,77791]
===
match
---
operator: = [72247,72248]
operator: = [72298,72299]
===
match
---
decorator [78370,78387]
decorator [78421,78438]
===
match
---
name: filter [3554,3560]
name: filter [3554,3560]
===
match
---
trailer [81043,81049]
trailer [81094,81100]
===
match
---
atom_expr [78818,78853]
atom_expr [78869,78904]
===
match
---
suite [69668,69883]
suite [69719,69934]
===
match
---
trailer [39069,39076]
trailer [39069,39076]
===
match
---
name: state [42228,42233]
name: state [42228,42233]
===
match
---
string: 'end_date' [13197,13207]
string: 'end_date' [13197,13207]
===
match
---
arglist [2877,2882]
arglist [2877,2882]
===
match
---
parameters [31333,31339]
parameters [31333,31339]
===
match
---
operator: { [86346,86347]
operator: { [86397,86398]
===
match
---
name: parent_group [60914,60926]
name: parent_group [60965,60977]
===
match
---
name: TaskGroup [16070,16079]
name: TaskGroup [16070,16079]
===
match
---
name: result [58077,58083]
name: result [58128,58134]
===
match
---
name: dag_id [36306,36312]
name: dag_id [36306,36312]
===
match
---
name: on_failure_callback [34849,34868]
name: on_failure_callback [34849,34868]
===
match
---
suite [16625,17116]
suite [16625,17116]
===
match
---
name: result [58215,58221]
name: result [58266,58272]
===
match
---
name: user_defined_macros [40249,40268]
name: user_defined_macros [40249,40268]
===
match
---
argument [74081,74092]
argument [74132,74143]
===
match
---
name: include_subdags [49759,49774]
name: include_subdags [49810,49825]
===
match
---
name: BaseOperator [12370,12382]
name: BaseOperator [12370,12382]
===
match
---
trailer [85644,85657]
trailer [85695,85708]
===
match
---
name: BaseOperator [42597,42609]
name: BaseOperator [42597,42609]
===
match
---
operator: = [20019,20020]
operator: = [20019,20020]
===
match
---
operator: > [26647,26648]
operator: > [26647,26648]
===
match
---
trailer [25843,25875]
trailer [25843,25875]
===
match
---
trailer [45632,45638]
trailer [45632,45638]
===
match
---
operator: , [69504,69505]
operator: , [69555,69556]
===
match
---
name: orm_dag [74146,74153]
name: orm_dag [74197,74204]
===
match
---
operator: = [49976,49977]
operator: = [50027,50028]
===
match
---
name: self [86904,86908]
name: self [86955,86959]
===
match
---
funcdef [31583,31709]
funcdef [31583,31709]
===
match
---
simple_stmt [63405,63453]
simple_stmt [63456,63504]
===
match
---
trailer [27553,27560]
trailer [27553,27560]
===
match
---
name: get_default_executor [69040,69060]
name: get_default_executor [69091,69111]
===
match
---
name: get_next [19378,19386]
name: get_next [19378,19386]
===
match
---
name: t [62727,62728]
name: t [62778,62779]
===
match
---
name: List [45533,45537]
name: List [45533,45537]
===
match
---
operator: } [45905,45906]
operator: } [45905,45906]
===
match
---
atom_expr [48850,48859]
atom_expr [48850,48859]
===
match
---
operator: , [83966,83967]
operator: , [84017,84018]
===
match
---
name: ti_list [56943,56950]
name: ti_list [56994,57001]
===
match
---
operator: = [12171,12172]
operator: = [12171,12172]
===
match
---
trailer [42049,42119]
trailer [42049,42119]
===
match
---
expr_stmt [19953,20001]
expr_stmt [19953,20001]
===
match
---
simple_stmt [33720,33818]
simple_stmt [33720,33818]
===
match
---
parameters [16177,16190]
parameters [16177,16190]
===
match
---
comparison [15657,15693]
comparison [15657,15693]
===
match
---
trailer [28195,28214]
trailer [28195,28214]
===
match
---
name: _previous_context_managed_dags [95093,95123]
name: _previous_context_managed_dags [95144,95174]
===
match
---
name: Optional [45444,45452]
name: Optional [45444,45452]
===
match
---
arglist [69102,69620]
arglist [69153,69671]
===
match
---
operator: = [11584,11585]
operator: = [11584,11585]
===
match
---
name: t [60754,60755]
name: t [60805,60806]
===
match
---
name: t [25152,25153]
name: t [25152,25153]
===
match
---
operator: = [41606,41607]
operator: = [41606,41607]
===
match
---
name: paused_dag_ids [87583,87597]
name: paused_dag_ids [87634,87648]
===
match
---
name: func [74846,74850]
name: func [74897,74901]
===
match
---
if_stmt [40278,40366]
if_stmt [40278,40366]
===
match
---
decorator [69888,69905]
decorator [69939,69956]
===
match
---
name: delta [20266,20271]
name: delta [20266,20271]
===
match
---
name: calculate_dagrun_date_fields [91039,91067]
name: calculate_dagrun_date_fields [91090,91118]
===
match
---
name: start_date [50199,50209]
name: start_date [50250,50260]
===
match
---
atom [23138,23180]
atom [23138,23180]
===
match
---
name: dag_bag [54295,54302]
name: dag_bag [54346,54353]
===
match
---
param [66835,66847]
param [66886,66898]
===
match
---
name: property [87991,87999]
name: property [88042,88050]
===
match
---
name: self [49242,49246]
name: self [49293,49297]
===
match
---
operator: , [15446,15447]
operator: , [15446,15447]
===
match
---
trailer [77278,77285]
trailer [77329,77336]
===
match
---
name: tasks [76632,76637]
name: tasks [76683,76688]
===
match
---
operator: == [32029,32031]
operator: == [32029,32031]
===
match
---
name: BackfillJob [68742,68753]
name: BackfillJob [68793,68804]
===
match
---
name: State [50423,50428]
name: State [50474,50479]
===
match
---
trailer [42217,42223]
trailer [42217,42223]
===
match
---
atom_expr [76216,76225]
atom_expr [76267,76276]
===
match
---
name: self [12685,12689]
name: self [12685,12689]
===
match
---
atom_expr [76171,76182]
atom_expr [76222,76233]
===
match
---
name: airflow [68807,68814]
name: airflow [68858,68865]
===
match
---
name: Stats [2135,2140]
name: Stats [2135,2140]
===
match
---
argument [10085,10091]
argument [10085,10091]
===
match
---
name: filter [86557,86563]
name: filter [86608,86614]
===
match
---
operator: = [10223,10224]
operator: = [10223,10224]
===
match
---
funcdef [30005,30078]
funcdef [30005,30078]
===
match
---
trailer [49036,49042]
trailer [49036,49042]
===
match
---
or_test [23937,23981]
or_test [23937,23981]
===
match
---
trailer [37769,37773]
trailer [37769,37773]
===
match
---
atom_expr [85984,86010]
atom_expr [86035,86061]
===
match
---
name: task [52682,52686]
name: task [52733,52737]
===
match
---
name: is_ [42109,42112]
name: is_ [42109,42112]
===
match
---
funcdef [35839,36541]
funcdef [35839,36541]
===
match
---
string: """This method is deprecated in favor of partial_subset""" [58310,58368]
string: """This method is deprecated in favor of partial_subset""" [58361,58419]
===
match
---
operator: = [46341,46342]
operator: = [46341,46342]
===
match
---
trailer [24679,24697]
trailer [24679,24697]
===
match
---
atom_expr [32109,32121]
atom_expr [32109,32121]
===
match
---
simple_stmt [61839,61853]
simple_stmt [61890,61904]
===
match
---
param [58734,58759]
param [58785,58810]
===
match
---
string: "Attempted to clear too many tasks " [52102,52138]
string: "Attempted to clear too many tasks " [52153,52189]
===
match
---
atom_expr [45829,45850]
atom_expr [45829,45850]
===
match
---
name: self [24675,24679]
name: self [24675,24679]
===
match
---
name: child [61613,61618]
name: child [61664,61669]
===
match
---
operator: , [18663,18664]
operator: , [18663,18664]
===
match
---
name: utcnow [27554,27560]
name: utcnow [27554,27560]
===
match
---
name: next_run_date [25941,25954]
name: next_run_date [25941,25954]
===
match
---
param [67068,67082]
param [67119,67133]
===
match
---
funcdef [90012,91030]
funcdef [90063,91081]
===
match
---
trailer [61512,61520]
trailer [61563,61571]
===
match
---
parameters [64934,64946]
parameters [64985,64997]
===
match
---
name: self [39709,39713]
name: self [39709,39713]
===
match
---
operator: , [40414,40415]
operator: , [40414,40415]
===
match
---
atom_expr [75771,75785]
atom_expr [75822,75836]
===
match
---
name: count [57507,57512]
name: count [57558,57563]
===
match
---
simple_stmt [54981,55147]
simple_stmt [55032,55198]
===
match
---
name: self [51419,51423]
name: self [51470,51474]
===
match
---
parameters [32589,32609]
parameters [32589,32609]
===
match
---
suite [40307,40366]
suite [40307,40366]
===
match
---
name: end_date [55551,55559]
name: end_date [55602,55610]
===
match
---
operator: == [16214,16216]
operator: == [16214,16216]
===
match
---
name: keys [30778,30782]
name: keys [30778,30782]
===
match
---
atom_expr [61088,61114]
atom_expr [61139,61165]
===
match
---
name: self [86803,86807]
name: self [86854,86858]
===
match
---
operator: , [26065,26066]
operator: , [26065,26066]
===
match
---
name: cls [95767,95770]
name: cls [95818,95821]
===
match
---
name: timezone [19992,20000]
name: timezone [19992,20000]
===
match
---
param [37136,37141]
param [37136,37141]
===
match
---
operator: { [56942,56943]
operator: { [56993,56994]
===
match
---
expr_stmt [57789,57812]
expr_stmt [57840,57863]
===
match
---
trailer [72027,72138]
trailer [72078,72189]
===
match
---
operator: , [85963,85964]
operator: , [86014,86015]
===
match
---
atom_expr [83365,83389]
atom_expr [83416,83440]
===
match
---
operator: = [14066,14067]
operator: = [14066,14067]
===
match
---
atom_expr [59930,59946]
atom_expr [59981,59997]
===
match
---
name: user_defined_filters [40344,40364]
name: user_defined_filters [40344,40364]
===
match
---
decorator [88083,88100]
decorator [88134,88151]
===
match
---
operator: , [55892,55893]
operator: , [55943,55944]
===
match
---
name: expunge_all [54614,54625]
name: expunge_all [54665,54676]
===
match
---
comparison [78722,78746]
comparison [78773,78797]
===
match
---
trailer [25646,25665]
trailer [25646,25665]
===
match
---
name: child [61323,61328]
name: child [61374,61379]
===
match
---
atom [93916,93918]
atom [93967,93969]
===
match
---
atom_expr [16203,16213]
atom_expr [16203,16213]
===
match
---
atom_expr [12795,12833]
atom_expr [12795,12833]
===
match
---
name: dag [61862,61865]
name: dag [61913,61916]
===
match
---
expr_stmt [38728,38743]
expr_stmt [38728,38743]
===
match
---
name: matched_tasks [60035,60048]
name: matched_tasks [60086,60099]
===
match
---
trailer [86083,86090]
trailer [86134,86141]
===
match
---
name: t [25188,25189]
name: t [25188,25189]
===
match
---
if_stmt [50562,50630]
if_stmt [50613,50681]
===
match
---
atom_expr [50240,50257]
atom_expr [50291,50308]
===
match
---
suite [89426,89835]
suite [89477,89886]
===
match
---
name: or_ [1401,1404]
name: or_ [1401,1404]
===
match
---
name: tags [16038,16042]
name: tags [16038,16042]
===
match
---
name: clear [56177,56182]
name: clear [56228,56233]
===
match
---
atom_expr [62437,62457]
atom_expr [62488,62508]
===
match
---
decorators [88760,88794]
decorators [88811,88845]
===
match
---
name: dag_args [92148,92156]
name: dag_args [92199,92207]
===
match
---
operator: , [56297,56298]
operator: , [56348,56349]
===
match
---
param [46067,46085]
param [46067,46085]
===
match
---
trailer [87410,87440]
trailer [87461,87491]
===
match
---
trailer [44935,44942]
trailer [44935,44942]
===
match
---
atom_expr [65968,65982]
atom_expr [66019,66033]
===
match
---
name: dagruns [37526,37533]
name: dagruns [37526,37533]
===
match
---
trailer [12647,12661]
trailer [12647,12661]
===
match
---
name: self [26749,26753]
name: self [26749,26753]
===
match
---
string: 'end_date' [13749,13759]
string: 'end_date' [13749,13759]
===
match
---
and_test [65831,65862]
and_test [65882,65913]
===
match
---
name: __doc__ [93624,93631]
name: __doc__ [93675,93682]
===
match
---
parameters [87068,87113]
parameters [87119,87164]
===
match
---
atom_expr [54606,54627]
atom_expr [54657,54678]
===
match
---
operator: = [45124,45125]
operator: = [45124,45125]
===
match
---
trailer [85331,85338]
trailer [85382,85389]
===
match
---
operator: == [16396,16398]
operator: == [16396,16398]
===
match
---
simple_stmt [23131,23181]
simple_stmt [23131,23181]
===
match
---
name: executor [69234,69242]
name: executor [69285,69293]
===
match
---
operator: = [76169,76170]
operator: = [76220,76221]
===
match
---
trailer [87082,87087]
trailer [87133,87138]
===
match
---
name: dag_hash [72446,72454]
name: dag_hash [72497,72505]
===
match
---
trailer [62853,62875]
trailer [62904,62926]
===
match
---
name: TaskNotFound [1656,1668]
name: TaskNotFound [1656,1668]
===
match
---
name: parse_args [69840,69850]
name: parse_args [69891,69901]
===
match
---
trailer [62763,62773]
trailer [62814,62824]
===
match
---
name: update [35203,35209]
name: update [35203,35209]
===
match
---
name: name [83284,83288]
name: name [83335,83339]
===
match
---
suite [64822,64917]
suite [64873,64968]
===
match
---
operator: >= [91649,91651]
operator: >= [91700,91702]
===
match
---
name: Optional [10762,10770]
name: Optional [10762,10770]
===
match
---
simple_stmt [48831,48907]
simple_stmt [48831,48907]
===
match
---
name: isinstance [61267,61277]
name: isinstance [61318,61328]
===
match
---
atom_expr [86079,86117]
atom_expr [86130,86168]
===
match
---
name: num [18956,18959]
name: num [18956,18959]
===
match
---
name: naive [20065,20070]
name: naive [20065,20070]
===
match
---
atom [16652,16664]
atom [16652,16664]
===
match
---
simple_stmt [64362,64379]
simple_stmt [64413,64430]
===
match
---
name: StrictUndefined [10370,10385]
name: StrictUndefined [10370,10385]
===
match
---
name: orm_dag [75689,75696]
name: orm_dag [75740,75747]
===
match
---
name: self [40339,40343]
name: self [40339,40343]
===
match
---
atom_expr [21885,21918]
atom_expr [21885,21918]
===
match
---
expr_stmt [61578,61627]
expr_stmt [61629,61678]
===
match
---
parameters [29343,29349]
parameters [29343,29349]
===
match
---
trailer [41047,41054]
trailer [41047,41054]
===
match
---
trailer [62746,62759]
trailer [62797,62810]
===
match
---
atom [27466,27500]
atom [27466,27500]
===
match
---
decorator [78352,78366]
decorator [78403,78417]
===
match
---
atom_expr [62905,62920]
atom_expr [62956,62971]
===
match
---
return_stmt [29781,29805]
return_stmt [29781,29805]
===
match
---
trailer [30782,30784]
trailer [30782,30784]
===
match
---
name: staticmethod [79851,79863]
name: staticmethod [79902,79914]
===
match
---
name: values [30545,30551]
name: values [30545,30551]
===
match
---
trailer [74973,75117]
trailer [75024,75168]
===
match
---
trailer [52405,52422]
trailer [52456,52473]
===
match
---
operator: - [40885,40886]
operator: - [40885,40886]
===
match
---
name: airflow [94405,94412]
name: airflow [94456,94463]
===
match
---
atom_expr [15626,15654]
atom_expr [15626,15654]
===
match
---
name: utils [2560,2565]
name: utils [2560,2565]
===
match
---
operator: ** [93497,93499]
operator: ** [93548,93550]
===
match
---
name: timedelta [10075,10084]
name: timedelta [10075,10084]
===
match
---
name: generate_run_id [71926,71941]
name: generate_run_id [71977,71992]
===
match
---
operator: = [22891,22892]
operator: = [22891,22892]
===
match
---
atom_expr [11836,11883]
atom_expr [11836,11883]
===
match
---
name: session [31769,31776]
name: session [31769,31776]
===
match
---
atom_expr [20351,20364]
atom_expr [20351,20364]
===
match
---
trailer [2900,2910]
trailer [2900,2910]
===
match
---
name: previous [21824,21832]
name: previous [21824,21832]
===
match
---
tfpdef [11398,11423]
tfpdef [11398,11423]
===
match
---
param [63088,63093]
param [63139,63144]
===
match
---
name: get_is_paused [33169,33182]
name: get_is_paused [33169,33182]
===
match
---
return_stmt [16362,16444]
return_stmt [16362,16444]
===
match
---
name: cls [81283,81286]
name: cls [81334,81337]
===
match
---
name: tis [55270,55273]
name: tis [55321,55324]
===
match
---
name: self [55320,55324]
name: self [55371,55375]
===
match
---
name: sqlalchemy [1410,1420]
name: sqlalchemy [1410,1420]
===
match
---
name: dag_id [52521,52527]
name: dag_id [52572,52578]
===
match
---
name: property [30880,30888]
name: property [30880,30888]
===
match
---
trailer [88551,88563]
trailer [88602,88614]
===
match
---
string: 'loader' [39637,39645]
string: 'loader' [39637,39645]
===
match
---
not_test [71498,71510]
not_test [71549,71561]
===
match
---
trailer [31091,31099]
trailer [31091,31099]
===
match
---
simple_stmt [54878,54887]
simple_stmt [54929,54938]
===
match
---
suite [29946,29978]
suite [29946,29978]
===
match
---
name: debug [26020,26025]
name: debug [26020,26025]
===
match
---
atom_expr [36919,37052]
atom_expr [36919,37052]
===
match
---
operator: = [88184,88185]
operator: = [88235,88236]
===
match
---
trailer [65658,65667]
trailer [65709,65718]
===
match
---
fstring_end: " [63450,63451]
fstring_end: " [63501,63502]
===
match
---
suite [89856,89886]
suite [89907,89937]
===
match
---
param [70264,70295]
param [70315,70346]
===
match
---
expr_stmt [71910,71967]
expr_stmt [71961,72018]
===
match
---
atom_expr [25957,25997]
atom_expr [25957,25997]
===
match
---
operator: , [70341,70342]
operator: , [70392,70393]
===
match
---
name: include_subdags [53839,53854]
name: include_subdags [53890,53905]
===
match
---
name: state [80929,80934]
name: state [80980,80985]
===
match
---
simple_stmt [77828,78035]
simple_stmt [77879,78086]
===
match
---
param [64562,64569]
param [64613,64620]
===
match
---
atom_expr [74558,74605]
atom_expr [74609,74656]
===
match
---
suite [53016,53108]
suite [53067,53159]
===
match
---
operator: >= [24893,24895]
operator: >= [24893,24895]
===
match
---
name: conditions [48831,48841]
name: conditions [48831,48841]
===
match
---
atom_expr [27467,27479]
atom_expr [27467,27479]
===
match
---
arglist [19737,19775]
arglist [19737,19775]
===
match
---
name: Optional [10159,10167]
name: Optional [10159,10167]
===
match
---
name: filter_task_group [60889,60906]
name: filter_task_group [60940,60957]
===
match
---
simple_stmt [44923,44949]
simple_stmt [44923,44949]
===
match
---
trailer [41479,41486]
trailer [41479,41486]
===
match
---
param [31169,31173]
param [31169,31173]
===
match
---
name: _context_managed_dag [95302,95322]
name: _context_managed_dag [95353,95373]
===
match
---
operator: , [37140,37141]
operator: , [37140,37141]
===
match
---
while_stmt [25559,25681]
while_stmt [25559,25681]
===
match
---
name: execution_date [53531,53545]
name: execution_date [53582,53596]
===
match
---
name: self [26495,26499]
name: self [26495,26499]
===
match
---
name: alive_dag_filelocs [89497,89515]
name: alive_dag_filelocs [89548,89566]
===
match
---
operator: , [16385,16386]
operator: , [16385,16386]
===
match
---
decorated [78957,79845]
decorated [79008,79896]
===
match
---
suite [48814,48950]
suite [48814,48950]
===
match
---
operator: , [60780,60781]
operator: , [60831,60832]
===
match
---
decorated [95692,95792]
decorated [95743,95843]
===
match
---
atom_expr [52275,52302]
atom_expr [52326,52353]
===
match
---
name: session [45399,45406]
name: session [45399,45406]
===
match
---
suite [81141,81207]
suite [81192,81258]
===
match
---
name: state [50530,50535]
name: state [50581,50586]
===
match
---
number: 4 [64605,64606]
number: 4 [64656,64657]
===
match
---
simple_stmt [92177,92470]
simple_stmt [92228,92521]
===
match
---
name: subdags [77732,77739]
name: subdags [77783,77790]
===
match
---
trailer [44893,44901]
trailer [44893,44901]
===
match
---
atom_expr [10280,10293]
atom_expr [10280,10293]
===
match
---
funcdef [26731,28041]
funcdef [26731,28041]
===
match
---
tfpdef [92487,92498]
tfpdef [92538,92549]
===
match
---
name: session [88862,88869]
name: session [88913,88920]
===
match
---
name: DEFAULT_VIEW_PRESETS [2978,2998]
name: DEFAULT_VIEW_PRESETS [2978,2998]
===
match
---
atom_expr [76518,76533]
atom_expr [76569,76584]
===
match
---
atom_expr [78908,78926]
atom_expr [78959,78977]
===
match
---
param [91093,91142]
param [91144,91193]
===
match
---
trailer [61394,61409]
trailer [61445,61460]
===
match
---
name: _value [17313,17319]
name: _value [17313,17319]
===
match
---
name: state [42218,42223]
name: state [42218,42223]
===
match
---
name: TI [49109,49111]
name: TI [49109,49111]
===
match
---
expr_stmt [63504,63528]
expr_stmt [63555,63579]
===
match
---
comp_op [49209,49215]
comp_op [49209,49215]
===
match
---
atom_expr [72154,72510]
atom_expr [72205,72561]
===
match
---
name: relativedelta [1278,1291]
name: relativedelta [1278,1291]
===
match
---
simple_stmt [29095,29116]
simple_stmt [29095,29116]
===
match
---
not_test [41371,41403]
not_test [41371,41403]
===
match
---
string: 'webserver' [87944,87955]
string: 'webserver' [87995,88006]
===
match
---
not_test [24240,24295]
not_test [24240,24295]
===
match
---
name: next_run_date [27871,27884]
name: next_run_date [27871,27884]
===
match
---
expr_stmt [3437,3490]
expr_stmt [3437,3490]
===
match
---
param [28069,28074]
param [28069,28074]
===
match
---
name: _upgrade_outdated_dag_access_control [17470,17506]
name: _upgrade_outdated_dag_access_control [17470,17506]
===
match
---
name: STORE_DAG_CODE [77414,77428]
name: STORE_DAG_CODE [77465,77479]
===
match
---
operator: , [1199,1200]
operator: , [1199,1200]
===
match
---
string: "or there may be a cyclic dependency." [52171,52209]
string: "or there may be a cyclic dependency." [52222,52260]
===
match
---
operator: += [64639,64641]
operator: += [64690,64692]
===
match
---
name: access_control [29576,29590]
name: access_control [29576,29590]
===
match
---
name: StrictUndefined [10344,10359]
name: StrictUndefined [10344,10359]
===
match
---
return_stmt [57578,57590]
return_stmt [57629,57641]
===
match
---
atom_expr [44584,44613]
atom_expr [44584,44613]
===
match
---
simple_stmt [1234,1264]
simple_stmt [1234,1264]
===
match
---
tfpdef [88145,88168]
tfpdef [88196,88219]
===
match
---
sync_comp_for [77479,77498]
sync_comp_for [77530,77549]
===
match
---
if_stmt [12437,12834]
if_stmt [12437,12834]
===
match
---
simple_stmt [42870,43260]
simple_stmt [42870,43260]
===
match
---
tfpdef [70061,70091]
tfpdef [70112,70142]
===
match
---
suite [95751,95792]
suite [95802,95843]
===
match
---
funcdef [86381,86434]
funcdef [86432,86485]
===
match
---
name: dag [55316,55319]
name: dag [55367,55370]
===
match
---
name: dag [59861,59864]
name: dag [59912,59915]
===
match
---
name: naive [20586,20591]
name: naive [20586,20591]
===
match
---
trailer [93474,93521]
trailer [93525,93572]
===
match
---
name: subdag [43291,43297]
name: subdag [43291,43297]
===
match
---
operator: , [55977,55978]
operator: , [56028,56029]
===
match
---
atom_expr [52682,52701]
atom_expr [52733,52752]
===
match
---
name: subdags [39120,39127]
name: subdags [39120,39127]
===
match
---
trailer [82684,82694]
trailer [82735,82745]
===
match
---
operator: = [24544,24545]
operator: = [24544,24545]
===
match
---
name: runs [35620,35624]
name: runs [35620,35624]
===
match
---
name: Dict [1091,1095]
name: Dict [1091,1095]
===
match
---
string: """         Set ``is_active=False`` on the DAGs for which the DAG files have been removed.         Additionally change ``is_active=False`` to ``True`` if the DAG file exists.          :param alive_dag_filelocs: file paths of alive DAGs         :param session: ORM Session         """ [88885,89168]
string: """         Set ``is_active=False`` on the DAGs for which the DAG files have been removed.         Additionally change ``is_active=False`` to ``True`` if the DAG file exists.          :param alive_dag_filelocs: file paths of alive DAGs         :param session: ORM Session         """ [88936,89219]
===
match
---
name: __doc__ [93672,93679]
name: __doc__ [93723,93730]
===
match
---
name: self [82843,82847]
name: self [82894,82898]
===
match
---
name: Optional [11207,11215]
name: Optional [11207,11215]
===
match
---
atom_expr [65987,66015]
atom_expr [66038,66066]
===
match
---
operator: , [41102,41103]
operator: , [41102,41103]
===
match
---
argument [35659,35678]
argument [35659,35678]
===
match
---
comparison [90765,90807]
comparison [90816,90858]
===
match
---
parameters [17204,17210]
parameters [17204,17210]
===
match
---
trailer [70213,70225]
trailer [70264,70276]
===
match
---
trailer [13735,13748]
trailer [13735,13748]
===
match
---
if_stmt [18821,18869]
if_stmt [18821,18869]
===
match
---
name: missing_dag_ids [74194,74209]
name: missing_dag_ids [74245,74260]
===
match
---
name: self [14976,14980]
name: self [14976,14980]
===
match
---
arith_expr [20274,20305]
arith_expr [20274,20305]
===
match
---
trailer [80527,80581]
trailer [80578,80632]
===
match
---
operator: , [28467,28468]
operator: , [28467,28468]
===
match
---
atom_expr [71531,71554]
atom_expr [71582,71605]
===
match
---
name: run_type [70195,70203]
name: run_type [70246,70254]
===
match
---
name: get_active_runs [35455,35470]
name: get_active_runs [35455,35470]
===
match
---
not_test [71981,71991]
not_test [72032,72042]
===
match
---
simple_stmt [29175,29202]
simple_stmt [29175,29202]
===
match
---
name: is_subdag [75806,75815]
name: is_subdag [75857,75866]
===
match
---
name: t [62573,62574]
name: t [62624,62625]
===
match
---
name: make_aware [21844,21854]
name: make_aware [21844,21854]
===
match
---
atom_expr [58583,58619]
atom_expr [58634,58670]
===
match
---
operator: = [37879,37880]
operator: = [37879,37880]
===
match
---
name: DAG [29666,29669]
name: DAG [29666,29669]
===
match
---
expr_stmt [69071,69630]
expr_stmt [69122,69681]
===
match
---
operator: @ [40705,40706]
operator: @ [40705,40706]
===
match
---
fstring [86338,86361]
fstring [86389,86412]
===
match
---
or_test [22621,22743]
or_test [22621,22743]
===
match
---
name: end_date [65659,65667]
name: end_date [65710,65718]
===
match
---
atom_expr [38241,38434]
atom_expr [38241,38434]
===
match
---
name: self [88567,88571]
name: self [88618,88622]
===
match
---
trailer [12285,12293]
trailer [12285,12293]
===
match
---
decorator [45296,45313]
decorator [45296,45313]
===
match
---
trailer [90893,90924]
trailer [90944,90975]
===
match
---
atom_expr [42753,42763]
atom_expr [42753,42763]
===
match
---
name: self [72181,72185]
name: self [72232,72236]
===
match
---
atom_expr [66703,66722]
atom_expr [66754,66773]
===
match
---
param [87069,87088]
param [87120,87139]
===
match
---
name: DR [3663,3665]
name: DR [3663,3665]
===
match
---
atom_expr [89898,89914]
atom_expr [89949,89965]
===
match
---
suite [93978,94043]
suite [94029,94094]
===
match
---
simple_stmt [11447,11494]
simple_stmt [11447,11494]
===
match
---
operator: -> [31340,31342]
operator: -> [31340,31342]
===
match
---
name: orm_dag [77095,77102]
name: orm_dag [77146,77153]
===
match
---
name: validate_key [2339,2351]
name: validate_key [2339,2351]
===
match
---
trailer [25985,25996]
trailer [25985,25996]
===
match
---
trailer [83297,83328]
trailer [83348,83379]
===
match
---
trailer [48937,48949]
trailer [48937,48949]
===
match
---
trailer [77666,77668]
trailer [77717,77719]
===
match
---
operator: = [66275,66276]
operator: = [66326,66327]
===
match
---
atom_expr [39210,39220]
atom_expr [39210,39220]
===
match
---
operator: = [64406,64407]
operator: = [64457,64458]
===
match
---
param [29627,29632]
param [29627,29632]
===
match
---
decorated [29121,29202]
decorated [29121,29202]
===
match
---
name: utils_date_range [18884,18900]
name: utils_date_range [18884,18900]
===
match
---
name: update [40332,40338]
name: update [40332,40338]
===
match
---
trailer [41080,41087]
trailer [41080,41087]
===
match
---
arglist [10576,10601]
arglist [10576,10601]
===
match
---
name: self [27489,27493]
name: self [27489,27493]
===
match
---
trailer [49197,49208]
trailer [49197,49208]
===
match
---
operator: , [16388,16389]
operator: , [16388,16389]
===
match
---
name: str [31178,31181]
name: str [31178,31181]
===
match
---
name: dags [73162,73166]
name: dags [73213,73217]
===
match
---
trailer [74934,74952]
trailer [74985,75003]
===
match
---
trailer [42068,42072]
trailer [42068,42072]
===
match
---
param [45996,46010]
param [45996,46010]
===
match
---
tfpdef [87069,87087]
tfpdef [87120,87138]
===
match
---
parameters [26748,26781]
parameters [26748,26781]
===
match
---
simple_stmt [78043,78082]
simple_stmt [78094,78133]
===
match
---
simple_stmt [42000,42146]
simple_stmt [42000,42146]
===
match
---
operator: = [12248,12249]
operator: = [12248,12249]
===
match
---
trailer [33254,33272]
trailer [33254,33272]
===
match
---
name: include_externally_triggered [3195,3223]
name: include_externally_triggered [3195,3223]
===
match
---
simple_stmt [75754,75787]
simple_stmt [75805,75838]
===
match
---
trailer [37630,37637]
trailer [37630,37637]
===
match
---
decorator [29719,29729]
decorator [29719,29729]
===
match
---
trailer [49056,49063]
trailer [49056,49063]
===
match
---
name: dag_model [89759,89768]
name: dag_model [89810,89819]
===
match
---
name: self [82715,82719]
name: self [82766,82770]
===
match
---
param [57613,57618]
param [57664,57669]
===
match
---
operator: , [30433,30434]
operator: , [30433,30434]
===
match
---
expr_stmt [84986,85015]
expr_stmt [85037,85066]
===
match
---
atom_expr [74831,74844]
atom_expr [74882,74895]
===
match
---
name: _context_managed_dag [95636,95656]
name: _context_managed_dag [95687,95707]
===
match
---
if_stmt [28307,28382]
if_stmt [28307,28382]
===
match
---
name: Optional [10416,10424]
name: Optional [10416,10424]
===
match
---
trailer [95076,95081]
trailer [95127,95132]
===
match
---
name: concurrency_reached [32165,32184]
name: concurrency_reached [32165,32184]
===
match
---
name: classmethod [89996,90007]
name: classmethod [90047,90058]
===
match
---
name: k [57979,57980]
name: k [58030,58031]
===
match
---
name: len [56668,56671]
name: len [56719,56722]
===
match
---
simple_stmt [67180,68696]
simple_stmt [67231,68747]
===
match
---
name: subdag [38690,38696]
name: subdag [38690,38696]
===
match
---
trailer [12512,12519]
trailer [12512,12519]
===
match
---
name: start_date [12440,12450]
name: start_date [12440,12450]
===
match
---
operator: = [16036,16037]
operator: = [16036,16037]
===
match
---
name: items [93970,93975]
name: items [94021,94026]
===
match
---
name: property [30792,30800]
name: property [30792,30800]
===
match
---
expr_stmt [76332,76371]
expr_stmt [76383,76422]
===
match
---
operator: = [69831,69832]
operator: = [69882,69883]
===
match
---
name: dp [64119,64121]
name: dp [64170,64172]
===
match
---
operator: = [83688,83689]
operator: = [83739,83740]
===
match
---
name: execution_date [71952,71966]
name: execution_date [72003,72017]
===
match
---
trailer [94504,94524]
trailer [94555,94575]
===
match
---
operator: , [86661,86662]
operator: , [86712,86713]
===
match
---
atom_expr [64584,64620]
atom_expr [64635,64671]
===
match
---
string: 'timezone' [12864,12874]
string: 'timezone' [12864,12874]
===
match
---
string: 'is_picklable' [63506,63520]
string: 'is_picklable' [63557,63571]
===
match
---
name: any [76584,76587]
name: any [76635,76638]
===
match
---
operator: = [37534,37535]
operator: = [37534,37535]
===
match
---
operator: = [14238,14239]
operator: = [14238,14239]
===
match
---
name: acyclic [44544,44551]
name: acyclic [44544,44551]
===
match
---
trailer [10167,10177]
trailer [10167,10177]
===
match
---
name: parent_dag [76044,76054]
name: parent_dag [76095,76105]
===
match
---
atom_expr [84995,85015]
atom_expr [85046,85066]
===
match
---
suite [68789,68901]
suite [68840,68952]
===
match
---
name: TaskGroup [2702,2711]
name: TaskGroup [2702,2711]
===
match
---
name: start_date [49518,49528]
name: start_date [49569,49579]
===
match
---
simple_stmt [55743,55760]
simple_stmt [55794,55811]
===
match
---
simple_stmt [832,842]
simple_stmt [832,842]
===
match
---
name: is_ [81091,81094]
name: is_ [81142,81145]
===
match
---
dotted_name [29208,29228]
dotted_name [29208,29228]
===
match
---
name: perm [18259,18263]
name: perm [18259,18263]
===
match
---
suite [76931,76976]
suite [76982,77027]
===
match
---
operator: == [78742,78744]
operator: == [78793,78795]
===
match
---
expr_stmt [14976,14998]
expr_stmt [14976,14998]
===
match
---
atom_expr [15094,15118]
atom_expr [15094,15118]
===
match
---
trailer [27468,27479]
trailer [27468,27479]
===
match
---
name: traceback [884,893]
name: traceback [884,893]
===
match
---
name: ID_LEN [83356,83362]
name: ID_LEN [83407,83413]
===
match
---
atom_expr [26475,26485]
atom_expr [26475,26485]
===
match
---
operator: = [62497,62498]
operator: = [62548,62549]
===
match
---
suite [23982,24007]
suite [23982,24007]
===
match
---
strings [18371,18509]
strings [18371,18509]
===
match
---
suite [71992,72139]
suite [72043,72190]
===
match
---
atom_expr [65297,65312]
atom_expr [65348,65363]
===
match
---
name: executors [68953,68962]
name: executors [69004,69013]
===
match
---
name: property [38489,38497]
name: property [38489,38497]
===
match
---
trailer [61070,61085]
trailer [61121,61136]
===
match
---
expr_stmt [75297,75675]
expr_stmt [75348,75726]
===
match
---
operator: , [55830,55831]
operator: , [55881,55882]
===
match
---
name: tii [53226,53229]
name: tii [53277,53280]
===
match
---
simple_stmt [79828,79845]
simple_stmt [79879,79896]
===
match
---
arglist [74917,75118]
arglist [74968,75169]
===
match
---
operator: = [15463,15464]
operator: = [15463,15464]
===
match
---
atom_expr [45654,45680]
atom_expr [45654,45680]
===
match
---
trailer [21854,21865]
trailer [21854,21865]
===
match
---
name: filter [79444,79450]
name: filter [79495,79501]
===
match
---
name: add [72527,72530]
name: add [72578,72581]
===
match
---
arglist [85366,85389]
arglist [85417,85440]
===
match
---
name: setter [29222,29228]
name: setter [29222,29228]
===
match
---
trailer [91524,91549]
trailer [91575,91600]
===
match
---
name: provide_session [63905,63920]
name: provide_session [63956,63971]
===
match
---
arglist [76706,76816]
arglist [76757,76867]
===
match
---
name: List [1130,1134]
name: List [1130,1134]
===
match
---
suite [58836,62973]
suite [58887,63024]
===
match
---
name: self [39463,39467]
name: self [39463,39467]
===
match
---
expr_stmt [41470,41527]
expr_stmt [41470,41527]
===
match
---
arglist [72174,72500]
arglist [72225,72551]
===
match
---
operator: , [58828,58829]
operator: , [58879,58880]
===
match
---
trailer [40236,40243]
trailer [40236,40243]
===
match
---
trailer [45537,45542]
trailer [45537,45542]
===
match
---
name: active_dates [35744,35756]
name: active_dates [35744,35756]
===
match
---
name: cascade [85287,85294]
name: cascade [85338,85345]
===
match
---
string: 'task_ids' [9694,9704]
string: 'task_ids' [9694,9704]
===
match
---
atom_expr [57529,57569]
atom_expr [57580,57620]
===
match
---
operator: = [66891,66892]
operator: = [66942,66943]
===
match
---
operator: , [29440,29441]
operator: , [29440,29441]
===
match
---
trailer [31968,31974]
trailer [31968,31974]
===
match
---
name: copy [795,799]
name: copy [795,799]
===
match
---
operator: { [45885,45886]
operator: { [45885,45886]
===
match
---
name: run_type [72415,72423]
name: run_type [72466,72474]
===
match
---
atom_expr [83298,83309]
atom_expr [83349,83360]
===
match
---
name: max_recursion_depth [54210,54229]
name: max_recursion_depth [54261,54280]
===
match
---
trailer [29966,29977]
trailer [29966,29977]
===
match
---
name: RUNNING [75491,75498]
name: RUNNING [75542,75549]
===
match
---
name: access_control [29606,29620]
name: access_control [29606,29620]
===
match
---
trailer [36967,36974]
trailer [36967,36974]
===
match
---
name: DAG [95746,95749]
name: DAG [95797,95800]
===
match
---
atom_expr [39897,39926]
atom_expr [39897,39926]
===
match
---
fstring [14587,14636]
fstring [14587,14636]
===
match
---
suite [26565,26696]
suite [26565,26696]
===
match
---
decorated [87990,88078]
decorated [88041,88129]
===
match
---
name: self [49124,49128]
name: self [49124,49128]
===
match
---
trailer [10274,10294]
trailer [10274,10294]
===
match
---
name: int [91163,91166]
name: int [91214,91217]
===
match
---
name: Column [84924,84930]
name: Column [84975,84981]
===
match
---
name: is_active [89769,89778]
name: is_active [89820,89829]
===
match
---
name: include_subdag_tasks [44972,44992]
name: include_subdag_tasks [44972,44992]
===
match
---
param [22099,22104]
param [22099,22104]
===
match
---
atom_expr [13328,13343]
atom_expr [13328,13343]
===
match
---
name: upstream_list [42538,42551]
name: upstream_list [42538,42551]
===
match
---
name: session [55478,55485]
name: session [55529,55536]
===
match
---
not_test [12846,12875]
not_test [12846,12875]
===
match
---
operator: = [48966,48967]
operator: = [48966,48967]
===
match
---
if_stmt [63245,63397]
if_stmt [63296,63448]
===
match
---
name: pendulum [1225,1233]
name: pendulum [1225,1233]
===
match
---
trailer [51790,51806]
trailer [51841,51857]
===
match
---
name: old_dag [95444,95451]
name: old_dag [95495,95502]
===
match
---
name: task [65297,65301]
name: task [65348,65352]
===
match
---
name: end_date [55879,55887]
name: end_date [55930,55938]
===
match
---
trailer [88622,88637]
trailer [88673,88688]
===
match
---
name: dag_id [48867,48873]
name: dag_id [48867,48873]
===
match
---
fstring_end: ' [14857,14858]
fstring_end: ' [14857,14858]
===
match
---
simple_stmt [62162,62254]
simple_stmt [62213,62305]
===
match
---
operator: = [64265,64266]
operator: = [64316,64317]
===
match
---
operator: = [11325,11326]
operator: = [11325,11326]
===
match
---
name: t [26490,26491]
name: t [26490,26491]
===
match
---
testlist_comp [22851,22861]
testlist_comp [22851,22861]
===
match
---
name: confirm_prompt [57304,57318]
name: confirm_prompt [57355,57369]
===
match
---
atom_expr [38922,38941]
atom_expr [38922,38941]
===
match
---
name: self [16178,16182]
name: self [16178,16182]
===
match
---
operator: == [41638,41640]
operator: == [41638,41640]
===
match
---
suite [17326,17372]
suite [17326,17372]
===
match
---
trailer [16889,16904]
trailer [16889,16904]
===
match
---
trailer [32119,32121]
trailer [32119,32121]
===
match
---
simple_stmt [54805,54822]
simple_stmt [54856,54873]
===
match
---
string: 'dag_id' [93325,93333]
string: 'dag_id' [93376,93384]
===
match
---
operator: = [46429,46430]
operator: = [46429,46430]
===
match
---
operator: , [57235,57236]
operator: , [57286,57287]
===
match
---
name: get_downstream [64703,64717]
name: get_downstream [64754,64768]
===
match
---
param [11341,11389]
param [11341,11389]
===
match
---
operator: == [86738,86740]
operator: == [86789,86791]
===
match
---
name: bool [42847,42851]
name: bool [42847,42851]
===
match
---
operator: = [39941,39942]
operator: = [39941,39942]
===
match
---
string: 'dags_are_paused_at_creation' [83905,83934]
string: 'dags_are_paused_at_creation' [83956,83985]
===
match
---
name: add [74626,74629]
name: add [74677,74680]
===
match
---
argument [56358,56378]
argument [56409,56429]
===
match
---
name: s [41973,41974]
name: s [41973,41974]
===
match
---
name: dag_id [86663,86669]
name: dag_id [86714,86720]
===
match
---
simple_stmt [77368,77393]
simple_stmt [77419,77444]
===
match
---
return_stmt [83442,83458]
return_stmt [83493,83509]
===
match
---
name: self [78108,78112]
name: self [78159,78163]
===
match
---
trailer [13715,13730]
trailer [13715,13730]
===
match
---
name: dags [56149,56153]
name: dags [56200,56204]
===
match
---
expr_stmt [74776,75198]
expr_stmt [74827,75249]
===
match
---
name: tis [50835,50838]
name: tis [50886,50889]
===
match
---
return_stmt [31262,31304]
return_stmt [31262,31304]
===
match
---
name: self [20664,20668]
name: self [20664,20668]
===
match
---
param [64935,64940]
param [64986,64991]
===
match
---
simple_stmt [12779,12834]
simple_stmt [12779,12834]
===
match
---
trailer [58147,58154]
trailer [58198,58205]
===
match
---
name: self [25981,25985]
name: self [25981,25985]
===
match
---
trailer [17091,17115]
trailer [17091,17115]
===
match
---
atom_expr [72690,72727]
atom_expr [72741,72778]
===
match
---
name: self [59785,59789]
name: self [59836,59840]
===
match
---
trailer [36982,36989]
trailer [36982,36989]
===
match
---
suite [14465,14651]
suite [14465,14651]
===
match
---
atom_expr [59972,60021]
atom_expr [60023,60072]
===
match
---
trailer [63997,64007]
trailer [64048,64058]
===
match
---
operator: , [2517,2518]
operator: , [2517,2518]
===
match
---
atom_expr [61340,61353]
atom_expr [61391,61404]
===
match
---
operator: { [16146,16147]
operator: { [16146,16147]
===
match
---
operator: { [11665,11666]
operator: { [11665,11666]
===
match
---
atom_expr [87935,87984]
atom_expr [87986,88035]
===
match
---
name: task_dict [60728,60737]
name: task_dict [60779,60788]
===
match
---
trailer [27756,27775]
trailer [27756,27775]
===
match
---
name: tis [54817,54820]
name: tis [54868,54871]
===
match
---
trailer [78725,78741]
trailer [78776,78792]
===
match
---
param [55854,55870]
param [55905,55921]
===
match
---
name: task_dict [62542,62551]
name: task_dict [62593,62602]
===
match
---
atom_expr [95454,95478]
atom_expr [95505,95529]
===
match
---
trailer [48879,48887]
trailer [48879,48887]
===
match
---
name: external_dag_id [52536,52551]
name: external_dag_id [52587,52602]
===
match
---
param [88826,88830]
param [88877,88881]
===
match
---
name: set_dag_runs_state [55434,55452]
name: set_dag_runs_state [55485,55503]
===
match
---
trailer [13264,13276]
trailer [13264,13276]
===
match
---
atom_expr [86564,86579]
atom_expr [86615,86630]
===
match
---
string: """This method is deprecated in favor of bulk_write_to_db""" [72864,72924]
string: """This method is deprecated in favor of bulk_write_to_db""" [72915,72975]
===
match
---
simple_stmt [64063,64073]
simple_stmt [64114,64124]
===
match
---
atom_expr [22635,22657]
atom_expr [22635,22657]
===
match
---
operator: = [15926,15927]
operator: = [15926,15927]
===
match
---
name: task [39065,39069]
name: task [39065,39069]
===
match
---
name: value [94036,94041]
name: value [94087,94092]
===
match
---
name: _access_control [29648,29663]
name: _access_control [29648,29663]
===
match
---
return_stmt [17870,17881]
return_stmt [17870,17881]
===
match
---
expr_stmt [13528,13618]
expr_stmt [13528,13618]
===
match
---
name: str [15443,15446]
name: str [15443,15446]
===
match
---
trailer [44690,44698]
trailer [44690,44698]
===
match
---
dotted_name [1772,1793]
dotted_name [1772,1793]
===
match
---
atom_expr [64610,64619]
atom_expr [64661,64670]
===
match
---
operator: , [9704,9705]
operator: , [9704,9705]
===
match
---
suite [35246,35281]
suite [35246,35281]
===
match
---
name: pickle [63601,63607]
name: pickle [63652,63658]
===
match
---
operator: @ [73199,73200]
operator: @ [73250,73251]
===
match
---
operator: = [67075,67076]
operator: = [67126,67127]
===
match
---
simple_stmt [29463,29489]
simple_stmt [29463,29489]
===
match
---
suite [82917,83155]
suite [82968,83206]
===
match
---
name: also_include [60853,60865]
name: also_include [60904,60916]
===
match
---
simple_stmt [80467,80582]
simple_stmt [80518,80633]
===
match
---
name: concurrency [76504,76515]
name: concurrency [76555,76566]
===
match
---
name: dag_id [72174,72180]
name: dag_id [72225,72231]
===
match
---
number: 25 [85156,85158]
number: 25 [85207,85209]
===
match
---
name: dag_id [29053,29059]
name: dag_id [29053,29059]
===
match
---
name: Session [90051,90058]
name: Session [90102,90109]
===
match
---
name: fileloc [89406,89413]
name: fileloc [89457,89464]
===
match
---
simple_stmt [81215,81235]
simple_stmt [81266,81286]
===
match
---
return_stmt [29005,29024]
return_stmt [29005,29024]
===
match
---
name: DagRun [74856,74862]
name: DagRun [74907,74913]
===
match
---
operator: , [52551,52552]
operator: , [52602,52603]
===
match
---
name: utils [2472,2477]
name: utils [2472,2477]
===
match
---
if_stmt [49149,50187]
if_stmt [49149,50238]
===
match
---
operator: , [12862,12863]
operator: , [12862,12863]
===
match
---
operator: = [10562,10563]
operator: = [10562,10563]
===
match
---
simple_stmt [14478,14651]
simple_stmt [14478,14651]
===
match
---
argument [43468,43511]
argument [43468,43511]
===
match
---
name: property [38077,38085]
name: property [38077,38085]
===
match
---
operator: = [66792,66793]
operator: = [66843,66844]
===
match
---
trailer [22021,22063]
trailer [22021,22063]
===
match
---
param [58653,58658]
param [58704,58709]
===
match
---
name: pendulum [22223,22231]
name: pendulum [22223,22231]
===
match
---
name: orm_dag [76153,76160]
name: orm_dag [76204,76211]
===
match
---
simple_stmt [61862,61922]
simple_stmt [61913,61973]
===
match
---
name: self [49193,49197]
name: self [49193,49197]
===
match
---
name: Set [1154,1157]
name: Set [1154,1157]
===
match
---
suite [41404,41528]
suite [41404,41528]
===
match
---
subscriptlist [3139,3154]
subscriptlist [3139,3154]
===
match
---
name: get_task_instances [40730,40748]
name: get_task_instances [40730,40748]
===
match
---
name: task_end_dates [26457,26471]
name: task_end_dates [26457,26471]
===
match
---
operator: { [66140,66141]
operator: { [66191,66192]
===
match
---
for_stmt [16673,17072]
for_stmt [16673,17072]
===
match
---
operator: , [81070,81071]
operator: , [81121,81122]
===
match
---
atom_expr [63058,63068]
atom_expr [63109,63119]
===
match
---
name: Optional [10260,10268]
name: Optional [10260,10268]
===
match
---
name: airflow [2073,2080]
name: airflow [2073,2080]
===
match
---
trailer [64165,64168]
trailer [64216,64219]
===
match
---
trailer [32112,32119]
trailer [32112,32119]
===
match
---
name: schedule_interval [33836,33853]
name: schedule_interval [33836,33853]
===
match
---
atom_expr [41855,41883]
atom_expr [41855,41883]
===
match
---
atom_expr [32967,33148]
atom_expr [32967,33148]
===
match
---
expr_stmt [63803,63828]
expr_stmt [63854,63879]
===
match
---
simple_stmt [76496,76534]
simple_stmt [76547,76585]
===
match
---
if_stmt [51111,54504]
if_stmt [51162,54555]
===
match
---
operator: = [35026,35027]
operator: = [35026,35027]
===
match
---
simple_stmt [64633,64644]
simple_stmt [64684,64695]
===
match
---
suite [63541,63730]
suite [63592,63781]
===
match
---
fstring_start: f' [14807,14809]
fstring_start: f' [14807,14809]
===
match
---
name: self [23034,23038]
name: self [23034,23038]
===
match
---
suite [94544,95792]
suite [94595,95843]
===
match
---
import_from [1510,1545]
import_from [1510,1545]
===
match
---
name: DagRun [75560,75566]
name: DagRun [75611,75617]
===
match
---
annassign [14431,14451]
annassign [14431,14451]
===
match
---
param [55827,55831]
param [55878,55882]
===
match
---
name: max_recursion_depth [54230,54249]
name: max_recursion_depth [54281,54300]
===
match
---
simple_stmt [72737,72748]
simple_stmt [72788,72799]
===
match
---
atom_expr [58157,58168]
atom_expr [58208,58219]
===
match
---
param [11021,11082]
param [11021,11082]
===
match
---
operator: = [27307,27308]
operator: = [27307,27308]
===
match
---
name: self [66745,66749]
name: self [66796,66800]
===
match
---
name: graph_unsorted [44702,44716]
name: graph_unsorted [44702,44716]
===
match
---
operator: , [92105,92106]
operator: , [92156,92157]
===
match
---
operator: = [56550,56551]
operator: = [56601,56602]
===
match
---
trailer [23223,23242]
trailer [23223,23242]
===
match
---
name: folder [31162,31168]
name: folder [31162,31168]
===
match
---
name: DagRun [75155,75161]
name: DagRun [75206,75212]
===
match
---
operator: @ [32147,32148]
operator: @ [32147,32148]
===
match
---
decorator [72770,72787]
decorator [72821,72838]
===
match
---
atom_expr [83654,83694]
atom_expr [83705,83745]
===
match
---
atom_expr [88588,88729]
atom_expr [88639,88780]
===
match
---
atom_expr [61127,61147]
atom_expr [61178,61198]
===
match
---
operator: = [73278,73279]
operator: = [73329,73330]
===
match
---
name: session [1486,1493]
name: session [1486,1493]
===
match
---
trailer [51044,51046]
trailer [51095,51097]
===
match
---
funcdef [31158,31305]
funcdef [31158,31305]
===
match
---
operator: += [39105,39107]
operator: += [39105,39107]
===
match
---
atom_expr [79797,79815]
atom_expr [79848,79866]
===
match
---
name: t [60258,60259]
name: t [60309,60310]
===
match
---
decorated [37815,38071]
decorated [37815,38071]
===
match
---
name: full_filepath [12019,12032]
name: full_filepath [12019,12032]
===
match
---
name: self [33668,33672]
name: self [33668,33672]
===
match
---
simple_stmt [31129,31139]
simple_stmt [31129,31139]
===
match
---
atom_expr [76727,76763]
atom_expr [76778,76814]
===
match
---
atom_expr [12455,12472]
atom_expr [12455,12472]
===
match
---
operator: , [83309,83310]
operator: , [83360,83361]
===
match
---
operator: , [61618,61619]
operator: , [61669,61670]
===
match
---
name: _comps [16687,16693]
name: _comps [16687,16693]
===
match
---
expr_stmt [69826,69852]
expr_stmt [69877,69903]
===
match
---
expr_stmt [50587,50629]
expr_stmt [50638,50680]
===
match
---
operator: , [58789,58790]
operator: , [58840,58841]
===
match
---
param [33237,33241]
param [33237,33241]
===
match
---
trailer [75319,75675]
trailer [75370,75726]
===
match
---
name: tasks [38769,38774]
name: tasks [38769,38774]
===
match
---
subscriptlist [15433,15461]
subscriptlist [15433,15461]
===
match
---
atom_expr [65654,65667]
atom_expr [65705,65718]
===
match
---
name: query [80481,80486]
name: query [80532,80537]
===
match
---
simple_stmt [57507,57517]
simple_stmt [57558,57568]
===
match
---
decorated [28958,29025]
decorated [28958,29025]
===
match
---
trailer [80669,80673]
trailer [80720,80724]
===
match
---
name: str [9909,9912]
name: str [9909,9912]
===
match
---
name: dag [72573,72576]
name: dag [72624,72627]
===
match
---
decorated [32147,32546]
decorated [32147,32546]
===
match
---
name: __name__ [2911,2919]
name: __name__ [2911,2919]
===
match
---
operator: @ [30696,30697]
operator: @ [30696,30697]
===
match
---
trailer [48891,48905]
trailer [48891,48905]
===
match
---
trailer [77465,77500]
trailer [77516,77551]
===
match
---
name: self [45596,45600]
name: self [45596,45600]
===
match
---
trailer [78204,78217]
trailer [78255,78268]
===
match
---
fstring_start: f" [53072,53074]
fstring_start: f" [53123,53125]
===
match
---
not_test [89755,89778]
not_test [89806,89829]
===
match
---
name: dag_bound_args [93296,93310]
name: dag_bound_args [93347,93361]
===
match
---
trailer [83660,83694]
trailer [83711,83745]
===
match
---
operator: = [54811,54812]
operator: = [54862,54863]
===
match
---
simple_stmt [19227,19248]
simple_stmt [19227,19248]
===
match
---
atom_expr [11937,11957]
atom_expr [11937,11957]
===
match
---
name: execution_date [45836,45850]
name: execution_date [45836,45850]
===
match
---
name: self [21434,21438]
name: self [21434,21438]
===
match
---
expr_stmt [19227,19247]
expr_stmt [19227,19247]
===
match
---
trailer [64613,64619]
trailer [64664,64670]
===
match
---
trailer [38985,38995]
trailer [38985,38995]
===
match
---
name: dry_run [56087,56094]
name: dry_run [56138,56145]
===
match
---
name: DagModel [32727,32735]
name: DagModel [32727,32735]
===
match
---
atom_expr [36452,36509]
atom_expr [36452,36509]
===
match
---
trailer [75631,75646]
trailer [75682,75697]
===
match
---
name: self [64816,64820]
name: self [64867,64871]
===
match
---
trailer [76747,76751]
trailer [76798,76802]
===
match
---
name: owners [84986,84992]
name: owners [85037,85043]
===
match
---
atom [22621,22709]
atom [22621,22709]
===
match
---
operator: , [83903,83904]
operator: , [83954,83955]
===
match
---
name: access_control [17842,17856]
name: access_control [17842,17856]
===
match
---
operator: , [28561,28562]
operator: , [28561,28562]
===
match
---
suite [93632,93680]
suite [93683,93731]
===
match
---
not_test [28260,28273]
not_test [28260,28273]
===
match
---
trailer [89960,89969]
trailer [90011,90020]
===
match
---
name: fn [30996,30998]
name: fn [30996,30998]
===
match
---
operator: { [74145,74146]
operator: { [74196,74197]
===
match
---
name: timezone [20730,20738]
name: timezone [20730,20738]
===
match
---
trailer [58233,58238]
trailer [58284,58289]
===
match
---
operator: , [36586,36587]
operator: , [36586,36587]
===
match
---
name: timezone [21232,21240]
name: timezone [21232,21240]
===
match
---
string: 'landing_times' [3040,3055]
string: 'landing_times' [3040,3055]
===
match
---
name: task_ids [50619,50627]
name: task_ids [50670,50678]
===
match
---
suite [25408,25489]
suite [25408,25489]
===
match
---
name: default_args [13131,13143]
name: default_args [13131,13143]
===
match
---
param [46094,46113]
param [46094,46113]
===
match
---
name: catchup [24250,24257]
name: catchup [24250,24257]
===
match
---
trailer [86726,86748]
trailer [86777,86799]
===
match
---
string: 'end_date' [13087,13097]
string: 'end_date' [13087,13097]
===
match
---
simple_stmt [92615,92649]
simple_stmt [92666,92700]
===
match
---
expr_stmt [3057,3103]
expr_stmt [3057,3103]
===
match
---
operator: , [1351,1352]
operator: , [1351,1352]
===
match
---
trailer [12070,12083]
trailer [12070,12083]
===
match
---
operator: = [45416,45417]
operator: = [45416,45417]
===
match
---
operator: , [75037,75038]
operator: , [75088,75089]
===
match
---
name: new_start [24951,24960]
name: new_start [24951,24960]
===
match
---
subscriptlist [12365,12382]
subscriptlist [12365,12382]
===
match
---
atom_expr [91123,91140]
atom_expr [91174,91191]
===
match
---
simple_stmt [44742,44748]
simple_stmt [44742,44748]
===
match
---
operator: = [15655,15656]
operator: = [15655,15656]
===
match
---
name: orm [1421,1424]
name: orm [1421,1424]
===
match
---
decorator [40705,40722]
decorator [40705,40722]
===
match
---
trailer [50529,50535]
trailer [50580,50586]
===
match
---
name: following [20640,20649]
name: following [20640,20649]
===
match
---
name: dag_id [11982,11988]
name: dag_id [11982,11988]
===
match
---
name: filter [80831,80837]
name: filter [80882,80888]
===
match
---
simple_stmt [57789,57813]
simple_stmt [57840,57864]
===
match
---
name: subdag [39113,39119]
name: subdag [39113,39119]
===
match
---
operator: = [40765,40766]
operator: = [40765,40766]
===
match
---
operator: = [76516,76517]
operator: = [76567,76568]
===
match
---
string: "@once" [22661,22668]
string: "@once" [22661,22668]
===
match
---
funcdef [29602,29714]
funcdef [29602,29714]
===
match
---
name: List [18797,18801]
name: List [18797,18801]
===
match
---
trailer [70039,70044]
trailer [70090,70095]
===
match
---
name: query [3648,3653]
name: query [3648,3653]
===
match
---
string: "The 'can_dag_read' and 'can_dag_edit' permissions are deprecated. " [18371,18439]
string: "The 'can_dag_read' and 'can_dag_edit' permissions are deprecated. " [18371,18439]
===
match
---
name: parent_dag [49247,49257]
name: parent_dag [49298,49308]
===
match
---
string: '.' [14193,14196]
string: '.' [14193,14196]
===
match
---
operator: = [14284,14285]
operator: = [14284,14285]
===
match
---
name: values [61238,61244]
name: values [61289,61295]
===
match
---
atom_expr [93476,93495]
atom_expr [93527,93546]
===
match
---
name: self [24995,24999]
name: self [24995,24999]
===
match
---
import_from [2769,2806]
import_from [2769,2806]
===
match
---
testlist_comp [23010,23020]
testlist_comp [23010,23020]
===
match
---
name: subdag [45080,45086]
name: subdag [45080,45086]
===
match
---
simple_stmt [80821,80868]
simple_stmt [80872,80919]
===
match
---
atom_expr [49458,50186]
atom_expr [49509,50237]
===
match
---
operator: = [78442,78443]
operator: = [78493,78494]
===
match
---
name: dag [63281,63284]
name: dag [63332,63335]
===
match
---
param [86671,86683]
param [86722,86734]
===
match
---
name: new_start [24727,24736]
name: new_start [24727,24736]
===
match
---
simple_stmt [33878,33904]
simple_stmt [33878,33904]
===
match
---
name: self [13675,13679]
name: self [13675,13679]
===
match
---
string: 'params' [11918,11926]
string: 'params' [11918,11926]
===
match
---
import_from [1313,1404]
import_from [1313,1404]
===
match
---
name: task_id [66238,66245]
name: task_id [66289,66296]
===
match
---
operator: * [92147,92148]
operator: * [92198,92199]
===
match
---
name: DagRunType [71663,71673]
name: DagRunType [71714,71724]
===
match
---
suite [52823,52897]
suite [52874,52948]
===
match
---
name: copy [59867,59871]
name: copy [59918,59922]
===
match
---
string: """         Returns the dag run for a given execution date if it exists, otherwise         none.          :param execution_date: The execution date of the DagRun to find.         :param session:         :return: The DagRun if found, otherwise None.         """ [36627,36887]
string: """         Returns the dag run for a given execution date if it exists, otherwise         none.          :param execution_date: The execution date of the DagRun to find.         :param session:         :return: The DagRun if found, otherwise None.         """ [36627,36887]
===
match
---
name: self [25437,25441]
name: self [25437,25441]
===
match
---
name: dag_obj [93525,93532]
name: dag_obj [93576,93583]
===
match
---
name: self [21932,21936]
name: self [21932,21936]
===
match
---
argument [13278,13300]
argument [13278,13300]
===
match
---
name: property [42559,42567]
name: property [42559,42567]
===
match
---
operator: , [54046,54047]
operator: , [54097,54098]
===
match
---
comparison [80734,80748]
comparison [80785,80799]
===
match
---
atom_expr [13115,13161]
atom_expr [13115,13161]
===
match
---
name: nullable [85375,85383]
name: nullable [85426,85434]
===
match
---
trailer [74862,74877]
trailer [74913,74928]
===
match
---
name: Union [58686,58691]
name: Union [58737,58742]
===
match
---
decorated [69888,72748]
decorated [69939,72799]
===
match
---
name: default_args [11810,11822]
name: default_args [11810,11822]
===
match
---
operator: = [28189,28190]
operator: = [28189,28190]
===
match
---
suite [45030,45132]
suite [45030,45132]
===
match
---
arglist [31028,31058]
arglist [31028,31058]
===
match
---
arglist [73947,73977]
arglist [73998,74028]
===
match
---
name: end_date [65702,65710]
name: end_date [65753,65761]
===
match
---
sync_comp_for [16423,16443]
sync_comp_for [16423,16443]
===
match
---
name: key [51079,51082]
name: key [51130,51133]
===
match
---
name: dttm [63724,63728]
name: dttm [63775,63779]
===
match
---
fstring_expr [14589,14611]
fstring_expr [14589,14611]
===
match
---
operator: , [72392,72393]
operator: , [72443,72444]
===
match
---
operator: @ [78352,78353]
operator: @ [78403,78404]
===
match
---
funcdef [88104,88755]
funcdef [88155,88806]
===
match
---
atom_expr [51433,51443]
atom_expr [51484,51494]
===
match
---
name: type [71880,71884]
name: type [71931,71935]
===
match
---
name: full_filepath [31290,31303]
name: full_filepath [31290,31303]
===
match
---
trailer [36269,36275]
trailer [36269,36275]
===
match
---
string: '__dot__' [88067,88076]
string: '__dot__' [88118,88127]
===
match
---
name: conf [66892,66896]
name: conf [66943,66947]
===
match
---
operator: , [75451,75452]
operator: , [75502,75503]
===
match
---
name: end_date [45479,45487]
name: end_date [45479,45487]
===
match
---
trailer [43649,43663]
trailer [43649,43663]
===
match
---
name: scheduler_lock [84579,84593]
name: scheduler_lock [84630,84644]
===
match
---
name: all [42292,42295]
name: all [42292,42295]
===
match
---
param [32185,32189]
param [32185,32189]
===
match
---
name: keys [73853,73857]
name: keys [73904,73908]
===
match
---
fstring_expr [56926,56933]
fstring_expr [56977,56984]
===
match
---
operator: = [10959,10960]
operator: = [10959,10960]
===
match
---
expr_stmt [94466,94524]
expr_stmt [94517,94575]
===
match
---
trailer [85989,85991]
trailer [86040,86042]
===
match
---
name: relationship [94492,94504]
name: relationship [94543,94555]
===
match
---
operator: = [15119,15120]
operator: = [15119,15120]
===
match
---
funcdef [28674,28953]
funcdef [28674,28953]
===
match
---
name: models [1997,2003]
name: models [1997,2003]
===
match
---
name: copied [61379,61385]
name: copied [61430,61436]
===
match
---
arglist [12630,12666]
arglist [12630,12666]
===
match
---
parameters [72810,72854]
parameters [72861,72905]
===
match
---
operator: = [10815,10816]
operator: = [10815,10816]
===
match
---
name: self [63288,63292]
name: self [63339,63343]
===
match
---
operator: = [55621,55622]
operator: = [55672,55673]
===
match
---
if_stmt [24237,25023]
if_stmt [24237,25023]
===
match
---
name: recursion_depth [51835,51850]
name: recursion_depth [51886,51901]
===
match
---
name: orm_dag [76918,76925]
name: orm_dag [76969,76976]
===
match
---
suite [18177,18274]
suite [18177,18274]
===
match
---
argument [33125,33137]
argument [33125,33137]
===
match
---
trailer [45103,45130]
trailer [45103,45130]
===
match
---
suite [50993,51047]
suite [51044,51098]
===
match
---
decorated [17448,18630]
decorated [17448,18630]
===
match
---
decorator [38076,38086]
decorator [38076,38086]
===
match
---
trailer [35763,35783]
trailer [35763,35783]
===
match
---
simple_stmt [64391,64414]
simple_stmt [64442,64465]
===
match
---
atom_expr [56173,56570]
atom_expr [56224,56621]
===
match
---
name: tags [74536,74540]
name: tags [74587,74591]
===
match
---
simple_stmt [93359,93403]
simple_stmt [93410,93454]
===
match
---
operator: = [55913,55914]
operator: = [55964,55965]
===
match
---
trailer [64295,64299]
trailer [64346,64350]
===
match
---
operator: = [87544,87545]
operator: = [87595,87596]
===
match
---
trailer [24265,24283]
trailer [24265,24283]
===
match
---
name: croniter [19263,19271]
name: croniter [19263,19271]
===
match
---
name: DagRun [74917,74923]
name: DagRun [74968,74974]
===
match
---
trailer [13692,13704]
trailer [13692,13704]
===
match
---
simple_stmt [74048,74117]
simple_stmt [74099,74168]
===
match
---
name: property [29720,29728]
name: property [29720,29728]
===
match
---
name: start_date [18673,18683]
name: start_date [18673,18683]
===
match
---
param [58667,58725]
param [58718,58776]
===
match
---
name: timezone [20523,20531]
name: timezone [20523,20531]
===
match
---
string: 'start_date' [12703,12715]
string: 'start_date' [12703,12715]
===
match
---
atom_expr [31523,31563]
atom_expr [31523,31563]
===
match
---
trailer [38768,38774]
trailer [38768,38774]
===
match
---
name: schedule_interval [85189,85206]
name: schedule_interval [85240,85257]
===
match
---
operator: , [50153,50154]
operator: , [50204,50205]
===
match
---
or_test [65938,66088]
or_test [65989,66139]
===
match
---
trailer [66462,66478]
trailer [66513,66529]
===
match
---
parameters [20822,20834]
parameters [20822,20834]
===
match
---
name: debug [63782,63787]
name: debug [63833,63838]
===
match
---
suite [56108,57591]
suite [56159,57642]
===
match
---
atom_expr [75969,75990]
atom_expr [76020,76041]
===
match
---
trailer [50428,50435]
trailer [50479,50486]
===
match
---
atom_expr [65535,65550]
atom_expr [65586,65601]
===
match
---
expr_stmt [65513,65568]
expr_stmt [65564,65619]
===
match
---
operator: , [46343,46344]
operator: , [46343,46344]
===
match
---
trailer [49496,50172]
trailer [49547,50223]
===
match
---
testlist_comp [56845,56868]
testlist_comp [56896,56919]
===
match
---
name: external_trigger [35869,35885]
name: external_trigger [35869,35885]
===
match
---
name: c [16414,16415]
name: c [16414,16415]
===
match
---
atom_expr [38032,38045]
atom_expr [38032,38045]
===
match
---
trailer [50603,50629]
trailer [50654,50680]
===
match
---
operator: = [11145,11146]
operator: = [11145,11146]
===
match
---
name: self [12344,12348]
name: self [12344,12348]
===
match
---
name: dag_ids [48630,48637]
name: dag_ids [48630,48637]
===
match
---
name: DagRunType [2617,2627]
name: DagRunType [2617,2627]
===
match
---
operator: , [3008,3009]
operator: , [3008,3009]
===
match
---
comparison [88543,88578]
comparison [88594,88629]
===
match
---
name: models [1909,1915]
name: models [1909,1915]
===
match
---
name: task_id [61329,61336]
name: task_id [61380,61387]
===
match
---
expr_stmt [17890,18090]
expr_stmt [17890,18090]
===
match
---
return_stmt [37072,37085]
return_stmt [37072,37085]
===
match
---
expr_stmt [66218,66253]
expr_stmt [66269,66304]
===
match
---
atom_expr [87078,87087]
atom_expr [87129,87138]
===
match
---
trailer [36355,36361]
trailer [36355,36361]
===
match
---
decorator [81240,81253]
decorator [81291,81304]
===
match
---
trailer [66128,66191]
trailer [66179,66242]
===
match
---
param [45479,45515]
param [45479,45515]
===
match
---
operator: , [69475,69476]
operator: , [69526,69527]
===
match
---
name: backref [85324,85331]
name: backref [85375,85382]
===
match
---
trailer [77660,77666]
trailer [77711,77717]
===
match
---
expr_stmt [71653,71706]
expr_stmt [71704,71757]
===
match
---
fstring_string: \n\nAre you sure? (yes/no):  [56951,56979]
fstring_string: \n\nAre you sure? (yes/no):  [57002,57030]
===
match
---
trailer [42009,42016]
trailer [42009,42016]
===
match
---
operator: , [65550,65551]
operator: , [65601,65602]
===
match
---
decorated [30696,30786]
decorated [30696,30786]
===
match
---
name: get [76797,76800]
name: get [76848,76851]
===
match
---
trailer [74114,74116]
trailer [74165,74167]
===
match
---
operator: - [21636,21637]
operator: - [21636,21637]
===
match
---
arglist [49283,49424]
arglist [49334,49475]
===
match
---
name: tis [54544,54547]
name: tis [54595,54598]
===
match
---
name: dttm [28215,28219]
name: dttm [28215,28219]
===
match
---
expr_stmt [59747,59776]
expr_stmt [59798,59827]
===
match
---
trailer [76358,76371]
trailer [76409,76422]
===
match
---
operator: , [33137,33138]
operator: , [33137,33138]
===
match
---
name: self [29012,29016]
name: self [29012,29016]
===
match
---
name: self [64911,64915]
name: self [64962,64966]
===
match
---
name: state [45363,45368]
name: state [45363,45368]
===
match
---
name: FAILED [50429,50435]
name: FAILED [50480,50486]
===
match
---
string: 'last_loaded' [81611,81624]
string: 'last_loaded' [81662,81675]
===
match
---
trailer [59982,60021]
trailer [60033,60072]
===
match
---
tfpdef [82403,82426]
tfpdef [82454,82477]
===
match
---
name: convert_to_utc [13716,13730]
name: convert_to_utc [13716,13730]
===
match
---
param [57619,57623]
param [57670,57674]
===
match
---
trailer [31535,31541]
trailer [31535,31541]
===
match
---
name: has_task_concurrency_limits [85396,85423]
name: has_task_concurrency_limits [85447,85474]
===
match
---
trailer [20574,20585]
trailer [20574,20585]
===
match
---
name: end_date [55542,55550]
name: end_date [55593,55601]
===
match
---
string: """         Ensure the DagModel rows for the given dags are up-to-date in the dag table in the DB, including         calculated fields.          Note that this method can be called for both DAGs and SubDAGs. A SubDag is actually a SubDagOperator.          :param dags: the DAG objects to save to the DB         :type dags: List[airflow.models.dag.DAG]         :return: None         """ [73294,73679]
string: """         Ensure the DagModel rows for the given dags are up-to-date in the dag table in the DB, including         calculated fields.          Note that this method can be called for both DAGs and SubDAGs. A SubDag is actually a SubDagOperator.          :param dags: the DAG objects to save to the DB         :type dags: List[airflow.models.dag.DAG]         :return: None         """ [73345,73730]
===
match
---
name: List [42592,42596]
name: List [42592,42596]
===
match
---
decorated [28408,28648]
decorated [28408,28648]
===
match
---
operator: = [11980,11981]
operator: = [11980,11981]
===
match
---
if_stmt [26191,26285]
if_stmt [26191,26285]
===
match
---
operator: = [10133,10134]
operator: = [10133,10134]
===
match
---
name: _full_filepath [29286,29300]
name: _full_filepath [29286,29300]
===
match
---
trailer [15965,15990]
trailer [15965,15990]
===
match
---
arglist [10977,11010]
arglist [10977,11010]
===
match
---
trailer [63227,63236]
trailer [63278,63287]
===
match
---
name: Context [2024,2031]
name: Context [2024,2031]
===
match
---
name: concurrency [32130,32141]
name: concurrency [32130,32141]
===
match
---
atom_expr [13406,13439]
atom_expr [13406,13439]
===
match
---
suite [49221,50187]
suite [49221,50238]
===
match
---
trailer [13429,13439]
trailer [13429,13439]
===
match
---
operator: = [66840,66841]
operator: = [66891,66892]
===
match
---
operator: = [83268,83269]
operator: = [83319,83320]
===
match
---
atom [39623,39817]
atom [39623,39817]
===
match
---
if_stmt [45783,45864]
if_stmt [45783,45864]
===
match
---
operator: { [63431,63432]
operator: { [63482,63483]
===
match
---
name: back [12243,12247]
name: back [12243,12247]
===
match
---
name: DAG [15832,15835]
name: DAG [15832,15835]
===
match
---
operator: = [55550,55551]
operator: = [55601,55602]
===
match
---
decorators [78352,78387]
decorators [78403,78438]
===
match
---
string: 'scheduler' [85881,85892]
string: 'scheduler' [85932,85943]
===
match
---
tfpdef [70304,70334]
tfpdef [70355,70385]
===
match
---
simple_stmt [78322,78347]
simple_stmt [78373,78398]
===
match
---
argument [57399,57426]
argument [57450,57477]
===
match
---
name: globals [94310,94317]
name: globals [94361,94368]
===
match
---
trailer [20459,20468]
trailer [20459,20468]
===
match
---
name: result [57806,57812]
name: result [57857,57863]
===
match
---
operator: , [28845,28846]
operator: , [28845,28846]
===
match
---
parameters [30905,30911]
parameters [30905,30911]
===
match
---
string: 'donot_pickle' [66916,66930]
string: 'donot_pickle' [66967,66981]
===
match
---
name: cron_next [19409,19418]
name: cron_next [19409,19418]
===
match
---
trailer [38454,38480]
trailer [38454,38480]
===
match
---
operator: , [76815,76816]
operator: , [76866,76867]
===
match
---
decorated [45942,55781]
decorated [45942,55832]
===
match
---
name: logging [2893,2900]
name: logging [2893,2900]
===
match
---
param [69972,70014]
param [70023,70065]
===
match
---
if_stmt [18283,18591]
if_stmt [18283,18591]
===
match
---
trailer [80850,80856]
trailer [80901,80907]
===
match
---
funcdef [30710,30786]
funcdef [30710,30786]
===
match
---
param [70023,70052]
param [70074,70103]
===
match
---
funcdef [23270,26726]
funcdef [23270,26726]
===
match
---
expr_stmt [62042,62099]
expr_stmt [62093,62150]
===
match
---
return_stmt [88035,88077]
return_stmt [88086,88128]
===
match
---
import_from [2305,2351]
import_from [2305,2351]
===
match
---
param [31763,31768]
param [31763,31768]
===
match
---
operator: , [1632,1633]
operator: , [1632,1633]
===
match
---
decorated [89995,91030]
decorated [90046,91081]
===
match
---
operator: , [36602,36603]
operator: , [36602,36603]
===
match
---
name: task [42533,42537]
name: task [42533,42537]
===
match
---
name: start_date [55503,55513]
name: start_date [55554,55564]
===
match
---
name: self [25642,25646]
name: self [25642,25646]
===
match
---
expr_stmt [92016,92052]
expr_stmt [92067,92103]
===
match
---
name: self [33758,33762]
name: self [33758,33762]
===
match
---
name: self [26246,26250]
name: self [26246,26250]
===
match
---
operator: , [82296,82297]
operator: , [82347,82348]
===
match
---
name: is_paused [74476,74485]
name: is_paused [74527,74536]
===
match
---
operator: , [32430,32431]
operator: , [32430,32431]
===
match
---
atom_expr [55232,55415]
atom_expr [55283,55466]
===
match
---
argument [64262,64270]
argument [64313,64321]
===
match
---
name: cls [73141,73144]
name: cls [73192,73195]
===
match
---
name: timezone [12915,12923]
name: timezone [12915,12923]
===
match
---
operator: , [46248,46249]
operator: , [46248,46249]
===
match
---
name: child [61395,61400]
name: child [61446,61451]
===
match
---
trailer [62524,62537]
trailer [62575,62588]
===
match
---
name: is_paused [88128,88137]
name: is_paused [88179,88188]
===
match
---
name: param [30087,30092]
name: param [30087,30092]
===
match
---
name: task [43483,43487]
name: task [43483,43487]
===
match
---
name: subdags [38506,38513]
name: subdags [38506,38513]
===
match
---
operator: , [80570,80571]
operator: , [80621,80622]
===
match
---
name: get_prev [21730,21738]
name: get_prev [21730,21738]
===
match
---
simple_stmt [23369,23926]
simple_stmt [23369,23926]
===
match
---
name: dag [79675,79678]
name: dag [79726,79729]
===
match
---
trailer [62937,62945]
trailer [62988,62996]
===
match
---
trailer [88601,88611]
trailer [88652,88662]
===
match
---
tfpdef [29066,29076]
tfpdef [29066,29076]
===
match
---
name: isinstance [71531,71541]
name: isinstance [71582,71592]
===
match
---
trailer [90768,90793]
trailer [90819,90844]
===
match
---
name: append [17054,17060]
name: append [17054,17060]
===
match
---
arglist [75416,75595]
arglist [75467,75646]
===
match
---
fstring_expr [71624,71638]
fstring_expr [71675,71689]
===
match
---
trailer [92634,92648]
trailer [92685,92699]
===
match
---
operator: = [18862,18863]
operator: = [18862,18863]
===
match
---
trailer [15630,15654]
trailer [15630,15654]
===
match
---
trailer [64669,64685]
trailer [64720,64736]
===
match
---
trailer [10575,10602]
trailer [10575,10602]
===
match
---
name: query [36452,36457]
name: query [36452,36457]
===
match
---
name: context [35132,35139]
name: context [35132,35139]
===
match
---
atom_expr [10469,10483]
atom_expr [10469,10483]
===
match
---
simple_stmt [62042,62100]
simple_stmt [62093,62151]
===
match
---
operator: , [32594,32595]
operator: , [32594,32595]
===
match
---
name: timezone [18769,18777]
name: timezone [18769,18777]
===
match
---
name: self [45240,45244]
name: self [45240,45244]
===
match
---
name: run_type [75002,75010]
name: run_type [75053,75061]
===
match
---
name: delta [21638,21643]
name: delta [21638,21643]
===
match
---
name: Optional [22141,22149]
name: Optional [22141,22149]
===
match
---
simple_stmt [15065,15086]
simple_stmt [15065,15086]
===
match
---
name: provide_session [69889,69904]
name: provide_session [69940,69955]
===
match
---
atom [77078,77108]
atom [77129,77159]
===
match
---
simple_stmt [41014,41240]
simple_stmt [41014,41240]
===
match
---
name: self [17300,17304]
name: self [17300,17304]
===
match
---
simple_stmt [74309,74351]
simple_stmt [74360,74402]
===
match
---
simple_stmt [26578,26618]
simple_stmt [26578,26618]
===
match
---
operator: & [48875,48876]
operator: & [48875,48876]
===
match
---
string: 'core' [86091,86097]
string: 'core' [86142,86148]
===
match
---
name: next_run_date [28000,28013]
name: next_run_date [28000,28013]
===
match
---
name: provide_session [86458,86473]
name: provide_session [86509,86524]
===
match
---
trailer [48611,48617]
trailer [48611,48617]
===
match
---
atom_expr [33246,33272]
atom_expr [33246,33272]
===
match
---
name: OrderedDict [934,945]
name: OrderedDict [934,945]
===
match
---
trailer [61526,61534]
trailer [61577,61585]
===
match
---
operator: += [39512,39514]
operator: += [39512,39514]
===
match
---
operator: , [22103,22104]
operator: , [22103,22104]
===
match
---
dictorsetmaker [60754,60865]
dictorsetmaker [60805,60916]
===
match
---
trailer [58111,58132]
trailer [58162,58183]
===
match
---
simple_stmt [92062,92137]
simple_stmt [92113,92188]
===
match
---
name: question [56883,56891]
name: question [56934,56942]
===
match
---
trailer [3711,3713]
trailer [3711,3713]
===
match
---
name: only_failed [56286,56297]
name: only_failed [56337,56348]
===
match
---
trailer [45653,45681]
trailer [45653,45681]
===
match
---
atom_expr [18190,18218]
atom_expr [18190,18218]
===
match
---
trailer [24060,24078]
trailer [24060,24078]
===
match
---
simple_stmt [34792,34869]
simple_stmt [34792,34869]
===
match
---
param [30820,30824]
param [30820,30824]
===
match
---
operator: , [11388,11389]
operator: , [11388,11389]
===
match
---
name: task_dict [59729,59738]
name: task_dict [59780,59789]
===
match
---
name: start_date [18914,18924]
name: start_date [18914,18924]
===
match
---
name: getint [10640,10646]
name: getint [10640,10646]
===
match
---
atom_expr [28310,28343]
atom_expr [28310,28343]
===
match
---
if_stmt [40184,40270]
if_stmt [40184,40270]
===
match
---
name: count [57585,57590]
name: count [57636,57641]
===
match
---
atom_expr [89450,89489]
atom_expr [89501,89540]
===
match
---
param [16619,16623]
param [16619,16623]
===
match
---
name: next_run_date [25626,25639]
name: next_run_date [25626,25639]
===
match
---
name: _pickle_id [29967,29977]
name: _pickle_id [29967,29977]
===
match
---
funcdef [63075,63453]
funcdef [63126,63504]
===
match
---
name: dp [64216,64218]
name: dp [64267,64269]
===
match
---
trailer [42253,42262]
trailer [42253,42262]
===
match
---
trailer [13986,14005]
trailer [13986,14005]
===
match
---
name: provide_session [31715,31730]
name: provide_session [31715,31730]
===
match
---
sync_comp_for [31542,31561]
sync_comp_for [31542,31561]
===
match
---
name: start_date [37142,37152]
name: start_date [37142,37152]
===
match
---
param [16488,16493]
param [16488,16493]
===
match
---
operator: { [18221,18222]
operator: { [18221,18222]
===
match
---
fstring_string:  tasks:\n [56933,56942]
fstring_string:  tasks:\n [56984,56993]
===
match
---
simple_stmt [29781,29806]
simple_stmt [29781,29806]
===
match
---
string: 'scheduler' [10977,10988]
string: 'scheduler' [10977,10988]
===
match
---
atom_expr [53527,53545]
atom_expr [53578,53596]
===
match
---
name: task_dict [65973,65982]
name: task_dict [66024,66033]
===
match
---
name: tis [49458,49461]
name: tis [49509,49512]
===
match
---
trailer [74625,74629]
trailer [74676,74680]
===
match
---
and_test [44972,45029]
and_test [44972,45029]
===
match
---
param [46214,46249]
param [46214,46249]
===
match
---
arglist [31084,31119]
arglist [31084,31119]
===
match
---
name: children [61386,61394]
name: children [61437,61445]
===
match
---
arglist [57130,57462]
arglist [57181,57513]
===
match
---
string: 'dag_default_view' [10839,10857]
string: 'dag_default_view' [10839,10857]
===
match
---
name: edge_info [83085,83094]
name: edge_info [83136,83145]
===
match
---
name: RUNNING [32075,32082]
name: RUNNING [32075,32082]
===
match
---
operator: } [82753,82754]
operator: } [82804,82805]
===
match
---
atom_expr [57764,57780]
atom_expr [57815,57831]
===
match
---
string: 'user_defined_macros' [57881,57902]
string: 'user_defined_macros' [57932,57953]
===
match
---
atom_expr [76384,76403]
atom_expr [76435,76454]
===
match
---
atom_expr [65089,65104]
atom_expr [65140,65155]
===
match
---
simple_stmt [85841,85941]
simple_stmt [85892,85992]
===
match
---
operator: , [45514,45515]
operator: , [45514,45515]
===
match
---
name: query [73869,73874]
name: query [73920,73925]
===
match
---
name: func [1395,1399]
name: func [1395,1399]
===
match
---
name: previous_schedule [28315,28332]
name: previous_schedule [28315,28332]
===
match
---
name: args [58604,58608]
name: args [58655,58659]
===
match
---
name: task_dict [62441,62450]
name: task_dict [62492,62501]
===
match
---
name: task [65681,65685]
name: task [65732,65736]
===
match
---
name: parse [52676,52681]
name: parse [52727,52732]
===
match
---
atom_expr [62854,62874]
atom_expr [62905,62925]
===
match
---
operator: = [40864,40865]
operator: = [40864,40865]
===
match
---
atom_expr [43469,43481]
atom_expr [43469,43481]
===
match
---
name: d [63897,63898]
name: d [63948,63949]
===
match
---
comparison [80541,80570]
comparison [80592,80621]
===
match
---
trailer [21843,21854]
trailer [21843,21854]
===
match
---
name: session [73891,73898]
name: session [73942,73949]
===
match
---
operator: = [59758,59759]
operator: = [59809,59810]
===
match
---
name: self [15733,15737]
name: self [15733,15737]
===
match
---
name: orm_dags [74048,74056]
name: orm_dags [74099,74107]
===
match
---
trailer [42519,42525]
trailer [42519,42525]
===
match
---
atom_expr [24546,24574]
atom_expr [24546,24574]
===
match
---
name: self [29436,29440]
name: self [29436,29440]
===
match
---
name: TaskInstance [80649,80661]
name: TaskInstance [80700,80712]
===
match
---
trailer [76804,76811]
trailer [76855,76862]
===
match
---
trailer [39112,39119]
trailer [39112,39119]
===
match
---
name: only_running [55929,55941]
name: only_running [55980,55992]
===
match
---
trailer [11562,11583]
trailer [11562,11583]
===
match
---
trailer [37615,37622]
trailer [37615,37622]
===
match
---
trailer [65517,65528]
trailer [65568,65579]
===
match
---
name: graph_unsorted [44589,44603]
name: graph_unsorted [44589,44603]
===
match
---
operator: , [46057,46058]
operator: , [46057,46058]
===
match
---
trailer [18019,18050]
trailer [18019,18050]
===
match
---
name: f_sig [93198,93203]
name: f_sig [93249,93254]
===
match
---
operator: , [67081,67082]
operator: , [67132,67133]
===
match
---
name: filter [86720,86726]
name: filter [86771,86777]
===
match
---
name: conf [10635,10639]
name: conf [10635,10639]
===
match
---
atom_expr [45625,45681]
atom_expr [45625,45681]
===
match
---
operator: = [76460,76461]
operator: = [76511,76512]
===
match
---
trailer [30529,30554]
trailer [30529,30554]
===
match
---
atom_expr [45376,45389]
atom_expr [45376,45389]
===
match
---
name: description [9984,9995]
name: description [9984,9995]
===
match
---
name: task_ids [80674,80682]
name: task_ids [80725,80733]
===
match
---
trailer [69646,69648]
trailer [69697,69699]
===
match
---
name: self [66382,66386]
name: self [66433,66437]
===
match
---
except_clause [2823,2841]
except_clause [2823,2841]
===
match
---
simple_stmt [36627,36888]
simple_stmt [36627,36888]
===
match
---
trailer [22202,22211]
trailer [22202,22211]
===
match
---
name: end_date [26251,26259]
name: end_date [26251,26259]
===
match
---
name: provide_session [36547,36562]
name: provide_session [36547,36562]
===
match
---
simple_stmt [26705,26726]
simple_stmt [26705,26726]
===
match
---
for_stmt [35715,35784]
for_stmt [35715,35784]
===
match
---
atom_expr [20455,20478]
atom_expr [20455,20478]
===
match
---
name: setter [30567,30573]
name: setter [30567,30573]
===
match
---
name: orm_dag [74667,74674]
name: orm_dag [74718,74725]
===
match
---
name: dag [77145,77148]
name: dag [77196,77199]
===
match
---
name: self [12066,12070]
name: self [12066,12070]
===
match
---
trailer [75024,75037]
trailer [75075,75088]
===
match
---
trailer [58587,58602]
trailer [58638,58653]
===
match
---
atom_expr [64015,64030]
atom_expr [64066,64081]
===
match
---
expr_stmt [14114,14150]
expr_stmt [14114,14150]
===
match
---
atom_expr [31678,31700]
atom_expr [31678,31700]
===
match
---
name: instances [50823,50832]
name: instances [50874,50883]
===
match
---
trailer [11215,11221]
trailer [11215,11221]
===
match
---
name: downstream_task_id [82872,82890]
name: downstream_task_id [82923,82941]
===
match
---
string: """         Return list of all owners found in DAG tasks.          :return: Comma separated list of owners in DAG tasks         :rtype: str         """ [31356,31507]
string: """         Return list of all owners found in DAG tasks.          :return: Comma separated list of owners in DAG tasks         :rtype: str         """ [31356,31507]
===
match
---
name: tis [49023,49026]
name: tis [49023,49026]
===
match
---
name: dag_id [52960,52966]
name: dag_id [53011,53017]
===
match
---
suite [16694,17072]
suite [16694,17072]
===
match
---
atom_expr [37550,37775]
atom_expr [37550,37775]
===
match
---
trailer [79414,79420]
trailer [79465,79471]
===
match
---
name: self [63088,63092]
name: self [63139,63143]
===
match
---
name: path [31272,31276]
name: path [31272,31276]
===
match
---
atom [48849,48874]
atom [48849,48874]
===
match
---
name: parse [13220,13225]
name: parse [13220,13225]
===
match
---
atom_expr [30054,30069]
atom_expr [30054,30069]
===
match
---
fstring_end: ' [14569,14570]
fstring_end: ' [14569,14570]
===
match
---
name: verbose [69489,69496]
name: verbose [69540,69547]
===
match
---
atom [23009,23021]
atom [23009,23021]
===
match
---
suite [86170,86298]
suite [86221,86349]
===
match
---
decorated [29575,29714]
decorated [29575,29714]
===
match
---
name: include_parentdag [49152,49169]
name: include_parentdag [49152,49169]
===
match
---
simple_stmt [64770,64788]
simple_stmt [64821,64839]
===
match
---
simple_stmt [24134,24146]
simple_stmt [24134,24146]
===
match
---
string: "Setting next_dagrun for %s to %s" [92071,92105]
string: "Setting next_dagrun for %s to %s" [92122,92156]
===
match
---
operator: * [92695,92696]
operator: * [92746,92747]
===
match
---
name: commit [79836,79842]
name: commit [79887,79893]
===
match
---
simple_stmt [36444,36510]
simple_stmt [36444,36510]
===
match
---
if_stmt [91603,92053]
if_stmt [91654,92104]
===
match
---
name: self [20823,20827]
name: self [20823,20827]
===
match
---
name: file [2272,2276]
name: file [2272,2276]
===
match
---
name: DagTag [83163,83169]
name: DagTag [83214,83220]
===
match
---
decorated [88083,88755]
decorated [88134,88806]
===
match
---
name: Tuple [1163,1168]
name: Tuple [1163,1168]
===
match
---
trailer [51423,51432]
trailer [51474,51483]
===
match
---
simple_stmt [1896,1943]
simple_stmt [1896,1943]
===
match
---
atom_expr [17220,17261]
atom_expr [17220,17261]
===
match
---
name: next_run_date [26551,26564]
name: next_run_date [26551,26564]
===
match
---
atom_expr [89396,89413]
atom_expr [89447,89464]
===
match
---
atom_expr [19233,19247]
atom_expr [19233,19247]
===
match
---
name: airflow [1856,1863]
name: airflow [1856,1863]
===
match
---
name: self [59760,59764]
name: self [59811,59815]
===
match
---
atom_expr [61223,61246]
atom_expr [61274,61297]
===
match
---
trailer [85148,85160]
trailer [85199,85211]
===
match
---
atom_expr [14773,14936]
atom_expr [14773,14936]
===
match
---
trailer [36531,36538]
trailer [36531,36538]
===
match
---
suite [83433,83459]
suite [83484,83510]
===
match
---
trailer [74629,74638]
trailer [74680,74689]
===
match
---
name: dag_id [87470,87476]
name: dag_id [87521,87527]
===
match
---
name: filter [45647,45653]
name: filter [45647,45653]
===
match
---
operator: = [12500,12501]
operator: = [12500,12501]
===
match
---
trailer [50242,50257]
trailer [50293,50308]
===
match
---
atom_expr [73754,73763]
atom_expr [73805,73814]
===
match
---
if_stmt [41780,42146]
if_stmt [41780,42146]
===
match
---
atom_expr [76406,76421]
atom_expr [76457,76472]
===
match
---
trailer [49042,49046]
trailer [49042,49046]
===
match
---
trailer [65972,65982]
trailer [66023,66033]
===
match
---
name: first [86749,86754]
name: first [86800,86805]
===
match
---
atom_expr [65148,65208]
atom_expr [65199,65259]
===
match
---
name: fn [31068,31070]
name: fn [31068,31070]
===
match
---
atom_expr [17335,17371]
atom_expr [17335,17371]
===
match
---
name: getboolean [66897,66907]
name: getboolean [66948,66958]
===
match
---
param [92769,92775]
param [92820,92826]
===
match
---
arglist [94030,94041]
arglist [94081,94092]
===
match
---
atom_expr [73252,73269]
atom_expr [73303,73320]
===
match
---
name: self [64312,64316]
name: self [64363,64367]
===
match
---
name: _parent_group [61134,61147]
name: _parent_group [61185,61198]
===
match
---
name: dag_model [89352,89361]
name: dag_model [89403,89412]
===
match
---
for_stmt [44572,45132]
for_stmt [44572,45132]
===
match
---
sync_comp_for [63049,63068]
sync_comp_for [63100,63119]
===
match
---
trailer [38024,38031]
trailer [38024,38031]
===
match
---
operator: = [90975,90976]
operator: = [91026,91027]
===
match
---
name: Optional [70126,70134]
name: Optional [70177,70185]
===
match
---
atom_expr [85690,85741]
atom_expr [85741,85792]
===
match
---
name: start_date [12455,12465]
name: start_date [12455,12465]
===
match
---
trailer [54491,54495]
trailer [54542,54546]
===
match
---
comp_op [74439,74445]
comp_op [74490,74496]
===
match
---
name: run_type [71942,71950]
name: run_type [71993,72001]
===
match
---
simple_stmt [35915,36187]
simple_stmt [35915,36187]
===
match
---
name: bind_partial [92682,92694]
name: bind_partial [92733,92745]
===
match
---
name: updated_access_control [18607,18629]
name: updated_access_control [18607,18629]
===
match
---
string: 'dag_id' [9676,9684]
string: 'dag_id' [9676,9684]
===
match
---
trailer [40248,40268]
trailer [40248,40268]
===
match
---
simple_stmt [95093,95140]
simple_stmt [95144,95191]
===
match
---
operator: = [11689,11690]
operator: = [11689,11690]
===
match
---
name: query [3700,3705]
name: query [3700,3705]
===
match
---
name: self [12571,12575]
name: self [12571,12575]
===
match
---
name: schedule_interval [13776,13793]
name: schedule_interval [13776,13793]
===
match
---
name: paused_dag_ids [87614,87628]
name: paused_dag_ids [87665,87679]
===
match
---
name: query [48612,48617]
name: query [48612,48617]
===
match
---
suite [36431,36510]
suite [36431,36510]
===
match
---
name: get_latest_execution_date [38455,38480]
name: get_latest_execution_date [38455,38480]
===
match
---
name: DagModel [73905,73913]
name: DagModel [73956,73964]
===
match
---
comparison [32057,32082]
comparison [32057,32082]
===
match
---
name: dags [73695,73699]
name: dags [73746,73750]
===
match
---
operator: { [18124,18125]
operator: { [18124,18125]
===
match
---
name: self [13771,13775]
name: self [13771,13775]
===
match
---
atom_expr [84244,84263]
atom_expr [84295,84314]
===
match
---
trailer [28821,28828]
trailer [28821,28828]
===
match
---
trailer [81090,81094]
trailer [81141,81145]
===
match
---
simple_stmt [72933,73126]
simple_stmt [72984,73177]
===
match
---
string: 'cache_size' [39791,39803]
string: 'cache_size' [39791,39803]
===
match
---
atom_expr [92107,92117]
atom_expr [92158,92168]
===
match
---
name: active_dag_ids [78419,78433]
name: active_dag_ids [78470,78484]
===
match
---
atom_expr [51041,51046]
atom_expr [51092,51097]
===
match
---
param [26755,26766]
param [26755,26766]
===
match
---
import_name [1204,1217]
import_name [1204,1217]
===
match
---
name: searchpath [39671,39681]
name: searchpath [39671,39681]
===
match
---
name: get_serialized_fields [81261,81282]
name: get_serialized_fields [81312,81333]
===
match
---
operator: { [14908,14909]
operator: { [14908,14909]
===
match
---
operator: , [58556,58557]
operator: , [58607,58608]
===
match
---
name: dag [76706,76709]
name: dag [76757,76760]
===
match
---
name: Column [84596,84602]
name: Column [84647,84653]
===
match
---
atom_expr [74468,74485]
atom_expr [74519,74536]
===
match
---
operator: , [38365,38366]
operator: , [38365,38366]
===
match
---
trailer [12110,12121]
trailer [12110,12121]
===
match
---
name: append [74660,74666]
name: append [74711,74717]
===
match
---
trailer [76245,76255]
trailer [76296,76306]
===
match
---
expr_stmt [15626,15693]
expr_stmt [15626,15693]
===
match
---
atom_expr [64362,64378]
atom_expr [64413,64429]
===
match
---
operator: , [46112,46113]
operator: , [46112,46113]
===
match
---
name: all [16369,16372]
name: all [16369,16372]
===
match
---
comp_if [26506,26519]
comp_if [26506,26519]
===
match
---
operator: = [49897,49898]
operator: = [49948,49949]
===
match
---
name: self [65089,65093]
name: self [65140,65144]
===
match
---
operator: @ [92729,92730]
operator: @ [92780,92781]
===
match
---
trailer [39214,39220]
trailer [39214,39220]
===
match
---
sync_comp_for [42503,42551]
sync_comp_for [42503,42551]
===
match
---
operator: , [43481,43482]
operator: , [43481,43482]
===
match
---
name: min [26598,26601]
name: min [26598,26601]
===
match
---
name: timezone [13346,13354]
name: timezone [13346,13354]
===
match
---
not_test [42529,42551]
not_test [42529,42551]
===
match
---
name: __tablename__ [83254,83267]
name: __tablename__ [83305,83318]
===
match
---
simple_stmt [2176,2253]
simple_stmt [2176,2253]
===
match
---
trailer [54495,54503]
trailer [54546,54554]
===
match
---
operator: = [74143,74144]
operator: = [74194,74195]
===
match
---
operator: = [94303,94304]
operator: = [94354,94355]
===
match
---
operator: = [56511,56512]
operator: = [56562,56563]
===
match
---
atom [27309,27311]
atom [27309,27311]
===
match
---
operator: , [18545,18546]
operator: , [18545,18546]
===
match
---
suite [58202,58239]
suite [58253,58290]
===
match
---
name: only_failed [57224,57235]
name: only_failed [57275,57286]
===
match
---
trailer [11639,11648]
trailer [11639,11648]
===
match
---
name: _comps [16437,16443]
name: _comps [16437,16443]
===
match
---
name: list [76859,76863]
name: list [76910,76914]
===
match
---
trailer [2876,2883]
trailer [2876,2883]
===
match
---
name: default_args [12739,12751]
name: default_args [12739,12751]
===
match
---
string: '.' [49334,49337]
string: '.' [49385,49388]
===
match
---
string: """         Calculates the following schedule for this dag in UTC.          :param dttm: utc datetime         :return: utc datetime         """ [19571,19714]
string: """         Calculates the following schedule for this dag in UTC.          :param dttm: utc datetime         :return: utc datetime         """ [19571,19714]
===
match
---
trailer [86754,86756]
trailer [86805,86807]
===
match
---
name: t [56856,56857]
name: t [56907,56908]
===
match
---
trailer [57796,57802]
trailer [57847,57853]
===
match
---
name: conf [83881,83885]
name: conf [83932,83936]
===
match
---
trailer [51413,51418]
trailer [51464,51469]
===
match
---
name: dag_run_state [53969,53982]
name: dag_run_state [54020,54033]
===
match
---
trailer [59728,59738]
trailer [59779,59789]
===
match
---
trailer [75659,75663]
trailer [75710,75714]
===
match
---
name: qry [81164,81167]
name: qry [81215,81218]
===
match
---
arglist [37609,37742]
arglist [37609,37742]
===
match
---
return_stmt [87607,87628]
return_stmt [87658,87679]
===
match
---
name: is_subdag [27806,27815]
name: is_subdag [27806,27815]
===
match
---
simple_stmt [36519,36541]
simple_stmt [36519,36541]
===
match
---
simple_stmt [90069,90441]
simple_stmt [90120,90492]
===
match
---
argument [18563,18575]
argument [18563,18575]
===
match
---
trailer [74008,74015]
trailer [74059,74066]
===
match
---
simple_stmt [13771,13814]
simple_stmt [13771,13814]
===
match
---
name: self [17256,17260]
name: self [17256,17260]
===
match
---
suite [40212,40270]
suite [40212,40270]
===
match
---
arglist [76801,76814]
arglist [76852,76865]
===
match
---
trailer [40882,40884]
trailer [40882,40884]
===
match
---
return_stmt [26684,26695]
return_stmt [26684,26695]
===
match
---
name: str [58692,58695]
name: str [58743,58746]
===
match
---
simple_stmt [14767,14937]
simple_stmt [14767,14937]
===
match
---
name: updated_access_control [18099,18121]
name: updated_access_control [18099,18121]
===
match
---
trailer [76751,76763]
trailer [76802,76814]
===
match
---
comparison [52518,52551]
comparison [52569,52602]
===
match
---
atom [39760,39777]
atom [39760,39777]
===
match
---
name: str [87664,87667]
name: str [87715,87718]
===
match
---
comp_if [42526,42551]
comp_if [42526,42551]
===
match
---
import_from [11447,11493]
import_from [11447,11493]
===
match
---
expr_stmt [35620,35679]
expr_stmt [35620,35679]
===
match
---
suite [60312,60382]
suite [60363,60433]
===
match
---
string: 'DAG.tasks can not be modified. Use dag.add_task() instead.' [30629,30689]
string: 'DAG.tasks can not be modified. Use dag.add_task() instead.' [30629,30689]
===
match
---
atom_expr [34902,34964]
atom_expr [34902,34964]
===
match
---
simple_stmt [866,877]
simple_stmt [866,877]
===
match
---
name: confirm_prompt [56796,56810]
name: confirm_prompt [56847,56861]
===
match
---
operator: = [10781,10782]
operator: = [10781,10782]
===
match
---
expr_stmt [74363,74395]
expr_stmt [74414,74446]
===
match
---
name: dag_id [28822,28828]
name: dag_id [28822,28828]
===
match
---
name: edge_info [82720,82729]
name: edge_info [82771,82780]
===
match
---
name: dag_id [73791,73797]
name: dag_id [73842,73848]
===
match
---
atom_expr [89541,89560]
atom_expr [89592,89611]
===
match
---
name: task [65876,65880]
name: task [65927,65931]
===
match
---
trailer [31075,31083]
trailer [31075,31083]
===
match
---
name: task [64941,64945]
name: task [64992,64996]
===
match
---
expr_stmt [2922,2977]
expr_stmt [2922,2977]
===
match
---
name: Optional [1140,1148]
name: Optional [1140,1148]
===
match
---
name: tis [41838,41841]
name: tis [41838,41841]
===
match
---
name: property [30697,30705]
name: property [30697,30705]
===
match
---
suite [17211,17282]
suite [17211,17282]
===
match
---
name: int [12132,12135]
name: int [12132,12135]
===
match
---
operator: = [86077,86078]
operator: = [86128,86129]
===
match
---
trailer [74561,74566]
trailer [74612,74617]
===
match
---
name: cron_next [19361,19370]
name: cron_next [19361,19370]
===
match
---
dotted_name [1948,1969]
dotted_name [1948,1969]
===
match
---
dotted_name [2310,2331]
dotted_name [2310,2331]
===
match
---
atom_expr [85869,85940]
atom_expr [85920,85991]
===
match
---
name: tis [54647,54650]
name: tis [54698,54701]
===
match
---
simple_stmt [12344,12389]
simple_stmt [12344,12389]
===
match
---
atom_expr [38981,38995]
atom_expr [38981,38995]
===
match
---
name: run [35764,35767]
name: run [35764,35767]
===
match
---
atom_expr [15702,15730]
atom_expr [15702,15730]
===
match
---
simple_stmt [45055,45132]
simple_stmt [45055,45132]
===
match
---
argument [49283,49342]
argument [49334,49393]
===
match
---
decorated [30457,30555]
decorated [30457,30555]
===
match
---
name: self [45982,45986]
name: self [45982,45986]
===
match
---
name: arguments [93374,93383]
name: arguments [93425,93434]
===
match
---
name: dag_id [79916,79922]
name: dag_id [79967,79973]
===
match
---
operator: = [62725,62726]
operator: = [62776,62777]
===
match
---
expr_stmt [19361,19396]
expr_stmt [19361,19396]
===
match
---
operator: } [18089,18090]
operator: } [18089,18090]
===
match
---
atom_expr [13707,13761]
atom_expr [13707,13761]
===
match
---
parameters [95728,95733]
parameters [95779,95784]
===
match
---
name: DagRun [36349,36355]
name: DagRun [36349,36355]
===
match
---
if_stmt [12616,12767]
if_stmt [12616,12767]
===
match
---
name: property [86368,86376]
name: property [86419,86427]
===
match
---
suite [26260,26285]
suite [26260,26285]
===
match
---
expr_stmt [55159,55200]
expr_stmt [55210,55251]
===
match
---
name: State [45376,45381]
name: State [45376,45381]
===
match
---
name: self [13497,13501]
name: self [13497,13501]
===
match
---
arglist [92695,92718]
arglist [92746,92769]
===
match
---
for_stmt [76844,77021]
for_stmt [76895,77072]
===
match
---
name: recursion_depth [49977,49992]
name: recursion_depth [50028,50043]
===
match
---
atom_expr [9997,10010]
atom_expr [9997,10010]
===
match
---
operator: @ [29030,29031]
operator: @ [29030,29031]
===
match
---
simple_stmt [75874,75931]
simple_stmt [75925,75982]
===
match
---
name: deepcopy [57987,57995]
name: deepcopy [58038,58046]
===
match
---
return_stmt [16453,16465]
return_stmt [16453,16465]
===
match
---
argument [53583,53610]
argument [53634,53661]
===
match
---
name: f_back [12266,12272]
name: f_back [12266,12272]
===
match
---
name: session [86809,86816]
name: session [86860,86867]
===
match
---
name: next_run_date [26084,26097]
name: next_run_date [26084,26097]
===
match
---
simple_stmt [62374,62459]
simple_stmt [62425,62510]
===
match
---
parameters [78107,78113]
parameters [78158,78164]
===
match
---
operator: } [74184,74185]
operator: } [74235,74236]
===
match
---
atom_expr [40320,40365]
atom_expr [40320,40365]
===
match
---
name: union [49462,49467]
name: union [49513,49518]
===
match
---
trailer [35144,35165]
trailer [35144,35165]
===
match
---
name: DagRun [75469,75475]
name: DagRun [75520,75526]
===
match
---
name: dag_id [75779,75785]
name: dag_id [75830,75836]
===
match
---
trailer [43467,43512]
trailer [43467,43512]
===
match
---
trailer [35008,35010]
trailer [35008,35010]
===
match
---
expr_stmt [54981,55146]
expr_stmt [55032,55197]
===
match
---
name: session [86671,86678]
name: session [86722,86729]
===
match
---
atom_expr [83291,83328]
atom_expr [83342,83379]
===
match
---
operator: + [20759,20760]
operator: + [20759,20760]
===
match
---
trailer [87419,87429]
trailer [87470,87480]
===
match
---
atom_expr [64883,64916]
atom_expr [64934,64967]
===
match
---
return_stmt [23131,23180]
return_stmt [23131,23180]
===
match
---
operator: = [12294,12295]
operator: = [12294,12295]
===
match
---
string: '.' [88062,88065]
string: '.' [88113,88116]
===
match
---
name: dag_id [91909,91915]
name: dag_id [91960,91966]
===
match
---
operator: = [61878,61879]
operator: = [61929,61930]
===
match
---
name: key [75717,75720]
name: key [75768,75771]
===
match
---
expr_stmt [84225,84263]
expr_stmt [84276,84314]
===
match
---
atom_expr [12630,12661]
atom_expr [12630,12661]
===
match
---
import_from [2141,2175]
import_from [2141,2175]
===
match
---
name: info [82897,82901]
name: info [82948,82952]
===
match
---
param [29436,29441]
param [29436,29441]
===
match
---
operator: , [49992,49993]
operator: , [50043,50044]
===
match
---
name: start_date [65518,65528]
name: start_date [65569,65579]
===
match
---
trailer [25912,25923]
trailer [25912,25923]
===
match
---
name: info [79562,79566]
name: info [79613,79617]
===
match
---
name: normalize_schedule [25962,25980]
name: normalize_schedule [25962,25980]
===
match
---
name: run_id [71699,71705]
name: run_id [71750,71756]
===
match
---
trailer [64148,64155]
trailer [64199,64206]
===
match
---
or_test [11649,11667]
or_test [11649,11667]
===
match
---
trailer [14039,14050]
trailer [14039,14050]
===
match
---
param [70304,70342]
param [70355,70393]
===
match
---
operator: , [55919,55920]
operator: , [55970,55971]
===
match
---
operator: = [58155,58156]
operator: = [58206,58207]
===
match
---
atom_expr [86904,86915]
atom_expr [86955,86966]
===
match
---
trailer [65556,65567]
trailer [65607,65618]
===
match
---
operator: = [69370,69371]
operator: = [69421,69422]
===
match
---
param [10945,11012]
param [10945,11012]
===
match
---
operator: , [34058,34059]
operator: , [34058,34059]
===
match
---
trailer [88571,88578]
trailer [88622,88629]
===
match
---
expr_stmt [56167,56570]
expr_stmt [56218,56621]
===
match
---
name: concurrency [29397,29408]
name: concurrency [29397,29408]
===
match
---
operator: = [57513,57514]
operator: = [57564,57565]
===
match
---
trailer [93336,93345]
trailer [93387,93396]
===
match
---
string: 'dag_id' [93384,93392]
string: 'dag_id' [93435,93443]
===
match
---
tfpdef [11021,11074]
tfpdef [11021,11074]
===
match
---
operator: = [87344,87345]
operator: = [87395,87396]
===
match
---
atom_expr [91000,91028]
atom_expr [91051,91079]
===
match
---
trailer [56590,56597]
trailer [56641,56648]
===
match
---
fstring_string: $ [53238,53239]
fstring_string: $ [53289,53290]
===
match
---
operator: , [41578,41579]
operator: , [41578,41579]
===
match
---
name: self [15809,15813]
name: self [15809,15813]
===
match
---
atom_expr [75416,75451]
atom_expr [75467,75502]
===
match
---
trailer [21792,21801]
trailer [21792,21801]
===
match
---
operator: , [83363,83364]
operator: , [83414,83415]
===
match
---
trailer [21608,21620]
trailer [21608,21620]
===
match
---
name: group [62400,62405]
name: group [62451,62456]
===
match
---
expr_stmt [48753,48768]
expr_stmt [48753,48768]
===
match
---
name: task_ids_or_regex [49283,49300]
name: task_ids_or_regex [49334,49351]
===
match
---
trailer [26250,26259]
trailer [26250,26259]
===
match
---
name: task_id [53230,53237]
name: task_id [53281,53288]
===
match
---
if_stmt [36399,36510]
if_stmt [36399,36510]
===
match
---
trailer [79561,79566]
trailer [79612,79617]
===
match
---
name: self [29621,29625]
name: self [29621,29625]
===
match
---
argument [53969,53996]
argument [54020,54047]
===
match
---
trailer [13590,13603]
trailer [13590,13603]
===
match
---
name: session [79407,79414]
name: session [79458,79465]
===
match
---
name: task_id [63388,63395]
name: task_id [63439,63446]
===
match
---
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_latest_execution_date` method." [38268,38365]
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_latest_execution_date` method." [38268,38365]
===
match
---
simple_stmt [74363,74396]
simple_stmt [74414,74447]
===
match
---
trailer [13086,13098]
trailer [13086,13098]
===
match
---
name: jinja_env_options [39964,39981]
name: jinja_env_options [39964,39981]
===
match
---
expr_stmt [40921,41004]
expr_stmt [40921,41004]
===
match
---
name: Dict [11263,11267]
name: Dict [11263,11267]
===
match
---
param [39186,39190]
param [39186,39190]
===
match
---
atom_expr [74319,74350]
atom_expr [74370,74401]
===
match
---
suite [61557,61826]
suite [61608,61877]
===
match
---
param [17205,17209]
param [17205,17209]
===
match
---
import_as_names [1616,1668]
import_as_names [1616,1668]
===
match
---
name: tags [16031,16035]
name: tags [16031,16035]
===
match
---
parameters [86393,86399]
parameters [86444,86450]
===
match
---
funcdef [28429,28648]
funcdef [28429,28648]
===
match
---
name: tis [41844,41847]
name: tis [41844,41847]
===
match
---
operator: = [21186,21187]
operator: = [21186,21187]
===
match
---
trailer [86890,87001]
trailer [86941,87052]
===
match
---
name: dag [76462,76465]
name: dag [76513,76516]
===
match
---
name: tis [56598,56601]
name: tis [56649,56652]
===
match
---
trailer [65853,65862]
trailer [65904,65913]
===
match
---
name: group [62266,62271]
name: group [62317,62322]
===
match
---
expr_stmt [29281,29308]
expr_stmt [29281,29308]
===
match
---
trailer [21778,21787]
trailer [21778,21787]
===
match
---
operator: = [53721,53722]
operator: = [53772,53773]
===
match
---
operator: = [28875,28876]
operator: = [28875,28876]
===
match
---
name: bulk_write_to_db [73224,73240]
name: bulk_write_to_db [73275,73291]
===
match
---
operator: -> [88191,88193]
operator: -> [88242,88244]
===
match
---
name: query [36444,36449]
name: query [36444,36449]
===
match
---
decorator [87990,88000]
decorator [88041,88051]
===
match
---
trailer [86748,86754]
trailer [86799,86805]
===
match
---
name: dag [57099,57102]
name: dag [57150,57153]
===
match
---
operator: = [30117,30118]
operator: = [30117,30118]
===
match
---
expr_stmt [58141,58168]
expr_stmt [58192,58219]
===
match
---
name: searchpath [39501,39511]
name: searchpath [39501,39511]
===
match
---
name: dag_id [78827,78833]
name: dag_id [78878,78884]
===
match
---
parameters [42818,42860]
parameters [42818,42860]
===
match
---
trailer [59764,59776]
trailer [59815,59827]
===
match
---
name: self [58107,58111]
name: self [58158,58162]
===
match
---
simple_stmt [37795,37810]
simple_stmt [37795,37810]
===
match
---
atom_expr [85359,85390]
atom_expr [85410,85441]
===
match
---
simple_stmt [41417,41458]
simple_stmt [41417,41458]
===
match
---
operator: , [37152,37153]
operator: , [37152,37153]
===
match
---
operator: , [10866,10867]
operator: , [10866,10867]
===
match
---
atom_expr [12250,12272]
atom_expr [12250,12272]
===
match
---
trailer [80673,80683]
trailer [80724,80734]
===
match
---
trailer [24674,24709]
trailer [24674,24709]
===
match
---
operator: @ [34013,34014]
operator: @ [34013,34014]
===
match
---
name: provide_session [2443,2458]
name: provide_session [2443,2458]
===
match
---
simple_stmt [93287,93347]
simple_stmt [93338,93398]
===
match
---
trailer [21936,21965]
trailer [21936,21965]
===
match
---
trailer [62379,62397]
trailer [62430,62448]
===
match
---
funcdef [29909,29978]
funcdef [29909,29978]
===
match
---
trailer [64369,64376]
trailer [64420,64427]
===
match
---
atom_expr [20566,20596]
atom_expr [20566,20596]
===
match
---
string: """         Simple utility method to set dependency between two tasks that         already have been added to the DAG using add_task()         """ [40463,40609]
string: """         Simple utility method to set dependency between two tasks that         already have been added to the DAG using add_task()         """ [40463,40609]
===
match
---
name: copy [60765,60769]
name: copy [60816,60820]
===
match
---
for_stmt [64737,64788]
for_stmt [64788,64839]
===
match
---
name: normalize_schedule [28050,28068]
name: normalize_schedule [28050,28068]
===
match
---
operator: = [28837,28838]
operator: = [28837,28838]
===
match
---
name: primary [51083,51090]
name: primary [51134,51141]
===
match
---
trailer [78816,78854]
trailer [78867,78905]
===
match
---
atom_expr [42046,42119]
atom_expr [42046,42119]
===
match
---
name: self [82680,82684]
name: self [82731,82735]
===
match
---
name: visited_external_tis [51128,51148]
name: visited_external_tis [51179,51199]
===
match
---
trailer [48887,48891]
trailer [48887,48891]
===
match
---
suite [60132,60219]
suite [60183,60270]
===
match
---
name: child [61278,61283]
name: child [61329,61334]
===
match
---
name: self [39439,39443]
name: self [39439,39443]
===
match
---
simple_stmt [81158,81207]
simple_stmt [81209,81258]
===
match
---
comparison [80773,80782]
comparison [80824,80833]
===
match
---
operator: , [70185,70186]
operator: , [70236,70237]
===
match
---
trailer [88618,88638]
trailer [88669,88689]
===
match
---
trailer [83375,83389]
trailer [83426,83440]
===
match
---
return_stmt [54878,54886]
return_stmt [54929,54937]
===
match
---
name: ORIENTATION_PRESETS [14878,14897]
name: ORIENTATION_PRESETS [14878,14897]
===
match
---
fstring_string: A cyclic dependency occurred in dag:  [45202,45239]
fstring_string: A cyclic dependency occurred in dag:  [45202,45239]
===
match
---
decorators [79850,79885]
decorators [79901,79936]
===
match
---
name: get_num_task_instances [79893,79915]
name: get_num_task_instances [79944,79966]
===
match
---
trailer [35413,35418]
trailer [35413,35418]
===
match
---
atom_expr [22141,22168]
atom_expr [22141,22168]
===
match
---
operator: -> [29350,29352]
operator: -> [29350,29352]
===
match
---
name: get [10822,10825]
name: get [10822,10825]
===
match
---
name: jinja_environment_kwargs [39834,39858]
name: jinja_environment_kwargs [39834,39858]
===
match
---
operator: , [31115,31116]
operator: , [31115,31116]
===
match
---
operator: , [86807,86808]
operator: , [86858,86859]
===
match
---
name: self [16116,16120]
name: self [16116,16120]
===
match
---
operator: , [82778,82779]
operator: , [82829,82830]
===
match
---
dictorsetmaker [87547,87597]
dictorsetmaker [87598,87648]
===
match
---
name: relativedelta [1299,1312]
name: relativedelta [1299,1312]
===
match
---
trailer [49320,49327]
trailer [49371,49378]
===
match
---
name: DeprecationWarning [38379,38397]
name: DeprecationWarning [38379,38397]
===
match
---
expr_stmt [21181,21211]
expr_stmt [21181,21211]
===
match
---
string: """     DAG context is used to keep the current DAG when DAG is used as ContextManager.      You can use DAG as context:      .. code-block:: python          with DAG(             dag_id='example_dag',             default_args=default_args,             schedule_interval='0 0 * * *',             dagrun_timeout=timedelta(minutes=60)         ) as dag:      If you do this the context stores the DAG and whenever new task is created, it will use     such stored DAG as the parent DAG.      """ [94549,95040]
string: """     DAG context is used to keep the current DAG when DAG is used as ContextManager.      You can use DAG as context:      .. code-block:: python          with DAG(             dag_id='example_dag',             default_args=default_args,             schedule_interval='0 0 * * *',             dagrun_timeout=timedelta(minutes=60)         ) as dag:      If you do this the context stores the DAG and whenever new task is created, it will use     such stored DAG as the parent DAG.      """ [94600,95091]
===
match
---
name: external_dag [53149,53161]
name: external_dag [53200,53212]
===
match
---
import_from [50671,50731]
import_from [50722,50782]
===
match
---
name: only_running [53722,53734]
name: only_running [53773,53785]
===
match
---
atom_expr [25267,25313]
atom_expr [25267,25313]
===
match
---
simple_stmt [95632,95664]
simple_stmt [95683,95715]
===
match
---
name: ti [35023,35025]
name: ti [35023,35025]
===
match
---
param [10876,10936]
param [10876,10936]
===
match
---
trailer [11809,11822]
trailer [11809,11822]
===
match
---
arglist [79584,79736]
arglist [79635,79787]
===
match
---
name: conditions [48753,48763]
name: conditions [48753,48763]
===
match
---
name: TI [48850,48852]
name: TI [48850,48852]
===
match
---
trailer [88752,88754]
trailer [88803,88805]
===
match
---
operator: + [64608,64609]
operator: + [64659,64660]
===
match
---
comp_op [76911,76917]
comp_op [76962,76968]
===
match
---
trailer [73898,73904]
trailer [73949,73955]
===
match
---
atom_expr [63632,63647]
atom_expr [63683,63698]
===
match
---
name: start_date [57130,57140]
name: start_date [57181,57191]
===
match
---
name: DAG [92635,92638]
name: DAG [92686,92689]
===
match
---
factor [35032,35034]
factor [35032,35034]
===
match
---
operator: , [82750,82751]
operator: , [82801,82802]
===
match
---
dotted_name [29576,29597]
dotted_name [29576,29597]
===
match
---
operator: = [70249,70250]
operator: = [70300,70301]
===
match
---
trailer [18242,18254]
trailer [18242,18254]
===
match
---
expr_stmt [20554,20596]
expr_stmt [20554,20596]
===
match
---
trailer [16593,16600]
trailer [16593,16600]
===
match
---
trailer [76409,76421]
trailer [76460,76472]
===
match
---
name: DagPickle [63959,63968]
name: DagPickle [64010,64019]
===
match
---
name: self [13528,13532]
name: self [13528,13532]
===
match
---
name: tuple [45271,45276]
name: tuple [45271,45276]
===
match
---
argument [55130,55145]
argument [55181,55196]
===
match
---
trailer [16657,16663]
trailer [16657,16663]
===
match
---
name: airflow [2114,2121]
name: airflow [2114,2121]
===
match
---
trailer [82719,82729]
trailer [82770,82780]
===
match
---
name: self [88122,88126]
name: self [88173,88177]
===
match
---
trailer [36370,36378]
trailer [36370,36378]
===
match
---
name: using_end_date [27510,27524]
name: using_end_date [27510,27524]
===
match
---
trailer [32519,32543]
trailer [32519,32543]
===
match
---
simple_stmt [12486,12520]
simple_stmt [12486,12520]
===
match
---
trailer [3665,3680]
trailer [3665,3680]
===
match
---
trailer [74110,74114]
trailer [74161,74165]
===
match
---
operator: = [40792,40793]
operator: = [40792,40793]
===
match
---
and_test [25501,25545]
and_test [25501,25545]
===
match
---
name: format_exc [63869,63879]
name: format_exc [63920,63930]
===
match
---
operator: = [86851,86852]
operator: = [86902,86903]
===
match
---
if_stmt [24880,24961]
if_stmt [24880,24961]
===
match
---
simple_stmt [12281,12336]
simple_stmt [12281,12336]
===
match
---
suite [24710,24750]
suite [24710,24750]
===
match
---
name: TaskInstance [41068,41080]
name: TaskInstance [41068,41080]
===
match
---
arglist [69871,69881]
arglist [69922,69932]
===
match
---
param [67035,67059]
param [67086,67110]
===
match
---
operator: = [60241,60242]
operator: = [60292,60293]
===
match
---
name: dag_id [37631,37637]
name: dag_id [37631,37637]
===
match
---
import_from [68940,69000]
import_from [68991,69051]
===
match
---
atom_expr [36465,36488]
atom_expr [36465,36488]
===
match
---
operator: = [70226,70227]
operator: = [70277,70278]
===
match
---
name: str [10889,10892]
name: str [10889,10892]
===
match
---
simple_stmt [58077,58133]
simple_stmt [58128,58184]
===
match
---
name: parser [69770,69776]
name: parser [69821,69827]
===
match
---
operator: , [20063,20064]
operator: , [20063,20064]
===
match
---
fstring_string: ' has already been added to the DAG [66154,66189]
fstring_string: ' has already been added to the DAG [66205,66240]
===
match
---
trailer [84486,84499]
trailer [84537,84550]
===
match
---
simple_stmt [93653,93680]
simple_stmt [93704,93731]
===
match
---
trailer [36538,36540]
trailer [36538,36540]
===
match
---
trailer [63377,63387]
trailer [63428,63438]
===
match
---
operator: = [85636,85637]
operator: = [85687,85688]
===
match
---
operator: , [81991,81992]
operator: , [82042,82043]
===
match
---
name: func [69866,69870]
name: func [69917,69921]
===
match
---
name: task_dict [66468,66477]
name: task_dict [66519,66528]
===
match
---
suite [65129,65209]
suite [65180,65260]
===
match
---
name: airflow [1772,1779]
name: airflow [1772,1779]
===
match
---
param [58768,58790]
param [58819,58841]
===
match
---
trailer [15706,15730]
trailer [15706,15730]
===
match
---
name: timezone [20509,20517]
name: timezone [20509,20517]
===
match
---
name: Optional [70321,70329]
name: Optional [70372,70380]
===
match
---
trailer [65093,65104]
trailer [65144,65155]
===
match
---
name: dag [73807,73810]
name: dag [73858,73861]
===
match
---
name: dag [62063,62066]
name: dag [62114,62117]
===
match
---
operator: = [27974,27975]
operator: = [27974,27975]
===
match
---
and_test [12440,12472]
and_test [12440,12472]
===
match
---
atom_expr [31285,31303]
atom_expr [31285,31303]
===
match
---
if_stmt [95215,95324]
if_stmt [95266,95375]
===
match
---
suite [13862,13919]
suite [13862,13919]
===
match
---
name: dagrun [37079,37085]
name: dagrun [37079,37085]
===
match
---
name: DagModel [86564,86572]
name: DagModel [86615,86623]
===
match
---
atom_expr [12734,12765]
atom_expr [12734,12765]
===
match
---
simple_stmt [71910,71968]
simple_stmt [71961,72019]
===
match
---
string: '@once' [24082,24089]
string: '@once' [24082,24089]
===
match
---
atom_expr [3548,3590]
atom_expr [3548,3590]
===
match
---
name: self [27801,27805]
name: self [27801,27805]
===
match
---
operator: = [32603,32604]
operator: = [32603,32604]
===
match
---
fstring_start: f" [56894,56896]
fstring_start: f" [56945,56947]
===
match
---
atom_expr [55693,55733]
atom_expr [55744,55784]
===
match
---
atom_expr [75632,75645]
atom_expr [75683,75696]
===
match
---
trailer [33168,33182]
trailer [33168,33182]
===
match
---
name: default_args [13649,13661]
name: default_args [13649,13661]
===
match
---
suite [71748,71968]
suite [71799,72019]
===
match
---
expr_stmt [76384,76421]
expr_stmt [76435,76472]
===
match
---
decorators [78957,78992]
decorators [79008,79043]
===
match
---
trailer [51359,51471]
trailer [51410,51522]
===
match
---
operator: { [71624,71625]
operator: { [71675,71676]
===
match
---
operator: , [53801,53802]
operator: , [53852,53853]
===
match
---
name: self [16051,16055]
name: self [16051,16055]
===
match
---
param [34082,34094]
param [34082,34094]
===
match
---
name: query [41028,41033]
name: query [41028,41033]
===
match
---
name: state [50440,50445]
name: state [50491,50496]
===
match
---
atom_expr [27752,27793]
atom_expr [27752,27793]
===
match
---
trailer [64007,64014]
trailer [64058,64065]
===
match
---
string: 'task_ids' [16779,16789]
string: 'task_ids' [16779,16789]
===
match
---
atom_expr [92674,92719]
atom_expr [92725,92770]
===
match
---
name: start_date [37680,37690]
name: start_date [37680,37690]
===
match
---
operator: , [53734,53735]
operator: , [53785,53786]
===
match
---
atom_expr [61880,61921]
atom_expr [61931,61972]
===
match
---
simple_stmt [73773,73820]
simple_stmt [73824,73871]
===
match
---
name: functools [64883,64892]
name: functools [64934,64943]
===
match
---
trailer [24999,25010]
trailer [24999,25010]
===
match
---
name: jinja2 [39647,39653]
name: jinja2 [39647,39653]
===
match
---
expr_stmt [76546,76638]
expr_stmt [76597,76689]
===
match
---
name: filter [42198,42204]
name: filter [42198,42204]
===
match
---
operator: != [18301,18303]
operator: != [18301,18303]
===
match
---
name: _access_control [29554,29569]
name: _access_control [29554,29569]
===
match
---
operator: = [10011,10012]
operator: = [10011,10012]
===
match
---
expr_stmt [39094,39127]
expr_stmt [39094,39127]
===
match
---
fstring_expr [71879,71895]
fstring_expr [71930,71946]
===
match
---
operator: } [60797,60798]
operator: } [60848,60849]
===
match
---
name: run_dates [27297,27306]
name: run_dates [27297,27306]
===
match
---
name: t [64718,64719]
name: t [64769,64770]
===
match
---
parameters [16115,16121]
parameters [16115,16121]
===
match
---
simple_stmt [1984,2068]
simple_stmt [1984,2068]
===
match
---
name: owner [76220,76225]
name: owner [76271,76276]
===
match
---
atom_expr [19737,19770]
atom_expr [19737,19770]
===
match
---
operator: } [9862,9863]
operator: } [9862,9863]
===
match
---
name: List [30732,30736]
name: List [30732,30736]
===
match
---
decorator [28958,28968]
decorator [28958,28968]
===
match
---
name: convert_to_utc [21894,21908]
name: convert_to_utc [21894,21908]
===
match
---
argument [73102,73114]
argument [73153,73165]
===
match
---
name: task_ids_or_regex [58667,58684]
name: task_ids_or_regex [58718,58735]
===
match
---
trailer [93320,93324]
trailer [93371,93375]
===
match
---
name: datetime [19387,19395]
name: datetime [19387,19395]
===
match
---
operator: = [56002,56003]
operator: = [56053,56054]
===
match
---
name: task_id [52307,52314]
name: task_id [52358,52365]
===
match
---
name: Dict [11376,11380]
name: Dict [11376,11380]
===
match
---
operator: = [49611,49612]
operator: = [49662,49663]
===
match
---
trailer [95301,95322]
trailer [95352,95373]
===
match
---
operator: ** [39962,39964]
operator: ** [39962,39964]
===
match
---
simple_stmt [76652,76831]
simple_stmt [76703,76882]
===
match
---
simple_stmt [78458,78711]
simple_stmt [78509,78762]
===
match
---
name: tii [52956,52959]
name: tii [53007,53010]
===
match
---
trailer [20668,20697]
trailer [20668,20697]
===
match
---
param [90042,90058]
param [90093,90109]
===
match
---
trailer [38254,38434]
trailer [38254,38434]
===
match
---
operator: = [3546,3547]
operator: = [3546,3547]
===
match
---
trailer [49265,49438]
trailer [49316,49489]
===
match
---
for_stmt [93935,94043]
for_stmt [93986,94094]
===
match
---
param [17306,17312]
param [17306,17312]
===
match
---
fstring_string: <DAG:  [16140,16146]
fstring_string: <DAG:  [16140,16146]
===
match
---
simple_stmt [2141,2176]
simple_stmt [2141,2176]
===
match
---
funcdef [87046,87629]
funcdef [87097,87680]
===
match
---
tfpdef [10312,10360]
tfpdef [10312,10360]
===
match
---
atom_expr [10762,10780]
atom_expr [10762,10780]
===
match
---
trailer [26071,26082]
trailer [26071,26082]
===
match
---
simple_stmt [86409,86434]
simple_stmt [86460,86485]
===
match
---
param [10691,10734]
param [10691,10734]
===
match
---
atom_expr [52021,52348]
atom_expr [52072,52399]
===
match
---
and_test [68766,68788]
and_test [68817,68839]
===
match
---
simple_stmt [68802,68861]
simple_stmt [68853,68912]
===
match
---
atom_expr [50527,50535]
atom_expr [50578,50586]
===
match
---
atom_expr [63374,63396]
atom_expr [63425,63447]
===
match
---
expr_stmt [61127,61162]
expr_stmt [61178,61213]
===
match
---
name: num [18960,18963]
name: num [18960,18963]
===
match
---
atom [13897,13918]
atom [13897,13918]
===
match
---
name: extend [45068,45074]
name: extend [45068,45074]
===
match
---
name: str [54947,54950]
name: str [54998,55001]
===
match
---
expr_stmt [54830,54842]
expr_stmt [54881,54893]
===
match
---
name: dag [74594,74597]
name: dag [74645,74648]
===
match
---
name: timezone [21626,21634]
name: timezone [21626,21634]
===
match
---
param [55840,55845]
param [55891,55896]
===
match
---
trailer [61897,61921]
trailer [61948,61972]
===
match
---
funcdef [42572,42793]
funcdef [42572,42793]
===
match
---
name: self [78043,78047]
name: self [78094,78098]
===
match
---
trailer [41095,41102]
trailer [41095,41102]
===
match
---
expr_stmt [9657,9863]
expr_stmt [9657,9863]
===
match
---
trailer [11847,11854]
trailer [11847,11854]
===
match
---
name: default [30110,30117]
name: default [30110,30117]
===
match
---
param [62997,63009]
param [63048,63060]
===
match
---
name: task_dict [30768,30777]
name: task_dict [30768,30777]
===
match
---
expr_stmt [33878,33903]
expr_stmt [33878,33903]
===
match
---
atom_expr [84320,84339]
atom_expr [84371,84390]
===
match
---
operator: = [95452,95453]
operator: = [95503,95504]
===
match
---
name: filter_query [88624,88636]
name: filter_query [88675,88687]
===
match
---
name: base [1689,1693]
name: base [1689,1693]
===
match
---
name: Callable [1061,1069]
name: Callable [1061,1069]
===
match
---
name: template_searchpath [13954,13973]
name: template_searchpath [13954,13973]
===
match
---
trailer [61237,61244]
trailer [61288,61295]
===
match
---
name: replace [88054,88061]
name: replace [88105,88112]
===
match
---
name: tis [42244,42247]
name: tis [42244,42247]
===
match
---
suite [18840,18869]
suite [18840,18869]
===
match
---
atom_expr [17038,17071]
atom_expr [17038,17071]
===
match
---
operator: = [95563,95564]
operator: = [95614,95615]
===
match
---
parameters [29748,29754]
parameters [29748,29754]
===
match
---
fstring [14518,14570]
fstring [14518,14570]
===
match
---
operator: = [71917,71918]
operator: = [71968,71969]
===
match
---
atom_expr [42263,42290]
atom_expr [42263,42290]
===
match
---
trailer [73737,73764]
trailer [73788,73815]
===
match
---
name: get_task [40670,40678]
name: get_task [40670,40678]
===
match
---
trailer [77330,77343]
trailer [77381,77394]
===
match
---
name: _getframe [12254,12263]
name: _getframe [12254,12263]
===
match
---
operator: = [18767,18768]
operator: = [18767,18768]
===
match
---
name: self [49174,49178]
name: self [49174,49178]
===
match
---
operator: , [69281,69282]
operator: , [69332,69333]
===
match
---
decorator [34013,34030]
decorator [34013,34030]
===
match
---
atom_expr [20334,20365]
atom_expr [20334,20365]
===
match
---
param [10797,10867]
param [10797,10867]
===
match
---
atom_expr [66459,66478]
atom_expr [66510,66529]
===
match
---
name: str [12663,12666]
name: str [12663,12666]
===
match
---
param [32590,32595]
param [32590,32595]
===
match
---
param [66879,66932]
param [66930,66983]
===
match
---
name: sorted [75700,75706]
name: sorted [75751,75757]
===
match
---
name: tasks [42758,42763]
name: tasks [42758,42763]
===
match
---
trailer [69865,69870]
trailer [69916,69921]
===
match
---
name: session [28838,28845]
name: session [28838,28845]
===
match
---
simple_stmt [57099,57481]
simple_stmt [57150,57532]
===
match
---
dictorsetmaker [9676,9857]
dictorsetmaker [9676,9857]
===
match
---
string: 'parent_dag' [9714,9726]
string: 'parent_dag' [9714,9726]
===
match
---
operator: , [22212,22213]
operator: , [22212,22213]
===
match
---
expr_stmt [41602,41647]
expr_stmt [41602,41647]
===
match
---
return_stmt [64423,64432]
return_stmt [64474,64483]
===
match
---
name: parser [69833,69839]
name: parser [69884,69890]
===
match
---
name: self [86316,86320]
name: self [86367,86371]
===
match
---
name: self [31678,31682]
name: self [31678,31682]
===
match
---
import_as_names [1432,1465]
import_as_names [1432,1465]
===
match
---
expr_stmt [26457,26520]
expr_stmt [26457,26520]
===
match
---
trailer [35209,35229]
trailer [35209,35229]
===
match
---
trailer [60079,60087]
trailer [60130,60138]
===
match
---
dotted_name [69731,69742]
dotted_name [69782,69793]
===
match
---
operator: , [73114,73115]
operator: , [73165,73166]
===
match
---
name: state [40787,40792]
name: state [40787,40792]
===
match
---
suite [56623,56651]
suite [56674,56702]
===
match
---
expr_stmt [25132,25201]
expr_stmt [25132,25201]
===
match
---
operator: = [74083,74084]
operator: = [74134,74135]
===
match
---
tfpdef [91093,91141]
tfpdef [91144,91192]
===
match
---
trailer [91783,91789]
trailer [91834,91840]
===
match
---
operator: , [57324,57325]
operator: , [57375,57376]
===
match
---
name: Optional [91114,91122]
name: Optional [91165,91173]
===
match
---
name: self [63178,63182]
name: self [63229,63233]
===
match
---
name: session [55743,55750]
name: session [55794,55801]
===
match
---
name: self [24245,24249]
name: self [24245,24249]
===
match
---
name: self [29373,29377]
name: self [29373,29377]
===
match
---
name: tags [77319,77323]
name: tags [77370,77374]
===
match
---
name: self [11967,11971]
name: self [11967,11971]
===
match
---
trailer [86556,86563]
trailer [86607,86614]
===
match
---
argument [18956,18963]
argument [18956,18963]
===
match
---
trailer [19418,19425]
trailer [19418,19425]
===
match
---
argument [85375,85389]
argument [85426,85440]
===
match
---
expr_stmt [62471,62559]
expr_stmt [62522,62610]
===
match
---
name: orm_dag [75771,75778]
name: orm_dag [75822,75829]
===
match
---
name: task_id [80511,80518]
name: task_id [80562,80569]
===
match
---
trailer [82759,82783]
trailer [82810,82834]
===
match
---
operator: + [54169,54170]
operator: + [54220,54221]
===
match
---
trailer [95745,95750]
trailer [95796,95801]
===
match
---
name: dp [64210,64212]
name: dp [64261,64263]
===
match
---
name: utcnow [63570,63576]
name: utcnow [63621,63627]
===
match
---
param [3186,3194]
param [3186,3194]
===
match
---
name: set_edge_info [82829,82842]
name: set_edge_info [82880,82893]
===
match
---
operator: , [72499,72500]
operator: , [72550,72551]
===
match
---
trailer [20034,20063]
trailer [20034,20063]
===
match
---
operator: = [52890,52891]
operator: = [52941,52942]
===
match
---
classdef [83461,92137]
classdef [83512,92188]
===
match
---
name: ImportError [2830,2841]
name: ImportError [2830,2841]
===
match
---
name: job [69639,69642]
name: job [69690,69693]
===
match
---
name: task_id [49112,49119]
name: task_id [49112,49119]
===
match
---
name: t [64660,64661]
name: t [64711,64712]
===
match
---
name: tis [41602,41605]
name: tis [41602,41605]
===
match
---
simple_stmt [19062,19219]
simple_stmt [19062,19219]
===
match
---
name: other [16184,16189]
name: other [16184,16189]
===
match
---
operator: , [35657,35658]
operator: , [35657,35658]
===
match
---
simple_stmt [61491,61536]
simple_stmt [61542,61587]
===
match
---
simple_stmt [50587,50630]
simple_stmt [50638,50681]
===
match
---
name: FileSystemLoader [39654,39670]
name: FileSystemLoader [39654,39670]
===
match
---
string: "Cancelled, nothing was cleared." [57535,57568]
string: "Cancelled, nothing was cleared." [57586,57619]
===
match
---
name: DagModel [79421,79429]
name: DagModel [79472,79480]
===
match
---
import_from [2665,2711]
import_from [2665,2711]
===
match
---
atom_expr [30758,30785]
atom_expr [30758,30785]
===
match
---
trailer [80491,80497]
trailer [80542,80548]
===
match
---
name: helpers [2324,2331]
name: helpers [2324,2331]
===
match
---
trailer [76339,76352]
trailer [76390,76403]
===
match
---
name: property [29122,29130]
name: property [29122,29130]
===
match
---
trailer [81481,81483]
trailer [81532,81534]
===
match
---
return_stmt [30518,30554]
return_stmt [30518,30554]
===
match
---
atom_expr [13047,13064]
atom_expr [13047,13064]
===
match
---
name: utils [2678,2683]
name: utils [2678,2683]
===
match
---
operator: = [49376,49377]
operator: = [49427,49428]
===
match
---
param [45363,45390]
param [45363,45390]
===
match
---
operator: ** [58610,58612]
operator: ** [58661,58663]
===
match
---
name: session [2428,2435]
name: session [2428,2435]
===
match
---
name: filter [50400,50406]
name: filter [50451,50457]
===
match
---
atom_expr [63213,63236]
atom_expr [63264,63287]
===
match
---
string: "You are about to delete these {count} tasks:\n{ti_list}\n\nAre you sure? (yes/no): " [55010,55095]
string: "You are about to delete these {count} tasks:\n{ti_list}\n\nAre you sure? (yes/no): " [55061,55146]
===
match
---
argument [16373,16443]
argument [16373,16443]
===
match
---
name: self [12734,12738]
name: self [12734,12738]
===
match
---
arglist [86904,86991]
arglist [86955,87042]
===
match
---
operator: , [87955,87956]
operator: , [88006,88007]
===
match
---
name: external_trigger [36492,36508]
name: external_trigger [36492,36508]
===
match
---
simple_stmt [56167,56571]
simple_stmt [56218,56622]
===
match
---
operator: += [60554,60556]
operator: += [60605,60607]
===
match
---
operator: @ [29494,29495]
operator: @ [29494,29495]
===
match
---
atom_expr [24056,24078]
atom_expr [24056,24078]
===
match
---
name: self [39287,39291]
name: self [39287,39291]
===
match
---
name: end_date [65836,65844]
name: end_date [65887,65895]
===
match
---
decorator [79850,79864]
decorator [79901,79915]
===
match
---
suite [73700,73720]
suite [73751,73771]
===
match
---
name: str [70040,70043]
name: str [70091,70094]
===
match
---
simple_stmt [77653,77669]
simple_stmt [77704,77720]
===
match
---
simple_stmt [21991,22064]
simple_stmt [21991,22064]
===
match
---
operator: , [86932,86933]
operator: , [86983,86984]
===
match
---
trailer [14060,14065]
trailer [14060,14065]
===
match
---
atom_expr [57794,57802]
atom_expr [57845,57853]
===
match
---
name: in_ [87477,87480]
name: in_ [87528,87531]
===
match
---
simple_stmt [17080,17116]
simple_stmt [17080,17116]
===
match
---
simple_stmt [33982,34008]
simple_stmt [33982,34008]
===
match
---
name: airflow [1551,1558]
name: airflow [1551,1558]
===
match
---
simple_stmt [32308,32500]
simple_stmt [32308,32500]
===
match
---
operator: = [55477,55478]
operator: = [55528,55529]
===
match
---
if_stmt [39826,39928]
if_stmt [39826,39928]
===
match
---
trailer [86590,86596]
trailer [86641,86647]
===
match
---
name: _task_group [59935,59946]
name: _task_group [59986,59997]
===
match
---
string: 'fetch' [45928,45935]
string: 'fetch' [45928,45935]
===
match
---
trailer [24800,24818]
trailer [24800,24818]
===
match
---
name: next_run_date [25666,25679]
name: next_run_date [25666,25679]
===
match
---
atom [60740,60875]
atom [60791,60926]
===
match
---
name: self [88020,88024]
name: self [88071,88075]
===
match
---
param [32854,32858]
param [32854,32858]
===
match
---
trailer [61277,61298]
trailer [61328,61349]
===
match
---
operator: , [69940,69941]
operator: , [69991,69992]
===
match
---
name: now [19307,19310]
name: now [19307,19310]
===
match
---
argument [45104,45129]
argument [45104,45129]
===
match
---
comparison [64015,64045]
comparison [64066,64096]
===
match
---
simple_stmt [16453,16466]
simple_stmt [16453,16466]
===
match
---
atom_expr [94310,94349]
atom_expr [94361,94400]
===
match
---
trailer [50454,50470]
trailer [50505,50521]
===
match
---
operator: , [40432,40433]
operator: , [40432,40433]
===
match
---
name: cls [95632,95635]
name: cls [95683,95686]
===
match
---
name: self [87914,87918]
name: self [87965,87969]
===
match
---
simple_stmt [51496,51511]
simple_stmt [51547,51562]
===
match
---
decorator [31569,31579]
decorator [31569,31579]
===
match
---
trailer [50239,50272]
trailer [50290,50323]
===
match
---
name: session [72544,72551]
name: session [72595,72602]
===
match
---
name: bulk_sync_to_db [72795,72810]
name: bulk_sync_to_db [72846,72861]
===
match
---
return_stmt [28365,28381]
return_stmt [28365,28381]
===
match
---
name: self [15626,15630]
name: self [15626,15630]
===
match
---
name: dag_sig [92615,92622]
name: dag_sig [92666,92673]
===
match
---
atom_expr [17923,17965]
atom_expr [17923,17965]
===
match
---
if_stmt [74408,74516]
if_stmt [74459,74567]
===
match
---
simple_stmt [877,894]
simple_stmt [877,894]
===
match
---
name: on_success_callback [15121,15140]
name: on_success_callback [15121,15140]
===
match
---
operator: , [93943,93944]
operator: , [93994,93995]
===
match
---
import_from [2585,2641]
import_from [2585,2641]
===
match
---
name: relativedelta [2963,2976]
name: relativedelta [2963,2976]
===
match
---
name: provide_session [78371,78386]
name: provide_session [78422,78437]
===
match
---
name: self [29344,29348]
name: self [29344,29348]
===
match
---
trailer [64340,64347]
trailer [64391,64398]
===
match
---
suite [86517,86599]
suite [86568,86650]
===
match
---
operator: = [20564,20565]
operator: = [20564,20565]
===
match
---
name: func [31975,31979]
name: func [31975,31979]
===
match
---
name: args [69861,69865]
name: args [69912,69916]
===
match
---
name: DagModel [79451,79459]
name: DagModel [79502,79510]
===
match
---
if_stmt [16771,16905]
if_stmt [16771,16905]
===
match
---
expr_stmt [64063,64072]
expr_stmt [64114,64123]
===
match
---
name: states [79939,79945]
name: states [79990,79996]
===
match
---
trailer [28554,28561]
trailer [28554,28561]
===
match
---
if_stmt [20156,20597]
if_stmt [20156,20597]
===
match
---
param [39287,39291]
param [39287,39291]
===
match
---
trailer [40991,40995]
trailer [40991,40995]
===
match
---
name: default_view [87919,87931]
name: default_view [87970,87982]
===
match
---
name: qry [81158,81161]
name: qry [81209,81212]
===
match
---
arglist [36961,37030]
arglist [36961,37030]
===
match
---
operator: , [41228,41229]
operator: , [41228,41229]
===
match
---
argument [53908,53931]
argument [53959,53982]
===
match
---
name: Integer [1372,1379]
name: Integer [1372,1379]
===
match
---
atom_expr [77442,77500]
atom_expr [77493,77551]
===
match
---
name: tasks [66504,66509]
name: tasks [66555,66560]
===
match
---
operator: , [17319,17320]
operator: , [17319,17320]
===
match
---
atom_expr [52464,52729]
atom_expr [52515,52780]
===
match
---
param [31769,31781]
param [31769,31781]
===
match
---
trailer [86090,86117]
trailer [86141,86168]
===
match
---
name: Session [1501,1508]
name: Session [1501,1508]
===
match
---
parameters [63473,63479]
parameters [63524,63530]
===
match
---
name: pickle_info [63462,63473]
name: pickle_info [63513,63524]
===
match
---
name: start_date [65557,65567]
name: start_date [65608,65618]
===
match
---
atom_expr [59785,59799]
atom_expr [59836,59850]
===
match
---
operator: , [57936,57937]
operator: , [57987,57988]
===
match
---
atom_expr [78329,78346]
atom_expr [78380,78397]
===
match
---
name: only_running [53709,53721]
name: only_running [53760,53772]
===
match
---
name: classmethod [81241,81252]
name: classmethod [81292,81303]
===
match
---
name: isinstance [13825,13835]
name: isinstance [13825,13835]
===
match
---
arglist [32335,32489]
arglist [32335,32489]
===
match
---
param [11398,11431]
param [11398,11431]
===
match
---
atom_expr [19464,19474]
atom_expr [19464,19474]
===
match
---
name: include_subdags [50642,50657]
name: include_subdags [50693,50708]
===
match
---
operator: , [40981,40982]
operator: , [40981,40982]
===
match
---
trailer [41448,41455]
trailer [41448,41455]
===
match
---
trailer [14417,14431]
trailer [14417,14431]
===
match
---
name: provide_session [34014,34029]
name: provide_session [34014,34029]
===
match
---
operator: , [53240,53241]
operator: , [53291,53292]
===
match
---
operator: = [58784,58785]
operator: = [58835,58836]
===
match
---
trailer [89768,89778]
trailer [89819,89829]
===
match
---
name: Union [1184,1189]
name: Union [1184,1189]
===
match
---
comparison [74995,75037]
comparison [75046,75088]
===
match
---
arith_expr [64590,64619]
arith_expr [64641,64670]
===
match
---
simple_stmt [56660,56681]
simple_stmt [56711,56732]
===
match
---
expr_stmt [56117,56129]
expr_stmt [56168,56180]
===
match
---
operator: == [25905,25907]
operator: == [25905,25907]
===
match
---
atom_expr [95256,95323]
atom_expr [95307,95374]
===
match
---
simple_stmt [39234,39261]
simple_stmt [39234,39261]
===
match
---
name: dag [60794,60797]
name: dag [60845,60848]
===
match
---
trailer [33955,33973]
trailer [33955,33973]
===
match
---
operator: , [82870,82871]
operator: , [82921,82922]
===
match
---
name: self [41216,41220]
name: self [41216,41220]
===
match
---
atom_expr [79451,79476]
atom_expr [79502,79527]
===
match
---
suite [14754,14937]
suite [14754,14937]
===
match
---
atom_expr [32057,32065]
atom_expr [32057,32065]
===
match
---
operator: { [60782,60783]
operator: { [60833,60834]
===
match
---
trailer [91572,91593]
trailer [91623,91644]
===
match
---
arglist [93475,93520]
arglist [93526,93571]
===
match
---
trailer [88542,88579]
trailer [88593,88630]
===
match
---
name: timezone [13707,13715]
name: timezone [13707,13715]
===
match
---
simple_stmt [856,866]
simple_stmt [856,866]
===
match
---
trailer [18716,18721]
trailer [18716,18721]
===
match
---
name: now [24657,24660]
name: now [24657,24660]
===
match
---
arglist [18371,18576]
arglist [18371,18576]
===
match
---
trailer [88645,88729]
trailer [88696,88780]
===
match
---
atom_expr [58107,58132]
atom_expr [58158,58183]
===
match
---
name: self [41375,41379]
name: self [41375,41379]
===
match
---
name: tuple [43644,43649]
name: tuple [43644,43649]
===
match
---
if_stmt [39460,39540]
if_stmt [39460,39540]
===
match
---
suite [25609,25681]
suite [25609,25681]
===
match
---
name: activate_dag_runs [55342,55359]
name: activate_dag_runs [55393,55410]
===
match
---
name: factory [92761,92768]
name: factory [92812,92819]
===
match
---
comparison [36961,36989]
comparison [36961,36989]
===
match
---
trailer [29016,29024]
trailer [29016,29024]
===
match
---
name: get_concurrency_reached [32520,32543]
name: get_concurrency_reached [32520,32543]
===
match
---
operator: = [30999,31000]
operator: = [30999,31000]
===
match
---
name: __name__ [50931,50939]
name: __name__ [50982,50990]
===
match
---
name: filter [78810,78816]
name: filter [78861,78867]
===
match
---
name: task_ids_or_regex [59983,60000]
name: task_ids_or_regex [60034,60051]
===
match
---
name: validate_key [11937,11949]
name: validate_key [11937,11949]
===
match
---
atom_expr [42771,42791]
atom_expr [42771,42791]
===
match
---
atom_expr [53419,54446]
atom_expr [53470,54497]
===
match
---
suite [44662,44748]
suite [44662,44748]
===
match
---
name: executor [68918,68926]
name: executor [68969,68977]
===
match
---
trailer [89316,89320]
trailer [89367,89371]
===
match
---
name: run [72148,72151]
name: run [72199,72202]
===
match
---
operator: = [56372,56373]
operator: = [56423,56424]
===
match
---
name: timedelta [10716,10725]
name: timedelta [10716,10725]
===
match
---
name: log [35332,35335]
name: log [35332,35335]
===
match
---
name: query [3453,3458]
name: query [3453,3458]
===
match
---
name: node [44943,44947]
name: node [44943,44947]
===
match
---
funcdef [92139,94288]
funcdef [92190,94339]
===
match
---
simple_stmt [18190,18274]
simple_stmt [18190,18274]
===
match
---
name: include_parentdag [49796,49813]
name: include_parentdag [49847,49864]
===
match
---
name: roots [64751,64756]
name: roots [64802,64807]
===
match
---
atom_expr [65896,65909]
atom_expr [65947,65960]
===
match
---
name: only_failed [50365,50376]
name: only_failed [50416,50427]
===
match
---
trailer [37985,37991]
trailer [37985,37991]
===
match
---
name: get_downstream [64770,64784]
name: get_downstream [64821,64835]
===
match
---
atom_expr [94320,94348]
atom_expr [94371,94399]
===
match
---
and_test [71720,71747]
and_test [71771,71798]
===
match
---
trailer [21729,21738]
trailer [21729,21738]
===
match
---
trailer [19741,19770]
trailer [19741,19770]
===
match
---
name: tis [54963,54966]
name: tis [55014,55017]
===
match
---
trailer [17345,17369]
trailer [17345,17369]
===
match
---
trailer [86708,86714]
trailer [86759,86765]
===
match
---
atom_expr [76111,76128]
atom_expr [76162,76179]
===
match
---
param [19556,19560]
param [19556,19560]
===
match
---
name: execution_date [35768,35782]
name: execution_date [35768,35782]
===
match
---
trailer [93203,93218]
trailer [93254,93269]
===
match
---
trailer [81232,81234]
trailer [81283,81285]
===
match
---
simple_stmt [58015,58069]
simple_stmt [58066,58120]
===
match
---
suite [88876,89990]
suite [88927,90041]
===
match
---
name: query [52472,52477]
name: query [52523,52528]
===
match
---
name: warnings [32308,32316]
name: warnings [32308,32316]
===
match
---
name: filter [41848,41854]
name: filter [41848,41854]
===
match
---
atom_expr [11112,11144]
atom_expr [11112,11144]
===
match
---
atom_expr [20761,20794]
atom_expr [20761,20794]
===
match
---
simple_stmt [87329,87520]
simple_stmt [87380,87571]
===
match
---
operator: , [21041,21042]
operator: , [21041,21042]
===
match
---
parameters [58643,58835]
parameters [58694,58886]
===
match
---
operator: = [45927,45928]
operator: = [45927,45928]
===
match
---
name: dag_by_ids [74369,74379]
name: dag_by_ids [74420,74430]
===
match
---
trailer [63712,63719]
trailer [63763,63770]
===
match
---
atom_expr [64034,64045]
atom_expr [64085,64096]
===
match
---
name: self [57732,57736]
name: self [57783,57787]
===
match
---
name: get_last_dagrun [86787,86802]
name: get_last_dagrun [86838,86853]
===
match
---
simple_stmt [76546,76639]
simple_stmt [76597,76690]
===
match
---
not_test [71764,71800]
not_test [71815,71851]
===
match
---
string: 'TB' [3086,3090]
string: 'TB' [3086,3090]
===
match
---
parameters [82842,82916]
parameters [82893,82967]
===
match
---
operator: { [56926,56927]
operator: { [56977,56978]
===
match
---
name: task_id [61527,61534]
name: task_id [61578,61585]
===
match
---
expr_stmt [63978,64054]
expr_stmt [64029,64105]
===
match
---
name: dag_id [86495,86501]
name: dag_id [86546,86552]
===
match
---
simple_stmt [84986,85016]
simple_stmt [85037,85067]
===
match
---
name: cls [86658,86661]
name: cls [86709,86712]
===
match
---
simple_stmt [60145,60219]
simple_stmt [60196,60270]
===
match
---
operator: ~ [78817,78818]
operator: ~ [78868,78869]
===
match
---
simple_stmt [15897,15952]
simple_stmt [15897,15952]
===
match
---
name: upstream_task_id [82849,82865]
name: upstream_task_id [82900,82916]
===
match
---
operator: = [55513,55514]
operator: = [55564,55565]
===
match
---
operator: = [18219,18220]
operator: = [18219,18220]
===
match
---
string: 'has_on_success_callback' [82228,82253]
string: 'has_on_success_callback' [82279,82304]
===
match
---
parameters [39286,39292]
parameters [39286,39292]
===
match
---
name: question [54981,54989]
name: question [55032,55040]
===
match
---
and_test [64084,64105]
and_test [64135,64156]
===
match
---
name: using_end_date [27359,27373]
name: using_end_date [27359,27373]
===
match
---
name: self [87655,87659]
name: self [87706,87710]
===
match
---
name: instance [21197,21205]
name: instance [21197,21205]
===
match
---
name: Index [1365,1370]
name: Index [1365,1370]
===
match
---
name: t [77090,77091]
name: t [77141,77142]
===
match
---
name: self [40244,40248]
name: self [40244,40248]
===
match
---
trailer [22184,22242]
trailer [22184,22242]
===
match
---
operator: = [54836,54837]
operator: = [54887,54888]
===
match
---
simple_stmt [83181,83249]
simple_stmt [83232,83300]
===
match
---
param [35892,35904]
param [35892,35904]
===
match
---
atom_expr [23941,23963]
atom_expr [23941,23963]
===
match
---
name: __init__ [85950,85958]
name: __init__ [86001,86009]
===
match
---
name: self [11805,11809]
name: self [11805,11809]
===
match
---
string: 'start_date' [13604,13616]
string: 'start_date' [13604,13616]
===
match
---
name: property [29896,29904]
name: property [29896,29904]
===
match
---
simple_stmt [79062,79374]
simple_stmt [79113,79425]
===
match
---
name: TYPE_CHECKING [1042,1055]
name: TYPE_CHECKING [1042,1055]
===
match
---
name: all [50839,50842]
name: all [50890,50893]
===
match
---
name: tags [77040,77044]
name: tags [77091,77095]
===
match
---
operator: = [19231,19232]
operator: = [19231,19232]
===
match
---
param [69936,69941]
param [69987,69992]
===
match
---
operator: = [55971,55972]
operator: = [56022,56023]
===
match
---
name: next_start [24533,24543]
name: next_start [24533,24543]
===
match
---
or_test [41359,41403]
or_test [41359,41403]
===
match
---
simple_stmt [35793,35813]
simple_stmt [35793,35813]
===
match
---
expr_stmt [95332,95362]
expr_stmt [95383,95413]
===
match
---
name: self [66498,66502]
name: self [66549,66553]
===
match
---
arglist [85881,85939]
arglist [85932,85990]
===
match
---
trailer [54945,54968]
trailer [54996,55019]
===
match
---
name: ValueError [71578,71588]
name: ValueError [71629,71639]
===
match
---
name: end_date [18937,18945]
name: end_date [18937,18945]
===
match
---
name: str [63103,63106]
name: str [63154,63157]
===
match
---
simple_stmt [42490,42553]
simple_stmt [42490,42553]
===
match
---
name: dag_bound_args [93359,93373]
name: dag_bound_args [93410,93424]
===
match
---
name: self [16147,16151]
name: self [16147,16151]
===
match
---
trailer [78949,78951]
trailer [79000,79002]
===
match
---
operator: = [56462,56463]
operator: = [56513,56514]
===
match
---
expr_stmt [24533,24574]
expr_stmt [24533,24574]
===
match
---
argument [55316,55324]
argument [55367,55375]
===
match
---
operator: == [38942,38944]
operator: == [38942,38944]
===
match
---
trailer [72572,72576]
trailer [72623,72627]
===
match
---
atom_expr [64770,64787]
atom_expr [64821,64838]
===
match
---
operator: , [1379,1380]
operator: , [1379,1380]
===
match
---
trailer [12783,12792]
trailer [12783,12792]
===
match
---
operator: = [14958,14959]
operator: = [14958,14959]
===
match
---
operator: = [50033,50034]
operator: = [50084,50085]
===
match
---
trailer [29099,29107]
trailer [29099,29107]
===
match
---
trailer [63576,63578]
trailer [63627,63629]
===
match
---
name: order_by [42254,42262]
name: order_by [42254,42262]
===
match
---
name: params [11199,11205]
name: params [11199,11205]
===
match
---
string: "Maximum recursion depth {} reached for {} {}. " [52021,52069]
string: "Maximum recursion depth {} reached for {} {}. " [52072,52120]
===
match
---
operator: } [59803,59804]
operator: } [59854,59855]
===
match
---
name: v [57828,57829]
name: v [57879,57880]
===
match
---
simple_stmt [79797,79816]
simple_stmt [79848,79867]
===
match
---
name: RUNNING [56070,56077]
name: RUNNING [56121,56128]
===
match
---
name: dag_id [41081,41087]
name: dag_id [41081,41087]
===
match
---
atom [63038,63069]
atom [63089,63120]
===
match
---
name: remove [77005,77011]
name: remove [77056,77062]
===
match
---
operator: = [56892,56893]
operator: = [56943,56944]
===
match
---
name: parent_dag [49198,49208]
name: parent_dag [49198,49208]
===
match
---
trailer [49490,49496]
trailer [49541,49547]
===
match
---
name: AirflowException [1616,1632]
name: AirflowException [1616,1632]
===
match
---
name: collections [915,926]
name: collections [915,926]
===
match
---
trailer [93490,93495]
trailer [93541,93546]
===
match
---
operator: , [81737,81738]
operator: , [81788,81789]
===
match
---
name: ORIENTATION_PRESETS [3057,3076]
name: ORIENTATION_PRESETS [3057,3076]
===
match
---
operator: = [13404,13405]
operator: = [13404,13405]
===
match
---
operator: @ [88777,88778]
operator: @ [88828,88829]
===
match
---
name: self [14945,14949]
name: self [14945,14949]
===
match
---
operator: , [69527,69528]
operator: , [69578,69579]
===
match
---
name: DagRun [37564,37570]
name: DagRun [37564,37570]
===
match
---
trailer [40875,40882]
trailer [40875,40882]
===
match
---
atom [11665,11667]
atom [11665,11667]
===
match
---
name: _task_group [66387,66398]
name: _task_group [66438,66449]
===
match
---
operator: , [66846,66847]
operator: , [66897,66898]
===
match
---
atom_expr [85149,85159]
atom_expr [85200,85210]
===
match
---
simple_stmt [68704,68754]
simple_stmt [68755,68805]
===
match
---
arglist [53203,53354]
arglist [53254,53405]
===
match
---
arglist [19981,20000]
arglist [19981,20000]
===
match
---
name: min [27462,27465]
name: min [27462,27465]
===
match
---
name: typing [1022,1028]
name: typing [1022,1028]
===
match
---
simple_stmt [64876,64917]
simple_stmt [64927,64968]
===
match
---
trailer [22897,22920]
trailer [22897,22920]
===
match
---
parameters [66735,67170]
parameters [66786,67221]
===
match
---
simple_stmt [82320,82351]
simple_stmt [82371,82402]
===
match
---
operator: = [15791,15792]
operator: = [15791,15792]
===
match
---
name: get [87940,87943]
name: get [87991,87994]
===
match
---
name: session [32596,32603]
name: session [32596,32603]
===
match
---
atom_expr [65531,65568]
atom_expr [65582,65619]
===
match
---
name: dag [48785,48788]
name: dag [48785,48788]
===
match
---
trailer [49101,49108]
trailer [49101,49108]
===
match
---
operator: } [56932,56933]
operator: } [56983,56984]
===
match
---
simple_stmt [94273,94288]
simple_stmt [94324,94339]
===
match
---
trailer [38249,38254]
trailer [38249,38254]
===
match
---
and_test [91606,91671]
and_test [91657,91722]
===
match
---
atom_expr [41440,41457]
atom_expr [41440,41457]
===
match
---
trailer [60755,60763]
trailer [60806,60814]
===
match
---
name: dag_args [92696,92704]
name: dag_args [92747,92755]
===
match
---
expr_stmt [19256,19311]
expr_stmt [19256,19311]
===
match
---
simple_stmt [78935,78952]
simple_stmt [78986,79003]
===
match
---
trailer [12738,12751]
trailer [12738,12751]
===
match
---
name: self [13390,13394]
name: self [13390,13394]
===
match
---
trailer [35271,35280]
trailer [35271,35280]
===
match
---
name: context [35272,35279]
name: context [35272,35279]
===
match
---
trailer [57793,57803]
trailer [57844,57854]
===
match
---
atom_expr [79703,79735]
atom_expr [79754,79786]
===
match
---
operator: , [30108,30109]
operator: , [30108,30109]
===
match
---
suite [40840,41005]
suite [40840,41005]
===
match
---
argument [83677,83693]
argument [83728,83744]
===
match
---
name: append [48931,48937]
name: append [48931,48937]
===
match
---
operator: , [57426,57427]
operator: , [57477,57478]
===
match
---
if_stmt [77402,77501]
if_stmt [77453,77552]
===
match
---
operator: = [44843,44844]
operator: = [44843,44844]
===
match
---
name: states [80792,80798]
name: states [80843,80849]
===
match
---
operator: = [69163,69164]
operator: = [69214,69215]
===
match
---
comp_if [80955,80963]
comp_if [81006,81014]
===
match
---
fstring_string: You are about to delete these  [56896,56926]
fstring_string: You are about to delete these  [56947,56977]
===
match
---
decorated [86762,87002]
decorated [86813,87053]
===
match
---
simple_stmt [35744,35784]
simple_stmt [35744,35784]
===
match
---
suite [66089,66192]
suite [66140,66243]
===
match
---
string: """         Returns the number of task instances in the given DAG.          :param session: ORM session         :param dag_id: ID of the DAG to get the task concurrency of         :type dag_id: unicode         :param task_ids: A list of valid task IDs for the given DAG         :type task_ids: list[unicode]         :param states: A list of states to filter by if supplied         :type states: list[state]         :return: The number of running tasks         :rtype: int         """ [79975,80458]
string: """         Returns the number of task instances in the given DAG.          :param session: ORM session         :param dag_id: ID of the DAG to get the task concurrency of         :type dag_id: unicode         :param task_ids: A list of valid task IDs for the given DAG         :type task_ids: list[unicode]         :param states: A list of states to filter by if supplied         :type states: list[state]         :return: The number of running tasks         :rtype: int         """ [80026,80509]
===
match
---
name: self [24796,24800]
name: self [24796,24800]
===
match
---
trailer [74824,74830]
trailer [74875,74881]
===
match
---
name: classmethod [55787,55798]
name: classmethod [55838,55849]
===
match
---
atom_expr [20274,20297]
atom_expr [20274,20297]
===
match
---
operator: = [69559,69560]
operator: = [69610,69611]
===
match
---
name: pickle_id [64396,64405]
name: pickle_id [64447,64456]
===
match
---
simple_stmt [23190,23265]
simple_stmt [23190,23265]
===
match
---
fstring_start: f" [63424,63426]
fstring_start: f" [63475,63477]
===
match
---
name: other [16551,16556]
name: other [16551,16556]
===
match
---
expr_stmt [74309,74350]
expr_stmt [74360,74401]
===
match
---
name: creating_job_id [70304,70319]
name: creating_job_id [70355,70370]
===
match
---
operator: , [72454,72455]
operator: , [72505,72506]
===
match
---
return_stmt [73134,73176]
return_stmt [73185,73227]
===
match
---
operator: , [82378,82379]
operator: , [82429,82430]
===
match
---
trailer [65915,65924]
trailer [65966,65975]
===
match
---
name: Text [85070,85074]
name: Text [85121,85125]
===
match
---
number: 0 [51558,51559]
number: 0 [51609,51610]
===
match
---
trailer [87918,87931]
trailer [87969,87982]
===
match
---
atom_expr [84924,84944]
atom_expr [84975,84995]
===
match
---
param [66498,66503]
param [66549,66554]
===
match
---
name: min_task_end_date [26578,26595]
name: min_task_end_date [26578,26595]
===
match
---
atom_expr [72569,72576]
atom_expr [72620,72627]
===
match
---
name: dttm [28075,28079]
name: dttm [28075,28079]
===
match
---
name: next_run_date [26712,26725]
name: next_run_date [26712,26725]
===
match
---
name: end_date [18853,18861]
name: end_date [18853,18861]
===
match
---
trailer [27775,27793]
trailer [27775,27793]
===
match
---
name: filter [41480,41486]
name: filter [41480,41486]
===
match
---
name: self [15412,15416]
name: self [15412,15416]
===
match
---
atom_expr [86875,87001]
atom_expr [86926,87052]
===
match
---
atom_expr [52956,52966]
atom_expr [53007,53017]
===
match
---
name: DagModel [32744,32752]
name: DagModel [32744,32752]
===
match
---
suite [17857,17882]
suite [17857,17882]
===
match
---
dotted_name [1471,1493]
dotted_name [1471,1493]
===
match
---
name: dag_id [86909,86915]
name: dag_id [86960,86966]
===
match
---
operator: = [15830,15831]
operator: = [15830,15831]
===
match
---
operator: = [74367,74368]
operator: = [74418,74419]
===
match
---
simple_stmt [52925,52968]
simple_stmt [52976,53019]
===
match
---
string: '@once' [24287,24294]
string: '@once' [24287,24294]
===
match
---
name: __init__ [9931,9939]
name: __init__ [9931,9939]
===
match
---
string: "DAG" [72833,72838]
string: "DAG" [72884,72889]
===
match
---
parameters [32184,32190]
parameters [32184,32190]
===
match
---
name: conf [10895,10899]
name: conf [10895,10899]
===
match
---
argument [53516,53545]
argument [53567,53596]
===
match
---
name: ExternalTaskMarker [52275,52293]
name: ExternalTaskMarker [52326,52344]
===
match
---
name: TaskInstance [41855,41867]
name: TaskInstance [41855,41867]
===
match
---
name: tii [52759,52762]
name: tii [52810,52813]
===
match
---
atom_expr [19917,19940]
atom_expr [19917,19940]
===
match
---
parameters [23296,23359]
parameters [23296,23359]
===
match
---
operator: = [69455,69456]
operator: = [69506,69507]
===
match
---
name: get_current_dag [95713,95728]
name: get_current_dag [95764,95779]
===
match
---
name: str [12365,12368]
name: str [12365,12368]
===
match
---
annassign [95123,95139]
annassign [95174,95190]
===
match
---
simple_stmt [63206,63237]
simple_stmt [63257,63288]
===
match
---
name: run_type [71779,71787]
name: run_type [71830,71838]
===
match
---
trailer [30534,30544]
trailer [30534,30544]
===
match
---
operator: = [13560,13561]
operator: = [13560,13561]
===
match
---
name: jinja2 [39943,39949]
name: jinja2 [39943,39949]
===
match
---
simple_stmt [22252,22610]
simple_stmt [22252,22610]
===
match
---
if_stmt [50362,50473]
if_stmt [50413,50524]
===
match
---
trailer [83896,83935]
trailer [83947,83986]
===
match
---
name: dict [70173,70177]
name: dict [70224,70228]
===
match
---
trailer [13196,13208]
trailer [13196,13208]
===
match
---
operator: = [58822,58823]
operator: = [58873,58874]
===
match
---
atom_expr [64124,64194]
atom_expr [64175,64245]
===
match
---
operator: = [95657,95658]
operator: = [95708,95709]
===
match
---
trailer [92681,92694]
trailer [92732,92745]
===
match
---
string: 'dag_default_view' [78268,78286]
string: 'dag_default_view' [78319,78337]
===
match
---
operator: = [46052,46053]
operator: = [46052,46053]
===
match
---
name: dag_id [14178,14184]
name: dag_id [14178,14184]
===
match
---
trailer [66422,66430]
trailer [66473,66481]
===
match
---
funcdef [83414,83459]
funcdef [83465,83510]
===
match
---
param [58291,58299]
param [58342,58350]
===
match
---
operator: , [12661,12662]
operator: , [12661,12662]
===
match
---
operator: = [69023,69024]
operator: = [69074,69075]
===
match
---
name: stacklevel [33125,33135]
name: stacklevel [33125,33135]
===
match
---
name: is_active [89551,89560]
name: is_active [89602,89611]
===
match
---
trailer [78293,78295]
trailer [78344,78346]
===
match
---
return_stmt [86694,86756]
return_stmt [86745,86807]
===
match
---
name: dagcode [1828,1835]
name: dagcode [1828,1835]
===
match
---
atom_expr [21008,21041]
atom_expr [21008,21041]
===
match
---
atom_expr [74488,74515]
atom_expr [74539,74566]
===
match
---
trailer [79723,79733]
trailer [79774,79784]
===
match
---
suite [13099,13319]
suite [13099,13319]
===
match
---
operator: , [1178,1179]
operator: , [1178,1179]
===
match
---
operator: , [69141,69142]
operator: , [69192,69193]
===
match
---
operator: , [85787,85788]
operator: , [85838,85839]
===
match
---
simple_stmt [86060,86118]
simple_stmt [86111,86169]
===
match
---
operator: } [14897,14898]
operator: } [14897,14898]
===
match
---
trailer [76553,76581]
trailer [76604,76632]
===
match
---
name: classmethod [86605,86616]
name: classmethod [86656,86667]
===
match
---
argument [92695,92704]
argument [92746,92755]
===
match
---
arglist [59983,60020]
arglist [60034,60071]
===
match
---
atom_expr [65513,65528]
atom_expr [65564,65579]
===
match
---
name: cls [95256,95259]
name: cls [95307,95310]
===
match
---
name: dttm [20334,20338]
name: dttm [20334,20338]
===
match
---
name: visited_external_tis [50964,50984]
name: visited_external_tis [51015,51035]
===
match
---
operator: , [55629,55630]
operator: , [55680,55681]
===
match
---
atom_expr [37978,38070]
atom_expr [37978,38070]
===
match
---
atom_expr [76898,76910]
atom_expr [76949,76961]
===
match
---
name: dag [74363,74366]
name: dag [74414,74417]
===
match
---
name: backref [1432,1439]
name: backref [1432,1439]
===
match
---
operator: , [54249,54250]
operator: , [54300,54301]
===
match
---
trailer [73992,73999]
trailer [74043,74050]
===
match
---
name: query [74074,74079]
name: query [74125,74130]
===
match
---
parameters [9939,11437]
parameters [9939,11437]
===
match
---
name: start_date [12502,12512]
name: start_date [12502,12512]
===
match
---
operator: @ [45296,45297]
operator: @ [45296,45297]
===
match
---
name: get_edge_info [82360,82373]
name: get_edge_info [82411,82424]
===
match
---
argument [60468,60481]
argument [60519,60532]
===
match
---
name: run_type [71653,71661]
name: run_type [71704,71712]
===
match
---
suite [49010,49140]
suite [49010,49140]
===
match
---
name: executor [69014,69022]
name: executor [69065,69073]
===
match
---
operator: , [91091,91092]
operator: , [91142,91143]
===
match
---
operator: , [72262,72263]
operator: , [72313,72314]
===
match
---
string: 'params' [11873,11881]
string: 'params' [11873,11881]
===
match
---
atom_expr [92016,92045]
atom_expr [92067,92096]
===
match
---
name: t [60058,60059]
name: t [60109,60110]
===
match
---
operator: { [14621,14622]
operator: { [14621,14622]
===
match
---
simple_stmt [21824,21866]
simple_stmt [21824,21866]
===
match
---
name: user_defined_filters [58084,58104]
name: user_defined_filters [58135,58155]
===
match
---
param [87655,87659]
param [87706,87710]
===
match
---
simple_stmt [63978,64055]
simple_stmt [64029,64106]
===
match
---
trailer [58221,58226]
trailer [58272,58277]
===
match
---
testlist_comp [43469,43487]
testlist_comp [43469,43487]
===
match
---
atom_expr [15438,15461]
atom_expr [15438,15461]
===
match
---
name: schedule_interval [24680,24697]
name: schedule_interval [24680,24697]
===
match
---
comparison [63321,63345]
comparison [63372,63396]
===
match
---
name: states [81198,81204]
name: states [81249,81255]
===
match
---
name: max_recursion_depth [51857,51876]
name: max_recursion_depth [51908,51927]
===
match
---
dotted_name [43273,43297]
dotted_name [43273,43297]
===
match
---
number: 0 [54863,54864]
number: 0 [54914,54915]
===
match
---
name: count [56713,56718]
name: count [56764,56769]
===
match
---
name: TI [48877,48879]
name: TI [48877,48879]
===
match
---
name: only_failed [56274,56285]
name: only_failed [56325,56336]
===
match
---
string: 'LR' [3080,3084]
string: 'LR' [3080,3084]
===
match
---
expr_stmt [80467,80581]
expr_stmt [80518,80632]
===
match
---
simple_stmt [66520,66664]
simple_stmt [66571,66715]
===
match
---
name: t [54958,54959]
name: t [55009,55010]
===
match
---
if_stmt [50196,50273]
if_stmt [50247,50324]
===
match
---
name: DR [3421,3423]
name: DR [3421,3423]
===
match
---
simple_stmt [37526,37786]
simple_stmt [37526,37786]
===
match
---
dictorsetmaker [39637,39807]
dictorsetmaker [39637,39807]
===
match
---
argument [57257,57282]
argument [57308,57333]
===
match
---
name: property [32148,32156]
name: property [32148,32156]
===
match
---
sync_comp_for [42741,42791]
sync_comp_for [42741,42791]
===
match
---
param [67091,67101]
param [67142,67152]
===
match
---
name: __serialized_fields [81383,81402]
name: __serialized_fields [81434,81453]
===
match
---
trailer [62759,62781]
trailer [62810,62832]
===
match
---
trailer [13225,13318]
trailer [13225,13318]
===
match
---
if_stmt [57868,58006]
if_stmt [57919,58057]
===
match
---
name: DagModel [64015,64023]
name: DagModel [64066,64074]
===
match
---
trailer [42295,42297]
trailer [42295,42297]
===
match
---
atom_expr [15832,15888]
atom_expr [15832,15888]
===
match
---
simple_stmt [30850,30874]
simple_stmt [30850,30874]
===
match
---
with_item [93471,93532]
with_item [93522,93583]
===
match
---
simple_stmt [31516,31564]
simple_stmt [31516,31564]
===
match
---
trailer [90695,90699]
trailer [90746,90750]
===
match
---
name: back [12323,12327]
name: back [12323,12327]
===
match
---
arglist [57971,58004]
arglist [58022,58055]
===
match
---
simple_stmt [50823,50845]
simple_stmt [50874,50896]
===
match
---
name: ignore_task_deps [69312,69328]
name: ignore_task_deps [69363,69379]
===
match
---
name: active_dag_ids [78838,78852]
name: active_dag_ids [78889,78903]
===
match
---
atom_expr [41476,41527]
atom_expr [41476,41527]
===
match
---
name: max_active_runs [91656,91671]
name: max_active_runs [91707,91722]
===
match
---
suite [3766,83155]
suite [3766,83206]
===
match
---
trailer [54816,54821]
trailer [54867,54872]
===
match
---
trailer [62840,62853]
trailer [62891,62904]
===
match
---
name: dag_model [89541,89550]
name: dag_model [89592,89601]
===
match
---
name: Optional [10707,10715]
name: Optional [10707,10715]
===
match
---
name: node [44643,44647]
name: node [44643,44647]
===
match
---
import_from [1896,1942]
import_from [1896,1942]
===
match
---
expr_stmt [95093,95139]
expr_stmt [95144,95190]
===
match
---
trailer [50232,50239]
trailer [50283,50290]
===
match
---
name: date_last_automated_dagrun [22113,22139]
name: date_last_automated_dagrun [22113,22139]
===
match
---
operator: = [66769,66770]
operator: = [66820,66821]
===
match
---
operator: = [79932,79933]
operator: = [79983,79984]
===
match
---
trailer [50410,50471]
trailer [50461,50522]
===
match
---
name: dttm [28398,28402]
name: dttm [28398,28402]
===
match
---
suite [16558,16601]
suite [16558,16601]
===
match
---
simple_stmt [946,987]
simple_stmt [946,987]
===
match
---
trailer [25863,25874]
trailer [25863,25874]
===
match
---
trailer [45884,45936]
trailer [45884,45936]
===
match
---
name: DagModel [74319,74327]
name: DagModel [74370,74378]
===
match
---
and_test [65952,66027]
and_test [66003,66078]
===
match
---
trailer [48895,48904]
trailer [48895,48904]
===
match
---
exprlist [87565,87579]
exprlist [87616,87630]
===
match
---
simple_stmt [65142,65209]
simple_stmt [65193,65260]
===
match
---
name: get_dag [52948,52955]
name: get_dag [52999,53006]
===
match
---
trailer [10899,10903]
trailer [10899,10903]
===
match
---
simple_stmt [42306,42317]
simple_stmt [42306,42317]
===
match
---
sync_comp_for [56852,56868]
sync_comp_for [56903,56919]
===
match
---
name: DagModel [63998,64006]
name: DagModel [64049,64057]
===
match
---
trailer [62167,62186]
trailer [62218,62237]
===
match
---
atom_expr [95218,95242]
atom_expr [95269,95293]
===
match
---
name: upstream [60366,60374]
name: upstream [60417,60425]
===
match
---
trailer [32036,32043]
trailer [32036,32043]
===
match
---
atom_expr [94466,94489]
atom_expr [94517,94540]
===
match
---
name: filter [36954,36960]
name: filter [36954,36960]
===
match
---
trailer [55172,55180]
trailer [55223,55231]
===
match
---
trailer [25290,25313]
trailer [25290,25313]
===
match
---
trailer [91972,91988]
trailer [92023,92039]
===
match
---
name: self [24896,24900]
name: self [24896,24900]
===
match
---
trailer [52488,52729]
trailer [52539,52780]
===
match
---
name: task [51786,51790]
name: task [51837,51841]
===
match
---
name: start_date [25190,25200]
name: start_date [25190,25200]
===
match
---
name: type [16217,16221]
name: type [16217,16221]
===
match
---
name: user_defined_filters [40286,40306]
name: user_defined_filters [40286,40306]
===
match
---
trailer [76282,76299]
trailer [76333,76350]
===
match
---
funcdef [64537,64728]
funcdef [64588,64779]
===
match
---
operator: = [18959,18960]
operator: = [18959,18960]
===
match
---
operator: , [72192,72193]
operator: , [72243,72244]
===
match
---
name: intersection [62747,62759]
name: intersection [62798,62810]
===
match
---
atom_expr [45183,45254]
atom_expr [45183,45254]
===
match
---
trailer [71834,71897]
trailer [71885,71948]
===
match
---
operator: = [65890,65891]
operator: = [65941,65942]
===
match
---
name: hash_components [17098,17113]
name: hash_components [17098,17113]
===
match
---
operator: = [36611,36612]
operator: = [36611,36612]
===
match
---
suite [54913,55201]
suite [54964,55252]
===
match
---
decorated [73182,77758]
decorated [73233,77809]
===
match
---
trailer [74015,74019]
trailer [74066,74070]
===
match
---
argument [57212,57235]
argument [57263,57286]
===
match
---
name: self [29281,29285]
name: self [29281,29285]
===
match
---
name: _upgrade_outdated_dag_access_control [29670,29706]
name: _upgrade_outdated_dag_access_control [29670,29706]
===
match
---
name: self [14413,14417]
name: self [14413,14417]
===
match
---
name: task_id [48880,48887]
name: task_id [48880,48887]
===
match
---
simple_stmt [3693,3714]
simple_stmt [3693,3714]
===
match
---
tfpdef [10027,10072]
tfpdef [10027,10072]
===
match
---
name: Optional [14052,14060]
name: Optional [14052,14060]
===
match
---
trailer [90685,90695]
trailer [90736,90746]
===
match
---
if_stmt [26630,26696]
if_stmt [26630,26696]
===
match
---
name: cls [90765,90768]
name: cls [90816,90819]
===
match
---
name: serialized_dag [94420,94434]
name: serialized_dag [94471,94485]
===
match
---
atom_expr [86701,86756]
atom_expr [86752,86807]
===
match
---
simple_stmt [2305,2352]
simple_stmt [2305,2352]
===
match
---
param [88122,88127]
param [88173,88178]
===
match
---
suite [29634,29714]
suite [29634,29714]
===
match
---
operator: = [10529,10530]
operator: = [10529,10530]
===
match
---
trailer [12490,12499]
trailer [12490,12499]
===
match
---
name: verbose [67068,67075]
name: verbose [67119,67126]
===
match
---
operator: , [69242,69243]
operator: , [69293,69294]
===
match
---
name: UtcDateTime [85529,85540]
name: UtcDateTime [85580,85591]
===
match
---
name: dag_bag [46387,46394]
name: dag_bag [46387,46394]
===
match
---
expr_stmt [16051,16097]
expr_stmt [16051,16097]
===
match
---
name: t [60187,60188]
name: t [60238,60239]
===
match
---
comparison [24056,24089]
comparison [24056,24089]
===
match
---
expr_stmt [63489,63495]
expr_stmt [63540,63546]
===
match
---
name: dag_models [89285,89295]
name: dag_models [89336,89346]
===
match
---
expr_stmt [25251,25313]
expr_stmt [25251,25313]
===
match
---
name: dag [62934,62937]
name: dag [62985,62988]
===
match
---
name: task_id [61432,61439]
name: task_id [61483,61490]
===
match
---
decorator [86367,86377]
decorator [86418,86428]
===
match
---
name: airflow [2357,2364]
name: airflow [2357,2364]
===
match
---
atom_expr [24796,24830]
atom_expr [24796,24830]
===
match
---
expr_stmt [80615,80698]
expr_stmt [80666,80749]
===
match
---
comparison [16774,16789]
comparison [16774,16789]
===
match
---
name: matched_tasks [60145,60158]
name: matched_tasks [60196,60209]
===
match
---
comparison [86022,86046]
comparison [86073,86097]
===
match
---
trailer [78877,78887]
trailer [78928,78938]
===
match
---
sync_comp_for [43489,43511]
sync_comp_for [43489,43511]
===
match
---
simple_stmt [69770,69818]
simple_stmt [69821,69869]
===
match
---
name: end_date [66784,66792]
name: end_date [66835,66843]
===
match
---
simple_stmt [82810,82820]
simple_stmt [82861,82871]
===
match
---
param [11161,11190]
param [11161,11190]
===
match
---
name: dag [77036,77039]
name: dag [77087,77090]
===
match
---
expr_stmt [68874,68900]
expr_stmt [68925,68951]
===
match
---
operator: = [49418,49419]
operator: = [49469,49470]
===
match
---
name: env [40320,40323]
name: env [40320,40323]
===
match
---
name: LocalExecutor [68847,68860]
name: LocalExecutor [68898,68911]
===
match
---
trailer [48852,48859]
trailer [48852,48859]
===
match
---
atom_expr [85324,85338]
atom_expr [85375,85389]
===
match
---
name: missing_dag_id [74262,74276]
name: missing_dag_id [74313,74327]
===
match
---
name: Dict [11216,11220]
name: Dict [11216,11220]
===
match
---
name: dagrun [34983,34989]
name: dagrun [34983,34989]
===
match
---
trailer [36932,36940]
trailer [36932,36940]
===
match
---
name: self [65968,65972]
name: self [66019,66023]
===
match
---
name: orientation [10876,10887]
name: orientation [10876,10887]
===
match
---
trailer [30767,30777]
trailer [30767,30777]
===
match
---
name: session [78935,78942]
name: session [78986,78993]
===
match
---
name: logging_mixin [2375,2388]
name: logging_mixin [2375,2388]
===
match
---
trailer [34848,34868]
trailer [34848,34868]
===
match
---
string: "This method is deprecated and will be removed in a future version. Please use bulk_write_to_db" [72960,73056]
string: "This method is deprecated and will be removed in a future version. Please use bulk_write_to_db" [73011,73107]
===
match
---
operator: = [21230,21231]
operator: = [21230,21231]
===
match
---
operator: = [10484,10485]
operator: = [10484,10485]
===
match
---
simple_stmt [18853,18869]
simple_stmt [18853,18869]
===
match
---
name: schedule_interval [76466,76483]
name: schedule_interval [76517,76534]
===
match
---
return_stmt [37795,37809]
return_stmt [37795,37809]
===
match
---
name: get_paused_dag_ids [87050,87068]
name: get_paused_dag_ids [87101,87119]
===
match
---
name: _context_managed_dag [95542,95562]
name: _context_managed_dag [95593,95613]
===
match
---
expr_stmt [45808,45863]
expr_stmt [45808,45863]
===
match
---
name: pop_context_managed_dag [17346,17369]
name: pop_context_managed_dag [17346,17369]
===
match
---
simple_stmt [55232,55416]
simple_stmt [55283,55467]
===
match
---
name: confirm_prompt [54898,54912]
name: confirm_prompt [54949,54963]
===
match
---
string: """         Get the next execution date after the given ``date_last_automated_dagrun``, according to         schedule_interval, start_date, end_date etc.  This doesn't check max active run or any other         "concurrency" type limits, it only performs calculations based on the various date and interval fields         of this dag and it's tasks.          :param date_last_automated_dagrun: The execution_date of the last scheduler or             backfill triggered run for this dag         :type date_last_automated_dagrun: pendulum.Pendulum         """ [23369,23925]
string: """         Get the next execution date after the given ``date_last_automated_dagrun``, according to         schedule_interval, start_date, end_date etc.  This doesn't check max active run or any other         "concurrency" type limits, it only performs calculations based on the various date and interval fields         of this dag and it's tasks.          :param date_last_automated_dagrun: The execution_date of the last scheduler or             backfill triggered run for this dag         :type date_last_automated_dagrun: pendulum.Pendulum         """ [23369,23925]
===
match
---
return_stmt [95760,95791]
return_stmt [95811,95842]
===
match
---
operator: = [79959,79960]
operator: = [80010,80011]
===
match
---
name: query [75341,75346]
name: query [75392,75397]
===
match
---
name: commit [78943,78949]
name: commit [78994,79000]
===
match
---
name: query [90966,90971]
name: query [91017,91022]
===
match
---
trailer [24622,24627]
trailer [24622,24627]
===
match
---
name: len [63650,63653]
name: len [63701,63704]
===
match
---
operator: } [53104,53105]
operator: } [53155,53156]
===
match
---
param [66504,66509]
param [66555,66560]
===
match
---
name: is_active [78878,78887]
name: is_active [78929,78938]
===
match
---
arglist [87944,87975]
arglist [87995,88026]
===
match
---
trailer [32129,32141]
trailer [32129,32141]
===
match
---
name: cli [69658,69661]
name: cli [69709,69712]
===
match
---
argument [30435,30450]
argument [30435,30450]
===
match
---
suite [88026,88078]
suite [88077,88129]
===
match
---
simple_stmt [94400,94461]
simple_stmt [94451,94512]
===
match
---
operator: = [18573,18574]
operator: = [18573,18574]
===
match
---
trailer [56671,56680]
trailer [56722,56731]
===
match
---
operator: -> [42352,42354]
operator: -> [42352,42354]
===
match
---
param [28075,28079]
param [28075,28079]
===
match
---
name: session [77368,77375]
name: session [77419,77426]
===
match
---
atom_expr [88738,88754]
atom_expr [88789,88805]
===
match
---
atom_expr [45886,45898]
atom_expr [45886,45898]
===
match
---
atom_expr [91905,91915]
atom_expr [91956,91966]
===
match
---
name: default_args [11905,11917]
name: default_args [11905,11917]
===
match
---
trailer [73955,73960]
trailer [74006,74011]
===
match
---
atom_expr [29666,29713]
atom_expr [29666,29713]
===
match
---
param [36604,36616]
param [36604,36616]
===
match
---
atom_expr [74995,75010]
atom_expr [75046,75061]
===
match
---
name: ti [50897,50899]
name: ti [50948,50950]
===
match
---
comparison [45829,45862]
comparison [45829,45862]
===
match
---
trailer [66398,66413]
trailer [66449,66464]
===
match
---
atom_expr [59813,59829]
atom_expr [59864,59880]
===
match
---
simple_stmt [42620,42720]
simple_stmt [42620,42720]
===
match
---
trailer [35345,35391]
trailer [35345,35391]
===
match
---
name: timezone [21779,21787]
name: timezone [21779,21787]
===
match
---
if_stmt [25750,26099]
if_stmt [25750,26099]
===
match
---
string: '_log' [58194,58200]
string: '_log' [58245,58251]
===
match
---
name: t [60162,60163]
name: t [60213,60214]
===
match
---
trailer [10522,10528]
trailer [10522,10528]
===
match
---
operator: >= [50258,50260]
operator: >= [50309,50311]
===
match
---
atom_expr [16399,16422]
atom_expr [16399,16422]
===
match
---
name: TaskInstance [81031,81043]
name: TaskInstance [81082,81094]
===
match
---
expr_stmt [12779,12833]
expr_stmt [12779,12833]
===
match
---
name: template_undefined [39714,39732]
name: template_undefined [39714,39732]
===
match
---
operator: == [38996,38998]
operator: == [38996,38998]
===
match
---
name: template_searchpath [39520,39539]
name: template_searchpath [39520,39539]
===
match
---
tfpdef [70264,70287]
tfpdef [70315,70338]
===
match
---
name: Optional [11404,11412]
name: Optional [11404,11412]
===
match
---
operator: @ [29396,29397]
operator: @ [29396,29397]
===
match
---
name: PatternType [58697,58708]
name: PatternType [58748,58759]
===
match
---
atom_expr [18748,18766]
atom_expr [18748,18766]
===
match
---
operator: , [54099,54100]
operator: , [54150,54151]
===
match
---
operator: == [80561,80563]
operator: == [80612,80614]
===
match
---
name: session [46281,46288]
name: session [46281,46288]
===
match
---
name: session [49932,49939]
name: session [49983,49990]
===
match
---
atom_expr [74618,74638]
atom_expr [74669,74689]
===
match
---
annassign [95066,95088]
annassign [95117,95139]
===
match
---
operator: + [20366,20367]
operator: + [20366,20367]
===
match
---
arglist [45885,45935]
arglist [45885,45935]
===
match
---
trailer [74491,74515]
trailer [74542,74566]
===
match
---
decorated [42322,42553]
decorated [42322,42553]
===
match
---
parameters [77798,77818]
parameters [77849,77869]
===
match
---
string: """         Runs the DAG.          :param start_date: the start date of the range to run         :type start_date: datetime.datetime         :param end_date: the end date of the range to run         :type end_date: datetime.datetime         :param mark_success: True to mark jobs as succeeded without running them         :type mark_success: bool         :param local: True to run the tasks using the LocalExecutor         :type local: bool         :param executor: The executor instance to run the tasks         :type executor: airflow.executor.base_executor.BaseExecutor         :param donot_pickle: True to avoid pickling DAG object and send to workers         :type donot_pickle: bool         :param ignore_task_deps: True to skip upstream tasks         :type ignore_task_deps: bool         :param ignore_first_depends_on_past: True to ignore depends_on_past             dependencies for the first set of tasks only         :type ignore_first_depends_on_past: bool         :param pool: Resource pool to use         :type pool: str         :param delay_on_limit_secs: Time in seconds to wait before next attempt to run             dag run when max_active_runs limit has been reached         :type delay_on_limit_secs: float         :param verbose: Make logging output more verbose         :type verbose: bool         :param conf: user defined dictionary passed from CLI         :type conf: dict         :param rerun_failed_tasks:         :type: bool         :param run_backwards:         :type: bool          """ [67180,68695]
string: """         Runs the DAG.          :param start_date: the start date of the range to run         :type start_date: datetime.datetime         :param end_date: the end date of the range to run         :type end_date: datetime.datetime         :param mark_success: True to mark jobs as succeeded without running them         :type mark_success: bool         :param local: True to run the tasks using the LocalExecutor         :type local: bool         :param executor: The executor instance to run the tasks         :type executor: airflow.executor.base_executor.BaseExecutor         :param donot_pickle: True to avoid pickling DAG object and send to workers         :type donot_pickle: bool         :param ignore_task_deps: True to skip upstream tasks         :type ignore_task_deps: bool         :param ignore_first_depends_on_past: True to ignore depends_on_past             dependencies for the first set of tasks only         :type ignore_first_depends_on_past: bool         :param pool: Resource pool to use         :type pool: str         :param delay_on_limit_secs: Time in seconds to wait before next attempt to run             dag run when max_active_runs limit has been reached         :type delay_on_limit_secs: float         :param verbose: Make logging output more verbose         :type verbose: bool         :param conf: user defined dictionary passed from CLI         :type conf: dict         :param rerun_failed_tasks:         :type: bool         :param run_backwards:         :type: bool          """ [67231,68746]
===
match
---
decorator [29983,30001]
decorator [29983,30001]
===
match
---
simple_stmt [28391,28403]
simple_stmt [28391,28403]
===
match
---
name: num_active_runs [76781,76796]
name: num_active_runs [76832,76847]
===
match
---
operator: < [16586,16587]
operator: < [16586,16587]
===
match
---
trailer [79450,79515]
trailer [79501,79566]
===
match
---
name: next_run_date [25532,25545]
name: next_run_date [25532,25545]
===
match
---
atom_expr [85751,85828]
atom_expr [85802,85879]
===
match
---
name: self [91520,91524]
name: self [91571,91575]
===
match
---
comparison [50240,50271]
comparison [50291,50322]
===
match
---
name: dag_id [64024,64030]
name: dag_id [64075,64081]
===
match
---
if_stmt [63318,63397]
if_stmt [63369,63448]
===
match
---
parameters [42582,42588]
parameters [42582,42588]
===
match
---
name: DagRun [45738,45744]
name: DagRun [45738,45744]
===
match
---
arith_expr [20334,20373]
arith_expr [20334,20373]
===
match
---
decorated [30560,30691]
decorated [30560,30691]
===
match
---
simple_stmt [16026,16043]
simple_stmt [16026,16043]
===
match
---
string: 'extensions' [39746,39758]
string: 'extensions' [39746,39758]
===
match
---
argument [77268,77285]
argument [77319,77336]
===
match
---
atom_expr [14035,14050]
atom_expr [14035,14050]
===
match
---
operator: == [86580,86582]
operator: == [86631,86633]
===
match
---
decorator [77763,77780]
decorator [77814,77831]
===
match
---
string: "Cancelled, nothing was cleared." [55699,55732]
string: "Cancelled, nothing was cleared." [55750,55783]
===
match
---
name: int [29449,29452]
name: int [29449,29452]
===
match
---
name: utcnow [41449,41455]
name: utcnow [41449,41455]
===
match
---
operator: , [52273,52274]
operator: , [52324,52325]
===
match
---
operator: = [3424,3425]
operator: = [3424,3425]
===
match
---
simple_stmt [89177,89276]
simple_stmt [89228,89327]
===
match
---
name: int [10558,10561]
name: int [10558,10561]
===
match
---
name: dag_id [88463,88469]
name: dag_id [88514,88520]
===
match
---
name: cls [95538,95541]
name: cls [95589,95592]
===
match
---
number: 2000 [84938,84942]
number: 2000 [84989,84993]
===
match
---
expr_stmt [48572,48589]
expr_stmt [48572,48589]
===
match
---
decorator [29121,29131]
decorator [29121,29131]
===
match
---
simple_stmt [44544,44560]
simple_stmt [44544,44560]
===
match
---
name: start_date [45432,45442]
name: start_date [45432,45442]
===
match
---
name: filepath [30897,30905]
name: filepath [30897,30905]
===
match
---
simple_stmt [13179,13319]
simple_stmt [13179,13319]
===
match
---
operator: == [75011,75013]
operator: == [75062,75064]
===
match
---
return_stmt [42490,42552]
return_stmt [42490,42552]
===
match
---
operator: = [11528,11529]
operator: = [11528,11529]
===
match
---
simple_stmt [88410,88481]
simple_stmt [88461,88532]
===
match
---
atom_expr [77405,77428]
atom_expr [77456,77479]
===
match
---
name: __repr__ [83418,83426]
name: __repr__ [83469,83477]
===
match
---
atom_expr [25174,25184]
atom_expr [25174,25184]
===
match
---
operator: } [18272,18273]
operator: } [18272,18273]
===
match
---
operator: , [49382,49383]
operator: , [49433,49434]
===
match
---
trailer [20029,20071]
trailer [20029,20071]
===
match
---
string: 'gantt' [3031,3038]
string: 'gantt' [3031,3038]
===
match
---
name: cls [90845,90848]
name: cls [90896,90899]
===
match
---
name: start_date [25758,25768]
name: start_date [25758,25768]
===
match
---
simple_stmt [93080,93123]
simple_stmt [93131,93174]
===
match
---
operator: + [31049,31050]
operator: + [31049,31050]
===
match
---
trailer [26019,26025]
trailer [26019,26025]
===
match
---
trailer [30628,30690]
trailer [30628,30690]
===
match
---
operator: = [31071,31072]
operator: = [31071,31072]
===
match
---
name: stacklevel [32476,32486]
name: stacklevel [32476,32486]
===
match
---
expr_stmt [14710,14740]
expr_stmt [14710,14740]
===
match
---
name: new_start [24784,24793]
name: new_start [24784,24793]
===
match
---
arglist [85757,85827]
arglist [85808,85878]
===
match
---
simple_stmt [79558,79751]
simple_stmt [79609,79802]
===
match
---
name: self [16545,16549]
name: self [16545,16549]
===
match
---
dictorsetmaker [88660,88689]
dictorsetmaker [88711,88740]
===
match
---
name: DagRunType [75014,75024]
name: DagRunType [75065,75075]
===
match
---
decorated [29494,29570]
decorated [29494,29570]
===
match
---
suite [77694,77758]
suite [77745,77809]
===
match
---
operator: @ [42558,42559]
operator: @ [42558,42559]
===
match
---
trailer [21262,21271]
trailer [21262,21271]
===
match
---
trailer [23348,23357]
trailer [23348,23357]
===
match
---
name: _context_managed_dag [95458,95478]
name: _context_managed_dag [95509,95529]
===
match
---
name: task [65326,65330]
name: task [65377,65381]
===
match
---
and_test [65085,65128]
and_test [65136,65179]
===
match
---
name: external_dag [52925,52937]
name: external_dag [52976,52988]
===
match
---
name: str [13157,13160]
name: str [13157,13160]
===
match
---
return_stmt [95672,95686]
return_stmt [95723,95737]
===
match
---
argument [69295,69328]
argument [69346,69379]
===
match
---
name: self [34844,34848]
name: self [34844,34848]
===
match
---
name: property [31145,31153]
name: property [31145,31153]
===
match
---
operator: = [73875,73876]
operator: = [73926,73927]
===
match
---
trailer [18784,18786]
trailer [18784,18786]
===
match
---
suite [77819,78082]
suite [77870,78133]
===
match
---
operator: , [88829,88830]
operator: , [88880,88881]
===
match
---
name: next_dagrun_after_date [23274,23296]
name: next_dagrun_after_date [23274,23296]
===
match
---
atom_expr [43501,43511]
atom_expr [43501,43511]
===
match
---
name: String [1381,1387]
name: String [1381,1387]
===
match
---
name: self [9949,9953]
name: self [9949,9953]
===
match
---
suite [50574,50630]
suite [50625,50681]
===
match
---
parameters [37135,37177]
parameters [37135,37177]
===
match
---
expr_stmt [61026,61051]
expr_stmt [61077,61102]
===
match
---
expr_stmt [45574,45608]
expr_stmt [45574,45608]
===
match
---
suite [24978,25023]
suite [24978,25023]
===
match
---
name: dag_ids [55622,55629]
name: dag_ids [55673,55680]
===
match
---
funcdef [3158,3714]
funcdef [3158,3714]
===
match
---
name: fn [31073,31075]
name: fn [31073,31075]
===
match
---
return_stmt [31129,31138]
return_stmt [31129,31138]
===
match
---
trailer [39670,39682]
trailer [39670,39682]
===
match
---
name: DagRun [37708,37714]
name: DagRun [37708,37714]
===
match
---
operator: , [40753,40754]
operator: , [40753,40754]
===
match
---
funcdef [69654,69883]
funcdef [69705,69934]
===
match
---
dotted_name [68807,68839]
dotted_name [68858,68890]
===
match
---
try_stmt [89331,89990]
try_stmt [89382,90041]
===
match
---
name: pickle_id [84658,84667]
name: pickle_id [84709,84718]
===
match
---
arglist [57996,58003]
arglist [58047,58054]
===
match
---
name: orm_dag [76238,76245]
name: orm_dag [76289,76296]
===
match
---
simple_stmt [51328,51472]
simple_stmt [51379,51523]
===
match
---
trailer [90633,90639]
trailer [90684,90690]
===
match
---
string: """Returns a list of the subdag objects associated to this DAG""" [38529,38594]
string: """Returns a list of the subdag objects associated to this DAG""" [38529,38594]
===
match
---
name: self [36978,36982]
name: self [36978,36982]
===
match
---
operator: , [72423,72424]
operator: , [72474,72475]
===
match
---
suite [79053,79845]
suite [79104,79896]
===
match
---
atom_expr [59724,59738]
atom_expr [59775,59789]
===
match
---
name: other [16588,16593]
name: other [16588,16593]
===
match
---
return_stmt [20609,20650]
return_stmt [20609,20650]
===
match
---
operator: , [82030,82031]
operator: , [82081,82082]
===
match
---
name: State [50539,50544]
name: State [50590,50595]
===
match
---
name: include_externally_triggered [28847,28875]
name: include_externally_triggered [28847,28875]
===
match
---
atom_expr [24503,24520]
atom_expr [24503,24520]
===
match
---
trailer [63633,63647]
trailer [63684,63698]
===
match
---
string: 'webserver' [78255,78266]
string: 'webserver' [78306,78317]
===
match
---
name: tzinfo [12827,12833]
name: tzinfo [12827,12833]
===
match
---
name: union [53423,53428]
name: union [53474,53479]
===
match
---
trailer [95297,95323]
trailer [95348,95374]
===
match
---
name: session [70242,70249]
name: session [70293,70300]
===
match
---
atom [59802,59804]
atom [59853,59855]
===
match
---
import_name [856,865]
import_name [856,865]
===
match
---
decorator [30696,30706]
decorator [30696,30706]
===
match
---
fstring_start: f" [45200,45202]
fstring_start: f" [45200,45202]
===
match
---
name: orm_dag [76332,76339]
name: orm_dag [76383,76390]
===
match
---
simple_stmt [38529,38595]
simple_stmt [38529,38595]
===
match
---
name: self [77799,77803]
name: self [77850,77854]
===
match
---
atom_expr [37655,37676]
atom_expr [37655,37676]
===
match
---
string: 'end_date' [13630,13640]
string: 'end_date' [13630,13640]
===
match
---
name: __tablename__ [83530,83543]
name: __tablename__ [83581,83594]
===
match
---
comparison [24883,24911]
comparison [24883,24911]
===
match
---
operator: = [78888,78889]
operator: = [78939,78940]
===
match
---
atom [54946,54967]
atom [54997,55018]
===
match
---
operator: = [70288,70289]
operator: = [70339,70340]
===
match
---
name: dttm [21252,21256]
name: dttm [21252,21256]
===
match
---
operator: == [41088,41090]
operator: == [41088,41090]
===
match
---
name: following_schedule [23224,23242]
name: following_schedule [23224,23242]
===
match
---
trailer [40942,40953]
trailer [40942,40953]
===
match
---
trailer [43473,43481]
trailer [43473,43481]
===
match
---
param [40755,40771]
param [40755,40771]
===
match
---
name: session [79828,79835]
name: session [79879,79886]
===
match
---
atom_expr [18884,19014]
atom_expr [18884,19014]
===
match
---
name: isinstance [19726,19736]
name: isinstance [19726,19736]
===
match
---
trailer [20753,20795]
trailer [20753,20795]
===
match
---
trailer [90897,90923]
trailer [90948,90974]
===
match
---
trailer [72551,72557]
trailer [72602,72608]
===
match
---
name: count [36270,36275]
name: count [36270,36275]
===
match
---
atom_expr [74651,74675]
atom_expr [74702,74726]
===
match
---
name: isinstance [12619,12629]
name: isinstance [12619,12629]
===
match
---
atom_expr [90682,90706]
atom_expr [90733,90757]
===
match
---
name: str [63700,63703]
name: str [63751,63754]
===
match
---
operator: >= [45760,45762]
operator: >= [45760,45762]
===
match
---
name: query [37986,37991]
name: query [37986,37991]
===
match
---
funcdef [66728,69649]
funcdef [66779,69700]
===
match
---
comparison [27871,27902]
comparison [27871,27902]
===
match
---
name: visited_external_tis [54340,54360]
name: visited_external_tis [54391,54411]
===
match
---
name: task_id [63094,63101]
name: task_id [63145,63152]
===
match
---
operator: , [30592,30593]
operator: , [30592,30593]
===
match
---
not_test [65650,65667]
not_test [65701,65718]
===
match
---
expr_stmt [15961,16017]
expr_stmt [15961,16017]
===
match
---
simple_stmt [38131,38233]
simple_stmt [38131,38233]
===
match
---
simple_stmt [33930,33974]
simple_stmt [33930,33974]
===
match
---
trailer [32720,32726]
trailer [32720,32726]
===
match
---
atom_expr [23034,23056]
atom_expr [23034,23056]
===
match
---
import_from [43268,43319]
import_from [43268,43319]
===
match
---
name: graph_unsorted [44874,44888]
name: graph_unsorted [44874,44888]
===
match
---
name: session [54092,54099]
name: session [54143,54150]
===
match
---
for_stmt [62108,62560]
for_stmt [62159,62611]
===
match
---
trailer [11120,11144]
trailer [11120,11144]
===
match
---
trailer [61228,61237]
trailer [61279,61288]
===
match
---
trailer [18168,18174]
trailer [18168,18174]
===
match
---
return_stmt [32784,32820]
return_stmt [32784,32820]
===
match
---
name: tasks [39215,39220]
name: tasks [39215,39220]
===
match
---
if_stmt [86019,86118]
if_stmt [86070,86169]
===
match
---
trailer [10477,10483]
trailer [10477,10483]
===
match
---
operator: @ [30879,30880]
operator: @ [30879,30880]
===
match
---
argument [69342,69399]
argument [69393,69450]
===
match
---
argument [55342,55365]
argument [55393,55416]
===
match
---
atom_expr [50229,50272]
atom_expr [50280,50323]
===
match
---
atom_expr [41116,41143]
atom_expr [41116,41143]
===
match
---
simple_stmt [24933,24961]
simple_stmt [24933,24961]
===
match
---
name: _pickle_id [12111,12121]
name: _pickle_id [12111,12121]
===
match
---
tfpdef [63108,63129]
tfpdef [63159,63180]
===
match
---
expr_stmt [93999,94042]
expr_stmt [94050,94093]
===
match
---
trailer [32321,32499]
trailer [32321,32499]
===
match
---
expr_stmt [76238,76262]
expr_stmt [76289,76313]
===
match
---
name: level [64633,64638]
name: level [64684,64689]
===
match
---
arith_expr [22022,22062]
arith_expr [22022,22062]
===
match
---
name: models [1864,1870]
name: models [1864,1870]
===
match
---
name: default_args [13533,13545]
name: default_args [13533,13545]
===
match
---
name: orientation [14909,14920]
name: orientation [14909,14920]
===
match
---
operator: == [88455,88457]
operator: == [88506,88508]
===
match
---
operator: , [53870,53871]
operator: , [53921,53922]
===
match
---
operator: , [69962,69963]
operator: , [70013,70014]
===
match
---
name: self [58278,58282]
name: self [58329,58333]
===
match
---
expr_stmt [2978,3056]
expr_stmt [2978,3056]
===
match
---
simple_stmt [58310,58369]
simple_stmt [58361,58420]
===
match
---
atom_expr [63288,63300]
atom_expr [63339,63351]
===
match
---
suite [2764,2823]
suite [2764,2823]
===
match
---
trailer [58083,58104]
trailer [58134,58155]
===
match
---
simple_stmt [87135,87321]
simple_stmt [87186,87372]
===
match
---
atom_expr [63561,63578]
atom_expr [63612,63629]
===
match
---
name: schedule_interval [23946,23963]
name: schedule_interval [23946,23963]
===
match
---
name: next_run_date [25891,25904]
name: next_run_date [25891,25904]
===
match
---
operator: , [18143,18144]
operator: , [18143,18144]
===
match
---
name: copied [61777,61783]
name: copied [61828,61834]
===
match
---
expr_stmt [89285,89322]
expr_stmt [89336,89373]
===
match
---
parameters [86494,86516]
parameters [86545,86567]
===
match
---
name: default_args [13074,13086]
name: default_args [13074,13086]
===
match
---
simple_stmt [15626,15694]
simple_stmt [15626,15694]
===
match
---
param [56017,56041]
param [56068,56092]
===
match
---
operator: , [58289,58290]
operator: , [58340,58341]
===
match
---
name: DagRunType [70214,70224]
name: DagRunType [70265,70275]
===
match
---
operator: = [74334,74335]
operator: = [74385,74386]
===
match
---
funcdef [17191,17282]
funcdef [17191,17282]
===
match
---
name: Column [83952,83958]
name: Column [84003,84009]
===
match
---
operator: , [2950,2951]
operator: , [2950,2951]
===
match
---
atom_expr [34983,35010]
atom_expr [34983,35010]
===
match
---
trailer [86546,86556]
trailer [86597,86607]
===
match
---
trailer [95599,95603]
trailer [95650,95654]
===
match
---
name: cls [57764,57767]
name: cls [57815,57818]
===
match
---
operator: = [41950,41951]
operator: = [41950,41951]
===
match
---
trailer [42197,42204]
trailer [42197,42204]
===
match
---
atom_expr [50323,50340]
atom_expr [50374,50391]
===
match
---
operator: == [49064,49066]
operator: == [49064,49066]
===
match
---
atom_expr [89257,89274]
atom_expr [89308,89325]
===
match
---
simple_stmt [1405,1466]
simple_stmt [1405,1466]
===
match
---
dotted_name [2464,2488]
dotted_name [2464,2488]
===
match
---
for_stmt [61210,61826]
for_stmt [61261,61877]
===
match
---
name: dag [62437,62440]
name: dag [62488,62491]
===
match
---
comp_op [28931,28937]
comp_op [28931,28937]
===
match
---
tfpdef [82897,82915]
tfpdef [82948,82966]
===
match
---
param [73271,73283]
param [73322,73334]
===
match
---
name: Optional [10114,10122]
name: Optional [10114,10122]
===
match
---
simple_stmt [1466,1509]
simple_stmt [1466,1509]
===
match
---
operator: } [87597,87598]
operator: } [87648,87649]
===
match
---
name: airflow [2590,2597]
name: airflow [2590,2597]
===
match
---
name: warnings [72933,72941]
name: warnings [72984,72992]
===
match
---
operator: = [61086,61087]
operator: = [61137,61138]
===
match
---
simple_stmt [64119,64195]
simple_stmt [64170,64246]
===
match
---
operator: -> [28989,28991]
operator: -> [28989,28991]
===
match
---
trailer [85873,85880]
trailer [85924,85931]
===
match
---
param [29344,29348]
param [29344,29348]
===
match
---
simple_stmt [65876,65926]
simple_stmt [65927,65977]
===
match
---
atom_expr [15149,15173]
atom_expr [15149,15173]
===
match
---
name: start_date [72287,72297]
name: start_date [72338,72348]
===
match
---
operator: = [45508,45509]
operator: = [45508,45509]
===
match
---
name: type [38922,38926]
name: type [38922,38926]
===
match
---
suite [50293,50354]
suite [50344,50405]
===
match
---
string: """         Get the Default DAG View, returns the default config value if DagModel does not         have a value         """ [87677,87801]
string: """         Get the Default DAG View, returns the default config value if DagModel does not         have a value         """ [87728,87852]
===
match
---
atom [88425,88480]
atom [88476,88531]
===
match
---
name: tuple [17092,17097]
name: tuple [17092,17097]
===
match
---
expr_stmt [33720,33781]
expr_stmt [33720,33781]
===
match
---
name: self [16682,16686]
name: self [16682,16686]
===
match
---
for_stmt [75685,77393]
for_stmt [75736,77444]
===
match
---
operator: = [54229,54230]
operator: = [54280,54281]
===
match
---
if_stmt [65935,66432]
if_stmt [65986,66483]
===
match
---
arglist [32994,33138]
arglist [32994,33138]
===
match
---
suite [82695,82784]
suite [82746,82835]
===
match
---
name: end_date [49570,49578]
name: end_date [49621,49629]
===
match
---
name: session [54084,54091]
name: session [54135,54142]
===
match
---
name: DagRunType [71676,71686]
name: DagRunType [71727,71737]
===
match
---
trailer [41220,41226]
trailer [41220,41226]
===
match
---
raise_stmt [65142,65208]
raise_stmt [65193,65259]
===
match
---
name: execution_date [45745,45759]
name: execution_date [45745,45759]
===
match
---
trailer [81197,81205]
trailer [81248,81256]
===
match
---
trailer [24851,24862]
trailer [24851,24862]
===
match
---
simple_stmt [83940,83999]
simple_stmt [83991,84050]
===
match
---
atom_expr [39829,39858]
atom_expr [39829,39858]
===
match
---
name: run_id [72213,72219]
name: run_id [72264,72270]
===
match
---
expr_stmt [18099,18126]
expr_stmt [18099,18126]
===
match
---
if_stmt [43600,43664]
if_stmt [43600,43664]
===
match
---
name: dag_id [37616,37622]
name: dag_id [37616,37622]
===
match
---
name: DAG [91088,91091]
name: DAG [91139,91142]
===
match
---
name: other [16523,16528]
name: other [16523,16528]
===
match
---
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_latest_execution_date` method.""" [38131,38232]
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_latest_execution_date` method.""" [38131,38232]
===
match
---
operator: , [66502,66503]
operator: , [66553,66554]
===
match
---
operator: = [76582,76583]
operator: = [76633,76634]
===
match
---
operator: = [72483,72484]
operator: = [72534,72535]
===
match
---
simple_stmt [1808,1851]
simple_stmt [1808,1851]
===
match
---
name: ignore_task_deps [69295,69311]
name: ignore_task_deps [69346,69362]
===
match
---
atom_expr [30763,30784]
atom_expr [30763,30784]
===
match
---
name: state [50414,50419]
name: state [50465,50470]
===
match
---
name: states [80711,80717]
name: states [80762,80768]
===
match
---
arglist [41068,41229]
arglist [41068,41229]
===
match
---
expr_stmt [64247,64271]
expr_stmt [64298,64322]
===
match
---
string: 'catchup_by_default' [10990,11010]
string: 'catchup_by_default' [10990,11010]
===
match
---
name: tags [77103,77107]
name: tags [77154,77158]
===
match
---
arglist [13247,13300]
arglist [13247,13300]
===
match
---
param [37154,37163]
param [37154,37163]
===
match
---
comparison [16373,16422]
comparison [16373,16422]
===
match
---
operator: <= [24654,24656]
operator: <= [24654,24656]
===
match
---
suite [56811,57035]
suite [56862,57086]
===
match
---
suite [95206,95363]
suite [95257,95414]
===
match
---
string: 'start_date' [9736,9748]
string: 'start_date' [9736,9748]
===
match
---
not_test [27797,27815]
not_test [27797,27815]
===
match
---
simple_stmt [63554,63579]
simple_stmt [63605,63630]
===
match
---
trailer [16818,16841]
trailer [16818,16841]
===
match
---
name: confirm_prompt [49692,49706]
name: confirm_prompt [49743,49757]
===
match
---
trailer [64892,64900]
trailer [64943,64951]
===
match
---
name: get_concurrency_reached [31739,31762]
name: get_concurrency_reached [31739,31762]
===
match
---
name: default_args [12635,12647]
name: default_args [12635,12647]
===
match
---
atom_expr [29932,29945]
atom_expr [29932,29945]
===
match
---
operator: , [10490,10491]
operator: , [10490,10491]
===
match
---
name: dag [77728,77731]
name: dag [77779,77782]
===
match
---
trailer [3553,3560]
trailer [3553,3560]
===
match
---
name: state [75476,75481]
name: state [75527,75532]
===
match
---
dotted_name [1813,1835]
dotted_name [1813,1835]
===
match
---
name: confirm_prompt [46122,46136]
name: confirm_prompt [46122,46136]
===
match
---
name: task_dict [66223,66232]
name: task_dict [66274,66283]
===
match
---
trailer [36926,36932]
trailer [36926,36932]
===
match
---
name: int [10629,10632]
name: int [10629,10632]
===
match
---
name: dag [73787,73790]
name: dag [73838,73841]
===
match
---
name: task [42498,42502]
name: task [42498,42502]
===
match
---
name: next_dagrun_create_after [90849,90873]
name: next_dagrun_create_after [90900,90924]
===
match
---
name: cast [1195,1199]
name: cast [1195,1199]
===
match
---
trailer [65348,65359]
trailer [65399,65410]
===
match
---
name: airflow [1813,1820]
name: airflow [1813,1820]
===
match
---
string: """         Looks for outdated dag level permissions (can_dag_read and can_dag_edit) in DAG         access_controls (for example, {'role1': {'can_dag_read'}, 'role2': {'can_dag_read', 'can_dag_edit'}})         and replaces them with updated permissions (can_read and can_edit).         """ [17537,17826]
string: """         Looks for outdated dag level permissions (can_dag_read and can_dag_edit) in DAG         access_controls (for example, {'role1': {'can_dag_read'}, 'role2': {'can_dag_read', 'can_dag_edit'}})         and replaces them with updated permissions (can_read and can_edit).         """ [17537,17826]
===
match
---
trailer [50899,50908]
trailer [50950,50959]
===
match
---
name: dag_id [64039,64045]
name: dag_id [64090,64096]
===
match
---
atom_expr [43644,43663]
atom_expr [43644,43663]
===
match
---
name: task [42736,42740]
name: task [42736,42740]
===
match
---
simple_stmt [40375,40386]
simple_stmt [40375,40386]
===
match
---
atom_expr [53462,54416]
atom_expr [53513,54467]
===
match
---
name: provide_session [77764,77779]
name: provide_session [77815,77830]
===
match
---
string: """         Returns a list of dates between the interval received as parameter using this         dag's schedule interval. Returned dates can be used for execution dates.          :param start_date: the start date of the interval         :type start_date: datetime         :param end_date: the end date of the interval, defaults to timezone.utcnow()         :type end_date: datetime         :return: a list of dates within the interval following the dag's schedule         :rtype: list         """ [26791,27288]
string: """         Returns a list of dates between the interval received as parameter using this         dag's schedule interval. Returned dates can be used for execution dates.          :param start_date: the start date of the interval         :type start_date: datetime         :param end_date: the end date of the interval, defaults to timezone.utcnow()         :type end_date: datetime         :return: a list of dates within the interval following the dag's schedule         :rtype: list         """ [26791,27288]
===
match
---
decorator [72753,72766]
decorator [72804,72817]
===
match
---
comparison [50964,50992]
comparison [51015,51043]
===
match
---
atom_expr [50593,50629]
atom_expr [50644,50680]
===
match
---
testlist_comp [23139,23179]
testlist_comp [23139,23179]
===
match
---
expr_stmt [25782,25875]
expr_stmt [25782,25875]
===
match
---
atom_expr [60063,60073]
atom_expr [60114,60124]
===
match
---
name: session [89953,89960]
name: session [90004,90011]
===
match
---
if_stmt [25214,25395]
if_stmt [25214,25395]
===
match
---
arglist [52254,52314]
arglist [52305,52365]
===
match
---
trailer [10424,10430]
trailer [10424,10430]
===
match
---
name: add_task [66708,66716]
name: add_task [66759,66767]
===
match
---
operator: , [60006,60007]
operator: , [60057,60058]
===
match
---
name: Interval [85216,85224]
name: Interval [85267,85275]
===
match
---
name: is_paused [32810,32819]
name: is_paused [32810,32819]
===
match
---
return_stmt [61839,61852]
return_stmt [61890,61903]
===
match
---
operator: , [1168,1169]
operator: , [1168,1169]
===
match
---
atom_expr [58015,58041]
atom_expr [58066,58092]
===
match
---
atom_expr [89177,89275]
atom_expr [89228,89326]
===
insert-node
---
name: DAG [3748,3751]
to
classdef [3742,83155]
at 0
===
insert-node
---
name: LoggingMixin [3752,3764]
to
classdef [3742,83155]
at 1
===
insert-tree
---
simple_stmt [3771,9652]
    string: """     A dag (directed acyclic graph) is a collection of tasks with directional     dependencies. A dag also has a schedule, a start date and an end date     (optional). For each schedule, (say daily or hourly), the DAG needs to run     each individual tasks as their dependencies are met. Certain tasks have     the property of depending on their own past, meaning that they can't run     until their previous schedule (and upstream tasks) are completed.      DAGs essentially act as namespaces for tasks. A task_id can only be     added once to a DAG.      :param dag_id: The id of the DAG; must consist exclusively of alphanumeric         characters, dashes, dots and underscores (all ASCII)     :type dag_id: str     :param description: The description for the DAG to e.g. be shown on the webserver     :type description: str     :param schedule_interval: Defines how often that DAG runs, this         timedelta object gets added to your latest task instance's         execution_date to figure out the next schedule     :type schedule_interval: datetime.timedelta or         dateutil.relativedelta.relativedelta or str that acts as a cron         expression     :param start_date: The timestamp from which the scheduler will         attempt to backfill     :type start_date: datetime.datetime     :param end_date: A date beyond which your DAG won't run, leave to None         for open ended scheduling     :type end_date: datetime.datetime     :param template_searchpath: This list of folders (non relative)         defines where jinja will look for your templates. Order matters.         Note that jinja/airflow includes the path of your DAG file by         default     :type template_searchpath: str or list[str]     :param template_undefined: Template undefined type.     :type template_undefined: jinja2.StrictUndefined     :param user_defined_macros: a dictionary of macros that will be exposed         in your jinja templates. For example, passing ``dict(foo='bar')``         to this argument allows you to ``{{ foo }}`` in all jinja         templates related to this DAG. Note that you can pass any         type of object here.     :type user_defined_macros: dict     :param user_defined_filters: a dictionary of filters that will be exposed         in your jinja templates. For example, passing         ``dict(hello=lambda name: 'Hello %s' % name)`` to this argument allows         you to ``{{ 'world' | hello }}`` in all jinja templates related to         this DAG.     :type user_defined_filters: dict     :param default_args: A dictionary of default parameters to be used         as constructor keyword parameters when initialising operators.         Note that operators have the same hook, and precede those defined         here, meaning that if your dict contains `'depends_on_past': True`         here and `'depends_on_past': False` in the operator's call         `default_args`, the actual value will be `False`.     :type default_args: dict     :param params: a dictionary of DAG level parameters that are made         accessible in templates, namespaced under `params`. These         params can be overridden at the task level.     :type params: dict     :param concurrency: the number of task instances allowed to run         concurrently     :type concurrency: int     :param max_active_runs: maximum number of active DAG runs, beyond this         number of DAG runs in a running state, the scheduler won't create         new active DAG runs     :type max_active_runs: int     :param dagrun_timeout: specify how long a DagRun should be up before         timing out / failing, so that new DagRuns can be created. The timeout         is only enforced for scheduled DagRuns.     :type dagrun_timeout: datetime.timedelta     :param sla_miss_callback: specify a function to call when reporting SLA         timeouts.     :type sla_miss_callback: types.FunctionType     :param default_view: Specify DAG default view (tree, graph, duration,                                                    gantt, landing_times), default tree     :type default_view: str     :param orientation: Specify DAG orientation in graph view (LR, TB, RL, BT), default LR     :type orientation: str     :param catchup: Perform scheduler catchup (or only run latest)? Defaults to True     :type catchup: bool     :param on_failure_callback: A function to be called when a DagRun of this dag fails.         A context dictionary is passed as a single parameter to this function.     :type on_failure_callback: callable     :param on_success_callback: Much like the ``on_failure_callback`` except         that it is executed when the dag succeeds.     :type on_success_callback: callable     :param access_control: Specify optional DAG-level permissions, e.g.,         "{'role1': {'can_read'}, 'role2': {'can_read', 'can_edit'}}"     :type access_control: dict     :param is_paused_upon_creation: Specifies if the dag is paused when created for the first time.         If the dag exists already, this flag will be ignored. If this optional parameter         is not specified, the global config setting will be used.     :type is_paused_upon_creation: bool or None     :param jinja_environment_kwargs: additional configuration options to be passed to Jinja         ``Environment`` for template rendering          **Example**: to avoid Jinja from removing a trailing newline from template strings ::              DAG(dag_id='my-dag',                 jinja_environment_kwargs={                     'keep_trailing_newline': True,                     # some other jinja2 Environment options here                 }             )          **See**: `Jinja Environment documentation         <https://jinja.palletsprojects.com/en/master/api/#jinja2.Environment>`_      :type jinja_environment_kwargs: dict     :param tags: List of tags to help filtering DAGS in the UI.     :type tags: List[str]     """ [3771,9651]
to
suite [3766,83155]
at 0
===
insert-tree
---
decorator [45942,45959]
    operator: @ [45942,45943]
    name: provide_session [45943,45958]
to
decorated [45942,55781]
at 0
===
insert-node
---
name: clear [45967,45972]
to
funcdef [45963,55781]
at 0
===
insert-tree
---
simple_stmt [49234,49273]
    atom_expr [49234,49272]
        name: dag_ids [49234,49241]
        trailer [49241,49248]
            name: append [49242,49248]
        trailer [49248,49272]
            atom_expr [49249,49271]
                name: self [49249,49253]
                trailer [49253,49264]
                    name: parent_dag [49254,49264]
                trailer [49264,49271]
                    name: dag_id [49265,49271]
to
suite [49221,50187]
at 0
===
delete-node
---
name: DAG [3748,3751]
===
===
delete-node
---
name: LoggingMixin [3752,3764]
===
===
delete-tree
---
simple_stmt [3771,9652]
    string: """     A dag (directed acyclic graph) is a collection of tasks with directional     dependencies. A dag also has a schedule, a start date and an end date     (optional). For each schedule, (say daily or hourly), the DAG needs to run     each individual tasks as their dependencies are met. Certain tasks have     the property of depending on their own past, meaning that they can't run     until their previous schedule (and upstream tasks) are completed.      DAGs essentially act as namespaces for tasks. A task_id can only be     added once to a DAG.      :param dag_id: The id of the DAG; must consist exclusively of alphanumeric         characters, dashes, dots and underscores (all ASCII)     :type dag_id: str     :param description: The description for the DAG to e.g. be shown on the webserver     :type description: str     :param schedule_interval: Defines how often that DAG runs, this         timedelta object gets added to your latest task instance's         execution_date to figure out the next schedule     :type schedule_interval: datetime.timedelta or         dateutil.relativedelta.relativedelta or str that acts as a cron         expression     :param start_date: The timestamp from which the scheduler will         attempt to backfill     :type start_date: datetime.datetime     :param end_date: A date beyond which your DAG won't run, leave to None         for open ended scheduling     :type end_date: datetime.datetime     :param template_searchpath: This list of folders (non relative)         defines where jinja will look for your templates. Order matters.         Note that jinja/airflow includes the path of your DAG file by         default     :type template_searchpath: str or list[str]     :param template_undefined: Template undefined type.     :type template_undefined: jinja2.StrictUndefined     :param user_defined_macros: a dictionary of macros that will be exposed         in your jinja templates. For example, passing ``dict(foo='bar')``         to this argument allows you to ``{{ foo }}`` in all jinja         templates related to this DAG. Note that you can pass any         type of object here.     :type user_defined_macros: dict     :param user_defined_filters: a dictionary of filters that will be exposed         in your jinja templates. For example, passing         ``dict(hello=lambda name: 'Hello %s' % name)`` to this argument allows         you to ``{{ 'world' | hello }}`` in all jinja templates related to         this DAG.     :type user_defined_filters: dict     :param default_args: A dictionary of default parameters to be used         as constructor keyword parameters when initialising operators.         Note that operators have the same hook, and precede those defined         here, meaning that if your dict contains `'depends_on_past': True`         here and `'depends_on_past': False` in the operator's call         `default_args`, the actual value will be `False`.     :type default_args: dict     :param params: a dictionary of DAG level parameters that are made         accessible in templates, namespaced under `params`. These         params can be overridden at the task level.     :type params: dict     :param concurrency: the number of task instances allowed to run         concurrently     :type concurrency: int     :param max_active_runs: maximum number of active DAG runs, beyond this         number of DAG runs in a running state, the scheduler won't create         new active DAG runs     :type max_active_runs: int     :param dagrun_timeout: specify how long a DagRun should be up before         timing out / failing, so that new DagRuns can be created. The timeout         is only enforced for scheduled DagRuns.     :type dagrun_timeout: datetime.timedelta     :param sla_miss_callback: specify a function to call when reporting SLA         timeouts.     :type sla_miss_callback: types.FunctionType     :param default_view: Specify DAG default view (tree, graph, duration,                                                    gantt, landing_times), default tree     :type default_view: str     :param orientation: Specify DAG orientation in graph view (LR, TB, RL, BT), default LR     :type orientation: str     :param catchup: Perform scheduler catchup (or only run latest)? Defaults to True     :type catchup: bool     :param on_failure_callback: A function to be called when a DagRun of this dag fails.         A context dictionary is passed as a single parameter to this function.     :type on_failure_callback: callable     :param on_success_callback: Much like the ``on_failure_callback`` except         that it is executed when the dag succeeds.     :type on_success_callback: callable     :param access_control: Specify optional DAG-level permissions, e.g.,         "{'role1': {'can_read'}, 'role2': {'can_read', 'can_edit'}}"     :type access_control: dict     :param is_paused_upon_creation: Specifies if the dag is paused when created for the first time.         If the dag exists already, this flag will be ignored. If this optional parameter         is not specified, the global config setting will be used.     :type is_paused_upon_creation: bool or None     :param jinja_environment_kwargs: additional configuration options to be passed to Jinja         ``Environment`` for template rendering          **Example**: to avoid Jinja from removing a trailing newline from template strings ::              DAG(dag_id='my-dag',                 jinja_environment_kwargs={                     'keep_trailing_newline': True,                     # some other jinja2 Environment options here                 }             )          **See**: `Jinja Environment documentation         <https://jinja.palletsprojects.com/en/master/api/#jinja2.Environment>`_      :type jinja_environment_kwargs: dict     :param tags: List of tags to help filtering DAGS in the UI.     :type tags: List[str]     """ [3771,9651]
===
delete-tree
---
decorator [45942,45959]
    operator: @ [45942,45943]
    name: provide_session [45943,45958]
===
delete-node
---
name: clear [45967,45972]
===
