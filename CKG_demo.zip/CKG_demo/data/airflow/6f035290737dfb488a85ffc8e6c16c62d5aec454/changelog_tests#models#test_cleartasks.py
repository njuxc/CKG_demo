===
match
---
name: timedelta [4970,4979]
name: timedelta [6004,6013]
===
match
---
operator: = [13002,13003]
operator: = [15169,15170]
===
match
---
name: self [7246,7250]
name: self [8980,8984]
===
match
---
argument [13122,13131]
argument [15289,15298]
===
match
---
trailer [4028,4042]
trailer [4728,4742]
===
match
---
atom_expr [2459,2473]
atom_expr [2809,2823]
===
match
---
comparison [3279,3296]
comparison [3979,3996]
===
match
---
name: state [12689,12694]
name: state [14856,14861]
===
match
---
simple_stmt [12143,12170]
simple_stmt [14310,14337]
===
match
---
name: i [12686,12687]
name: i [14853,14854]
===
match
---
arith_expr [9054,9096]
arith_expr [11221,11263]
===
match
---
simple_stmt [13580,13607]
simple_stmt [15747,15774]
===
match
---
operator: , [3549,3550]
operator: , [4249,4250]
===
match
---
simple_stmt [5682,5717]
simple_stmt [7066,7101]
===
match
---
trailer [5490,5505]
trailer [6524,6539]
===
match
---
funcdef [1424,2513]
funcdef [1424,2863]
===
match
---
suite [9114,9260]
suite [11281,11427]
===
match
---
operator: = [4508,4509]
operator: = [5542,5543]
===
match
---
name: session [3076,3083]
name: session [3426,3433]
===
match
---
name: num_of_dags [11458,11469]
name: num_of_dags [13625,13636]
===
match
---
argument [9045,9096]
argument [11212,11263]
===
match
---
name: utils [1098,1103]
name: utils [1098,1103]
===
match
---
simple_stmt [10481,10500]
simple_stmt [12648,12667]
===
match
---
name: tis [11528,11531]
name: tis [13695,13698]
===
match
---
name: filter [3130,3136]
name: filter [3809,3815]
===
match
---
trailer [4554,4562]
trailer [5588,5596]
===
match
---
operator: = [1722,1723]
operator: = [1722,1723]
===
match
---
atom_expr [9274,9384]
atom_expr [11441,11551]
===
match
---
suite [6111,7190]
suite [7495,8924]
===
match
---
name: dag_maker [3551,3560]
name: dag_maker [4251,4260]
===
match
---
trailer [3754,3908]
trailer [4454,4608]
===
match
---
operator: = [1904,1905]
operator: = [1904,1905]
===
match
---
atom_expr [1932,1960]
atom_expr [1932,1960]
===
match
---
simple_stmt [1385,1391]
simple_stmt [1385,1391]
===
match
---
atom_expr [5178,5191]
atom_expr [6212,6225]
===
match
---
assert_stmt [7095,7120]
assert_stmt [8829,8854]
===
match
---
operator: = [4203,4204]
operator: = [4903,4904]
===
match
---
trailer [12738,12749]
trailer [14905,14916]
===
match
---
trailer [4434,4438]
trailer [5468,5472]
===
match
---
trailer [5927,5938]
trailer [7311,7322]
===
match
---
name: dag [9671,9674]
name: dag [11838,11841]
===
match
---
name: dag [6795,6798]
name: dag [8508,8511]
===
match
---
name: dag [10863,10866]
name: dag [13030,13033]
===
match
---
trailer [12526,12532]
trailer [14693,14699]
===
match
---
trailer [2891,2894]
trailer [3241,3244]
===
match
---
number: 3 [12064,12065]
number: 3 [14231,14232]
===
match
---
atom_expr [11291,11303]
atom_expr [13458,13470]
===
match
---
atom_expr [13037,13069]
atom_expr [15204,15236]
===
match
---
name: ti0 [5959,5962]
name: ti0 [7343,7346]
===
match
---
atom_expr [13463,13476]
atom_expr [15630,15643]
===
match
---
operator: >> [13149,13151]
operator: >> [15316,15318]
===
match
---
comparison [10034,10052]
comparison [12201,12219]
===
match
---
arglist [6394,6420]
arglist [7778,7804]
===
match
---
expr_stmt [2937,2991]
expr_stmt [3287,3341]
===
match
---
operator: == [4592,4594]
operator: == [5626,5628]
===
match
---
trailer [5313,5320]
trailer [6347,6354]
===
match
---
name: State [1819,1824]
name: State [1819,1824]
===
match
---
atom_expr [12207,12215]
atom_expr [14374,14382]
===
match
---
trailer [11167,11174]
trailer [13334,13341]
===
match
---
name: DummyOperator [5079,5092]
name: DummyOperator [6113,6126]
===
match
---
comparison [5924,5943]
comparison [7308,7327]
===
match
---
name: dag_maker [2575,2584]
name: dag_maker [2925,2934]
===
match
---
lambdef [7626,7639]
lambdef [9360,9373]
===
match
---
operator: , [6492,6493]
operator: , [7876,7877]
===
match
---
name: task0 [1954,1959]
name: task0 [1954,1959]
===
match
---
trailer [12688,12694]
trailer [14855,14861]
===
match
---
argument [6281,6288]
argument [7665,7672]
===
match
---
operator: = [7466,7467]
operator: = [9200,9201]
===
match
---
suite [6308,6422]
suite [7692,7806]
===
match
---
name: state [4595,4600]
name: state [5629,5634]
===
match
---
operator: , [6559,6560]
operator: , [7943,7944]
===
match
---
name: dag [9110,9113]
name: dag [11277,11280]
===
match
---
name: state [4586,4591]
name: state [5620,5625]
===
match
---
with_item [4823,5006]
with_item [5857,6040]
===
match
---
operator: = [2094,2095]
operator: = [2423,2424]
===
match
---
arglist [8249,8460]
arglist [9983,10194]
===
match
---
name: execution_date [10898,10912]
name: execution_date [13065,13079]
===
match
---
trailer [8173,8179]
trailer [9907,9913]
===
match
---
argument [9020,9043]
argument [11187,11210]
===
match
---
parameters [4791,4808]
parameters [5825,5842]
===
match
---
trailer [11506,11508]
trailer [13673,13675]
===
match
---
name: dag_maker [7371,7380]
name: dag_maker [9105,9114]
===
match
---
comparison [12043,12065]
comparison [14210,14232]
===
match
---
trailer [12248,12254]
trailer [14415,14421]
===
match
---
atom_expr [3745,3908]
atom_expr [4445,4608]
===
match
---
trailer [11343,11346]
trailer [13510,13513]
===
match
---
trailer [12335,12337]
trailer [14502,14504]
===
match
---
name: TI [5639,5641]
name: TI [7002,7004]
===
match
---
assert_stmt [7164,7189]
assert_stmt [8898,8923]
===
match
---
atom_expr [5652,5662]
atom_expr [7015,7025]
===
match
---
simple_stmt [2217,2239]
simple_stmt [2567,2589]
===
match
---
trailer [7525,7535]
trailer [9259,9269]
===
match
---
arglist [5172,5235]
arglist [6206,6269]
===
match
---
name: DEFAULT_DATE [3457,3469]
name: DEFAULT_DATE [4157,4169]
===
match
---
name: ti1 [6561,6564]
name: ti1 [7945,7948]
===
match
---
operator: , [2197,2198]
operator: , [2547,2548]
===
match
---
operator: , [11042,11043]
operator: , [13209,13210]
===
match
---
simple_stmt [13290,13319]
simple_stmt [15457,15486]
===
match
---
trailer [4402,4409]
trailer [5415,5422]
===
match
---
trailer [9674,9680]
trailer [11841,11847]
===
match
---
operator: == [12102,12104]
operator: == [14269,14271]
===
match
---
operator: , [5258,5259]
operator: , [6292,6293]
===
match
---
simple_stmt [1085,1142]
simple_stmt [1085,1142]
===
match
---
argument [5042,5057]
argument [6076,6091]
===
match
---
name: RUNNING [4068,4075]
name: RUNNING [4768,4775]
===
match
---
name: op2 [13491,13494]
name: op2 [15658,15661]
===
match
---
operator: + [9067,9068]
operator: + [11234,11235]
===
match
---
name: tis [11834,11837]
name: tis [14001,14004]
===
match
---
name: ti0 [9802,9805]
name: ti0 [11969,11972]
===
match
---
number: 2 [6419,6420]
number: 2 [7803,7804]
===
match
---
trailer [9976,9980]
trailer [12143,12147]
===
match
---
argument [1691,1702]
argument [1691,1702]
===
match
---
testlist_star_expr [10481,10490]
testlist_star_expr [12648,12657]
===
match
---
name: tis [11743,11746]
name: tis [13910,13913]
===
match
---
trailer [12735,12738]
trailer [14902,14905]
===
match
---
assert_stmt [2350,2376]
assert_stmt [2700,2726]
===
match
---
name: task0 [9127,9132]
name: task0 [11294,11299]
===
match
---
name: op2 [13152,13155]
name: op2 [15319,15322]
===
match
---
name: refresh_from_task [5333,5350]
name: refresh_from_task [6367,6384]
===
match
---
name: session [3047,3054]
name: session [3397,3404]
===
match
---
simple_stmt [4272,4310]
simple_stmt [4972,5010]
===
match
---
string: '0' [3951,3954]
string: '0' [4651,4654]
===
match
---
name: refresh_from_task [9471,9488]
name: refresh_from_task [11638,11655]
===
match
---
simple_stmt [3968,4006]
simple_stmt [4668,4706]
===
match
---
name: RUNNING [1825,1832]
name: RUNNING [1825,1832]
===
match
---
trailer [2220,2236]
trailer [2570,2586]
===
match
---
suite [1471,2513]
suite [1471,2863]
===
match
---
arith_expr [6247,6289]
arith_expr [7631,7673]
===
match
---
atom_expr [9643,9657]
atom_expr [11810,11824]
===
match
---
trailer [12703,12708]
trailer [14870,14875]
===
match
---
number: 10 [4985,4987]
number: 10 [6019,6021]
===
match
---
operator: = [11034,11035]
operator: = [13201,13202]
===
match
---
name: dag [7559,7562]
name: dag [9293,9296]
===
match
---
name: tis [12211,12214]
name: tis [14378,14381]
===
match
---
name: State [2915,2920]
name: State [3265,3270]
===
match
---
trailer [10115,10131]
trailer [12282,12298]
===
match
---
atom_expr [11164,11178]
atom_expr [13331,13345]
===
match
---
name: state [4276,4281]
name: state [4976,4981]
===
match
---
name: SCHEDULED [5225,5234]
name: SCHEDULED [6259,6268]
===
match
---
name: session [4547,4554]
name: session [5581,5588]
===
match
---
expr_stmt [4138,4166]
expr_stmt [4838,4866]
===
match
---
operator: , [6289,6290]
operator: , [7673,7674]
===
match
---
arith_expr [10694,10736]
arith_expr [12861,12903]
===
match
---
testlist_comp [3389,3415]
testlist_comp [4089,4115]
===
match
---
trailer [8004,8008]
trailer [9738,9742]
===
match
---
simple_stmt [12566,12596]
simple_stmt [14733,14763]
===
match
---
trailer [8782,8805]
trailer [10949,10972]
===
match
---
name: ti1 [1900,1903]
name: ti1 [1900,1903]
===
match
---
name: ti1 [7964,7967]
name: ti1 [9698,9701]
===
match
---
trailer [4655,4662]
trailer [5689,5696]
===
match
---
atom_expr [5135,5245]
atom_expr [6169,6279]
===
match
---
simple_stmt [13769,13796]
simple_stmt [15936,15963]
===
match
---
atom_expr [12619,12635]
atom_expr [14786,14802]
===
match
---
name: commit [3084,3090]
name: commit [3434,3440]
===
match
---
operator: == [13756,13758]
operator: == [15923,15925]
===
match
---
name: start_date [4671,4681]
name: start_date [5705,5715]
===
match
---
name: session [8166,8173]
name: session [9900,9907]
===
match
---
argument [5093,5108]
argument [6127,6142]
===
match
---
simple_stmt [849,938]
simple_stmt [849,938]
===
match
---
dotted_name [854,868]
dotted_name [854,868]
===
match
---
testlist_star_expr [9430,9438]
testlist_star_expr [11597,11605]
===
match
---
name: failed_dag_idx [12179,12193]
name: failed_dag_idx [14346,14360]
===
match
---
name: tis [11574,11577]
name: tis [13741,13744]
===
match
---
operator: , [4503,4504]
operator: , [5537,5538]
===
match
---
assert_stmt [9992,10018]
assert_stmt [12159,12185]
===
match
---
arglist [6846,6858]
arglist [8580,8592]
===
match
---
argument [12955,13006]
argument [15122,15173]
===
match
---
name: DagRunType [1174,1184]
name: DagRunType [1174,1184]
===
match
---
name: dag_id [8278,8284]
name: dag_id [10012,10018]
===
match
---
operator: = [7582,7583]
operator: = [9316,9317]
===
match
---
trailer [5543,5551]
trailer [6577,6585]
===
match
---
arglist [7394,7545]
arglist [9128,9279]
===
match
---
name: ti0 [3059,3062]
name: ti0 [3409,3412]
===
match
---
simple_stmt [10362,10388]
simple_stmt [12529,12555]
===
match
---
atom_expr [13849,13862]
atom_expr [16016,16029]
===
match
---
with_stmt [7366,7756]
with_stmt [9100,9490]
===
match
---
name: refresh_from_db [11491,11506]
name: refresh_from_db [13658,13673]
===
match
---
name: try_number [12739,12749]
name: try_number [14906,14916]
===
match
---
trailer [6979,6981]
trailer [8713,8715]
===
match
---
operator: , [8343,8344]
operator: , [10077,10078]
===
match
---
trailer [1908,1923]
trailer [1908,1923]
===
match
---
name: settings [10454,10462]
name: settings [12621,12629]
===
match
---
import_as_name [881,899]
import_as_name [881,899]
===
match
---
name: tis [11616,11619]
name: tis [13783,13786]
===
match
---
trailer [9592,9603]
trailer [11759,11770]
===
match
---
operator: , [7544,7545]
operator: , [9278,9279]
===
match
---
number: 2 [11361,11362]
number: 2 [13528,13529]
===
match
---
import_from [1085,1141]
import_from [1085,1141]
===
match
---
name: DEFAULT_DATE [10913,10925]
name: DEFAULT_DATE [13080,13092]
===
match
---
trailer [5621,5627]
trailer [6984,6990]
===
match
---
name: test_clear_task_instances_without_dag [6056,6093]
name: test_clear_task_instances_without_dag [7440,7477]
===
match
---
trailer [11416,11427]
trailer [13583,13594]
===
match
---
trailer [10866,10880]
trailer [13033,13047]
===
match
---
assert_stmt [12078,12106]
assert_stmt [14245,14273]
===
match
---
assert_stmt [11827,11855]
assert_stmt [13994,14022]
===
match
---
trailer [5638,5663]
trailer [7001,7026]
===
match
---
number: 1 [9607,9608]
number: 1 [11774,11775]
===
match
---
simple_stmt [11484,11509]
simple_stmt [13651,13676]
===
match
---
operator: , [9433,9434]
operator: , [11600,11601]
===
match
---
operator: , [10626,10627]
operator: , [12793,12794]
===
match
---
operator: = [7700,7701]
operator: = [9434,9435]
===
match
---
simple_stmt [11375,11404]
simple_stmt [13542,13571]
===
match
---
comparison [11291,11320]
comparison [13458,13487]
===
match
---
number: 2 [5942,5943]
number: 2 [7326,7327]
===
match
---
name: DEFAULT_DATE [7502,7514]
name: DEFAULT_DATE [9236,9248]
===
match
---
name: end_date [4937,4945]
name: end_date [5971,5979]
===
match
---
trailer [6675,6677]
trailer [8059,8061]
===
match
---
atom_expr [13491,13515]
atom_expr [15658,15682]
===
match
---
operator: == [8728,8730]
operator: == [10826,10828]
===
match
---
number: 0 [8863,8864]
number: 0 [11030,11031]
===
match
---
atom_expr [8884,8918]
atom_expr [11051,11085]
===
match
---
operator: == [11399,11401]
operator: == [13566,13568]
===
match
---
atom_expr [9671,9682]
atom_expr [11838,11849]
===
match
---
atom_expr [3870,3897]
atom_expr [4570,4597]
===
match
---
simple_stmt [5467,5506]
simple_stmt [6501,6540]
===
match
---
name: refresh_from_db [2221,2236]
name: refresh_from_db [2571,2586]
===
match
---
atom_expr [8166,8511]
atom_expr [9900,10245]
===
match
---
operator: = [7604,7605]
operator: = [9338,9339]
===
match
---
operator: , [3897,3898]
operator: , [4597,4598]
===
match
---
assert_stmt [6021,6046]
assert_stmt [7405,7430]
===
match
---
atom_expr [10034,10047]
atom_expr [12201,12214]
===
match
---
name: refresh_from_task [7968,7985]
name: refresh_from_task [9702,9719]
===
match
---
name: create_dagrun [10867,10880]
name: create_dagrun [13034,13047]
===
match
---
trailer [6764,6770]
trailer [8477,8483]
===
match
---
simple_stmt [3571,3732]
simple_stmt [4271,4432]
===
match
---
name: dag_maker [2851,2860]
name: dag_maker [3201,3210]
===
match
---
operator: = [7848,7849]
operator: = [9582,9583]
===
match
---
testlist_star_expr [10493,10499]
testlist_star_expr [12660,12666]
===
match
---
simple_stmt [13145,13156]
simple_stmt [15312,15323]
===
match
---
name: task0 [5314,5319]
name: task0 [6348,6353]
===
match
---
assert_stmt [2385,2410]
assert_stmt [2735,2760]
===
match
---
param [12829,12834]
param [14996,15001]
===
match
---
name: append [11168,11174]
name: append [13335,13341]
===
match
---
name: max_tries [2498,2507]
name: max_tries [2848,2857]
===
match
---
name: query [3120,3125]
name: query [3799,3804]
===
match
---
comparison [13849,13867]
comparison [16016,16034]
===
match
---
name: State [9317,9322]
name: State [11484,11489]
===
match
---
argument [3846,3897]
argument [4546,4597]
===
match
---
comparison [9763,9786]
comparison [11930,11953]
===
match
---
operator: , [7442,7443]
operator: , [9176,9177]
===
match
---
atom_expr [8550,8584]
atom_expr [10284,10318]
===
match
---
funcdef [8929,10388]
funcdef [11096,12555]
===
match
---
trailer [2123,2130]
trailer [2452,2459]
===
match
---
trailer [2609,2784]
trailer [2959,3134]
===
match
---
simple_stmt [9269,9385]
simple_stmt [11436,11552]
===
match
---
operator: = [7899,7900]
operator: = [9633,9634]
===
match
---
name: start_date [12918,12928]
name: start_date [15085,15095]
===
match
---
expr_stmt [3106,3167]
expr_stmt [3785,3867]
===
match
---
name: max_tries [10373,10382]
name: max_tries [12540,12549]
===
match
---
operator: = [3854,3855]
operator: = [4554,4555]
===
match
---
name: ti2 [13776,13779]
name: ti2 [15943,15946]
===
match
---
number: 1 [8922,8923]
number: 1 [11089,11090]
===
match
---
comparison [5993,6012]
comparison [7377,7396]
===
match
---
trailer [10337,10348]
trailer [12504,12515]
===
match
---
operator: == [12007,12009]
operator: == [14174,14176]
===
match
---
simple_stmt [3047,3064]
simple_stmt [3397,3414]
===
match
---
trailer [4392,4398]
trailer [5405,5411]
===
match
---
argument [12918,12941]
argument [15085,15108]
===
match
---
trailer [10462,10470]
trailer [12629,12637]
===
match
---
assert_stmt [11284,11320]
assert_stmt [13451,13487]
===
match
---
operator: , [3455,3456]
operator: , [4155,4156]
===
match
---
assert_stmt [10327,10353]
assert_stmt [12494,12520]
===
match
---
name: clear_db_runs [1360,1373]
name: clear_db_runs [1360,1373]
===
match
---
name: dr [5130,5132]
name: dr [6164,6166]
===
match
---
atom_expr [9069,9096]
atom_expr [11236,11263]
===
match
---
atom_expr [13170,13280]
atom_expr [15337,15447]
===
match
---
atom_expr [11759,11772]
atom_expr [13926,13939]
===
match
---
argument [1299,1311]
argument [1299,1311]
===
match
---
assert_stmt [5986,6012]
assert_stmt [7370,7396]
===
match
---
argument [5110,5119]
argument [6144,6153]
===
match
---
name: ti0 [5255,5258]
name: ti0 [6289,6292]
===
match
---
atom_expr [10062,10073]
atom_expr [12229,12240]
===
match
---
name: max_tries [13853,13862]
name: max_tries [16020,16029]
===
match
---
operator: = [2849,2850]
operator: = [3199,3200]
===
match
---
atom_expr [6668,6677]
atom_expr [8052,8061]
===
match
---
atom_expr [5525,5552]
atom_expr [6559,6586]
===
match
---
comparison [12520,12549]
comparison [14687,14716]
===
match
---
string: 'test_clear_task_instances_without_task' [4846,4886]
string: 'test_clear_task_instances_without_task' [5880,5920]
===
match
---
string: 'task0' [5050,5057]
string: 'task0' [6084,6091]
===
match
---
name: dag [4423,4426]
name: dag [5436,5439]
===
match
---
name: db [1400,1402]
name: db [1400,1402]
===
match
---
trailer [6633,6651]
trailer [8017,8035]
===
match
---
atom_expr [8906,8917]
atom_expr [11073,11084]
===
match
---
name: max_tries [13467,13476]
name: max_tries [15634,15643]
===
match
---
arglist [10600,10737]
arglist [12767,12904]
===
match
---
name: SUCCESS [11765,11772]
name: SUCCESS [13932,13939]
===
match
---
comparison [12619,12640]
comparison [14786,14807]
===
match
---
expr_stmt [5130,5245]
expr_stmt [6164,6279]
===
match
---
operator: = [7625,7626]
operator: = [9359,9360]
===
match
---
name: Session [10463,10470]
name: Session [12630,12637]
===
match
---
simple_stmt [6751,6813]
simple_stmt [8464,8547]
===
match
---
name: i [10624,10625]
name: i [12791,12792]
===
match
---
name: max_tries [5963,5972]
name: max_tries [7347,7356]
===
match
---
number: 1 [12218,12219]
number: 1 [14385,14386]
===
match
---
parameters [1453,1470]
parameters [1453,1470]
===
match
---
name: State [11759,11764]
name: State [13926,13931]
===
match
---
name: start_date [6201,6211]
name: start_date [7585,7595]
===
match
---
name: DEFAULT_DATE [9031,9043]
name: DEFAULT_DATE [11198,11210]
===
match
---
import_name [805,818]
import_name [805,818]
===
match
---
name: state [2430,2435]
name: state [2780,2785]
===
match
---
assert_stmt [13421,13447]
assert_stmt [15588,15614]
===
match
---
name: try_number [5997,6007]
name: try_number [7381,7391]
===
match
---
simple_stmt [9467,9496]
simple_stmt [11634,11663]
===
match
---
name: create_dagrun [7780,7793]
name: create_dagrun [9514,9527]
===
match
---
trailer [5332,5350]
trailer [6366,6384]
===
match
---
operator: == [4420,4422]
operator: == [5433,5435]
===
match
---
suite [1278,13868]
suite [1278,16035]
===
match
---
trailer [6671,6675]
trailer [8055,8059]
===
match
---
name: qry [4379,4382]
name: qry [5392,5395]
===
match
---
assert_stmt [7060,7086]
assert_stmt [8794,8820]
===
match
---
expr_stmt [5608,5669]
expr_stmt [6971,7053]
===
match
---
atom_expr [11994,12006]
atom_expr [14161,14173]
===
match
---
number: 10 [1634,1636]
number: 10 [1634,1636]
===
match
---
atom_expr [7964,7992]
atom_expr [9698,9726]
===
match
---
name: i [11532,11533]
name: i [13699,13700]
===
match
---
testlist_star_expr [7890,7898]
testlist_star_expr [9624,9632]
===
match
---
lambdef [7722,7735]
lambdef [9456,9469]
===
match
---
trailer [8022,8026]
trailer [9756,9760]
===
match
---
assert_stmt [11736,11772]
assert_stmt [13903,13939]
===
match
---
atom_expr [12321,12337]
atom_expr [14488,14504]
===
match
---
operator: , [6535,6536]
operator: , [7919,7920]
===
match
---
name: qry [6846,6849]
name: qry [8580,8583]
===
match
---
assert_stmt [9721,9747]
assert_stmt [11888,11914]
===
match
---
parameters [1341,1347]
parameters [1341,1347]
===
match
---
assert_stmt [8602,8648]
assert_stmt [10336,10382]
===
match
---
assert_stmt [12566,12595]
assert_stmt [14733,14762]
===
match
---
expr_stmt [10444,10472]
expr_stmt [12611,12639]
===
match
---
name: count [8504,8509]
name: count [10238,10243]
===
match
---
comparison [2426,2443]
comparison [2776,2793]
===
match
---
name: dag [10840,10843]
name: dag [13007,13010]
===
match
---
name: task_id [7693,7700]
name: task_id [9427,9434]
===
match
---
simple_stmt [13327,13342]
simple_stmt [15494,15509]
===
match
---
name: dr [4668,4670]
name: dr [5702,5704]
===
match
---
operator: , [6187,6188]
operator: , [7571,7572]
===
match
---
comparison [11792,11814]
comparison [13959,13981]
===
match
---
expr_stmt [2845,2894]
expr_stmt [3195,3244]
===
match
---
atom_expr [9837,9850]
atom_expr [12004,12017]
===
match
---
name: TI [4399,4401]
name: TI [5412,5414]
===
match
---
param [3534,3550]
param [4234,4250]
===
match
---
operator: , [4886,4887]
operator: , [5920,5921]
===
match
---
name: ti1 [13587,13590]
name: ti1 [15754,15757]
===
match
---
name: TI [6782,6784]
name: TI [8495,8497]
===
match
---
name: create_dagrun [13180,13193]
name: create_dagrun [15347,15360]
===
match
---
operator: , [3416,3417]
operator: , [4116,4117]
===
match
---
operator: = [5100,5101]
operator: = [6134,6135]
===
match
---
name: autouse [1299,1306]
name: autouse [1299,1306]
===
match
---
name: task_id [8720,8727]
name: task_id [10818,10825]
===
match
---
trailer [9680,9682]
trailer [11847,11849]
===
match
---
simple_stmt [2007,2017]
simple_stmt [2007,2017]
===
match
---
operator: , [2573,2574]
operator: , [2923,2924]
===
match
---
simple_stmt [7129,7156]
simple_stmt [8863,8890]
===
match
---
name: dr [4583,4585]
name: dr [5617,5619]
===
match
---
simple_stmt [7964,7993]
simple_stmt [9698,9727]
===
match
---
atom_expr [3279,3288]
atom_expr [3979,3988]
===
match
---
comparison [2121,2144]
comparison [2450,2473]
===
match
---
trailer [3319,3340]
trailer [4019,4040]
===
match
---
atom_expr [5478,5505]
atom_expr [6512,6539]
===
match
---
atom_expr [12698,12708]
atom_expr [14865,14875]
===
match
---
parameters [8947,8964]
parameters [11114,11131]
===
match
---
atom_expr [6567,6584]
atom_expr [7951,7968]
===
match
---
name: airflow [1090,1097]
name: airflow [1090,1097]
===
match
---
simple_stmt [6960,6982]
simple_stmt [8694,8716]
===
match
---
name: tis [11259,11262]
name: tis [13426,13429]
===
match
---
param [2575,2584]
param [2925,2934]
===
match
---
assert_stmt [10234,10260]
assert_stmt [12401,12427]
===
match
---
simple_stmt [5255,5284]
simple_stmt [6289,6318]
===
match
---
trailer [2818,2835]
trailer [3168,3185]
===
match
---
name: utils [1155,1160]
name: utils [1155,1160]
===
match
---
atom_expr [13742,13755]
atom_expr [15909,15922]
===
match
---
comparison [11382,11403]
comparison [13549,13570]
===
match
---
name: ti1 [6630,6633]
name: ti1 [8014,8017]
===
match
---
operator: = [1559,1560]
operator: = [1559,1560]
===
match
---
name: session [8667,8674]
name: session [10748,10755]
===
match
---
name: dr [8394,8396]
name: dr [10128,10130]
===
match
---
argument [6201,6224]
argument [7585,7608]
===
match
---
atom_expr [13301,13318]
atom_expr [15468,15485]
===
match
---
simple_stmt [5292,5321]
simple_stmt [6326,6355]
===
match
---
atom_expr [1776,1886]
atom_expr [1776,1886]
===
match
---
name: dag_maker [7252,7261]
name: dag_maker [8986,8995]
===
match
---
name: State [11307,11312]
name: State [13474,13479]
===
match
---
operator: == [2406,2408]
operator: == [2756,2758]
===
match
---
name: TaskReschedule [8180,8194]
name: TaskReschedule [9914,9928]
===
match
---
name: DummyOperator [2805,2818]
name: DummyOperator [3155,3168]
===
match
---
atom_expr [5440,5453]
atom_expr [6474,6487]
===
match
---
name: i [12089,12090]
name: i [14256,14257]
===
match
---
operator: = [2826,2827]
operator: = [3176,3177]
===
match
---
name: airflow [943,950]
name: airflow [943,950]
===
match
---
trailer [11879,11899]
trailer [14046,14066]
===
match
---
number: 1 [9819,9820]
number: 1 [11986,11987]
===
match
---
operator: , [4141,4142]
operator: , [4841,4842]
===
match
---
operator: = [13058,13059]
operator: = [15225,15226]
===
match
---
operator: = [6327,6328]
operator: = [7711,7712]
===
match
---
operator: , [8952,8953]
operator: , [11119,11120]
===
match
---
atom_expr [8572,8583]
atom_expr [10306,10317]
===
match
---
operator: != [12478,12480]
operator: != [14645,14647]
===
match
---
simple_stmt [13456,13482]
simple_stmt [15623,15649]
===
match
---
trailer [12203,12220]
trailer [14370,14387]
===
match
---
operator: == [10048,10050]
operator: == [12215,12217]
===
match
---
name: NONE [9782,9786]
name: NONE [11949,11953]
===
match
---
simple_stmt [2452,2479]
simple_stmt [2802,2829]
===
match
---
suite [10419,12800]
suite [12586,14967]
===
match
---
operator: , [5234,5235]
operator: , [6268,6269]
===
match
---
name: ti1 [4272,4275]
name: ti1 [4972,4975]
===
match
---
trailer [4670,4681]
trailer [5704,5715]
===
match
---
name: test_clear_task_instances_dr_state [3486,3520]
name: test_clear_task_instances_dr_state [4186,4220]
===
match
---
trailer [5537,5552]
trailer [6571,6586]
===
match
---
name: dr [1771,1773]
name: dr [1771,1773]
===
match
---
name: query [4393,4398]
name: query [5406,5411]
===
match
---
trailer [12622,12625]
trailer [14789,14792]
===
match
---
trailer [1799,1886]
trailer [1799,1886]
===
match
---
trailer [12439,12442]
trailer [14606,14609]
===
match
---
name: session [4475,4482]
name: session [5509,5516]
===
match
---
trailer [11457,11470]
trailer [13624,13637]
===
match
---
name: DummyOperator [6380,6393]
name: DummyOperator [7764,7777]
===
match
---
number: 1 [8588,8589]
number: 1 [10322,10323]
===
match
---
trailer [10085,10101]
trailer [12252,12268]
===
match
---
trailer [5041,5058]
trailer [6075,6092]
===
match
---
operator: = [9223,9224]
operator: = [11390,11391]
===
match
---
number: 1 [2409,2410]
number: 1 [2759,2760]
===
match
---
with_stmt [3001,3349]
with_stmt [3351,4049]
===
match
---
name: state [1104,1109]
name: state [1104,1109]
===
match
---
atom_expr [8609,8643]
atom_expr [10343,10377]
===
match
---
trailer [8909,8917]
trailer [11076,11084]
===
match
---
atom_expr [11918,11936]
atom_expr [14085,14103]
===
match
---
trailer [7930,7948]
trailer [9664,9682]
===
match
---
trailer [4255,4263]
trailer [4955,4963]
===
match
---
operator: == [8333,8335]
operator: == [10067,10069]
===
match
---
simple_stmt [805,819]
simple_stmt [805,819]
===
match
---
operator: = [6246,6247]
operator: = [7630,7631]
===
match
---
comparison [10241,10260]
comparison [12408,12427]
===
match
---
simple_stmt [5130,5246]
simple_stmt [6164,6280]
===
match
---
simple_stmt [11827,11856]
simple_stmt [13994,14023]
===
match
---
name: session [1055,1062]
name: session [1055,1062]
===
match
---
number: 10 [9093,9095]
number: 10 [11260,11262]
===
match
---
name: ti1 [8631,8634]
name: ti1 [10365,10368]
===
match
---
atom_expr [11792,11809]
atom_expr [13959,13976]
===
match
---
expr_stmt [6321,6359]
expr_stmt [7705,7743]
===
match
---
atom_expr [12436,12460]
atom_expr [14603,14627]
===
match
---
number: 1 [13130,13131]
number: 1 [15297,15298]
===
match
---
name: tis [11711,11714]
name: tis [13878,13881]
===
match
---
trailer [2462,2473]
trailer [2812,2823]
===
match
---
operator: = [8800,8801]
operator: = [10967,10968]
===
match
---
argument [4089,4118]
argument [4789,4818]
===
match
---
for_stmt [11670,11856]
for_stmt [13837,14023]
===
match
---
name: task_id [8735,8742]
name: task_id [10833,10840]
===
match
---
atom_expr [1400,1418]
atom_expr [1400,1418]
===
match
---
atom_expr [6795,6805]
atom_expr [8508,8518]
===
match
---
trailer [7692,7755]
trailer [9426,9489]
===
match
---
name: num_of_dags [11685,11696]
name: num_of_dags [13852,13863]
===
match
---
expr_stmt [4318,4345]
expr_stmt [5018,5045]
===
match
---
name: datetime [12979,12987]
name: datetime [15146,15154]
===
match
---
atom_expr [3442,3455]
atom_expr [4142,4155]
===
match
---
operator: == [10256,10258]
operator: == [12423,12425]
===
match
---
arith_expr [1595,1637]
arith_expr [1595,1637]
===
match
---
name: DEFAULT_DATE [9054,9066]
name: DEFAULT_DATE [11221,11233]
===
match
---
operator: = [12194,12195]
operator: = [14361,14362]
===
match
---
operator: = [6211,6212]
operator: = [7595,7596]
===
match
---
name: merge [12286,12291]
name: merge [14453,14458]
===
match
---
string: 'task1' [6402,6409]
string: 'task1' [7786,7793]
===
match
---
name: randint [12196,12203]
name: randint [14363,14370]
===
match
---
trailer [12541,12549]
trailer [14708,14716]
===
match
---
name: tis [12436,12439]
name: tis [14603,14606]
===
match
---
trailer [4979,4988]
trailer [6013,6022]
===
match
---
atom_expr [9135,9181]
atom_expr [11302,11348]
===
match
---
trailer [2920,2928]
trailer [3270,3278]
===
match
---
name: task_instances [7904,7918]
name: task_instances [9638,9652]
===
match
---
name: ti0 [2217,2220]
name: ti0 [2567,2570]
===
match
---
trailer [8008,8010]
trailer [9742,9744]
===
match
---
name: max_tries [6032,6041]
name: max_tries [7416,7425]
===
match
---
name: session [11027,11034]
name: session [13194,13201]
===
match
---
arglist [4470,4512]
arglist [5504,5546]
===
match
---
name: dag [3150,3153]
name: dag [3829,3832]
===
match
---
atom_expr [4823,4999]
atom_expr [5857,6033]
===
match
---
name: dag_maker [2600,2609]
name: dag_maker [2950,2959]
===
match
---
atom_expr [9864,9878]
atom_expr [12031,12045]
===
match
---
operator: = [9401,9402]
operator: = [11568,11569]
===
match
---
name: clear_task_instances [8762,8782]
name: clear_task_instances [10929,10949]
===
match
---
assert_stmt [4576,4600]
assert_stmt [5610,5634]
===
match
---
name: python_callable [7610,7625]
name: python_callable [9344,9359]
===
match
---
number: 1 [8458,8459]
number: 1 [10192,10193]
===
match
---
name: DummyOperator [9202,9215]
name: DummyOperator [11369,11382]
===
match
---
atom_expr [7171,7184]
atom_expr [8905,8918]
===
match
---
operator: = [10948,10949]
operator: = [13115,13116]
===
match
---
name: dr [7901,7903]
name: dr [9635,9637]
===
match
---
atom_expr [11227,11245]
atom_expr [13394,13412]
===
match
---
argument [6411,6420]
argument [7795,7804]
===
match
---
operator: == [11304,11306]
operator: == [13471,13473]
===
match
---
name: TI [3126,3128]
name: TI [3805,3807]
===
match
---
dotted_name [993,1015]
dotted_name [993,1015]
===
match
---
expr_stmt [5255,5283]
expr_stmt [6289,6317]
===
match
---
atom_expr [6630,6658]
atom_expr [8014,8042]
===
match
---
atom_expr [5491,5504]
atom_expr [6525,6538]
===
match
---
number: 1 [13480,13481]
number: 1 [15647,15648]
===
match
---
name: TaskInstanceState [4284,4301]
name: TaskInstanceState [4984,5001]
===
match
---
name: dag [8705,8708]
name: dag [10803,10806]
===
match
---
atom_expr [2324,2333]
atom_expr [2674,2683]
===
match
---
name: dag [1652,1655]
name: dag [1652,1655]
===
match
---
trailer [2327,2333]
trailer [2677,2683]
===
match
---
trailer [11534,11540]
trailer [13701,13707]
===
match
---
trailer [4275,4281]
trailer [4975,4981]
===
match
---
operator: , [6224,6225]
operator: , [7608,7609]
===
match
---
atom_expr [3237,3258]
atom_expr [3937,3958]
===
match
---
name: tis [11484,11487]
name: tis [13651,13654]
===
match
---
number: 2 [9661,9662]
number: 2 [11828,11829]
===
match
---
operator: = [5454,5455]
operator: = [6488,6489]
===
match
---
name: max_tries [9806,9815]
name: max_tries [11973,11982]
===
match
---
comparison [11834,11855]
comparison [14001,14022]
===
match
---
atom_expr [7136,7150]
atom_expr [8870,8884]
===
match
---
name: dag_maker [4328,4337]
name: dag_maker [5028,5037]
===
match
---
simple_stmt [13491,13516]
simple_stmt [15658,15683]
===
match
---
name: max_tries [11389,11398]
name: max_tries [13556,13565]
===
match
---
simple_stmt [2025,2035]
simple_stmt [2025,2035]
===
match
---
operator: = [4984,4985]
operator: = [6018,6019]
===
match
---
atom_expr [9467,9495]
atom_expr [11634,11662]
===
match
---
name: PythonSensor [1023,1035]
name: PythonSensor [1023,1035]
===
match
---
name: operators [951,960]
name: operators [951,960]
===
match
---
comparison [7136,7155]
comparison [8870,8889]
===
match
---
trailer [4042,4129]
trailer [4742,4829]
===
match
---
simple_stmt [1357,1376]
simple_stmt [1357,1376]
===
match
---
name: State [9776,9781]
name: State [11943,11948]
===
match
---
name: end_date [6238,6246]
name: end_date [7622,7630]
===
match
---
name: dr [7765,7767]
name: dr [9499,9501]
===
match
---
operator: , [7893,7894]
operator: , [9627,9628]
===
match
---
expr_stmt [6556,6584]
expr_stmt [7940,7968]
===
match
---
operator: , [13226,13227]
operator: , [15393,15394]
===
match
---
expr_stmt [4175,4217]
expr_stmt [4875,4917]
===
match
---
atom_expr [9763,9772]
atom_expr [11930,11939]
===
match
---
atom_expr [11711,11723]
atom_expr [13878,13890]
===
match
---
name: clean [1336,1341]
name: clean [1336,1341]
===
match
---
argument [9216,9247]
argument [11383,11414]
===
match
---
name: DAG [10579,10582]
name: DAG [12746,12749]
===
match
---
string: 'test_task_clear_' [10793,10811]
string: 'test_task_clear_' [12960,12978]
===
match
---
name: RUNNING [10955,10962]
name: RUNNING [13122,13129]
===
match
---
trailer [8630,8643]
trailer [10364,10377]
===
match
---
name: dags [11880,11884]
name: dags [14047,14051]
===
match
---
atom_expr [6479,6492]
atom_expr [7863,7876]
===
match
---
name: try_number [11799,11809]
name: try_number [13966,13976]
===
match
---
name: range [11679,11684]
name: range [13846,13851]
===
match
---
operator: == [2508,2510]
operator: == [2858,2860]
===
match
---
trailer [2940,2961]
trailer [3290,3311]
===
match
---
name: RUNNING [5184,5191]
name: RUNNING [6218,6225]
===
match
---
trailer [2764,2773]
trailer [3114,3123]
===
match
---
name: task_id [5042,5049]
name: task_id [6076,6083]
===
match
---
trailer [6963,6979]
trailer [8697,8713]
===
match
---
atom_expr [6515,6535]
atom_expr [7899,7919]
===
match
---
comparison [2324,2341]
comparison [2674,2691]
===
match
---
name: TI [4410,4412]
name: TI [5423,5425]
===
match
---
comparison [10334,10353]
comparison [12501,12520]
===
match
---
operator: - [12216,12217]
operator: - [14383,14384]
===
match
---
simple_stmt [10082,10104]
simple_stmt [12249,12271]
===
match
---
name: task1 [5538,5543]
name: task1 [6572,6577]
===
match
---
name: pytest [812,818]
name: pytest [812,818]
===
match
---
operator: , [2671,2672]
operator: , [3021,3022]
===
match
---
comparison [9999,10018]
comparison [12166,12185]
===
match
---
operator: , [5108,5109]
operator: , [6142,6143]
===
match
---
argument [9344,9373]
argument [11511,11540]
===
match
---
name: task_instances [6570,6584]
name: task_instances [7954,7968]
===
match
---
operator: , [9043,9044]
operator: , [11210,11211]
===
match
---
trailer [8905,8918]
trailer [11072,11085]
===
match
---
trailer [3058,3063]
trailer [3408,3413]
===
match
---
string: 'test_dag_clear' [9002,9018]
string: 'test_dag_clear' [11169,11185]
===
match
---
name: refresh_from_db [6964,6979]
name: refresh_from_db [8698,8713]
===
match
---
atom_expr [9589,9603]
atom_expr [11756,11770]
===
match
---
name: ti0 [5924,5927]
name: ti0 [7308,7311]
===
match
---
name: i [11620,11621]
name: i [13787,13788]
===
match
---
name: random [12148,12154]
name: random [14315,14321]
===
match
---
arglist [4056,4119]
arglist [4756,4819]
===
match
---
name: try_number [7140,7150]
name: try_number [8874,8884]
===
match
---
name: i [11838,11839]
name: i [14005,14006]
===
match
---
name: self [4792,4796]
name: self [5826,5830]
===
match
---
suite [2586,3349]
suite [2936,4049]
===
match
---
name: python_callable [7706,7721]
name: python_callable [9440,9455]
===
match
---
trailer [6270,6280]
trailer [7654,7664]
===
match
---
trailer [10784,10844]
trailer [12951,13011]
===
match
---
name: end_date [9045,9053]
name: end_date [11212,11220]
===
match
---
name: ti1 [1969,1972]
name: ti1 [1969,1972]
===
match
---
atom_expr [8394,8403]
atom_expr [10128,10137]
===
match
---
trailer [8634,8642]
trailer [10368,10376]
===
match
---
name: state [5172,5177]
name: state [6206,6211]
===
match
---
simple_stmt [7164,7190]
simple_stmt [8898,8924]
===
match
---
operator: , [7869,7870]
operator: , [9603,9604]
===
match
---
name: ti2 [13849,13852]
name: ti2 [16016,16019]
===
match
---
trailer [5667,5669]
trailer [7051,7053]
===
match
---
atom_expr [12404,12422]
atom_expr [14571,14589]
===
match
---
atom_expr [4098,4118]
atom_expr [4798,4818]
===
match
---
simple_stmt [7576,7660]
simple_stmt [9310,9394]
===
match
---
name: run [2011,2014]
name: run [2011,2014]
===
match
---
atom_expr [12682,12694]
atom_expr [14849,14861]
===
match
---
operator: = [9092,9093]
operator: = [11259,11260]
===
match
---
atom_expr [10112,10133]
atom_expr [12279,12300]
===
match
---
expr_stmt [4272,4309]
expr_stmt [4972,5009]
===
match
---
simple_stmt [8137,8530]
simple_stmt [9871,10264]
===
match
---
name: days [12998,13002]
name: days [15165,15169]
===
match
---
trailer [11746,11749]
trailer [13913,13916]
===
match
---
dotted_name [1041,1062]
dotted_name [1041,1062]
===
match
---
name: state [3527,3532]
name: state [4227,4232]
===
match
---
atom_expr [4226,4235]
atom_expr [4926,4935]
===
match
---
name: tis [12619,12622]
name: tis [14786,14789]
===
match
---
suite [2077,2208]
suite [2077,2558]
===
match
---
simple_stmt [1036,1085]
simple_stmt [1036,1085]
===
match
---
name: refresh_from_db [3241,3256]
name: refresh_from_db [3941,3956]
===
match
---
trailer [4969,4979]
trailer [6003,6013]
===
match
---
simple_stmt [6021,6047]
simple_stmt [7405,7431]
===
match
---
operator: = [6478,6479]
operator: = [7862,7863]
===
match
---
atom_expr [2937,2961]
atom_expr [3287,3311]
===
match
---
trailer [6774,6781]
trailer [8487,8494]
===
match
---
decorated [1283,1419]
decorated [1283,1419]
===
match
---
atom_expr [5959,5972]
atom_expr [7343,7356]
===
match
---
number: 10 [3894,3896]
number: 10 [4594,4596]
===
match
---
simple_stmt [4138,4167]
simple_stmt [4838,4867]
===
match
---
atom_expr [10082,10103]
atom_expr [12249,12270]
===
match
---
name: failed_dag_idx [12233,12247]
name: failed_dag_idx [14400,14414]
===
match
---
string: 'bash_op' [13059,13068]
string: 'bash_op' [15226,15235]
===
match
---
import_from [820,848]
import_from [820,848]
===
match
---
funcdef [2518,3349]
funcdef [2868,4049]
===
match
---
simple_stmt [10112,10134]
simple_stmt [12279,12301]
===
match
---
name: dr [9269,9271]
name: dr [11436,11438]
===
match
---
assert_stmt [12036,12065]
assert_stmt [14203,14232]
===
match
---
trailer [8684,8691]
trailer [10782,10789]
===
match
---
trailer [4367,4369]
trailer [5067,5069]
===
match
---
atom_expr [10814,10820]
atom_expr [12981,12987]
===
match
---
name: ti0 [9467,9470]
name: ti0 [11634,11637]
===
match
---
operator: == [7151,7153]
operator: == [8885,8887]
===
match
---
name: task [11118,11122]
name: task [13285,13289]
===
match
---
name: ti0 [7890,7893]
name: ti0 [9624,9627]
===
match
---
suite [12846,13868]
suite [15013,16035]
===
match
---
atom_expr [7102,7115]
atom_expr [8836,8849]
===
match
---
operator: = [9156,9157]
operator: = [11323,11324]
===
match
---
atom_expr [9317,9330]
atom_expr [11484,11497]
===
match
---
name: task1 [7672,7677]
name: task1 [9406,9411]
===
match
---
simple_stmt [9864,9883]
simple_stmt [12031,12050]
===
match
---
name: State [12010,12015]
name: State [14177,14182]
===
match
---
dotted_name [1228,1244]
dotted_name [1228,1244]
===
match
---
name: task0 [7949,7954]
name: task0 [9683,9688]
===
match
---
argument [3943,3954]
argument [4643,4654]
===
match
---
name: ti2 [13428,13431]
name: ti2 [15595,15598]
===
match
---
simple_stmt [4379,4441]
simple_stmt [5392,5475]
===
match
---
string: '0' [1699,1702]
string: '0' [1699,1702]
===
match
---
atom_expr [4175,4202]
atom_expr [4875,4902]
===
match
---
atom_expr [8667,8749]
atom_expr [10748,10902]
===
match
---
argument [13102,13120]
argument [15269,15287]
===
match
---
argument [10644,10667]
argument [12811,12834]
===
match
---
operator: , [7826,7827]
operator: , [9560,9561]
===
match
---
name: external_executor_id [2941,2961]
name: external_executor_id [3291,3311]
===
match
---
name: dr [4014,4016]
name: dr [4714,4716]
===
match
---
atom_expr [10334,10348]
atom_expr [12501,12515]
===
match
---
name: dag_id [3140,3146]
name: dag_id [3819,3825]
===
match
---
trailer [2137,2144]
trailer [2466,2473]
===
match
---
trailer [1972,1990]
trailer [1972,1990]
===
match
---
atom_expr [3420,3432]
atom_expr [4120,4132]
===
match
---
simple_stmt [9756,9787]
simple_stmt [11923,11954]
===
match
---
trailer [5224,5234]
trailer [6258,6268]
===
match
---
expr_stmt [1771,1886]
expr_stmt [1771,1886]
===
match
---
arith_expr [10793,10820]
arith_expr [12960,12987]
===
match
---
name: TI [2121,2123]
name: TI [2450,2452]
===
match
---
trailer [13381,13383]
trailer [15548,15550]
===
match
---
operator: = [4282,4283]
operator: = [4982,4983]
===
match
---
name: tests [1190,1195]
name: tests [1190,1195]
===
match
---
name: TI [8692,8694]
name: TI [10790,10792]
===
match
---
name: start_date [3809,3819]
name: start_date [4509,4519]
===
match
---
atom_expr [5367,5376]
atom_expr [6401,6410]
===
match
---
simple_stmt [1969,1998]
simple_stmt [1969,1998]
===
match
---
operator: , [915,916]
operator: , [915,916]
===
match
---
operator: == [13443,13445]
operator: == [15610,15612]
===
match
---
trailer [3129,3136]
trailer [3808,3815]
===
match
---
name: count_task_reschedule [8089,8110]
name: count_task_reschedule [9823,9844]
===
match
---
name: range [11918,11923]
name: range [14085,14090]
===
match
---
atom_expr [6757,6812]
atom_expr [8470,8546]
===
match
---
name: try_number [9647,9657]
name: try_number [11814,11824]
===
match
---
atom_expr [10863,11057]
atom_expr [13030,13224]
===
match
---
name: DEFAULT_DATE [4911,4923]
name: DEFAULT_DATE [5945,5957]
===
match
---
name: ti1 [10207,10210]
name: ti1 [12374,12377]
===
match
---
name: state [4641,4646]
name: state [5675,5680]
===
match
---
trailer [5836,5838]
trailer [7220,7222]
===
match
---
operator: == [11358,11360]
operator: == [13525,13527]
===
match
---
name: TaskInstanceState [4238,4255]
name: TaskInstanceState [4938,4955]
===
match
---
operator: = [1306,1307]
operator: = [1306,1307]
===
match
---
name: qry [3106,3109]
name: qry [3785,3788]
===
match
---
number: 3 [2511,2512]
number: 3 [2861,2862]
===
match
---
name: dag_id [8695,8701]
name: dag_id [10793,10799]
===
match
---
trailer [6393,6421]
trailer [7777,7805]
===
match
---
trailer [6134,6300]
trailer [7518,7684]
===
match
---
atom_expr [4385,4440]
atom_expr [5398,5474]
===
match
---
operator: = [8665,8666]
operator: = [10728,10729]
===
match
---
name: timedelta [9078,9087]
name: timedelta [11245,11254]
===
match
---
trailer [9077,9087]
trailer [11244,11254]
===
match
---
simple_stmt [9691,9713]
simple_stmt [11858,11880]
===
match
---
for_stmt [11218,11404]
for_stmt [13385,13571]
===
match
---
name: SUCCESS [4256,4263]
name: SUCCESS [4956,4963]
===
match
---
name: task_id [8336,8343]
name: task_id [10070,10077]
===
match
---
operator: , [8459,8460]
operator: , [10193,10194]
===
match
---
name: retries [9249,9256]
name: retries [11416,11423]
===
match
---
suite [7563,7756]
suite [9297,9490]
===
match
---
atom_expr [11340,11357]
atom_expr [13507,13524]
===
match
---
name: tis [12732,12735]
name: tis [14899,14902]
===
match
---
argument [4980,4987]
argument [6014,6021]
===
match
---
simple_stmt [820,849]
simple_stmt [820,849]
===
match
---
arglist [8783,8804]
arglist [10950,10971]
===
match
---
atom_expr [13428,13442]
atom_expr [15595,15609]
===
match
---
simple_stmt [1932,1961]
simple_stmt [1932,1961]
===
match
---
name: state [9767,9772]
name: state [11934,11939]
===
match
---
trailer [4438,4440]
trailer [5472,5474]
===
match
---
name: session [9413,9420]
name: session [11580,11587]
===
match
---
atom_expr [9999,10013]
atom_expr [12166,12180]
===
match
---
trailer [1618,1628]
trailer [1618,1628]
===
match
---
with_stmt [6120,6422]
with_stmt [7504,7806]
===
match
---
name: count_task_reschedule [8825,8846]
name: count_task_reschedule [10992,11013]
===
match
---
arglist [9216,9258]
arglist [11383,11425]
===
match
---
assert_stmt [9756,9786]
assert_stmt [11923,11953]
===
match
---
suite [12658,12800]
suite [14825,14967]
===
match
---
name: TI [897,899]
name: TI [897,899]
===
match
---
atom_expr [6782,6791]
atom_expr [8495,8504]
===
match
---
simple_stmt [1895,1924]
simple_stmt [1895,1924]
===
match
---
name: commit [12329,12335]
name: commit [14496,14502]
===
match
---
operator: = [7812,7813]
operator: = [9546,9547]
===
match
---
simple_stmt [1771,1887]
simple_stmt [1771,1887]
===
match
---
name: task [13354,13358]
name: task [15521,15525]
===
match
---
trailer [1628,1637]
trailer [1628,1637]
===
match
---
simple_stmt [12229,12270]
simple_stmt [14396,14437]
===
match
---
name: run_id [8397,8403]
name: run_id [10131,10137]
===
match
---
name: session [9393,9400]
name: session [11560,11567]
===
match
---
argument [3215,3222]
argument [3915,3922]
===
match
---
operator: , [10667,10668]
operator: , [12834,12835]
===
match
---
atom_expr [11865,11899]
atom_expr [14032,14066]
===
match
---
simple_stmt [12078,12107]
simple_stmt [14245,14274]
===
match
---
trailer [12781,12784]
trailer [14948,14951]
===
match
---
name: qry [5703,5706]
name: qry [7087,7090]
===
match
---
trailer [4108,4118]
trailer [4808,4818]
===
match
---
name: ti0 [4226,4229]
name: ti0 [4926,4929]
===
match
---
name: DagRunType [6515,6525]
name: DagRunType [7899,7909]
===
match
---
trailer [12523,12526]
trailer [14690,14693]
===
match
---
trailer [13531,13533]
trailer [15698,15700]
===
match
---
atom_expr [12347,12385]
atom_expr [14514,14552]
===
match
---
name: i [12399,12400]
name: i [14566,14567]
===
match
---
simple_stmt [8661,8750]
simple_stmt [10724,10917]
===
match
---
argument [1751,1760]
argument [1751,1760]
===
match
---
name: task_id [3943,3950]
name: task_id [4643,4650]
===
match
---
simple_stmt [2385,2411]
simple_stmt [2735,2761]
===
match
---
simple_stmt [7060,7087]
simple_stmt [8794,8821]
===
match
---
classdef [1257,13868]
classdef [1257,16035]
===
match
---
simple_stmt [4547,4567]
simple_stmt [5581,5601]
===
match
---
name: TaskInstance [881,893]
name: TaskInstance [881,893]
===
match
---
name: create_dagrun [6446,6459]
name: create_dagrun [7830,7843]
===
match
---
trailer [2149,2151]
trailer [2499,2501]
===
match
---
operator: = [13035,13036]
operator: = [15202,15203]
===
match
---
name: task0 [6321,6326]
name: task0 [7705,7710]
===
match
---
operator: , [6409,6410]
operator: , [7793,7794]
===
match
---
simple_stmt [12036,12066]
simple_stmt [14203,14233]
===
match
---
argument [2819,2834]
argument [3169,3184]
===
match
---
simple_stmt [11413,11434]
simple_stmt [13580,13601]
===
match
---
name: parametrize [3367,3378]
name: parametrize [4067,4078]
===
match
---
name: ti2 [13350,13353]
name: ti2 [15517,15520]
===
match
---
operator: == [9851,9853]
operator: == [12018,12020]
===
match
---
trailer [12285,12291]
trailer [14452,14458]
===
match
---
atom_expr [1819,1832]
atom_expr [1819,1832]
===
match
---
not_test [5474,5505]
not_test [6508,6539]
===
match
---
trailer [10999,11009]
trailer [13166,13176]
===
match
---
assert_stmt [12612,12640]
assert_stmt [14779,14807]
===
match
---
argument [10728,10735]
argument [12895,12902]
===
match
---
name: task_instances [4152,4166]
name: task_instances [4852,4866]
===
match
---
assert_stmt [10362,10387]
assert_stmt [12529,12554]
===
match
---
operator: , [1749,1750]
operator: , [1749,1750]
===
match
---
name: state [12527,12532]
name: state [14694,14699]
===
match
---
name: settings [840,848]
name: settings [840,848]
===
match
---
name: dr [4563,4565]
name: dr [5597,5599]
===
match
---
argument [9088,9095]
argument [11255,11262]
===
match
---
argument [4937,4988]
argument [5971,6022]
===
match
---
simple_stmt [11567,11597]
simple_stmt [13734,13764]
===
match
---
atom_expr [9802,9815]
atom_expr [11969,11982]
===
match
---
simple_stmt [1400,1419]
simple_stmt [1400,1419]
===
match
---
name: max_tries [13746,13755]
name: max_tries [15913,15922]
===
match
---
trailer [10717,10727]
trailer [12884,12894]
===
match
---
operator: == [7082,7084]
operator: == [8816,8818]
===
match
---
trailer [9710,9712]
trailer [11877,11879]
===
match
---
arith_expr [3855,3897]
arith_expr [4555,4597]
===
match
---
name: pytest [3355,3361]
name: pytest [4055,4061]
===
match
---
name: dr [4175,4177]
name: dr [4875,4877]
===
match
---
atom_expr [11743,11755]
atom_expr [13910,13922]
===
match
---
argument [4900,4923]
argument [5934,5957]
===
match
---
trailer [9932,9934]
trailer [12099,12101]
===
match
---
name: FAILED [12263,12269]
name: FAILED [14430,14436]
===
match
---
trailer [12088,12091]
trailer [14255,14258]
===
match
---
name: task0 [7576,7581]
name: task0 [9310,9315]
===
match
---
trailer [11427,11433]
trailer [13594,13600]
===
match
---
name: session [4354,4361]
name: session [5054,5061]
===
match
---
name: days [3889,3893]
name: days [4589,4593]
===
match
---
assert_stmt [7129,7155]
assert_stmt [8863,8889]
===
match
---
atom_expr [11574,11591]
atom_expr [13741,13758]
===
match
---
trailer [2874,2876]
trailer [3224,3226]
===
match
---
simple_stmt [11333,11363]
simple_stmt [13500,13530]
===
match
---
name: State [3442,3447]
name: State [4142,4147]
===
match
---
name: tis [11291,11294]
name: tis [13458,13461]
===
match
---
trailer [13050,13069]
trailer [15217,15236]
===
match
---
number: 3 [10017,10018]
number: 3 [12184,12185]
===
match
---
argument [7610,7639]
argument [9344,9373]
===
match
---
name: dag_maker [4798,4807]
name: dag_maker [5832,5841]
===
match
---
trailer [4585,4591]
trailer [5619,5625]
===
match
---
name: task_instances [11078,11092]
name: task_instances [13245,13259]
===
match
---
operator: = [9439,9440]
operator: = [11606,11607]
===
match
---
name: state [4498,4503]
name: state [5532,5537]
===
match
---
trailer [1865,1875]
trailer [1865,1875]
===
match
---
atom [8144,8529]
atom [9878,10263]
===
match
---
trailer [1690,1703]
trailer [1690,1703]
===
match
---
trailer [5392,5394]
trailer [6426,6428]
===
match
---
name: i [12524,12525]
name: i [14691,14692]
===
match
---
string: 'task0' [6351,6358]
string: 'task0' [7735,7742]
===
match
---
simple_stmt [9393,9421]
simple_stmt [11560,11588]
===
match
---
argument [8797,8804]
argument [10964,10971]
===
match
---
funcdef [4749,6047]
funcdef [5783,7431]
===
match
---
simple_stmt [4226,4264]
simple_stmt [4926,4964]
===
match
---
name: try_number [7071,7081]
name: try_number [8805,8815]
===
match
---
name: state [2328,2333]
name: state [2678,2683]
===
match
---
operator: , [3213,3214]
operator: , [3913,3914]
===
match
---
atom_expr [2134,2144]
atom_expr [2463,2473]
===
match
---
atom_expr [9973,9982]
atom_expr [12140,12149]
===
match
---
trailer [12869,13017]
trailer [15036,15184]
===
match
---
assert_stmt [8818,8864]
assert_stmt [10985,11031]
===
match
---
expr_stmt [10858,11057]
expr_stmt [13025,13224]
===
match
---
trailer [1953,1960]
trailer [1953,1960]
===
match
---
atom_expr [8429,8454]
atom_expr [10163,10188]
===
match
---
simple_stmt [10234,10261]
simple_stmt [12401,12428]
===
match
---
atom_expr [9617,9626]
atom_expr [11784,11793]
===
match
---
atom_expr [5079,5120]
atom_expr [6113,6154]
===
match
---
trailer [2120,2145]
trailer [2449,2474]
===
match
---
simple_stmt [7672,7756]
simple_stmt [9406,9490]
===
match
---
assert_stmt [3272,3296]
assert_stmt [3972,3996]
===
match
---
name: ti1 [4143,4146]
name: ti1 [4843,4846]
===
match
---
name: session [12278,12285]
name: session [14445,14452]
===
match
---
name: create_session [1070,1084]
name: create_session [1070,1084]
===
match
---
operator: = [4945,4946]
operator: = [5979,5980]
===
match
---
name: task_id [1738,1745]
name: task_id [1738,1745]
===
match
---
comparison [8692,8715]
comparison [10790,10813]
===
match
---
simple_stmt [9504,9533]
simple_stmt [11671,11700]
===
match
---
operator: = [13129,13130]
operator: = [15296,15297]
===
match
---
simple_stmt [6556,6585]
simple_stmt [7940,7969]
===
match
---
name: session [5708,5715]
name: session [7092,7099]
===
match
---
operator: == [8271,8273]
operator: == [10005,10007]
===
match
---
trailer [13259,13269]
trailer [15426,15436]
===
match
---
decorator [1283,1328]
decorator [1283,1328]
===
match
---
name: has_task [5482,5490]
name: has_task [6516,6524]
===
match
---
name: run [8023,8026]
name: run [9757,9760]
===
match
---
name: ti1 [13524,13527]
name: ti1 [15691,15694]
===
match
---
operator: = [10827,10828]
operator: = [12994,12995]
===
match
---
name: session [10444,10451]
name: session [12611,12618]
===
match
---
simple_stmt [11785,11815]
simple_stmt [13952,13982]
===
match
---
operator: , [4988,4989]
operator: , [6022,6023]
===
match
---
simple_stmt [7095,7121]
simple_stmt [8829,8855]
===
match
---
name: SCHEDULED [6526,6535]
name: SCHEDULED [7910,7919]
===
match
---
simple_stmt [3180,3224]
simple_stmt [3880,3924]
===
match
---
trailer [2754,2764]
trailer [3104,3114]
===
match
---
trailer [9488,9495]
trailer [11655,11662]
===
match
---
atom_expr [12010,12023]
atom_expr [14177,14190]
===
match
---
name: op1 [13031,13034]
name: op1 [15198,15201]
===
match
---
name: timedelta [7526,7535]
name: timedelta [9260,9269]
===
match
---
name: range [10541,10546]
name: range [12708,12713]
===
match
---
name: max_tries [12626,12635]
name: max_tries [14793,14802]
===
match
---
name: refresh_from_task [6597,6614]
name: refresh_from_task [7981,7998]
===
match
---
assert_stmt [11987,12023]
assert_stmt [14154,14190]
===
match
---
atom_expr [6262,6289]
atom_expr [7646,7673]
===
match
---
operator: , [3204,3205]
operator: , [3904,3905]
===
match
---
arglist [2185,2206]
arglist [2535,2556]
===
match
---
trailer [1402,1416]
trailer [1402,1416]
===
match
---
argument [4484,4503]
argument [5518,5537]
===
match
---
operator: + [6260,6261]
operator: + [7644,7645]
===
match
---
operator: , [1311,1312]
operator: , [1311,1312]
===
match
---
operator: , [7250,7251]
operator: , [8984,8985]
===
match
---
name: i [11222,11223]
name: i [13389,13390]
===
match
---
name: dags [12362,12366]
name: dags [14529,14533]
===
match
---
arith_expr [4946,4988]
arith_expr [5980,6022]
===
match
---
trailer [2109,2113]
trailer [2438,2442]
===
match
---
argument [2722,2773]
argument [3072,3123]
===
match
---
name: DummyOperator [13088,13101]
name: DummyOperator [15255,15268]
===
match
---
expr_stmt [2090,2151]
expr_stmt [2419,2501]
===
match
---
atom_expr [1485,1648]
atom_expr [1485,1648]
===
match
---
name: dr [13165,13167]
name: dr [15332,15334]
===
match
---
name: ti1 [9905,9908]
name: ti1 [12072,12075]
===
match
---
trailer [4426,4433]
trailer [5439,5446]
===
match
---
string: "some_external_executor_id" [2964,2991]
string: "some_external_executor_id" [3314,3341]
===
match
---
name: state [6473,6478]
name: state [7857,7862]
===
match
---
argument [6343,6358]
argument [7727,7742]
===
match
---
operator: = [4097,4098]
operator: = [4797,4798]
===
match
---
expr_stmt [7576,7659]
expr_stmt [9310,9393]
===
match
---
name: tests [1228,1233]
name: tests [1228,1233]
===
match
---
name: all [3162,3165]
name: all [3862,3865]
===
match
---
name: TI [5628,5630]
name: TI [6991,6993]
===
match
---
name: i [11578,11579]
name: i [13745,13746]
===
match
---
name: dag_maker [1776,1785]
name: dag_maker [1776,1785]
===
match
---
argument [7493,7544]
argument [9227,9278]
===
match
---
name: end_date [10685,10693]
name: end_date [12852,12860]
===
match
---
operator: = [5213,5214]
operator: = [6247,6248]
===
match
---
trailer [9694,9710]
trailer [11861,11877]
===
match
---
comparison [9802,9820]
comparison [11969,11987]
===
match
---
operator: + [4959,4960]
operator: + [5993,5994]
===
match
---
name: str [10814,10817]
name: str [12981,12984]
===
match
---
name: SCHEDULED [4109,4118]
name: SCHEDULED [4809,4818]
===
match
---
operator: == [7185,7187]
operator: == [8919,8921]
===
match
---
name: DEFAULT_DATE [12929,12941]
name: DEFAULT_DATE [15096,15108]
===
match
---
expr_stmt [5020,5058]
expr_stmt [6054,6092]
===
match
---
trailer [11795,11798]
trailer [13962,13965]
===
match
---
trailer [2429,2435]
trailer [2779,2785]
===
match
---
param [6094,6099]
param [7478,7483]
===
match
---
name: ignore_ti_state [13550,13565]
name: ignore_ti_state [15717,15732]
===
match
---
operator: , [10820,10821]
operator: , [12987,12988]
===
match
---
name: DEFAULT_DATE [7467,7479]
name: DEFAULT_DATE [9201,9213]
===
match
---
trailer [11714,11717]
trailer [13881,13884]
===
match
---
name: refresh_from_task [1973,1990]
name: refresh_from_task [1973,1990]
===
match
---
name: DagRunType [9353,9363]
name: DagRunType [11520,11530]
===
match
---
atom_expr [11452,11470]
atom_expr [13619,13637]
===
match
---
trailer [9925,9932]
trailer [12092,12099]
===
match
---
name: task_id [2819,2826]
name: task_id [3169,3176]
===
match
---
trailer [7903,7918]
trailer [9637,9652]
===
match
---
number: 2 [10352,10353]
number: 2 [12519,12520]
===
match
---
trailer [4562,4566]
trailer [5596,5600]
===
match
---
trailer [5158,5245]
trailer [6192,6279]
===
match
---
param [12835,12844]
param [15002,15011]
===
match
---
trailer [13590,13601]
trailer [15757,15768]
===
match
---
name: session [8788,8795]
name: session [10955,10962]
===
match
---
funcdef [6052,7190]
funcdef [7436,8924]
===
match
---
name: dr [6431,6433]
name: dr [7815,7817]
===
match
---
trailer [3256,3258]
trailer [3956,3958]
===
match
---
trailer [6798,6805]
trailer [8511,8518]
===
match
---
operator: = [9272,9273]
operator: = [11439,11440]
===
match
---
name: run [5389,5392]
name: run [6423,6426]
===
match
---
comparison [11743,11772]
comparison [13910,13939]
===
match
---
name: max_tries [12092,12101]
name: max_tries [14259,14268]
===
match
---
name: DAG [12347,12350]
name: DAG [14514,14517]
===
match
---
argument [4056,4075]
argument [4756,4775]
===
match
---
trailer [8223,8482]
trailer [9957,10216]
===
match
---
trailer [5528,5537]
trailer [6562,6571]
===
match
---
trailer [7174,7184]
trailer [8908,8918]
===
match
---
assert_stmt [11567,11596]
assert_stmt [13734,13763]
===
match
---
name: try_number [10003,10013]
name: try_number [12170,12180]
===
match
---
name: task1 [5071,5076]
name: task1 [6105,6110]
===
match
---
trailer [12576,12579]
trailer [14743,14746]
===
match
---
name: dag_maker [7770,7779]
name: dag_maker [9504,9513]
===
match
---
name: len [12207,12210]
name: len [14374,14377]
===
match
---
name: i [11674,11675]
name: i [13841,13842]
===
match
---
trailer [3240,3256]
trailer [3940,3956]
===
match
---
trailer [1785,1799]
trailer [1785,1799]
===
match
---
name: DummyOperator [10771,10784]
name: DummyOperator [12938,12951]
===
match
---
name: datetime [795,803]
name: datetime [795,803]
===
match
---
name: all [6807,6810]
name: all [8541,8544]
===
match
---
simple_stmt [8877,8924]
simple_stmt [11044,11091]
===
match
---
name: try_number [11347,11357]
name: try_number [13514,13524]
===
match
---
trailer [2250,2266]
trailer [2600,2616]
===
match
---
atom_expr [4328,4345]
atom_expr [5028,5045]
===
match
---
operator: == [12636,12638]
operator: == [14803,14805]
===
match
---
atom_expr [13350,13358]
atom_expr [15517,15525]
===
match
---
name: session [11035,11042]
name: session [13202,13209]
===
match
---
number: 1 [12105,12106]
number: 1 [14272,14273]
===
match
---
arglist [12883,13007]
arglist [15050,15174]
===
match
---
name: task_dict [5444,5453]
name: task_dict [6478,6487]
===
match
---
name: ti1 [2426,2429]
name: ti1 [2776,2779]
===
match
---
name: RUNNING [6485,6492]
name: RUNNING [7869,7876]
===
match
---
atom_expr [10709,10736]
atom_expr [12876,12903]
===
match
---
trailer [10880,11057]
trailer [13047,13224]
===
match
---
trailer [10131,10133]
trailer [12298,12300]
===
match
---
decorated [3354,4744]
decorated [4054,5778]
===
match
---
simple_stmt [2350,2377]
simple_stmt [2700,2727]
===
match
---
trailer [6781,6806]
trailer [8494,8519]
===
match
---
param [8954,8963]
param [11121,11130]
===
match
---
name: dr [4697,4699]
name: dr [5731,5733]
===
match
---
trailer [3083,3090]
trailer [3433,3440]
===
match
---
name: task_instances [2877,2891]
name: task_instances [3227,3241]
===
match
---
atom_expr [6593,6621]
atom_expr [7977,8005]
===
match
---
suite [5595,5717]
suite [6629,7101]
===
match
---
operator: = [1633,1634]
operator: = [1633,1634]
===
match
---
suite [5007,5121]
suite [6041,6155]
===
match
---
trailer [13745,13755]
trailer [15912,15922]
===
match
---
trailer [9731,9742]
trailer [11898,11909]
===
match
---
trailer [6993,7009]
trailer [8727,8743]
===
match
---
assert_stmt [2419,2443]
assert_stmt [2769,2793]
===
match
---
number: 2 [5118,5119]
number: 2 [6152,6153]
===
match
---
name: db [1357,1359]
name: db [1357,1359]
===
match
---
atom_expr [11382,11398]
atom_expr [13549,13565]
===
match
---
simple_stmt [2247,2269]
simple_stmt [2597,2619]
===
match
---
operator: = [6350,6351]
operator: = [7734,7735]
===
match
---
operator: == [9773,9775]
operator: == [11940,11942]
===
match
---
name: commit [9926,9932]
name: commit [12093,12099]
===
match
---
trailer [11840,11850]
trailer [14007,14017]
===
match
---
name: state [11535,11540]
name: state [13702,13707]
===
match
---
suite [1656,1762]
suite [1656,1762]
===
match
---
trailer [7535,7544]
trailer [9269,9278]
===
match
---
operator: = [1774,1775]
operator: = [1774,1775]
===
match
---
comparison [12778,12799]
comparison [14945,14966]
===
match
---
simple_stmt [9671,9683]
simple_stmt [11838,11850]
===
match
---
atom_expr [7901,7918]
atom_expr [9635,9652]
===
match
---
number: 1 [11854,11855]
number: 1 [14021,14022]
===
match
---
name: DagRunType [1855,1865]
name: DagRunType [1855,1865]
===
match
---
assert_stmt [9795,9820]
assert_stmt [11962,11987]
===
match
---
simple_stmt [2090,2152]
simple_stmt [2419,2502]
===
match
---
operator: == [13602,13604]
operator: == [15769,15771]
===
match
---
suite [3034,3349]
suite [3384,4049]
===
match
---
with_item [3745,3915]
with_item [4445,4615]
===
match
---
name: dr [9441,9443]
name: dr [11608,11610]
===
match
---
trailer [11269,11271]
trailer [13436,13438]
===
match
---
trailer [11868,11879]
trailer [14035,14046]
===
match
---
trailer [9322,9330]
trailer [11489,11497]
===
match
---
atom [3419,3439]
atom [4119,4139]
===
match
---
trailer [11297,11303]
trailer [13464,13470]
===
match
---
name: tis [12573,12576]
name: tis [14740,14743]
===
match
---
atom_expr [1357,1375]
atom_expr [1357,1375]
===
match
---
name: timedelta [1619,1628]
name: timedelta [1619,1628]
===
match
---
name: append [11140,11146]
name: append [13307,13313]
===
match
---
comparison [12476,12495]
comparison [14643,14662]
===
match
---
atom_expr [3006,3022]
atom_expr [3356,3372]
===
match
---
assert_stmt [12675,12708]
assert_stmt [14842,14875]
===
match
---
trailer [13500,13515]
trailer [15667,15682]
===
match
---
name: session [3026,3033]
name: session [3376,3383]
===
match
---
name: TaskReschedule [8249,8263]
name: TaskReschedule [9983,9997]
===
match
---
comparison [9589,9608]
comparison [11756,11775]
===
match
---
simple_stmt [9636,9663]
simple_stmt [11803,11830]
===
match
---
argument [3809,3832]
argument [4509,4532]
===
match
---
trailer [13431,13442]
trailer [15598,15609]
===
match
---
simple_stmt [12347,12386]
simple_stmt [14514,14553]
===
match
---
name: RUNNING [3448,3455]
name: RUNNING [4148,4155]
===
match
---
string: """Test that TaskReschedules are deleted correctly when TaskInstances are cleared""" [7272,7356]
string: """Test that TaskReschedules are deleted correctly when TaskInstances are cleared""" [9006,9090]
===
match
---
operator: , [1637,1638]
operator: , [1637,1638]
===
match
---
name: ti0 [8847,8850]
name: ti0 [11014,11017]
===
match
---
argument [6238,6289]
argument [7622,7673]
===
match
---
atom_expr [8692,8701]
atom_expr [10790,10799]
===
match
---
param [1342,1346]
param [1342,1346]
===
match
---
name: task_id [9149,9156]
name: task_id [11316,11323]
===
match
---
name: qry [8661,8664]
name: qry [10724,10727]
===
match
---
assert_stmt [13769,13795]
assert_stmt [15936,15962]
===
match
---
operator: = [7721,7722]
operator: = [9455,9456]
===
match
---
name: max_tries [7106,7115]
name: max_tries [8840,8849]
===
match
---
simple_stmt [3106,3168]
simple_stmt [3785,3868]
===
match
---
atom_expr [4650,4662]
atom_expr [5684,5696]
===
match
---
trailer [12046,12049]
trailer [14213,14216]
===
match
---
operator: = [4497,4498]
operator: = [5531,5532]
===
match
---
trailer [2860,2874]
trailer [3210,3224]
===
match
---
trailer [6280,6289]
trailer [7664,7673]
===
match
---
atom_expr [8043,8059]
atom_expr [9777,9793]
===
match
---
operator: = [12928,12929]
operator: = [15095,15096]
===
match
---
argument [7737,7754]
argument [9471,9488]
===
match
---
operator: == [12061,12063]
operator: == [14228,14230]
===
match
---
atom_expr [2915,2928]
atom_expr [3265,3278]
===
match
---
atom_expr [4149,4166]
atom_expr [4849,4866]
===
match
---
argument [7456,7479]
argument [9190,9213]
===
match
---
string: "reschedule" [7742,7754]
string: "reschedule" [9476,9488]
===
match
---
arglist [3982,4004]
arglist [4682,4704]
===
match
---
trailer [6845,6859]
trailer [8579,8593]
===
match
---
comparison [3316,3348]
comparison [4016,4048]
===
match
---
simple_stmt [9430,9459]
simple_stmt [11597,11626]
===
match
---
suite [10560,11179]
suite [12727,13346]
===
match
---
number: 10 [10733,10735]
number: 10 [12900,12902]
===
match
---
param [3521,3526]
param [4221,4226]
===
match
---
expr_stmt [2903,2928]
expr_stmt [3253,3278]
===
match
---
atom_expr [11259,11271]
atom_expr [13426,13438]
===
match
---
name: i [12440,12441]
name: i [14607,14608]
===
match
---
testlist_star_expr [4138,4146]
testlist_star_expr [4838,4846]
===
match
---
with_item [2049,2076]
with_item [2049,2076]
===
match
---
trailer [12328,12335]
trailer [14495,14502]
===
match
---
trailer [8680,8684]
trailer [10761,10765]
===
match
---
atom_expr [3047,3063]
atom_expr [3397,3413]
===
match
---
name: SUCCESS [12542,12549]
name: SUCCESS [14709,14716]
===
match
---
name: session [5587,5594]
name: session [6621,6628]
===
match
---
name: ti0 [7067,7070]
name: ti0 [8801,8804]
===
match
---
operator: == [5939,5941]
operator: == [7323,7325]
===
match
---
simple_stmt [10573,10752]
simple_stmt [12740,12919]
===
match
---
trailer [12000,12006]
trailer [14167,14173]
===
match
---
name: create_session [2049,2063]
name: create_session [2049,2063]
===
match
---
operator: , [10834,10835]
operator: , [13001,13002]
===
match
---
atom_expr [4522,4537]
atom_expr [5556,5571]
===
match
---
testlist_star_expr [13290,13298]
testlist_star_expr [15457,15465]
===
match
---
name: has_task [5529,5537]
name: has_task [6563,6571]
===
match
---
name: ti2 [13374,13377]
name: ti2 [15541,15544]
===
match
---
name: datetime [2746,2754]
name: datetime [3096,3104]
===
match
---
name: ti1 [9999,10002]
name: ti1 [12166,12169]
===
match
---
name: task0 [5020,5025]
name: task0 [6054,6059]
===
match
---
atom_expr [12732,12749]
atom_expr [14899,14916]
===
match
---
operator: = [6514,6515]
operator: = [7898,7899]
===
match
---
name: retries [13122,13129]
name: retries [15289,15296]
===
match
---
name: ti1 [8906,8909]
name: ti1 [11073,11076]
===
match
---
trailer [10065,10071]
trailer [12232,12238]
===
match
---
name: dag_id [8709,8715]
name: dag_id [10807,10813]
===
match
---
name: mode [7641,7645]
name: mode [9375,9379]
===
match
---
operator: , [3439,3440]
operator: , [4139,4140]
===
match
---
operator: , [12205,12206]
operator: , [14372,14373]
===
match
---
name: task_id [5497,5504]
name: task_id [6531,6538]
===
match
---
name: SCHEDULED [9364,9373]
name: SCHEDULED [11531,11540]
===
match
---
name: ti0 [3316,3319]
name: ti0 [4016,4019]
===
match
---
name: refresh_from_db [9695,9710]
name: refresh_from_db [11862,11877]
===
match
---
name: qry [2090,2093]
name: qry [2419,2422]
===
match
---
atom_expr [10541,10559]
atom_expr [12708,12726]
===
match
---
trailer [12361,12385]
trailer [14528,14552]
===
match
---
operator: , [8795,8796]
operator: , [10962,10963]
===
match
---
comparison [2392,2410]
comparison [2742,2760]
===
match
---
simple_stmt [8602,8649]
simple_stmt [10336,10383]
===
match
---
trailer [13527,13531]
trailer [15694,15698]
===
match
---
name: State [12698,12703]
name: State [14865,14870]
===
match
---
operator: == [12795,12797]
operator: == [14962,14964]
===
match
---
trailer [7985,7992]
trailer [9719,9726]
===
match
---
number: 1 [12639,12640]
number: 1 [14806,14807]
===
match
---
number: 10 [13003,13005]
number: 10 [15170,15172]
===
match
---
atom_expr [8825,8859]
atom_expr [10992,11026]
===
match
---
name: session [4318,4325]
name: session [5018,5025]
===
match
---
argument [6473,6492]
argument [7857,7876]
===
match
---
name: tis [12085,12088]
name: tis [14252,14255]
===
match
---
string: 'test_dag_clear_task_1' [9224,9247]
string: 'test_dag_clear_task_1' [11391,11414]
===
match
---
name: QUEUED [4656,4662]
name: QUEUED [5690,5696]
===
match
---
name: python [1009,1015]
name: python [1009,1015]
===
match
---
trailer [5631,5638]
trailer [6994,7001]
===
match
---
name: tis [12043,12046]
name: tis [14210,14213]
===
match
---
trailer [10954,10962]
trailer [13121,13129]
===
match
---
name: op1 [13145,13148]
name: op1 [15312,15315]
===
match
---
operator: = [13359,13360]
operator: = [15526,15527]
===
match
---
name: test_dags_clear [10397,10412]
name: test_dags_clear [12564,12579]
===
match
---
trailer [10101,10103]
trailer [12268,12270]
===
match
---
operator: = [4383,4384]
operator: = [5396,5397]
===
match
---
number: 10 [7541,7543]
number: 10 [9275,9277]
===
match
---
number: 2 [10051,10052]
number: 2 [12218,12219]
===
match
---
name: i [12623,12624]
name: i [14790,14791]
===
match
---
trailer [8383,8390]
trailer [10117,10124]
===
match
---
name: range [11452,11457]
name: range [13619,13624]
===
match
---
expr_stmt [12179,12220]
expr_stmt [14346,14387]
===
match
---
name: tis [10487,10490]
name: tis [12654,12657]
===
match
---
name: qry [2185,2188]
name: qry [2535,2538]
===
match
---
name: TaskReschedule [8429,8443]
name: TaskReschedule [10163,10177]
===
match
---
atom_expr [2007,2016]
atom_expr [2007,2016]
===
match
---
operator: , [3993,3994]
operator: , [4693,4694]
===
match
---
trailer [1373,1375]
trailer [1373,1375]
===
match
---
name: dag_id [4413,4419]
name: dag_id [5426,5432]
===
match
---
trailer [7380,7555]
trailer [9114,9289]
===
match
---
operator: = [1818,1819]
operator: = [1818,1819]
===
match
---
name: refresh_from_task [1936,1953]
name: refresh_from_task [1936,1953]
===
match
---
comparison [7102,7120]
comparison [8836,8854]
===
match
---
name: ti0 [9430,9433]
name: ti0 [11597,11600]
===
match
---
atom_expr [9918,9934]
atom_expr [12085,12101]
===
match
---
assert_stmt [10200,10225]
assert_stmt [12367,12392]
===
match
---
name: task_instances [1909,1923]
name: task_instances [1909,1923]
===
match
---
operator: , [3532,3533]
operator: , [4232,4233]
===
match
---
string: "reschedule" [7646,7658]
string: "reschedule" [9380,9392]
===
match
---
import_from [938,987]
import_from [938,987]
===
match
---
comparison [10207,10225]
comparison [12374,12392]
===
match
---
simple_stmt [4318,4346]
simple_stmt [5018,5046]
===
match
---
trailer [11923,11936]
trailer [14090,14103]
===
match
---
name: task1 [1716,1721]
name: task1 [1716,1721]
===
match
---
suite [11471,11638]
suite [13638,13805]
===
match
---
name: task_id [3982,3989]
name: task_id [4682,4689]
===
match
---
trailer [9148,9181]
trailer [11315,11348]
===
match
---
name: i [10536,10537]
name: i [12703,12704]
===
match
---
comparison [6028,6046]
comparison [7412,7430]
===
match
---
atom_expr [13587,13601]
atom_expr [15754,15768]
===
match
---
name: DEFAULT_DATE [10694,10706]
name: DEFAULT_DATE [12861,12873]
===
match
---
name: State [5178,5183]
name: State [6212,6217]
===
match
---
atom_expr [8847,8858]
atom_expr [11014,11025]
===
match
---
atom_expr [1855,1875]
atom_expr [1855,1875]
===
match
---
comparison [13463,13481]
comparison [15630,15648]
===
match
---
arglist [12204,12219]
arglist [14371,14386]
===
match
---
param [10413,10417]
param [12580,12584]
===
match
---
name: i [11386,11387]
name: i [13553,13554]
===
match
---
atom_expr [7849,7869]
atom_expr [9583,9603]
===
match
---
operator: == [12750,12752]
operator: == [14917,14919]
===
match
---
name: owner [10822,10827]
name: owner [12989,12994]
===
match
---
name: i [11998,11999]
name: i [14165,14166]
===
match
---
operator: = [13248,13249]
operator: = [15415,15416]
===
match
---
name: PythonSensor [7680,7692]
name: PythonSensor [9414,9426]
===
match
---
name: timedelta [12988,12997]
name: timedelta [15155,15164]
===
match
---
comparison [8550,8589]
comparison [10284,10323]
===
match
---
name: ti0 [5367,5370]
name: ti0 [6401,6404]
===
match
---
name: filter [6775,6781]
name: filter [8488,8494]
===
match
---
operator: == [11810,11812]
operator: == [13977,13979]
===
match
---
name: models [862,868]
name: models [862,868]
===
match
---
simple_stmt [11865,11900]
simple_stmt [14032,14067]
===
match
---
trailer [12291,12312]
trailer [14458,14479]
===
match
---
argument [6506,6535]
argument [7890,7919]
===
match
---
operator: == [6792,6794]
operator: == [8505,8507]
===
match
---
not_test [5521,5552]
not_test [6555,6586]
===
match
---
name: ti1 [6686,6689]
name: ti1 [8070,8073]
===
match
---
trailer [5655,5662]
trailer [7018,7025]
===
match
---
comparison [8249,8284]
comparison [9983,10018]
===
match
---
name: airflow [1041,1048]
name: airflow [1041,1048]
===
match
---
name: timedelta [10718,10727]
name: timedelta [12885,12894]
===
match
---
name: start_date [9020,9030]
name: start_date [11187,11197]
===
match
---
atom_expr [11950,11974]
atom_expr [14117,14141]
===
match
---
with_stmt [3740,4006]
with_stmt [4440,4706]
===
match
---
string: 'test_clear_task_instances' [1508,1535]
string: 'test_clear_task_instances' [1508,1535]
===
match
---
name: run_type [6506,6514]
name: run_type [7890,7898]
===
match
---
atom_expr [13088,13132]
atom_expr [15255,15299]
===
match
---
assert_stmt [9582,9608]
assert_stmt [11749,11775]
===
match
---
operator: == [12533,12535]
operator: == [14700,14702]
===
match
---
name: State [6479,6484]
name: State [7863,7868]
===
match
---
name: dag [8797,8800]
name: dag [10964,10967]
===
match
---
operator: , [2773,2774]
operator: , [3123,3124]
===
match
---
name: task_id [7597,7604]
name: task_id [9331,9338]
===
match
---
atom_expr [4284,4309]
atom_expr [4984,5009]
===
match
---
dotted_name [1190,1202]
dotted_name [1190,1202]
===
match
---
import_name [788,803]
import_name [788,803]
===
match
---
trailer [9283,9297]
trailer [11450,11464]
===
match
---
name: ti0 [9589,9592]
name: ti0 [11756,11759]
===
match
---
argument [10822,10834]
argument [12989,13001]
===
match
---
parameters [2568,2585]
parameters [2918,2935]
===
match
---
atom_expr [2164,2207]
atom_expr [2514,2557]
===
match
---
name: task_id [8910,8917]
name: task_id [11077,11084]
===
match
---
name: ti0 [1932,1935]
name: ti0 [1932,1935]
===
match
---
simple_stmt [11284,11321]
simple_stmt [13451,13488]
===
match
---
atom_expr [10369,10382]
atom_expr [12536,12549]
===
match
---
trailer [7070,7081]
trailer [8804,8815]
===
match
---
trailer [7779,7793]
trailer [9513,9527]
===
match
---
comparison [2459,2478]
comparison [2809,2828]
===
match
---
name: DEFAULT_DATE [2731,2743]
name: DEFAULT_DATE [3081,3093]
===
match
---
name: str [10620,10623]
name: str [12787,12790]
===
match
---
atom_expr [10949,10962]
atom_expr [13116,13129]
===
match
---
name: dry_run [11886,11893]
name: dry_run [14053,14060]
===
match
---
string: "class" [1319,1326]
string: "class" [1319,1326]
===
match
---
operator: = [1745,1746]
operator: = [1745,1746]
===
match
---
atom_expr [7584,7659]
atom_expr [9318,9393]
===
match
---
trailer [3200,3223]
trailer [3900,3923]
===
match
---
number: 3 [12594,12595]
number: 3 [14761,14762]
===
match
---
string: "last_scheduling" [3398,3415]
string: "last_scheduling" [4098,4115]
===
match
---
name: datetime [10709,10717]
name: datetime [12876,12884]
===
match
---
atom_expr [13776,13790]
atom_expr [15943,15957]
===
match
---
trailer [4412,4419]
trailer [5425,5432]
===
match
---
trailer [4229,4235]
trailer [4929,4935]
===
match
---
operator: = [3950,3951]
operator: = [4650,4651]
===
match
---
name: i [11344,11345]
name: i [13511,13512]
===
match
---
atom_expr [2025,2034]
atom_expr [2025,2034]
===
match
---
simple_stmt [12321,12338]
simple_stmt [14488,14505]
===
match
---
atom_expr [11616,11632]
atom_expr [13783,13799]
===
match
---
atom_expr [7067,7081]
atom_expr [8801,8815]
===
match
---
assert_stmt [13456,13481]
assert_stmt [15623,15648]
===
match
---
name: dr [11075,11077]
name: dr [13242,13244]
===
match
---
name: ti0 [2357,2360]
name: ti0 [2707,2710]
===
match
---
atom_expr [5292,5320]
atom_expr [6326,6354]
===
match
---
name: self [10413,10417]
name: self [12580,12584]
===
match
---
operator: = [11116,11117]
operator: = [13283,13284]
===
match
---
number: 0 [11093,11094]
number: 0 [13260,13261]
===
match
---
name: utils [1049,1054]
name: utils [1049,1054]
===
match
---
name: i [11954,11955]
name: i [14121,14122]
===
match
---
assert_stmt [11785,11814]
assert_stmt [13952,13981]
===
match
---
number: 2 [2375,2376]
number: 2 [2725,2726]
===
match
---
name: num_of_dags [11924,11935]
name: num_of_dags [14091,14102]
===
match
---
name: tis [12682,12685]
name: tis [14849,14852]
===
match
---
param [3551,3560]
param [4251,4260]
===
match
---
operator: , [13293,13294]
operator: , [15460,15461]
===
match
---
name: DEFAULT_DATE [1595,1607]
name: DEFAULT_DATE [1595,1607]
===
match
---
trailer [9215,9259]
trailer [11382,11426]
===
match
---
atom [3441,3470]
atom [4141,4170]
===
match
---
name: state [4056,4061]
name: state [4756,4761]
===
match
---
name: create_session [6710,6724]
name: create_session [8094,8108]
===
match
---
name: days [9088,9092]
name: days [11255,11259]
===
match
---
with_stmt [2044,2208]
with_stmt [2044,2558]
===
match
---
trailer [3942,3955]
trailer [4642,4655]
===
match
---
name: ti1 [10241,10244]
name: ti1 [12408,12411]
===
match
---
expr_stmt [4379,4440]
expr_stmt [5392,5474]
===
match
---
name: self [3521,3525]
name: self [4221,4225]
===
match
---
name: airflow [1147,1154]
name: airflow [1147,1154]
===
match
---
name: dags [11135,11139]
name: dags [13302,13306]
===
match
---
atom_expr [5993,6007]
atom_expr [7377,7391]
===
match
---
trailer [6784,6791]
trailer [8497,8504]
===
match
---
operator: , [1122,1123]
operator: , [1122,1123]
===
match
---
simple_stmt [4175,4218]
simple_stmt [4875,4918]
===
match
---
argument [13550,13570]
argument [15717,15737]
===
match
---
arglist [2623,2774]
arglist [2973,3124]
===
match
---
name: test_utils [1234,1244]
name: test_utils [1234,1244]
===
match
---
expr_stmt [13165,13280]
expr_stmt [15332,15447]
===
match
---
simple_stmt [11987,12024]
simple_stmt [14154,14191]
===
match
---
suite [13018,13156]
suite [15185,15323]
===
match
---
name: ti1 [6990,6993]
name: ti1 [8724,8727]
===
match
---
assert_stmt [5917,5943]
assert_stmt [7301,7327]
===
match
---
arith_expr [12964,13006]
arith_expr [15131,15173]
===
match
---
simple_stmt [6321,6360]
simple_stmt [7705,7744]
===
match
---
trailer [11265,11269]
trailer [13432,13436]
===
match
---
trailer [11490,11506]
trailer [13657,13673]
===
match
---
name: try_number [11581,11591]
name: try_number [13748,13758]
===
match
---
operator: == [8860,8862]
operator: == [11027,11029]
===
match
---
name: filter [5632,5638]
name: filter [6995,7001]
===
match
---
name: days [4980,4984]
name: days [6014,6018]
===
match
---
atom_expr [13542,13571]
atom_expr [15709,15738]
===
match
---
argument [5205,5234]
argument [6239,6268]
===
match
---
comparison [13742,13760]
comparison [15909,15927]
===
match
---
for_stmt [12395,12800]
for_stmt [14562,14967]
===
match
---
atom_expr [4449,4513]
atom_expr [5483,5547]
===
match
---
name: create_dagrun [1786,1799]
name: create_dagrun [1786,1799]
===
match
---
simple_stmt [13374,13384]
simple_stmt [15541,15551]
===
match
---
operator: == [6042,6044]
operator: == [7426,7428]
===
match
---
trailer [9980,9982]
trailer [12147,12149]
===
match
---
name: refresh_from_db [5851,5866]
name: refresh_from_db [7235,7250]
===
match
---
name: days [10728,10732]
name: days [12895,12899]
===
match
---
simple_stmt [988,1036]
simple_stmt [988,1036]
===
match
---
simple_stmt [1669,1704]
simple_stmt [1669,1704]
===
match
---
argument [7693,7704]
argument [9427,9438]
===
match
---
import_from [12143,12169]
import_from [14310,14336]
===
match
---
name: dr [13301,13303]
name: dr [15468,15470]
===
match
---
comparison [11616,11637]
comparison [13783,13804]
===
match
---
operator: , [3832,3833]
operator: , [4532,4533]
===
match
---
name: clear [13495,13500]
name: clear [15662,15667]
===
match
---
name: datetime [7517,7525]
name: datetime [9251,9259]
===
match
---
name: try_number [10338,10348]
name: try_number [12505,12515]
===
match
---
operator: = [13509,13510]
operator: = [15676,15677]
===
match
---
operator: == [13477,13479]
operator: == [15644,15646]
===
match
---
name: TI [2110,2112]
name: TI [2439,2441]
===
match
---
trailer [5496,5504]
trailer [6530,6538]
===
match
---
expr_stmt [11070,11095]
expr_stmt [13237,13262]
===
match
---
operator: , [879,880]
operator: , [879,880]
===
match
---
number: 4 [10224,10225]
number: 4 [12391,12392]
===
match
---
operator: = [4147,4148]
operator: = [4847,4848]
===
match
---
operator: = [1675,1676]
operator: = [1675,1676]
===
match
---
trailer [8694,8701]
trailer [10792,10799]
===
match
---
trailer [8179,8195]
trailer [9913,9929]
===
match
---
operator: = [1318,1319]
operator: = [1318,1319]
===
match
---
trailer [13377,13381]
trailer [15544,15548]
===
match
---
operator: , [3795,3796]
operator: , [4495,4496]
===
match
---
atom_expr [11528,11540]
atom_expr [13695,13707]
===
match
---
param [1460,1469]
param [1460,1469]
===
match
---
argument [13207,13226]
argument [15374,15393]
===
match
---
name: DagRunType [7849,7859]
name: DagRunType [9583,9593]
===
match
---
operator: = [3819,3820]
operator: = [4519,4520]
===
match
---
name: ti0 [9617,9620]
name: ti0 [11784,11787]
===
match
---
trailer [11346,11357]
trailer [13513,13524]
===
match
---
atom [3418,3471]
atom [4118,4171]
===
match
---
suite [11937,12107]
suite [14104,14274]
===
match
---
name: create_session [8043,8057]
name: create_session [9777,9791]
===
match
---
name: ti1 [9864,9867]
name: ti1 [12031,12034]
===
match
---
trailer [11953,11956]
trailer [14120,14123]
===
match
---
trailer [4067,4075]
trailer [4767,4775]
===
match
---
name: ti0 [1895,1898]
name: ti0 [1895,1898]
===
match
---
trailer [6596,6614]
trailer [7980,7998]
===
match
---
simple_stmt [2317,2342]
simple_stmt [2667,2692]
===
match
---
simple_stmt [7272,7357]
simple_stmt [9006,9091]
===
match
---
trailer [3090,3092]
trailer [3440,3442]
===
match
---
operator: = [2202,2203]
operator: = [2552,2553]
===
match
---
comparison [4616,4637]
comparison [5650,5671]
===
match
---
trailer [12987,12997]
trailer [15154,15164]
===
match
---
assert_stmt [2487,2512]
assert_stmt [2837,2862]
===
match
---
name: all [2146,2149]
name: all [2496,2499]
===
match
---
parameters [10412,10418]
parameters [12579,12585]
===
match
---
atom_expr [5924,5938]
atom_expr [7308,7322]
===
match
---
name: task [11111,11115]
name: task [13278,13282]
===
match
---
trailer [2010,2014]
trailer [2010,2014]
===
match
---
trailer [13218,13226]
trailer [15385,15393]
===
match
---
comparison [12573,12595]
comparison [14740,14762]
===
match
---
name: airflow [993,1000]
name: airflow [993,1000]
===
match
---
name: ti0 [2937,2940]
name: ti0 [3287,3290]
===
match
---
operator: , [1832,1833]
operator: , [1832,1833]
===
match
---
atom_expr [4697,4724]
atom_expr [5731,5758]
===
match
---
name: task0 [5491,5496]
name: task0 [6525,6530]
===
match
---
operator: , [5706,5707]
operator: , [7090,7091]
===
match
---
atom_expr [8274,8284]
atom_expr [10008,10018]
===
match
---
name: SUCCESS [12016,12023]
name: SUCCESS [14183,14190]
===
match
---
atom_expr [13374,13383]
atom_expr [15541,15550]
===
match
---
trailer [2113,2120]
trailer [2442,2449]
===
match
---
name: end_date [12955,12963]
name: end_date [15122,15130]
===
match
---
arith_expr [7502,7544]
arith_expr [9236,9278]
===
match
---
trailer [10817,10820]
trailer [12984,12987]
===
match
---
simple_stmt [12436,12461]
simple_stmt [14603,14628]
===
match
---
atom_expr [12229,12254]
atom_expr [14396,14421]
===
match
---
name: try_number [2463,2473]
name: try_number [2813,2823]
===
match
---
atom_expr [6960,6981]
atom_expr [8694,8715]
===
match
---
name: refresh_from_db [10116,10131]
name: refresh_from_db [12283,12298]
===
match
---
assert_stmt [4690,4743]
assert_stmt [5724,5777]
===
match
---
number: 3 [11813,11814]
number: 3 [13980,13981]
===
match
---
atom_expr [12257,12269]
atom_expr [14424,14436]
===
match
---
arglist [3388,3471]
arglist [4088,4171]
===
match
---
name: dag_id [2138,2144]
name: dag_id [2467,2473]
===
match
---
trailer [3425,3432]
trailer [4125,4132]
===
match
---
number: 2 [9746,9747]
number: 2 [11913,11914]
===
match
---
name: self [8948,8952]
name: self [11115,11119]
===
match
---
name: try_number [13591,13601]
name: try_number [15758,15768]
===
match
---
name: run_id [8384,8390]
name: run_id [10118,10124]
===
match
---
comparison [12732,12754]
comparison [14899,14921]
===
match
---
name: all [4435,4438]
name: all [5469,5472]
===
match
---
atom_expr [8705,8715]
atom_expr [10803,10813]
===
match
---
arglist [3768,3898]
arglist [4468,4598]
===
match
---
name: session [3112,3119]
name: session [3791,3798]
===
match
---
name: TaskReschedule [8310,8324]
name: TaskReschedule [10044,10058]
===
match
---
name: ti1 [10112,10115]
name: ti1 [12279,12282]
===
match
---
name: dr [4149,4151]
name: dr [4849,4851]
===
match
---
name: session [2190,2197]
name: session [2540,2547]
===
match
---
trailer [10623,10626]
trailer [12790,12793]
===
match
---
atom_expr [4410,4419]
atom_expr [5423,5432]
===
match
---
name: dag_maker [6125,6134]
name: dag_maker [7509,7518]
===
match
---
simple_stmt [12612,12641]
simple_stmt [14779,14808]
===
match
---
name: start_date [7456,7466]
name: start_date [9190,9200]
===
match
---
name: dr [10858,10860]
name: dr [13025,13027]
===
match
---
operator: == [2474,2476]
operator: == [2824,2826]
===
match
---
argument [9249,9258]
argument [11416,11425]
===
match
---
name: query [5622,5627]
name: query [6985,6990]
===
match
---
operator: , [8786,8787]
operator: , [10953,10954]
===
match
---
trailer [12091,12101]
trailer [14258,14268]
===
match
---
name: models [1196,1202]
name: models [1196,1202]
===
match
---
operator: = [4910,4911]
operator: = [5944,5945]
===
match
---
trailer [2145,2149]
trailer [2495,2499]
===
match
---
trailer [4699,4724]
trailer [5733,5758]
===
match
---
name: add [3055,3058]
name: add [3405,3408]
===
match
---
argument [10898,10925]
argument [13065,13092]
===
match
---
arglist [8692,8742]
arglist [10790,10840]
===
match
---
operator: == [2131,2133]
operator: == [2460,2462]
===
match
---
atom_expr [11834,11850]
atom_expr [14001,14017]
===
match
---
comparison [2494,2512]
comparison [2844,2862]
===
match
---
trailer [10727,10736]
trailer [12894,12903]
===
match
---
atom_expr [5639,5648]
atom_expr [7002,7011]
===
match
---
trailer [1990,1997]
trailer [1990,1997]
===
match
---
import_from [1142,1184]
import_from [1142,1184]
===
match
---
simple_stmt [4576,4601]
simple_stmt [5610,5635]
===
match
---
name: state [12249,12254]
name: state [14416,14421]
===
match
---
operator: , [7735,7736]
operator: , [9469,9470]
===
match
---
trailer [11312,11320]
trailer [13479,13487]
===
match
---
name: SCHEDULED [1866,1875]
name: SCHEDULED [1866,1875]
===
match
---
trailer [11717,11721]
trailer [13884,13888]
===
match
---
name: DummyOperator [9135,9148]
name: DummyOperator [11302,11315]
===
match
---
name: State [7813,7818]
name: State [9547,9552]
===
match
---
name: dag_maker [12835,12844]
name: dag_maker [15002,15011]
===
match
---
argument [9149,9180]
argument [11316,11347]
===
match
---
name: dag [4509,4512]
name: dag [5543,5546]
===
match
---
name: task_id [8111,8118]
name: task_id [9845,9852]
===
match
---
name: create_session [5567,5581]
name: create_session [6601,6615]
===
match
---
name: types [1161,1166]
name: types [1161,1166]
===
match
---
operator: == [7116,7118]
operator: == [8850,8852]
===
match
---
simple_stmt [788,804]
simple_stmt [788,804]
===
match
---
name: i [12736,12737]
name: i [14903,14904]
===
match
---
name: State [4650,4655]
name: State [5684,5689]
===
match
---
name: dag [5003,5006]
name: dag [6037,6040]
===
match
---
atom_expr [8369,8390]
atom_expr [10103,10124]
===
match
---
operator: == [8391,8393]
operator: == [10125,10127]
===
match
---
operator: = [13109,13110]
operator: = [15276,15277]
===
match
---
comparison [2357,2376]
comparison [2707,2726]
===
match
---
trailer [11837,11840]
trailer [14004,14007]
===
match
---
argument [5172,5191]
argument [6206,6225]
===
match
---
number: 2 [13794,13795]
number: 2 [15961,15962]
===
match
---
name: DEFAULT_DATE [4205,4217]
name: DEFAULT_DATE [4905,4917]
===
match
---
atom_expr [2096,2151]
atom_expr [2425,2501]
===
match
---
name: session [2096,2103]
name: session [2425,2432]
===
match
---
trailer [1935,1953]
trailer [1935,1953]
===
match
---
suite [3916,4006]
suite [4616,4706]
===
match
---
operator: , [13006,13007]
operator: , [15173,15174]
===
match
---
simple_stmt [9992,10019]
simple_stmt [12159,12186]
===
match
---
name: run_type [1846,1854]
name: run_type [1846,1854]
===
match
---
name: ti0 [10334,10337]
name: ti0 [12501,12504]
===
match
---
trailer [6724,6726]
trailer [8108,8110]
===
match
---
trailer [6459,6546]
trailer [7843,7930]
===
match
---
simple_stmt [11070,11096]
simple_stmt [13237,13263]
===
match
---
trailer [1494,1648]
trailer [1494,1648]
===
match
---
operator: , [1572,1573]
operator: , [1572,1573]
===
match
---
comparison [8825,8864]
comparison [10992,11031]
===
match
---
trailer [11972,11974]
trailer [14139,14141]
===
match
---
trailer [12997,13006]
trailer [15164,15173]
===
match
---
trailer [12458,12460]
trailer [14625,14627]
===
match
---
name: clear_task_instances [2164,2184]
name: clear_task_instances [2514,2534]
===
match
---
atom_expr [6380,6421]
atom_expr [7764,7805]
===
match
---
argument [2765,2772]
argument [3115,3122]
===
match
---
simple_stmt [9127,9182]
simple_stmt [11294,11349]
===
match
---
name: dag [5525,5528]
name: dag [6559,6562]
===
match
---
string: 'test_operator_clear' [12883,12904]
string: 'test_operator_clear' [15050,15071]
===
match
---
simple_stmt [6825,6860]
simple_stmt [8559,8594]
===
match
---
name: clear_dags [11417,11427]
name: clear_dags [13584,13594]
===
match
---
name: mark [3362,3366]
name: mark [4062,4066]
===
match
---
name: run_type [13240,13248]
name: run_type [15407,15415]
===
match
---
atom_expr [9504,9532]
atom_expr [11671,11699]
===
match
---
name: last_scheduling [3534,3549]
name: last_scheduling [4234,4249]
===
match
---
name: i [11447,11448]
name: i [13614,13615]
===
match
---
name: refresh [4555,4562]
name: refresh [5589,5596]
===
match
---
simple_stmt [5952,5978]
simple_stmt [7336,7362]
===
match
---
simple_stmt [10858,11058]
simple_stmt [13025,13225]
===
match
---
operator: + [10812,10813]
operator: + [12979,12980]
===
match
---
trailer [11139,11146]
trailer [13306,13313]
===
match
---
atom_expr [8019,8028]
atom_expr [9753,9762]
===
match
---
operator: = [5077,5078]
operator: = [6111,6112]
===
match
---
testlist_comp [3419,3470]
testlist_comp [4119,4170]
===
match
---
name: task_instances [9444,9458]
name: task_instances [11611,11625]
===
match
---
name: create_dagrun [5145,5158]
name: create_dagrun [6179,6192]
===
match
---
atom_expr [4062,4075]
atom_expr [4762,4775]
===
match
---
name: dag [2134,2137]
name: dag [2463,2466]
===
match
---
simple_stmt [10027,10053]
simple_stmt [12194,12220]
===
match
---
for_stmt [10532,11179]
for_stmt [12699,13346]
===
match
---
trailer [5663,5667]
trailer [7047,7051]
===
match
---
operator: == [9743,9745]
operator: == [11910,11912]
===
match
---
trailer [6693,6695]
trailer [8077,8079]
===
match
---
suite [4809,6047]
suite [5843,7431]
===
match
---
name: op2 [13361,13364]
name: op2 [15528,15531]
===
match
---
name: DagRunType [5214,5224]
name: DagRunType [6248,6258]
===
match
---
comparison [4583,4600]
comparison [5617,5634]
===
match
---
simple_stmt [4014,4130]
simple_stmt [4714,4830]
===
match
---
name: op1 [13338,13341]
name: op1 [15505,15508]
===
match
---
assert_stmt [2452,2478]
assert_stmt [2802,2828]
===
match
---
name: clear_task_instances [3180,3200]
name: clear_task_instances [3880,3900]
===
match
---
atom_expr [2805,2835]
atom_expr [3155,3185]
===
match
---
argument [10785,10820]
argument [12952,12987]
===
match
---
operator: , [2708,2709]
operator: , [3058,3059]
===
match
---
operator: = [3989,3990]
operator: = [4689,4690]
===
match
---
expr_stmt [7890,7918]
expr_stmt [9624,9652]
===
match
---
trailer [2236,2238]
trailer [2586,2588]
===
match
---
parameters [12828,12845]
parameters [14995,15012]
===
match
---
arglist [10785,10843]
arglist [12952,13010]
===
match
---
simple_stmt [6990,7012]
simple_stmt [8724,8746]
===
match
---
name: count_task_reschedule [8884,8905]
name: count_task_reschedule [11051,11072]
===
match
---
operator: = [1854,1855]
operator: = [1854,1855]
===
match
---
simple_stmt [9973,9983]
simple_stmt [12140,12150]
===
match
---
operator: = [9053,9054]
operator: = [11220,11221]
===
match
---
operator: == [8702,8704]
operator: == [10800,10802]
===
match
---
operator: = [10520,10521]
operator: = [12687,12688]
===
match
---
operator: , [11884,11885]
operator: , [14051,14052]
===
match
---
simple_stmt [9617,9627]
simple_stmt [11784,11794]
===
match
---
argument [10980,11009]
argument [13147,13176]
===
match
---
name: ti0 [10082,10085]
name: ti0 [12249,12252]
===
match
---
trailer [12784,12794]
trailer [14951,14961]
===
match
---
name: ti1 [9435,9438]
name: ti1 [11602,11605]
===
match
---
trailer [9904,9909]
trailer [12071,12076]
===
match
---
operator: == [11633,11635]
operator: == [13800,13802]
===
match
---
argument [2685,2708]
argument [3035,3058]
===
match
---
operator: == [13863,13865]
operator: == [16030,16032]
===
match
---
name: start_date [1549,1559]
name: start_date [1549,1559]
===
match
---
operator: + [3868,3869]
operator: + [4568,4569]
===
match
---
atom [5456,5458]
atom [6490,6492]
===
match
---
operator: = [4017,4018]
operator: = [4717,4718]
===
match
---
name: state [3283,3288]
name: state [3983,3988]
===
match
---
name: SUCCESS [4302,4309]
name: SUCCESS [5002,5009]
===
match
---
atom_expr [7813,7826]
atom_expr [9547,9560]
===
match
---
atom_expr [6990,7011]
atom_expr [8724,8745]
===
match
---
name: op2 [13082,13085]
name: op2 [15249,15252]
===
match
---
atom_expr [11135,11151]
atom_expr [13302,13318]
===
match
---
simple_stmt [5329,5358]
simple_stmt [6363,6392]
===
match
---
name: clear_task_instances [4449,4469]
name: clear_task_instances [5483,5503]
===
match
---
argument [13501,13514]
argument [15668,15681]
===
match
---
name: start_date [4619,4629]
name: start_date [5653,5663]
===
match
---
assert_stmt [12771,12799]
assert_stmt [14938,14966]
===
match
---
operator: , [1535,1536]
operator: , [1535,1536]
===
match
---
simple_stmt [11521,11555]
simple_stmt [13688,13722]
===
match
---
argument [9311,9330]
argument [11478,11497]
===
match
---
name: DAG [11865,11868]
name: DAG [14032,14035]
===
match
---
trailer [8575,8583]
trailer [10309,10317]
===
match
---
name: ti1 [9837,9840]
name: ti1 [12004,12007]
===
match
---
trailer [13494,13500]
trailer [15661,15667]
===
match
---
atom_expr [4583,4591]
atom_expr [5617,5625]
===
match
---
trailer [10470,10472]
trailer [12637,12639]
===
match
---
name: tis [12229,12232]
name: tis [14396,14399]
===
match
---
simple_stmt [2419,2444]
simple_stmt [2769,2794]
===
match
---
name: last_scheduling_decision [4178,4202]
name: last_scheduling_decision [4878,4902]
===
match
---
name: timedelta [6271,6280]
name: timedelta [7655,7664]
===
match
---
operator: , [3525,3526]
operator: , [4225,4226]
===
match
---
atom_expr [6329,6359]
atom_expr [7713,7743]
===
match
---
name: state [2907,2912]
name: state [3257,3262]
===
match
---
name: ti0 [2392,2395]
name: ti0 [2742,2745]
===
match
---
arglist [7693,7754]
arglist [9427,9488]
===
match
---
simple_stmt [10764,10845]
simple_stmt [12931,13012]
===
match
---
trailer [3136,3161]
trailer [3815,3840]
===
match
---
name: run_type [5205,5213]
name: run_type [6239,6247]
===
match
---
number: 2 [6011,6012]
number: 2 [7395,7396]
===
match
---
operator: = [13565,13566]
operator: = [15732,15733]
===
match
---
trailer [2497,2507]
trailer [2847,2857]
===
match
---
trailer [8509,8511]
trailer [10243,10245]
===
match
---
simple_stmt [13165,13281]
simple_stmt [15332,15448]
===
match
---
trailer [9766,9772]
trailer [11933,11939]
===
match
---
simple_stmt [4690,4744]
simple_stmt [5724,5778]
===
match
---
trailer [11385,11388]
trailer [13552,13555]
===
match
---
number: 10 [6286,6288]
number: 10 [7670,7672]
===
match
---
argument [6394,6409]
argument [7778,7793]
===
match
---
funcdef [7195,8924]
funcdef [8929,11091]
===
match
---
name: retries [1751,1758]
name: retries [1751,1758]
===
match
---
operator: + [7515,7516]
operator: + [9249,9250]
===
match
---
name: DEFAULT_DATE [12964,12976]
name: DEFAULT_DATE [15131,15143]
===
match
---
operator: = [4236,4237]
operator: = [4936,4937]
===
match
---
trailer [5962,5972]
trailer [7346,7356]
===
match
---
name: timedelta [2755,2764]
name: timedelta [3105,3114]
===
match
---
atom_expr [4423,4433]
atom_expr [5436,5446]
===
match
---
trailer [1359,1373]
trailer [1359,1373]
===
match
---
comparison [4410,4433]
comparison [5423,5446]
===
match
---
name: fixture [1291,1298]
name: fixture [1291,1298]
===
match
---
trailer [13193,13280]
trailer [15360,15447]
===
match
---
trailer [11580,11591]
trailer [13747,13758]
===
match
---
trailer [6484,6492]
trailer [7868,7876]
===
match
---
name: dag_id [3154,3160]
name: dag_id [3833,3839]
===
match
---
operator: , [8284,8285]
operator: , [10018,10019]
===
match
---
param [7252,7261]
param [8986,8995]
===
match
---
simple_stmt [9582,9609]
simple_stmt [11749,11776]
===
match
---
trailer [11721,11723]
trailer [13888,13890]
===
match
---
operator: , [1898,1899]
operator: , [1898,1899]
===
match
---
trailer [12210,12215]
trailer [14377,14382]
===
match
---
name: days [2765,2769]
name: days [3115,3119]
===
match
---
trailer [11577,11580]
trailer [13744,13747]
===
match
---
atom_expr [6125,6300]
atom_expr [7509,7684]
===
match
---
name: self [12829,12833]
name: self [14996,15000]
===
match
---
name: test_dag_clear [8933,8947]
name: test_dag_clear [11100,11114]
===
match
---
trailer [11531,11534]
trailer [13698,13701]
===
match
---
arith_expr [10600,10626]
arith_expr [12767,12793]
===
match
---
name: count_task_reschedule [8550,8571]
name: count_task_reschedule [10284,10305]
===
match
---
name: qry [3201,3204]
name: qry [3901,3904]
===
match
---
atom_expr [3137,3146]
atom_expr [3816,3825]
===
match
---
simple_stmt [2487,2513]
simple_stmt [2837,2863]
===
match
---
name: State [11544,11549]
name: State [13711,13716]
===
match
---
testlist_star_expr [5255,5263]
testlist_star_expr [6289,6297]
===
match
---
with_item [1485,1655]
with_item [1485,1655]
===
match
---
atom_expr [1724,1761]
atom_expr [1724,1761]
===
match
---
name: create_dagrun [4029,4042]
name: create_dagrun [4729,4742]
===
match
---
atom_expr [7371,7555]
atom_expr [9105,9289]
===
match
---
trailer [5443,5453]
trailer [6477,6487]
===
match
---
expr_stmt [11108,11122]
expr_stmt [13275,13289]
===
match
---
operator: == [5973,5975]
operator: == [7357,7359]
===
match
---
name: timedelta [3879,3888]
name: timedelta [4579,4588]
===
match
---
for_stmt [11443,11638]
for_stmt [13610,13805]
===
match
---
trailer [8443,8454]
trailer [10177,10188]
===
match
---
number: 3 [10259,10260]
number: 3 [12426,12427]
===
match
---
name: TI [6771,6773]
name: TI [8484,8486]
===
match
---
name: refresh_from_db [5821,5836]
name: refresh_from_db [7205,7220]
===
match
---
suite [2792,2836]
suite [3142,3186]
===
match
---
name: state [9311,9316]
name: state [11478,11483]
===
match
---
simple_stmt [2903,2929]
simple_stmt [3253,3279]
===
match
---
atom_expr [1677,1703]
atom_expr [1677,1703]
===
match
---
operator: , [4118,4119]
operator: , [4818,4819]
===
match
---
trailer [3981,4005]
trailer [4681,4705]
===
match
---
name: run [9621,9624]
name: run [11788,11791]
===
match
---
string: """Test that DR state is set to None after clear.         And that DR.last_scheduling_decision is handled OK.         start_date is also set to None         """ [3571,3731]
string: """Test that DR state is set to None after clear.         And that DR.last_scheduling_decision is handled OK.         start_date is also set to None         """ [4271,4431]
===
match
---
trailer [8691,8743]
trailer [10789,10841]
===
match
---
name: clear_task_instances [917,937]
name: clear_task_instances [917,937]
===
match
---
comparison [12682,12708]
comparison [14849,14875]
===
match
---
simple_stmt [5367,5377]
simple_stmt [6401,6411]
===
match
---
comparison [13776,13795]
comparison [15943,15962]
===
match
---
name: try_number [13780,13790]
name: try_number [15947,15957]
===
match
---
suite [8120,8530]
suite [9854,10264]
===
match
---
trailer [10546,10559]
trailer [12713,12726]
===
match
---
assert_stmt [3309,3348]
assert_stmt [4009,4048]
===
match
---
argument [12368,12384]
argument [14535,14551]
===
match
---
operator: , [6098,6099]
operator: , [7482,7483]
===
match
---
name: dag [3219,3222]
name: dag [3919,3922]
===
match
---
trailer [13330,13335]
trailer [15497,15502]
===
match
---
operator: = [10732,10733]
operator: = [12899,12900]
===
match
---
name: max_tries [10211,10220]
name: max_tries [12378,12387]
===
match
---
name: task1 [9194,9199]
name: task1 [11361,11366]
===
match
---
simple_stmt [13542,13572]
simple_stmt [15709,15739]
===
match
---
trailer [10372,10382]
trailer [12539,12549]
===
match
---
name: dag [4505,4508]
name: dag [5539,5542]
===
match
---
operator: , [4482,4483]
operator: , [5516,5517]
===
match
---
string: '1' [1746,1749]
string: '1' [1746,1749]
===
match
---
simple_stmt [5608,5670]
simple_stmt [6971,7054]
===
match
---
simple_stmt [11135,11152]
simple_stmt [13302,13319]
===
match
---
name: session [2069,2076]
name: session [2069,2076]
===
match
---
operator: = [12379,12380]
operator: = [14546,14547]
===
match
---
trailer [9867,9878]
trailer [12034,12045]
===
match
---
atom_expr [10620,10626]
atom_expr [12787,12793]
===
match
---
simple_stmt [8001,8011]
simple_stmt [9735,9745]
===
match
---
comparison [9837,9855]
comparison [12004,12022]
===
match
---
name: state [11298,11303]
name: state [13465,13470]
===
match
---
name: all [8744,8747]
name: all [10897,10900]
===
match
---
param [8948,8953]
param [11115,11120]
===
match
---
operator: = [10792,10793]
operator: = [12959,12960]
===
match
---
operator: , [2188,2189]
operator: , [2538,2539]
===
match
---
name: task [13331,13335]
name: task [15498,15502]
===
match
---
name: DummyOperator [13037,13050]
name: DummyOperator [15204,15217]
===
match
---
with_stmt [2595,2836]
with_stmt [2945,3186]
===
match
---
trailer [13545,13549]
trailer [15712,15716]
===
match
---
name: ti1 [5993,5996]
name: ti1 [7377,7380]
===
match
---
simple_stmt [2164,2208]
simple_stmt [2514,2558]
===
match
---
simple_stmt [4449,4514]
simple_stmt [5483,5548]
===
match
---
atom_expr [13249,13269]
atom_expr [15416,15436]
===
match
---
atom_expr [1610,1637]
atom_expr [1610,1637]
===
match
---
name: ti1 [2494,2497]
name: ti1 [2844,2847]
===
match
---
name: dag_maker [8979,8988]
name: dag_maker [11146,11155]
===
match
---
name: ti0 [8001,8004]
name: ti0 [9735,9738]
===
match
---
atom_expr [6028,6041]
atom_expr [7412,7425]
===
match
---
string: '0' [7605,7608]
string: '0' [9339,9342]
===
match
---
atom_expr [5266,5283]
atom_expr [6300,6317]
===
match
---
simple_stmt [6686,6696]
simple_stmt [8070,8080]
===
match
---
name: State [12257,12262]
name: State [14424,14429]
===
match
---
trailer [4535,4537]
trailer [5569,5571]
===
match
---
suite [3562,4744]
suite [4262,5778]
===
match
---
name: PythonSensor [7584,7596]
name: PythonSensor [9318,9330]
===
match
---
expr_stmt [8661,8749]
expr_stmt [10724,10916]
===
match
---
name: session [12321,12328]
name: session [14488,14495]
===
match
---
operator: = [6755,6756]
operator: = [8468,8469]
===
match
---
parameters [6093,6110]
parameters [7477,7494]
===
match
---
atom_expr [12196,12220]
atom_expr [14363,14387]
===
match
---
name: task0 [1669,1674]
name: task0 [1669,1674]
===
match
---
comparison [10369,10387]
comparison [12536,12554]
===
match
---
name: qry [4470,4473]
name: qry [5504,5507]
===
match
---
name: ti0 [5292,5295]
name: ti0 [6326,6329]
===
match
---
trailer [2063,2065]
trailer [2063,2065]
===
match
---
name: dag [2203,2206]
name: dag [2553,2556]
===
match
---
funcdef [12805,13868]
funcdef [14972,16035]
===
match
---
atom_expr [2121,2130]
atom_expr [2450,2459]
===
match
---
trailer [9470,9488]
trailer [11637,11655]
===
match
---
trailer [10037,10047]
trailer [12204,12214]
===
match
---
name: session [8063,8070]
name: session [9797,9804]
===
match
---
name: days [7536,7540]
name: days [9270,9274]
===
match
---
with_stmt [8974,9260]
with_stmt [11141,11427]
===
match
---
operator: @ [1283,1284]
operator: @ [1283,1284]
===
match
---
string: "state" [3389,3396]
string: "state" [4089,4096]
===
match
---
operator: = [12255,12256]
operator: = [14422,14423]
===
match
---
testlist_star_expr [6556,6564]
testlist_star_expr [7940,7948]
===
match
---
trailer [13353,13358]
trailer [15520,15525]
===
match
---
trailer [4409,4434]
trailer [5422,5447]
===
match
---
import_as_names [1117,1141]
import_as_names [1117,1141]
===
match
---
simple_stmt [11711,11724]
simple_stmt [13878,13891]
===
match
---
name: dag_maker [12860,12869]
name: dag_maker [15027,15036]
===
match
---
name: session [4522,4529]
name: session [5556,5563]
===
match
---
atom_expr [11544,11554]
atom_expr [13711,13721]
===
match
---
atom_expr [5329,5357]
atom_expr [6363,6391]
===
match
---
name: DagRunType [10989,10999]
name: DagRunType [13156,13166]
===
match
---
trailer [11174,11178]
trailer [13341,13345]
===
match
---
expr_stmt [12229,12269]
expr_stmt [14396,14436]
===
match
---
comparison [8609,8648]
comparison [10343,10382]
===
match
---
name: DummyOperator [3968,3981]
name: DummyOperator [4668,4681]
===
match
---
name: query [2104,2109]
name: query [2433,2438]
===
match
---
name: refresh_from_db [6994,7009]
name: refresh_from_db [8728,8743]
===
match
---
name: all [5664,5667]
name: all [7048,7051]
===
match
---
param [4798,4807]
param [5832,5841]
===
match
---
trailer [8571,8584]
trailer [10305,10318]
===
match
---
operator: = [1698,1699]
operator: = [1698,1699]
===
match
---
atom_expr [10579,10751]
atom_expr [12746,12918]
===
match
---
operator: , [12833,12834]
operator: , [15000,15001]
===
match
---
trailer [9443,9458]
trailer [11610,11625]
===
match
---
atom_expr [8249,8270]
atom_expr [9983,10004]
===
match
---
operator: == [10221,10223]
operator: == [12388,12390]
===
match
---
comparison [11574,11596]
comparison [13741,13763]
===
match
---
name: RUNNING [13219,13226]
name: RUNNING [15386,15393]
===
match
---
name: dag_maker [9403,9412]
name: dag_maker [11570,11579]
===
match
---
name: clear [9675,9680]
name: clear [11842,11847]
===
match
---
name: i [11913,11914]
name: i [14080,14081]
===
match
---
argument [3982,3993]
argument [4682,4693]
===
match
---
atom_expr [5847,5868]
atom_expr [7231,7252]
===
match
---
name: filter [4403,4409]
name: filter [5416,5422]
===
match
---
trailer [8734,8742]
trailer [10832,10840]
===
match
---
argument [13051,13068]
argument [15218,15235]
===
match
---
name: ti0 [8731,8734]
name: ti0 [10829,10832]
===
match
---
atom_expr [2392,2405]
atom_expr [2742,2755]
===
match
---
name: max_tries [2396,2405]
name: max_tries [2746,2755]
===
match
---
argument [2199,2206]
argument [2549,2556]
===
match
---
atom_expr [12043,12060]
atom_expr [14210,14227]
===
match
---
import_from [1036,1084]
import_from [1036,1084]
===
match
---
import_from [1223,1254]
import_from [1223,1254]
===
match
---
trailer [3282,3288]
trailer [3982,3988]
===
match
---
comparison [5639,5662]
comparison [7002,7025]
===
match
---
name: query [6765,6770]
name: query [8478,8483]
===
match
---
number: 0 [13759,13760]
number: 0 [15926,15927]
===
match
---
atom_expr [11679,11697]
atom_expr [13846,13864]
===
match
---
operator: = [13086,13087]
operator: = [15253,15254]
===
match
---
trailer [9898,9904]
trailer [12065,12071]
===
match
---
name: dag_maker [3745,3754]
name: dag_maker [4445,4454]
===
match
---
comparison [9728,9747]
comparison [11895,11914]
===
match
---
atom_expr [8731,8742]
atom_expr [10829,10840]
===
match
---
trailer [6525,6535]
trailer [7909,7919]
===
match
---
string: 'test_clear_task_instances' [3768,3795]
string: 'test_clear_task_instances' [4468,4495]
===
match
---
name: dag [5440,5443]
name: dag [6474,6477]
===
match
---
name: clear_dags [12351,12361]
name: clear_dags [14518,14528]
===
match
---
expr_stmt [9127,9181]
expr_stmt [11294,11348]
===
match
---
param [1454,1459]
param [1454,1459]
===
match
---
atom_expr [10989,11009]
atom_expr [13156,13176]
===
match
---
simple_stmt [10508,10524]
simple_stmt [12675,12691]
===
match
---
simple_stmt [12278,12313]
simple_stmt [14445,14480]
===
match
---
trailer [13779,13790]
trailer [15946,15957]
===
match
---
operator: = [3218,3219]
operator: = [3918,3919]
===
match
---
atom_expr [9353,9373]
atom_expr [11520,11540]
===
match
---
trailer [13101,13132]
trailer [15268,15299]
===
match
---
number: 2 [7154,7155]
number: 2 [8888,8889]
===
match
---
suite [8965,10388]
suite [11132,12555]
===
match
---
number: 2 [6045,6046]
number: 2 [7429,7430]
===
match
---
trailer [9525,9532]
trailer [11692,11699]
===
match
---
comparison [11528,11554]
comparison [13695,13721]
===
match
---
operator: = [5049,5050]
operator: = [6083,6084]
===
match
---
trailer [2876,2891]
trailer [3226,3241]
===
match
---
operator: = [9352,9353]
operator: = [11519,11520]
===
match
---
operator: , [9247,9248]
operator: , [11414,11415]
===
match
---
name: ti0 [6556,6559]
name: ti0 [7940,7943]
===
match
---
trailer [10244,10255]
trailer [12411,12422]
===
match
---
name: ti1 [9504,9507]
name: ti1 [11671,11674]
===
match
---
suite [7263,8924]
suite [8997,11091]
===
match
---
trailer [7818,7826]
trailer [9552,9560]
===
match
---
name: ti [11175,11177]
name: ti [13342,13344]
===
match
---
expr_stmt [9393,9420]
expr_stmt [11560,11587]
===
match
---
atom_expr [9403,9420]
atom_expr [11570,11587]
===
match
---
name: session [9891,9898]
name: session [12058,12065]
===
match
---
operator: = [7645,7646]
operator: = [9379,9380]
===
match
---
trailer [11110,11115]
trailer [13277,13282]
===
match
---
name: ti1 [2247,2250]
name: ti1 [2597,2600]
===
match
---
trailer [5866,5868]
trailer [7250,7252]
===
match
---
atom_expr [6825,6859]
atom_expr [8559,8593]
===
match
---
argument [1846,1875]
argument [1846,1875]
===
match
---
comparison [4641,4662]
comparison [5675,5696]
===
match
---
arglist [6148,6290]
arglist [7532,7674]
===
match
---
trailer [5581,5583]
trailer [6615,6617]
===
match
---
name: max_tries [9841,9850]
name: max_tries [12008,12017]
===
match
---
operator: == [10349,10351]
operator: == [12516,12518]
===
match
---
argument [1586,1637]
argument [1586,1637]
===
match
---
string: 'test' [10828,10834]
string: 'test' [12995,13001]
===
match
---
operator: = [13212,13213]
operator: = [15379,15380]
===
match
---
operator: , [7479,7480]
operator: , [9213,9214]
===
match
---
testlist_comp [3420,3438]
testlist_comp [4120,4138]
===
match
---
number: 2 [2477,2478]
number: 2 [2827,2828]
===
match
---
atom_expr [4238,4263]
atom_expr [4938,4963]
===
match
---
operator: == [11592,11594]
operator: == [13759,13761]
===
match
---
operator: , [10495,10496]
operator: , [12662,12663]
===
match
---
operator: = [10988,10989]
operator: = [13155,13156]
===
match
---
atom_expr [2746,2773]
atom_expr [3096,3123]
===
match
---
expr_stmt [1669,1703]
expr_stmt [1669,1703]
===
match
---
operator: = [12963,12964]
operator: = [15130,15131]
===
match
---
name: dag_id [2124,2130]
name: dag_id [2453,2459]
===
match
---
name: task_id [8325,8332]
name: task_id [10059,10066]
===
match
---
name: start_date [10644,10654]
name: start_date [12811,12821]
===
match
---
name: dag_id [5656,5662]
name: dag_id [7019,7025]
===
match
---
test [4616,4681]
test [5650,5715]
===
match
---
argument [7536,7543]
argument [9270,9277]
===
match
---
trailer [9507,9525]
trailer [11674,11692]
===
match
---
atom_expr [13213,13226]
atom_expr [15380,15393]
===
match
---
operator: = [7501,7502]
operator: = [9235,9236]
===
match
---
number: 5 [10522,10523]
number: 5 [12689,12690]
===
match
---
name: start_date [2685,2695]
name: start_date [3035,3045]
===
match
---
assert_stmt [2317,2341]
assert_stmt [2667,2691]
===
match
---
operator: = [2769,2770]
operator: = [3119,3120]
===
match
---
name: RUNNING [9323,9330]
name: RUNNING [11490,11497]
===
match
---
name: state [1813,1818]
name: state [1813,1818]
===
match
---
trailer [11487,11490]
trailer [13654,13657]
===
match
---
name: TaskInstanceState [1124,1141]
name: TaskInstanceState [1124,1141]
===
match
---
name: airflow [854,861]
name: airflow [854,861]
===
match
---
name: task_id [13102,13109]
name: task_id [15269,15276]
===
match
---
operator: , [4796,4797]
operator: , [5830,5831]
===
match
---
comparison [8310,8343]
comparison [10044,10077]
===
match
---
expr_stmt [5071,5120]
expr_stmt [6105,6154]
===
match
---
name: flush [4362,4367]
name: flush [5062,5067]
===
match
---
argument [12998,13005]
argument [15165,15172]
===
match
---
name: ti1 [2025,2028]
name: ti1 [2025,2028]
===
match
---
atom_expr [10454,10472]
atom_expr [12621,12639]
===
match
---
name: ti0 [7102,7105]
name: ti0 [8836,8839]
===
match
---
name: dag_maker [8954,8963]
name: dag_maker [11121,11130]
===
match
---
name: dag_id [6785,6791]
name: dag_id [8498,8504]
===
match
---
param [3527,3533]
param [4227,4233]
===
match
---
name: create_dagrun [9284,9297]
name: create_dagrun [11451,11464]
===
match
---
name: i [11488,11489]
name: i [13655,13656]
===
match
---
name: refresh_from_task [7931,7948]
name: refresh_from_task [9665,9682]
===
match
---
name: datetime [1610,1618]
name: datetime [1610,1618]
===
match
---
trailer [7009,7011]
trailer [8743,8745]
===
match
---
simple_stmt [3309,3349]
simple_stmt [4009,4049]
===
match
---
operator: = [6401,6402]
operator: = [7785,7786]
===
match
---
name: dag_id [4427,4433]
name: dag_id [5440,5446]
===
match
---
trailer [6614,6621]
trailer [7998,8005]
===
match
---
trailer [9840,9850]
trailer [12007,12017]
===
match
---
simple_stmt [10200,10226]
simple_stmt [12367,12393]
===
match
---
simple_stmt [11259,11272]
simple_stmt [13426,13439]
===
match
---
name: try_number [9593,9603]
name: try_number [11760,11770]
===
match
---
comparison [5959,5977]
comparison [7343,7361]
===
match
---
argument [1629,1636]
argument [1629,1636]
===
match
---
trailer [8674,8680]
trailer [10755,10761]
===
match
---
trailer [9412,9420]
trailer [11579,11587]
===
match
---
atom_expr [7517,7544]
atom_expr [9251,9278]
===
match
---
name: max_tries [11841,11850]
name: max_tries [14008,14017]
===
match
---
atom_expr [4354,4369]
atom_expr [5054,5069]
===
match
---
atom_expr [5538,5551]
atom_expr [6572,6585]
===
match
---
trailer [11764,11772]
trailer [13931,13939]
===
match
---
argument [7840,7869]
argument [9574,9603]
===
match
---
param [6100,6109]
param [7484,7493]
===
match
---
name: ti0 [9728,9731]
name: ti0 [11895,11898]
===
match
---
name: run_type [9344,9352]
name: run_type [11511,11519]
===
match
---
operator: = [10654,10655]
operator: = [12821,12822]
===
match
---
atom_expr [12536,12549]
atom_expr [14703,14716]
===
match
---
operator: + [12977,12978]
operator: + [15144,15145]
===
match
---
name: dag_maker [4019,4028]
name: dag_maker [4719,4728]
===
match
---
atom_expr [5567,5583]
atom_expr [6601,6617]
===
match
---
simple_stmt [3272,3297]
simple_stmt [3972,3997]
===
match
---
name: try_number [12050,12060]
name: try_number [14217,14227]
===
match
---
trailer [2028,2032]
trailer [2028,2032]
===
match
---
operator: = [4326,4327]
operator: = [5026,5027]
===
match
---
with_stmt [1480,1762]
with_stmt [1480,1762]
===
match
---
assert_stmt [5514,5552]
assert_stmt [6548,6586]
===
match
---
name: datetime [9069,9077]
name: datetime [11236,11244]
===
match
---
operator: == [11756,11758]
operator: == [13923,13925]
===
match
---
trailer [4618,4629]
trailer [5652,5663]
===
match
---
operator: = [4002,4003]
operator: = [4702,4703]
===
match
---
operator: == [8644,8646]
operator: == [10378,10380]
===
match
---
name: count_task_reschedule [8609,8630]
name: count_task_reschedule [10343,10364]
===
match
---
expr_stmt [13082,13132]
expr_stmt [15249,15299]
===
match
---
name: i [12782,12783]
name: i [14949,14950]
===
match
---
trailer [9624,9626]
trailer [11791,11793]
===
match
---
atom_expr [1906,1923]
atom_expr [1906,1923]
===
match
---
name: mode [7737,7741]
name: mode [9471,9475]
===
match
---
operator: , [3396,3397]
operator: , [4096,4097]
===
match
---
trailer [3139,3146]
trailer [3818,3825]
===
match
---
simple_stmt [9891,9910]
simple_stmt [12058,12077]
===
match
---
name: dag [6304,6307]
name: dag [7688,7691]
===
match
---
atom [3388,3416]
atom [4088,4116]
===
match
---
number: 1 [9881,9882]
number: 1 [12048,12049]
===
match
---
operator: == [4725,4727]
operator: == [5759,5761]
===
match
---
name: task1 [5351,5356]
name: task1 [6385,6390]
===
match
---
name: flush [4530,4535]
name: flush [5564,5569]
===
match
---
funcdef [1332,1419]
funcdef [1332,1419]
===
match
---
atom_expr [8979,9106]
atom_expr [11146,11273]
===
match
---
simple_stmt [12725,12755]
simple_stmt [14892,14922]
===
match
---
name: dag [10573,10576]
name: dag [12740,12743]
===
match
---
atom_expr [4961,4988]
atom_expr [5995,6022]
===
match
---
name: ti0 [3237,3240]
name: ti0 [3937,3940]
===
match
---
trailer [8747,8749]
trailer [10900,10902]
===
match
---
trailer [11388,11398]
trailer [13555,13565]
===
match
---
trailer [3878,3888]
trailer [4578,4588]
===
match
---
name: end_date [3846,3854]
name: end_date [4546,4554]
===
match
---
name: ti0 [4138,4141]
name: ti0 [4838,4841]
===
match
---
operator: == [8919,8921]
operator: == [11086,11088]
===
match
---
param [8111,8118]
param [9845,9852]
===
match
---
operator: == [10014,10016]
operator: == [12181,12183]
===
match
---
trailer [4832,4999]
trailer [5866,6033]
===
match
---
atom_expr [5614,5669]
atom_expr [6977,7053]
===
match
---
name: task_id [8576,8583]
name: task_id [10310,10317]
===
match
---
name: tis [11950,11953]
name: tis [14117,14120]
===
match
---
argument [10836,10843]
argument [13003,13010]
===
match
---
trailer [4398,4402]
trailer [5411,5415]
===
match
---
name: clear_task_instances [6825,6845]
name: clear_task_instances [8559,8579]
===
match
---
trailer [6031,6041]
trailer [7415,7425]
===
match
---
name: DEFAULT_DATE [3820,3832]
name: DEFAULT_DATE [4520,4532]
===
match
---
assert_stmt [13735,13760]
assert_stmt [15902,15927]
===
match
---
assert_stmt [11521,11554]
assert_stmt [13688,13721]
===
match
---
import_from [1185,1222]
import_from [1185,1222]
===
match
---
simple_stmt [13524,13534]
simple_stmt [15691,15701]
===
match
---
name: task0 [9489,9494]
name: task0 [11656,11661]
===
match
---
name: num_of_dags [10547,10558]
name: num_of_dags [12714,12725]
===
match
---
argument [10943,10962]
argument [13110,13129]
===
match
---
simple_stmt [9721,9748]
simple_stmt [11888,11915]
===
match
---
name: RUNNING [7819,7826]
name: RUNNING [9553,9560]
===
match
---
assert_stmt [8877,8923]
assert_stmt [11044,11090]
===
match
---
name: days [6281,6285]
name: days [7665,7669]
===
match
---
name: max_tries [11623,11632]
name: max_tries [13790,13799]
===
match
---
operator: } [5457,5458]
operator: } [6491,6492]
===
match
---
name: ti0 [2007,2010]
name: ti0 [2007,2010]
===
match
---
name: ti0 [8572,8575]
name: ti0 [10306,10309]
===
match
---
operator: + [10707,10708]
operator: + [12874,12875]
===
match
---
name: State [12536,12541]
name: State [14703,14708]
===
match
---
name: DEFAULT_DATE [1560,1572]
name: DEFAULT_DATE [1560,1572]
===
match
---
expr_stmt [6372,6421]
expr_stmt [7756,7805]
===
match
---
simple_stmt [5385,5395]
simple_stmt [6419,6429]
===
match
---
name: ti1 [5329,5332]
name: ti1 [6363,6366]
===
match
---
expr_stmt [10573,10751]
expr_stmt [12740,12918]
===
match
---
number: 2 [1759,1760]
number: 2 [1759,1760]
===
match
---
name: State [10949,10954]
name: State [13116,13121]
===
match
---
expr_stmt [10508,10523]
expr_stmt [12675,12690]
===
match
---
with_stmt [6705,6860]
with_stmt [8089,8594]
===
match
---
operator: , [11009,11010]
operator: , [13176,13177]
===
match
---
operator: + [10618,10619]
operator: + [12785,12786]
===
match
---
name: refresh_from_task [5296,5313]
name: refresh_from_task [6330,6347]
===
match
---
operator: = [5133,5134]
operator: = [6167,6168]
===
match
---
simple_stmt [5817,5839]
simple_stmt [7201,7223]
===
match
---
name: i [11295,11296]
name: i [13462,13463]
===
match
---
operator: == [11851,11853]
operator: == [14018,14020]
===
match
---
argument [3995,4004]
argument [4695,4704]
===
match
---
name: ti1 [13327,13330]
name: ti1 [15494,15497]
===
match
---
atom_expr [11307,11320]
atom_expr [13474,13487]
===
match
---
funcdef [10393,12800]
funcdef [12560,14967]
===
match
---
operator: = [10839,10840]
operator: = [13006,13007]
===
match
---
name: dag [5478,5481]
name: dag [6512,6515]
===
match
---
name: tis [11382,11385]
name: tis [13549,13552]
===
match
---
name: QUEUED [3426,3432]
name: QUEUED [4126,4132]
===
match
---
operator: , [10736,10737]
operator: , [12903,12904]
===
match
---
name: ti2 [13542,13545]
name: ti2 [15709,15712]
===
match
---
name: range [11227,11232]
name: range [13394,13399]
===
match
---
arith_expr [2731,2773]
arith_expr [3081,3123]
===
match
---
trailer [8324,8332]
trailer [10058,10066]
===
match
---
name: dag_maker [9274,9283]
name: dag_maker [11441,11450]
===
match
---
name: ti [11108,11110]
name: ti [13275,13277]
===
match
---
operator: = [9030,9031]
operator: = [11197,11198]
===
match
---
expr_stmt [4014,4129]
expr_stmt [4714,4829]
===
match
---
name: i [11796,11797]
name: i [13963,13964]
===
match
---
name: DEFAULT_DATE [1210,1222]
name: DEFAULT_DATE [1210,1222]
===
match
---
name: ti0 [2845,2848]
name: ti0 [3195,3198]
===
match
---
name: qry [8783,8786]
name: qry [10950,10953]
===
match
---
simple_stmt [13350,13365]
simple_stmt [15517,15532]
===
match
---
trailer [8277,8284]
trailer [10011,10018]
===
match
---
trailer [11798,11809]
trailer [13965,13976]
===
match
---
name: try_number [2361,2371]
name: try_number [2711,2721]
===
match
---
string: 'test_clear_task_instances_without_dag' [6148,6187]
string: 'test_clear_task_instances_without_dag' [7532,7571]
===
match
---
name: task_id [8851,8858]
name: task_id [11018,11025]
===
match
---
argument [10685,10736]
argument [12852,12903]
===
match
---
simple_stmt [6630,6659]
simple_stmt [8014,8043]
===
match
---
name: airflow [825,832]
name: airflow [825,832]
===
match
---
trailer [11146,11151]
trailer [13313,13318]
===
match
---
atom_expr [10771,10844]
atom_expr [12938,13011]
===
match
---
name: ti0 [2324,2327]
name: ti0 [2674,2677]
===
match
---
suite [12423,12800]
suite [14590,14967]
===
match
---
simple_stmt [7765,7881]
simple_stmt [9499,9615]
===
match
---
param [7246,7251]
param [8980,8985]
===
match
---
trailer [3888,3897]
trailer [4588,4597]
===
match
---
testlist_star_expr [1895,1903]
testlist_star_expr [1895,1903]
===
match
---
expr_stmt [9194,9259]
expr_stmt [11361,11426]
===
match
---
operator: = [2913,2914]
operator: = [3263,3264]
===
match
---
operator: = [7741,7742]
operator: = [9475,9476]
===
match
---
trailer [4469,4513]
trailer [5503,5547]
===
match
---
operator: , [13120,13121]
operator: , [15287,15288]
===
match
---
simple_stmt [11736,11773]
simple_stmt [13903,13940]
===
match
---
return_stmt [8137,8529]
return_stmt [9871,10263]
===
match
---
operator: = [4061,4062]
operator: = [4761,4762]
===
match
---
atom_expr [4668,4681]
atom_expr [5702,5715]
===
match
---
trailer [7793,7880]
trailer [9527,9614]
===
match
---
name: session [9918,9925]
name: session [12085,12092]
===
match
---
argument [4505,4512]
argument [5539,5546]
===
match
---
name: DEFAULT_DATE [6247,6259]
name: DEFAULT_DATE [7631,7643]
===
match
---
atom_expr [2357,2371]
atom_expr [2707,2721]
===
match
---
name: filter [8217,8223]
name: filter [9951,9957]
===
match
---
expr_stmt [10764,10844]
expr_stmt [12931,13011]
===
match
---
atom_expr [2217,2238]
atom_expr [2567,2588]
===
match
---
name: failed_dag_idx [12296,12310]
name: failed_dag_idx [14463,14477]
===
match
---
name: ti1 [13742,13745]
name: ti1 [15909,15912]
===
match
---
operator: = [5026,5027]
operator: = [6060,6061]
===
match
---
comparison [3137,3160]
comparison [3816,3839]
===
match
---
parameters [7245,7262]
parameters [8979,8996]
===
match
---
operator: = [5612,5613]
operator: = [6975,6976]
===
match
---
string: '1' [7701,7704]
string: '1' [9435,9438]
===
match
---
trailer [4529,4535]
trailer [5563,5569]
===
match
---
expr_stmt [13031,13069]
expr_stmt [15198,15236]
===
match
---
comparison [13587,13606]
comparison [15754,15773]
===
match
---
atom_expr [12860,13017]
atom_expr [15027,15184]
===
match
---
string: 'test_clear_task_instances_with_task_reschedule' [7394,7442]
string: 'test_clear_task_instances_with_task_reschedule' [9128,9176]
===
match
---
name: dags [10481,10485]
name: dags [12648,12652]
===
match
---
argument [11027,11042]
argument [13194,13209]
===
match
---
simple_stmt [11108,11123]
simple_stmt [13275,13290]
===
match
---
name: DAG [876,879]
name: DAG [876,879]
===
match
---
trailer [6342,6359]
trailer [7726,7743]
===
match
---
name: dag [8801,8804]
name: dag [10968,10971]
===
match
---
simple_stmt [13735,13761]
simple_stmt [15902,15928]
===
match
---
name: test_clear_task_instances_external_executor_id [2522,2568]
name: test_clear_task_instances_external_executor_id [2872,2918]
===
match
---
name: run [11266,11269]
name: run [13433,13436]
===
match
---
trailer [12579,12590]
trailer [14746,14757]
===
match
---
name: DEFAULT_DATE [4946,4958]
name: DEFAULT_DATE [5980,5992]
===
match
---
simple_stmt [3929,3956]
simple_stmt [4629,4656]
===
match
---
string: 'task1' [5101,5108]
string: 'task1' [6135,6142]
===
match
---
atom_expr [5817,5838]
atom_expr [7201,7222]
===
match
---
operator: , [9018,9019]
operator: , [11185,11186]
===
match
---
name: refresh_from_db [12443,12458]
name: refresh_from_db [14610,14625]
===
match
---
name: dag_maker [6436,6445]
name: dag_maker [7820,7829]
===
match
---
arglist [13207,13270]
arglist [15374,15437]
===
match
---
name: max_tries [7175,7184]
name: max_tries [8909,8918]
===
match
---
atom_expr [2600,2784]
atom_expr [2950,3134]
===
match
---
operator: , [12366,12367]
operator: , [14533,14534]
===
match
---
name: refresh_from_db [2251,2266]
name: refresh_from_db [2601,2616]
===
match
---
name: self [1454,1458]
name: self [1454,1458]
===
match
---
simple_stmt [938,988]
simple_stmt [938,988]
===
match
---
name: test_clear_task_instances [1428,1453]
name: test_clear_task_instances [1428,1453]
===
match
---
assert_stmt [10027,10052]
assert_stmt [12194,12219]
===
match
---
arglist [5093,5119]
arglist [6127,6153]
===
match
---
name: try_number [5928,5938]
name: try_number [7312,7322]
===
match
---
operator: , [10962,10963]
operator: , [13129,13130]
===
match
---
atom_expr [4547,4566]
atom_expr [5581,5600]
===
match
---
trailer [2184,2207]
trailer [2534,2557]
===
match
---
atom_expr [5682,5716]
atom_expr [7066,7100]
===
match
---
operator: = [10912,10913]
operator: = [13079,13080]
===
match
---
operator: , [4075,4076]
operator: , [4775,4776]
===
match
---
assert_stmt [12513,12549]
assert_stmt [14680,14716]
===
match
---
simple_stmt [9194,9260]
simple_stmt [11361,11427]
===
match
---
operator: = [6285,6286]
operator: = [7669,7670]
===
match
---
trailer [5374,5376]
trailer [6408,6410]
===
match
---
expr_stmt [13327,13341]
expr_stmt [15494,15508]
===
match
---
operator: , [899,900]
operator: , [899,900]
===
match
---
atom_expr [4616,4629]
atom_expr [5650,5663]
===
match
---
name: task_id [10785,10792]
name: task_id [12952,12959]
===
match
---
simple_stmt [12675,12709]
simple_stmt [14842,14876]
===
match
---
argument [7641,7658]
argument [9375,9392]
===
match
---
atom_expr [11075,11095]
atom_expr [13242,13262]
===
match
---
name: run [13546,13549]
name: run [15713,15716]
===
match
---
name: tis [11792,11795]
name: tis [13959,13962]
===
match
---
name: TI [8681,8683]
name: TI [10762,10764]
===
match
---
simple_stmt [13082,13133]
simple_stmt [15249,15300]
===
match
---
import_from [849,937]
import_from [849,937]
===
match
---
name: only_failed [12368,12379]
name: only_failed [14535,14546]
===
match
---
trailer [3161,3165]
trailer [3861,3865]
===
match
---
name: ti1 [5260,5263]
name: ti1 [6294,6297]
===
match
---
name: end_date [1586,1594]
name: end_date [1586,1594]
===
match
---
trailer [6569,6584]
trailer [7953,7968]
===
match
---
trailer [11956,11972]
trailer [14123,14139]
===
match
---
simple_stmt [5514,5553]
simple_stmt [6548,6587]
===
match
---
with_item [8043,8070]
with_item [9777,9804]
===
match
---
name: sensors [1001,1008]
name: sensors [1001,1008]
===
match
---
with_item [8979,9113]
with_item [11146,11280]
===
match
---
atom_expr [3180,3223]
atom_expr [3880,3923]
===
match
---
trailer [10582,10751]
trailer [12749,12918]
===
match
---
argument [1313,1326]
argument [1313,1326]
===
match
---
operator: = [10577,10578]
operator: = [12744,12745]
===
match
---
assert_stmt [11333,11362]
assert_stmt [13500,13529]
===
match
---
trailer [3125,3129]
trailer [3804,3808]
===
match
---
atom_expr [3929,3955]
atom_expr [4629,4655]
===
match
---
trailer [10071,10073]
trailer [12238,12240]
===
match
---
argument [1549,1572]
argument [1549,1572]
===
match
---
assert_stmt [9636,9662]
assert_stmt [11803,11829]
===
match
---
name: run_type [7840,7848]
name: run_type [9574,9582]
===
match
---
name: num_of_dags [12410,12421]
name: num_of_dags [14577,14588]
===
match
---
atom_expr [3150,3160]
atom_expr [3829,3839]
===
match
---
name: query [8174,8179]
name: query [9908,9913]
===
match
---
trailer [9805,9815]
trailer [11972,11982]
===
match
---
atom_expr [12085,12101]
atom_expr [14252,14268]
===
match
---
name: qry [6751,6754]
name: qry [8464,8467]
===
match
---
atom_expr [9891,9909]
atom_expr [12058,12076]
===
match
---
atom_expr [11413,11433]
atom_expr [13580,13600]
===
match
---
name: task_id [6343,6350]
name: task_id [7727,7734]
===
match
---
import_from [988,1035]
import_from [988,1035]
===
match
---
operator: , [9373,9374]
operator: , [11540,11541]
===
match
---
trailer [11092,11095]
trailer [13259,13262]
===
match
---
name: dag [11147,11150]
name: dag [13314,13317]
===
match
---
operator: , [7704,7705]
operator: , [9438,9439]
===
match
---
name: last_scheduling_decision [4700,4724]
name: last_scheduling_decision [5734,5758]
===
match
---
name: i [11715,11716]
name: i [13882,13883]
===
match
---
name: tis [12778,12781]
name: tis [14945,14948]
===
match
---
trailer [8026,8028]
trailer [9760,9762]
===
match
---
atom [10493,10495]
atom [12660,12662]
===
match
---
name: DEFAULT_DATE [10655,10667]
name: DEFAULT_DATE [12822,12834]
===
match
---
name: i [12047,12048]
name: i [14214,14215]
===
match
---
name: DummyOperator [5028,5041]
name: DummyOperator [6062,6075]
===
match
---
simple_stmt [2937,2992]
simple_stmt [3287,3342]
===
match
---
simple_stmt [7927,7956]
simple_stmt [9661,9690]
===
match
---
operator: = [7540,7541]
operator: = [9274,9275]
===
match
---
argument [7597,7608]
argument [9331,9342]
===
match
---
param [4792,4797]
param [5826,5831]
===
match
---
assert_stmt [8543,8589]
assert_stmt [10277,10323]
===
match
---
comparison [12085,12106]
comparison [14252,14273]
===
match
---
name: external_executor_id [3320,3340]
name: external_executor_id [4020,4040]
===
match
---
operator: == [6008,6010]
operator: == [7392,7394]
===
match
---
with_item [3006,3033]
with_item [3356,3383]
===
match
---
trailer [12262,12269]
trailer [14429,14436]
===
match
---
trailer [4301,4309]
trailer [5001,5009]
===
match
---
name: task_id [13051,13058]
name: task_id [15218,15225]
===
match
---
name: tis [11164,11167]
name: tis [13331,13334]
===
match
---
operator: = [3110,3111]
operator: = [3789,3790]
===
match
---
name: task1 [1991,1996]
name: task1 [1991,1996]
===
match
---
simple_stmt [13421,13448]
simple_stmt [15588,15615]
===
match
---
parameters [8110,8119]
parameters [9844,9853]
===
match
---
trailer [1737,1761]
trailer [1737,1761]
===
match
---
suite [1348,1419]
suite [1348,1419]
===
match
---
name: dag_id [6799,6805]
name: dag_id [8512,8518]
===
match
---
trailer [6770,6774]
trailer [8483,8487]
===
match
---
trailer [2103,2109]
trailer [2432,2438]
===
match
---
expr_stmt [1895,1923]
expr_stmt [1895,1923]
===
match
---
operator: = [9200,9201]
operator: = [11367,11368]
===
match
---
trailer [8719,8727]
trailer [10817,10825]
===
match
---
expr_stmt [13350,13364]
expr_stmt [15517,15531]
===
match
---
name: num_of_dags [11233,11244]
name: num_of_dags [13400,13411]
===
match
---
name: refresh_from_db [11957,11972]
name: refresh_from_db [14124,14139]
===
match
---
name: DEFAULT_DATE [6212,6224]
name: DEFAULT_DATE [7596,7608]
===
match
---
name: try_number [9732,9742]
name: try_number [11899,11909]
===
match
---
param [2569,2574]
param [2919,2924]
===
match
---
comparison [13428,13447]
comparison [15595,15614]
===
match
---
operator: = [5117,5118]
operator: = [6151,6152]
===
match
---
with_item [5567,5594]
with_item [6601,6628]
===
match
---
atom_expr [12278,12312]
atom_expr [14445,14479]
===
match
---
trailer [13852,13862]
trailer [16019,16029]
===
match
---
name: ti1 [2459,2462]
name: ti1 [2809,2812]
===
match
---
operator: = [13168,13169]
operator: = [15335,15336]
===
match
---
trailer [13179,13193]
trailer [15346,15360]
===
match
---
number: 2 [11595,11596]
number: 2 [13762,13763]
===
match
---
suite [12496,12641]
suite [14663,14808]
===
match
---
name: self [6094,6098]
name: self [7478,7482]
===
match
---
atom_expr [3968,4005]
atom_expr [4668,4705]
===
match
---
trailer [5481,5490]
trailer [6515,6524]
===
match
---
name: i [12577,12578]
name: i [14744,14745]
===
match
---
name: ti0 [6668,6671]
name: ti0 [8052,8055]
===
match
---
name: task_id [8635,8642]
name: task_id [10369,10376]
===
match
---
name: ti0 [10369,10372]
name: ti0 [12536,12539]
===
match
---
atom_expr [13327,13335]
atom_expr [15494,15502]
===
match
---
string: 'test_dag_clear_task_0' [9157,9180]
string: 'test_dag_clear_task_0' [11324,11347]
===
match
---
with_stmt [12855,13156]
with_stmt [15022,15323]
===
match
---
dotted_name [943,966]
dotted_name [943,966]
===
match
---
name: DEFAULT_DATE [3855,3867]
name: DEFAULT_DATE [4555,4567]
===
match
---
name: dag_id [5642,5648]
name: dag_id [7005,7011]
===
match
---
name: ti0 [9763,9766]
name: ti0 [11930,11933]
===
match
---
name: run [6690,6693]
name: run [8074,8077]
===
match
---
name: State [13213,13218]
name: State [15380,15385]
===
match
---
atom_expr [8001,8010]
atom_expr [9735,9744]
===
match
---
name: session [6851,6858]
name: session [8585,8592]
===
match
---
atom_expr [12292,12311]
atom_expr [14459,14478]
===
match
---
atom_expr [5385,5394]
atom_expr [6419,6428]
===
match
---
name: task_id [9216,9223]
name: task_id [11383,11390]
===
match
---
name: session [6730,6737]
name: session [8114,8121]
===
match
---
name: run [5371,5374]
name: run [6405,6408]
===
match
---
trailer [5388,5392]
trailer [6422,6426]
===
match
---
trailer [2395,2405]
trailer [2745,2755]
===
match
---
name: test_operator_clear [12809,12828]
name: test_operator_clear [14976,14995]
===
match
---
simple_stmt [5020,5059]
simple_stmt [6054,6093]
===
match
---
atom_expr [1969,1997]
atom_expr [1969,1997]
===
match
---
name: task1 [6652,6657]
name: task1 [8036,8041]
===
match
---
name: dag_maker [1485,1494]
name: dag_maker [1485,1494]
===
match
---
trailer [5820,5836]
trailer [7204,7220]
===
match
---
trailer [8850,8858]
trailer [11017,11025]
===
match
---
name: tis [11994,11997]
name: tis [14161,14164]
===
match
---
atom_expr [3076,3092]
atom_expr [3426,3442]
===
match
---
string: 'test_clear_task_instances_external_executor_id' [2623,2671]
string: 'test_clear_task_instances_external_executor_id' [2973,3021]
===
match
---
name: run [11718,11721]
name: run [13885,13888]
===
match
---
name: create_dagrun [2861,2874]
name: create_dagrun [3211,3224]
===
match
---
operator: , [1875,1876]
operator: , [1875,1876]
===
match
---
name: try_number [13432,13442]
name: try_number [15599,15609]
===
match
---
expr_stmt [9864,9882]
expr_stmt [12031,12049]
===
match
---
with_item [6125,6307]
with_item [7509,7691]
===
match
---
name: DagRunType [13249,13259]
name: DagRunType [15416,15426]
===
match
---
name: test_clear_task_instances_with_task_reschedule [7199,7245]
name: test_clear_task_instances_with_task_reschedule [8933,8979]
===
match
---
atom_expr [7770,7880]
atom_expr [9504,9614]
===
match
---
string: 'task0' [2827,2834]
string: 'task0' [3177,3184]
===
match
---
name: run [2029,2032]
name: run [2029,2032]
===
match
---
operator: = [13299,13300]
operator: = [15466,15467]
===
match
---
trailer [7596,7659]
trailer [9330,9393]
===
match
---
operator: , [12904,12905]
operator: , [15071,15072]
===
match
---
name: i [10818,10819]
name: i [12985,12986]
===
match
---
name: session [4338,4345]
name: session [5038,5045]
===
match
---
operator: @ [3354,3355]
operator: @ [4054,4055]
===
match
---
number: 1 [13866,13867]
number: 1 [16033,16034]
===
match
---
assert_stmt [11609,11637]
assert_stmt [13776,13804]
===
match
---
name: ti1 [8019,8022]
name: ti1 [9753,9756]
===
match
---
trailer [9781,9786]
trailer [11948,11953]
===
match
---
argument [7807,7826]
argument [9541,9560]
===
match
---
name: DummyOperator [1724,1737]
name: DummyOperator [1724,1737]
===
match
---
name: query [8675,8680]
name: query [10756,10761]
===
match
---
simple_stmt [2845,2895]
simple_stmt [3195,3245]
===
match
---
name: dummy [961,966]
name: dummy [961,966]
===
match
---
arith_expr [12207,12219]
arith_expr [14374,14386]
===
match
---
operator: , [12941,12942]
operator: , [15108,15109]
===
match
---
name: ti0 [7927,7930]
name: ti0 [9661,9664]
===
match
---
trailer [8263,8270]
trailer [9997,10004]
===
match
---
name: try_number [12580,12590]
name: try_number [14747,14757]
===
match
---
name: days [1629,1633]
name: days [1629,1633]
===
match
---
name: DummyOperator [1677,1690]
name: DummyOperator [1677,1690]
===
match
---
simple_stmt [5071,5121]
simple_stmt [6105,6155]
===
match
---
simple_stmt [5986,6013]
simple_stmt [7370,7397]
===
match
---
atom_expr [9441,9458]
atom_expr [11608,11625]
===
match
---
trailer [3119,3125]
trailer [3798,3804]
===
match
---
name: self [2569,2573]
name: self [2919,2923]
===
match
---
name: refresh_from_task [6634,6651]
name: refresh_from_task [8018,8035]
===
match
---
simple_stmt [1142,1185]
simple_stmt [1142,1185]
===
match
---
trailer [12350,12361]
trailer [14517,14528]
===
match
---
argument [3889,3896]
argument [4589,4596]
===
match
---
operator: , [9330,9331]
operator: , [11497,11498]
===
match
---
funcdef [8085,8530]
funcdef [9819,10264]
===
match
---
trailer [4177,4202]
trailer [4877,4902]
===
match
---
trailer [11077,11092]
trailer [13244,13259]
===
match
---
name: ti1 [13290,13293]
name: ti1 [15457,15460]
===
match
---
trailer [2014,2016]
trailer [2014,2016]
===
match
---
atom_expr [2851,2894]
atom_expr [3201,3244]
===
match
---
name: ti2 [13295,13298]
name: ti2 [15462,15465]
===
match
---
comparison [11994,12023]
comparison [14161,14190]
===
match
---
atom_expr [12778,12794]
atom_expr [14945,14961]
===
match
---
trailer [9620,9624]
trailer [11787,11791]
===
match
---
file_input [788,13868]
file_input [788,16035]
===
match
---
trailer [7967,7985]
trailer [9701,9719]
===
match
---
comparison [8369,8403]
comparison [10103,10137]
===
match
---
name: dr [4616,4618]
name: dr [5650,5652]
===
match
---
trailer [11997,12000]
trailer [14164,14167]
===
match
---
trailer [5144,5158]
trailer [6178,6192]
===
match
---
number: 10 [2770,2772]
number: 10 [3120,3122]
===
match
---
simple_stmt [1185,1223]
simple_stmt [1185,1223]
===
match
---
number: 2 [12798,12799]
number: 2 [14965,14966]
===
match
---
suite [8071,8924]
suite [9805,11091]
===
match
---
name: dag_maker [13170,13179]
name: dag_maker [15337,15346]
===
match
---
name: test_clear_task_instances_without_task [4753,4791]
name: test_clear_task_instances_without_task [5787,5825]
===
match
---
trailer [10002,10013]
trailer [12169,12180]
===
match
---
expr_stmt [6431,6546]
expr_stmt [7815,7930]
===
match
---
name: dr [6567,6569]
name: dr [7951,7953]
===
match
---
name: datetime [4961,4969]
name: datetime [5995,6003]
===
match
---
trailer [2906,2912]
trailer [3256,3262]
===
match
---
name: retries [3995,4002]
name: retries [4695,4702]
===
match
---
simple_stmt [8818,8865]
simple_stmt [10985,11032]
===
match
---
number: 2 [4003,4004]
number: 2 [4703,4704]
===
match
---
simple_stmt [5917,5944]
simple_stmt [7301,7328]
===
match
---
expr_stmt [4226,4263]
expr_stmt [4926,4963]
===
match
---
trailer [13303,13318]
trailer [15470,15485]
===
match
---
trailer [1824,1832]
trailer [1824,1832]
===
match
---
simple_stmt [10062,10074]
simple_stmt [12229,12241]
===
match
---
simple_stmt [6372,6422]
simple_stmt [7756,7806]
===
match
---
expr_stmt [9269,9384]
expr_stmt [11436,11551]
===
match
---
trailer [5092,5120]
trailer [6126,6154]
===
match
---
operator: = [6565,6566]
operator: = [7949,7950]
===
match
---
trailer [6806,6810]
trailer [8540,8544]
===
match
---
expr_stmt [7765,7880]
expr_stmt [9499,9614]
===
match
---
operator: , [3432,3433]
operator: , [4132,4133]
===
match
---
name: datetime [6262,6270]
name: datetime [7646,7654]
===
match
---
expr_stmt [5440,5458]
expr_stmt [6474,6492]
===
match
---
atom_expr [9728,9742]
atom_expr [11895,11909]
===
match
---
name: i [11747,11748]
name: i [13914,13915]
===
match
---
assert_stmt [13842,13867]
assert_stmt [16009,16034]
===
match
---
trailer [8216,8223]
trailer [9950,9957]
===
match
---
atom_expr [12979,13006]
atom_expr [15146,15173]
===
match
---
name: task1 [9526,9531]
name: task1 [11693,11698]
===
match
---
simple_stmt [3076,3093]
simple_stmt [3426,3443]
===
match
---
atom_expr [7927,7955]
atom_expr [9661,9689]
===
match
---
arglist [13102,13131]
arglist [15269,15298]
===
match
---
argument [11886,11898]
argument [14053,14065]
===
match
---
number: 1 [10386,10387]
number: 1 [12553,12554]
===
match
---
name: qry [5608,5611]
name: qry [6971,6974]
===
match
---
name: max_tries [10038,10047]
name: max_tries [12205,12214]
===
match
---
testlist_comp [3442,3469]
testlist_comp [4142,4169]
===
match
---
name: start_date [4900,4910]
name: start_date [5934,5944]
===
match
---
number: 2 [9257,9258]
number: 2 [11424,11425]
===
match
---
number: 0 [11402,11403]
number: 0 [13569,13570]
===
match
---
number: 0 [12204,12205]
number: 0 [14371,14372]
===
match
---
simple_stmt [12771,12800]
simple_stmt [14938,14967]
===
match
---
name: task_id [5544,5551]
name: task_id [6578,6585]
===
match
---
operator: = [13336,13337]
operator: = [15503,15504]
===
match
---
operator: == [2372,2374]
operator: == [2722,2724]
===
match
---
atom [10497,10499]
atom [12664,12666]
===
match
---
trailer [11549,11554]
trailer [13716,13721]
===
match
---
operator: , [13269,13270]
operator: , [15436,15437]
===
match
---
operator: = [7768,7769]
operator: = [9502,9503]
===
match
---
name: task [10764,10768]
name: task [12931,12935]
===
match
---
name: ti [11070,11072]
name: ti [13237,13239]
===
match
---
trailer [3165,3167]
trailer [3865,3867]
===
match
---
number: 1 [8647,8648]
number: 1 [10381,10382]
===
match
---
simple_stmt [9918,9935]
simple_stmt [12085,12102]
===
match
---
operator: = [11893,11894]
operator: = [14060,14061]
===
match
---
name: datetime [3870,3878]
name: datetime [4570,4578]
===
match
---
number: 1 [7119,7120]
number: 1 [8853,8854]
===
match
---
arglist [1299,1326]
arglist [1299,1326]
===
match
---
trailer [8743,8747]
trailer [10896,10900]
===
match
---
name: ti1 [7136,7139]
name: ti1 [8870,8873]
===
match
---
operator: == [13791,13793]
operator: == [15958,15960]
===
match
---
string: 'dummy_op' [13110,13120]
string: 'dummy_op' [15277,15287]
===
match
---
operator: = [5264,5265]
operator: = [6298,6299]
===
match
---
number: 2 [7188,7189]
number: 2 [8922,8923]
===
match
---
name: dag_maker [4823,4832]
name: dag_maker [5857,5866]
===
match
---
operator: , [6849,6850]
operator: , [8583,8584]
===
match
---
argument [7706,7735]
argument [9440,9469]
===
match
---
dotted_name [1147,1166]
dotted_name [1147,1166]
===
match
---
atom_expr [11484,11508]
atom_expr [13651,13675]
===
match
---
trailer [2360,2371]
trailer [2710,2721]
===
match
---
arglist [7597,7658]
arglist [9331,9392]
===
match
---
number: 2 [7085,7086]
number: 2 [8819,8820]
===
match
---
trailer [8988,9106]
trailer [11155,11273]
===
match
---
name: try_number [10245,10255]
name: try_number [12412,12422]
===
match
---
trailer [12409,12422]
trailer [14576,14589]
===
match
---
parameters [3520,3561]
parameters [4220,4261]
===
match
---
name: task_instances [5269,5283]
name: task_instances [6303,6317]
===
match
---
trailer [9297,9384]
trailer [11464,11551]
===
match
---
argument [1738,1749]
argument [1738,1749]
===
match
---
atom_expr [8717,8727]
atom_expr [10815,10825]
===
match
---
operator: , [1458,1459]
operator: , [1458,1459]
===
match
---
comparison [7067,7086]
comparison [8801,8820]
===
match
---
trailer [12049,12060]
trailer [14216,14227]
===
match
---
trailer [6651,6658]
trailer [8035,8042]
===
match
---
trailer [11232,11245]
trailer [13399,13412]
===
match
---
name: end_date [2722,2730]
name: end_date [3072,3080]
===
match
---
arglist [10898,11043]
arglist [13065,13210]
===
match
---
trailer [11749,11755]
trailer [13916,13922]
===
match
---
assert_stmt [5467,5505]
assert_stmt [6501,6539]
===
match
---
name: NONE [11550,11554]
name: NONE [13717,13721]
===
match
---
trailer [1416,1418]
trailer [1416,1418]
===
match
---
simple_stmt [12179,12221]
simple_stmt [14346,14388]
===
match
---
name: scope [1313,1318]
name: scope [1313,1318]
===
match
---
operator: = [10693,10694]
operator: = [12860,12861]
===
match
---
trailer [12685,12688]
trailer [14852,14855]
===
match
---
trailer [3020,3022]
trailer [3370,3372]
===
match
---
name: ti0 [6593,6596]
name: ti0 [7977,7980]
===
match
---
name: session [4385,4392]
name: session [5398,5405]
===
match
---
name: session [5614,5621]
name: session [6977,6984]
===
match
---
simple_stmt [11950,11975]
simple_stmt [14117,14142]
===
match
---
string: 'test_dag_clear_' [10600,10617]
string: 'test_dag_clear_' [12767,12784]
===
match
---
atom_expr [2426,2435]
atom_expr [2776,2785]
===
match
---
simple_stmt [5847,5869]
simple_stmt [7231,7253]
===
match
---
simple_stmt [10327,10354]
simple_stmt [12494,12521]
===
match
---
name: DummyOperator [3929,3942]
name: DummyOperator [4629,4642]
===
match
---
operator: == [9604,9606]
operator: == [11771,11773]
===
match
---
name: ti1 [6028,6031]
name: ti1 [7412,7415]
===
match
---
name: session [6757,6764]
name: session [8470,8477]
===
match
---
name: ti0 [9643,9646]
name: ti0 [11810,11813]
===
match
---
operator: = [10861,10862]
operator: = [13028,13029]
===
match
---
number: 3 [12753,12754]
number: 3 [14920,14921]
===
match
---
trailer [6445,6459]
trailer [7829,7843]
===
match
---
trailer [9646,9657]
trailer [11813,11824]
===
match
---
name: dag [5652,5655]
name: dag [7015,7018]
===
match
---
trailer [12015,12023]
trailer [14182,14190]
===
match
---
atom_expr [8762,8805]
atom_expr [10929,10972]
===
match
---
operator: = [9879,9880]
operator: = [12046,12047]
===
match
---
operator: = [10769,10770]
operator: = [12936,12937]
===
match
---
atom_expr [11108,11115]
atom_expr [13275,13282]
===
match
---
name: DAG [11413,11416]
name: DAG [13580,13583]
===
match
---
name: ti1 [7895,7898]
name: ti1 [9629,9632]
===
match
---
name: dag_id [8264,8270]
name: dag_id [9998,10004]
===
match
---
name: ti1 [9973,9976]
name: ti1 [12140,12143]
===
match
---
trailer [12625,12635]
trailer [14792,14802]
===
match
---
operator: , [8715,8716]
operator: , [10813,10814]
===
match
---
name: pytest [1284,1290]
name: pytest [1284,1290]
===
match
---
arglist [7807,7870]
arglist [9541,9604]
===
match
---
trailer [13549,13571]
trailer [15716,15738]
===
match
---
name: dag [10836,10839]
name: dag [13003,13006]
===
match
---
assert_stmt [11375,11403]
assert_stmt [13542,13570]
===
match
---
trailer [10210,10220]
trailer [12377,12387]
===
match
---
name: SUCCESS [2921,2928]
name: SUCCESS [3271,3278]
===
match
---
name: dag_maker [5135,5144]
name: dag_maker [6169,6178]
===
match
---
name: retries [5110,5117]
name: retries [6144,6151]
===
match
---
atom_expr [8310,8332]
atom_expr [10044,10066]
===
match
---
trailer [11684,11697]
trailer [13851,13864]
===
match
---
name: dag_maker [1460,1469]
name: dag_maker [1460,1469]
===
match
---
operator: + [1608,1609]
operator: + [1608,1609]
===
match
---
name: filter [8685,8691]
name: filter [10783,10789]
===
match
---
simple_stmt [12513,12550]
simple_stmt [14680,14717]
===
match
---
trailer [5702,5716]
trailer [7086,7100]
===
match
---
number: 2 [13605,13606]
number: 2 [15772,15773]
===
match
---
atom_expr [2903,2912]
atom_expr [3253,3262]
===
match
---
trailer [5268,5283]
trailer [6302,6317]
===
match
---
arglist [1508,1638]
arglist [1508,1638]
===
match
---
name: run_type [10980,10988]
name: run_type [13147,13155]
===
match
---
trailer [5627,5631]
trailer [6990,6994]
===
match
---
simple_stmt [8019,8029]
simple_stmt [9753,9763]
===
match
---
atom_expr [2247,2268]
atom_expr [2597,2618]
===
match
---
operator: = [3893,3894]
operator: = [4593,4594]
===
match
---
name: clear [10066,10071]
name: clear [12233,12238]
===
match
---
trailer [2266,2268]
trailer [2616,2618]
===
match
---
operator: = [10452,10453]
operator: = [12619,12620]
===
match
---
name: session [3206,3213]
name: session [3906,3913]
===
match
---
name: dag [3215,3218]
name: dag [3915,3918]
===
match
---
number: 1 [5976,5977]
number: 1 [7360,7361]
===
match
---
name: range [12404,12409]
name: range [14571,14576]
===
match
---
decorator [3354,3478]
decorator [4054,4178]
===
match
---
expr_stmt [9430,9458]
expr_stmt [11597,11625]
===
match
---
name: task_id [5093,5100]
name: task_id [6127,6134]
===
match
---
trailer [6810,6812]
trailer [8544,8546]
===
match
---
trailer [8396,8403]
trailer [10130,10137]
===
match
---
name: TI [8717,8719]
name: TI [10815,10817]
===
match
---
name: refresh_from_db [10086,10101]
name: refresh_from_db [12253,12268]
===
match
---
arglist [4846,4989]
arglist [5880,6023]
===
match
---
trailer [9087,9096]
trailer [11254,11263]
===
match
---
name: filter [2114,2120]
name: filter [2443,2449]
===
match
---
atom_expr [13524,13533]
atom_expr [15691,15700]
===
match
---
atom_expr [10241,10255]
atom_expr [12408,12422]
===
match
---
trailer [13466,13476]
trailer [15633,15643]
===
match
---
operator: = [1594,1595]
operator: = [1594,1595]
===
match
---
number: 2 [9854,9855]
number: 2 [12021,12022]
===
match
---
trailer [7105,7115]
trailer [8839,8849]
===
match
---
operator: = [6434,6435]
operator: = [7818,7819]
===
match
---
name: last_scheduling [4728,4743]
name: last_scheduling [5762,5777]
===
match
---
suite [11698,11856]
suite [13865,14023]
===
match
---
with_stmt [8038,8924]
with_stmt [9772,11091]
===
match
---
simple_stmt [2805,2836]
simple_stmt [3155,3186]
===
match
---
name: SCHEDULED [11000,11009]
name: SCHEDULED [13167,13176]
===
match
---
simple_stmt [6593,6622]
simple_stmt [7977,8006]
===
match
---
name: i [11263,11264]
name: i [13430,13431]
===
match
---
number: 0 [2892,2893]
number: 0 [3242,3243]
===
match
---
operator: == [9816,9818]
operator: == [11983,11985]
===
match
---
with_item [2600,2791]
with_item [2950,3141]
===
match
---
operator: = [10491,10492]
operator: = [12658,12659]
===
match
---
name: ti1 [7171,7174]
name: ti1 [8905,8908]
===
match
---
comparison [8429,8459]
comparison [10163,10193]
===
match
---
name: ti0 [5817,5820]
name: ti0 [7201,7204]
===
match
---
name: run [13378,13381]
name: run [15545,15548]
===
match
---
name: dag [10062,10065]
name: dag [12229,12232]
===
match
---
simple_stmt [4522,4538]
simple_stmt [5556,5572]
===
match
---
arglist [12362,12384]
arglist [14529,14551]
===
match
---
string: '1' [3990,3993]
string: '1' [4690,4693]
===
match
---
trailer [7859,7869]
trailer [9593,9603]
===
match
---
assert_stmt [5952,5977]
assert_stmt [7336,7361]
===
match
---
atom_expr [6436,6546]
atom_expr [7820,7930]
===
match
---
operator: == [9658,9660]
operator: == [11825,11827]
===
match
---
operator: == [3147,3149]
operator: == [3826,3828]
===
match
---
expr_stmt [1716,1761]
expr_stmt [1716,1761]
===
match
---
operator: , [7639,7640]
operator: , [9373,9374]
===
match
---
name: TI [3137,3139]
name: TI [3816,3818]
===
match
---
name: SCHEDULED [7860,7869]
name: SCHEDULED [9594,9603]
===
match
---
name: run [9977,9980]
name: run [12144,12147]
===
match
---
operator: , [4923,4924]
operator: , [5957,5958]
===
match
---
name: ti1 [5847,5850]
name: ti1 [7231,7234]
===
match
---
operator: = [6418,6419]
operator: = [7802,7803]
===
match
---
simple_stmt [13031,13070]
simple_stmt [15198,15237]
===
match
---
comparison [8884,8923]
comparison [11051,11090]
===
match
---
operator: == [11541,11543]
operator: == [13708,13710]
===
match
---
operator: , [4473,4474]
operator: , [5507,5508]
===
match
---
trailer [5641,5648]
trailer [7004,7011]
===
match
---
atom_expr [9776,9786]
atom_expr [11943,11953]
===
match
---
arglist [11880,11898]
arglist [14047,14065]
===
match
---
name: clear_task_instances [5682,5702]
name: clear_task_instances [7066,7086]
===
match
---
with_stmt [4818,5121]
with_stmt [5852,6155]
===
match
---
simple_stmt [8543,8590]
simple_stmt [10277,10324]
===
match
---
trailer [12295,12311]
trailer [14462,14478]
===
match
---
shift_expr [13145,13155]
shift_expr [15312,15322]
===
match
---
operator: == [8455,8457]
operator: == [10189,10191]
===
match
---
operator: = [7678,7679]
operator: = [9412,9413]
===
match
---
trailer [9363,9373]
trailer [11530,11540]
===
match
---
simple_stmt [4354,4370]
simple_stmt [5054,5070]
===
match
---
name: State [3420,3425]
name: State [4120,4125]
===
match
---
operator: = [9256,9257]
operator: = [11423,11424]
===
match
---
name: ti1 [10034,10037]
name: ti1 [12201,12204]
===
match
---
name: self [1342,1346]
name: self [1342,1346]
===
match
---
name: task_instances [13304,13318]
name: task_instances [15471,15485]
===
match
---
name: ti1 [5385,5388]
name: ti1 [6419,6422]
===
match
---
number: 1 [11636,11637]
number: 1 [13803,13804]
===
match
---
with_item [6710,6737]
with_item [8094,8121]
===
match
---
name: dag [2788,2791]
name: dag [3138,3141]
===
match
---
name: run_type [4089,4097]
name: run_type [4789,4797]
===
match
---
name: tis [12292,12295]
name: tis [14459,14462]
===
match
---
name: task_id [1691,1698]
name: task_id [1691,1698]
===
match
---
trailer [5370,5374]
trailer [6404,6408]
===
match
---
atom_expr [4272,4281]
atom_expr [4972,4981]
===
match
---
arglist [6473,6536]
arglist [7857,7920]
===
match
---
name: upstream [13501,13509]
name: upstream [15668,15676]
===
match
---
simple_stmt [9830,9856]
simple_stmt [11997,12023]
===
match
---
trailer [12442,12458]
trailer [14609,14625]
===
match
---
trailer [7948,7955]
trailer [9682,9689]
===
match
---
trailer [8057,8059]
trailer [9791,9793]
===
match
---
assert_stmt [4609,4681]
assert_stmt [5643,5715]
===
match
---
if_stmt [12473,12800]
if_stmt [14640,14967]
===
match
---
simple_stmt [1223,1255]
simple_stmt [1223,1255]
===
match
---
simple_stmt [11609,11638]
simple_stmt [13776,13805]
===
match
---
trailer [8708,8715]
trailer [10806,10813]
===
match
---
name: DagRunType [4098,4108]
name: DagRunType [4798,4808]
===
match
---
simple_stmt [6431,6547]
simple_stmt [7815,7931]
===
match
---
name: dags [11428,11432]
name: dags [13595,13599]
===
match
---
funcdef [3482,4744]
funcdef [4182,5778]
===
match
---
operator: , [8403,8404]
operator: , [10137,10138]
===
match
---
name: try_number [8444,8454]
name: try_number [10178,10188]
===
match
---
operator: = [11073,11074]
operator: = [13240,13241]
===
match
---
name: dag [8274,8277]
name: dag [10008,10011]
===
match
---
name: NONE [12704,12708]
name: NONE [14871,14875]
===
match
---
number: 1 [13446,13447]
number: 1 [15613,15614]
===
match
---
simple_stmt [3237,3259]
simple_stmt [3937,3959]
===
match
---
name: TaskReschedule [8369,8383]
name: TaskReschedule [10103,10117]
===
match
---
atom_expr [5214,5234]
atom_expr [6248,6268]
===
match
---
name: i [12476,12477]
name: i [14643,14644]
===
match
---
operator: , [7608,7609]
operator: , [9342,9343]
===
match
---
name: dag_maker [6100,6109]
name: dag_maker [7484,7493]
===
match
---
expr_stmt [13290,13318]
expr_stmt [15457,15485]
===
match
---
trailer [6689,6693]
trailer [8073,8077]
===
match
---
trailer [4337,4345]
trailer [5037,5045]
===
match
---
dotted_name [1090,1109]
dotted_name [1090,1109]
===
match
---
argument [1813,1832]
argument [1813,1832]
===
match
---
atom_expr [5028,5058]
atom_expr [6062,6092]
===
match
---
operator: == [12695,12697]
operator: == [14862,14864]
===
match
---
atom_expr [10207,10220]
atom_expr [12374,12387]
===
match
---
name: state [12001,12006]
name: state [14168,14173]
===
match
---
operator: = [2730,2731]
operator: = [3080,3081]
===
match
---
with_item [7371,7562]
with_item [9105,9296]
===
match
---
arglist [9311,9374]
arglist [11478,11541]
===
match
---
assert_stmt [12725,12754]
assert_stmt [14892,14921]
===
match
---
atom_expr [6710,6726]
atom_expr [8094,8110]
===
match
---
name: end_date [7493,7501]
name: end_date [9227,9235]
===
match
---
name: dag [2199,2202]
name: dag [2549,2552]
===
match
---
name: max_tries [12785,12794]
name: max_tries [14952,14961]
===
match
---
trailer [11619,11622]
trailer [13786,13789]
===
match
---
expr_stmt [10481,10499]
expr_stmt [12648,12666]
===
match
---
comparison [11340,11362]
comparison [13507,13529]
===
match
---
name: ti0 [3279,3282]
name: ti0 [3979,3982]
===
match
---
suite [11246,11404]
suite [13413,13571]
===
match
---
simple_stmt [13842,13868]
simple_stmt [16009,16035]
===
match
---
name: SUCCESS [11313,11320]
name: SUCCESS [13480,13487]
===
match
---
name: num_of_dags [10508,10519]
name: num_of_dags [12675,12686]
===
match
---
trailer [3054,3058]
trailer [3404,3408]
===
match
---
simple_stmt [4609,4682]
simple_stmt [5643,5716]
===
match
---
simple_stmt [9795,9821]
simple_stmt [11962,11988]
===
match
---
trailer [5850,5866]
trailer [7234,7250]
===
match
---
name: state [13207,13212]
name: state [15374,15379]
===
match
---
name: dag_run_state [4484,4497]
name: dag_run_state [5518,5531]
===
match
---
atom_expr [2494,2507]
atom_expr [2844,2857]
===
match
---
assert_stmt [13580,13606]
assert_stmt [15747,15773]
===
match
---
trailer [5350,5357]
trailer [6384,6391]
===
match
---
trailer [12232,12248]
trailer [14399,14415]
===
match
---
comparison [4697,4743]
comparison [5731,5777]
===
match
---
simple_stmt [8762,8806]
simple_stmt [10929,10973]
===
match
---
operator: = [2695,2696]
operator: = [3045,3046]
===
match
---
operator: = [2962,2963]
operator: = [3312,3313]
===
match
---
operator: == [8585,8587]
operator: == [10319,10321]
===
match
---
operator: , [10925,10926]
operator: , [13092,13093]
===
match
---
name: failed_dag_idx [12481,12495]
name: failed_dag_idx [14648,14662]
===
match
---
name: randint [12162,12169]
name: randint [14329,14336]
===
match
---
trailer [8503,8509]
trailer [10237,10243]
===
match
---
name: dr [5266,5268]
name: dr [6300,6302]
===
match
---
name: create_session [3006,3020]
name: create_session [3356,3370]
===
match
---
name: tis [11340,11343]
name: tis [13507,13510]
===
match
---
name: DEFAULT_DATE [2696,2708]
name: DEFAULT_DATE [3046,3058]
===
match
---
trailer [3447,3455]
trailer [4147,4155]
===
match
---
arglist [1738,1760]
arglist [1738,1760]
===
match
---
simple_stmt [10444,10473]
simple_stmt [12611,12640]
===
match
---
atom_expr [12573,12590]
atom_expr [14740,14757]
===
match
---
name: dr [1906,1908]
name: dr [1906,1908]
===
match
---
operator: == [5649,5651]
operator: == [7012,7014]
===
match
---
for_stmt [11909,12107]
for_stmt [14076,14274]
===
match
---
arglist [3201,3222]
arglist [3901,3922]
===
match
---
trailer [8846,8859]
trailer [11013,11026]
===
match
---
argument [13240,13269]
argument [15407,15436]
===
match
---
operator: == [12591,12593]
operator: == [14758,14760]
===
match
---
name: DummyOperator [6329,6342]
name: DummyOperator [7713,7726]
===
match
---
trailer [4151,4166]
trailer [4851,4866]
===
match
---
simple_stmt [1716,1762]
simple_stmt [1716,1762]
===
match
---
import_as_names [876,937]
import_as_names [876,937]
===
match
---
atom_expr [4019,4129]
atom_expr [4719,4829]
===
match
---
operator: = [1758,1759]
operator: = [1758,1759]
===
match
---
atom_expr [2049,2065]
atom_expr [2049,2065]
===
match
---
name: ti0 [9691,9694]
name: ti0 [11858,11861]
===
match
---
name: ti0 [6960,6963]
name: ti0 [8694,8697]
===
match
---
simple_stmt [7890,7919]
simple_stmt [9624,9653]
===
match
---
name: state [10943,10948]
name: state [13110,13115]
===
match
---
name: run [6672,6675]
name: run [8056,8059]
===
match
---
suite [6738,6860]
suite [8122,8594]
===
match
---
name: tis [12520,12523]
name: tis [14687,14690]
===
match
---
comparison [8717,8742]
comparison [10815,10840]
===
match
---
dotted_name [3355,3378]
dotted_name [4055,4078]
===
match
---
operator: { [5456,5457]
operator: { [6490,6491]
===
match
---
atom_expr [9202,9259]
atom_expr [11369,11426]
===
match
---
operator: == [10383,10385]
operator: == [12550,12552]
===
match
---
name: db [1252,1254]
name: db [1252,1254]
===
match
---
name: TaskReschedule [901,915]
name: TaskReschedule [901,915]
===
match
---
name: state [11750,11755]
name: state [13917,13922]
===
match
---
trailer [5996,6007]
trailer [7380,7391]
===
match
---
arglist [5703,5715]
arglist [7087,7099]
===
match
---
comparison [6782,6805]
comparison [8495,8518]
===
match
---
simple_stmt [5440,5459]
simple_stmt [6474,6493]
===
match
---
atom_expr [3316,3340]
atom_expr [4016,4040]
===
match
---
simple_stmt [6668,6678]
simple_stmt [8052,8062]
===
match
---
operator: + [2744,2745]
operator: + [3094,3095]
===
match
---
atom_expr [9691,9712]
atom_expr [11858,11879]
===
match
---
operator: = [9316,9317]
operator: = [11483,11484]
===
match
---
name: refresh_from_task [9508,9525]
name: refresh_from_task [11675,11692]
===
match
---
trailer [11262,11265]
trailer [13429,13432]
===
match
---
name: State [4062,4067]
name: State [4762,4767]
===
match
---
atom_expr [12520,12532]
atom_expr [14687,14699]
===
match
---
name: dag [3912,3915]
name: dag [4612,4615]
===
match
---
operator: , [5191,5192]
operator: , [6225,6226]
===
match
---
trailer [2032,2034]
trailer [2032,2034]
===
match
---
name: clear_dags [11869,11879]
name: clear_dags [14036,14046]
===
match
---
trailer [5183,5191]
trailer [6217,6225]
===
match
---
name: try_number [9868,9878]
name: try_number [12035,12045]
===
match
---
with_stmt [5562,5717]
with_stmt [6596,7101]
===
match
---
name: ti2 [13463,13466]
name: ti2 [15630,15633]
===
match
---
name: DummyOperator [974,987]
name: DummyOperator [974,987]
===
match
---
operator: = [9133,9134]
operator: = [11300,11301]
===
match
---
operator: , [10485,10486]
operator: , [12652,12653]
===
match
---
name: SCHEDULED [13260,13269]
name: SCHEDULED [15427,15436]
===
match
---
trailer [3153,3160]
trailer [3832,3839]
===
match
---
name: state [4230,4235]
name: state [4930,4935]
===
match
---
name: merge [9899,9904]
name: merge [12066,12071]
===
match
---
simple_stmt [11164,11179]
simple_stmt [13331,13346]
===
match
---
operator: == [4647,4649]
operator: == [5681,5683]
===
match
---
arglist [1813,1876]
arglist [1813,1876]
===
match
---
trailer [5295,5313]
trailer [6329,6347]
===
match
---
expr_stmt [7672,7755]
expr_stmt [9406,9489]
===
match
---
name: task_id [6394,6401]
name: task_id [7778,7785]
===
match
---
name: ti0 [2903,2906]
name: ti0 [3253,3256]
===
match
---
name: run [8005,8008]
name: run [9739,9742]
===
match
---
name: State [1117,1122]
name: State [1117,1122]
===
match
---
dotted_name [1284,1298]
dotted_name [1284,1298]
===
match
---
name: retries [6411,6418]
name: retries [7795,7802]
===
match
---
atom_expr [6686,6695]
atom_expr [8070,8079]
===
match
---
operator: = [6378,6379]
operator: = [7762,7763]
===
match
---
operator: = [5177,5178]
operator: = [6211,6212]
===
match
---
trailer [11622,11632]
trailer [13789,13799]
===
match
---
atom_expr [3112,3167]
atom_expr [3791,3867]
===
match
---
expr_stmt [6751,6812]
expr_stmt [8464,8546]
===
match
---
atom_expr [8631,8642]
atom_expr [10365,10376]
===
match
---
comparison [7171,7189]
comparison [8905,8923]
===
match
---
arglist [9002,9096]
arglist [11169,11263]
===
match
---
trailer [4361,4367]
trailer [5061,5067]
===
match
---
trailer [7139,7150]
trailer [8873,8884]
===
match
---
name: run [13528,13531]
name: run [15695,15698]
===
match
---
comparison [9643,9662]
comparison [11810,11829]
===
match
---
assert_stmt [9830,9855]
assert_stmt [11997,12022]
===
match
---
name: state [7807,7812]
name: state [9541,9546]
===
match
---
name: task1 [7986,7991]
name: task1 [9720,9725]
===
match
---
name: task1 [6372,6377]
name: task1 [7756,7761]
===
match
---
atom_expr [7680,7755]
atom_expr [9414,9489]
===
match
---
name: task0 [6615,6620]
name: task0 [7999,8004]
===
match
---
trailer [11294,11297]
trailer [13461,13464]
===
match
---
name: clear_db_runs [1403,1416]
name: clear_db_runs [1403,1416]
===
insert-node
---
name: TestClearTasks [1263,1277]
to
classdef [1257,13868]
at 0
===
insert-tree
---
trailer [5447,5456]
    name: order_by [5448,5456]
to
atom_expr [4385,4440]
at 5
===
insert-tree
---
trailer [5456,5468]
    atom_expr [5457,5467]
        name: TI [5457,5459]
        trailer [5459,5467]
            name: task_id [5460,5467]
to
atom_expr [4385,4440]
at 6
===
insert-node
---
atom [10730,10916]
to
expr_stmt [8661,8749]
at 2
===
insert-tree
---
trailer [2474,2483]
    name: order_by [2475,2483]
to
atom_expr [2096,2151]
at 5
===
insert-tree
---
trailer [2483,2495]
    atom_expr [2484,2494]
        name: TI [2484,2486]
        trailer [2486,2494]
            name: task_id [2487,2494]
to
atom_expr [2096,2151]
at 6
===
insert-tree
---
trailer [3840,3849]
    name: order_by [3841,3849]
to
atom_expr [3112,3167]
at 5
===
insert-tree
---
trailer [3849,3861]
    atom_expr [3850,3860]
        name: TI [3850,3852]
        trailer [3852,3860]
            name: task_id [3853,3860]
to
atom_expr [3112,3167]
at 6
===
insert-tree
---
trailer [7026,7035]
    name: order_by [7027,7035]
to
atom_expr [5614,5669]
at 5
===
insert-tree
---
trailer [7035,7047]
    atom_expr [7036,7046]
        name: TI [7036,7038]
        trailer [7038,7046]
            name: task_id [7039,7046]
to
atom_expr [5614,5669]
at 6
===
insert-tree
---
trailer [8519,8528]
    name: order_by [8520,8528]
to
atom_expr [6757,6812]
at 5
===
insert-tree
---
trailer [8528,8540]
    atom_expr [8529,8539]
        name: TI [8529,8531]
        trailer [8531,8539]
            name: task_id [8532,8539]
to
atom_expr [6757,6812]
at 6
===
move-tree
---
atom_expr [8667,8749]
    name: session [8667,8674]
    trailer [8674,8680]
        name: query [8675,8680]
    trailer [8680,8684]
        name: TI [8681,8683]
    trailer [8684,8691]
        name: filter [8685,8691]
    trailer [8691,8743]
        arglist [8692,8742]
            comparison [8692,8715]
                atom_expr [8692,8701]
                    name: TI [8692,8694]
                    trailer [8694,8701]
                        name: dag_id [8695,8701]
                operator: == [8702,8704]
                atom_expr [8705,8715]
                    name: dag [8705,8708]
                    trailer [8708,8715]
                        name: dag_id [8709,8715]
            operator: , [8715,8716]
            comparison [8717,8742]
                atom_expr [8717,8727]
                    name: TI [8717,8719]
                    trailer [8719,8727]
                        name: task_id [8720,8727]
                operator: == [8728,8730]
                atom_expr [8731,8742]
                    name: ti0 [8731,8734]
                    trailer [8734,8742]
                        name: task_id [8735,8742]
    trailer [8743,8747]
        name: all [8744,8747]
    trailer [8747,8749]
to
atom [10730,10916]
at 0
===
insert-tree
---
trailer [10858,10867]
    name: order_by [10859,10867]
to
atom_expr [8667,8749]
at 5
===
insert-tree
---
trailer [10867,10879]
    atom_expr [10868,10878]
        name: TI [10868,10870]
        trailer [10870,10878]
            name: task_id [10871,10878]
to
atom_expr [8667,8749]
at 6
===
delete-node
---
name: TestClearTasks [1263,1277]
===
