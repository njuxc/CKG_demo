===
match
---
atom_expr [6747,6796]
atom_expr [6747,6796]
===
match
---
operator: += [6107,6109]
operator: += [6107,6109]
===
match
---
name: try_number [3221,3231]
name: try_number [3221,3231]
===
match
---
simple_stmt [6900,6946]
simple_stmt [6900,6946]
===
match
---
if_stmt [2148,2221]
if_stmt [2148,2221]
===
match
---
name: url [6924,6927]
name: url [6924,6927]
===
match
---
name: ti [3128,3130]
name: ti [3128,3130]
===
match
---
except_clause [6137,6158]
except_clause [6137,6158]
===
match
---
name: ti [2628,2630]
name: ti [2628,2630]
===
match
---
except_clause [4360,4381]
except_clause [4360,4381]
===
match
---
try_stmt [4178,4529]
try_stmt [4178,4529]
===
match
---
name: pathlib [855,862]
name: pathlib [855,862]
===
match
---
name: self [3271,3275]
name: self [3271,3275]
===
match
---
trailer [8597,8610]
trailer [8597,8610]
===
match
---
name: try_numbers [8647,8658]
name: try_numbers [8647,8658]
===
match
---
name: metadata_array [9149,9163]
name: metadata_array [9149,9163]
===
match
---
name: list_namespaced_pod [5133,5152]
name: list_namespaced_pod [5133,5152]
===
match
---
atom_expr [1780,1808]
atom_expr [1780,1808]
===
match
---
name: join [4069,4073]
name: join [4069,4073]
===
match
---
atom_expr [8749,8804]
atom_expr [8749,8804]
===
match
---
trailer [3169,3184]
trailer [3169,3184]
===
match
---
name: airflow [1004,1011]
name: airflow [1004,1011]
===
match
---
simple_stmt [2076,2140]
simple_stmt [2076,2140]
===
match
---
testlist_comp [6821,6855]
testlist_comp [6821,6855]
===
match
---
name: self [4004,4008]
name: self [4004,4008]
===
match
---
name: task_instance [8760,8773]
name: task_instance [8760,8773]
===
match
---
operator: , [4557,4558]
operator: , [4557,4558]
===
match
---
atom_expr [2715,2742]
atom_expr [2715,2742]
===
match
---
trailer [6261,6270]
trailer [6261,6270]
===
match
---
fstring_start: f" [6604,6606]
fstring_start: f" [6604,6606]
===
match
---
simple_stmt [11183,11200]
simple_stmt [11314,11331]
===
match
---
operator: = [6909,6910]
operator: = [6909,6910]
===
match
---
name: conf [5842,5846]
name: conf [5842,5846]
===
match
---
trailer [4550,4570]
trailer [4550,4570]
===
match
---
simple_stmt [4119,4128]
simple_stmt [4119,4128]
===
match
---
name: helpers [1018,1025]
name: helpers [1018,1025]
===
match
---
string: "" [4125,4127]
string: "" [4125,4127]
===
match
---
operator: } [4290,4291]
operator: } [4290,4291]
===
match
---
arglist [10434,10451]
arglist [10434,10451]
===
match
---
file_input [787,11200]
file_input [787,11331]
===
match
---
comparison [5428,5445]
comparison [5428,5445]
===
match
---
name: conf [6462,6466]
name: conf [6462,6466]
===
match
---
fstring_expr [4281,4291]
fstring_expr [4281,4291]
===
match
---
arglist [3090,3232]
arglist [3090,3232]
===
match
---
operator: { [4474,4475]
operator: { [4474,4475]
===
match
---
name: filename_template [3052,3069]
name: filename_template [3052,3069]
===
match
---
trailer [3051,3069]
trailer [3051,3069]
===
match
---
expr_stmt [5731,6048]
expr_stmt [5731,6048]
===
match
---
operator: , [7362,7363]
operator: , [7362,7363]
===
match
---
simple_stmt [2414,2435]
simple_stmt [2414,2435]
===
match
---
name: jinja_context [2790,2803]
name: jinja_context [2790,2803]
===
match
---
parameters [3313,3350]
parameters [3313,3350]
===
match
---
name: e [4380,4381]
name: e [4380,4381]
===
match
---
simple_stmt [6103,6124]
simple_stmt [6103,6124]
===
match
---
param [3336,3349]
param [3336,3349]
===
match
---
name: path [11012,11016]
name: path [11012,11016]
===
match
---
atom_expr [2329,2354]
atom_expr [2329,2354]
===
match
---
operator: += [6537,6539]
operator: += [6537,6539]
===
match
---
name: pod [5246,5249]
name: pod [5246,5249]
===
match
---
trailer [2346,2354]
trailer [2346,2354]
===
match
---
atom_expr [6911,6945]
atom_expr [6911,6945]
===
match
---
simple_stmt [9203,9384]
simple_stmt [9203,9384]
===
match
---
operator: , [2545,2546]
operator: , [2545,2546]
===
match
---
operator: , [9147,9148]
operator: , [9147,9148]
===
match
---
atom_expr [6278,6284]
atom_expr [6278,6284]
===
match
---
fstring_string: *** Log file does not exist:  [6542,6571]
fstring_string: *** Log file does not exist:  [6542,6571]
===
match
---
param [7349,7363]
param [7349,7363]
===
match
---
argument [6929,6944]
argument [6929,6944]
===
match
---
operator: , [6437,6438]
operator: , [6437,6438]
===
match
---
simple_stmt [9098,9127]
simple_stmt [9098,9127]
===
match
---
name: os [847,849]
name: os [847,849]
===
match
---
trailer [5495,5508]
trailer [5495,5508]
===
match
---
trailer [4805,4814]
trailer [4805,4814]
===
match
---
fstring_string: \n [7283,7285]
fstring_string: \n [7283,7285]
===
match
---
comparison [8181,8199]
comparison [8181,8199]
===
match
---
operator: = [4002,4003]
operator: = [4002,4003]
===
match
---
name: str [4518,4521]
name: str [4518,4521]
===
match
---
with_item [4204,4226]
with_item [4204,4226]
===
match
---
operator: , [5810,5811]
operator: , [5810,5811]
===
match
---
name: parse_template_string [1033,1054]
name: parse_template_string [1033,1054]
===
match
---
return_stmt [3286,3298]
return_stmt [3286,3298]
===
match
---
atom_expr [2048,2067]
atom_expr [2048,2067]
===
match
---
operator: } [4483,4484]
operator: } [4483,4484]
===
match
---
name: ti [4803,4805]
name: ti [4803,4805]
===
match
---
atom_expr [5799,5810]
atom_expr [5799,5810]
===
match
---
testlist_comp [5246,5382]
testlist_comp [5246,5382]
===
match
---
atom [8495,8517]
atom [8495,8517]
===
match
---
name: metadata [5345,5353]
name: metadata [5345,5353]
===
match
---
name: full_path [11190,11199]
name: full_path [11321,11330]
===
match
---
operator: = [2804,2805]
operator: = [2804,2805]
===
match
---
trailer [2472,2480]
trailer [2472,2480]
===
match
---
operator: = [4123,4124]
operator: = [4123,4124]
===
match
---
trailer [5157,5161]
trailer [5157,5161]
===
match
---
operator: , [2120,2121]
operator: , [2120,2121]
===
match
---
parameters [7342,7395]
parameters [7342,7395]
===
match
---
name: kube_client [4747,4758]
name: kube_client [4747,4758]
===
match
---
trailer [2204,2220]
trailer [2204,2220]
===
match
---
trailer [5152,5189]
trailer [5152,5189]
===
match
---
atom_expr [3128,3138]
atom_expr [3128,3138]
===
match
---
expr_stmt [7113,7140]
expr_stmt [7113,7140]
===
match
---
arglist [11156,11172]
arglist [11177,11193]
===
match
---
trailer [10490,10501]
trailer [10490,10501]
===
match
---
name: Path [870,874]
name: Path [870,874]
===
match
---
trailer [11023,11034]
trailer [11023,11034]
===
match
---
operator: * [8641,8642]
operator: * [8641,8642]
===
match
---
simple_stmt [6317,6521]
simple_stmt [6317,6521]
===
match
---
name: filename_jinja_template [1785,1808]
name: filename_jinja_template [1785,1808]
===
match
---
trailer [2728,2742]
trailer [2728,2742]
===
match
---
if_stmt [4796,5563]
if_stmt [4796,5563]
===
match
---
trailer [6330,6335]
trailer [6330,6335]
===
match
---
operator: { [2806,2807]
operator: { [2806,2807]
===
match
---
suite [1611,1852]
suite [1611,1852]
===
match
---
name: path [10476,10480]
name: path [10476,10480]
===
match
---
expr_stmt [6533,6584]
expr_stmt [6533,6584]
===
match
---
dictorsetmaker [8497,8515]
dictorsetmaker [8497,8515]
===
match
---
name: try_number [8559,8569]
name: try_number [8559,8569]
===
match
---
trailer [8284,8304]
trailer [8284,8304]
===
match
---
name: try_number [2745,2755]
name: try_number [2745,2755]
===
match
---
suite [2316,2355]
suite [2316,2355]
===
match
---
trailer [6919,6923]
trailer [6919,6923]
===
match
---
name: conf [6747,6751]
name: conf [6747,6751]
===
match
---
atom_expr [7127,7140]
atom_expr [7127,7140]
===
match
---
operator: = [2671,2672]
operator: = [2671,2672]
===
match
---
name: matches [5432,5439]
name: matches [5432,5439]
===
match
---
expr_stmt [3984,4041]
expr_stmt [3984,4041]
===
match
---
name: join [6331,6335]
name: join [6331,6335]
===
match
---
operator: } [8438,8439]
operator: } [8438,8439]
===
match
---
fstring_start: f" [7231,7233]
fstring_start: f" [7231,7233]
===
match
---
trailer [4208,4218]
trailer [4208,4218]
===
match
---
parameters [3270,3276]
parameters [3270,3276]
===
match
---
name: _render_filename [10417,10433]
name: _render_filename [10417,10433]
===
match
---
operator: , [5863,5864]
operator: , [5863,5864]
===
match
---
atom_expr [6323,6520]
atom_expr [6323,6520]
===
match
---
name: Exception [7160,7169]
name: Exception [7160,7169]
===
match
---
trailer [2627,2639]
trailer [2627,2639]
===
match
---
expr_stmt [4315,4347]
expr_stmt [4315,4347]
===
match
---
simple_stmt [8733,8805]
simple_stmt [8733,8805]
===
match
---
expr_stmt [6103,6123]
expr_stmt [6103,6123]
===
match
---
name: log [6208,6211]
name: log [6208,6211]
===
match
---
name: hostname [6262,6270]
name: hostname [6262,6270]
===
match
---
operator: = [8747,8748]
operator: = [8747,8748]
===
match
---
simple_stmt [2790,2959]
simple_stmt [2790,2959]
===
match
---
name: mkdir [10946,10951]
name: mkdir [10946,10951]
===
match
---
name: self [7343,7347]
name: self [7343,7347]
===
match
---
atom_expr [6110,6123]
atom_expr [6110,6123]
===
match
---
simple_stmt [10526,10565]
simple_stmt [10526,10565]
===
match
---
name: len [8594,8597]
name: len [8594,8597]
===
match
---
name: os [10538,10540]
name: os [10538,10540]
===
match
---
operator: = [6461,6462]
operator: = [6461,6462]
===
match
---
string: 'namespace' [5865,5876]
string: 'namespace' [5865,5876]
===
match
---
tfpdef [1587,1609]
tfpdef [1587,1609]
===
match
---
name: logs [8580,8584]
name: logs [8580,8584]
===
match
---
name: get_template_context [2676,2696]
name: get_template_context [2676,2696]
===
match
---
name: handler [2393,2400]
name: handler [2393,2400]
===
match
---
string: 'webserver' [6759,6770]
string: 'webserver' [6759,6770]
===
match
---
suite [2563,3243]
suite [2563,3243]
===
match
---
name: items [5308,5313]
name: items [5308,5313]
===
match
---
operator: , [8773,8774]
operator: , [8773,8774]
===
match
---
fstring_string: *** Failed to fetch log file from worker.  [7233,7275]
fstring_string: *** Failed to fetch log file from worker.  [7233,7275]
===
match
---
suite [5446,5563]
suite [5446,5563]
===
match
---
trailer [2255,2261]
trailer [2255,2261]
===
match
---
trailer [6470,6506]
trailer [6470,6506]
===
match
---
atom [7308,7328]
atom [7308,7328]
===
match
---
atom_expr [2388,2400]
atom_expr [2388,2400]
===
match
---
operator: } [2957,2958]
operator: } [2957,2958]
===
match
---
name: try_number [3210,3220]
name: try_number [3210,3220]
===
match
---
name: log [4504,4507]
name: log [4504,4507]
===
match
---
name: open [11048,11052]
name: open [11048,11052]
===
match
---
name: ti [1879,1881]
name: ti [1879,1881]
===
match
---
argument [10964,10976]
argument [10964,10976]
===
match
---
dotted_name [941,962]
dotted_name [941,962]
===
match
---
arglist [4026,4040]
arglist [4026,4040]
===
match
---
import_from [999,1054]
import_from [999,1054]
===
match
---
name: kube_client [5737,5748]
name: kube_client [5737,5748]
===
match
---
name: enumerate [8697,8706]
name: enumerate [8697,8706]
===
match
---
atom_expr [11009,11034]
atom_expr [11009,11034]
===
match
---
name: airflow [1083,1090]
name: airflow [1083,1090]
===
match
---
return_stmt [9136,9163]
return_stmt [9136,9163]
===
match
---
expr_stmt [8544,8570]
expr_stmt [8544,8570]
===
match
---
name: _read [8754,8759]
name: _read [8754,8759]
===
match
---
operator: , [5174,5175]
operator: , [5174,5175]
===
match
---
operator: , [10436,10437]
operator: , [10436,10437]
===
match
---
string: """         Provide task_instance context to airflow task handler.          :param ti: task instance object         """ [1908,2027]
string: """         Provide task_instance context to airflow task handler.          :param ti: task instance object         """ [1908,2027]
===
match
---
trailer [5655,5662]
trailer [5655,5662]
===
match
---
expr_stmt [6317,6520]
expr_stmt [6317,6520]
===
match
---
name: file [4330,4334]
name: file [4330,4334]
===
match
---
funcdef [1546,1852]
funcdef [1546,1852]
===
match
---
operator: , [2549,2550]
operator: , [2549,2550]
===
match
---
name: get [4547,4550]
name: get [4547,4550]
===
match
---
name: _preload_content [6007,6023]
name: _preload_content [6007,6023]
===
match
---
name: logging [1142,1149]
name: logging [1142,1149]
===
match
---
operator: = [5981,5982]
operator: = [5981,5982]
===
match
---
for_stmt [6066,6124]
for_stmt [6066,6124]
===
match
---
name: os [11147,11149]
name: os [11168,11170]
===
match
---
argument [5832,5877]
argument [5832,5877]
===
match
---
fstring [6215,6290]
fstring [6215,6290]
===
match
---
simple_stmt [4248,4295]
simple_stmt [4248,4295]
===
match
---
name: typing [880,886]
name: typing [880,886]
===
match
---
name: record [2347,2353]
name: record [2347,2353]
===
match
---
comparison [4542,4594]
comparison [4542,4594]
===
match
---
suite [2376,2435]
suite [2376,2435]
===
match
---
trailer [6121,6123]
trailer [6121,6123]
===
match
---
simple_stmt [1908,2028]
simple_stmt [1908,2028]
===
match
---
operator: = [8278,8279]
operator: = [8278,8279]
===
match
---
atom [8353,8469]
atom [8353,8469]
===
match
---
operator: = [10471,10472]
operator: = [10471,10472]
===
match
---
name: log [7113,7116]
name: log [7113,7116]
===
match
---
operator: = [5943,5944]
operator: = [5943,5944]
===
match
---
fstring_string: *** Fetching from:  [6606,6625]
fstring_string: *** Fetching from:  [6606,6625]
===
match
---
expr_stmt [4119,4127]
expr_stmt [4119,4127]
===
match
---
operator: += [4508,4510]
operator: += [4508,4510]
===
match
---
atom_expr [4542,4570]
atom_expr [4542,4570]
===
match
---
atom_expr [6962,6979]
atom_expr [6962,6979]
===
match
---
name: handler [2419,2426]
name: handler [2419,2426]
===
match
---
expr_stmt [6208,6290]
expr_stmt [6208,6290]
===
match
---
simple_stmt [8619,8660]
simple_stmt [8619,8660]
===
match
---
arglist [8760,8803]
arglist [8760,8803]
===
match
---
expr_stmt [8266,8304]
expr_stmt [8266,8304]
===
match
---
atom_expr [9098,9115]
atom_expr [9098,9115]
===
match
---
operator: = [8556,8557]
operator: = [8556,8557]
===
match
---
simple_stmt [825,840]
simple_stmt [825,840]
===
match
---
name: ti [10438,10440]
name: ti [10438,10440]
===
match
---
simple_stmt [2036,2068]
simple_stmt [2036,2068]
===
match
---
trailer [3013,3030]
trailer [3013,3030]
===
match
---
atom [8558,8570]
atom [8558,8570]
===
match
---
param [3320,3323]
param [3320,3323]
===
match
---
name: ti [5684,5686]
name: ti [5684,5686]
===
match
---
fstring_string: \n [4484,4486]
fstring_string: \n [4484,4486]
===
match
---
name: jinja_context [2715,2728]
name: jinja_context [2715,2728]
===
match
---
trailer [5559,5562]
trailer [5559,5562]
===
match
---
name: directory [10935,10944]
name: directory [10935,10944]
===
match
---
operator: { [6625,6626]
operator: { [6625,6626]
===
match
---
arglist [6924,6944]
arglist [6924,6944]
===
match
---
trailer [1627,1636]
trailer [1627,1636]
===
match
---
name: timeout [6667,6674]
name: timeout [6667,6674]
===
match
---
name: ti [5538,5540]
name: ti [5538,5540]
===
match
---
trailer [11016,11023]
trailer [11016,11023]
===
match
---
atom_expr [6462,6506]
atom_expr [6462,6506]
===
match
---
name: _init_file [2053,2063]
name: _init_file [2053,2063]
===
match
---
expr_stmt [6737,6796]
expr_stmt [6737,6796]
===
match
---
name: decode [6115,6121]
name: decode [6115,6121]
===
match
---
expr_stmt [4248,4294]
expr_stmt [4248,4294]
===
match
---
fstring_start: f" [4255,4257]
fstring_start: f" [4255,4257]
===
match
---
simple_stmt [6533,6585]
simple_stmt [6533,6585]
===
match
---
fstring [6604,6633]
fstring [6604,6633]
===
match
---
trailer [10540,10545]
trailer [10540,10545]
===
match
---
name: log [4119,4122]
name: log [4119,4122]
===
match
---
trailer [10951,10992]
trailer [10951,10992]
===
match
---
fstring_expr [7275,7283]
fstring_expr [7275,7283]
===
match
---
simple_stmt [1620,1639]
simple_stmt [1620,1639]
===
match
---
string: "TaskInstance" [1883,1897]
string: "TaskInstance" [1883,1897]
===
match
---
trailer [2063,2067]
trailer [2063,2067]
===
match
---
name: execution_date [3170,3184]
name: execution_date [3170,3184]
===
match
---
trailer [2080,2088]
trailer [2080,2088]
===
match
---
string: 'try_number' [2729,2741]
string: 'try_number' [2729,2741]
===
match
---
funcdef [7334,9164]
funcdef [7334,9164]
===
match
---
atom_expr [10486,10501]
atom_expr [10486,10501]
===
match
---
name: handler [2499,2506]
name: handler [2499,2506]
===
match
---
name: self [3314,3318]
name: self [3314,3318]
===
match
---
param [3324,3335]
param [3324,3335]
===
match
---
atom_expr [5496,5507]
atom_expr [5496,5507]
===
match
---
name: metadata [9118,9126]
name: metadata [9118,9126]
===
match
---
atom [8371,8454]
atom [8371,8454]
===
match
---
operator: , [8493,8494]
operator: , [8493,8494]
===
match
---
trailer [2110,2139]
trailer [2110,2139]
===
match
---
operator: = [6321,6322]
operator: = [6321,6322]
===
match
---
arglist [6432,6506]
arglist [6432,6506]
===
match
---
number: 0o777 [10957,10962]
number: 0o777 [10957,10962]
===
match
---
name: matches [5478,5485]
name: matches [5478,5485]
===
match
---
trailer [6758,6796]
trailer [6758,6796]
===
match
---
name: text [7136,7140]
name: text [7136,7140]
===
match
---
expr_stmt [6597,6633]
expr_stmt [6597,6633]
===
match
---
name: hostname [5802,5810]
name: hostname [5802,5810]
===
match
---
atom_expr [11048,11076]
atom_expr [11048,11076]
===
match
---
expr_stmt [10396,10452]
expr_stmt [10396,10452]
===
match
---
operator: , [7347,7348]
operator: , [7347,7348]
===
match
---
fstring_string: \n [4525,4527]
fstring_string: \n [4525,4527]
===
match
---
name: next_try_number [8238,8253]
name: next_try_number [8238,8253]
===
match
---
atom_expr [8643,8659]
atom_expr [8643,8659]
===
match
---
name: len [5428,5431]
name: len [5428,5431]
===
match
---
operator: , [6770,6771]
operator: , [6770,6771]
===
match
---
name: log [4248,4251]
name: log [4248,4251]
===
match
---
number: 63 [4819,4821]
number: 63 [4819,4821]
===
match
---
name: log [7224,7227]
name: log [7224,7227]
===
match
---
trailer [4521,4524]
trailer [4521,4524]
===
match
---
name: i [8672,8673]
name: i [8672,8673]
===
match
---
atom_expr [3097,3106]
atom_expr [3097,3106]
===
match
---
atom [5220,5404]
atom [5220,5404]
===
match
---
name: self [2468,2472]
name: self [2468,2472]
===
match
---
operator: , [10501,10502]
operator: , [10501,10502]
===
match
---
atom_expr [4074,4089]
atom_expr [4074,4089]
===
match
---
except_clause [6813,6856]
except_clause [6813,6856]
===
match
---
name: ValueError [6845,6855]
name: ValueError [6845,6855]
===
match
---
name: url [6626,6629]
name: url [6626,6629]
===
match
---
exprlist [8672,8693]
exprlist [8672,8693]
===
match
---
atom_expr [4799,4815]
atom_expr [4799,4815]
===
match
---
string: "utf-8" [6982,6989]
string: "utf-8" [6982,6989]
===
match
---
funcdef [2360,2435]
funcdef [2360,2435]
===
match
---
string: 'executor' [4559,4569]
string: 'executor' [4559,4569]
===
match
---
atom_expr [5737,6048]
atom_expr [5737,6048]
===
match
---
name: self [2048,2052]
name: self [2048,2052]
===
match
---
name: res [5731,5734]
name: res [5731,5734]
===
match
---
operator: , [2939,2940]
operator: , [2939,2940]
===
match
---
trailer [3184,3194]
trailer [3184,3194]
===
match
---
operator: = [9116,9117]
operator: = [9116,9117]
===
match
---
suite [4227,4348]
suite [4227,4348]
===
match
---
suite [5509,5563]
suite [5509,5563]
===
match
---
name: Optional [909,917]
name: Optional [909,917]
===
match
---
operator: , [8793,8794]
operator: , [8793,8794]
===
match
---
string: 'task' [2632,2638]
string: 'task' [2632,2638]
===
match
---
string: "http://{ti.hostname}:{worker_log_server_port}/log" [6336,6387]
string: "http://{ti.hostname}:{worker_log_server_port}/log" [6336,6387]
===
match
---
trailer [9046,9048]
trailer [9046,9048]
===
match
---
expr_stmt [6962,6989]
expr_stmt [6962,6989]
===
match
---
name: try_number_element [8775,8793]
name: try_number_element [8775,8793]
===
match
---
atom_expr [4004,4041]
atom_expr [4004,4041]
===
match
---
name: res [6078,6081]
name: res [6078,6081]
===
match
---
name: self [1756,1760]
name: self [1756,1760]
===
match
---
trailer [11149,11155]
trailer [11170,11176]
===
match
---
trailer [8237,8253]
trailer [8237,8253]
===
match
---
argument [3210,3231]
argument [3210,3231]
===
match
---
funcdef [2520,3243]
funcdef [2520,3243]
===
match
---
name: self [2076,2080]
name: self [2076,2080]
===
match
---
expr_stmt [4504,4528]
expr_stmt [4504,4528]
===
match
---
name: ti [3097,3099]
name: ti [3097,3099]
===
match
---
param [1879,1897]
param [1879,1897]
===
match
---
try_stmt [6712,6883]
try_stmt [6712,6883]
===
match
---
simple_stmt [3286,3299]
simple_stmt [3286,3299]
===
match
---
trailer [6114,6121]
trailer [6114,6121]
===
match
---
trailer [5686,5695]
trailer [5686,5695]
===
match
---
simple_stmt [6597,6634]
simple_stmt [6597,6634]
===
match
---
atom [8496,8516]
atom [8496,8516]
===
match
---
fstring_expr [6571,6581]
fstring_expr [6571,6581]
===
match
---
string: 'kubernetes' [5162,5174]
string: 'kubernetes' [5162,5174]
===
match
---
name: self [4074,4078]
name: self [4074,4078]
===
match
---
param [7343,7348]
param [7343,7348]
===
match
---
trailer [6335,6407]
trailer [6335,6407]
===
match
---
testlist [8489,8517]
testlist [8489,8517]
===
match
---
name: ti [5496,5498]
name: ti [5496,5498]
===
match
---
trailer [4329,4347]
trailer [4329,4347]
===
match
---
name: get [6467,6470]
name: get [6467,6470]
===
match
---
operator: = [1730,1731]
operator: = [1730,1731]
===
match
---
name: try_number [10441,10451]
name: try_number [10441,10451]
===
match
---
trailer [11155,11173]
trailer [11176,11194]
===
match
---
atom_expr [5538,5549]
atom_expr [5538,5549]
===
match
---
atom_expr [5552,5562]
atom_expr [5552,5562]
===
match
---
if_stmt [2300,2355]
if_stmt [2300,2355]
===
match
---
name: self [2329,2333]
name: self [2329,2333]
===
match
---
name: name [5259,5263]
name: name [5259,5263]
===
match
---
trailer [7093,7095]
trailer [7093,7095]
===
match
---
name: relative_path [10503,10516]
name: relative_path [10503,10516]
===
match
---
trailer [4078,4089]
trailer [4078,4089]
===
match
---
name: ti [9190,9192]
name: ti [9190,9192]
===
match
---
simple_stmt [3040,3243]
simple_stmt [3040,3243]
===
match
---
trailer [2341,2346]
trailer [2341,2346]
===
match
---
trailer [9010,9013]
trailer [9010,9013]
===
match
---
name: self [2575,2579]
name: self [2575,2579]
===
match
---
arglist [6759,6795]
arglist [6759,6795]
===
match
---
simple_stmt [4050,4110]
simple_stmt [4050,4110]
===
match
---
operator: = [10971,10972]
operator: = [10971,10972]
===
match
---
name: _read_grouped_logs [9028,9046]
name: _read_grouped_logs [9028,9046]
===
match
---
name: str [1582,1585]
name: str [1582,1585]
===
match
---
simple_stmt [2229,2263]
simple_stmt [2229,2263]
===
match
---
trailer [3069,3076]
trailer [3069,3076]
===
match
---
trailer [1718,1729]
trailer [1718,1729]
===
match
---
operator: = [2089,2090]
operator: = [2089,2090]
===
match
---
name: getint [6752,6758]
name: getint [6752,6758]
===
match
---
name: directory [10526,10535]
name: directory [10526,10535]
===
match
---
operator: , [3322,3323]
operator: , [3322,3323]
===
match
---
name: parents [10964,10971]
name: parents [10964,10971]
===
match
---
name: pod_list [5110,5118]
name: pod_list [5110,5118]
===
match
---
trailer [9027,9046]
trailer [9027,9046]
===
match
---
name: exist_ok [10978,10986]
name: exist_ok [10978,10986]
===
match
---
name: startswith [5359,5369]
name: startswith [5359,5369]
===
match
---
name: Exception [6144,6153]
name: Exception [6144,6153]
===
match
---
expr_stmt [2790,2958]
expr_stmt [2790,2958]
===
match
---
argument [3120,3138]
argument [3120,3138]
===
match
---
fstring [6540,6584]
fstring [6540,6584]
===
match
---
trailer [2866,2881]
trailer [2866,2881]
===
match
---
name: try_number [4030,4040]
name: try_number [4030,4040]
===
match
---
name: Exception [4367,4376]
name: Exception [4367,4376]
===
match
---
name: filename_jinja_template [2983,3006]
name: filename_jinja_template [2983,3006]
===
match
---
operator: { [8427,8428]
operator: { [8427,8428]
===
match
---
atom_expr [2205,2219]
atom_expr [2205,2219]
===
match
---
comparison [4799,4821]
comparison [4799,4821]
===
match
---
operator: , [3231,3232]
operator: , [3231,3232]
===
match
---
name: exists [4148,4154]
name: exists [4148,4154]
===
match
---
operator: , [6029,6030]
operator: , [6029,6030]
===
match
---
if_stmt [5425,5563]
if_stmt [5425,5563]
===
match
---
suite [6082,6124]
suite [6082,6124]
===
match
---
dotted_name [1004,1025]
dotted_name [1004,1025]
===
match
---
simple_stmt [3395,3786]
simple_stmt [3395,3786]
===
match
---
import_from [4671,4729]
import_from [4671,4729]
===
match
---
atom_expr [5587,5713]
atom_expr [5587,5713]
===
match
---
name: hostname [5687,5695]
name: hostname [5687,5695]
===
match
---
operator: } [6284,6285]
operator: } [6284,6285]
===
match
---
operator: } [6580,6581]
operator: } [6580,6581]
===
match
---
trailer [2098,2110]
trailer [2098,2110]
===
match
---
atom_expr [5474,5489]
atom_expr [5474,5489]
===
match
---
operator: * [8592,8593]
operator: * [8592,8593]
===
match
---
param [2547,2550]
param [2547,2550]
===
match
---
if_stmt [5471,5563]
if_stmt [5471,5563]
===
match
---
trailer [1625,1627]
trailer [1625,1627]
===
match
---
name: get [5847,5850]
name: get [5847,5850]
===
match
---
simple_stmt [7224,7287]
simple_stmt [7224,7287]
===
match
---
name: log [5580,5583]
name: log [5580,5583]
===
match
---
name: filename_template [1833,1850]
name: filename_template [1833,1850]
===
match
---
atom_expr [5341,5382]
atom_expr [5341,5382]
===
match
---
return_stmt [8482,8517]
return_stmt [8482,8517]
===
match
---
name: log [8733,8736]
name: log [8733,8736]
===
match
---
name: self [10486,10490]
name: self [10486,10490]
===
match
---
name: raise_for_status [7077,7093]
name: raise_for_status [7077,7093]
===
match
---
name: close [11069,11074]
name: close [11069,11074]
===
match
---
name: log_relative_path [4091,4108]
name: log_relative_path [4091,4108]
===
match
---
param [1873,1878]
param [1873,1878]
===
match
---
atom [8372,8453]
atom [8372,8453]
===
match
---
string: 'kubernetes' [5851,5863]
string: 'kubernetes' [5851,5863]
===
match
---
operator: { [6277,6278]
operator: { [6277,6278]
===
match
---
name: self [1780,1784]
name: self [1780,1784]
===
match
---
atom_expr [10930,10992]
atom_expr [10930,10992]
===
match
---
name: get [5158,5161]
name: get [5158,5161]
===
match
---
name: full_path [11024,11033]
name: full_path [11024,11033]
===
match
---
name: name [5354,5358]
name: name [5354,5358]
===
match
---
trailer [2982,3006]
trailer [2982,3006]
===
match
---
name: AirflowConfigException [6821,6843]
name: AirflowConfigException [6821,6843]
===
match
---
trailer [3099,3106]
trailer [3099,3106]
===
match
---
name: isoformat [3185,3194]
name: isoformat [3185,3194]
===
match
---
name: ti [6435,6437]
name: ti [6435,6437]
===
match
---
simple_stmt [2657,2699]
simple_stmt [2657,2699]
===
match
---
atom_expr [8224,8253]
atom_expr [8224,8253]
===
match
---
name: self [1714,1718]
name: self [1714,1718]
===
match
---
trailer [1149,1157]
trailer [1149,1157]
===
match
---
arglist [10952,10991]
arglist [10952,10991]
===
match
---
name: __init__ [1628,1636]
name: __init__ [1628,1636]
===
match
---
string: 'core' [4551,4557]
string: 'core' [4551,4557]
===
match
---
comparison [5474,5508]
comparison [5474,5508]
===
match
---
operator: = [6745,6746]
operator: = [6745,6746]
===
match
---
simple_stmt [2715,2756]
simple_stmt [2715,2756]
===
match
---
name: _init_file [9173,9183]
name: _init_file [9173,9183]
===
match
---
name: next_try [8294,8302]
name: next_try [8294,8302]
===
match
---
operator: , [8292,8293]
operator: , [8292,8293]
===
match
---
operator: , [4028,4029]
operator: , [4028,4029]
===
match
---
name: try_number [3324,3334]
name: try_number [3324,3334]
===
match
---
name: ti [6432,6434]
name: ti [6432,6434]
===
match
---
trailer [5498,5507]
trailer [5498,5507]
===
match
---
name: self [9023,9027]
name: self [9023,9027]
===
match
---
fstring_string: ***  [4513,4517]
fstring_string: ***  [4513,4517]
===
match
---
operator: , [1585,1586]
operator: , [1585,1586]
===
match
---
expr_stmt [5538,5562]
expr_stmt [5538,5562]
===
match
---
trailer [6281,6284]
trailer [6281,6284]
===
match
---
trailer [2881,2891]
trailer [2881,2891]
===
match
---
trailer [1636,1638]
trailer [1636,1638]
===
match
---
suite [8720,9127]
suite [8720,9127]
===
match
---
operator: } [7327,7328]
operator: } [7327,7328]
===
match
---
simple_stmt [9006,9086]
simple_stmt [9006,9086]
===
match
---
name: hasattr [2620,2627]
name: hasattr [2620,2627]
===
match
---
operator: = [6980,6981]
operator: = [6980,6981]
===
match
---
fstring_end: " [6583,6584]
fstring_end: " [6583,6584]
===
match
---
operator: { [4517,4518]
operator: { [4517,4518]
===
match
---
trailer [2432,2434]
trailer [2432,2434]
===
match
---
name: execution_date [3152,3166]
name: execution_date [3152,3166]
===
match
---
expr_stmt [1647,1666]
expr_stmt [1647,1666]
===
match
---
argument [5937,5949]
argument [5937,5949]
===
match
---
name: set_context [1861,1872]
name: set_context [1861,1872]
===
match
---
trailer [2498,2506]
trailer [2498,2506]
===
match
---
comp_if [5338,5382]
comp_if [5338,5382]
===
match
---
fstring_end: " [7285,7286]
fstring_end: " [7285,7286]
===
match
---
param [7381,7394]
param [7381,7394]
===
match
---
operator: = [5798,5799]
operator: = [5798,5799]
===
match
---
suite [1073,1118]
suite [1073,1118]
===
match
---
expr_stmt [2076,2139]
expr_stmt [2076,2139]
===
match
---
name: parse_template_string [1811,1832]
name: parse_template_string [1811,1832]
===
match
---
operator: , [9188,9189]
operator: , [9188,9189]
===
match
---
operator: , [2893,2894]
operator: , [2893,2894]
===
match
---
name: utils [1012,1017]
name: utils [1012,1017]
===
match
---
name: dag_id [3100,3106]
name: dag_id [3100,3106]
===
match
---
operator: , [8387,8388]
operator: , [8387,8388]
===
match
---
operator: = [5841,5842]
operator: = [5841,5842]
===
match
---
fstring_expr [6277,6285]
fstring_expr [6277,6285]
===
match
---
name: setLevel [2242,2250]
name: setLevel [2242,2250]
===
match
---
trailer [5353,5358]
trailer [5353,5358]
===
match
---
name: try_number [7364,7374]
name: try_number [7364,7374]
===
match
---
trailer [4008,4025]
trailer [4008,4025]
===
match
---
string: 'celery' [6471,6479]
string: 'celery' [6471,6479]
===
match
---
name: self [2229,2233]
name: self [2229,2233]
===
match
---
parameters [2369,2375]
parameters [2369,2375]
===
match
---
atom_expr [2978,3030]
atom_expr [2978,3030]
===
match
---
arglist [5851,5876]
arglist [5851,5876]
===
match
---
trailer [2241,2250]
trailer [2241,2250]
===
match
---
trailer [8290,8303]
trailer [8290,8303]
===
match
---
name: i [9011,9012]
name: i [9011,9012]
===
match
---
funcdef [2268,2355]
funcdef [2268,2355]
===
match
---
arith_expr [7120,7140]
arith_expr [7120,7140]
===
match
---
name: path [4143,4147]
name: path [4143,4147]
===
match
---
fstring_end: ' [6289,6290]
fstring_end: ' [6289,6290]
===
match
---
atom_expr [1647,1659]
atom_expr [1647,1659]
===
match
---
name: handler [1652,1659]
name: handler [1652,1659]
===
match
---
atom_expr [8285,8303]
atom_expr [8285,8303]
===
match
---
expr_stmt [2657,2698]
expr_stmt [2657,2698]
===
match
---
name: format [5656,5662]
name: format [5656,5662]
===
match
---
trailer [6923,6945]
trailer [6923,6945]
===
match
---
simple_stmt [7068,7096]
simple_stmt [7068,7096]
===
match
---
string: 'ts' [2858,2862]
string: 'ts' [2858,2862]
===
match
---
operator: = [4059,4060]
operator: = [4059,4060]
===
match
---
trailer [4142,4147]
trailer [4142,4147]
===
match
---
suite [4165,4529]
suite [4165,4529]
===
match
---
name: location [4282,4290]
name: location [4282,4290]
===
match
---
operator: = [7389,7390]
operator: = [7389,7390]
===
match
---
operator: , [6843,6844]
operator: , [6843,6844]
===
match
---
parameters [2276,2290]
parameters [2276,2290]
===
match
---
trailer [4546,4550]
trailer [4546,4550]
===
match
---
name: logs [9006,9010]
name: logs [9006,9010]
===
match
---
simple_stmt [8580,8611]
simple_stmt [8580,8611]
===
match
---
number: 1 [8331,8332]
number: 1 [8331,8332]
===
match
---
atom_expr [2151,2165]
atom_expr [2151,2165]
===
match
---
name: response [6900,6908]
name: response [6900,6908]
===
match
---
suite [9194,11200]
suite [9194,11331]
===
match
---
name: try_number [8318,8328]
name: try_number [8318,8328]
===
match
---
operator: , [8736,8737]
operator: , [8736,8737]
===
match
---
trailer [5249,5258]
trailer [5249,5258]
===
match
---
trailer [4324,4329]
trailer [4324,4329]
===
match
---
name: relative_path [10396,10409]
name: relative_path [10396,10409]
===
match
---
name: jinja_context [3016,3029]
name: jinja_context [3016,3029]
===
match
---
fstring_expr [4474,4484]
fstring_expr [4474,4484]
===
match
---
expr_stmt [8619,8659]
expr_stmt [8619,8659]
===
match
---
trailer [6325,6330]
trailer [6325,6330]
===
match
---
trailer [1760,1778]
trailer [1760,1778]
===
match
---
trailer [9069,9078]
trailer [9069,9078]
===
match
---
name: kubernetes [4684,4694]
name: kubernetes [4684,4694]
===
match
---
name: FileHandler [2099,2110]
name: FileHandler [2099,2110]
===
match
---
trailer [10945,10951]
trailer [10945,10951]
===
match
---
dotted_name [1083,1097]
dotted_name [1083,1097]
===
match
---
fstring_start: f' [6215,6217]
fstring_start: f' [6215,6217]
===
match
---
name: e [7280,7281]
name: e [7280,7281]
===
match
---
string: '*** Trying to get logs (last 100 lines) from worker pod {} ***\n\n' [5587,5655]
string: '*** Trying to get logs (last 100 lines) from worker pod {} ***\n\n' [5587,5655]
===
match
---
atom_expr [1714,1729]
atom_expr [1714,1729]
===
match
---
simple_stmt [4671,4730]
simple_stmt [4671,4730]
===
match
---
trailer [4802,4815]
trailer [4802,4815]
===
match
---
trailer [2512,2514]
trailer [2512,2514]
===
match
---
name: local_loc [2111,2120]
name: local_loc [2111,2120]
===
match
---
name: self [3047,3051]
name: self [3047,3051]
===
match
---
if_stmt [11002,11174]
if_stmt [11002,11305]
===
match
---
if_stmt [2572,3031]
if_stmt [2572,3031]
===
match
---
if_stmt [4137,7287]
if_stmt [4137,7287]
===
match
---
operator: = [3220,3221]
operator: = [3220,3221]
===
match
---
arglist [2628,2638]
arglist [2628,2638]
===
match
---
trailer [5846,5850]
trailer [5846,5850]
===
match
---
sync_comp_for [5288,5382]
sync_comp_for [5288,5382]
===
match
---
trailer [10440,10451]
trailer [10440,10451]
===
match
---
import_as_names [894,917]
import_as_names [894,917]
===
match
---
name: self [2978,2982]
name: self [2978,2982]
===
match
---
simple_stmt [7405,7875]
simple_stmt [7405,7875]
===
match
---
simple_stmt [2329,2355]
simple_stmt [2329,2355]
===
match
---
trailer [1832,1851]
trailer [1832,1851]
===
match
---
operator: , [2836,2837]
operator: , [2836,2837]
===
match
---
name: metadata_array [9098,9112]
name: metadata_array [9098,9112]
===
match
---
testlist_star_expr [8733,8746]
testlist_star_expr [8733,8746]
===
match
---
suite [6857,6883]
suite [6857,6883]
===
match
---
trailer [5662,5713]
trailer [5662,5713]
===
match
---
name: i [9113,9114]
name: i [9113,9114]
===
match
---
name: pod [5292,5295]
name: pod [5292,5295]
===
match
---
suite [2640,2756]
suite [2640,2756]
===
match
---
expr_stmt [4050,4109]
expr_stmt [4050,4109]
===
match
---
funcdef [3304,7329]
funcdef [3304,7329]
===
match
---
simple_stmt [7296,7329]
simple_stmt [7296,7329]
===
match
---
operator: = [6675,6676]
operator: = [6675,6676]
===
match
---
name: self [2414,2418]
name: self [2414,2418]
===
match
---
trailer [2418,2426]
trailer [2418,2426]
===
match
---
atom_expr [2673,2698]
atom_expr [2673,2698]
===
match
---
operator: , [1563,1564]
operator: , [1563,1564]
===
match
---
param [3314,3319]
param [3314,3319]
===
match
---
trailer [3006,3013]
trailer [3006,3013]
===
match
---
name: AirflowConfigException [970,992]
name: AirflowConfigException [970,992]
===
match
---
trailer [5431,5440]
trailer [5431,5440]
===
match
---
name: metadata [5250,5258]
name: metadata [5250,5258]
===
match
---
simple_stmt [5538,5563]
simple_stmt [5538,5563]
===
match
---
operator: = [4435,4436]
operator: = [4435,4436]
===
match
---
atom_expr [11147,11173]
atom_expr [11168,11194]
===
match
---
fstring [7231,7286]
fstring [7231,7286]
===
match
---
param [2370,2374]
param [2370,2374]
===
match
---
parameters [2540,2562]
parameters [2540,2562]
===
match
---
trailer [10475,10480]
trailer [10475,10480]
===
match
---
expr_stmt [9098,9126]
expr_stmt [9098,9126]
===
match
---
operator: , [907,908]
operator: , [907,908]
===
match
---
name: self [2303,2307]
name: self [2303,2307]
===
match
---
name: url [6317,6320]
name: url [6317,6320]
===
match
---
suite [2401,2435]
suite [2401,2435]
===
match
---
operator: = [5908,5909]
operator: = [5908,5909]
===
match
---
simple_stmt [850,875]
simple_stmt [850,875]
===
match
---
if_stmt [1056,1118]
if_stmt [1056,1118]
===
match
---
simple_stmt [7113,7141]
simple_stmt [7113,7141]
===
match
---
expr_stmt [4431,4487]
expr_stmt [4431,4487]
===
match
---
name: location [4475,4483]
name: location [4475,4483]
===
match
---
operator: , [7306,7307]
operator: , [7306,7307]
===
match
---
trailer [3076,3242]
trailer [3076,3242]
===
match
---
operator: = [3344,3345]
operator: = [3344,3345]
===
match
---
name: handler [2334,2341]
name: handler [2334,2341]
===
match
---
number: 0 [5560,5561]
number: 0 [5560,5561]
===
match
---
dotted_name [4676,4706]
dotted_name [4676,4706]
===
match
---
operator: = [5218,5219]
operator: = [5218,5219]
===
match
---
return_stmt [2971,3030]
return_stmt [2971,3030]
===
match
---
comparison [8318,8332]
comparison [8318,8332]
===
match
---
name: dirname [10546,10553]
name: dirname [10546,10553]
===
match
---
name: try_numbers [8266,8277]
name: try_numbers [8266,8277]
===
match
---
name: self [2205,2209]
name: self [2205,2209]
===
match
---
fstring_end: " [4527,4528]
fstring_end: " [4527,4528]
===
match
---
name: line [6110,6114]
name: line [6110,6114]
===
match
---
try_stmt [6646,7287]
try_stmt [6646,7287]
===
match
---
dictorsetmaker [2828,2940]
dictorsetmaker [2828,2940]
===
match
---
argument [6007,6029]
argument [6007,6029]
===
match
---
trailer [11068,11074]
trailer [11068,11074]
===
match
---
parameters [2449,2455]
parameters [2449,2455]
===
match
---
name: encoding [6971,6979]
name: encoding [6971,6979]
===
match
---
name: timeout [6737,6744]
name: timeout [6737,6744]
===
match
---
operator: = [8634,8635]
operator: = [8634,8635]
===
match
---
name: handler [2081,2088]
name: handler [2081,2088]
===
match
---
name: self [2450,2454]
name: self [2450,2454]
===
match
---
trailer [2579,2603]
trailer [2579,2603]
===
match
---
trailer [5358,5369]
trailer [5358,5369]
===
match
---
simple_stmt [5731,6049]
simple_stmt [5731,6049]
===
match
---
arglist [6336,6406]
arglist [6336,6406]
===
match
---
atom_expr [4322,4347]
atom_expr [4322,4347]
===
match
---
expr_stmt [8213,8253]
expr_stmt [8213,8253]
===
match
---
expr_stmt [2036,2067]
expr_stmt [2036,2067]
===
match
---
if_stmt [8178,8571]
if_stmt [8178,8571]
===
match
---
name: formatter [2210,2219]
name: formatter [2210,2219]
===
match
---
trailer [4147,4154]
trailer [4147,4154]
===
match
---
trailer [2675,2696]
trailer [2675,2696]
===
match
---
name: full_path [10554,10563]
name: full_path [10554,10563]
===
match
---
fstring [4437,4487]
fstring [4437,4487]
===
match
---
fstring_expr [4517,4525]
fstring_expr [4517,4525]
===
match
---
name: log [4431,4434]
name: log [4431,4434]
===
match
---
trailer [5344,5353]
trailer [5344,5353]
===
match
---
operator: = [2046,2047]
operator: = [2046,2047]
===
match
---
name: _render_filename [2524,2540]
name: _render_filename [2524,2540]
===
match
---
operator: } [8638,8639]
operator: } [8638,8639]
===
match
---
name: response [7127,7135]
name: response [7127,7135]
===
match
---
name: log [9080,9083]
name: log [9080,9083]
===
match
---
trailer [6407,6414]
trailer [6407,6414]
===
match
---
name: self [2494,2498]
name: self [2494,2498]
===
match
---
atom_expr [2229,2262]
atom_expr [2229,2262]
===
match
---
atom_expr [10473,10517]
atom_expr [10473,10517]
===
match
---
trailer [5369,5382]
trailer [5369,5382]
===
match
---
name: pod [5341,5344]
name: pod [5341,5344]
===
match
---
param [9184,9189]
param [9184,9189]
===
match
---
fstring [8389,8452]
fstring [8389,8452]
===
match
---
atom [9054,9085]
atom [9054,9085]
===
match
---
expr_stmt [4747,4778]
expr_stmt [4747,4778]
===
match
---
operator: , [8673,8674]
operator: , [8673,8674]
===
match
---
operator: == [4571,4573]
operator: == [4571,4573]
===
match
---
fstring_start: f' [8389,8391]
fstring_start: f' [8389,8391]
===
match
---
trailer [10416,10433]
trailer [10416,10433]
===
match
---
name: self [2151,2155]
name: self [2151,2155]
===
match
---
name: filename_template [1587,1604]
name: filename_template [1587,1604]
===
match
---
string: '' [8588,8590]
string: '' [8588,8590]
===
match
---
atom_expr [7068,7095]
atom_expr [7068,7095]
===
match
---
name: encoding [2122,2130]
name: encoding [2122,2130]
===
match
---
name: join [4325,4329]
name: join [4325,4329]
===
match
---
tfpdef [1565,1585]
tfpdef [1565,1585]
===
match
---
atom_expr [9006,9013]
atom_expr [9006,9013]
===
match
---
name: full_path [11053,11062]
name: full_path [11053,11062]
===
match
---
operator: , [6479,6480]
operator: , [6479,6480]
===
match
---
name: conf [4542,4546]
name: conf [4542,4546]
===
match
---
name: name [5794,5798]
name: name [5794,5798]
===
match
---
name: self [2388,2392]
name: self [2388,2392]
===
match
---
name: close [2444,2449]
name: close [2444,2449]
===
match
---
name: chmod [11150,11155]
name: chmod [11171,11176]
===
match
---
suite [2456,2515]
suite [2456,2515]
===
match
---
simple_stmt [840,850]
simple_stmt [840,850]
===
match
---
suite [1159,11200]
suite [1159,11331]
===
match
---
name: logs [9143,9147]
name: logs [9143,9147]
===
match
---
name: _render_filename [4009,4025]
name: _render_filename [4009,4025]
===
match
---
simple_stmt [10396,10453]
simple_stmt [10396,10453]
===
match
---
arglist [11053,11067]
arglist [11053,11067]
===
match
---
operator: , [2281,2282]
operator: , [2281,2282]
===
match
---
trailer [7076,7093]
trailer [7076,7093]
===
match
---
operator: + [7125,7126]
operator: + [7125,7126]
===
match
---
expr_stmt [8346,8469]
expr_stmt [8346,8469]
===
match
---
return_stmt [3040,3242]
return_stmt [3040,3242]
===
match
---
atom_expr [2864,2893]
atom_expr [2864,2893]
===
match
---
operator: , [11062,11063]
operator: , [11062,11063]
===
match
---
name: container [5899,5908]
name: container [5899,5908]
===
match
---
string: 'KubernetesExecutor' [4574,4594]
string: 'KubernetesExecutor' [4574,4594]
===
match
---
name: self [1559,1563]
name: self [1559,1563]
===
match
---
simple_stmt [11147,11174]
simple_stmt [11168,11195]
===
match
---
name: timeout [6929,6936]
name: timeout [6929,6936]
===
match
---
name: os [4061,4063]
name: os [4061,4063]
===
match
---
trailer [4063,4068]
trailer [4063,4068]
===
match
---
operator: { [7308,7309]
operator: { [7308,7309]
===
match
---
string: "a" [11064,11067]
string: "a" [11064,11067]
===
match
---
suite [8200,8305]
suite [8200,8305]
===
match
---
name: try_number [2929,2939]
name: try_number [2929,2939]
===
match
---
operator: , [3106,3107]
operator: , [3106,3107]
===
match
---
name: os [4140,4142]
name: os [4140,4142]
===
match
---
simple_stmt [1078,1118]
simple_stmt [1078,1118]
===
match
---
argument [6439,6506]
argument [6439,6506]
===
match
---
name: __init__ [1550,1558]
name: __init__ [1550,1558]
===
match
---
param [1587,1609]
param [1587,1609]
===
match
---
name: base_log_folder [1565,1580]
name: base_log_folder [1565,1580]
===
match
---
arglist [10486,10516]
arglist [10486,10516]
===
match
---
operator: , [1778,1779]
operator: , [1778,1779]
===
match
---
testlist_comp [9056,9083]
testlist_comp [9056,9083]
===
match
---
fstring_string: \n [6630,6632]
fstring_string: \n [6630,6632]
===
match
---
fstring_string: \n [6581,6583]
fstring_string: \n [6581,6583]
===
match
---
arglist [6471,6505]
arglist [6471,6505]
===
match
---
fstring_expr [8427,8439]
fstring_expr [8427,8439]
===
match
---
term [8587,8610]
term [8587,8610]
===
match
---
atom [8637,8639]
atom [8637,8639]
===
match
---
atom_expr [4061,4109]
atom_expr [4061,4109]
===
match
---
suite [4822,5563]
suite [4822,5563]
===
match
---
funcdef [3248,3299]
funcdef [3248,3299]
===
match
---
operator: , [10976,10977]
operator: , [10976,10977]
===
match
---
argument [5794,5810]
argument [5794,5810]
===
match
---
name: ti [3167,3169]
name: ti [3167,3169]
===
match
---
name: worker_log_server_port [6439,6461]
name: worker_log_server_port [6439,6461]
===
match
---
argument [5971,5985]
argument [5971,5985]
===
match
---
name: try_number_element [8675,8693]
name: try_number_element [8675,8693]
===
match
---
trailer [2155,2165]
trailer [2155,2165]
===
match
---
operator: , [9078,9079]
operator: , [9078,9079]
===
match
---
expr_stmt [1756,1851]
expr_stmt [1756,1851]
===
match
---
name: dag_id [3090,3096]
name: dag_id [3090,3096]
===
match
---
name: logging [2091,2098]
name: logging [2091,2098]
===
match
---
name: readlines [4335,4344]
name: readlines [4335,4344]
===
match
---
fstring_string: \n\n [6285,6289]
fstring_string: \n\n [6285,6289]
===
match
---
suite [4637,6291]
suite [4637,6291]
===
match
---
trailer [2891,2893]
trailer [2891,2893]
===
match
---
simple_stmt [2494,2515]
simple_stmt [2494,2515]
===
match
---
expr_stmt [10461,10517]
expr_stmt [10461,10517]
===
match
---
name: ti [10434,10436]
name: ti [10434,10436]
===
match
---
trailer [5132,5152]
trailer [5132,5152]
===
match
---
trailer [2250,2262]
trailer [2250,2262]
===
match
---
name: self [2277,2281]
name: self [2277,2281]
===
match
---
name: ti [4026,4028]
name: ti [4026,4028]
===
match
---
name: try_number [2551,2561]
name: try_number [2551,2561]
===
match
---
trailer [5748,5772]
trailer [5748,5772]
===
match
---
trailer [5477,5489]
trailer [5477,5489]
===
match
---
suite [6650,7141]
suite [6650,7141]
===
match
---
simple_stmt [8482,8518]
simple_stmt [8482,8518]
===
match
---
name: open [4204,4208]
name: open [4204,4208]
===
match
---
tfpdef [1879,1897]
tfpdef [1879,1897]
===
match
---
atom_expr [4518,4524]
atom_expr [4518,4524]
===
match
---
simple_stmt [1647,1706]
simple_stmt [1647,1706]
===
match
---
atom_expr [2303,2315]
atom_expr [2303,2315]
===
match
---
arglist [8291,8302]
arglist [8291,8302]
===
match
---
fstring_end: " [4293,4294]
fstring_end: " [4293,4294]
===
match
---
trailer [5540,5549]
trailer [5540,5549]
===
match
---
fstring_string: *** Reading local file:  [4257,4281]
fstring_string: *** Reading local file:  [4257,4281]
===
match
---
operator: += [7117,7119]
operator: += [7117,7119]
===
match
---
trailer [7135,7140]
trailer [7135,7140]
===
match
---
name: handler [2308,2315]
name: handler [2308,2315]
===
match
---
name: task_instance [7349,7362]
name: task_instance [7349,7362]
===
match
---
atom_expr [4330,4346]
atom_expr [4330,4346]
===
match
---
name: _read_grouped_logs [3252,3270]
name: _read_grouped_logs [3252,3270]
===
match
---
trailer [4068,4073]
trailer [4068,4073]
===
match
---
name: render [3007,3013]
name: render [3007,3013]
===
match
---
name: e [7173,7174]
name: e [7173,7174]
===
match
---
simple_stmt [8266,8305]
simple_stmt [8266,8305]
===
match
---
trailer [5258,5263]
trailer [5258,5263]
===
match
---
name: log_relative_path [6389,6406]
name: log_relative_path [6389,6406]
===
match
---
name: close [2507,2512]
name: close [2507,2512]
===
match
---
suite [7396,9164]
suite [7396,9164]
===
match
---
name: try_number [8428,8438]
name: try_number [8428,8438]
===
match
---
operator: += [7228,7230]
operator: += [7228,7230]
===
match
---
name: full_path [10461,10470]
name: full_path [10461,10470]
===
match
---
name: os [6323,6325]
name: os [6323,6325]
===
match
---
name: airflow [4676,4683]
name: airflow [4676,4683]
===
match
---
parameters [9183,9193]
parameters [9183,9193]
===
match
---
import_from [850,874]
import_from [850,874]
===
match
---
param [2283,2289]
param [2283,2289]
===
match
---
operator: = [10986,10987]
operator: = [10986,10987]
===
match
---
trailer [2307,2315]
trailer [2307,2315]
===
match
---
expr_stmt [10526,10564]
expr_stmt [10526,10564]
===
match
---
name: kube_client [4695,4706]
name: kube_client [4695,4706]
===
match
---
name: metadata_array [8619,8633]
name: metadata_array [8619,8633]
===
match
---
import_name [919,934]
import_name [919,934]
===
match
---
string: '\n' [7120,7124]
string: '\n' [7120,7124]
===
match
---
operator: = [3096,3097]
operator: = [3096,3097]
===
match
---
operator: == [5441,5443]
operator: == [5441,5443]
===
match
---
import_name [840,849]
import_name [840,849]
===
match
---
parameters [1558,1610]
parameters [1558,1610]
===
match
---
simple_stmt [6667,6696]
simple_stmt [6667,6696]
===
match
---
expr_stmt [1714,1747]
expr_stmt [1714,1747]
===
match
---
name: path [6326,6330]
name: path [6326,6330]
===
match
---
name: get [6920,6923]
name: get [6920,6923]
===
match
---
operator: { [7275,7276]
operator: { [7275,7276]
===
match
---
name: location [6572,6580]
name: location [6572,6580]
===
match
---
simple_stmt [5210,5405]
simple_stmt [5210,5405]
===
match
---
trailer [3194,3196]
trailer [3194,3196]
===
match
---
suite [1899,2263]
suite [1899,2263]
===
match
---
name: namespace [5832,5841]
name: namespace [5832,5841]
===
match
---
simple_stmt [6737,6797]
simple_stmt [6737,6797]
===
match
---
atom_expr [8697,8719]
atom_expr [8697,8719]
===
match
---
atom_expr [2414,2434]
atom_expr [2414,2434]
===
match
---
trailer [2191,2204]
trailer [2191,2204]
===
match
---
name: flush [2427,2432]
name: flush [2427,2432]
===
match
---
trailer [10934,10945]
trailer [10934,10945]
===
match
---
name: response [7068,7076]
name: response [7068,7076]
===
match
---
term [8636,8659]
term [8636,8659]
===
match
---
operator: = [1809,1810]
operator: = [1809,1810]
===
match
---
name: logs [8489,8493]
name: logs [8489,8493]
===
match
---
trailer [10480,10485]
trailer [10480,10485]
===
match
---
number: 0 [5486,5487]
number: 0 [5486,5487]
===
match
---
funcdef [1857,2263]
funcdef [1857,2263]
===
match
---
name: log [9016,9019]
name: log [9016,9019]
===
match
---
atom_expr [5246,5263]
atom_expr [5246,5263]
===
match
---
name: str [6278,6281]
name: str [6278,6281]
===
match
---
testlist_comp [8371,8455]
testlist_comp [8371,8455]
===
match
---
name: format [3070,3076]
name: format [3070,3076]
===
match
---
simple_stmt [6208,6291]
simple_stmt [6208,6291]
===
match
---
name: airflow [941,948]
name: airflow [941,948]
===
match
---
suite [2604,3031]
suite [2604,3031]
===
match
---
trailer [10433,10452]
trailer [10433,10452]
===
match
---
suite [6304,7287]
suite [6304,7287]
===
match
---
name: self [2541,2545]
name: self [2541,2545]
===
match
---
simple_stmt [8213,8254]
simple_stmt [8213,8254]
===
match
---
name: join [10481,10485]
name: join [10481,10485]
===
match
---
argument [10952,10962]
argument [10952,10962]
===
match
---
name: _read [3308,3313]
name: _read [3308,3313]
===
match
---
trailer [5161,5188]
trailer [5161,5188]
===
match
---
dictorsetmaker [7309,7327]
dictorsetmaker [7309,7327]
===
match
---
name: log_relative_path [3984,4001]
name: log_relative_path [3984,4001]
===
match
---
name: os [11009,11011]
name: os [11009,11011]
===
match
---
name: emit [2272,2276]
name: emit [2272,2276]
===
match
---
name: metadata [3336,3344]
name: metadata [3336,3344]
===
match
---
atom_expr [4803,4814]
atom_expr [4803,4814]
===
match
---
suite [11035,11174]
suite [11035,11305]
===
match
---
string: "" [4322,4324]
string: "" [4322,4324]
===
match
---
name: hostname [5373,5381]
name: hostname [5373,5381]
===
match
---
trailer [8646,8659]
trailer [8646,8659]
===
match
---
name: location [4209,4217]
name: location [4209,4217]
===
match
---
name: read_namespaced_pod_log [5749,5772]
name: read_namespaced_pod_log [5749,5772]
===
match
---
name: task_id [3131,3138]
name: task_id [3131,3138]
===
match
---
name: e [4522,4523]
name: e [4522,4523]
===
match
---
atom_expr [8280,8304]
atom_expr [8280,8304]
===
match
---
name: hostname [5499,5507]
name: hostname [5499,5507]
===
match
---
operator: = [5735,5736]
operator: = [5735,5736]
===
match
---
name: jinja_context [2657,2670]
name: jinja_context [2657,2670]
===
match
---
expr_stmt [2715,2755]
expr_stmt [2715,2755]
===
match
---
argument [2122,2138]
argument [2122,2138]
===
match
---
name: range [8285,8290]
name: range [8285,8290]
===
match
---
not_test [11005,11034]
not_test [11005,11034]
===
match
---
operator: { [8637,8638]
operator: { [8637,8638]
===
match
---
name: handler [2184,2191]
name: handler [2184,2191]
===
match
---
if_stmt [2617,2959]
if_stmt [2617,2959]
===
match
---
expr_stmt [6900,6945]
expr_stmt [6900,6945]
===
match
---
operator: ** [3014,3016]
operator: ** [3014,3016]
===
match
---
string: """         Template method that contains custom logic of reading         logs given the try_number.          :param ti: task instance record         :param try_number: current try_number to read log from         :param metadata: log metadata,                          can be used for steaming log reading and auto-tailing.         :return: log message as a string and metadata.         """ [3395,3785]
string: """         Template method that contains custom logic of reading         logs given the try_number.          :param ti: task instance record         :param try_number: current try_number to read log from         :param metadata: log metadata,                          can be used for steaming log reading and auto-tailing.         :return: log message as a string and metadata.         """ [3395,3785]
===
match
---
atom_expr [9056,9078]
atom_expr [9056,9078]
===
match
---
name: path [4064,4068]
name: path [4064,4068]
===
match
---
suite [3386,7329]
suite [3386,7329]
===
match
---
operator: = [2743,2744]
operator: = [2743,2744]
===
match
---
trailer [4073,4109]
trailer [4073,4109]
===
match
---
trailer [2183,2191]
trailer [2183,2191]
===
match
---
operator: = [9014,9015]
operator: = [9014,9015]
===
match
---
trailer [1651,1659]
trailer [1651,1659]
===
match
---
operator: } [6270,6271]
operator: } [6270,6271]
===
match
---
name: ti [2547,2549]
name: ti [2547,2549]
===
match
---
name: len [5492,5495]
name: len [5492,5495]
===
match
---
argument [10978,10991]
argument [10978,10991]
===
match
---
arglist [5162,5187]
arglist [5162,5187]
===
match
---
operator: < [8329,8330]
operator: < [8329,8330]
===
match
---
trailer [3130,3138]
trailer [3130,3138]
===
match
---
operator: , [5877,5878]
operator: , [5877,5878]
===
match
---
suite [7207,7287]
suite [7207,7287]
===
match
---
argument [3090,3106]
argument [3090,3106]
===
match
---
trailer [6414,6520]
trailer [6414,6520]
===
match
---
simple_stmt [9136,9164]
simple_stmt [9136,9164]
===
match
---
suite [4182,4348]
suite [4182,4348]
===
match
---
operator: } [4524,4525]
operator: } [4524,4525]
===
match
---
operator: = [1660,1661]
operator: = [1660,1661]
===
match
---
simple_stmt [8544,8571]
simple_stmt [8544,8571]
===
match
---
param [1559,1564]
param [1559,1564]
===
match
---
string: 'utf-8' [2131,2138]
string: 'utf-8' [2131,2138]
===
match
---
operator: = [7374,7375]
operator: = [7374,7375]
===
match
---
name: execution_date [2867,2881]
name: execution_date [2867,2881]
===
match
---
simple_stmt [1756,1852]
simple_stmt [1756,1852]
===
match
---
fstring_start: f" [4511,4513]
fstring_start: f" [4511,4513]
===
match
---
expr_stmt [9006,9085]
expr_stmt [9006,9085]
===
match
---
name: file [4222,4226]
name: file [4222,4226]
===
match
---
number: 0o666 [11167,11172]
number: 0o666 [11188,11193]
===
match
---
operator: , [7379,7380]
operator: , [7379,7380]
===
match
---
name: str [1606,1609]
name: str [1606,1609]
===
match
---
name: f [6282,6283]
name: f [6282,6283]
===
match
---
operator: , [6387,6388]
operator: , [6387,6388]
===
match
---
name: local_base [10491,10501]
name: local_base [10491,10501]
===
match
---
operator: += [6212,6214]
operator: += [6212,6214]
===
match
---
operator: >= [4816,4818]
operator: >= [4816,4818]
===
match
---
atom_expr [5428,5440]
atom_expr [5428,5440]
===
match
---
import_name [825,839]
import_name [825,839]
===
match
---
name: ti [5799,5801]
name: ti [5799,5801]
===
match
---
testlist [7303,7328]
testlist [7303,7328]
===
match
---
operator: , [5985,5986]
operator: , [5985,5986]
===
match
---
operator: , [2630,2631]
operator: , [2630,2631]
===
match
---
name: local_base [1719,1729]
name: local_base [1719,1729]
===
match
---
name: requests [6911,6919]
name: requests [6911,6919]
===
match
---
operator: = [8585,8586]
operator: = [8585,8586]
===
match
---
operator: = [6023,6024]
operator: = [6023,6024]
===
match
---
atom_expr [2179,2220]
atom_expr [2179,2220]
===
match
---
string: 'end_of_log' [8497,8509]
string: 'end_of_log' [8497,8509]
===
match
---
trailer [7279,7282]
trailer [7279,7282]
===
match
---
operator: , [1877,1878]
operator: , [1877,1878]
===
match
---
name: line [6070,6074]
name: line [6070,6074]
===
match
---
name: log [6103,6106]
name: log [6103,6106]
===
match
---
atom_expr [1620,1638]
atom_expr [1620,1638]
===
match
---
trailer [4154,4164]
trailer [4154,4164]
===
match
---
name: self [2370,2374]
name: self [2370,2374]
===
match
---
string: 'base' [5909,5915]
string: 'base' [5909,5915]
===
match
---
name: models [1091,1097]
name: models [1091,1097]
===
match
---
operator: { [6258,6259]
operator: { [6258,6259]
===
match
---
simple_stmt [4315,4348]
simple_stmt [4315,4348]
===
match
---
string: """         Create log directory and give it correct permissions.          :param ti: task instance object         :return: relative log path of the given task instance         """ [9203,9383]
string: """         Create log directory and give it correct permissions.          :param ti: task instance object         :return: relative log path of the given task instance         """ [9203,9383]
===
match
---
operator: = [10536,10537]
operator: = [10536,10537]
===
match
---
name: handler [2473,2480]
name: handler [2473,2480]
===
match
---
atom_expr [4140,4164]
atom_expr [4140,4164]
===
match
---
operator: = [8222,8223]
operator: = [8222,8223]
===
match
---
operator: = [10410,10411]
operator: = [10410,10411]
===
match
---
fstring_string: *** Unable to fetch logs from worker pod  [6217,6258]
fstring_string: *** Unable to fetch logs from worker pod  [6217,6258]
===
match
---
number: 1 [8291,8292]
number: 1 [8291,8292]
===
match
---
name: level [2256,2261]
name: level [2256,2261]
===
match
---
name: flush [2364,2369]
name: flush [2364,2369]
===
match
---
name: metadata [8795,8803]
name: metadata [8795,8803]
===
match
---
name: configuration [949,962]
name: configuration [949,962]
===
match
---
trailer [2333,2341]
trailer [2333,2341]
===
match
---
operator: } [6629,6630]
operator: } [6629,6630]
===
match
---
name: pod_list [5299,5307]
name: pod_list [5299,5307]
===
match
---
atom_expr [5492,5508]
atom_expr [5492,5508]
===
match
---
atom_expr [10412,10452]
atom_expr [10412,10452]
===
match
---
atom_expr [3167,3196]
atom_expr [3167,3196]
===
match
---
name: self [1873,1877]
name: self [1873,1877]
===
match
---
fstring_start: f" [4437,4439]
fstring_start: f" [4437,4439]
===
match
---
simple_stmt [4504,4529]
simple_stmt [4504,4529]
===
match
---
trailer [4776,4778]
trailer [4776,4778]
===
match
---
operator: = [5119,5120]
operator: = [5119,5120]
===
match
---
atom_expr [10438,10451]
atom_expr [10438,10451]
===
match
---
test [9016,9085]
test [9016,9085]
===
match
---
name: hostname [9070,9078]
name: hostname [9070,9078]
===
match
---
name: ti [2673,2675]
name: ti [2673,2675]
===
match
---
name: log [7303,7306]
name: log [7303,7306]
===
match
---
trailer [2052,2063]
trailer [2052,2063]
===
match
---
name: formatter [2156,2165]
name: formatter [2156,2165]
===
match
---
name: TYPE_CHECKING [894,907]
name: TYPE_CHECKING [894,907]
===
match
---
fstring_end: " [4486,4487]
fstring_end: " [4486,4487]
===
match
---
string: 'ti' [2828,2832]
string: 'ti' [2828,2832]
===
match
---
trailer [10553,10564]
trailer [10553,10564]
===
match
---
name: try_numbers [8544,8555]
name: try_numbers [8544,8555]
===
match
---
param [2277,2282]
param [2277,2282]
===
match
---
param [7364,7380]
param [7364,7380]
===
match
---
expr_stmt [5210,5404]
expr_stmt [5210,5404]
===
match
---
trailer [2426,2432]
trailer [2426,2432]
===
match
---
fstring [4511,4528]
fstring [4511,4528]
===
match
---
simple_stmt [10930,10993]
simple_stmt [10930,10993]
===
match
---
name: ti [2834,2836]
name: ti [2834,2836]
===
match
---
trailer [5801,5810]
trailer [5801,5810]
===
match
---
name: TaskInstance [1105,1117]
name: TaskInstance [1105,1117]
===
match
---
for_stmt [8668,9127]
for_stmt [8668,9127]
===
match
---
with_stmt [4199,4348]
with_stmt [4199,4348]
===
match
---
atom_expr [8594,8610]
atom_expr [8594,8610]
===
match
---
testlist [9143,9163]
testlist [9143,9163]
===
match
---
atom [2806,2958]
atom [2806,2958]
===
match
---
name: get_kube_client [4714,4729]
name: get_kube_client [4714,4729]
===
match
---
string: 'WORKER_LOG_SERVER_PORT' [6481,6505]
string: 'WORKER_LOG_SERVER_PORT' [6481,6505]
===
match
---
name: ti [2864,2866]
name: ti [2864,2866]
===
match
---
suite [2773,2959]
suite [2773,2959]
===
match
---
param [9190,9192]
param [9190,9192]
===
match
---
name: metadata [7381,7389]
name: metadata [7381,7389]
===
match
---
trailer [8706,8719]
trailer [8706,8719]
===
match
---
atom_expr [6259,6270]
atom_expr [6259,6270]
===
match
---
simple_stmt [1714,1748]
simple_stmt [1714,1748]
===
match
---
suite [2481,2515]
suite [2481,2515]
===
match
---
atom_expr [2251,2261]
atom_expr [2251,2261]
===
match
---
operator: = [2130,2131]
operator: = [2130,2131]
===
match
---
trailer [4334,4344]
trailer [4334,4344]
===
match
---
operator: , [11165,11166]
operator: , [11186,11187]
===
match
---
name: base_log_folder [1732,1747]
name: base_log_folder [1732,1747]
===
match
---
simple_stmt [11048,11077]
simple_stmt [11048,11077]
===
match
---
string: """         Read logs of given task instance from local machine.          :param task_instance: task instance object         :param try_number: task instance try_number to read logs from. If None                            it returns all logs separated by try_number         :param metadata: log metadata,                          can be used for steaming log reading and auto-tailing.         :return: a list of listed tuples which order log string by host         """ [7405,7874]
string: """         Read logs of given task instance from local machine.          :param task_instance: task instance object         :param try_number: task instance try_number to read logs from. If None                            it returns all logs separated by try_number         :param metadata: log metadata,                          can be used for steaming log reading and auto-tailing.         :return: a list of listed tuples which order log string by host         """ [7405,7874]
===
match
---
trailer [5850,5877]
trailer [5850,5877]
===
match
---
trailer [10545,10553]
trailer [10545,10553]
===
match
---
fstring_expr [6625,6630]
fstring_expr [6625,6630]
===
match
---
param [2551,2561]
param [2551,2561]
===
match
---
name: ti [6259,6261]
name: ti [6259,6261]
===
match
---
param [1565,1586]
param [1565,1586]
===
match
---
name: full_path [11156,11165]
name: full_path [11177,11186]
===
match
---
simple_stmt [3984,4042]
simple_stmt [3984,4042]
===
match
---
atom_expr [5478,5488]
atom_expr [5478,5488]
===
match
---
name: get_kube_client [4761,4776]
name: get_kube_client [4761,4776]
===
match
---
name: Path [10930,10934]
name: Path [10930,10934]
===
match
---
if_stmt [2385,2435]
if_stmt [2385,2435]
===
match
---
operator: += [4252,4254]
operator: += [4252,4254]
===
match
---
trailer [8753,8759]
trailer [8753,8759]
===
match
---
operator: += [6601,6603]
operator: += [6601,6603]
===
match
---
name: follow [5937,5943]
name: follow [5937,5943]
===
match
---
expr_stmt [6667,6681]
expr_stmt [6667,6681]
===
match
---
trailer [2209,2219]
trailer [2209,2219]
===
match
---
fstring_string:  ***\n [6271,6277]
fstring_string:  ***\n [6271,6277]
===
match
---
operator: , [10962,10963]
operator: , [10962,10963]
===
match
---
operator: { [6571,6572]
operator: { [6571,6572]
===
match
---
name: isoformat [2882,2891]
name: isoformat [2882,2891]
===
match
---
name: matches [5552,5559]
name: matches [5552,5559]
===
match
---
name: setFormatter [2192,2204]
name: setFormatter [2192,2204]
===
match
---
simple_stmt [4747,4779]
simple_stmt [4747,4779]
===
match
---
atom_expr [2494,2514]
atom_expr [2494,2514]
===
match
---
name: path [10541,10545]
name: path [10541,10545]
===
match
---
simple_stmt [6962,6990]
simple_stmt [6962,6990]
===
match
---
param [2541,2546]
param [2541,2546]
===
match
---
atom_expr [4761,4778]
atom_expr [4761,4778]
===
match
---
name: local_base [4079,4089]
name: local_base [4079,4089]
===
match
---
number: 100 [5982,5985]
number: 100 [5982,5985]
===
match
---
name: timeout [6937,6944]
name: timeout [6937,6944]
===
match
---
arglist [4551,4569]
arglist [4551,4569]
===
match
---
trailer [2392,2400]
trailer [2392,2400]
===
match
---
import_from [1078,1117]
import_from [1078,1117]
===
match
---
fstring_start: f" [6540,6542]
fstring_start: f" [6540,6542]
===
match
---
atom_expr [1811,1851]
atom_expr [1811,1851]
===
match
---
trailer [11011,11016]
trailer [11011,11016]
===
match
---
operator: , [3334,3335]
operator: , [3334,3335]
===
match
---
simple_stmt [999,1055]
simple_stmt [999,1055]
===
match
---
name: self [1647,1651]
name: self [1647,1651]
===
match
---
name: task_id [3120,3127]
name: task_id [3120,3127]
===
match
---
atom_expr [4204,4218]
atom_expr [4204,4218]
===
match
---
trailer [5372,5381]
trailer [5372,5381]
===
match
---
operator: += [5584,5586]
operator: += [5584,5586]
===
match
---
atom_expr [10538,10564]
atom_expr [10538,10564]
===
match
---
suite [2291,2355]
suite [2291,2355]
===
match
---
name: str [7276,7279]
name: str [7276,7279]
===
match
---
atom_expr [2620,2639]
atom_expr [2620,2639]
===
match
---
trailer [4344,4346]
trailer [4344,4346]
===
match
---
funcdef [2440,2515]
funcdef [2440,2515]
===
match
---
simple_stmt [936,999]
simple_stmt [936,999]
===
match
---
arglist [2111,2138]
arglist [2111,2138]
===
match
---
trailer [6751,6758]
trailer [6751,6758]
===
match
---
name: local_loc [2036,2045]
name: local_loc [2036,2045]
===
match
---
testlist_star_expr [1756,1808]
testlist_star_expr [1756,1808]
===
match
---
operator: { [8496,8497]
operator: { [8496,8497]
===
match
---
atom [6820,6856]
atom [6820,6856]
===
match
---
trailer [9112,9115]
trailer [9112,9115]
===
match
---
name: kube_client [5121,5132]
name: kube_client [5121,5132]
===
match
---
operator: = [3127,3128]
operator: = [3127,3128]
===
match
---
name: location [4050,4058]
name: location [4050,4058]
===
match
---
funcdef [9169,11200]
funcdef [9169,11331]
===
match
---
atom_expr [5842,5877]
atom_expr [5842,5877]
===
match
---
name: format [6408,6414]
name: format [6408,6414]
===
match
---
name: tail_lines [5971,5981]
name: tail_lines [5971,5981]
===
match
---
operator: = [6936,6937]
operator: = [6936,6937]
===
match
---
fstring_string: *** Failed to load local log file:  [4439,4474]
fstring_string: *** Failed to load local log file:  [4439,4474]
===
match
---
atom_expr [3047,3242]
atom_expr [3047,3242]
===
match
---
fstring_expr [6258,6271]
fstring_expr [6258,6271]
===
match
---
operator: } [8515,8516]
operator: } [8515,8516]
===
match
---
simple_stmt [2179,2221]
simple_stmt [2179,2221]
===
match
---
name: len [8643,8646]
name: len [8643,8646]
===
match
---
operator: = [10956,10957]
operator: = [10956,10957]
===
match
---
trailer [1784,1808]
trailer [1784,1808]
===
match
---
operator: = [8351,8352]
operator: = [8351,8352]
===
match
---
name: try_numbers [8707,8718]
name: try_numbers [8707,8718]
===
match
---
name: hostname [4806,4814]
name: hostname [4806,4814]
===
match
---
param [3271,3275]
param [3271,3275]
===
match
---
trailer [10485,10517]
trailer [10485,10517]
===
match
---
trailer [2696,2698]
trailer [2696,2698]
===
match
---
expr_stmt [8733,8804]
expr_stmt [8733,8804]
===
match
---
trailer [8759,8804]
trailer [8759,8804]
===
match
---
simple_stmt [875,918]
simple_stmt [875,918]
===
match
---
name: exists [11017,11023]
name: exists [11017,11023]
===
match
---
suite [4654,6124]
suite [4654,6124]
===
match
---
atom_expr [2091,2139]
atom_expr [2091,2139]
===
match
---
name: task_instance [8224,8237]
name: task_instance [8224,8237]
===
match
---
suite [8531,8571]
suite [8531,8571]
===
match
---
atom_expr [2468,2480]
atom_expr [2468,2480]
===
match
---
expr_stmt [8580,8610]
expr_stmt [8580,8610]
===
match
---
try_stmt [4650,6291]
try_stmt [4650,6291]
===
match
---
simple_stmt [5580,5714]
simple_stmt [5580,5714]
===
match
---
name: ti [2064,2066]
name: ti [2064,2066]
===
match
---
atom [8587,8591]
atom [8587,8591]
===
match
---
string: 'log_fetch_timeout_sec' [6772,6795]
string: 'log_fetch_timeout_sec' [6772,6795]
===
match
---
name: len [4799,4802]
name: len [4799,4802]
===
match
---
trailer [6970,6979]
trailer [6970,6979]
===
match
---
operator: { [4281,4282]
operator: { [4281,4282]
===
match
---
suite [6191,6291]
suite [6191,6291]
===
match
---
name: logging [832,839]
name: logging [832,839]
===
match
---
name: try_number [8181,8191]
name: try_number [8181,8191]
===
match
---
name: filename_template [1761,1778]
name: filename_template [1761,1778]
===
match
---
atom_expr [5299,5313]
atom_expr [5299,5313]
===
match
---
operator: = [3166,3167]
operator: = [3166,3167]
===
match
---
name: metadata [8738,8746]
name: metadata [8738,8746]
===
match
---
suite [6716,6797]
suite [6716,6797]
===
match
---
argument [5899,5915]
argument [5899,5915]
===
match
---
name: f [6157,6158]
name: f [6157,6158]
===
match
---
import_as_names [970,998]
import_as_names [970,998]
===
match
---
name: task_instance [9056,9069]
name: task_instance [9056,9069]
===
match
---
atom_expr [5121,5189]
atom_expr [5121,5189]
===
match
---
argument [6432,6437]
argument [6432,6437]
===
match
---
operator: = [6434,6435]
operator: = [6434,6435]
===
match
---
atom [9055,9084]
atom [9055,9084]
===
match
---
atom_expr [2076,2088]
atom_expr [2076,2088]
===
match
---
arglist [5794,6030]
arglist [5794,6030]
===
match
---
name: log [6533,6536]
name: log [6533,6536]
===
match
---
argument [3152,3196]
argument [3152,3196]
===
match
---
return_stmt [7296,7328]
return_stmt [7296,7328]
===
match
---
name: next_try [8213,8221]
name: next_try [8213,8221]
===
match
---
name: response [6962,6970]
name: response [6962,6970]
===
match
---
name: self [2179,2183]
name: self [2179,2183]
===
match
---
operator: > [5490,5491]
operator: > [5490,5491]
===
match
---
simple_stmt [2971,3031]
simple_stmt [2971,3031]
===
match
---
atom_expr [9023,9048]
atom_expr [9023,9048]
===
match
---
if_stmt [2465,2515]
if_stmt [2465,2515]
===
match
---
name: filename_jinja_template [2580,2603]
name: filename_jinja_template [2580,2603]
===
match
---
fstring_string: \n [4291,4293]
fstring_string: \n [4291,4293]
===
match
---
return_stmt [11183,11199]
return_stmt [11314,11330]
===
match
---
simple_stmt [919,935]
simple_stmt [919,935]
===
match
---
name: read [7338,7342]
name: read [7338,7342]
===
match
---
simple_stmt [10461,10518]
simple_stmt [10461,10518]
===
match
---
atom [8636,8640]
atom [8636,8640]
===
match
---
expr_stmt [7224,7286]
expr_stmt [7224,7286]
===
match
---
param [2450,2454]
param [2450,2454]
===
match
---
operator: , [5915,5916]
operator: , [5915,5916]
===
match
---
atom_expr [5153,5188]
atom_expr [5153,5188]
===
match
---
name: handler [2234,2241]
name: handler [2234,2241]
===
match
---
string: 'namespace' [5176,5187]
string: 'namespace' [5176,5187]
===
match
---
trailer [5307,5313]
trailer [5307,5313]
===
match
---
name: mode [10952,10956]
name: mode [10952,10956]
===
match
---
suite [4414,4529]
suite [4414,4529]
===
match
---
atom_expr [1142,1157]
atom_expr [1142,1157]
===
match
---
atom_expr [5370,5381]
atom_expr [5370,5381]
===
match
---
name: log [6597,6600]
name: log [6597,6600]
===
match
---
name: Handler [1150,1157]
name: Handler [1150,1157]
===
match
---
name: self [2251,2255]
name: self [2251,2255]
===
match
---
name: try_numbers [8598,8609]
name: try_numbers [8598,8609]
===
match
---
string: 'end_of_log' [7309,7321]
string: 'end_of_log' [7309,7321]
===
match
---
operator: , [8454,8455]
operator: , [8454,8455]
===
match
---
string: 'try_number' [2915,2927]
string: 'try_number' [2915,2927]
===
match
---
operator: , [3196,3197]
operator: , [3196,3197]
===
match
---
import_from [936,998]
import_from [936,998]
===
match
---
operator: = [4759,4760]
operator: = [4759,4760]
===
match
---
import_from [875,917]
import_from [875,917]
===
match
---
atom_expr [1756,1778]
atom_expr [1756,1778]
===
match
---
operator: , [992,993]
operator: , [992,993]
===
match
---
name: log [4315,4318]
name: log [4315,4318]
===
match
---
number: 1 [5444,5445]
number: 1 [5444,5445]
===
match
---
operator: , [3318,3319]
operator: , [3318,3319]
===
match
---
trailer [6466,6470]
trailer [6466,6470]
===
match
---
trailer [11052,11068]
trailer [11052,11068]
===
match
---
operator: } [7282,7283]
operator: } [7282,7283]
===
match
---
argument [3014,3029]
argument [3014,3029]
===
match
---
operator: += [4319,4321]
operator: += [4319,4321]
===
match
---
name: matches [5210,5217]
name: matches [5210,5217]
===
match
---
name: hostname [5541,5549]
name: hostname [5541,5549]
===
match
---
name: location [4155,4163]
name: location [4155,4163]
===
match
---
except_clause [7153,7174]
except_clause [7153,7174]
===
match
---
string: 'default_host' [8373,8387]
string: 'default_host' [8373,8387]
===
match
---
name: self [9184,9188]
name: self [9184,9188]
===
match
---
suite [3277,3299]
suite [3277,3299]
===
match
---
name: self [10412,10416]
name: self [10412,10416]
===
match
---
trailer [2233,2241]
trailer [2233,2241]
===
match
---
operator: , [6927,6928]
operator: , [6927,6928]
===
match
---
parameters [1872,1898]
parameters [1872,1898]
===
match
---
suite [8333,8518]
suite [8333,8518]
===
match
---
trailer [11074,11076]
trailer [11074,11076]
===
match
---
name: conf [994,998]
name: conf [994,998]
===
match
---
fstring [4255,4294]
fstring [4255,4294]
===
match
---
operator: , [3138,3139]
operator: , [3138,3139]
===
match
---
expr_stmt [5110,5189]
expr_stmt [5110,5189]
===
match
---
trailer [5485,5488]
trailer [5485,5488]
===
match
---
name: record [2283,2289]
name: record [2283,2289]
===
match
---
name: conf [5153,5157]
name: conf [5153,5157]
===
match
---
simple_stmt [6878,6883]
simple_stmt [6878,6883]
===
match
---
testlist_comp [8373,8452]
testlist_comp [8373,8452]
===
match
---
suite [2166,2221]
suite [2166,2221]
===
match
---
name: self [8749,8753]
name: self [8749,8753]
===
match
---
name: requests [926,934]
name: requests [926,934]
===
match
---
name: logs [8346,8350]
name: logs [8346,8350]
===
match
---
name: len [5474,5477]
name: len [5474,5477]
===
match
---
trailer [2506,2512]
trailer [2506,2512]
===
match
---
name: ti [5370,5372]
name: ti [5370,5372]
===
match
---
name: TYPE_CHECKING [1059,1072]
name: TYPE_CHECKING [1059,1072]
===
match
---
name: super [1620,1625]
name: super [1620,1625]
===
match
---
atom_expr [2575,2603]
atom_expr [2575,2603]
===
match
---
fstring_end: ' [8451,8452]
fstring_end: ' [8451,8452]
===
match
---
operator: , [4089,4090]
operator: , [4089,4090]
===
match
---
fstring_string: Error fetching the logs. Try number  [8391,8427]
fstring_string: Error fetching the logs. Try number  [8391,8427]
===
match
---
operator: = [5550,5551]
operator: = [5550,5551]
===
match
---
trailer [4025,4041]
trailer [4025,4041]
===
match
---
name: os [10473,10475]
name: os [10473,10475]
===
match
---
simple_stmt [4431,4488]
simple_stmt [4431,4488]
===
match
---
name: emit [2342,2346]
name: emit [2342,2346]
===
match
---
name: ti [3320,3322]
name: ti [3320,3322]
===
match
---
arglist [4074,4108]
arglist [4074,4108]
===
match
---
expr_stmt [5580,5713]
expr_stmt [5580,5713]
===
match
---
name: list [8280,8284]
name: list [8280,8284]
===
match
---
fstring_string:  is invalid. [8439,8451]
fstring_string:  is invalid. [8439,8451]
===
match
---
fstring_end: " [6632,6633]
fstring_end: " [6632,6633]
===
match
---
simple_stmt [8346,8470]
simple_stmt [8346,8470]
===
match
---
simple_stmt [5110,5190]
simple_stmt [5110,5190]
===
match
---
trailer [5772,6048]
trailer [5772,6048]
===
match
---
atom_expr [7276,7282]
atom_expr [7276,7282]
===
match
---
atom_expr [5684,5695]
atom_expr [5684,5695]
===
match
---
operator: , [5949,5950]
operator: , [5949,5950]
===
match
---
classdef [1120,11200]
classdef [1120,11331]
===
insert-tree
---
simple_stmt [787,825]
    string: """File logging handler for tasks.""" [787,824]
to
file_input [787,11200]
at 0
===
insert-node
---
name: FileTaskHandler [1126,1141]
to
classdef [1120,11200]
at 0
===
insert-tree
---
simple_stmt [1164,1541]
    string: """     FileTaskHandler is a python log handler that handles and reads     task instance logs. It creates and delegates log handling     to `logging.FileHandler` after receiving task instance context.     It reads logs from task instance's host machine.      :param base_log_folder: Base log folder to place logs.     :param filename_template: template filename string     """ [1164,1540]
to
suite [1159,11200]
at 0
===
insert-node
---
try_stmt [11147,11305]
to
suite [11035,11174]
at 1
===
insert-node
---
suite [11151,11195]
to
try_stmt [11147,11305]
at 0
===
move-tree
---
simple_stmt [11147,11174]
    atom_expr [11147,11173]
        name: os [11147,11149]
        trailer [11149,11155]
            name: chmod [11150,11155]
        trailer [11155,11173]
            arglist [11156,11172]
                name: full_path [11156,11165]
                operator: , [11165,11166]
                number: 0o666 [11167,11172]
to
suite [11151,11195]
at 0
===
delete-tree
---
simple_stmt [787,825]
    string: """File logging handler for tasks.""" [787,824]
===
delete-node
---
name: FileTaskHandler [1126,1141]
===
===
delete-tree
---
simple_stmt [1164,1541]
    string: """     FileTaskHandler is a python log handler that handles and reads     task instance logs. It creates and delegates log handling     to `logging.FileHandler` after receiving task instance context.     It reads logs from task instance's host machine.      :param base_log_folder: Base log folder to place logs.     :param filename_template: template filename string     """ [1164,1540]
