===
match
---
operator: , [10313,10314]
operator: , [11179,11180]
===
match
---
operator: = [6121,6122]
operator: = [6121,6122]
===
match
---
operator: , [10389,10390]
operator: , [11255,11256]
===
match
---
operator: , [10876,10877]
operator: , [11742,11743]
===
match
---
name: event_buffer [10436,10448]
name: event_buffer [11302,11314]
===
match
---
string: '{"kind": "Status", "apiVersion": "v1", "metadata": {}, "status": "Failure", ' [5682,5760]
string: '{"kind": "Status", "apiVersion": "v1", "metadata": {}, "status": "Failure", ' [5682,5760]
===
match
---
string: 'foo' [13033,13038]
string: 'foo' [13899,13904]
===
match
---
trailer [11045,11064]
trailer [11911,11930]
===
match
---
testlist_comp [6991,7035]
testlist_comp [6991,7035]
===
match
---
number: 1 [3814,3815]
number: 1 [3814,3815]
===
match
---
atom_expr [9315,9339]
atom_expr [10181,10205]
===
match
---
name: models [928,934]
name: models [928,934]
===
match
---
name: patch [11495,11500]
name: patch [12361,12366]
===
match
---
arglist [12017,12062]
arglist [12883,12928]
===
match
---
operator: { [6566,6567]
operator: { [6566,6567]
===
match
---
name: mock_get_kube_client [11731,11751]
name: mock_get_kube_client [12597,12617]
===
match
---
name: status [6084,6090]
name: status [6084,6090]
===
match
---
dotted_name [7940,7950]
dotted_name [7940,7950]
===
match
---
name: mock_stats_gauge [8040,8056]
name: mock_stats_gauge [8040,8056]
===
match
---
name: key [10372,10375]
name: key [11238,11241]
===
match
---
name: mock_api_client [6465,6480]
name: mock_api_client [6465,6480]
===
match
---
trailer [7229,7234]
trailer [7229,7234]
===
match
---
import_name [787,800]
import_name [787,800]
===
match
---
name: datetime [862,870]
name: datetime [862,870]
===
match
---
funcdef [4493,4821]
funcdef [4493,4821]
===
match
---
arglist [8221,8252]
arglist [8221,8252]
===
match
---
name: mock_api_client [6607,6622]
name: mock_api_client [6607,6622]
===
match
---
operator: = [6638,6639]
operator: = [6638,6639]
===
match
---
testlist_comp [2062,2087]
testlist_comp [2062,2087]
===
match
---
simple_stmt [12432,12458]
simple_stmt [13298,13324]
===
match
---
decorator [10638,10707]
decorator [11504,11573]
===
match
---
param [2599,2604]
param [2599,2604]
===
match
---
operator: == [3521,3523]
operator: == [3521,3523]
===
match
---
trailer [5496,5501]
trailer [5496,5501]
===
match
---
atom_expr [12651,12723]
atom_expr [13517,13589]
===
match
---
name: _is_safe_label_value [4197,4217]
name: _is_safe_label_value [4197,4217]
===
match
---
trailer [6349,6395]
trailer [6349,6395]
===
match
---
name: response [6385,6393]
name: response [6385,6393]
===
match
---
import_name [811,824]
import_name [811,824]
===
match
---
operator: @ [2556,2557]
operator: @ [2556,2557]
===
match
---
name: delete_worker_pods [10122,10140]
name: delete_worker_pods [10988,11006]
===
match
---
string: 'airflow.executors.kubernetes_executor.get_kube_client' [12218,12273]
string: 'airflow.executors.kubernetes_executor.get_kube_client' [13084,13139]
===
match
---
name: _is_safe_label_value [4067,4087]
name: _is_safe_label_value [4067,4087]
===
match
---
name: mock [6335,6339]
name: mock [6335,6339]
===
match
---
string: 'test-namespace' [12046,12062]
string: 'test-namespace' [12912,12928]
===
match
---
operator: = [4701,4702]
operator: = [4701,4702]
===
match
---
simple_stmt [11236,11300]
simple_stmt [12102,12166]
===
match
---
operator: @ [9673,9674]
operator: @ [10539,10540]
===
match
---
expr_stmt [6210,6285]
expr_stmt [6210,6285]
===
match
---
trailer [1773,1779]
trailer [1773,1779]
===
match
---
trailer [1872,1877]
trailer [1872,1877]
===
match
---
name: re [2710,2712]
name: re [2710,2712]
===
match
---
expr_stmt [10981,11016]
expr_stmt [11847,11882]
===
match
---
simple_stmt [13789,13862]
simple_stmt [14655,14728]
===
match
---
simple_stmt [6465,6500]
simple_stmt [6465,6500]
===
match
---
operator: , [7116,7117]
operator: , [7116,7117]
===
match
---
atom [2102,2139]
atom [2102,2139]
===
match
---
return_stmt [2460,2550]
return_stmt [2460,2550]
===
match
---
name: kubernetes_executor [9320,9339]
name: kubernetes_executor [10186,10205]
===
match
---
string: "deserialize_model_dict" [3760,3784]
string: "deserialize_model_dict" [3760,3784]
===
match
---
name: queue [7054,7059]
name: queue [7054,7059]
===
match
---
name: _is_valid_pod_id [2343,2359]
name: _is_valid_pod_id [2343,2359]
===
match
---
atom_expr [5019,5043]
atom_expr [5019,5043]
===
match
---
name: self [12352,12356]
name: self [13218,13222]
===
match
---
operator: , [11189,11190]
operator: , [12055,12056]
===
match
---
operator: } [13594,13595]
operator: } [14460,14461]
===
match
---
name: AirflowKubernetesScheduler [5135,5161]
name: AirflowKubernetesScheduler [5135,5161]
===
match
---
operator: @ [3163,3164]
operator: @ [3163,3164]
===
match
---
name: new_datetime_obj [4804,4820]
name: new_datetime_obj [4804,4820]
===
match
---
atom_expr [9552,9581]
atom_expr [10418,10447]
===
match
---
simple_stmt [7661,7707]
simple_stmt [7661,7707]
===
match
---
string: 'airflow.executors.kubernetes_executor.get_kube_client' [13127,13182]
string: 'airflow.executors.kubernetes_executor.get_kube_client' [13993,14048]
===
match
---
simple_stmt [2160,2294]
simple_stmt [2160,2294]
===
match
---
operator: = [13680,13681]
operator: = [14546,14547]
===
match
---
trailer [7345,7356]
trailer [7345,7356]
===
match
---
trailer [11157,11163]
trailer [12023,12029]
===
match
---
operator: = [8125,8126]
operator: = [8125,8126]
===
match
---
name: mock_get_kube_client [10878,10898]
name: mock_get_kube_client [11744,11764]
===
match
---
operator: = [4126,4127]
operator: = [4126,4127]
===
match
---
operator: , [9426,9427]
operator: , [10292,10293]
===
match
---
decorated [3060,3884]
decorated [3060,3884]
===
match
---
name: key [11337,11340]
name: key [12203,12206]
===
match
---
name: utcnow [9394,9400]
name: utcnow [10260,10266]
===
match
---
expr_stmt [3985,4042]
expr_stmt [3985,4042]
===
match
---
string: "my_task_id" [2120,2132]
string: "my_task_id" [2120,2132]
===
match
---
simple_stmt [7417,7475]
simple_stmt [7417,7475]
===
match
---
simple_stmt [9373,9403]
simple_stmt [10239,10269]
===
match
---
string: "my_task_id" [2075,2087]
string: "my_task_id" [2075,2087]
===
match
---
trailer [5079,5099]
trailer [5079,5099]
===
match
---
name: pod_ids [13853,13860]
name: pod_ids [14719,14726]
===
match
---
name: make_safe_label_value [4013,4034]
name: make_safe_label_value [4013,4034]
===
match
---
trailer [3863,3874]
trailer [3863,3874]
===
match
---
simple_stmt [6294,6396]
simple_stmt [6294,6396]
===
match
---
comparison [10427,10472]
comparison [11293,11338]
===
match
---
name: test_time [10315,10324]
name: test_time [11181,11190]
===
match
---
operator: , [12181,12182]
operator: , [13047,13048]
===
match
---
name: string [818,824]
name: string [818,824]
===
match
---
name: TestCase [4861,4869]
name: TestCase [4861,4869]
===
match
---
trailer [8365,8369]
trailer [8365,8369]
===
match
---
param [8645,8672]
param [9511,9538]
===
match
---
string: 'executor.open_slots' [8221,8242]
string: 'executor.open_slots' [8221,8242]
===
match
---
suite [6738,7707]
suite [6738,7707]
===
match
---
name: executor [9304,9312]
name: executor [10170,10178]
===
match
---
atom_expr [1730,1744]
atom_expr [1730,1744]
===
match
---
number: 1 [12787,12788]
number: 1 [13653,13654]
===
match
---
trailer [2913,2915]
trailer [2913,2915]
===
match
---
operator: @ [9824,9825]
operator: @ [10690,10691]
===
match
---
name: FAILED [12118,12124]
name: FAILED [12984,12990]
===
match
---
param [11708,11713]
param [12574,12579]
===
match
---
assert_stmt [13089,13109]
assert_stmt [13955,13975]
===
match
---
name: event_buffer [11324,11336]
name: event_buffer [12190,12202]
===
match
---
string: 'airflow.executors.kubernetes_executor.KubeConfig' [7724,7774]
string: 'airflow.executors.kubernetes_executor.KubeConfig' [7724,7774]
===
match
---
param [11731,11752]
param [12597,12618]
===
match
---
name: executor [11149,11157]
name: executor [12015,12023]
===
match
---
operator: , [13686,13687]
operator: , [14552,14553]
===
match
---
operator: , [12978,12979]
operator: , [13844,13845]
===
match
---
simple_stmt [898,942]
simple_stmt [898,942]
===
match
---
number: 200 [2135,2138]
number: 200 [2135,2138]
===
match
---
name: self [10992,10996]
name: self [11858,11862]
===
match
---
name: tests [1016,1021]
name: tests [1016,1021]
===
match
---
name: executor [10349,10357]
name: executor [11215,11223]
===
match
---
simple_stmt [12341,12377]
simple_stmt [13207,13243]
===
match
---
name: executor [11796,11804]
name: executor [12662,12670]
===
match
---
name: mock_kubernetes_job_watcher [8645,8672]
name: mock_kubernetes_job_watcher [9511,9538]
===
match
---
and_test [2467,2550]
and_test [2467,2550]
===
match
---
comparison [11315,11361]
comparison [12181,12227]
===
match
---
operator: { [13581,13582]
operator: { [14447,14448]
===
match
---
name: kubernetes_executor [10073,10092]
name: kubernetes_executor [10939,10958]
===
match
---
trailer [8741,8743]
trailer [9607,9609]
===
match
---
simple_stmt [3695,3745]
simple_stmt [3695,3745]
===
match
---
name: self [5400,5404]
name: self [5400,5404]
===
match
---
trailer [3969,3971]
trailer [3969,3971]
===
match
---
operator: , [9225,9226]
operator: , [10091,10092]
===
match
---
name: airflow [1310,1317]
name: airflow [1310,1317]
===
match
---
name: self [2188,2192]
name: self [2188,2192]
===
match
---
parameters [1665,1680]
parameters [1665,1680]
===
match
---
expr_stmt [4592,4675]
expr_stmt [4592,4675]
===
match
---
string: 'airflow.executors.kubernetes_executor.AirflowKubernetesScheduler.delete_pod' [11574,11651]
string: 'airflow.executors.kubernetes_executor.AirflowKubernetesScheduler.delete_pod' [12440,12517]
===
match
---
name: k8s [13610,13613]
name: k8s [14476,14479]
===
match
---
name: mock_kubernetes_job_watcher [11753,11780]
name: mock_kubernetes_job_watcher [12619,12646]
===
match
---
name: task_queue [7688,7698]
name: task_queue [7688,7698]
===
match
---
suite [1745,1855]
suite [1745,1855]
===
match
---
param [10861,10877]
param [11727,11743]
===
match
---
import_from [1354,1411]
import_from [1354,1411]
===
match
---
operator: , [12581,12582]
operator: , [13447,13448]
===
match
---
decorated [7712,8431]
decorated [7712,8431]
===
match
---
comparison [12079,12124]
comparison [12945,12990]
===
match
---
trailer [7195,7197]
trailer [7195,7197]
===
match
---
string: 'modified' [12896,12906]
string: 'modified' [13762,13772]
===
match
---
number: 0 [3817,3818]
number: 0 [3817,3818]
===
match
---
number: 0 [3629,3630]
number: 0 [3629,3630]
===
match
---
simple_stmt [2375,2452]
simple_stmt [2375,2452]
===
match
---
string: 'dag' [12918,12923]
string: 'dag' [13784,13789]
===
match
---
operator: = [9415,9416]
operator: = [10281,10282]
===
match
---
simple_stmt [12732,13081]
simple_stmt [13598,13947]
===
match
---
parameters [2863,2869]
parameters [2863,2869]
===
match
---
funcdef [3296,3884]
funcdef [3296,3884]
===
match
---
name: pod_ids [13096,13103]
name: pod_ids [13962,13969]
===
match
---
operator: @ [3060,3061]
operator: @ [3060,3061]
===
match
---
operator: = [6772,6773]
operator: = [6772,6773]
===
match
---
string: 'name' [13025,13031]
string: 'name' [13891,13897]
===
match
---
string: 'airflow.executors.kubernetes_executor.get_kube_client' [10650,10705]
string: 'airflow.executors.kubernetes_executor.get_kube_client' [11516,11571]
===
match
---
simple_stmt [1354,1412]
simple_stmt [1354,1412]
===
match
---
argument [13845,13860]
argument [14711,14726]
===
match
---
name: executor [9348,9356]
name: executor [10214,10222]
===
match
---
atom_expr [3788,3819]
atom_expr [3788,3819]
===
match
---
atom_expr [3695,3744]
atom_expr [3695,3744]
===
match
---
name: dag_id [4480,4486]
name: dag_id [4480,4486]
===
match
---
simple_stmt [6631,6707]
simple_stmt [6631,6707]
===
match
---
atom [7090,7143]
atom [7090,7143]
===
match
---
name: kubernetes_executor [7171,7190]
name: kubernetes_executor [7171,7190]
===
match
---
trailer [10465,10472]
trailer [11331,11338]
===
match
---
funcdef [9191,9668]
funcdef [10057,10534]
===
match
---
simple_stmt [13089,13110]
simple_stmt [13955,13976]
===
match
---
simple_stmt [11308,11362]
simple_stmt [12174,12228]
===
match
---
decorator [2321,2335]
decorator [2321,2335]
===
match
---
name: datetime_to_label_safe_datestring [4628,4661]
name: datetime_to_label_safe_datestring [4628,4661]
===
match
---
name: pod [13840,13843]
name: pod [14706,14709]
===
match
---
atom_expr [5075,5106]
atom_expr [5075,5106]
===
match
---
simple_stmt [871,897]
simple_stmt [871,897]
===
match
---
dotted_name [1359,1391]
dotted_name [1359,1391]
===
match
---
import_name [5466,5476]
import_name [5466,5476]
===
match
---
name: random [794,800]
name: random [794,800]
===
match
---
atom_expr [4569,4583]
atom_expr [4569,4583]
===
match
---
sync_comp_for [2509,2523]
sync_comp_for [2509,2523]
===
match
---
name: State [8842,8847]
name: State [9708,9713]
===
match
---
expr_stmt [10287,10340]
expr_stmt [11153,11206]
===
match
---
parameters [3331,3370]
parameters [3331,3370]
===
match
---
arglist [3077,3157]
arglist [3077,3157]
===
match
---
dotted_name [1421,1440]
dotted_name [1421,1440]
===
match
---
name: mock [10712,10716]
name: mock [11578,11582]
===
match
---
operator: , [13011,13012]
operator: , [13877,13878]
===
match
---
atom_expr [3640,3673]
atom_expr [3640,3673]
===
match
---
operator: , [3726,3727]
operator: , [3726,3727]
===
match
---
operator: , [11262,11263]
operator: , [12128,12129]
===
match
---
atom_expr [6774,6798]
atom_expr [6774,6798]
===
match
---
name: k8s [13642,13645]
name: k8s [14508,14511]
===
match
---
name: kubernetes [1318,1328]
name: kubernetes [1318,1328]
===
match
---
suite [1473,1528]
suite [1473,1528]
===
match
---
trailer [8276,8311]
trailer [8276,8311]
===
match
---
decorated [5118,7707]
decorated [5118,7707]
===
match
---
name: timezone [9385,9393]
name: timezone [10251,10259]
===
match
---
name: safe_dag_id [4088,4099]
name: safe_dag_id [4088,4099]
===
match
---
number: 0 [9579,9580]
number: 0 [10445,10446]
===
match
---
trailer [3874,3877]
trailer [3874,3877]
===
match
---
expr_stmt [5019,5066]
expr_stmt [5019,5066]
===
match
---
name: mock [8302,8306]
name: mock [8302,8306]
===
match
---
dotted_name [13116,13126]
dotted_name [13982,13992]
===
match
---
decorator [9824,9915]
decorator [10690,10781]
===
match
---
decorator [3060,3159]
decorator [3060,3159]
===
match
---
param [9992,10013]
param [10858,10879]
===
match
---
trailer [3549,3552]
trailer [3549,3552]
===
match
---
name: key [11259,11262]
name: key [12125,12128]
===
match
---
name: make_safe_label_value [4458,4479]
name: make_safe_label_value [4458,4479]
===
match
---
trailer [8306,8310]
trailer [8306,8310]
===
match
---
operator: , [7143,7144]
operator: , [7143,7144]
===
match
---
trailer [4217,4231]
trailer [4217,4231]
===
match
---
trailer [4661,4675]
trailer [4661,4675]
===
match
---
trailer [11163,11165]
trailer [12029,12031]
===
match
---
operator: == [4441,4443]
operator: == [4441,4443]
===
match
---
param [8623,8644]
param [9489,9510]
===
match
---
trailer [2494,2500]
trailer [2494,2500]
===
match
---
operator: @ [11562,11563]
operator: @ [12428,12429]
===
match
---
comparison [9552,9598]
comparison [10418,10464]
===
match
---
name: cases [1920,1925]
name: cases [1920,1925]
===
match
---
name: State [11348,11353]
name: State [12214,12219]
===
match
---
expr_stmt [6577,6622]
expr_stmt [6577,6622]
===
match
---
name: test_time [10249,10258]
name: test_time [11115,11124]
===
match
---
name: safe_dag_id [3985,3996]
name: safe_dag_id [3985,3996]
===
match
---
simple_stmt [1416,1454]
simple_stmt [1416,1454]
===
match
---
assert_stmt [4277,4337]
assert_stmt [4277,4337]
===
match
---
operator: = [10953,10954]
operator: = [11819,11820]
===
match
---
trailer [1842,1852]
trailer [1842,1852]
===
match
---
operator: , [2139,2140]
operator: , [2139,2140]
===
match
---
number: 403 [6093,6096]
number: 403 [6093,6096]
===
match
---
name: patch [10644,10649]
name: patch [11510,11515]
===
match
---
string: 'try_number2' [11971,11984]
string: 'try_number2' [12837,12850]
===
match
---
trailer [12148,12172]
trailer [13014,13038]
===
match
---
param [9969,9974]
param [10835,10840]
===
match
---
trailer [2712,2718]
trailer [2712,2718]
===
match
---
name: executor [11907,11915]
name: executor [12773,12781]
===
match
---
name: datetime_obj [4788,4800]
name: datetime_obj [4788,4800]
===
match
---
name: State [10460,10465]
name: State [11326,11331]
===
match
---
expr_stmt [6465,6499]
expr_stmt [6465,6499]
===
match
---
string: 'task_id' [12925,12934]
string: 'task_id' [13791,13800]
===
match
---
atom [9417,9464]
atom [10283,10330]
===
match
---
simple_stmt [2303,2316]
simple_stmt [2303,2316]
===
match
---
term [2120,2138]
term [2120,2138]
===
match
---
name: pod_generator [4294,4307]
name: pod_generator [4294,4307]
===
match
---
argument [13836,13843]
argument [14702,14709]
===
match
---
name: dag_id [4284,4290]
name: dag_id [4284,4290]
===
match
---
name: response [6105,6113]
name: response [6105,6113]
===
match
---
operator: = [5649,5650]
operator: = [5649,5650]
===
match
---
name: len [2689,2692]
name: len [2689,2692]
===
match
---
string: "task" [12611,12617]
string: "task" [13477,13483]
===
match
---
trailer [3962,3969]
trailer [3962,3969]
===
match
---
operator: = [10208,10209]
operator: = [11074,11075]
===
match
---
trailer [7687,7698]
trailer [7687,7698]
===
match
---
atom_expr [6577,6604]
atom_expr [6577,6604]
===
match
---
string: "foo" [13681,13686]
string: "foo" [14547,14552]
===
match
---
suite [5010,5113]
suite [5010,5113]
===
match
---
suite [8107,8431]
suite [8107,8431]
===
match
---
trailer [6968,7158]
trailer [6968,7158]
===
match
---
trailer [11353,11361]
trailer [12219,12227]
===
match
---
trailer [10072,10092]
trailer [10938,10958]
===
match
---
string: 'dag_id' [9418,9426]
string: 'dag_id' [10284,10292]
===
match
---
trailer [12520,12632]
trailer [13386,13498]
===
match
---
string: "foo" [12543,12548]
string: "foo" [13409,13414]
===
match
---
name: mock_kube_client [6294,6310]
name: mock_kube_client [6294,6310]
===
match
---
name: _is_valid_pod_id [3028,3044]
name: _is_valid_pod_id [3028,3044]
===
match
---
name: task_id [4164,4171]
name: task_id [4164,4171]
===
match
---
name: mock_kube_client [6577,6593]
name: mock_kube_client [6577,6593]
===
match
---
name: mock_stats_gauge [8390,8406]
name: mock_stats_gauge [8390,8406]
===
match
---
name: key [12101,12104]
name: key [12967,12970]
===
match
---
atom_expr [10349,10411]
atom_expr [11215,11277]
===
match
---
import_as_names [1180,1294]
import_as_names [1180,1294]
===
match
---
trailer [4307,4329]
trailer [4307,4329]
===
match
---
atom_expr [11907,11923]
atom_expr [12773,12789]
===
match
---
string: 'try_number1' [8791,8804]
string: 'try_number1' [9657,9670]
===
match
---
operator: , [3353,3354]
operator: , [3353,3354]
===
match
---
name: path [5497,5501]
name: path [5497,5501]
===
match
---
trailer [3877,3880]
trailer [3877,3880]
===
match
---
trailer [8329,8334]
trailer [8329,8334]
===
match
---
expr_stmt [1478,1511]
expr_stmt [1478,1511]
===
match
---
name: patch [7786,7791]
name: patch [7786,7791]
===
match
---
trailer [2952,2971]
trailer [2952,2971]
===
match
---
name: mock_calls [3864,3874]
name: mock_calls [3864,3874]
===
match
---
argument [13633,13770]
argument [14499,14636]
===
match
---
name: executor [8116,8124]
name: executor [8116,8124]
===
match
---
trailer [6374,6394]
trailer [6374,6394]
===
match
---
name: kubernetes_executor [1143,1162]
name: kubernetes_executor [1143,1162]
===
match
---
simple_stmt [11907,11924]
simple_stmt [12773,12790]
===
match
---
name: KubernetesExecutor [1216,1234]
name: KubernetesExecutor [1216,1234]
===
match
---
simple_stmt [8189,8382]
simple_stmt [8189,8382]
===
match
---
operator: , [13038,13039]
operator: , [13904,13905]
===
match
---
name: SUCCESS [11354,11361]
name: SUCCESS [12220,12227]
===
match
---
arglist [5135,5215]
arglist [5135,5215]
===
match
---
dotted_name [7713,7723]
dotted_name [7713,7723]
===
match
---
argument [5677,6056]
argument [5677,6056]
===
match
---
simple_stmt [6508,6569]
simple_stmt [6508,6569]
===
match
---
name: make_unique_pod_id [2953,2971]
name: make_unique_pod_id [2953,2971]
===
match
---
suite [4871,13967]
suite [4871,14833]
===
match
---
comparison [4788,4820]
comparison [4788,4820]
===
match
---
name: kubernetes_executor [13496,13515]
name: kubernetes_executor [14362,14381]
===
match
---
name: datetime [4569,4577]
name: datetime [4569,4577]
===
match
---
string: 'dag_id' [12908,12916]
string: 'dag_id' [13774,13782]
===
match
---
name: datetime_obj [4662,4674]
name: datetime_obj [4662,4674]
===
match
---
string: 'task' [12936,12942]
string: 'task' [13802,13808]
===
match
---
trailer [4066,4087]
trailer [4066,4087]
===
match
---
string: "airflow-worker" [12558,12574]
string: "airflow-worker" [13424,13440]
===
match
---
name: calls [8424,8429]
name: calls [8424,8429]
===
match
---
operator: } [12617,12618]
operator: } [13483,13484]
===
match
---
decorator [13115,13184]
decorator [13981,14050]
===
match
---
operator: } [12455,12456]
operator: } [13321,13322]
===
match
---
trailer [4141,4163]
trailer [4141,4163]
===
match
---
name: self [8617,8621]
name: self [9483,9487]
===
match
---
operator: { [12557,12558]
operator: { [13423,13424]
===
match
---
name: _gen_random_string [1647,1665]
name: _gen_random_string [1647,1665]
===
match
---
trailer [9393,9400]
trailer [10259,10266]
===
match
---
param [9266,9293]
param [10132,10159]
===
match
---
operator: { [13963,13964]
operator: { [14829,14830]
===
match
---
simple_stmt [4592,4676]
simple_stmt [4592,4676]
===
match
---
name: TestCase [1610,1618]
name: TestCase [1610,1618]
===
match
---
atom [2024,2047]
atom [2024,2047]
===
match
---
trailer [9506,9514]
trailer [10372,10380]
===
match
---
name: mock [8325,8329]
name: mock [8325,8329]
===
match
---
name: kubernetes_executor [12357,12376]
name: kubernetes_executor [13223,13242]
===
match
---
param [5428,5455]
param [5428,5455]
===
match
---
operator: , [10375,10376]
operator: , [11241,11242]
===
match
---
name: staticmethod [2557,2569]
name: staticmethod [2557,2569]
===
match
---
atom_expr [5651,6066]
atom_expr [5651,6066]
===
match
---
simple_stmt [6105,6135]
simple_stmt [6105,6135]
===
match
---
trailer [12172,12200]
trailer [13038,13066]
===
match
---
name: join [1873,1877]
name: join [1873,1877]
===
match
---
string: 'task_id' [10304,10313]
string: 'task_id' [11170,11179]
===
match
---
name: config [1033,1039]
name: config [1033,1039]
===
match
---
name: mock_trigger_tasks [8058,8076]
name: mock_trigger_tasks [8058,8076]
===
match
---
trailer [13897,13918]
trailer [14763,14784]
===
match
---
trailer [2692,2699]
trailer [2692,2699]
===
match
---
name: http_resp [6375,6384]
name: http_resp [6375,6384]
===
match
---
operator: , [10012,10013]
operator: , [10878,10879]
===
match
---
operator: = [11891,11892]
operator: = [12757,12758]
===
match
---
trailer [2172,2293]
trailer [2172,2293]
===
match
---
simple_stmt [8814,8878]
simple_stmt [9680,9744]
===
match
---
name: V1ObjectMeta [12508,12520]
name: V1ObjectMeta [13374,13386]
===
match
---
name: mock [9674,9678]
name: mock [10540,10544]
===
match
---
name: RUNNING [8848,8855]
name: RUNNING [9714,9721]
===
match
---
parameters [11698,11786]
parameters [12564,12652]
===
match
---
trailer [11811,11831]
trailer [12677,12697]
===
match
---
operator: == [3785,3787]
operator: == [3785,3787]
===
match
---
expr_stmt [6075,6096]
expr_stmt [6075,6096]
===
match
---
name: patch [3234,3239]
name: patch [3234,3239]
===
match
---
simple_stmt [3640,3687]
simple_stmt [3640,3687]
===
match
---
string: 'pod_id' [8857,8865]
string: 'pod_id' [9723,9731]
===
match
---
trailer [9578,9581]
trailer [10444,10447]
===
match
---
name: kubernetes_executor [8699,8718]
name: kubernetes_executor [9565,9584]
===
match
---
simple_stmt [11370,11406]
simple_stmt [12236,12272]
===
match
---
name: State [1448,1453]
name: State [1448,1453]
===
match
---
atom_expr [12022,12034]
atom_expr [12888,12900]
===
match
---
name: self [1905,1909]
name: self [1905,1909]
===
match
---
number: 43 [4423,4425]
number: 43 [4423,4425]
===
match
---
funcdef [5372,7707]
funcdef [5372,7707]
===
match
---
trailer [4329,4337]
trailer [4329,4337]
===
match
---
name: test_time [11202,11211]
name: test_time [12068,12077]
===
match
---
name: HTTPResponse [5651,5663]
name: HTTPResponse [5651,5663]
===
match
---
comparison [12739,13080]
comparison [13605,13946]
===
match
---
decorators [9673,9915]
decorators [10539,10781]
===
match
---
expr_stmt [13571,13595]
expr_stmt [14437,14461]
===
match
---
expr_stmt [10101,10148]
expr_stmt [10967,11014]
===
match
---
suite [2870,3055]
suite [2870,3055]
===
match
---
name: mock_get_kube_client [5406,5426]
name: mock_get_kube_client [5406,5426]
===
match
---
simple_stmt [13571,13596]
simple_stmt [14437,14462]
===
match
---
name: executor [11840,11848]
name: executor [12706,12714]
===
match
---
string: 'airflow.executors.kubernetes_executor.KubernetesJobWatcher' [8448,8508]
string: 'airflow.executors.kubernetes_executor.KubernetesJobWatcher' [9314,9374]
===
match
---
operator: @ [7861,7862]
operator: @ [7861,7862]
===
match
---
operator: @ [9751,9752]
operator: @ [10617,10618]
===
match
---
trailer [3655,3673]
trailer [3655,3673]
===
match
---
operator: , [8865,8866]
operator: , [9731,9732]
===
match
---
arglist [3451,3479]
arglist [3451,3479]
===
match
---
name: executor [10427,10435]
name: executor [11293,11301]
===
match
---
name: patch [5227,5232]
name: patch [5227,5232]
===
match
---
number: 63 [2703,2705]
number: 63 [2703,2705]
===
match
---
operator: , [6695,6696]
operator: , [6695,6696]
===
match
---
string: "dag" [13731,13736]
string: "dag" [14597,14602]
===
match
---
name: mock [3229,3233]
name: mock [3229,3233]
===
match
---
atom_expr [10377,10389]
atom_expr [11243,11255]
===
match
---
operator: = [6227,6228]
operator: = [6227,6228]
===
match
---
atom_expr [3999,4042]
atom_expr [3999,4042]
===
match
---
operator: , [8242,8243]
operator: , [8242,8243]
===
match
---
expr_stmt [11840,11897]
expr_stmt [12706,12763]
===
match
---
name: make_safe_label_value [4142,4163]
name: make_safe_label_value [4142,4163]
===
match
---
name: kubernetes_executor [5080,5099]
name: kubernetes_executor [5080,5099]
===
match
---
arglist [2986,3001]
arglist [2986,3001]
===
match
---
assert_stmt [13934,13966]
assert_stmt [14800,14832]
===
match
---
operator: , [13227,13228]
operator: , [14093,14094]
===
match
---
name: mock_delete_pod [11714,11729]
name: mock_delete_pod [12580,12595]
===
match
---
simple_stmt [10981,11017]
simple_stmt [11847,11883]
===
match
---
trailer [6954,6968]
trailer [6954,6968]
===
match
---
expr_stmt [5486,5563]
expr_stmt [5486,5563]
===
match
---
name: unittest [832,840]
name: unittest [832,840]
===
match
---
name: TestAirflowKubernetesScheduler [1570,1600]
name: TestAirflowKubernetesScheduler [1570,1600]
===
match
---
name: key [11932,11935]
name: key [12798,12801]
===
match
---
name: test_make_safe_label_value [3893,3919]
name: test_make_safe_label_value [3893,3919]
===
match
---
operator: @ [13115,13116]
operator: @ [13981,13982]
===
match
---
decorators [3060,3292]
decorators [3060,3292]
===
match
---
name: value [2693,2698]
name: value [2693,2698]
===
match
---
dotted_name [1072,1094]
dotted_name [1072,1094]
===
match
---
atom_expr [11149,11165]
atom_expr [12015,12031]
===
match
---
atom_expr [4444,4487]
atom_expr [4444,4487]
===
match
---
operator: == [4291,4293]
operator: == [4291,4293]
===
match
---
atom_expr [13610,13780]
atom_expr [14476,14646]
===
match
---
operator: == [13104,13106]
operator: == [13970,13972]
===
match
---
atom_expr [8694,8718]
atom_expr [9560,9584]
===
match
---
string: 'pod_id' [11279,11287]
string: 'pod_id' [12145,12153]
===
match
---
string: "bar" [12576,12581]
string: "bar" [13442,13447]
===
match
---
dotted_name [10712,10722]
dotted_name [11578,11588]
===
match
---
trailer [7273,7295]
trailer [7273,7295]
===
match
---
name: State [9585,9590]
name: State [10451,10456]
===
match
---
name: patch [13121,13126]
name: patch [13987,13992]
===
match
---
number: 200 [2254,2257]
number: 200 [2254,2257]
===
match
---
trailer [2247,2258]
trailer [2247,2258]
===
match
---
name: reason [6114,6120]
name: reason [6114,6120]
===
match
---
trailer [12755,12776]
trailer [13621,13642]
===
match
---
name: self [12308,12312]
name: self [13174,13178]
===
match
---
operator: , [5426,5427]
operator: , [5426,5427]
===
match
---
term [1770,1791]
term [1770,1791]
===
match
---
string: "task_id" [13738,13747]
string: "task_id" [14604,14613]
===
match
---
name: mock [5222,5226]
name: mock [5222,5226]
===
match
---
expr_stmt [4244,4264]
expr_stmt [4244,4264]
===
match
---
string: "dag" [12593,12598]
string: "dag" [13459,13464]
===
match
---
operator: , [11969,11970]
operator: , [12835,12836]
===
match
---
trailer [11244,11258]
trailer [12110,12124]
===
match
---
atom_expr [6508,6563]
atom_expr [6508,6563]
===
match
---
simple_stmt [8727,8744]
simple_stmt [9593,9610]
===
match
---
name: test_get_base_pod_from_template [3300,3331]
name: test_get_base_pod_from_template [3300,3331]
===
match
---
string: "deserialize_model_dict" [3496,3520]
string: "deserialize_model_dict" [3496,3520]
===
match
---
name: key [10287,10290]
name: key [11153,11156]
===
match
---
name: patch [9102,9107]
name: patch [9968,9973]
===
match
---
string: 'airflow.executors.kubernetes_executor.AirflowKubernetesScheduler.delete_pod' [9108,9185]
string: 'airflow.executors.kubernetes_executor.AirflowKubernetesScheduler.delete_pod' [9974,10051]
===
match
---
comparison [2689,2705]
comparison [2689,2705]
===
match
---
string: 'test-namespace' [12183,12199]
string: 'test-namespace' [13049,13065]
===
match
---
atom_expr [1836,1852]
atom_expr [1836,1852]
===
match
---
name: pod_template_file_path [3571,3593]
name: pod_template_file_path [3571,3593]
===
match
---
suite [5457,7707]
suite [5457,7707]
===
match
---
name: test_adopt_launched_task [12283,12307]
name: test_adopt_launched_task [13149,13173]
===
match
---
trailer [12507,12520]
trailer [13373,13386]
===
match
---
name: AirflowKubernetesScheduler [3077,3103]
name: AirflowKubernetesScheduler [3077,3103]
===
match
---
simple_stmt [11025,11073]
simple_stmt [11891,11939]
===
match
---
name: key [9411,9414]
name: key [10277,10280]
===
match
---
trailer [9362,9364]
trailer [10228,10230]
===
match
---
trailer [2211,2222]
trailer [2211,2222]
===
match
---
atom_expr [2272,2282]
atom_expr [2272,2282]
===
match
---
decorator [3228,3292]
decorator [3228,3292]
===
match
---
argument [6271,6284]
argument [6271,6284]
===
match
---
string: 'airflow.executors.kubernetes_executor.get_kube_client' [9763,9818]
string: 'airflow.executors.kubernetes_executor.get_kube_client' [10629,10684]
===
match
---
operator: @ [9096,9097]
operator: @ [9962,9963]
===
match
---
operator: = [4251,4252]
operator: = [4251,4252]
===
match
---
atom_expr [4852,4869]
atom_expr [4852,4869]
===
match
---
operator: @ [8436,8437]
operator: @ [9302,9303]
===
match
---
name: test_gauge_executor_metrics [8006,8033]
name: test_gauge_executor_metrics [8006,8033]
===
match
---
name: start [8736,8741]
name: start [9602,9607]
===
match
---
operator: , [2724,2725]
operator: , [2724,2725]
===
match
---
param [3355,3369]
param [3355,3369]
===
match
---
trailer [7295,7302]
trailer [7295,7302]
===
match
---
atom_expr [2467,2476]
atom_expr [2467,2476]
===
match
---
string: 'task_id' [11191,11200]
string: 'task_id' [12057,12066]
===
match
---
simple_stmt [8116,8152]
simple_stmt [8116,8152]
===
match
---
trailer [13918,13925]
trailer [14784,14791]
===
match
---
operator: * [4421,4422]
operator: * [4421,4422]
===
match
---
trailer [13658,13770]
trailer [14524,14636]
===
match
---
operator: , [13843,13844]
operator: , [14709,14710]
===
match
---
decorator [5221,5295]
decorator [5221,5295]
===
match
---
string: 'airflow-worker' [12878,12894]
string: 'airflow-worker' [13744,13760]
===
match
---
operator: , [9264,9265]
operator: , [10130,10131]
===
match
---
name: safe_task_id [4218,4230]
name: safe_task_id [4218,4230]
===
match
---
operator: , [10302,10303]
operator: , [11168,11169]
===
match
---
operator: = [2621,2622]
operator: = [2621,2622]
===
match
---
decorator [11411,11485]
decorator [12277,12351]
===
match
---
simple_stmt [1478,1528]
simple_stmt [1478,1528]
===
match
---
operator: , [9524,9525]
operator: , [10390,10391]
===
match
---
trailer [12105,12108]
trailer [12971,12974]
===
match
---
simple_stmt [12651,12724]
simple_stmt [13517,13590]
===
match
---
atom_expr [6935,7158]
atom_expr [6935,7158]
===
match
---
operator: } [13755,13756]
operator: } [14621,14622]
===
match
---
atom_expr [1770,1779]
atom_expr [1770,1779]
===
match
---
dotted_name [1016,1039]
dotted_name [1016,1039]
===
match
---
argument [13676,13686]
argument [14542,14552]
===
match
---
atom_expr [11370,11405]
atom_expr [12236,12271]
===
match
---
atom_expr [4614,4675]
atom_expr [4614,4675]
===
match
---
string: 'tasks' [7102,7109]
string: 'tasks' [7102,7109]
===
match
---
name: value [2599,2604]
name: value [2599,2604]
===
match
---
decorator [7780,7857]
decorator [7780,7857]
===
match
---
atom_expr [12352,12376]
atom_expr [13218,13242]
===
match
---
name: pod_generator [1378,1391]
name: pod_generator [1378,1391]
===
match
---
trailer [3538,3549]
trailer [3538,3549]
===
match
---
string: 'airflow.executors.kubernetes_executor.KubernetesJobWatcher' [11423,11483]
string: 'airflow.executors.kubernetes_executor.KubernetesJobWatcher' [12289,12349]
===
match
---
name: mock [8515,8519]
name: mock [9381,9385]
===
match
---
number: 64 [4380,4382]
number: 64 [4380,4382]
===
match
---
atom_expr [12385,12410]
atom_expr [13251,13276]
===
match
---
name: key [12017,12020]
name: key [12883,12886]
===
match
---
funcdef [2574,2733]
funcdef [2574,2733]
===
match
---
dotted_name [981,994]
dotted_name [981,994]
===
match
---
trailer [11915,11921]
trailer [12781,12787]
===
match
---
suite [3926,4488]
suite [3926,4488]
===
match
---
name: pod_template_file [3656,3673]
name: pod_template_file [3656,3673]
===
match
---
funcdef [1894,2316]
funcdef [1894,2316]
===
match
---
name: airflow [981,988]
name: airflow [981,988]
===
match
---
name: char_seed [1717,1726]
name: char_seed [1717,1726]
===
match
---
param [13229,13245]
param [14095,14111]
===
match
---
trailer [8822,8836]
trailer [9688,9702]
===
match
---
dotted_name [903,920]
dotted_name [903,920]
===
match
---
operator: , [2010,2011]
operator: , [2010,2011]
===
match
---
string: 'ex_time' [8780,8789]
string: 'ex_time' [9646,9655]
===
match
---
operator: , [9242,9243]
operator: , [10108,10109]
===
match
---
atom_expr [2224,2258]
atom_expr [2224,2258]
===
match
---
trailer [8168,8178]
trailer [8168,8178]
===
match
---
atom_expr [10101,10140]
atom_expr [10967,11006]
===
match
---
name: SUCCESS [9507,9514]
name: SUCCESS [10373,10380]
===
match
---
testlist_comp [9418,9463]
testlist_comp [10284,10329]
===
match
---
atom_expr [1870,1888]
atom_expr [1870,1888]
===
match
---
name: unittest [876,884]
name: unittest [876,884]
===
match
---
name: _change_state [12003,12016]
name: _change_state [12869,12882]
===
match
---
atom_expr [6483,6499]
atom_expr [6483,6499]
===
match
---
decorated [10560,11406]
decorated [11426,12272]
===
match
---
trailer [6233,6239]
trailer [6233,6239]
===
match
---
operator: @ [8514,8515]
operator: @ [9380,9381]
===
match
---
operator: == [13949,13951]
operator: == [14815,14817]
===
match
---
operator: = [5491,5492]
operator: = [5491,5492]
===
match
---
param [9244,9265]
param [10110,10131]
===
match
---
simple_stmt [1011,1057]
simple_stmt [1011,1057]
===
match
---
name: mock [10561,10565]
name: mock [11427,11431]
===
match
---
trailer [4750,4771]
trailer [4750,4771]
===
match
---
name: safe_task_id [4113,4125]
name: safe_task_id [4113,4125]
===
match
---
suite [1911,2316]
suite [1911,2316]
===
match
---
name: return_value [6551,6563]
name: return_value [6551,6563]
===
match
---
simple_stmt [3753,3820]
simple_stmt [3753,3820]
===
match
---
trailer [5663,6066]
trailer [5663,6066]
===
match
---
name: pod_name [3045,3053]
name: pod_name [3045,3053]
===
match
---
name: pod [13604,13607]
name: pod [14470,14473]
===
match
---
name: mock [7862,7866]
name: mock [7862,7866]
===
match
---
name: mock_kubernetes_job_watcher [10900,10927]
name: mock_kubernetes_job_watcher [11766,11793]
===
match
---
atom [8758,8805]
atom [9624,9671]
===
match
---
atom_expr [8814,8877]
atom_expr [9680,9743]
===
match
---
name: executor [11236,11244]
name: executor [12102,12110]
===
match
---
operator: , [8789,8790]
operator: , [9655,9656]
===
match
---
trailer [11921,11923]
trailer [12787,12789]
===
match
---
atom_expr [10261,10278]
atom_expr [11127,11144]
===
match
---
name: timezone [1002,1010]
name: timezone [1002,1010]
===
match
---
string: "5" [5109,5112]
string: "5" [5109,5112]
===
match
---
name: mock [11412,11416]
name: mock [12278,12282]
===
match
---
name: kubernetes_executor [7557,7576]
name: kubernetes_executor [7557,7576]
===
match
---
name: AirflowKubernetesScheduler [1180,1206]
name: AirflowKubernetesScheduler [1180,1206]
===
match
---
simple_stmt [825,841]
simple_stmt [825,841]
===
match
---
testlist_comp [8211,8371]
testlist_comp [8211,8371]
===
match
---
name: executor [10981,10989]
name: executor [11847,11855]
===
match
---
simple_stmt [5640,6067]
simple_stmt [5640,6067]
===
match
---
decorator [2556,2570]
decorator [2556,2570]
===
match
---
trailer [2537,2550]
trailer [2537,2550]
===
match
---
string: "/foo/bar" [3676,3686]
string: "/foo/bar" [3676,3686]
===
match
---
string: 'airflow.executors.kubernetes_executor.get_kube_client' [5311,5366]
string: 'airflow.executors.kubernetes_executor.get_kube_client' [5311,5366]
===
match
---
comparison [3077,3111]
comparison [3077,3111]
===
match
---
trailer [8248,8252]
trailer [8248,8252]
===
match
---
arglist [11259,11298]
arglist [12125,12164]
===
match
---
name: pod_ids [13571,13578]
name: pod_ids [14437,14444]
===
match
---
name: MagicMock [6488,6497]
name: MagicMock [6488,6497]
===
match
---
dotted_name [3164,3174]
dotted_name [3164,3174]
===
match
---
name: utcnow [10270,10276]
name: utcnow [11136,11142]
===
match
---
name: executor [8160,8168]
name: executor [8160,8168]
===
match
---
name: self [4996,5000]
name: self [4996,5000]
===
match
---
string: 'run' [7111,7116]
string: 'run' [7111,7116]
===
match
---
operator: , [8855,8856]
operator: , [9721,9722]
===
match
---
expr_stmt [1920,2150]
expr_stmt [1920,2150]
===
match
---
name: char_seed [1782,1791]
name: char_seed [1782,1791]
===
match
---
atom_expr [13881,13925]
atom_expr [14747,14791]
===
match
---
name: self [2224,2228]
name: self [2224,2228]
===
match
---
name: key [11174,11177]
name: key [12040,12043]
===
match
---
name: patch [8520,8525]
name: patch [9386,9391]
===
match
---
operator: = [6279,6280]
operator: = [6279,6280]
===
match
---
operator: , [2789,2790]
operator: , [2789,2790]
===
match
---
arglist [6986,7144]
arglist [6986,7144]
===
match
---
name: mock [8361,8365]
name: mock [8361,8365]
===
match
---
expr_stmt [9304,9339]
expr_stmt [10170,10205]
===
match
---
simple_stmt [3016,3055]
simple_stmt [3016,3055]
===
match
---
parameters [8616,8673]
parameters [9482,9539]
===
match
---
operator: = [13839,13840]
operator: = [14705,14706]
===
match
---
name: new_datetime_obj [4684,4700]
name: new_datetime_obj [4684,4700]
===
match
---
operator: , [9973,9974]
operator: , [10839,10840]
===
match
---
name: ch [2513,2515]
name: ch [2513,2515]
===
match
---
operator: , [13736,13737]
operator: , [14602,14603]
===
match
---
name: mock_get_kube_client [8623,8643]
name: mock_get_kube_client [9489,9509]
===
match
---
atom_expr [9348,9364]
atom_expr [10214,10230]
===
match
---
name: called [7296,7302]
name: called [7296,7302]
===
match
---
operator: @ [8945,8946]
operator: @ [9811,9812]
===
match
---
arglist [2719,2731]
arglist [2719,2731]
===
match
---
trailer [11385,11403]
trailer [12251,12269]
===
match
---
name: autospec [6271,6279]
name: autospec [6271,6279]
===
match
---
decorators [11411,11653]
decorators [12277,12519]
===
match
---
operator: , [11287,11288]
operator: , [12153,12154]
===
match
---
suite [9295,9668]
suite [10161,10534]
===
match
---
simple_stmt [6210,6286]
simple_stmt [6210,6286]
===
match
---
trailer [10276,10278]
trailer [11142,11144]
===
match
---
name: executor [8893,8901]
name: executor [9759,9767]
===
match
---
name: patch [9830,9835]
name: patch [10696,10701]
===
match
---
simple_stmt [8683,8719]
simple_stmt [9549,9585]
===
match
---
dotted_name [2739,2754]
dotted_name [2739,2754]
===
match
---
name: empty [7699,7704]
name: empty [7699,7704]
===
match
---
operator: @ [10560,10561]
operator: @ [11426,11427]
===
match
---
name: pod_generator [1336,1349]
name: pod_generator [1336,1349]
===
match
---
assert_stmt [12732,13080]
assert_stmt [13598,13946]
===
match
---
testlist_comp [10294,10339]
testlist_comp [11160,11205]
===
match
---
name: executor [11315,11323]
name: executor [12181,12189]
===
match
---
name: mock [9097,9101]
name: mock [9963,9967]
===
match
---
expr_stmt [2929,3003]
expr_stmt [2929,3003]
===
match
---
parameters [9220,9294]
parameters [10086,10160]
===
match
---
simple_stmt [1067,1115]
simple_stmt [1067,1115]
===
match
---
import_name [801,810]
import_name [801,810]
===
match
---
operator: @ [11411,11412]
operator: @ [12277,12278]
===
match
---
decorator [1625,1639]
decorator [1625,1639]
===
match
---
atom_expr [12472,12642]
atom_expr [13338,13508]
===
match
---
trailer [11860,11890]
trailer [12726,12756]
===
match
---
arglist [8335,8369]
arglist [8335,8369]
===
match
---
trailer [5501,5504]
trailer [5501,5504]
===
match
---
trailer [9622,9646]
trailer [10488,10512]
===
match
---
operator: == [12109,12111]
operator: == [12975,12977]
===
match
---
name: range [1730,1735]
name: range [1730,1735]
===
match
---
operator: , [2073,2074]
operator: , [2073,2074]
===
match
---
operator: , [12044,12045]
operator: , [12910,12911]
===
match
---
name: dag_id [4330,4336]
name: dag_id [4330,4336]
===
match
---
atom_expr [7668,7706]
atom_expr [7668,7706]
===
match
---
operator: = [4612,4613]
operator: = [4612,4613]
===
match
---
simple_stmt [11149,11166]
simple_stmt [12015,12032]
===
match
---
name: mock_kube_client [6440,6456]
name: mock_kube_client [6440,6456]
===
match
---
name: delete_worker_pods [11046,11064]
name: delete_worker_pods [11912,11930]
===
match
---
simple_stmt [6404,6457]
simple_stmt [6404,6457]
===
match
---
name: create_namespaced_pod [7434,7455]
name: create_namespaced_pod [7434,7455]
===
match
---
name: kubernetes_executor [6935,6954]
name: kubernetes_executor [6935,6954]
===
match
---
operator: = [12411,12412]
operator: = [13277,13278]
===
match
---
simple_stmt [10943,10973]
simple_stmt [11809,11839]
===
match
---
name: mock [11490,11494]
name: mock [12356,12360]
===
match
---
string: 'requested: limits.memory=4Gi, used: limits.memory=6508Mi, limited: limits.memory=10Gi", ' [5868,5958]
string: 'requested: limits.memory=4Gi, used: limits.memory=6508Mi, limited: limits.memory=10Gi", ' [5868,5958]
===
match
---
operator: , [7124,7125]
operator: , [7124,7125]
===
match
---
atom_expr [12504,12632]
atom_expr [13370,13498]
===
match
---
trailer [12659,12679]
trailer [13525,13545]
===
match
---
atom_expr [2188,2222]
atom_expr [2188,2222]
===
match
---
string: 'pod_id' [12173,12181]
string: 'pod_id' [13039,13047]
===
match
---
assert_stmt [13870,13925]
assert_stmt [14736,14791]
===
match
---
name: patch [11417,11422]
name: patch [12283,12288]
===
match
---
simple_stmt [841,871]
simple_stmt [841,871]
===
match
---
trailer [2277,2282]
trailer [2277,2282]
===
match
---
atom_expr [12112,12124]
atom_expr [12978,12990]
===
match
---
string: 'pod_id' [10391,10399]
string: 'pod_id' [11257,11265]
===
match
---
name: self [2902,2906]
name: self [2902,2906]
===
match
---
atom_expr [2689,2699]
atom_expr [2689,2699]
===
match
---
name: self [4539,4543]
name: self [4539,4543]
===
match
---
classdef [4823,13967]
classdef [4823,14833]
===
match
---
name: cases [2160,2165]
name: cases [2160,2165]
===
match
---
operator: , [3111,3112]
operator: , [3111,3112]
===
match
---
operator: @ [5118,5119]
operator: @ [5118,5119]
===
match
---
name: extend [2166,2172]
name: extend [2166,2172]
===
match
---
name: executor [13480,13488]
name: executor [14346,14354]
===
match
---
trailer [11848,11860]
trailer [12714,12726]
===
match
---
name: V1Pod [12476,12481]
name: V1Pod [13342,13347]
===
match
---
atom_expr [11081,11131]
atom_expr [11947,11997]
===
match
---
atom_expr [2972,3002]
atom_expr [2972,3002]
===
match
---
operator: , [1206,1207]
operator: , [1206,1207]
===
match
---
operator: , [8311,8312]
operator: , [8311,8312]
===
match
---
decorator [2738,2837]
decorator [2738,2837]
===
match
---
simple_stmt [13934,13967]
simple_stmt [14800,14833]
===
match
---
operator: @ [10638,10639]
operator: @ [11504,11505]
===
match
---
string: 'some_parameter' [7126,7142]
string: 'some_parameter' [7126,7142]
===
match
---
decorator [3163,3224]
decorator [3163,3224]
===
match
---
trailer [5064,5066]
trailer [5064,5066]
===
match
---
string: 'dag_id' [8759,8767]
string: 'dag_id' [9625,9633]
===
match
---
param [13223,13228]
param [14089,14094]
===
match
---
expr_stmt [8116,8151]
expr_stmt [8116,8151]
===
match
---
name: test_time [9439,9448]
name: test_time [10305,10314]
===
match
---
string: "bar" [13714,13719]
string: "bar" [14580,14585]
===
match
---
name: _change_state [8823,8836]
name: _change_state [9689,9702]
===
match
---
name: patch [9679,9684]
name: patch [10545,10550]
===
match
---
atom_expr [11348,11361]
atom_expr [12214,12227]
===
match
---
name: match [2713,2718]
name: match [2713,2718]
===
match
---
trailer [9400,9402]
trailer [10266,10268]
===
match
---
comparison [13096,13109]
comparison [13962,13975]
===
match
---
simple_stmt [7557,7584]
simple_stmt [7557,7584]
===
match
---
expr_stmt [12432,12457]
expr_stmt [13298,13323]
===
match
---
suite [1681,1889]
suite [1681,1889]
===
match
---
argument [12707,12722]
argument [13573,13588]
===
match
---
assert_stmt [10420,10472]
assert_stmt [11286,11338]
===
match
---
name: name [2471,2475]
name: name [2471,2475]
===
match
---
name: mock_calls [3612,3622]
name: mock_calls [3612,3622]
===
match
---
operator: = [5044,5045]
operator: = [5044,5045]
===
match
---
testlist_comp [1943,1968]
testlist_comp [1943,1968]
===
match
---
name: regex [2375,2380]
name: regex [2375,2380]
===
match
---
name: key [8837,8840]
name: key [9703,9706]
===
match
---
trailer [2906,2913]
trailer [2906,2913]
===
match
---
decorator [9023,9092]
decorator [9889,9958]
===
match
---
trailer [13613,13619]
trailer [14479,14485]
===
match
---
name: try_number [6908,6918]
name: try_number [6908,6918]
===
match
---
name: get_base_pod_from_template [3424,3450]
name: get_base_pod_from_template [3424,3450]
===
match
---
name: metadata [13633,13641]
name: metadata [14499,14507]
===
match
---
operator: { [6640,6641]
operator: { [6640,6641]
===
match
---
trailer [3802,3813]
trailer [3802,3813]
===
match
---
param [10900,10927]
param [11766,11793]
===
match
---
name: seed [2248,2252]
name: seed [2248,2252]
===
match
---
name: mock_kube_client [13881,13897]
name: mock_kube_client [14747,14763]
===
match
---
operator: @ [2738,2739]
operator: @ [2738,2739]
===
match
---
name: mock_kube_client [12314,12330]
name: mock_kube_client [13180,13196]
===
match
---
trailer [12475,12481]
trailer [13341,13347]
===
match
---
atom [1702,1704]
atom [1702,1704]
===
match
---
operator: <= [2700,2702]
operator: <= [2700,2702]
===
match
---
operator: , [1293,1294]
operator: , [1293,1294]
===
match
---
comparison [3835,3883]
comparison [3835,3883]
===
match
---
argument [7082,7143]
argument [7082,7143]
===
match
---
operator: = [11065,11066]
operator: = [11931,11932]
===
match
---
trailer [7362,7364]
trailer [7362,7364]
===
match
---
simple_stmt [7596,7649]
simple_stmt [7596,7649]
===
match
---
simple_stmt [1758,1793]
simple_stmt [1758,1793]
===
match
---
name: mock_generator [3788,3802]
name: mock_generator [3788,3802]
===
match
---
name: kube_config [11849,11860]
name: kube_config [12715,12726]
===
match
---
import_from [1011,1056]
import_from [1011,1056]
===
match
---
import_from [1416,1453]
import_from [1416,1453]
===
match
---
suite [13247,13967]
suite [14113,14833]
===
match
---
param [3338,3354]
param [3338,3354]
===
match
---
string: r'^[^a-z0-9A-Z]*|[^a-zA-Z0-9_\-\.]|[^a-z0-9A-Z]*$' [2623,2673]
string: r'^[^a-z0-9A-Z]*|[^a-zA-Z0-9_\-\.]|[^a-z0-9A-Z]*$' [2623,2673]
===
match
---
decorated [2556,2733]
decorated [2556,2733]
===
match
---
name: mock_generator [3524,3538]
name: mock_generator [3524,3538]
===
match
---
name: dag_id [3939,3945]
name: dag_id [3939,3945]
===
match
---
arglist [13676,13756]
arglist [14542,14622]
===
match
---
expr_stmt [5075,5112]
expr_stmt [5075,5112]
===
match
---
atom_expr [6229,6285]
atom_expr [6229,6285]
===
match
---
simple_stmt [4554,4584]
simple_stmt [4554,4584]
===
match
---
name: test_change_state_success [9195,9220]
name: test_change_state_success [10061,10086]
===
match
---
testlist_comp [7091,7142]
testlist_comp [7091,7142]
===
match
---
name: pod_ids [12707,12714]
name: pod_ids [13573,13580]
===
match
---
testlist_comp [2187,2282]
testlist_comp [2187,2282]
===
match
---
name: dag_id [2883,2889]
name: dag_id [2883,2889]
===
match
---
string: 'airflow.executors.kubernetes_executor.get_kube_client' [11501,11556]
string: 'airflow.executors.kubernetes_executor.get_kube_client' [12367,12422]
===
match
---
atom_expr [6720,6737]
atom_expr [6720,6737]
===
match
---
name: client [914,920]
name: client [914,920]
===
match
---
trailer [12002,12016]
trailer [12868,12882]
===
match
---
operator: , [5169,5170]
operator: , [5169,5170]
===
match
---
not_test [7322,7364]
not_test [7322,7364]
===
match
---
name: executor [10101,10109]
name: executor [10967,10975]
===
match
---
operator: , [2222,2223]
operator: , [2222,2223]
===
match
---
arglist [2248,2257]
arglist [2248,2257]
===
match
---
name: unittest [5119,5127]
name: unittest [5119,5127]
===
match
---
number: 1 [3875,3876]
number: 1 [3875,3876]
===
match
---
funcdef [11657,12201]
funcdef [12523,13067]
===
match
---
name: AirflowKubernetesScheduler [2755,2781]
name: AirflowKubernetesScheduler [2755,2781]
===
match
---
import_from [841,870]
import_from [841,870]
===
match
---
atom_expr [8893,8922]
atom_expr [9759,9788]
===
match
---
trailer [9560,9573]
trailer [10426,10439]
===
match
---
operator: = [13579,13580]
operator: = [14445,14446]
===
match
---
parameters [13222,13246]
parameters [14088,14112]
===
match
---
name: key [6986,6989]
name: key [6986,6989]
===
match
---
operator: , [9437,9438]
operator: , [10303,10304]
===
match
---
trailer [11403,11405]
trailer [12269,12271]
===
match
---
trailer [3625,3628]
trailer [3625,3628]
===
match
---
string: "my_dag_id" [2062,2073]
string: "my_dag_id" [2062,2073]
===
match
---
trailer [12776,12786]
trailer [13642,13652]
===
match
---
name: V1ObjectMeta [13646,13658]
name: V1ObjectMeta [14512,14524]
===
match
---
simple_stmt [10249,10279]
simple_stmt [11115,11145]
===
match
---
atom_expr [12079,12108]
atom_expr [12945,12974]
===
match
---
name: datetime [846,854]
name: datetime [846,854]
===
match
---
operator: , [8778,8779]
operator: , [9644,9645]
===
match
---
name: return_value [6425,6437]
name: return_value [6425,6437]
===
match
---
assert_stmt [4055,4100]
assert_stmt [4055,4100]
===
match
---
operator: = [8195,8196]
operator: = [8195,8196]
===
match
---
name: empty [7357,7362]
name: empty [7357,7362]
===
match
---
suite [1062,1454]
suite [1062,1454]
===
match
---
dotted_name [9024,9034]
dotted_name [9890,9900]
===
match
---
param [11753,11780]
param [12619,12646]
===
match
---
name: executor [10224,10232]
name: executor [11090,11098]
===
match
---
string: 'metadata' [12833,12843]
string: 'metadata' [13699,13709]
===
match
---
expr_stmt [13524,13562]
expr_stmt [14390,14428]
===
match
---
name: call [8216,8220]
name: call [8216,8220]
===
match
---
name: patch [5305,5310]
name: patch [5305,5310]
===
match
---
operator: , [12548,12549]
operator: , [13414,13415]
===
match
---
atom_expr [7326,7364]
atom_expr [7326,7364]
===
match
---
trailer [13645,13658]
trailer [14511,14524]
===
match
---
string: 'pod_id' [12036,12044]
string: 'pod_id' [12902,12910]
===
match
---
trailer [7356,7362]
trailer [7356,7362]
===
match
---
name: _gen_random_string [2229,2247]
name: _gen_random_string [2229,2247]
===
match
---
trailer [6593,6604]
trailer [6593,6604]
===
match
---
name: ch [2492,2494]
name: ch [2492,2494]
===
match
---
operator: == [10457,10459]
operator: == [11323,11325]
===
match
---
atom_expr [7210,7236]
atom_expr [7210,7236]
===
match
---
name: self [3958,3962]
name: self [3958,3962]
===
match
---
simple_stmt [10157,10216]
simple_stmt [11023,11082]
===
match
---
simple_stmt [811,825]
simple_stmt [811,825]
===
match
---
string: 'default' [8867,8876]
string: 'default' [9733,9742]
===
match
---
name: body [5677,5681]
name: body [5677,5681]
===
match
---
operator: = [13641,13642]
operator: = [14507,14508]
===
match
---
arglist [6240,6284]
arglist [6240,6284]
===
match
---
name: executor [8683,8691]
name: executor [9549,9557]
===
match
---
name: test_execution_date_serialize_deserialize [4497,4538]
name: test_execution_date_serialize_deserialize [4497,4538]
===
match
---
expr_stmt [10943,10972]
expr_stmt [11809,11838]
===
match
---
atom [6990,7036]
atom [6990,7036]
===
match
---
name: patch [7945,7950]
name: patch [7945,7950]
===
match
---
name: mock [13116,13120]
name: mock [13982,13986]
===
match
---
name: kubernetes [1367,1377]
name: kubernetes [1367,1377]
===
match
---
name: regex [2615,2620]
name: regex [2615,2620]
===
match
---
arglist [10372,10410]
arglist [11238,11276]
===
match
---
string: 'ex_time' [11960,11969]
string: 'ex_time' [12826,12835]
===
match
---
simple_stmt [3828,3884]
simple_stmt [3828,3884]
===
match
---
trailer [3622,3625]
trailer [3622,3625]
===
match
---
operator: , [2047,2048]
operator: , [2047,2048]
===
match
---
name: mock_delete_pod [9975,9990]
name: mock_delete_pod [10841,10856]
===
match
---
atom_expr [2529,2550]
atom_expr [2529,2550]
===
match
---
simple_stmt [3564,3632]
simple_stmt [3564,3632]
===
match
---
operator: , [7023,7024]
operator: , [7023,7024]
===
match
---
operator: { [13107,13108]
operator: { [13973,13974]
===
match
---
atom_expr [5046,5066]
atom_expr [5046,5066]
===
match
---
dotted_name [11490,11500]
dotted_name [12356,12366]
===
match
---
param [4539,4543]
param [4539,4543]
===
match
---
operator: { [13952,13953]
operator: { [14818,14819]
===
match
---
trailer [10996,11016]
trailer [11862,11882]
===
match
---
operator: = [9313,9314]
operator: = [10179,10180]
===
match
---
simple_stmt [4781,4821]
simple_stmt [4781,4821]
===
match
---
atom_expr [9501,9514]
atom_expr [10367,10380]
===
match
---
name: append [1815,1821]
name: append [1815,1821]
===
match
---
assert_stmt [9545,9598]
assert_stmt [10411,10464]
===
match
---
atom_expr [7257,7302]
atom_expr [7257,7302]
===
match
---
trailer [4577,4581]
trailer [4577,4581]
===
match
---
atom_expr [8244,8252]
atom_expr [8244,8252]
===
match
---
import_from [898,941]
import_from [898,941]
===
match
---
name: _change_state [10358,10371]
name: _change_state [11224,11237]
===
match
---
operator: , [13069,13070]
operator: , [13935,13936]
===
match
---
trailer [1769,1792]
trailer [1769,1792]
===
match
---
atom_expr [13789,13861]
atom_expr [14655,14727]
===
match
---
atom_expr [1601,1618]
atom_expr [1601,1618]
===
match
---
atom [10293,10340]
atom [11159,11206]
===
match
---
operator: { [12793,12794]
operator: { [13659,13660]
===
match
---
string: 'namespace' [13052,13063]
string: 'namespace' [13918,13929]
===
match
---
decorator [7939,7998]
decorator [7939,7998]
===
match
---
expr_stmt [11932,11985]
expr_stmt [12798,12851]
===
match
---
name: mock_get_kube_client [9992,10012]
name: mock_get_kube_client [10858,10878]
===
match
---
trailer [10121,10140]
trailer [10987,11006]
===
match
---
simple_stmt [6075,6097]
simple_stmt [6075,6097]
===
match
---
simple_stmt [4055,4101]
simple_stmt [4055,4101]
===
match
---
atom_expr [8727,8743]
atom_expr [9593,9609]
===
match
---
trailer [13817,13861]
trailer [14683,14727]
===
match
---
name: FAILED [10466,10472]
name: FAILED [11332,11338]
===
match
---
simple_stmt [2615,2674]
simple_stmt [2615,2674]
===
match
---
expr_stmt [13480,13515]
expr_stmt [14346,14381]
===
match
---
name: dag_id [4244,4250]
name: dag_id [4244,4250]
===
match
---
name: k8s [12472,12475]
name: k8s [13338,13341]
===
match
---
operator: , [5404,5405]
operator: , [5404,5405]
===
match
---
and_test [2689,2732]
and_test [2689,2732]
===
match
---
trailer [8178,8180]
trailer [8178,8180]
===
match
---
simple_stmt [9545,9599]
simple_stmt [10411,10465]
===
match
---
number: 0 [12106,12107]
number: 0 [12972,12973]
===
match
---
simple_stmt [6908,6923]
simple_stmt [6908,6923]
===
match
---
name: name [13676,13680]
name: name [14542,14546]
===
match
---
string: "a" [4417,4420]
string: "a" [4417,4420]
===
match
---
decorated [11411,12201]
decorated [12277,13067]
===
match
---
operator: , [8621,8622]
operator: , [9487,9488]
===
match
---
atom_expr [11236,11299]
atom_expr [12102,12165]
===
match
---
operator: { [12815,12816]
operator: { [13681,13682]
===
match
---
string: "modified" [13552,13562]
string: "modified" [14418,14428]
===
match
---
trailer [7698,7704]
trailer [7698,7704]
===
match
---
simple_stmt [1120,1301]
simple_stmt [1120,1301]
===
match
---
string: 'task' [6998,7004]
string: 'task' [6998,7004]
===
match
---
name: executor [12385,12393]
name: executor [13251,13259]
===
match
---
trailer [2192,2211]
trailer [2192,2211]
===
match
---
comparison [4402,4487]
comparison [4402,4487]
===
match
---
name: k8s [938,941]
name: k8s [938,941]
===
match
---
param [4996,5000]
param [4996,5000]
===
match
---
name: test_run_next_exception [5376,5399]
name: test_run_next_exception [5376,5399]
===
match
---
name: self [3920,3924]
name: self [3920,3924]
===
match
---
param [1905,1909]
param [1905,1909]
===
match
---
operator: , [9448,9449]
operator: , [10314,10315]
===
match
---
trailer [8931,8939]
trailer [9797,9805]
===
match
---
return_stmt [2303,2315]
return_stmt [2303,2315]
===
match
---
string: 'pod_id' [9647,9655]
string: 'pod_id' [10513,10521]
===
match
---
dictorsetmaker [12443,12456]
dictorsetmaker [13309,13322]
===
match
---
atom [1983,2010]
atom [1983,2010]
===
match
---
sync_comp_for [2260,2282]
sync_comp_for [2260,2282]
===
match
---
operator: = [6361,6362]
operator: = [6361,6362]
===
match
---
atom_expr [3424,3480]
atom_expr [3424,3480]
===
match
---
exprlist [3939,3954]
exprlist [3939,3954]
===
match
---
name: sys [5473,5476]
name: sys [5473,5476]
===
match
---
atom_expr [1805,1854]
atom_expr [1805,1854]
===
match
---
trailer [11269,11277]
trailer [12135,12143]
===
match
---
name: pod_template_file_path [3380,3402]
name: pod_template_file_path [3380,3402]
===
match
---
name: task_id [3947,3954]
name: task_id [3947,3954]
===
match
---
return_stmt [2682,2732]
return_stmt [2682,2732]
===
match
---
name: name [12538,12542]
name: name [13404,13408]
===
match
---
funcdef [8587,8940]
funcdef [9453,9806]
===
match
---
operator: } [13965,13966]
operator: } [14831,14832]
===
match
---
operator: , [12020,12021]
operator: , [12886,12887]
===
match
---
atom_expr [4062,4100]
atom_expr [4062,4100]
===
match
---
name: self [9315,9319]
name: self [10181,10185]
===
match
---
name: mock_generator [3355,3369]
name: mock_generator [3355,3369]
===
match
---
trailer [10970,10972]
trailer [11836,11838]
===
match
---
operator: * [4378,4379]
operator: * [4378,4379]
===
match
---
trailer [10448,10453]
trailer [11314,11319]
===
match
---
operator: , [1257,1258]
operator: , [1257,1258]
===
match
---
param [8078,8088]
param [8078,8088]
===
match
---
comparison [13941,13966]
comparison [14807,14832]
===
match
---
string: "/foo/bar" [3835,3845]
string: "/foo/bar" [3835,3845]
===
match
---
name: name [2545,2549]
name: name [2545,2549]
===
match
---
expr_stmt [4350,4382]
expr_stmt [4350,4382]
===
match
---
simple_stmt [4395,4488]
simple_stmt [4395,4488]
===
match
---
string: '"reason": "Forbidden", "details": {"name": "podname", "kind": "pods"}, "code": 403}' [5971,6056]
string: '"reason": "Forbidden", "details": {"name": "podname", "kind": "pods"}, "code": 403}' [5971,6056]
===
match
---
string: 'airflow.executors.base_executor.BaseExecutor.trigger_tasks' [7873,7933]
string: 'airflow.executors.base_executor.BaseExecutor.trigger_tasks' [7873,7933]
===
match
---
name: sync [7577,7581]
name: sync [7577,7581]
===
match
---
name: range [2272,2277]
name: range [2272,2277]
===
match
---
atom_expr [3597,3631]
atom_expr [3597,3631]
===
match
---
operator: = [12470,12471]
operator: = [13336,13337]
===
match
---
trailer [11323,11336]
trailer [12189,12202]
===
match
---
trailer [6239,6285]
trailer [6239,6285]
===
match
---
name: executor [11081,11089]
name: executor [11947,11955]
===
match
---
operator: , [2543,2544]
operator: , [2543,2544]
===
match
---
name: mock_kubeconfig [3338,3353]
name: mock_kubeconfig [3338,3353]
===
match
---
simple_stmt [13256,13471]
simple_stmt [14122,14337]
===
match
---
simple_stmt [9304,9340]
simple_stmt [10170,10206]
===
match
---
atom [13952,13966]
atom [14818,14832]
===
match
---
operator: == [9582,9584]
operator: == [10448,10450]
===
match
---
operator: = [3997,3998]
operator: = [3997,3998]
===
match
---
name: pod_generator [4128,4141]
name: pod_generator [4128,4141]
===
match
---
trailer [12393,12410]
trailer [13259,13276]
===
match
---
funcdef [2339,2551]
funcdef [2339,2551]
===
match
---
return_stmt [1863,1888]
return_stmt [1863,1888]
===
match
---
name: mock [10639,10643]
name: mock [11505,11509]
===
match
---
name: call [8272,8276]
name: call [8272,8276]
===
match
---
number: 0 [3881,3882]
number: 0 [3881,3882]
===
match
---
name: utils [989,994]
name: utils [989,994]
===
match
---
operator: = [12542,12543]
operator: = [13408,13409]
===
match
---
name: mock [6483,6487]
name: mock [6483,6487]
===
match
---
name: start [9357,9362]
name: start [10223,10228]
===
match
---
operator: , [7004,7005]
operator: , [7004,7005]
===
match
---
atom_expr [6335,6395]
atom_expr [6335,6395]
===
match
---
name: ApiException [6362,6374]
name: ApiException [6362,6374]
===
match
---
name: mock [3164,3168]
name: mock [3164,3168]
===
match
---
name: mock [7781,7785]
name: mock [7781,7785]
===
match
---
atom [12557,12618]
atom [13423,13484]
===
match
---
simple_stmt [3424,3481]
simple_stmt [3424,3481]
===
match
---
name: setUp [4990,4995]
name: setUp [4990,4995]
===
match
---
name: timezone [10261,10269]
name: timezone [11127,11135]
===
match
---
name: skipIf [3070,3076]
name: skipIf [3070,3076]
===
match
---
param [10878,10899]
param [11744,11765]
===
match
---
parameters [4538,4544]
parameters [4538,4544]
===
match
---
expr_stmt [8683,8718]
expr_stmt [9549,9584]
===
match
---
atom_expr [2488,2524]
atom_expr [2488,2524]
===
match
---
dotted_name [10639,10649]
dotted_name [11505,11515]
===
match
---
term [2103,2118]
term [2103,2118]
===
match
---
trailer [11336,11341]
trailer [12202,12207]
===
match
---
name: assert_has_calls [8407,8423]
name: assert_has_calls [8407,8423]
===
match
---
string: 'foo' [12973,12978]
string: 'foo' [13839,13844]
===
match
---
name: self [13223,13227]
name: self [14089,14093]
===
match
---
atom_expr [4128,4172]
atom_expr [4128,4172]
===
match
---
atom_expr [12133,12200]
atom_expr [12999,13066]
===
match
---
name: dag_id [4350,4356]
name: dag_id [4350,4356]
===
match
---
operator: } [6705,6706]
operator: } [6705,6706]
===
match
---
arglist [3722,3743]
arglist [3722,3743]
===
match
---
string: "a" [4374,4377]
string: "a" [4374,4377]
===
match
---
atom [13592,13594]
atom [14458,14460]
===
match
---
name: mock_generator [3849,3863]
name: mock_generator [3849,3863]
===
match
---
trailer [7619,7641]
trailer [7619,7641]
===
match
---
trailer [1609,1618]
trailer [1609,1618]
===
match
---
assert_stmt [4395,4487]
assert_stmt [4395,4487]
===
match
---
name: label_safe_datestring_to_datetime [4717,4750]
name: label_safe_datestring_to_datetime [4717,4750]
===
match
---
name: seed [1666,1670]
name: seed [1666,1670]
===
match
---
suite [10934,11406]
suite [11800,12272]
===
match
---
name: state [1435,1440]
name: state [1435,1440]
===
match
---
comparison [3496,3555]
comparison [3496,3555]
===
match
---
name: patch [7718,7723]
name: patch [7718,7723]
===
match
---
expr_stmt [11796,11831]
expr_stmt [12662,12697]
===
match
---
trailer [8334,8370]
trailer [8334,8370]
===
match
---
name: start [10233,10238]
name: start [11099,11104]
===
match
---
dotted_name [8946,8956]
dotted_name [9812,9822]
===
match
---
string: 'default' [10401,10410]
string: 'default' [11267,11276]
===
match
---
name: mock_kube_client [12739,12755]
name: mock_kube_client [13605,13621]
===
match
---
simple_stmt [7210,7237]
simple_stmt [7210,7237]
===
match
---
param [1672,1679]
param [1672,1679]
===
match
---
trailer [6836,6838]
trailer [6836,6838]
===
match
---
trailer [1735,1744]
trailer [1735,1744]
===
match
---
atom_expr [10068,10092]
atom_expr [10934,10958]
===
match
---
name: kubernetes_executor [6811,6830]
name: kubernetes_executor [6811,6830]
===
match
---
operator: + [5505,5506]
operator: + [5505,5506]
===
match
---
operator: , [7036,7037]
operator: , [7036,7037]
===
match
---
name: sys [5493,5496]
name: sys [5493,5496]
===
match
---
atom [13695,13756]
atom [14561,14622]
===
match
---
dotted_name [9097,9107]
dotted_name [9963,9973]
===
match
---
comparison [5135,5169]
comparison [5135,5169]
===
match
---
operator: , [6996,6997]
operator: , [6996,6997]
===
match
---
operator: } [12942,12943]
operator: } [13808,13809]
===
match
---
trailer [2165,2172]
trailer [2165,2172]
===
match
---
name: key [9496,9499]
name: key [10362,10365]
===
match
---
atom_expr [6294,6332]
atom_expr [6294,6332]
===
match
---
simple_stmt [10420,10473]
simple_stmt [11286,11339]
===
match
---
trailer [4012,4034]
trailer [4012,4034]
===
match
---
trailer [12016,12063]
trailer [12882,12929]
===
match
---
expr_stmt [10157,10215]
expr_stmt [11023,11081]
===
match
---
atom [1942,1969]
atom [1942,1969]
===
match
---
name: labels [13688,13694]
name: labels [14554,14560]
===
match
---
name: mock_kubeconfig [3640,3655]
name: mock_kubeconfig [3640,3655]
===
match
---
trailer [4034,4042]
trailer [4034,4042]
===
match
---
atom_expr [2710,2732]
atom_expr [2710,2732]
===
match
---
name: key [10449,10452]
name: key [11315,11318]
===
match
---
suite [10048,10517]
suite [10914,11383]
===
match
---
name: task_id [2891,2898]
name: task_id [2891,2898]
===
match
---
string: 'dag_id' [11939,11947]
string: 'dag_id' [12805,12813]
===
match
---
trailer [12481,12642]
trailer [13347,13508]
===
match
---
atom_expr [2492,2502]
atom_expr [2492,2502]
===
match
---
name: side_effect [7456,7467]
name: side_effect [7456,7467]
===
match
---
trailer [8698,8718]
trailer [9564,9584]
===
match
---
string: 'airflow.executors.kubernetes_executor.KubernetesJobWatcher' [10572,10632]
string: 'airflow.executors.kubernetes_executor.KubernetesJobWatcher' [11438,11498]
===
match
---
dotted_name [3229,3239]
dotted_name [3229,3239]
===
match
---
name: conf_vars [6720,6729]
name: conf_vars [6720,6729]
===
match
---
name: pod_ids [12715,12722]
name: pod_ids [13581,13588]
===
match
---
name: str_len [1672,1679]
name: str_len [1672,1679]
===
match
---
name: PodGenerator [1399,1411]
name: PodGenerator [1399,1411]
===
match
---
trailer [7455,7467]
trailer [7455,7467]
===
match
---
operator: , [12705,12706]
operator: , [13571,13572]
===
match
---
name: mock [12207,12211]
name: mock [13073,13077]
===
match
---
simple_stmt [4113,4173]
simple_stmt [4113,4173]
===
match
---
trailer [8406,8423]
trailer [8406,8423]
===
match
---
name: config [6631,6637]
name: config [6631,6637]
===
match
---
name: mock_calls [3803,3813]
name: mock_calls [3803,3813]
===
match
---
name: unittest [3061,3069]
name: unittest [3061,3069]
===
match
---
trailer [13495,13515]
trailer [14361,14381]
===
match
---
operator: = [2938,2939]
operator: = [2938,2939]
===
match
---
name: create_namespaced_pod [7620,7641]
name: create_namespaced_pod [7620,7641]
===
match
---
decorated [2738,3055]
decorated [2738,3055]
===
match
---
strings [5682,6056]
strings [5682,6056]
===
match
---
dotted_name [8437,8447]
dotted_name [9303,9313]
===
match
---
operator: * [2113,2114]
operator: * [2113,2114]
===
match
---
name: call [8330,8334]
name: call [8330,8334]
===
match
---
operator: { [13592,13593]
operator: { [14458,14459]
===
match
---
trailer [4087,4100]
trailer [4087,4100]
===
match
---
atom_expr [8160,8180]
atom_expr [8160,8180]
===
match
---
name: State [9501,9506]
name: State [10367,10372]
===
match
---
decorator [11489,11558]
decorator [12355,12424]
===
match
---
name: mock [9752,9756]
name: mock [10618,10622]
===
match
---
decorated [1625,1889]
decorated [1625,1889]
===
match
---
decorators [5118,5368]
decorators [5118,5368]
===
match
---
string: 'airflow.executors.kubernetes_executor.AirflowKubernetesScheduler.delete_pod' [9836,9913]
string: 'airflow.executors.kubernetes_executor.AirflowKubernetesScheduler.delete_pod' [10702,10779]
===
match
---
funcdef [2841,3055]
funcdef [2841,3055]
===
match
---
string: 'kubernetes python package is not installed' [5171,5215]
string: 'kubernetes python package is not installed' [5171,5215]
===
match
---
operator: = [4567,4568]
operator: = [4567,4568]
===
match
---
trailer [8836,8877]
trailer [9702,9743]
===
match
---
name: kube_config [10110,10121]
name: kube_config [10976,10987]
===
match
---
trailer [10963,10970]
trailer [11829,11836]
===
match
---
name: kubernetes_executor [5024,5043]
name: kubernetes_executor [5024,5043]
===
match
---
dotted_name [5119,5134]
dotted_name [5119,5134]
===
match
---
dotted_name [8515,8525]
dotted_name [9381,9391]
===
match
---
atom [12442,12457]
atom [13308,13323]
===
match
---
name: string [1836,1842]
name: string [1836,1842]
===
match
---
operator: = [6438,6439]
operator: = [6438,6439]
===
match
---
funcdef [9919,10517]
funcdef [10785,11383]
===
match
---
trailer [2500,2502]
trailer [2500,2502]
===
match
---
name: test_change_state_running [8591,8616]
name: test_change_state_running [9457,9482]
===
match
---
operator: = [6919,6920]
operator: = [6919,6920]
===
match
---
operator: , [12943,12944]
operator: , [13809,13810]
===
match
---
import_from [942,974]
import_from [942,974]
===
match
---
name: regex [2719,2724]
name: regex [2719,2724]
===
match
---
name: skipIf [5128,5134]
name: skipIf [5128,5134]
===
match
---
name: kubernetes [1072,1082]
name: kubernetes [1072,1082]
===
match
---
import_as_name [928,941]
import_as_name [928,941]
===
match
---
atom_expr [13642,13770]
atom_expr [14508,14636]
===
match
---
name: executor [10057,10065]
name: executor [10923,10931]
===
match
---
operator: == [12790,12792]
operator: == [13656,13658]
===
match
---
name: executor [8814,8822]
name: executor [9680,9688]
===
match
---
name: skipIf [2748,2754]
name: skipIf [2748,2754]
===
match
---
name: job_id [5100,5106]
name: job_id [5100,5106]
===
match
---
decorator [9096,9187]
decorator [9962,10053]
===
match
---
trailer [4716,4750]
trailer [4716,4750]
===
match
---
trailer [12087,12100]
trailer [12953,12966]
===
match
---
string: "dagtask" [12443,12452]
string: "dagtask" [13309,13318]
===
match
---
name: timezone [10955,10963]
name: timezone [11821,11829]
===
match
---
name: str [1770,1773]
name: str [1770,1773]
===
match
---
trailer [3628,3631]
trailer [3628,3631]
===
match
---
name: mock [9024,9028]
name: mock [9890,9894]
===
match
---
trailer [6113,6120]
trailer [6113,6120]
===
match
---
operator: = [7089,7090]
operator: = [7089,7090]
===
match
---
name: executors [1133,1142]
name: executors [1133,1142]
===
match
---
name: _cases [3963,3969]
name: _cases [3963,3969]
===
match
---
name: mock_delete_pod [9607,9622]
name: mock_delete_pod [10473,10488]
===
match
---
trailer [6487,6497]
trailer [6487,6497]
===
match
---
trailer [12679,12723]
trailer [13545,13589]
===
match
---
name: _change_state [9482,9495]
name: _change_state [10348,10361]
===
match
---
string: 'airflow.executors.kubernetes_executor.KubernetesExecutor.sync' [7792,7855]
string: 'airflow.executors.kubernetes_executor.KubernetesExecutor.sync' [7792,7855]
===
match
---
name: executor [11994,12002]
name: executor [12860,12868]
===
match
---
operator: , [10859,10860]
operator: , [11725,11726]
===
match
---
simple_stmt [5075,5113]
simple_stmt [5075,5113]
===
match
---
trailer [3880,3883]
trailer [3880,3883]
===
match
---
assert_stmt [3016,3054]
assert_stmt [3016,3054]
===
match
---
suite [2916,3055]
suite [2916,3055]
===
match
---
name: patch [9757,9762]
name: patch [10623,10628]
===
match
---
argument [6986,7036]
argument [6986,7036]
===
match
---
name: patch [3169,3174]
name: patch [3169,3174]
===
match
---
name: test_time [10943,10952]
name: test_time [11809,11818]
===
match
---
funcdef [8002,8431]
funcdef [8002,8431]
===
match
---
trailer [9590,9598]
trailer [10456,10464]
===
match
---
atom [12877,12943]
atom [13743,13809]
===
match
---
operator: , [3336,3337]
operator: , [3336,3337]
===
match
---
suite [4545,4821]
suite [4545,4821]
===
match
---
string: "airflow.kubernetes.pod_generator.PodGenerator" [3175,3222]
string: "airflow.kubernetes.pod_generator.PodGenerator" [3175,3222]
===
match
---
assert_stmt [3753,3819]
assert_stmt [3753,3819]
===
match
---
string: 'try_number2' [9450,9463]
string: 'try_number2' [10316,10329]
===
match
---
trailer [6339,6349]
trailer [6339,6349]
===
match
---
atom_expr [7171,7197]
atom_expr [7171,7197]
===
match
---
operator: @ [9023,9024]
operator: @ [9889,9890]
===
match
---
atom_expr [8302,8310]
atom_expr [8302,8310]
===
match
---
dictorsetmaker [13953,13965]
dictorsetmaker [14819,14831]
===
match
---
name: create_pod_id [2972,2985]
name: create_pod_id [2972,2985]
===
match
---
name: mock [8437,8441]
name: mock [9303,9307]
===
match
---
atom [12845,12997]
atom [13711,13863]
===
match
---
simple_stmt [2682,2733]
simple_stmt [2682,2733]
===
match
---
exprlist [2883,2898]
exprlist [2883,2898]
===
match
---
trailer [10238,10240]
trailer [11104,11106]
===
match
---
name: pod_generator [3999,4012]
name: pod_generator [3999,4012]
===
match
---
import_name [825,840]
import_name [825,840]
===
match
---
simple_stmt [11796,11832]
simple_stmt [12662,12698]
===
match
---
string: 'task_id' [11949,11958]
string: 'task_id' [12815,12824]
===
match
---
atom_expr [1758,1792]
atom_expr [1758,1792]
===
match
---
name: self [5075,5079]
name: self [5075,5079]
===
match
---
atom_expr [6362,6394]
atom_expr [6362,6394]
===
match
---
string: "task_id" [12600,12609]
string: "task_id" [13466,13475]
===
match
---
assert_stmt [4185,4231]
assert_stmt [4185,4231]
===
match
---
operator: = [7059,7060]
operator: = [7059,7060]
===
match
---
assert_stmt [3489,3555]
assert_stmt [3489,3555]
===
match
---
argument [12550,12618]
argument [13416,13484]
===
match
---
import_from [1067,1114]
import_from [1067,1114]
===
match
---
expr_stmt [10249,10278]
expr_stmt [11115,11144]
===
match
---
trailer [10435,10448]
trailer [11301,11314]
===
match
---
operator: @ [2321,2322]
operator: @ [2321,2322]
===
match
---
decorator [7712,7776]
decorator [7712,7776]
===
match
---
arglist [12538,12618]
arglist [13404,13484]
===
match
---
operator: , [9499,9500]
operator: , [10365,10366]
===
match
---
operator: = [10066,10067]
operator: = [10932,10933]
===
match
---
string: 'dag_id' [10294,10302]
string: 'dag_id' [11160,11168]
===
match
---
testlist_comp [1942,2140]
testlist_comp [1942,2140]
===
match
---
operator: == [11345,11347]
operator: == [12211,12213]
===
match
---
operator: , [8056,8057]
operator: , [8056,8057]
===
match
---
simple_stmt [6811,6839]
simple_stmt [6811,6839]
===
match
---
trailer [10109,10121]
trailer [10975,10987]
===
match
---
trailer [10232,10238]
trailer [11098,11104]
===
match
---
expr_stmt [6631,6706]
expr_stmt [6631,6706]
===
match
---
name: client [1083,1089]
name: client [1083,1089]
===
match
---
suite [8674,8940]
suite [9540,9806]
===
match
---
arglist [8837,8876]
arglist [9703,9742]
===
match
---
name: airflow [1421,1428]
name: airflow [1421,1428]
===
match
---
param [10855,10860]
param [11721,11726]
===
match
---
operator: = [6091,6092]
operator: = [6091,6092]
===
match
---
decorator [5118,5217]
decorator [5118,5217]
===
match
---
name: unittest [2739,2747]
name: unittest [2739,2747]
===
match
---
name: side_effect [6350,6361]
name: side_effect [6350,6361]
===
match
---
argument [6375,6393]
argument [6375,6393]
===
match
---
argument [12495,12632]
argument [13361,13498]
===
match
---
simple_stmt [11994,12064]
simple_stmt [12860,12930]
===
match
---
atom [13963,13965]
atom [14829,14831]
===
match
---
comparison [2467,2483]
comparison [2467,2483]
===
match
---
operator: , [3473,3474]
operator: , [3473,3474]
===
match
---
dotted_name [1125,1162]
dotted_name [1125,1162]
===
match
---
operator: , [2118,2119]
operator: , [2118,2119]
===
match
---
name: pod [12466,12469]
name: pod [13332,13335]
===
match
---
simple_stmt [10349,10412]
simple_stmt [11215,11278]
===
match
---
string: 'airflow.executors.kubernetes_executor.get_kube_client' [8526,8581]
string: 'airflow.executors.kubernetes_executor.get_kube_client' [9392,9447]
===
match
---
simple_stmt [10224,10241]
simple_stmt [11090,11107]
===
match
---
string: r"^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*$" [2383,2451]
string: r"^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*$" [2383,2451]
===
match
---
trailer [4627,4661]
trailer [4627,4661]
===
match
---
operator: @ [7712,7713]
operator: @ [7712,7713]
===
match
---
operator: = [12714,12715]
operator: = [13580,13581]
===
match
---
name: self [9221,9225]
name: self [10087,10091]
===
match
---
operator: , [2034,2035]
operator: , [2034,2035]
===
match
---
trailer [3450,3480]
trailer [3450,3480]
===
match
---
expr_stmt [1690,1704]
expr_stmt [1690,1704]
===
match
---
operator: == [3594,3596]
operator: == [3594,3596]
===
match
---
argument [13688,13756]
argument [14554,14622]
===
match
---
name: pod [13836,13839]
name: pod [14702,14705]
===
match
---
operator: @ [11489,11490]
operator: @ [12355,12356]
===
match
---
name: pod_ids [12432,12439]
name: pod_ids [13298,13305]
===
match
---
trailer [4479,4487]
trailer [4479,4487]
===
match
---
param [2864,2868]
param [2864,2868]
===
match
---
trailer [10357,10371]
trailer [11223,11237]
===
match
---
simple_stmt [1863,1889]
simple_stmt [1863,1889]
===
match
---
name: self [6774,6778]
name: self [6774,6778]
===
match
---
atom_expr [7557,7583]
atom_expr [7557,7583]
===
match
---
atom_expr [8127,8151]
atom_expr [8127,8151]
===
match
---
string: 'true' [7118,7124]
string: 'true' [7118,7124]
===
match
---
name: response [5640,5648]
name: response [5640,5648]
===
match
---
dotted_name [12207,12217]
dotted_name [13073,13083]
===
match
---
simple_stmt [9411,9465]
simple_stmt [10277,10331]
===
match
---
name: self [3023,3027]
name: self [3023,3027]
===
match
---
trailer [10371,10411]
trailer [11237,11277]
===
match
---
name: State [10377,10382]
name: State [11243,11248]
===
match
---
decorator [11562,11653]
decorator [12428,12519]
===
match
---
atom_expr [7417,7467]
atom_expr [7417,7467]
===
match
---
trailer [2971,3003]
trailer [2971,3003]
===
match
---
trailer [10496,10514]
trailer [11362,11380]
===
match
---
decorated [8945,9668]
decorated [9811,10534]
===
match
---
name: sync [7230,7234]
name: sync [7230,7234]
===
match
---
name: adopt_launched_task [12660,12679]
name: adopt_launched_task [13526,13545]
===
match
---
name: executor [12651,12659]
name: executor [13517,13525]
===
match
---
param [5400,5405]
param [5400,5405]
===
match
---
name: kubernetes_executor [6752,6771]
name: kubernetes_executor [6752,6771]
===
match
---
name: k8s [12504,12507]
name: k8s [13370,13373]
===
match
---
trailer [9481,9495]
trailer [10347,10361]
===
match
---
atom_expr [11807,11831]
atom_expr [12673,12697]
===
match
---
name: value [2726,2731]
name: value [2726,2731]
===
match
---
operator: = [11805,11806]
operator: = [12671,12672]
===
match
---
name: RUNNING [8932,8939]
name: RUNNING [9798,9805]
===
match
---
import_from [871,896]
import_from [871,896]
===
match
---
string: "my_dag_id_" [4402,4414]
string: "my_dag_id_" [4402,4414]
===
match
---
atom_expr [8325,8370]
atom_expr [8325,8370]
===
match
---
number: 200 [2218,2221]
number: 200 [2218,2221]
===
match
---
decorated [12206,13110]
decorated [13072,13976]
===
match
---
name: ImportError [1461,1472]
name: ImportError [1461,1472]
===
match
---
name: command [7082,7089]
name: command [7082,7089]
===
match
---
import_from [1305,1349]
import_from [1305,1349]
===
match
---
operator: = [10291,10292]
operator: = [11157,11158]
===
match
---
trailer [9319,9339]
trailer [10185,10205]
===
match
---
operator: } [13010,13011]
operator: } [13876,13877]
===
match
---
name: self [5019,5023]
name: self [5019,5023]
===
match
---
term [4374,4382]
term [4374,4382]
===
match
---
atom_expr [10157,10207]
atom_expr [11023,11073]
===
match
---
name: test_change_state_failed_no_deletion [9923,9959]
name: test_change_state_failed_no_deletion [10789,10825]
===
match
---
name: metadata [12495,12503]
name: metadata [13361,13369]
===
match
---
parameters [10845,10933]
parameters [11711,11799]
===
match
---
trailer [8919,8922]
trailer [9785,9788]
===
match
---
trailer [1764,1769]
trailer [1764,1769]
===
match
---
assert_stmt [11308,11361]
assert_stmt [12174,12227]
===
match
---
testlist_comp [11181,11226]
testlist_comp [12047,12092]
===
match
---
name: name [2360,2364]
name: name [2360,2364]
===
match
---
string: 'kubernetes.client.CoreV1Api' [6240,6269]
string: 'kubernetes.client.CoreV1Api' [6240,6269]
===
match
---
param [12308,12313]
param [13174,13179]
===
match
---
operator: <= [2477,2479]
operator: <= [2477,2479]
===
match
---
decorator [8436,8510]
decorator [9302,9376]
===
match
---
expr_stmt [9411,9464]
expr_stmt [10277,10330]
===
match
---
trailer [12027,12034]
trailer [12893,12900]
===
match
---
name: path [5486,5490]
name: path [5486,5490]
===
match
---
operator: = [6333,6334]
operator: = [6333,6334]
===
match
---
name: serialized_datetime [4751,4770]
name: serialized_datetime [4751,4770]
===
match
---
atom_expr [11840,11890]
atom_expr [12706,12756]
===
match
---
expr_stmt [6508,6568]
expr_stmt [6508,6568]
===
match
---
name: executor [13524,13532]
name: executor [14390,14398]
===
match
---
trailer [8914,8919]
trailer [9780,9785]
===
match
---
string: 'try_number3' [10326,10339]
string: 'try_number3' [11192,11205]
===
match
---
atom [2186,2283]
atom [2186,2283]
===
match
---
name: test_create_pod_id [2845,2863]
name: test_create_pod_id [2845,2863]
===
match
---
trailer [3721,3744]
trailer [3721,3744]
===
match
---
trailer [7581,7583]
trailer [7581,7583]
===
match
---
argument [2492,2523]
argument [2492,2523]
===
match
---
assert_stmt [4781,4820]
assert_stmt [4781,4820]
===
match
---
expr_stmt [12385,12423]
expr_stmt [13251,13289]
===
match
---
operator: = [10141,10142]
operator: = [11007,11008]
===
match
---
operator: @ [5299,5300]
operator: @ [5299,5300]
===
match
---
string: 'dag' [6991,6996]
string: 'dag' [6991,6996]
===
match
---
trailer [1828,1835]
trailer [1828,1835]
===
match
---
name: mock_kubernetes_job_watcher [5428,5455]
name: mock_kubernetes_job_watcher [5428,5455]
===
match
---
atom_expr [8211,8253]
atom_expr [8211,8253]
===
match
---
name: unittest [4852,4860]
name: unittest [4852,4860]
===
match
---
expr_stmt [7417,7474]
expr_stmt [7417,7474]
===
match
---
string: "Forbidden" [6123,6134]
string: "Forbidden" [6123,6134]
===
match
---
operator: , [6667,6668]
operator: , [6667,6668]
===
match
---
trailer [1821,1854]
trailer [1821,1854]
===
match
---
string: "modified" [12413,12423]
string: "modified" [13279,13289]
===
match
---
param [1666,1671]
param [1666,1671]
===
match
---
name: _cases [1898,1904]
name: _cases [1898,1904]
===
match
---
name: mock_get_kube_client [6404,6424]
name: mock_get_kube_client [6404,6424]
===
match
---
string: 'kubernetes python package is not installed' [2791,2835]
string: 'kubernetes python package is not installed' [2791,2835]
===
match
---
name: create_namespaced_pod [7274,7295]
name: create_namespaced_pod [7274,7295]
===
match
---
trailer [2718,2732]
trailer [2718,2732]
===
match
---
string: 'airflow.executors.kubernetes_executor.KubernetesJobWatcher' [9685,9745]
string: 'airflow.executors.kubernetes_executor.KubernetesJobWatcher' [10551,10611]
===
match
---
name: kube_config [10166,10177]
name: kube_config [11032,11043]
===
match
---
name: printable [1843,1852]
name: printable [1843,1852]
===
match
---
name: patch [10566,10571]
name: patch [11432,11437]
===
match
---
name: kubernetes [903,913]
name: kubernetes [903,913]
===
match
---
decorator [7861,7935]
decorator [7861,7935]
===
match
---
simple_stmt [12072,12125]
simple_stmt [12938,12991]
===
match
---
atom [12454,12456]
atom [13320,13322]
===
match
---
operator: , [1969,1970]
operator: , [1969,1970]
===
match
---
comparison [4284,4337]
comparison [4284,4337]
===
match
---
atom_expr [8842,8855]
atom_expr [9708,9721]
===
match
---
name: patch_namespaced_pod [12756,12776]
name: patch_namespaced_pod [13622,13642]
===
match
---
name: executor [12341,12349]
name: executor [13207,13215]
===
match
---
operator: -> [5002,5004]
operator: -> [5002,5004]
===
match
---
param [11714,11730]
param [12580,12596]
===
match
---
decorators [8436,8583]
decorators [9302,9449]
===
match
---
operator: = [6605,6606]
operator: = [6605,6606]
===
match
---
name: get_base_pod_from_template [1267,1293]
name: get_base_pod_from_template [1267,1293]
===
match
---
trailer [12786,12789]
trailer [13652,13655]
===
match
---
name: start [11158,11163]
name: start [12024,12029]
===
match
---
decorator [9673,9747]
decorator [10539,10613]
===
match
---
arglist [2212,2221]
arglist [2212,2221]
===
match
---
string: "/bar/biz" [3405,3415]
string: "/bar/biz" [3405,3415]
===
match
---
string: 'default' [9657,9666]
string: 'default' [10523,10532]
===
match
---
assert_stmt [7661,7706]
assert_stmt [7661,7706]
===
match
---
comparison [2492,2508]
comparison [2492,2508]
===
match
---
operator: == [2503,2505]
operator: == [2503,2505]
===
match
---
atom_expr [1822,1853]
atom_expr [1822,1853]
===
match
---
trailer [8215,8220]
trailer [8215,8220]
===
match
---
number: 1 [3626,3627]
number: 1 [3626,3627]
===
match
---
name: mock_kubernetes_job_watcher [10014,10041]
name: mock_kubernetes_job_watcher [10880,10907]
===
match
---
expr_stmt [11174,11227]
expr_stmt [12040,12093]
===
match
---
name: mock_kube_client [13818,13834]
name: mock_kube_client [14684,14700]
===
match
---
name: event_buffer [8902,8914]
name: event_buffer [9768,9780]
===
match
---
name: SUCCESS [9591,9598]
name: SUCCESS [10457,10464]
===
match
---
name: rest [1090,1094]
name: rest [1090,1094]
===
match
---
atom_expr [4192,4231]
atom_expr [4192,4231]
===
match
---
trailer [8847,8855]
trailer [9713,9721]
===
match
---
name: kubernetes_executor [7210,7229]
name: kubernetes_executor [7210,7229]
===
match
---
operator: { [12454,12455]
operator: { [13320,13321]
===
match
---
number: 0 [11342,11343]
number: 0 [12208,12209]
===
match
---
name: patch_namespaced_pod [13898,13918]
name: patch_namespaced_pod [14764,14784]
===
match
---
trailer [6497,6499]
trailer [6497,6499]
===
match
---
operator: = [12503,12504]
operator: = [13369,13370]
===
match
---
assert_stmt [3828,3883]
assert_stmt [3828,3883]
===
match
---
operator: , [7100,7101]
operator: , [7100,7101]
===
match
---
string: 'dag_id' [11181,11189]
string: 'dag_id' [12047,12055]
===
match
---
name: mock [5300,5304]
name: mock [5300,5304]
===
match
---
name: self [2864,2868]
name: self [2864,2868]
===
match
---
arglist [2538,2549]
arglist [2538,2549]
===
match
---
name: SUCCESS [11270,11277]
name: SUCCESS [12136,12143]
===
match
---
operator: = [8756,8757]
operator: = [9622,9623]
===
match
---
trailer [12117,12124]
trailer [12983,12990]
===
match
---
name: mock_delete_pod [10481,10496]
name: mock_delete_pod [11347,11362]
===
match
---
name: delete_worker_pods_on_failure [10178,10207]
name: delete_worker_pods_on_failure [11044,11073]
===
match
---
operator: , [7109,7110]
operator: , [7109,7110]
===
match
---
param [9221,9226]
param [10087,10092]
===
match
---
trailer [8423,8430]
trailer [8423,8430]
===
match
---
parameters [3919,3925]
parameters [3919,3925]
===
match
---
dictorsetmaker [12833,12997]
dictorsetmaker [13699,13863]
===
match
---
name: create_pod_id [1244,1257]
name: create_pod_id [1244,1257]
===
match
---
expr_stmt [12341,12376]
expr_stmt [13207,13242]
===
match
---
operator: * [2133,2134]
operator: * [2133,2134]
===
match
---
operator: , [13719,13720]
operator: , [14585,14586]
===
match
---
operator: @ [3228,3229]
operator: @ [3228,3229]
===
match
---
name: pod [12702,12705]
name: pod [13568,13571]
===
match
---
string: "my.task.id" [1997,2009]
string: "my.task.id" [1997,2009]
===
match
---
expr_stmt [13604,13780]
expr_stmt [14470,14646]
===
match
---
name: staticmethod [1626,1638]
name: staticmethod [1626,1638]
===
match
---
simple_stmt [8390,8431]
simple_stmt [8390,8431]
===
match
---
operator: , [1670,1671]
operator: , [1670,1671]
===
match
---
operator: = [4357,4358]
operator: = [4357,4358]
===
match
---
name: mock_generator [3597,3611]
name: mock_generator [3597,3611]
===
match
---
import_from [976,1010]
import_from [976,1010]
===
match
---
trailer [12356,12376]
trailer [13222,13242]
===
match
---
dictorsetmaker [13696,13755]
dictorsetmaker [14562,14621]
===
match
---
operator: = [6481,6482]
operator: = [6481,6482]
===
match
---
name: scheduler_job_id [13533,13549]
name: scheduler_job_id [14399,14415]
===
match
---
simple_stmt [2929,3004]
simple_stmt [2929,3004]
===
match
---
atom_expr [3524,3555]
atom_expr [3524,3555]
===
match
---
name: patch [8951,8956]
name: patch [9817,9822]
===
match
---
name: call_args [12777,12786]
name: call_args [13643,13652]
===
match
---
decorators [7712,7998]
decorators [7712,7998]
===
match
---
not_test [13877,13925]
not_test [14743,14791]
===
match
---
decorated [8436,8940]
decorated [9302,9806]
===
match
---
testlist_comp [6655,6688]
testlist_comp [6655,6688]
===
match
---
string: "my-task-id" [1956,1968]
string: "my-task-id" [1956,1968]
===
match
---
assert_stmt [8886,8939]
assert_stmt [9752,9805]
===
match
---
simple_stmt [13870,13926]
simple_stmt [14736,14792]
===
match
---
arglist [12173,12199]
arglist [13039,13065]
===
match
---
string: "dag_id" [12583,12591]
string: "dag_id" [13449,13457]
===
match
---
simple_stmt [11174,11228]
simple_stmt [12040,12094]
===
match
---
name: assert_not_called [10497,10514]
name: assert_not_called [11363,11380]
===
match
---
trailer [6523,6550]
trailer [6523,6550]
===
match
---
atom [6654,6689]
atom [6654,6689]
===
match
---
expr_stmt [3640,3686]
expr_stmt [3640,3686]
===
match
---
testlist_comp [1984,2009]
testlist_comp [1984,2009]
===
match
---
number: 100 [2278,2281]
number: 100 [2278,2281]
===
match
---
name: pod_generator [4614,4627]
name: pod_generator [4614,4627]
===
match
---
name: start [6831,6836]
name: start [6831,6836]
===
match
---
name: sync [7191,7195]
name: sync [7191,7195]
===
match
---
operator: , [10399,10400]
operator: , [11265,11266]
===
match
---
name: called [13919,13925]
name: called [14785,14791]
===
match
---
funcdef [12279,13110]
funcdef [13145,13976]
===
match
---
name: char_list [1690,1699]
name: char_list [1690,1699]
===
match
---
name: try_number [7025,7035]
name: try_number [7025,7035]
===
match
---
suite [3972,4488]
suite [3972,4488]
===
match
---
name: mock [9825,9829]
name: mock [10691,10695]
===
match
---
simple_stmt [7315,7365]
simple_stmt [7315,7365]
===
match
---
string: "my.dag.id" [1984,1995]
string: "my.dag.id" [1984,1995]
===
match
---
name: mock_kube_config [8089,8105]
name: mock_kube_config [8089,8105]
===
match
---
name: re [2529,2531]
name: re [2529,2531]
===
match
---
for_stmt [3935,4488]
for_stmt [3935,4488]
===
match
---
trailer [8901,8914]
trailer [9767,9780]
===
match
---
trailer [7433,7455]
trailer [7433,7455]
===
match
---
atom_expr [5493,5504]
atom_expr [5493,5504]
===
match
---
string: "MYTASKID" [2036,2046]
string: "MYTASKID" [2036,2046]
===
match
---
name: len [2467,2470]
name: len [2467,2470]
===
match
---
simple_stmt [2460,2551]
simple_stmt [2460,2551]
===
match
---
name: event_buffer [12088,12100]
name: event_buffer [12954,12966]
===
match
---
atom [6640,6706]
atom [6640,6706]
===
match
---
testlist_comp [2103,2138]
testlist_comp [2103,2138]
===
match
---
operator: = [11178,11179]
operator: = [12044,12045]
===
match
---
simple_stmt [12133,12201]
simple_stmt [12999,13067]
===
match
---
name: random [1758,1764]
name: random [1758,1764]
===
match
---
simple_stmt [9473,9537]
simple_stmt [10339,10403]
===
match
---
expr_stmt [2615,2673]
expr_stmt [2615,2673]
===
match
---
string: "my_dag_id" [1943,1954]
string: "my_dag_id" [1943,1954]
===
match
---
expr_stmt [6294,6395]
expr_stmt [6294,6395]
===
match
---
funcdef [1643,1889]
funcdef [1643,1889]
===
match
---
operator: , [11958,11959]
operator: , [12824,12825]
===
match
---
operator: = [11132,11133]
operator: = [11998,11999]
===
match
---
operator: , [11712,11713]
operator: , [12578,12579]
===
match
---
trailer [10382,10389]
trailer [11248,11255]
===
match
---
name: _is_safe_label_value [2578,2598]
name: _is_safe_label_value [2578,2598]
===
match
---
operator: , [12312,12313]
operator: , [13178,13179]
===
match
---
operator: , [8076,8077]
operator: , [8076,8077]
===
match
---
name: assert_called_once_with [12149,12172]
name: assert_called_once_with [13015,13038]
===
match
---
name: self [3332,3336]
name: self [3332,3336]
===
match
---
classdef [1564,4821]
classdef [1564,4821]
===
match
---
name: ANY [8249,8252]
name: ANY [8249,8252]
===
match
---
operator: , [8087,8088]
operator: , [8087,8088]
===
match
---
string: 'task_id' [8769,8778]
string: 'task_id' [9635,9644]
===
match
---
argument [6350,6394]
argument [6350,6394]
===
match
---
arglist [9647,9666]
arglist [10513,10532]
===
match
---
atom_expr [8267,8311]
atom_expr [8267,8311]
===
match
---
operator: = [12440,12441]
operator: = [13306,13307]
===
match
---
trailer [7014,7021]
trailer [7014,7021]
===
match
---
operator: , [8643,8644]
operator: , [9509,9510]
===
match
---
string: 'airflow.executors.kubernetes_executor.KubernetesJobWatcher' [8957,9017]
string: 'airflow.executors.kubernetes_executor.KubernetesJobWatcher' [9823,9883]
===
match
---
atom_expr [2902,2915]
atom_expr [2902,2915]
===
match
---
operator: , [12034,12035]
operator: , [12900,12901]
===
match
---
operator: , [11947,11948]
operator: , [12813,12814]
===
match
---
name: match [2532,2537]
name: match [2532,2537]
===
match
---
name: executor [9473,9481]
name: executor [10339,10347]
===
match
---
string: 'body' [12807,12813]
string: 'body' [13673,13679]
===
match
---
funcdef [4986,5113]
funcdef [4986,5113]
===
match
---
atom_expr [7006,7023]
atom_expr [7006,7023]
===
match
---
funcdef [3889,4488]
funcdef [3889,4488]
===
match
---
for_stmt [2879,3055]
for_stmt [2879,3055]
===
match
---
argument [7054,7064]
argument [7054,7064]
===
match
---
number: 0 [5502,5503]
number: 0 [5502,5503]
===
match
---
expr_stmt [6404,6456]
expr_stmt [6404,6456]
===
match
---
trailer [8220,8253]
trailer [8220,8253]
===
match
---
name: create_namespaced_pod [6311,6332]
name: create_namespaced_pod [6311,6332]
===
match
---
name: labels [12550,12556]
name: labels [13416,13422]
===
match
---
operator: @ [12206,12207]
operator: @ [13072,13073]
===
match
---
param [5406,5427]
param [5406,5427]
===
match
---
name: ANY [8366,8369]
name: ANY [8366,8369]
===
match
---
simple_stmt [13524,13563]
simple_stmt [14390,14429]
===
match
---
operator: , [8300,8301]
operator: , [8300,8301]
===
match
---
simple_stmt [7171,7198]
simple_stmt [7171,7198]
===
match
---
operator: } [12996,12997]
operator: } [13862,13863]
===
match
---
trailer [10269,10276]
trailer [11135,11142]
===
match
---
operator: = [10990,10991]
operator: = [11856,11857]
===
match
---
name: name [2519,2523]
name: name [2519,2523]
===
match
---
trailer [4581,4583]
trailer [4581,4583]
===
match
---
operator: , [9514,9515]
operator: , [10380,10381]
===
match
---
atom_expr [10481,10516]
atom_expr [11347,11382]
===
match
---
param [8034,8039]
param [8034,8039]
===
match
---
name: utcnow [10964,10970]
name: utcnow [11830,11836]
===
match
---
simple_stmt [12385,12424]
simple_stmt [13251,13290]
===
match
---
operator: @ [10711,10712]
operator: @ [11577,11578]
===
match
---
atom_expr [4294,4337]
atom_expr [4294,4337]
===
match
---
parameters [9959,10047]
parameters [10825,10913]
===
match
---
name: adopt_launched_task [13798,13817]
name: adopt_launched_task [14664,14683]
===
match
---
name: seed [1774,1778]
name: seed [1774,1778]
===
match
---
name: airflow [1359,1366]
name: airflow [1359,1366]
===
match
---
atom_expr [13524,13549]
atom_expr [14390,14415]
===
match
---
string: 'kubernetes' [6655,6667]
string: 'kubernetes' [6655,6667]
===
match
---
dotted_name [10561,10571]
dotted_name [11427,11437]
===
match
---
name: utcnow [7015,7021]
name: utcnow [7015,7021]
===
match
---
name: datetime [7006,7014]
name: datetime [7006,7014]
===
match
---
number: 253 [2480,2483]
number: 253 [2480,2483]
===
match
---
name: FAILED [12028,12034]
name: FAILED [12894,12900]
===
match
---
testlist_comp [11939,11984]
testlist_comp [12805,12850]
===
match
---
param [9975,9991]
param [10841,10857]
===
match
---
name: key [9574,9577]
name: key [10440,10443]
===
match
---
trailer [13532,13549]
trailer [14398,14415]
===
match
---
name: calls [8189,8194]
name: calls [8189,8194]
===
match
---
atom_expr [3958,3971]
atom_expr [3958,3971]
===
match
---
param [8058,8077]
param [8058,8077]
===
match
---
name: mock [8244,8248]
name: mock [8244,8248]
===
match
---
operator: , [8253,8254]
operator: , [8253,8254]
===
match
---
trailer [9356,9362]
trailer [10222,10228]
===
match
---
parameters [8033,8106]
parameters [8033,8106]
===
match
---
operator: = [12350,12351]
operator: = [13216,13217]
===
match
---
name: kubernetes_executor [7326,7345]
name: kubernetes_executor [7326,7345]
===
match
---
atom_expr [3023,3054]
atom_expr [3023,3054]
===
match
---
dotted_name [11563,11573]
dotted_name [12429,12439]
===
match
---
trailer [7234,7236]
trailer [7234,7236]
===
match
---
trailer [3044,3054]
trailer [3044,3054]
===
match
---
trailer [10514,10516]
trailer [11380,11382]
===
match
---
name: test_not_adopt_unassigned_task [13192,13222]
name: test_not_adopt_unassigned_task [14058,14088]
===
match
---
name: execute_async [6955,6968]
name: execute_async [6955,6968]
===
match
---
simple_stmt [11840,11898]
simple_stmt [12706,12764]
===
match
---
simple_stmt [1920,2151]
simple_stmt [1920,2151]
===
match
---
number: 200 [2115,2118]
number: 200 [2115,2118]
===
match
---
name: mock [7940,7944]
name: mock [7940,7944]
===
match
---
trailer [7190,7195]
trailer [7190,7195]
===
match
---
operator: = [12701,12702]
operator: = [13567,13568]
===
match
---
name: patch [9029,9034]
name: patch [9895,9900]
===
match
---
string: 'default' [9526,9535]
string: 'default' [10392,10401]
===
match
---
simple_stmt [942,975]
simple_stmt [942,975]
===
match
---
operator: + [4415,4416]
operator: + [4415,4416]
===
match
---
comparison [2755,2789]
comparison [2755,2789]
===
match
---
operator: , [8038,8039]
operator: , [8038,8039]
===
match
---
name: make_safe_label_value [4308,4329]
name: make_safe_label_value [4308,4329]
===
match
---
name: mock_delete_pod [9227,9242]
name: mock_delete_pod [10093,10108]
===
match
---
name: re [808,810]
name: re [808,810]
===
match
---
trailer [11101,11131]
trailer [11967,11997]
===
match
---
string: 'airflow.executors.kubernetes_executor.KubernetesJobWatcher' [5233,5293]
string: 'airflow.executors.kubernetes_executor.KubernetesJobWatcher' [5233,5293]
===
match
---
dictorsetmaker [12807,13070]
dictorsetmaker [13673,13936]
===
match
---
trailer [11089,11101]
trailer [11955,11967]
===
match
---
simple_stmt [7250,7303]
simple_stmt [7250,7303]
===
match
---
operator: , [8767,8768]
operator: , [9633,9634]
===
match
---
trailer [10453,10456]
trailer [11319,11322]
===
match
---
trailer [6550,6563]
trailer [6550,6563]
===
match
---
simple_stmt [8752,8806]
simple_stmt [9618,9672]
===
match
---
name: mock_get_kube_client [9244,9264]
name: mock_get_kube_client [10110,10130]
===
match
---
name: executor [13789,13797]
name: executor [14655,14663]
===
match
---
operator: , [11277,11278]
operator: , [12143,12144]
===
match
---
parameters [5399,5456]
parameters [5399,5456]
===
match
---
name: ch [2506,2508]
name: ch [2506,2508]
===
match
---
dictorsetmaker [6654,6696]
dictorsetmaker [6654,6696]
===
match
---
expr_stmt [11025,11072]
expr_stmt [11891,11938]
===
match
---
string: 'default' [11289,11298]
string: 'default' [12155,12164]
===
match
---
name: now [4578,4581]
name: now [4578,4581]
===
match
---
name: mock [8211,8215]
name: mock [8211,8215]
===
match
---
suite [2366,2551]
suite [2366,2551]
===
match
---
simple_stmt [10057,10093]
simple_stmt [10923,10959]
===
match
---
atom_expr [9385,9402]
atom_expr [10251,10268]
===
match
---
name: unittest [1601,1609]
name: unittest [1601,1609]
===
match
---
name: all [2488,2491]
name: all [2488,2491]
===
match
---
trailer [10177,10207]
trailer [11043,11073]
===
match
---
simple_stmt [10101,10149]
simple_stmt [10967,11015]
===
match
---
simple_stmt [4684,4772]
simple_stmt [4684,4772]
===
match
---
name: sanitize_for_serialization [6524,6550]
name: sanitize_for_serialization [6524,6550]
===
match
---
name: pod [12698,12701]
name: pod [13564,13567]
===
match
---
trailer [6083,6090]
trailer [6083,6090]
===
match
---
expr_stmt [10057,10092]
expr_stmt [10923,10958]
===
match
---
expr_stmt [3380,3415]
expr_stmt [3380,3415]
===
match
---
name: heartbeat [8169,8178]
name: heartbeat [8169,8178]
===
match
---
dictorsetmaker [12867,12979]
dictorsetmaker [13733,13845]
===
match
---
name: mock [11563,11567]
name: mock [12429,12433]
===
match
---
name: mock_kube_client [13229,13245]
name: mock_kube_client [14095,14111]
===
match
---
operator: , [10898,10899]
operator: , [11764,11765]
===
match
---
atom [11938,11985]
atom [12804,12851]
===
match
---
atom_expr [8926,8939]
atom_expr [9792,9805]
===
match
---
operator: = [1505,1506]
operator: = [1505,1506]
===
match
---
operator: = [6989,6990]
operator: = [6989,6990]
===
match
---
name: _change_state [11245,11258]
name: _change_state [12111,12124]
===
match
---
decorator [9751,9820]
decorator [10617,10686]
===
match
---
assert_stmt [7250,7302]
assert_stmt [7250,7302]
===
match
---
trailer [11258,11299]
trailer [12124,12165]
===
match
---
term [4417,4425]
term [4417,4425]
===
match
---
name: event_buffer [9561,9573]
name: event_buffer [10427,10439]
===
match
---
simple_stmt [9348,9365]
simple_stmt [10214,10231]
===
match
---
atom [2187,2259]
atom [2187,2259]
===
match
---
trailer [2985,3002]
trailer [2985,3002]
===
match
---
atom_expr [3849,3883]
atom_expr [3849,3883]
===
match
---
name: pod_generator [4444,4457]
name: pod_generator [4444,4457]
===
match
---
name: str_len [1736,1743]
name: str_len [1736,1743]
===
match
---
name: mock_kube_client [7603,7619]
name: mock_kube_client [7603,7619]
===
match
---
name: mock [6229,6233]
name: mock [6229,6233]
===
match
---
arith_expr [4359,4382]
arith_expr [4359,4382]
===
match
---
name: executor [12079,12087]
name: executor [12945,12953]
===
match
---
arglist [12680,12722]
arglist [13546,13588]
===
match
---
simple_stmt [12466,12643]
simple_stmt [13332,13509]
===
match
---
name: config [6730,6736]
name: config [6730,6736]
===
match
---
dotted_name [1310,1328]
dotted_name [1310,1328]
===
match
---
name: mock [892,896]
name: mock [892,896]
===
match
---
operator: , [6269,6270]
operator: , [6269,6270]
===
match
---
name: lower [2495,2500]
name: lower [2495,2500]
===
match
---
trailer [3027,3044]
trailer [3027,3044]
===
match
---
expr_stmt [6908,6922]
expr_stmt [6908,6922]
===
match
---
argument [12538,12548]
argument [13404,13414]
===
match
---
operator: @ [7939,7940]
operator: @ [7939,7940]
===
match
---
atom_expr [6811,6838]
atom_expr [6811,6838]
===
match
---
name: datetime_obj [4554,4566]
name: datetime_obj [4554,4566]
===
match
---
simple_stmt [3489,3556]
simple_stmt [3489,3556]
===
match
---
name: patch [8442,8447]
name: patch [9308,9313]
===
match
---
string: 'executor.running_tasks' [8335,8359]
string: 'executor.running_tasks' [8335,8359]
===
match
---
simple_stmt [4244,4265]
simple_stmt [4244,4265]
===
match
---
operator: = [13694,13695]
operator: = [14560,14561]
===
match
---
atom [6566,6568]
atom [6566,6568]
===
match
---
simple_stmt [5466,5477]
simple_stmt [5466,5477]
===
match
---
parameters [12307,12331]
parameters [13173,13197]
===
match
---
name: dag_id [2986,2992]
name: dag_id [2986,2992]
===
match
---
atom_expr [9585,9598]
atom_expr [10451,10464]
===
match
---
trailer [4860,4869]
trailer [4860,4869]
===
match
---
dotted_name [9825,9835]
dotted_name [10691,10701]
===
match
---
name: char_list [1878,1887]
name: char_list [1878,1887]
===
match
---
name: serialized_datetime [4592,4611]
name: serialized_datetime [4592,4611]
===
match
---
string: "foobar" [13582,13590]
string: "foobar" [14448,14456]
===
match
---
simple_stmt [11081,11140]
simple_stmt [11947,12006]
===
match
---
name: executor [11025,11033]
name: executor [11891,11899]
===
match
---
name: patch [6234,6239]
name: patch [6234,6239]
===
match
---
name: self [4192,4196]
name: self [4192,4196]
===
match
---
operator: , [1234,1235]
operator: , [1234,1235]
===
match
---
trailer [13619,13780]
trailer [14485,14646]
===
match
---
assert_stmt [7315,7364]
assert_stmt [7315,7364]
===
match
---
expr_stmt [4554,4583]
expr_stmt [4554,4583]
===
match
---
decorators [10560,10802]
decorators [11426,11668]
===
match
---
decorator [8514,8583]
decorator [9380,9449]
===
match
---
expr_stmt [5640,6066]
expr_stmt [5640,6066]
===
match
---
operator: { [12442,12443]
operator: { [13308,13309]
===
match
---
testlist_comp [8759,8804]
testlist_comp [9625,9670]
===
match
---
string: 'try_number2' [11213,11226]
string: 'try_number2' [12079,12092]
===
match
---
atom_expr [10427,10456]
atom_expr [11293,11322]
===
match
---
decorated [2321,2551]
decorated [2321,2551]
===
match
---
trailer [10165,10177]
trailer [11031,11043]
===
match
---
expr_stmt [6105,6134]
expr_stmt [6105,6134]
===
match
---
operator: + [4372,4373]
operator: + [4372,4373]
===
match
---
name: self [10855,10859]
name: self [11721,11725]
===
match
---
name: patch [11568,11573]
name: patch [12434,12439]
===
match
---
operator: , [2088,2089]
operator: , [2088,2089]
===
match
---
atom_expr [13491,13515]
atom_expr [14357,14381]
===
match
---
simple_stmt [5019,5067]
simple_stmt [5019,5067]
===
match
---
expr_stmt [9373,9402]
expr_stmt [10239,10268]
===
match
---
operator: , [11200,11201]
operator: , [12066,12067]
===
match
---
decorated [13115,13967]
decorated [13981,14833]
===
match
---
name: patch [12212,12217]
name: patch [13078,13083]
===
match
---
dotted_name [9674,9684]
dotted_name [10540,10550]
===
match
---
atom_expr [8390,8430]
atom_expr [8390,8430]
===
match
---
string: "foobar" [13953,13961]
string: "foobar" [14819,14827]
===
match
---
operator: } [13079,13080]
operator: } [13945,13946]
===
match
---
dotted_name [9752,9762]
dotted_name [10618,10628]
===
match
---
operator: , [1995,1996]
operator: , [1995,1996]
===
match
---
param [3332,3337]
param [3332,3337]
===
match
---
trailer [13797,13817]
trailer [14663,14683]
===
match
---
operator: , [2252,2253]
operator: , [2252,2253]
===
match
---
name: test_time [9373,9382]
name: test_time [10239,10248]
===
match
---
name: ApiException [1102,1114]
name: ApiException [1102,1114]
===
match
---
name: MagicMock [6340,6349]
name: MagicMock [6340,6349]
===
match
---
expr_stmt [8752,8805]
expr_stmt [9618,9671]
===
match
---
param [3920,3924]
param [3920,3924]
===
match
---
simple_stmt [3380,3416]
simple_stmt [3380,3416]
===
match
---
trailer [9495,9536]
trailer [10361,10402]
===
match
---
name: mock_kube_client [6210,6226]
name: mock_kube_client [6210,6226]
===
match
---
trailer [1814,1821]
trailer [1814,1821]
===
match
---
simple_stmt [6752,6799]
simple_stmt [6752,6799]
===
match
---
operator: = [3403,3404]
operator: = [3403,3404]
===
match
---
name: test_change_state_skip_pod_deletion [10810,10845]
name: test_change_state_skip_pod_deletion [11676,11711]
===
match
---
name: mock_kube_client [12680,12696]
name: mock_kube_client [13546,13562]
===
match
---
trailer [2491,2524]
trailer [2491,2524]
===
match
---
name: pod_ids [13845,13852]
name: pod_ids [14711,14718]
===
match
---
name: mock_calls [3539,3549]
name: mock_calls [3539,3549]
===
match
---
name: conf_vars [1047,1056]
name: conf_vars [1047,1056]
===
match
---
funcdef [13188,13967]
funcdef [14054,14833]
===
match
---
dotted_name [7781,7791]
dotted_name [7781,7791]
===
match
---
name: State [11264,11269]
name: State [12130,12135]
===
match
---
operator: = [13489,13490]
operator: = [14355,14356]
===
match
---
assert_stmt [3564,3631]
assert_stmt [3564,3631]
===
match
---
simple_stmt [5486,5564]
simple_stmt [5486,5564]
===
match
---
trailer [11341,11344]
trailer [12207,12210]
===
match
---
trailer [6424,6437]
trailer [6424,6437]
===
match
---
simple_stmt [11932,11986]
simple_stmt [12798,12852]
===
match
---
operator: = [6564,6565]
operator: = [6564,6565]
===
match
---
name: mock_delete_pod [10861,10876]
name: mock_delete_pod [11727,11742]
===
match
---
atom_expr [11315,11344]
atom_expr [12181,12210]
===
match
---
string: "mydagid" [2103,2112]
string: "mydagid" [2103,2112]
===
match
---
atom_expr [6404,6437]
atom_expr [6404,6437]
===
match
---
operator: } [6567,6568]
operator: } [6567,6568]
===
match
---
simple_stmt [8886,8940]
simple_stmt [9752,9806]
===
match
---
name: urllib3 [947,954]
name: urllib3 [947,954]
===
match
---
assert_stmt [12072,12124]
assert_stmt [12938,12990]
===
match
---
atom_expr [8361,8369]
atom_expr [8361,8369]
===
match
---
name: kubernetes_executor [7668,7687]
name: kubernetes_executor [7668,7687]
===
match
---
operator: = [2381,2382]
operator: = [2381,2382]
===
match
---
string: '"message": "pods \\"podname\\" is forbidden: exceeded quota: compute-resources, ' [5773,5855]
string: '"message": "pods \\"podname\\" is forbidden: exceeded quota: compute-resources, ' [5773,5855]
===
match
---
name: kube_config [11034,11045]
name: kube_config [11900,11911]
===
match
---
atom [12793,13080]
atom [13659,13946]
===
match
---
param [8617,8622]
param [9483,9488]
===
match
---
string: '/tests/kubernetes/pod_generator_base_with_secrets.yaml' [5507,5563]
string: '/tests/kubernetes/pod_generator_base_with_secrets.yaml' [5507,5563]
===
match
---
expr_stmt [4113,4172]
expr_stmt [4113,4172]
===
match
---
name: delete_worker_pods_on_failure [11102,11131]
name: delete_worker_pods_on_failure [11968,11997]
===
match
---
operator: , [9990,9991]
operator: , [10856,10857]
===
match
---
atom_expr [11994,12063]
atom_expr [12860,12929]
===
match
---
with_stmt [6715,7707]
with_stmt [6715,7707]
===
match
---
comparison [8893,8939]
comparison [9759,9805]
===
match
---
string: "airflow-worker" [13696,13712]
string: "airflow-worker" [14562,14578]
===
match
---
dotted_name [5300,5310]
dotted_name [5300,5310]
===
match
---
atom_expr [2940,3003]
atom_expr [2940,3003]
===
match
---
operator: == [8923,8925]
operator: == [9789,9791]
===
match
---
simple_stmt [4350,4383]
simple_stmt [4350,4383]
===
match
---
name: mock_delete_pod [11370,11385]
name: mock_delete_pod [12236,12251]
===
match
---
string: 'airflow' [7091,7100]
string: 'airflow' [7091,7100]
===
match
---
name: kubernetes_executor [11812,11831]
name: kubernetes_executor [12678,12697]
===
match
---
expr_stmt [6752,6798]
expr_stmt [6752,6798]
===
match
---
name: self [9969,9973]
name: self [10835,10839]
===
match
---
trailer [1877,1888]
trailer [1877,1888]
===
match
---
name: executor [8727,8735]
name: executor [9593,9601]
===
match
---
name: mock_sync [8078,8087]
name: mock_sync [8078,8087]
===
match
---
name: assert_not_called [11386,11403]
name: assert_not_called [12252,12269]
===
match
---
testlist_comp [2025,2046]
testlist_comp [2025,2046]
===
match
---
name: regex [2538,2543]
name: regex [2538,2543]
===
match
---
dictorsetmaker [12878,12942]
dictorsetmaker [13744,13808]
===
match
---
name: mock_delete_pod [12133,12148]
name: mock_delete_pod [12999,13014]
===
match
---
name: key [8915,8918]
name: key [9781,9784]
===
match
---
operator: = [5107,5108]
operator: = [5107,5108]
===
match
---
operator: , [12906,12907]
operator: , [13772,13773]
===
match
---
string: "-0ce114c45" [4428,4440]
string: "-0ce114c45" [4428,4440]
===
match
---
simple_stmt [13480,13516]
simple_stmt [14346,14382]
===
match
---
operator: = [8692,8693]
operator: = [9558,9559]
===
match
---
simple_stmt [1305,1350]
simple_stmt [1305,1350]
===
match
---
operator: , [12923,12924]
operator: , [13789,13790]
===
match
---
string: 'name' [12965,12971]
string: 'name' [13831,13837]
===
match
---
string: 'pod_template_file' [6669,6688]
string: 'pod_template_file' [6669,6688]
===
match
---
trailer [4163,4172]
trailer [4163,4172]
===
match
---
atom [12815,13011]
atom [13681,13877]
===
match
---
operator: } [13108,13109]
operator: } [13974,13975]
===
match
---
operator: @ [7780,7781]
operator: @ [7780,7781]
===
match
---
name: char_list [1805,1814]
name: char_list [1805,1814]
===
match
---
name: executor [9552,9560]
name: executor [10418,10426]
===
match
---
arglist [13818,13860]
arglist [14684,14726]
===
match
---
operator: * [1780,1781]
operator: * [1780,1781]
===
match
---
suite [3371,3884]
suite [3371,3884]
===
match
---
operator: = [1700,1701]
operator: = [1700,1701]
===
match
---
name: _gen_random_string [2193,2211]
name: _gen_random_string [2193,2211]
===
match
---
atom [13107,13109]
atom [13973,13975]
===
match
---
name: patch [7867,7872]
name: patch [7867,7872]
===
match
---
dictorsetmaker [13582,13594]
dictorsetmaker [14448,14460]
===
match
---
name: mock [8946,8950]
name: mock [9812,9816]
===
match
---
name: self [11807,11811]
name: self [12673,12677]
===
match
---
string: 'kubernetes python package is not installed' [3113,3157]
string: 'kubernetes python package is not installed' [3113,3157]
===
match
---
name: assert_called_once_with [9623,9646]
name: assert_called_once_with [10489,10512]
===
match
---
trailer [6310,6332]
trailer [6310,6332]
===
match
---
operator: = [10259,10260]
operator: = [11125,11126]
===
match
---
name: patch [10717,10722]
name: patch [11583,11588]
===
match
---
atom [11180,11227]
atom [12046,12093]
===
match
---
name: response [6075,6083]
name: response [6075,6083]
===
match
---
trailer [7021,7023]
trailer [7021,7023]
===
match
---
simple_stmt [8160,8181]
simple_stmt [8160,8181]
===
match
---
atom_expr [10992,11016]
atom_expr [11858,11882]
===
match
---
operator: = [11936,11937]
operator: = [12802,12803]
===
match
---
trailer [8735,8741]
trailer [9601,9607]
===
match
---
name: cases [2310,2315]
name: cases [2310,2315]
===
match
---
atom_expr [9473,9536]
atom_expr [10339,10402]
===
match
---
simple_stmt [1805,1855]
simple_stmt [1805,1855]
===
match
---
operator: , [7064,7065]
operator: , [7064,7065]
===
match
---
operator: @ [5221,5222]
operator: @ [5221,5222]
===
match
---
operator: { [13695,13696]
operator: { [14561,14562]
===
match
---
trailer [7704,7706]
trailer [7704,7706]
===
match
---
expr_stmt [4684,4771]
expr_stmt [4684,4771]
===
match
---
trailer [3816,3819]
trailer [3816,3819]
===
match
---
try_stmt [1058,1528]
try_stmt [1058,1528]
===
match
---
dotted_name [5222,5232]
dotted_name [5222,5232]
===
match
---
param [8089,8105]
param [8089,8105]
===
match
---
atom [1928,2150]
atom [1928,2150]
===
match
---
trailer [2470,2476]
trailer [2470,2476]
===
match
---
name: V1Pod [13614,13619]
name: V1Pod [14480,14485]
===
match
---
string: "MYDAGID" [2025,2034]
string: "MYDAGID" [2025,2034]
===
match
---
trailer [2531,2537]
trailer [2531,2537]
===
match
---
parameters [2598,2605]
parameters [2598,2605]
===
match
---
arglist [8277,8310]
arglist [8277,8310]
===
match
---
decorator [5299,5368]
decorator [5299,5368]
===
match
---
name: mock_kubeconfig [3728,3743]
name: mock_kubeconfig [3728,3743]
===
match
---
name: State [12022,12027]
name: State [12888,12893]
===
match
---
operator: , [1954,1955]
operator: , [1954,1955]
===
match
---
string: "dag_id" [13721,13729]
string: "dag_id" [14587,14595]
===
match
---
atom [8197,8381]
atom [8197,8381]
===
match
---
dotted_name [7862,7872]
dotted_name [7862,7872]
===
match
---
number: 0 [8920,8921]
number: 0 [9786,9787]
===
match
---
operator: , [8359,8360]
operator: , [8359,8360]
===
match
---
string: "task" [13749,13755]
string: "task" [14615,14621]
===
match
---
simple_stmt [976,1011]
simple_stmt [976,1011]
===
match
---
trailer [2228,2247]
trailer [2228,2247]
===
match
---
name: staticmethod [2322,2334]
name: staticmethod [2322,2334]
===
match
---
string: '' [1870,1872]
string: '' [1870,1872]
===
match
---
name: kubernetes_executor [10997,11016]
name: kubernetes_executor [11863,11882]
===
match
---
trailer [3611,3622]
trailer [3611,3622]
===
match
---
string: 'task_id' [9428,9437]
string: 'task_id' [10294,10303]
===
match
---
expr_stmt [12466,12642]
expr_stmt [13332,13508]
===
match
---
operator: = [1926,1927]
operator: = [1926,1927]
===
match
---
trailer [6778,6798]
trailer [6778,6798]
===
match
---
decorator [10711,10802]
decorator [11577,11668]
===
match
---
comparison [3571,3631]
comparison [3571,3631]
===
match
---
simple_stmt [10287,10341]
simple_stmt [11153,11207]
===
match
---
name: HTTPResponse [962,974]
name: HTTPResponse [962,974]
===
match
---
operator: == [3846,3848]
operator: == [3846,3848]
===
match
---
name: airflow [1125,1132]
name: airflow [1125,1132]
===
match
---
testlist_comp [2188,2258]
testlist_comp [2188,2258]
===
match
---
name: executor [10157,10165]
name: executor [11023,11031]
===
match
---
name: self [13491,13495]
name: self [14357,14361]
===
match
---
comparison [3760,3819]
comparison [3760,3819]
===
match
---
trailer [9573,9578]
trailer [10439,10444]
===
match
---
atom_expr [10460,10472]
atom_expr [11326,11338]
===
match
---
operator: { [12877,12878]
operator: { [13743,13744]
===
match
---
decorator [10560,10634]
decorator [11426,11500]
===
match
---
string: 'airflow.executors.kubernetes_executor.get_kube_client' [9035,9090]
string: 'airflow.executors.kubernetes_executor.get_kube_client' [9901,9956]
===
match
---
operator: = [13608,13609]
operator: = [14474,14475]
===
match
---
name: seed [1765,1769]
name: seed [1765,1769]
===
match
---
name: dag_id [4035,4041]
name: dag_id [4035,4041]
===
match
---
operator: @ [1625,1626]
operator: @ [1625,1626]
===
match
---
arglist [2755,2835]
arglist [2755,2835]
===
match
---
arglist [9496,9535]
arglist [10362,10401]
===
match
---
operator: = [6384,6385]
operator: = [6384,6385]
===
match
---
string: 'airflow.executors.base_executor.Stats.gauge' [7951,7996]
string: 'airflow.executors.base_executor.Stats.gauge' [7951,7996]
===
match
---
trailer [6729,6737]
trailer [6729,6737]
===
match
---
name: scheduler_job_id [12394,12410]
name: scheduler_job_id [13260,13276]
===
match
---
dictorsetmaker [12558,12617]
dictorsetmaker [13424,13483]
===
match
---
name: task_id [2994,3001]
name: task_id [2994,3001]
===
match
---
number: 0 [3550,3551]
number: 0 [3550,3551]
===
match
---
number: 0 [3553,3554]
number: 0 [3553,3554]
===
match
---
name: State [12112,12117]
name: State [12978,12983]
===
match
---
decorated [9673,10517]
decorated [10539,11383]
===
match
---
simple_stmt [801,811]
simple_stmt [801,811]
===
match
---
operator: , [10324,10325]
operator: , [11190,11191]
===
match
---
name: State [8926,8931]
name: State [9792,9797]
===
match
---
name: seed [2264,2268]
name: seed [2264,2268]
===
match
---
trailer [5023,5043]
trailer [5023,5043]
===
match
---
operator: , [2992,2993]
operator: , [2992,2993]
===
match
---
operator: , [2889,2890]
operator: , [2889,2890]
===
match
---
atom_expr [7603,7648]
atom_expr [7603,7648]
===
match
---
operator: = [5681,5682]
operator: = [5681,5682]
===
match
---
simple_stmt [3985,4043]
simple_stmt [3985,4043]
===
match
---
operator: == [4801,4803]
operator: == [4801,4803]
===
match
---
name: mock_api_client [6508,6523]
name: mock_api_client [6508,6523]
===
match
---
atom_expr [12739,12789]
atom_expr [13605,13655]
===
match
---
simple_stmt [4185,4232]
simple_stmt [4185,4232]
===
match
---
string: 'labels' [12867,12875]
string: 'labels' [13733,13741]
===
match
---
number: 0 [10454,10455]
number: 0 [11320,11321]
===
match
---
arith_expr [5493,5563]
arith_expr [5493,5563]
===
match
---
param [8040,8057]
param [8040,8057]
===
match
---
parameters [2359,2365]
parameters [2359,2365]
===
match
---
string: """         We should not adopt any tasks that were not assigned by the scheduler.         This ensures that there is no contention over pod management.         @param mock_kube_client:         @return:         """ [13256,13470]
string: """         We should not adopt any tasks that were not assigned by the scheduler.         This ensures that there is no contention over pod management.         @param mock_kube_client:         @return:         """ [14122,14336]
===
match
---
name: kubernetes_executor [8132,8151]
name: kubernetes_executor [8132,8151]
===
match
---
import_from [1120,1300]
import_from [1120,1300]
===
match
---
suite [1620,4821]
suite [1620,4821]
===
match
---
name: test_change_state_failed_pod_deletion [11661,11698]
name: test_change_state_failed_pod_deletion [12527,12564]
===
match
---
operator: = [7468,7469]
operator: = [7468,7469]
===
match
---
number: 1 [3878,3879]
number: 1 [3878,3879]
===
match
---
operator: = [9383,9384]
operator: = [10249,10250]
===
match
---
name: test_utils [1022,1032]
name: test_utils [1022,1032]
===
match
---
string: 'executor.queued_tasks' [8277,8300]
string: 'executor.queued_tasks' [8277,8300]
===
match
---
name: self [11708,11712]
name: self [12574,12578]
===
match
---
suite [11787,12201]
suite [12653,13067]
===
match
---
simple_stmt [787,801]
simple_stmt [787,801]
===
match
---
name: mock_kube_client [7257,7273]
name: mock_kube_client [7257,7273]
===
match
---
name: AirflowKubernetesScheduler [1478,1504]
name: AirflowKubernetesScheduler [1478,1504]
===
match
---
operator: , [13834,13835]
operator: , [14700,14701]
===
match
---
name: KubernetesExecutor [5046,5064]
name: KubernetesExecutor [5046,5064]
===
match
---
trailer [5099,5106]
trailer [5099,5106]
===
match
---
operator: = [12556,12557]
operator: = [13422,13423]
===
match
---
name: utils [1429,1434]
name: utils [1429,1434]
===
match
---
simple_stmt [4277,4338]
simple_stmt [4277,4338]
===
match
---
name: mock_kube_client [7417,7433]
name: mock_kube_client [7417,7433]
===
match
---
simple_stmt [10481,10517]
simple_stmt [11347,11383]
===
match
---
atom_expr [11264,11277]
atom_expr [12130,12143]
===
match
---
trailer [6830,6836]
trailer [6830,6836]
===
match
---
simple_stmt [1690,1705]
simple_stmt [1690,1705]
===
match
---
param [12314,12330]
param [13180,13196]
===
match
---
trailer [8131,8151]
trailer [8131,8151]
===
match
---
atom_expr [6075,6090]
atom_expr [6075,6090]
===
match
---
operator: , [11729,11730]
operator: , [12595,12596]
===
match
---
name: mock [8267,8271]
name: mock [8267,8271]
===
match
---
parameters [1904,1910]
parameters [1904,1910]
===
match
---
expr_stmt [11081,11139]
expr_stmt [11947,12005]
===
match
---
trailer [9646,9667]
trailer [10512,10533]
===
match
---
assert_stmt [7596,7648]
assert_stmt [7596,7648]
===
match
---
param [10014,10041]
param [10880,10907]
===
match
---
trailer [11033,11045]
trailer [11899,11911]
===
match
---
name: start [11916,11921]
name: start [12782,12787]
===
match
---
except_clause [1454,1472]
except_clause [1454,1472]
===
match
---
argument [12698,12705]
argument [13564,13571]
===
match
---
atom_expr [10955,10972]
atom_expr [11821,11838]
===
match
---
dotted_name [3061,3076]
dotted_name [3061,3076]
===
match
---
name: delete_worker_pods_on_failure [11861,11890]
name: delete_worker_pods_on_failure [12727,12756]
===
match
---
operator: } [13593,13594]
operator: } [14459,14460]
===
match
---
decorators [8945,9187]
decorators [9811,10053]
===
match
---
name: self [8034,8038]
name: self [8034,8038]
===
match
---
dotted_name [11412,11422]
dotted_name [12278,12288]
===
match
---
name: pod_name [2929,2937]
name: pod_name [2929,2937]
===
match
---
string: 'pod_id' [9516,9524]
string: 'pod_id' [10382,10390]
===
match
---
atom_expr [11025,11064]
atom_expr [11891,11930]
===
match
---
trailer [4457,4479]
trailer [4457,4479]
===
match
---
operator: , [8370,8371]
operator: , [8370,8371]
===
match
---
trailer [7641,7648]
trailer [7641,7648]
===
match
---
trailer [4196,4217]
trailer [4196,4217]
===
match
---
operator: , [11211,11212]
operator: , [12077,12078]
===
match
---
suite [12332,13110]
suite [13198,13976]
===
match
---
decorator [8945,9019]
decorator [9811,9885]
===
match
---
operator: = [3674,3675]
operator: = [3674,3675]
===
match
---
atom_expr [10224,10240]
atom_expr [11090,11106]
===
match
---
simple_stmt [9607,9668]
simple_stmt [10473,10534]
===
match
---
atom [13581,13595]
atom [14447,14461]
===
match
---
name: key [8752,8755]
name: key [9618,9621]
===
match
---
name: get_base_pod_from_template [3695,3721]
name: get_base_pod_from_template [3695,3721]
===
match
---
atom_expr [6105,6120]
atom_expr [6105,6120]
===
match
---
atom_expr [4703,4771]
atom_expr [4703,4771]
===
match
---
name: self [4062,4066]
name: self [4062,4066]
===
match
---
trailer [3552,3555]
trailer [3552,3555]
===
match
---
atom_expr [9607,9667]
atom_expr [10473,10533]
===
match
---
name: task_queue [7346,7356]
name: task_queue [7346,7356]
===
match
---
operator: , [2216,2217]
operator: , [2216,2217]
===
match
---
name: ANY [8307,8310]
name: ANY [8307,8310]
===
match
---
number: 1 [6921,6922]
number: 1 [6921,6922]
===
match
---
name: kube_config [11090,11101]
name: kube_config [11956,11967]
===
match
---
string: "airflow.executors.kubernetes_executor.KubeConfig" [3240,3290]
string: "airflow.executors.kubernetes_executor.KubeConfig" [3240,3290]
===
match
---
number: 0 [3623,3624]
number: 0 [3623,3624]
===
match
---
name: self [10068,10072]
name: self [10934,10938]
===
match
---
string: "my_dag_id_" [4359,4371]
string: "my_dag_id_" [4359,4371]
===
match
---
param [9227,9243]
param [10093,10109]
===
match
---
name: self [8694,8698]
name: self [9560,9564]
===
match
---
simple_stmt [6935,7159]
simple_stmt [6935,7159]
===
match
---
decorator [12206,12275]
decorator [13072,13141]
===
match
---
name: path [6691,6695]
name: path [6691,6695]
===
match
---
string: "my_dag_id" [4253,4264]
string: "my_dag_id" [4253,4264]
===
match
---
string: 'airflow.executors.kubernetes_executor.AirflowKubernetesScheduler.delete_pod' [10723,10800]
string: 'airflow.executors.kubernetes_executor.AirflowKubernetesScheduler.delete_pod' [11589,11666]
===
match
---
operator: + [4426,4427]
operator: + [4426,4427]
===
match
---
name: choice [1829,1835]
name: choice [1829,1835]
===
match
---
for_stmt [1713,1855]
for_stmt [1713,1855]
===
match
---
name: random [1822,1828]
name: random [1822,1828]
===
match
---
name: seed [2212,2216]
name: seed [2212,2216]
===
match
---
operator: = [13550,13551]
operator: = [14416,14417]
===
match
---
operator: , [3945,3946]
operator: , [3945,3946]
===
match
---
name: mock_kubernetes_job_watcher [9266,9293]
name: mock_kubernetes_job_watcher [10132,10159]
===
match
---
file_input [787,13967]
file_input [787,14833]
===
match
---
operator: , [9655,9656]
operator: , [10521,10522]
===
match
---
name: kubernetes_executor [6779,6798]
name: kubernetes_executor [6779,6798]
===
match
---
expr_stmt [2375,2451]
expr_stmt [2375,2451]
===
match
---
trailer [1835,1853]
trailer [1835,1853]
===
match
---
trailer [3813,3816]
trailer [3813,3816]
===
match
---
arith_expr [4402,4440]
arith_expr [4402,4440]
===
match
---
name: called [7642,7648]
name: called [7642,7648]
===
match
---
name: FAILED [10383,10389]
name: FAILED [11249,11255]
===
match
---
operator: } [13964,13965]
operator: } [14830,14831]
===
match
---
expr_stmt [8189,8381]
expr_stmt [8189,8381]
===
match
---
operator: , [11751,11752]
operator: , [12617,12618]
===
match
---
operator: } [12456,12457]
operator: } [13322,13323]
===
match
---
name: mock [7713,7717]
name: mock [7713,7717]
===
match
---
funcdef [10806,11406]
funcdef [11672,12272]
===
match
---
name: _cases [2907,2913]
name: _cases [2907,2913]
===
match
---
name: pod_generator [4703,4716]
name: pod_generator [4703,4716]
===
match
---
suite [2606,2733]
suite [2606,2733]
===
match
---
name: self [8127,8131]
name: self [8127,8131]
===
match
---
simple_stmt [13604,13781]
simple_stmt [14470,14647]
===
match
---
param [2360,2364]
param [2360,2364]
===
match
---
atom_expr [2160,2293]
atom_expr [2160,2293]
===
match
---
operator: , [8840,8841]
operator: , [9706,9707]
===
match
---
name: PodGenerator [2940,2952]
name: PodGenerator [2940,2952]
===
match
---
trailer [12100,12105]
trailer [12966,12971]
===
match
---
parameters [4995,5001]
parameters [4995,5001]
===
match
---
name: api_client [6594,6604]
name: api_client [6594,6604]
===
match
---
name: pod_template_file_path [3451,3473]
name: pod_template_file_path [3451,3473]
===
match
---
simple_stmt [6577,6623]
simple_stmt [6577,6623]
===
match
---
operator: = [13852,13853]
operator: = [14718,14719]
===
match
---
trailer [8271,8276]
trailer [8271,8276]
===
match
---
name: pod_ids [13941,13948]
name: pod_ids [14807,14814]
===
match
---
trailer [7576,7581]
trailer [7576,7581]
===
match
---
operator: , [12696,12697]
operator: , [13562,13563]
===
match
---
operator: , [12598,12599]
operator: , [13464,13465]
===
match
---
operator: { [12845,12846]
operator: { [13711,13712]
===
match
---
atom [2061,2088]
atom [2061,2088]
===
insert-node
---
name: TestKubernetesExecutor [4829,4851]
to
classdef [4823,13967]
at 0
===
insert-tree
---
simple_stmt [4876,4981]
    string: """     Tests if an ApiException from the Kube Client will cause the task to     be rescheduled.     """ [4876,4980]
to
suite [4871,13967]
at 0
===
insert-tree
---
decorated [8436,9297]
    decorators [8436,8583]
        decorator [8436,8510]
            operator: @ [8436,8437]
            dotted_name [8437,8447]
                name: mock [8437,8441]
                name: patch [8442,8447]
            string: 'airflow.executors.kubernetes_executor.KubernetesJobWatcher' [8448,8508]
        decorator [8514,8583]
            operator: @ [8514,8515]
            dotted_name [8515,8525]
                name: mock [8515,8519]
                name: patch [8520,8525]
            string: 'airflow.executors.kubernetes_executor.get_kube_client' [8526,8581]
    funcdef [8587,9297]
        name: test_invalid_executor_config [8591,8619]
        parameters [8619,8676]
            param [8620,8625]
                name: self [8620,8624]
                operator: , [8624,8625]
            param [8626,8647]
                name: mock_get_kube_client [8626,8646]
                operator: , [8646,8647]
            param [8648,8675]
                name: mock_kubernetes_job_watcher [8648,8675]
        suite [8677,9297]
            simple_stmt [8686,8722]
                expr_stmt [8686,8721]
                    name: executor [8686,8694]
                    operator: = [8695,8696]
                    atom_expr [8697,8721]
                        name: self [8697,8701]
                        trailer [8701,8721]
                            name: kubernetes_executor [8702,8721]
            simple_stmt [8730,8747]
                atom_expr [8730,8746]
                    name: executor [8730,8738]
                    trailer [8738,8744]
                        name: start [8739,8744]
                    trailer [8744,8746]
            simple_stmt [8756,8791]
                assert_stmt [8756,8790]
                    comparison [8763,8790]
                        atom_expr [8763,8784]
                            name: executor [8763,8771]
                            trailer [8771,8784]
                                name: event_buffer [8772,8784]
                        operator: == [8785,8787]
                        atom [8788,8790]
                            operator: { [8788,8789]
                            operator: } [8789,8790]
            simple_stmt [8799,9202]
                atom_expr [8799,9201]
                    name: executor [8799,8807]
                    trailer [8807,8821]
                        name: execute_async [8808,8821]
                    trailer [8821,9201]
                        arglist [8835,9191]
                            argument [8835,8876]
                                name: key [8835,8838]
                                operator: = [8838,8839]
                                atom [8839,8876]
                                    testlist_comp [8840,8875]
                                        string: 'dag' [8840,8845]
                                        operator: , [8845,8846]
                                        string: 'task' [8847,8853]
                                        operator: , [8853,8854]
                                        atom_expr [8855,8872]
                                            name: datetime [8855,8863]
                                            trailer [8863,8870]
                                                name: utcnow [8864,8870]
                                            trailer [8870,8872]
                                        operator: , [8872,8873]
                                        number: 1 [8874,8875]
                            operator: , [8876,8877]
                            argument [8890,8900]
                                name: queue [8890,8895]
                                operator: = [8895,8896]
                            operator: , [8900,8901]
                            argument [8914,8975]
                                name: command [8914,8921]
                                operator: = [8921,8922]
                                atom [8922,8975]
                                    testlist_comp [8923,8974]
                                        string: 'airflow' [8923,8932]
                                        operator: , [8932,8933]
                                        string: 'tasks' [8934,8941]
                                        operator: , [8941,8942]
                                        string: 'run' [8943,8948]
                                        operator: , [8948,8949]
                                        string: 'true' [8950,8956]
                                        operator: , [8956,8957]
                                        string: 'some_parameter' [8958,8974]
                            operator: , [8975,8976]
                            argument [8989,9190]
                                name: executor_config [8989,9004]
                                operator: = [9004,9005]
                                atom_expr [9005,9190]
                                    name: k8s [9005,9008]
                                    trailer [9008,9014]
                                        name: V1Pod [9009,9014]
                                    trailer [9014,9190]
                                        argument [9032,9176]
                                            name: spec [9032,9036]
                                            operator: = [9036,9037]
                                            atom_expr [9037,9176]
                                                name: k8s [9037,9040]
                                                trailer [9040,9050]
                                                    name: V1PodSpec [9041,9050]
                                                trailer [9050,9176]
                                                    argument [9072,9158]
                                                        name: containers [9072,9082]
                                                        operator: = [9082,9083]
                                                        atom [9083,9158]
                                                            atom_expr [9084,9157]
                                                                name: k8s [9084,9087]
                                                                trailer [9087,9099]
                                                                    name: V1Container [9088,9099]
                                                                trailer [9099,9157]
                                                                    arglist [9100,9156]
                                                                        argument [9100,9111]
                                                                            name: name [9100,9104]
                                                                            operator: = [9104,9105]
                                                                            string: "base" [9105,9111]
                                                                        operator: , [9111,9112]
                                                                        argument [9113,9128]
                                                                            name: image [9113,9118]
                                                                            operator: = [9118,9119]
                                                                            string: "myimage" [9119,9128]
                                                                        operator: , [9128,9129]
                                                                        argument [9130,9156]
                                                                            name: image_pull_policy [9130,9147]
                                                                            operator: = [9147,9148]
                                                                            string: "Always" [9148,9156]
                            operator: , [9190,9191]
            simple_stmt [9211,9297]
                assert_stmt [9211,9296]
                    comparison [9218,9296]
                        atom_expr [9218,9260]
                            name: list [9218,9222]
                            trailer [9222,9254]
                                atom_expr [9223,9253]
                                    name: executor [9223,9231]
                                    trailer [9231,9244]
                                        name: event_buffer [9232,9244]
                                    trailer [9244,9251]
                                        name: values [9245,9251]
                                    trailer [9251,9253]
                            trailer [9254,9257]
                                number: 0 [9255,9256]
                            trailer [9257,9260]
                                number: 1 [9258,9259]
                        operator: == [9261,9263]
                        string: "Invalid executor_config passed" [9264,9296]
to
suite [4871,13967]
at 5
===
delete-node
---
name: TestKubernetesExecutor [4829,4851]
===
===
delete-tree
---
simple_stmt [4876,4981]
    string: """     Tests if an ApiException from the Kube Client will cause the task to     be rescheduled.     """ [4876,4980]
