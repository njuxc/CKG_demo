===
match
---
name: dag [14591,14594]
name: dag [14591,14594]
===
match
---
name: self [59048,59052]
name: self [59100,59104]
===
match
---
atom_expr [44936,44947]
atom_expr [44988,44999]
===
match
---
simple_stmt [18862,18894]
simple_stmt [18862,18894]
===
match
---
argument [60311,60333]
argument [60363,60385]
===
match
---
name: Optional [52311,52319]
name: Optional [52363,52371]
===
match
---
trailer [74187,74405]
trailer [74239,74457]
===
match
---
decorator [77371,77388]
decorator [77423,77440]
===
match
---
operator: = [67980,67981]
operator: = [68032,68033]
===
match
---
dotted_name [48134,48165]
dotted_name [48186,48217]
===
match
---
atom_expr [40186,40201]
atom_expr [40186,40201]
===
match
---
name: prev_ti [30229,30236]
name: prev_ti [30229,30236]
===
match
---
name: max_tries [9806,9815]
name: max_tries [9806,9815]
===
match
---
name: try_number [68598,68608]
name: try_number [68650,68660]
===
match
---
if_stmt [20455,20533]
if_stmt [20455,20533]
===
match
---
argument [15121,15166]
argument [15121,15166]
===
match
---
name: ti [80396,80398]
name: ti [80448,80450]
===
match
---
if_stmt [18498,18544]
if_stmt [18498,18544]
===
match
---
name: test_mode [44270,44279]
name: test_mode [44322,44331]
===
match
---
name: OperationalError [1377,1393]
name: OperationalError [1377,1393]
===
match
---
operator: , [49842,49843]
operator: , [49894,49895]
===
match
---
operator: , [64575,64576]
operator: , [64627,64628]
===
match
---
atom_expr [37456,37504]
atom_expr [37456,37504]
===
match
---
name: and_ [6665,6669]
name: and_ [6665,6669]
===
match
---
comparison [73925,73961]
comparison [73977,74013]
===
match
---
argument [46243,46258]
argument [46295,46310]
===
match
---
testlist_comp [18698,18719]
testlist_comp [18698,18719]
===
match
---
name: self [70881,70885]
name: self [70933,70937]
===
match
---
param [15464,15476]
param [15464,15476]
===
match
---
operator: , [48896,48897]
operator: , [48948,48949]
===
match
---
atom_expr [22475,22484]
atom_expr [22475,22484]
===
match
---
operator: , [15605,15606]
operator: , [15605,15606]
===
match
---
comparison [52892,52928]
comparison [52944,52980]
===
match
---
atom_expr [40378,40397]
atom_expr [40378,40397]
===
match
---
name: ti [80502,80504]
name: ti [80554,80556]
===
match
---
name: self [40277,40281]
name: self [40277,40281]
===
match
---
atom_expr [35433,35444]
atom_expr [35433,35444]
===
match
---
operator: = [35886,35887]
operator: = [35886,35887]
===
match
---
atom_expr [54551,54564]
atom_expr [54603,54616]
===
match
---
trailer [33615,33669]
trailer [33615,33669]
===
match
---
operator: = [39866,39867]
operator: = [39866,39867]
===
match
---
trailer [55380,55384]
trailer [55432,55436]
===
match
---
trailer [44969,44975]
trailer [45021,45027]
===
match
---
atom_expr [53710,53723]
atom_expr [53762,53775]
===
match
---
name: exception [71571,71580]
name: exception [71623,71632]
===
match
---
name: has_task [5333,5341]
name: has_task [5333,5341]
===
match
---
operator: = [35811,35812]
operator: = [35811,35812]
===
match
---
name: self [48778,48782]
name: self [48830,48834]
===
match
---
operator: = [52748,52749]
operator: = [52800,52801]
===
match
---
trailer [47227,47235]
trailer [47279,47287]
===
match
---
trailer [7722,7737]
trailer [7722,7737]
===
match
---
number: 1 [60686,60687]
number: 1 [60738,60739]
===
match
---
name: _queue [81364,81370]
name: _queue [81416,81422]
===
match
---
name: failed [32125,32131]
name: failed [32125,32131]
===
match
---
atom_expr [11886,11925]
atom_expr [11886,11925]
===
match
---
trailer [64252,64283]
trailer [64304,64335]
===
match
---
name: XCom [23852,23856]
name: XCom [23852,23856]
===
match
---
decorated [8267,8522]
decorated [8267,8522]
===
match
---
atom_expr [27224,27233]
atom_expr [27224,27233]
===
match
---
atom_expr [42879,42891]
atom_expr [42931,42943]
===
match
---
name: session [35101,35108]
name: session [35101,35108]
===
match
---
expr_stmt [21919,21950]
expr_stmt [21919,21950]
===
match
---
name: task_id [74247,74254]
name: task_id [74299,74306]
===
match
---
fstring_end: ' [56946,56947]
fstring_end: ' [56998,56999]
===
match
---
name: task [71793,71797]
name: task [71845,71849]
===
match
---
operator: @ [35059,35060]
operator: @ [35059,35060]
===
match
---
operator: @ [80907,80908]
operator: @ [80959,80960]
===
match
---
tfpdef [15890,15899]
tfpdef [15890,15899]
===
match
---
name: task_id [79191,79198]
name: task_id [79243,79250]
===
match
---
argument [68521,68568]
argument [68573,68620]
===
match
---
arglist [4616,4630]
arglist [4616,4630]
===
match
---
name: self [19115,19119]
name: self [19115,19119]
===
match
---
if_stmt [71872,72041]
if_stmt [71924,72093]
===
match
---
name: Exception [52150,52159]
name: Exception [52202,52211]
===
match
---
simple_stmt [72518,72602]
simple_stmt [72570,72654]
===
match
---
name: datetime [11069,11077]
name: datetime [11069,11077]
===
match
---
expr_stmt [40835,40855]
expr_stmt [40804,40824]
===
match
---
trailer [50939,50945]
trailer [50991,50997]
===
match
---
suite [37764,37818]
suite [37764,37818]
===
match
---
subscriptlist [56083,56097]
subscriptlist [56135,56149]
===
match
---
if_stmt [49603,50339]
if_stmt [49655,50391]
===
match
---
trailer [82668,82677]
trailer [82720,82729]
===
match
---
import_from [1202,1259]
import_from [1202,1259]
===
match
---
argument [76573,76590]
argument [76625,76642]
===
match
---
name: jinja_env [71776,71785]
name: jinja_env [71828,71837]
===
match
---
trailer [72564,72590]
trailer [72616,72642]
===
match
---
param [25384,25389]
param [25384,25389]
===
match
---
name: self [40186,40190]
name: self [40186,40190]
===
match
---
suite [4151,4199]
suite [4151,4199]
===
match
---
funcdef [41606,45648]
funcdef [41575,45700]
===
match
---
atom_expr [52619,52643]
atom_expr [52671,52695]
===
match
---
name: __init__ [63770,63778]
name: __init__ [63822,63830]
===
match
---
name: task_copy [49606,49615]
name: task_copy [49658,49667]
===
match
---
name: TaskInstance [81632,81644]
name: TaskInstance [81684,81696]
===
match
---
operator: = [77251,77252]
operator: = [77303,77304]
===
match
---
parameters [81329,81335]
parameters [81381,81387]
===
match
---
name: Variable [64244,64252]
name: Variable [64296,64304]
===
match
---
operator: = [54589,54590]
operator: = [54641,54642]
===
match
---
name: self [48371,48375]
name: self [48423,48427]
===
match
---
name: __init__ [62844,62852]
name: __init__ [62896,62904]
===
match
---
trailer [23404,23416]
trailer [23404,23416]
===
match
---
name: TaskInstance [25997,26009]
name: TaskInstance [25997,26009]
===
match
---
name: session [20596,20603]
name: session [20596,20603]
===
match
---
name: task_id_by_key [6085,6099]
name: task_id_by_key [6085,6099]
===
match
---
name: dag_run [62548,62555]
name: dag_run [62600,62607]
===
match
---
name: self [77841,77845]
name: self [77893,77897]
===
match
---
trailer [51497,51505]
trailer [51549,51557]
===
match
---
arglist [4336,4352]
arglist [4336,4352]
===
match
---
name: property [81377,81385]
name: property [81429,81437]
===
match
---
trailer [43553,43561]
trailer [43605,43613]
===
match
---
atom_expr [77071,77081]
atom_expr [77123,77133]
===
match
---
import_from [1260,1349]
import_from [1260,1349]
===
match
---
name: task_id [78970,78977]
name: task_id [79022,79029]
===
match
---
fstring_string: <TaskInstance:  [32935,32950]
fstring_string: <TaskInstance:  [32935,32950]
===
match
---
trailer [35988,35993]
trailer [35988,35993]
===
match
---
atom_expr [22730,22738]
atom_expr [22730,22738]
===
match
---
atom [7649,7674]
atom [7649,7674]
===
match
---
arith_expr [70881,70900]
arith_expr [70933,70952]
===
match
---
atom_expr [30371,30388]
atom_expr [30371,30388]
===
match
---
atom [72912,72945]
atom [72964,72997]
===
match
---
string: '%Y-%m-%d' [61842,61852]
string: '%Y-%m-%d' [61894,61904]
===
match
---
suite [27795,27879]
suite [27795,27879]
===
match
---
operator: , [51934,51935]
operator: , [51986,51987]
===
match
---
trailer [18530,18543]
trailer [18530,18543]
===
match
---
name: dump [4611,4615]
name: dump [4611,4615]
===
match
---
name: get_previous_execution_date [29066,29093]
name: get_previous_execution_date [29066,29093]
===
match
---
name: attr [41415,41419]
name: attr [41384,41388]
===
match
---
name: _set_context [77931,77943]
name: _set_context [77983,77995]
===
match
---
trailer [11664,11672]
trailer [11664,11672]
===
match
---
atom [65847,65955]
atom [65899,66007]
===
match
---
name: TaskInstanceKey [24128,24143]
name: TaskInstanceKey [24128,24143]
===
match
---
operator: = [60731,60732]
operator: = [60783,60784]
===
match
---
operator: = [38240,38241]
operator: = [38240,38241]
===
match
---
name: from_string [71252,71263]
name: from_string [71304,71315]
===
match
---
operator: = [15195,15196]
operator: = [15195,15196]
===
match
---
name: error [4237,4242]
name: error [4237,4242]
===
match
---
operator: = [17913,17914]
operator: = [17913,17914]
===
match
---
name: e [43212,43213]
name: e [43264,43265]
===
match
---
name: reduced [8285,8292]
name: reduced [8285,8292]
===
match
---
trailer [80094,80100]
trailer [80146,80152]
===
match
---
trailer [72731,72736]
trailer [72783,72788]
===
match
---
operator: = [72211,72212]
operator: = [72263,72264]
===
match
---
atom_expr [11276,11285]
atom_expr [11276,11285]
===
match
---
trailer [5207,5216]
trailer [5207,5216]
===
match
---
name: dag_id [60327,60333]
name: dag_id [60379,60385]
===
match
---
trailer [49333,49335]
trailer [49385,49387]
===
match
---
not_test [27677,27696]
not_test [27677,27696]
===
match
---
name: self [20383,20387]
name: self [20383,20387]
===
match
---
trailer [43921,43933]
trailer [43973,43985]
===
match
---
not_test [4025,4033]
not_test [4025,4033]
===
match
---
name: kubernetes [2910,2920]
name: kubernetes [2910,2920]
===
match
---
atom_expr [3149,3163]
atom_expr [3149,3163]
===
match
---
decorated [13827,13942]
decorated [13827,13942]
===
match
---
operator: @ [12411,12412]
operator: @ [12411,12412]
===
match
---
name: cmd [18300,18303]
name: cmd [18300,18303]
===
match
---
suite [62363,62403]
suite [62415,62455]
===
match
---
except_clause [66610,66662]
except_clause [66662,66714]
===
match
---
simple_stmt [3019,3077]
simple_stmt [3019,3077]
===
match
---
name: dag_ids [76545,76552]
name: dag_ids [76597,76604]
===
match
---
name: TaskInstance [79051,79063]
name: TaskInstance [79103,79115]
===
match
---
expr_stmt [5456,5483]
expr_stmt [5456,5483]
===
match
---
name: with_for_update [82289,82304]
name: with_for_update [82341,82356]
===
match
---
name: actual_start_date [55091,55108]
name: actual_start_date [55143,55160]
===
match
---
tfpdef [15615,15636]
tfpdef [15615,15636]
===
match
---
argument [59343,59354]
argument [59395,59406]
===
match
---
name: self [40625,40629]
name: self [40625,40629]
===
match
---
return_stmt [59687,59696]
return_stmt [59739,59748]
===
match
---
atom_expr [41505,41535]
atom_expr [41474,41504]
===
match
---
operator: @ [29645,29646]
operator: @ [29645,29646]
===
match
---
atom_expr [81046,81062]
atom_expr [81098,81114]
===
match
---
trailer [10279,10305]
trailer [10279,10305]
===
match
---
simple_stmt [3101,3118]
simple_stmt [3101,3118]
===
match
---
name: context [49488,49495]
name: context [49540,49547]
===
match
---
parameters [81091,81097]
parameters [81143,81149]
===
match
---
arglist [21563,21712]
arglist [21563,21712]
===
match
---
name: os [71072,71074]
name: os [71124,71126]
===
match
---
expr_stmt [3202,3235]
expr_stmt [3202,3235]
===
match
---
name: property [80989,80997]
name: property [81041,81049]
===
match
---
expr_stmt [33729,34014]
expr_stmt [33729,34014]
===
match
---
arglist [71041,71115]
arglist [71093,71167]
===
match
---
operator: } [42876,42877]
operator: } [42928,42929]
===
match
---
atom [18228,18257]
atom [18228,18257]
===
match
---
operator: @ [41559,41560]
operator: @ [41528,41529]
===
match
---
name: ti [22525,22527]
name: ti [22525,22527]
===
match
---
name: globals [82398,82405]
name: globals [82450,82457]
===
match
---
operator: = [62181,62182]
operator: = [62233,62234]
===
match
---
name: ignore_schedule [27681,27696]
name: ignore_schedule [27681,27696]
===
match
---
trailer [7189,7201]
trailer [7189,7201]
===
match
---
name: self [43084,43088]
name: self [43136,43140]
===
match
---
simple_stmt [48778,48817]
simple_stmt [48830,48869]
===
match
---
operator: = [62547,62548]
operator: = [62599,62600]
===
match
---
name: airflow [82538,82545]
name: airflow [82590,82597]
===
match
---
name: hr_line_break [40639,40652]
name: hr_line_break [40639,40652]
===
match
---
subscriptlist [52326,52340]
subscriptlist [52378,52392]
===
match
---
trailer [18965,18976]
trailer [18965,18976]
===
match
---
decorators [41559,41602]
decorators [41528,41571]
===
match
---
trailer [45264,45279]
trailer [45316,45331]
===
match
---
name: unixname [12014,12022]
name: unixname [12014,12022]
===
match
---
operator: = [70132,70133]
operator: = [70184,70185]
===
match
---
name: get_hostname [42772,42784]
name: get_hostname [42741,42753]
===
match
---
name: in_ [79126,79129]
name: in_ [79178,79181]
===
match
---
atom_expr [47494,47531]
atom_expr [47546,47583]
===
match
---
name: scheduler_job_id [68825,68841]
name: scheduler_job_id [68877,68893]
===
match
---
atom_expr [56119,56133]
atom_expr [56171,56185]
===
match
---
argument [10949,10968]
argument [10949,10968]
===
match
---
name: schedulable_ti [47447,47461]
name: schedulable_ti [47499,47513]
===
match
---
name: state [81086,81091]
name: state [81138,81143]
===
match
---
trailer [24280,24295]
trailer [24280,24295]
===
match
---
comparison [35007,35053]
comparison [35007,35053]
===
match
---
name: var [62881,62884]
name: var [62933,62936]
===
match
---
atom_expr [76976,77006]
atom_expr [77028,77058]
===
match
---
simple_stmt [22774,22792]
simple_stmt [22774,22792]
===
match
---
name: log [40505,40508]
name: log [40505,40508]
===
match
---
string: '' [61904,61906]
string: '' [61956,61958]
===
match
---
operator: , [58462,58463]
operator: , [58514,58515]
===
match
---
name: task [54891,54895]
name: task [54943,54947]
===
match
---
simple_stmt [61737,61759]
simple_stmt [61789,61811]
===
match
---
name: exceptions [1628,1638]
name: exceptions [1628,1638]
===
match
---
simple_stmt [47548,47630]
simple_stmt [47600,47682]
===
match
---
parameters [24353,24385]
parameters [24353,24385]
===
match
---
name: test_mode [59100,59109]
name: test_mode [59152,59161]
===
match
---
simple_stmt [52673,52711]
simple_stmt [52725,52763]
===
match
---
atom_expr [42756,42769]
atom_expr [42725,42738]
===
match
---
name: airflow [7268,7275]
name: airflow [7268,7275]
===
match
---
atom_expr [11745,11767]
atom_expr [11745,11767]
===
match
---
name: self [26183,26187]
name: self [26183,26187]
===
match
---
argument [68669,68693]
argument [68721,68745]
===
match
---
name: self [26063,26067]
name: self [26063,26067]
===
match
---
atom_expr [34970,34980]
atom_expr [34970,34980]
===
match
---
name: self [59862,59866]
name: self [59914,59918]
===
match
---
name: context [51681,51688]
name: context [51733,51740]
===
match
---
trailer [8496,8520]
trailer [8496,8520]
===
match
---
trailer [65588,65598]
trailer [65640,65650]
===
match
---
trailer [61890,61898]
trailer [61942,61950]
===
match
---
name: context [51135,51142]
name: context [51187,51194]
===
match
---
trailer [32053,32062]
trailer [32053,32062]
===
match
---
trailer [26100,26108]
trailer [26100,26108]
===
match
---
trailer [79814,79821]
trailer [79866,79873]
===
match
---
trailer [14536,14540]
trailer [14536,14540]
===
match
---
trailer [33807,33814]
trailer [33807,33814]
===
match
---
atom_expr [7844,7857]
atom_expr [7844,7857]
===
match
---
name: relationship [1436,1448]
name: relationship [1436,1448]
===
match
---
name: bool [35914,35918]
name: bool [35914,35918]
===
match
---
operator: = [27249,27250]
operator: = [27249,27250]
===
match
---
name: Any [73162,73165]
name: Any [73214,73217]
===
match
---
trailer [23385,23397]
trailer [23385,23397]
===
match
---
name: self [48981,48985]
name: self [49033,49037]
===
match
---
name: dag_id [78779,78785]
name: dag_id [78831,78837]
===
match
---
param [14028,14047]
param [14028,14047]
===
match
---
atom_expr [26216,26270]
atom_expr [26216,26270]
===
match
---
trailer [15868,15873]
trailer [15868,15873]
===
match
---
simple_stmt [7477,7543]
simple_stmt [7477,7543]
===
match
---
expr_stmt [3165,3201]
expr_stmt [3165,3201]
===
match
---
name: task_id [19335,19342]
name: task_id [19335,19342]
===
match
---
name: self [57131,57135]
name: self [57183,57187]
===
match
---
name: task_id [79362,79369]
name: task_id [79414,79421]
===
match
---
name: self [13241,13245]
name: self [13241,13245]
===
match
---
operator: = [76552,76553]
operator: = [76604,76605]
===
match
---
name: prev_execution_date [61813,61832]
name: prev_execution_date [61865,61884]
===
match
---
atom_expr [46127,46138]
atom_expr [46179,46190]
===
match
---
string: 'html_content_template' [72220,72243]
string: 'html_content_template' [72272,72295]
===
match
---
simple_stmt [80789,80817]
simple_stmt [80841,80869]
===
match
---
operator: = [54454,54455]
operator: = [54506,54507]
===
match
---
name: force_fail [56150,56160]
name: force_fail [56202,56212]
===
match
---
argument [74313,74365]
argument [74365,74417]
===
match
---
trailer [21939,21950]
trailer [21939,21950]
===
match
---
arglist [79285,79436]
arglist [79337,79488]
===
match
---
return_stmt [79022,79230]
return_stmt [79074,79282]
===
match
---
operator: , [6730,6731]
operator: , [6730,6731]
===
match
---
operator: , [11743,11744]
operator: , [11743,11744]
===
match
---
atom_expr [66480,66526]
atom_expr [66532,66578]
===
match
---
fstring_string: __ [62308,62310]
fstring_string: __ [62360,62362]
===
match
---
fstring_expr [62326,62337]
fstring_expr [62378,62389]
===
match
---
trailer [6915,6921]
trailer [6915,6921]
===
match
---
param [74698,74722]
param [74750,74774]
===
match
---
trailer [30379,30388]
trailer [30379,30388]
===
match
---
simple_stmt [6551,7140]
simple_stmt [6551,7140]
===
match
---
trailer [22743,22747]
trailer [22743,22747]
===
match
---
simple_stmt [32384,32426]
simple_stmt [32384,32426]
===
match
---
name: task [44936,44940]
name: task [44988,44992]
===
match
---
name: base_url [19282,19290]
name: base_url [19282,19290]
===
match
---
arglist [30582,30800]
arglist [30582,30800]
===
match
---
name: self [24895,24899]
name: self [24895,24899]
===
match
---
suite [72975,73009]
suite [73027,73061]
===
match
---
trailer [47661,47663]
trailer [47713,47715]
===
match
---
dotted_name [2495,2526]
dotted_name [2495,2526]
===
match
---
name: xcom [77308,77312]
name: xcom [77360,77364]
===
match
---
trailer [34729,34734]
trailer [34729,34734]
===
match
---
name: session [54590,54597]
name: session [54642,54649]
===
match
---
operator: = [9997,9998]
operator: = [9997,9998]
===
match
---
arith_expr [19571,19791]
arith_expr [19571,19791]
===
match
---
tfpdef [35936,35957]
tfpdef [35936,35957]
===
match
---
name: task_id [26010,26017]
name: task_id [26010,26017]
===
match
---
simple_stmt [49728,49747]
simple_stmt [49780,49799]
===
match
---
name: TaskInstanceKey [7912,7927]
name: TaskInstanceKey [7912,7927]
===
match
---
name: try_number [13182,13192]
name: try_number [13182,13192]
===
match
---
operator: { [62295,62296]
operator: { [62347,62348]
===
match
---
name: prev_ds_nodash [61737,61751]
name: prev_ds_nodash [61789,61803]
===
match
---
operator: , [53932,53933]
operator: , [53984,53985]
===
match
---
operator: = [78310,78311]
operator: = [78362,78363]
===
match
---
atom_expr [3897,3918]
atom_expr [3897,3918]
===
match
---
name: dump [4393,4397]
name: dump [4393,4397]
===
match
---
operator: , [1338,1339]
operator: , [1338,1339]
===
match
---
param [14273,14283]
param [14273,14283]
===
match
---
expr_stmt [11692,11768]
expr_stmt [11692,11768]
===
match
---
fstring_expr [19058,19072]
fstring_expr [19058,19072]
===
match
---
name: self [23592,23596]
name: self [23592,23596]
===
match
---
name: self [35659,35663]
name: self [35659,35663]
===
match
---
name: prev_execution_date [61276,61295]
name: prev_execution_date [61328,61347]
===
match
---
trailer [38606,38613]
trailer [38606,38613]
===
match
---
name: delete [54341,54347]
name: delete [54393,54399]
===
match
---
trailer [37568,37607]
trailer [37568,37607]
===
match
---
return_stmt [26315,26360]
return_stmt [26315,26360]
===
match
---
atom_expr [77649,77660]
atom_expr [77701,77712]
===
match
---
atom_expr [11158,11169]
atom_expr [11158,11169]
===
match
---
simple_stmt [67893,67921]
simple_stmt [67945,67973]
===
match
---
name: self [55457,55461]
name: self [55509,55513]
===
match
---
comparison [20298,20334]
comparison [20298,20334]
===
match
---
atom_expr [40835,40848]
atom_expr [40804,40817]
===
match
---
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [70025,70087]
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [70077,70139]
===
match
---
trailer [49642,49644]
trailer [49694,49696]
===
match
---
decorated [64096,64472]
decorated [64148,64524]
===
match
---
parameters [26406,26480]
parameters [26406,26480]
===
match
---
name: AirflowSmartSensorException [43181,43208]
name: AirflowSmartSensorException [43233,43260]
===
match
---
simple_stmt [72459,72510]
simple_stmt [72511,72562]
===
match
---
suite [7254,7434]
suite [7254,7434]
===
match
---
name: self [48058,48062]
name: self [48110,48114]
===
match
---
trailer [61329,61344]
trailer [61381,61396]
===
match
---
name: self [24833,24837]
name: self [24833,24837]
===
match
---
atom_expr [32510,32558]
atom_expr [32510,32558]
===
match
---
name: start_date [30249,30259]
name: start_date [30249,30259]
===
match
---
name: self [63090,63094]
name: self [63142,63146]
===
match
---
operator: = [39849,39850]
operator: = [39849,39850]
===
match
---
operator: = [54488,54489]
operator: = [54540,54541]
===
match
---
argument [79263,79476]
argument [79315,79528]
===
match
---
operator: { [32950,32951]
operator: { [32950,32951]
===
match
---
trailer [33940,33949]
trailer [33940,33949]
===
match
---
name: render [72213,72219]
name: render [72265,72271]
===
match
---
atom_expr [22453,22462]
atom_expr [22453,22462]
===
match
---
operator: , [41673,41674]
operator: , [41642,41643]
===
match
---
name: State [43548,43553]
name: State [43600,43605]
===
match
---
if_stmt [18267,18338]
if_stmt [18267,18338]
===
match
---
name: datetime [80860,80868]
name: datetime [80912,80920]
===
match
---
name: Exception [4109,4118]
name: Exception [4109,4118]
===
match
---
expr_stmt [10311,10374]
expr_stmt [10311,10374]
===
match
---
operator: , [14242,14243]
operator: , [14242,14243]
===
match
---
decorator [81306,81316]
decorator [81358,81368]
===
match
---
operator: , [22888,22889]
operator: , [22888,22889]
===
match
---
atom_expr [6581,7073]
atom_expr [6581,7073]
===
match
---
name: dagrun [7497,7503]
name: dagrun [7497,7503]
===
match
---
name: get [63440,63443]
name: get [63492,63495]
===
match
---
atom_expr [78756,78775]
atom_expr [78808,78827]
===
match
---
atom_expr [54886,54895]
atom_expr [54938,54947]
===
match
---
trailer [79933,79945]
trailer [79985,79997]
===
match
---
name: local [14188,14193]
name: local [14188,14193]
===
match
---
string: 'dag_run_conf_overrides_params' [62439,62470]
string: 'dag_run_conf_overrides_params' [62491,62522]
===
match
---
testlist [72372,72411]
testlist [72424,72463]
===
match
---
name: signum [48308,48314]
name: signum [48360,48366]
===
match
---
name: hexdigest [33968,33977]
name: hexdigest [33968,33977]
===
match
---
for_stmt [66391,66527]
for_stmt [66443,66579]
===
match
---
trailer [77277,77283]
trailer [77329,77335]
===
match
---
atom_expr [68495,68507]
atom_expr [68547,68559]
===
match
---
operator: - [72927,72928]
operator: - [72979,72980]
===
match
---
name: ti [25967,25969]
name: ti [25967,25969]
===
match
---
name: verbose [38555,38562]
name: verbose [38555,38562]
===
match
---
name: self [52205,52209]
name: self [52257,52261]
===
match
---
except_clause [51535,51560]
except_clause [51587,51612]
===
match
---
name: test_mode [35903,35912]
name: test_mode [35903,35912]
===
match
---
name: dag_id [74581,74587]
name: dag_id [74633,74639]
===
match
---
operator: , [46710,46711]
operator: , [46762,46763]
===
match
---
comparison [23960,24002]
comparison [23960,24002]
===
match
---
string: '%Y%m%dT%H%M%S' [62071,62086]
string: '%Y%m%dT%H%M%S' [62123,62138]
===
match
---
operator: { [7719,7720]
operator: { [7719,7720]
===
match
---
name: format [74112,74118]
name: format [74164,74170]
===
match
---
trailer [40513,40528]
trailer [40513,40528]
===
match
---
argument [49480,49495]
argument [49532,49547]
===
match
---
name: ignore_all_deps [53433,53448]
name: ignore_all_deps [53485,53500]
===
match
---
suite [81645,82376]
suite [81697,82428]
===
match
---
name: SUCCESS [26261,26268]
name: SUCCESS [26261,26268]
===
match
---
name: self [43851,43855]
name: self [43903,43907]
===
match
---
name: task [23346,23350]
name: task [23346,23350]
===
match
---
arglist [58492,58525]
arglist [58544,58577]
===
match
---
atom_expr [62042,62087]
atom_expr [62094,62139]
===
match
---
atom_expr [60544,60584]
atom_expr [60596,60636]
===
match
---
atom_expr [70752,70965]
atom_expr [70804,71017]
===
match
---
trailer [26112,26138]
trailer [26112,26138]
===
match
---
suite [82482,82678]
suite [82534,82730]
===
match
---
name: and_ [6789,6793]
name: and_ [6789,6793]
===
match
---
trailer [28219,28224]
trailer [28219,28224]
===
match
---
funcdef [48289,48532]
funcdef [48341,48584]
===
match
---
testlist_comp [18767,18789]
testlist_comp [18767,18789]
===
match
---
operator: - [71680,71681]
operator: - [71732,71733]
===
match
---
decorated [81206,81301]
decorated [81258,81353]
===
match
---
name: session [59754,59761]
name: session [59806,59813]
===
match
---
atom_expr [35007,35033]
atom_expr [35007,35033]
===
match
---
trailer [76908,76918]
trailer [76960,76970]
===
match
---
name: dag_id [76553,76559]
name: dag_id [76605,76611]
===
match
---
name: _date_or_empty [45363,45377]
name: _date_or_empty [45415,45429]
===
match
---
name: self [55848,55852]
name: self [55900,55904]
===
match
---
name: Session [29747,29754]
name: Session [29747,29754]
===
match
---
name: ti [7720,7722]
name: ti [7720,7722]
===
match
---
operator: , [21492,21493]
operator: , [21492,21493]
===
match
---
yield_expr [32876,32892]
yield_expr [32876,32892]
===
match
---
if_stmt [66345,67056]
if_stmt [66397,67108]
===
match
---
atom_expr [30861,30874]
atom_expr [30861,30874]
===
match
---
trailer [35044,35051]
trailer [35044,35051]
===
match
---
name: tis [78709,78712]
name: tis [78761,78764]
===
match
---
name: session [59298,59305]
name: session [59350,59357]
===
match
---
operator: = [64242,64243]
operator: = [64294,64295]
===
match
---
dotted_name [2370,2383]
dotted_name [2370,2383]
===
match
---
tfpdef [63276,63292]
tfpdef [63328,63344]
===
match
---
name: _try_number [9747,9758]
name: _try_number [9747,9758]
===
match
---
atom_expr [33888,33903]
atom_expr [33888,33903]
===
match
---
name: test_mode [59246,59255]
name: test_mode [59298,59307]
===
match
---
decorated [81068,81133]
decorated [81120,81185]
===
match
---
atom [18641,18650]
atom [18641,18650]
===
match
---
atom_expr [80165,80182]
atom_expr [80217,80234]
===
match
---
simple_stmt [55311,55331]
simple_stmt [55363,55383]
===
match
---
operator: , [67857,67858]
operator: , [67909,67910]
===
match
---
argument [59267,59288]
argument [59319,59340]
===
match
---
name: self [53389,53393]
name: self [53441,53445]
===
match
---
operator: = [7884,7885]
operator: = [7884,7885]
===
match
---
name: get_failed_dep_statuses [31802,31825]
name: get_failed_dep_statuses [31802,31825]
===
match
---
name: in_env_var_format [49149,49166]
name: in_env_var_format [49201,49218]
===
match
---
operator: , [14943,14944]
operator: , [14943,14944]
===
match
---
expr_stmt [20162,20446]
expr_stmt [20162,20446]
===
match
---
trailer [71285,71292]
trailer [71337,71344]
===
match
---
suite [24866,25003]
suite [24866,25003]
===
match
---
name: t [79151,79152]
name: t [79203,79204]
===
match
---
trailer [54988,55005]
trailer [55040,55057]
===
match
---
atom_expr [19330,19342]
atom_expr [19330,19342]
===
match
---
trailer [21575,21582]
trailer [21575,21582]
===
match
---
name: try_number [70870,70880]
name: try_number [70922,70932]
===
match
---
operator: -> [8299,8301]
operator: -> [8299,8301]
===
match
---
string: "%s" [56552,56556]
string: "%s" [56604,56608]
===
match
---
operator: = [9473,9474]
operator: = [9473,9474]
===
match
---
trailer [73021,73025]
trailer [73073,73077]
===
match
---
name: state [39041,39046]
name: state [39041,39046]
===
match
---
param [66103,66107]
param [66155,66159]
===
match
---
name: self [8458,8462]
name: self [8458,8462]
===
match
---
name: session [42710,42717]
name: session [42679,42686]
===
match
---
operator: , [8240,8241]
operator: , [8240,8241]
===
match
---
simple_stmt [60234,60410]
simple_stmt [60286,60462]
===
match
---
trailer [47501,47514]
trailer [47553,47566]
===
match
---
trailer [79853,79861]
trailer [79905,79913]
===
match
---
param [28540,28544]
param [28540,28544]
===
match
---
atom_expr [60676,60688]
atom_expr [60728,60740]
===
match
---
operator: , [29552,29553]
operator: , [29552,29553]
===
match
---
dotted_name [45874,45895]
dotted_name [45926,45947]
===
match
---
string: "%s dependency '%s' PASSED: %s, %s" [32613,32648]
string: "%s dependency '%s' PASSED: %s, %s" [32613,32648]
===
match
---
operator: = [42814,42815]
operator: = [42866,42867]
===
match
---
name: _run_mini_scheduler_on_child_tasks [45704,45738]
name: _run_mini_scheduler_on_child_tasks [45756,45790]
===
match
---
name: datetime [79892,79900]
name: datetime [79944,79952]
===
match
---
number: 1 [82426,82427]
number: 1 [82478,82479]
===
match
---
simple_stmt [24153,24218]
simple_stmt [24153,24218]
===
match
---
simple_stmt [79870,79921]
simple_stmt [79922,79973]
===
match
---
simple_stmt [50954,50971]
simple_stmt [51006,51023]
===
match
---
name: value [74228,74233]
name: value [74280,74285]
===
match
---
atom_expr [63120,63133]
atom_expr [63172,63185]
===
match
---
name: deserialize_value [77342,77359]
name: deserialize_value [77394,77411]
===
match
---
name: State [57860,57865]
name: State [57912,57917]
===
match
---
operator: = [24379,24380]
operator: = [24379,24380]
===
match
---
name: get_rendered_template_fields [66074,66102]
name: get_rendered_template_fields [66126,66154]
===
match
---
simple_stmt [44665,44722]
simple_stmt [44717,44774]
===
match
---
trailer [11839,11855]
trailer [11839,11855]
===
match
---
name: schedule_tis [47502,47514]
name: schedule_tis [47554,47566]
===
match
---
name: error [56386,56391]
name: error [56438,56443]
===
match
---
suite [41248,41333]
suite [41217,41302]
===
match
---
argument [29541,29552]
argument [29541,29552]
===
match
---
test [31726,31770]
test [31726,31770]
===
match
---
decorator [20559,20576]
decorator [20559,20576]
===
match
---
operator: , [10991,10992]
operator: , [10991,10992]
===
match
---
atom_expr [50900,50917]
atom_expr [50952,50969]
===
match
---
name: str [18163,18166]
name: str [18163,18166]
===
match
---
name: sha1 [33768,33772]
name: sha1 [33768,33772]
===
match
---
operator: , [9532,9533]
operator: , [9532,9533]
===
match
---
name: ignore_all_deps [37692,37707]
name: ignore_all_deps [37692,37707]
===
match
---
name: dep_status [32080,32090]
name: dep_status [32080,32090]
===
match
---
atom_expr [19470,19501]
atom_expr [19470,19501]
===
match
---
operator: = [46178,46179]
operator: = [46230,46231]
===
match
---
atom_expr [7107,7129]
atom_expr [7107,7129]
===
match
---
name: with_for_update [21773,21788]
name: with_for_update [21773,21788]
===
match
---
trailer [53858,54245]
trailer [53910,54297]
===
match
---
suite [8591,8750]
suite [8591,8750]
===
match
---
name: self [12009,12013]
name: self [12009,12013]
===
match
---
operator: , [62942,62943]
operator: , [62994,62995]
===
match
---
string: "Recording the task instance as FAILED" [20805,20844]
string: "Recording the task instance as FAILED" [20805,20844]
===
match
---
name: make_aware [11718,11728]
name: make_aware [11718,11728]
===
match
---
name: ti [21853,21855]
name: ti [21853,21855]
===
match
---
name: self [64683,64687]
name: self [64735,64739]
===
match
---
name: registered [50177,50187]
name: registered [50229,50239]
===
match
---
atom_expr [15819,15832]
atom_expr [15819,15832]
===
match
---
name: ti [7650,7652]
name: ti [7650,7652]
===
match
---
parameters [81487,81493]
parameters [81539,81545]
===
match
---
name: execution_date [11803,11817]
name: execution_date [11803,11817]
===
match
---
name: property [80656,80664]
name: property [80708,80716]
===
match
---
atom_expr [37548,37607]
atom_expr [37548,37607]
===
match
---
name: task [37431,37435]
name: task [37431,37435]
===
match
---
suite [52656,52806]
suite [52708,52858]
===
match
---
name: date [41434,41438]
name: date [41403,41407]
===
match
---
trailer [15933,15938]
trailer [15933,15938]
===
match
---
name: Optional [80184,80192]
name: Optional [80236,80244]
===
match
---
name: dag [5375,5378]
name: dag [5375,5378]
===
match
---
annassign [80354,80376]
annassign [80406,80428]
===
match
---
name: pool [10755,10759]
name: pool [10755,10759]
===
match
---
strings [49981,50094]
strings [50033,50146]
===
match
---
name: str [52326,52329]
name: str [52378,52381]
===
match
---
name: vals_kv [77134,77141]
name: vals_kv [77186,77193]
===
match
---
trailer [7354,7379]
trailer [7354,7379]
===
match
---
name: handle_failure_with_callback [59010,59038]
name: handle_failure_with_callback [59062,59090]
===
match
---
name: airflow [2176,2183]
name: airflow [2176,2183]
===
match
---
string: 'ds_nodash' [64611,64622]
string: 'ds_nodash' [64663,64674]
===
match
---
operator: = [39111,39112]
operator: = [39111,39112]
===
match
---
name: orm [1410,1413]
name: orm [1410,1413]
===
match
---
param [79765,79781]
param [79817,79833]
===
match
---
trailer [35387,35395]
trailer [35387,35395]
===
match
---
tfpdef [15464,15475]
tfpdef [15464,15475]
===
match
---
name: var [63933,63936]
name: var [63985,63988]
===
match
---
name: self [39890,39894]
name: self [39890,39894]
===
match
---
trailer [64731,64738]
trailer [64783,64790]
===
match
---
simple_stmt [48935,49008]
simple_stmt [48987,49060]
===
match
---
name: str [8121,8124]
name: str [8121,8124]
===
match
---
name: task [23486,23490]
name: task [23486,23490]
===
match
---
name: pendulum [30264,30272]
name: pendulum [30264,30272]
===
match
---
operator: = [71150,71151]
operator: = [71202,71203]
===
match
---
param [81606,81627]
param [81658,81679]
===
match
---
operator: , [10013,10014]
operator: , [10013,10014]
===
match
---
name: self [43737,43741]
name: self [43789,43793]
===
match
---
name: dr [35355,35357]
name: dr [35355,35357]
===
match
---
decorated [81306,81371]
decorated [81358,81423]
===
match
---
name: execution_date [7723,7737]
name: execution_date [7723,7737]
===
match
---
operator: , [55576,55577]
operator: , [55628,55629]
===
match
---
suite [41421,41536]
suite [41390,41505]
===
match
---
not_test [25307,25333]
not_test [25307,25333]
===
match
---
parameters [59038,59195]
parameters [59090,59247]
===
match
---
trailer [74597,74602]
trailer [74649,74654]
===
match
---
operator: == [35468,35470]
operator: == [35468,35470]
===
match
---
name: timedelta [34611,34620]
name: timedelta [34611,34620]
===
match
---
trailer [58842,58852]
trailer [58894,58904]
===
match
---
trailer [23429,23439]
trailer [23429,23439]
===
match
---
operator: , [45195,45196]
operator: , [45247,45248]
===
match
---
atom_expr [9999,10041]
atom_expr [9999,10041]
===
match
---
name: Variable [63295,63303]
name: Variable [63347,63355]
===
match
---
simple_stmt [60719,60791]
simple_stmt [60771,60843]
===
match
---
atom_expr [56871,56890]
atom_expr [56923,56942]
===
match
---
operator: = [61535,61536]
operator: = [61587,61588]
===
match
---
param [67947,67952]
param [67999,68004]
===
match
---
name: IO [3874,3876]
name: IO [3874,3876]
===
match
---
operator: = [53812,53813]
operator: = [53864,53865]
===
match
---
if_stmt [82248,82358]
if_stmt [82300,82410]
===
match
---
name: provide_session [55042,55057]
name: provide_session [55094,55109]
===
match
---
name: item [63444,63448]
name: item [63496,63500]
===
match
---
name: include_upstream [46732,46748]
name: include_upstream [46784,46800]
===
match
---
atom_expr [40922,40938]
atom_expr [40891,40907]
===
match
---
operator: , [8715,8716]
operator: , [8715,8716]
===
match
---
funcdef [20580,20933]
funcdef [20580,20933]
===
match
---
simple_stmt [24879,24925]
simple_stmt [24879,24925]
===
match
---
name: execution_date [79132,79146]
name: execution_date [79184,79198]
===
match
---
expr_stmt [60719,60790]
expr_stmt [60771,60842]
===
match
---
simple_stmt [901,937]
simple_stmt [901,937]
===
match
---
operator: , [26270,26271]
operator: , [26270,26271]
===
match
---
name: with_row_locks [2800,2814]
name: with_row_locks [2800,2814]
===
match
---
name: qry [82346,82349]
name: qry [82398,82401]
===
match
---
name: job_id [37621,37627]
name: job_id [37621,37627]
===
match
---
trailer [62126,62135]
trailer [62178,62187]
===
match
---
name: airflow [48134,48141]
name: airflow [48186,48193]
===
match
---
trailer [43455,43459]
trailer [43507,43511]
===
match
---
trailer [80319,80324]
trailer [80371,80376]
===
match
---
name: commit [55915,55921]
name: commit [55967,55973]
===
match
---
name: get_template_context [42972,42992]
name: get_template_context [43024,43044]
===
match
---
trailer [78969,78977]
trailer [79021,79029]
===
match
---
arglist [10585,10622]
arglist [10585,10622]
===
match
---
trailer [10215,10224]
trailer [10215,10224]
===
match
---
name: error [20584,20589]
name: error [20584,20589]
===
match
---
name: self [12314,12318]
name: self [12314,12318]
===
match
---
name: self [58732,58736]
name: self [58784,58788]
===
match
---
name: self [79792,79796]
name: self [79844,79848]
===
match
---
trailer [40730,40734]
trailer [40730,40734]
===
match
---
name: AirflowTaskTimeout [1791,1809]
name: AirflowTaskTimeout [1791,1809]
===
match
---
atom_expr [19175,19213]
atom_expr [19175,19213]
===
match
---
suite [18204,18259]
suite [18204,18259]
===
match
---
name: _priority_weight [80437,80453]
name: _priority_weight [80489,80505]
===
match
---
operator: = [20603,20604]
operator: = [20603,20604]
===
match
---
suite [68230,69156]
suite [68282,69208]
===
match
---
atom_expr [68768,68811]
atom_expr [68820,68863]
===
match
---
name: elements [1512,1520]
name: elements [1512,1520]
===
match
---
arith_expr [38176,38207]
arith_expr [38176,38207]
===
match
---
name: incr [50605,50609]
name: incr [50657,50661]
===
match
---
funcdef [23572,24092]
funcdef [23572,24092]
===
match
---
simple_stmt [25263,25334]
simple_stmt [25263,25334]
===
match
---
suite [3307,3848]
suite [3307,3848]
===
match
---
name: queued_dttm [22706,22717]
name: queued_dttm [22706,22717]
===
match
---
fstring [32933,33017]
fstring [32933,33017]
===
match
---
simple_stmt [17909,17965]
simple_stmt [17909,17965]
===
match
---
name: self [11276,11280]
name: self [11276,11280]
===
match
---
name: and_ [78734,78738]
name: and_ [78786,78790]
===
match
---
expr_stmt [3139,3163]
expr_stmt [3139,3163]
===
match
---
operator: = [3111,3112]
operator: = [3111,3112]
===
match
---
operator: = [31858,31859]
operator: = [31858,31859]
===
match
---
name: pool [9939,9943]
name: pool [9939,9943]
===
match
---
string: """Key used to identify task instance.""" [7945,7986]
string: """Key used to identify task instance.""" [7945,7986]
===
match
---
string: 'BASE_URL' [19544,19554]
string: 'BASE_URL' [19544,19554]
===
match
---
trailer [63123,63133]
trailer [63175,63185]
===
match
---
param [35936,35965]
param [35936,35965]
===
match
---
atom_expr [70714,70979]
atom_expr [70766,71031]
===
match
---
atom_expr [55932,56001]
atom_expr [55984,56053]
===
match
---
funcdef [81468,81532]
funcdef [81520,81584]
===
match
---
name: _handle_reschedule [55066,55084]
name: _handle_reschedule [55118,55136]
===
match
---
argument [15029,15060]
argument [15029,15060]
===
match
---
operator: , [79369,79370]
operator: , [79421,79422]
===
match
---
name: task [56804,56808]
name: task [56856,56860]
===
match
---
parameters [72792,72798]
parameters [72844,72850]
===
match
---
trailer [18985,19015]
trailer [18985,19015]
===
match
---
trailer [7338,7347]
trailer [7338,7347]
===
match
---
operator: , [68553,68554]
operator: , [68605,68606]
===
match
---
expr_stmt [77110,77179]
expr_stmt [77162,77231]
===
match
---
trailer [54743,54745]
trailer [54795,54797]
===
match
---
name: task_id [42884,42891]
name: task_id [42936,42943]
===
match
---
trailer [58141,58147]
trailer [58193,58199]
===
match
---
expr_stmt [70107,70495]
expr_stmt [70159,70547]
===
match
---
simple_stmt [40447,40460]
simple_stmt [40447,40460]
===
match
---
name: Column [10334,10340]
name: Column [10334,10340]
===
match
---
simple_stmt [79792,79822]
simple_stmt [79844,79874]
===
match
---
name: get_email_subject_content [69165,69190]
name: get_email_subject_content [69217,69242]
===
match
---
name: hasattr [47345,47352]
name: hasattr [47397,47404]
===
match
---
string: '%Y%m%dT%H%M%S' [58628,58643]
string: '%Y%m%dT%H%M%S' [58680,58695]
===
match
---
trailer [69480,69491]
trailer [69532,69543]
===
match
---
and_test [51768,51813]
and_test [51820,51865]
===
match
---
name: ready_for_retry [25316,25331]
name: ready_for_retry [25316,25331]
===
match
---
operator: , [38256,38257]
operator: , [38256,38257]
===
match
---
operator: = [68592,68593]
operator: = [68644,68645]
===
match
---
trailer [21790,21796]
trailer [21790,21796]
===
match
---
name: set_state [24344,24353]
name: set_state [24344,24353]
===
match
---
comparison [59483,59516]
comparison [59535,59568]
===
match
---
trailer [53238,53251]
trailer [53290,53303]
===
match
---
trailer [23267,23272]
trailer [23267,23272]
===
match
---
atom_expr [32980,32999]
atom_expr [32980,32999]
===
match
---
name: task [11660,11664]
name: task [11660,11664]
===
match
---
fstring_string: Unable to render a k8s spec for this taskinstance:  [67526,67577]
fstring_string: Unable to render a k8s spec for this taskinstance:  [67578,67629]
===
match
---
argument [54005,54038]
argument [54057,54090]
===
match
---
simple_stmt [22475,22495]
simple_stmt [22475,22495]
===
match
---
name: max [5885,5888]
name: max [5885,5888]
===
match
---
operator: = [12546,12547]
operator: = [12546,12547]
===
match
---
decorated [29645,30302]
decorated [29645,30302]
===
match
---
trailer [3676,3847]
trailer [3676,3847]
===
match
---
operator: , [39707,39708]
operator: , [39707,39708]
===
match
---
argument [59233,59244]
argument [59285,59296]
===
match
---
arglist [61899,61906]
arglist [61951,61958]
===
match
---
atom_expr [49366,49405]
atom_expr [49418,49457]
===
match
---
number: 2 [28966,28967]
number: 2 [28966,28967]
===
match
---
suite [47705,48008]
suite [47757,48060]
===
match
---
string: "at task runtime. Attempt %s of " [40086,40119]
string: "at task runtime. Attempt %s of " [40086,40119]
===
match
---
if_stmt [56405,56565]
if_stmt [56457,56617]
===
match
---
name: incr [42848,42852]
name: incr [42900,42904]
===
match
---
name: log [31731,31734]
name: log [31731,31734]
===
match
---
expr_stmt [18948,19016]
expr_stmt [18948,19016]
===
match
---
operator: = [21977,21978]
operator: = [21977,21978]
===
match
---
name: __init__ [11032,11040]
name: __init__ [11032,11040]
===
match
---
trailer [47433,47437]
trailer [47485,47489]
===
match
---
trailer [7383,7385]
trailer [7383,7385]
===
match
---
operator: , [59552,59553]
operator: , [59604,59605]
===
match
---
name: tis [79473,79476]
name: tis [79525,79528]
===
match
---
name: params [62532,62538]
name: params [62584,62590]
===
match
---
trailer [60125,60142]
trailer [60177,60194]
===
match
---
simple_stmt [51885,51899]
simple_stmt [51937,51951]
===
match
---
operator: , [56174,56175]
operator: , [56226,56227]
===
match
---
atom_expr [49606,49644]
atom_expr [49658,49696]
===
match
---
simple_stmt [39978,40261]
simple_stmt [39978,40261]
===
match
---
string: "Webserver does not have access to User-defined Macros or Filters " [66724,66791]
string: "Webserver does not have access to User-defined Macros or Filters " [66776,66843]
===
match
---
name: datetime [73200,73208]
name: datetime [73252,73260]
===
match
---
operator: = [71663,71664]
operator: = [71715,71716]
===
match
---
operator: = [20480,20481]
operator: = [20480,20481]
===
match
---
trailer [71388,71395]
trailer [71440,71447]
===
match
---
suite [18287,18338]
suite [18287,18338]
===
match
---
name: render_k8s_pod_yaml [68186,68205]
name: render_k8s_pod_yaml [68238,68257]
===
match
---
name: exception_html [70819,70833]
name: exception_html [70871,70885]
===
match
---
atom_expr [33853,33865]
atom_expr [33853,33865]
===
match
---
suite [32132,32158]
suite [32132,32158]
===
match
---
atom_expr [57043,57055]
atom_expr [57095,57107]
===
match
---
name: _prepare_and_execute_task_with_callbacks [48017,48057]
name: _prepare_and_execute_task_with_callbacks [48069,48109]
===
match
---
name: state [58142,58147]
name: state [58194,58199]
===
match
---
operator: = [41839,41840]
operator: = [41808,41809]
===
match
---
trailer [58970,58977]
trailer [59022,59029]
===
match
---
name: verbose_aware_logger [31703,31723]
name: verbose_aware_logger [31703,31723]
===
match
---
name: merge [40902,40907]
name: merge [40871,40876]
===
match
---
name: seconds [34621,34628]
name: seconds [34621,34628]
===
match
---
atom_expr [32965,32977]
atom_expr [32965,32977]
===
match
---
except_clause [44752,44794]
except_clause [44804,44846]
===
match
---
comparison [82125,82162]
comparison [82177,82214]
===
match
---
trailer [31730,31734]
trailer [31730,31734]
===
match
---
trailer [52708,52710]
trailer [52760,52762]
===
match
---
operator: , [65001,65002]
operator: , [65053,65054]
===
match
---
not_test [69426,69451]
not_test [69478,69503]
===
match
---
expr_stmt [38985,39020]
expr_stmt [38985,39020]
===
match
---
name: with_entities [77259,77272]
name: with_entities [77311,77324]
===
match
---
name: self [48258,48262]
name: self [48310,48314]
===
match
---
simple_stmt [77451,77498]
simple_stmt [77503,77550]
===
match
---
if_stmt [78635,78930]
if_stmt [78687,78982]
===
match
---
operator: , [72539,72540]
operator: , [72591,72592]
===
match
---
operator: , [67679,67680]
operator: , [67731,67732]
===
match
---
name: cmd [18807,18810]
name: cmd [18807,18810]
===
match
---
operator: = [80274,80275]
operator: = [80326,80327]
===
match
---
name: task [41204,41208]
name: task [41173,41177]
===
match
---
decorated [12596,13176]
decorated [12596,13176]
===
match
---
name: v [49302,49303]
name: v [49354,49355]
===
match
---
return_stmt [35532,35541]
return_stmt [35532,35541]
===
match
---
simple_stmt [3925,3969]
simple_stmt [3925,3969]
===
match
---
name: get_task_instance [27943,27960]
name: get_task_instance [27943,27960]
===
match
---
string: '-' [62013,62016]
string: '-' [62065,62068]
===
match
---
simple_stmt [1161,1186]
simple_stmt [1161,1186]
===
match
---
atom_expr [43737,43748]
atom_expr [43789,43800]
===
match
---
operator: -> [56246,56248]
operator: -> [56298,56300]
===
match
---
trailer [5987,5991]
trailer [5987,5991]
===
match
---
name: next_ds [61607,61614]
name: next_ds [61659,61666]
===
match
---
operator: = [14172,14173]
operator: = [14172,14173]
===
match
---
operator: , [17941,17942]
operator: , [17941,17942]
===
match
---
testlist_comp [17916,17963]
testlist_comp [17916,17963]
===
match
---
trailer [14756,14770]
trailer [14756,14770]
===
match
---
name: DagRun [60276,60282]
name: DagRun [60328,60334]
===
match
---
name: context [51936,51943]
name: context [51988,51995]
===
match
---
fstring_expr [19034,19043]
fstring_expr [19034,19043]
===
match
---
name: operator [22649,22657]
name: operator [22649,22657]
===
match
---
atom_expr [71152,71214]
atom_expr [71204,71266]
===
match
---
expr_stmt [12065,12083]
expr_stmt [12065,12083]
===
match
---
name: session [45745,45752]
name: session [45797,45804]
===
match
---
with_item [4331,4359]
with_item [4331,4359]
===
match
---
name: warn [30564,30568]
name: warn [30564,30568]
===
match
---
operator: = [67390,67391]
operator: = [67442,67443]
===
match
---
trailer [4015,4017]
trailer [4015,4017]
===
match
---
trailer [58977,58979]
trailer [59029,59031]
===
match
---
name: yesterday_ds [60638,60650]
name: yesterday_ds [60690,60702]
===
match
---
name: e [44197,44198]
name: e [44249,44250]
===
match
---
tfpdef [63198,63207]
tfpdef [63250,63259]
===
match
---
simple_stmt [6001,6077]
simple_stmt [6001,6077]
===
match
---
expr_stmt [9747,9801]
expr_stmt [9747,9801]
===
match
---
string: 'ti_dag_state' [10539,10553]
string: 'ti_dag_state' [10539,10553]
===
match
---
except_clause [4417,4433]
except_clause [4417,4433]
===
match
---
simple_stmt [3575,3615]
simple_stmt [3575,3615]
===
match
---
name: airflow [59885,59892]
name: airflow [59937,59944]
===
match
---
simple_stmt [22399,22427]
simple_stmt [22399,22427]
===
match
---
name: airflow_context_vars [49307,49327]
name: airflow_context_vars [49359,49379]
===
match
---
arith_expr [34100,34135]
arith_expr [34100,34135]
===
match
---
string: 'TaskInstanceKey' [8302,8319]
string: 'TaskInstanceKey' [8302,8319]
===
match
---
dotted_name [1818,1837]
dotted_name [1818,1837]
===
match
---
trailer [4249,4265]
trailer [4249,4265]
===
match
---
name: self [45311,45315]
name: self [45363,45367]
===
match
---
name: _try_number [22252,22263]
name: _try_number [22252,22263]
===
match
---
name: expected_state [3818,3832]
name: expected_state [3818,3832]
===
match
---
operator: = [4703,4704]
operator: = [4703,4704]
===
match
---
operator: = [68632,68633]
operator: = [68684,68685]
===
match
---
simple_stmt [63424,63475]
simple_stmt [63476,63527]
===
match
---
name: Column [1283,1289]
name: Column [1283,1289]
===
match
---
trailer [19526,19530]
trailer [19526,19530]
===
match
---
name: info [41274,41278]
name: info [41243,41247]
===
match
---
operator: = [53098,53099]
operator: = [53150,53151]
===
match
---
string: 'json' [65865,65871]
string: 'json' [65917,65923]
===
match
---
trailer [43143,43149]
trailer [43195,43201]
===
match
---
name: dag_id [68467,68473]
name: dag_id [68519,68525]
===
match
---
operator: , [26138,26139]
operator: , [26138,26139]
===
match
---
name: task_id [47462,47469]
name: task_id [47514,47521]
===
match
---
or_test [24801,24865]
or_test [24801,24865]
===
match
---
operator: , [46138,46139]
operator: , [46190,46191]
===
match
---
name: execution_date [74313,74327]
name: execution_date [74365,74379]
===
match
---
string: '%s dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [58313,58386]
string: '%s dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [58365,58438]
===
match
---
trailer [78944,79008]
trailer [78996,79060]
===
match
---
with_stmt [71976,72041]
with_stmt [72028,72093]
===
match
---
operator: , [10657,10658]
operator: , [10657,10658]
===
match
---
name: state [52552,52557]
name: state [52604,52609]
===
match
---
trailer [56462,56472]
trailer [56514,56524]
===
match
---
name: self [11477,11481]
name: self [11477,11481]
===
match
---
arith_expr [60654,60688]
arith_expr [60706,60740]
===
match
---
simple_stmt [10046,10074]
simple_stmt [10046,10074]
===
match
---
operator: @ [81068,81069]
operator: @ [81120,81121]
===
match
---
expr_stmt [18902,18939]
expr_stmt [18902,18939]
===
match
---
operator: , [30963,30964]
operator: , [30963,30964]
===
match
---
operator: , [14976,14977]
operator: , [14976,14977]
===
match
---
name: exception [72439,72448]
name: exception [72491,72500]
===
match
---
suite [19863,20554]
suite [19863,20554]
===
match
---
atom_expr [58935,58954]
atom_expr [58987,59006]
===
match
---
trailer [39994,40260]
trailer [39994,40260]
===
match
---
trailer [53682,53687]
trailer [53734,53739]
===
match
---
operator: == [82146,82148]
operator: == [82198,82200]
===
match
---
name: task [59867,59871]
name: task [59919,59923]
===
match
---
operator: -> [19856,19858]
operator: -> [19856,19858]
===
match
---
expr_stmt [42796,42833]
expr_stmt [42848,42885]
===
match
---
name: render_templates [48898,48914]
name: render_templates [48950,48966]
===
match
---
not_test [68063,68074]
not_test [68115,68126]
===
match
---
comp_if [47222,47261]
comp_if [47274,47313]
===
match
---
trailer [20188,20194]
trailer [20188,20194]
===
match
---
decorated [32250,32893]
decorated [32250,32893]
===
match
---
atom_expr [40580,40595]
atom_expr [40580,40595]
===
match
---
name: reason [32787,32793]
name: reason [32787,32793]
===
match
---
operator: -> [81167,81169]
operator: -> [81219,81221]
===
match
---
trailer [4091,4097]
trailer [4091,4097]
===
match
---
decorators [45653,45696]
decorators [45705,45748]
===
match
---
trailer [45279,45297]
trailer [45331,45349]
===
match
---
argument [70819,70848]
argument [70871,70900]
===
match
---
simple_stmt [67155,67226]
simple_stmt [67207,67278]
===
match
---
simple_stmt [80630,80650]
simple_stmt [80682,80702]
===
match
---
operator: , [78026,78027]
operator: , [78078,78079]
===
match
---
name: ti [5122,5124]
name: ti [5122,5124]
===
match
---
atom_expr [80276,80290]
atom_expr [80328,80342]
===
match
---
trailer [39018,39020]
trailer [39018,39020]
===
match
---
operator: = [73002,73003]
operator: = [73054,73055]
===
match
---
name: get_template_context [53192,53212]
name: get_template_context [53244,53264]
===
match
---
name: str [3903,3906]
name: str [3903,3906]
===
match
---
operator: , [36000,36001]
operator: , [36000,36001]
===
match
---
number: 1 [60766,60767]
number: 1 [60818,60819]
===
match
---
trailer [47446,47470]
trailer [47498,47522]
===
match
---
suite [80780,80817]
suite [80832,80869]
===
match
---
name: job_id [42732,42738]
name: job_id [42701,42707]
===
match
---
operator: , [28909,28910]
operator: , [28909,28910]
===
match
---
name: platform [2676,2684]
name: platform [2676,2684]
===
match
---
name: _start_date [79934,79945]
name: _start_date [79986,79997]
===
match
---
suite [7394,7434]
suite [7394,7434]
===
match
---
fstring_string: &task_id= [19320,19329]
fstring_string: &task_id= [19320,19329]
===
match
---
name: self [77702,77706]
name: self [77754,77758]
===
match
---
trailer [61674,61683]
trailer [61726,61735]
===
match
---
name: job_ids [4999,5006]
name: job_ids [4999,5006]
===
match
---
operator: @ [45674,45675]
operator: @ [45726,45727]
===
match
---
sync_comp_for [7738,7751]
sync_comp_for [7738,7751]
===
match
---
trailer [21796,21798]
trailer [21796,21798]
===
match
---
operator: } [19363,19364]
operator: } [19363,19364]
===
match
---
operator: = [23605,23606]
operator: = [23605,23606]
===
match
---
arglist [5889,5926]
arglist [5889,5926]
===
match
---
trailer [11124,11133]
trailer [11124,11133]
===
match
---
argument [54786,54797]
argument [54838,54849]
===
match
---
operator: = [42965,42966]
operator: = [43017,43018]
===
match
---
param [13310,13314]
param [13310,13314]
===
match
---
operator: , [69442,69443]
operator: , [69494,69495]
===
match
---
trailer [80113,80130]
trailer [80165,80182]
===
match
---
fstring_start: f' [48708,48710]
fstring_start: f' [48760,48762]
===
match
---
atom [47187,47262]
atom [47239,47314]
===
match
---
name: self [80762,80766]
name: self [80814,80818]
===
match
---
param [63276,63335]
param [63328,63387]
===
match
---
dotted_name [1959,1988]
dotted_name [1959,1988]
===
match
---
atom_expr [45779,45855]
atom_expr [45831,45907]
===
match
---
trailer [51595,51597]
trailer [51647,51649]
===
match
---
parameters [28047,28053]
parameters [28047,28053]
===
match
---
name: ti [22019,22021]
name: ti [22019,22021]
===
match
---
argument [27219,27233]
argument [27219,27233]
===
match
---
trailer [34569,34583]
trailer [34569,34583]
===
match
---
atom_expr [43139,43149]
atom_expr [43191,43201]
===
match
---
string: 'value' [65913,65920]
string: 'value' [65965,65972]
===
match
---
trailer [29132,29137]
trailer [29132,29137]
===
match
---
operator: , [56140,56141]
operator: , [56192,56193]
===
match
---
atom_expr [56829,56842]
atom_expr [56881,56894]
===
match
---
trailer [62300,62307]
trailer [62352,62359]
===
match
---
operator: = [71339,71340]
operator: = [71391,71392]
===
match
---
operator: = [51868,51869]
operator: = [51920,51921]
===
match
---
name: PickleType [1314,1324]
name: PickleType [1314,1324]
===
match
---
name: exception_html [71617,71631]
name: exception_html [71669,71683]
===
match
---
name: t [78999,79000]
name: t [79051,79052]
===
match
---
name: TemplateAssertionError [1221,1243]
name: TemplateAssertionError [1221,1243]
===
match
---
operator: , [61902,61903]
operator: , [61954,61955]
===
match
---
trailer [14892,15410]
trailer [14892,15410]
===
match
---
trailer [55384,55655]
trailer [55436,55707]
===
match
---
simple_stmt [51646,51690]
simple_stmt [51698,51742]
===
match
---
and_test [29586,29639]
and_test [29586,29639]
===
match
---
name: ti [80224,80226]
name: ti [80276,80278]
===
match
---
operator: = [62240,62241]
operator: = [62292,62293]
===
match
---
trailer [32591,32812]
trailer [32591,32812]
===
match
---
simple_stmt [18902,18940]
simple_stmt [18902,18940]
===
match
---
name: self [22231,22235]
name: self [22231,22235]
===
match
---
trailer [79297,79304]
trailer [79349,79356]
===
match
---
operator: , [22843,22844]
operator: , [22843,22844]
===
match
---
name: prev_execution_date [61960,61979]
name: prev_execution_date [62012,62031]
===
match
---
argument [53872,53887]
argument [53924,53939]
===
match
---
name: task [5434,5438]
name: task [5434,5438]
===
match
---
name: self [79830,79834]
name: self [79882,79886]
===
match
---
trailer [9730,9742]
trailer [9730,9742]
===
match
---
name: ti [82341,82343]
name: ti [82393,82395]
===
match
---
name: render_templates [54989,55005]
name: render_templates [55041,55057]
===
match
---
trailer [32955,32962]
trailer [32955,32962]
===
match
---
name: UndefinedError [67463,67477]
name: UndefinedError [67515,67529]
===
match
---
name: DagRun [35314,35320]
name: DagRun [35314,35320]
===
match
---
name: self [55685,55689]
name: self [55737,55741]
===
match
---
import_from [1449,1491]
import_from [1449,1491]
===
match
---
trailer [65241,65249]
trailer [65293,65301]
===
match
---
name: task [43066,43070]
name: task [43118,43122]
===
match
---
argument [43105,43125]
argument [43157,43177]
===
match
---
name: dag_run [82592,82599]
name: dag_run [82644,82651]
===
match
---
name: dep_name [32707,32715]
name: dep_name [32707,32715]
===
match
---
name: sqlalchemy [1265,1275]
name: sqlalchemy [1265,1275]
===
match
---
operator: , [44104,44105]
operator: , [44156,44157]
===
match
---
operator: , [65622,65623]
operator: , [65674,65675]
===
match
---
suite [18560,18602]
suite [18560,18602]
===
match
---
operator: , [44697,44698]
operator: , [44749,44750]
===
match
---
name: execution_date [35476,35490]
name: execution_date [35476,35490]
===
match
---
name: property [81139,81147]
name: property [81191,81199]
===
match
---
atom_expr [12383,12397]
atom_expr [12383,12397]
===
match
---
operator: - [70897,70898]
operator: - [70949,70950]
===
match
---
name: prepare_for_execution [48226,48247]
name: prepare_for_execution [48278,48299]
===
match
---
atom_expr [55311,55330]
atom_expr [55363,55382]
===
match
---
operator: , [71631,71632]
operator: , [71683,71684]
===
match
---
name: stats [2218,2223]
name: stats [2218,2223]
===
match
---
name: items [66455,66460]
name: items [66507,66512]
===
match
---
atom_expr [45599,45647]
atom_expr [45651,45699]
===
match
---
import_as_names [1283,1349]
import_as_names [1283,1349]
===
match
---
expr_stmt [78304,78324]
expr_stmt [78356,78376]
===
match
---
trailer [24958,24967]
trailer [24958,24967]
===
match
---
try_stmt [42903,44979]
try_stmt [42955,45031]
===
match
---
name: kube_config [2985,2996]
name: kube_config [2985,2996]
===
match
---
name: self [81190,81194]
name: self [81242,81246]
===
match
---
name: Union [59069,59074]
name: Union [59121,59126]
===
match
---
atom_expr [50632,50651]
atom_expr [50684,50703]
===
match
---
if_stmt [21732,21842]
if_stmt [21732,21842]
===
match
---
name: self [68674,68678]
name: self [68726,68730]
===
match
---
name: attr [41383,41387]
name: attr [41352,41356]
===
match
---
trailer [74292,74299]
trailer [74344,74351]
===
match
---
atom_expr [24262,24274]
atom_expr [24262,24274]
===
match
---
name: dr [7870,7872]
name: dr [7870,7872]
===
match
---
expr_stmt [8025,8049]
expr_stmt [8025,8049]
===
match
---
trailer [72900,72909]
trailer [72952,72961]
===
match
---
name: utils [2713,2718]
name: utils [2713,2718]
===
match
---
atom_expr [52727,52747]
atom_expr [52779,52799]
===
match
---
trailer [5250,5257]
trailer [5250,5257]
===
match
---
operator: = [53747,53748]
operator: = [53799,53800]
===
match
---
name: TaskInstance [79178,79190]
name: TaskInstance [79230,79242]
===
match
---
atom_expr [5974,5991]
atom_expr [5974,5991]
===
match
---
arith_expr [72913,72944]
arith_expr [72965,72996]
===
match
---
trailer [22648,22657]
trailer [22648,22657]
===
match
---
decorator [12596,12606]
decorator [12596,12606]
===
match
---
name: self [33867,33871]
name: self [33867,33871]
===
match
---
name: ti [21937,21939]
name: ti [21937,21939]
===
match
---
simple_stmt [61866,61908]
simple_stmt [61918,61960]
===
match
---
trailer [13127,13139]
trailer [13127,13139]
===
match
---
operator: = [69424,69425]
operator: = [69476,69477]
===
match
---
name: e [43427,43428]
name: e [43479,43480]
===
match
---
operator: , [38553,38554]
operator: , [38553,38554]
===
match
---
name: ID_LEN [9507,9513]
name: ID_LEN [9507,9513]
===
match
---
name: self [28540,28544]
name: self [28540,28544]
===
match
---
trailer [20434,20436]
trailer [20434,20436]
===
match
---
suite [16042,18811]
suite [16042,18811]
===
match
---
operator: = [39633,39634]
operator: = [39633,39634]
===
match
---
name: renderedtifields [66191,66207]
name: renderedtifields [66243,66259]
===
match
---
simple_stmt [43574,43949]
simple_stmt [43626,44001]
===
match
---
operator: = [26296,26297]
operator: = [26296,26297]
===
match
---
string: """         Returns a command that can be executed anywhere where airflow is         installed. This command is part of the message sent to executors by         the orchestrator.         """ [14322,14512]
string: """         Returns a command that can be executed anywhere where airflow is         installed. This command is part of the message sent to executors by         the orchestrator.         """ [14322,14512]
===
match
---
argument [54513,54522]
argument [54565,54574]
===
match
---
name: next_execution_date [61358,61377]
name: next_execution_date [61410,61429]
===
match
---
simple_stmt [37645,37676]
simple_stmt [37645,37676]
===
match
---
arglist [21456,21498]
arglist [21456,21498]
===
match
---
atom_expr [28549,28573]
atom_expr [28549,28573]
===
match
---
argument [54582,54597]
argument [54634,54649]
===
match
---
trailer [13245,13257]
trailer [13245,13257]
===
match
---
operator: , [18779,18780]
operator: , [18779,18780]
===
match
---
name: task_copy [48715,48724]
name: task_copy [48767,48776]
===
match
---
comparison [77626,77660]
comparison [77678,77712]
===
match
---
simple_stmt [46571,46824]
simple_stmt [46623,46876]
===
match
---
name: Float [1291,1296]
name: Float [1291,1296]
===
match
---
operator: } [19077,19078]
operator: } [19077,19078]
===
match
---
funcdef [29666,30302]
funcdef [29666,30302]
===
match
---
operator: = [9722,9723]
operator: = [9722,9723]
===
match
---
atom_expr [43902,43933]
atom_expr [43954,43985]
===
match
---
operator: = [51653,51654]
operator: = [51705,51706]
===
match
---
atom_expr [49548,49589]
atom_expr [49600,49641]
===
match
---
atom [33640,33668]
atom [33640,33668]
===
match
---
for_stmt [47279,47471]
for_stmt [47331,47523]
===
match
---
atom_expr [79586,79613]
atom_expr [79638,79665]
===
match
---
operator: , [62437,62438]
operator: , [62489,62490]
===
match
---
simple_stmt [47989,48008]
simple_stmt [48041,48060]
===
match
---
name: property [8076,8084]
name: property [8076,8084]
===
match
---
arglist [27849,27877]
arglist [27849,27877]
===
match
---
name: int [80365,80368]
name: int [80417,80420]
===
match
---
name: PodGenerator [68941,68953]
name: PodGenerator [68993,69005]
===
match
---
trailer [51422,51440]
trailer [51474,51492]
===
match
---
trailer [54890,54895]
trailer [54942,54947]
===
match
---
operator: , [37810,37811]
operator: , [37810,37811]
===
match
---
trailer [72304,72355]
trailer [72356,72407]
===
match
---
name: Integer [9825,9832]
name: Integer [9825,9832]
===
match
---
return_stmt [34767,34795]
return_stmt [34767,34795]
===
match
---
name: self [20854,20858]
name: self [20854,20858]
===
match
---
simple_stmt [2400,2443]
simple_stmt [2400,2443]
===
match
---
suite [41481,41536]
suite [41450,41505]
===
match
---
string: "airflow" [17916,17925]
string: "airflow" [17916,17925]
===
match
---
operator: = [31888,31889]
operator: = [31888,31889]
===
match
---
comp_op [53148,53154]
comp_op [53200,53206]
===
match
---
arglist [6794,6847]
arglist [6794,6847]
===
match
---
name: xcom_pull [74436,74445]
name: xcom_pull [74488,74497]
===
match
---
name: isoformat [19201,19210]
name: isoformat [19201,19210]
===
match
---
name: prev_execution_date [61154,61173]
name: prev_execution_date [61206,61225]
===
match
---
name: String [10134,10140]
name: String [10134,10140]
===
match
---
operator: = [14525,14526]
operator: = [14525,14526]
===
match
---
atom_expr [48734,48751]
atom_expr [48786,48803]
===
match
---
atom_expr [33840,33851]
atom_expr [33840,33851]
===
match
---
operator: { [48733,48734]
operator: { [48785,48786]
===
match
---
atom_expr [72913,72926]
atom_expr [72965,72978]
===
match
---
trailer [58942,58948]
trailer [58994,59000]
===
match
---
expr_stmt [34512,34590]
expr_stmt [34512,34590]
===
match
---
string: 'prev_ds_nodash' [65015,65031]
string: 'prev_ds_nodash' [65067,65083]
===
match
---
name: reschedule_date [55615,55630]
name: reschedule_date [55667,55682]
===
match
---
name: State [57043,57048]
name: State [57095,57100]
===
match
---
name: value [51863,51868]
name: value [51915,51920]
===
match
---
name: variable [2031,2039]
name: variable [2031,2039]
===
match
---
string: 'kcah_acitats' [82408,82422]
string: 'kcah_acitats' [82460,82474]
===
match
---
operator: = [41816,41817]
operator: = [41785,41786]
===
match
---
except_clause [43271,43303]
except_clause [43323,43355]
===
match
---
expr_stmt [82341,82357]
expr_stmt [82393,82409]
===
match
---
name: State [29021,29026]
name: State [29021,29026]
===
match
---
atom_expr [77273,77283]
atom_expr [77325,77335]
===
match
---
operator: @ [80988,80989]
operator: @ [81040,81041]
===
match
---
atom_expr [25997,26017]
atom_expr [25997,26017]
===
match
---
name: result [51795,51801]
name: result [51847,51853]
===
match
---
name: extend [18524,18530]
name: extend [18524,18530]
===
match
---
name: self [24276,24280]
name: self [24276,24280]
===
match
---
name: log [52210,52213]
name: log [52262,52265]
===
match
---
name: task [52059,52063]
name: task [52111,52115]
===
match
---
simple_stmt [9556,9611]
simple_stmt [9556,9611]
===
match
---
atom_expr [52059,52083]
atom_expr [52111,52135]
===
match
---
trailer [68732,68734]
trailer [68784,68786]
===
match
---
atom_expr [27059,27101]
atom_expr [27059,27101]
===
match
---
expr_stmt [7407,7433]
expr_stmt [7407,7433]
===
match
---
simple_stmt [885,901]
simple_stmt [885,901]
===
match
---
trailer [43231,43235]
trailer [43283,43287]
===
match
---
trailer [80889,80901]
trailer [80941,80953]
===
match
---
trailer [79129,79160]
trailer [79181,79212]
===
match
---
name: self [57057,57061]
name: self [57109,57113]
===
match
---
name: actual_start_date [55528,55545]
name: actual_start_date [55580,55597]
===
match
---
name: dag_run [46841,46848]
name: dag_run [46893,46900]
===
match
---
string: 'core' [62431,62437]
string: 'core' [62483,62489]
===
match
---
expr_stmt [53093,53109]
expr_stmt [53145,53161]
===
match
---
name: test_mode [56108,56117]
name: test_mode [56160,56169]
===
match
---
suite [66557,66598]
suite [66609,66650]
===
match
---
fstring_string: &execution_date= [19697,19713]
fstring_string: &execution_date= [19697,19713]
===
match
---
name: self [30353,30357]
name: self [30353,30357]
===
match
---
name: bool [15895,15899]
name: bool [15895,15899]
===
match
---
atom_expr [11709,11768]
atom_expr [11709,11768]
===
match
---
operator: ** [9515,9517]
operator: ** [9515,9517]
===
match
---
name: dag_id [78769,78775]
name: dag_id [78821,78827]
===
match
---
name: str [80311,80314]
name: str [80363,80366]
===
match
---
trailer [30370,30389]
trailer [30370,30389]
===
match
---
atom_expr [24249,24260]
atom_expr [24249,24260]
===
match
---
operator: , [81604,81605]
operator: , [81656,81657]
===
match
---
name: tomorrow_ds [62242,62253]
name: tomorrow_ds [62294,62305]
===
match
---
name: path [14835,14839]
name: path [14835,14839]
===
match
---
operator: , [54522,54523]
operator: , [54574,54575]
===
match
---
name: Tuple [8110,8115]
name: Tuple [8110,8115]
===
match
---
annassign [80182,80204]
annassign [80234,80256]
===
match
---
name: XCom [23918,23922]
name: XCom [23918,23922]
===
match
---
argument [71396,71411]
argument [71448,71463]
===
match
---
simple_stmt [61527,61578]
simple_stmt [61579,61630]
===
match
---
name: RenderedTaskInstanceFields [67199,67225]
name: RenderedTaskInstanceFields [67251,67277]
===
match
---
trailer [23864,24013]
trailer [23864,24013]
===
match
---
atom_expr [11193,11205]
atom_expr [11193,11205]
===
match
---
simple_stmt [72716,72771]
simple_stmt [72768,72823]
===
match
---
name: dag_id [78957,78963]
name: dag_id [79009,79015]
===
match
---
name: execution_date [76476,76490]
name: execution_date [76528,76542]
===
match
---
simple_stmt [25967,26282]
simple_stmt [25967,26282]
===
match
---
name: self [63864,63868]
name: self [63916,63920]
===
match
---
testlist [8215,8261]
testlist [8215,8261]
===
match
---
operator: , [56238,56239]
operator: , [56290,56291]
===
match
---
argument [38274,38305]
argument [38274,38305]
===
match
---
comparison [24801,24829]
comparison [24801,24829]
===
match
---
atom_expr [49185,49352]
atom_expr [49237,49404]
===
match
---
atom_expr [30095,30145]
atom_expr [30095,30145]
===
match
---
annassign [79945,79971]
annassign [79997,80023]
===
match
---
name: airflow [2293,2300]
name: airflow [2293,2300]
===
match
---
name: hr_line_break [40294,40307]
name: hr_line_break [40294,40307]
===
match
---
name: ignore_ti_state [15180,15195]
name: ignore_ti_state [15180,15195]
===
match
---
arglist [50558,50588]
arglist [50610,50640]
===
match
---
name: execution_date [8025,8039]
name: execution_date [8025,8039]
===
match
---
atom_expr [69027,69058]
atom_expr [69079,69110]
===
match
---
name: dag_id [9484,9490]
name: dag_id [9484,9490]
===
match
---
simple_stmt [52587,52604]
simple_stmt [52639,52656]
===
match
---
simple_stmt [20888,20908]
simple_stmt [20888,20908]
===
match
---
trailer [79834,79843]
trailer [79886,79895]
===
match
---
name: test_mode [55132,55141]
name: test_mode [55184,55193]
===
match
---
if_stmt [4022,4055]
if_stmt [4022,4055]
===
match
---
name: activate_dag_runs [7442,7459]
name: activate_dag_runs [7442,7459]
===
match
---
return_stmt [78727,78929]
return_stmt [78779,78981]
===
match
---
arglist [72220,72265]
arglist [72272,72317]
===
match
---
name: _date_or_empty [43907,43921]
name: _date_or_empty [43959,43973]
===
match
---
operator: = [38345,38346]
operator: = [38345,38346]
===
match
---
lambdef [65189,65250]
lambdef [65241,65302]
===
match
---
atom_expr [67907,67919]
atom_expr [67959,67971]
===
match
---
sync_comp_for [79147,79159]
sync_comp_for [79199,79211]
===
match
---
name: self [73017,73021]
name: self [73069,73073]
===
match
---
name: job_id [15917,15923]
name: job_id [15917,15923]
===
match
---
operator: = [35118,35119]
operator: = [35118,35119]
===
match
---
string: """Overwrite Task Params with DagRun.conf""" [67699,67743]
string: """Overwrite Task Params with DagRun.conf""" [67751,67795]
===
match
---
trailer [43741,43748]
trailer [43793,43800]
===
match
---
strings [40016,40164]
strings [40016,40164]
===
match
---
name: TaskInstance [78803,78815]
name: TaskInstance [78855,78867]
===
match
---
trailer [34674,34679]
trailer [34674,34679]
===
match
---
param [19836,19841]
param [19836,19841]
===
match
---
operator: , [45806,45807]
operator: , [45858,45859]
===
match
---
name: self [60654,60658]
name: self [60706,60710]
===
match
---
simple_stmt [69027,69059]
simple_stmt [69079,69111]
===
match
---
atom_expr [50388,50416]
atom_expr [50440,50468]
===
match
---
name: error [59343,59348]
name: error [59395,59400]
===
match
---
number: 1 [37815,37816]
number: 1 [37815,37816]
===
match
---
simple_stmt [53093,53110]
simple_stmt [53145,53162]
===
match
---
name: self [82099,82103]
name: self [82151,82155]
===
match
---
trailer [30866,30874]
trailer [30866,30874]
===
match
---
name: html_content [72381,72393]
name: html_content [72433,72445]
===
match
---
operator: , [15798,15799]
operator: , [15798,15799]
===
match
---
annassign [79804,79821]
annassign [79856,79873]
===
match
---
trailer [11261,11267]
trailer [11261,11267]
===
match
---
expr_stmt [10078,10111]
expr_stmt [10078,10111]
===
match
---
parameters [3869,3884]
parameters [3869,3884]
===
match
---
trailer [50788,50792]
trailer [50840,50844]
===
match
---
trailer [21967,21976]
trailer [21967,21976]
===
match
---
expr_stmt [62161,62212]
expr_stmt [62213,62264]
===
match
---
name: timezone [50900,50908]
name: timezone [50952,50960]
===
match
---
funcdef [63766,63818]
funcdef [63818,63870]
===
match
---
name: Index [10738,10743]
name: Index [10738,10743]
===
match
---
string: 'dag' [60056,60061]
string: 'dag' [60108,60113]
===
match
---
expr_stmt [62096,62152]
expr_stmt [62148,62204]
===
match
---
name: deps [32474,32478]
name: deps [32474,32478]
===
match
---
simple_stmt [34963,35054]
simple_stmt [34963,35054]
===
match
---
atom_expr [59069,59090]
atom_expr [59121,59142]
===
match
---
name: PickleType [10280,10290]
name: PickleType [10280,10290]
===
match
---
name: update [62383,62389]
name: update [62435,62441]
===
match
---
atom_expr [80073,80084]
atom_expr [80125,80136]
===
match
---
name: error [56419,56424]
name: error [56471,56476]
===
match
---
name: dr [26919,26921]
name: dr [26919,26921]
===
match
---
operator: , [4722,4723]
operator: , [4722,4723]
===
match
---
trailer [65328,65417]
trailer [65380,65469]
===
match
---
name: TaskInstanceKey [24233,24248]
name: TaskInstanceKey [24233,24248]
===
match
---
trailer [48961,48980]
trailer [49013,49032]
===
match
---
trailer [18696,18721]
trailer [18696,18721]
===
match
---
name: context [48808,48815]
name: context [48860,48867]
===
match
---
simple_stmt [18573,18602]
simple_stmt [18573,18602]
===
match
---
import_from [2547,2589]
import_from [2547,2589]
===
match
---
name: pool [53704,53708]
name: pool [53756,53760]
===
match
---
name: self [39791,39795]
name: self [39791,39795]
===
match
---
name: dag [4714,4717]
name: dag [4714,4717]
===
match
---
name: dr [26803,26805]
name: dr [26803,26805]
===
match
---
name: session [40414,40421]
name: session [40414,40421]
===
match
---
simple_stmt [18630,18652]
simple_stmt [18630,18652]
===
match
---
atom_expr [38599,38615]
atom_expr [38599,38615]
===
match
---
trailer [19635,19643]
trailer [19635,19643]
===
match
---
operator: , [9964,9965]
operator: , [9964,9965]
===
match
---
trailer [50604,50609]
trailer [50656,50661]
===
match
---
name: execution_date [8247,8261]
name: execution_date [8247,8261]
===
match
---
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [70278,70322]
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [70330,70374]
===
match
---
atom_expr [60513,60529]
atom_expr [60565,60581]
===
match
---
trailer [60627,60629]
trailer [60679,60681]
===
match
---
string: """URL to mark TI success""" [19421,19449]
string: """URL to mark TI success""" [19421,19449]
===
match
---
param [30965,30978]
param [30965,30978]
===
match
---
name: failed [31680,31686]
name: failed [31680,31686]
===
match
---
name: self [43451,43455]
name: self [43503,43507]
===
match
---
simple_stmt [47820,47973]
simple_stmt [47872,48025]
===
match
---
atom_expr [64069,64082]
atom_expr [64121,64134]
===
match
---
operator: , [63334,63335]
operator: , [63386,63387]
===
match
---
simple_stmt [49185,49353]
simple_stmt [49237,49405]
===
match
---
name: state [20520,20525]
name: state [20520,20525]
===
match
---
tfpdef [11079,11099]
tfpdef [11079,11099]
===
match
---
operator: , [65895,65896]
operator: , [65947,65948]
===
match
---
tfpdef [73226,73242]
tfpdef [73278,73294]
===
match
---
name: FAILED [57866,57872]
name: FAILED [57918,57924]
===
match
---
name: Optional [26429,26437]
name: Optional [26429,26437]
===
match
---
name: reconstructor [12412,12425]
name: reconstructor [12412,12425]
===
match
---
name: typing [1023,1029]
name: typing [1023,1029]
===
match
---
atom_expr [80109,80130]
atom_expr [80161,80182]
===
match
---
trailer [21696,21711]
trailer [21696,21711]
===
match
---
name: str [29133,29136]
name: str [29133,29136]
===
match
---
name: task [60126,60130]
name: task [60178,60182]
===
match
---
simple_stmt [857,871]
simple_stmt [857,871]
===
match
---
if_stmt [18041,18108]
if_stmt [18041,18108]
===
match
---
name: Optional [53674,53682]
name: Optional [53726,53734]
===
match
---
suite [8136,8262]
suite [8136,8262]
===
match
---
parameters [80850,80856]
parameters [80902,80908]
===
match
---
number: 1000 [9863,9867]
number: 1000 [9863,9867]
===
match
---
operator: -> [81023,81025]
operator: -> [81075,81077]
===
match
---
atom_expr [23442,23454]
atom_expr [23442,23454]
===
match
---
name: dag [60323,60326]
name: dag [60375,60378]
===
match
---
argument [74222,74233]
argument [74274,74285]
===
match
---
operator: = [58031,58032]
operator: = [58083,58084]
===
match
---
name: min_backoff [33588,33599]
name: min_backoff [33588,33599]
===
match
---
suite [20610,20933]
suite [20610,20933]
===
match
---
trailer [40545,40550]
trailer [40545,40550]
===
match
---
name: ti [26298,26300]
name: ti [26298,26300]
===
match
---
name: Optional [41802,41810]
name: Optional [41771,41779]
===
match
---
name: task [48263,48267]
name: task [48315,48319]
===
match
---
trailer [81194,81200]
trailer [81246,81252]
===
match
---
name: session [40922,40929]
name: session [40891,40898]
===
match
---
trailer [26770,26774]
trailer [26770,26774]
===
match
---
name: session [19842,19849]
name: session [19842,19849]
===
match
---
name: state [5125,5130]
name: state [5125,5130]
===
match
---
name: self [81330,81334]
name: self [81382,81386]
===
match
---
trailer [22527,22538]
trailer [22527,22538]
===
match
---
suite [33325,34759]
suite [33325,34759]
===
match
---
operator: @ [58985,58986]
operator: @ [59037,59038]
===
match
---
param [33047,33051]
param [33047,33051]
===
match
---
atom_expr [32577,32812]
atom_expr [32577,32812]
===
match
---
name: prev_ti [30282,30289]
name: prev_ti [30282,30289]
===
match
---
param [41832,41845]
param [41801,41814]
===
match
---
atom_expr [11086,11099]
atom_expr [11086,11099]
===
match
---
name: self [68555,68559]
name: self [68607,68611]
===
match
---
atom_expr [20298,20318]
atom_expr [20298,20318]
===
match
---
name: ignore_task_deps [53518,53534]
name: ignore_task_deps [53570,53586]
===
match
---
trailer [44048,44050]
trailer [44100,44102]
===
match
---
operator: , [50831,50832]
operator: , [50883,50884]
===
match
---
param [59754,59766]
param [59806,59818]
===
match
---
operator: != [14649,14651]
operator: != [14649,14651]
===
match
---
name: exception [69197,69206]
name: exception [69249,69258]
===
match
---
name: ts [62116,62118]
name: ts [62168,62170]
===
match
---
operator: - [33663,33664]
operator: - [33663,33664]
===
match
---
trailer [57034,57038]
trailer [57086,57090]
===
match
---
name: render [71389,71395]
name: render [71441,71447]
===
match
---
arglist [40739,40758]
arglist [40739,40758]
===
match
---
trailer [48980,49007]
trailer [49032,49059]
===
match
---
operator: , [64738,64739]
operator: , [64790,64791]
===
match
---
atom_expr [13123,13139]
atom_expr [13123,13139]
===
match
---
arglist [49140,49171]
arglist [49192,49223]
===
match
---
name: test_mode [57004,57013]
name: test_mode [57056,57065]
===
match
---
name: task_copy [50471,50480]
name: task_copy [50523,50532]
===
match
---
simple_stmt [24031,24048]
simple_stmt [24031,24048]
===
match
---
name: _log [11281,11285]
name: _log [11281,11285]
===
match
---
arglist [58313,58645]
arglist [58365,58697]
===
match
---
comparison [54658,54685]
comparison [54710,54737]
===
match
---
name: session [20916,20923]
name: session [20916,20923]
===
match
---
simple_stmt [10152,10186]
simple_stmt [10152,10186]
===
match
---
string: "Dependencies all met for %s" [32188,32217]
string: "Dependencies all met for %s" [32188,32217]
===
match
---
name: clear_xcom_data [48665,48680]
name: clear_xcom_data [48717,48732]
===
match
---
raise_stmt [73975,74169]
raise_stmt [74027,74221]
===
match
---
trailer [37782,37787]
trailer [37782,37787]
===
match
---
trailer [44567,44573]
trailer [44619,44625]
===
match
---
operator: , [37584,37585]
operator: , [37584,37585]
===
match
---
name: session [27761,27768]
name: session [27761,27768]
===
match
---
operator: , [11077,11078]
operator: , [11077,11078]
===
match
---
name: client [2921,2927]
name: client [2921,2927]
===
match
---
name: warning [49948,49955]
name: warning [50000,50007]
===
match
---
operator: , [1095,1096]
operator: , [1095,1096]
===
match
---
expr_stmt [59855,59871]
expr_stmt [59907,59923]
===
match
---
name: force_fail [57788,57798]
name: force_fail [57840,57850]
===
match
---
trailer [52823,52829]
trailer [52875,52881]
===
match
---
atom_expr [41312,41331]
atom_expr [41281,41300]
===
match
---
operator: , [33979,33980]
operator: , [33979,33980]
===
match
---
operator: = [27726,27727]
operator: = [27726,27727]
===
match
---
param [14252,14264]
param [14252,14264]
===
match
---
arglist [10348,10372]
arglist [10348,10372]
===
match
---
name: _run_mini_scheduler_on_child_tasks [45604,45638]
name: _run_mini_scheduler_on_child_tasks [45656,45690]
===
match
---
name: actual_start_date [44087,44104]
name: actual_start_date [44139,44156]
===
match
---
operator: } [44975,44976]
operator: } [45027,45028]
===
match
---
trailer [8504,8515]
trailer [8504,8515]
===
match
---
atom_expr [72716,72770]
atom_expr [72768,72822]
===
match
---
name: get [71938,71941]
name: get [71990,71993]
===
match
---
trailer [27760,27777]
trailer [27760,27777]
===
match
---
name: executor_namespace [68893,68911]
name: executor_namespace [68945,68963]
===
match
---
expr_stmt [11276,11321]
expr_stmt [11276,11321]
===
match
---
name: str [80690,80693]
name: str [80742,80745]
===
match
---
simple_stmt [39890,39914]
simple_stmt [39890,39914]
===
match
---
trailer [59506,59516]
trailer [59558,59568]
===
match
---
suite [78078,79487]
suite [78130,79539]
===
match
---
name: TaskInstanceKey [81407,81422]
name: TaskInstanceKey [81459,81474]
===
match
---
not_test [78163,78170]
not_test [78215,78222]
===
match
---
name: pendulum [61942,61950]
name: pendulum [61994,62002]
===
match
---
operator: = [71786,71787]
operator: = [71838,71839]
===
match
---
comparison [47089,47133]
comparison [47141,47185]
===
match
---
name: task_copy [54904,54913]
name: task_copy [54956,54965]
===
match
---
expr_stmt [71227,71309]
expr_stmt [71279,71361]
===
match
---
parameters [11040,11107]
parameters [11040,11107]
===
match
---
atom_expr [42816,42833]
atom_expr [42868,42885]
===
match
---
name: pid [22744,22747]
name: pid [22744,22747]
===
match
---
atom_expr [71497,71762]
atom_expr [71549,71814]
===
match
---
string: 'prev_execution_date' [65061,65082]
string: 'prev_execution_date' [65113,65134]
===
match
---
name: self [65584,65588]
name: self [65636,65640]
===
match
---
name: ti [5191,5193]
name: ti [5191,5193]
===
match
---
param [41754,41781]
param [41723,41750]
===
match
---
name: dag_id [19357,19363]
name: dag_id [19357,19363]
===
match
---
name: max [34566,34569]
name: max [34566,34569]
===
match
---
atom_expr [22439,22450]
atom_expr [22439,22450]
===
match
---
name: dispose [41062,41069]
name: dispose [41031,41038]
===
match
---
trailer [67298,67304]
trailer [67350,67356]
===
match
---
expr_stmt [27569,27637]
expr_stmt [27569,27637]
===
match
---
name: Optional [29716,29724]
name: Optional [29716,29724]
===
match
---
number: 1 [71682,71683]
number: 1 [71734,71735]
===
match
---
decorator [81068,81078]
decorator [81120,81130]
===
match
---
comparison [78968,78994]
comparison [79020,79046]
===
match
---
simple_stmt [68239,68265]
simple_stmt [68291,68317]
===
match
---
atom_expr [23215,23225]
atom_expr [23215,23225]
===
match
---
argument [54402,54427]
argument [54454,54479]
===
match
---
expr_stmt [61276,61345]
expr_stmt [61328,61397]
===
match
---
param [48308,48315]
param [48360,48367]
===
match
---
name: self [80483,80487]
name: self [80535,80539]
===
match
---
trailer [59940,59942]
trailer [59992,59994]
===
match
---
name: params [62356,62362]
name: params [62408,62414]
===
match
---
tfpdef [77992,78045]
tfpdef [78044,78097]
===
match
---
atom_expr [11117,11135]
atom_expr [11117,11135]
===
match
---
name: dep_context [32546,32557]
name: dep_context [32546,32557]
===
match
---
operator: , [72243,72244]
operator: , [72295,72296]
===
match
---
operator: = [59238,59239]
operator: = [59290,59291]
===
match
---
name: airflow [2061,2068]
name: airflow [2061,2068]
===
match
---
trailer [22511,22522]
trailer [22511,22522]
===
match
---
atom_expr [10533,10569]
atom_expr [10533,10569]
===
match
---
trailer [26164,26179]
trailer [26164,26179]
===
match
---
simple_stmt [55685,55722]
simple_stmt [55737,55774]
===
match
---
name: cmd [18573,18576]
name: cmd [18573,18576]
===
match
---
name: task_type [23536,23545]
name: task_type [23536,23545]
===
match
---
arglist [8445,8520]
arglist [8445,8520]
===
match
---
argument [68582,68608]
argument [68634,68660]
===
match
---
fstring_string: &dag_id= [19343,19351]
fstring_string: &dag_id= [19343,19351]
===
match
---
expr_stmt [30085,30145]
expr_stmt [30085,30145]
===
match
---
name: Context [59771,59778]
name: Context [59823,59830]
===
match
---
operator: = [82283,82284]
operator: = [82335,82336]
===
match
---
param [32299,32304]
param [32299,32304]
===
match
---
name: cmd [18755,18758]
name: cmd [18755,18758]
===
match
---
arglist [71942,71954]
arglist [71994,72006]
===
match
---
operator: = [45030,45031]
operator: = [45082,45083]
===
match
---
name: session [25390,25397]
name: session [25390,25397]
===
match
---
trailer [79033,79230]
trailer [79085,79282]
===
match
---
trailer [64682,64703]
trailer [64734,64755]
===
match
---
trailer [59584,59607]
trailer [59636,59659]
===
match
---
expr_stmt [78364,78401]
expr_stmt [78416,78453]
===
match
---
trailer [18476,18489]
trailer [18476,18489]
===
match
---
name: refresh_from_db [44217,44232]
name: refresh_from_db [44269,44284]
===
match
---
atom_expr [14700,14712]
atom_expr [14700,14712]
===
match
---
trailer [48262,48267]
trailer [48314,48319]
===
match
---
parameters [59747,59767]
parameters [59799,59819]
===
match
---
trailer [45362,45377]
trailer [45414,45429]
===
match
---
trailer [6029,6044]
trailer [6029,6044]
===
match
---
name: dag_run [61104,61111]
name: dag_run [61156,61163]
===
match
---
operator: { [19668,19669]
operator: { [19668,19669]
===
match
---
simple_stmt [40769,40796]
simple_stmt [40769,40796]
===
match
---
name: max_tries [71720,71729]
name: max_tries [71772,71781]
===
match
---
trailer [50961,50968]
trailer [51013,51020]
===
match
---
operator: -> [45759,45761]
operator: -> [45811,45813]
===
match
---
return_stmt [72057,72118]
return_stmt [72109,72170]
===
match
---
name: session [38546,38553]
name: session [38546,38553]
===
match
---
suite [2900,3077]
suite [2900,3077]
===
match
---
name: dag [60131,60134]
name: dag [60183,60186]
===
match
---
name: self [35433,35437]
name: self [35433,35437]
===
match
---
operator: , [66509,66510]
operator: , [66561,66562]
===
match
---
operator: , [43748,43749]
operator: , [43800,43801]
===
match
---
name: log [56459,56462]
name: log [56511,56514]
===
match
---
comparison [79335,79369]
comparison [79387,79421]
===
match
---
atom_expr [52101,52134]
atom_expr [52153,52186]
===
match
---
name: log [56542,56545]
name: log [56594,56597]
===
match
---
name: property [81307,81315]
name: property [81359,81367]
===
match
---
atom_expr [63802,63810]
atom_expr [63854,63862]
===
match
---
argument [44699,44720]
argument [44751,44772]
===
match
---
atom_expr [67867,67879]
atom_expr [67919,67931]
===
match
---
string: 'html_content_template' [72305,72328]
string: 'html_content_template' [72357,72380]
===
match
---
name: task_copy [51655,51664]
name: task_copy [51707,51716]
===
match
---
name: _end_date [79985,79994]
name: _end_date [80037,80046]
===
match
---
name: dag_id [19674,19680]
name: dag_id [19674,19680]
===
match
---
comparison [21563,21597]
comparison [21563,21597]
===
match
---
name: self [11144,11148]
name: self [11144,11148]
===
match
---
name: content [71846,71853]
name: content [71898,71905]
===
match
---
name: self [66103,66107]
name: self [66155,66159]
===
match
---
atom_expr [54729,54745]
atom_expr [54781,54797]
===
match
---
name: strftime [60770,60778]
name: strftime [60822,60830]
===
match
---
argument [50575,50588]
argument [50627,50640]
===
match
---
atom_expr [40894,40913]
atom_expr [40863,40882]
===
match
---
operator: = [16015,16016]
operator: = [16015,16016]
===
match
---
name: str [18091,18094]
name: str [18091,18094]
===
match
---
name: session [74387,74394]
name: session [74439,74446]
===
match
---
trailer [57111,57115]
trailer [57163,57167]
===
match
---
trailer [60617,60627]
trailer [60669,60679]
===
match
---
operator: , [30949,30950]
operator: , [30949,30950]
===
match
---
name: Stats [50599,50604]
name: Stats [50651,50656]
===
match
---
import_from [2815,2852]
import_from [2815,2852]
===
match
---
name: result [59568,59574]
name: result [59620,59626]
===
match
---
name: refresh_from_db [44394,44409]
name: refresh_from_db [44446,44461]
===
match
---
name: context [51673,51680]
name: context [51725,51732]
===
match
---
name: priority_weight [22595,22610]
name: priority_weight [22595,22610]
===
match
---
trailer [61841,61853]
trailer [61893,61905]
===
match
---
name: self [41449,41453]
name: self [41418,41422]
===
match
---
number: 0 [78322,78323]
number: 0 [78374,78375]
===
match
---
atom_expr [4386,4408]
atom_expr [4386,4408]
===
match
---
expr_stmt [31881,31894]
expr_stmt [31881,31894]
===
match
---
trailer [9952,9981]
trailer [9952,9981]
===
match
---
trailer [23797,23801]
trailer [23797,23801]
===
match
---
trailer [60738,60753]
trailer [60790,60805]
===
match
---
name: Optional [35980,35988]
name: Optional [35980,35988]
===
match
---
operator: , [15475,15476]
operator: , [15475,15476]
===
match
---
name: _Variable__NO_DEFAULT_SENTINEL [63304,63334]
name: _Variable__NO_DEFAULT_SENTINEL [63356,63386]
===
match
---
atom_expr [23515,23528]
atom_expr [23515,23528]
===
match
---
name: utils [2503,2508]
name: utils [2503,2508]
===
match
---
name: Sentry [41581,41587]
name: Sentry [41550,41556]
===
match
---
simple_stmt [81432,81449]
simple_stmt [81484,81501]
===
match
---
name: self [72896,72900]
name: self [72948,72952]
===
match
---
tfpdef [35788,35810]
tfpdef [35788,35810]
===
match
---
atom_expr [10273,10305]
atom_expr [10273,10305]
===
match
---
atom_expr [22507,22522]
atom_expr [22507,22522]
===
match
---
name: ApiClient [69083,69092]
name: ApiClient [69135,69144]
===
match
---
trailer [48707,48763]
trailer [48759,48815]
===
match
---
suite [72450,72771]
suite [72502,72823]
===
match
---
name: ti [47225,47227]
name: ti [47277,47279]
===
match
---
atom_expr [79246,79486]
atom_expr [79298,79538]
===
match
---
trailer [20258,20265]
trailer [20258,20265]
===
match
---
name: self [59386,59390]
name: self [59438,59442]
===
match
---
simple_stmt [80483,80511]
simple_stmt [80535,80563]
===
match
---
simple_stmt [60638,60711]
simple_stmt [60690,60763]
===
match
---
simple_stmt [79830,79862]
simple_stmt [79882,79914]
===
match
---
comparison [82176,82227]
comparison [82228,82279]
===
match
---
suite [52192,52266]
suite [52244,52318]
===
match
---
string: 'tomorrow_ds' [65636,65649]
string: 'tomorrow_ds' [65688,65701]
===
match
---
operator: , [14199,14200]
operator: , [14199,14200]
===
match
---
atom_expr [71875,71904]
atom_expr [71927,71956]
===
match
---
operator: == [26328,26330]
operator: == [26328,26330]
===
match
---
arith_expr [24954,24985]
arith_expr [24954,24985]
===
match
---
name: ti [6027,6029]
name: ti [6027,6029]
===
match
---
argument [68925,69007]
argument [68977,69059]
===
match
---
string: """Returns TaskInstanceKey with provided ``try_number``""" [8600,8658]
string: """Returns TaskInstanceKey with provided ``try_number``""" [8600,8658]
===
match
---
operator: = [73210,73211]
operator: = [73262,73263]
===
match
---
trailer [29453,29457]
trailer [29453,29457]
===
match
---
name: ValueError [73981,73991]
name: ValueError [74033,74043]
===
match
---
simple_stmt [22507,22544]
simple_stmt [22507,22544]
===
match
---
simple_stmt [41265,41333]
simple_stmt [41234,41302]
===
match
---
operator: = [59183,59184]
operator: = [59235,59236]
===
match
---
trailer [20221,20228]
trailer [20221,20228]
===
match
---
trailer [43464,43467]
trailer [43516,43519]
===
match
---
atom_expr [60112,60142]
atom_expr [60164,60194]
===
match
---
expr_stmt [58137,58168]
expr_stmt [58189,58220]
===
match
---
name: self [69438,69442]
name: self [69490,69494]
===
match
---
name: key [71951,71954]
name: key [72003,72006]
===
match
---
name: COLLATION_ARGS [9517,9531]
name: COLLATION_ARGS [9517,9531]
===
match
---
trailer [49368,49376]
trailer [49420,49428]
===
match
---
name: state [27587,27592]
name: state [27587,27592]
===
match
---
name: from_string [71351,71362]
name: from_string [71403,71414]
===
match
---
name: html_content [72527,72539]
name: html_content [72579,72591]
===
match
---
decorator [12411,12426]
decorator [12411,12426]
===
match
---
name: add [57035,57038]
name: add [57087,57090]
===
match
---
atom_expr [82028,82238]
atom_expr [82080,82290]
===
match
---
return_stmt [38632,38644]
return_stmt [38632,38644]
===
match
---
name: Log [57039,57042]
name: Log [57091,57094]
===
match
---
atom_expr [41153,41230]
atom_expr [41122,41199]
===
match
---
name: ti [5295,5297]
name: ti [5295,5297]
===
match
---
operator: , [15769,15770]
operator: , [15769,15770]
===
match
---
name: prev_ti [30085,30092]
name: prev_ti [30085,30092]
===
match
---
name: task [23299,23303]
name: task [23299,23303]
===
match
---
operator: , [39756,39757]
operator: , [39756,39757]
===
match
---
name: defaultdict [925,936]
name: defaultdict [925,936]
===
match
---
trailer [63128,63132]
trailer [63180,63184]
===
match
---
operator: - [38189,38190]
operator: - [38189,38190]
===
match
---
atom_expr [54366,54612]
atom_expr [54418,54664]
===
match
---
operator: = [41738,41739]
operator: = [41707,41708]
===
match
---
name: RenderedTaskInstanceFields [66283,66309]
name: RenderedTaskInstanceFields [66335,66361]
===
match
---
name: self [25311,25315]
name: self [25311,25315]
===
match
---
simple_stmt [77540,77815]
simple_stmt [77592,77867]
===
match
---
name: session [57027,57034]
name: session [57079,57086]
===
match
---
suite [32479,32893]
suite [32479,32893]
===
match
---
name: error_file [44309,44319]
name: error_file [44361,44371]
===
match
---
operator: -> [29768,29770]
operator: -> [29768,29770]
===
match
---
name: String [9500,9506]
name: String [9500,9506]
===
match
---
operator: = [61174,61175]
operator: = [61226,61227]
===
match
---
name: execution_date [79111,79125]
name: execution_date [79163,79177]
===
match
---
param [19115,19119]
param [19115,19119]
===
match
---
operator: + [40238,40239]
operator: + [40238,40239]
===
match
---
name: task_id [74260,74267]
name: task_id [74312,74319]
===
match
---
atom_expr [58834,58895]
atom_expr [58886,58947]
===
match
---
trailer [5341,5350]
trailer [5341,5350]
===
match
---
operator: , [15015,15016]
operator: , [15015,15016]
===
match
---
atom_expr [78891,78900]
atom_expr [78943,78952]
===
match
---
simple_stmt [46017,46284]
simple_stmt [46069,46336]
===
match
---
operator: , [54122,54123]
operator: , [54174,54175]
===
match
---
param [15779,15799]
param [15779,15799]
===
match
---
trailer [31734,31739]
trailer [31734,31739]
===
match
---
suite [53768,54799]
suite [53820,54851]
===
match
---
name: nullable [9966,9974]
name: nullable [9966,9974]
===
match
---
atom_expr [49116,49172]
atom_expr [49168,49224]
===
match
---
trailer [39938,39946]
trailer [39938,39946]
===
match
---
name: bool [35881,35885]
name: bool [35881,35885]
===
match
---
string: """Handle Failure for the TaskInstance""" [56263,56304]
string: """Handle Failure for the TaskInstance""" [56315,56356]
===
match
---
string: """Functions that need to be run before a Task is executed""" [51969,52030]
string: """Functions that need to be run before a Task is executed""" [52021,52082]
===
match
---
name: self [14906,14910]
name: self [14906,14910]
===
match
---
trailer [57048,57055]
trailer [57100,57107]
===
match
---
name: queued_by_job [82640,82653]
name: queued_by_job [82692,82705]
===
match
---
operator: @ [63147,63148]
operator: @ [63199,63200]
===
match
---
trailer [40428,40430]
trailer [40428,40430]
===
match
---
name: dag_id [23898,23904]
name: dag_id [23898,23904]
===
match
---
name: task [23400,23404]
name: task [23400,23404]
===
match
---
name: start_date [9615,9625]
name: start_date [9615,9625]
===
match
---
name: ti [22703,22705]
name: ti [22703,22705]
===
match
---
name: airflow_context_vars [49384,49404]
name: airflow_context_vars [49436,49456]
===
match
---
operator: , [15907,15908]
operator: , [15907,15908]
===
match
---
name: job_ids [7370,7377]
name: job_ids [7370,7377]
===
match
---
trailer [54662,54668]
trailer [54714,54720]
===
match
---
name: iso [17960,17963]
name: iso [17960,17963]
===
match
---
simple_stmt [67102,67147]
simple_stmt [67154,67199]
===
match
---
trailer [64417,64471]
trailer [64469,64523]
===
match
---
argument [9515,9531]
argument [9515,9531]
===
match
---
funcdef [81220,81301]
funcdef [81272,81353]
===
match
---
name: ti [21825,21827]
name: ti [21825,21827]
===
match
---
simple_stmt [66680,67056]
simple_stmt [66732,67108]
===
match
---
tfpdef [15779,15790]
tfpdef [15779,15790]
===
match
---
atom_expr [47402,47421]
atom_expr [47454,47473]
===
match
---
suite [62472,62557]
suite [62524,62609]
===
match
---
operator: , [15368,15369]
operator: , [15368,15369]
===
match
---
simple_stmt [50784,50839]
simple_stmt [50836,50891]
===
match
---
name: pid [22735,22738]
name: pid [22735,22738]
===
match
---
name: queued_dttm [22689,22700]
name: queued_dttm [22689,22700]
===
match
---
name: delete_old_records [48962,48980]
name: delete_old_records [49014,49032]
===
match
---
trailer [3608,3612]
trailer [3608,3612]
===
match
---
trailer [62489,62524]
trailer [62541,62576]
===
match
---
expr_stmt [22774,22791]
expr_stmt [22774,22791]
===
match
---
trailer [50609,50660]
trailer [50661,50712]
===
match
---
if_stmt [45569,45648]
if_stmt [45621,45700]
===
match
---
name: yesterday_ds_nodash [62161,62180]
name: yesterday_ds_nodash [62213,62232]
===
match
---
atom_expr [71715,71729]
atom_expr [71767,71781]
===
match
---
name: filter_by [60301,60310]
name: filter_by [60353,60362]
===
match
---
number: 1 [13940,13941]
number: 1 [13940,13941]
===
match
---
simple_stmt [40723,40761]
simple_stmt [40723,40761]
===
match
---
name: context [52673,52680]
name: context [52725,52732]
===
match
---
name: ignore_all_deps [38241,38256]
name: ignore_all_deps [38241,38256]
===
match
---
trailer [61302,61306]
trailer [61354,61358]
===
match
---
return_stmt [78184,78195]
return_stmt [78236,78247]
===
match
---
trailer [21549,21722]
trailer [21549,21722]
===
match
---
if_stmt [70505,72356]
if_stmt [70557,72408]
===
match
---
simple_stmt [70533,70562]
simple_stmt [70585,70614]
===
match
---
name: provide_session [19798,19813]
name: provide_session [19798,19813]
===
match
---
simple_stmt [49458,49497]
simple_stmt [49510,49549]
===
match
---
atom_expr [68712,68734]
atom_expr [68764,68786]
===
match
---
arglist [49838,49851]
arglist [49890,49903]
===
match
---
trailer [47654,47661]
trailer [47706,47713]
===
match
---
simple_stmt [11869,11926]
simple_stmt [11869,11926]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28583,28722]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28583,28722]
===
match
---
suite [56744,56795]
suite [56796,56847]
===
match
---
atom_expr [20246,20265]
atom_expr [20246,20265]
===
match
---
operator: ** [10356,10358]
operator: ** [10356,10358]
===
match
---
simple_stmt [52205,52266]
simple_stmt [52257,52318]
===
match
---
operator: = [29138,29139]
operator: = [29138,29139]
===
match
---
simple_stmt [66171,66242]
simple_stmt [66223,66294]
===
match
---
name: pool [54201,54205]
name: pool [54253,54257]
===
match
---
expr [32445,32478]
expr [32445,32478]
===
match
---
name: get_hostname [37661,37673]
name: get_hostname [37661,37673]
===
match
---
simple_stmt [16051,17860]
simple_stmt [16051,17860]
===
match
---
name: self [61408,61412]
name: self [61460,61464]
===
match
---
suite [66378,66527]
suite [66430,66579]
===
match
---
name: task_copy [49801,49810]
name: task_copy [49853,49862]
===
match
---
trailer [48743,48751]
trailer [48795,48803]
===
match
---
name: dag_id [10600,10606]
name: dag_id [10600,10606]
===
match
---
trailer [39816,39872]
trailer [39816,39872]
===
match
---
operator: , [63895,63896]
operator: , [63947,63948]
===
match
---
atom_expr [49458,49496]
atom_expr [49510,49548]
===
match
---
param [20999,21020]
param [20999,21020]
===
match
---
operator: , [64703,64704]
operator: , [64755,64756]
===
match
---
operator: , [79317,79318]
operator: , [79369,79370]
===
match
---
trailer [11828,11839]
trailer [11828,11839]
===
match
---
comparison [56316,56333]
comparison [56368,56385]
===
match
---
name: Integer [9782,9789]
name: Integer [9782,9789]
===
match
---
suite [4275,4632]
suite [4275,4632]
===
match
---
suite [32337,32893]
suite [32337,32893]
===
match
---
operator: = [15874,15875]
operator: = [15874,15875]
===
match
---
arglist [49981,50134]
arglist [50033,50186]
===
match
---
name: get_dagrun [35084,35094]
name: get_dagrun [35084,35094]
===
match
---
name: dag_id [78644,78650]
name: dag_id [78696,78702]
===
match
---
name: Variable [2047,2055]
name: Variable [2047,2055]
===
match
---
argument [45841,45854]
argument [45893,45906]
===
match
---
name: args [43429,43433]
name: args [43481,43485]
===
match
---
name: task_copy [51413,51422]
name: task_copy [51465,51474]
===
match
---
name: self [40392,40396]
name: self [40392,40396]
===
match
---
decorated [19089,19366]
decorated [19089,19366]
===
match
---
name: try_number [33652,33662]
name: try_number [33652,33662]
===
match
---
name: pool_slots [23286,23296]
name: pool_slots [23286,23296]
===
match
---
operator: , [27864,27865]
operator: , [27864,27865]
===
match
---
parameters [20589,20609]
parameters [20589,20609]
===
match
---
operator: , [11015,11016]
operator: , [11015,11016]
===
match
---
trailer [33293,33298]
trailer [33293,33298]
===
match
---
expr_stmt [9874,9905]
expr_stmt [9874,9905]
===
match
---
string: """         Construct a TaskInstance from the database based on the primary key          :param session: DB session.         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :return: the task instance constructed         """ [81654,82013]
string: """         Construct a TaskInstance from the database based on the primary key          :param session: DB session.         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :return: the task instance constructed         """ [81706,82065]
===
match
---
if_stmt [37955,40460]
if_stmt [37955,40460]
===
match
---
suite [26509,28013]
suite [26509,28013]
===
match
---
trailer [69491,69499]
trailer [69543,69551]
===
match
---
funcdef [81152,81201]
funcdef [81204,81253]
===
match
---
operator: } [44947,44948]
operator: } [44999,45000]
===
match
---
atom_expr [45514,45533]
atom_expr [45566,45585]
===
match
---
name: Context [67971,67978]
name: Context [68023,68030]
===
match
---
simple_stmt [2205,2237]
simple_stmt [2205,2237]
===
match
---
trailer [37673,37675]
trailer [37673,37675]
===
match
---
simple_stmt [45016,45050]
simple_stmt [45068,45102]
===
match
---
name: pool [23268,23272]
name: pool [23268,23272]
===
match
---
name: self [50443,50447]
name: self [50495,50499]
===
match
---
suite [13103,13140]
suite [13103,13140]
===
match
---
name: self [65618,65622]
name: self [65670,65674]
===
match
---
name: retries [23447,23454]
name: retries [23447,23454]
===
match
---
trailer [52796,52805]
trailer [52848,52857]
===
match
---
name: items [7122,7127]
name: items [7122,7127]
===
match
---
operator: = [31724,31725]
operator: = [31724,31725]
===
match
---
name: get_previous_start_date [65359,65382]
name: get_previous_start_date [65411,65434]
===
match
---
name: task_copy [49458,49467]
name: task_copy [49510,49519]
===
match
---
trailer [28494,28496]
trailer [28494,28496]
===
match
---
operator: -> [24125,24127]
operator: -> [24125,24127]
===
match
---
trailer [35381,35387]
trailer [35381,35387]
===
match
---
operator: = [9944,9945]
operator: = [9944,9945]
===
match
---
trailer [21923,21934]
trailer [21923,21934]
===
match
---
simple_stmt [42564,42581]
simple_stmt [42533,42550]
===
match
---
string: '' [12108,12110]
string: '' [12108,12110]
===
match
---
name: provide_session [77372,77387]
name: provide_session [77424,77439]
===
match
---
name: TaskInstanceKey [8674,8689]
name: TaskInstanceKey [8674,8689]
===
match
---
operator: , [53423,53424]
operator: , [53475,53476]
===
match
---
name: Index [1298,1303]
name: Index [1298,1303]
===
match
---
trailer [37442,37447]
trailer [37442,37447]
===
match
---
not_test [57000,57013]
not_test [57052,57065]
===
match
---
suite [8822,79487]
suite [8822,79539]
===
match
---
trailer [71890,71904]
trailer [71942,71956]
===
match
---
operator: = [22739,22740]
operator: = [22739,22740]
===
match
---
expr_stmt [10116,10147]
expr_stmt [10116,10147]
===
match
---
string: ':' [62144,62147]
string: ':' [62196,62199]
===
match
---
param [35659,35664]
param [35659,35664]
===
match
---
param [69197,69206]
param [69249,69258]
===
match
---
operator: , [10877,10878]
operator: , [10877,10878]
===
match
---
trailer [47833,47972]
trailer [47885,48024]
===
match
---
name: dag [27653,27656]
name: dag [27653,27656]
===
match
---
name: task_reschedule [39190,39205]
name: task_reschedule [39190,39205]
===
match
---
operator: , [13223,13224]
operator: , [13223,13224]
===
match
---
trailer [79347,79355]
trailer [79399,79407]
===
match
---
name: self [25270,25274]
name: self [25270,25274]
===
match
---
operator: = [24893,24894]
operator: = [24893,24894]
===
match
---
param [59748,59753]
param [59800,59805]
===
match
---
name: pickle_id [15260,15269]
name: pickle_id [15260,15269]
===
match
---
trailer [57115,57184]
trailer [57167,57236]
===
match
---
operator: = [68673,68674]
operator: = [68725,68726]
===
match
---
name: execution_date [8477,8491]
name: execution_date [8477,8491]
===
match
---
name: dag_run [61116,61123]
name: dag_run [61168,61175]
===
match
---
operator: , [64422,64423]
operator: , [64474,64475]
===
match
---
atom_expr [44965,44975]
atom_expr [45017,45027]
===
match
---
trailer [10060,10073]
trailer [10060,10073]
===
match
---
name: task [46590,46594]
name: task [46642,46646]
===
match
---
string: "--cfg-path" [18767,18779]
string: "--cfg-path" [18767,18779]
===
match
---
name: relationship [10845,10857]
name: relationship [10845,10857]
===
match
---
trailer [48888,48921]
trailer [48940,48973]
===
match
---
name: jinja_context [71200,71213]
name: jinja_context [71252,71265]
===
match
---
arglist [80224,80241]
arglist [80276,80293]
===
match
---
expr_stmt [80432,80474]
expr_stmt [80484,80526]
===
match
---
atom_expr [15860,15873]
atom_expr [15860,15873]
===
match
---
trailer [6833,6837]
trailer [6833,6837]
===
match
---
atom_expr [81249,81262]
atom_expr [81301,81314]
===
match
---
trailer [60087,60094]
trailer [60139,60146]
===
match
---
parameters [48057,48078]
parameters [48109,48130]
===
match
---
decorator [73079,73096]
decorator [73131,73148]
===
match
---
name: priority_weight [10078,10093]
name: priority_weight [10078,10093]
===
match
---
trailer [44067,44086]
trailer [44119,44138]
===
match
---
operator: = [62885,62886]
operator: = [62937,62938]
===
match
---
tfpdef [53433,53454]
tfpdef [53485,53506]
===
match
---
trailer [33772,33967]
trailer [33772,33967]
===
match
---
string: """Send alert email with exception information.""" [72459,72509]
string: """Send alert email with exception information.""" [72511,72561]
===
match
---
parameters [12446,12452]
parameters [12446,12452]
===
match
---
operator: = [22611,22612]
operator: = [22611,22612]
===
match
---
atom_expr [50303,50338]
atom_expr [50355,50390]
===
match
---
simple_stmt [21039,21433]
simple_stmt [21039,21433]
===
match
---
operator: = [20526,20527]
operator: = [20526,20527]
===
match
---
atom_expr [20854,20864]
atom_expr [20854,20864]
===
match
---
name: run_id [59996,60002]
name: run_id [60048,60054]
===
match
---
name: TaskInstance [14863,14875]
name: TaskInstance [14863,14875]
===
match
---
expr_stmt [69067,69126]
expr_stmt [69119,69178]
===
match
---
atom_expr [51413,51456]
atom_expr [51465,51508]
===
match
---
name: expanduser [18966,18976]
name: expanduser [18966,18976]
===
match
---
name: settings [69027,69035]
name: settings [69079,69087]
===
match
---
expr_stmt [29510,29570]
expr_stmt [29510,29570]
===
match
---
trailer [21639,21647]
trailer [21639,21647]
===
match
---
operator: , [23904,23905]
operator: , [23904,23905]
===
match
---
decorator [80822,80832]
decorator [80874,80884]
===
match
---
simple_stmt [2110,2171]
simple_stmt [2110,2171]
===
match
---
trailer [8246,8261]
trailer [8246,8261]
===
match
---
string: 'ti_state_lkp' [10673,10687]
string: 'ti_state_lkp' [10673,10687]
===
match
---
operator: , [52329,52330]
operator: , [52381,52382]
===
match
---
simple_stmt [4280,4322]
simple_stmt [4280,4322]
===
match
---
operator: , [65662,65663]
operator: , [65714,65715]
===
match
---
string: """Prepare Task for Execution""" [48088,48120]
string: """Prepare Task for Execution""" [48140,48172]
===
match
---
string: "exception" [52735,52746]
string: "exception" [52787,52798]
===
match
---
name: SUCCESS [54678,54685]
name: SUCCESS [54730,54737]
===
match
---
funcdef [72417,72771]
funcdef [72469,72823]
===
match
---
name: ti [22415,22417]
name: ti [22415,22417]
===
match
---
name: macros [59900,59906]
name: macros [59952,59958]
===
match
---
string: "Rescheduling due to concurrency limits reached " [40016,40065]
string: "Rescheduling due to concurrency limits reached " [40016,40065]
===
match
---
expr_stmt [47488,47531]
expr_stmt [47540,47583]
===
match
---
simple_stmt [61276,61346]
simple_stmt [61328,61398]
===
match
---
atom_expr [61298,61345]
atom_expr [61350,61397]
===
match
---
number: 1 [50655,50656]
number: 1 [50707,50708]
===
match
---
string: """Log URL for TaskInstance""" [19130,19160]
string: """Log URL for TaskInstance""" [19130,19160]
===
match
---
name: _try_number [13128,13139]
name: _try_number [13128,13139]
===
match
---
atom_expr [7210,7237]
atom_expr [7210,7237]
===
match
---
operator: = [80198,80199]
operator: = [80250,80251]
===
match
---
name: cmd [18466,18469]
name: cmd [18466,18469]
===
match
---
name: quote [19175,19180]
name: quote [19175,19180]
===
match
---
name: dep_status [31783,31793]
name: dep_status [31783,31793]
===
match
---
string: 'next_ds_nodash' [64814,64830]
string: 'next_ds_nodash' [64866,64882]
===
match
---
arglist [33760,34000]
arglist [33760,34000]
===
match
---
name: str [81339,81342]
name: str [81391,81394]
===
match
---
argument [79130,79159]
argument [79182,79211]
===
match
---
comparison [6794,6821]
comparison [6794,6821]
===
match
---
trailer [8476,8491]
trailer [8476,8491]
===
match
---
name: self [80681,80685]
name: self [80733,80737]
===
match
---
trailer [46094,46221]
trailer [46146,46273]
===
match
---
tfpdef [29117,29137]
tfpdef [29117,29137]
===
match
---
operator: , [22882,22883]
operator: , [22882,22883]
===
match
---
operator: = [56843,56844]
operator: = [56895,56896]
===
match
---
argument [64449,64470]
argument [64501,64522]
===
match
---
name: strftime [60564,60572]
name: strftime [60616,60624]
===
match
---
name: airflow [60160,60167]
name: airflow [60212,60219]
===
match
---
operator: , [68568,68569]
operator: , [68620,68621]
===
match
---
atom_expr [81279,81300]
atom_expr [81331,81352]
===
match
---
suite [12453,12591]
suite [12453,12591]
===
match
---
name: jinja_env [71341,71350]
name: jinja_env [71393,71402]
===
match
---
return_stmt [30222,30301]
return_stmt [30222,30301]
===
match
---
name: session [37577,37584]
name: session [37577,37584]
===
match
---
trailer [18166,18174]
trailer [18166,18174]
===
match
---
name: str [74624,74627]
name: str [74676,74679]
===
match
---
name: exception_html [69460,69474]
name: exception_html [69512,69526]
===
match
---
operator: , [80398,80399]
operator: , [80450,80451]
===
match
---
name: start_date [80840,80850]
name: start_date [80892,80902]
===
match
---
param [81161,81165]
param [81213,81217]
===
match
---
name: e [44793,44794]
name: e [44845,44846]
===
match
---
name: AirflowFailException [1674,1694]
name: AirflowFailException [1674,1694]
===
match
---
atom_expr [45409,45428]
atom_expr [45461,45480]
===
match
---
name: execution_date [73906,73920]
name: execution_date [73958,73972]
===
match
---
name: self [8500,8504]
name: self [8500,8504]
===
match
---
atom [18697,18720]
atom [18697,18720]
===
match
---
operator: } [47150,47151]
operator: } [47202,47203]
===
match
---
operator: + [37919,37920]
operator: + [37919,37920]
===
match
---
atom_expr [39113,39170]
atom_expr [39113,39170]
===
match
---
name: open [4331,4335]
name: open [4331,4335]
===
match
---
name: session [50926,50933]
name: session [50978,50985]
===
match
---
trailer [43056,43071]
trailer [43108,43123]
===
match
---
name: task_id [19636,19643]
name: task_id [19636,19643]
===
match
---
name: test_mode [44688,44697]
name: test_mode [44740,44749]
===
match
---
name: verbose [35673,35680]
name: verbose [35673,35680]
===
match
---
comparison [24833,24865]
comparison [24833,24865]
===
match
---
operator: @ [80822,80823]
operator: @ [80874,80875]
===
match
---
name: jinja_env [71242,71251]
name: jinja_env [71294,71303]
===
match
---
trailer [5240,5247]
trailer [5240,5247]
===
match
---
name: task_id [47002,47009]
name: task_id [47054,47061]
===
match
---
trailer [5387,5396]
trailer [5387,5396]
===
match
---
term [33616,33668]
term [33616,33668]
===
match
---
trailer [32090,32097]
trailer [32090,32097]
===
match
---
name: jinja2 [71048,71054]
name: jinja2 [71100,71106]
===
match
---
name: AirflowException [44354,44370]
name: AirflowException [44406,44422]
===
match
---
suite [67780,67921]
suite [67832,67973]
===
match
---
parameters [77991,78046]
parameters [78043,78098]
===
match
---
simple_stmt [82366,82376]
simple_stmt [82418,82428]
===
match
---
name: self [12065,12069]
name: self [12065,12069]
===
match
---
name: str [35953,35956]
name: str [35953,35956]
===
match
---
name: task [55435,55439]
name: task [55487,55491]
===
match
---
name: airflow [35285,35292]
name: airflow [35285,35292]
===
match
---
name: fd [3870,3872]
name: fd [3870,3872]
===
match
---
fstring_string: . [32963,32964]
fstring_string: . [32963,32964]
===
match
---
trailer [25996,26018]
trailer [25996,26018]
===
match
---
name: contextlib [3239,3249]
name: contextlib [3239,3249]
===
match
---
trailer [18303,18310]
trailer [18303,18310]
===
match
---
operator: + [13938,13939]
operator: + [13938,13939]
===
match
---
operator: = [82438,82439]
operator: = [82490,82491]
===
match
---
operator: , [1303,1304]
operator: , [1303,1304]
===
match
---
operator: , [7675,7676]
operator: , [7675,7676]
===
match
---
param [62853,62857]
param [62905,62909]
===
match
---
atom_expr [31797,31867]
atom_expr [31797,31867]
===
match
---
trailer [25912,25932]
trailer [25912,25932]
===
match
---
name: task [58089,58093]
name: task [58141,58145]
===
match
---
atom_expr [60431,60445]
atom_expr [60483,60497]
===
match
---
simple_stmt [30085,30146]
simple_stmt [30085,30146]
===
match
---
name: state [40774,40779]
name: state [40774,40779]
===
match
---
suite [14665,14715]
suite [14665,14715]
===
match
---
atom_expr [72560,72601]
atom_expr [72612,72653]
===
match
---
trailer [62389,62402]
trailer [62441,62454]
===
match
---
operator: , [78914,78915]
operator: , [78966,78967]
===
match
---
name: dagrun [60175,60181]
name: dagrun [60227,60233]
===
match
---
atom_expr [46179,46198]
atom_expr [46231,46250]
===
match
---
expr_stmt [69523,69564]
expr_stmt [69575,69616]
===
match
---
suite [3652,3848]
suite [3652,3848]
===
match
---
expr_stmt [56829,56862]
expr_stmt [56881,56914]
===
match
---
trailer [71814,71816]
trailer [71866,71868]
===
match
---
atom_expr [60262,60395]
atom_expr [60314,60447]
===
match
---
name: task_id [77159,77166]
name: task_id [77211,77218]
===
match
---
operator: = [53724,53725]
operator: = [53776,53777]
===
match
---
trailer [18142,18149]
trailer [18142,18149]
===
match
---
name: dry_run [55026,55033]
name: dry_run [55078,55085]
===
match
---
name: state [22779,22784]
name: state [22779,22784]
===
match
---
operator: = [70787,70788]
operator: = [70839,70840]
===
match
---
name: task [44950,44954]
name: task [45002,45006]
===
match
---
trailer [34989,35002]
trailer [34989,35002]
===
match
---
atom_expr [54758,54798]
atom_expr [54810,54850]
===
match
---
name: TaskInstance [21563,21575]
name: TaskInstance [21563,21575]
===
match
---
operator: = [61296,61297]
operator: = [61348,61349]
===
match
---
operator: = [10034,10035]
operator: = [10034,10035]
===
match
---
name: task [54958,54962]
name: task [55010,55014]
===
match
---
argument [65230,65249]
argument [65282,65301]
===
match
---
trailer [7648,7675]
trailer [7648,7675]
===
match
---
name: query [60270,60275]
name: query [60322,60327]
===
match
---
name: str [8000,8003]
name: str [8000,8003]
===
match
---
name: execution_date [11610,11624]
name: execution_date [11610,11624]
===
match
---
operator: , [65508,65509]
operator: , [65560,65561]
===
match
---
name: mark_success [17976,17988]
name: mark_success [17976,17988]
===
match
---
atom_expr [34984,35002]
atom_expr [34984,35002]
===
match
---
name: execution_date [33872,33886]
name: execution_date [33872,33886]
===
match
---
operator: , [65473,65474]
operator: , [65525,65526]
===
match
---
simple_stmt [72627,72678]
simple_stmt [72679,72730]
===
match
---
name: execute [7218,7225]
name: execute [7218,7225]
===
match
---
atom_expr [78803,78830]
atom_expr [78855,78882]
===
match
---
atom [35360,35522]
atom [35360,35522]
===
match
---
trailer [55689,55695]
trailer [55741,55747]
===
match
---
name: info [58295,58299]
name: info [58347,58351]
===
match
---
expr_stmt [9484,9551]
expr_stmt [9484,9551]
===
match
---
name: mark_success [35867,35879]
name: mark_success [35867,35879]
===
match
---
simple_stmt [17868,17901]
simple_stmt [17868,17901]
===
match
---
name: Session [1484,1491]
name: Session [1484,1491]
===
match
---
arglist [43605,43934]
arglist [43657,43986]
===
match
---
atom_expr [25972,26281]
atom_expr [25972,26281]
===
match
---
trailer [55945,56001]
trailer [55997,56053]
===
match
---
trailer [34974,34980]
trailer [34974,34980]
===
match
---
return_stmt [63424,63474]
return_stmt [63476,63526]
===
match
---
name: state [30122,30127]
name: state [30122,30127]
===
match
---
trailer [20923,20930]
trailer [20923,20930]
===
match
---
import_from [1874,1908]
import_from [1874,1908]
===
match
---
simple_stmt [61803,61854]
simple_stmt [61855,61906]
===
match
---
trailer [9925,9934]
trailer [9925,9934]
===
match
---
operator: < [35034,35035]
operator: < [35034,35035]
===
match
---
fstring_expr [32950,32963]
fstring_expr [32950,32963]
===
match
---
return_stmt [59651,59678]
return_stmt [59703,59730]
===
match
---
trailer [51664,51672]
trailer [51716,51724]
===
match
---
simple_stmt [1394,1449]
simple_stmt [1394,1449]
===
match
---
trailer [69035,69053]
trailer [69087,69105]
===
match
---
name: log [11482,11485]
name: log [11482,11485]
===
match
---
name: actual_start_date [42796,42813]
name: actual_start_date [42848,42865]
===
match
---
name: Optional [74529,74537]
name: Optional [74581,74589]
===
match
---
name: dag [26755,26758]
name: dag [26755,26758]
===
match
---
trailer [53191,53212]
trailer [53243,53264]
===
match
---
name: AirflowSkipException [43278,43298]
name: AirflowSkipException [43330,43350]
===
match
---
name: str [80193,80196]
name: str [80245,80248]
===
match
---
string: 'task_instance' [65487,65502]
string: 'task_instance' [65539,65554]
===
match
---
operator: , [49337,49338]
operator: , [49389,49390]
===
match
---
exprlist [7090,7103]
exprlist [7090,7103]
===
match
---
simple_stmt [42681,42719]
simple_stmt [42650,42688]
===
match
---
name: State [24815,24820]
name: State [24815,24820]
===
match
---
trailer [77272,77284]
trailer [77324,77336]
===
match
---
strings [45085,45195]
strings [45137,45247]
===
match
---
operator: , [2103,2104]
operator: , [2103,2104]
===
match
---
name: first_task_id [79202,79215]
name: first_task_id [79254,79267]
===
match
---
name: result [51479,51485]
name: result [51531,51537]
===
match
---
expr_stmt [50882,50917]
expr_stmt [50934,50969]
===
match
---
name: State [5202,5207]
name: State [5202,5207]
===
match
---
trailer [30099,30115]
trailer [30099,30115]
===
match
---
name: try_number [8054,8064]
name: try_number [8054,8064]
===
match
---
atom_expr [33606,33669]
atom_expr [33606,33669]
===
match
---
operator: @ [77955,77956]
operator: @ [78007,78008]
===
match
---
trailer [74537,74564]
trailer [74589,74616]
===
match
---
name: dag_id [42870,42876]
name: dag_id [42922,42928]
===
match
---
suite [56437,56503]
suite [56489,56555]
===
match
---
name: update [60119,60125]
name: update [60171,60177]
===
match
---
name: utcnow [45041,45047]
name: utcnow [45093,45099]
===
match
---
name: xcom [2076,2080]
name: xcom [2076,2080]
===
match
---
atom_expr [57860,57872]
atom_expr [57912,57924]
===
match
---
return_stmt [64481,66064]
return_stmt [64533,66116]
===
match
---
name: provide_session [26367,26382]
name: provide_session [26367,26382]
===
match
---
name: log [20795,20798]
name: log [20795,20798]
===
match
---
name: self [79929,79933]
name: self [79981,79985]
===
match
---
name: self [54366,54370]
name: self [54418,54422]
===
match
---
name: self [12447,12451]
name: self [12447,12451]
===
match
---
atom_expr [42842,42894]
atom_expr [42894,42946]
===
match
---
operator: = [50581,50582]
operator: = [50633,50634]
===
match
---
operator: = [27856,27857]
operator: = [27856,27857]
===
match
---
atom_expr [68415,69018]
atom_expr [68467,69070]
===
match
---
name: self [72560,72564]
name: self [72612,72616]
===
match
---
tfpdef [53704,53723]
tfpdef [53756,53775]
===
match
---
dotted_name [2662,2684]
dotted_name [2662,2684]
===
match
---
not_test [40867,40880]
not_test [40836,40849]
===
match
---
trailer [33933,33940]
trailer [33933,33940]
===
match
---
name: self [22399,22403]
name: self [22399,22403]
===
match
---
atom_expr [79029,79230]
atom_expr [79081,79282]
===
match
---
trailer [37649,37658]
trailer [37649,37658]
===
match
---
name: raw [14233,14236]
name: raw [14233,14236]
===
match
---
name: ti_deps [2250,2257]
name: ti_deps [2250,2257]
===
match
---
trailer [37740,37746]
trailer [37740,37746]
===
match
---
name: full_filepath [14757,14770]
name: full_filepath [14757,14770]
===
match
---
operator: = [69539,69540]
operator: = [69591,69592]
===
match
---
operator: = [15292,15293]
operator: = [15292,15293]
===
match
---
operator: = [42666,42667]
operator: = [42635,42636]
===
match
---
suite [11786,11856]
suite [11786,11856]
===
match
---
fstring_start: f" [19695,19697]
fstring_start: f" [19695,19697]
===
match
---
simple_stmt [80333,80377]
simple_stmt [80385,80429]
===
match
---
name: context [50408,50415]
name: context [50460,50467]
===
match
---
trailer [7637,7644]
trailer [7637,7644]
===
match
---
name: end_date [24959,24967]
name: end_date [24959,24967]
===
match
---
name: RUNNING [77760,77767]
name: RUNNING [77812,77819]
===
match
---
trailer [32456,32461]
trailer [32456,32461]
===
match
---
operator: , [4346,4347]
operator: , [4346,4347]
===
match
---
operator: = [56809,56810]
operator: = [56861,56862]
===
match
---
name: update [71511,71517]
name: update [71563,71569]
===
match
---
atom_expr [32445,32461]
atom_expr [32445,32461]
===
match
---
name: ignore_ti_state [38274,38289]
name: ignore_ti_state [38274,38289]
===
match
---
string: """Is task instance is eligible for retry""" [59401,59445]
string: """Is task instance is eligible for retry""" [59453,59497]
===
match
---
name: deps [32457,32461]
name: deps [32457,32461]
===
match
---
if_stmt [5318,5928]
if_stmt [5318,5928]
===
match
---
name: str [63120,63123]
name: str [63172,63175]
===
match
---
name: task [50637,50641]
name: task [50689,50693]
===
match
---
name: seek [3976,3980]
name: seek [3976,3980]
===
match
---
trailer [76966,76974]
trailer [77018,77026]
===
match
---
import_from [35280,35320]
import_from [35280,35320]
===
match
---
operator: } [65954,65955]
operator: } [66006,66007]
===
match
---
name: params [60088,60094]
name: params [60140,60146]
===
match
---
name: e [67588,67589]
name: e [67640,67641]
===
match
---
string: 'execution_date' [64647,64663]
string: 'execution_date' [64699,64715]
===
match
---
trailer [80533,80537]
trailer [80585,80589]
===
match
---
arglist [76476,76673]
arglist [76528,76725]
===
match
---
name: ignore_ti_state [54068,54083]
name: ignore_ti_state [54120,54135]
===
match
---
atom_expr [56899,56954]
atom_expr [56951,57006]
===
match
---
atom_expr [11144,11155]
atom_expr [11144,11155]
===
match
---
name: dag [14521,14524]
name: dag [14521,14524]
===
match
---
name: conf [62415,62419]
name: conf [62467,62471]
===
match
---
name: test_mode [56364,56373]
name: test_mode [56416,56425]
===
match
---
operator: == [77751,77753]
operator: == [77803,77805]
===
match
---
operator: = [60242,60243]
operator: = [60294,60295]
===
match
---
name: ti [5413,5415]
name: ti [5413,5415]
===
match
---
suite [57834,58111]
suite [57886,58163]
===
match
---
name: logging [3208,3215]
name: logging [3208,3215]
===
match
---
trailer [28557,28573]
trailer [28557,28573]
===
match
---
name: self [43139,43143]
name: self [43191,43195]
===
match
---
trailer [68541,68568]
trailer [68593,68620]
===
match
---
operator: = [27871,27872]
operator: = [27871,27872]
===
match
---
name: context [53025,53032]
name: context [53077,53084]
===
match
---
trailer [52319,52342]
trailer [52371,52394]
===
match
---
number: 1 [40614,40615]
number: 1 [40614,40615]
===
match
---
atom_expr [77626,77645]
atom_expr [77678,77697]
===
match
---
parameters [80761,80767]
parameters [80813,80819]
===
match
---
operator: = [63974,63975]
operator: = [64026,64027]
===
match
---
suite [34827,35054]
suite [34827,35054]
===
match
---
name: Integer [9926,9933]
name: Integer [9926,9933]
===
match
---
dotted_name [2910,2938]
dotted_name [2910,2938]
===
match
---
name: session [46243,46250]
name: session [46295,46302]
===
match
---
name: self [40804,40808]
name: self [42764,42768]
===
match
---
name: execution_date [29624,29638]
name: execution_date [29624,29638]
===
match
---
suite [18126,18177]
suite [18126,18177]
===
match
---
trailer [8694,8701]
trailer [8694,8701]
===
match
---
operator: = [15338,15339]
operator: = [15338,15339]
===
match
---
atom_expr [10738,10784]
atom_expr [10738,10784]
===
match
---
trailer [48225,48247]
trailer [48277,48299]
===
match
---
name: self [80885,80889]
name: self [80937,80941]
===
match
---
atom [69753,70097]
atom [69805,70149]
===
match
---
trailer [53718,53723]
trailer [53770,53775]
===
match
---
simple_stmt [49548,49590]
simple_stmt [49600,49642]
===
match
---
name: set_error_file [56761,56775]
name: set_error_file [56813,56827]
===
match
---
operator: = [38508,38509]
operator: = [38508,38509]
===
match
---
operator: = [12323,12324]
operator: = [12323,12324]
===
match
---
operator: ** [71198,71200]
operator: ** [71250,71252]
===
match
---
atom_expr [43796,43833]
atom_expr [43848,43885]
===
match
---
simple_stmt [21509,21723]
simple_stmt [21509,21723]
===
match
---
name: execution_date [61181,61195]
name: execution_date [61233,61247]
===
match
---
name: self [52547,52551]
name: self [52599,52603]
===
match
---
operator: , [37483,37484]
operator: , [37483,37484]
===
match
---
trailer [43578,43582]
trailer [43630,43634]
===
match
---
trailer [7585,7593]
trailer [7585,7593]
===
match
---
operator: = [80370,80371]
operator: = [80422,80423]
===
match
---
name: context [49140,49147]
name: context [49192,49199]
===
match
---
name: jinja_context [72104,72117]
name: jinja_context [72156,72169]
===
match
---
atom_expr [55685,55695]
atom_expr [55737,55747]
===
match
---
atom_expr [55907,55923]
atom_expr [55959,55975]
===
match
---
name: task_id [8463,8470]
name: task_id [8463,8470]
===
match
---
operator: , [76559,76560]
operator: , [76611,76612]
===
match
---
atom_expr [21830,21841]
atom_expr [21830,21841]
===
match
---
simple_stmt [13148,13176]
simple_stmt [13148,13176]
===
match
---
operator: = [10052,10053]
operator: = [10052,10053]
===
match
---
decorator [80907,80917]
decorator [80959,80969]
===
match
---
atom_expr [23425,23439]
atom_expr [23425,23439]
===
match
---
atom_expr [65922,65940]
atom_expr [65974,65992]
===
match
---
atom_expr [55430,55439]
atom_expr [55482,55491]
===
match
---
atom_expr [34725,34750]
atom_expr [34725,34750]
===
match
---
trailer [6567,7139]
trailer [6567,7139]
===
match
---
parameters [63778,63784]
parameters [63830,63836]
===
match
---
name: task_copy [51768,51777]
name: task_copy [51820,51829]
===
match
---
argument [74379,74394]
argument [74431,74446]
===
match
---
name: execution_date [74351,74365]
name: execution_date [74403,74417]
===
match
---
funcdef [53334,54799]
funcdef [53386,54851]
===
match
---
trailer [6697,6712]
trailer [6697,6712]
===
match
---
parameters [8100,8106]
parameters [8100,8106]
===
match
---
simple_stmt [72988,73009]
simple_stmt [73040,73061]
===
match
---
name: queue [23207,23212]
name: queue [23207,23212]
===
match
---
name: try_number [8505,8515]
name: try_number [8505,8515]
===
match
---
name: task [26335,26339]
name: task [26335,26339]
===
match
---
expr_stmt [46841,46866]
expr_stmt [46893,46918]
===
match
---
simple_stmt [21825,21842]
simple_stmt [21825,21842]
===
match
---
operator: = [49114,49115]
operator: = [49166,49167]
===
match
---
name: start_date [24763,24773]
name: start_date [24763,24773]
===
match
---
atom_expr [71072,71097]
atom_expr [71124,71149]
===
match
---
operator: , [33999,34000]
operator: , [33999,34000]
===
match
---
name: query [7580,7585]
name: query [7580,7585]
===
match
---
operator: , [15107,15108]
operator: , [15107,15108]
===
match
---
if_stmt [62412,62557]
if_stmt [62464,62609]
===
match
---
atom_expr [67255,67304]
atom_expr [67307,67356]
===
match
---
trailer [11758,11767]
trailer [11758,11767]
===
match
---
string: 'try_number' [9768,9780]
string: 'try_number' [9768,9780]
===
match
---
funcdef [4634,7904]
funcdef [4634,7904]
===
match
---
fstring_end: ' [48761,48762]
fstring_end: ' [48813,48814]
===
match
---
name: default_var [63276,63287]
name: default_var [63328,63339]
===
match
---
name: TaskInstance [20298,20310]
name: TaskInstance [20298,20310]
===
match
---
simple_stmt [51164,51236]
simple_stmt [51216,51288]
===
match
---
operator: , [76531,76532]
operator: , [76583,76584]
===
match
---
trailer [45474,45478]
trailer [45526,45530]
===
match
---
name: include_prior_dates [76624,76643]
name: include_prior_dates [76676,76695]
===
match
---
trailer [23238,23243]
trailer [23238,23243]
===
match
---
argument [14990,15015]
argument [14990,15015]
===
match
---
trailer [60778,60790]
trailer [60830,60842]
===
match
---
argument [27235,27273]
argument [27235,27273]
===
match
---
string: """Get failed Dependencies""" [32346,32375]
string: """Get failed Dependencies""" [32346,32375]
===
match
---
trailer [72933,72944]
trailer [72985,72996]
===
match
---
atom_expr [24895,24908]
atom_expr [24895,24908]
===
match
---
operator: , [64543,64544]
operator: , [64595,64596]
===
match
---
operator: = [57858,57859]
operator: = [57910,57911]
===
match
---
name: ti [22375,22377]
name: ti [22375,22377]
===
match
---
name: sanitize_for_serialization [69095,69121]
name: sanitize_for_serialization [69147,69173]
===
match
---
arglist [11729,11767]
arglist [11729,11767]
===
match
---
name: bool [56128,56132]
name: bool [56180,56184]
===
match
---
decorated [20938,22851]
decorated [20938,22851]
===
match
---
trailer [62880,62884]
trailer [62932,62936]
===
match
---
operator: = [38175,38176]
operator: = [38175,38176]
===
match
---
trailer [22571,22577]
trailer [22571,22577]
===
match
---
operator: = [44852,44853]
operator: = [44904,44905]
===
match
---
atom_expr [19669,19680]
atom_expr [19669,19680]
===
match
---
operator: , [10728,10729]
operator: , [10728,10729]
===
match
---
name: self [42727,42731]
name: self [42696,42700]
===
match
---
atom_expr [23263,23272]
atom_expr [23263,23272]
===
match
---
simple_stmt [41544,41554]
simple_stmt [41513,41523]
===
match
---
operator: = [21935,21936]
operator: = [21935,21936]
===
match
---
name: ignore_ti_state [39741,39756]
name: ignore_ti_state [39741,39756]
===
match
---
name: task [62311,62315]
name: task [62363,62367]
===
match
---
operator: @ [35547,35548]
operator: @ [35547,35548]
===
match
---
funcdef [29062,29640]
funcdef [29062,29640]
===
match
---
name: get_hostname [2577,2589]
name: get_hostname [2577,2589]
===
match
---
atom_expr [77057,77069]
atom_expr [77109,77121]
===
match
---
operator: = [62114,62115]
operator: = [62166,62167]
===
match
---
simple_stmt [59454,59517]
simple_stmt [59506,59569]
===
match
---
operator: , [56950,56951]
operator: , [57002,57003]
===
match
---
name: try_number [81006,81016]
name: try_number [81058,81068]
===
match
---
operator: { [19044,19045]
operator: { [19044,19045]
===
match
---
trailer [71460,71481]
trailer [71512,71533]
===
match
---
name: renderedtifields [48149,48165]
name: renderedtifields [48201,48217]
===
match
---
name: yesterday_ds [62183,62195]
name: yesterday_ds [62235,62247]
===
match
---
name: max_tries [70937,70946]
name: max_tries [70989,70998]
===
match
---
simple_stmt [35532,35542]
simple_stmt [35532,35542]
===
match
---
operator: == [37747,37749]
operator: == [37747,37749]
===
match
---
name: TaskInstance [27206,27218]
name: TaskInstance [27206,27218]
===
match
---
atom_expr [48715,48731]
atom_expr [48767,48783]
===
match
---
trailer [45213,45220]
trailer [45265,45272]
===
match
---
import_from [1103,1133]
import_from [1103,1133]
===
match
---
name: ti [80138,80140]
name: ti [80190,80192]
===
match
---
trailer [11909,11925]
trailer [11909,11925]
===
match
---
expr_stmt [7552,7797]
expr_stmt [7552,7797]
===
match
---
if_stmt [56313,56374]
if_stmt [56365,56426]
===
match
---
name: DagRun [7586,7592]
name: DagRun [7586,7592]
===
match
---
simple_stmt [9652,9683]
simple_stmt [9652,9683]
===
match
---
name: self [52594,52598]
name: self [52646,52650]
===
match
---
trailer [22489,22494]
trailer [22489,22494]
===
match
---
suite [61141,61250]
suite [61193,61302]
===
match
---
name: TemplateAssertionError [66618,66640]
name: TemplateAssertionError [66670,66692]
===
match
---
operator: = [60024,60025]
operator: = [60076,60077]
===
match
---
atom [18311,18336]
atom [18311,18336]
===
match
---
tfpdef [15917,15938]
tfpdef [15917,15938]
===
match
---
string: "Clearing XCom data" [23808,23828]
string: "Clearing XCom data" [23808,23828]
===
match
---
atom_expr [23486,23506]
atom_expr [23486,23506]
===
match
---
name: self [77427,77431]
name: self [77479,77483]
===
match
---
simple_stmt [45409,45429]
simple_stmt [45461,45481]
===
match
---
atom_expr [29780,29797]
atom_expr [29780,29797]
===
match
---
import_from [2657,2699]
import_from [2657,2699]
===
match
---
parameters [68205,68211]
parameters [68257,68263]
===
match
---
trailer [40504,40508]
trailer [40504,40508]
===
match
---
atom_expr [79308,79317]
atom_expr [79360,79369]
===
match
---
trailer [59465,59470]
trailer [59517,59522]
===
match
---
and_test [14606,14664]
and_test [14606,14664]
===
match
---
name: self [20902,20906]
name: self [20902,20906]
===
match
---
trailer [3153,3163]
trailer [3153,3163]
===
match
---
and_test [14728,14770]
and_test [14728,14770]
===
match
---
name: info [40634,40638]
name: info [40634,40638]
===
match
---
atom_expr [56408,56436]
atom_expr [56460,56488]
===
match
---
fstring_expr [44964,44976]
fstring_expr [45016,45028]
===
match
---
suite [71855,72119]
suite [71907,72171]
===
match
---
trailer [82312,82314]
trailer [82364,82366]
===
match
---
not_test [58908,58921]
not_test [58960,58973]
===
match
---
name: fmt [59674,59677]
name: fmt [59726,59729]
===
match
---
trailer [80523,80528]
trailer [80575,80580]
===
match
---
name: task_id [45239,45246]
name: task_id [45291,45298]
===
match
---
atom_expr [74529,74564]
atom_expr [74581,74616]
===
match
---
expr_stmt [11178,11205]
expr_stmt [11178,11205]
===
match
---
simple_stmt [71322,71413]
simple_stmt [71374,71465]
===
match
---
name: uselist [10978,10985]
name: uselist [10978,10985]
===
match
---
decorated [81537,82376]
decorated [81589,82428]
===
match
---
string: "worker-config" [68842,68857]
string: "worker-config" [68894,68909]
===
match
---
operator: @ [81306,81307]
operator: @ [81358,81359]
===
match
---
operator: , [17958,17959]
operator: , [17958,17959]
===
match
---
simple_stmt [50599,50661]
simple_stmt [50651,50713]
===
match
---
fstring_end: ' [50652,50653]
fstring_end: ' [50704,50705]
===
match
---
atom_expr [57152,57167]
atom_expr [57204,57219]
===
match
---
operator: = [70931,70932]
operator: = [70983,70984]
===
match
---
trailer [48379,48385]
trailer [48431,48437]
===
match
---
trailer [53129,53147]
trailer [53181,53199]
===
match
---
expr_stmt [26755,26774]
expr_stmt [26755,26774]
===
match
---
operator: { [44949,44950]
operator: { [45001,45002]
===
match
---
atom_expr [20482,20493]
atom_expr [20482,20493]
===
match
---
name: external_executor_id [10311,10331]
name: external_executor_id [10311,10331]
===
match
---
param [63779,63783]
param [63831,63835]
===
match
---
name: execution_date [74140,74154]
name: execution_date [74192,74206]
===
match
---
name: String [9428,9434]
name: String [9428,9434]
===
match
---
arglist [40016,40242]
arglist [40016,40242]
===
match
---
operator: , [32754,32755]
operator: , [32754,32755]
===
match
---
name: task [37479,37483]
name: task [37479,37483]
===
match
---
name: state [29709,29714]
name: state [29709,29714]
===
match
---
simple_stmt [59823,59847]
simple_stmt [59875,59899]
===
match
---
trailer [9891,9905]
trailer [9891,9905]
===
match
---
trailer [80641,80649]
trailer [80693,80701]
===
match
---
operator: -> [80940,80942]
operator: -> [80992,80994]
===
match
---
name: append [3507,3513]
name: append [3507,3513]
===
match
---
trailer [79591,79613]
trailer [79643,79665]
===
match
---
name: test_mode [55230,55239]
name: test_mode [55282,55291]
===
match
---
operator: , [10553,10554]
operator: , [10553,10554]
===
match
---
name: execution_date [61413,61427]
name: execution_date [61465,61479]
===
match
---
trailer [44216,44232]
trailer [44268,44284]
===
match
---
atom_expr [12025,12034]
atom_expr [12025,12034]
===
match
---
trailer [22479,22484]
trailer [22479,22484]
===
match
---
trailer [80972,80982]
trailer [81024,81034]
===
match
---
dictorsetmaker [64502,66054]
dictorsetmaker [64554,66106]
===
match
---
operator: = [10022,10023]
operator: = [10022,10023]
===
match
---
atom_expr [48829,48922]
atom_expr [48881,48974]
===
match
---
operator: , [53548,53549]
operator: , [53600,53601]
===
match
---
fstring_end: " [62337,62338]
fstring_end: " [62389,62390]
===
match
---
trailer [18689,18696]
trailer [18689,18696]
===
match
---
expr_stmt [26803,26840]
expr_stmt [26803,26840]
===
match
---
name: bool [15593,15597]
name: bool [15593,15597]
===
match
---
name: FileSystemLoader [71055,71071]
name: FileSystemLoader [71107,71123]
===
match
---
trailer [18765,18791]
trailer [18765,18791]
===
match
---
atom_expr [55285,55302]
atom_expr [55337,55354]
===
match
---
operator: ** [71396,71398]
operator: ** [71448,71450]
===
match
---
name: delay [33248,33253]
name: delay [33248,33253]
===
match
---
name: state [57852,57857]
name: state [57904,57909]
===
match
---
try_stmt [51379,51620]
try_stmt [51431,51672]
===
match
---
param [63864,63869]
param [63916,63921]
===
match
---
atom_expr [6027,6044]
atom_expr [6027,6044]
===
match
---
name: task_id [26101,26108]
name: task_id [26101,26108]
===
match
---
parameters [71840,71854]
parameters [71892,71906]
===
match
---
trailer [33007,33013]
trailer [33007,33013]
===
match
---
atom_expr [22556,22566]
atom_expr [22556,22566]
===
match
---
string: 'ti_dag_date' [10585,10598]
string: 'ti_dag_date' [10585,10598]
===
match
---
import_as_names [1845,1873]
import_as_names [1845,1873]
===
match
---
expr_stmt [40325,40361]
expr_stmt [40325,40361]
===
match
---
simple_stmt [22919,23194]
simple_stmt [22919,23194]
===
match
---
simple_stmt [5191,5217]
simple_stmt [5191,5217]
===
match
---
parameters [4219,4266]
parameters [4219,4266]
===
match
---
atom [77547,77814]
atom [77599,77866]
===
match
---
operator: , [56086,56087]
operator: , [56138,56139]
===
match
---
name: ti [22613,22615]
name: ti [22613,22615]
===
match
---
name: render [72095,72101]
name: render [72147,72153]
===
match
---
trailer [42971,42992]
trailer [43023,43044]
===
match
---
operator: -> [80857,80859]
operator: -> [80909,80911]
===
match
---
comparison [78803,78848]
comparison [78855,78900]
===
match
---
atom_expr [44212,44234]
atom_expr [44264,44286]
===
match
---
trailer [21522,21528]
trailer [21522,21528]
===
match
---
suite [7468,7904]
suite [7468,7904]
===
match
---
name: html_content_err [71322,71338]
name: html_content_err [71374,71390]
===
match
---
name: self [14527,14531]
name: self [14527,14531]
===
match
---
name: default_subject [69523,69538]
name: default_subject [69575,69590]
===
match
---
name: dag_run [67767,67774]
name: dag_run [67819,67826]
===
match
---
name: Tuple [1090,1095]
name: Tuple [1090,1095]
===
match
---
trailer [20228,20417]
trailer [20228,20417]
===
match
---
trailer [45238,45246]
trailer [45290,45298]
===
match
---
name: merge [58943,58948]
name: merge [58995,59000]
===
match
---
name: str [24367,24370]
name: str [24367,24370]
===
match
---
import_from [2288,2364]
import_from [2288,2364]
===
match
---
atom_expr [5329,5350]
atom_expr [5329,5350]
===
match
---
atom_expr [74549,74562]
atom_expr [74601,74614]
===
match
---
operator: , [70797,70798]
operator: , [70849,70850]
===
match
---
operator: + [34112,34113]
operator: + [34112,34113]
===
match
---
name: Session [29163,29170]
name: Session [29163,29170]
===
match
---
trailer [25331,25333]
trailer [25331,25333]
===
match
---
operator: @ [80583,80584]
operator: @ [80635,80636]
===
match
---
name: next_ds_nodash [64832,64846]
name: next_ds_nodash [64884,64898]
===
match
---
comparison [52547,52573]
comparison [52599,52625]
===
match
---
name: ti [5164,5166]
name: ti [5164,5166]
===
match
---
arglist [63444,63473]
arglist [63496,63525]
===
match
---
operator: @ [55041,55042]
operator: @ [55093,55094]
===
match
---
tfpdef [15740,15761]
tfpdef [15740,15761]
===
match
---
name: log [43456,43459]
name: log [43508,43511]
===
match
---
trailer [32984,32999]
trailer [32984,32999]
===
match
---
name: os [3984,3986]
name: os [3984,3986]
===
match
---
operator: = [71047,71048]
operator: = [71099,71100]
===
match
---
atom_expr [26808,26840]
atom_expr [26808,26840]
===
match
---
name: contextlib [794,804]
name: contextlib [794,804]
===
match
---
name: default_html_content_err [72330,72354]
name: default_html_content_err [72382,72406]
===
match
---
fstring_string: / [19057,19058]
fstring_string: / [19057,19058]
===
match
---
trailer [7127,7129]
trailer [7127,7129]
===
match
---
name: drs [7816,7819]
name: drs [7816,7819]
===
match
---
name: Integer [10216,10223]
name: Integer [10216,10223]
===
match
---
name: last_dagrun [27714,27725]
name: last_dagrun [27714,27725]
===
match
---
operator: = [44308,44309]
operator: = [44360,44361]
===
match
---
annassign [7998,8003]
annassign [7998,8003]
===
match
---
name: info [40546,40550]
name: info [40546,40550]
===
match
---
name: execute [51665,51672]
name: execute [51717,51724]
===
match
---
string: "previous_start_date was called" [30043,30075]
string: "previous_start_date was called" [30043,30075]
===
match
---
operator: < [73940,73941]
operator: < [73992,73993]
===
match
---
operator: @ [24097,24098]
operator: @ [24097,24098]
===
match
---
atom_expr [26240,26253]
atom_expr [26240,26253]
===
match
---
operator: , [4403,4404]
operator: , [4403,4404]
===
match
---
simple_stmt [43227,43244]
simple_stmt [43279,43296]
===
match
---
except_clause [72686,72702]
except_clause [72738,72754]
===
match
---
atom_expr [21937,21950]
atom_expr [21937,21950]
===
match
---
name: self [48995,48999]
name: self [49047,49051]
===
match
---
operator: , [9441,9442]
operator: , [9441,9442]
===
match
---
atom_expr [55016,55035]
atom_expr [55068,55087]
===
match
---
import_from [82488,82528]
import_from [82540,82580]
===
match
---
name: try_number [5518,5528]
name: try_number [5518,5528]
===
match
---
arglist [57125,57182]
arglist [57177,57234]
===
match
---
name: dag_id [62301,62307]
name: dag_id [62353,62359]
===
match
---
trailer [27730,27760]
trailer [27730,27760]
===
match
---
simple_stmt [54278,54285]
simple_stmt [54330,54337]
===
match
---
import_from [2853,2894]
import_from [2853,2894]
===
match
---
name: self [24692,24696]
name: self [24692,24696]
===
match
---
operator: = [15833,15834]
operator: = [15833,15834]
===
match
---
operator: = [30121,30122]
operator: = [30121,30122]
===
match
---
operator: = [60429,60430]
operator: = [60481,60482]
===
match
---
trailer [53298,53307]
trailer [53350,53359]
===
match
---
decorator [81138,81148]
decorator [81190,81200]
===
match
---
file_input [787,82678]
file_input [787,82730]
===
match
---
funcdef [26387,28013]
funcdef [26387,28013]
===
match
---
name: log [22806,22809]
name: log [22806,22809]
===
match
---
trailer [7183,7189]
trailer [7183,7189]
===
match
---
simple_stmt [55879,55899]
simple_stmt [55931,55951]
===
match
---
operator: } [59962,59963]
operator: } [60014,60015]
===
match
---
trailer [9704,9711]
trailer [9704,9711]
===
match
---
name: TaskInstanceKey [8429,8444]
name: TaskInstanceKey [8429,8444]
===
match
---
arglist [37479,37503]
arglist [37479,37503]
===
match
---
operator: = [61378,61379]
operator: = [61430,61431]
===
match
---
operator: = [7160,7161]
operator: = [7160,7161]
===
match
---
name: data [4001,4005]
name: data [4001,4005]
===
match
---
operator: = [38562,38563]
operator: = [38562,38563]
===
match
---
simple_stmt [27199,27275]
simple_stmt [27199,27275]
===
match
---
name: current_time [24777,24789]
name: current_time [24777,24789]
===
match
---
name: max_tries [5892,5901]
name: max_tries [5892,5901]
===
match
---
expr_stmt [70993,71129]
expr_stmt [71045,71181]
===
match
---
number: 1 [55868,55869]
number: 1 [55920,55921]
===
match
---
trailer [3980,3996]
trailer [3980,3996]
===
match
---
atom_expr [72638,72653]
atom_expr [72690,72705]
===
match
---
name: first [77285,77290]
name: first [77337,77342]
===
match
---
name: last_dagrun [27895,27906]
name: last_dagrun [27895,27906]
===
match
---
name: self [55085,55089]
name: self [55137,55141]
===
match
---
name: bool [35845,35849]
name: bool [35845,35849]
===
match
---
name: debug [32586,32591]
name: debug [32586,32591]
===
match
---
name: State [44578,44583]
name: State [44630,44635]
===
match
---
name: prev_execution_date [61920,61939]
name: prev_execution_date [61972,61991]
===
match
---
number: 1 [37812,37813]
number: 1 [37812,37813]
===
match
---
name: min [34721,34724]
name: min [34721,34724]
===
match
---
operator: , [61626,61627]
operator: , [61678,61679]
===
match
---
name: self [20269,20273]
name: self [20269,20273]
===
match
---
name: execution_date [35453,35467]
name: execution_date [35453,35467]
===
match
---
name: self [49548,49552]
name: self [49600,49604]
===
match
---
argument [68622,68655]
argument [68674,68707]
===
match
---
operator: , [35964,35965]
operator: , [35964,35965]
===
match
---
arglist [56419,56435]
arglist [56471,56487]
===
match
---
atom_expr [12009,12022]
atom_expr [12009,12022]
===
match
---
name: session [27857,27864]
name: session [27857,27864]
===
match
---
operator: , [59265,59266]
operator: , [59317,59318]
===
match
---
name: self [39930,39934]
name: self [39930,39934]
===
match
---
simple_stmt [61590,61632]
simple_stmt [61642,61684]
===
match
---
atom_expr [6695,6712]
atom_expr [6695,6712]
===
match
---
arglist [69500,69512]
arglist [69552,69564]
===
match
---
atom_expr [25284,25302]
atom_expr [25284,25302]
===
match
---
name: and_ [79029,79033]
name: and_ [79081,79085]
===
match
---
operator: , [40578,40579]
operator: , [40578,40579]
===
match
---
name: commit [40930,40936]
name: commit [40899,40905]
===
match
---
trailer [48375,48379]
trailer [48427,48431]
===
match
---
operator: , [56786,56787]
operator: , [56838,56839]
===
match
---
name: self [19352,19356]
name: self [19352,19356]
===
match
---
name: commit [60521,60527]
name: commit [60573,60579]
===
match
---
argument [38555,38567]
argument [38555,38567]
===
match
---
arglist [74119,74154]
arglist [74171,74206]
===
match
---
simple_stmt [40325,40362]
simple_stmt [40325,40362]
===
match
---
fstring_expr [49290,49293]
fstring_expr [49342,49345]
===
match
---
name: force_fail [59267,59277]
name: force_fail [59319,59329]
===
match
---
operator: - [82425,82426]
operator: - [82477,82478]
===
match
---
name: log [1894,1897]
name: log [1894,1897]
===
match
---
arglist [77057,77081]
arglist [77109,77133]
===
match
---
string: "Refreshing TaskInstance %s from DB" [21456,21492]
string: "Refreshing TaskInstance %s from DB" [21456,21492]
===
match
---
name: self [53100,53104]
name: self [53152,53156]
===
match
---
name: session [27769,27776]
name: session [27769,27776]
===
match
---
if_stmt [12043,12084]
if_stmt [12043,12084]
===
match
---
name: iso [18902,18905]
name: iso [18902,18905]
===
match
---
name: TaskInstanceStateType [79562,79583]
name: TaskInstanceStateType [79614,79635]
===
match
---
name: OperationalError [47683,47699]
name: OperationalError [47735,47751]
===
match
---
trailer [41157,41161]
trailer [41126,41130]
===
match
---
name: self [37616,37620]
name: self [37616,37620]
===
match
---
atom_expr [62415,62471]
atom_expr [62467,62523]
===
match
---
name: verbose [53880,53887]
name: verbose [53932,53939]
===
match
---
name: close [54738,54743]
name: close [54790,54795]
===
match
---
simple_stmt [70714,70980]
simple_stmt [70766,71032]
===
match
---
trailer [62419,62430]
trailer [62471,62482]
===
match
---
name: Exception [58775,58784]
name: Exception [58827,58836]
===
match
---
suite [23612,24092]
suite [23612,24092]
===
match
---
suite [54298,54613]
suite [54350,54665]
===
match
---
name: getuser [12025,12032]
name: getuser [12025,12032]
===
match
---
simple_stmt [59916,59943]
simple_stmt [59968,59995]
===
match
---
atom_expr [21563,21582]
atom_expr [21563,21582]
===
match
---
expr_stmt [79792,79821]
expr_stmt [79844,79873]
===
match
---
expr_stmt [10152,10185]
expr_stmt [10152,10185]
===
match
---
argument [68825,68857]
argument [68877,68909]
===
match
---
atom_expr [50599,50660]
atom_expr [50651,50712]
===
match
---
name: pool [35974,35978]
name: pool [35974,35978]
===
match
---
operator: = [25970,25971]
operator: = [25970,25971]
===
match
---
name: self [71788,71792]
name: self [71840,71844]
===
match
---
name: State [7419,7424]
name: State [7419,7424]
===
match
---
name: Float [9705,9710]
name: Float [9705,9710]
===
match
---
name: dag_id [7992,7998]
name: dag_id [7992,7998]
===
match
---
name: get [19527,19530]
name: get [19527,19530]
===
match
---
name: DagRun [7631,7637]
name: DagRun [7631,7637]
===
match
---
operator: { [14699,14700]
operator: { [14699,14700]
===
match
---
expr_stmt [9806,9833]
expr_stmt [9806,9833]
===
match
---
return_stmt [64062,64082]
return_stmt [64114,64134]
===
match
---
name: conf [45779,45783]
name: conf [45831,45835]
===
match
---
name: TaskInstance [26216,26228]
name: TaskInstance [26216,26228]
===
match
---
name: models [1967,1973]
name: models [1967,1973]
===
match
---
operator: , [4667,4668]
operator: , [4667,4668]
===
match
---
name: self [19059,19063]
name: self [19059,19063]
===
match
---
name: jinja_context [70533,70546]
name: jinja_context [70585,70598]
===
match
---
name: t [78945,78946]
name: t [78997,78998]
===
match
---
name: self [24297,24301]
name: self [24297,24301]
===
match
---
name: session [7325,7332]
name: session [7325,7332]
===
match
---
trailer [61306,61324]
trailer [61358,61376]
===
match
---
simple_stmt [62602,62827]
simple_stmt [62654,62879]
===
match
---
trailer [44684,44721]
trailer [44736,44773]
===
match
---
param [72433,72438]
param [72485,72490]
===
match
---
try_stmt [52039,52266]
try_stmt [52091,52318]
===
match
---
string: """         Clears all XCom data from the database for the task instance          :param session: SQLAlchemy ORM Session         :type session: Session         """ [23621,23784]
string: """         Clears all XCom data from the database for the task instance          :param session: SQLAlchemy ORM Session         :type session: Session         """ [23621,23784]
===
match
---
suite [58698,58896]
suite [58750,58948]
===
match
---
if_stmt [40864,40914]
if_stmt [40833,40883]
===
match
---
atom_expr [54658,54668]
atom_expr [54710,54720]
===
match
---
return_stmt [19564,19791]
return_stmt [19564,19791]
===
match
---
name: log [73022,73025]
name: log [73074,73077]
===
match
---
simple_stmt [56263,56305]
simple_stmt [56315,56357]
===
match
---
trailer [64072,64082]
trailer [64124,64134]
===
match
---
name: warning [40286,40293]
name: warning [40286,40293]
===
match
---
operator: @ [8267,8268]
operator: @ [8267,8268]
===
match
---
name: self [63124,63128]
name: self [63176,63180]
===
match
---
trailer [7347,7354]
trailer [7347,7354]
===
match
---
operator: @ [23551,23552]
operator: @ [23551,23552]
===
match
---
atom_expr [13089,13102]
atom_expr [13089,13102]
===
match
---
expr_stmt [33248,33277]
expr_stmt [33248,33277]
===
match
---
name: self [46127,46131]
name: self [46179,46183]
===
match
---
operator: } [19319,19320]
operator: } [19319,19320]
===
match
---
name: Optional [28549,28557]
name: Optional [28549,28557]
===
match
---
operator: , [14917,14918]
operator: , [14917,14918]
===
match
---
return_stmt [14856,15410]
return_stmt [14856,15410]
===
match
---
trailer [30281,30301]
trailer [30281,30301]
===
match
---
if_stmt [38447,38645]
if_stmt [38447,38645]
===
match
---
name: cmd [18520,18523]
name: cmd [18520,18523]
===
match
---
atom_expr [10794,10820]
atom_expr [10794,10820]
===
match
---
name: state [20488,20493]
name: state [20488,20493]
===
match
---
name: try_number [71653,71663]
name: try_number [71705,71715]
===
match
---
name: DagRun [35446,35452]
name: DagRun [35446,35452]
===
match
---
name: self [33256,33260]
name: self [33256,33260]
===
match
---
name: scalar [77796,77802]
name: scalar [77848,77854]
===
match
---
comparison [47225,47261]
comparison [47277,47313]
===
match
---
name: self [32464,32468]
name: self [32464,32468]
===
match
---
operator: = [33254,33255]
operator: = [33254,33255]
===
match
---
atom_expr [29197,29214]
atom_expr [29197,29214]
===
match
---
decorator [19089,19099]
decorator [19089,19099]
===
match
---
simple_stmt [2750,2815]
simple_stmt [2750,2815]
===
match
---
name: str [26438,26441]
name: str [26438,26441]
===
match
---
operator: == [79071,79073]
operator: == [79123,79125]
===
match
---
trailer [79361,79369]
trailer [79413,79421]
===
match
---
name: items [7033,7038]
name: items [7033,7038]
===
match
---
trailer [45603,45638]
trailer [45655,45690]
===
match
---
atom_expr [18163,18174]
atom_expr [18163,18174]
===
match
---
operator: , [65103,65104]
operator: , [65155,65156]
===
match
---
param [26451,26474]
param [26451,26474]
===
match
---
atom_expr [7870,7883]
atom_expr [7870,7883]
===
match
---
operator: = [53455,53456]
operator: = [53507,53508]
===
match
---
expr_stmt [67372,67418]
expr_stmt [67424,67470]
===
match
---
name: Exception [44760,44769]
name: Exception [44812,44821]
===
match
---
name: _state [80078,80084]
name: _state [80130,80136]
===
match
---
suite [78714,78930]
suite [78766,78982]
===
match
---
name: result [51892,51898]
name: result [51944,51950]
===
match
---
name: ApiClient [2946,2955]
name: ApiClient [2946,2955]
===
match
---
name: dag_id [15464,15470]
name: dag_id [15464,15470]
===
match
---
name: task [46640,46644]
name: task [46692,46696]
===
match
---
name: end_date [55568,55576]
name: end_date [55620,55628]
===
match
---
simple_stmt [4604,4632]
simple_stmt [4604,4632]
===
match
---
name: on_kill [51588,51595]
name: on_kill [51640,51647]
===
match
---
name: job_id [35936,35942]
name: job_id [35936,35942]
===
match
---
name: self [55563,55567]
name: self [55615,55619]
===
match
---
atom_expr [77337,77365]
atom_expr [77389,77417]
===
match
---
operator: -> [81404,81406]
operator: -> [81456,81458]
===
match
---
name: self [21692,21696]
name: self [21692,21696]
===
match
---
parameters [77426,77441]
parameters [77478,77493]
===
match
---
expr_stmt [22003,22030]
expr_stmt [22003,22030]
===
match
---
string: "--ignore-dependencies" [18312,18335]
string: "--ignore-dependencies" [18312,18335]
===
match
---
atom_expr [77903,77911]
atom_expr [77955,77963]
===
match
---
argument [38497,38536]
argument [38497,38536]
===
match
---
dotted_name [2755,2779]
dotted_name [2755,2779]
===
match
---
name: task_id [68500,68507]
name: task_id [68552,68559]
===
match
---
trailer [24070,24091]
trailer [24070,24091]
===
match
---
name: key [74619,74622]
name: key [74671,74674]
===
match
---
operator: , [72328,72329]
operator: , [72380,72381]
===
match
---
operator: = [68386,68387]
operator: = [68438,68439]
===
match
---
name: execution_date [78685,78699]
name: execution_date [78737,78751]
===
match
---
name: State [34984,34989]
name: State [34984,34989]
===
match
---
param [67667,67672]
param [67719,67724]
===
match
---
expr_stmt [43535,43561]
expr_stmt [43587,43613]
===
match
---
trailer [10140,10146]
trailer [10140,10146]
===
match
---
simple_stmt [14784,14809]
simple_stmt [14784,14809]
===
match
---
name: Optional [81249,81257]
name: Optional [81301,81309]
===
match
---
string: "Failed when executing execute callback" [52224,52264]
string: "Failed when executing execute callback" [52276,52316]
===
match
---
decorated [73079,74406]
decorated [73131,74458]
===
match
---
name: delay [34752,34757]
name: delay [34752,34757]
===
match
---
suite [3920,4199]
suite [3920,4199]
===
match
---
simple_stmt [62876,62892]
simple_stmt [62928,62944]
===
match
---
trailer [8462,8470]
trailer [8462,8470]
===
match
---
if_stmt [42920,43072]
if_stmt [42972,43124]
===
match
---
parameters [13309,13315]
parameters [13309,13315]
===
match
---
operator: , [66640,66641]
operator: , [66692,66693]
===
match
---
atom_expr [23960,23979]
atom_expr [23960,23979]
===
match
---
name: __getattr__ [62909,62920]
name: __getattr__ [62961,62972]
===
match
---
name: rendered_k8s_spec [67372,67389]
name: rendered_k8s_spec [67424,67441]
===
match
---
atom_expr [57847,57857]
atom_expr [57899,57909]
===
match
---
name: dag_id [23883,23889]
name: dag_id [23883,23889]
===
match
---
simple_stmt [72896,72962]
simple_stmt [72948,73014]
===
match
---
atom_expr [73942,73961]
atom_expr [73994,74013]
===
match
---
name: ID_LEN [10348,10354]
name: ID_LEN [10348,10354]
===
match
---
simple_stmt [72279,72356]
simple_stmt [72331,72408]
===
match
---
name: bool [53496,53500]
name: bool [53548,53552]
===
match
---
name: self [61176,61180]
name: self [61228,61232]
===
match
---
dotted_name [2552,2569]
dotted_name [2552,2569]
===
match
---
name: getattr [41441,41448]
name: getattr [41410,41417]
===
match
---
name: filter [20222,20228]
name: filter [20222,20228]
===
match
---
name: tis [79004,79007]
name: tis [79056,79059]
===
match
---
name: self [24879,24883]
name: self [24879,24883]
===
match
---
simple_stmt [23463,23507]
simple_stmt [23463,23507]
===
match
---
operator: != [3641,3643]
operator: != [3641,3643]
===
match
---
trailer [29724,29729]
trailer [29724,29729]
===
match
---
name: key [24115,24118]
name: key [24115,24118]
===
match
---
atom_expr [49273,49337]
atom_expr [49325,49389]
===
match
---
name: func [1340,1344]
name: func [1340,1344]
===
match
---
name: bool [35720,35724]
name: bool [35720,35724]
===
match
---
comparison [26040,26074]
comparison [26040,26074]
===
match
---
name: session [29154,29161]
name: session [29154,29161]
===
match
---
atom_expr [31726,31739]
atom_expr [31726,31739]
===
match
---
param [79759,79764]
param [79811,79816]
===
match
---
atom_expr [33794,33949]
atom_expr [33794,33949]
===
match
---
trailer [48664,48680]
trailer [48716,48732]
===
match
---
operator: = [53616,53617]
operator: = [53668,53669]
===
match
---
atom_expr [21586,21597]
atom_expr [21586,21597]
===
match
---
atom_expr [79792,79804]
atom_expr [79844,79856]
===
match
---
simple_stmt [44247,44321]
simple_stmt [44299,44373]
===
match
---
name: staticmethod [15417,15429]
name: staticmethod [15417,15429]
===
match
---
name: session [24031,24038]
name: session [24031,24038]
===
match
---
name: airflow [1818,1825]
name: airflow [1818,1825]
===
match
---
simple_stmt [13241,13266]
simple_stmt [13241,13266]
===
match
---
name: jinja2 [1207,1213]
name: jinja2 [1207,1213]
===
match
---
name: self [8717,8721]
name: self [8717,8721]
===
match
---
trailer [22455,22462]
trailer [22455,22462]
===
match
---
name: self [51827,51831]
name: self [51879,51883]
===
match
---
name: Optional [29188,29196]
name: Optional [29188,29196]
===
match
---
name: start_date [72872,72882]
name: start_date [72924,72934]
===
match
---
fstring_start: f' [44923,44925]
fstring_start: f' [44975,44977]
===
match
---
operator: = [21513,21514]
operator: = [21513,21514]
===
match
---
atom_expr [19352,19363]
atom_expr [19352,19363]
===
match
---
comp_op [47097,47103]
comp_op [47149,47155]
===
match
---
name: self [13921,13925]
name: self [13921,13925]
===
match
---
name: Column [9421,9427]
name: Column [9421,9427]
===
match
---
simple_stmt [28063,28203]
simple_stmt [28063,28203]
===
match
---
name: rendered_k8s_spec [67320,67337]
name: rendered_k8s_spec [67372,67389]
===
match
---
trailer [48724,48731]
trailer [48776,48783]
===
match
---
atom_expr [13075,13085]
atom_expr [13075,13085]
===
match
---
simple_stmt [37616,37637]
simple_stmt [37616,37637]
===
match
---
name: task [58884,58888]
name: task [58936,58940]
===
match
---
name: execution_date [41215,41229]
name: execution_date [41184,41198]
===
match
---
operator: = [35850,35851]
operator: = [35850,35851]
===
match
---
trailer [21673,21688]
trailer [21673,21688]
===
match
---
name: int [81258,81261]
name: int [81310,81313]
===
match
---
expr_stmt [60638,60710]
expr_stmt [60690,60762]
===
match
---
atom_expr [6789,6848]
atom_expr [6789,6848]
===
match
---
trailer [13925,13937]
trailer [13925,13937]
===
match
---
name: warn [28740,28744]
name: warn [28740,28744]
===
match
---
suite [5110,6077]
suite [5110,6077]
===
match
---
suite [81105,81133]
suite [81157,81185]
===
match
---
name: delay [33616,33621]
name: delay [33616,33621]
===
match
---
operator: = [62000,62001]
operator: = [62052,62053]
===
match
---
comparison [78665,78699]
comparison [78717,78751]
===
match
---
string: 'start_date' [58556,58568]
string: 'start_date' [58608,58620]
===
match
---
name: error [48380,48385]
name: error [48432,48437]
===
match
---
name: State [26240,26245]
name: State [26240,26245]
===
match
---
param [13861,13865]
param [13861,13865]
===
match
---
trailer [45413,45426]
trailer [45465,45478]
===
match
---
trailer [33298,33324]
trailer [33298,33324]
===
match
---
trailer [60134,60141]
trailer [60186,60193]
===
match
---
trailer [27228,27233]
trailer [27228,27233]
===
match
---
name: State [5951,5956]
name: State [5951,5956]
===
match
---
trailer [50461,50481]
trailer [50513,50533]
===
match
---
name: downstream_task_ids [47114,47133]
name: downstream_task_ids [47166,47185]
===
match
---
name: test_mode [59256,59265]
name: test_mode [59308,59317]
===
match
---
atom_expr [54691,54716]
atom_expr [54743,54768]
===
match
---
param [23592,23597]
param [23592,23597]
===
match
---
simple_stmt [5870,5928]
simple_stmt [5870,5928]
===
match
---
name: DepContext [39495,39505]
name: DepContext [39495,39505]
===
match
---
name: file_path [15849,15858]
name: file_path [15849,15858]
===
match
---
name: SKIPPED [26246,26253]
name: SKIPPED [26246,26253]
===
match
---
string: """         Call callback defined for finished state change.          NOTE: Only invoke this function from caller of self._run_raw_task or         self.run         """ [52368,52535]
string: """         Call callback defined for finished state change.          NOTE: Only invoke this function from caller of self._run_raw_task or         self.run         """ [52420,52587]
===
match
---
name: TaskFail [1945,1953]
name: TaskFail [1945,1953]
===
match
---
name: dag_id [7090,7096]
name: dag_id [7090,7096]
===
match
---
name: info [49194,49198]
name: info [49246,49250]
===
match
---
atom_expr [22774,22784]
atom_expr [22774,22784]
===
match
---
atom_expr [50669,50695]
atom_expr [50721,50747]
===
match
---
operator: = [79849,79850]
operator: = [79901,79902]
===
match
---
trailer [74183,74187]
trailer [74235,74239]
===
match
---
dotted_name [3024,3056]
dotted_name [3024,3056]
===
match
---
arglist [18986,19014]
arglist [18986,19014]
===
match
---
operator: = [3590,3591]
operator: = [3590,3591]
===
match
---
trailer [77943,77949]
trailer [77995,78001]
===
match
---
name: do_xcom_push [51778,51790]
name: do_xcom_push [51830,51842]
===
match
---
operator: , [72167,72168]
operator: , [72219,72220]
===
match
---
suite [50188,50339]
suite [50240,50391]
===
match
---
name: self [40500,40504]
name: self [40500,40504]
===
match
---
expr_stmt [11803,11855]
expr_stmt [11803,11855]
===
match
---
atom_expr [18755,18791]
atom_expr [18755,18791]
===
match
---
factor [82425,82427]
factor [82477,82479]
===
match
---
atom_expr [76491,76510]
atom_expr [76543,76562]
===
match
---
param [4714,4723]
param [4714,4723]
===
match
---
name: dag_id [46132,46138]
name: dag_id [46184,46190]
===
match
---
operator: , [70946,70947]
operator: , [70998,70999]
===
match
---
atom_expr [78968,78977]
atom_expr [79020,79029]
===
match
---
name: _key [81444,81448]
name: _key [81496,81500]
===
match
---
arglist [9768,9800]
arglist [9768,9800]
===
match
---
atom_expr [22375,22386]
atom_expr [22375,22386]
===
match
---
parameters [32298,32336]
parameters [32298,32336]
===
match
---
atom_expr [48862,48921]
atom_expr [48914,48973]
===
match
---
trailer [44393,44409]
trailer [44445,44461]
===
match
---
operator: = [63011,63012]
operator: = [63063,63064]
===
match
---
trailer [23519,23528]
trailer [23519,23528]
===
match
---
name: execution_date [11869,11883]
name: execution_date [11869,11883]
===
match
---
string: 'previously_succeeded' [37788,37810]
string: 'previously_succeeded' [37788,37810]
===
match
---
name: timezone [11820,11828]
name: timezone [11820,11828]
===
match
---
name: dep_context [39817,39828]
name: dep_context [39817,39828]
===
match
---
operator: , [76643,76644]
operator: , [76695,76696]
===
match
---
comparison [21661,21711]
comparison [21661,21711]
===
match
---
name: _dag_id [80642,80649]
name: _dag_id [80694,80701]
===
match
---
name: queue [10046,10051]
name: queue [10046,10051]
===
match
---
trailer [61959,61980]
trailer [62011,62032]
===
match
---
operator: = [74681,74682]
operator: = [74733,74734]
===
match
---
atom_expr [8717,8736]
atom_expr [8717,8736]
===
match
---
operator: = [7842,7843]
operator: = [7842,7843]
===
match
---
trailer [58155,58168]
trailer [58207,58220]
===
match
---
trailer [57831,57833]
trailer [57883,57885]
===
match
---
simple_stmt [82022,82239]
simple_stmt [82074,82291]
===
match
---
trailer [31764,31770]
trailer [31764,31770]
===
match
---
operator: , [1243,1244]
operator: , [1243,1244]
===
match
---
name: Union [1097,1102]
name: Union [1097,1102]
===
match
---
name: result [59658,59664]
name: result [59710,59716]
===
match
---
trailer [79310,79317]
trailer [79362,79369]
===
match
---
atom_expr [5073,5089]
atom_expr [5073,5089]
===
match
---
trailer [9669,9682]
trailer [9669,9682]
===
match
---
name: _date_or_empty [43801,43815]
name: _date_or_empty [43853,43867]
===
match
---
operator: = [46250,46251]
operator: = [46302,46303]
===
match
---
name: self [29520,29524]
name: self [29520,29524]
===
match
---
trailer [14875,14892]
trailer [14875,14892]
===
match
---
operator: , [52302,52303]
operator: , [52354,52355]
===
match
---
atom_expr [80432,80453]
atom_expr [80484,80505]
===
match
---
expr_stmt [40804,40826]
expr_stmt [42764,42786]
===
match
---
trailer [82304,82306]
trailer [82356,82358]
===
match
---
atom_expr [80483,80494]
atom_expr [80535,80546]
===
match
---
simple_stmt [44028,44051]
simple_stmt [44080,44103]
===
match
---
trailer [5166,5173]
trailer [5166,5173]
===
match
---
name: var [63129,63132]
name: var [63181,63184]
===
match
---
name: context [49844,49851]
name: context [49896,49903]
===
match
---
name: Column [9946,9952]
name: Column [9946,9952]
===
match
---
atom_expr [32167,32224]
atom_expr [32167,32224]
===
match
---
operator: = [71616,71617]
operator: = [71668,71669]
===
match
---
name: _update_ti_state_for_sensing [50726,50754]
name: _update_ti_state_for_sensing [50778,50806]
===
match
---
name: dep_context [39829,39840]
name: dep_context [39829,39840]
===
match
---
operator: } [19056,19057]
operator: } [19056,19057]
===
match
---
suite [52929,53034]
suite [52981,53086]
===
match
---
name: self [34670,34674]
name: self [34670,34674]
===
match
---
name: filter [21543,21549]
name: filter [21543,21549]
===
match
---
trailer [68559,68567]
trailer [68611,68619]
===
match
---
simple_stmt [61644,61705]
simple_stmt [61696,61757]
===
match
---
operator: , [24696,24697]
operator: , [24696,24697]
===
match
---
param [53704,53731]
param [53756,53783]
===
match
---
name: dag_id [10689,10695]
name: dag_id [10689,10695]
===
match
---
atom_expr [46890,46941]
atom_expr [46942,46993]
===
match
---
operator: , [6821,6822]
operator: , [6821,6822]
===
match
---
name: timezone [56845,56853]
name: timezone [56897,56905]
===
match
---
funcdef [63831,64013]
funcdef [63883,64065]
===
match
---
atom_expr [81510,81531]
atom_expr [81562,81583]
===
match
---
atom_expr [71242,71309]
atom_expr [71294,71361]
===
match
---
name: self [33047,33051]
name: self [33047,33051]
===
match
---
import_from [48129,48199]
import_from [48181,48251]
===
match
---
atom_expr [56454,56502]
atom_expr [56506,56554]
===
match
---
trailer [61683,61704]
trailer [61735,61756]
===
match
---
name: task [47109,47113]
name: task [47161,47165]
===
match
---
name: VariableJsonAccessor [65873,65893]
name: VariableJsonAccessor [65925,65945]
===
match
---
name: STATICA_HACK [82449,82461]
name: STATICA_HACK [82501,82513]
===
match
---
if_stmt [41096,41333]
if_stmt [41065,41302]
===
match
---
atom_expr [74009,74155]
atom_expr [74061,74207]
===
match
---
funcdef [30321,30876]
funcdef [30321,30876]
===
match
---
trailer [77290,77292]
trailer [77342,77344]
===
match
---
funcdef [81082,81133]
funcdef [81134,81185]
===
match
---
name: from_string [72074,72085]
name: from_string [72126,72137]
===
match
---
expr_stmt [76441,76683]
expr_stmt [76493,76735]
===
match
---
simple_stmt [44389,44412]
simple_stmt [44441,44464]
===
match
---
string: "--pool" [18585,18593]
string: "--pool" [18585,18593]
===
match
---
name: datetime [958,966]
name: datetime [958,966]
===
match
---
atom_expr [35944,35957]
atom_expr [35944,35957]
===
match
---
operator: , [15644,15645]
operator: , [15644,15645]
===
match
---
name: String [9892,9898]
name: String [9892,9898]
===
match
---
trailer [49277,49282]
trailer [49329,49334]
===
match
---
expr_stmt [82398,82445]
expr_stmt [82450,82497]
===
match
---
name: filter_for_tis [77977,77991]
name: filter_for_tis [78029,78043]
===
match
---
name: ti_hash [34114,34121]
name: ti_hash [34114,34121]
===
match
---
name: exception [56463,56472]
name: exception [56515,56524]
===
match
---
atom_expr [52833,52846]
atom_expr [52885,52898]
===
match
---
name: the_log [19035,19042]
name: the_log [19035,19042]
===
match
---
atom_expr [26183,26202]
atom_expr [26183,26202]
===
match
---
atom_expr [65873,65895]
atom_expr [65925,65947]
===
match
---
trailer [22734,22738]
trailer [22734,22738]
===
match
---
name: pickle [864,870]
name: pickle [864,870]
===
match
---
atom_expr [5870,5882]
atom_expr [5870,5882]
===
match
---
operator: = [56134,56135]
operator: = [56186,56187]
===
match
---
trailer [81125,81132]
trailer [81177,81184]
===
match
---
name: os [854,856]
name: os [854,856]
===
match
---
name: dag_id [21591,21597]
name: dag_id [21591,21597]
===
match
---
name: xcom [77246,77250]
name: xcom [77298,77302]
===
match
---
operator: , [55545,55546]
operator: , [55597,55598]
===
match
---
name: params [67859,67865]
name: params [67911,67917]
===
match
---
string: """Return Number of running TIs from the DB""" [77451,77497]
string: """Return Number of running TIs from the DB""" [77503,77549]
===
match
---
operator: , [73127,73128]
operator: , [73179,73180]
===
match
---
string: "rendering of template_fields." [66999,67030]
string: "rendering of template_fields." [67051,67082]
===
match
---
suite [80243,80291]
suite [80295,80343]
===
match
---
name: task_copy [48734,48743]
name: task_copy [48786,48795]
===
match
---
fstring_start: f' [42853,42855]
fstring_start: f' [42905,42907]
===
match
---
trailer [41061,41069]
trailer [41030,41038]
===
match
---
name: ignore_depends_on_past [38346,38368]
name: ignore_depends_on_past [38346,38368]
===
match
---
name: job_id [42741,42747]
name: job_id [42710,42716]
===
match
---
number: 2 [28446,28447]
number: 2 [28446,28447]
===
match
---
operator: = [70833,70834]
operator: = [70885,70886]
===
match
---
operator: = [15723,15724]
operator: = [15723,15724]
===
match
---
atom_expr [4604,4631]
atom_expr [4604,4631]
===
match
---
if_stmt [13072,13140]
if_stmt [13072,13140]
===
match
---
trailer [60486,60498]
trailer [60538,60550]
===
match
---
name: int [33602,33605]
name: int [33602,33605]
===
match
---
operator: { [70549,70550]
operator: { [70601,70602]
===
match
---
atom [76942,77096]
atom [76994,77148]
===
match
---
simple_stmt [19025,19084]
simple_stmt [19025,19084]
===
match
---
name: get_previous_ti [28479,28494]
name: get_previous_ti [28479,28494]
===
match
---
name: dag_run [67755,67762]
name: dag_run [67807,67814]
===
match
---
atom_expr [80333,80354]
atom_expr [80385,80406]
===
match
---
operator: , [50653,50654]
operator: , [50705,50706]
===
match
---
atom_expr [22231,22246]
atom_expr [22231,22246]
===
match
---
name: airflow [2552,2559]
name: airflow [2552,2559]
===
match
---
name: Column [9698,9704]
name: Column [9698,9704]
===
match
---
simple_stmt [77192,77220]
simple_stmt [77244,77272]
===
match
---
if_stmt [80213,80291]
if_stmt [80265,80343]
===
match
---
suite [24144,24314]
suite [24144,24314]
===
match
---
simple_stmt [25875,25892]
simple_stmt [25875,25892]
===
match
---
param [34821,34825]
param [34821,34825]
===
match
---
name: context [3289,3296]
name: context [3289,3296]
===
match
---
atom_expr [82125,82145]
atom_expr [82177,82197]
===
match
---
string: """         Returns whether a task is in UP_FOR_RETRY state and its retry interval         has elapsed.         """ [25082,25197]
string: """         Returns whether a task is in UP_FOR_RETRY state and its retry interval         has elapsed.         """ [25082,25197]
===
match
---
operator: , [77069,77070]
operator: , [77121,77122]
===
match
---
trailer [79874,79890]
trailer [79926,79942]
===
match
---
name: task [52860,52864]
name: task [52912,52916]
===
match
---
trailer [60765,60768]
trailer [60817,60820]
===
match
---
string: 'ts' [65730,65734]
string: 'ts' [65782,65786]
===
match
---
atom_expr [79830,79843]
atom_expr [79882,79895]
===
match
---
import_as_names [1037,1102]
import_as_names [1037,1102]
===
match
---
string: '' [62018,62020]
string: '' [62070,62072]
===
match
---
name: self [33289,33293]
name: self [33289,33293]
===
match
---
argument [46732,46754]
argument [46784,46806]
===
match
---
import_name [857,870]
import_name [857,870]
===
match
---
name: KubeConfig [3004,3014]
name: KubeConfig [3004,3014]
===
match
---
atom_expr [22569,22577]
atom_expr [22569,22577]
===
match
---
import_from [1492,1545]
import_from [1492,1545]
===
match
---
param [15890,15908]
param [15890,15908]
===
match
---
simple_stmt [41869,42556]
simple_stmt [41838,42525]
===
match
---
simple_stmt [8025,8050]
simple_stmt [8025,8050]
===
match
---
operator: , [64597,64598]
operator: , [64649,64650]
===
match
---
atom_expr [7572,7787]
atom_expr [7572,7787]
===
match
---
expr_stmt [21764,21798]
expr_stmt [21764,21798]
===
match
---
trailer [26339,26359]
trailer [26339,26359]
===
match
---
suite [71427,72356]
suite [71479,72408]
===
match
---
operator: , [11045,11046]
operator: , [11045,11046]
===
match
---
funcdef [32898,33018]
funcdef [32898,33018]
===
match
---
simple_stmt [79646,79741]
simple_stmt [79698,79793]
===
match
---
fstring [19658,19682]
fstring [19658,19682]
===
match
---
name: state [11079,11084]
name: state [11079,11084]
===
match
---
name: lock_for_update [37586,37601]
name: lock_for_update [37586,37601]
===
match
---
tfpdef [56108,56133]
tfpdef [56160,56185]
===
match
---
atom_expr [21692,21711]
atom_expr [21692,21711]
===
match
---
operator: = [74227,74228]
operator: = [74279,74280]
===
match
---
tfpdef [29154,29170]
tfpdef [29154,29170]
===
match
---
name: State [30861,30866]
name: State [30861,30866]
===
match
---
comparison [35416,35444]
comparison [35416,35444]
===
match
---
if_stmt [57885,58059]
if_stmt [57937,58111]
===
match
---
operator: = [5469,5470]
operator: = [5469,5470]
===
match
---
operator: = [68461,68462]
operator: = [68513,68514]
===
match
---
for_stmt [32434,32893]
for_stmt [32434,32893]
===
match
---
arglist [61623,61630]
arglist [61675,61682]
===
match
---
trailer [49467,49479]
trailer [49519,49531]
===
match
---
suite [59814,66065]
suite [59866,66117]
===
match
---
operator: , [62265,62266]
operator: , [62317,62318]
===
match
---
operator: , [21597,21598]
operator: , [21597,21598]
===
match
---
name: dag_run [46890,46897]
name: dag_run [46942,46949]
===
match
---
suite [72807,73074]
suite [72859,73126]
===
match
---
name: State [55698,55703]
name: State [55750,55755]
===
match
---
trailer [76495,76510]
trailer [76547,76562]
===
match
---
string: 'var' [65840,65845]
string: 'var' [65892,65897]
===
match
---
import_name [1135,1146]
import_name [1135,1146]
===
match
---
name: self [80934,80938]
name: self [80986,80990]
===
match
---
atom_expr [46063,46221]
atom_expr [46115,46273]
===
match
---
decorator [53313,53330]
decorator [53365,53382]
===
match
---
name: dag_id [10962,10968]
name: dag_id [10962,10968]
===
match
---
trailer [62253,62261]
trailer [62305,62313]
===
match
---
operator: = [48891,48892]
operator: = [48943,48944]
===
match
---
suite [42907,43166]
suite [42959,43218]
===
match
---
name: self [53047,53051]
name: self [53099,53103]
===
match
---
name: params [67893,67899]
name: params [67945,67951]
===
match
---
expr_stmt [63928,63980]
expr_stmt [63980,64032]
===
match
---
param [8547,8552]
param [8547,8552]
===
match
---
name: has_option [71880,71890]
name: has_option [71932,71942]
===
match
---
name: task [26113,26117]
name: task [26113,26117]
===
match
---
name: try_number [6797,6807]
name: try_number [6797,6807]
===
match
---
operator: , [14109,14110]
operator: , [14109,14110]
===
match
---
operator: == [82204,82206]
operator: == [82256,82258]
===
match
---
name: last_dagrun [27931,27942]
name: last_dagrun [27931,27942]
===
match
---
suite [18853,19084]
suite [18853,19084]
===
match
---
name: state [24698,24703]
name: state [24698,24703]
===
match
---
atom_expr [18686,18721]
atom_expr [18686,18721]
===
match
---
string: 'execution_date' [45280,45296]
string: 'execution_date' [45332,45348]
===
match
---
atom_expr [20790,20845]
atom_expr [20790,20845]
===
match
---
trailer [33651,33662]
trailer [33651,33662]
===
match
---
trailer [59342,59355]
trailer [59394,59407]
===
match
---
atom_expr [26088,26138]
atom_expr [26088,26138]
===
match
---
name: SUCCESS [30867,30874]
name: SUCCESS [30867,30874]
===
match
---
name: add [40731,40734]
name: add [40731,40734]
===
match
---
trailer [58454,58462]
trailer [58506,58514]
===
match
---
fstring_start: f" [67524,67526]
fstring_start: f" [67576,67578]
===
match
---
expr_stmt [63802,63817]
expr_stmt [63854,63869]
===
match
---
simple_stmt [55932,56002]
simple_stmt [55984,56054]
===
match
---
trailer [47056,47065]
trailer [47108,47117]
===
match
---
comp_op [59626,59632]
comp_op [59678,59684]
===
match
---
name: try_number [59488,59498]
name: try_number [59540,59550]
===
match
---
testlist_comp [18079,18105]
testlist_comp [18079,18105]
===
match
---
name: _date_or_empty [41362,41376]
name: _date_or_empty [41331,41345]
===
match
---
funcdef [59361,59517]
funcdef [59413,59569]
===
match
---
name: Column [10235,10241]
name: Column [10235,10241]
===
match
---
name: str [81170,81173]
name: str [81222,81225]
===
match
---
name: Stats [48696,48701]
name: Stats [48748,48753]
===
match
---
name: RenderedTaskInstanceFields [48935,48961]
name: RenderedTaskInstanceFields [48987,49013]
===
match
---
trailer [24820,24829]
trailer [24820,24829]
===
match
---
trailer [64539,64543]
trailer [64591,64595]
===
match
---
simple_stmt [10229,10251]
simple_stmt [10229,10251]
===
match
---
atom_expr [43535,43545]
atom_expr [43587,43597]
===
match
---
trailer [20901,20907]
trailer [20901,20907]
===
match
---
atom_expr [38985,39000]
atom_expr [38985,39000]
===
match
---
atom [26239,26269]
atom [26239,26269]
===
match
---
name: self [26761,26765]
name: self [26761,26765]
===
match
---
simple_stmt [27288,27301]
simple_stmt [27288,27301]
===
match
---
operator: , [39544,39545]
operator: , [39544,39545]
===
match
---
name: hostname [42761,42769]
name: hostname [42730,42738]
===
match
---
simple_stmt [3665,3848]
simple_stmt [3665,3848]
===
match
---
operator: -> [59196,59198]
operator: -> [59248,59250]
===
match
---
operator: = [10094,10095]
operator: = [10094,10095]
===
match
---
name: dates [7027,7032]
name: dates [7027,7032]
===
match
---
operator: , [43778,43779]
operator: , [43830,43831]
===
match
---
expr_stmt [5191,5216]
expr_stmt [5191,5216]
===
match
---
string: 'Log file: {{ti.log_filepath}}<br>' [70375,70410]
string: 'Log file: {{ti.log_filepath}}<br>' [70427,70462]
===
match
---
atom_expr [34611,34654]
atom_expr [34611,34654]
===
match
---
name: state [12070,12075]
name: state [12070,12075]
===
match
---
atom_expr [80519,80528]
atom_expr [80571,80580]
===
match
---
name: log [3665,3668]
name: log [3665,3668]
===
match
---
simple_stmt [79929,79972]
simple_stmt [79981,80024]
===
match
---
atom_expr [79051,79070]
atom_expr [79103,79122]
===
match
---
simple_stmt [4072,4098]
simple_stmt [4072,4098]
===
match
---
expr_stmt [32384,32425]
expr_stmt [32384,32425]
===
match
---
param [35095,35100]
param [35095,35100]
===
match
---
name: self [47424,47428]
name: self [47476,47480]
===
match
---
trailer [60498,60500]
trailer [60550,60552]
===
match
---
name: Integer [10242,10249]
name: Integer [10242,10249]
===
match
---
trailer [71054,71071]
trailer [71106,71123]
===
match
---
name: func [77575,77579]
name: func [77627,77631]
===
match
---
simple_stmt [48209,48250]
simple_stmt [48261,48302]
===
match
---
name: models [82546,82552]
name: models [82598,82604]
===
match
---
name: ds_nodash [64624,64633]
name: ds_nodash [64676,64685]
===
match
---
arglist [58616,58643]
arglist [58668,58695]
===
match
---
name: dep_context [30933,30944]
name: dep_context [30933,30944]
===
match
---
name: next_ds_nodash [61590,61604]
name: next_ds_nodash [61642,61656]
===
match
---
simple_stmt [40277,40309]
simple_stmt [40277,40309]
===
match
---
expr_stmt [17909,17964]
expr_stmt [17909,17964]
===
match
---
operator: = [24724,24725]
operator: = [24724,24725]
===
match
---
name: self [67947,67951]
name: self [67999,68003]
===
match
---
string: """Write error into error file by path""" [4280,4321]
string: """Write error into error file by path""" [4280,4321]
===
match
---
name: DagRun [46077,46083]
name: DagRun [46129,46135]
===
match
---
name: configuration [1589,1602]
name: configuration [1589,1602]
===
match
---
simple_stmt [62376,62403]
simple_stmt [62428,62455]
===
match
---
expr_stmt [6551,7139]
expr_stmt [6551,7139]
===
match
---
arglist [47353,47375]
arglist [47405,47427]
===
match
---
suite [57014,57064]
suite [57066,57116]
===
match
---
simple_stmt [54311,54354]
simple_stmt [54363,54406]
===
match
---
atom_expr [26331,26360]
atom_expr [26331,26360]
===
match
---
trailer [20326,20334]
trailer [20326,20334]
===
match
---
trailer [6045,6060]
trailer [6045,6060]
===
match
---
atom_expr [42865,42876]
atom_expr [42917,42928]
===
match
---
atom_expr [22644,22657]
atom_expr [22644,22657]
===
match
---
suite [17989,18033]
suite [17989,18033]
===
match
---
name: self [12531,12535]
name: self [12531,12535]
===
match
---
parameters [33046,33052]
parameters [33046,33052]
===
match
---
name: next_try_number [13845,13860]
name: next_try_number [13845,13860]
===
match
---
classdef [79616,82376]
classdef [79668,82428]
===
match
---
operator: = [37498,37499]
operator: = [37498,37499]
===
match
---
operator: = [7417,7418]
operator: = [7417,7418]
===
match
---
name: info [31735,31739]
name: info [31735,31739]
===
match
---
atom [33646,33667]
atom [33646,33667]
===
match
---
trailer [52213,52223]
trailer [52265,52275]
===
match
---
trailer [48701,48707]
trailer [48753,48759]
===
match
---
arglist [9507,9531]
arglist [9507,9531]
===
match
---
name: state [29541,29546]
name: state [29541,29546]
===
match
---
name: self [23202,23206]
name: self [23202,23206]
===
match
---
trailer [82103,82111]
trailer [82155,82163]
===
match
---
name: dag [5321,5324]
name: dag [5321,5324]
===
match
---
simple_stmt [63997,64013]
simple_stmt [64049,64065]
===
match
---
trailer [72033,72038]
trailer [72085,72090]
===
match
---
operator: , [1296,1297]
operator: , [1296,1297]
===
match
---
operator: = [9604,9605]
operator: = [9604,9605]
===
match
---
suite [7940,8750]
suite [7940,8750]
===
match
---
with_item [71981,71996]
with_item [72033,72048]
===
match
---
name: dag_id [79064,79070]
name: dag_id [79116,79122]
===
match
---
operator: = [10985,10986]
operator: = [10985,10986]
===
match
---
param [24360,24371]
param [24360,24371]
===
match
---
operator: = [22785,22786]
operator: = [22785,22786]
===
match
---
atom_expr [66488,66497]
atom_expr [66540,66549]
===
match
---
name: log [47553,47556]
name: log [47605,47608]
===
match
---
decorator [20938,20955]
decorator [20938,20955]
===
match
---
string: 'task' [69444,69450]
string: 'task' [69496,69502]
===
match
---
name: utils [2456,2461]
name: utils [2456,2461]
===
match
---
operator: = [37436,37437]
operator: = [37436,37437]
===
match
---
trailer [55614,55630]
trailer [55666,55682]
===
match
---
name: self [77926,77930]
name: self [77978,77982]
===
match
---
atom_expr [71005,71129]
atom_expr [71057,71181]
===
match
---
name: first [78343,78348]
name: first [78395,78400]
===
match
---
trailer [80800,80816]
trailer [80852,80868]
===
match
---
name: task_id [20311,20318]
name: task_id [20311,20318]
===
match
---
decorator [58985,59002]
decorator [59037,59054]
===
match
---
param [55132,55148]
param [55184,55200]
===
match
---
string: """Return TI Context""" [59823,59846]
string: """Return TI Context""" [59875,59898]
===
match
---
atom_expr [11288,11321]
atom_expr [11288,11321]
===
match
---
atom_expr [65354,65403]
atom_expr [65406,65455]
===
match
---
parameters [52297,52350]
parameters [52349,52402]
===
match
---
atom_expr [54322,54353]
atom_expr [54374,54405]
===
match
---
import_from [2905,2955]
import_from [2905,2955]
===
match
---
name: TaskInstanceKey [79592,79607]
name: TaskInstanceKey [79644,79659]
===
match
---
trailer [59487,59498]
trailer [59539,59550]
===
match
---
simple_stmt [24713,24732]
simple_stmt [24713,24732]
===
match
---
name: session [30951,30958]
name: session [30951,30958]
===
match
---
name: min [34539,34542]
name: min [34539,34542]
===
match
---
simple_stmt [8600,8659]
simple_stmt [8600,8659]
===
match
---
name: self [43574,43578]
name: self [43626,43630]
===
match
---
name: partial_dag [47045,47056]
name: partial_dag [47097,47108]
===
match
---
atom_expr [60079,60094]
atom_expr [60131,60146]
===
match
---
name: overwrite_params_with_dag_run_conf [62490,62524]
name: overwrite_params_with_dag_run_conf [62542,62576]
===
match
---
atom_expr [41802,41815]
atom_expr [41771,41784]
===
match
---
tfpdef [35974,35993]
tfpdef [35974,35993]
===
match
---
name: pickle_id [18044,18053]
name: pickle_id [18044,18053]
===
match
---
operator: = [22054,22055]
operator: = [22054,22055]
===
match
---
string: 'TaskInstanceKey' [8573,8590]
string: 'TaskInstanceKey' [8573,8590]
===
match
---
trailer [58948,58954]
trailer [59000,59006]
===
match
---
name: self [44563,44567]
name: self [44615,44619]
===
match
---
trailer [61324,61345]
trailer [61376,61397]
===
match
---
decorated [26366,28013]
decorated [26366,28013]
===
match
---
name: task_tries [6905,6915]
name: task_tries [6905,6915]
===
match
---
simple_stmt [24056,24092]
simple_stmt [24056,24092]
===
match
---
name: task_copy [51488,51497]
name: task_copy [51540,51549]
===
match
---
tfpdef [62960,62969]
tfpdef [63012,63021]
===
match
---
atom_expr [13921,13937]
atom_expr [13921,13937]
===
match
---
name: session [53740,53747]
name: session [53792,53799]
===
match
---
simple_stmt [9874,9906]
simple_stmt [9874,9906]
===
match
---
operator: { [49286,49287]
operator: { [49338,49339]
===
match
---
expr_stmt [27288,27300]
expr_stmt [27288,27300]
===
match
---
trailer [47352,47376]
trailer [47404,47428]
===
match
---
operator: = [30136,30137]
operator: = [30136,30137]
===
match
---
name: dag_model [10833,10842]
name: dag_model [10833,10842]
===
match
---
name: session [77433,77440]
name: session [77485,77492]
===
match
---
name: airflow_context_vars [49093,49113]
name: airflow_context_vars [49145,49165]
===
match
---
name: Any [3159,3162]
name: Any [3159,3162]
===
match
---
trailer [26067,26074]
trailer [26067,26074]
===
match
---
expr_stmt [54904,54944]
expr_stmt [54956,54996]
===
match
---
simple_stmt [40922,40939]
simple_stmt [40891,40908]
===
match
---
trailer [77706,77714]
trailer [77758,77766]
===
match
---
name: mark_success [42927,42939]
name: mark_success [42979,42991]
===
match
---
trailer [44251,44266]
trailer [44303,44318]
===
match
---
operator: , [57150,57151]
operator: , [57202,57203]
===
match
---
simple_stmt [9939,9982]
simple_stmt [9939,9982]
===
match
---
string: 'ti' [65612,65616]
string: 'ti' [65664,65668]
===
match
---
operator: , [10784,10785]
operator: , [10784,10785]
===
match
---
suite [51458,51523]
suite [51510,51575]
===
match
---
suite [42940,43072]
suite [42992,43124]
===
match
---
name: reschedule_exception [43994,44014]
name: reschedule_exception [44046,44066]
===
match
---
atom_expr [72896,72909]
atom_expr [72948,72961]
===
match
---
param [22890,22908]
param [22890,22908]
===
match
---
name: qry [82285,82288]
name: qry [82337,82340]
===
match
---
operator: , [51142,51143]
operator: , [51194,51195]
===
match
---
simple_stmt [58286,58656]
simple_stmt [58338,58708]
===
match
---
atom_expr [5248,5257]
atom_expr [5248,5257]
===
match
---
trailer [7032,7038]
trailer [7032,7038]
===
match
---
name: subject [71142,71149]
name: subject [71194,71201]
===
match
---
name: os [18958,18960]
name: os [18958,18960]
===
match
---
atom_expr [68215,68229]
atom_expr [68267,68281]
===
match
---
string: 'Host: {{ti.hostname}}<br>' [70335,70362]
string: 'Host: {{ti.hostname}}<br>' [70387,70414]
===
match
---
operator: = [68880,68881]
operator: = [68932,68933]
===
match
---
trailer [51347,51365]
trailer [51399,51417]
===
match
---
name: ignore_ti_state [53558,53573]
name: ignore_ti_state [53610,53625]
===
match
---
simple_stmt [41046,41088]
simple_stmt [41015,41057]
===
match
---
name: self [68495,68499]
name: self [68547,68551]
===
match
---
operator: , [53991,53992]
operator: , [54043,54044]
===
match
---
funcdef [13204,13266]
funcdef [13204,13266]
===
match
---
name: end_date [80925,80933]
name: end_date [80977,80985]
===
match
---
param [77427,77432]
param [77479,77484]
===
match
---
simple_stmt [29510,29571]
simple_stmt [29510,29571]
===
match
---
trailer [20895,20901]
trailer [20895,20901]
===
match
---
name: PodGenerator [68768,68780]
name: PodGenerator [68820,68832]
===
match
---
name: self [13075,13079]
name: self [13075,13079]
===
match
---
operator: -> [81336,81338]
operator: -> [81388,81390]
===
match
---
fstring_string:  [ [33000,33002]
fstring_string:  [ [33000,33002]
===
match
---
operator: = [43150,43151]
operator: = [43202,43203]
===
match
---
trailer [56904,56909]
trailer [56956,56961]
===
match
---
fstring_end: " [49293,49294]
fstring_end: " [49345,49346]
===
match
---
operator: , [55630,55631]
operator: , [55682,55683]
===
match
---
for_stmt [7806,7904]
for_stmt [7806,7904]
===
match
---
name: Optional [41724,41732]
name: Optional [41693,41701]
===
match
---
simple_stmt [40537,40617]
simple_stmt [40537,40617]
===
match
---
annassign [8064,8069]
annassign [8064,8069]
===
match
---
simple_stmt [40662,40684]
simple_stmt [40662,40684]
===
match
---
lambdef [5065,5089]
lambdef [5065,5089]
===
match
---
arglist [79051,79216]
arglist [79103,79268]
===
match
---
comparison [79387,79435]
comparison [79439,79487]
===
match
---
operator: , [32003,32004]
operator: , [32003,32004]
===
match
---
operator: , [18995,18996]
operator: , [18995,18996]
===
match
---
import_from [2443,2489]
import_from [2443,2489]
===
match
---
funcdef [19818,20554]
funcdef [19818,20554]
===
match
---
fstring_start: f" [47855,47857]
fstring_start: f" [47907,47909]
===
match
---
simple_stmt [22801,22851]
simple_stmt [22801,22851]
===
match
---
parameters [19405,19411]
parameters [19405,19411]
===
match
---
name: task [56816,56820]
name: task [56868,56872]
===
match
---
exprlist [49299,49303]
exprlist [49351,49355]
===
match
---
name: self [25025,25029]
name: self [25025,25029]
===
match
---
param [32323,32335]
param [32323,32335]
===
match
---
string: "--ignore-depends-on-past" [18397,18423]
string: "--ignore-depends-on-past" [18397,18423]
===
match
---
operator: , [56098,56099]
operator: , [56150,56151]
===
match
---
simple_stmt [41434,41461]
simple_stmt [41403,41430]
===
match
---
tfpdef [26422,26442]
tfpdef [26422,26442]
===
match
---
name: UP_FOR_RETRY [53067,53079]
name: UP_FOR_RETRY [53119,53131]
===
match
---
operator: , [64633,64634]
operator: , [64685,64686]
===
match
---
operator: , [35663,35664]
operator: , [35663,35664]
===
match
---
name: self [68206,68210]
name: self [68258,68262]
===
match
---
atom_expr [60350,60369]
atom_expr [60402,60421]
===
match
---
name: SENSING [50866,50873]
name: SENSING [50918,50925]
===
match
---
parameters [81585,81628]
parameters [81637,81680]
===
match
---
param [81592,81605]
param [81644,81657]
===
match
---
trailer [33967,33977]
trailer [33967,33977]
===
match
---
argument [42702,42717]
argument [42671,42686]
===
match
---
atom_expr [59483,59498]
atom_expr [59535,59550]
===
match
---
name: refresh_from_task [37461,37478]
name: refresh_from_task [37461,37478]
===
match
---
name: pickle_id [15808,15817]
name: pickle_id [15808,15817]
===
match
---
name: refresh_from_task [42629,42646]
name: refresh_from_task [42598,42615]
===
match
---
classdef [8752,79487]
classdef [8752,79539]
===
match
---
name: refresh_from_task [22860,22877]
name: refresh_from_task [22860,22877]
===
match
---
trailer [39946,39961]
trailer [39946,39961]
===
match
---
parameters [12624,12630]
parameters [12624,12630]
===
match
---
trailer [11749,11754]
trailer [11749,11754]
===
match
---
trailer [30272,30281]
trailer [30272,30281]
===
match
---
atom_expr [21661,21688]
atom_expr [21661,21688]
===
match
---
name: task_id [79348,79355]
name: task_id [79400,79407]
===
match
---
trailer [39162,39168]
trailer [39162,39168]
===
match
---
simple_stmt [38113,38435]
simple_stmt [38113,38435]
===
match
---
name: Column [10166,10172]
name: Column [10166,10172]
===
match
---
name: datetime [942,950]
name: datetime [942,950]
===
match
---
name: namespace [68871,68880]
name: namespace [68923,68932]
===
match
---
parameters [80933,80939]
parameters [80985,80991]
===
match
---
name: execution_date [11957,11971]
name: execution_date [11957,11971]
===
match
---
operator: = [24614,24615]
operator: = [24614,24615]
===
match
---
trailer [7606,7613]
trailer [7606,7613]
===
match
---
name: int [33739,33742]
name: int [33739,33742]
===
match
---
and_test [78945,78994]
and_test [78997,79046]
===
match
---
name: execution_date [21697,21711]
name: execution_date [21697,21711]
===
match
---
name: models [2069,2075]
name: models [2069,2075]
===
match
---
name: execution_date [8722,8736]
name: execution_date [8722,8736]
===
match
---
atom_expr [77926,77949]
atom_expr [77978,78001]
===
match
---
not_test [40696,40709]
not_test [40696,40709]
===
match
---
expr_stmt [61527,61577]
expr_stmt [61579,61629]
===
match
---
trailer [34778,34787]
trailer [34778,34787]
===
match
---
string: 'end_date' [45378,45388]
string: 'end_date' [45430,45440]
===
match
---
name: str [80086,80089]
name: str [80138,80141]
===
match
---
name: _queue [80488,80494]
name: _queue [80540,80546]
===
match
---
operator: = [20165,20166]
operator: = [20165,20166]
===
match
---
atom_expr [9919,9934]
atom_expr [9919,9934]
===
match
---
atom_expr [5940,5948]
atom_expr [5940,5948]
===
match
---
name: job_id [54489,54495]
name: job_id [54541,54547]
===
match
---
name: date [68669,68673]
name: date [68721,68725]
===
match
---
simple_stmt [52101,52135]
simple_stmt [52153,52187]
===
match
---
atom_expr [57116,57183]
atom_expr [57168,57235]
===
match
---
comparison [53125,53159]
comparison [53177,53211]
===
match
---
arglist [9435,9459]
arglist [9435,9459]
===
match
---
simple_stmt [56804,56821]
simple_stmt [56856,56873]
===
match
---
argument [39523,39544]
argument [39523,39544]
===
match
---
atom_expr [24847,24865]
atom_expr [24847,24865]
===
match
---
trailer [72073,72085]
trailer [72125,72137]
===
match
---
atom_expr [80637,80649]
atom_expr [80689,80701]
===
match
---
simple_stmt [78087,78152]
simple_stmt [78139,78204]
===
match
---
name: execution_date [11692,11706]
name: execution_date [11692,11706]
===
match
---
operator: , [82111,82112]
operator: , [82163,82164]
===
match
---
operator: = [9883,9884]
operator: = [9883,9884]
===
match
---
atom_expr [41441,41460]
atom_expr [41410,41429]
===
match
---
atom_expr [15925,15938]
atom_expr [15925,15938]
===
match
---
return_stmt [32233,32244]
return_stmt [32233,32244]
===
match
---
trailer [62430,62471]
trailer [62482,62523]
===
match
---
name: PodGenerator [3064,3076]
name: PodGenerator [3064,3076]
===
match
---
operator: == [78831,78833]
operator: == [78883,78885]
===
match
---
trailer [62195,62203]
trailer [62247,62255]
===
match
---
name: Variable [63431,63439]
name: Variable [63483,63491]
===
match
---
param [26416,26421]
param [26416,26421]
===
match
---
name: FAILED [20873,20879]
name: FAILED [20873,20879]
===
match
---
operator: , [8119,8120]
operator: , [8119,8120]
===
match
---
atom_expr [22741,22747]
atom_expr [22741,22747]
===
match
---
trailer [9767,9801]
trailer [9767,9801]
===
match
---
operator: = [27295,27296]
operator: = [27295,27296]
===
match
---
name: dag_id [49000,49006]
name: dag_id [49052,49058]
===
match
---
name: Exception [59080,59089]
name: Exception [59132,59141]
===
match
---
expr_stmt [61154,61195]
expr_stmt [61206,61247]
===
match
---
name: in_ [7715,7718]
name: in_ [7715,7718]
===
match
---
trailer [64008,64012]
trailer [64060,64064]
===
match
---
trailer [33635,33637]
trailer [33635,33637]
===
match
---
name: in_ [26235,26238]
name: in_ [26235,26238]
===
match
---
import_as_names [2088,2109]
import_as_names [2088,2109]
===
match
---
trailer [10172,10185]
trailer [10172,10185]
===
match
---
name: Index [10633,10638]
name: Index [10633,10638]
===
match
---
atom [70134,70495]
atom [70186,70547]
===
match
---
trailer [71023,71129]
trailer [71075,71181]
===
match
---
name: tis [7464,7467]
name: tis [7464,7467]
===
match
---
trailer [54340,54353]
trailer [54392,54405]
===
match
---
name: provide_session [59703,59718]
name: provide_session [59755,59770]
===
match
---
operator: = [19462,19463]
operator: = [19462,19463]
===
match
---
operator: , [64447,64448]
operator: , [64499,64500]
===
match
---
atom_expr [82346,82357]
atom_expr [82398,82409]
===
match
---
suite [18617,18652]
suite [18617,18652]
===
match
---
operator: = [74565,74566]
operator: = [74617,74618]
===
match
---
expr_stmt [77246,77292]
expr_stmt [77298,77344]
===
match
---
name: duration [24942,24950]
name: duration [24942,24950]
===
match
---
trailer [30248,30259]
trailer [30248,30259]
===
match
---
name: error [53254,53259]
name: error [53306,53311]
===
match
---
operator: , [35778,35779]
operator: , [35778,35779]
===
match
---
operator: = [15900,15901]
operator: = [15900,15901]
===
match
---
trailer [10067,10072]
trailer [10067,10072]
===
match
---
trailer [40839,40848]
trailer [40808,40817]
===
match
---
operator: = [42569,42570]
operator: = [42538,42539]
===
match
---
simple_stmt [28987,29036]
simple_stmt [28987,29036]
===
match
---
name: self [62485,62489]
name: self [62537,62541]
===
match
---
simple_stmt [77903,77918]
simple_stmt [77955,77970]
===
match
---
expr_stmt [61208,61249]
expr_stmt [61260,61301]
===
match
---
operator: , [10704,10705]
operator: , [10704,10705]
===
match
---
trailer [61407,61428]
trailer [61459,61480]
===
match
---
suite [20507,20533]
suite [20507,20533]
===
match
---
name: self [63002,63006]
name: self [63054,63058]
===
match
---
simple_stmt [43535,43562]
simple_stmt [43587,43614]
===
match
---
name: queue [22561,22566]
name: queue [22561,22566]
===
match
---
name: tis [78317,78320]
name: tis [78369,78372]
===
match
---
trailer [67970,67979]
trailer [68022,68031]
===
match
---
name: on_failure_callback [52624,52643]
name: on_failure_callback [52676,52695]
===
match
---
trailer [41305,41310]
trailer [41274,41279]
===
match
---
name: post_execute [50545,50557]
name: post_execute [50597,50609]
===
match
---
string: 'Submitting %s to sensor service' [50798,50831]
string: 'Submitting %s to sensor service' [50850,50883]
===
match
---
name: test_mode [12388,12397]
name: test_mode [12388,12397]
===
match
---
name: path [14678,14682]
name: path [14678,14682]
===
match
---
name: task_id [21624,21631]
name: task_id [21624,21631]
===
match
---
name: var [63807,63810]
name: var [63859,63862]
===
match
---
name: extend [18759,18765]
name: extend [18759,18765]
===
match
---
argument [54341,54352]
argument [54393,54404]
===
match
---
trailer [71263,71285]
trailer [71315,71337]
===
match
---
expr_stmt [47402,47470]
expr_stmt [47454,47522]
===
match
---
atom_expr [31659,31671]
atom_expr [31659,31671]
===
match
---
name: pod_id [68521,68527]
name: pod_id [68573,68579]
===
match
---
except_clause [3077,3095]
except_clause [3077,3095]
===
match
---
name: rendered_task_instance_fields [66425,66454]
name: rendered_task_instance_fields [66477,66506]
===
match
---
if_stmt [55227,55260]
if_stmt [55279,55312]
===
match
---
trailer [12013,12022]
trailer [12013,12022]
===
match
---
string: 'end_date' [43922,43932]
string: 'end_date' [43974,43984]
===
match
---
name: XCOM_RETURN_KEY [74630,74645]
name: XCOM_RETURN_KEY [74682,74697]
===
match
---
simple_stmt [27170,27182]
simple_stmt [27170,27182]
===
match
---
atom_expr [14791,14808]
atom_expr [14791,14808]
===
match
---
operator: = [74715,74716]
operator: = [74767,74768]
===
match
---
funcdef [50722,51106]
funcdef [50774,51158]
===
match
---
testlist_comp [10533,10821]
testlist_comp [10533,10821]
===
match
---
annassign [80309,80324]
annassign [80361,80376]
===
match
---
trailer [51440,51454]
trailer [51492,51506]
===
match
---
trailer [71941,71955]
trailer [71993,72007]
===
match
---
suite [63911,64013]
suite [63963,64065]
===
match
---
operator: , [15535,15536]
operator: , [15535,15536]
===
match
---
operator: = [79901,79902]
operator: = [79953,79954]
===
match
---
operator: , [1078,1079]
operator: , [1078,1079]
===
match
---
trailer [30115,30145]
trailer [30115,30145]
===
match
---
operator: = [82344,82345]
operator: = [82396,82397]
===
match
---
operator: , [14077,14078]
operator: , [14077,14078]
===
match
---
decorated [25036,25334]
decorated [25036,25334]
===
match
---
testlist_comp [77134,77178]
testlist_comp [77186,77230]
===
match
---
name: self [38454,38458]
name: self [38454,38458]
===
match
---
atom_expr [20888,20907]
atom_expr [20888,20907]
===
match
---
argument [10356,10372]
argument [10356,10372]
===
match
---
if_stmt [53122,53308]
if_stmt [53174,53360]
===
match
---
name: xcom_push [73104,73113]
name: xcom_push [73156,73165]
===
match
---
trailer [31825,31867]
trailer [31825,31867]
===
match
---
atom_expr [79812,79821]
atom_expr [79864,79873]
===
match
---
atom_expr [30362,30389]
atom_expr [30362,30389]
===
match
---
name: AirflowException [48483,48499]
name: AirflowException [48535,48551]
===
match
---
simple_stmt [33062,33240]
simple_stmt [33062,33240]
===
match
---
trailer [38153,38434]
trailer [38153,38434]
===
match
---
name: and_ [1334,1338]
name: and_ [1334,1338]
===
match
---
name: self [63802,63806]
name: self [63854,63858]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28758,28909]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28758,28909]
===
match
---
if_stmt [39784,40460]
if_stmt [39784,40460]
===
match
---
operator: , [44840,44841]
operator: , [44892,44893]
===
match
---
trailer [58748,58755]
trailer [58800,58807]
===
match
---
decorator [25339,25356]
decorator [25339,25356]
===
match
---
trailer [45071,45400]
trailer [45123,45452]
===
match
---
trailer [77579,77585]
trailer [77631,77637]
===
match
---
name: self [37548,37552]
name: self [37548,37552]
===
match
---
name: dill [10299,10303]
name: dill [10299,10303]
===
match
---
import_name [1186,1201]
import_name [1186,1201]
===
match
---
param [15808,15840]
param [15808,15840]
===
match
---
trailer [72647,72653]
trailer [72699,72705]
===
match
---
param [81240,81244]
param [81292,81296]
===
match
---
simple_stmt [29808,30020]
simple_stmt [29808,30020]
===
match
---
expr_stmt [62030,62087]
expr_stmt [62082,62139]
===
match
---
trailer [55412,55645]
trailer [55464,55697]
===
match
---
atom_expr [51827,51876]
atom_expr [51879,51928]
===
match
---
name: on_failure_callback [52777,52796]
name: on_failure_callback [52829,52848]
===
match
---
simple_stmt [60112,60143]
simple_stmt [60164,60195]
===
match
---
name: Optional [1080,1088]
name: Optional [1080,1088]
===
match
---
name: are_dependents_done [25364,25383]
name: are_dependents_done [25364,25383]
===
match
---
trailer [74118,74155]
trailer [74170,74207]
===
match
---
name: task [56931,56935]
name: task [56983,56987]
===
match
---
simple_stmt [26290,26307]
simple_stmt [26290,26307]
===
match
---
name: fallback [45841,45849]
name: fallback [45893,45901]
===
match
---
tfpdef [53633,53648]
tfpdef [53685,53700]
===
match
---
dotted_name [2242,2269]
dotted_name [2242,2269]
===
match
---
simple_stmt [2905,2956]
simple_stmt [2905,2956]
===
match
---
operator: , [43833,43834]
operator: , [43885,43886]
===
match
---
expr_stmt [39481,39771]
expr_stmt [39481,39771]
===
match
---
not_test [39787,39872]
not_test [39787,39872]
===
match
---
name: self [14014,14018]
name: self [14014,14018]
===
match
---
operator: , [14018,14019]
operator: , [14018,14019]
===
match
---
name: strftime [41510,41518]
name: strftime [41479,41487]
===
match
---
operator: , [21711,21712]
operator: , [21711,21712]
===
match
---
dotted_name [2705,2726]
dotted_name [2705,2726]
===
match
---
fstring_expr [19668,19681]
fstring_expr [19668,19681]
===
match
---
name: task_id [6068,6075]
name: task_id [6068,6075]
===
match
---
atom_expr [77253,77292]
atom_expr [77305,77344]
===
match
---
trailer [59470,59478]
trailer [59522,59530]
===
match
---
trailer [44669,44684]
trailer [44721,44736]
===
match
---
name: kubernetes [68286,68296]
name: kubernetes [68338,68348]
===
match
---
string: "Executing %s on %s" [41279,41299]
string: "Executing %s on %s" [41248,41268]
===
match
---
operator: , [10766,10767]
operator: , [10766,10767]
===
match
---
name: session [45514,45521]
name: session [45566,45573]
===
match
---
import_from [3019,3076]
import_from [3019,3076]
===
match
---
simple_stmt [53231,53260]
simple_stmt [53283,53312]
===
match
---
operator: , [54234,54235]
operator: , [54286,54287]
===
match
---
simple_stmt [14521,14541]
simple_stmt [14521,14541]
===
match
---
operator: , [7011,7012]
operator: , [7011,7012]
===
match
---
trailer [41408,41420]
trailer [41377,41389]
===
match
---
trailer [66492,66497]
trailer [66544,66549]
===
match
---
number: 256 [10068,10071]
number: 256 [10068,10071]
===
match
---
tfpdef [56184,56209]
tfpdef [56236,56261]
===
match
---
atom_expr [46635,46664]
atom_expr [46687,46716]
===
match
---
import_from [2205,2236]
import_from [2205,2236]
===
match
---
atom_expr [21769,21798]
atom_expr [21769,21798]
===
match
---
name: ti [22569,22571]
name: ti [22569,22571]
===
match
---
simple_stmt [61990,62022]
simple_stmt [62042,62074]
===
match
---
name: dag_id [14911,14917]
name: dag_id [14911,14917]
===
match
---
trailer [67914,67919]
trailer [67966,67971]
===
match
---
tfpdef [15654,15682]
tfpdef [15654,15682]
===
match
---
name: _CURRENT_CONTEXT [3490,3506]
name: _CURRENT_CONTEXT [3490,3506]
===
match
---
name: str [73142,73145]
name: str [73194,73197]
===
match
---
operator: = [54914,54915]
operator: = [54966,54967]
===
match
---
simple_stmt [11803,11856]
simple_stmt [11803,11856]
===
match
---
parameters [24118,24124]
parameters [24118,24124]
===
match
---
trailer [37460,37478]
trailer [37460,37478]
===
match
---
arglist [46063,46259]
arglist [46115,46311]
===
match
---
name: AirflowTaskTimeout [51542,51560]
name: AirflowTaskTimeout [51594,51612]
===
match
---
expr_stmt [47169,47262]
expr_stmt [47221,47314]
===
match
---
atom_expr [18630,18651]
atom_expr [18630,18651]
===
match
---
name: execution_date [14962,14976]
name: execution_date [14962,14976]
===
match
---
param [69191,69196]
param [69243,69248]
===
match
---
operator: , [72393,72394]
operator: , [72445,72446]
===
match
---
name: IO [1037,1039]
name: IO [1037,1039]
===
match
---
string: 'ts_nodash_with_tz' [65788,65807]
string: 'ts_nodash_with_tz' [65840,65859]
===
match
---
simple_stmt [43084,43127]
simple_stmt [43136,43179]
===
match
---
return_stmt [64398,64471]
return_stmt [64450,64523]
===
match
---
atom_expr [68593,68608]
atom_expr [68645,68660]
===
match
---
name: self [58476,58480]
name: self [58528,58532]
===
match
---
argument [38225,38256]
argument [38225,38256]
===
match
---
expr_stmt [34603,34654]
expr_stmt [34603,34654]
===
match
---
expr_stmt [19511,19555]
expr_stmt [19511,19555]
===
match
---
trailer [6796,6807]
trailer [6796,6807]
===
match
---
name: Optional [15925,15933]
name: Optional [15925,15933]
===
match
---
atom_expr [68135,68176]
atom_expr [68187,68228]
===
match
---
atom_expr [82176,82203]
atom_expr [82228,82255]
===
match
---
comparison [76383,76397]
comparison [76435,76449]
===
match
---
operator: , [41822,41823]
operator: , [41791,41792]
===
match
---
trailer [65394,65402]
trailer [65446,65454]
===
match
---
arglist [56552,56563]
arglist [56604,56615]
===
match
---
atom_expr [47989,48007]
atom_expr [48041,48059]
===
match
---
trailer [41509,41518]
trailer [41478,41487]
===
match
---
atom_expr [4616,4626]
atom_expr [4616,4626]
===
match
---
suite [77858,77950]
suite [77910,78002]
===
match
---
name: e [44828,44829]
name: e [44880,44881]
===
match
---
operator: , [966,967]
operator: , [966,967]
===
match
---
name: commit [58971,58977]
name: commit [59023,59029]
===
match
---
expr_stmt [22556,22577]
expr_stmt [22556,22577]
===
match
---
if_stmt [72846,73009]
if_stmt [72898,73061]
===
match
---
arglist [58556,58585]
arglist [58608,58637]
===
match
---
name: dag_run [60431,60438]
name: dag_run [60483,60490]
===
match
---
operator: } [66063,66064]
operator: } [66115,66116]
===
match
---
string: 'logging' [18986,18995]
string: 'logging' [18986,18995]
===
match
---
operator: , [24690,24691]
operator: , [24690,24691]
===
match
---
trailer [78768,78775]
trailer [78820,78827]
===
match
---
operator: + [13172,13173]
operator: + [13172,13173]
===
match
---
operator: , [78848,78849]
operator: , [78900,78901]
===
match
---
name: ignore_task_deps [38386,38402]
name: ignore_task_deps [38386,38402]
===
match
---
string: "Task Duration set to %s" [73032,73057]
string: "Task Duration set to %s" [73084,73109]
===
match
---
decorator [8075,8085]
decorator [8075,8085]
===
match
---
suite [51814,51877]
suite [51866,51929]
===
match
---
name: pool [14273,14277]
name: pool [14273,14277]
===
match
---
atom_expr [18573,18601]
atom_expr [18573,18601]
===
match
---
name: self [79759,79763]
name: self [79811,79815]
===
match
---
return_stmt [32145,32157]
return_stmt [32145,32157]
===
match
---
name: TaskInstance [78866,78878]
name: TaskInstance [78918,78930]
===
match
---
trailer [5124,5130]
trailer [5124,5130]
===
match
---
operator: , [71898,71899]
operator: , [71950,71951]
===
match
---
simple_stmt [22043,22065]
simple_stmt [22043,22065]
===
match
---
trailer [27965,27973]
trailer [27965,27973]
===
match
---
trailer [6060,6064]
trailer [6060,6064]
===
match
---
name: modded_hash [34543,34554]
name: modded_hash [34543,34554]
===
match
---
trailer [41161,41166]
trailer [41130,41135]
===
match
---
name: state [33008,33013]
name: state [33008,33013]
===
match
---
expr_stmt [31703,31770]
expr_stmt [31703,31770]
===
match
---
name: self [11655,11659]
name: self [11655,11659]
===
match
---
suite [72614,72678]
suite [72666,72730]
===
match
---
name: task_id [68560,68567]
name: task_id [68612,68619]
===
match
---
simple_stmt [11935,11972]
simple_stmt [11935,11972]
===
match
---
simple_stmt [40835,40856]
simple_stmt [40804,40825]
===
match
---
trailer [65201,65229]
trailer [65253,65281]
===
match
---
name: session [46933,46940]
name: session [46985,46992]
===
match
---
funcdef [24111,24314]
funcdef [24111,24314]
===
match
---
name: datetime [8041,8049]
name: datetime [8041,8049]
===
match
---
name: values_ordered_by_id [77110,77130]
name: values_ordered_by_id [77162,77182]
===
match
---
name: _try_number [55853,55864]
name: _try_number [55905,55916]
===
match
---
atom_expr [64535,64543]
atom_expr [64587,64595]
===
match
---
atom_expr [65584,65598]
atom_expr [65636,65650]
===
match
---
operator: , [41208,41209]
operator: , [41177,41178]
===
match
---
name: key [80534,80537]
name: key [80586,80589]
===
match
---
fstring_string: ?task_id= [19621,19630]
fstring_string: ?task_id= [19621,19630]
===
match
---
name: logging_mixin [2513,2526]
name: logging_mixin [2513,2526]
===
match
---
try_stmt [4369,4632]
try_stmt [4369,4632]
===
match
---
simple_stmt [39091,39171]
simple_stmt [39091,39171]
===
match
---
arglist [37569,37606]
arglist [37569,37606]
===
match
---
name: self [81161,81165]
name: self [81213,81217]
===
match
---
name: XCom [2105,2109]
name: XCom [2105,2109]
===
match
---
name: strftime [62062,62070]
name: strftime [62114,62122]
===
match
---
name: SimpleTaskInstance [79622,79640]
name: SimpleTaskInstance [79674,79692]
===
match
---
simple_stmt [81503,81532]
simple_stmt [81555,81584]
===
match
---
operator: , [29107,29108]
operator: , [29107,29108]
===
match
---
string: 'ds' [64589,64593]
string: 'ds' [64641,64645]
===
match
---
operator: , [18089,18090]
operator: , [18089,18090]
===
match
---
arglist [56910,56953]
arglist [56962,57005]
===
match
---
atom_expr [81359,81370]
atom_expr [81411,81422]
===
match
---
expr_stmt [82378,82397]
expr_stmt [82430,82449]
===
match
---
name: settings [1567,1575]
name: settings [1567,1575]
===
match
---
parameters [30352,30358]
parameters [30352,30358]
===
match
---
atom_expr [11239,11267]
atom_expr [11239,11267]
===
match
---
trailer [5064,5090]
trailer [5064,5090]
===
match
---
name: commit [24039,24045]
name: commit [24039,24045]
===
match
---
name: log [58839,58842]
name: log [58891,58894]
===
match
---
simple_stmt [13325,13473]
simple_stmt [13325,13473]
===
match
---
and_test [73906,73961]
and_test [73958,74013]
===
match
---
atom_expr [6905,6923]
atom_expr [6905,6923]
===
match
---
atom_expr [7631,7675]
atom_expr [7631,7675]
===
match
---
atom_expr [71048,71098]
atom_expr [71100,71150]
===
match
---
name: test_mode [41683,41692]
name: test_mode [41652,41661]
===
match
---
trailer [48855,48861]
trailer [48907,48913]
===
match
---
operator: , [20594,20595]
operator: , [20594,20595]
===
match
---
atom_expr [55698,55721]
atom_expr [55750,55773]
===
match
---
operator: , [44268,44269]
operator: , [44320,44321]
===
match
---
operator: , [68608,68609]
operator: , [68660,68661]
===
match
---
trailer [42847,42852]
trailer [42899,42904]
===
match
---
decorated [24319,25031]
decorated [24319,25031]
===
match
---
simple_stmt [39227,39272]
simple_stmt [39227,39272]
===
match
---
name: task_id [8008,8015]
name: task_id [8008,8015]
===
match
---
name: task [26766,26770]
name: task [26766,26770]
===
match
---
operator: , [54597,54598]
operator: , [54649,54650]
===
match
---
expr_stmt [22043,22064]
expr_stmt [22043,22064]
===
match
---
atom_expr [80007,80018]
atom_expr [80059,80070]
===
match
---
atom_expr [30028,30076]
atom_expr [30028,30076]
===
match
---
trailer [20387,20402]
trailer [20387,20402]
===
match
---
name: TaskInstance [26152,26164]
name: TaskInstance [26152,26164]
===
match
---
name: log [48376,48379]
name: log [48428,48431]
===
match
---
name: self [32670,32674]
name: self [32670,32674]
===
match
---
atom_expr [77134,77154]
atom_expr [77186,77206]
===
match
---
dictorsetmaker [76960,77082]
dictorsetmaker [77012,77134]
===
match
---
trailer [28739,28744]
trailer [28739,28744]
===
match
---
trailer [18937,18939]
trailer [18937,18939]
===
match
---
name: self [22043,22047]
name: self [22043,22047]
===
match
---
name: Proxy [65166,65171]
name: Proxy [65218,65223]
===
match
---
comparison [52619,52655]
comparison [52671,52707]
===
match
---
arglist [48889,48920]
arglist [48941,48972]
===
match
---
name: task [62351,62355]
name: task [62403,62407]
===
match
---
simple_stmt [9806,9834]
simple_stmt [9806,9834]
===
match
---
trailer [13809,13821]
trailer [13809,13821]
===
match
---
name: session [47647,47654]
name: session [47699,47706]
===
match
---
name: dag_id [79815,79821]
name: dag_id [79867,79873]
===
match
---
arglist [47562,47628]
arglist [47614,47680]
===
match
---
operator: , [50656,50657]
operator: , [50708,50709]
===
match
---
atom_expr [21635,21647]
atom_expr [21635,21647]
===
match
---
atom_expr [23983,24002]
atom_expr [23983,24002]
===
match
---
trailer [20858,20864]
trailer [20858,20864]
===
match
---
trailer [11295,11305]
trailer [11295,11305]
===
match
---
name: session [31859,31866]
name: session [31859,31866]
===
match
---
name: self [43766,43770]
name: self [43818,43822]
===
match
---
operator: = [15143,15144]
operator: = [15143,15144]
===
match
---
name: get_k8s_pod_yaml [67282,67298]
name: get_k8s_pod_yaml [67334,67350]
===
match
---
name: hasattr [69430,69437]
name: hasattr [69482,69489]
===
match
---
trailer [47428,47433]
trailer [47480,47485]
===
match
---
param [64039,64043]
param [64091,64095]
===
match
---
name: ignore_ti_state [37716,37731]
name: ignore_ti_state [37716,37731]
===
match
---
string: 'yesterday_ds_nodash' [66011,66032]
string: 'yesterday_ds_nodash' [66063,66084]
===
match
---
dotted_name [2210,2223]
dotted_name [2210,2223]
===
match
---
trailer [9499,9551]
trailer [9499,9551]
===
match
---
trailer [80395,80418]
trailer [80447,80470]
===
match
---
fstring_expr [42878,42892]
fstring_expr [42930,42944]
===
match
---
trailer [44266,44320]
trailer [44318,44372]
===
match
---
trailer [7121,7127]
trailer [7121,7127]
===
match
---
trailer [78316,78321]
trailer [78368,78373]
===
match
---
expr_stmt [72988,73008]
expr_stmt [73040,73060]
===
match
---
name: provide_session [74412,74427]
name: provide_session [74464,74479]
===
match
---
name: TaskReschedule [55398,55412]
name: TaskReschedule [55450,55464]
===
match
---
operator: = [42604,42605]
operator: = [42573,42574]
===
match
---
trailer [50407,50416]
trailer [50459,50468]
===
match
---
operator: = [58193,58194]
operator: = [58245,58246]
===
match
---
operator: = [62291,62292]
operator: = [62343,62344]
===
match
---
name: name [54560,54564]
name: name [54612,54616]
===
match
---
trailer [19180,19213]
trailer [19180,19213]
===
match
---
trailer [62524,62556]
trailer [62576,62608]
===
match
---
trailer [38458,38479]
trailer [38458,38479]
===
match
---
name: ti [6016,6018]
name: ti [6016,6018]
===
match
---
name: ts_nodash [65765,65774]
name: ts_nodash [65817,65826]
===
match
---
atom_expr [23381,23397]
atom_expr [23381,23397]
===
match
---
name: self [27081,27085]
name: self [27081,27085]
===
match
---
string: 'ti_job_id' [10800,10811]
string: 'ti_job_id' [10800,10811]
===
match
---
simple_stmt [48541,48587]
simple_stmt [48593,48639]
===
match
---
param [51135,51143]
param [51187,51195]
===
match
---
name: sql [1508,1511]
name: sql [1508,1511]
===
match
---
name: dag [14537,14540]
name: dag [14537,14540]
===
match
---
suite [79641,82376]
suite [79693,82428]
===
match
---
name: self [73059,73063]
name: self [73111,73115]
===
match
---
trailer [5956,5961]
trailer [5956,5961]
===
match
---
trailer [48462,48464]
trailer [48514,48516]
===
match
---
operator: = [3197,3198]
operator: = [3197,3198]
===
match
---
name: pendulum [64665,64673]
name: pendulum [64717,64725]
===
match
---
atom_expr [64665,64703]
atom_expr [64717,64755]
===
match
---
atom_expr [8215,8226]
atom_expr [8215,8226]
===
match
---
name: self [72988,72992]
name: self [73040,73044]
===
match
---
trailer [27960,27991]
trailer [27960,27991]
===
match
---
param [62960,62970]
param [63012,63022]
===
match
---
trailer [77608,77782]
trailer [77660,77834]
===
match
---
operator: , [17949,17950]
operator: , [17949,17950]
===
match
---
expr_stmt [5016,5091]
expr_stmt [5016,5091]
===
match
---
operator: == [6613,6615]
operator: == [6613,6615]
===
match
---
atom_expr [80885,80901]
atom_expr [80937,80953]
===
match
---
name: self [41633,41637]
name: self [41602,41606]
===
match
---
simple_stmt [9615,9648]
simple_stmt [9615,9648]
===
match
---
atom_expr [3888,3919]
atom_expr [3888,3919]
===
match
---
trailer [3215,3225]
trailer [3215,3225]
===
match
---
name: ignore_schedule [27569,27584]
name: ignore_schedule [27569,27584]
===
match
---
comparison [25270,25302]
comparison [25270,25302]
===
match
---
name: hr_line_break [40514,40527]
name: hr_line_break [40514,40527]
===
match
---
name: get [64126,64129]
name: get [64178,64181]
===
match
---
trailer [40638,40653]
trailer [40638,40653]
===
match
---
operator: , [64902,64903]
operator: , [64954,64955]
===
match
---
name: ignore_ti_state [54052,54067]
name: ignore_ti_state [54104,54119]
===
match
---
name: TaskInstance [82176,82188]
name: TaskInstance [82228,82240]
===
match
---
simple_stmt [36047,37423]
simple_stmt [36047,37423]
===
match
---
suite [11108,12406]
suite [11108,12406]
===
match
---
simple_stmt [9411,9480]
simple_stmt [9411,9480]
===
match
---
atom_expr [9698,9711]
atom_expr [9698,9711]
===
match
---
dotted_name [1497,1520]
dotted_name [1497,1520]
===
match
---
name: REQUEUEABLE_DEPS [39528,39544]
name: REQUEUEABLE_DEPS [39528,39544]
===
match
---
trailer [3187,3196]
trailer [3187,3196]
===
match
---
trailer [34724,34758]
trailer [34724,34758]
===
match
---
not_test [11422,11463]
not_test [11422,11463]
===
match
---
name: tis [78167,78170]
name: tis [78219,78222]
===
match
---
atom_expr [78945,78953]
atom_expr [78997,79005]
===
match
---
name: pool [15364,15368]
name: pool [15364,15368]
===
match
---
expr_stmt [76932,77096]
expr_stmt [76984,77148]
===
match
---
name: first [39163,39168]
name: first [39163,39168]
===
match
---
name: _dag_id [82104,82111]
name: _dag_id [82156,82163]
===
match
---
fstring_string: = [49289,49290]
fstring_string: = [49341,49342]
===
match
---
trailer [58691,58697]
trailer [58743,58749]
===
match
---
name: nullable [10026,10034]
name: nullable [10026,10034]
===
match
---
trailer [45062,45066]
trailer [45114,45118]
===
match
---
simple_stmt [72132,72186]
simple_stmt [72184,72238]
===
match
---
operator: = [22017,22018]
operator: = [22017,22018]
===
match
---
operator: , [10569,10570]
operator: , [10569,10570]
===
match
---
atom_expr [40325,40341]
atom_expr [40325,40341]
===
match
---
trailer [35452,35467]
trailer [35452,35467]
===
match
---
name: ti [82373,82375]
name: ti [82425,82427]
===
match
---
arglist [50462,50480]
arglist [50514,50532]
===
match
---
operator: , [27973,27974]
operator: , [27973,27974]
===
match
---
name: integrate_macros_plugins [59916,59940]
name: integrate_macros_plugins [59968,59992]
===
match
---
operator: @ [56007,56008]
operator: @ [56059,56060]
===
match
---
param [14119,14148]
param [14119,14148]
===
match
---
argument [39859,39871]
argument [39859,39871]
===
match
---
test [54650,54716]
test [54702,54768]
===
match
---
name: task [11047,11051]
name: task [11047,11051]
===
match
---
operator: } [19643,19644]
operator: } [19643,19644]
===
match
---
name: self [69191,69195]
name: self [69243,69247]
===
match
---
string: 'Host: {{ti.hostname}}<br>' [69937,69964]
string: 'Host: {{ti.hostname}}<br>' [69989,70016]
===
match
---
funcdef [56028,58980]
funcdef [56080,59032]
===
match
---
atom_expr [77754,77767]
atom_expr [77806,77819]
===
match
---
trailer [18005,18012]
trailer [18005,18012]
===
match
---
trailer [79984,79994]
trailer [80036,80046]
===
match
---
trailer [46897,46932]
trailer [46949,46984]
===
match
---
and_test [34970,35053]
and_test [34970,35053]
===
match
---
name: RenderedTaskInstanceFields [67255,67281]
name: RenderedTaskInstanceFields [67307,67333]
===
match
---
name: dag [5329,5332]
name: dag [5329,5332]
===
match
---
trailer [69092,69094]
trailer [69144,69146]
===
match
---
param [74655,74689]
param [74707,74741]
===
match
---
operator: = [63937,63938]
operator: = [63989,63990]
===
match
---
suite [81494,81532]
suite [81546,81584]
===
match
---
name: ignore_ti_state [18437,18452]
name: ignore_ti_state [18437,18452]
===
match
---
name: passed [32748,32754]
name: passed [32748,32754]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28238,28389]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28238,28389]
===
match
---
name: task_id [58455,58462]
name: task_id [58507,58514]
===
match
---
simple_stmt [55016,55036]
simple_stmt [55068,55088]
===
match
---
name: ti [80007,80009]
name: ti [80059,80061]
===
match
---
operator: @ [19371,19372]
operator: @ [19371,19372]
===
match
---
name: pendulum [61666,61674]
name: pendulum [61718,61726]
===
match
---
trailer [40734,40760]
trailer [40734,40760]
===
match
---
atom_expr [44028,44050]
atom_expr [44080,44102]
===
match
---
annassign [8039,8049]
annassign [8039,8049]
===
match
---
name: error [59233,59238]
name: error [59285,59290]
===
match
---
return_stmt [13798,13821]
return_stmt [13798,13821]
===
match
---
name: mark_success [15579,15591]
name: mark_success [15579,15591]
===
match
---
name: String [1326,1332]
name: String [1326,1332]
===
match
---
name: item [63952,63956]
name: item [64004,64008]
===
match
---
operator: = [46583,46584]
operator: = [46635,46636]
===
match
---
name: utcnow [40353,40359]
name: utcnow [40353,40359]
===
match
---
simple_stmt [18067,18108]
simple_stmt [18067,18108]
===
match
---
operator: = [71003,71004]
operator: = [71055,71056]
===
match
---
param [30927,30932]
param [30927,30932]
===
match
---
name: str [56205,56208]
name: str [56257,56260]
===
match
---
trailer [27942,27960]
trailer [27942,27960]
===
match
---
operator: } [47916,47917]
operator: } [47968,47969]
===
match
---
simple_stmt [49366,49406]
simple_stmt [49418,49458]
===
match
---
name: FAILED [52567,52573]
name: FAILED [52619,52625]
===
match
---
simple_stmt [45514,45534]
simple_stmt [45566,45586]
===
match
---
atom_expr [78381,78401]
atom_expr [78433,78453]
===
match
---
parameters [51929,51959]
parameters [51981,52011]
===
match
---
simple_stmt [34603,34655]
simple_stmt [34603,34655]
===
match
---
name: in_ [6834,6837]
name: in_ [6834,6837]
===
match
---
name: error_file [56733,56743]
name: error_file [56785,56795]
===
match
---
operator: , [50759,50760]
operator: , [50811,50812]
===
match
---
name: models [60168,60174]
name: models [60220,60226]
===
match
---
name: self [41301,41305]
name: self [41270,41274]
===
match
---
arglist [4398,4407]
arglist [4398,4407]
===
match
---
atom_expr [5413,5439]
atom_expr [5413,5439]
===
match
---
atom_expr [76896,76918]
atom_expr [76948,76970]
===
match
---
suite [26922,27275]
suite [26922,27275]
===
match
---
operator: = [3206,3207]
operator: = [3206,3207]
===
match
---
trailer [73199,73209]
trailer [73251,73261]
===
match
---
arglist [49216,49338]
arglist [49268,49390]
===
match
---
trailer [43428,43433]
trailer [43480,43485]
===
match
---
operator: = [52681,52682]
operator: = [52733,52734]
===
match
---
trailer [23857,23864]
trailer [23857,23864]
===
match
---
simple_stmt [41341,41353]
simple_stmt [41310,41322]
===
match
---
name: task [66493,66497]
name: task [66545,66549]
===
match
---
trailer [65382,65403]
trailer [65434,65455]
===
match
---
atom_expr [71664,71679]
atom_expr [71716,71731]
===
match
---
name: debug [23802,23807]
name: debug [23802,23807]
===
match
---
trailer [73946,73961]
trailer [73998,74013]
===
match
---
import_from [1547,1575]
import_from [1547,1575]
===
match
---
expr_stmt [61590,61631]
expr_stmt [61642,61683]
===
match
---
arglist [77626,77768]
arglist [77678,77820]
===
match
---
atom_expr [30826,30875]
atom_expr [30826,30875]
===
match
---
name: verbose [39859,39866]
name: verbose [39859,39866]
===
match
---
name: execution_date [21674,21688]
name: execution_date [21674,21688]
===
match
---
name: unixname [22404,22412]
name: unixname [22404,22412]
===
match
---
operator: , [63868,63869]
operator: , [63920,63921]
===
match
---
name: models [67168,67174]
name: models [67220,67226]
===
match
---
atom_expr [5164,5173]
atom_expr [5164,5173]
===
match
---
name: State [52833,52838]
name: State [52885,52890]
===
match
---
name: try_number [11986,11996]
name: try_number [11986,11996]
===
match
---
name: xcom [77360,77364]
name: xcom [77412,77416]
===
match
---
name: ignore_task_deps [15700,15716]
name: ignore_task_deps [15700,15716]
===
match
---
trailer [31801,31825]
trailer [31801,31825]
===
match
---
import_from [1394,1448]
import_from [1394,1448]
===
match
---
operator: , [10820,10821]
operator: , [10820,10821]
===
match
---
trailer [33767,33772]
trailer [33767,33772]
===
match
---
name: self [59461,59465]
name: self [59513,59517]
===
match
---
operator: , [24002,24003]
operator: , [24002,24003]
===
match
---
trailer [62012,62021]
trailer [62064,62073]
===
match
---
trailer [80260,80273]
trailer [80312,80325]
===
match
---
name: start_date [39261,39271]
name: start_date [39261,39271]
===
match
---
trailer [48547,48554]
trailer [48599,48606]
===
match
---
operator: , [76590,76591]
operator: , [76642,76643]
===
match
---
name: next_execution_date [61644,61663]
name: next_execution_date [61696,61715]
===
match
---
operator: , [24260,24261]
operator: , [24260,24261]
===
match
---
trailer [24060,24064]
trailer [24060,24064]
===
match
---
string: 'task' [65461,65467]
string: 'task' [65513,65519]
===
match
---
operator: } [33013,33014]
operator: } [33013,33014]
===
match
---
atom_expr [12531,12545]
atom_expr [12531,12545]
===
match
---
not_test [45440,45453]
not_test [45492,45505]
===
match
---
expr_stmt [62876,62891]
expr_stmt [62928,62943]
===
match
---
argument [15074,15107]
argument [15074,15107]
===
match
---
name: self [54886,54890]
name: self [54938,54942]
===
match
---
trailer [7872,7883]
trailer [7872,7883]
===
match
---
atom_expr [21963,21976]
atom_expr [21963,21976]
===
match
---
string: 'webserver' [19242,19253]
string: 'webserver' [19242,19253]
===
match
---
operator: = [63293,63294]
operator: = [63345,63346]
===
match
---
simple_stmt [7992,8004]
simple_stmt [7992,8004]
===
match
---
trailer [5297,5305]
trailer [5297,5305]
===
match
---
atom_expr [23323,23343]
atom_expr [23323,23343]
===
match
---
name: ti [79812,79814]
name: ti [79864,79866]
===
match
---
trailer [56888,56890]
trailer [56940,56942]
===
match
---
atom_expr [22801,22850]
atom_expr [22801,22850]
===
match
---
name: commit [38607,38613]
name: commit [38607,38613]
===
match
---
operator: , [54564,54565]
operator: , [54616,54617]
===
match
---
simple_stmt [1492,1546]
simple_stmt [1492,1546]
===
match
---
operator: , [15236,15237]
operator: , [15236,15237]
===
match
---
trailer [25990,25996]
trailer [25990,25996]
===
match
---
strings [69767,70087]
strings [69819,70139]
===
match
---
operator: { [19329,19330]
operator: { [19329,19330]
===
match
---
comparison [35446,35490]
comparison [35446,35490]
===
match
---
trailer [56541,56545]
trailer [56593,56597]
===
match
---
name: schedulable_ti [47353,47367]
name: schedulable_ti [47405,47419]
===
match
---
name: VariableJsonAccessor [63490,63510]
name: VariableJsonAccessor [63542,63562]
===
match
---
name: task_retries [5531,5543]
name: task_retries [5531,5543]
===
match
---
operator: = [74327,74328]
operator: = [74379,74380]
===
match
---
param [55085,55090]
param [55137,55142]
===
match
---
simple_stmt [48445,48465]
simple_stmt [48497,48517]
===
match
---
name: self [43227,43231]
name: self [43279,43283]
===
match
---
tfpdef [35703,35724]
tfpdef [35703,35724]
===
match
---
name: self [72913,72917]
name: self [72965,72969]
===
match
---
simple_stmt [82627,82678]
simple_stmt [82679,82730]
===
match
---
simple_stmt [7263,7305]
simple_stmt [7263,7305]
===
match
---
name: self [67793,67797]
name: self [67845,67849]
===
match
---
operator: = [50768,50769]
operator: = [50820,50821]
===
match
---
expr_stmt [72022,72040]
expr_stmt [72074,72092]
===
match
---
name: int [81026,81029]
name: int [81078,81081]
===
match
---
operator: = [27585,27586]
operator: = [27585,27586]
===
match
---
string: """Returns SQLAlchemy filter to query selected task instances""" [78087,78151]
string: """Returns SQLAlchemy filter to query selected task instances""" [78139,78203]
===
match
---
simple_stmt [937,978]
simple_stmt [937,978]
===
match
---
name: key [76524,76527]
name: key [76576,76579]
===
match
---
name: bool [41694,41698]
name: bool [41663,41667]
===
match
---
name: property [24098,24106]
name: property [24098,24106]
===
match
---
name: self [57152,57156]
name: self [57204,57208]
===
match
---
except_clause [43957,44014]
except_clause [44009,44066]
===
match
---
name: TaskInstance [26040,26052]
name: TaskInstance [26040,26052]
===
match
---
name: airflow [1552,1559]
name: airflow [1552,1559]
===
match
---
name: verbose_aware_logger [32167,32187]
name: verbose_aware_logger [32167,32187]
===
match
---
operator: = [9816,9817]
operator: = [9816,9817]
===
match
---
simple_stmt [79239,79487]
simple_stmt [79291,79539]
===
match
---
operator: , [1324,1325]
operator: , [1324,1325]
===
match
---
operator: = [72296,72297]
operator: = [72348,72349]
===
match
---
name: cfg_path [14292,14300]
name: cfg_path [14292,14300]
===
match
---
name: generate_command [14876,14892]
name: generate_command [14876,14892]
===
match
---
operator: = [11997,11998]
operator: = [11997,11998]
===
match
---
argument [9462,9478]
argument [9462,9478]
===
match
---
param [53518,53549]
param [53570,53601]
===
match
---
simple_stmt [1186,1202]
simple_stmt [1186,1202]
===
match
---
atom_expr [32837,32854]
atom_expr [32837,32854]
===
match
---
name: dag_id [78654,78660]
name: dag_id [78706,78712]
===
match
---
trailer [45783,45794]
trailer [45835,45846]
===
match
---
arglist [48555,48585]
arglist [48607,48637]
===
match
---
name: num [47625,47628]
name: num [47677,47680]
===
match
---
trailer [22377,22386]
trailer [22377,22386]
===
match
---
name: self [67392,67396]
name: self [67444,67448]
===
match
---
trailer [6669,6972]
trailer [6669,6972]
===
match
---
name: self [43011,43015]
name: self [43063,43067]
===
match
---
expr_stmt [23202,23225]
expr_stmt [23202,23225]
===
match
---
name: models [2024,2030]
name: models [2024,2030]
===
match
---
dotted_name [68278,68324]
dotted_name [68330,68376]
===
match
---
name: SEEK_SET [3987,3995]
name: SEEK_SET [3987,3995]
===
match
---
operator: , [44296,44297]
operator: , [44348,44349]
===
match
---
suite [60063,60530]
suite [60115,60582]
===
match
---
atom_expr [3874,3883]
atom_expr [3874,3883]
===
match
---
trailer [72148,72185]
trailer [72200,72237]
===
match
---
argument [38171,38207]
argument [38171,38207]
===
match
---
atom_expr [48995,49006]
atom_expr [49047,49058]
===
match
---
argument [48898,48920]
argument [48950,48972]
===
match
---
name: try_number [40585,40595]
name: try_number [40585,40595]
===
match
---
suite [61790,61981]
suite [61842,62033]
===
match
---
fstring_expr [67577,67580]
fstring_expr [67629,67632]
===
match
---
name: self [47820,47824]
name: self [47872,47876]
===
match
---
suite [74736,77366]
suite [74788,77418]
===
match
---
name: warnings [28731,28739]
name: warnings [28731,28739]
===
match
---
trailer [3975,3980]
trailer [3975,3980]
===
match
---
trailer [3876,3883]
trailer [3876,3883]
===
match
---
operator: = [55141,55142]
operator: = [55193,55194]
===
match
---
operator: = [76527,76528]
operator: = [76579,76580]
===
match
---
tfpdef [35673,35686]
tfpdef [35673,35686]
===
match
---
name: info [40509,40513]
name: info [40509,40513]
===
match
---
operator: = [82026,82027]
operator: = [82078,82079]
===
match
---
param [15849,15881]
param [15849,15881]
===
match
---
name: previous_schedule [27063,27080]
name: previous_schedule [27063,27080]
===
match
---
simple_stmt [51023,51106]
simple_stmt [51075,51158]
===
match
---
atom_expr [52320,52341]
atom_expr [52372,52393]
===
match
---
argument [47940,47953]
argument [47992,48005]
===
match
---
return_stmt [82366,82375]
return_stmt [82418,82427]
===
match
---
name: AirflowException [66686,66702]
name: AirflowException [66738,66754]
===
match
---
expr_stmt [54311,54353]
expr_stmt [54363,54405]
===
match
---
atom_expr [12092,12105]
atom_expr [12092,12105]
===
match
---
trailer [22809,22815]
trailer [22809,22815]
===
match
---
number: 1 [8497,8498]
number: 1 [8497,8498]
===
match
---
trailer [56909,56954]
trailer [56961,57006]
===
match
---
name: NamedTemporaryFile [999,1017]
name: NamedTemporaryFile [999,1017]
===
match
---
number: 0 [26304,26305]
number: 0 [26304,26305]
===
match
---
trailer [80169,80182]
trailer [80221,80234]
===
match
---
argument [71705,71729]
argument [71757,71781]
===
match
---
atom_expr [3592,3614]
atom_expr [3592,3614]
===
match
---
name: key [81394,81397]
name: key [81446,81449]
===
match
---
operator: = [39577,39578]
operator: = [39577,39578]
===
match
---
trailer [34620,34654]
trailer [34620,34654]
===
match
---
operator: = [54347,54348]
operator: = [54399,54400]
===
match
---
operator: = [7556,7557]
operator: = [7556,7557]
===
match
---
name: self [24740,24744]
name: self [24740,24744]
===
match
---
expr_stmt [53177,53214]
expr_stmt [53229,53266]
===
match
---
name: BaseJob [82669,82676]
name: BaseJob [82721,82728]
===
match
---
name: cmd [18002,18005]
name: cmd [18002,18005]
===
match
---
if_stmt [37685,37818]
if_stmt [37685,37818]
===
match
---
trailer [71668,71679]
trailer [71720,71731]
===
match
---
trailer [10340,10374]
trailer [10340,10374]
===
match
---
name: command_as_list [68717,68732]
name: command_as_list [68769,68784]
===
match
---
name: context [68168,68175]
name: context [68220,68227]
===
match
---
name: log [47825,47828]
name: log [47877,47880]
===
match
---
atom_expr [80388,80418]
atom_expr [80440,80470]
===
match
---
expr_stmt [54953,54974]
expr_stmt [55005,55026]
===
match
---
operator: == [6713,6715]
operator: == [6713,6715]
===
match
---
arglist [30116,30144]
arglist [30116,30144]
===
match
---
simple_stmt [27812,27879]
simple_stmt [27812,27879]
===
match
---
trailer [18395,18425]
trailer [18395,18425]
===
match
---
operator: @ [45653,45654]
operator: @ [45705,45706]
===
match
---
name: ts [60593,60595]
name: ts [60645,60647]
===
match
---
operator: == [23931,23933]
operator: == [23931,23933]
===
match
---
simple_stmt [64398,64472]
simple_stmt [64450,64524]
===
match
---
operator: = [23398,23399]
operator: = [23398,23399]
===
match
---
atom_expr [27608,27629]
atom_expr [27608,27629]
===
match
---
sync_comp_for [47030,47133]
sync_comp_for [47082,47185]
===
match
---
operator: = [14571,14572]
operator: = [14571,14572]
===
match
---
name: state [45488,45493]
name: state [45540,45545]
===
match
---
name: List [16032,16036]
name: List [16032,16036]
===
match
---
argument [76476,76510]
argument [76528,76562]
===
match
---
simple_stmt [70993,71130]
simple_stmt [71045,71182]
===
match
---
name: dag_id [19050,19056]
name: dag_id [19050,19056]
===
match
---
import_name [871,884]
import_name [871,884]
===
match
---
trailer [15827,15832]
trailer [15827,15832]
===
match
---
decorator [63147,63161]
decorator [63199,63213]
===
match
---
name: BooleanClauseList [1528,1545]
name: BooleanClauseList [1528,1545]
===
match
---
param [11053,11078]
param [11053,11078]
===
match
---
name: error_fd [54729,54737]
name: error_fd [54781,54789]
===
match
---
string: 'webserver' [19531,19542]
string: 'webserver' [19531,19542]
===
match
---
argument [10291,10303]
argument [10291,10303]
===
match
---
parameters [18846,18852]
parameters [18846,18852]
===
match
---
atom_expr [12119,12138]
atom_expr [12119,12138]
===
match
---
argument [15332,15345]
argument [15332,15345]
===
match
---
operator: = [61228,61229]
operator: = [61280,61281]
===
match
---
operator: , [65955,65956]
operator: , [66007,66008]
===
match
---
name: getboolean [62420,62430]
name: getboolean [62472,62482]
===
match
---
operator: = [29020,29021]
operator: = [29020,29021]
===
match
---
atom_expr [78638,78713]
atom_expr [78690,78765]
===
match
---
comparison [27608,27637]
comparison [27608,27637]
===
match
---
simple_stmt [20541,20554]
simple_stmt [20541,20554]
===
match
---
name: end_date [24900,24908]
name: end_date [24900,24908]
===
match
---
dotted_name [2176,2190]
dotted_name [2176,2190]
===
match
---
name: utils [2866,2871]
name: utils [2866,2871]
===
match
---
operator: = [25397,25398]
operator: = [25397,25398]
===
match
---
name: dag [11755,11758]
name: dag [11755,11758]
===
match
---
trailer [57038,57063]
trailer [57090,57115]
===
match
---
operator: = [35994,35995]
operator: = [35994,35995]
===
match
---
atom_expr [61537,61577]
atom_expr [61589,61629]
===
match
---
operator: , [68811,68812]
operator: , [68863,68864]
===
match
---
name: Any [80132,80135]
name: Any [80184,80187]
===
match
---
name: ts_nodash_with_tz [65809,65826]
name: ts_nodash_with_tz [65861,65878]
===
match
---
simple_stmt [34767,34796]
simple_stmt [34767,34796]
===
match
---
name: ignore_ti_state [38290,38305]
name: ignore_ti_state [38290,38305]
===
match
---
trailer [49552,49574]
trailer [49604,49626]
===
match
---
name: ti [20458,20460]
name: ti [20458,20460]
===
match
---
atom_expr [66283,66336]
atom_expr [66335,66388]
===
match
---
tfpdef [74619,74627]
tfpdef [74671,74679]
===
match
---
trailer [62261,62270]
trailer [62313,62322]
===
match
---
name: result [50575,50581]
name: result [50627,50633]
===
match
---
name: construct_task_instance [81562,81585]
name: construct_task_instance [81614,81637]
===
match
---
atom_expr [17874,17900]
atom_expr [17874,17900]
===
match
---
trailer [50792,50797]
trailer [50844,50849]
===
match
---
trailer [67874,67879]
trailer [67926,67931]
===
match
---
name: self [8472,8476]
name: self [8472,8476]
===
match
---
operator: , [40595,40596]
operator: , [40595,40596]
===
match
---
name: __repr__ [64030,64038]
name: __repr__ [64082,64090]
===
match
---
operator: = [77131,77132]
operator: = [77183,77184]
===
match
---
trailer [80223,80242]
trailer [80275,80294]
===
match
---
atom_expr [55457,55476]
atom_expr [55509,55528]
===
match
---
name: log [41158,41161]
name: log [41127,41130]
===
match
---
name: state [24806,24811]
name: state [24806,24811]
===
match
---
atom_expr [54984,55007]
atom_expr [55036,55059]
===
match
---
name: task [37443,37447]
name: task [37443,37447]
===
match
---
name: all [78638,78641]
name: all [78690,78693]
===
match
---
simple_stmt [47169,47263]
simple_stmt [47221,47315]
===
match
---
operator: = [58087,58088]
operator: = [58139,58140]
===
match
---
name: self [29703,29707]
name: self [29703,29707]
===
match
---
string: 'test_mode' [65571,65582]
string: 'test_mode' [65623,65634]
===
match
---
atom_expr [6794,6807]
atom_expr [6794,6807]
===
match
---
trailer [68892,68911]
trailer [68944,68963]
===
match
---
operator: @ [25339,25340]
operator: @ [25339,25340]
===
match
---
name: jinja2 [1154,1160]
name: jinja2 [1154,1160]
===
match
---
argument [39562,39593]
argument [39562,39593]
===
match
---
atom_expr [9573,9610]
atom_expr [9573,9610]
===
match
---
simple_stmt [34713,34759]
simple_stmt [34713,34759]
===
match
---
string: 'Exception:<br>Failed attempt to attach error logs<br>' [70210,70265]
string: 'Exception:<br>Failed attempt to attach error logs<br>' [70262,70317]
===
match
---
simple_stmt [43256,43263]
simple_stmt [43308,43315]
===
match
---
operator: , [63448,63449]
operator: , [63500,63501]
===
match
---
operator: , [55510,55511]
operator: , [55562,55563]
===
match
---
name: self [8547,8551]
name: self [8547,8551]
===
match
---
operator: @ [81206,81207]
operator: @ [81258,81259]
===
match
---
name: isoformat [18928,18937]
name: isoformat [18928,18937]
===
match
---
operator: @ [80655,80656]
operator: @ [80707,80708]
===
match
---
name: self [52956,52960]
name: self [53008,53012]
===
match
---
trailer [5872,5882]
trailer [5872,5882]
===
match
---
trailer [80303,80309]
trailer [80355,80361]
===
match
---
trailer [62070,62087]
trailer [62122,62139]
===
match
---
funcdef [41358,41554]
funcdef [41327,41523]
===
match
---
trailer [12096,12105]
trailer [12096,12105]
===
match
---
arith_expr [19282,19365]
arith_expr [19282,19365]
===
match
---
name: field_name [66499,66509]
name: field_name [66551,66561]
===
match
---
param [59048,59053]
param [59100,59105]
===
match
---
tfpdef [15808,15832]
tfpdef [15808,15832]
===
match
---
trailer [39011,39018]
trailer [39011,39018]
===
match
---
trailer [48247,48249]
trailer [48299,48301]
===
match
---
arglist [58853,58894]
arglist [58905,58946]
===
match
---
name: end_date [21968,21976]
name: end_date [21968,21976]
===
match
---
atom_expr [62116,62152]
atom_expr [62168,62204]
===
match
---
name: context [53177,53184]
name: context [53229,53236]
===
match
---
operator: , [53393,53394]
operator: , [53445,53446]
===
match
---
suite [68075,68126]
suite [68127,68178]
===
match
---
atom_expr [52956,52983]
atom_expr [53008,53035]
===
match
---
name: self [21963,21967]
name: self [21963,21967]
===
match
---
simple_stmt [9374,9406]
simple_stmt [9374,9406]
===
match
---
name: TaskInstance [20195,20207]
name: TaskInstance [20195,20207]
===
match
---
name: get_template_context [59727,59747]
name: get_template_context [59779,59799]
===
match
---
operator: = [59348,59349]
operator: = [59400,59401]
===
match
---
atom_expr [71981,71991]
atom_expr [72033,72043]
===
match
---
name: property [19090,19098]
name: property [19090,19098]
===
match
---
param [73137,73146]
param [73189,73198]
===
match
---
trailer [71719,71729]
trailer [71771,71781]
===
match
---
trailer [80487,80494]
trailer [80539,80546]
===
match
---
operator: , [28967,28968]
operator: , [28967,28968]
===
match
---
trailer [11218,11223]
trailer [11218,11223]
===
match
---
name: self [50882,50886]
name: self [50934,50938]
===
match
---
operator: = [39527,39528]
operator: = [39527,39528]
===
match
---
operator: , [77767,77768]
operator: , [77819,77820]
===
match
---
name: signal_handler [48571,48585]
name: signal_handler [48623,48637]
===
match
---
simple_stmt [55373,55656]
simple_stmt [55425,55708]
===
match
---
decorator [28502,28512]
decorator [28502,28512]
===
match
---
trailer [39894,39900]
trailer [39894,39900]
===
match
---
suite [7820,7904]
suite [7820,7904]
===
match
---
name: state [2834,2839]
name: state [2834,2839]
===
match
---
trailer [52325,52341]
trailer [52377,52393]
===
match
---
name: update [70728,70734]
name: update [70780,70786]
===
match
---
trailer [24253,24260]
trailer [24253,24260]
===
match
---
parameters [81397,81403]
parameters [81449,81455]
===
match
---
name: self [45260,45264]
name: self [45312,45316]
===
match
---
operator: { [7649,7650]
operator: { [7649,7650]
===
match
---
simple_stmt [18800,18811]
simple_stmt [18800,18811]
===
match
---
trailer [43582,43587]
trailer [43634,43639]
===
match
---
term [37922,37930]
term [37922,37930]
===
match
---
funcdef [72776,73074]
funcdef [72828,73126]
===
match
---
simple_stmt [59401,59446]
simple_stmt [59453,59498]
===
match
---
simple_stmt [69412,69452]
simple_stmt [69464,69504]
===
match
---
operator: , [1039,1040]
operator: , [1039,1040]
===
match
---
name: default [9791,9798]
name: default [9791,9798]
===
match
---
fstring_string: / [19072,19073]
fstring_string: / [19072,19073]
===
match
---
trailer [50968,50970]
trailer [51020,51022]
===
match
---
dotted_name [1879,1897]
dotted_name [1879,1897]
===
match
---
operator: , [72653,72654]
operator: , [72705,72706]
===
match
---
simple_stmt [43480,43523]
simple_stmt [43532,43575]
===
match
---
operator: @ [8075,8076]
operator: @ [8075,8076]
===
match
---
name: session [45467,45474]
name: session [45519,45526]
===
match
---
trailer [30289,30300]
trailer [30289,30300]
===
match
---
arglist [39140,39161]
arglist [39140,39161]
===
match
---
if_stmt [41398,41536]
if_stmt [41367,41505]
===
match
---
operator: = [14141,14142]
operator: = [14141,14142]
===
match
---
name: Optional [78050,78058]
name: Optional [78102,78110]
===
match
---
operator: = [37912,37913]
operator: = [37912,37913]
===
match
---
name: ignore_all_deps [18188,18203]
name: ignore_all_deps [18188,18203]
===
match
---
atom_expr [65236,65249]
atom_expr [65288,65301]
===
match
---
operator: @ [59702,59703]
operator: @ [59754,59755]
===
match
---
trailer [66487,66526]
trailer [66539,66578]
===
match
---
return_stmt [81183,81200]
return_stmt [81235,81252]
===
match
---
name: end_date [55274,55282]
name: end_date [55326,55334]
===
match
---
name: self [13123,13127]
name: self [13123,13127]
===
match
---
trailer [19673,19680]
trailer [19673,19680]
===
match
---
expr_stmt [24601,24633]
expr_stmt [24601,24633]
===
match
---
name: airflow [2242,2249]
name: airflow [2242,2249]
===
match
---
funcdef [68182,69156]
funcdef [68234,69208]
===
match
---
name: timedelta [60756,60765]
name: timedelta [60808,60817]
===
match
---
name: provide_session [20560,20575]
name: provide_session [20560,20575]
===
match
---
raise_stmt [51023,51105]
raise_stmt [51075,51157]
===
match
---
operator: = [40342,40343]
operator: = [40342,40343]
===
match
---
name: state [53052,53057]
name: state [53104,53109]
===
match
---
operator: + [34788,34789]
operator: + [34788,34789]
===
match
---
name: extend [18690,18696]
name: extend [18690,18696]
===
match
---
trailer [64931,64939]
trailer [64983,64991]
===
match
---
name: self [80299,80303]
name: self [80351,80355]
===
match
---
atom_expr [62183,62212]
atom_expr [62235,62264]
===
match
---
name: _priority_weight [80338,80354]
name: _priority_weight [80390,80406]
===
match
---
arglist [27219,27273]
arglist [27219,27273]
===
match
---
trailer [56204,56209]
trailer [56256,56261]
===
match
---
simple_stmt [29225,29441]
simple_stmt [29225,29441]
===
match
---
name: log [29454,29457]
name: log [29454,29457]
===
match
---
name: t [78704,78705]
name: t [78756,78757]
===
match
---
name: mark_success [41123,41135]
name: mark_success [41092,41104]
===
match
---
trailer [60602,60617]
trailer [60654,60669]
===
match
---
name: mark_success [14990,15002]
name: mark_success [14990,15002]
===
match
---
simple_stmt [45543,45560]
simple_stmt [45595,45612]
===
match
---
trailer [47108,47113]
trailer [47160,47165]
===
match
---
suite [66463,66527]
suite [66515,66579]
===
match
---
name: dag [27291,27294]
name: dag [27291,27294]
===
match
---
suite [40881,40914]
suite [40850,40883]
===
match
---
simple_stmt [45599,45648]
simple_stmt [45651,45700]
===
match
---
trailer [69499,69513]
trailer [69551,69565]
===
match
---
trailer [29026,29034]
trailer [29026,29034]
===
match
---
trailer [73991,74169]
trailer [74043,74221]
===
match
---
name: pool [41754,41758]
name: pool [41723,41727]
===
match
---
atom_expr [10845,11022]
atom_expr [10845,11022]
===
match
---
name: task_type [56936,56945]
name: task_type [56988,56997]
===
match
---
expr_stmt [71440,71483]
expr_stmt [71492,71535]
===
match
---
import_name [787,804]
import_name [787,804]
===
match
---
name: info [50793,50797]
name: info [50845,50849]
===
match
---
simple_stmt [69135,69156]
simple_stmt [69187,69208]
===
match
---
name: error_fd [54707,54715]
name: error_fd [54759,54767]
===
match
---
name: provide_session [30882,30897]
name: provide_session [30882,30897]
===
match
---
trailer [31760,31764]
trailer [31760,31764]
===
match
---
fstring_string: DAGS_FOLDER/ [14687,14699]
fstring_string: DAGS_FOLDER/ [14687,14699]
===
match
---
name: Exception [52331,52340]
name: Exception [52383,52392]
===
match
---
simple_stmt [50882,50918]
simple_stmt [50934,50970]
===
match
---
atom_expr [19464,19502]
atom_expr [19464,19502]
===
match
---
decorated [28018,28497]
decorated [28018,28497]
===
match
---
simple_stmt [44151,44158]
simple_stmt [44203,44210]
===
match
---
operator: == [54669,54671]
operator: == [54721,54723]
===
match
---
name: self [40597,40601]
name: self [40597,40601]
===
match
---
name: session [42702,42709]
name: session [42671,42678]
===
match
---
operator: , [67461,67462]
operator: , [67513,67514]
===
match
---
trailer [77145,77154]
trailer [77197,77206]
===
match
---
trailer [41273,41278]
trailer [41242,41247]
===
match
---
name: log [3202,3205]
name: log [3202,3205]
===
match
---
arglist [59233,59305]
arglist [59285,59357]
===
match
---
operator: , [1344,1345]
operator: , [1344,1345]
===
match
---
name: log [40282,40285]
name: log [40282,40285]
===
match
---
expr_stmt [23323,23372]
expr_stmt [23323,23372]
===
match
---
operator: , [71098,71099]
operator: , [71150,71151]
===
match
---
name: dag_id [76411,76417]
name: dag_id [76463,76469]
===
match
---
name: dag_run [60449,60456]
name: dag_run [60501,60508]
===
match
---
and_test [59461,59516]
and_test [59513,59568]
===
match
---
expr_stmt [57916,57984]
expr_stmt [57968,58036]
===
match
---
name: RUNNING_DEPS [38176,38188]
name: RUNNING_DEPS [38176,38188]
===
match
---
trailer [42760,42769]
trailer [42729,42738]
===
match
---
trailer [81514,81531]
trailer [81566,81583]
===
match
---
string: """         Make an XCom available for tasks to pull.          :param key: A key for the XCom         :type key: str         :param value: A value for the XCom. The value is pickled and stored             in the database.         :type value: any picklable object         :param execution_date: if provided, the XCom will not be visible until             this date. This can be used, for example, to send a message to a             task on a future date without it being immediately visible.         :type execution_date: datetime         :param session: Sqlalchemy ORM Session         :type session: Session         """ [73274,73894]
string: """         Make an XCom available for tasks to pull.          :param key: A key for the XCom         :type key: str         :param value: A value for the XCom. The value is pickled and stored             in the database.         :type value: any picklable object         :param execution_date: if provided, the XCom will not be visible until             this date. This can be used, for example, to send a message to a             task on a future date without it being immediately visible.         :type execution_date: datetime         :param session: Sqlalchemy ORM Session         :type session: Session         """ [73326,73946]
===
match
---
name: dag_id [8220,8226]
name: dag_id [8220,8226]
===
match
---
name: property [19372,19380]
name: property [19372,19380]
===
match
---
trailer [23922,23930]
trailer [23922,23930]
===
match
---
name: self [22317,22321]
name: self [22317,22321]
===
match
---
param [63090,63094]
param [63142,63146]
===
match
---
name: execution_date [78834,78848]
name: execution_date [78886,78900]
===
match
---
trailer [3668,3676]
trailer [3668,3676]
===
match
---
parameters [62852,62858]
parameters [62904,62910]
===
match
---
return_stmt [34963,35053]
return_stmt [34963,35053]
===
match
---
import_as_names [2334,2364]
import_as_names [2334,2364]
===
match
---
sync_comp_for [78700,78712]
sync_comp_for [78752,78764]
===
match
---
trailer [14634,14648]
trailer [14634,14648]
===
match
---
name: task_id [5342,5349]
name: task_id [5342,5349]
===
match
---
operator: = [80500,80501]
operator: = [80552,80553]
===
match
---
trailer [50336,50338]
trailer [50388,50390]
===
match
---
fstring_expr [32979,33000]
fstring_expr [32979,33000]
===
match
---
if_stmt [7439,7904]
if_stmt [7439,7904]
===
match
---
atom [77133,77179]
atom [77185,77231]
===
match
---
name: session [60262,60269]
name: session [60314,60321]
===
match
---
operator: , [65557,65558]
operator: , [65609,65610]
===
match
---
simple_stmt [49939,50157]
simple_stmt [49991,50209]
===
match
---
trailer [52981,52983]
trailer [53033,53035]
===
match
---
trailer [70885,70896]
trailer [70937,70948]
===
match
---
atom_expr [44563,44573]
atom_expr [44615,44625]
===
match
---
name: executor_config [10255,10270]
name: executor_config [10255,10270]
===
match
---
argument [46164,46198]
argument [46216,46250]
===
match
---
name: state [37741,37746]
name: state [37741,37746]
===
match
---
atom_expr [79958,79971]
atom_expr [80010,80023]
===
match
---
name: execution_date [80747,80761]
name: execution_date [80799,80813]
===
match
---
operator: , [59078,59079]
operator: , [59130,59131]
===
match
---
trailer [26052,26059]
trailer [26052,26059]
===
match
---
name: self [41210,41214]
name: self [41179,41183]
===
match
---
atom_expr [11820,11855]
atom_expr [11820,11855]
===
match
---
trailer [33265,33277]
trailer [33265,33277]
===
match
---
operator: , [53694,53695]
operator: , [53746,53747]
===
match
---
operator: = [71240,71241]
operator: = [71292,71293]
===
match
---
name: DepContext [2277,2287]
name: DepContext [2277,2287]
===
match
---
simple_stmt [22317,22347]
simple_stmt [22317,22347]
===
match
---
fstring_expr [19630,19644]
fstring_expr [19630,19644]
===
match
---
name: self [40580,40584]
name: self [40580,40584]
===
match
---
if_stmt [27118,27182]
if_stmt [27118,27182]
===
match
---
trailer [17898,17900]
trailer [17898,17900]
===
match
---
atom_expr [9731,9741]
atom_expr [9731,9741]
===
match
---
name: task_retries [5456,5468]
name: task_retries [5456,5468]
===
match
---
name: conf [67875,67879]
name: conf [67927,67931]
===
match
---
trailer [31928,32112]
trailer [31928,32112]
===
match
---
name: ignore_depends_on_past [14119,14141]
name: ignore_depends_on_past [14119,14141]
===
match
---
name: self [8293,8297]
name: self [8293,8297]
===
match
---
atom_expr [80216,80242]
atom_expr [80268,80294]
===
match
---
operator: @ [74411,74412]
operator: @ [74463,74464]
===
match
---
atom_expr [74346,74365]
atom_expr [74398,74417]
===
match
---
name: query [23846,23851]
name: query [23846,23851]
===
match
---
simple_stmt [1260,1350]
simple_stmt [1260,1350]
===
match
---
param [22884,22889]
param [22884,22889]
===
match
---
name: max_tries [23430,23439]
name: max_tries [23430,23439]
===
match
---
name: job_id [10813,10819]
name: job_id [10813,10819]
===
match
---
name: refresh_from_db [43485,43500]
name: refresh_from_db [43537,43552]
===
match
---
operator: , [38419,38420]
operator: , [38419,38420]
===
match
---
number: 1 [10023,10024]
number: 1 [10023,10024]
===
match
---
name: self [64004,64008]
name: self [64056,64060]
===
match
---
name: Optional [15819,15827]
name: Optional [15819,15827]
===
match
---
atom_expr [3984,3995]
atom_expr [3984,3995]
===
match
---
trailer [22688,22700]
trailer [22688,22700]
===
match
---
name: Stats [44912,44917]
name: Stats [44964,44969]
===
match
---
trailer [24974,24985]
trailer [24974,24985]
===
match
---
argument [54169,54182]
argument [54221,54234]
===
match
---
name: cfg_path [15382,15390]
name: cfg_path [15382,15390]
===
match
---
operator: , [72437,72438]
operator: , [72489,72490]
===
match
---
decorator [19797,19814]
decorator [19797,19814]
===
match
---
not_test [37712,37731]
not_test [37712,37731]
===
match
---
operator: = [12106,12107]
operator: = [12106,12107]
===
match
---
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [69880,69924]
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [69932,69976]
===
match
---
trailer [34565,34569]
trailer [34565,34569]
===
match
---
operator: = [23529,23530]
operator: = [23529,23530]
===
match
---
operator: , [46258,46259]
operator: , [46310,46311]
===
match
---
name: drs [7552,7555]
name: drs [7552,7555]
===
match
---
atom_expr [41265,41332]
atom_expr [41234,41301]
===
match
---
operator: , [32217,32218]
operator: , [32217,32218]
===
match
---
name: params [67673,67679]
name: params [67725,67731]
===
match
---
trailer [14794,14808]
trailer [14794,14808]
===
match
---
atom_expr [22590,22610]
atom_expr [22590,22610]
===
match
---
fstring [14685,14714]
fstring [14685,14714]
===
match
---
name: sanitized_pod [69142,69155]
name: sanitized_pod [69194,69207]
===
match
---
fstring_expr [19351,19364]
fstring_expr [19351,19364]
===
match
---
name: session [1469,1476]
name: session [1469,1476]
===
match
---
name: k [49299,49300]
name: k [49351,49352]
===
match
---
funcdef [34801,35054]
funcdef [34801,35054]
===
match
---
operator: { [56930,56931]
operator: { [56982,56983]
===
match
---
atom_expr [38143,38434]
atom_expr [38143,38434]
===
match
---
name: session [40723,40730]
name: session [40723,40730]
===
match
---
name: SKIPPED [43554,43561]
name: SKIPPED [43606,43613]
===
match
---
trailer [25886,25891]
trailer [25886,25891]
===
match
---
name: pool [54513,54517]
name: pool [54565,54569]
===
match
---
trailer [6026,6045]
trailer [6026,6045]
===
match
---
name: total_seconds [72946,72959]
name: total_seconds [72998,73011]
===
match
---
name: in_ [78887,78890]
name: in_ [78939,78942]
===
match
---
name: t [79130,79131]
name: t [79182,79183]
===
match
---
trailer [60520,60527]
trailer [60572,60579]
===
match
---
name: get_previous_ti [29525,29540]
name: get_previous_ti [29525,29540]
===
match
---
name: deserialize_model_file [68954,68976]
name: deserialize_model_file [69006,69028]
===
match
---
name: get [77142,77145]
name: get [77194,77197]
===
match
---
name: func [25986,25990]
name: func [25986,25990]
===
match
---
operator: = [11818,11819]
operator: = [11818,11819]
===
match
---
trailer [6018,6025]
trailer [6018,6025]
===
match
---
name: self [14957,14961]
name: self [14957,14961]
===
match
---
atom_expr [10127,10147]
atom_expr [10127,10147]
===
match
---
name: execution_date [19475,19489]
name: execution_date [19475,19489]
===
match
---
operator: , [70848,70849]
operator: , [70900,70901]
===
match
---
operator: , [48062,48063]
operator: , [48114,48115]
===
match
---
atom_expr [23793,23829]
atom_expr [23793,23829]
===
match
---
simple_stmt [29449,29502]
simple_stmt [29449,29502]
===
match
---
name: self [57806,57810]
name: self [57858,57862]
===
match
---
argument [60335,60369]
argument [60387,60421]
===
match
---
name: UndefinedError [66642,66656]
name: UndefinedError [66694,66708]
===
match
---
arith_expr [34556,34589]
arith_expr [34556,34589]
===
match
---
operator: = [5007,5008]
operator: = [5007,5008]
===
match
---
param [77992,78045]
param [78044,78097]
===
match
---
name: airflow [2115,2122]
name: airflow [2115,2122]
===
match
---
operator: , [29736,29737]
operator: , [29736,29737]
===
match
---
name: task [41306,41310]
name: task [41275,41279]
===
match
---
argument [44281,44296]
argument [44333,44348]
===
match
---
name: state [20859,20864]
name: state [20859,20864]
===
match
---
name: _state [81126,81132]
name: _state [81178,81184]
===
match
---
operator: = [30860,30861]
operator: = [30860,30861]
===
match
---
suite [48079,50696]
suite [48131,50748]
===
match
---
trailer [68466,68473]
trailer [68518,68525]
===
match
---
suite [14822,14847]
suite [14822,14847]
===
match
---
suite [18742,18792]
suite [18742,18792]
===
match
---
atom [5009,5011]
atom [5009,5011]
===
match
---
if_stmt [26912,27275]
if_stmt [26912,27275]
===
match
---
operator: = [62040,62041]
operator: = [62092,62093]
===
match
---
suite [39074,39272]
suite [39074,39272]
===
match
---
expr_stmt [60539,60584]
expr_stmt [60591,60636]
===
match
---
expr_stmt [5500,5547]
expr_stmt [5500,5547]
===
match
---
atom [60733,60769]
atom [60785,60821]
===
match
---
trailer [43815,43833]
trailer [43867,43885]
===
match
---
trailer [5193,5199]
trailer [5193,5199]
===
match
---
trailer [50557,50589]
trailer [50609,50641]
===
match
---
string: '%Y-%m-%d' [60699,60709]
string: '%Y-%m-%d' [60751,60761]
===
match
---
name: self [81398,81402]
name: self [81450,81454]
===
match
---
name: job_id [9910,9916]
name: job_id [9910,9916]
===
match
---
param [35903,35927]
param [35903,35927]
===
match
---
name: ImportError [3084,3095]
name: ImportError [3084,3095]
===
match
---
simple_stmt [8145,8200]
simple_stmt [8145,8200]
===
match
---
decorated [80988,81063]
decorated [81040,81115]
===
match
---
operator: , [47367,47368]
operator: , [47419,47420]
===
match
---
name: session [7210,7217]
name: session [7210,7217]
===
match
---
name: self [31797,31801]
name: self [31797,31801]
===
match
---
string: """Only Renders Templates for the TI""" [54831,54870]
string: """Only Renders Templates for the TI""" [54883,54922]
===
match
---
atom_expr [53061,53079]
atom_expr [53113,53131]
===
match
---
name: self [22590,22594]
name: self [22590,22594]
===
match
---
argument [74201,74208]
argument [74253,74260]
===
match
---
name: task_id [77691,77698]
name: task_id [77743,77750]
===
match
---
expr_stmt [80299,80324]
expr_stmt [80351,80376]
===
match
---
name: info [46883,46887]
name: info [46935,46939]
===
match
---
name: task [5471,5475]
name: task [5471,5475]
===
match
---
name: self [37645,37649]
name: self [37645,37649]
===
match
---
expr_stmt [62280,62338]
expr_stmt [62332,62390]
===
match
---
trailer [60393,60395]
trailer [60445,60447]
===
match
---
name: Column [9493,9499]
name: Column [9493,9499]
===
match
---
name: self [59585,59589]
name: self [59637,59641]
===
match
---
name: var [64009,64012]
name: var [64061,64064]
===
match
---
trailer [7174,7181]
trailer [7174,7181]
===
match
---
name: non_requeueable_dep_context [38509,38536]
name: non_requeueable_dep_context [38509,38536]
===
match
---
suite [29216,29640]
suite [29216,29640]
===
match
---
name: passed [32848,32854]
name: passed [32848,32854]
===
match
---
trailer [21788,21790]
trailer [21788,21790]
===
match
---
operator: = [82654,82655]
operator: = [82706,82707]
===
match
---
name: Index [10533,10538]
name: Index [10533,10538]
===
match
---
suite [47317,47471]
suite [47369,47523]
===
match
---
funcdef [67061,67623]
funcdef [67113,67675]
===
match
---
trailer [54920,54942]
trailer [54972,54994]
===
match
---
atom_expr [5903,5926]
atom_expr [5903,5926]
===
match
---
expr_stmt [22644,22671]
expr_stmt [22644,22671]
===
match
---
string: 'Failed to send email to: %s' [58853,58882]
string: 'Failed to send email to: %s' [58905,58934]
===
match
---
name: error_fd [54551,54559]
name: error_fd [54603,54611]
===
match
---
atom_expr [79359,79369]
atom_expr [79411,79421]
===
match
---
operator: == [82096,82098]
operator: == [82148,82150]
===
match
---
trailer [71481,71483]
trailer [71533,71535]
===
match
---
operator: , [41744,41745]
operator: , [41713,41714]
===
match
---
atom_expr [10134,10146]
atom_expr [10134,10146]
===
match
---
name: dag_id [68547,68553]
name: dag_id [68599,68605]
===
match
---
trailer [68716,68732]
trailer [68768,68784]
===
match
---
arglist [32188,32223]
arglist [32188,32223]
===
match
---
param [67673,67680]
param [67725,67732]
===
match
---
trailer [48799,48816]
trailer [48851,48868]
===
match
---
name: task [11158,11162]
name: task [11158,11162]
===
match
---
trailer [54762,54785]
trailer [54814,54837]
===
match
---
parameters [29693,29767]
parameters [29693,29767]
===
match
---
trailer [56833,56842]
trailer [56885,56894]
===
match
---
testlist_comp [67439,67477]
testlist_comp [67491,67529]
===
match
---
decorated [63147,63475]
decorated [63199,63527]
===
match
---
name: isoformat [60618,60627]
name: isoformat [60670,60679]
===
match
---
simple_stmt [27033,27102]
simple_stmt [27033,27102]
===
match
---
name: self [22003,22007]
name: self [22003,22007]
===
match
---
trailer [14703,14712]
trailer [14703,14712]
===
match
---
operator: , [74365,74366]
operator: , [74417,74418]
===
match
---
name: ignore_depends_on_past [15144,15166]
name: ignore_depends_on_past [15144,15166]
===
match
---
atom_expr [41046,41071]
atom_expr [41015,41040]
===
match
---
name: Optional [30362,30370]
name: Optional [30362,30370]
===
match
---
trailer [76462,76683]
trailer [76514,76735]
===
match
---
name: convert_to_utc [11895,11909]
name: convert_to_utc [11895,11909]
===
match
---
arglist [34543,34589]
arglist [34543,34589]
===
match
---
name: Optional [68215,68223]
name: Optional [68267,68275]
===
match
---
name: error [56788,56793]
name: error [56840,56845]
===
match
---
trailer [39231,39242]
trailer [39231,39242]
===
match
---
name: task_id [5388,5395]
name: task_id [5388,5395]
===
match
---
name: COLLATION_ARGS [10358,10372]
name: COLLATION_ARGS [10358,10372]
===
match
---
fstring_end: " [19718,19719]
fstring_end: " [19718,19719]
===
match
---
name: deserialize_json [64449,64465]
name: deserialize_json [64501,64517]
===
match
---
simple_stmt [66251,66337]
simple_stmt [66303,66389]
===
match
---
operator: , [9513,9514]
operator: , [9513,9514]
===
match
---
name: instance [29607,29615]
name: instance [29607,29615]
===
match
---
name: task [52772,52776]
name: task [52824,52828]
===
match
---
simple_stmt [69523,69565]
simple_stmt [69575,69617]
===
match
---
operator: , [11051,11052]
operator: , [11051,11052]
===
match
---
arith_expr [8500,8519]
arith_expr [8500,8519]
===
match
---
trailer [35475,35490]
trailer [35475,35490]
===
match
---
name: frame [48316,48321]
name: frame [48368,48373]
===
match
---
name: state [44970,44975]
name: state [45022,45027]
===
match
---
name: self [12383,12387]
name: self [12383,12387]
===
match
---
trailer [71350,71362]
trailer [71402,71414]
===
match
---
comparison [44563,44606]
comparison [44615,44658]
===
match
---
name: self [70556,70560]
name: self [70608,70612]
===
match
---
atom_expr [37438,37447]
atom_expr [37438,37447]
===
match
---
name: Optional [26484,26492]
name: Optional [26484,26492]
===
match
---
parameters [48307,48322]
parameters [48359,48374]
===
match
---
atom_expr [27206,27274]
atom_expr [27206,27274]
===
match
---
name: dag [46849,46852]
name: dag [46901,46904]
===
match
---
expr_stmt [52587,52603]
expr_stmt [52639,52655]
===
match
---
name: exception_html [71602,71616]
name: exception_html [71654,71668]
===
match
---
name: get_previous_scheduled_dagrun [27731,27760]
name: get_previous_scheduled_dagrun [27731,27760]
===
match
---
name: execution_date [19186,19200]
name: execution_date [19186,19200]
===
match
---
operator: == [39047,39049]
operator: == [39047,39049]
===
match
---
trailer [8707,8715]
trailer [8707,8715]
===
match
---
name: TaskInstance [79098,79110]
name: TaskInstance [79150,79162]
===
match
---
name: self [81092,81096]
name: self [81144,81148]
===
match
---
atom_expr [26761,26774]
atom_expr [26761,26774]
===
match
---
argument [15225,15236]
argument [15225,15236]
===
match
---
trailer [7332,7338]
trailer [7332,7338]
===
match
---
name: date_attr [59543,59552]
name: date_attr [59595,59604]
===
match
---
expr_stmt [12314,12330]
expr_stmt [12314,12330]
===
match
---
fstring_start: f" [19032,19034]
fstring_start: f" [19032,19034]
===
match
---
trailer [41732,41737]
trailer [41701,41706]
===
match
---
name: start_date [21924,21934]
name: start_date [21924,21934]
===
match
---
name: ti [5870,5872]
name: ti [5870,5872]
===
match
---
trailer [71792,71797]
trailer [71844,71849]
===
match
---
name: dag_id [20259,20265]
name: dag_id [20259,20265]
===
match
---
trailer [47828,47833]
trailer [47880,47885]
===
match
---
name: self [8690,8694]
name: self [8690,8694]
===
match
---
name: signal [48555,48561]
name: signal [48607,48613]
===
match
---
name: pickle_id [14209,14218]
name: pickle_id [14209,14218]
===
match
---
name: task_id [24267,24274]
name: task_id [24267,24274]
===
match
---
operator: = [47185,47186]
operator: = [47237,47238]
===
match
---
trailer [79190,79198]
trailer [79242,79250]
===
match
---
tfpdef [56150,56166]
tfpdef [56202,56218]
===
match
---
tfpdef [15579,15597]
tfpdef [15579,15597]
===
match
---
simple_stmt [62096,62153]
simple_stmt [62148,62205]
===
match
---
name: key [51842,51845]
name: key [51894,51897]
===
match
---
name: execution_date [73947,73961]
name: execution_date [73999,74013]
===
match
---
name: execution_date [7700,7714]
name: execution_date [7700,7714]
===
match
---
atom [37921,37931]
atom [37921,37931]
===
match
---
funcdef [13841,13942]
funcdef [13841,13942]
===
match
---
name: UtcDateTime [9635,9646]
name: UtcDateTime [9635,9646]
===
match
---
arglist [34725,34757]
arglist [34725,34757]
===
match
---
expr_stmt [33588,33670]
expr_stmt [33588,33670]
===
match
---
number: 1 [34588,34589]
number: 1 [34588,34589]
===
match
---
name: str [62966,62969]
name: str [63018,63021]
===
match
---
name: mark_success [53597,53609]
name: mark_success [53649,53661]
===
match
---
name: dag_id [44941,44947]
name: dag_id [44993,44999]
===
match
---
name: dr [7833,7835]
name: dr [7833,7835]
===
match
---
name: try_number [6049,6059]
name: try_number [6049,6059]
===
match
---
name: property [80730,80738]
name: property [80782,80790]
===
match
---
simple_stmt [12009,12035]
simple_stmt [12009,12035]
===
match
---
atom_expr [57169,57182]
atom_expr [57221,57234]
===
match
---
trailer [30042,30076]
trailer [30042,30076]
===
match
---
tfpdef [3289,3305]
tfpdef [3289,3305]
===
match
---
name: utcnow [42825,42831]
name: utcnow [42877,42883]
===
match
---
name: use_default [69412,69423]
name: use_default [69464,69475]
===
match
---
name: open [71981,71985]
name: open [72033,72037]
===
match
---
operator: , [69195,69196]
operator: , [69247,69248]
===
match
---
name: property [80908,80916]
name: property [80960,80968]
===
match
---
name: session [40378,40385]
name: session [40378,40385]
===
match
---
name: query [21523,21528]
name: query [21523,21528]
===
match
---
name: state [43144,43149]
name: state [43196,43201]
===
match
---
argument [54219,54234]
argument [54271,54286]
===
match
---
name: first [78381,78386]
name: first [78433,78438]
===
match
---
trailer [46084,46094]
trailer [46136,46146]
===
match
---
expr_stmt [23515,23545]
expr_stmt [23515,23545]
===
match
---
atom_expr [61380,61428]
atom_expr [61432,61480]
===
match
---
name: staticmethod [64097,64109]
name: staticmethod [64149,64161]
===
match
---
trailer [68780,68789]
trailer [68832,68841]
===
match
---
operator: = [38545,38546]
operator: = [38545,38546]
===
match
---
return_stmt [27199,27274]
return_stmt [27199,27274]
===
match
---
name: TaskReschedule [1996,2010]
name: TaskReschedule [1996,2010]
===
match
---
operator: = [66281,66282]
operator: = [66333,66334]
===
match
---
name: task [49584,49588]
name: task [49636,49640]
===
match
---
name: construct_pod [68428,68441]
name: construct_pod [68480,68493]
===
match
---
simple_stmt [59213,59307]
simple_stmt [59265,59359]
===
match
---
trailer [33621,33635]
trailer [33621,33635]
===
match
---
operator: = [74386,74387]
operator: = [74438,74439]
===
match
---
trailer [78643,78650]
trailer [78695,78702]
===
match
---
trailer [32473,32478]
trailer [32473,32478]
===
match
---
name: task [65469,65473]
name: task [65521,65525]
===
match
---
trailer [56363,56373]
trailer [56415,56425]
===
match
---
trailer [58555,58586]
trailer [58607,58638]
===
match
---
arglist [66488,66525]
arglist [66540,66577]
===
match
---
operator: , [47918,47919]
operator: , [47970,47971]
===
match
---
name: attr [41455,41459]
name: attr [41424,41428]
===
match
---
trailer [23350,23372]
trailer [23350,23372]
===
match
---
name: res [54261,54264]
name: res [54313,54316]
===
match
---
simple_stmt [44333,44339]
simple_stmt [44385,44391]
===
match
---
trailer [24650,24656]
trailer [24650,24656]
===
match
---
name: self [59213,59217]
name: self [59265,59269]
===
match
---
funcdef [64026,64083]
funcdef [64078,64135]
===
match
---
name: ignore_task_deps [18270,18286]
name: ignore_task_deps [18270,18286]
===
match
---
trailer [14531,14536]
trailer [14531,14536]
===
match
---
if_stmt [18185,18259]
if_stmt [18185,18259]
===
match
---
name: dag_id [35438,35444]
name: dag_id [35438,35444]
===
match
---
return_stmt [13116,13139]
return_stmt [13116,13139]
===
match
---
operator: , [57055,57056]
operator: , [57107,57108]
===
match
---
name: yesterday_ds [65985,65997]
name: yesterday_ds [66037,66049]
===
match
---
name: contextmanager [3250,3264]
name: contextmanager [3250,3264]
===
match
---
name: execution_date [60603,60617]
name: execution_date [60655,60669]
===
match
---
atom_expr [15961,15974]
atom_expr [15961,15974]
===
match
---
name: default_var [64225,64236]
name: default_var [64277,64288]
===
match
---
trailer [47437,47446]
trailer [47489,47498]
===
match
---
name: self [44808,44812]
name: self [44860,44864]
===
match
---
name: get_template_context [68103,68123]
name: get_template_context [68155,68175]
===
match
---
simple_stmt [23281,23315]
simple_stmt [23281,23315]
===
match
---
trailer [73031,73073]
trailer [73083,73125]
===
match
---
operator: = [10843,10844]
operator: = [10843,10844]
===
match
---
name: task [62390,62394]
name: task [62442,62446]
===
match
---
trailer [12136,12138]
trailer [12136,12138]
===
match
---
name: date [41505,41509]
name: date [41474,41478]
===
match
---
fstring [19619,19645]
fstring [19619,19645]
===
match
---
operator: = [41666,41667]
operator: = [41635,41636]
===
match
---
name: self [30927,30931]
name: self [30927,30931]
===
match
---
name: ds [64595,64597]
name: ds [64647,64649]
===
match
---
name: _try_number [13810,13821]
name: _try_number [13810,13821]
===
match
---
name: str [16037,16040]
name: str [16037,16040]
===
match
---
argument [71653,71683]
argument [71705,71735]
===
match
---
atom_expr [20181,20436]
atom_expr [20181,20436]
===
match
---
operator: , [6622,6623]
operator: , [6622,6623]
===
match
---
trailer [7699,7714]
trailer [7699,7714]
===
match
---
operator: = [38402,38403]
operator: = [38402,38403]
===
match
---
operator: = [76418,76419]
operator: = [76470,76471]
===
match
---
operator: * [33638,33639]
operator: * [33638,33639]
===
match
---
simple_stmt [54984,55008]
simple_stmt [55036,55060]
===
match
---
comp_if [47086,47133]
comp_if [47138,47185]
===
match
---
name: schedulable_tis [47301,47316]
name: schedulable_tis [47353,47368]
===
match
---
trailer [40329,40341]
trailer [40329,40341]
===
match
---
trailer [10241,10250]
trailer [10241,10250]
===
match
---
trailer [58290,58294]
trailer [58342,58346]
===
match
---
trailer [24038,24045]
trailer [24038,24045]
===
match
---
name: String [9731,9737]
name: String [9731,9737]
===
match
---
atom_expr [24833,24843]
atom_expr [24833,24843]
===
match
---
name: XCom [23960,23964]
name: XCom [23960,23964]
===
match
---
string: "TaskInstance" [78012,78026]
string: "TaskInstance" [78064,78078]
===
match
---
sync_comp_for [7660,7673]
sync_comp_for [7660,7673]
===
match
---
simple_stmt [20520,20533]
simple_stmt [20520,20533]
===
match
---
parameters [34820,34826]
parameters [34820,34826]
===
match
---
name: following_schedule [61389,61407]
name: following_schedule [61441,61459]
===
match
---
argument [59290,59305]
argument [59342,59357]
===
match
---
comp_op [47236,47242]
comp_op [47288,47294]
===
match
---
name: try_number [71669,71679]
name: try_number [71721,71731]
===
match
---
name: timer [48702,48707]
name: timer [48754,48759]
===
match
---
simple_stmt [5456,5484]
simple_stmt [5456,5484]
===
match
---
atom [60244,60409]
atom [60296,60461]
===
match
---
name: dag_run [67681,67688]
name: dag_run [67733,67740]
===
match
---
try_stmt [2896,3118]
try_stmt [2896,3118]
===
match
---
name: next_retry_datetime [35012,35031]
name: next_retry_datetime [35012,35031]
===
match
---
decorated [55041,56002]
decorated [55093,56054]
===
match
---
arglist [37788,37816]
arglist [37788,37816]
===
match
---
trailer [40293,40308]
trailer [40293,40308]
===
match
---
trailer [18583,18601]
trailer [18583,18601]
===
match
---
operator: = [47948,47949]
operator: = [48000,48001]
===
match
---
atom_expr [65148,65264]
atom_expr [65200,65316]
===
match
---
name: ignore_depends_on_past [38323,38345]
name: ignore_depends_on_past [38323,38345]
===
match
---
name: utcnow [35045,35051]
name: utcnow [35045,35051]
===
match
---
param [12625,12629]
param [12625,12629]
===
match
---
name: Context [3139,3146]
name: Context [3139,3146]
===
match
---
name: __name__ [3226,3234]
name: __name__ [3226,3234]
===
match
---
name: self [13861,13865]
name: self [13861,13865]
===
match
---
funcdef [32271,32893]
funcdef [32271,32893]
===
match
---
simple_stmt [40378,40398]
simple_stmt [40378,40398]
===
match
---
suite [45856,48008]
suite [45908,48060]
===
match
---
name: self [11745,11749]
name: self [11745,11749]
===
match
---
atom_expr [22056,22064]
atom_expr [22056,22064]
===
match
---
simple_stmt [55269,55303]
simple_stmt [55321,55355]
===
match
---
expr_stmt [19169,19213]
expr_stmt [19169,19213]
===
match
---
name: Stats [56963,56968]
name: Stats [57015,57020]
===
match
---
name: pool [23239,23243]
name: pool [23239,23243]
===
match
---
name: value [77278,77283]
name: value [77330,77335]
===
match
---
name: jinja_context [71398,71411]
name: jinja_context [71450,71463]
===
match
---
atom [18396,18424]
atom [18396,18424]
===
match
---
operator: = [14789,14790]
operator: = [14789,14790]
===
match
---
trailer [53051,53057]
trailer [53103,53109]
===
match
---
name: task [54879,54883]
name: task [54931,54935]
===
match
---
atom_expr [51029,51105]
atom_expr [51081,51157]
===
match
---
decorated [35547,41353]
decorated [35547,41322]
===
match
---
atom_expr [63928,63936]
atom_expr [63980,63988]
===
match
---
trailer [52960,52981]
trailer [53012,53033]
===
match
---
name: str [15472,15475]
name: str [15472,15475]
===
match
---
atom_expr [57806,57833]
atom_expr [57858,57885]
===
match
---
atom_expr [7162,7201]
atom_expr [7162,7201]
===
match
---
name: task [42865,42869]
name: task [42917,42921]
===
match
---
argument [76545,76559]
argument [76597,76611]
===
match
---
name: instance [61675,61683]
name: instance [61727,61735]
===
match
---
name: bool [53575,53579]
name: bool [53627,53631]
===
match
---
trailer [61832,61841]
trailer [61884,61893]
===
match
---
simple_stmt [81114,81133]
simple_stmt [81166,81185]
===
match
---
name: get_task [47438,47446]
name: get_task [47490,47498]
===
match
---
operator: = [55156,55157]
operator: = [55208,55209]
===
match
---
tfpdef [74519,74564]
tfpdef [74571,74616]
===
match
---
name: self [22644,22648]
name: self [22644,22648]
===
match
---
arglist [23878,24003]
arglist [23878,24003]
===
match
---
atom_expr [80092,80100]
atom_expr [80144,80152]
===
match
---
operator: = [40780,40781]
operator: = [40780,40781]
===
match
---
trailer [44917,44922]
trailer [44969,44974]
===
match
---
name: extend [18389,18395]
name: extend [18389,18395]
===
match
---
operator: = [10164,10165]
operator: = [10164,10165]
===
match
---
simple_stmt [19872,20154]
simple_stmt [19872,20154]
===
match
---
trailer [52105,52125]
trailer [52157,52177]
===
match
---
simple_stmt [67501,67590]
simple_stmt [67553,67642]
===
match
---
name: query [25980,25985]
name: query [25980,25985]
===
match
---
tfpdef [53518,53540]
tfpdef [53570,53592]
===
match
---
operator: = [35958,35959]
operator: = [35958,35959]
===
match
---
atom_expr [24937,24950]
atom_expr [24937,24950]
===
match
---
trailer [32530,32558]
trailer [32530,32558]
===
match
---
name: default_html_content_err [71363,71387]
name: default_html_content_err [71415,71439]
===
match
---
expr_stmt [4001,4017]
expr_stmt [4001,4017]
===
match
---
trailer [25024,25030]
trailer [25024,25030]
===
match
---
name: _safe_date [58481,58491]
name: _safe_date [58533,58543]
===
match
---
comparison [6603,6622]
comparison [6603,6622]
===
match
---
atom_expr [82207,82227]
atom_expr [82259,82279]
===
match
---
expr_stmt [61714,61728]
expr_stmt [61766,61780]
===
match
---
string: """Get Airflow Variable after deserializing JSON value""" [64324,64381]
string: """Get Airflow Variable after deserializing JSON value""" [64376,64433]
===
match
---
operator: = [70880,70881]
operator: = [70932,70933]
===
match
---
param [48058,48063]
param [48110,48115]
===
match
---
atom_expr [62311,62323]
atom_expr [62363,62375]
===
match
---
if_stmt [32830,32893]
if_stmt [32830,32893]
===
match
---
name: get [63022,63025]
name: get [63074,63077]
===
match
---
atom_expr [50954,50970]
atom_expr [51006,51022]
===
match
---
operator: { [19058,19059]
operator: { [19058,19059]
===
match
---
name: lazy_object_proxy [65148,65165]
name: lazy_object_proxy [65200,65217]
===
match
---
atom_expr [21441,21499]
atom_expr [21441,21499]
===
match
---
name: pickler [10291,10298]
name: pickler [10291,10298]
===
match
---
name: kube_config [68881,68892]
name: kube_config [68933,68944]
===
match
---
operator: , [8551,8552]
operator: , [8551,8552]
===
match
---
trailer [62382,62389]
trailer [62434,62441]
===
match
---
name: conditions [6551,6561]
name: conditions [6551,6561]
===
match
---
name: state [25275,25280]
name: state [25275,25280]
===
match
---
simple_stmt [22684,22718]
simple_stmt [22684,22718]
===
match
---
name: Column [10273,10279]
name: Column [10273,10279]
===
match
---
tfpdef [15700,15722]
tfpdef [15700,15722]
===
match
---
name: skippable_task_ids [47243,47261]
name: skippable_task_ids [47295,47313]
===
match
---
string: """         Checks whether the immediate dependents of this task instance have succeeded or have been skipped.         This is meant to be used by wait_for_downstream.          This is useful when you do not want to start processing the next         schedule of a task until the dependents are done. For instance,         if the task DROPs and recreates a table.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [25413,25866]
string: """         Checks whether the immediate dependents of this task instance have succeeded or have been skipped.         This is meant to be used by wait_for_downstream.          This is useful when you do not want to start processing the next         schedule of a task until the dependents are done. For instance,         if the task DROPs and recreates a table.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [25413,25866]
===
match
---
param [81586,81591]
param [81638,81643]
===
match
---
operator: { [44577,44578]
operator: { [44629,44630]
===
match
---
operator: , [45344,45345]
operator: , [45396,45397]
===
match
---
trailer [7379,7383]
trailer [7379,7383]
===
match
---
atom_expr [27931,27991]
atom_expr [27931,27991]
===
match
---
fstring [42853,42893]
fstring [42905,42945]
===
match
---
trailer [60563,60572]
trailer [60615,60624]
===
match
---
atom_expr [23234,23243]
atom_expr [23234,23243]
===
match
---
atom [44577,44606]
atom [44629,44658]
===
match
---
name: dag [14700,14703]
name: dag [14700,14703]
===
match
---
operator: -> [81098,81100]
operator: -> [81150,81152]
===
match
---
name: airflow [67160,67167]
name: airflow [67212,67219]
===
match
---
name: execution_date [18913,18927]
name: execution_date [18913,18927]
===
match
---
trailer [56968,56973]
trailer [57020,57025]
===
match
---
trailer [3612,3614]
trailer [3612,3614]
===
match
---
trailer [20430,20434]
trailer [20430,20434]
===
match
---
param [15917,15946]
param [15917,15946]
===
match
---
operator: } [77095,77096]
operator: } [77147,77148]
===
match
---
expr_stmt [53231,53259]
expr_stmt [53283,53311]
===
match
---
operator: = [28445,28446]
operator: = [28445,28446]
===
match
---
trailer [52566,52573]
trailer [52618,52625]
===
match
---
simple_stmt [9716,9743]
simple_stmt [9716,9743]
===
match
---
name: warnings [28211,28219]
name: warnings [28211,28219]
===
match
---
name: dag [27297,27300]
name: dag [27297,27300]
===
match
---
trailer [56860,56862]
trailer [56912,56914]
===
match
---
operator: = [10961,10962]
operator: = [10961,10962]
===
match
---
name: self [21919,21923]
name: self [21919,21923]
===
match
---
name: state [29117,29122]
name: state [29117,29122]
===
match
---
name: TaskInstance [82076,82088]
name: TaskInstance [82128,82140]
===
match
---
operator: { [19034,19035]
operator: { [19034,19035]
===
match
---
trailer [6015,6026]
trailer [6015,6026]
===
match
---
operator: , [49147,49148]
operator: , [49199,49200]
===
match
---
trailer [10133,10147]
trailer [10133,10147]
===
match
---
decorated [59702,66065]
decorated [59754,66117]
===
match
---
sync_comp_for [78995,79007]
sync_comp_for [79047,79059]
===
match
---
atom_expr [35036,35053]
atom_expr [35036,35053]
===
match
---
name: self [72849,72853]
name: self [72901,72905]
===
match
---
name: log [55937,55940]
name: log [55989,55992]
===
match
---
suite [58715,58756]
suite [58767,58808]
===
match
---
operator: , [15297,15298]
operator: , [15297,15298]
===
match
---
arglist [6603,7059]
arglist [6603,7059]
===
match
---
operator: , [10968,10969]
operator: , [10968,10969]
===
match
---
simple_stmt [61461,61483]
simple_stmt [61513,61535]
===
match
---
name: pod [68409,68412]
name: pod [68461,68464]
===
match
---
trailer [6793,6848]
trailer [6793,6848]
===
match
---
expr_stmt [24879,24924]
expr_stmt [24879,24924]
===
match
---
name: run [53338,53341]
name: run [53390,53393]
===
match
---
trailer [3513,3522]
trailer [3513,3522]
===
match
---
operator: , [1726,1727]
operator: , [1726,1727]
===
match
---
parameters [35611,36029]
parameters [35611,36029]
===
match
---
atom_expr [48371,48432]
atom_expr [48423,48484]
===
match
---
name: self [35007,35011]
name: self [35007,35011]
===
match
---
dictorsetmaker [7720,7751]
dictorsetmaker [7720,7751]
===
match
---
operator: , [58568,58569]
operator: , [58620,58621]
===
match
---
name: bool [53644,53648]
name: bool [53696,53700]
===
match
---
name: partial_dag [46855,46866]
name: partial_dag [46907,46918]
===
match
---
name: Optional [11086,11094]
name: Optional [11086,11094]
===
match
---
name: TR [6695,6697]
name: TR [6695,6697]
===
match
---
simple_stmt [42756,42787]
simple_stmt [42725,42756]
===
match
---
name: XCom [23878,23882]
name: XCom [23878,23882]
===
match
---
expr_stmt [20854,20879]
expr_stmt [20854,20879]
===
match
---
simple_stmt [14678,14715]
simple_stmt [14678,14715]
===
match
---
name: timezone [24616,24624]
name: timezone [24616,24624]
===
match
---
name: rendered_k8s_spec [67605,67622]
name: rendered_k8s_spec [67657,67674]
===
match
---
dotted_name [82538,82559]
dotted_name [82590,82611]
===
match
---
name: pod_override_object [68748,68767]
name: pod_override_object [68800,68819]
===
match
---
name: pool [54196,54200]
name: pool [54248,54252]
===
match
---
operator: , [8491,8492]
operator: , [8491,8492]
===
match
---
or_test [31644,31671]
or_test [31644,31671]
===
match
---
atom_expr [78426,78439]
atom_expr [78478,78491]
===
match
---
operator: = [61881,61882]
operator: = [61933,61934]
===
match
---
trailer [56875,56888]
trailer [56927,56940]
===
match
---
return_stmt [63997,64012]
return_stmt [64049,64064]
===
match
---
name: self [39227,39231]
name: self [39227,39231]
===
match
---
simple_stmt [2815,2853]
simple_stmt [2815,2853]
===
match
---
trailer [57865,57872]
trailer [57917,57924]
===
match
---
suite [59204,59356]
suite [59256,59408]
===
match
---
name: self [45483,45487]
name: self [45535,45539]
===
match
---
decorated [58985,59356]
decorated [59037,59408]
===
match
---
name: Optional [59111,59119]
name: Optional [59163,59171]
===
match
---
parameters [4658,4725]
parameters [4658,4725]
===
match
---
number: 2 [33641,33642]
number: 2 [33641,33642]
===
match
---
decorator [32250,32267]
decorator [32250,32267]
===
match
---
simple_stmt [50847,50874]
simple_stmt [50899,50926]
===
match
---
funcdef [81002,81063]
funcdef [81054,81115]
===
match
---
and_test [27653,27696]
and_test [27653,27696]
===
match
---
trailer [71517,71762]
trailer [71569,71814]
===
match
---
name: self [23463,23467]
name: self [23463,23467]
===
match
---
name: key [74205,74208]
name: key [74257,74260]
===
match
---
name: self [19669,19673]
name: self [19669,19673]
===
match
---
trailer [43539,43545]
trailer [43591,43597]
===
match
---
trailer [82407,82437]
trailer [82459,82489]
===
match
---
simple_stmt [69067,69127]
simple_stmt [69119,69179]
===
match
---
atom_expr [77732,77750]
atom_expr [77784,77802]
===
match
---
simple_stmt [27569,27638]
simple_stmt [27569,27638]
===
match
---
name: math [842,846]
name: math [842,846]
===
match
---
name: params [62376,62382]
name: params [62428,62434]
===
match
---
decorator [41559,41576]
decorator [41528,41545]
===
match
---
operator: , [1060,1061]
operator: , [1060,1061]
===
match
---
atom_expr [34556,34585]
atom_expr [34556,34585]
===
match
---
name: _try_number [13160,13171]
name: _try_number [13160,13171]
===
match
---
operator: = [60003,60004]
operator: = [60055,60056]
===
match
---
trailer [78386,78401]
trailer [78438,78453]
===
match
---
name: session [82028,82035]
name: session [82080,82087]
===
match
---
operator: = [65388,65389]
operator: = [65440,65441]
===
match
---
name: get_template_context [52961,52981]
name: get_template_context [53013,53033]
===
match
---
decorator [80583,80593]
decorator [80635,80645]
===
match
---
suite [51633,51690]
suite [51685,51742]
===
match
---
trailer [40629,40633]
trailer [40629,40633]
===
match
---
if_stmt [27650,27879]
if_stmt [27650,27879]
===
match
---
atom_expr [18217,18258]
atom_expr [18217,18258]
===
match
---
name: exception [69481,69490]
name: exception [69533,69542]
===
match
---
arglist [72149,72184]
arglist [72201,72236]
===
match
---
name: signal_handler [48293,48307]
name: signal_handler [48345,48359]
===
match
---
name: get_dep_statuses [32514,32530]
name: get_dep_statuses [32514,32530]
===
match
---
expr_stmt [80073,80100]
expr_stmt [80125,80152]
===
match
---
name: property [81455,81463]
name: property [81507,81515]
===
match
---
dotted_name [2293,2326]
dotted_name [2293,2326]
===
match
---
name: filter_by [46085,46094]
name: filter_by [46137,46146]
===
match
---
name: AirflowRescheduleException [1700,1726]
name: AirflowRescheduleException [1700,1726]
===
match
---
name: self [41312,41316]
name: self [41281,41285]
===
match
---
trailer [28478,28494]
trailer [28478,28494]
===
match
---
argument [74247,74267]
argument [74299,74319]
===
match
---
trailer [65938,65940]
trailer [65990,65992]
===
match
---
simple_stmt [62280,62339]
simple_stmt [62332,62391]
===
match
---
dotted_name [2595,2625]
dotted_name [2595,2625]
===
match
---
atom_expr [23463,23483]
atom_expr [23463,23483]
===
match
---
operator: , [44686,44687]
operator: , [44738,44739]
===
match
---
name: State [13089,13094]
name: State [13089,13094]
===
match
---
trailer [40773,40779]
trailer [40773,40779]
===
match
---
name: UP_FOR_RETRY [24853,24865]
name: UP_FOR_RETRY [24853,24865]
===
match
---
atom [64488,66064]
atom [64540,66116]
===
match
---
operator: = [56357,56358]
operator: = [56409,56410]
===
match
---
argument [51506,51521]
argument [51558,51573]
===
match
---
atom_expr [62242,62270]
atom_expr [62294,62322]
===
match
---
name: task_copy [55016,55025]
name: task_copy [55068,55077]
===
match
---
name: dep_context [31826,31837]
name: dep_context [31826,31837]
===
match
---
atom_expr [7693,7753]
atom_expr [7693,7753]
===
match
---
name: test_mode [58912,58921]
name: test_mode [58964,58973]
===
match
---
name: log_message [58181,58192]
name: log_message [58233,58244]
===
match
---
name: SUCCESS [65242,65249]
name: SUCCESS [65294,65301]
===
match
---
name: pid [40809,40812]
name: pid [42769,42772]
===
match
---
trailer [14910,14917]
trailer [14910,14917]
===
match
---
name: job_id [14252,14258]
name: job_id [14252,14258]
===
match
---
operator: , [48993,48994]
operator: , [49045,49046]
===
match
---
operator: -> [78047,78049]
operator: -> [78099,78101]
===
match
---
suite [43434,43468]
suite [43486,43520]
===
match
---
operator: , [62147,62148]
operator: , [62199,62200]
===
match
---
trailer [43906,43921]
trailer [43958,43973]
===
match
---
operator: , [74208,74209]
operator: , [74260,74261]
===
match
---
name: REQUEUEABLE_DEPS [2334,2350]
name: REQUEUEABLE_DEPS [2334,2350]
===
match
---
expr_stmt [60422,60466]
expr_stmt [60474,60518]
===
match
---
simple_stmt [80256,80291]
simple_stmt [80308,80343]
===
match
---
name: session [29738,29745]
name: session [29738,29745]
===
match
---
operator: = [79584,79585]
operator: = [79636,79637]
===
match
---
trailer [82188,82203]
trailer [82240,82255]
===
match
---
atom_expr [22525,22538]
atom_expr [22525,22538]
===
match
---
name: state [13080,13085]
name: state [13080,13085]
===
match
---
expr_stmt [23463,23506]
expr_stmt [23463,23506]
===
match
---
string: "Task failed with exception" [56473,56501]
string: "Task failed with exception" [56525,56553]
===
match
---
name: registered [49788,49798]
name: registered [49840,49850]
===
match
---
name: error [58749,58754]
name: error [58801,58806]
===
match
---
operator: , [8124,8125]
operator: , [8124,8125]
===
match
---
atom_expr [41199,41208]
atom_expr [41168,41177]
===
match
---
trailer [32585,32591]
trailer [32585,32591]
===
match
---
operator: , [51952,51953]
operator: , [52004,52005]
===
match
---
name: execution_date [11840,11854]
name: execution_date [11840,11854]
===
match
---
string: '' [62132,62134]
string: '' [62184,62186]
===
match
---
operator: = [70547,70548]
operator: = [70599,70600]
===
match
---
simple_stmt [44738,44744]
simple_stmt [44790,44796]
===
match
---
name: run_id [60422,60428]
name: run_id [60474,60480]
===
match
---
name: dag_id [43742,43748]
name: dag_id [43794,43800]
===
match
---
return_stmt [81272,81300]
return_stmt [81324,81352]
===
match
---
simple_stmt [1909,1954]
simple_stmt [1909,1954]
===
match
---
atom_expr [65197,65250]
atom_expr [65249,65302]
===
match
---
trailer [67416,67418]
trailer [67468,67470]
===
match
---
name: mark_success [54402,54414]
name: mark_success [54454,54466]
===
match
---
argument [54445,54464]
argument [54497,54516]
===
match
---
operator: , [45220,45221]
operator: , [45272,45273]
===
match
---
atom_expr [76420,76431]
atom_expr [76472,76483]
===
match
---
atom_expr [42624,42672]
atom_expr [42593,42641]
===
match
---
operator: == [35430,35432]
operator: == [35430,35432]
===
match
---
name: context [50558,50565]
name: context [50610,50617]
===
match
---
except_clause [49869,49885]
except_clause [49921,49937]
===
match
---
trailer [55886,55892]
trailer [55938,55944]
===
match
---
operator: , [1312,1313]
operator: , [1312,1313]
===
match
---
name: session [27983,27990]
name: session [27983,27990]
===
match
---
return_stmt [4043,4054]
return_stmt [4043,4054]
===
match
---
name: warning [11486,11493]
name: warning [11486,11493]
===
match
---
trailer [24248,24313]
trailer [24248,24313]
===
match
---
name: task [47417,47421]
name: task [47469,47473]
===
match
---
atom_expr [71341,71412]
atom_expr [71393,71464]
===
match
---
name: self [33003,33007]
name: self [33003,33007]
===
match
---
name: ignore_all_deps [53901,53916]
name: ignore_all_deps [53953,53968]
===
match
---
suite [80419,80475]
suite [80471,80527]
===
match
---
trailer [19210,19212]
trailer [19210,19212]
===
match
---
name: timezone [11426,11434]
name: timezone [11426,11434]
===
match
---
operator: , [69007,69008]
operator: , [69059,69060]
===
match
---
suite [79009,79231]
suite [79061,79283]
===
match
---
trailer [26492,26508]
trailer [26492,26508]
===
match
---
name: max [8493,8496]
name: max [8493,8496]
===
match
---
expr_stmt [66251,66336]
expr_stmt [66303,66388]
===
match
---
trailer [22594,22610]
trailer [22594,22610]
===
match
---
name: ignore_task_deps [35788,35804]
name: ignore_task_deps [35788,35804]
===
match
---
trailer [47561,47629]
trailer [47613,47681]
===
match
---
simple_stmt [50434,50482]
simple_stmt [50486,50534]
===
match
---
name: enrich_errors [45682,45695]
name: enrich_errors [45734,45747]
===
match
---
trailer [46183,46198]
trailer [46235,46250]
===
match
---
simple_stmt [23838,24023]
simple_stmt [23838,24023]
===
match
---
atom_expr [3973,3996]
atom_expr [3973,3996]
===
match
---
trailer [28224,28458]
trailer [28224,28458]
===
match
---
string: 'schedule_after_task_execution' [45808,45839]
string: 'schedule_after_task_execution' [45860,45891]
===
match
---
suite [5351,5548]
suite [5351,5548]
===
match
---
string: """Filepath for TaskInstance""" [18862,18893]
string: """Filepath for TaskInstance""" [18862,18893]
===
match
---
name: self [31756,31760]
name: self [31756,31760]
===
match
---
arglist [67808,67879]
arglist [67860,67931]
===
match
---
trailer [78815,78830]
trailer [78867,78882]
===
match
---
name: pickle [4079,4085]
name: pickle [4079,4085]
===
match
---
name: bool [35766,35770]
name: bool [35766,35770]
===
match
---
name: ti [80456,80458]
name: ti [80508,80510]
===
match
---
name: next_execution_date [61494,61513]
name: next_execution_date [61546,61565]
===
match
---
simple_stmt [33248,33278]
simple_stmt [33248,33278]
===
match
---
name: kubernetes [3032,3042]
name: kubernetes [3032,3042]
===
match
---
trailer [32423,32425]
trailer [32423,32425]
===
match
---
atom_expr [78866,78914]
atom_expr [78918,78966]
===
match
---
name: fd [4405,4407]
name: fd [4405,4407]
===
match
---
name: task [52872,52876]
name: task [52924,52928]
===
match
---
trailer [78431,78439]
trailer [78483,78491]
===
match
---
name: on_execute_callback [52106,52125]
name: on_execute_callback [52158,52177]
===
match
---
name: self [34725,34729]
name: self [34725,34729]
===
match
---
suite [4373,4409]
suite [4373,4409]
===
match
---
name: task_ids [74519,74527]
name: task_ids [74571,74579]
===
match
---
atom_expr [81439,81448]
atom_expr [81491,81500]
===
match
---
name: api_client [2928,2938]
name: api_client [2928,2938]
===
match
---
atom_expr [66574,66597]
atom_expr [66626,66649]
===
match
---
decorated [3238,3848]
decorated [3238,3848]
===
match
---
operator: , [59052,59053]
operator: , [59104,59105]
===
match
---
trailer [37517,37527]
trailer [37517,37527]
===
match
---
trailer [72726,72770]
trailer [72778,72822]
===
match
---
name: timezone [39003,39011]
name: timezone [39003,39011]
===
match
---
trailer [46281,46283]
trailer [46333,46335]
===
match
---
parameters [63089,63095]
parameters [63141,63147]
===
match
---
simple_stmt [871,885]
simple_stmt [871,885]
===
match
---
trailer [10638,10657]
trailer [10638,10657]
===
match
---
operator: , [44829,44830]
operator: , [44881,44882]
===
match
---
operator: = [53688,53689]
operator: = [53740,53741]
===
match
---
name: self [81121,81125]
name: self [81173,81177]
===
match
---
name: upper [82429,82434]
name: upper [82481,82486]
===
match
---
atom_expr [14753,14770]
atom_expr [14753,14770]
===
match
---
atom_expr [45016,45029]
atom_expr [45068,45081]
===
match
---
atom_expr [52205,52265]
atom_expr [52257,52317]
===
match
---
name: start_date [24745,24755]
name: start_date [24745,24755]
===
match
---
arglist [44087,44137]
arglist [44139,44189]
===
match
---
suite [8320,8522]
suite [8320,8522]
===
match
---
simple_stmt [30819,30876]
simple_stmt [30819,30876]
===
match
---
suite [55240,55260]
suite [55292,55312]
===
match
---
and_test [25270,25333]
and_test [25270,25333]
===
match
---
simple_stmt [28467,28497]
simple_stmt [28467,28497]
===
match
---
funcdef [63173,63475]
funcdef [63225,63527]
===
match
---
simple_stmt [50303,50339]
simple_stmt [50355,50391]
===
match
---
simple_stmt [80703,80724]
simple_stmt [80755,80776]
===
match
---
param [8293,8297]
param [8293,8297]
===
match
---
and_test [58667,58697]
and_test [58719,58749]
===
match
---
param [73226,73250]
param [73278,73302]
===
match
---
string: 'conf' [64502,64508]
string: 'conf' [64554,64560]
===
match
---
name: schedulable_ti [47402,47416]
name: schedulable_ti [47454,47468]
===
match
---
name: utcnow [7895,7901]
name: utcnow [7895,7901]
===
match
---
name: log [45063,45066]
name: log [45115,45118]
===
match
---
atom_expr [62296,62307]
atom_expr [62348,62359]
===
match
---
simple_stmt [11692,11769]
simple_stmt [11692,11769]
===
match
---
name: first [82307,82312]
name: first [82359,82364]
===
match
---
suite [30980,32245]
suite [30980,32245]
===
match
---
name: self [68135,68139]
name: self [68187,68191]
===
match
---
name: priority_weight [23328,23343]
name: priority_weight [23328,23343]
===
match
---
name: deserialize_value [76981,76998]
name: deserialize_value [77033,77050]
===
match
---
atom_expr [34539,34590]
atom_expr [34539,34590]
===
match
---
name: task [48073,48077]
name: task [48125,48129]
===
match
---
trailer [25985,26019]
trailer [25985,26019]
===
match
---
atom_expr [41401,41420]
atom_expr [41370,41389]
===
match
---
name: XCom [76449,76453]
name: XCom [76501,76505]
===
match
---
atom_expr [40625,40653]
atom_expr [40625,40653]
===
match
---
expr_stmt [20474,20493]
expr_stmt [20474,20493]
===
match
---
parameters [63180,63357]
parameters [63232,63409]
===
match
---
name: ti [79308,79310]
name: ti [79360,79362]
===
match
---
name: state [5943,5948]
name: state [5943,5948]
===
match
---
name: email [72737,72742]
name: email [72789,72794]
===
match
---
operator: , [53752,53753]
operator: , [53804,53805]
===
match
---
name: UP_FOR_RESCHEDULE [55704,55721]
name: UP_FOR_RESCHEDULE [55756,55773]
===
match
---
name: content [72086,72093]
name: content [72138,72145]
===
match
---
expr_stmt [49728,49746]
expr_stmt [49780,49798]
===
match
---
trailer [42593,42603]
trailer [42562,42572]
===
match
---
trailer [47906,47916]
trailer [47958,47968]
===
match
---
simple_stmt [82533,82574]
simple_stmt [82585,82626]
===
match
---
name: context [52946,52953]
name: context [52998,53005]
===
match
---
atom_expr [58600,58644]
atom_expr [58652,58696]
===
match
---
name: dep_context [32398,32409]
name: dep_context [32398,32409]
===
match
---
trailer [16036,16041]
trailer [16036,16041]
===
match
---
arglist [71561,71730]
arglist [71613,71782]
===
match
---
decorated [81454,81532]
decorated [81506,81584]
===
match
---
atom_expr [72298,72355]
atom_expr [72350,72407]
===
match
---
atom_expr [61408,61427]
atom_expr [61460,61479]
===
match
---
name: email [58889,58894]
name: email [58941,58946]
===
match
---
trailer [19237,19241]
trailer [19237,19241]
===
match
---
name: next_execution_date [61684,61703]
name: next_execution_date [61736,61755]
===
match
---
trailer [68789,68811]
trailer [68841,68863]
===
match
---
suite [20461,20494]
suite [20461,20494]
===
match
---
atom_expr [47424,47470]
atom_expr [47476,47522]
===
match
---
name: self [22878,22882]
name: self [22878,22882]
===
match
---
name: task_copy [50535,50544]
name: task_copy [50587,50596]
===
match
---
simple_stmt [25011,25031]
simple_stmt [25011,25031]
===
match
---
trailer [67906,67920]
trailer [67958,67972]
===
match
---
trailer [56815,56820]
trailer [56867,56872]
===
match
---
atom_expr [79178,79198]
atom_expr [79230,79250]
===
match
---
atom_expr [11655,11674]
atom_expr [11655,11674]
===
match
---
string: "task" [47369,47375]
string: "task" [47421,47427]
===
match
---
import_from [2961,3014]
import_from [2961,3014]
===
match
---
trailer [78890,78914]
trailer [78942,78966]
===
match
---
atom_expr [43480,43522]
atom_expr [43532,43574]
===
match
---
simple_stmt [64062,64083]
simple_stmt [64114,64135]
===
match
---
name: subject [72655,72662]
name: subject [72707,72714]
===
match
---
name: log [67798,67801]
name: log [67850,67853]
===
match
---
operator: , [56556,56557]
operator: , [56608,56609]
===
match
---
atom_expr [18958,19016]
atom_expr [18958,19016]
===
match
---
name: reconstructor [1421,1434]
name: reconstructor [1421,1434]
===
match
---
simple_stmt [1202,1260]
simple_stmt [1202,1260]
===
match
---
trailer [11133,11135]
trailer [11133,11135]
===
match
---
expr_stmt [22475,22494]
expr_stmt [22475,22494]
===
match
---
name: Iterable [77997,78005]
name: Iterable [78049,78057]
===
match
---
simple_stmt [18385,18426]
simple_stmt [18385,18426]
===
match
---
name: context_to_airflow_vars [49116,49139]
name: context_to_airflow_vars [49168,49191]
===
match
---
atom_expr [23838,24022]
atom_expr [23838,24022]
===
match
---
param [13219,13224]
param [13219,13224]
===
match
---
operator: -> [81629,81631]
operator: -> [81681,81683]
===
match
---
parameters [73113,73256]
parameters [73165,73308]
===
match
---
name: str [64153,64156]
name: str [64205,64208]
===
match
---
simple_stmt [23202,23226]
simple_stmt [23202,23226]
===
match
---
name: load_error_file [3854,3869]
name: load_error_file [3854,3869]
===
match
---
trailer [57156,57167]
trailer [57208,57219]
===
match
---
operator: , [45246,45247]
operator: , [45298,45299]
===
match
---
expr_stmt [19458,19502]
expr_stmt [19458,19502]
===
match
---
simple_stmt [24642,24705]
simple_stmt [24642,24705]
===
match
---
trailer [45066,45071]
trailer [45118,45123]
===
match
---
name: State [50860,50865]
name: State [50912,50917]
===
match
---
name: subject [72744,72751]
name: subject [72796,72803]
===
match
---
operator: , [64800,64801]
operator: , [64852,64853]
===
match
---
argument [78891,78913]
argument [78943,78965]
===
match
---
name: ready_for_retry [34805,34820]
name: ready_for_retry [34805,34820]
===
match
---
operator: = [14103,14104]
operator: = [14103,14104]
===
match
---
tfpdef [35742,35770]
tfpdef [35742,35770]
===
match
---
trailer [4085,4091]
trailer [4085,4091]
===
match
---
trailer [5044,5091]
trailer [5044,5091]
===
match
---
funcdef [30902,32245]
funcdef [30902,32245]
===
match
---
simple_stmt [42589,42616]
simple_stmt [42558,42585]
===
match
---
name: try_number [6811,6821]
name: try_number [6811,6821]
===
match
---
atom_expr [27653,27664]
atom_expr [27653,27664]
===
match
---
trailer [9506,9532]
trailer [9506,9532]
===
match
---
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.value.variable_name }}`` or             ``{{ var.value.get('variable_name', 'fallback') }}``.             """ [62602,62826]
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.value.variable_name }}`` or             ``{{ var.value.get('variable_name', 'fallback') }}``.             """ [62654,62878]
===
match
---
param [53389,53394]
param [53441,53446]
===
match
---
annassign [80494,80510]
annassign [80546,80562]
===
match
---
operator: = [15044,15045]
operator: = [15044,15045]
===
match
---
atom_expr [7833,7841]
atom_expr [7833,7841]
===
match
---
suite [76919,77220]
suite [76971,77272]
===
match
---
trailer [43088,43104]
trailer [43140,43156]
===
match
---
trailer [62046,62061]
trailer [62098,62113]
===
match
---
atom_expr [40723,40760]
atom_expr [40723,40760]
===
match
---
name: utils [2378,2383]
name: utils [2378,2383]
===
match
---
expr_stmt [55685,55721]
expr_stmt [55737,55773]
===
match
---
expr_stmt [52946,52983]
expr_stmt [52998,53035]
===
match
---
atom_expr [43451,43467]
atom_expr [43503,43519]
===
match
---
string: """         Return the try number that this task number will be when it is actually         run.          If the TaskInstance is currently running, this will match the column in the         database, in all other cases this will be incremented.         """ [12640,12896]
string: """         Return the try number that this task number will be when it is actually         run.          If the TaskInstance is currently running, this will match the column in the         database, in all other cases this will be incremented.         """ [12640,12896]
===
match
---
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [69767,69816]
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [69819,69868]
===
match
---
operator: , [35926,35927]
operator: , [35926,35927]
===
match
---
comparison [79285,79317]
comparison [79337,79369]
===
match
---
atom_expr [9761,9801]
atom_expr [9761,9801]
===
match
---
name: self [24119,24123]
name: self [24119,24123]
===
match
---
name: BaseJob [7355,7362]
name: BaseJob [7355,7362]
===
match
---
name: pool [15359,15363]
name: pool [15359,15363]
===
match
---
name: overwrite_params_with_dag_run_conf [67632,67666]
name: overwrite_params_with_dag_run_conf [67684,67718]
===
match
---
trailer [77042,77056]
trailer [77094,77108]
===
match
---
name: test_mode [54445,54454]
name: test_mode [54497,54506]
===
match
---
name: Log [45479,45482]
name: Log [45531,45534]
===
match
---
trailer [54957,54962]
trailer [55009,55014]
===
match
---
atom_expr [43766,43778]
atom_expr [43818,43830]
===
match
---
operator: , [15569,15570]
operator: , [15569,15570]
===
match
---
operator: { [76942,76943]
operator: { [76994,76995]
===
match
---
simple_stmt [12119,12139]
simple_stmt [12119,12139]
===
match
---
trailer [77341,77359]
trailer [77393,77411]
===
match
---
param [35867,35894]
param [35867,35894]
===
match
---
atom_expr [39930,39961]
atom_expr [39930,39961]
===
match
---
trailer [5888,5927]
trailer [5888,5927]
===
match
---
not_test [67316,67337]
not_test [67368,67389]
===
match
---
trailer [11985,11996]
trailer [11985,11996]
===
match
---
tfpdef [4220,4235]
tfpdef [4220,4235]
===
match
---
trailer [59319,59342]
trailer [59371,59394]
===
match
---
trailer [43459,43464]
trailer [43511,43516]
===
match
---
expr_stmt [79562,79613]
expr_stmt [79614,79665]
===
match
---
expr_stmt [69460,69513]
expr_stmt [69512,69565]
===
match
---
name: log_message [57916,57927]
name: log_message [57968,57979]
===
match
---
name: task [64535,64539]
name: task [64587,64591]
===
match
---
param [56226,56239]
param [56278,56291]
===
match
---
exprlist [6881,6901]
exprlist [6881,6901]
===
match
---
trailer [72959,72961]
trailer [73011,73013]
===
match
---
name: state [80095,80100]
name: state [80147,80152]
===
match
---
simple_stmt [53276,53308]
simple_stmt [53328,53360]
===
match
---
parameters [13966,14312]
parameters [13966,14312]
===
match
---
trailer [46076,46084]
trailer [46128,46136]
===
match
---
trailer [18094,18105]
trailer [18094,18105]
===
match
---
name: Optional [16001,16009]
name: Optional [16001,16009]
===
match
---
trailer [5891,5901]
trailer [5891,5901]
===
match
---
return_stmt [29579,29639]
return_stmt [29579,29639]
===
match
---
operator: = [24951,24952]
operator: = [24951,24952]
===
match
---
atom_expr [55373,55655]
atom_expr [55425,55707]
===
match
---
name: self [19631,19635]
name: self [19631,19635]
===
match
---
simple_stmt [80299,80325]
simple_stmt [80351,80377]
===
match
---
decorator [45674,45696]
decorator [45726,45748]
===
match
---
atom_expr [24953,25002]
atom_expr [24953,25002]
===
match
---
simple_stmt [31630,31672]
simple_stmt [31630,31672]
===
match
---
operator: = [20992,20993]
operator: = [20992,20993]
===
match
---
name: duration [72993,73001]
name: duration [73045,73053]
===
match
---
atom_expr [19631,19643]
atom_expr [19631,19643]
===
match
---
comparison [59619,59637]
comparison [59671,59689]
===
match
---
trailer [45478,45501]
trailer [45530,45553]
===
match
---
simple_stmt [56454,56503]
simple_stmt [56506,56555]
===
match
---
name: next_ds [64793,64800]
name: next_ds [64845,64852]
===
match
---
name: expected_state [3575,3589]
name: expected_state [3575,3589]
===
match
---
trailer [82137,82145]
trailer [82189,82197]
===
match
---
name: execution_date [27235,27249]
name: execution_date [27235,27249]
===
match
---
name: ignore_all_deps [15045,15060]
name: ignore_all_deps [15045,15060]
===
match
---
string: '%Y%m%dT%H%M%S' [58510,58525]
string: '%Y%m%dT%H%M%S' [58562,58577]
===
match
---
comparison [27653,27672]
comparison [27653,27672]
===
match
---
atom_expr [10054,10073]
atom_expr [10054,10073]
===
match
---
name: filter [77602,77608]
name: filter [77654,77660]
===
match
---
name: dag_id [77639,77645]
name: dag_id [77691,77697]
===
match
---
operator: , [2798,2799]
operator: , [2798,2799]
===
match
---
atom_expr [6756,6949]
atom_expr [6756,6949]
===
match
---
operator: , [41310,41311]
operator: , [41279,41280]
===
match
---
name: operator [23520,23528]
name: operator [23520,23528]
===
match
---
operator: , [58586,58587]
operator: , [58638,58639]
===
match
---
if_stmt [61101,61429]
if_stmt [61153,61481]
===
match
---
arglist [38171,38420]
arglist [38171,38420]
===
match
---
name: jinja_context [70714,70727]
name: jinja_context [70766,70779]
===
match
---
argument [39674,39707]
argument [39674,39707]
===
match
---
atom_expr [33616,33637]
atom_expr [33616,33637]
===
match
---
name: self [50784,50788]
name: self [50836,50840]
===
match
---
operator: = [58255,58256]
operator: = [58307,58308]
===
match
---
trailer [19063,19071]
trailer [19063,19071]
===
match
---
name: dep_status [32737,32747]
name: dep_status [32737,32747]
===
match
---
name: RUNNING [5140,5147]
name: RUNNING [5140,5147]
===
match
---
name: ti [6065,6067]
name: ti [6065,6067]
===
match
---
decorator [24097,24107]
decorator [24097,24107]
===
match
---
name: task [11750,11754]
name: task [11750,11754]
===
match
---
operator: , [20997,20998]
operator: , [20997,20998]
===
match
---
simple_stmt [9910,9935]
simple_stmt [9910,9935]
===
match
---
return_stmt [81114,81132]
return_stmt [81166,81184]
===
match
---
if_stmt [59616,59679]
if_stmt [59668,59731]
===
match
---
trailer [13159,13171]
trailer [13159,13171]
===
match
---
atom_expr [22703,22717]
atom_expr [22703,22717]
===
match
---
name: count [26322,26327]
name: count [26322,26327]
===
match
---
trailer [26108,26112]
trailer [26108,26112]
===
match
---
name: filepath [14704,14712]
name: filepath [14704,14712]
===
match
---
atom_expr [27961,27973]
atom_expr [27961,27973]
===
match
---
if_stmt [45437,45534]
if_stmt [45489,45586]
===
match
---
expr_stmt [57847,57872]
expr_stmt [57899,57924]
===
match
---
trailer [24064,24070]
trailer [24064,24070]
===
match
---
name: self [32911,32915]
name: self [32911,32915]
===
match
---
trailer [8115,8135]
trailer [8115,8135]
===
match
---
operator: @ [18816,18817]
operator: @ [18816,18817]
===
match
---
string: "wb" [4348,4352]
string: "wb" [4348,4352]
===
match
---
parameters [32910,32916]
parameters [32910,32916]
===
match
---
simple_stmt [24226,24314]
simple_stmt [24226,24314]
===
match
---
name: State [37750,37755]
name: State [37750,37755]
===
match
---
operator: == [79305,79307]
operator: == [79357,79359]
===
match
---
string: """Render k8s pod yaml""" [68239,68264]
string: """Render k8s pod yaml""" [68291,68316]
===
match
---
name: self [56871,56875]
name: self [56923,56927]
===
match
---
name: dag [14753,14756]
name: dag [14753,14756]
===
match
---
name: full_filepath [14635,14648]
name: full_filepath [14635,14648]
===
match
---
trailer [23535,23545]
trailer [23535,23545]
===
match
---
and_test [67755,67779]
and_test [67807,67831]
===
match
---
operator: = [3147,3148]
operator: = [3147,3148]
===
match
---
import_from [901,936]
import_from [901,936]
===
match
---
simple_stmt [9484,9552]
simple_stmt [9484,9552]
===
match
---
param [29703,29708]
param [29703,29708]
===
match
---
suite [55163,56002]
suite [55215,56054]
===
match
---
trailer [55567,55576]
trailer [55619,55628]
===
match
---
trailer [78348,78355]
trailer [78400,78407]
===
match
---
expr_stmt [80483,80510]
expr_stmt [80535,80562]
===
match
---
argument [51842,51861]
argument [51894,51913]
===
match
---
name: self [40769,40773]
name: self [40769,40773]
===
match
---
operator: = [39001,39002]
operator: = [39001,39002]
===
match
---
name: task [25887,25891]
name: task [25887,25891]
===
match
---
return_stmt [28987,29035]
return_stmt [28987,29035]
===
match
---
trailer [77075,77081]
trailer [77127,77133]
===
match
---
name: self [43796,43800]
name: self [43848,43852]
===
match
---
name: integrate_macros_plugins [2146,2170]
name: integrate_macros_plugins [2146,2170]
===
match
---
simple_stmt [80961,80983]
simple_stmt [81013,81035]
===
match
---
if_stmt [76380,76432]
if_stmt [76432,76484]
===
match
---
name: pool_slots [22528,22538]
name: pool_slots [22528,22538]
===
match
---
name: self [41153,41157]
name: self [41122,41126]
===
match
---
decorated [50701,51106]
decorated [50753,51158]
===
match
---
param [20979,20984]
param [20979,20984]
===
match
---
atom_expr [78312,78324]
atom_expr [78364,78376]
===
match
---
tfpdef [15523,15535]
tfpdef [15523,15535]
===
match
---
name: query [82036,82041]
name: query [82088,82093]
===
match
---
simple_stmt [30222,30302]
simple_stmt [30222,30302]
===
match
---
name: self [72727,72731]
name: self [72779,72783]
===
match
---
name: pod_generator [3043,3056]
name: pod_generator [3043,3056]
===
match
---
operator: ** [72102,72104]
operator: ** [72154,72156]
===
match
---
name: state [52824,52829]
name: state [52876,52881]
===
match
---
parameters [25383,25403]
parameters [25383,25403]
===
match
---
trailer [8219,8226]
trailer [8219,8226]
===
match
---
name: airflow [45874,45881]
name: airflow [45926,45933]
===
match
---
atom_expr [70881,70896]
atom_expr [70933,70948]
===
match
---
name: error [59062,59067]
name: error [59114,59119]
===
match
---
operator: , [44126,44127]
operator: , [44178,44179]
===
match
---
operator: = [77912,77913]
operator: = [77964,77965]
===
match
---
name: getLogger [11296,11305]
name: getLogger [11296,11305]
===
match
---
expr_stmt [9986,10041]
expr_stmt [9986,10041]
===
match
---
operator: == [25281,25283]
operator: == [25281,25283]
===
match
---
simple_stmt [48829,48923]
simple_stmt [48881,48975]
===
match
---
trailer [22705,22717]
trailer [22705,22717]
===
match
---
operator: = [60651,60652]
operator: = [60703,60704]
===
match
---
atom_expr [71933,71955]
atom_expr [71985,72007]
===
match
---
name: self [68593,68597]
name: self [68645,68649]
===
match
---
not_test [42923,42939]
not_test [42975,42991]
===
match
---
name: job_id [15339,15345]
name: job_id [15339,15345]
===
match
---
name: self [32980,32984]
name: self [32980,32984]
===
match
---
atom_expr [11477,11639]
atom_expr [11477,11639]
===
match
---
simple_stmt [77246,77293]
simple_stmt [77298,77345]
===
match
---
string: 'yesterday_ds' [65969,65983]
string: 'yesterday_ds' [66021,66035]
===
match
---
operator: = [34628,34629]
operator: = [34628,34629]
===
match
---
operator: , [46198,46199]
operator: , [46250,46251]
===
match
---
decorator [81376,81386]
decorator [81428,81438]
===
match
---
name: self [61325,61329]
name: self [61377,61381]
===
match
---
parameters [28539,28545]
parameters [28539,28545]
===
match
---
operator: = [12076,12077]
operator: = [12076,12077]
===
match
---
name: session [4673,4680]
name: session [4673,4680]
===
match
---
trailer [60354,60369]
trailer [60406,60421]
===
match
---
tfpdef [53403,53416]
tfpdef [53455,53468]
===
match
---
trailer [19499,19501]
trailer [19499,19501]
===
match
---
param [12447,12451]
param [12447,12451]
===
match
---
name: format [33808,33814]
name: format [33808,33814]
===
match
---
simple_stmt [39930,39962]
simple_stmt [39930,39962]
===
match
---
atom_expr [4008,4017]
atom_expr [4008,4017]
===
match
---
trailer [22443,22450]
trailer [22443,22450]
===
match
---
param [14157,14179]
param [14157,14179]
===
match
---
suite [49918,50157]
suite [49970,50209]
===
match
---
comparison [27587,27604]
comparison [27587,27604]
===
match
---
arglist [31946,32098]
arglist [31946,32098]
===
match
---
atom_expr [10280,10304]
atom_expr [10280,10304]
===
match
---
trailer [60548,60563]
trailer [60600,60615]
===
match
---
subscriptlist [59075,59089]
subscriptlist [59127,59141]
===
match
---
suite [53160,53308]
suite [53212,53360]
===
match
---
atom_expr [14652,14664]
atom_expr [14652,14664]
===
match
---
name: Log [1905,1908]
name: Log [1905,1908]
===
match
---
operator: = [22413,22414]
operator: = [22413,22414]
===
match
---
name: task_id [77707,77714]
name: task_id [77759,77766]
===
match
---
atom_expr [43227,43243]
atom_expr [43279,43295]
===
match
---
name: execution_date [57136,57150]
name: execution_date [57188,57202]
===
match
---
operator: } [44605,44606]
operator: } [44657,44658]
===
match
---
name: hasattr [41401,41408]
name: hasattr [41370,41377]
===
match
---
suite [29799,30302]
suite [29799,30302]
===
match
---
operator: , [68693,68694]
operator: , [68745,68746]
===
match
---
operator: , [42651,42652]
operator: , [42620,42621]
===
match
---
name: ignore_all_deps [35703,35718]
name: ignore_all_deps [35703,35718]
===
match
---
operator: = [10125,10126]
operator: = [10125,10126]
===
match
---
atom [49283,49336]
atom [49335,49388]
===
match
---
atom_expr [78006,78044]
atom_expr [78058,78096]
===
match
---
string: "Failed to register in sensor service." [49981,50020]
string: "Failed to register in sensor service." [50033,50072]
===
match
---
name: execution_date [55462,55476]
name: execution_date [55514,55528]
===
match
---
name: or_ [6756,6759]
name: or_ [6756,6759]
===
match
---
expr_stmt [11935,11971]
expr_stmt [11935,11971]
===
match
---
name: dag [14631,14634]
name: dag [14631,14634]
===
match
---
suite [72703,72771]
suite [72755,72823]
===
match
---
name: ti [5100,5102]
name: ti [5100,5102]
===
match
---
name: current_time [24601,24613]
name: current_time [24601,24613]
===
match
---
arglist [78756,78915]
arglist [78808,78967]
===
match
---
name: dagrun [82553,82559]
name: dagrun [82605,82611]
===
match
---
operator: = [51845,51846]
operator: = [51897,51898]
===
match
---
comparison [6695,6730]
comparison [6695,6730]
===
match
---
trailer [26437,26442]
trailer [26437,26442]
===
match
---
trailer [24045,24047]
trailer [24045,24047]
===
match
---
trailer [20798,20804]
trailer [20798,20804]
===
match
---
arglist [9580,9609]
arglist [9580,9609]
===
match
---
trailer [44922,44978]
trailer [44974,45030]
===
match
---
name: lock_for_update [20999,21014]
name: lock_for_update [20999,21014]
===
match
---
name: pool_override [42653,42666]
name: pool_override [42622,42635]
===
match
---
name: Column [9818,9824]
name: Column [9818,9824]
===
match
---
name: self [71664,71668]
name: self [71716,71720]
===
match
---
name: session [50761,50768]
name: session [50813,50820]
===
match
---
name: debug [24651,24656]
name: debug [24651,24656]
===
match
---
trailer [69053,69058]
trailer [69105,69110]
===
match
---
testlist_star_expr [72518,72557]
testlist_star_expr [72570,72609]
===
match
---
arglist [60050,60061]
arglist [60102,60113]
===
match
---
operator: = [53649,53650]
operator: = [53701,53702]
===
match
---
operator: , [58526,58527]
operator: , [58578,58579]
===
match
---
suite [27149,27182]
suite [27149,27182]
===
match
---
name: airflow [2705,2712]
name: airflow [2705,2712]
===
match
---
name: refresh_from_db [20963,20978]
name: refresh_from_db [20963,20978]
===
match
---
name: self [8703,8707]
name: self [8703,8707]
===
match
---
except_clause [44347,44375]
except_clause [44399,44427]
===
match
---
operator: , [10623,10624]
operator: , [10623,10624]
===
match
---
trailer [66702,67048]
trailer [66754,67100]
===
match
---
arglist [62127,62134]
arglist [62179,62186]
===
match
---
name: self [39140,39144]
name: self [39140,39144]
===
match
---
param [53472,53509]
param [53524,53561]
===
match
---
atom_expr [25011,25030]
atom_expr [25011,25030]
===
match
---
trailer [22417,22426]
trailer [22417,22426]
===
match
---
expr_stmt [19222,19266]
expr_stmt [19222,19266]
===
match
---
if_stmt [60076,60143]
if_stmt [60128,60195]
===
match
---
suite [62859,62892]
suite [62911,62944]
===
match
---
suite [61514,61705]
suite [61566,61757]
===
match
---
name: airflow [1914,1921]
name: airflow [1914,1921]
===
match
---
trailer [77061,77069]
trailer [77113,77121]
===
match
---
simple_stmt [49788,49853]
simple_stmt [49840,49905]
===
match
---
trailer [43015,43056]
trailer [43067,43108]
===
match
---
name: self [65197,65201]
name: self [65249,65253]
===
match
---
name: self [32965,32969]
name: self [32965,32969]
===
match
---
name: TaskInstance [79285,79297]
name: TaskInstance [79337,79349]
===
match
---
trailer [58852,58895]
trailer [58904,58947]
===
match
---
trailer [40359,40361]
trailer [40359,40361]
===
match
---
name: log [58291,58294]
name: log [58343,58346]
===
match
---
name: self [80968,80972]
name: self [81020,81024]
===
match
---
name: session [60513,60520]
name: session [60565,60572]
===
match
---
operator: = [35771,35772]
operator: = [35771,35772]
===
match
---
trailer [24266,24274]
trailer [24266,24274]
===
match
---
name: log [40542,40545]
name: log [40542,40545]
===
match
---
string: '' [62209,62211]
string: '' [62261,62263]
===
match
---
operator: = [52592,52593]
operator: = [52644,52645]
===
match
---
operator: -> [8570,8572]
operator: -> [8570,8572]
===
match
---
name: FAILED [57049,57055]
name: FAILED [57101,57107]
===
match
---
name: TaskInstance [20246,20258]
name: TaskInstance [20246,20258]
===
match
---
name: item [62960,62964]
name: item [63012,63016]
===
match
---
name: self [58450,58454]
name: self [58502,58506]
===
match
---
suite [38582,38645]
suite [38582,38645]
===
match
---
atom_expr [40344,40361]
atom_expr [40344,40361]
===
match
---
trailer [40633,40638]
trailer [40633,40638]
===
match
---
operator: @ [3238,3239]
operator: @ [3238,3239]
===
match
---
trailer [58544,58555]
trailer [58596,58607]
===
match
---
simple_stmt [37456,37505]
simple_stmt [37456,37505]
===
match
---
operator: * [37926,37927]
operator: * [37926,37927]
===
match
---
name: task_ids [76909,76917]
name: task_ids [76961,76969]
===
match
---
simple_stmt [12531,12591]
simple_stmt [12531,12591]
===
match
---
simple_stmt [81654,82014]
simple_stmt [81706,82066]
===
match
---
expr_stmt [46883,46941]
expr_stmt [46935,46993]
===
match
---
name: operator [22663,22671]
name: operator [22663,22671]
===
match
---
argument [15382,15399]
argument [15382,15399]
===
match
---
parameters [50754,50774]
parameters [50806,50826]
===
match
---
name: self [81488,81492]
name: self [81540,81544]
===
match
---
expr_stmt [9910,9934]
expr_stmt [9910,9934]
===
match
---
trailer [72101,72118]
trailer [72153,72170]
===
match
---
fstring_start: f" [19619,19621]
fstring_start: f" [19619,19621]
===
match
---
trailer [4335,4353]
trailer [4335,4353]
===
match
---
suite [11464,11926]
suite [11464,11926]
===
match
---
atom_expr [29616,29638]
atom_expr [29616,29638]
===
match
---
name: exception [72591,72600]
name: exception [72643,72652]
===
match
---
atom [20167,20446]
atom [20167,20446]
===
match
---
suite [5174,5259]
suite [5174,5259]
===
match
---
name: ds [60539,60541]
name: ds [60591,60593]
===
match
---
name: set_error_file [4205,4219]
name: set_error_file [4205,4219]
===
match
---
name: max_tries [71705,71714]
name: max_tries [71757,71766]
===
match
---
name: load_error_file [54691,54706]
name: load_error_file [54743,54758]
===
match
---
name: bool [15718,15722]
name: bool [15718,15722]
===
match
---
name: provide_session [41560,41575]
name: provide_session [41529,41544]
===
match
---
atom [18477,18488]
atom [18477,18488]
===
match
---
suite [71905,72041]
suite [71957,72093]
===
match
---
operator: , [5901,5902]
operator: , [5901,5902]
===
match
---
name: datetime [79947,79955]
name: datetime [79999,80007]
===
match
---
param [63886,63896]
param [63938,63948]
===
match
---
name: prev_ds [64994,65001]
name: prev_ds [65046,65053]
===
match
---
param [72793,72797]
param [72845,72849]
===
match
---
operator: , [32535,32536]
operator: , [32535,32536]
===
match
---
name: delay_backoff_in_seconds [34512,34536]
name: delay_backoff_in_seconds [34512,34536]
===
match
---
return_stmt [27170,27181]
return_stmt [27170,27181]
===
match
---
trailer [11434,11447]
trailer [11434,11447]
===
match
---
trailer [11243,11261]
trailer [11243,11261]
===
match
---
suite [63511,64472]
suite [63563,64524]
===
match
---
atom_expr [59502,59516]
atom_expr [59554,59568]
===
match
---
operator: = [15314,15315]
operator: = [15314,15315]
===
match
---
param [14188,14200]
param [14188,14200]
===
match
---
funcdef [81390,81449]
funcdef [81442,81501]
===
match
---
name: timezone [11886,11894]
name: timezone [11886,11894]
===
match
---
name: str [53683,53686]
name: str [53735,53738]
===
match
---
name: get_email_subject_content [72565,72590]
name: get_email_subject_content [72617,72642]
===
match
---
trailer [56973,56988]
trailer [57025,57040]
===
match
---
trailer [68546,68553]
trailer [68598,68605]
===
match
---
arglist [43057,43070]
arglist [43109,43122]
===
match
---
name: ignore_task_deps [38403,38419]
name: ignore_task_deps [38403,38419]
===
match
---
name: execution_date [82189,82203]
name: execution_date [82241,82255]
===
match
---
name: dep_context [31644,31655]
name: dep_context [31644,31655]
===
match
---
comparison [52819,52846]
comparison [52871,52898]
===
match
---
name: conf [19233,19237]
name: conf [19233,19237]
===
match
---
operator: , [64969,64970]
operator: , [65021,65022]
===
match
---
trailer [46041,46277]
trailer [46093,46329]
===
match
---
name: self [43902,43906]
name: self [43954,43958]
===
match
---
param [8101,8105]
param [8101,8105]
===
match
---
name: __init__ [79750,79758]
name: __init__ [79802,79810]
===
match
---
name: task_id [5298,5305]
name: task_id [5298,5305]
===
match
---
name: self [21441,21445]
name: self [21441,21445]
===
match
---
trailer [25018,25024]
trailer [25018,25024]
===
match
---
name: context [52727,52734]
name: context [52779,52786]
===
match
---
funcdef [18830,19084]
funcdef [18830,19084]
===
match
---
name: self [23515,23519]
name: self [23515,23519]
===
match
---
operator: = [15090,15091]
operator: = [15090,15091]
===
match
---
atom_expr [23918,23930]
atom_expr [23918,23930]
===
match
---
atom_expr [5053,5090]
atom_expr [5053,5090]
===
match
---
name: fd [4008,4010]
name: fd [4008,4010]
===
match
---
trailer [35415,35491]
trailer [35415,35491]
===
match
---
name: Stats [2231,2236]
name: Stats [2231,2236]
===
match
---
simple_stmt [56899,56955]
simple_stmt [56951,57007]
===
match
---
name: task_id [8708,8715]
name: task_id [8708,8715]
===
match
---
atom_expr [73191,73209]
atom_expr [73243,73261]
===
match
---
string: """         Immediately runs the task (without checking or changing db state         before execution) and then sets the appropriate final state after         completion and runs any post-execute callbacks. Meant to be called         only after another function changes the state to running.          :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [41869,42555]
string: """         Immediately runs the task (without checking or changing db state         before execution) and then sets the appropriate final state after         completion and runs any post-execute callbacks. Meant to be called         only after another function changes the state to running.          :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [41838,42524]
===
match
---
simple_stmt [27714,27778]
simple_stmt [27714,27778]
===
match
---
operator: = [54067,54068]
operator: = [54119,54120]
===
match
---
name: self [54816,54820]
name: self [54868,54872]
===
match
---
operator: , [58882,58883]
operator: , [58934,58935]
===
match
---
name: task [61298,61302]
name: task [61350,61354]
===
match
---
operator: = [47492,47493]
operator: = [47544,47545]
===
match
---
name: str [15869,15872]
name: str [15869,15872]
===
match
---
operator: , [6949,6950]
operator: , [6949,6950]
===
match
---
trailer [34542,34590]
trailer [34542,34590]
===
match
---
atom [66617,66657]
atom [66669,66709]
===
match
---
operator: = [61940,61941]
operator: = [61992,61993]
===
match
---
trailer [56551,56564]
trailer [56603,56616]
===
match
---
atom_expr [80051,80064]
atom_expr [80103,80116]
===
match
---
operator: = [46025,46026]
operator: = [46077,46078]
===
match
---
simple_stmt [54729,54746]
simple_stmt [54781,54798]
===
match
---
trailer [79399,79414]
trailer [79451,79466]
===
match
---
trailer [29014,29035]
trailer [29014,29035]
===
match
---
name: session [30129,30136]
name: session [30129,30136]
===
match
---
operator: = [45752,45753]
operator: = [45804,45805]
===
match
---
simple_stmt [19275,19366]
simple_stmt [19275,19366]
===
match
---
import_as_names [1421,1448]
import_as_names [1421,1448]
===
match
---
name: self [71715,71719]
name: self [71767,71771]
===
match
---
string: 'utf-8' [33941,33948]
string: 'utf-8' [33941,33948]
===
match
---
trailer [5139,5147]
trailer [5139,5147]
===
match
---
param [59062,59091]
param [59114,59143]
===
match
---
atom_expr [80317,80324]
atom_expr [80369,80376]
===
match
---
trailer [29606,29615]
trailer [29606,29615]
===
match
---
name: refresh_from_db [44033,44048]
name: refresh_from_db [44085,44100]
===
match
---
name: rollback [47997,48005]
name: rollback [48049,48057]
===
match
---
param [74581,74610]
param [74633,74662]
===
match
---
decorator [77955,77969]
decorator [78007,78021]
===
match
---
atom_expr [23400,23416]
atom_expr [23400,23416]
===
match
---
name: get [19238,19241]
name: get [19238,19241]
===
match
---
operator: , [1752,1753]
operator: , [1752,1753]
===
match
---
operator: , [63207,63208]
operator: , [63259,63260]
===
match
---
import_from [66171,66241]
import_from [66223,66293]
===
match
---
operator: } [32962,32963]
operator: } [32962,32963]
===
match
---
name: state [5194,5199]
name: state [5194,5199]
===
match
---
operator: -> [4267,4269]
operator: -> [4267,4269]
===
match
---
dotted_name [1914,1937]
dotted_name [1914,1937]
===
match
---
name: raw [77847,77850]
name: raw [77899,77902]
===
match
---
operator: , [40164,40165]
operator: , [40164,40165]
===
match
---
raise_stmt [66680,67055]
raise_stmt [66732,67107]
===
match
---
operator: = [10233,10234]
operator: = [10233,10234]
===
match
---
comparison [37736,37763]
comparison [37736,37763]
===
match
---
name: email_alert [58737,58748]
name: email_alert [58789,58800]
===
match
---
simple_stmt [24740,24790]
simple_stmt [24740,24790]
===
match
---
name: str [15934,15937]
name: str [15934,15937]
===
match
---
name: end_date [57174,57182]
name: end_date [57226,57234]
===
match
---
operator: + [19580,19581]
operator: + [19580,19581]
===
match
---
name: info [43236,43240]
name: info [43288,43292]
===
match
---
operator: = [76581,76582]
operator: = [76633,76634]
===
match
---
param [22878,22883]
param [22878,22883]
===
match
---
arglist [62431,62470]
arglist [62483,62522]
===
match
---
operator: , [6891,6892]
operator: , [6891,6892]
===
match
---
operator: , [65598,65599]
operator: , [65650,65651]
===
match
---
number: 1 [40682,40683]
number: 1 [40682,40683]
===
match
---
name: ti [7742,7744]
name: ti [7742,7744]
===
match
---
if_stmt [24798,25003]
if_stmt [24798,25003]
===
match
---
string: "TaskInstance.dag_id == DagModel.dag_id" [10899,10939]
string: "TaskInstance.dag_id == DagModel.dag_id" [10899,10939]
===
match
---
operator: , [53623,53624]
operator: , [53675,53676]
===
match
---
string: '%Y%m%dT%H%M%S' [41519,41534]
string: '%Y%m%dT%H%M%S' [41488,41503]
===
match
---
name: path [14784,14788]
name: path [14784,14788]
===
match
---
atom_expr [53276,53307]
atom_expr [53328,53359]
===
match
---
string: 'ts_nodash' [65752,65763]
string: 'ts_nodash' [65804,65815]
===
match
---
name: base_job [7281,7289]
name: base_job [7281,7289]
===
match
---
name: datetime [80943,80951]
name: datetime [80995,81003]
===
match
---
trailer [40929,40936]
trailer [40898,40905]
===
match
---
name: state [30855,30860]
name: state [30855,30860]
===
match
---
name: self [67299,67303]
name: self [67351,67355]
===
match
---
name: cfg_path [18781,18789]
name: cfg_path [18781,18789]
===
match
---
atom_expr [22415,22426]
atom_expr [22415,22426]
===
match
---
name: pool_override [23246,23259]
name: pool_override [23246,23259]
===
match
---
name: rendered_task_instance_fields [66251,66280]
name: rendered_task_instance_fields [66303,66332]
===
match
---
suite [51383,51523]
suite [51435,51575]
===
match
---
trailer [20194,20208]
trailer [20194,20208]
===
match
---
suite [4726,7904]
suite [4726,7904]
===
match
---
param [30933,30950]
param [30933,30950]
===
match
---
name: len [26331,26334]
name: len [26331,26334]
===
match
---
name: test_mode [54455,54464]
name: test_mode [54507,54516]
===
match
---
name: self [25384,25388]
name: self [25384,25388]
===
match
---
trailer [26009,26017]
trailer [26009,26017]
===
match
---
param [51144,51153]
param [51196,51205]
===
match
---
atom_expr [42681,42718]
atom_expr [42650,42687]
===
match
---
name: data [4029,4033]
name: data [4029,4033]
===
match
---
simple_stmt [25082,25198]
simple_stmt [25082,25198]
===
match
---
simple_stmt [51827,51877]
simple_stmt [51879,51929]
===
match
---
name: activate_dag_runs [4686,4703]
name: activate_dag_runs [4686,4703]
===
match
---
name: self [80027,80031]
name: self [80079,80083]
===
match
---
decorated [80583,80650]
decorated [80635,80702]
===
match
---
atom_expr [30241,30259]
atom_expr [30241,30259]
===
match
---
operator: = [31687,31688]
operator: = [31687,31688]
===
match
---
import_from [67155,67225]
import_from [67207,67277]
===
match
---
name: with_entities [77043,77056]
name: with_entities [77095,77108]
===
match
---
lambdef [65346,65403]
lambdef [65398,65455]
===
match
---
operator: , [1088,1089]
operator: , [1088,1089]
===
match
---
funcdef [11028,12406]
funcdef [11028,12406]
===
match
---
simple_stmt [47647,47664]
simple_stmt [47699,47716]
===
match
---
name: self [79980,79984]
name: self [80032,80036]
===
match
---
trailer [40666,40678]
trailer [40666,40678]
===
match
---
expr_stmt [71142,71214]
expr_stmt [71194,71266]
===
match
---
trailer [50641,50651]
trailer [50693,50703]
===
match
---
name: job_id [41716,41722]
name: job_id [41685,41691]
===
match
---
param [45739,45744]
param [45791,45796]
===
match
---
atom_expr [43851,43884]
atom_expr [43903,43936]
===
match
---
operator: } [42891,42892]
operator: } [42943,42944]
===
match
---
atom_expr [72867,72882]
atom_expr [72919,72934]
===
match
---
simple_stmt [61438,61453]
simple_stmt [61490,61505]
===
match
---
name: incr [56905,56909]
name: incr [56957,56961]
===
match
---
operator: = [35919,35920]
operator: = [35919,35920]
===
match
---
operator: - [34586,34587]
operator: - [34586,34587]
===
match
---
name: _key [80524,80528]
name: _key [80576,80580]
===
match
---
atom_expr [80138,80156]
atom_expr [80190,80208]
===
match
---
name: conf [1610,1614]
name: conf [1610,1614]
===
match
---
simple_stmt [22730,22748]
simple_stmt [22730,22748]
===
match
---
simple_stmt [71497,71763]
simple_stmt [71549,71815]
===
match
---
expr_stmt [14835,14846]
expr_stmt [14835,14846]
===
match
---
dotted_name [35285,35306]
dotted_name [35285,35306]
===
match
---
atom_expr [76449,76683]
atom_expr [76501,76735]
===
match
---
operator: , [67865,67866]
operator: , [67917,67918]
===
match
---
name: provide_session [25340,25355]
name: provide_session [25340,25355]
===
match
---
name: task [11193,11197]
name: task [11193,11197]
===
match
---
trailer [43800,43815]
trailer [43852,43867]
===
match
---
name: info [43583,43587]
name: info [43635,43639]
===
match
---
simple_stmt [8008,8021]
simple_stmt [8008,8021]
===
match
---
operator: , [53887,53888]
operator: , [53939,53940]
===
match
---
name: self [45058,45062]
name: self [45110,45114]
===
match
---
trailer [42869,42876]
trailer [42921,42928]
===
match
---
atom_expr [74589,74602]
atom_expr [74641,74654]
===
match
---
name: dag [27608,27611]
name: dag [27608,27611]
===
match
---
name: ignore_depends_on_past [39611,39633]
name: ignore_depends_on_past [39611,39633]
===
match
---
trailer [62394,62401]
trailer [62446,62453]
===
match
---
name: State [2847,2852]
name: State [2847,2852]
===
match
---
parameters [74445,74728]
parameters [74497,74780]
===
match
---
simple_stmt [56829,56863]
simple_stmt [56881,56915]
===
match
---
name: task_id [10697,10704]
name: task_id [10697,10704]
===
match
---
param [55110,55131]
param [55162,55183]
===
match
---
operator: -> [26481,26483]
operator: -> [26481,26483]
===
match
---
name: bool [41661,41665]
name: bool [41630,41634]
===
match
---
name: Column [9628,9634]
name: Column [9628,9634]
===
match
---
atom_expr [58540,58586]
atom_expr [58592,58638]
===
match
---
simple_stmt [51578,51598]
simple_stmt [51630,51650]
===
match
---
name: in_ [26109,26112]
name: in_ [26109,26112]
===
match
---
simple_stmt [55907,55924]
simple_stmt [55959,55976]
===
match
---
trailer [49383,49405]
trailer [49435,49457]
===
match
---
operator: = [73243,73244]
operator: = [73295,73296]
===
match
---
name: filter [7348,7354]
name: filter [7348,7354]
===
match
---
decorated [56007,58980]
decorated [56059,59032]
===
match
---
atom_expr [20867,20879]
atom_expr [20867,20879]
===
match
---
name: logging [11288,11295]
name: logging [11288,11295]
===
match
---
fstring_start: f" [19293,19295]
fstring_start: f" [19293,19295]
===
match
---
operator: , [62016,62017]
operator: , [62068,62069]
===
match
---
operator: = [65235,65236]
operator: = [65287,65288]
===
match
---
fstring_string: .log [19078,19082]
fstring_string: .log [19078,19082]
===
match
---
name: self [25067,25071]
name: self [25067,25071]
===
match
---
expr_stmt [50847,50873]
expr_stmt [50899,50925]
===
match
---
trailer [55315,55328]
trailer [55367,55380]
===
match
---
name: reschedule_exception [55594,55614]
name: reschedule_exception [55646,55666]
===
match
---
trailer [41166,41230]
trailer [41135,41199]
===
match
---
name: self [64039,64043]
name: self [64091,64095]
===
match
---
name: and_ [6581,6585]
name: and_ [6581,6585]
===
match
---
name: task_copy [54965,54974]
name: task_copy [55017,55026]
===
match
---
simple_stmt [48477,48532]
simple_stmt [48529,48584]
===
match
---
name: params [64963,64969]
name: params [65015,65021]
===
match
---
operator: = [31642,31643]
operator: = [31642,31643]
===
match
---
operator: = [60542,60543]
operator: = [60594,60595]
===
match
---
expr_stmt [79870,79920]
expr_stmt [79922,79972]
===
match
---
name: self [11935,11939]
name: self [11935,11939]
===
match
---
simple_stmt [71142,71215]
simple_stmt [71194,71267]
===
match
---
simple_stmt [2056,2110]
simple_stmt [2056,2110]
===
match
---
simple_stmt [11276,11322]
simple_stmt [11276,11322]
===
match
---
name: start_date [21940,21950]
name: start_date [21940,21950]
===
match
---
trailer [39795,39816]
trailer [39795,39816]
===
match
---
name: task [42879,42883]
name: task [42931,42935]
===
match
---
name: handle_failure [44670,44684]
name: handle_failure [44722,44736]
===
match
---
atom_expr [32737,32754]
atom_expr [32737,32754]
===
match
---
atom_expr [8703,8715]
atom_expr [8703,8715]
===
match
---
atom [18766,18790]
atom [18766,18790]
===
match
---
simple_stmt [56761,56795]
simple_stmt [56813,56847]
===
match
---
name: delete_qry [7226,7236]
name: delete_qry [7226,7236]
===
match
---
name: _run_finished_callback [52275,52297]
name: _run_finished_callback [52327,52349]
===
match
---
operator: = [37628,37629]
operator: = [37628,37629]
===
match
---
funcdef [51111,51899]
funcdef [51163,51951]
===
match
---
name: exception_html [70834,70848]
name: exception_html [70886,70900]
===
match
---
trailer [7644,7648]
trailer [7644,7648]
===
match
---
simple_stmt [82341,82358]
simple_stmt [82393,82410]
===
match
---
trailer [40787,40795]
trailer [40787,40795]
===
match
---
operator: - [60674,60675]
operator: - [60726,60727]
===
match
---
name: delete_qry [7149,7159]
name: delete_qry [7149,7159]
===
match
---
param [80762,80766]
param [80814,80818]
===
match
---
trailer [41203,41208]
trailer [41172,41177]
===
match
---
simple_stmt [28001,28013]
simple_stmt [28001,28013]
===
match
---
name: task_id [78893,78900]
name: task_id [78945,78952]
===
match
---
trailer [7613,7768]
trailer [7613,7768]
===
match
---
name: dep_name [32054,32062]
name: dep_name [32054,32062]
===
match
---
import_name [820,834]
import_name [820,834]
===
match
---
name: dag_id [6606,6612]
name: dag_id [6606,6612]
===
match
---
name: session [38599,38606]
name: session [38599,38606]
===
match
---
simple_stmt [1103,1134]
simple_stmt [1103,1134]
===
match
---
name: e [43302,43303]
name: e [43354,43355]
===
match
---
name: verbose [41099,41106]
name: verbose [41068,41075]
===
match
---
name: dep_status [32496,32506]
name: dep_status [32496,32506]
===
match
---
name: pod [69054,69057]
name: pod [69106,69109]
===
match
---
name: self [40754,40758]
name: self [40754,40758]
===
match
---
name: key [76528,76531]
name: key [76580,76583]
===
match
---
string: 'prev_execution_date_success' [65117,65146]
string: 'prev_execution_date_success' [65169,65198]
===
match
---
name: pickle_id [14577,14586]
name: pickle_id [14577,14586]
===
match
---
name: email [58692,58697]
name: email [58744,58749]
===
match
---
trailer [54737,54743]
trailer [54789,54795]
===
match
---
trailer [30854,30875]
trailer [30854,30875]
===
match
---
name: prev_ds [61803,61810]
name: prev_ds [61855,61862]
===
match
---
suite [41389,41554]
suite [41358,41523]
===
match
---
expr_stmt [46959,47151]
expr_stmt [47011,47203]
===
match
---
operator: = [37659,37660]
operator: = [37659,37660]
===
match
---
name: Base [1869,1873]
name: Base [1869,1873]
===
match
---
suite [50417,50482]
suite [50469,50534]
===
match
---
string: """Returns a tuple that identifies the task instance uniquely""" [24153,24217]
string: """Returns a tuple that identifies the task instance uniquely""" [24153,24217]
===
match
---
atom_expr [8674,8749]
atom_expr [8674,8749]
===
match
---
name: merge [20896,20901]
name: merge [20896,20901]
===
match
---
simple_stmt [55848,55870]
simple_stmt [55900,55922]
===
match
---
simple_stmt [21441,21500]
simple_stmt [21441,21500]
===
match
---
decorated [35059,35542]
decorated [35059,35542]
===
match
---
operator: = [5373,5374]
operator: = [5373,5374]
===
match
---
simple_stmt [60422,60467]
simple_stmt [60474,60519]
===
match
---
except_clause [4102,4118]
except_clause [4102,4118]
===
match
---
atom_expr [55879,55898]
atom_expr [55931,55950]
===
match
---
fstring_end: " [19644,19645]
fstring_end: " [19644,19645]
===
match
---
arglist [64418,64470]
arglist [64470,64522]
===
match
---
name: AirflowFailException [44173,44193]
name: AirflowFailException [44225,44245]
===
match
---
operator: -> [28546,28548]
operator: -> [28546,28548]
===
match
---
name: dag_id [17943,17949]
name: dag_id [17943,17949]
===
match
---
name: task_id [32970,32977]
name: task_id [32970,32977]
===
match
---
trailer [55025,55033]
trailer [55077,55085]
===
match
---
name: duration [22008,22016]
name: duration [22008,22016]
===
match
---
trailer [6048,6059]
trailer [6048,6059]
===
match
---
name: Exception [72693,72702]
name: Exception [72745,72754]
===
match
---
suite [77233,77366]
suite [77285,77418]
===
match
---
fstring_end: " [47917,47918]
fstring_end: " [47969,47970]
===
match
---
expr_stmt [39091,39170]
expr_stmt [39091,39170]
===
match
---
name: State [39903,39908]
name: State [39903,39908]
===
match
---
suite [44015,44158]
suite [44067,44210]
===
match
---
name: get [18982,18985]
name: get [18982,18985]
===
match
---
parameters [64129,64306]
parameters [64181,64358]
===
match
---
operator: = [71714,71715]
operator: = [71766,71767]
===
match
---
trailer [39934,39938]
trailer [39934,39938]
===
match
---
operator: == [20266,20268]
operator: == [20266,20268]
===
match
---
trailer [61614,61622]
trailer [61666,61674]
===
match
---
name: utils [2413,2418]
name: utils [2413,2418]
===
match
---
atom_expr [24879,24892]
atom_expr [24879,24892]
===
match
---
name: total_seconds [24987,25000]
name: total_seconds [24987,25000]
===
match
---
name: task [59855,59859]
name: task [59907,59911]
===
match
---
name: pickle_id [15250,15259]
name: pickle_id [15250,15259]
===
match
---
name: self [80165,80169]
name: self [80217,80221]
===
match
---
operator: , [35099,35100]
operator: , [35099,35100]
===
match
---
trailer [7901,7903]
trailer [7901,7903]
===
match
---
atom [7719,7752]
atom [7719,7752]
===
match
---
operator: = [22485,22486]
operator: = [22485,22486]
===
match
---
name: self [11239,11243]
name: self [11239,11243]
===
match
---
atom_expr [56963,56988]
atom_expr [57015,57040]
===
match
---
name: airflow [82493,82500]
name: airflow [82545,82552]
===
match
---
expr_stmt [24713,24731]
expr_stmt [24713,24731]
===
match
---
atom_expr [42967,42994]
atom_expr [43019,43046]
===
match
---
trailer [41214,41229]
trailer [41183,41198]
===
match
---
name: execution_date [6030,6044]
name: execution_date [6030,6044]
===
match
---
name: retry_delay [33266,33277]
name: retry_delay [33266,33277]
===
match
---
fstring_expr [44949,44963]
fstring_expr [45001,45015]
===
match
---
name: cmd [18385,18388]
name: cmd [18385,18388]
===
match
---
name: job_id [5251,5257]
name: job_id [5251,5257]
===
match
---
name: error [56070,56075]
name: error [56122,56127]
===
match
---
operator: == [78978,78980]
operator: == [79030,79032]
===
match
---
name: jobs [7276,7280]
name: jobs [7276,7280]
===
match
---
simple_stmt [3119,3139]
simple_stmt [3119,3139]
===
match
---
name: job_id [5167,5173]
name: job_id [5167,5173]
===
match
---
funcdef [51904,52266]
funcdef [51956,52318]
===
match
---
name: dag_id [77654,77660]
name: dag_id [77706,77712]
===
match
---
suite [4063,4098]
suite [4063,4098]
===
match
---
name: task [52892,52896]
name: task [52944,52948]
===
match
---
atom [24953,24986]
atom [24953,24986]
===
match
---
trailer [52598,52603]
trailer [52650,52655]
===
match
---
trailer [77284,77290]
trailer [77336,77342]
===
match
---
operator: = [15791,15792]
operator: = [15791,15792]
===
match
---
name: session [39850,39857]
name: session [39850,39857]
===
match
---
simple_stmt [5974,5992]
simple_stmt [5974,5992]
===
match
---
name: max_tries [22337,22346]
name: max_tries [22337,22346]
===
match
---
name: task [51954,51958]
name: task [52006,52010]
===
match
---
name: SUCCESS [29027,29034]
name: SUCCESS [29027,29034]
===
match
---
name: extend [18221,18227]
name: extend [18221,18227]
===
match
---
operator: , [8470,8471]
operator: , [8470,8471]
===
match
---
expr_stmt [9556,9610]
expr_stmt [9556,9610]
===
match
---
param [14292,14306]
param [14292,14306]
===
match
---
name: Optional [35944,35952]
name: Optional [35944,35952]
===
match
---
param [3870,3883]
param [3870,3883]
===
match
---
atom_expr [79387,79414]
atom_expr [79439,79466]
===
match
---
decorator [13271,13281]
decorator [13271,13281]
===
match
---
name: execution_date [46164,46178]
name: execution_date [46216,46230]
===
match
---
name: context [52126,52133]
name: context [52178,52185]
===
match
---
simple_stmt [5940,5962]
simple_stmt [5940,5962]
===
match
---
trailer [71879,71890]
trailer [71931,71942]
===
match
---
suite [35126,35542]
suite [35126,35542]
===
match
---
trailer [6759,6949]
trailer [6759,6949]
===
match
---
operator: , [37813,37814]
operator: , [37813,37814]
===
match
---
atom_expr [19181,19212]
atom_expr [19181,19212]
===
match
---
simple_stmt [59952,59988]
simple_stmt [60004,60040]
===
match
---
name: Session [74707,74714]
name: Session [74759,74766]
===
match
---
name: render_k8s_pod_yaml [67397,67416]
name: render_k8s_pod_yaml [67449,67468]
===
match
---
name: airflow [66176,66183]
name: airflow [66228,66235]
===
match
---
fstring_expr [42864,42877]
fstring_expr [42916,42929]
===
match
---
name: self [63928,63932]
name: self [63980,63984]
===
match
---
name: dep_status [32837,32847]
name: dep_status [32837,32847]
===
match
---
operator: = [9798,9799]
operator: = [9798,9799]
===
match
---
name: task_id_by_key [6001,6015]
name: task_id_by_key [6001,6015]
===
match
---
simple_stmt [59651,59679]
simple_stmt [59703,59731]
===
match
---
simple_stmt [80878,80902]
simple_stmt [80930,80954]
===
match
---
name: operator [10116,10124]
name: operator [10116,10124]
===
match
---
parameters [53341,53759]
parameters [53393,53811]
===
match
---
simple_stmt [14835,14847]
simple_stmt [14835,14847]
===
match
---
trailer [77744,77750]
trailer [77796,77802]
===
match
---
atom_expr [59213,59306]
atom_expr [59265,59358]
===
match
---
trailer [45330,45344]
trailer [45382,45396]
===
match
---
string: 'dag' [64528,64533]
string: 'dag' [64580,64585]
===
match
---
atom_expr [48258,48267]
atom_expr [48310,48319]
===
match
---
trailer [23882,23889]
trailer [23882,23889]
===
match
---
operator: == [78776,78778]
operator: == [78828,78830]
===
match
---
operator: @ [32250,32251]
operator: @ [32250,32251]
===
match
---
name: self [24713,24717]
name: self [24713,24717]
===
match
---
decorator [19371,19381]
decorator [19371,19381]
===
match
---
operator: @ [13181,13182]
operator: @ [13181,13182]
===
match
---
name: add [45475,45478]
name: add [45527,45530]
===
match
---
name: self [81240,81244]
name: self [81292,81296]
===
match
---
name: sanitized_pod [69067,69080]
name: sanitized_pod [69119,69132]
===
match
---
operator: = [26468,26469]
operator: = [26468,26469]
===
match
---
name: tis [7670,7673]
name: tis [7670,7673]
===
match
---
trailer [34679,34695]
trailer [34679,34695]
===
match
---
trailer [9959,9964]
trailer [9959,9964]
===
match
---
name: ti [5500,5502]
name: ti [5500,5502]
===
match
---
subscriptlist [78012,78043]
subscriptlist [78064,78095]
===
match
---
trailer [40190,40201]
trailer [40190,40201]
===
match
---
name: self [55893,55897]
name: self [55945,55949]
===
match
---
operator: , [56060,56061]
operator: , [56112,56113]
===
match
---
parameters [59385,59391]
parameters [59437,59443]
===
match
---
simple_stmt [80109,80157]
simple_stmt [80161,80209]
===
match
---
operator: , [74267,74268]
operator: , [74319,74320]
===
match
---
operator: -> [59768,59770]
operator: -> [59820,59822]
===
match
---
name: use_default [70508,70519]
name: use_default [70560,70571]
===
match
---
if_stmt [5119,5992]
if_stmt [5119,5992]
===
match
---
param [51954,51958]
param [52006,52010]
===
match
---
atom_expr [58286,58655]
atom_expr [58338,58707]
===
match
---
name: execution_date [64688,64702]
name: execution_date [64740,64754]
===
match
---
trailer [22815,22850]
trailer [22815,22850]
===
match
---
name: dep_status [32882,32892]
name: dep_status [32882,32892]
===
match
---
trailer [79796,79804]
trailer [79848,79856]
===
match
---
atom_expr [32080,32097]
atom_expr [32080,32097]
===
match
---
atom_expr [27826,27878]
atom_expr [27826,27878]
===
match
---
name: self [12625,12629]
name: self [12625,12629]
===
match
---
name: filter [23858,23864]
name: filter [23858,23864]
===
match
---
simple_stmt [7833,7858]
simple_stmt [7833,7858]
===
match
---
trailer [18070,18077]
trailer [18070,18077]
===
match
---
atom_expr [55594,55630]
atom_expr [55646,55682]
===
match
---
operator: @ [53313,53314]
operator: @ [53365,53366]
===
match
---
operator: = [51513,51514]
operator: = [51565,51566]
===
match
---
name: Column [9999,10005]
name: Column [9999,10005]
===
match
---
trailer [49376,49383]
trailer [49428,49435]
===
match
---
atom_expr [56077,56098]
atom_expr [56129,56150]
===
match
---
name: session [25972,25979]
name: session [25972,25979]
===
match
---
name: task_id [68487,68494]
name: task_id [68539,68546]
===
match
---
trailer [52871,52876]
trailer [52923,52928]
===
match
---
name: self [42756,42760]
name: self [42725,42729]
===
match
---
name: dep_status [32696,32706]
name: dep_status [32696,32706]
===
match
---
trailer [18633,18640]
trailer [18633,18640]
===
match
---
arglist [33840,33903]
arglist [33840,33903]
===
match
---
parameters [81016,81022]
parameters [81068,81074]
===
match
---
name: total_seconds [34570,34583]
name: total_seconds [34570,34583]
===
match
---
comparison [14631,14664]
comparison [14631,14664]
===
match
---
trailer [42628,42646]
trailer [42597,42615]
===
match
---
name: dill [1142,1146]
name: dill [1142,1146]
===
match
---
trailer [35510,35512]
trailer [35510,35512]
===
match
---
trailer [10102,10111]
trailer [10102,10111]
===
match
---
name: self [23381,23385]
name: self [23381,23385]
===
match
---
suite [69208,72412]
suite [69260,72464]
===
match
---
name: utils [2763,2768]
name: utils [2763,2768]
===
match
---
param [67087,67091]
param [67139,67143]
===
match
---
name: DagRun [82567,82573]
name: DagRun [82619,82625]
===
match
---
name: e [44267,44268]
name: e [44319,44320]
===
match
---
name: State [58150,58155]
name: State [58202,58207]
===
match
---
string: '\n' [69500,69504]
string: '\n' [69552,69556]
===
match
---
name: state [27866,27871]
name: state [27866,27871]
===
match
---
operator: { [46980,46981]
operator: { [47032,47033]
===
match
---
name: sqlalchemy [1355,1365]
name: sqlalchemy [1355,1365]
===
match
---
name: _date_or_empty [45316,45330]
name: _date_or_empty [45368,45382]
===
match
---
operator: , [16021,16022]
operator: , [16021,16022]
===
match
---
trailer [60326,60333]
trailer [60378,60385]
===
match
---
suite [43304,43949]
suite [43356,44001]
===
match
---
atom_expr [24031,24047]
atom_expr [24031,24047]
===
match
---
trailer [35051,35053]
trailer [35051,35053]
===
match
---
simple_stmt [3540,3554]
simple_stmt [3540,3554]
===
match
---
name: check_and_change_state_before_execution [35572,35611]
name: check_and_change_state_before_execution [35572,35611]
===
match
---
name: bool [59120,59124]
name: bool [59172,59176]
===
match
---
trailer [35408,35415]
trailer [35408,35415]
===
match
---
name: models [66184,66190]
name: models [66236,66242]
===
match
---
operator: @ [81537,81538]
operator: @ [81589,81590]
===
match
---
name: self [23793,23797]
name: self [23793,23797]
===
match
---
string: "--pickle" [18079,18089]
string: "--pickle" [18079,18089]
===
match
---
operator: , [39144,39145]
operator: , [39144,39145]
===
match
---
name: Environment [71012,71023]
name: Environment [71064,71075]
===
match
---
trailer [26300,26303]
trailer [26300,26303]
===
match
---
atom_expr [80456,80474]
atom_expr [80508,80526]
===
match
---
operator: = [42709,42710]
operator: = [42678,42679]
===
match
---
operator: -> [72799,72801]
operator: -> [72851,72853]
===
match
---
string: """Load and return error from error file""" [3925,3968]
string: """Load and return error from error file""" [3925,3968]
===
match
---
name: lock_for_update [43501,43516]
name: lock_for_update [43553,43568]
===
match
---
trailer [20310,20318]
trailer [20310,20318]
===
match
---
operator: @ [25036,25037]
operator: @ [25036,25037]
===
match
---
atom_expr [33256,33277]
atom_expr [33256,33277]
===
match
---
name: exception [52214,52223]
name: exception [52266,52275]
===
match
---
name: value [77076,77081]
name: value [77128,77133]
===
match
---
atom_expr [24616,24633]
atom_expr [24616,24633]
===
match
---
name: render [71191,71197]
name: render [71243,71249]
===
match
---
name: prev_execution_date [61770,61789]
name: prev_execution_date [61822,61841]
===
match
---
name: _Variable__NO_DEFAULT_SENTINEL [64253,64283]
name: _Variable__NO_DEFAULT_SENTINEL [64305,64335]
===
match
---
trailer [6921,6923]
trailer [6921,6923]
===
match
---
atom_expr [9724,9742]
atom_expr [9724,9742]
===
match
---
operator: -> [29185,29187]
operator: -> [29185,29187]
===
match
---
atom_expr [28731,28978]
atom_expr [28731,28978]
===
match
---
name: should_pass_filepath [14550,14570]
name: should_pass_filepath [14550,14570]
===
match
---
operator: , [50094,50095]
operator: , [50146,50147]
===
match
---
name: or_ [1346,1349]
name: or_ [1346,1349]
===
match
---
expr_stmt [22507,22543]
expr_stmt [22507,22543]
===
match
---
operator: , [77845,77846]
operator: , [77897,77898]
===
match
---
name: task_id [17951,17958]
name: task_id [17951,17958]
===
match
---
atom_expr [9500,9532]
atom_expr [9500,9532]
===
match
---
operator: = [52343,52344]
operator: = [52395,52396]
===
match
---
argument [30855,30874]
argument [30855,30874]
===
match
---
name: prev_ds [61714,61721]
name: prev_ds [61766,61773]
===
match
---
atom_expr [68790,68810]
atom_expr [68842,68862]
===
match
---
tfpdef [4237,4265]
tfpdef [4237,4265]
===
match
---
name: dag_id [26053,26059]
name: dag_id [26053,26059]
===
match
---
expr_stmt [39227,39271]
expr_stmt [39227,39271]
===
match
---
atom_expr [21515,21722]
atom_expr [21515,21722]
===
match
---
name: base_worker_pod [68925,68940]
name: base_worker_pod [68977,68992]
===
match
---
param [68206,68210]
param [68258,68262]
===
match
---
suite [44199,44339]
suite [44251,44391]
===
match
---
arglist [62262,62269]
arglist [62314,62321]
===
match
---
parameters [51128,51154]
parameters [51180,51206]
===
match
---
name: max_tries [5873,5882]
name: max_tries [5873,5882]
===
match
---
name: property [28503,28511]
name: property [28503,28511]
===
match
---
name: String [10061,10067]
name: String [10061,10067]
===
match
---
trailer [79063,79070]
trailer [79115,79122]
===
match
---
arglist [9500,9550]
arglist [9500,9550]
===
match
---
simple_stmt [10833,11023]
simple_stmt [10833,11023]
===
match
---
trailer [5905,5926]
trailer [5905,5926]
===
match
---
name: airflow [1879,1886]
name: airflow [1879,1886]
===
match
---
decorator [64096,64110]
decorator [64148,64162]
===
match
---
trailer [42831,42833]
trailer [42883,42885]
===
match
---
not_test [27121,27148]
not_test [27121,27148]
===
match
---
simple_stmt [23515,23546]
simple_stmt [23515,23546]
===
match
---
name: DateTime [30380,30388]
name: DateTime [30380,30388]
===
match
---
operator: , [1434,1435]
operator: , [1434,1435]
===
match
---
atom_expr [33289,33324]
atom_expr [33289,33324]
===
match
---
name: str [29725,29728]
name: str [29725,29728]
===
match
---
name: State [39050,39055]
name: State [39050,39055]
===
match
---
trailer [27290,27294]
trailer [27290,27294]
===
match
---
decorated [13181,13266]
decorated [13181,13266]
===
match
---
name: partial_dag [46571,46582]
name: partial_dag [46623,46634]
===
match
---
trailer [72637,72677]
trailer [72689,72729]
===
match
---
operator: = [5031,5032]
operator: = [5031,5032]
===
match
---
name: self [67087,67091]
name: self [67139,67143]
===
match
---
fstring_start: f" [19658,19660]
fstring_start: f" [19658,19660]
===
match
---
operator: , [35818,35819]
operator: , [35818,35819]
===
match
---
simple_stmt [50669,50696]
simple_stmt [50721,50748]
===
match
---
operator: = [9419,9420]
operator: = [9419,9420]
===
match
---
name: log [43232,43235]
name: log [43284,43287]
===
match
---
name: reschedule_exception [55110,55130]
name: reschedule_exception [55162,55182]
===
match
---
atom_expr [80710,80723]
atom_expr [80762,80775]
===
match
---
if_stmt [18610,18652]
if_stmt [18610,18652]
===
match
---
atom_expr [64727,64738]
atom_expr [64779,64790]
===
match
---
operator: = [43546,43547]
operator: = [43598,43599]
===
match
---
name: self [19330,19334]
name: self [19330,19334]
===
match
---
trailer [40421,40428]
trailer [40421,40428]
===
match
---
suite [14771,14809]
suite [14771,14809]
===
match
---
name: environ [49369,49376]
name: environ [49421,49428]
===
match
---
name: task [27219,27223]
name: task [27219,27223]
===
match
---
name: Stats [56899,56904]
name: Stats [56951,56956]
===
match
---
name: bool [56162,56166]
name: bool [56214,56218]
===
match
---
trailer [27085,27100]
trailer [27085,27100]
===
match
---
dotted_name [1108,1120]
dotted_name [1108,1120]
===
match
---
suite [73962,74170]
suite [74014,74222]
===
match
---
atom_expr [69430,69451]
atom_expr [69482,69503]
===
match
---
trailer [82422,82428]
trailer [82474,82480]
===
match
---
name: self [22801,22805]
name: self [22801,22805]
===
match
---
operator: , [43884,43885]
operator: , [43936,43937]
===
match
---
name: ts [65736,65738]
name: ts [65788,65790]
===
match
---
name: prev_ti [29510,29517]
name: prev_ti [29510,29517]
===
match
---
atom_expr [53814,54245]
atom_expr [53866,54297]
===
match
---
fstring_start: f" [32933,32935]
fstring_start: f" [32933,32935]
===
match
---
name: kube_config [68374,68385]
name: kube_config [68426,68437]
===
match
---
name: file_path [18663,18672]
name: file_path [18663,18672]
===
match
---
param [20596,20608]
param [20596,20608]
===
match
---
not_test [45572,45585]
not_test [45624,45637]
===
match
---
atom_expr [67767,67779]
atom_expr [67819,67831]
===
match
---
name: file_path [15283,15292]
name: file_path [15283,15292]
===
match
---
atom_expr [3490,3522]
atom_expr [3490,3522]
===
match
---
atom_expr [54672,54685]
atom_expr [54724,54737]
===
match
---
name: task [48221,48225]
name: task [48273,48277]
===
match
---
trailer [72917,72926]
trailer [72969,72978]
===
match
---
name: include_direct_upstream [46776,46799]
name: include_direct_upstream [46828,46851]
===
match
---
parameters [81160,81166]
parameters [81212,81218]
===
match
---
suite [63785,63818]
suite [63837,63870]
===
match
---
trailer [40738,40759]
trailer [40738,40759]
===
match
---
name: test_mode [12536,12545]
name: test_mode [12536,12545]
===
match
---
operator: , [59600,59601]
operator: , [59652,59653]
===
match
---
arglist [49575,49588]
arglist [49627,49640]
===
match
---
name: first [21834,21839]
name: first [21834,21839]
===
match
---
suite [4034,4055]
suite [4034,4055]
===
match
---
atom_expr [66425,66462]
atom_expr [66477,66514]
===
match
---
import_from [2700,2749]
import_from [2700,2749]
===
match
---
arglist [3981,3995]
arglist [3981,3995]
===
match
---
name: state [39895,39900]
name: state [39895,39900]
===
match
---
operator: = [29755,29756]
operator: = [29755,29756]
===
match
---
name: set_current_context [3269,3288]
name: set_current_context [3269,3288]
===
match
---
atom_expr [26298,26306]
atom_expr [26298,26306]
===
match
---
name: execution_date [61235,61249]
name: execution_date [61287,61301]
===
match
---
name: conf [19522,19526]
name: conf [19522,19526]
===
match
---
param [11079,11106]
param [11079,11106]
===
match
---
atom_expr [8445,8456]
atom_expr [8445,8456]
===
match
---
name: self [51930,51934]
name: self [51982,51986]
===
match
---
name: self [61230,61234]
name: self [61282,61286]
===
match
---
operator: , [59188,59189]
operator: , [59240,59241]
===
match
---
name: jinja_env [72064,72073]
name: jinja_env [72116,72125]
===
match
---
operator: , [10753,10754]
operator: , [10753,10754]
===
match
---
if_stmt [40693,40761]
if_stmt [40693,40761]
===
match
---
trailer [18220,18227]
trailer [18220,18227]
===
match
---
name: debug [30037,30042]
name: debug [30037,30042]
===
match
---
except_clause [43174,43213]
except_clause [43226,43265]
===
match
---
name: TR [39108,39110]
name: TR [39108,39110]
===
match
---
expr_stmt [51646,51689]
expr_stmt [51698,51741]
===
match
---
trailer [32847,32854]
trailer [32847,32854]
===
match
---
fstring_expr [50631,50652]
fstring_expr [50683,50704]
===
match
---
name: COLLATION_ARGS [1845,1859]
name: COLLATION_ARGS [1845,1859]
===
match
---
trailer [57173,57182]
trailer [57225,57234]
===
match
---
atom_expr [48483,48531]
atom_expr [48535,48583]
===
match
---
name: subject [72132,72139]
name: subject [72184,72191]
===
match
---
if_stmt [58664,58896]
if_stmt [58716,58948]
===
match
---
name: relationship [82602,82614]
name: relationship [82654,82666]
===
match
---
name: info [45067,45071]
name: info [45119,45123]
===
match
---
expr_stmt [79929,79971]
expr_stmt [79981,80023]
===
match
---
trailer [11754,11758]
trailer [11754,11758]
===
match
---
arglist [8497,8519]
arglist [8497,8519]
===
match
---
return_stmt [40447,40459]
return_stmt [40447,40459]
===
match
---
dotted_name [1581,1602]
dotted_name [1581,1602]
===
match
---
name: get_rendered_k8s_spec [67065,67086]
name: get_rendered_k8s_spec [67117,67138]
===
match
---
simple_stmt [3973,3997]
simple_stmt [3973,3997]
===
match
---
trailer [40281,40285]
trailer [40281,40285]
===
match
---
atom_expr [9493,9551]
atom_expr [9493,9551]
===
match
---
arglist [10539,10568]
arglist [10539,10568]
===
match
---
name: session [29554,29561]
name: session [29554,29561]
===
match
---
operator: , [1066,1067]
operator: , [1066,1067]
===
match
---
atom_expr [40804,40812]
atom_expr [42764,42772]
===
match
---
name: self [37736,37740]
name: self [37736,37740]
===
match
---
argument [27849,27864]
argument [27849,27864]
===
match
---
dotted_name [2115,2138]
dotted_name [2115,2138]
===
match
---
simple_stmt [23425,23455]
simple_stmt [23425,23455]
===
match
---
name: expected_state [3626,3640]
name: expected_state [3626,3640]
===
match
---
trailer [14935,14943]
trailer [14935,14943]
===
match
---
name: on_kill [48455,48462]
name: on_kill [48507,48514]
===
match
---
return_stmt [77330,77365]
return_stmt [77382,77417]
===
match
---
operator: == [79199,79201]
operator: == [79251,79253]
===
match
---
string: """Set TI duration""" [72816,72837]
string: """Set TI duration""" [72868,72889]
===
match
---
atom_expr [5134,5147]
atom_expr [5134,5147]
===
match
---
suite [77313,77366]
suite [77365,77418]
===
match
---
trailer [50636,50641]
trailer [50688,50693]
===
match
---
name: where [7184,7189]
name: where [7184,7189]
===
match
---
name: self [62042,62046]
name: self [62094,62098]
===
match
---
simple_stmt [13914,13942]
simple_stmt [13914,13942]
===
match
---
name: self [27961,27965]
name: self [27961,27965]
===
match
---
operator: , [10695,10696]
operator: , [10695,10696]
===
match
---
name: self [40908,40912]
name: self [40877,40881]
===
match
---
operator: = [74204,74205]
operator: = [74256,74257]
===
match
---
name: airflow [2405,2412]
name: airflow [2405,2412]
===
match
---
name: execution_date [11910,11924]
name: execution_date [11910,11924]
===
match
---
name: email_for_state [58239,58254]
name: email_for_state [58291,58306]
===
match
---
trailer [76453,76462]
trailer [76505,76514]
===
match
---
name: e [67054,67055]
name: e [67106,67107]
===
match
---
param [73175,73217]
param [73227,73269]
===
match
---
fstring_end: " [33016,33017]
fstring_end: " [33016,33017]
===
match
---
trailer [55461,55476]
trailer [55513,55528]
===
match
---
trailer [22615,22631]
trailer [22615,22631]
===
match
---
name: finished [24821,24829]
name: finished [24821,24829]
===
match
---
name: duration [22022,22030]
name: duration [22022,22030]
===
match
---
param [64225,64284]
param [64277,64336]
===
match
---
name: engine [41055,41061]
name: engine [41024,41030]
===
match
---
name: state [9716,9721]
name: state [9716,9721]
===
match
---
name: task_id [27966,27973]
name: task_id [27966,27973]
===
match
---
simple_stmt [68273,68365]
simple_stmt [68325,68417]
===
match
---
name: dag_run [62540,62547]
name: dag_run [62592,62599]
===
match
---
name: rendered_k8s_spec [67235,67252]
name: rendered_k8s_spec [67287,67304]
===
match
---
operator: == [77646,77648]
operator: == [77698,77700]
===
match
---
name: session [58963,58970]
name: session [59015,59022]
===
match
---
operator: = [72030,72031]
operator: = [72082,72083]
===
match
---
trailer [78005,78045]
trailer [78057,78097]
===
match
---
name: dag_id [79311,79317]
name: dag_id [79363,79369]
===
match
---
atom_expr [45260,45297]
atom_expr [45312,45349]
===
match
---
name: utcnow [24625,24631]
name: utcnow [24625,24631]
===
match
---
name: run_as_user [23386,23397]
name: run_as_user [23386,23397]
===
match
---
operator: = [56167,56168]
operator: = [56219,56220]
===
match
---
name: min_backoff [34100,34111]
name: min_backoff [34100,34111]
===
match
---
trailer [7652,7659]
trailer [7652,7659]
===
match
---
tfpdef [15955,15974]
tfpdef [15955,15974]
===
match
---
name: self [80637,80641]
name: self [80689,80693]
===
match
---
operator: , [58626,58627]
operator: , [58678,58679]
===
match
---
expr_stmt [79830,79861]
expr_stmt [79882,79913]
===
match
---
name: task [60318,60322]
name: task [60370,60374]
===
match
---
atom_expr [22043,22053]
atom_expr [22043,22053]
===
match
---
operator: = [26759,26760]
operator: = [26759,26760]
===
match
---
param [32305,32322]
param [32305,32322]
===
match
---
expr_stmt [59996,60007]
expr_stmt [60048,60059]
===
match
---
argument [64424,64447]
argument [64476,64499]
===
match
---
name: total_seconds [33622,33635]
name: total_seconds [33622,33635]
===
match
---
subscriptlist [3903,3917]
subscriptlist [3903,3917]
===
match
---
trailer [65171,65264]
trailer [65223,65316]
===
match
---
operator: = [54550,54551]
operator: = [54602,54603]
===
match
---
operator: = [79810,79811]
operator: = [79862,79863]
===
match
---
simple_stmt [69217,69269]
simple_stmt [69269,69321]
===
match
---
param [15545,15570]
param [15545,15570]
===
match
---
trailer [18310,18337]
trailer [18310,18337]
===
match
---
operator: } [56945,56946]
operator: } [56997,56998]
===
match
---
name: NamedTemporaryFile [54322,54340]
name: NamedTemporaryFile [54374,54392]
===
match
---
decorated [45653,48008]
decorated [45705,48060]
===
match
---
string: 'prev_ds' [64983,64992]
string: 'prev_ds' [65035,65044]
===
match
---
name: orm [1465,1468]
name: orm [1465,1468]
===
match
---
operator: , [60054,60055]
operator: , [60106,60107]
===
match
---
trailer [11659,11664]
trailer [11659,11664]
===
match
---
simple_stmt [30028,30077]
simple_stmt [30028,30077]
===
match
---
trailer [82041,82055]
trailer [82093,82107]
===
match
---
name: execution_date [26165,26179]
name: execution_date [26165,26179]
===
match
---
name: task [62296,62300]
name: task [62348,62352]
===
match
---
name: Sentry [2198,2204]
name: Sentry [2198,2204]
===
match
---
atom_expr [40815,40826]
atom_expr [42775,42786]
===
match
---
simple_stmt [77867,77895]
simple_stmt [77919,77947]
===
match
---
operator: == [23980,23982]
operator: == [23980,23982]
===
match
---
trailer [71937,71941]
trailer [71989,71993]
===
match
---
param [11041,11046]
param [11041,11046]
===
match
---
atom_expr [10341,10373]
atom_expr [10341,10373]
===
match
---
name: task [60050,60054]
name: task [60102,60106]
===
match
---
name: self [76491,76495]
name: self [76543,76547]
===
match
---
name: log [49190,49193]
name: log [49242,49245]
===
match
---
name: try_number [12614,12624]
name: try_number [12614,12624]
===
match
---
name: context [53299,53306]
name: context [53351,53358]
===
match
---
operator: } [32999,33000]
operator: } [32999,33000]
===
match
---
trailer [46131,46138]
trailer [46183,46190]
===
match
---
atom_expr [68098,68125]
atom_expr [68150,68177]
===
match
---
name: primaryjoin [10887,10898]
name: primaryjoin [10887,10898]
===
match
---
suite [37975,40460]
suite [37975,40460]
===
match
---
trailer [3506,3513]
trailer [3506,3513]
===
match
---
name: filter [82056,82062]
name: filter [82108,82114]
===
match
---
name: KeyboardInterrupt [44771,44788]
name: KeyboardInterrupt [44823,44840]
===
match
---
operator: = [47422,47423]
operator: = [47474,47475]
===
match
---
atom_expr [5500,5512]
atom_expr [5500,5512]
===
match
---
name: UndefinedError [1245,1259]
name: UndefinedError [1245,1259]
===
match
---
operator: , [48314,48315]
operator: , [48366,48367]
===
match
---
name: ApiClient [3101,3110]
name: ApiClient [3101,3110]
===
match
---
simple_stmt [43011,43072]
simple_stmt [43063,43124]
===
match
---
suite [21030,22851]
suite [21030,22851]
===
match
---
trailer [12535,12545]
trailer [12535,12545]
===
match
---
string: """         Forces the task instance's state to FAILED in the database.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [20619,20781]
string: """         Forces the task instance's state to FAILED in the database.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [20619,20781]
===
match
---
trailer [60698,60710]
trailer [60750,60762]
===
match
---
atom_expr [20383,20402]
atom_expr [20383,20402]
===
match
---
name: non_requeueable_dep_context [38113,38140]
name: non_requeueable_dep_context [38113,38140]
===
match
---
expr_stmt [61990,62021]
expr_stmt [62042,62073]
===
match
---
name: modded_hash [34086,34097]
name: modded_hash [34086,34097]
===
match
---
name: session [57104,57111]
name: session [57156,57163]
===
match
---
param [56150,56175]
param [56202,56227]
===
match
---
atom [70549,70561]
atom [70601,70613]
===
match
---
simple_stmt [10190,10225]
simple_stmt [10190,10225]
===
match
---
operator: { [19351,19352]
operator: { [19351,19352]
===
match
---
atom_expr [23878,23889]
atom_expr [23878,23889]
===
match
---
atom_expr [60653,60710]
atom_expr [60705,60762]
===
match
---
expr_stmt [27714,27777]
expr_stmt [27714,27777]
===
match
---
name: State [65389,65394]
name: State [65441,65446]
===
match
---
name: test_mode [44831,44840]
name: test_mode [44883,44892]
===
match
---
operator: = [53916,53917]
operator: = [53968,53969]
===
match
---
name: task [53125,53129]
name: task [53177,53181]
===
match
---
name: self [56454,56458]
name: self [56506,56510]
===
match
---
trailer [48554,48586]
trailer [48606,48638]
===
match
---
operator: , [15166,15167]
operator: , [15166,15167]
===
match
---
param [80608,80612]
param [80660,80664]
===
match
---
suite [13867,13942]
suite [13867,13942]
===
match
---
operator: { [50631,50632]
operator: { [50683,50684]
===
match
---
suite [54822,55036]
suite [54874,55088]
===
match
---
name: with_try_number [8531,8546]
name: with_try_number [8531,8546]
===
match
---
name: task [5368,5372]
name: task [5368,5372]
===
match
---
name: render [71834,71840]
name: render [71886,71892]
===
match
---
if_stmt [50174,50339]
if_stmt [50226,50391]
===
match
---
argument [27761,27776]
argument [27761,27776]
===
match
---
operator: , [49255,49256]
operator: , [49307,49308]
===
match
---
trailer [44598,44605]
trailer [44650,44657]
===
match
---
import_from [68273,68345]
import_from [68325,68397]
===
match
---
argument [51863,51875]
argument [51915,51927]
===
match
---
atom_expr [48935,49007]
atom_expr [48987,49059]
===
match
---
trailer [68499,68507]
trailer [68551,68559]
===
match
---
atom_expr [52311,52342]
atom_expr [52363,52394]
===
match
---
name: generate_command [15438,15454]
name: generate_command [15438,15454]
===
match
---
name: self [42589,42593]
name: self [42558,42562]
===
match
---
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [43649,43719]
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [43701,43771]
===
match
---
simple_stmt [74179,74406]
simple_stmt [74231,74458]
===
match
---
trailer [68223,68229]
trailer [68275,68281]
===
match
---
name: the_log [18948,18955]
name: the_log [18948,18955]
===
match
---
if_stmt [5161,5259]
if_stmt [5161,5259]
===
match
---
name: state [29015,29020]
name: state [29015,29020]
===
match
---
trailer [7424,7433]
trailer [7424,7433]
===
match
---
name: task [58257,58261]
name: task [58309,58313]
===
match
---
number: 1 [56952,56953]
number: 1 [57004,57005]
===
match
---
operator: = [52954,52955]
operator: = [53006,53007]
===
match
---
operator: -> [80614,80616]
operator: -> [80666,80668]
===
match
---
arglist [44685,44720]
arglist [44737,44772]
===
match
---
name: DepContext [38143,38153]
name: DepContext [38143,38153]
===
match
---
name: Index [10794,10799]
name: Index [10794,10799]
===
match
---
parameters [19114,19120]
parameters [19114,19120]
===
match
---
name: self [47104,47108]
name: self [47156,47160]
===
match
---
not_test [47341,47376]
not_test [47393,47428]
===
match
---
operator: = [18906,18907]
operator: = [18906,18907]
===
match
---
simple_stmt [68409,69019]
simple_stmt [68461,69071]
===
match
---
atom_expr [56359,56373]
atom_expr [56411,56425]
===
match
---
name: is_container [76896,76908]
name: is_container [76948,76960]
===
match
---
trailer [11094,11099]
trailer [11094,11099]
===
match
---
if_stmt [67313,67590]
if_stmt [67365,67642]
===
match
---
name: self [46179,46183]
name: self [46231,46235]
===
match
---
name: _try_number [13246,13257]
name: _try_number [13246,13257]
===
match
---
atom_expr [48445,48464]
atom_expr [48497,48516]
===
match
---
string: 'BASE_LOG_FOLDER' [18997,19014]
string: 'BASE_LOG_FOLDER' [18997,19014]
===
match
---
decorated [80655,80724]
decorated [80707,80776]
===
match
---
name: _safe_date [59526,59536]
name: _safe_date [59578,59588]
===
match
---
dictorsetmaker [65865,65941]
dictorsetmaker [65917,65993]
===
match
---
argument [26824,26839]
argument [26824,26839]
===
match
---
simple_stmt [10116,10148]
simple_stmt [10116,10148]
===
match
---
name: dag [27059,27062]
name: dag [27059,27062]
===
match
---
name: self [82149,82153]
name: self [82201,82205]
===
match
---
with_stmt [48691,50590]
with_stmt [48743,50642]
===
match
---
operator: , [40201,40202]
operator: , [40201,40202]
===
match
---
atom_expr [48981,48993]
atom_expr [49033,49045]
===
match
---
param [29738,29761]
param [29738,29761]
===
match
---
name: mark_success [54415,54427]
name: mark_success [54467,54479]
===
match
---
name: iso [19169,19172]
name: iso [19169,19172]
===
match
---
name: execution_date [23965,23979]
name: execution_date [23965,23979]
===
match
---
suite [66663,67056]
suite [66715,67108]
===
match
---
suite [14313,15411]
suite [14313,15411]
===
match
---
trailer [48782,48799]
trailer [48834,48851]
===
match
---
name: dag_id [68455,68461]
name: dag_id [68507,68513]
===
match
---
name: state [12046,12051]
name: state [12046,12051]
===
match
---
name: defaultdict [5053,5064]
name: defaultdict [5053,5064]
===
match
---
simple_stmt [2288,2365]
simple_stmt [2288,2365]
===
match
---
name: self [30095,30099]
name: self [30095,30099]
===
match
---
name: self [50833,50837]
name: self [50885,50889]
===
match
---
name: task_copy [51144,51153]
name: task_copy [51196,51205]
===
match
---
string: "Exporting the following env vars:\n%s" [49216,49255]
string: "Exporting the following env vars:\n%s" [49268,49307]
===
match
---
atom_expr [29771,29798]
atom_expr [29771,29798]
===
match
---
operator: = [35687,35688]
operator: = [35687,35688]
===
match
---
expr_stmt [80333,80376]
expr_stmt [80385,80428]
===
match
---
atom_expr [81190,81200]
atom_expr [81242,81252]
===
match
---
simple_stmt [60539,60585]
simple_stmt [60591,60637]
===
match
---
param [59537,59542]
param [59589,59594]
===
match
---
expr_stmt [9652,9682]
expr_stmt [9652,9682]
===
match
---
suite [62589,63475]
suite [62641,63527]
===
match
---
fstring_string: &dag_id= [19660,19668]
fstring_string: &dag_id= [19660,19668]
===
match
---
trailer [42883,42891]
trailer [42935,42943]
===
match
---
name: replace [62119,62126]
name: replace [62171,62178]
===
match
---
atom_expr [26113,26137]
atom_expr [26113,26137]
===
match
---
name: UtcDateTime [10173,10184]
name: UtcDateTime [10173,10184]
===
match
---
name: state [20548,20553]
name: state [20548,20553]
===
match
---
trailer [68644,68655]
trailer [68696,68707]
===
match
---
name: Union [74538,74543]
name: Union [74590,74595]
===
match
---
suite [56392,56795]
suite [56444,56847]
===
match
---
string: """Sets the log context.""" [77867,77894]
string: """Sets the log context.""" [77919,77946]
===
match
---
operator: = [64465,64466]
operator: = [64517,64518]
===
match
---
name: registered [49728,49738]
name: registered [49780,49790]
===
match
---
name: helpers [2462,2469]
name: helpers [2462,2469]
===
match
---
operator: = [39828,39829]
operator: = [39828,39829]
===
match
---
simple_stmt [78410,78440]
simple_stmt [78462,78492]
===
match
---
name: self [55311,55315]
name: self [55363,55367]
===
match
---
name: TaskInstance [26088,26100]
name: TaskInstance [26088,26100]
===
match
---
operator: @ [28018,28019]
operator: @ [28018,28019]
===
match
---
name: filter [7607,7613]
name: filter [7607,7613]
===
match
---
name: utcnow [55294,55300]
name: utcnow [55346,55352]
===
match
---
operator: = [46704,46705]
operator: = [46756,46757]
===
match
---
name: self [32219,32223]
name: self [32219,32223]
===
match
---
operator: , [10354,10355]
operator: , [10354,10355]
===
match
---
tfpdef [74581,74602]
tfpdef [74633,74654]
===
match
---
trailer [52623,52643]
trailer [52675,52695]
===
match
---
atom_expr [79870,79890]
atom_expr [79922,79942]
===
match
---
trailer [78886,78890]
trailer [78938,78942]
===
match
---
argument [74281,74299]
argument [74333,74351]
===
match
---
atom_expr [29520,29570]
atom_expr [29520,29570]
===
match
---
import_from [2365,2399]
import_from [2365,2399]
===
match
---
operator: = [46799,46800]
operator: = [46851,46852]
===
match
---
atom_expr [39978,40260]
atom_expr [39978,40260]
===
match
---
trailer [46070,46076]
trailer [46122,46128]
===
match
---
name: __file__ [71088,71096]
name: __file__ [71140,71148]
===
match
---
expr_stmt [54642,54716]
expr_stmt [54694,54768]
===
match
---
name: execution_date [6716,6730]
name: execution_date [6716,6730]
===
match
---
suite [73265,74406]
suite [73317,74458]
===
match
---
operator: , [9591,9592]
operator: , [9591,9592]
===
match
---
name: _task_id [82154,82162]
name: _task_id [82206,82214]
===
match
---
trailer [57124,57183]
trailer [57176,57235]
===
match
---
name: task [64927,64931]
name: task [64979,64983]
===
match
---
dotted_name [7482,7503]
dotted_name [7482,7503]
===
match
---
fstring_string: Skipping mini scheduling run due to exception:  [47857,47904]
fstring_string: Skipping mini scheduling run due to exception:  [47909,47956]
===
match
---
trailer [54677,54685]
trailer [54729,54737]
===
match
---
subscript [82423,82427]
subscript [82475,82479]
===
match
---
atom_expr [34670,34695]
atom_expr [34670,34695]
===
match
---
param [41683,41707]
param [41652,41676]
===
match
---
simple_stmt [42842,42895]
simple_stmt [42894,42947]
===
match
---
simple_stmt [14856,15411]
simple_stmt [14856,15411]
===
match
---
string: """Run TaskInstance""" [53777,53799]
string: """Run TaskInstance""" [53829,53851]
===
match
---
atom_expr [74288,74299]
atom_expr [74340,74351]
===
match
---
trailer [77258,77272]
trailer [77310,77324]
===
match
---
atom_expr [34774,34787]
atom_expr [34774,34787]
===
match
---
name: self [24056,24060]
name: self [24056,24060]
===
match
---
operator: , [59244,59245]
operator: , [59296,59297]
===
match
---
atom [59961,59963]
atom [60013,60015]
===
match
---
atom_expr [16001,16014]
atom_expr [16001,16014]
===
match
---
argument [68455,68473]
argument [68507,68525]
===
match
---
trailer [43855,43870]
trailer [43907,43922]
===
match
---
simple_stmt [3202,3236]
simple_stmt [3202,3236]
===
match
---
operator: = [80049,80050]
operator: = [80101,80102]
===
match
---
return_stmt [41341,41352]
return_stmt [41310,41321]
===
match
---
expr_stmt [42589,42615]
expr_stmt [42558,42584]
===
match
---
operator: , [76672,76673]
operator: , [76724,76725]
===
match
---
operator: , [57129,57130]
operator: , [57181,57182]
===
match
---
trailer [26812,26823]
trailer [26812,26823]
===
match
---
name: context [50566,50573]
name: context [50618,50625]
===
match
---
param [52298,52303]
param [52350,52355]
===
match
---
atom_expr [40662,40678]
atom_expr [40662,40678]
===
match
---
trailer [5981,5987]
trailer [5981,5987]
===
match
---
name: _pool [81195,81200]
name: _pool [81247,81252]
===
match
---
atom_expr [60318,60333]
atom_expr [60370,60385]
===
match
---
name: dag [14791,14794]
name: dag [14791,14794]
===
match
---
name: instance [30273,30281]
name: instance [30273,30281]
===
match
---
name: subject [72372,72379]
name: subject [72424,72431]
===
match
---
trailer [51841,51876]
trailer [51893,51928]
===
match
---
operator: == [53058,53060]
operator: == [53110,53112]
===
match
---
name: self [74255,74259]
name: self [74307,74311]
===
match
---
tfpdef [29738,29754]
tfpdef [29738,29754]
===
match
---
name: self [45599,45603]
name: self [45651,45655]
===
match
---
trailer [58093,58110]
trailer [58145,58162]
===
match
---
atom_expr [54916,54944]
atom_expr [54968,54996]
===
match
---
name: job_id [18167,18173]
name: job_id [18167,18173]
===
match
---
operator: , [15880,15881]
operator: , [15880,15881]
===
match
---
param [56108,56141]
param [56160,56193]
===
match
---
arglist [69438,69450]
arglist [69490,69502]
===
match
---
simple_stmt [58963,58980]
simple_stmt [59015,59032]
===
match
---
trailer [30568,30810]
trailer [30568,30810]
===
match
---
operator: + [19291,19292]
operator: + [19291,19292]
===
match
---
return_stmt [69135,69155]
return_stmt [69187,69207]
===
match
---
name: schedulable_tis [47515,47530]
name: schedulable_tis [47567,47582]
===
match
---
or_test [57788,57833]
or_test [57840,57885]
===
match
---
simple_stmt [847,857]
simple_stmt [847,857]
===
match
---
atom_expr [64073,64081]
atom_expr [64125,64133]
===
match
---
name: task [53276,53280]
name: task [53328,53332]
===
match
---
name: ti [7664,7666]
name: ti [7664,7666]
===
match
---
expr_stmt [42957,42994]
expr_stmt [43009,43046]
===
match
---
name: dep_context [31838,31849]
name: dep_context [31838,31849]
===
match
---
import_from [1018,1102]
import_from [1018,1102]
===
match
---
operator: = [12398,12399]
operator: = [12398,12399]
===
match
---
parameters [54815,54821]
parameters [54867,54873]
===
match
---
trailer [63443,63474]
trailer [63495,63526]
===
match
---
trailer [56472,56502]
trailer [56524,56554]
===
match
---
name: local [15779,15784]
name: local [15779,15784]
===
match
---
name: TR [39113,39115]
name: TR [39113,39115]
===
match
---
trailer [26334,26360]
trailer [26334,26360]
===
match
---
simple_stmt [22556,22578]
simple_stmt [22556,22578]
===
match
---
name: task_id [9411,9418]
name: task_id [9411,9418]
===
match
---
name: bool [15678,15682]
name: bool [15678,15682]
===
match
---
name: timezone [11709,11717]
name: timezone [11709,11717]
===
match
---
trailer [66330,66336]
trailer [66382,66388]
===
match
---
operator: = [68494,68495]
operator: = [68546,68547]
===
match
---
name: session [24372,24379]
name: session [24372,24379]
===
match
---
name: TaskInstance [77626,77638]
name: TaskInstance [77678,77690]
===
match
---
fstring_string: . [44948,44949]
fstring_string: . [45000,45001]
===
match
---
argument [28435,28447]
argument [28435,28447]
===
match
---
expr_stmt [27812,27878]
expr_stmt [27812,27878]
===
match
---
trailer [29540,29570]
trailer [29540,29570]
===
match
---
simple_stmt [78727,78930]
simple_stmt [78779,78982]
===
match
---
simple_stmt [12462,12523]
simple_stmt [12462,12523]
===
match
---
string: 'prev_start_date_success' [65278,65303]
string: 'prev_start_date_success' [65330,65355]
===
match
---
string: """         The task instance for the task that ran before this task instance.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [26518,26746]
string: """         The task instance for the task that ran before this task instance.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [26518,26746]
===
match
---
trailer [22251,22263]
trailer [22251,22263]
===
match
---
name: execution_date [78667,78681]
name: execution_date [78719,78733]
===
match
---
operator: = [80136,80137]
operator: = [80188,80189]
===
match
---
trailer [32969,32977]
trailer [32969,32977]
===
match
---
name: session [41832,41839]
name: session [41801,41808]
===
match
---
trailer [49198,49352]
trailer [49250,49404]
===
match
---
expr_stmt [40769,40795]
expr_stmt [40769,40795]
===
match
---
operator: @ [81138,81139]
operator: @ [81190,81191]
===
match
---
trailer [45482,45500]
trailer [45534,45552]
===
match
---
atom_expr [63939,63980]
atom_expr [63991,64032]
===
match
---
if_stmt [25901,25958]
if_stmt [25901,25958]
===
match
---
atom_expr [68941,69007]
atom_expr [68993,69059]
===
match
---
name: encode [33934,33940]
name: encode [33934,33940]
===
match
---
operator: -> [80768,80770]
operator: -> [80820,80822]
===
match
---
arglist [19242,19265]
arglist [19242,19265]
===
match
---
atom_expr [5471,5483]
atom_expr [5471,5483]
===
match
---
return_stmt [25263,25333]
return_stmt [25263,25333]
===
match
---
operator: , [77660,77661]
operator: , [77712,77713]
===
match
---
suite [5565,5928]
suite [5565,5928]
===
match
---
param [8553,8568]
param [8553,8568]
===
match
---
name: query [76441,76446]
name: query [76493,76498]
===
match
---
name: test_mode [54146,54155]
name: test_mode [54198,54207]
===
match
---
expr_stmt [71322,71412]
expr_stmt [71374,71464]
===
match
---
trailer [6837,6847]
trailer [6837,6847]
===
match
---
name: pickle_id [18095,18104]
name: pickle_id [18095,18104]
===
match
---
name: provide_session [58986,59001]
name: provide_session [59038,59053]
===
match
---
atom_expr [24740,24755]
atom_expr [24740,24755]
===
match
---
name: self [37438,37442]
name: self [37438,37442]
===
match
---
import_from [978,1017]
import_from [978,1017]
===
match
---
string: """         Get datetime of the next retry if the task instance fails. For exponential         backoff, retry_delay is used as base and will be converted to seconds.         """ [33062,33239]
string: """         Get datetime of the next retry if the task instance fails. For exponential         backoff, retry_delay is used as base and will be converted to seconds.         """ [33062,33239]
===
match
---
name: jinja_env [70993,71002]
name: jinja_env [71045,71054]
===
match
---
suite [28054,28497]
suite [28054,28497]
===
match
---
name: tis [4664,4667]
name: tis [4664,4667]
===
match
---
operator: , [73249,73250]
operator: , [73301,73302]
===
match
---
argument [76657,76672]
argument [76709,76724]
===
match
---
expr_stmt [5870,5927]
expr_stmt [5870,5927]
===
match
---
name: task_copy [51338,51347]
name: task_copy [51390,51399]
===
match
---
atom_expr [19059,19071]
atom_expr [19059,19071]
===
match
---
trailer [40907,40913]
trailer [40876,40882]
===
match
---
argument [78642,78712]
argument [78694,78764]
===
match
---
trailer [17888,17898]
trailer [17888,17898]
===
match
---
operator: , [58644,58645]
operator: , [58696,58697]
===
match
---
name: property [13272,13280]
name: property [13272,13280]
===
match
---
name: str [79806,79809]
name: str [79858,79861]
===
match
---
name: self [26416,26420]
name: self [26416,26420]
===
match
---
trailer [24624,24631]
trailer [24624,24631]
===
match
---
name: timeout [2887,2894]
name: timeout [2887,2894]
===
match
---
expr_stmt [72198,72266]
expr_stmt [72250,72318]
===
match
---
name: xcom_push [51832,51841]
name: xcom_push [51884,51893]
===
match
---
atom_expr [42772,42786]
atom_expr [42741,42755]
===
match
---
suite [47377,47471]
suite [47429,47523]
===
match
---
name: log [50789,50792]
name: log [50841,50844]
===
match
---
name: SUCCESS [44584,44591]
name: SUCCESS [44636,44643]
===
match
---
argument [37569,37584]
argument [37569,37584]
===
match
---
atom [18584,18600]
atom [18584,18600]
===
match
---
name: default_var [64424,64435]
name: default_var [64476,64487]
===
match
---
operator: = [14840,14841]
operator: = [14840,14841]
===
match
---
name: self [22845,22849]
name: self [22845,22849]
===
match
---
operator: -> [80687,80689]
operator: -> [80739,80741]
===
match
---
name: job_ids [5233,5240]
name: job_ids [5233,5240]
===
match
---
name: incr [56969,56973]
name: incr [57021,57025]
===
match
---
subscriptlist [4250,4264]
subscriptlist [4250,4264]
===
match
---
expr_stmt [9838,9869]
expr_stmt [9838,9869]
===
match
---
operator: = [22567,22568]
operator: = [22567,22568]
===
match
---
simple_stmt [1615,1813]
simple_stmt [1615,1813]
===
match
---
decorator [23551,23568]
decorator [23551,23568]
===
match
---
name: TaskInstance [77678,77690]
name: TaskInstance [77730,77742]
===
match
---
name: session [73226,73233]
name: session [73278,73285]
===
match
---
operator: , [14046,14047]
operator: , [14046,14047]
===
match
---
name: session [39154,39161]
name: session [39154,39161]
===
match
---
atom_expr [44578,44591]
atom_expr [44630,44643]
===
match
---
dotted_name [7268,7289]
dotted_name [7268,7289]
===
match
---
name: _execution_date [82212,82227]
name: _execution_date [82264,82279]
===
match
---
name: self [74288,74292]
name: self [74340,74344]
===
match
---
operator: = [30958,30959]
operator: = [30958,30959]
===
match
---
trailer [81050,81062]
trailer [81102,81114]
===
match
---
decorator [35547,35564]
decorator [35547,35564]
===
match
---
name: log_message [58400,58411]
name: log_message [58452,58463]
===
match
---
name: self [77649,77653]
name: self [77701,77705]
===
match
---
operator: , [72525,72526]
operator: , [72577,72578]
===
match
---
trailer [49479,49496]
trailer [49531,49548]
===
match
---
if_stmt [18116,18177]
if_stmt [18116,18177]
===
match
---
name: self [11214,11218]
name: self [11214,11218]
===
match
---
name: TaskInstance [82125,82137]
name: TaskInstance [82177,82189]
===
match
---
atom_expr [55398,55645]
atom_expr [55450,55697]
===
match
---
name: ti [22453,22455]
name: ti [22453,22455]
===
match
---
name: ti_hash [33729,33736]
name: ti_hash [33729,33736]
===
match
---
suite [5272,5992]
suite [5272,5992]
===
match
---
trailer [29615,29639]
trailer [29615,29639]
===
match
---
name: ti [79903,79905]
name: ti [79955,79957]
===
match
---
dotted_name [3239,3264]
dotted_name [3239,3264]
===
match
---
name: state [27872,27877]
name: state [27872,27877]
===
match
---
atom_expr [33602,33670]
atom_expr [33602,33670]
===
match
---
simple_stmt [63524,63753]
simple_stmt [63576,63805]
===
match
---
name: self [66488,66492]
name: self [66540,66544]
===
match
---
name: TaskInstance [20352,20364]
name: TaskInstance [20352,20364]
===
match
---
import_from [1576,1614]
import_from [1576,1614]
===
match
---
trailer [52896,52916]
trailer [52948,52968]
===
match
---
operator: , [20334,20335]
operator: , [20334,20335]
===
match
---
atom_expr [58257,58276]
atom_expr [58309,58328]
===
match
---
argument [9791,9800]
argument [9791,9800]
===
match
---
atom_expr [63002,63010]
atom_expr [63054,63062]
===
match
---
name: state [77745,77750]
name: state [77797,77802]
===
match
---
operator: = [19520,19521]
operator: = [19520,19521]
===
match
---
atom_expr [45311,45344]
atom_expr [45363,45396]
===
match
---
trailer [50915,50917]
trailer [50967,50969]
===
match
---
operator: } [67579,67580]
operator: } [67631,67632]
===
match
---
name: renderedtifields [67175,67191]
name: renderedtifields [67227,67243]
===
match
---
name: self [53187,53191]
name: self [53239,53243]
===
match
---
name: key [71841,71844]
name: key [71893,71896]
===
match
---
string: 'BASE_URL' [19255,19265]
string: 'BASE_URL' [19255,19265]
===
match
---
expr_stmt [22684,22717]
expr_stmt [22684,22717]
===
match
---
name: jinja2 [71005,71011]
name: jinja2 [71057,71063]
===
match
---
if_stmt [14603,14847]
if_stmt [14603,14847]
===
match
---
operator: == [21689,21691]
operator: == [21689,21691]
===
match
---
trailer [25315,25331]
trailer [25315,25331]
===
match
---
name: State [40739,40744]
name: State [40739,40744]
===
match
---
name: self [45739,45743]
name: self [45791,45795]
===
match
---
trailer [58888,58894]
trailer [58940,58946]
===
match
---
atom_expr [59916,59942]
atom_expr [59968,59994]
===
match
---
name: datetime [15561,15569]
name: datetime [15561,15569]
===
match
---
name: XCom [77273,77277]
name: XCom [77325,77329]
===
match
---
name: pendulum [1193,1201]
name: pendulum [1193,1201]
===
match
---
name: execution_date [11448,11462]
name: execution_date [11448,11462]
===
match
---
name: email_for_state [58071,58086]
name: email_for_state [58123,58138]
===
match
---
decorated [23551,24092]
decorated [23551,24092]
===
match
---
name: e [47703,47704]
name: e [47755,47756]
===
match
---
fstring_string: __ [62324,62326]
fstring_string: __ [62376,62378]
===
match
---
name: DepContext [32413,32423]
name: DepContext [32413,32423]
===
match
---
argument [68871,68911]
argument [68923,68963]
===
match
---
expr_stmt [60234,60409]
expr_stmt [60286,60461]
===
match
---
name: var [63060,63063]
name: var [63112,63115]
===
match
---
name: sqlalchemy [1454,1464]
name: sqlalchemy [1454,1464]
===
match
---
funcdef [80597,80650]
funcdef [80649,80702]
===
match
---
name: str [8116,8119]
name: str [8116,8119]
===
match
---
sync_comp_for [6993,7040]
sync_comp_for [6993,7040]
===
match
---
trailer [56853,56860]
trailer [56905,56912]
===
match
---
name: NONE [5957,5961]
name: NONE [5957,5961]
===
match
---
arglist [59585,59606]
arglist [59637,59658]
===
match
---
trailer [77795,77802]
trailer [77847,77854]
===
match
---
strings [74009,74111]
strings [74061,74163]
===
match
---
string: 'ti_pool' [10744,10753]
string: 'ti_pool' [10744,10753]
===
match
---
name: self [24249,24253]
name: self [24249,24253]
===
match
---
name: self [66331,66335]
name: self [66383,66387]
===
match
---
name: self [80109,80113]
name: self [80161,80165]
===
match
---
arglist [20246,20403]
arglist [20246,20403]
===
match
---
operator: , [34750,34751]
operator: , [34750,34751]
===
match
---
operator: , [30773,30774]
operator: , [30773,30774]
===
match
---
operator: = [80005,80006]
operator: = [80057,80058]
===
match
---
trailer [34583,34585]
trailer [34583,34585]
===
match
---
argument [15283,15297]
argument [15283,15297]
===
match
---
name: log [49944,49947]
name: log [49996,49999]
===
match
---
name: jinja_env [71152,71161]
name: jinja_env [71204,71213]
===
match
---
trailer [38613,38615]
trailer [38613,38615]
===
match
---
funcdef [80836,80902]
funcdef [80888,80954]
===
match
---
argument [15250,15269]
argument [15250,15269]
===
match
---
parameters [59536,59558]
parameters [59588,59610]
===
match
---
atom_expr [79903,79920]
atom_expr [79955,79972]
===
match
---
trailer [40352,40359]
trailer [40352,40359]
===
match
---
trailer [66578,66595]
trailer [66630,66647]
===
match
---
simple_stmt [80432,80475]
simple_stmt [80484,80527]
===
match
---
trailer [50886,50897]
trailer [50938,50949]
===
match
---
name: pool_override [22890,22903]
name: pool_override [22890,22903]
===
match
---
trailer [28998,29014]
trailer [28998,29014]
===
match
---
name: Exception [56088,56097]
name: Exception [56140,56149]
===
match
---
param [81330,81334]
param [81382,81386]
===
match
---
name: error_file [44710,44720]
name: error_file [44762,44772]
===
match
---
try_stmt [4059,4199]
try_stmt [4059,4199]
===
match
---
operator: , [15269,15270]
operator: , [15269,15270]
===
match
---
fstring_start: f' [56910,56912]
fstring_start: f' [56962,56964]
===
match
---
param [15654,15691]
param [15654,15691]
===
match
---
atom_expr [52892,52916]
atom_expr [52944,52968]
===
match
---
operator: = [72558,72559]
operator: = [72610,72611]
===
match
---
name: self [23281,23285]
name: self [23281,23285]
===
match
---
suite [52359,53308]
suite [52411,53360]
===
match
---
name: str [15970,15973]
name: str [15970,15973]
===
match
---
suite [45952,47664]
suite [46004,47716]
===
match
---
name: kubernetes_helper_functions [68297,68324]
name: kubernetes_helper_functions [68349,68376]
===
match
---
simple_stmt [13876,13906]
simple_stmt [13876,13906]
===
match
---
name: set_current_context [50388,50407]
name: set_current_context [50440,50459]
===
match
---
name: Optional [73191,73199]
name: Optional [73243,73251]
===
match
---
atom_expr [37736,37746]
atom_expr [37736,37746]
===
match
---
string: "%d downstream tasks scheduled from follow-on schedule check" [47562,47623]
string: "%d downstream tasks scheduled from follow-on schedule check" [47614,47675]
===
match
---
trailer [71074,71079]
trailer [71126,71131]
===
match
---
name: ti [79359,79361]
name: ti [79411,79413]
===
match
---
name: test_mode [56316,56325]
name: test_mode [56368,56377]
===
match
---
name: self [55932,55936]
name: self [55984,55988]
===
match
---
name: state [22059,22064]
name: state [22059,22064]
===
match
---
string: """Get the email subject content for exceptions.""" [69217,69268]
string: """Get the email subject content for exceptions.""" [69269,69320]
===
match
---
name: self [45528,45532]
name: self [45580,45584]
===
match
---
param [4220,4236]
param [4220,4236]
===
match
---
name: debug [31765,31770]
name: debug [31765,31770]
===
match
---
string: '' [62149,62151]
string: '' [62201,62203]
===
match
---
operator: = [59959,59960]
operator: = [60011,60012]
===
match
---
operator: = [54145,54146]
operator: = [54197,54198]
===
match
---
trailer [82405,82407]
trailer [82457,82459]
===
match
---
name: force_fail [59278,59288]
name: force_fail [59330,59340]
===
match
---
trailer [11485,11493]
trailer [11485,11493]
===
match
---
atom_expr [53231,53251]
atom_expr [53283,53303]
===
match
---
atom_expr [18002,18032]
atom_expr [18002,18032]
===
match
---
expr_stmt [8054,8069]
expr_stmt [8054,8069]
===
match
---
string: 'start_date' [43871,43883]
string: 'start_date' [43923,43935]
===
match
---
operator: , [3157,3158]
operator: , [3157,3158]
===
match
---
argument [10978,10991]
argument [10978,10991]
===
match
---
trailer [9737,9741]
trailer [9737,9741]
===
match
---
decorator [45653,45670]
decorator [45705,45722]
===
match
---
string: 'run_as_user' [80228,80241]
string: 'run_as_user' [80280,80293]
===
match
---
return_stmt [63048,63063]
return_stmt [63100,63115]
===
match
---
simple_stmt [82398,82446]
simple_stmt [82450,82498]
===
match
---
name: self [8228,8232]
name: self [8228,8232]
===
match
---
string: 'params' [64953,64961]
string: 'params' [65005,65013]
===
match
---
operator: = [22451,22452]
operator: = [22451,22452]
===
match
---
trailer [61898,61907]
trailer [61950,61959]
===
match
---
trailer [21772,21788]
trailer [21772,21788]
===
match
---
name: UtcDateTime [9670,9681]
name: UtcDateTime [9670,9681]
===
match
---
name: isoformat [19490,19499]
name: isoformat [19490,19499]
===
match
---
trailer [21981,21990]
trailer [21981,21990]
===
match
---
string: "--raw" [18642,18649]
string: "--raw" [18642,18649]
===
match
---
name: Exception [56426,56435]
name: Exception [56478,56487]
===
match
---
name: next_ds_nodash [61461,61475]
name: next_ds_nodash [61513,61527]
===
match
---
argument [27975,27990]
argument [27975,27990]
===
match
---
name: yesterday_ds_nodash [66034,66053]
name: yesterday_ds_nodash [66086,66105]
===
match
---
trailer [67281,67298]
trailer [67333,67350]
===
match
---
parameters [8292,8298]
parameters [8292,8298]
===
match
---
trailer [30563,30568]
trailer [30563,30568]
===
match
---
arglist [50798,50837]
arglist [50850,50889]
===
match
---
name: self [80710,80714]
name: self [80762,80766]
===
match
---
or_test [27587,27637]
or_test [27587,27637]
===
match
---
name: DagRun [7693,7699]
name: DagRun [7693,7699]
===
match
---
name: dag [47434,47437]
name: dag [47486,47489]
===
match
---
param [80851,80855]
param [80903,80907]
===
match
---
expr_stmt [17868,17900]
expr_stmt [17868,17900]
===
match
---
name: refresh_from_db [37553,37568]
name: refresh_from_db [37553,37568]
===
match
---
tfpdef [35867,35885]
tfpdef [35867,35885]
===
match
---
operator: , [71683,71684]
operator: , [71735,71736]
===
match
---
name: task [42564,42568]
name: task [42533,42537]
===
match
---
name: self [41409,41413]
name: self [41378,41382]
===
match
---
name: test_mode [40871,40880]
name: test_mode [40840,40849]
===
match
---
param [41377,41382]
param [41346,41351]
===
match
---
operator: , [70900,70901]
operator: , [70952,70953]
===
match
---
name: Union [3897,3902]
name: Union [3897,3902]
===
match
---
expr_stmt [10833,11022]
expr_stmt [10833,11022]
===
match
---
argument [30787,30799]
argument [30787,30799]
===
match
---
name: settings [41046,41054]
name: settings [41015,41023]
===
match
---
name: get_template_context [71461,71481]
name: get_template_context [71513,71533]
===
match
---
name: e [47905,47906]
name: e [47957,47958]
===
match
---
name: ti [48889,48891]
name: ti [48941,48943]
===
match
---
name: NamedTuple [7928,7938]
name: NamedTuple [7928,7938]
===
match
---
trailer [68597,68608]
trailer [68649,68660]
===
match
---
name: self [70932,70936]
name: self [70984,70988]
===
match
---
name: ti [5903,5905]
name: ti [5903,5905]
===
match
---
atom_expr [33867,33886]
atom_expr [33867,33886]
===
match
---
trailer [53066,53079]
trailer [53118,53131]
===
match
---
name: ti [22249,22251]
name: ti [22249,22251]
===
match
---
name: end_date [72854,72862]
name: end_date [72906,72914]
===
match
---
expr_stmt [37431,37447]
expr_stmt [37431,37447]
===
match
---
string: 'ti' [70550,70554]
string: 'ti' [70602,70606]
===
match
---
name: Optional [15961,15969]
name: Optional [15961,15969]
===
match
---
name: self [8101,8105]
name: self [8101,8105]
===
match
---
name: session [29562,29569]
name: session [29562,29569]
===
match
---
name: queued_by_job_id [10190,10206]
name: queued_by_job_id [10190,10206]
===
match
---
operator: = [37528,37529]
operator: = [37528,37529]
===
match
---
name: ignore_task_deps [39691,39707]
name: ignore_task_deps [39691,39707]
===
match
---
name: self [40537,40541]
name: self [40537,40541]
===
match
---
name: LoggingMixin [2534,2546]
name: LoggingMixin [2534,2546]
===
match
---
name: execution_date [24281,24295]
name: execution_date [24281,24295]
===
match
---
simple_stmt [52772,52806]
simple_stmt [52824,52858]
===
match
---
trailer [47996,48005]
trailer [48048,48057]
===
match
---
name: try_number [70886,70896]
name: try_number [70938,70948]
===
match
---
trailer [74557,74562]
trailer [74609,74614]
===
match
---
operator: , [19840,19841]
operator: , [19840,19841]
===
match
---
trailer [63806,63810]
trailer [63858,63862]
===
match
---
simple_stmt [38985,39021]
simple_stmt [38985,39021]
===
match
---
simple_stmt [2365,2400]
simple_stmt [2365,2400]
===
match
---
suite [51366,51620]
suite [51418,51672]
===
match
---
name: XCom [74179,74183]
name: XCom [74231,74235]
===
match
---
trailer [40550,40616]
trailer [40550,40616]
===
match
---
atom_expr [68977,69006]
atom_expr [69029,69058]
===
match
---
operator: } [19680,19681]
operator: } [19680,19681]
===
match
---
tfpdef [73175,73209]
tfpdef [73227,73261]
===
match
---
funcdef [24340,25031]
funcdef [24340,25031]
===
match
---
operator: , [54182,54183]
operator: , [54234,54235]
===
match
---
simple_stmt [23234,23273]
simple_stmt [23234,23273]
===
match
---
atom_expr [31908,32112]
atom_expr [31908,32112]
===
match
---
name: __repr__ [63081,63089]
name: __repr__ [63133,63141]
===
match
---
atom_expr [40414,40430]
atom_expr [40414,40430]
===
match
---
name: end_date [56834,56842]
name: end_date [56886,56894]
===
match
---
atom_expr [82408,82436]
atom_expr [82460,82488]
===
match
---
name: Column [9573,9579]
name: Column [9573,9579]
===
match
---
name: execution_date [32985,32999]
name: execution_date [32985,32999]
===
match
---
trailer [10347,10373]
trailer [10347,10373]
===
match
---
operator: , [45493,45494]
operator: , [45545,45546]
===
match
---
simple_stmt [4731,4995]
simple_stmt [4731,4995]
===
match
---
operator: @ [19089,19090]
operator: @ [19089,19090]
===
match
---
name: self [50940,50944]
name: self [50992,50996]
===
match
---
atom_expr [79418,79435]
atom_expr [79470,79487]
===
match
---
atom_expr [72213,72266]
atom_expr [72265,72318]
===
match
---
name: str [79609,79612]
name: str [79661,79664]
===
match
---
simple_stmt [22644,22672]
simple_stmt [22644,22672]
===
match
---
trailer [45377,45389]
trailer [45429,45441]
===
match
---
atom_expr [5885,5927]
atom_expr [5885,5927]
===
match
---
name: self [64073,64077]
name: self [64125,64129]
===
match
---
trailer [67899,67906]
trailer [67951,67958]
===
match
---
name: partial_subset [46599,46613]
name: partial_subset [46651,46665]
===
match
---
name: task [52587,52591]
name: task [52639,52643]
===
match
---
trailer [7849,7857]
trailer [7849,7857]
===
match
---
if_stmt [26783,27992]
if_stmt [26783,27992]
===
match
---
atom_expr [64244,64283]
atom_expr [64296,64335]
===
match
---
name: schedulable_tis [47206,47221]
name: schedulable_tis [47258,47273]
===
match
---
name: include_prior_dates [76604,76623]
name: include_prior_dates [76656,76675]
===
match
---
name: task [23531,23535]
name: task [23531,23535]
===
match
---
name: t [78905,78906]
name: t [78957,78958]
===
match
---
operator: = [74603,74604]
operator: = [74655,74656]
===
match
---
name: prev_attempted_tries [5906,5926]
name: prev_attempted_tries [5906,5926]
===
match
---
atom_expr [4331,4353]
atom_expr [4331,4353]
===
match
---
trailer [7225,7237]
trailer [7225,7237]
===
match
---
name: job [7318,7321]
name: job [7318,7321]
===
match
---
trailer [66454,66460]
trailer [66506,66512]
===
match
---
import_name [847,856]
import_name [847,856]
===
match
---
operator: , [30931,30932]
operator: , [30931,30932]
===
match
---
operator: @ [64096,64097]
operator: @ [64148,64149]
===
match
---
name: cmd [18630,18633]
name: cmd [18630,18633]
===
match
---
tfpdef [41790,41815]
tfpdef [41759,41784]
===
match
---
operator: = [68711,68712]
operator: = [68763,68764]
===
match
---
name: Variable [63013,63021]
name: Variable [63065,63073]
===
match
---
trailer [7362,7365]
trailer [7362,7365]
===
match
---
name: task [68140,68144]
name: task [68192,68196]
===
match
---
funcdef [67926,68177]
funcdef [67978,68229]
===
match
---
funcdef [66070,67056]
funcdef [66122,67108]
===
match
---
trailer [82211,82227]
trailer [82263,82279]
===
match
---
name: ignore_depends_on_past [53969,53991]
name: ignore_depends_on_past [54021,54043]
===
match
---
name: cfg_path [15991,15999]
name: cfg_path [15991,15999]
===
match
---
parameters [69190,69207]
parameters [69242,69259]
===
match
---
operator: , [59288,59289]
operator: , [59340,59341]
===
match
---
trailer [21833,21839]
trailer [21833,21839]
===
match
---
name: error_file [56184,56194]
name: error_file [56236,56246]
===
match
---
operator: + [5529,5530]
operator: + [5529,5530]
===
match
---
operator: , [74609,74610]
operator: , [74661,74662]
===
match
---
atom_expr [56537,56564]
atom_expr [56589,56616]
===
match
---
name: task [52101,52105]
name: task [52153,52157]
===
match
---
trailer [68988,69006]
trailer [69040,69058]
===
match
---
name: session [60479,60486]
name: session [60531,60538]
===
match
---
name: on_retry_callback [53130,53147]
name: on_retry_callback [53182,53199]
===
match
---
operator: , [8701,8702]
operator: , [8701,8702]
===
match
---
name: tis [79156,79159]
name: tis [79208,79211]
===
match
---
arglist [47855,47954]
arglist [47907,48006]
===
match
---
name: dagrun [35300,35306]
name: dagrun [35300,35306]
===
match
---
simple_stmt [30555,30811]
simple_stmt [30555,30811]
===
match
---
name: self [81017,81021]
name: self [81069,81073]
===
match
---
name: State [53061,53066]
name: State [53113,53118]
===
match
---
name: self [14931,14935]
name: self [14931,14935]
===
match
---
name: self [19406,19410]
name: self [19406,19410]
===
match
---
trailer [20804,20845]
trailer [20804,20845]
===
match
---
decorator [41580,41602]
decorator [41549,41571]
===
match
---
string: """Fetch rendered template fields from DB""" [66118,66162]
string: """Fetch rendered template fields from DB""" [66170,66214]
===
match
---
operator: = [38141,38142]
operator: = [38141,38142]
===
match
---
decorated [28502,29036]
decorated [28502,29036]
===
match
---
name: dict [71535,71539]
name: dict [71587,71591]
===
match
---
trailer [33260,33265]
trailer [33260,33265]
===
match
---
name: e [43465,43466]
name: e [43517,43518]
===
match
---
operator: += [40679,40681]
operator: += [40679,40681]
===
match
---
operator: = [19173,19174]
operator: = [19173,19174]
===
match
---
operator: { [49290,49291]
operator: { [49342,49343]
===
match
---
operator: == [6808,6810]
operator: == [6808,6810]
===
match
---
name: dag_id [78334,78340]
name: dag_id [78386,78392]
===
match
---
name: path [18961,18965]
name: path [18961,18965]
===
match
---
name: session [26832,26839]
name: session [26832,26839]
===
match
---
operator: , [56216,56217]
operator: , [56268,56269]
===
match
---
string: 'Marking task as SKIPPED. ' [43605,43632]
string: 'Marking task as SKIPPED. ' [43657,43684]
===
match
---
trailer [60269,60275]
trailer [60321,60327]
===
match
---
name: get_template_env [71798,71814]
name: get_template_env [71850,71866]
===
match
---
atom_expr [6001,6076]
atom_expr [6001,6076]
===
match
---
name: items [6916,6921]
name: items [6916,6921]
===
match
---
decorator [80988,80998]
decorator [81040,81050]
===
match
---
expr_stmt [80109,80156]
expr_stmt [80161,80208]
===
match
---
name: task_ids [47057,47065]
name: task_ids [47109,47117]
===
match
---
atom_expr [6640,7058]
atom_expr [6640,7058]
===
match
---
trailer [26823,26840]
trailer [26823,26840]
===
match
---
name: Column [9919,9925]
name: Column [9919,9925]
===
match
---
decorator [30881,30898]
decorator [30881,30898]
===
match
---
atom_expr [56196,56209]
atom_expr [56248,56261]
===
match
---
name: dag_id [79298,79304]
name: dag_id [79350,79356]
===
match
---
name: extend [18634,18640]
name: extend [18634,18640]
===
match
---
name: self [68462,68466]
name: self [68514,68518]
===
match
---
parameters [63846,63910]
parameters [63898,63962]
===
match
---
name: session [36010,36017]
name: session [36010,36017]
===
match
---
operator: = [59159,59160]
operator: = [59211,59212]
===
match
---
name: execution_date [79421,79435]
name: execution_date [79473,79487]
===
match
---
name: task_copy [48209,48218]
name: task_copy [48261,48270]
===
match
---
atom_expr [72929,72944]
atom_expr [72981,72996]
===
match
---
operator: = [12023,12024]
operator: = [12023,12024]
===
match
---
name: default [10015,10022]
name: default [10015,10022]
===
match
---
name: State [5134,5139]
name: State [5134,5139]
===
match
---
name: first [82350,82355]
name: first [82402,82407]
===
match
---
name: lock_for_update [43105,43120]
name: lock_for_update [43157,43172]
===
match
---
number: 0 [26301,26302]
number: 0 [26301,26302]
===
match
---
atom_expr [5122,5130]
atom_expr [5122,5130]
===
match
---
expr_stmt [61803,61853]
expr_stmt [61855,61905]
===
match
---
exprlist [6997,7023]
exprlist [6997,7023]
===
match
---
string: """     Sets the current execution context to the provided context object.     This method should be called once per Task execution, before calling operator.execute.     """ [3312,3485]
string: """     Sets the current execution context to the provided context object.     This method should be called once per Task execution, before calling operator.execute.     """ [3312,3485]
===
match
---
trailer [65893,65895]
trailer [65945,65947]
===
match
---
name: previous_ti [28036,28047]
name: previous_ti [28036,28047]
===
match
---
atom_expr [23299,23314]
atom_expr [23299,23314]
===
match
---
atom_expr [48221,48249]
atom_expr [48273,48301]
===
match
---
string: "/success" [19596,19606]
string: "/success" [19596,19606]
===
match
---
operator: , [53656,53657]
operator: , [53708,53709]
===
match
---
trailer [77653,77660]
trailer [77705,77712]
===
match
---
atom_expr [61116,61140]
atom_expr [61168,61192]
===
match
---
operator: = [11100,11101]
operator: = [11100,11101]
===
match
---
atom_expr [50443,50481]
atom_expr [50495,50533]
===
match
---
name: clear_task_instances [4638,4658]
name: clear_task_instances [4638,4658]
===
match
---
name: get_num_running_task_instances [77396,77426]
name: get_num_running_task_instances [77448,77478]
===
match
---
operator: , [14263,14264]
operator: , [14263,14264]
===
match
---
name: self [23893,23897]
name: self [23893,23897]
===
match
---
name: are_dependencies_met [30906,30926]
name: are_dependencies_met [30906,30926]
===
match
---
name: email [2419,2424]
name: email [2419,2424]
===
match
---
name: super [11117,11122]
name: super [11117,11122]
===
match
---
suite [70520,71413]
suite [70572,71465]
===
match
---
operator: , [50469,50470]
operator: , [50521,50522]
===
match
---
name: dag_id [8450,8456]
name: dag_id [8450,8456]
===
match
---
name: SHUTDOWN [5208,5216]
name: SHUTDOWN [5208,5216]
===
match
---
operator: + [40612,40613]
operator: + [40612,40613]
===
match
---
param [74505,74510]
param [74557,74562]
===
match
---
simple_stmt [40414,40431]
simple_stmt [40414,40431]
===
match
---
operator: = [68527,68528]
operator: = [68579,68580]
===
match
---
name: log_url [19107,19114]
name: log_url [19107,19114]
===
match
---
operator: , [35893,35894]
operator: , [35893,35894]
===
match
---
return_stmt [18800,18810]
return_stmt [18800,18810]
===
match
---
trailer [42992,42994]
trailer [43044,43046]
===
match
---
suite [50775,51106]
suite [50827,51158]
===
match
---
string: """         Refreshes the task instance from the database based on the primary key          :param session: SQLAlchemy ORM Session         :type session: Session         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :type lock_for_update: bool         """ [21039,21432]
string: """         Refreshes the task instance from the database based on the primary key          :param session: SQLAlchemy ORM Session         :type session: Session         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :type lock_for_update: bool         """ [21039,21432]
===
match
---
operator: , [4253,4254]
operator: , [4253,4254]
===
match
---
funcdef [12430,12591]
funcdef [12430,12591]
===
match
---
operator: == [52558,52560]
operator: == [52610,52612]
===
match
---
name: error [59239,59244]
name: error [59291,59296]
===
match
---
atom_expr [78050,78077]
atom_expr [78102,78129]
===
match
---
operator: , [15839,15840]
operator: , [15839,15840]
===
match
---
name: models [48142,48148]
name: models [48194,48200]
===
match
---
funcdef [62840,62892]
funcdef [62892,62944]
===
match
---
suite [45586,45648]
suite [45638,45700]
===
match
---
simple_stmt [51614,51620]
simple_stmt [51666,51672]
===
match
---
atom_expr [44247,44320]
atom_expr [44299,44372]
===
match
---
name: self [53814,53818]
name: self [53866,53870]
===
match
---
name: Optional [15860,15868]
name: Optional [15860,15868]
===
match
---
name: SUCCESS [37756,37763]
name: SUCCESS [37756,37763]
===
match
---
suite [71997,72041]
suite [72049,72093]
===
match
---
argument [39146,39161]
argument [39146,39161]
===
match
---
param [53633,53657]
param [53685,53709]
===
match
---
name: dag_id [7638,7644]
name: dag_id [7638,7644]
===
match
---
name: task [23263,23267]
name: task [23263,23267]
===
match
---
name: dep_status [32043,32053]
name: dep_status [32043,32053]
===
match
---
name: duration [9687,9695]
name: duration [9687,9695]
===
match
---
simple_stmt [54879,54896]
simple_stmt [54931,54948]
===
match
---
atom_expr [44912,44978]
atom_expr [44964,45030]
===
match
---
operator: , [51133,51134]
operator: , [51185,51186]
===
match
---
name: Column [10096,10102]
name: Column [10096,10102]
===
match
---
operator: , [8736,8737]
operator: , [8736,8737]
===
match
---
trailer [39986,39994]
trailer [39986,39994]
===
match
---
operator: , [55439,55440]
operator: , [55491,55492]
===
match
---
suite [21812,21842]
suite [21812,21842]
===
match
---
and_test [72849,72882]
and_test [72901,72934]
===
match
---
expr_stmt [5285,5305]
expr_stmt [5285,5305]
===
match
---
trailer [39055,39073]
trailer [39055,39073]
===
match
---
name: hasattr [60042,60049]
name: hasattr [60094,60101]
===
match
---
trailer [33857,33865]
trailer [33857,33865]
===
match
---
operator: = [23213,23214]
operator: = [23213,23214]
===
match
---
name: jinja_context [71440,71453]
name: jinja_context [71492,71505]
===
match
---
string: """         The execution date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29225,29440]
string: """         The execution date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29225,29440]
===
match
---
name: state [50852,50857]
name: state [50904,50909]
===
match
---
name: operator_helpers [2609,2625]
name: operator_helpers [2609,2625]
===
match
---
if_stmt [56383,56795]
if_stmt [56435,56847]
===
match
---
expr_stmt [9687,9711]
expr_stmt [9687,9711]
===
match
---
tfpdef [53597,53615]
tfpdef [53649,53667]
===
match
---
simple_stmt [59568,59608]
simple_stmt [59620,59660]
===
match
---
atom_expr [10579,10623]
atom_expr [10579,10623]
===
match
---
name: job_id [15332,15338]
name: job_id [15332,15338]
===
match
---
argument [6665,7040]
argument [6665,7040]
===
match
---
operator: , [32715,32716]
operator: , [32715,32716]
===
match
---
operator: = [43120,43121]
operator: = [43172,43173]
===
match
---
fstring_end: " [19364,19365]
fstring_end: " [19364,19365]
===
match
---
suite [51155,51899]
suite [51207,51951]
===
match
---
operator: , [32303,32304]
operator: , [32303,32304]
===
match
---
parameters [30926,30979]
parameters [30926,30979]
===
match
---
name: error_file [41790,41800]
name: error_file [41759,41769]
===
match
---
trailer [8721,8736]
trailer [8721,8736]
===
match
---
arglist [29541,29569]
arglist [29541,29569]
===
match
---
trailer [24852,24865]
trailer [24852,24865]
===
match
---
simple_stmt [30399,30547]
simple_stmt [30399,30547]
===
match
---
suite [51561,51620]
suite [51613,51672]
===
match
---
trailer [57135,57150]
trailer [57187,57202]
===
match
---
tfpdef [35101,35117]
tfpdef [35101,35117]
===
match
---
atom_expr [67392,67418]
atom_expr [67444,67470]
===
match
---
atom_expr [53047,53057]
atom_expr [53099,53109]
===
match
---
name: cmd [18067,18070]
name: cmd [18067,18070]
===
match
---
operator: , [66497,66498]
operator: , [66549,66550]
===
match
---
import_from [937,977]
import_from [937,977]
===
match
---
param [77847,77856]
param [77899,77908]
===
match
---
funcdef [28032,28497]
funcdef [28032,28497]
===
match
---
string: 'Rescheduling task, marking task as UP_FOR_RESCHEDULE' [55946,56000]
string: 'Rescheduling task, marking task as UP_FOR_RESCHEDULE' [55998,56052]
===
match
---
operator: = [78379,78380]
operator: = [78431,78432]
===
match
---
trailer [20364,20379]
trailer [20364,20379]
===
match
---
number: 0 [20485,20486]
number: 0 [20485,20486]
===
match
---
string: "{}#{}#{}#{}" [33794,33807]
string: "{}#{}#{}#{}" [33794,33807]
===
match
---
trailer [24656,24704]
trailer [24656,24704]
===
match
---
name: task [54916,54920]
name: task [54968,54972]
===
match
---
name: self [25882,25886]
name: self [25882,25886]
===
match
---
operator: @ [20559,20560]
operator: @ [20559,20560]
===
match
---
name: all [7380,7383]
name: all [7380,7383]
===
match
---
atom_expr [45058,45400]
atom_expr [45110,45452]
===
match
---
simple_stmt [2700,2750]
simple_stmt [2700,2750]
===
match
---
param [50761,50773]
param [50813,50825]
===
match
---
simple_stmt [81352,81371]
simple_stmt [81404,81423]
===
match
---
atom_expr [9849,9869]
atom_expr [9849,9869]
===
match
---
trailer [3902,3918]
trailer [3902,3918]
===
match
---
operator: = [57928,57929]
operator: = [57980,57981]
===
match
---
atom_expr [56845,56862]
atom_expr [56897,56914]
===
match
---
atom_expr [43574,43948]
atom_expr [43626,44000]
===
match
---
name: _run_raw_task [54371,54384]
name: _run_raw_task [54423,54436]
===
match
---
simple_stmt [28583,28723]
simple_stmt [28583,28723]
===
match
---
name: end_date [21982,21990]
name: end_date [21982,21990]
===
match
---
arith_expr [60734,60768]
arith_expr [60786,60820]
===
match
---
name: self [62853,62857]
name: self [62905,62909]
===
match
---
name: tomorrow_ds_nodash [65698,65716]
name: tomorrow_ds_nodash [65750,65768]
===
match
---
name: ti_key_str [62280,62290]
name: ti_key_str [62332,62342]
===
match
---
funcdef [35080,35542]
funcdef [35080,35542]
===
match
---
name: var [64078,64081]
name: var [64130,64133]
===
match
---
name: next_ds [61527,61534]
name: next_ds [61579,61586]
===
match
---
tfpdef [64147,64156]
tfpdef [64199,64208]
===
match
---
decorated [80907,80983]
decorated [80959,81035]
===
match
---
tfpdef [29709,29729]
tfpdef [29709,29729]
===
match
---
fstring_start: f' [50610,50612]
fstring_start: f' [50662,50664]
===
match
---
name: macros [64762,64768]
name: macros [64814,64820]
===
match
---
suite [61263,61429]
suite [61315,61481]
===
match
---
dictorsetmaker [70550,70560]
dictorsetmaker [70602,70612]
===
match
---
name: id [7363,7365]
name: id [7363,7365]
===
match
---
if_stmt [11652,11856]
if_stmt [11652,11856]
===
match
---
name: self [68542,68546]
name: self [68594,68598]
===
match
---
expr_stmt [62221,62270]
expr_stmt [62273,62322]
===
match
---
operator: = [61752,61753]
operator: = [61804,61805]
===
match
---
if_stmt [18552,18602]
if_stmt [18552,18602]
===
match
---
name: init_on_load [12434,12446]
name: init_on_load [12434,12446]
===
match
---
name: subject [72518,72525]
name: subject [72570,72577]
===
match
---
name: try_number [13208,13218]
name: try_number [13208,13218]
===
match
---
operator: , [43064,43065]
operator: , [43116,43117]
===
match
---
name: first [78426,78431]
name: first [78478,78483]
===
match
---
argument [71602,71631]
argument [71654,71683]
===
match
---
return_stmt [13148,13175]
return_stmt [13148,13175]
===
match
---
name: task_id [47034,47041]
name: task_id [47086,47093]
===
match
---
operator: , [26253,26254]
operator: , [26253,26254]
===
match
---
simple_stmt [77110,77180]
simple_stmt [77162,77232]
===
match
---
trailer [56127,56133]
trailer [56179,56185]
===
match
---
string: "Updating task params (%s) with DagRun.conf (%s)" [67808,67857]
string: "Updating task params (%s) with DagRun.conf (%s)" [67860,67909]
===
match
---
trailer [22363,22372]
trailer [22363,22372]
===
match
---
name: result [50582,50588]
name: result [50634,50640]
===
match
---
tfpdef [52304,52342]
tfpdef [52356,52394]
===
match
---
arglist [45795,45854]
arglist [45847,45906]
===
match
---
expr_stmt [25967,26281]
expr_stmt [25967,26281]
===
match
---
operator: -> [52351,52353]
operator: -> [52403,52405]
===
match
---
name: pop [3609,3612]
name: pop [3609,3612]
===
match
---
simple_stmt [68005,68052]
simple_stmt [68057,68104]
===
match
---
name: task [53093,53097]
name: task [53145,53149]
===
match
---
name: task_id [44955,44962]
name: task_id [45007,45014]
===
match
---
expr_stmt [72279,72355]
expr_stmt [72331,72407]
===
match
---
trailer [23327,23343]
trailer [23327,23343]
===
match
---
name: TR [6823,6825]
name: TR [6823,6825]
===
match
---
arglist [24657,24703]
arglist [24657,24703]
===
match
---
return_stmt [63113,63133]
return_stmt [63165,63185]
===
match
---
operator: , [57167,57168]
operator: , [57219,57220]
===
match
---
operator: , [8226,8227]
operator: , [8226,8227]
===
match
---
number: 1 [40240,40241]
number: 1 [40240,40241]
===
match
---
name: downstream_task_ids [26340,26359]
name: downstream_task_ids [26340,26359]
===
match
---
import_as_names [1221,1259]
import_as_names [1221,1259]
===
match
---
name: dag_id [60311,60317]
name: dag_id [60363,60369]
===
match
---
name: BaseJob [7297,7304]
name: BaseJob [7297,7304]
===
match
---
name: ignore_depends_on_past [15654,15676]
name: ignore_depends_on_past [15654,15676]
===
match
---
atom_expr [21611,21631]
atom_expr [21611,21631]
===
match
---
name: ds [62002,62004]
name: ds [62054,62056]
===
match
---
trailer [55300,55302]
trailer [55352,55354]
===
match
---
atom_expr [9953,9964]
atom_expr [9953,9964]
===
match
---
name: kubernetes [2974,2984]
name: kubernetes [2974,2984]
===
match
---
name: session [35374,35381]
name: session [35374,35381]
===
match
---
fstring_expr [19713,19718]
fstring_expr [19713,19718]
===
match
---
try_stmt [58711,58896]
try_stmt [58763,58948]
===
match
---
trailer [21542,21549]
trailer [21542,21549]
===
match
---
trailer [24941,24950]
trailer [24941,24950]
===
match
---
trailer [46639,46644]
trailer [46691,46696]
===
match
---
try_stmt [66553,67056]
try_stmt [66605,67108]
===
match
---
operator: = [15975,15976]
operator: = [15975,15976]
===
match
---
trailer [44583,44591]
trailer [44635,44643]
===
match
---
atom_expr [47045,47065]
atom_expr [47097,47117]
===
match
---
argument [39611,39656]
argument [39611,39656]
===
match
---
not_test [54257,54264]
not_test [54309,54316]
===
match
---
simple_stmt [12065,12084]
simple_stmt [12065,12084]
===
match
---
if_stmt [80385,80475]
if_stmt [80437,80527]
===
match
---
simple_stmt [47402,47471]
simple_stmt [47454,47523]
===
match
---
expr_stmt [72518,72601]
expr_stmt [72570,72653]
===
match
---
arith_expr [40223,40241]
arith_expr [40223,40241]
===
match
---
fstring [56910,56947]
fstring [56962,56999]
===
match
---
name: warning [39987,39994]
name: warning [39987,39994]
===
match
---
funcdef [64122,64472]
funcdef [64174,64524]
===
match
---
name: self [56537,56541]
name: self [56589,56593]
===
match
---
name: self [39036,39040]
name: self [39036,39040]
===
match
---
name: AirflowRescheduleException [43964,43990]
name: AirflowRescheduleException [44016,44042]
===
match
---
operator: = [82391,82392]
operator: = [82443,82444]
===
match
---
trailer [49327,49333]
trailer [49379,49385]
===
match
---
simple_stmt [52368,52536]
simple_stmt [52420,52588]
===
match
---
name: getLogger [3216,3225]
name: getLogger [3216,3225]
===
match
---
trailer [38989,39000]
trailer [38989,39000]
===
match
---
trailer [40808,40812]
trailer [42768,42772]
===
match
---
trailer [80504,80510]
trailer [80556,80562]
===
match
---
name: str [74558,74561]
name: str [74610,74613]
===
match
---
trailer [80337,80354]
trailer [80389,80406]
===
match
---
atom_expr [57104,57184]
atom_expr [57156,57236]
===
match
---
simple_stmt [71440,71484]
simple_stmt [71492,71536]
===
match
---
atom_expr [8690,8701]
atom_expr [8690,8701]
===
match
---
trailer [72642,72647]
trailer [72694,72699]
===
match
---
expr_stmt [12092,12110]
expr_stmt [12092,12110]
===
match
---
atom_expr [80184,80197]
atom_expr [80236,80249]
===
match
---
trailer [79420,79435]
trailer [79472,79487]
===
match
---
name: DepContext [31659,31669]
name: DepContext [31659,31669]
===
match
---
suite [81343,81371]
suite [81395,81423]
===
match
---
name: self [39978,39982]
name: self [39978,39982]
===
match
---
trailer [24837,24843]
trailer [24837,24843]
===
match
---
trailer [55940,55945]
trailer [55992,55997]
===
match
---
expr_stmt [22590,22631]
expr_stmt [22590,22631]
===
match
---
comparison [13075,13102]
comparison [13075,13102]
===
match
---
dotted_name [2966,2996]
dotted_name [2966,2996]
===
match
---
trailer [63021,63025]
trailer [63073,63077]
===
match
---
operator: , [55147,55148]
operator: , [55199,55200]
===
match
---
simple_stmt [32876,32893]
simple_stmt [32876,32893]
===
match
---
operator: = [59575,59576]
operator: = [59627,59628]
===
match
---
operator: = [50128,50129]
operator: = [50180,50181]
===
match
---
name: primary [8093,8100]
name: primary [8093,8100]
===
match
---
name: self [65354,65358]
name: self [65406,65410]
===
match
---
name: AirflowException [67507,67523]
name: AirflowException [67559,67575]
===
match
---
atom_expr [11214,11223]
atom_expr [11214,11223]
===
match
---
name: replace [62005,62012]
name: replace [62057,62064]
===
match
---
name: AirflowException [1652,1668]
name: AirflowException [1652,1668]
===
match
---
simple_stmt [76411,76432]
simple_stmt [76463,76484]
===
match
---
operator: , [41381,41382]
operator: , [41350,41351]
===
match
---
expr_stmt [59568,59607]
expr_stmt [59620,59659]
===
match
---
name: log [31761,31764]
name: log [31761,31764]
===
match
---
not_test [26915,26921]
not_test [26915,26921]
===
match
---
operator: = [29546,29547]
operator: = [29546,29547]
===
match
---
name: are_dependencies_met [38459,38479]
name: are_dependencies_met [38459,38479]
===
match
---
trailer [9634,9647]
trailer [9634,9647]
===
match
---
trailer [41269,41273]
trailer [41238,41242]
===
match
---
trailer [51454,51456]
trailer [51506,51508]
===
match
---
atom_expr [62390,62401]
atom_expr [62442,62453]
===
match
---
param [15740,15770]
param [15740,15770]
===
match
---
simple_stmt [61154,61196]
simple_stmt [61206,61248]
===
match
---
trailer [23206,23212]
trailer [23206,23212]
===
match
---
name: Context [3298,3305]
name: Context [3298,3305]
===
match
---
argument [11001,11015]
argument [11001,11015]
===
match
---
simple_stmt [52860,52877]
simple_stmt [52912,52929]
===
match
---
name: query_for_task_instance [39116,39139]
name: query_for_task_instance [39116,39139]
===
match
---
suite [27697,27778]
suite [27697,27778]
===
match
---
if_stmt [51335,51690]
if_stmt [51387,51742]
===
match
---
funcdef [28516,29036]
funcdef [28516,29036]
===
match
---
if_stmt [68060,68126]
if_stmt [68112,68178]
===
match
---
simple_stmt [38599,38616]
simple_stmt [38599,38616]
===
match
---
simple_stmt [62030,62088]
simple_stmt [62082,62140]
===
match
---
atom_expr [78665,78681]
atom_expr [78717,78733]
===
match
---
name: execution_date [41317,41331]
name: execution_date [41286,41300]
===
match
---
name: info [47829,47833]
name: info [47881,47885]
===
match
---
atom_expr [26429,26442]
atom_expr [26429,26442]
===
match
---
operator: = [69751,69752]
operator: = [69803,69804]
===
match
---
name: self [42624,42628]
name: self [42593,42597]
===
match
---
name: self [19470,19474]
name: self [19470,19474]
===
match
---
suite [26790,27992]
suite [26790,27992]
===
match
---
operator: = [54648,54649]
operator: = [54700,54701]
===
match
---
name: update [49377,49383]
name: update [49429,49435]
===
match
---
tfpdef [56070,56098]
tfpdef [56122,56150]
===
match
---
atom_expr [26040,26059]
atom_expr [26040,26059]
===
match
---
string: 'execution_date can not be in the past (current ' [74009,74058]
string: 'execution_date can not be in the past (current ' [74061,74110]
===
match
---
if_stmt [45776,48008]
if_stmt [45828,48060]
===
match
---
operator: , [38305,38306]
operator: , [38305,38306]
===
match
---
atom_expr [45032,45049]
atom_expr [45084,45101]
===
match
---
name: task_id [33858,33865]
name: task_id [33858,33865]
===
match
---
operator: = [9626,9627]
operator: = [9626,9627]
===
match
---
name: Exception [4424,4433]
name: Exception [4424,4433]
===
match
---
atom_expr [10667,10728]
atom_expr [10667,10728]
===
match
---
trailer [52687,52708]
trailer [52739,52760]
===
match
---
expr_stmt [12009,12034]
expr_stmt [12009,12034]
===
match
---
name: set_duration [55316,55328]
name: set_duration [55368,55380]
===
match
---
trailer [6067,6075]
trailer [6067,6075]
===
match
---
name: unixname [9874,9882]
name: unixname [9874,9882]
===
match
---
trailer [42824,42831]
trailer [42876,42883]
===
match
---
atom_expr [69477,69513]
atom_expr [69529,69565]
===
match
---
name: dag [64540,64543]
name: dag [64592,64595]
===
match
---
name: taskfail [1929,1937]
name: taskfail [1929,1937]
===
match
---
fstring_expr [19073,19078]
fstring_expr [19073,19078]
===
match
---
trailer [71087,71097]
trailer [71139,71149]
===
match
---
name: hostname [12097,12105]
name: hostname [12097,12105]
===
match
---
decorated [25339,26361]
decorated [25339,26361]
===
match
---
suite [25073,25334]
suite [25073,25334]
===
match
---
name: self [33853,33857]
name: self [33853,33857]
===
match
---
param [20985,20998]
param [20985,20998]
===
match
---
simple_stmt [2011,2056]
simple_stmt [2011,2056]
===
match
---
atom_expr [72912,72961]
atom_expr [72964,73013]
===
match
---
not_test [37688,37707]
not_test [37688,37707]
===
match
---
name: state [10722,10727]
name: state [10722,10727]
===
match
---
param [63198,63208]
param [63250,63260]
===
match
---
expr_stmt [21509,21722]
expr_stmt [21509,21722]
===
match
---
name: result [76999,77005]
name: result [77051,77057]
===
match
---
if_stmt [18346,18426]
if_stmt [18346,18426]
===
match
---
name: iso [19074,19077]
name: iso [19074,19077]
===
match
---
atom_expr [32043,32062]
atom_expr [32043,32062]
===
match
---
simple_stmt [23323,23373]
simple_stmt [23323,23373]
===
match
---
name: self [59502,59506]
name: self [59554,59558]
===
match
---
simple_stmt [33588,33671]
simple_stmt [33588,33671]
===
match
---
name: self [13805,13809]
name: self [13805,13809]
===
match
---
name: incr [50675,50679]
name: incr [50727,50731]
===
match
---
name: session [55373,55380]
name: session [55425,55432]
===
match
---
trailer [33605,33670]
trailer [33605,33670]
===
match
---
operator: , [44279,44280]
operator: , [44331,44332]
===
match
---
name: stacklevel [30787,30797]
name: stacklevel [30787,30797]
===
match
---
simple_stmt [45058,45401]
simple_stmt [45110,45453]
===
match
---
name: task_id [15523,15530]
name: task_id [15523,15530]
===
match
---
simple_stmt [40894,40914]
simple_stmt [40863,40883]
===
match
---
name: Any [74732,74735]
name: Any [74784,74787]
===
match
---
atom_expr [46027,46283]
atom_expr [46079,46335]
===
match
---
name: relationship [82656,82668]
name: relationship [82708,82720]
===
match
---
atom_expr [43548,43561]
atom_expr [43600,43613]
===
match
---
expr_stmt [8008,8020]
expr_stmt [8008,8020]
===
match
---
simple_stmt [61920,61981]
simple_stmt [61972,62033]
===
match
---
name: log [39935,39938]
name: log [39935,39938]
===
match
---
trailer [30032,30036]
trailer [30032,30036]
===
match
---
expr_stmt [10506,10827]
expr_stmt [10506,10827]
===
match
---
name: html_content_err [72541,72557]
name: html_content_err [72593,72609]
===
match
---
trailer [53212,53214]
trailer [53264,53266]
===
match
---
name: self [21494,21498]
name: self [21494,21498]
===
match
---
name: self [80796,80800]
name: self [80848,80852]
===
match
---
operator: , [41453,41454]
operator: , [41422,41423]
===
match
---
name: self [32299,32303]
name: self [32299,32303]
===
match
---
param [53597,53624]
param [53649,53676]
===
match
---
atom_expr [33003,33013]
atom_expr [33003,33013]
===
match
---
arglist [39523,39757]
arglist [39523,39757]
===
match
---
comparison [34970,35002]
comparison [34970,35002]
===
match
---
operator: = [51680,51681]
operator: = [51732,51733]
===
match
---
name: timedelta [60676,60685]
name: timedelta [60728,60737]
===
match
---
try_stmt [3527,3848]
try_stmt [3527,3848]
===
match
---
name: add [55381,55384]
name: add [55433,55436]
===
match
---
operator: == [34981,34983]
operator: == [34981,34983]
===
match
---
operator: , [38536,38537]
operator: , [38536,38537]
===
match
---
trailer [50544,50557]
trailer [50596,50609]
===
match
---
param [14233,14243]
param [14233,14243]
===
match
---
param [24354,24359]
param [24354,24359]
===
match
---
string: "%s. State set to NONE." [40140,40164]
string: "%s. State set to NONE." [40140,40164]
===
match
---
name: BaseJob [82521,82528]
name: BaseJob [82573,82580]
===
match
---
import_name [1147,1160]
import_name [1147,1160]
===
match
---
trailer [80436,80453]
trailer [80488,80505]
===
match
---
trailer [32513,32530]
trailer [32513,32530]
===
match
---
name: self [68790,68794]
name: self [68842,68846]
===
match
---
name: next_execution_date [64883,64902]
name: next_execution_date [64935,64954]
===
match
---
name: str [64069,64072]
name: str [64121,64124]
===
match
---
name: self [77903,77907]
name: self [77955,77959]
===
match
---
name: get_previous_dagrun [27829,27848]
name: get_previous_dagrun [27829,27848]
===
match
---
atom_expr [62351,62362]
atom_expr [62403,62414]
===
match
---
argument [31826,31849]
argument [31826,31849]
===
match
---
atom_expr [47345,47376]
atom_expr [47397,47428]
===
match
---
name: int [80045,80048]
name: int [80097,80100]
===
match
---
operator: - [24968,24969]
operator: - [24968,24969]
===
match
---
sync_comp_for [77155,77178]
sync_comp_for [77207,77230]
===
match
---
arglist [8690,8748]
arglist [8690,8748]
===
match
---
name: execution_date [46184,46198]
name: execution_date [46236,46250]
===
match
---
operator: == [78651,78653]
operator: == [78703,78705]
===
match
---
atom_expr [6065,6075]
atom_expr [6065,6075]
===
match
---
suite [67690,67921]
suite [67742,67973]
===
match
---
name: dict [70752,70756]
name: dict [70804,70808]
===
match
---
param [26422,26450]
param [26422,26450]
===
match
---
tfpdef [59062,59090]
tfpdef [59114,59142]
===
match
---
name: try_number [8553,8563]
name: try_number [8553,8563]
===
match
---
operator: , [15211,15212]
operator: , [15211,15212]
===
match
---
name: self [29449,29453]
name: self [29449,29453]
===
match
---
arglist [42647,42671]
arglist [42616,42640]
===
match
---
name: start_date [30290,30300]
name: start_date [30290,30300]
===
match
---
number: 1 [56949,56950]
number: 1 [57001,57002]
===
match
---
sync_comp_for [49295,49335]
sync_comp_for [49347,49387]
===
match
---
param [29103,29108]
param [29103,29108]
===
match
---
dotted_name [2820,2839]
dotted_name [2820,2839]
===
match
---
name: unixname [22418,22426]
name: unixname [22418,22426]
===
match
---
name: dag [60084,60087]
name: dag [60136,60139]
===
match
---
operator: , [58508,58509]
operator: , [58560,58561]
===
match
---
simple_stmt [56347,56374]
simple_stmt [56399,56426]
===
match
---
trailer [71011,71023]
trailer [71063,71075]
===
match
---
atom_expr [51488,51522]
atom_expr [51540,51574]
===
match
---
simple_stmt [8667,8750]
simple_stmt [8667,8750]
===
match
---
operator: = [15762,15763]
operator: = [15762,15763]
===
match
---
atom_expr [24801,24811]
atom_expr [24801,24811]
===
match
---
param [35101,35124]
param [35101,35124]
===
match
---
tfpdef [35903,35918]
tfpdef [35903,35918]
===
match
---
operator: , [64156,64157]
operator: , [64208,64209]
===
match
---
name: self [74119,74123]
name: self [74171,74175]
===
match
---
suite [80694,80724]
suite [80746,80776]
===
match
---
name: task_id [43771,43778]
name: task_id [43823,43830]
===
match
---
simple_stmt [3312,3486]
simple_stmt [3312,3486]
===
match
---
simple_stmt [61208,61250]
simple_stmt [61260,61302]
===
match
---
operator: = [39690,39691]
operator: = [39690,39691]
===
match
---
atom_expr [50847,50857]
atom_expr [50899,50909]
===
match
---
name: test_mode [37518,37527]
name: test_mode [37518,37527]
===
match
---
trailer [19489,19499]
trailer [19489,19499]
===
match
---
name: self [45016,45020]
name: self [45068,45072]
===
match
---
trailer [67396,67416]
trailer [67448,67468]
===
match
---
operator: = [11010,11011]
operator: = [11010,11011]
===
match
---
name: pool [42667,42671]
name: pool [42636,42640]
===
match
---
string: "Setting task state for %s to %s" [24657,24690]
string: "Setting task state for %s to %s" [24657,24690]
===
match
---
name: ti_deps [2301,2308]
name: ti_deps [2301,2308]
===
match
---
simple_stmt [10506,10828]
simple_stmt [10506,10828]
===
match
---
name: next_execution_date [61537,61556]
name: next_execution_date [61589,61608]
===
match
---
name: models [1826,1832]
name: models [1826,1832]
===
match
---
name: task [32469,32473]
name: task [32469,32473]
===
match
---
trailer [44032,44048]
trailer [44084,44100]
===
match
---
name: path [15293,15297]
name: path [15293,15297]
===
match
---
name: merge [55887,55892]
name: merge [55939,55944]
===
match
---
fstring_expr [62295,62308]
fstring_expr [62347,62360]
===
match
---
trailer [70936,70946]
trailer [70988,70998]
===
match
---
name: t [78968,78969]
name: t [79020,79021]
===
match
---
atom_expr [49801,49852]
atom_expr [49853,49904]
===
match
---
name: UtcDateTime [2787,2798]
name: UtcDateTime [2787,2798]
===
match
---
trailer [45550,45557]
trailer [45602,45609]
===
match
---
simple_stmt [44877,44883]
simple_stmt [44929,44935]
===
match
---
name: query [77253,77258]
name: query [77305,77310]
===
match
---
operator: , [74394,74395]
operator: , [74446,74447]
===
match
---
expr_stmt [7992,8003]
expr_stmt [7992,8003]
===
match
---
trailer [45315,45330]
trailer [45367,45382]
===
match
---
suite [72883,72962]
suite [72935,73014]
===
match
---
name: loads [4086,4091]
name: loads [4086,4091]
===
match
---
name: airflow [2370,2377]
name: airflow [2370,2377]
===
match
---
trailer [35031,35033]
trailer [35031,35033]
===
match
---
atom_expr [25908,25932]
atom_expr [25908,25932]
===
match
---
fstring [50610,50653]
fstring [50662,50705]
===
match
---
name: VariableAccessor [62572,62588]
name: VariableAccessor [62624,62640]
===
match
---
name: catchup [27657,27664]
name: catchup [27657,27664]
===
match
---
name: context [51506,51513]
name: context [51558,51565]
===
match
---
name: task [34730,34734]
name: task [34730,34734]
===
match
---
operator: , [68473,68474]
operator: , [68525,68526]
===
match
---
fstring [62293,62338]
fstring [62345,62390]
===
match
---
name: raw [15890,15893]
name: raw [15890,15893]
===
match
---
argument [68487,68507]
argument [68539,68559]
===
match
---
operator: , [68655,68656]
operator: , [68707,68708]
===
match
---
name: self [51129,51133]
name: self [51181,51185]
===
match
---
param [36010,36023]
param [36010,36023]
===
match
---
name: provide_session [2734,2749]
name: provide_session [2734,2749]
===
match
---
param [14209,14224]
param [14209,14224]
===
match
---
name: state [30116,30121]
name: state [30116,30121]
===
match
---
string: 'ti_failures' [56974,56987]
string: 'ti_failures' [57026,57039]
===
match
---
name: self [44063,44067]
name: self [44115,44119]
===
match
---
param [35703,35733]
param [35703,35733]
===
match
---
import_name [835,846]
import_name [835,846]
===
match
---
operator: = [55283,55284]
operator: = [55335,55336]
===
match
---
trailer [9427,9479]
trailer [9427,9479]
===
match
---
name: try_number [33893,33903]
name: try_number [33893,33903]
===
match
---
suite [12052,12084]
suite [12052,12084]
===
match
---
name: self [11981,11985]
name: self [11981,11985]
===
match
---
operator: = [80529,80530]
operator: = [80581,80582]
===
match
---
return_stmt [19275,19365]
return_stmt [19275,19365]
===
match
---
trailer [42575,42580]
trailer [42544,42549]
===
match
---
trailer [62135,62143]
trailer [62187,62195]
===
match
---
name: self [43535,43539]
name: self [43587,43591]
===
match
---
name: dag_id [11163,11169]
name: dag_id [11163,11169]
===
match
---
name: dep_context [32305,32316]
name: dep_context [32305,32316]
===
match
---
name: get [64414,64417]
name: get [64466,64469]
===
match
---
name: Optional [56196,56204]
name: Optional [56248,56256]
===
match
---
operator: , [29177,29178]
operator: , [29177,29178]
===
match
---
name: airflow [2820,2827]
name: airflow [2820,2827]
===
match
---
atom_expr [39903,39913]
atom_expr [39903,39913]
===
match
---
name: _try_number [55499,55510]
name: _try_number [55551,55562]
===
match
---
argument [54482,54495]
argument [54534,54547]
===
match
---
comparison [78945,78963]
comparison [78997,79015]
===
match
---
trailer [48680,48682]
trailer [48732,48734]
===
match
---
atom_expr [58089,58110]
atom_expr [58141,58162]
===
match
---
trailer [63303,63334]
trailer [63355,63386]
===
match
---
atom_expr [62876,62884]
atom_expr [62928,62936]
===
match
---
trailer [19474,19489]
trailer [19474,19489]
===
match
---
decorated [24097,24314]
decorated [24097,24314]
===
match
---
atom_expr [61813,61853]
atom_expr [61865,61905]
===
match
---
tfpdef [74655,74680]
tfpdef [74707,74732]
===
match
---
return_stmt [4072,4097]
return_stmt [4072,4097]
===
match
---
name: default_subject [72169,72184]
name: default_subject [72221,72236]
===
match
---
operator: , [41299,41300]
operator: , [41268,41269]
===
match
---
name: self [66574,66578]
name: self [66626,66630]
===
match
---
trailer [7781,7785]
trailer [7781,7785]
===
match
---
name: error [56558,56563]
name: error [56610,56615]
===
match
---
name: end_date [72918,72926]
name: end_date [72970,72978]
===
match
---
name: full_filepath [14795,14808]
name: full_filepath [14795,14808]
===
match
---
name: log [41270,41273]
name: log [41239,41242]
===
match
---
name: deserialize_json [63958,63974]
name: deserialize_json [64010,64026]
===
match
---
name: test_mode [45444,45453]
name: test_mode [45496,45505]
===
match
---
subscriptlist [8116,8134]
subscriptlist [8116,8134]
===
match
---
name: start_date [79961,79971]
name: start_date [80013,80023]
===
match
---
name: State [24847,24852]
name: State [24847,24852]
===
match
---
suite [77442,77815]
suite [77494,77867]
===
match
---
name: error_file [44842,44852]
name: error_file [44894,44904]
===
match
---
name: extend [18006,18012]
name: extend [18006,18012]
===
match
---
simple_stmt [63002,63032]
simple_stmt [63054,63084]
===
match
---
expr_stmt [79980,80018]
expr_stmt [80032,80070]
===
match
---
name: Column [9724,9730]
name: Column [9724,9730]
===
match
---
operator: , [10561,10562]
operator: , [10561,10562]
===
match
---
parameters [62920,62984]
parameters [62972,63036]
===
match
---
trailer [79249,79486]
trailer [79301,79538]
===
match
---
if_stmt [54254,54285]
if_stmt [54306,54337]
===
match
---
fstring [19293,19365]
fstring [19293,19365]
===
match
---
name: task [22884,22888]
name: task [22884,22888]
===
match
---
argument [29015,29034]
argument [29015,29034]
===
match
---
param [19842,19854]
param [19842,19854]
===
match
---
if_stmt [61767,61981]
if_stmt [61819,62033]
===
match
---
simple_stmt [5233,5259]
simple_stmt [5233,5259]
===
match
---
operator: , [64939,64940]
operator: , [64991,64992]
===
match
---
simple_stmt [20474,20494]
simple_stmt [20474,20494]
===
match
---
name: item [63198,63202]
name: item [63250,63254]
===
match
---
param [15523,15536]
param [15523,15536]
===
match
---
string: """         Generates the shell command required to execute this task instance.          :param dag_id: DAG ID         :type dag_id: str         :param task_id: Task ID         :type task_id: str         :param execution_date: Execution date for the task         :type execution_date: datetime         :param mark_success: Whether to mark the task as successful         :type mark_success: bool         :param ignore_all_deps: Ignore all ignorable dependencies.             Overrides the other ignore_* parameters.         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past parameter of DAGs             (e.g. for Backfills)         :type ignore_depends_on_past: bool         :param ignore_task_deps: Ignore task-specific dependencies such as depends_on_past             and trigger rule         :type ignore_task_deps: bool         :param ignore_ti_state: Ignore the task instance's previous failure/success         :type ignore_ti_state: bool         :param local: Whether to run the task locally         :type local: bool         :param pickle_id: If the DAG was serialized to the DB, the ID             associated with the pickled DAG         :type pickle_id: Optional[int]         :param file_path: path to the file containing the DAG definition         :type file_path: Optional[str]         :param raw: raw mode (needs more details)         :type raw: Optional[bool]         :param job_id: job ID (needs more details)         :type job_id: Optional[int]         :param pool: the Airflow pool that the task should run in         :type pool: Optional[str]         :param cfg_path: the Path to the configuration file         :type cfg_path: Optional[str]         :return: shell command that can be used to run the task instance         :rtype: list[str]         """ [16051,17859]
string: """         Generates the shell command required to execute this task instance.          :param dag_id: DAG ID         :type dag_id: str         :param task_id: Task ID         :type task_id: str         :param execution_date: Execution date for the task         :type execution_date: datetime         :param mark_success: Whether to mark the task as successful         :type mark_success: bool         :param ignore_all_deps: Ignore all ignorable dependencies.             Overrides the other ignore_* parameters.         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past parameter of DAGs             (e.g. for Backfills)         :type ignore_depends_on_past: bool         :param ignore_task_deps: Ignore task-specific dependencies such as depends_on_past             and trigger rule         :type ignore_task_deps: bool         :param ignore_ti_state: Ignore the task instance's previous failure/success         :type ignore_ti_state: bool         :param local: Whether to run the task locally         :type local: bool         :param pickle_id: If the DAG was serialized to the DB, the ID             associated with the pickled DAG         :type pickle_id: Optional[int]         :param file_path: path to the file containing the DAG definition         :type file_path: Optional[str]         :param raw: raw mode (needs more details)         :type raw: Optional[bool]         :param job_id: job ID (needs more details)         :type job_id: Optional[int]         :param pool: the Airflow pool that the task should run in         :type pool: Optional[str]         :param cfg_path: the Path to the configuration file         :type cfg_path: Optional[str]         :return: shell command that can be used to run the task instance         :rtype: list[str]         """ [16051,17859]
===
match
---
operator: = [15390,15391]
operator: = [15390,15391]
===
match
---
expr_stmt [14784,14808]
expr_stmt [14784,14808]
===
match
---
atom_expr [22359,22372]
atom_expr [22359,22372]
===
match
---
atom_expr [68528,68568]
atom_expr [68580,68620]
===
match
---
expr_stmt [10255,10305]
expr_stmt [10255,10305]
===
match
---
name: or_ [6640,6643]
name: or_ [6640,6643]
===
match
---
name: queue [23220,23225]
name: queue [23220,23225]
===
match
---
name: ignore_task_deps [14087,14103]
name: ignore_task_deps [14087,14103]
===
match
---
annassign [79843,79861]
annassign [79895,79913]
===
match
---
name: bool [59154,59158]
name: bool [59206,59210]
===
match
---
operator: @ [73079,73080]
operator: @ [73131,73132]
===
match
---
return_stmt [28001,28012]
return_stmt [28001,28012]
===
match
---
name: email_alert [72421,72432]
name: email_alert [72473,72484]
===
match
---
name: provide_session [81538,81553]
name: provide_session [81590,81605]
===
match
---
name: raw [77908,77911]
name: raw [77960,77963]
===
match
---
name: pool [80320,80324]
name: pool [80372,80376]
===
match
---
trailer [27656,27664]
trailer [27656,27664]
===
match
---
name: default_html_content_err [70107,70131]
name: default_html_content_err [70159,70183]
===
match
---
name: hasattr [80388,80395]
name: hasattr [80440,80447]
===
match
---
operator: @ [81376,81377]
operator: @ [81428,81429]
===
match
---
arglist [10639,10656]
arglist [10639,10656]
===
match
---
trailer [5415,5433]
trailer [5415,5433]
===
match
---
name: getattr [59577,59584]
name: getattr [59629,59636]
===
match
---
trailer [9855,9869]
trailer [9855,9869]
===
match
---
name: inlets [64732,64738]
name: inlets [64784,64790]
===
match
---
name: self [44665,44669]
name: self [44717,44721]
===
match
---
trailer [76980,76998]
trailer [77032,77050]
===
match
---
operator: , [35693,35694]
operator: , [35693,35694]
===
match
---
string: "--mark-success" [18014,18030]
string: "--mark-success" [18014,18030]
===
match
---
argument [9534,9550]
argument [9534,9550]
===
match
---
trailer [10538,10569]
trailer [10538,10569]
===
match
---
string: 'macros' [64752,64760]
string: 'macros' [64804,64812]
===
match
---
trailer [52734,52747]
trailer [52786,52799]
===
match
---
operator: , [48569,48570]
operator: , [48621,48622]
===
match
---
simple_stmt [835,847]
simple_stmt [835,847]
===
match
---
name: params [62525,62531]
name: params [62577,62583]
===
match
---
atom_expr [40277,40308]
atom_expr [40277,40308]
===
match
---
operator: = [40849,40850]
operator: = [40818,40819]
===
match
---
expr_stmt [63002,63031]
expr_stmt [63054,63083]
===
match
---
name: local [18501,18506]
name: local [18501,18506]
===
match
---
name: dag_id [35423,35429]
name: dag_id [35423,35429]
===
match
---
parameters [23591,23611]
parameters [23591,23611]
===
match
---
atom_expr [41301,41310]
atom_expr [41270,41279]
===
match
---
simple_stmt [4160,4199]
simple_stmt [4160,4199]
===
match
---
name: pre_execute [49468,49479]
name: pre_execute [49520,49531]
===
match
---
trailer [26117,26137]
trailer [26117,26137]
===
match
---
name: all [7782,7785]
name: all [7782,7785]
===
match
---
atom_expr [45479,45500]
atom_expr [45531,45552]
===
match
---
argument [6581,7129]
argument [6581,7129]
===
match
---
trailer [24020,24022]
trailer [24020,24022]
===
match
---
atom_expr [70932,70946]
atom_expr [70984,70998]
===
match
---
trailer [23964,23979]
trailer [23964,23979]
===
match
---
atom_expr [26063,26074]
atom_expr [26063,26074]
===
match
---
parameters [20978,21021]
parameters [20978,21021]
===
match
---
name: ds_nodash [62327,62336]
name: ds_nodash [62379,62388]
===
match
---
name: query [77569,77574]
name: query [77621,77626]
===
match
---
trailer [6643,7058]
trailer [6643,7058]
===
match
---
name: t [78665,78666]
name: t [78717,78718]
===
match
---
suite [31868,32113]
suite [31868,32113]
===
match
---
operator: = [68940,68941]
operator: = [68992,68993]
===
match
---
operator: = [72910,72911]
operator: = [72962,72963]
===
match
---
name: dag_id [33845,33851]
name: dag_id [33845,33851]
===
match
---
name: result [59619,59625]
name: result [59671,59677]
===
match
---
funcdef [71830,72119]
funcdef [71882,72171]
===
match
---
name: test_mode [54136,54145]
name: test_mode [54188,54197]
===
match
---
trailer [11894,11909]
trailer [11894,11909]
===
match
---
name: STATICA_HACK [82378,82390]
name: STATICA_HACK [82430,82442]
===
match
---
operator: = [59126,59127]
operator: = [59178,59179]
===
match
---
operator: = [28965,28966]
operator: = [28965,28966]
===
match
---
trailer [8689,8749]
trailer [8689,8749]
===
match
---
name: session [40894,40901]
name: session [40863,40870]
===
match
---
simple_stmt [1813,1874]
simple_stmt [1813,1874]
===
match
---
with_stmt [50383,50482]
with_stmt [50435,50534]
===
match
---
operator: , [79215,79216]
operator: , [79267,79268]
===
match
---
trailer [60049,60062]
trailer [60101,60114]
===
match
---
atom_expr [51405,51457]
atom_expr [51457,51509]
===
match
---
operator: , [63956,63957]
operator: , [64008,64009]
===
match
---
name: execution_date [11729,11743]
name: execution_date [11729,11743]
===
match
---
name: self [80608,80612]
name: self [80660,80664]
===
match
---
name: prepare_for_execution [54921,54942]
name: prepare_for_execution [54973,54994]
===
match
---
operator: , [20402,20403]
operator: , [20402,20403]
===
match
---
atom_expr [26484,26508]
atom_expr [26484,26508]
===
match
---
operator: = [22332,22333]
operator: = [22332,22333]
===
match
---
trailer [20794,20798]
trailer [20794,20798]
===
match
---
name: ti [22334,22336]
name: ti [22334,22336]
===
match
---
atom_expr [65389,65402]
atom_expr [65441,65454]
===
match
---
operator: = [14277,14278]
operator: = [14277,14278]
===
match
---
suite [40710,40761]
suite [40710,40761]
===
match
---
name: context [48800,48807]
name: context [48852,48859]
===
match
---
string: """         Returns whether or not all the conditions are met for this task instance to be run         given the context for the dependencies (e.g. a task instance being force run from         the UI will ignore some dependencies).          :param dep_context: The execution context that determines the dependencies that             should be evaluated.         :type dep_context: DepContext         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param verbose: whether log details on failed dependencies on             info or debug log level         :type verbose: bool         """ [30989,31621]
string: """         Returns whether or not all the conditions are met for this task instance to be run         given the context for the dependencies (e.g. a task instance being force run from         the UI will ignore some dependencies).          :param dep_context: The execution context that determines the dependencies that             should be evaluated.         :type dep_context: DepContext         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param verbose: whether log details on failed dependencies on             info or debug log level         :type verbose: bool         """ [30989,31621]
===
match
---
name: ignore_task_deps [54005,54021]
name: ignore_task_deps [54057,54073]
===
match
---
name: warning [3669,3676]
name: warning [3669,3676]
===
match
---
atom_expr [4244,4265]
atom_expr [4244,4265]
===
match
---
arglist [10800,10819]
arglist [10800,10819]
===
match
---
atom_expr [73017,73073]
atom_expr [73069,73125]
===
match
---
param [45745,45757]
param [45797,45809]
===
match
---
atom_expr [82285,82314]
atom_expr [82337,82366]
===
match
---
tfpdef [73137,73145]
tfpdef [73189,73197]
===
match
---
simple_stmt [3490,3523]
simple_stmt [3490,3523]
===
match
---
return_stmt [13914,13941]
return_stmt [13914,13941]
===
match
---
operator: -> [8107,8109]
operator: -> [8107,8109]
===
match
---
trailer [21623,21631]
trailer [21623,21631]
===
match
---
simple_stmt [24395,24593]
simple_stmt [24395,24593]
===
match
---
string: "Refreshed TaskInstance %s" [22816,22843]
string: "Refreshed TaskInstance %s" [22816,22843]
===
match
---
name: max_retry_delay [34735,34750]
name: max_retry_delay [34735,34750]
===
match
---
name: urllib [1108,1114]
name: urllib [1108,1114]
===
match
---
name: XCom [77057,77061]
name: XCom [77109,77113]
===
match
---
fstring_expr [47904,47917]
fstring_expr [47956,47969]
===
match
---
parameters [41623,41851]
parameters [41592,41820]
===
match
---
trailer [68427,68441]
trailer [68479,68493]
===
match
---
name: ID_LEN [1861,1867]
name: ID_LEN [1861,1867]
===
match
---
simple_stmt [14550,14595]
simple_stmt [14550,14595]
===
match
---
name: default_html_content [72245,72265]
name: default_html_content [72297,72317]
===
match
---
name: self [24758,24762]
name: self [24758,24762]
===
match
---
expr_stmt [50434,50481]
expr_stmt [50486,50533]
===
match
---
name: task [14532,14536]
name: task [14532,14536]
===
match
---
operator: , [68911,68912]
operator: , [68963,68964]
===
match
---
atom_expr [11178,11190]
atom_expr [11178,11190]
===
match
---
operator: = [14258,14259]
operator: = [14258,14259]
===
match
---
operator: , [9460,9461]
operator: , [9460,9461]
===
match
---
operator: , [55476,55477]
operator: , [55528,55529]
===
match
---
trailer [45040,45047]
trailer [45092,45099]
===
match
---
return_stmt [72365,72411]
return_stmt [72417,72463]
===
match
---
suite [36038,41353]
suite [36038,41322]
===
match
---
name: XCom [77337,77341]
name: XCom [77389,77393]
===
match
---
operator: , [36022,36023]
operator: , [36022,36023]
===
match
---
trailer [6825,6833]
trailer [6825,6833]
===
match
---
simple_stmt [81272,81301]
simple_stmt [81324,81353]
===
match
---
simple_stmt [19421,19450]
simple_stmt [19421,19450]
===
match
---
name: self [40662,40666]
name: self [40662,40666]
===
match
---
name: dag_id [48725,48731]
name: dag_id [48777,48783]
===
match
---
atom_expr [30264,30301]
atom_expr [30264,30301]
===
match
---
except_clause [58768,58784]
except_clause [58820,58836]
===
match
---
trailer [23938,23946]
trailer [23938,23946]
===
match
---
name: execution_date [61330,61344]
name: execution_date [61382,61396]
===
match
---
name: self [56359,56363]
name: self [56411,56415]
===
match
---
operator: { [44935,44936]
operator: { [44987,44988]
===
match
---
name: self [28994,28998]
name: self [28994,28998]
===
match
---
trailer [72992,73001]
trailer [73044,73053]
===
match
---
name: current_time [24912,24924]
name: current_time [24912,24924]
===
match
---
operator: } [14712,14713]
operator: } [14712,14713]
===
match
---
trailer [9434,9460]
trailer [9434,9460]
===
match
---
expr_stmt [67235,67304]
expr_stmt [67287,67356]
===
match
---
number: 0 [9799,9800]
number: 0 [9799,9800]
===
match
---
suite [52043,52135]
suite [52095,52187]
===
match
---
name: self [81359,81363]
name: self [81411,81415]
===
match
---
name: timezone [45032,45040]
name: timezone [45084,45092]
===
match
---
atom_expr [60734,60753]
atom_expr [60786,60805]
===
match
---
atom_expr [19233,19266]
atom_expr [19233,19266]
===
match
---
name: execute [51498,51505]
name: execute [51550,51557]
===
match
---
operator: = [37601,37602]
operator: = [37601,37602]
===
match
---
number: 256 [9960,9963]
number: 256 [9960,9963]
===
match
---
atom_expr [18091,18105]
atom_expr [18091,18105]
===
match
---
name: warn [28220,28224]
name: warn [28220,28224]
===
match
---
if_stmt [27892,27992]
if_stmt [27892,27992]
===
match
---
trailer [30830,30854]
trailer [30830,30854]
===
match
---
name: session [20181,20188]
name: session [20181,20188]
===
match
---
name: Any [64238,64241]
name: Any [64290,64293]
===
match
---
name: dag_id [79074,79080]
name: dag_id [79126,79132]
===
match
---
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.json.variable_name }}`` or             ``{{ var.json.get('variable_name', {'fall': 'back'}) }}``.             """ [63524,63752]
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.json.variable_name }}`` or             ``{{ var.json.get('variable_name', {'fall': 'back'}) }}``.             """ [63576,63804]
===
match
---
suite [82328,82358]
suite [82380,82410]
===
match
---
name: task [33261,33265]
name: task [33261,33265]
===
match
---
name: dag_id [58430,58436]
name: dag_id [58482,58488]
===
match
---
name: _execution_date [79875,79890]
name: _execution_date [79927,79942]
===
match
---
name: ts_nodash [62030,62039]
name: ts_nodash [62082,62091]
===
match
---
return_stmt [25946,25957]
return_stmt [25946,25957]
===
match
---
operator: = [54414,54415]
operator: = [54466,54467]
===
match
---
arglist [73032,73072]
arglist [73084,73124]
===
match
---
atom_expr [6665,6972]
atom_expr [6665,6972]
===
match
---
trailer [63059,63063]
trailer [63111,63115]
===
match
---
trailer [7785,7787]
trailer [7785,7787]
===
match
---
dotted_name [2858,2879]
dotted_name [2858,2879]
===
match
---
operator: , [79763,79764]
operator: , [79815,79816]
===
match
---
string: """Executes Task (optionally with a Timeout) and pushes Xcom results""" [51164,51235]
string: """Executes Task (optionally with a Timeout) and pushes Xcom results""" [51216,51287]
===
match
---
operator: = [74628,74629]
operator: = [74680,74681]
===
match
---
suite [49767,49853]
suite [49819,49905]
===
match
---
name: reschedule_exception [44106,44126]
name: reschedule_exception [44158,44178]
===
match
---
trailer [74350,74365]
trailer [74402,74417]
===
match
---
name: bool [15786,15790]
name: bool [15786,15790]
===
match
---
sliceop [82424,82427]
sliceop [82476,82479]
===
match
---
name: ti [80317,80319]
name: ti [80369,80371]
===
match
---
expr_stmt [59952,59963]
expr_stmt [60004,60015]
===
match
---
name: handle_failure [44813,44827]
name: handle_failure [44865,44879]
===
match
---
param [24119,24123]
param [24119,24123]
===
match
---
name: task_id [5285,5292]
name: task_id [5285,5292]
===
match
---
name: qry [21509,21512]
name: qry [21509,21512]
===
match
---
name: _task_id [80715,80723]
name: _task_id [80767,80775]
===
match
---
argument [10015,10024]
argument [10015,10024]
===
match
---
name: error [52304,52309]
name: error [52356,52361]
===
match
---
suite [81030,81063]
suite [81082,81115]
===
match
---
except_clause [47676,47704]
except_clause [47728,47756]
===
match
---
expr_stmt [77903,77917]
expr_stmt [77955,77969]
===
match
---
name: conf [18977,18981]
name: conf [18977,18981]
===
match
---
suite [45454,45534]
suite [45506,45586]
===
match
---
name: self [58425,58429]
name: self [58477,58481]
===
match
---
name: XCOM_RETURN_KEY [51846,51861]
name: XCOM_RETURN_KEY [51898,51913]
===
match
---
operator: = [11191,11192]
operator: = [11191,11192]
===
match
---
name: session [39146,39153]
name: session [39146,39153]
===
match
---
operator: = [59297,59298]
operator: = [59349,59350]
===
match
---
name: session [56226,56233]
name: session [56278,56285]
===
match
---
name: context [42957,42964]
name: context [43009,43016]
===
match
---
expr_stmt [14550,14594]
expr_stmt [14550,14594]
===
match
---
name: default_var [64436,64447]
name: default_var [64488,64499]
===
match
---
name: _safe_date [58545,58555]
name: _safe_date [58597,58607]
===
match
---
name: job_id [22444,22450]
name: job_id [22444,22450]
===
match
---
suite [67338,67590]
suite [67390,67642]
===
match
---
expr_stmt [4999,5011]
expr_stmt [4999,5011]
===
match
---
operator: , [10024,10025]
operator: , [10024,10025]
===
match
---
atom_expr [7027,7040]
atom_expr [7027,7040]
===
match
---
operator: = [21767,21768]
operator: = [21767,21768]
===
match
---
operator: , [43719,43720]
operator: , [43771,43772]
===
match
---
expr_stmt [61358,61428]
expr_stmt [61410,61480]
===
match
---
string: '-' [61623,61626]
string: '-' [61675,61678]
===
match
---
simple_stmt [11117,11136]
simple_stmt [11117,11136]
===
match
---
name: commit [50962,50968]
name: commit [51014,51020]
===
match
---
name: str [16010,16013]
name: str [16010,16013]
===
match
---
operator: = [32316,32317]
operator: = [32316,32317]
===
match
---
operator: == [78682,78684]
operator: == [78734,78736]
===
match
---
name: result [76960,76966]
name: result [77012,77018]
===
match
---
parameters [67666,67689]
parameters [67718,67741]
===
match
---
operator: , [15945,15946]
operator: , [15945,15946]
===
match
---
operator: = [43516,43517]
operator: = [43568,43569]
===
match
---
funcdef [80669,80724]
funcdef [80721,80776]
===
match
---
operator: , [31849,31850]
operator: , [31849,31850]
===
match
---
operator: = [11224,11225]
operator: = [11224,11225]
===
match
---
return_stmt [77192,77219]
return_stmt [77244,77271]
===
match
---
trailer [50447,50461]
trailer [50499,50513]
===
match
---
trailer [55852,55864]
trailer [55904,55916]
===
match
---
name: pendulum [29780,29788]
name: pendulum [29780,29788]
===
match
---
name: values_ordered_by_id [77199,77219]
name: values_ordered_by_id [77251,77271]
===
match
---
name: _execution_date [80801,80816]
name: _execution_date [80853,80868]
===
match
---
trailer [48499,48531]
trailer [48551,48583]
===
match
---
name: fd [4357,4359]
name: fd [4357,4359]
===
match
---
trailer [77141,77145]
trailer [77193,77197]
===
match
---
name: self [54758,54762]
name: self [54810,54814]
===
match
---
name: is_eligible_to_retry [59365,59385]
name: is_eligible_to_retry [59417,59437]
===
match
---
name: str [4232,4235]
name: str [4232,4235]
===
match
---
trailer [20273,20280]
trailer [20273,20280]
===
match
---
name: int [8565,8568]
name: int [8565,8568]
===
match
---
operator: { [42878,42879]
operator: { [42930,42931]
===
match
---
operator: , [53730,53731]
operator: , [53782,53783]
===
match
---
suite [18673,18722]
suite [18673,18722]
===
match
---
operator: = [42739,42740]
operator: = [42708,42709]
===
match
---
atom_expr [48778,48816]
atom_expr [48830,48868]
===
match
---
name: cfg_path [15391,15399]
name: cfg_path [15391,15399]
===
match
---
name: debug [22810,22815]
name: debug [22810,22815]
===
match
---
trailer [80364,80369]
trailer [80416,80421]
===
match
---
atom_expr [10096,10111]
atom_expr [10096,10111]
===
match
---
trailer [60769,60778]
trailer [60821,60830]
===
match
---
string: "Dependencies not met for %s, dependency '%s' FAILED: %s" [31946,32003]
string: "Dependencies not met for %s, dependency '%s' FAILED: %s" [31946,32003]
===
match
---
operator: == [79415,79417]
operator: == [79467,79469]
===
match
---
suite [44795,44883]
suite [44847,44935]
===
match
---
trailer [19185,19200]
trailer [19185,19200]
===
match
---
name: path [71926,71930]
name: path [71978,71982]
===
match
---
operator: -> [81246,81248]
operator: -> [81298,81300]
===
match
---
operator: = [15939,15940]
operator: = [15939,15940]
===
match
---
name: dag_run [67907,67914]
name: dag_run [67959,67966]
===
match
---
atom_expr [82656,82677]
atom_expr [82708,82729]
===
match
---
name: state [24360,24365]
name: state [24360,24365]
===
match
---
trailer [80140,80156]
trailer [80192,80208]
===
match
---
operator: , [45297,45298]
operator: , [45349,45350]
===
match
---
trailer [35422,35429]
trailer [35422,35429]
===
match
---
atom_expr [23281,23296]
atom_expr [23281,23296]
===
match
---
name: exception [70778,70787]
name: exception [70830,70839]
===
match
---
operator: , [66405,66406]
operator: , [66457,66458]
===
match
---
trailer [46594,46598]
trailer [46646,46650]
===
match
---
fstring_string: / [19043,19044]
fstring_string: / [19043,19044]
===
match
---
name: count [26290,26295]
name: count [26290,26295]
===
match
---
name: list [78312,78316]
name: list [78364,78368]
===
match
---
string: "when Dag Serialization is enabled. Hence for the task that have not yet " [66812,66886]
string: "when Dag Serialization is enabled. Hence for the task that have not yet " [66864,66938]
===
match
---
simple_stmt [80519,80538]
simple_stmt [80571,80590]
===
match
---
exprlist [66395,66421]
exprlist [66447,66473]
===
match
---
name: self [50632,50636]
name: self [50684,50688]
===
match
---
name: item [64418,64422]
name: item [64470,64474]
===
match
---
atom_expr [18139,18176]
atom_expr [18139,18176]
===
match
---
name: conf [64510,64514]
name: conf [64562,64566]
===
match
---
name: State [25284,25289]
name: State [25284,25289]
===
match
---
operator: , [41844,41845]
operator: , [41813,41814]
===
match
---
name: session [21515,21522]
name: session [21515,21522]
===
match
---
expr_stmt [72132,72185]
expr_stmt [72184,72237]
===
match
---
trailer [55273,55282]
trailer [55325,55334]
===
match
---
trailer [5433,5439]
trailer [5433,5439]
===
match
---
expr_stmt [14678,14714]
expr_stmt [14678,14714]
===
match
---
expr_stmt [61920,61980]
expr_stmt [61972,62032]
===
match
---
number: 2 [33665,33666]
number: 2 [33665,33666]
===
match
---
simple_stmt [26518,26747]
simple_stmt [26518,26747]
===
match
---
arglist [32613,32794]
arglist [32613,32794]
===
match
---
arglist [80396,80417]
arglist [80448,80469]
===
match
---
simple_stmt [54904,54945]
simple_stmt [54956,54997]
===
match
---
name: verbose_aware_logger [31908,31928]
name: verbose_aware_logger [31908,31928]
===
match
---
name: self [19181,19185]
name: self [19181,19185]
===
match
---
fstring_expr [44935,44948]
fstring_expr [44987,45000]
===
match
---
trailer [6585,7073]
trailer [6585,7073]
===
match
---
decorator [80655,80665]
decorator [80707,80717]
===
match
---
atom_expr [41724,41737]
atom_expr [41693,41706]
===
match
---
decorator [3238,3265]
decorator [3238,3265]
===
match
---
operator: { [64488,64489]
operator: { [64540,64541]
===
match
---
string: """     Clears a set of task instances, but makes sure the running ones     get killed.      :param tis: a list of task instances     :param session: current session     :param activate_dag_runs: flag to check for active dag run     :param dag: DAG object     """ [4731,4994]
string: """     Clears a set of task instances, but makes sure the running ones     get killed.      :param tis: a list of task instances     :param session: current session     :param activate_dag_runs: flag to check for active dag run     :param dag: DAG object     """ [4731,4994]
===
match
---
operator: = [22701,22702]
operator: = [22701,22702]
===
match
---
atom_expr [47820,47972]
atom_expr [47872,48024]
===
match
---
name: ignore_task_deps [15074,15090]
name: ignore_task_deps [15074,15090]
===
match
---
operator: , [32321,32322]
operator: , [32321,32322]
===
match
---
name: self [22774,22778]
name: self [22774,22778]
===
match
---
trailer [51831,51841]
trailer [51883,51893]
===
match
---
string: 'Marking task as SUCCESS. ' [45085,45112]
string: 'Marking task as SUCCESS. ' [45137,45164]
===
match
---
atom_expr [79098,79160]
atom_expr [79150,79212]
===
match
---
name: Optional [80356,80364]
name: Optional [80408,80416]
===
match
---
if_stmt [41473,41536]
if_stmt [41442,41505]
===
match
---
trailer [16009,16014]
trailer [16009,16014]
===
match
---
operator: = [46748,46749]
operator: = [46800,46801]
===
match
---
name: primary_key [9534,9545]
name: primary_key [9534,9545]
===
match
---
tfpdef [3870,3883]
tfpdef [3870,3883]
===
match
---
string: """         Checks dependencies and then sets state to RUNNING if they are met. Returns         True if and only if state is set to RUNNING, which implies that task should be         executed, in preparation for _run_raw_task          :param verbose: whether to turn on more verbose logging         :type verbose: bool         :param ignore_all_deps: Ignore all of the non-critical dependencies, just runs         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past DAG attribute         :type ignore_depends_on_past: bool         :param ignore_task_deps: Don't check the dependencies of this TaskInstance's task         :type ignore_task_deps: bool         :param ignore_ti_state: Disregards previous task instance state         :type ignore_ti_state: bool         :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param job_id: Job (BackfillJob / LocalTaskJob / SchedulerJob) ID         :type job_id: str         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         :return: whether the state was changed to running or not         :rtype: bool         """ [36047,37422]
string: """         Checks dependencies and then sets state to RUNNING if they are met. Returns         True if and only if state is set to RUNNING, which implies that task should be         executed, in preparation for _run_raw_task          :param verbose: whether to turn on more verbose logging         :type verbose: bool         :param ignore_all_deps: Ignore all of the non-critical dependencies, just runs         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past DAG attribute         :type ignore_depends_on_past: bool         :param ignore_task_deps: Don't check the dependencies of this TaskInstance's task         :type ignore_task_deps: bool         :param ignore_ti_state: Disregards previous task instance state         :type ignore_ti_state: bool         :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param job_id: Job (BackfillJob / LocalTaskJob / SchedulerJob) ID         :type job_id: str         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         :return: whether the state was changed to running or not         :rtype: bool         """ [36047,37422]
===
match
---
comparison [20246,20280]
comparison [20246,20280]
===
match
---
trailer [68102,68123]
trailer [68154,68175]
===
match
---
yield_expr [3540,3553]
yield_expr [3540,3553]
===
match
---
name: fd [4628,4630]
name: fd [4628,4630]
===
match
---
name: _pool [80304,80309]
name: _pool [80356,80361]
===
match
---
decorator [55041,55058]
decorator [55093,55110]
===
match
---
name: ti [22056,22058]
name: ti [22056,22058]
===
match
---
param [41716,41745]
param [41685,41714]
===
match
---
operator: = [56233,56234]
operator: = [56285,56286]
===
match
---
arglist [57043,57061]
arglist [57095,57113]
===
match
---
name: self [52867,52871]
name: self [52919,52923]
===
match
---
atom_expr [52561,52573]
atom_expr [52613,52625]
===
match
---
trailer [82288,82304]
trailer [82340,82356]
===
match
---
name: str [41811,41814]
name: str [41780,41783]
===
match
---
trailer [24301,24312]
trailer [24301,24312]
===
match
---
simple_stmt [9747,9802]
simple_stmt [9747,9802]
===
match
---
operator: = [15363,15364]
operator: = [15363,15364]
===
match
---
operator: = [19849,19850]
operator: = [19849,19850]
===
match
---
operator: { [65847,65848]
operator: { [65899,65900]
===
match
---
atom_expr [6016,6025]
atom_expr [6016,6025]
===
match
---
trailer [56775,56794]
trailer [56827,56846]
===
match
---
atom_expr [38454,38581]
atom_expr [38454,38581]
===
match
---
name: self [68098,68102]
name: self [68150,68154]
===
match
---
string: """         The start date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29808,30019]
string: """         The start date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29808,30019]
===
match
---
name: _handle_reschedule [44068,44086]
name: _handle_reschedule [44120,44138]
===
match
---
argument [37485,37503]
argument [37485,37503]
===
match
---
name: self [38985,38989]
name: self [38985,38989]
===
match
---
simple_stmt [1147,1161]
simple_stmt [1147,1161]
===
match
---
atom_expr [58732,58755]
atom_expr [58784,58807]
===
match
---
param [41790,41823]
param [41759,41792]
===
match
---
expr_stmt [37645,37675]
expr_stmt [37645,37675]
===
match
---
trailer [3986,3995]
trailer [3986,3995]
===
match
---
expr_stmt [37513,37539]
expr_stmt [37513,37539]
===
match
---
name: self [81046,81050]
name: self [81098,81102]
===
match
---
suite [57899,57985]
suite [57951,58037]
===
match
---
name: is_smart_sensor_compatible [49616,49642]
name: is_smart_sensor_compatible [49668,49694]
===
match
---
string: 'inlets' [64717,64725]
string: 'inlets' [64769,64777]
===
match
---
operator: , [68734,68735]
operator: , [68786,68787]
===
match
---
atom_expr [43084,43126]
atom_expr [43136,43178]
===
match
---
atom_expr [53000,53033]
atom_expr [53052,53085]
===
match
---
trailer [5332,5341]
trailer [5332,5341]
===
match
---
atom_expr [58476,58526]
atom_expr [58528,58578]
===
match
---
name: datetime [8126,8134]
name: datetime [8126,8134]
===
match
---
atom_expr [37777,37817]
atom_expr [37777,37817]
===
match
---
arglist [54402,54598]
arglist [54454,54650]
===
match
---
param [56184,56217]
param [56236,56269]
===
match
---
suite [34696,34759]
suite [34696,34759]
===
match
---
simple_stmt [67793,67881]
simple_stmt [67845,67933]
===
match
---
trailer [46598,46613]
trailer [46650,46665]
===
match
---
operator: == [21583,21585]
operator: == [21583,21585]
===
match
---
trailer [22047,22053]
trailer [22047,22053]
===
match
---
atom_expr [22399,22412]
atom_expr [22399,22412]
===
match
---
simple_stmt [23621,23785]
simple_stmt [23621,23785]
===
match
---
expr_stmt [52860,52876]
expr_stmt [52912,52928]
===
match
---
name: String [9953,9959]
name: String [9953,9959]
===
match
---
suite [32559,32893]
suite [32559,32893]
===
match
---
fstring_expr [56930,56946]
fstring_expr [56982,56998]
===
match
---
simple_stmt [7945,7987]
simple_stmt [7945,7987]
===
match
---
trailer [77585,77587]
trailer [77637,77639]
===
match
---
operator: = [9571,9572]
operator: = [9571,9572]
===
match
---
trailer [7835,7841]
trailer [7835,7841]
===
match
---
operator: , [67671,67672]
operator: , [67723,67724]
===
match
---
name: loader [71041,71047]
name: loader [71093,71099]
===
match
---
operator: = [74254,74255]
operator: = [74306,74307]
===
match
---
name: _start_date [80890,80901]
name: _start_date [80942,80953]
===
match
---
string: 'execution_date is {}; received {})' [74075,74111]
string: 'execution_date is {}; received {})' [74127,74163]
===
match
---
name: ti [22487,22489]
name: ti [22487,22489]
===
match
---
name: render [71286,71292]
name: render [71338,71344]
===
match
---
atom_expr [59577,59607]
atom_expr [59629,59659]
===
match
---
trailer [24986,25000]
trailer [24986,25000]
===
match
---
trailer [56458,56462]
trailer [56510,56514]
===
match
---
suite [79783,80538]
suite [79835,80590]
===
match
---
arglist [28238,28448]
arglist [28238,28448]
===
match
---
simple_stmt [33729,34015]
simple_stmt [33729,34015]
===
match
---
trailer [61412,61427]
trailer [61464,61479]
===
match
---
name: self [23323,23327]
name: self [23323,23327]
===
match
---
trailer [4610,4615]
trailer [4610,4615]
===
match
---
atom_expr [24297,24312]
atom_expr [24297,24312]
===
match
---
simple_stmt [53000,53034]
simple_stmt [53052,53086]
===
match
---
simple_stmt [20162,20447]
simple_stmt [20162,20447]
===
match
---
atom_expr [24815,24829]
atom_expr [24815,24829]
===
match
---
suite [41860,45648]
suite [41829,45700]
===
match
---
name: register_in_sensor_service [49811,49837]
name: register_in_sensor_service [49863,49889]
===
match
---
expr_stmt [46017,46283]
expr_stmt [46069,46335]
===
match
---
name: clear_xcom_data [23576,23591]
name: clear_xcom_data [23576,23591]
===
match
---
atom_expr [82099,82111]
atom_expr [82151,82163]
===
match
---
trailer [60083,60087]
trailer [60135,60139]
===
match
---
expr_stmt [82022,82238]
expr_stmt [82074,82290]
===
match
---
suite [52574,52806]
suite [52626,52858]
===
match
---
name: stacklevel [28955,28965]
name: stacklevel [28955,28965]
===
match
---
name: self [32951,32955]
name: self [32951,32955]
===
match
---
operator: = [61811,61812]
operator: = [61863,61864]
===
match
---
name: self [22359,22363]
name: self [22359,22363]
===
match
---
name: error_file [4336,4346]
name: error_file [4336,4346]
===
match
---
if_stmt [32122,32158]
if_stmt [32122,32158]
===
match
---
expr_stmt [58239,58276]
expr_stmt [58291,58328]
===
match
---
operator: , [10606,10607]
operator: , [10606,10607]
===
match
---
operator: = [40813,40814]
operator: = [42773,42774]
===
match
---
name: execution_date [73925,73939]
name: execution_date [73977,73991]
===
match
---
name: taskreschedule [1974,1988]
name: taskreschedule [1974,1988]
===
match
---
name: should_pass_filepath [14728,14748]
name: should_pass_filepath [14728,14748]
===
match
---
name: airflow [7482,7489]
name: airflow [7482,7489]
===
match
---
name: property [25037,25045]
name: property [25037,25045]
===
match
---
simple_stmt [28731,28979]
simple_stmt [28731,28979]
===
match
---
fstring_expr [32964,32978]
fstring_expr [32964,32978]
===
match
---
name: self [59748,59752]
name: self [59800,59804]
===
match
---
name: prev_execution_date [65084,65103]
name: prev_execution_date [65136,65155]
===
match
---
operator: = [51486,51487]
operator: = [51538,51539]
===
match
---
name: models [35293,35299]
name: models [35293,35299]
===
match
---
simple_stmt [58732,58756]
simple_stmt [58784,58808]
===
match
---
operator: = [72140,72141]
operator: = [72192,72193]
===
match
---
name: self [81439,81443]
name: self [81491,81495]
===
match
---
argument [53901,53932]
argument [53953,53984]
===
match
---
name: task [25908,25912]
name: task [25908,25912]
===
match
---
expr_stmt [61461,61482]
expr_stmt [61513,61534]
===
match
---
name: state [43540,43545]
name: state [43592,43597]
===
match
---
funcdef [67628,67921]
funcdef [67680,67973]
===
match
---
trailer [55434,55439]
trailer [55486,55491]
===
match
---
trailer [4392,4397]
trailer [4392,4397]
===
match
---
trailer [63932,63936]
trailer [63984,63988]
===
match
---
expr_stmt [11214,11230]
expr_stmt [11214,11230]
===
match
---
name: self [44389,44393]
name: self [44441,44445]
===
match
---
trailer [42701,42718]
trailer [42670,42687]
===
match
---
name: hr_line_break [37898,37911]
name: hr_line_break [37898,37911]
===
match
---
atom_expr [37750,37763]
atom_expr [37750,37763]
===
match
---
atom_expr [6603,6612]
atom_expr [6603,6612]
===
match
---
name: dag_id [21576,21582]
name: dag_id [21576,21582]
===
match
---
operator: = [74287,74288]
operator: = [74339,74340]
===
match
---
expr_stmt [13241,13265]
expr_stmt [13241,13265]
===
match
---
trailer [5247,5258]
trailer [5247,5258]
===
match
---
operator: , [76510,76511]
operator: , [76562,76563]
===
match
---
trailer [23897,23904]
trailer [23897,23904]
===
match
---
name: provide_session [35060,35075]
name: provide_session [35060,35075]
===
match
---
trailer [43484,43500]
trailer [43536,43552]
===
match
---
string: 'ti_successes' [50680,50694]
string: 'ti_successes' [50732,50746]
===
match
---
decorator [24319,24336]
decorator [24319,24336]
===
match
---
atom_expr [50535,50589]
atom_expr [50587,50641]
===
match
---
name: dirname [71080,71087]
name: dirname [71132,71139]
===
match
---
name: _dag_id [79797,79804]
name: _dag_id [79849,79856]
===
match
---
operator: , [24370,24371]
operator: , [24370,24371]
===
match
---
expr_stmt [48258,48279]
expr_stmt [48310,48331]
===
match
---
and_test [78642,78699]
and_test [78694,78751]
===
match
---
trailer [7714,7718]
trailer [7714,7718]
===
match
---
name: error [54642,54647]
name: error [54694,54699]
===
match
---
name: execution_date [11940,11954]
name: execution_date [11940,11954]
===
match
---
suite [22910,23546]
suite [22910,23546]
===
match
---
expr_stmt [39890,39913]
expr_stmt [39890,39913]
===
match
---
name: mark_success [37962,37974]
name: mark_success [37962,37974]
===
match
---
annassign [79994,80018]
annassign [80046,80070]
===
match
---
operator: = [41774,41775]
operator: = [41743,41744]
===
match
---
name: ti [22660,22662]
name: ti [22660,22662]
===
match
---
name: ignore_all_deps [15615,15630]
name: ignore_all_deps [15615,15630]
===
match
---
operator: } [50651,50652]
operator: } [50703,50704]
===
match
---
trailer [82055,82062]
trailer [82107,82114]
===
match
---
name: Union [4244,4249]
name: Union [4244,4249]
===
match
---
name: hostname [9838,9846]
name: hostname [9838,9846]
===
match
---
name: ti [6046,6048]
name: ti [6046,6048]
===
match
---
arglist [11511,11625]
arglist [11511,11625]
===
match
---
name: ts_nodash_with_tz [62096,62113]
name: ts_nodash_with_tz [62148,62165]
===
match
---
atom_expr [18067,18107]
atom_expr [18067,18107]
===
match
---
operator: , [1859,1860]
operator: , [1859,1860]
===
match
---
atom_expr [32951,32962]
atom_expr [32951,32962]
===
match
---
name: task_type [50642,50651]
name: task_type [50694,50703]
===
match
---
dotted_name [2016,2039]
dotted_name [2016,2039]
===
match
---
name: verbose [53403,53410]
name: verbose [53455,53462]
===
match
---
name: self [20322,20326]
name: self [20322,20326]
===
match
---
arglist [10006,10040]
arglist [10006,10040]
===
match
---
expr_stmt [5368,5396]
expr_stmt [5368,5396]
===
match
---
param [14014,14019]
param [14014,14019]
===
match
---
simple_stmt [59687,59697]
simple_stmt [59739,59749]
===
match
---
operator: { [44964,44965]
operator: { [45016,45017]
===
match
---
name: pod_mutation_hook [69036,69053]
name: pod_mutation_hook [69088,69105]
===
match
---
name: airflow [2016,2023]
name: airflow [2016,2023]
===
match
---
simple_stmt [58071,58111]
simple_stmt [58123,58163]
===
match
---
name: commit [47655,47661]
name: commit [47707,47713]
===
match
---
name: dep [32510,32513]
name: dep [32510,32513]
===
match
---
trailer [40227,40237]
trailer [40227,40237]
===
match
---
operator: = [29171,29172]
operator: = [29171,29172]
===
match
---
name: self [13155,13159]
name: self [13155,13159]
===
match
---
trailer [77802,77804]
trailer [77854,77856]
===
match
---
operator: } [49292,49293]
operator: } [49344,49345]
===
match
---
param [23598,23610]
param [23598,23610]
===
match
---
operator: , [10759,10760]
operator: , [10759,10760]
===
match
---
atom_expr [51338,51365]
atom_expr [51390,51417]
===
match
---
suite [54265,54285]
suite [54317,54337]
===
match
---
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [70148,70197]
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [70200,70249]
===
match
---
name: log [2509,2512]
name: log [2509,2512]
===
match
---
argument [62525,62538]
argument [62577,62590]
===
match
---
comparison [3626,3651]
comparison [3626,3651]
===
match
---
trailer [40541,40545]
trailer [40541,40545]
===
match
---
expr_stmt [9939,9981]
expr_stmt [9939,9981]
===
match
---
name: self [22730,22734]
name: self [22730,22734]
===
match
---
argument [50120,50133]
argument [50172,50185]
===
match
---
trailer [51505,51522]
trailer [51557,51574]
===
match
---
trailer [56418,56436]
trailer [56470,56488]
===
match
---
operator: , [54083,54084]
operator: , [54135,54136]
===
match
---
name: task [11262,11266]
name: task [11262,11266]
===
match
---
name: execution_date [60739,60753]
name: execution_date [60791,60805]
===
match
---
trailer [7217,7225]
trailer [7217,7225]
===
match
---
trailer [45020,45029]
trailer [45072,45081]
===
match
---
name: self [22475,22479]
name: self [22475,22479]
===
match
---
name: raw [77914,77917]
name: raw [77966,77969]
===
match
---
argument [71561,71580]
argument [71613,71632]
===
match
---
fstring_string: . [48732,48733]
fstring_string: . [48784,48785]
===
match
---
trailer [25274,25280]
trailer [25274,25280]
===
match
---
trailer [11197,11205]
trailer [11197,11205]
===
match
---
return_stmt [8422,8521]
return_stmt [8422,8521]
===
match
---
name: dag_id [26068,26074]
name: dag_id [26068,26074]
===
match
---
operator: = [27982,27983]
operator: = [27982,27983]
===
match
---
simple_stmt [46959,47152]
simple_stmt [47011,47204]
===
match
---
operator: , [74645,74646]
operator: , [74697,74698]
===
match
---
trailer [15969,15974]
trailer [15969,15974]
===
match
---
parameters [56046,56245]
parameters [56098,56297]
===
match
---
name: timezone [2391,2399]
name: timezone [2391,2399]
===
match
---
operator: = [79956,79957]
operator: = [80008,80009]
===
match
---
name: merge [25019,25024]
name: merge [25019,25024]
===
match
---
name: pendulum [30371,30379]
name: pendulum [30371,30379]
===
match
---
expr_stmt [69730,70097]
expr_stmt [69782,70149]
===
match
---
comparison [5122,5147]
comparison [5122,5147]
===
match
---
tfpdef [63886,63895]
tfpdef [63938,63947]
===
match
---
argument [28955,28967]
argument [28955,28967]
===
match
---
simple_stmt [3139,3164]
simple_stmt [3139,3164]
===
match
---
name: self [77944,77948]
name: self [77996,78000]
===
match
---
trailer [59217,59232]
trailer [59269,59284]
===
match
---
atom_expr [13155,13171]
atom_expr [13155,13171]
===
match
---
name: default_subject [71174,71189]
name: default_subject [71226,71241]
===
match
---
trailer [7579,7585]
trailer [7579,7585]
===
match
---
name: session [55907,55914]
name: session [55959,55966]
===
match
---
operator: = [23440,23441]
operator: = [23440,23441]
===
match
---
trailer [9579,9610]
trailer [9579,9610]
===
match
---
operator: , [18708,18709]
operator: , [18708,18709]
===
match
---
operator: = [38289,38290]
operator: = [38289,38290]
===
match
---
name: execution_date [60549,60563]
name: execution_date [60601,60615]
===
match
---
name: ti [82280,82282]
name: ti [82332,82334]
===
match
---
trailer [14655,14664]
trailer [14655,14664]
===
match
---
operator: , [27233,27234]
operator: , [27233,27234]
===
match
---
trailer [29779,29798]
trailer [29779,29798]
===
match
---
operator: , [58436,58437]
operator: , [58488,58489]
===
match
---
if_stmt [47338,47471]
if_stmt [47390,47523]
===
match
---
trailer [71362,71388]
trailer [71414,71440]
===
match
---
trailer [19241,19266]
trailer [19241,19266]
===
match
---
atom_expr [42571,42580]
atom_expr [42540,42549]
===
match
---
trailer [40824,40826]
trailer [42784,42786]
===
match
---
param [25067,25071]
param [25067,25071]
===
match
---
name: self [22556,22560]
name: self [22556,22560]
===
match
---
name: error_file [54540,54550]
name: error_file [54592,54602]
===
match
---
operator: = [80315,80316]
operator: = [80367,80368]
===
match
---
operator: } [44962,44963]
operator: } [45014,45015]
===
match
---
argument [10887,10939]
argument [10887,10939]
===
match
---
name: append [5241,5247]
name: append [5241,5247]
===
match
---
operator: , [29707,29708]
operator: , [29707,29708]
===
match
---
simple_stmt [44624,44631]
simple_stmt [44676,44683]
===
match
---
trailer [48454,48462]
trailer [48506,48514]
===
match
---
name: delete [7175,7181]
name: delete [7175,7181]
===
match
---
atom_expr [45209,45220]
atom_expr [45261,45272]
===
match
---
trailer [22805,22809]
trailer [22805,22809]
===
match
---
name: test_mode [45576,45585]
name: test_mode [45628,45637]
===
match
---
trailer [78058,78077]
trailer [78110,78129]
===
match
---
simple_stmt [60593,60630]
simple_stmt [60645,60682]
===
match
---
name: context [68067,68074]
name: context [68119,68126]
===
match
---
simple_stmt [68374,68401]
simple_stmt [68426,68453]
===
match
---
suite [19121,19366]
suite [19121,19366]
===
match
---
atom_expr [63431,63474]
atom_expr [63483,63526]
===
match
---
name: TaskInstanceKey [78028,78043]
name: TaskInstanceKey [78080,78095]
===
match
---
suite [51960,52266]
suite [52012,52318]
===
match
---
simple_stmt [79562,79614]
simple_stmt [79614,79666]
===
match
---
funcdef [63077,63134]
funcdef [63129,63186]
===
match
---
if_stmt [67752,67921]
if_stmt [67804,67973]
===
match
---
decorator [18816,18826]
decorator [18816,18826]
===
match
---
trailer [69437,69451]
trailer [69489,69503]
===
match
---
name: self [24262,24266]
name: self [24262,24266]
===
match
---
trailer [43770,43778]
trailer [43822,43830]
===
match
---
funcdef [69161,72412]
funcdef [69213,72464]
===
match
---
return_stmt [41544,41553]
return_stmt [41513,41522]
===
match
---
operator: , [18161,18162]
operator: , [18161,18162]
===
match
---
suite [67484,67590]
suite [67536,67642]
===
match
---
atom_expr [32413,32425]
atom_expr [32413,32425]
===
match
---
trailer [74259,74267]
trailer [74311,74319]
===
match
---
trailer [21590,21597]
trailer [21590,21597]
===
match
---
operator: , [51861,51862]
operator: , [51913,51914]
===
match
---
param [59386,59390]
param [59438,59442]
===
match
---
name: error [54786,54791]
name: error [54838,54843]
===
match
---
operator: , [62538,62539]
operator: , [62590,62591]
===
match
---
simple_stmt [19564,19792]
simple_stmt [19564,19792]
===
match
---
arglist [72305,72354]
arglist [72357,72406]
===
match
---
atom_expr [34721,34758]
atom_expr [34721,34758]
===
match
---
trailer [48999,49006]
trailer [49051,49058]
===
match
---
operator: , [24274,24275]
operator: , [24274,24275]
===
match
---
comparison [53047,53079]
comparison [53099,53131]
===
match
---
name: property [8268,8276]
name: property [8268,8276]
===
match
---
param [24372,24384]
param [24372,24384]
===
match
---
trailer [71071,71098]
trailer [71123,71150]
===
match
---
atom_expr [82398,82437]
atom_expr [82450,82489]
===
match
---
trailer [45527,45533]
trailer [45579,45585]
===
match
---
atom_expr [40735,40759]
atom_expr [40735,40759]
===
match
---
trailer [39505,39771]
trailer [39505,39771]
===
match
---
name: next_execution_date [61208,61227]
name: next_execution_date [61260,61279]
===
match
---
expr_stmt [72896,72961]
expr_stmt [72948,73013]
===
match
---
simple_stmt [80165,80205]
simple_stmt [80217,80257]
===
match
---
name: self [11178,11182]
name: self [11178,11182]
===
match
---
name: params [60135,60141]
name: params [60187,60193]
===
match
---
name: execution_date [17874,17888]
name: execution_date [17874,17888]
===
match
---
suite [58817,58896]
suite [58869,58948]
===
match
---
name: task_ids [77170,77178]
name: task_ids [77222,77230]
===
match
---
name: error_file [44853,44863]
name: error_file [44905,44915]
===
match
---
name: previous_ti_success [28520,28539]
name: previous_ti_success [28520,28539]
===
match
---
if_stmt [52616,52806]
if_stmt [52668,52858]
===
match
---
operator: = [59860,59861]
operator: = [59912,59913]
===
match
---
name: __getattr__ [63835,63846]
name: __getattr__ [63887,63898]
===
match
---
trailer [61180,61195]
trailer [61232,61247]
===
match
---
name: dag_run [67867,67874]
name: dag_run [67919,67926]
===
match
---
atom_expr [48555,48569]
atom_expr [48607,48621]
===
match
---
name: base_job [82505,82513]
name: base_job [82557,82565]
===
match
---
name: try_number [80054,80064]
name: try_number [80106,80116]
===
match
---
name: str [15532,15535]
name: str [15532,15535]
===
match
---
simple_stmt [5016,5092]
simple_stmt [5016,5092]
===
match
---
name: context [3793,3800]
name: context [3793,3800]
===
match
---
operator: , [19542,19543]
operator: , [19542,19543]
===
match
---
funcdef [25050,25334]
funcdef [25050,25334]
===
match
---
atom_expr [80256,80273]
atom_expr [80308,80325]
===
match
---
trailer [18388,18395]
trailer [18388,18395]
===
match
---
atom_expr [79335,79355]
atom_expr [79387,79407]
===
match
---
trailer [10672,10728]
trailer [10672,10728]
===
match
---
operator: } [48731,48732]
operator: } [48783,48784]
===
match
---
simple_stmt [10255,10306]
simple_stmt [10255,10306]
===
match
---
name: filepath [14656,14664]
name: filepath [14656,14664]
===
match
---
parameters [13218,13231]
parameters [13218,13231]
===
match
---
name: priority_weight [22616,22631]
name: priority_weight [22616,22631]
===
match
---
operator: , [10649,10650]
operator: , [10649,10650]
===
match
---
trailer [23446,23454]
trailer [23446,23454]
===
match
---
name: pod [69122,69125]
name: pod [69174,69177]
===
match
---
name: models [1922,1928]
name: models [1922,1928]
===
match
---
simple_stmt [72365,72412]
simple_stmt [72417,72464]
===
match
---
name: bool [36033,36037]
name: bool [36033,36037]
===
match
---
parameters [80680,80686]
parameters [80732,80738]
===
match
---
try_stmt [72610,72771]
try_stmt [72662,72823]
===
match
---
trailer [54706,54716]
trailer [54758,54768]
===
match
---
name: debug [21450,21455]
name: debug [21450,21455]
===
match
---
expr_stmt [82579,82622]
expr_stmt [82631,82674]
===
match
---
name: self [60544,60548]
name: self [60596,60600]
===
match
---
expr_stmt [23281,23314]
expr_stmt [23281,23314]
===
match
---
name: job_id [18119,18125]
name: job_id [18119,18125]
===
match
---
operator: = [69081,69082]
operator: = [69133,69134]
===
match
---
dotted_name [2061,2080]
dotted_name [2061,2080]
===
match
---
name: bool [15632,15636]
name: bool [15632,15636]
===
match
---
name: _try_number [13926,13937]
name: _try_number [13926,13937]
===
match
---
name: from_string [71162,71173]
name: from_string [71214,71225]
===
match
---
suite [44648,44744]
suite [44700,44796]
===
match
---
trailer [8232,8240]
trailer [8232,8240]
===
match
---
operator: } [49288,49289]
operator: } [49340,49341]
===
match
---
simple_stmt [5413,5440]
simple_stmt [5413,5440]
===
match
---
trailer [10290,10304]
trailer [10290,10304]
===
match
---
name: dag_run [60234,60241]
name: dag_run [60286,60293]
===
match
---
name: self [55430,55434]
name: self [55482,55486]
===
match
---
name: airflow [2448,2455]
name: airflow [2448,2455]
===
match
---
atom_expr [7355,7378]
atom_expr [7355,7378]
===
match
---
simple_stmt [58137,58169]
simple_stmt [58189,58221]
===
match
---
name: start_date [24975,24985]
name: start_date [24975,24985]
===
match
---
trailer [43235,43240]
trailer [43287,43292]
===
match
---
name: property [30308,30316]
name: property [30308,30316]
===
match
---
name: self [33888,33892]
name: self [33888,33892]
===
match
---
argument [38538,38553]
argument [38538,38553]
===
match
---
trailer [23845,23851]
trailer [23845,23851]
===
match
---
decorated [19797,20554]
decorated [19797,20554]
===
match
---
if_stmt [52889,53034]
if_stmt [52941,53086]
===
match
---
name: self [80851,80855]
name: self [80903,80907]
===
match
---
simple_stmt [51969,52031]
simple_stmt [52021,52083]
===
match
---
simple_stmt [21919,21951]
simple_stmt [21919,21951]
===
match
---
trailer [55914,55921]
trailer [55966,55973]
===
match
---
name: is_localized [11435,11447]
name: is_localized [11435,11447]
===
match
---
operator: = [26831,26832]
operator: = [26831,26832]
===
match
---
string: 'email' [71891,71898]
string: 'email' [71943,71950]
===
match
---
trailer [61388,61407]
trailer [61440,61459]
===
match
---
name: session [46251,46258]
name: session [46303,46310]
===
match
---
comp_op [52644,52650]
comp_op [52696,52702]
===
match
---
name: airflow [1959,1966]
name: airflow [1959,1966]
===
match
---
name: XCOM_RETURN_KEY [2088,2103]
name: XCOM_RETURN_KEY [2088,2103]
===
match
---
atom_expr [40597,40611]
atom_expr [40597,40611]
===
match
---
name: dag_id [80601,80607]
name: dag_id [80653,80659]
===
match
---
classdef [62566,63475]
classdef [62618,63527]
===
match
---
trailer [81443,81448]
trailer [81495,81500]
===
match
---
param [52304,52349]
param [52356,52401]
===
match
---
arglist [41449,41459]
arglist [41418,41428]
===
match
---
simple_stmt [78184,78196]
simple_stmt [78236,78248]
===
match
---
string: """Fetch rendered template fields from DB""" [67102,67146]
string: """Fetch rendered template fields from DB""" [67154,67198]
===
match
---
atom_expr [33739,34014]
atom_expr [33739,34014]
===
match
---
atom_expr [39036,39046]
atom_expr [39036,39046]
===
match
---
name: str [19859,19862]
name: str [19859,19862]
===
match
---
atom_expr [47201,47221]
atom_expr [47253,47273]
===
match
---
tfpdef [59142,59158]
tfpdef [59194,59210]
===
match
---
name: start_date [50887,50897]
name: start_date [50939,50949]
===
match
---
name: signal [878,884]
name: signal [878,884]
===
match
---
name: State [65236,65241]
name: State [65288,65293]
===
match
---
name: max_tries [5503,5512]
name: max_tries [5503,5512]
===
match
---
parameters [77840,77857]
parameters [77892,77909]
===
match
---
operator: = [6562,6563]
operator: = [6562,6563]
===
match
---
expr_stmt [27033,27101]
expr_stmt [27033,27101]
===
match
---
trailer [59119,59125]
trailer [59171,59177]
===
match
---
name: execution_date [62047,62061]
name: execution_date [62099,62113]
===
match
---
trailer [74543,74563]
trailer [74595,74615]
===
match
---
trailer [44232,44234]
trailer [44284,44286]
===
match
---
name: previous_start_date_success [30325,30352]
name: previous_start_date_success [30325,30352]
===
match
---
name: state [10761,10766]
name: state [10761,10766]
===
match
---
name: executor_config [68795,68810]
name: executor_config [68847,68862]
===
match
---
name: cfg_path [18733,18741]
name: cfg_path [18733,18741]
===
match
---
name: self [8215,8219]
name: self [8215,8219]
===
match
---
name: PodGenerator [68415,68427]
name: PodGenerator [68467,68479]
===
match
---
name: State [44593,44598]
name: State [44645,44650]
===
match
---
name: task [57125,57129]
name: task [57177,57181]
===
match
---
suite [44607,44631]
suite [44659,44683]
===
match
---
operator: = [5513,5514]
operator: = [5513,5514]
===
match
---
name: get_previous_start_date [29670,29693]
name: get_previous_start_date [29670,29693]
===
match
---
simple_stmt [48660,48683]
simple_stmt [48712,48735]
===
match
---
funcdef [74432,77366]
funcdef [74484,77418]
===
match
---
name: str [74544,74547]
name: str [74596,74599]
===
match
---
trailer [71395,71412]
trailer [71447,71464]
===
match
---
decorator [35059,35076]
decorator [35059,35076]
===
match
---
atom_expr [61883,61907]
atom_expr [61935,61959]
===
match
---
name: refresh_from_db [42686,42701]
name: refresh_from_db [42655,42670]
===
match
---
atom_expr [61942,61980]
atom_expr [61994,62032]
===
match
---
name: previous_scheduled_date [27033,27056]
name: previous_scheduled_date [27033,27056]
===
match
---
atom_expr [26255,26268]
atom_expr [26255,26268]
===
match
---
name: self [24970,24974]
name: self [24970,24974]
===
match
---
name: self [56056,56060]
name: self [56108,56112]
===
match
---
funcdef [59723,66065]
funcdef [59775,66117]
===
match
---
atom_expr [23934,23946]
atom_expr [23934,23946]
===
match
---
decorator [81537,81554]
decorator [81589,81606]
===
match
---
name: f [72032,72033]
name: f [72084,72085]
===
match
---
operator: { [19630,19631]
operator: { [19630,19631]
===
match
---
operator: , [17925,17926]
operator: , [17925,17926]
===
match
---
operator: , [11592,11593]
operator: , [11592,11593]
===
match
---
operator: , [11624,11625]
operator: , [11624,11625]
===
match
---
atom_expr [32464,32478]
atom_expr [32464,32478]
===
match
---
name: self [22684,22688]
name: self [22684,22688]
===
match
---
name: str [35989,35992]
name: str [35989,35992]
===
match
---
atom_expr [78941,79008]
atom_expr [78993,79060]
===
match
---
name: str [74598,74601]
name: str [74650,74653]
===
match
---
name: ti [80051,80053]
name: ti [80103,80105]
===
match
---
name: DagRun [45903,45909]
name: DagRun [45955,45961]
===
match
---
operator: = [10298,10299]
operator: = [10298,10299]
===
match
---
operator: = [10332,10333]
operator: = [10332,10333]
===
match
---
atom [60653,60689]
atom [60705,60741]
===
match
---
trailer [39260,39271]
trailer [39260,39271]
===
match
---
trailer [79267,79450]
trailer [79319,79502]
===
match
---
dotted_name [13182,13199]
dotted_name [13182,13199]
===
match
---
operator: = [60349,60350]
operator: = [60401,60402]
===
match
---
name: read [72034,72038]
name: read [72086,72090]
===
match
---
argument [27866,27877]
argument [27866,27877]
===
match
---
name: bool [53412,53416]
name: bool [53464,53468]
===
match
---
operator: , [39840,39841]
operator: , [39840,39841]
===
match
---
name: state [7836,7841]
name: state [7836,7841]
===
match
---
trailer [77568,77574]
trailer [77620,77626]
===
match
---
expr_stmt [22439,22462]
expr_stmt [22439,22462]
===
match
---
name: datetime [80771,80779]
name: datetime [80823,80831]
===
match
---
trailer [45047,45049]
trailer [45099,45101]
===
match
---
simple_stmt [66480,66527]
simple_stmt [66532,66579]
===
match
---
name: ignore_depends_on_past [15121,15143]
name: ignore_depends_on_past [15121,15143]
===
match
---
simple_stmt [2853,2895]
simple_stmt [2853,2895]
===
match
---
name: ignore_ti_state [35828,35843]
name: ignore_ti_state [35828,35843]
===
match
---
name: foreign_keys [10949,10961]
name: foreign_keys [10949,10961]
===
match
---
import_name [805,819]
import_name [805,819]
===
match
---
trailer [62118,62126]
trailer [62170,62178]
===
match
---
atom_expr [3665,3847]
atom_expr [3665,3847]
===
match
---
operator: - [8516,8517]
operator: - [8516,8517]
===
match
---
number: 16 [33997,33999]
number: 16 [33997,33999]
===
match
---
param [29709,29737]
param [29709,29737]
===
match
---
name: first_task_id [78981,78994]
name: first_task_id [79033,79046]
===
match
---
operator: = [11955,11956]
operator: = [11955,11956]
===
match
---
operator: = [9974,9975]
operator: = [9974,9975]
===
match
---
operator: = [39493,39494]
operator: = [39493,39494]
===
match
---
trailer [52838,52846]
trailer [52890,52898]
===
match
---
atom_expr [64927,64939]
atom_expr [64979,64991]
===
match
---
operator: = [54021,54022]
operator: = [54073,54074]
===
match
---
name: Optional [67962,67970]
name: Optional [68014,68022]
===
match
---
name: self [81510,81514]
name: self [81562,81566]
===
match
---
name: session [27975,27982]
name: session [27975,27982]
===
match
---
trailer [55936,55940]
trailer [55988,55992]
===
match
---
trailer [11280,11285]
trailer [11280,11285]
===
match
---
name: pool [18595,18599]
name: pool [18595,18599]
===
match
---
if_stmt [44560,44744]
if_stmt [44612,44796]
===
match
---
operator: = [46853,46854]
operator: = [46905,46906]
===
match
---
operator: = [49487,49488]
operator: = [49539,49540]
===
match
---
operator: , [3800,3801]
operator: , [3800,3801]
===
match
---
name: item [64147,64151]
name: item [64199,64203]
===
match
---
name: int [8066,8069]
name: int [8066,8069]
===
match
---
trailer [21455,21499]
trailer [21455,21499]
===
match
---
operator: , [4680,4681]
operator: , [4680,4681]
===
match
---
parameters [29093,29184]
parameters [29093,29184]
===
match
---
trailer [11182,11190]
trailer [11182,11190]
===
match
---
trailer [19469,19502]
trailer [19469,19502]
===
match
---
name: task [34675,34679]
name: task [34675,34679]
===
match
---
name: delay [34713,34718]
name: delay [34713,34718]
===
match
---
operator: , [40752,40753]
operator: , [40752,40753]
===
match
---
simple_stmt [12383,12406]
simple_stmt [12383,12406]
===
match
---
simple_stmt [2490,2547]
simple_stmt [2490,2547]
===
match
---
atom_expr [52867,52876]
atom_expr [52919,52928]
===
match
---
import_from [7477,7517]
import_from [7477,7517]
===
match
---
name: schedule_interval [27612,27629]
name: schedule_interval [27612,27629]
===
match
---
trailer [23303,23314]
trailer [23303,23314]
===
match
---
simple_stmt [1135,1147]
simple_stmt [1135,1147]
===
match
---
trailer [7365,7369]
trailer [7365,7369]
===
match
---
trailer [24744,24755]
trailer [24744,24755]
===
match
---
simple_stmt [61358,61429]
simple_stmt [61410,61481]
===
match
---
argument [51673,51688]
argument [51725,51740]
===
match
---
operator: } [32977,32978]
operator: } [32977,32978]
===
match
---
suite [18453,18490]
suite [18453,18490]
===
match
---
name: signal [48541,48547]
name: signal [48593,48599]
===
match
---
suite [67093,67623]
suite [67145,67675]
===
match
---
name: self [57847,57851]
name: self [57899,57903]
===
match
---
fstring_string: . [42877,42878]
fstring_string: . [42929,42930]
===
match
---
comparison [82076,82111]
comparison [82128,82163]
===
match
---
argument [54540,54564]
argument [54592,54616]
===
match
---
name: Index [10667,10672]
name: Index [10667,10672]
===
match
---
name: retries [5476,5483]
name: retries [5476,5483]
===
match
---
atom_expr [8110,8135]
atom_expr [8110,8135]
===
match
---
name: str [11095,11098]
name: str [11095,11098]
===
match
---
argument [65383,65402]
argument [65435,65454]
===
match
---
name: ignore_all_deps [39578,39593]
name: ignore_all_deps [39578,39593]
===
match
---
decorated [13271,13822]
decorated [13271,13822]
===
match
---
operator: = [9545,9546]
operator: = [9545,9546]
===
match
---
trailer [62315,62323]
trailer [62367,62375]
===
match
---
name: state [44568,44573]
name: state [44620,44625]
===
match
---
operator: = [9491,9492]
operator: = [9491,9492]
===
match
---
atom_expr [30282,30300]
atom_expr [30282,30300]
===
match
---
atom_expr [23531,23545]
atom_expr [23531,23545]
===
match
---
dictorsetmaker [47002,47133]
dictorsetmaker [47054,47185]
===
match
---
strings [19596,19781]
strings [19596,19781]
===
match
---
trailer [49943,49947]
trailer [49995,49999]
===
match
---
simple_stmt [23793,23830]
simple_stmt [23793,23830]
===
match
---
name: State [52561,52566]
name: State [52613,52618]
===
match
---
atom_expr [7407,7416]
atom_expr [7407,7416]
===
match
---
arith_expr [37914,37931]
arith_expr [37914,37931]
===
match
---
atom_expr [24056,24091]
atom_expr [24056,24091]
===
match
---
comparison [23918,23946]
comparison [23918,23946]
===
match
---
decorated [20559,20933]
decorated [20559,20933]
===
match
---
name: self [60350,60354]
name: self [60402,60406]
===
match
---
name: ti [47188,47190]
name: ti [47240,47242]
===
match
---
name: verbose [30965,30972]
name: verbose [30965,30972]
===
match
---
argument [30116,30127]
argument [30116,30127]
===
match
---
name: get_dagrun [26813,26823]
name: get_dagrun [26813,26823]
===
match
---
name: query [35382,35387]
name: query [35382,35387]
===
match
---
atom_expr [68462,68473]
atom_expr [68514,68525]
===
match
---
argument [6789,6923]
argument [6789,6923]
===
match
---
operator: == [78954,78956]
operator: == [79006,79008]
===
match
---
trailer [68123,68125]
trailer [68175,68177]
===
match
---
name: utils [2560,2565]
name: utils [2560,2565]
===
match
---
argument [15311,15318]
argument [15311,15318]
===
match
---
expr_stmt [82280,82314]
expr_stmt [82332,82366]
===
match
---
simple_stmt [7149,7202]
simple_stmt [7149,7202]
===
match
---
name: Iterable [74549,74557]
name: Iterable [74601,74609]
===
match
---
param [15955,15982]
param [15955,15982]
===
match
---
operator: = [80090,80091]
operator: = [80142,80143]
===
match
---
name: collections [906,917]
name: collections [906,917]
===
match
---
operator: = [50441,50442]
operator: = [50493,50494]
===
match
---
operator: , [59132,59133]
operator: , [59184,59185]
===
match
---
dotted_name [67160,67191]
dotted_name [67212,67243]
===
match
---
operator: = [5293,5294]
operator: = [5293,5294]
===
match
---
expr_stmt [68374,68400]
expr_stmt [68426,68452]
===
match
---
trailer [23807,23829]
trailer [23807,23829]
===
match
---
atom [67438,67478]
atom [67490,67530]
===
match
---
name: state [24718,24723]
name: state [24718,24723]
===
match
---
name: error [56546,56551]
name: error [56598,56603]
===
match
---
name: context [43057,43064]
name: context [43109,43116]
===
match
---
operator: = [44291,44292]
operator: = [44343,44344]
===
match
---
operator: = [14300,14301]
operator: = [14300,14301]
===
match
---
operator: , [35444,35445]
operator: , [35444,35445]
===
match
---
name: int [15828,15831]
name: int [15828,15831]
===
match
---
atom_expr [8429,8521]
atom_expr [8429,8521]
===
match
---
name: session [55879,55886]
name: session [55931,55938]
===
match
---
operator: , [64283,64284]
operator: , [64335,64336]
===
match
---
suite [59559,59697]
suite [59611,59749]
===
match
---
suite [32917,33018]
suite [32917,33018]
===
match
---
string: "Task received SIGTERM signal" [48500,48530]
string: "Task received SIGTERM signal" [48552,48582]
===
match
---
param [81092,81096]
param [81144,81148]
===
match
---
string: 'task_instance_key_str' [65522,65545]
string: 'task_instance_key_str' [65574,65597]
===
match
---
name: first_task_id [78410,78423]
name: first_task_id [78462,78475]
===
match
---
import_from [1615,1812]
import_from [1615,1812]
===
match
---
arglist [24249,24312]
arglist [24249,24312]
===
match
---
name: airflow [2210,2217]
name: airflow [2210,2217]
===
match
---
name: ignore_all_deps [14056,14071]
name: ignore_all_deps [14056,14071]
===
match
---
suite [18507,18544]
suite [18507,18544]
===
match
---
arith_expr [34774,34795]
arith_expr [34774,34795]
===
match
---
trailer [60275,60283]
trailer [60327,60335]
===
match
---
trailer [33742,34014]
trailer [33742,34014]
===
match
---
suite [80952,80983]
suite [81004,81035]
===
match
---
name: execution_timeout [51348,51365]
name: execution_timeout [51400,51417]
===
match
---
trailer [39139,39162]
trailer [39139,39162]
===
match
---
name: _end_date [80973,80982]
name: _end_date [81025,81034]
===
match
---
operator: , [3906,3907]
operator: , [3906,3907]
===
match
---
trailer [51587,51595]
trailer [51639,51647]
===
match
---
name: TaskInstance [21661,21673]
name: TaskInstance [21661,21673]
===
match
---
trailer [57851,57857]
trailer [57903,57909]
===
match
---
atom_expr [57039,57062]
atom_expr [57091,57114]
===
match
---
operator: = [76940,76941]
operator: = [76992,76993]
===
match
---
atom_expr [8493,8520]
atom_expr [8493,8520]
===
match
---
suite [58124,58277]
suite [58176,58329]
===
match
---
string: """         Returns the DagRun for this TaskInstance          :param session: SQLAlchemy ORM Session         :return: DagRun         """ [35135,35271]
string: """         Returns the DagRun for this TaskInstance          :param session: SQLAlchemy ORM Session         :return: DagRun         """ [35135,35271]
===
match
---
operator: , [15690,15691]
operator: , [15690,15691]
===
match
---
trailer [53818,53858]
trailer [53870,53910]
===
match
---
param [18847,18851]
param [18847,18851]
===
match
---
trailer [54384,54612]
trailer [54436,54664]
===
match
---
operator: == [5131,5133]
operator: == [5131,5133]
===
match
---
name: extend [18071,18077]
name: extend [18071,18077]
===
match
---
name: session [25011,25018]
name: session [25011,25018]
===
match
---
fstring_expr [48733,48752]
fstring_expr [48785,48804]
===
match
---
suite [44376,44744]
suite [44428,44796]
===
match
---
name: self [37513,37517]
name: self [37513,37517]
===
match
---
name: TaskFail [57116,57124]
name: TaskFail [57168,57176]
===
match
---
name: self [81279,81283]
name: self [81331,81335]
===
match
---
operator: = [5883,5884]
operator: = [5883,5884]
===
match
---
name: context [68088,68095]
name: context [68140,68147]
===
match
---
atom_expr [24233,24313]
atom_expr [24233,24313]
===
match
---
operator: = [69475,69476]
operator: = [69527,69528]
===
match
---
atom_expr [5515,5528]
atom_expr [5515,5528]
===
match
---
string: """     Simplified Task Instance.      Used to send data between processes via Queues.     """ [79646,79740]
string: """     Simplified Task Instance.      Used to send data between processes via Queues.     """ [79698,79792]
===
match
---
trailer [82428,82434]
trailer [82480,82486]
===
match
---
atom_expr [80502,80510]
atom_expr [80554,80562]
===
match
---
simple_stmt [72198,72267]
simple_stmt [72250,72319]
===
match
---
name: run_as_user [80279,80290]
name: run_as_user [80331,80342]
===
match
---
simple_stmt [51479,51523]
simple_stmt [51531,51575]
===
match
---
argument [71100,71115]
argument [71152,71167]
===
match
---
param [67953,67986]
param [68005,68038]
===
match
---
if_stmt [52544,53308]
if_stmt [52596,53360]
===
match
---
operator: , [54038,54039]
operator: , [54090,54091]
===
match
---
operator: = [31837,31838]
operator: = [31837,31838]
===
match
---
name: delete [24014,24020]
name: delete [24014,24020]
===
match
---
name: ignore_ti_state [39725,39740]
name: ignore_ti_state [39725,39740]
===
match
---
simple_stmt [37431,37448]
simple_stmt [37431,37448]
===
match
---
param [51936,51953]
param [51988,52005]
===
match
---
expr_stmt [61644,61704]
expr_stmt [61696,61756]
===
match
---
trailer [55921,55923]
trailer [55973,55975]
===
match
---
atom_expr [81121,81132]
atom_expr [81173,81184]
===
match
---
atom_expr [39003,39020]
atom_expr [39003,39020]
===
match
---
atom_expr [24276,24295]
atom_expr [24276,24295]
===
match
---
expr_stmt [11981,12000]
expr_stmt [11981,12000]
===
match
---
name: provide_session [56008,56023]
name: provide_session [56060,56075]
===
match
---
atom [3199,3201]
atom [3199,3201]
===
match
---
name: t [78891,78892]
name: t [78943,78944]
===
match
---
trailer [57042,57062]
trailer [57094,57114]
===
match
---
trailer [29788,29797]
trailer [29788,29797]
===
match
---
simple_stmt [1018,1103]
simple_stmt [1018,1103]
===
match
---
name: execution_date [15545,15559]
name: execution_date [15545,15559]
===
match
---
trailer [72736,72742]
trailer [72788,72794]
===
match
---
name: fmt [59554,59557]
name: fmt [59606,59609]
===
match
---
name: FAILED [44599,44605]
name: FAILED [44651,44657]
===
match
---
name: task_reschedule [39091,39106]
name: task_reschedule [39091,39106]
===
match
---
try_stmt [54294,54799]
try_stmt [54346,54851]
===
match
---
atom_expr [72032,72040]
atom_expr [72084,72092]
===
match
---
decorated [41559,45648]
decorated [41528,45700]
===
match
---
expr_stmt [68409,69018]
expr_stmt [68461,69070]
===
match
---
name: render [72142,72148]
name: render [72194,72200]
===
match
---
operator: } [19042,19043]
operator: } [19042,19043]
===
match
---
simple_stmt [56963,56989]
simple_stmt [57015,57041]
===
match
---
if_stmt [62348,62403]
if_stmt [62400,62455]
===
match
---
suite [67355,67419]
suite [67407,67471]
===
match
---
name: log [40630,40633]
name: log [40630,40633]
===
match
---
name: UP_FOR_RETRY [34990,35002]
name: UP_FOR_RETRY [34990,35002]
===
match
---
atom_expr [22249,22263]
atom_expr [22249,22263]
===
match
---
atom_expr [20269,20280]
atom_expr [20269,20280]
===
match
---
expr_stmt [23381,23416]
expr_stmt [23381,23416]
===
match
---
trailer [33844,33851]
trailer [33844,33851]
===
match
---
simple_stmt [80027,80065]
simple_stmt [80079,80117]
===
match
---
try_stmt [49763,50157]
try_stmt [49815,50209]
===
match
---
testlist_comp [47188,47261]
testlist_comp [47240,47313]
===
match
---
name: k [49287,49288]
name: k [49339,49340]
===
match
---
trailer [10799,10820]
trailer [10799,10820]
===
match
---
atom_expr [10061,10072]
atom_expr [10061,10072]
===
match
---
name: context [49480,49487]
name: context [49532,49539]
===
match
---
return_stmt [24226,24313]
return_stmt [24226,24313]
===
match
---
operator: = [46888,46889]
operator: = [46940,46941]
===
match
---
atom_expr [42589,42603]
atom_expr [42558,42572]
===
match
---
name: task_id [78432,78439]
name: task_id [78484,78491]
===
match
---
trailer [71173,71190]
trailer [71225,71242]
===
match
---
operator: , [30799,30800]
operator: , [30799,30800]
===
match
---
atom_expr [57131,57150]
atom_expr [57183,57202]
===
match
---
operator: = [53501,53502]
operator: = [53553,53554]
===
match
---
name: provide_session [50702,50717]
name: provide_session [50754,50769]
===
match
---
name: dag_id [8695,8701]
name: dag_id [8695,8701]
===
match
---
trailer [39982,39986]
trailer [39982,39986]
===
match
---
name: all [20431,20434]
name: all [20431,20434]
===
match
---
operator: = [20865,20866]
operator: = [20865,20866]
===
match
---
name: State [40782,40787]
name: State [40782,40787]
===
match
---
and_test [61104,61140]
and_test [61156,61192]
===
match
---
name: timezone [55285,55293]
name: timezone [55337,55345]
===
match
---
operator: = [68841,68842]
operator: = [68893,68894]
===
match
---
for_stmt [31779,32113]
for_stmt [31779,32113]
===
match
---
name: List [3183,3187]
name: List [3183,3187]
===
match
---
atom_expr [58137,58147]
atom_expr [58189,58199]
===
match
---
atom_expr [80299,80309]
atom_expr [80351,80361]
===
match
---
simple_stmt [11981,12001]
simple_stmt [11981,12001]
===
match
---
name: task [61380,61384]
name: task [61432,61436]
===
match
---
atom_expr [27288,27294]
atom_expr [27288,27294]
===
match
---
name: job_id [22456,22462]
name: job_id [22456,22462]
===
match
---
name: session [46063,46070]
name: session [46115,46122]
===
match
---
simple_stmt [78334,78356]
simple_stmt [78386,78408]
===
match
---
trailer [72853,72862]
trailer [72905,72914]
===
match
---
operator: } [62323,62324]
operator: } [62375,62376]
===
match
---
name: pickle [4386,4392]
name: pickle [4386,4392]
===
match
---
atom_expr [29598,29639]
atom_expr [29598,29639]
===
match
---
parameters [13860,13866]
parameters [13860,13866]
===
match
---
name: ignore_ti_state [15740,15755]
name: ignore_ti_state [15740,15755]
===
match
---
trailer [55892,55898]
trailer [55944,55950]
===
match
---
argument [10026,10040]
argument [10026,10040]
===
match
---
name: execution_date [23988,24002]
name: execution_date [23988,24002]
===
match
---
name: self [43480,43484]
name: self [43532,43536]
===
match
---
operator: = [52865,52866]
operator: = [52917,52918]
===
match
---
trailer [5517,5528]
trailer [5517,5528]
===
match
---
operator: = [34537,34538]
operator: = [34537,34538]
===
match
---
decorator [26366,26383]
decorator [26366,26383]
===
match
---
name: TaskInstance [82579,82591]
name: TaskInstance [82631,82643]
===
match
---
suite [5148,5259]
suite [5148,5259]
===
match
---
name: models [1887,1893]
name: models [1887,1893]
===
match
---
trailer [33610,33615]
trailer [33610,33615]
===
match
---
suite [53080,53308]
suite [53132,53360]
===
match
---
name: extend [18143,18149]
name: extend [18143,18149]
===
match
---
name: e [44685,44686]
name: e [44737,44738]
===
match
---
simple_stmt [53777,53800]
simple_stmt [53829,53852]
===
match
---
name: _task_id [79835,79843]
name: _task_id [79887,79895]
===
match
---
name: TaskInstance [82042,82054]
name: TaskInstance [82094,82106]
===
match
---
expr_stmt [7149,7201]
expr_stmt [7149,7201]
===
match
---
name: strftime [60690,60698]
name: strftime [60742,60750]
===
match
---
simple_stmt [42957,42995]
simple_stmt [43009,43047]
===
match
---
operator: , [28389,28390]
operator: , [28389,28390]
===
match
---
atom_expr [71535,71748]
atom_expr [71587,71800]
===
match
---
operator: } [19342,19343]
operator: } [19342,19343]
===
match
---
name: ti [20162,20164]
name: ti [20162,20164]
===
match
---
name: task [58687,58691]
name: task [58739,58743]
===
match
---
atom_expr [7419,7433]
atom_expr [7419,7433]
===
match
---
atom_expr [13241,13257]
atom_expr [13241,13257]
===
match
---
name: get [63177,63180]
name: get [63229,63232]
===
match
---
name: session [2719,2726]
name: session [2719,2726]
===
match
---
name: executor_config [23468,23483]
name: executor_config [23468,23483]
===
match
---
simple_stmt [2171,2205]
simple_stmt [2171,2205]
===
match
---
operator: , [74721,74722]
operator: , [74773,74774]
===
match
---
operator: = [21828,21829]
operator: = [21828,21829]
===
match
---
name: Exception [3908,3917]
name: Exception [3908,3917]
===
match
---
name: task_id [23923,23930]
name: task_id [23923,23930]
===
match
---
name: self [82207,82211]
name: self [82259,82263]
===
match
---
name: error_file [44298,44308]
name: error_file [44350,44360]
===
match
---
name: force_fail [44281,44291]
name: force_fail [44333,44343]
===
match
---
string: "Received SIGTERM. Terminating subprocesses." [48386,48431]
string: "Received SIGTERM. Terminating subprocesses." [48438,48483]
===
match
---
operator: , [58386,58387]
operator: , [58438,58439]
===
match
---
name: or_ [79246,79249]
name: or_ [79298,79301]
===
match
---
trailer [42646,42672]
trailer [42615,42641]
===
match
---
trailer [72590,72601]
trailer [72642,72653]
===
match
---
name: html_content [72198,72210]
name: html_content [72250,72262]
===
match
---
operator: , [65774,65775]
operator: , [65826,65827]
===
match
---
name: Integer [10006,10013]
name: Integer [10006,10013]
===
match
---
simple_stmt [58181,58227]
simple_stmt [58233,58279]
===
match
---
name: replace [61615,61622]
name: replace [61667,61674]
===
match
---
name: str [4250,4253]
name: str [4250,4253]
===
match
---
operator: , [53462,53463]
operator: , [53514,53515]
===
match
---
name: quote [19464,19469]
name: quote [19464,19469]
===
match
---
name: try_number [24302,24312]
name: try_number [24302,24312]
===
match
---
atom_expr [14906,14917]
atom_expr [14906,14917]
===
match
---
operator: = [30944,30945]
operator: = [30944,30945]
===
match
---
operator: , [3832,3833]
operator: , [3832,3833]
===
match
---
trailer [55005,55007]
trailer [55057,55059]
===
match
---
trailer [63947,63951]
trailer [63999,64003]
===
match
---
operator: } [70560,70561]
operator: } [70612,70613]
===
match
---
expr_stmt [11869,11925]
expr_stmt [11869,11925]
===
match
---
trailer [42685,42701]
trailer [42654,42670]
===
match
---
string: 'priority_weight' [80400,80417]
string: 'priority_weight' [80452,80469]
===
match
---
operator: = [5200,5201]
operator: = [5200,5201]
===
match
---
string: """         Get the very latest state from the database, if a session is passed,         we use and looking up the state becomes part of the session, otherwise         a new session is used.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [19872,20153]
string: """         Get the very latest state from the database, if a session is passed,         we use and looking up the state becomes part of the session, otherwise         a new session is used.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [19872,20153]
===
match
---
if_stmt [78160,78196]
if_stmt [78212,78248]
===
match
---
name: timeout [2872,2879]
name: timeout [2872,2879]
===
match
---
name: state [12078,12083]
name: state [12078,12083]
===
match
---
arglist [3694,3833]
arglist [3694,3833]
===
match
---
name: state [24726,24731]
name: state [24726,24731]
===
match
---
decorated [74411,77366]
decorated [74463,77418]
===
match
---
and_test [30229,30301]
and_test [30229,30301]
===
match
---
name: self [8242,8246]
name: self [8242,8246]
===
match
---
name: handle_failure [59218,59232]
name: handle_failure [59270,59284]
===
match
---
argument [42653,42671]
argument [42622,42640]
===
match
---
string: "Immediate failure requested. Marking task as FAILED." [57930,57984]
string: "Immediate failure requested. Marking task as FAILED." [57982,58036]
===
match
---
name: _safe_date [58605,58615]
name: _safe_date [58657,58667]
===
match
---
simple_stmt [81039,81063]
simple_stmt [81091,81115]
===
match
---
name: html_content_err [72395,72411]
name: html_content_err [72447,72463]
===
match
---
expr_stmt [22317,22346]
expr_stmt [22317,22346]
===
match
---
operator: , [80226,80227]
operator: , [80278,80279]
===
match
---
name: raw [18613,18616]
name: raw [18613,18616]
===
match
---
atom_expr [9428,9460]
atom_expr [9428,9460]
===
match
---
string: 'Log file: {{ti.log_filepath}}<br>' [69977,70012]
string: 'Log file: {{ti.log_filepath}}<br>' [70029,70064]
===
match
---
expr_stmt [12531,12553]
expr_stmt [12531,12553]
===
match
---
atom [44759,44789]
atom [44811,44841]
===
match
---
operator: , [26449,26450]
operator: , [26449,26450]
===
match
---
trailer [40817,40824]
trailer [42777,42784]
===
match
---
trailer [53280,53298]
trailer [53332,53350]
===
match
---
operator: = [71110,71111]
operator: = [71162,71163]
===
match
---
atom_expr [58687,58697]
atom_expr [58739,58749]
===
match
---
atom_expr [39495,39771]
atom_expr [39495,39771]
===
match
---
operator: = [61605,61606]
operator: = [61657,61658]
===
match
---
name: filter [35409,35415]
name: filter [35409,35415]
===
match
---
name: __init__ [11125,11133]
name: __init__ [11125,11133]
===
match
---
trailer [32581,32585]
trailer [32581,32585]
===
match
---
simple_stmt [28211,28459]
simple_stmt [28211,28459]
===
match
---
trailer [7718,7753]
trailer [7718,7753]
===
match
---
name: tis [7748,7751]
name: tis [7748,7751]
===
match
---
name: from_obj [68781,68789]
name: from_obj [68833,68841]
===
match
---
name: value [74222,74227]
name: value [74274,74279]
===
match
---
atom_expr [56931,56945]
atom_expr [56983,56997]
===
match
---
operator: = [15230,15231]
operator: = [15230,15231]
===
match
---
atom_expr [6046,6059]
atom_expr [6046,6059]
===
match
---
name: self [74505,74509]
name: self [74557,74561]
===
match
---
arglist [39817,39871]
arglist [39817,39871]
===
match
---
name: job_id [54169,54175]
name: job_id [54221,54227]
===
match
---
trailer [51672,51689]
trailer [51724,51741]
===
match
---
operator: = [48219,48220]
operator: = [48271,48272]
===
match
---
simple_stmt [7210,7238]
simple_stmt [7210,7238]
===
match
---
name: self [62876,62880]
name: self [62928,62932]
===
match
---
name: models [45882,45888]
name: models [45934,45940]
===
match
---
operator: == [79356,79358]
operator: == [79408,79410]
===
match
---
trailer [47552,47556]
trailer [47604,47608]
===
match
---
simple_stmt [60513,60530]
simple_stmt [60565,60582]
===
match
---
expr_stmt [80165,80204]
expr_stmt [80217,80256]
===
match
---
name: task [27229,27233]
name: task [27229,27233]
===
match
---
simple_stmt [8329,8414]
simple_stmt [8329,8414]
===
match
---
and_test [14573,14594]
and_test [14573,14594]
===
match
---
simple_stmt [978,1018]
simple_stmt [978,1018]
===
match
---
expr_stmt [53808,54245]
expr_stmt [53860,54297]
===
match
---
name: merge [5982,5987]
name: merge [5982,5987]
===
match
---
name: try_number [40191,40201]
name: try_number [40191,40201]
===
match
---
simple_stmt [18520,18544]
simple_stmt [18520,18544]
===
match
---
trailer [9824,9833]
trailer [9824,9833]
===
match
---
name: self [59315,59319]
name: self [59367,59371]
===
match
---
simple_stmt [61714,61729]
simple_stmt [61766,61781]
===
match
---
atom_expr [72988,73001]
atom_expr [73040,73053]
===
match
---
atom_expr [6823,6847]
atom_expr [6823,6847]
===
match
---
annassign [79890,79920]
annassign [79942,79972]
===
match
---
name: DateTime [29206,29214]
name: DateTime [29206,29214]
===
match
---
name: test_mode [40700,40709]
name: test_mode [40700,40709]
===
match
---
trailer [58261,58276]
trailer [58313,58328]
===
match
---
trailer [12069,12075]
trailer [12069,12075]
===
match
---
dictorsetmaker [44578,44605]
dictorsetmaker [44630,44657]
===
match
---
name: self [72929,72933]
name: self [72981,72985]
===
match
---
suite [12631,13176]
suite [12631,13176]
===
match
---
operator: , [46754,46755]
operator: , [46806,46807]
===
match
---
name: staticmethod [77956,77968]
name: staticmethod [78008,78020]
===
match
---
atom_expr [47104,47133]
atom_expr [47156,47185]
===
match
---
trailer [67807,67880]
trailer [67859,67932]
===
match
---
name: dag [61303,61306]
name: dag [61355,61358]
===
match
---
name: rendered_value [66407,66421]
name: rendered_value [66459,66473]
===
match
---
argument [70870,70900]
argument [70922,70952]
===
match
---
name: running [13095,13102]
name: running [13095,13102]
===
match
---
name: str [8017,8020]
name: str [8017,8020]
===
match
---
atom_expr [29716,29729]
atom_expr [29716,29729]
===
match
---
operator: == [26180,26182]
operator: == [26180,26182]
===
match
---
name: mark_success_url [19389,19405]
name: mark_success_url [19389,19405]
===
match
---
trailer [6605,6612]
trailer [6605,6612]
===
match
---
name: execution_date [20388,20402]
name: execution_date [20388,20402]
===
match
---
arith_expr [71664,71683]
arith_expr [71716,71735]
===
match
---
name: error [4398,4403]
name: error [4398,4403]
===
match
---
name: KubeConfig [68388,68398]
name: KubeConfig [68440,68450]
===
match
---
name: RUNNING [40745,40752]
name: RUNNING [40745,40752]
===
match
---
name: self [76420,76424]
name: self [76472,76476]
===
match
---
name: ignore_depends_on_past [35742,35764]
name: ignore_depends_on_past [35742,35764]
===
match
---
name: external_trigger [61124,61140]
name: external_trigger [61176,61192]
===
match
---
suite [3566,3848]
suite [3566,3848]
===
match
---
name: state [24838,24843]
name: state [24838,24843]
===
match
---
trailer [48561,48569]
trailer [48613,48621]
===
match
---
name: args [68707,68711]
name: args [68759,68763]
===
match
---
name: pool [22480,22484]
name: pool [22480,22484]
===
match
---
name: RenderedTaskInstanceFields [48829,48855]
name: RenderedTaskInstanceFields [48881,48907]
===
match
---
decorated [53313,54799]
decorated [53365,54851]
===
match
---
import_as_names [958,977]
import_as_names [958,977]
===
match
---
name: provide_session [32251,32266]
name: provide_session [32251,32266]
===
match
---
operator: , [7096,7097]
operator: , [7096,7097]
===
match
---
name: State [20867,20872]
name: State [20867,20872]
===
match
---
name: Optional [74589,74597]
name: Optional [74641,74649]
===
match
---
name: task [42647,42651]
name: task [42616,42620]
===
match
---
name: self [49185,49189]
name: self [49237,49241]
===
match
---
param [59100,59133]
param [59152,59185]
===
match
---
name: items [49328,49333]
name: items [49380,49385]
===
match
---
trailer [71797,71814]
trailer [71849,71866]
===
match
---
arglist [48981,49006]
arglist [49033,49058]
===
match
---
name: TR [6603,6605]
name: TR [6603,6605]
===
match
---
atom_expr [63055,63063]
atom_expr [63107,63115]
===
match
---
fstring [48708,48762]
fstring [48760,48814]
===
match
---
name: self [46635,46639]
name: self [46687,46691]
===
match
---
name: task_id [77062,77069]
name: task_id [77114,77121]
===
match
---
trailer [64077,64081]
trailer [64129,64133]
===
match
---
string: """         Pull XComs that optionally meet certain criteria.          The default value for `key` limits the search to XComs         that were returned by other tasks (as opposed to those that were pushed         manually). To remove this filter, pass key=None (or any desired value).          If a single task_id string is provided, the result is the value of the         most recent matching XCom from that task_id. If multiple task_ids are         provided, a tuple of matching values is returned. None is returned         whenever no matches are found.          :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. The default key is 'return_value', also             available as a constant XCOM_RETURN_KEY. This key is automatically             given to XComs returned by tasks (as opposed to being pushed             manually). To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_id: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: Sqlalchemy ORM Session         :type session: Session         """ [74745,76371]
string: """         Pull XComs that optionally meet certain criteria.          The default value for `key` limits the search to XComs         that were returned by other tasks (as opposed to those that were pushed         manually). To remove this filter, pass key=None (or any desired value).          If a single task_id string is provided, the result is the value of the         most recent matching XCom from that task_id. If multiple task_ids are         provided, a tuple of matching values is returned. None is returned         whenever no matches are found.          :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. The default key is 'return_value', also             available as a constant XCOM_RETURN_KEY. This key is automatically             given to XComs returned by tasks (as opposed to being pushed             manually). To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_id: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: Sqlalchemy ORM Session         :type session: Session         """ [74797,76423]
===
match
---
operator: , [68507,68508]
operator: , [68559,68560]
===
match
---
return_stmt [8208,8261]
return_stmt [8208,8261]
===
match
---
param [35673,35694]
param [35673,35694]
===
match
---
simple_stmt [48258,48280]
simple_stmt [48310,48332]
===
match
---
suite [18372,18426]
suite [18372,18426]
===
match
---
operator: , [74688,74689]
operator: , [74740,74741]
===
match
---
simple_stmt [41498,41536]
simple_stmt [41467,41505]
===
match
---
atom_expr [37661,37675]
atom_expr [37661,37675]
===
match
---
trailer [41518,41535]
trailer [41487,41504]
===
match
---
string: "--ignore-all-dependencies" [18229,18256]
string: "--ignore-all-dependencies" [18229,18256]
===
match
---
fstring_string: /log?execution_date= [19295,19315]
fstring_string: /log?execution_date= [19295,19315]
===
match
---
simple_stmt [20916,20933]
simple_stmt [20916,20933]
===
match
---
arglist [45085,45390]
arglist [45137,45442]
===
match
---
string: '<br>' [69506,69512]
string: '<br>' [69558,69564]
===
match
---
simple_stmt [54642,54717]
simple_stmt [54694,54769]
===
match
---
operator: , [54155,54156]
operator: , [54207,54208]
===
match
---
name: num [47488,47491]
name: num [47540,47543]
===
match
---
name: kube_image [68622,68632]
name: kube_image [68674,68684]
===
match
---
name: read [4011,4015]
name: read [4011,4015]
===
match
---
operator: = [3122,3123]
operator: = [3122,3123]
===
match
---
trailer [11447,11463]
trailer [11447,11463]
===
match
---
trailer [11148,11155]
trailer [11148,11155]
===
match
---
funcdef [55062,56002]
funcdef [55114,56054]
===
match
---
simple_stmt [26803,26841]
simple_stmt [26803,26841]
===
match
---
name: downstream_task_ids [46645,46664]
name: downstream_task_ids [46697,46716]
===
match
---
not_test [25904,25932]
not_test [25904,25932]
===
match
---
atom_expr [57027,57063]
atom_expr [57079,57115]
===
match
---
atom_expr [23893,23904]
atom_expr [23893,23904]
===
match
---
name: Variable [64405,64413]
name: Variable [64457,64465]
===
match
---
param [77433,77440]
param [77485,77492]
===
match
---
expr_stmt [25875,25891]
expr_stmt [25875,25891]
===
match
---
string: "Current context is not equal to the state at context stack. Expected=%s, got=%s" [3694,3775]
string: "Current context is not equal to the state at context stack. Expected=%s, got=%s" [3694,3775]
===
match
---
atom_expr [8458,8470]
atom_expr [8458,8470]
===
match
---
simple_stmt [18466,18490]
simple_stmt [18466,18490]
===
match
---
trailer [44954,44962]
trailer [45006,45014]
===
match
---
name: ignore_depends_on_past [53472,53494]
name: ignore_depends_on_past [53524,53546]
===
match
---
arglist [28758,28968]
arglist [28758,28968]
===
match
---
trailer [21445,21449]
trailer [21445,21449]
===
match
---
or_test [74328,74365]
or_test [74380,74417]
===
match
---
arglist [46635,46805]
arglist [46687,46857]
===
match
---
name: cmd [18217,18220]
name: cmd [18217,18220]
===
match
---
annassign [3181,3201]
annassign [3181,3201]
===
match
---
name: RenderedTaskInstanceFields [48173,48199]
name: RenderedTaskInstanceFields [48225,48251]
===
match
---
name: BooleanClauseList [78059,78076]
name: BooleanClauseList [78111,78128]
===
match
---
name: exc_info [50120,50128]
name: exc_info [50172,50180]
===
match
---
operator: , [1867,1868]
operator: , [1867,1868]
===
match
---
simple_stmt [67598,67623]
simple_stmt [67650,67675]
===
match
---
name: _CURRENT_CONTEXT [3592,3608]
name: _CURRENT_CONTEXT [3592,3608]
===
match
---
operator: , [1668,1669]
operator: , [1668,1669]
===
match
---
argument [68748,68811]
argument [68800,68863]
===
match
---
operator: , [58411,58412]
operator: , [58463,58464]
===
match
---
operator: , [10598,10599]
operator: , [10598,10599]
===
match
---
trailer [60689,60698]
trailer [60741,60750]
===
match
---
string: '-' [62127,62130]
string: '-' [62179,62182]
===
match
---
simple_stmt [69460,69514]
simple_stmt [69512,69566]
===
match
---
name: execution_date [11053,11067]
name: execution_date [11053,11067]
===
match
---
name: end_date [45021,45029]
name: end_date [45073,45081]
===
match
---
arglist [35416,35490]
arglist [35416,35490]
===
match
---
atom_expr [8500,8515]
atom_expr [8500,8515]
===
match
---
string: "Task successfully registered in smart sensor." [51057,51104]
string: "Task successfully registered in smart sensor." [51109,51156]
===
match
---
sync_comp_for [47191,47261]
sync_comp_for [47243,47313]
===
match
---
atom [46980,47151]
atom [47032,47203]
===
match
---
trailer [24646,24650]
trailer [24646,24650]
===
match
---
return_stmt [80703,80723]
return_stmt [80755,80775]
===
match
---
simple_stmt [62161,62213]
simple_stmt [62213,62265]
===
match
---
atom_expr [14527,14540]
atom_expr [14527,14540]
===
match
---
name: reason [32091,32097]
name: reason [32091,32097]
===
match
---
operator: = [56210,56211]
operator: = [56262,56263]
===
match
---
name: Variable [63939,63947]
name: Variable [63991,63999]
===
match
---
name: context [49575,49582]
name: context [49627,49634]
===
match
---
atom [19582,19791]
atom [19582,19791]
===
match
---
string: """Setting Next Try Number""" [13876,13905]
string: """Setting Next Try Number""" [13876,13905]
===
match
---
atom_expr [51768,51790]
atom_expr [51820,51842]
===
match
---
expr_stmt [49093,49172]
expr_stmt [49145,49224]
===
match
---
operator: , [15318,15319]
operator: , [15318,15319]
===
match
---
name: self [11041,11045]
name: self [11041,11045]
===
match
---
operator: , [32793,32794]
operator: , [32793,32794]
===
match
---
trailer [3896,3919]
trailer [3896,3919]
===
match
---
name: dr [27728,27730]
name: dr [27728,27730]
===
match
---
name: self [54953,54957]
name: self [55005,55009]
===
match
---
name: get_many [76454,76462]
name: get_many [76506,76514]
===
match
---
operator: -> [74729,74731]
operator: -> [74781,74783]
===
match
---
atom_expr [28211,28458]
atom_expr [28211,28458]
===
match
---
name: ti [5889,5891]
name: ti [5889,5891]
===
match
---
name: property [80584,80592]
name: property [80636,80644]
===
match
---
name: String [10341,10347]
name: String [10341,10347]
===
match
---
comparison [23878,23904]
comparison [23878,23904]
===
match
---
name: item [63886,63890]
name: item [63938,63942]
===
match
---
atom_expr [44665,44721]
atom_expr [44717,44773]
===
match
---
trailer [55498,55510]
trailer [55550,55562]
===
match
---
name: vals_kv [76932,76939]
name: vals_kv [76984,76991]
===
match
---
name: self [41377,41381]
name: self [41346,41350]
===
match
---
name: html_content_err [72279,72295]
name: html_content_err [72331,72347]
===
match
---
atom_expr [35980,35993]
atom_expr [35980,35993]
===
match
---
atom_expr [60126,60141]
atom_expr [60178,60193]
===
match
---
argument [48800,48815]
argument [48852,48867]
===
match
---
name: session [45543,45550]
name: session [45595,45602]
===
match
---
name: UP_FOR_RESCHEDULE [39056,39073]
name: UP_FOR_RESCHEDULE [39056,39073]
===
match
---
trailer [18960,18965]
trailer [18960,18965]
===
match
---
trailer [47824,47828]
trailer [47876,47880]
===
match
---
parameters [79758,79782]
parameters [79810,79834]
===
match
---
trailer [41448,41460]
trailer [41417,41429]
===
match
---
trailer [61123,61140]
trailer [61175,61192]
===
match
---
name: self [59537,59541]
name: self [59589,59593]
===
match
---
atom_expr [63295,63334]
atom_expr [63347,63386]
===
match
---
name: str [41769,41772]
name: str [41738,41741]
===
match
---
trailer [78878,78886]
trailer [78930,78938]
===
match
---
if_stmt [6082,7238]
if_stmt [6082,7238]
===
match
---
trailer [70734,70979]
trailer [70786,71031]
===
match
---
simple_stmt [820,835]
simple_stmt [820,835]
===
match
---
name: total_seconds [51441,51454]
name: total_seconds [51493,51506]
===
match
---
trailer [10743,10784]
trailer [10743,10784]
===
match
---
name: datetime [79996,80004]
name: datetime [80048,80056]
===
match
---
name: utils [2603,2608]
name: utils [2603,2608]
===
match
---
name: self [37456,37460]
name: self [37456,37460]
===
match
---
operator: , [74547,74548]
operator: , [74599,74600]
===
match
---
name: _date_or_empty [43856,43870]
name: _date_or_empty [43908,43922]
===
match
---
name: Optional [53710,53718]
name: Optional [53762,53770]
===
match
---
name: self [58286,58290]
name: self [58338,58342]
===
match
---
operator: ** [71293,71295]
operator: ** [71345,71347]
===
match
---
name: state [10651,10656]
name: state [10651,10656]
===
match
---
trailer [40391,40397]
trailer [40391,40397]
===
match
---
simple_stmt [19169,19214]
simple_stmt [19169,19214]
===
match
---
import_name [885,900]
import_name [885,900]
===
match
---
name: prev_ds_nodash [65033,65047]
name: prev_ds_nodash [65085,65099]
===
match
---
trailer [47113,47133]
trailer [47165,47185]
===
match
---
name: property [13828,13836]
name: property [13828,13836]
===
match
---
raise_stmt [67501,67589]
raise_stmt [67553,67641]
===
match
---
name: dag_id [74281,74287]
name: dag_id [74333,74339]
===
match
---
trailer [79110,79125]
trailer [79162,79177]
===
match
---
name: utils [2828,2833]
name: utils [2828,2833]
===
match
---
trailer [43157,43165]
trailer [43209,43217]
===
match
---
operator: = [29518,29519]
operator: = [29518,29519]
===
match
---
string: """Render templates in the operator fields.""" [68005,68051]
string: """Render templates in the operator fields.""" [68057,68103]
===
match
---
simple_stmt [18139,18177]
simple_stmt [18139,18177]
===
match
---
arglist [14906,15400]
arglist [14906,15400]
===
match
---
name: timedelta [968,977]
name: timedelta [968,977]
===
match
---
name: self [80432,80436]
name: self [80484,80488]
===
match
---
name: utcnow [39012,39018]
name: utcnow [39012,39018]
===
match
---
name: commit [20924,20930]
name: commit [20924,20930]
===
match
---
tfpdef [74698,74714]
tfpdef [74750,74766]
===
match
---
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [45125,45195]
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [45177,45247]
===
match
---
name: RUNNING_DEPS [2352,2364]
name: RUNNING_DEPS [2352,2364]
===
match
---
decorated [80729,80817]
decorated [80781,80869]
===
match
---
return_stmt [80878,80901]
return_stmt [80930,80953]
===
match
---
name: session [77561,77568]
name: session [77613,77620]
===
match
---
param [81017,81021]
param [81069,81073]
===
match
---
name: execution_date [6698,6712]
name: execution_date [6698,6712]
===
match
---
dotted_name [60160,60181]
dotted_name [60212,60233]
===
match
---
funcdef [45700,48008]
funcdef [45752,48060]
===
match
---
expr_stmt [31630,31671]
expr_stmt [31630,31671]
===
match
---
fstring_string:   [32978,32979]
fstring_string:   [32978,32979]
===
match
---
atom_expr [68542,68553]
atom_expr [68594,68605]
===
match
---
param [74619,74646]
param [74671,74698]
===
match
---
argument [44298,44319]
argument [44350,44371]
===
match
---
trailer [78011,78044]
trailer [78063,78096]
===
match
---
atom_expr [11935,11954]
atom_expr [11935,11954]
===
match
---
name: self [46585,46589]
name: self [46637,46641]
===
match
---
name: queue [80505,80510]
name: queue [80557,80562]
===
match
---
trailer [24883,24892]
trailer [24883,24892]
===
match
---
name: state [22048,22053]
name: state [22048,22053]
===
match
---
trailer [67774,67779]
trailer [67826,67831]
===
match
---
simple_stmt [7870,7904]
simple_stmt [7870,7904]
===
match
---
name: execution_date [79906,79920]
name: execution_date [79958,79972]
===
match
---
atom_expr [46585,46823]
atom_expr [46637,46875]
===
match
---
name: self [24801,24805]
name: self [24801,24805]
===
match
---
name: on_retry_callback [53281,53298]
name: on_retry_callback [53333,53350]
===
match
---
name: task_id [78879,78886]
name: task_id [78931,78938]
===
match
---
name: exc_info [47940,47948]
name: exc_info [47992,48000]
===
match
---
if_stmt [34667,34759]
if_stmt [34667,34759]
===
match
---
expr_stmt [24740,24789]
expr_stmt [24740,24789]
===
match
---
name: ds_nodash [61990,61999]
name: ds_nodash [62042,62051]
===
match
---
fstring_end: " [19082,19083]
fstring_end: " [19082,19083]
===
match
---
number: 1 [8518,8519]
number: 1 [8518,8519]
===
match
---
subscriptlist [3154,3162]
subscriptlist [3154,3162]
===
match
---
operator: = [9388,9389]
operator: = [9388,9389]
===
match
---
dictorsetmaker [7650,7673]
dictorsetmaker [7650,7673]
===
match
---
atom_expr [25882,25891]
atom_expr [25882,25891]
===
match
---
simple_stmt [53808,54246]
simple_stmt [53860,54298]
===
match
---
operator: , [23946,23947]
operator: , [23946,23947]
===
match
---
trailer [64687,64702]
trailer [64739,64754]
===
match
---
operator: = [41699,41700]
operator: = [41668,41669]
===
match
---
trailer [40584,40595]
trailer [40584,40595]
===
match
---
name: content [72022,72029]
name: content [72074,72081]
===
match
---
name: airflow [2595,2602]
name: airflow [2595,2602]
===
match
---
suite [59392,59517]
suite [59444,59569]
===
match
---
operator: { [32964,32965]
operator: { [32964,32965]
===
match
---
atom_expr [22487,22494]
atom_expr [22487,22494]
===
match
---
trailer [68167,68176]
trailer [68219,68228]
===
match
---
trailer [18523,18530]
trailer [18523,18530]
===
match
---
trailer [41054,41061]
trailer [41023,41030]
===
match
---
simple_stmt [54831,54871]
simple_stmt [54883,54923]
===
match
---
name: self [47548,47552]
name: self [47600,47604]
===
match
---
suite [24386,25031]
suite [24386,25031]
===
match
---
name: _execute_task [50448,50461]
name: _execute_task [50500,50513]
===
match
---
operator: -> [53760,53762]
operator: -> [53812,53814]
===
match
---
trailer [24899,24908]
trailer [24899,24908]
===
match
---
trailer [22560,22566]
trailer [22560,22566]
===
match
---
name: enrich_errors [41588,41601]
name: enrich_errors [41557,41570]
===
match
---
if_stmt [82446,82678]
if_stmt [82498,82730]
===
match
---
name: ti [47195,47197]
name: ti [47247,47249]
===
match
---
operator: , [33886,33887]
operator: , [33886,33887]
===
match
---
name: __table_args__ [10506,10520]
name: __table_args__ [10506,10520]
===
match
---
trailer [18758,18765]
trailer [18758,18765]
===
match
---
string: 'Airflow alert: {{ti}}' [69541,69564]
string: 'Airflow alert: {{ti}}' [69593,69616]
===
match
---
name: retry_exponential_backoff [33299,33324]
name: retry_exponential_backoff [33299,33324]
===
match
---
name: task_id [48986,48993]
name: task_id [49038,49045]
===
match
---
string: """         Checks on whether the task instance is in the right state and timeframe         to be retried.         """ [34836,34954]
string: """         Checks on whether the task instance is in the right state and timeframe         to be retried.         """ [34836,34954]
===
match
---
suite [11675,11769]
suite [11675,11769]
===
match
---
simple_stmt [67235,67305]
simple_stmt [67287,67357]
===
match
---
param [28048,28052]
param [28048,28052]
===
match
---
name: get [63948,63951]
name: get [64000,64003]
===
match
---
name: defaultdict [5073,5084]
name: defaultdict [5073,5084]
===
match
---
simple_stmt [12640,12897]
simple_stmt [12640,12897]
===
match
---
name: result [51869,51875]
name: result [51921,51927]
===
match
---
expr_stmt [78410,78439]
expr_stmt [78462,78491]
===
match
---
trailer [51056,51105]
trailer [51108,51157]
===
match
---
name: self [50303,50307]
name: self [50355,50359]
===
match
---
name: Dict [1046,1050]
name: Dict [1046,1050]
===
match
---
name: is_container [2477,2489]
name: is_container [2477,2489]
===
match
---
param [35742,35779]
param [35742,35779]
===
match
---
name: ignore_depends_on_past [53946,53968]
name: ignore_depends_on_past [53998,54020]
===
match
---
atom_expr [43152,43165]
atom_expr [43204,43217]
===
match
---
operator: , [2350,2351]
operator: , [2350,2351]
===
match
---
name: NamedTuple [1068,1078]
name: NamedTuple [1068,1078]
===
match
---
name: dag_id [11149,11155]
name: dag_id [11149,11155]
===
match
---
argument [70922,70946]
argument [70974,70998]
===
match
---
string: 'run_id' [65431,65439]
string: 'run_id' [65483,65491]
===
match
---
operator: = [76623,76624]
operator: = [76675,76676]
===
match
---
name: exception [70788,70797]
name: exception [70840,70849]
===
match
---
string: 'TaskInstance' [28558,28572]
string: 'TaskInstance' [28558,28572]
===
match
---
fstring [19032,19083]
fstring [19032,19083]
===
match
---
operator: = [63461,63462]
operator: = [63513,63514]
===
match
---
trailer [48385,48432]
trailer [48437,48484]
===
match
---
operator: @ [81454,81455]
operator: @ [81506,81507]
===
match
---
atom_expr [40223,40237]
atom_expr [40223,40237]
===
match
---
name: self [24354,24358]
name: self [24354,24358]
===
match
---
dotted_name [41581,41601]
dotted_name [41550,41570]
===
match
---
tfpdef [53666,53687]
tfpdef [53718,53739]
===
match
---
trailer [23490,23506]
trailer [23490,23506]
===
match
---
atom_expr [76960,76974]
atom_expr [77012,77026]
===
match
---
name: replace [61891,61898]
name: replace [61943,61950]
===
match
---
operator: = [39153,39154]
operator: = [39153,39154]
===
match
---
operator: , [55089,55090]
operator: , [55141,55142]
===
match
---
name: pool [81156,81160]
name: pool [81208,81212]
===
match
---
name: lazy_object_proxy [1168,1185]
name: lazy_object_proxy [1168,1185]
===
match
---
trailer [8449,8456]
trailer [8449,8456]
===
match
---
if_stmt [17973,18033]
if_stmt [17973,18033]
===
match
---
name: merge [40386,40391]
name: merge [40386,40391]
===
match
---
trailer [24762,24773]
trailer [24762,24773]
===
match
---
trailer [26019,26026]
trailer [26019,26026]
===
match
---
name: pickle [4604,4610]
name: pickle [4604,4610]
===
match
---
trailer [70756,70965]
trailer [70808,71017]
===
match
---
trailer [78738,78929]
trailer [78790,78981]
===
match
---
name: dep_status [32776,32786]
name: dep_status [32776,32786]
===
match
---
argument [71041,71098]
argument [71093,71150]
===
match
---
expr_stmt [21963,21990]
expr_stmt [21963,21990]
===
match
---
trailer [50679,50695]
trailer [50731,50747]
===
match
---
not_test [57802,57833]
not_test [57854,57885]
===
match
---
operator: @ [13271,13272]
operator: @ [13271,13272]
===
match
---
name: dict [68224,68228]
name: dict [68276,68280]
===
match
---
param [4237,4265]
param [4237,4265]
===
match
---
name: task_id [6826,6833]
name: task_id [6826,6833]
===
match
---
name: hr_line_break [39947,39960]
name: hr_line_break [39947,39960]
===
match
---
trailer [62203,62212]
trailer [62255,62264]
===
match
---
string: " Continue to run task in non smart sensor mode." [50045,50094]
string: " Continue to run task in non smart sensor mode." [50097,50146]
===
match
---
suite [80869,80902]
suite [80921,80954]
===
match
---
operator: , [1694,1695]
operator: , [1694,1695]
===
match
---
atom_expr [43011,43071]
atom_expr [43063,43123]
===
match
---
fstring_expr [19329,19343]
fstring_expr [19329,19343]
===
match
---
trailer [80278,80290]
trailer [80330,80342]
===
match
---
atom [17915,17964]
atom [17915,17964]
===
match
---
name: Column [10209,10215]
name: Column [10209,10215]
===
match
---
operator: = [37576,37577]
operator: = [37576,37577]
===
match
---
name: check_and_change_state_before_execution [53819,53858]
name: check_and_change_state_before_execution [53871,53910]
===
match
---
name: Context [3188,3195]
name: Context [3188,3195]
===
match
---
name: dr [35539,35541]
name: dr [35539,35541]
===
match
---
atom_expr [9892,9904]
atom_expr [9892,9904]
===
match
---
name: task [53000,53004]
name: task [53052,53056]
===
match
---
operator: = [68413,68414]
operator: = [68465,68466]
===
match
---
simple_stmt [66574,66598]
simple_stmt [66626,66650]
===
match
---
name: self [41265,41269]
name: self [41234,41238]
===
match
---
atom_expr [63124,63132]
atom_expr [63176,63184]
===
match
---
name: log [30033,30036]
name: log [30033,30036]
===
match
---
atom_expr [35446,35467]
atom_expr [35446,35467]
===
match
---
string: "Starting attempt %s of %s" [40551,40578]
string: "Starting attempt %s of %s" [40551,40578]
===
match
---
name: error [52750,52755]
name: error [52802,52807]
===
match
---
simple_stmt [31908,32113]
simple_stmt [31908,32113]
===
match
---
trailer [66309,66330]
trailer [66361,66382]
===
match
---
trailer [50933,50939]
trailer [50985,50991]
===
match
---
operator: , [34554,34555]
operator: , [34554,34555]
===
match
---
suite [41136,41231]
suite [41105,41200]
===
match
---
name: airflow [1620,1627]
name: airflow [1620,1627]
===
match
---
operator: , [47953,47954]
operator: , [48005,48006]
===
match
---
atom_expr [41210,41229]
atom_expr [41179,41198]
===
match
---
param [29117,29145]
param [29117,29145]
===
match
---
comp_op [27593,27599]
comp_op [27593,27599]
===
match
---
funcdef [12610,13176]
funcdef [12610,13176]
===
match
---
trailer [29623,29638]
trailer [29623,29638]
===
match
---
atom_expr [12065,12075]
atom_expr [12065,12075]
===
match
---
simple_stmt [73975,74170]
simple_stmt [74027,74222]
===
match
---
name: self [68712,68716]
name: self [68764,68768]
===
match
---
atom_expr [46841,46852]
atom_expr [46893,46904]
===
match
---
comparison [78756,78785]
comparison [78808,78837]
===
match
---
return_stmt [80961,80982]
return_stmt [81013,81034]
===
match
---
trailer [23851,23857]
trailer [23851,23857]
===
match
---
with_stmt [51400,51523]
with_stmt [51452,51575]
===
match
---
operator: , [72751,72752]
operator: , [72803,72804]
===
match
---
if_stmt [39033,39272]
if_stmt [39033,39272]
===
match
---
name: ti [21764,21766]
name: ti [21764,21766]
===
match
---
operator: , [38207,38208]
operator: , [38207,38208]
===
match
---
operator: = [71570,71571]
operator: = [71622,71623]
===
match
---
trailer [65358,65382]
trailer [65410,65434]
===
match
---
simple_stmt [47488,47532]
simple_stmt [47540,47584]
===
match
---
fstring_string: ti.start. [42855,42864]
fstring_string: ti.start. [42907,42916]
===
match
---
atom_expr [67893,67920]
atom_expr [67945,67972]
===
match
---
name: log_filepath [18834,18846]
name: log_filepath [18834,18846]
===
match
---
trailer [33977,33979]
trailer [33977,33979]
===
match
---
name: ignore_all_deps [53917,53932]
name: ignore_all_deps [53969,53984]
===
match
---
decorated [30307,30876]
decorated [30307,30876]
===
match
---
name: tomorrow_ds [60719,60730]
name: tomorrow_ds [60771,60782]
===
match
---
operator: , [23596,23597]
operator: , [23596,23597]
===
match
---
name: conf [71933,71937]
name: conf [71985,71989]
===
match
---
name: timezone [7886,7894]
name: timezone [7886,7894]
===
match
---
name: execution_date [10608,10622]
name: execution_date [10608,10622]
===
match
---
name: dr [27826,27828]
name: dr [27826,27828]
===
match
---
name: task [53105,53109]
name: task [53157,53161]
===
match
---
name: self [12119,12123]
name: self [12119,12123]
===
match
---
simple_stmt [49093,49173]
simple_stmt [49145,49225]
===
match
---
name: raw [15315,15318]
name: raw [15315,15318]
===
match
---
operator: , [65826,65827]
operator: , [65878,65879]
===
match
---
name: property [81069,81077]
name: property [81121,81129]
===
match
---
decorated [19371,19792]
decorated [19371,19792]
===
match
---
trailer [49139,49172]
trailer [49191,49224]
===
match
---
trailer [61950,61959]
trailer [62002,62011]
===
match
---
power [33641,33667]
power [33641,33667]
===
match
---
name: DeprecationWarning [30755,30773]
name: DeprecationWarning [30755,30773]
===
match
---
atom_expr [10235,10250]
atom_expr [10235,10250]
===
match
---
operator: , [48071,48072]
operator: , [48123,48124]
===
match
---
name: dep_context [31630,31641]
name: dep_context [31630,31641]
===
match
---
name: self [24642,24646]
name: self [24642,24646]
===
match
---
name: session [74698,74705]
name: session [74750,74757]
===
match
---
if_stmt [56730,56795]
if_stmt [56782,56847]
===
match
---
name: log_message [58019,58030]
name: log_message [58071,58082]
===
match
---
simple_stmt [62221,62271]
simple_stmt [62273,62323]
===
match
---
atom_expr [59461,59478]
atom_expr [59513,59530]
===
match
---
if_stmt [43424,43468]
if_stmt [43476,43520]
===
match
---
fstring_string: . [44963,44964]
fstring_string: . [45015,45016]
===
match
---
name: task [72643,72647]
name: task [72695,72699]
===
match
---
name: context [67953,67960]
name: context [68005,68012]
===
match
---
import_from [45869,45909]
import_from [45921,45961]
===
match
---
name: conf [67775,67779]
name: conf [67827,67831]
===
match
---
name: dag_id [78947,78953]
name: dag_id [78999,79005]
===
match
---
name: session [30137,30144]
name: session [30137,30144]
===
match
---
expr_stmt [58181,58226]
expr_stmt [58233,58278]
===
match
---
name: self [58540,58544]
name: self [58592,58596]
===
match
---
name: ignore_all_deps [15029,15044]
name: ignore_all_deps [15029,15044]
===
match
---
name: previous_schedule [61307,61324]
name: previous_schedule [61359,61376]
===
match
---
atom_expr [82627,82653]
atom_expr [82679,82705]
===
match
---
expr_stmt [7870,7903]
expr_stmt [7870,7903]
===
match
---
name: raw [12319,12322]
name: raw [12319,12322]
===
match
---
name: self [32531,32535]
name: self [32531,32535]
===
match
---
decorated [81138,81201]
decorated [81190,81253]
===
match
---
import_from [1350,1393]
import_from [1350,1393]
===
match
---
operator: , [66053,66054]
operator: , [66105,66106]
===
match
---
simple_stmt [40500,40529]
simple_stmt [40500,40529]
===
match
---
name: RenderedTaskInstanceFields [66215,66241]
name: RenderedTaskInstanceFields [66267,66293]
===
match
---
argument [15180,15211]
argument [15180,15211]
===
match
---
atom_expr [79285,79304]
atom_expr [79337,79356]
===
match
---
name: f [71995,71996]
name: f [72047,72048]
===
match
---
trailer [45426,45428]
trailer [45478,45480]
===
match
---
name: Column [9885,9891]
name: Column [9885,9891]
===
match
---
simple_stmt [22439,22463]
simple_stmt [22439,22463]
===
match
---
atom_expr [49939,50156]
atom_expr [49991,50208]
===
match
---
name: extend [18577,18583]
name: extend [18577,18583]
===
match
---
simple_stmt [31881,31895]
simple_stmt [31881,31895]
===
match
---
arglist [68542,68567]
arglist [68594,68619]
===
match
---
simple_stmt [37898,37946]
simple_stmt [37898,37946]
===
match
---
operator: = [32330,32331]
operator: = [32330,32331]
===
match
---
name: dag_id [46120,46126]
name: dag_id [46172,46178]
===
match
---
trailer [21449,21455]
trailer [21449,21455]
===
match
---
import_from [82533,82573]
import_from [82585,82625]
===
match
---
arith_expr [33647,33666]
arith_expr [33647,33666]
===
match
---
name: result [50434,50440]
name: result [50486,50492]
===
match
---
decorator [56007,56024]
decorator [56059,56076]
===
match
---
name: lock_for_update [82251,82266]
name: lock_for_update [82303,82318]
===
match
---
name: tis [5106,5109]
name: tis [5106,5109]
===
match
---
name: self [72433,72437]
name: self [72485,72489]
===
match
---
name: TaskInstance [21529,21541]
name: TaskInstance [21529,21541]
===
match
---
name: session [31851,31858]
name: session [31851,31858]
===
match
---
funcdef [3265,3848]
funcdef [3265,3848]
===
match
---
simple_stmt [35355,35523]
simple_stmt [35355,35523]
===
match
---
operator: , [79435,79436]
operator: , [79487,79488]
===
match
---
simple_stmt [31680,31695]
simple_stmt [31680,31695]
===
match
---
operator: , [62207,62208]
operator: , [62259,62260]
===
match
---
operator: , [53508,53509]
operator: , [53560,53561]
===
match
---
return_stmt [41498,41535]
return_stmt [41467,41504]
===
match
---
name: dag [26771,26774]
name: dag [26771,26774]
===
match
---
name: Union [52320,52325]
name: Union [52372,52377]
===
match
---
trailer [41278,41332]
trailer [41247,41301]
===
match
---
name: ti [79418,79420]
name: ti [79470,79472]
===
match
---
operator: -> [21022,21024]
operator: -> [21022,21024]
===
match
---
operator: , [1785,1786]
operator: , [1785,1786]
===
match
---
tfpdef [8553,8568]
tfpdef [8553,8568]
===
match
---
expr_stmt [70533,70561]
expr_stmt [70585,70613]
===
match
---
operator: , [17934,17935]
operator: , [17934,17935]
===
match
---
simple_stmt [78304,78325]
simple_stmt [78356,78377]
===
match
---
suite [56254,58980]
suite [56306,59032]
===
match
---
atom_expr [32696,32715]
atom_expr [32696,32715]
===
match
---
import_from [2110,2170]
import_from [2110,2170]
===
match
---
string: 'dag_run' [64557,64566]
string: 'dag_run' [64609,64618]
===
match
---
atom_expr [10334,10374]
atom_expr [10334,10374]
===
match
---
simple_stmt [59315,59356]
simple_stmt [59367,59408]
===
match
---
name: merge [50934,50939]
name: merge [50986,50991]
===
match
---
argument [54196,54205]
argument [54248,54257]
===
match
---
name: render_templates [66579,66595]
name: render_templates [66631,66647]
===
match
---
atom_expr [40500,40528]
atom_expr [40500,40528]
===
match
---
operator: = [10521,10522]
operator: = [10521,10522]
===
match
---
name: context [3546,3553]
name: context [3546,3553]
===
match
---
name: RenderedTaskInstanceFields [48862,48888]
name: RenderedTaskInstanceFields [48914,48940]
===
match
---
name: self [59483,59487]
name: self [59535,59539]
===
match
---
simple_stmt [11477,11640]
simple_stmt [11477,11640]
===
match
---
operator: , [1050,1051]
operator: , [1050,1051]
===
match
---
number: 0 [3981,3982]
number: 0 [3981,3982]
===
match
---
name: timedelta [34556,34565]
name: timedelta [34556,34565]
===
match
---
operator: = [50565,50566]
operator: = [50617,50618]
===
match
---
number: 20 [9738,9740]
number: 20 [9738,9740]
===
match
---
parameters [80607,80613]
parameters [80659,80665]
===
match
---
fstring_start: f" [14685,14687]
fstring_start: f" [14685,14687]
===
match
---
simple_stmt [78364,78402]
simple_stmt [78416,78454]
===
match
---
atom_expr [40537,40616]
atom_expr [40537,40616]
===
match
---
name: local [15231,15236]
name: local [15231,15236]
===
match
---
simple_stmt [5368,5397]
simple_stmt [5368,5397]
===
match
---
name: session [55149,55156]
name: session [55201,55208]
===
match
---
name: self [32577,32581]
name: self [32577,32581]
===
match
---
simple_stmt [9986,10042]
simple_stmt [9986,10042]
===
match
---
operator: , [53587,53588]
operator: , [53639,53640]
===
match
---
trailer [4619,4626]
trailer [4619,4626]
===
match
---
name: queue [81324,81329]
name: queue [81376,81381]
===
match
---
name: VariableAccessor [65922,65938]
name: VariableAccessor [65974,65990]
===
match
---
operator: , [78785,78786]
operator: , [78837,78838]
===
match
---
simple_stmt [58019,58059]
simple_stmt [58071,58111]
===
match
---
operator: = [39901,39902]
operator: = [39901,39902]
===
match
---
argument [53946,53991]
argument [53998,54043]
===
match
---
name: qry [21769,21772]
name: qry [21769,21772]
===
match
---
name: self [63055,63059]
name: self [63107,63111]
===
match
---
atom_expr [40782,40795]
atom_expr [40782,40795]
===
match
---
name: session [74379,74386]
name: session [74431,74438]
===
match
---
arglist [62204,62211]
arglist [62256,62263]
===
match
---
operator: , [74571,74572]
operator: , [74623,74624]
===
match
---
string: "execution date %s has no timezone information. Using default from dag or system" [11511,11592]
string: "execution date %s has no timezone information. Using default from dag or system" [11511,11592]
===
match
---
name: Iterable [1052,1060]
name: Iterable [1052,1060]
===
match
---
name: execution_date [78387,78401]
name: execution_date [78439,78453]
===
match
---
decorator [29645,29662]
decorator [29645,29662]
===
match
---
param [74519,74572]
param [74571,74624]
===
match
---
name: pool [37499,37503]
name: pool [37499,37503]
===
match
---
strings [43605,43719]
strings [43657,43771]
===
match
---
name: get_previous_ti [30100,30115]
name: get_previous_ti [30100,30115]
===
match
---
operator: , [8498,8499]
operator: , [8498,8499]
===
match
---
if_stmt [21850,22792]
if_stmt [21850,22792]
===
match
---
name: test_mode [37530,37539]
name: test_mode [37530,37539]
===
match
---
operator: % [34122,34123]
operator: % [34122,34123]
===
match
---
name: execution_date [60355,60369]
name: execution_date [60407,60421]
===
match
---
name: dep_context [32384,32395]
name: dep_context [32384,32395]
===
match
---
atom_expr [74255,74267]
atom_expr [74307,74319]
===
match
---
simple_stmt [71926,71956]
simple_stmt [71978,72008]
===
match
---
atom_expr [58425,58436]
atom_expr [58477,58488]
===
match
---
suite [81174,81201]
suite [81226,81253]
===
match
---
name: default_html_content [71264,71284]
name: default_html_content [71316,71336]
===
match
---
trailer [80031,80043]
trailer [80083,80095]
===
match
---
name: delay_backoff_in_seconds [34629,34653]
name: delay_backoff_in_seconds [34629,34653]
===
match
---
name: self [72867,72871]
name: self [72919,72923]
===
match
---
operator: , [32062,32063]
operator: , [32062,32063]
===
match
---
name: task [42576,42580]
name: task [42545,42549]
===
match
---
argument [50558,50573]
argument [50610,50625]
===
match
---
name: _run_as_user [80170,80182]
name: _run_as_user [80222,80234]
===
match
---
string: 'start_date' [45331,45343]
string: 'start_date' [45383,45395]
===
match
---
name: task_ids [76582,76590]
name: task_ids [76634,76642]
===
match
---
simple_stmt [26315,26361]
simple_stmt [26315,26361]
===
match
---
name: AirflowSmartSensorException [1758,1785]
name: AirflowSmartSensorException [1758,1785]
===
match
---
atom_expr [77678,77698]
atom_expr [77730,77750]
===
match
---
simple_stmt [12092,12111]
simple_stmt [12092,12111]
===
match
---
name: _run_raw_task [41610,41623]
name: _run_raw_task [41579,41592]
===
match
---
trailer [63439,63443]
trailer [63491,63495]
===
match
---
atom_expr [56761,56794]
atom_expr [56813,56846]
===
match
---
name: get_previous_start_date [30831,30854]
name: get_previous_start_date [30831,30854]
===
match
---
atom_expr [80968,80982]
atom_expr [81020,81034]
===
match
---
trailer [82434,82436]
trailer [82486,82488]
===
match
---
suite [19412,19792]
suite [19412,19792]
===
match
---
argument [72102,72117]
argument [72154,72169]
===
match
---
suite [64307,64472]
suite [64359,64524]
===
match
---
simple_stmt [2237,2288]
simple_stmt [2237,2288]
===
match
---
simple_stmt [2443,2490]
simple_stmt [2443,2490]
===
match
---
operator: = [27824,27825]
operator: = [27824,27825]
===
match
---
simple_stmt [19458,19503]
simple_stmt [19458,19503]
===
match
---
name: UtcDateTime [9580,9591]
name: UtcDateTime [9580,9591]
===
match
---
expr_stmt [14521,14540]
expr_stmt [14521,14540]
===
match
---
operator: = [54884,54885]
operator: = [54936,54937]
===
match
---
name: TaskInstance [78756,78768]
name: TaskInstance [78808,78820]
===
match
---
operator: , [38368,38369]
operator: , [38368,38369]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28063,28202]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28063,28202]
===
match
---
name: self [58137,58141]
name: self [58189,58193]
===
match
---
name: _try_number [40667,40678]
name: _try_number [40667,40678]
===
match
---
simple_stmt [70107,70496]
simple_stmt [70159,70548]
===
match
---
suite [45767,48008]
suite [45819,48060]
===
match
---
name: provide_session [20939,20954]
name: provide_session [20939,20954]
===
match
---
operator: , [1809,1810]
operator: , [1809,1810]
===
match
---
param [50755,50760]
param [50807,50812]
===
match
---
name: self [23934,23938]
name: self [23934,23938]
===
match
---
simple_stmt [8054,8070]
simple_stmt [8054,8070]
===
match
---
trailer [18469,18476]
trailer [18469,18476]
===
match
---
trailer [39115,39139]
trailer [39115,39139]
===
match
---
trailer [68953,68976]
trailer [69005,69028]
===
match
---
simple_stmt [20619,20782]
simple_stmt [20619,20782]
===
match
---
name: execution_date [74328,74342]
name: execution_date [74380,74394]
===
match
---
name: TaskInstance [79769,79781]
name: TaskInstance [79821,79833]
===
match
---
string: "run" [17936,17941]
string: "run" [17936,17941]
===
match
---
comparison [20352,20402]
comparison [20352,20402]
===
match
---
name: task_id [11183,11190]
name: task_id [11183,11190]
===
match
---
name: replace [62196,62203]
name: replace [62248,62255]
===
match
---
name: bool [35806,35810]
name: bool [35806,35810]
===
match
---
name: iso [19458,19461]
name: iso [19458,19461]
===
match
---
name: task_copy [48270,48279]
name: task_copy [48322,48331]
===
match
---
operator: , [26074,26075]
operator: , [26074,26075]
===
match
---
atom_expr [39791,39872]
atom_expr [39791,39872]
===
match
---
name: mark_success [14028,14040]
name: mark_success [14028,14040]
===
match
---
simple_stmt [82579,82623]
simple_stmt [82631,82675]
===
match
---
operator: = [22247,22248]
operator: = [22247,22248]
===
match
---
name: task [72732,72736]
name: task [72784,72788]
===
match
---
name: task [59466,59470]
name: task [59518,59522]
===
match
---
name: try_number [22236,22246]
name: try_number [22236,22246]
===
match
---
arglist [10744,10783]
arglist [10744,10783]
===
match
---
name: TaskInstance [21611,21623]
name: TaskInstance [21611,21623]
===
match
---
name: default_var [63450,63461]
name: default_var [63502,63513]
===
match
---
name: bool [35682,35686]
name: bool [35682,35686]
===
match
---
name: REQUEUEABLE_DEPS [38191,38207]
name: REQUEUEABLE_DEPS [38191,38207]
===
match
---
import_from [2171,2204]
import_from [2171,2204]
===
match
---
sync_comp_for [7086,7129]
sync_comp_for [7086,7129]
===
match
---
name: self [80333,80337]
name: self [80385,80389]
===
match
---
name: self [19836,19840]
name: self [19836,19840]
===
match
---
simple_stmt [79980,80019]
simple_stmt [80032,80071]
===
match
---
simple_stmt [11144,11170]
simple_stmt [11144,11170]
===
match
---
trailer [29457,29463]
trailer [29457,29463]
===
match
---
atom_expr [35471,35490]
atom_expr [35471,35490]
===
match
---
decorator [8267,8277]
decorator [8267,8277]
===
match
---
operator: , [32544,32545]
operator: , [32544,32545]
===
match
---
operator: == [52830,52832]
operator: == [52882,52884]
===
match
---
name: path [71986,71990]
name: path [72038,72042]
===
match
---
name: self [18908,18912]
name: self [18908,18912]
===
match
---
operator: -> [67988,67990]
operator: -> [68040,68042]
===
match
---
name: _try_number [81051,81062]
name: _try_number [81103,81114]
===
match
---
expr_stmt [48209,48249]
expr_stmt [48261,48301]
===
match
---
comparison [51795,51813]
comparison [51847,51865]
===
match
---
simple_stmt [34512,34591]
simple_stmt [34512,34591]
===
match
---
param [59142,59167]
param [59194,59219]
===
match
---
param [25390,25402]
param [25390,25402]
===
match
---
operator: , [7753,7754]
operator: , [7753,7754]
===
match
---
operator: , [71729,71730]
operator: , [71781,71782]
===
match
---
name: self [50755,50759]
name: self [50807,50811]
===
match
---
expr_stmt [61438,61452]
expr_stmt [61490,61504]
===
match
---
atom_expr [18520,18543]
atom_expr [18520,18543]
===
match
---
strings [66724,67030]
strings [66776,67082]
===
match
---
import_from [1813,1873]
import_from [1813,1873]
===
match
---
expr_stmt [3101,3117]
expr_stmt [3101,3117]
===
match
---
trailer [82349,82355]
trailer [82401,82407]
===
match
---
name: property [18817,18825]
name: property [18817,18825]
===
match
---
name: self [42967,42971]
name: self [43019,43023]
===
match
---
trailer [52125,52134]
trailer [52177,52186]
===
match
---
name: str [53719,53722]
name: str [53771,53774]
===
match
---
arith_expr [13921,13941]
arith_expr [13921,13941]
===
match
---
name: task_id [77146,77153]
name: task_id [77198,77205]
===
match
---
name: self [80519,80523]
name: self [80571,80575]
===
match
---
operator: = [49739,49740]
operator: = [49791,49792]
===
match
---
number: 0 [11999,12000]
number: 0 [11999,12000]
===
match
---
name: on_execute_callback [52064,52083]
name: on_execute_callback [52116,52135]
===
match
---
expr_stmt [9411,9479]
expr_stmt [9411,9479]
===
match
---
trailer [82355,82357]
trailer [82407,82409]
===
match
---
param [41633,41638]
param [41602,41607]
===
match
---
name: execution_date [74124,74138]
name: execution_date [74176,74190]
===
match
---
tfpdef [64225,64241]
tfpdef [64277,64293]
===
match
---
name: self [34970,34974]
name: self [34970,34974]
===
match
---
operator: , [74509,74510]
operator: , [74561,74562]
===
match
---
trailer [77690,77698]
trailer [77742,77750]
===
match
---
atom_expr [14957,14976]
atom_expr [14957,14976]
===
match
---
simple_stmt [63048,63064]
simple_stmt [63100,63116]
===
match
---
name: airflow [2495,2502]
name: airflow [2495,2502]
===
match
---
string: 'next_execution_date' [64860,64881]
string: 'next_execution_date' [64912,64933]
===
match
---
string: "--subdir" [18698,18708]
string: "--subdir" [18698,18708]
===
match
---
name: key [74201,74204]
name: key [74253,74256]
===
match
---
name: query [7333,7338]
name: query [7333,7338]
===
match
---
trailer [67797,67801]
trailer [67849,67853]
===
match
---
name: first [21791,21796]
name: first [21791,21796]
===
match
---
decorator [13181,13200]
decorator [13181,13200]
===
match
---
trailer [48005,48007]
trailer [48057,48059]
===
match
---
operator: = [9847,9848]
operator: = [9847,9848]
===
match
---
name: refresh_from_task [11244,11261]
name: refresh_from_task [11244,11261]
===
match
---
operator: = [22373,22374]
operator: = [22373,22374]
===
match
---
suite [52847,53034]
suite [52899,53086]
===
match
---
name: self [22507,22511]
name: self [22507,22511]
===
match
---
trailer [26187,26202]
trailer [26187,26202]
===
match
---
name: email_on_failure [58094,58110]
name: email_on_failure [58146,58162]
===
match
---
simple_stmt [24601,24634]
simple_stmt [24601,24634]
===
match
---
name: handle_failure [44252,44266]
name: handle_failure [44304,44318]
===
match
---
operator: = [19231,19232]
operator: = [19231,19232]
===
match
---
parameters [67946,67987]
parameters [67998,68039]
===
match
---
name: Tuple [79586,79591]
name: Tuple [79638,79643]
===
match
---
sync_comp_for [78901,78913]
sync_comp_for [78953,78965]
===
match
---
expr_stmt [54879,54895]
expr_stmt [54931,54947]
===
match
---
string: "--force" [18478,18487]
string: "--force" [18478,18487]
===
match
---
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [70423,70485]
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [70475,70537]
===
match
---
expr_stmt [71776,71816]
expr_stmt [71828,71868]
===
match
---
trailer [68441,69018]
trailer [68493,69070]
===
match
---
name: math [33606,33610]
name: math [33606,33610]
===
match
---
funcdef [25360,26361]
funcdef [25360,26361]
===
match
---
expr_stmt [51479,51522]
expr_stmt [51531,51574]
===
match
---
trailer [77574,77588]
trailer [77626,77640]
===
match
---
trailer [25289,25302]
trailer [25289,25302]
===
match
---
name: State [26255,26260]
name: State [26255,26260]
===
match
---
name: _run_finished_callback [59320,59342]
name: _run_finished_callback [59372,59394]
===
match
---
fstring_string: operator_successes_ [50612,50631]
fstring_string: operator_successes_ [50664,50683]
===
match
---
operator: , [32648,32649]
operator: , [32648,32649]
===
match
---
trailer [58615,58644]
trailer [58667,58696]
===
match
---
trailer [19530,19555]
trailer [19530,19555]
===
match
---
name: init_on_load [12124,12136]
name: init_on_load [12124,12136]
===
match
---
trailer [28744,28978]
trailer [28744,28978]
===
match
---
name: self [56829,56833]
name: self [56881,56885]
===
match
---
simple_stmt [54366,54613]
simple_stmt [54418,54665]
===
match
---
name: task_id_by_key [7107,7121]
name: task_id_by_key [7107,7121]
===
match
---
name: str [56083,56086]
name: str [56135,56138]
===
match
---
name: session [23838,23845]
name: session [23838,23845]
===
match
---
name: session [26451,26458]
name: session [26451,26458]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.             """ [30582,30741]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.             """ [30582,30741]
===
match
---
name: retries [59471,59478]
name: retries [59523,59530]
===
match
---
trailer [44940,44947]
trailer [44992,44999]
===
match
---
argument [63450,63473]
argument [63502,63525]
===
match
---
expr_stmt [34713,34758]
expr_stmt [34713,34758]
===
match
---
trailer [33871,33886]
trailer [33871,33886]
===
match
---
return_stmt [27924,27991]
return_stmt [27924,27991]
===
match
---
trailer [71190,71197]
trailer [71242,71249]
===
match
---
name: timezone [40344,40352]
name: timezone [40344,40352]
===
match
---
name: dag_id [74293,74299]
name: dag_id [74345,74351]
===
match
---
arglist [68455,69008]
arglist [68507,69060]
===
match
---
expr_stmt [58071,58110]
expr_stmt [58123,58162]
===
match
---
funcdef [35568,41353]
funcdef [35568,41322]
===
match
---
string: 'outlets' [64916,64925]
string: 'outlets' [64968,64977]
===
match
---
name: _priority_weight [81284,81300]
name: _priority_weight [81336,81352]
===
match
---
trailer [23285,23296]
trailer [23285,23296]
===
match
---
name: task [23442,23446]
name: task [23442,23446]
===
match
---
argument [54136,54155]
argument [54188,54207]
===
match
---
trailer [18077,18107]
trailer [18077,18107]
===
match
---
name: ti [21979,21981]
name: ti [21979,21981]
===
match
---
operator: = [59277,59278]
operator: = [59329,59330]
===
match
---
name: dependencies_deps [2309,2326]
name: dependencies_deps [2309,2326]
===
match
---
or_test [24895,24924]
or_test [24895,24924]
===
match
---
suite [58002,58059]
suite [58054,58111]
===
match
---
trailer [82591,82599]
trailer [82643,82651]
===
match
---
operator: , [72662,72663]
operator: , [72714,72715]
===
match
---
name: innerjoin [11001,11010]
name: innerjoin [11001,11010]
===
match
---
name: plugins_manager [2123,2138]
name: plugins_manager [2123,2138]
===
match
---
expr_stmt [40662,40683]
expr_stmt [40662,40683]
===
match
---
atom_expr [5233,5258]
atom_expr [5233,5258]
===
match
---
name: XCom [76976,76980]
name: XCom [77028,77032]
===
match
---
operator: = [27768,27769]
operator: = [27768,27769]
===
match
---
return_stmt [81039,81062]
return_stmt [81091,81114]
===
match
---
trailer [32747,32754]
trailer [32747,32754]
===
match
---
operator: = [9696,9697]
operator: = [9696,9697]
===
match
---
expr_stmt [80519,80537]
expr_stmt [80571,80589]
===
match
---
name: self [44028,44032]
name: self [44080,44084]
===
match
---
name: incr [37783,37787]
name: incr [37783,37787]
===
match
---
atom_expr [4079,4097]
atom_expr [4079,4097]
===
match
---
simple_stmt [57027,57064]
simple_stmt [57079,57116]
===
match
---
name: warnings [30555,30563]
name: warnings [30555,30563]
===
match
---
simple_stmt [7552,7798]
simple_stmt [7552,7798]
===
match
---
atom_expr [55848,55864]
atom_expr [55900,55916]
===
match
---
atom_expr [12314,12322]
atom_expr [12314,12322]
===
match
---
arglist [56776,56793]
arglist [56828,56845]
===
match
---
expr_stmt [43139,43165]
expr_stmt [43191,43217]
===
match
---
simple_stmt [71227,71310]
simple_stmt [71279,71362]
===
match
---
funcdef [8281,8522]
funcdef [8281,8522]
===
match
---
name: dag_run [64568,64575]
name: dag_run [64620,64627]
===
match
---
atom_expr [18466,18489]
atom_expr [18466,18489]
===
match
---
trailer [29463,29501]
trailer [29463,29501]
===
match
---
operator: = [11286,11287]
operator: = [11286,11287]
===
match
---
trailer [82088,82095]
trailer [82140,82147]
===
match
---
atom_expr [78642,78650]
atom_expr [78694,78702]
===
match
---
fstring_expr [48714,48732]
fstring_expr [48766,48784]
===
match
---
dotted_name [1454,1476]
dotted_name [1454,1476]
===
match
---
trailer [43240,43243]
trailer [43292,43295]
===
match
---
simple_stmt [21764,21799]
simple_stmt [21764,21799]
===
match
---
annassign [8015,8020]
annassign [8015,8020]
===
match
---
expr_stmt [80027,80064]
expr_stmt [80079,80116]
===
match
---
decorator [25036,25046]
decorator [25036,25046]
===
match
---
testlist_comp [66618,66656]
testlist_comp [66670,66708]
===
match
---
trailer [23987,24002]
trailer [23987,24002]
===
match
---
name: job_id [54482,54488]
name: job_id [54534,54540]
===
match
---
name: current_state [19822,19835]
name: current_state [19822,19835]
===
match
---
and_test [7442,7467]
and_test [7442,7467]
===
match
---
suite [21751,21799]
suite [21751,21799]
===
match
---
name: self [20590,20594]
name: self [20590,20594]
===
match
---
suite [22761,22792]
suite [22761,22792]
===
match
---
decorated [29041,29640]
decorated [29041,29640]
===
match
---
string: 'execution_date' [43816,43832]
string: 'execution_date' [43868,43884]
===
match
---
atom_expr [61325,61344]
atom_expr [61377,61396]
===
match
---
param [14056,14078]
param [14056,14078]
===
match
---
trailer [24805,24811]
trailer [24805,24811]
===
match
---
sync_comp_for [77023,77082]
sync_comp_for [77075,77134]
===
match
---
name: task_ids [76573,76581]
name: task_ids [76625,76633]
===
match
---
atom_expr [64683,64702]
atom_expr [64735,64754]
===
match
---
name: __table__ [7165,7174]
name: __table__ [7165,7174]
===
match
---
expr_stmt [22231,22263]
expr_stmt [22231,22263]
===
match
---
name: log [43579,43582]
name: log [43631,43634]
===
match
---
decorated [8075,8262]
decorated [8075,8262]
===
match
---
atom_expr [50926,50945]
atom_expr [50978,50997]
===
match
---
string: 'TaskInstance' [26493,26507]
string: 'TaskInstance' [26493,26507]
===
match
---
name: Dict [3149,3153]
name: Dict [3149,3153]
===
match
---
simple_stmt [9838,9870]
simple_stmt [9838,9870]
===
match
---
trailer [27062,27080]
trailer [27062,27080]
===
match
---
operator: , [59752,59753]
operator: , [59804,59805]
===
match
---
simple_stmt [11239,11268]
simple_stmt [11239,11268]
===
match
---
decorated [12411,12591]
decorated [12411,12591]
===
match
---
name: ignore_task_deps [15091,15107]
name: ignore_task_deps [15091,15107]
===
match
---
operator: , [10811,10812]
operator: , [10811,10812]
===
match
---
funcdef [59006,59356]
funcdef [59058,59408]
===
match
---
operator: = [68767,68768]
operator: = [68819,68820]
===
match
---
term [34114,34135]
term [34114,34135]
===
match
---
trailer [49615,49642]
trailer [49667,49694]
===
match
---
name: ti [5940,5942]
name: ti [5940,5942]
===
match
---
name: sqlalchemy [2769,2779]
name: sqlalchemy [2769,2779]
===
match
---
atom_expr [79929,79945]
atom_expr [79981,79997]
===
match
---
tfpdef [15849,15873]
tfpdef [15849,15873]
===
match
---
trailer [5942,5948]
trailer [5942,5948]
===
match
---
simple_stmt [12314,12331]
simple_stmt [12314,12331]
===
match
---
if_stmt [18660,18722]
if_stmt [18660,18722]
===
match
---
trailer [44827,44864]
trailer [44879,44916]
===
match
---
string: """Remake the key by subtracting 1 from try number to match in memory information""" [8329,8413]
string: """Remake the key by subtracting 1 from try number to match in memory information""" [8329,8413]
===
match
---
return_stmt [19025,19083]
return_stmt [19025,19083]
===
match
---
operator: = [14071,14072]
operator: = [14071,14072]
===
match
---
atom_expr [59315,59355]
atom_expr [59367,59407]
===
match
---
name: self [58600,58604]
name: self [58652,58656]
===
match
---
trailer [52551,52557]
trailer [52603,52609]
===
match
---
trailer [50307,50336]
trailer [50359,50388]
===
match
---
trailer [58299,58655]
trailer [58351,58707]
===
match
---
operator: = [23297,23298]
operator: = [23297,23298]
===
match
---
name: SUCCESS [65395,65402]
name: SUCCESS [65447,65454]
===
match
---
operator: = [34609,34610]
operator: = [34609,34610]
===
match
---
expr_stmt [60016,60030]
expr_stmt [60068,60082]
===
match
---
operator: = [41439,41440]
operator: = [41408,41409]
===
match
---
operator: , [64768,64769]
operator: , [64820,64821]
===
match
---
expr_stmt [52673,52710]
expr_stmt [52725,52762]
===
match
---
param [15700,15731]
param [15700,15731]
===
match
---
if_stmt [7243,7434]
if_stmt [7243,7434]
===
match
---
trailer [47416,47421]
trailer [47468,47473]
===
match
---
name: DeprecationWarning [28403,28421]
name: DeprecationWarning [28403,28421]
===
match
---
operator: = [11707,11708]
operator: = [11707,11708]
===
match
---
try_stmt [45948,48008]
try_stmt [46000,48060]
===
match
---
atom_expr [60654,60673]
atom_expr [60706,60725]
===
match
---
trailer [77759,77767]
trailer [77811,77819]
===
match
---
argument [49149,49171]
argument [49201,49223]
===
match
---
arglist [10867,11016]
arglist [10867,11016]
===
match
---
suite [59638,59679]
suite [59690,59731]
===
match
---
atom_expr [10633,10657]
atom_expr [10633,10657]
===
match
---
simple_stmt [32167,32225]
simple_stmt [32167,32225]
===
match
---
atom_expr [13805,13821]
atom_expr [13805,13821]
===
match
---
name: task_instance_scheduling_decisions [46898,46932]
name: task_instance_scheduling_decisions [46950,46984]
===
match
---
simple_stmt [48129,48200]
simple_stmt [48181,48252]
===
match
---
trailer [53004,53024]
trailer [53056,53076]
===
match
---
name: RUNNING [40788,40795]
name: RUNNING [40788,40795]
===
match
---
trailer [53104,53109]
trailer [53156,53161]
===
match
---
name: previous_scheduled_date [27250,27273]
name: previous_scheduled_date [27250,27273]
===
match
---
name: getuser [2692,2699]
name: getuser [2692,2699]
===
match
---
operator: , [30741,30742]
operator: , [30741,30742]
===
match
---
name: error [59349,59354]
name: error [59401,59406]
===
match
---
name: session [32537,32544]
name: session [32537,32544]
===
match
---
tfpdef [53472,53500]
tfpdef [53524,53552]
===
match
---
atom_expr [79263,79450]
atom_expr [79315,79502]
===
match
---
name: fd [3973,3975]
name: fd [3973,3975]
===
match
---
funcdef [20959,22851]
funcdef [20959,22851]
===
match
---
name: execution_date [60659,60673]
name: execution_date [60711,60725]
===
match
---
name: cmd [18139,18142]
name: cmd [18139,18142]
===
match
---
name: provide_session [24320,24335]
name: provide_session [24320,24335]
===
match
---
trailer [49947,49955]
trailer [49999,50007]
===
match
---
name: skippable_task_ids [46959,46977]
name: skippable_task_ids [47011,47029]
===
match
---
name: ti [5515,5517]
name: ti [5515,5517]
===
match
---
trailer [43104,43126]
trailer [43156,43178]
===
match
---
name: self [27224,27228]
name: self [27224,27228]
===
match
---
trailer [72038,72040]
trailer [72090,72092]
===
match
---
name: dry_run [54808,54815]
name: dry_run [54860,54867]
===
match
---
operator: == [77699,77701]
operator: == [77751,77753]
===
match
---
trailer [46613,46823]
trailer [46665,46875]
===
match
---
simple_stmt [44063,44139]
simple_stmt [44115,44191]
===
match
---
operator: = [64435,64436]
operator: = [64487,64488]
===
match
---
name: airflow [2755,2762]
name: airflow [2755,2762]
===
match
---
simple_stmt [63928,63981]
simple_stmt [63980,64033]
===
match
---
name: date_attr [59591,59600]
name: date_attr [59643,59652]
===
match
---
and_test [5321,5350]
and_test [5321,5350]
===
match
---
trailer [48985,48993]
trailer [49037,49045]
===
match
---
trailer [45487,45493]
trailer [45539,45545]
===
match
---
name: try_number [68582,68592]
name: try_number [68634,68644]
===
match
---
name: self [22439,22443]
name: self [22439,22443]
===
match
---
atom_expr [67793,67880]
atom_expr [67845,67932]
===
match
---
operator: { [59961,59962]
operator: { [60013,60014]
===
match
---
expr_stmt [52727,52755]
expr_stmt [52779,52807]
===
match
---
name: task [47429,47433]
name: task [47481,47485]
===
match
---
operator: , [50133,50134]
operator: , [50185,50186]
===
match
---
trailer [18012,18032]
trailer [18012,18032]
===
match
---
operator: } [48751,48752]
operator: } [48803,48804]
===
match
---
atom_expr [29188,29215]
atom_expr [29188,29215]
===
match
---
operator: , [40241,40242]
operator: , [40241,40242]
===
match
---
name: airflow [2858,2865]
name: airflow [2858,2865]
===
match
---
name: previous_scheduled_date [27125,27148]
name: previous_scheduled_date [27125,27148]
===
match
---
tfpdef [35828,35849]
tfpdef [35828,35849]
===
match
---
operator: , [74299,74300]
operator: , [74351,74352]
===
match
---
trailer [22007,22016]
trailer [22007,22016]
===
match
---
name: Proxy [65323,65328]
name: Proxy [65375,65380]
===
match
---
decorated [77955,79487]
decorated [78007,79539]
===
match
---
name: iso [19316,19319]
name: iso [19316,19319]
===
match
---
name: email_on_retry [58262,58276]
name: email_on_retry [58314,58328]
===
match
---
atom_expr [9946,9981]
atom_expr [9946,9981]
===
match
---
name: AirflowSmartSensorException [51029,51056]
name: AirflowSmartSensorException [51081,51108]
===
match
---
argument [54052,54083]
argument [54104,54135]
===
match
---
name: self [60598,60602]
name: self [60650,60654]
===
match
---
if_stmt [61491,61705]
if_stmt [61543,61757]
===
match
---
name: models [7490,7496]
name: models [7490,7496]
===
match
---
operator: , [56947,56948]
operator: , [56999,57000]
===
match
---
name: var [63007,63010]
name: var [63059,63062]
===
match
---
operator: , [65264,65265]
operator: , [65316,65317]
===
match
---
trailer [11122,11124]
trailer [11122,11124]
===
match
---
trailer [32786,32793]
trailer [32786,32793]
===
match
---
string: """         Copy common attributes from the given task.          :param task: The task object to copy from         :type task: airflow.models.BaseOperator         :param pool_override: Use the pool_override instead of task's pool         :type pool_override: str         """ [22919,23193]
string: """         Copy common attributes from the given task.          :param task: The task object to copy from         :type task: airflow.models.BaseOperator         :param pool_override: Use the pool_override instead of task's pool         :type pool_override: str         """ [22919,23193]
===
match
---
argument [38323,38368]
argument [38323,38368]
===
match
---
parameters [66102,66108]
parameters [66154,66160]
===
match
---
name: dag_id [7653,7659]
name: dag_id [7653,7659]
===
match
---
trailer [77930,77943]
trailer [77982,77995]
===
match
---
trailer [21839,21841]
trailer [21839,21841]
===
match
---
operator: , [44591,44592]
operator: , [44643,44644]
===
match
---
trailer [68144,68167]
trailer [68196,68219]
===
match
---
atom_expr [8228,8240]
atom_expr [8228,8240]
===
match
---
operator: , [10687,10688]
operator: , [10687,10688]
===
match
---
trailer [76424,76431]
trailer [76476,76483]
===
match
---
annassign [80043,80064]
annassign [80095,80116]
===
match
---
simple_stmt [54758,54799]
simple_stmt [54810,54851]
===
match
---
expr_stmt [3119,3138]
expr_stmt [3119,3138]
===
match
---
trailer [82035,82041]
trailer [82087,82093]
===
match
---
name: ignore_all_deps [39562,39577]
name: ignore_all_deps [39562,39577]
===
match
---
operator: { [32979,32980]
operator: { [32979,32980]
===
match
---
name: base_url [19571,19579]
name: base_url [19571,19579]
===
match
---
name: ignore_depends_on_past [18349,18371]
name: ignore_depends_on_past [18349,18371]
===
match
---
trailer [24631,24633]
trailer [24631,24633]
===
match
---
trailer [45557,45559]
trailer [45609,45611]
===
match
---
parameters [25066,25072]
parameters [25066,25072]
===
match
---
trailer [62355,62362]
trailer [62407,62414]
===
match
---
return_stmt [81503,81531]
return_stmt [81555,81583]
===
match
---
simple_stmt [37548,37608]
simple_stmt [37548,37608]
===
match
---
trailer [59866,59871]
trailer [59918,59923]
===
match
---
name: downstream_task_ids [25913,25932]
name: downstream_task_ids [25913,25932]
===
match
---
simple_stmt [45869,45935]
simple_stmt [45921,45987]
===
match
---
name: dr [7810,7812]
name: dr [7810,7812]
===
match
---
simple_stmt [14322,14513]
simple_stmt [14322,14513]
===
match
---
suite [58922,58955]
suite [58974,59007]
===
match
---
return_stmt [4160,4198]
return_stmt [4160,4198]
===
match
---
import_from [60155,60195]
import_from [60207,60247]
===
match
---
name: state [7411,7416]
name: state [7411,7416]
===
match
---
funcdef [4201,4632]
funcdef [4201,4632]
===
match
---
name: mark_success [54110,54122]
name: mark_success [54162,54174]
===
match
---
operator: == [21632,21634]
operator: == [21632,21634]
===
match
---
argument [63958,63979]
argument [64010,64031]
===
match
---
operator: = [60596,60597]
operator: = [60648,60649]
===
match
---
operator: , [55130,55131]
operator: , [55182,55183]
===
match
---
simple_stmt [18755,18792]
simple_stmt [18755,18792]
===
match
---
name: self [73942,73946]
name: self [73994,73998]
===
match
---
operator: = [49799,49800]
operator: = [49851,49852]
===
match
---
atom [18531,18542]
atom [18531,18542]
===
match
---
name: Column [10127,10133]
name: Column [10127,10133]
===
match
---
simple_stmt [39481,39772]
simple_stmt [39481,39772]
===
match
---
except_clause [67431,67483]
except_clause [67483,67535]
===
match
---
name: dag_run [46017,46024]
name: dag_run [46069,46076]
===
match
---
name: ti [5988,5990]
name: ti [5988,5990]
===
match
---
trailer [23467,23483]
trailer [23467,23483]
===
match
---
name: warning [39939,39946]
name: warning [39939,39946]
===
match
---
name: self [74346,74350]
name: self [74398,74402]
===
match
---
suite [39873,40460]
suite [39873,40460]
===
match
---
operator: , [9780,9781]
operator: , [9780,9781]
===
match
---
suite [21856,22748]
suite [21856,22748]
===
match
---
name: instance [64674,64682]
name: instance [64726,64734]
===
match
---
import_from [2011,2055]
import_from [2011,2055]
===
match
---
atom_expr [61230,61249]
atom_expr [61282,61301]
===
match
---
simple_stmt [22003,22031]
simple_stmt [22003,22031]
===
match
---
name: task [23215,23219]
name: task [23215,23219]
===
match
---
return_stmt [80630,80649]
return_stmt [80682,80701]
===
match
---
operator: , [59589,59590]
operator: , [59641,59642]
===
match
---
name: defaultdict [5033,5044]
name: defaultdict [5033,5044]
===
match
---
simple_stmt [5500,5548]
simple_stmt [5500,5548]
===
match
---
atom_expr [39245,39271]
atom_expr [39245,39271]
===
match
---
funcdef [15434,18811]
funcdef [15434,18811]
===
match
---
if_stmt [56997,57064]
if_stmt [57049,57116]
===
match
---
trailer [39040,39046]
trailer [39040,39046]
===
match
---
name: timeout [51405,51412]
name: timeout [51457,51464]
===
match
---
simple_stmt [18686,18722]
simple_stmt [18686,18722]
===
match
---
name: task_id [62316,62323]
name: task_id [62368,62375]
===
match
---
name: try_number [8738,8748]
name: try_number [8738,8748]
===
match
---
trailer [20930,20932]
trailer [20930,20932]
===
match
---
atom_expr [50882,50897]
atom_expr [50934,50949]
===
match
---
name: self [50847,50851]
name: self [50899,50903]
===
match
---
trailer [11939,11954]
trailer [11939,11954]
===
match
---
trailer [72094,72101]
trailer [72146,72153]
===
match
---
atom_expr [9663,9682]
atom_expr [9663,9682]
===
match
---
simple_stmt [73017,73074]
simple_stmt [73069,73126]
===
match
---
name: e [44374,44375]
name: e [44426,44427]
===
match
---
name: ignore_task_deps [54022,54038]
name: ignore_task_deps [54074,54090]
===
match
---
simple_stmt [30989,31622]
simple_stmt [30989,31622]
===
match
---
operator: , [56424,56425]
operator: , [56476,56477]
===
match
---
name: conditions [7190,7200]
name: conditions [7190,7200]
===
match
---
trailer [82153,82162]
trailer [82205,82214]
===
match
---
operator: , [79080,79081]
operator: , [79132,79133]
===
match
---
suite [66540,67056]
suite [66592,67108]
===
match
---
operator: { [19073,19074]
operator: { [19073,19074]
===
match
---
string: """         Set TaskInstance state.          :param state: State to set for the TI         :type state: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [24395,24592]
string: """         Set TaskInstance state.          :param state: State to set for the TI         :type state: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [24395,24592]
===
match
---
string: 'end_date' [58616,58626]
string: 'end_date' [58668,58678]
===
match
---
name: on_success_callback [52897,52916]
name: on_success_callback [52949,52968]
===
match
---
simple_stmt [5285,5306]
simple_stmt [5285,5306]
===
match
---
name: List [1062,1066]
name: List [1062,1066]
===
match
---
operator: = [44709,44710]
operator: = [44761,44762]
===
match
---
argument [62540,62555]
argument [62592,62607]
===
match
---
fstring_end: ' [44976,44977]
fstring_end: ' [45028,45029]
===
match
---
atom_expr [5202,5216]
atom_expr [5202,5216]
===
match
---
arglist [10673,10727]
arglist [10673,10727]
===
match
---
operator: , [35732,35733]
operator: , [35732,35733]
===
match
---
name: local [15225,15230]
name: local [15225,15230]
===
match
---
arglist [45483,45499]
arglist [45535,45551]
===
match
---
name: context_to_airflow_vars [2633,2656]
name: context_to_airflow_vars [2633,2656]
===
match
---
atom_expr [74538,74563]
atom_expr [74590,74615]
===
match
---
operator: = [50898,50899]
operator: = [50950,50951]
===
match
---
simple_stmt [10311,10375]
simple_stmt [10311,10375]
===
match
---
name: ignore_ti_state [14157,14172]
name: ignore_ti_state [14157,14172]
===
match
---
operator: , [41413,41414]
operator: , [41382,41383]
===
match
---
param [15991,16022]
param [15991,16022]
===
match
---
atom_expr [60042,60062]
atom_expr [60094,60114]
===
match
---
atom [18150,18175]
atom [18150,18175]
===
match
---
name: priority_weight_total [23351,23372]
name: priority_weight_total [23351,23372]
===
match
---
name: DateTime [29789,29797]
name: DateTime [29789,29797]
===
match
---
trailer [58294,58299]
trailer [58346,58351]
===
match
---
atom_expr [22334,22346]
atom_expr [22334,22346]
===
match
---
operator: , [45389,45390]
operator: , [45441,45442]
===
match
---
trailer [37552,37568]
trailer [37552,37568]
===
match
---
trailer [71197,71214]
trailer [71249,71266]
===
match
---
name: task_id [19064,19071]
name: task_id [19064,19071]
===
match
---
name: state [10563,10568]
name: state [10563,10568]
===
match
---
import_from [1954,2010]
import_from [1954,2010]
===
match
---
operator: , [24295,24296]
operator: , [24295,24296]
===
match
---
operator: = [60317,60318]
operator: = [60369,60370]
===
match
---
name: pool_slots [22512,22522]
name: pool_slots [22512,22522]
===
match
---
name: get_failed_dep_statuses [32275,32298]
name: get_failed_dep_statuses [32275,32298]
===
match
---
name: task_id [80673,80680]
name: task_id [80725,80732]
===
match
---
operator: , [35857,35858]
operator: , [35857,35858]
===
match
---
atom_expr [60756,60768]
atom_expr [60808,60820]
===
match
---
name: task [25875,25879]
name: task [25875,25879]
===
match
---
operator: , [54495,54496]
operator: , [54547,54548]
===
match
---
name: render_templates [48783,48799]
name: render_templates [48835,48851]
===
match
---
funcdef [52271,53308]
funcdef [52323,53360]
===
match
---
name: run_id [65441,65447]
name: run_id [65493,65499]
===
match
---
name: max_tries [40602,40611]
name: max_tries [40602,40611]
===
match
---
simple_stmt [60155,60221]
simple_stmt [60207,60273]
===
match
---
param [80934,80938]
param [80986,80990]
===
match
---
name: log [39983,39986]
name: log [39983,39986]
===
match
---
atom_expr [19522,19555]
atom_expr [19522,19555]
===
match
---
trailer [82062,82238]
trailer [82114,82290]
===
match
---
classdef [63484,64472]
classdef [63536,64524]
===
match
---
atom_expr [18385,18425]
atom_expr [18385,18425]
===
match
---
simple_stmt [40625,40654]
simple_stmt [40625,40654]
===
match
---
name: ti [80531,80533]
name: ti [80583,80585]
===
match
---
name: task_id [79854,79861]
name: task_id [79906,79913]
===
match
---
name: pool_override [37485,37498]
name: pool_override [37485,37498]
===
match
---
operator: = [25880,25881]
operator: = [25880,25881]
===
match
---
name: execution_date [60335,60349]
name: execution_date [60387,60401]
===
match
---
atom_expr [32776,32793]
atom_expr [32776,32793]
===
match
---
return_stmt [32926,33017]
return_stmt [32926,33017]
===
match
---
string: "Marking success for %s on %s" [41167,41197]
string: "Marking success for %s on %s" [41136,41166]
===
match
---
tfpdef [59100,59125]
tfpdef [59152,59177]
===
match
---
trailer [52209,52213]
trailer [52261,52265]
===
match
---
name: is_eligible_to_retry [57811,57831]
name: is_eligible_to_retry [57863,57883]
===
match
---
operator: } [19717,19718]
operator: } [19717,19718]
===
match
---
string: '-' [61899,61902]
string: '-' [61951,61954]
===
match
---
atom_expr [6564,7139]
atom_expr [6564,7139]
===
match
---
name: error_fd [54311,54319]
name: error_fd [54363,54371]
===
match
---
operator: = [14218,14219]
operator: = [14218,14219]
===
match
---
comparison [79178,79215]
comparison [79230,79267]
===
match
---
name: primary_key [9593,9604]
name: primary_key [9593,9604]
===
match
---
name: dr [27288,27290]
name: dr [27288,27290]
===
match
---
return_stmt [79239,79486]
return_stmt [79291,79538]
===
match
---
decorated [15416,18811]
decorated [15416,18811]
===
match
---
name: self [24954,24958]
name: self [24954,24958]
===
match
---
operator: = [68096,68097]
operator: = [68148,68149]
===
match
---
operator: -> [41852,41854]
operator: -> [41821,41823]
===
match
---
operator: = [78341,78342]
operator: = [78393,78394]
===
match
---
name: _run_as_user [80261,80273]
name: _run_as_user [80313,80325]
===
match
---
argument [34621,34653]
argument [34621,34653]
===
match
---
atom_expr [52683,52710]
atom_expr [52735,52762]
===
match
---
suite [25404,26361]
suite [25404,26361]
===
match
---
atom_expr [47548,47629]
atom_expr [47600,47681]
===
match
---
atom_expr [48660,48682]
atom_expr [48712,48734]
===
match
---
operator: , [43933,43934]
operator: , [43985,43986]
===
match
---
trailer [45638,45647]
trailer [45690,45699]
===
match
---
name: pool_slots [23304,23314]
name: pool_slots [23304,23314]
===
match
---
simple_stmt [35135,35272]
simple_stmt [35135,35272]
===
match
---
operator: -> [73257,73259]
operator: -> [73309,73311]
===
match
---
annassign [80084,80100]
annassign [80136,80152]
===
match
---
name: first [35505,35510]
name: first [35505,35510]
===
match
---
suite [3096,3118]
suite [3096,3118]
===
match
---
atom_expr [40769,40779]
atom_expr [40769,40779]
===
match
---
arglist [51842,51875]
arglist [51894,51927]
===
match
---
name: make_aware [11829,11839]
name: make_aware [11829,11839]
===
match
---
name: log [24647,24650]
name: log [24647,24650]
===
match
---
strings [70148,70485]
strings [70200,70537]
===
match
---
name: state [65230,65235]
name: state [65282,65287]
===
match
---
dotted_name [66176,66207]
dotted_name [66228,66259]
===
match
---
name: self [26808,26812]
name: self [26808,26812]
===
match
---
atom_expr [16032,16041]
atom_expr [16032,16041]
===
match
---
dotted_name [45675,45695]
dotted_name [45727,45747]
===
match
---
expr_stmt [20520,20532]
expr_stmt [20520,20532]
===
match
---
trailer [71079,71087]
trailer [71131,71139]
===
match
---
name: e [66661,66662]
name: e [66713,66714]
===
match
---
atom_expr [44950,44962]
atom_expr [45002,45014]
===
match
---
arglist [41279,41331]
arglist [41248,41300]
===
match
---
param [3289,3305]
param [3289,3305]
===
match
---
simple_stmt [77330,77366]
simple_stmt [77382,77418]
===
match
---
string: '' [60005,60007]
string: '' [60057,60059]
===
match
---
string: """Return task instance primary key part of the key""" [8145,8199]
string: """Return task instance primary key part of the key""" [8145,8199]
===
match
---
simple_stmt [45467,45502]
simple_stmt [45519,45554]
===
match
---
trailer [49189,49193]
trailer [49241,49245]
===
match
---
tfpdef [53558,53579]
tfpdef [53610,53631]
===
match
---
trailer [12387,12397]
trailer [12387,12397]
===
match
---
funcdef [81320,81371]
funcdef [81372,81423]
===
match
---
arglist [44828,44863]
arglist [44880,44915]
===
match
---
name: info [55941,55945]
name: info [55993,55997]
===
match
---
decorator [81206,81216]
decorator [81258,81268]
===
match
---
atom_expr [24954,24967]
atom_expr [24954,24967]
===
match
---
param [53433,53463]
param [53485,53515]
===
match
---
name: self [13310,13314]
name: self [13310,13314]
===
match
---
tfpdef [15991,16014]
tfpdef [15991,16014]
===
match
---
atom_expr [39050,39073]
atom_expr [39050,39073]
===
match
---
simple_stmt [63113,63134]
simple_stmt [63165,63186]
===
match
---
name: session [59176,59183]
name: session [59228,59235]
===
match
---
operator: = [30972,30973]
operator: = [30972,30973]
===
match
---
name: NONE [39909,39913]
name: NONE [39909,39913]
===
match
---
trailer [79125,79129]
trailer [79177,79181]
===
match
---
name: dag [14652,14655]
name: dag [14652,14655]
===
match
---
trailer [4397,4408]
trailer [4397,4408]
===
match
---
name: provide_session [73080,73095]
name: provide_session [73132,73147]
===
match
---
trailer [18912,18927]
trailer [18912,18927]
===
match
---
atom_expr [10166,10185]
atom_expr [10166,10185]
===
match
---
comparison [79051,79080]
comparison [79103,79132]
===
match
---
name: tempfile [983,991]
name: tempfile [983,991]
===
match
---
trailer [43587,43948]
trailer [43639,44000]
===
match
---
operator: = [24756,24757]
operator: = [24756,24757]
===
match
---
name: force_fail [59142,59152]
name: force_fail [59194,59204]
===
match
---
operator: , [79607,79608]
operator: , [79659,79660]
===
match
---
atom_expr [48696,48763]
atom_expr [48748,48815]
===
match
---
operator: , [73057,73058]
operator: , [73109,73110]
===
match
---
name: executor_config [23491,23506]
name: executor_config [23491,23506]
===
match
---
trailer [4010,4015]
trailer [4010,4015]
===
match
---
simple_stmt [34836,34955]
simple_stmt [34836,34955]
===
match
---
name: ti [79765,79767]
name: ti [79817,79819]
===
match
---
name: session [58935,58942]
name: session [58987,58994]
===
match
---
string: 'scheduler' [45795,45806]
string: 'scheduler' [45847,45858]
===
match
---
atom_expr [31756,31770]
atom_expr [31756,31770]
===
match
---
arglist [55430,55631]
arglist [55482,55683]
===
match
---
trailer [80192,80197]
trailer [80244,80249]
===
match
---
operator: = [10207,10208]
operator: = [10207,10208]
===
match
---
simple_stmt [64481,66065]
simple_stmt [64533,66117]
===
match
---
name: max_tries [22322,22331]
name: max_tries [22322,22331]
===
match
---
name: bool [53611,53615]
name: bool [53663,53667]
===
match
---
decorated [81376,81449]
decorated [81428,81501]
===
match
---
trailer [58429,58436]
trailer [58481,58488]
===
match
---
dotted_name [1355,1369]
dotted_name [1355,1369]
===
match
---
trailer [33892,33903]
trailer [33892,33903]
===
match
---
simple_stmt [76932,77097]
simple_stmt [76984,77149]
===
match
---
trailer [47514,47531]
trailer [47566,47583]
===
match
---
name: self [35471,35475]
name: self [35471,35475]
===
match
---
decorated [30881,32245]
decorated [30881,32245]
===
match
---
name: airflow [2966,2973]
name: airflow [2966,2973]
===
match
---
name: dag_id [76383,76389]
name: dag_id [76435,76441]
===
match
---
expr_stmt [80256,80290]
expr_stmt [80308,80342]
===
match
---
param [80681,80685]
param [80733,80737]
===
match
---
operator: = [29730,29731]
operator: = [29730,29731]
===
match
---
atom_expr [58963,58979]
atom_expr [59015,59031]
===
match
---
expr_stmt [61866,61907]
expr_stmt [61918,61959]
===
match
---
import_from [2590,2656]
import_from [2590,2656]
===
match
---
simple_stmt [21963,21991]
simple_stmt [21963,21991]
===
match
---
arglist [82076,82228]
arglist [82128,82280]
===
match
---
trailer [42852,42894]
trailer [42904,42946]
===
match
---
for_stmt [5096,6077]
for_stmt [5096,6077]
===
match
---
simple_stmt [72057,72119]
simple_stmt [72109,72171]
===
match
---
trailer [74123,74138]
trailer [74175,74190]
===
match
---
name: timezone [11759,11767]
name: timezone [11759,11767]
===
match
---
atom_expr [24642,24704]
atom_expr [24642,24704]
===
match
---
tfpdef [51936,51952]
tfpdef [51988,52004]
===
match
---
funcdef [81558,82376]
funcdef [81610,82428]
===
match
---
atom_expr [61176,61195]
atom_expr [61228,61247]
===
match
---
name: Optional [56119,56127]
name: Optional [56171,56179]
===
match
---
name: str [80496,80499]
name: str [80548,80551]
===
match
---
name: dep_context [32445,32456]
name: dep_context [32445,32456]
===
match
---
name: state [65383,65388]
name: state [65435,65440]
===
match
---
operator: @ [30307,30308]
operator: @ [30307,30308]
===
match
---
param [13225,13230]
param [13225,13230]
===
match
---
atom_expr [9818,9833]
atom_expr [9818,9833]
===
match
---
operator: , [10720,10721]
operator: , [10720,10721]
===
match
---
name: _run_finished_callback [54763,54785]
name: _run_finished_callback [54815,54837]
===
match
---
string: '' [59694,59696]
string: '' [59746,59748]
===
match
---
atom_expr [58450,58462]
atom_expr [58502,58514]
===
match
---
trailer [78321,78324]
trailer [78373,78376]
===
match
---
name: default_html_content [69730,69750]
name: default_html_content [69782,69802]
===
match
---
trailer [39908,39913]
trailer [39908,39913]
===
match
---
name: session [50954,50961]
name: session [51006,51013]
===
match
---
name: create_pod_id [68528,68541]
name: create_pod_id [68580,68593]
===
match
---
operator: = [61476,61477]
operator: = [61528,61529]
===
match
---
name: max_tries [70922,70931]
name: max_tries [70974,70983]
===
match
---
trailer [3225,3235]
trailer [3225,3235]
===
match
---
trailer [42731,42738]
trailer [42700,42707]
===
match
---
argument [39817,39840]
argument [39817,39840]
===
match
---
name: add [57112,57115]
name: add [57164,57167]
===
match
---
name: dag [26786,26789]
name: dag [26786,26789]
===
match
---
string: "tasks" [17927,17934]
string: "tasks" [17927,17934]
===
match
---
operator: = [54791,54792]
operator: = [54843,54844]
===
match
---
trailer [22336,22346]
trailer [22336,22346]
===
match
---
operator: , [9789,9790]
operator: , [9789,9790]
===
match
---
operator: = [46126,46127]
operator: = [46178,46179]
===
match
---
operator: , [7058,7059]
operator: , [7058,7059]
===
match
---
operator: = [27057,27058]
operator: = [27057,27058]
===
match
---
operator: = [14193,14194]
operator: = [14193,14194]
===
match
---
name: pool [18555,18559]
name: pool [18555,18559]
===
match
---
simple_stmt [19130,19161]
simple_stmt [19130,19161]
===
match
---
operator: = [50858,50859]
operator: = [50910,50911]
===
match
---
trailer [11672,11674]
trailer [11672,11674]
===
match
---
trailer [58736,58748]
trailer [58788,58800]
===
match
---
name: _run_execute_callback [49553,49574]
name: _run_execute_callback [49605,49626]
===
match
---
name: State [77754,77759]
name: State [77806,77811]
===
match
---
trailer [81363,81370]
trailer [81415,81422]
===
match
---
funcdef [79746,80538]
funcdef [79798,80590]
===
match
---
suite [30390,30876]
suite [30390,30876]
===
match
---
name: self [57169,57173]
name: self [57221,57225]
===
match
---
name: Index [10579,10584]
name: Index [10579,10584]
===
match
---
return_stmt [80789,80816]
return_stmt [80841,80868]
===
match
---
atom_expr [27081,27100]
atom_expr [27081,27100]
===
match
---
atom_expr [5375,5396]
atom_expr [5375,5396]
===
match
---
operator: - [5544,5545]
operator: - [5544,5545]
===
match
---
name: start_date [38990,39000]
name: start_date [38990,39000]
===
match
---
simple_stmt [52727,52756]
simple_stmt [52779,52808]
===
match
---
argument [59246,59265]
argument [59298,59317]
===
match
---
import_from [2400,2442]
import_from [2400,2442]
===
match
---
name: task [52619,52623]
name: task [52671,52675]
===
match
---
atom_expr [18977,19015]
atom_expr [18977,19015]
===
match
---
name: self [21586,21590]
name: self [21586,21590]
===
match
---
import_name [1161,1185]
import_name [1161,1185]
===
match
---
simple_stmt [43451,43468]
simple_stmt [43503,43520]
===
match
---
arglist [74201,74395]
arglist [74253,74447]
===
match
---
fstring_end: " [14713,14714]
fstring_end: " [14713,14714]
===
match
---
simple_stmt [13798,13822]
simple_stmt [13798,13822]
===
match
---
name: first [78304,78309]
name: first [78356,78361]
===
match
---
name: state [26229,26234]
name: state [26229,26234]
===
match
---
atom_expr [7325,7385]
atom_expr [7325,7385]
===
match
---
suite [82267,82315]
suite [82319,82367]
===
match
---
name: self [23234,23238]
name: self [23234,23238]
===
match
---
param [56070,56099]
param [56122,56151]
===
match
---
name: str [80617,80620]
name: str [80669,80672]
===
match
---
argument [68707,68734]
argument [68759,68786]
===
match
---
name: result [77027,77033]
name: result [77079,77085]
===
match
---
atom_expr [20322,20334]
atom_expr [20322,20334]
===
match
---
expr_stmt [21825,21841]
expr_stmt [21825,21841]
===
match
---
name: TR [6794,6796]
name: TR [6794,6796]
===
match
---
name: refresh_from_db [43089,43104]
name: refresh_from_db [43141,43156]
===
match
---
expr_stmt [45016,45049]
expr_stmt [45068,45101]
===
match
---
funcdef [77820,77950]
funcdef [77872,78002]
===
match
---
name: force_fail [57888,57898]
name: force_fail [57940,57950]
===
match
---
argument [9443,9459]
argument [9443,9459]
===
match
---
operator: = [45849,45850]
operator: = [45901,45902]
===
match
---
fstring_string: dag. [48710,48714]
fstring_string: dag. [48762,48766]
===
match
---
fstring_start: f" [49284,49286]
fstring_start: f" [49336,49338]
===
match
---
name: self [20790,20794]
name: self [20790,20794]
===
match
---
arith_expr [13155,13175]
arith_expr [13155,13175]
===
match
---
atom_expr [44808,44864]
atom_expr [44860,44916]
===
match
---
suite [48358,48532]
suite [48410,48584]
===
match
---
parameters [15454,16028]
parameters [15454,16028]
===
match
---
name: executor_config [80141,80156]
name: executor_config [80193,80208]
===
match
---
name: render_template_fields [68145,68167]
name: render_template_fields [68197,68219]
===
match
---
operator: = [82600,82601]
operator: = [82652,82653]
===
match
---
atom_expr [7650,7659]
atom_expr [7650,7659]
===
match
---
simple_stmt [1449,1492]
simple_stmt [1449,1492]
===
match
---
atom_expr [35374,35512]
atom_expr [35374,35512]
===
match
---
atom_expr [18908,18939]
atom_expr [18908,18939]
===
match
---
operator: , [33865,33866]
operator: , [33865,33866]
===
match
---
atom_expr [5951,5961]
atom_expr [5951,5961]
===
match
---
operator: = [58148,58149]
operator: = [58200,58201]
===
match
---
simple_stmt [22359,22387]
simple_stmt [22359,22387]
===
match
---
name: debug [24065,24070]
name: debug [24065,24070]
===
match
---
name: incr [44918,44922]
name: incr [44970,44974]
===
match
---
operator: , [74138,74139]
operator: , [74190,74191]
===
match
---
try_stmt [67351,67590]
try_stmt [67403,67642]
===
match
---
tfpdef [79765,79781]
tfpdef [79817,79833]
===
match
---
expr_stmt [42564,42580]
expr_stmt [42533,42549]
===
match
---
name: session [54582,54589]
name: session [54634,54641]
===
match
---
and_test [37688,37763]
and_test [37688,37763]
===
match
---
param [30353,30357]
param [30353,30357]
===
match
---
name: set [5085,5088]
name: set [5085,5088]
===
match
---
param [41647,41674]
param [41616,41643]
===
match
---
operator: @ [50701,50702]
operator: @ [50753,50754]
===
match
---
atom_expr [49307,49335]
atom_expr [49359,49387]
===
match
---
arglist [50610,50659]
arglist [50662,50711]
===
match
---
operator: , [54427,54428]
operator: , [54479,54480]
===
match
---
number: 1000 [10141,10145]
number: 1000 [10141,10145]
===
match
---
trailer [24013,24020]
trailer [24013,24020]
===
match
---
operator: , [33851,33852]
operator: , [33851,33852]
===
match
---
name: isinstance [56408,56418]
name: isinstance [56460,56470]
===
match
---
name: context [3644,3651]
name: context [3644,3651]
===
match
---
name: TaskInstance [79335,79347]
name: TaskInstance [79387,79399]
===
match
---
operator: = [36017,36018]
operator: = [36017,36018]
===
match
---
name: state [29547,29552]
name: state [29547,29552]
===
match
---
operator: , [73216,73217]
operator: , [73268,73269]
===
match
---
name: AirflowSkipException [1732,1752]
name: AirflowSkipException [1732,1752]
===
match
---
trailer [44409,44411]
trailer [44461,44463]
===
match
---
trailer [32187,32224]
trailer [32187,32224]
===
match
---
trailer [49282,49337]
trailer [49334,49389]
===
match
---
name: self [31726,31730]
name: self [31726,31730]
===
match
---
operator: = [21014,21015]
operator: = [21014,21015]
===
match
---
name: prev_ds [61883,61890]
name: prev_ds [61935,61942]
===
match
---
suite [62985,63064]
suite [63037,63116]
===
match
---
name: execution_timeout [51423,51440]
name: execution_timeout [51475,51492]
===
match
---
trailer [71292,71309]
trailer [71344,71361]
===
match
---
annassign [39106,39170]
annassign [39106,39170]
===
match
---
operator: , [19253,19254]
operator: , [19253,19254]
===
match
---
operator: = [4006,4007]
operator: = [4006,4007]
===
match
---
name: params [62395,62401]
name: params [62447,62453]
===
match
---
expr_stmt [42727,42747]
expr_stmt [42696,42716]
===
match
---
operator: = [61722,61723]
operator: = [61774,61775]
===
match
---
fstring [67524,67581]
fstring [67576,67633]
===
match
---
simple_stmt [44808,44865]
simple_stmt [44860,44917]
===
match
---
operator: = [54320,54321]
operator: = [54372,54373]
===
match
---
trailer [61622,61631]
trailer [61674,61683]
===
match
---
name: sqlalchemy [1497,1507]
name: sqlalchemy [1497,1507]
===
match
---
trailer [80458,80474]
trailer [80510,80526]
===
match
---
operator: = [54517,54518]
operator: = [54569,54570]
===
match
---
name: exception [58843,58852]
name: exception [58895,58904]
===
match
---
fstring_end: " [19681,19682]
fstring_end: " [19681,19682]
===
match
---
name: last_dagrun [27812,27823]
name: last_dagrun [27812,27823]
===
match
---
name: UP_FOR_RETRY [25290,25302]
name: UP_FOR_RETRY [25290,25302]
===
match
---
param [64147,64157]
param [64199,64209]
===
match
---
trailer [60685,60688]
trailer [60737,60740]
===
match
---
operator: { [48714,48715]
operator: { [48766,48767]
===
match
---
suite [32855,32893]
suite [32855,32893]
===
match
---
name: SHUTDOWN [7425,7433]
name: SHUTDOWN [7425,7433]
===
match
---
operator: = [78424,78425]
operator: = [78476,78477]
===
match
---
atom_expr [3183,3196]
atom_expr [3183,3196]
===
match
---
suite [78171,78196]
suite [78223,78248]
===
match
---
operator: = [14040,14041]
operator: = [14040,14041]
===
match
---
name: params [60112,60118]
name: params [60164,60170]
===
match
---
name: Session [73235,73242]
name: Session [73287,73294]
===
match
---
operator: = [54226,54227]
operator: = [54278,54279]
===
match
---
name: set [74184,74187]
name: set [74236,74239]
===
match
---
name: self [45234,45238]
name: self [45286,45290]
===
match
---
name: dep_context [39481,39492]
name: dep_context [39481,39492]
===
match
---
param [55091,55109]
param [55143,55161]
===
match
---
trailer [11717,11728]
trailer [11717,11728]
===
match
---
arglist [53872,54235]
arglist [53924,54287]
===
match
---
name: self [18847,18851]
name: self [18847,18851]
===
match
---
operator: , [72379,72380]
operator: , [72431,72432]
===
match
---
name: value [13225,13230]
name: value [13225,13230]
===
match
---
name: v [49291,49292]
name: v [49343,49344]
===
match
---
simple_stmt [18948,19017]
simple_stmt [18948,19017]
===
match
---
simple_stmt [10078,10112]
simple_stmt [10078,10112]
===
match
---
argument [29554,29569]
argument [29554,29569]
===
match
---
expr_stmt [41434,41460]
expr_stmt [41403,41429]
===
match
---
trailer [23219,23225]
trailer [23219,23225]
===
match
---
name: count [25991,25996]
name: count [25991,25996]
===
match
---
name: dep_context [38497,38508]
name: dep_context [38497,38508]
===
match
---
name: timezone [35036,35044]
name: timezone [35036,35044]
===
match
---
name: t [78642,78643]
name: t [78694,78695]
===
match
---
trailer [61384,61388]
trailer [61436,61440]
===
match
---
name: self [20979,20983]
name: self [20979,20983]
===
match
---
trailer [52063,52083]
trailer [52115,52135]
===
match
---
trailer [19200,19210]
trailer [19200,19210]
===
match
---
argument [54097,54122]
argument [54149,54174]
===
match
---
operator: = [14236,14237]
operator: = [14236,14237]
===
match
---
atom_expr [5889,5901]
atom_expr [5889,5901]
===
match
---
trailer [18227,18258]
trailer [18227,18258]
===
match
---
tfpdef [41647,41665]
tfpdef [41616,41634]
===
match
---
name: debug [73026,73031]
name: debug [73078,73083]
===
match
---
name: in_ [7645,7648]
name: in_ [7645,7648]
===
match
---
param [29154,29178]
param [29154,29178]
===
match
---
trailer [22321,22331]
trailer [22321,22331]
===
match
---
trailer [8444,8521]
trailer [8444,8521]
===
match
---
name: session [27849,27856]
name: session [27849,27856]
===
match
---
trailer [67523,67582]
trailer [67575,67634]
===
match
---
argument [78945,79007]
argument [78997,79059]
===
match
---
simple_stmt [44912,44979]
simple_stmt [44964,45031]
===
match
---
operator: = [34719,34720]
operator: = [34719,34720]
===
match
---
operator: , [20983,20984]
operator: , [20983,20984]
===
match
---
operator: = [9759,9760]
operator: = [9759,9760]
===
match
---
name: DagRun [35388,35394]
name: DagRun [35388,35394]
===
match
---
operator: = [61664,61665]
operator: = [61716,61717]
===
match
---
operator: , [14178,14179]
operator: , [14178,14179]
===
match
---
operator: , [4235,4236]
operator: , [4235,4236]
===
match
---
trailer [18976,19016]
trailer [18976,19016]
===
match
---
atom_expr [22019,22030]
atom_expr [22019,22030]
===
match
---
param [51129,51134]
param [51181,51186]
===
match
---
trailer [58838,58842]
trailer [58890,58894]
===
match
---
param [14087,14110]
param [14087,14110]
===
match
---
trailer [68398,68400]
trailer [68450,68452]
===
match
---
fstring_end: " [67580,67581]
fstring_end: " [67632,67633]
===
match
---
import_from [2056,2109]
import_from [2056,2109]
===
match
---
name: log [21446,21449]
name: log [21446,21449]
===
match
---
trailer [22778,22784]
trailer [22778,22784]
===
match
---
trailer [38479,38581]
trailer [38479,38581]
===
match
---
argument [43501,43521]
argument [43553,43573]
===
match
---
atom_expr [55563,55576]
atom_expr [55615,55628]
===
match
---
simple_stmt [2590,2657]
simple_stmt [2590,2657]
===
match
---
name: start_date [72934,72944]
name: start_date [72986,72996]
===
match
---
name: executor_config [81472,81487]
name: executor_config [81524,81539]
===
match
---
param [73155,73166]
param [73207,73218]
===
match
---
fstring [19695,19719]
fstring [19695,19719]
===
match
---
or_test [32398,32425]
or_test [32398,32425]
===
match
---
name: state [54663,54668]
name: state [54715,54720]
===
match
---
name: next_ds [61438,61445]
name: next_ds [61490,61497]
===
match
---
simple_stmt [34086,34136]
simple_stmt [34086,34136]
===
match
---
operator: , [4708,4709]
operator: , [4708,4709]
===
match
---
name: setter [13193,13199]
name: setter [13193,13199]
===
match
---
atom_expr [82579,82599]
atom_expr [82631,82651]
===
match
---
trailer [37755,37763]
trailer [37755,37763]
===
match
---
operator: = [35358,35359]
operator: = [35358,35359]
===
match
---
operator: @ [41580,41581]
operator: @ [41549,41550]
===
match
---
atom_expr [73981,74169]
atom_expr [74033,74221]
===
match
---
trailer [6064,6076]
trailer [6064,6076]
===
match
---
simple_stmt [52946,52984]
simple_stmt [52998,53036]
===
match
---
atom_expr [78343,78355]
atom_expr [78395,78407]
===
match
---
name: __repr__ [32902,32910]
name: __repr__ [32902,32910]
===
match
---
atom_expr [62485,62556]
atom_expr [62537,62608]
===
match
---
trailer [41069,41071]
trailer [41038,41040]
===
match
---
name: self [21635,21639]
name: self [21635,21639]
===
match
---
operator: , [32097,32098]
operator: , [32097,32098]
===
match
---
testlist_comp [18151,18174]
testlist_comp [18151,18174]
===
match
---
funcdef [3850,4199]
funcdef [3850,4199]
===
match
---
trailer [11493,11639]
trailer [11493,11639]
===
match
---
simple_stmt [1547,1576]
simple_stmt [1547,1576]
===
match
---
trailer [49837,49852]
trailer [49889,49904]
===
match
---
name: get_previous_ti [26391,26406]
name: get_previous_ti [26391,26406]
===
match
---
trailer [70727,70734]
trailer [70779,70786]
===
match
---
name: add [6061,6064]
name: add [6061,6064]
===
match
---
simple_stmt [58834,58896]
simple_stmt [58886,58948]
===
match
---
operator: , [71949,71950]
operator: , [72001,72002]
===
match
---
name: error_file [44699,44709]
name: error_file [44751,44761]
===
match
---
operator: = [42770,42771]
operator: = [42739,42740]
===
match
---
name: set_duration [45414,45426]
name: set_duration [45466,45478]
===
match
---
dotted_name [2405,2424]
dotted_name [2405,2424]
===
match
---
name: Integer [1305,1312]
name: Integer [1305,1312]
===
match
---
trailer [10584,10623]
trailer [10584,10623]
===
match
---
testlist_comp [49284,49335]
testlist_comp [49336,49387]
===
match
---
operator: , [14223,14224]
operator: , [14223,14224]
===
match
---
operator: , [59541,59542]
operator: , [59593,59594]
===
match
---
expr_stmt [23234,23272]
expr_stmt [23234,23272]
===
match
---
atom_expr [80796,80816]
atom_expr [80848,80868]
===
match
---
fstring_string: ti.finish. [44925,44935]
fstring_string: ti.finish. [44977,44987]
===
match
---
return_stmt [8667,8749]
return_stmt [8667,8749]
===
match
---
operator: = [54109,54110]
operator: = [54161,54162]
===
match
---
operator: { [42864,42865]
operator: { [42916,42917]
===
match
---
name: job_id [37630,37636]
name: job_id [37630,37636]
===
match
---
tfpdef [41716,41737]
tfpdef [41685,41706]
===
match
---
trailer [40601,40611]
trailer [40601,40611]
===
match
---
name: str [69477,69480]
name: str [69529,69532]
===
match
---
import_from [2490,2546]
import_from [2490,2546]
===
match
---
name: date [41476,41480]
name: date [41445,41449]
===
match
---
atom_expr [59862,59871]
atom_expr [59914,59923]
===
match
---
atom_expr [72064,72118]
atom_expr [72116,72170]
===
match
---
operator: @ [28502,28503]
operator: @ [28502,28503]
===
match
---
name: task_id [8233,8240]
name: task_id [8233,8240]
===
match
---
parameters [8546,8569]
parameters [8546,8569]
===
match
---
trailer [55703,55721]
trailer [55755,55773]
===
match
---
trailer [61565,61577]
trailer [61617,61629]
===
match
---
string: "task_instance" [9390,9405]
string: "task_instance" [9390,9405]
===
match
---
atom_expr [77702,77714]
atom_expr [77754,77766]
===
match
---
operator: = [67253,67254]
operator: = [67305,67306]
===
match
---
atom_expr [19045,19056]
atom_expr [19045,19056]
===
match
---
name: State [43152,43157]
name: State [43204,43209]
===
match
---
trailer [40508,40513]
trailer [40508,40513]
===
match
---
trailer [68139,68144]
trailer [68191,68196]
===
match
---
name: signal [48548,48554]
name: signal [48600,48606]
===
match
---
simple_stmt [24937,25003]
simple_stmt [24937,25003]
===
match
---
atom_expr [8472,8491]
atom_expr [8472,8491]
===
match
---
arglist [38497,38567]
arglist [38497,38567]
===
match
---
name: task_ids [6893,6901]
name: task_ids [6893,6901]
===
match
---
trailer [56082,56098]
trailer [56134,56150]
===
match
---
name: stacklevel [28435,28445]
name: stacklevel [28435,28445]
===
match
---
trailer [7038,7040]
trailer [7038,7040]
===
match
---
param [59543,59553]
param [59595,59605]
===
match
---
atom_expr [50860,50873]
atom_expr [50912,50925]
===
match
---
name: statement [47907,47916]
name: statement [47959,47968]
===
match
---
trailer [20484,20487]
trailer [20484,20487]
===
match
---
name: session [47989,47996]
name: session [48041,48048]
===
match
---
trailer [45521,45527]
trailer [45573,45579]
===
match
---
atom_expr [26335,26359]
atom_expr [26335,26359]
===
match
---
simple_stmt [19222,19267]
simple_stmt [19222,19267]
===
match
---
arglist [41167,41229]
arglist [41136,41198]
===
match
---
string: "--local" [18532,18541]
string: "--local" [18532,18541]
===
match
---
trailer [41768,41773]
trailer [41737,41742]
===
match
---
trailer [50908,50915]
trailer [50960,50967]
===
match
---
name: qry [82022,82025]
name: qry [82074,82077]
===
match
---
trailer [55293,55300]
trailer [55345,55352]
===
match
---
trailer [66595,66597]
trailer [66647,66649]
===
match
---
if_stmt [18730,18792]
if_stmt [18730,18792]
===
match
---
name: task_tries [7013,7023]
name: task_tries [7013,7023]
===
match
---
name: str [3154,3157]
name: str [3154,3157]
===
match
---
test [60431,60466]
test [60483,60518]
===
match
---
expr_stmt [49788,49852]
expr_stmt [49840,49904]
===
match
---
simple_stmt [32145,32158]
simple_stmt [32145,32158]
===
match
---
name: self [49838,49842]
name: self [49890,49894]
===
match
---
name: dag_id [82089,82095]
name: dag_id [82141,82147]
===
match
---
parameters [67086,67092]
parameters [67138,67144]
===
match
---
operator: , [3775,3776]
operator: , [3775,3776]
===
match
---
name: set_duration [72780,72792]
name: set_duration [72832,72844]
===
match
---
name: kube_config [68977,68988]
name: kube_config [69029,69040]
===
match
---
trailer [40901,40907]
trailer [40870,40876]
===
match
---
simple_stmt [8208,8262]
simple_stmt [8208,8262]
===
match
---
name: isoformat [17889,17898]
name: isoformat [17889,17898]
===
match
---
name: task [60079,60083]
name: task [60131,60135]
===
match
---
name: pool [15955,15959]
name: pool [15955,15959]
===
match
---
operator: , [69504,69505]
operator: , [69556,69557]
===
match
---
if_stmt [39187,39272]
if_stmt [39187,39272]
===
match
---
string: "--job-id" [18151,18161]
string: "--job-id" [18151,18161]
===
match
---
name: verbose [31743,31750]
name: verbose [31743,31750]
===
match
---
name: session [45639,45646]
name: session [45691,45698]
===
match
---
trailer [68976,69007]
trailer [69028,69059]
===
match
---
operator: , [44769,44770]
operator: , [44821,44822]
===
match
---
name: ti [20482,20484]
name: ti [20482,20484]
===
match
---
suite [64045,64083]
suite [64097,64135]
===
match
---
operator: , [65997,65998]
operator: , [66049,66050]
===
match
---
simple_stmt [32577,32813]
simple_stmt [32577,32813]
===
match
---
operator: , [29144,29145]
operator: , [29144,29145]
===
match
---
operator: == [20319,20321]
operator: == [20319,20321]
===
match
---
name: session [54219,54226]
name: session [54271,54278]
===
match
---
operator: , [73145,73146]
operator: , [73197,73198]
===
match
---
name: Exception [4255,4264]
name: Exception [4255,4264]
===
match
---
trailer [82306,82312]
trailer [82358,82364]
===
match
---
param [73123,73128]
param [73175,73180]
===
match
---
atom_expr [24758,24773]
atom_expr [24758,24773]
===
match
---
expr_stmt [35355,35522]
expr_stmt [35355,35522]
===
match
---
string: '' [62267,62269]
string: '' [62319,62321]
===
match
---
name: pool_slots [9986,9996]
name: pool_slots [9986,9996]
===
match
---
name: self [52298,52302]
name: self [52350,52354]
===
match
---
simple_stmt [37777,37818]
simple_stmt [37777,37818]
===
match
---
param [15615,15645]
param [15615,15645]
===
match
---
atom_expr [41760,41773]
atom_expr [41729,41742]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.         """ [30399,30546]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.         """ [30399,30546]
===
match
---
name: self [72793,72797]
name: self [72845,72849]
===
match
---
string: """Get Airflow Variable value""" [63375,63407]
string: """Get Airflow Variable value""" [63427,63459]
===
match
---
param [4673,4681]
param [4673,4681]
===
match
---
expr_stmt [69412,69451]
expr_stmt [69464,69503]
===
match
---
simple_stmt [19511,19556]
simple_stmt [19511,19556]
===
match
---
name: iso [17868,17871]
name: iso [17868,17871]
===
match
---
decorator [29041,29058]
decorator [29041,29058]
===
match
---
string: "&downstream=false" [19762,19781]
string: "&downstream=false" [19762,19781]
===
match
---
simple_stmt [23381,23417]
simple_stmt [23381,23417]
===
match
---
trailer [54370,54384]
trailer [54422,54436]
===
match
---
name: get_templated_fields [66310,66330]
name: get_templated_fields [66362,66382]
===
match
---
trailer [44812,44827]
trailer [44864,44879]
===
match
---
suite [67996,68177]
suite [68048,68229]
===
match
---
operator: , [41637,41638]
operator: , [41606,41607]
===
match
---
param [51930,51935]
param [51982,51987]
===
match
---
operator: = [54963,54964]
operator: = [55015,55016]
===
match
---
expr_stmt [22359,22386]
expr_stmt [22359,22386]
===
match
---
param [35788,35819]
param [35788,35819]
===
match
---
name: ignore_all_deps [38225,38240]
name: ignore_all_deps [38225,38240]
===
match
---
name: html_content [72664,72676]
name: html_content [72716,72728]
===
match
---
name: self [81586,81590]
name: self [81638,81642]
===
match
---
atom_expr [37513,37527]
atom_expr [37513,37527]
===
match
---
trailer [27080,27101]
trailer [27080,27101]
===
match
---
expr_stmt [46571,46823]
expr_stmt [46623,46875]
===
match
---
atom_expr [55269,55282]
atom_expr [55321,55334]
===
match
---
operator: , [49582,49583]
operator: , [49634,49635]
===
match
---
atom [18013,18031]
atom [18013,18031]
===
match
---
atom_expr [39227,39242]
atom_expr [39227,39242]
===
match
---
name: replace [69492,69499]
name: replace [69544,69551]
===
match
---
name: end_date [9652,9660]
name: end_date [9652,9660]
===
match
---
name: DagRun [35416,35422]
name: DagRun [35416,35422]
===
match
---
operator: , [55108,55109]
operator: , [55160,55161]
===
match
---
name: provide_session [23552,23567]
name: provide_session [23552,23567]
===
match
---
arglist [9428,9478]
arglist [9428,9478]
===
match
---
name: UP_FOR_RETRY [58156,58168]
name: UP_FOR_RETRY [58208,58220]
===
match
---
operator: { [19713,19714]
operator: { [19713,19714]
===
match
---
name: DagRun [7511,7517]
name: DagRun [7511,7517]
===
match
---
simple_stmt [60016,60031]
simple_stmt [60068,60083]
===
match
---
simple_stmt [54953,54975]
simple_stmt [55005,55027]
===
match
---
subscriptlist [74544,74562]
subscriptlist [74596,74614]
===
match
---
name: session [32323,32330]
name: session [32323,32330]
===
match
---
atom [7558,7797]
atom [7558,7797]
===
match
---
operator: = [22658,22659]
operator: = [22658,22659]
===
match
---
tfpdef [24360,24370]
tfpdef [24360,24370]
===
match
---
trailer [27828,27848]
trailer [27828,27848]
===
match
---
trailer [27218,27274]
trailer [27218,27274]
===
match
---
name: execution_date [79400,79414]
name: execution_date [79452,79466]
===
match
---
atom_expr [66686,67048]
atom_expr [66738,67100]
===
match
---
trailer [30036,30042]
trailer [30036,30042]
===
match
---
name: Stats [50669,50674]
name: Stats [50721,50726]
===
match
---
operator: @ [26366,26367]
operator: @ [26366,26367]
===
match
---
atom_expr [29021,29034]
atom_expr [29021,29034]
===
match
---
param [59176,59189]
param [59228,59241]
===
match
---
arglist [26040,26271]
arglist [26040,26271]
===
match
---
name: _executor_config [81515,81531]
name: _executor_config [81567,81583]
===
match
---
operator: , [41706,41707]
operator: , [41675,41676]
===
match
---
name: self [44212,44216]
name: self [44264,44268]
===
match
---
trailer [32468,32473]
trailer [32468,32473]
===
match
---
trailer [60130,60134]
trailer [60182,60186]
===
match
---
param [30951,30964]
param [30951,30964]
===
match
---
name: TemplateAssertionError [67439,67461]
name: TemplateAssertionError [67491,67513]
===
match
---
atom_expr [43427,43433]
atom_expr [43479,43485]
===
match
---
simple_stmt [18217,18259]
simple_stmt [18217,18259]
===
match
---
name: session [54227,54234]
name: session [54279,54286]
===
match
---
operator: = [15598,15599]
operator: = [15598,15599]
===
match
---
name: html_content [71227,71239]
name: html_content [71279,71291]
===
match
---
operator: , [68857,68858]
operator: , [68909,68910]
===
match
---
import_from [7263,7304]
import_from [7263,7304]
===
match
---
operator: @ [29041,29042]
operator: @ [29041,29042]
===
match
---
name: task_id [47228,47235]
name: task_id [47280,47287]
===
match
---
arglist [71891,71903]
arglist [71943,71955]
===
match
---
expr_stmt [55848,55869]
expr_stmt [55900,55921]
===
match
---
trailer [60118,60125]
trailer [60170,60177]
===
match
---
operator: , [81590,81591]
operator: , [81642,81643]
===
match
---
operator: { [19315,19316]
operator: { [19315,19316]
===
match
---
trailer [20487,20493]
trailer [20487,20493]
===
match
---
name: task [33294,33298]
name: task [33294,33298]
===
match
---
trailer [12123,12136]
trailer [12123,12136]
===
match
---
operator: , [14305,14306]
operator: , [14305,14306]
===
match
---
suite [63096,63134]
suite [63148,63186]
===
match
---
name: error [54792,54797]
name: error [54844,54849]
===
match
---
name: utcnow [56854,56860]
name: utcnow [56906,56912]
===
match
---
name: commit [45551,45557]
name: commit [45603,45609]
===
match
---
name: Context [51945,51952]
name: Context [51997,52004]
===
match
---
trailer [49193,49198]
trailer [49245,49250]
===
match
---
operator: -= [55865,55867]
operator: -= [55917,55919]
===
match
---
name: run_id [60439,60445]
name: run_id [60491,60497]
===
match
---
name: dep [32438,32441]
name: dep [32438,32441]
===
match
---
arglist [32531,32557]
arglist [32531,32557]
===
match
---
if_stmt [41120,41333]
if_stmt [41089,41302]
===
match
---
name: execution_date [9556,9570]
name: execution_date [9556,9570]
===
match
---
operator: = [53252,53253]
operator: = [53304,53305]
===
match
---
operator: -> [30359,30361]
operator: -> [30359,30361]
===
match
---
name: downstream_task_ids [26118,26137]
name: downstream_task_ids [26118,26137]
===
match
---
operator: = [59761,59762]
operator: = [59813,59814]
===
match
---
operator: , [1289,1290]
operator: , [1289,1290]
===
match
---
name: task_id [76967,76974]
name: task_id [77019,77026]
===
match
---
trailer [80714,80723]
trailer [80766,80775]
===
match
---
simple_stmt [67699,67744]
simple_stmt [67751,67796]
===
match
---
operator: = [32396,32397]
operator: = [32396,32397]
===
match
---
simple_stmt [66118,66163]
simple_stmt [66170,66215]
===
match
---
testlist_comp [44760,44788]
testlist_comp [44812,44840]
===
match
---
name: execution_date [78816,78830]
name: execution_date [78868,78882]
===
match
---
name: _executor_config [80114,80130]
name: _executor_config [80166,80182]
===
match
---
operator: , [3982,3983]
operator: , [3982,3983]
===
match
---
arglist [41409,41419]
arglist [41378,41388]
===
match
---
name: sqlalchemy [1399,1409]
name: sqlalchemy [1399,1409]
===
match
---
atom_expr [42727,42738]
atom_expr [42696,42707]
===
match
---
atom_expr [47447,47469]
atom_expr [47499,47521]
===
match
---
simple_stmt [57104,57185]
simple_stmt [57156,57237]
===
match
---
name: str [41733,41736]
name: str [41702,41705]
===
match
---
operator: , [46804,46805]
operator: , [46856,46857]
===
match
---
atom_expr [37645,37658]
atom_expr [37645,37658]
===
match
---
name: dag [46595,46598]
name: dag [46647,46650]
===
match
---
name: str [4616,4619]
name: str [4616,4619]
===
match
---
if_stmt [76893,77366]
if_stmt [76945,77418]
===
match
---
string: '%Y-%m-%d' [60573,60583]
string: '%Y-%m-%d' [60625,60635]
===
match
---
name: ti [22741,22743]
name: ti [22741,22743]
===
match
---
argument [44842,44863]
argument [44894,44915]
===
match
---
name: ti [79467,79469]
name: ti [79519,79521]
===
match
---
operator: = [81599,81600]
operator: = [81651,81652]
===
match
---
argument [76524,76531]
argument [76576,76583]
===
match
---
simple_stmt [59996,60008]
simple_stmt [60048,60060]
===
match
---
name: ti [5248,5250]
name: ti [5248,5250]
===
match
---
name: _update_ti_state_for_sensing [50308,50336]
name: _update_ti_state_for_sensing [50360,50388]
===
match
---
fstring [44923,44977]
fstring [44975,45029]
===
match
---
param [35974,36001]
param [35974,36001]
===
match
---
parameters [35094,35125]
parameters [35094,35125]
===
match
---
name: session [76665,76672]
name: session [76717,76724]
===
match
---
trailer [5502,5512]
trailer [5502,5512]
===
match
---
operator: = [13258,13259]
operator: = [13258,13259]
===
match
---
arglist [19531,19554]
arglist [19531,19554]
===
match
---
trailer [22058,22064]
trailer [22058,22064]
===
match
---
name: self [41199,41203]
name: self [41168,41172]
===
match
---
suite [13232,13266]
suite [13232,13266]
===
match
---
name: State [54672,54677]
name: State [54724,54729]
===
match
---
atom_expr [24970,24985]
atom_expr [24970,24985]
===
match
---
simple_stmt [79022,79231]
simple_stmt [79074,79283]
===
match
---
name: qry [21830,21833]
name: qry [21830,21833]
===
match
---
trailer [51777,51790]
trailer [51829,51842]
===
match
---
atom_expr [71456,71483]
atom_expr [71508,71535]
===
match
---
operator: } [62307,62308]
operator: } [62359,62360]
===
match
---
atom_expr [64405,64471]
atom_expr [64457,64523]
===
match
---
comp_op [52917,52923]
comp_op [52969,52975]
===
match
---
atom_expr [77575,77587]
atom_expr [77627,77639]
===
match
---
dotted_name [1620,1638]
dotted_name [1620,1638]
===
match
---
operator: , [45839,45840]
operator: , [45891,45892]
===
match
---
operator: -> [3885,3887]
operator: -> [3885,3887]
===
match
---
name: all [78941,78944]
name: all [78993,78996]
===
match
---
trailer [73063,73072]
trailer [73115,73124]
===
match
---
trailer [25979,25985]
trailer [25979,25985]
===
match
---
simple_stmt [8422,8522]
simple_stmt [8422,8522]
===
match
---
name: dag [61385,61388]
name: dag [61437,61440]
===
match
---
name: session [37569,37576]
name: session [37569,37576]
===
match
---
name: init_run_context [77824,77840]
name: init_run_context [77876,77892]
===
match
---
atom_expr [60733,60790]
atom_expr [60785,60842]
===
match
---
decorator [30307,30317]
decorator [30307,30317]
===
match
---
name: query [20189,20194]
name: query [20189,20194]
===
match
---
arglist [7631,7754]
arglist [7631,7754]
===
match
---
atom_expr [45467,45501]
atom_expr [45519,45553]
===
match
---
name: self [29103,29107]
name: self [29103,29107]
===
match
---
trailer [55328,55330]
trailer [55380,55382]
===
match
---
suite [4466,4632]
suite [4466,4632]
===
match
---
import_from [2237,2287]
import_from [2237,2287]
===
match
---
trailer [78892,78900]
trailer [78944,78952]
===
match
---
operator: , [26202,26203]
operator: , [26202,26203]
===
match
---
operator: = [63811,63812]
operator: = [63863,63864]
===
match
---
name: net [2566,2569]
name: net [2566,2569]
===
match
---
trailer [77056,77082]
trailer [77108,77134]
===
match
---
string: '\n' [49273,49277]
string: '\n' [49325,49329]
===
match
---
operator: , [60333,60334]
operator: , [60385,60386]
===
match
---
name: provide_session [29042,29057]
name: provide_session [29042,29057]
===
match
---
expr_stmt [24937,25002]
expr_stmt [24937,25002]
===
match
---
suite [54629,54799]
suite [54681,54851]
===
match
---
name: self [63779,63783]
name: self [63831,63835]
===
match
---
name: self [19045,19049]
name: self [19045,19049]
===
match
---
operator: = [46978,46979]
operator: = [47030,47031]
===
match
---
number: 2 [30798,30799]
number: 2 [30798,30799]
===
match
---
name: bool [74676,74680]
name: bool [74728,74732]
===
match
---
name: self [42681,42685]
name: self [42650,42654]
===
match
---
trailer [10857,11022]
trailer [10857,11022]
===
match
---
decorated [80822,80902]
decorated [80874,80954]
===
match
---
simple_stmt [77926,77950]
simple_stmt [77978,78002]
===
match
---
trailer [23801,23807]
trailer [23801,23807]
===
match
---
comparison [78642,78660]
comparison [78694,78712]
===
match
---
atom_expr [9421,9479]
atom_expr [9421,9479]
===
match
---
simple_stmt [44212,44235]
simple_stmt [44264,44287]
===
match
---
expr_stmt [42756,42786]
expr_stmt [42725,42755]
===
match
---
simple_stmt [1576,1615]
simple_stmt [1576,1615]
===
match
---
name: self [45209,45213]
name: self [45261,45265]
===
match
---
name: autoescape [71100,71110]
name: autoescape [71152,71162]
===
match
---
simple_stmt [18002,18033]
simple_stmt [18002,18033]
===
match
---
string: "\n" [37914,37918]
string: "\n" [37914,37918]
===
match
---
atom_expr [22003,22016]
atom_expr [22003,22016]
===
match
---
suite [49645,50339]
suite [49697,50391]
===
match
---
suite [6100,7238]
suite [6100,7238]
===
match
---
testlist_comp [18585,18599]
testlist_comp [18585,18599]
===
match
---
operator: -> [68212,68214]
operator: -> [68264,68266]
===
match
---
expr_stmt [10190,10224]
expr_stmt [10190,10224]
===
match
---
trailer [60387,60393]
trailer [60439,60445]
===
match
---
atom_expr [51655,51689]
atom_expr [51707,51741]
===
match
---
string: 'subject_template' [72149,72167]
string: 'subject_template' [72201,72219]
===
match
---
name: exception [71561,71570]
name: exception [71613,71622]
===
match
---
operator: -> [36030,36032]
operator: -> [36030,36032]
===
match
---
name: command_as_list [13951,13966]
name: command_as_list [13951,13966]
===
match
---
param [54816,54820]
param [54868,54872]
===
match
---
name: execution_date [68679,68693]
name: execution_date [68731,68745]
===
match
---
name: max_retry_delay [34680,34695]
name: max_retry_delay [34680,34695]
===
match
---
operator: , [54205,54206]
operator: , [54257,54258]
===
match
---
name: bytes [3877,3882]
name: bytes [3877,3882]
===
match
---
name: ti_key_str [65547,65557]
name: ti_key_str [65599,65609]
===
match
---
trailer [18149,18176]
trailer [18149,18176]
===
match
---
name: context [50462,50469]
name: context [50514,50521]
===
match
---
name: result [51646,51652]
name: result [51698,51704]
===
match
---
name: self [44247,44251]
name: self [44299,44303]
===
match
---
simple_stmt [1874,1909]
simple_stmt [1874,1909]
===
match
---
simple_stmt [63375,63408]
simple_stmt [63427,63460]
===
match
---
name: context [51514,51521]
name: context [51566,51573]
===
match
---
name: Any [1041,1044]
name: Any [1041,1044]
===
match
---
name: str [81101,81104]
name: str [81153,81156]
===
match
---
decorator [81454,81464]
decorator [81506,81516]
===
match
---
arith_expr [40597,40615]
arith_expr [40597,40615]
===
match
---
parameters [22877,22909]
parameters [22877,22909]
===
match
---
trailer [10005,10041]
trailer [10005,10041]
===
match
---
param [81398,81402]
param [81450,81454]
===
match
---
name: task_copy [51578,51587]
name: task_copy [51630,51639]
===
match
---
name: State [7844,7849]
name: State [7844,7849]
===
match
---
atom_expr [53100,53109]
atom_expr [53152,53161]
===
match
---
name: self [23983,23987]
name: self [23983,23987]
===
match
---
atom_expr [53674,53687]
atom_expr [53726,53739]
===
match
---
atom_expr [9628,9647]
atom_expr [9628,9647]
===
match
---
trailer [74111,74118]
trailer [74163,74170]
===
match
---
operator: , [15981,15982]
operator: , [15981,15982]
===
match
---
name: extend [18470,18476]
name: extend [18470,18476]
===
match
---
name: self [24937,24941]
name: self [24937,24941]
===
match
---
fstring_string: .duration [48752,48761]
fstring_string: .duration [48804,48813]
===
match
---
name: provide_session [29646,29661]
name: provide_session [29646,29661]
===
match
---
parameters [72432,72449]
parameters [72484,72501]
===
match
---
trailer [19334,19342]
trailer [19334,19342]
===
match
---
string: '%Y-%m-%d' [61566,61576]
string: '%Y-%m-%d' [61618,61628]
===
match
---
atom_expr [44063,44138]
atom_expr [44115,44190]
===
match
---
simple_stmt [71776,71817]
simple_stmt [71828,71869]
===
match
---
string: "started running, please use 'airflow tasks render' for debugging the " [66907,66978]
string: "started running, please use 'airflow tasks render' for debugging the " [66959,67030]
===
match
---
name: job [82501,82504]
name: job [82553,82556]
===
match
---
operator: @ [24319,24320]
operator: @ [24319,24320]
===
match
---
simple_stmt [68135,68177]
simple_stmt [68187,68229]
===
match
---
simple_stmt [74745,76372]
simple_stmt [74797,76424]
===
match
---
operator: = [62531,62532]
operator: = [62583,62584]
===
match
---
name: bool [53536,53540]
name: bool [53588,53592]
===
match
---
if_stmt [77305,77366]
if_stmt [77357,77418]
===
match
---
param [71846,71853]
param [71898,71905]
===
match
---
simple_stmt [82378,82398]
simple_stmt [82430,82450]
===
match
---
atom_expr [21919,21934]
atom_expr [21919,21934]
===
match
---
operator: , [39656,39657]
operator: , [39656,39657]
===
match
---
import_as_names [1652,1810]
import_as_names [1652,1810]
===
match
---
expr_stmt [76411,76431]
expr_stmt [76463,76483]
===
match
---
trailer [54559,54564]
trailer [54611,54616]
===
match
---
name: task_id [14936,14943]
name: task_id [14936,14943]
===
match
---
expr_stmt [37616,37636]
expr_stmt [37616,37636]
===
match
---
operator: = [53417,53418]
operator: = [53469,53470]
===
match
---
simple_stmt [57916,57985]
simple_stmt [57968,58037]
===
match
---
expr_stmt [55269,55302]
expr_stmt [55321,55354]
===
match
---
param [81488,81492]
param [81540,81544]
===
match
---
trailer [5475,5483]
trailer [5475,5483]
===
match
---
simple_stmt [805,820]
simple_stmt [805,820]
===
match
---
name: provide_session [35548,35563]
name: provide_session [35548,35563]
===
match
---
atom_expr [61666,61704]
atom_expr [61718,61756]
===
match
---
param [67681,67688]
param [67733,67740]
===
match
---
name: ignore_task_deps [39674,39690]
name: ignore_task_deps [39674,39690]
===
match
---
operator: , [8456,8457]
operator: , [8456,8457]
===
match
---
argument [48889,48896]
argument [48941,48948]
===
match
---
operator: = [76664,76665]
operator: = [76716,76717]
===
match
---
name: iso [19714,19717]
name: iso [19714,19717]
===
match
---
name: _run_execute_callback [51908,51929]
name: _run_execute_callback [51960,51981]
===
match
---
operator: = [59255,59256]
operator: = [59307,59308]
===
match
---
decorator [13827,13837]
decorator [13827,13837]
===
match
---
simple_stmt [55253,55260]
simple_stmt [55305,55312]
===
match
---
argument [76604,76643]
argument [76656,76695]
===
match
---
name: logging [827,834]
name: logging [827,834]
===
match
---
name: on_success_callback [53005,53024]
name: on_success_callback [53057,53076]
===
match
---
name: send_email [2432,2442]
name: send_email [2432,2442]
===
match
---
suite [28574,29036]
suite [28574,29036]
===
match
---
atom_expr [22613,22631]
atom_expr [22613,22631]
===
match
---
string: '%Y-%m-%d' [60779,60789]
string: '%Y-%m-%d' [60831,60841]
===
match
---
operator: = [76490,76491]
operator: = [76542,76543]
===
match
---
simple_stmt [60479,60501]
simple_stmt [60531,60553]
===
match
---
string: "-" [37922,37925]
string: "-" [37922,37925]
===
match
---
dotted_name [1399,1413]
dotted_name [1399,1413]
===
match
---
simple_stmt [72816,72838]
simple_stmt [72868,72890]
===
match
---
name: task_id [47089,47096]
name: task_id [47141,47148]
===
match
---
param [41383,41387]
param [41352,41356]
===
match
---
param [48073,48077]
param [48125,48129]
===
match
---
raise_stmt [48477,48531]
raise_stmt [48529,48583]
===
match
---
name: instance [61951,61959]
name: instance [62003,62011]
===
match
---
except_clause [52143,52159]
except_clause [52195,52211]
===
match
---
name: start_date [39232,39242]
name: start_date [39232,39242]
===
match
---
simple_stmt [48088,48121]
simple_stmt [48140,48173]
===
match
---
name: execution_date [78364,78378]
name: execution_date [78416,78430]
===
match
---
name: dagrun [45889,45895]
name: dagrun [45941,45947]
===
match
---
operator: == [26060,26062]
operator: == [26060,26062]
===
match
---
atom_expr [14931,14943]
atom_expr [14931,14943]
===
match
---
atom_expr [77561,77804]
atom_expr [77613,77856]
===
match
---
param [53666,53695]
param [53718,53747]
===
match
---
name: or_ [6564,6567]
name: or_ [6564,6567]
===
match
---
name: deps [39523,39527]
name: deps [39523,39527]
===
match
---
param [35828,35858]
param [35828,35858]
===
match
---
string: 'Exception:<br>{{exception_html}}<br>' [69829,69867]
string: 'Exception:<br>{{exception_html}}<br>' [69881,69919]
===
match
---
funcdef [8527,8750]
funcdef [8527,8750]
===
match
---
trailer [26765,26770]
trailer [26765,26770]
===
match
---
operator: | [32462,32463]
operator: | [32462,32463]
===
match
---
atom_expr [29449,29501]
atom_expr [29449,29501]
===
match
---
trailer [71985,71991]
trailer [72037,72043]
===
match
---
simple_stmt [2961,3015]
simple_stmt [2961,3015]
===
match
---
name: strftime [61557,61565]
name: strftime [61609,61617]
===
match
---
atom_expr [56811,56820]
atom_expr [56863,56872]
===
match
---
operator: = [30093,30094]
operator: = [30093,30094]
===
match
---
name: String [9856,9862]
name: String [9856,9862]
===
match
---
simple_stmt [11178,11206]
simple_stmt [11178,11206]
===
match
---
atom_expr [68633,68655]
atom_expr [68685,68707]
===
match
---
funcdef [33023,34796]
funcdef [33023,34796]
===
match
---
number: 1 [5546,5547]
number: 1 [5546,5547]
===
match
---
operator: , [65417,65418]
operator: , [65469,65470]
===
match
---
atom_expr [60598,60629]
atom_expr [60650,60681]
===
match
---
if_stmt [60039,60530]
if_stmt [60091,60582]
===
match
---
atom_expr [51578,51597]
atom_expr [51630,51649]
===
match
---
expr_stmt [12383,12405]
expr_stmt [12383,12405]
===
match
---
trailer [39168,39170]
trailer [39168,39170]
===
match
---
operator: @ [13827,13828]
operator: @ [13827,13828]
===
match
---
expr_stmt [5940,5961]
expr_stmt [5940,5961]
===
match
---
param [53740,53753]
param [53792,53805]
===
match
---
trailer [21528,21542]
trailer [21528,21542]
===
match
---
trailer [24717,24723]
trailer [24717,24723]
===
match
---
trailer [7164,7174]
trailer [7164,7174]
===
match
---
name: sentry [2184,2190]
name: sentry [2184,2190]
===
match
---
name: task_id [20327,20334]
name: task_id [20327,20334]
===
match
---
funcdef [19385,19792]
funcdef [19385,19792]
===
match
---
simple_stmt [26755,26775]
simple_stmt [26755,26775]
===
match
---
name: dag_id [78349,78355]
name: dag_id [78401,78407]
===
match
---
name: self [45358,45362]
name: self [45410,45414]
===
match
---
name: dag_id [24254,24260]
name: dag_id [24254,24260]
===
match
---
atom_expr [61607,61631]
atom_expr [61659,61683]
===
match
---
name: start_date [57157,57167]
name: start_date [57209,57219]
===
match
---
param [19406,19410]
param [19406,19410]
===
match
---
name: lazy_object_proxy [65305,65322]
name: lazy_object_proxy [65357,65374]
===
match
---
simple_stmt [18300,18338]
simple_stmt [18300,18338]
===
match
---
name: dag_id [10555,10561]
name: dag_id [10555,10561]
===
match
---
expr_stmt [78334,78355]
expr_stmt [78386,78407]
===
match
---
trailer [20872,20879]
trailer [20872,20879]
===
match
---
name: Column [10054,10060]
name: Column [10054,10060]
===
match
---
name: verbose [53872,53879]
name: verbose [53924,53931]
===
match
---
name: Optional [41760,41768]
name: Optional [41729,41737]
===
match
---
atom_expr [67962,67979]
atom_expr [68014,68031]
===
match
---
suite [44899,44979]
suite [44951,45031]
===
match
---
name: file_path [18710,18719]
name: file_path [18710,18719]
===
match
---
import_from [1909,1953]
import_from [1909,1953]
===
match
---
name: exc [1366,1369]
name: exc [1366,1369]
===
match
---
trailer [45794,45855]
trailer [45846,45907]
===
match
---
param [4664,4668]
param [4664,4668]
===
match
---
trailer [50674,50679]
trailer [50726,50731]
===
match
---
name: pool [54518,54522]
name: pool [54570,54574]
===
match
---
name: and_ [79263,79267]
name: and_ [79315,79319]
===
match
---
name: ignore_ti_state [15196,15211]
name: ignore_ti_state [15196,15211]
===
match
---
trailer [61234,61249]
trailer [61286,61301]
===
match
---
comp_op [51802,51808]
comp_op [51854,51860]
===
match
---
string: '-' [62262,62265]
string: '-' [62314,62317]
===
match
---
simple_stmt [64324,64382]
simple_stmt [64376,64434]
===
match
---
suite [18054,18108]
suite [18054,18108]
===
match
---
operator: , [39593,39594]
operator: , [39593,39594]
===
match
---
trailer [41810,41815]
trailer [41779,41784]
===
match
---
simple_stmt [67372,67419]
simple_stmt [67424,67471]
===
match
---
trailer [77359,77365]
trailer [77411,77417]
===
match
---
name: task_reschedule [39245,39260]
name: task_reschedule [39245,39260]
===
match
---
except_clause [44166,44198]
except_clause [44218,44250]
===
match
---
name: error [20799,20804]
name: error [20799,20804]
===
match
---
trailer [80053,80064]
trailer [80105,80116]
===
match
---
operator: , [25388,25389]
operator: , [25388,25389]
===
match
---
trailer [77601,77608]
trailer [77653,77660]
===
match
---
name: pool [22490,22494]
name: pool [22490,22494]
===
match
---
name: end_date [80010,80018]
name: end_date [80062,80070]
===
match
---
trailer [65229,65250]
trailer [65281,65302]
===
match
---
name: include_downstream [46686,46704]
name: include_downstream [46738,46756]
===
match
---
trailer [47556,47561]
trailer [47608,47613]
===
match
---
subscriptlist [79592,79612]
subscriptlist [79644,79664]
===
match
---
name: outlets [64932,64939]
name: outlets [64984,64991]
===
match
---
simple_stmt [68088,68126]
simple_stmt [68140,68178]
===
match
---
simple_stmt [4043,4055]
simple_stmt [4043,4055]
===
match
---
operator: , [24358,24359]
operator: , [24358,24359]
===
match
---
trailer [79131,79146]
trailer [79183,79198]
===
match
---
name: dag_id [6019,6025]
name: dag_id [6019,6025]
===
match
---
trailer [26228,26234]
trailer [26228,26234]
===
match
---
name: mark_success [54097,54109]
name: mark_success [54149,54161]
===
match
---
trailer [57810,57831]
trailer [57862,57883]
===
match
---
atom_expr [65305,65417]
atom_expr [65357,65469]
===
match
---
name: self [28474,28478]
name: self [28474,28478]
===
match
---
name: dep_context [2258,2269]
name: dep_context [2258,2269]
===
match
---
name: key [71900,71903]
name: key [71952,71955]
===
match
---
trailer [62004,62012]
trailer [62056,62064]
===
match
---
name: parse [1115,1120]
name: parse [1115,1120]
===
match
---
operator: } [7673,7674]
operator: } [7673,7674]
===
match
---
name: task_id [11198,11205]
name: task_id [11198,11205]
===
match
---
name: is_premature [25054,25066]
name: is_premature [25054,25066]
===
match
---
trailer [58480,58491]
trailer [58532,58543]
===
match
---
name: failed [31881,31887]
name: failed [31881,31887]
===
match
---
operator: = [49166,49167]
operator: = [49218,49219]
===
match
---
name: email_for_state [58667,58682]
name: email_for_state [58719,58734]
===
match
---
name: execution_date [73175,73189]
name: execution_date [73227,73241]
===
match
---
parameters [64038,64044]
parameters [64090,64096]
===
match
---
simple_stmt [2657,2700]
simple_stmt [2657,2700]
===
match
---
name: params [59952,59958]
name: params [60004,60010]
===
match
---
simple_stmt [50535,50590]
simple_stmt [50587,50642]
===
match
---
trailer [61556,61565]
trailer [61608,61617]
===
match
---
not_test [32833,32854]
not_test [32833,32854]
===
match
---
trailer [26026,26281]
trailer [26026,26281]
===
match
---
parameters [55084,55162]
parameters [55136,55214]
===
match
---
name: self [62938,62942]
name: self [62990,62994]
===
match
---
operator: = [22903,22904]
operator: = [22903,22904]
===
match
---
operator: , [77431,77432]
operator: , [77483,77484]
===
match
---
atom_expr [80356,80369]
atom_expr [80408,80421]
===
match
---
name: session [76657,76664]
name: session [76709,76716]
===
match
---
operator: == [20380,20382]
operator: == [20380,20382]
===
match
---
atom_expr [77037,77082]
atom_expr [77089,77134]
===
match
---
trailer [26260,26268]
trailer [26260,26268]
===
match
---
name: prev_ds_nodash [61866,61880]
name: prev_ds_nodash [61918,61932]
===
match
---
name: state [26422,26427]
name: state [26422,26427]
===
match
---
atom_expr [52547,52557]
atom_expr [52599,52609]
===
match
---
simple_stmt [13116,13140]
simple_stmt [13116,13140]
===
match
---
simple_stmt [4386,4409]
simple_stmt [4386,4409]
===
match
---
name: render_templates [67930,67946]
name: render_templates [67982,67998]
===
match
---
trailer [27848,27878]
trailer [27848,27878]
===
match
---
atom_expr [52819,52829]
atom_expr [52871,52881]
===
match
---
arglist [72638,72676]
arglist [72690,72728]
===
match
---
name: Optional [29124,29132]
name: Optional [29124,29132]
===
match
---
trailer [59664,59673]
trailer [59716,59725]
===
match
---
operator: , [15060,15061]
operator: , [15060,15061]
===
match
---
name: execution_date [11403,11417]
name: execution_date [11403,11417]
===
match
---
name: airflow [68278,68285]
name: airflow [68330,68337]
===
match
---
name: ti [80276,80278]
name: ti [80328,80330]
===
match
---
name: queued_dttm [10152,10163]
name: queued_dttm [10152,10163]
===
match
---
parameters [19835,19855]
parameters [19835,19855]
===
match
---
simple_stmt [56537,56565]
simple_stmt [56589,56617]
===
match
---
suite [56520,56565]
suite [56572,56617]
===
match
---
simple_stmt [59855,59872]
simple_stmt [59907,59924]
===
match
---
trailer [60300,60310]
trailer [60352,60362]
===
match
---
funcdef [62905,63064]
funcdef [62957,63116]
===
match
---
name: utcnow [50909,50915]
name: utcnow [50961,50967]
===
match
---
name: hostname [22364,22372]
name: hostname [22364,22372]
===
match
---
atom_expr [59111,59125]
atom_expr [59163,59177]
===
match
---
fstring_end: ' [42892,42893]
fstring_end: ' [42944,42945]
===
match
---
name: _CURRENT_CONTEXT [3165,3181]
name: _CURRENT_CONTEXT [3165,3181]
===
match
---
trailer [80077,80084]
trailer [80129,80136]
===
match
---
name: property [12597,12605]
name: property [12597,12605]
===
match
---
atom_expr [10209,10224]
atom_expr [10209,10224]
===
match
---
name: dag_id [6616,6622]
name: dag_id [6616,6622]
===
match
---
name: job_ids [7246,7253]
name: job_ids [7246,7253]
===
match
---
suite [4360,4632]
suite [4360,4632]
===
match
---
arglist [72727,72769]
arglist [72779,72821]
===
match
---
name: self [55269,55273]
name: self [55321,55325]
===
match
---
name: pod_template_file [68989,69006]
name: pod_template_file [69041,69058]
===
match
---
simple_stmt [22231,22305]
simple_stmt [22231,22305]
===
match
---
name: min_backoff [34124,34135]
name: min_backoff [34124,34135]
===
match
---
name: DagRun [82615,82621]
name: DagRun [82667,82673]
===
match
---
funcdef [13285,13822]
funcdef [13285,13822]
===
match
---
name: self [12092,12096]
name: self [12092,12096]
===
match
---
atom_expr [72849,72862]
atom_expr [72901,72914]
===
match
---
name: cmd [18686,18689]
name: cmd [18686,18689]
===
match
---
atom_expr [47905,47916]
atom_expr [47957,47968]
===
match
---
name: jinja_context [71497,71510]
name: jinja_context [71549,71562]
===
match
---
name: log [23798,23801]
name: log [23798,23801]
===
match
---
name: test_mode [44128,44137]
name: test_mode [44180,44189]
===
match
---
param [56056,56061]
param [56108,56113]
===
match
---
atom_expr [72627,72677]
atom_expr [72679,72729]
===
match
---
name: execution_date [20365,20379]
name: execution_date [20365,20379]
===
match
---
name: priority_weight [80459,80474]
name: priority_weight [80511,80526]
===
match
---
name: session [23598,23605]
name: session [23598,23605]
===
match
---
param [48316,48321]
param [48368,48373]
===
match
---
name: self [49939,49943]
name: self [49991,49995]
===
match
---
name: rendered_value [66511,66525]
name: rendered_value [66563,66577]
===
match
---
simple_stmt [2547,2590]
simple_stmt [2547,2590]
===
match
---
name: provide_session [53314,53329]
name: provide_session [53366,53381]
===
match
---
name: one [46278,46281]
name: one [46330,46333]
===
match
---
operator: @ [20938,20939]
operator: @ [20938,20939]
===
match
---
name: next_retry_datetime [33027,33046]
name: next_retry_datetime [33027,33046]
===
match
---
name: email [72648,72653]
name: email [72700,72705]
===
match
---
name: test_mode [65589,65598]
name: test_mode [65641,65650]
===
match
---
name: dag_run [47494,47501]
name: dag_run [47546,47553]
===
match
---
number: 1000 [9899,9903]
number: 1000 [9899,9903]
===
match
---
operator: , [49300,49301]
operator: , [49352,49353]
===
match
---
name: self [52819,52823]
name: self [52871,52875]
===
match
---
argument [71198,71213]
argument [71250,71265]
===
match
---
annassign [80130,80156]
annassign [80182,80208]
===
match
---
trailer [65322,65328]
trailer [65374,65380]
===
match
---
simple_stmt [7407,7434]
simple_stmt [7407,7434]
===
match
---
trailer [54942,54944]
trailer [54994,54996]
===
match
---
or_test [22525,22543]
or_test [22525,22543]
===
match
---
import_as_names [2787,2814]
import_as_names [2787,2814]
===
match
---
name: strftime [61833,61841]
name: strftime [61885,61893]
===
match
---
name: self [48892,48896]
name: self [48944,48948]
===
match
---
atom_expr [69083,69126]
atom_expr [69135,69178]
===
match
---
expr_stmt [38113,38434]
expr_stmt [38113,38434]
===
match
---
trailer [33814,33933]
trailer [33814,33933]
===
match
---
return_stmt [59454,59516]
return_stmt [59506,59568]
===
match
---
name: get_previous_execution_date [65202,65229]
name: get_previous_execution_date [65254,65281]
===
match
---
name: state [34975,34980]
name: state [34975,34980]
===
match
---
return_stmt [81432,81448]
return_stmt [81484,81500]
===
match
---
atom_expr [28994,29035]
atom_expr [28994,29035]
===
match
---
name: prev_ti [30241,30248]
name: prev_ti [30241,30248]
===
match
---
funcdef [48013,50696]
funcdef [48065,50748]
===
match
---
simple_stmt [58935,58955]
simple_stmt [58987,59007]
===
match
---
name: render [72298,72304]
name: render [72350,72356]
===
match
---
name: ID_LEN [9435,9441]
name: ID_LEN [9435,9441]
===
match
---
simple_stmt [4999,5012]
simple_stmt [4999,5012]
===
match
---
simple_stmt [20854,20880]
simple_stmt [20854,20880]
===
match
---
expr_stmt [56347,56373]
expr_stmt [56399,56425]
===
match
---
name: COLLATION_ARGS [9445,9459]
name: COLLATION_ARGS [9445,9459]
===
match
---
simple_stmt [57847,57873]
simple_stmt [57899,57925]
===
match
---
name: merge [45522,45527]
name: merge [45574,45579]
===
match
---
operator: -> [16029,16031]
operator: -> [16029,16031]
===
match
---
arglist [62144,62151]
arglist [62196,62203]
===
match
---
name: __tablename__ [9374,9387]
name: __tablename__ [9374,9387]
===
match
---
name: TaskInstance [77732,77744]
name: TaskInstance [77784,77796]
===
match
---
name: timezone [42816,42824]
name: timezone [42868,42876]
===
match
---
name: self [40325,40329]
name: self [40325,40329]
===
match
---
name: task_id [21640,21647]
name: task_id [21640,21647]
===
match
---
string: 'tomorrow_ds_nodash' [65676,65696]
string: 'tomorrow_ds_nodash' [65728,65748]
===
match
---
trailer [49574,49589]
trailer [49626,49641]
===
match
---
arglist [27961,27990]
arglist [27961,27990]
===
match
---
atom_expr [64004,64012]
atom_expr [64056,64064]
===
match
---
operator: ** [33643,33645]
operator: ** [33643,33645]
===
match
---
name: create_pod_id [68332,68345]
name: create_pod_id [68384,68397]
===
match
---
simple_stmt [80073,80101]
simple_stmt [80125,80153]
===
match
---
name: Stats [37777,37782]
name: Stats [37777,37782]
===
match
---
return_stmt [28467,28496]
return_stmt [28467,28496]
===
match
---
name: task_id [82138,82145]
name: task_id [82190,82197]
===
match
---
simple_stmt [63802,63818]
simple_stmt [63854,63870]
===
match
---
name: getpid [40818,40824]
name: getpid [42778,42784]
===
match
---
param [15579,15606]
param [15579,15606]
===
match
---
atom_expr [21979,21990]
atom_expr [21979,21990]
===
match
---
trailer [80009,80018]
trailer [80061,80070]
===
match
---
operator: , [73165,73166]
operator: , [73217,73218]
===
match
---
operator: { [62310,62311]
operator: { [62362,62363]
===
match
---
trailer [56935,56945]
trailer [56987,56997]
===
match
---
testlist_comp [26240,26268]
testlist_comp [26240,26268]
===
match
---
tfpdef [41683,41698]
tfpdef [41652,41667]
===
match
---
operator: = [30797,30798]
operator: = [30797,30798]
===
match
---
param [77841,77846]
param [77893,77898]
===
match
---
operator: , [10939,10940]
operator: , [10939,10940]
===
match
---
trailer [9862,9868]
trailer [9862,9868]
===
match
---
name: TR [3119,3121]
name: TR [3119,3121]
===
match
---
or_test [24758,24789]
or_test [24758,24789]
===
match
---
atom_expr [26152,26179]
atom_expr [26152,26179]
===
match
---
funcdef [77392,77815]
funcdef [77444,77867]
===
match
---
fstring_start: f" [62293,62295]
fstring_start: f" [62345,62347]
===
match
---
comparison [77678,77714]
comparison [77730,77766]
===
match
---
atom_expr [22660,22671]
atom_expr [22660,22671]
===
match
---
atom_expr [54953,54962]
atom_expr [55005,55014]
===
match
---
operator: , [65447,65448]
operator: , [65499,65500]
===
match
---
name: handle_failure [56032,56046]
name: handle_failure [56084,56098]
===
match
---
simple_stmt [25413,25867]
simple_stmt [25413,25867]
===
match
---
name: self [58949,58953]
name: self [59001,59005]
===
match
---
name: Session [35110,35117]
name: Session [35110,35117]
===
match
---
expr_stmt [10046,10073]
expr_stmt [10046,10073]
===
match
---
expr_stmt [26290,26306]
expr_stmt [26290,26306]
===
match
---
trailer [78666,78681]
trailer [78718,78733]
===
match
---
trailer [64413,64417]
trailer [64465,64469]
===
match
---
name: e [67578,67579]
name: e [67630,67631]
===
match
---
operator: = [15637,15638]
operator: = [15637,15638]
===
match
---
atom_expr [59658,59678]
atom_expr [59710,59730]
===
match
---
operator: = [14683,14684]
operator: = [14683,14684]
===
match
---
trailer [59232,59306]
trailer [59284,59358]
===
match
---
atom_expr [44389,44411]
atom_expr [44441,44463]
===
match
---
parameters [45738,45758]
parameters [45790,45810]
===
match
---
name: dag_id [32956,32962]
name: dag_id [32956,32962]
===
match
---
fstring_expr [19315,19320]
fstring_expr [19315,19320]
===
match
---
atom_expr [39890,39900]
atom_expr [39890,39900]
===
match
---
atom_expr [35416,35429]
atom_expr [35416,35429]
===
match
---
operator: , [20280,20281]
operator: , [20280,20281]
===
match
---
dotted_name [82493,82513]
dotted_name [82545,82565]
===
match
---
name: BaseJob [7339,7346]
name: BaseJob [7339,7346]
===
match
---
atom_expr [14631,14648]
atom_expr [14631,14648]
===
match
---
operator: = [5949,5950]
operator: = [5949,5950]
===
match
---
atom_expr [79130,79146]
atom_expr [79182,79198]
===
match
---
trailer [18576,18583]
trailer [18576,18583]
===
match
---
argument [46120,46138]
argument [46172,46190]
===
match
---
name: self [72638,72642]
name: self [72690,72694]
===
match
---
trailer [13094,13102]
trailer [13094,13102]
===
match
---
operator: , [21647,21648]
operator: , [21647,21648]
===
match
---
operator: , [71580,71581]
operator: , [71632,71633]
===
match
---
operator: = [23484,23485]
operator: = [23484,23485]
===
match
---
string: "airflow.task" [11306,11320]
string: "airflow.task" [11306,11320]
===
match
---
simple_stmt [32926,33018]
simple_stmt [32926,33018]
===
match
---
operator: , [15399,15400]
operator: , [15399,15400]
===
match
---
trailer [41316,41331]
trailer [41285,41300]
===
match
---
name: test_mode [53633,53642]
name: test_mode [53685,53694]
===
match
---
trailer [49810,49837]
trailer [49862,49889]
===
match
---
arglist [44267,44319]
arglist [44319,44371]
===
match
---
operator: @ [15416,15417]
operator: @ [15416,15417]
===
match
---
trailer [35011,35031]
trailer [35011,35031]
===
match
---
arglist [46120,46199]
arglist [46172,46251]
===
match
---
atom_expr [9885,9905]
atom_expr [9885,9905]
===
match
---
name: conf [67915,67919]
name: conf [67967,67971]
===
match
---
atom_expr [23346,23372]
atom_expr [23346,23372]
===
match
---
name: task [11226,11230]
name: task [11226,11230]
===
match
---
operator: ** [9443,9445]
operator: ** [9443,9445]
===
match
---
name: strftime [59665,59673]
name: strftime [59717,59725]
===
match
---
param [59554,59557]
param [59606,59609]
===
match
---
name: self [44965,44969]
name: self [45017,45021]
===
match
---
name: self [56811,56815]
name: self [56863,56867]
===
match
---
param [62938,62943]
param [62990,62995]
===
match
---
operator: , [65047,65048]
operator: , [65099,65100]
===
match
---
suite [76398,76432]
suite [76450,76484]
===
match
---
operator: , [82227,82228]
operator: , [82279,82280]
===
match
---
name: self [67667,67671]
name: self [67719,67723]
===
match
---
name: RUNNING [7850,7857]
name: RUNNING [7850,7857]
===
match
---
expr_stmt [22399,22426]
expr_stmt [22399,22426]
===
match
---
param [20590,20595]
param [20590,20595]
===
match
---
name: deps [38171,38175]
name: deps [38171,38175]
===
match
---
name: str [63204,63207]
name: str [63256,63259]
===
match
---
trailer [18640,18651]
trailer [18640,18651]
===
match
---
name: test_mode [42606,42615]
name: test_mode [42575,42584]
===
match
---
name: error [4620,4625]
name: error [4620,4625]
===
match
---
string: '-' [62204,62207]
string: '-' [62256,62259]
===
match
---
not_test [14573,14586]
not_test [14573,14586]
===
match
---
atom_expr [73059,73072]
atom_expr [73111,73124]
===
match
---
expr_stmt [58019,58058]
expr_stmt [58071,58110]
===
match
---
trailer [72085,72094]
trailer [72137,72146]
===
match
---
trailer [49955,50156]
trailer [50007,50208]
===
match
---
operator: = [10271,10272]
operator: = [10271,10272]
===
match
---
string: "DagModel" [10867,10877]
string: "DagModel" [10867,10877]
===
match
---
operator: = [33600,33601]
operator: = [33600,33601]
===
match
---
name: error_file [4220,4230]
name: error_file [4220,4230]
===
match
---
name: base_url [19222,19230]
name: base_url [19222,19230]
===
match
---
trailer [5378,5387]
trailer [5378,5387]
===
match
---
atom_expr [68881,68911]
atom_expr [68933,68963]
===
match
---
atom_expr [78734,78929]
atom_expr [78786,78981]
===
match
---
simple_stmt [82488,82529]
simple_stmt [82540,82581]
===
match
---
fstring_expr [19044,19057]
fstring_expr [19044,19057]
===
match
---
arglist [60311,60369]
arglist [60363,60421]
===
match
---
name: _prepare_and_execute_task_with_callbacks [43016,43056]
name: _prepare_and_execute_task_with_callbacks [43068,43108]
===
match
---
simple_stmt [35280,35346]
simple_stmt [35280,35346]
===
match
---
name: default_var [63462,63473]
name: default_var [63514,63525]
===
match
---
simple_stmt [787,805]
simple_stmt [787,805]
===
match
---
operator: , [67951,67952]
operator: , [68003,68004]
===
match
---
trailer [50865,50873]
trailer [50917,50925]
===
match
---
name: TaskReschedule [3124,3138]
name: TaskReschedule [3124,3138]
===
match
---
number: 1 [50658,50659]
number: 1 [50710,50711]
===
match
---
operator: = [23244,23245]
operator: = [23244,23245]
===
match
---
operator: = [54200,54201]
operator: = [54252,54253]
===
match
---
simple_stmt [48371,48433]
simple_stmt [48423,48485]
===
match
---
name: send_email [72716,72726]
name: send_email [72768,72778]
===
match
---
name: warnings [892,900]
name: warnings [892,900]
===
match
---
fstring_expr [49286,49289]
fstring_expr [49338,49341]
===
match
---
name: session [5974,5981]
name: session [5974,5981]
===
match
---
name: self [40835,40839]
name: self [40804,40808]
===
match
---
expr_stmt [61737,61758]
expr_stmt [61789,61810]
===
match
---
name: DeprecationWarning [28923,28941]
name: DeprecationWarning [28923,28941]
===
match
---
operator: , [28941,28942]
operator: , [28941,28942]
===
match
---
return_stmt [20541,20553]
return_stmt [20541,20553]
===
match
---
atom_expr [3208,3235]
atom_expr [3208,3235]
===
match
---
trailer [52223,52265]
trailer [52275,52317]
===
match
---
operator: = [15002,15003]
operator: = [15002,15003]
===
match
---
operator: = [27223,27224]
operator: = [27223,27224]
===
match
---
trailer [27611,27629]
trailer [27611,27629]
===
match
---
name: duration [73064,73072]
name: duration [73116,73124]
===
match
---
name: mark_success [41647,41659]
name: mark_success [41616,41628]
===
match
---
comparison [21611,21647]
comparison [21611,21647]
===
match
---
atom_expr [5191,5199]
atom_expr [5191,5199]
===
match
---
tfpdef [26451,26467]
tfpdef [26451,26467]
===
match
---
argument [46686,46710]
argument [46738,46762]
===
match
---
operator: , [74233,74234]
operator: , [74285,74286]
===
match
---
if_stmt [18434,18490]
if_stmt [18434,18490]
===
match
---
operator: } [62336,62337]
operator: } [62388,62389]
===
match
---
name: are_dependencies_met [39796,39816]
name: are_dependencies_met [39796,39816]
===
match
---
param [55149,55161]
param [55201,55213]
===
match
---
suite [43214,43263]
suite [43266,43315]
===
match
---
operator: = [53185,53186]
operator: = [53237,53238]
===
match
---
name: first [60388,60393]
name: first [60440,60445]
===
match
---
funcdef [73100,74406]
funcdef [73152,74458]
===
match
---
operator: , [41197,41198]
operator: , [41166,41167]
===
match
---
operator: = [11156,11157]
operator: = [11156,11157]
===
match
---
number: 80 [37928,37930]
number: 80 [37928,37930]
===
match
---
name: airflow [1581,1588]
name: airflow [1581,1588]
===
match
---
name: ignore_depends_on_past [39634,39656]
name: ignore_depends_on_past [39634,39656]
===
match
---
name: task_id_by_key [5016,5030]
name: task_id_by_key [5016,5030]
===
match
---
atom_expr [7720,7737]
atom_expr [7720,7737]
===
match
---
name: quote [1128,1133]
name: quote [1128,1133]
===
match
---
trailer [11305,11321]
trailer [11305,11321]
===
match
---
trailer [18927,18937]
trailer [18927,18937]
===
match
---
name: task [11219,11223]
name: task [11219,11223]
===
match
---
simple_stmt [58239,58277]
simple_stmt [58291,58329]
===
match
---
trailer [18981,18985]
trailer [18981,18985]
===
match
---
param [53558,53588]
param [53610,53640]
===
match
---
name: tis [78910,78913]
name: tis [78962,78965]
===
match
---
name: html_content_err [72753,72769]
name: html_content_err [72805,72821]
===
match
---
trailer [40385,40391]
trailer [40385,40391]
===
match
---
tfpdef [41754,41773]
tfpdef [41723,41742]
===
match
---
trailer [68678,68693]
trailer [68730,68745]
===
match
---
trailer [58604,58615]
trailer [58656,58667]
===
match
---
name: run_as_user [23405,23416]
name: run_as_user [23405,23416]
===
match
---
operator: @ [19797,19798]
operator: @ [19797,19798]
===
match
---
name: session [39842,39849]
name: session [39842,39849]
===
match
---
operator: , [41780,41781]
operator: , [41749,41750]
===
match
---
name: value [73155,73160]
name: value [73207,73212]
===
match
---
name: kube_config [68633,68644]
name: kube_config [68685,68696]
===
match
---
name: with_row_locks [46027,46041]
name: with_row_locks [46079,46093]
===
match
---
decorator [80729,80739]
decorator [80781,80791]
===
match
---
atom_expr [25270,25280]
atom_expr [25270,25280]
===
match
---
name: _try_number [80032,80043]
name: _try_number [80084,80095]
===
match
---
name: lock_for_update [81606,81621]
name: lock_for_update [81658,81673]
===
match
---
name: Stats [42842,42847]
name: Stats [42894,42899]
===
match
---
simple_stmt [59880,59907]
simple_stmt [59932,59959]
===
match
---
name: replace [62136,62143]
name: replace [62188,62195]
===
match
---
trailer [7894,7901]
trailer [7894,7901]
===
match
---
trailer [37787,37817]
trailer [37787,37817]
===
match
---
atom_expr [68555,68567]
atom_expr [68607,68619]
===
match
---
atom_expr [62002,62021]
atom_expr [62054,62073]
===
match
---
trailer [82639,82653]
trailer [82691,82705]
===
match
---
string: 'email' [71942,71949]
string: 'email' [71994,72001]
===
match
---
name: jinja_context [71295,71308]
name: jinja_context [71347,71360]
===
match
---
operator: = [77850,77851]
operator: = [77902,77903]
===
match
---
if_stmt [57785,58277]
if_stmt [57837,58329]
===
match
---
name: session [59290,59297]
name: session [59342,59349]
===
match
---
funcdef [13947,15411]
funcdef [13947,15411]
===
match
---
number: 1 [13174,13175]
number: 1 [13174,13175]
===
match
---
name: TaskInstance [79387,79399]
name: TaskInstance [79439,79451]
===
match
---
trailer [22235,22246]
trailer [22235,22246]
===
match
---
name: Column [9663,9669]
name: Column [9663,9669]
===
match
---
comparison [26322,26360]
comparison [26322,26360]
===
match
---
expr_stmt [71926,71955]
expr_stmt [71978,72007]
===
match
---
name: join [49278,49282]
name: join [49330,49334]
===
match
---
simple_stmt [31703,31771]
simple_stmt [31703,31771]
===
match
---
operator: , [65716,65717]
operator: , [65768,65769]
===
match
---
operator: = [39740,39741]
operator: = [39740,39741]
===
match
---
name: str [59075,59078]
name: str [59127,59130]
===
match
---
name: has_dag [11665,11672]
name: has_dag [11665,11672]
===
match
---
name: refresh_from_task [5416,5433]
name: refresh_from_task [5416,5433]
===
match
---
name: self [28048,28052]
name: self [28048,28052]
===
match
---
atom_expr [77997,78045]
atom_expr [78049,78097]
===
match
---
string: "Failed to load task run error" [4167,4198]
string: "Failed to load task run error" [4167,4198]
===
match
---
operator: = [34098,34099]
operator: = [34098,34099]
===
match
---
operator: , [59090,59091]
operator: , [59142,59143]
===
match
---
atom_expr [28474,28496]
atom_expr [28474,28496]
===
match
---
operator: , [77714,77715]
operator: , [77766,77767]
===
match
---
name: try_number [6881,6891]
name: try_number [6881,6891]
===
match
---
tfpdef [15545,15569]
tfpdef [15545,15569]
===
match
---
simple_stmt [73274,73895]
simple_stmt [73326,73947]
===
match
---
name: staticmethod [63148,63160]
name: staticmethod [63200,63212]
===
match
---
operator: = [9917,9918]
operator: = [9917,9918]
===
match
---
trailer [82614,82622]
trailer [82666,82674]
===
match
---
trailer [40744,40752]
trailer [40744,40752]
===
match
---
trailer [13079,13085]
trailer [13079,13085]
===
match
---
fstring_string: ]> [33014,33016]
fstring_string: ]> [33014,33016]
===
match
---
return_stmt [30819,30875]
return_stmt [30819,30875]
===
match
---
trailer [77638,77645]
trailer [77690,77697]
===
match
---
fstring [49284,49294]
fstring [49336,49346]
===
match
---
operator: = [22523,22524]
operator: = [22523,22524]
===
match
---
trailer [50851,50857]
trailer [50903,50909]
===
match
---
trailer [71510,71517]
trailer [71562,71569]
===
match
---
trailer [7410,7416]
trailer [7410,7416]
===
match
---
simple_stmt [25946,25958]
simple_stmt [25946,25958]
===
match
---
suite [56334,56374]
suite [56386,56426]
===
match
---
operator: , [14282,14283]
operator: , [14282,14283]
===
match
---
tfpdef [73155,73165]
tfpdef [73207,73217]
===
match
---
trailer [53024,53033]
trailer [53076,53085]
===
match
---
string: "previous_execution_date was called" [29464,29500]
string: "previous_execution_date was called" [29464,29500]
===
match
---
argument [9966,9980]
argument [9966,9980]
===
match
---
parameters [41376,41388]
parameters [41345,41357]
===
match
---
operator: @ [80729,80730]
operator: @ [80781,80782]
===
match
---
name: self [42571,42575]
name: self [42540,42544]
===
match
---
atom [10523,10827]
atom [10523,10827]
===
match
---
name: primary_key [9462,9473]
name: primary_key [9462,9473]
===
match
---
string: """Initialize the attributes that aren't stored in the DB""" [12462,12522]
string: """Initialize the attributes that aren't stored in the DB""" [12462,12522]
===
match
---
atom_expr [45483,45493]
atom_expr [45535,45545]
===
match
---
comparison [39036,39073]
comparison [39036,39073]
===
match
---
name: context [48064,48071]
name: context [48116,48123]
===
match
---
param [11047,11052]
param [11047,11052]
===
match
---
simple_stmt [37513,37540]
simple_stmt [37513,37540]
===
match
---
operator: = [39243,39244]
operator: = [39243,39244]
===
match
---
name: DagRun [60189,60195]
name: DagRun [60241,60247]
===
match
---
trailer [19356,19363]
trailer [19356,19363]
===
match
---
name: self [48660,48664]
name: self [48712,48716]
===
match
---
name: queue [22572,22577]
name: queue [22572,22577]
===
match
---
name: cmd [17909,17912]
name: cmd [17909,17912]
===
match
---
operator: { [67577,67578]
operator: { [67629,67630]
===
match
---
comparison [26152,26202]
comparison [26152,26202]
===
match
---
arglist [62525,62555]
arglist [62577,62607]
===
match
---
string: '' [61628,61630]
string: '' [61680,61682]
===
match
---
trailer [46589,46594]
trailer [46641,46646]
===
match
---
simple_stmt [27924,27992]
simple_stmt [27924,27992]
===
match
---
expr_stmt [7833,7857]
expr_stmt [7833,7857]
===
match
---
expr_stmt [60593,60629]
expr_stmt [60645,60681]
===
match
---
name: debug [67802,67807]
name: debug [67854,67859]
===
match
---
name: session [38538,38545]
name: session [38538,38545]
===
match
---
name: self [30028,30032]
name: self [30028,30032]
===
match
---
name: duration [72901,72909]
name: duration [72953,72961]
===
match
---
name: self [34821,34825]
name: self [34821,34825]
===
match
---
operator: = [10898,10899]
operator: = [10898,10899]
===
match
---
name: Session [26460,26467]
name: Session [26460,26467]
===
match
---
atom_expr [11426,11463]
atom_expr [11426,11463]
===
match
---
expr_stmt [9374,9405]
expr_stmt [9374,9405]
===
match
---
funcdef [59522,59697]
funcdef [59574,59749]
===
match
---
operator: , [30127,30128]
operator: , [30127,30128]
===
match
---
suite [52084,52135]
suite [52136,52187]
===
match
---
atom_expr [80027,80043]
atom_expr [80079,80095]
===
match
---
trailer [48861,48922]
trailer [48913,48974]
===
match
---
name: Integer [10103,10110]
name: Integer [10103,10110]
===
match
---
argument [70778,70797]
argument [70830,70849]
===
match
---
atom_expr [62376,62402]
atom_expr [62428,62454]
===
match
---
name: Any [63289,63292]
name: Any [63341,63344]
===
match
---
trailer [26234,26238]
trailer [26234,26238]
===
match
---
name: dag_id [76425,76431]
name: dag_id [76477,76483]
===
match
---
string: 'next_ds' [64782,64791]
string: 'next_ds' [64834,64843]
===
match
---
name: dag_run [60016,60023]
name: dag_run [60068,60075]
===
match
---
name: hasattr [80216,80223]
name: hasattr [80268,80275]
===
match
---
name: Exception [49876,49885]
name: Exception [49928,49937]
===
match
---
suite [80621,80650]
suite [80673,80702]
===
match
---
name: delay [34790,34795]
name: delay [34790,34795]
===
match
---
trailer [40936,40938]
trailer [40905,40907]
===
match
---
for_stmt [7314,7434]
for_stmt [7314,7434]
===
match
---
name: self [54984,54988]
name: self [55036,55040]
===
match
---
operator: , [72742,72743]
operator: , [72794,72795]
===
match
---
name: task_copy [48445,48454]
name: task_copy [48497,48506]
===
match
---
number: 1 [70899,70900]
number: 1 [70951,70952]
===
match
---
expr_stmt [34086,34135]
expr_stmt [34086,34135]
===
match
---
suite [81423,81449]
suite [81475,81501]
===
match
---
operator: } [19071,19072]
operator: } [19071,19072]
===
match
---
argument [71293,71308]
argument [71345,71360]
===
match
---
operator: , [59166,59167]
operator: , [59218,59219]
===
match
---
operator: , [26420,26421]
operator: , [26420,26421]
===
match
---
name: session [20888,20895]
name: session [20888,20895]
===
match
---
string: 'execution_date' [58492,58508]
string: 'execution_date' [58544,58560]
===
match
---
atom_expr [53187,53214]
atom_expr [53239,53266]
===
match
---
simple_stmt [40804,40827]
simple_stmt [42764,42787]
===
match
---
fstring [47855,47918]
fstring [47907,47970]
===
match
---
name: ti [79958,79960]
name: ti [80010,80012]
===
match
---
name: self [73123,73127]
name: self [73175,73179]
===
match
---
name: tomorrow_ds_nodash [62221,62239]
name: tomorrow_ds_nodash [62273,62291]
===
match
---
lambdef [5045,5090]
lambdef [5045,5090]
===
match
---
name: e [67482,67483]
name: e [67534,67535]
===
match
---
trailer [60658,60673]
trailer [60710,60725]
===
match
---
name: value [13260,13265]
name: value [13260,13265]
===
match
---
atom_expr [68674,68693]
atom_expr [68726,68745]
===
match
---
operator: , [28421,28422]
operator: , [28421,28422]
===
match
---
trailer [37620,37627]
trailer [37620,37627]
===
match
---
suite [63358,63475]
suite [63410,63527]
===
match
---
operator: = [81621,81622]
operator: = [81673,81674]
===
match
---
atom_expr [60479,60500]
atom_expr [60531,60552]
===
match
---
simple_stmt [76441,76684]
simple_stmt [76493,76736]
===
match
---
trailer [73025,73031]
trailer [73077,73083]
===
match
---
name: execution_date [26188,26202]
name: execution_date [26188,26202]
===
match
---
name: base [1833,1837]
name: base [1833,1837]
===
match
---
name: self [71456,71460]
name: self [71508,71512]
===
match
---
trailer [60527,60529]
trailer [60579,60581]
===
match
---
arglist [22816,22849]
arglist [22816,22849]
===
match
---
operator: = [80454,80455]
operator: = [80506,80507]
===
match
---
name: context [52797,52804]
name: context [52849,52856]
===
match
---
trailer [63951,63980]
trailer [64003,64032]
===
match
---
operator: , [1332,1333]
operator: , [1332,1333]
===
match
---
name: schedulable_ti [47283,47297]
name: schedulable_ti [47335,47349]
===
match
---
name: SIGTERM [48562,48569]
name: SIGTERM [48614,48621]
===
match
---
trailer [46848,46852]
trailer [46900,46904]
===
match
---
atom_expr [68388,68400]
atom_expr [68440,68452]
===
match
---
decorator [28018,28028]
decorator [28018,28028]
===
match
---
operator: } [7751,7752]
operator: } [7751,7752]
===
match
---
name: info [47201,47205]
name: info [47253,47257]
===
match
---
name: res [53808,53811]
name: res [53860,53863]
===
match
---
name: _date_or_empty [45265,45279]
name: _date_or_empty [45317,45331]
===
match
---
trailer [12032,12034]
trailer [12032,12034]
===
match
---
name: job_id [53666,53672]
name: job_id [53718,53724]
===
match
---
operator: <= [59499,59501]
operator: <= [59551,59553]
===
match
---
arglist [70778,70947]
arglist [70830,70999]
===
match
---
trailer [77907,77911]
trailer [77959,77963]
===
match
---
operator: = [4717,4718]
operator: = [4717,4718]
===
match
---
atom_expr [9856,9868]
atom_expr [9856,9868]
===
match
---
name: get_template_context [52688,52708]
name: get_template_context [52740,52760]
===
match
---
argument [15359,15368]
argument [15359,15368]
===
match
---
classdef [7906,8750]
classdef [7906,8750]
===
match
---
name: Column [9761,9767]
name: Column [9761,9767]
===
match
---
if_stmt [52056,52135]
if_stmt [52108,52187]
===
match
---
name: base_url [19511,19519]
name: base_url [19511,19519]
===
match
---
trailer [32706,32715]
trailer [32706,32715]
===
match
---
simple_stmt [4001,4018]
simple_stmt [4001,4018]
===
match
---
name: property [80823,80831]
name: property [80875,80883]
===
match
---
name: tomorrow_ds [65651,65662]
name: tomorrow_ds [65703,65714]
===
match
---
name: end_date [34779,34787]
name: end_date [34779,34787]
===
match
---
operator: = [18956,18957]
operator: = [18956,18957]
===
match
---
trailer [62143,62152]
trailer [62195,62204]
===
match
---
parameters [3288,3306]
parameters [3288,3306]
===
match
---
comparison [77732,77767]
comparison [77784,77819]
===
match
---
simple_stmt [1954,2011]
simple_stmt [1954,2011]
===
match
---
suite [66109,67056]
suite [66161,67108]
===
match
---
name: log [32582,32585]
name: log [32582,32585]
===
match
---
suite [81263,81301]
suite [81315,81353]
===
match
---
trailer [35952,35957]
trailer [35952,35957]
===
match
---
atom_expr [11981,11996]
atom_expr [11981,11996]
===
match
---
expr_stmt [22730,22747]
expr_stmt [22730,22747]
===
match
---
name: getboolean [45784,45794]
name: getboolean [45836,45846]
===
match
---
trailer [56545,56551]
trailer [56597,56603]
===
match
---
name: hashlib [33760,33767]
name: hashlib [33760,33767]
===
match
---
atom_expr [47225,47235]
atom_expr [47277,47287]
===
match
---
name: path [71075,71079]
name: path [71127,71131]
===
match
---
atom_expr [24713,24723]
atom_expr [24713,24723]
===
match
---
name: self [45409,45413]
name: self [45461,45465]
===
match
---
atom_expr [52594,52603]
atom_expr [52646,52655]
===
match
---
operator: , [46664,46665]
operator: , [46716,46717]
===
match
---
name: session [26824,26831]
name: session [26824,26831]
===
match
---
atom_expr [37616,37627]
atom_expr [37616,37627]
===
match
---
name: query [77037,77042]
name: query [77089,77094]
===
match
---
trailer [22662,22671]
trailer [22662,22671]
===
match
---
operator: { [33002,33003]
operator: { [33002,33003]
===
match
---
trailer [55033,55035]
trailer [55085,55087]
===
match
---
name: execution_date [76496,76510]
name: execution_date [76548,76562]
===
match
---
for_stmt [32492,32893]
for_stmt [32492,32893]
===
match
---
operator: , [82162,82163]
operator: , [82214,82215]
===
match
---
name: should_pass_filepath [14606,14626]
name: should_pass_filepath [14606,14626]
===
match
---
name: extend [18304,18310]
name: extend [18304,18310]
===
match
---
trailer [31669,31671]
trailer [31669,31671]
===
match
---
operator: = [35725,35726]
operator: = [35725,35726]
===
match
---
string: '' [41551,41553]
string: '' [41520,41522]
===
match
---
simple_stmt [82280,82315]
simple_stmt [82332,82367]
===
match
---
operator: = [55696,55697]
operator: = [55748,55749]
===
match
---
trailer [52776,52796]
trailer [52828,52848]
===
match
---
trailer [5084,5089]
trailer [5084,5089]
===
match
---
name: session [81592,81599]
name: session [81644,81651]
===
match
---
name: end_date [40840,40848]
name: end_date [40809,40817]
===
match
---
name: task [52599,52603]
name: task [52651,52655]
===
match
---
name: self [55494,55498]
name: self [55546,55550]
===
match
---
expr_stmt [37898,37931]
expr_stmt [37898,37931]
===
match
---
operator: = [15683,15684]
operator: = [15683,15684]
===
match
---
name: priority_weight [81224,81239]
name: priority_weight [81276,81291]
===
match
---
operator: = [53541,53542]
operator: = [53593,53594]
===
match
---
atom_expr [30555,30810]
atom_expr [30555,30810]
===
match
---
operator: , [1044,1045]
operator: , [1044,1045]
===
match
---
operator: , [71844,71845]
operator: , [71896,71897]
===
match
---
operator: , [65940,65941]
operator: , [65992,65993]
===
match
---
return_stmt [51885,51898]
return_stmt [51937,51950]
===
match
---
name: self [79870,79874]
name: self [79922,79926]
===
match
---
trailer [35504,35510]
trailer [35504,35510]
===
match
---
suite [60095,60143]
suite [60147,60195]
===
match
---
operator: , [15345,15346]
operator: , [15345,15346]
===
match
---
name: Sentry [45675,45681]
name: Sentry [45727,45733]
===
match
---
simple_stmt [72022,72041]
simple_stmt [72074,72093]
===
match
---
operator: = [26443,26444]
operator: = [26443,26444]
===
match
---
funcdef [8089,8262]
funcdef [8089,8262]
===
match
---
decorator [15416,15430]
decorator [15416,15430]
===
match
---
operator: , [32025,32026]
operator: , [32025,32026]
===
match
---
if_stmt [3623,3848]
if_stmt [3623,3848]
===
match
---
operator: , [46221,46222]
operator: , [46273,46274]
===
match
---
name: set_duration [56876,56888]
name: set_duration [56928,56940]
===
match
---
trailer [68794,68810]
trailer [68846,68862]
===
match
---
and_test [11403,11463]
and_test [11403,11463]
===
match
---
expr_stmt [10229,10250]
expr_stmt [10229,10250]
===
match
---
trailer [60572,60584]
trailer [60624,60636]
===
match
---
tfpdef [67953,67979]
tfpdef [68005,68031]
===
match
---
atom_expr [80531,80537]
atom_expr [80583,80589]
===
match
---
name: expunge_all [60487,60498]
name: expunge_all [60539,60550]
===
match
---
or_test [23246,23272]
or_test [23246,23272]
===
match
---
operator: = [76447,76448]
operator: = [76499,76500]
===
match
---
expr_stmt [68088,68125]
expr_stmt [68140,68177]
===
match
---
name: session [20985,20992]
name: session [20985,20992]
===
match
---
operator: @ [30881,30882]
operator: @ [30881,30882]
===
match
---
fstring_expr [62310,62324]
fstring_expr [62362,62376]
===
match
---
trailer [72871,72882]
trailer [72923,72934]
===
match
---
string: "Marking task as UP_FOR_RETRY." [58195,58226]
string: "Marking task as UP_FOR_RETRY." [58247,58278]
===
match
---
trailer [14961,14976]
trailer [14961,14976]
===
match
---
if_stmt [33286,34759]
if_stmt [33286,34759]
===
match
---
atom_expr [79980,79994]
atom_expr [80032,80046]
===
match
---
atom_expr [48541,48586]
atom_expr [48593,48638]
===
match
---
import_from [2750,2814]
import_from [2750,2814]
===
match
---
arglist [9953,9980]
arglist [9953,9980]
===
match
---
operator: , [32674,32675]
operator: , [32674,32675]
===
match
---
name: self [52683,52687]
name: self [52735,52739]
===
match
---
name: prev_attempted_tries [13289,13309]
name: prev_attempted_tries [13289,13309]
===
match
---
trailer [60310,60370]
trailer [60362,60422]
===
match
---
name: in_ [7366,7369]
name: in_ [7366,7369]
===
match
---
trailer [79905,79920]
trailer [79957,79972]
===
match
---
name: get_task [5379,5387]
name: get_task [5379,5387]
===
match
---
trailer [22403,22412]
trailer [22403,22412]
===
match
---
operator: = [48807,48808]
operator: = [48859,48860]
===
match
---
trailer [62061,62070]
trailer [62113,62122]
===
match
---
name: get_previous_ti [28999,29014]
name: get_previous_ti [28999,29014]
===
match
---
simple_stmt [62485,62557]
simple_stmt [62537,62609]
===
match
---
operator: = [17872,17873]
operator: = [17872,17873]
===
match
---
name: info [47557,47561]
name: info [47609,47613]
===
match
---
atom_expr [22684,22700]
atom_expr [22684,22700]
===
match
---
operator: , [64514,64515]
operator: , [64566,64567]
===
match
---
trailer [81257,81262]
trailer [81309,81314]
===
match
---
operator: = [53968,53969]
operator: = [54020,54021]
===
match
---
atom_expr [27728,27777]
atom_expr [27728,27777]
===
match
---
simple_stmt [41153,41231]
simple_stmt [41122,41200]
===
match
---
expr_stmt [9716,9742]
expr_stmt [9716,9742]
===
match
---
name: execution_date [6997,7011]
name: execution_date [6997,7011]
===
match
---
trailer [22021,22030]
trailer [22021,22030]
===
match
---
param [53403,53424]
param [53455,53476]
===
match
---
trailer [29205,29214]
trailer [29205,29214]
===
match
---
operator: = [26806,26807]
operator: = [26806,26807]
===
match
---
operator: = [11884,11885]
operator: = [11884,11885]
===
match
---
name: hashlib [812,819]
name: hashlib [812,819]
===
match
---
atom_expr [74119,74138]
atom_expr [74171,74190]
===
match
---
trailer [71251,71263]
trailer [71303,71315]
===
match
---
trailer [79960,79971]
trailer [80012,80023]
===
match
---
if_stmt [73903,74170]
if_stmt [73955,74222]
===
match
---
trailer [67801,67807]
trailer [67853,67859]
===
match
---
decorated [77371,77815]
decorated [77423,77867]
===
match
---
name: prev_ti [29586,29593]
name: prev_ti [29586,29593]
===
match
---
arglist [6695,6950]
arglist [6695,6950]
===
match
---
trailer [58491,58526]
trailer [58543,58578]
===
match
---
operator: , [14147,14148]
operator: , [14147,14148]
===
match
---
name: context [53231,53238]
name: context [53283,53290]
===
match
---
atom_expr [20352,20379]
atom_expr [20352,20379]
===
match
---
trailer [47461,47469]
trailer [47513,47521]
===
match
---
atom_expr [23202,23212]
atom_expr [23202,23212]
===
match
---
name: Log [40735,40738]
name: Log [40735,40738]
===
match
---
operator: = [48268,48269]
operator: = [48320,48321]
===
match
---
trailer [26238,26270]
trailer [26238,26270]
===
match
---
suite [48764,50590]
suite [48816,50642]
===
match
---
name: str [79845,79848]
name: str [79897,79900]
===
match
---
simple_stmt [3165,3202]
simple_stmt [3165,3202]
===
match
---
argument [31851,31866]
argument [31851,31866]
===
match
---
atom_expr [14863,15410]
atom_expr [14863,15410]
===
match
---
name: count [77580,77585]
name: count [77632,77637]
===
match
---
operator: = [29561,29562]
operator: = [29561,29562]
===
match
---
atom_expr [25986,26018]
atom_expr [25986,26018]
===
match
---
name: dates [7098,7103]
name: dates [7098,7103]
===
match
---
atom_expr [72727,72742]
atom_expr [72779,72794]
===
match
---
operator: , [65738,65739]
operator: , [65790,65791]
===
match
---
trailer [40285,40293]
trailer [40285,40293]
===
match
---
atom_expr [7886,7903]
atom_expr [7886,7903]
===
match
---
simple_stmt [38632,38645]
simple_stmt [38632,38645]
===
match
---
operator: , [28447,28448]
operator: , [28447,28448]
===
match
---
argument [30129,30144]
argument [30129,30144]
===
match
---
atom_expr [33647,33662]
atom_expr [33647,33662]
===
match
---
trailer [81283,81300]
trailer [81335,81352]
===
match
---
name: setattr [66480,66487]
name: setattr [66532,66539]
===
match
---
param [71841,71845]
param [71893,71897]
===
match
---
operator: = [48914,48915]
operator: = [48966,48967]
===
match
---
string: 'ti_state' [10639,10649]
string: 'ti_state' [10639,10649]
===
match
---
suite [13316,13822]
suite [13316,13822]
===
match
---
operator: = [23344,23345]
operator: = [23344,23345]
===
match
---
funcdef [19103,19366]
funcdef [19103,19366]
===
match
---
name: rendered_task_instance_fields [66348,66377]
name: rendered_task_instance_fields [66400,66429]
===
match
---
operator: = [61446,61447]
operator: = [61498,61499]
===
match
---
name: mark_success [15003,15015]
name: mark_success [15003,15015]
===
match
---
argument [39842,39857]
argument [39842,39857]
===
match
---
name: schedulable_tis [47169,47184]
name: schedulable_tis [47221,47236]
===
match
---
argument [9593,9609]
argument [9593,9609]
===
match
---
atom_expr [18300,18337]
atom_expr [18300,18337]
===
match
---
name: context [3514,3521]
name: context [3514,3521]
===
match
---
operator: , [47623,47624]
operator: , [47675,47676]
===
match
---
name: os [49366,49368]
name: os [49418,49420]
===
match
---
arglist [40551,40615]
arglist [40551,40615]
===
match
---
operator: @ [12596,12597]
operator: @ [12596,12597]
===
match
---
trailer [43500,43522]
trailer [43552,43574]
===
match
---
argument [39725,39756]
argument [39725,39756]
===
match
---
name: ti [80092,80094]
name: ti [80144,80146]
===
match
---
trailer [46644,46664]
trailer [46696,46716]
===
match
---
trailer [63006,63010]
trailer [63058,63062]
===
match
---
atom_expr [40739,40752]
atom_expr [40739,40752]
===
match
---
name: state [20474,20479]
name: state [20474,20479]
===
match
---
simple_stmt [53177,53215]
simple_stmt [53229,53267]
===
match
---
suite [33053,34796]
suite [33053,34796]
===
match
---
string: """         Based on this instance's try_number, this will calculate         the number of previously attempted tries, defaulting to 0.         """ [13325,13472]
string: """         Based on this instance's try_number, this will calculate         the number of previously attempted tries, defaulting to 0.         """ [13325,13472]
===
match
---
funcdef [54804,55036]
funcdef [54856,55088]
===
match
---
operator: = [15259,15260]
operator: = [15259,15260]
===
match
---
trailer [64673,64682]
trailer [64725,64734]
===
match
---
name: task_id [48744,48751]
name: task_id [48796,48803]
===
match
---
name: bool [15757,15761]
name: bool [15757,15761]
===
match
---
name: provide_session [45654,45669]
name: provide_session [45706,45721]
===
match
---
atom_expr [71788,71816]
atom_expr [71840,71868]
===
match
---
atom_expr [50784,50838]
atom_expr [50836,50890]
===
match
---
operator: + [60754,60755]
operator: + [60806,60807]
===
match
---
arglist [31826,31866]
arglist [31826,31866]
===
match
---
name: self [13219,13223]
name: self [13219,13223]
===
match
---
name: kube_image [68645,68655]
name: kube_image [68697,68707]
===
match
---
operator: = [71931,71932]
operator: = [71983,71984]
===
match
---
atom_expr [55494,55510]
atom_expr [55546,55562]
===
match
---
name: lock_for_update [21735,21750]
name: lock_for_update [21735,21750]
===
match
---
trailer [54785,54798]
trailer [54837,54850]
===
match
---
name: bool [53450,53454]
name: bool [53502,53506]
===
match
---
name: prev_ti [29616,29623]
name: prev_ti [29616,29623]
===
match
---
name: ceil [33611,33615]
name: ceil [33611,33615]
===
match
---
name: TaskInstance [82627,82639]
name: TaskInstance [82679,82691]
===
match
---
name: replace [62254,62261]
name: replace [62306,62313]
===
match
---
trailer [59673,59678]
trailer [59725,59730]
===
match
---
funcdef [80743,80817]
funcdef [80795,80869]
===
match
---
name: TR [7162,7164]
name: TR [7162,7164]
===
match
---
operator: == [23890,23892]
operator: == [23890,23892]
===
match
---
name: priority_weight [10768,10783]
name: priority_weight [10768,10783]
===
match
---
trailer [46932,46941]
trailer [46984,46993]
===
match
---
atom_expr [63013,63031]
atom_expr [63065,63083]
===
match
---
suite [25933,25958]
suite [25933,25958]
===
match
---
decorated [18816,19084]
decorated [18816,19084]
===
match
---
expr_stmt [31680,31694]
expr_stmt [31680,31694]
===
match
---
name: airflow [2662,2669]
name: airflow [2662,2669]
===
match
---
name: self [33840,33844]
name: self [33840,33844]
===
match
---
atom_expr [45234,45246]
atom_expr [45286,45298]
===
match
---
name: session [7572,7579]
name: session [7572,7579]
===
match
---
trailer [34734,34750]
trailer [34734,34750]
===
match
---
name: SUCCESS [52839,52846]
name: SUCCESS [52891,52898]
===
match
---
expr_stmt [11144,11169]
expr_stmt [11144,11169]
===
match
---
name: dag_id [20274,20280]
name: dag_id [20274,20280]
===
match
---
atom_expr [22317,22331]
atom_expr [22317,22331]
===
match
---
string: "exception" [53239,53250]
string: "exception" [53291,53302]
===
match
---
name: self [35095,35099]
name: self [35095,35099]
===
match
---
atom_expr [53125,53147]
atom_expr [53177,53199]
===
match
---
string: "&upstream=false" [19732,19749]
string: "&upstream=false" [19732,19749]
===
match
---
name: query [46071,46076]
name: query [46123,46128]
===
match
---
simple_stmt [56871,56891]
simple_stmt [56923,56943]
===
match
---
trailer [59074,59090]
trailer [59126,59142]
===
match
---
argument [38386,38419]
argument [38386,38419]
===
match
---
trailer [69094,69121]
trailer [69146,69173]
===
match
---
trailer [60322,60326]
trailer [60374,60378]
===
match
---
trailer [71539,71748]
trailer [71591,71800]
===
match
---
name: item [63026,63030]
name: item [63078,63082]
===
match
---
suite [41107,41333]
suite [41076,41302]
===
match
---
name: hostname [22378,22386]
name: hostname [22378,22386]
===
match
---
atom_expr [45358,45389]
atom_expr [45410,45441]
===
match
---
name: pendulum [29598,29606]
name: pendulum [29598,29606]
===
match
---
simple_stmt [46841,46867]
simple_stmt [46893,46919]
===
match
---
name: pid [10229,10232]
name: pid [10229,10232]
===
match
---
expr_stmt [9615,9647]
expr_stmt [9615,9647]
===
match
---
name: info [41162,41166]
name: info [41131,41135]
===
match
---
operator: , [15730,15731]
operator: , [15730,15731]
===
match
---
operator: , [4626,4627]
operator: , [4626,4627]
===
match
---
name: e [43241,43242]
name: e [43293,43294]
===
match
---
with_stmt [4326,4632]
with_stmt [4326,4632]
===
match
---
name: utils [2670,2675]
name: utils [2670,2675]
===
match
---
simple_stmt [20790,20846]
simple_stmt [20790,20846]
===
match
---
operator: = [53580,53581]
operator: = [53632,53633]
===
match
---
expr_stmt [3575,3614]
expr_stmt [3575,3614]
===
match
---
simple_stmt [11214,11231]
simple_stmt [11214,11231]
===
match
---
atom_expr [44593,44605]
atom_expr [44645,44657]
===
match
---
atom_expr [74179,74405]
atom_expr [74231,74457]
===
match
---
atom_expr [45543,45559]
atom_expr [45595,45611]
===
match
---
name: self [60734,60738]
name: self [60786,60790]
===
match
---
name: self [34774,34778]
name: self [34774,34778]
===
match
---
fstring_string: operator_failures_ [56912,56930]
fstring_string: operator_failures_ [56964,56982]
===
match
---
name: ti [79851,79853]
name: ti [79903,79905]
===
match
---
operator: , [62130,62131]
operator: , [62182,62183]
===
match
---
name: test_mode [56347,56356]
name: test_mode [56399,56408]
===
match
---
funcdef [22856,23546]
funcdef [22856,23546]
===
match
---
trailer [78946,78953]
trailer [78998,79005]
===
match
---
trailer [29524,29540]
trailer [29524,29540]
===
match
---
trailer [51412,51457]
trailer [51464,51509]
===
match
---
name: info [43460,43464]
name: info [43512,43516]
===
match
---
simple_stmt [50926,50946]
simple_stmt [50978,50998]
===
match
---
trailer [63025,63031]
trailer [63077,63083]
===
match
---
operator: = [54175,54176]
operator: = [54227,54228]
===
match
---
trailer [44086,44138]
trailer [44138,44190]
===
match
---
simple_stmt [43139,43166]
simple_stmt [43191,43218]
===
match
---
name: self [40223,40227]
name: self [40223,40227]
===
match
---
simple_stmt [42624,42673]
simple_stmt [42593,42642]
===
match
---
operator: , [62969,62970]
operator: , [63021,63022]
===
match
---
name: pendulum [29197,29205]
name: pendulum [29197,29205]
===
match
---
trailer [25000,25002]
trailer [25000,25002]
===
match
---
atom_expr [82149,82162]
atom_expr [82201,82214]
===
match
---
string: "XCom data cleared" [24071,24090]
string: "XCom data cleared" [24071,24090]
===
match
---
if_stmt [58905,58955]
if_stmt [58957,59007]
===
match
---
fstring_expr [33002,33014]
fstring_expr [33002,33014]
===
match
---
name: property [81207,81215]
name: property [81259,81267]
===
match
---
trailer [9898,9904]
trailer [9898,9904]
===
match
---
param [72439,72448]
param [72491,72500]
===
match
---
simple_stmt [46883,46942]
simple_stmt [46935,46994]
===
match
---
operator: , [50573,50574]
operator: , [50625,50626]
===
match
---
name: self [80073,80077]
name: self [80125,80129]
===
match
---
name: dag_id [45214,45220]
name: dag_id [45266,45272]
===
match
---
trailer [12318,12322]
trailer [12318,12322]
===
match
---
atom [18078,18106]
atom [18078,18106]
===
match
---
atom_expr [58150,58168]
atom_expr [58202,58220]
===
match
---
trailer [42784,42786]
trailer [42753,42755]
===
match
---
trailer [66460,66462]
trailer [66512,66514]
===
match
---
atom_expr [29124,29137]
atom_expr [29124,29137]
===
match
---
operator: , [79160,79161]
operator: , [79212,79213]
===
match
---
funcdef [77973,79487]
funcdef [78025,79539]
===
match
---
name: Union [78006,78011]
name: Union [78058,78063]
===
match
---
arith_expr [5515,5547]
arith_expr [5515,5547]
===
match
---
name: os [40815,40817]
name: os [42775,42777]
===
match
---
name: max_tries [40228,40237]
name: max_tries [40228,40237]
===
match
---
expr_stmt [56804,56820]
expr_stmt [56856,56872]
===
match
---
operator: , [45743,45744]
operator: , [45795,45796]
===
match
---
name: queued_dttm [40330,40341]
name: queued_dttm [40330,40341]
===
match
---
operator: { [47904,47905]
operator: { [47956,47957]
===
match
---
atom_expr [58884,58894]
atom_expr [58936,58946]
===
match
---
if_stmt [51765,51877]
if_stmt [51817,51929]
===
match
---
operator: == [24844,24846]
operator: == [24844,24846]
===
match
---
atom_expr [33760,33979]
atom_expr [33760,33979]
===
match
---
operator: @ [77371,77372]
operator: @ [77423,77424]
===
match
---
operator: = [9661,9662]
operator: = [9661,9662]
===
match
---
operator: , [18593,18594]
operator: , [18593,18594]
===
match
---
name: commit [40422,40428]
name: commit [40422,40428]
===
match
---
name: tis [77992,77995]
name: tis [78044,78047]
===
match
---
name: property [28019,28027]
name: property [28019,28027]
===
match
---
sync_comp_for [79463,79476]
sync_comp_for [79515,79528]
===
match
---
name: key [73137,73140]
name: key [73189,73192]
===
match
---
simple_stmt [9687,9712]
simple_stmt [9687,9712]
===
match
---
name: state [55690,55695]
name: state [55742,55747]
===
match
---
suite [39206,39272]
suite [39206,39272]
===
match
---
return_stmt [77540,77814]
return_stmt [77592,77866]
===
match
---
name: conf [71875,71879]
name: conf [71927,71931]
===
match
---
decorator [74411,74428]
decorator [74463,74480]
===
match
---
name: include_prior_dates [74655,74674]
name: include_prior_dates [74707,74726]
===
match
---
operator: = [33737,33738]
operator: = [33737,33738]
===
match
---
simple_stmt [42727,42748]
simple_stmt [42696,42717]
===
match
---
string: "Marking task as FAILED." [58033,58058]
string: "Marking task as FAILED." [58085,58110]
===
match
---
name: log [24061,24064]
name: log [24061,24064]
===
match
---
expr_stmt [23425,23454]
expr_stmt [23425,23454]
===
match
---
name: test_mode [42594,42603]
name: test_mode [42563,42572]
===
match
---
simple_stmt [69730,70098]
simple_stmt [69782,70150]
===
match
---
dotted_name [2448,2469]
dotted_name [2448,2469]
===
match
---
name: Union [56077,56082]
name: Union [56129,56134]
===
match
---
operator: , [54464,54465]
operator: , [54516,54517]
===
match
---
funcdef [80921,80983]
funcdef [80973,81035]
===
match
---
name: _execute_task [51115,51128]
name: _execute_task [51167,51180]
===
match
---
simple_stmt [42796,42834]
simple_stmt [42848,42886]
===
match
---
simple_stmt [32233,32245]
simple_stmt [32233,32245]
===
match
---
atom_expr [67507,67582]
atom_expr [67559,67634]
===
match
---
not_test [38450,38581]
not_test [38450,38581]
===
match
---
atom_expr [25311,25333]
atom_expr [25311,25333]
===
match
---
name: task_id [23939,23946]
name: task_id [23939,23946]
===
match
---
trailer [26303,26306]
trailer [26303,26306]
===
match
---
trailer [71161,71173]
trailer [71213,71225]
===
match
---
trailer [60438,60445]
trailer [60490,60497]
===
match
---
param [32911,32915]
param [32911,32915]
===
match
---
name: filter [26020,26026]
name: filter [26020,26026]
===
match
---
param [4686,4709]
param [4686,4709]
===
match
---
tfpdef [11053,11077]
tfpdef [11053,11077]
===
match
---
name: execution_date [10706,10720]
name: execution_date [10706,10720]
===
match
---
return_stmt [67598,67622]
return_stmt [67650,67674]
===
match
---
name: field_name [66395,66405]
name: field_name [66447,66457]
===
match
---
name: Column [9849,9855]
name: Column [9849,9855]
===
match
---
trailer [43870,43884]
trailer [43922,43936]
===
match
---
trailer [76998,77006]
trailer [77050,77058]
===
match
---
name: self [23425,23429]
name: self [23425,23429]
===
match
---
name: self [8445,8449]
name: self [8445,8449]
===
match
---
name: debug [29458,29463]
name: debug [29458,29463]
===
match
---
atom_expr [5033,5091]
atom_expr [5033,5091]
===
match
---
name: data [4092,4096]
name: data [4092,4096]
===
match
---
simple_stmt [32346,32376]
simple_stmt [32346,32376]
===
match
---
atom_expr [72142,72185]
atom_expr [72194,72237]
===
match
---
trailer [29196,29215]
trailer [29196,29215]
===
match
---
name: self [45495,45499]
name: self [45547,45551]
===
match
---
operator: , [39857,39858]
operator: , [39857,39858]
===
match
---
name: send_email [72627,72637]
name: send_email [72679,72689]
===
match
---
decorator [50701,50718]
decorator [50753,50770]
===
match
---
atom_expr [79851,79861]
atom_expr [79903,79913]
===
match
---
arglist [63952,63979]
arglist [64004,64031]
===
match
---
suite [27907,27992]
suite [27907,27992]
===
match
---
argument [46776,46804]
argument [46828,46856]
===
match
---
name: hostname [37650,37658]
name: hostname [37650,37658]
===
match
---
name: max_tries [59507,59516]
name: max_tries [59559,59568]
===
match
---
operator: , [64846,64847]
operator: , [64898,64899]
===
match
---
name: self [32021,32025]
name: self [32021,32025]
===
match
---
name: self [58834,58838]
name: self [58886,58890]
===
match
---
import_from [59880,59906]
import_from [59932,59958]
===
match
---
not_test [37958,37974]
not_test [37958,37974]
===
match
---
param [48064,48072]
param [48116,48124]
===
match
---
name: Optional [29771,29779]
name: Optional [29771,29779]
===
match
---
name: job_id [54176,54182]
name: job_id [54228,54234]
===
match
---
if_stmt [11400,11926]
if_stmt [11400,11926]
===
match
---
name: self [30826,30830]
name: self [30826,30830]
===
match
---
decorator [59702,59719]
decorator [59754,59771]
===
match
---
trailer [11162,11169]
trailer [11162,11169]
===
match
---
simple_stmt [1350,1394]
simple_stmt [1350,1394]
===
match
---
atom_expr [20916,20932]
atom_expr [20916,20932]
===
match
---
name: execution_date [27086,27100]
name: execution_date [27086,27100]
===
match
---
trailer [65165,65171]
trailer [65217,65223]
===
match
---
name: self [65504,65508]
name: self [65556,65560]
===
match
---
trailer [4615,4631]
trailer [4615,4631]
===
match
---
name: airflow [3024,3031]
name: airflow [3024,3031]
===
match
---
atom_expr [82076,82095]
atom_expr [82128,82147]
===
match
---
fstring_expr [14699,14713]
fstring_expr [14699,14713]
===
match
---
operator: = [53879,53880]
operator: = [53931,53932]
===
match
---
trailer [46277,46281]
trailer [46329,46333]
===
match
---
operator: { [62326,62327]
operator: { [62378,62379]
===
match
---
trailer [72945,72959]
trailer [72997,73011]
===
match
---
operator: = [71454,71455]
operator: = [71506,71507]
===
match
---
if_stmt [78938,79231]
if_stmt [78990,79283]
===
match
---
name: error_file [56776,56786]
name: error_file [56828,56838]
===
match
---
name: XCom [77071,77075]
name: XCom [77123,77127]
===
match
---
trailer [72219,72266]
trailer [72271,72318]
===
match
---
trailer [19049,19056]
trailer [19049,19056]
===
match
---
name: self [80256,80260]
name: self [80308,80312]
===
match
---
trailer [35437,35444]
trailer [35437,35444]
===
match
---
name: task [64727,64731]
name: task [64779,64783]
===
match
---
parameters [81239,81245]
parameters [81291,81297]
===
match
---
name: raw [15311,15314]
name: raw [15311,15314]
===
match
---
name: Optional [3888,3896]
name: Optional [3888,3896]
===
match
---
atom_expr [8242,8261]
atom_expr [8242,8261]
===
match
---
name: task_ids [6838,6846]
name: task_ids [6838,6846]
===
match
---
trailer [11728,11768]
trailer [11728,11768]
===
match
---
atom_expr [5295,5305]
atom_expr [5295,5305]
===
match
---
atom_expr [52772,52805]
atom_expr [52824,52857]
===
match
---
return_stmt [81352,81370]
return_stmt [81404,81422]
===
match
---
name: self [54658,54662]
name: self [54710,54714]
===
match
---
suite [3531,3554]
suite [3531,3554]
===
match
---
expr_stmt [82627,82677]
expr_stmt [82679,82729]
===
match
---
trailer [50797,50838]
trailer [50849,50890]
===
match
---
arglist [62013,62020]
arglist [62065,62072]
===
match
---
sync_comp_for [6877,6923]
sync_comp_for [6877,6923]
===
match
---
string: '%Y%m%dT%H%M%S' [58570,58585]
string: '%Y%m%dT%H%M%S' [58622,58637]
===
match
---
trailer [7369,7378]
trailer [7369,7378]
===
match
---
trailer [26245,26253]
trailer [26245,26253]
===
match
---
name: write [48856,48861]
name: write [48908,48913]
===
match
---
trailer [69121,69126]
trailer [69173,69178]
===
match
---
simple_stmt [29579,29640]
simple_stmt [29579,29640]
===
match
---
trailer [78641,78713]
trailer [78693,78765]
===
match
---
name: str [63892,63895]
name: str [63944,63947]
===
match
---
argument [37586,37606]
argument [37586,37606]
===
match
---
name: job [7407,7410]
name: job [7407,7410]
===
match
---
trailer [7181,7183]
trailer [7181,7183]
===
match
---
name: SUCCESS [43158,43165]
name: SUCCESS [43210,43217]
===
match
---
atom_expr [47647,47663]
atom_expr [47699,47715]
===
match
---
simple_stmt [22590,22632]
simple_stmt [22590,22632]
===
match
---
name: delay [34603,34608]
name: delay [34603,34608]
===
match
---
trailer [47205,47221]
trailer [47257,47273]
===
match
---
trailer [37478,37504]
trailer [37478,37504]
===
match
---
name: start_date [7873,7883]
name: start_date [7873,7883]
===
match
---
simple_stmt [81183,81201]
simple_stmt [81235,81253]
===
match
---
trailer [11481,11485]
trailer [11481,11485]
===
match
---
number: 1 [22542,22543]
number: 1 [22542,22543]
===
match
---
name: end_date [24884,24892]
name: end_date [24884,24892]
===
match
---
atom_expr [82602,82622]
atom_expr [82654,82674]
===
match
---
name: update [67900,67906]
name: update [67952,67958]
===
match
---
name: self [33647,33651]
name: self [33647,33651]
===
insert-node
---
name: TaskInstance [8758,8770]
to
classdef [8752,79487]
at 0
===
insert-tree
---
arglist [8771,8789]
    name: Base [8771,8775]
    operator: , [8775,8776]
    name: LoggingMixin [8777,8789]
to
classdef [8752,79487]
at 1
===
insert-tree
---
simple_stmt [8827,9369]
    string: """     Task instances store the state of a task instance. This table is the     authority and single source of truth around what tasks have run and the     state they are in.      The SqlAlchemy model doesn't have a SqlAlchemy foreign key to the task or     dag model deliberately to have more control over transactions.      Database transactions on this table should insure double triggers and     any confusion around what task instances are or aren't ready to run     even while multiple schedulers may be firing task instances.     """ [8827,9368]
to
suite [8822,79487]
at 0
===
move-tree
---
simple_stmt [40804,40827]
    expr_stmt [40804,40826]
        atom_expr [40804,40812]
            name: self [40804,40808]
            trailer [40808,40812]
                name: pid [40809,40812]
        operator: = [40813,40814]
        atom_expr [40815,40826]
            name: os [40815,40817]
            trailer [40817,40824]
                name: getpid [40818,40824]
            trailer [40824,40826]
to
suite [41860,45648]
at 7
===
insert-tree
---
simple_stmt [42795,42815]
    atom_expr [42795,42814]
        name: session [42795,42802]
        trailer [42802,42808]
            name: merge [42803,42808]
        trailer [42808,42814]
            name: self [42809,42813]
to
suite [41860,45648]
at 8
===
insert-tree
---
simple_stmt [42823,42840]
    atom_expr [42823,42839]
        name: session [42823,42830]
        trailer [42830,42837]
            name: commit [42831,42837]
        trailer [42837,42839]
to
suite [41860,45648]
at 9
===
delete-node
---
name: TaskInstance [8758,8770]
===
===
delete-tree
---
arglist [8771,8789]
    name: Base [8771,8775]
    operator: , [8775,8776]
    name: LoggingMixin [8777,8789]
===
delete-tree
---
simple_stmt [8827,9369]
    string: """     Task instances store the state of a task instance. This table is the     authority and single source of truth around what tasks have run and the     state they are in.      The SqlAlchemy model doesn't have a SqlAlchemy foreign key to the task or     dag model deliberately to have more control over transactions.      Database transactions on this table should insure double triggers and     any confusion around what task instances are or aren't ready to run     even while multiple schedulers may be firing task instances.     """ [8827,9368]
