===
match
---
assert_stmt [18794,18849]
assert_stmt [19145,19200]
===
match
---
suite [20896,21472]
suite [21301,21877]
===
match
---
simple_stmt [4398,4409]
simple_stmt [4566,4577]
===
match
---
name: LocalTaskJob [12748,12760]
name: LocalTaskJob [12959,12971]
===
match
---
operator: = [12746,12747]
operator: = [12957,12958]
===
match
---
name: ti [17395,17397]
name: ti [17606,17608]
===
match
---
operator: = [6968,6969]
operator: = [7179,7180]
===
match
---
name: session [4890,4897]
name: session [5101,5108]
===
match
---
simple_stmt [1684,1726]
simple_stmt [1724,1766]
===
match
---
operator: , [6870,6871]
operator: , [7081,7082]
===
match
---
expr_stmt [2922,2968]
expr_stmt [2962,3008]
===
match
---
operator: = [16317,16318]
operator: = [16528,16529]
===
match
---
operator: , [3014,3015]
operator: , [3054,3055]
===
match
---
atom [3578,3597]
atom [3584,3603]
===
match
---
operator: @ [20752,20753]
operator: @ [21157,21158]
===
match
---
atom_expr [9280,9333]
atom_expr [9491,9544]
===
match
---
name: clear_db_jobs [1816,1829]
name: clear_db_jobs [1856,1869]
===
match
---
trailer [13030,13046]
trailer [13241,13257]
===
match
---
name: executor [12801,12809]
name: executor [13012,13020]
===
match
---
trailer [17174,17180]
trailer [17385,17391]
===
match
---
operator: = [21394,21395]
operator: = [21799,21800]
===
match
---
argument [12565,12588]
argument [12776,12799]
===
match
---
operator: = [5505,5506]
operator: = [5716,5717]
===
match
---
trailer [1934,1946]
trailer [1974,1986]
===
match
---
trailer [19533,19711]
trailer [19884,20062]
===
match
---
name: get_task_instance [2930,2947]
name: get_task_instance [2970,2987]
===
match
---
name: range [17769,17774]
name: range [17980,17985]
===
match
---
trailer [6696,6700]
trailer [6907,6911]
===
match
---
trailer [9778,9780]
trailer [9989,9991]
===
match
---
name: State [3763,3768]
name: State [3769,3774]
===
match
---
assert_stmt [10307,10340]
assert_stmt [10518,10551]
===
match
---
name: DAG [12081,12084]
name: DAG [12292,12295]
===
match
---
name: RUNNING [17849,17856]
name: RUNNING [18060,18067]
===
match
---
operator: = [9278,9279]
operator: = [9489,9490]
===
match
---
name: ti [5586,5588]
name: ti [5797,5799]
===
match
---
trailer [8526,8566]
trailer [8737,8777]
===
match
---
atom_expr [12748,12831]
atom_expr [12959,13042]
===
match
---
trailer [15750,15752]
trailer [15961,15963]
===
match
---
name: AirflowException [4186,4202]
name: AirflowException [4347,4363]
===
match
---
import_name [864,875]
import_name [864,875]
===
match
---
name: get [6697,6700]
name: get [6908,6911]
===
match
---
trailer [5602,5610]
trailer [5813,5821]
===
match
---
atom_expr [17642,17667]
atom_expr [17853,17878]
===
match
---
name: DagBag [4920,4926]
name: DagBag [5131,5137]
===
match
---
name: dags [6692,6696]
name: dags [6903,6907]
===
match
---
atom_expr [17795,17815]
atom_expr [18006,18026]
===
match
---
argument [14604,14627]
argument [14815,14838]
===
match
---
name: mock_get_task_runner [21266,21286]
name: mock_get_task_runner [21671,21691]
===
match
---
trailer [8380,8388]
trailer [8591,8599]
===
match
---
name: RUNNING [14534,14541]
name: RUNNING [14745,14752]
===
match
---
name: DEFAULT_DATE [3551,3563]
name: DEFAULT_DATE [3557,3569]
===
match
---
name: job1 [4469,4473]
name: job1 [4673,4677]
===
match
---
operator: = [8229,8230]
operator: = [8440,8441]
===
match
---
name: dag [12141,12144]
name: dag [12352,12355]
===
match
---
simple_stmt [4806,4856]
simple_stmt [5017,5067]
===
match
---
simple_stmt [5183,5212]
simple_stmt [5394,5423]
===
match
---
operator: = [14114,14115]
operator: = [14325,14326]
===
match
---
name: failure_callback [19400,19416]
name: failure_callback [19751,19767]
===
match
---
string: "test" [17229,17235]
string: "test" [17440,17446]
===
match
---
name: dag [1231,1234]
name: dag [1271,1274]
===
match
---
name: test_localtaskjob_maintain_heart_rate [9043,9080]
name: test_localtaskjob_maintain_heart_rate [9254,9291]
===
match
---
name: object [13268,13274]
name: object [13479,13485]
===
match
---
arglist [6597,6660]
arglist [6808,6871]
===
match
---
atom_expr [9716,9781]
atom_expr [9927,9992]
===
match
---
name: DEFAULT_DATE [18908,18920]
name: DEFAULT_DATE [19259,19271]
===
match
---
name: tearDown [2273,2281]
name: tearDown [2313,2321]
===
match
---
operator: = [5096,5097]
operator: = [5307,5308]
===
match
---
name: State [7468,7473]
name: State [7679,7684]
===
match
---
atom_expr [11975,12012]
atom_expr [12186,12223]
===
match
---
arith_expr [6129,6134]
arith_expr [6340,6345]
===
match
---
name: test_heartbeat_failed_fast [4677,4703]
name: test_heartbeat_failed_fast [4888,4914]
===
match
---
trailer [19834,19905]
trailer [20185,20256]
===
match
---
operator: == [11487,11489]
operator: == [11698,11700]
===
match
---
number: 9 [20713,20714]
number: 9 [21118,21119]
===
match
---
number: 0 [17775,17776]
number: 0 [17986,17987]
===
match
---
argument [6995,7010]
argument [7206,7221]
===
match
---
name: create_dagrun [5229,5242]
name: create_dagrun [5440,5453]
===
match
---
name: state [13067,13072]
name: state [13278,13283]
===
match
---
expr_stmt [4294,4319]
expr_stmt [4455,4487]
===
match
---
operator: , [14348,14349]
operator: , [14559,14560]
===
match
---
trailer [17657,17665]
trailer [17868,17876]
===
match
---
simple_stmt [10280,10291]
simple_stmt [10491,10502]
===
match
---
trailer [4185,4203]
trailer [4346,4364]
===
match
---
atom_expr [7432,7452]
atom_expr [7643,7663]
===
match
---
trailer [5202,5211]
trailer [5413,5422]
===
match
---
name: State [8966,8971]
name: State [9177,9182]
===
match
---
import_from [1158,1210]
import_from [1198,1250]
===
match
---
arglist [5260,5456]
arglist [5471,5667]
===
match
---
string: 'dag_run' [18809,18818]
string: 'dag_run' [19160,19169]
===
match
---
trailer [8996,9002]
trailer [9207,9213]
===
match
---
trailer [8460,8466]
trailer [8671,8677]
===
match
---
testlist_comp [20708,20729]
testlist_comp [21113,21134]
===
match
---
name: session [5448,5455]
name: session [5659,5666]
===
match
---
arglist [16234,16240]
arglist [16445,16451]
===
match
---
operator: , [18568,18569]
operator: , [18919,18920]
===
match
---
number: 1 [20395,20396]
number: 1 [20800,20801]
===
match
---
classdef [20627,21472]
classdef [21032,21877]
===
match
---
atom_expr [15768,15776]
atom_expr [15979,15987]
===
match
---
name: dag [5190,5193]
name: dag [5401,5404]
===
match
---
operator: = [12613,12614]
operator: = [12824,12825]
===
match
---
name: AirflowException [1050,1066]
name: AirflowException [1090,1106]
===
match
---
assert_stmt [5998,6031]
assert_stmt [6209,6242]
===
match
---
name: ti [8364,8366]
name: ti [8575,8577]
===
match
---
name: context [13984,13991]
name: context [14195,14202]
===
match
---
with_item [10136,10200]
with_item [10347,10411]
===
match
---
name: time [19046,19050]
name: time [19397,19401]
===
match
---
trailer [14533,14541]
trailer [14744,14752]
===
match
---
argument [3929,3948]
argument [3935,3954]
===
match
---
simple_stmt [4008,4034]
simple_stmt [4014,4040]
===
match
---
expr_stmt [8082,8282]
expr_stmt [8293,8493]
===
match
---
atom_expr [12030,12062]
atom_expr [12241,12273]
===
match
---
string: """         Test that ensures that mark_failure in the UI fails         the task, and executes on_failure_callback         """ [10886,11012]
string: """         Test that ensures that mark_failure in the UI fails         the task, and executes on_failure_callback         """ [11097,11223]
===
match
---
trailer [8399,8408]
trailer [8610,8619]
===
match
---
simple_stmt [14684,14742]
simple_stmt [14895,14953]
===
match
---
operator: , [13379,13380]
operator: , [13590,13591]
===
match
---
name: heartbeat_callback [4474,4492]
name: heartbeat_callback [4678,4696]
===
match
---
trailer [13081,13088]
trailer [13292,13299]
===
match
---
name: dag [8087,8090]
name: dag [8298,8301]
===
match
---
name: state [17960,17965]
name: state [18171,18176]
===
match
---
operator: = [12809,12810]
operator: = [13020,13021]
===
match
---
number: 0 [11184,11185]
number: 0 [11395,11396]
===
match
---
name: State [7355,7360]
name: State [7566,7571]
===
match
---
parameters [13356,13393]
parameters [13567,13604]
===
match
---
name: dag [19434,19437]
name: dag [19785,19788]
===
match
---
operator: = [2890,2891]
operator: = [2930,2931]
===
match
---
name: return_value [21287,21299]
name: return_value [21692,21704]
===
match
---
trailer [18023,18030]
trailer [18234,18241]
===
match
---
with_stmt [10038,10394]
with_stmt [10249,10605]
===
match
---
arglist [9729,9780]
arglist [9940,9991]
===
match
---
string: 'test_state_succeeded1' [21069,21092]
string: 'test_state_succeeded1' [21474,21497]
===
match
---
atom_expr [21395,21409]
atom_expr [21800,21814]
===
match
---
operator: + [20724,20725]
operator: + [21129,21130]
===
match
---
suite [13787,14028]
suite [13998,14239]
===
match
---
argument [17360,17375]
argument [17571,17586]
===
match
---
name: dag [9280,9283]
name: dag [9491,9494]
===
match
---
decorator [13261,13310]
decorator [13472,13521]
===
match
---
trailer [18654,18656]
trailer [19005,19007]
===
match
---
string: 'i' [16234,16237]
string: 'i' [16445,16448]
===
match
---
trailer [17650,17657]
trailer [17861,17868]
===
match
---
atom_expr [21047,21102]
atom_expr [21452,21507]
===
match
---
expr_stmt [6679,6721]
expr_stmt [6890,6932]
===
match
---
trailer [9627,9667]
trailer [9838,9878]
===
match
---
operator: = [14195,14196]
operator: = [14406,14407]
===
match
---
name: State [14528,14533]
name: State [14739,14744]
===
match
---
argument [18055,18065]
argument [18266,18276]
===
match
---
simple_stmt [19046,19061]
simple_stmt [19397,19412]
===
match
---
operator: , [14255,14256]
operator: , [14466,14467]
===
match
---
name: success_callback [17075,17091]
name: success_callback [17286,17302]
===
match
---
trailer [2342,2344]
trailer [2382,2384]
===
match
---
name: MockExecutor [21395,21407]
name: MockExecutor [21800,21812]
===
match
---
name: dag [21112,21115]
name: dag [21517,21520]
===
match
---
name: DEFAULT_DATE [3805,3817]
name: DEFAULT_DATE [3811,3823]
===
match
---
simple_stmt [1784,1845]
simple_stmt [1824,1885]
===
match
---
operator: , [9478,9479]
operator: , [9689,9690]
===
match
---
name: time2 [6152,6157]
name: time2 [6363,6368]
===
match
---
name: session [6768,6775]
name: session [6979,6986]
===
match
---
operator: , [7161,7162]
operator: , [7372,7373]
===
match
---
name: start_date [14157,14167]
name: start_date [14368,14378]
===
match
---
argument [4493,4505]
argument [4697,4709]
===
match
---
operator: = [16974,16975]
operator: = [17185,17186]
===
match
---
name: Value [16279,16284]
name: Value [16490,16495]
===
match
---
decorated [9010,10824]
decorated [9221,11035]
===
match
---
arglist [17510,17579]
arglist [17721,17790]
===
match
---
name: refresh_from_db [7099,7114]
name: refresh_from_db [7310,7325]
===
match
---
atom_expr [5971,5985]
atom_expr [6182,6196]
===
match
---
name: state [9459,9464]
name: state [9670,9675]
===
match
---
name: value [19244,19249]
name: value [19595,19600]
===
match
---
name: DEFAULT_DATE [14168,14180]
name: DEFAULT_DATE [14379,14391]
===
match
---
trailer [4400,4404]
trailer [4568,4572]
===
match
---
atom_expr [11744,11756]
atom_expr [11955,11967]
===
match
---
name: task_terminated_externally [18132,18158]
name: task_terminated_externally [18343,18369]
===
match
---
name: execution_date [3790,3804]
name: execution_date [3796,3810]
===
match
---
name: task_instance [2998,3011]
name: task_instance [3038,3051]
===
match
---
operator: = [19268,19269]
operator: = [19619,19620]
===
match
---
name: SUCCESS [17974,17981]
name: SUCCESS [18185,18192]
===
match
---
trailer [6583,6670]
trailer [6794,6881]
===
match
---
name: db [1806,1808]
name: db [1846,1848]
===
match
---
number: 1 [11377,11378]
number: 1 [11588,11589]
===
match
---
suite [16869,16923]
suite [17080,17134]
===
match
---
simple_stmt [2080,2096]
simple_stmt [2120,2136]
===
match
---
name: task_runner [19919,19930]
name: task_runner [20270,20281]
===
match
---
trailer [18105,18111]
trailer [18316,18322]
===
match
---
name: ignore_ti_state [14818,14833]
name: ignore_ti_state [15029,15044]
===
match
---
argument [12520,12547]
argument [12731,12758]
===
match
---
string: 'start' [10076,10083]
string: 'start' [10287,10294]
===
match
---
comparison [11398,11446]
comparison [11609,11657]
===
match
---
number: 1 [6059,6060]
number: 1 [6270,6271]
===
match
---
trailer [13702,13710]
trailer [13913,13921]
===
match
---
assert_stmt [8947,8979]
assert_stmt [9158,9190]
===
match
---
sync_comp_for [3191,3217]
sync_comp_for [3231,3257]
===
match
---
arglist [19547,19701]
arglist [19898,20052]
===
match
---
name: DagBag [7786,7792]
name: DagBag [7997,8003]
===
match
---
atom_expr [5225,5470]
atom_expr [5436,5681]
===
match
---
name: timeout [15549,15556]
name: timeout [15760,15767]
===
match
---
atom_expr [14456,14675]
atom_expr [14667,14886]
===
match
---
string: "test" [19554,19560]
string: "test" [19905,19911]
===
match
---
trailer [20034,20051]
trailer [20385,20402]
===
match
---
simple_stmt [1519,1554]
simple_stmt [1559,1594]
===
match
---
trailer [7294,7296]
trailer [7505,7507]
===
match
---
param [5903,5910]
param [6114,6121]
===
match
---
simple_stmt [20282,20314]
simple_stmt [20690,20719]
===
match
---
argument [4988,5010]
argument [5199,5221]
===
match
---
name: run_id [8118,8124]
name: run_id [8329,8335]
===
match
---
arith_expr [6260,6273]
arith_expr [6471,6484]
===
match
---
expr_stmt [11733,11756]
expr_stmt [11944,11967]
===
match
---
name: dag_id [16489,16495]
name: dag_id [16700,16706]
===
match
---
dictorsetmaker [3579,3596]
dictorsetmaker [3585,3602]
===
match
---
name: latest_heartbeat [5941,5957]
name: latest_heartbeat [6152,6168]
===
match
---
funcdef [16335,16519]
funcdef [16546,16730]
===
match
---
name: Session [19477,19484]
name: Session [19828,19835]
===
match
---
atom_expr [13842,13871]
atom_expr [14053,14082]
===
match
---
suite [20530,20581]
suite [20935,20986]
===
match
---
trailer [11324,11326]
trailer [11535,11537]
===
match
---
atom_expr [5597,5610]
atom_expr [5808,5821]
===
match
---
trailer [20929,20935]
trailer [21334,21340]
===
match
---
name: settings [3472,3480]
name: settings [3478,3486]
===
match
---
atom_expr [4137,4157]
atom_expr [4143,4163]
===
match
---
operator: = [8552,8553]
operator: = [8763,8764]
===
match
---
operator: = [5188,5189]
operator: = [5399,5400]
===
match
---
name: execution_date [9492,9506]
name: execution_date [9703,9717]
===
match
---
argument [4128,4157]
argument [4134,4163]
===
match
---
name: task_instance [21368,21381]
name: task_instance [21773,21786]
===
match
---
name: context [13778,13785]
name: context [13989,13996]
===
match
---
name: ti [19786,19788]
name: ti [20137,20139]
===
match
---
trailer [11405,11416]
trailer [11616,11627]
===
match
---
simple_stmt [7620,7650]
simple_stmt [7831,7861]
===
match
---
atom_expr [21112,21123]
atom_expr [21517,21528]
===
match
---
param [18687,18694]
param [19038,19045]
===
match
---
simple_stmt [5142,5171]
simple_stmt [5353,5382]
===
match
---
arglist [1935,1945]
arglist [1975,1985]
===
match
---
name: session [8453,8460]
name: session [8664,8671]
===
match
---
name: SUCCESS [3769,3776]
name: SUCCESS [3775,3782]
===
match
---
operator: = [3841,3842]
operator: = [3847,3848]
===
match
---
operator: } [20980,20981]
operator: } [21385,21386]
===
match
---
name: RUNNING [7474,7481]
name: RUNNING [7685,7692]
===
match
---
name: dagbag [6685,6691]
name: dagbag [6896,6902]
===
match
---
name: ignore_ti_state [17528,17543]
name: ignore_ti_state [17739,17754]
===
match
---
operator: = [17523,17524]
operator: = [17734,17735]
===
match
---
argument [19749,19776]
argument [20100,20127]
===
match
---
atom_expr [15452,15468]
atom_expr [15663,15679]
===
match
---
arglist [12761,12830]
arglist [12972,13041]
===
match
---
expr_stmt [16528,16624]
expr_stmt [16739,16835]
===
match
---
parameters [18259,18265]
parameters [3452,3458]
===
match
---
trailer [20334,20346]
trailer [20739,20751]
===
match
---
expr_stmt [5836,5858]
expr_stmt [6047,6069]
===
match
---
name: dr [2779,2781]
name: dr [2819,2821]
===
match
---
name: task [19738,19742]
name: task [20089,20093]
===
match
---
simple_stmt [942,974]
simple_stmt [942,974]
===
match
---
operator: , [19873,19874]
operator: , [20224,20225]
===
match
---
atom_expr [8034,8052]
atom_expr [8245,8263]
===
match
---
parameters [20527,20529]
parameters [20932,20934]
===
match
---
suite [3617,3665]
suite [3623,3671]
===
match
---
name: hostname [5626,5634]
name: hostname [5837,5845]
===
match
---
operator: , [9556,9557]
operator: , [9767,9768]
===
match
---
parameters [16651,16655]
parameters [16862,16866]
===
match
---
trailer [16439,16445]
trailer [16650,16656]
===
match
---
operator: , [8164,8165]
operator: , [8375,8376]
===
match
---
name: job1 [17627,17631]
name: job1 [17838,17842]
===
match
---
name: job1 [10280,10284]
name: job1 [10491,10495]
===
match
---
name: job [5871,5874]
name: job [6082,6085]
===
match
---
argument [19337,19366]
argument [19688,19717]
===
match
---
name: execution_date [14559,14573]
name: execution_date [14770,14784]
===
match
---
name: clean_db_helper [20512,20527]
name: clean_db_helper [20917,20932]
===
match
---
trailer [11847,11851]
trailer [12058,12062]
===
match
---
comparison [13896,13953]
comparison [14107,14164]
===
match
---
trailer [9404,9418]
trailer [9615,9629]
===
match
---
name: utils [1659,1664]
name: utils [1699,1704]
===
match
---
name: state [5317,5322]
name: state [5528,5533]
===
match
---
number: 1 [18621,18622]
number: 1 [18972,18973]
===
match
---
simple_stmt [6806,6818]
simple_stmt [7017,7029]
===
match
---
trailer [9418,9596]
trailer [9629,9807]
===
match
---
name: airflow [995,1002]
name: airflow [1035,1042]
===
match
---
atom_expr [12489,12502]
atom_expr [12700,12713]
===
match
---
trailer [4830,4842]
trailer [5041,5053]
===
match
---
dotted_name [9011,9034]
dotted_name [9222,9245]
===
match
---
name: task_id [8317,8324]
name: task_id [8528,8535]
===
match
---
trailer [7568,7575]
trailer [7779,7786]
===
match
---
name: job1 [2978,2982]
name: job1 [3018,3022]
===
match
---
name: heartbeat_records [6111,6128]
name: heartbeat_records [6322,6339]
===
match
---
name: DAG [16534,16537]
name: DAG [16745,16748]
===
match
---
expr_stmt [20905,20938]
expr_stmt [21310,21343]
===
match
---
with_stmt [16378,16451]
with_stmt [16589,16662]
===
match
---
atom_expr [16416,16445]
atom_expr [16627,16656]
===
match
---
name: executor [14840,14848]
name: executor [15051,15059]
===
match
---
operator: = [8192,8193]
operator: = [8403,8404]
===
match
---
argument [12674,12701]
argument [12885,12912]
===
match
---
name: run [10285,10288]
name: run [10496,10499]
===
match
---
trailer [19737,19777]
trailer [20088,20128]
===
match
---
name: airflow [1163,1170]
name: airflow [1203,1210]
===
match
---
trailer [5242,5470]
trailer [5453,5681]
===
match
---
simple_stmt [2715,2750]
simple_stmt [2755,2790]
===
match
---
operator: = [4373,4374]
operator: = [4541,4542]
===
match
---
name: execution_date [7059,7073]
name: execution_date [7270,7284]
===
match
---
atom_expr [10497,10507]
atom_expr [10708,10718]
===
match
---
name: dag [5142,5145]
name: dag [5353,5356]
===
match
---
name: ti [2922,2924]
name: ti [2962,2964]
===
match
---
operator: = [9506,9507]
operator: = [9717,9718]
===
match
---
simple_stmt [19967,19993]
simple_stmt [20318,20344]
===
match
---
name: state [3757,3762]
name: state [3763,3768]
===
match
---
with_item [8694,8769]
with_item [8905,8980]
===
match
---
name: jobs [1171,1175]
name: jobs [1211,1215]
===
match
---
arglist [14702,14740]
arglist [14913,14951]
===
match
---
operator: = [4136,4137]
operator: = [4142,4143]
===
match
---
param [7762,7766]
param [7973,7977]
===
match
---
argument [6958,6981]
argument [7169,7192]
===
match
---
expr_stmt [4328,4352]
expr_stmt [4496,4520]
===
match
---
trailer [19050,19056]
trailer [19401,19407]
===
match
---
name: DEFAULT_DATE [1902,1914]
name: DEFAULT_DATE [1942,1954]
===
match
---
name: context [11265,11272]
name: context [11476,11483]
===
match
---
name: ti [17957,17959]
name: ti [18168,18170]
===
match
---
name: dagbag [6568,6574]
name: dagbag [6779,6785]
===
match
---
trailer [2801,2913]
trailer [2841,2953]
===
match
---
atom_expr [6890,6903]
atom_expr [7101,7114]
===
match
---
name: task_terminated_externally [12030,12056]
name: task_terminated_externally [12241,12267]
===
match
---
trailer [15556,15560]
trailer [15767,15771]
===
match
---
assert_stmt [17916,17948]
assert_stmt [18127,18159]
===
match
---
atom_expr [8966,8979]
atom_expr [9177,9190]
===
match
---
dotted_name [1251,1272]
dotted_name [1291,1312]
===
match
---
name: value [12057,12062]
name: value [12268,12273]
===
match
---
argument [12606,12621]
argument [12817,12832]
===
match
---
comparison [18801,18849]
comparison [19152,19200]
===
match
---
operator: = [7002,7003]
operator: = [7213,7214]
===
match
---
operator: = [19579,19580]
operator: = [19930,19931]
===
match
---
argument [18897,18920]
argument [19248,19271]
===
match
---
expr_stmt [5183,5211]
expr_stmt [5394,5422]
===
match
---
operator: = [3804,3805]
operator: = [3810,3811]
===
match
---
name: sleep [20222,20227]
name: sleep [20596,20601]
===
match
---
trailer [3677,3683]
trailer [3683,3689]
===
match
---
name: TaskInstance [21204,21216]
name: TaskInstance [21609,21621]
===
match
---
simple_stmt [7658,7679]
simple_stmt [7869,7890]
===
match
---
name: ignore_ti_state [19853,19868]
name: ignore_ti_state [20204,20219]
===
match
---
operator: = [7233,7234]
operator: = [7444,7445]
===
match
---
operator: = [3697,3698]
operator: = [3703,3704]
===
match
---
name: side_effects [21312,21324]
name: side_effects [21717,21729]
===
match
---
name: State [9465,9470]
name: State [9676,9681]
===
match
---
name: models [1259,1265]
name: models [1299,1305]
===
match
---
operator: , [20705,20706]
operator: , [21110,21111]
===
match
---
string: "airflow.jobs.local_task_job.get_task_runner" [20764,20809]
string: "airflow.jobs.local_task_job.get_task_runner" [21169,21214]
===
match
---
name: session [8347,8354]
name: session [8558,8565]
===
match
---
name: TaskInstance [1327,1339]
name: TaskInstance [1367,1379]
===
match
---
operator: - [15474,15475]
operator: - [15685,15686]
===
match
---
trailer [3702,3716]
trailer [3708,3722]
===
match
---
name: session [10808,10815]
name: session [11019,11026]
===
match
---
name: mock_base_job_sleep [2226,2245]
name: mock_base_job_sleep [2266,2285]
===
match
---
operator: = [8346,8347]
operator: = [8557,8558]
===
match
---
name: run_id [3730,3736]
name: run_id [3736,3742]
===
match
---
suite [15561,15723]
suite [15772,15934]
===
match
---
trailer [16477,16488]
trailer [16688,16699]
===
match
---
name: join [7595,7599]
name: join [7806,7810]
===
match
---
trailer [9228,9264]
trailer [9439,9475]
===
match
---
simple_stmt [9273,9334]
simple_stmt [9484,9545]
===
match
---
simple_stmt [812,822]
simple_stmt [812,822]
===
match
---
name: DummyOperator [3636,3649]
name: DummyOperator [3642,3655]
===
match
---
trailer [18808,18819]
trailer [19159,19170]
===
match
---
atom_expr [13896,13921]
atom_expr [14107,14132]
===
match
---
name: session [3868,3875]
name: session [3874,3881]
===
match
---
atom_expr [7561,7577]
atom_expr [7772,7788]
===
match
---
name: mock_executor [1867,1880]
name: mock_executor [1907,1920]
===
match
---
atom_expr [8852,8911]
atom_expr [9063,9122]
===
match
---
param [11265,11272]
param [11476,11483]
===
match
---
import_name [836,847]
import_name [836,847]
===
match
---
name: ti_run [8642,8648]
name: ti_run [8853,8859]
===
match
---
atom_expr [8989,9004]
atom_expr [9200,9215]
===
match
---
simple_stmt [18275,18399]
simple_stmt [18615,18750]
===
match
---
operator: , [8893,8894]
operator: , [9104,9105]
===
match
---
simple_stmt [11459,11525]
simple_stmt [11670,11736]
===
match
---
param [20860,20881]
param [21265,21286]
===
match
---
operator: = [6776,6777]
operator: = [6987,6988]
===
match
---
name: DEFAULT_DATE [8193,8205]
name: DEFAULT_DATE [8404,8416]
===
match
---
simple_stmt [17490,17581]
simple_stmt [17701,17792]
===
match
---
name: AirflowException [4569,4585]
name: AirflowException [4780,4796]
===
match
---
operator: = [7959,7960]
operator: = [8170,8171]
===
match
---
name: get_hostname [4375,4387]
name: get_hostname [4543,4555]
===
match
---
name: ti [8397,8399]
name: ti [8608,8610]
===
match
---
name: self [10441,10445]
name: self [10652,10656]
===
match
---
trailer [19902,19904]
trailer [20253,20255]
===
match
---
operator: = [17333,17334]
operator: = [17544,17545]
===
match
---
name: is_alive [20477,20485]
name: is_alive [20882,20890]
===
match
---
operator: = [2821,2822]
operator: = [2861,2862]
===
match
---
name: dag_id [12085,12091]
name: dag_id [12296,12302]
===
match
---
atom [20717,20723]
atom [21122,21128]
===
match
---
atom_expr [14849,14869]
atom_expr [15060,15080]
===
match
---
assert_stmt [13147,13191]
assert_stmt [13358,13402]
===
match
---
name: start_date [8219,8229]
name: start_date [8430,8440]
===
match
---
name: dag [2557,2560]
name: dag [2597,2600]
===
match
---
arglist [9628,9666]
arglist [9839,9877]
===
match
---
name: State [13076,13081]
name: State [13287,13292]
===
match
---
param [4704,4708]
param [4915,4919]
===
match
---
expr_stmt [11195,11237]
expr_stmt [11406,11448]
===
match
---
name: mock [20753,20757]
name: mock [21158,21162]
===
match
---
name: execution_date [19607,19621]
name: execution_date [19958,19972]
===
match
---
funcdef [11534,12067]
funcdef [11745,12278]
===
match
---
operator: , [17346,17347]
operator: , [17557,17558]
===
match
---
operator: , [17235,17236]
operator: , [17446,17447]
===
match
---
argument [17323,17346]
argument [17534,17557]
===
match
---
name: ti [15732,15734]
name: ti [15943,15945]
===
match
---
trailer [17509,17580]
trailer [17720,17791]
===
match
---
atom_expr [3356,3375]
atom_expr [3396,3415]
===
match
---
name: task_id [5088,5095]
name: task_id [5299,5306]
===
match
---
name: DEFAULT_DATE [14728,14740]
name: DEFAULT_DATE [14939,14951]
===
match
---
name: heartbeat_records [6066,6083]
name: heartbeat_records [6277,6294]
===
match
---
simple_stmt [19458,19487]
simple_stmt [19809,19838]
===
match
---
suite [12404,12637]
suite [12615,12848]
===
match
---
simple_stmt [21462,21472]
simple_stmt [21867,21877]
===
match
---
operator: , [13361,13362]
operator: , [13572,13573]
===
match
---
simple_stmt [12741,12832]
simple_stmt [12952,13043]
===
match
---
atom_expr [2721,2749]
atom_expr [2761,2789]
===
match
---
name: state [14522,14527]
name: state [14733,14738]
===
match
---
atom_expr [11344,11373]
atom_expr [11555,11584]
===
match
---
atom_expr [20953,21031]
atom_expr [21358,21436]
===
match
---
operator: , [12672,12673]
operator: , [12883,12884]
===
match
---
operator: = [9211,9212]
operator: = [9422,9423]
===
match
---
name: session [19458,19465]
name: session [19809,19816]
===
match
---
with_stmt [4167,4285]
with_stmt [4328,4446]
===
match
---
trailer [2947,2968]
trailer [2987,3008]
===
match
---
name: dag [17191,17194]
name: dag [17402,17405]
===
match
---
string: 'test_exit_on_failure' [14233,14255]
string: 'test_exit_on_failure' [14444,14466]
===
match
---
name: dag [2698,2701]
name: dag [2738,2741]
===
match
---
name: task_instance [14800,14813]
name: task_instance [15011,15024]
===
match
---
name: create_dagrun [17195,17208]
name: create_dagrun [17406,17419]
===
match
---
argument [19875,19904]
argument [20226,20255]
===
match
---
trailer [4450,4457]
trailer [4618,4625]
===
match
---
argument [8628,8648]
argument [8839,8859]
===
match
---
operator: = [2719,2720]
operator: = [2759,2760]
===
match
---
simple_stmt [7125,7185]
simple_stmt [7336,7396]
===
match
---
name: session [11773,11780]
name: session [11984,11991]
===
match
---
name: utils [1532,1537]
name: utils [1572,1577]
===
match
---
name: success_callback_called [16416,16439]
name: success_callback_called [16627,16650]
===
match
---
suite [20661,21472]
suite [21066,21877]
===
match
---
name: DummyOperator [1376,1389]
name: DummyOperator [1416,1429]
===
match
---
operator: , [908,909]
operator: , [908,909]
===
match
---
name: session [8895,8902]
name: session [9106,9113]
===
match
---
operator: = [5486,5487]
operator: = [5697,5698]
===
match
---
atom_expr [13741,13747]
atom_expr [13952,13958]
===
match
---
trailer [11749,11756]
trailer [11960,11967]
===
match
---
simple_stmt [5998,6032]
simple_stmt [6209,6243]
===
match
---
atom_expr [3674,3685]
atom_expr [3680,3691]
===
match
---
name: state [20251,20256]
name: state [20625,20630]
===
match
---
trailer [13016,13018]
trailer [13227,13229]
===
match
---
name: dag [21132,21135]
name: dag [21537,21540]
===
match
---
name: essential_attr [3203,3217]
name: essential_attr [3243,3257]
===
match
---
name: append [5930,5936]
name: append [6141,6147]
===
match
---
name: refresh_from_db [9683,9698]
name: refresh_from_db [9894,9909]
===
match
---
name: join [18050,18054]
name: join [18261,18265]
===
match
---
operator: , [21226,21227]
operator: , [21631,21632]
===
match
---
argument [19853,19873]
argument [20204,20224]
===
match
---
operator: == [10389,10391]
operator: == [10600,10602]
===
match
---
trailer [5328,5336]
trailer [5539,5547]
===
match
---
name: dag [17105,17108]
name: dag [17316,17319]
===
match
---
number: 1 [8443,8444]
number: 1 [8654,8655]
===
match
---
name: multiprocessing [796,811]
name: multiprocessing [796,811]
===
match
---
atom_expr [9676,9700]
atom_expr [9887,9911]
===
match
---
import_from [916,941]
import_from [916,941]
===
match
---
arglist [8118,8272]
arglist [8329,8483]
===
match
---
comparison [8927,8938]
comparison [9138,9149]
===
match
---
suite [15420,15477]
suite [15631,15688]
===
match
---
simple_stmt [4600,4668]
simple_stmt [4811,4879]
===
match
---
trailer [13180,13186]
trailer [13391,13397]
===
match
---
name: DagBag [9105,9111]
name: DagBag [9316,9322]
===
match
---
name: dag [2759,2762]
name: dag [2799,2802]
===
match
---
name: isinstance [13973,13983]
name: isinstance [14184,14194]
===
match
---
assert_stmt [16463,16518]
assert_stmt [16674,16729]
===
match
---
expr_stmt [9096,9198]
expr_stmt [9307,9409]
===
match
---
name: patch [20758,20763]
name: patch [21163,21168]
===
match
---
trailer [8706,8754]
trailer [8917,8965]
===
match
---
name: side_effect [15503,15514]
name: side_effect [15714,15725]
===
match
---
trailer [19982,19990]
trailer [20333,20341]
===
match
---
trailer [4178,4185]
trailer [4339,4346]
===
match
---
operator: , [8271,8272]
operator: , [8482,8483]
===
match
---
operator: == [7482,7484]
operator: == [7693,7695]
===
match
---
argument [8873,8893]
argument [9084,9104]
===
match
---
name: get_task [9284,9292]
name: get_task [9495,9503]
===
match
---
name: LocalTaskJob [14787,14799]
name: LocalTaskJob [14998,15010]
===
match
---
string: "test_heartbeat_failed_fast_run" [5267,5299]
string: "test_heartbeat_failed_fast_run" [5478,5510]
===
match
---
atom_expr [7096,7116]
atom_expr [7307,7327]
===
match
---
name: self [13357,13361]
name: self [13568,13572]
===
match
---
name: on_failure_callback [19380,19399]
name: on_failure_callback [19731,19750]
===
match
---
name: ti [17831,17833]
name: ti [18042,18044]
===
match
---
atom_expr [2305,2320]
atom_expr [2345,2360]
===
match
---
name: range [20094,20099]
name: range [20445,20450]
===
match
---
operator: , [16589,16590]
operator: , [16800,16801]
===
match
---
operator: = [2561,2562]
operator: = [2601,2602]
===
match
---
import_name [975,988]
import_name [975,988]
===
match
---
name: patcher [2199,2206]
name: patcher [2239,2246]
===
match
---
argument [17710,17725]
argument [17921,17936]
===
match
---
simple_stmt [7535,7553]
simple_stmt [7746,7764]
===
match
---
name: ti [12711,12713]
name: ti [12922,12924]
===
match
---
simple_stmt [20947,21032]
simple_stmt [21352,21437]
===
match
---
operator: = [16277,16278]
operator: = [16488,16489]
===
match
---
funcdef [9932,9996]
funcdef [10143,10207]
===
match
---
name: object [10049,10055]
name: object [10260,10266]
===
match
---
simple_stmt [16932,17124]
simple_stmt [17143,17335]
===
match
---
trailer [11821,11823]
trailer [12032,12034]
===
match
---
name: delta [6318,6323]
name: delta [6529,6534]
===
match
---
name: DEFAULT_DATE [19659,19671]
name: DEFAULT_DATE [20010,20022]
===
match
---
simple_stmt [17795,17816]
simple_stmt [18006,18027]
===
match
---
operator: , [19851,19852]
operator: , [20202,20203]
===
match
---
name: multi_return_code [9936,9953]
name: multi_return_code [10147,10164]
===
match
---
name: session [12396,12403]
name: session [12607,12614]
===
match
---
dotted_name [1689,1710]
dotted_name [1729,1750]
===
match
---
arglist [16538,16623]
arglist [16749,16834]
===
match
---
name: refresh_from_db [5556,5571]
name: refresh_from_db [5767,5782]
===
match
---
simple_stmt [9709,9782]
simple_stmt [9920,9993]
===
match
---
simple_stmt [8920,8939]
simple_stmt [9131,9150]
===
match
---
atom_expr [15780,15792]
atom_expr [15991,16003]
===
match
---
arglist [17413,17451]
arglist [17624,17662]
===
match
---
atom_expr [11773,11790]
atom_expr [11984,12001]
===
match
---
name: settings [8034,8042]
name: settings [8245,8253]
===
match
---
name: task_id [3650,3657]
name: task_id [3656,3663]
===
match
---
atom_expr [17935,17948]
atom_expr [18146,18159]
===
match
---
not_test [15448,15468]
not_test [15659,15679]
===
match
---
trailer [3288,3300]
trailer [3328,3340]
===
match
---
operator: , [19700,19701]
operator: , [20051,20052]
===
match
---
trailer [2841,2849]
trailer [2881,2889]
===
match
---
name: ti [14814,14816]
name: ti [15025,15027]
===
match
---
name: ti [13064,13066]
name: ti [13275,13277]
===
match
---
simple_stmt [18747,18782]
simple_stmt [19098,19133]
===
match
---
param [10871,10875]
param [11082,11086]
===
match
---
atom_expr [7587,7611]
atom_expr [7798,7822]
===
match
---
operator: , [1829,1830]
operator: , [1869,1870]
===
match
---
operator: = [5447,5448]
operator: = [5658,5659]
===
match
---
trailer [17973,17981]
trailer [18184,18192]
===
match
---
simple_stmt [7502,7527]
simple_stmt [7713,7738]
===
match
---
name: State [17255,17260]
name: State [17466,17471]
===
match
---
simple_stmt [14190,14381]
simple_stmt [14401,14592]
===
match
---
simple_stmt [11344,11379]
simple_stmt [11555,11590]
===
match
---
name: context [18687,18694]
name: context [19038,19045]
===
match
---
atom_expr [17990,18007]
atom_expr [18201,18218]
===
match
---
argument [9459,9478]
argument [9670,9689]
===
match
---
name: mock_return_code [13363,13379]
name: mock_return_code [13574,13590]
===
match
---
atom_expr [19967,19992]
atom_expr [20318,20343]
===
match
---
atom_expr [10808,10823]
atom_expr [11019,11034]
===
match
---
name: mock_method [8758,8769]
name: mock_method [8969,8980]
===
match
---
simple_stmt [10886,11013]
simple_stmt [11097,11224]
===
match
---
name: airflow [1094,1101]
name: airflow [1134,1141]
===
match
---
operator: , [16237,16238]
operator: , [16448,16449]
===
match
---
atom_expr [14078,14100]
atom_expr [14289,14311]
===
match
---
operator: = [6575,6576]
operator: = [6786,6787]
===
match
---
trailer [19284,19448]
trailer [19635,19799]
===
match
---
atom_expr [13697,13710]
atom_expr [13908,13921]
===
match
---
atom_expr [8615,8680]
atom_expr [8826,8891]
===
match
---
trailer [6691,6696]
trailer [6902,6907]
===
match
---
string: 'owner' [18936,18943]
string: 'owner' [19287,19294]
===
match
---
atom_expr [17191,17386]
atom_expr [17402,17597]
===
match
---
operator: , [16564,16565]
operator: , [16775,16776]
===
match
---
name: engine [17651,17657]
name: engine [17862,17868]
===
match
---
name: delta [6251,6256]
name: delta [6462,6467]
===
match
---
trailer [7226,7243]
trailer [7437,7454]
===
match
---
operator: = [9613,9614]
operator: = [9824,9825]
===
match
---
operator: = [5762,5763]
operator: = [5973,5974]
===
match
---
name: mock_base_job_sleep [10446,10465]
name: mock_base_job_sleep [10657,10676]
===
match
---
simple_stmt [8575,8600]
simple_stmt [8786,8811]
===
match
---
trailer [9682,9698]
trailer [9893,9909]
===
match
---
param [2387,2391]
param [2427,2431]
===
match
---
argument [6597,6623]
argument [6808,6834]
===
match
---
expr_stmt [10218,10263]
expr_stmt [10429,10474]
===
match
---
trailer [4623,4625]
trailer [4834,4836]
===
match
---
trailer [14768,14770]
trailer [14979,14981]
===
match
---
simple_stmt [7404,7420]
simple_stmt [7615,7631]
===
match
---
name: LocalTaskJob [19822,19834]
name: LocalTaskJob [20173,20185]
===
match
---
simple_stmt [19720,19778]
simple_stmt [20071,20129]
===
match
---
name: pytest [20667,20673]
name: pytest [21072,21078]
===
match
---
atom_expr [9213,9264]
atom_expr [9424,9475]
===
match
---
atom_expr [13154,13186]
atom_expr [13365,13397]
===
match
---
argument [8895,8910]
argument [9106,9121]
===
match
---
atom_expr [17843,17856]
atom_expr [18054,18067]
===
match
---
operator: - [6324,6325]
operator: - [6535,6536]
===
match
---
number: 0 [16921,16922]
number: 0 [17132,17133]
===
match
---
operator: = [8085,8086]
operator: = [8296,8297]
===
match
---
name: LocalTaskJob [2985,2997]
name: LocalTaskJob [3025,3037]
===
match
---
simple_stmt [1947,2006]
simple_stmt [1987,2046]
===
match
---
atom_expr [11398,11423]
atom_expr [11609,11634]
===
match
---
operator: = [8902,8903]
operator: = [9113,9114]
===
match
---
arglist [13275,13308]
arglist [13486,13519]
===
match
---
atom_expr [10043,10103]
atom_expr [10254,10314]
===
match
---
string: "job_type" [3106,3116]
string: "job_type" [3146,3156]
===
match
---
name: ti [5623,5625]
name: ti [5834,5836]
===
match
---
string: "Marking TI as failed 'externally'" [11680,11715]
string: "Marking TI as failed 'externally'" [11891,11926]
===
match
---
string: "return_codes" [20691,20705]
string: "return_codes" [21096,21110]
===
match
---
name: job1 [9709,9713]
name: job1 [9920,9924]
===
match
---
dotted_name [20753,20763]
dotted_name [21158,21168]
===
match
---
atom_expr [5871,5893]
atom_expr [6082,6104]
===
match
---
trailer [12360,12362]
trailer [12571,12573]
===
match
---
operator: = [3470,3471]
operator: = [3476,3477]
===
match
---
operator: = [9653,9654]
operator: = [9864,9865]
===
match
---
simple_stmt [2104,2120]
simple_stmt [2144,2160]
===
match
---
name: SUCCESS [7700,7707]
name: SUCCESS [7911,7918]
===
match
---
suite [2296,2345]
suite [2336,2385]
===
match
---
simple_stmt [5586,5611]
simple_stmt [5797,5822]
===
match
---
assert_stmt [15834,15875]
assert_stmt [16045,16086]
===
match
---
name: pid [8930,8933]
name: pid [9141,9144]
===
match
---
trailer [6274,6288]
trailer [6485,6499]
===
match
---
suite [4204,4285]
suite [4365,4446]
===
match
---
expr_stmt [11147,11186]
expr_stmt [11358,11397]
===
match
---
decorator [13197,13257]
decorator [13408,13468]
===
match
---
name: job1 [8608,8612]
name: job1 [8819,8823]
===
match
---
trailer [7487,7493]
trailer [7698,7704]
===
match
---
simple_stmt [7587,7612]
simple_stmt [7798,7823]
===
match
---
number: 1 [1944,1945]
number: 1 [1984,1985]
===
match
---
name: task [1455,1459]
name: task [1495,1499]
===
match
---
argument [3730,3743]
argument [3736,3749]
===
match
---
expr_stmt [4361,4389]
expr_stmt [4529,4557]
===
match
---
arglist [19738,19776]
arglist [20089,20127]
===
match
---
simple_stmt [14456,14676]
simple_stmt [14667,14887]
===
match
---
operator: = [5526,5527]
operator: = [5737,5738]
===
match
---
name: ti [17923,17925]
name: ti [18134,18136]
===
match
---
expr_stmt [3499,3598]
expr_stmt [3505,3604]
===
match
---
trailer [7713,7719]
trailer [7924,7930]
===
match
---
operator: @ [20490,20491]
operator: @ [20895,20896]
===
match
---
atom_expr [17831,17839]
atom_expr [18042,18050]
===
match
---
trailer [8042,8050]
trailer [8253,8261]
===
match
---
atom_expr [2836,2849]
atom_expr [2876,2889]
===
match
---
atom_expr [13064,13072]
atom_expr [13275,13283]
===
match
---
simple_stmt [9401,9597]
simple_stmt [9612,9808]
===
match
---
name: run [20047,20050]
name: run [20398,20401]
===
match
---
name: ti_run [9606,9612]
name: ti_run [9817,9823]
===
match
---
name: execution_date [5512,5526]
name: execution_date [5723,5737]
===
match
---
expr_stmt [7125,7184]
expr_stmt [7336,7395]
===
match
---
atom_expr [19786,19806]
atom_expr [20137,20157]
===
match
---
suite [11327,11379]
suite [11538,11590]
===
match
---
operator: , [14586,14587]
operator: , [14797,14798]
===
match
---
name: self [10871,10875]
name: self [11082,11086]
===
match
---
lambdef [5896,5958]
lambdef [6107,6169]
===
match
---
trailer [12084,12137]
trailer [12295,12348]
===
match
---
simple_stmt [18125,18170]
simple_stmt [18336,18381]
===
match
---
arglist [11230,11236]
arglist [11441,11447]
===
match
---
trailer [10284,10288]
trailer [10495,10499]
===
match
---
simple_stmt [3674,3686]
simple_stmt [3680,3692]
===
match
---
assert_stmt [3349,3375]
assert_stmt [3389,3415]
===
match
---
name: start_date [2880,2890]
name: start_date [2920,2930]
===
match
---
name: dag [19430,19433]
name: dag [19781,19784]
===
match
---
atom_expr [9465,9478]
atom_expr [9676,9689]
===
match
---
comparison [10441,10481]
comparison [10652,10692]
===
match
---
name: task [17418,17422]
name: task [17629,17633]
===
match
---
simple_stmt [12711,12732]
simple_stmt [12922,12943]
===
match
---
simple_stmt [4911,5026]
simple_stmt [5122,5237]
===
match
---
name: task_terminated_externally [11975,12001]
name: task_terminated_externally [12186,12212]
===
match
---
suite [14443,14676]
suite [14654,14887]
===
match
---
atom [3280,3340]
atom [3320,3380]
===
match
---
trailer [16537,16624]
trailer [16748,16835]
===
match
---
simple_stmt [21040,21103]
simple_stmt [21445,21508]
===
match
---
simple_stmt [1646,1684]
simple_stmt [1686,1724]
===
match
---
number: 0 [9920,9921]
number: 0 [10131,10132]
===
match
---
name: executor [17550,17558]
name: executor [17761,17769]
===
match
---
assert_stmt [20355,20396]
assert_stmt [20760,20801]
===
match
---
trailer [14098,14100]
trailer [14309,14311]
===
match
---
name: unittest [2031,2039]
name: unittest [2071,2079]
===
match
---
atom_expr [2221,2245]
atom_expr [2261,2285]
===
match
---
operator: = [17074,17075]
operator: = [17285,17286]
===
match
---
trailer [17208,17386]
trailer [17419,17597]
===
match
---
argument [17413,17422]
argument [17624,17633]
===
match
---
string: 'test_heartbeat_failed_fast_op' [5098,5129]
string: 'test_heartbeat_failed_fast_op' [5309,5340]
===
match
---
name: ti [5750,5752]
name: ti [5961,5963]
===
match
---
name: hostname [8400,8408]
name: hostname [8611,8619]
===
match
---
simple_stmt [3630,3665]
simple_stmt [3636,3671]
===
match
---
simple_stmt [848,864]
simple_stmt [848,864]
===
match
---
atom_expr [15841,15870]
atom_expr [16052,16081]
===
match
---
name: state [7714,7719]
name: state [7925,7930]
===
match
---
name: task_function [11538,11551]
name: task_function [11749,11762]
===
match
---
string: 'owner1' [3588,3596]
string: 'owner1' [3594,3602]
===
match
---
with_item [10043,10117]
with_item [10254,10328]
===
match
---
atom_expr [12845,12856]
atom_expr [13056,13067]
===
match
---
trailer [7575,7577]
trailer [7786,7788]
===
match
---
name: task [9633,9637]
name: task [9844,9848]
===
match
---
string: 'i' [18616,18619]
string: 'i' [18967,18970]
===
match
---
name: time [16715,16719]
name: time [16926,16930]
===
match
---
name: mock_start [10107,10117]
name: mock_start [10318,10328]
===
match
---
name: target [20035,20041]
name: target [20386,20392]
===
match
---
trailer [8065,8071]
trailer [8276,8282]
===
match
---
trailer [4240,4242]
trailer [4401,4403]
===
match
---
atom_expr [11574,11590]
atom_expr [11785,11801]
===
match
---
argument [7163,7183]
argument [7374,7394]
===
match
---
name: task_id [19298,19305]
name: task_id [19649,19656]
===
match
---
dotted_name [1789,1808]
dotted_name [1829,1848]
===
match
---
name: mock_ret_code [10187,10200]
name: mock_ret_code [10398,10411]
===
match
---
dotted_name [20491,20505]
dotted_name [20896,20910]
===
match
---
trailer [16719,16725]
trailer [16930,16936]
===
match
---
trailer [17774,17781]
trailer [17985,17992]
===
match
---
operator: = [8124,8125]
operator: = [8335,8336]
===
match
---
name: Value [18559,18564]
name: Value [18910,18915]
===
match
---
trailer [3683,3685]
trailer [3689,3691]
===
match
---
name: refresh_from_db [12714,12729]
name: refresh_from_db [12925,12940]
===
match
---
name: DEFAULT_DATE [14615,14627]
name: DEFAULT_DATE [14826,14838]
===
match
---
trailer [7414,7419]
trailer [7625,7630]
===
match
---
name: dag_id [14120,14126]
name: dag_id [14331,14337]
===
match
---
name: DagBag [6577,6583]
name: DagBag [6788,6794]
===
match
---
trailer [2225,2245]
trailer [2265,2285]
===
match
---
name: include_examples [6637,6653]
name: include_examples [6848,6864]
===
match
---
name: task_terminated_externally [13154,13180]
name: task_terminated_externally [13365,13391]
===
match
---
name: signal [20298,20304]
name: signal [18470,18476]
===
match
---
expr_stmt [7030,7087]
expr_stmt [7241,7298]
===
match
---
expr_stmt [4398,4408]
expr_stmt [4566,4576]
===
match
---
argument [5776,5791]
argument [5987,6002]
===
match
---
arglist [13984,14026]
arglist [14195,14237]
===
match
---
simple_stmt [14072,14101]
simple_stmt [14283,14312]
===
match
---
name: refresh_from_db [15735,15750]
name: refresh_from_db [15946,15961]
===
match
---
trailer [13865,13871]
trailer [14076,14082]
===
match
---
name: session [4493,4500]
name: session [4697,4704]
===
match
---
number: 0 [20727,20728]
number: 0 [21132,21133]
===
match
---
operator: , [14369,14370]
operator: , [14580,14581]
===
match
---
operator: = [8880,8881]
operator: = [9091,9092]
===
match
---
simple_stmt [7252,7268]
simple_stmt [7463,7479]
===
match
---
operator: , [3130,3131]
operator: , [3170,3171]
===
match
---
name: FAILED [13082,13088]
name: FAILED [13293,13299]
===
match
---
name: join [20330,20334]
name: join [20735,20739]
===
match
---
name: run_id [12452,12458]
name: run_id [12663,12669]
===
match
---
argument [19685,19700]
argument [20036,20051]
===
match
---
expr_stmt [8364,8388]
expr_stmt [8575,8599]
===
match
---
trailer [13066,13072]
trailer [13277,13283]
===
match
---
name: TaskInstance [17400,17412]
name: TaskInstance [17611,17623]
===
match
---
name: state [11736,11741]
name: state [11947,11952]
===
match
---
trailer [10417,10422]
trailer [10628,10633]
===
match
---
trailer [8436,8440]
trailer [8647,8651]
===
match
---
with_stmt [21419,21472]
with_stmt [21824,21877]
===
match
---
name: LocalTaskJob [21355,21367]
name: LocalTaskJob [21760,21772]
===
match
---
argument [14840,14869]
argument [15051,15080]
===
match
---
atom_expr [5488,5540]
atom_expr [5699,5751]
===
match
---
atom_expr [2563,2683]
atom_expr [2603,2723]
===
match
---
atom_expr [4361,4372]
atom_expr [4529,4540]
===
match
---
atom_expr [19884,19904]
atom_expr [20235,20255]
===
match
---
name: ignore_ti_state [12779,12794]
name: ignore_ti_state [12990,13005]
===
match
---
import_from [1019,1088]
import_from [1059,1128]
===
match
---
operator: , [18619,18620]
operator: , [18970,18971]
===
match
---
operator: , [17091,17092]
operator: , [17302,17303]
===
match
---
atom_expr [16470,16495]
atom_expr [16681,16706]
===
match
---
atom_expr [8325,8337]
atom_expr [8536,8548]
===
match
---
string: 'owner' [2655,2662]
string: 'owner' [2695,2702]
===
match
---
number: 0 [13708,13709]
number: 0 [13919,13920]
===
match
---
string: 'test_localtaskjob_double_trigger' [9229,9263]
string: 'test_localtaskjob_double_trigger' [9440,9474]
===
match
---
string: """         Test that ensures that mark_success in the UI doesn't cause         the task to fail, and that the task exits         """ [6426,6559]
string: """         Test that ensures that mark_success in the UI doesn't cause         the task to fail, and that the task exits         """ [6637,6770]
===
match
---
name: ti [20290,20292]
name: ti [20537,20539]
===
match
---
expr_stmt [15486,15534]
expr_stmt [15697,15745]
===
match
---
name: ti [8434,8436]
name: ti [8645,8647]
===
match
---
operator: = [20009,20010]
operator: = [20360,20361]
===
match
---
expr_stmt [4516,4541]
expr_stmt [4720,4752]
===
match
---
name: state [7488,7493]
name: state [7699,7704]
===
match
---
atom_expr [9381,9392]
atom_expr [9592,9603]
===
match
---
operator: , [9637,9638]
operator: , [9848,9849]
===
match
---
name: dag [21098,21101]
name: dag [21503,21506]
===
match
---
trailer [12354,12360]
trailer [12565,12571]
===
match
---
simple_stmt [10490,10525]
simple_stmt [10701,10736]
===
match
---
name: object [10142,10148]
name: object [10353,10359]
===
match
---
argument [12761,12777]
argument [12972,12988]
===
match
---
atom_expr [12711,12731]
atom_expr [12922,12942]
===
match
---
operator: = [6607,6608]
operator: = [6818,6819]
===
match
---
trailer [11841,11847]
trailer [12052,12058]
===
match
---
atom_expr [4328,4336]
atom_expr [4496,4504]
===
match
---
operator: = [18608,18609]
operator: = [18959,18960]
===
match
---
trailer [11786,11790]
trailer [11997,12001]
===
match
---
expr_stmt [18859,18955]
expr_stmt [19210,19306]
===
match
---
operator: , [10167,10168]
operator: , [10378,10379]
===
match
---
argument [8219,8242]
argument [8430,8453]
===
match
---
arglist [9432,9586]
arglist [9643,9797]
===
match
---
operator: = [2653,2654]
operator: = [2693,2694]
===
match
---
expr_stmt [19217,19253]
expr_stmt [19568,19604]
===
match
---
name: execution_date [12674,12688]
name: execution_date [12885,12899]
===
match
---
argument [3038,3067]
argument [3078,3107]
===
match
---
argument [21172,21188]
argument [21577,21593]
===
match
---
simple_stmt [14780,14871]
simple_stmt [14991,15082]
===
match
---
import_as_names [1816,1844]
import_as_names [1856,1884]
===
match
---
simple_stmt [10307,10341]
simple_stmt [10518,10552]
===
match
---
trailer [7259,7265]
trailer [7470,7476]
===
match
---
argument [5440,5455]
argument [5651,5666]
===
match
---
name: job1 [17589,17593]
name: job1 [17800,17804]
===
match
---
atom_expr [4516,4537]
atom_expr [4720,4748]
===
match
---
expr_stmt [13719,13747]
expr_stmt [13930,13958]
===
match
---
name: execution_date [17282,17296]
name: execution_date [17493,17507]
===
match
---
simple_stmt [13889,13954]
simple_stmt [14100,14165]
===
match
---
simple_stmt [2759,2771]
simple_stmt [2799,2811]
===
match
---
atom_expr [11643,11651]
atom_expr [11854,11862]
===
match
---
name: DAG [3505,3508]
name: DAG [3511,3514]
===
match
---
simple_stmt [9343,9372]
simple_stmt [9554,9583]
===
match
---
simple_stmt [19217,19254]
simple_stmt [19568,19605]
===
match
---
atom_expr [14390,14401]
atom_expr [14601,14612]
===
match
---
operator: , [7010,7011]
operator: , [7221,7222]
===
match
---
string: "dag_id" [3096,3104]
string: "dag_id" [3136,3144]
===
match
---
name: check_result_2 [3263,3277]
name: check_result_2 [3303,3317]
===
match
---
name: StandardTaskRunner [19933,19951]
name: StandardTaskRunner [20284,20302]
===
match
---
name: test_localtaskjob_double_trigger [7729,7761]
name: test_localtaskjob_double_trigger [7940,7972]
===
match
---
operator: < [10783,10784]
operator: < [10994,10995]
===
match
---
trailer [9390,9392]
trailer [9601,9603]
===
match
---
trailer [10789,10799]
trailer [11000,11010]
===
match
---
name: session [18016,18023]
name: session [18227,18234]
===
match
---
atom_expr [7786,7879]
atom_expr [7997,8090]
===
match
---
number: 0 [12065,12066]
number: 0 [12276,12277]
===
match
---
simple_stmt [2978,3069]
simple_stmt [3018,3109]
===
match
---
operator: = [3634,3635]
operator: = [3640,3641]
===
match
---
arglist [8527,8565]
arglist [8738,8776]
===
match
---
trailer [11735,11741]
trailer [11946,11952]
===
match
---
trailer [4155,4157]
trailer [4161,4163]
===
match
---
funcdef [13757,14028]
funcdef [13968,14239]
===
match
---
operator: = [16544,16545]
operator: = [16755,16756]
===
match
---
simple_stmt [17461,17482]
simple_stmt [17672,17693]
===
match
---
trailer [6177,6180]
trailer [6388,6391]
===
match
---
trailer [5694,5701]
trailer [5905,5912]
===
match
---
suite [3453,4668]
suite [3459,4879]
===
match
---
suite [11556,12067]
suite [11767,12278]
===
match
---
atom_expr [19046,19060]
atom_expr [19397,19411]
===
match
---
simple_stmt [5717,5794]
simple_stmt [5928,6005]
===
match
---
trailer [4604,4623]
trailer [4815,4834]
===
match
---
name: DAG [20953,20956]
name: DAG [21358,21361]
===
match
---
simple_stmt [1442,1519]
simple_stmt [1482,1559]
===
match
---
trailer [20485,20487]
trailer [20890,20892]
===
match
---
argument [6857,6870]
argument [7068,7081]
===
match
---
simple_stmt [8453,8471]
simple_stmt [8664,8682]
===
match
---
simple_stmt [18859,18956]
simple_stmt [19210,19307]
===
match
---
operator: = [12575,12576]
operator: = [12786,12787]
===
match
---
name: process [17735,17742]
name: process [17946,17953]
===
match
---
name: session [8339,8346]
name: session [8550,8557]
===
match
---
trailer [7973,8014]
trailer [8184,8225]
===
match
---
parameters [16355,16364]
parameters [16566,16575]
===
match
---
atom_expr [20412,20444]
atom_expr [20817,20849]
===
match
---
trailer [9283,9292]
trailer [9494,9503]
===
match
---
trailer [8885,8893]
trailer [9096,9104]
===
match
---
simple_stmt [13671,13711]
simple_stmt [13882,13922]
===
match
---
argument [17550,17579]
argument [17761,17790]
===
match
---
operator: = [8748,8749]
operator: = [8959,8960]
===
match
---
name: unittest [921,929]
name: unittest [921,929]
===
match
---
name: kwargs [15412,15418]
name: kwargs [15623,15629]
===
match
---
argument [2880,2903]
argument [2920,2943]
===
match
---
atom_expr [7132,7184]
atom_expr [7343,7395]
===
match
---
atom_expr [7355,7368]
atom_expr [7566,7579]
===
match
---
expr_stmt [21349,21410]
expr_stmt [21754,21815]
===
match
---
name: task [9628,9632]
name: task [9839,9843]
===
match
---
trailer [21149,21189]
trailer [21554,21594]
===
match
---
name: job1 [10497,10501]
name: job1 [10708,10712]
===
match
---
param [13381,13392]
param [13592,13603]
===
match
---
operator: = [17417,17418]
operator: = [17628,17629]
===
match
---
arglist [12663,12701]
arglist [12874,12912]
===
match
---
testlist_comp [3281,3339]
testlist_comp [3321,3379]
===
match
---
name: dag [3699,3702]
name: dag [3705,3708]
===
match
---
string: 'return_code' [10169,10182]
string: 'return_code' [10380,10393]
===
match
---
name: ti [4398,4400]
name: ti [4566,4568]
===
match
---
name: failure_callback [14332,14348]
name: failure_callback [14543,14559]
===
match
---
operator: = [17495,17496]
operator: = [17706,17707]
===
match
---
operator: = [12261,12262]
operator: = [12472,12473]
===
match
---
operator: , [11182,11183]
operator: , [11393,11394]
===
match
---
simple_stmt [5038,5076]
simple_stmt [5249,5287]
===
match
---
operator: } [18953,18954]
operator: } [19304,19305]
===
match
---
trailer [20956,21031]
trailer [21361,21436]
===
match
---
trailer [11670,11674]
trailer [11881,11885]
===
match
---
trailer [5500,5540]
trailer [5711,5751]
===
match
---
operator: == [17840,17842]
operator: == [18051,18053]
===
match
---
number: 1 [10480,10481]
number: 1 [10691,10692]
===
match
---
expr_stmt [12741,12831]
expr_stmt [12952,13042]
===
match
---
trailer [17748,17750]
trailer [17959,17961]
===
match
---
operator: = [7052,7053]
operator: = [7263,7264]
===
match
---
name: context [16356,16363]
name: context [16567,16574]
===
match
---
simple_stmt [6568,6671]
simple_stmt [6779,6882]
===
match
---
name: DEFAULT_DATE [6932,6944]
name: DEFAULT_DATE [7143,7155]
===
match
---
name: time [10413,10417]
name: time [10624,10628]
===
match
---
simple_stmt [4042,4059]
simple_stmt [4048,4065]
===
match
---
argument [14312,14348]
argument [14523,14559]
===
match
---
name: dag [2784,2787]
name: dag [2824,2827]
===
match
---
operator: = [18557,18558]
operator: = [18908,18909]
===
match
---
name: ti [8291,8293]
name: ti [8502,8504]
===
match
---
name: include_examples [7846,7862]
name: include_examples [8057,8073]
===
match
---
trailer [11679,11716]
trailer [11890,11927]
===
match
---
trailer [3977,3983]
trailer [3983,3989]
===
match
---
name: state [15771,15776]
name: state [15982,15987]
===
match
---
arglist [19835,19904]
arglist [20186,20255]
===
match
---
operator: = [20342,20343]
operator: = [20747,20748]
===
match
---
name: task [5501,5505]
name: task [5712,5716]
===
match
---
name: start_date [3540,3550]
name: start_date [3546,3556]
===
match
---
operator: = [11171,11172]
operator: = [11382,11383]
===
match
---
simple_stmt [6679,6722]
simple_stmt [6890,6933]
===
match
---
name: total_seconds [6275,6288]
name: total_seconds [6486,6499]
===
match
---
name: mock_get_task_runner [20860,20880]
name: mock_get_task_runner [21265,21285]
===
match
---
name: session [4042,4049]
name: session [4048,4055]
===
match
---
trailer [12390,12392]
trailer [12601,12603]
===
match
---
trailer [17665,17667]
trailer [17876,17878]
===
match
---
arglist [8707,8753]
arglist [8918,8964]
===
match
---
string: """         Check whether essential attributes         of LocalTaskJob can be assigned with         proper values without intervention         """ [2402,2548]
string: """         Check whether essential attributes         of LocalTaskJob can be assigned with         proper values without intervention         """ [2442,2588]
===
match
---
name: settings [1010,1018]
name: settings [1050,1058]
===
match
---
atom_expr [2248,2263]
atom_expr [2288,2303]
===
match
---
number: 1 [1941,1942]
number: 1 [1981,1982]
===
match
---
name: commit [4451,4457]
name: commit [4619,4625]
===
match
---
string: 'i' [11179,11182]
string: 'i' [11390,11393]
===
match
---
arglist [20100,20105]
arglist [20451,20456]
===
match
---
argument [14157,14180]
argument [14368,14391]
===
match
---
name: patch [13262,13267]
name: patch [13473,13478]
===
match
---
name: state [2830,2835]
name: state [2870,2875]
===
match
---
argument [8736,8753]
argument [8947,8964]
===
match
---
if_stmt [20153,20205]
if_stmt [20504,20579]
===
match
---
simple_stmt [15486,15535]
simple_stmt [15697,15746]
===
match
---
argument [18922,18954]
argument [19273,19305]
===
match
---
atom_expr [17400,17452]
atom_expr [17611,17663]
===
match
---
funcdef [20815,21472]
funcdef [21220,21877]
===
match
---
operator: = [19692,19693]
operator: = [20043,20044]
===
match
---
name: value [13181,13186]
name: value [13392,13397]
===
match
---
argument [14559,14586]
argument [14770,14797]
===
match
---
name: start_date [21007,21017]
name: start_date [21412,21422]
===
match
---
name: clear [3678,3683]
name: clear [3684,3689]
===
match
---
operator: = [3577,3578]
operator: = [3583,3584]
===
match
---
name: multi_return_code [10246,10263]
name: multi_return_code [10457,10474]
===
match
---
operator: = [8373,8374]
operator: = [8584,8585]
===
match
---
string: 'test_failure_callback_race' [14127,14155]
string: 'test_failure_callback_race' [14338,14366]
===
match
---
atom_expr [7404,7419]
atom_expr [7615,7630]
===
match
---
argument [19430,19437]
argument [19781,19788]
===
match
---
operator: , [19634,19635]
operator: , [19985,19986]
===
match
---
atom_expr [4555,4586]
atom_expr [4766,4797]
===
match
---
number: 0 [19252,19253]
number: 0 [19603,19604]
===
match
---
name: dag_id [13915,13921]
name: dag_id [14126,14132]
===
match
---
name: get_task [6741,6749]
name: get_task [6952,6960]
===
match
---
operator: , [12621,12622]
operator: , [12832,12833]
===
match
---
operator: = [17228,17229]
operator: = [17439,17440]
===
match
---
number: 9 [15475,15476]
number: 9 [15686,15687]
===
match
---
operator: = [17367,17368]
operator: = [17578,17579]
===
match
---
operator: = [14652,14653]
operator: = [14863,14864]
===
match
---
simple_stmt [11773,11791]
simple_stmt [11984,12002]
===
match
---
simple_stmt [8479,8496]
simple_stmt [8690,8707]
===
match
---
name: DEFAULT_DATE [9654,9666]
name: DEFAULT_DATE [9865,9877]
===
match
---
name: python_callable [17012,17027]
name: python_callable [17223,17238]
===
match
---
string: 'airflow.utils.process_utils.subprocess.check_call' [13204,13255]
string: 'airflow.utils.process_utils.subprocess.check_call' [13415,13466]
===
match
---
name: task_runner [1460,1471]
name: task_runner [1500,1511]
===
match
---
name: create_dagrun [12421,12434]
name: create_dagrun [12632,12645]
===
match
---
funcdef [15381,15477]
funcdef [15592,15688]
===
match
---
comparison [11466,11524]
comparison [11677,11735]
===
match
---
name: State [20168,20173]
name: State [20519,20524]
===
match
---
atom_expr [1917,1946]
atom_expr [1957,1986]
===
match
---
trailer [8466,8470]
trailer [8677,8681]
===
match
---
operator: @ [20666,20667]
operator: @ [21071,21072]
===
match
---
arglist [20290,20312]
arglist [20698,20717]
===
match
---
name: execution_date [14713,14727]
name: execution_date [14924,14938]
===
match
---
argument [12779,12799]
argument [12990,13010]
===
match
---
atom_expr [14689,14741]
atom_expr [14900,14952]
===
match
---
name: DummyOperator [2721,2734]
name: DummyOperator [2761,2774]
===
match
---
name: session [19693,19700]
name: session [20044,20051]
===
match
---
name: attr [3185,3189]
name: attr [3225,3229]
===
match
---
argument [12663,12672]
argument [12874,12883]
===
match
---
operator: = [4500,4501]
operator: = [4704,4705]
===
match
---
simple_stmt [7096,7117]
simple_stmt [7307,7328]
===
match
---
name: time1 [6268,6273]
name: time1 [6479,6484]
===
match
---
simple_stmt [15433,15477]
simple_stmt [15644,15688]
===
match
---
atom_expr [18082,18111]
atom_expr [18293,18322]
===
match
---
trailer [9698,9700]
trailer [9909,9911]
===
match
---
operator: * [15403,15404]
operator: * [15614,15615]
===
match
---
atom_expr [13076,13088]
atom_expr [13287,13299]
===
match
---
atom_expr [21266,21324]
atom_expr [21671,21729]
===
match
---
comparison [17923,17948]
comparison [18134,18159]
===
match
---
comparison [13154,13191]
comparison [13365,13402]
===
match
---
trailer [21060,21102]
trailer [21465,21507]
===
match
---
name: state [17834,17839]
name: state [18045,18050]
===
match
---
trailer [6749,6758]
trailer [6960,6969]
===
match
---
name: getattr [3281,3288]
name: getattr [3321,3328]
===
match
---
trailer [6288,6290]
trailer [6499,6501]
===
match
---
arglist [10149,10182]
arglist [10360,10393]
===
match
---
argument [8317,8337]
argument [8528,8548]
===
match
---
name: dag [14456,14459]
name: dag [14667,14670]
===
match
---
argument [9492,9519]
argument [9703,9730]
===
match
---
name: call_count [10325,10335]
name: call_count [10536,10546]
===
match
---
argument [3868,3883]
argument [3874,3889]
===
match
---
name: SUCCESS [9471,9478]
name: SUCCESS [9682,9689]
===
match
---
name: session [7003,7010]
name: session [7214,7221]
===
match
---
operator: = [19742,19743]
operator: = [20093,20094]
===
match
---
simple_stmt [7030,7088]
simple_stmt [7241,7299]
===
match
---
operator: , [14504,14505]
operator: , [14715,14716]
===
match
---
atom_expr [4075,4158]
atom_expr [4081,4164]
===
match
---
arglist [14491,14661]
arglist [14702,14872]
===
match
---
parameters [7761,7767]
parameters [7972,7978]
===
match
---
atom_expr [8927,8933]
atom_expr [9138,9144]
===
match
---
argument [12801,12830]
argument [13012,13041]
===
match
---
trailer [19476,19484]
trailer [19827,19835]
===
match
---
atom_expr [13984,14004]
atom_expr [14195,14215]
===
match
---
name: patch [10043,10048]
name: patch [10254,10259]
===
match
---
number: 60 [19057,19059]
number: 60 [19408,19410]
===
match
---
operator: = [14727,14728]
operator: = [14938,14939]
===
match
---
trailer [10465,10476]
trailer [10676,10687]
===
match
---
string: "task marked as failed externally" [11490,11524]
string: "task marked as failed externally" [11701,11735]
===
match
---
import_name [848,863]
import_name [848,863]
===
match
---
operator: , [9749,9750]
operator: , [9960,9961]
===
match
---
name: mock_ret_code [10364,10377]
name: mock_ret_code [10575,10588]
===
match
---
name: python_callable [14269,14284]
name: python_callable [14480,14495]
===
match
---
simple_stmt [10808,10824]
simple_stmt [11019,11035]
===
match
---
operator: , [2828,2829]
operator: , [2868,2869]
===
match
---
trailer [5666,5670]
trailer [5877,5881]
===
match
---
trailer [2143,2174]
trailer [2183,2214]
===
match
---
name: sleep [19051,19056]
name: sleep [19402,19407]
===
match
---
atom_expr [17717,17725]
atom_expr [17928,17936]
===
match
---
operator: , [12465,12466]
operator: , [12676,12677]
===
match
---
import_from [1726,1783]
import_from [1766,1823]
===
match
---
atom_expr [7961,8014]
atom_expr [8172,8225]
===
match
---
name: DEFAULT_DATE [6969,6981]
name: DEFAULT_DATE [7180,7192]
===
match
---
atom_expr [8881,8893]
atom_expr [9092,9104]
===
match
---
name: session [4417,4424]
name: session [4585,4592]
===
match
---
name: Value [16228,16233]
name: Value [16439,16444]
===
match
---
operator: == [20165,20167]
operator: == [20516,20518]
===
match
---
trailer [21444,21448]
trailer [21849,21853]
===
match
---
expr_stmt [8434,8444]
expr_stmt [8645,8655]
===
match
---
simple_stmt [1211,1246]
simple_stmt [1251,1286]
===
match
---
name: task [19743,19747]
name: task [20094,20098]
===
match
---
name: ti [4431,4433]
name: ti [4599,4601]
===
match
---
comparison [13064,13088]
comparison [13275,13299]
===
match
---
simple_stmt [20458,20488]
simple_stmt [20863,20893]
===
match
---
dotted_name [1447,1492]
dotted_name [1487,1532]
===
match
---
name: heartbeat_records [6009,6026]
name: heartbeat_records [6220,6237]
===
match
---
name: refresh_from_db [7279,7294]
name: refresh_from_db [7490,7505]
===
match
---
name: len [6062,6065]
name: len [6273,6276]
===
match
---
parameters [18982,18986]
parameters [19333,19337]
===
match
---
operator: , [2614,2615]
operator: , [2654,2655]
===
match
---
simple_stmt [20241,20274]
simple_stmt [20615,20648]
===
match
---
atom_expr [5664,5670]
atom_expr [5875,5881]
===
match
---
name: run [17722,17725]
name: run [17933,17936]
===
match
---
operator: = [21202,21203]
operator: = [21607,21608]
===
match
---
name: session [9343,9350]
name: session [9554,9561]
===
match
---
name: session [8024,8031]
name: session [8235,8242]
===
match
---
atom_expr [7894,7945]
atom_expr [8105,8156]
===
match
---
trailer [18196,18205]
trailer [18407,18416]
===
match
---
funcdef [16634,16923]
funcdef [16845,17134]
===
match
---
trailer [10022,10027]
trailer [10233,10238]
===
match
---
atom_expr [4294,4315]
atom_expr [4455,4483]
===
match
---
name: all [3356,3359]
name: all [3396,3399]
===
match
---
trailer [8835,8837]
trailer [9046,9048]
===
match
---
name: process [20001,20008]
name: process [20352,20359]
===
match
---
arglist [17775,17780]
arglist [17986,17991]
===
match
---
argument [9751,9780]
argument [9962,9991]
===
match
---
operator: = [3093,3094]
operator: = [3133,3134]
===
match
---
simple_stmt [7386,7392]
simple_stmt [7597,7603]
===
match
---
atom_expr [18865,18955]
atom_expr [19216,19306]
===
match
---
suite [2702,2750]
suite [2742,2790]
===
match
---
comparison [20156,20181]
comparison [20507,20532]
===
match
---
trailer [7265,7267]
trailer [7476,7478]
===
match
---
trailer [7699,7707]
trailer [7910,7918]
===
match
---
simple_stmt [7888,7946]
simple_stmt [8099,8157]
===
match
---
atom_expr [2080,2095]
atom_expr [2120,2135]
===
match
---
name: RUNNING [19586,19593]
name: RUNNING [19937,19944]
===
match
---
name: time [20217,20221]
name: time [20591,20595]
===
match
---
name: heartbeat_records [5912,5929]
name: heartbeat_records [6123,6140]
===
match
---
trailer [4849,4855]
trailer [5060,5066]
===
match
---
assert_stmt [13966,14027]
assert_stmt [14177,14238]
===
match
---
argument [17528,17548]
argument [17739,17759]
===
match
---
operator: , [3563,3564]
operator: , [3569,3570]
===
match
---
name: net [1573,1576]
name: net [1613,1616]
===
match
---
assert_stmt [7620,7649]
assert_stmt [7831,7860]
===
match
---
atom_expr [6685,6721]
atom_expr [6896,6932]
===
match
---
name: start_date [12113,12123]
name: start_date [12324,12334]
===
match
---
trailer [15734,15750]
trailer [15945,15961]
===
match
---
trailer [9369,9371]
trailer [9580,9582]
===
match
---
atom_expr [17968,17981]
atom_expr [18179,18192]
===
match
---
assert_stmt [10490,10524]
assert_stmt [10701,10735]
===
match
---
parameters [13777,13786]
parameters [13988,13997]
===
match
---
simple_stmt [9381,9393]
simple_stmt [9592,9604]
===
match
---
simple_stmt [1597,1646]
simple_stmt [1637,1686]
===
match
---
name: time1 [6103,6108]
name: time1 [6314,6319]
===
match
---
operator: , [19560,19561]
operator: , [19911,19912]
===
match
---
expr_stmt [6768,6796]
expr_stmt [6979,7007]
===
match
---
argument [14800,14816]
argument [15011,15027]
===
match
---
name: task_id [8886,8893]
name: task_id [9097,9104]
===
match
---
name: merge [7543,7548]
name: merge [7754,7759]
===
match
---
argument [19835,19851]
argument [20186,20202]
===
match
---
name: exceptions [1032,1042]
name: exceptions [1072,1082]
===
match
---
simple_stmt [19914,19958]
simple_stmt [20265,20309]
===
match
---
name: op1 [3630,3633]
name: op1 [3636,3639]
===
match
---
name: ti [8847,8849]
name: ti [9058,9060]
===
match
---
name: ignore_ti_state [4106,4121]
name: ignore_ti_state [4112,4127]
===
match
---
atom_expr [10218,10243]
atom_expr [10429,10454]
===
match
---
number: 10 [20103,20105]
number: 20 [20454,20456]
===
match
---
operator: -> [2288,2290]
operator: -> [2328,2330]
===
match
---
name: test_utils [1795,1805]
name: test_utils [1835,1845]
===
match
---
import_as_names [904,915]
import_as_names [904,915]
===
match
---
atom_expr [20298,20312]
atom_expr [18470,18484]
===
match
---
operator: = [16532,16533]
operator: = [16743,16744]
===
match
---
fstring_expr [20966,20981]
fstring_expr [21371,21386]
===
match
---
atom_expr [5586,5594]
atom_expr [5797,5805]
===
match
---
trailer [4561,4568]
trailer [4772,4779]
===
match
---
suite [19200,19254]
suite [19551,19605]
===
match
---
expr_stmt [14684,14741]
expr_stmt [14895,14952]
===
match
---
trailer [11315,11324]
trailer [11526,11535]
===
match
---
name: timezone [1545,1553]
name: timezone [1585,1593]
===
match
---
arglist [12085,12136]
arglist [12296,12347]
===
match
---
atom_expr [17461,17481]
atom_expr [17672,17692]
===
match
---
operator: , [8131,8132]
operator: , [8342,8343]
===
match
---
name: settings [6778,6786]
name: settings [6989,6997]
===
match
---
trailer [6128,6135]
trailer [6339,6346]
===
match
---
name: Session [3481,3488]
name: Session [3487,3494]
===
match
---
trailer [2093,2095]
trailer [2133,2135]
===
match
---
name: RUNNING [20266,20273]
name: RUNNING [20640,20647]
===
match
---
name: os [819,821]
name: os [819,821]
===
match
---
operator: , [4970,4971]
operator: , [5181,5182]
===
match
---
trailer [4430,4434]
trailer [4598,4602]
===
match
---
atom_expr [20011,20051]
atom_expr [20362,20402]
===
match
---
arglist [2815,2903]
arglist [2855,2943]
===
match
---
name: session [5687,5694]
name: session [5898,5905]
===
match
---
trailer [4344,4352]
trailer [4512,4520]
===
match
---
name: test_process_kill_call_on_failure_callback [18217,18259]
name: test_process_kill_calls_on_failure_callback [18543,18586]
===
match
---
simple_stmt [8024,8053]
simple_stmt [8235,8264]
===
match
---
trailer [17626,17632]
trailer [17837,17843]
===
match
---
operator: = [3875,3876]
operator: = [3881,3882]
===
match
---
trailer [7408,7414]
trailer [7619,7625]
===
match
---
operator: , [17268,17269]
operator: , [17479,17480]
===
match
---
trailer [12729,12731]
trailer [12940,12942]
===
match
---
name: merge [8461,8466]
name: merge [8672,8677]
===
match
---
expr_stmt [16886,16922]
expr_stmt [17097,17133]
===
match
---
atom_expr [4398,4404]
atom_expr [4566,4572]
===
match
---
operator: = [5266,5267]
operator: = [5477,5478]
===
match
---
operator: = [4405,4406]
operator: = [4573,4574]
===
match
---
with_stmt [19179,19254]
with_stmt [19530,19605]
===
match
---
operator: , [3116,3117]
operator: , [3156,3157]
===
match
---
trailer [20046,20050]
trailer [20397,20401]
===
match
---
name: DEFAULT_DATE [8553,8565]
name: DEFAULT_DATE [8764,8776]
===
match
---
name: ti [8927,8929]
name: ti [9138,9140]
===
match
---
expr_stmt [9207,9264]
expr_stmt [9418,9475]
===
match
---
name: DEFAULT_DATE [5527,5539]
name: DEFAULT_DATE [5738,5750]
===
match
---
name: clear [2763,2768]
name: clear [2803,2808]
===
match
---
trailer [7047,7087]
trailer [7258,7298]
===
match
---
trailer [16233,16241]
trailer [16444,16452]
===
match
---
name: execution_date [2851,2865]
name: execution_date [2891,2905]
===
match
---
trailer [19951,19957]
trailer [20302,20308]
===
match
---
name: _ [20089,20090]
name: _ [20440,20441]
===
match
---
name: job1 [3179,3183]
name: job1 [3219,3223]
===
match
---
operator: = [19305,19306]
operator: = [19656,19657]
===
match
---
name: Session [6787,6794]
name: Session [6998,7005]
===
match
---
import_name [789,811]
import_name [789,811]
===
match
---
operator: = [9714,9715]
operator: = [9925,9926]
===
match
---
operator: * [20715,20716]
operator: * [21120,21121]
===
match
---
simple_stmt [6768,6797]
simple_stmt [6979,7008]
===
match
---
atom_expr [6826,7021]
atom_expr [7037,7232]
===
match
---
atom_expr [19933,19957]
atom_expr [20284,20308]
===
match
---
name: _check_call [13381,13392]
name: _check_call [13592,13603]
===
match
---
operator: = [9543,9544]
operator: = [9754,9755]
===
match
---
trailer [12056,12062]
trailer [12267,12273]
===
match
---
name: SUCCESS [2842,2849]
name: SUCCESS [2882,2889]
===
match
---
name: ti [21199,21201]
name: ti [21604,21606]
===
match
---
atom_expr [18189,18207]
atom_expr [18400,18418]
===
match
---
operator: = [19820,19821]
operator: = [20171,20172]
===
match
---
name: State [8151,8156]
name: State [8362,8367]
===
match
---
name: State [17843,17848]
name: State [18054,18059]
===
match
---
name: clear [6810,6815]
name: clear [7021,7026]
===
match
---
operator: = [20963,20964]
operator: = [21368,21369]
===
match
---
operator: = [2925,2926]
operator: = [2965,2966]
===
match
---
parameters [11264,11273]
parameters [11475,11484]
===
match
---
import_from [876,915]
import_from [876,915]
===
match
---
name: run [8788,8791]
name: run [8999,9002]
===
match
---
operator: = [1963,1964]
operator: = [2003,2004]
===
match
---
atom_expr [17923,17931]
atom_expr [18134,18142]
===
match
---
simple_stmt [17957,17982]
simple_stmt [18168,18193]
===
match
---
trailer [19484,19486]
trailer [19835,19837]
===
match
---
arglist [20691,20730]
arglist [21096,21135]
===
match
---
name: DEFAULT_DATE [16577,16589]
name: DEFAULT_DATE [16788,16800]
===
match
---
dotted_name [1559,1576]
dotted_name [1599,1616]
===
match
---
simple_stmt [4417,4435]
simple_stmt [4585,4603]
===
match
---
classdef [2008,20488]
classdef [2048,20893]
===
match
---
operator: = [14614,14615]
operator: = [14825,14826]
===
match
---
trailer [2768,2770]
trailer [2808,2810]
===
match
---
trailer [7473,7481]
trailer [7684,7692]
===
match
---
trailer [11631,11639]
trailer [11842,11850]
===
match
---
simple_stmt [14390,14402]
simple_stmt [14601,14613]
===
match
---
trailer [6329,6339]
trailer [6540,6550]
===
match
---
name: airflow [1602,1609]
name: airflow [1642,1649]
===
match
---
dotted_name [1602,1623]
dotted_name [1642,1663]
===
match
---
trailer [4568,4586]
trailer [4779,4797]
===
match
---
name: merge [11781,11786]
name: merge [11992,11997]
===
match
---
operator: = [20951,20952]
operator: = [21356,21357]
===
match
---
trailer [8329,8337]
trailer [8540,8548]
===
match
---
name: start_date [5399,5409]
name: start_date [5610,5620]
===
match
---
name: python [1413,1419]
name: python [1453,1459]
===
match
---
trailer [20476,20485]
trailer [20881,20890]
===
match
---
import_from [1597,1645]
import_from [1637,1685]
===
match
---
operator: , [1942,1943]
operator: , [1982,1983]
===
match
---
trailer [4457,4459]
trailer [4625,4627]
===
match
---
operator: = [16576,16577]
operator: = [16787,16788]
===
match
---
operator: , [6981,6982]
operator: , [7192,7193]
===
match
---
suite [18266,20488]
suite [18606,20893]
===
match
---
name: refresh_from_db [17464,17479]
name: refresh_from_db [17675,17690]
===
match
---
argument [21228,21255]
argument [21633,21660]
===
match
---
name: pid [4401,4404]
name: pid [4569,4572]
===
match
---
operator: = [7201,7202]
operator: = [7412,7413]
===
match
---
argument [17105,17112]
argument [17316,17323]
===
match
---
comparison [7343,7368]
comparison [7554,7579]
===
match
---
trailer [4387,4389]
trailer [4555,4557]
===
match
---
operator: = [17684,17685]
operator: = [17895,17896]
===
match
---
name: job1 [17717,17721]
name: job1 [17928,17932]
===
match
---
number: 50 [7323,7325]
number: 50 [7534,7536]
===
match
---
trailer [5929,5936]
trailer [6140,6147]
===
match
---
atom_expr [1965,2005]
atom_expr [2005,2045]
===
match
---
name: ti [4328,4330]
name: ti [4496,4498]
===
match
---
simple_stmt [4217,4285]
simple_stmt [4378,4446]
===
match
---
name: airflow [1345,1352]
name: airflow [1385,1392]
===
match
---
operator: < [6341,6342]
operator: < [6552,6553]
===
match
---
number: 0.2 [17903,17906]
number: 0.2 [18114,18117]
===
match
---
operator: = [15515,15516]
operator: = [15726,15727]
===
match
---
atom_expr [7631,7649]
atom_expr [7842,7860]
===
match
---
string: 'airflow.jobs.base_job.sleep' [2144,2173]
string: 'airflow.jobs.base_job.sleep' [2184,2213]
===
match
---
atom_expr [21355,21410]
atom_expr [21760,21815]
===
match
---
trailer [18054,18066]
trailer [18265,18277]
===
match
---
decorators [13197,13310]
decorators [13408,13521]
===
match
---
atom_expr [11173,11186]
atom_expr [11384,11397]
===
match
---
string: 'test_localtaskjob_double_trigger' [7910,7944]
string: 'test_localtaskjob_double_trigger' [8121,8155]
===
match
---
name: pytest [4172,4178]
name: pytest [4333,4339]
===
match
---
name: ti_run [9676,9682]
name: ti_run [9887,9893]
===
match
---
suite [7327,7453]
suite [7538,7664]
===
match
---
argument [8538,8565]
argument [8749,8776]
===
match
---
name: patch [13198,13203]
name: patch [13409,13414]
===
match
---
expr_stmt [7888,7945]
expr_stmt [8099,8156]
===
match
---
string: """         Test that task heartbeat will sleep when it fails fast         """ [4719,4797]
string: """         Test that task heartbeat will sleep when it fails fast         """ [4930,5008]
===
match
---
operator: , [3538,3539]
operator: , [3544,3545]
===
match
---
name: job1 [19952,19956]
name: job1 [20303,20307]
===
match
---
name: multiprocessing [17686,17701]
name: multiprocessing [17897,17912]
===
match
---
trailer [2929,2947]
trailer [2969,2987]
===
match
---
name: run_id [5260,5266]
name: run_id [5471,5477]
===
match
---
trailer [6058,6085]
trailer [6269,6296]
===
match
---
trailer [16953,17123]
trailer [17164,17334]
===
match
---
operator: = [3906,3907]
operator: = [3912,3913]
===
match
---
name: settings [19967,19975]
name: settings [20318,20326]
===
match
---
operator: = [10411,10412]
operator: = [10622,10623]
===
match
---
trailer [18003,18007]
trailer [18214,18218]
===
match
---
name: dag [6806,6809]
name: dag [7017,7020]
===
match
---
comparison [18082,18116]
comparison [18293,18327]
===
match
---
name: LocalTaskJob [7132,7144]
name: LocalTaskJob [7343,7355]
===
match
---
argument [3540,3563]
argument [3546,3569]
===
match
---
name: task_instance [9729,9742]
name: task_instance [9940,9953]
===
match
---
atom_expr [2199,2211]
atom_expr [2239,2251]
===
match
---
simple_stmt [3462,3491]
simple_stmt [3468,3497]
===
match
---
import_from [1246,1286]
import_from [1286,1326]
===
match
---
expr_stmt [3694,3894]
expr_stmt [3700,3900]
===
match
---
trailer [8493,8495]
trailer [8704,8706]
===
match
---
name: ti [20120,20122]
name: ti [20471,20473]
===
match
---
operator: += [16446,16448]
operator: += [16657,16659]
===
match
---
name: create_dagrun [19520,19533]
name: create_dagrun [19871,19884]
===
match
---
trailer [8699,8706]
trailer [8910,8917]
===
match
---
parameters [11551,11555]
parameters [11762,11766]
===
match
---
trailer [17742,17748]
trailer [17953,17959]
===
match
---
operator: = [14848,14849]
operator: = [15059,15060]
===
match
---
name: state [7505,7510]
name: state [7716,7721]
===
match
---
assert_stmt [3227,3253]
assert_stmt [3267,3293]
===
match
---
name: DEFAULT_DATE [12576,12588]
name: DEFAULT_DATE [12787,12799]
===
match
---
trailer [17833,17839]
trailer [18044,18050]
===
match
---
name: create_dagrun [21136,21149]
name: create_dagrun [21541,21554]
===
match
---
trailer [17180,17182]
trailer [17391,17393]
===
match
---
name: RUNNING [6896,6903]
name: RUNNING [7107,7114]
===
match
---
name: Value [18610,18615]
name: Value [18961,18966]
===
match
---
operator: += [11374,11376]
operator: += [11585,11587]
===
match
---
with_item [14415,14442]
with_item [14626,14653]
===
match
---
name: close [10816,10821]
name: close [11027,11032]
===
match
---
name: parametrize [20679,20690]
name: parametrize [21084,21095]
===
match
---
assert_stmt [10357,10393]
assert_stmt [10568,10604]
===
match
---
name: value [13866,13871]
name: value [14077,14082]
===
match
---
operator: = [4843,4844]
operator: = [5054,5055]
===
match
---
import_from [1211,1245]
import_from [1251,1285]
===
match
---
trailer [20173,20181]
trailer [20524,20532]
===
match
---
name: heartbeat_records [6160,6177]
name: heartbeat_records [6371,6388]
===
match
---
trailer [2318,2320]
trailer [2358,2360]
===
match
---
name: State [17935,17940]
name: State [18146,18151]
===
match
---
name: DEFAULT_DATE [21018,21030]
name: DEFAULT_DATE [21423,21435]
===
match
---
trailer [17940,17948]
trailer [18151,18159]
===
match
---
name: ti [12775,12777]
name: ti [12986,12988]
===
match
---
expr_stmt [3153,3218]
expr_stmt [3193,3258]
===
match
---
name: dag [9207,9210]
name: dag [9418,9421]
===
match
---
atom_expr [3636,3664]
atom_expr [3642,3670]
===
match
---
atom_expr [10018,10029]
atom_expr [10229,10240]
===
match
---
name: task_instance [8628,8641]
name: task_instance [8839,8852]
===
match
---
string: "test" [14498,14504]
string: "test" [14709,14715]
===
match
---
atom_expr [11668,11716]
atom_expr [11879,11927]
===
match
---
trailer [19990,19992]
trailer [20341,20343]
===
match
---
expr_stmt [4068,4158]
expr_stmt [4074,4164]
===
match
---
argument [3565,3597]
argument [3571,3603]
===
match
---
arglist [16967,17113]
arglist [17178,17324]
===
match
---
string: "start_date" [3118,3130]
string: "start_date" [3158,3170]
===
match
---
name: task_terminated_externally [19217,19243]
name: task_terminated_externally [19568,19594]
===
match
---
name: return_code [21300,21311]
name: return_code [21705,21716]
===
match
---
expr_stmt [7502,7526]
expr_stmt [7713,7737]
===
match
---
suite [10201,10394]
suite [10412,10605]
===
match
---
name: TaskInstance [9615,9627]
name: TaskInstance [9826,9838]
===
match
---
simple_stmt [15761,15826]
simple_stmt [15972,16037]
===
match
---
operator: = [11222,11223]
operator: = [11433,11434]
===
match
---
atom_expr [9401,9596]
atom_expr [9612,9807]
===
match
---
trailer [17463,17479]
trailer [17674,17690]
===
match
---
operator: = [3278,3279]
operator: = [3318,3319]
===
match
---
name: value [15865,15870]
name: value [16076,16081]
===
match
---
simple_stmt [822,836]
simple_stmt [822,836]
===
match
---
simple_stmt [3153,3219]
simple_stmt [3193,3259]
===
match
---
name: return_codes [21327,21339]
name: return_codes [21732,21744]
===
match
---
name: return_codes [9976,9988]
name: return_codes [10187,10199]
===
match
---
name: self [4704,4708]
name: self [4915,4919]
===
match
---
operator: , [6060,6061]
operator: , [6271,6272]
===
match
---
param [11552,11554]
param [11763,11765]
===
match
---
trailer [14399,14401]
trailer [14610,14612]
===
match
---
arith_expr [10761,10782]
arith_expr [10972,10993]
===
match
---
funcdef [4673,6347]
funcdef [4884,6558]
===
match
---
name: job1 [15452,15456]
name: job1 [15663,15667]
===
match
---
expr_stmt [3630,3664]
expr_stmt [3636,3670]
===
match
---
atom_expr [10511,10524]
atom_expr [10722,10735]
===
match
---
name: attr [3295,3299]
name: attr [3335,3339]
===
match
---
name: target [17710,17716]
name: target [17921,17927]
===
match
---
trailer [18158,18164]
trailer [18369,18375]
===
match
---
name: assert_queries_count [21424,21444]
name: assert_queries_count [21829,21849]
===
match
---
name: run_id [6857,6863]
name: run_id [7068,7074]
===
match
---
trailer [19585,19593]
trailer [19936,19944]
===
match
---
simple_stmt [16416,16451]
simple_stmt [16627,16662]
===
match
---
name: ti [19720,19722]
name: ti [20071,20073]
===
match
---
funcdef [9039,10824]
funcdef [9250,11035]
===
match
---
expr_stmt [9606,9667]
expr_stmt [9817,9878]
===
match
---
simple_stmt [17916,17949]
simple_stmt [18127,18160]
===
match
---
expr_stmt [17589,17632]
expr_stmt [17800,17843]
===
match
---
simple_stmt [1902,1947]
simple_stmt [1942,1987]
===
match
---
operator: , [14660,14661]
operator: , [14871,14872]
===
match
---
string: 'test_mark_failure' [11427,11446]
string: 'test_mark_failure' [11638,11657]
===
match
---
operator: == [10477,10479]
operator: == [10688,10690]
===
match
---
name: dummy_return_code [15517,15534]
name: dummy_return_code [15728,15745]
===
match
---
trailer [20292,20296]
trailer [20539,20543]
===
match
---
operator: = [14813,14814]
operator: = [15024,15025]
===
match
---
trailer [18564,18572]
trailer [18915,18923]
===
match
---
simple_stmt [3349,3376]
simple_stmt [3389,3416]
===
match
---
name: RUNNING [3992,3999]
name: RUNNING [3998,4005]
===
match
---
trailer [12420,12434]
trailer [12631,12645]
===
match
---
funcdef [18965,19254]
funcdef [19316,19605]
===
match
---
arglist [14225,14370]
arglist [14436,14581]
===
match
---
number: 0 [20709,20710]
number: 0 [21114,21115]
===
match
---
name: failure_callback_called [13104,13127]
name: failure_callback_called [13315,13338]
===
match
---
simple_stmt [16715,16730]
simple_stmt [16926,16941]
===
match
---
operator: += [13872,13874]
operator: += [14083,14085]
===
match
---
name: task_id [16967,16974]
name: task_id [17178,17185]
===
match
---
name: get_lock [11316,11324]
name: get_lock [11527,11535]
===
match
---
operator: = [14527,14528]
operator: = [14738,14739]
===
match
---
string: 'exception' [13992,14003]
string: 'exception' [14203,14214]
===
match
---
for_stmt [17760,17908]
for_stmt [17971,18119]
===
match
---
name: python_callable [12246,12261]
name: python_callable [12457,12472]
===
match
---
trailer [20438,20444]
trailer [20843,20849]
===
match
---
name: value [16440,16445]
name: value [16651,16656]
===
match
---
suite [7768,9005]
suite [7979,9216]
===
match
---
name: datetime [1926,1934]
name: datetime [1966,1974]
===
match
---
name: session [17133,17140]
name: session [17344,17351]
===
match
---
operator: , [18895,18896]
operator: , [19246,19247]
===
match
---
operator: , [20296,20297]
operator: , [20704,20705]
===
match
---
name: create_dagrun [8091,8104]
name: create_dagrun [8302,8315]
===
match
---
simple_stmt [15834,15876]
simple_stmt [16045,16087]
===
match
---
name: ti [16652,16654]
name: ti [16863,16865]
===
match
---
atom_expr [17735,17750]
atom_expr [17946,17961]
===
match
---
decorated [20666,21472]
decorated [21071,21877]
===
match
---
number: 10 [20343,20345]
number: 10 [20748,20750]
===
match
---
trailer [18770,18776]
trailer [19121,19127]
===
match
---
simple_stmt [4719,4798]
simple_stmt [4930,5009]
===
match
---
name: raises [4562,4568]
name: raises [4773,4779]
===
match
---
parameters [15922,15928]
parameters [16133,16139]
===
match
---
trailer [9384,9390]
trailer [9595,9601]
===
match
---
simple_stmt [9898,9923]
simple_stmt [10109,10134]
===
match
---
trailer [5555,5571]
trailer [5766,5782]
===
match
---
name: heartrate [5810,5819]
name: heartrate [6021,6030]
===
match
---
trailer [20578,20580]
trailer [20983,20985]
===
match
---
name: TEST_DAG_FOLDER [7817,7832]
name: TEST_DAG_FOLDER [8028,8043]
===
match
---
name: task_id [8330,8337]
name: task_id [8541,8548]
===
match
---
argument [9729,9749]
argument [9940,9960]
===
match
---
arglist [3929,3965]
arglist [3935,3971]
===
match
---
name: dag [19516,19519]
name: dag [19867,19870]
===
match
---
operator: = [18863,18864]
operator: = [19214,19215]
===
match
---
trailer [9988,9992]
trailer [10199,10203]
===
match
---
simple_stmt [4068,4159]
simple_stmt [4074,4165]
===
match
---
atom_expr [16715,16729]
atom_expr [16926,16940]
===
match
---
comparison [8954,8979]
comparison [9165,9190]
===
match
---
name: task [21217,21221]
name: task [21622,21626]
===
match
---
assert_stmt [15761,15792]
assert_stmt [15972,16003]
===
match
---
name: dag_id [5038,5044]
name: dag_id [5249,5255]
===
match
---
with_stmt [3608,3665]
with_stmt [3614,3671]
===
match
---
name: check_result_2 [3360,3374]
name: check_result_2 [3400,3414]
===
match
---
trailer [12713,12729]
trailer [12924,12940]
===
match
---
atom_expr [19725,19777]
atom_expr [20076,20128]
===
match
---
name: session [9570,9577]
name: session [9781,9788]
===
match
---
simple_stmt [2183,2213]
simple_stmt [2223,2253]
===
match
---
name: log [11671,11674]
name: log [11882,11885]
===
match
---
suite [17857,17880]
suite [18068,18091]
===
match
---
trailer [6815,6817]
trailer [7026,7028]
===
match
---
trailer [9361,9369]
trailer [9572,9580]
===
match
---
operator: = [17543,17544]
operator: = [17754,17755]
===
match
---
atom_expr [9105,9198]
atom_expr [9316,9409]
===
match
---
atom_expr [20042,20050]
atom_expr [20393,20401]
===
match
---
name: task_function [14285,14298]
name: task_function [14496,14509]
===
match
---
name: patcher [2128,2135]
name: patcher [2168,2175]
===
match
---
suite [9087,10824]
suite [9298,11035]
===
match
---
operator: , [14541,14542]
operator: , [14752,14753]
===
match
---
name: Process [17702,17709]
name: Process [17913,17920]
===
match
---
name: time [11837,11841]
name: time [12048,12052]
===
match
---
operator: = [3657,3658]
operator: = [3663,3664]
===
match
---
operator: } [16622,16623]
operator: } [16833,16834]
===
match
---
comparison [15841,15875]
comparison [16052,16086]
===
match
---
name: Process [7219,7226]
name: Process [7430,7437]
===
match
---
trailer [20924,20938]
trailer [21329,21343]
===
match
---
name: callback_count_lock [13805,13824]
name: callback_count_lock [14016,14035]
===
match
---
trailer [12852,12856]
trailer [13063,13067]
===
match
---
atom_expr [3234,3253]
atom_expr [3274,3293]
===
match
---
name: settings [19468,19476]
name: settings [19819,19827]
===
match
---
trailer [10815,10821]
trailer [11026,11032]
===
match
---
trailer [19505,19507]
trailer [19856,19858]
===
match
---
atom_expr [17589,17605]
atom_expr [17800,17816]
===
match
---
name: hostname [4364,4372]
name: hostname [4532,4540]
===
match
---
simple_stmt [876,916]
simple_stmt [876,916]
===
match
---
funcdef [13314,15876]
funcdef [13525,16087]
===
match
---
string: """         Test that ensures that when a task exits with failure by itself,         failure callback is only called once         """ [13403,13536]
string: """         Test that ensures that when a task exits with failure by itself,         failure callback is only called once         """ [13614,13747]
===
match
---
name: range [6053,6058]
name: range [6264,6269]
===
match
---
name: session [3950,3957]
name: session [3956,3963]
===
match
---
number: 0 [18570,18571]
number: 0 [18921,18922]
===
match
---
name: job1 [20042,20046]
name: job1 [20393,20397]
===
match
---
name: ti [17795,17797]
name: ti [18006,18008]
===
match
---
atom_expr [8954,8962]
atom_expr [9165,9173]
===
match
---
import_from [1646,1683]
import_from [1686,1723]
===
match
---
name: SIGTERM [20305,20312]
name: SIGTERM [18477,18484]
===
match
---
name: job [5717,5720]
name: job [5928,5931]
===
match
---
name: execution_date [9639,9653]
name: execution_date [9850,9864]
===
match
---
suite [16399,16451]
suite [16610,16662]
===
match
---
arglist [7048,7086]
arglist [7259,7297]
===
match
---
atom_expr [18650,18656]
atom_expr [19001,19007]
===
match
---
number: 10 [15557,15559]
number: 10 [15768,15770]
===
match
---
atom_expr [17686,17726]
atom_expr [17897,17937]
===
match
---
name: dag_folder [7806,7816]
name: dag_folder [8017,8027]
===
match
---
trailer [12179,12341]
trailer [12390,12552]
===
match
---
trailer [10501,10507]
trailer [10712,10718]
===
match
---
name: Value [11173,11178]
name: Value [11384,11389]
===
match
---
name: task_function [16638,16651]
name: task_function [16849,16862]
===
match
---
trailer [12494,12502]
trailer [12705,12713]
===
match
---
name: PythonOperator [1427,1441]
name: PythonOperator [1467,1481]
===
match
---
name: get_hostname [5637,5649]
name: get_hostname [5848,5860]
===
match
---
not_test [18185,18207]
not_test [18396,18418]
===
match
---
simple_stmt [8082,8283]
simple_stmt [8293,8494]
===
match
---
assert_stmt [13889,13953]
assert_stmt [14100,14164]
===
match
---
expr_stmt [14190,14380]
expr_stmt [14401,14591]
===
match
---
arith_expr [20713,20729]
arith_expr [21118,21134]
===
match
---
atom_expr [21204,21256]
atom_expr [21609,21661]
===
match
---
trailer [7542,7548]
trailer [7753,7759]
===
match
---
name: value [20439,20444]
name: value [20844,20849]
===
match
---
arglist [5736,5792]
arglist [5947,6003]
===
match
---
string: 'test_state_succeeded1' [12205,12228]
string: 'test_state_succeeded1' [12416,12439]
===
match
---
trailer [16725,16729]
trailer [16936,16940]
===
match
---
with_stmt [10131,10394]
with_stmt [10342,10605]
===
match
---
argument [7059,7086]
argument [7270,7297]
===
match
---
name: i [6178,6179]
name: i [6389,6390]
===
match
---
expr_stmt [6251,6290]
expr_stmt [6462,6501]
===
match
---
atom_expr [2104,2119]
atom_expr [2144,2159]
===
match
---
operator: = [6653,6654]
operator: = [6864,6865]
===
match
---
atom_expr [11733,11741]
atom_expr [11944,11952]
===
match
---
string: 'start' [8727,8734]
string: 'start' [8938,8945]
===
match
---
name: DEFAULT_DATE [5410,5422]
name: DEFAULT_DATE [5621,5633]
===
match
---
name: state [8367,8372]
name: state [8578,8583]
===
match
---
trailer [18205,18207]
trailer [18416,18418]
===
match
---
trailer [8050,8052]
trailer [8261,8263]
===
match
---
atom_expr [10413,10424]
atom_expr [10624,10635]
===
match
---
atom_expr [8411,8425]
atom_expr [8622,8636]
===
match
---
suite [13394,15876]
suite [13605,16087]
===
match
---
name: standard_task_runner [1472,1492]
name: standard_task_runner [1512,1532]
===
match
---
name: clear_db_jobs [2080,2093]
name: clear_db_jobs [2120,2133]
===
match
---
arglist [11179,11185]
arglist [11390,11396]
===
match
---
expr_stmt [4008,4033]
expr_stmt [4014,4039]
===
match
---
argument [9570,9585]
argument [9781,9796]
===
match
---
simple_stmt [21266,21340]
simple_stmt [21671,21745]
===
match
---
name: ti [8954,8956]
name: ti [9165,9167]
===
match
---
trailer [8316,8355]
trailer [8527,8566]
===
match
---
name: TaskInstance [12650,12662]
name: TaskInstance [12861,12873]
===
match
---
operator: = [17141,17142]
operator: = [17352,17353]
===
match
---
assert_stmt [20241,20273]
assert_stmt [20615,20647]
===
match
---
atom_expr [7276,7296]
atom_expr [7487,7507]
===
match
---
simple_stmt [5836,5859]
simple_stmt [6047,6070]
===
match
---
operator: = [5635,5636]
operator: = [5846,5847]
===
match
---
atom_expr [12351,12362]
atom_expr [12562,12573]
===
match
---
argument [14225,14255]
argument [14436,14466]
===
match
---
dictorsetmaker [18936,18953]
dictorsetmaker [19287,19304]
===
match
---
name: job1 [17490,17494]
name: job1 [17701,17705]
===
match
---
comparison [18132,18169]
comparison [18343,18380]
===
match
---
atom [20708,20711]
atom [21113,21116]
===
match
---
simple_stmt [11733,11757]
simple_stmt [11944,11968]
===
match
---
trailer [8677,8679]
trailer [8888,8890]
===
match
---
name: timeout [12845,12852]
name: timeout [13056,13063]
===
match
---
argument [16538,16564]
argument [16749,16775]
===
match
---
name: task [8527,8531]
name: task [8738,8742]
===
match
---
name: on_success_callback [17055,17074]
name: on_success_callback [17266,17285]
===
match
---
operator: , [5455,5456]
operator: , [5666,5667]
===
match
---
name: DAG [2563,2566]
name: DAG [2603,2606]
===
match
---
name: dag [17171,17174]
name: dag [17382,17385]
===
match
---
atom_expr [5553,5573]
atom_expr [5764,5784]
===
match
---
name: time [17892,17896]
name: time [18103,18107]
===
match
---
simple_stmt [5623,5652]
simple_stmt [5834,5863]
===
match
---
name: SequentialExecutor [17559,17577]
name: SequentialExecutor [17770,17788]
===
match
---
name: refresh_from_db [8582,8597]
name: refresh_from_db [8793,8808]
===
match
---
number: 1 [18780,18781]
number: 1 [19131,19132]
===
match
---
arglist [4944,5011]
arglist [5155,5222]
===
match
---
comparison [13104,13138]
comparison [13315,13349]
===
match
---
with_stmt [14410,14676]
with_stmt [14621,14887]
===
match
---
name: DEFAULT_DATE [8230,8242]
name: DEFAULT_DATE [8441,8453]
===
match
---
name: State [21178,21183]
name: State [21583,21588]
===
match
---
atom_expr [14415,14431]
atom_expr [14626,14642]
===
match
---
operator: = [17966,17967]
operator: = [18177,18178]
===
match
---
name: RUNNING [5603,5610]
name: RUNNING [5814,5821]
===
match
---
simple_stmt [6426,6560]
simple_stmt [6637,6771]
===
match
---
trailer [6700,6721]
trailer [6911,6932]
===
match
---
name: StandardTaskRunner [10149,10167]
name: StandardTaskRunner [10360,10378]
===
match
---
funcdef [18213,20488]
funcdef [18539,20893]
===
match
---
name: setUp [2059,2064]
name: setUp [2099,2104]
===
match
---
operator: = [14573,14574]
operator: = [14784,14785]
===
match
---
name: DEFAULT_DATE [19764,19776]
name: DEFAULT_DATE [20115,20127]
===
match
---
atom_expr [7343,7351]
atom_expr [7554,7562]
===
match
---
name: tests [1850,1855]
name: tests [1890,1895]
===
match
---
expr_stmt [6568,6670]
expr_stmt [6779,6881]
===
match
---
argument [3650,3663]
argument [3656,3669]
===
match
---
atom_expr [16939,17123]
atom_expr [17150,17334]
===
match
---
with_stmt [12076,12342]
with_stmt [12287,12553]
===
match
---
trailer [12828,12830]
trailer [13039,13041]
===
match
---
trailer [14867,14869]
trailer [15078,15080]
===
match
---
trailer [3065,3067]
trailer [3105,3107]
===
match
---
name: test_mark_failure_on_failure_callback [10833,10870]
name: test_mark_failure_on_failure_callback [11044,11081]
===
match
---
operator: , [9151,9152]
operator: , [9362,9363]
===
match
---
atom_expr [16228,16241]
atom_expr [16439,16452]
===
match
---
name: start_date [9533,9543]
name: start_date [9744,9754]
===
match
---
atom_expr [11626,11639]
atom_expr [11837,11850]
===
match
---
atom_expr [2329,2344]
atom_expr [2369,2384]
===
match
---
operator: { [20966,20967]
operator: { [21371,21372]
===
match
---
atom [20707,20730]
atom [21112,21135]
===
match
---
name: get_task_instance [8855,8872]
name: get_task_instance [9066,9083]
===
match
---
simple_stmt [5806,5824]
simple_stmt [6017,6035]
===
match
---
atom_expr [8296,8355]
atom_expr [8507,8566]
===
match
---
name: clear [8066,8071]
name: clear [8277,8282]
===
match
---
name: job1 [19815,19819]
name: job1 [20166,20170]
===
match
---
trailer [20227,20232]
trailer [20601,20606]
===
match
---
arglist [3509,3597]
arglist [3515,3603]
===
match
---
operator: = [21221,21222]
operator: = [21626,21627]
===
match
---
operator: = [16603,16604]
operator: = [16814,16815]
===
match
---
name: create_dagrun [2788,2801]
name: create_dagrun [2828,2841]
===
match
---
name: patch [10136,10141]
name: patch [10347,10352]
===
match
---
atom_expr [12417,12636]
atom_expr [12628,12847]
===
match
---
arglist [7806,7869]
arglist [8017,8080]
===
match
---
number: 1 [6133,6134]
number: 1 [6344,6345]
===
match
---
trailer [7144,7184]
trailer [7355,7395]
===
match
---
trailer [4010,4019]
trailer [4016,4025]
===
match
---
name: shared_mem_lock [18632,18647]
name: shared_mem_lock [18983,18998]
===
match
---
trailer [21216,21256]
trailer [21621,21661]
===
match
---
atom_expr [11807,11823]
atom_expr [12018,12034]
===
match
---
expr_stmt [19914,19957]
expr_stmt [20265,20308]
===
match
---
trailer [7900,7905]
trailer [8111,8116]
===
match
---
trailer [11367,11373]
trailer [11578,11584]
===
match
---
parameters [10870,10876]
parameters [11081,11087]
===
match
---
name: models [1300,1306]
name: models [1340,1346]
===
match
---
argument [5501,5510]
argument [5712,5721]
===
match
---
atom_expr [19496,19507]
atom_expr [19847,19858]
===
match
---
simple_stmt [12030,12067]
simple_stmt [12241,12278]
===
match
---
name: value [16913,16918]
name: value [17124,17129]
===
match
---
param [15923,15927]
param [16134,16138]
===
match
---
trailer [20935,20937]
trailer [21340,21342]
===
match
---
string: "clean_db_helper" [20608,20625]
string: "clean_db_helper" [21013,21030]
===
match
---
name: state [11646,11651]
name: state [11857,11862]
===
match
---
atom_expr [20290,20296]
atom_expr [20537,20543]
===
match
---
operator: , [14298,14299]
operator: , [14509,14510]
===
match
---
trailer [17848,17856]
trailer [18059,18067]
===
match
---
argument [21386,21409]
argument [21791,21814]
===
match
---
argument [5317,5336]
argument [5528,5547]
===
match
---
comparison [6314,6346]
comparison [6525,6557]
===
match
---
import_from [1340,1389]
import_from [1380,1429]
===
match
---
atom_expr [8479,8495]
atom_expr [8690,8706]
===
match
---
simple_stmt [3499,3599]
simple_stmt [3505,3605]
===
match
---
atom_expr [18042,18066]
atom_expr [18253,18277]
===
match
---
argument [14645,14660]
argument [14856,14871]
===
match
---
trailer [16912,16918]
trailer [17123,17129]
===
match
---
operator: = [12688,12689]
operator: = [12899,12900]
===
match
---
name: session [5903,5910]
name: session [6114,6121]
===
match
---
trailer [2762,2768]
trailer [2802,2808]
===
match
---
name: task_id [3941,3948]
name: task_id [3947,3954]
===
match
---
operator: = [14687,14688]
operator: = [14898,14899]
===
match
---
name: multiprocessing [881,896]
name: multiprocessing [881,896]
===
match
---
operator: == [16496,16498]
operator: == [16707,16709]
===
match
---
arith_expr [6318,6339]
arith_expr [6529,6550]
===
match
---
expr_stmt [5142,5170]
expr_stmt [5353,5381]
===
match
---
simple_stmt [13097,13139]
simple_stmt [13308,13350]
===
match
---
trailer [2117,2119]
trailer [2157,2159]
===
match
---
name: DAG [18865,18868]
name: DAG [19216,19219]
===
match
---
simple_stmt [8505,8567]
simple_stmt [8716,8778]
===
match
---
assert_stmt [10434,10481]
assert_stmt [10645,10692]
===
match
---
simple_stmt [21112,21124]
simple_stmt [21517,21529]
===
match
---
operator: = [14232,14233]
operator: = [14443,14444]
===
match
---
trailer [21183,21188]
trailer [21588,21593]
===
match
---
atom_expr [10441,10476]
atom_expr [10652,10687]
===
match
---
simple_stmt [9207,9265]
simple_stmt [9418,9476]
===
match
---
name: task_id [3929,3936]
name: task_id [3935,3942]
===
match
---
trailer [20284,20289]
trailer [20692,20697]
===
match
---
operator: = [19763,19764]
operator: = [20114,20115]
===
match
---
expr_stmt [2715,2749]
expr_stmt [2755,2789]
===
match
---
name: failure_callback [18670,18686]
name: failure_callback [19021,19037]
===
match
---
name: refresh_from_db [19789,19804]
name: refresh_from_db [20140,20155]
===
match
---
trailer [2039,2048]
trailer [2079,2088]
===
match
---
atom [20726,20729]
atom [21131,21134]
===
match
---
trailer [7638,7647]
trailer [7849,7858]
===
match
---
name: ti [5553,5555]
name: ti [5764,5766]
===
match
---
param [15410,15418]
param [15621,15629]
===
match
---
name: check_failure [11251,11264]
name: check_failure [11462,11475]
===
match
---
expr_stmt [8024,8052]
expr_stmt [8235,8263]
===
match
---
operator: = [18875,18876]
operator: = [19226,19227]
===
match
---
atom_expr [2031,2048]
atom_expr [2071,2088]
===
match
---
operator: = [20041,20042]
operator: = [20392,20393]
===
match
---
trailer [7599,7611]
trailer [7810,7822]
===
match
---
operator: = [7816,7817]
operator: = [8027,8028]
===
match
---
name: executor [3038,3046]
name: executor [3078,3086]
===
match
---
trailer [5809,5819]
trailer [6020,6030]
===
match
---
atom_expr [8397,8408]
atom_expr [8608,8619]
===
match
---
dotted_name [20584,20607]
dotted_name [20989,21012]
===
match
---
trailer [7450,7452]
trailer [7661,7663]
===
match
---
name: is_alive [18197,18205]
name: is_alive [18408,18416]
===
match
---
atom_expr [20260,20273]
atom_expr [20634,20647]
===
match
---
string: 'i' [13703,13706]
string: 'i' [13914,13917]
===
match
---
arglist [9125,9188]
arglist [9336,9399]
===
match
---
atom_expr [19914,19930]
atom_expr [20265,20281]
===
match
---
name: TestLocalTaskJobPerformance [20633,20660]
name: TestLocalTaskJobPerformance [21038,21065]
===
match
---
simple_stmt [2402,2549]
simple_stmt [2442,2589]
===
match
---
suite [18730,18782]
suite [19081,19133]
===
match
---
name: DagBag [1280,1286]
name: DagBag [1320,1326]
===
match
---
operator: = [4918,4919]
operator: = [5129,5130]
===
match
---
simple_stmt [6307,6347]
simple_stmt [6518,6558]
===
match
---
simple_stmt [7561,7578]
simple_stmt [7772,7789]
===
match
---
funcdef [15881,18208]
funcdef [16092,18419]
===
match
---
argument [12246,12275]
argument [12457,12486]
===
match
---
name: clear [19500,19505]
name: clear [19851,19856]
===
match
---
operator: = [19883,19884]
operator: = [20234,20235]
===
match
---
name: dag [3674,3677]
name: dag [3680,3683]
===
match
---
name: Value [11224,11229]
name: Value [11435,11440]
===
match
---
expr_stmt [16202,16241]
expr_stmt [16413,16452]
===
match
---
trailer [5228,5242]
trailer [5439,5453]
===
match
---
operator: , [12228,12229]
operator: , [12439,12440]
===
match
---
name: ti [20248,20250]
name: ti [20622,20624]
===
match
---
suite [15929,18208]
suite [16140,18419]
===
match
---
trailer [20385,20391]
trailer [20790,20796]
===
match
---
trailer [5571,5573]
trailer [5782,5784]
===
match
---
name: timeout [7600,7607]
name: timeout [7811,7818]
===
match
---
decorated [20583,21472]
decorated [20988,21877]
===
match
---
operator: == [8963,8965]
operator: == [9174,9176]
===
match
---
argument [12483,12502]
argument [12694,12713]
===
match
---
trailer [11178,11186]
trailer [11389,11397]
===
match
---
name: unittest [947,955]
name: unittest [947,955]
===
match
---
expr_stmt [4806,4855]
expr_stmt [5017,5066]
===
match
---
name: airflow [1024,1031]
name: airflow [1064,1071]
===
match
---
name: test_mark_success_on_success_callback [15885,15922]
name: test_mark_success_on_success_callback [16096,16133]
===
match
---
trailer [14752,14768]
trailer [14963,14979]
===
match
---
arglist [21061,21101]
arglist [21466,21506]
===
match
---
operator: = [18934,18935]
operator: = [19285,19286]
===
match
---
name: session [14653,14660]
name: session [14864,14871]
===
match
---
trailer [8817,8835]
trailer [9028,9046]
===
match
---
operator: = [3736,3737]
operator: = [3742,3743]
===
match
---
operator: = [12488,12489]
operator: = [12699,12700]
===
match
---
name: dr [8852,8854]
name: dr [9063,9065]
===
match
---
operator: = [13695,13696]
operator: = [13906,13907]
===
match
---
simple_stmt [5553,5574]
simple_stmt [5764,5785]
===
match
---
trailer [10821,10823]
trailer [11032,11034]
===
match
---
operator: = [20919,20920]
operator: = [21324,21325]
===
match
---
trailer [12760,12831]
trailer [12971,13042]
===
match
---
atom_expr [2759,2770]
atom_expr [2799,2810]
===
match
---
name: start [17743,17748]
name: start [17954,17959]
===
match
---
atom_expr [4339,4352]
atom_expr [4507,4520]
===
match
---
name: timeout [1718,1725]
name: timeout [1758,1765]
===
match
---
arglist [21150,21188]
arglist [21555,21593]
===
match
---
operator: , [4126,4127]
operator: , [4132,4133]
===
match
---
operator: , [4104,4105]
operator: , [4110,4111]
===
match
---
name: LocalTaskJob [9716,9728]
name: LocalTaskJob [9927,9939]
===
match
---
trailer [18030,18032]
trailer [18241,18243]
===
match
---
name: quarantined [9023,9034]
name: quarantined [9234,9245]
===
match
---
argument [3016,3036]
argument [3056,3076]
===
match
---
argument [19380,19416]
argument [19731,19767]
===
match
---
name: process [20322,20329]
name: process [20727,20734]
===
match
---
arglist [4088,4157]
arglist [4094,4163]
===
match
---
name: unittest [855,863]
name: unittest [855,863]
===
match
---
name: essential_attr [3078,3092]
name: essential_attr [3118,3132]
===
match
---
operator: { [16604,16605]
operator: { [16815,16816]
===
match
---
name: State [8375,8380]
name: State [8586,8591]
===
match
---
name: heartrate [6330,6339]
name: heartrate [6541,6550]
===
match
---
name: session [8903,8910]
name: session [9114,9121]
===
match
---
name: State [4339,4344]
name: State [4507,4512]
===
match
---
name: dummy_return_code [15385,15402]
name: dummy_return_code [15596,15613]
===
match
---
simple_stmt [19263,19449]
simple_stmt [19614,19800]
===
match
---
suite [17782,17908]
suite [17993,18119]
===
match
---
atom_expr [2956,2967]
atom_expr [2996,3007]
===
match
---
name: State [12489,12494]
name: State [12700,12705]
===
match
---
operator: , [17112,17113]
operator: , [17323,17324]
===
match
---
trailer [14799,14870]
trailer [15010,15081]
===
match
---
atom_expr [6577,6670]
atom_expr [6788,6881]
===
match
---
name: ti [4008,4010]
name: ti [4014,4016]
===
match
---
name: str [20921,20924]
name: str [21326,21329]
===
match
---
name: test_localtaskjob_heartbeat [3409,3436]
name: test_localtaskjob_heartbeat [3425,3452]
===
match
---
assert_stmt [6307,6346]
assert_stmt [6518,6557]
===
match
---
name: include_examples [9165,9181]
name: include_examples [9376,9392]
===
match
---
import_name [822,835]
import_name [822,835]
===
match
---
name: FAILED [15786,15792]
name: FAILED [15997,16003]
===
match
---
name: utils [1697,1702]
name: utils [1737,1742]
===
match
---
decorator [20752,20811]
decorator [21157,21216]
===
match
---
name: ti [7485,7487]
name: ti [7696,7698]
===
match
---
simple_stmt [4328,4353]
simple_stmt [4496,4521]
===
match
---
name: pid [5667,5670]
name: pid [5878,5881]
===
match
---
name: value [18159,18164]
name: value [18370,18375]
===
match
---
expr_stmt [18632,18656]
expr_stmt [18983,19007]
===
match
---
name: dag [6737,6740]
name: dag [6948,6951]
===
match
---
operator: = [5368,5369]
operator: = [5579,5580]
===
match
---
operator: = [16919,16920]
operator: = [17130,17131]
===
match
---
name: Lock [904,908]
name: Lock [904,908]
===
match
---
operator: = [21242,21243]
operator: = [21647,21648]
===
match
---
atom_expr [7485,7493]
atom_expr [7696,7704]
===
match
---
name: task_id [21061,21068]
name: task_id [21466,21473]
===
match
---
operator: = [19250,19251]
operator: = [19601,19602]
===
match
---
argument [20335,20345]
argument [20740,20750]
===
match
---
expr_stmt [6103,6135]
expr_stmt [6314,6346]
===
match
---
name: create_session [11574,11588]
name: create_session [11785,11799]
===
match
---
trailer [7660,7676]
trailer [7871,7887]
===
match
---
trailer [9002,9004]
trailer [9213,9215]
===
match
---
simple_stmt [10754,10800]
simple_stmt [10965,11011]
===
match
---
operator: = [17438,17439]
operator: = [17649,17650]
===
match
---
trailer [13903,13914]
trailer [14114,14125]
===
match
---
operator: , [3036,3037]
operator: , [3076,3077]
===
match
---
trailer [19056,19060]
trailer [19407,19411]
===
match
---
expr_stmt [9898,9922]
expr_stmt [10109,10133]
===
match
---
name: State [7694,7699]
name: State [7905,7910]
===
match
---
string: 'i' [18565,18568]
string: 'i' [18916,18919]
===
match
---
trailer [13983,14027]
trailer [14194,14238]
===
match
---
assert_stmt [13097,13138]
assert_stmt [13308,13349]
===
match
---
string: 'dag_run' [16478,16487]
string: 'dag_run' [16689,16698]
===
match
---
expr_stmt [16416,16450]
expr_stmt [16627,16661]
===
match
---
trailer [6008,6027]
trailer [6219,6238]
===
match
---
atom_expr [2927,2968]
atom_expr [2967,3008]
===
match
---
name: dagbag [1266,1272]
name: dagbag [1306,1312]
===
match
---
name: task_terminated_externally [11195,11221]
name: task_terminated_externally [11406,11432]
===
match
---
name: job [5806,5809]
name: job [6017,6020]
===
match
---
simple_stmt [7432,7453]
simple_stmt [7643,7664]
===
match
---
operator: = [7607,7608]
operator: = [7818,7819]
===
match
---
atom_expr [6005,6027]
atom_expr [6216,6238]
===
match
---
trailer [8597,8599]
trailer [8808,8810]
===
match
---
operator: == [15871,15873]
operator: == [16082,16084]
===
match
---
trailer [20026,20034]
trailer [20377,20385]
===
match
---
trailer [13745,13747]
trailer [13956,13958]
===
match
---
name: create_dagrun [3703,3716]
name: create_dagrun [3709,3722]
===
match
---
trailer [5625,5634]
trailer [5836,5845]
===
match
---
name: dag [17109,17112]
name: dag [17320,17323]
===
match
---
argument [19738,19747]
argument [20089,20098]
===
match
---
name: airflow [1292,1299]
name: airflow [1332,1339]
===
match
---
expr_stmt [10005,10029]
expr_stmt [10216,10240]
===
match
---
trailer [12001,12010]
trailer [12212,12221]
===
match
---
operator: = [6889,6890]
operator: = [7100,7101]
===
match
---
string: 'owner' [16605,16612]
string: 'owner' [16816,16823]
===
match
---
argument [5260,5299]
argument [5471,5510]
===
match
---
factor [15474,15476]
factor [15685,15687]
===
match
---
name: task [8881,8885]
name: task [9092,9096]
===
match
---
operator: == [8934,8936]
operator: == [9145,9147]
===
match
---
operator: = [4954,4955]
operator: = [5165,5166]
===
match
---
name: close [8997,9002]
name: close [9208,9213]
===
match
---
name: create_session [1631,1645]
name: create_session [1671,1685]
===
match
---
argument [17222,17235]
argument [17433,17446]
===
match
---
atom_expr [3505,3598]
atom_expr [3511,3604]
===
match
---
name: SequentialExecutor [4137,4155]
name: SequentialExecutor [4143,4161]
===
match
---
assert_stmt [13057,13088]
assert_stmt [13268,13299]
===
match
---
name: executor [9751,9759]
name: executor [9962,9970]
===
match
---
trailer [19788,19804]
trailer [20139,20155]
===
match
---
trailer [20265,20273]
trailer [20639,20647]
===
match
---
name: job1 [7125,7129]
name: job1 [7336,7340]
===
match
---
name: DAG [14116,14119]
name: DAG [14327,14330]
===
match
---
atom_expr [10364,10388]
atom_expr [10575,10599]
===
match
---
suite [6086,6347]
suite [6297,6558]
===
match
---
name: settings [17143,17151]
name: settings [17354,17362]
===
match
---
simple_stmt [2305,2321]
simple_stmt [2345,2361]
===
match
---
atom_expr [7468,7481]
atom_expr [7679,7692]
===
match
---
expr_stmt [5717,5793]
expr_stmt [5928,6004]
===
match
---
name: pop [9989,9992]
name: pop [10200,10203]
===
match
---
name: side_effect [4831,4842]
name: side_effect [5042,5053]
===
match
---
operator: = [16226,16227]
operator: = [16437,16438]
===
match
---
simple_stmt [14110,14182]
simple_stmt [14321,14393]
===
match
---
string: "test" [9439,9445]
string: "test" [9650,9656]
===
match
---
name: commit [11815,11821]
name: commit [12026,12032]
===
match
---
name: PythonOperator [19270,19284]
name: PythonOperator [19621,19635]
===
match
---
name: success_callback_called [16202,16225]
name: success_callback_called [16413,16436]
===
match
---
operator: , [16288,16289]
operator: , [16499,16500]
===
match
---
name: start_date [2616,2626]
name: start_date [2656,2666]
===
match
---
trailer [10148,10183]
trailer [10359,10394]
===
match
---
name: test_utils [1737,1747]
name: test_utils [1777,1787]
===
match
---
name: dag [19496,19499]
name: dag [19847,19850]
===
match
---
name: session [17990,17997]
name: session [18201,18208]
===
match
---
dotted_name [1216,1234]
dotted_name [1256,1274]
===
match
---
trailer [17721,17725]
trailer [17932,17936]
===
match
---
suite [4710,6347]
suite [4921,6558]
===
match
---
argument [16566,16589]
argument [16777,16800]
===
match
---
expr_stmt [1947,2005]
expr_stmt [1987,2045]
===
match
---
name: job1 [10785,10789]
name: job1 [10996,11000]
===
match
---
operator: = [5409,5410]
operator: = [5620,5621]
===
match
---
name: get_task_instance [3911,3928]
name: get_task_instance [3917,3934]
===
match
---
number: 0.5 [6343,6346]
number: 0.5 [6554,6557]
===
match
---
arglist [13703,13709]
arglist [13914,13920]
===
match
---
trailer [15770,15776]
trailer [15981,15987]
===
match
---
name: start_date [6958,6968]
name: start_date [7169,7179]
===
match
---
trailer [20221,20227]
trailer [20595,20601]
===
match
---
argument [17282,17309]
argument [17493,17520]
===
match
---
simple_stmt [16886,16923]
simple_stmt [17097,17134]
===
match
---
name: job1 [4600,4604]
name: job1 [4811,4815]
===
match
---
trailer [8787,8791]
trailer [8998,9002]
===
match
---
trailer [7792,7879]
trailer [8003,8090]
===
match
---
arglist [6857,7011]
arglist [7068,7222]
===
match
---
trailer [11780,11786]
trailer [11991,11997]
===
match
---
atom_expr [8453,8470]
atom_expr [8664,8681]
===
match
---
operator: = [12312,12313]
operator: = [12523,12524]
===
match
---
name: commit [4050,4056]
name: commit [4056,4062]
===
match
---
operator: = [21156,21157]
operator: = [21561,21562]
===
match
---
simple_stmt [20060,20076]
simple_stmt [20411,20427]
===
match
---
trailer [6065,6084]
trailer [6276,6295]
===
match
---
assert_stmt [18178,18207]
assert_stmt [18389,18418]
===
match
---
name: sleep [4850,4855]
name: sleep [5061,5066]
===
match
---
number: 60 [16726,16728]
number: 60 [16937,16939]
===
match
---
atom_expr [4375,4389]
atom_expr [4543,4557]
===
match
---
operator: = [8850,8851]
operator: = [9061,9062]
===
match
---
name: State [6890,6895]
name: State [7101,7106]
===
match
---
name: process [7587,7594]
name: process [7798,7805]
===
match
---
simple_stmt [8608,8681]
simple_stmt [8819,8892]
===
match
---
atom_expr [20156,20164]
atom_expr [20507,20515]
===
match
---
suite [2393,3376]
suite [2433,3416]
===
match
---
atom_expr [20248,20256]
atom_expr [20622,20630]
===
match
---
name: ignore_ti_state [3016,3031]
name: ignore_ti_state [3056,3071]
===
match
---
expr_stmt [11344,11378]
expr_stmt [11555,11589]
===
match
---
operator: , [12799,12800]
operator: , [13010,13011]
===
match
---
simple_stmt [4294,4320]
simple_stmt [4455,4488]
===
match
---
operator: , [8734,8735]
operator: , [8945,8946]
===
match
---
name: heartrate [10790,10799]
name: heartrate [11001,11010]
===
match
---
atom_expr [20925,20937]
atom_expr [21330,21342]
===
match
---
name: dag_id [16538,16544]
name: dag_id [16749,16755]
===
match
---
atom_expr [6160,6180]
atom_expr [6371,6391]
===
match
---
name: range [7314,7319]
name: range [7525,7530]
===
match
---
argument [14362,14369]
argument [14573,14580]
===
match
---
number: 1 [20448,20449]
number: 1 [20853,20854]
===
match
---
comparison [10314,10340]
comparison [10525,10551]
===
match
---
trailer [15716,15720]
trailer [15927,15931]
===
match
---
operator: == [18165,18167]
operator: == [18376,18378]
===
match
---
name: task_instance [12761,12774]
name: task_instance [12972,12985]
===
match
---
name: LocalTaskJob [1198,1210]
name: LocalTaskJob [1238,1250]
===
match
---
name: start_date [18897,18907]
name: start_date [19248,19258]
===
match
---
arglist [5501,5539]
arglist [5712,5750]
===
match
---
param [13357,13362]
param [13568,13573]
===
match
---
argument [12085,12111]
argument [12296,12322]
===
match
---
simple_stmt [3694,3895]
simple_stmt [3700,3901]
===
match
---
name: value [13128,13133]
name: value [13339,13344]
===
match
---
trailer [2734,2749]
trailer [2774,2789]
===
match
---
simple_stmt [13057,13089]
simple_stmt [13268,13300]
===
match
---
expr_stmt [3263,3340]
expr_stmt [3303,3380]
===
match
---
name: RUNNING [20174,20181]
name: RUNNING [20525,20532]
===
match
---
name: local_task_job [1176,1190]
name: local_task_job [1216,1230]
===
match
---
operator: , [5336,5337]
operator: , [5547,5548]
===
match
---
simple_stmt [18042,18067]
simple_stmt [18253,18278]
===
match
---
simple_stmt [9606,9668]
simple_stmt [9817,9879]
===
match
---
simple_stmt [10357,10394]
simple_stmt [10568,10605]
===
match
---
name: session [17368,17375]
name: session [17579,17586]
===
match
---
name: state [1665,1670]
name: state [1705,1710]
===
match
---
name: task [12668,12672]
name: task [12879,12883]
===
match
---
comparison [20362,20396]
comparison [20767,20801]
===
match
---
trailer [17959,17965]
trailer [18170,18176]
===
match
---
funcdef [14037,14101]
funcdef [14248,14312]
===
match
---
name: process [7252,7259]
name: process [7463,7470]
===
match
---
trailer [8956,8962]
trailer [9167,9173]
===
match
---
expr_stmt [2557,2683]
expr_stmt [2597,2723]
===
match
---
dotted_name [1024,1042]
dotted_name [1064,1082]
===
match
---
name: shared_mem_lock [16383,16398]
name: shared_mem_lock [16594,16609]
===
match
---
name: _ [17764,17765]
name: _ [17975,17976]
===
match
---
atom_expr [17957,17965]
atom_expr [18168,18176]
===
match
---
argument [14491,14504]
argument [14702,14715]
===
match
---
name: SequentialExecutor [14849,14867]
name: SequentialExecutor [15060,15078]
===
match
---
name: return_codes [20882,20894]
name: return_codes [21287,21299]
===
match
---
name: Value [910,915]
name: Value [910,915]
===
match
---
simple_stmt [17990,18008]
simple_stmt [18201,18219]
===
match
---
name: State [2836,2841]
name: State [2876,2881]
===
match
---
operator: = [17108,17109]
operator: = [17319,17320]
===
match
---
param [2065,2069]
param [2105,2109]
===
match
---
funcdef [2350,3376]
funcdef [2390,3416]
===
match
---
operator: = [3550,3551]
operator: = [3556,3557]
===
match
---
string: 'test_state_succeeded1' [16975,16998]
string: 'test_state_succeeded1' [17186,17209]
===
match
---
name: task [14702,14706]
name: task [14913,14917]
===
match
---
comparison [10364,10393]
comparison [10575,10604]
===
match
---
argument [2998,3014]
argument [3038,3054]
===
match
---
simple_stmt [20120,20141]
simple_stmt [20471,20492]
===
match
---
operator: = [4101,4102]
operator: = [4107,4108]
===
match
---
name: shared_mem_lock [19184,19199]
name: shared_mem_lock [19535,19550]
===
match
---
operator: , [17309,17310]
operator: , [17520,17521]
===
match
---
trailer [21135,21149]
trailer [21540,21554]
===
match
---
atom_expr [4417,4434]
atom_expr [4585,4602]
===
match
---
name: ti [18004,18006]
name: ti [18215,18217]
===
match
---
atom_expr [8087,8282]
atom_expr [8298,8493]
===
match
---
trailer [8581,8597]
trailer [8792,8808]
===
match
---
expr_stmt [5483,5540]
expr_stmt [5694,5751]
===
match
---
simple_stmt [11837,11852]
simple_stmt [12048,12063]
===
match
---
name: context [11466,11473]
name: context [11677,11684]
===
match
---
name: TaskInstance [19725,19737]
name: TaskInstance [20076,20088]
===
match
---
suite [7369,7392]
suite [7580,7603]
===
match
---
trailer [3508,3598]
trailer [3514,3604]
===
match
---
name: dag [16528,16531]
name: dag [16739,16742]
===
match
---
name: start [7260,7265]
name: start [7471,7476]
===
match
---
trailer [4330,4336]
trailer [4498,4504]
===
match
---
name: attr [3195,3199]
name: attr [3235,3239]
===
match
---
operator: , [19437,19438]
operator: , [19788,19789]
===
match
---
name: get_dag [5155,5162]
name: get_dag [5366,5373]
===
match
---
atom_expr [19270,19448]
atom_expr [19621,19799]
===
match
---
operator: = [17296,17297]
operator: = [17507,17508]
===
match
---
atom_expr [5148,5170]
atom_expr [5359,5381]
===
match
---
trailer [19519,19533]
trailer [19870,19884]
===
match
---
expr_stmt [18747,18781]
expr_stmt [19098,19132]
===
match
---
string: 'owner1' [16614,16622]
string: 'owner1' [16825,16833]
===
match
---
name: task [5183,5187]
name: task [5394,5398]
===
match
---
trailer [3480,3488]
trailer [3486,3494]
===
match
---
atom_expr [8575,8599]
atom_expr [8786,8810]
===
match
---
trailer [3649,3664]
trailer [3655,3670]
===
match
---
comparison [7468,7493]
comparison [7679,7704]
===
match
---
expr_stmt [8847,8911]
expr_stmt [9058,9122]
===
match
---
simple_stmt [10434,10482]
simple_stmt [10645,10693]
===
match
---
trailer [8090,8104]
trailer [8301,8315]
===
match
---
expr_stmt [13671,13710]
expr_stmt [13882,13921]
===
match
---
operator: , [10083,10084]
operator: , [10294,10295]
===
match
---
operator: = [2626,2627]
operator: = [2666,2667]
===
match
---
atom_expr [9353,9371]
atom_expr [9564,9582]
===
match
---
comparison [6005,6031]
comparison [6216,6242]
===
match
---
string: 'i' [16285,16288]
string: 'i' [16496,16499]
===
match
---
name: State [19580,19585]
name: State [19931,19936]
===
match
---
suite [14059,14101]
suite [14270,14312]
===
match
---
simple_stmt [17892,17908]
simple_stmt [18103,18119]
===
match
---
operator: = [3046,3047]
operator: = [3086,3087]
===
match
---
operator: = [18062,18063]
operator: = [18273,18274]
===
match
---
expr_stmt [20001,20051]
expr_stmt [20352,20402]
===
match
---
number: 13 [21445,21447]
number: 15 [21850,21852]
===
match
---
name: TEST_DAG_FOLDER [1947,1962]
name: TEST_DAG_FOLDER [1987,2002]
===
match
---
name: task_id [5203,5210]
name: task_id [5414,5421]
===
match
---
string: "test" [8125,8131]
string: "test" [8336,8342]
===
match
---
argument [21150,21170]
argument [21555,21575]
===
match
---
parameters [2064,2070]
parameters [2104,2110]
===
match
---
name: airflow [1395,1402]
name: airflow [1435,1442]
===
match
---
atom_expr [8434,8440]
atom_expr [8645,8651]
===
match
---
atom_expr [7535,7552]
atom_expr [7746,7763]
===
match
---
name: session [3958,3965]
name: session [3964,3971]
===
match
---
name: dr [8082,8084]
name: dr [8293,8295]
===
match
---
trailer [8156,8164]
trailer [8367,8375]
===
match
---
argument [7846,7868]
argument [8057,8079]
===
match
---
operator: , [5299,5300]
operator: , [5510,5511]
===
match
---
operator: = [2865,2866]
operator: = [2905,2906]
===
match
---
name: job1 [8783,8787]
name: job1 [8994,8998]
===
match
---
operator: , [8205,8206]
operator: , [8416,8417]
===
match
---
operator: = [17398,17399]
operator: = [17609,17610]
===
match
---
operator: = [9632,9633]
operator: = [9843,9844]
===
match
---
name: run_id [19547,19553]
name: run_id [19898,19904]
===
match
---
argument [2830,2849]
argument [2870,2889]
===
match
---
name: dispose [19983,19990]
name: dispose [20334,20341]
===
match
---
name: heartbeat_callback [4605,4623]
name: heartbeat_callback [4816,4834]
===
match
---
simple_stmt [16301,16326]
simple_stmt [16512,16537]
===
match
---
atom_expr [17559,17579]
atom_expr [17770,17790]
===
match
---
trailer [3991,3999]
trailer [3997,4005]
===
match
---
name: run_id [2815,2821]
name: run_id [2855,2861]
===
match
---
trailer [6895,6903]
trailer [7106,7114]
===
match
---
name: unique_prefix [20967,20980]
name: unique_prefix [21372,21385]
===
match
---
trailer [3940,3948]
trailer [3946,3954]
===
match
---
operator: { [2654,2655]
operator: { [2694,2695]
===
match
---
param [14055,14057]
param [14266,14268]
===
match
---
atom_expr [4920,5025]
atom_expr [5131,5236]
===
match
---
parameters [18686,18695]
parameters [19037,19046]
===
match
---
expr_stmt [3903,3966]
expr_stmt [3909,3972]
===
match
---
import_from [1287,1339]
import_from [1327,1379]
===
match
---
atom_expr [3171,3190]
atom_expr [3211,3230]
===
match
---
operator: = [12667,12668]
operator: = [12878,12879]
===
match
---
operator: = [3011,3012]
operator: = [3051,3052]
===
match
---
operator: = [12091,12092]
operator: = [12302,12303]
===
match
---
simple_stmt [11391,11447]
simple_stmt [11602,11658]
===
match
---
expr_stmt [5038,5075]
expr_stmt [5249,5286]
===
match
---
name: sleep [17897,17902]
name: sleep [18108,18113]
===
match
---
name: state [4331,4336]
name: state [4499,4504]
===
match
---
operator: = [6863,6864]
operator: = [7074,7075]
===
match
---
simple_stmt [13147,13192]
simple_stmt [13358,13403]
===
match
---
atom_expr [4870,4886]
atom_expr [5081,5097]
===
match
---
name: engine [19976,19982]
name: engine [20327,20333]
===
match
---
name: self [2221,2225]
name: self [2261,2265]
===
match
---
atom_expr [3472,3490]
atom_expr [3478,3496]
===
match
---
name: refresh_from_db [17798,17813]
name: refresh_from_db [18009,18024]
===
match
---
operator: > [6028,6029]
operator: > [6239,6240]
===
match
---
name: task_function [12262,12275]
name: task_function [12473,12486]
===
match
---
expr_stmt [17676,17726]
expr_stmt [17887,17937]
===
match
---
trailer [5735,5793]
trailer [5946,6004]
===
match
---
atom_expr [7502,7510]
atom_expr [7713,7721]
===
match
---
name: time [843,847]
name: time [843,847]
===
match
---
name: session [12614,12621]
name: session [12825,12832]
===
match
---
atom_expr [2985,3068]
atom_expr [3025,3108]
===
match
---
arglist [14800,14869]
arglist [15011,15080]
===
match
---
trailer [14429,14431]
trailer [14640,14642]
===
match
---
operator: , [14004,14005]
operator: , [14215,14216]
===
match
---
with_stmt [15544,15723]
with_stmt [15755,15934]
===
match
---
name: task_function [14041,14054]
name: task_function [14252,14265]
===
match
---
name: ti [3975,3977]
name: ti [3981,3983]
===
match
---
name: run_id [9432,9438]
name: run_id [9643,9649]
===
match
---
expr_stmt [3462,3490]
expr_stmt [3468,3496]
===
match
---
import_from [1519,1553]
import_from [1559,1593]
===
match
---
simple_stmt [8783,8794]
simple_stmt [8994,9005]
===
match
---
name: pytest [6353,6359]
name: pytest [6564,6570]
===
match
---
atom_expr [20282,20313]
atom_expr [20690,20718]
===
match
---
operator: = [3936,3937]
operator: = [3942,3943]
===
match
---
name: Lock [18650,18654]
name: Lock [19001,19005]
===
match
---
name: success_callback [16339,16355]
name: success_callback [16550,16566]
===
match
---
name: dagbag [9213,9219]
name: dagbag [9424,9430]
===
match
---
simple_stmt [9676,9701]
simple_stmt [9887,9912]
===
match
---
arglist [16285,16291]
arglist [16496,16502]
===
match
---
expr_stmt [1902,1946]
expr_stmt [1942,1986]
===
match
---
trailer [6786,6794]
trailer [6997,7005]
===
match
---
simple_stmt [2922,2969]
simple_stmt [2962,3009]
===
match
---
atom_expr [21424,21448]
atom_expr [21829,21853]
===
match
---
simple_stmt [18632,18657]
simple_stmt [18983,19008]
===
match
---
trailer [14473,14675]
trailer [14684,14886]
===
match
---
operator: = [4316,4317]
operator: = [4484,4485]
===
match
---
atom_expr [2138,2174]
atom_expr [2178,2214]
===
match
---
simple_stmt [14750,14771]
simple_stmt [14961,14982]
===
match
---
atom_expr [15549,15560]
atom_expr [15760,15771]
===
match
---
name: SequentialExecutor [1139,1157]
name: SequentialExecutor [1179,1197]
===
match
---
simple_stmt [916,942]
simple_stmt [916,942]
===
match
---
name: get_hostname [8411,8423]
name: get_hostname [8622,8634]
===
match
---
operator: , [3854,3855]
operator: , [3860,3861]
===
match
---
atom_expr [21178,21188]
atom_expr [21583,21593]
===
match
---
operator: = [8032,8033]
operator: = [8243,8244]
===
match
---
string: 'test_mark_success' [6701,6720]
string: 'test_mark_success' [6912,6931]
===
match
---
trailer [9224,9228]
trailer [9435,9439]
===
match
---
name: Session [8043,8050]
name: Session [8254,8261]
===
match
---
param [9081,9085]
param [9292,9296]
===
match
---
name: dag [21094,21097]
name: dag [21499,21502]
===
match
---
name: DummyOperator [21047,21060]
name: DummyOperator [21452,21465]
===
match
---
trailer [11588,11590]
trailer [11799,11801]
===
match
---
argument [7600,7610]
argument [7811,7821]
===
match
---
name: session [19685,19692]
name: session [20036,20043]
===
match
---
name: State [15780,15785]
name: State [15991,15996]
===
match
---
name: signal [829,835]
name: signal [829,835]
===
match
---
name: airflow [1559,1566]
name: airflow [1599,1606]
===
match
---
name: job [21462,21465]
name: job [21867,21870]
===
match
---
operator: = [12063,12064]
operator: = [12274,12275]
===
match
---
name: default_args [2641,2653]
name: default_args [2681,2693]
===
match
---
name: value [20386,20391]
name: value [20791,20796]
===
match
---
name: mock_pid [4294,4302]
name: job1 [4455,4459]
===
match
---
name: AirflowFailException [14006,14026]
name: AirflowFailException [14217,14237]
===
match
---
name: mock_base_job_sleep [4811,4830]
name: mock_base_job_sleep [5022,5041]
===
match
---
expr_stmt [9343,9371]
expr_stmt [9554,9582]
===
match
---
atom_expr [10280,10290]
atom_expr [10491,10501]
===
match
---
name: task_runner [17594,17605]
name: task_runner [17805,17816]
===
match
---
atom_expr [4443,4459]
atom_expr [4611,4627]
===
match
---
argument [12452,12465]
argument [12663,12676]
===
match
---
operator: = [3503,3504]
operator: = [3509,3510]
===
match
---
dotted_name [1731,1755]
dotted_name [1771,1795]
===
match
---
name: dag [20947,20950]
name: dag [21352,21355]
===
match
---
operator: , [3776,3777]
operator: , [3782,3783]
===
match
---
name: executors [1102,1111]
name: executors [1142,1151]
===
match
---
name: RUNNING [11632,11639]
name: RUNNING [11843,11850]
===
match
---
name: job1 [15712,15716]
name: job1 [15923,15927]
===
match
---
operator: = [2782,2783]
operator: = [2822,2823]
===
match
---
atom_expr [11466,11486]
atom_expr [11677,11697]
===
match
---
arglist [20957,21030]
arglist [21362,21435]
===
match
---
import_from [1390,1441]
import_from [1430,1481]
===
match
---
operator: , [9519,9520]
operator: , [9730,9731]
===
match
---
string: 'dag_run' [11406,11415]
string: 'dag_run' [11617,11626]
===
match
---
operator: == [15777,15779]
operator: == [15988,15990]
===
match
---
trailer [12434,12636]
trailer [12645,12847]
===
match
---
name: shared_mem_lock [16853,16868]
name: shared_mem_lock [17064,17079]
===
match
---
name: os [20282,20284]
name: os [20690,20692]
===
match
---
trailer [9470,9478]
trailer [9681,9689]
===
match
---
name: start_date [17323,17333]
name: start_date [17534,17544]
===
match
---
operator: , [17375,17376]
operator: , [17586,17587]
===
match
---
param [20854,20859]
param [21259,21264]
===
match
---
operator: = [5146,5147]
operator: = [5357,5358]
===
match
---
atom_expr [9615,9667]
atom_expr [9826,9878]
===
match
---
trailer [11229,11237]
trailer [11440,11448]
===
match
---
name: utils [1610,1615]
name: utils [1650,1655]
===
match
---
name: clear_db_runs [1831,1844]
name: clear_db_runs [1871,1884]
===
match
---
name: failure_callback [13761,13777]
name: failure_callback [13972,13988]
===
match
---
trailer [8627,8680]
trailer [8838,8891]
===
match
---
funcdef [11247,11525]
funcdef [11458,11736]
===
match
---
funcdef [20508,20581]
funcdef [20913,20986]
===
match
---
name: pytest [9011,9017]
name: pytest [9222,9228]
===
match
---
simple_stmt [1158,1211]
simple_stmt [1198,1251]
===
match
---
name: self [2183,2187]
name: self [2223,2227]
===
match
---
argument [4106,4126]
argument [4112,4132]
===
match
---
name: task_id [12197,12204]
name: task_id [12408,12415]
===
match
---
arglist [12452,12622]
arglist [12663,12833]
===
match
---
dotted_name [1850,1880]
dotted_name [1890,1920]
===
match
---
operator: == [13134,13136]
operator: == [13345,13347]
===
match
---
trailer [5974,5983]
trailer [6185,6194]
===
match
---
trailer [10422,10424]
trailer [10633,10635]
===
match
---
operator: , [19747,19748]
operator: , [20098,20099]
===
match
---
name: State [10511,10516]
name: State [10722,10727]
===
match
---
operator: , [7832,7833]
operator: , [8043,8044]
===
match
---
trailer [21465,21469]
trailer [21870,21874]
===
match
---
atom_expr [18016,18032]
atom_expr [18227,18243]
===
match
---
operator: = [8150,8151]
operator: = [8361,8362]
===
match
---
name: dag [6679,6682]
name: dag [6890,6893]
===
match
---
name: Value [13697,13702]
name: Value [13908,13913]
===
match
---
atom_expr [14787,14870]
atom_expr [14998,15081]
===
match
---
name: task [7048,7052]
name: task [7259,7263]
===
match
---
name: job [5971,5974]
name: job [6182,6185]
===
match
---
name: environ [1968,1975]
name: environ [2008,2015]
===
match
---
string: 'test_on_failure' [19306,19323]
string: 'test_on_failure' [19657,19674]
===
match
---
name: mock [937,941]
name: mock [937,941]
===
match
---
comparison [17831,17856]
comparison [18042,18067]
===
match
---
dotted_name [947,960]
dotted_name [947,960]
===
match
---
decorator [20490,20508]
decorator [20895,20913]
===
match
---
string: 'owner' [3579,3586]
string: 'owner' [3585,3592]
===
match
---
operator: == [20392,20394]
operator: == [20797,20799]
===
match
---
string: 'test_localtaskjob_heartbeat' [3509,3538]
string: 'test_localtaskjob_heartbeat' [3515,3544]
===
match
---
simple_stmt [7461,7494]
simple_stmt [7672,7705]
===
match
---
operator: = [6735,6736]
operator: = [6946,6947]
===
match
---
trailer [11473,11486]
trailer [11684,11697]
===
match
---
simple_stmt [16250,16293]
simple_stmt [16461,16504]
===
match
---
for_stmt [7305,7453]
for_stmt [7516,7664]
===
match
---
atom_expr [18610,18623]
atom_expr [18961,18974]
===
match
---
expr_stmt [8505,8566]
expr_stmt [8716,8777]
===
match
---
operator: = [5785,5786]
operator: = [5996,5997]
===
match
---
expr_stmt [17395,17452]
expr_stmt [17606,17663]
===
match
---
import_from [1784,1844]
import_from [1824,1884]
===
match
---
argument [3831,3854]
argument [3837,3860]
===
match
---
trailer [3716,3894]
trailer [3722,3900]
===
match
---
trailer [20138,20140]
trailer [20489,20491]
===
match
---
name: clear [21116,21121]
name: clear [21521,21526]
===
match
---
atom_expr [15712,15722]
atom_expr [15923,15933]
===
match
---
simple_stmt [5971,5986]
simple_stmt [6182,6197]
===
match
---
atom_expr [19822,19905]
atom_expr [20173,20256]
===
match
---
name: run [13013,13016]
name: run [13224,13227]
===
match
---
name: start_date [16566,16576]
name: start_date [16777,16787]
===
match
---
name: session [7535,7542]
name: session [7746,7753]
===
match
---
operator: , [7057,7058]
operator: , [7268,7269]
===
match
---
name: session [8264,8271]
name: session [8475,8482]
===
match
---
atom [3170,3218]
atom [3210,3258]
===
match
---
import_from [1442,1518]
import_from [1482,1558]
===
match
---
name: dag [18859,18862]
name: dag [19210,19213]
===
match
---
name: session [3462,3469]
name: session [3468,3475]
===
match
---
name: DEFAULT_DATE [9507,9519]
name: DEFAULT_DATE [9718,9730]
===
match
---
suite [11602,11824]
suite [11813,12035]
===
match
---
expr_stmt [5586,5610]
expr_stmt [5797,5821]
===
match
---
operator: , [11233,11234]
operator: , [11444,11445]
===
match
---
simple_stmt [20565,20581]
simple_stmt [20970,20986]
===
match
---
trailer [3488,3490]
trailer [3494,3496]
===
match
---
name: task_id [2948,2955]
name: task_id [2988,2995]
===
match
---
name: state [5589,5594]
name: state [5800,5805]
===
match
---
param [2282,2286]
param [2322,2326]
===
match
---
name: task_function [17028,17041]
name: task_function [17239,17252]
===
match
---
with_stmt [2693,2750]
with_stmt [2733,2790]
===
match
---
name: session [4443,4450]
name: session [4611,4618]
===
match
---
operator: , [7868,7869]
operator: , [8079,8080]
===
match
---
name: op1 [3937,3940]
name: op1 [3943,3946]
===
match
---
simple_stmt [7193,7244]
simple_stmt [7404,7455]
===
match
---
expr_stmt [5623,5651]
expr_stmt [5834,5862]
===
match
---
string: "test" [6864,6870]
string: "test" [7075,7081]
===
match
---
assert_stmt [10754,10799]
assert_stmt [10965,11010]
===
match
---
atom_expr [4042,4058]
atom_expr [4048,4064]
===
match
---
name: process [17676,17683]
name: process [17887,17894]
===
match
---
argument [3757,3776]
argument [3763,3782]
===
match
---
name: create_dagrun [6830,6843]
name: create_dagrun [7041,7054]
===
match
---
name: task_instance [5736,5749]
name: task_instance [5947,5960]
===
match
---
operator: == [7352,7354]
operator: == [7563,7565]
===
match
---
atom_expr [19516,19711]
atom_expr [19867,20062]
===
match
---
trailer [12010,12012]
trailer [12221,12223]
===
match
---
operator: = [8512,8513]
operator: = [8723,8724]
===
match
---
string: 'test_heartbeat_failed_fast' [5047,5075]
string: 'test_heartbeat_failed_fast' [5258,5286]
===
match
---
expr_stmt [5806,5823]
expr_stmt [6017,6034]
===
match
---
name: heartbeat_records [5836,5853]
name: heartbeat_records [6047,6064]
===
match
---
simple_stmt [13842,13877]
simple_stmt [14053,14088]
===
match
---
argument [6884,6903]
argument [7095,7114]
===
match
---
funcdef [2269,2345]
funcdef [2309,2385]
===
match
---
name: ti [4102,4104]
name: ti [4108,4110]
===
match
---
trailer [5940,5957]
trailer [6151,6168]
===
match
---
name: self [2065,2069]
name: self [2105,2109]
===
match
---
atom_expr [19468,19486]
atom_expr [19819,19837]
===
match
---
operator: = [19658,19659]
operator: = [20009,20010]
===
match
---
name: airflow [1216,1223]
name: airflow [1256,1263]
===
match
---
operator: , [6944,6945]
operator: , [7155,7156]
===
match
---
name: failure_callback_called [20362,20385]
name: failure_callback_called [20767,20790]
===
match
---
operator: = [21097,21098]
operator: = [21502,21503]
===
match
---
simple_stmt [4443,4460]
simple_stmt [4611,4628]
===
match
---
simple_stmt [18794,18850]
simple_stmt [19145,19201]
===
match
---
simple_stmt [21132,21190]
simple_stmt [21537,21595]
===
match
---
operator: == [20445,20447]
operator: == [20850,20852]
===
match
---
simple_stmt [1089,1158]
simple_stmt [1129,1198]
===
match
---
name: DEFAULT_DATE [12124,12136]
name: DEFAULT_DATE [12335,12347]
===
match
---
operator: = [9911,9912]
operator: = [10122,10123]
===
match
---
name: default_args [16591,16603]
name: default_args [16802,16814]
===
match
---
atom_expr [20120,20140]
atom_expr [20471,20491]
===
match
---
name: dag [9401,9404]
name: dag [9612,9615]
===
match
---
name: execution_date [5354,5368]
name: execution_date [5565,5579]
===
match
---
name: pid [8437,8440]
name: pid [8648,8651]
===
match
---
name: ti_run [8575,8581]
name: ti_run [8786,8792]
===
match
---
return_stmt [9969,9995]
return_stmt [10180,10206]
===
match
---
name: airflow [1447,1454]
name: airflow [1487,1494]
===
match
---
name: _ [7309,7310]
name: _ [7520,7521]
===
match
---
comparison [20412,20449]
comparison [20817,20854]
===
match
---
operator: = [21045,21046]
operator: = [21450,21451]
===
match
---
name: ti [7030,7032]
name: ti [7241,7243]
===
match
---
name: state [21172,21177]
name: state [21577,21582]
===
match
---
name: ti [7159,7161]
name: ti [7370,7372]
===
match
---
name: is_alive [7639,7647]
name: is_alive [7850,7858]
===
match
---
name: SUCCESS [8157,8164]
name: SUCCESS [8368,8375]
===
match
---
name: on_failure_callback [14312,14331]
name: on_failure_callback [14523,14542]
===
match
---
expr_stmt [7777,7879]
expr_stmt [7988,8090]
===
match
---
trailer [19975,19982]
trailer [20326,20333]
===
match
---
argument [9432,9445]
argument [9643,9656]
===
match
---
number: 1 [16290,16291]
number: 1 [16501,16502]
===
match
---
operator: = [2955,2956]
operator: = [2995,2996]
===
match
---
name: TaskInstance [8514,8526]
name: TaskInstance [8725,8737]
===
match
---
string: "test" [2822,2828]
string: "test" [2862,2868]
===
match
---
name: State [3986,3991]
name: State [3992,3997]
===
match
---
argument [9125,9151]
argument [9336,9362]
===
match
---
simple_stmt [17191,17387]
simple_stmt [17402,17598]
===
match
---
parameters [6410,6416]
parameters [6621,6627]
===
match
---
name: SUCCESS [7519,7526]
name: SUCCESS [7730,7737]
===
match
---
atom_expr [6111,6135]
atom_expr [6322,6346]
===
match
---
simple_stmt [864,876]
simple_stmt [864,876]
===
match
---
name: DEFAULT_DATE [17334,17346]
name: DEFAULT_DATE [17545,17557]
===
match
---
name: process [18189,18196]
name: process [18400,18407]
===
match
---
operator: = [14126,14127]
operator: = [14337,14338]
===
match
---
simple_stmt [789,812]
simple_stmt [789,812]
===
match
---
number: 0 [9993,9994]
number: 0 [10204,10205]
===
match
---
name: run_id [14491,14497]
name: run_id [14702,14708]
===
match
---
operator: == [11640,11642]
operator: == [11851,11853]
===
match
---
name: refresh_from_db [7435,7450]
name: refresh_from_db [7646,7661]
===
match
---
name: executor [21386,21394]
name: executor [21791,21799]
===
match
---
name: shared_mem_lock [18714,18729]
name: shared_mem_lock [19065,19080]
===
match
---
name: object [8700,8706]
name: object [8911,8917]
===
match
---
operator: = [19433,19434]
operator: = [19784,19785]
===
match
---
fstring_string: _test_number_of_queries [20981,21004]
fstring_string: _test_number_of_queries [21386,21409]
===
match
---
simple_stmt [20535,20541]
simple_stmt [20940,20946]
===
match
---
trailer [4524,4537]
trailer [4724,4736]
===
match
---
atom_expr [6778,6796]
atom_expr [6989,7007]
===
match
---
operator: == [13187,13189]
operator: == [13398,13400]
===
match
---
suite [16365,16519]
suite [16576,16730]
===
match
---
name: tests [1731,1736]
name: tests [1771,1776]
===
match
---
name: DEFAULT_DATE [9544,9556]
name: DEFAULT_DATE [9755,9767]
===
match
---
argument [6917,6944]
argument [7128,7155]
===
match
---
operator: , [6903,6904]
operator: , [7114,7115]
===
match
---
name: dagbag [5148,5154]
name: dagbag [5359,5365]
===
match
---
name: raises [4179,4185]
name: raises [4340,4346]
===
match
---
name: os [1965,1967]
name: os [2005,2007]
===
match
---
operator: = [10016,10017]
operator: = [10227,10228]
===
match
---
argument [14702,14711]
argument [14913,14922]
===
match
---
name: DEFAULT_DATE [17297,17309]
name: DEFAULT_DATE [17508,17520]
===
match
---
operator: , [20711,20712]
operator: , [21116,21117]
===
match
---
operator: = [12794,12795]
operator: = [13005,13006]
===
match
---
atom_expr [18801,18826]
atom_expr [19152,19177]
===
match
---
name: self [7762,7766]
name: self [7973,7977]
===
match
---
trailer [7548,7552]
trailer [7759,7763]
===
match
---
simple_stmt [20217,20233]
simple_stmt [20591,20607]
===
match
---
name: run [7239,7242]
name: run [7450,7453]
===
match
---
name: TEST_DAG_FOLDER [6608,6623]
name: TEST_DAG_FOLDER [6819,6834]
===
match
---
funcdef [18666,18850]
funcdef [19017,19201]
===
match
---
name: task [7053,7057]
name: task [7264,7268]
===
match
---
operator: , [1939,1940]
operator: , [1979,1980]
===
match
---
operator: , [3883,3884]
operator: , [3889,3890]
===
match
---
name: commit [5695,5701]
name: commit [5906,5912]
===
match
---
trailer [17260,17268]
trailer [17471,17479]
===
match
---
name: executor [8650,8658]
name: executor [8861,8869]
===
match
---
name: start [20068,20073]
name: start [20419,20424]
===
match
---
atom_expr [16534,16624]
atom_expr [16745,16835]
===
match
---
name: on_failure_callback [12293,12312]
name: on_failure_callback [12504,12523]
===
match
---
argument [10085,10102]
argument [10296,10313]
===
match
---
name: stop [2207,2211]
name: stop [2247,2251]
===
match
---
string: 'test_mark_failure' [12092,12111]
string: 'test_mark_failure' [12303,12322]
===
match
---
name: ti [14750,14752]
name: ti [14961,14963]
===
match
---
name: target [7227,7233]
name: target [7438,7444]
===
match
---
name: test_number_of_queries_single_loop [20819,20853]
name: test_number_of_queries_single_loop [21224,21258]
===
match
---
name: all [3234,3237]
name: all [3274,3277]
===
match
---
name: clear [17175,17180]
name: clear [17386,17391]
===
match
---
with_stmt [11569,11824]
with_stmt [11780,12035]
===
match
---
number: 30 [12853,12855]
number: 30 [13064,13066]
===
match
---
simple_stmt [10218,10264]
simple_stmt [10429,10475]
===
match
---
expr_stmt [19458,19486]
expr_stmt [19809,19837]
===
match
---
operator: , [5010,5011]
operator: , [5221,5222]
===
match
---
expr_stmt [8397,8425]
expr_stmt [8608,8636]
===
match
---
name: DEFAULT_DATE [12535,12547]
name: DEFAULT_DATE [12746,12758]
===
match
---
expr_stmt [17490,17580]
expr_stmt [17701,17791]
===
match
---
trailer [20067,20073]
trailer [20418,20424]
===
match
---
operator: , [12326,12327]
operator: , [12537,12538]
===
match
---
operator: = [14331,14332]
operator: = [14542,14543]
===
match
---
with_stmt [4550,4668]
with_stmt [4761,4879]
===
match
---
atom_expr [20545,20560]
atom_expr [20950,20965]
===
match
---
parameters [9080,9086]
parameters [9291,9297]
===
match
---
name: StandardTaskRunner [8707,8725]
name: StandardTaskRunner [8918,8936]
===
match
---
trailer [8872,8911]
trailer [9083,9122]
===
match
---
name: airflow [1251,1258]
name: airflow [1291,1298]
===
match
---
simple_stmt [19815,19906]
simple_stmt [20166,20257]
===
match
---
atom_expr [20168,20181]
atom_expr [20519,20532]
===
match
---
name: process [7631,7638]
name: process [7842,7849]
===
match
---
argument [12197,12228]
argument [12408,12439]
===
match
---
name: dag_id [18869,18875]
name: dag_id [19220,19226]
===
match
---
simple_stmt [21199,21257]
simple_stmt [21604,21662]
===
match
---
name: task [12663,12667]
name: task [12874,12878]
===
match
---
trailer [10027,10029]
trailer [10238,10240]
===
match
---
import_from [1684,1725]
import_from [1724,1765]
===
match
---
name: start_date [12565,12575]
name: start_date [12776,12786]
===
match
---
name: RUNNING [4345,4352]
name: RUNNING [4513,4520]
===
match
---
operator: = [6931,6932]
operator: = [7142,7143]
===
match
---
operator: , [5510,5511]
operator: , [5721,5722]
===
match
---
comparison [3281,3312]
comparison [3321,3352]
===
match
---
name: clear [9385,9390]
name: clear [9596,9601]
===
match
---
name: state [20159,20164]
name: state [20510,20515]
===
match
---
simple_stmt [13028,13049]
simple_stmt [13239,13260]
===
match
---
simple_stmt [8364,8389]
simple_stmt [8575,8600]
===
match
---
name: test_localtaskjob_essential_attr [2354,2386]
name: test_localtaskjob_essential_attr [2394,2426]
===
match
---
atom_expr [12165,12341]
atom_expr [12376,12552]
===
match
---
string: 'test_mark_success' [16499,16518]
string: 'test_mark_success' [16710,16729]
===
match
---
name: sleep [11842,11847]
name: sleep [12053,12058]
===
match
---
trailer [4424,4430]
trailer [4592,4598]
===
match
---
name: task_id [14225,14232]
name: task_id [14436,14443]
===
match
---
name: self [9081,9085]
name: self [9292,9296]
===
match
---
string: 'test_mark_success' [16545,16564]
string: 'test_mark_success' [16756,16775]
===
match
---
atom_expr [20469,20487]
atom_expr [20874,20892]
===
match
---
name: task_function [19353,19366]
name: task_function [19704,19717]
===
match
---
string: 'test_localtaskjob_essential_attr' [2580,2614]
string: 'test_localtaskjob_essential_attr' [2620,2654]
===
match
---
simple_stmt [1845,1901]
simple_stmt [1885,1941]
===
match
---
arglist [6059,6084]
arglist [6270,6295]
===
match
---
name: Session [9362,9369]
name: Session [9573,9580]
===
match
---
simple_stmt [7276,7297]
simple_stmt [7487,7508]
===
match
---
name: include_examples [4988,5004]
name: include_examples [5199,5215]
===
match
---
trailer [17709,17726]
trailer [17920,17937]
===
match
---
name: ti [19849,19851]
name: ti [20200,20202]
===
match
---
atom_expr [14528,14541]
atom_expr [14739,14752]
===
match
---
comparison [20248,20273]
comparison [20622,20647]
===
match
---
operator: , [12547,12548]
operator: , [12758,12759]
===
match
---
name: failure_callback_called [15841,15864]
name: failure_callback_called [16052,16075]
===
match
---
atom_expr [6053,6085]
atom_expr [6264,6296]
===
match
---
number: 2016 [1935,1939]
number: 2016 [1975,1979]
===
match
---
operator: , [9187,9188]
operator: , [9398,9399]
===
match
---
name: start_date [3831,3841]
name: start_date [3837,3847]
===
match
---
name: ti [21382,21384]
name: ti [21787,21789]
===
match
---
trailer [10377,10388]
trailer [10588,10599]
===
match
---
name: StandardTaskRunner [17608,17626]
name: StandardTaskRunner [17819,17837]
===
match
---
expr_stmt [2779,2913]
expr_stmt [2819,2953]
===
match
---
trailer [3910,3928]
trailer [3916,3934]
===
match
---
name: ti_run [8505,8511]
name: ti_run [8716,8722]
===
match
---
simple_stmt [5483,5541]
simple_stmt [5694,5752]
===
match
---
atom_expr [17608,17632]
atom_expr [17819,17843]
===
match
---
name: callback_count_lock [13719,13738]
name: callback_count_lock [13930,13949]
===
match
---
arglist [12197,12327]
arglist [12408,12538]
===
match
---
argument [20957,21005]
argument [21362,21410]
===
match
---
operator: , [10074,10075]
operator: , [10285,10286]
===
match
---
atom_expr [18747,18776]
atom_expr [19098,19127]
===
match
---
name: create_dagrun [9405,9418]
name: create_dagrun [9616,9629]
===
match
---
name: hostname [4011,4019]
name: hostname [4017,4025]
===
match
---
name: ti [17524,17526]
name: ti [17735,17737]
===
match
---
number: 0 [7320,7321]
number: 0 [7531,7532]
===
match
---
trailer [21121,21123]
trailer [21526,21528]
===
match
---
name: session [14645,14652]
name: session [14856,14863]
===
match
---
name: dag_id [20957,20963]
name: dag_id [21362,21368]
===
match
---
name: terminating [15457,15468]
name: terminating [15668,15679]
===
match
---
operator: , [20101,20102]
operator: , [20452,20453]
===
match
---
operator: = [21353,21354]
operator: = [21758,21759]
===
match
---
trailer [18819,18826]
trailer [19170,19177]
===
match
---
simple_stmt [20322,20347]
simple_stmt [20727,20752]
===
match
---
expr_stmt [7954,8014]
expr_stmt [8165,8225]
===
match
---
trailer [7319,7326]
trailer [7530,7537]
===
match
---
name: State [11744,11749]
name: State [11955,11960]
===
match
---
name: DEFAULT_DATE [12689,12701]
name: DEFAULT_DATE [12900,12912]
===
match
---
simple_stmt [15732,15753]
simple_stmt [15943,15964]
===
match
---
operator: = [9181,9182]
operator: = [9392,9393]
===
match
---
dotted_name [1292,1319]
dotted_name [1332,1359]
===
match
---
name: pytest [20491,20497]
name: pytest [20896,20902]
===
match
---
trailer [15720,15722]
trailer [15931,15933]
===
match
---
fstring_end: ' [21004,21005]
fstring_end: ' [21409,21410]
===
match
---
name: state [17249,17254]
name: state [17460,17465]
===
match
---
trailer [1967,1975]
trailer [2007,2015]
===
match
---
name: failure_callback_called [18747,18770]
name: failure_callback_called [19098,19121]
===
match
---
name: Session [17152,17159]
name: Session [17363,17370]
===
match
---
name: dagbag [7894,7900]
name: dagbag [8105,8111]
===
match
---
simple_stmt [2329,2345]
simple_stmt [2369,2385]
===
match
---
name: task [17413,17417]
name: task [17624,17628]
===
match
---
number: 1 [4318,4319]
number: 1 [4486,4487]
===
match
---
name: op1 [2956,2959]
name: op1 [2996,2999]
===
match
---
simple_stmt [4361,4390]
simple_stmt [4529,4558]
===
match
---
param [13363,13380]
param [13574,13591]
===
match
---
simple_stmt [1554,1597]
simple_stmt [1594,1637]
===
match
---
name: check_result_1 [3238,3252]
name: check_result_1 [3278,3292]
===
match
---
operator: @ [20583,20584]
operator: @ [20988,20989]
===
match
---
assert_stmt [8920,8938]
assert_stmt [9131,9149]
===
match
---
name: value [18771,18776]
name: value [19122,19127]
===
match
---
name: dag_id [11417,11423]
name: dag_id [11628,11634]
===
match
---
term [20713,20723]
term [21118,21128]
===
match
---
name: return_value [4303,4315]
name: task_runner [4460,4471]
===
match
---
name: StandardTaskRunner [1500,1518]
name: StandardTaskRunner [1540,1558]
===
match
---
dotted_name [1395,1419]
dotted_name [1435,1459]
===
match
---
name: uuid [871,875]
name: uuid [871,875]
===
match
---
suite [11274,11525]
suite [11485,11736]
===
match
---
atom_expr [7203,7243]
atom_expr [7414,7454]
===
match
---
trailer [8298,8316]
trailer [8509,8527]
===
match
---
name: models [1224,1230]
name: models [1264,1270]
===
match
---
expr_stmt [16301,16325]
expr_stmt [16512,16536]
===
match
---
name: PythonOperator [16939,16953]
name: PythonOperator [17150,17164]
===
match
---
name: task [21222,21226]
name: task [21627,21631]
===
match
---
argument [5354,5381]
argument [5565,5592]
===
match
---
operator: = [8641,8642]
operator: = [8852,8853]
===
match
---
param [18983,18985]
param [19334,19336]
===
match
---
trailer [20122,20138]
trailer [20473,20489]
===
match
---
name: assert_not_called [8818,8835]
name: assert_not_called [9029,9046]
===
match
---
with_stmt [11970,12067]
with_stmt [12181,12278]
===
match
---
simple_stmt [12351,12363]
simple_stmt [12562,12574]
===
match
---
name: session [8256,8263]
name: session [8467,8474]
===
match
---
operator: , [14838,14839]
operator: , [15049,15050]
===
match
---
atom_expr [21132,21189]
atom_expr [21537,21594]
===
match
---
trailer [2566,2683]
trailer [2606,2723]
===
match
---
atom_expr [3908,3966]
atom_expr [3914,3972]
===
match
---
operator: = [9351,9352]
operator: = [9562,9563]
===
match
---
name: ti [12645,12647]
name: ti [12856,12858]
===
match
---
atom_expr [9760,9780]
atom_expr [9971,9991]
===
match
---
name: commit [8487,8493]
name: commit [8698,8704]
===
match
---
simple_stmt [17171,17183]
simple_stmt [17382,17394]
===
match
---
name: dags [9220,9224]
name: dags [9431,9435]
===
match
---
operator: = [5721,5722]
operator: = [5932,5933]
===
match
---
simple_stmt [20001,20052]
simple_stmt [20352,20403]
===
match
---
operator: = [18907,18908]
operator: = [19258,19259]
===
match
---
name: task [6730,6734]
name: task [6941,6945]
===
match
---
trailer [21407,21409]
trailer [21812,21814]
===
match
---
name: task_id [2735,2742]
name: task_id [2775,2782]
===
match
---
atom_expr [6806,6817]
atom_expr [7017,7028]
===
match
---
param [15403,15409]
param [15614,15620]
===
match
---
atom_expr [8806,8837]
atom_expr [9017,9048]
===
match
---
atom [6259,6274]
atom [6470,6485]
===
match
---
testlist_comp [9914,9921]
testlist_comp [10125,10132]
===
match
---
operator: == [18827,18829]
operator: == [19178,19180]
===
match
---
operator: = [7511,7512]
operator: = [7722,7723]
===
match
---
name: create_session [14415,14429]
name: create_session [14626,14640]
===
match
---
argument [3950,3965]
argument [3956,3971]
===
match
---
name: tests [1789,1794]
name: tests [1829,1834]
===
match
---
decorated [20490,20581]
decorated [20895,20986]
===
match
---
argument [17249,17268]
argument [17460,17479]
===
match
---
name: time_start [10005,10015]
name: time_start [10216,10226]
===
match
---
trailer [8423,8425]
trailer [8634,8636]
===
match
---
name: ti [7549,7551]
name: ti [7760,7762]
===
match
---
trailer [18049,18054]
trailer [18260,18265]
===
match
---
operator: = [2246,2247]
operator: = [2286,2287]
===
match
---
name: StandardTaskRunner [13275,13293]
name: StandardTaskRunner [13486,13504]
===
match
---
trailer [21469,21471]
trailer [21874,21876]
===
match
---
assert_stmt [7461,7493]
assert_stmt [7672,7704]
===
match
---
name: ti [11552,11554]
name: ti [11763,11765]
===
match
---
name: LocalTaskJob [8615,8627]
name: LocalTaskJob [8826,8838]
===
match
---
trailer [18615,18623]
trailer [18966,18974]
===
match
---
trailer [10324,10335]
trailer [10535,10546]
===
match
---
name: DEFAULT_DATE [17439,17451]
name: DEFAULT_DATE [17650,17662]
===
match
---
name: dag [14110,14113]
name: dag [14321,14324]
===
match
---
name: ti [7276,7278]
name: ti [7487,7489]
===
match
---
name: return_value [10085,10097]
name: return_value [10296,10308]
===
match
---
argument [17055,17091]
argument [17266,17302]
===
match
---
expr_stmt [19263,19448]
expr_stmt [19614,19799]
===
match
---
funcdef [6381,7720]
funcdef [6592,7931]
===
match
---
expr_stmt [12645,12702]
expr_stmt [12856,12913]
===
match
---
simple_stmt [3975,4000]
simple_stmt [3981,4006]
===
match
---
trailer [2206,2211]
trailer [2246,2251]
===
match
---
param [20882,20894]
param [21287,21299]
===
match
---
expr_stmt [8291,8355]
expr_stmt [8502,8566]
===
match
---
name: state [12483,12488]
name: state [12694,12699]
===
match
---
operator: = [5854,5855]
operator: = [6065,6066]
===
match
---
name: state [7346,7351]
name: state [7557,7562]
===
match
---
operator: , [17776,17777]
operator: , [17987,17988]
===
match
---
name: check_failure [12313,12326]
name: check_failure [12524,12537]
===
match
---
operator: = [8441,8442]
operator: = [8652,8653]
===
match
---
simple_stmt [8847,8912]
simple_stmt [9058,9123]
===
match
---
simple_stmt [15712,15723]
simple_stmt [15923,15934]
===
match
---
string: 'test_localtaskjob_double_trigger_task' [9293,9332]
string: 'test_localtaskjob_double_trigger_task' [9504,9543]
===
match
---
expr_stmt [13842,13876]
expr_stmt [14053,14087]
===
match
---
simple_stmt [9096,9199]
simple_stmt [9307,9410]
===
match
---
trailer [17593,17605]
trailer [17804,17816]
===
match
---
name: ti [11787,11789]
name: ti [11998,12000]
===
match
---
for_stmt [6044,6347]
for_stmt [6255,6558]
===
match
---
trailer [20289,20313]
trailer [20697,20718]
===
match
---
trailer [11814,11821]
trailer [12025,12032]
===
match
---
trailer [13127,13133]
trailer [13338,13344]
===
match
---
simple_stmt [15938,16068]
simple_stmt [16149,16279]
===
match
---
number: 1 [13875,13876]
number: 1 [14086,14087]
===
match
---
name: LocalTaskJob [5723,5735]
name: LocalTaskJob [5934,5946]
===
match
---
number: 1 [8937,8938]
number: 1 [9148,9149]
===
match
---
name: mark [20591,20595]
name: mark [20996,21000]
===
match
---
operator: , [3293,3294]
operator: , [3333,3334]
===
match
---
name: state [8957,8962]
name: state [9168,9173]
===
match
---
argument [7806,7832]
argument [8017,8043]
===
match
---
argument [12293,12326]
argument [12504,12537]
===
match
---
argument [8256,8271]
argument [8467,8482]
===
match
---
name: time [10018,10022]
name: time [10229,10233]
===
match
---
name: session [12606,12613]
name: session [12817,12824]
===
match
---
name: executor [5754,5762]
name: executor [5965,5973]
===
match
---
string: "hostname" [3132,3142]
string: "hostname" [3172,3182]
===
match
---
atom_expr [20094,20106]
atom_expr [20445,20457]
===
match
---
simple_stmt [7954,8015]
simple_stmt [8165,8226]
===
match
---
simple_stmt [18581,18624]
simple_stmt [18932,18975]
===
match
---
argument [9628,9637]
argument [9839,9848]
===
match
---
name: process [20469,20476]
name: process [20874,20881]
===
match
---
import_from [1089,1157]
import_from [1129,1197]
===
match
---
name: mock [956,960]
name: mock [956,960]
===
match
---
name: get_task [5194,5202]
name: get_task [5405,5413]
===
match
---
with_item [12081,12144]
with_item [12292,12355]
===
match
---
expr_stmt [17133,17161]
expr_stmt [17344,17372]
===
match
---
trailer [7218,7226]
trailer [7429,7437]
===
match
---
name: mock_pid [4516,4524]
name: job1 [4720,4724]
===
match
---
trailer [10231,10243]
trailer [10442,10454]
===
match
---
trailer [17925,17931]
trailer [18136,18142]
===
match
---
trailer [9292,9333]
trailer [9503,9544]
===
match
---
operator: , [3104,3105]
operator: , [3144,3145]
===
match
---
dotted_name [1651,1670]
dotted_name [1691,1710]
===
match
---
simple_stmt [19516,19712]
simple_stmt [19867,20063]
===
match
---
name: job1 [13008,13012]
name: job1 [13219,13223]
===
match
---
simple_stmt [8434,8445]
simple_stmt [8645,8656]
===
match
---
operator: = [7073,7074]
operator: = [7284,7285]
===
match
---
suite [20107,20233]
suite [20458,20607]
===
match
---
name: execution_date [17424,17438]
name: execution_date [17635,17649]
===
match
---
trailer [13991,14004]
trailer [14202,14215]
===
match
---
trailer [9992,9995]
trailer [10203,10206]
===
match
---
name: dag [5225,5228]
name: dag [5436,5439]
===
match
---
trailer [2959,2967]
trailer [2999,3007]
===
match
---
name: op1 [2715,2718]
name: op1 [2755,2758]
===
match
---
trailer [8104,8282]
trailer [8315,8493]
===
match
---
atom_expr [3763,3776]
atom_expr [3769,3782]
===
match
---
name: test_failure_callback_only_called_once [13318,13356]
name: test_failure_callback_only_called_once [13529,13567]
===
match
---
assert_stmt [20405,20449]
assert_stmt [20810,20854]
===
match
---
atom_expr [17255,17268]
atom_expr [17466,17479]
===
match
---
argument [14713,14740]
argument [14924,14951]
===
match
---
name: dag [3499,3502]
name: dag [3505,3508]
===
match
---
expr_stmt [12030,12066]
expr_stmt [12241,12277]
===
match
---
simple_stmt [10005,10030]
simple_stmt [10216,10241]
===
match
---
name: mock_method [8806,8817]
name: mock_method [9017,9028]
===
match
---
trailer [8929,8933]
trailer [9140,9144]
===
match
---
simple_stmt [10402,10425]
simple_stmt [10613,10636]
===
match
---
name: clear [14394,14399]
name: clear [14605,14610]
===
match
---
name: self [2282,2286]
name: self [2322,2326]
===
match
---
trailer [4473,4492]
trailer [4677,4696]
===
match
---
name: MockExecutor [5763,5775]
name: MockExecutor [5974,5986]
===
match
---
atom_expr [7711,7719]
atom_expr [7922,7930]
===
match
---
string: 'op1' [2743,2748]
string: 'op1' [2783,2788]
===
match
---
for_stmt [20085,20233]
for_stmt [20436,20607]
===
match
---
atom_expr [8659,8679]
atom_expr [8870,8890]
===
match
---
name: State [20260,20265]
name: State [20634,20639]
===
match
---
name: dag [9381,9384]
name: dag [9592,9595]
===
match
---
expr_stmt [17957,17981]
expr_stmt [18168,18192]
===
match
---
argument [19574,19593]
argument [19925,19944]
===
match
---
argument [6637,6659]
argument [6848,6870]
===
match
---
atom_expr [5937,5957]
atom_expr [6148,6168]
===
match
---
atom_expr [12810,12830]
atom_expr [13021,13041]
===
match
---
arglist [8873,8910]
arglist [9084,9121]
===
match
---
name: job [21349,21352]
name: job [21754,21757]
===
match
---
operator: = [3957,3958]
operator: = [3963,3964]
===
match
---
operator: = [3762,3763]
operator: = [3768,3769]
===
match
---
trailer [20558,20560]
trailer [20963,20965]
===
match
---
assert_stmt [11459,11524]
assert_stmt [11670,11735]
===
match
---
operator: = [12204,12205]
operator: = [12415,12416]
===
match
---
argument [14818,14838]
argument [15029,15049]
===
match
---
name: task [8532,8536]
name: task [8743,8747]
===
match
---
name: start_date [14604,14614]
name: start_date [14815,14825]
===
match
---
name: dr [8296,8298]
name: dr [8507,8509]
===
match
---
operator: = [7784,7785]
operator: = [7995,7996]
===
match
---
atom_expr [16279,16292]
atom_expr [16490,16503]
===
match
---
name: shared_mem_lock [16301,16316]
name: shared_mem_lock [16512,16527]
===
match
---
atom_expr [3281,3300]
atom_expr [3321,3340]
===
match
---
argument [5512,5539]
argument [5723,5750]
===
match
---
simple_stmt [11668,11717]
simple_stmt [11879,11928]
===
match
---
simple_stmt [2128,2175]
simple_stmt [2168,2215]
===
match
---
trailer [5588,5594]
trailer [5799,5805]
===
match
---
trailer [7345,7351]
trailer [7556,7562]
===
match
---
name: clear_db_runs [2329,2342]
name: clear_db_runs [2369,2382]
===
match
---
number: 1 [18168,18169]
number: 1 [18379,18380]
===
match
---
dotted_name [1163,1190]
dotted_name [1203,1230]
===
match
---
name: task [19263,19267]
name: task [19614,19618]
===
match
---
operator: , [2849,2850]
operator: , [2889,2890]
===
match
---
name: get [7906,7909]
name: get [8117,8120]
===
match
---
operator: , [3183,3184]
operator: , [3223,3224]
===
match
---
operator: = [21325,21326]
operator: = [21730,21731]
===
match
---
comparison [11626,11651]
comparison [11837,11862]
===
match
---
operator: = [21017,21018]
operator: = [21422,21423]
===
match
---
trailer [16284,16292]
trailer [16495,16503]
===
match
---
name: run_id [21150,21156]
name: run_id [21555,21561]
===
match
---
operator: = [4020,4021]
operator: = [4026,4027]
===
match
---
dotted_name [6353,6376]
dotted_name [6564,6587]
===
match
---
trailer [10516,10524]
trailer [10727,10735]
===
match
---
operator: , [19416,19417]
operator: , [19767,19768]
===
match
---
simple_stmt [16528,16625]
simple_stmt [16739,16836]
===
match
---
atom_expr [4845,4855]
atom_expr [5056,5066]
===
match
---
operator: { [18935,18936]
operator: { [19286,19287]
===
match
---
name: call_count [10466,10476]
name: call_count [10677,10687]
===
match
---
operator: = [10097,10098]
operator: = [10308,10309]
===
match
---
expr_stmt [2978,3068]
expr_stmt [3018,3108]
===
match
---
simple_stmt [836,848]
simple_stmt [836,848]
===
match
---
name: dummy [1363,1368]
name: dummy [1403,1408]
===
match
---
name: operators [1403,1412]
name: operators [1443,1452]
===
match
---
simple_stmt [16202,16242]
simple_stmt [16413,16453]
===
match
---
name: patch [8694,8699]
name: patch [8905,8910]
===
match
---
name: context [16470,16477]
name: context [16681,16688]
===
match
---
name: context [11398,11405]
name: context [11609,11616]
===
match
---
operator: = [17254,17255]
operator: = [17465,17466]
===
match
---
argument [17424,17451]
argument [17635,17662]
===
match
---
atom_expr [8062,8073]
atom_expr [8273,8284]
===
match
---
name: ti [11643,11645]
name: ti [11854,11856]
===
match
---
trailer [17577,17579]
trailer [17788,17790]
===
match
---
operator: , [8648,8649]
operator: , [8859,8860]
===
match
---
atom_expr [17497,17580]
atom_expr [17708,17791]
===
match
---
trailer [2187,2198]
trailer [2227,2238]
===
match
---
operator: = [19621,19622]
operator: = [19972,19973]
===
match
---
name: timezone [1917,1925]
name: timezone [1957,1965]
===
match
---
trailer [17902,17907]
trailer [18113,18118]
===
match
---
name: create_dagrun [14460,14473]
name: create_dagrun [14671,14684]
===
match
---
expr_stmt [19720,19777]
expr_stmt [20071,20128]
===
match
---
trailer [5701,5703]
trailer [5912,5914]
===
match
---
operator: = [8658,8659]
operator: = [8869,8870]
===
match
---
name: dr [2927,2929]
name: dr [2967,2969]
===
match
---
simple_stmt [18178,18208]
simple_stmt [18389,18419]
===
match
---
expr_stmt [4911,5025]
expr_stmt [5122,5236]
===
match
---
name: task_instance [19835,19848]
name: task_instance [20186,20199]
===
match
---
name: context [18801,18808]
name: context [19152,19159]
===
match
---
name: refresh_from_db [20123,20138]
name: refresh_from_db [20474,20489]
===
match
---
operator: = [16937,16938]
operator: = [17148,17149]
===
match
---
arglist [3289,3299]
arglist [3329,3339]
===
match
---
param [13778,13785]
param [13989,13996]
===
match
---
name: get_lock [12002,12010]
name: get_lock [12213,12221]
===
match
---
atom_expr [10136,10183]
atom_expr [10347,10394]
===
match
---
name: task_instance [4088,4101]
name: task_instance [4094,4107]
===
match
---
simple_stmt [20199,20205]
simple_stmt [20573,20579]
===
match
---
name: success_callback_called [18082,18105]
name: success_callback_called [18293,18316]
===
match
---
name: run [21466,21469]
name: run [21871,21874]
===
match
---
simple_stmt [2779,2914]
simple_stmt [2819,2954]
===
match
---
operator: = [8263,8264]
operator: = [8474,8475]
===
match
---
name: start [2256,2261]
name: start [2296,2301]
===
match
---
simple_stmt [17133,17162]
simple_stmt [17344,17373]
===
match
---
argument [14120,14155]
argument [14331,14366]
===
match
---
name: mark [6360,6364]
name: mark [6571,6575]
===
match
---
trailer [11645,11651]
trailer [11856,11862]
===
match
---
name: state [8145,8150]
name: state [8356,8361]
===
match
---
atom_expr [7658,7678]
atom_expr [7869,7889]
===
match
---
name: ti [11668,11670]
name: ti [11879,11881]
===
match
---
import_as_names [1050,1088]
import_as_names [1090,1128]
===
match
---
name: DEFAULT_DATE [3842,3854]
name: DEFAULT_DATE [3848,3860]
===
match
---
number: 1 [10339,10340]
number: 1 [10550,10551]
===
match
---
simple_stmt [4469,4507]
simple_stmt [4673,4711]
===
match
---
trailer [5874,5893]
trailer [6085,6104]
===
match
---
atom_expr [20362,20391]
atom_expr [20767,20796]
===
match
---
atom_expr [5190,5211]
atom_expr [5401,5422]
===
match
---
name: task_id [2960,2967]
name: task_id [3000,3007]
===
match
---
name: operators [1353,1362]
name: operators [1393,1402]
===
match
---
expr_stmt [10402,10424]
expr_stmt [10613,10635]
===
match
---
expr_stmt [18581,18623]
expr_stmt [18932,18974]
===
match
---
argument [2948,2967]
argument [2988,3007]
===
match
---
name: executor [19875,19883]
name: executor [20226,20234]
===
match
---
parameters [15402,15419]
parameters [15613,15630]
===
match
---
argument [20035,20050]
argument [20386,20401]
===
match
---
argument [12113,12136]
argument [12324,12347]
===
match
---
name: state [10502,10507]
name: state [10713,10718]
===
match
---
argument [2735,2748]
argument [2775,2788]
===
match
---
expr_stmt [12158,12341]
expr_stmt [12369,12552]
===
match
---
name: job1 [19914,19918]
name: job1 [20265,20269]
===
match
---
trailer [10055,10103]
trailer [10266,10314]
===
match
---
name: self [6411,6415]
name: self [6622,6626]
===
match
---
atom_expr [17892,17907]
atom_expr [18103,18118]
===
match
---
trailer [7518,7526]
trailer [7729,7737]
===
match
---
atom_expr [3699,3894]
atom_expr [3705,3900]
===
match
---
trailer [6794,6796]
trailer [7005,7007]
===
match
---
argument [17012,17041]
argument [17223,17252]
===
match
---
number: 1 [16449,16450]
number: 1 [16660,16661]
===
match
---
import_from [942,973]
import_from [942,973]
===
match
---
name: multiprocessing [20011,20026]
name: multiprocessing [20362,20377]
===
match
---
trailer [14119,14181]
trailer [14330,14392]
===
match
---
operator: - [10770,10771]
operator: - [10981,10982]
===
match
---
simple_stmt [17395,17453]
simple_stmt [17606,17664]
===
match
---
trailer [15502,15514]
trailer [15713,15725]
===
match
---
name: unique_prefix [20905,20918]
name: unique_prefix [21310,21323]
===
match
---
expr_stmt [9273,9333]
expr_stmt [9484,9544]
===
match
---
operator: , [21384,21385]
operator: , [21789,21790]
===
match
---
number: 0 [20100,20101]
number: 0 [20451,20452]
===
match
---
number: 10 [11848,11850]
number: 10 [12059,12061]
===
match
---
with_stmt [18709,18782]
with_stmt [19060,19133]
===
match
---
argument [16967,16998]
argument [17178,17209]
===
match
---
argument [8118,8131]
argument [8329,8342]
===
match
---
atom_expr [3986,3999]
atom_expr [3992,4005]
===
match
---
name: airflow [1524,1531]
name: airflow [1564,1571]
===
match
---
string: 'exception' [11474,11485]
string: 'exception' [11685,11696]
===
match
---
number: 2 [10392,10393]
number: 2 [10603,10604]
===
match
---
suite [12145,12342]
suite [12356,12553]
===
match
---
name: failure_callback_called [13842,13865]
name: failure_callback_called [14053,14076]
===
match
---
name: python_callable [19337,19352]
name: python_callable [19688,19703]
===
match
---
name: job1 [4217,4221]
name: job1 [4378,4382]
===
match
---
atom_expr [11292,11326]
atom_expr [11503,11537]
===
match
---
trailer [20073,20075]
trailer [20424,20426]
===
match
---
name: State [5323,5328]
name: State [5534,5539]
===
match
---
atom_expr [8375,8388]
atom_expr [8586,8599]
===
match
---
name: dag_id [18820,18826]
name: dag_id [19171,19177]
===
match
---
name: task [14707,14711]
name: task [14918,14922]
===
match
---
simple_stmt [20905,20939]
simple_stmt [21310,21344]
===
match
---
expr_stmt [21199,21256]
expr_stmt [21604,21661]
===
match
---
trailer [21115,21121]
trailer [21520,21526]
===
match
---
simple_stmt [8806,8838]
simple_stmt [9017,9049]
===
match
---
string: "test" [3737,3743]
string: "test" [3743,3749]
===
match
---
name: job1 [4068,4072]
name: job1 [4074,4078]
===
match
---
name: refresh_from_db [13031,13046]
name: refresh_from_db [13242,13257]
===
match
---
argument [9639,9666]
argument [9850,9877]
===
match
---
number: 10 [18063,18065]
number: 10 [18274,18276]
===
match
---
trailer [17701,17709]
trailer [17912,17920]
===
match
---
trailer [4087,4158]
trailer [4093,4164]
===
match
---
simple_stmt [2557,2684]
simple_stmt [2597,2724]
===
match
---
name: dr [3694,3696]
name: dr [3700,3702]
===
match
---
atom [9913,9922]
atom [10124,10133]
===
match
---
operator: , [18920,18921]
operator: , [19271,19272]
===
match
---
name: clear_db_runs [2104,2117]
name: clear_db_runs [2144,2157]
===
match
---
name: dag_folder [6597,6607]
name: dag_folder [6808,6818]
===
match
---
name: info [11675,11679]
name: info [11886,11890]
===
match
---
name: create_session [4870,4884]
name: create_session [5081,5095]
===
match
---
expr_stmt [9709,9781]
expr_stmt [9920,9992]
===
match
---
trailer [5162,5170]
trailer [5373,5381]
===
match
---
name: RUNNING [17941,17948]
name: RUNNING [18152,18159]
===
match
---
operator: = [14833,14834]
operator: = [15044,15045]
===
match
---
simple_stmt [1390,1442]
simple_stmt [1430,1482]
===
match
---
operator: , [7321,7322]
operator: , [7532,7533]
===
match
---
trailer [8854,8872]
trailer [9065,9083]
===
match
---
operator: = [21381,21382]
operator: = [21786,21787]
===
match
---
atom_expr [18559,18572]
atom_expr [18910,18923]
===
match
---
name: task_function [18969,18982]
name: task_function [19320,19333]
===
match
---
name: dr [3908,3910]
name: dr [3914,3916]
===
match
---
name: SequentialExecutor [19884,19902]
name: SequentialExecutor [20235,20253]
===
match
---
name: quarantined [6365,6376]
name: quarantined [6576,6587]
===
match
---
trailer [5154,5162]
trailer [5365,5373]
===
match
---
name: DEFAULT_DATE [19622,19634]
name: DEFAULT_DATE [19973,19985]
===
match
---
trailer [4926,5025]
trailer [5137,5236]
===
match
---
testlist_comp [3096,3142]
testlist_comp [3136,3182]
===
match
---
name: State [7513,7518]
name: State [7724,7729]
===
match
---
trailer [5193,5202]
trailer [5404,5413]
===
match
---
operator: = [6683,6684]
operator: = [6894,6895]
===
match
---
trailer [20099,20106]
trailer [20450,20457]
===
match
---
argument [9165,9187]
argument [9376,9398]
===
match
---
trailer [3359,3375]
trailer [3399,3415]
===
match
---
name: kill [20285,20289]
name: kill [20693,20697]
===
match
---
name: dag [14390,14393]
name: dag [14601,14604]
===
match
---
arglist [18616,18622]
arglist [18967,18973]
===
match
---
name: mock_start [10314,10324]
name: mock_start [10525,10535]
===
match
---
parameters [2386,2392]
parameters [2426,2432]
===
match
---
dictorsetmaker [16605,16622]
dictorsetmaker [16816,16833]
===
match
---
name: state [6884,6889]
name: state [7095,7100]
===
match
---
number: 1 [13190,13191]
number: 1 [13401,13402]
===
match
---
operator: = [19723,19724]
operator: = [20074,20075]
===
match
---
simple_stmt [11619,11652]
simple_stmt [11830,11863]
===
match
---
simple_stmt [13008,13019]
simple_stmt [13219,13230]
===
match
---
name: mark [20674,20678]
name: mark [21079,21083]
===
match
---
atom_expr [11224,11237]
atom_expr [11435,11448]
===
match
---
name: ti [17461,17463]
name: ti [17672,17674]
===
match
---
assert_stmt [20458,20487]
assert_stmt [20863,20892]
===
match
---
operator: = [2136,2137]
operator: = [2176,2177]
===
match
---
name: task [14190,14194]
name: task [14401,14405]
===
match
---
atom_expr [6737,6758]
atom_expr [6948,6969]
===
match
---
suite [18987,19254]
suite [19338,19605]
===
match
---
name: TEST_DAG_FOLDER [4955,4970]
name: TEST_DAG_FOLDER [5166,5181]
===
match
---
operator: = [5749,5750]
operator: = [5960,5961]
===
match
---
atom_expr [21462,21471]
atom_expr [21867,21876]
===
match
---
suite [9956,9996]
suite [10167,10207]
===
match
---
name: failure_callback_called [18533,18556]
name: failure_callback_called [18884,18907]
===
match
---
name: time_start [10772,10782]
name: time_start [10983,10993]
===
match
---
simple_stmt [18533,18573]
simple_stmt [18884,18924]
===
match
---
dotted_name [1094,1131]
dotted_name [1134,1171]
===
match
---
with_stmt [12840,13019]
with_stmt [13051,13230]
===
match
---
expr_stmt [2128,2174]
expr_stmt [2168,2214]
===
match
---
name: SequentialExecutor [8659,8677]
name: SequentialExecutor [8870,8888]
===
match
---
argument [7145,7161]
argument [7356,7372]
===
match
---
name: ti_run [9743,9749]
name: ti_run [9954,9960]
===
match
---
with_item [11574,11601]
with_item [11785,11812]
===
match
---
name: ti [3012,3014]
name: ti [3052,3054]
===
match
---
name: ti [13028,13030]
name: ti [13239,13241]
===
match
---
param [16652,16654]
param [16863,16865]
===
match
---
name: settings [17642,17650]
name: settings [17853,17861]
===
match
---
trailer [15785,15792]
trailer [15996,16003]
===
match
---
atom_expr [13104,13133]
atom_expr [13315,13344]
===
match
---
comp_op [3301,3307]
comp_op [3341,3347]
===
match
---
comparison [15768,15792]
comparison [15979,16003]
===
match
---
suite [10118,10394]
suite [10329,10605]
===
match
---
name: asserts [1748,1755]
name: asserts [1788,1795]
===
match
---
simple_stmt [5871,5959]
simple_stmt [6082,6170]
===
match
---
name: StandardTaskRunner [10056,10074]
name: StandardTaskRunner [10267,10285]
===
match
---
name: airflow [1689,1696]
name: airflow [1729,1736]
===
match
---
trailer [16323,16325]
trailer [16534,16536]
===
match
---
operator: @ [13261,13262]
operator: @ [13472,13473]
===
match
---
name: task [7954,7958]
name: task [8165,8169]
===
match
---
operator: , [3743,3744]
operator: , [3749,3750]
===
match
---
parameters [2281,2287]
parameters [2321,2327]
===
match
---
name: failure_callback_called [11147,11170]
name: failure_callback_called [11358,11381]
===
match
---
name: ti [7343,7345]
name: ti [7554,7556]
===
match
---
name: dag [7961,7964]
name: dag [8172,8175]
===
match
---
simple_stmt [11147,11187]
simple_stmt [11358,11398]
===
match
---
name: mock_return_code [15486,15502]
name: mock_return_code [15697,15713]
===
match
---
name: RUNNING [5329,5336]
name: RUNNING [5540,5547]
===
match
---
operator: { [3578,3579]
operator: { [3584,3585]
===
match
---
expr_stmt [21040,21102]
expr_stmt [21445,21507]
===
match
---
name: hasattr [3171,3178]
name: hasattr [3211,3218]
===
match
---
import_from [1554,1596]
import_from [1594,1636]
===
match
---
name: task [16932,16936]
name: task [17143,17147]
===
match
---
name: self [18260,18264]
name: self [3453,3457]
===
match
---
atom_expr [4806,4842]
atom_expr [5017,5053]
===
match
---
arglist [3730,3884]
arglist [3736,3890]
===
match
---
argument [19607,19634]
argument [19958,19985]
===
match
---
with_stmt [8689,8838]
with_stmt [8900,9049]
===
match
---
atom_expr [4469,4506]
atom_expr [4673,4710]
===
match
---
expr_stmt [6730,6758]
expr_stmt [6941,6969]
===
match
---
number: 1 [18115,18116]
number: 1 [18326,18327]
===
match
---
trailer [14211,14380]
trailer [14422,14591]
===
match
---
expr_stmt [14780,14870]
expr_stmt [14991,15081]
===
match
---
name: job [6326,6329]
name: job [6537,6540]
===
match
---
name: task_instance [7145,7158]
name: task_instance [7356,7369]
===
match
---
suite [21449,21472]
suite [21854,21877]
===
match
---
trailer [2261,2263]
trailer [2301,2303]
===
match
---
operator: , [19671,19672]
operator: , [20022,20023]
===
match
---
operator: = [4538,4539]
operator: = [4749,4750]
===
match
---
name: dag [14366,14369]
name: dag [14577,14580]
===
match
---
simple_stmt [975,989]
simple_stmt [975,989]
===
match
---
argument [14522,14541]
argument [14733,14752]
===
match
---
with_item [12376,12403]
with_item [12587,12614]
===
match
---
name: job1 [3289,3293]
name: job1 [3329,3333]
===
match
---
simple_stmt [17874,17880]
simple_stmt [18085,18091]
===
match
---
name: task_terminated_externally [20412,20438]
name: task_terminated_externally [20817,20843]
===
match
---
trailer [4056,4058]
trailer [4062,4064]
===
match
---
string: "blablabla" [4022,4033]
string: "blablabla" [4028,4039]
===
match
---
suite [16656,16923]
suite [16867,17134]
===
match
---
expr_stmt [18533,18572]
expr_stmt [18884,18923]
===
match
---
name: time [10418,10422]
name: time [10629,10633]
===
match
---
name: create_session [12376,12390]
name: create_session [12587,12601]
===
match
---
name: ti [7658,7660]
name: ti [7869,7871]
===
match
---
number: 10 [7608,7610]
number: 10 [7819,7821]
===
match
---
operator: = [9742,9743]
operator: = [9953,9954]
===
match
---
argument [4944,4970]
argument [5155,5181]
===
match
---
name: session [9578,9585]
name: session [9789,9796]
===
match
---
operator: = [9438,9439]
operator: = [9649,9650]
===
match
---
simple_stmt [8947,8980]
simple_stmt [9158,9191]
===
match
---
funcdef [7725,9005]
funcdef [7936,9216]
===
match
---
simple_stmt [1019,1089]
simple_stmt [1059,1129]
===
match
---
assert_stmt [18125,18169]
assert_stmt [18336,18380]
===
match
---
operator: = [19553,19554]
operator: = [19904,19905]
===
match
---
name: heartbeat_callback [4222,4240]
name: heartbeat_callback [4383,4401]
===
match
---
trailer [2198,2212]
trailer [2238,2252]
===
match
---
name: len [6005,6008]
name: len [6216,6219]
===
match
---
name: failure_callback_called [13671,13694]
name: failure_callback_called [13882,13905]
===
match
---
name: task [12158,12162]
name: task [12369,12373]
===
match
---
operator: , [9918,9919]
operator: , [10129,10130]
===
match
---
name: AirflowFailException [1068,1088]
name: AirflowFailException [1108,1128]
===
match
---
name: ti [5483,5485]
name: ti [5694,5696]
===
match
---
operator: , [1066,1067]
operator: , [1106,1107]
===
match
---
operator: , [12275,12276]
operator: , [12486,12487]
===
match
---
number: 1 [5673,5674]
number: 1 [5884,5885]
===
match
---
dotted_name [20667,20690]
dotted_name [21072,21095]
===
match
---
operator: , [21092,21093]
operator: , [21497,21498]
===
match
---
suite [2050,20488]
suite [2090,20893]
===
match
---
trailer [2255,2261]
trailer [2295,2301]
===
match
---
atom_expr [16886,16918]
atom_expr [17097,17129]
===
match
---
simple_stmt [6152,6181]
simple_stmt [6363,6392]
===
match
---
trailer [9728,9781]
trailer [9939,9992]
===
match
---
simple_stmt [19496,19508]
simple_stmt [19847,19859]
===
match
---
decorated [13197,15876]
decorated [13408,16087]
===
match
---
simple_stmt [1726,1784]
simple_stmt [1766,1824]
===
match
---
name: task [5506,5510]
name: task [5717,5721]
===
match
---
atom_expr [7314,7326]
atom_expr [7525,7537]
===
match
---
operator: , [2639,2640]
operator: , [2679,2680]
===
match
---
string: 'return_code' [13295,13308]
string: 'return_code' [13506,13519]
===
match
---
name: task [21040,21044]
name: task [21445,21449]
===
match
---
trailer [8071,8073]
trailer [8282,8284]
===
match
---
decorator [6352,6377]
decorator [6563,6588]
===
match
---
simple_stmt [12158,12342]
simple_stmt [12369,12553]
===
match
---
name: State [5597,5602]
name: State [5808,5813]
===
match
---
name: Lock [16319,16323]
name: Lock [16530,16534]
===
match
---
import_from [990,1018]
import_from [1030,1058]
===
match
---
name: clear_db_jobs [2305,2318]
name: clear_db_jobs [2345,2358]
===
match
---
simple_stmt [16463,16519]
simple_stmt [16674,16730]
===
match
---
param [18260,18264]
param [3453,3457]
===
match
---
argument [18869,18895]
argument [19220,19246]
===
match
---
operator: , [12111,12112]
operator: , [12322,12323]
===
match
---
operator: = [5004,5005]
operator: = [5215,5216]
===
match
---
operator: = [5322,5323]
operator: = [5533,5534]
===
match
---
operator: = [14365,14366]
operator: = [14576,14577]
===
match
---
name: time [10023,10027]
name: time [10234,10238]
===
match
---
simple_stmt [5225,5471]
simple_stmt [5436,5682]
===
match
---
name: abs [6314,6317]
name: abs [6525,6528]
===
match
---
simple_stmt [1340,1390]
simple_stmt [1380,1430]
===
match
---
operator: = [17027,17028]
operator: = [17238,17239]
===
match
---
trailer [20250,20256]
trailer [20624,20630]
===
match
---
operator: = [3168,3169]
operator: = [3208,3209]
===
match
---
trailer [7278,7294]
trailer [7489,7505]
===
match
---
suite [10877,13192]
suite [11088,13403]
===
match
---
name: job1 [7234,7238]
name: job1 [7445,7449]
===
match
---
param [16356,16363]
param [16567,16574]
===
match
---
arglist [17222,17376]
arglist [17433,17587]
===
match
---
name: MockExecutor [1888,1900]
name: MockExecutor [1928,1940]
===
match
---
comparison [10497,10524]
comparison [10708,10735]
===
match
---
trailer [9219,9224]
trailer [9430,9435]
===
match
---
name: task_terminated_externally [16886,16912]
name: task_terminated_externally [17097,17123]
===
match
---
atom_expr [5687,5703]
atom_expr [5898,5914]
===
match
---
string: 'i' [11230,11233]
string: 'i' [11441,11444]
===
match
---
atom_expr [7694,7707]
atom_expr [7905,7918]
===
match
---
atom_expr [14116,14181]
atom_expr [14327,14392]
===
match
---
name: ti [7502,7504]
name: ti [7713,7715]
===
match
---
operator: = [5595,5596]
operator: = [5806,5807]
===
match
---
arglist [14120,14180]
arglist [14331,14391]
===
match
---
simple_stmt [6730,6759]
simple_stmt [6941,6970]
===
match
---
name: dag [12351,12354]
name: dag [12562,12565]
===
match
---
operator: , [17041,17042]
operator: , [17252,17253]
===
match
---
trailer [17412,17452]
trailer [17623,17663]
===
match
---
arglist [18869,18954]
arglist [19220,19305]
===
match
---
expr_stmt [19815,19905]
expr_stmt [20166,20256]
===
match
---
simple_stmt [3078,3144]
simple_stmt [3118,3184]
===
match
---
name: PythonOperator [12165,12179]
name: PythonOperator [12376,12390]
===
match
---
atom_expr [5806,5819]
atom_expr [6017,6030]
===
match
---
trailer [6809,6815]
trailer [7020,7026]
===
match
---
operator: , [5422,5423]
operator: , [5633,5634]
===
match
---
atom_expr [19580,19593]
atom_expr [19931,19944]
===
match
---
name: default_args [3565,3577]
name: default_args [3571,3583]
===
match
---
name: AirflowFailException [14078,14098]
name: AirflowFailException [14289,14309]
===
match
---
name: process [7193,7200]
name: process [7404,7411]
===
match
---
name: DEFAULT_DATE [7074,7086]
name: DEFAULT_DATE [7285,7297]
===
match
---
operator: == [18112,18114]
operator: == [18323,18325]
===
match
---
trailer [2787,2801]
trailer [2827,2841]
===
match
---
operator: , [8725,8726]
operator: , [8936,8937]
===
match
---
simple_stmt [1287,1340]
simple_stmt [1327,1380]
===
match
---
name: SequentialExecutor [9760,9778]
name: SequentialExecutor [9971,9989]
===
match
---
name: timeout [18055,18062]
name: timeout [18266,18273]
===
match
---
argument [7227,7242]
argument [7438,7453]
===
match
---
atom_expr [7234,7242]
atom_expr [7445,7453]
===
match
---
comparison [7694,7719]
comparison [7905,7930]
===
match
---
operator: , [21170,21171]
operator: , [21575,21576]
===
match
---
simple_stmt [13719,13748]
simple_stmt [13930,13959]
===
match
---
trailer [4810,4830]
trailer [5021,5041]
===
match
---
atom_expr [5723,5793]
atom_expr [5934,6004]
===
match
---
name: task_id [8873,8880]
name: task_id [9084,9091]
===
match
---
name: airflow [1651,1658]
name: airflow [1691,1698]
===
match
---
atom_expr [10314,10335]
atom_expr [10525,10546]
===
match
---
atom_expr [13973,14027]
atom_expr [14184,14238]
===
match
---
trailer [4221,4240]
trailer [4382,4401]
===
match
---
atom_expr [6259,6290]
atom_expr [6470,6501]
===
match
---
operator: = [2835,2836]
operator: = [2875,2876]
===
match
---
suite [8770,8838]
suite [8981,9049]
===
match
---
simple_stmt [8989,9005]
simple_stmt [9200,9216]
===
match
---
name: sequential_executor [1112,1131]
name: sequential_executor [1152,1171]
===
match
---
name: test_mark_success_no_kill [6385,6410]
name: test_mark_success_no_kill [6596,6621]
===
match
---
operator: == [10508,10510]
operator: == [10719,10721]
===
match
---
name: Process [20027,20034]
name: Process [20378,20385]
===
match
---
name: dag [8062,8065]
name: dag [8273,8276]
===
match
---
name: SequentialExecutor [3047,3065]
name: SequentialExecutor [3087,3105]
===
match
---
trailer [18868,18955]
trailer [19219,19306]
===
match
---
name: patcher [2248,2255]
name: patcher [2288,2295]
===
match
---
operator: , [20880,20881]
operator: , [21285,21286]
===
match
---
trailer [14701,14741]
trailer [14912,14952]
===
match
---
simple_stmt [3227,3254]
simple_stmt [3267,3294]
===
match
---
atom_expr [6314,6340]
atom_expr [6525,6551]
===
match
---
trailer [13914,13921]
trailer [14125,14132]
===
match
---
operator: == [17932,17934]
operator: == [18143,18145]
===
match
---
operator: , [13293,13294]
operator: , [13504,13505]
===
match
---
operator: = [19868,19869]
operator: = [20219,20220]
===
match
---
atom [3095,3143]
atom [3135,3183]
===
match
---
suite [4898,6347]
suite [5109,6558]
===
match
---
atom_expr [3975,3983]
atom_expr [3981,3989]
===
match
---
trailer [7964,7973]
trailer [8175,8184]
===
match
---
name: ignore_ti_state [7163,7178]
name: ignore_ti_state [7374,7389]
===
match
---
number: 0 [16239,16240]
number: 0 [16450,16451]
===
match
---
arglist [8628,8679]
arglist [8839,8890]
===
match
---
atom_expr [17143,17161]
atom_expr [17354,17372]
===
match
---
name: ti [14684,14686]
name: ti [14895,14897]
===
match
---
trailer [17479,17481]
trailer [17690,17692]
===
match
---
name: return_codes [9898,9910]
name: return_codes [10109,10121]
===
match
---
arglist [2998,3067]
arglist [3038,3107]
===
match
---
trailer [5775,5792]
trailer [5986,6003]
===
match
---
trailer [5983,5985]
trailer [6194,6196]
===
match
---
operator: , [5752,5753]
operator: , [5963,5964]
===
match
---
simple_stmt [8062,8074]
simple_stmt [8273,8285]
===
match
---
argument [5399,5422]
argument [5610,5633]
===
match
---
not_test [7627,7649]
not_test [7838,7860]
===
match
---
expr_stmt [5088,5129]
expr_stmt [5299,5340]
===
match
---
operator: = [2742,2743]
operator: = [2782,2783]
===
match
---
simple_stmt [8397,8426]
simple_stmt [8608,8637]
===
match
---
trailer [20329,20334]
trailer [20734,20739]
===
match
---
trailer [7360,7368]
trailer [7571,7579]
===
match
---
simple_stmt [2221,2264]
simple_stmt [2261,2304]
===
match
---
trailer [7238,7242]
trailer [7449,7453]
===
match
---
dotted_name [13262,13274]
dotted_name [13473,13485]
===
match
---
assert_stmt [11391,11446]
assert_stmt [11602,11657]
===
match
---
name: session [8479,8486]
name: session [8690,8697]
===
match
---
operator: , [8337,8338]
operator: , [8548,8549]
===
match
---
expr_stmt [7193,7243]
expr_stmt [7404,7454]
===
match
---
operator: = [6257,6258]
operator: = [6468,6469]
===
match
---
operator: , [19593,19594]
operator: , [19944,19945]
===
match
---
simple_stmt [1246,1287]
simple_stmt [1286,1327]
===
match
---
name: session [11807,11814]
name: session [12018,12025]
===
match
---
operator: = [8613,8614]
operator: = [8824,8825]
===
match
---
operator: , [14816,14817]
operator: , [15027,15028]
===
match
---
decorated [6352,7720]
decorated [6563,7931]
===
match
---
suite [20182,20205]
suite [20556,20579]
===
match
---
name: DAG [1242,1245]
name: DAG [1282,1285]
===
match
---
name: uuid4 [20930,20935]
name: uuid4 [21335,21340]
===
match
---
simple_stmt [13966,14028]
simple_stmt [14177,14239]
===
match
---
name: LocalTaskJob [17497,17509]
name: LocalTaskJob [17708,17720]
===
match
---
expr_stmt [8608,8680]
expr_stmt [8819,8891]
===
match
---
suite [12857,13019]
suite [13068,13230]
===
match
---
name: sleep [7409,7414]
name: sleep [7620,7625]
===
match
---
name: TestCase [2040,2048]
name: TestCase [2080,2088]
===
match
---
name: pytest [20584,20590]
name: pytest [20989,20995]
===
match
---
operator: @ [6352,6353]
operator: @ [6563,6564]
===
match
---
atom_expr [4600,4625]
atom_expr [4811,4836]
===
match
---
simple_stmt [7687,7720]
simple_stmt [7898,7931]
===
match
---
name: ti [15768,15770]
name: ti [15979,15981]
===
match
---
trailer [7676,7678]
trailer [7887,7889]
===
match
---
operator: , [15408,15409]
operator: , [15619,15620]
===
match
---
simple_stmt [6826,7022]
simple_stmt [7037,7233]
===
match
---
operator: += [18777,18779]
operator: += [19128,19130]
===
match
---
name: PythonOperator [14197,14211]
name: PythonOperator [14408,14422]
===
match
---
operator: = [14167,14168]
operator: = [14378,14379]
===
match
---
arglist [2580,2673]
arglist [2620,2713]
===
match
---
number: 0.2 [20228,20231]
number: 0.2 [20602,20605]
===
match
---
name: get_hostname [1584,1596]
name: get_hostname [1624,1636]
===
match
---
with_stmt [4865,6347]
with_stmt [5076,6558]
===
match
---
trailer [21367,21410]
trailer [21772,21815]
===
match
---
trailer [10048,10055]
trailer [10259,10266]
===
match
---
operator: , [14155,14156]
operator: , [14366,14367]
===
match
---
decorator [9010,9035]
decorator [9221,9246]
===
match
---
operator: ** [15410,15412]
operator: ** [15621,15623]
===
match
---
arglist [7320,7325]
arglist [7531,7536]
===
match
---
name: uuid [20925,20929]
name: uuid [21330,21334]
===
match
---
trailer [6740,6749]
trailer [6951,6960]
===
match
---
name: utils [1567,1572]
name: utils [1607,1612]
===
match
---
name: get [9225,9228]
name: get [9436,9439]
===
match
---
operator: , [12588,12589]
operator: , [12799,12800]
===
match
---
name: RUNNING [17261,17268]
name: RUNNING [17472,17479]
===
match
---
name: patch [2138,2143]
name: patch [2178,2183]
===
match
---
parameters [4703,4709]
parameters [4914,4920]
===
match
---
operator: = [6158,6159]
operator: = [6369,6370]
===
match
---
name: timeout [1703,1710]
name: timeout [1743,1750]
===
match
---
expr_stmt [3078,3143]
expr_stmt [3118,3183]
===
match
---
string: 'test_mark_failure' [18876,18895]
string: 'test_mark_failure' [19227,19246]
===
match
---
arglist [3179,3189]
arglist [3219,3229]
===
match
---
expr_stmt [6152,6180]
expr_stmt [6363,6391]
===
match
---
simple_stmt [990,1019]
simple_stmt [1030,1059]
===
match
---
name: RUNNING [8972,8979]
name: RUNNING [9183,9190]
===
match
---
argument [19298,19323]
argument [19649,19674]
===
match
---
atom_expr [17171,17182]
atom_expr [17382,17393]
===
match
---
simple_stmt [17589,17633]
simple_stmt [17800,17844]
===
match
---
simple_stmt [17676,17727]
simple_stmt [17887,17938]
===
match
---
operator: , [19323,19324]
operator: , [19674,19675]
===
match
---
argument [21368,21384]
argument [21773,21789]
===
match
---
suite [6417,7720]
suite [6628,7931]
===
match
---
name: task_terminated_externally [16250,16276]
name: task_terminated_externally [16461,16487]
===
match
---
trailer [1975,2005]
trailer [2015,2045]
===
match
---
trailer [7905,7909]
trailer [8116,8120]
===
match
---
name: TaskInstance [14689,14701]
name: TaskInstance [14900,14912]
===
match
---
operator: = [7130,7131]
operator: = [7341,7342]
===
match
---
dotted_name [1345,1368]
dotted_name [1385,1408]
===
match
---
operator: == [11424,11426]
operator: == [11635,11637]
===
match
---
return_stmt [15433,15476]
return_stmt [15644,15687]
===
match
---
name: ti [18983,18985]
name: ti [19334,19336]
===
match
---
parameters [14054,14058]
parameters [14265,14269]
===
match
---
operator: , [5381,5382]
operator: , [5592,5593]
===
match
---
operator: , [6659,6660]
operator: , [6870,6871]
===
match
---
trailer [3237,3253]
trailer [3277,3293]
===
match
---
operator: = [19848,19849]
operator: = [20199,20200]
===
match
---
trailer [10445,10465]
trailer [10656,10676]
===
match
---
expr_stmt [5871,5958]
expr_stmt [6082,6169]
===
match
---
name: TaskInstance [7035,7047]
name: TaskInstance [7246,7258]
===
match
---
trailer [1925,1934]
trailer [1965,1974]
===
match
---
name: value [18106,18111]
name: value [18317,18322]
===
match
---
name: ti [7711,7713]
name: ti [7922,7924]
===
match
---
name: run [15717,15720]
name: run [15928,15931]
===
match
---
operator: = [8324,8325]
operator: = [8535,8536]
===
match
---
name: DEFAULT_DATE [14574,14586]
name: DEFAULT_DATE [14785,14797]
===
match
---
sync_comp_for [3313,3339]
sync_comp_for [3353,3379]
===
match
---
name: ti [4361,4363]
name: ti [4529,4531]
===
match
---
trailer [9111,9198]
trailer [9322,9409]
===
match
---
name: time2 [6260,6265]
name: time2 [6471,6476]
===
match
---
simple_stmt [19786,19807]
simple_stmt [20137,20158]
===
match
---
with_stmt [13800,13877]
with_stmt [14011,14088]
===
match
---
trailer [4492,4506]
trailer [4696,4710]
===
match
---
trailer [17194,17208]
trailer [17405,17419]
===
match
---
assert_stmt [18075,18116]
assert_stmt [18286,18327]
===
match
---
operator: = [3031,3032]
operator: = [3071,3072]
===
match
---
operator: = [8531,8532]
operator: = [8742,8743]
===
match
---
import_name [812,821]
import_name [812,821]
===
match
---
name: task [8325,8329]
name: task [8536,8540]
===
match
---
operator: = [3984,3985]
operator: = [3990,3991]
===
match
---
number: 2 [5822,5823]
number: 2 [6033,6034]
===
match
---
atom_expr [12650,12702]
atom_expr [12861,12913]
===
match
---
operator: , [9445,9446]
operator: , [9656,9657]
===
match
---
operator: = [17558,17559]
operator: = [17769,17770]
===
match
---
operator: = [14284,14285]
operator: = [14495,14496]
===
match
---
atom_expr [3937,3948]
atom_expr [3943,3954]
===
match
---
trailer [6843,7021]
trailer [7054,7232]
===
match
---
string: "test" [12459,12465]
string: "test" [12670,12676]
===
match
---
parameters [9953,9955]
parameters [10164,10166]
===
match
---
funcdef [3405,4668]
funcdef [3421,4879]
===
match
---
atom_expr [18132,18164]
atom_expr [18343,18375]
===
match
---
atom_expr [10785,10799]
atom_expr [10996,11010]
===
match
---
with_stmt [12371,12637]
with_stmt [12582,12848]
===
match
---
operator: = [10244,10245]
operator: = [10455,10456]
===
match
---
name: side_effect [10232,10243]
name: side_effect [10443,10454]
===
match
---
argument [2616,2639]
argument [2656,2679]
===
match
---
trailer [13046,13048]
trailer [13257,13259]
===
match
---
trailer [6317,6340]
trailer [6528,6551]
===
match
---
trailer [21286,21299]
trailer [21691,21704]
===
match
---
argument [19648,19671]
argument [19999,20022]
===
match
---
operator: , [12502,12503]
operator: , [12713,12714]
===
match
---
atom_expr [7035,7087]
atom_expr [7246,7298]
===
match
---
argument [16591,16623]
argument [16802,16834]
===
match
---
operator: == [13922,13924]
operator: == [14133,14135]
===
match
---
operator: , [13706,13707]
operator: , [13917,13918]
===
match
---
operator: , [8242,8243]
operator: , [8453,8454]
===
match
---
trailer [17151,17159]
trailer [17362,17370]
===
match
---
name: test_utils [1856,1866]
name: test_utils [1896,1906]
===
match
---
atom [18935,18954]
atom [19286,19305]
===
match
---
trailer [11416,11423]
trailer [11627,11634]
===
match
---
atom_expr [12376,12392]
atom_expr [12587,12603]
===
match
---
name: TEST_DAG_FOLDER [9136,9151]
name: TEST_DAG_FOLDER [9347,9362]
===
match
---
simple_stmt [20355,20397]
simple_stmt [20760,20802]
===
match
---
name: dagbag [7777,7783]
name: dagbag [7988,7994]
===
match
---
name: task_terminated_externally [18581,18607]
name: task_terminated_externally [18932,18958]
===
match
---
testlist_comp [3171,3217]
testlist_comp [3211,3257]
===
match
---
operator: , [21005,21006]
operator: , [21410,21411]
===
match
---
name: check_result_1 [3153,3167]
name: check_result_1 [3193,3207]
===
match
---
operator: , [19366,19367]
operator: , [19717,19718]
===
match
---
trailer [4302,4315]
trailer [4459,4471]
===
match
---
operator: } [2672,2673]
operator: } [2712,2713]
===
match
---
number: 0.1 [7415,7418]
number: 0.1 [7626,7629]
===
match
---
trailer [5936,5958]
trailer [6147,6169]
===
match
---
name: dag [12417,12420]
name: dag [12628,12631]
===
match
---
name: return_value [4525,4537]
name: task_runner [4725,4736]
===
match
---
name: dag_folder [9125,9135]
name: dag_folder [9336,9346]
===
match
---
trailer [7594,7599]
trailer [7805,7810]
===
match
---
assert_stmt [7687,7719]
assert_stmt [7898,7930]
===
match
---
name: taskinstance [1307,1319]
name: taskinstance [1347,1359]
===
match
---
string: 'owner1' [18945,18953]
string: 'owner1' [19296,19304]
===
match
---
arglist [18565,18571]
arglist [18916,18922]
===
match
---
name: self [20854,20858]
name: self [21259,21263]
===
match
---
name: args [15404,15408]
name: args [15615,15619]
===
match
---
argument [8527,8536]
argument [8738,8747]
===
match
---
name: dispose [17658,17665]
name: dispose [17869,17876]
===
match
---
with_stmt [11287,11379]
with_stmt [11498,11590]
===
match
---
operator: = [17606,17607]
operator: = [17817,17818]
===
match
---
trailer [17797,17813]
trailer [18008,18024]
===
match
---
number: 2 [6030,6031]
number: 2 [6241,6242]
===
match
---
atom_expr [3047,3067]
atom_expr [3087,3107]
===
match
---
simple_stmt [11807,11824]
simple_stmt [12018,12035]
===
match
---
operator: = [4073,4074]
operator: = [4079,4080]
===
match
---
operator: , [16998,16999]
operator: , [17209,17210]
===
match
---
name: session [5440,5447]
name: session [5651,5658]
===
match
---
atom_expr [11837,11851]
atom_expr [12048,12062]
===
match
---
operator: = [12163,12164]
operator: = [12374,12375]
===
match
---
atom_expr [20217,20232]
atom_expr [20591,20606]
===
match
---
simple_stmt [9969,9996]
simple_stmt [10180,10207]
===
match
---
operator: = [14497,14498]
operator: = [14708,14709]
===
match
---
simple_stmt [8291,8356]
simple_stmt [8502,8567]
===
match
---
string: """         Test that ensures that when a task is killed with sigterm         on_failure_callback gets executed         """ [18275,18398]
string: """         Test that ensures that when a task is killed with sigterm or sigkill         on_failure_callback gets executed         """ [18615,18749]
===
match
---
atom_expr [4008,4019]
atom_expr [4014,4025]
===
match
---
name: clear_db_runs [20565,20578]
name: clear_db_runs [20970,20983]
===
match
---
operator: == [10336,10338]
operator: == [10547,10549]
===
match
---
atom_expr [20322,20346]
atom_expr [20727,20751]
===
match
---
name: execution_date [8178,8192]
name: execution_date [8389,8403]
===
match
---
trailer [11674,11679]
trailer [11885,11890]
===
match
---
atom_expr [7513,7526]
atom_expr [7724,7737]
===
match
---
operator: , [3948,3949]
operator: , [3954,3955]
===
match
---
suite [2071,2264]
suite [2111,2304]
===
match
---
operator: , [17548,17549]
operator: , [17759,17760]
===
match
---
name: dag [14362,14365]
name: dag [14573,14576]
===
match
---
trailer [15456,15468]
trailer [15667,15679]
===
match
---
operator: = [12648,12649]
operator: = [12859,12860]
===
match
---
argument [9533,9556]
argument [9744,9767]
===
match
---
argument [2851,2878]
argument [2891,2918]
===
match
---
file_input [789,21472]
file_input [789,21877]
===
match
---
operator: = [7033,7034]
operator: = [7244,7245]
===
match
---
name: mark [9018,9022]
name: mark [9229,9233]
===
match
---
argument [21061,21092]
argument [21466,21497]
===
match
---
trailer [19499,19505]
trailer [19850,19856]
===
match
---
simple_stmt [6251,6291]
simple_stmt [6462,6502]
===
match
---
name: ti [8467,8469]
name: ti [8678,8680]
===
match
---
name: pytest [4555,4561]
name: pytest [4766,4772]
===
match
---
string: 'test_mark_failure' [18830,18849]
string: 'test_mark_failure' [19181,19200]
===
match
---
name: call_count [10378,10388]
name: call_count [10589,10599]
===
match
---
name: run_id [17222,17228]
name: run_id [17433,17439]
===
match
---
atom_expr [5637,5651]
atom_expr [5848,5862]
===
match
---
name: session [1616,1623]
name: session [1656,1663]
===
match
---
operator: = [7862,7863]
operator: = [8073,8074]
===
match
---
name: failure_callback_called [11292,11315]
name: failure_callback_called [11503,11526]
===
match
---
raise_stmt [14072,14100]
raise_stmt [14283,14311]
===
match
---
name: state [17926,17931]
name: state [18137,18142]
===
match
---
trailer [7647,7649]
trailer [7858,7860]
===
match
---
atom_expr [15486,15514]
atom_expr [15697,15725]
===
match
---
dotted_name [1524,1537]
dotted_name [1564,1577]
===
match
---
simple_stmt [18016,18033]
simple_stmt [18227,18244]
===
match
---
operator: = [5045,5046]
operator: = [5256,5257]
===
match
---
string: """         Test that ensures that where a task is marked success in the UI         on_success_callback gets executed         """ [15938,16067]
string: """         Test that ensures that where a task is marked success in the UI         on_success_callback gets executed         """ [16149,16278]
===
match
---
operator: = [21068,21069]
operator: = [21473,21474]
===
match
---
name: ti [20156,20158]
name: ti [20507,20509]
===
match
---
atom_expr [20921,20938]
atom_expr [21326,21343]
===
match
---
name: DEFAULT_DATE [21243,21255]
name: DEFAULT_DATE [21648,21660]
===
match
---
name: session [7561,7568]
name: session [7772,7779]
===
match
---
name: context [13896,13903]
name: context [14107,14114]
===
match
---
atom_expr [12081,12137]
atom_expr [12292,12348]
===
match
---
name: State [1678,1683]
name: State [1718,1723]
===
match
---
name: _execute [5975,5983]
name: _execute [6186,6194]
===
match
---
operator: , [14627,14628]
operator: , [14838,14839]
===
match
---
expr_stmt [2221,2263]
expr_stmt [2261,2303]
===
match
---
name: ti [3903,3905]
name: ti [3909,3911]
===
match
---
atom_expr [5323,5336]
atom_expr [5534,5547]
===
match
---
trailer [17159,17161]
trailer [17370,17372]
===
match
---
operator: = [9103,9104]
operator: = [9314,9315]
===
match
---
name: execution_date [21228,21242]
name: execution_date [21633,21647]
===
match
---
atom_expr [8783,8793]
atom_expr [8994,9004]
===
match
---
name: executor [4128,4136]
name: executor [4134,4142]
===
match
---
name: pytest [982,988]
name: pytest [982,988]
===
match
---
operator: = [7178,7179]
operator: = [7389,7390]
===
match
---
number: 2 [4540,4541]
number: 2 [4751,4752]
===
match
---
funcdef [10829,13192]
funcdef [11040,13403]
===
match
---
atom_expr [13028,13048]
atom_expr [13239,13259]
===
match
---
name: time_end [10402,10410]
name: time_end [10613,10621]
===
match
---
name: ti [14055,14057]
name: ti [14266,14268]
===
match
---
name: time [7404,7408]
name: time [7615,7619]
===
match
---
operator: = [14706,14707]
operator: = [14917,14918]
===
match
---
operator: = [9759,9760]
operator: = [9970,9971]
===
match
---
string: 'test_failure_callback_race' [13925,13953]
string: 'test_failure_callback_race' [14136,14164]
===
match
---
name: ti [11733,11735]
name: ti [11944,11946]
===
match
---
name: get_task [7965,7973]
name: get_task [8176,8184]
===
match
---
trailer [13012,13016]
trailer [13223,13227]
===
match
---
trailer [19918,19930]
trailer [20269,20281]
===
match
---
operator: = [9464,9465]
operator: = [9675,9676]
===
match
---
expr_stmt [16250,16292]
expr_stmt [16461,16503]
===
match
---
name: get_task_instance [8299,8316]
name: get_task_instance [8510,8527]
===
match
---
name: clear_db_jobs [20545,20558]
name: clear_db_jobs [20950,20963]
===
match
---
operator: = [21177,21178]
operator: = [21582,21583]
===
match
---
atom [2654,2673]
atom [2694,2713]
===
match
---
name: commit [18024,18030]
name: commit [18235,18241]
===
match
---
trailer [15864,15870]
trailer [16075,16081]
===
match
---
trailer [7114,7116]
trailer [7325,7327]
===
match
---
expr_stmt [16932,17123]
expr_stmt [17143,17334]
===
match
---
trailer [3928,3966]
trailer [3934,3972]
===
match
---
name: heartbeat_callback [5875,5893]
name: heartbeat_callback [6086,6104]
===
match
---
atom_expr [17769,17781]
atom_expr [17980,17992]
===
match
---
atom_expr [15732,15752]
atom_expr [15943,15963]
===
match
---
trailer [7504,7510]
trailer [7715,7721]
===
match
---
name: failure_callback_called [11344,11367]
name: failure_callback_called [11555,11578]
===
match
---
trailer [8486,8493]
trailer [8697,8704]
===
match
---
assert_stmt [11619,11651]
assert_stmt [11830,11862]
===
match
---
operator: , [2878,2879]
operator: , [2918,2919]
===
match
---
argument [2641,2673]
argument [2681,2713]
===
match
---
suite [18696,18850]
suite [19047,19201]
===
match
---
trailer [7098,7114]
trailer [7309,7325]
===
match
---
atom_expr [4217,4242]
atom_expr [4378,4403]
===
match
---
operator: = [5894,5895]
operator: = [6105,6106]
===
match
---
name: attr [3317,3321]
name: attr [3357,3361]
===
match
---
name: default_args [18922,18934]
name: default_args [19273,19285]
===
match
---
operator: == [7708,7710]
operator: == [7919,7921]
===
match
---
atom_expr [14197,14380]
atom_expr [14408,14591]
===
match
---
name: do_update [5776,5785]
name: do_update [5987,5996]
===
match
---
name: self [4806,4810]
name: self [5017,5021]
===
match
---
number: 1 [4407,4408]
number: 1 [4575,4576]
===
match
---
operator: = [17716,17717]
operator: = [17927,17928]
===
match
---
name: i [6129,6130]
name: i [6340,6341]
===
match
---
simple_stmt [5088,5130]
simple_stmt [5299,5341]
===
match
---
operator: = [5820,5821]
operator: = [6031,6032]
===
match
---
suite [13825,13877]
suite [14036,14088]
===
match
---
name: session [3876,3883]
name: session [3882,3889]
===
match
---
trailer [14459,14473]
trailer [14670,14684]
===
match
---
trailer [19804,19806]
trailer [20155,20157]
===
match
---
simple_stmt [13403,13537]
simple_stmt [13614,13748]
===
match
---
atom_expr [5763,5792]
atom_expr [5974,6003]
===
match
---
name: dag [6826,6829]
name: dag [7037,7040]
===
match
---
operator: , [8536,8537]
operator: , [8747,8748]
===
match
---
argument [5754,5792]
argument [5965,6003]
===
match
---
simple_stmt [4516,4542]
simple_stmt [4720,4753]
===
match
---
trailer [8366,8372]
trailer [8577,8583]
===
match
---
trailer [17896,17902]
trailer [18107,18113]
===
match
---
string: 'AIRFLOW__CORE__DAGS_FOLDER' [1976,2004]
string: 'AIRFLOW__CORE__DAGS_FOLDER' [2016,2044]
===
match
---
import_from [1845,1900]
import_from [1885,1940]
===
match
---
name: state [3978,3983]
name: state [3984,3989]
===
match
---
expr_stmt [21266,21339]
expr_stmt [21671,21744]
===
match
---
comparison [10761,10799]
comparison [10972,11010]
===
match
---
test [15440,15476]
test [15651,15687]
===
match
---
argument [21007,21030]
argument [21412,21435]
===
match
---
simple_stmt [3263,3341]
simple_stmt [3303,3381]
===
match
---
name: job1 [12741,12745]
name: job1 [12952,12956]
===
match
---
atom [5856,5858]
atom [6067,6069]
===
match
---
trailer [19243,19249]
trailer [19594,19600]
===
match
---
name: time_end [10761,10769]
name: time_end [10972,10980]
===
match
---
atom_expr [5623,5634]
atom_expr [5834,5845]
===
match
---
name: dag_folder [4944,4954]
name: dag_folder [5155,5165]
===
match
---
operator: - [6266,6267]
operator: - [6477,6478]
===
match
---
atom_expr [20565,20580]
atom_expr [20970,20985]
===
match
---
trailer [3178,3190]
trailer [3218,3230]
===
match
---
name: session [14435,14442]
name: session [14646,14653]
===
match
---
argument [2815,2828]
argument [2855,2868]
===
match
---
name: RUNNING [7361,7368]
name: RUNNING [7572,7579]
===
match
---
simple_stmt [5687,5704]
simple_stmt [5898,5915]
===
match
---
name: state [19574,19579]
name: state [19925,19930]
===
match
---
operator: , [3817,3818]
operator: , [3823,3824]
===
match
---
name: DEFAULT_DATE [5369,5381]
name: DEFAULT_DATE [5580,5592]
===
match
---
name: ti [7432,7434]
name: ti [7643,7645]
===
match
---
name: SequentialExecutor [12810,12828]
name: SequentialExecutor [13021,13039]
===
match
---
trailer [7434,7450]
trailer [7645,7661]
===
match
---
name: FAILED [11750,11756]
name: FAILED [11961,11967]
===
match
---
operator: , [9585,9586]
operator: , [9796,9797]
===
match
---
operator: = [19931,19932]
operator: = [20282,20283]
===
match
---
name: refresh_from_db [7661,7676]
name: refresh_from_db [7872,7887]
===
match
---
name: essential_attr [3325,3339]
name: essential_attr [3365,3379]
===
match
---
string: 'op1' [3658,3663]
string: 'op1' [3664,3669]
===
match
---
operator: = [8409,8410]
operator: = [8620,8621]
===
match
---
name: self [2387,2391]
name: self [2427,2431]
===
match
---
name: patch [968,973]
name: patch [968,973]
===
match
---
fstring_start: f' [20964,20966]
fstring_start: f' [21369,21371]
===
match
---
decorator [20666,20748]
decorator [21071,21153]
===
match
---
name: session [17360,17367]
name: session [17571,17578]
===
match
---
arglist [21368,21409]
arglist [21773,21814]
===
match
---
name: dag [3613,3616]
name: dag [3619,3622]
===
match
---
number: 1 [13137,13138]
number: 1 [13348,13349]
===
match
---
atom_expr [6062,6084]
atom_expr [6273,6295]
===
match
---
number: 1 [11235,11236]
number: 1 [11446,11447]
===
match
---
name: addCleanup [2188,2198]
name: addCleanup [2228,2238]
===
match
---
name: task [9273,9277]
name: task [9484,9488]
===
match
---
operator: = [9577,9578]
operator: = [9788,9789]
===
match
---
simple_stmt [17642,17668]
simple_stmt [17853,17879]
===
match
---
name: RUNNING [12495,12502]
name: RUNNING [12706,12713]
===
match
---
comparison [16470,16518]
comparison [16681,16729]
===
match
---
if_stmt [17828,17880]
if_stmt [18039,18091]
===
match
---
argument [3790,3817]
argument [3796,3823]
===
match
---
string: 'owner1' [2664,2672]
string: 'owner1' [2704,2712]
===
match
---
trailer [2997,3068]
trailer [3037,3108]
===
match
---
argument [19547,19560]
argument [19898,19911]
===
match
---
simple_stmt [12417,12637]
simple_stmt [12628,12848]
===
match
---
atom_expr [8514,8566]
atom_expr [8725,8777]
===
match
---
atom_expr [7252,7267]
atom_expr [7463,7478]
===
match
---
simple_stmt [3903,3967]
simple_stmt [3909,3973]
===
match
---
atom_expr [14750,14770]
atom_expr [14961,14981]
===
match
---
operator: = [18648,18649]
operator: = [18999,19000]
===
match
---
name: execution_date [6917,6931]
name: execution_date [7128,7142]
===
match
---
atom_expr [2784,2913]
atom_expr [2824,2953]
===
match
---
operator: = [4121,4122]
operator: = [4127,4128]
===
match
---
atom_expr [2183,2212]
atom_expr [2223,2252]
===
match
---
name: SUCCESS [10517,10524]
name: SUCCESS [10728,10735]
===
match
---
atom_expr [19217,19249]
atom_expr [19568,19600]
===
match
---
name: timeout [20335,20342]
name: timeout [20740,20747]
===
match
---
expr_stmt [14110,14181]
expr_stmt [14321,14392]
===
match
---
name: LocalTaskJob [4075,4087]
name: LocalTaskJob [4081,4093]
===
match
---
arglist [8317,8354]
arglist [8528,8565]
===
match
---
name: dag_id [5163,5169]
name: dag_id [5374,5380]
===
match
---
name: refresh_from_db [14753,14768]
name: refresh_from_db [14964,14979]
===
match
---
simple_stmt [20405,20450]
simple_stmt [20810,20855]
===
match
---
atom_expr [6326,6339]
atom_expr [6537,6550]
===
match
---
atom_expr [16319,16325]
atom_expr [16530,16536]
===
match
---
dictorsetmaker [2655,2672]
dictorsetmaker [2695,2712]
===
match
---
name: clear [12355,12360]
name: clear [12566,12571]
===
match
---
trailer [14393,14399]
trailer [14604,14610]
===
match
---
name: usefixtures [20596,20607]
name: usefixtures [21001,21012]
===
match
---
atom_expr [9976,9995]
atom_expr [10187,10206]
===
match
---
name: job [5937,5940]
name: job [6148,6151]
===
match
---
trailer [17813,17815]
trailer [18024,18026]
===
match
---
name: NONE [21184,21188]
name: NONE [21589,21593]
===
match
---
name: TaskInstance [5488,5500]
name: TaskInstance [5699,5711]
===
match
---
operator: } [3596,3597]
operator: } [3602,3603]
===
match
---
with_stmt [16848,16923]
with_stmt [17059,17134]
===
match
---
name: session [11594,11601]
name: session [11805,11812]
===
match
---
name: settings [9353,9361]
name: settings [9564,9572]
===
match
---
decorators [20666,20811]
decorators [21071,21216]
===
match
---
operator: = [14785,14786]
operator: = [14996,14997]
===
match
---
operator: , [17422,17423]
operator: , [17633,17634]
===
match
---
name: Lock [13741,13745]
name: Lock [13952,13956]
===
match
---
name: multiprocessing [7203,7218]
name: multiprocessing [7414,7429]
===
match
---
expr_stmt [3975,3999]
expr_stmt [3981,4005]
===
match
---
trailer [8791,8793]
trailer [9002,9004]
===
match
---
parameters [20853,20895]
parameters [21258,21300]
===
match
---
name: dagbag [4911,4917]
name: dagbag [5122,5128]
===
match
---
param [6411,6415]
param [6622,6626]
===
match
---
name: ti [7096,7098]
name: ti [7307,7309]
===
match
---
name: DEFAULT_DATE [2627,2639]
name: DEFAULT_DATE [2667,2679]
===
match
---
trailer [20304,20312]
trailer [18476,18484]
===
match
---
atom [16604,16623]
atom [16815,16834]
===
match
---
operator: = [8294,8295]
operator: = [8505,8506]
===
match
---
name: task_instance [17510,17523]
name: task_instance [17721,17734]
===
match
---
name: unique_prefix [21157,21170]
name: unique_prefix [21562,21575]
===
match
---
argument [4088,4104]
argument [4094,4110]
===
match
---
string: 'test_localtaskjob_double_trigger_task' [7974,8013]
string: 'test_localtaskjob_double_trigger_task' [8185,8224]
===
match
---
name: start_date [19648,19658]
name: start_date [19999,20009]
===
match
---
operator: = [19466,19467]
operator: = [19817,19818]
===
match
---
operator: = [12458,12459]
operator: = [12669,12670]
===
match
---
name: execution_date [19749,19763]
name: execution_date [20100,20114]
===
match
---
name: i [6048,6049]
name: i [6259,6260]
===
match
---
string: 'dag_run' [13904,13913]
string: 'dag_run' [14115,14124]
===
match
---
operator: , [20858,20859]
operator: , [21263,21264]
===
match
---
trailer [8971,8979]
trailer [9182,9190]
===
match
---
funcdef [2055,2264]
funcdef [2095,2304]
===
match
---
name: merge [4425,4430]
name: merge [4593,4598]
===
match
---
name: job1 [14780,14784]
name: job1 [14991,14995]
===
match
---
suite [4587,4668]
suite [4798,4879]
===
match
---
argument [8178,8205]
argument [8389,8416]
===
match
---
name: execution_date [8538,8552]
name: execution_date [8749,8763]
===
match
---
operator: = [12774,12775]
operator: = [12985,12986]
===
match
---
operator: , [14711,14712]
operator: , [14922,14923]
===
match
---
operator: = [6109,6110]
operator: = [6320,6321]
===
match
---
argument [8145,8164]
argument [8356,8375]
===
match
---
number: 25 [17778,17780]
number: 25 [17989,17991]
===
match
---
expr_stmt [5664,5674]
expr_stmt [5875,5885]
===
match
---
name: DEFAULT_DATE [2891,2903]
name: DEFAULT_DATE [2931,2943]
===
match
---
trailer [10288,10290]
trailer [10499,10501]
===
match
---
trailer [4363,4372]
trailer [4531,4540]
===
match
---
name: session [8989,8996]
name: session [9200,9207]
===
match
---
operator: = [11742,11743]
operator: = [11953,11954]
===
match
---
name: dags [7901,7905]
name: dags [8112,8116]
===
match
---
simple_stmt [20545,20561]
simple_stmt [20950,20966]
===
match
---
arglist [7145,7183]
arglist [7356,7394]
===
match
---
atom_expr [8151,8164]
atom_expr [8362,8375]
===
match
---
operator: , [12777,12778]
operator: , [12988,12989]
===
match
---
name: ti [5664,5666]
name: ti [5875,5877]
===
match
---
operator: @ [13197,13198]
operator: @ [13408,13409]
===
match
---
atom_expr [13008,13018]
atom_expr [13219,13229]
===
match
---
argument [21217,21226]
argument [21622,21631]
===
match
---
simple_stmt [11195,11238]
simple_stmt [11406,11449]
===
match
---
arglist [10056,10102]
arglist [10267,10313]
===
match
---
operator: = [19352,19353]
operator: = [19703,19704]
===
match
---
name: fixture [20498,20505]
name: fixture [20903,20910]
===
match
---
operator: == [13073,13075]
operator: == [13284,13286]
===
match
---
simple_stmt [21349,21411]
simple_stmt [21754,21816]
===
match
---
name: commit [7569,7575]
name: commit [7780,7786]
===
match
---
operator: @ [9010,9011]
operator: @ [9221,9222]
===
match
---
simple_stmt [7777,7880]
simple_stmt [7988,8091]
===
match
---
string: 'task1' [6750,6757]
string: 'task1' [6961,6968]
===
match
---
operator: = [12123,12124]
operator: = [12334,12335]
===
match
---
atom_expr [20060,20075]
atom_expr [20411,20426]
===
match
---
name: dag [7888,7891]
name: dag [8099,8102]
===
match
---
atom_expr [8364,8372]
atom_expr [8575,8583]
===
match
---
expr_stmt [20947,21031]
expr_stmt [21352,21436]
===
match
---
trailer [21299,21311]
trailer [21704,21716]
===
match
---
suite [12013,12067]
suite [12224,12278]
===
match
---
operator: - [6131,6132]
operator: - [6342,6343]
===
match
---
operator: , [17526,17527]
operator: , [17737,17738]
===
match
---
operator: = [19399,19400]
operator: = [19750,19751]
===
match
---
operator: = [7892,7893]
operator: = [8103,8104]
===
match
---
trailer [10141,10148]
trailer [10352,10359]
===
match
---
operator: = [2983,2984]
operator: = [3023,3024]
===
match
---
simple_stmt [12645,12703]
simple_stmt [12856,12914]
===
match
---
operator: = [4337,4338]
operator: = [4505,4506]
===
match
---
name: State [11626,11631]
name: State [11837,11842]
===
match
---
operator: , [6623,6624]
operator: , [6834,6835]
===
match
---
trailer [12662,12702]
trailer [12873,12913]
===
match
---
name: process [18042,18049]
name: process [18253,18260]
===
match
---
operator: == [20257,20259]
operator: == [20631,20633]
===
match
---
name: time [4845,4849]
name: time [5056,5060]
===
match
---
argument [5736,5752]
argument [5947,5963]
===
match
---
atom_expr [4172,4203]
atom_expr [4333,4364]
===
match
---
trailer [21311,21324]
trailer [21716,21729]
===
match
---
trailer [5649,5651]
trailer [5860,5862]
===
match
---
trailer [3768,3776]
trailer [3774,3782]
===
match
---
arglist [21217,21255]
arglist [21622,21660]
===
match
---
operator: = [12534,12535]
operator: = [12745,12746]
===
match
---
trailer [20158,20164]
trailer [20509,20515]
===
match
---
name: self [15923,15927]
name: self [16134,16138]
===
match
---
operator: = [1915,1916]
operator: = [1955,1956]
===
match
---
argument [7048,7057]
argument [7259,7268]
===
match
---
name: DEFAULT_DATE [2866,2878]
name: DEFAULT_DATE [2906,2918]
===
match
---
argument [8339,8354]
argument [8550,8565]
===
match
---
name: value [11368,11373]
name: value [11579,11584]
===
match
---
name: process [20060,20067]
name: process [20411,20418]
===
match
---
name: mock_ret_code [10218,10231]
name: mock_ret_code [10429,10442]
===
match
---
trailer [16488,16495]
trailer [16699,16706]
===
match
---
decorator [20583,20627]
decorator [20988,21032]
===
match
---
with_item [4870,4897]
with_item [5081,5108]
===
match
---
trailer [7909,7945]
trailer [8120,8156]
===
match
---
operator: = [7158,7159]
operator: = [7369,7370]
===
match
---
if_stmt [7340,7392]
if_stmt [7551,7603]
===
match
---
not_test [20465,20487]
not_test [20870,20892]
===
match
---
name: execution_date [12520,12534]
name: execution_date [12731,12745]
===
match
---
argument [14269,14298]
argument [14480,14509]
===
match
---
atom_expr [8694,8754]
atom_expr [8905,8965]
===
match
---
simple_stmt [6103,6136]
simple_stmt [6314,6347]
===
match
---
name: State [17968,17973]
name: State [18179,18184]
===
match
---
name: merge [17998,18003]
name: merge [18209,18214]
===
match
---
trailer [4049,4056]
trailer [4055,4062]
===
match
---
name: sleep [16720,16725]
name: sleep [16931,16936]
===
match
---
name: session [6995,7002]
name: session [7206,7213]
===
match
---
operator: = [9135,9136]
operator: = [9346,9347]
===
match
---
trailer [4884,4886]
trailer [5095,5097]
===
match
---
argument [17510,17526]
argument [17721,17737]
===
match
---
trailer [17997,18003]
trailer [18208,18214]
===
match
---
name: pid [20293,20296]
name: pid [20540,20543]
===
match
---
operator: = [13739,13740]
operator: = [13950,13951]
===
match
---
name: assert_queries_count [1763,1783]
name: assert_queries_count [1803,1823]
===
match
---
name: RUNNING [8381,8388]
name: RUNNING [8592,8599]
===
match
---
argument [21094,21101]
argument [21499,21506]
===
match
---
fstring [20964,21005]
fstring [21369,21410]
===
match
---
simple_stmt [5664,5675]
simple_stmt [5875,5886]
===
match
---
number: 1 [15874,15875]
number: 1 [16085,16086]
===
match
---
name: return_value [8736,8748]
name: return_value [8947,8959]
===
match
---
simple_stmt [18075,18117]
simple_stmt [18286,18328]
===
match
---
name: dagbag [9096,9102]
name: dagbag [9307,9313]
===
match
---
operator: = [5671,5672]
operator: = [5882,5883]
===
match
---
trailer [6829,6843]
trailer [7040,7054]
===
match
---
simple_stmt [17735,17751]
simple_stmt [17946,17962]
===
match
---
atom_expr [5912,5958]
atom_expr [6123,6169]
===
match
---
argument [8650,8679]
argument [8861,8890]
===
match
---
arglist [19298,19438]
arglist [19649,19789]
===
insert-tree
---
simple_stmt [989,1029]
    import_from [989,1028]
        name: parameterized [994,1007]
        name: parameterized [1015,1028]
to
file_input [789,21472]
at 10
===
insert-node
---
name: TestLocalTaskJob [2054,2070]
to
classdef [2008,20488]
at 0
===
move-tree
---
funcdef [3405,4668]
    name: test_localtaskjob_heartbeat [3409,3436]
    parameters [3436,3452]
        param [3437,3442]
            name: self [3437,3441]
            operator: , [3441,3442]
        param [3443,3451]
            name: mock_pid [3443,3451]
    suite [3453,4668]
        simple_stmt [3462,3491]
            expr_stmt [3462,3490]
                name: session [3462,3469]
                operator: = [3470,3471]
                atom_expr [3472,3490]
                    name: settings [3472,3480]
                    trailer [3480,3488]
                        name: Session [3481,3488]
                    trailer [3488,3490]
        simple_stmt [3499,3599]
            expr_stmt [3499,3598]
                name: dag [3499,3502]
                operator: = [3503,3504]
                atom_expr [3505,3598]
                    name: DAG [3505,3508]
                    trailer [3508,3598]
                        arglist [3509,3597]
                            string: 'test_localtaskjob_heartbeat' [3509,3538]
                            operator: , [3538,3539]
                            argument [3540,3563]
                                name: start_date [3540,3550]
                                operator: = [3550,3551]
                                name: DEFAULT_DATE [3551,3563]
                            operator: , [3563,3564]
                            argument [3565,3597]
                                name: default_args [3565,3577]
                                operator: = [3577,3578]
                                atom [3578,3597]
                                    operator: { [3578,3579]
                                    dictorsetmaker [3579,3596]
                                        string: 'owner' [3579,3586]
                                        string: 'owner1' [3588,3596]
                                    operator: } [3596,3597]
        with_stmt [3608,3665]
            name: dag [3613,3616]
            suite [3617,3665]
                simple_stmt [3630,3665]
                    expr_stmt [3630,3664]
                        name: op1 [3630,3633]
                        operator: = [3634,3635]
                        atom_expr [3636,3664]
                            name: DummyOperator [3636,3649]
                            trailer [3649,3664]
                                argument [3650,3663]
                                    name: task_id [3650,3657]
                                    operator: = [3657,3658]
                                    string: 'op1' [3658,3663]
        simple_stmt [3674,3686]
            atom_expr [3674,3685]
                name: dag [3674,3677]
                trailer [3677,3683]
                    name: clear [3678,3683]
                trailer [3683,3685]
        simple_stmt [3694,3895]
            expr_stmt [3694,3894]
                name: dr [3694,3696]
                operator: = [3697,3698]
                atom_expr [3699,3894]
                    name: dag [3699,3702]
                    trailer [3702,3716]
                        name: create_dagrun [3703,3716]
                    trailer [3716,3894]
                        arglist [3730,3884]
                            argument [3730,3743]
                                name: run_id [3730,3736]
                                operator: = [3736,3737]
                                string: "test" [3737,3743]
                            operator: , [3743,3744]
                            argument [3757,3776]
                                name: state [3757,3762]
                                operator: = [3762,3763]
                                atom_expr [3763,3776]
                                    name: State [3763,3768]
                                    trailer [3768,3776]
                                        name: SUCCESS [3769,3776]
                            operator: , [3776,3777]
                            argument [3790,3817]
                                name: execution_date [3790,3804]
                                operator: = [3804,3805]
                                name: DEFAULT_DATE [3805,3817]
                            operator: , [3817,3818]
                            argument [3831,3854]
                                name: start_date [3831,3841]
                                operator: = [3841,3842]
                                name: DEFAULT_DATE [3842,3854]
                            operator: , [3854,3855]
                            argument [3868,3883]
                                name: session [3868,3875]
                                operator: = [3875,3876]
                                name: session [3876,3883]
                            operator: , [3883,3884]
        simple_stmt [3903,3967]
            expr_stmt [3903,3966]
                name: ti [3903,3905]
                operator: = [3906,3907]
                atom_expr [3908,3966]
                    name: dr [3908,3910]
                    trailer [3910,3928]
                        name: get_task_instance [3911,3928]
                    trailer [3928,3966]
                        arglist [3929,3965]
                            argument [3929,3948]
                                name: task_id [3929,3936]
                                operator: = [3936,3937]
                                atom_expr [3937,3948]
                                    name: op1 [3937,3940]
                                    trailer [3940,3948]
                                        name: task_id [3941,3948]
                            operator: , [3948,3949]
                            argument [3950,3965]
                                name: session [3950,3957]
                                operator: = [3957,3958]
                                name: session [3958,3965]
        simple_stmt [3975,4000]
            expr_stmt [3975,3999]
                atom_expr [3975,3983]
                    name: ti [3975,3977]
                    trailer [3977,3983]
                        name: state [3978,3983]
                operator: = [3984,3985]
                atom_expr [3986,3999]
                    name: State [3986,3991]
                    trailer [3991,3999]
                        name: RUNNING [3992,3999]
        simple_stmt [4008,4034]
            expr_stmt [4008,4033]
                atom_expr [4008,4019]
                    name: ti [4008,4010]
                    trailer [4010,4019]
                        name: hostname [4011,4019]
                operator: = [4020,4021]
                string: "blablabla" [4022,4033]
        simple_stmt [4042,4059]
            atom_expr [4042,4058]
                name: session [4042,4049]
                trailer [4049,4056]
                    name: commit [4050,4056]
                trailer [4056,4058]
        simple_stmt [4068,4159]
            expr_stmt [4068,4158]
                name: job1 [4068,4072]
                operator: = [4073,4074]
                atom_expr [4075,4158]
                    name: LocalTaskJob [4075,4087]
                    trailer [4087,4158]
                        arglist [4088,4157]
                            argument [4088,4104]
                                name: task_instance [4088,4101]
                                operator: = [4101,4102]
                                name: ti [4102,4104]
                            operator: , [4104,4105]
                            argument [4106,4126]
                                name: ignore_ti_state [4106,4121]
                                operator: = [4121,4122]
                            operator: , [4126,4127]
                            argument [4128,4157]
                                name: executor [4128,4136]
                                operator: = [4136,4137]
                                atom_expr [4137,4157]
                                    name: SequentialExecutor [4137,4155]
                                    trailer [4155,4157]
        with_stmt [4167,4285]
            atom_expr [4172,4203]
                name: pytest [4172,4178]
                trailer [4178,4185]
                    name: raises [4179,4185]
                trailer [4185,4203]
                    name: AirflowException [4186,4202]
            suite [4204,4285]
                simple_stmt [4217,4285]
                    atom_expr [4217,4242]
                        name: job1 [4217,4221]
                        trailer [4221,4240]
                            name: heartbeat_callback [4222,4240]
                        trailer [4240,4242]
        simple_stmt [4294,4320]
            expr_stmt [4294,4319]
                atom_expr [4294,4315]
                    name: mock_pid [4294,4302]
                    trailer [4302,4315]
                        name: return_value [4303,4315]
                operator: = [4316,4317]
                number: 1 [4318,4319]
        simple_stmt [4328,4353]
            expr_stmt [4328,4352]
                atom_expr [4328,4336]
                    name: ti [4328,4330]
                    trailer [4330,4336]
                        name: state [4331,4336]
                operator: = [4337,4338]
                atom_expr [4339,4352]
                    name: State [4339,4344]
                    trailer [4344,4352]
                        name: RUNNING [4345,4352]
        simple_stmt [4361,4390]
            expr_stmt [4361,4389]
                atom_expr [4361,4372]
                    name: ti [4361,4363]
                    trailer [4363,4372]
                        name: hostname [4364,4372]
                operator: = [4373,4374]
                atom_expr [4375,4389]
                    name: get_hostname [4375,4387]
                    trailer [4387,4389]
        simple_stmt [4398,4409]
            expr_stmt [4398,4408]
                atom_expr [4398,4404]
                    name: ti [4398,4400]
                    trailer [4400,4404]
                        name: pid [4401,4404]
                operator: = [4405,4406]
                number: 1 [4407,4408]
        simple_stmt [4417,4435]
            atom_expr [4417,4434]
                name: session [4417,4424]
                trailer [4424,4430]
                    name: merge [4425,4430]
                trailer [4430,4434]
                    name: ti [4431,4433]
        simple_stmt [4443,4460]
            atom_expr [4443,4459]
                name: session [4443,4450]
                trailer [4450,4457]
                    name: commit [4451,4457]
                trailer [4457,4459]
        simple_stmt [4469,4507]
            atom_expr [4469,4506]
                name: job1 [4469,4473]
                trailer [4473,4492]
                    name: heartbeat_callback [4474,4492]
                trailer [4492,4506]
                    argument [4493,4505]
                        name: session [4493,4500]
                        operator: = [4500,4501]
        simple_stmt [4516,4542]
            expr_stmt [4516,4541]
                atom_expr [4516,4537]
                    name: mock_pid [4516,4524]
                    trailer [4524,4537]
                        name: return_value [4525,4537]
                operator: = [4538,4539]
                number: 2 [4540,4541]
        with_stmt [4550,4668]
            atom_expr [4555,4586]
                name: pytest [4555,4561]
                trailer [4561,4568]
                    name: raises [4562,4568]
                trailer [4568,4586]
                    name: AirflowException [4569,4585]
            suite [4587,4668]
                simple_stmt [4600,4668]
                    atom_expr [4600,4625]
                        name: job1 [4600,4604]
                        trailer [4604,4623]
                            name: heartbeat_callback [4605,4623]
                        trailer [4623,4625]
to
suite [2050,20488]
at 3
===
insert-node
---
decorated [18424,20893]
to
suite [2050,20488]
at 12
===
move-tree
---
parameters [18259,18265]
    param [18260,18264]
        name: self [18260,18264]
to
funcdef [3405,4668]
at 1
===
insert-node
---
decorator [18424,18535]
to
decorated [18424,20893]
at 0
===
move-tree
---
funcdef [18213,20488]
    name: test_process_kill_call_on_failure_callback [18217,18259]
    parameters [18259,18265]
        param [18260,18264]
            name: self [18260,18264]
    suite [18266,20488]
        simple_stmt [18275,18399]
            string: """         Test that ensures that when a task is killed with sigterm         on_failure_callback gets executed         """ [18275,18398]
        simple_stmt [18533,18573]
            expr_stmt [18533,18572]
                name: failure_callback_called [18533,18556]
                operator: = [18557,18558]
                atom_expr [18559,18572]
                    name: Value [18559,18564]
                    trailer [18564,18572]
                        arglist [18565,18571]
                            string: 'i' [18565,18568]
                            operator: , [18568,18569]
                            number: 0 [18570,18571]
        simple_stmt [18581,18624]
            expr_stmt [18581,18623]
                name: task_terminated_externally [18581,18607]
                operator: = [18608,18609]
                atom_expr [18610,18623]
                    name: Value [18610,18615]
                    trailer [18615,18623]
                        arglist [18616,18622]
                            string: 'i' [18616,18619]
                            operator: , [18619,18620]
                            number: 1 [18621,18622]
        simple_stmt [18632,18657]
            expr_stmt [18632,18656]
                name: shared_mem_lock [18632,18647]
                operator: = [18648,18649]
                atom_expr [18650,18656]
                    name: Lock [18650,18654]
                    trailer [18654,18656]
        funcdef [18666,18850]
            name: failure_callback [18670,18686]
            parameters [18686,18695]
                param [18687,18694]
                    name: context [18687,18694]
            suite [18696,18850]
                with_stmt [18709,18782]
                    name: shared_mem_lock [18714,18729]
                    suite [18730,18782]
                        simple_stmt [18747,18782]
                            expr_stmt [18747,18781]
                                atom_expr [18747,18776]
                                    name: failure_callback_called [18747,18770]
                                    trailer [18770,18776]
                                        name: value [18771,18776]
                                operator: += [18777,18779]
                                number: 1 [18780,18781]
                simple_stmt [18794,18850]
                    assert_stmt [18794,18849]
                        comparison [18801,18849]
                            atom_expr [18801,18826]
                                name: context [18801,18808]
                                trailer [18808,18819]
                                    string: 'dag_run' [18809,18818]
                                trailer [18819,18826]
                                    name: dag_id [18820,18826]
                            operator: == [18827,18829]
                            string: 'test_mark_failure' [18830,18849]
        simple_stmt [18859,18956]
            expr_stmt [18859,18955]
                name: dag [18859,18862]
                operator: = [18863,18864]
                atom_expr [18865,18955]
                    name: DAG [18865,18868]
                    trailer [18868,18955]
                        arglist [18869,18954]
                            argument [18869,18895]
                                name: dag_id [18869,18875]
                                operator: = [18875,18876]
                                string: 'test_mark_failure' [18876,18895]
                            operator: , [18895,18896]
                            argument [18897,18920]
                                name: start_date [18897,18907]
                                operator: = [18907,18908]
                                name: DEFAULT_DATE [18908,18920]
                            operator: , [18920,18921]
                            argument [18922,18954]
                                name: default_args [18922,18934]
                                operator: = [18934,18935]
                                atom [18935,18954]
                                    operator: { [18935,18936]
                                    dictorsetmaker [18936,18953]
                                        string: 'owner' [18936,18943]
                                        string: 'owner1' [18945,18953]
                                    operator: } [18953,18954]
        funcdef [18965,19254]
            name: task_function [18969,18982]
            parameters [18982,18986]
                param [18983,18985]
                    name: ti [18983,18985]
            suite [18987,19254]
                simple_stmt [19046,19061]
                    atom_expr [19046,19060]
                        name: time [19046,19050]
                        trailer [19050,19056]
                            name: sleep [19051,19056]
                        trailer [19056,19060]
                            number: 60 [19057,19059]
                with_stmt [19179,19254]
                    name: shared_mem_lock [19184,19199]
                    suite [19200,19254]
                        simple_stmt [19217,19254]
                            expr_stmt [19217,19253]
                                atom_expr [19217,19249]
                                    name: task_terminated_externally [19217,19243]
                                    trailer [19243,19249]
                                        name: value [19244,19249]
                                operator: = [19250,19251]
                                number: 0 [19252,19253]
        simple_stmt [19263,19449]
            expr_stmt [19263,19448]
                name: task [19263,19267]
                operator: = [19268,19269]
                atom_expr [19270,19448]
                    name: PythonOperator [19270,19284]
                    trailer [19284,19448]
                        arglist [19298,19438]
                            argument [19298,19323]
                                name: task_id [19298,19305]
                                operator: = [19305,19306]
                                string: 'test_on_failure' [19306,19323]
                            operator: , [19323,19324]
                            argument [19337,19366]
                                name: python_callable [19337,19352]
                                operator: = [19352,19353]
                                name: task_function [19353,19366]
                            operator: , [19366,19367]
                            argument [19380,19416]
                                name: on_failure_callback [19380,19399]
                                operator: = [19399,19400]
                                name: failure_callback [19400,19416]
                            operator: , [19416,19417]
                            argument [19430,19437]
                                name: dag [19430,19433]
                                operator: = [19433,19434]
                                name: dag [19434,19437]
                            operator: , [19437,19438]
        simple_stmt [19458,19487]
            expr_stmt [19458,19486]
                name: session [19458,19465]
                operator: = [19466,19467]
                atom_expr [19468,19486]
                    name: settings [19468,19476]
                    trailer [19476,19484]
                        name: Session [19477,19484]
                    trailer [19484,19486]
        simple_stmt [19496,19508]
            atom_expr [19496,19507]
                name: dag [19496,19499]
                trailer [19499,19505]
                    name: clear [19500,19505]
                trailer [19505,19507]
        simple_stmt [19516,19712]
            atom_expr [19516,19711]
                name: dag [19516,19519]
                trailer [19519,19533]
                    name: create_dagrun [19520,19533]
                trailer [19533,19711]
                    arglist [19547,19701]
                        argument [19547,19560]
                            name: run_id [19547,19553]
                            operator: = [19553,19554]
                            string: "test" [19554,19560]
                        operator: , [19560,19561]
                        argument [19574,19593]
                            name: state [19574,19579]
                            operator: = [19579,19580]
                            atom_expr [19580,19593]
                                name: State [19580,19585]
                                trailer [19585,19593]
                                    name: RUNNING [19586,19593]
                        operator: , [19593,19594]
                        argument [19607,19634]
                            name: execution_date [19607,19621]
                            operator: = [19621,19622]
                            name: DEFAULT_DATE [19622,19634]
                        operator: , [19634,19635]
                        argument [19648,19671]
                            name: start_date [19648,19658]
                            operator: = [19658,19659]
                            name: DEFAULT_DATE [19659,19671]
                        operator: , [19671,19672]
                        argument [19685,19700]
                            name: session [19685,19692]
                            operator: = [19692,19693]
                            name: session [19693,19700]
                        operator: , [19700,19701]
        simple_stmt [19720,19778]
            expr_stmt [19720,19777]
                name: ti [19720,19722]
                operator: = [19723,19724]
                atom_expr [19725,19777]
                    name: TaskInstance [19725,19737]
                    trailer [19737,19777]
                        arglist [19738,19776]
                            argument [19738,19747]
                                name: task [19738,19742]
                                operator: = [19742,19743]
                                name: task [19743,19747]
                            operator: , [19747,19748]
                            argument [19749,19776]
                                name: execution_date [19749,19763]
                                operator: = [19763,19764]
                                name: DEFAULT_DATE [19764,19776]
        simple_stmt [19786,19807]
            atom_expr [19786,19806]
                name: ti [19786,19788]
                trailer [19788,19804]
                    name: refresh_from_db [19789,19804]
                trailer [19804,19806]
        simple_stmt [19815,19906]
            expr_stmt [19815,19905]
                name: job1 [19815,19819]
                operator: = [19820,19821]
                atom_expr [19822,19905]
                    name: LocalTaskJob [19822,19834]
                    trailer [19834,19905]
                        arglist [19835,19904]
                            argument [19835,19851]
                                name: task_instance [19835,19848]
                                operator: = [19848,19849]
                                name: ti [19849,19851]
                            operator: , [19851,19852]
                            argument [19853,19873]
                                name: ignore_ti_state [19853,19868]
                                operator: = [19868,19869]
                            operator: , [19873,19874]
                            argument [19875,19904]
                                name: executor [19875,19883]
                                operator: = [19883,19884]
                                atom_expr [19884,19904]
                                    name: SequentialExecutor [19884,19902]
                                    trailer [19902,19904]
        simple_stmt [19914,19958]
            expr_stmt [19914,19957]
                atom_expr [19914,19930]
                    name: job1 [19914,19918]
                    trailer [19918,19930]
                        name: task_runner [19919,19930]
                operator: = [19931,19932]
                atom_expr [19933,19957]
                    name: StandardTaskRunner [19933,19951]
                    trailer [19951,19957]
                        name: job1 [19952,19956]
        simple_stmt [19967,19993]
            atom_expr [19967,19992]
                name: settings [19967,19975]
                trailer [19975,19982]
                    name: engine [19976,19982]
                trailer [19982,19990]
                    name: dispose [19983,19990]
                trailer [19990,19992]
        simple_stmt [20001,20052]
            expr_stmt [20001,20051]
                name: process [20001,20008]
                operator: = [20009,20010]
                atom_expr [20011,20051]
                    name: multiprocessing [20011,20026]
                    trailer [20026,20034]
                        name: Process [20027,20034]
                    trailer [20034,20051]
                        argument [20035,20050]
                            name: target [20035,20041]
                            operator: = [20041,20042]
                            atom_expr [20042,20050]
                                name: job1 [20042,20046]
                                trailer [20046,20050]
                                    name: run [20047,20050]
        simple_stmt [20060,20076]
            atom_expr [20060,20075]
                name: process [20060,20067]
                trailer [20067,20073]
                    name: start [20068,20073]
                trailer [20073,20075]
        for_stmt [20085,20233]
            name: _ [20089,20090]
            atom_expr [20094,20106]
                name: range [20094,20099]
                trailer [20099,20106]
                    arglist [20100,20105]
                        number: 0 [20100,20101]
                        operator: , [20101,20102]
                        number: 10 [20103,20105]
            suite [20107,20233]
                simple_stmt [20120,20141]
                    atom_expr [20120,20140]
                        name: ti [20120,20122]
                        trailer [20122,20138]
                            name: refresh_from_db [20123,20138]
                        trailer [20138,20140]
                if_stmt [20153,20205]
                    comparison [20156,20181]
                        atom_expr [20156,20164]
                            name: ti [20156,20158]
                            trailer [20158,20164]
                                name: state [20159,20164]
                        operator: == [20165,20167]
                        atom_expr [20168,20181]
                            name: State [20168,20173]
                            trailer [20173,20181]
                                name: RUNNING [20174,20181]
                    suite [20182,20205]
                        simple_stmt [20199,20205]
                simple_stmt [20217,20233]
                    atom_expr [20217,20232]
                        name: time [20217,20221]
                        trailer [20221,20227]
                            name: sleep [20222,20227]
                        trailer [20227,20232]
                            number: 0.2 [20228,20231]
        simple_stmt [20241,20274]
            assert_stmt [20241,20273]
                comparison [20248,20273]
                    atom_expr [20248,20256]
                        name: ti [20248,20250]
                        trailer [20250,20256]
                            name: state [20251,20256]
                    operator: == [20257,20259]
                    atom_expr [20260,20273]
                        name: State [20260,20265]
                        trailer [20265,20273]
                            name: RUNNING [20266,20273]
        simple_stmt [20282,20314]
            atom_expr [20282,20313]
                name: os [20282,20284]
                trailer [20284,20289]
                    name: kill [20285,20289]
                trailer [20289,20313]
                    arglist [20290,20312]
                        atom_expr [20290,20296]
                            name: ti [20290,20292]
                            trailer [20292,20296]
                                name: pid [20293,20296]
                        operator: , [20296,20297]
                        atom_expr [20298,20312]
                            name: signal [20298,20304]
                            trailer [20304,20312]
                                name: SIGTERM [20305,20312]
        simple_stmt [20322,20347]
            atom_expr [20322,20346]
                name: process [20322,20329]
                trailer [20329,20334]
                    name: join [20330,20334]
                trailer [20334,20346]
                    argument [20335,20345]
                        name: timeout [20335,20342]
                        operator: = [20342,20343]
                        number: 10 [20343,20345]
        simple_stmt [20355,20397]
            assert_stmt [20355,20396]
                comparison [20362,20396]
                    atom_expr [20362,20391]
                        name: failure_callback_called [20362,20385]
                        trailer [20385,20391]
                            name: value [20386,20391]
                    operator: == [20392,20394]
                    number: 1 [20395,20396]
        simple_stmt [20405,20450]
            assert_stmt [20405,20449]
                comparison [20412,20449]
                    atom_expr [20412,20444]
                        name: task_terminated_externally [20412,20438]
                        trailer [20438,20444]
                            name: value [20439,20444]
                    operator: == [20445,20447]
                    number: 1 [20448,20449]
        simple_stmt [20458,20488]
            assert_stmt [20458,20487]
                not_test [20465,20487]
                    atom_expr [20469,20487]
                        name: process [20469,20476]
                        trailer [20476,20485]
                            name: is_alive [20477,20485]
                        trailer [20485,20487]
to
decorated [18424,20893]
at 1
===
insert-tree
---
simple_stmt [4173,4187]
    expr_stmt [4173,4186]
        atom_expr [4173,4180]
            name: ti [4173,4175]
            trailer [4175,4180]
                name: task [4176,4180]
        operator: = [4181,4182]
        name: op1 [4183,4186]
to
suite [3453,4668]
at 10
===
insert-tree
---
simple_stmt [4195,4221]
    atom_expr [4195,4220]
        name: ti [4195,4197]
        trailer [4197,4215]
            name: refresh_from_task [4198,4215]
        trailer [4215,4220]
            name: op1 [4216,4219]
to
suite [3453,4668]
at 11
===
insert-tree
---
simple_stmt [4229,4273]
    expr_stmt [4229,4272]
        atom_expr [4229,4245]
            name: job1 [4229,4233]
            trailer [4233,4245]
                name: task_runner [4234,4245]
        operator: = [4246,4247]
        atom_expr [4248,4272]
            name: StandardTaskRunner [4248,4266]
            trailer [4266,4272]
                name: job1 [4267,4271]
to
suite [3453,4668]
at 12
===
insert-tree
---
simple_stmt [4281,4320]
    expr_stmt [4281,4319]
        atom_expr [4281,4305]
            name: job1 [4281,4285]
            trailer [4285,4297]
                name: task_runner [4286,4297]
            trailer [4297,4305]
                name: process [4298,4305]
        operator: = [4306,4307]
        atom_expr [4308,4319]
            name: mock [4308,4312]
            trailer [4312,4317]
                name: Mock [4313,4317]
            trailer [4317,4319]
to
suite [3453,4668]
at 13
===
insert-tree
---
simple_stmt [4636,4665]
    assert_stmt [4636,4664]
        comparison [4643,4664]
            atom_expr [4643,4649]
                name: ti [4643,4645]
                trailer [4645,4649]
                    name: pid [4646,4649]
            operator: != [4650,4652]
            atom_expr [4653,4664]
                name: os [4653,4655]
                trailer [4655,4662]
                    name: getpid [4656,4662]
                trailer [4662,4664]
to
suite [3453,4668]
at 21
===
insert-node
---
atom [18455,18528]
to
decorator [18424,18535]
at 2
===
update-node
---
name: test_process_kill_call_on_failure_callback [18217,18259]
replace test_process_kill_call_on_failure_callback by test_process_kill_calls_on_failure_callback
===
insert-tree
---
parameters [18586,18605]
    param [18587,18592]
        name: self [18587,18591]
        operator: , [18591,18592]
    param [18593,18604]
        name: signal_type [18593,18604]
to
funcdef [18213,20488]
at 1
===
insert-node
---
testlist_comp [18469,18518]
to
atom [18455,18528]
at 0
===
insert-tree
---
simple_stmt [20656,20682]
    assert_stmt [20656,20681]
        comparison [20663,20681]
            atom_expr [20663,20669]
                name: ti [20663,20665]
                trailer [20665,20669]
                    name: pid [20666,20669]
            comp_op [20670,20676]
to
suite [18266,20488]
at 20
===
insert-node
---
atom [18469,18486]
to
testlist_comp [18469,18518]
at 0
===
update-node
---
string: """         Test that ensures that when a task is killed with sigterm         on_failure_callback gets executed         """ [18275,18398]
replace """         Test that ensures that when a task is killed with sigterm         on_failure_callback gets executed         """ by """         Test that ensures that when a task is killed with sigterm or sigkill         on_failure_callback gets executed         """
===
update-node
---
name: mock_pid [4294,4302]
replace mock_pid by job1
===
insert-tree
---
trailer [4471,4479]
    name: process [4472,4479]
to
atom_expr [4294,4315]
at 2
===
insert-tree
---
trailer [4479,4483]
    name: pid [4480,4483]
to
atom_expr [4294,4315]
at 3
===
update-node
---
name: mock_pid [4516,4524]
replace mock_pid by job1
===
insert-tree
---
trailer [4736,4744]
    name: process [4737,4744]
to
atom_expr [4516,4537]
at 2
===
insert-tree
---
trailer [4744,4748]
    name: pid [4745,4748]
to
atom_expr [4516,4537]
at 3
===
insert-node
---
testlist_comp [18470,18485]
to
atom [18469,18486]
at 0
===
update-node
---
name: return_value [4303,4315]
replace return_value by task_runner
===
update-node
---
name: return_value [4525,4537]
replace return_value by task_runner
===
move-tree
---
atom_expr [20298,20312]
    name: signal [20298,20304]
    trailer [20304,20312]
        name: SIGTERM [20305,20312]
to
testlist_comp [18470,18485]
at 0
===
insert-node
---
and_test [20507,20555]
to
if_stmt [20153,20205]
at 0
===
update-node
---
number: 10 [20103,20105]
replace 10 by 20
===
move-tree
---
comparison [20156,20181]
    atom_expr [20156,20164]
        name: ti [20156,20158]
        trailer [20158,20164]
            name: state [20159,20164]
    operator: == [20165,20167]
    atom_expr [20168,20181]
        name: State [20168,20173]
        trailer [20173,20181]
            name: RUNNING [20174,20181]
to
and_test [20507,20555]
at 0
===
insert-node
---
comparison [20537,20555]
to
and_test [20507,20555]
at 1
===
insert-tree
---
atom_expr [20698,20704]
    name: ti [20698,20700]
    trailer [20700,20704]
        name: pid [20701,20704]
to
arglist [20290,20312]
at 0
===
insert-node
---
name: signal_type [20706,20717]
to
arglist [20290,20312]
at 3
===
update-node
---
number: 13 [21445,21447]
replace 13 by 15
===
move-tree
---
atom_expr [20290,20296]
    name: ti [20290,20292]
    trailer [20292,20296]
        name: pid [20293,20296]
to
comparison [20537,20555]
at 0
===
delete-node
---
name: TestLocalTaskJob [2014,2030]
===
===
delete-tree
---
parameters [3436,3452]
    param [3437,3442]
        name: self [3437,3441]
        operator: , [3441,3442]
    param [3443,3451]
        name: mock_pid [3443,3451]
===
delete-node
---
decorated [3381,4668]
===
