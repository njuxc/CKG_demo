===
match
---
operator: ** [2398,2400]
operator: ** [2388,2390]
===
match
---
dotted_name [1243,1262]
dotted_name [1233,1252]
===
match
---
atom_expr [2441,2457]
atom_expr [2431,2447]
===
match
---
string: "Received SIGTERM. Terminating subprocesses" [2641,2685]
string: "Received SIGTERM. Terminating subprocesses" [2631,2675]
===
match
---
param [1501,1531]
param [1491,1521]
===
match
---
simple_stmt [4509,4901]
simple_stmt [4499,4891]
===
match
---
dotted_name [1193,1214]
dotted_name [1183,1204]
===
match
---
name: warning [7959,7966]
name: warning [8193,8200]
===
match
---
arglist [3175,3205]
arglist [3165,3195]
===
match
---
name: self [3470,3474]
name: self [3460,3464]
===
match
---
suite [5982,6010]
suite [5972,6000]
===
match
---
trailer [2381,2390]
trailer [2371,2380]
===
match
---
trailer [2782,2796]
trailer [2772,2786]
===
match
---
name: self [5995,5999]
name: self [5985,5989]
===
match
---
trailer [7282,7457]
trailer [7476,7651]
===
match
---
operator: = [2148,2149]
operator: = [2138,2139]
===
match
---
tfpdef [1626,1647]
tfpdef [1616,1637]
===
match
---
suite [1306,8649]
suite [1296,8883]
===
match
---
expr_stmt [2061,2099]
expr_stmt [2051,2089]
===
match
---
tfpdef [1501,1522]
tfpdef [1491,1512]
===
match
---
comparison [7107,7132]
comparison [7301,7326]
===
match
---
name: task_instance [6524,6537]
name: task_instance [6718,6731]
===
match
---
trailer [5607,5612]
trailer [5597,5602]
===
match
---
param [2426,2430]
param [2416,2420]
===
match
---
name: min [4616,4619]
name: min [4606,4609]
===
match
---
trailer [2390,2407]
trailer [2380,2397]
===
match
---
name: time_since_last_heartbeat [5895,5920]
name: time_since_last_heartbeat [5885,5910]
===
match
---
atom_expr [2810,2824]
atom_expr [2800,2814]
===
match
---
name: self [6470,6474]
name: self [6664,6668]
===
match
---
simple_stmt [6077,6134]
simple_stmt [6067,6124]
===
match
---
trailer [8629,8641]
trailer [8863,8875]
===
match
---
atom_expr [8101,8129]
atom_expr [8335,8363]
===
match
---
name: return_code [7874,7885]
name: return_code [8108,8119]
===
match
---
name: signal [3168,3174]
name: signal [3158,3164]
===
match
---
name: ti [7604,7606]
name: ti [7815,7817]
===
match
---
trailer [4848,4858]
trailer [4838,4848]
===
match
---
string: "exceeded limit ({}s)." [5864,5887]
string: "exceeded limit ({}s)." [5854,5877]
===
match
---
name: task_instance [1464,1477]
name: task_instance [1454,1467]
===
match
---
import_name [800,813]
import_name [790,803]
===
match
---
atom_expr [8625,8641]
atom_expr [8859,8875]
===
match
---
name: self [2476,2480]
name: self [2466,2470]
===
match
---
simple_stmt [1311,1359]
simple_stmt [1301,1349]
===
match
---
trailer [7496,7537]
trailer [7690,7731]
===
match
---
expr_stmt [1818,1852]
expr_stmt [1808,1842]
===
match
---
trailer [3281,3608]
trailer [3271,3598]
===
match
---
operator: , [1801,1802]
operator: , [1791,1792]
===
match
---
simple_stmt [2726,2763]
simple_stmt [2716,2753]
===
match
---
operator: = [3520,3521]
operator: = [3510,3511]
===
match
---
name: SUCCESS [8163,8170]
name: SUCCESS [8397,8404]
===
match
---
operator: , [5920,5921]
operator: , [5910,5911]
===
match
---
trailer [1908,1924]
trailer [1898,1914]
===
match
---
if_stmt [8142,8526]
if_stmt [8376,8760]
===
match
---
name: RUNNING [7125,7132]
name: RUNNING [7319,7326]
===
match
---
simple_stmt [5103,5110]
simple_stmt [5093,5100]
===
match
---
name: task_runner [1075,1086]
name: task_runner [1065,1076]
===
match
---
name: total_seconds [4770,4783]
name: total_seconds [4760,4773]
===
match
---
name: refresh_from_db [7045,7060]
name: refresh_from_db [7239,7254]
===
match
---
trailer [4783,4785]
trailer [4773,4775]
===
match
---
name: taskinstance [992,1004]
name: taskinstance [982,994]
===
match
---
operator: = [8642,8643]
operator: = [8876,8877]
===
match
---
name: task [1070,1074]
name: task [1060,1064]
===
match
---
import_from [972,1024]
import_from [962,1014]
===
match
---
atom_expr [7480,7537]
atom_expr [7674,7731]
===
match
---
string: "Terminating instance." [8041,8064]
string: "Terminating instance." [8275,8298]
===
match
---
operator: != [6432,6434]
operator: != [6626,6628]
===
match
---
simple_stmt [1951,2004]
simple_stmt [1941,1994]
===
match
---
name: log [7955,7958]
name: log [8189,8192]
===
match
---
operator: - [4745,4746]
operator: - [4735,4736]
===
match
---
string: "does not match this instance's hostname " [7332,7374]
string: "does not match this instance's hostname " [7526,7568]
===
match
---
trailer [5894,5943]
trailer [5884,5933]
===
match
---
atom_expr [7791,7843]
atom_expr [8025,8077]
===
match
---
param [1450,1455]
param [1440,1445]
===
match
---
name: latest_heartbeat [5479,5495]
name: latest_heartbeat [5469,5485]
===
match
---
arglist [7304,7439]
arglist [7498,7633]
===
match
---
expr_stmt [4918,4983]
expr_stmt [4908,4973]
===
match
---
expr_stmt [7180,7215]
expr_stmt [7374,7409]
===
match
---
name: ignore_task_deps [2017,2033]
name: ignore_task_deps [2007,2023]
===
match
---
name: pickle_id [2150,2159]
name: pickle_id [2140,2149]
===
match
---
name: airflow [1115,1122]
name: airflow [1105,1112]
===
match
---
expr_stmt [6383,6395]
expr_stmt [6373,6385]
===
match
---
atom_expr [7026,7062]
atom_expr [7220,7256]
===
match
---
simple_stmt [5685,5734]
simple_stmt [5675,5724]
===
match
---
name: set_state [2861,2870]
name: set_state [2851,2860]
===
match
---
name: getpid [7568,7574]
name: task_runner [7764,7775]
===
match
---
atom_expr [8157,8170]
atom_expr [8391,8404]
===
match
---
simple_stmt [6519,6610]
simple_stmt [6713,6804]
===
match
---
simple_stmt [7026,7063]
simple_stmt [7220,7257]
===
match
---
suite [8171,8201]
suite [8405,8435]
===
match
---
trailer [2634,2640]
trailer [2624,2630]
===
match
---
name: mark_success [3313,3325]
name: mark_success [3303,3315]
===
match
---
name: pool [3593,3597]
name: pool [3583,3587]
===
match
---
atom_expr [4525,4900]
atom_expr [4515,4890]
===
match
---
name: deserialize_run_error [6487,6508]
name: deserialize_run_error [6681,6702]
===
match
---
if_stmt [7638,7844]
if_stmt [7849,8078]
===
match
---
name: airflow [1030,1037]
name: airflow [1020,1027]
===
match
---
trailer [2445,2457]
trailer [2435,2447]
===
match
---
atom_expr [2726,2762]
atom_expr [2716,2752]
===
match
---
simple_stmt [7675,7769]
simple_stmt [7909,8003]
===
match
---
operator: = [6566,6567]
operator: = [6760,6761]
===
match
---
atom_expr [7675,7768]
atom_expr [7909,8002]
===
match
---
suite [7133,7844]
suite [7327,8078]
===
match
---
try_stmt [3694,6010]
try_stmt [3684,6000]
===
match
---
name: start [3728,3733]
name: start [3718,3723]
===
match
---
suite [2432,6010]
suite [2422,6000]
===
match
---
name: heartbeat_callback [6738,6756]
name: heartbeat_callback [6932,6950]
===
match
---
name: signal [807,813]
name: signal [797,803]
===
match
---
name: return_code [4949,4960]
name: return_code [4939,4950]
===
match
---
name: _run_finished_callback [8541,8563]
name: _run_finished_callback [8775,8797]
===
match
---
name: airflow [1243,1250]
name: airflow [1233,1240]
===
match
---
tfpdef [1586,1608]
tfpdef [1576,1598]
===
match
---
name: ti [7204,7206]
name: ti [7398,7400]
===
match
---
suite [2825,2885]
suite [2815,2875]
===
match
---
name: error [6567,6572]
name: error [6761,6766]
===
match
---
name: bool [1564,1568]
name: bool [1554,1558]
===
match
---
trailer [2379,2381]
trailer [2369,2371]
===
match
---
name: self [6407,6411]
name: self [6601,6605]
===
match
---
name: fqdn [7146,7150]
name: fqdn [7340,7344]
===
match
---
trailer [6230,6246]
trailer [6220,6236]
===
match
---
atom_expr [5685,5733]
atom_expr [5675,5723]
===
match
---
atom_expr [1818,1836]
atom_expr [1808,1826]
===
match
---
name: id [3567,3569]
name: id [3557,3559]
===
match
---
funcdef [2413,6010]
funcdef [2403,6000]
===
match
---
name: self [3562,3566]
name: self [3552,3556]
===
match
---
name: signal [3161,3167]
name: signal [3151,3157]
===
match
---
name: error [5694,5699]
name: error [5684,5689]
===
match
---
trailer [7954,7958]
trailer [8188,8192]
===
match
---
name: TaskInstance [1479,1491]
name: TaskInstance [1469,1481]
===
match
---
simple_stmt [882,930]
simple_stmt [872,920]
===
match
---
simple_stmt [3048,3111]
simple_stmt [3038,3101]
===
match
---
argument [2391,2396]
argument [2381,2386]
===
match
---
arglist [7692,7767]
arglist [7926,8001]
===
match
---
trailer [7907,7936]
trailer [8141,8170]
===
match
---
dotted_name [1150,1167]
dotted_name [1140,1157]
===
match
---
name: self [2133,2137]
name: self [2123,2127]
===
match
---
atom_expr [7604,7610]
atom_expr [7815,7821]
===
match
---
name: error [6383,6388]
name: error [6373,6378]
===
match
---
name: task_runner [8106,8117]
name: task_runner [8340,8351]
===
match
---
name: max_wait_time [4969,4982]
name: max_wait_time [4959,4972]
===
match
---
trailer [7403,7412]
trailer [7597,7606]
===
match
---
simple_stmt [8625,8649]
simple_stmt [8859,8883]
===
match
---
name: ignore_depends_on_past [1956,1978]
name: ignore_depends_on_past [1946,1968]
===
match
---
name: self [4747,4751]
name: self [4737,4741]
===
match
---
name: typing [819,825]
name: typing [809,815]
===
match
---
trailer [1720,1725]
trailer [1710,1715]
===
match
---
trailer [7030,7044]
trailer [7224,7238]
===
match
---
atom_expr [3622,3665]
atom_expr [3612,3655]
===
match
---
name: state [8148,8153]
name: state [8382,8387]
===
match
---
expr_stmt [7071,7094]
expr_stmt [7265,7288]
===
match
---
dictorsetmaker [1383,1421]
dictorsetmaker [1373,1411]
===
match
---
name: kwargs [2400,2406]
name: kwargs [2390,2396]
===
match
---
trailer [3630,3635]
trailer [3620,3625]
===
match
---
trailer [3715,3727]
trailer [3705,3717]
===
match
---
suite [6892,7017]
suite [7086,7211]
===
match
---
trailer [4948,4960]
trailer [4938,4950]
===
match
---
atom_expr [7076,7094]
atom_expr [7270,7288]
===
match
---
name: TaskInstance [1012,1024]
name: TaskInstance [1002,1014]
===
match
---
suite [6777,8649]
suite [6971,8883]
===
match
---
suite [2567,3111]
suite [2557,3101]
===
match
---
simple_stmt [2108,2125]
simple_stmt [2098,2115]
===
match
---
operator: = [3354,3355]
operator: = [3344,3345]
===
match
---
string: 'local_task_job_prolonged_heartbeat_failure' [5613,5657]
string: 'local_task_job_prolonged_heartbeat_failure' [5603,5647]
===
match
---
import_from [1188,1237]
import_from [1178,1227]
===
match
---
atom_expr [3711,3735]
atom_expr [3701,3725]
===
match
---
operator: , [3325,3326]
operator: , [3315,3316]
===
match
---
name: __mapper_args__ [1364,1379]
name: __mapper_args__ [1354,1369]
===
match
---
parameters [6756,6776]
parameters [6950,6970]
===
match
---
trailer [5462,5469]
trailer [5452,5459]
===
match
---
expr_stmt [2012,2052]
expr_stmt [2002,2042]
===
match
---
name: terminating [2345,2356]
name: terminating [2335,2346]
===
match
---
name: heartrate [4849,4858]
name: heartrate [4839,4848]
===
match
---
simple_stmt [814,842]
simple_stmt [804,832]
===
match
---
arith_expr [5454,5495]
arith_expr [5444,5485]
===
match
---
operator: , [1616,1617]
operator: , [1606,1607]
===
match
---
trailer [3312,3325]
trailer [3302,3315]
===
match
---
and_test [7857,7936]
and_test [8091,8170]
===
match
---
atom_expr [3470,3491]
atom_expr [3460,3481]
===
match
---
name: deserialize_run_error [8464,8485]
name: deserialize_run_error [8698,8719]
===
match
---
name: self [2726,2730]
name: self [2716,2720]
===
match
---
name: self [1450,1454]
name: self [1440,1444]
===
match
---
simple_stmt [6969,6998]
simple_stmt [7163,7192]
===
match
---
name: self [7950,7954]
name: self [8184,8188]
===
match
---
atom_expr [5048,5082]
atom_expr [5038,5072]
===
match
---
simple_stmt [1188,1238]
simple_stmt [1178,1228]
===
match
---
name: self [7857,7861]
name: self [8091,8095]
===
match
---
import_from [1025,1056]
import_from [1015,1046]
===
match
---
atom_expr [4727,4744]
atom_expr [4717,4734]
===
match
---
operator: , [4858,4859]
operator: , [4848,4849]
===
match
---
operator: == [7611,7613]
operator: == [7822,7824]
===
match
---
import_from [843,881]
import_from [833,871]
===
match
---
atom_expr [6679,6707]
atom_expr [6873,6901]
===
match
---
trailer [6646,6658]
trailer [6840,6852]
===
match
---
atom_expr [5760,5965]
atom_expr [5750,5955]
===
match
---
name: bool [1643,1647]
name: bool [1633,1637]
===
match
---
trailer [2703,2711]
trailer [2693,2701]
===
match
---
atom_expr [2778,2802]
atom_expr [2768,2792]
===
match
---
name: airflow [1150,1157]
name: airflow [1140,1147]
===
match
---
trailer [8117,8127]
trailer [8351,8361]
===
match
---
atom_expr [2061,2081]
atom_expr [2051,2071]
===
match
---
simple_stmt [3622,3666]
simple_stmt [3612,3656]
===
match
---
name: State [1270,1275]
name: State [1260,1265]
===
match
---
trailer [6007,6009]
trailer [5997,5999]
===
match
---
name: latest_heartbeat [4752,4768]
name: latest_heartbeat [4742,4758]
===
match
---
name: self [2012,2016]
name: self [2002,2006]
===
match
---
name: utils [1158,1163]
name: utils [1148,1153]
===
match
---
dotted_name [935,956]
dotted_name [925,946]
===
match
---
trailer [3635,3665]
trailer [3625,3655]
===
match
---
trailer [4619,4881]
trailer [4609,4871]
===
match
---
atom_expr [7565,7576]
atom_expr [7759,7787]
===
match
---
expr_stmt [7589,7625]
expr_stmt [7800,7836]
===
match
---
name: on_kill [6619,6626]
name: on_kill [6813,6820]
===
match
---
trailer [4742,4744]
trailer [4732,4734]
===
match
---
name: self [6875,6879]
name: self [7069,7073]
===
match
---
trailer [6973,6985]
trailer [7167,7179]
===
match
---
operator: = [3587,3588]
operator: = [3577,3578]
===
match
---
trailer [7060,7062]
trailer [7254,7256]
===
match
---
operator: = [8445,8446]
operator: = [8679,8680]
===
match
---
operator: , [1783,1784]
operator: , [1773,1774]
===
match
---
name: bool [1518,1522]
name: bool [1508,1512]
===
match
---
name: hostname [7207,7215]
name: hostname [7401,7409]
===
match
---
trailer [7109,7115]
trailer [7303,7309]
===
match
---
simple_stmt [1861,1896]
simple_stmt [1851,1886]
===
match
---
expr_stmt [4509,4900]
expr_stmt [4499,4890]
===
match
---
name: log [7680,7683]
name: log [7914,7917]
===
match
---
name: models [985,991]
name: models [975,981]
===
match
---
name: info [6151,6155]
name: info [6141,6145]
===
match
---
name: Optional [1748,1756]
name: Optional [1738,1746]
===
match
---
argument [3583,3597]
argument [3573,3587]
===
match
---
name: self [3588,3592]
name: self [3578,3582]
===
match
---
name: refresh_from_db [2745,2760]
name: refresh_from_db [2735,2750]
===
match
---
name: utils [1123,1128]
name: utils [1113,1118]
===
match
---
name: task_instance [1875,1888]
name: task_instance [1865,1878]
===
match
---
trailer [2213,2225]
trailer [2203,2215]
===
match
---
name: log [3627,3630]
name: log [3617,3620]
===
match
---
simple_stmt [5754,5966]
simple_stmt [5744,5956]
===
match
---
name: task_runner [6475,6486]
name: task_runner [6669,6680]
===
match
---
trailer [8540,8563]
trailer [8774,8797]
===
match
---
name: error [2992,2997]
name: error [2982,2987]
===
match
---
atom_expr [3412,3439]
atom_expr [3402,3429]
===
match
---
name: mark_success [3295,3307]
name: mark_success [3285,3297]
===
match
---
name: pickle_id [2138,2147]
name: pickle_id [2128,2137]
===
match
---
name: same_hostname [7235,7248]
name: same_hostname [7429,7442]
===
match
---
operator: = [2118,2119]
operator: = [2108,2109]
===
match
---
atom_expr [4726,4785]
atom_expr [4716,4775]
===
match
---
name: return_code [5070,5081]
name: return_code [5060,5071]
===
match
---
raise_stmt [7474,7537]
raise_stmt [7668,7731]
===
match
---
decorator [6713,6730]
decorator [6907,6924]
===
match
---
raise_stmt [7785,7843]
raise_stmt [8019,8077]
===
match
---
name: bool [1604,1608]
name: bool [1594,1598]
===
match
---
operator: = [2997,2998]
operator: = [2987,2988]
===
match
---
name: SIGTERM [3182,3189]
name: SIGTERM [3172,3179]
===
match
---
funcdef [2533,3111]
funcdef [2523,3101]
===
match
---
name: ignore_depends_on_past [3417,3439]
name: ignore_depends_on_past [3407,3429]
===
match
---
name: hasattr [7900,7907]
name: hasattr [8134,8141]
===
match
---
param [1540,1577]
param [1530,1567]
===
match
---
operator: , [1454,1455]
operator: , [1444,1445]
===
match
---
trailer [7885,7887]
trailer [8119,8121]
===
match
---
parameters [1440,1808]
parameters [1430,1798]
===
match
---
atom_expr [2842,2884]
atom_expr [2832,2874]
===
match
---
while_stmt [4262,5966]
while_stmt [4252,5956]
===
match
---
name: conf [3772,3776]
name: conf [3762,3766]
===
match
---
name: self [5048,5052]
name: self [5038,5042]
===
match
---
suite [6633,6708]
suite [6827,6902]
===
match
---
comparison [5003,5026]
comparison [4993,5016]
===
match
---
trailer [5478,5495]
trailer [5468,5485]
===
match
---
expr_stmt [1904,1942]
expr_stmt [1894,1932]
===
match
---
trailer [7080,7094]
trailer [7274,7288]
===
match
---
name: task_instance [1839,1852]
name: task_instance [1829,1842]
===
match
---
suite [4289,5966]
suite [4279,5956]
===
match
---
name: self [2108,2112]
name: self [2098,2102]
===
match
---
trailer [8463,8485]
trailer [8697,8719]
===
match
---
name: pid [7751,7754]
name: pid [7985,7988]
===
match
---
name: timezone [5454,5462]
name: timezone [5444,5452]
===
match
---
trailer [2915,2938]
trailer [2905,2928]
===
match
---
param [1665,1692]
param [1655,1682]
===
match
---
name: ignore_ti_state [1626,1641]
name: ignore_ti_state [1616,1631]
===
match
---
name: log [5690,5693]
name: log [5680,5683]
===
match
---
trailer [5699,5733]
trailer [5689,5723]
===
match
---
name: self [4932,4936]
name: self [4922,4926]
===
match
---
name: self [1904,1908]
name: self [1894,1898]
===
match
---
name: super [2374,2379]
name: super [2364,2369]
===
match
---
string: "LocalTaskJob received SIGTERM signal" [3071,3109]
string: "LocalTaskJob received SIGTERM signal" [3061,3099]
===
match
---
name: state [1257,1262]
name: state [1247,1252]
===
match
---
trailer [7861,7873]
trailer [8095,8107]
===
match
---
name: fqdn [7196,7200]
name: fqdn [7390,7394]
===
match
---
argument [3505,3541]
argument [3495,3531]
===
match
---
comparison [2778,2824]
comparison [2768,2814]
===
match
---
name: ti [7401,7403]
name: ti [7595,7597]
===
match
---
name: same_process [7645,7657]
name: same_process [7879,7891]
===
match
---
parameters [6626,6632]
parameters [6820,6826]
===
match
---
trailer [7679,7683]
trailer [7913,7917]
===
match
---
trailer [6216,6230]
trailer [6206,6220]
===
match
---
simple_stmt [7589,7626]
simple_stmt [7800,7837]
===
match
---
name: __init__ [1432,1440]
name: __init__ [1422,1430]
===
match
---
param [1586,1617]
param [1576,1607]
===
match
---
name: self [6642,6646]
name: self [6836,6840]
===
match
---
operator: = [1684,1685]
operator: = [1674,1675]
===
match
---
trailer [6668,6670]
trailer [6862,6864]
===
match
---
expr_stmt [2340,2364]
expr_stmt [2330,2354]
===
match
---
operator: , [6761,6762]
operator: , [6955,6956]
===
match
---
trailer [4528,4900]
trailer [4518,4890]
===
match
---
name: net [1164,1167]
name: net [1154,1157]
===
match
---
atom_expr [8066,8074]
atom_expr [8300,8308]
===
match
---
name: State [2810,2815]
name: State [2800,2805]
===
match
---
name: LocalTaskJob [1284,1296]
name: LocalTaskJob [1274,1286]
===
match
---
operator: , [1768,1769]
operator: , [1758,1759]
===
match
---
name: warning [7684,7691]
name: warning [7918,7925]
===
match
---
parameters [2551,2566]
parameters [2541,2556]
===
match
---
operator: , [1530,1531]
operator: , [1520,1521]
===
match
---
operator: , [1655,1656]
operator: , [1645,1646]
===
match
---
string: "PID of job runner does not match" [7808,7842]
string: "PID of job runner does not match" [8042,8076]
===
match
---
argument [3555,3569]
argument [3545,3559]
===
match
---
name: mark_success [2188,2200]
name: mark_success [2178,2190]
===
match
---
name: task_runner [3716,3727]
name: task_runner [3706,3717]
===
match
---
expr_stmt [8188,8200]
expr_stmt [8422,8434]
===
match
---
atom_expr [1748,1761]
atom_expr [1738,1751]
===
match
---
atom_expr [2897,3035]
atom_expr [2887,3025]
===
match
---
trailer [3566,3569]
trailer [3556,3559]
===
match
---
simple_stmt [2580,2614]
simple_stmt [2570,2604]
===
match
---
arglist [5895,5942]
arglist [5885,5932]
===
match
---
name: heartbeat_time_limit [5922,5942]
name: heartbeat_time_limit [5912,5932]
===
match
---
trailer [7966,8088]
trailer [8200,8322]
===
match
---
name: self [7266,7270]
name: self [7460,7464]
===
match
---
operator: > [5558,5559]
operator: > [5548,5549]
===
match
---
name: SUCCESS [6441,6448]
name: SUCCESS [6635,6642]
===
match
---
name: airflow [1193,1200]
name: airflow [1183,1190]
===
match
---
atom_expr [3588,3597]
atom_expr [3578,3587]
===
match
---
operator: -> [6060,6062]
operator: -> [6050,6052]
===
match
---
suite [6068,6610]
suite [6058,6804]
===
match
---
atom_expr [2626,2686]
atom_expr [2616,2676]
===
match
---
name: signum [2552,2558]
name: signum [2542,2548]
===
match
---
strings [5802,5887]
strings [5792,5877]
===
match
---
name: task_instance [3228,3241]
name: task_instance [3218,3231]
===
match
---
name: task_instance [7031,7044]
name: task_instance [7225,7238]
===
match
---
operator: , [1576,1577]
operator: , [1566,1567]
===
match
---
simple_stmt [6383,6396]
simple_stmt [6373,6386]
===
match
---
operator: = [7074,7075]
operator: = [7268,7269]
===
match
---
atom_expr [6470,6510]
atom_expr [6664,6704]
===
match
---
name: task_instance [7081,7094]
name: task_instance [7275,7288]
===
match
---
trailer [5693,5699]
trailer [5683,5689]
===
match
---
trailer [6705,6707]
trailer [6899,6901]
===
match
---
name: error [8564,8569]
name: error [8798,8803]
===
match
---
name: task_runner [7862,7873]
name: task_runner [8096,8107]
===
match
---
trailer [5131,5141]
trailer [5121,5131]
===
match
---
name: get_hostname [7153,7165]
name: get_hostname [7347,7359]
===
match
---
name: pool [2113,2117]
name: pool [2103,2107]
===
match
---
operator: , [5657,5658]
operator: , [5647,5648]
===
match
---
operator: = [7151,7152]
operator: = [7345,7346]
===
match
---
name: _run_finished_callback [6538,6560]
name: _run_finished_callback [6732,6754]
===
match
---
string: """Self destruct task if state has been moved away from running externally""" [6786,6863]
string: """Self destruct task if state has been moved away from running externally""" [6980,7057]
===
match
---
trailer [3733,3735]
trailer [3723,3725]
===
match
---
trailer [6695,6705]
trailer [6889,6899]
===
match
---
name: task_instance [6412,6425]
name: task_instance [6606,6619]
===
match
---
trailer [2796,2802]
trailer [2786,2792]
===
match
---
simple_stmt [1238,1276]
simple_stmt [1228,1266]
===
match
---
number: 0.75 [4788,4792]
number: 0.75 [4778,4782]
===
match
---
dotted_name [848,869]
dotted_name [838,859]
===
match
---
name: error [6561,6566]
name: error [6755,6760]
===
match
---
name: configuration [856,869]
name: configuration [846,859]
===
match
---
name: ti [8145,8147]
name: ti [8379,8381]
===
match
---
string: "%s" [7375,7379]
string: "%s" [7569,7573]
===
match
---
name: terminating [4277,4288]
name: terminating [4267,4278]
===
match
---
trailer [7606,7610]
trailer [7817,7821]
===
match
---
atom_expr [8145,8153]
atom_expr [8379,8387]
===
match
---
name: State [6435,6440]
name: State [6629,6634]
===
match
---
simple_stmt [843,882]
simple_stmt [833,872]
===
match
---
name: Stats [5602,5607]
name: Stats [5592,5597]
===
match
---
atom_expr [4932,4983]
atom_expr [4922,4973]
===
match
---
name: self [2699,2703]
name: self [2689,2693]
===
match
---
name: state [2797,2802]
name: state [2787,2792]
===
match
---
name: self [4844,4848]
name: self [4834,4838]
===
match
---
atom_expr [7153,7167]
atom_expr [7347,7361]
===
match
---
operator: * [2391,2392]
operator: * [2381,2382]
===
match
---
name: log [2631,2634]
name: log [2621,2624]
===
match
---
atom [5453,5496]
atom [5443,5486]
===
match
---
name: terminate [8118,8127]
name: terminate [8352,8361]
===
match
---
simple_stmt [2168,2201]
simple_stmt [2158,2191]
===
match
---
parameters [2425,2431]
parameters [2415,2421]
===
match
---
param [6627,6631]
param [6821,6825]
===
match
---
operator: = [2082,2083]
operator: = [2072,2073]
===
match
---
simple_stmt [2441,2482]
simple_stmt [2431,2472]
===
match
---
simple_stmt [972,1025]
simple_stmt [962,1015]
===
match
---
name: ignore_depends_on_past [1540,1562]
name: ignore_depends_on_past [1530,1552]
===
match
---
name: heartbeat_time_limit [3749,3769]
name: heartbeat_time_limit [3739,3759]
===
match
---
atom_expr [6642,6670]
atom_expr [6836,6864]
===
match
---
operator: = [2357,2358]
operator: = [2347,2348]
===
match
---
trailer [1888,1895]
trailer [1878,1885]
===
match
---
trailer [3776,3783]
trailer [3766,3773]
===
match
---
atom_expr [2108,2117]
atom_expr [2098,2107]
===
match
---
atom_expr [1951,1978]
atom_expr [1941,1968]
===
match
---
name: int [6055,6058]
name: int [6045,6048]
===
match
---
trailer [6411,6425]
trailer [6605,6619]
===
match
---
string: 'process' [7926,7935]
string: 'process' [8160,8169]
===
match
---
name: self [1951,1955]
name: self [1941,1945]
===
match
---
trailer [5069,5082]
trailer [5059,5072]
===
match
---
name: self [8447,8451]
name: self [8681,8685]
===
match
---
string: 'scheduler' [3784,3795]
string: 'scheduler' [3774,3785]
===
match
---
string: """LocalTaskJob runs a single task instance.""" [1311,1358]
string: """LocalTaskJob runs a single task instance.""" [1301,1348]
===
match
---
simple_stmt [1818,1853]
simple_stmt [1808,1843]
===
match
---
operator: , [4881,4882]
operator: , [4871,4872]
===
match
---
name: self [6519,6523]
name: self [6713,6717]
===
match
---
atom_expr [6435,6448]
atom_expr [6629,6642]
===
match
---
operator: = [8569,8570]
operator: = [8803,8804]
===
match
---
atom_expr [3308,3325]
atom_expr [3298,3315]
===
match
---
trailer [1822,1836]
trailer [1812,1826]
===
match
---
parameters [6035,6059]
parameters [6025,6049]
===
match
---
name: current_pid [7614,7625]
name: current_pid [7825,7836]
===
match
---
argument [6561,6572]
argument [6755,6766]
===
match
---
operator: = [1569,1570]
operator: = [1559,1560]
===
match
---
param [1464,1492]
param [1454,1482]
===
match
---
atom_expr [4272,4288]
atom_expr [4262,4278]
===
match
---
atom_expr [2168,2185]
atom_expr [2158,2175]
===
match
---
atom_expr [8538,8576]
atom_expr [8772,8810]
===
match
---
arglist [5613,5663]
arglist [5603,5653]
===
match
---
atom_expr [7748,7754]
atom_expr [7982,7988]
===
match
---
name: frame [2560,2565]
name: frame [2550,2555]
===
match
---
trailer [2172,2185]
trailer [2162,2175]
===
match
---
name: self [3308,3312]
name: self [3298,3302]
===
match
---
name: total_seconds [5497,5510]
name: total_seconds [5487,5500]
===
match
---
name: Optional [833,841]
name: Optional [823,831]
===
match
---
if_stmt [6872,7017]
if_stmt [7066,7211]
===
match
---
operator: = [1726,1727]
operator: = [1716,1717]
===
match
---
name: self [1818,1822]
name: self [1808,1812]
===
match
---
name: heartbeat_time_limit [5560,5580]
name: heartbeat_time_limit [5550,5570]
===
match
---
file_input [790,8649]
file_input [790,8883]
===
match
---
trailer [2815,2824]
trailer [2805,2814]
===
match
---
name: self [6969,6973]
name: self [7163,7167]
===
match
---
atom_expr [6875,6891]
atom_expr [7069,7085]
===
match
---
funcdef [6615,6708]
funcdef [6809,6902]
===
match
---
string: "Hostname of job runner does not match" [7497,7536]
string: "Hostname of job runner does not match" [7691,7730]
===
match
---
dotted_name [1115,1128]
dotted_name [1105,1118]
===
match
---
operator: = [7563,7564]
operator: = [7757,7758]
===
match
---
tfpdef [1665,1683]
tfpdef [1655,1673]
===
match
---
trailer [5999,6007]
trailer [5989,5997]
===
match
---
name: ignore_ti_state [3526,3541]
name: ignore_ti_state [3516,3531]
===
match
---
trailer [3359,3375]
trailer [3349,3365]
===
match
---
name: error [8570,8575]
name: error [8804,8809]
===
match
---
import_from [814,841]
import_from [804,831]
===
match
---
simple_stmt [7180,7216]
simple_stmt [7374,7410]
===
match
---
dotted_name [1062,1086]
dotted_name [1052,1076]
===
match
---
suite [7658,7844]
suite [7892,8078]
===
match
---
trailer [6537,6560]
trailer [6731,6754]
===
match
---
param [6763,6775]
param [6957,6969]
===
match
---
trailer [3727,3733]
trailer [3717,3723]
===
match
---
operator: , [1732,1733]
operator: , [1722,1723]
===
match
---
trailer [4735,4742]
trailer [4725,4732]
===
match
---
trailer [1756,1761]
trailer [1746,1751]
===
match
---
atom_expr [5474,5495]
atom_expr [5464,5485]
===
match
---
string: "the current pid %s" [7726,7746]
string: "the current pid %s" [7960,7980]
===
match
---
comparison [7857,7895]
comparison [8091,8129]
===
match
---
argument [2992,3021]
argument [2982,3011]
===
match
---
simple_stmt [1364,1423]
simple_stmt [1354,1413]
===
match
---
name: session [6763,6770]
name: session [6957,6964]
===
match
---
simple_stmt [8188,8201]
simple_stmt [8422,8435]
===
match
---
name: self [3622,3626]
name: self [3612,3616]
===
match
---
trailer [3416,3439]
trailer [3406,3429]
===
match
---
argument [4961,4982]
argument [4951,4972]
===
match
---
comparison [8145,8170]
comparison [8379,8404]
===
match
---
trailer [6486,6508]
trailer [6680,6702]
===
match
---
param [6757,6762]
param [6951,6956]
===
match
---
simple_stmt [6642,6671]
simple_stmt [6836,6865]
===
match
---
name: timezone [1136,1144]
name: timezone [1126,1134]
===
match
---
expr_stmt [2441,2481]
expr_stmt [2431,2471]
===
match
---
string: "Heartbeat time limit exceeded!" [5700,5732]
string: "Heartbeat time limit exceeded!" [5690,5722]
===
match
---
name: ignore_ti_state [2066,2081]
name: ignore_ti_state [2056,2071]
===
match
---
simple_stmt [2374,2408]
simple_stmt [2364,2398]
===
match
---
arglist [6156,6202]
arglist [6146,6192]
===
match
---
simple_stmt [6212,6249]
simple_stmt [6202,6239]
===
match
---
raise_stmt [3048,3110]
raise_stmt [3038,3100]
===
match
---
trailer [8105,8117]
trailer [8339,8351]
===
match
---
string: "task marked as failed externally" [8491,8525]
string: "task marked as failed externally" [8725,8759]
===
match
---
trailer [7044,7060]
trailer [7238,7254]
===
match
---
param [6042,6058]
param [6032,6048]
===
match
---
suite [1809,2408]
suite [1799,2398]
===
match
---
simple_stmt [7010,7017]
simple_stmt [7204,7211]
===
match
---
tfpdef [1540,1568]
tfpdef [1530,1558]
===
match
---
name: task_runner [6974,6985]
name: task_runner [7168,7179]
===
match
---
operator: , [2558,2559]
operator: , [2548,2549]
===
match
---
trailer [5510,5512]
trailer [5500,5502]
===
match
---
trailer [8485,8487]
trailer [8719,8721]
===
match
---
name: self [6679,6683]
name: self [6873,6877]
===
match
---
expr_stmt [2108,2124]
expr_stmt [2098,2114]
===
match
---
simple_stmt [7474,7538]
simple_stmt [7668,7732]
===
match
---
trailer [2640,2686]
trailer [2630,2676]
===
match
---
simple_stmt [7950,8089]
simple_stmt [8184,8323]
===
match
---
trailer [5689,5693]
trailer [5679,5683]
===
match
---
trailer [7574,7576]
trailer [7775,7783]
===
match
---
trailer [2137,2147]
trailer [2127,2137]
===
match
---
name: dag_id [1889,1895]
name: dag_id [1879,1885]
===
match
---
strings [7984,8064]
strings [8218,8298]
===
match
---
name: utils [1251,1256]
name: utils [1241,1246]
===
match
---
name: same_hostname [7180,7193]
name: same_hostname [7374,7387]
===
match
---
name: job_id [3555,3561]
name: job_id [3545,3551]
===
match
---
operator: } [1421,1422]
operator: } [1411,1412]
===
match
---
name: mark_success [1665,1677]
name: mark_success [1655,1667]
===
match
---
name: utcnow [5463,5469]
name: utcnow [5453,5459]
===
match
---
atom_expr [2460,2481]
atom_expr [2450,2471]
===
match
---
name: ignore_task_deps [3475,3491]
name: ignore_task_deps [3465,3481]
===
match
---
expr_stmt [5425,5512]
expr_stmt [5415,5502]
===
match
---
simple_stmt [2209,2233]
simple_stmt [2199,2223]
===
match
---
comparison [7196,7215]
comparison [7390,7409]
===
match
---
trailer [4751,4768]
trailer [4741,4758]
===
match
---
name: airflow [887,894]
name: airflow [877,884]
===
match
---
if_stmt [3216,3685]
if_stmt [3206,3675]
===
match
---
arglist [4550,4882]
arglist [4540,4872]
===
match
---
trailer [6440,6448]
trailer [6634,6642]
===
match
---
trailer [7873,7885]
trailer [8107,8119]
===
match
---
trailer [2630,2634]
trailer [2620,2624]
===
match
---
name: ignore_all_deps [1927,1942]
name: ignore_all_deps [1917,1932]
===
match
---
argument [2398,2406]
argument [2388,2396]
===
match
---
trailer [3525,3541]
trailer [3515,3531]
===
match
---
name: pool [1742,1746]
name: pool [1732,1736]
===
match
---
name: stats [1038,1043]
name: stats [1028,1033]
===
match
---
name: signal [3175,3181]
name: signal [3165,3171]
===
match
---
name: state [6426,6431]
name: state [6620,6625]
===
match
---
name: self [2778,2782]
name: self [2768,2772]
===
match
---
name: str [1721,1724]
name: str [1711,1714]
===
match
---
atom_expr [5995,6009]
atom_expr [5985,5999]
===
match
---
trailer [6150,6155]
trailer [6140,6145]
===
match
---
name: self [3223,3227]
name: self [3213,3217]
===
match
---
operator: = [6389,6390]
operator: = [6379,6380]
===
match
---
simple_stmt [2012,2053]
simple_stmt [2002,2043]
===
match
---
suite [6449,6511]
suite [6643,6705]
===
match
---
number: 1 [5659,5660]
number: 1 [5649,5650]
===
match
---
trailer [6425,6431]
trailer [6619,6625]
===
match
---
simple_stmt [6142,6204]
simple_stmt [6132,6194]
===
match
---
name: airflow [848,855]
name: airflow [838,845]
===
match
---
operator: = [1979,1980]
operator: = [1969,1970]
===
match
---
simple_stmt [1145,1188]
simple_stmt [1135,1178]
===
match
---
simple_stmt [1110,1145]
simple_stmt [1100,1135]
===
match
---
name: _run_finished_callback [2916,2938]
name: _run_finished_callback [2906,2928]
===
match
---
operator: = [2034,2035]
operator: = [2024,2025]
===
match
---
trailer [6146,6150]
trailer [6136,6140]
===
match
---
name: incr [5608,5612]
name: incr [5598,5602]
===
match
---
atom_expr [5127,5143]
atom_expr [5117,5133]
===
match
---
name: conf [877,881]
name: conf [867,871]
===
match
---
trailer [8147,8153]
trailer [8381,8387]
===
match
---
trailer [8451,8463]
trailer [8685,8697]
===
match
---
operator: , [3439,3440]
operator: , [3429,3430]
===
match
---
param [2560,2565]
param [2550,2555]
===
match
---
arglist [2391,2406]
arglist [2381,2396]
===
match
---
if_stmt [7104,8649]
if_stmt [7298,8883]
===
match
---
trailer [4960,4983]
trailer [4950,4973]
===
match
---
simple_stmt [3749,3832]
simple_stmt [3739,3822]
===
match
---
operator: , [7924,7925]
operator: , [8158,8159]
===
match
---
name: signal_handler [3191,3205]
name: signal_handler [3181,3195]
===
match
---
name: Optional [1712,1720]
name: Optional [1702,1710]
===
match
---
name: handle_task_exit [6019,6035]
name: handle_task_exit [6009,6025]
===
match
---
name: Stats [1051,1056]
name: Stats [1041,1046]
===
match
---
name: getint [3777,3783]
name: getint [3767,3773]
===
match
---
name: self [3711,3715]
name: self [3701,3705]
===
match
---
funcdef [6015,6610]
funcdef [6005,6804]
===
match
---
name: self [6142,6146]
name: self [6132,6136]
===
match
---
trailer [7958,7966]
trailer [8192,8200]
===
match
---
operator: , [6040,6041]
operator: , [6030,6031]
===
match
---
simple_stmt [3161,3207]
simple_stmt [3151,3197]
===
match
---
name: bool [1679,1683]
name: bool [1669,1673]
===
match
---
arglist [3784,3830]
arglist [3774,3820]
===
match
---
operator: = [8194,8195]
operator: = [8428,8429]
===
match
---
name: refresh_from_db [6231,6246]
name: refresh_from_db [6221,6236]
===
match
---
trailer [5469,5471]
trailer [5459,5461]
===
match
---
if_stmt [6404,6511]
if_stmt [6598,6705]
===
match
---
name: task_instance [1823,1836]
name: task_instance [1813,1826]
===
match
---
string: "Task exited with return code %s" [6156,6189]
string: "Task exited with return code %s" [6146,6179]
===
match
---
operator: = [3411,3412]
operator: = [3401,3402]
===
match
---
operator: = [1523,1524]
operator: = [1513,1514]
===
match
---
arith_expr [4727,4768]
arith_expr [4717,4758]
===
match
---
name: BaseJob [964,971]
name: BaseJob [954,961]
===
match
---
trailer [4936,4948]
trailer [4926,4938]
===
match
---
name: exceptions [895,905]
name: exceptions [885,895]
===
match
---
simple_stmt [800,814]
simple_stmt [790,804]
===
match
---
suite [5027,5110]
suite [5017,5100]
===
match
---
name: args [1779,1783]
name: args [1769,1773]
===
match
---
atom_expr [6142,6203]
atom_expr [6132,6193]
===
match
---
trailer [1955,1978]
trailer [1945,1968]
===
match
---
trailer [6246,6248]
trailer [6236,6238]
===
match
---
atom_expr [2340,2356]
atom_expr [2330,2346]
===
match
---
expr_stmt [1861,1895]
expr_stmt [1851,1885]
===
match
---
trailer [2475,2481]
trailer [2465,2471]
===
match
---
suite [7249,7538]
suite [7443,7732]
===
match
---
param [2552,2559]
param [2542,2549]
===
match
---
trailer [3070,3110]
trailer [3060,3100]
===
match
---
name: task_runner [7913,7924]
name: task_runner [8147,8158]
===
match
---
trailer [3181,3189]
trailer [3171,3179]
===
match
---
atom [1382,1422]
atom [1372,1412]
===
match
---
import_from [1110,1144]
import_from [1100,1134]
===
match
---
atom [4645,4818]
atom [4635,4808]
===
match
---
atom [4726,4769]
atom [4716,4759]
===
match
---
atom_expr [3054,3110]
atom_expr [3044,3100]
===
match
---
simple_stmt [8538,8613]
simple_stmt [8772,8847]
===
match
---
atom_expr [3562,3569]
atom_expr [3552,3559]
===
match
---
operator: , [3189,3190]
operator: , [3179,3180]
===
match
---
trailer [3626,3630]
trailer [3616,3620]
===
match
---
trailer [6879,6891]
trailer [7073,7085]
===
match
---
name: warning [7275,7282]
name: warning [7469,7476]
===
match
---
trailer [2744,2760]
trailer [2734,2750]
===
match
---
if_stmt [2775,2885]
if_stmt [2765,2875]
===
match
---
operator: = [4968,4969]
operator: = [4958,4959]
===
match
---
arglist [7908,7935]
arglist [8142,8169]
===
match
---
atom_expr [7107,7115]
atom_expr [7301,7309]
===
match
---
name: terminate [6986,6995]
name: terminate [7180,7189]
===
match
---
name: self [7675,7679]
name: self [7909,7913]
===
match
---
atom_expr [5802,5943]
atom_expr [5792,5933]
===
match
---
trailer [2938,3035]
trailer [2928,3025]
===
match
---
operator: = [7194,7195]
operator: = [7388,7389]
===
match
---
name: signal_handler [2537,2551]
name: signal_handler [2527,2541]
===
match
---
name: time_since_last_heartbeat [5532,5557]
name: time_since_last_heartbeat [5522,5547]
===
match
---
name: terminating [6880,6891]
name: terminating [7074,7085]
===
match
---
operator: = [1648,1649]
operator: = [1638,1639]
===
match
---
simple_stmt [1904,1943]
simple_stmt [1894,1933]
===
match
---
operator: = [1925,1926]
operator: = [1915,1916]
===
match
---
name: handle_task_exit [5053,5069]
name: handle_task_exit [5043,5059]
===
match
---
comp_op [2803,2809]
comp_op [2793,2799]
===
match
---
name: task_runner [6647,6658]
name: task_runner [6841,6852]
===
match
---
atom_expr [2133,2147]
atom_expr [2123,2137]
===
match
---
atom_expr [7950,8088]
atom_expr [8184,8322]
===
match
---
operator: = [4523,4524]
operator: = [4513,4514]
===
match
---
import_from [1145,1187]
import_from [1135,1177]
===
match
---
simple_stmt [3678,3685]
simple_stmt [3668,3675]
===
match
---
name: self [6757,6761]
name: self [6951,6955]
===
match
---
operator: == [7201,7203]
operator: == [7395,7397]
===
match
---
expr_stmt [8439,8525]
expr_stmt [8673,8759]
===
match
---
trailer [5776,5965]
trailer [5766,5955]
===
match
---
expr_stmt [7551,7576]
expr_stmt [7745,7787]
===
match
---
atom_expr [3223,3608]
atom_expr [3213,3598]
===
match
---
trailer [5141,5143]
trailer [5131,5133]
===
match
---
name: self [2842,2846]
name: self [2832,2836]
===
match
---
simple_stmt [2897,3036]
simple_stmt [2887,3026]
===
match
---
operator: - [4724,4725]
operator: - [4714,4715]
===
match
---
name: return_code [5003,5014]
name: return_code [4993,5004]
===
match
---
atom_expr [2699,2713]
atom_expr [2689,2703]
===
match
---
trailer [7206,7215]
trailer [7400,7409]
===
match
---
trailer [6508,6510]
trailer [6702,6704]
===
match
---
operator: = [2186,2187]
operator: = [2176,2177]
===
match
---
simple_stmt [8101,8130]
simple_stmt [8335,8364]
===
match
---
name: info [3631,3635]
name: info [3621,3625]
===
match
---
trailer [2846,2860]
trailer [2836,2850]
===
match
---
arglist [4645,4859]
arglist [4635,4849]
===
match
---
name: os [7565,7567]
name: self [7759,7763]
===
match
---
name: ignore_all_deps [1501,1516]
name: ignore_all_deps [1491,1506]
===
match
---
suite [5581,5966]
suite [5571,5956]
===
match
---
operator: , [7412,7413]
operator: , [7606,7607]
===
match
---
comparison [7604,7625]
comparison [7815,7836]
===
match
---
operator: , [3375,3376]
operator: , [3365,3366]
===
match
---
atom_expr [6519,6573]
atom_expr [6713,6767]
===
match
---
trailer [8068,8074]
trailer [8302,8308]
===
match
---
operator: , [3795,3796]
operator: , [3785,3786]
===
match
---
name: max_wait_time [4509,4522]
name: max_wait_time [4499,4512]
===
match
---
name: jobs [943,947]
name: jobs [933,937]
===
match
---
name: get_task_runner [2460,2475]
name: get_task_runner [2450,2465]
===
match
---
name: return_code [4918,4929]
name: return_code [4908,4919]
===
match
---
trailer [6985,6995]
trailer [7179,7189]
===
match
---
operator: == [7116,7118]
operator: == [7310,7312]
===
match
---
name: pool [2120,2124]
name: pool [2110,2114]
===
match
---
name: AirflowException [7480,7496]
name: AirflowException [7674,7690]
===
match
---
name: State [2871,2876]
name: State [2861,2866]
===
match
---
raise_stmt [5754,5965]
raise_stmt [5744,5955]
===
match
---
name: FAILED [2877,2883]
name: FAILED [2867,2873]
===
match
---
name: provide_session [1222,1237]
name: provide_session [1212,1227]
===
match
---
simple_stmt [2626,2687]
simple_stmt [2616,2677]
===
match
---
simple_stmt [6786,6864]
simple_stmt [6980,7058]
===
match
---
trailer [1865,1872]
trailer [1855,1862]
===
match
---
string: "Task is not able to be run" [3636,3664]
string: "Task is not able to be run" [3626,3654]
===
match
---
operator: == [8154,8156]
operator: == [8388,8390]
===
match
---
name: task_instance [2731,2744]
name: task_instance [2721,2734]
===
match
---
trailer [5612,5664]
trailer [5602,5654]
===
match
---
operator: , [7379,7380]
operator: , [7573,7574]
===
match
---
trailer [2760,2762]
trailer [2750,2752]
===
match
---
operator: , [1491,1492]
operator: , [1481,1482]
===
match
---
name: airflow [1062,1069]
name: airflow [1052,1059]
===
match
---
operator: = [6468,6469]
operator: = [6662,6663]
===
match
---
atom_expr [7908,7924]
atom_expr [8142,8158]
===
match
---
name: timeout [4961,4968]
name: timeout [4951,4958]
===
match
---
expr_stmt [2209,2232]
expr_stmt [2199,2222]
===
match
---
operator: = [1609,1610]
operator: = [1599,1600]
===
match
---
name: self [6627,6631]
name: self [6821,6825]
===
match
---
atom_expr [7900,7936]
atom_expr [8134,8170]
===
match
---
operator: , [7746,7747]
operator: , [7980,7981]
===
match
---
operator: , [4818,4819]
operator: , [4808,4809]
===
match
---
simple_stmt [1025,1057]
simple_stmt [1015,1047]
===
match
---
name: airflow [935,942]
name: airflow [925,932]
===
match
---
operator: = [7602,7603]
operator: = [7813,7814]
===
match
---
name: ti [7748,7750]
name: ti [7982,7984]
===
match
---
suite [7937,8649]
suite [8171,8883]
===
match
---
trailer [6155,6203]
trailer [6145,6193]
===
match
---
simple_stmt [7785,7844]
simple_stmt [8019,8078]
===
match
---
operator: = [3469,3470]
operator: = [3459,3460]
===
match
---
trailer [2901,2915]
trailer [2891,2905]
===
match
---
operator: * [4786,4787]
operator: * [4776,4777]
===
match
---
string: """Handle case where self.task_runner exits by itself""" [6077,6133]
string: """Handle case where self.task_runner exits by itself""" [6067,6123]
===
match
---
import_from [930,971]
import_from [920,961]
===
match
---
trailer [7567,7574]
trailer [7763,7775]
===
match
---
trailer [7124,7132]
trailer [7318,7326]
===
match
---
atom_expr [7401,7412]
atom_expr [7595,7606]
===
match
---
trailer [2065,2081]
trailer [2055,2071]
===
match
---
name: get_hostname [1175,1187]
name: get_hostname [1165,1177]
===
match
---
name: ignore_ti_state [3505,3520]
name: ignore_ti_state [3495,3510]
===
match
---
param [6036,6041]
param [6026,6031]
===
match
---
not_test [7641,7657]
not_test [7875,7891]
===
match
---
simple_stmt [930,972]
simple_stmt [920,962]
===
match
---
suite [3609,3685]
suite [3599,3675]
===
match
---
arglist [7984,8074]
arglist [8218,8308]
===
match
---
name: _execute [2417,2425]
name: _execute [2407,2415]
===
match
---
string: "State of this instance has been externally set to %s. " [7984,8040]
string: "State of this instance has been externally set to %s. " [8218,8274]
===
match
---
trailer [8563,8576]
trailer [8797,8810]
===
match
---
param [1793,1802]
param [1783,1792]
===
match
---
name: self [2626,2630]
name: self [2616,2620]
===
match
---
name: self [1861,1865]
name: self [1851,1855]
===
match
---
name: current_pid [7551,7562]
name: current_pid [7745,7756]
===
match
---
expr_stmt [8625,8648]
expr_stmt [8859,8882]
===
match
---
string: "task received sigterm" [2998,3021]
string: "task received sigterm" [2988,3011]
===
match
---
simple_stmt [1057,1110]
simple_stmt [1047,1100]
===
match
---
trailer [2860,2870]
trailer [2850,2860]
===
match
---
not_test [7231,7248]
not_test [7425,7442]
===
match
---
trailer [6474,6486]
trailer [6668,6680]
===
match
---
name: self [2168,2172]
name: self [2158,2162]
===
match
---
dotted_name [977,1004]
dotted_name [967,994]
===
match
---
name: AirflowException [3054,3070]
name: AirflowException [3044,3060]
===
match
---
atom_expr [7204,7215]
atom_expr [7398,7409]
===
match
---
atom_expr [6969,6997]
atom_expr [7163,7191]
===
match
---
name: current_pid [7756,7767]
name: current_pid [7990,8001]
===
match
---
string: 'LocalTaskJob' [1407,1421]
string: 'LocalTaskJob' [1397,1411]
===
match
---
param [1626,1656]
param [1616,1646]
===
match
---
tfpdef [1701,1725]
tfpdef [1691,1715]
===
match
---
name: ti [7071,7073]
name: ti [7265,7267]
===
match
---
trailer [3592,3597]
trailer [3582,3587]
===
match
---
name: terminating [8630,8641]
name: terminating [8864,8875]
===
match
---
string: "Time since last heartbeat({:.2f}s) " [5802,5839]
string: "Time since last heartbeat({:.2f}s) " [5792,5829]
===
match
---
name: error [2635,2640]
name: error [2625,2630]
===
match
---
name: self [7076,7080]
name: self [7270,7274]
===
match
---
import_from [1238,1275]
import_from [1228,1265]
===
match
---
string: 'scheduler_zombie_task_threshold' [3797,3830]
string: 'scheduler_zombie_task_threshold' [3787,3820]
===
match
---
operator: - [5472,5473]
operator: - [5462,5463]
===
match
---
name: AirflowException [7791,7807]
name: AirflowException [8025,8041]
===
match
---
operator: = [3561,3562]
operator: = [3551,3552]
===
match
---
funcdef [1428,2408]
funcdef [1418,2398]
===
match
---
trailer [7750,7754]
trailer [7984,7988]
===
match
---
tfpdef [6042,6058]
tfpdef [6032,6048]
===
match
---
comp_op [5015,5021]
comp_op [5005,5011]
===
match
---
tfpdef [1742,1761]
tfpdef [1732,1751]
===
match
---
name: ignore_all_deps [1909,1924]
name: ignore_all_deps [1899,1914]
===
match
---
name: heartbeat_time_limit [4675,4695]
name: heartbeat_time_limit [4665,4685]
===
match
---
name: self [4272,4276]
name: self [4262,4266]
===
match
---
operator: = [4930,4931]
operator: = [4920,4921]
===
match
---
name: self [2061,2065]
name: self [2051,2055]
===
match
---
if_stmt [7228,7538]
if_stmt [7422,7732]
===
match
---
atom_expr [1904,1924]
atom_expr [1894,1914]
===
match
---
simple_stmt [7146,7168]
simple_stmt [7340,7362]
===
match
---
atom_expr [3521,3541]
atom_expr [3511,3531]
===
match
---
name: format [5888,5894]
name: format [5878,5884]
===
match
---
comparison [6407,6448]
comparison [6601,6642]
===
match
---
name: State [7119,7124]
name: State [7313,7318]
===
match
---
name: kwargs [1795,1801]
name: kwargs [1785,1791]
===
match
---
simple_stmt [7071,7095]
simple_stmt [7265,7289]
===
match
---
tfpdef [1464,1491]
tfpdef [1454,1481]
===
match
---
trailer [7270,7274]
trailer [7464,7468]
===
match
---
trailer [3783,3831]
trailer [3773,3821]
===
match
---
name: dag_id [1866,1872]
name: dag_id [1856,1862]
===
match
---
name: pickle_id [1701,1710]
name: pickle_id [1691,1700]
===
match
---
operator: , [7754,7755]
operator: , [7988,7989]
===
match
---
operator: * [1778,1779]
operator: * [1768,1769]
===
match
---
name: ignore_all_deps [3339,3354]
name: ignore_all_deps [3329,3344]
===
match
---
import_from [882,929]
import_from [872,919]
===
match
---
name: ti [8066,8068]
name: ti [8300,8302]
===
match
---
simple_stmt [5995,6010]
simple_stmt [5985,6000]
===
match
---
not_test [3219,3608]
not_test [3209,3598]
===
match
---
decorated [6713,8649]
decorated [6907,8883]
===
match
---
classdef [1278,8649]
classdef [1268,8883]
===
match
---
not_test [4268,4288]
not_test [4258,4278]
===
match
---
name: fqdn [7434,7438]
name: fqdn [7628,7632]
===
match
---
operator: , [3569,3570]
operator: , [3559,3560]
===
match
---
name: self [5474,5478]
name: self [5464,5468]
===
match
---
operator: = [1873,1874]
operator: = [1863,1864]
===
match
---
number: 1 [5662,5663]
number: 1 [5652,5653]
===
match
---
name: airflow [977,984]
name: airflow [967,974]
===
match
---
expr_stmt [2133,2159]
expr_stmt [2123,2149]
===
match
---
name: AirflowException [5760,5776]
name: AirflowException [5750,5766]
===
match
---
name: same_process [7589,7601]
name: same_process [7800,7812]
===
match
---
trailer [5496,5510]
trailer [5486,5500]
===
match
---
name: state [8069,8074]
name: state [8303,8308]
===
match
---
trailer [4769,4783]
trailer [4759,4773]
===
match
---
argument [3453,3491]
argument [3443,3481]
===
match
---
if_stmt [5529,5966]
if_stmt [5519,5956]
===
match
---
trailer [7683,7691]
trailer [7917,7925]
===
match
---
trailer [8127,8129]
trailer [8361,8363]
===
match
---
atom_expr [3772,3831]
atom_expr [3762,3821]
===
match
---
name: task_runner [2214,2225]
name: task_runner [2204,2215]
===
match
---
name: self [2340,2344]
name: self [2330,2334]
===
match
---
name: self [3521,3525]
name: self [3511,3515]
===
match
---
suite [3698,5966]
suite [3688,5956]
===
match
---
atom_expr [1712,1725]
atom_expr [1702,1715]
===
match
---
trailer [6995,6997]
trailer [7189,7191]
===
match
---
trailer [6560,6573]
trailer [6754,6767]
===
match
---
name: error [8188,8193]
name: error [8422,8427]
===
match
---
atom_expr [2871,2883]
atom_expr [2861,2873]
===
match
---
name: ti [7107,7109]
name: ti [7301,7303]
===
match
---
argument [8564,8575]
argument [8798,8809]
===
match
---
trailer [3174,3206]
trailer [3164,3196]
===
match
---
name: ignore_all_deps [3360,3375]
name: ignore_all_deps [3350,3365]
===
match
---
argument [3295,3325]
argument [3285,3315]
===
match
---
expr_stmt [3749,3831]
expr_stmt [3739,3821]
===
match
---
simple_stmt [2699,2714]
simple_stmt [2689,2704]
===
match
---
expr_stmt [1364,1422]
expr_stmt [1354,1412]
===
match
---
name: str [1757,1760]
name: str [1747,1750]
===
match
---
name: self [5127,5131]
name: self [5117,5121]
===
match
---
trailer [5887,5894]
trailer [5877,5884]
===
match
---
simple_stmt [6679,6708]
simple_stmt [6873,6902]
===
match
---
name: task_instance [6217,6230]
name: task_instance [6207,6220]
===
match
---
simple_stmt [2340,2365]
simple_stmt [2330,2355]
===
match
---
string: 'polymorphic_identity' [1383,1405]
string: 'polymorphic_identity' [1373,1395]
===
match
---
simple_stmt [8439,8526]
simple_stmt [8673,8760]
===
match
---
atom_expr [3175,3189]
atom_expr [3165,3179]
===
match
---
strings [7692,7746]
strings [7926,7980]
===
match
---
argument [3389,3439]
argument [3379,3429]
===
match
---
name: error [6462,6467]
name: error [6656,6661]
===
match
---
operator: , [4551,4552]
operator: , [4541,4542]
===
match
---
simple_stmt [5127,5144]
simple_stmt [5117,5134]
===
match
---
name: self [2441,2445]
name: self [2431,2435]
===
match
---
name: on_finish [6696,6705]
name: on_finish [6890,6899]
===
match
---
expr_stmt [2168,2200]
expr_stmt [2158,2190]
===
match
---
name: self [7026,7030]
name: self [7220,7224]
===
match
---
name: self [5685,5689]
name: self [5675,5679]
===
match
---
operator: = [2458,2459]
operator: = [2448,2449]
===
match
---
trailer [2112,2117]
trailer [2102,2107]
===
match
---
trailer [2711,2713]
trailer [2701,2703]
===
match
---
atom_expr [3161,3206]
atom_expr [3151,3196]
===
match
---
name: on_kill [2704,2711]
name: on_kill [2694,2701]
===
match
---
atom_expr [8447,8487]
atom_expr [8681,8721]
===
match
---
name: time_since_last_heartbeat [5425,5450]
name: time_since_last_heartbeat [5415,5440]
===
match
---
name: self [6212,6216]
name: self [6202,6206]
===
match
---
name: task_runner [4937,4948]
name: task_runner [4927,4938]
===
match
---
param [1778,1784]
param [1768,1774]
===
match
---
funcdef [6734,8649]
funcdef [6928,8883]
===
match
---
trailer [7274,7282]
trailer [7468,7476]
===
match
---
trailer [8162,8170]
trailer [8396,8404]
===
match
---
trailer [6523,6537]
trailer [6717,6731]
===
match
---
operator: { [1382,1383]
operator: { [1372,1373]
===
match
---
simple_stmt [7551,7577]
simple_stmt [7745,7788]
===
match
---
name: task_instance [2902,2915]
name: task_instance [2892,2905]
===
match
---
name: error [8439,8444]
name: error [8673,8678]
===
match
---
atom_expr [1861,1872]
atom_expr [1851,1862]
===
match
---
string: "Recorded pid %s does not match " [7692,7725]
string: "Recorded pid %s does not match " [7926,7959]
===
match
---
atom_expr [4747,4768]
atom_expr [4737,4758]
===
match
---
name: max [4525,4528]
name: max [4515,4518]
===
match
---
atom_expr [3355,3375]
atom_expr [3345,3365]
===
match
---
atom_expr [2374,2407]
atom_expr [2364,2397]
===
match
---
name: heartbeat [5132,5141]
name: heartbeat [5122,5131]
===
match
---
comparison [5532,5580]
comparison [5522,5570]
===
match
---
atom_expr [5602,5664]
atom_expr [5592,5654]
===
match
---
name: get_task_runner [1094,1109]
name: get_task_runner [1084,1099]
===
match
---
atom_expr [4616,4881]
atom_expr [4606,4871]
===
match
---
trailer [7691,7768]
trailer [7925,8002]
===
match
---
operator: , [3491,3492]
operator: , [3481,3482]
===
match
---
suite [8218,8526]
suite [8452,8760]
===
match
---
or_test [8447,8525]
or_test [8681,8759]
===
match
---
name: self [8101,8105]
name: self [8335,8339]
===
match
---
operator: ** [1793,1795]
operator: ** [1783,1785]
===
match
---
trailer [3227,3241]
trailer [3217,3231]
===
match
---
name: State [8157,8162]
name: State [8391,8396]
===
match
---
name: check_and_change_state_before_execution [3242,3281]
name: check_and_change_state_before_execution [3232,3271]
===
match
---
trailer [6683,6695]
trailer [6877,6889]
===
match
---
trailer [5052,5069]
trailer [5042,5059]
===
match
---
trailer [2870,2884]
trailer [2860,2874]
===
match
---
operator: @ [6713,6714]
operator: @ [6907,6908]
===
match
---
import_from [1057,1109]
import_from [1047,1099]
===
match
---
name: session [1207,1214]
name: session [1197,1204]
===
match
---
name: mark_success [2173,2185]
name: mark_success [2163,2175]
===
match
---
simple_stmt [2842,2885]
simple_stmt [2832,2875]
===
match
---
atom_expr [5453,5512]
atom_expr [5443,5502]
===
match
---
operator: = [6770,6771]
operator: = [6964,6965]
===
match
---
expr_stmt [1951,2003]
expr_stmt [1941,1993]
===
match
---
name: self [2426,2430]
name: self [2416,2420]
===
match
---
name: self [6036,6040]
name: self [6026,6030]
===
match
---
name: utils [1201,1206]
name: utils [1191,1196]
===
match
---
name: utcnow [4736,4742]
name: utcnow [4726,4732]
===
match
---
atom_expr [1875,1895]
atom_expr [1865,1885]
===
match
---
name: log [7271,7274]
name: log [7465,7468]
===
match
---
name: args [2392,2396]
name: args [2382,2386]
===
match
---
trailer [7912,7924]
trailer [8146,8158]
===
match
---
name: BaseJob [1297,1304]
name: BaseJob [1287,1294]
===
match
---
atom_expr [4844,4858]
atom_expr [4834,4848]
===
match
---
name: ti [8538,8540]
name: ti [8772,8774]
===
match
---
operator: , [8064,8065]
operator: , [8298,8299]
===
match
---
operator: , [3597,3598]
operator: , [3587,3588]
===
match
---
atom_expr [7119,7132]
atom_expr [7313,7326]
===
match
---
name: ignore_task_deps [1586,1602]
name: ignore_task_deps [1576,1592]
===
match
---
name: task_instance [2783,2796]
name: task_instance [2773,2786]
===
match
---
simple_stmt [2133,2160]
simple_stmt [2123,2150]
===
match
---
simple_stmt [3711,3736]
simple_stmt [3701,3726]
===
match
---
name: return_code [6042,6053]
name: return_code [6032,6043]
===
match
---
string: """Setting kill signal handler""" [2580,2613]
string: """Setting kill signal handler""" [2570,2603]
===
match
---
trailer [3474,3491]
trailer [3464,3481]
===
match
---
strings [7304,7379]
strings [7498,7573]
===
match
---
name: hostname [7404,7412]
name: hostname [7598,7606]
===
match
---
atom_expr [6407,6431]
atom_expr [6601,6625]
===
match
---
name: self [8625,8629]
name: self [8859,8863]
===
match
---
simple_stmt [6462,6511]
simple_stmt [6656,6705]
===
match
---
simple_stmt [5048,5083]
simple_stmt [5038,5073]
===
match
---
operator: = [1837,1838]
operator: = [1827,1828]
===
match
---
name: task_runner [8452,8463]
name: task_runner [8686,8697]
===
match
---
arith_expr [4675,4792]
arith_expr [4665,4782]
===
match
---
name: finished [2816,2824]
name: finished [2806,2814]
===
match
---
number: 0 [4550,4551]
number: 0 [4540,4541]
===
match
---
term [4726,4792]
term [4716,4782]
===
match
---
if_stmt [5000,5110]
if_stmt [4990,5100]
===
match
---
expr_stmt [7146,7167]
expr_stmt [7340,7361]
===
match
---
operator: , [2396,2397]
operator: , [2386,2387]
===
match
---
name: timezone [4727,4735]
name: timezone [4717,4725]
===
match
---
atom_expr [6212,6248]
atom_expr [6202,6238]
===
match
---
name: pool [3583,3587]
name: pool [3573,3577]
===
match
---
operator: , [6189,6190]
operator: , [6179,6180]
===
match
---
name: AirflowException [913,929]
name: AirflowException [903,919]
===
match
---
operator: , [1691,1692]
operator: , [1681,1682]
===
match
---
trailer [3241,3281]
trailer [3231,3271]
===
match
---
operator: , [7438,7439]
operator: , [7632,7633]
===
match
---
trailer [6658,6668]
trailer [6852,6862]
===
match
---
param [1742,1769]
param [1732,1759]
===
match
---
trailer [2016,2033]
trailer [2006,2023]
===
match
---
name: self [2209,2213]
name: self [2199,2203]
===
match
---
name: log [6147,6150]
name: log [6137,6140]
===
match
---
operator: = [1762,1763]
operator: = [1752,1753]
===
match
---
operator: = [2226,2227]
operator: = [2216,2217]
===
match
---
name: __init__ [2382,2390]
name: __init__ [2372,2380]
===
match
---
trailer [2876,2883]
trailer [2866,2873]
===
match
---
name: ignore_depends_on_past [1981,2003]
name: ignore_depends_on_past [1971,1993]
===
match
---
name: base_job [948,956]
name: base_job [938,946]
===
match
---
operator: = [3770,3771]
operator: = [3760,3761]
===
match
---
param [1701,1733]
param [1691,1723]
===
match
---
atom_expr [7266,7457]
atom_expr [7460,7651]
===
match
---
dotted_name [887,905]
dotted_name [877,895]
===
match
---
name: state [7110,7115]
name: state [7304,7309]
===
match
---
dotted_name [1030,1043]
dotted_name [1020,1033]
===
match
---
trailer [2344,2356]
trailer [2334,2346]
===
match
---
string: "The recorded hostname %s " [7304,7331]
string: "The recorded hostname %s " [7498,7525]
===
match
---
trailer [7807,7843]
trailer [8041,8077]
===
match
---
arglist [3295,3598]
arglist [3285,3588]
===
match
---
name: ignore_task_deps [3453,3469]
name: ignore_task_deps [3443,3459]
===
match
---
simple_stmt [5602,5665]
simple_stmt [5592,5655]
===
match
---
trailer [7165,7167]
trailer [7359,7361]
===
match
---
atom_expr [2209,2225]
atom_expr [2199,2215]
===
match
---
trailer [2730,2744]
trailer [2720,2734]
===
match
---
name: task_runner [2446,2457]
name: task_runner [2436,2447]
===
match
---
name: task_instance [2847,2860]
name: task_instance [2837,2850]
===
match
---
name: return_code [6191,6202]
name: return_code [6181,6192]
===
match
---
name: pid [7607,7610]
name: pid [7818,7821]
===
match
---
name: ignore_task_deps [2036,2052]
name: ignore_task_deps [2026,2042]
===
match
---
expr_stmt [6462,6510]
expr_stmt [6656,6704]
===
match
---
simple_stmt [2061,2100]
simple_stmt [2051,2090]
===
match
---
operator: , [5660,5661]
operator: , [5650,5651]
===
match
---
simple_stmt [5425,5513]
simple_stmt [5415,5503]
===
match
---
name: self [3412,3416]
name: self [3402,3406]
===
match
---
operator: , [3541,3542]
operator: , [3531,3532]
===
match
---
name: ignore_ti_state [2084,2099]
name: ignore_ti_state [2074,2089]
===
match
---
trailer [3167,3174]
trailer [3157,3164]
===
match
---
name: terminate [6659,6668]
name: terminate [6853,6862]
===
match
---
trailer [4276,4288]
trailer [4266,4278]
===
match
---
atom_expr [5454,5471]
atom_expr [5444,5461]
===
match
---
name: ignore_depends_on_past [3389,3411]
name: ignore_depends_on_past [3379,3401]
===
match
---
name: self [2897,2901]
name: self [2887,2891]
===
match
---
name: provide_session [6714,6729]
name: provide_session [6908,6923]
===
match
---
name: on_kill [6000,6007]
name: on_kill [5990,5997]
===
match
---
argument [3339,3375]
argument [3329,3365]
===
match
---
simple_stmt [4918,4984]
simple_stmt [4908,4974]
===
match
---
name: task_runner [6684,6695]
name: task_runner [6878,6889]
===
match
---
name: self [3355,3359]
name: self [3345,3349]
===
match
---
operator: = [5451,5452]
operator: = [5441,5442]
===
match
---
operator: = [3307,3308]
operator: = [3297,3298]
===
match
---
simple_stmt [7266,7458]
simple_stmt [7460,7652]
===
match
---
atom_expr [2012,2033]
atom_expr [2002,2023]
===
match
---
name: self [7908,7912]
name: self [8142,8146]
===
match
---
atom_expr [7857,7887]
atom_expr [8091,8121]
===
match
---
operator: = [1380,1381]
operator: = [1370,1371]
===
insert-tree
---
if_stmt [6394,6590]
    comparison [6397,6438]
        atom_expr [6397,6421]
            name: self [6397,6401]
            trailer [6401,6415]
                name: task_instance [6402,6415]
            trailer [6415,6421]
                name: state [6416,6421]
        operator: == [6422,6424]
        atom_expr [6425,6438]
            name: State [6425,6430]
            trailer [6430,6438]
                name: RUNNING [6431,6438]
    suite [6439,6590]
        simple_stmt [6547,6590]
            atom_expr [6547,6589]
                name: self [6547,6551]
                trailer [6551,6565]
                    name: task_instance [6552,6565]
                trailer [6565,6575]
                    name: set_state [6566,6575]
                trailer [6575,6589]
                    atom_expr [6576,6588]
                        name: State [6576,6581]
                        trailer [6581,6588]
                            name: FAILED [6582,6588]
to
suite [6068,6610]
at 4
===
insert-node
---
and_test [7852,7891]
to
if_stmt [7638,7844]
at 0
===
move-tree
---
not_test [7641,7657]
    name: same_process [7645,7657]
to
and_test [7852,7891]
at 1
===
update-node
---
name: os [7565,7567]
replace os by self
===
insert-tree
---
trailer [7783,7787]
    name: pid [7784,7787]
to
atom_expr [7565,7576]
at 3
===
update-node
---
name: getpid [7568,7574]
replace getpid by task_runner
===
insert-node
---
name: process [7776,7783]
to
trailer [7574,7576]
at 0
===
delete-tree
---
simple_stmt [790,800]
    import_name [790,799]
        name: os [797,799]
