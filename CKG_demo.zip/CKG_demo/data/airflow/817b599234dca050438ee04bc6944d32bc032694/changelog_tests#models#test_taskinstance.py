===
match
---
assert_stmt [25872,25911]
assert_stmt [25872,25911]
===
match
---
operator: = [60345,60346]
operator: = [60345,60346]
===
match
---
string: 'foo' [16019,16024]
string: 'foo' [16019,16024]
===
match
---
number: 1 [5004,5005]
number: 1 [5004,5005]
===
match
---
operator: , [5070,5071]
operator: , [5070,5071]
===
match
---
comparison [5193,5252]
comparison [5193,5252]
===
match
---
number: 3 [23489,23490]
number: 3 [23489,23490]
===
match
---
operator: , [9981,9982]
operator: , [9981,9982]
===
match
---
name: task_id [4488,4495]
name: task_id [4488,4495]
===
match
---
argument [9347,9365]
argument [9347,9365]
===
match
---
trailer [26313,26324]
trailer [26313,26324]
===
match
---
name: execution_date [53538,53552]
name: execution_date [53538,53552]
===
match
---
number: 5 [33686,33687]
number: 5 [33686,33687]
===
match
---
argument [17386,17418]
argument [17386,17418]
===
match
---
operator: , [34810,34811]
operator: , [34810,34811]
===
match
---
string: 'test_get_rendered_k8s_spec' [69728,69756]
string: 'test_get_rendered_k8s_spec' [69728,69756]
===
match
---
operator: = [68669,68670]
operator: = [68669,68670]
===
match
---
trailer [39271,39281]
trailer [39271,39281]
===
match
---
funcdef [73449,75975]
funcdef [73449,75975]
===
match
---
operator: , [33857,33858]
operator: , [33857,33858]
===
match
---
operator: , [32713,32714]
operator: , [32713,32714]
===
match
---
name: ti [13752,13754]
name: ti [13752,13754]
===
match
---
name: ti [21330,21332]
name: ti [21330,21332]
===
match
---
trailer [53655,53670]
trailer [53655,53670]
===
match
---
operator: , [9129,9130]
operator: , [9129,9130]
===
match
---
name: add [22602,22605]
name: add [22602,22605]
===
match
---
operator: , [72204,72205]
operator: , [72204,72205]
===
match
---
operator: { [11912,11913]
operator: { [11912,11913]
===
match
---
atom_expr [22087,22125]
atom_expr [22087,22125]
===
match
---
trailer [71363,71365]
trailer [71363,71365]
===
match
---
operator: = [38653,38654]
operator: = [38653,38654]
===
match
---
name: DAG [9033,9036]
name: DAG [9033,9036]
===
match
---
operator: = [13650,13651]
operator: = [13650,13651]
===
match
---
name: DEFAULT_DATE [36350,36362]
name: DEFAULT_DATE [36350,36362]
===
match
---
trailer [40397,40411]
trailer [40397,40411]
===
match
---
name: State [54534,54539]
name: State [54534,54539]
===
match
---
name: test_reschedule_handling [24050,24074]
name: test_reschedule_handling [24050,24074]
===
match
---
operator: , [57953,57954]
operator: , [57953,57954]
===
match
---
trailer [80200,80262]
trailer [80200,80262]
===
match
---
name: owner [41634,41639]
name: owner [41634,41639]
===
match
---
comparison [18487,18512]
comparison [18487,18512]
===
match
---
operator: = [23594,23595]
operator: = [23594,23595]
===
match
---
name: ti [46433,46435]
name: ti [46433,46435]
===
match
---
name: SCHEDULED [18434,18443]
name: SCHEDULED [18434,18443]
===
match
---
number: 1 [54064,54065]
number: 1 [54064,54065]
===
match
---
operator: , [33032,33033]
operator: , [33032,33033]
===
match
---
name: try_number [29569,29579]
name: try_number [29569,29579]
===
match
---
expr_stmt [43684,43756]
expr_stmt [43684,43756]
===
match
---
name: ti_list [55335,55342]
name: ti_list [55335,55342]
===
match
---
name: str [51680,51683]
name: str [51680,51683]
===
match
---
argument [43732,43755]
argument [43732,43755]
===
match
---
name: timedelta [30736,30745]
name: timedelta [30736,30745]
===
match
---
name: task_id [69147,69154]
name: task_id [69147,69154]
===
match
---
trailer [37958,37993]
trailer [37958,37993]
===
match
---
operator: == [44269,44271]
operator: == [44269,44271]
===
match
---
trailer [45188,45192]
trailer [45188,45192]
===
match
---
trailer [35241,35260]
trailer [35241,35260]
===
match
---
atom_expr [44046,44111]
atom_expr [44046,44111]
===
match
---
operator: , [51621,51622]
operator: , [51621,51622]
===
match
---
name: ti [43787,43789]
name: ti [43787,43789]
===
match
---
operator: } [72691,72692]
operator: } [72691,72692]
===
match
---
assert_stmt [56842,56872]
assert_stmt [56842,56872]
===
match
---
arglist [14312,14421]
arglist [14312,14421]
===
match
---
argument [59728,59737]
argument [59728,59737]
===
match
---
argument [67478,67493]
argument [67478,67493]
===
match
---
atom_expr [54505,54518]
atom_expr [54505,54518]
===
match
---
atom_expr [22621,22649]
atom_expr [22621,22649]
===
match
---
simple_stmt [19109,19114]
simple_stmt [19109,19114]
===
match
---
name: DAG [56939,56942]
name: DAG [56939,56942]
===
match
---
name: RenderedTaskInstanceFields [1393,1419]
name: RenderedTaskInstanceFields [1393,1419]
===
match
---
atom_expr [16759,16777]
atom_expr [16759,16777]
===
match
---
expr_stmt [26912,26937]
expr_stmt [26912,26937]
===
match
---
trailer [29300,29304]
trailer [29300,29304]
===
match
---
atom_expr [9482,9497]
atom_expr [9482,9497]
===
match
---
argument [8645,8664]
argument [8645,8664]
===
match
---
name: get_task_instance [56630,56647]
name: get_task_instance [56630,56647]
===
match
---
name: timezone [40314,40322]
name: timezone [40314,40322]
===
match
---
trailer [25046,25061]
trailer [25046,25061]
===
match
---
name: utcnow [64159,64165]
name: utcnow [64159,64165]
===
match
---
trailer [15768,15930]
trailer [15768,15930]
===
match
---
operator: , [34522,34523]
operator: , [34522,34523]
===
match
---
operator: , [33731,33732]
operator: , [33731,33732]
===
match
---
name: DEFAULT_DATE [43662,43674]
name: DEFAULT_DATE [43662,43674]
===
match
---
name: datetime [41683,41691]
name: datetime [41683,41691]
===
match
---
name: end_date [66381,66389]
name: end_date [66381,66389]
===
match
---
arglist [18251,18294]
arglist [18251,18294]
===
match
---
testlist_star_expr [26679,26689]
testlist_star_expr [26679,26689]
===
match
---
operator: = [75030,75031]
operator: = [75030,75031]
===
match
---
operator: == [43439,43441]
operator: == [43439,43441]
===
match
---
atom [59257,59353]
atom [59257,59353]
===
match
---
expr_stmt [58715,58750]
expr_stmt [58715,58750]
===
match
---
name: temp_instance [3368,3381]
name: temp_instance [3368,3381]
===
match
---
argument [16554,16583]
argument [16554,16583]
===
match
---
name: self [43930,43934]
name: self [43930,43934]
===
match
---
argument [31020,31037]
argument [31020,31037]
===
match
---
number: 0 [14191,14192]
number: 0 [14191,14192]
===
match
---
operator: = [15701,15702]
operator: = [15701,15702]
===
match
---
simple_stmt [61975,62004]
simple_stmt [61975,62004]
===
match
---
atom_expr [42804,42851]
atom_expr [42804,42851]
===
match
---
trailer [77732,77746]
trailer [77732,77746]
===
match
---
name: run_date [34678,34686]
name: run_date [34678,34686]
===
match
---
suite [73602,75975]
suite [73602,75975]
===
match
---
name: refresh_from_db [29426,29441]
name: refresh_from_db [29426,29441]
===
match
---
number: 0 [38724,38725]
number: 0 [38724,38725]
===
match
---
name: _ [55111,55112]
name: _ [55111,55112]
===
match
---
suite [60329,61334]
suite [60329,61334]
===
match
---
expr_stmt [19905,20000]
expr_stmt [19905,20000]
===
match
---
operator: , [32801,32802]
operator: , [32801,32802]
===
match
---
atom_expr [64453,64506]
atom_expr [64453,64506]
===
match
---
name: ti [77008,77010]
name: ti [77008,77010]
===
match
---
name: ti [23065,23067]
name: ti [23065,23067]
===
match
---
dictorsetmaker [72305,72356]
dictorsetmaker [72305,72356]
===
match
---
name: execution_date [14238,14252]
name: execution_date [14238,14252]
===
match
---
atom_expr [54236,54298]
atom_expr [54236,54298]
===
match
---
name: dag [51026,51029]
name: dag [51026,51029]
===
match
---
import_name [979,994]
import_name [979,994]
===
match
---
assert_stmt [43376,43408]
assert_stmt [43376,43408]
===
match
---
name: get_previous_ti [54139,54154]
name: get_previous_ti [54139,54154]
===
match
---
name: add [3825,3828]
name: add [3825,3828]
===
match
---
trailer [50988,50990]
trailer [50988,50990]
===
match
---
operator: , [33511,33512]
operator: , [33511,33512]
===
match
---
suite [9632,10218]
suite [9632,10218]
===
match
---
operator: , [71813,71814]
operator: , [71813,71814]
===
match
---
name: RUNNING [60929,60936]
name: RUNNING [60929,60936]
===
match
---
name: self [39783,39787]
name: self [39783,39787]
===
match
---
atom_expr [7580,7628]
atom_expr [7580,7628]
===
match
---
trailer [16447,16461]
trailer [16447,16461]
===
match
---
name: self [65004,65008]
name: self [65004,65008]
===
match
---
simple_stmt [3060,3089]
simple_stmt [3060,3089]
===
match
---
simple_stmt [35102,35139]
simple_stmt [35102,35139]
===
match
---
number: 2 [20797,20798]
number: 2 [20797,20798]
===
match
---
expr_stmt [37329,37399]
expr_stmt [37329,37399]
===
match
---
name: external_trigger [65889,65905]
name: external_trigger [65889,65905]
===
match
---
number: 5 [67186,67187]
number: 5 [67186,67187]
===
match
---
trailer [24909,24916]
trailer [24909,24916]
===
match
---
operator: , [31816,31817]
operator: , [31816,31817]
===
match
---
operator: = [50678,50679]
operator: = [50678,50679]
===
match
---
name: MANUAL [56587,56593]
name: MANUAL [56587,56593]
===
match
---
param [73491,73504]
param [73491,73504]
===
match
---
simple_stmt [29502,29547]
simple_stmt [29502,29547]
===
match
---
name: include_prior_dates [41178,41197]
name: include_prior_dates [41178,41197]
===
match
---
argument [34958,34967]
argument [34958,34967]
===
match
---
expr_stmt [36541,36590]
expr_stmt [36541,36590]
===
match
---
operator: , [76956,76957]
operator: , [76956,76957]
===
match
---
string: 'test_generate_command_specific_param' [67644,67682]
string: 'test_generate_command_specific_param' [67644,67682]
===
match
---
string: 'op1' [69155,69160]
string: 'op1' [69155,69160]
===
match
---
name: task [47063,47067]
name: task [47063,47067]
===
match
---
number: 5 [32523,32524]
number: 5 [32523,32524]
===
match
---
string: 'op' [49830,49834]
string: 'op' [49830,49834]
===
match
---
name: DAG [16079,16082]
name: DAG [16079,16082]
===
match
---
expr_stmt [40011,40077]
expr_stmt [40011,40077]
===
match
---
trailer [61071,61079]
trailer [61071,61079]
===
match
---
name: task [65939,65943]
name: task [65939,65943]
===
match
---
argument [19142,19174]
argument [19142,19174]
===
match
---
operator: + [66557,66558]
operator: + [66557,66558]
===
match
---
argument [69147,69160]
argument [69147,69160]
===
match
---
trailer [66991,67010]
trailer [66991,67010]
===
match
---
comparison [4247,4267]
comparison [4247,4267]
===
match
---
operator: = [78348,78349]
operator: = [78348,78349]
===
match
---
return_stmt [52768,52778]
return_stmt [52768,52778]
===
match
---
operator: == [58396,58398]
operator: == [58396,58398]
===
match
---
trailer [12046,12059]
trailer [12046,12059]
===
match
---
simple_stmt [58181,58217]
simple_stmt [58181,58217]
===
match
---
simple_stmt [43376,43409]
simple_stmt [43376,43409]
===
match
---
operator: , [9160,9161]
operator: , [9160,9161]
===
match
---
name: self [13809,13813]
name: self [13809,13813]
===
match
---
comparison [28933,28951]
comparison [28933,28951]
===
match
---
name: run_date [25443,25451]
name: run_date [25443,25451]
===
match
---
name: State [72025,72030]
name: State [72025,72030]
===
match
---
name: State [19267,19272]
name: State [19267,19272]
===
match
---
number: 2 [33025,33026]
number: 2 [33025,33026]
===
match
---
operator: = [40209,40210]
operator: = [40209,40210]
===
match
---
atom_expr [65707,65922]
atom_expr [65707,65922]
===
match
---
fstring_expr [67093,67105]
fstring_expr [67093,67105]
===
match
---
operator: = [46630,46631]
operator: = [46630,46631]
===
match
---
operator: = [35671,35672]
operator: = [35671,35672]
===
match
---
operator: , [1477,1478]
operator: , [1477,1478]
===
match
---
arglist [60853,60902]
arglist [60853,60902]
===
match
---
operator: = [22492,22493]
operator: = [22492,22493]
===
match
---
funcdef [48087,48686]
funcdef [48087,48686]
===
match
---
name: state [11536,11541]
name: state [11536,11541]
===
match
---
operator: , [25061,25062]
operator: , [25061,25062]
===
match
---
name: xcom_pull [39085,39094]
name: xcom_pull [39085,39094]
===
match
---
argument [18019,18060]
argument [18019,18060]
===
match
---
name: ti_list [55493,55500]
name: ti_list [55493,55500]
===
match
---
operator: = [25116,25117]
operator: = [25116,25117]
===
match
---
param [36741,36745]
param [36741,36745]
===
match
---
name: TIDepStatus [12454,12465]
name: TIDepStatus [12454,12465]
===
match
---
atom [72191,72248]
atom [72191,72248]
===
match
---
operator: = [9933,9934]
operator: = [9933,9934]
===
match
---
arglist [4488,4660]
arglist [4488,4660]
===
match
---
name: ti [14327,14329]
name: ti [14327,14329]
===
match
---
argument [23756,23783]
argument [23756,23783]
===
match
---
operator: = [22178,22179]
operator: = [22178,22179]
===
match
---
operator: = [42647,42648]
operator: = [42647,42648]
===
match
---
expr_stmt [58226,58273]
expr_stmt [58226,58273]
===
match
---
name: TI [69211,69213]
name: TI [69211,69213]
===
match
---
atom_expr [25706,25720]
atom_expr [25706,25720]
===
match
---
argument [62478,62485]
argument [62478,62485]
===
match
---
operator: @ [8844,8845]
operator: @ [8844,8845]
===
match
---
operator: , [64607,64608]
operator: , [64607,64608]
===
match
---
string: 'test' [7684,7690]
string: 'test' [7684,7690]
===
match
---
name: refresh_from_db [31296,31311]
name: refresh_from_db [31296,31311]
===
match
---
operator: = [74722,74723]
operator: = [74722,74723]
===
match
---
simple_stmt [22430,22452]
simple_stmt [22430,22452]
===
match
---
simple_stmt [42904,42913]
simple_stmt [42904,42913]
===
match
---
name: ti [19448,19450]
name: ti [19448,19450]
===
match
---
operator: , [30850,30851]
operator: , [30850,30851]
===
match
---
name: python_callable [74249,74264]
name: python_callable [74249,74264]
===
match
---
argument [61446,61474]
argument [61446,61474]
===
match
---
arglist [64784,64827]
arglist [64784,64827]
===
match
---
trailer [79830,79834]
trailer [79830,79834]
===
match
---
operator: = [14326,14327]
operator: = [14326,14327]
===
match
---
operator: == [80083,80085]
operator: == [80083,80085]
===
match
---
operator: , [16540,16541]
operator: , [16540,16541]
===
match
---
string: ':' [70497,70500]
string: ':' [70497,70500]
===
match
---
name: dag [43727,43730]
name: dag [43727,43730]
===
match
---
name: value [39981,39986]
name: value [39981,39986]
===
match
---
name: ti [50084,50086]
name: ti [50084,50086]
===
match
---
operator: , [32289,32290]
operator: , [32289,32290]
===
match
---
name: models [42523,42529]
name: models [42523,42529]
===
match
---
name: test_bitshift_compose_operators [8372,8403]
name: test_bitshift_compose_operators [8372,8403]
===
match
---
trailer [9489,9493]
trailer [9489,9493]
===
match
---
argument [10425,10438]
argument [10425,10438]
===
match
---
operator: @ [77983,77984]
operator: @ [77983,77984]
===
match
---
operator: = [9827,9828]
operator: = [9827,9828]
===
match
---
parameters [71393,71441]
parameters [71393,71441]
===
match
---
operator: == [25669,25671]
operator: == [25669,25671]
===
match
---
atom_expr [54491,54503]
atom_expr [54491,54503]
===
match
---
argument [39117,39124]
argument [39117,39124]
===
match
---
name: dag [63944,63947]
name: dag [63944,63947]
===
match
---
name: _try_number [28901,28912]
name: _try_number [28901,28912]
===
match
---
operator: , [52954,52955]
operator: , [52954,52955]
===
match
---
trailer [25622,25638]
trailer [25622,25638]
===
match
---
operator: = [57148,57149]
operator: = [57148,57149]
===
match
---
trailer [66914,66916]
trailer [66914,66916]
===
match
---
operator: , [13231,13232]
operator: , [13231,13232]
===
match
---
operator: , [12165,12166]
operator: , [12165,12166]
===
match
---
name: task [11496,11500]
name: task [11496,11500]
===
match
---
atom_expr [45055,45064]
atom_expr [45055,45064]
===
match
---
name: datetime [40729,40737]
name: datetime [40729,40737]
===
match
---
name: ti [19009,19011]
name: ti [19009,19011]
===
match
---
import_name [804,813]
import_name [804,813]
===
match
---
arglist [64053,64072]
arglist [64053,64072]
===
match
---
simple_stmt [34658,34688]
simple_stmt [34658,34688]
===
match
---
assert_stmt [44420,44445]
assert_stmt [44420,44445]
===
match
---
name: dag [62482,62485]
name: dag [62482,62485]
===
match
---
trailer [65136,65159]
trailer [65136,65159]
===
match
---
name: State [66815,66820]
name: State [66815,66820]
===
match
---
operator: { [73112,73113]
operator: { [73112,73113]
===
match
---
atom [36019,36040]
atom [36019,36040]
===
match
---
name: self [67620,67624]
name: self [67620,67624]
===
match
---
assert_stmt [49609,49629]
assert_stmt [49609,49629]
===
match
---
name: exec_date [40374,40383]
name: exec_date [40374,40383]
===
match
---
annassign [2604,2640]
annassign [2604,2640]
===
match
---
trailer [79855,79864]
trailer [79855,79864]
===
match
---
argument [78969,78992]
argument [78969,78992]
===
match
---
arglist [23377,23718]
arglist [23377,23718]
===
match
---
name: task [14232,14236]
name: task [14232,14236]
===
match
---
parameters [68158,68164]
parameters [68158,68164]
===
match
---
comparison [54820,54908]
comparison [54820,54908]
===
match
---
operator: , [6458,6459]
operator: , [6458,6459]
===
match
---
suite [77121,77162]
suite [77121,77162]
===
match
---
string: 'A' [73113,73116]
string: 'A' [73113,73116]
===
match
---
atom_expr [3259,3276]
atom_expr [3259,3276]
===
match
---
atom_expr [35054,35092]
atom_expr [35054,35092]
===
match
---
operator: , [13224,13225]
operator: , [13224,13225]
===
match
---
argument [62514,62524]
argument [62514,62524]
===
match
---
operator: , [70612,70613]
operator: , [70612,70613]
===
match
---
argument [44820,44843]
argument [44820,44843]
===
match
---
name: session [71315,71322]
name: session [71315,71322]
===
match
---
atom_expr [24970,24983]
atom_expr [24970,24983]
===
match
---
operator: , [20372,20373]
operator: , [20372,20373]
===
match
---
name: dag [40394,40397]
name: dag [40394,40397]
===
match
---
argument [11491,11500]
argument [11491,11500]
===
match
---
operator: , [25296,25297]
operator: , [25296,25297]
===
match
---
operator: , [34133,34134]
operator: , [34133,34134]
===
match
---
string: 'env' [70566,70571]
string: 'env' [70566,70571]
===
match
---
operator: , [65488,65489]
operator: , [65488,65489]
===
match
---
simple_stmt [22886,22908]
simple_stmt [22886,22908]
===
match
---
expr_stmt [12130,12180]
expr_stmt [12130,12180]
===
match
---
string: 'bar' [16276,16281]
string: 'bar' [16276,16281]
===
match
---
atom [7865,7891]
atom [7865,7891]
===
match
---
number: 1 [54202,54203]
number: 1 [54202,54203]
===
match
---
param [53268,53275]
param [53268,53275]
===
match
---
name: DAG [21731,21734]
name: DAG [21731,21734]
===
match
---
arith_expr [5029,5070]
arith_expr [5029,5070]
===
match
---
name: task [13988,13992]
name: task [13988,13992]
===
match
---
operator: + [26239,26240]
operator: + [26239,26240]
===
match
---
name: TI [3141,3143]
name: TI [3141,3143]
===
match
---
name: queue [76707,76712]
name: queue [76707,76712]
===
match
---
name: task1 [61848,61853]
name: task1 [61848,61853]
===
match
---
number: 5 [32603,32604]
number: 5 [32603,32604]
===
match
---
name: SUCCESS [55540,55547]
name: SUCCESS [55540,55547]
===
match
---
name: DummyOperator [47762,47775]
name: DummyOperator [47762,47775]
===
match
---
trailer [67052,67058]
trailer [67052,67058]
===
match
---
name: done [24247,24251]
name: done [24247,24251]
===
match
---
expr_stmt [2590,2640]
expr_stmt [2590,2640]
===
match
---
operator: , [61498,61499]
operator: , [61498,61499]
===
match
---
name: op1 [8693,8696]
name: op1 [8693,8696]
===
match
---
assert_stmt [24019,24040]
assert_stmt [24019,24040]
===
match
---
operator: @ [68930,68931]
operator: @ [68930,68931]
===
match
---
name: dag_id [67098,67104]
name: dag_id [67098,67104]
===
match
---
fstring_end: ' [67059,67060]
fstring_end: ' [67059,67060]
===
match
---
atom_expr [41879,41892]
atom_expr [41879,41892]
===
match
---
operator: , [32361,32362]
operator: , [32361,32362]
===
match
---
simple_stmt [8332,8363]
simple_stmt [8332,8363]
===
match
---
argument [24797,24846]
argument [24797,24846]
===
match
---
operator: , [1443,1444]
operator: , [1443,1444]
===
match
---
operator: , [52853,52854]
operator: , [52853,52854]
===
match
---
argument [37959,37981]
argument [37959,37981]
===
match
---
operator: , [23565,23566]
operator: , [23565,23566]
===
match
---
name: dag_id [67470,67476]
name: dag_id [67470,67476]
===
match
---
name: TI [49873,49875]
name: TI [49873,49875]
===
match
---
atom_expr [45413,45464]
atom_expr [45413,45464]
===
match
---
name: date1 [30027,30032]
name: date1 [30027,30032]
===
match
---
trailer [27618,27636]
trailer [27618,27636]
===
match
---
argument [4135,4142]
argument [4135,4142]
===
match
---
operator: , [33484,33485]
operator: , [33484,33485]
===
match
---
simple_stmt [12034,12118]
simple_stmt [12034,12118]
===
match
---
name: i [34510,34511]
name: i [34510,34511]
===
match
---
trailer [27930,27976]
trailer [27930,27976]
===
match
---
name: ti [35721,35723]
name: ti [35721,35723]
===
match
---
number: 0 [62060,62061]
number: 0 [62060,62061]
===
match
---
name: ti [39682,39684]
name: ti [39682,39684]
===
match
---
argument [61855,61880]
argument [61855,61880]
===
match
---
name: dag_run [47902,47909]
name: dag_run [47902,47909]
===
match
---
operator: , [24560,24561]
operator: , [24560,24561]
===
match
---
name: ti [31329,31331]
name: ti [31329,31331]
===
match
---
simple_stmt [74751,74819]
simple_stmt [74751,74819]
===
match
---
simple_stmt [40340,40385]
simple_stmt [40340,40385]
===
match
---
trailer [54664,54692]
trailer [54664,54692]
===
match
---
atom [31674,31722]
atom [31674,31722]
===
match
---
operator: , [53834,53835]
operator: , [53834,53835]
===
match
---
name: raises [42873,42879]
name: raises [42873,42879]
===
match
---
simple_stmt [21086,21098]
simple_stmt [21086,21098]
===
match
---
name: max_delay [23012,23021]
name: max_delay [23012,23021]
===
match
---
operator: , [60095,60096]
operator: , [60095,60096]
===
match
---
expr_stmt [65985,66009]
expr_stmt [65985,66009]
===
match
---
name: root_dag [74628,74636]
name: root_dag [74628,74636]
===
match
---
simple_stmt [2876,2909]
simple_stmt [2876,2909]
===
match
---
name: scenario [53295,53303]
name: scenario [53295,53303]
===
match
---
name: state [52589,52594]
name: state [52589,52594]
===
match
---
name: mark_success [78802,78814]
name: mark_success [78802,78814]
===
match
---
trailer [14475,14477]
trailer [14475,14477]
===
match
---
argument [40048,40076]
argument [40048,40076]
===
match
---
atom [16018,16032]
atom [16018,16032]
===
match
---
name: _evaluate_trigger_rule [34727,34749]
name: _evaluate_trigger_rule [34727,34749]
===
match
---
name: get_test_ti [52686,52697]
name: get_test_ti [52686,52697]
===
match
---
operator: = [62743,62744]
operator: = [62743,62744]
===
match
---
atom_expr [18629,18669]
atom_expr [18629,18669]
===
match
---
operator: = [66389,66390]
operator: = [66389,66390]
===
match
---
arglist [78384,78433]
arglist [78384,78433]
===
match
---
string: 'a test value' [57713,57727]
string: 'a test value' [57713,57727]
===
match
---
name: NONE [72741,72745]
name: NONE [72741,72745]
===
match
---
atom_expr [13764,13777]
atom_expr [13764,13777]
===
match
---
trailer [23969,23981]
trailer [23969,23981]
===
match
---
name: DAG [42530,42533]
name: DAG [42530,42533]
===
match
---
name: State [54782,54787]
name: State [54782,54787]
===
match
---
atom_expr [57546,57563]
atom_expr [57546,57563]
===
match
---
suite [18545,19785]
suite [18545,19785]
===
match
---
name: owner [20299,20304]
name: owner [20299,20304]
===
match
---
trailer [23000,23009]
trailer [23000,23009]
===
match
---
name: task_id [43083,43090]
name: task_id [43083,43090]
===
match
---
operator: { [16018,16019]
operator: { [16018,16019]
===
match
---
operator: == [44429,44431]
operator: == [44429,44431]
===
match
---
operator: , [58363,58364]
operator: , [58363,58364]
===
match
---
argument [18757,18778]
argument [18757,18778]
===
match
---
name: op1 [8071,8074]
name: op1 [8071,8074]
===
match
---
name: TI [24872,24874]
name: TI [24872,24874]
===
match
---
arglist [75835,75875]
arglist [75835,75875]
===
match
---
atom_expr [3179,3191]
atom_expr [3179,3191]
===
match
---
atom_expr [9935,10002]
atom_expr [9935,10002]
===
match
---
decorated [77983,78829]
decorated [77983,78829]
===
match
---
operator: , [61793,61794]
operator: , [61793,61794]
===
match
---
name: datetime [46204,46212]
name: datetime [46204,46212]
===
match
---
argument [42607,42630]
argument [42607,42630]
===
match
---
operator: , [22125,22126]
operator: , [22125,22126]
===
match
---
name: op [66452,66454]
name: op [66452,66454]
===
match
---
string: 'C' [74228,74231]
string: 'C' [74228,74231]
===
match
---
name: parameterized [55019,55032]
name: parameterized [55019,55032]
===
match
---
name: test_retry_handling [19794,19813]
name: test_retry_handling [19794,19813]
===
match
---
name: cast [898,902]
name: cast [898,902]
===
match
---
atom_expr [60912,60920]
atom_expr [60912,60920]
===
match
---
atom_expr [36020,36033]
atom_expr [36020,36033]
===
match
---
trailer [50119,50128]
trailer [50119,50128]
===
match
---
trailer [66820,66828]
trailer [66820,66828]
===
match
---
name: self [2968,2972]
name: self [2968,2972]
===
match
---
string: 'D' [72683,72686]
string: 'D' [72683,72686]
===
match
---
operator: = [76148,76149]
operator: = [76148,76149]
===
match
---
name: scenario [55160,55168]
name: scenario [55160,55168]
===
match
---
simple_stmt [76077,76136]
simple_stmt [76077,76136]
===
match
---
operator: , [70049,70050]
operator: , [70049,70050]
===
match
---
argument [13153,13168]
argument [13153,13168]
===
match
---
name: tis [16664,16667]
name: tis [16664,16667]
===
match
---
comparison [53456,53492]
comparison [53456,53492]
===
match
---
trailer [20459,20463]
trailer [20459,20463]
===
match
---
string: 'task_id' [69491,69500]
string: 'task_id' [69491,69500]
===
match
---
operator: = [16393,16394]
operator: = [16393,16394]
===
match
---
name: ti [29298,29300]
name: ti [29298,29300]
===
match
---
trailer [62564,62570]
trailer [62564,62570]
===
match
---
name: dag [7140,7143]
name: dag [7140,7143]
===
match
---
trailer [31921,31929]
trailer [31921,31929]
===
match
---
atom_expr [77198,77207]
atom_expr [77198,77207]
===
match
---
trailer [47207,47212]
trailer [47207,47212]
===
match
---
simple_stmt [52740,52755]
simple_stmt [52740,52755]
===
match
---
name: task [30545,30549]
name: task [30545,30549]
===
match
---
assert_stmt [53591,53670]
assert_stmt [53591,53670]
===
match
---
argument [41147,41167]
argument [41147,41167]
===
match
---
name: add [22830,22833]
name: add [22830,22833]
===
match
---
name: now [78428,78431]
name: now [78428,78431]
===
match
---
argument [14876,14892]
argument [14876,14892]
===
match
---
simple_stmt [49306,49363]
simple_stmt [49306,49363]
===
match
---
argument [5730,5753]
argument [5730,5753]
===
match
---
name: State [61320,61325]
name: State [61320,61325]
===
match
---
argument [42999,43052]
argument [42999,43052]
===
match
---
trailer [65128,65136]
trailer [65128,65136]
===
match
---
argument [76735,76752]
argument [76735,76752]
===
match
---
trailer [7231,7235]
trailer [7231,7235]
===
match
---
suite [12648,13778]
suite [12648,13778]
===
match
---
operator: , [48953,48954]
operator: , [48953,48954]
===
match
---
simple_stmt [70753,70791]
simple_stmt [70753,70791]
===
match
---
suite [9469,9527]
suite [9469,9527]
===
match
---
trailer [8016,8021]
trailer [8016,8021]
===
match
---
comparison [28898,28917]
comparison [28898,28917]
===
match
---
name: seconds [22834,22841]
name: seconds [22834,22841]
===
match
---
simple_stmt [23793,23844]
simple_stmt [23793,23844]
===
match
---
name: test_reschedule_handling_clear_reschedules [27986,28028]
name: test_reschedule_handling_clear_reschedules [27986,28028]
===
match
---
with_stmt [71269,71366]
with_stmt [71269,71366]
===
match
---
number: 10 [4140,4142]
number: 10 [4140,4142]
===
match
---
name: mock_on_failure_3 [63138,63155]
name: mock_on_failure_3 [63138,63155]
===
match
---
except_clause [20478,20501]
except_clause [20478,20501]
===
match
---
trailer [54661,54664]
trailer [54661,54664]
===
match
---
name: trs [29779,29782]
name: trs [29779,29782]
===
match
---
simple_stmt [46161,46226]
simple_stmt [46161,46226]
===
match
---
operator: + [44959,44960]
operator: + [44959,44960]
===
match
---
atom_expr [22722,22746]
atom_expr [22722,22746]
===
match
---
name: query [46863,46868]
name: query [46863,46868]
===
match
---
expr_stmt [50673,50853]
expr_stmt [50673,50853]
===
match
---
name: task [56763,56767]
name: task [56763,56767]
===
match
---
name: task_instance [71598,71611]
name: task_instance [71598,71611]
===
match
---
arglist [9843,9919]
arglist [9843,9919]
===
match
---
name: new_date [52707,52715]
name: new_date [52707,52715]
===
match
---
trailer [64825,64827]
trailer [64825,64827]
===
match
---
trailer [50327,50340]
trailer [50327,50340]
===
match
---
operator: = [36415,36416]
operator: = [36415,36416]
===
match
---
atom_expr [47912,47920]
atom_expr [47912,47920]
===
match
---
operator: = [49829,49830]
operator: = [49829,49830]
===
match
---
operator: , [65764,65765]
operator: , [65764,65765]
===
match
---
operator: = [30652,30653]
operator: = [30652,30653]
===
match
---
assert_stmt [9552,9581]
assert_stmt [9552,9581]
===
match
---
argument [75740,75755]
argument [75740,75755]
===
match
---
trailer [10953,10958]
trailer [10953,10958]
===
match
---
name: replace [5404,5411]
name: replace [5404,5411]
===
match
---
atom [48489,48509]
atom [48489,48509]
===
match
---
operator: , [49223,49224]
operator: , [49223,49224]
===
match
---
string: "task_instance" [62810,62825]
string: "task_instance" [62810,62825]
===
match
---
trailer [12941,12945]
trailer [12941,12945]
===
match
---
argument [67463,67476]
argument [67463,67476]
===
match
---
trailer [80284,80293]
trailer [80284,80293]
===
match
---
operator: , [14195,14196]
operator: , [14195,14196]
===
match
---
string: """         Test xcom_pull, using different filtering methods.         """ [36756,36830]
string: """         Test xcom_pull, using different filtering methods.         """ [36756,36830]
===
match
---
string: 'foo' [37227,37232]
string: 'foo' [37227,37232]
===
match
---
arglist [40120,40283]
arglist [40120,40283]
===
match
---
name: pendulum [52181,52189]
name: pendulum [52181,52189]
===
match
---
name: trs [29892,29895]
name: trs [29892,29895]
===
match
---
operator: , [59584,59585]
operator: , [59584,59585]
===
match
---
comparison [45264,45320]
comparison [45264,45320]
===
match
---
string: 'A' [73224,73227]
string: 'A' [73224,73227]
===
match
---
argument [73770,73787]
argument [73770,73787]
===
match
---
operator: , [62485,62486]
operator: , [62485,62486]
===
match
---
simple_stmt [40588,40623]
simple_stmt [40588,40623]
===
match
---
trailer [12079,12115]
trailer [12079,12115]
===
match
---
atom_expr [63034,63257]
atom_expr [63034,63257]
===
match
---
name: DAG [46558,46561]
name: DAG [46558,46561]
===
match
---
arglist [13037,13232]
arglist [13037,13232]
===
match
---
trailer [46868,46878]
trailer [46868,46878]
===
match
---
name: task [10574,10578]
name: task [10574,10578]
===
match
---
name: task_id [44141,44148]
name: task_id [44141,44148]
===
match
---
trailer [12370,12372]
trailer [12370,12372]
===
match
---
operator: = [45032,45033]
operator: = [45032,45033]
===
match
---
number: 2 [13217,13218]
number: 2 [13217,13218]
===
match
---
name: DAG [65409,65412]
name: DAG [65409,65412]
===
match
---
trailer [10091,10093]
trailer [10091,10093]
===
match
---
name: task [43765,43769]
name: task [43765,43769]
===
match
---
name: DAG [59979,59982]
name: DAG [59979,59982]
===
match
---
expr_stmt [53360,53439]
expr_stmt [53360,53439]
===
match
---
operator: , [14183,14184]
operator: , [14183,14184]
===
match
---
operator: , [18801,18802]
operator: , [18801,18802]
===
match
---
comparison [45336,45392]
comparison [45336,45392]
===
match
---
atom_expr [62573,62585]
atom_expr [62573,62585]
===
match
---
arglist [4174,4202]
arglist [4174,4202]
===
match
---
simple_stmt [25620,25641]
simple_stmt [25620,25641]
===
match
---
number: 0 [33304,33305]
number: 0 [33304,33305]
===
match
---
decorator [68930,69000]
decorator [68930,69000]
===
match
---
suite [64895,64925]
suite [64895,64925]
===
match
---
operator: = [34529,34530]
operator: = [34529,34530]
===
match
---
operator: , [37381,37382]
operator: , [37381,37382]
===
match
---
operator: = [74548,74549]
operator: = [74548,74549]
===
match
---
operator: , [31834,31835]
operator: , [31834,31835]
===
match
---
name: SUCCESS [71991,71998]
name: SUCCESS [71991,71998]
===
match
---
suite [47433,47686]
suite [47433,47686]
===
match
---
string: 'scheduler' [73040,73051]
string: 'scheduler' [73040,73051]
===
match
---
trailer [39000,39004]
trailer [39000,39004]
===
match
---
name: SUCCESS [52348,52355]
name: SUCCESS [52348,52355]
===
match
---
trailer [63047,63257]
trailer [63047,63257]
===
match
---
name: dag [43642,43645]
name: dag [43642,43645]
===
match
---
name: execution_date [48361,48375]
name: execution_date [48361,48375]
===
match
---
atom_expr [50292,50315]
atom_expr [50292,50315]
===
match
---
string: 'test_mark_non_runnable_task_as_success' [12953,12993]
string: 'test_mark_non_runnable_task_as_success' [12953,12993]
===
match
---
name: context_arg_1 [62078,62091]
name: context_arg_1 [62078,62091]
===
match
---
operator: , [30049,30050]
operator: , [30049,30050]
===
match
---
simple_stmt [21480,21570]
simple_stmt [21480,21570]
===
match
---
name: priority_weight [76784,76799]
name: priority_weight [76784,76799]
===
match
---
operator: , [16507,16508]
operator: , [16507,16508]
===
match
---
simple_stmt [40716,40756]
simple_stmt [40716,40756]
===
match
---
operator: , [59125,59126]
operator: , [59125,59126]
===
match
---
operator: == [77383,77385]
operator: == [77383,77385]
===
match
---
operator: = [68346,68347]
operator: = [68346,68347]
===
match
---
assert_stmt [35710,35746]
assert_stmt [35710,35746]
===
match
---
string: 'execution_date' [46970,46986]
string: 'execution_date' [46970,46986]
===
match
---
argument [51779,51814]
argument [51779,51814]
===
match
---
trailer [76313,76333]
trailer [76313,76333]
===
match
---
arglist [52481,52543]
arglist [52481,52543]
===
match
---
atom_expr [20883,20895]
atom_expr [20883,20895]
===
match
---
operator: = [66781,66782]
operator: = [66781,66782]
===
match
---
suite [78888,79472]
suite [78888,79472]
===
match
---
name: execution_date [54205,54219]
name: execution_date [54205,54219]
===
match
---
atom_expr [78447,78455]
atom_expr [78447,78455]
===
match
---
name: exec_date [37190,37199]
name: exec_date [37190,37199]
===
match
---
trailer [26259,26270]
trailer [26259,26270]
===
match
---
operator: , [70540,70541]
operator: , [70540,70541]
===
match
---
arith_expr [5284,5325]
arith_expr [5284,5325]
===
match
---
name: utcnow [64819,64825]
name: utcnow [64819,64825]
===
match
---
name: state [13755,13760]
name: state [13755,13760]
===
match
---
operator: , [11320,11321]
operator: , [11320,11321]
===
match
---
operator: , [36337,36338]
operator: , [36337,36338]
===
match
---
operator: , [32435,32436]
operator: , [32435,32436]
===
match
---
name: state [65988,65993]
name: state [65988,65993]
===
match
---
string: 'op' [79035,79039]
string: 'op' [79035,79039]
===
match
---
operator: , [57882,57883]
operator: , [57882,57883]
===
match
---
expr_stmt [53810,53879]
expr_stmt [53810,53879]
===
match
---
name: task [60086,60090]
name: task [60086,60090]
===
match
---
argument [28602,28611]
argument [28602,28611]
===
match
---
name: start_date [61500,61510]
name: start_date [61500,61510]
===
match
---
argument [78684,78699]
argument [78684,78699]
===
match
---
operator: = [21625,21626]
operator: = [21625,21626]
===
match
---
argument [58576,58599]
argument [58576,58599]
===
match
---
dictorsetmaker [72589,72643]
dictorsetmaker [72589,72643]
===
match
---
name: dag [9276,9279]
name: dag [9276,9279]
===
match
---
operator: , [70462,70463]
operator: , [70462,70463]
===
match
---
name: dag [78355,78358]
name: dag [78355,78358]
===
match
---
operator: = [61143,61144]
operator: = [61143,61144]
===
match
---
operator: , [53948,53949]
operator: , [53948,53949]
===
match
---
operator: == [20615,20617]
operator: == [20615,20617]
===
match
---
argument [40120,40139]
argument [40120,40139]
===
match
---
atom_expr [55534,55547]
atom_expr [55534,55547]
===
match
---
operator: = [35279,35280]
operator: = [35279,35280]
===
match
---
trailer [40411,40544]
trailer [40411,40544]
===
match
---
expr_stmt [71090,71145]
expr_stmt [71090,71145]
===
match
---
name: ti_list [55589,55596]
name: ti_list [55589,55596]
===
match
---
name: read_data [49325,49334]
name: read_data [49325,49334]
===
match
---
arglist [38869,38978]
arglist [38869,38978]
===
match
---
operator: = [30808,30809]
operator: = [30808,30809]
===
match
---
name: dag [78257,78260]
name: dag [78257,78260]
===
match
---
name: period [22809,22815]
name: period [22809,22815]
===
match
---
trailer [16388,16434]
trailer [16388,16434]
===
match
---
name: ti [23737,23739]
name: ti [23737,23739]
===
match
---
atom_expr [50461,50478]
atom_expr [50461,50478]
===
match
---
name: test_previous_ti [53223,53239]
name: test_previous_ti [53223,53239]
===
match
---
operator: = [36307,36308]
operator: = [36307,36308]
===
match
---
trailer [53930,53968]
trailer [53930,53968]
===
match
---
name: environ [65321,65328]
name: environ [65321,65328]
===
match
---
expr_stmt [60845,60903]
expr_stmt [60845,60903]
===
match
---
arglist [27816,27869]
arglist [27816,27869]
===
match
---
name: ti [35344,35346]
name: ti [35344,35346]
===
match
---
assert_stmt [61301,61333]
assert_stmt [61301,61333]
===
match
---
name: executor_config [15568,15583]
name: executor_config [15568,15583]
===
match
---
name: session [45231,45238]
name: session [45231,45238]
===
match
---
argument [46169,46178]
argument [46169,46178]
===
match
---
simple_stmt [60220,60292]
simple_stmt [60220,60292]
===
match
---
name: ti [51276,51278]
name: ti [51276,51278]
===
match
---
trailer [26963,27020]
trailer [26963,27020]
===
match
---
name: AirflowException [29330,29346]
name: AirflowException [29330,29346]
===
match
---
name: DAG [58127,58130]
name: DAG [58127,58130]
===
match
---
trailer [26205,26216]
trailer [26205,26216]
===
match
---
arglist [78550,78700]
arglist [78550,78700]
===
match
---
assert_stmt [7317,7337]
assert_stmt [7317,7337]
===
match
---
string: 'echo {{dag.dag_id}}; exit 1' [20157,20186]
string: 'echo {{dag.dag_id}}; exit 1' [20157,20186]
===
match
---
operator: == [77283,77285]
operator: == [77283,77285]
===
match
---
atom_expr [53322,53334]
atom_expr [53322,53334]
===
match
---
comparison [29682,29714]
comparison [29682,29714]
===
match
---
name: State [73194,73199]
name: State [73194,73199]
===
match
---
trailer [22152,22192]
trailer [22152,22192]
===
match
---
number: 0 [38721,38722]
number: 0 [38721,38722]
===
match
---
operator: = [52807,52808]
operator: = [52807,52808]
===
match
---
name: scheduler_job [74594,74607]
name: scheduler_job [74594,74607]
===
match
---
name: create_session [68375,68389]
name: create_session [68375,68389]
===
match
---
operator: , [32604,32605]
operator: , [32604,32605]
===
match
---
trailer [20349,20358]
trailer [20349,20358]
===
match
---
name: expect_state [34143,34155]
name: expect_state [34143,34155]
===
match
---
simple_stmt [16444,16624]
simple_stmt [16444,16624]
===
match
---
name: UPSTREAM_FAILED [32378,32393]
name: UPSTREAM_FAILED [32378,32393]
===
match
---
simple_stmt [76027,76069]
simple_stmt [76027,76069]
===
match
---
simple_stmt [71520,71579]
simple_stmt [71520,71579]
===
match
---
operator: , [17331,17332]
operator: , [17331,17332]
===
match
---
trailer [17631,17637]
trailer [17631,17637]
===
match
---
string: 'one_success' [32016,32029]
string: 'one_success' [32016,32029]
===
match
---
name: datetime [13202,13210]
name: datetime [13202,13210]
===
match
---
trailer [51506,51512]
trailer [51506,51512]
===
match
---
name: DEFAULT_DATE [9732,9744]
name: DEFAULT_DATE [9732,9744]
===
match
---
arglist [37097,37144]
arglist [37097,37144]
===
match
---
operator: = [50231,50232]
operator: = [50231,50232]
===
match
---
name: State [19646,19651]
name: State [19646,19651]
===
match
---
expr_stmt [47865,47893]
expr_stmt [47865,47893]
===
match
---
operator: = [41026,41027]
operator: = [41026,41027]
===
match
---
name: next_retry_datetime [22953,22972]
name: next_retry_datetime [22953,22972]
===
match
---
argument [38564,38583]
argument [38564,38583]
===
match
---
name: DEFAULT_DATE [68024,68036]
name: DEFAULT_DATE [68024,68036]
===
match
---
name: test_refresh_from_task [76609,76631]
name: test_refresh_from_task [76609,76631]
===
match
---
name: ti [29566,29568]
name: ti [29566,29568]
===
match
---
name: dag_run [71400,71407]
name: dag_run [71400,71407]
===
match
---
param [50427,50431]
param [50427,50431]
===
match
---
simple_stmt [56777,56834]
simple_stmt [56777,56834]
===
match
---
name: task [20546,20550]
name: task [20546,20550]
===
match
---
name: ti [27266,27268]
name: ti [27266,27268]
===
match
---
trailer [78427,78431]
trailer [78427,78431]
===
match
---
number: 0 [11458,11459]
number: 0 [11458,11459]
===
match
---
atom_expr [19414,19432]
atom_expr [19414,19432]
===
match
---
string: 'metadata' [69297,69307]
string: 'metadata' [69297,69307]
===
match
---
argument [20552,20584]
argument [20552,20584]
===
match
---
suite [3748,3869]
suite [3748,3869]
===
match
---
number: 240 [22614,22617]
number: 240 [22614,22617]
===
match
---
name: state [13559,13564]
name: state [13559,13564]
===
match
---
trailer [10173,10177]
trailer [10173,10177]
===
match
---
suite [35888,35934]
suite [35888,35934]
===
match
---
trailer [77913,77920]
trailer [77913,77920]
===
match
---
name: ti2 [37463,37466]
name: ti2 [37463,37466]
===
match
---
operator: = [60090,60091]
operator: = [60090,60091]
===
match
---
operator: = [4181,4182]
operator: = [4181,4182]
===
match
---
atom_expr [14253,14270]
atom_expr [14253,14270]
===
match
---
trailer [79786,79837]
trailer [79786,79837]
===
match
---
suite [77171,77208]
suite [77171,77208]
===
match
---
assert_stmt [62071,62128]
assert_stmt [62071,62128]
===
match
---
trailer [73273,73289]
trailer [73273,73289]
===
match
---
trailer [2800,2807]
trailer [2800,2807]
===
match
---
operator: = [36392,36393]
operator: = [36392,36393]
===
match
---
name: task [49252,49256]
name: task [49252,49256]
===
match
---
argument [63883,63926]
argument [63883,63926]
===
match
---
trailer [36962,36971]
trailer [36962,36971]
===
match
---
name: next_retry_datetime [23863,23882]
name: next_retry_datetime [23863,23882]
===
match
---
atom_expr [70001,70009]
atom_expr [70001,70009]
===
match
---
name: ti_list [53509,53516]
name: ti_list [53509,53516]
===
match
---
name: expand [77998,78004]
name: expand [77998,78004]
===
match
---
string: 'hello' [41342,41349]
string: 'hello' [41342,41349]
===
match
---
name: dag [78359,78362]
name: dag [78359,78362]
===
match
---
trailer [44296,44307]
trailer [44296,44307]
===
match
---
atom_expr [69055,69113]
atom_expr [69055,69113]
===
match
---
trailer [9358,9365]
trailer [9358,9365]
===
match
---
dotted_name [76542,76565]
dotted_name [76542,76565]
===
match
---
testlist_comp [33287,33333]
testlist_comp [33287,33333]
===
match
---
suite [64357,64971]
suite [64357,64971]
===
match
---
trailer [39459,39463]
trailer [39459,39463]
===
match
---
operator: , [13578,13579]
operator: , [13578,13579]
===
match
---
name: models [34277,34283]
name: models [34277,34283]
===
match
---
name: dag [7304,7307]
name: dag [7304,7307]
===
match
---
expr_stmt [62729,62776]
expr_stmt [62729,62776]
===
match
---
operator: , [78393,78394]
operator: , [78393,78394]
===
match
---
operator: = [21704,21705]
operator: = [21704,21705]
===
match
---
operator: = [24720,24721]
operator: = [24720,24721]
===
match
---
trailer [8644,8679]
trailer [8644,8679]
===
match
---
trailer [54138,54154]
trailer [54138,54154]
===
match
---
trailer [61842,61881]
trailer [61842,61881]
===
match
---
name: ti [41134,41136]
name: ti [41134,41136]
===
match
---
assert_stmt [29502,29546]
assert_stmt [29502,29546]
===
match
---
trailer [36060,36068]
trailer [36060,36068]
===
match
---
operator: == [21467,21469]
operator: == [21467,21469]
===
match
---
trailer [45213,45217]
trailer [45213,45217]
===
match
---
atom_expr [11610,11625]
atom_expr [11610,11625]
===
match
---
operator: = [28364,28365]
operator: = [28364,28365]
===
match
---
operator: , [33035,33036]
operator: , [33035,33036]
===
match
---
simple_stmt [28926,28952]
simple_stmt [28926,28952]
===
match
---
trailer [7530,7565]
trailer [7530,7565]
===
match
---
operator: = [26177,26178]
operator: = [26177,26178]
===
match
---
trailer [73595,73601]
trailer [73595,73601]
===
match
---
name: start_date [6547,6557]
name: start_date [6547,6557]
===
match
---
name: ti [23954,23956]
name: ti [23954,23956]
===
match
---
simple_stmt [53295,53351]
simple_stmt [53295,53351]
===
match
---
name: body [49564,49568]
name: body [49564,49568]
===
match
---
trailer [51317,51340]
trailer [51317,51340]
===
match
---
operator: = [5553,5554]
operator: = [5553,5554]
===
match
---
atom_expr [72752,72762]
atom_expr [72752,72762]
===
match
---
try_stmt [29273,29411]
try_stmt [29273,29411]
===
match
---
parameters [19008,19012]
parameters [19008,19012]
===
match
---
string: 'dag' [7418,7423]
string: 'dag' [7418,7423]
===
match
---
name: DEFAULT_DATE [67851,67863]
name: DEFAULT_DATE [67851,67863]
===
match
---
name: session [73615,73622]
name: session [73615,73622]
===
match
---
name: utcnow [76187,76193]
name: utcnow [76187,76193]
===
match
---
trailer [23986,23995]
trailer [23986,23995]
===
match
---
trailer [50059,50075]
trailer [50059,50075]
===
match
---
operator: , [42399,42400]
operator: , [42399,42400]
===
match
---
atom_expr [52971,53012]
atom_expr [52971,53012]
===
match
---
atom_expr [14768,15037]
atom_expr [14768,15037]
===
match
---
name: timezone [23825,23833]
name: timezone [23825,23833]
===
match
---
operator: = [6395,6396]
operator: = [6395,6396]
===
match
---
name: on_failure_callback [62357,62376]
name: on_failure_callback [62357,62376]
===
match
---
operator: = [79907,79908]
operator: = [79907,79908]
===
match
---
name: SUCCESS [61326,61333]
name: SUCCESS [61326,61333]
===
match
---
atom_expr [20911,20925]
atom_expr [20911,20925]
===
match
---
atom [52809,53163]
atom [52809,53163]
===
match
---
simple_stmt [28891,28918]
simple_stmt [28891,28918]
===
match
---
operator: -> [51993,51995]
operator: -> [51993,51995]
===
match
---
name: dag [17222,17225]
name: dag [17222,17225]
===
match
---
number: 10 [65550,65552]
number: 10 [65550,65552]
===
match
---
operator: == [29524,29526]
operator: == [29524,29526]
===
match
---
string: 'downstream' [34366,34378]
string: 'downstream' [34366,34378]
===
match
---
name: State [33046,33051]
name: State [33046,33051]
===
match
---
atom_expr [2850,2867]
atom_expr [2850,2867]
===
match
---
trailer [57246,57253]
trailer [57246,57253]
===
match
---
atom_expr [76659,76939]
atom_expr [76659,76939]
===
match
---
atom_expr [17049,17109]
atom_expr [17049,17109]
===
match
---
name: try_number [28936,28946]
name: try_number [28936,28946]
===
match
---
name: task_instance_a [74751,74766]
name: task_instance_a [74751,74766]
===
match
---
trailer [12394,12400]
trailer [12394,12400]
===
match
---
name: base [1652,1656]
name: base [1652,1656]
===
match
---
suite [14559,15187]
suite [14559,15187]
===
match
---
operator: , [16349,16350]
operator: , [16349,16350]
===
match
---
name: task [59829,59833]
name: task [59829,59833]
===
match
---
name: try_number [21456,21466]
name: try_number [21456,21466]
===
match
---
name: expected_state [25310,25324]
name: expected_state [25310,25324]
===
match
---
operator: = [52099,52100]
operator: = [52099,52100]
===
match
---
trailer [52743,52750]
trailer [52743,52750]
===
match
---
operator: = [75339,75340]
operator: = [75339,75340]
===
match
---
param [48114,48129]
param [48114,48129]
===
match
---
atom [52564,52566]
atom [52564,52566]
===
match
---
operator: , [32283,32284]
operator: , [32283,32284]
===
match
---
trailer [53140,53148]
trailer [53140,53148]
===
match
---
simple_stmt [79133,79158]
simple_stmt [79133,79158]
===
match
---
name: DAG [15389,15392]
name: DAG [15389,15392]
===
match
---
name: callback_ran [2922,2934]
name: callback_ran [2922,2934]
===
match
---
operator: = [38161,38162]
operator: = [38161,38162]
===
match
---
operator: = [22086,22087]
operator: = [22086,22087]
===
match
---
argument [38153,38192]
argument [38153,38192]
===
match
---
name: self [15243,15247]
name: self [15243,15247]
===
match
---
string: "image" [76900,76907]
string: "image" [76900,76907]
===
match
---
number: 0 [33796,33797]
number: 0 [33796,33797]
===
match
---
name: DAG [76033,76036]
name: DAG [76033,76036]
===
match
---
name: dag [4347,4350]
name: dag [4347,4350]
===
match
---
name: SCHEDULED [71934,71943]
name: SCHEDULED [71934,71943]
===
match
---
name: test_does_not_retry_on_airflow_fail_exception [63634,63679]
name: test_does_not_retry_on_airflow_fail_exception [63634,63679]
===
match
---
trailer [22864,22877]
trailer [22864,22877]
===
match
---
operator: - [4566,4567]
operator: - [4566,4567]
===
match
---
operator: , [14858,14859]
operator: , [14858,14859]
===
match
---
name: dag_id [73781,73787]
name: dag_id [73781,73787]
===
match
---
operator: , [27884,27885]
operator: , [27884,27885]
===
match
---
expr_stmt [75187,75216]
expr_stmt [75187,75216]
===
match
---
name: delete [71357,71363]
name: delete [71357,71363]
===
match
---
name: start_date [4384,4394]
name: start_date [4384,4394]
===
match
---
operator: = [62276,62277]
operator: = [62276,62277]
===
match
---
simple_stmt [36839,37004]
simple_stmt [36839,37004]
===
match
---
trailer [27588,27643]
trailer [27588,27643]
===
match
---
simple_stmt [2762,2788]
simple_stmt [2762,2788]
===
match
---
operator: == [5208,5210]
operator: == [5208,5210]
===
match
---
operator: = [23258,23259]
operator: = [23258,23259]
===
match
---
name: parse_qs [46722,46730]
name: parse_qs [46722,46730]
===
match
---
operator: , [49127,49128]
operator: , [49127,49128]
===
match
---
trailer [63622,63624]
trailer [63622,63624]
===
match
---
name: _prev_dates_param_list [53191,53213]
name: _prev_dates_param_list [53191,53213]
===
match
---
name: now [47850,47853]
name: now [47850,47853]
===
match
---
name: task_type [80073,80082]
name: task_type [80073,80082]
===
match
---
name: flush [73934,73939]
name: flush [73934,73939]
===
match
---
argument [22047,22062]
argument [22047,22062]
===
match
---
name: state [45126,45131]
name: state [45126,45131]
===
match
---
argument [23535,23565]
argument [23535,23565]
===
match
---
name: mark_success_url [46769,46785]
name: mark_success_url [46769,46785]
===
match
---
expr_stmt [11892,11976]
expr_stmt [11892,11976]
===
match
---
operator: , [65553,65554]
operator: , [65553,65554]
===
match
---
name: expand [54348,54354]
name: expand [54348,54354]
===
match
---
operator: = [78645,78646]
operator: = [78645,78646]
===
match
---
expr_stmt [27030,27054]
expr_stmt [27030,27054]
===
match
---
atom_expr [76083,76135]
atom_expr [76083,76135]
===
match
---
name: Optional [2669,2677]
name: Optional [2669,2677]
===
match
---
arglist [7657,7699]
arglist [7657,7699]
===
match
---
trailer [54510,54518]
trailer [54510,54518]
===
match
---
operator: = [4552,4553]
operator: = [4552,4553]
===
match
---
trailer [11870,11879]
trailer [11870,11879]
===
match
---
name: task [58667,58671]
name: task [58667,58671]
===
match
---
string: 'test_post_execute_dag' [42541,42564]
string: 'test_post_execute_dag' [42541,42564]
===
match
---
trailer [27181,27183]
trailer [27181,27183]
===
match
---
operator: = [37795,37796]
operator: = [37795,37796]
===
match
---
atom_expr [50358,50369]
atom_expr [50358,50369]
===
match
---
trailer [46524,46543]
trailer [46524,46543]
===
match
---
atom_expr [51315,51342]
atom_expr [51315,51342]
===
match
---
name: test_run_pooling_task [13787,13808]
name: test_run_pooling_task [13787,13808]
===
match
---
operator: = [13954,13955]
operator: = [13954,13955]
===
match
---
trailer [55848,55934]
trailer [55848,55934]
===
match
---
name: dag_id [14717,14723]
name: dag_id [14717,14723]
===
match
---
operator: = [22644,22645]
operator: = [22644,22645]
===
match
---
import_from [1134,1170]
import_from [1134,1170]
===
match
---
atom_expr [72401,72411]
atom_expr [72401,72411]
===
match
---
name: self [61363,61367]
name: self [61363,61367]
===
match
---
name: dag [15751,15754]
name: dag [15751,15754]
===
match
---
trailer [30745,30753]
trailer [30745,30753]
===
match
---
assert_stmt [19627,19664]
assert_stmt [19627,19664]
===
match
---
name: db [14458,14460]
name: db [14458,14460]
===
match
---
argument [46662,46671]
argument [46662,46671]
===
match
---
trailer [21225,21237]
trailer [21225,21237]
===
match
---
atom_expr [7819,7830]
atom_expr [7819,7830]
===
match
---
atom_expr [15723,15740]
atom_expr [15723,15740]
===
match
---
expr_stmt [3060,3088]
expr_stmt [3060,3088]
===
match
---
name: datetime [65526,65534]
name: datetime [65526,65534]
===
match
---
operator: , [9890,9891]
operator: , [9890,9891]
===
match
---
operator: = [37104,37105]
operator: = [37104,37105]
===
match
---
name: airflow [1636,1643]
name: airflow [1636,1643]
===
match
---
atom_expr [79201,79400]
atom_expr [79201,79400]
===
match
---
operator: , [18160,18161]
operator: , [18160,18161]
===
match
---
atom_expr [62202,62218]
atom_expr [62202,62218]
===
match
---
arglist [51764,51831]
arglist [51764,51831]
===
match
---
simple_stmt [15751,15931]
simple_stmt [15751,15931]
===
match
---
simple_stmt [41257,41326]
simple_stmt [41257,41326]
===
match
---
operator: , [31018,31019]
operator: , [31018,31019]
===
match
---
name: State [53851,53856]
name: State [53851,53856]
===
match
---
operator: = [28636,28637]
operator: = [28636,28637]
===
match
---
trailer [54599,54637]
trailer [54599,54637]
===
match
---
trailer [79297,79305]
trailer [79297,79305]
===
match
---
name: session [70803,70810]
name: session [70803,70810]
===
match
---
expr_stmt [6325,6375]
expr_stmt [6325,6375]
===
match
---
simple_stmt [77403,77453]
simple_stmt [77403,77453]
===
match
---
assert_stmt [80050,80101]
assert_stmt [80050,80101]
===
match
---
operator: , [51165,51166]
operator: , [51165,51166]
===
match
---
name: start_date [24797,24807]
name: start_date [24797,24807]
===
match
---
testlist_comp [78073,78108]
testlist_comp [78073,78108]
===
match
---
trailer [12312,12349]
trailer [12312,12349]
===
match
---
argument [6460,6485]
argument [6460,6485]
===
match
---
operator: , [63155,63156]
operator: , [63155,63156]
===
match
---
name: test_set_task_dates [3927,3946]
name: test_set_task_dates [3927,3946]
===
match
---
operator: , [15652,15653]
operator: , [15652,15653]
===
match
---
suite [29277,29307]
suite [29277,29307]
===
match
---
arglist [7418,7448]
arglist [7418,7448]
===
match
---
atom_expr [62644,62672]
atom_expr [62644,62672]
===
match
---
trailer [22463,22474]
trailer [22463,22474]
===
match
---
number: 0 [13229,13230]
number: 0 [13229,13230]
===
match
---
argument [28537,28554]
argument [28537,28554]
===
match
---
name: dag [78515,78518]
name: dag [78515,78518]
===
match
---
arglist [30794,30894]
arglist [30794,30894]
===
match
---
trailer [78463,78471]
trailer [78463,78471]
===
match
---
arglist [78341,78362]
arglist [78341,78362]
===
match
---
operator: = [52341,52342]
operator: = [52341,52342]
===
match
---
name: ti [19230,19232]
name: ti [19230,19232]
===
match
---
trailer [7820,7828]
trailer [7820,7828]
===
match
---
operator: , [33743,33744]
operator: , [33743,33744]
===
match
---
name: op2 [8112,8115]
name: op2 [8112,8115]
===
match
---
comparison [61308,61333]
comparison [61308,61333]
===
match
---
param [55105,55110]
param [55105,55110]
===
match
---
operator: , [33886,33887]
operator: , [33886,33887]
===
match
---
name: dag_id [51764,51770]
name: dag_id [51764,51770]
===
match
---
argument [9789,9802]
argument [9789,9802]
===
match
---
simple_stmt [29423,29444]
simple_stmt [29423,29444]
===
match
---
argument [68009,68036]
argument [68009,68036]
===
match
---
operator: , [52233,52234]
operator: , [52233,52234]
===
match
---
operator: = [7515,7516]
operator: = [7515,7516]
===
match
---
operator: = [28770,28771]
operator: = [28770,28771]
===
match
---
name: SUCCESS [71914,71921]
name: SUCCESS [71914,71921]
===
match
---
name: Union [51612,51617]
name: Union [51612,51617]
===
match
---
string: 'test_xcom_2' [37968,37981]
string: 'test_xcom_2' [37968,37981]
===
match
---
name: task_id [51862,51869]
name: task_id [51862,51869]
===
match
---
trailer [11583,11585]
trailer [11583,11585]
===
match
---
simple_stmt [46059,46101]
simple_stmt [46059,46101]
===
match
---
assert_stmt [29727,29766]
assert_stmt [29727,29766]
===
match
---
name: start_date [34609,34619]
name: start_date [34609,34619]
===
match
---
argument [46076,46099]
argument [46076,46099]
===
match
---
trailer [54496,54503]
trailer [54496,54503]
===
match
---
name: PythonSensor [1718,1730]
name: PythonSensor [1718,1730]
===
match
---
name: state [17632,17637]
name: state [17632,17637]
===
match
---
param [3887,3891]
param [3887,3891]
===
match
---
operator: = [52055,52056]
operator: = [52055,52056]
===
match
---
name: task [47755,47759]
name: task [47755,47759]
===
match
---
name: task_id [74988,74995]
name: task_id [74988,74995]
===
match
---
atom_expr [30837,30850]
atom_expr [30837,30850]
===
match
---
name: List [51675,51679]
name: List [51675,51679]
===
match
---
operator: = [14806,14807]
operator: = [14806,14807]
===
match
---
trailer [44140,44190]
trailer [44140,44190]
===
match
---
name: get_task_instance [75133,75150]
name: get_task_instance [75133,75150]
===
match
---
operator: , [33423,33424]
operator: , [33423,33424]
===
match
---
name: dag [7696,7699]
name: dag [7696,7699]
===
match
---
argument [52218,52233]
argument [52218,52233]
===
match
---
name: ti [17475,17477]
name: ti [17475,17477]
===
match
---
name: tests [2395,2400]
name: tests [2395,2400]
===
match
---
atom_expr [22849,22877]
atom_expr [22849,22877]
===
match
---
arglist [49382,49437]
arglist [49382,49437]
===
match
---
suite [57981,58415]
suite [57981,58415]
===
match
---
operator: = [9235,9236]
operator: = [9235,9236]
===
match
---
arglist [63374,63417]
arglist [63374,63417]
===
match
---
expr_stmt [70753,70790]
expr_stmt [70753,70790]
===
match
---
name: op4 [8269,8272]
name: op4 [8269,8272]
===
match
---
name: task [64784,64788]
name: task [64784,64788]
===
match
---
name: schedule_interval [54600,54617]
name: schedule_interval [54600,54617]
===
match
---
name: dag [9027,9030]
name: dag [9027,9030]
===
match
---
name: start_date [66344,66354]
name: start_date [66344,66354]
===
match
---
name: timezone [57238,57246]
name: timezone [57238,57246]
===
match
---
operator: = [13523,13524]
operator: = [13523,13524]
===
match
---
operator: = [36349,36350]
operator: = [36349,36350]
===
match
---
name: dag [8081,8084]
name: dag [8081,8084]
===
match
---
simple_stmt [52784,53164]
simple_stmt [52784,53164]
===
match
---
atom_expr [74723,74736]
atom_expr [74723,74736]
===
match
---
comparison [68771,68800]
comparison [68771,68800]
===
match
---
operator: -> [51691,51693]
operator: -> [51691,51693]
===
match
---
suite [59965,60292]
suite [59965,60292]
===
match
---
name: PythonOperator [74205,74219]
name: PythonOperator [74205,74219]
===
match
---
string: 'op_1' [5791,5797]
string: 'op_1' [5791,5797]
===
match
---
name: mode [24574,24578]
name: mode [24574,24578]
===
match
---
simple_stmt [23248,23291]
simple_stmt [23248,23291]
===
match
---
operator: , [41782,41783]
operator: , [41782,41783]
===
match
---
name: dag [5160,5163]
name: dag [5160,5163]
===
match
---
name: create_session [70712,70726]
name: create_session [70712,70726]
===
match
---
name: mock_send_email [48515,48530]
name: mock_send_email [48515,48530]
===
match
---
operator: , [27100,27101]
operator: , [27100,27101]
===
match
---
assert_stmt [46856,46890]
assert_stmt [46856,46890]
===
match
---
operator: = [50459,50460]
operator: = [50459,50460]
===
match
---
operator: , [51777,51778]
operator: , [51777,51778]
===
match
---
operator: { [34509,34510]
operator: { [34509,34510]
===
match
---
operator: , [14199,14200]
operator: , [14199,14200]
===
match
---
number: 0 [15660,15661]
number: 0 [15660,15661]
===
match
---
shift_expr [43765,43778]
shift_expr [43765,43778]
===
match
---
operator: = [49123,49124]
operator: = [49123,49124]
===
match
---
trailer [54858,54879]
trailer [54858,54879]
===
match
---
name: State [72824,72829]
name: State [72824,72829]
===
match
---
atom_expr [57238,57255]
atom_expr [57238,57255]
===
match
---
atom_expr [75229,75271]
atom_expr [75229,75271]
===
match
---
name: validate_ti_states [75816,75834]
name: validate_ti_states [75816,75834]
===
match
---
name: dag [38601,38604]
name: dag [38601,38604]
===
match
---
trailer [74347,74393]
trailer [74347,74393]
===
match
---
name: date [22437,22441]
name: date [22437,22441]
===
match
---
name: task_id [10479,10486]
name: task_id [10479,10486]
===
match
---
operator: = [11486,11487]
operator: = [11486,11487]
===
match
---
string: 'task' [43091,43097]
string: 'task' [43091,43097]
===
match
---
suite [10105,10163]
suite [10105,10163]
===
match
---
name: now [46521,46524]
name: now [46521,46524]
===
match
---
name: MagicMock [61557,61566]
name: MagicMock [61557,61566]
===
match
---
number: 0 [32285,32286]
number: 0 [32285,32286]
===
match
---
assert_stmt [7811,7891]
assert_stmt [7811,7891]
===
match
---
name: test_post_execute_hook [42055,42077]
name: test_post_execute_hook [42055,42077]
===
match
---
argument [34493,34513]
argument [34493,34513]
===
match
---
simple_stmt [4867,5082]
simple_stmt [4867,5082]
===
match
---
name: refresh_from_task [77011,77028]
name: refresh_from_task [77011,77028]
===
match
---
atom_expr [55335,55390]
atom_expr [55335,55390]
===
match
---
string: 'airflow' [38654,38663]
string: 'airflow' [38654,38663]
===
match
---
operator: , [29068,29069]
operator: , [29068,29069]
===
match
---
expr_stmt [35471,35555]
expr_stmt [35471,35555]
===
match
---
expr_stmt [22261,22292]
expr_stmt [22261,22292]
===
match
---
testlist_comp [32950,32995]
testlist_comp [32950,32995]
===
match
---
operator: , [22115,22116]
operator: , [22115,22116]
===
match
---
string: """         Test assigning Operators to Dags, including deferred assignment         """ [6643,6730]
string: """         Test assigning Operators to Dags, including deferred assignment         """ [6643,6730]
===
match
---
trailer [13947,13979]
trailer [13947,13979]
===
match
---
name: self [65660,65664]
name: self [65660,65664]
===
match
---
atom_expr [45341,45392]
atom_expr [45341,45392]
===
match
---
trailer [34572,34584]
trailer [34572,34584]
===
match
---
operator: = [26213,26214]
operator: = [26213,26214]
===
match
---
arglist [46562,46592]
arglist [46562,46592]
===
match
---
arglist [65426,65554]
arglist [65426,65554]
===
match
---
name: email [49550,49555]
name: email [49550,49555]
===
match
---
name: run_ti_and_assert [26829,26846]
name: run_ti_and_assert [26829,26846]
===
match
---
name: pool [3778,3782]
name: pool [3778,3782]
===
match
---
operator: , [33038,33039]
operator: , [33038,33039]
===
match
---
operator: = [57207,57208]
operator: = [57207,57208]
===
match
---
operator: , [72745,72746]
operator: , [72745,72746]
===
match
---
assert_stmt [22658,22679]
assert_stmt [22658,22679]
===
match
---
operator: , [33311,33312]
operator: , [33311,33312]
===
match
---
name: task [79070,79074]
name: task [79070,79074]
===
match
---
fstring_string: runme_ [34503,34509]
fstring_string: runme_ [34503,34509]
===
match
---
name: self [54424,54428]
name: self [54424,54428]
===
match
---
simple_stmt [74929,74997]
simple_stmt [74929,74997]
===
match
---
operator: = [11673,11674]
operator: = [11673,11674]
===
match
---
name: self [77941,77945]
name: self [77941,77945]
===
match
---
name: BashOperator [68241,68253]
name: BashOperator [68241,68253]
===
match
---
operator: = [37691,37692]
operator: = [37691,37692]
===
match
---
name: dag [48981,48984]
name: dag [48981,48984]
===
match
---
operator: { [72375,72376]
operator: { [72375,72376]
===
match
---
name: i [7835,7836]
name: i [7835,7836]
===
match
---
name: dag_id [48998,49004]
name: dag_id [48998,49004]
===
match
---
tfpdef [51593,51648]
tfpdef [51593,51648]
===
match
---
name: AirflowException [8301,8317]
name: AirflowException [8301,8317]
===
match
---
argument [5549,5563]
argument [5549,5563]
===
match
---
operator: == [4842,4844]
operator: == [4842,4844]
===
match
---
atom_expr [73744,73878]
atom_expr [73744,73878]
===
match
---
simple_stmt [47755,47790]
simple_stmt [47755,47790]
===
match
---
operator: = [50738,50739]
operator: = [50738,50739]
===
match
---
parameters [59411,59443]
parameters [59411,59443]
===
match
---
name: State [26990,26995]
name: State [26990,26995]
===
match
---
simple_stmt [41127,41213]
simple_stmt [41127,41213]
===
match
---
atom_expr [14400,14420]
atom_expr [14400,14420]
===
match
---
name: test_xcom_pull [36726,36740]
name: test_xcom_pull [36726,36740]
===
match
---
name: utcnow [20576,20582]
name: utcnow [20576,20582]
===
match
---
trailer [46129,46152]
trailer [46129,46152]
===
match
---
operator: , [64793,64794]
operator: , [64793,64794]
===
match
---
trailer [27112,27120]
trailer [27112,27120]
===
match
---
operator: = [34645,34646]
operator: = [34645,34646]
===
match
---
operator: = [41726,41727]
operator: = [41726,41727]
===
match
---
operator: , [32230,32231]
operator: , [32230,32231]
===
match
---
name: settings [60955,60963]
name: settings [60955,60963]
===
match
---
operator: , [33168,33169]
operator: , [33168,33169]
===
match
---
number: 0 [62057,62058]
number: 0 [62057,62058]
===
match
---
name: state [64965,64970]
name: state [64965,64970]
===
match
---
operator: = [11495,11496]
operator: = [11495,11496]
===
match
---
operator: , [14377,14378]
operator: , [14377,14378]
===
match
---
name: create_dagrun [79205,79218]
name: create_dagrun [79205,79218]
===
match
---
name: session [66874,66881]
name: session [66874,66881]
===
match
---
operator: = [13604,13605]
operator: = [13604,13605]
===
match
---
name: create_session [52410,52424]
name: create_session [52410,52424]
===
match
---
trailer [14226,14271]
trailer [14226,14271]
===
match
---
simple_stmt [47552,47581]
simple_stmt [47552,47581]
===
match
---
simple_stmt [29727,29767]
simple_stmt [29727,29767]
===
match
---
trailer [75952,75968]
trailer [75952,75968]
===
match
---
trailer [45344,45375]
trailer [45344,45375]
===
match
---
name: ti [22917,22919]
name: ti [22917,22919]
===
match
---
expr_stmt [43525,43596]
expr_stmt [43525,43596]
===
match
---
name: clear_db_pools [14461,14475]
name: clear_db_pools [14461,14475]
===
match
---
atom_expr [18463,18471]
atom_expr [18463,18471]
===
match
---
operator: = [59784,59785]
operator: = [59784,59785]
===
match
---
trailer [28837,28882]
trailer [28837,28882]
===
match
---
name: session [16639,16646]
name: session [16639,16646]
===
match
---
name: settings [73625,73633]
name: settings [73625,73633]
===
match
---
name: DAG [58560,58563]
name: DAG [58560,58563]
===
match
---
operator: , [70064,70065]
operator: , [70064,70065]
===
match
---
testlist_comp [78074,78083]
testlist_comp [78074,78083]
===
match
---
name: retry_delay [18815,18826]
name: retry_delay [18815,18826]
===
match
---
operator: = [71131,71132]
operator: = [71131,71132]
===
match
---
trailer [75024,75029]
trailer [75024,75029]
===
match
---
arglist [50510,50654]
arglist [50510,50654]
===
match
---
name: task [60220,60224]
name: task [60220,60224]
===
match
---
operator: = [80237,80238]
operator: = [80237,80238]
===
match
---
string: 'test_run_pooling_task_with_skip' [18027,18060]
string: 'test_run_pooling_task_with_skip' [18027,18060]
===
match
---
name: BaseSensorOperator [11229,11247]
name: BaseSensorOperator [11229,11247]
===
match
---
name: unittest [77537,77545]
name: unittest [77537,77545]
===
match
---
operator: = [60711,60712]
operator: = [60711,60712]
===
match
---
atom_expr [77342,77358]
atom_expr [77342,77358]
===
match
---
expr_stmt [63767,63839]
expr_stmt [63767,63839]
===
match
---
operator: = [14704,14705]
operator: = [14704,14705]
===
match
---
operator: , [68194,68195]
operator: , [68194,68195]
===
match
---
simple_stmt [21216,21243]
simple_stmt [21216,21243]
===
match
---
trailer [39694,39725]
trailer [39694,39725]
===
match
---
parameters [64350,64356]
parameters [64350,64356]
===
match
---
name: self [60323,60327]
name: self [60323,60327]
===
match
---
trailer [18250,18295]
trailer [18250,18295]
===
match
---
atom_expr [8564,8612]
atom_expr [8564,8612]
===
match
---
name: dag [18623,18626]
name: dag [18623,18626]
===
match
---
name: mock_on_failure_1 [61729,61746]
name: mock_on_failure_1 [61729,61746]
===
match
---
decorated [48034,48686]
decorated [48034,48686]
===
match
---
argument [63402,63417]
argument [63402,63417]
===
match
---
operator: , [31899,31900]
operator: , [31899,31900]
===
match
---
expr_stmt [21762,22136]
expr_stmt [21762,22136]
===
match
---
atom [69593,69975]
atom [69593,69975]
===
match
---
parameters [78159,78201]
parameters [78159,78201]
===
match
---
operator: , [78281,78282]
operator: , [78281,78282]
===
match
---
import_from [1807,1838]
import_from [1807,1838]
===
match
---
name: DEFAULT_DATE [66559,66571]
name: DEFAULT_DATE [66559,66571]
===
match
---
argument [61136,61151]
argument [61136,61151]
===
match
---
operator: = [48985,48986]
operator: = [48985,48986]
===
match
---
expr_stmt [62983,63017]
expr_stmt [62983,63017]
===
match
---
operator: , [34899,34900]
operator: , [34899,34900]
===
match
---
name: create_session [78216,78230]
name: create_session [78216,78230]
===
match
---
name: get_template_context [58728,58748]
name: get_template_context [58728,58748]
===
match
---
string: 'baz' [37494,37499]
string: 'baz' [37494,37499]
===
match
---
name: ti [29734,29736]
name: ti [29734,29736]
===
match
---
expr_stmt [43062,43132]
expr_stmt [43062,43132]
===
match
---
parameters [50175,50181]
parameters [50175,50181]
===
match
---
name: task [46602,46606]
name: task [46602,46606]
===
match
---
argument [41018,41038]
argument [41018,41038]
===
match
---
name: task_id [74973,74980]
name: task_id [74973,74980]
===
match
---
simple_stmt [79595,79639]
simple_stmt [79595,79639]
===
match
---
argument [66597,66624]
argument [66597,66624]
===
match
---
assert_stmt [57401,57478]
assert_stmt [57401,57478]
===
match
---
operator: , [26895,26896]
operator: , [26895,26896]
===
match
---
trailer [35931,35933]
trailer [35931,35933]
===
match
---
operator: , [33954,33955]
operator: , [33954,33955]
===
match
---
atom_expr [72824,72834]
atom_expr [72824,72834]
===
match
---
name: session [79370,79377]
name: session [79370,79377]
===
match
---
number: 1 [53564,53565]
number: 1 [53564,53565]
===
match
---
operator: = [61810,61811]
operator: = [61810,61811]
===
match
---
operator: = [59732,59733]
operator: = [59732,59733]
===
match
---
argument [58245,58272]
argument [58245,58272]
===
match
---
name: datetime [4116,4124]
name: datetime [4116,4124]
===
match
---
operator: == [65123,65125]
operator: == [65123,65125]
===
match
---
string: 'value' [59127,59134]
string: 'value' [59127,59134]
===
match
---
dictorsetmaker [73151,73204]
dictorsetmaker [73151,73204]
===
match
---
operator: = [21767,21768]
operator: = [21767,21768]
===
match
---
number: 60 [27725,27727]
number: 60 [27725,27727]
===
match
---
atom_expr [65747,65764]
atom_expr [65747,65764]
===
match
---
trailer [76672,76939]
trailer [76672,76939]
===
match
---
name: dag_id [3231,3237]
name: dag_id [3231,3237]
===
match
---
name: datetime [26187,26195]
name: datetime [26187,26195]
===
match
---
assert_stmt [60462,60528]
assert_stmt [60462,60528]
===
match
---
atom_expr [75375,75389]
atom_expr [75375,75389]
===
match
---
name: task [58239,58243]
name: task [58239,58243]
===
match
---
name: models [41402,41408]
name: models [41402,41408]
===
match
---
trailer [41813,41946]
trailer [41813,41946]
===
match
---
operator: , [49555,49556]
operator: , [49555,49556]
===
match
---
name: airflow [1921,1928]
name: airflow [1921,1928]
===
match
---
atom_expr [20837,20855]
atom_expr [20837,20855]
===
match
---
name: ANY [70006,70009]
name: ANY [70006,70009]
===
match
---
name: pool [13123,13127]
name: pool [13123,13127]
===
match
---
simple_stmt [67424,67524]
simple_stmt [67424,67524]
===
match
---
exprlist [74414,74434]
exprlist [74414,74434]
===
match
---
suite [48408,48430]
suite [48408,48430]
===
match
---
operator: + [66403,66404]
operator: + [66403,66404]
===
match
---
name: TI [36557,36559]
name: TI [36557,36559]
===
match
---
trailer [55345,55369]
trailer [55345,55369]
===
match
---
string: 'B' [72668,72671]
string: 'B' [72668,72671]
===
match
---
trailer [3906,3915]
trailer [3906,3915]
===
match
---
assert_stmt [61250,61263]
assert_stmt [61250,61263]
===
match
---
name: op1 [8250,8253]
name: op1 [8250,8253]
===
match
---
name: dep_patch [12004,12013]
name: dep_patch [12004,12013]
===
match
---
operator: + [5042,5043]
operator: + [5042,5043]
===
match
---
name: mock_on_failure_1 [61532,61549]
name: mock_on_failure_1 [61532,61549]
===
match
---
name: dag [24397,24400]
name: dag [24397,24400]
===
match
---
operator: == [80294,80296]
operator: == [80294,80296]
===
match
---
operator: , [53849,53850]
operator: , [53849,53850]
===
match
---
name: State [73249,73254]
name: State [73249,73254]
===
match
---
argument [60778,60817]
argument [60778,60817]
===
match
---
param [78188,78200]
param [78188,78200]
===
match
---
atom_expr [56704,56716]
atom_expr [56704,56716]
===
match
---
argument [40783,40807]
argument [40783,40807]
===
match
---
expr_stmt [54479,54548]
expr_stmt [54479,54548]
===
match
---
name: TI [63272,63274]
name: TI [63272,63274]
===
match
---
atom_expr [51288,51306]
atom_expr [51288,51306]
===
match
---
string: 'op_1' [4182,4188]
string: 'op_1' [4182,4188]
===
match
---
trailer [42910,42912]
trailer [42910,42912]
===
match
---
operator: = [68325,68326]
operator: = [68325,68326]
===
match
---
operator: , [63400,63401]
operator: , [63400,63401]
===
match
---
number: 2 [33486,33487]
number: 2 [33486,33487]
===
match
---
parameters [44490,44496]
parameters [44490,44496]
===
match
---
operator: == [53553,53555]
operator: == [53553,53555]
===
match
---
trailer [54309,54312]
trailer [54309,54312]
===
match
---
suite [17702,18513]
suite [17702,18513]
===
match
---
name: task_id [67303,67310]
name: task_id [67303,67310]
===
match
---
name: has_dag [6939,6946]
name: has_dag [6939,6946]
===
match
---
name: ti [60144,60146]
name: ti [60144,60146]
===
match
---
number: 1 [33856,33857]
number: 1 [33856,33857]
===
match
---
string: 'test_dag' [36277,36287]
string: 'test_dag' [36277,36287]
===
match
---
name: timezone [16416,16424]
name: timezone [16416,16424]
===
match
---
parameters [28261,28263]
parameters [28261,28263]
===
match
---
name: ti [17629,17631]
name: ti [17629,17631]
===
match
---
simple_stmt [50084,50102]
simple_stmt [50084,50102]
===
match
---
trailer [53992,53995]
trailer [53992,53995]
===
match
---
name: replace [6355,6362]
name: replace [6355,6362]
===
match
---
name: session [51187,51194]
name: session [51187,51194]
===
match
---
operator: = [38535,38536]
operator: = [38535,38536]
===
match
---
number: 2016 [38706,38710]
number: 2016 [38706,38710]
===
match
---
name: NONE [72758,72762]
name: NONE [72758,72762]
===
match
---
operator: { [59566,59567]
operator: { [59566,59567]
===
match
---
name: merge [51007,51012]
name: merge [51007,51012]
===
match
---
name: State [73268,73273]
name: State [73268,73273]
===
match
---
number: 0 [28522,28523]
number: 0 [28522,28523]
===
match
---
name: dag [57190,57193]
name: dag [57190,57193]
===
match
---
name: State [31836,31841]
name: State [31836,31841]
===
match
---
name: AirflowException [19075,19091]
name: AirflowException [19075,19091]
===
match
---
name: dep_patch [12577,12586]
name: dep_patch [12577,12586]
===
match
---
operator: = [24771,24772]
operator: = [24771,24772]
===
match
---
simple_stmt [26946,27021]
simple_stmt [26946,27021]
===
match
---
operator: , [70213,70214]
operator: , [70213,70214]
===
match
---
operator: , [18965,18966]
operator: , [18965,18966]
===
match
---
name: duration [25934,25942]
name: duration [25934,25942]
===
match
---
operator: = [61510,61511]
operator: = [61510,61511]
===
match
---
param [29141,29161]
param [29141,29161]
===
match
---
trailer [35723,35744]
trailer [35723,35744]
===
match
---
raise_stmt [64390,64437]
raise_stmt [64390,64437]
===
match
---
trailer [66135,66151]
trailer [66135,66151]
===
match
---
argument [50602,50653]
argument [50602,50653]
===
match
---
arglist [46169,46224]
arglist [46169,46224]
===
match
---
expr_stmt [57204,57256]
expr_stmt [57204,57256]
===
match
---
operator: , [67796,67797]
operator: , [67796,67797]
===
match
---
operator: , [32633,32634]
operator: , [32633,32634]
===
match
---
expr_stmt [49035,49234]
expr_stmt [49035,49234]
===
match
---
trailer [50869,50920]
trailer [50869,50920]
===
match
---
name: dag [18078,18081]
name: dag [18078,18081]
===
match
---
trailer [22724,22744]
trailer [22724,22744]
===
match
---
operator: = [74945,74946]
operator: = [74945,74946]
===
match
---
trailer [4848,4857]
trailer [4848,4857]
===
match
---
name: timezone [9964,9972]
name: timezone [9964,9972]
===
match
---
atom_expr [79292,79305]
atom_expr [79292,79305]
===
match
---
name: end_date [23796,23804]
name: end_date [23796,23804]
===
match
---
argument [31231,31248]
argument [31231,31248]
===
match
---
expr_stmt [58181,58216]
expr_stmt [58181,58216]
===
match
---
tfpdef [34058,34078]
tfpdef [34058,34078]
===
match
---
name: test_template_with_json_variable [59379,59411]
name: test_template_with_json_variable [59379,59411]
===
match
---
string: 'mock' [12108,12114]
string: 'mock' [12108,12114]
===
match
---
argument [43795,43805]
argument [43795,43805]
===
match
---
atom [59149,59243]
atom [59149,59243]
===
match
---
operator: , [60862,60863]
operator: , [60862,60863]
===
match
---
atom_expr [67094,67104]
atom_expr [67094,67104]
===
match
---
argument [65819,65842]
argument [65819,65842]
===
match
---
atom_expr [78949,78993]
atom_expr [78949,78993]
===
match
---
name: clear_db_runs [3537,3550]
name: clear_db_runs [3537,3550]
===
match
---
dictorsetmaker [72663,72691]
dictorsetmaker [72663,72691]
===
match
---
atom_expr [46964,46990]
atom_expr [46964,46990]
===
match
---
simple_stmt [34472,34541]
simple_stmt [34472,34541]
===
match
---
suite [16833,17655]
suite [16833,17655]
===
match
---
name: ti [20533,20535]
name: ti [20533,20535]
===
match
---
name: self [2762,2766]
name: self [2762,2766]
===
match
---
expr_stmt [62227,62261]
expr_stmt [62227,62261]
===
match
---
name: test_pool [3829,3838]
name: test_pool [3829,3838]
===
match
---
testlist_comp [57615,57896]
testlist_comp [57615,57896]
===
match
---
argument [34824,34843]
argument [34824,34843]
===
match
---
name: task_id [67110,67117]
name: task_id [67110,67117]
===
match
---
atom_expr [27613,27636]
atom_expr [27613,27636]
===
match
---
tfpdef [34107,34133]
tfpdef [34107,34133]
===
match
---
name: task [52274,52278]
name: task [52274,52278]
===
match
---
assert_stmt [58382,58414]
assert_stmt [58382,58414]
===
match
---
name: DAG [7414,7417]
name: DAG [7414,7417]
===
match
---
name: types [2260,2265]
name: types [2260,2265]
===
match
---
operator: = [65510,65511]
operator: = [65510,65511]
===
match
---
operator: = [60443,60444]
operator: = [60443,60444]
===
match
---
operator: , [24783,24784]
operator: , [24783,24784]
===
match
---
name: delay [21619,21624]
name: delay [21619,21624]
===
match
---
simple_stmt [67691,67708]
simple_stmt [67691,67708]
===
match
---
operator: = [7538,7539]
operator: = [7538,7539]
===
match
---
argument [55911,55933]
argument [55911,55933]
===
match
---
name: AirflowException [1202,1218]
name: AirflowException [1202,1218]
===
match
---
atom [53306,53350]
atom [53306,53350]
===
match
---
if_stmt [77104,77208]
if_stmt [77104,77208]
===
match
---
operator: , [14192,14193]
operator: , [14192,14193]
===
match
---
name: operators [1542,1551]
name: operators [1542,1551]
===
match
---
simple_stmt [39675,39734]
simple_stmt [39675,39734]
===
match
---
name: schedule_interval [55281,55298]
name: schedule_interval [55281,55298]
===
match
---
arith_expr [29583,29606]
arith_expr [29583,29606]
===
match
---
name: self [3947,3951]
name: self [3947,3951]
===
match
---
name: on_failure_callback [61709,61728]
name: on_failure_callback [61709,61728]
===
match
---
name: result [42401,42407]
name: result [42401,42407]
===
match
---
expr_stmt [23853,23884]
expr_stmt [23853,23884]
===
match
---
atom_expr [72769,72779]
atom_expr [72769,72779]
===
match
---
trailer [11909,11976]
trailer [11909,11976]
===
match
---
operator: , [28494,28495]
operator: , [28494,28495]
===
match
---
argument [41602,41620]
argument [41602,41620]
===
match
---
string: '{{ var.value.get("a_variable") }}' [57676,57711]
string: '{{ var.value.get("a_variable") }}' [57676,57711]
===
match
---
operator: , [9802,9803]
operator: , [9802,9803]
===
match
---
name: _test_previous_dates_setup [55254,55280]
name: _test_previous_dates_setup [55254,55280]
===
match
---
operator: , [52948,52949]
operator: , [52948,52949]
===
match
---
name: period [22445,22451]
name: period [22445,22451]
===
match
---
name: task [75203,75207]
name: task [75203,75207]
===
match
---
trailer [4886,5081]
trailer [4886,5081]
===
match
---
atom [69283,70697]
atom [69283,70697]
===
match
---
expr_stmt [43787,43840]
expr_stmt [43787,43840]
===
match
---
simple_stmt [56458,56605]
simple_stmt [56458,56605]
===
match
---
operator: = [62312,62313]
operator: = [62312,62313]
===
match
---
name: DagRunType [65282,65292]
name: DagRunType [65282,65292]
===
match
---
trailer [43190,43192]
trailer [43190,43192]
===
match
---
name: task [44120,44124]
name: task [44120,44124]
===
match
---
operator: == [68096,68098]
operator: == [68096,68098]
===
match
---
name: timezone [48376,48384]
name: timezone [48376,48384]
===
match
---
trailer [56059,56069]
trailer [56059,56069]
===
match
---
comparison [76395,76422]
comparison [76395,76422]
===
match
---
assert_stmt [6239,6275]
assert_stmt [6239,6275]
===
match
---
name: DummyOperator [60713,60726]
name: DummyOperator [60713,60726]
===
match
---
name: task [79654,79658]
name: task [79654,79658]
===
match
---
operator: , [27838,27839]
operator: , [27838,27839]
===
match
---
trailer [44241,44248]
trailer [44241,44248]
===
match
---
suite [75922,75975]
suite [75922,75975]
===
match
---
name: expected_task_reschedule_count [26097,26127]
name: expected_task_reschedule_count [26097,26127]
===
match
---
operator: = [50610,50611]
operator: = [50610,50611]
===
match
---
operator: , [26743,26744]
operator: , [26743,26744]
===
match
---
name: expand [31580,31586]
name: expand [31580,31586]
===
match
---
name: dag [28360,28363]
name: dag [28360,28363]
===
match
---
name: ti_list [53456,53463]
name: ti_list [53456,53463]
===
match
---
funcdef [14660,15105]
funcdef [14660,15105]
===
match
---
simple_stmt [40302,40332]
simple_stmt [40302,40332]
===
match
---
trailer [57070,57079]
trailer [57070,57079]
===
match
---
simple_stmt [5807,5825]
simple_stmt [5807,5825]
===
match
---
operator: = [43548,43549]
operator: = [43548,43549]
===
match
---
name: session [66837,66844]
name: session [66837,66844]
===
match
---
trailer [74776,74794]
trailer [74776,74794]
===
match
---
operator: , [32236,32237]
operator: , [32236,32237]
===
match
---
atom [32263,32321]
atom [32263,32321]
===
match
---
name: owner [14940,14945]
name: owner [14940,14945]
===
match
---
argument [44863,44872]
argument [44863,44872]
===
match
---
name: ti [18504,18506]
name: ti [18504,18506]
===
match
---
trailer [71955,71960]
trailer [71955,71960]
===
match
---
trailer [4350,4359]
trailer [4350,4359]
===
match
---
name: self [11015,11019]
name: self [11015,11019]
===
match
---
argument [66491,66498]
argument [66491,66498]
===
match
---
operator: , [46220,46221]
operator: , [46220,46221]
===
match
---
operator: == [25777,25779]
operator: == [25777,25779]
===
match
---
number: 1 [45408,45409]
number: 1 [45408,45409]
===
match
---
operator: = [46687,46688]
operator: = [46687,46688]
===
match
---
name: execution_date [79081,79095]
name: execution_date [79081,79095]
===
match
---
name: DEFAULT_DATE [70980,70992]
name: DEFAULT_DATE [70980,70992]
===
match
---
string: 'test_task_naive_datetime' [6432,6458]
string: 'test_task_naive_datetime' [6432,6458]
===
match
---
name: ti [20780,20782]
name: ti [20780,20782]
===
match
---
name: task1 [37075,37080]
name: task1 [37075,37080]
===
match
---
operator: { [72191,72192]
operator: { [72191,72192]
===
match
---
name: ti [19615,19617]
name: ti [19615,19617]
===
match
---
trailer [3481,3495]
trailer [3481,3495]
===
match
---
arglist [35779,35877]
arglist [35779,35877]
===
match
---
trailer [10727,10729]
trailer [10727,10729]
===
match
---
trailer [64289,64296]
trailer [64289,64296]
===
match
---
name: run [41958,41961]
name: run [41958,41961]
===
match
---
number: 1 [33431,33432]
number: 1 [33431,33432]
===
match
---
number: 0 [26780,26781]
number: 0 [26780,26781]
===
match
---
trailer [13201,13210]
trailer [13201,13210]
===
match
---
assert_stmt [54049,54111]
assert_stmt [54049,54111]
===
match
---
trailer [50634,50644]
trailer [50634,50644]
===
match
---
string: 'dag_run' [60477,60486]
string: 'dag_run' [60477,60486]
===
match
---
operator: = [14252,14253]
operator: = [14252,14253]
===
match
---
name: task_id [46130,46137]
name: task_id [46130,46137]
===
match
---
suite [68165,68925]
suite [68165,68925]
===
match
---
string: 'test_run_pooling_task_with_mark_success' [17067,17108]
string: 'test_run_pooling_task_with_mark_success' [17067,17108]
===
match
---
funcdef [16783,17655]
funcdef [16783,17655]
===
match
---
number: 2 [40271,40272]
number: 2 [40271,40272]
===
match
---
operator: = [61838,61839]
operator: = [61838,61839]
===
match
---
name: DEFAULT_DATE [51898,51910]
name: DEFAULT_DATE [51898,51910]
===
match
---
simple_stmt [20457,20466]
simple_stmt [20457,20466]
===
match
---
return_stmt [24376,24387]
return_stmt [24376,24387]
===
match
---
trailer [76152,76217]
trailer [76152,76217]
===
match
---
trailer [47967,47984]
trailer [47967,47984]
===
match
---
name: State [26872,26877]
name: State [26872,26877]
===
match
---
trailer [68423,68427]
trailer [68423,68427]
===
match
---
number: 1 [20208,20209]
number: 1 [20208,20209]
===
match
---
string: 'test_xcom' [39104,39115]
string: 'test_xcom' [39104,39115]
===
match
---
operator: = [58238,58239]
operator: = [58238,58239]
===
match
---
operator: , [23701,23702]
operator: , [23701,23702]
===
match
---
name: patch [66201,66206]
name: patch [66201,66206]
===
match
---
expr_stmt [23945,24010]
expr_stmt [23945,24010]
===
match
---
name: task [24457,24461]
name: task [24457,24461]
===
match
---
name: ti [2810,2812]
name: ti [2810,2812]
===
match
---
atom_expr [47930,47984]
atom_expr [47930,47984]
===
match
---
name: task_id [74048,74055]
name: task_id [74048,74055]
===
match
---
atom_expr [51026,51205]
atom_expr [51026,51205]
===
match
---
string: 'a' [59561,59564]
string: 'a' [59561,59564]
===
match
---
operator: { [71719,71720]
operator: { [71719,71720]
===
match
---
name: timedelta [26304,26313]
name: timedelta [26304,26313]
===
match
---
expr_stmt [10832,10846]
expr_stmt [10832,10846]
===
match
---
number: 0 [63509,63510]
number: 0 [63509,63510]
===
match
---
dotted_name [31566,31586]
dotted_name [31566,31586]
===
match
---
expr_stmt [2828,2867]
expr_stmt [2828,2867]
===
match
---
atom_expr [8819,8838]
atom_expr [8819,8838]
===
match
---
name: SCHEDULED [13616,13625]
name: SCHEDULED [13616,13625]
===
match
---
simple_stmt [27192,27213]
simple_stmt [27192,27213]
===
match
---
trailer [30164,30166]
trailer [30164,30166]
===
match
---
argument [44794,44808]
argument [44794,44808]
===
match
---
argument [26260,26269]
argument [26260,26269]
===
match
---
operator: , [15598,15599]
operator: , [15598,15599]
===
match
---
name: self [50176,50180]
name: self [50176,50180]
===
match
---
name: urllib [46709,46715]
name: urllib [46709,46715]
===
match
---
expr_stmt [76226,76256]
expr_stmt [76226,76256]
===
match
---
name: PythonOperator [41481,41495]
name: PythonOperator [41481,41495]
===
match
---
operator: , [72286,72287]
operator: , [72286,72287]
===
match
---
name: state [31332,31337]
name: state [31332,31337]
===
match
---
parameters [59958,59964]
parameters [59958,59964]
===
match
---
operator: , [73132,73133]
operator: , [73132,73133]
===
match
---
simple_stmt [45231,45248]
simple_stmt [45231,45248]
===
match
---
name: start_date [55886,55896]
name: start_date [55886,55896]
===
match
---
simple_stmt [2102,2137]
simple_stmt [2102,2137]
===
match
---
string: 'Try 1' [48670,48677]
string: 'Try 1' [48670,48677]
===
match
---
trailer [41682,41691]
trailer [41682,41691]
===
match
---
operator: , [79352,79353]
operator: , [79352,79353]
===
match
---
arglist [44920,44987]
arglist [44920,44987]
===
match
---
assert_stmt [51396,51459]
assert_stmt [51396,51459]
===
match
---
name: start_date [63302,63312]
name: start_date [63302,63312]
===
match
---
name: task_instance_d [75453,75468]
name: task_instance_d [75453,75468]
===
match
---
string: 'airflow' [15541,15550]
string: 'airflow' [15541,15550]
===
match
---
operator: , [58953,58954]
operator: , [58953,58954]
===
match
---
name: dag [11030,11033]
name: dag [11030,11033]
===
match
---
name: _ [53246,53247]
name: _ [53246,53247]
===
match
---
operator: , [31722,31723]
operator: , [31722,31723]
===
match
---
trailer [40252,40261]
trailer [40252,40261]
===
match
---
number: 2 [20929,20930]
number: 2 [20929,20930]
===
match
---
operator: , [33555,33556]
operator: , [33555,33556]
===
match
---
atom_expr [33046,33059]
atom_expr [33046,33059]
===
match
---
argument [49426,49437]
argument [49426,49437]
===
match
---
suite [76647,77502]
suite [76647,77502]
===
match
---
argument [64600,64607]
argument [64600,64607]
===
match
---
name: utcnow [43184,43190]
name: utcnow [43184,43190]
===
match
---
atom_expr [40588,40622]
atom_expr [40588,40622]
===
match
---
name: days [56070,56074]
name: days [56070,56074]
===
match
---
trailer [29684,29693]
trailer [29684,29693]
===
match
---
simple_stmt [74534,74582]
simple_stmt [74534,74582]
===
match
---
atom_expr [25879,25890]
atom_expr [25879,25890]
===
match
---
name: test_task_stats [66237,66252]
name: test_task_stats [66237,66252]
===
match
---
name: fail [27770,27774]
name: fail [27770,27774]
===
match
---
simple_stmt [52323,52374]
simple_stmt [52323,52374]
===
match
---
name: expand [53691,53697]
name: expand [53691,53697]
===
match
---
simple_stmt [2645,2690]
simple_stmt [2645,2690]
===
match
---
name: DagRunType [30873,30883]
name: DagRunType [30873,30883]
===
match
---
trailer [51256,51275]
trailer [51256,51275]
===
match
---
comparison [65175,65243]
comparison [65175,65243]
===
match
---
name: flag_upstream_failed [34981,35001]
name: flag_upstream_failed [34981,35001]
===
match
---
comparison [8812,8838]
comparison [8812,8838]
===
match
---
operator: == [41204,41206]
operator: == [41204,41206]
===
match
---
name: State [54491,54496]
name: State [54491,54496]
===
match
---
trailer [63508,63511]
trailer [63508,63511]
===
match
---
number: 0 [33310,33311]
number: 0 [33310,33311]
===
match
---
name: dag [14851,14854]
name: dag [14851,14854]
===
match
---
argument [14973,15022]
argument [14973,15022]
===
match
---
trailer [62059,62062]
trailer [62059,62062]
===
match
---
operator: = [74117,74118]
operator: = [74117,74118]
===
match
---
name: handle_failure [62598,62612]
name: handle_failure [62598,62612]
===
match
---
name: operator [77467,77475]
name: operator [77467,77475]
===
match
---
atom_expr [9829,9920]
atom_expr [9829,9920]
===
match
---
try_stmt [64177,64269]
try_stmt [64177,64269]
===
match
---
name: mark_success [78815,78827]
name: mark_success [78815,78827]
===
match
---
operator: = [23458,23459]
operator: = [23458,23459]
===
match
---
atom [32077,32125]
atom [32077,32125]
===
match
---
operator: , [32429,32430]
operator: , [32429,32430]
===
match
---
trailer [71504,71506]
trailer [71504,71506]
===
match
---
name: timedelta [18836,18845]
name: timedelta [18836,18845]
===
match
---
simple_stmt [76226,76257]
simple_stmt [76226,76257]
===
match
---
operator: == [79669,79671]
operator: == [79669,79671]
===
match
---
atom_expr [54089,54102]
atom_expr [54089,54102]
===
match
---
simple_stmt [75407,75437]
simple_stmt [75407,75437]
===
match
---
operator: = [20014,20015]
operator: = [20014,20015]
===
match
---
expr_stmt [8558,8612]
expr_stmt [8558,8612]
===
match
---
operator: , [31819,31820]
operator: , [31819,31820]
===
match
---
assert_stmt [4213,4267]
assert_stmt [4213,4267]
===
match
---
simple_stmt [13711,13737]
simple_stmt [13711,13737]
===
match
---
name: patch [68936,68941]
name: patch [68936,68941]
===
match
---
name: retries [21889,21896]
name: retries [21889,21896]
===
match
---
decorated [66200,67188]
decorated [66200,67188]
===
match
---
name: State [32772,32777]
name: State [32772,32777]
===
match
---
name: KeyError [58778,58786]
name: KeyError [58778,58786]
===
match
---
string: 'op1' [59704,59709]
string: 'op1' [59704,59709]
===
match
---
parameters [33940,34201]
parameters [33940,34201]
===
match
---
operator: = [60061,60062]
operator: = [60061,60062]
===
match
---
argument [69089,69112]
argument [69089,69112]
===
match
---
trailer [5196,5207]
trailer [5196,5207]
===
match
---
atom [11784,11786]
atom [11784,11786]
===
match
---
atom_expr [46709,46847]
atom_expr [46709,46847]
===
match
---
operator: = [63412,63413]
operator: = [63412,63413]
===
match
---
name: get_task_instance [56686,56703]
name: get_task_instance [56686,56703]
===
match
---
trailer [39034,39044]
trailer [39034,39044]
===
match
---
operator: , [51663,51664]
operator: , [51663,51664]
===
match
---
string: 'A' [71794,71797]
string: 'A' [71794,71797]
===
match
---
name: NONE [9577,9581]
name: NONE [9577,9581]
===
match
---
name: callback_ran [3032,3044]
name: callback_ran [3032,3044]
===
match
---
import_from [1631,1682]
import_from [1631,1682]
===
match
---
assert_stmt [48621,48654]
assert_stmt [48621,48654]
===
match
---
trailer [50309,50313]
trailer [50309,50313]
===
match
---
name: op1 [8332,8335]
name: op1 [8332,8335]
===
match
---
atom_expr [78410,78433]
atom_expr [78410,78433]
===
match
---
trailer [38471,38521]
trailer [38471,38521]
===
match
---
name: op2 [4792,4795]
name: op2 [4792,4795]
===
match
---
testlist_comp [59258,59352]
testlist_comp [59258,59352]
===
match
---
name: RUNNING [43401,43408]
name: RUNNING [43401,43408]
===
match
---
atom_expr [10118,10133]
atom_expr [10118,10133]
===
match
---
trailer [45192,45197]
trailer [45192,45197]
===
match
---
operator: , [51885,51886]
operator: , [51885,51886]
===
match
---
atom_expr [64695,64733]
atom_expr [64695,64733]
===
match
---
name: task [16389,16393]
name: task [16389,16393]
===
match
---
operator: = [54017,54018]
operator: = [54017,54018]
===
match
---
operator: } [68997,68998]
operator: } [68997,68998]
===
match
---
param [6628,6632]
param [6628,6632]
===
match
---
operator: , [17347,17348]
operator: , [17347,17348]
===
match
---
funcdef [47691,48029]
funcdef [47691,48029]
===
match
---
name: self [56911,56915]
name: self [56911,56915]
===
match
---
name: owner [40204,40209]
name: owner [40204,40209]
===
match
---
trailer [51275,51279]
trailer [51275,51279]
===
match
---
argument [61843,61853]
argument [61843,61853]
===
match
---
operator: + [25800,25801]
operator: + [25800,25801]
===
match
---
name: end_date [50602,50610]
name: end_date [50602,50610]
===
match
---
name: MANUAL [65758,65764]
name: MANUAL [65758,65764]
===
match
---
name: QUEUED [10631,10637]
name: QUEUED [10631,10637]
===
match
---
name: params [47351,47357]
name: params [47351,47357]
===
match
---
expr_stmt [49868,49961]
expr_stmt [49868,49961]
===
match
---
operator: == [77476,77478]
operator: == [77476,77478]
===
match
---
name: datetime [24817,24825]
name: datetime [24817,24825]
===
match
---
argument [50870,50879]
argument [50870,50879]
===
match
---
atom_expr [12235,12253]
atom_expr [12235,12253]
===
match
---
trailer [5722,5754]
trailer [5722,5754]
===
match
---
name: datetime [42759,42767]
name: datetime [42759,42767]
===
match
---
name: session [50999,51006]
name: session [50999,51006]
===
match
---
param [15249,15261]
param [15249,15261]
===
match
---
trailer [55599,55623]
trailer [55599,55623]
===
match
---
name: DagRunType [52056,52066]
name: DagRunType [52056,52066]
===
match
---
name: ti [59720,59722]
name: ti [59720,59722]
===
match
---
name: settings [1162,1170]
name: settings [1162,1170]
===
match
---
arglist [39695,39724]
arglist [39695,39724]
===
match
---
argument [40471,40490]
argument [40471,40490]
===
match
---
trailer [3704,3706]
trailer [3704,3706]
===
match
---
atom_expr [8093,8116]
atom_expr [8093,8116]
===
match
---
param [42386,42391]
param [42386,42391]
===
match
---
argument [4190,4202]
argument [4190,4202]
===
match
---
atom_expr [23306,23335]
atom_expr [23306,23335]
===
match
---
operator: , [18223,18224]
operator: , [18223,18224]
===
match
---
trailer [19313,19323]
trailer [19313,19323]
===
match
---
operator: = [16562,16563]
operator: = [16562,16563]
===
match
---
not_test [43856,43904]
not_test [43856,43904]
===
match
---
expr_stmt [13931,13979]
expr_stmt [13931,13979]
===
match
---
arglist [38792,38827]
arglist [38792,38827]
===
match
---
trailer [46622,46645]
trailer [46622,46645]
===
match
---
name: utcnow [15732,15738]
name: utcnow [15732,15738]
===
match
---
atom_expr [22394,22421]
atom_expr [22394,22421]
===
match
---
name: start_date [49973,49983]
name: start_date [49973,49983]
===
match
---
string: 'airflow' [64001,64010]
string: 'airflow' [64001,64010]
===
match
---
operator: , [32983,32984]
operator: , [32983,32984]
===
match
---
operator: == [42441,42443]
operator: == [42441,42443]
===
match
---
number: 0 [15017,15018]
number: 0 [15017,15018]
===
match
---
name: DEFAULT_DATE [7436,7448]
name: DEFAULT_DATE [7436,7448]
===
match
---
funcdef [57917,58415]
funcdef [57917,58415]
===
match
---
parameters [39782,39788]
parameters [39782,39788]
===
match
---
funcdef [20400,20524]
funcdef [20400,20524]
===
match
---
number: 2 [19511,19512]
number: 2 [19511,19512]
===
match
---
argument [79041,79048]
argument [79041,79048]
===
match
---
name: day_1 [55999,56004]
name: day_1 [55999,56004]
===
match
---
name: slots [3796,3801]
name: slots [3796,3801]
===
match
---
string: 'test_xcom' [39704,39715]
string: 'test_xcom' [39704,39715]
===
match
---
name: datetime [50042,50050]
name: datetime [50042,50050]
===
match
---
atom_expr [38884,38901]
atom_expr [38884,38901]
===
match
---
atom [70574,70630]
atom [70574,70630]
===
match
---
simple_stmt [50962,50991]
simple_stmt [50962,50991]
===
match
---
operator: , [20379,20380]
operator: , [20379,20380]
===
match
---
trailer [6078,6114]
trailer [6078,6114]
===
match
---
argument [43807,43839]
argument [43807,43839]
===
match
---
operator: = [9056,9057]
operator: = [9056,9057]
===
match
---
number: 1 [32357,32358]
number: 1 [32357,32358]
===
match
---
argument [17539,17568]
argument [17539,17568]
===
match
---
name: expand [71671,71677]
name: expand [71671,71677]
===
match
---
name: try_number [44297,44307]
name: try_number [44297,44307]
===
match
---
dictorsetmaker [71980,72040]
dictorsetmaker [71980,72040]
===
match
---
expr_stmt [65931,65976]
expr_stmt [65931,65976]
===
match
---
name: test_utils [2459,2469]
name: test_utils [2459,2469]
===
match
---
simple_stmt [27172,27184]
simple_stmt [27172,27184]
===
match
---
operator: = [68542,68543]
operator: = [68542,68543]
===
match
---
operator: , [18743,18744]
operator: , [18743,18744]
===
match
---
trailer [40823,40825]
trailer [40823,40825]
===
match
---
name: DummyOperator [9214,9227]
name: DummyOperator [9214,9227]
===
match
---
name: session [45448,45455]
name: session [45448,45455]
===
match
---
string: 'all_success' [31800,31813]
string: 'all_success' [31800,31813]
===
match
---
name: State [15834,15839]
name: State [15834,15839]
===
match
---
arglist [71102,71144]
arglist [71102,71144]
===
match
---
import_from [2448,2493]
import_from [2448,2493]
===
match
---
string: 'test-dag' [68520,68530]
string: 'test-dag' [68520,68530]
===
match
---
argument [39282,39302]
argument [39282,39302]
===
match
---
argument [50565,50588]
argument [50565,50588]
===
match
---
name: DummyOperator [43069,43082]
name: DummyOperator [43069,43082]
===
match
---
name: task [57212,57216]
name: task [57212,57216]
===
match
---
simple_stmt [29405,29411]
simple_stmt [29405,29411]
===
match
---
operator: , [65875,65876]
operator: , [65875,65876]
===
match
---
operator: = [4591,4592]
operator: = [4591,4592]
===
match
---
arglist [13259,13328]
arglist [13259,13328]
===
match
---
argument [46144,46151]
argument [46144,46151]
===
match
---
assert_stmt [55582,55669]
assert_stmt [55582,55669]
===
match
---
name: start_date [14150,14160]
name: start_date [14150,14160]
===
match
---
operator: , [34843,34844]
operator: , [34843,34844]
===
match
---
atom_expr [77088,77098]
atom_expr [77088,77098]
===
match
---
simple_stmt [37209,37247]
simple_stmt [37209,37247]
===
match
---
suite [36747,38245]
suite [36747,38245]
===
match
---
name: DEFAULT_DATE [56036,56048]
name: DEFAULT_DATE [56036,56048]
===
match
---
trailer [62773,62776]
trailer [62773,62776]
===
match
---
operator: , [50821,50822]
operator: , [50821,50822]
===
match
---
operator: , [58095,58096]
operator: , [58095,58096]
===
match
---
trailer [22396,22405]
trailer [22396,22405]
===
match
---
number: 1 [31821,31822]
number: 1 [31821,31822]
===
match
---
operator: , [52715,52716]
operator: , [52715,52716]
===
match
---
operator: = [14854,14855]
operator: = [14854,14855]
===
match
---
operator: , [72681,72682]
operator: , [72681,72682]
===
match
---
trailer [51631,51641]
trailer [51631,51641]
===
match
---
operator: { [73150,73151]
operator: { [73150,73151]
===
match
---
name: tests [2453,2458]
name: tests [2453,2458]
===
match
---
operator: , [40160,40161]
operator: , [40160,40161]
===
match
---
simple_stmt [60845,60904]
simple_stmt [60845,60904]
===
match
---
atom_expr [67443,67523]
atom_expr [67443,67523]
===
match
---
simple_stmt [19600,19619]
simple_stmt [19600,19619]
===
match
---
number: 1 [64062,64063]
number: 1 [64062,64063]
===
match
---
simple_stmt [3761,3805]
simple_stmt [3761,3805]
===
match
---
operator: , [27969,27970]
operator: , [27969,27970]
===
match
---
operator: , [40282,40283]
operator: , [40282,40283]
===
match
---
trailer [25996,26019]
trailer [25996,26019]
===
match
---
comparison [3213,3237]
comparison [3213,3237]
===
match
---
operator: , [9345,9346]
operator: , [9345,9346]
===
match
---
name: session [61144,61151]
name: session [61144,61151]
===
match
---
trailer [63869,64107]
trailer [63869,64107]
===
match
---
operator: , [27821,27822]
operator: , [27821,27822]
===
match
---
expr_stmt [38130,38204]
expr_stmt [38130,38204]
===
match
---
name: freeze_time [29234,29245]
name: freeze_time [29234,29245]
===
match
---
simple_stmt [17622,17655]
simple_stmt [17622,17655]
===
match
---
operator: = [43713,43714]
operator: = [43713,43714]
===
match
---
with_stmt [49371,49540]
with_stmt [49371,49540]
===
match
---
trailer [47189,47191]
trailer [47189,47191]
===
match
---
simple_stmt [2557,2586]
simple_stmt [2557,2586]
===
match
---
operator: == [45338,45340]
operator: == [45338,45340]
===
match
---
param [24075,24079]
param [24075,24079]
===
match
---
name: failing_status [35672,35686]
name: failing_status [35672,35686]
===
match
---
operator: = [55533,55534]
operator: = [55533,55534]
===
match
---
operator: = [68694,68695]
operator: = [68694,68695]
===
match
---
name: execution_date [20552,20566]
name: execution_date [20552,20566]
===
match
---
name: timedelta [66414,66423]
name: timedelta [66414,66423]
===
match
---
name: os [65055,65057]
name: os [65055,65057]
===
match
---
name: dag_id [42534,42540]
name: dag_id [42534,42540]
===
match
---
operator: , [27555,27556]
operator: , [27555,27556]
===
match
---
operator: = [18718,18719]
operator: = [18718,18719]
===
match
---
argument [10357,10380]
argument [10357,10380]
===
match
---
argument [36339,36362]
argument [36339,36362]
===
match
---
operator: , [32277,32278]
operator: , [32277,32278]
===
match
---
operator: { [11784,11785]
operator: { [11784,11785]
===
match
---
atom [76583,76603]
atom [76583,76603]
===
match
---
name: error_message [71427,71440]
name: error_message [71427,71440]
===
match
---
name: dag [4433,4436]
name: dag [4433,4436]
===
match
---
operator: = [15064,15065]
operator: = [15064,15065]
===
match
---
name: KeyError [60197,60205]
name: KeyError [60197,60205]
===
match
---
assert_stmt [29456,29489]
assert_stmt [29456,29489]
===
match
---
simple_stmt [29779,29869]
simple_stmt [29779,29869]
===
match
---
trailer [39644,39666]
trailer [39644,39666]
===
match
---
param [71409,71426]
param [71409,71426]
===
match
---
name: DEFAULT_DATE [66649,66661]
name: DEFAULT_DATE [66649,66661]
===
match
---
dotted_name [1812,1825]
dotted_name [1812,1825]
===
match
---
atom_expr [8497,8545]
atom_expr [8497,8545]
===
match
---
string: 'one_failed' [33472,33484]
string: 'one_failed' [33472,33484]
===
match
---
name: op [67037,67039]
name: op [67037,67039]
===
match
---
name: naive_datetime [6325,6339]
name: naive_datetime [6325,6339]
===
match
---
operator: = [53145,53146]
operator: = [53145,53146]
===
match
---
name: utcnow [28873,28879]
name: utcnow [28873,28879]
===
match
---
trailer [65544,65553]
trailer [65544,65553]
===
match
---
testlist_comp [59150,59242]
testlist_comp [59150,59242]
===
match
---
dictorsetmaker [71794,71812]
dictorsetmaker [71794,71812]
===
match
---
string: 'A' [74056,74059]
string: 'A' [74056,74059]
===
match
---
operator: , [43649,43650]
operator: , [43649,43650]
===
match
---
argument [60678,60685]
argument [60678,60685]
===
match
---
name: called [61257,61263]
name: called [61257,61263]
===
match
---
operator: , [9187,9188]
operator: , [9187,9188]
===
match
---
arith_expr [65511,65553]
arith_expr [65511,65553]
===
match
---
simple_stmt [64908,64925]
simple_stmt [64908,64925]
===
match
---
name: State [9989,9994]
name: State [9989,9994]
===
match
---
string: 'run' [67366,67371]
string: 'run' [67366,67371]
===
match
---
name: tzinfo [5412,5418]
name: tzinfo [5412,5418]
===
match
---
name: start_date [6460,6470]
name: start_date [6460,6470]
===
match
---
trailer [55623,55644]
trailer [55623,55644]
===
match
---
trailer [40747,40755]
trailer [40747,40755]
===
match
---
import_from [856,902]
import_from [856,902]
===
match
---
atom_expr [49808,49859]
atom_expr [49808,49859]
===
match
---
name: ti [76496,76498]
name: ti [76496,76498]
===
match
---
name: task_id [71570,71577]
name: task_id [71570,71577]
===
match
---
atom_expr [52056,52076]
atom_expr [52056,52076]
===
match
---
name: xcom_pull [40641,40650]
name: xcom_pull [40641,40650]
===
match
---
name: task [71102,71106]
name: task [71102,71106]
===
match
---
operator: = [28863,28864]
operator: = [28863,28864]
===
match
---
trailer [64196,64200]
trailer [64196,64200]
===
match
---
name: task [77029,77033]
name: task [77029,77033]
===
match
---
name: State [19772,19777]
name: State [19772,19777]
===
match
---
expr_stmt [26137,26162]
expr_stmt [26137,26162]
===
match
---
operator: , [54450,54451]
operator: , [54450,54451]
===
match
---
operator: , [16356,16357]
operator: , [16356,16357]
===
match
---
expr_stmt [23737,23784]
expr_stmt [23737,23784]
===
match
---
atom_expr [57460,57477]
atom_expr [57460,57477]
===
match
---
name: execution_date [6158,6172]
name: execution_date [6158,6172]
===
match
---
name: start_date [6756,6766]
name: start_date [6756,6766]
===
match
---
comparison [49616,49629]
comparison [49616,49629]
===
match
---
number: 0 [34254,34255]
number: 0 [34254,34255]
===
match
---
name: DEFAULT_DATE [58260,58272]
name: DEFAULT_DATE [58260,58272]
===
match
---
atom_expr [52012,52248]
atom_expr [52012,52248]
===
match
---
string: 'task_with_exp_backoff_and_max_delay' [21803,21840]
string: 'task_with_exp_backoff_and_max_delay' [21803,21840]
===
match
---
atom_expr [23031,23044]
atom_expr [23031,23044]
===
match
---
number: 3600 [50132,50136]
number: 3600 [50132,50136]
===
match
---
name: pop [12915,12918]
name: pop [12915,12918]
===
match
---
operator: , [42008,42009]
operator: , [42008,42009]
===
match
---
string: 'test_op_1' [8519,8530]
string: 'test_op_1' [8519,8530]
===
match
---
name: ti [18243,18245]
name: ti [18243,18245]
===
match
---
operator: = [14073,14074]
operator: = [14073,14074]
===
match
---
name: date3 [26978,26983]
name: date3 [26978,26983]
===
match
---
atom_expr [5719,5754]
atom_expr [5719,5754]
===
match
---
operator: , [57814,57815]
operator: , [57814,57815]
===
match
---
suite [8964,9582]
suite [8964,9582]
===
match
---
argument [6487,6510]
argument [6487,6510]
===
match
---
name: dag [62478,62481]
name: dag [62478,62481]
===
match
---
trailer [72406,72411]
trailer [72406,72411]
===
match
---
atom_expr [12034,12059]
atom_expr [12034,12059]
===
match
---
atom_expr [13474,13673]
atom_expr [13474,13673]
===
match
---
operator: = [21968,21969]
operator: = [21968,21969]
===
match
---
number: 0 [64725,64726]
number: 0 [64725,64726]
===
match
---
atom_expr [32692,32713]
atom_expr [32692,32713]
===
match
---
name: body [49754,49758]
name: body [49754,49758]
===
match
---
operator: = [37550,37551]
operator: = [37550,37551]
===
match
---
name: models [44046,44052]
name: models [44046,44052]
===
match
---
name: datetime [24674,24682]
name: datetime [24674,24682]
===
match
---
expr_stmt [48489,48540]
expr_stmt [48489,48540]
===
match
---
string: 'AIRFLOW_CTX_TASK_ID' [65137,65158]
string: 'AIRFLOW_CTX_TASK_ID' [65137,65158]
===
match
---
trailer [68593,68643]
trailer [68593,68643]
===
match
---
string: 'test_op_3' [7665,7676]
string: 'test_op_3' [7665,7676]
===
match
---
atom_expr [59725,59767]
atom_expr [59725,59767]
===
match
---
name: params [47658,47664]
name: params [47658,47664]
===
match
---
name: dict [68942,68946]
name: dict [68942,68946]
===
match
---
simple_stmt [74873,74916]
simple_stmt [74873,74916]
===
match
---
operator: = [13564,13565]
operator: = [13564,13565]
===
match
---
trailer [47282,47317]
trailer [47282,47317]
===
match
---
string: 'test_requeue_over_dag_concurrency' [9057,9092]
string: 'test_requeue_over_dag_concurrency' [9057,9092]
===
match
---
name: catchup [54452,54459]
name: catchup [54452,54459]
===
match
---
trailer [62152,62170]
trailer [62152,62170]
===
match
---
trailer [6975,6993]
trailer [6975,6993]
===
match
---
simple_stmt [39457,39505]
simple_stmt [39457,39505]
===
match
---
atom_expr [20601,20614]
atom_expr [20601,20614]
===
match
---
string: """         tests xcom set/clear relative to a task in a 'success' rerun scenario         """ [38298,38391]
string: """         tests xcom set/clear relative to a task in a 'success' rerun scenario         """ [38298,38391]
===
match
---
name: setUp [77880,77885]
name: setUp [77880,77885]
===
match
---
name: task [28838,28842]
name: task [28838,28842]
===
match
---
argument [47114,47123]
argument [47114,47123]
===
match
---
atom_expr [67944,68065]
atom_expr [67944,68065]
===
match
---
argument [44166,44189]
argument [44166,44189]
===
match
---
operator: , [7475,7476]
operator: , [7475,7476]
===
match
---
string: 'foo' [15585,15590]
string: 'foo' [15585,15590]
===
match
---
string: "hopeless" [63746,63756]
string: "hopeless" [63746,63756]
===
match
---
name: ti [22689,22691]
name: ti [22689,22691]
===
match
---
name: NONE [71879,71883]
name: NONE [71879,71883]
===
match
---
simple_stmt [19344,19370]
simple_stmt [19344,19370]
===
match
---
name: TI [49249,49251]
name: TI [49249,49251]
===
match
---
name: execution_date [64795,64809]
name: execution_date [64795,64809]
===
match
---
operator: = [14029,14030]
operator: = [14029,14030]
===
match
---
atom_expr [66755,66795]
atom_expr [66755,66795]
===
match
---
arglist [79027,79048]
arglist [79027,79048]
===
match
---
name: retries [23481,23488]
name: retries [23481,23488]
===
match
---
name: task_id [37351,37358]
name: task_id [37351,37358]
===
match
---
name: naive_datetime [6496,6510]
name: naive_datetime [6496,6510]
===
match
---
name: dag [30470,30473]
name: dag [30470,30473]
===
match
---
atom_expr [51962,51979]
atom_expr [51962,51979]
===
match
---
name: State [14505,14510]
name: State [14505,14510]
===
match
---
arglist [44714,44762]
arglist [44714,44762]
===
match
---
name: mock_on_retry_3 [63589,63604]
name: mock_on_retry_3 [63589,63604]
===
match
---
arglist [38153,38203]
arglist [38153,38203]
===
match
---
simple_stmt [35710,35747]
simple_stmt [35710,35747]
===
match
---
name: tests [2325,2330]
name: tests [2325,2330]
===
match
---
name: DEFAULT_DATE [60006,60018]
name: DEFAULT_DATE [60006,60018]
===
match
---
name: patch [8845,8850]
name: patch [8845,8850]
===
match
---
simple_stmt [54647,54722]
simple_stmt [54647,54722]
===
match
---
simple_stmt [22917,22935]
simple_stmt [22917,22935]
===
match
---
operator: = [48354,48355]
operator: = [48354,48355]
===
match
---
expr_stmt [2523,2552]
expr_stmt [2523,2552]
===
match
---
trailer [13717,13736]
trailer [13717,13736]
===
match
---
atom_expr [17475,17492]
atom_expr [17475,17492]
===
match
---
name: timedelta [4125,4134]
name: timedelta [4125,4134]
===
match
---
argument [47817,47855]
argument [47817,47855]
===
match
---
atom_expr [26872,26895]
atom_expr [26872,26895]
===
match
---
name: add_task [5811,5819]
name: add_task [5811,5819]
===
match
---
atom_expr [3817,3839]
atom_expr [3817,3839]
===
match
---
operator: == [3223,3225]
operator: == [3223,3225]
===
match
---
operator: == [46882,46884]
operator: == [46882,46884]
===
match
---
name: execution_date [46673,46687]
name: execution_date [46673,46687]
===
match
---
simple_stmt [62182,62219]
simple_stmt [62182,62219]
===
match
---
trailer [54827,54830]
trailer [54827,54830]
===
match
---
name: TI [66755,66757]
name: TI [66755,66757]
===
match
---
funcdef [38250,39734]
funcdef [38250,39734]
===
match
---
operator: } [69564,69565]
operator: } [69564,69565]
===
match
---
name: task [17118,17122]
name: task [17118,17122]
===
match
---
string: 'airflow.ti_deps.deps.prev_dagrun_dep.PrevDagrunDep.get_dep_statuses' [35779,35848]
string: 'airflow.ti_deps.deps.prev_dagrun_dep.PrevDagrunDep.get_dep_statuses' [35779,35848]
===
match
---
operator: == [20760,20762]
operator: == [20760,20762]
===
match
---
name: executor_config [77413,77428]
name: executor_config [77413,77428]
===
match
---
trailer [53566,53581]
trailer [53566,53581]
===
match
---
atom_expr [10713,10729]
atom_expr [10713,10729]
===
match
---
trailer [53624,53626]
trailer [53624,53626]
===
match
---
name: owner [17269,17274]
name: owner [17269,17274]
===
match
---
name: models [38461,38467]
name: models [38461,38467]
===
match
---
operator: , [67905,67906]
operator: , [67905,67906]
===
match
---
operator: = [5496,5497]
operator: = [5496,5497]
===
match
---
string: 'False' [72240,72247]
string: 'False' [72240,72247]
===
match
---
name: self [69035,69039]
name: self [69035,69039]
===
match
---
name: result [37665,37671]
name: result [37665,37671]
===
match
---
argument [7477,7500]
argument [7477,7500]
===
match
---
name: ti [12392,12394]
name: ti [12392,12394]
===
match
---
suite [47746,48029]
suite [47746,48029]
===
match
---
name: task [40777,40781]
name: task [40777,40781]
===
match
---
name: MANUAL [65293,65299]
name: MANUAL [65293,65299]
===
match
---
operator: = [49984,49985]
operator: = [49984,49985]
===
match
---
argument [22076,22125]
argument [22076,22125]
===
match
---
atom_expr [76301,76333]
atom_expr [76301,76333]
===
match
---
name: FAILED [36097,36103]
name: FAILED [36097,36103]
===
match
---
name: execution_date [46180,46194]
name: execution_date [46180,46194]
===
match
---
operator: == [68777,68779]
operator: == [68777,68779]
===
match
---
atom_expr [54699,54712]
atom_expr [54699,54712]
===
match
---
operator: = [51186,51187]
operator: = [51186,51187]
===
match
---
name: owner [63995,64000]
name: owner [63995,64000]
===
match
---
operator: - [11744,11745]
operator: - [11744,11745]
===
match
---
string: 'test_pool' [13128,13139]
string: 'test_pool' [13128,13139]
===
match
---
param [46044,46048]
param [46044,46048]
===
match
---
argument [36270,36287]
argument [36270,36287]
===
match
---
arglist [71031,71079]
arglist [71031,71079]
===
match
---
operator: = [45065,45066]
operator: = [45065,45066]
===
match
---
number: 2016 [57080,57084]
number: 2016 [57080,57084]
===
match
---
argument [51878,51885]
argument [51878,51885]
===
match
---
arglist [79236,79386]
arglist [79236,79386]
===
match
---
trailer [3777,3804]
trailer [3777,3804]
===
match
---
argument [17460,17492]
argument [17460,17492]
===
match
---
atom [33780,33826]
atom [33780,33826]
===
match
---
param [25371,25402]
param [25371,25402]
===
match
---
trailer [57521,57544]
trailer [57521,57544]
===
match
---
simple_stmt [9207,9285]
simple_stmt [9207,9285]
===
match
---
operator: , [32891,32892]
operator: , [32891,32892]
===
match
---
argument [18846,18855]
argument [18846,18855]
===
match
---
operator: = [5996,5997]
operator: = [5996,5997]
===
match
---
operator: , [14077,14078]
operator: , [14077,14078]
===
match
---
operator: = [28521,28522]
operator: = [28521,28522]
===
match
---
operator: , [19247,19248]
operator: , [19247,19248]
===
match
---
operator: , [58243,58244]
operator: , [58243,58244]
===
match
---
expr_stmt [48981,49026]
expr_stmt [48981,49026]
===
match
---
number: 0 [43227,43228]
number: 0 [43227,43228]
===
match
---
operator: = [38817,38818]
operator: = [38817,38818]
===
match
---
atom_expr [54269,54282]
atom_expr [54269,54282]
===
match
---
operator: , [55184,55185]
operator: , [55184,55185]
===
match
---
simple_stmt [47798,47857]
simple_stmt [47798,47857]
===
match
---
name: test_next_retry_datetime_short_intervals [23146,23186]
name: test_next_retry_datetime_short_intervals [23146,23186]
===
match
---
expr_stmt [11708,11762]
expr_stmt [11708,11762]
===
match
---
operator: , [41545,41546]
operator: , [41545,41546]
===
match
---
operator: = [56575,56576]
operator: = [56575,56576]
===
match
---
name: task [50875,50879]
name: task [50875,50879]
===
match
---
simple_stmt [8491,8546]
simple_stmt [8491,8546]
===
match
---
argument [43651,43674]
argument [43651,43674]
===
match
---
arglist [74220,74264]
arglist [74220,74264]
===
match
---
operator: , [64641,64642]
operator: , [64641,64642]
===
match
---
operator: } [72285,72286]
operator: } [72285,72286]
===
match
---
operator: = [50788,50789]
operator: = [50788,50789]
===
match
---
trailer [61184,61188]
trailer [61184,61188]
===
match
---
number: 0 [53464,53465]
number: 0 [53464,53465]
===
match
---
name: start_date [14973,14983]
name: start_date [14973,14983]
===
match
---
atom [59077,59135]
atom [59077,59135]
===
match
---
operator: = [48258,48259]
operator: = [48258,48259]
===
match
---
expr_stmt [61890,61914]
expr_stmt [61890,61914]
===
match
---
operator: = [8652,8653]
operator: = [8652,8653]
===
match
---
atom_expr [53307,53320]
atom_expr [53307,53320]
===
match
---
argument [18251,18260]
argument [18251,18260]
===
match
---
name: datetime [18940,18948]
name: datetime [18940,18948]
===
match
---
name: successes [33991,34000]
name: successes [33991,34000]
===
match
---
atom_expr [62682,62719]
atom_expr [62682,62719]
===
match
---
string: '{{ var.value.get("missing_variable") }}' [58822,58863]
string: '{{ var.value.get("missing_variable") }}' [58822,58863]
===
match
---
name: task [44925,44929]
name: task [44925,44929]
===
match
---
operator: = [63223,63224]
operator: = [63223,63224]
===
match
---
trailer [52875,52914]
trailer [52875,52914]
===
match
---
string: 'execution_date' [69424,69440]
string: 'execution_date' [69424,69440]
===
match
---
operator: , [72451,72452]
operator: , [72451,72452]
===
match
---
name: pool [77140,77144]
name: pool [77140,77144]
===
match
---
testlist_comp [36020,36039]
testlist_comp [36020,36039]
===
match
---
operator: == [43224,43226]
operator: == [43224,43226]
===
match
---
expr_stmt [60436,60449]
expr_stmt [60436,60449]
===
match
---
trailer [19651,19664]
trailer [19651,19664]
===
match
---
assert_stmt [48663,48685]
assert_stmt [48663,48685]
===
match
---
atom_expr [64035,64073]
atom_expr [64035,64073]
===
match
---
name: ti [22818,22820]
name: ti [22818,22820]
===
match
---
name: execution_date [3262,3276]
name: execution_date [3262,3276]
===
match
---
trailer [56486,56604]
trailer [56486,56604]
===
match
---
trailer [58634,58649]
trailer [58634,58649]
===
match
---
assert_stmt [19487,19512]
assert_stmt [19487,19512]
===
match
---
simple_stmt [51351,51388]
simple_stmt [51351,51388]
===
match
---
name: days [52655,52659]
name: days [52655,52659]
===
match
---
name: fail [28280,28284]
name: fail [28280,28284]
===
match
---
name: RUNNING_DEPS [1903,1915]
name: RUNNING_DEPS [1903,1915]
===
match
---
trailer [3230,3237]
trailer [3230,3237]
===
match
---
operator: = [30750,30751]
operator: = [30750,30751]
===
match
---
name: db [3506,3508]
name: db [3506,3508]
===
match
---
operator: = [23560,23561]
operator: = [23560,23561]
===
match
---
trailer [41730,41787]
trailer [41730,41787]
===
match
---
simple_stmt [65985,66010]
simple_stmt [65985,66010]
===
match
---
param [25310,25325]
param [25310,25325]
===
match
---
expr_stmt [47798,47856]
expr_stmt [47798,47856]
===
match
---
operator: , [36103,36104]
operator: , [36103,36104]
===
match
---
name: op [65944,65946]
name: op [65944,65946]
===
match
---
name: start_date [34211,34221]
name: start_date [34211,34221]
===
match
---
operator: , [20363,20364]
operator: , [20363,20364]
===
match
---
name: start_date [6808,6818]
name: start_date [6808,6818]
===
match
---
operator: = [54088,54089]
operator: = [54088,54089]
===
match
---
number: 0 [16354,16355]
number: 0 [16354,16355]
===
match
---
name: trigger_rule_dep [2063,2079]
name: trigger_rule_dep [2063,2079]
===
match
---
argument [24490,24531]
argument [24490,24531]
===
match
---
simple_stmt [8419,8461]
simple_stmt [8419,8461]
===
match
---
name: ignore_all_deps [39464,39479]
name: ignore_all_deps [39464,39479]
===
match
---
name: AirflowException [25527,25543]
name: AirflowException [25527,25543]
===
match
---
trailer [54997,55012]
trailer [54997,55012]
===
match
---
trailer [74456,74458]
trailer [74456,74458]
===
match
---
operator: , [37173,37174]
operator: , [37173,37174]
===
match
---
atom_expr [49986,50019]
atom_expr [49986,50019]
===
match
---
testlist_comp [33841,33885]
testlist_comp [33841,33885]
===
match
---
expr_stmt [68234,68303]
expr_stmt [68234,68303]
===
match
---
atom_expr [27686,27754]
atom_expr [27686,27754]
===
match
---
trailer [11946,11964]
trailer [11946,11964]
===
match
---
name: timezone [19157,19165]
name: timezone [19157,19165]
===
match
---
name: timezone [6061,6069]
name: timezone [6061,6069]
===
match
---
name: task [9302,9306]
name: task [9302,9306]
===
match
---
simple_stmt [47063,47098]
simple_stmt [47063,47098]
===
match
---
name: State [10948,10953]
name: State [10948,10953]
===
match
---
trailer [20463,20465]
trailer [20463,20465]
===
match
---
operator: = [66284,66285]
operator: = [66284,66285]
===
match
---
operator: , [33396,33397]
operator: , [33396,33397]
===
match
---
expr_stmt [22943,22974]
expr_stmt [22943,22974]
===
match
---
arglist [13509,13659]
arglist [13509,13659]
===
match
---
operator: = [8446,8447]
operator: = [8446,8447]
===
match
---
operator: , [50071,50072]
operator: , [50071,50072]
===
match
---
name: create_task_instance [15164,15184]
name: create_task_instance [15164,15184]
===
match
---
atom_expr [15627,15665]
atom_expr [15627,15665]
===
match
---
simple_stmt [3593,3623]
simple_stmt [3593,3623]
===
match
---
name: task_id [16174,16181]
name: task_id [16174,16181]
===
match
---
arglist [38472,38520]
arglist [38472,38520]
===
match
---
atom_expr [12364,12372]
atom_expr [12364,12372]
===
match
---
trailer [60240,60291]
trailer [60240,60291]
===
match
---
operator: = [12933,12934]
operator: = [12933,12934]
===
match
---
trailer [29425,29441]
trailer [29425,29441]
===
match
---
trailer [18465,18469]
trailer [18465,18469]
===
match
---
name: dag_id [67810,67816]
name: dag_id [67810,67816]
===
match
---
simple_stmt [77363,77399]
simple_stmt [77363,77399]
===
match
---
assert_stmt [35102,35138]
assert_stmt [35102,35138]
===
match
---
trailer [5172,5177]
trailer [5172,5177]
===
match
---
expr_stmt [59776,59811]
expr_stmt [59776,59811]
===
match
---
trailer [33193,33201]
trailer [33193,33201]
===
match
---
operator: = [43529,43530]
operator: = [43529,43530]
===
match
---
name: task_id [64550,64557]
name: task_id [64550,64557]
===
match
---
atom_expr [35569,35696]
atom_expr [35569,35696]
===
match
---
trailer [4359,4364]
trailer [4359,4364]
===
match
---
operator: , [32118,32119]
operator: , [32118,32119]
===
match
---
operator: , [36433,36434]
operator: , [36433,36434]
===
match
---
simple_stmt [27221,27251]
simple_stmt [27221,27251]
===
match
---
name: op1 [8491,8494]
name: op1 [8491,8494]
===
match
---
string: '/subject/path' [48756,48771]
string: '/subject/path' [48756,48771]
===
match
---
name: email [49213,49218]
name: email [49213,49218]
===
match
---
operator: , [72780,72781]
operator: , [72780,72781]
===
match
---
atom_expr [4461,4670]
atom_expr [4461,4670]
===
match
---
name: DEFAULT_DATE [69100,69112]
name: DEFAULT_DATE [69100,69112]
===
match
---
name: dag [44161,44164]
name: dag [44161,44164]
===
match
---
simple_stmt [929,978]
simple_stmt [929,978]
===
match
---
operator: = [40156,40157]
operator: = [40156,40157]
===
match
---
operator: = [34661,34662]
operator: = [34661,34662]
===
match
---
name: task_id [71562,71569]
name: task_id [71562,71569]
===
match
---
operator: = [34500,34501]
operator: = [34500,34501]
===
match
---
atom_expr [54924,54983]
atom_expr [54924,54983]
===
match
---
name: DummyOperator [51848,51861]
name: DummyOperator [51848,51861]
===
match
---
testlist_star_expr [26925,26937]
testlist_star_expr [26925,26937]
===
match
---
comparison [71598,71635]
comparison [71598,71635]
===
match
---
operator: = [35001,35002]
operator: = [35001,35002]
===
match
---
operator: , [67777,67778]
operator: , [67777,67778]
===
match
---
trailer [11547,11554]
trailer [11547,11554]
===
match
---
simple_stmt [36653,36717]
simple_stmt [36653,36717]
===
match
---
operator: = [47497,47498]
operator: = [47497,47498]
===
match
---
name: CallbackWrapper [50461,50476]
name: CallbackWrapper [50461,50476]
===
match
---
parameters [55712,55718]
parameters [55712,55718]
===
match
---
trailer [73161,73168]
trailer [73161,73168]
===
match
---
name: task_id [55976,55983]
name: task_id [55976,55983]
===
match
---
suite [30461,31355]
suite [30461,31355]
===
match
---
operator: = [50970,50971]
operator: = [50970,50971]
===
match
---
operator: = [7755,7756]
operator: = [7755,7756]
===
match
---
name: ti [27192,27194]
name: ti [27192,27194]
===
match
---
argument [31039,31073]
argument [31039,31073]
===
match
---
name: ti [20745,20747]
name: ti [20745,20747]
===
match
---
trailer [19614,19618]
trailer [19614,19618]
===
match
---
operator: , [64670,64671]
operator: , [64670,64671]
===
match
---
argument [49263,49295]
argument [49263,49295]
===
match
---
atom_expr [30677,30688]
atom_expr [30677,30688]
===
match
---
trailer [12279,12292]
trailer [12279,12292]
===
match
---
trailer [16775,16777]
trailer [16775,16777]
===
match
---
param [36201,36221]
param [36201,36221]
===
match
---
simple_stmt [2523,2553]
simple_stmt [2523,2553]
===
match
---
expr_stmt [10566,10638]
expr_stmt [10566,10638]
===
match
---
operator: , [33367,33368]
operator: , [33367,33368]
===
match
---
trailer [47357,47369]
trailer [47357,47369]
===
match
---
name: state [17506,17511]
name: state [17506,17511]
===
match
---
string: 'test_xcom' [39542,39553]
string: 'test_xcom' [39542,39553]
===
match
---
param [49786,49790]
param [49786,49790]
===
match
---
trailer [4420,4429]
trailer [4420,4429]
===
match
---
trailer [7656,7700]
trailer [7656,7700]
===
match
---
atom_expr [44204,44251]
atom_expr [44204,44251]
===
match
---
operator: , [22109,22110]
operator: , [22109,22110]
===
match
---
name: UPSTREAM_FAILED [73274,73289]
name: UPSTREAM_FAILED [73274,73289]
===
match
---
trailer [77845,77868]
trailer [77845,77868]
===
match
---
name: ti_2 [56784,56788]
name: ti_2 [56784,56788]
===
match
---
testlist_comp [58925,58997]
testlist_comp [58925,58997]
===
match
---
operator: , [57096,57097]
operator: , [57096,57097]
===
match
---
trailer [75348,75366]
trailer [75348,75366]
===
match
---
operator: = [14126,14127]
operator: = [14126,14127]
===
match
---
atom_expr [42479,42507]
atom_expr [42479,42507]
===
match
---
name: SerializedBaseOperator [79983,80005]
name: SerializedBaseOperator [79983,80005]
===
match
---
trailer [13943,13947]
trailer [13943,13947]
===
match
---
name: execution_date [19142,19156]
name: execution_date [19142,19156]
===
match
---
operator: , [32530,32531]
operator: , [32530,32531]
===
match
---
name: self [10262,10266]
name: self [10262,10266]
===
match
---
simple_stmt [64854,64863]
simple_stmt [64854,64863]
===
match
---
suite [52618,52755]
suite [52618,52755]
===
match
---
name: ti [16381,16383]
name: ti [16381,16383]
===
match
---
operator: = [66845,66846]
operator: = [66845,66846]
===
match
---
operator: , [55109,55110]
operator: , [55109,55110]
===
match
---
arglist [79070,79119]
arglist [79070,79119]
===
match
---
trailer [38550,38737]
trailer [38550,38737]
===
match
---
argument [51103,51122]
argument [51103,51122]
===
match
---
trailer [40600,40622]
trailer [40600,40622]
===
match
---
name: task_id [50707,50714]
name: task_id [50707,50714]
===
match
---
parameters [41241,41247]
parameters [41241,41247]
===
match
---
trailer [77346,77358]
trailer [77346,77358]
===
match
---
trailer [40737,40747]
trailer [40737,40747]
===
match
---
name: ti [22201,22203]
name: ti [22201,22203]
===
match
---
operator: = [63790,63791]
operator: = [63790,63791]
===
match
---
name: create_dagrun [41800,41813]
name: create_dagrun [41800,41813]
===
match
---
testlist_star_expr [27764,27774]
testlist_star_expr [27764,27774]
===
match
---
parameters [60385,60394]
parameters [60385,60394]
===
match
---
number: 0 [57092,57093]
number: 0 [57092,57093]
===
match
---
simple_stmt [59453,59525]
simple_stmt [59453,59525]
===
match
---
dictorsetmaker [69327,70050]
dictorsetmaker [69327,70050]
===
match
---
name: state [9562,9567]
name: state [9562,9567]
===
match
---
name: state [16521,16526]
name: state [16521,16526]
===
match
---
name: stats_mock [66981,66991]
name: stats_mock [66981,66991]
===
match
---
trailer [14169,14178]
trailer [14169,14178]
===
match
---
name: execution_date [40443,40457]
name: execution_date [40443,40457]
===
match
---
trailer [10478,10556]
trailer [10478,10556]
===
match
---
name: db [77812,77814]
name: db [77812,77814]
===
match
---
name: version [2297,2304]
name: version [2297,2304]
===
match
---
string: 'baz' [38238,38243]
string: 'baz' [38238,38243]
===
match
---
trailer [68723,68752]
trailer [68723,68752]
===
match
---
string: 'test_xcom_2' [37359,37372]
string: 'test_xcom_2' [37359,37372]
===
match
---
name: priority_weight_total [77291,77312]
name: priority_weight_total [77291,77312]
===
match
---
name: dag [7232,7235]
name: dag [7232,7235]
===
match
---
name: op2 [4772,4775]
name: op2 [4772,4775]
===
match
---
number: 1 [27868,27869]
number: 1 [27868,27869]
===
match
---
trailer [14178,14199]
trailer [14178,14199]
===
match
---
operator: , [32168,32169]
operator: , [32168,32169]
===
match
---
simple_stmt [45206,45223]
simple_stmt [45206,45223]
===
match
---
operator: , [73242,73243]
operator: , [73242,73243]
===
match
---
name: generate_command [68099,68115]
name: generate_command [68099,68115]
===
match
---
name: dag [56926,56929]
name: dag [56926,56929]
===
match
---
atom_expr [8250,8273]
atom_expr [8250,8273]
===
match
---
operator: , [8861,8862]
operator: , [8861,8862]
===
match
---
trailer [40590,40600]
trailer [40590,40600]
===
match
---
argument [37835,37844]
argument [37835,37844]
===
match
---
number: 1 [54745,54746]
number: 1 [54745,54746]
===
match
---
name: dep_patch [12156,12165]
name: dep_patch [12156,12165]
===
match
---
name: pytest [7953,7959]
name: pytest [7953,7959]
===
match
---
expr_stmt [55999,56019]
expr_stmt [55999,56019]
===
match
---
operator: , [32971,32972]
operator: , [32971,32972]
===
match
---
if_stmt [75285,75493]
if_stmt [75285,75493]
===
match
---
atom_expr [79983,80041]
atom_expr [79983,80041]
===
match
---
name: SUCCESS [31347,31354]
name: SUCCESS [31347,31354]
===
match
---
operator: , [6092,6093]
operator: , [6092,6093]
===
match
---
name: expected_try_number [25338,25357]
name: expected_try_number [25338,25357]
===
match
---
name: test_xcom_push_flag [41222,41241]
name: test_xcom_push_flag [41222,41241]
===
match
---
argument [54083,54102]
argument [54083,54102]
===
match
---
argument [64124,64133]
argument [64124,64133]
===
match
---
number: 0 [31758,31759]
number: 0 [31758,31759]
===
match
---
string: 'test' [4934,4940]
string: 'test' [4934,4940]
===
match
---
string: 'airflow-worker' [69615,69631]
string: 'airflow-worker' [69615,69631]
===
match
---
number: 0 [40274,40275]
number: 0 [40274,40275]
===
match
---
with_stmt [78211,78715]
with_stmt [78211,78715]
===
match
---
funcdef [55675,56873]
funcdef [55675,56873]
===
match
---
name: merge [66882,66887]
name: merge [66882,66887]
===
match
---
operator: = [12002,12003]
operator: = [12002,12003]
===
match
---
operator: = [76177,76178]
operator: = [76177,76178]
===
match
---
suite [29216,29931]
suite [29216,29931]
===
match
---
name: timedelta [24683,24692]
name: timedelta [24683,24692]
===
match
---
name: ti_2 [56751,56755]
name: ti_2 [56751,56755]
===
match
---
argument [60054,60067]
argument [60054,60067]
===
match
---
operator: , [72834,72835]
operator: , [72834,72835]
===
match
---
atom [12515,12540]
atom [12515,12540]
===
match
---
trailer [24972,24983]
trailer [24972,24983]
===
match
---
name: str [2678,2681]
name: str [2678,2681]
===
match
---
name: run_ti_and_assert [27063,27080]
name: run_ti_and_assert [27063,27080]
===
match
---
atom_expr [38921,38934]
atom_expr [38921,38934]
===
match
---
simple_stmt [22581,22650]
simple_stmt [22581,22650]
===
match
---
arglist [41018,41047]
arglist [41018,41047]
===
match
---
import_from [1731,1806]
import_from [1731,1806]
===
match
---
simple_stmt [6925,6949]
simple_stmt [6925,6949]
===
match
---
trailer [34608,34619]
trailer [34608,34619]
===
match
---
string: 'tasks' [70243,70250]
string: 'tasks' [70243,70250]
===
match
---
string: 'one_success' [32078,32091]
string: 'one_success' [32078,32091]
===
match
---
operator: = [62956,62957]
operator: = [62956,62957]
===
match
---
testlist_comp [71721,71765]
testlist_comp [71721,71765]
===
match
---
atom_expr [28637,28666]
atom_expr [28637,28666]
===
match
---
name: self [73479,73483]
name: self [73479,73483]
===
match
---
trailer [54931,54934]
trailer [54931,54934]
===
match
---
expr_stmt [23031,23049]
expr_stmt [23031,23049]
===
match
---
trailer [33051,33059]
trailer [33051,33059]
===
match
---
funcdef [28961,29931]
funcdef [28961,29931]
===
match
---
name: run_id [74683,74689]
name: run_id [74683,74689]
===
match
---
operator: , [15022,15023]
operator: , [15022,15023]
===
match
---
atom_expr [48987,49026]
atom_expr [48987,49026]
===
match
---
operator: = [13935,13936]
operator: = [13935,13936]
===
match
---
argument [40359,40383]
argument [40359,40383]
===
match
---
name: run_type [19294,19302]
name: run_type [19294,19302]
===
match
---
trailer [4813,4824]
trailer [4813,4824]
===
match
---
argument [4092,4143]
argument [4092,4143]
===
match
---
operator: = [22417,22418]
operator: = [22417,22418]
===
match
---
operator: , [27897,27898]
operator: , [27897,27898]
===
match
---
suite [67239,67574]
suite [67239,67574]
===
match
---
operator: , [33794,33795]
operator: , [33794,33795]
===
match
---
name: pendulum [57460,57468]
name: pendulum [57460,57468]
===
match
---
name: DAG [78263,78266]
name: DAG [78263,78266]
===
match
---
argument [50212,50224]
argument [50212,50224]
===
match
---
atom_expr [42523,42565]
atom_expr [42523,42565]
===
match
---
number: 30 [21654,21656]
number: 30 [21654,21656]
===
match
---
simple_stmt [9027,9199]
simple_stmt [9027,9199]
===
match
---
simple_stmt [2796,2820]
simple_stmt [2796,2820]
===
match
---
number: 1 [32680,32681]
number: 1 [32680,32681]
===
match
---
argument [56500,56520]
argument [56500,56520]
===
match
---
name: ti [30356,30358]
name: ti [30356,30358]
===
match
---
trailer [52514,52543]
trailer [52514,52543]
===
match
---
simple_stmt [27571,27644]
simple_stmt [27571,27644]
===
match
---
string: 'op1' [58643,58648]
string: 'op1' [58643,58648]
===
match
---
operator: } [16723,16724]
operator: } [16723,16724]
===
match
---
arglist [8511,8544]
arglist [8511,8544]
===
match
---
string: 'run' [70280,70285]
string: 'run' [70280,70285]
===
match
---
trailer [73633,73641]
trailer [73633,73641]
===
match
---
operator: == [20960,20962]
operator: == [20960,20962]
===
match
---
simple_stmt [75535,75557]
simple_stmt [75535,75557]
===
match
---
operator: , [30077,30078]
operator: , [30077,30078]
===
match
---
operator: , [64010,64011]
operator: , [64010,64011]
===
match
---
atom_expr [67390,67414]
atom_expr [67390,67414]
===
match
---
suite [8478,8711]
suite [8478,8711]
===
match
---
string: 'C' [72413,72416]
string: 'C' [72413,72416]
===
match
---
trailer [47805,47856]
trailer [47805,47856]
===
match
---
string: 'test-dag' [58131,58141]
string: 'test-dag' [58131,58141]
===
match
---
number: 15 [22418,22420]
number: 15 [22418,22420]
===
match
---
atom_expr [51214,51230]
atom_expr [51214,51230]
===
match
---
name: run_type [61093,61101]
name: run_type [61093,61101]
===
match
---
name: timezone [11517,11525]
name: timezone [11517,11525]
===
match
---
name: dag [20010,20013]
name: dag [20010,20013]
===
match
---
name: end_date [4437,4445]
name: end_date [4437,4445]
===
match
---
argument [17239,17255]
argument [17239,17255]
===
match
---
name: task_id [60740,60747]
name: task_id [60740,60747]
===
match
---
name: self [44491,44495]
name: self [44491,44495]
===
match
---
trailer [7828,7830]
trailer [7828,7830]
===
match
---
argument [59586,59605]
argument [59586,59605]
===
match
---
string: 'test_run_pooling_task_op' [15491,15517]
string: 'test_run_pooling_task_op' [15491,15517]
===
match
---
name: task_b [74981,74987]
name: task_b [74981,74987]
===
match
---
operator: = [58692,58693]
operator: = [58692,58693]
===
match
---
name: on_retry_callback [61760,61777]
name: on_retry_callback [61760,61777]
===
match
---
suite [66271,67188]
suite [66271,67188]
===
match
---
name: days [5318,5322]
name: days [5318,5322]
===
match
---
string: '0 0 * * *' [52895,52906]
string: '0 0 * * *' [52895,52906]
===
match
---
name: DEFAULT_DATE [71132,71144]
name: DEFAULT_DATE [71132,71144]
===
match
---
atom_expr [10625,10637]
atom_expr [10625,10637]
===
match
---
name: DEFAULT_DATE [58693,58705]
name: DEFAULT_DATE [58693,58705]
===
match
---
trailer [25497,25501]
trailer [25497,25501]
===
match
---
parameters [77718,77720]
parameters [77718,77720]
===
match
---
name: timedelta [44970,44979]
name: timedelta [44970,44979]
===
match
---
string: "next_execution_date" [57436,57457]
string: "next_execution_date" [57436,57457]
===
match
---
operator: , [60817,60818]
operator: , [60817,60818]
===
match
---
name: task_id [68594,68601]
name: task_id [68594,68601]
===
match
---
operator: = [9895,9896]
operator: = [9895,9896]
===
match
---
trailer [21513,21534]
trailer [21513,21534]
===
match
---
name: end_date [23116,23124]
name: end_date [23116,23124]
===
match
---
operator: } [72356,72357]
operator: } [72356,72357]
===
match
---
operator: = [25043,25044]
operator: = [25043,25044]
===
match
---
name: isoformat [66572,66581]
name: isoformat [66572,66581]
===
match
---
name: date1 [26971,26976]
name: date1 [26971,26976]
===
match
---
name: dag [17917,17920]
name: dag [17917,17920]
===
match
---
atom [47215,47233]
atom [47215,47233]
===
match
---
name: dag [18870,18873]
name: dag [18870,18873]
===
match
---
name: session [10146,10153]
name: session [10146,10153]
===
match
---
argument [58635,58648]
argument [58635,58648]
===
match
---
operator: , [32968,32969]
operator: , [32968,32969]
===
match
---
name: timezone [43822,43830]
name: timezone [43822,43830]
===
match
---
name: _ [54430,54431]
name: _ [54430,54431]
===
match
---
funcdef [59914,60292]
funcdef [59914,60292]
===
match
---
name: Exception [42283,42292]
name: Exception [42283,42292]
===
match
---
name: UP_FOR_RETRY [21195,21207]
name: UP_FOR_RETRY [21195,21207]
===
match
---
name: State [10625,10630]
name: State [10625,10630]
===
match
---
argument [18891,18906]
argument [18891,18906]
===
match
---
name: failing_status [35380,35394]
name: failing_status [35380,35394]
===
match
---
operator: = [5544,5545]
operator: = [5544,5545]
===
match
---
comparison [65026,65087]
comparison [65026,65087]
===
match
---
name: DummyOperator [17125,17138]
name: DummyOperator [17125,17138]
===
match
---
operator: = [79623,79624]
operator: = [79623,79624]
===
match
---
name: freeze_time [25431,25442]
name: freeze_time [25431,25442]
===
match
---
name: context [58365,58372]
name: context [58365,58372]
===
match
---
raise_stmt [28302,28326]
raise_stmt [28302,28326]
===
match
---
comparison [39082,39134]
comparison [39082,39134]
===
match
---
operator: , [45016,45017]
operator: , [45016,45017]
===
match
---
argument [30637,30657]
argument [30637,30657]
===
match
---
simple_stmt [40631,40691]
simple_stmt [40631,40691]
===
match
---
trailer [52607,52617]
trailer [52607,52617]
===
match
---
comparison [30220,30239]
comparison [30220,30239]
===
match
---
simple_stmt [19704,19718]
simple_stmt [19704,19718]
===
match
---
trailer [25765,25776]
trailer [25765,25776]
===
match
---
simple_stmt [39638,39667]
simple_stmt [39638,39667]
===
match
---
name: date [22990,22994]
name: date [22990,22994]
===
match
---
name: TI [58664,58666]
name: TI [58664,58666]
===
match
---
with_stmt [11564,11655]
with_stmt [11564,11655]
===
match
---
atom [35970,36155]
atom [35970,36155]
===
match
---
name: retries [63216,63223]
name: retries [63216,63223]
===
match
---
argument [9721,9744]
argument [9721,9744]
===
match
---
operator: } [47892,47893]
operator: } [47892,47893]
===
match
---
comparison [48670,48685]
comparison [48670,48685]
===
match
---
trailer [4586,4594]
trailer [4586,4594]
===
match
---
operator: , [32894,32895]
operator: , [32894,32895]
===
match
---
string: 'value' [70614,70621]
string: 'value' [70614,70621]
===
match
---
argument [57051,57100]
argument [57051,57100]
===
match
---
arglist [35501,35553]
arglist [35501,35553]
===
match
---
simple_stmt [36302,36364]
simple_stmt [36302,36364]
===
match
---
operator: , [33797,33798]
operator: , [33797,33798]
===
match
---
string: 'namespace' [70027,70038]
string: 'namespace' [70027,70038]
===
match
---
operator: = [8518,8519]
operator: = [8518,8519]
===
match
---
name: state [52100,52105]
name: state [52100,52105]
===
match
---
atom_expr [79909,79956]
atom_expr [79909,79956]
===
match
---
atom_expr [16444,16623]
atom_expr [16444,16623]
===
match
---
simple_stmt [40817,40826]
simple_stmt [40817,40826]
===
match
---
assert_stmt [5605,5645]
assert_stmt [5605,5645]
===
match
---
number: 60 [27952,27954]
number: 60 [27952,27954]
===
match
---
argument [39464,39484]
argument [39464,39484]
===
match
---
name: SKIPPED [33052,33059]
name: SKIPPED [33052,33059]
===
match
---
operator: = [11390,11391]
operator: = [11390,11391]
===
match
---
argument [44561,44605]
argument [44561,44605]
===
match
---
trailer [79545,79586]
trailer [79545,79586]
===
match
---
name: datetime [36963,36971]
name: datetime [36963,36971]
===
match
---
name: next_retry_datetime [23068,23087]
name: next_retry_datetime [23068,23087]
===
match
---
trailer [30332,30355]
trailer [30332,30355]
===
match
---
name: handle_failure [61927,61941]
name: handle_failure [61927,61941]
===
match
---
operator: , [69087,69088]
operator: , [69087,69088]
===
match
---
name: expected_task_reschedule_count [25371,25401]
name: expected_task_reschedule_count [25371,25401]
===
match
---
operator: , [61413,61414]
operator: , [61413,61414]
===
match
---
simple_stmt [48621,48655]
simple_stmt [48621,48655]
===
match
---
name: timezone [34224,34232]
name: timezone [34224,34232]
===
match
---
argument [66638,66661]
argument [66638,66661]
===
match
---
number: 0 [28916,28917]
number: 0 [28916,28917]
===
match
---
parameters [28982,29215]
parameters [28982,29215]
===
match
---
name: ti [23860,23862]
name: ti [23860,23862]
===
match
---
name: run_date [28996,29004]
name: run_date [28996,29004]
===
match
---
argument [65948,65975]
argument [65948,65975]
===
match
---
string: 'test_previous_dates' [51717,51738]
string: 'test_previous_dates' [51717,51738]
===
match
---
name: ti [15940,15942]
name: ti [15940,15942]
===
match
---
argument [39054,39065]
argument [39054,39065]
===
match
---
trailer [29963,29965]
trailer [29963,29965]
===
match
---
operator: , [31248,31249]
operator: , [31248,31249]
===
match
---
name: dag [79630,79633]
name: dag [79630,79633]
===
match
---
operator: , [40781,40782]
operator: , [40781,40782]
===
match
---
name: DummyOperator [6397,6410]
name: DummyOperator [6397,6410]
===
match
---
atom_expr [44961,44987]
atom_expr [44961,44987]
===
match
---
number: 1 [3802,3803]
number: 1 [3802,3803]
===
match
---
name: self [53755,53759]
name: self [53755,53759]
===
match
---
simple_stmt [28231,28244]
simple_stmt [28231,28244]
===
match
---
name: NONE [72407,72411]
name: NONE [72407,72411]
===
match
---
name: session [73891,73898]
name: session [73891,73898]
===
match
---
name: task [43605,43609]
name: task [43605,43609]
===
match
---
operator: = [60797,60798]
operator: = [60797,60798]
===
match
---
atom [71902,71961]
atom [71902,71961]
===
match
---
operator: , [55298,55299]
operator: , [55298,55299]
===
match
---
trailer [52654,52664]
trailer [52654,52664]
===
match
---
name: op1 [4154,4157]
name: op1 [4154,4157]
===
match
---
operator: , [41696,41697]
operator: , [41696,41697]
===
match
---
testlist_comp [33411,33456]
testlist_comp [33411,33456]
===
match
---
name: FAILED [54526,54532]
name: FAILED [54526,54532]
===
match
---
operator: = [71058,71059]
operator: = [71058,71059]
===
match
---
argument [56411,56437]
argument [56411,56437]
===
match
---
name: timezone [6007,6015]
name: timezone [6007,6015]
===
match
---
expr_stmt [7511,7565]
expr_stmt [7511,7565]
===
match
---
trailer [25015,25148]
trailer [25015,25148]
===
match
---
name: run [30995,30998]
name: run [30995,30998]
===
match
---
argument [63995,64010]
argument [63995,64010]
===
match
---
operator: , [38236,38237]
operator: , [38236,38237]
===
match
---
atom [47251,47270]
atom [47251,47270]
===
match
---
argument [3796,3803]
argument [3796,3803]
===
match
---
name: TI [23742,23744]
name: TI [23742,23744]
===
match
---
name: datetime [80238,80246]
name: datetime [80238,80246]
===
match
---
simple_stmt [23300,23336]
simple_stmt [23300,23336]
===
match
---
operator: = [39541,39542]
operator: = [39541,39542]
===
match
---
number: 0 [40280,40281]
number: 0 [40280,40281]
===
match
---
name: ti [13711,13713]
name: ti [13711,13713]
===
match
---
number: 2016 [20359,20363]
number: 2016 [20359,20363]
===
match
---
name: task_state_in_callback [3343,3365]
name: task_state_in_callback [3343,3365]
===
match
---
trailer [73234,73242]
trailer [73234,73242]
===
match
---
name: run [40820,40823]
name: run [40820,40823]
===
match
---
simple_stmt [1683,1731]
simple_stmt [1683,1731]
===
match
---
atom_expr [55962,55989]
atom_expr [55962,55989]
===
match
---
operator: = [5418,5419]
operator: = [5418,5419]
===
match
---
trailer [6938,6946]
trailer [6938,6946]
===
match
---
decorated [15192,16778]
decorated [15192,16778]
===
match
---
operator: , [65805,65806]
operator: , [65805,65806]
===
match
---
atom_expr [68416,68459]
atom_expr [68416,68459]
===
match
---
classdef [42321,42508]
classdef [42321,42508]
===
match
---
operator: , [76995,76996]
operator: , [76995,76996]
===
match
---
atom_expr [77137,77144]
atom_expr [77137,77144]
===
match
---
name: NONE [27246,27250]
name: NONE [27246,27250]
===
match
---
atom_expr [19230,19247]
atom_expr [19230,19247]
===
match
---
operator: , [32364,32365]
operator: , [32364,32365]
===
match
---
atom_expr [76178,76195]
atom_expr [76178,76195]
===
match
---
name: key [37223,37226]
name: key [37223,37226]
===
match
---
name: BashOperator [48201,48213]
name: BashOperator [48201,48213]
===
match
---
atom_expr [20946,20959]
atom_expr [20946,20959]
===
match
---
name: TI [64121,64123]
name: TI [64121,64123]
===
match
---
simple_stmt [60538,60698]
simple_stmt [60538,60698]
===
match
---
name: context_arg_2 [62829,62842]
name: context_arg_2 [62829,62842]
===
match
---
name: orm [1106,1109]
name: orm [1106,1109]
===
match
---
expr_stmt [2796,2819]
expr_stmt [2796,2819]
===
match
---
trailer [62962,62972]
trailer [62962,62972]
===
match
---
name: ret [52775,52778]
name: ret [52775,52778]
===
match
---
name: python_callable [74377,74392]
name: python_callable [74377,74392]
===
match
---
atom_expr [27729,27747]
atom_expr [27729,27747]
===
match
---
operator: = [31067,31068]
operator: = [31067,31068]
===
match
---
trailer [17059,17109]
trailer [17059,17109]
===
match
---
name: minutes [26314,26321]
name: minutes [26314,26321]
===
match
---
trailer [10836,10842]
trailer [10836,10842]
===
match
---
name: naive_datetime [5866,5880]
name: naive_datetime [5866,5880]
===
match
---
atom_expr [36510,36532]
atom_expr [36510,36532]
===
match
---
trailer [53535,53537]
trailer [53535,53537]
===
match
---
suite [3432,76539]
suite [3432,76539]
===
match
---
name: task [17375,17379]
name: task [17375,17379]
===
match
---
name: xcom_pull [39685,39694]
name: xcom_pull [39685,39694]
===
match
---
name: dag_id [73770,73776]
name: dag_id [73770,73776]
===
match
---
operator: = [6818,6819]
operator: = [6818,6819]
===
match
---
operator: = [34342,34343]
operator: = [34342,34343]
===
match
---
argument [20200,20209]
argument [20200,20209]
===
match
---
argument [56534,56553]
argument [56534,56553]
===
match
---
operator: = [57237,57238]
operator: = [57237,57238]
===
match
---
number: 6 [57086,57087]
number: 6 [57086,57087]
===
match
---
simple_stmt [80050,80102]
simple_stmt [80050,80102]
===
match
---
atom_expr [46906,46925]
atom_expr [46906,46925]
===
match
---
expr_stmt [68570,68643]
expr_stmt [68570,68643]
===
match
---
name: seconds [22606,22613]
name: seconds [22606,22613]
===
match
---
name: State [55376,55381]
name: State [55376,55381]
===
match
---
atom_expr [60955,60973]
atom_expr [60955,60973]
===
match
---
operator: = [39017,39018]
operator: = [39017,39018]
===
match
---
atom_expr [52646,52664]
atom_expr [52646,52664]
===
match
---
string: 'dag2' [6800,6806]
string: 'dag2' [6800,6806]
===
match
---
trailer [22829,22833]
trailer [22829,22833]
===
match
---
argument [52655,52663]
argument [52655,52663]
===
match
---
name: session [15912,15919]
name: session [15912,15919]
===
match
---
atom_expr [61320,61333]
atom_expr [61320,61333]
===
match
---
operator: , [64726,64727]
operator: , [64726,64727]
===
match
---
number: 0 [33307,33308]
number: 0 [33307,33308]
===
match
---
string: 'foo' [38198,38203]
string: 'foo' [38198,38203]
===
match
---
trailer [78418,78427]
trailer [78418,78427]
===
match
---
import_from [1090,1132]
import_from [1090,1132]
===
match
---
assert_stmt [70833,70878]
assert_stmt [70833,70878]
===
match
---
operator: , [42630,42631]
operator: , [42630,42631]
===
match
---
name: end_date [60635,60643]
name: end_date [60635,60643]
===
match
---
operator: = [56311,56312]
operator: = [56311,56312]
===
match
---
trailer [3317,3319]
trailer [3317,3319]
===
match
---
operator: , [72851,72852]
operator: , [72851,72852]
===
match
---
atom_expr [3127,3319]
atom_expr [3127,3319]
===
match
---
name: try_number [19497,19507]
name: try_number [19497,19507]
===
match
---
name: self [65388,65392]
name: self [65388,65392]
===
match
---
trailer [22820,22829]
trailer [22820,22829]
===
match
---
comparison [64284,64308]
comparison [64284,64308]
===
match
---
trailer [12438,12451]
trailer [12438,12451]
===
match
---
simple_stmt [31112,31136]
simple_stmt [31112,31136]
===
match
---
atom_expr [29234,29255]
atom_expr [29234,29255]
===
match
---
simple_stmt [44854,44903]
simple_stmt [44854,44903]
===
match
---
name: ti1 [61923,61926]
name: ti1 [61923,61926]
===
match
---
name: ti_list [54924,54931]
name: ti_list [54924,54931]
===
match
---
atom_expr [9964,9981]
atom_expr [9964,9981]
===
match
---
number: 0 [24841,24842]
number: 0 [24841,24842]
===
match
---
funcdef [51921,52396]
funcdef [51921,52396]
===
match
---
name: airflow [2107,2114]
name: airflow [2107,2114]
===
match
---
name: dag_id [48157,48163]
name: dag_id [48157,48163]
===
match
---
name: session [52365,52372]
name: session [52365,52372]
===
match
---
string: 'test_retry_handling_op' [18719,18743]
string: 'test_retry_handling_op' [18719,18743]
===
match
---
name: new_ti [68717,68723]
name: new_ti [68717,68723]
===
match
---
name: run [15943,15946]
name: run [15943,15946]
===
match
---
operator: , [66432,66433]
operator: , [66432,66433]
===
match
---
name: DEFAULT_DATE [68695,68707]
name: DEFAULT_DATE [68695,68707]
===
match
---
atom_expr [45134,45147]
atom_expr [45134,45147]
===
match
---
name: seconds [22637,22644]
name: seconds [22637,22644]
===
match
---
operator: = [64470,64471]
operator: = [64470,64471]
===
match
---
operator: , [60621,60622]
operator: , [60621,60622]
===
match
---
arglist [53028,53081]
arglist [53028,53081]
===
match
---
atom_expr [10832,10842]
atom_expr [10832,10842]
===
match
---
operator: = [65792,65793]
operator: = [65792,65793]
===
match
---
argument [4954,5006]
argument [4954,5006]
===
match
---
name: dag_id [67635,67641]
name: dag_id [67635,67641]
===
match
---
expr_stmt [58326,58373]
expr_stmt [58326,58373]
===
match
---
trailer [64165,64167]
trailer [64165,64167]
===
match
---
argument [54693,54712]
argument [54693,54712]
===
match
---
string: 'all_done' [33662,33672]
string: 'all_done' [33662,33672]
===
match
---
string: '2016-01-01T00_00_00_plus_00_00' [69796,69828]
string: '2016-01-01T00_00_00_plus_00_00' [69796,69828]
===
match
---
name: dag [79634,79637]
name: dag [79634,79637]
===
match
---
expr_stmt [47063,47097]
expr_stmt [47063,47097]
===
match
---
atom_expr [32612,32633]
atom_expr [32612,32633]
===
match
---
name: get_task_instance [74777,74794]
name: get_task_instance [74777,74794]
===
match
---
operator: = [9306,9307]
operator: = [9306,9307]
===
match
---
operator: = [17274,17275]
operator: = [17274,17275]
===
match
---
name: executor_config [16259,16274]
name: executor_config [16259,16274]
===
match
---
name: task_id [75151,75158]
name: task_id [75151,75158]
===
match
---
operator: = [7578,7579]
operator: = [7578,7579]
===
match
---
atom_expr [3027,3044]
atom_expr [3027,3044]
===
match
---
atom_expr [32772,32793]
atom_expr [32772,32793]
===
match
---
operator: , [33370,33371]
operator: , [33370,33371]
===
match
---
operator: = [67942,67943]
operator: = [67942,67943]
===
match
---
trailer [45303,45320]
trailer [45303,45320]
===
match
---
atom_expr [73663,73718]
atom_expr [73663,73718]
===
match
---
number: 0 [14194,14195]
number: 0 [14194,14195]
===
match
---
expr_stmt [78376,78434]
expr_stmt [78376,78434]
===
match
---
arith_expr [4965,5006]
arith_expr [4965,5006]
===
match
---
operator: , [12333,12334]
operator: , [12333,12334]
===
match
---
atom_expr [39520,39563]
atom_expr [39520,39563]
===
match
---
operator: = [8671,8672]
operator: = [8671,8672]
===
match
---
trailer [37677,37687]
trailer [37677,37687]
===
match
---
string: "D -> C -> B & A -> B, when A runs but C isn't QUEUED yet, B shouldn't be QUEUED." [72909,72991]
string: "D -> C -> B & A -> B, when A runs but C isn't QUEUED yet, B shouldn't be QUEUED." [72909,72991]
===
match
---
operator: , [38713,38714]
operator: , [38713,38714]
===
match
---
string: 'test_get_rendered_k8s_spec' [70315,70343]
string: 'test_get_rendered_k8s_spec' [70315,70343]
===
match
---
simple_stmt [61532,61569]
simple_stmt [61532,61569]
===
match
---
operator: , [14056,14057]
operator: , [14056,14057]
===
match
---
argument [16639,16654]
argument [16639,16654]
===
match
---
name: clear [21090,21095]
name: clear [21090,21095]
===
match
---
string: 'scheduler' [72193,72204]
string: 'scheduler' [72193,72204]
===
match
---
trailer [51521,51529]
trailer [51521,51529]
===
match
---
name: opener [49418,49424]
name: opener [49418,49424]
===
match
---
name: DAG [23313,23316]
name: DAG [23313,23316]
===
match
---
name: ti [43209,43211]
name: ti [43209,43211]
===
match
---
simple_stmt [7007,7026]
simple_stmt [7007,7026]
===
match
---
name: utcnow [48385,48391]
name: utcnow [48385,48391]
===
match
---
name: ti [58292,58294]
name: ti [58292,58294]
===
match
---
name: pool [10793,10797]
name: pool [10793,10797]
===
match
---
operator: , [31771,31772]
operator: , [31771,31772]
===
match
---
arglist [6749,6779]
arglist [6749,6779]
===
match
---
simple_stmt [3561,3585]
simple_stmt [3561,3585]
===
match
---
operator: = [30619,30620]
operator: = [30619,30620]
===
match
---
name: title [49689,49694]
name: title [49689,49694]
===
match
---
atom_expr [6936,6948]
atom_expr [6936,6948]
===
match
---
atom_expr [60469,60494]
atom_expr [60469,60494]
===
match
---
atom_expr [13404,13420]
atom_expr [13404,13420]
===
match
---
atom_expr [44780,44844]
atom_expr [44780,44844]
===
match
---
simple_stmt [18304,18455]
simple_stmt [18304,18455]
===
match
---
simple_stmt [49801,49860]
simple_stmt [49801,49860]
===
match
---
argument [49213,49223]
argument [49213,49223]
===
match
---
trailer [30135,30137]
trailer [30135,30137]
===
match
---
dotted_name [58880,58900]
dotted_name [58880,58900]
===
match
---
name: run [64857,64860]
name: run [64857,64860]
===
match
---
operator: , [66624,66625]
operator: , [66624,66625]
===
match
---
number: 1 [32520,32521]
number: 1 [32520,32521]
===
match
---
dictorsetmaker [59561,59583]
dictorsetmaker [59561,59583]
===
match
---
name: pytest [6962,6968]
name: pytest [6962,6968]
===
match
---
name: self [48108,48112]
name: self [48108,48112]
===
match
---
expr_stmt [23793,23843]
expr_stmt [23793,23843]
===
match
---
operator: , [38604,38605]
operator: , [38604,38605]
===
match
---
simple_stmt [52768,52779]
simple_stmt [52768,52779]
===
match
---
atom_expr [57209,57256]
atom_expr [57209,57256]
===
match
---
name: ti [68455,68457]
name: ti [68455,68457]
===
match
---
atom_expr [49042,49234]
atom_expr [49042,49234]
===
match
---
name: timedelta [50635,50644]
name: timedelta [50635,50644]
===
match
---
trailer [55539,55547]
trailer [55539,55547]
===
match
---
argument [18711,18743]
argument [18711,18743]
===
match
---
argument [36435,36458]
argument [36435,36458]
===
match
---
name: task [38792,38796]
name: task [38792,38796]
===
match
---
suite [19820,21570]
suite [19820,21570]
===
match
---
argument [13270,13302]
argument [13270,13302]
===
match
---
funcdef [35184,35934]
funcdef [35184,35934]
===
match
---
operator: = [39987,39988]
operator: = [39987,39988]
===
match
---
trailer [54166,54174]
trailer [54166,54174]
===
match
---
name: datetime [28637,28645]
name: datetime [28637,28645]
===
match
---
trailer [77545,77554]
trailer [77545,77554]
===
match
---
arglist [76037,76067]
arglist [76037,76067]
===
match
---
operator: , [10438,10439]
operator: , [10438,10439]
===
match
---
trailer [8074,8078]
trailer [8074,8078]
===
match
---
operator: = [67999,68000]
operator: = [67999,68000]
===
match
---
operator: = [46640,46641]
operator: = [46640,46641]
===
match
---
argument [19131,19140]
argument [19131,19140]
===
match
---
trailer [64856,64860]
trailer [64856,64860]
===
match
---
string: 'test_queries' [78953,78967]
string: 'test_queries' [78953,78967]
===
match
---
name: state [9347,9352]
name: state [9347,9352]
===
match
---
operator: , [31777,31778]
operator: , [31777,31778]
===
match
---
operator: , [32100,32101]
operator: , [32100,32101]
===
match
---
argument [28838,28847]
argument [28838,28847]
===
match
---
atom_expr [35349,35371]
atom_expr [35349,35371]
===
match
---
name: session [13424,13431]
name: session [13424,13431]
===
match
---
trailer [36682,36684]
trailer [36682,36684]
===
match
---
operator: , [48359,48360]
operator: , [48359,48360]
===
match
---
name: start_date [4067,4077]
name: start_date [4067,4077]
===
match
---
trailer [10894,10901]
trailer [10894,10901]
===
match
---
name: execution_date [16401,16415]
name: execution_date [16401,16415]
===
match
---
name: minutes [21697,21704]
name: minutes [21697,21704]
===
match
---
atom_expr [77432,77452]
atom_expr [77432,77452]
===
match
---
arglist [42768,42778]
arglist [42768,42778]
===
match
---
string: 'test_does_not_retry_on_airflow_fail_exception' [63791,63838]
string: 'test_does_not_retry_on_airflow_fail_exception' [63791,63838]
===
match
---
atom_expr [8287,8318]
atom_expr [8287,8318]
===
match
---
simple_stmt [13931,13980]
simple_stmt [13931,13980]
===
match
---
trailer [13754,13760]
trailer [13754,13760]
===
match
---
operator: , [63947,63948]
operator: , [63947,63948]
===
match
---
assert_stmt [20594,20619]
assert_stmt [20594,20619]
===
match
---
name: serialize_operator [79932,79950]
name: serialize_operator [79932,79950]
===
match
---
name: task_id [42607,42614]
name: task_id [42607,42614]
===
match
---
simple_stmt [60134,60170]
simple_stmt [60134,60170]
===
match
---
operator: , [19947,19948]
operator: , [19947,19948]
===
match
---
name: dag [44730,44733]
name: dag [44730,44733]
===
match
---
with_stmt [6957,7026]
with_stmt [6957,7026]
===
match
---
trailer [76525,76534]
trailer [76525,76534]
===
match
---
operator: , [32996,32997]
operator: , [32996,32997]
===
match
---
expr_stmt [15445,15680]
expr_stmt [15445,15680]
===
match
---
trailer [20782,20793]
trailer [20782,20793]
===
match
---
name: start_date [36943,36953]
name: start_date [36943,36953]
===
match
---
operator: | [11688,11689]
operator: | [11688,11689]
===
match
---
argument [49068,49106]
argument [49068,49106]
===
match
---
argument [24414,24447]
argument [24414,24447]
===
match
---
name: expected_url [46235,46247]
name: expected_url [46235,46247]
===
match
---
comparison [19448,19478]
comparison [19448,19478]
===
match
---
operator: -> [53277,53279]
operator: -> [53277,53279]
===
match
---
argument [5512,5531]
argument [5512,5531]
===
match
---
atom_expr [12895,12913]
atom_expr [12895,12913]
===
match
---
operator: = [54566,54567]
operator: = [54566,54567]
===
match
---
number: 3 [76773,76774]
number: 3 [76773,76774]
===
match
---
trailer [12366,12370]
trailer [12366,12370]
===
match
---
name: dag [56469,56472]
name: dag [56469,56472]
===
match
---
comparison [65259,65354]
comparison [65259,65354]
===
match
---
argument [74717,74736]
argument [74717,74736]
===
match
---
argument [35242,35259]
argument [35242,35259]
===
match
---
atom [33348,33396]
atom [33348,33396]
===
match
---
name: generate_command [67925,67941]
name: generate_command [67925,67941]
===
match
---
arglist [64550,64757]
arglist [64550,64757]
===
match
---
operator: , [33582,33583]
operator: , [33582,33583]
===
match
---
simple_stmt [35274,35336]
simple_stmt [35274,35336]
===
match
---
name: task [59733,59737]
name: task [59733,59737]
===
match
---
operator: , [15665,15666]
operator: , [15665,15666]
===
match
---
param [36195,36200]
param [36195,36200]
===
match
---
name: tzinfo [6599,6605]
name: tzinfo [6599,6605]
===
match
---
testlist_comp [33153,33208]
testlist_comp [33153,33208]
===
match
---
atom_expr [44700,44763]
atom_expr [44700,44763]
===
match
---
name: TI [37414,37416]
name: TI [37414,37416]
===
match
---
operator: , [15009,15010]
operator: , [15009,15010]
===
match
---
number: 5 [32976,32977]
number: 5 [32976,32977]
===
match
---
name: _run_finished_callback [62648,62670]
name: _run_finished_callback [62648,62670]
===
match
---
trailer [22833,22846]
trailer [22833,22846]
===
match
---
atom_expr [30727,30753]
atom_expr [30727,30753]
===
match
---
name: ti [77324,77326]
name: ti [77324,77326]
===
match
---
name: airflow [1268,1275]
name: airflow [1268,1275]
===
match
---
expr_stmt [22715,22746]
expr_stmt [22715,22746]
===
match
---
name: DAG [79542,79545]
name: DAG [79542,79545]
===
match
---
atom_expr [73249,73261]
atom_expr [73249,73261]
===
match
---
atom_expr [66900,66916]
atom_expr [66900,66916]
===
match
---
trailer [60852,60903]
trailer [60852,60903]
===
match
---
operator: , [31902,31903]
operator: , [31902,31903]
===
match
---
trailer [20716,20729]
trailer [20716,20729]
===
match
---
trailer [79204,79218]
trailer [79204,79218]
===
match
---
expr_stmt [50191,50249]
expr_stmt [50191,50249]
===
match
---
operator: = [18930,18931]
operator: = [18930,18931]
===
match
---
operator: @ [31565,31566]
operator: @ [31565,31566]
===
match
---
operator: , [79079,79080]
operator: , [79079,79080]
===
match
---
argument [9276,9283]
argument [9276,9283]
===
match
---
operator: , [41176,41177]
operator: , [41176,41177]
===
match
---
name: self [53240,53244]
name: self [53240,53244]
===
match
---
name: class_name [12476,12486]
name: class_name [12476,12486]
===
match
---
name: _try_number [27269,27280]
name: _try_number [27269,27280]
===
match
---
trailer [54744,54747]
trailer [54744,54747]
===
match
---
atom_expr [72716,72728]
atom_expr [72716,72728]
===
match
---
name: result [58389,58395]
name: result [58389,58395]
===
match
---
expr_stmt [5833,5881]
expr_stmt [5833,5881]
===
match
---
argument [6876,6888]
argument [6876,6888]
===
match
---
name: session [79378,79385]
name: session [79378,79385]
===
match
---
expr_stmt [24397,24448]
expr_stmt [24397,24448]
===
match
---
argument [74134,74145]
argument [74134,74145]
===
match
---
atom_expr [64854,64862]
atom_expr [64854,64862]
===
match
---
name: RUNNING [61072,61079]
name: RUNNING [61072,61079]
===
match
---
name: utcnow [29957,29963]
name: utcnow [29957,29963]
===
match
---
number: 0 [32600,32601]
number: 0 [32600,32601]
===
match
---
string: "op" [55984,55988]
string: "op" [55984,55988]
===
match
---
string: 'airflow_version' [69670,69687]
string: 'airflow_version' [69670,69687]
===
match
---
expr_stmt [69127,69196]
expr_stmt [69127,69196]
===
match
---
suite [36289,36496]
suite [36289,36496]
===
match
---
name: keep_blank_values [46794,46811]
name: keep_blank_values [46794,46811]
===
match
---
trailer [39463,39504]
trailer [39463,39504]
===
match
---
number: 1 [24987,24988]
number: 1 [24987,24988]
===
match
---
atom_expr [74947,74996]
atom_expr [74947,74996]
===
match
---
operator: = [47447,47448]
operator: = [47447,47448]
===
match
---
arglist [50707,50843]
arglist [50707,50843]
===
match
---
name: task [77342,77346]
name: task [77342,77346]
===
match
---
name: task_id [24490,24497]
name: task_id [24490,24497]
===
match
---
parameters [54423,54460]
parameters [54423,54460]
===
match
---
name: execution_date [64135,64149]
name: execution_date [64135,64149]
===
match
---
simple_stmt [903,929]
simple_stmt [903,929]
===
match
---
number: 2 [31895,31896]
number: 2 [31895,31896]
===
match
---
atom_expr [68780,68800]
atom_expr [68780,68800]
===
match
---
atom_expr [55493,55548]
atom_expr [55493,55548]
===
match
---
dictorsetmaker [16019,16031]
dictorsetmaker [16019,16031]
===
match
---
number: 5 [32970,32971]
number: 5 [32970,32971]
===
match
---
operator: } [47269,47270]
operator: } [47269,47270]
===
match
---
name: mock_send_email [48114,48129]
name: mock_send_email [48114,48129]
===
match
---
name: self [21604,21608]
name: self [21604,21608]
===
match
---
name: dag [11334,11337]
name: dag [11334,11337]
===
match
---
operator: , [78084,78085]
operator: , [78084,78085]
===
match
---
name: ti [21378,21380]
name: ti [21378,21380]
===
match
---
operator: , [48112,48113]
operator: , [48112,48113]
===
match
---
trailer [3563,3582]
trailer [3563,3582]
===
match
---
operator: = [74055,74056]
operator: = [74055,74056]
===
match
---
simple_stmt [2917,2943]
simple_stmt [2917,2943]
===
match
---
number: 0 [16351,16352]
number: 0 [16351,16352]
===
match
---
parameters [23186,23192]
parameters [23186,23192]
===
match
---
suite [6994,7026]
suite [6994,7026]
===
match
---
name: run_date [30928,30936]
name: run_date [30928,30936]
===
match
---
operator: , [1160,1161]
operator: , [1160,1161]
===
match
---
trailer [78532,78714]
trailer [78532,78714]
===
match
---
name: add [13453,13456]
name: add [13453,13456]
===
match
---
name: task_id [7531,7538]
name: task_id [7531,7538]
===
match
---
atom_expr [20538,20585]
atom_expr [20538,20585]
===
match
---
name: TI [6187,6189]
name: TI [6187,6189]
===
match
---
operator: == [20794,20796]
operator: == [20794,20796]
===
match
---
atom_expr [66925,66943]
atom_expr [66925,66943]
===
match
---
name: utcnow [18286,18292]
name: utcnow [18286,18292]
===
match
---
trailer [40322,40329]
trailer [40322,40329]
===
match
---
parameters [16826,16832]
parameters [16826,16832]
===
match
---
name: fail [63699,63703]
name: fail [63699,63703]
===
match
---
simple_stmt [43141,43194]
simple_stmt [43141,43194]
===
match
---
operator: , [65642,65643]
operator: , [65642,65643]
===
match
---
simple_stmt [2241,2284]
simple_stmt [2241,2284]
===
match
---
operator: = [10599,10600]
operator: = [10599,10600]
===
match
---
operator: = [22931,22932]
operator: = [22931,22932]
===
match
---
name: utcnow [43831,43837]
name: utcnow [43831,43837]
===
match
---
name: refresh_from_db [30149,30164]
name: refresh_from_db [30149,30164]
===
match
---
simple_stmt [42574,42791]
simple_stmt [42574,42791]
===
match
---
operator: , [28611,28612]
operator: , [28611,28612]
===
match
---
operator: , [43106,43107]
operator: , [43106,43107]
===
match
---
operator: , [33490,33491]
operator: , [33490,33491]
===
match
---
name: DEFAULT_DATE [55897,55909]
name: DEFAULT_DATE [55897,55909]
===
match
---
atom_expr [11542,11554]
atom_expr [11542,11554]
===
match
---
operator: , [7748,7749]
operator: , [7748,7749]
===
match
---
name: timezone [76178,76186]
name: timezone [76178,76186]
===
match
---
simple_stmt [1263,1315]
simple_stmt [1263,1315]
===
match
---
operator: = [37986,37987]
operator: = [37986,37987]
===
match
---
name: dep_patch [12516,12525]
name: dep_patch [12516,12525]
===
match
---
simple_stmt [59820,59868]
simple_stmt [59820,59868]
===
match
---
atom_expr [3338,3365]
atom_expr [3338,3365]
===
match
---
arglist [53402,53438]
arglist [53402,53438]
===
match
---
trailer [53482,53484]
trailer [53482,53484]
===
match
---
name: timezone [64035,64043]
name: timezone [64035,64043]
===
match
---
name: state [79286,79291]
name: state [79286,79291]
===
match
---
name: get_num_running_task_instances [45273,45303]
name: get_num_running_task_instances [45273,45303]
===
match
---
trailer [41774,41786]
trailer [41774,41786]
===
match
---
expr_stmt [29940,29965]
expr_stmt [29940,29965]
===
match
---
operator: , [73205,73206]
operator: , [73205,73206]
===
match
---
trailer [62972,62974]
trailer [62972,62974]
===
match
---
simple_stmt [76652,76940]
simple_stmt [76652,76940]
===
match
---
trailer [36269,36288]
trailer [36269,36288]
===
match
---
atom_expr [44127,44190]
atom_expr [44127,44190]
===
match
---
string: "{{ task.task_id }}" [71059,71079]
string: "{{ task.task_id }}" [71059,71079]
===
match
---
atom_expr [79453,79471]
atom_expr [79453,79471]
===
match
---
name: add_task [4763,4771]
name: add_task [4763,4771]
===
match
---
name: dag_model [73732,73741]
name: dag_model [73732,73741]
===
match
---
comparison [46433,46459]
comparison [46433,46459]
===
match
---
name: conf_vars [73586,73595]
name: conf_vars [73586,73595]
===
match
---
number: 3 [55597,55598]
number: 3 [55597,55598]
===
match
---
string: 'DummyOperator' [80086,80101]
string: 'DummyOperator' [80086,80101]
===
match
---
trailer [62647,62670]
trailer [62647,62670]
===
match
---
string: 'baz' [37724,37729]
string: 'baz' [37724,37729]
===
match
---
name: key [37835,37838]
name: key [37835,37838]
===
match
---
assert_stmt [77213,77252]
assert_stmt [77213,77252]
===
match
---
name: clear_db_runs [77733,77746]
name: clear_db_runs [77733,77746]
===
match
---
operator: , [17337,17338]
operator: , [17337,17338]
===
match
---
trailer [58821,58873]
trailer [58821,58873]
===
match
---
operator: , [65633,65634]
operator: , [65633,65634]
===
match
---
operator: = [78605,78606]
operator: = [78605,78606]
===
match
---
trailer [10918,10920]
trailer [10918,10920]
===
match
---
number: 1 [44985,44986]
number: 1 [44985,44986]
===
match
---
number: 0 [30048,30049]
number: 0 [30048,30049]
===
match
---
operator: , [26983,26984]
operator: , [26983,26984]
===
match
---
name: start_date [5730,5740]
name: start_date [5730,5740]
===
match
---
operator: = [61777,61778]
operator: = [61777,61778]
===
match
---
name: retries [64087,64094]
name: retries [64087,64094]
===
match
---
name: datetime [2615,2623]
name: datetime [2615,2623]
===
match
---
trailer [54704,54712]
trailer [54704,54712]
===
match
---
dotted_name [1584,1608]
dotted_name [1584,1608]
===
match
---
operator: = [69281,69282]
operator: = [69281,69282]
===
match
---
operator: = [23286,23287]
operator: = [23286,23287]
===
match
---
trailer [23999,24010]
trailer [23999,24010]
===
match
---
operator: , [27863,27864]
operator: , [27863,27864]
===
match
---
operator: , [49569,49570]
operator: , [49569,49570]
===
match
---
operator: , [48310,48311]
operator: , [48310,48311]
===
match
---
simple_stmt [63767,63840]
simple_stmt [63767,63840]
===
match
---
name: run_ti_and_assert [28965,28982]
name: run_ti_and_assert [28965,28982]
===
match
---
name: rtif [70815,70819]
name: rtif [70815,70819]
===
match
---
name: int [34024,34027]
name: int [34024,34027]
===
match
---
name: UP_FOR_RETRY [76320,76332]
name: UP_FOR_RETRY [76320,76332]
===
match
---
number: 2 [24832,24833]
number: 2 [24832,24833]
===
match
---
atom_expr [28864,28881]
atom_expr [28864,28881]
===
match
---
operator: , [38663,38664]
operator: , [38663,38664]
===
match
---
param [59418,59426]
param [59418,59426]
===
match
---
operator: == [65315,65317]
operator: == [65315,65317]
===
match
---
name: DEFAULT_DATE [79573,79585]
name: DEFAULT_DATE [79573,79585]
===
match
---
param [14553,14557]
param [14553,14557]
===
match
---
trailer [9541,9543]
trailer [9541,9543]
===
match
---
operator: = [40178,40179]
operator: = [40178,40179]
===
match
---
trailer [50913,50917]
trailer [50913,50917]
===
match
---
argument [17506,17525]
argument [17506,17525]
===
match
---
name: state [18381,18386]
name: state [18381,18386]
===
match
---
name: utcnow [44242,44248]
name: utcnow [44242,44248]
===
match
---
operator: = [3771,3772]
operator: = [3771,3772]
===
match
---
name: self [53899,53903]
name: self [53899,53903]
===
match
---
with_stmt [16067,16372]
with_stmt [16067,16372]
===
match
---
name: task [19131,19135]
name: task [19131,19135]
===
match
---
name: session [51179,51186]
name: session [51179,51186]
===
match
---
name: serialized_objects [1758,1776]
name: serialized_objects [1758,1776]
===
match
---
expr_stmt [28231,28243]
expr_stmt [28231,28243]
===
match
---
trailer [56853,56864]
trailer [56853,56864]
===
match
---
expr_stmt [37013,37042]
expr_stmt [37013,37042]
===
match
---
arglist [15483,15666]
arglist [15483,15666]
===
match
---
atom_expr [33188,33201]
atom_expr [33188,33201]
===
match
---
operator: , [38726,38727]
operator: , [38726,38727]
===
match
---
simple_stmt [65096,65160]
simple_stmt [65096,65160]
===
match
---
string: 'op1' [68262,68267]
string: 'op1' [68262,68267]
===
match
---
expr_stmt [24247,24259]
expr_stmt [24247,24259]
===
match
---
name: State [53307,53312]
name: State [53307,53312]
===
match
---
trailer [44322,44328]
trailer [44322,44328]
===
match
---
name: task_instance [71520,71533]
name: task_instance [71520,71533]
===
match
---
string: 'dag' [5723,5728]
string: 'dag' [5723,5728]
===
match
---
param [76012,76016]
param [76012,76016]
===
match
---
trailer [52650,52654]
trailer [52650,52654]
===
match
---
name: deserialized_op [80206,80221]
name: deserialized_op [80206,80221]
===
match
---
operator: , [32974,32975]
operator: , [32974,32975]
===
match
---
trailer [42758,42767]
trailer [42758,42767]
===
match
---
string: 'airflow.models.taskinstance.send_email' [48870,48910]
string: 'airflow.models.taskinstance.send_email' [48870,48910]
===
match
---
operator: = [50261,50262]
operator: = [50261,50262]
===
match
---
operator: , [43721,43722]
operator: , [43721,43722]
===
match
---
parameters [67619,67625]
parameters [67619,67625]
===
match
---
number: 1 [31898,31899]
number: 1 [31898,31899]
===
match
---
name: days [50645,50649]
name: days [50645,50649]
===
match
---
name: TIDepStatus [12301,12312]
name: TIDepStatus [12301,12312]
===
match
---
name: datetime [40253,40261]
name: datetime [40253,40261]
===
match
---
name: utcnow [26154,26160]
name: utcnow [26154,26160]
===
match
---
decorator [48691,48859]
decorator [48691,48859]
===
match
---
name: trs [25976,25979]
name: trs [25976,25979]
===
match
---
operator: = [41516,41517]
operator: = [41516,41517]
===
match
---
trailer [55562,55573]
trailer [55562,55573]
===
match
---
tfpdef [34172,34194]
tfpdef [34172,34194]
===
match
---
suite [7399,8363]
suite [7399,8363]
===
match
---
atom_expr [5193,5207]
atom_expr [5193,5207]
===
match
---
name: session [16759,16766]
name: session [16759,16766]
===
match
---
name: ti [39032,39034]
name: ti [39032,39034]
===
match
---
operator: , [71775,71776]
operator: , [71775,71776]
===
match
---
name: start_date [34311,34321]
name: start_date [34311,34321]
===
match
---
simple_stmt [73926,73942]
simple_stmt [73926,73942]
===
match
---
operator: , [29037,29038]
operator: , [29037,29038]
===
match
---
with_stmt [68828,68925]
with_stmt [68828,68925]
===
match
---
name: TI [3213,3215]
name: TI [3213,3215]
===
match
---
expr_stmt [41358,41387]
expr_stmt [41358,41387]
===
match
---
operator: = [44984,44985]
operator: = [44984,44985]
===
match
---
name: dag [4050,4053]
name: dag [4050,4053]
===
match
---
name: run [19050,19053]
name: run [19050,19053]
===
match
---
testlist_comp [31675,31721]
testlist_comp [31675,31721]
===
match
---
string: 'op1' [71039,71044]
string: 'op1' [71039,71044]
===
match
---
name: datetime [26241,26249]
name: datetime [26241,26249]
===
match
---
name: ti [19760,19762]
name: ti [19760,19762]
===
match
---
operator: , [27936,27937]
operator: , [27936,27937]
===
match
---
string: "AIRFLOW_IS_K8S_EXECUTOR_POD" [68960,68989]
string: "AIRFLOW_IS_K8S_EXECUTOR_POD" [68960,68989]
===
match
---
name: dag2 [6789,6793]
name: dag2 [6789,6793]
===
match
---
string: 'test_mark_non_runnable_task_as_success_op' [13045,13088]
string: 'test_mark_non_runnable_task_as_success_op' [13045,13088]
===
match
---
name: State [72401,72406]
name: State [72401,72406]
===
match
---
name: task [46667,46671]
name: task [46667,46671]
===
match
---
simple_stmt [11664,11700]
simple_stmt [11664,11700]
===
match
---
trailer [12299,12351]
trailer [12299,12351]
===
match
---
argument [38194,38203]
argument [38194,38203]
===
match
---
operator: = [42013,42014]
operator: = [42013,42014]
===
match
---
name: execution_date [6044,6058]
name: execution_date [6044,6058]
===
match
---
operator: = [17400,17401]
operator: = [17400,17401]
===
match
---
name: State [27729,27734]
name: State [27729,27734]
===
match
---
simple_stmt [60033,60069]
simple_stmt [60033,60069]
===
match
---
trailer [74572,74580]
trailer [74572,74580]
===
match
---
trailer [40705,40707]
trailer [40705,40707]
===
match
---
name: deps [2058,2062]
name: deps [2058,2062]
===
match
---
name: key [38194,38197]
name: key [38194,38197]
===
match
---
name: models [15382,15388]
name: models [15382,15388]
===
match
---
operator: = [71106,71107]
operator: = [71106,71107]
===
match
---
trailer [38766,38773]
trailer [38766,38773]
===
match
---
name: pytest [58764,58770]
name: pytest [58764,58770]
===
match
---
string: 'A' [71832,71835]
string: 'A' [71832,71835]
===
match
---
trailer [75698,75739]
trailer [75698,75739]
===
match
---
trailer [7417,7449]
trailer [7417,7449]
===
match
---
operator: = [38478,38479]
operator: = [38478,38479]
===
match
---
trailer [54572,54599]
trailer [54572,54599]
===
match
---
parameters [6627,6633]
parameters [6627,6633]
===
match
---
name: date1 [27603,27608]
name: date1 [27603,27608]
===
match
---
name: max_active_runs [9143,9158]
name: max_active_runs [9143,9158]
===
match
---
simple_stmt [19726,19745]
simple_stmt [19726,19745]
===
match
---
trailer [54135,54138]
trailer [54135,54138]
===
match
---
name: start_date [36435,36445]
name: start_date [36435,36445]
===
match
---
operator: @ [48691,48692]
operator: @ [48691,48692]
===
match
---
operator: = [4459,4460]
operator: = [4459,4460]
===
match
---
funcdef [10223,10959]
funcdef [10223,10959]
===
match
---
name: State [36091,36096]
name: State [36091,36096]
===
match
---
name: exec_date [38746,38755]
name: exec_date [38746,38755]
===
match
---
simple_stmt [69263,70698]
simple_stmt [69263,70698]
===
match
---
atom_expr [34479,34540]
atom_expr [34479,34540]
===
match
---
argument [76682,76697]
argument [76682,76697]
===
match
---
operator: = [47910,47911]
operator: = [47910,47911]
===
match
---
with_stmt [35233,35336]
with_stmt [35233,35336]
===
match
---
trailer [36407,36459]
trailer [36407,36459]
===
match
---
name: create_session [68833,68847]
name: create_session [68833,68847]
===
match
---
atom_expr [67024,67034]
atom_expr [67024,67034]
===
match
---
trailer [38886,38901]
trailer [38886,38901]
===
match
---
string: 'subject_template' [48735,48753]
string: 'subject_template' [48735,48753]
===
match
---
suite [75306,75493]
suite [75306,75493]
===
match
---
operator: == [29746,29748]
operator: == [29746,29748]
===
match
---
simple_stmt [54917,55013]
simple_stmt [54917,55013]
===
match
---
atom_expr [51403,51442]
atom_expr [51403,51442]
===
match
---
operator: = [10486,10487]
operator: = [10486,10487]
===
match
---
operator: == [19769,19771]
operator: == [19769,19771]
===
match
---
arglist [40772,40807]
arglist [40772,40807]
===
match
---
comparison [41134,41212]
comparison [41134,41212]
===
match
---
operator: { [71793,71794]
operator: { [71793,71794]
===
match
---
argument [30864,30893]
argument [30864,30893]
===
match
---
name: ti [41979,41981]
name: ti [41979,41981]
===
match
---
atom_expr [4810,4824]
atom_expr [4810,4824]
===
match
---
name: SCHEDULED [79343,79352]
name: SCHEDULED [79343,79352]
===
match
---
operator: = [58333,58334]
operator: = [58333,58334]
===
match
---
operator: , [73051,73052]
operator: , [73051,73052]
===
match
---
number: 2 [23703,23704]
number: 2 [23703,23704]
===
match
---
operator: = [26321,26322]
operator: = [26321,26322]
===
match
---
atom_expr [28427,28820]
atom_expr [28427,28820]
===
match
---
name: task [44693,44697]
name: task [44693,44697]
===
match
---
operator: , [31715,31716]
operator: , [31715,31716]
===
match
---
operator: = [12293,12294]
operator: = [12293,12294]
===
match
---
arglist [40601,40621]
arglist [40601,40621]
===
match
---
name: dag [67024,67027]
name: dag [67024,67027]
===
match
---
operator: , [9899,9900]
operator: , [9899,9900]
===
match
---
trailer [28376,28411]
trailer [28376,28411]
===
match
---
name: state [61311,61316]
name: state [61311,61316]
===
match
---
fstring_start: f' [34501,34503]
fstring_start: f' [34501,34503]
===
match
---
operator: , [41935,41936]
operator: , [41935,41936]
===
match
---
name: dag [65639,65642]
name: dag [65639,65642]
===
match
---
name: State [21189,21194]
name: State [21189,21194]
===
match
---
operator: , [50588,50589]
operator: , [50588,50589]
===
match
---
name: State [66181,66186]
name: State [66181,66186]
===
match
---
name: ti_1 [56818,56822]
name: ti_1 [56818,56822]
===
match
---
string: 'test' [7558,7564]
string: 'test' [7558,7564]
===
match
---
operator: = [6881,6882]
operator: = [6881,6882]
===
match
---
string: 'exit 1' [18770,18778]
string: 'exit 1' [18770,18778]
===
match
---
name: ti [13251,13253]
name: ti [13251,13253]
===
match
---
string: 'airflow' [18151,18160]
string: 'airflow' [18151,18160]
===
match
---
atom_expr [4792,4806]
atom_expr [4792,4806]
===
match
---
name: ti [51288,51290]
name: ti [51288,51290]
===
match
---
trailer [50805,50821]
trailer [50805,50821]
===
match
---
trailer [60167,60169]
trailer [60167,60169]
===
match
---
name: task [59675,59679]
name: task [59675,59679]
===
match
---
comparison [51504,51529]
comparison [51504,51529]
===
match
---
name: State [72418,72423]
name: State [72418,72423]
===
match
---
assert_stmt [55407,55477]
assert_stmt [55407,55477]
===
match
---
argument [24662,24703]
argument [24662,24703]
===
match
---
simple_stmt [62013,62063]
simple_stmt [62013,62063]
===
match
---
trailer [29465,29471]
trailer [29465,29471]
===
match
---
trailer [54243,54246]
trailer [54243,54246]
===
match
---
param [73505,73516]
param [73505,73516]
===
match
---
trailer [3658,3660]
trailer [3658,3660]
===
match
---
atom_expr [52181,52200]
atom_expr [52181,52200]
===
match
---
operator: } [72643,72644]
operator: } [72643,72644]
===
match
---
decorator [48034,48083]
decorator [48034,48083]
===
match
---
operator: = [66478,66479]
operator: = [66478,66479]
===
match
---
name: exec_date [38818,38827]
name: exec_date [38818,38827]
===
match
---
name: models [36845,36851]
name: models [36845,36851]
===
match
---
name: SCHEDULED [72031,72040]
name: SCHEDULED [72031,72040]
===
match
---
operator: , [24625,24626]
operator: , [24625,24626]
===
match
---
simple_stmt [13445,13461]
simple_stmt [13445,13461]
===
match
---
assert_stmt [25653,25686]
assert_stmt [25653,25686]
===
match
---
atom_expr [71950,71960]
atom_expr [71950,71960]
===
match
---
name: create_dagrun [18308,18321]
name: create_dagrun [18308,18321]
===
match
---
name: DagModel [1357,1365]
name: DagModel [1357,1365]
===
match
---
trailer [29568,29579]
trailer [29568,29579]
===
match
---
name: task [40353,40357]
name: task [40353,40357]
===
match
---
name: DEFAULT_DATE [43119,43131]
name: DEFAULT_DATE [43119,43131]
===
match
---
operator: = [44160,44161]
operator: = [44160,44161]
===
match
---
name: return_value [12439,12451]
name: return_value [12439,12451]
===
match
---
trailer [67081,67120]
trailer [67081,67120]
===
match
---
argument [76153,76161]
argument [76153,76161]
===
match
---
expr_stmt [76944,77003]
expr_stmt [76944,77003]
===
match
---
simple_stmt [11892,11977]
simple_stmt [11892,11977]
===
match
---
name: getattr [7007,7014]
name: getattr [7007,7014]
===
match
---
operator: = [18026,18027]
operator: = [18026,18027]
===
match
---
trailer [40482,40490]
trailer [40482,40490]
===
match
---
atom [31799,31865]
atom [31799,31865]
===
match
---
name: ti [46654,46656]
name: ti [46654,46656]
===
match
---
parameters [42385,42413]
parameters [42385,42413]
===
match
---
parameters [50426,50432]
parameters [50426,50432]
===
match
---
name: schedule_interval [51797,51814]
name: schedule_interval [51797,51814]
===
match
---
trailer [54066,54082]
trailer [54066,54082]
===
match
---
argument [16521,16540]
argument [16521,16540]
===
match
---
operator: } [69974,69975]
operator: } [69974,69975]
===
match
---
operator: = [58153,58154]
operator: = [58153,58154]
===
match
---
name: datetime [28780,28788]
name: datetime [28780,28788]
===
match
---
name: State [72310,72315]
name: State [72310,72315]
===
match
---
operator: = [41155,41156]
operator: = [41155,41156]
===
match
---
name: task_id [74348,74355]
name: task_id [74348,74355]
===
match
---
atom_expr [78785,78828]
atom_expr [78785,78828]
===
match
---
name: State [76203,76208]
name: State [76203,76208]
===
match
---
operator: @ [71656,71657]
operator: @ [71656,71657]
===
match
---
atom_expr [73817,73831]
atom_expr [73817,73831]
===
match
---
name: __module__ [11917,11927]
name: __module__ [11917,11927]
===
match
---
simple_stmt [58715,58751]
simple_stmt [58715,58751]
===
match
---
comparison [45408,45464]
comparison [45408,45464]
===
match
---
trailer [47113,47164]
trailer [47113,47164]
===
match
---
argument [36943,36992]
argument [36943,36992]
===
match
---
trailer [66887,66891]
trailer [66887,66891]
===
match
---
number: 1 [25802,25803]
number: 1 [25802,25803]
===
match
---
number: 1 [33489,33490]
number: 1 [33489,33490]
===
match
---
operator: , [67816,67817]
operator: , [67816,67817]
===
match
---
name: expected_query_count [78750,78770]
name: expected_query_count [78750,78770]
===
match
---
trailer [12586,12591]
trailer [12586,12591]
===
match
---
name: dag [34384,34387]
name: dag [34384,34387]
===
match
---
operator: , [31908,31909]
operator: , [31908,31909]
===
match
---
testlist_comp [57829,57894]
testlist_comp [57829,57894]
===
match
---
trailer [23067,23087]
trailer [23067,23087]
===
match
---
operator: , [33165,33166]
operator: , [33165,33166]
===
match
---
name: state [51507,51512]
name: state [51507,51512]
===
match
---
arglist [27081,27126]
arglist [27081,27126]
===
match
---
operator: = [40352,40353]
operator: = [40352,40353]
===
match
---
operator: } [59582,59583]
operator: } [59582,59583]
===
match
---
name: dag2 [44615,44619]
name: dag2 [44615,44619]
===
match
---
name: raises [7191,7197]
name: raises [7191,7197]
===
match
---
fstring_expr [11929,11941]
fstring_expr [11929,11941]
===
match
---
operator: , [32598,32599]
operator: , [32598,32599]
===
match
---
param [36222,36250]
param [36222,36250]
===
match
---
name: DummyOperator [36394,36407]
name: DummyOperator [36394,36407]
===
match
---
trailer [46957,46963]
trailer [46957,46963]
===
match
---
funcdef [49764,50137]
funcdef [49764,50137]
===
match
---
simple_stmt [55239,55319]
simple_stmt [55239,55319]
===
match
---
argument [68196,68219]
argument [68196,68219]
===
match
---
atom_expr [50084,50101]
atom_expr [50084,50101]
===
match
---
operator: , [28588,28589]
operator: , [28588,28589]
===
match
---
atom_expr [78646,78666]
atom_expr [78646,78666]
===
match
---
name: pytest [8287,8293]
name: pytest [8287,8293]
===
match
---
name: set_state [75067,75076]
name: set_state [75067,75076]
===
match
---
operator: = [63068,63069]
operator: = [63068,63069]
===
match
---
name: op [7324,7326]
name: op [7324,7326]
===
match
---
trailer [16326,16335]
trailer [16326,16335]
===
match
---
trailer [58563,58600]
trailer [58563,58600]
===
match
---
operator: , [64063,64064]
operator: , [64063,64064]
===
match
---
operator: , [33752,33753]
operator: , [33752,33753]
===
match
---
comparison [77220,77252]
comparison [77220,77252]
===
match
---
name: dag [7134,7137]
name: dag [7134,7137]
===
match
---
param [34143,34163]
param [34143,34163]
===
match
---
name: downstream [34666,34676]
name: downstream [34666,34676]
===
match
---
name: start_date [44166,44176]
name: start_date [44166,44176]
===
match
---
arglist [61014,61152]
arglist [61014,61152]
===
match
---
name: task_id [48227,48234]
name: task_id [48227,48234]
===
match
---
trailer [20022,20026]
trailer [20022,20026]
===
match
---
name: task_id [67691,67698]
name: task_id [67691,67698]
===
match
---
parameters [46490,46496]
parameters [46490,46496]
===
match
---
name: ti1 [45055,45058]
name: ti1 [45055,45058]
===
match
---
string: 'test_echo_env_variables' [65026,65051]
string: 'test_echo_env_variables' [65026,65051]
===
match
---
operator: , [33590,33591]
operator: , [33590,33591]
===
match
---
atom_expr [26145,26162]
atom_expr [26145,26162]
===
match
---
operator: } [59583,59584]
operator: } [59583,59584]
===
match
---
name: task_id [61655,61662]
name: task_id [61655,61662]
===
match
---
name: state [21381,21386]
name: state [21381,21386]
===
match
---
testlist_comp [32736,32800]
testlist_comp [32736,32800]
===
match
---
trailer [66927,66941]
trailer [66927,66941]
===
match
---
operator: , [39715,39716]
operator: , [39715,39716]
===
match
---
name: value [41583,41588]
name: value [41583,41588]
===
match
---
argument [21912,21929]
argument [21912,21929]
===
match
---
trailer [54262,54283]
trailer [54262,54283]
===
match
---
operator: , [36517,36518]
operator: , [36517,36518]
===
match
---
operator: = [64809,64810]
operator: = [64809,64810]
===
match
---
param [59959,59963]
param [59959,59963]
===
match
---
comparison [44360,44378]
comparison [44360,44378]
===
match
---
operator: , [48771,48772]
operator: , [48771,48772]
===
match
---
simple_stmt [61834,61882]
simple_stmt [61834,61882]
===
match
---
name: dag [73657,73660]
name: dag [73657,73660]
===
match
---
trailer [49479,49481]
trailer [49479,49481]
===
match
---
argument [4999,5005]
argument [4999,5005]
===
match
---
string: 'test_run_pooling_task_with_skip' [17941,17974]
string: 'test_run_pooling_task_with_skip' [17941,17974]
===
match
---
operator: = [27041,27042]
operator: = [27041,27042]
===
match
---
string: 'op_3' [4908,4914]
string: 'op_3' [4908,4914]
===
match
---
atom_expr [10936,10944]
atom_expr [10936,10944]
===
match
---
trailer [75254,75271]
trailer [75254,75271]
===
match
---
name: State [61066,61071]
name: State [61066,61071]
===
match
---
string: 'test_get_rendered_k8s_spec' [69374,69402]
string: 'test_get_rendered_k8s_spec' [69374,69402]
===
match
---
string: 'schedule_after_task_execution' [72603,72634]
string: 'schedule_after_task_execution' [72603,72634]
===
match
---
argument [50277,50315]
argument [50277,50315]
===
match
---
trailer [47083,47097]
trailer [47083,47097]
===
match
---
string: 'dag' [4060,4065]
string: 'dag' [4060,4065]
===
match
---
operator: = [68621,68622]
operator: = [68621,68622]
===
match
---
name: State [74723,74728]
name: State [74723,74728]
===
match
---
atom_expr [50896,50919]
atom_expr [50896,50919]
===
match
---
atom_expr [70935,70993]
atom_expr [70935,70993]
===
match
---
atom_expr [65175,65199]
atom_expr [65175,65199]
===
match
---
expr_stmt [4050,4144]
expr_stmt [4050,4144]
===
match
---
name: self [41242,41246]
name: self [41242,41246]
===
match
---
argument [4900,4914]
argument [4900,4914]
===
match
---
simple_stmt [74480,74521]
simple_stmt [74480,74521]
===
match
---
operator: = [43067,43068]
operator: = [43067,43068]
===
match
---
suite [64181,64203]
suite [64181,64203]
===
match
---
trailer [5819,5824]
trailer [5819,5824]
===
match
---
trailer [18939,18948]
trailer [18939,18948]
===
match
---
trailer [54747,54775]
trailer [54747,54775]
===
match
---
operator: , [15890,15891]
operator: , [15890,15891]
===
match
---
operator: , [66583,66584]
operator: , [66583,66584]
===
match
---
trailer [75366,75390]
trailer [75366,75390]
===
match
---
trailer [26019,26023]
trailer [26019,26023]
===
match
---
expr_stmt [6044,6114]
expr_stmt [6044,6114]
===
match
---
trailer [37222,37246]
trailer [37222,37246]
===
match
---
param [46491,46495]
param [46491,46495]
===
match
---
name: context [60134,60141]
name: context [60134,60141]
===
match
---
param [3676,3680]
param [3676,3680]
===
match
---
name: State [12899,12904]
name: State [12899,12904]
===
match
---
operator: , [33044,33045]
operator: , [33044,33045]
===
match
---
trailer [21635,21645]
trailer [21635,21645]
===
match
---
simple_stmt [77843,77871]
simple_stmt [77843,77871]
===
match
---
operator: , [15649,15650]
operator: , [15649,15650]
===
match
---
operator: , [64723,64724]
operator: , [64723,64724]
===
match
---
string: "task_instance" [63548,63563]
string: "task_instance" [63548,63563]
===
match
---
simple_stmt [78320,78364]
simple_stmt [78320,78364]
===
match
---
number: 1 [41701,41702]
number: 1 [41701,41702]
===
match
---
number: 1 [54891,54892]
number: 1 [54891,54892]
===
match
---
argument [37383,37398]
argument [37383,37398]
===
match
---
atom_expr [65660,65688]
atom_expr [65660,65688]
===
match
---
simple_stmt [13988,14211]
simple_stmt [13988,14211]
===
match
---
except_clause [29323,29346]
except_clause [29323,29346]
===
match
---
name: flag_upstream_failed [34107,34127]
name: flag_upstream_failed [34107,34127]
===
match
---
expr_stmt [47200,47233]
expr_stmt [47200,47233]
===
match
---
atom_expr [60879,60902]
atom_expr [60879,60902]
===
match
---
name: key [39121,39124]
name: key [39121,39124]
===
match
---
operator: , [34967,34968]
operator: , [34967,34968]
===
match
---
argument [71102,71115]
argument [71102,71115]
===
match
---
name: ti [39457,39459]
name: ti [39457,39459]
===
match
---
trailer [56730,56735]
trailer [56730,56735]
===
match
---
atom_expr [21724,21753]
atom_expr [21724,21753]
===
match
---
atom [12851,12914]
atom [12851,12914]
===
match
---
simple_stmt [40394,40545]
simple_stmt [40394,40545]
===
match
---
name: task [47114,47118]
name: task [47114,47118]
===
match
---
name: max_delay [22003,22012]
name: max_delay [22003,22012]
===
match
---
simple_stmt [30763,30905]
simple_stmt [30763,30905]
===
match
---
name: Optional [2532,2540]
name: Optional [2532,2540]
===
match
---
suite [49518,49540]
suite [49518,49540]
===
match
---
operator: , [27723,27724]
operator: , [27723,27724]
===
match
---
expr_stmt [66837,66865]
expr_stmt [66837,66865]
===
match
---
expr_stmt [80189,80262]
expr_stmt [80189,80262]
===
match
---
operator: == [25943,25945]
operator: == [25943,25945]
===
match
---
name: execution_date [49912,49926]
name: execution_date [49912,49926]
===
match
---
with_stmt [70930,71081]
with_stmt [70930,71081]
===
match
---
atom_expr [61223,61241]
atom_expr [61223,61241]
===
match
---
trailer [41146,41203]
trailer [41146,41203]
===
match
---
atom_expr [75892,75921]
atom_expr [75892,75921]
===
match
---
atom_expr [24403,24448]
atom_expr [24403,24448]
===
match
---
simple_stmt [79779,79838]
simple_stmt [79779,79838]
===
match
---
arglist [46213,46223]
arglist [46213,46223]
===
match
---
operator: == [30191,30193]
operator: == [30191,30193]
===
match
---
operator: == [38016,38018]
operator: == [38016,38018]
===
match
---
operator: } [11940,11941]
operator: } [11940,11941]
===
match
---
name: ti1 [37797,37800]
name: ti1 [37797,37800]
===
match
---
name: new_task [71107,71115]
name: new_task [71107,71115]
===
match
---
atom_expr [15694,15741]
atom_expr [15694,15741]
===
match
---
name: State [51446,51451]
name: State [51446,51451]
===
match
---
number: 11 [4656,4658]
number: 11 [4656,4658]
===
match
---
name: RenderedTaskInstanceFields [68888,68914]
name: RenderedTaskInstanceFields [68888,68914]
===
match
---
trailer [16731,16734]
trailer [16731,16734]
===
match
---
simple_stmt [64447,64507]
simple_stmt [64447,64507]
===
match
---
argument [24717,24724]
argument [24717,24724]
===
match
---
name: dag_id [41413,41419]
name: dag_id [41413,41419]
===
match
---
number: 2 [15651,15652]
number: 2 [15651,15652]
===
match
---
operator: = [35248,35249]
operator: = [35248,35249]
===
match
---
operator: = [61626,61627]
operator: = [61626,61627]
===
match
---
name: self [9626,9630]
name: self [9626,9630]
===
match
---
operator: , [10617,10618]
operator: , [10617,10618]
===
match
---
trailer [28788,28809]
trailer [28788,28809]
===
match
---
argument [54859,54878]
argument [54859,54878]
===
match
---
number: 0 [33495,33496]
number: 0 [33495,33496]
===
match
---
tfpdef [51946,51979]
tfpdef [51946,51979]
===
match
---
operator: , [32298,32299]
operator: , [32298,32299]
===
match
---
trailer [24825,24846]
trailer [24825,24846]
===
match
---
name: refresh_from_db [66955,66970]
name: refresh_from_db [66955,66970]
===
match
---
trailer [35574,35696]
trailer [35574,35696]
===
match
---
name: task_id [59696,59703]
name: task_id [59696,59703]
===
match
---
argument [30511,30534]
argument [30511,30534]
===
match
---
name: dag [30126,30129]
name: dag [30126,30129]
===
match
---
name: test_task_naive_datetime [6285,6309]
name: test_task_naive_datetime [6285,6309]
===
match
---
name: max_retry_delay [23579,23594]
name: max_retry_delay [23579,23594]
===
match
---
atom_expr [34450,34458]
atom_expr [34450,34458]
===
match
---
string: 'C' [73189,73192]
string: 'C' [73189,73192]
===
match
---
suite [6634,7369]
suite [6634,7369]
===
match
---
trailer [68847,68849]
trailer [68847,68849]
===
match
---
atom_expr [50117,50128]
atom_expr [50117,50128]
===
match
---
name: context [2974,2981]
name: context [2974,2981]
===
match
---
trailer [32617,32633]
trailer [32617,32633]
===
match
---
simple_stmt [63523,63581]
simple_stmt [63523,63581]
===
match
---
assert_stmt [8763,8796]
assert_stmt [8763,8796]
===
match
---
string: 'scheduler' [72590,72601]
string: 'scheduler' [72590,72601]
===
match
---
argument [40348,40357]
argument [40348,40357]
===
match
---
operator: , [47324,47325]
operator: , [47324,47325]
===
match
---
name: subdir [74563,74569]
name: subdir [74563,74569]
===
match
---
comparison [46906,46933]
comparison [46906,46933]
===
match
---
argument [62305,62343]
argument [62305,62343]
===
match
---
simple_stmt [61429,61523]
simple_stmt [61429,61523]
===
match
---
number: 2016 [6079,6083]
number: 2016 [6079,6083]
===
match
---
name: error_message [75620,75633]
name: error_message [75620,75633]
===
match
---
atom_expr [4873,5081]
atom_expr [4873,5081]
===
match
---
trailer [68881,68887]
trailer [68881,68887]
===
match
---
number: 1 [26214,26215]
number: 1 [26214,26215]
===
match
---
name: PythonOperator [65578,65592]
name: PythonOperator [65578,65592]
===
match
---
string: """         test that running a task in an existing pool update task state as SUCCESS.         """ [13824,13922]
string: """         test that running a task in an existing pool update task state as SUCCESS.         """ [13824,13922]
===
match
---
operator: = [68206,68207]
operator: = [68206,68207]
===
match
---
argument [58678,58705]
argument [58678,58705]
===
match
---
operator: = [17221,17222]
operator: = [17221,17222]
===
match
---
name: create_dagrun [78519,78532]
name: create_dagrun [78519,78532]
===
match
---
operator: , [23521,23522]
operator: , [23521,23522]
===
match
---
operator: = [76157,76158]
operator: = [76157,76158]
===
match
---
operator: , [24833,24834]
operator: , [24833,24834]
===
match
---
atom_expr [77286,77312]
atom_expr [77286,77312]
===
match
---
argument [49252,49261]
argument [49252,49261]
===
match
---
simple_stmt [63266,63314]
simple_stmt [63266,63314]
===
match
---
trailer [54994,54997]
trailer [54994,54997]
===
match
---
operator: { [47215,47216]
operator: { [47215,47216]
===
match
---
operator: , [32355,32356]
operator: , [32355,32356]
===
match
---
string: 'A' [72267,72270]
string: 'A' [72267,72270]
===
match
---
argument [50769,50821]
argument [50769,50821]
===
match
---
name: generate_command [67947,67963]
name: generate_command [67947,67963]
===
match
---
trailer [17646,17654]
trailer [17646,17654]
===
match
---
name: models [17049,17055]
name: models [17049,17055]
===
match
---
simple_stmt [54479,54549]
simple_stmt [54479,54549]
===
match
---
name: SUCCESS [72387,72394]
name: SUCCESS [72387,72394]
===
match
---
simple_stmt [10912,10921]
simple_stmt [10912,10921]
===
match
---
name: QUEUED [73162,73168]
name: QUEUED [73162,73168]
===
match
---
operator: = [24879,24880]
operator: = [24879,24880]
===
match
---
name: state [56534,56539]
name: state [56534,56539]
===
match
---
trailer [14781,15037]
trailer [14781,15037]
===
match
---
name: ti [66750,66752]
name: ti [66750,66752]
===
match
---
name: TestCase [3422,3430]
name: TestCase [3422,3430]
===
match
---
operator: , [14420,14421]
operator: , [14420,14421]
===
match
---
argument [42807,42816]
argument [42807,42816]
===
match
---
simple_stmt [3027,3052]
simple_stmt [3027,3052]
===
match
---
simple_stmt [36505,36533]
simple_stmt [36505,36533]
===
match
---
simple_stmt [51288,51307]
simple_stmt [51288,51307]
===
match
---
trailer [9576,9581]
trailer [9576,9581]
===
match
---
operator: , [22162,22163]
operator: , [22162,22163]
===
match
---
comparison [31119,31135]
comparison [31119,31135]
===
match
---
name: dag [41396,41399]
name: dag [41396,41399]
===
match
---
trailer [24409,24413]
trailer [24409,24413]
===
match
---
operator: , [11463,11464]
operator: , [11463,11464]
===
match
---
atom_expr [36660,36684]
atom_expr [36660,36684]
===
match
---
trailer [35294,35335]
trailer [35294,35335]
===
match
---
trailer [4383,4394]
trailer [4383,4394]
===
match
---
trailer [35744,35746]
trailer [35744,35746]
===
match
---
name: task_id [62305,62312]
name: task_id [62305,62312]
===
match
---
name: DEFAULT_DATE [35358,35370]
name: DEFAULT_DATE [35358,35370]
===
match
---
argument [38677,38726]
argument [38677,38726]
===
match
---
name: execution_date [37175,37189]
name: execution_date [37175,37189]
===
match
---
operator: == [28947,28949]
operator: == [28947,28949]
===
match
---
trailer [58666,58706]
trailer [58666,58706]
===
match
---
suite [68221,68304]
suite [68221,68304]
===
match
---
name: return_value [8998,9010]
name: return_value [8998,9010]
===
match
---
name: python_callable [64621,64636]
name: python_callable [64621,64636]
===
match
---
name: patch_dict [11771,11781]
name: patch_dict [11771,11781]
===
match
---
trailer [19708,19714]
trailer [19708,19714]
===
match
---
number: 0 [32226,32227]
number: 0 [32226,32227]
===
match
---
operator: = [64520,64521]
operator: = [64520,64521]
===
match
---
param [28996,29005]
param [28996,29005]
===
match
---
trailer [3859,3866]
trailer [3859,3866]
===
match
---
argument [43642,43649]
argument [43642,43649]
===
match
---
name: run_with_error [21315,21329]
name: run_with_error [21315,21329]
===
match
---
number: 0 [28801,28802]
number: 0 [28801,28802]
===
match
---
atom_expr [12454,12501]
atom_expr [12454,12501]
===
match
---
operator: = [43610,43611]
operator: = [43610,43611]
===
match
---
number: 2 [44360,44361]
number: 2 [44360,44361]
===
match
---
simple_stmt [2037,2102]
simple_stmt [2037,2102]
===
match
---
trailer [11617,11621]
trailer [11617,11621]
===
match
---
name: day_2 [56028,56033]
name: day_2 [56028,56033]
===
match
---
trailer [58294,58315]
trailer [58294,58315]
===
match
---
name: date [52469,52473]
name: date [52469,52473]
===
match
---
operator: = [79095,79096]
operator: = [79095,79096]
===
match
---
operator: = [54268,54269]
operator: = [54268,54269]
===
match
---
trailer [26088,26093]
trailer [26088,26093]
===
match
---
name: pool_override [77148,77161]
name: pool_override [77148,77161]
===
match
---
name: self [2828,2832]
name: self [2828,2832]
===
match
---
string: '2016-01-01T00:00:00+00:00' [69442,69469]
string: '2016-01-01T00:00:00+00:00' [69442,69469]
===
match
---
arglist [63883,64097]
arglist [63883,64097]
===
match
---
number: 5 [34646,34647]
number: 5 [34646,34647]
===
match
---
expr_stmt [50028,50075]
expr_stmt [50028,50075]
===
match
---
arglist [17327,17346]
arglist [17327,17346]
===
match
---
simple_stmt [24268,24281]
simple_stmt [24268,24281]
===
match
---
name: run_date [25193,25201]
name: run_date [25193,25201]
===
match
---
atom_expr [20016,20056]
atom_expr [20016,20056]
===
match
---
string: '2016-01-01T00:00:00+00:00' [70408,70435]
string: '2016-01-01T00:00:00+00:00' [70408,70435]
===
match
---
name: DEFAULT_DATE [66782,66794]
name: DEFAULT_DATE [66782,66794]
===
match
---
simple_stmt [47173,47192]
simple_stmt [47173,47192]
===
match
---
operator: >> [36477,36479]
operator: >> [36477,36479]
===
match
---
name: mark_success [40561,40573]
name: mark_success [40561,40573]
===
match
---
name: schedule_interval [55114,55131]
name: schedule_interval [55114,55131]
===
match
---
name: op1 [5820,5823]
name: op1 [5820,5823]
===
match
---
string: 'test' [7756,7762]
string: 'test' [7756,7762]
===
match
---
name: ti [19047,19049]
name: ti [19047,19049]
===
match
---
assert_stmt [22983,23021]
assert_stmt [22983,23021]
===
match
---
simple_stmt [56302,56449]
simple_stmt [56302,56449]
===
match
---
atom_expr [3561,3584]
atom_expr [3561,3584]
===
match
---
comparison [70840,70878]
comparison [70840,70878]
===
match
---
atom_expr [75051,75093]
atom_expr [75051,75093]
===
match
---
name: RUNNING [38927,38934]
name: RUNNING [38927,38934]
===
match
---
operator: = [70758,70759]
operator: = [70758,70759]
===
match
---
operator: , [64073,64074]
operator: , [64073,64074]
===
match
---
operator: = [51881,51882]
operator: = [51881,51882]
===
match
---
trailer [3633,3658]
trailer [3633,3658]
===
match
---
trailer [14329,14344]
trailer [14329,14344]
===
match
---
trailer [65281,65314]
trailer [65281,65314]
===
match
---
sync_comp_for [35069,35091]
sync_comp_for [35069,35091]
===
match
---
comparison [21378,21402]
comparison [21378,21402]
===
match
---
name: start_date [73694,73704]
name: start_date [73694,73704]
===
match
---
name: init_state [75077,75087]
name: init_state [75077,75087]
===
match
---
name: op1 [5846,5849]
name: op1 [5846,5849]
===
match
---
trailer [52029,52248]
trailer [52029,52248]
===
match
---
trailer [47317,47334]
trailer [47317,47334]
===
match
---
expr_stmt [6841,6889]
expr_stmt [6841,6889]
===
match
---
name: ti [36505,36507]
name: ti [36505,36507]
===
match
---
atom_expr [2669,2682]
atom_expr [2669,2682]
===
match
---
simple_stmt [14761,15038]
simple_stmt [14761,15038]
===
match
---
argument [70969,70992]
argument [70969,70992]
===
match
---
operator: = [36445,36446]
operator: = [36445,36446]
===
match
---
name: FAILED [62579,62585]
name: FAILED [62579,62585]
===
match
---
trailer [19636,19642]
trailer [19636,19642]
===
match
---
param [29051,29069]
param [29051,29069]
===
match
---
operator: = [60747,60748]
operator: = [60747,60748]
===
match
---
trailer [43837,43839]
trailer [43837,43839]
===
match
---
name: value [37234,37239]
name: value [37234,37239]
===
match
---
dotted_name [2246,2265]
dotted_name [2246,2265]
===
match
---
operator: , [30817,30818]
operator: , [30817,30818]
===
match
---
testlist_comp [48490,48508]
testlist_comp [48490,48508]
===
match
---
name: NONE [72335,72339]
name: NONE [72335,72339]
===
match
---
simple_stmt [56670,56718]
simple_stmt [56670,56718]
===
match
---
operator: = [61900,61901]
operator: = [61900,61901]
===
match
---
string: 'reschedule' [28542,28554]
string: 'reschedule' [28542,28554]
===
match
---
operator: , [33567,33568]
operator: , [33567,33568]
===
match
---
operator: = [49432,49433]
operator: = [49432,49433]
===
match
---
simple_stmt [54813,54909]
simple_stmt [54813,54909]
===
match
---
operator: + [23125,23126]
operator: + [23125,23126]
===
match
---
name: task [42574,42578]
name: task [42574,42578]
===
match
---
atom_expr [79602,79638]
atom_expr [79602,79638]
===
match
---
operator: = [24900,24901]
operator: = [24900,24901]
===
match
---
operator: = [27891,27892]
operator: = [27891,27892]
===
match
---
trailer [49935,49944]
trailer [49935,49944]
===
match
---
number: 0 [24844,24845]
number: 0 [24844,24845]
===
match
---
name: execution_date [78395,78409]
name: execution_date [78395,78409]
===
match
---
operator: = [66724,66725]
operator: = [66724,66725]
===
match
---
expr_stmt [44040,44111]
expr_stmt [44040,44111]
===
match
---
name: expected_end_date [29051,29068]
name: expected_end_date [29051,29068]
===
match
---
operator: = [63943,63944]
operator: = [63943,63944]
===
match
---
param [33991,34006]
param [33991,34006]
===
match
---
operator: = [42832,42833]
operator: = [42832,42833]
===
match
---
string: 'annotations' [69327,69340]
string: 'annotations' [69327,69340]
===
match
---
name: task2 [62519,62524]
name: task2 [62519,62524]
===
match
---
operator: == [38227,38229]
operator: == [38227,38229]
===
match
---
trailer [74846,74851]
trailer [74846,74851]
===
match
---
operator: , [76850,76851]
operator: , [76850,76851]
===
match
---
atom_expr [64781,64828]
atom_expr [64781,64828]
===
match
---
operator: , [39484,39485]
operator: , [39484,39485]
===
match
---
argument [65545,65552]
argument [65545,65552]
===
match
---
trailer [15696,15741]
trailer [15696,15741]
===
match
---
trailer [67445,67462]
trailer [67445,67462]
===
match
---
trailer [21730,21734]
trailer [21730,21734]
===
match
---
operator: = [63279,63280]
operator: = [63279,63280]
===
match
---
dictorsetmaker [71903,71960]
dictorsetmaker [71903,71960]
===
match
---
name: State [40477,40482]
name: State [40477,40482]
===
match
---
operator: = [44830,44831]
operator: = [44830,44831]
===
match
---
name: create_dagrun [16448,16461]
name: create_dagrun [16448,16461]
===
match
---
simple_stmt [44120,44191]
simple_stmt [44120,44191]
===
match
---
argument [68269,68302]
argument [68269,68302]
===
match
---
name: DummyOperator [66457,66470]
name: DummyOperator [66457,66470]
===
match
---
argument [68532,68555]
argument [68532,68555]
===
match
---
operator: = [40065,40066]
operator: = [40065,40066]
===
match
---
argument [76163,76195]
argument [76163,76195]
===
match
---
operator: , [32592,32593]
operator: , [32592,32593]
===
match
---
name: executor_config [76860,76875]
name: executor_config [76860,76875]
===
match
---
name: DAG [17056,17059]
name: DAG [17056,17059]
===
match
---
name: operators [1494,1503]
name: operators [1494,1503]
===
match
---
argument [9106,9129]
argument [9106,9129]
===
match
---
operator: , [31765,31766]
operator: , [31765,31766]
===
match
---
atom_expr [16670,16694]
atom_expr [16670,16694]
===
match
---
simple_stmt [50487,50665]
simple_stmt [50487,50665]
===
match
---
name: parse [46751,46756]
name: parse [46751,46756]
===
match
---
name: test_set_dag [6615,6627]
name: test_set_dag [6615,6627]
===
match
---
operator: = [45311,45312]
operator: = [45311,45312]
===
match
---
trailer [39532,39563]
trailer [39532,39563]
===
match
---
simple_stmt [21666,21709]
simple_stmt [21666,21709]
===
match
---
with_stmt [25426,25608]
with_stmt [25426,25608]
===
match
---
with_stmt [35564,35747]
with_stmt [35564,35747]
===
match
---
number: 2 [33425,33426]
number: 2 [33425,33426]
===
match
---
number: 0 [64728,64729]
number: 0 [64728,64729]
===
match
---
string: 'test_op_4' [7737,7748]
string: 'test_op_4' [7737,7748]
===
match
---
atom_expr [33117,33130]
atom_expr [33117,33130]
===
match
---
name: run_type [41906,41914]
name: run_type [41906,41914]
===
match
---
name: task_id [50212,50219]
name: task_id [50212,50219]
===
match
---
operator: , [20130,20131]
operator: , [20130,20131]
===
match
---
funcdef [28253,28351]
funcdef [28253,28351]
===
match
---
name: task [35274,35278]
name: task [35274,35278]
===
match
---
trailer [8577,8612]
trailer [8577,8612]
===
match
---
operator: = [50219,50220]
operator: = [50219,50220]
===
match
---
assert_stmt [30175,30204]
assert_stmt [30175,30204]
===
match
---
trailer [57287,57308]
trailer [57287,57308]
===
match
---
operator: == [76409,76411]
operator: == [76409,76411]
===
match
---
parameters [46043,46049]
parameters [46043,46049]
===
match
---
name: dag [63767,63770]
name: dag [63767,63770]
===
match
---
name: RUNNABLE_STATES [12877,12892]
name: RUNNABLE_STATES [12877,12892]
===
match
---
trailer [54962,54983]
trailer [54962,54983]
===
match
---
argument [15616,15665]
argument [15616,15665]
===
match
---
arith_expr [26287,26324]
arith_expr [26287,26324]
===
match
---
simple_stmt [47106,47165]
simple_stmt [47106,47165]
===
match
---
trailer [26877,26895]
trailer [26877,26895]
===
match
---
simple_stmt [10171,10180]
simple_stmt [10171,10180]
===
match
---
assert_stmt [10188,10217]
assert_stmt [10188,10217]
===
match
---
simple_stmt [63026,63258]
simple_stmt [63026,63258]
===
match
---
operator: = [39307,39308]
operator: = [39307,39308]
===
match
---
name: pool_slots [76762,76772]
name: pool_slots [76762,76772]
===
match
---
simple_stmt [30126,30138]
simple_stmt [30126,30138]
===
match
---
operator: , [74145,74146]
operator: , [74145,74146]
===
match
---
name: dep [11913,11916]
name: dep [11913,11916]
===
match
---
simple_stmt [37707,37730]
simple_stmt [37707,37730]
===
match
---
number: 0 [46923,46924]
number: 0 [46923,46924]
===
match
---
arith_expr [66546,66583]
arith_expr [66546,66583]
===
match
---
atom [32415,32481]
atom [32415,32481]
===
match
---
simple_stmt [38455,38522]
simple_stmt [38455,38522]
===
match
---
atom_expr [74205,74265]
atom_expr [74205,74265]
===
match
---
simple_stmt [39075,39135]
simple_stmt [39075,39135]
===
match
---
number: 0 [18221,18222]
number: 0 [18221,18222]
===
match
---
decorated [31565,35179]
decorated [31565,35179]
===
match
---
argument [54263,54282]
argument [54263,54282]
===
match
---
name: TI [52266,52268]
name: TI [52266,52268]
===
match
---
parameters [48948,48971]
parameters [48948,48971]
===
match
---
atom [78073,78084]
atom [78073,78084]
===
match
---
trailer [66511,66525]
trailer [66511,66525]
===
match
---
string: 'B' [72000,72003]
string: 'B' [72000,72003]
===
match
---
simple_stmt [26078,26128]
simple_stmt [26078,26128]
===
match
---
simple_stmt [66081,66098]
simple_stmt [66081,66098]
===
match
---
name: rtif [70753,70757]
name: rtif [70753,70757]
===
match
---
atom_expr [68428,68458]
atom_expr [68428,68458]
===
match
---
atom_expr [9441,9457]
atom_expr [9441,9457]
===
match
---
trailer [23956,23965]
trailer [23956,23965]
===
match
---
name: TI [37160,37162]
name: TI [37160,37162]
===
match
---
string: 'test_check_and_change_state_before_execution' [43549,43595]
string: 'test_check_and_change_state_before_execution' [43549,43595]
===
match
---
with_stmt [9436,9527]
with_stmt [9436,9527]
===
match
---
name: task [18256,18260]
name: task [18256,18260]
===
match
---
name: task_id [5512,5519]
name: task_id [5512,5519]
===
match
---
operator: = [58259,58260]
operator: = [58259,58260]
===
match
---
name: context_arg_2 [62729,62742]
name: context_arg_2 [62729,62742]
===
match
---
operator: = [70979,70980]
operator: = [70979,70980]
===
match
---
operator: , [34676,34677]
operator: , [34676,34677]
===
match
---
expr_stmt [20010,20056]
expr_stmt [20010,20056]
===
match
---
operator: , [28746,28747]
operator: , [28746,28747]
===
match
---
string: 'B' [73170,73173]
string: 'B' [73170,73173]
===
match
---
comparison [8770,8796]
comparison [8770,8796]
===
match
---
comparison [20699,20729]
comparison [20699,20729]
===
match
---
name: parameterized [71657,71670]
name: parameterized [71657,71670]
===
match
---
simple_stmt [17118,17359]
simple_stmt [17118,17359]
===
match
---
name: SUCCESS [54095,54102]
name: SUCCESS [54095,54102]
===
match
---
trailer [44560,44606]
trailer [44560,44606]
===
match
---
atom_expr [47519,47542]
atom_expr [47519,47542]
===
match
---
operator: = [28683,28684]
operator: = [28683,28684]
===
match
---
number: 0 [32751,32752]
number: 0 [32751,32752]
===
match
---
argument [64684,64733]
argument [64684,64733]
===
match
---
name: sleep [19709,19714]
name: sleep [19709,19714]
===
match
---
operator: = [68239,68240]
operator: = [68239,68240]
===
match
---
name: _try_number [21226,21237]
name: _try_number [21226,21237]
===
match
---
atom [67733,67916]
atom [67733,67916]
===
match
---
name: owner [18891,18896]
name: owner [18891,18896]
===
match
---
name: add [23996,23999]
name: add [23996,23999]
===
match
---
arglist [35410,35460]
arglist [35410,35460]
===
match
---
trailer [50904,50913]
trailer [50904,50913]
===
match
---
atom_expr [16036,16058]
atom_expr [16036,16058]
===
match
---
name: test_depends_on_past [30434,30454]
name: test_depends_on_past [30434,30454]
===
match
---
simple_stmt [31083,31104]
simple_stmt [31083,31104]
===
match
---
atom_expr [43069,43132]
atom_expr [43069,43132]
===
match
---
name: BashOperator [68581,68593]
name: BashOperator [68581,68593]
===
match
---
trailer [51759,51763]
trailer [51759,51763]
===
match
---
name: task_id [57141,57148]
name: task_id [57141,57148]
===
match
---
argument [79286,79305]
argument [79286,79305]
===
match
---
operator: , [26781,26782]
operator: , [26781,26782]
===
match
---
comparison [9559,9581]
comparison [9559,9581]
===
match
---
argument [45006,45016]
argument [45006,45016]
===
match
---
name: airflow [1688,1695]
name: airflow [1688,1695]
===
match
---
atom_expr [70840,70857]
atom_expr [70840,70857]
===
match
---
param [6310,6314]
param [6310,6314]
===
match
---
operator: = [38137,38138]
operator: = [38137,38138]
===
match
---
atom_expr [2777,2787]
atom_expr [2777,2787]
===
match
---
string: 'exit 1' [49154,49162]
string: 'exit 1' [49154,49162]
===
match
---
number: 1 [42777,42778]
number: 1 [42777,42778]
===
match
---
except_clause [48438,48461]
except_clause [48438,48461]
===
match
---
suite [25577,25608]
suite [25577,25608]
===
match
---
trailer [59545,59606]
trailer [59545,59606]
===
match
---
name: test_next_retry_datetime [21579,21603]
name: test_next_retry_datetime [21579,21603]
===
match
---
comparison [25931,25963]
comparison [25931,25963]
===
match
---
argument [34857,34872]
argument [34857,34872]
===
match
---
name: dag [65403,65406]
name: dag [65403,65406]
===
match
---
name: dag [6739,6742]
name: dag [6739,6742]
===
match
---
suite [7216,7243]
suite [7216,7243]
===
match
---
simple_stmt [17588,17614]
simple_stmt [17588,17614]
===
match
---
comparison [22990,23021]
comparison [22990,23021]
===
match
---
name: task [58335,58339]
name: task [58335,58339]
===
match
---
name: raises [7960,7966]
name: raises [7960,7966]
===
match
---
operator: = [14095,14096]
operator: = [14095,14096]
===
match
---
name: key [39308,39311]
name: key [39308,39311]
===
match
---
operator: == [25891,25893]
operator: == [25891,25893]
===
match
---
operator: , [59558,59559]
operator: , [59558,59559]
===
match
---
simple_stmt [67532,67574]
simple_stmt [67532,67574]
===
match
---
name: ti [66804,66806]
name: ti [66804,66806]
===
match
---
parameters [49785,49791]
parameters [49785,49791]
===
match
---
trailer [47462,47476]
trailer [47462,47476]
===
match
---
expr_stmt [47552,47580]
expr_stmt [47552,47580]
===
match
---
atom_expr [9353,9365]
atom_expr [9353,9365]
===
match
---
trailer [71356,71363]
trailer [71356,71363]
===
match
---
trailer [37687,37698]
trailer [37687,37698]
===
match
---
simple_stmt [49970,50020]
simple_stmt [49970,50020]
===
match
---
name: called [60338,60344]
name: called [60338,60344]
===
match
---
name: db [3561,3563]
name: db [3561,3563]
===
match
---
operator: , [22012,22013]
operator: , [22012,22013]
===
match
---
name: patch_dict [12544,12554]
name: patch_dict [12544,12554]
===
match
---
operator: , [24648,24649]
operator: , [24648,24649]
===
match
---
suite [52455,52779]
suite [52455,52779]
===
match
---
simple_stmt [61923,61967]
simple_stmt [61923,61967]
===
match
---
atom_expr [11690,11699]
atom_expr [11690,11699]
===
match
---
simple_stmt [48421,48430]
simple_stmt [48421,48430]
===
match
---
number: 1 [55422,55423]
number: 1 [55422,55423]
===
match
---
name: task [44920,44924]
name: task [44920,44924]
===
match
---
operator: = [16415,16416]
operator: = [16415,16416]
===
match
---
name: parse [46958,46963]
name: parse [46958,46963]
===
match
---
operator: = [9011,9012]
operator: = [9011,9012]
===
match
---
operator: , [36982,36983]
operator: , [36982,36983]
===
match
---
atom_expr [76033,76068]
atom_expr [76033,76068]
===
match
---
name: _try_number [20914,20925]
name: _try_number [20914,20925]
===
match
---
string: 'dag' [46562,46567]
string: 'dag' [46562,46567]
===
match
---
suite [47054,47378]
suite [47054,47378]
===
match
---
name: dagrun_1 [56302,56310]
name: dagrun_1 [56302,56310]
===
match
---
operator: = [7713,7714]
operator: = [7713,7714]
===
match
---
simple_stmt [12577,12594]
simple_stmt [12577,12594]
===
match
---
atom_expr [47111,47164]
atom_expr [47111,47164]
===
match
---
name: ti [43141,43143]
name: ti [43141,43143]
===
match
---
name: start_date [44820,44830]
name: start_date [44820,44830]
===
match
---
atom_expr [64396,64437]
atom_expr [64396,64437]
===
match
---
atom_expr [36091,36103]
atom_expr [36091,36103]
===
match
---
operator: , [48841,48842]
operator: , [48841,48842]
===
match
---
name: fail [26801,26805]
name: fail [26801,26805]
===
match
---
operator: = [37672,37673]
operator: = [37672,37673]
===
match
---
if_stmt [75648,75877]
if_stmt [75648,75877]
===
match
---
operator: { [59560,59561]
operator: { [59560,59561]
===
match
---
name: second_run_state [73534,73550]
name: second_run_state [73534,73550]
===
match
---
simple_stmt [31201,31285]
simple_stmt [31201,31285]
===
match
---
atom_expr [41955,41963]
atom_expr [41955,41963]
===
match
---
trailer [27080,27127]
trailer [27080,27127]
===
match
---
trailer [43400,43408]
trailer [43400,43408]
===
match
---
operator: , [61416,61417]
operator: , [61416,61417]
===
match
---
parameters [51583,51690]
parameters [51583,51690]
===
match
---
simple_stmt [9641,9814]
simple_stmt [9641,9814]
===
match
---
operator: = [79044,79045]
operator: = [79044,79045]
===
match
---
name: Pool [1383,1387]
name: Pool [1383,1387]
===
match
---
name: SKIPPED [32306,32313]
name: SKIPPED [32306,32313]
===
match
---
name: set_dependency [74484,74498]
name: set_dependency [74484,74498]
===
match
---
operator: , [15517,15518]
operator: , [15517,15518]
===
match
---
with_item [68375,68402]
with_item [68375,68402]
===
match
---
atom_expr [31119,31127]
atom_expr [31119,31127]
===
match
---
arglist [30999,31073]
arglist [30999,31073]
===
match
---
comparison [3165,3191]
comparison [3165,3191]
===
match
---
atom_expr [26755,26778]
atom_expr [26755,26778]
===
match
---
name: ti [25620,25622]
name: ti [25620,25622]
===
match
---
operator: = [64754,64755]
operator: = [64754,64755]
===
match
---
operator: , [31703,31704]
operator: , [31703,31704]
===
match
---
suite [46497,46999]
suite [46497,46999]
===
match
---
name: dag [8075,8078]
name: dag [8075,8078]
===
match
---
trailer [40771,40808]
trailer [40771,40808]
===
match
---
comparison [21223,21242]
comparison [21223,21242]
===
match
---
trailer [35500,35554]
trailer [35500,35554]
===
match
---
name: dag [17218,17221]
name: dag [17218,17221]
===
match
---
atom_expr [4759,4776]
atom_expr [4759,4776]
===
match
---
for_stmt [74410,74521]
for_stmt [74410,74521]
===
match
---
trailer [74987,74995]
trailer [74987,74995]
===
match
---
simple_stmt [52681,52724]
simple_stmt [52681,52724]
===
match
---
simple_stmt [47590,47642]
simple_stmt [47590,47642]
===
match
---
arglist [37163,37199]
arglist [37163,37199]
===
match
---
operator: , [49562,49563]
operator: , [49562,49563]
===
match
---
testlist_comp [38231,38243]
testlist_comp [38231,38243]
===
match
---
operator: , [42779,42780]
operator: , [42779,42780]
===
match
---
simple_stmt [8625,8680]
simple_stmt [8625,8680]
===
match
---
trailer [18639,18669]
trailer [18639,18669]
===
match
---
operator: , [9744,9745]
operator: , [9744,9745]
===
match
---
trailer [66470,66499]
trailer [66470,66499]
===
match
---
atom_expr [4417,4429]
atom_expr [4417,4429]
===
match
---
number: 1 [46219,46220]
number: 1 [46219,46220]
===
match
---
name: retry_delay [24662,24673]
name: retry_delay [24662,24673]
===
match
---
arglist [66471,66498]
arglist [66471,66498]
===
match
---
atom_expr [47280,47334]
atom_expr [47280,47334]
===
match
---
operator: , [33026,33027]
operator: , [33026,33027]
===
match
---
name: start_date [76226,76236]
name: start_date [76226,76236]
===
match
---
trailer [79104,79113]
trailer [79104,79113]
===
match
---
trailer [60085,60125]
trailer [60085,60125]
===
match
---
name: DEFAULT_DATE [46087,46099]
name: DEFAULT_DATE [46087,46099]
===
match
---
atom [35488,35555]
atom [35488,35555]
===
match
---
raise_stmt [42473,42507]
raise_stmt [42473,42507]
===
match
---
operator: = [35321,35322]
operator: = [35321,35322]
===
match
---
assert_stmt [55486,55573]
assert_stmt [55486,55573]
===
match
---
atom_expr [65996,66009]
atom_expr [65996,66009]
===
match
---
trailer [43246,43286]
trailer [43246,43286]
===
match
---
string: 'xcom_value' [38433,38445]
string: 'xcom_value' [38433,38445]
===
match
---
operator: } [16031,16032]
operator: } [16031,16032]
===
match
---
simple_stmt [53449,53493]
simple_stmt [53449,53493]
===
match
---
name: SCHEDULED [41926,41935]
name: SCHEDULED [41926,41935]
===
match
---
operator: } [76931,76932]
operator: } [76931,76932]
===
match
---
name: SUCCESS [44404,44411]
name: SUCCESS [44404,44411]
===
match
---
string: 'test_reschedule_handling_sensor' [28461,28494]
string: 'test_reschedule_handling_sensor' [28461,28494]
===
match
---
name: DEFAULT_DATE [30522,30534]
name: DEFAULT_DATE [30522,30534]
===
match
---
string: 'test_xcom' [38479,38490]
string: 'test_xcom' [38479,38490]
===
match
---
simple_stmt [43525,43597]
simple_stmt [43525,43597]
===
match
---
expr_stmt [49244,49296]
expr_stmt [49244,49296]
===
match
---
atom_expr [79332,79352]
atom_expr [79332,79352]
===
match
---
string: 'one_success' [32656,32669]
string: 'one_success' [32656,32669]
===
match
---
operator: = [44232,44233]
operator: = [44232,44233]
===
match
---
operator: , [50012,50013]
operator: , [50012,50013]
===
match
---
operator: , [33067,33068]
operator: , [33067,33068]
===
match
---
name: TI [46659,46661]
name: TI [46659,46661]
===
match
---
argument [16597,16612]
argument [16597,16612]
===
match
---
name: task2 [44772,44777]
name: task2 [44772,44777]
===
match
---
atom_expr [79813,79836]
atom_expr [79813,79836]
===
match
---
operator: = [37158,37159]
operator: = [37158,37159]
===
match
---
arglist [40425,40534]
arglist [40425,40534]
===
match
---
trailer [50050,50059]
trailer [50050,50059]
===
match
---
name: self [58460,58464]
name: self [58460,58464]
===
match
---
operator: , [21973,21974]
operator: , [21973,21974]
===
match
---
assert_stmt [23098,23136]
assert_stmt [23098,23136]
===
match
---
argument [76044,76067]
argument [76044,76067]
===
match
---
name: State [54089,54094]
name: State [54089,54094]
===
match
---
param [25279,25297]
param [25279,25297]
===
match
---
operator: = [10843,10844]
operator: = [10843,10844]
===
match
---
tfpdef [33964,33981]
tfpdef [33964,33981]
===
match
---
atom_expr [76496,76507]
atom_expr [76496,76507]
===
match
---
operator: , [27093,27094]
operator: , [27093,27094]
===
match
---
simple_stmt [19123,19176]
simple_stmt [19123,19176]
===
match
---
name: TI [42804,42806]
name: TI [42804,42806]
===
match
---
trailer [38142,38152]
trailer [38142,38152]
===
match
---
operator: , [75601,75602]
operator: , [75601,75602]
===
match
---
name: task_id [78341,78348]
name: task_id [78341,78348]
===
match
---
operator: , [72671,72672]
operator: , [72671,72672]
===
match
---
operator: , [53759,53760]
operator: , [53759,53760]
===
match
---
name: dag [42517,42520]
name: dag [42517,42520]
===
match
---
atom_expr [10788,10797]
atom_expr [10788,10797]
===
match
---
atom_expr [44917,44988]
atom_expr [44917,44988]
===
match
---
simple_stmt [1043,1090]
simple_stmt [1043,1090]
===
match
---
atom_expr [77076,77084]
atom_expr [77076,77084]
===
match
---
trailer [10630,10637]
trailer [10630,10637]
===
match
---
atom_expr [6061,6114]
atom_expr [6061,6114]
===
match
---
simple_stmt [37154,37201]
simple_stmt [37154,37201]
===
match
---
operator: = [14945,14946]
operator: = [14945,14946]
===
match
---
atom_expr [10465,10556]
atom_expr [10465,10556]
===
match
---
operator: = [35302,35303]
operator: = [35302,35303]
===
match
---
trailer [17138,17358]
trailer [17138,17358]
===
match
---
operator: , [34246,34247]
operator: , [34246,34247]
===
match
---
argument [9174,9187]
argument [9174,9187]
===
match
---
operator: + [12321,12322]
operator: + [12321,12322]
===
match
---
operator: , [32125,32126]
operator: , [32125,32126]
===
match
---
param [48955,48970]
param [48955,48970]
===
match
---
argument [69162,69195]
argument [69162,69195]
===
match
---
name: date2 [26171,26176]
name: date2 [26171,26176]
===
match
---
string: 'manual__' [66546,66556]
string: 'manual__' [66546,66556]
===
match
---
name: upstream [74414,74422]
name: upstream [74414,74422]
===
match
---
operator: = [44639,44640]
operator: = [44639,44640]
===
match
---
expr_stmt [17118,17358]
expr_stmt [17118,17358]
===
match
---
name: MagicMock [62207,62216]
name: MagicMock [62207,62216]
===
match
---
operator: = [23805,23806]
operator: = [23805,23806]
===
match
---
operator: , [24839,24840]
operator: , [24839,24840]
===
match
---
name: FAILED [63340,63346]
name: FAILED [63340,63346]
===
match
---
simple_stmt [15689,15742]
simple_stmt [15689,15742]
===
match
---
with_stmt [59974,60069]
with_stmt [59974,60069]
===
match
---
dictorsetmaker [70104,70672]
dictorsetmaker [70104,70672]
===
match
---
trailer [46168,46225]
trailer [46168,46225]
===
match
---
name: parse [52509,52514]
name: parse [52509,52514]
===
match
---
operator: = [19933,19934]
operator: = [19933,19934]
===
match
---
name: content [58356,58363]
name: content [58356,58363]
===
match
---
operator: , [58574,58575]
operator: , [58574,58575]
===
match
---
trailer [15094,15101]
trailer [15094,15101]
===
match
---
number: 1 [10410,10411]
number: 1 [10410,10411]
===
match
---
name: date2 [26847,26852]
name: date2 [26847,26852]
===
match
---
name: ti [47106,47108]
name: ti [47106,47108]
===
match
---
name: self [71394,71398]
name: self [71394,71398]
===
match
---
atom_expr [19184,19334]
atom_expr [19184,19334]
===
match
---
name: utcnow [57247,57253]
name: utcnow [57247,57253]
===
match
---
name: dag_id [2801,2807]
name: dag_id [2801,2807]
===
match
---
string: 'A' [73151,73154]
string: 'A' [73151,73154]
===
match
---
operator: = [14222,14223]
operator: = [14222,14223]
===
match
---
name: self [59959,59963]
name: self [59959,59963]
===
match
---
simple_stmt [1171,1263]
simple_stmt [1171,1263]
===
match
---
name: ignore_first_depends_on_past [31039,31067]
name: ignore_first_depends_on_past [31039,31067]
===
match
---
name: Optional [881,889]
name: Optional [881,889]
===
match
---
trailer [55503,55527]
trailer [55503,55527]
===
match
---
arglist [5723,5753]
arglist [5723,5753]
===
match
---
name: unittest [833,841]
name: unittest [833,841]
===
match
---
argument [20098,20130]
argument [20098,20130]
===
match
---
operator: , [78076,78077]
operator: , [78076,78077]
===
match
---
name: start_date [73821,73831]
name: start_date [73821,73831]
===
match
---
name: clean_db [3696,3704]
name: clean_db [3696,3704]
===
match
---
name: start_date [8436,8446]
name: start_date [8436,8446]
===
match
---
expr_stmt [62505,62552]
expr_stmt [62505,62552]
===
match
---
name: key [39117,39120]
name: key [39117,39120]
===
match
---
name: utcnow [13294,13300]
name: utcnow [13294,13300]
===
match
---
name: session [3127,3134]
name: session [3127,3134]
===
match
---
operator: , [52860,52861]
operator: , [52860,52861]
===
match
---
atom_expr [72858,72868]
atom_expr [72858,72868]
===
match
---
number: 2 [31752,31753]
number: 2 [31752,31753]
===
match
---
dotted_name [1921,1956]
dotted_name [1921,1956]
===
match
---
operator: = [63242,63243]
operator: = [63242,63243]
===
match
---
name: test_email_alert [48091,48107]
name: test_email_alert [48091,48107]
===
match
---
number: 1 [24647,24648]
number: 1 [24647,24648]
===
match
---
param [33950,33955]
param [33950,33955]
===
match
---
string: 'xcom_key' [39962,39972]
string: 'xcom_key' [39962,39972]
===
match
---
name: execution_date [2853,2867]
name: execution_date [2853,2867]
===
match
---
atom_expr [20745,20759]
atom_expr [20745,20759]
===
match
---
operator: , [69917,69918]
operator: , [69917,69918]
===
match
---
operator: , [50879,50880]
operator: , [50879,50880]
===
match
---
operator: , [43158,43159]
operator: , [43158,43159]
===
match
---
argument [78341,78353]
argument [78341,78353]
===
match
---
name: dag [64600,64603]
name: dag [64600,64603]
===
match
---
arglist [76682,76933]
arglist [76682,76933]
===
match
---
name: ser_ti [80278,80284]
name: ser_ti [80278,80284]
===
match
---
number: 0 [40277,40278]
number: 0 [40277,40278]
===
match
---
name: downstream_list [8823,8838]
name: downstream_list [8823,8838]
===
match
---
expr_stmt [9822,9920]
expr_stmt [9822,9920]
===
match
---
number: 0 [32288,32289]
number: 0 [32288,32289]
===
match
---
argument [41413,41431]
argument [41413,41431]
===
match
---
operator: = [44733,44734]
operator: = [44733,44734]
===
match
---
simple_stmt [25872,25912]
simple_stmt [25872,25912]
===
match
---
name: expected_end_date [25248,25265]
name: expected_end_date [25248,25265]
===
match
---
trailer [22972,22974]
trailer [22972,22974]
===
match
---
name: timedelta [56060,56069]
name: timedelta [56060,56069]
===
match
---
name: create_task_instance [14664,14684]
name: create_task_instance [14664,14684]
===
match
---
operator: = [75158,75159]
operator: = [75158,75159]
===
match
---
name: done [27764,27768]
name: done [27764,27768]
===
match
---
number: 1 [20368,20369]
number: 1 [20368,20369]
===
match
---
string: "override" [47562,47572]
string: "override" [47562,47572]
===
match
---
argument [8578,8597]
argument [8578,8597]
===
match
---
expr_stmt [65403,65564]
expr_stmt [65403,65564]
===
match
---
name: utcnow [42842,42848]
name: utcnow [42842,42848]
===
match
---
atom_expr [56849,56864]
atom_expr [56849,56864]
===
match
---
name: ti [9535,9537]
name: ti [9535,9537]
===
match
---
name: UPSTREAM_FAILED [32618,32633]
name: UPSTREAM_FAILED [32618,32633]
===
match
---
string: 'labels' [69583,69591]
string: 'labels' [69583,69591]
===
match
---
argument [48157,48184]
argument [48157,48184]
===
match
---
string: "myCustomDockerImage" [76909,76930]
string: "myCustomDockerImage" [76909,76930]
===
match
---
name: key [39049,39052]
name: key [39049,39052]
===
match
---
atom_expr [43860,43904]
atom_expr [43860,43904]
===
match
---
comparison [3259,3299]
comparison [3259,3299]
===
match
---
operator: = [60759,60760]
operator: = [60759,60760]
===
match
---
atom_expr [3593,3622]
atom_expr [3593,3622]
===
match
---
testlist_comp [58924,59354]
testlist_comp [58924,59354]
===
match
---
atom_expr [71165,71195]
atom_expr [71165,71195]
===
match
---
arglist [61843,61880]
arglist [61843,61880]
===
match
---
name: FAILED [73255,73261]
name: FAILED [73255,73261]
===
match
---
operator: = [40573,40574]
operator: = [40573,40574]
===
match
---
operator: = [40373,40374]
operator: = [40373,40374]
===
match
---
expr_stmt [60338,60352]
expr_stmt [60338,60352]
===
match
---
trailer [30998,31074]
trailer [30998,31074]
===
match
---
simple_stmt [76301,76334]
simple_stmt [76301,76334]
===
match
---
name: task_id [60054,60061]
name: task_id [60054,60061]
===
match
---
parameters [79519,79525]
parameters [79519,79525]
===
match
---
trailer [56812,56814]
trailer [56812,56814]
===
match
---
arglist [39045,39065]
arglist [39045,39065]
===
match
---
trailer [65592,65698]
trailer [65592,65698]
===
match
---
name: datetime [79105,79113]
name: datetime [79105,79113]
===
match
---
simple_stmt [11844,11880]
simple_stmt [11844,11880]
===
match
---
comparison [75288,75305]
comparison [75288,75305]
===
match
---
name: run [29301,29304]
name: run [29301,29304]
===
match
---
name: dag [40011,40014]
name: dag [40011,40014]
===
match
---
atom_expr [68241,68303]
atom_expr [68241,68303]
===
match
---
name: State [72329,72334]
name: State [72329,72334]
===
match
---
operator: = [42811,42812]
operator: = [42811,42812]
===
match
---
trailer [66855,66863]
trailer [66855,66863]
===
match
---
atom_expr [21342,21362]
atom_expr [21342,21362]
===
match
---
operator: } [72428,72429]
operator: } [72428,72429]
===
match
---
operator: , [32965,32966]
operator: , [32965,32966]
===
match
---
name: op2 [8132,8135]
name: op2 [8132,8135]
===
match
---
number: 0 [62771,62772]
number: 0 [62771,62772]
===
match
---
name: pool_slots [77223,77233]
name: pool_slots [77223,77233]
===
match
---
operator: == [25721,25723]
operator: == [25721,25723]
===
match
---
simple_stmt [61378,61421]
simple_stmt [61378,61421]
===
match
---
simple_stmt [3962,4042]
simple_stmt [3962,4042]
===
match
---
atom_expr [42581,42790]
atom_expr [42581,42790]
===
match
---
number: 0 [23712,23713]
number: 0 [23712,23713]
===
match
---
name: state [38915,38920]
name: state [38915,38920]
===
match
---
suite [51699,52779]
suite [51699,52779]
===
match
---
trailer [18492,18500]
trailer [18492,18500]
===
match
---
operator: == [39313,39315]
operator: == [39313,39315]
===
match
---
operator: = [44308,44309]
operator: = [44308,44309]
===
match
---
trailer [55381,55389]
trailer [55381,55389]
===
match
---
name: dag [8419,8422]
name: dag [8419,8422]
===
match
---
trailer [10901,10903]
trailer [10901,10903]
===
match
---
number: 5 [32443,32444]
number: 5 [32443,32444]
===
match
---
number: 9 [22933,22934]
number: 9 [22933,22934]
===
match
---
operator: = [52273,52274]
operator: = [52273,52274]
===
match
---
name: op_no_dag [5554,5563]
name: op_no_dag [5554,5563]
===
match
---
trailer [54023,54031]
trailer [54023,54031]
===
match
---
operator: = [79782,79783]
operator: = [79782,79783]
===
match
---
suite [77556,80313]
suite [77556,80313]
===
match
---
comparison [19760,19784]
comparison [19760,19784]
===
match
---
name: models [21724,21730]
name: models [21724,21730]
===
match
---
expr_stmt [26171,26216]
expr_stmt [26171,26216]
===
match
---
funcdef [78834,79472]
funcdef [78834,79472]
===
match
---
operator: , [16208,16209]
operator: , [16208,16209]
===
match
---
name: _try_number [24938,24949]
name: _try_number [24938,24949]
===
match
---
operator: , [13215,13216]
operator: , [13215,13216]
===
match
---
simple_stmt [58282,58318]
simple_stmt [58282,58318]
===
match
---
name: commit [61205,61211]
name: commit [61205,61211]
===
match
---
atom_expr [64194,64202]
atom_expr [64194,64202]
===
match
---
simple_stmt [49535,49540]
simple_stmt [49535,49540]
===
match
---
trailer [56708,56716]
trailer [56708,56716]
===
match
---
trailer [77202,77207]
trailer [77202,77207]
===
match
---
testlist_comp [32140,32186]
testlist_comp [32140,32186]
===
match
---
string: 'B' [72819,72822]
string: 'B' [72819,72822]
===
match
---
operator: , [54431,54432]
operator: , [54431,54432]
===
match
---
string: 'test_xcom' [41420,41431]
string: 'test_xcom' [41420,41431]
===
match
---
simple_stmt [75685,75757]
simple_stmt [75685,75757]
===
match
---
name: timezone [15086,15094]
name: timezone [15086,15094]
===
match
---
name: dag_run [75125,75132]
name: dag_run [75125,75132]
===
match
---
assert_stmt [64277,64308]
assert_stmt [64277,64308]
===
match
---
argument [71562,71577]
argument [71562,71577]
===
match
---
trailer [45163,45167]
trailer [45163,45167]
===
match
---
name: DummyOperator [30552,30565]
name: DummyOperator [30552,30565]
===
match
---
name: parameterized [53170,53183]
name: parameterized [53170,53183]
===
match
---
name: dag [23622,23625]
name: dag [23622,23625]
===
match
---
atom_expr [34553,34584]
atom_expr [34553,34584]
===
match
---
atom_expr [46949,46991]
atom_expr [46949,46991]
===
match
---
operator: = [49075,49076]
operator: = [49075,49076]
===
match
---
parameters [60322,60328]
parameters [60322,60328]
===
match
---
operator: , [69160,69161]
operator: , [69160,69161]
===
match
---
parameters [66252,66270]
parameters [66252,66270]
===
match
---
number: 0 [33375,33376]
number: 0 [33375,33376]
===
match
---
operator: = [20304,20305]
operator: = [20304,20305]
===
match
---
trailer [8780,8796]
trailer [8780,8796]
===
match
---
expr_stmt [14219,14271]
expr_stmt [14219,14271]
===
match
---
simple_stmt [45181,45198]
simple_stmt [45181,45198]
===
match
---
suite [19030,19056]
suite [19030,19056]
===
match
---
operator: += [40726,40728]
operator: += [40726,40728]
===
match
---
atom_expr [21315,21333]
atom_expr [21315,21333]
===
match
---
atom_expr [71837,71849]
atom_expr [71837,71849]
===
match
---
name: state [54155,54160]
name: state [54155,54160]
===
match
---
argument [79798,79836]
argument [79798,79836]
===
match
---
arith_expr [12313,12333]
arith_expr [12313,12333]
===
match
---
number: 0 [18215,18216]
number: 0 [18215,18216]
===
match
---
argument [4174,4188]
argument [4174,4188]
===
match
---
atom_expr [7953,7984]
atom_expr [7953,7984]
===
match
---
name: state [55624,55629]
name: state [55624,55629]
===
match
---
number: 0 [46879,46880]
number: 0 [46879,46880]
===
match
---
operator: , [15847,15848]
operator: , [15847,15848]
===
match
---
operator: = [34807,34808]
operator: = [34807,34808]
===
match
---
operator: = [56619,56620]
operator: = [56619,56620]
===
match
---
trailer [12855,12874]
trailer [12855,12874]
===
match
---
name: task [56648,56652]
name: task [56648,56652]
===
match
---
operator: = [16089,16090]
operator: = [16089,16090]
===
match
---
trailer [18635,18639]
trailer [18635,18639]
===
match
---
operator: , [79628,79629]
operator: , [79628,79629]
===
match
---
operator: , [11456,11457]
operator: , [11456,11457]
===
match
---
comparison [54737,54804]
comparison [54737,54804]
===
match
---
trailer [49381,49438]
trailer [49381,49438]
===
match
---
atom [33410,33457]
atom [33410,33457]
===
match
---
name: python_callable [74163,74178]
name: python_callable [74163,74178]
===
match
---
expr_stmt [75453,75492]
expr_stmt [75453,75492]
===
match
---
expr_stmt [61834,61881]
expr_stmt [61834,61881]
===
match
---
trailer [50980,50988]
trailer [50980,50988]
===
match
---
name: assert_command [67716,67730]
name: assert_command [67716,67730]
===
match
---
name: ti [19429,19431]
name: ti [19429,19431]
===
match
---
atom_expr [53598,53641]
atom_expr [53598,53641]
===
match
---
operator: = [63301,63302]
operator: = [63301,63302]
===
match
---
simple_stmt [62071,62129]
simple_stmt [62071,62129]
===
match
---
operator: { [73223,73224]
operator: { [73223,73224]
===
match
---
name: datetime [78410,78418]
name: datetime [78410,78418]
===
match
---
expr_stmt [34211,34262]
expr_stmt [34211,34262]
===
match
---
simple_stmt [61577,61612]
simple_stmt [61577,61612]
===
match
---
argument [42710,42725]
argument [42710,42725]
===
match
---
atom_expr [27192,27212]
atom_expr [27192,27212]
===
match
---
suite [42973,43444]
suite [42973,43444]
===
match
---
atom_expr [34663,34687]
atom_expr [34663,34687]
===
match
---
operator: = [44945,44946]
operator: = [44945,44946]
===
match
---
argument [49912,49950]
argument [49912,49950]
===
match
---
operator: , [66330,66331]
operator: , [66330,66331]
===
match
---
arglist [75594,75633]
arglist [75594,75633]
===
match
---
name: key [39555,39558]
name: key [39555,39558]
===
match
---
atom_expr [55215,55228]
atom_expr [55215,55228]
===
match
---
trailer [75513,75520]
trailer [75513,75520]
===
match
---
string: 'fallback' [59342,59352]
string: 'fallback' [59342,59352]
===
match
---
argument [79370,79385]
argument [79370,79385]
===
match
---
number: 120 [26985,26988]
number: 120 [26985,26988]
===
match
---
name: _try_number [43427,43438]
name: _try_number [43427,43438]
===
match
---
trailer [47664,47676]
trailer [47664,47676]
===
match
---
atom_expr [66181,66194]
atom_expr [66181,66194]
===
match
---
name: ti [40588,40590]
name: ti [40588,40590]
===
match
---
name: parameterized [58880,58893]
name: parameterized [58880,58893]
===
match
---
operator: , [17343,17344]
operator: , [17343,17344]
===
match
---
trailer [65265,65281]
trailer [65265,65281]
===
match
---
atom_expr [38838,38988]
atom_expr [38838,38988]
===
match
---
trailer [29441,29443]
trailer [29441,29443]
===
match
---
name: op2 [7846,7849]
name: op2 [7846,7849]
===
match
---
name: execution_date [62526,62540]
name: execution_date [62526,62540]
===
match
---
trailer [34492,34540]
trailer [34492,34540]
===
match
---
trailer [65867,65875]
trailer [65867,65875]
===
match
---
atom_expr [70760,70790]
atom_expr [70760,70790]
===
match
---
operator: = [34833,34834]
operator: = [34833,34834]
===
match
---
simple_stmt [6239,6276]
simple_stmt [6239,6276]
===
match
---
trailer [3620,3622]
trailer [3620,3622]
===
match
---
assert_stmt [35901,35933]
assert_stmt [35901,35933]
===
match
---
name: expected_state [71464,71478]
name: expected_state [71464,71478]
===
match
---
name: serialization [1744,1757]
name: serialization [1744,1757]
===
match
---
name: execution_date [2833,2847]
name: execution_date [2833,2847]
===
match
---
name: NONE [72864,72868]
name: NONE [72864,72868]
===
match
---
name: Pool [10775,10779]
name: Pool [10775,10779]
===
match
---
trailer [72010,72018]
trailer [72010,72018]
===
match
---
operator: , [32041,32042]
operator: , [32041,32042]
===
match
---
name: SCHEDULED [16574,16583]
name: SCHEDULED [16574,16583]
===
match
---
atom [19935,20000]
atom [19935,20000]
===
match
---
trailer [16734,16750]
trailer [16734,16750]
===
match
---
atom_expr [58335,58373]
atom_expr [58335,58373]
===
match
---
expr_stmt [62561,62585]
expr_stmt [62561,62585]
===
match
---
name: task_id [74220,74227]
name: task_id [74220,74227]
===
match
---
simple_stmt [45257,45321]
simple_stmt [45257,45321]
===
match
---
name: DummyOperator [15452,15465]
name: DummyOperator [15452,15465]
===
match
---
operator: = [11034,11035]
operator: = [11034,11035]
===
match
---
argument [23317,23334]
argument [23317,23334]
===
match
---
name: dag [24721,24724]
name: dag [24721,24724]
===
match
---
operator: , [17204,17205]
operator: , [17204,17205]
===
match
---
dotted_name [1844,1877]
dotted_name [1844,1877]
===
match
---
simple_stmt [22145,22193]
simple_stmt [22145,22193]
===
match
---
trailer [40640,40650]
trailer [40640,40650]
===
match
---
operator: , [33818,33819]
operator: , [33818,33819]
===
match
---
name: date1 [26738,26743]
name: date1 [26738,26743]
===
match
---
expr_stmt [12830,12920]
expr_stmt [12830,12920]
===
match
---
name: period [22673,22679]
name: period [22673,22679]
===
match
---
name: timezone [13193,13201]
name: timezone [13193,13201]
===
match
---
operator: , [36033,36034]
operator: , [36033,36034]
===
match
---
name: ti_list [54302,54309]
name: ti_list [54302,54309]
===
match
---
string: 'to' [49219,49223]
string: 'to' [49219,49223]
===
match
---
atom_expr [52266,52310]
atom_expr [52266,52310]
===
match
---
simple_stmt [14281,14432]
simple_stmt [14281,14432]
===
match
---
if_stmt [75889,75975]
if_stmt [75889,75975]
===
match
---
operator: = [42749,42750]
operator: = [42749,42750]
===
match
---
param [5359,5363]
param [5359,5363]
===
match
---
simple_stmt [69127,69197]
simple_stmt [69127,69197]
===
match
---
funcdef [42051,42913]
funcdef [42051,42913]
===
match
---
name: dag_run [75594,75601]
name: dag_run [75594,75601]
===
match
---
string: 'task' [51870,51876]
string: 'task' [51870,51876]
===
match
---
atom_expr [77537,77554]
atom_expr [77537,77554]
===
match
---
number: 3 [33498,33499]
number: 3 [33498,33499]
===
match
---
operator: , [32444,32445]
operator: , [32444,32445]
===
match
---
name: now [50310,50313]
name: now [50310,50313]
===
match
---
atom_expr [46659,46692]
atom_expr [46659,46692]
===
match
---
parameters [51936,51992]
parameters [51936,51992]
===
match
---
string: 'test_queries' [79546,79560]
string: 'test_queries' [79546,79560]
===
match
---
trailer [47161,47163]
trailer [47161,47163]
===
match
---
operator: , [32106,32107]
operator: , [32106,32107]
===
match
---
operator: == [70858,70860]
operator: == [70858,70860]
===
match
---
param [76632,76645]
param [76632,76645]
===
match
---
simple_stmt [4154,4204]
simple_stmt [4154,4204]
===
match
---
name: owner [42710,42715]
name: owner [42710,42715]
===
match
---
operator: = [78261,78262]
operator: = [78261,78262]
===
match
---
trailer [52347,52355]
trailer [52347,52355]
===
match
---
trailer [41884,41892]
trailer [41884,41892]
===
match
---
name: state [10619,10624]
name: state [10619,10624]
===
match
---
name: op_no_dag [6537,6546]
name: op_no_dag [6537,6546]
===
match
---
name: state [15828,15833]
name: state [15828,15833]
===
match
---
operator: = [43174,43175]
operator: = [43174,43175]
===
match
---
trailer [12914,12918]
trailer [12914,12918]
===
match
---
name: dag [57186,57189]
name: dag [57186,57189]
===
match
---
arith_expr [26233,26270]
arith_expr [26233,26270]
===
match
---
simple_stmt [45089,45114]
simple_stmt [45089,45114]
===
match
---
operator: == [29580,29582]
operator: == [29580,29582]
===
match
---
argument [66424,66431]
argument [66424,66431]
===
match
---
atom_expr [34224,34262]
atom_expr [34224,34262]
===
match
---
trailer [45072,45080]
trailer [45072,45080]
===
match
---
argument [14940,14955]
argument [14940,14955]
===
match
---
trailer [8253,8268]
trailer [8253,8268]
===
match
---
operator: , [68330,68331]
operator: , [68330,68331]
===
match
---
name: rtif [70840,70844]
name: rtif [70840,70844]
===
match
---
atom_expr [15940,15963]
atom_expr [15940,15963]
===
match
---
atom_expr [3413,3430]
atom_expr [3413,3430]
===
match
---
operator: = [23515,23516]
operator: = [23515,23516]
===
match
---
operator: = [37123,37124]
operator: = [37123,37124]
===
match
---
comparison [76349,76379]
comparison [76349,76379]
===
match
---
trailer [46922,46925]
trailer [46922,46925]
===
match
---
simple_stmt [44693,44764]
simple_stmt [44693,44764]
===
match
---
name: all_non_requeueable_deps [11708,11732]
name: all_non_requeueable_deps [11708,11732]
===
match
---
trailer [23218,23228]
trailer [23218,23228]
===
match
---
param [9626,9630]
param [9626,9630]
===
match
---
testlist_comp [48726,48753]
testlist_comp [48726,48753]
===
match
---
expr_stmt [48194,48332]
expr_stmt [48194,48332]
===
match
---
funcdef [8368,8839]
funcdef [8368,8839]
===
match
---
name: FAILED [55207,55213]
name: FAILED [55207,55213]
===
match
---
simple_stmt [3097,3330]
simple_stmt [3097,3330]
===
match
---
trailer [10817,10819]
trailer [10817,10819]
===
match
---
parameters [47426,47432]
parameters [47426,47432]
===
match
---
name: task [51841,51845]
name: task [51841,51845]
===
match
---
atom_expr [73926,73941]
atom_expr [73926,73941]
===
match
---
operator: , [28554,28555]
operator: , [28554,28555]
===
match
---
operator: } [70685,70686]
operator: } [70685,70686]
===
match
---
atom_expr [49927,49950]
atom_expr [49927,49950]
===
match
---
atom [53821,53879]
atom [53821,53879]
===
match
---
expr_stmt [52784,53163]
expr_stmt [52784,53163]
===
match
---
atom_expr [7295,7301]
atom_expr [7295,7301]
===
match
---
simple_stmt [15164,15187]
simple_stmt [15164,15187]
===
match
---
operator: } [11927,11928]
operator: } [11927,11928]
===
match
---
atom_expr [78327,78363]
atom_expr [78327,78363]
===
match
---
operator: = [7557,7558]
operator: = [7557,7558]
===
match
---
name: task_id [7594,7601]
name: task_id [7594,7601]
===
match
---
atom_expr [63855,64107]
atom_expr [63855,64107]
===
match
---
trailer [50360,50369]
trailer [50360,50369]
===
match
---
number: 0 [32757,32758]
number: 0 [32757,32758]
===
match
---
atom_expr [72381,72394]
atom_expr [72381,72394]
===
match
---
decorated [76541,77502]
decorated [76541,77502]
===
match
---
param [34172,34195]
param [34172,34195]
===
match
---
atom_expr [54865,54878]
atom_expr [54865,54878]
===
match
---
name: execution_date [71117,71131]
name: execution_date [71117,71131]
===
match
---
expr_stmt [10754,10819]
expr_stmt [10754,10819]
===
match
---
simple_stmt [49638,49695]
simple_stmt [49638,49695]
===
match
---
trailer [51763,51832]
trailer [51763,51832]
===
match
---
arith_expr [30709,30753]
arith_expr [30709,30753]
===
match
---
name: start_date [79562,79572]
name: start_date [79562,79572]
===
match
---
argument [14022,14056]
argument [14022,14056]
===
match
---
trailer [21686,21696]
trailer [21686,21696]
===
match
---
funcdef [69004,71366]
funcdef [69004,71366]
===
match
---
trailer [9561,9567]
trailer [9561,9567]
===
match
---
trailer [74607,74614]
trailer [74607,74614]
===
match
---
suite [35697,35747]
suite [35697,35747]
===
match
---
operator: + [65524,65525]
operator: + [65524,65525]
===
match
---
operator: = [64451,64452]
operator: = [64451,64452]
===
match
---
operator: = [12849,12850]
operator: = [12849,12850]
===
match
---
expr_stmt [36505,36532]
expr_stmt [36505,36532]
===
match
---
argument [44057,44110]
argument [44057,44110]
===
match
---
operator: , [64057,64058]
operator: , [64057,64058]
===
match
---
trailer [60476,60487]
trailer [60476,60487]
===
match
---
trailer [8218,8236]
trailer [8218,8236]
===
match
---
operator: , [27671,27672]
operator: , [27671,27672]
===
match
---
name: State [27240,27245]
name: State [27240,27245]
===
match
---
number: 9 [5323,5324]
number: 9 [5323,5324]
===
match
---
suite [58466,58874]
suite [58466,58874]
===
match
---
name: DEFAULT_DATE [46580,46592]
name: DEFAULT_DATE [46580,46592]
===
match
---
simple_stmt [66018,66047]
simple_stmt [66018,66047]
===
match
---
name: on_success_callback [50769,50788]
name: on_success_callback [50769,50788]
===
match
---
simple_stmt [62227,62262]
simple_stmt [62227,62262]
===
match
---
name: AirflowException [49501,49517]
name: AirflowException [49501,49517]
===
match
---
expr_stmt [17917,17975]
expr_stmt [17917,17975]
===
match
---
argument [22164,22191]
argument [22164,22191]
===
match
---
name: self [46044,46048]
name: self [46044,46048]
===
match
---
operator: , [62524,62525]
operator: , [62524,62525]
===
match
---
trailer [13418,13420]
trailer [13418,13420]
===
match
---
operator: = [76657,76658]
operator: = [76657,76658]
===
match
---
number: 1 [26322,26323]
number: 1 [26322,26323]
===
match
---
name: test_echo_env_variables [65364,65387]
name: test_echo_env_variables [65364,65387]
===
match
---
string: "Europe/Amsterdam" [6016,6034]
string: "Europe/Amsterdam" [6016,6034]
===
match
---
name: session [73926,73933]
name: session [73926,73933]
===
match
---
string: 'one_success' [32496,32509]
string: 'one_success' [32496,32509]
===
match
---
trailer [24476,24857]
trailer [24476,24857]
===
match
---
operator: = [66813,66814]
operator: = [66813,66814]
===
match
---
atom_expr [15751,15930]
atom_expr [15751,15930]
===
match
---
name: dag [14070,14073]
name: dag [14070,14073]
===
match
---
name: SCHEDULED [17559,17568]
name: SCHEDULED [17559,17568]
===
match
---
trailer [58078,58082]
trailer [58078,58082]
===
match
---
name: value [40610,40615]
name: value [40610,40615]
===
match
---
name: State [13764,13769]
name: State [13764,13769]
===
match
---
trailer [32697,32713]
trailer [32697,32713]
===
match
---
with_stmt [60178,60292]
with_stmt [60178,60292]
===
match
---
simple_stmt [17043,17110]
simple_stmt [17043,17110]
===
match
---
argument [40601,40608]
argument [40601,40608]
===
match
---
atom_expr [21378,21386]
atom_expr [21378,21386]
===
match
---
operator: -> [53792,53794]
operator: -> [53792,53794]
===
match
---
assert_stmt [17622,17654]
assert_stmt [17622,17654]
===
match
---
expr_stmt [52635,52664]
expr_stmt [52635,52664]
===
match
---
comparison [55335,55398]
comparison [55335,55398]
===
match
---
name: task_id [3168,3175]
name: task_id [3168,3175]
===
match
---
operator: = [6867,6868]
operator: = [6867,6868]
===
match
---
atom_expr [62594,62635]
atom_expr [62594,62635]
===
match
---
argument [36408,36433]
argument [36408,36433]
===
match
---
atom_expr [37209,37246]
atom_expr [37209,37246]
===
match
---
operator: , [72339,72340]
operator: , [72339,72340]
===
match
---
name: DummyOperator [4160,4173]
name: DummyOperator [4160,4173]
===
match
---
operator: = [59647,59648]
operator: = [59647,59648]
===
match
---
name: dag_model [73903,73912]
name: dag_model [73903,73912]
===
match
---
number: 0 [10845,10846]
number: 0 [10845,10846]
===
match
---
name: are_dependencies_met [35724,35744]
name: are_dependencies_met [35724,35744]
===
match
---
name: get_template_context [57288,57308]
name: get_template_context [57288,57308]
===
match
---
expr_stmt [79062,79120]
expr_stmt [79062,79120]
===
match
---
string: """         Test the availability of variables in templates         """ [57990,58061]
string: """         Test the availability of variables in templates         """ [57990,58061]
===
match
---
name: execution_date [13270,13284]
name: execution_date [13270,13284]
===
match
---
operator: , [37372,37373]
operator: , [37372,37373]
===
match
---
name: State [53822,53827]
name: State [53822,53827]
===
match
---
operator: = [76054,76055]
operator: = [76054,76055]
===
match
---
param [78882,78886]
param [78882,78886]
===
match
---
suite [15432,15681]
suite [15432,15681]
===
match
---
atom_expr [54969,54982]
atom_expr [54969,54982]
===
match
---
name: create_dagrun [13478,13491]
name: create_dagrun [13478,13491]
===
match
---
param [13809,13813]
param [13809,13813]
===
match
---
atom_expr [42014,42036]
atom_expr [42014,42036]
===
match
---
number: 3 [22477,22478]
number: 3 [22477,22478]
===
match
---
argument [55370,55389]
argument [55370,55389]
===
match
---
name: all_deps [11664,11672]
name: all_deps [11664,11672]
===
match
---
comparison [25763,25803]
comparison [25763,25803]
===
match
---
operator: , [31825,31826]
operator: , [31825,31826]
===
match
---
string: 'bar' [38231,38236]
string: 'bar' [38231,38236]
===
match
---
decorator [76541,76605]
decorator [76541,76605]
===
match
---
param [42401,42412]
param [42401,42412]
===
match
---
param [65388,65392]
param [65388,65392]
===
match
---
atom_expr [37797,37845]
atom_expr [37797,37845]
===
match
---
name: execution_date [2590,2604]
name: execution_date [2590,2604]
===
match
---
param [7393,7397]
param [7393,7397]
===
match
---
parameters [42077,42083]
parameters [42077,42083]
===
match
---
param [8932,8937]
param [8932,8937]
===
match
---
trailer [53463,53466]
trailer [53463,53466]
===
match
---
arglist [73667,73717]
arglist [73667,73717]
===
match
---
operator: = [4495,4496]
operator: = [4495,4496]
===
match
---
name: ti1 [61890,61893]
name: ti1 [61890,61893]
===
match
---
name: task [28420,28424]
name: task [28420,28424]
===
match
---
operator: == [56815,56817]
operator: == [56815,56817]
===
match
---
operator: = [20070,20071]
operator: = [20070,20071]
===
match
---
name: dag [9892,9895]
name: dag [9892,9895]
===
match
---
simple_stmt [44420,44446]
simple_stmt [44420,44446]
===
match
---
number: 0 [57098,57099]
number: 0 [57098,57099]
===
match
---
string: 'schedule_after_task_execution' [72206,72237]
string: 'schedule_after_task_execution' [72206,72237]
===
match
---
name: try_number [20949,20959]
name: try_number [20949,20959]
===
match
---
atom_expr [52870,52914]
atom_expr [52870,52914]
===
match
---
name: expected_start_date [29018,29037]
name: expected_start_date [29018,29037]
===
match
---
name: _run_raw_task [61226,61239]
name: _run_raw_task [61226,61239]
===
match
---
operator: = [61869,61870]
operator: = [61869,61870]
===
match
---
name: dag_id [44057,44063]
name: dag_id [44057,44063]
===
match
---
suite [3953,5326]
suite [3953,5326]
===
match
---
name: execution_date [51057,51071]
name: execution_date [51057,51071]
===
match
---
argument [39304,39311]
argument [39304,39311]
===
match
---
operator: , [7854,7855]
operator: , [7854,7855]
===
match
---
trailer [54974,54982]
trailer [54974,54982]
===
match
---
name: dag_id [36869,36875]
name: dag_id [36869,36875]
===
match
---
expr_stmt [22689,22706]
expr_stmt [22689,22706]
===
match
---
name: context [59776,59783]
name: context [59776,59783]
===
match
---
name: session [66055,66062]
name: session [66055,66062]
===
match
---
operator: , [24724,24725]
operator: , [24724,24725]
===
match
---
trailer [64158,64165]
trailer [64158,64165]
===
match
---
name: first_run_state [75603,75618]
name: first_run_state [75603,75618]
===
match
---
trailer [77814,77832]
trailer [77814,77832]
===
match
---
name: date1 [26179,26184]
name: date1 [26179,26184]
===
match
---
name: mock [62245,62249]
name: mock [62245,62249]
===
match
---
assert_stmt [79846,79883]
assert_stmt [79846,79883]
===
match
---
name: FAILED [61908,61914]
name: FAILED [61908,61914]
===
match
---
string: 'mock' [12494,12500]
string: 'mock' [12494,12500]
===
match
---
string: 'value' [59235,59242]
string: 'value' [59235,59242]
===
match
---
operator: , [33115,33116]
operator: , [33115,33116]
===
match
---
name: create_dagrun [56317,56330]
name: create_dagrun [56317,56330]
===
match
---
name: dag [44810,44813]
name: dag [44810,44813]
===
match
---
operator: = [15256,15257]
operator: = [15256,15257]
===
match
---
argument [14799,14833]
argument [14799,14833]
===
match
---
trailer [20747,20759]
trailer [20747,20759]
===
match
---
operator: = [37134,37135]
operator: = [37134,37135]
===
match
---
operator: , [38977,38978]
operator: , [38977,38978]
===
match
---
name: _prev_dates_param_list [54355,54377]
name: _prev_dates_param_list [54355,54377]
===
match
---
argument [42534,42564]
argument [42534,42564]
===
match
---
argument [52094,52105]
argument [52094,52105]
===
match
---
simple_stmt [21446,21472]
simple_stmt [21446,21472]
===
match
---
argument [23618,23625]
argument [23618,23625]
===
match
---
argument [46818,46837]
argument [46818,46837]
===
match
---
assert_stmt [76516,76538]
assert_stmt [76516,76538]
===
match
---
operator: , [33029,33030]
operator: , [33029,33030]
===
match
---
atom_expr [45206,45222]
atom_expr [45206,45222]
===
match
---
simple_stmt [69206,69254]
simple_stmt [69206,69254]
===
match
---
funcdef [47383,47686]
funcdef [47383,47686]
===
match
---
trailer [55500,55503]
trailer [55500,55503]
===
match
---
name: task_id [41509,41516]
name: task_id [41509,41516]
===
match
---
operator: = [74767,74768]
operator: = [74767,74768]
===
match
---
arglist [46662,46691]
arglist [46662,46691]
===
match
---
operator: = [67255,67256]
operator: = [67255,67256]
===
match
---
atom_expr [16386,16434]
atom_expr [16386,16434]
===
match
---
name: task [10579,10583]
name: task [10579,10583]
===
match
---
number: 0 [32034,32035]
number: 0 [32034,32035]
===
match
---
string: 'run' [67791,67796]
string: 'run' [67791,67796]
===
match
---
atom_expr [72329,72339]
atom_expr [72329,72339]
===
match
---
operator: , [32481,32482]
operator: , [32481,32482]
===
match
---
operator: = [46063,46064]
operator: = [46063,46064]
===
match
---
operator: , [4090,4091]
operator: , [4090,4091]
===
match
---
trailer [78266,78307]
trailer [78266,78307]
===
match
---
trailer [19465,19478]
trailer [19465,19478]
===
match
---
name: title [48607,48612]
name: title [48607,48612]
===
match
---
name: DAG [66286,66289]
name: DAG [66286,66289]
===
match
---
number: 0 [32040,32041]
number: 0 [32040,32041]
===
match
---
operator: , [55909,55910]
operator: , [55909,55910]
===
match
---
argument [7552,7564]
argument [7552,7564]
===
match
---
trailer [28879,28881]
trailer [28879,28881]
===
match
---
name: raises [15126,15132]
name: raises [15126,15132]
===
match
---
argument [28849,28881]
argument [28849,28881]
===
match
---
operator: , [53244,53245]
operator: , [53244,53245]
===
match
---
name: task_instance_c [75229,75244]
name: task_instance_c [75229,75244]
===
match
---
argument [10574,10583]
argument [10574,10583]
===
match
---
trailer [54283,54298]
trailer [54283,54298]
===
match
---
name: ti [30182,30184]
name: ti [30182,30184]
===
match
---
operator: , [18959,18960]
operator: , [18959,18960]
===
match
---
operator: = [41340,41341]
operator: = [41340,41341]
===
match
---
operator: = [12153,12154]
operator: = [12153,12154]
===
match
---
arglist [53931,53967]
arglist [53931,53967]
===
match
---
name: State [55455,55460]
name: State [55455,55460]
===
match
---
name: dag_id [42999,43005]
name: dag_id [42999,43005]
===
match
---
operator: == [10204,10206]
operator: == [10204,10206]
===
match
---
string: 'dag' [7019,7024]
string: 'dag' [7019,7024]
===
match
---
string: 'test_reschedule_handling_sensor' [24498,24531]
string: 'test_reschedule_handling_sensor' [24498,24531]
===
match
---
name: ti [39520,39522]
name: ti [39520,39522]
===
match
---
assert_stmt [16011,16058]
assert_stmt [16011,16058]
===
match
---
operator: , [50015,50016]
operator: , [50015,50016]
===
match
---
operator: = [55983,55984]
operator: = [55983,55984]
===
match
---
trailer [9972,9979]
trailer [9972,9979]
===
match
---
expr_stmt [11771,11786]
expr_stmt [11771,11786]
===
match
---
name: new_task [68670,68678]
name: new_task [68670,68678]
===
match
---
name: timedelta [23269,23278]
name: timedelta [23269,23278]
===
match
---
name: execution_date [38803,38817]
name: execution_date [38803,38817]
===
match
---
operator: = [37421,37422]
operator: = [37421,37422]
===
match
---
with_item [55845,55941]
with_item [55845,55941]
===
match
---
trailer [61893,61899]
trailer [61893,61899]
===
match
---
argument [64784,64793]
argument [64784,64793]
===
match
---
operator: = [44148,44149]
operator: = [44148,44149]
===
match
---
simple_stmt [7346,7369]
simple_stmt [7346,7369]
===
match
---
operator: , [33180,33181]
operator: , [33180,33181]
===
match
---
name: now [47158,47161]
name: now [47158,47161]
===
match
---
atom_expr [79654,79668]
atom_expr [79654,79668]
===
match
---
operator: , [61695,61696]
operator: , [61695,61696]
===
match
---
name: expected_state [71621,71635]
name: expected_state [71621,71635]
===
match
---
argument [66675,66694]
argument [66675,66694]
===
match
---
name: append [52744,52750]
name: append [52744,52750]
===
match
---
operator: = [49926,49927]
operator: = [49926,49927]
===
match
---
operator: = [65861,65862]
operator: = [65861,65862]
===
match
---
name: _run_raw_task [66109,66122]
name: _run_raw_task [66109,66122]
===
match
---
name: DateTime [51971,51979]
name: DateTime [51971,51979]
===
match
---
name: dag_id [2557,2563]
name: dag_id [2557,2563]
===
match
---
trailer [68427,68459]
trailer [68427,68459]
===
match
---
name: DEFAULT_DATE [36446,36458]
name: DEFAULT_DATE [36446,36458]
===
match
---
comparison [37714,37729]
comparison [37714,37729]
===
match
---
operator: , [78164,78165]
operator: , [78164,78165]
===
match
---
operator: = [17547,17548]
operator: = [17547,17548]
===
match
---
name: ti [42904,42906]
name: ti [42904,42906]
===
match
---
operator: , [33758,33759]
operator: , [33758,33759]
===
match
---
atom_expr [53851,53863]
atom_expr [53851,53863]
===
match
---
name: task [38530,38534]
name: task [38530,38534]
===
match
---
name: self [46491,46495]
name: self [46491,46495]
===
match
---
operator: , [72891,72892]
operator: , [72891,72892]
===
match
---
operator: , [6874,6875]
operator: , [6874,6875]
===
match
---
parameters [43509,43515]
parameters [43509,43515]
===
match
---
atom_expr [45101,45113]
atom_expr [45101,45113]
===
match
---
simple_stmt [48663,48686]
simple_stmt [48663,48686]
===
match
---
name: airflow [1985,1992]
name: airflow [1985,1992]
===
match
---
trailer [49286,49293]
trailer [49286,49293]
===
match
---
atom_expr [23260,23290]
atom_expr [23260,23290]
===
match
---
suite [25474,25504]
suite [25474,25504]
===
match
---
string: 'dag' [76037,76042]
string: 'dag' [76037,76042]
===
match
---
atom_expr [64150,64167]
atom_expr [64150,64167]
===
match
---
simple_stmt [40011,40078]
simple_stmt [40011,40078]
===
match
---
operator: @ [55018,55019]
operator: @ [55018,55019]
===
match
---
name: os [65126,65128]
name: os [65126,65128]
===
match
---
trailer [56703,56717]
trailer [56703,56717]
===
match
---
operator: = [62243,62244]
operator: = [62243,62244]
===
match
---
number: 0 [46988,46989]
number: 0 [46988,46989]
===
match
---
name: ti [10195,10197]
name: ti [10195,10197]
===
match
---
argument [62455,62464]
argument [62455,62464]
===
match
---
name: get_previous_execution_date [54935,54962]
name: get_previous_execution_date [54935,54962]
===
match
---
simple_stmt [48489,48541]
simple_stmt [48489,48541]
===
match
---
operator: = [38571,38572]
operator: = [38571,38572]
===
match
---
name: new_ti [71165,71171]
name: new_ti [71165,71171]
===
match
---
simple_stmt [41955,41964]
simple_stmt [41955,41964]
===
match
---
operator: , [52914,52915]
operator: , [52914,52915]
===
match
---
param [2968,2973]
param [2968,2973]
===
match
---
atom_expr [12577,12593]
atom_expr [12577,12593]
===
match
---
operator: = [11902,11903]
operator: = [11902,11903]
===
match
---
name: QUEUED [11548,11554]
name: QUEUED [11548,11554]
===
match
---
number: 2 [32105,32106]
number: 2 [32105,32106]
===
match
---
atom [72375,72429]
atom [72375,72429]
===
match
---
name: try_number [22920,22930]
name: try_number [22920,22930]
===
match
---
trailer [79026,79049]
trailer [79026,79049]
===
match
---
atom_expr [7359,7368]
atom_expr [7359,7368]
===
match
---
atom_expr [27956,27969]
atom_expr [27956,27969]
===
match
---
name: result [37936,37942]
name: result [37936,37942]
===
match
---
name: python_callable [74233,74248]
name: python_callable [74233,74248]
===
match
---
simple_stmt [55486,55574]
simple_stmt [55486,55574]
===
match
---
atom_expr [50972,50990]
atom_expr [50972,50990]
===
match
---
atom_expr [71985,71998]
atom_expr [71985,71998]
===
match
---
operator: , [43097,43098]
operator: , [43097,43098]
===
match
---
parameters [56910,56916]
parameters [56910,56916]
===
match
---
name: overwrite_params_with_dag_run_conf [47283,47317]
name: overwrite_params_with_dag_run_conf [47283,47317]
===
match
---
trailer [69213,69253]
trailer [69213,69253]
===
match
---
operator: , [32761,32762]
operator: , [32761,32762]
===
match
---
operator: , [73290,73291]
operator: , [73290,73291]
===
match
---
operator: , [72541,72542]
operator: , [72541,72542]
===
match
---
funcdef [41218,42046]
funcdef [41218,42046]
===
match
---
argument [74048,74059]
argument [74048,74059]
===
match
---
operator: , [34162,34163]
operator: , [34162,34163]
===
match
---
param [53764,53782]
param [53764,53782]
===
match
---
trailer [6589,6598]
trailer [6589,6598]
===
match
---
trailer [23965,23969]
trailer [23965,23969]
===
match
---
name: key [39559,39562]
name: key [39559,39562]
===
match
---
operator: = [46194,46195]
operator: = [46194,46195]
===
match
---
atom_expr [38957,38977]
atom_expr [38957,38977]
===
match
---
simple_stmt [52261,52311]
simple_stmt [52261,52311]
===
match
---
operator: = [23349,23350]
operator: = [23349,23350]
===
match
---
name: idx [52584,52587]
name: idx [52584,52587]
===
match
---
name: utils [2115,2120]
name: utils [2115,2120]
===
match
---
arglist [11491,11554]
arglist [11491,11554]
===
match
---
atom_expr [27107,27120]
atom_expr [27107,27120]
===
match
---
funcdef [2948,3388]
funcdef [2948,3388]
===
match
---
name: SCHEDULED [25128,25137]
name: SCHEDULED [25128,25137]
===
match
---
operator: , [26736,26737]
operator: , [26736,26737]
===
match
---
simple_stmt [14458,14478]
simple_stmt [14458,14478]
===
match
---
trailer [60928,60936]
trailer [60928,60936]
===
match
---
atom_expr [51109,51122]
atom_expr [51109,51122]
===
match
---
number: 6 [61415,61416]
number: 6 [61415,61416]
===
match
---
name: expand [57585,57591]
name: expand [57585,57591]
===
match
---
operator: = [60682,60683]
operator: = [60682,60683]
===
match
---
string: 'airflow' [70204,70213]
string: 'airflow' [70204,70213]
===
match
---
operator: = [75374,75375]
operator: = [75374,75375]
===
match
---
name: DAG [73663,73666]
name: DAG [73663,73666]
===
match
---
argument [79236,79268]
argument [79236,79268]
===
match
---
name: expected_query_count [78166,78186]
name: expected_query_count [78166,78186]
===
match
---
trailer [20701,20707]
trailer [20701,20707]
===
match
---
name: ti2 [45193,45196]
name: ti2 [45193,45196]
===
match
---
name: State [54505,54510]
name: State [54505,54510]
===
match
---
simple_stmt [67635,67683]
simple_stmt [67635,67683]
===
match
---
name: task [42807,42811]
name: task [42807,42811]
===
match
---
strings [46264,46407]
strings [46264,46407]
===
match
---
trailer [66863,66865]
trailer [66863,66865]
===
match
---
name: execution_date [65778,65792]
name: execution_date [65778,65792]
===
match
---
string: 'B' [71799,71802]
string: 'B' [71799,71802]
===
match
---
name: timedelta [65535,65544]
name: timedelta [65535,65544]
===
match
---
simple_stmt [21342,21363]
simple_stmt [21342,21363]
===
match
---
simple_stmt [20864,20896]
simple_stmt [20864,20896]
===
match
---
assert_stmt [40631,40690]
assert_stmt [40631,40690]
===
match
---
name: DEFAULT_DATE [44177,44189]
name: DEFAULT_DATE [44177,44189]
===
match
---
simple_stmt [14568,14651]
simple_stmt [14568,14651]
===
match
---
argument [76197,76216]
argument [76197,76216]
===
match
---
name: seconds [23229,23236]
name: seconds [23229,23236]
===
match
---
atom [78014,78118]
atom [78014,78118]
===
match
---
name: AirflowException [20485,20501]
name: AirflowException [20485,20501]
===
match
---
name: duration [50361,50369]
name: duration [50361,50369]
===
match
---
name: _try_number [30223,30234]
name: _try_number [30223,30234]
===
match
---
simple_stmt [43417,43444]
simple_stmt [43417,43444]
===
match
---
operator: , [24703,24704]
operator: , [24703,24704]
===
match
---
name: DummyOperator [7715,7728]
name: DummyOperator [7715,7728]
===
match
---
arglist [31210,31283]
arglist [31210,31283]
===
match
---
name: timedelta [21636,21645]
name: timedelta [21636,21645]
===
match
---
operator: , [33334,33335]
operator: , [33334,33335]
===
match
---
simple_stmt [23853,23885]
simple_stmt [23853,23885]
===
match
---
trailer [77241,77252]
trailer [77241,77252]
===
match
---
string: 'test_run_pooling_task_with_mark_success_op' [17160,17204]
string: 'test_run_pooling_task_with_mark_success_op' [17160,17204]
===
match
---
atom_expr [34710,35033]
atom_expr [34710,35033]
===
match
---
argument [34981,35022]
argument [34981,35022]
===
match
---
expr_stmt [55239,55318]
expr_stmt [55239,55318]
===
match
---
trailer [6142,6157]
trailer [6142,6157]
===
match
---
suite [35261,35336]
suite [35261,35336]
===
match
---
trailer [53327,53334]
trailer [53327,53334]
===
match
---
operator: @ [77690,77691]
operator: @ [77690,77691]
===
match
---
argument [6363,6374]
argument [6363,6374]
===
match
---
argument [62526,62551]
argument [62526,62551]
===
match
---
string: 'test' [8672,8678]
string: 'test' [8672,8678]
===
match
---
name: dag [48140,48143]
name: dag [48140,48143]
===
match
---
name: op [65573,65575]
name: op [65573,65575]
===
match
---
string: 'A' [72799,72802]
string: 'A' [72799,72802]
===
match
---
trailer [58748,58750]
trailer [58748,58750]
===
match
---
name: pool [10832,10836]
name: pool [10832,10836]
===
match
---
simple_stmt [71591,71651]
simple_stmt [71591,71651]
===
match
---
operator: , [25094,25095]
operator: , [25094,25095]
===
match
---
expr_stmt [37788,37845]
expr_stmt [37788,37845]
===
match
---
name: State [53865,53870]
name: State [53865,53870]
===
match
---
argument [54012,54031]
argument [54012,54031]
===
match
---
operator: = [60111,60112]
operator: = [60111,60112]
===
match
---
suite [42891,42913]
suite [42891,42913]
===
match
---
name: start_date [9106,9116]
name: start_date [9106,9116]
===
match
---
trailer [65213,65243]
trailer [65213,65243]
===
match
---
funcdef [51553,52779]
funcdef [51553,52779]
===
match
---
operator: = [78388,78389]
operator: = [78388,78389]
===
match
---
arith_expr [22998,23021]
arith_expr [22998,23021]
===
match
---
operator: = [22948,22949]
operator: = [22948,22949]
===
match
---
expr_stmt [50929,50953]
expr_stmt [50929,50953]
===
match
---
name: skipped [34857,34864]
name: skipped [34857,34864]
===
match
---
name: PythonSensor [28427,28439]
name: PythonSensor [28427,28439]
===
match
---
operator: , [78107,78108]
operator: , [78107,78108]
===
match
---
argument [36901,36929]
argument [36901,36929]
===
match
---
assert_stmt [13745,13777]
assert_stmt [13745,13777]
===
match
---
string: 'spec' [70078,70084]
string: 'spec' [70078,70084]
===
match
---
string: '{{ var.value.a_variable }}' [57616,57644]
string: '{{ var.value.a_variable }}' [57616,57644]
===
match
---
name: class_name [12090,12100]
name: class_name [12090,12100]
===
match
---
trailer [73933,73939]
trailer [73933,73939]
===
match
---
param [63680,63684]
param [63680,63684]
===
match
---
argument [55976,55988]
argument [55976,55988]
===
match
---
trailer [74047,74093]
trailer [74047,74093]
===
match
---
name: callback_wrapper [50789,50805]
name: callback_wrapper [50789,50805]
===
match
---
number: 1 [64755,64756]
number: 1 [64755,64756]
===
match
---
number: 0 [33099,33100]
number: 0 [33099,33100]
===
match
---
operator: = [56034,56035]
operator: = [56034,56035]
===
match
---
operator: , [36979,36980]
operator: , [36979,36980]
===
match
---
operator: = [18349,18350]
operator: = [18349,18350]
===
match
---
operator: == [21186,21188]
operator: == [21186,21188]
===
match
---
name: now [50914,50917]
name: now [50914,50917]
===
match
---
operator: = [44396,44397]
operator: = [44396,44397]
===
match
---
suite [55942,55990]
suite [55942,55990]
===
match
---
argument [23481,23490]
argument [23481,23490]
===
match
---
trailer [79658,79668]
trailer [79658,79668]
===
match
---
simple_stmt [63848,64108]
simple_stmt [63848,64108]
===
match
---
name: period [22355,22361]
name: period [22355,22361]
===
match
---
trailer [67402,67412]
trailer [67402,67412]
===
match
---
simple_stmt [8763,8797]
simple_stmt [8763,8797]
===
match
---
string: 'test_requeue_over_task_concurrency_op' [9851,9890]
string: 'test_requeue_over_task_concurrency_op' [9851,9890]
===
match
---
name: task [79006,79010]
name: task [79006,79010]
===
match
---
tfpdef [51981,51991]
tfpdef [51981,51991]
===
match
---
atom [70118,70672]
atom [70118,70672]
===
match
---
operator: = [49277,49278]
operator: = [49277,49278]
===
match
---
trailer [38841,38855]
trailer [38841,38855]
===
match
---
atom_expr [61840,61881]
atom_expr [61840,61881]
===
match
---
name: error_message [71637,71650]
name: error_message [71637,71650]
===
match
---
trailer [20913,20925]
trailer [20913,20925]
===
match
---
atom_expr [40513,40533]
atom_expr [40513,40533]
===
match
---
string: 'task' [36331,36337]
string: 'task' [36331,36337]
===
match
---
trailer [44793,44844]
trailer [44793,44844]
===
match
---
name: mock [62958,62962]
name: mock [62958,62962]
===
match
---
argument [38915,38934]
argument [38915,38934]
===
match
---
trailer [43537,43541]
trailer [43537,43541]
===
match
---
trailer [40023,40027]
trailer [40023,40027]
===
match
---
trailer [70814,70820]
trailer [70814,70820]
===
match
---
operator: = [79812,79813]
operator: = [79812,79813]
===
match
---
suite [8410,8839]
suite [8410,8839]
===
match
---
number: 0 [10554,10555]
number: 0 [10554,10555]
===
match
---
string: '@monthly' [40066,40076]
string: '@monthly' [40066,40076]
===
match
---
name: next_dagrun [73805,73816]
name: next_dagrun [73805,73816]
===
match
---
argument [11414,11463]
argument [11414,11463]
===
match
---
simple_stmt [1839,1916]
simple_stmt [1839,1916]
===
match
---
atom_expr [22201,22212]
atom_expr [22201,22212]
===
match
---
name: set_duration [50328,50340]
name: set_duration [50328,50340]
===
match
---
argument [67977,67990]
argument [67977,67990]
===
match
---
operator: = [3366,3367]
operator: = [3366,3367]
===
match
---
atom_expr [45269,45320]
atom_expr [45269,45320]
===
match
---
assert_stmt [62785,62842]
assert_stmt [62785,62842]
===
match
---
argument [38792,38801]
argument [38792,38801]
===
match
---
atom_expr [3280,3299]
atom_expr [3280,3299]
===
match
---
arglist [46069,46099]
arglist [46069,46099]
===
match
---
name: stats_mock [67124,67134]
name: stats_mock [67124,67134]
===
match
---
name: ti [61308,61310]
name: ti [61308,61310]
===
match
---
name: expected_rendered_ti_fields [21542,21569]
name: expected_rendered_ti_fields [21542,21569]
===
match
---
operator: = [24646,24647]
operator: = [24646,24647]
===
match
---
simple_stmt [29559,29607]
simple_stmt [29559,29607]
===
match
---
atom_expr [54161,54174]
atom_expr [54161,54174]
===
match
---
comparison [21453,21471]
comparison [21453,21471]
===
match
---
expr_stmt [27880,27904]
expr_stmt [27880,27904]
===
match
---
name: date1 [27711,27716]
name: date1 [27711,27716]
===
match
---
simple_stmt [804,814]
simple_stmt [804,814]
===
match
---
name: SUCCESS [51452,51459]
name: SUCCESS [51452,51459]
===
match
---
string: "maybe this will pass?" [64413,64436]
string: "maybe this will pass?" [64413,64436]
===
match
---
name: state [55370,55375]
name: state [55370,55375]
===
match
---
operator: = [14160,14161]
operator: = [14160,14161]
===
match
---
operator: , [60776,60777]
operator: , [60776,60777]
===
match
---
argument [28730,28746]
argument [28730,28746]
===
match
---
argument [75151,75173]
argument [75151,75173]
===
match
---
name: session [45304,45311]
name: session [45304,45311]
===
match
---
name: run [39001,39004]
name: run [39001,39004]
===
match
---
number: 3 [54136,54137]
number: 3 [54136,54137]
===
match
---
simple_stmt [68653,68709]
simple_stmt [68653,68709]
===
match
---
simple_stmt [39262,39322]
simple_stmt [39262,39322]
===
match
---
operator: , [27611,27612]
operator: , [27611,27612]
===
match
---
expr_stmt [78943,78993]
expr_stmt [78943,78993]
===
match
---
number: 0 [33802,33803]
number: 0 [33802,33803]
===
match
---
number: 1 [57089,57090]
number: 1 [57089,57090]
===
match
---
name: dag [9280,9283]
name: dag [9280,9283]
===
match
---
operator: = [16141,16142]
operator: = [16141,16142]
===
match
---
assert_stmt [77457,77501]
assert_stmt [77457,77501]
===
match
---
name: start_date [13182,13192]
name: start_date [13182,13192]
===
match
---
string: 'test-dag' [34288,34298]
string: 'test-dag' [34288,34298]
===
match
---
trailer [58082,58112]
trailer [58082,58112]
===
match
---
string: """         test that running task with mark_success param update task state         as SUCCESS without running task despite it fails dependency checks.         """ [12657,12821]
string: """         test that running task with mark_success param update task state         as SUCCESS without running task despite it fails dependency checks.         """ [12657,12821]
===
match
---
simple_stmt [59675,59711]
simple_stmt [59675,59711]
===
match
---
expr_stmt [28210,28222]
expr_stmt [28210,28222]
===
match
---
trailer [10197,10203]
trailer [10197,10203]
===
match
---
simple_stmt [75323,75391]
simple_stmt [75323,75391]
===
match
---
trailer [30766,30780]
trailer [30766,30780]
===
match
---
name: result [38009,38015]
name: result [38009,38015]
===
match
---
trailer [59849,59867]
trailer [59849,59867]
===
match
---
with_stmt [69050,69197]
with_stmt [69050,69197]
===
match
---
comparison [25706,25743]
comparison [25706,25743]
===
match
---
name: dag [7298,7301]
name: dag [7298,7301]
===
match
---
operator: = [2904,2905]
operator: = [2904,2905]
===
match
---
name: utc_date [6267,6275]
name: utc_date [6267,6275]
===
match
---
argument [30794,30817]
argument [30794,30817]
===
match
---
string: '{{ var.json.get("missing_variable") }}' [60241,60281]
string: '{{ var.json.get("missing_variable") }}' [60241,60281]
===
match
---
expr_stmt [37075,37145]
expr_stmt [37075,37145]
===
match
---
trailer [44336,44344]
trailer [44336,44344]
===
match
---
number: 1 [40753,40754]
number: 1 [40753,40754]
===
match
---
name: task2 [16394,16399]
name: task2 [16394,16399]
===
match
---
name: key [37688,37691]
name: key [37688,37691]
===
match
---
dictorsetmaker [47562,47579]
dictorsetmaker [47562,47579]
===
match
---
with_item [68833,68860]
with_item [68833,68860]
===
match
---
name: self [43510,43514]
name: self [43510,43514]
===
match
---
atom [16275,16289]
atom [16275,16289]
===
match
---
number: 1 [28610,28611]
number: 1 [28610,28611]
===
match
---
operator: , [32989,32990]
operator: , [32989,32990]
===
match
---
argument [74973,74995]
argument [74973,74995]
===
match
---
name: context [58282,58289]
name: context [58282,58289]
===
match
---
expr_stmt [22145,22192]
expr_stmt [22145,22192]
===
match
---
operator: , [33023,33024]
operator: , [33023,33024]
===
match
---
operator: = [51823,51824]
operator: = [51823,51824]
===
match
---
argument [21987,22012]
argument [21987,22012]
===
match
---
expr_stmt [40302,40331]
expr_stmt [40302,40331]
===
match
---
atom_expr [75407,75427]
atom_expr [75407,75427]
===
match
---
atom_expr [73268,73289]
atom_expr [73268,73289]
===
match
---
atom_expr [78565,78582]
atom_expr [78565,78582]
===
match
---
name: dag_id [17934,17940]
name: dag_id [17934,17940]
===
match
---
name: self [63680,63684]
name: self [63680,63684]
===
match
---
parameters [3675,3681]
parameters [3675,3681]
===
match
---
name: self [3902,3906]
name: self [3902,3906]
===
match
---
operator: } [73093,73094]
operator: } [73093,73094]
===
match
---
name: task [55955,55959]
name: task [55955,55959]
===
match
---
operator: , [38583,38584]
operator: , [38583,38584]
===
match
---
atom_expr [74333,74393]
atom_expr [74333,74393]
===
match
---
atom_expr [74438,74458]
atom_expr [74438,74458]
===
match
---
atom [57675,57728]
atom [57675,57728]
===
match
---
name: callback_wrapper [51358,51374]
name: callback_wrapper [51358,51374]
===
match
---
testlist_comp [70204,70436]
testlist_comp [70204,70436]
===
match
---
name: add_task [5164,5172]
name: add_task [5164,5172]
===
match
---
atom_expr [19494,19507]
atom_expr [19494,19507]
===
match
---
simple_stmt [52386,52396]
simple_stmt [52386,52396]
===
match
---
operator: , [26778,26779]
operator: , [26778,26779]
===
match
---
string: 'A' [74910,74913]
string: 'A' [74910,74913]
===
match
---
operator: , [66661,66662]
operator: , [66661,66662]
===
match
---
operator: = [16489,16490]
operator: = [16489,16490]
===
match
---
name: start_date [66638,66648]
name: start_date [66638,66648]
===
match
---
trailer [55596,55599]
trailer [55596,55599]
===
match
---
trailer [66088,66095]
trailer [66088,66095]
===
match
---
simple_stmt [10566,10639]
simple_stmt [10566,10639]
===
match
---
trailer [24682,24692]
trailer [24682,24692]
===
match
---
name: execution_date [41845,41859]
name: execution_date [41845,41859]
===
match
---
comparison [50117,50136]
comparison [50117,50136]
===
match
---
operator: = [25080,25081]
operator: = [25080,25081]
===
match
---
assert_stmt [18480,18512]
assert_stmt [18480,18512]
===
match
---
atom_expr [11569,11585]
atom_expr [11569,11585]
===
match
---
operator: = [30316,30317]
operator: = [30316,30317]
===
match
---
name: timezone [28771,28779]
name: timezone [28771,28779]
===
match
---
name: method_patch [12034,12046]
name: method_patch [12034,12046]
===
match
---
arglist [63275,63312]
arglist [63275,63312]
===
match
---
number: 2 [18955,18956]
number: 2 [18955,18956]
===
match
---
trailer [40106,40293]
trailer [40106,40293]
===
match
---
number: 0 [24838,24839]
number: 0 [24838,24839]
===
match
---
trailer [71611,71617]
trailer [71611,71617]
===
match
---
operator: , [76581,76582]
operator: , [76581,76582]
===
match
---
name: task_id [7657,7664]
name: task_id [7657,7664]
===
match
---
string: 'test_get_rendered_k8s_spec' [70939,70967]
string: 'test_get_rendered_k8s_spec' [70939,70967]
===
match
---
name: dag [73817,73820]
name: dag [73817,73820]
===
match
---
name: clear_rendered_ti_fields [3596,3620]
name: clear_rendered_ti_fields [3596,3620]
===
match
---
name: xcom_pull [37678,37687]
name: xcom_pull [37678,37687]
===
match
---
name: State [54520,54525]
name: State [54520,54525]
===
match
---
name: self [3691,3695]
name: self [3691,3695]
===
match
---
name: QUEUED [45107,45113]
name: QUEUED [45107,45113]
===
match
---
trailer [46756,46765]
trailer [46756,46765]
===
match
---
simple_stmt [7637,7701]
simple_stmt [7637,7701]
===
match
---
trailer [2573,2578]
trailer [2573,2578]
===
match
---
expr_stmt [22461,22478]
expr_stmt [22461,22478]
===
match
---
trailer [20575,20582]
trailer [20575,20582]
===
match
---
simple_stmt [18463,18472]
simple_stmt [18463,18472]
===
match
---
name: ti_list [54056,54063]
name: ti_list [54056,54063]
===
match
---
name: List [875,879]
name: List [875,879]
===
match
---
argument [41992,42008]
argument [41992,42008]
===
match
---
operator: = [31239,31240]
operator: = [31239,31240]
===
match
---
name: TI [40769,40771]
name: TI [40769,40771]
===
match
---
name: pytest [7073,7079]
name: pytest [7073,7079]
===
match
---
number: 0 [33736,33737]
number: 0 [33736,33737]
===
match
---
name: bash_command [49141,49153]
name: bash_command [49141,49153]
===
match
---
atom_expr [60083,60125]
atom_expr [60083,60125]
===
match
---
name: self [36195,36199]
name: self [36195,36199]
===
match
---
trailer [64703,64712]
trailer [64703,64712]
===
match
---
arglist [48350,48393]
arglist [48350,48393]
===
match
---
argument [14851,14858]
argument [14851,14858]
===
match
---
name: ti [20852,20854]
name: ti [20852,20854]
===
match
---
name: task_id [11261,11268]
name: task_id [11261,11268]
===
match
---
number: 5 [21470,21471]
number: 5 [21470,21471]
===
match
---
trailer [75165,75173]
trailer [75165,75173]
===
match
---
name: dag [52012,52015]
name: dag [52012,52015]
===
match
---
trailer [78952,78993]
trailer [78952,78993]
===
match
---
atom_expr [49970,49983]
atom_expr [49970,49983]
===
match
---
name: i [7819,7820]
name: i [7819,7820]
===
match
---
comparison [19494,19512]
comparison [19494,19512]
===
match
---
trailer [44052,44056]
trailer [44052,44056]
===
match
---
suite [2518,3388]
suite [2518,3388]
===
match
---
operator: = [4907,4908]
operator: = [4907,4908]
===
match
---
operator: = [47801,47802]
operator: = [47801,47802]
===
match
---
arglist [70939,70992]
arglist [70939,70992]
===
match
---
atom_expr [19646,19664]
atom_expr [19646,19664]
===
match
---
name: clear_db_task_fail [3564,3582]
name: clear_db_task_fail [3564,3582]
===
match
---
expr_stmt [18623,18669]
expr_stmt [18623,18669]
===
match
---
atom_expr [28366,28411]
atom_expr [28366,28411]
===
match
---
atom_expr [75570,75634]
atom_expr [75570,75634]
===
match
---
simple_stmt [47200,47234]
simple_stmt [47200,47234]
===
match
---
arglist [76991,77001]
arglist [76991,77001]
===
match
---
name: db [3593,3595]
name: db [3593,3595]
===
match
---
simple_stmt [61250,61264]
simple_stmt [61250,61264]
===
match
---
simple_stmt [11610,11626]
simple_stmt [11610,11626]
===
match
---
operator: , [33103,33104]
operator: , [33103,33104]
===
match
---
name: run_type [17539,17547]
name: run_type [17539,17547]
===
match
---
operator: , [36199,36200]
operator: , [36199,36200]
===
match
---
operator: = [22387,22388]
operator: = [22387,22388]
===
match
---
name: start_date [43732,43742]
name: start_date [43732,43742]
===
match
---
atom [46250,46417]
atom [46250,46417]
===
match
---
name: task [79951,79955]
name: task [79951,79955]
===
match
---
string: 'dag' [46069,46074]
string: 'dag' [46069,46074]
===
match
---
string: 'test_pool' [17244,17255]
string: 'test_pool' [17244,17255]
===
match
---
simple_stmt [75187,75217]
simple_stmt [75187,75217]
===
match
---
number: 1 [14188,14189]
number: 1 [14188,14189]
===
match
---
assert_stmt [20864,20895]
assert_stmt [20864,20895]
===
match
---
operator: == [43392,43394]
operator: == [43392,43394]
===
match
---
name: execution_date [53656,53670]
name: execution_date [53656,53670]
===
match
---
atom_expr [44398,44411]
atom_expr [44398,44411]
===
match
---
operator: = [46579,46580]
operator: = [46579,46580]
===
match
---
trailer [78801,78828]
trailer [78801,78828]
===
match
---
name: dag [63239,63242]
name: dag [63239,63242]
===
match
---
assert_stmt [29881,29930]
assert_stmt [29881,29930]
===
match
---
atom_expr [54520,54532]
atom_expr [54520,54532]
===
match
---
trailer [71861,71866]
trailer [71861,71866]
===
match
---
trailer [50086,50099]
trailer [50086,50099]
===
match
---
simple_stmt [73955,73986]
simple_stmt [73955,73986]
===
match
---
operator: = [7487,7488]
operator: = [7487,7488]
===
match
---
simple_stmt [20533,20586]
simple_stmt [20533,20586]
===
match
---
name: context [60386,60393]
name: context [60386,60393]
===
match
---
name: state [19637,19642]
name: state [19637,19642]
===
match
---
operator: = [61028,61029]
operator: = [61028,61029]
===
match
---
name: TaskReschedule [1449,1463]
name: TaskReschedule [1449,1463]
===
match
---
simple_stmt [23945,24011]
simple_stmt [23945,24011]
===
match
---
name: state [10939,10944]
name: state [10939,10944]
===
match
---
argument [73805,73831]
argument [73805,73831]
===
match
---
name: ti [22950,22952]
name: ti [22950,22952]
===
match
---
trailer [15388,15392]
trailer [15388,15392]
===
match
---
name: datetime [79813,79821]
name: datetime [79813,79821]
===
match
---
name: datetime [795,803]
name: datetime [795,803]
===
match
---
name: self [12642,12646]
name: self [12642,12646]
===
match
---
operator: , [35022,35023]
operator: , [35022,35023]
===
match
---
name: ti [21258,21260]
name: ti [21258,21260]
===
match
---
operator: , [15706,15707]
operator: , [15706,15707]
===
match
---
arglist [20541,20584]
arglist [20541,20584]
===
match
---
name: queue [77079,77084]
name: queue [77079,77084]
===
match
---
trailer [36851,36855]
trailer [36851,36855]
===
match
---
name: datetime [50626,50634]
name: datetime [50626,50634]
===
match
---
simple_stmt [61272,61293]
simple_stmt [61272,61293]
===
match
---
atom_expr [79415,79439]
atom_expr [79415,79439]
===
match
---
name: test_ti_updates_with_task [15217,15242]
name: test_ti_updates_with_task [15217,15242]
===
match
---
expr_stmt [35344,35371]
expr_stmt [35344,35371]
===
match
---
name: ti [58725,58727]
name: ti [58725,58727]
===
match
---
atom_expr [4845,4857]
atom_expr [4845,4857]
===
match
---
trailer [3215,3222]
trailer [3215,3222]
===
match
---
string: 'mock_' [12080,12087]
string: 'mock_' [12080,12087]
===
match
---
name: ti [76523,76525]
name: ti [76523,76525]
===
match
---
and_test [62792,62842]
and_test [62792,62842]
===
match
---
operator: , [76195,76196]
operator: , [76195,76196]
===
match
---
atom_expr [24808,24846]
atom_expr [24808,24846]
===
match
---
name: task_id [76097,76104]
name: task_id [76097,76104]
===
match
---
name: exec_date [37444,37453]
name: exec_date [37444,37453]
===
match
---
with_stmt [8200,8274]
with_stmt [8200,8274]
===
match
---
simple_stmt [1315,1481]
simple_stmt [1315,1481]
===
match
---
trailer [42994,42998]
trailer [42994,42998]
===
match
---
arglist [12080,12114]
arglist [12080,12114]
===
match
---
name: render_template [60225,60240]
name: render_template [60225,60240]
===
match
---
import_from [1916,1979]
import_from [1916,1979]
===
match
---
name: schedule_interval [55911,55928]
name: schedule_interval [55911,55928]
===
match
---
name: priority_weight [77267,77282]
name: priority_weight [77267,77282]
===
match
---
trailer [3031,3044]
trailer [3031,3044]
===
match
---
expr_stmt [52558,52566]
expr_stmt [52558,52566]
===
match
---
comparison [47658,47685]
comparison [47658,47685]
===
match
---
atom_expr [66028,66046]
atom_expr [66028,66046]
===
match
---
operator: = [44888,44889]
operator: = [44888,44889]
===
match
---
atom_expr [37463,37500]
atom_expr [37463,37500]
===
match
---
name: __name__ [11871,11879]
name: __name__ [11871,11879]
===
match
---
number: 2016 [15002,15006]
number: 2016 [15002,15006]
===
match
---
funcdef [25158,26128]
funcdef [25158,26128]
===
match
---
name: param [1069,1074]
name: param [1069,1074]
===
match
---
atom_expr [74981,74995]
atom_expr [74981,74995]
===
match
---
operator: , [32752,32753]
operator: , [32752,32753]
===
match
---
name: query [68882,68887]
name: query [68882,68887]
===
match
---
name: DummyOperator [44127,44140]
name: DummyOperator [44127,44140]
===
match
---
trailer [78492,78498]
trailer [78492,78498]
===
match
---
name: executor_config [16735,16750]
name: executor_config [16735,16750]
===
match
---
atom_expr [23807,23843]
atom_expr [23807,23843]
===
match
---
trailer [6410,6520]
trailer [6410,6520]
===
match
---
name: PythonOperator [42340,42354]
name: PythonOperator [42340,42354]
===
match
---
atom_expr [21627,21657]
atom_expr [21627,21657]
===
match
---
arglist [7729,7772]
arglist [7729,7772]
===
match
---
simple_stmt [47651,47686]
simple_stmt [47651,47686]
===
match
---
simple_stmt [53978,54041]
simple_stmt [53978,54041]
===
match
---
operator: = [23045,23046]
operator: = [23045,23046]
===
match
---
name: get_task_instance [74955,74972]
name: get_task_instance [74955,74972]
===
match
---
name: delay [21924,21929]
name: delay [21924,21929]
===
match
---
operator: = [7736,7737]
operator: = [7736,7737]
===
match
---
operator: { [67023,67024]
operator: { [67023,67024]
===
match
---
string: 'test_get_rendered_k8s_spec' [69059,69087]
string: 'test_get_rendered_k8s_spec' [69059,69087]
===
match
---
atom_expr [12852,12874]
atom_expr [12852,12874]
===
match
---
name: ti [76301,76303]
name: ti [76301,76303]
===
match
---
operator: , [57084,57085]
operator: , [57084,57085]
===
match
---
trailer [62259,62261]
trailer [62259,62261]
===
match
---
name: session [66081,66088]
name: session [66081,66088]
===
match
---
argument [76113,76125]
argument [76113,76125]
===
match
---
name: DummyOperator [60040,60053]
name: DummyOperator [60040,60053]
===
match
---
expr_stmt [79779,79837]
expr_stmt [79779,79837]
===
match
---
simple_stmt [75811,75877]
simple_stmt [75811,75877]
===
match
---
name: passed [35062,35068]
name: passed [35062,35068]
===
match
---
operator: == [24984,24986]
operator: == [24984,24986]
===
match
---
operator: , [32292,32293]
operator: , [32292,32293]
===
match
---
name: key [41169,41172]
name: key [41169,41172]
===
match
---
not_test [30417,30424]
not_test [30417,30424]
===
match
---
name: execution_date [15800,15814]
name: execution_date [15800,15814]
===
match
---
name: task_id [36408,36415]
name: task_id [36408,36415]
===
match
---
trailer [53097,53156]
trailer [53097,53156]
===
match
---
simple_stmt [50258,50317]
simple_stmt [50258,50317]
===
match
---
expr_stmt [44997,45046]
expr_stmt [44997,45046]
===
match
---
name: value [39060,39065]
name: value [39060,39065]
===
match
---
name: mock [68931,68935]
name: mock [68931,68935]
===
match
---
expr_stmt [50862,50920]
expr_stmt [50862,50920]
===
match
---
operator: , [76802,76803]
operator: , [76802,76803]
===
match
---
atom_expr [15057,15104]
atom_expr [15057,15104]
===
match
---
operator: == [16033,16035]
operator: == [16033,16035]
===
match
---
argument [24545,24560]
argument [24545,24560]
===
match
---
operator: , [26683,26684]
operator: , [26683,26684]
===
match
---
number: 1 [41781,41782]
number: 1 [41781,41782]
===
match
---
expr_stmt [42574,42790]
expr_stmt [42574,42790]
===
match
---
name: op3 [7851,7854]
name: op3 [7851,7854]
===
match
---
name: datetime [14170,14178]
name: datetime [14170,14178]
===
match
---
string: 'op' [47092,47096]
string: 'op' [47092,47096]
===
match
---
argument [45376,45391]
argument [45376,45391]
===
match
---
name: settings [50972,50980]
name: settings [50972,50980]
===
match
---
operator: , [32935,32936]
operator: , [32935,32936]
===
match
---
simple_stmt [18480,18513]
simple_stmt [18480,18513]
===
match
---
operator: = [9158,9159]
operator: = [9158,9159]
===
match
---
arglist [62514,62551]
arglist [62514,62551]
===
match
---
string: 'task_with_exp_backoff_and_short_time_interval' [23385,23432]
string: 'task_with_exp_backoff_and_short_time_interval' [23385,23432]
===
match
---
trailer [53856,53863]
trailer [53856,53863]
===
match
---
atom_expr [70803,70820]
atom_expr [70803,70820]
===
match
---
trailer [62513,62552]
trailer [62513,62552]
===
match
---
operator: , [56397,56398]
operator: , [56397,56398]
===
match
---
name: DEFAULT_DATE [60609,60621]
name: DEFAULT_DATE [60609,60621]
===
match
---
name: date3 [27938,27943]
name: date3 [27938,27943]
===
match
---
operator: = [9773,9774]
operator: = [9773,9774]
===
match
---
name: commit [10895,10901]
name: commit [10895,10901]
===
match
---
name: ti [49970,49972]
name: ti [49970,49972]
===
match
---
number: 2016 [24826,24830]
number: 2016 [24826,24830]
===
match
---
atom_expr [77785,77803]
atom_expr [77785,77803]
===
match
---
atom_expr [76314,76332]
atom_expr [76314,76332]
===
match
---
operator: , [32280,32281]
operator: , [32280,32281]
===
match
---
arglist [74134,74178]
arglist [74134,74178]
===
match
---
operator: , [17284,17285]
operator: , [17284,17285]
===
match
---
name: date1 [26745,26750]
name: date1 [26745,26750]
===
match
---
atom_expr [50940,50953]
atom_expr [50940,50953]
===
match
---
name: ti [77264,77266]
name: ti [77264,77266]
===
match
---
name: DAG [17930,17933]
name: DAG [17930,17933]
===
match
---
operator: , [23710,23711]
operator: , [23710,23711]
===
match
---
atom_expr [23793,23804]
atom_expr [23793,23804]
===
match
---
operator: , [34252,34253]
operator: , [34252,34253]
===
match
---
atom_expr [42833,42850]
atom_expr [42833,42850]
===
match
---
operator: , [7849,7850]
operator: , [7849,7850]
===
match
---
param [34107,34134]
param [34107,34134]
===
match
---
string: 'test_pool' [14881,14892]
string: 'test_pool' [14881,14892]
===
match
---
name: task [15697,15701]
name: task [15697,15701]
===
match
---
expr_stmt [40716,40755]
expr_stmt [40716,40755]
===
match
---
with_stmt [3715,3869]
with_stmt [3715,3869]
===
match
---
comparison [8132,8146]
comparison [8132,8146]
===
match
---
name: xcom_pull [41008,41017]
name: xcom_pull [41008,41017]
===
match
---
operator: = [9279,9280]
operator: = [9279,9280]
===
match
---
trailer [12561,12563]
trailer [12561,12563]
===
match
---
string: '{{ var.json.get("a_variable", {"a": {"test": "unused_fallback"}})["a"]["test"] }}' [59150,59233]
string: '{{ var.json.get("a_variable", {"a": {"test": "unused_fallback"}})["a"]["test"] }}' [59150,59233]
===
match
---
simple_stmt [25653,25687]
simple_stmt [25653,25687]
===
match
---
name: result [42434,42440]
name: result [42434,42440]
===
match
---
expr_stmt [7458,7501]
expr_stmt [7458,7501]
===
match
---
expr_stmt [8491,8545]
expr_stmt [8491,8545]
===
match
---
name: dag_id [35242,35248]
name: dag_id [35242,35248]
===
match
---
trailer [67027,67034]
trailer [67027,67034]
===
match
---
operator: , [32050,32051]
operator: , [32050,32051]
===
match
---
operator: , [4914,4915]
operator: , [4914,4915]
===
match
---
number: 0 [31827,31828]
number: 0 [31827,31828]
===
match
---
funcdef [53726,54328]
funcdef [53726,54328]
===
match
---
comparison [55493,55573]
comparison [55493,55573]
===
match
---
number: 0 [32164,32165]
number: 0 [32164,32165]
===
match
---
trailer [62216,62218]
trailer [62216,62218]
===
match
---
operator: = [67983,67984]
operator: = [67983,67984]
===
match
---
atom_expr [5807,5824]
atom_expr [5807,5824]
===
match
---
operator: = [41735,41736]
operator: = [41735,41736]
===
match
---
operator: = [13008,13009]
operator: = [13008,13009]
===
match
---
name: merge [79179,79184]
name: merge [79179,79184]
===
match
---
number: 0 [20262,20263]
number: 0 [20262,20263]
===
match
---
with_stmt [29229,29411]
with_stmt [29229,29411]
===
match
---
trailer [13477,13491]
trailer [13477,13491]
===
match
---
operator: = [46811,46812]
operator: = [46811,46812]
===
match
---
name: query [3135,3140]
name: query [3135,3140]
===
match
---
trailer [64200,64202]
trailer [64200,64202]
===
match
---
name: State [79292,79297]
name: State [79292,79297]
===
match
---
operator: , [42816,42817]
operator: , [42816,42817]
===
match
---
name: pendulum [51962,51970]
name: pendulum [51962,51970]
===
match
---
operator: == [6264,6266]
operator: == [6264,6266]
===
match
---
argument [65635,65642]
argument [65635,65642]
===
match
---
trailer [26160,26162]
trailer [26160,26162]
===
match
---
dotted_name [2325,2337]
dotted_name [2325,2337]
===
match
---
simple_stmt [30146,30167]
simple_stmt [30146,30167]
===
match
---
name: end_date [23957,23965]
name: end_date [23957,23965]
===
match
---
name: session [52357,52364]
name: session [52357,52364]
===
match
---
expr_stmt [67328,67415]
expr_stmt [67328,67415]
===
match
---
argument [74233,74264]
argument [74233,74264]
===
match
---
name: seconds [22380,22387]
name: seconds [22380,22387]
===
match
---
number: 3 [55501,55502]
number: 3 [55501,55502]
===
match
---
name: airflow [1736,1743]
name: airflow [1736,1743]
===
match
---
atom_expr [20711,20729]
atom_expr [20711,20729]
===
match
---
atom_expr [62511,62552]
atom_expr [62511,62552]
===
match
---
name: mock_calls [67135,67145]
name: mock_calls [67135,67145]
===
match
---
atom_expr [61171,61188]
atom_expr [61171,61188]
===
match
---
number: 1 [33170,33171]
number: 1 [33170,33171]
===
match
---
testlist_star_expr [26808,26820]
testlist_star_expr [26808,26820]
===
match
---
trailer [72829,72834]
trailer [72829,72834]
===
match
---
name: TI [48347,48349]
name: TI [48347,48349]
===
match
---
simple_stmt [40764,40809]
simple_stmt [40764,40809]
===
match
---
argument [18381,18400]
argument [18381,18400]
===
match
---
trailer [64536,64767]
trailer [64536,64767]
===
match
---
testlist_comp [57743,57813]
testlist_comp [57743,57813]
===
match
---
assert_stmt [39262,39321]
assert_stmt [39262,39321]
===
match
---
atom_expr [52819,52860]
atom_expr [52819,52860]
===
match
---
name: dag_id [67984,67990]
name: dag_id [67984,67990]
===
match
---
atom_expr [23113,23124]
atom_expr [23113,23124]
===
match
---
argument [43706,43721]
argument [43706,43721]
===
match
---
argument [15697,15706]
argument [15697,15706]
===
match
---
simple_stmt [75570,75635]
simple_stmt [75570,75635]
===
match
---
simple_stmt [54558,54638]
simple_stmt [54558,54638]
===
match
---
operator: = [52474,52475]
operator: = [52474,52475]
===
match
---
atom_expr [5268,5280]
atom_expr [5268,5280]
===
match
---
expr_stmt [45122,45147]
expr_stmt [45122,45147]
===
match
---
argument [17595,17612]
argument [17595,17612]
===
match
---
name: self [8932,8936]
name: self [8932,8936]
===
match
---
operator: , [33364,33365]
operator: , [33364,33365]
===
match
---
operator: } [34511,34512]
operator: } [34511,34512]
===
match
---
atom_expr [73586,73601]
atom_expr [73586,73601]
===
match
---
param [55713,55717]
param [55713,55717]
===
match
---
operator: , [33687,33688]
operator: , [33687,33688]
===
match
---
expr_stmt [18678,18980]
expr_stmt [18678,18980]
===
match
---
string: "" [2906,2908]
string: "" [2906,2908]
===
match
---
trailer [74498,74520]
trailer [74498,74520]
===
match
---
name: task [14227,14231]
name: task [14227,14231]
===
match
---
trailer [19201,19334]
trailer [19201,19334]
===
match
---
operator: } [67047,67048]
operator: } [67047,67048]
===
match
---
trailer [3915,3917]
trailer [3915,3917]
===
match
---
string: "execution_date" [57355,57371]
string: "execution_date" [57355,57371]
===
match
---
expr_stmt [61577,61611]
expr_stmt [61577,61611]
===
match
---
operator: , [39115,39116]
operator: , [39115,39116]
===
match
---
comparison [49710,49758]
comparison [49710,49758]
===
match
---
arglist [69214,69252]
arglist [69214,69252]
===
match
---
arglist [78953,78992]
arglist [78953,78992]
===
match
---
name: state [50932,50937]
name: state [50932,50937]
===
match
---
operator: == [49622,49624]
operator: == [49622,49624]
===
match
---
suite [58168,58217]
suite [58168,58217]
===
match
---
string: 'C' [72688,72691]
string: 'C' [72688,72691]
===
match
---
operator: = [63032,63033]
operator: = [63032,63033]
===
match
---
expr_stmt [34271,34322]
expr_stmt [34271,34322]
===
match
---
name: DEFAULT_DATE [66355,66367]
name: DEFAULT_DATE [66355,66367]
===
match
---
atom_expr [12068,12115]
atom_expr [12068,12115]
===
match
---
operator: = [6743,6744]
operator: = [6743,6744]
===
match
---
operator: , [970,971]
operator: , [970,971]
===
match
---
name: RUNNING [74729,74736]
name: RUNNING [74729,74736]
===
match
---
operator: = [22266,22267]
operator: = [22266,22267]
===
match
---
operator: , [31709,31710]
operator: , [31709,31710]
===
match
---
expr_stmt [44320,44344]
expr_stmt [44320,44344]
===
match
---
trailer [20679,20683]
trailer [20679,20683]
===
match
---
arglist [44141,44189]
arglist [44141,44189]
===
match
---
operator: , [60686,60687]
operator: , [60686,60687]
===
match
---
name: execution_date [57223,57237]
name: execution_date [57223,57237]
===
match
---
expr_stmt [2917,2942]
expr_stmt [2917,2942]
===
match
---
name: ti_deps [1993,2000]
name: ti_deps [1993,2000]
===
match
---
name: expected_try_number [29583,29602]
name: expected_try_number [29583,29602]
===
match
---
operator: = [79791,79792]
operator: = [79791,79792]
===
match
---
simple_stmt [71315,71366]
simple_stmt [71315,71366]
===
match
---
name: catchup [53783,53790]
name: catchup [53783,53790]
===
match
---
name: datetime [79822,79830]
name: datetime [79822,79830]
===
match
---
name: start_date [4796,4806]
name: start_date [4796,4806]
===
match
---
assert_stmt [27259,27285]
assert_stmt [27259,27285]
===
match
---
atom_expr [67107,67117]
atom_expr [67107,67117]
===
match
---
name: utcnow [15095,15101]
name: utcnow [15095,15101]
===
match
---
operator: = [8423,8424]
operator: = [8423,8424]
===
match
---
name: task_id [67381,67388]
name: task_id [67381,67388]
===
match
---
name: ti [69206,69208]
name: ti [69206,69208]
===
match
---
name: AirflowFailException [63725,63745]
name: AirflowFailException [63725,63745]
===
match
---
trailer [25708,25720]
trailer [25708,25720]
===
match
---
operator: , [70250,70251]
operator: , [70250,70251]
===
match
---
operator: = [52644,52645]
operator: = [52644,52645]
===
match
---
argument [35311,35334]
argument [35311,35334]
===
match
---
name: self [55105,55109]
name: self [55105,55109]
===
match
---
simple_stmt [12830,12921]
simple_stmt [12830,12921]
===
match
---
name: TI [47803,47805]
name: TI [47803,47805]
===
match
---
arglist [49889,49951]
arglist [49889,49951]
===
match
---
operator: , [49106,49107]
operator: , [49106,49107]
===
match
---
operator: = [56358,56359]
operator: = [56358,56359]
===
match
---
arith_expr [12466,12486]
arith_expr [12466,12486]
===
match
---
operator: = [36875,36876]
operator: = [36875,36876]
===
match
---
name: call [955,959]
name: call [955,959]
===
match
---
simple_stmt [50325,50343]
simple_stmt [50325,50343]
===
match
---
import_from [1315,1480]
import_from [1315,1480]
===
match
---
suite [14687,15105]
suite [14687,15105]
===
match
---
atom_expr [7111,7117]
atom_expr [7111,7117]
===
match
---
trailer [30883,30893]
trailer [30883,30893]
===
match
---
assert_stmt [25699,25743]
assert_stmt [25699,25743]
===
match
---
expr_stmt [9294,9366]
expr_stmt [9294,9366]
===
match
---
simple_stmt [39513,39573]
simple_stmt [39513,39573]
===
match
---
string: 'D' [74356,74359]
string: 'D' [74356,74359]
===
match
---
name: done [27880,27884]
name: done [27880,27884]
===
match
---
string: 'airflow' [37135,37144]
string: 'airflow' [37135,37144]
===
match
---
atom_expr [13565,13578]
atom_expr [13565,13578]
===
match
---
trailer [42529,42533]
trailer [42529,42533]
===
match
---
dictorsetmaker [47216,47232]
dictorsetmaker [47216,47232]
===
match
---
trailer [49590,49600]
trailer [49590,49600]
===
match
---
assert_stmt [45401,45464]
assert_stmt [45401,45464]
===
match
---
operator: , [7613,7614]
operator: , [7613,7614]
===
match
---
trailer [18005,18234]
trailer [18005,18234]
===
match
---
name: ti [20699,20701]
name: ti [20699,20701]
===
match
---
trailer [34357,34432]
trailer [34357,34432]
===
match
---
name: task [50191,50195]
name: task [50191,50195]
===
match
---
assert_stmt [26078,26127]
assert_stmt [26078,26127]
===
match
---
name: one [10814,10817]
name: one [10814,10817]
===
match
---
operator: = [9800,9801]
operator: = [9800,9801]
===
match
---
trailer [55448,55469]
trailer [55448,55469]
===
match
---
param [42967,42971]
param [42967,42971]
===
match
---
operator: = [78325,78326]
operator: = [78325,78326]
===
match
---
string: 'one_failed' [33411,33423]
string: 'one_failed' [33411,33423]
===
match
---
operator: = [15869,15870]
operator: = [15869,15870]
===
match
---
string: '{{ var.value.a_variable }}' [58925,58953]
string: '{{ var.value.a_variable }}' [58925,58953]
===
match
---
operator: , [25234,25235]
operator: , [25234,25235]
===
match
---
name: date4 [27081,27086]
name: date4 [27081,27086]
===
match
---
comparison [29463,29489]
comparison [29463,29489]
===
match
---
parameters [64374,64376]
parameters [64374,64376]
===
match
---
param [55133,55140]
param [55133,55140]
===
match
---
arglist [52876,52913]
arglist [52876,52913]
===
match
---
atom_expr [68947,68957]
atom_expr [68947,68957]
===
match
---
trailer [73780,73787]
trailer [73780,73787]
===
match
---
name: run_with_error [18994,19008]
name: run_with_error [18994,19008]
===
match
---
operator: = [22475,22476]
operator: = [22475,22476]
===
match
---
trailer [40442,40457]
trailer [40442,40457]
===
match
---
atom_expr [52686,52723]
atom_expr [52686,52723]
===
match
---
param [44491,44495]
param [44491,44495]
===
match
---
number: 2 [17333,17334]
number: 2 [17333,17334]
===
match
---
number: 2016 [23697,23701]
number: 2016 [23697,23701]
===
match
---
number: 0 [32964,32965]
number: 0 [32964,32965]
===
match
---
testlist_comp [72193,72237]
testlist_comp [72193,72237]
===
match
---
argument [24738,24753]
argument [24738,24753]
===
match
---
assert_stmt [53449,53492]
assert_stmt [53449,53492]
===
match
---
operator: = [4933,4934]
operator: = [4933,4934]
===
match
---
operator: , [64096,64097]
operator: , [64096,64097]
===
match
---
with_stmt [8469,8711]
with_stmt [8469,8711]
===
match
---
atom_expr [18248,18295]
atom_expr [18248,18295]
===
match
---
operator: = [79572,79573]
operator: = [79572,79573]
===
match
---
trailer [61441,61445]
trailer [61441,61445]
===
match
---
name: SUCCESS [53871,53878]
name: SUCCESS [53871,53878]
===
match
---
operator: = [9942,9943]
operator: = [9942,9943]
===
match
---
assert_stmt [20773,20798]
assert_stmt [20773,20798]
===
match
---
name: self [36741,36745]
name: self [36741,36745]
===
match
---
name: DummyOperator [37337,37350]
name: DummyOperator [37337,37350]
===
match
---
operator: , [896,897]
operator: , [896,897]
===
match
---
atom_expr [30146,30166]
atom_expr [30146,30166]
===
match
---
funcdef [47004,47378]
funcdef [47004,47378]
===
match
---
name: session [45312,45319]
name: session [45312,45319]
===
match
---
simple_stmt [58070,58113]
simple_stmt [58070,58113]
===
match
---
string: 'test_xcom_2' [38178,38191]
string: 'test_xcom_2' [38178,38191]
===
match
---
operator: , [61814,61815]
operator: , [61814,61815]
===
match
---
name: task [60858,60862]
name: task [60858,60862]
===
match
---
expr_stmt [17043,17109]
expr_stmt [17043,17109]
===
match
---
trailer [30780,30904]
trailer [30780,30904]
===
match
---
param [66259,66269]
param [66259,66269]
===
match
---
name: create_dagrun [66512,66525]
name: create_dagrun [66512,66525]
===
match
---
trailer [33122,33130]
trailer [33122,33130]
===
match
---
name: execution_date [28849,28863]
name: execution_date [28849,28863]
===
match
---
name: dagrun_2 [56458,56466]
name: dagrun_2 [56458,56466]
===
match
---
arglist [44863,44901]
arglist [44863,44901]
===
match
---
testlist_comp [33082,33137]
testlist_comp [33082,33137]
===
match
---
operator: = [7435,7436]
operator: = [7435,7436]
===
match
---
string: 'baz' [16718,16723]
string: 'baz' [16718,16723]
===
match
---
atom_expr [53836,53849]
atom_expr [53836,53849]
===
match
---
name: TI [45003,45005]
name: TI [45003,45005]
===
match
---
comparison [53985,54040]
comparison [53985,54040]
===
match
---
name: days [44980,44984]
name: days [44980,44984]
===
match
---
simple_stmt [6182,6231]
simple_stmt [6182,6231]
===
match
---
name: models [63773,63779]
name: models [63773,63779]
===
match
---
operator: { [67093,67094]
operator: { [67093,67094]
===
match
---
name: poke_interval [24545,24558]
name: poke_interval [24545,24558]
===
match
---
argument [41634,41649]
argument [41634,41649]
===
match
---
arglist [22105,22124]
arglist [22105,22124]
===
match
---
operator: , [33826,33827]
operator: , [33826,33827]
===
match
---
name: executor_config [77437,77452]
name: executor_config [77437,77452]
===
match
---
name: session [13643,13650]
name: session [13643,13650]
===
match
---
atom_expr [53509,53552]
atom_expr [53509,53552]
===
match
---
number: 1 [18212,18213]
number: 1 [18212,18213]
===
match
---
operator: , [1419,1420]
operator: , [1419,1420]
===
match
---
name: DummyOperator [76083,76096]
name: DummyOperator [76083,76096]
===
match
---
trailer [61926,61941]
trailer [61926,61941]
===
match
---
simple_stmt [17711,17832]
simple_stmt [17711,17832]
===
match
---
name: result [59820,59826]
name: result [59820,59826]
===
match
---
name: task_id [58635,58642]
name: task_id [58635,58642]
===
match
---
param [54433,54451]
param [54433,54451]
===
match
---
simple_stmt [49868,49962]
simple_stmt [49868,49962]
===
match
---
simple_stmt [18678,18981]
simple_stmt [18678,18981]
===
match
---
name: op [7131,7133]
name: op [7131,7133]
===
match
---
name: execution_date [11502,11516]
name: execution_date [11502,11516]
===
match
---
assert_stmt [63523,63580]
assert_stmt [63523,63580]
===
match
---
simple_stmt [19414,19433]
simple_stmt [19414,19433]
===
match
---
name: dag [28684,28687]
name: dag [28684,28687]
===
match
---
name: deps [11695,11699]
name: deps [11695,11699]
===
match
---
decorator [53676,53722]
decorator [53676,53722]
===
match
---
operator: , [11500,11501]
operator: , [11500,11501]
===
match
---
atom_expr [68318,68360]
atom_expr [68318,68360]
===
match
---
param [67620,67624]
param [67620,67624]
===
match
---
name: downstream [74509,74519]
name: downstream [74509,74519]
===
match
---
operator: = [3045,3046]
operator: = [3045,3046]
===
match
---
number: 0 [33434,33435]
number: 0 [33434,33435]
===
match
---
trailer [43082,43132]
trailer [43082,43132]
===
match
---
operator: = [10578,10579]
operator: = [10578,10579]
===
match
---
string: "override" [47665,47675]
string: "override" [47665,47675]
===
match
---
name: get_test_ti [51925,51936]
name: get_test_ti [51925,51936]
===
match
---
atom [72192,72238]
atom [72192,72238]
===
match
---
name: dag_id [20027,20033]
name: dag_id [20027,20033]
===
match
---
name: task_id [56653,56660]
name: task_id [56653,56660]
===
match
---
operator: = [4077,4078]
operator: = [4077,4078]
===
match
---
number: 0 [57095,57096]
number: 0 [57095,57096]
===
match
---
atom_expr [63589,63624]
atom_expr [63589,63624]
===
match
---
name: session [66018,66025]
name: session [66018,66025]
===
match
---
operator: = [39120,39121]
operator: = [39120,39121]
===
match
---
name: DummyOperator [10465,10478]
name: DummyOperator [10465,10478]
===
match
---
string: "dummy" [76690,76697]
string: "dummy" [76690,76697]
===
match
---
argument [55886,55909]
argument [55886,55909]
===
match
---
expr_stmt [63266,63313]
expr_stmt [63266,63313]
===
match
---
expr_stmt [36839,37003]
expr_stmt [36839,37003]
===
match
---
name: State [72769,72774]
name: State [72769,72774]
===
match
---
atom_expr [26295,26324]
atom_expr [26295,26324]
===
match
---
name: test_generate_command_default_param [67197,67232]
name: test_generate_command_default_param [67197,67232]
===
match
---
number: 3 [32167,32168]
number: 3 [32167,32168]
===
match
---
operator: , [67875,67876]
operator: , [67875,67876]
===
match
---
trailer [4474,4670]
trailer [4474,4670]
===
match
---
name: ti [29463,29465]
name: ti [29463,29465]
===
match
---
comparison [53509,53581]
comparison [53509,53581]
===
match
---
name: State [33117,33122]
name: State [33117,33122]
===
match
---
name: State [36020,36025]
name: State [36020,36025]
===
match
---
assert_stmt [77317,77358]
assert_stmt [77317,77358]
===
match
---
expr_stmt [4867,5081]
expr_stmt [4867,5081]
===
match
---
trailer [64964,64970]
trailer [64964,64970]
===
match
---
suite [74303,74394]
suite [74303,74394]
===
match
---
name: FAILED [19778,19784]
name: FAILED [19778,19784]
===
match
---
atom_expr [46558,46593]
atom_expr [46558,46593]
===
match
---
simple_stmt [21315,21334]
simple_stmt [21315,21334]
===
match
---
param [55111,55113]
param [55111,55113]
===
match
---
atom_expr [10571,10638]
atom_expr [10571,10638]
===
match
---
name: state [75469,75474]
name: state [75469,75474]
===
match
---
atom_expr [77843,77870]
atom_expr [77843,77870]
===
match
---
atom_expr [74873,74915]
atom_expr [74873,74915]
===
match
---
name: ti_deps [2050,2057]
name: ti_deps [2050,2057]
===
match
---
trailer [8428,8460]
trailer [8428,8460]
===
match
---
operator: = [11359,11360]
operator: = [11359,11360]
===
match
---
string: 'test' [59567,59573]
string: 'test' [59567,59573]
===
match
---
name: DummyOperator [79013,79026]
name: DummyOperator [79013,79026]
===
match
---
argument [59696,59709]
argument [59696,59709]
===
match
---
operator: = [10553,10554]
operator: = [10553,10554]
===
match
---
atom [57742,57814]
atom [57742,57814]
===
match
---
operator: , [73515,73516]
operator: , [73515,73516]
===
match
---
operator: , [69469,69470]
operator: , [69469,69470]
===
match
---
atom_expr [76265,76278]
atom_expr [76265,76278]
===
match
---
name: owner [38648,38653]
name: owner [38648,38653]
===
match
---
operator: = [47068,47069]
operator: = [47068,47069]
===
match
---
operator: , [73187,73188]
operator: , [73187,73188]
===
match
---
name: ti [76349,76351]
name: ti [76349,76351]
===
match
---
operator: = [79633,79634]
operator: = [79633,79634]
===
match
---
trailer [21260,21271]
trailer [21260,21271]
===
match
---
operator: } [71812,71813]
operator: } [71812,71813]
===
match
---
name: datetime [79096,79104]
name: datetime [79096,79104]
===
match
---
name: end_date [22852,22860]
name: end_date [22852,22860]
===
match
---
name: DEFAULT_DATE [23771,23783]
name: DEFAULT_DATE [23771,23783]
===
match
---
operator: , [57661,57662]
operator: , [57661,57662]
===
match
---
atom_expr [7007,7025]
atom_expr [7007,7025]
===
match
---
name: dag [65635,65638]
name: dag [65635,65638]
===
match
---
simple_stmt [6044,6115]
simple_stmt [6044,6115]
===
match
---
atom_expr [50999,51016]
atom_expr [50999,51016]
===
match
---
funcdef [56878,57565]
funcdef [56878,57565]
===
match
---
name: max_delay [23595,23604]
name: max_delay [23595,23604]
===
match
---
parameters [67232,67238]
parameters [67232,67238]
===
match
---
name: BashOperator [23351,23363]
name: BashOperator [23351,23363]
===
match
---
name: commit [51222,51228]
name: commit [51222,51228]
===
match
---
operator: = [52225,52226]
operator: = [52225,52226]
===
match
---
param [3947,3951]
param [3947,3951]
===
match
---
name: TI [50263,50265]
name: TI [50263,50265]
===
match
---
suite [46050,46460]
suite [46050,46460]
===
match
---
operator: , [5563,5564]
operator: , [5563,5564]
===
match
---
operator: = [67699,67700]
operator: = [67699,67700]
===
match
---
name: dag_id [56956,56962]
name: dag_id [56956,56962]
===
match
---
name: ti [18350,18352]
name: ti [18350,18352]
===
match
---
name: State [21390,21395]
name: State [21390,21395]
===
match
---
simple_stmt [5261,5326]
simple_stmt [5261,5326]
===
match
---
name: TI [79067,79069]
name: TI [79067,79069]
===
match
---
name: add_task [4351,4359]
name: add_task [4351,4359]
===
match
---
name: passing_status [35471,35485]
name: passing_status [35471,35485]
===
match
---
argument [4587,4593]
argument [4587,4593]
===
match
---
assert_stmt [54917,55012]
assert_stmt [54917,55012]
===
match
---
name: task [63848,63852]
name: task [63848,63852]
===
match
---
name: run_with_error [20665,20679]
name: run_with_error [20665,20679]
===
match
---
trailer [9493,9497]
trailer [9493,9497]
===
match
---
name: deserialize_operator [80006,80026]
name: deserialize_operator [80006,80026]
===
match
---
operator: , [7878,7879]
operator: , [7878,7879]
===
match
---
string: 'task_id' [46912,46921]
string: 'task_id' [46912,46921]
===
match
---
trailer [52424,52426]
trailer [52424,52426]
===
match
---
simple_stmt [10754,10820]
simple_stmt [10754,10820]
===
match
---
name: TI [59725,59727]
name: TI [59725,59727]
===
match
---
simple_stmt [76388,76465]
simple_stmt [76388,76465]
===
match
---
operator: = [78379,78380]
operator: = [78379,78380]
===
match
---
trailer [20582,20584]
trailer [20582,20584]
===
match
---
trailer [9517,9524]
trailer [9517,9524]
===
match
---
operator: , [7017,7018]
operator: , [7017,7018]
===
match
---
param [51937,51945]
param [51937,51945]
===
match
---
number: 1 [16732,16733]
number: 1 [16732,16733]
===
match
---
name: TI [47490,47492]
name: TI [47490,47492]
===
match
---
name: value [39129,39134]
name: value [39129,39134]
===
match
---
atom_expr [37552,37567]
atom_expr [37552,37567]
===
match
---
name: mock_on_retry_2 [62745,62760]
name: mock_on_retry_2 [62745,62760]
===
match
---
testlist_comp [49550,49568]
testlist_comp [49550,49568]
===
match
---
operator: , [18443,18444]
operator: , [18443,18444]
===
match
---
operator: = [77048,77049]
operator: = [77048,77049]
===
match
---
name: dag [7327,7330]
name: dag [7327,7330]
===
match
---
number: 2 [15008,15009]
number: 2 [15008,15009]
===
match
---
trailer [49821,49859]
trailer [49821,49859]
===
match
---
arglist [51057,51195]
arglist [51057,51195]
===
match
---
atom_expr [7517,7565]
atom_expr [7517,7565]
===
match
---
number: 2016 [13211,13215]
number: 2016 [13211,13215]
===
match
---
expr_stmt [28830,28882]
expr_stmt [28830,28882]
===
match
---
operator: , [40357,40358]
operator: , [40357,40358]
===
match
---
trailer [22636,22649]
trailer [22636,22649]
===
match
---
atom_expr [73175,73187]
atom_expr [73175,73187]
===
match
---
name: DEFAULT_DATE [8447,8459]
name: DEFAULT_DATE [8447,8459]
===
match
---
operator: , [53047,53048]
operator: , [53047,53048]
===
match
---
operator: == [65200,65202]
operator: == [65200,65202]
===
match
---
argument [10537,10555]
argument [10537,10555]
===
match
---
simple_stmt [62594,62636]
simple_stmt [62594,62636]
===
match
---
atom [32878,32935]
atom [32878,32935]
===
match
---
name: assert_called_with [66992,67010]
name: assert_called_with [66992,67010]
===
match
---
name: tzinfo [6107,6113]
name: tzinfo [6107,6113]
===
match
---
trailer [54870,54878]
trailer [54870,54878]
===
match
---
funcdef [43449,43905]
funcdef [43449,43905]
===
match
---
name: DummyOperator [79602,79615]
name: DummyOperator [79602,79615]
===
match
---
name: State [45101,45106]
name: State [45101,45106]
===
match
---
name: State [78606,78611]
name: State [78606,78611]
===
match
---
operator: , [67379,67380]
operator: , [67379,67380]
===
match
---
trailer [50313,50315]
trailer [50313,50315]
===
match
---
operator: = [21741,21742]
operator: = [21741,21742]
===
match
---
trailer [27210,27212]
trailer [27210,27212]
===
match
---
argument [5245,5251]
argument [5245,5251]
===
match
---
operator: = [68660,68661]
operator: = [68660,68661]
===
match
---
arglist [9938,10001]
arglist [9938,10001]
===
match
---
operator: = [38687,38688]
operator: = [38687,38688]
===
match
---
atom_expr [25431,25452]
atom_expr [25431,25452]
===
match
---
operator: , [70500,70501]
operator: , [70500,70501]
===
match
---
operator: , [18131,18132]
operator: , [18131,18132]
===
match
---
name: ti [79185,79187]
name: ti [79185,79187]
===
match
---
parameters [36740,36746]
parameters [36740,36746]
===
match
---
string: 'name' [70575,70581]
string: 'name' [70575,70581]
===
match
---
atom_expr [78729,78771]
atom_expr [78729,78771]
===
match
---
name: task [41731,41735]
name: task [41731,41735]
===
match
---
name: start_date [10357,10367]
name: start_date [10357,10367]
===
match
---
trailer [49324,49362]
trailer [49324,49362]
===
match
---
operator: - [22392,22393]
operator: - [22392,22393]
===
match
---
trailer [50693,50853]
trailer [50693,50853]
===
match
---
number: 1 [36981,36982]
number: 1 [36981,36982]
===
match
---
trailer [60986,61000]
trailer [60986,61000]
===
match
---
simple_stmt [60462,60529]
simple_stmt [60462,60529]
===
match
---
argument [22834,22845]
argument [22834,22845]
===
match
---
simple_stmt [48981,49027]
simple_stmt [48981,49027]
===
match
---
atom_expr [14493,14501]
atom_expr [14493,14501]
===
match
---
name: mock_on_failure_1 [62029,62046]
name: mock_on_failure_1 [62029,62046]
===
match
---
name: state [67053,67058]
name: state [67053,67058]
===
match
---
argument [45448,45463]
argument [45448,45463]
===
match
---
operator: = [31009,31010]
operator: = [31009,31010]
===
match
---
expr_stmt [39956,39972]
expr_stmt [39956,39972]
===
match
---
suite [74007,74521]
suite [74007,74521]
===
match
---
parameters [30454,30460]
parameters [30454,30460]
===
match
---
name: mock [61595,61599]
name: mock [61595,61599]
===
match
---
trailer [13570,13578]
trailer [13570,13578]
===
match
---
atom_expr [30919,30937]
atom_expr [30919,30937]
===
match
---
name: dag [61429,61432]
name: dag [61429,61432]
===
match
---
string: '{{ var.json.a_variable["a"]["test"] }}' [59013,59053]
string: '{{ var.json.a_variable["a"]["test"] }}' [59013,59053]
===
match
---
name: session [15947,15954]
name: session [15947,15954]
===
match
---
name: State [36126,36131]
name: State [36126,36131]
===
match
---
trailer [73898,73902]
trailer [73898,73902]
===
match
---
operator: , [33100,33101]
operator: , [33100,33101]
===
match
---
simple_stmt [45156,45173]
simple_stmt [45156,45173]
===
match
---
trailer [74219,74265]
trailer [74219,74265]
===
match
---
name: parameterized [1076,1089]
name: parameterized [1076,1089]
===
match
---
operator: = [30474,30475]
operator: = [30474,30475]
===
match
---
number: 6 [40268,40269]
number: 6 [40268,40269]
===
match
---
atom_expr [20457,20465]
atom_expr [20457,20465]
===
match
---
operator: = [5067,5068]
operator: = [5067,5068]
===
match
---
name: init_state [75295,75305]
name: init_state [75295,75305]
===
match
---
parameters [55104,55141]
parameters [55104,55141]
===
match
---
operator: = [8604,8605]
operator: = [8604,8605]
===
match
---
param [47048,47052]
param [47048,47052]
===
match
---
arglist [36408,36458]
arglist [36408,36458]
===
match
---
name: DEFAULT_DATE [66390,66402]
name: DEFAULT_DATE [66390,66402]
===
match
---
atom_expr [42988,43053]
atom_expr [42988,43053]
===
match
---
name: tests [2363,2368]
name: tests [2363,2368]
===
match
---
name: end_date [22593,22601]
name: end_date [22593,22601]
===
match
---
operator: != [55645,55647]
operator: != [55645,55647]
===
match
---
name: python_callable [18095,18110]
name: python_callable [18095,18110]
===
match
---
trailer [41991,42037]
trailer [41991,42037]
===
match
---
name: ti [17588,17590]
name: ti [17588,17590]
===
match
---
atom_expr [13285,13302]
atom_expr [13285,13302]
===
match
---
funcdef [39739,41213]
funcdef [39739,41213]
===
match
---
trailer [24874,24919]
trailer [24874,24919]
===
match
---
argument [28625,28666]
argument [28625,28666]
===
match
---
trailer [55342,55345]
trailer [55342,55345]
===
match
---
name: task_state_in_callback [2645,2667]
name: task_state_in_callback [2645,2667]
===
match
---
expr_stmt [50442,50478]
expr_stmt [50442,50478]
===
match
---
simple_stmt [63427,63456]
simple_stmt [63427,63456]
===
match
---
suite [79440,79472]
suite [79440,79472]
===
match
---
name: date [23105,23109]
name: date [23105,23109]
===
match
---
testlist_comp [33472,33518]
testlist_comp [33472,33518]
===
match
---
comparison [10936,10958]
comparison [10936,10958]
===
match
---
number: 0 [32223,32224]
number: 0 [32223,32224]
===
match
---
name: dag [78943,78946]
name: dag [78943,78946]
===
match
---
trailer [75132,75150]
trailer [75132,75150]
===
match
---
string: 'op' [47784,47788]
string: 'op' [47784,47788]
===
match
---
name: task [79792,79796]
name: task [79792,79796]
===
match
---
parameters [28028,28034]
parameters [28028,28034]
===
match
---
trailer [18321,18454]
trailer [18321,18454]
===
match
---
operator: = [49871,49872]
operator: = [49871,49872]
===
match
---
trailer [30222,30234]
trailer [30222,30234]
===
match
---
string: 'dag' [6749,6754]
string: 'dag' [6749,6754]
===
match
---
operator: , [34255,34256]
operator: , [34255,34256]
===
match
---
number: 3 [33179,33180]
number: 3 [33179,33180]
===
match
---
operator: } [47232,47233]
operator: } [47232,47233]
===
match
---
operator: = [45001,45002]
operator: = [45001,45002]
===
match
---
argument [20541,20550]
argument [20541,20550]
===
match
---
name: ti [61272,61274]
name: ti [61272,61274]
===
match
---
suite [13432,13703]
suite [13432,13703]
===
match
---
trailer [35061,35068]
trailer [35061,35068]
===
match
---
name: datetime [53122,53130]
name: datetime [53122,53130]
===
match
---
name: start_date [64024,64034]
name: start_date [64024,64034]
===
match
---
number: 0 [32754,32755]
number: 0 [32754,32755]
===
match
---
string: 'DummyOperator' [79672,79687]
string: 'DummyOperator' [79672,79687]
===
match
---
expr_stmt [42982,43053]
expr_stmt [42982,43053]
===
match
---
atom_expr [71598,71617]
atom_expr [71598,71617]
===
match
---
name: environ [68950,68957]
name: environ [68950,68957]
===
match
---
trailer [25933,25942]
trailer [25933,25942]
===
match
---
string: 'email' [48726,48733]
string: 'email' [48726,48733]
===
match
---
name: cast [52476,52480]
name: cast [52476,52480]
===
match
---
operator: = [49247,49248]
operator: = [49247,49248]
===
match
---
operator: = [59600,59601]
operator: = [59600,59601]
===
match
---
argument [64795,64827]
argument [64795,64827]
===
match
---
name: try_number [22692,22702]
name: try_number [22692,22702]
===
match
---
operator: = [76081,76082]
operator: = [76081,76082]
===
match
---
name: overwrite_params_with_dag_run_conf [47593,47627]
name: overwrite_params_with_dag_run_conf [47593,47627]
===
match
---
comparison [76523,76538]
comparison [76523,76538]
===
match
---
operator: , [33429,33430]
operator: , [33429,33430]
===
match
---
atom_expr [55249,55318]
atom_expr [55249,55318]
===
match
---
arglist [44207,44250]
arglist [44207,44250]
===
match
---
operator: , [14136,14137]
operator: , [14136,14137]
===
match
---
number: 6 [38712,38713]
number: 6 [38712,38713]
===
match
---
argument [18414,18443]
argument [18414,18443]
===
match
---
fstring_expr [67106,67118]
fstring_expr [67106,67118]
===
match
---
name: schedule_interval [40048,40065]
name: schedule_interval [40048,40065]
===
match
---
simple_stmt [46856,46891]
simple_stmt [46856,46891]
===
match
---
name: TI [1441,1443]
name: TI [1441,1443]
===
match
---
name: Session [66037,66044]
name: Session [66037,66044]
===
match
---
operator: , [16583,16584]
operator: , [16583,16584]
===
match
---
name: dag [24998,25001]
name: dag [24998,25001]
===
match
---
atom_expr [12130,12152]
atom_expr [12130,12152]
===
match
---
arglist [60561,60687]
arglist [60561,60687]
===
match
---
simple_stmt [1631,1683]
simple_stmt [1631,1683]
===
match
---
name: state [54012,54017]
name: state [54012,54017]
===
match
---
name: pytest [60183,60189]
name: pytest [60183,60189]
===
match
---
with_item [15382,15431]
with_item [15382,15431]
===
match
---
name: dag [74637,74640]
name: dag [74637,74640]
===
match
---
operator: , [35848,35849]
operator: , [35848,35849]
===
match
---
name: date3 [27816,27821]
name: date3 [27816,27821]
===
match
---
name: test_template_with_variable_missing [58424,58459]
name: test_template_with_variable_missing [58424,58459]
===
match
---
trailer [23033,23044]
trailer [23033,23044]
===
match
---
trailer [10787,10813]
trailer [10787,10813]
===
match
---
name: method_patch [11989,12001]
name: method_patch [11989,12001]
===
match
---
argument [36323,36337]
argument [36323,36337]
===
match
---
arglist [60086,60124]
arglist [60086,60124]
===
match
---
name: dag_id [15393,15399]
name: dag_id [15393,15399]
===
match
---
name: dag [60823,60826]
name: dag [60823,60826]
===
match
---
trailer [65987,65993]
trailer [65987,65993]
===
match
---
name: dag_id [16083,16089]
name: dag_id [16083,16089]
===
match
---
name: enumerate [52598,52607]
name: enumerate [52598,52607]
===
match
---
name: key [41173,41176]
name: key [41173,41176]
===
match
---
atom_expr [6537,6564]
atom_expr [6537,6564]
===
match
---
number: 3 [33865,33866]
number: 3 [33865,33866]
===
match
---
name: ti [38784,38786]
name: ti [38784,38786]
===
match
---
atom_expr [41979,42037]
atom_expr [41979,42037]
===
match
---
expr_stmt [74024,74093]
expr_stmt [74024,74093]
===
match
---
trailer [18433,18443]
trailer [18433,18443]
===
match
---
simple_stmt [78515,78715]
simple_stmt [78515,78715]
===
match
---
name: session [45156,45163]
name: session [45156,45163]
===
match
---
atom_expr [49575,49600]
atom_expr [49575,49600]
===
match
---
assert_stmt [54730,54804]
assert_stmt [54730,54804]
===
match
---
atom_expr [51848,51911]
atom_expr [51848,51911]
===
match
---
atom_expr [61552,61568]
atom_expr [61552,61568]
===
match
---
simple_stmt [76516,76539]
simple_stmt [76516,76539]
===
match
---
name: fail [28231,28235]
name: fail [28231,28235]
===
match
---
string: 'one_failed' [33287,33299]
string: 'one_failed' [33287,33299]
===
match
---
name: self [3226,3230]
name: self [3226,3230]
===
match
---
operator: , [31229,31230]
operator: , [31229,31230]
===
match
---
name: end_date [31231,31239]
name: end_date [31231,31239]
===
match
---
trailer [58355,58373]
trailer [58355,58373]
===
match
---
name: dag [7408,7411]
name: dag [7408,7411]
===
match
---
string: 'one_success' [32264,32277]
string: 'one_success' [32264,32277]
===
match
---
trailer [67462,67523]
trailer [67462,67523]
===
match
---
operator: , [29160,29161]
operator: , [29160,29161]
===
match
---
operator: , [53120,53121]
operator: , [53120,53121]
===
match
---
trailer [67039,67047]
trailer [67039,67047]
===
match
---
operator: { [71979,71980]
operator: { [71979,71980]
===
match
---
atom_expr [18423,18443]
atom_expr [18423,18443]
===
match
---
name: DummyOperator [9829,9842]
name: DummyOperator [9829,9842]
===
match
---
operator: = [7138,7139]
operator: = [7138,7139]
===
match
---
argument [37477,37486]
argument [37477,37486]
===
match
---
arglist [73770,73864]
arglist [73770,73864]
===
match
---
string: 'fail_dag' [21742,21752]
string: 'fail_dag' [21742,21752]
===
match
---
name: add [10126,10129]
name: add [10126,10129]
===
match
---
trailer [48423,48427]
trailer [48423,48427]
===
match
---
name: ti [58226,58228]
name: ti [58226,58228]
===
match
---
atom_expr [56932,57111]
atom_expr [56932,57111]
===
match
---
atom_expr [73625,73643]
atom_expr [73625,73643]
===
match
---
name: ti [79133,79135]
name: ti [79133,79135]
===
match
---
trailer [3342,3365]
trailer [3342,3365]
===
match
---
name: done [34958,34962]
name: done [34958,34962]
===
match
---
arglist [41992,42036]
arglist [41992,42036]
===
match
---
name: start_date [65465,65475]
name: start_date [65465,65475]
===
match
---
operator: , [31756,31757]
operator: , [31756,31757]
===
match
---
operator: = [22872,22873]
operator: = [22872,22873]
===
match
---
simple_stmt [76145,76218]
simple_stmt [76145,76218]
===
match
---
assert_stmt [21251,21276]
assert_stmt [21251,21276]
===
match
---
atom_expr [62561,62570]
atom_expr [62561,62570]
===
match
---
operator: = [22213,22214]
operator: = [22213,22214]
===
match
---
name: State [54699,54704]
name: State [54699,54704]
===
match
---
argument [15947,15962]
argument [15947,15962]
===
match
---
operator: = [31028,31029]
operator: = [31028,31029]
===
match
---
arglist [67463,67522]
arglist [67463,67522]
===
match
---
with_stmt [7179,7243]
with_stmt [7179,7243]
===
match
---
argument [14238,14270]
argument [14238,14270]
===
match
---
operator: = [23858,23859]
operator: = [23858,23859]
===
match
---
comparison [77264,77312]
comparison [77264,77312]
===
match
---
atom_expr [38139,38204]
atom_expr [38139,38204]
===
match
---
operator: = [58662,58663]
operator: = [58662,58663]
===
match
---
argument [57186,57193]
argument [57186,57193]
===
match
---
name: run_ti_and_assert [27913,27930]
name: run_ti_and_assert [27913,27930]
===
match
---
atom_expr [71908,71921]
atom_expr [71908,71921]
===
match
---
name: state [12395,12400]
name: state [12395,12400]
===
match
---
simple_stmt [12429,12502]
simple_stmt [12429,12502]
===
match
---
atom [32015,32063]
atom [32015,32063]
===
match
---
operator: , [7884,7885]
operator: , [7884,7885]
===
match
---
name: mark [76549,76553]
name: mark [76549,76553]
===
match
---
number: 4 [21275,21276]
number: 4 [21275,21276]
===
match
---
string: 'airflow' [40210,40219]
string: 'airflow' [40210,40219]
===
match
---
operator: = [64000,64001]
operator: = [64000,64001]
===
match
---
expr_stmt [40086,40293]
expr_stmt [40086,40293]
===
match
---
trailer [9537,9541]
trailer [9537,9541]
===
match
---
trailer [64463,64506]
trailer [64463,64506]
===
match
---
trailer [3258,3300]
trailer [3258,3300]
===
match
---
operator: = [41614,41615]
operator: = [41614,41615]
===
match
---
trailer [22592,22601]
trailer [22592,22601]
===
match
---
name: pendulum [52481,52489]
name: pendulum [52481,52489]
===
match
---
atom_expr [23954,23981]
atom_expr [23954,23981]
===
match
---
name: dag [30763,30766]
name: dag [30763,30766]
===
match
---
argument [63784,63838]
argument [63784,63838]
===
match
---
atom_expr [75506,75522]
atom_expr [75506,75522]
===
match
---
name: task [34472,34476]
name: task [34472,34476]
===
match
---
operator: = [76031,76032]
operator: = [76031,76032]
===
match
---
operator: = [42540,42541]
operator: = [42540,42541]
===
match
---
name: test_are_dependents_done [36170,36194]
name: test_are_dependents_done [36170,36194]
===
match
---
name: init_state [74899,74909]
name: init_state [74899,74909]
===
match
---
simple_stmt [28210,28223]
simple_stmt [28210,28223]
===
match
---
atom_expr [77220,77233]
atom_expr [77220,77233]
===
match
---
trailer [14446,14448]
trailer [14446,14448]
===
match
---
string: '1' [69953,69956]
string: '1' [69953,69956]
===
match
---
atom_expr [6134,6173]
atom_expr [6134,6173]
===
match
---
argument [43108,43131]
argument [43108,43131]
===
match
---
string: 'task' [67701,67707]
string: 'task' [67701,67707]
===
match
---
atom_expr [6397,6520]
atom_expr [6397,6520]
===
match
---
name: title [49557,49562]
name: title [49557,49562]
===
match
---
expr_stmt [7408,7449]
expr_stmt [7408,7449]
===
match
---
name: DummyOperator [36309,36322]
name: DummyOperator [36309,36322]
===
match
---
comparison [42434,42451]
comparison [42434,42451]
===
match
---
operator: , [78619,78620]
operator: , [78619,78620]
===
match
---
suite [15263,16778]
suite [15263,16778]
===
match
---
trailer [40701,40705]
trailer [40701,40705]
===
match
---
assert_stmt [67532,67573]
assert_stmt [67532,67573]
===
match
---
trailer [77139,77144]
trailer [77139,77144]
===
match
---
argument [11385,11400]
argument [11385,11400]
===
match
---
name: test_generate_command_specific_param [67583,67619]
name: test_generate_command_specific_param [67583,67619]
===
match
---
number: 0 [26752,26753]
number: 0 [26752,26753]
===
match
---
expr_stmt [2876,2908]
expr_stmt [2876,2908]
===
match
---
argument [39695,39715]
argument [39695,39715]
===
match
---
name: state [44390,44395]
name: state [44390,44395]
===
match
---
string: 'all_failed' [33082,33094]
string: 'all_failed' [33082,33094]
===
match
---
name: DEFAULT_DATE [65963,65975]
name: DEFAULT_DATE [65963,65975]
===
match
---
operator: , [53156,53157]
operator: , [53156,53157]
===
match
---
name: DEFAULT_DATE [7488,7500]
name: DEFAULT_DATE [7488,7500]
===
match
---
name: dag [16118,16121]
name: dag [16118,16121]
===
match
---
name: Pool [10788,10792]
name: Pool [10788,10792]
===
match
---
name: ti [40638,40640]
name: ti [40638,40640]
===
match
---
suite [63686,64309]
suite [63686,64309]
===
match
---
operator: , [67493,67494]
operator: , [67493,67494]
===
match
---
argument [73849,73863]
argument [73849,73863]
===
match
---
name: ti [10912,10914]
name: ti [10912,10914]
===
match
---
operator: = [46086,46087]
operator: = [46086,46087]
===
match
---
trailer [2766,2774]
trailer [2766,2774]
===
match
---
name: utcnow [16425,16431]
name: utcnow [16425,16431]
===
match
---
argument [63118,63155]
argument [63118,63155]
===
match
---
atom_expr [55648,55669]
atom_expr [55648,55669]
===
match
---
arglist [18711,18970]
arglist [18711,18970]
===
match
---
argument [5318,5324]
argument [5318,5324]
===
match
---
name: func [24294,24298]
name: func [24294,24298]
===
match
---
name: UP_FOR_RETRY [64946,64958]
name: UP_FOR_RETRY [64946,64958]
===
match
---
parameters [20418,20422]
parameters [20418,20422]
===
match
---
name: dag [76127,76130]
name: dag [76127,76130]
===
match
---
trailer [52193,52200]
trailer [52193,52200]
===
match
---
name: create_session [9441,9455]
name: create_session [9441,9455]
===
match
---
trailer [79117,79119]
trailer [79117,79119]
===
match
---
operator: = [13309,13310]
operator: = [13309,13310]
===
match
---
name: ti_list [54236,54243]
name: ti_list [54236,54243]
===
match
---
atom_expr [30476,30535]
atom_expr [30476,30535]
===
match
---
arglist [56344,56438]
arglist [56344,56438]
===
match
---
atom_expr [18277,18294]
atom_expr [18277,18294]
===
match
---
operator: = [9731,9732]
operator: = [9731,9732]
===
match
---
trailer [67171,67182]
trailer [67171,67182]
===
match
---
string: 'C' [72341,72344]
string: 'C' [72341,72344]
===
match
---
operator: , [12492,12493]
operator: , [12492,12493]
===
match
---
atom_expr [12004,12021]
atom_expr [12004,12021]
===
match
---
trailer [54094,54102]
trailer [54094,54102]
===
match
---
expr_stmt [46552,46593]
expr_stmt [46552,46593]
===
match
---
name: ti1 [44854,44857]
name: ti1 [44854,44857]
===
match
---
operator: = [46832,46833]
operator: = [46832,46833]
===
match
---
operator: , [32900,32901]
operator: , [32900,32901]
===
match
---
operator: = [37167,37168]
operator: = [37167,37168]
===
match
---
atom_expr [22461,22474]
atom_expr [22461,22474]
===
match
---
expr_stmt [38425,38445]
expr_stmt [38425,38445]
===
match
---
operator: = [75475,75476]
operator: = [75475,75476]
===
match
---
operator: = [50270,50271]
operator: = [50270,50271]
===
match
---
testlist_comp [71701,73428]
testlist_comp [71701,73428]
===
match
---
atom_expr [46609,46645]
atom_expr [46609,46645]
===
match
---
name: ti [77370,77372]
name: ti [77370,77372]
===
match
---
name: end_date [4421,4429]
name: end_date [4421,4429]
===
match
---
name: DateTime [57555,57563]
name: DateTime [57555,57563]
===
match
---
name: scenario [54479,54487]
name: scenario [54479,54487]
===
match
---
name: dag [38838,38841]
name: dag [38838,38841]
===
match
---
name: run_as_user [76812,76823]
name: run_as_user [76812,76823]
===
match
---
argument [18262,18294]
argument [18262,18294]
===
match
---
atom_expr [38789,38828]
atom_expr [38789,38828]
===
match
---
operator: , [24753,24754]
operator: , [24753,24754]
===
match
---
operator: = [62518,62519]
operator: = [62518,62519]
===
match
---
name: k8s_pod_yaml [70845,70857]
name: k8s_pod_yaml [70845,70857]
===
match
---
trailer [51970,51979]
trailer [51970,51979]
===
match
---
atom_expr [51072,51089]
atom_expr [51072,51089]
===
match
---
arith_expr [4553,4594]
arith_expr [4553,4594]
===
match
---
name: task [56738,56742]
name: task [56738,56742]
===
match
---
operator: == [5916,5918]
operator: == [5916,5918]
===
match
---
simple_stmt [75506,75523]
simple_stmt [75506,75523]
===
match
---
arglist [78267,78306]
arglist [78267,78306]
===
match
---
name: models [1154,1160]
name: models [1154,1160]
===
match
---
suite [69114,69197]
suite [69114,69197]
===
match
---
string: "A -> B -> C, with fast-follow OFF, when A runs, B shouldn't be QUEUED." [72469,72541]
string: "A -> B -> C, with fast-follow OFF, when A runs, B shouldn't be QUEUED." [72469,72541]
===
match
---
name: state [54263,54268]
name: state [54263,54268]
===
match
---
number: 0 [31761,31762]
number: 0 [31761,31762]
===
match
---
operator: = [46556,46557]
operator: = [46556,46557]
===
match
---
suite [74459,74521]
suite [74459,74521]
===
match
---
name: TestCase [77546,77554]
name: TestCase [77546,77554]
===
match
---
number: 5 [32760,32761]
number: 5 [32760,32761]
===
match
---
operator: , [4940,4941]
operator: , [4940,4941]
===
match
---
simple_stmt [43945,44032]
simple_stmt [43945,44032]
===
match
---
atom_expr [75535,75556]
atom_expr [75535,75556]
===
match
---
name: now [52190,52193]
name: now [52190,52193]
===
match
---
operator: , [17568,17569]
operator: , [17568,17569]
===
match
---
atom_expr [3226,3237]
atom_expr [3226,3237]
===
match
---
name: ti [22394,22396]
name: ti [22394,22396]
===
match
---
arith_expr [60644,60686]
arith_expr [60644,60686]
===
match
---
operator: = [51846,51847]
operator: = [51846,51847]
===
match
---
operator: = [40659,40660]
operator: = [40659,40660]
===
match
---
atom_expr [61272,61292]
atom_expr [61272,61292]
===
match
---
operator: , [51944,51945]
operator: , [51944,51945]
===
match
---
operator: = [37388,37389]
operator: = [37388,37389]
===
match
---
name: DEFAULT_DATE [65830,65842]
name: DEFAULT_DATE [65830,65842]
===
match
---
name: dag_id [64464,64470]
name: dag_id [64464,64470]
===
match
---
number: 0 [27125,27126]
number: 0 [27125,27126]
===
match
---
name: days [53068,53072]
name: days [53068,53072]
===
match
---
operator: = [63890,63891]
operator: = [63890,63891]
===
match
---
argument [14358,14377]
argument [14358,14377]
===
match
---
atom_expr [36309,36363]
atom_expr [36309,36363]
===
match
---
string: 'airflow' [14127,14136]
string: 'airflow' [14127,14136]
===
match
---
name: new_date [52635,52643]
name: new_date [52635,52643]
===
match
---
argument [58234,58243]
argument [58234,58243]
===
match
---
number: 0 [26897,26898]
number: 0 [26897,26898]
===
match
---
operator: , [18260,18261]
operator: , [18260,18261]
===
match
---
name: self [8404,8408]
name: self [8404,8408]
===
match
---
trailer [78449,78455]
trailer [78449,78455]
===
match
---
name: day_2 [56515,56520]
name: day_2 [56515,56520]
===
match
---
operator: , [28802,28803]
operator: , [28802,28803]
===
match
---
param [25193,25202]
param [25193,25202]
===
match
---
name: task_id [46623,46630]
name: task_id [46623,46630]
===
match
---
operator: , [21840,21841]
operator: , [21840,21841]
===
match
---
name: State [73156,73161]
name: State [73156,73161]
===
match
---
name: retries [24639,24646]
name: retries [24639,24646]
===
match
---
name: State [2235,2240]
name: State [2235,2240]
===
match
---
trailer [27734,27747]
trailer [27734,27747]
===
match
---
operator: = [41197,41198]
operator: = [41197,41198]
===
match
---
trailer [66068,66072]
trailer [66068,66072]
===
match
---
name: dependencies [73491,73503]
name: dependencies [73491,73503]
===
match
---
import_name [826,841]
import_name [826,841]
===
match
---
trailer [53401,53439]
trailer [53401,53439]
===
match
---
operator: , [31759,31760]
operator: , [31759,31760]
===
match
---
operator: = [6106,6107]
operator: = [6106,6107]
===
match
---
testlist_star_expr [48489,48512]
testlist_star_expr [48489,48512]
===
match
---
operator: , [35524,35525]
operator: , [35524,35525]
===
match
---
assert_stmt [76388,76464]
assert_stmt [76388,76464]
===
match
---
string: 'airflow' [28707,28716]
string: 'airflow' [28707,28716]
===
match
---
name: DagRunType [41915,41925]
name: DagRunType [41915,41925]
===
match
---
operator: , [44164,44165]
operator: , [44164,44165]
===
match
---
name: assert_not_called [62700,62717]
name: assert_not_called [62700,62717]
===
match
---
operator: = [9963,9964]
operator: = [9963,9964]
===
match
---
assert_stmt [16703,16750]
assert_stmt [16703,16750]
===
match
---
operator: = [6369,6370]
operator: = [6369,6370]
===
match
---
operator: , [15012,15013]
operator: , [15012,15013]
===
match
---
assert_stmt [35147,35178]
assert_stmt [35147,35178]
===
match
---
expr_stmt [38455,38521]
expr_stmt [38455,38521]
===
match
---
operator: = [74689,74690]
operator: = [74689,74690]
===
match
---
fstring_start: f' [11910,11912]
fstring_start: f' [11910,11912]
===
match
---
trailer [21455,21466]
trailer [21455,21466]
===
match
---
testlist_comp [52819,53157]
testlist_comp [52819,53157]
===
match
---
simple_stmt [4050,4145]
simple_stmt [4050,4145]
===
match
---
string: 'C' [72836,72839]
string: 'C' [72836,72839]
===
match
---
name: session [68416,68423]
name: session [68416,68423]
===
match
---
trailer [55559,55562]
trailer [55559,55562]
===
match
---
name: ti1 [37552,37555]
name: ti1 [37552,37555]
===
match
---
number: 1 [64095,64096]
number: 1 [64095,64096]
===
match
---
name: timedelta [4577,4586]
name: timedelta [4577,4586]
===
match
---
operator: , [61046,61047]
operator: , [61046,61047]
===
match
---
atom_expr [74803,74817]
atom_expr [74803,74817]
===
match
---
name: ti_deps [1929,1936]
name: ti_deps [1929,1936]
===
match
---
name: dag [44544,44547]
name: dag [44544,44547]
===
match
---
lambdef [42681,42696]
lambdef [42681,42696]
===
match
---
decorated [55018,55670]
decorated [55018,55670]
===
match
---
atom_expr [66133,66153]
atom_expr [66133,66153]
===
match
---
argument [79616,79628]
argument [79616,79628]
===
match
---
atom_expr [17401,17418]
atom_expr [17401,17418]
===
match
---
operator: = [56419,56420]
operator: = [56419,56420]
===
match
---
operator: = [63332,63333]
operator: = [63332,63333]
===
match
---
comparison [4417,4445]
comparison [4417,4445]
===
match
---
string: 'test_queries' [78267,78281]
string: 'test_queries' [78267,78281]
===
match
---
atom_expr [5769,5798]
atom_expr [5769,5798]
===
match
---
trailer [46987,46990]
trailer [46987,46990]
===
match
---
assert_stmt [29619,29662]
assert_stmt [29619,29662]
===
match
---
atom_expr [43792,43840]
atom_expr [43792,43840]
===
match
---
operator: , [51979,51980]
operator: , [51979,51980]
===
match
---
suite [61369,63625]
suite [61369,63625]
===
match
---
name: DEFAULT_DATE [67510,67522]
name: DEFAULT_DATE [67510,67522]
===
match
---
argument [9938,9947]
argument [9938,9947]
===
match
---
simple_stmt [46899,46934]
simple_stmt [46899,46934]
===
match
---
atom_expr [63773,63839]
atom_expr [63773,63839]
===
match
---
decorator [71656,73445]
decorator [71656,73445]
===
match
---
name: self [3887,3891]
name: self [3887,3891]
===
match
---
atom_expr [64940,64958]
atom_expr [64940,64958]
===
match
---
operator: , [57221,57222]
operator: , [57221,57222]
===
match
---
operator: , [18367,18368]
operator: , [18367,18368]
===
match
---
name: minutes [26206,26213]
name: minutes [26206,26213]
===
match
---
simple_stmt [13003,13243]
simple_stmt [13003,13243]
===
match
---
operator: = [47488,47489]
operator: = [47488,47489]
===
match
---
name: start_date [7477,7487]
name: start_date [7477,7487]
===
match
---
trailer [28645,28655]
trailer [28645,28655]
===
match
---
operator: , [31865,31866]
operator: , [31865,31866]
===
match
---
arglist [59983,60018]
arglist [59983,60018]
===
match
---
funcdef [77876,77923]
funcdef [77876,77923]
===
match
---
name: date [24026,24030]
name: date [24026,24030]
===
match
---
trailer [56545,56553]
trailer [56545,56553]
===
match
---
operator: = [47139,47140]
operator: = [47139,47140]
===
match
---
name: TI [80198,80200]
name: TI [80198,80200]
===
match
---
simple_stmt [75939,75975]
simple_stmt [75939,75975]
===
match
---
trailer [54175,54190]
trailer [54175,54190]
===
match
---
trailer [7079,7086]
trailer [7079,7086]
===
match
---
operator: = [48297,48298]
operator: = [48297,48298]
===
match
---
trailer [3205,3212]
trailer [3205,3212]
===
match
---
name: State [53322,53327]
name: State [53322,53327]
===
match
---
expr_stmt [66018,66046]
expr_stmt [66018,66046]
===
match
---
operator: = [73858,73859]
operator: = [73858,73859]
===
match
---
operator: , [32063,32064]
operator: , [32063,32064]
===
match
---
number: 10 [50650,50652]
number: 10 [50650,50652]
===
match
---
operator: , [49199,49200]
operator: , [49199,49200]
===
match
---
funcdef [17660,18513]
funcdef [17660,18513]
===
match
---
operator: , [15069,15070]
operator: , [15069,15070]
===
match
---
trailer [51074,51089]
trailer [51074,51089]
===
match
---
name: dag_run [47173,47180]
name: dag_run [47173,47180]
===
match
---
name: run_type [65738,65746]
name: run_type [65738,65746]
===
match
---
name: DAG [18636,18639]
name: DAG [18636,18639]
===
match
---
operator: , [32352,32353]
operator: , [32352,32353]
===
match
---
name: execution_date [40359,40373]
name: execution_date [40359,40373]
===
match
---
trailer [61641,61825]
trailer [61641,61825]
===
match
---
string: 'test_xcom' [41156,41167]
string: 'test_xcom' [41156,41167]
===
match
---
string: '&dag_id=dag' [46394,46407]
string: '&dag_id=dag' [46394,46407]
===
match
---
name: key [39045,39048]
name: key [39045,39048]
===
match
---
name: dag [7692,7695]
name: dag [7692,7695]
===
match
---
trailer [75788,75792]
trailer [75788,75792]
===
match
---
simple_stmt [39798,39948]
simple_stmt [39798,39948]
===
match
---
funcdef [61339,63625]
funcdef [61339,63625]
===
match
---
string: 'test fail status name' [35410,35433]
string: 'test fail status name' [35410,35433]
===
match
---
simple_stmt [61197,61214]
simple_stmt [61197,61214]
===
match
---
name: downstream_ti_state [36624,36643]
name: downstream_ti_state [36624,36643]
===
match
---
expr_stmt [64116,64168]
expr_stmt [64116,64168]
===
match
---
name: ti_1 [56726,56730]
name: ti_1 [56726,56730]
===
match
---
operator: == [25837,25839]
operator: == [25837,25839]
===
match
---
operator: , [22121,22122]
operator: , [22121,22122]
===
match
---
name: ti [58659,58661]
name: ti [58659,58661]
===
match
---
atom_expr [71856,71866]
atom_expr [71856,71866]
===
match
---
number: 2 [16342,16343]
number: 2 [16342,16343]
===
match
---
trailer [3695,3704]
trailer [3695,3704]
===
match
---
and_test [4792,4857]
and_test [4792,4857]
===
match
---
string: 'cron/no-catchup' [52876,52893]
string: 'cron/no-catchup' [52876,52893]
===
match
---
trailer [41765,41774]
trailer [41765,41774]
===
match
---
operator: = [66680,66681]
operator: = [66680,66681]
===
match
---
operator: = [9297,9298]
operator: = [9297,9298]
===
match
---
simple_stmt [46942,46999]
simple_stmt [46942,46999]
===
match
---
trailer [31841,31857]
trailer [31841,31857]
===
match
---
trailer [36025,36033]
trailer [36025,36033]
===
match
---
argument [28508,28523]
argument [28508,28523]
===
match
---
atom_expr [36266,36288]
atom_expr [36266,36288]
===
match
---
name: execution_date [50881,50895]
name: execution_date [50881,50895]
===
match
---
operator: = [42000,42001]
operator: = [42000,42001]
===
match
---
operator: , [27866,27867]
operator: , [27866,27867]
===
match
---
atom_expr [39143,39151]
atom_expr [39143,39151]
===
match
---
operator: = [76279,76280]
operator: = [76279,76280]
===
match
---
name: dag [7114,7117]
name: dag [7114,7117]
===
match
---
trailer [66413,66423]
trailer [66413,66423]
===
match
---
simple_stmt [65573,65699]
simple_stmt [65573,65699]
===
match
---
operator: , [63202,63203]
operator: , [63202,63203]
===
match
---
with_stmt [7948,8022]
with_stmt [7948,8022]
===
match
---
trailer [12861,12873]
trailer [12861,12873]
===
match
---
atom_expr [13445,13460]
atom_expr [13445,13460]
===
match
---
operator: = [41043,41044]
operator: = [41043,41044]
===
match
---
atom_expr [13711,13736]
atom_expr [13711,13736]
===
match
---
name: RUNNING [66821,66828]
name: RUNNING [66821,66828]
===
match
---
string: 'one_success' [32140,32153]
string: 'one_success' [32140,32153]
===
match
---
comparison [39682,39733]
comparison [39682,39733]
===
match
---
expr_stmt [67716,67916]
expr_stmt [67716,67916]
===
match
---
operator: , [27747,27748]
operator: , [27747,27748]
===
match
---
number: 3 [44427,44428]
number: 3 [44427,44428]
===
match
---
name: State [56540,56545]
name: State [56540,56545]
===
match
---
trailer [14008,14210]
trailer [14008,14210]
===
match
---
name: models [16072,16078]
name: models [16072,16078]
===
match
---
operator: , [14189,14190]
operator: , [14189,14190]
===
match
---
operator: , [51648,51649]
operator: , [51648,51649]
===
match
---
atom_expr [74665,74737]
atom_expr [74665,74737]
===
match
---
atom_expr [13524,13541]
atom_expr [13524,13541]
===
match
---
trailer [61112,61122]
trailer [61112,61122]
===
match
---
trailer [66171,66177]
trailer [66171,66177]
===
match
---
trailer [68320,68360]
trailer [68320,68360]
===
match
---
argument [40748,40754]
argument [40748,40754]
===
match
---
string: 'get_concurrency_reached' [8863,8888]
string: 'get_concurrency_reached' [8863,8888]
===
match
---
name: dag [4810,4813]
name: dag [4810,4813]
===
match
---
trailer [22632,22636]
trailer [22632,22636]
===
match
---
simple_stmt [79647,79688]
simple_stmt [79647,79688]
===
match
---
trailer [22270,22290]
trailer [22270,22290]
===
match
---
name: task_id [75367,75374]
name: task_id [75367,75374]
===
match
---
trailer [31121,31127]
trailer [31121,31127]
===
match
---
simple_stmt [66837,66866]
simple_stmt [66837,66866]
===
match
---
name: mock_on_failure_2 [62682,62699]
name: mock_on_failure_2 [62682,62699]
===
match
---
name: task_id [67486,67493]
name: task_id [67486,67493]
===
match
---
testlist_star_expr [49549,49572]
testlist_star_expr [49549,49572]
===
match
---
argument [66344,66367]
argument [66344,66367]
===
match
---
name: ti [5833,5835]
name: ti [5833,5835]
===
match
---
operator: == [79865,79867]
operator: == [79865,79867]
===
match
---
name: DEFAULT_DATE [6342,6354]
name: DEFAULT_DATE [6342,6354]
===
match
---
with_item [10077,10104]
with_item [10077,10104]
===
match
---
trailer [18948,18969]
trailer [18948,18969]
===
match
---
trailer [12945,12994]
trailer [12945,12994]
===
match
---
atom_expr [47590,47641]
atom_expr [47590,47641]
===
match
---
trailer [23687,23696]
trailer [23687,23696]
===
match
---
trailer [77975,77977]
trailer [77975,77977]
===
match
---
name: expand [35954,35960]
name: expand [35954,35960]
===
match
---
dictorsetmaker [72376,72428]
dictorsetmaker [72376,72428]
===
match
---
string: 'airflow' [13159,13168]
string: 'airflow' [13159,13168]
===
match
---
name: retry_delay [28625,28636]
name: retry_delay [28625,28636]
===
match
---
simple_stmt [63355,63419]
simple_stmt [63355,63419]
===
match
---
name: operators [1592,1601]
name: operators [1592,1601]
===
match
---
name: ti_1 [56849,56853]
name: ti_1 [56849,56853]
===
match
---
atom_expr [50325,50342]
atom_expr [50325,50342]
===
match
---
suite [11021,12594]
suite [11021,12594]
===
match
---
operator: = [30486,30487]
operator: = [30486,30487]
===
match
---
operator: , [70967,70968]
operator: , [70967,70968]
===
match
---
operator: == [46992,46994]
operator: == [46992,46994]
===
match
---
trailer [30735,30745]
trailer [30735,30745]
===
match
---
atom_expr [58621,58649]
atom_expr [58621,58649]
===
match
---
atom [72173,72556]
atom [72173,72556]
===
match
---
operator: , [9775,9776]
operator: , [9775,9776]
===
match
---
string: 'test_reschedule_handling' [24421,24447]
string: 'test_reschedule_handling' [24421,24447]
===
match
---
comparison [38009,38024]
comparison [38009,38024]
===
match
---
simple_stmt [7111,7122]
simple_stmt [7111,7122]
===
match
---
trailer [36322,36363]
trailer [36322,36363]
===
match
---
operator: , [36144,36145]
operator: , [36144,36145]
===
match
---
name: now [49945,49948]
name: now [49945,49948]
===
match
---
simple_stmt [73657,73719]
simple_stmt [73657,73719]
===
match
---
expr_stmt [63026,63257]
expr_stmt [63026,63257]
===
match
---
operator: = [63270,63271]
operator: = [63270,63271]
===
match
---
argument [45304,45319]
argument [45304,45319]
===
match
---
name: task_id [2780,2787]
name: task_id [2780,2787]
===
match
---
atom_expr [14281,14431]
atom_expr [14281,14431]
===
match
---
dotted_name [2395,2419]
dotted_name [2395,2419]
===
match
---
atom_expr [30709,30724]
atom_expr [30709,30724]
===
match
---
name: state [62565,62570]
name: state [62565,62570]
===
match
---
operator: = [44548,44549]
operator: = [44548,44549]
===
match
---
simple_stmt [57120,57195]
simple_stmt [57120,57195]
===
match
---
operator: = [9850,9851]
operator: = [9850,9851]
===
match
---
except_clause [49494,49517]
except_clause [49494,49517]
===
match
---
trailer [59833,59849]
trailer [59833,59849]
===
match
---
atom_expr [4398,4412]
atom_expr [4398,4412]
===
match
---
name: DAG [69055,69058]
name: DAG [69055,69058]
===
match
---
name: task_id [9228,9235]
name: task_id [9228,9235]
===
match
---
operator: , [71115,71116]
operator: , [71115,71116]
===
match
---
simple_stmt [73732,73879]
simple_stmt [73732,73879]
===
match
---
operator: = [36843,36844]
operator: = [36843,36844]
===
match
---
name: ti [64776,64778]
name: ti [64776,64778]
===
match
---
name: retries [77391,77398]
name: retries [77391,77398]
===
match
---
operator: , [29004,29005]
operator: , [29004,29005]
===
match
---
atom_expr [39082,39125]
atom_expr [39082,39125]
===
match
---
for_stmt [52580,52755]
for_stmt [52580,52755]
===
match
---
simple_stmt [55999,56020]
simple_stmt [55999,56020]
===
match
---
nonlocal_stmt [60408,60423]
nonlocal_stmt [60408,60423]
===
match
---
name: task_id [17152,17159]
name: task_id [17152,17159]
===
match
---
name: timezone [22087,22095]
name: timezone [22087,22095]
===
match
---
string: 'a_variable' [59546,59558]
string: 'a_variable' [59546,59558]
===
match
---
name: new_task [68570,68578]
name: new_task [68570,68578]
===
match
---
name: pendulum [46949,46957]
name: pendulum [46949,46957]
===
match
---
atom_expr [51240,51279]
atom_expr [51240,51279]
===
match
---
trailer [79069,79120]
trailer [79069,79120]
===
match
---
name: get_previous_start_date [55346,55369]
name: get_previous_start_date [55346,55369]
===
match
---
name: dag_id [36270,36276]
name: dag_id [36270,36276]
===
match
---
name: op [67107,67109]
name: op [67107,67109]
===
match
---
name: ti [10936,10938]
name: ti [10936,10938]
===
match
---
argument [23639,23654]
argument [23639,23654]
===
match
---
string: "Start date should have been left alone" [76424,76464]
string: "Start date should have been left alone" [76424,76464]
===
match
---
name: state [29466,29471]
name: state [29466,29471]
===
match
---
atom_expr [13010,13242]
atom_expr [13010,13242]
===
match
---
argument [41827,41859]
argument [41827,41859]
===
match
---
atom_expr [67037,67047]
atom_expr [67037,67047]
===
match
---
trailer [3140,3144]
trailer [3140,3144]
===
match
---
arglist [68947,68998]
arglist [68947,68998]
===
match
---
operator: = [11268,11269]
operator: = [11268,11269]
===
match
---
operator: , [59425,59426]
operator: , [59425,59426]
===
match
---
argument [26206,26215]
argument [26206,26215]
===
match
---
name: Session [44525,44532]
name: Session [44525,44532]
===
match
---
atom_expr [24872,24919]
atom_expr [24872,24919]
===
match
---
operator: , [24836,24837]
operator: , [24836,24837]
===
match
---
name: SUCCESS [54024,54031]
name: SUCCESS [54024,54031]
===
match
---
operator: , [73831,73832]
operator: , [73831,73832]
===
match
---
sync_comp_for [7831,7860]
sync_comp_for [7831,7860]
===
match
---
string: 'airflow' [67346,67355]
string: 'airflow' [67346,67355]
===
match
---
atom_expr [40769,40808]
atom_expr [40769,40808]
===
match
---
name: session [68395,68402]
name: session [68395,68402]
===
match
---
name: utcnow [17410,17416]
name: utcnow [17410,17416]
===
match
---
trailer [35910,35931]
trailer [35910,35931]
===
match
---
decorated [53676,54328]
decorated [53676,54328]
===
match
---
operator: , [75618,75619]
operator: , [75618,75619]
===
match
---
funcdef [50142,50378]
funcdef [50142,50378]
===
match
---
operator: , [72248,72249]
operator: , [72248,72249]
===
match
---
trailer [40523,40533]
trailer [40523,40533]
===
match
---
name: param [52924,52929]
name: param [52924,52929]
===
match
---
name: dag [64604,64607]
name: dag [64604,64607]
===
match
---
name: ti [35908,35910]
name: ti [35908,35910]
===
match
---
number: 2018 [50060,50064]
number: 2018 [50060,50064]
===
match
---
atom_expr [21678,21708]
atom_expr [21678,21708]
===
match
---
name: self [3280,3284]
name: self [3280,3284]
===
match
---
comparison [12392,12416]
comparison [12392,12416]
===
match
---
name: xcom_push [37467,37476]
name: xcom_push [37467,37476]
===
match
---
assert_stmt [5891,5931]
assert_stmt [5891,5931]
===
match
---
atom_expr [24464,24857]
atom_expr [24464,24857]
===
match
---
name: dep_results [34696,34707]
name: dep_results [34696,34707]
===
match
---
operator: , [26866,26867]
operator: , [26866,26867]
===
match
---
number: 0 [22120,22121]
number: 0 [22120,22121]
===
match
---
parameters [63703,63705]
parameters [63703,63705]
===
match
---
assert_stmt [6573,6605]
assert_stmt [6573,6605]
===
match
---
name: exec_date [37013,37022]
name: exec_date [37013,37022]
===
match
---
expr_stmt [51841,51911]
expr_stmt [51841,51911]
===
match
---
name: owner [7615,7620]
name: owner [7615,7620]
===
match
---
name: session [3852,3859]
name: session [3852,3859]
===
match
---
operator: , [58141,58142]
operator: , [58141,58142]
===
match
---
atom_expr [73777,73787]
atom_expr [73777,73787]
===
match
---
string: 'True' [73087,73093]
string: 'True' [73087,73093]
===
match
---
operator: , [48509,48510]
operator: , [48509,48510]
===
match
---
name: ti [6246,6248]
name: ti [6246,6248]
===
match
---
trailer [28439,28820]
trailer [28439,28820]
===
match
---
trailer [49875,49961]
trailer [49875,49961]
===
match
---
name: models [14706,14712]
name: models [14706,14712]
===
match
---
number: 1 [22114,22115]
number: 1 [22114,22115]
===
match
---
trailer [56755,56760]
trailer [56755,56760]
===
match
---
expr_stmt [78320,78363]
expr_stmt [78320,78363]
===
match
---
atom_expr [62245,62261]
atom_expr [62245,62261]
===
match
---
name: unittest [908,916]
name: unittest [908,916]
===
match
---
name: DAG [9647,9650]
name: DAG [9647,9650]
===
match
---
argument [59995,60018]
argument [59995,60018]
===
match
---
simple_stmt [12130,12181]
simple_stmt [12130,12181]
===
match
---
trailer [52335,52373]
trailer [52335,52373]
===
match
---
name: __class__ [11861,11870]
name: __class__ [11861,11870]
===
match
---
simple_stmt [13824,13923]
simple_stmt [13824,13923]
===
match
---
tfpdef [34015,34027]
tfpdef [34015,34027]
===
match
---
name: ti [31293,31295]
name: ti [31293,31295]
===
match
---
operator: , [28793,28794]
operator: , [28793,28794]
===
match
---
operator: , [57644,57645]
operator: , [57644,57645]
===
match
---
dotted_name [1176,1194]
dotted_name [1176,1194]
===
match
---
funcdef [14524,15187]
funcdef [14524,15187]
===
match
---
trailer [10608,10615]
trailer [10608,10615]
===
match
---
operator: = [28425,28426]
operator: = [28425,28426]
===
match
---
import_name [814,825]
import_name [814,825]
===
match
---
trailer [79135,79141]
trailer [79135,79141]
===
match
---
number: 1 [24835,24836]
number: 1 [24835,24836]
===
match
---
operator: = [10624,10625]
operator: = [10624,10625]
===
match
---
arglist [50870,50919]
arglist [50870,50919]
===
match
---
trailer [79455,79469]
trailer [79455,79469]
===
match
---
atom_expr [2810,2819]
atom_expr [2810,2819]
===
match
---
operator: = [37377,37378]
operator: = [37377,37378]
===
match
---
dictorsetmaker [71720,71774]
dictorsetmaker [71720,71774]
===
match
---
atom_expr [66874,66891]
atom_expr [66874,66891]
===
match
---
operator: = [4521,4522]
operator: = [4521,4522]
===
match
---
argument [49836,49858]
argument [49836,49858]
===
match
---
operator: = [22029,22030]
operator: = [22029,22030]
===
match
---
simple_stmt [24339,24364]
simple_stmt [24339,24364]
===
match
---
operator: , [64756,64757]
operator: , [64756,64757]
===
match
---
arglist [67977,68055]
arglist [67977,68055]
===
match
---
name: ti [19123,19125]
name: ti [19123,19125]
===
match
---
name: start_date [43651,43661]
name: start_date [43651,43661]
===
match
---
trailer [68664,68708]
trailer [68664,68708]
===
match
---
operator: , [23713,23714]
operator: , [23713,23714]
===
match
---
name: key [40601,40604]
name: key [40601,40604]
===
match
---
simple_stmt [5486,5533]
simple_stmt [5486,5533]
===
match
---
name: ti3 [63266,63269]
name: ti3 [63266,63269]
===
match
---
assert_stmt [39513,39572]
assert_stmt [39513,39572]
===
match
---
argument [64655,64670]
argument [64655,64670]
===
match
---
simple_stmt [67328,67416]
simple_stmt [67328,67416]
===
match
---
string: 'hive_in_python_op' [65614,65633]
string: 'hive_in_python_op' [65614,65633]
===
match
---
assert_stmt [14486,14518]
assert_stmt [14486,14518]
===
match
---
trailer [67873,67875]
trailer [67873,67875]
===
match
---
argument [16401,16433]
argument [16401,16433]
===
match
---
operator: , [33209,33210]
operator: , [33209,33210]
===
match
---
string: 'dag_id' [69364,69372]
string: 'dag_id' [69364,69372]
===
match
---
name: run [42907,42910]
name: run [42907,42910]
===
match
---
argument [18815,18856]
argument [18815,18856]
===
match
---
name: NONE [72775,72779]
name: NONE [72775,72779]
===
match
---
name: FAILED [21396,21402]
name: FAILED [21396,21402]
===
match
---
simple_stmt [61223,61242]
simple_stmt [61223,61242]
===
match
---
name: session [11610,11617]
name: session [11610,11617]
===
match
---
argument [5841,5849]
argument [5841,5849]
===
match
---
operator: , [30039,30040]
operator: , [30039,30040]
===
match
---
suite [42356,42508]
suite [42356,42508]
===
match
---
name: init_state [75255,75265]
name: init_state [75255,75265]
===
match
---
name: state [21180,21185]
name: state [21180,21185]
===
match
---
atom_expr [11488,11555]
atom_expr [11488,11555]
===
match
---
trailer [37948,37958]
trailer [37948,37958]
===
match
---
name: iter [12295,12299]
name: iter [12295,12299]
===
match
---
name: date1 [29940,29945]
name: date1 [29940,29945]
===
match
---
trailer [30479,30535]
trailer [30479,30535]
===
match
---
atom_expr [30009,30081]
atom_expr [30009,30081]
===
match
---
number: 1 [41698,41699]
number: 1 [41698,41699]
===
match
---
operator: , [15661,15662]
operator: , [15661,15662]
===
match
---
atom_expr [31836,31857]
atom_expr [31836,31857]
===
match
---
assert_stmt [41127,41212]
assert_stmt [41127,41212]
===
match
---
operator: , [66489,66490]
operator: , [66489,66490]
===
match
---
name: State [36055,36060]
name: State [36055,36060]
===
match
---
dotted_name [1636,1656]
dotted_name [1636,1656]
===
match
---
simple_stmt [54121,54220]
simple_stmt [54121,54220]
===
match
---
name: call_args [62761,62770]
name: call_args [62761,62770]
===
match
---
name: start_date [76044,76054]
name: start_date [76044,76054]
===
match
---
simple_stmt [49473,49482]
simple_stmt [49473,49482]
===
match
---
name: dag [44040,44043]
name: dag [44040,44043]
===
match
---
name: refresh_from_db [51471,51486]
name: refresh_from_db [51471,51486]
===
match
---
name: task_id [71455,71462]
name: task_id [71455,71462]
===
match
---
atom_expr [36557,36590]
atom_expr [36557,36590]
===
match
---
expr_stmt [75323,75390]
expr_stmt [75323,75390]
===
match
---
argument [41559,41588]
argument [41559,41588]
===
match
---
argument [37163,37173]
argument [37163,37173]
===
match
---
name: method_patch [12167,12179]
name: method_patch [12167,12179]
===
match
---
name: execution_date [22164,22178]
name: execution_date [22164,22178]
===
match
---
simple_stmt [842,856]
simple_stmt [842,856]
===
match
---
name: mock_open [49315,49324]
name: mock_open [49315,49324]
===
match
---
name: DAG [51760,51763]
name: DAG [51760,51763]
===
match
---
trailer [40560,40579]
trailer [40560,40579]
===
match
---
name: RenderedTaskInstanceFields [21487,21513]
name: RenderedTaskInstanceFields [21487,21513]
===
match
---
number: 0 [31904,31905]
number: 0 [31904,31905]
===
match
---
simple_stmt [54229,54328]
simple_stmt [54229,54328]
===
match
---
name: class_name [11930,11940]
name: class_name [11930,11940]
===
match
---
operator: = [61065,61066]
operator: = [61065,61066]
===
match
---
trailer [25127,25137]
trailer [25127,25137]
===
match
---
name: dag [13102,13105]
name: dag [13102,13105]
===
match
---
trailer [49944,49948]
trailer [49944,49948]
===
match
---
atom_expr [4980,5006]
atom_expr [4980,5006]
===
match
---
atom_expr [46116,46152]
atom_expr [46116,46152]
===
match
---
trailer [46768,46785]
trailer [46768,46785]
===
match
---
name: dag [30616,30619]
name: dag [30616,30619]
===
match
---
operator: = [18110,18111]
operator: = [18110,18111]
===
match
---
name: TIDepStatus [35398,35409]
name: TIDepStatus [35398,35409]
===
match
---
operator: = [65994,65995]
operator: = [65994,65995]
===
match
---
simple_stmt [78257,78308]
simple_stmt [78257,78308]
===
match
---
parameters [35217,35223]
parameters [35217,35223]
===
match
---
name: SCHEDULED [40524,40533]
name: SCHEDULED [40524,40533]
===
match
---
trailer [54274,54282]
trailer [54274,54282]
===
match
---
argument [34805,34810]
argument [34805,34810]
===
match
---
string: 'B' [75088,75091]
string: 'B' [75088,75091]
===
match
---
operator: , [11459,11460]
operator: , [11459,11460]
===
match
---
simple_stmt [26679,26705]
simple_stmt [26679,26705]
===
match
---
atom_expr [56420,56437]
atom_expr [56420,56437]
===
match
---
name: catchup [51816,51823]
name: catchup [51816,51823]
===
match
---
simple_stmt [9930,10003]
simple_stmt [9930,10003]
===
match
---
trailer [18835,18845]
trailer [18835,18845]
===
match
---
trailer [14442,14446]
trailer [14442,14446]
===
match
---
operator: = [40767,40768]
operator: = [40767,40768]
===
match
---
atom_expr [79784,79837]
atom_expr [79784,79837]
===
match
---
operator: , [32180,32181]
operator: , [32180,32181]
===
match
---
atom_expr [75811,75876]
atom_expr [75811,75876]
===
match
---
argument [35659,35686]
argument [35659,35686]
===
match
---
operator: , [79560,79561]
operator: , [79560,79561]
===
match
---
name: DagRunType [78646,78656]
name: DagRunType [78646,78656]
===
match
---
operator: { [71902,71903]
operator: { [71902,71903]
===
match
---
name: expand [55033,55039]
name: expand [55033,55039]
===
match
---
string: 'task2' [43714,43721]
string: 'task2' [43714,43721]
===
match
---
param [47740,47744]
param [47740,47744]
===
match
---
name: stop [12587,12591]
name: stop [12587,12591]
===
match
---
arglist [68665,68707]
arglist [68665,68707]
===
match
---
param [18539,18543]
param [18539,18543]
===
match
---
name: NONE [71862,71866]
name: NONE [71862,71866]
===
match
---
decorator [58879,59371]
decorator [58879,59371]
===
match
---
name: timedelta [60668,60677]
name: timedelta [60668,60677]
===
match
---
operator: = [75747,75748]
operator: = [75747,75748]
===
match
---
operator: @ [15192,15193]
operator: @ [15192,15193]
===
match
---
name: try_number [20783,20793]
name: try_number [20783,20793]
===
match
---
dictorsetmaker [72192,72247]
dictorsetmaker [72192,72247]
===
match
---
simple_stmt [29881,29931]
simple_stmt [29881,29931]
===
match
---
operator: = [47559,47560]
operator: = [47559,47560]
===
match
---
expr_stmt [30545,30668]
expr_stmt [30545,30668]
===
match
---
expr_stmt [6739,6780]
expr_stmt [6739,6780]
===
match
---
name: session [78692,78699]
name: session [78692,78699]
===
match
---
number: 0 [28664,28665]
number: 0 [28664,28665]
===
match
---
name: execution_date [43160,43174]
name: execution_date [43160,43174]
===
match
---
name: xcom_pull [37949,37958]
name: xcom_pull [37949,37958]
===
match
---
operator: = [22362,22363]
operator: = [22362,22363]
===
match
---
name: ti [11622,11624]
name: ti [11622,11624]
===
match
---
argument [56070,56076]
argument [56070,56076]
===
match
---
arglist [52336,52372]
arglist [52336,52372]
===
match
---
name: State [12856,12861]
name: State [12856,12861]
===
match
---
simple_stmt [30677,30689]
simple_stmt [30677,30689]
===
match
---
name: utcnow [10609,10615]
name: utcnow [10609,10615]
===
match
---
atom_expr [12301,12349]
atom_expr [12301,12349]
===
match
---
arglist [14799,15023]
arglist [14799,15023]
===
match
---
name: ti_list [55239,55246]
name: ti_list [55239,55246]
===
match
---
operator: { [73038,73039]
operator: { [73038,73039]
===
match
---
name: assert_not_called [62153,62170]
name: assert_not_called [62153,62170]
===
match
---
string: 'test_raise_other_exception' [64558,64586]
string: 'test_raise_other_exception' [64558,64586]
===
match
---
operator: , [53781,53782]
operator: , [53781,53782]
===
match
---
name: start_date [28760,28770]
name: start_date [28760,28770]
===
match
---
atom_expr [76349,76357]
atom_expr [76349,76357]
===
match
---
simple_stmt [2828,2868]
simple_stmt [2828,2868]
===
match
---
operator: } [19999,20000]
operator: } [19999,20000]
===
match
---
number: 0 [32351,32352]
number: 0 [32351,32352]
===
match
---
name: QUEUED [72722,72728]
name: QUEUED [72722,72728]
===
match
---
operator: = [74141,74142]
operator: = [74141,74142]
===
match
---
atom_expr [28933,28946]
atom_expr [28933,28946]
===
match
---
operator: , [71849,71850]
operator: , [71849,71850]
===
match
---
simple_stmt [47902,47921]
simple_stmt [47902,47921]
===
match
---
name: DEFAULT_DATE [67390,67402]
name: DEFAULT_DATE [67390,67402]
===
match
---
operator: = [43153,43154]
operator: = [43153,43154]
===
match
---
number: 1 [23706,23707]
number: 1 [23706,23707]
===
match
---
argument [64621,64641]
argument [64621,64641]
===
match
---
name: run_date [31221,31229]
name: run_date [31221,31229]
===
match
---
trailer [41961,41963]
trailer [41961,41963]
===
match
---
assert_stmt [44353,44378]
assert_stmt [44353,44378]
===
match
---
simple_stmt [16842,17035]
simple_stmt [16842,17035]
===
match
---
operator: = [42407,42408]
operator: = [42407,42408]
===
match
---
name: dag_id [24414,24420]
name: dag_id [24414,24420]
===
match
---
argument [7750,7762]
argument [7750,7762]
===
match
---
simple_stmt [47994,48029]
simple_stmt [47994,48029]
===
match
---
name: items [12246,12251]
name: items [12246,12251]
===
match
---
number: 2 [32217,32218]
number: 2 [32217,32218]
===
match
---
trailer [60146,60167]
trailer [60146,60167]
===
match
---
atom_expr [8631,8679]
atom_expr [8631,8679]
===
match
---
operator: , [23604,23605]
operator: , [23604,23605]
===
match
---
assert_stmt [12385,12416]
assert_stmt [12385,12416]
===
match
---
operator: + [4114,4115]
operator: + [4114,4115]
===
match
---
simple_stmt [7229,7243]
simple_stmt [7229,7243]
===
match
---
operator: == [24950,24952]
operator: == [24950,24952]
===
match
---
simple_stmt [30545,30669]
simple_stmt [30545,30669]
===
match
---
name: State [10207,10212]
name: State [10207,10212]
===
match
---
name: DEFAULT_DATE [78294,78306]
name: DEFAULT_DATE [78294,78306]
===
match
---
atom [31879,31937]
atom [31879,31937]
===
match
---
simple_stmt [56842,56873]
simple_stmt [56842,56873]
===
match
---
operator: = [7683,7684]
operator: = [7683,7684]
===
match
---
number: 1 [64722,64723]
number: 1 [64722,64723]
===
match
---
name: pool [24767,24771]
name: pool [24767,24771]
===
match
---
arglist [8645,8678]
arglist [8645,8678]
===
match
---
name: create_session [78902,78916]
name: create_session [78902,78916]
===
match
---
testlist_star_expr [27880,27890]
testlist_star_expr [27880,27890]
===
match
---
name: RUNNABLE_STATES [1964,1979]
name: RUNNABLE_STATES [1964,1979]
===
match
---
operator: = [15796,15797]
operator: = [15796,15797]
===
match
---
name: _clean [77914,77920]
name: _clean [77914,77920]
===
match
---
name: try_number [25766,25776]
name: try_number [25766,25776]
===
match
---
number: 0 [32517,32518]
number: 0 [32517,32518]
===
match
---
atom [59012,59063]
atom [59012,59063]
===
match
---
atom_expr [46863,46881]
atom_expr [46863,46881]
===
match
---
expr_stmt [37154,37200]
expr_stmt [37154,37200]
===
match
---
simple_stmt [50673,50854]
simple_stmt [50673,50854]
===
match
---
operator: , [47502,47503]
operator: , [47502,47503]
===
match
---
operator: , [33678,33679]
operator: , [33678,33679]
===
match
---
simple_stmt [41358,41388]
simple_stmt [41358,41388]
===
match
---
name: session [52698,52705]
name: session [52698,52705]
===
match
---
trailer [66581,66583]
trailer [66581,66583]
===
match
---
atom_expr [9033,9198]
atom_expr [9033,9198]
===
match
---
testlist_star_expr [27893,27904]
testlist_star_expr [27893,27904]
===
match
---
atom_expr [19157,19174]
atom_expr [19157,19174]
===
match
---
decorated [68930,71366]
decorated [68930,71366]
===
match
---
string: "test force_fail handling" [63374,63400]
string: "test force_fail handling" [63374,63400]
===
match
---
operator: == [35119,35121]
operator: == [35119,35121]
===
match
---
argument [5783,5797]
argument [5783,5797]
===
match
---
suite [43936,44446]
suite [43936,44446]
===
match
---
name: environ [65129,65136]
name: environ [65129,65136]
===
match
---
operator: = [64694,64695]
operator: = [64694,64695]
===
match
---
argument [48264,48285]
argument [48264,48285]
===
match
---
exprlist [52584,52594]
exprlist [52584,52594]
===
match
---
operator: , [53012,53013]
operator: , [53012,53013]
===
match
---
operator: , [67355,67356]
operator: , [67355,67356]
===
match
---
atom_expr [2828,2847]
atom_expr [2828,2847]
===
match
---
name: bash_command [18757,18769]
name: bash_command [18757,18769]
===
match
---
parameters [24074,24080]
parameters [24074,24080]
===
match
---
operator: == [21238,21240]
operator: == [21238,21240]
===
match
---
trailer [6069,6078]
trailer [6069,6078]
===
match
---
name: generate_command [67557,67573]
name: generate_command [67557,67573]
===
match
---
trailer [37212,37222]
trailer [37212,37222]
===
match
---
simple_stmt [62729,62777]
simple_stmt [62729,62777]
===
match
---
arglist [11261,11464]
arglist [11261,11464]
===
match
---
operator: = [5003,5004]
operator: = [5003,5004]
===
match
---
trailer [54201,54204]
trailer [54201,54204]
===
match
---
argument [13182,13231]
argument [13182,13231]
===
match
---
name: execution_date [80223,80237]
name: execution_date [80223,80237]
===
match
---
name: owner [8599,8604]
name: owner [8599,8604]
===
match
---
atom_expr [77187,77194]
atom_expr [77187,77194]
===
match
---
trailer [62578,62585]
trailer [62578,62585]
===
match
---
operator: , [72991,72992]
operator: , [72991,72992]
===
match
---
simple_stmt [2590,2641]
simple_stmt [2590,2641]
===
match
---
operator: = [40439,40440]
operator: = [40439,40440]
===
match
---
number: 1 [4592,4593]
number: 1 [4592,4593]
===
match
---
atom_expr [58725,58750]
atom_expr [58725,58750]
===
match
---
simple_stmt [68717,68755]
simple_stmt [68717,68755]
===
match
---
string: 'True' [69873,69879]
string: 'True' [69873,69879]
===
match
---
atom_expr [79542,79586]
atom_expr [79542,79586]
===
match
---
trailer [19740,19744]
trailer [19740,19744]
===
match
---
trailer [37162,37200]
trailer [37162,37200]
===
match
---
argument [16389,16399]
argument [16389,16399]
===
match
---
name: Stats [66214,66219]
name: Stats [66214,66219]
===
match
---
trailer [34630,34640]
trailer [34630,34640]
===
match
---
assert_stmt [7346,7368]
assert_stmt [7346,7368]
===
match
---
name: ti [76480,76482]
name: ti [76480,76482]
===
match
---
simple_stmt [44997,45047]
simple_stmt [44997,45047]
===
match
---
operator: , [14344,14345]
operator: , [14344,14345]
===
match
---
atom_expr [34604,34619]
atom_expr [34604,34619]
===
match
---
name: MagicMock [63006,63015]
name: MagicMock [63006,63015]
===
match
---
operator: , [32038,32039]
operator: , [32038,32039]
===
match
---
testlist_comp [55172,55228]
testlist_comp [55172,55228]
===
match
---
operator: = [10367,10368]
operator: = [10367,10368]
===
match
---
operator: , [6086,6087]
operator: , [6086,6087]
===
match
---
name: failed [34037,34043]
name: failed [34037,34043]
===
match
---
simple_stmt [44353,44379]
simple_stmt [44353,44379]
===
match
---
expr_stmt [66452,66499]
expr_stmt [66452,66499]
===
match
---
name: NONE [10213,10217]
name: NONE [10213,10217]
===
match
---
name: AirflowFailException [1220,1240]
name: AirflowFailException [1220,1240]
===
match
---
name: self [3027,3031]
name: self [3027,3031]
===
match
---
number: 0 [33859,33860]
number: 0 [33859,33860]
===
match
---
argument [40028,40046]
argument [40028,40046]
===
match
---
name: DagRun [47912,47918]
name: DagRun [47912,47918]
===
match
---
trailer [37476,37500]
trailer [37476,37500]
===
match
---
name: task [56731,56735]
name: task [56731,56735]
===
match
---
trailer [45106,45113]
trailer [45106,45113]
===
match
---
atom_expr [21258,21271]
atom_expr [21258,21271]
===
match
---
trailer [65534,65544]
trailer [65534,65544]
===
match
---
simple_stmt [58475,58547]
simple_stmt [58475,58547]
===
match
---
simple_stmt [48549,48570]
simple_stmt [48549,48570]
===
match
---
name: state [19261,19266]
name: state [19261,19266]
===
match
---
name: strict_parsing [46818,46832]
name: strict_parsing [46818,46832]
===
match
---
name: task [49889,49893]
name: task [49889,49893]
===
match
---
trailer [11046,11103]
trailer [11046,11103]
===
match
---
param [29113,29128]
param [29113,29128]
===
match
---
operator: , [33684,33685]
operator: , [33684,33685]
===
match
---
operator: = [66455,66456]
operator: = [66455,66456]
===
match
---
name: get_task_instance [75349,75366]
name: get_task_instance [75349,75366]
===
match
---
fstring [11910,11975]
fstring [11910,11975]
===
match
---
operator: , [18877,18878]
operator: , [18877,18878]
===
match
---
operator: , [57184,57185]
operator: , [57184,57185]
===
match
---
atom_expr [19351,19364]
atom_expr [19351,19364]
===
match
---
trailer [59727,59767]
trailer [59727,59767]
===
match
---
argument [7425,7448]
argument [7425,7448]
===
match
---
argument [14910,14922]
argument [14910,14922]
===
match
---
operator: } [67104,67105]
operator: } [67104,67105]
===
match
---
trailer [63373,63418]
trailer [63373,63418]
===
match
---
operator: , [57372,57373]
operator: , [57372,57373]
===
match
---
name: content [59418,59425]
name: content [59418,59425]
===
match
---
number: 3 [27971,27972]
number: 3 [27971,27972]
===
match
---
number: 0 [31907,31908]
number: 0 [31907,31908]
===
match
---
comparison [22437,22451]
comparison [22437,22451]
===
match
---
atom_expr [25117,25137]
atom_expr [25117,25137]
===
match
---
simple_stmt [8805,8839]
simple_stmt [8805,8839]
===
match
---
name: task_id [18019,18026]
name: task_id [18019,18026]
===
match
---
name: QUEUED [12410,12416]
name: QUEUED [12410,12416]
===
match
---
name: SCHEDULED [15881,15890]
name: SCHEDULED [15881,15890]
===
match
---
argument [51136,51165]
argument [51136,51165]
===
match
---
name: start_date [56823,56833]
name: start_date [56823,56833]
===
match
---
atom [54490,54548]
atom [54490,54548]
===
match
---
operator: , [33382,33383]
operator: , [33382,33383]
===
match
---
operator: = [16317,16318]
operator: = [16317,16318]
===
match
---
trailer [74972,74996]
trailer [74972,74996]
===
match
---
param [50176,50180]
param [50176,50180]
===
match
---
trailer [46765,46786]
trailer [46765,46786]
===
match
---
argument [73694,73717]
argument [73694,73717]
===
match
---
name: mock_on_failure_3 [62938,62955]
name: mock_on_failure_3 [62938,62955]
===
match
---
simple_stmt [35042,35093]
simple_stmt [35042,35093]
===
match
---
name: owner [37129,37134]
name: owner [37129,37134]
===
match
---
operator: , [72144,72145]
operator: , [72144,72145]
===
match
---
trailer [15754,15768]
trailer [15754,15768]
===
match
---
operator: = [5389,5390]
operator: = [5389,5390]
===
match
---
trailer [19496,19507]
trailer [19496,19507]
===
match
---
argument [42818,42850]
argument [42818,42850]
===
match
---
name: pendulum [46512,46520]
name: pendulum [46512,46520]
===
match
---
name: RUNNING [25087,25094]
name: RUNNING [25087,25094]
===
match
---
simple_stmt [78376,78435]
simple_stmt [78376,78435]
===
match
---
name: State [31916,31921]
name: State [31916,31921]
===
match
---
name: ti [16490,16492]
name: ti [16490,16492]
===
match
---
suite [24081,27977]
suite [24081,27977]
===
match
---
operator: , [33675,33676]
operator: , [33675,33676]
===
match
---
operator: , [31037,31038]
operator: , [31037,31038]
===
match
---
operator: , [70009,70010]
operator: , [70009,70010]
===
match
---
name: scheduler_job [74534,74547]
name: scheduler_job [74534,74547]
===
match
---
operator: = [28833,28834]
operator: = [28833,28834]
===
match
---
atom_expr [3070,3088]
atom_expr [3070,3088]
===
match
---
name: State [34157,34162]
name: State [34157,34162]
===
match
---
name: session [16597,16604]
name: session [16597,16604]
===
match
---
atom [47874,47893]
atom [47874,47893]
===
match
---
string: 'op1' [69502,69507]
string: 'op1' [69502,69507]
===
match
---
trailer [23815,23824]
trailer [23815,23824]
===
match
---
operator: = [53072,53073]
operator: = [53072,53073]
===
match
---
string: 'template: test_email_alert_with_config' [49645,49685]
string: 'template: test_email_alert_with_config' [49645,49685]
===
match
---
name: UP_FOR_RESCHEDULE [26996,27013]
name: UP_FOR_RESCHEDULE [26996,27013]
===
match
---
name: dag2 [7458,7462]
name: dag2 [7458,7462]
===
match
---
name: MANUAL [56431,56437]
name: MANUAL [56431,56437]
===
match
---
operator: , [50064,50065]
operator: , [50064,50065]
===
match
---
expr_stmt [44772,44844]
expr_stmt [44772,44844]
===
match
---
name: dag [48255,48258]
name: dag [48255,48258]
===
match
---
name: test_run_pooling_task_with_mark_success [16787,16826]
name: test_run_pooling_task_with_mark_success [16787,16826]
===
match
---
trailer [7297,7301]
trailer [7297,7301]
===
match
---
name: db [77843,77845]
name: db [77843,77845]
===
match
---
atom_expr [15119,15150]
atom_expr [15119,15150]
===
match
---
trailer [75381,75389]
trailer [75381,75389]
===
match
---
operator: = [74331,74332]
operator: = [74331,74332]
===
match
---
name: query [71323,71328]
name: query [71323,71328]
===
match
---
trailer [30994,30998]
trailer [30994,30998]
===
match
---
atom_expr [61902,61914]
atom_expr [61902,61914]
===
match
---
name: date [52646,52650]
name: date [52646,52650]
===
match
---
comparison [5268,5325]
comparison [5268,5325]
===
match
---
name: State [38921,38926]
name: State [38921,38926]
===
match
---
operator: = [73971,73972]
operator: = [73971,73972]
===
match
---
trailer [38926,38934]
trailer [38926,38934]
===
match
---
operator: , [31914,31915]
operator: , [31914,31915]
===
match
---
operator: = [62200,62201]
operator: = [62200,62201]
===
match
---
atom_expr [70712,70728]
atom_expr [70712,70728]
===
match
---
name: dag [37374,37377]
name: dag [37374,37377]
===
match
---
name: validate_ti_states [75575,75593]
name: validate_ti_states [75575,75593]
===
match
---
operator: == [20880,20882]
operator: == [20880,20882]
===
match
---
simple_stmt [12364,12373]
simple_stmt [12364,12373]
===
match
---
name: refresh_from_db [61275,61290]
name: refresh_from_db [61275,61290]
===
match
---
simple_stmt [23031,23050]
simple_stmt [23031,23050]
===
match
---
trailer [61000,61162]
trailer [61000,61162]
===
match
---
string: 'B' [72324,72327]
string: 'B' [72324,72327]
===
match
---
simple_stmt [31322,31355]
simple_stmt [31322,31355]
===
match
---
string: 'test fail reason' [35442,35460]
string: 'test fail reason' [35442,35460]
===
match
---
name: error_message [73552,73565]
name: error_message [73552,73565]
===
match
---
name: dag_id [10300,10306]
name: dag_id [10300,10306]
===
match
---
name: task [52269,52273]
name: task [52269,52273]
===
match
---
operator: , [55884,55885]
operator: , [55884,55885]
===
match
---
simple_stmt [61620,61826]
simple_stmt [61620,61826]
===
match
---
simple_stmt [52469,52545]
simple_stmt [52469,52545]
===
match
---
name: task [23745,23749]
name: task [23745,23749]
===
match
---
atom [36125,36144]
atom [36125,36144]
===
match
---
operator: = [13127,13128]
operator: = [13127,13128]
===
match
---
expr_stmt [71007,71080]
expr_stmt [71007,71080]
===
match
---
name: self [64351,64355]
name: self [64351,64355]
===
match
---
simple_stmt [21411,21438]
simple_stmt [21411,21438]
===
match
---
atom_expr [21487,21538]
atom_expr [21487,21538]
===
match
---
operator: = [60953,60954]
operator: = [60953,60954]
===
match
---
operator: = [15626,15627]
operator: = [15626,15627]
===
match
---
name: DagRunType [25117,25127]
name: DagRunType [25117,25127]
===
match
---
name: session [68853,68860]
name: session [68853,68860]
===
match
---
operator: , [32313,32314]
operator: , [32313,32314]
===
match
---
name: task_id [21795,21802]
name: task_id [21795,21802]
===
match
---
name: ti [29626,29628]
name: ti [29626,29628]
===
match
---
argument [47504,47542]
argument [47504,47542]
===
match
---
name: task [58234,58238]
name: task [58234,58238]
===
match
---
simple_stmt [58326,58374]
simple_stmt [58326,58374]
===
match
---
simple_stmt [77964,77978]
simple_stmt [77964,77978]
===
match
---
name: task [68783,68787]
name: task [68783,68787]
===
match
---
arglist [16475,16613]
arglist [16475,16613]
===
match
---
name: task [77237,77241]
name: task [77237,77241]
===
match
---
dictorsetmaker [15585,15597]
dictorsetmaker [15585,15597]
===
match
---
operator: , [32473,32474]
operator: , [32473,32474]
===
match
---
name: test_requeue_over_pool_concurrency [10227,10261]
name: test_requeue_over_pool_concurrency [10227,10261]
===
match
---
operator: , [57544,57545]
operator: , [57544,57545]
===
match
---
argument [55624,55643]
argument [55624,55643]
===
match
---
simple_stmt [66452,66500]
simple_stmt [66452,66500]
===
match
---
atom_expr [30194,30204]
atom_expr [30194,30204]
===
match
---
operator: = [40797,40798]
operator: = [40797,40798]
===
match
---
arglist [79546,79585]
arglist [79546,79585]
===
match
---
atom [70573,70631]
atom [70573,70631]
===
match
---
name: _run_finished_callback [61979,62001]
name: _run_finished_callback [61979,62001]
===
match
---
operator: , [33361,33362]
operator: , [33361,33362]
===
match
---
parameters [73469,73571]
parameters [73469,73571]
===
match
---
expr_stmt [67303,67319]
expr_stmt [67303,67319]
===
match
---
name: start_date [23668,23678]
name: start_date [23668,23678]
===
match
---
expr_stmt [73955,73985]
expr_stmt [73955,73985]
===
match
---
operator: , [72275,72276]
operator: , [72275,72276]
===
match
---
funcdef [77928,77978]
funcdef [77928,77978]
===
match
---
name: state [55528,55533]
name: state [55528,55533]
===
match
---
name: pool [77203,77207]
name: pool [77203,77207]
===
match
---
number: 960 [22842,22845]
number: 960 [22842,22845]
===
match
---
simple_stmt [38002,38025]
simple_stmt [38002,38025]
===
match
---
trailer [22223,22232]
trailer [22223,22232]
===
match
---
name: start_date [76412,76422]
name: start_date [76412,76422]
===
match
---
trailer [46435,46443]
trailer [46435,46443]
===
match
---
atom [67345,67415]
atom [67345,67415]
===
match
---
suite [58601,58650]
suite [58601,58650]
===
match
---
operator: = [68316,68317]
operator: = [68316,68317]
===
match
---
atom_expr [17548,17568]
atom_expr [17548,17568]
===
match
---
name: start_date [11414,11424]
name: start_date [11414,11424]
===
match
---
name: self [3179,3183]
name: self [3179,3183]
===
match
---
name: seconds [24000,24007]
name: seconds [24000,24007]
===
match
---
atom_expr [52500,52543]
atom_expr [52500,52543]
===
match
---
operator: , [8530,8531]
operator: , [8530,8531]
===
match
---
atom_expr [64962,64970]
atom_expr [64962,64970]
===
match
---
name: ti [22722,22724]
name: ti [22722,22724]
===
match
---
name: DummyOperator [5498,5511]
name: DummyOperator [5498,5511]
===
match
---
expr_stmt [5541,5595]
expr_stmt [5541,5595]
===
match
---
number: 5 [33560,33561]
number: 5 [33560,33561]
===
match
---
name: datetime [49927,49935]
name: datetime [49927,49935]
===
match
---
operator: = [42986,42987]
operator: = [42986,42987]
===
match
---
operator: = [54698,54699]
operator: = [54698,54699]
===
match
---
trailer [2614,2633]
trailer [2614,2633]
===
match
---
number: 0 [18967,18968]
number: 0 [18967,18968]
===
match
---
atom_expr [35398,35461]
atom_expr [35398,35461]
===
match
---
name: dag_run [47326,47333]
name: dag_run [47326,47333]
===
match
---
name: pytest [42866,42872]
name: pytest [42866,42872]
===
match
---
name: create_dagrun [65711,65724]
name: create_dagrun [65711,65724]
===
match
---
operator: = [69132,69133]
operator: = [69132,69133]
===
match
---
simple_stmt [1481,1529]
simple_stmt [1481,1529]
===
match
---
arglist [47806,47855]
arglist [47806,47855]
===
match
---
atom_expr [75939,75974]
atom_expr [75939,75974]
===
match
---
name: environ [65058,65065]
name: environ [65058,65065]
===
match
---
operator: = [35486,35487]
operator: = [35486,35487]
===
match
---
name: freeze_time [1031,1042]
name: freeze_time [1031,1042]
===
match
---
arglist [23697,23716]
arglist [23697,23716]
===
match
---
trailer [57554,57563]
trailer [57554,57563]
===
match
---
atom_expr [22917,22930]
atom_expr [22917,22930]
===
match
---
comparison [48001,48028]
comparison [48001,48028]
===
match
---
atom_expr [78606,78619]
atom_expr [78606,78619]
===
match
---
name: execution_date [60864,60878]
name: execution_date [60864,60878]
===
match
---
name: scenario [53810,53818]
name: scenario [53810,53818]
===
match
---
argument [24693,24702]
argument [24693,24702]
===
match
---
name: run_ti_and_assert [27798,27815]
name: run_ti_and_assert [27798,27815]
===
match
---
string: 'foo' [37839,37844]
string: 'foo' [37839,37844]
===
match
---
trailer [37810,37845]
trailer [37810,37845]
===
match
---
operator: , [31753,31754]
operator: , [31753,31754]
===
match
---
name: task_id [34358,34365]
name: task_id [34358,34365]
===
match
---
trailer [17446,17579]
trailer [17446,17579]
===
match
---
name: ti [79853,79855]
name: ti [79853,79855]
===
match
---
suite [39789,41213]
suite [39789,41213]
===
match
---
name: execution_date [56344,56358]
name: execution_date [56344,56358]
===
match
---
trailer [70786,70790]
trailer [70786,70790]
===
match
---
atom_expr [29463,29471]
atom_expr [29463,29471]
===
match
---
operator: , [61079,61080]
operator: , [61079,61080]
===
match
---
argument [49889,49898]
argument [49889,49898]
===
match
---
arglist [64713,64732]
arglist [64713,64732]
===
match
---
name: state [66807,66812]
name: state [66807,66812]
===
match
---
trailer [21344,21360]
trailer [21344,21360]
===
match
---
string: 'test_xcom' [38572,38583]
string: 'test_xcom' [38572,38583]
===
match
---
operator: == [71230,71232]
operator: == [71230,71232]
===
match
---
atom_expr [17641,17654]
atom_expr [17641,17654]
===
match
---
argument [18174,18223]
argument [18174,18223]
===
match
---
argument [38492,38520]
argument [38492,38520]
===
match
---
name: result [37861,37867]
name: result [37861,37867]
===
match
---
name: db [77730,77732]
name: db [77730,77732]
===
match
---
simple_stmt [25602,25608]
simple_stmt [25602,25608]
===
match
---
atom_expr [22998,23009]
atom_expr [22998,23009]
===
match
---
simple_stmt [68874,68925]
simple_stmt [68874,68925]
===
match
---
argument [68594,68607]
argument [68594,68607]
===
match
---
operator: , [33450,33451]
operator: , [33450,33451]
===
match
---
classdef [42267,42312]
classdef [42267,42312]
===
match
---
string: 'to' [48318,48322]
string: 'to' [48318,48322]
===
match
---
name: task [75423,75427]
name: task [75423,75427]
===
match
---
name: try_number [24973,24983]
name: try_number [24973,24983]
===
match
---
operator: , [1365,1366]
operator: , [1365,1366]
===
match
---
operator: = [51144,51145]
operator: = [51144,51145]
===
match
---
name: task_id [74795,74802]
name: task_id [74795,74802]
===
match
---
name: assert_not_called [63605,63622]
name: assert_not_called [63605,63622]
===
match
---
trailer [27815,27870]
trailer [27815,27870]
===
match
---
atom_expr [18350,18367]
atom_expr [18350,18367]
===
match
---
comparison [48556,48569]
comparison [48556,48569]
===
match
---
atom [73039,73085]
atom [73039,73085]
===
match
---
simple_stmt [79453,79472]
simple_stmt [79453,79472]
===
match
---
number: 2 [32155,32156]
number: 2 [32155,32156]
===
match
---
name: parameterized [57571,57584]
name: parameterized [57571,57584]
===
match
---
atom_expr [3773,3804]
atom_expr [3773,3804]
===
match
---
name: State [53836,53841]
name: State [53836,53841]
===
match
---
expr_stmt [22581,22649]
expr_stmt [22581,22649]
===
match
---
operator: = [68050,68051]
operator: = [68050,68051]
===
match
---
trailer [55658,55669]
trailer [55658,55669]
===
match
---
name: state [54083,54088]
name: state [54083,54088]
===
match
---
operator: , [59737,59738]
operator: , [59737,59738]
===
match
---
operator: @ [66200,66201]
operator: @ [66200,66201]
===
match
---
trailer [65057,65065]
trailer [65057,65065]
===
match
---
atom_expr [57285,57310]
atom_expr [57285,57310]
===
match
---
operator: = [61550,61551]
operator: = [61550,61551]
===
match
---
name: self [2796,2800]
name: self [2796,2800]
===
match
---
name: TI [5838,5840]
name: TI [5838,5840]
===
match
---
expr_stmt [2762,2787]
expr_stmt [2762,2787]
===
match
---
name: DEFAULT_DATE [56007,56019]
name: DEFAULT_DATE [56007,56019]
===
match
---
name: PythonOperator [74033,74047]
name: PythonOperator [74033,74047]
===
match
---
trailer [59695,59710]
trailer [59695,59710]
===
match
---
name: done [29975,29979]
name: done [29975,29979]
===
match
---
suite [70994,71081]
suite [70994,71081]
===
match
---
suite [3893,3918]
suite [3893,3918]
===
match
---
name: DAG [28373,28376]
name: DAG [28373,28376]
===
match
---
trailer [61225,61239]
trailer [61225,61239]
===
match
---
atom_expr [3213,3222]
atom_expr [3213,3222]
===
match
---
name: task_ids [39095,39103]
name: task_ids [39095,39103]
===
match
---
name: add [22406,22409]
name: add [22406,22409]
===
match
---
comparison [25660,25686]
comparison [25660,25686]
===
match
---
name: task [61843,61847]
name: task [61843,61847]
===
match
---
comparison [29566,29606]
comparison [29566,29606]
===
match
---
string: 'op' [47471,47475]
string: 'op' [47471,47475]
===
match
---
name: email [50226,50231]
name: email [50226,50231]
===
match
---
argument [11355,11371]
argument [11355,11371]
===
match
---
name: run [12367,12370]
name: run [12367,12370]
===
match
---
atom_expr [18931,18969]
atom_expr [18931,18969]
===
match
---
name: set_state [36614,36623]
name: set_state [36614,36623]
===
match
---
simple_stmt [64776,64829]
simple_stmt [64776,64829]
===
match
---
name: pool [17239,17243]
name: pool [17239,17243]
===
match
---
string: 'test_xcom_1' [37105,37118]
string: 'test_xcom_1' [37105,37118]
===
match
---
name: SKIPPED [18493,18500]
name: SKIPPED [18493,18500]
===
match
---
trailer [23278,23290]
trailer [23278,23290]
===
match
---
name: task_instance_c [75187,75202]
name: task_instance_c [75187,75202]
===
match
---
atom_expr [19726,19744]
atom_expr [19726,19744]
===
match
---
name: TI [43146,43148]
name: TI [43146,43148]
===
match
---
suite [56917,57565]
suite [56917,57565]
===
match
---
expr_stmt [60033,60068]
expr_stmt [60033,60068]
===
match
---
atom_expr [35281,35335]
atom_expr [35281,35335]
===
match
---
name: state [74717,74722]
name: state [74717,74722]
===
match
---
name: run_ti_and_assert [27571,27588]
name: run_ti_and_assert [27571,27588]
===
match
---
trailer [51043,51205]
trailer [51043,51205]
===
match
---
expr_stmt [11664,11699]
expr_stmt [11664,11699]
===
match
---
name: State [30051,30056]
name: State [30051,30056]
===
match
---
name: set_state [74889,74898]
name: set_state [74889,74898]
===
match
---
operator: - [23982,23983]
operator: - [23982,23983]
===
match
---
name: ti [30146,30148]
name: ti [30146,30148]
===
match
---
arglist [14022,14200]
arglist [14022,14200]
===
match
---
number: 3 [21897,21898]
number: 3 [21897,21898]
===
match
---
name: set [59542,59545]
name: set [59542,59545]
===
match
---
number: 5 [32031,32032]
number: 5 [32031,32032]
===
match
---
name: FAILED [54497,54503]
name: FAILED [54497,54503]
===
match
---
name: task [21762,21766]
name: task [21762,21766]
===
match
---
operator: = [23740,23741]
operator: = [23740,23741]
===
match
---
number: 3 [33108,33109]
number: 3 [33108,33109]
===
match
---
name: expand [58894,58900]
name: expand [58894,58900]
===
match
---
trailer [74622,74641]
trailer [74622,74641]
===
match
---
name: expected_state [29475,29489]
name: expected_state [29475,29489]
===
match
---
name: ti [23113,23115]
name: ti [23113,23115]
===
match
---
name: xcom_push [37213,37222]
name: xcom_push [37213,37222]
===
match
---
operator: , [4594,4595]
operator: , [4594,4595]
===
match
---
name: dag_id [9664,9670]
name: dag_id [9664,9670]
===
match
---
name: ti [29423,29425]
name: ti [29423,29425]
===
match
---
name: result [59883,59889]
name: result [59883,59889]
===
match
---
operator: = [61452,61453]
operator: = [61452,61453]
===
match
---
atom_expr [50028,50039]
atom_expr [50028,50039]
===
match
---
trailer [5810,5819]
trailer [5810,5819]
===
match
---
expr_stmt [16135,16371]
expr_stmt [16135,16371]
===
match
---
operator: , [72429,72430]
operator: , [72429,72430]
===
match
---
trailer [66095,66097]
trailer [66095,66097]
===
match
---
name: execution_date [49263,49277]
name: execution_date [49263,49277]
===
match
---
simple_stmt [42799,42852]
simple_stmt [42799,42852]
===
match
---
arglist [52698,52722]
arglist [52698,52722]
===
match
---
trailer [75815,75834]
trailer [75815,75834]
===
match
---
name: retry_exponential_backoff [21943,21968]
name: retry_exponential_backoff [21943,21968]
===
match
---
name: owner [64655,64660]
name: owner [64655,64660]
===
match
---
name: test_overwrite_params_with_dag_run_conf [47008,47047]
name: test_overwrite_params_with_dag_run_conf [47008,47047]
===
match
---
simple_stmt [62561,62586]
simple_stmt [62561,62586]
===
match
---
argument [6100,6113]
argument [6100,6113]
===
match
---
name: ti [34805,34807]
name: ti [34805,34807]
===
match
---
argument [78395,78433]
argument [78395,78433]
===
match
---
name: patch_dict [12130,12140]
name: patch_dict [12130,12140]
===
match
---
name: DEFAULT_DATE [44831,44843]
name: DEFAULT_DATE [44831,44843]
===
match
---
operator: = [64788,64789]
operator: = [64788,64789]
===
match
---
atom_expr [36600,36644]
atom_expr [36600,36644]
===
match
---
operator: = [18769,18770]
operator: = [18769,18770]
===
match
---
simple_stmt [2137,2203]
simple_stmt [2137,2203]
===
match
---
operator: == [19643,19645]
operator: == [19643,19645]
===
match
---
atom_expr [58070,58112]
atom_expr [58070,58112]
===
match
---
atom_expr [53336,53349]
atom_expr [53336,53349]
===
match
---
name: SUCCESS [53842,53849]
name: SUCCESS [53842,53849]
===
match
---
name: test_overwrite_params_with_dag_run_none [47387,47426]
name: test_overwrite_params_with_dag_run_none [47387,47426]
===
match
---
name: i [34445,34446]
name: i [34445,34446]
===
match
---
parameters [48107,48130]
parameters [48107,48130]
===
match
---
argument [51862,51876]
argument [51862,51876]
===
match
---
atom_expr [65985,65993]
atom_expr [65985,65993]
===
match
---
comparison [77187,77207]
comparison [77187,77207]
===
match
---
name: parameterized [31566,31579]
name: parameterized [31566,31579]
===
match
---
trailer [61408,61420]
trailer [61408,61420]
===
match
---
name: owner [34524,34529]
name: owner [34524,34529]
===
match
---
name: task [64789,64793]
name: task [64789,64793]
===
match
---
trailer [45217,45222]
trailer [45217,45222]
===
match
---
operator: , [32242,32243]
operator: , [32242,32243]
===
match
---
operator: , [68007,68008]
operator: , [68007,68008]
===
match
---
simple_stmt [52558,52567]
simple_stmt [52558,52567]
===
match
---
simple_stmt [22809,22878]
simple_stmt [22809,22878]
===
match
---
assert_stmt [76342,76379]
assert_stmt [76342,76379]
===
match
---
name: owner [28701,28706]
name: owner [28701,28706]
===
match
---
atom_expr [50626,50653]
atom_expr [50626,50653]
===
match
---
operator: = [37967,37968]
operator: = [37967,37968]
===
match
---
expr_stmt [40764,40808]
expr_stmt [40764,40808]
===
match
---
arglist [68321,68359]
arglist [68321,68359]
===
match
---
number: 10 [76800,76802]
number: 10 [76800,76802]
===
match
---
with_item [70712,70739]
with_item [70712,70739]
===
match
---
trailer [76208,76216]
trailer [76208,76216]
===
match
---
operator: , [33299,33300]
operator: , [33299,33300]
===
match
---
expr_stmt [48342,48394]
expr_stmt [48342,48394]
===
match
---
name: serialize_json [59586,59600]
name: serialize_json [59586,59600]
===
match
---
name: ignore_all_deps [39645,39660]
name: ignore_all_deps [39645,39660]
===
match
---
string: 'test_run_pooling_task' [15400,15423]
string: 'test_run_pooling_task' [15400,15423]
===
match
---
name: refresh_from_db [25623,25638]
name: refresh_from_db [25623,25638]
===
match
---
name: DAG [7465,7468]
name: DAG [7465,7468]
===
match
---
operator: , [33737,33738]
operator: , [33737,33738]
===
match
---
atom_expr [31293,31313]
atom_expr [31293,31313]
===
match
---
name: task_c [75159,75165]
name: task_c [75159,75165]
===
match
---
trailer [3313,3317]
trailer [3313,3317]
===
match
---
argument [10300,10343]
argument [10300,10343]
===
match
---
atom_expr [54534,54547]
atom_expr [54534,54547]
===
match
---
operator: = [46657,46658]
operator: = [46657,46658]
===
match
---
return_stmt [52386,52395]
return_stmt [52386,52395]
===
match
---
operator: , [53957,53958]
operator: , [53957,53958]
===
match
---
name: unittest [3413,3421]
name: unittest [3413,3421]
===
match
---
trailer [38696,38705]
trailer [38696,38705]
===
match
---
trailer [66907,66914]
trailer [66907,66914]
===
match
---
name: ti [21158,21160]
name: ti [21158,21160]
===
match
---
argument [37120,37127]
argument [37120,37127]
===
match
---
trailer [20948,20959]
trailer [20948,20959]
===
match
---
atom_expr [37337,37399]
atom_expr [37337,37399]
===
match
---
argument [60819,60826]
argument [60819,60826]
===
match
---
name: session [16647,16654]
name: session [16647,16654]
===
match
---
comparison [26085,26127]
comparison [26085,26127]
===
match
---
string: "test_get_previous_start_date_none" [55849,55884]
string: "test_get_previous_start_date_none" [55849,55884]
===
match
---
argument [28680,28687]
argument [28680,28687]
===
match
---
operator: , [19280,19281]
operator: , [19280,19281]
===
match
---
name: start_date [58143,58153]
name: start_date [58143,58153]
===
match
---
name: generate_command [67446,67462]
name: generate_command [67446,67462]
===
match
---
name: _prev_dates_param_list [55040,55062]
name: _prev_dates_param_list [55040,55062]
===
match
---
name: DEFAULT_DATE [65175,65187]
name: DEFAULT_DATE [65175,65187]
===
match
---
name: add [45164,45167]
name: add [45164,45167]
===
match
---
suite [53800,54328]
suite [53800,54328]
===
match
---
simple_stmt [44911,44989]
simple_stmt [44911,44989]
===
match
---
operator: , [7690,7691]
operator: , [7690,7691]
===
match
---
name: ti [47930,47932]
name: ti [47930,47932]
===
match
---
name: DEFAULT_DATE [4553,4565]
name: DEFAULT_DATE [4553,4565]
===
match
---
name: DummyOperator [57127,57140]
name: DummyOperator [57127,57140]
===
match
---
operator: , [79268,79269]
operator: , [79268,79269]
===
match
---
trailer [16461,16623]
trailer [16461,16623]
===
match
---
name: parameterized [1048,1061]
name: parameterized [1048,1061]
===
match
---
operator: , [32094,32095]
operator: , [32094,32095]
===
match
---
name: run_ti_and_assert [27686,27703]
name: run_ti_and_assert [27686,27703]
===
match
---
funcdef [17841,17908]
funcdef [17841,17908]
===
match
---
operator: = [13254,13255]
operator: = [13254,13255]
===
match
---
name: UPSTREAM_FAILED [32698,32713]
name: UPSTREAM_FAILED [32698,32713]
===
match
---
param [53249,53267]
param [53249,53267]
===
match
---
operator: = [2775,2776]
operator: = [2775,2776]
===
match
---
name: ti [35154,35156]
name: ti [35154,35156]
===
match
---
trailer [40329,40331]
trailer [40329,40331]
===
match
---
argument [38948,38977]
argument [38948,38977]
===
match
---
operator: = [48345,48346]
operator: = [48345,48346]
===
match
---
operator: = [49806,49807]
operator: = [49806,49807]
===
match
---
operator: , [879,880]
operator: , [879,880]
===
match
---
atom_expr [8777,8796]
atom_expr [8777,8796]
===
match
---
name: execution_date [58678,58692]
name: execution_date [58678,58692]
===
match
---
simple_stmt [17984,18235]
simple_stmt [17984,18235]
===
match
---
operator: , [66730,66731]
operator: , [66730,66731]
===
match
---
expr_stmt [3027,3051]
expr_stmt [3027,3051]
===
match
---
name: bash_command [23446,23458]
name: bash_command [23446,23458]
===
match
---
arglist [56500,56594]
arglist [56500,56594]
===
match
---
operator: = [60005,60006]
operator: = [60005,60006]
===
match
---
operator: = [44211,44212]
operator: = [44211,44212]
===
match
---
arglist [25029,25138]
arglist [25029,25138]
===
match
---
expr_stmt [61378,61420]
expr_stmt [61378,61420]
===
match
---
operator: = [14880,14881]
operator: = [14880,14881]
===
match
---
simple_stmt [22487,22519]
simple_stmt [22487,22519]
===
match
---
simple_stmt [49703,49759]
simple_stmt [49703,49759]
===
match
---
name: State [71950,71955]
name: State [71950,71955]
===
match
---
trailer [45447,45464]
trailer [45447,45464]
===
match
---
trailer [12918,12920]
trailer [12918,12920]
===
match
---
atom_expr [29734,29745]
atom_expr [29734,29745]
===
match
---
name: new_ti [68653,68659]
name: new_ti [68653,68659]
===
match
---
operator: = [41878,41879]
operator: = [41878,41879]
===
match
---
trailer [17477,17492]
trailer [17477,17492]
===
match
---
name: params [47552,47558]
name: params [47552,47558]
===
match
---
operator: , [65299,65300]
operator: , [65299,65300]
===
match
---
arglist [74048,74092]
arglist [74048,74092]
===
match
---
trailer [51228,51230]
trailer [51228,51230]
===
match
---
param [73479,73484]
param [73479,73484]
===
match
---
import_from [2390,2447]
import_from [2390,2447]
===
match
---
operator: , [42775,42776]
operator: , [42775,42776]
===
match
---
name: task [68665,68669]
name: task [68665,68669]
===
match
---
operator: , [56553,56554]
operator: , [56553,56554]
===
match
---
operator: , [57711,57712]
operator: , [57711,57712]
===
match
---
string: "A -> B -> C, with fast-follow ON when A runs, B should be QUEUED. Same for B and C." [72059,72144]
string: "A -> B -> C, with fast-follow ON when A runs, B should be QUEUED. Same for B and C." [72059,72144]
===
match
---
string: 'test_echo_env_variables' [65426,65451]
string: 'test_echo_env_variables' [65426,65451]
===
match
---
trailer [22409,22421]
trailer [22409,22421]
===
match
---
atom_expr [61975,62003]
atom_expr [61975,62003]
===
match
---
argument [63275,63285]
argument [63275,63285]
===
match
---
dictorsetmaker [72711,72779]
dictorsetmaker [72711,72779]
===
match
---
trailer [53605,53608]
trailer [53605,53608]
===
match
---
dictorsetmaker [47252,47269]
dictorsetmaker [47252,47269]
===
match
---
dictorsetmaker [73224,73289]
dictorsetmaker [73224,73289]
===
match
---
arglist [8429,8459]
arglist [8429,8459]
===
match
---
argument [43083,43097]
argument [43083,43097]
===
match
---
operator: = [64034,64035]
operator: = [64034,64035]
===
match
---
atom_expr [32452,32473]
atom_expr [32452,32473]
===
match
---
name: timezone [18185,18193]
name: timezone [18185,18193]
===
match
---
name: raises [58771,58777]
name: raises [58771,58777]
===
match
---
try_stmt [25470,25608]
try_stmt [25470,25608]
===
match
---
name: add [22376,22379]
name: add [22376,22379]
===
match
---
operator: = [55928,55929]
operator: = [55928,55929]
===
match
---
operator: = [23488,23489]
operator: = [23488,23489]
===
match
---
operator: , [24884,24885]
operator: , [24884,24885]
===
match
---
atom_expr [68717,68754]
atom_expr [68717,68754]
===
match
---
name: task1 [37168,37173]
name: task1 [37168,37173]
===
match
---
expr_stmt [37543,37567]
expr_stmt [37543,37567]
===
match
---
name: mock [61552,61556]
name: mock [61552,61556]
===
match
---
atom_expr [5226,5252]
atom_expr [5226,5252]
===
match
---
operator: = [37226,37227]
operator: = [37226,37227]
===
match
---
atom_expr [2796,2807]
atom_expr [2796,2807]
===
match
---
name: State [41879,41884]
name: State [41879,41884]
===
match
---
operator: + [23010,23011]
operator: + [23010,23011]
===
match
---
except_clause [19068,19091]
except_clause [19068,19091]
===
match
---
fstring_expr [67023,67035]
fstring_expr [67023,67035]
===
match
---
name: bool [34129,34133]
name: bool [34129,34133]
===
match
---
atom_expr [63481,63514]
atom_expr [63481,63514]
===
match
---
name: datetime [47519,47527]
name: datetime [47519,47527]
===
match
---
name: op1 [4380,4383]
name: op1 [4380,4383]
===
match
---
arith_expr [34604,34648]
arith_expr [34604,34648]
===
match
---
trailer [22241,22248]
trailer [22241,22248]
===
match
---
atom_expr [56726,56735]
atom_expr [56726,56735]
===
match
---
atom [70086,70686]
atom [70086,70686]
===
match
---
argument [48312,48322]
argument [48312,48322]
===
match
---
suite [24301,24388]
suite [24301,24388]
===
match
---
operator: = [15833,15834]
operator: = [15833,15834]
===
match
---
operator: == [10945,10947]
operator: == [10945,10947]
===
match
---
operator: , [29204,29205]
operator: , [29204,29205]
===
match
---
operator: = [73623,73624]
operator: = [73623,73624]
===
match
---
expr_stmt [12429,12501]
expr_stmt [12429,12501]
===
match
---
name: DagRun [65259,65265]
name: DagRun [65259,65265]
===
match
---
expr_stmt [6123,6173]
expr_stmt [6123,6173]
===
match
---
atom_expr [25620,25640]
atom_expr [25620,25640]
===
match
---
name: ti [43424,43426]
name: ti [43424,43426]
===
match
---
operator: = [37335,37336]
operator: = [37335,37336]
===
match
---
argument [63061,63104]
argument [63061,63104]
===
match
---
name: session [70732,70739]
name: session [70732,70739]
===
match
---
operator: = [47249,47250]
operator: = [47249,47250]
===
match
---
trailer [65724,65922]
trailer [65724,65922]
===
match
---
argument [74795,74817]
argument [74795,74817]
===
match
---
import_from [1009,1042]
import_from [1009,1042]
===
match
---
dotted_name [71657,71677]
dotted_name [71657,71677]
===
match
---
name: execution_date [5901,5915]
name: execution_date [5901,5915]
===
match
---
param [11015,11019]
param [11015,11019]
===
match
---
trailer [6859,6889]
trailer [6859,6889]
===
match
---
operator: = [55247,55248]
operator: = [55247,55248]
===
match
---
name: ti [47590,47592]
name: ti [47590,47592]
===
match
---
simple_stmt [49035,49235]
simple_stmt [49035,49235]
===
match
---
expr_stmt [23202,23239]
expr_stmt [23202,23239]
===
match
---
number: 1 [32220,32221]
number: 1 [32220,32221]
===
match
---
comparison [22665,22679]
comparison [22665,22679]
===
match
---
name: timezone [61391,61399]
name: timezone [61391,61399]
===
match
---
operator: = [37480,37481]
operator: = [37480,37481]
===
match
---
simple_stmt [3691,3707]
simple_stmt [3691,3707]
===
match
---
comparison [44267,44285]
comparison [44267,44285]
===
match
---
name: task_id [6424,6431]
name: task_id [6424,6431]
===
match
---
simple_stmt [18554,18615]
simple_stmt [18554,18615]
===
match
---
name: dag [9641,9644]
name: dag [9641,9644]
===
match
---
string: 'fail_dag' [23324,23334]
string: 'fail_dag' [23324,23334]
===
match
---
operator: = [28734,28735]
operator: = [28734,28735]
===
match
---
name: QUEUED [9359,9365]
name: QUEUED [9359,9365]
===
match
---
dictorsetmaker [59567,59582]
dictorsetmaker [59567,59582]
===
match
---
operator: , [33457,33458]
operator: , [33457,33458]
===
match
---
name: start_date [31210,31220]
name: start_date [31210,31220]
===
match
---
operator: = [14399,14400]
operator: = [14399,14400]
===
match
---
operator: = [50838,50839]
operator: = [50838,50839]
===
match
---
name: value [39054,39059]
name: value [39054,39059]
===
match
---
simple_stmt [75107,75175]
simple_stmt [75107,75175]
===
match
---
operator: == [17638,17640]
operator: == [17638,17640]
===
match
---
string: 'True' [72637,72643]
string: 'True' [72637,72643]
===
match
---
trailer [56586,56593]
trailer [56586,56593]
===
match
---
number: 0 [9918,9919]
number: 0 [9918,9919]
===
match
---
name: dag [37120,37123]
name: dag [37120,37123]
===
match
---
atom_expr [64284,64296]
atom_expr [64284,64296]
===
match
---
expr_stmt [74929,74996]
expr_stmt [74929,74996]
===
match
---
arglist [57338,57391]
arglist [57338,57391]
===
match
---
operator: , [61746,61747]
operator: , [61746,61747]
===
match
---
atom_expr [25660,25668]
atom_expr [25660,25668]
===
match
---
name: start_date [52170,52180]
name: start_date [52170,52180]
===
match
---
trailer [22248,22250]
trailer [22248,22250]
===
match
---
operator: = [69099,69100]
operator: = [69099,69100]
===
match
---
operator: = [41574,41575]
operator: = [41574,41575]
===
match
---
simple_stmt [75773,75795]
simple_stmt [75773,75795]
===
match
---
atom_expr [50493,50664]
atom_expr [50493,50664]
===
match
---
operator: = [64660,64661]
operator: = [64660,64661]
===
match
---
expr_stmt [15972,16002]
expr_stmt [15972,16002]
===
match
---
expr_stmt [23058,23089]
expr_stmt [23058,23089]
===
match
---
name: op1 [6195,6198]
name: op1 [6195,6198]
===
match
---
operator: = [51869,51870]
operator: = [51869,51870]
===
match
---
name: TI [20538,20540]
name: TI [20538,20540]
===
match
---
trailer [63274,63313]
trailer [63274,63313]
===
match
---
simple_stmt [24019,24041]
simple_stmt [24019,24041]
===
match
---
operator: , [76774,76775]
operator: , [76774,76775]
===
match
---
trailer [2812,2819]
trailer [2812,2819]
===
match
---
simple_stmt [10832,10847]
simple_stmt [10832,10847]
===
match
---
name: ti2 [37408,37411]
name: ti2 [37408,37411]
===
match
---
trailer [79834,79836]
trailer [79834,79836]
===
match
---
name: os [68947,68949]
name: os [68947,68949]
===
match
---
name: create_session [13404,13418]
name: create_session [13404,13418]
===
match
---
name: task_ids [39533,39541]
name: task_ids [39533,39541]
===
match
---
argument [39645,39665]
argument [39645,39665]
===
match
---
operator: = [52180,52181]
operator: = [52180,52181]
===
match
---
operator: = [37819,37820]
operator: = [37819,37820]
===
match
---
operator: = [36918,36919]
operator: = [36918,36919]
===
match
---
name: fail [27543,27547]
name: fail [27543,27547]
===
match
---
trailer [36971,36992]
trailer [36971,36992]
===
match
---
atom_expr [30220,30234]
atom_expr [30220,30234]
===
match
---
name: UP_FOR_RETRY [19466,19478]
name: UP_FOR_RETRY [19466,19478]
===
match
---
name: dag [10532,10535]
name: dag [10532,10535]
===
match
---
simple_stmt [64277,64309]
simple_stmt [64277,64309]
===
match
---
simple_stmt [37936,37994]
simple_stmt [37936,37994]
===
match
---
simple_stmt [79201,79401]
simple_stmt [79201,79401]
===
match
---
trailer [54830,54858]
trailer [54830,54858]
===
match
---
name: task [20065,20069]
name: task [20065,20069]
===
match
---
name: execution_date [68009,68023]
name: execution_date [68009,68023]
===
match
---
atom_expr [39638,39666]
atom_expr [39638,39666]
===
match
---
operator: = [34708,34709]
operator: = [34708,34709]
===
match
---
name: DagRunType [14400,14410]
name: DagRunType [14400,14410]
===
match
---
name: execution_date [54894,54908]
name: execution_date [54894,54908]
===
match
---
name: query [10769,10774]
name: query [10769,10774]
===
match
---
trailer [73939,73941]
trailer [73939,73941]
===
match
---
name: bool [34190,34194]
name: bool [34190,34194]
===
match
---
argument [44141,44155]
argument [44141,44155]
===
match
---
atom_expr [68516,68556]
atom_expr [68516,68556]
===
match
---
expr_stmt [59675,59710]
expr_stmt [59675,59710]
===
match
---
name: utils [2216,2221]
name: utils [2216,2221]
===
match
---
operator: = [50575,50576]
operator: = [50575,50576]
===
match
---
simple_stmt [4455,4671]
simple_stmt [4455,4671]
===
match
---
string: 'one_success' [32336,32349]
string: 'one_success' [32336,32349]
===
match
---
atom_expr [41728,41787]
atom_expr [41728,41787]
===
match
---
name: State [62573,62578]
name: State [62573,62578]
===
match
---
funcdef [2720,2943]
funcdef [2720,2943]
===
match
---
trailer [22375,22379]
trailer [22375,22379]
===
match
---
param [55114,55132]
param [55114,55132]
===
match
---
atom_expr [74033,74093]
atom_expr [74033,74093]
===
match
---
name: op3 [5193,5196]
name: op3 [5193,5196]
===
match
---
trailer [50030,50039]
trailer [50030,50039]
===
match
---
name: self [18539,18543]
name: self [18539,18543]
===
match
---
atom_expr [59786,59811]
atom_expr [59786,59811]
===
match
---
name: ti [9930,9932]
name: ti [9930,9932]
===
match
---
name: _try_number [20748,20759]
name: _try_number [20748,20759]
===
match
---
name: dag [10528,10531]
name: dag [10528,10531]
===
match
---
atom_expr [25081,25094]
atom_expr [25081,25094]
===
match
---
simple_stmt [34211,34263]
simple_stmt [34211,34263]
===
match
---
name: test_success_callback_no_race_condition [50387,50426]
name: test_success_callback_no_race_condition [50387,50426]
===
match
---
operator: , [27950,27951]
operator: , [27950,27951]
===
match
---
operator: , [33174,33175]
operator: , [33174,33175]
===
match
---
name: TI [11488,11490]
name: TI [11488,11490]
===
match
---
operator: , [10380,10381]
operator: , [10380,10381]
===
match
---
operator: , [32595,32596]
operator: , [32595,32596]
===
match
---
name: task [76652,76656]
name: task [76652,76656]
===
match
---
comparison [4220,4242]
comparison [4220,4242]
===
match
---
testlist_comp [7841,7859]
testlist_comp [7841,7859]
===
match
---
expr_stmt [9027,9198]
expr_stmt [9027,9198]
===
match
---
name: init_state [73505,73515]
name: init_state [73505,73515]
===
match
---
assert_stmt [43849,43904]
assert_stmt [43849,43904]
===
match
---
name: op3 [7637,7640]
name: op3 [7637,7640]
===
match
---
name: get_previous_execution_date [54748,54775]
name: get_previous_execution_date [54748,54775]
===
match
---
expr_stmt [56028,56077]
expr_stmt [56028,56077]
===
match
---
trailer [20026,20056]
trailer [20026,20056]
===
match
---
name: RUNNING [65868,65875]
name: RUNNING [65868,65875]
===
match
---
string: 'test_success_callback_no_race_condition' [50510,50551]
string: 'test_success_callback_no_race_condition' [50510,50551]
===
match
---
string: 'test_retry_handling' [18647,18668]
string: 'test_retry_handling' [18647,18668]
===
match
---
trailer [49293,49295]
trailer [49293,49295]
===
match
---
operator: , [32056,32057]
operator: , [32056,32057]
===
match
---
name: models [28366,28372]
name: models [28366,28372]
===
match
---
name: DEFAULT_DATE [4617,4629]
name: DEFAULT_DATE [4617,4629]
===
match
---
string: 'email' [48786,48793]
string: 'email' [48786,48793]
===
match
---
name: find_for_task_instance [29800,29822]
name: find_for_task_instance [29800,29822]
===
match
---
name: RUNNING_DEPS [11675,11687]
name: RUNNING_DEPS [11675,11687]
===
match
---
funcdef [42369,42508]
funcdef [42369,42508]
===
match
---
with_stmt [58759,58874]
with_stmt [58759,58874]
===
match
---
fstring_expr [67036,67048]
fstring_expr [67036,67048]
===
match
---
trailer [15001,15022]
trailer [15001,15022]
===
match
---
trailer [6015,6035]
trailer [6015,6035]
===
match
---
expr_stmt [66804,66828]
expr_stmt [66804,66828]
===
match
---
expr_stmt [10458,10556]
expr_stmt [10458,10556]
===
match
---
simple_stmt [17367,17420]
simple_stmt [17367,17420]
===
match
---
number: 0 [32279,32280]
number: 0 [32279,32280]
===
match
---
name: run [10915,10918]
name: run [10915,10918]
===
match
---
operator: , [33493,33494]
operator: , [33493,33494]
===
match
---
atom_expr [66815,66828]
atom_expr [66815,66828]
===
match
---
trailer [32777,32793]
trailer [32777,32793]
===
match
---
atom_expr [41674,41703]
atom_expr [41674,41703]
===
match
---
name: dag_id [51708,51714]
name: dag_id [51708,51714]
===
match
---
argument [67992,68007]
argument [67992,68007]
===
match
---
argument [55528,55547]
argument [55528,55547]
===
match
---
operator: , [31905,31906]
operator: , [31905,31906]
===
match
---
operator: , [73692,73693]
operator: , [73692,73693]
===
match
---
atom_expr [66847,66865]
atom_expr [66847,66865]
===
match
---
atom_expr [22818,22846]
atom_expr [22818,22846]
===
match
---
atom_expr [46195,46224]
atom_expr [46195,46224]
===
match
---
number: 3 [32229,32230]
number: 3 [32229,32230]
===
match
---
name: State [32300,32305]
name: State [32300,32305]
===
match
---
name: execution_date [25029,25043]
name: execution_date [25029,25043]
===
match
---
arglist [19215,19324]
arglist [19215,19324]
===
match
---
name: pendulum [57374,57382]
name: pendulum [57374,57382]
===
match
---
name: fail [26918,26922]
name: fail [26918,26922]
===
match
---
name: task [44863,44867]
name: task [44863,44867]
===
match
---
trailer [53870,53878]
trailer [53870,53878]
===
match
---
operator: , [32218,32219]
operator: , [32218,32219]
===
match
---
number: 1 [28950,28951]
number: 1 [28950,28951]
===
match
---
name: timezone [42750,42758]
name: timezone [42750,42758]
===
match
---
atom_expr [43244,43288]
atom_expr [43244,43288]
===
match
---
simple_stmt [36541,36591]
simple_stmt [36541,36591]
===
match
---
argument [10479,10526]
argument [10479,10526]
===
match
---
atom [36054,36076]
atom [36054,36076]
===
match
---
operator: = [44813,44814]
operator: = [44813,44814]
===
match
---
name: models [48987,48993]
name: models [48987,48993]
===
match
---
expr_stmt [79006,79049]
expr_stmt [79006,79049]
===
match
---
operator: = [17921,17922]
operator: = [17921,17922]
===
match
---
operator: , [4188,4189]
operator: , [4188,4189]
===
match
---
argument [60598,60621]
argument [60598,60621]
===
match
---
arglist [38564,38727]
arglist [38564,38727]
===
match
---
argument [8511,8530]
argument [8511,8530]
===
match
---
parameters [14552,14558]
parameters [14552,14558]
===
match
---
name: task [17984,17988]
name: task [17984,17988]
===
match
---
expr_stmt [2694,2714]
expr_stmt [2694,2714]
===
match
---
string: 'test_email_alert' [48235,48253]
string: 'test_email_alert' [48235,48253]
===
match
---
string: 'value' [59575,59582]
string: 'value' [59575,59582]
===
match
---
operator: = [29986,29987]
operator: = [29986,29987]
===
match
---
name: result [37543,37549]
name: result [37543,37549]
===
match
---
expr_stmt [50258,50316]
expr_stmt [50258,50316]
===
match
---
not_test [29371,29379]
not_test [29371,29379]
===
match
---
string: "True" [68991,68997]
string: "True" [68991,68997]
===
match
---
string: '{{ var.value.get("missing_variable", "fallback") }}' [57829,57882]
string: '{{ var.value.get("missing_variable", "fallback") }}' [57829,57882]
===
match
---
name: refresh_from_db [21345,21360]
name: refresh_from_db [21345,21360]
===
match
---
simple_stmt [10146,10163]
simple_stmt [10146,10163]
===
match
---
name: first_run_state [73517,73532]
name: first_run_state [73517,73532]
===
match
---
string: 'test_operator' [42615,42630]
string: 'test_operator' [42615,42630]
===
match
---
simple_stmt [3479,3498]
simple_stmt [3479,3498]
===
match
---
simple_stmt [19047,19056]
simple_stmt [19047,19056]
===
match
---
operator: = [24273,24274]
operator: = [24273,24274]
===
match
---
simple_stmt [24998,25149]
simple_stmt [24998,25149]
===
match
---
operator: , [40278,40279]
operator: , [40278,40279]
===
match
---
number: 2017 [41692,41696]
number: 2017 [41692,41696]
===
match
---
name: expected_duration [29082,29099]
name: expected_duration [29082,29099]
===
match
---
atom_expr [19267,19280]
atom_expr [19267,19280]
===
match
---
simple_stmt [7811,7892]
simple_stmt [7811,7892]
===
match
---
name: datetime [41674,41682]
name: datetime [41674,41682]
===
match
---
operator: , [70686,70687]
operator: , [70686,70687]
===
match
---
operator: = [74076,74077]
operator: = [74076,74077]
===
match
---
parameters [25179,25412]
parameters [25179,25412]
===
match
---
name: ti [47485,47487]
name: ti [47485,47487]
===
match
---
name: execution_date [66597,66611]
name: execution_date [66597,66611]
===
match
---
atom_expr [53985,54032]
atom_expr [53985,54032]
===
match
---
simple_stmt [7458,7502]
simple_stmt [7458,7502]
===
match
---
name: ti [28830,28832]
name: ti [28830,28832]
===
match
---
number: 5 [32043,32044]
number: 5 [32043,32044]
===
match
---
number: 0 [17345,17346]
number: 0 [17345,17346]
===
match
---
dotted_name [1985,2017]
dotted_name [1985,2017]
===
match
---
name: context [60283,60290]
name: context [60283,60290]
===
match
---
assert_stmt [5186,5252]
assert_stmt [5186,5252]
===
match
---
name: ti [51072,51074]
name: ti [51072,51074]
===
match
---
operator: , [33326,33327]
operator: , [33326,33327]
===
match
---
trailer [48152,48156]
trailer [48152,48156]
===
match
---
trailer [39084,39094]
trailer [39084,39094]
===
match
---
name: python_callable [74061,74076]
name: python_callable [74061,74076]
===
match
---
trailer [51470,51486]
trailer [51470,51486]
===
match
---
atom [32495,32561]
atom [32495,32561]
===
match
---
name: Session [60964,60971]
name: Session [60964,60971]
===
match
---
atom_expr [12404,12416]
atom_expr [12404,12416]
===
match
---
trailer [22366,22375]
trailer [22366,22375]
===
match
---
operator: , [33444,33445]
operator: , [33444,33445]
===
match
---
simple_stmt [76265,76292]
simple_stmt [76265,76292]
===
match
---
trailer [67963,68065]
trailer [67963,68065]
===
match
---
name: deps [2001,2005]
name: deps [2001,2005]
===
match
---
trailer [17374,17419]
trailer [17374,17419]
===
match
---
trailer [54246,54262]
trailer [54246,54262]
===
match
---
comparison [54654,54721]
comparison [54654,54721]
===
match
---
name: test_utils [2369,2379]
name: test_utils [2369,2379]
===
match
---
assert_stmt [21480,21569]
assert_stmt [21480,21569]
===
match
---
operator: } [67058,67059]
operator: } [67058,67059]
===
match
---
operator: = [2683,2684]
operator: = [2683,2684]
===
match
---
operator: , [22033,22034]
operator: , [22033,22034]
===
match
---
name: test_template_with_variable [57921,57948]
name: test_template_with_variable [57921,57948]
===
match
---
number: 0 [33680,33681]
number: 0 [33680,33681]
===
match
---
trailer [13615,13625]
trailer [13615,13625]
===
match
---
name: datetime [5299,5307]
name: datetime [5299,5307]
===
match
---
atom_expr [17309,17347]
atom_expr [17309,17347]
===
match
---
name: dag [8474,8477]
name: dag [8474,8477]
===
match
---
simple_stmt [11708,11763]
simple_stmt [11708,11763]
===
match
---
atom_expr [72735,72745]
atom_expr [72735,72745]
===
match
---
name: dep [35058,35061]
name: dep [35058,35061]
===
match
---
name: DEFAULT_DATE [68207,68219]
name: DEFAULT_DATE [68207,68219]
===
match
---
trailer [44556,44560]
trailer [44556,44560]
===
match
---
atom_expr [45067,45080]
atom_expr [45067,45080]
===
match
---
atom_expr [51675,51684]
atom_expr [51675,51684]
===
match
---
argument [30480,30509]
argument [30480,30509]
===
match
---
simple_stmt [44615,44685]
simple_stmt [44615,44685]
===
match
---
atom_expr [68581,68643]
atom_expr [68581,68643]
===
match
---
trailer [75150,75174]
trailer [75150,75174]
===
match
---
name: date2 [26233,26238]
name: date2 [26233,26238]
===
match
---
arith_expr [56036,56077]
arith_expr [56036,56077]
===
match
---
simple_stmt [21762,22137]
simple_stmt [21762,22137]
===
match
---
name: urllib [46744,46750]
name: urllib [46744,46750]
===
match
---
name: RUNNING [79150,79157]
name: RUNNING [79150,79157]
===
match
---
name: DAG [20023,20026]
name: DAG [20023,20026]
===
match
---
number: 0 [64731,64732]
number: 0 [64731,64732]
===
match
---
atom_expr [78381,78434]
atom_expr [78381,78434]
===
match
---
trailer [3167,3175]
trailer [3167,3175]
===
match
---
atom_expr [24345,24363]
atom_expr [24345,24363]
===
match
---
simple_stmt [13745,13778]
simple_stmt [13745,13778]
===
match
---
operator: { [70086,70087]
operator: { [70086,70087]
===
match
---
trailer [75076,75093]
trailer [75076,75093]
===
match
---
argument [34515,34522]
argument [34515,34522]
===
match
---
name: datetime [5044,5052]
name: datetime [5044,5052]
===
match
---
name: models [20016,20022]
name: models [20016,20022]
===
match
---
name: dag_run [74947,74954]
name: dag_run [74947,74954]
===
match
---
name: ti [77464,77466]
name: ti [77464,77466]
===
match
---
name: timezone [20567,20575]
name: timezone [20567,20575]
===
match
---
trailer [44713,44763]
trailer [44713,44763]
===
match
---
assert_stmt [43237,43288]
assert_stmt [43237,43288]
===
match
---
suite [36252,36717]
suite [36252,36717]
===
match
---
operator: = [13105,13106]
operator: = [13105,13106]
===
match
---
operator: = [68023,68024]
operator: = [68023,68024]
===
match
---
argument [13123,13139]
argument [13123,13139]
===
match
---
trailer [2540,2545]
trailer [2540,2545]
===
match
---
atom_expr [28771,28809]
atom_expr [28771,28809]
===
match
---
operator: , [35433,35434]
operator: , [35433,35434]
===
match
---
name: task [19136,19140]
name: task [19136,19140]
===
match
---
name: date3 [26225,26230]
name: date3 [26225,26230]
===
match
---
name: dag [22026,22029]
name: dag [22026,22029]
===
match
---
argument [50645,50652]
argument [50645,50652]
===
match
---
name: PythonSensor [24464,24476]
name: PythonSensor [24464,24476]
===
match
---
trailer [15184,15186]
trailer [15184,15186]
===
match
---
testlist_comp [32264,32320]
testlist_comp [32264,32320]
===
match
---
operator: , [41779,41780]
operator: , [41779,41780]
===
match
---
name: ti [19634,19636]
name: ti [19634,19636]
===
match
---
name: ti [46161,46163]
name: ti [46161,46163]
===
match
---
name: context [42392,42399]
name: context [42392,42399]
===
match
---
name: State [72381,72386]
name: State [72381,72386]
===
match
---
name: ti3 [45122,45125]
name: ti3 [45122,45125]
===
match
---
atom_expr [30873,30893]
atom_expr [30873,30893]
===
match
---
string: 'test_execute_callback' [60561,60584]
string: 'test_execute_callback' [60561,60584]
===
match
---
comparison [41005,41056]
comparison [41005,41056]
===
match
---
classdef [2496,3388]
classdef [2496,3388]
===
match
---
name: task [38797,38801]
name: task [38797,38801]
===
match
---
name: key [39717,39720]
name: key [39717,39720]
===
match
---
name: execution_date [63287,63301]
name: execution_date [63287,63301]
===
match
---
operator: , [5849,5850]
operator: , [5849,5850]
===
match
---
trailer [76247,76254]
trailer [76247,76254]
===
match
---
assert_stmt [27221,27250]
assert_stmt [27221,27250]
===
match
---
assert_stmt [6530,6564]
assert_stmt [6530,6564]
===
match
---
trailer [15132,15150]
trailer [15132,15150]
===
match
---
operator: = [78814,78815]
operator: = [78814,78815]
===
match
---
funcdef [6611,7369]
funcdef [6611,7369]
===
match
---
arglist [56956,57101]
arglist [56956,57101]
===
match
---
simple_stmt [27880,27905]
simple_stmt [27880,27905]
===
match
---
argument [52357,52372]
argument [52357,52372]
===
match
---
name: session [61197,61204]
name: session [61197,61204]
===
match
---
param [66253,66258]
param [66253,66258]
===
match
---
name: UP_FOR_RESCHEDULE [26878,26895]
name: UP_FOR_RESCHEDULE [26878,26895]
===
match
---
simple_stmt [56726,56743]
simple_stmt [56726,56743]
===
match
---
trailer [17933,17975]
trailer [17933,17975]
===
match
---
trailer [35351,35371]
trailer [35351,35371]
===
match
---
string: 'baz' [38019,38024]
string: 'baz' [38019,38024]
===
match
---
arglist [15002,15021]
arglist [15002,15021]
===
match
---
suite [78202,78829]
suite [78202,78829]
===
match
---
name: second_run_state [75651,75667]
name: second_run_state [75651,75667]
===
match
---
operator: = [78456,78457]
operator: = [78456,78457]
===
match
---
name: add [73899,73902]
name: add [73899,73902]
===
match
---
number: 0 [33369,33370]
number: 0 [33369,33370]
===
match
---
operator: , [65842,65843]
operator: , [65842,65843]
===
match
---
name: state [45093,45098]
name: state [45093,45098]
===
match
---
number: 0 [17339,17340]
number: 0 [17339,17340]
===
match
---
atom_expr [53122,53148]
atom_expr [53122,53148]
===
match
---
operator: , [18906,18907]
operator: , [18906,18907]
===
match
---
trailer [10160,10162]
trailer [10160,10162]
===
match
---
atom_expr [48515,48540]
atom_expr [48515,48540]
===
match
---
operator: , [35998,35999]
operator: , [35998,35999]
===
match
---
assert_stmt [36653,36716]
assert_stmt [36653,36716]
===
match
---
operator: , [49261,49262]
operator: , [49261,49262]
===
match
---
operator: = [11337,11338]
operator: = [11337,11338]
===
match
---
arglist [42807,42850]
arglist [42807,42850]
===
match
---
name: email [49836,49841]
name: email [49836,49841]
===
match
---
trailer [29511,29523]
trailer [29511,29523]
===
match
---
assert_stmt [77257,77312]
assert_stmt [77257,77312]
===
match
---
name: RUNNING [19273,19280]
name: RUNNING [19273,19280]
===
match
---
suite [64841,64863]
suite [64841,64863]
===
match
---
argument [65502,65553]
argument [65502,65553]
===
match
---
not_test [6932,6948]
not_test [6932,6948]
===
match
---
argument [80201,80221]
argument [80201,80221]
===
match
---
name: models [11036,11042]
name: models [11036,11042]
===
match
---
atom_expr [77386,77398]
atom_expr [77386,77398]
===
match
---
name: TI [30919,30921]
name: TI [30919,30921]
===
match
---
name: dag [42982,42985]
name: dag [42982,42985]
===
match
---
trailer [23228,23239]
trailer [23228,23239]
===
match
---
string: "pool_override" [76566,76581]
string: "pool_override" [76566,76581]
===
match
---
operator: = [14723,14724]
operator: = [14723,14724]
===
match
---
string: 'test_dagrun_fast_follow' [73667,73692]
string: 'test_dagrun_fast_follow' [73667,73692]
===
match
---
number: 1 [32440,32441]
number: 1 [32440,32441]
===
match
---
name: self [19814,19818]
name: self [19814,19818]
===
match
---
with_stmt [10072,10163]
with_stmt [10072,10163]
===
match
---
name: task [69219,69223]
name: task [69219,69223]
===
match
---
name: ti [19351,19353]
name: ti [19351,19353]
===
match
---
simple_stmt [5713,5755]
simple_stmt [5713,5755]
===
match
---
simple_stmt [78447,78472]
simple_stmt [78447,78472]
===
match
---
atom_expr [43612,43675]
atom_expr [43612,43675]
===
match
---
name: DAG [11043,11046]
name: DAG [11043,11046]
===
match
---
atom_expr [21223,21237]
atom_expr [21223,21237]
===
match
---
operator: , [43805,43806]
operator: , [43805,43806]
===
match
---
name: execution_date [5565,5579]
name: execution_date [5565,5579]
===
match
---
trailer [46068,46100]
trailer [46068,46100]
===
match
---
name: DAG [46065,46068]
name: DAG [46065,46068]
===
match
---
argument [48350,48359]
argument [48350,48359]
===
match
---
string: '{{ var.value.get("a_variable", "unused_fallback") }}' [57743,57797]
string: '{{ var.value.get("a_variable", "unused_fallback") }}' [57743,57797]
===
match
---
name: days [53141,53145]
name: days [53141,53145]
===
match
---
name: SUCCESS [55192,55199]
name: SUCCESS [55192,55199]
===
match
---
expr_stmt [39981,40001]
expr_stmt [39981,40001]
===
match
---
funcdef [58420,58874]
funcdef [58420,58874]
===
match
---
name: models [2331,2337]
name: models [2331,2337]
===
match
---
operator: , [23717,23718]
operator: , [23717,23718]
===
match
---
operator: , [31893,31894]
operator: , [31893,31894]
===
match
---
name: datetime [34233,34241]
name: datetime [34233,34241]
===
match
---
name: task_state_in_callback [51420,51442]
name: task_state_in_callback [51420,51442]
===
match
---
name: timedelta [5235,5244]
name: timedelta [5235,5244]
===
match
---
string: 'airflow.models.taskinstance.open' [49382,49416]
string: 'airflow.models.taskinstance.open' [49382,49416]
===
match
---
atom_expr [45156,45172]
atom_expr [45156,45172]
===
match
---
operator: , [78186,78187]
operator: , [78186,78187]
===
match
---
operator: == [27237,27239]
operator: == [27237,27239]
===
match
---
name: task [58672,58676]
name: task [58672,58676]
===
match
---
expr_stmt [13251,13329]
expr_stmt [13251,13329]
===
match
---
name: run [14443,14446]
name: run [14443,14446]
===
match
---
name: DAG [70935,70938]
name: DAG [70935,70938]
===
match
---
operator: @ [57570,57571]
operator: @ [57570,57571]
===
match
---
name: parametrize [76554,76565]
name: parametrize [76554,76565]
===
match
---
name: dag [21718,21721]
name: dag [21718,21721]
===
match
---
operator: = [35862,35863]
operator: = [35862,35863]
===
match
---
trailer [76319,76332]
trailer [76319,76332]
===
match
---
name: task [47498,47502]
name: task [47498,47502]
===
match
---
operator: = [11733,11734]
operator: = [11733,11734]
===
match
---
name: DummyOperator [5769,5782]
name: DummyOperator [5769,5782]
===
match
---
name: task_instance_b [74929,74944]
name: task_instance_b [74929,74944]
===
match
---
suite [73572,75975]
suite [73572,75975]
===
match
---
param [53240,53245]
param [53240,53245]
===
match
---
trailer [61290,61292]
trailer [61290,61292]
===
match
---
name: task_id [40120,40127]
name: task_id [40120,40127]
===
match
---
name: UP_FOR_RETRY [76367,76379]
name: UP_FOR_RETRY [76367,76379]
===
match
---
atom [32575,32641]
atom [32575,32641]
===
match
---
atom_expr [55630,55643]
atom_expr [55630,55643]
===
match
---
atom_expr [13752,13760]
atom_expr [13752,13760]
===
match
---
expr_stmt [41474,41714]
expr_stmt [41474,41714]
===
match
---
name: deserialized_op [79965,79980]
name: deserialized_op [79965,79980]
===
match
---
operator: = [78979,78980]
operator: = [78979,78980]
===
match
---
operator: , [34048,34049]
operator: , [34048,34049]
===
match
---
atom_expr [20699,20707]
atom_expr [20699,20707]
===
match
---
with_stmt [78897,79401]
with_stmt [78897,79401]
===
match
---
simple_stmt [47344,47378]
simple_stmt [47344,47378]
===
match
---
arglist [52047,52234]
arglist [52047,52234]
===
match
---
name: date2 [27718,27723]
name: date2 [27718,27723]
===
match
---
name: session [45376,45383]
name: session [45376,45383]
===
match
---
operator: , [32097,32098]
operator: , [32097,32098]
===
match
---
name: ti [30220,30222]
name: ti [30220,30222]
===
match
---
operator: , [33138,33139]
operator: , [33138,33139]
===
match
---
name: ti [5612,5614]
name: ti [5612,5614]
===
match
---
suite [60207,60292]
suite [60207,60292]
===
match
---
operator: , [15919,15920]
operator: , [15919,15920]
===
match
---
expr_stmt [4154,4203]
expr_stmt [4154,4203]
===
match
---
fstring_string: . [11941,11942]
fstring_string: . [11941,11942]
===
match
---
comparison [40638,40690]
comparison [40638,40690]
===
match
---
trailer [53130,53140]
trailer [53130,53140]
===
match
---
operator: , [66257,66258]
operator: , [66257,66258]
===
match
---
operator: , [64133,64134]
operator: , [64133,64134]
===
match
---
atom_expr [10761,10819]
atom_expr [10761,10819]
===
match
---
simple_stmt [48140,48186]
simple_stmt [48140,48186]
===
match
---
trailer [53067,53075]
trailer [53067,53075]
===
match
---
name: datetime [23210,23218]
name: datetime [23210,23218]
===
match
---
operator: = [10436,10437]
operator: = [10436,10437]
===
match
---
name: run_ti_and_assert [25162,25179]
name: run_ti_and_assert [25162,25179]
===
match
---
trailer [45125,45131]
trailer [45125,45131]
===
match
---
operator: = [34418,34419]
operator: = [34418,34419]
===
match
---
name: test_utils [2401,2411]
name: test_utils [2401,2411]
===
match
---
name: ti [50028,50030]
name: ti [50028,50030]
===
match
---
and_test [63530,63580]
and_test [63530,63580]
===
match
---
operator: = [19229,19230]
operator: = [19229,19230]
===
match
---
name: ti1 [61834,61837]
name: ti1 [61834,61837]
===
match
---
simple_stmt [59720,59768]
simple_stmt [59720,59768]
===
match
---
name: RUNNING [45140,45147]
name: RUNNING [45140,45147]
===
match
---
trailer [66881,66887]
trailer [66881,66887]
===
match
---
name: timezone [18931,18939]
name: timezone [18931,18939]
===
match
---
atom_expr [18487,18500]
atom_expr [18487,18500]
===
match
---
operator: , [28847,28848]
operator: , [28847,28848]
===
match
---
expr_stmt [25976,26023]
expr_stmt [25976,26023]
===
match
---
expr_stmt [6182,6230]
expr_stmt [6182,6230]
===
match
---
string: 'op_1' [76105,76111]
string: 'op_1' [76105,76111]
===
match
---
name: end_date [6590,6598]
name: end_date [6590,6598]
===
match
---
name: task_id [35295,35302]
name: task_id [35295,35302]
===
match
---
simple_stmt [9510,9527]
simple_stmt [9510,9527]
===
match
---
trailer [55527,55548]
trailer [55527,55548]
===
match
---
trailer [57468,57477]
trailer [57468,57477]
===
match
---
operator: = [18646,18647]
operator: = [18646,18647]
===
match
---
trailer [27175,27181]
trailer [27175,27181]
===
match
---
operator: , [35657,35658]
operator: , [35657,35658]
===
match
---
simple_stmt [26829,26903]
simple_stmt [26829,26903]
===
match
---
trailer [80255,80259]
trailer [80255,80259]
===
match
---
operator: = [22002,22003]
operator: = [22002,22003]
===
match
---
name: ti_deps [1852,1859]
name: ti_deps [1852,1859]
===
match
---
operator: , [6806,6807]
operator: , [6806,6807]
===
match
---
argument [14391,14420]
argument [14391,14420]
===
match
---
operator: , [32690,32691]
operator: , [32690,32691]
===
match
---
name: int [34094,34097]
name: int [34094,34097]
===
match
---
string: 'airflow.ti_deps.deps.prev_dagrun_dep.PrevDagrunDep.get_dep_statuses' [35588,35657]
string: 'airflow.ti_deps.deps.prev_dagrun_dep.PrevDagrunDep.get_dep_statuses' [35588,35657]
===
match
---
name: tasks [7363,7368]
name: tasks [7363,7368]
===
match
---
atom_expr [73891,73913]
atom_expr [73891,73913]
===
match
---
operator: = [52294,52295]
operator: = [52294,52295]
===
match
---
atom_expr [73229,73242]
atom_expr [73229,73242]
===
match
---
expr_stmt [56751,56767]
expr_stmt [56751,56767]
===
match
---
arglist [58822,58872]
arglist [58822,58872]
===
match
---
name: State [64284,64289]
name: State [64284,64289]
===
match
---
parameters [76011,76017]
parameters [76011,76017]
===
match
---
name: DagRunType [40513,40523]
name: DagRunType [40513,40523]
===
match
---
expr_stmt [79536,79586]
expr_stmt [79536,79586]
===
match
---
operator: = [34394,34395]
operator: = [34394,34395]
===
match
---
name: ti [46766,46768]
name: ti [46766,46768]
===
match
---
trailer [7086,7097]
trailer [7086,7097]
===
match
---
name: failed [34893,34899]
name: failed [34893,34899]
===
match
---
operator: = [57283,57284]
operator: = [57283,57284]
===
match
---
operator: , [71425,71426]
operator: , [71425,71426]
===
match
---
suite [71507,71651]
suite [71507,71651]
===
match
---
comparison [43424,43443]
comparison [43424,43443]
===
match
---
name: filter [3158,3164]
name: filter [3158,3164]
===
match
---
name: op1 [8777,8780]
name: op1 [8777,8780]
===
match
---
simple_stmt [37408,37455]
simple_stmt [37408,37455]
===
match
---
atom_expr [16416,16433]
atom_expr [16416,16433]
===
match
---
name: State [76361,76366]
name: State [76361,76366]
===
match
---
atom_expr [18504,18512]
atom_expr [18504,18512]
===
match
---
name: RenderedTaskInstanceFields [68428,68454]
name: RenderedTaskInstanceFields [68428,68454]
===
match
---
operator: , [76125,76126]
operator: , [76125,76126]
===
match
---
operator: = [4964,4965]
operator: = [4964,4965]
===
match
---
for_stmt [34441,34585]
for_stmt [34441,34585]
===
match
---
name: timezone [14984,14992]
name: timezone [14984,14992]
===
match
---
name: start_date [61870,61880]
name: start_date [61870,61880]
===
match
---
atom_expr [22364,22391]
atom_expr [22364,22391]
===
match
---
operator: , [32678,32679]
operator: , [32678,32679]
===
match
---
expr_stmt [56726,56742]
expr_stmt [56726,56742]
===
match
---
simple_stmt [20665,20684]
simple_stmt [20665,20684]
===
match
---
trailer [3866,3868]
trailer [3866,3868]
===
match
---
operator: , [27594,27595]
operator: , [27594,27595]
===
match
---
string: 'op1' [60062,60067]
string: 'op1' [60062,60067]
===
match
---
name: ti [43383,43385]
name: ti [43383,43385]
===
match
---
name: op2 [8017,8020]
name: op2 [8017,8020]
===
match
---
name: TI [34663,34665]
name: TI [34663,34665]
===
match
---
name: task [77088,77092]
name: task [77088,77092]
===
match
---
atom_expr [79096,79119]
atom_expr [79096,79119]
===
match
---
argument [34406,34431]
argument [34406,34431]
===
match
---
operator: = [10409,10410]
operator: = [10409,10410]
===
match
---
name: SUCCESS [35991,35998]
name: SUCCESS [35991,35998]
===
match
---
argument [23579,23604]
argument [23579,23604]
===
match
---
testlist_comp [33662,33705]
testlist_comp [33662,33705]
===
match
---
operator: = [79331,79332]
operator: = [79331,79332]
===
match
---
string: 'echo test_retry_handling; exit 1' [19965,19999]
string: 'echo test_retry_handling; exit 1' [19965,19999]
===
match
---
name: utcnow [76248,76254]
name: utcnow [76248,76254]
===
match
---
suite [21610,23137]
suite [21610,23137]
===
match
---
trailer [23115,23124]
trailer [23115,23124]
===
match
---
operator: , [29979,29980]
operator: , [29979,29980]
===
match
---
funcdef [71371,71651]
funcdef [71371,71651]
===
match
---
operator: , [32112,32113]
operator: , [32112,32113]
===
match
---
name: DEFAULT_DATE [2345,2357]
name: DEFAULT_DATE [2345,2357]
===
match
---
name: op2 [8700,8703]
name: op2 [8700,8703]
===
match
---
arglist [37223,37245]
arglist [37223,37245]
===
match
---
operator: , [70343,70344]
operator: , [70343,70344]
===
match
---
simple_stmt [30990,31075]
simple_stmt [30990,31075]
===
match
---
trailer [46911,46922]
trailer [46911,46922]
===
match
---
trailer [37350,37399]
trailer [37350,37399]
===
match
---
operator: = [21896,21897]
operator: = [21896,21897]
===
match
---
operator: = [44044,44045]
operator: = [44044,44045]
===
match
---
operator: , [59243,59244]
operator: , [59243,59244]
===
match
---
name: get_task_instance [71544,71561]
name: get_task_instance [71544,71561]
===
match
---
name: TIDepStatus [35489,35500]
name: TIDepStatus [35489,35500]
===
match
---
simple_stmt [43062,43133]
simple_stmt [43062,43133]
===
match
---
atom_expr [53092,53156]
atom_expr [53092,53156]
===
match
---
trailer [78431,78433]
trailer [78431,78433]
===
match
---
operator: , [41524,41525]
operator: , [41524,41525]
===
match
---
name: task_id [66471,66478]
name: task_id [66471,66478]
===
match
---
trailer [68253,68303]
trailer [68253,68303]
===
match
---
argument [40561,40578]
argument [40561,40578]
===
match
---
expr_stmt [44294,44311]
expr_stmt [44294,44311]
===
match
---
number: 2016 [64053,64057]
number: 2016 [64053,64057]
===
match
---
name: task [40772,40776]
name: task [40772,40776]
===
match
---
funcdef [60362,60529]
funcdef [60362,60529]
===
match
---
name: self [35218,35222]
name: self [35218,35222]
===
match
---
name: callback_wrapper [51240,51256]
name: callback_wrapper [51240,51256]
===
match
---
name: datetime [16327,16335]
name: datetime [16327,16335]
===
match
---
name: upstream [74499,74507]
name: upstream [74499,74507]
===
match
---
simple_stmt [2320,2358]
simple_stmt [2320,2358]
===
match
---
operator: , [48262,48263]
operator: , [48262,48263]
===
match
---
trailer [19450,19456]
trailer [19450,19456]
===
match
---
argument [14091,14107]
argument [14091,14107]
===
match
---
atom_expr [58231,58273]
atom_expr [58231,58273]
===
match
---
operator: , [2972,2973]
operator: , [2972,2973]
===
match
---
trailer [56647,56661]
trailer [56647,56661]
===
match
---
trailer [42872,42879]
trailer [42872,42879]
===
match
---
atom [73112,73132]
atom [73112,73132]
===
match
---
operator: , [72018,72019]
operator: , [72018,72019]
===
match
---
operator: , [72817,72818]
operator: , [72817,72818]
===
match
---
simple_stmt [10277,10450]
simple_stmt [10277,10450]
===
match
---
name: minutes [23279,23286]
name: minutes [23279,23286]
===
match
---
argument [79081,79119]
argument [79081,79119]
===
match
---
atom_expr [58764,58787]
atom_expr [58764,58787]
===
match
---
operator: , [25201,25202]
operator: , [25201,25202]
===
match
---
simple_stmt [10188,10218]
simple_stmt [10188,10218]
===
match
---
operator: , [14107,14108]
operator: , [14107,14108]
===
match
---
operator: == [51443,51445]
operator: == [51443,51445]
===
match
---
argument [40153,40160]
argument [40153,40160]
===
match
---
atom_expr [74119,74179]
atom_expr [74119,74179]
===
match
---
trailer [78383,78434]
trailer [78383,78434]
===
match
---
comparison [21418,21437]
comparison [21418,21437]
===
match
---
expr_stmt [69206,69253]
expr_stmt [69206,69253]
===
match
---
name: ti_list [53889,53896]
name: ti_list [53889,53896]
===
match
---
name: execution_date [56500,56514]
name: execution_date [56500,56514]
===
match
---
number: 0 [32102,32103]
number: 0 [32102,32103]
===
match
---
name: state [30185,30190]
name: state [30185,30190]
===
match
---
argument [13102,13109]
argument [13102,13109]
===
match
---
trailer [30713,30724]
trailer [30713,30724]
===
match
---
comparison [55589,55669]
comparison [55589,55669]
===
match
---
funcdef [10964,12594]
funcdef [10964,12594]
===
match
---
name: execution_date [19215,19229]
name: execution_date [19215,19229]
===
match
---
name: dag [4398,4401]
name: dag [4398,4401]
===
match
---
operator: = [76799,76800]
operator: = [76799,76800]
===
match
---
param [59412,59417]
param [59412,59417]
===
match
---
name: are_dependencies_met [35911,35931]
name: are_dependencies_met [35911,35931]
===
match
---
operator: = [2634,2635]
operator: = [2634,2635]
===
match
---
classdef [77504,80313]
classdef [77504,80313]
===
match
---
name: TestOperator [42327,42339]
name: TestOperator [42327,42339]
===
match
---
simple_stmt [34271,34323]
simple_stmt [34271,34323]
===
match
---
name: end_date [4608,4616]
name: end_date [4608,4616]
===
match
---
name: int [34002,34005]
name: int [34002,34005]
===
match
---
operator: , [7676,7677]
operator: , [7676,7677]
===
match
---
name: task [34604,34608]
name: task [34604,34608]
===
match
---
number: 1 [53073,53074]
number: 1 [53073,53074]
===
match
---
name: run [13714,13717]
name: run [13714,13717]
===
match
---
name: one [3314,3317]
name: one [3314,3317]
===
match
---
trailer [57140,57194]
trailer [57140,57194]
===
match
---
argument [19294,19323]
argument [19294,19323]
===
match
---
trailer [44628,44632]
trailer [44628,44632]
===
match
---
name: mock_on_failure_2 [62377,62394]
name: mock_on_failure_2 [62377,62394]
===
match
---
operator: , [12525,12526]
operator: , [12525,12526]
===
match
---
name: models [40017,40023]
name: models [40017,40023]
===
match
---
operator: , [32601,32602]
operator: , [32601,32602]
===
match
---
simple_stmt [44040,44112]
simple_stmt [44040,44112]
===
match
---
trailer [5271,5280]
trailer [5271,5280]
===
match
---
trailer [75834,75876]
trailer [75834,75876]
===
match
---
trailer [77028,77063]
trailer [77028,77063]
===
match
---
operator: , [70285,70286]
operator: , [70285,70286]
===
match
---
simple_stmt [51240,51280]
simple_stmt [51240,51280]
===
match
---
trailer [59982,60019]
trailer [59982,60019]
===
match
---
atom_expr [16143,16371]
atom_expr [16143,16371]
===
match
---
import_from [2203,2240]
import_from [2203,2240]
===
match
---
with_stmt [68175,68304]
with_stmt [68175,68304]
===
match
---
simple_stmt [77561,77685]
simple_stmt [77561,77685]
===
match
---
arglist [36869,36993]
arglist [36869,36993]
===
match
---
funcdef [23142,24041]
funcdef [23142,24041]
===
match
---
assert_stmt [10929,10958]
assert_stmt [10929,10958]
===
match
---
name: DAG [44629,44632]
name: DAG [44629,44632]
===
match
---
name: dag [34380,34383]
name: dag [34380,34383]
===
match
---
atom_expr [64810,64827]
atom_expr [64810,64827]
===
match
---
simple_stmt [51396,51460]
simple_stmt [51396,51460]
===
match
---
comparison [53598,53670]
comparison [53598,53670]
===
match
---
name: ti3 [63427,63430]
name: ti3 [63427,63430]
===
match
---
assert_stmt [21216,21242]
assert_stmt [21216,21242]
===
match
---
operator: , [26969,26970]
operator: , [26969,26970]
===
match
---
atom_expr [36394,36459]
atom_expr [36394,36459]
===
match
---
trailer [40650,40681]
trailer [40650,40681]
===
match
---
name: task_id [36323,36330]
name: task_id [36323,36330]
===
match
---
name: ti [70787,70789]
name: ti [70787,70789]
===
match
---
name: FAILED [64290,64296]
name: FAILED [64290,64296]
===
match
---
number: 0 [22123,22124]
number: 0 [22123,22124]
===
match
---
name: datetime [80247,80255]
name: datetime [80247,80255]
===
match
---
operator: , [71998,71999]
operator: , [71998,71999]
===
match
---
operator: , [31822,31823]
operator: , [31822,31823]
===
match
---
name: dag [22030,22033]
name: dag [22030,22033]
===
match
---
trailer [30680,30686]
trailer [30680,30686]
===
match
---
operator: = [50865,50866]
operator: = [50865,50866]
===
match
---
trailer [77290,77312]
trailer [77290,77312]
===
match
---
number: 0 [62774,62775]
number: 0 [62774,62775]
===
match
---
expr_stmt [74831,74860]
expr_stmt [74831,74860]
===
match
---
funcdef [78129,78829]
funcdef [78129,78829]
===
match
---
name: date [22893,22897]
name: date [22893,22897]
===
match
---
expr_stmt [34593,34648]
expr_stmt [34593,34648]
===
match
---
param [71394,71399]
param [71394,71399]
===
match
---
operator: , [27954,27955]
operator: , [27954,27955]
===
match
---
number: 0 [53993,53994]
number: 0 [53993,53994]
===
match
---
testlist_comp [12516,12539]
testlist_comp [12516,12539]
===
match
---
argument [37234,37245]
argument [37234,37245]
===
match
---
name: TIDepStatus [2025,2036]
name: TIDepStatus [2025,2036]
===
match
---
name: op_no_dag [5486,5495]
name: op_no_dag [5486,5495]
===
match
---
number: 2016 [11443,11447]
number: 2016 [11443,11447]
===
match
---
operator: -> [54461,54463]
operator: -> [54461,54463]
===
match
---
name: create_dagrun [56473,56486]
name: create_dagrun [56473,56486]
===
match
---
arglist [74623,74640]
arglist [74623,74640]
===
match
---
trailer [3284,3299]
trailer [3284,3299]
===
match
---
trailer [59809,59811]
trailer [59809,59811]
===
match
---
trailer [68752,68754]
trailer [68752,68754]
===
match
---
name: mock_send_email [48955,48970]
name: mock_send_email [48955,48970]
===
match
---
name: start_date [46076,46086]
name: start_date [46076,46086]
===
match
---
name: start [12014,12019]
name: start [12014,12019]
===
match
---
name: start_date [36339,36349]
name: start_date [36339,36349]
===
match
---
name: create_dagrun [51030,51043]
name: create_dagrun [51030,51043]
===
match
---
name: handle_failure [63359,63373]
name: handle_failure [63359,63373]
===
match
---
operator: == [20926,20928]
operator: == [20926,20928]
===
match
---
trailer [35990,35998]
trailer [35990,35998]
===
match
---
name: ti2 [44911,44914]
name: ti2 [44911,44914]
===
match
---
name: QUEUED [71843,71849]
name: QUEUED [71843,71849]
===
match
---
atom_expr [9571,9581]
atom_expr [9571,9581]
===
match
---
operator: , [76830,76831]
operator: , [76830,76831]
===
match
---
operator: , [32286,32287]
operator: , [32286,32287]
===
match
---
name: duration [76526,76534]
name: duration [76526,76534]
===
match
---
name: DAG [78949,78952]
name: DAG [78949,78952]
===
match
---
operator: , [6198,6199]
operator: , [6198,6199]
===
match
---
simple_stmt [8973,9018]
simple_stmt [8973,9018]
===
match
---
funcdef [55068,55670]
funcdef [55068,55670]
===
match
---
assert_stmt [20939,20964]
assert_stmt [20939,20964]
===
match
---
name: seconds [20254,20261]
name: seconds [20254,20261]
===
match
---
string: 'name' [69993,69999]
string: 'name' [69993,69999]
===
match
---
number: 0 [32899,32900]
number: 0 [32899,32900]
===
match
---
name: State [65862,65867]
name: State [65862,65867]
===
match
---
name: timezone [10600,10608]
name: timezone [10600,10608]
===
match
---
dictorsetmaker [69615,69957]
dictorsetmaker [69615,69957]
===
match
---
name: param [52870,52875]
name: param [52870,52875]
===
match
---
trailer [5614,5629]
trailer [5614,5629]
===
match
---
argument [18792,18801]
argument [18792,18801]
===
match
---
name: catchup [51824,51831]
name: catchup [51824,51831]
===
match
---
name: task [15065,15069]
name: task [15065,15069]
===
match
---
trailer [23882,23884]
trailer [23882,23884]
===
match
---
trailer [12904,12912]
trailer [12904,12912]
===
match
---
name: patch [35760,35765]
name: patch [35760,35765]
===
match
---
number: 2018 [46213,46217]
number: 2018 [46213,46217]
===
match
---
atom [32655,32721]
atom [32655,32721]
===
match
---
name: test_previous_ti_success [53730,53754]
name: test_previous_ti_success [53730,53754]
===
match
---
name: dag_id [44633,44639]
name: dag_id [44633,44639]
===
match
---
name: get_template_context [60147,60167]
name: get_template_context [60147,60167]
===
match
---
argument [5412,5423]
argument [5412,5423]
===
match
---
trailer [47536,47540]
trailer [47536,47540]
===
match
---
expr_stmt [6789,6832]
expr_stmt [6789,6832]
===
match
---
expr_stmt [11844,11879]
expr_stmt [11844,11879]
===
match
---
with_stmt [13399,13703]
with_stmt [13399,13703]
===
match
---
name: get_previous_start_date [55600,55623]
name: get_previous_start_date [55600,55623]
===
match
---
simple_stmt [23737,23785]
simple_stmt [23737,23785]
===
match
---
name: task [40086,40090]
name: task [40086,40090]
===
match
---
atom_expr [52924,52961]
atom_expr [52924,52961]
===
match
---
arglist [38706,38725]
arglist [38706,38725]
===
match
---
trailer [48384,48391]
trailer [48384,48391]
===
match
---
import_from [2320,2357]
import_from [2320,2357]
===
match
---
param [54452,54459]
param [54452,54459]
===
match
---
suite [60020,60069]
suite [60020,60069]
===
match
---
name: execution_date [76163,76177]
name: execution_date [76163,76177]
===
match
---
atom_expr [71099,71145]
atom_expr [71099,71145]
===
match
---
name: timezone [15723,15731]
name: timezone [15723,15731]
===
match
---
operator: = [56736,56737]
operator: = [56736,56737]
===
match
---
trailer [55206,55213]
trailer [55206,55213]
===
match
---
string: 'incr' [66221,66227]
string: 'incr' [66221,66227]
===
match
---
name: value [39567,39572]
name: value [39567,39572]
===
match
---
simple_stmt [48194,48333]
simple_stmt [48194,48333]
===
match
---
argument [21735,21752]
argument [21735,21752]
===
match
---
name: datetime [41757,41765]
name: datetime [41757,41765]
===
match
---
atom_expr [63001,63017]
atom_expr [63001,63017]
===
match
---
operator: = [23384,23385]
operator: = [23384,23385]
===
match
---
operator: , [51194,51195]
operator: , [51194,51195]
===
match
---
number: 60 [23287,23289]
number: 60 [23287,23289]
===
match
---
atom_expr [41915,41935]
atom_expr [41915,41935]
===
match
---
string: "test_handle_failure_on_failure" [61663,61695]
string: "test_handle_failure_on_failure" [61663,61695]
===
match
---
dotted_name [2042,2079]
dotted_name [2042,2079]
===
match
---
trailer [39281,39312]
trailer [39281,39312]
===
match
---
argument [47084,47096]
argument [47084,47096]
===
match
---
name: fail [25572,25576]
name: fail [25572,25576]
===
match
---
simple_stmt [80271,80313]
simple_stmt [80271,80313]
===
match
---
with_item [71274,71301]
with_item [71274,71301]
===
match
---
operator: , [13221,13222]
operator: , [13221,13222]
===
match
---
operator: = [19302,19303]
operator: = [19302,19303]
===
match
---
name: datetime [2624,2632]
name: datetime [2624,2632]
===
match
---
import_from [2137,2202]
import_from [2137,2202]
===
match
---
name: DEFAULT_DATE [59754,59766]
name: DEFAULT_DATE [59754,59766]
===
match
---
string: 'a_variable' [58083,58095]
string: 'a_variable' [58083,58095]
===
match
---
operator: , [1377,1378]
operator: , [1377,1378]
===
match
---
trailer [10153,10160]
trailer [10153,10160]
===
match
---
trailer [19049,19053]
trailer [19049,19053]
===
match
---
atom_expr [39682,39725]
atom_expr [39682,39725]
===
match
---
name: run [40557,40560]
name: run [40557,40560]
===
match
---
operator: , [69879,69880]
operator: , [69879,69880]
===
match
---
dictorsetmaker [68960,68997]
dictorsetmaker [68960,68997]
===
match
---
name: op3 [8625,8628]
name: op3 [8625,8628]
===
match
---
operator: == [13761,13763]
operator: == [13761,13763]
===
match
---
trailer [6598,6605]
trailer [6598,6605]
===
match
---
atom_expr [52476,52544]
atom_expr [52476,52544]
===
match
---
name: ti [76265,76267]
name: ti [76265,76267]
===
match
---
atom_expr [23742,23784]
atom_expr [23742,23784]
===
match
---
trailer [65412,65564]
trailer [65412,65564]
===
match
---
argument [6808,6831]
argument [6808,6831]
===
match
---
simple_stmt [55328,55399]
simple_stmt [55328,55399]
===
match
---
number: 1 [26268,26269]
number: 1 [26268,26269]
===
match
---
param [2974,2981]
param [2974,2981]
===
match
---
expr_stmt [36302,36363]
expr_stmt [36302,36363]
===
match
---
operator: = [47470,47471]
operator: = [47470,47471]
===
match
---
number: 2 [33548,33549]
number: 2 [33548,33549]
===
match
---
atom_expr [60544,60697]
atom_expr [60544,60697]
===
match
---
name: DagRunType [61102,61112]
name: DagRunType [61102,61112]
===
match
---
arith_expr [12852,12913]
arith_expr [12852,12913]
===
match
---
name: are_dependents_done [36663,36682]
name: are_dependents_done [36663,36682]
===
match
---
name: test_handle_failure [61343,61362]
name: test_handle_failure [61343,61362]
===
match
---
operator: , [36988,36989]
operator: , [36988,36989]
===
match
---
operator: { [16710,16711]
operator: { [16710,16711]
===
match
---
name: start_date [61378,61388]
name: start_date [61378,61388]
===
match
---
atom_expr [58664,58706]
atom_expr [58664,58706]
===
match
---
atom_expr [35985,35998]
atom_expr [35985,35998]
===
match
---
import_from [1043,1089]
import_from [1043,1089]
===
match
---
atom_expr [13605,13625]
atom_expr [13605,13625]
===
match
---
operator: , [32927,32928]
operator: , [32927,32928]
===
match
---
string: 'foo' [37692,37697]
string: 'foo' [37692,37697]
===
match
---
trailer [41007,41017]
trailer [41007,41017]
===
match
---
simple_stmt [79171,79189]
simple_stmt [79171,79189]
===
match
---
name: params [47865,47871]
name: params [47865,47871]
===
match
---
expr_stmt [76077,76135]
expr_stmt [76077,76135]
===
match
---
assert_stmt [67070,67145]
assert_stmt [67070,67145]
===
match
---
name: retries [76840,76847]
name: retries [76840,76847]
===
match
---
name: execution_date [52295,52309]
name: execution_date [52295,52309]
===
match
---
atom_expr [53899,53968]
atom_expr [53899,53968]
===
match
---
argument [39717,39724]
argument [39717,39724]
===
match
---
simple_stmt [2358,2390]
simple_stmt [2358,2390]
===
match
---
atom_expr [61391,61420]
atom_expr [61391,61420]
===
match
---
testlist_comp [7819,7860]
testlist_comp [7819,7860]
===
match
---
trailer [12066,12117]
trailer [12066,12117]
===
match
---
operator: = [61728,61729]
operator: = [61728,61729]
===
match
---
name: task [66758,66762]
name: task [66758,66762]
===
match
---
name: days [4135,4139]
name: days [4135,4139]
===
match
---
arglist [12466,12500]
arglist [12466,12500]
===
match
---
argument [68254,68267]
argument [68254,68267]
===
match
---
trailer [72030,72040]
trailer [72030,72040]
===
match
---
name: dag [27172,27175]
name: dag [27172,27175]
===
match
---
name: State [60923,60928]
name: State [60923,60928]
===
match
---
name: run [18466,18469]
name: run [18466,18469]
===
match
---
argument [28377,28410]
argument [28377,28410]
===
match
---
string: 'test passing reason' [35532,35553]
string: 'test passing reason' [35532,35553]
===
match
---
number: 0 [16040,16041]
number: 0 [16040,16041]
===
match
---
atom_expr [41481,41714]
atom_expr [41481,41714]
===
match
---
operator: = [67441,67442]
operator: = [67441,67442]
===
match
---
name: dag [66508,66511]
name: dag [66508,66511]
===
match
---
arglist [6424,6510]
arglist [6424,6510]
===
match
---
simple_stmt [24963,24989]
simple_stmt [24963,24989]
===
match
---
atom [71979,72041]
atom [71979,72041]
===
match
---
name: task [68326,68330]
name: task [68326,68330]
===
match
---
operator: , [67756,67757]
operator: , [67756,67757]
===
match
---
assert_stmt [57487,57564]
assert_stmt [57487,57564]
===
match
---
testlist_comp [36055,36075]
testlist_comp [36055,36075]
===
match
---
string: 'kubernetes_executor' [69850,69871]
string: 'kubernetes_executor' [69850,69871]
===
match
---
testlist_comp [32656,32720]
testlist_comp [32656,32720]
===
match
---
atom_expr [26829,26902]
atom_expr [26829,26902]
===
match
---
simple_stmt [29975,30001]
simple_stmt [29975,30001]
===
match
---
atom_expr [32914,32927]
atom_expr [32914,32927]
===
match
---
operator: = [16604,16605]
operator: = [16604,16605]
===
match
---
atom_expr [43531,43596]
atom_expr [43531,43596]
===
match
---
atom_expr [72025,72040]
atom_expr [72025,72040]
===
match
---
argument [76812,76830]
argument [76812,76830]
===
match
---
assert_stmt [43202,43228]
assert_stmt [43202,43228]
===
match
---
atom_expr [80278,80293]
atom_expr [80278,80293]
===
match
---
funcdef [67579,68116]
funcdef [67579,68116]
===
match
---
name: retry_delay [21912,21923]
name: retry_delay [21912,21923]
===
match
---
arglist [60241,60290]
arglist [60241,60290]
===
match
---
trailer [30921,30937]
trailer [30921,30937]
===
match
---
name: DagRunType [17548,17558]
name: DagRunType [17548,17558]
===
match
---
operator: , [23467,23468]
operator: , [23467,23468]
===
match
---
operator: , [56593,56594]
operator: , [56593,56594]
===
match
---
for_stmt [12511,12594]
for_stmt [12511,12594]
===
match
---
argument [63216,63225]
argument [63216,63225]
===
match
---
name: ti [66888,66890]
name: ti [66888,66890]
===
match
---
string: 'http://localhost:8080/log?' [46264,46292]
string: 'http://localhost:8080/log?' [46264,46292]
===
match
---
string: 'cron/catchup' [52825,52839]
string: 'cron/catchup' [52825,52839]
===
match
---
atom_expr [66804,66812]
atom_expr [66804,66812]
===
match
---
trailer [29245,29255]
trailer [29245,29255]
===
match
---
name: dag [16670,16673]
name: dag [16670,16673]
===
match
---
name: task [59728,59732]
name: task [59728,59732]
===
match
---
simple_stmt [22355,22422]
simple_stmt [22355,22422]
===
match
---
atom_expr [16490,16507]
atom_expr [16490,16507]
===
match
---
name: NONE [71956,71960]
name: NONE [71956,71960]
===
match
---
operator: = [54968,54969]
operator: = [54968,54969]
===
match
---
parameters [65387,65393]
parameters [65387,65393]
===
match
---
string: 'B' [73244,73247]
string: 'B' [73244,73247]
===
match
---
name: datetime [5226,5234]
name: datetime [5226,5234]
===
match
---
param [54424,54429]
param [54424,54429]
===
match
---
trailer [79184,79188]
trailer [79184,79188]
===
match
---
name: seconds [18846,18853]
name: seconds [18846,18853]
===
match
---
atom_expr [59979,60019]
atom_expr [59979,60019]
===
match
---
testlist_comp [36091,36110]
testlist_comp [36091,36110]
===
match
---
name: dag [55938,55941]
name: dag [55938,55941]
===
match
---
name: task_id [14799,14806]
name: task_id [14799,14806]
===
match
---
trailer [46878,46881]
trailer [46878,46881]
===
match
---
name: DateTime [57383,57391]
name: DateTime [57383,57391]
===
match
---
trailer [58777,58787]
trailer [58777,58787]
===
match
---
operator: , [41703,41704]
operator: , [41703,41704]
===
match
---
name: poke_interval [28508,28521]
name: poke_interval [28508,28521]
===
match
---
name: Optional [2606,2614]
name: Optional [2606,2614]
===
match
---
operator: = [38787,38788]
operator: = [38787,38788]
===
match
---
string: 'test' [4196,4202]
string: 'test' [4196,4202]
===
match
---
name: pool [10754,10758]
name: pool [10754,10758]
===
match
---
name: dag [46148,46151]
name: dag [46148,46151]
===
match
---
operator: , [35309,35310]
operator: , [35309,35310]
===
match
---
name: ti [47280,47282]
name: ti [47280,47282]
===
match
---
expr_stmt [63465,63514]
expr_stmt [63465,63514]
===
match
---
trailer [50099,50101]
trailer [50099,50101]
===
match
---
trailer [12013,12019]
trailer [12013,12019]
===
match
---
argument [9983,10001]
argument [9983,10001]
===
match
---
simple_stmt [59533,59607]
simple_stmt [59533,59607]
===
match
---
testlist_comp [33781,33825]
testlist_comp [33781,33825]
===
match
---
name: retries [62455,62462]
name: retries [62455,62462]
===
match
---
name: len [29888,29891]
name: len [29888,29891]
===
match
---
name: self [23187,23191]
name: self [23187,23191]
===
match
---
simple_stmt [67070,67146]
simple_stmt [67070,67146]
===
match
---
atom_expr [3720,3736]
atom_expr [3720,3736]
===
match
---
trailer [20358,20379]
trailer [20358,20379]
===
match
---
name: list [51694,51698]
name: list [51694,51698]
===
match
---
trailer [3824,3828]
trailer [3824,3828]
===
match
---
name: session [44506,44513]
name: session [44506,44513]
===
match
---
operator: , [69756,69757]
operator: , [69756,69757]
===
match
---
trailer [46786,46792]
trailer [46786,46792]
===
match
---
expr_stmt [49801,49859]
expr_stmt [49801,49859]
===
match
---
name: DEFAULT_DATE [50611,50623]
name: DEFAULT_DATE [50611,50623]
===
match
---
string: 'test_reschedule_handling' [28384,28410]
string: 'test_reschedule_handling' [28384,28410]
===
match
---
atom_expr [45181,45197]
atom_expr [45181,45197]
===
match
---
name: is_active [73849,73858]
name: is_active [73849,73858]
===
match
---
name: DummyOperator [1565,1578]
name: DummyOperator [1565,1578]
===
match
---
name: task_instance_d [75323,75338]
name: task_instance_d [75323,75338]
===
match
---
operator: = [43090,43091]
operator: = [43090,43091]
===
match
---
name: call_args [49591,49600]
name: call_args [49591,49600]
===
match
---
with_item [9441,9468]
with_item [9441,9468]
===
match
---
operator: = [19126,19127]
operator: = [19126,19127]
===
match
---
string: '{{ var.json.get("a_variable")["a"]["test"] }}' [59078,59125]
string: '{{ var.json.get("a_variable")["a"]["test"] }}' [59078,59125]
===
match
---
argument [11502,11534]
argument [11502,11534]
===
match
---
suite [24322,24364]
suite [24322,24364]
===
match
---
simple_stmt [62644,62673]
simple_stmt [62644,62673]
===
match
---
trailer [65320,65328]
trailer [65320,65328]
===
match
---
comparison [38220,38244]
comparison [38220,38244]
===
match
---
trailer [42841,42848]
trailer [42841,42848]
===
match
---
operator: , [71884,71885]
operator: , [71884,71885]
===
match
---
atom [32201,32249]
atom [32201,32249]
===
match
---
name: session [51937,51944]
name: session [51937,51944]
===
match
---
name: execution_date [41742,41756]
name: execution_date [41742,41756]
===
match
---
name: NONE [30200,30204]
name: NONE [30200,30204]
===
match
---
name: PythonOperator [64522,64536]
name: PythonOperator [64522,64536]
===
match
---
simple_stmt [71154,71196]
simple_stmt [71154,71196]
===
match
---
name: SUCCESS [72810,72817]
name: SUCCESS [72810,72817]
===
match
---
operator: = [43799,43800]
operator: = [43799,43800]
===
match
---
comparison [37583,37597]
comparison [37583,37597]
===
match
---
name: SKIPPED [36026,36033]
name: SKIPPED [36026,36033]
===
match
---
expr_stmt [30698,30753]
expr_stmt [30698,30753]
===
match
---
argument [63169,63202]
argument [63169,63202]
===
match
---
name: params [47242,47248]
name: params [47242,47248]
===
match
---
dictorsetmaker [76877,76931]
dictorsetmaker [76877,76931]
===
match
---
name: task_id [7729,7736]
name: task_id [7729,7736]
===
match
---
operator: , [13088,13089]
operator: , [13088,13089]
===
match
---
expr_stmt [22355,22421]
expr_stmt [22355,22421]
===
match
---
trailer [31085,31101]
trailer [31085,31101]
===
match
---
name: expected_start_date [25215,25234]
name: expected_start_date [25215,25234]
===
match
---
name: utils [2254,2259]
name: utils [2254,2259]
===
match
---
atom_expr [79171,79188]
atom_expr [79171,79188]
===
match
---
trailer [15465,15680]
trailer [15465,15680]
===
match
---
operator: = [67731,67732]
operator: = [67731,67732]
===
match
---
trailer [54890,54893]
trailer [54890,54893]
===
match
---
name: TaskReschedule [25982,25996]
name: TaskReschedule [25982,25996]
===
match
---
arglist [57141,57193]
arglist [57141,57193]
===
match
---
operator: = [7641,7642]
operator: = [7641,7642]
===
match
---
argument [22153,22162]
argument [22153,22162]
===
match
---
operator: , [46142,46143]
operator: , [46142,46143]
===
match
---
trailer [53341,53349]
trailer [53341,53349]
===
match
---
name: BashOperator [18685,18697]
name: BashOperator [18685,18697]
===
match
---
param [54430,54432]
param [54430,54432]
===
match
---
argument [42644,42651]
argument [42644,42651]
===
match
---
comparison [24026,24040]
comparison [24026,24040]
===
match
---
trailer [39522,39532]
trailer [39522,39532]
===
match
---
trailer [31331,31337]
trailer [31331,31337]
===
match
---
atom_expr [74769,74818]
atom_expr [74769,74818]
===
match
---
operator: = [38600,38601]
operator: = [38600,38601]
===
match
---
simple_stmt [70833,70879]
simple_stmt [70833,70879]
===
match
---
operator: = [67485,67486]
operator: = [67485,67486]
===
match
---
name: set [12852,12855]
name: set [12852,12855]
===
match
---
atom_expr [76949,77003]
atom_expr [76949,77003]
===
match
---
operator: = [78293,78294]
operator: = [78293,78294]
===
match
---
argument [41906,41935]
argument [41906,41935]
===
match
---
argument [68038,68055]
argument [68038,68055]
===
match
---
operator: , [28809,28810]
operator: , [28809,28810]
===
match
---
operator: , [40139,40140]
operator: , [40139,40140]
===
match
---
name: test_xcom_pull_different_execution_date [39743,39782]
name: test_xcom_pull_different_execution_date [39743,39782]
===
match
---
atom_expr [77964,77977]
atom_expr [77964,77977]
===
match
---
string: 'mock' [12342,12348]
string: 'mock' [12342,12348]
===
match
---
operator: = [36330,36331]
operator: = [36330,36331]
===
match
---
name: ti [65931,65933]
name: ti [65931,65933]
===
match
---
trailer [66044,66046]
trailer [66044,66046]
===
match
---
decorator [54333,54379]
decorator [54333,54379]
===
match
---
string: 'test_email_alert' [48585,48603]
string: 'test_email_alert' [48585,48603]
===
match
---
name: test_set_duration_empty_dates [50146,50175]
name: test_set_duration_empty_dates [50146,50175]
===
match
---
trailer [35156,35162]
trailer [35156,35162]
===
match
---
operator: = [4158,4159]
operator: = [4158,4159]
===
match
---
suite [71442,71651]
suite [71442,71651]
===
match
---
arglist [18019,18224]
arglist [18019,18224]
===
match
---
argument [37175,37199]
argument [37175,37199]
===
match
---
atom_expr [20780,20793]
atom_expr [20780,20793]
===
match
---
trailer [11247,11474]
trailer [11247,11474]
===
match
---
operator: , [13139,13140]
operator: , [13139,13140]
===
match
---
expr_stmt [42517,42565]
expr_stmt [42517,42565]
===
match
---
string: 'tasks' [67357,67364]
string: 'tasks' [67357,67364]
===
match
---
trailer [40819,40823]
trailer [40819,40823]
===
match
---
trailer [27268,27280]
trailer [27268,27280]
===
match
---
trailer [14410,14420]
trailer [14410,14420]
===
match
---
name: task_b [74110,74116]
name: task_b [74110,74116]
===
match
---
string: 'test_op_2' [8586,8597]
string: 'test_op_2' [8586,8597]
===
match
---
atom_expr [2876,2903]
atom_expr [2876,2903]
===
match
---
name: dag [23300,23303]
name: dag [23300,23303]
===
match
---
comparison [79853,79883]
comparison [79853,79883]
===
match
---
trailer [64783,64828]
trailer [64783,64828]
===
match
---
operator: , [75842,75843]
operator: , [75842,75843]
===
match
---
trailer [35765,35887]
trailer [35765,35887]
===
match
---
argument [61014,61046]
argument [61014,61046]
===
match
---
name: datetime [50905,50913]
name: datetime [50905,50913]
===
match
---
name: email [48490,48495]
name: email [48490,48495]
===
match
---
name: UPSTREAM_FAILED [32778,32793]
name: UPSTREAM_FAILED [32778,32793]
===
match
---
atom_expr [66106,66124]
atom_expr [66106,66124]
===
match
---
operator: = [18683,18684]
operator: = [18683,18684]
===
match
---
name: bash_command [20144,20156]
name: bash_command [20144,20156]
===
match
---
operator: = [18150,18151]
operator: = [18150,18151]
===
match
---
trailer [51486,51488]
trailer [51486,51488]
===
match
---
number: 0 [64071,64072]
number: 0 [64071,64072]
===
match
---
trailer [21179,21185]
trailer [21179,21185]
===
match
---
name: SerializedBaseOperator [79909,79931]
name: SerializedBaseOperator [79909,79931]
===
match
---
trailer [6799,6832]
trailer [6799,6832]
===
match
---
trailer [68183,68220]
trailer [68183,68220]
===
match
---
operator: = [73661,73662]
operator: = [73661,73662]
===
match
---
number: 0 [31702,31703]
number: 0 [31702,31703]
===
match
---
trailer [75574,75593]
trailer [75574,75593]
===
match
---
atom_expr [2762,2774]
atom_expr [2762,2774]
===
match
---
atom_expr [49473,49481]
atom_expr [49473,49481]
===
match
---
operator: { [15584,15585]
operator: { [15584,15585]
===
match
---
name: params [48001,48007]
name: params [48001,48007]
===
match
---
operator: , [51641,51642]
operator: , [51641,51642]
===
match
---
atom_expr [60713,60836]
atom_expr [60713,60836]
===
match
---
name: expected_pod_spec [70861,70878]
name: expected_pod_spec [70861,70878]
===
match
---
name: days [40748,40752]
name: days [40748,40752]
===
match
---
argument [34641,34647]
argument [34641,34647]
===
match
---
operator: , [32675,32676]
operator: , [32675,32676]
===
match
---
name: create_dagrun [14285,14298]
name: create_dagrun [14285,14298]
===
match
---
simple_stmt [44772,44845]
simple_stmt [44772,44845]
===
match
---
operator: = [18896,18897]
operator: = [18896,18897]
===
match
---
with_stmt [42861,42913]
with_stmt [42861,42913]
===
match
---
operator: , [78967,78968]
operator: , [78967,78968]
===
match
---
name: ti [20946,20948]
name: ti [20946,20948]
===
match
---
operator: } [71883,71884]
operator: } [71883,71884]
===
match
---
assert_stmt [54813,54908]
assert_stmt [54813,54908]
===
match
---
name: task2 [45011,45016]
name: task2 [45011,45016]
===
match
---
operator: = [6495,6496]
operator: = [6495,6496]
===
match
---
trailer [13258,13329]
trailer [13258,13329]
===
match
---
name: timezone [64150,64158]
name: timezone [64150,64158]
===
match
---
operator: , [27657,27658]
operator: , [27657,27658]
===
match
---
name: ti [39082,39084]
name: ti [39082,39084]
===
match
---
expr_stmt [30312,30359]
expr_stmt [30312,30359]
===
match
---
argument [43542,43595]
argument [43542,43595]
===
match
---
expr_stmt [54558,54637]
expr_stmt [54558,54637]
===
match
---
operator: , [44929,44930]
operator: , [44929,44930]
===
match
---
name: set [58079,58082]
name: set [58079,58082]
===
match
---
trailer [66001,66009]
trailer [66001,66009]
===
match
---
string: 'test_requeue_over_dag_concurrency_op' [9236,9274]
string: 'test_requeue_over_dag_concurrency_op' [9236,9274]
===
match
---
suite [48972,49759]
suite [48972,49759]
===
match
---
name: datetime [50896,50904]
name: datetime [50896,50904]
===
match
---
operator: = [34275,34276]
operator: = [34275,34276]
===
match
---
name: ti [22998,23000]
name: ti [22998,23000]
===
match
---
expr_stmt [30470,30535]
expr_stmt [30470,30535]
===
match
---
operator: = [31278,31279]
operator: = [31278,31279]
===
match
---
simple_stmt [51214,51231]
simple_stmt [51214,51231]
===
match
---
comparison [7818,7891]
comparison [7818,7891]
===
match
---
operator: , [5006,5007]
operator: , [5006,5007]
===
match
---
operator: , [33201,33202]
operator: , [33201,33202]
===
match
---
trailer [63779,63783]
trailer [63779,63783]
===
match
---
name: assert_queries_count [78729,78749]
name: assert_queries_count [78729,78749]
===
match
---
simple_stmt [24090,24162]
simple_stmt [24090,24162]
===
match
---
operator: @ [53169,53170]
operator: @ [53169,53170]
===
match
---
param [51981,51991]
param [51981,51991]
===
match
---
name: task [75025,75029]
name: task [75025,75029]
===
match
---
operator: = [38509,38510]
operator: = [38509,38510]
===
match
---
name: downstream_list [8781,8796]
name: downstream_list [8781,8796]
===
match
---
trailer [27245,27250]
trailer [27245,27250]
===
match
---
name: task [60091,60095]
name: task [60091,60095]
===
match
---
operator: , [17225,17226]
operator: , [17225,17226]
===
match
---
simple_stmt [19627,19665]
simple_stmt [19627,19665]
===
match
---
name: dag [49124,49127]
name: dag [49124,49127]
===
match
---
operator: , [33549,33550]
operator: , [33549,33550]
===
match
---
atom_expr [11638,11654]
atom_expr [11638,11654]
===
match
---
name: UP_FOR_RETRY [19652,19664]
name: UP_FOR_RETRY [19652,19664]
===
match
---
argument [44739,44762]
argument [44739,44762]
===
match
---
operator: , [73168,73169]
operator: , [73168,73169]
===
match
---
operator: , [1901,1902]
operator: , [1901,1902]
===
match
---
number: 0 [16348,16349]
number: 0 [16348,16349]
===
match
---
name: ti [52323,52325]
name: ti [52323,52325]
===
match
---
parameters [57948,57980]
parameters [57948,57980]
===
match
---
simple_stmt [41972,42046]
simple_stmt [41972,42046]
===
match
---
expr_stmt [74324,74393]
expr_stmt [74324,74393]
===
match
---
operator: == [54191,54193]
operator: == [54191,54193]
===
match
---
trailer [18392,18400]
trailer [18392,18400]
===
match
---
name: run_with_error [19726,19740]
name: run_with_error [19726,19740]
===
match
---
expr_stmt [47755,47789]
expr_stmt [47755,47789]
===
match
---
fstring_end: ' [11974,11975]
fstring_end: ' [11974,11975]
===
match
---
name: do_xcom_push [41602,41614]
name: do_xcom_push [41602,41614]
===
match
---
trailer [79821,79830]
trailer [79821,79830]
===
match
---
trailer [67134,67145]
trailer [67134,67145]
===
match
---
simple_stmt [48578,48613]
simple_stmt [48578,48613]
===
match
---
operator: } [76930,76931]
operator: } [76930,76931]
===
match
---
number: 0 [24701,24702]
number: 0 [24701,24702]
===
match
---
name: task [15702,15706]
name: task [15702,15706]
===
match
---
argument [13643,13658]
argument [13643,13658]
===
match
---
name: bash_command [69162,69174]
name: bash_command [69162,69174]
===
match
---
string: "test_pool2" [76590,76602]
string: "test_pool2" [76590,76602]
===
match
---
atom [71701,72159]
atom [71701,72159]
===
match
---
name: task_id [5783,5790]
name: task_id [5783,5790]
===
match
---
name: downstream_task [36560,36575]
name: downstream_task [36560,36575]
===
match
---
trailer [8350,8362]
trailer [8350,8362]
===
match
---
name: deserialized_op [80057,80072]
name: deserialized_op [80057,80072]
===
match
---
name: add [45214,45217]
name: add [45214,45217]
===
match
---
argument [63940,63947]
argument [63940,63947]
===
match
---
comparison [54236,54327]
comparison [54236,54327]
===
match
---
name: execution_date [18335,18349]
name: execution_date [18335,18349]
===
match
---
param [34088,34098]
param [34088,34098]
===
match
---
trailer [60189,60196]
trailer [60189,60196]
===
match
---
operator: = [44867,44868]
operator: = [44867,44868]
===
match
---
argument [48998,49025]
argument [48998,49025]
===
match
---
name: test_pool [3761,3770]
name: test_pool [3761,3770]
===
match
---
string: 'B' [71851,71854]
string: 'B' [71851,71854]
===
match
---
arglist [30480,30534]
arglist [30480,30534]
===
match
---
trailer [36613,36623]
trailer [36613,36623]
===
match
---
name: MagicMock [62963,62972]
name: MagicMock [62963,62972]
===
match
---
atom_expr [21086,21097]
atom_expr [21086,21097]
===
match
---
atom_expr [56576,56593]
atom_expr [56576,56593]
===
match
---
try_stmt [64837,64925]
try_stmt [64837,64925]
===
match
---
name: State [31341,31346]
name: State [31341,31346]
===
match
---
argument [19261,19280]
argument [19261,19280]
===
match
---
trailer [41017,41048]
trailer [41017,41048]
===
match
---
operator: = [69218,69219]
operator: = [69218,69219]
===
match
---
import_from [1171,1262]
import_from [1171,1262]
===
match
---
tfpdef [34037,34048]
tfpdef [34037,34048]
===
match
---
name: DAG [24410,24413]
name: DAG [24410,24413]
===
match
---
atom_expr [4433,4445]
atom_expr [4433,4445]
===
match
---
arglist [7015,7024]
arglist [7015,7024]
===
match
---
name: utcnow [19166,19172]
name: utcnow [19166,19172]
===
match
---
name: State [79144,79149]
name: State [79144,79149]
===
match
---
assert_stmt [25816,25859]
assert_stmt [25816,25859]
===
match
---
name: run_type [40504,40512]
name: run_type [40504,40512]
===
match
---
atom [72589,72635]
atom [72589,72635]
===
match
---
name: start_date [15616,15626]
name: start_date [15616,15626]
===
match
---
atom_expr [23210,23239]
atom_expr [23210,23239]
===
match
---
name: start_date [18174,18184]
name: start_date [18174,18184]
===
match
---
name: ti_list [55552,55559]
name: ti_list [55552,55559]
===
match
---
dictorsetmaker [69297,70687]
dictorsetmaker [69297,70687]
===
match
---
atom_expr [3479,3497]
atom_expr [3479,3497]
===
match
---
expr_stmt [29779,29826]
expr_stmt [29779,29826]
===
match
---
trailer [37555,37565]
trailer [37555,37565]
===
match
---
name: start_date [44739,44749]
name: start_date [44739,44749]
===
match
---
name: TI [51996,51998]
name: TI [51996,51998]
===
match
---
name: catchup [53950,53957]
name: catchup [53950,53957]
===
match
---
trailer [45245,45247]
trailer [45245,45247]
===
match
---
arglist [59850,59866]
arglist [59850,59866]
===
match
---
operator: = [23678,23679]
operator: = [23678,23679]
===
match
---
operator: == [29640,29642]
operator: == [29640,29642]
===
match
---
name: fail [29375,29379]
name: fail [29375,29379]
===
match
---
name: key [39304,39307]
name: key [39304,39307]
===
match
---
name: mock [62202,62206]
name: mock [62202,62206]
===
match
---
atom_expr [31341,31354]
atom_expr [31341,31354]
===
match
---
operator: { [72588,72589]
operator: { [72588,72589]
===
match
---
name: self [2876,2880]
name: self [2876,2880]
===
match
---
operator: , [39553,39554]
operator: , [39553,39554]
===
match
---
trailer [44524,44532]
trailer [44524,44532]
===
match
---
trailer [48993,48997]
trailer [48993,48997]
===
match
---
string: 'one_success' [32202,32215]
string: 'one_success' [32202,32215]
===
match
---
name: dag [7359,7362]
name: dag [7359,7362]
===
match
---
suite [50182,50378]
suite [50182,50378]
===
match
---
simple_stmt [64515,64768]
simple_stmt [64515,64768]
===
match
---
expr_stmt [34331,34432]
expr_stmt [34331,34432]
===
match
---
simple_stmt [57401,57479]
simple_stmt [57401,57479]
===
match
---
name: tis [15972,15975]
name: tis [15972,15975]
===
match
---
name: State [45067,45072]
name: State [45067,45072]
===
match
---
name: get_rendered_k8s_spec [71172,71193]
name: get_rendered_k8s_spec [71172,71193]
===
match
---
name: ti [22621,22623]
name: ti [22621,22623]
===
match
---
name: self [28029,28033]
name: self [28029,28033]
===
match
---
number: 2 [9186,9187]
number: 2 [9186,9187]
===
match
---
expr_stmt [19123,19175]
expr_stmt [19123,19175]
===
match
---
name: key [37477,37480]
name: key [37477,37480]
===
match
---
name: object [66207,66213]
name: object [66207,66213]
===
match
---
name: dag [28680,28683]
name: dag [28680,28683]
===
match
---
name: State [71873,71878]
name: State [71873,71878]
===
match
---
atom [69342,69565]
atom [69342,69565]
===
match
---
argument [43626,43640]
argument [43626,43640]
===
match
---
operator: , [26976,26977]
operator: , [26976,26977]
===
match
---
operator: = [74569,74570]
operator: = [74569,74570]
===
match
---
argument [37417,37427]
argument [37417,37427]
===
match
---
operator: = [62481,62482]
operator: = [62481,62482]
===
match
---
atom_expr [49315,49362]
atom_expr [49315,49362]
===
match
---
name: DAG [8858,8861]
name: DAG [8858,8861]
===
match
---
trailer [65328,65354]
trailer [65328,65354]
===
match
---
atom_expr [10195,10203]
atom_expr [10195,10203]
===
match
---
name: datetime [20235,20243]
name: datetime [20235,20243]
===
match
---
name: clear [27176,27181]
name: clear [27176,27181]
===
match
---
number: 4 [32677,32678]
number: 4 [32677,32678]
===
match
---
operator: , [50653,50654]
operator: , [50653,50654]
===
match
---
name: state [60915,60920]
name: state [60915,60920]
===
match
---
number: 0 [15020,15021]
number: 0 [15020,15021]
===
match
---
name: scheduler_job [1281,1294]
name: scheduler_job [1281,1294]
===
match
---
operator: , [58863,58864]
operator: , [58863,58864]
===
match
---
expr_stmt [66750,66795]
expr_stmt [66750,66795]
===
match
---
name: DEFAULT_DATE [69240,69252]
name: DEFAULT_DATE [69240,69252]
===
match
---
parameters [3467,3469]
parameters [3467,3469]
===
match
---
operator: = [13044,13045]
operator: = [13044,13045]
===
match
---
comparison [68081,68115]
comparison [68081,68115]
===
match
---
name: devnull [74573,74580]
name: devnull [74573,74580]
===
match
---
trailer [22516,22518]
trailer [22516,22518]
===
match
---
atom_expr [29626,29639]
atom_expr [29626,29639]
===
match
---
atom [12155,12180]
atom [12155,12180]
===
match
---
name: state [51981,51986]
name: state [51981,51986]
===
match
---
simple_stmt [48475,48480]
simple_stmt [48475,48480]
===
match
---
simple_stmt [16759,16778]
simple_stmt [16759,16778]
===
match
---
atom [33533,33590]
atom [33533,33590]
===
match
---
atom_expr [54018,54031]
atom_expr [54018,54031]
===
match
---
trailer [42848,42850]
trailer [42848,42850]
===
match
---
operator: = [40243,40244]
operator: = [40243,40244]
===
match
---
operator: , [32518,32519]
operator: , [32518,32519]
===
match
---
name: TI [76150,76152]
name: TI [76150,76152]
===
match
---
operator: , [52076,52077]
operator: , [52076,52077]
===
match
---
arglist [34288,34321]
arglist [34288,34321]
===
match
---
operator: = [65746,65747]
operator: = [65746,65747]
===
match
---
trailer [71171,71193]
trailer [71171,71193]
===
match
---
atom_expr [65862,65875]
atom_expr [65862,65875]
===
match
---
number: 1 [9159,9160]
number: 1 [9159,9160]
===
match
---
name: DEFAULT_DATE [65793,65805]
name: DEFAULT_DATE [65793,65805]
===
match
---
number: 2 [55656,55657]
number: 2 [55656,55657]
===
match
---
atom_expr [64522,64767]
atom_expr [64522,64767]
===
match
---
atom_expr [65259,65314]
atom_expr [65259,65314]
===
match
---
operator: = [67343,67344]
operator: = [67343,67344]
===
match
---
number: 1 [56075,56076]
number: 1 [56075,56076]
===
match
---
atom_expr [21769,22136]
atom_expr [21769,22136]
===
match
---
trailer [19353,19364]
trailer [19353,19364]
===
match
---
operator: , [64066,64067]
operator: , [64066,64067]
===
match
---
arglist [17152,17348]
arglist [17152,17348]
===
match
---
name: task_id [47084,47091]
name: task_id [47084,47091]
===
match
---
simple_stmt [50862,50921]
simple_stmt [50862,50921]
===
match
---
name: dag [19184,19187]
name: dag [19184,19187]
===
match
---
atom_expr [39457,39504]
atom_expr [39457,39504]
===
match
---
name: self [33950,33954]
name: self [33950,33954]
===
match
---
operator: @ [51535,51536]
operator: @ [51535,51536]
===
match
---
funcdef [54383,55013]
funcdef [54383,55013]
===
match
---
tfpdef [34088,34097]
tfpdef [34088,34097]
===
match
---
operator: = [44749,44750]
operator: = [44749,44750]
===
match
---
name: DEFAULT_DATE [58587,58599]
name: DEFAULT_DATE [58587,58599]
===
match
---
atom_expr [57338,57372]
atom_expr [57338,57372]
===
match
---
name: XCOM_RETURN_KEY [42021,42036]
name: XCOM_RETURN_KEY [42021,42036]
===
match
---
operator: , [68036,68037]
operator: , [68036,68037]
===
match
---
operator: , [47634,47635]
operator: , [47634,47635]
===
match
---
atom_expr [77008,77063]
atom_expr [77008,77063]
===
match
---
trailer [32457,32473]
trailer [32457,32473]
===
match
---
trailer [28872,28879]
trailer [28872,28879]
===
match
---
arglist [16336,16355]
arglist [16336,16355]
===
match
---
operator: = [44063,44064]
operator: = [44063,44064]
===
match
---
name: DEFAULT_DATE [68347,68359]
name: DEFAULT_DATE [68347,68359]
===
match
---
name: ti [79062,79064]
name: ti [79062,79064]
===
match
---
number: 3 [33805,33806]
number: 3 [33805,33806]
===
match
---
name: BashOperator [20072,20084]
name: BashOperator [20072,20084]
===
match
---
argument [16307,16356]
argument [16307,16356]
===
match
---
trailer [40556,40560]
trailer [40556,40560]
===
match
---
operator: = [58209,58210]
operator: = [58209,58210]
===
match
---
simple_stmt [27063,27128]
simple_stmt [27063,27128]
===
match
---
trailer [51221,51228]
trailer [51221,51228]
===
match
---
name: ti [50117,50119]
name: ti [50117,50119]
===
match
---
argument [7692,7699]
argument [7692,7699]
===
match
---
name: conf [73596,73600]
name: conf [73596,73600]
===
match
---
name: task_id [75382,75389]
name: task_id [75382,75389]
===
match
---
name: expected_try_number [29527,29546]
name: expected_try_number [29527,29546]
===
match
---
expr_stmt [7131,7143]
expr_stmt [7131,7143]
===
match
---
operator: = [50895,50896]
operator: = [50895,50896]
===
match
---
operator: , [62441,62442]
operator: , [62441,62442]
===
match
---
expr_stmt [46109,46152]
expr_stmt [46109,46152]
===
match
---
operator: , [32103,32104]
operator: , [32103,32104]
===
match
---
operator: , [34378,34379]
operator: , [34378,34379]
===
match
---
trailer [11442,11463]
trailer [11442,11463]
===
match
---
trailer [24361,24363]
trailer [24361,24363]
===
match
---
name: task [47493,47497]
name: task [47493,47497]
===
match
---
trailer [3183,3191]
trailer [3183,3191]
===
match
---
name: DEFAULT_DATE [36577,36589]
name: DEFAULT_DATE [36577,36589]
===
match
---
atom_expr [61628,61825]
atom_expr [61628,61825]
===
match
---
name: settings [66028,66036]
name: settings [66028,66036]
===
match
---
operator: , [52839,52840]
operator: , [52839,52840]
===
match
---
operator: = [20545,20546]
operator: = [20545,20546]
===
match
---
operator: , [8434,8435]
operator: , [8434,8435]
===
match
---
suite [59444,59909]
suite [59444,59909]
===
match
---
number: 30 [76848,76850]
number: 30 [76848,76850]
===
match
---
trailer [35409,35461]
trailer [35409,35461]
===
match
---
argument [35295,35309]
argument [35295,35309]
===
match
---
operator: = [74227,74228]
operator: = [74227,74228]
===
match
---
operator: , [52893,52894]
operator: , [52893,52894]
===
match
---
string: 'airflow' [24744,24753]
string: 'airflow' [24744,24753]
===
match
---
name: task [18251,18255]
name: task [18251,18255]
===
match
---
name: on_retry_callback [63169,63186]
name: on_retry_callback [63169,63186]
===
match
---
operator: = [61101,61102]
operator: = [61101,61102]
===
match
---
trailer [45092,45098]
trailer [45092,45098]
===
match
---
operator: , [64733,64734]
operator: , [64733,64734]
===
match
---
name: parse [46716,46721]
name: parse [46716,46721]
===
match
---
trailer [11433,11442]
trailer [11433,11442]
===
match
---
name: run [17591,17594]
name: run [17591,17594]
===
match
---
number: 0 [31693,31694]
number: 0 [31693,31694]
===
match
---
simple_stmt [36600,36645]
simple_stmt [36600,36645]
===
match
---
operator: , [41859,41860]
operator: , [41859,41860]
===
match
---
name: flag_upstream_failed [35002,35022]
name: flag_upstream_failed [35002,35022]
===
match
---
operator: == [37868,37870]
operator: == [37868,37870]
===
match
---
operator: , [44216,44217]
operator: , [44216,44217]
===
match
---
trailer [66686,66694]
trailer [66686,66694]
===
match
---
trailer [77222,77233]
trailer [77222,77233]
===
match
---
name: set_downstream [8336,8350]
name: set_downstream [8336,8350]
===
match
---
atom_expr [22150,22192]
atom_expr [22150,22192]
===
match
---
simple_stmt [5763,5799]
simple_stmt [5763,5799]
===
match
---
operator: , [31813,31814]
operator: , [31813,31814]
===
match
---
operator: , [72357,72358]
operator: , [72357,72358]
===
match
---
operator: , [27716,27717]
operator: , [27716,27717]
===
match
---
name: commit [3860,3866]
name: commit [3860,3866]
===
match
---
assert_stmt [47994,48028]
assert_stmt [47994,48028]
===
match
---
name: settings [3070,3078]
name: settings [3070,3078]
===
match
---
arglist [6800,6831]
arglist [6800,6831]
===
match
---
atom_expr [14505,14518]
atom_expr [14505,14518]
===
match
---
number: 0 [32973,32974]
number: 0 [32973,32974]
===
match
---
name: merge [78493,78498]
name: merge [78493,78498]
===
match
---
name: task_id [67478,67485]
name: task_id [67478,67485]
===
match
---
operator: , [33059,33060]
operator: , [33059,33060]
===
match
---
name: datetime [38697,38705]
name: datetime [38697,38705]
===
match
---
simple_stmt [53502,53582]
simple_stmt [53502,53582]
===
match
---
atom [72570,73006]
atom [72570,73006]
===
match
---
simple_stmt [20837,20856]
simple_stmt [20837,20856]
===
match
---
trailer [75087,75092]
trailer [75087,75092]
===
match
---
argument [44980,44986]
argument [44980,44986]
===
match
---
operator: = [57061,57062]
operator: = [57061,57062]
===
match
---
name: ti [43244,43246]
name: ti [43244,43246]
===
match
---
trailer [75593,75634]
trailer [75593,75634]
===
match
---
name: Union [891,896]
name: Union [891,896]
===
match
---
operator: = [5579,5580]
operator: = [5579,5580]
===
match
---
operator: , [32721,32722]
operator: , [32721,32722]
===
match
---
name: task_a [74024,74030]
name: task_a [74024,74030]
===
match
---
string: 'op' [79624,79628]
string: 'op' [79624,79628]
===
match
---
name: state [51103,51108]
name: state [51103,51108]
===
match
---
argument [59637,59660]
argument [59637,59660]
===
match
---
name: task [9938,9942]
name: task [9938,9942]
===
match
---
operator: = [17047,17048]
operator: = [17047,17048]
===
match
---
testlist_comp [54491,54547]
testlist_comp [54491,54547]
===
match
---
trailer [5403,5411]
trailer [5403,5411]
===
match
---
name: create_dagrun [40398,40411]
name: create_dagrun [40398,40411]
===
match
---
name: timezone [64810,64818]
name: timezone [64810,64818]
===
match
---
name: called [60417,60423]
name: called [60417,60423]
===
match
---
name: self [2743,2747]
name: self [2743,2747]
===
match
---
name: ti [12364,12366]
name: ti [12364,12366]
===
match
---
operator: { [47251,47252]
operator: { [47251,47252]
===
match
---
trailer [62046,62056]
trailer [62046,62056]
===
match
---
operator: = [63976,63977]
operator: = [63976,63977]
===
match
---
operator: { [76899,76900]
operator: { [76899,76900]
===
match
---
trailer [59624,59661]
trailer [59624,59661]
===
match
---
suite [68861,68925]
suite [68861,68925]
===
match
---
argument [11047,11102]
argument [11047,11102]
===
match
---
atom [76899,76931]
atom [76899,76931]
===
match
---
operator: , [57093,57094]
operator: , [57093,57094]
===
match
---
simple_stmt [7574,7629]
simple_stmt [7574,7629]
===
match
---
operator: = [66026,66027]
operator: = [66026,66027]
===
match
---
atom_expr [56313,56448]
atom_expr [56313,56448]
===
match
---
operator: = [24673,24674]
operator: = [24673,24674]
===
match
---
number: 1 [27638,27639]
number: 1 [27638,27639]
===
match
---
name: _try_number [29512,29523]
name: _try_number [29512,29523]
===
match
---
name: try_number [19354,19364]
name: try_number [19354,19364]
===
match
---
name: SUCCESS [55636,55643]
name: SUCCESS [55636,55643]
===
match
---
trailer [61310,61316]
trailer [61310,61316]
===
match
---
name: airflow [1176,1183]
name: airflow [1176,1183]
===
match
---
trailer [79113,79117]
trailer [79113,79117]
===
match
---
operator: + [56049,56050]
operator: + [56049,56050]
===
match
---
name: dag2 [7768,7772]
name: dag2 [7768,7772]
===
match
---
operator: = [65638,65639]
operator: = [65638,65639]
===
match
---
atom_expr [63334,63346]
atom_expr [63334,63346]
===
match
---
with_stmt [52405,52779]
with_stmt [52405,52779]
===
match
---
atom_expr [55201,55213]
atom_expr [55201,55213]
===
match
---
operator: , [27639,27640]
operator: , [27639,27640]
===
match
---
trailer [80259,80261]
trailer [80259,80261]
===
match
---
argument [9302,9311]
argument [9302,9311]
===
match
---
operator: = [55375,55376]
operator: = [55375,55376]
===
match
---
operator: , [74715,74716]
operator: , [74715,74716]
===
match
---
number: 0 [33492,33493]
number: 0 [33492,33493]
===
match
---
name: fail [27659,27663]
name: fail [27659,27663]
===
match
---
name: models [1328,1334]
name: models [1328,1334]
===
match
---
operator: = [79250,79251]
operator: = [79250,79251]
===
match
---
operator: = [40604,40605]
operator: = [40604,40605]
===
match
---
expr_stmt [7709,7773]
expr_stmt [7709,7773]
===
match
---
name: State [33188,33193]
name: State [33188,33193]
===
match
---
name: end_date [31020,31028]
name: end_date [31020,31028]
===
match
---
suite [60395,60529]
suite [60395,60529]
===
match
---
name: task [76952,76956]
name: task [76952,76956]
===
match
---
arglist [34666,34686]
arglist [34666,34686]
===
match
---
simple_stmt [19753,19785]
simple_stmt [19753,19785]
===
match
---
atom_expr [65318,65354]
atom_expr [65318,65354]
===
match
---
name: _clean [77969,77975]
name: _clean [77969,77975]
===
match
---
operator: = [9185,9186]
operator: = [9185,9186]
===
match
---
argument [50835,50842]
argument [50835,50842]
===
match
---
param [19814,19818]
param [19814,19818]
===
match
---
expr_stmt [26279,26324]
expr_stmt [26279,26324]
===
match
---
string: "test_pool1" [76740,76752]
string: "test_pool1" [76740,76752]
===
match
---
name: datetime [57071,57079]
name: datetime [57071,57079]
===
match
---
operator: , [34194,34195]
operator: , [34194,34195]
===
match
---
argument [37351,37372]
argument [37351,37372]
===
match
---
name: dag_id [40028,40034]
name: dag_id [40028,40034]
===
match
---
argument [40772,40781]
argument [40772,40781]
===
match
---
operator: , [41649,41650]
operator: , [41649,41650]
===
match
---
trailer [3261,3276]
trailer [3261,3276]
===
match
---
trailer [47157,47161]
trailer [47157,47161]
===
match
---
name: DAG [50493,50496]
name: DAG [50493,50496]
===
match
---
operator: = [5865,5866]
operator: = [5865,5866]
===
match
---
simple_stmt [67154,67188]
simple_stmt [67154,67188]
===
match
---
argument [43099,43106]
argument [43099,43106]
===
match
---
name: exec_date [40798,40807]
name: exec_date [40798,40807]
===
match
---
argument [71117,71144]
argument [71117,71144]
===
match
---
argument [21646,21656]
argument [21646,21656]
===
match
---
name: ignore_first_depends_on_past [31250,31278]
name: ignore_first_depends_on_past [31250,31278]
===
match
---
trailer [22203,22212]
trailer [22203,22212]
===
match
---
name: create_dagrun [38842,38855]
name: create_dagrun [38842,38855]
===
match
---
simple_stmt [826,842]
simple_stmt [826,842]
===
match
---
name: session [61171,61178]
name: session [61171,61178]
===
match
---
argument [6860,6874]
argument [6860,6874]
===
match
---
argument [16259,16289]
argument [16259,16289]
===
match
---
name: ti [20680,20682]
name: ti [20680,20682]
===
match
---
trailer [45416,45447]
trailer [45416,45447]
===
match
---
name: dag [74665,74668]
name: dag [74665,74668]
===
match
---
name: dag [41538,41541]
name: dag [41538,41541]
===
match
---
operator: , [72411,72412]
operator: , [72411,72412]
===
match
---
suite [48131,48686]
suite [48131,48686]
===
match
---
name: template_context [57419,57435]
name: template_context [57419,57435]
===
match
---
name: run_date [30698,30706]
name: run_date [30698,30706]
===
match
---
trailer [36512,36532]
trailer [36512,36532]
===
match
---
name: exceptions [1184,1194]
name: exceptions [1184,1194]
===
match
---
name: DEFAULT_DATE [4078,4090]
name: DEFAULT_DATE [4078,4090]
===
match
---
assert_stmt [56777,56833]
assert_stmt [56777,56833]
===
match
---
argument [74683,74715]
argument [74683,74715]
===
match
---
trailer [63015,63017]
trailer [63015,63017]
===
match
---
trailer [14298,14431]
trailer [14298,14431]
===
match
---
trailer [11694,11699]
trailer [11694,11699]
===
match
---
number: 1 [23237,23238]
number: 1 [23237,23238]
===
match
---
atom_expr [51516,51529]
atom_expr [51516,51529]
===
match
---
operator: = [74355,74356]
operator: = [74355,74356]
===
match
---
testlist_star_expr [27537,27547]
testlist_star_expr [27537,27547]
===
match
---
simple_stmt [51315,51343]
simple_stmt [51315,51343]
===
match
---
string: 'one_failed' [33534,33546]
string: 'one_failed' [33534,33546]
===
match
---
operator: = [50874,50875]
operator: = [50874,50875]
===
match
---
operator: , [74422,74423]
operator: , [74422,74423]
===
match
---
param [47427,47431]
param [47427,47431]
===
match
---
name: DummyOperator [8564,8577]
name: DummyOperator [8564,8577]
===
match
---
atom_expr [75255,75270]
atom_expr [75255,75270]
===
match
---
suite [78244,78715]
suite [78244,78715]
===
match
---
trailer [9524,9526]
trailer [9524,9526]
===
match
---
name: SUCCESS [17647,17654]
name: SUCCESS [17647,17654]
===
match
---
number: 3 [54932,54933]
number: 3 [54932,54933]
===
match
---
name: day_1 [56359,56364]
name: day_1 [56359,56364]
===
match
---
trailer [77189,77194]
trailer [77189,77194]
===
match
---
trailer [21157,21161]
trailer [21157,21161]
===
match
---
name: self [50427,50431]
name: self [50427,50431]
===
match
---
argument [68665,68678]
argument [68665,68678]
===
match
---
trailer [65664,65688]
trailer [65664,65688]
===
match
---
name: airflow [1486,1493]
name: airflow [1486,1493]
===
match
---
operator: , [73489,73490]
operator: , [73489,73490]
===
match
---
simple_stmt [68764,68801]
simple_stmt [68764,68801]
===
match
---
number: 0 [28804,28805]
number: 0 [28804,28805]
===
match
---
operator: , [74059,74060]
operator: , [74059,74060]
===
match
---
operator: , [33981,33982]
operator: , [33981,33982]
===
match
---
operator: , [29993,29994]
operator: , [29993,29994]
===
match
---
operator: = [58186,58187]
operator: = [58186,58187]
===
match
---
arglist [61446,61521]
arglist [61446,61521]
===
match
---
name: _clean [77712,77718]
name: _clean [77712,77718]
===
match
---
trailer [7959,7966]
trailer [7959,7966]
===
match
---
operator: , [42696,42697]
operator: , [42696,42697]
===
match
---
name: days [4999,5003]
name: days [4999,5003]
===
match
---
operator: = [15911,15912]
operator: = [15911,15912]
===
match
---
expr_stmt [60945,60973]
expr_stmt [60945,60973]
===
match
---
name: dag [17043,17046]
name: dag [17043,17046]
===
match
---
atom_expr [38998,39023]
atom_expr [38998,39023]
===
match
---
atom [33286,33334]
atom [33286,33334]
===
match
---
trailer [78611,78619]
trailer [78611,78619]
===
match
---
operator: == [26094,26096]
operator: == [26094,26096]
===
match
---
testlist_comp [48786,48818]
testlist_comp [48786,48818]
===
match
---
operator: = [51108,51109]
operator: = [51108,51109]
===
match
---
testlist_comp [71719,72145]
testlist_comp [71719,72145]
===
match
---
name: start_date [35311,35321]
name: start_date [35311,35321]
===
match
---
name: models [43531,43537]
name: models [43531,43537]
===
match
---
argument [68332,68359]
argument [68332,68359]
===
match
---
name: ti [2850,2852]
name: ti [2850,2852]
===
match
---
argument [25108,25137]
argument [25108,25137]
===
match
---
atom_expr [61435,61522]
atom_expr [61435,61522]
===
match
---
operator: , [76998,76999]
operator: , [76998,76999]
===
match
---
atom_expr [10887,10903]
atom_expr [10887,10903]
===
match
---
name: op3 [8352,8355]
name: op3 [8352,8355]
===
match
---
name: ti [42799,42801]
name: ti [42799,42801]
===
match
---
number: 0 [17342,17343]
number: 0 [17342,17343]
===
match
---
expr_stmt [76652,76939]
expr_stmt [76652,76939]
===
match
---
name: State [72841,72846]
name: State [72841,72846]
===
match
---
name: task [77432,77436]
name: task [77432,77436]
===
match
---
name: operator [80285,80293]
name: operator [80285,80293]
===
match
---
number: 480 [22873,22876]
number: 480 [22873,22876]
===
match
---
name: task_states [12862,12873]
name: task_states [12862,12873]
===
match
---
operator: , [14186,14187]
operator: , [14186,14187]
===
match
---
operator: , [12216,12217]
operator: , [12216,12217]
===
match
---
name: python_callable [74077,74092]
name: python_callable [74077,74092]
===
match
---
operator: = [24252,24253]
operator: = [24252,24253]
===
match
---
name: test_check_and_change_state_before_execution_dep_not_met [43453,43509]
name: test_check_and_change_state_before_execution_dep_not_met [43453,43509]
===
match
---
name: tearDown [3878,3886]
name: tearDown [3878,3886]
===
match
---
atom_expr [24935,24949]
atom_expr [24935,24949]
===
match
---
argument [48287,48310]
argument [48287,48310]
===
match
---
operator: } [72040,72041]
operator: } [72040,72041]
===
match
---
name: xcom_pull [38143,38152]
name: xcom_pull [38143,38152]
===
match
---
arglist [6079,6113]
arglist [6079,6113]
===
match
---
assert_stmt [40998,41056]
assert_stmt [40998,41056]
===
match
---
operator: , [26916,26917]
operator: , [26916,26917]
===
match
---
name: SUCCESS [27962,27969]
name: SUCCESS [27962,27969]
===
match
---
string: 'test_dagrun_execute_callback' [60498,60528]
string: 'test_dagrun_execute_callback' [60498,60528]
===
match
---
name: mock [63001,63005]
name: mock [63001,63005]
===
match
---
argument [19215,19247]
argument [19215,19247]
===
match
---
operator: = [36555,36556]
operator: = [36555,36556]
===
match
---
string: 'C' [71945,71948]
string: 'C' [71945,71948]
===
match
---
name: datetime [50051,50059]
name: datetime [50051,50059]
===
match
---
atom_expr [68874,68924]
atom_expr [68874,68924]
===
match
---
atom_expr [23679,23717]
atom_expr [23679,23717]
===
match
---
name: expected_task_reschedule_count [29174,29204]
name: expected_task_reschedule_count [29174,29204]
===
match
---
parameters [69034,69040]
parameters [69034,69040]
===
match
---
name: op2 [4829,4832]
name: op2 [4829,4832]
===
match
---
expr_stmt [46059,46100]
expr_stmt [46059,46100]
===
match
---
trailer [31205,31209]
trailer [31205,31209]
===
match
---
trailer [77868,77870]
trailer [77868,77870]
===
match
---
operator: -> [77892,77894]
operator: -> [77892,77894]
===
match
---
name: dag [43723,43726]
name: dag [43723,43726]
===
match
---
name: SCHEDULED [78657,78666]
name: SCHEDULED [78657,78666]
===
match
---
name: fail [27036,27040]
name: fail [27036,27040]
===
match
---
assert_stmt [47344,47377]
assert_stmt [47344,47377]
===
match
---
name: owner [22047,22052]
name: owner [22047,22052]
===
match
---
name: state [54963,54968]
name: state [54963,54968]
===
match
---
name: done [27030,27034]
name: done [27030,27034]
===
match
---
string: 'test_pool' [24772,24783]
string: 'test_pool' [24772,24783]
===
match
---
operator: , [27086,27087]
operator: , [27086,27087]
===
match
---
simple_stmt [1090,1133]
simple_stmt [1090,1133]
===
match
---
name: ti [64854,64856]
name: ti [64854,64856]
===
match
---
simple_stmt [37013,37043]
simple_stmt [37013,37043]
===
match
---
name: DAG [8425,8428]
name: DAG [8425,8428]
===
match
---
trailer [54312,54327]
trailer [54312,54327]
===
match
---
name: timezone [42833,42841]
name: timezone [42833,42841]
===
match
---
name: dag [60819,60822]
name: dag [60819,60822]
===
match
---
string: 'test_dag' [35249,35259]
string: 'test_dag' [35249,35259]
===
match
---
trailer [24916,24918]
trailer [24916,24918]
===
match
---
name: task [50870,50874]
name: task [50870,50874]
===
match
---
number: 1 [6088,6089]
number: 1 [6088,6089]
===
match
---
comparison [10788,10812]
comparison [10788,10812]
===
match
---
operator: = [38404,38405]
operator: = [38404,38405]
===
match
---
name: ti_list [53360,53367]
name: ti_list [53360,53367]
===
match
---
atom [68959,68998]
atom [68959,68998]
===
match
---
argument [34358,34378]
argument [34358,34378]
===
match
---
name: task [58181,58185]
name: task [58181,58185]
===
match
---
name: python_callable [42665,42680]
name: python_callable [42665,42680]
===
match
---
name: session [78485,78492]
name: session [78485,78492]
===
match
---
funcdef [60297,61334]
funcdef [60297,61334]
===
match
---
with_stmt [79410,79472]
with_stmt [79410,79472]
===
match
---
expr_stmt [75407,75436]
expr_stmt [75407,75436]
===
match
---
name: DEFAULT_DATE [36519,36531]
name: DEFAULT_DATE [36519,36531]
===
match
---
name: run_type [56567,56575]
name: run_type [56567,56575]
===
match
---
comparison [43209,43228]
comparison [43209,43228]
===
match
---
operator: , [52961,52962]
operator: , [52961,52962]
===
match
---
param [10262,10266]
param [10262,10266]
===
match
---
operator: , [38192,38193]
operator: , [38192,38193]
===
match
---
trailer [47918,47920]
trailer [47918,47920]
===
match
---
operator: == [77429,77431]
operator: == [77429,77431]
===
match
---
name: self [3676,3680]
name: self [3676,3680]
===
match
---
string: 'C' [73263,73266]
string: 'C' [73263,73266]
===
match
---
name: ti [13524,13526]
name: ti [13524,13526]
===
match
---
operator: = [64149,64150]
operator: = [64149,64150]
===
match
---
atom_expr [66457,66499]
atom_expr [66457,66499]
===
match
---
name: DAG [6796,6799]
name: DAG [6796,6799]
===
match
---
string: 'test_failure_email' [48164,48184]
string: 'test_failure_email' [48164,48184]
===
match
---
arglist [12313,12348]
arglist [12313,12348]
===
match
---
trailer [16492,16507]
trailer [16492,16507]
===
match
---
expr_stmt [41723,41787]
expr_stmt [41723,41787]
===
match
---
name: ti [51504,51506]
name: ti [51504,51506]
===
match
---
name: DAG [44053,44056]
name: DAG [44053,44056]
===
match
---
string: 'image' [70488,70495]
string: 'image' [70488,70495]
===
match
---
argument [59739,59766]
argument [59739,59766]
===
match
---
operator: , [65946,65947]
operator: , [65946,65947]
===
match
---
operator: } [72779,72780]
operator: } [72779,72780]
===
match
---
operator: = [41914,41915]
operator: = [41914,41915]
===
match
---
operator: , [32358,32359]
operator: , [32358,32359]
===
match
---
operator: = [37189,37190]
operator: = [37189,37190]
===
match
---
decorator [3437,3451]
decorator [3437,3451]
===
match
---
trailer [80005,80026]
trailer [80005,80026]
===
match
---
name: dag [48259,48262]
name: dag [48259,48262]
===
match
---
argument [49120,49127]
argument [49120,49127]
===
match
---
string: 'True' [70623,70629]
string: 'True' [70623,70629]
===
match
---
trailer [55220,55228]
trailer [55220,55228]
===
match
---
suite [55150,55670]
suite [55150,55670]
===
match
---
trailer [60971,60973]
trailer [60971,60973]
===
match
---
name: ti [9494,9496]
name: ti [9494,9496]
===
match
---
atom_expr [5299,5325]
atom_expr [5299,5325]
===
match
---
simple_stmt [10929,10959]
simple_stmt [10929,10959]
===
match
---
parameters [18538,18544]
parameters [18538,18544]
===
match
---
name: context [59859,59866]
name: context [59859,59866]
===
match
---
argument [74628,74640]
argument [74628,74640]
===
match
---
argument [16475,16507]
argument [16475,16507]
===
match
---
atom_expr [35154,35162]
atom_expr [35154,35162]
===
match
---
testlist_star_expr [26912,26922]
testlist_star_expr [26912,26922]
===
match
---
with_stmt [70707,70879]
with_stmt [70707,70879]
===
match
---
assert_stmt [77130,77161]
assert_stmt [77130,77161]
===
match
---
number: 0 [33739,33740]
number: 0 [33739,33740]
===
match
---
operator: , [18778,18779]
operator: , [18778,18779]
===
match
---
name: execution_date [54284,54298]
name: execution_date [54284,54298]
===
match
---
operator: } [67117,67118]
operator: } [67117,67118]
===
match
---
atom_expr [62278,62496]
atom_expr [62278,62496]
===
match
---
trailer [50917,50919]
trailer [50917,50919]
===
match
---
name: task [56756,56760]
name: task [56756,56760]
===
match
---
trailer [20084,20390]
trailer [20084,20390]
===
match
---
name: utcnow [11526,11532]
name: utcnow [11526,11532]
===
match
---
name: done [26912,26916]
name: done [26912,26916]
===
match
---
operator: , [28666,28667]
operator: , [28666,28667]
===
match
---
simple_stmt [77730,77749]
simple_stmt [77730,77749]
===
match
---
name: parameterized [54334,54347]
name: parameterized [54334,54347]
===
match
---
trailer [16039,16042]
trailer [16039,16042]
===
match
---
number: 0 [14921,14922]
number: 0 [14921,14922]
===
match
---
operator: == [5630,5632]
operator: == [5630,5632]
===
match
---
operator: , [23654,23655]
operator: , [23654,23655]
===
match
---
atom_expr [18304,18454]
atom_expr [18304,18454]
===
match
---
simple_stmt [40554,40580]
simple_stmt [40554,40580]
===
match
---
parameters [61362,61368]
parameters [61362,61368]
===
match
---
simple_stmt [62505,62553]
simple_stmt [62505,62553]
===
match
---
atom_expr [23825,23842]
atom_expr [23825,23842]
===
match
---
number: 0 [34260,34261]
number: 0 [34260,34261]
===
match
---
trailer [12554,12561]
trailer [12554,12561]
===
match
---
assert_stmt [21170,21207]
assert_stmt [21170,21207]
===
match
---
trailer [73180,73187]
trailer [73180,73187]
===
match
---
trailer [4998,5006]
trailer [4998,5006]
===
match
---
number: 2 [22111,22112]
number: 2 [22111,22112]
===
match
---
trailer [38967,38977]
trailer [38967,38977]
===
match
---
atom_expr [34277,34322]
atom_expr [34277,34322]
===
match
---
atom [48785,48819]
atom [48785,48819]
===
match
---
trailer [7113,7117]
trailer [7113,7117]
===
match
---
operator: , [12100,12101]
operator: , [12100,12101]
===
match
---
operator: = [5249,5250]
operator: = [5249,5250]
===
match
---
string: 'airflow.models.taskinstance.send_email' [48041,48081]
string: 'airflow.models.taskinstance.send_email' [48041,48081]
===
match
---
trailer [57337,57392]
trailer [57337,57392]
===
match
---
trailer [16638,16655]
trailer [16638,16655]
===
match
---
atom_expr [57062,57100]
atom_expr [57062,57100]
===
match
---
operator: = [4054,4055]
operator: = [4054,4055]
===
match
---
fstring [34501,34513]
fstring [34501,34513]
===
match
---
number: 2 [33167,33168]
number: 2 [33167,33168]
===
match
---
trailer [6189,6230]
trailer [6189,6230]
===
match
---
trailer [16766,16775]
trailer [16766,16775]
===
match
---
name: ti [25763,25765]
name: ti [25763,25765]
===
match
---
name: period [22581,22587]
name: period [22581,22587]
===
match
---
arglist [47628,47640]
arglist [47628,47640]
===
match
---
name: python_callable [73955,73970]
name: python_callable [73955,73970]
===
match
---
testlist_comp [8352,8360]
testlist_comp [8352,8360]
===
match
---
name: xcom_pull [37556,37565]
name: xcom_pull [37556,37565]
===
match
---
param [33964,33982]
param [33964,33982]
===
match
---
assert_stmt [76473,76507]
assert_stmt [76473,76507]
===
match
---
operator: = [26923,26924]
operator: = [26923,26924]
===
match
---
comparison [41979,42045]
comparison [41979,42045]
===
match
---
operator: , [55213,55214]
operator: , [55213,55214]
===
match
---
argument [17218,17225]
argument [17218,17225]
===
match
---
trailer [2832,2847]
trailer [2832,2847]
===
match
---
operator: { [11929,11930]
operator: { [11929,11930]
===
match
---
atom [69309,70064]
atom [69309,70064]
===
match
---
name: isinstance [57327,57337]
name: isinstance [57327,57337]
===
match
---
name: state [76352,76357]
name: state [76352,76357]
===
match
---
argument [15828,15847]
argument [15828,15847]
===
match
---
name: retries [64747,64754]
name: retries [64747,64754]
===
match
---
argument [61060,61079]
argument [61060,61079]
===
match
---
simple_stmt [66055,66073]
simple_stmt [66055,66073]
===
match
---
name: task_d [75430,75436]
name: task_d [75430,75436]
===
match
---
name: AirflowSkipException [1242,1262]
name: AirflowSkipException [1242,1262]
===
match
---
operator: , [32521,32522]
operator: , [32521,32522]
===
match
---
param [57964,57979]
param [57964,57979]
===
match
---
name: start_date [61511,61521]
name: start_date [61511,61521]
===
match
---
assert_stmt [64933,64970]
assert_stmt [64933,64970]
===
match
---
argument [52047,52076]
argument [52047,52076]
===
match
---
name: tearDown [77932,77940]
name: tearDown [77932,77940]
===
match
---
operator: , [12486,12487]
operator: , [12486,12487]
===
match
---
operator: , [27727,27728]
operator: , [27727,27728]
===
match
---
name: date [23058,23062]
name: date [23058,23062]
===
match
---
name: BashOperator [1516,1528]
name: BashOperator [1516,1528]
===
match
---
funcdef [21575,23137]
funcdef [21575,23137]
===
match
---
atom_expr [44331,44344]
atom_expr [44331,44344]
===
match
---
atom_expr [55414,55469]
atom_expr [55414,55469]
===
match
---
name: external_trigger [66708,66724]
name: external_trigger [66708,66724]
===
match
---
atom_expr [19772,19784]
atom_expr [19772,19784]
===
match
---
arith_expr [25780,25803]
arith_expr [25780,25803]
===
match
---
argument [13596,13625]
argument [13596,13625]
===
match
---
name: assert_queries_count [79415,79435]
name: assert_queries_count [79415,79435]
===
match
---
name: self [67233,67237]
name: self [67233,67237]
===
match
---
name: iter [12062,12066]
name: iter [12062,12066]
===
match
---
atom_expr [47351,47369]
atom_expr [47351,47369]
===
match
---
simple_stmt [12267,12352]
simple_stmt [12267,12352]
===
match
---
argument [20330,20379]
argument [20330,20379]
===
match
---
trailer [46561,46593]
trailer [46561,46593]
===
match
---
name: TI [10571,10573]
name: TI [10571,10573]
===
match
---
operator: , [16612,16613]
operator: , [16612,16613]
===
match
---
operator: -> [55142,55144]
operator: -> [55142,55144]
===
match
---
simple_stmt [20738,20765]
simple_stmt [20738,20765]
===
match
---
simple_stmt [45055,45081]
simple_stmt [45055,45081]
===
match
---
suite [19092,19114]
suite [19092,19114]
===
match
---
string: 'all_done' [33721,33731]
string: 'all_done' [33721,33731]
===
match
---
argument [18335,18367]
argument [18335,18367]
===
match
---
name: ti [34658,34660]
name: ti [34658,34660]
===
match
---
trailer [77832,77834]
trailer [77832,77834]
===
match
---
operator: = [34602,34603]
operator: = [34602,34603]
===
match
---
name: run_date [34593,34601]
name: run_date [34593,34601]
===
match
---
atom [70174,70462]
atom [70174,70462]
===
match
---
name: dag [15428,15431]
name: dag [15428,15431]
===
match
---
operator: = [40127,40128]
operator: = [40127,40128]
===
match
---
trailer [16573,16583]
trailer [16573,16583]
===
match
---
comparison [54056,54111]
comparison [54056,54111]
===
match
---
argument [46569,46592]
argument [46569,46592]
===
match
---
argument [20278,20285]
argument [20278,20285]
===
match
---
argument [25029,25061]
argument [25029,25061]
===
match
---
assert_stmt [31322,31354]
assert_stmt [31322,31354]
===
match
---
fstring_expr [34509,34512]
fstring_expr [34509,34512]
===
match
---
operator: , [53428,53429]
operator: , [53428,53429]
===
match
---
string: 'schedule_after_task_execution' [73053,73084]
string: 'schedule_after_task_execution' [73053,73084]
===
match
---
name: ti [25044,25046]
name: ti [25044,25046]
===
match
---
name: timezone [18277,18285]
name: timezone [18277,18285]
===
match
---
atom_expr [54782,54795]
atom_expr [54782,54795]
===
match
---
argument [64464,64505]
argument [64464,64505]
===
match
---
name: TI [65936,65938]
name: TI [65936,65938]
===
match
---
fstring_string: . [67105,67106]
fstring_string: . [67105,67106]
===
match
---
name: ti [22590,22592]
name: ti [22590,22592]
===
match
---
suite [7098,7122]
suite [7098,7122]
===
match
---
string: 'test_pool' [10801,10812]
string: 'test_pool' [10801,10812]
===
match
---
name: run [49476,49479]
name: run [49476,49479]
===
match
---
name: ti [30914,30916]
name: ti [30914,30916]
===
match
---
trailer [43862,43902]
trailer [43862,43902]
===
match
---
name: DummyOperator [44700,44713]
name: DummyOperator [44700,44713]
===
match
---
assert_stmt [45329,45392]
assert_stmt [45329,45392]
===
match
---
assert_stmt [65019,65087]
assert_stmt [65019,65087]
===
match
---
name: DummyOperator [13995,14008]
name: DummyOperator [13995,14008]
===
match
---
arglist [24826,24845]
arglist [24826,24845]
===
match
---
expr_stmt [26679,26704]
expr_stmt [26679,26704]
===
match
---
atom_expr [41402,41432]
atom_expr [41402,41432]
===
match
---
expr_stmt [67635,67682]
expr_stmt [67635,67682]
===
match
---
operator: = [65829,65830]
operator: = [65829,65830]
===
match
---
expr_stmt [34472,34540]
expr_stmt [34472,34540]
===
match
---
number: 0 [27752,27753]
number: 0 [27752,27753]
===
match
---
string: 'env' [19936,19941]
string: 'env' [19936,19941]
===
match
---
operator: = [42802,42803]
operator: = [42802,42803]
===
match
---
name: DagModel [73744,73752]
name: DagModel [73744,73752]
===
match
---
operator: , [40190,40191]
operator: , [40190,40191]
===
match
---
name: self [77964,77968]
name: self [77964,77968]
===
match
---
simple_stmt [60706,60837]
simple_stmt [60706,60837]
===
match
---
name: State [18487,18492]
name: State [18487,18492]
===
match
---
number: 0 [27015,27016]
number: 0 [27015,27016]
===
match
---
operator: , [35356,35357]
operator: , [35356,35357]
===
match
---
operator: = [41400,41401]
operator: = [41400,41401]
===
match
---
number: 2 [44310,44311]
number: 2 [44310,44311]
===
match
---
comparison [54924,55012]
comparison [54924,55012]
===
match
---
number: 0 [32967,32968]
number: 0 [32967,32968]
===
match
---
argument [60097,60124]
argument [60097,60124]
===
match
---
trailer [68887,68915]
trailer [68887,68915]
===
match
---
name: start_date [30999,31009]
name: start_date [30999,31009]
===
match
---
operator: , [18207,18208]
operator: , [18207,18208]
===
match
---
operator: = [42579,42580]
operator: = [42579,42580]
===
match
---
assert_stmt [37707,37729]
assert_stmt [37707,37729]
===
match
---
name: op1 [4220,4223]
name: op1 [4220,4223]
===
match
---
parameters [6309,6315]
parameters [6309,6315]
===
match
---
string: 'bar' [37871,37876]
string: 'bar' [37871,37876]
===
match
---
name: skipped [34015,34022]
name: skipped [34015,34022]
===
match
---
name: tis [16036,16039]
name: tis [16036,16039]
===
match
---
operator: , [18400,18401]
operator: , [18400,18401]
===
match
---
operator: = [45455,45456]
operator: = [45455,45456]
===
match
---
name: callback_ran [2694,2706]
name: callback_ran [2694,2706]
===
match
---
name: execution_date [18262,18276]
name: execution_date [18262,18276]
===
match
---
name: State [61902,61907]
name: State [61902,61907]
===
match
---
name: SUCCESS [13770,13777]
name: SUCCESS [13770,13777]
===
match
---
trailer [6362,6375]
trailer [6362,6375]
===
match
---
operator: , [33854,33855]
operator: , [33854,33855]
===
match
---
name: commit [13694,13700]
name: commit [13694,13700]
===
match
---
operator: , [33740,33741]
operator: , [33740,33741]
===
match
---
name: op_no_dag [6385,6394]
name: op_no_dag [6385,6394]
===
match
---
string: 'test-dag' [68184,68194]
string: 'test-dag' [68184,68194]
===
match
---
name: urllib [849,855]
name: urllib [849,855]
===
match
---
param [60323,60327]
param [60323,60327]
===
match
---
simple_stmt [67248,67295]
simple_stmt [67248,67295]
===
match
---
number: 2020 [76991,76995]
number: 2020 [76991,76995]
===
match
---
name: func [28257,28261]
name: func [28257,28261]
===
match
---
string: 'op_no_dag' [5520,5531]
string: 'op_no_dag' [5520,5531]
===
match
---
funcdef [24046,27977]
funcdef [24046,27977]
===
match
---
argument [50707,50719]
argument [50707,50719]
===
match
---
operator: , [71943,71944]
operator: , [71943,71944]
===
match
---
operator: << [8704,8706]
operator: << [8704,8706]
===
match
---
name: DummyOperator [61628,61641]
name: DummyOperator [61628,61641]
===
match
---
operator: , [72692,72693]
operator: , [72692,72693]
===
match
---
name: schedule_interval [61476,61493]
name: schedule_interval [61476,61493]
===
match
---
argument [76860,76932]
argument [76860,76932]
===
match
---
expr_stmt [16664,16694]
expr_stmt [16664,16694]
===
match
---
operator: , [59857,59858]
operator: , [59857,59858]
===
match
---
atom_expr [13995,14210]
atom_expr [13995,14210]
===
match
---
name: days [30746,30750]
name: days [30746,30750]
===
match
---
argument [15060,15069]
argument [15060,15069]
===
match
---
operator: = [56675,56676]
operator: = [56675,56676]
===
match
---
operator: , [10583,10584]
operator: , [10583,10584]
===
match
---
name: ti [41723,41725]
name: ti [41723,41725]
===
match
---
atom_expr [56469,56604]
atom_expr [56469,56604]
===
match
---
number: 0 [33366,33367]
number: 0 [33366,33367]
===
match
---
operator: = [23977,23978]
operator: = [23977,23978]
===
match
---
trailer [54011,54032]
trailer [54011,54032]
===
match
---
name: State [54161,54166]
name: State [54161,54166]
===
match
---
name: timezone [57062,57070]
name: timezone [57062,57070]
===
match
---
operator: = [27664,27665]
operator: = [27664,27665]
===
match
---
name: downstream [74424,74434]
name: downstream [74424,74434]
===
match
---
operator: = [76739,76740]
operator: = [76739,76740]
===
match
---
number: 0 [36984,36985]
number: 0 [36984,36985]
===
match
---
trailer [19428,19432]
trailer [19428,19432]
===
match
---
name: ti [10566,10568]
name: ti [10566,10568]
===
match
---
number: 1 [13220,13221]
number: 1 [13220,13221]
===
match
---
atom_expr [66169,66177]
atom_expr [66169,66177]
===
match
---
decorator [15192,15209]
decorator [15192,15209]
===
match
---
comparison [67539,67573]
comparison [67539,67573]
===
match
---
simple_stmt [38425,38446]
simple_stmt [38425,38446]
===
match
---
assert_stmt [48578,48612]
assert_stmt [48578,48612]
===
match
---
simple_stmt [16011,16059]
simple_stmt [16011,16059]
===
match
---
string: 'dag_id' [69718,69726]
string: 'dag_id' [69718,69726]
===
match
---
name: all_deps [11735,11743]
name: all_deps [11735,11743]
===
match
---
operator: , [32349,32350]
operator: , [32349,32350]
===
match
---
arglist [10574,10637]
arglist [10574,10637]
===
match
---
number: 5 [30751,30752]
number: 5 [30751,30752]
===
match
---
expr_stmt [61429,61522]
expr_stmt [61429,61522]
===
match
---
operator: = [40776,40777]
operator: = [40776,40777]
===
match
---
string: 'exit 1' [21867,21875]
string: 'exit 1' [21867,21875]
===
match
---
name: start_date [17298,17308]
name: start_date [17298,17308]
===
match
---
assert_stmt [25924,25963]
assert_stmt [25924,25963]
===
match
---
trailer [11964,11973]
trailer [11964,11973]
===
match
---
name: execution_date [9313,9327]
name: execution_date [9313,9327]
===
match
---
operator: = [46510,46511]
operator: = [46510,46511]
===
match
---
string: 'template: test_email_alert_with_config' [49710,49750]
string: 'template: test_email_alert_with_config' [49710,49750]
===
match
---
argument [78637,78666]
argument [78637,78666]
===
match
---
name: run_date [31029,31037]
name: run_date [31029,31037]
===
match
---
trailer [46969,46987]
trailer [46969,46987]
===
match
---
operator: , [27782,27783]
operator: , [27782,27783]
===
match
---
operator: , [4502,4503]
operator: , [4502,4503]
===
match
---
name: dag [13474,13477]
name: dag [13474,13477]
===
match
---
operator: = [23323,23324]
operator: = [23323,23324]
===
match
---
name: try_number [44275,44285]
name: try_number [44275,44285]
===
match
---
operator: = [17511,17512]
operator: = [17511,17512]
===
match
---
funcdef [42918,43444]
funcdef [42918,43444]
===
match
---
string: 'op_2' [4496,4502]
string: 'op_2' [4496,4502]
===
match
---
operator: , [69546,69547]
operator: , [69546,69547]
===
match
---
with_stmt [10708,10904]
with_stmt [10708,10904]
===
match
---
suite [68557,68644]
suite [68557,68644]
===
match
---
atom_expr [30126,30137]
atom_expr [30126,30137]
===
match
---
trailer [5411,5424]
trailer [5411,5424]
===
match
---
for_stmt [12190,12502]
for_stmt [12190,12502]
===
match
---
operator: , [63246,63247]
operator: , [63246,63247]
===
match
---
name: expected_state [25672,25686]
name: expected_state [25672,25686]
===
match
---
name: TI [60083,60085]
name: TI [60083,60085]
===
match
---
number: 2016 [17327,17331]
number: 2016 [17327,17331]
===
match
---
expr_stmt [24457,24857]
expr_stmt [24457,24857]
===
match
---
name: check_and_change_state_before_execution [43863,43902]
name: check_and_change_state_before_execution [43863,43902]
===
match
---
number: 1 [77000,77001]
number: 1 [77000,77001]
===
match
---
simple_stmt [30698,30754]
simple_stmt [30698,30754]
===
match
---
string: "KubernetesExecutor" [76877,76897]
string: "KubernetesExecutor" [76877,76897]
===
match
---
operator: = [62509,62510]
operator: = [62509,62510]
===
match
---
name: task [64124,64128]
name: task [64124,64128]
===
match
---
name: timedelta [28646,28655]
name: timedelta [28646,28655]
===
match
---
atom_expr [51623,51641]
atom_expr [51623,51641]
===
match
---
name: expected_are_dependents_done [36222,36250]
name: expected_are_dependents_done [36222,36250]
===
match
---
atom_expr [32532,32553]
atom_expr [32532,32553]
===
match
---
string: 'D' [72764,72767]
string: 'D' [72764,72767]
===
match
---
operator: = [30707,30708]
operator: = [30707,30708]
===
match
---
name: DAG [48994,48997]
name: DAG [48994,48997]
===
match
---
trailer [51419,51442]
trailer [51419,51442]
===
match
---
name: dag_id [38472,38478]
name: dag_id [38472,38478]
===
match
---
string: 'test_requeue_over_pool_concurrency_op' [10487,10526]
string: 'test_requeue_over_pool_concurrency_op' [10487,10526]
===
match
---
atom_expr [55589,55644]
atom_expr [55589,55644]
===
match
---
name: run [48424,48427]
name: run [48424,48427]
===
match
---
trailer [57504,57564]
trailer [57504,57564]
===
match
---
name: _run_raw_task [66928,66941]
name: _run_raw_task [66928,66941]
===
match
---
simple_stmt [66804,66829]
simple_stmt [66804,66829]
===
match
---
name: task_id [58202,58209]
name: task_id [58202,58209]
===
match
---
argument [65738,65764]
argument [65738,65764]
===
match
---
import_from [929,977]
import_from [929,977]
===
match
---
name: task_id [28453,28460]
name: task_id [28453,28460]
===
match
---
name: slots [10837,10842]
name: slots [10837,10842]
===
match
---
name: task_id [42001,42008]
name: task_id [42001,42008]
===
match
---
name: staticmethod [51536,51548]
name: staticmethod [51536,51548]
===
match
---
trailer [54204,54219]
trailer [54204,54219]
===
match
---
name: key [40605,40608]
name: key [40605,40608]
===
match
---
name: db [2387,2389]
name: db [2387,2389]
===
match
---
expr_stmt [56926,57111]
expr_stmt [56926,57111]
===
match
---
string: "{{ task.task_id }}" [68622,68642]
string: "{{ task.task_id }}" [68622,68642]
===
match
---
number: 0 [76537,76538]
number: 0 [76537,76538]
===
match
---
trailer [53626,53641]
trailer [53626,53641]
===
match
---
atom [32335,32401]
atom [32335,32401]
===
match
---
operator: = [7412,7413]
operator: = [7412,7413]
===
match
---
suite [51999,52396]
suite [51999,52396]
===
match
---
expr_stmt [56458,56604]
expr_stmt [56458,56604]
===
match
---
operator: = [16274,16275]
operator: = [16274,16275]
===
match
---
name: self [55249,55253]
name: self [55249,55253]
===
match
---
assert_stmt [48549,48569]
assert_stmt [48549,48569]
===
match
---
arglist [65738,65912]
arglist [65738,65912]
===
match
---
string: "{{ task.task_id }}" [69175,69195]
string: "{{ task.task_id }}" [69175,69195]
===
match
---
operator: = [20340,20341]
operator: = [20340,20341]
===
match
---
argument [66708,66730]
argument [66708,66730]
===
match
---
param [2743,2748]
param [2743,2748]
===
match
---
atom_expr [55845,55934]
atom_expr [55845,55934]
===
match
---
if_stmt [24314,24364]
if_stmt [24314,24364]
===
match
---
operator: , [78100,78101]
operator: , [78100,78101]
===
match
---
operator: = [7664,7665]
operator: = [7664,7665]
===
match
---
name: execution_date [40783,40797]
name: execution_date [40783,40797]
===
match
---
number: 1 [55560,55561]
number: 1 [55560,55561]
===
match
---
operator: , [42390,42391]
operator: , [42390,42391]
===
match
---
name: dag_id [67977,67983]
name: dag_id [67977,67983]
===
match
---
number: 0 [32158,32159]
number: 0 [32158,32159]
===
match
---
name: start_date [18920,18930]
name: start_date [18920,18930]
===
match
---
testlist_comp [59013,59062]
testlist_comp [59013,59062]
===
match
---
name: owner [8532,8537]
name: owner [8532,8537]
===
match
---
operator: , [33681,33682]
operator: , [33681,33682]
===
match
---
name: ti [17367,17369]
name: ti [17367,17369]
===
match
---
atom_expr [75341,75390]
atom_expr [75341,75390]
===
match
---
name: find_for_task_instance [25997,26019]
name: find_for_task_instance [25997,26019]
===
match
---
expr_stmt [3338,3387]
expr_stmt [3338,3387]
===
match
---
operator: , [13218,13219]
operator: , [13218,13219]
===
match
---
trailer [76397,76408]
trailer [76397,76408]
===
match
---
comparison [24970,24988]
comparison [24970,24988]
===
match
---
trailer [39044,39066]
trailer [39044,39066]
===
match
---
name: version [2312,2319]
name: version [2312,2319]
===
match
---
atom_expr [28308,28326]
atom_expr [28308,28326]
===
match
---
name: DEFAULT_DATE [35322,35334]
name: DEFAULT_DATE [35322,35334]
===
match
---
atom_expr [19600,19618]
atom_expr [19600,19618]
===
match
---
atom_expr [18685,18980]
atom_expr [18685,18980]
===
match
---
trailer [17055,17059]
trailer [17055,17059]
===
match
---
name: DEFAULT_DATE [65476,65488]
name: DEFAULT_DATE [65476,65488]
===
match
---
name: State [76314,76319]
name: State [76314,76319]
===
match
---
string: 'timedelta/catchup' [53028,53047]
string: 'timedelta/catchup' [53028,53047]
===
match
---
return_stmt [28339,28350]
return_stmt [28339,28350]
===
match
---
arglist [11443,11462]
arglist [11443,11462]
===
match
---
simple_stmt [22715,22747]
simple_stmt [22715,22747]
===
match
---
name: SKIPPED [33123,33130]
name: SKIPPED [33123,33130]
===
match
---
number: 0 [23709,23710]
number: 0 [23709,23710]
===
match
---
simple_stmt [46602,46646]
simple_stmt [46602,46646]
===
match
---
name: dag [14855,14858]
name: dag [14855,14858]
===
match
---
expr_stmt [13003,13242]
expr_stmt [13003,13242]
===
match
---
name: DEFAULT_DATE [60112,60124]
name: DEFAULT_DATE [60112,60124]
===
match
---
name: new_ti [71090,71096]
name: new_ti [71090,71096]
===
match
---
atom_expr [78902,78918]
atom_expr [78902,78918]
===
match
---
atom [48711,48852]
atom [48711,48852]
===
match
---
name: try_number [23034,23044]
name: try_number [23034,23044]
===
match
---
operator: = [28706,28707]
operator: = [28706,28707]
===
match
---
name: DummyOperator [43612,43625]
name: DummyOperator [43612,43625]
===
match
---
expr_stmt [7295,7307]
expr_stmt [7295,7307]
===
match
---
string: 'one_success' [32736,32749]
string: 'one_success' [32736,32749]
===
match
---
atom_expr [15978,16002]
atom_expr [15978,16002]
===
match
---
atom_expr [9647,9813]
atom_expr [9647,9813]
===
match
---
operator: == [60495,60497]
operator: == [60495,60497]
===
match
---
operator: = [60542,60543]
operator: = [60542,60543]
===
match
---
operator: , [34258,34259]
operator: , [34258,34259]
===
match
---
atom_expr [18387,18400]
atom_expr [18387,18400]
===
match
---
name: mock_on_retry_1 [61778,61793]
name: mock_on_retry_1 [61778,61793]
===
match
---
name: call_args [48531,48540]
name: call_args [48531,48540]
===
match
---
name: task [41474,41478]
name: task [41474,41478]
===
match
---
operator: = [43726,43727]
operator: = [43726,43727]
===
match
---
operator: , [59635,59636]
operator: , [59635,59636]
===
match
---
simple_stmt [29619,29663]
simple_stmt [29619,29663]
===
match
---
operator: , [27120,27121]
operator: , [27120,27121]
===
match
---
arglist [30579,30658]
arglist [30579,30658]
===
match
---
trailer [53608,53624]
trailer [53608,53624]
===
match
---
argument [7594,7613]
argument [7594,7613]
===
match
---
operator: != [54984,54986]
operator: != [54984,54986]
===
match
---
string: "prev_execution_date" [57522,57543]
string: "prev_execution_date" [57522,57543]
===
match
---
simple_stmt [76944,77004]
simple_stmt [76944,77004]
===
match
---
name: days [34641,34645]
name: days [34641,34645]
===
match
---
trailer [25638,25640]
trailer [25638,25640]
===
match
---
operator: == [19457,19459]
operator: == [19457,19459]
===
match
---
operator: , [50224,50225]
operator: , [50224,50225]
===
match
---
expr_stmt [75009,75038]
expr_stmt [75009,75038]
===
match
---
name: xcom_push [39035,39044]
name: xcom_push [39035,39044]
===
match
---
simple_stmt [41334,41350]
simple_stmt [41334,41350]
===
match
---
testlist_comp [73038,73413]
testlist_comp [73038,73413]
===
match
---
simple_stmt [23344,23729]
simple_stmt [23344,23729]
===
match
---
operator: , [30032,30033]
operator: , [30032,30033]
===
match
---
arglist [16174,16357]
arglist [16174,16357]
===
match
---
trailer [16673,16692]
trailer [16673,16692]
===
match
---
trailer [62597,62612]
trailer [62597,62612]
===
match
---
name: test_pendulum_template_dates [56882,56910]
name: test_pendulum_template_dates [56882,56910]
===
match
---
trailer [51290,51304]
trailer [51290,51304]
===
match
---
string: 'Europe/Brussels' [46525,46542]
string: 'Europe/Brussels' [46525,46542]
===
match
---
simple_stmt [62983,63018]
simple_stmt [62983,63018]
===
match
---
arglist [77029,77062]
arglist [77029,77062]
===
match
---
name: dag [46552,46555]
name: dag [46552,46555]
===
match
---
atom_expr [29948,29965]
atom_expr [29948,29965]
===
match
---
trailer [79435,79439]
trailer [79435,79439]
===
match
---
atom [32949,32996]
atom [32949,32996]
===
match
---
param [42392,42400]
param [42392,42400]
===
match
---
comparison [66169,66194]
comparison [66169,66194]
===
match
---
argument [18870,18877]
argument [18870,18877]
===
match
---
name: execution_date [78550,78564]
name: execution_date [78550,78564]
===
match
---
name: execution_date [58245,58259]
name: execution_date [58245,58259]
===
match
---
atom_expr [17429,17579]
atom_expr [17429,17579]
===
match
---
string: 'B' [72272,72275]
string: 'B' [72272,72275]
===
match
---
operator: == [29472,29474]
operator: == [29472,29474]
===
match
---
atom [7818,7861]
atom [7818,7861]
===
match
---
operator: = [23621,23622]
operator: = [23621,23622]
===
match
---
expr_stmt [47242,47270]
expr_stmt [47242,47270]
===
match
---
simple_stmt [26279,26325]
simple_stmt [26279,26325]
===
match
---
atom_expr [59621,59661]
atom_expr [59621,59661]
===
match
---
operator: = [62999,63000]
operator: = [62999,63000]
===
match
---
name: seconds [22865,22872]
name: seconds [22865,22872]
===
match
---
name: DEFAULT_DATE [5391,5403]
name: DEFAULT_DATE [5391,5403]
===
match
---
name: DEFAULT_DATE [9117,9129]
name: DEFAULT_DATE [9117,9129]
===
match
---
name: bash_command [68609,68621]
name: bash_command [68609,68621]
===
match
---
string: 'A' [72305,72308]
string: 'A' [72305,72308]
===
match
---
expr_stmt [79133,79157]
expr_stmt [79133,79157]
===
match
---
suite [35224,35934]
suite [35224,35934]
===
match
---
name: ti [78499,78501]
name: ti [78499,78501]
===
match
---
trailer [63325,63331]
trailer [63325,63331]
===
match
---
trailer [61399,61408]
trailer [61399,61408]
===
match
---
operator: == [67183,67185]
operator: == [67183,67185]
===
match
---
param [48949,48954]
param [48949,48954]
===
match
---
atom_expr [14224,14271]
atom_expr [14224,14271]
===
match
---
atom_expr [40093,40293]
atom_expr [40093,40293]
===
match
---
name: filter [10781,10787]
name: filter [10781,10787]
===
match
---
trailer [47932,47967]
trailer [47932,47967]
===
match
---
atom_expr [61308,61316]
atom_expr [61308,61316]
===
match
---
string: 'all_failed' [32950,32962]
string: 'all_failed' [32950,32962]
===
match
---
name: task [36472,36476]
name: task [36472,36476]
===
match
---
operator: = [76847,76848]
operator: = [76847,76848]
===
match
---
trailer [66757,66795]
trailer [66757,66795]
===
match
---
operator: = [7118,7119]
operator: = [7118,7119]
===
match
---
operator: , [26799,26800]
operator: , [26799,26800]
===
match
---
funcdef [48916,49759]
funcdef [48916,49759]
===
match
---
funcdef [13783,14519]
funcdef [13783,14519]
===
match
---
string: 'B' [72396,72399]
string: 'B' [72396,72399]
===
match
---
trailer [12898,12913]
trailer [12898,12913]
===
match
---
import_name [995,1008]
import_name [995,1008]
===
match
---
name: pool [14876,14880]
name: pool [14876,14880]
===
match
---
trailer [2880,2903]
trailer [2880,2903]
===
match
---
name: days [4651,4655]
name: days [4651,4655]
===
match
---
atom_expr [68662,68708]
atom_expr [68662,68708]
===
match
---
atom_expr [69134,69196]
atom_expr [69134,69196]
===
match
---
name: task [44207,44211]
name: task [44207,44211]
===
match
---
simple_stmt [66981,67062]
simple_stmt [66981,67062]
===
match
---
name: TI [9299,9301]
name: TI [9299,9301]
===
match
---
trailer [21089,21095]
trailer [21089,21095]
===
match
---
atom_expr [60983,61162]
atom_expr [60983,61162]
===
match
---
operator: = [28663,28664]
operator: = [28663,28664]
===
match
---
operator: , [50719,50720]
operator: , [50719,50720]
===
match
---
name: TI [14224,14226]
name: TI [14224,14226]
===
match
---
number: 0 [31696,31697]
number: 0 [31696,31697]
===
match
---
name: dag [9896,9899]
name: dag [9896,9899]
===
match
---
operator: , [11450,11451]
operator: , [11450,11451]
===
match
---
name: ti [22364,22366]
name: ti [22364,22366]
===
match
---
trailer [56069,56077]
trailer [56069,56077]
===
match
---
name: timedelta [5308,5317]
name: timedelta [5308,5317]
===
match
---
param [73534,73551]
param [73534,73551]
===
match
---
number: 5 [31690,31691]
number: 5 [31690,31691]
===
match
---
funcdef [63695,63758]
funcdef [63695,63758]
===
match
---
operator: , [32187,32188]
operator: , [32187,32188]
===
match
---
name: DEFAULT_DATE [59648,59660]
name: DEFAULT_DATE [59648,59660]
===
match
---
number: 0 [33028,33029]
number: 0 [33028,33029]
===
match
---
number: 60 [21705,21707]
number: 60 [21705,21707]
===
match
---
expr_stmt [35380,35462]
expr_stmt [35380,35462]
===
match
---
name: DEFAULT_DATE [76055,76067]
name: DEFAULT_DATE [76055,76067]
===
match
---
name: TI [5546,5548]
name: TI [5546,5548]
===
match
---
simple_stmt [2390,2448]
simple_stmt [2390,2448]
===
match
---
name: _get_dep_statuses [11947,11964]
name: _get_dep_statuses [11947,11964]
===
match
---
expr_stmt [73615,73643]
expr_stmt [73615,73643]
===
match
---
operator: = [74802,74803]
operator: = [74802,74803]
===
match
---
trailer [15839,15847]
trailer [15839,15847]
===
match
---
number: 1 [27641,27642]
number: 1 [27641,27642]
===
match
---
name: completed [35042,35051]
name: completed [35042,35051]
===
match
---
atom_expr [11857,11879]
atom_expr [11857,11879]
===
match
---
name: ti_list [54820,54827]
name: ti_list [54820,54827]
===
match
---
simple_stmt [2284,2320]
simple_stmt [2284,2320]
===
match
---
name: pytest [15119,15125]
name: pytest [15119,15125]
===
match
---
operator: != [54299,54301]
operator: != [54299,54301]
===
match
---
name: render_template [58340,58355]
name: render_template [58340,58355]
===
match
---
assert_stmt [30213,30239]
assert_stmt [30213,30239]
===
match
---
arglist [63061,63247]
arglist [63061,63247]
===
match
---
name: dependencies_states [1937,1956]
name: dependencies_states [1937,1956]
===
match
---
atom_expr [74550,74581]
atom_expr [74550,74581]
===
match
---
name: start_date [70969,70979]
name: start_date [70969,70979]
===
match
---
expr_stmt [74196,74265]
expr_stmt [74196,74265]
===
match
---
assert_stmt [59876,59908]
assert_stmt [59876,59908]
===
match
---
arglist [14227,14270]
arglist [14227,14270]
===
match
---
operator: = [56383,56384]
operator: = [56383,56384]
===
match
---
name: task [62514,62518]
name: task [62514,62518]
===
match
---
argument [74220,74231]
argument [74220,74231]
===
match
---
name: mark_success [68038,68050]
name: mark_success [68038,68050]
===
match
---
operator: = [22841,22842]
operator: = [22841,22842]
===
match
---
name: airflow [1534,1541]
name: airflow [1534,1541]
===
match
---
name: TaskInstance [1425,1437]
name: TaskInstance [1425,1437]
===
match
---
name: start_date [4402,4412]
name: start_date [4402,4412]
===
match
---
funcdef [7374,8363]
funcdef [7374,8363]
===
match
---
name: state [9983,9988]
name: state [9983,9988]
===
match
---
argument [24605,24625]
argument [24605,24625]
===
match
---
operator: , [26930,26931]
operator: , [26930,26931]
===
match
---
name: TI [57209,57211]
name: TI [57209,57211]
===
match
---
name: TriggerRuleDep [2087,2101]
name: TriggerRuleDep [2087,2101]
===
match
---
name: now [46506,46509]
name: now [46506,46509]
===
match
---
atom_expr [61923,61966]
atom_expr [61923,61966]
===
match
---
comparison [56849,56872]
comparison [56849,56872]
===
match
---
expr_stmt [51708,51738]
expr_stmt [51708,51738]
===
match
---
assert_stmt [19753,19784]
assert_stmt [19753,19784]
===
match
---
arglist [8858,8888]
arglist [8858,8888]
===
match
---
comparison [50358,50377]
comparison [50358,50377]
===
match
---
name: DAG [36852,36855]
name: DAG [36852,36855]
===
match
---
argument [69225,69252]
argument [69225,69252]
===
match
---
operator: == [4395,4397]
operator: == [4395,4397]
===
match
---
arglist [15697,15740]
arglist [15697,15740]
===
match
---
name: DummyOperator [6846,6859]
name: DummyOperator [6846,6859]
===
match
---
atom_expr [7073,7097]
atom_expr [7073,7097]
===
match
---
expr_stmt [73657,73718]
expr_stmt [73657,73718]
===
match
---
name: dag [73777,73780]
name: dag [73777,73780]
===
match
---
arglist [26731,26784]
arglist [26731,26784]
===
match
---
name: pod_spec [71233,71241]
name: pod_spec [71233,71241]
===
match
---
operator: = [24401,24402]
operator: = [24401,24402]
===
match
---
expr_stmt [62182,62218]
expr_stmt [62182,62218]
===
match
---
assert_stmt [77403,77452]
assert_stmt [77403,77452]
===
match
---
argument [18145,18160]
argument [18145,18160]
===
match
---
annassign [2667,2689]
annassign [2667,2689]
===
match
---
argument [34886,34899]
argument [34886,34899]
===
match
---
name: mark_success [13718,13730]
name: mark_success [13718,13730]
===
match
---
trailer [51155,51165]
trailer [51155,51165]
===
match
---
operator: , [53320,53321]
operator: , [53320,53321]
===
match
---
atom_expr [4160,4203]
atom_expr [4160,4203]
===
match
---
atom [71793,71813]
atom [71793,71813]
===
match
---
string: 'all_failed' [33011,33023]
string: 'all_failed' [33011,33023]
===
match
---
comparison [39520,39572]
comparison [39520,39572]
===
match
---
name: dag [76027,76030]
name: dag [76027,76030]
===
match
---
name: schedule_interval [54433,54450]
name: schedule_interval [54433,54450]
===
match
---
argument [13037,13088]
argument [13037,13088]
===
match
---
arith_expr [23113,23136]
arith_expr [23113,23136]
===
match
---
number: 2 [18209,18210]
number: 2 [18209,18210]
===
match
---
operator: == [64959,64961]
operator: == [64959,64961]
===
match
---
trailer [17317,17326]
trailer [17317,17326]
===
match
---
param [73485,73490]
param [73485,73490]
===
match
---
name: task [80201,80205]
name: task [80201,80205]
===
match
---
name: bash_command [68269,68281]
name: bash_command [68269,68281]
===
match
---
expr_stmt [12034,12117]
expr_stmt [12034,12117]
===
match
---
operator: , [43730,43731]
operator: , [43730,43731]
===
match
---
operator: = [49153,49154]
operator: = [49153,49154]
===
match
---
operator: , [8597,8598]
operator: , [8597,8598]
===
match
---
name: session [79171,79178]
name: session [79171,79178]
===
match
---
name: end_date [4833,4841]
name: end_date [4833,4841]
===
match
---
operator: { [48711,48712]
operator: { [48711,48712]
===
match
---
name: SUCCESS [14511,14518]
name: SUCCESS [14511,14518]
===
match
---
operator: { [47561,47562]
operator: { [47561,47562]
===
match
---
arglist [27589,27642]
arglist [27589,27642]
===
match
---
name: on_execute_callback [60778,60797]
name: on_execute_callback [60778,60797]
===
match
---
name: dag [63243,63246]
name: dag [63243,63246]
===
match
---
operator: = [41419,41420]
operator: = [41419,41420]
===
match
---
simple_stmt [68570,68644]
simple_stmt [68570,68644]
===
match
---
operator: = [65549,65550]
operator: = [65549,65550]
===
match
---
name: task2 [37329,37334]
name: task2 [37329,37334]
===
match
---
operator: = [47810,47811]
operator: = [47810,47811]
===
match
---
name: ti_list [53985,53992]
name: ti_list [53985,53992]
===
match
---
operator: = [6214,6215]
operator: = [6214,6215]
===
match
---
name: period [24034,24040]
name: period [24034,24040]
===
match
---
operator: , [52498,52499]
operator: , [52498,52499]
===
match
---
trailer [61907,61914]
trailer [61907,61914]
===
match
---
name: dag [43525,43528]
name: dag [43525,43528]
===
match
---
trailer [4223,4234]
trailer [4223,4234]
===
match
---
name: ti [21177,21179]
name: ti [21177,21179]
===
match
---
atom_expr [22689,22702]
atom_expr [22689,22702]
===
match
---
simple_stmt [1009,1043]
simple_stmt [1009,1043]
===
match
---
trailer [77010,77028]
trailer [77010,77028]
===
match
---
simple_stmt [62682,62720]
simple_stmt [62682,62720]
===
match
---
name: task_instance_a [74831,74846]
name: task_instance_a [74831,74846]
===
match
---
operator: = [14983,14984]
operator: = [14983,14984]
===
match
---
string: """         tests xcom fetch behavior with different execution dates, using         both xcom_pull with "include_prior_dates" and without         """ [39798,39947]
string: """         tests xcom fetch behavior with different execution dates, using         both xcom_pull with "include_prior_dates" and without         """ [39798,39947]
===
match
---
testlist_comp [53307,53349]
testlist_comp [53307,53349]
===
match
---
name: dag [60538,60541]
name: dag [60538,60541]
===
match
---
number: 0 [33677,33678]
number: 0 [33677,33678]
===
match
---
atom [71687,73438]
atom [71687,73438]
===
match
---
atom_expr [55376,55389]
atom_expr [55376,55389]
===
match
---
operator: , [54518,54519]
operator: , [54518,54519]
===
match
---
argument [60086,60095]
argument [60086,60095]
===
match
---
argument [71031,71044]
argument [71031,71044]
===
match
---
comparison [29509,29546]
comparison [29509,29546]
===
match
---
name: run [39460,39463]
name: run [39460,39463]
===
match
---
name: call_args [62047,62056]
name: call_args [62047,62056]
===
match
---
name: task_id [8645,8652]
name: task_id [8645,8652]
===
match
---
arglist [35588,35686]
arglist [35588,35686]
===
match
---
operator: , [41699,41700]
operator: , [41699,41700]
===
match
---
operator: , [46178,46179]
operator: , [46178,46179]
===
match
---
atom_expr [3631,3660]
atom_expr [3631,3660]
===
match
---
argument [49176,49199]
argument [49176,49199]
===
match
---
string: 'expected error.' [42489,42506]
string: 'expected error.' [42489,42506]
===
match
---
atom_expr [75477,75492]
atom_expr [75477,75492]
===
match
---
name: task_id [4174,4181]
name: task_id [4174,4181]
===
match
---
expr_stmt [50487,50664]
expr_stmt [50487,50664]
===
match
---
name: ti [61185,61187]
name: ti [61185,61187]
===
match
---
name: get_previous_ti [53996,54011]
name: get_previous_ti [53996,54011]
===
match
---
trailer [67097,67104]
trailer [67097,67104]
===
match
---
atom_expr [79144,79157]
atom_expr [79144,79157]
===
match
---
trailer [72386,72394]
trailer [72386,72394]
===
match
---
string: 'C' [71868,71871]
string: 'C' [71868,71871]
===
match
---
string: 'test_depends_on_past' [30487,30509]
string: 'test_depends_on_past' [30487,30509]
===
match
---
operator: , [66765,66766]
operator: , [66765,66766]
===
match
---
argument [9901,9919]
argument [9901,9919]
===
match
---
expr_stmt [23300,23335]
expr_stmt [23300,23335]
===
match
---
simple_stmt [24457,24858]
simple_stmt [24457,24858]
===
match
---
operator: , [5728,5729]
operator: , [5728,5729]
===
match
---
operator: = [43118,43119]
operator: = [43118,43119]
===
match
---
name: DAG [43538,43541]
name: DAG [43538,43541]
===
match
---
name: new_task [71007,71015]
name: new_task [71007,71015]
===
match
---
suite [77900,77923]
suite [77900,77923]
===
match
---
name: ti1 [37945,37948]
name: ti1 [37945,37948]
===
match
---
name: test_requeue_over_dag_concurrency [8898,8931]
name: test_requeue_over_dag_concurrency [8898,8931]
===
match
---
parameters [36194,36251]
parameters [36194,36251]
===
match
---
simple_stmt [66874,66892]
simple_stmt [66874,66892]
===
match
---
atom_expr [11913,11927]
atom_expr [11913,11927]
===
match
---
name: set_downstream [8097,8111]
name: set_downstream [8097,8111]
===
match
---
name: create_dagrun [17433,17446]
name: create_dagrun [17433,17446]
===
match
---
operator: } [70653,70654]
operator: } [70653,70654]
===
match
---
name: dag_run [74769,74776]
name: dag_run [74769,74776]
===
match
---
atom_expr [55172,55184]
atom_expr [55172,55184]
===
match
---
name: ti [76395,76397]
name: ti [76395,76397]
===
match
---
operator: = [9212,9213]
operator: = [9212,9213]
===
match
---
name: retry_delay [20223,20234]
name: retry_delay [20223,20234]
===
match
---
name: state [18507,18512]
name: state [18507,18512]
===
match
---
trailer [42593,42790]
trailer [42593,42790]
===
match
---
operator: = [60142,60143]
operator: = [60142,60143]
===
match
---
name: session [9510,9517]
name: session [9510,9517]
===
match
---
number: 3 [33551,33552]
number: 3 [33551,33552]
===
match
---
argument [44207,44216]
argument [44207,44216]
===
match
---
arglist [40348,40383]
arglist [40348,40383]
===
match
---
operator: , [46816,46817]
operator: , [46816,46817]
===
match
---
argument [66767,66794]
argument [66767,66794]
===
match
---
name: self [42386,42390]
name: self [42386,42390]
===
match
---
argument [43149,43158]
argument [43149,43158]
===
match
---
simple_stmt [43787,43841]
simple_stmt [43787,43841]
===
match
---
trailer [61566,61568]
trailer [61566,61568]
===
match
---
operator: = [76875,76876]
operator: = [76875,76876]
===
match
---
simple_stmt [12929,12995]
simple_stmt [12929,12995]
===
match
---
tfpdef [51650,51663]
tfpdef [51650,51663]
===
match
---
name: ti3 [44997,45000]
name: ti3 [44997,45000]
===
match
---
trailer [7014,7025]
trailer [7014,7025]
===
match
---
trailer [22104,22125]
trailer [22104,22125]
===
match
---
number: 0 [33437,33438]
number: 0 [33437,33438]
===
match
---
atom_expr [3691,3706]
atom_expr [3691,3706]
===
match
---
name: int [34075,34078]
name: int [34075,34078]
===
match
---
name: ti [78565,78567]
name: ti [78565,78567]
===
match
---
atom_expr [47762,47789]
atom_expr [47762,47789]
===
match
---
number: 0 [32594,32595]
number: 0 [32594,32595]
===
match
---
atom_expr [40314,40331]
atom_expr [40314,40331]
===
match
---
with_item [78216,78243]
with_item [78216,78243]
===
match
---
operator: , [33314,33315]
operator: , [33314,33315]
===
match
---
string: 'A' [72711,72714]
string: 'A' [72711,72714]
===
match
---
number: 0 [64065,64066]
number: 0 [64065,64066]
===
match
---
operator: , [63926,63927]
operator: , [63926,63927]
===
match
---
trailer [71498,71504]
trailer [71498,71504]
===
match
---
expr_stmt [5989,6035]
expr_stmt [5989,6035]
===
match
---
simple_stmt [3902,3918]
simple_stmt [3902,3918]
===
match
---
name: key [39956,39959]
name: key [39956,39959]
===
match
---
trailer [28935,28946]
trailer [28935,28946]
===
match
---
trailer [74450,74456]
trailer [74450,74456]
===
match
---
string: """         Test that retry delays are respected         """ [18554,18614]
string: """         Test that retry delays are respected         """ [18554,18614]
===
match
---
name: datetime [20350,20358]
name: datetime [20350,20358]
===
match
---
operator: = [9116,9117]
operator: = [9116,9117]
===
match
---
operator: , [33171,33172]
operator: , [33171,33172]
===
match
---
name: expect_completed [34172,34188]
name: expect_completed [34172,34188]
===
match
---
try_stmt [19026,19114]
try_stmt [19026,19114]
===
match
---
name: int [34045,34048]
name: int [34045,34048]
===
match
---
trailer [66036,66044]
trailer [66036,66044]
===
match
---
trailer [8001,8016]
trailer [8001,8016]
===
match
---
string: 'error' [42444,42451]
string: 'error' [42444,42451]
===
match
---
atom_expr [4347,4364]
atom_expr [4347,4364]
===
match
---
simple_stmt [27798,27871]
simple_stmt [27798,27871]
===
match
---
name: TI [60850,60852]
name: TI [60850,60852]
===
match
---
name: session [9482,9489]
name: session [9482,9489]
===
match
---
name: dag [61807,61810]
name: dag [61807,61810]
===
match
---
trailer [73752,73878]
trailer [73752,73878]
===
match
---
trailer [41408,41412]
trailer [41408,41412]
===
match
---
trailer [31209,31284]
trailer [31209,31284]
===
match
---
name: isoformat [67403,67412]
name: isoformat [67403,67412]
===
match
---
atom_expr [44365,44378]
atom_expr [44365,44378]
===
match
---
comparison [80278,80312]
comparison [80278,80312]
===
match
---
suite [15151,15187]
suite [15151,15187]
===
match
---
name: op2 [8770,8773]
name: op2 [8770,8773]
===
match
---
string: 'test-dag' [59625,59635]
string: 'test-dag' [59625,59635]
===
match
---
string: '{{ var.json.get("missing_variable", {"a": {"test": "fallback"}})["a"]["test"] }}' [59258,59340]
string: '{{ var.json.get("missing_variable", {"a": {"test": "fallback"}})["a"]["test"] }}' [59258,59340]
===
match
---
simple_stmt [16632,16656]
simple_stmt [16632,16656]
===
match
---
trailer [75554,75556]
trailer [75554,75556]
===
match
---
operator: , [70435,70436]
operator: , [70435,70436]
===
match
---
operator: , [69828,69829]
operator: , [69828,69829]
===
match
---
number: 1 [50070,50071]
number: 1 [50070,50071]
===
match
---
name: DEFAULT_DATE [45033,45045]
name: DEFAULT_DATE [45033,45045]
===
match
---
name: ti [24867,24869]
name: ti [24867,24869]
===
match
---
operator: = [37838,37839]
operator: = [37838,37839]
===
match
---
name: schedule_interval [38492,38509]
name: schedule_interval [38492,38509]
===
match
---
argument [66381,66432]
argument [66381,66432]
===
match
---
exprlist [71455,71478]
exprlist [71455,71478]
===
match
---
name: ti [44365,44367]
name: ti [44365,44367]
===
match
---
name: test_log_url [46031,46043]
name: test_log_url [46031,46043]
===
match
---
name: processor_agent [75906,75921]
name: processor_agent [75906,75921]
===
match
---
trailer [46715,46721]
trailer [46715,46721]
===
match
---
string: 'True' [71768,71774]
string: 'True' [71768,71774]
===
match
---
operator: , [15015,15016]
operator: , [15015,15016]
===
match
---
arglist [27704,27753]
arglist [27704,27753]
===
match
---
name: execution_date [65948,65962]
name: execution_date [65948,65962]
===
match
---
operator: , [49162,49163]
operator: , [49162,49163]
===
match
---
name: task_id [41517,41524]
name: task_id [41517,41524]
===
match
---
operator: , [14833,14834]
operator: , [14833,14834]
===
match
---
simple_stmt [6789,6833]
simple_stmt [6789,6833]
===
match
---
atom_expr [15834,15847]
atom_expr [15834,15847]
===
match
---
operator: = [2808,2809]
operator: = [2808,2809]
===
match
---
argument [40673,40680]
argument [40673,40680]
===
match
---
operator: = [59723,59724]
operator: = [59723,59724]
===
match
---
name: execution_date [68680,68694]
name: execution_date [68680,68694]
===
match
---
trailer [75468,75474]
trailer [75468,75474]
===
match
---
name: start_date [22076,22086]
name: start_date [22076,22086]
===
match
---
number: 0 [64068,64069]
number: 0 [64068,64069]
===
match
---
name: class_name [12141,12151]
name: class_name [12141,12151]
===
match
---
suite [29380,29411]
suite [29380,29411]
===
match
---
trailer [25662,25668]
trailer [25662,25668]
===
match
---
expr_stmt [78447,78471]
expr_stmt [78447,78471]
===
match
---
name: RUNNING [56546,56553]
name: RUNNING [56546,56553]
===
match
---
string: 'test@test.test' [50232,50248]
string: 'test@test.test' [50232,50248]
===
match
---
simple_stmt [57204,57257]
simple_stmt [57204,57257]
===
match
---
operator: = [10306,10307]
operator: = [10306,10307]
===
match
---
operator: , [32249,32250]
operator: , [32249,32250]
===
match
---
expr_stmt [46161,46225]
expr_stmt [46161,46225]
===
match
---
atom_expr [51446,51459]
atom_expr [51446,51459]
===
match
---
operator: = [30586,30587]
operator: = [30586,30587]
===
match
---
name: pool [38618,38622]
name: pool [38618,38622]
===
match
---
operator: = [58290,58291]
operator: = [58290,58291]
===
match
---
argument [42739,42779]
argument [42739,42779]
===
match
---
name: task [78320,78324]
name: task [78320,78324]
===
match
---
atom_expr [7465,7501]
atom_expr [7465,7501]
===
match
---
name: start_date [68196,68206]
name: start_date [68196,68206]
===
match
---
operator: , [59340,59341]
operator: , [59340,59341]
===
match
---
param [53755,53760]
param [53755,53760]
===
match
---
operator: = [44698,44699]
operator: = [44698,44699]
===
match
---
argument [58143,58166]
argument [58143,58166]
===
match
---
atom_expr [22233,22250]
atom_expr [22233,22250]
===
match
---
expr_stmt [67925,68065]
expr_stmt [67925,68065]
===
match
---
operator: = [30836,30837]
operator: = [30836,30837]
===
match
---
argument [65889,65911]
argument [65889,65911]
===
match
---
trailer [10286,10449]
trailer [10286,10449]
===
match
---
number: 2 [38715,38716]
number: 2 [38715,38716]
===
match
---
name: context_arg_3 [63567,63580]
name: context_arg_3 [63567,63580]
===
match
---
trailer [43385,43391]
trailer [43385,43391]
===
match
---
operator: = [20566,20567]
operator: = [20566,20567]
===
match
---
name: execution_date [16493,16507]
name: execution_date [16493,16507]
===
match
---
argument [79027,79039]
argument [79027,79039]
===
match
---
name: ti [40764,40766]
name: ti [40764,40766]
===
match
---
atom_expr [67050,67058]
atom_expr [67050,67058]
===
match
---
argument [15861,15890]
argument [15861,15890]
===
match
---
atom_expr [21418,21432]
atom_expr [21418,21432]
===
match
---
operator: , [8355,8356]
operator: , [8355,8356]
===
match
---
name: run [10174,10177]
name: run [10174,10177]
===
match
---
trailer [53903,53930]
trailer [53903,53930]
===
match
---
operator: , [34005,34006]
operator: , [34005,34006]
===
match
---
name: State [27613,27618]
name: State [27613,27618]
===
match
---
operator: == [65052,65054]
operator: == [65052,65054]
===
match
---
atom_expr [56677,56717]
atom_expr [56677,56717]
===
match
---
argument [24639,24648]
argument [24639,24648]
===
match
---
operator: = [52562,52563]
operator: = [52562,52563]
===
match
---
trailer [22095,22104]
trailer [22095,22104]
===
match
---
trailer [79342,79352]
trailer [79342,79352]
===
match
---
trailer [4650,4659]
trailer [4650,4659]
===
match
---
operator: , [31937,31938]
operator: , [31937,31938]
===
match
---
name: DagRunType [51145,51155]
name: DagRunType [51145,51155]
===
match
---
assert_stmt [47651,47685]
assert_stmt [47651,47685]
===
match
---
name: state [20874,20879]
name: state [20874,20879]
===
match
---
operator: = [56005,56006]
operator: = [56005,56006]
===
match
---
argument [75367,75389]
argument [75367,75389]
===
match
---
trailer [53516,53519]
trailer [53516,53519]
===
match
---
string: 'test_run_pooling_task' [13955,13978]
string: 'test_run_pooling_task' [13955,13978]
===
match
---
name: timezone [20341,20349]
name: timezone [20341,20349]
===
match
---
name: DEFAULT_DATE [44750,44762]
name: DEFAULT_DATE [44750,44762]
===
match
---
trailer [54063,54066]
trailer [54063,54066]
===
match
---
operator: = [12452,12453]
operator: = [12452,12453]
===
match
---
operator: = [65905,65906]
operator: = [65905,65906]
===
match
---
operator: , [23704,23705]
operator: , [23704,23705]
===
match
---
operator: = [21722,21723]
operator: = [21722,21723]
===
match
---
operator: = [39290,39291]
operator: = [39290,39291]
===
match
---
name: downstream [34331,34341]
name: downstream [34331,34341]
===
match
---
simple_stmt [19487,19513]
simple_stmt [19487,19513]
===
match
---
atom_expr [36055,36068]
atom_expr [36055,36068]
===
match
---
name: DAG [13944,13947]
name: DAG [13944,13947]
===
match
---
atom_expr [73156,73168]
atom_expr [73156,73168]
===
match
---
trailer [5782,5798]
trailer [5782,5798]
===
match
---
atom_expr [50042,50075]
atom_expr [50042,50075]
===
match
---
name: class_name [12194,12204]
name: class_name [12194,12204]
===
match
---
operator: , [40269,40270]
operator: , [40269,40270]
===
match
---
name: dagbag [74608,74614]
name: dagbag [74608,74614]
===
match
---
name: ti [68780,68782]
name: ti [68780,68782]
===
match
---
simple_stmt [65931,65977]
simple_stmt [65931,65977]
===
match
---
expr_stmt [22917,22934]
expr_stmt [22917,22934]
===
match
---
classdef [3390,76539]
classdef [3390,76539]
===
match
---
name: dag [44734,44737]
name: dag [44734,44737]
===
match
---
testlist_comp [32202,32248]
testlist_comp [32202,32248]
===
match
---
argument [34300,34321]
argument [34300,34321]
===
match
---
name: task [48355,48359]
name: task [48355,48359]
===
match
---
name: email [60754,60759]
name: email [60754,60759]
===
match
---
simple_stmt [65019,65088]
simple_stmt [65019,65088]
===
match
---
trailer [57079,57100]
trailer [57079,57100]
===
match
---
operator: = [6766,6767]
operator: = [6766,6767]
===
match
---
name: models [17923,17929]
name: models [17923,17929]
===
match
---
name: AirflowException [28308,28324]
name: AirflowException [28308,28324]
===
match
---
name: ret [52558,52561]
name: ret [52558,52561]
===
match
---
argument [56567,56593]
argument [56567,56593]
===
match
---
comparison [23105,23136]
comparison [23105,23136]
===
match
---
dictorsetmaker [70575,70629]
dictorsetmaker [70575,70629]
===
match
---
operator: @ [48034,48035]
operator: @ [48034,48035]
===
match
---
operator: = [67311,67312]
operator: = [67311,67312]
===
match
---
with_stmt [7068,7122]
with_stmt [7068,7122]
===
match
---
string: 'test_dop_task' [30587,30602]
string: 'test_dop_task' [30587,30602]
===
match
---
operator: == [46444,46446]
operator: == [46444,46446]
===
match
---
trailer [75905,75921]
trailer [75905,75921]
===
match
---
argument [54155,54174]
argument [54155,54174]
===
match
---
expr_stmt [37408,37454]
expr_stmt [37408,37454]
===
match
---
operator: = [13158,13159]
operator: = [13158,13159]
===
match
---
name: State [50940,50945]
name: State [50940,50945]
===
match
---
number: 1 [18800,18801]
number: 1 [18800,18801]
===
match
---
trailer [44248,44250]
trailer [44248,44250]
===
match
---
argument [63961,63981]
argument [63961,63981]
===
match
---
name: object [8851,8857]
name: object [8851,8857]
===
match
---
argument [13559,13578]
argument [13559,13578]
===
match
---
argument [24875,24884]
argument [24875,24884]
===
match
---
name: ti2 [45341,45344]
name: ti2 [45341,45344]
===
match
---
operator: , [40272,40273]
operator: , [40272,40273]
===
match
---
dotted_name [1095,1117]
dotted_name [1095,1117]
===
match
---
trailer [5234,5244]
trailer [5234,5244]
===
match
---
arglist [8578,8611]
arglist [8578,8611]
===
match
---
operator: = [48513,48514]
operator: = [48513,48514]
===
match
---
name: commit [11646,11652]
name: commit [11646,11652]
===
match
---
operator: = [62571,62572]
operator: = [62571,62572]
===
match
---
operator: = [66753,66754]
operator: = [66753,66754]
===
match
---
name: QUEUED [9995,10001]
name: QUEUED [9995,10001]
===
match
---
expr_stmt [57120,57194]
expr_stmt [57120,57194]
===
match
---
suite [42084,42913]
suite [42084,42913]
===
match
---
name: dag [30620,30623]
name: dag [30620,30623]
===
match
---
expr_stmt [34696,35033]
expr_stmt [34696,35033]
===
match
---
atom_expr [26085,26093]
atom_expr [26085,26093]
===
match
---
name: get_num_running_task_instances [45417,45447]
name: get_num_running_task_instances [45417,45447]
===
match
---
name: raise_skip_exception [18111,18131]
name: raise_skip_exception [18111,18131]
===
match
---
trailer [51679,51684]
trailer [51679,51684]
===
match
---
operator: , [55131,55132]
operator: , [55131,55132]
===
match
---
name: params [47318,47324]
name: params [47318,47324]
===
match
---
name: execution_date [24886,24900]
name: execution_date [24886,24900]
===
match
---
operator: == [44362,44364]
operator: == [44362,44364]
===
match
---
operator: , [68957,68958]
operator: , [68957,68958]
===
match
---
atom [76876,76932]
atom [76876,76932]
===
match
---
name: MagicMock [61600,61609]
name: MagicMock [61600,61609]
===
match
---
simple_stmt [54730,54805]
simple_stmt [54730,54805]
===
match
---
simple_stmt [3852,3869]
simple_stmt [3852,3869]
===
match
---
name: task [60033,60037]
name: task [60033,60037]
===
match
---
name: ser_ti [80189,80195]
name: ser_ti [80189,80195]
===
match
---
name: dag [46637,46640]
name: dag [46637,46640]
===
match
---
trailer [50931,50937]
trailer [50931,50937]
===
match
---
trailer [65187,65197]
trailer [65187,65197]
===
match
---
name: task [13259,13263]
name: task [13259,13263]
===
match
---
operator: == [21539,21541]
operator: == [21539,21541]
===
match
---
trailer [7197,7215]
trailer [7197,7215]
===
match
---
name: AirflowException [15133,15149]
name: AirflowException [15133,15149]
===
match
---
expr_stmt [7229,7242]
expr_stmt [7229,7242]
===
match
---
name: dag [18074,18077]
name: dag [18074,18077]
===
match
---
name: done [27537,27541]
name: done [27537,27541]
===
match
---
name: days [5245,5249]
name: days [5245,5249]
===
match
---
atom_expr [78485,78502]
atom_expr [78485,78502]
===
match
---
name: task_ids [41992,42000]
name: task_ids [41992,42000]
===
match
---
testlist_comp [53822,53878]
testlist_comp [53822,53878]
===
match
---
atom_expr [12851,12920]
atom_expr [12851,12920]
===
match
---
name: task [49257,49261]
name: task [49257,49261]
===
match
---
name: execution_date [6200,6214]
name: execution_date [6200,6214]
===
match
---
operator: , [52355,52356]
operator: , [52355,52356]
===
match
---
expr_stmt [17367,17419]
expr_stmt [17367,17419]
===
match
---
name: title [48497,48502]
name: title [48497,48502]
===
match
---
atom_expr [54128,54190]
atom_expr [54128,54190]
===
match
---
name: AirflowException [6976,6992]
name: AirflowException [6976,6992]
===
match
---
number: 1 [62463,62464]
number: 1 [62463,62464]
===
match
---
operator: , [9947,9948]
operator: , [9947,9948]
===
match
---
name: ti [79779,79781]
name: ti [79779,79781]
===
match
---
string: "test_handle_failure_on_retry" [62313,62343]
string: "test_handle_failure_on_retry" [62313,62343]
===
match
---
operator: , [33851,33852]
operator: , [33851,33852]
===
match
---
param [15243,15248]
param [15243,15248]
===
match
---
name: ti [51013,51015]
name: ti [51013,51015]
===
match
---
trailer [3523,3525]
trailer [3523,3525]
===
match
---
simple_stmt [20065,20391]
simple_stmt [20065,20391]
===
match
---
name: _run_finished_callback [51318,51340]
name: _run_finished_callback [51318,51340]
===
match
---
trailer [19172,19174]
trailer [19172,19174]
===
match
---
atom_expr [67851,67875]
atom_expr [67851,67875]
===
match
---
with_item [52410,52437]
with_item [52410,52437]
===
match
---
name: start_date [62541,62551]
name: start_date [62541,62551]
===
match
---
atom [48725,48754]
atom [48725,48754]
===
match
---
operator: = [5740,5741]
operator: = [5740,5741]
===
match
---
trailer [62001,62003]
trailer [62001,62003]
===
match
---
name: ti [28933,28935]
name: ti [28933,28935]
===
match
---
param [8404,8408]
param [8404,8408]
===
match
---
name: dag [74623,74626]
name: dag [74623,74626]
===
match
---
comparison [67077,67145]
comparison [67077,67145]
===
match
---
operator: , [27105,27106]
operator: , [27105,27106]
===
match
---
argument [24886,24918]
argument [24886,24918]
===
match
---
operator: , [38634,38635]
operator: , [38634,38635]
===
match
---
trailer [44389,44395]
trailer [44389,44395]
===
match
---
name: start_date [64684,64694]
name: start_date [64684,64694]
===
match
---
argument [41731,41740]
argument [41731,41740]
===
match
---
name: dag [43099,43102]
name: dag [43099,43102]
===
match
---
name: _ [53761,53762]
name: _ [53761,53762]
===
match
---
name: ti [20871,20873]
name: ti [20871,20873]
===
match
---
atom_expr [38461,38521]
atom_expr [38461,38521]
===
match
---
funcdef [19790,21570]
funcdef [19790,21570]
===
match
---
trailer [32919,32927]
trailer [32919,32927]
===
match
---
operator: = [16668,16669]
operator: = [16668,16669]
===
match
---
atom_expr [9559,9567]
atom_expr [9559,9567]
===
match
---
arglist [37417,37453]
arglist [37417,37453]
===
match
---
name: State [55201,55206]
name: State [55201,55206]
===
match
---
name: dag [63940,63943]
name: dag [63940,63943]
===
match
---
operator: = [15722,15723]
operator: = [15722,15723]
===
match
---
simple_stmt [17429,17580]
simple_stmt [17429,17580]
===
match
---
trailer [23795,23804]
trailer [23795,23804]
===
match
---
operator: , [36985,36986]
operator: , [36985,36986]
===
match
---
name: task_type [79659,79668]
name: task_type [79659,79668]
===
match
---
name: Stats [1833,1838]
name: Stats [1833,1838]
===
match
---
operator: , [43640,43641]
operator: , [43640,43641]
===
match
---
name: patch [48035,48040]
name: patch [48035,48040]
===
match
---
dictorsetmaker [72267,72285]
dictorsetmaker [72267,72285]
===
match
---
number: 2 [32093,32094]
number: 2 [32093,32094]
===
match
---
name: State [32612,32617]
name: State [32612,32617]
===
match
---
trailer [35057,35092]
trailer [35057,35092]
===
match
---
name: dag [79201,79204]
name: dag [79201,79204]
===
match
---
name: datetime [21678,21686]
name: datetime [21678,21686]
===
match
---
name: SUCCESS [54275,54282]
name: SUCCESS [54275,54282]
===
match
---
name: render_template [58806,58821]
name: render_template [58806,58821]
===
match
---
arglist [49068,49224]
arglist [49068,49224]
===
match
---
trailer [78340,78363]
trailer [78340,78363]
===
match
---
name: DEFAULT_DATE [58154,58166]
name: DEFAULT_DATE [58154,58166]
===
match
---
parameters [24298,24300]
parameters [24298,24300]
===
match
---
number: 2 [42774,42775]
number: 2 [42774,42775]
===
match
---
argument [15535,15550]
argument [15535,15550]
===
match
---
string: 'op1' [68602,68607]
string: 'op1' [68602,68607]
===
match
---
operator: , [76932,76933]
operator: , [76932,76933]
===
match
---
operator: { [69309,69310]
operator: { [69309,69310]
===
match
---
name: start_date [42739,42749]
name: start_date [42739,42749]
===
match
---
name: state [45059,45064]
name: state [45059,45064]
===
match
---
simple_stmt [3338,3388]
simple_stmt [3338,3388]
===
match
---
atom_expr [15870,15890]
atom_expr [15870,15890]
===
match
---
simple_stmt [19829,19897]
simple_stmt [19829,19897]
===
match
---
operator: = [76972,76973]
operator: = [76972,76973]
===
match
---
operator: == [5281,5283]
operator: == [5281,5283]
===
match
---
name: TI [3165,3167]
name: TI [3165,3167]
===
match
---
name: force_fail [63402,63412]
name: force_fail [63402,63412]
===
match
---
name: dep_patch [12429,12438]
name: dep_patch [12429,12438]
===
match
---
operator: = [6470,6471]
operator: = [6470,6471]
===
match
---
name: timezone [14253,14261]
name: timezone [14253,14261]
===
match
---
trailer [8096,8111]
trailer [8096,8111]
===
match
---
atom_expr [77479,77501]
atom_expr [77479,77501]
===
match
---
operator: , [16289,16290]
operator: , [16289,16290]
===
match
---
simple_stmt [59876,59909]
simple_stmt [59876,59909]
===
match
---
operator: , [68678,68679]
operator: , [68678,68679]
===
match
---
argument [76840,76850]
argument [76840,76850]
===
match
---
operator: , [70631,70632]
operator: , [70631,70632]
===
match
---
operator: , [36992,36993]
operator: , [36992,36993]
===
match
---
name: task_id [23377,23384]
name: task_id [23377,23384]
===
match
---
argument [4516,4528]
argument [4516,4528]
===
match
---
name: start_date [16307,16317]
name: start_date [16307,16317]
===
match
---
simple_stmt [58801,58874]
simple_stmt [58801,58874]
===
match
---
operator: = [24743,24744]
operator: = [24743,24744]
===
match
---
trailer [44919,44988]
trailer [44919,44988]
===
match
---
name: params [47628,47634]
name: params [47628,47634]
===
match
---
trailer [62249,62259]
trailer [62249,62259]
===
match
---
comparison [21487,21569]
comparison [21487,21569]
===
match
---
name: create_dagrun [15755,15768]
name: create_dagrun [15755,15768]
===
match
---
number: 0 [31824,31825]
number: 0 [31824,31825]
===
match
---
arglist [49252,49295]
arglist [49252,49295]
===
match
---
atom_expr [7414,7449]
atom_expr [7414,7449]
===
match
---
trailer [74794,74818]
trailer [74794,74818]
===
match
---
name: self [6628,6632]
name: self [6628,6632]
===
match
---
trailer [29956,29963]
trailer [29956,29963]
===
match
---
name: ti [66169,66171]
name: ti [66169,66171]
===
match
---
dotted_name [1688,1710]
dotted_name [1688,1710]
===
match
---
arglist [7469,7500]
arglist [7469,7500]
===
match
---
name: DummyOperator [8497,8510]
name: DummyOperator [8497,8510]
===
match
---
name: task [22153,22157]
name: task [22153,22157]
===
match
---
operator: = [22720,22721]
operator: = [22720,22721]
===
match
---
string: "override" [47216,47226]
string: "override" [47216,47226]
===
match
---
operator: = [49334,49335]
operator: = [49334,49335]
===
match
---
operator: = [47760,47761]
operator: = [47760,47761]
===
match
---
trailer [9650,9813]
trailer [9650,9813]
===
match
---
argument [41178,41202]
argument [41178,41202]
===
match
---
argument [9228,9274]
argument [9228,9274]
===
match
---
name: pod_spec [71154,71162]
name: pod_spec [71154,71162]
===
match
---
suite [19013,19114]
suite [19013,19114]
===
match
---
atom_expr [5612,5629]
atom_expr [5612,5629]
===
match
---
name: ti [23793,23795]
name: ti [23793,23795]
===
match
---
trailer [63511,63514]
trailer [63511,63514]
===
match
---
atom [73020,73427]
atom [73020,73427]
===
match
---
operator: = [35347,35348]
operator: = [35347,35348]
===
match
---
trailer [19272,19280]
trailer [19272,19280]
===
match
---
funcdef [63630,64309]
funcdef [63630,64309]
===
match
---
name: task2 [37422,37427]
name: task2 [37422,37427]
===
match
---
fstring_string: . [67035,67036]
fstring_string: . [67035,67036]
===
match
---
operator: , [50755,50756]
operator: , [50755,50756]
===
match
---
trailer [18352,18367]
trailer [18352,18367]
===
match
---
trailer [40027,40077]
trailer [40027,40077]
===
match
---
atom [73150,73205]
atom [73150,73205]
===
match
---
simple_stmt [2694,2715]
simple_stmt [2694,2715]
===
match
---
name: downstream [34573,34583]
name: downstream [34573,34583]
===
match
---
trailer [80246,80255]
trailer [80246,80255]
===
match
---
name: DAG [5719,5722]
name: DAG [5719,5722]
===
match
---
number: 120 [22645,22648]
number: 120 [22645,22648]
===
match
---
param [28029,28033]
param [28029,28033]
===
match
---
argument [34380,34387]
argument [34380,34387]
===
match
---
atom_expr [63427,63455]
atom_expr [63427,63455]
===
match
---
atom_expr [65203,65243]
atom_expr [65203,65243]
===
match
---
number: 10 [60683,60685]
number: 10 [60683,60685]
===
match
---
string: 'test_xcom' [40035,40046]
string: 'test_xcom' [40035,40046]
===
match
---
name: utcnow [49287,49293]
name: utcnow [49287,49293]
===
match
---
operator: = [11782,11783]
operator: = [11782,11783]
===
match
---
atom_expr [78515,78714]
atom_expr [78515,78714]
===
match
---
expr_stmt [26225,26270]
expr_stmt [26225,26270]
===
match
---
operator: + [26185,26186]
operator: + [26185,26186]
===
match
---
atom [33720,33766]
atom [33720,33766]
===
match
---
simple_stmt [52635,52665]
simple_stmt [52635,52665]
===
match
---
operator: == [51513,51515]
operator: == [51513,51515]
===
match
---
trailer [6157,6173]
trailer [6157,6173]
===
match
---
name: dag_id [2813,2819]
name: dag_id [2813,2819]
===
match
---
for_stmt [11795,12181]
for_stmt [11795,12181]
===
match
---
string: "DummyOperator" [79868,79883]
string: "DummyOperator" [79868,79883]
===
match
---
name: dag [5713,5716]
name: dag [5713,5716]
===
match
---
name: self [77886,77890]
name: self [77886,77890]
===
match
---
name: raises [8212,8218]
name: raises [8212,8218]
===
match
---
operator: = [41756,41757]
operator: = [41756,41757]
===
match
---
suite [64239,64269]
suite [64239,64269]
===
match
---
name: catchup [55300,55307]
name: catchup [55300,55307]
===
match
---
expr_stmt [74655,74737]
expr_stmt [74655,74737]
===
match
---
name: task_id [37097,37104]
name: task_id [37097,37104]
===
match
---
argument [15071,15103]
argument [15071,15103]
===
match
---
name: task_d [75375,75381]
name: task_d [75375,75381]
===
match
---
operator: , [40533,40534]
operator: , [40533,40534]
===
match
---
trailer [21781,22136]
trailer [21781,22136]
===
match
---
simple_stmt [79846,79884]
simple_stmt [79846,79884]
===
match
---
name: ti [10871,10873]
name: ti [10871,10873]
===
match
---
parameters [17695,17701]
parameters [17695,17701]
===
match
---
operator: , [67388,67389]
operator: , [67388,67389]
===
match
---
name: conf_vars [2484,2493]
name: conf_vars [2484,2493]
===
match
---
operator: = [7302,7303]
operator: = [7302,7303]
===
match
---
atom_expr [19634,19642]
atom_expr [19634,19642]
===
match
---
atom [32735,32801]
atom [32735,32801]
===
match
---
testlist_comp [35985,36004]
testlist_comp [35985,36004]
===
match
---
argument [20299,20316]
argument [20299,20316]
===
match
---
atom_expr [60183,60206]
atom_expr [60183,60206]
===
match
---
name: dag [20282,20285]
name: dag [20282,20285]
===
match
---
name: fail [63977,63981]
name: fail [63977,63981]
===
match
---
expr_stmt [45089,45113]
expr_stmt [45089,45113]
===
match
---
name: _test_previous_dates_setup [54573,54599]
name: _test_previous_dates_setup [54573,54599]
===
match
---
trailer [47849,47853]
trailer [47849,47853]
===
match
---
name: models [48146,48152]
name: models [48146,48152]
===
match
---
number: 0 [33557,33558]
number: 0 [33557,33558]
===
match
---
assert_stmt [30410,30424]
assert_stmt [30410,30424]
===
match
---
trailer [56788,56812]
trailer [56788,56812]
===
match
---
simple_stmt [61890,61915]
simple_stmt [61890,61915]
===
match
---
name: RenderedTaskInstanceFields [70760,70786]
name: RenderedTaskInstanceFields [70760,70786]
===
match
---
atom_expr [66286,66443]
atom_expr [66286,66443]
===
match
---
name: test_get_num_running_task_instances [44455,44490]
name: test_get_num_running_task_instances [44455,44490]
===
match
---
operator: = [65934,65935]
operator: = [65934,65935]
===
match
---
name: upstream_failed [34058,34073]
name: upstream_failed [34058,34073]
===
match
---
name: test_get_previous_start_date_none [55679,55712]
name: test_get_previous_start_date_none [55679,55712]
===
match
---
simple_stmt [62137,62173]
simple_stmt [62137,62173]
===
match
---
operator: == [16725,16727]
operator: == [16725,16727]
===
match
---
name: DummyOperator [7643,7656]
name: DummyOperator [7643,7656]
===
match
---
trailer [34665,34687]
trailer [34665,34687]
===
match
---
dictorsetmaker [72799,72868]
dictorsetmaker [72799,72868]
===
match
---
simple_stmt [856,903]
simple_stmt [856,903]
===
match
---
operator: + [12474,12475]
operator: + [12474,12475]
===
match
---
operator: , [6095,6096]
operator: , [6095,6096]
===
match
---
string: 'error' [42689,42696]
string: 'error' [42689,42696]
===
match
---
simple_stmt [24376,24388]
simple_stmt [24376,24388]
===
match
---
operator: = [71016,71017]
operator: = [71016,71017]
===
match
---
trailer [11652,11654]
trailer [11652,11654]
===
match
---
simple_stmt [10887,10904]
simple_stmt [10887,10904]
===
match
---
expr_stmt [46701,46847]
expr_stmt [46701,46847]
===
match
---
simple_stmt [49549,49601]
simple_stmt [49549,49601]
===
match
---
name: datetime [66405,66413]
name: datetime [66405,66413]
===
match
---
name: task [68234,68238]
name: task [68234,68238]
===
match
---
dotted_name [8845,8857]
dotted_name [8845,8857]
===
match
---
name: models [23306,23312]
name: models [23306,23312]
===
match
---
argument [9892,9899]
argument [9892,9899]
===
match
---
number: 180 [27102,27105]
number: 180 [27102,27105]
===
match
---
suite [29347,29411]
suite [29347,29411]
===
match
---
name: op3 [8707,8710]
name: op3 [8707,8710]
===
match
---
trailer [60547,60697]
trailer [60547,60697]
===
match
---
name: session [68874,68881]
name: session [68874,68881]
===
match
---
trailer [19130,19175]
trailer [19130,19175]
===
match
---
trailer [72809,72817]
trailer [72809,72817]
===
match
---
arglist [41731,41786]
arglist [41731,41786]
===
match
---
expr_stmt [62270,62496]
expr_stmt [62270,62496]
===
match
---
trailer [65205,65213]
trailer [65205,65213]
===
match
---
name: DummyOperator [7517,7530]
name: DummyOperator [7517,7530]
===
match
---
name: ti [52681,52683]
name: ti [52681,52683]
===
match
---
name: task_id [47776,47783]
name: task_id [47776,47783]
===
match
---
name: state [52717,52722]
name: state [52717,52722]
===
match
---
atom_expr [17372,17419]
atom_expr [17372,17419]
===
match
---
operator: , [73483,73484]
operator: , [73483,73484]
===
match
---
name: datetime [50292,50300]
name: datetime [50292,50300]
===
match
---
name: State [72005,72010]
name: State [72005,72010]
===
match
---
argument [41742,41786]
argument [41742,41786]
===
match
---
number: 1 [34251,34252]
number: 1 [34251,34252]
===
match
---
name: op3 [4867,4870]
name: op3 [4867,4870]
===
match
---
simple_stmt [59776,59812]
simple_stmt [59776,59812]
===
match
---
funcdef [65360,66195]
funcdef [65360,66195]
===
match
---
operator: = [17989,17990]
operator: = [17989,17990]
===
match
---
simple_stmt [55582,55670]
simple_stmt [55582,55670]
===
match
---
with_stmt [36261,36496]
with_stmt [36261,36496]
===
match
---
name: TI [44204,44206]
name: TI [44204,44206]
===
match
---
operator: , [32044,32045]
operator: , [32044,32045]
===
match
---
atom_expr [10859,10874]
atom_expr [10859,10874]
===
match
---
import_from [2284,2319]
import_from [2284,2319]
===
match
---
arglist [30027,30080]
arglist [30027,30080]
===
match
---
atom_expr [47832,47855]
atom_expr [47832,47855]
===
match
---
arglist [76952,77002]
arglist [76952,77002]
===
match
---
trailer [44206,44251]
trailer [44206,44251]
===
match
---
name: get_previous_ti [54247,54262]
name: get_previous_ti [54247,54262]
===
match
---
trailer [11916,11927]
trailer [11916,11927]
===
match
---
name: os [811,813]
name: os [811,813]
===
match
---
operator: = [13263,13264]
operator: = [13263,13264]
===
match
---
name: SCHEDULED [19314,19323]
name: SCHEDULED [19314,19323]
===
match
---
operator: = [64779,64780]
operator: = [64779,64780]
===
match
---
operator: = [9917,9918]
operator: = [9917,9918]
===
match
---
trailer [11860,11870]
trailer [11860,11870]
===
match
---
simple_stmt [70803,70821]
simple_stmt [70803,70821]
===
match
---
name: run_type [38948,38956]
name: run_type [38948,38956]
===
match
---
trailer [14712,14716]
trailer [14712,14716]
===
match
---
operator: = [36276,36277]
operator: = [36276,36277]
===
match
---
operator: } [16288,16289]
operator: } [16288,16289]
===
match
---
operator: = [49313,49314]
operator: = [49313,49314]
===
match
---
argument [38803,38827]
argument [38803,38827]
===
match
---
operator: = [56930,56931]
operator: = [56930,56931]
===
match
---
testlist_comp [33011,33066]
testlist_comp [33011,33066]
===
match
---
comparison [20871,20895]
comparison [20871,20895]
===
match
---
arglist [58564,58599]
arglist [58564,58599]
===
match
---
assert_stmt [39675,39733]
assert_stmt [39675,39733]
===
match
---
name: delete [68916,68922]
name: delete [68916,68922]
===
match
---
atom_expr [64121,64168]
atom_expr [64121,64168]
===
match
---
operator: = [49004,49005]
operator: = [49004,49005]
===
match
---
name: datetime [14993,15001]
name: datetime [14993,15001]
===
match
---
trailer [52824,52860]
trailer [52824,52860]
===
match
---
operator: , [67371,67372]
operator: , [67371,67372]
===
match
---
trailer [4250,4259]
trailer [4250,4259]
===
match
---
trailer [4401,4412]
trailer [4401,4412]
===
match
---
atom_expr [19704,19717]
atom_expr [19704,19717]
===
match
---
name: task_id [63883,63890]
name: task_id [63883,63890]
===
match
---
operator: - [12893,12894]
operator: - [12893,12894]
===
match
---
testlist_comp [31674,33887]
testlist_comp [31674,33887]
===
match
---
name: BashOperator [69134,69146]
name: BashOperator [69134,69146]
===
match
---
operator: , [33878,33879]
operator: , [33878,33879]
===
match
---
name: owner [24738,24743]
name: owner [24738,24743]
===
match
---
name: typing [861,867]
name: typing [861,867]
===
match
---
trailer [50945,50953]
trailer [50945,50953]
===
match
---
expr_stmt [5763,5798]
expr_stmt [5763,5798]
===
match
---
simple_stmt [29298,29307]
simple_stmt [29298,29307]
===
match
---
name: setUp [3670,3675]
name: setUp [3670,3675]
===
match
---
operator: , [32156,32157]
operator: , [32156,32157]
===
match
---
number: 0 [31699,31700]
number: 0 [31699,31700]
===
match
---
name: ti [44294,44296]
name: ti [44294,44296]
===
match
---
operator: , [31688,31689]
operator: , [31688,31689]
===
match
---
name: task_id [44794,44801]
name: task_id [44794,44801]
===
match
---
atom_expr [53822,53834]
atom_expr [53822,53834]
===
match
---
atom_expr [44516,44534]
atom_expr [44516,44534]
===
match
---
atom_expr [7998,8021]
atom_expr [7998,8021]
===
match
---
atom_expr [24674,24703]
atom_expr [24674,24703]
===
match
---
argument [40504,40533]
argument [40504,40533]
===
match
---
name: NONE [72830,72834]
name: NONE [72830,72834]
===
match
---
name: DummyOperator [55962,55975]
name: DummyOperator [55962,55975]
===
match
---
trailer [44056,44111]
trailer [44056,44111]
===
match
---
with_item [10713,10740]
with_item [10713,10740]
===
match
---
argument [52280,52309]
argument [52280,52309]
===
match
---
string: 'execution_date' [69778,69794]
string: 'execution_date' [69778,69794]
===
match
---
operator: == [29694,29696]
operator: == [29694,29696]
===
match
---
operator: , [71961,71962]
operator: , [71961,71962]
===
match
---
trailer [75520,75522]
trailer [75520,75522]
===
match
---
name: DAG [63780,63783]
name: DAG [63780,63783]
===
match
---
name: ti [76944,76946]
name: ti [76944,76946]
===
match
---
operator: = [41841,41842]
operator: = [41841,41842]
===
match
---
trailer [26195,26205]
trailer [26195,26205]
===
match
---
string: 'test_retries_on_other_exceptions' [64471,64505]
string: 'test_retries_on_other_exceptions' [64471,64505]
===
match
---
operator: = [74636,74637]
operator: = [74636,74637]
===
match
---
operator: , [55112,55113]
operator: , [55112,55113]
===
match
---
name: add [68424,68427]
name: add [68424,68427]
===
match
---
name: SCHEDULED [14411,14420]
name: SCHEDULED [14411,14420]
===
match
---
operator: - [22847,22848]
operator: - [22847,22848]
===
match
---
trailer [7593,7628]
trailer [7593,7628]
===
match
---
operator: = [57216,57217]
operator: = [57216,57217]
===
match
---
string: 'AIRFLOW_IS_K8S_EXECUTOR_POD' [70583,70612]
string: 'AIRFLOW_IS_K8S_EXECUTOR_POD' [70583,70612]
===
match
---
name: items [71499,71504]
name: items [71499,71504]
===
match
---
atom_expr [51504,51512]
atom_expr [51504,51512]
===
match
---
name: context_arg_1 [62115,62128]
name: context_arg_1 [62115,62128]
===
match
---
expr_stmt [8419,8460]
expr_stmt [8419,8460]
===
match
---
trailer [37416,37454]
trailer [37416,37454]
===
match
---
trailer [21360,21362]
trailer [21360,21362]
===
match
---
name: has_dag [7821,7828]
name: has_dag [7821,7828]
===
match
---
name: timezone [76239,76247]
name: timezone [76239,76247]
===
match
---
trailer [75968,75972]
trailer [75968,75972]
===
match
---
comparison [59883,59908]
comparison [59883,59908]
===
match
---
name: dag [61811,61814]
name: dag [61811,61814]
===
match
---
name: pendulum [52500,52508]
name: pendulum [52500,52508]
===
match
---
argument [39486,39503]
argument [39486,39503]
===
match
---
name: start_date [76483,76493]
name: start_date [76483,76493]
===
match
---
string: 'test_pendulum_template_dates_task' [57149,57184]
string: 'test_pendulum_template_dates_task' [57149,57184]
===
match
---
trailer [66571,66581]
trailer [66571,66581]
===
match
---
operator: = [35052,35053]
operator: = [35052,35053]
===
match
---
parameters [78881,78887]
parameters [78881,78887]
===
match
---
name: task [23344,23348]
name: task [23344,23348]
===
match
---
trailer [25001,25015]
trailer [25001,25015]
===
match
---
assert_stmt [54229,54327]
assert_stmt [54229,54327]
===
match
---
string: 'D' [74285,74288]
string: 'D' [74285,74288]
===
match
---
trailer [44632,44684]
trailer [44632,44684]
===
match
---
simple_stmt [7998,8022]
simple_stmt [7998,8022]
===
match
---
name: TestRunRawTaskQueriesCount [77510,77536]
name: TestRunRawTaskQueriesCount [77510,77536]
===
match
---
string: 'AIRFLOW_CTX_DAG_RUN_ID' [65329,65353]
string: 'AIRFLOW_CTX_DAG_RUN_ID' [65329,65353]
===
match
---
name: seconds [24693,24700]
name: seconds [24693,24700]
===
match
---
trailer [12245,12251]
trailer [12245,12251]
===
match
---
name: dag [46059,46062]
name: dag [46059,46062]
===
match
---
number: 3 [21241,21242]
number: 3 [21241,21242]
===
match
---
name: owner [37383,37388]
name: owner [37383,37388]
===
match
---
name: airflow [2208,2215]
name: airflow [2208,2215]
===
match
---
operator: , [70378,70379]
operator: , [70378,70379]
===
match
---
atom_expr [45231,45247]
atom_expr [45231,45247]
===
match
---
operator: = [45010,45011]
operator: = [45010,45011]
===
match
---
name: dag [20278,20281]
name: dag [20278,20281]
===
match
---
name: session [10097,10104]
name: session [10097,10104]
===
match
---
name: FAILED [53328,53334]
name: FAILED [53328,53334]
===
match
---
name: run_type [13596,13604]
name: run_type [13596,13604]
===
match
---
argument [28453,28494]
argument [28453,28494]
===
match
---
operator: , [32912,32913]
operator: , [32912,32913]
===
match
---
simple_stmt [74024,74094]
simple_stmt [74024,74094]
===
match
---
argument [74361,74392]
argument [74361,74392]
===
match
---
trailer [63339,63346]
trailer [63339,63346]
===
match
---
name: SchedulerJob [1302,1314]
name: SchedulerJob [1302,1314]
===
match
---
atom_expr [11904,11976]
atom_expr [11904,11976]
===
match
---
name: template_context [57338,57354]
name: template_context [57338,57354]
===
match
---
operator: = [44858,44859]
operator: = [44858,44859]
===
match
---
argument [37374,37381]
argument [37374,37381]
===
match
---
operator: = [76118,76119]
operator: = [76118,76119]
===
match
---
operator: == [19508,19510]
operator: == [19508,19510]
===
match
---
atom_expr [45003,45046]
atom_expr [45003,45046]
===
match
---
operator: = [58671,58672]
operator: = [58671,58672]
===
match
---
param [12642,12646]
param [12642,12646]
===
match
---
trailer [54934,54962]
trailer [54934,54962]
===
match
---
trailer [42998,43053]
trailer [42998,43053]
===
match
---
name: patch [972,977]
name: patch [972,977]
===
match
---
name: try_number [21261,21271]
name: try_number [21261,21271]
===
match
---
atom_expr [66681,66694]
atom_expr [66681,66694]
===
match
---
name: _prev_dates_param_list [52784,52806]
name: _prev_dates_param_list [52784,52806]
===
match
---
argument [10585,10617]
argument [10585,10617]
===
match
---
operator: = [11855,11856]
operator: = [11855,11856]
===
match
---
argument [68321,68330]
argument [68321,68330]
===
match
---
number: 0 [33031,33032]
number: 0 [33031,33032]
===
match
---
trailer [23824,23843]
trailer [23824,23843]
===
match
---
operator: , [63104,63105]
operator: , [63104,63105]
===
match
---
number: 2016 [40262,40266]
number: 2016 [40262,40266]
===
match
---
operator: { [47874,47875]
operator: { [47874,47875]
===
match
---
atom_expr [7643,7700]
atom_expr [7643,7700]
===
match
---
name: task [30709,30713]
name: task [30709,30713]
===
match
---
trailer [77746,77748]
trailer [77746,77748]
===
match
---
comparison [77464,77501]
comparison [77464,77501]
===
match
---
parameters [42966,42972]
parameters [42966,42972]
===
match
---
name: timezone [2128,2136]
name: timezone [2128,2136]
===
match
---
name: unittest [934,942]
name: unittest [934,942]
===
match
---
name: timedelta [5053,5062]
name: timedelta [5053,5062]
===
match
---
name: start_date [78969,78979]
name: start_date [78969,78979]
===
match
---
name: session [45206,45213]
name: session [45206,45213]
===
match
---
name: datetime [47841,47849]
name: datetime [47841,47849]
===
match
---
name: dag_id [18640,18646]
name: dag_id [18640,18646]
===
match
---
trailer [46730,46847]
trailer [46730,46847]
===
match
---
simple_stmt [38746,38776]
simple_stmt [38746,38776]
===
match
---
name: ti [40699,40701]
name: ti [40699,40701]
===
match
---
name: State [73229,73234]
name: State [73229,73234]
===
match
---
operator: , [32227,32228]
operator: , [32227,32228]
===
match
---
argument [14227,14236]
argument [14227,14236]
===
match
---
import_from [903,928]
import_from [903,928]
===
match
---
atom_expr [3902,3917]
atom_expr [3902,3917]
===
match
---
name: task_id [44714,44721]
name: task_id [44714,44721]
===
match
---
number: 0 [18218,18219]
number: 0 [18218,18219]
===
match
---
string: 'A' [71903,71906]
string: 'A' [71903,71906]
===
match
---
string: 'test pass status name' [35501,35524]
string: 'test pass status name' [35501,35524]
===
match
---
simple_stmt [21718,21754]
simple_stmt [21718,21754]
===
match
---
name: done [34963,34967]
name: done [34963,34967]
===
match
---
operator: = [74162,74163]
operator: = [74162,74163]
===
match
---
comparison [13752,13777]
comparison [13752,13777]
===
match
---
name: _try_number [21421,21432]
name: _try_number [21421,21432]
===
match
---
with_stmt [73581,75975]
with_stmt [73581,75975]
===
match
---
string: 'test_pool' [3783,3794]
string: 'test_pool' [3783,3794]
===
match
---
simple_stmt [51708,51739]
simple_stmt [51708,51739]
===
match
---
name: create_dagrun [19188,19201]
name: create_dagrun [19188,19201]
===
match
---
atom_expr [57494,57564]
atom_expr [57494,57564]
===
match
---
argument [15904,15919]
argument [15904,15919]
===
match
---
simple_stmt [24928,24955]
simple_stmt [24928,24955]
===
match
---
name: generate_run_id [65266,65281]
name: generate_run_id [65266,65281]
===
match
---
operator: , [16346,16347]
operator: , [16346,16347]
===
match
---
operator: , [25324,25325]
operator: , [25324,25325]
===
match
---
simple_stmt [61171,61189]
simple_stmt [61171,61189]
===
match
---
simple_stmt [68416,68460]
simple_stmt [68416,68460]
===
match
---
arglist [68184,68219]
arglist [68184,68219]
===
match
---
name: downstream_ti_state [36201,36220]
name: downstream_ti_state [36201,36220]
===
match
---
argument [52269,52278]
argument [52269,52278]
===
match
---
name: dag [30677,30680]
name: dag [30677,30680]
===
match
---
name: NONE [72847,72851]
name: NONE [72847,72851]
===
match
---
name: db [77757,77759]
name: db [77757,77759]
===
match
---
number: 0 [32671,32672]
number: 0 [32671,32672]
===
match
---
name: execution_date [54313,54327]
name: execution_date [54313,54327]
===
match
---
trailer [13769,13777]
trailer [13769,13777]
===
match
---
simple_stmt [77317,77359]
simple_stmt [77317,77359]
===
match
---
simple_stmt [7317,7338]
simple_stmt [7317,7338]
===
match
---
import_as_names [1154,1170]
import_as_names [1154,1170]
===
match
---
atom_expr [16728,16750]
atom_expr [16728,16750]
===
match
---
atom_expr [80238,80261]
atom_expr [80238,80261]
===
match
---
trailer [3734,3736]
trailer [3734,3736]
===
match
---
operator: , [27768,27769]
operator: , [27768,27769]
===
match
---
atom_expr [19303,19323]
atom_expr [19303,19323]
===
match
---
name: Session [66856,66863]
name: Session [66856,66863]
===
match
---
simple_stmt [77008,77064]
simple_stmt [77008,77064]
===
match
---
expr_stmt [12929,12994]
expr_stmt [12929,12994]
===
match
---
operator: , [18210,18211]
operator: , [18210,18211]
===
match
---
trailer [39640,39644]
trailer [39640,39644]
===
match
---
operator: = [17066,17067]
operator: = [17066,17067]
===
match
---
operator: = [50714,50715]
operator: = [50714,50715]
===
match
---
name: UPSTREAM_FAILED [31842,31857]
name: UPSTREAM_FAILED [31842,31857]
===
match
---
dotted_name [53677,53697]
dotted_name [53677,53697]
===
match
---
trailer [52929,52961]
trailer [52929,52961]
===
match
---
param [57955,57963]
param [57955,57963]
===
match
---
name: execution_date [67495,67509]
name: execution_date [67495,67509]
===
match
---
name: task [42812,42816]
name: task [42812,42816]
===
match
---
operator: , [32215,32216]
operator: , [32215,32216]
===
match
---
operator: = [36508,36509]
operator: = [36508,36509]
===
match
---
number: 0 [32674,32675]
number: 0 [32674,32675]
===
match
---
trailer [51012,51016]
trailer [51012,51016]
===
match
---
atom_expr [10146,10162]
atom_expr [10146,10162]
===
match
---
name: TI [71099,71101]
name: TI [71099,71101]
===
match
---
operator: , [13168,13169]
operator: , [13168,13169]
===
match
---
name: datetime [47140,47148]
name: datetime [47140,47148]
===
match
---
operator: , [50008,50009]
operator: , [50008,50009]
===
match
---
dotted_name [68931,68946]
dotted_name [68931,68946]
===
match
---
name: dag_id [11047,11053]
name: dag_id [11047,11053]
===
match
---
simple_stmt [56751,56768]
simple_stmt [56751,56768]
===
match
---
name: DEFAULT_DATE [65511,65523]
name: DEFAULT_DATE [65511,65523]
===
match
---
atom_expr [5838,5881]
atom_expr [5838,5881]
===
match
---
name: settings [66847,66855]
name: settings [66847,66855]
===
match
---
atom_expr [63322,63331]
atom_expr [63322,63331]
===
match
---
trailer [39094,39125]
trailer [39094,39125]
===
match
---
atom_expr [46512,46543]
atom_expr [46512,46543]
===
match
---
name: end_date [22397,22405]
name: end_date [22397,22405]
===
match
---
trailer [64945,64958]
trailer [64945,64958]
===
match
---
atom_expr [19460,19478]
atom_expr [19460,19478]
===
match
---
argument [39045,39052]
argument [39045,39052]
===
match
---
lambdef [41575,41588]
lambdef [41575,41588]
===
match
---
operator: , [33320,33321]
operator: , [33320,33321]
===
match
---
name: state [64303,64308]
name: state [64303,64308]
===
match
---
arith_expr [11735,11762]
arith_expr [11735,11762]
===
match
---
dotted_name [1486,1508]
dotted_name [1486,1508]
===
match
---
simple_stmt [75009,75039]
simple_stmt [75009,75039]
===
match
---
fstring_expr [11942,11974]
fstring_expr [11942,11974]
===
match
---
trailer [72757,72762]
trailer [72757,72762]
===
match
---
string: 'airflow' [67747,67756]
string: 'airflow' [67747,67756]
===
match
---
simple_stmt [60983,61163]
simple_stmt [60983,61163]
===
match
---
trailer [78749,78771]
trailer [78749,78771]
===
match
---
argument [13509,13541]
argument [13509,13541]
===
match
---
trailer [2852,2867]
trailer [2852,2867]
===
match
---
argument [41873,41892]
argument [41873,41892]
===
match
---
name: DEFAULT_DATE [5029,5041]
name: DEFAULT_DATE [5029,5041]
===
match
---
name: _run_raw_task [79456,79469]
name: _run_raw_task [79456,79469]
===
match
---
string: 'test_xcom' [38623,38634]
string: 'test_xcom' [38623,38634]
===
match
---
trailer [71543,71561]
trailer [71543,71561]
===
match
---
simple_stmt [47485,47544]
simple_stmt [47485,47544]
===
match
---
operator: = [23770,23771]
operator: = [23770,23771]
===
match
---
name: schedule_interval [51779,51796]
name: schedule_interval [51779,51796]
===
match
---
simple_stmt [29456,29490]
simple_stmt [29456,29490]
===
match
---
atom_expr [77909,77922]
atom_expr [77909,77922]
===
match
---
operator: = [49841,49842]
operator: = [49841,49842]
===
match
---
name: task [49035,49039]
name: task [49035,49039]
===
match
---
expr_stmt [28420,28820]
expr_stmt [28420,28820]
===
match
---
operator: , [20316,20317]
operator: , [20316,20317]
===
match
---
string: 'test_pool' [28735,28746]
string: 'test_pool' [28735,28746]
===
match
---
assert_stmt [53978,54040]
assert_stmt [53978,54040]
===
match
---
atom_expr [71873,71883]
atom_expr [71873,71883]
===
match
---
trailer [16000,16002]
trailer [16000,16002]
===
match
---
dictorsetmaker [19936,19999]
dictorsetmaker [19936,19999]
===
match
---
argument [22410,22420]
argument [22410,22420]
===
match
---
operator: = [64119,64120]
operator: = [64119,64120]
===
match
---
name: datetime [49986,49994]
name: datetime [49986,49994]
===
match
---
operator: , [67837,67838]
operator: , [67837,67838]
===
match
---
argument [24574,24591]
argument [24574,24591]
===
match
---
string: """         Test the availability of variables in templates         """ [59453,59524]
string: """         Test the availability of variables in templates         """ [59453,59524]
===
match
---
arglist [9228,9283]
arglist [9228,9283]
===
match
---
argument [48227,48253]
argument [48227,48253]
===
match
---
number: 0 [24559,24560]
number: 0 [24559,24560]
===
match
---
funcdef [79477,80313]
funcdef [79477,80313]
===
match
---
name: os [65203,65205]
name: os [65203,65205]
===
match
---
operator: = [7236,7237]
operator: = [7236,7237]
===
match
---
name: timezone [15627,15635]
name: timezone [15627,15635]
===
match
---
string: 'downstream_task' [36416,36433]
string: 'downstream_task' [36416,36433]
===
match
---
operator: = [34864,34865]
operator: = [34864,34865]
===
match
---
atom_expr [10077,10093]
atom_expr [10077,10093]
===
match
---
name: TriggerRuleDep [34710,34724]
name: TriggerRuleDep [34710,34724]
===
match
---
parameters [76631,76646]
parameters [76631,76646]
===
match
---
name: SUCCESS [66187,66194]
name: SUCCESS [66187,66194]
===
match
---
atom_expr [74480,74520]
atom_expr [74480,74520]
===
match
---
expr_stmt [16381,16434]
expr_stmt [16381,16434]
===
match
---
arglist [17375,17418]
arglist [17375,17418]
===
match
---
argument [46637,46644]
argument [46637,46644]
===
match
---
trailer [77774,77776]
trailer [77774,77776]
===
match
---
name: os [65318,65320]
name: os [65318,65320]
===
match
---
name: DummyOperator [7580,7593]
name: DummyOperator [7580,7593]
===
match
---
operator: , [17255,17256]
operator: , [17255,17256]
===
match
---
number: 0 [34257,34258]
number: 0 [34257,34258]
===
match
---
name: days [60678,60682]
name: days [60678,60682]
===
match
---
comparison [46949,46998]
comparison [46949,46998]
===
match
---
name: run [39641,39644]
name: run [39641,39644]
===
match
---
operator: = [37239,37240]
operator: = [37239,37240]
===
match
---
name: expected_pod_spec [71212,71229]
name: expected_pod_spec [71212,71229]
===
match
---
argument [64087,64096]
argument [64087,64096]
===
match
---
name: naive_datetime [6471,6485]
name: naive_datetime [6471,6485]
===
match
---
name: task [58801,58805]
name: task [58801,58805]
===
match
---
name: ti1 [61975,61978]
name: ti1 [61975,61978]
===
match
---
name: pool_override [76632,76645]
name: pool_override [76632,76645]
===
match
---
operator: , [21898,21899]
operator: , [21898,21899]
===
match
---
trailer [62760,62770]
trailer [62760,62770]
===
match
---
name: AirflowException [64878,64894]
name: AirflowException [64878,64894]
===
match
---
name: task [60706,60710]
name: task [60706,60710]
===
match
---
string: 'foo' [37481,37486]
string: 'foo' [37481,37486]
===
match
---
trailer [54082,54103]
trailer [54082,54103]
===
match
---
trailer [6748,6780]
trailer [6748,6780]
===
match
---
trailer [9994,10001]
trailer [9994,10001]
===
match
---
operator: = [75208,75209]
operator: = [75208,75209]
===
match
---
expr_stmt [79965,80041]
expr_stmt [79965,80041]
===
match
---
dictorsetmaker [73113,73131]
dictorsetmaker [73113,73131]
===
match
---
name: task_ids [41147,41155]
name: task_ids [41147,41155]
===
match
---
assert_stmt [65252,65354]
assert_stmt [65252,65354]
===
match
---
name: session [78684,78691]
name: session [78684,78691]
===
match
---
operator: = [58229,58230]
operator: = [58229,58230]
===
match
---
name: DummyOperator [76659,76672]
name: DummyOperator [76659,76672]
===
match
---
name: SUCCESS [54511,54518]
name: SUCCESS [54511,54518]
===
match
---
trailer [79149,79157]
trailer [79149,79157]
===
match
---
operator: } [71774,71775]
operator: } [71774,71775]
===
match
---
simple_stmt [64194,64203]
simple_stmt [64194,64203]
===
match
---
simple_stmt [46235,46418]
simple_stmt [46235,46418]
===
match
---
name: start_date [20330,20340]
name: start_date [20330,20340]
===
match
---
argument [61500,61521]
argument [61500,61521]
===
match
---
name: RenderedTaskInstanceFields [71329,71355]
name: RenderedTaskInstanceFields [71329,71355]
===
match
---
name: date [23853,23857]
name: date [23853,23857]
===
match
---
string: 'containers' [70104,70116]
string: 'containers' [70104,70116]
===
match
---
atom_expr [29423,29443]
atom_expr [29423,29443]
===
match
---
operator: = [29783,29784]
operator: = [29783,29784]
===
match
---
name: start_date [65819,65829]
name: start_date [65819,65829]
===
match
---
operator: = [28383,28384]
operator: = [28383,28384]
===
match
---
name: datetime [4632,4640]
name: datetime [4632,4640]
===
match
---
trailer [26995,27013]
trailer [26995,27013]
===
match
---
argument [36869,36887]
argument [36869,36887]
===
match
---
operator: = [49040,49041]
operator: = [49040,49041]
===
match
---
name: TI [46166,46168]
name: TI [46166,46168]
===
match
---
name: execution_date [50277,50291]
name: execution_date [50277,50291]
===
match
---
atom [33661,33706]
atom [33661,33706]
===
match
---
name: end_date [23001,23009]
name: end_date [23001,23009]
===
match
---
operator: = [61493,61494]
operator: = [61493,61494]
===
match
---
name: TI [15057,15059]
name: TI [15057,15059]
===
match
---
argument [58667,58676]
argument [58667,58676]
===
match
---
name: ti [21453,21455]
name: ti [21453,21455]
===
match
---
operator: , [66367,66368]
operator: , [66367,66368]
===
match
---
atom_expr [71018,71080]
atom_expr [71018,71080]
===
match
---
argument [54776,54795]
argument [54776,54795]
===
match
---
trailer [47492,47543]
trailer [47492,47543]
===
match
---
trailer [63453,63455]
trailer [63453,63455]
===
match
---
operator: , [30657,30658]
operator: , [30657,30658]
===
match
---
trailer [42533,42565]
trailer [42533,42565]
===
match
---
name: execution_date [47817,47831]
name: execution_date [47817,47831]
===
match
---
trailer [29736,29745]
trailer [29736,29745]
===
match
---
operator: , [1218,1219]
operator: , [1218,1219]
===
match
---
name: run [75551,75554]
name: run [75551,75554]
===
match
---
operator: = [9670,9671]
operator: = [9670,9671]
===
match
---
operator: , [72041,72042]
operator: , [72041,72042]
===
match
---
operator: , [49898,49899]
operator: , [49898,49899]
===
match
---
trailer [47853,47855]
trailer [47853,47855]
===
match
---
trailer [55253,55280]
trailer [55253,55280]
===
match
---
name: self [30455,30459]
name: self [30455,30459]
===
match
---
name: op1 [7998,8001]
name: op1 [7998,8001]
===
match
---
name: ti [9294,9296]
name: ti [9294,9296]
===
match
---
name: op1 [76158,76161]
name: op1 [76158,76161]
===
match
---
atom_expr [6246,6263]
atom_expr [6246,6263]
===
match
---
trailer [3251,3258]
trailer [3251,3258]
===
match
---
expr_stmt [68313,68360]
expr_stmt [68313,68360]
===
match
---
operator: , [53148,53149]
operator: , [53148,53149]
===
match
---
operator: != [53642,53644]
operator: != [53642,53644]
===
match
---
number: 0 [27610,27611]
number: 0 [27610,27611]
===
match
---
trailer [75265,75270]
trailer [75265,75270]
===
match
---
argument [78802,78827]
argument [78802,78827]
===
match
---
name: called [60436,60442]
name: called [60436,60442]
===
match
---
string: 'B' [71804,71807]
string: 'B' [71804,71807]
===
match
---
operator: = [46607,46608]
operator: = [46607,46608]
===
match
---
argument [8436,8459]
argument [8436,8459]
===
match
---
name: get_templated_fields [21514,21534]
name: get_templated_fields [21514,21534]
===
match
---
operator: , [57728,57729]
operator: , [57728,57729]
===
match
---
operator: = [46147,46148]
operator: = [46147,46148]
===
match
---
simple_stmt [50110,50137]
simple_stmt [50110,50137]
===
match
---
operator: , [51876,51877]
operator: , [51876,51877]
===
match
---
operator: = [58619,58620]
operator: = [58619,58620]
===
match
---
simple_stmt [8071,8085]
simple_stmt [8071,8085]
===
match
---
operator: = [74248,74249]
operator: = [74248,74249]
===
match
---
operator: = [53819,53820]
operator: = [53819,53820]
===
match
---
name: set_downstream [8002,8016]
name: set_downstream [8002,8016]
===
match
---
trailer [31311,31313]
trailer [31311,31313]
===
match
---
atom_expr [18827,18856]
atom_expr [18827,18856]
===
match
---
trailer [19714,19717]
trailer [19714,19717]
===
match
---
operator: , [27750,27751]
operator: , [27750,27751]
===
match
---
name: add [23966,23969]
name: add [23966,23969]
===
match
---
name: period [22901,22907]
name: period [22901,22907]
===
match
---
number: 2016 [15645,15649]
number: 2016 [15645,15649]
===
match
---
with_item [16072,16121]
with_item [16072,16121]
===
match
---
name: task [77286,77290]
name: task [77286,77290]
===
match
---
fstring_string: . [11928,11929]
fstring_string: . [11928,11929]
===
match
---
trailer [55280,55318]
trailer [55280,55318]
===
match
---
name: State [72752,72757]
name: State [72752,72757]
===
match
---
string: 'test_requeue_over_task_concurrency' [9671,9707]
string: 'test_requeue_over_task_concurrency' [9671,9707]
===
match
---
expr_stmt [52469,52544]
expr_stmt [52469,52544]
===
match
---
atom_expr [50680,50853]
atom_expr [50680,50853]
===
match
---
trailer [64043,64052]
trailer [64043,64052]
===
match
---
name: Session [50981,50988]
name: Session [50981,50988]
===
match
---
argument [40204,40219]
argument [40204,40219]
===
match
---
testlist_comp [73040,73084]
testlist_comp [73040,73084]
===
match
---
expr_stmt [55160,55229]
expr_stmt [55160,55229]
===
match
---
trailer [61609,61611]
trailer [61609,61611]
===
match
---
name: sensors [1644,1651]
name: sensors [1644,1651]
===
match
---
name: State [44398,44403]
name: State [44398,44403]
===
match
---
name: task [45006,45010]
name: task [45006,45010]
===
match
---
trailer [61274,61290]
trailer [61274,61290]
===
match
---
number: 2 [33037,33038]
number: 2 [33037,33038]
===
match
---
number: 2 [26900,26901]
number: 2 [26900,26901]
===
match
---
assert_stmt [20692,20729]
assert_stmt [20692,20729]
===
match
---
name: body [48650,48654]
name: body [48650,48654]
===
match
---
funcdef [64976,65355]
funcdef [64976,65355]
===
match
---
argument [28701,28716]
argument [28701,28716]
===
match
---
atom_expr [11229,11474]
atom_expr [11229,11474]
===
match
---
expr_stmt [62013,62062]
expr_stmt [62013,62062]
===
match
---
name: task_id [67992,67999]
name: task_id [67992,67999]
===
match
---
name: task [14761,14765]
name: task [14761,14765]
===
match
---
name: result [37788,37794]
name: result [37788,37794]
===
match
---
operator: , [32032,32033]
operator: , [32032,32033]
===
match
---
name: task_id [68254,68261]
name: task_id [68254,68261]
===
match
---
simple_stmt [25976,26066]
simple_stmt [25976,26066]
===
match
---
operator: , [65451,65452]
operator: , [65451,65452]
===
match
---
operator: = [66428,66429]
operator: = [66428,66429]
===
match
---
name: test_check_task_dependencies [33912,33940]
name: test_check_task_dependencies [33912,33940]
===
match
---
name: ti [66106,66108]
name: ti [66106,66108]
===
match
---
shift_expr [36472,36495]
shift_expr [36472,36495]
===
match
---
operator: = [40752,40753]
operator: = [40752,40753]
===
match
---
number: 3 [19715,19716]
number: 3 [19715,19716]
===
match
---
operator: = [59703,59704]
operator: = [59703,59704]
===
match
---
number: 2 [31815,31816]
number: 2 [31815,31816]
===
match
---
operator: = [4139,4140]
operator: = [4139,4140]
===
match
---
trailer [4173,4203]
trailer [4173,4203]
===
match
---
name: timezone [26145,26153]
name: timezone [26145,26153]
===
match
---
expr_stmt [44544,44606]
expr_stmt [44544,44606]
===
match
---
expr_stmt [37665,37698]
expr_stmt [37665,37698]
===
match
---
name: state [52336,52341]
name: state [52336,52341]
===
match
---
name: catchup [53421,53428]
name: catchup [53421,53428]
===
match
---
atom_expr [76361,76379]
atom_expr [76361,76379]
===
match
---
dotted_name [1736,1776]
dotted_name [1736,1776]
===
match
---
argument [51764,51777]
argument [51764,51777]
===
match
---
operator: , [32755,32756]
operator: , [32755,32756]
===
match
---
name: create_dagrun [60987,61000]
name: create_dagrun [60987,61000]
===
match
---
suite [42414,42508]
suite [42414,42508]
===
match
---
simple_stmt [55160,55230]
simple_stmt [55160,55230]
===
match
---
name: task_instance_b [75051,75066]
name: task_instance_b [75051,75066]
===
match
---
simple_stmt [27764,27790]
simple_stmt [27764,27790]
===
match
---
simple_stmt [58614,58650]
simple_stmt [58614,58650]
===
match
---
name: ti [52751,52753]
name: ti [52751,52753]
===
match
---
argument [13304,13328]
argument [13304,13328]
===
match
---
simple_stmt [11771,11787]
simple_stmt [11771,11787]
===
match
---
name: try_number [20604,20614]
name: try_number [20604,20614]
===
match
---
expr_stmt [58659,58706]
expr_stmt [58659,58706]
===
match
---
simple_stmt [24867,24920]
simple_stmt [24867,24920]
===
match
---
trailer [42879,42890]
trailer [42879,42890]
===
match
---
name: DagRunType [18423,18433]
name: DagRunType [18423,18433]
===
match
---
operator: , [32035,32036]
operator: , [32035,32036]
===
match
---
operator: , [64060,64061]
operator: , [64060,64061]
===
match
---
name: retries [20200,20207]
name: retries [20200,20207]
===
match
---
name: session [78922,78929]
name: session [78922,78929]
===
match
---
argument [23377,23432]
argument [23377,23432]
===
match
---
simple_stmt [46426,46460]
simple_stmt [46426,46460]
===
match
---
atom_expr [79853,79864]
atom_expr [79853,79864]
===
match
---
operator: == [19365,19367]
operator: == [19365,19367]
===
match
---
name: max_retry_delay [21987,22002]
name: max_retry_delay [21987,22002]
===
match
---
operator: , [27835,27836]
operator: , [27835,27836]
===
match
---
name: run_with_error [19600,19614]
name: run_with_error [19600,19614]
===
match
---
string: "op1" [68771,68776]
string: "op1" [68771,68776]
===
match
---
operator: = [2546,2547]
operator: = [2546,2547]
===
match
---
trailer [25442,25452]
trailer [25442,25452]
===
match
---
expr_stmt [63848,64107]
expr_stmt [63848,64107]
===
match
---
trailer [23087,23089]
trailer [23087,23089]
===
match
---
simple_stmt [47865,47894]
simple_stmt [47865,47894]
===
match
---
atom_expr [12544,12563]
atom_expr [12544,12563]
===
match
---
operator: = [7620,7621]
operator: = [7620,7621]
===
match
---
name: mark_success [17595,17607]
name: mark_success [17595,17607]
===
match
---
name: dag_id [3216,3222]
name: dag_id [3216,3222]
===
match
---
trailer [30056,30074]
trailer [30056,30074]
===
match
---
name: datetime [21627,21635]
name: datetime [21627,21635]
===
match
---
argument [22380,22390]
argument [22380,22390]
===
match
---
simple_stmt [26912,26938]
simple_stmt [26912,26938]
===
match
---
operator: == [45266,45268]
operator: == [45266,45268]
===
match
---
argument [67495,67522]
argument [67495,67522]
===
match
---
simple_stmt [26225,26271]
simple_stmt [26225,26271]
===
match
---
name: non_runnable_state [12830,12848]
name: non_runnable_state [12830,12848]
===
match
---
suite [23193,24041]
suite [23193,24041]
===
match
---
name: State [32532,32537]
name: State [32532,32537]
===
match
---
atom [31596,33897]
atom [31596,33897]
===
match
---
operator: = [18246,18247]
operator: = [18246,18247]
===
match
---
arglist [61409,61419]
arglist [61409,61419]
===
match
---
argument [76127,76134]
argument [76127,76134]
===
match
---
argument [62408,62441]
argument [62408,62441]
===
match
---
atom_expr [2565,2578]
atom_expr [2565,2578]
===
match
---
name: timedelta [26250,26259]
name: timedelta [26250,26259]
===
match
---
trailer [50340,50342]
trailer [50340,50342]
===
match
---
name: execution_date [10585,10599]
name: execution_date [10585,10599]
===
match
---
atom_expr [47070,47097]
atom_expr [47070,47097]
===
match
---
operator: , [12340,12341]
operator: , [12340,12341]
===
match
---
name: state [2222,2227]
name: state [2222,2227]
===
match
---
atom_expr [54987,55012]
atom_expr [54987,55012]
===
match
---
trailer [10573,10638]
trailer [10573,10638]
===
match
---
name: DEFAULT_DATE [60644,60656]
name: DEFAULT_DATE [60644,60656]
===
match
---
fstring_start: f' [67011,67013]
fstring_start: f' [67011,67013]
===
match
---
simple_stmt [46109,46153]
simple_stmt [46109,46153]
===
match
---
name: task2 [43684,43689]
name: task2 [43684,43689]
===
match
---
fstring_end: ' [67118,67119]
fstring_end: ' [67118,67119]
===
match
---
arglist [74499,74519]
arglist [74499,74519]
===
match
---
name: AirflowSkipException [17887,17907]
name: AirflowSkipException [17887,17907]
===
match
---
name: self [47427,47431]
name: self [47427,47431]
===
match
---
arglist [47114,47163]
arglist [47114,47163]
===
match
---
operator: } [73131,73132]
operator: } [73131,73132]
===
match
---
operator: = [37358,37359]
operator: = [37358,37359]
===
match
---
trailer [49972,49983]
trailer [49972,49983]
===
match
---
name: python [1602,1608]
name: python [1602,1608]
===
match
---
argument [34389,34404]
argument [34389,34404]
===
match
---
name: ti [25706,25708]
name: ti [25706,25708]
===
match
---
number: 0 [33742,33743]
number: 0 [33742,33743]
===
match
---
trailer [2623,2632]
trailer [2623,2632]
===
match
---
operator: = [52684,52685]
operator: = [52684,52685]
===
match
---
string: 'xcom_key' [38406,38416]
string: 'xcom_key' [38406,38416]
===
match
---
name: task [48194,48198]
name: task [48194,48198]
===
match
---
name: TI [67944,67946]
name: TI [67944,67946]
===
match
---
name: AirflowException [8219,8235]
name: AirflowException [8219,8235]
===
match
---
atom_expr [12295,12351]
atom_expr [12295,12351]
===
match
---
trailer [76303,76313]
trailer [76303,76313]
===
match
---
argument [4542,4594]
argument [4542,4594]
===
match
---
fstring_string: . [67048,67049]
fstring_string: . [67048,67049]
===
match
---
funcdef [9587,10218]
funcdef [9587,10218]
===
match
---
name: SUCCESS [73235,73242]
name: SUCCESS [73235,73242]
===
match
---
name: State [78458,78463]
name: State [78458,78463]
===
match
---
arglist [43795,43839]
arglist [43795,43839]
===
match
---
expr_stmt [76145,76217]
expr_stmt [76145,76217]
===
match
---
dotted_name [1534,1557]
dotted_name [1534,1557]
===
match
---
testlist_comp [31737,31784]
testlist_comp [31737,31784]
===
match
---
atom_expr [36126,36136]
atom_expr [36126,36136]
===
match
---
arglist [62305,62486]
arglist [62305,62486]
===
match
---
expr_stmt [18243,18295]
expr_stmt [18243,18295]
===
match
---
name: utcnow [23834,23840]
name: utcnow [23834,23840]
===
match
---
operator: , [20375,20376]
operator: , [20375,20376]
===
match
---
param [59427,59442]
param [59427,59442]
===
match
---
simple_stmt [30009,30082]
simple_stmt [30009,30082]
===
match
---
trailer [15981,16000]
trailer [15981,16000]
===
match
---
atom_expr [42904,42912]
atom_expr [42904,42912]
===
match
---
number: 2 [54310,54311]
number: 2 [54310,54311]
===
match
---
name: state [54693,54698]
name: state [54693,54698]
===
match
---
name: test_execute_queries_count_store_serialized [78838,78881]
name: test_execute_queries_count_store_serialized [78838,78881]
===
match
---
trailer [2677,2682]
trailer [2677,2682]
===
match
---
argument [61807,61814]
argument [61807,61814]
===
match
---
comparison [80057,80101]
comparison [80057,80101]
===
match
---
operator: = [46248,46249]
operator: = [46248,46249]
===
match
---
simple_stmt [44320,44345]
simple_stmt [44320,44345]
===
match
---
name: test_operator_field_with_serialization [79481,79519]
name: test_operator_field_with_serialization [79481,79519]
===
match
---
atom_expr [61197,61213]
atom_expr [61197,61213]
===
match
---
name: _try_number [43212,43223]
name: _try_number [43212,43223]
===
match
---
name: test_set_duration [49768,49785]
name: test_set_duration [49768,49785]
===
match
---
trailer [68519,68556]
trailer [68519,68556]
===
match
---
name: stats [1820,1825]
name: stats [1820,1825]
===
match
---
trailer [51006,51012]
trailer [51006,51012]
===
match
---
number: 2 [10437,10438]
number: 2 [10437,10438]
===
match
---
testlist_star_expr [27653,27663]
testlist_star_expr [27653,27663]
===
match
---
param [60386,60393]
param [60386,60393]
===
match
---
trailer [7326,7330]
trailer [7326,7330]
===
match
---
operator: , [17384,17385]
operator: , [17384,17385]
===
match
---
argument [41538,41545]
argument [41538,41545]
===
match
---
operator: , [67364,67365]
operator: , [67364,67365]
===
match
---
name: pendulum [23807,23815]
name: pendulum [23807,23815]
===
match
---
trailer [22623,22632]
trailer [22623,22632]
===
match
---
operator: = [48199,48200]
operator: = [48199,48200]
===
match
---
trailer [53057,53067]
trailer [53057,53067]
===
match
---
argument [13259,13268]
argument [13259,13268]
===
match
---
name: dag [74480,74483]
name: dag [74480,74483]
===
match
---
trailer [44979,44987]
trailer [44979,44987]
===
match
---
operator: } [73204,73205]
operator: } [73204,73205]
===
match
---
name: TI [44860,44862]
name: TI [44860,44862]
===
match
---
comparison [20601,20619]
comparison [20601,20619]
===
match
---
argument [76707,76725]
argument [76707,76725]
===
match
---
operator: = [13730,13731]
operator: = [13730,13731]
===
match
---
name: task [23750,23754]
name: task [23750,23754]
===
match
---
funcdef [36722,38245]
funcdef [36722,38245]
===
match
---
name: ti [36660,36662]
name: ti [36660,36662]
===
match
---
name: mock_on_retry_3 [63187,63202]
name: mock_on_retry_3 [63187,63202]
===
match
---
name: DEFAULT_DATE [65301,65313]
name: DEFAULT_DATE [65301,65313]
===
match
---
simple_stmt [58659,58707]
simple_stmt [58659,58707]
===
match
---
atom_expr [63355,63418]
atom_expr [63355,63418]
===
match
---
atom_expr [14984,15022]
atom_expr [14984,15022]
===
match
---
argument [47806,47815]
argument [47806,47815]
===
match
---
assert_stmt [49638,49694]
assert_stmt [49638,49694]
===
match
---
atom_expr [56621,56661]
atom_expr [56621,56661]
===
match
---
simple_stmt [74831,74861]
simple_stmt [74831,74861]
===
match
---
operator: = [69209,69210]
operator: = [69209,69210]
===
match
---
simple_stmt [50442,50479]
simple_stmt [50442,50479]
===
match
---
simple_stmt [58382,58415]
simple_stmt [58382,58415]
===
match
---
name: execution_date [44218,44232]
name: execution_date [44218,44232]
===
match
---
name: start_date [9721,9731]
name: start_date [9721,9731]
===
match
---
name: DummyOperator [34479,34492]
name: DummyOperator [34479,34492]
===
match
---
operator: , [41620,41621]
operator: , [41620,41621]
===
match
---
operator: = [8495,8496]
operator: = [8495,8496]
===
match
---
operator: , [28687,28688]
operator: , [28687,28688]
===
match
---
name: state [44323,44328]
name: state [44323,44328]
===
match
---
operator: + [5297,5298]
operator: + [5297,5298]
===
match
---
string: """         test that try to create a task with pool_slots less than 1         """ [14568,14650]
string: """         test that try to create a task with pool_slots less than 1         """ [14568,14650]
===
match
---
operator: , [57895,57896]
operator: , [57895,57896]
===
match
---
operator: = [74663,74664]
operator: = [74663,74664]
===
match
---
param [73552,73565]
param [73552,73565]
===
match
---
atom_expr [15452,15680]
atom_expr [15452,15680]
===
match
---
name: non_runnable_state [13310,13328]
name: non_runnable_state [13310,13328]
===
match
---
name: ti [60912,60914]
name: ti [60912,60914]
===
match
---
comparison [25823,25859]
comparison [25823,25859]
===
match
---
comparison [62096,62128]
comparison [62096,62128]
===
match
---
name: start_date [76398,76408]
name: start_date [76398,76408]
===
match
---
string: 'airflow' [34395,34404]
string: 'airflow' [34395,34404]
===
match
---
operator: = [38956,38957]
operator: = [38956,38957]
===
match
---
trailer [13293,13300]
trailer [13293,13300]
===
match
---
arglist [18203,18222]
arglist [18203,18222]
===
match
---
name: task3 [63280,63285]
name: task3 [63280,63285]
===
match
---
name: end_date [23987,23995]
name: end_date [23987,23995]
===
match
---
name: DummyOperator [34344,34357]
name: DummyOperator [34344,34357]
===
match
---
trailer [61325,61333]
trailer [61325,61333]
===
match
---
simple_stmt [5541,5596]
simple_stmt [5541,5596]
===
match
---
name: TI [64781,64783]
name: TI [64781,64783]
===
match
---
atom_expr [10171,10179]
atom_expr [10171,10179]
===
match
---
argument [64024,64073]
argument [64024,64073]
===
match
---
string: 'C' [72747,72750]
string: 'C' [72747,72750]
===
match
---
name: days [66424,66428]
name: days [66424,66428]
===
match
---
trailer [39145,39149]
trailer [39145,39149]
===
match
---
simple_stmt [54049,54112]
simple_stmt [54049,54112]
===
match
---
name: DEFAULT_DATE [10368,10380]
name: DEFAULT_DATE [10368,10380]
===
match
---
comparison [63548,63580]
comparison [63548,63580]
===
match
---
trailer [64052,64073]
trailer [64052,64073]
===
match
---
operator: = [2707,2708]
operator: = [2707,2708]
===
match
---
name: state [43386,43391]
name: state [43386,43391]
===
match
---
assert_stmt [79647,79687]
assert_stmt [79647,79687]
===
match
---
number: 1 [15654,15655]
number: 1 [15654,15655]
===
match
---
string: 'test_check_and_change_state_before_execution' [43006,43052]
string: 'test_check_and_change_state_before_execution' [43006,43052]
===
match
---
name: instance [22224,22232]
name: instance [22224,22232]
===
match
---
name: ti_list [54987,54994]
name: ti_list [54987,54994]
===
match
---
trailer [55975,55989]
trailer [55975,55989]
===
match
---
name: create_dagrun [30767,30780]
name: create_dagrun [30767,30780]
===
match
---
name: staticmethod [77691,77703]
name: staticmethod [77691,77703]
===
match
---
name: datetime [18194,18202]
name: datetime [18194,18202]
===
match
---
import_name [788,803]
import_name [788,803]
===
match
---
trailer [28655,28666]
trailer [28655,28666]
===
match
---
name: done [26795,26799]
name: done [26795,26799]
===
match
---
simple_stmt [79893,79957]
simple_stmt [79893,79957]
===
match
---
trailer [78518,78532]
trailer [78518,78532]
===
match
---
argument [14150,14199]
argument [14150,14199]
===
match
---
atom_expr [47183,47191]
atom_expr [47183,47191]
===
match
---
trailer [67946,67963]
trailer [67946,67963]
===
match
---
name: now [80256,80259]
name: now [80256,80259]
===
match
---
trailer [55177,55184]
trailer [55177,55184]
===
match
---
name: DAG [14713,14716]
name: DAG [14713,14716]
===
match
---
name: DAG [64460,64463]
name: DAG [64460,64463]
===
match
---
atom_expr [7229,7235]
atom_expr [7229,7235]
===
match
---
trailer [72351,72356]
trailer [72351,72356]
===
match
---
suite [25544,25608]
suite [25544,25608]
===
match
---
trailer [56472,56486]
trailer [56472,56486]
===
match
---
name: start_date [30714,30724]
name: start_date [30714,30724]
===
match
---
suite [28264,28351]
suite [28264,28351]
===
match
---
trailer [60487,60494]
trailer [60487,60494]
===
match
---
simple_stmt [50351,50378]
simple_stmt [50351,50378]
===
match
---
operator: = [50649,50650]
operator: = [50649,50650]
===
match
---
trailer [45139,45147]
trailer [45139,45147]
===
match
---
arglist [10300,10439]
arglist [10300,10439]
===
match
---
testlist_comp [33349,33395]
testlist_comp [33349,33395]
===
match
---
operator: , [36111,36112]
operator: , [36111,36112]
===
match
---
operator: , [34027,34028]
operator: , [34027,34028]
===
match
---
argument [38648,38663]
argument [38648,38663]
===
match
---
operator: = [41479,41480]
operator: = [41479,41480]
===
match
---
simple_stmt [44506,44535]
simple_stmt [44506,44535]
===
match
---
trailer [77372,77382]
trailer [77372,77382]
===
match
---
atom_expr [58560,58600]
atom_expr [58560,58600]
===
match
---
string: 'one_success' [32416,32429]
string: 'one_success' [32416,32429]
===
match
---
operator: = [71038,71039]
operator: = [71038,71039]
===
match
---
param [68159,68163]
param [68159,68163]
===
match
---
name: timedelta [53058,53067]
name: timedelta [53058,53067]
===
match
---
name: UP_FOR_RESCHEDULE [27846,27863]
name: UP_FOR_RESCHEDULE [27846,27863]
===
match
---
atom_expr [3165,3175]
atom_expr [3165,3175]
===
match
---
trailer [23833,23840]
trailer [23833,23840]
===
match
---
simple_stmt [58226,58274]
simple_stmt [58226,58274]
===
match
---
operator: == [67554,67556]
operator: == [67554,67556]
===
match
---
trailer [79931,79950]
trailer [79931,79950]
===
match
---
argument [23745,23754]
argument [23745,23754]
===
match
---
operator: = [65613,65614]
operator: = [65613,65614]
===
match
---
trailer [56685,56703]
trailer [56685,56703]
===
match
---
string: """         Test that get_previous_start_date() can handle TaskInstance with no start_date.         """ [55728,55831]
string: """         Test that get_previous_start_date() can handle TaskInstance with no start_date.         """ [55728,55831]
===
match
---
name: date3 [26964,26969]
name: date3 [26964,26969]
===
match
---
atom_expr [35908,35933]
atom_expr [35908,35933]
===
match
---
arith_expr [66390,66432]
arith_expr [66390,66432]
===
match
---
name: session [50962,50969]
name: session [50962,50969]
===
match
---
dictorsetmaker [76900,76930]
dictorsetmaker [76900,76930]
===
match
---
name: session [15904,15911]
name: session [15904,15911]
===
match
---
string: '@monthly' [36919,36929]
string: '@monthly' [36919,36929]
===
match
---
name: models [56932,56938]
name: models [56932,56938]
===
match
---
assert_stmt [20904,20930]
assert_stmt [20904,20930]
===
match
---
simple_stmt [30213,30240]
simple_stmt [30213,30240]
===
match
---
trailer [28779,28788]
trailer [28779,28788]
===
match
---
atom_expr [58801,58873]
atom_expr [58801,58873]
===
match
---
name: dag [34515,34518]
name: dag [34515,34518]
===
match
---
operator: @ [58879,58880]
operator: @ [58879,58880]
===
match
---
name: DummyOperator [46116,46129]
name: DummyOperator [46116,46129]
===
match
---
parameters [65003,65009]
parameters [65003,65009]
===
match
---
name: naive_datetime [5580,5594]
name: naive_datetime [5580,5594]
===
match
---
number: 0 [30076,30077]
number: 0 [30076,30077]
===
match
---
operator: = [43633,43634]
operator: = [43633,43634]
===
match
---
name: dag2 [44814,44818]
name: dag2 [44814,44818]
===
match
---
name: self [79520,79524]
name: self [79520,79524]
===
match
---
trailer [15392,15424]
trailer [15392,15424]
===
match
---
atom_expr [43383,43391]
atom_expr [43383,43391]
===
match
---
operator: = [23236,23237]
operator: = [23236,23237]
===
match
---
name: ti [49473,49475]
name: ti [49473,49475]
===
match
---
with_item [11569,11596]
with_item [11569,11596]
===
match
---
name: State [71985,71990]
name: State [71985,71990]
===
match
---
atom_expr [3368,3387]
atom_expr [3368,3387]
===
match
---
name: ti [10171,10173]
name: ti [10171,10173]
===
match
---
param [25215,25235]
param [25215,25235]
===
match
---
name: datetime [47832,47840]
name: datetime [47832,47840]
===
match
---
trailer [71878,71883]
trailer [71878,71883]
===
match
---
operator: = [38459,38460]
operator: = [38459,38460]
===
match
---
comparison [65103,65159]
comparison [65103,65159]
===
match
---
simple_stmt [21251,21277]
simple_stmt [21251,21277]
===
match
---
trailer [5317,5325]
trailer [5317,5325]
===
match
---
operator: = [45099,45100]
operator: = [45099,45100]
===
match
---
number: 5 [32905,32906]
number: 5 [32905,32906]
===
match
---
operator: , [73094,73095]
operator: , [73094,73095]
===
match
---
assert_stmt [77069,77098]
assert_stmt [77069,77098]
===
match
---
simple_stmt [43237,43289]
simple_stmt [43237,43289]
===
match
---
name: add [52651,52654]
name: add [52651,52654]
===
match
---
name: DEFAULT_DATE [68543,68555]
name: DEFAULT_DATE [68543,68555]
===
match
---
funcdef [5331,6276]
funcdef [5331,6276]
===
match
---
name: ti [79453,79455]
name: ti [79453,79455]
===
match
---
trailer [12019,12021]
trailer [12019,12021]
===
match
---
name: SUCCESS [53342,53349]
name: SUCCESS [53342,53349]
===
match
---
trailer [68915,68922]
trailer [68915,68922]
===
match
---
name: test_requeue_over_task_concurrency [9591,9625]
name: test_requeue_over_task_concurrency [9591,9625]
===
match
---
suite [64377,64438]
suite [64377,64438]
===
match
---
operator: + [26293,26294]
operator: + [26293,26294]
===
match
---
string: 'op1' [70373,70378]
string: 'op1' [70373,70378]
===
match
---
argument [4651,4658]
argument [4651,4658]
===
match
---
atom_expr [40554,40579]
atom_expr [40554,40579]
===
match
---
trailer [55460,55468]
trailer [55460,55468]
===
match
---
atom_expr [4247,4259]
atom_expr [4247,4259]
===
match
---
operator: , [46217,46218]
operator: , [46217,46218]
===
match
---
import_from [1980,2036]
import_from [1980,2036]
===
match
---
operator: = [22613,22614]
operator: = [22613,22614]
===
match
---
operator: { [69342,69343]
operator: { [69342,69343]
===
match
---
simple_stmt [26713,26786]
simple_stmt [26713,26786]
===
match
---
trailer [19053,19055]
trailer [19053,19055]
===
match
---
param [67233,67237]
param [67233,67237]
===
match
---
operator: , [46074,46075]
operator: , [46074,46075]
===
match
---
name: timezone [23679,23687]
name: timezone [23679,23687]
===
match
---
atom [57601,57906]
atom [57601,57906]
===
match
---
name: DagRunType [16563,16573]
name: DagRunType [16563,16573]
===
match
---
operator: { [69283,69284]
operator: { [69283,69284]
===
match
---
param [8938,8962]
param [8938,8962]
===
match
---
name: raises [60190,60196]
name: raises [60190,60196]
===
match
---
trailer [34283,34287]
trailer [34283,34287]
===
match
---
argument [37688,37697]
argument [37688,37697]
===
match
---
simple_stmt [51841,51912]
simple_stmt [51841,51912]
===
match
---
operator: , [15655,15656]
operator: , [15655,15656]
===
match
---
trailer [70810,70814]
trailer [70810,70814]
===
match
---
name: create_session [71274,71288]
name: create_session [71274,71288]
===
match
---
argument [44730,44737]
argument [44730,44737]
===
match
---
simple_stmt [18243,18296]
simple_stmt [18243,18296]
===
match
---
string: 'A' [71980,71983]
string: 'A' [71980,71983]
===
match
---
operator: = [17243,17244]
operator: = [17243,17244]
===
match
---
trailer [43211,43223]
trailer [43211,43223]
===
match
---
operator: + [29603,29604]
operator: + [29603,29604]
===
match
---
name: clear_db_task_reschedule [3634,3658]
name: clear_db_task_reschedule [3634,3658]
===
match
---
name: execution_date [79236,79250]
name: execution_date [79236,79250]
===
match
---
arglist [26964,27019]
arglist [26964,27019]
===
match
---
name: create_dagrun [52016,52029]
name: create_dagrun [52016,52029]
===
match
---
name: expected_try_number [25724,25743]
name: expected_try_number [25724,25743]
===
match
---
name: timedelta [26196,26205]
name: timedelta [26196,26205]
===
match
---
name: bash_command [21854,21866]
name: bash_command [21854,21866]
===
match
---
operator: , [32441,32442]
operator: , [32441,32442]
===
match
---
funcdef [3455,3661]
funcdef [3455,3661]
===
match
---
name: xcom_pull [39272,39281]
name: xcom_pull [39272,39281]
===
match
---
trailer [75972,75974]
trailer [75972,75974]
===
match
---
operator: = [40615,40616]
operator: = [40615,40616]
===
match
---
name: dag_run [71536,71543]
name: dag_run [71536,71543]
===
match
---
simple_stmt [5160,5178]
simple_stmt [5160,5178]
===
match
---
trailer [17409,17416]
trailer [17409,17416]
===
match
---
arglist [42607,42780]
arglist [42607,42780]
===
match
---
trailer [80072,80082]
trailer [80072,80082]
===
match
---
param [51946,51980]
param [51946,51980]
===
match
---
operator: = [37023,37024]
operator: = [37023,37024]
===
match
---
name: execution_date [6249,6263]
name: execution_date [6249,6263]
===
match
---
name: NONE [10954,10958]
name: NONE [10954,10958]
===
match
---
name: dag [36839,36842]
name: dag [36839,36842]
===
match
---
name: models [44550,44556]
name: models [44550,44556]
===
match
---
operator: , [42725,42726]
operator: , [42725,42726]
===
match
---
funcdef [8894,9582]
funcdef [8894,9582]
===
match
---
name: get_previous_execution_date [54831,54858]
name: get_previous_execution_date [54831,54858]
===
match
---
name: ti_2 [56670,56674]
name: ti_2 [56670,56674]
===
match
---
operator: == [77195,77197]
operator: == [77195,77197]
===
match
---
name: key [37983,37986]
name: key [37983,37986]
===
match
---
comparison [58389,58414]
comparison [58389,58414]
===
match
---
name: State [55172,55177]
name: State [55172,55177]
===
match
---
trailer [22405,22409]
trailer [22405,22409]
===
match
---
string: 'all_success' [31880,31893]
string: 'all_success' [31880,31893]
===
match
---
name: state [76197,76202]
name: state [76197,76202]
===
match
---
trailer [9979,9981]
trailer [9979,9981]
===
match
---
name: _test_previous_dates_setup [51557,51583]
name: _test_previous_dates_setup [51557,51583]
===
match
---
operator: = [69154,69155]
operator: = [69154,69155]
===
match
---
assert_stmt [22430,22451]
assert_stmt [22430,22451]
===
match
---
trailer [40261,40282]
trailer [40261,40282]
===
match
---
number: 1 [50017,50018]
number: 1 [50017,50018]
===
match
---
param [21604,21608]
param [21604,21608]
===
match
---
import_as_names [1069,1089]
import_as_names [1069,1089]
===
match
---
name: pool_override [77035,77048]
name: pool_override [77035,77048]
===
match
---
decorated [51535,52779]
decorated [51535,52779]
===
match
---
argument [9843,9890]
argument [9843,9890]
===
match
---
atom_expr [41134,41203]
atom_expr [41134,41203]
===
match
---
name: timezone [11425,11433]
name: timezone [11425,11433]
===
match
---
atom_expr [36845,37003]
atom_expr [36845,37003]
===
match
---
string: 'C' [73118,73121]
string: 'C' [73118,73121]
===
match
---
assert_stmt [6925,6948]
assert_stmt [6925,6948]
===
match
---
trailer [53519,53535]
trailer [53519,53535]
===
match
---
name: mock_on_failure_2 [62182,62199]
name: mock_on_failure_2 [62182,62199]
===
match
---
string: 'test' [4522,4528]
string: 'test' [4522,4528]
===
match
---
string: 'one_success' [32576,32589]
string: 'one_success' [32576,32589]
===
match
---
operator: , [39302,39303]
operator: , [39302,39303]
===
match
---
if_stmt [42431,42508]
if_stmt [42431,42508]
===
match
---
operator: , [73787,73788]
operator: , [73787,73788]
===
match
---
arglist [15782,15920]
arglist [15782,15920]
===
match
---
operator: = [49573,49574]
operator: = [49573,49574]
===
match
---
atom_expr [61102,61122]
atom_expr [61102,61122]
===
match
---
name: self [76012,76016]
name: self [76012,76016]
===
match
---
name: start_date [25826,25836]
name: start_date [25826,25836]
===
match
---
name: State [30194,30199]
name: State [30194,30199]
===
match
---
import_from [1263,1314]
import_from [1263,1314]
===
match
---
name: RUNNING [50946,50953]
name: RUNNING [50946,50953]
===
match
---
name: result [58326,58332]
name: result [58326,58332]
===
match
---
suite [77955,77978]
suite [77955,77978]
===
match
---
number: 0 [27974,27975]
number: 0 [27974,27975]
===
match
---
name: run_type [18414,18422]
name: run_type [18414,18422]
===
match
---
name: task [37163,37167]
name: task [37163,37167]
===
match
---
dictorsetmaker [73039,73093]
dictorsetmaker [73039,73093]
===
match
---
assert_stmt [67154,67187]
assert_stmt [67154,67187]
===
match
---
name: UP_FOR_RESCHEDULE [26761,26778]
name: UP_FOR_RESCHEDULE [26761,26778]
===
match
---
operator: , [28805,28806]
operator: , [28805,28806]
===
match
---
number: 0 [15663,15664]
number: 0 [15663,15664]
===
match
---
name: date1 [27589,27594]
name: date1 [27589,27594]
===
match
---
trailer [34726,34749]
trailer [34726,34749]
===
match
---
name: pendulum [76973,76981]
name: pendulum [76973,76981]
===
match
---
trailer [63498,63508]
trailer [63498,63508]
===
match
---
simple_stmt [46552,46594]
simple_stmt [46552,46594]
===
match
---
trailer [14261,14268]
trailer [14261,14268]
===
match
---
name: ti [11483,11485]
name: ti [11483,11485]
===
match
---
funcdef [44451,45465]
funcdef [44451,45465]
===
match
---
string: 'test_run_pooling_task_op' [14807,14833]
string: 'test_run_pooling_task_op' [14807,14833]
===
match
---
operator: , [33177,33178]
operator: , [33177,33178]
===
match
---
name: result [37714,37720]
name: result [37714,37720]
===
match
---
atom_expr [37025,37042]
atom_expr [37025,37042]
===
match
---
name: scheduler_job [75892,75905]
name: scheduler_job [75892,75905]
===
match
---
operator: , [78666,78667]
operator: , [78666,78667]
===
match
---
name: datetime [44961,44969]
name: datetime [44961,44969]
===
match
---
name: SUCCESS [53313,53320]
name: SUCCESS [53313,53320]
===
match
---
name: task [5841,5845]
name: task [5841,5845]
===
match
---
atom_expr [20235,20264]
atom_expr [20235,20264]
===
match
---
name: task3 [63026,63031]
name: task3 [63026,63031]
===
match
---
number: 10 [50066,50068]
number: 10 [50066,50068]
===
match
---
operator: , [61151,61152]
operator: , [61151,61152]
===
match
---
number: 0 [28807,28808]
number: 0 [28807,28808]
===
match
---
name: xcom_pull [41982,41991]
name: xcom_pull [41982,41991]
===
match
---
suite [41248,42046]
suite [41248,42046]
===
match
---
operator: = [18873,18874]
operator: = [18873,18874]
===
match
---
trailer [12409,12416]
trailer [12409,12416]
===
match
---
name: session [16605,16612]
name: session [16605,16612]
===
match
---
operator: , [20264,20265]
operator: , [20264,20265]
===
match
---
argument [37223,37232]
argument [37223,37232]
===
match
---
name: FAILED [53828,53834]
name: FAILED [53828,53834]
===
match
---
trailer [21380,21386]
trailer [21380,21386]
===
match
---
simple_stmt [38838,38989]
simple_stmt [38838,38989]
===
match
---
name: schedule_interval [53402,53419]
name: schedule_interval [53402,53419]
===
match
---
name: create_session [11569,11583]
name: create_session [11569,11583]
===
match
---
trailer [13210,13231]
trailer [13210,13231]
===
match
---
trailer [21734,21753]
trailer [21734,21753]
===
match
---
name: TI [68318,68320]
name: TI [68318,68320]
===
match
---
name: date4 [27095,27100]
name: date4 [27095,27100]
===
match
---
operator: = [51796,51797]
operator: = [51796,51797]
===
match
---
name: scenario [55309,55317]
name: scenario [55309,55317]
===
match
---
name: DummyOperator [78327,78340]
name: DummyOperator [78327,78340]
===
match
---
atom_expr [51612,51648]
atom_expr [51612,51648]
===
match
---
name: execution_date [53627,53641]
name: execution_date [53627,53641]
===
match
---
name: execution_date [5615,5629]
name: execution_date [5615,5629]
===
match
---
simple_stmt [20692,20730]
simple_stmt [20692,20730]
===
match
---
simple_stmt [37854,37877]
simple_stmt [37854,37877]
===
match
---
operator: = [76772,76773]
operator: = [76772,76773]
===
match
---
string: 'test_requeue_over_pool_concurrency' [10307,10343]
string: 'test_requeue_over_pool_concurrency' [10307,10343]
===
match
---
string: 'test_retry_handling_op' [20106,20130]
string: 'test_retry_handling_op' [20106,20130]
===
match
---
name: start_date [69089,69099]
name: start_date [69089,69099]
===
match
---
name: state [40471,40476]
name: state [40471,40476]
===
match
---
name: DummyOperator [13010,13023]
name: DummyOperator [13010,13023]
===
match
---
name: dag [50839,50842]
name: dag [50839,50842]
===
match
---
atom_expr [54568,54637]
atom_expr [54568,54637]
===
match
---
trailer [64123,64168]
trailer [64123,64168]
===
match
---
name: start_date [59995,60005]
name: start_date [59995,60005]
===
match
---
name: timezone [24901,24909]
name: timezone [24901,24909]
===
match
---
name: trigger_rule [33964,33976]
name: trigger_rule [33964,33976]
===
match
---
simple_stmt [57990,58062]
simple_stmt [57990,58062]
===
match
---
operator: , [73412,73413]
operator: , [73412,73413]
===
match
---
name: task_id [30579,30586]
name: task_id [30579,30586]
===
match
---
funcdef [50383,51530]
funcdef [50383,51530]
===
match
---
argument [60754,60776]
argument [60754,60776]
===
match
---
operator: = [37443,37444]
operator: = [37443,37444]
===
match
---
argument [37983,37992]
argument [37983,37992]
===
match
---
name: successes [34824,34833]
name: successes [34824,34833]
===
match
---
operator: , [72601,72602]
operator: , [72601,72602]
===
match
---
operator: = [66545,66546]
operator: = [66545,66546]
===
match
---
operator: , [73863,73864]
operator: , [73863,73864]
===
match
---
trailer [16692,16694]
trailer [16692,16694]
===
match
---
trailer [23862,23882]
trailer [23862,23882]
===
match
---
atom_expr [4116,4143]
atom_expr [4116,4143]
===
match
---
simple_stmt [22983,23022]
simple_stmt [22983,23022]
===
match
---
not_test [25568,25576]
not_test [25568,25576]
===
match
---
simple_stmt [6385,6521]
simple_stmt [6385,6521]
===
match
---
operator: = [79065,79066]
operator: = [79065,79066]
===
match
---
simple_stmt [6739,6781]
simple_stmt [6739,6781]
===
match
---
operator: @ [54333,54334]
operator: @ [54333,54334]
===
match
---
operator: = [20033,20034]
operator: = [20033,20034]
===
match
---
simple_stmt [28339,28351]
simple_stmt [28339,28351]
===
match
---
operator: = [49893,49894]
operator: = [49893,49894]
===
match
---
number: 0 [27837,27838]
number: 0 [27837,27838]
===
match
---
name: self [59412,59416]
name: self [59412,59416]
===
match
---
operator: , [27636,27637]
operator: , [27636,27637]
===
match
---
number: 4 [21436,21437]
number: 4 [21436,21437]
===
match
---
name: bash [1504,1508]
name: bash [1504,1508]
===
match
---
argument [71046,71079]
argument [71046,71079]
===
match
---
number: 2 [33853,33854]
number: 2 [33853,33854]
===
match
---
atom_expr [60220,60291]
atom_expr [60220,60291]
===
match
---
operator: { [68959,68960]
operator: { [68959,68960]
===
match
---
trailer [8268,8273]
trailer [8268,8273]
===
match
---
arglist [79787,79836]
arglist [79787,79836]
===
match
---
argument [15568,15598]
argument [15568,15598]
===
match
---
atom [58924,58998]
atom [58924,58998]
===
match
---
number: 1 [41784,41785]
number: 1 [41784,41785]
===
match
---
name: op2 [8558,8561]
name: op2 [8558,8561]
===
match
---
name: timezone [28864,28872]
name: timezone [28864,28872]
===
match
---
string: 'op1' [69912,69917]
string: 'op1' [69912,69917]
===
match
---
name: minutes [26260,26267]
name: minutes [26260,26267]
===
match
---
atom_expr [75453,75474]
atom_expr [75453,75474]
===
match
---
atom_expr [75159,75173]
atom_expr [75159,75173]
===
match
---
operator: , [11534,11535]
operator: , [11534,11535]
===
match
---
arglist [15645,15664]
arglist [15645,15664]
===
match
---
trailer [37096,37145]
trailer [37096,37145]
===
match
---
operator: , [50551,50552]
operator: , [50551,50552]
===
match
---
assert_stmt [20738,20764]
assert_stmt [20738,20764]
===
match
---
expr_stmt [23344,23728]
expr_stmt [23344,23728]
===
match
---
name: create_dagrun [74669,74682]
name: create_dagrun [74669,74682]
===
match
---
argument [10528,10535]
argument [10528,10535]
===
match
---
operator: , [34872,34873]
operator: , [34872,34873]
===
match
---
atom_expr [51358,51387]
atom_expr [51358,51387]
===
match
---
trailer [77326,77338]
trailer [77326,77338]
===
match
---
simple_stmt [77457,77502]
simple_stmt [77457,77502]
===
match
---
with_stmt [8282,8363]
with_stmt [8282,8363]
===
match
---
argument [41509,41524]
argument [41509,41524]
===
match
---
operator: = [22703,22704]
operator: = [22703,22704]
===
match
---
suite [63706,63758]
suite [63706,63758]
===
match
---
atom_expr [25982,26023]
atom_expr [25982,26023]
===
match
---
name: run_with_error [20837,20851]
name: run_with_error [20837,20851]
===
match
---
trailer [62170,62172]
trailer [62170,62172]
===
match
---
name: NONE [72352,72356]
name: NONE [72352,72356]
===
match
---
string: 'test_dagrun_fast_follow' [74690,74715]
string: 'test_dagrun_fast_follow' [74690,74715]
===
match
---
simple_stmt [27913,27977]
simple_stmt [27913,27977]
===
match
---
name: date [22665,22669]
name: date [22665,22669]
===
match
---
name: utcnow [37034,37040]
name: utcnow [37034,37040]
===
match
---
arglist [47493,47542]
arglist [47493,47542]
===
match
---
comparison [43383,43408]
comparison [43383,43408]
===
match
---
operator: , [16241,16242]
operator: , [16241,16242]
===
match
---
atom_expr [8332,8362]
atom_expr [8332,8362]
===
match
---
atom_expr [5044,5070]
atom_expr [5044,5070]
===
match
---
operator: = [51071,51072]
operator: = [51071,51072]
===
match
---
expr_stmt [44615,44684]
expr_stmt [44615,44684]
===
match
---
argument [30616,30623]
argument [30616,30623]
===
match
---
trailer [46750,46756]
trailer [46750,46756]
===
match
---
name: timedelta [4989,4998]
name: timedelta [4989,4998]
===
match
---
simple_stmt [4785,4858]
simple_stmt [4785,4858]
===
match
---
name: DagRunType [56576,56586]
name: DagRunType [56576,56586]
===
match
---
trailer [71561,71578]
trailer [71561,71578]
===
match
---
trailer [75066,75076]
trailer [75066,75076]
===
match
---
trailer [77092,77098]
trailer [77092,77098]
===
match
---
atom_expr [12935,12994]
atom_expr [12935,12994]
===
match
---
name: AirflowException [7967,7983]
name: AirflowException [7967,7983]
===
match
---
param [77941,77945]
param [77941,77945]
===
match
---
name: expected_end_date [25894,25911]
name: expected_end_date [25894,25911]
===
match
---
trailer [53652,53655]
trailer [53652,53655]
===
match
---
trailer [64712,64733]
trailer [64712,64733]
===
match
---
trailer [44969,44979]
trailer [44969,44979]
===
match
---
name: ti [14440,14442]
name: ti [14440,14442]
===
match
---
atom_expr [21390,21402]
atom_expr [21390,21402]
===
match
---
trailer [75792,75794]
trailer [75792,75794]
===
match
---
not_test [35717,35746]
not_test [35717,35746]
===
match
---
arglist [52977,53011]
arglist [52977,53011]
===
match
---
operator: , [64717,64718]
operator: , [64717,64718]
===
match
---
name: run_ti_and_assert [30009,30026]
name: run_ti_and_assert [30009,30026]
===
match
---
operator: = [59680,59681]
operator: = [59680,59681]
===
match
---
string: 'all_success' [31675,31688]
string: 'all_success' [31675,31688]
===
match
---
suite [11831,12181]
suite [11831,12181]
===
match
---
operator: , [22062,22063]
operator: , [22062,22063]
===
match
---
name: State [27840,27845]
name: State [27840,27845]
===
match
---
name: start_date [48287,48297]
name: start_date [48287,48297]
===
match
---
name: SUCCESS [55221,55228]
name: SUCCESS [55221,55228]
===
match
---
trailer [74133,74179]
trailer [74133,74179]
===
match
---
name: expected_output [59893,59908]
name: expected_output [59893,59908]
===
match
---
if_stmt [25565,25608]
if_stmt [25565,25608]
===
match
---
trailer [23696,23717]
trailer [23696,23717]
===
match
---
suite [49456,49482]
suite [49456,49482]
===
match
---
name: airflow [2246,2253]
name: airflow [2246,2253]
===
match
---
atom [16710,16724]
atom [16710,16724]
===
match
---
name: set_state [76304,76313]
name: set_state [76304,76313]
===
match
---
argument [9949,9981]
argument [9949,9981]
===
match
---
operator: = [17940,17941]
operator: = [17940,17941]
===
match
---
name: next_retry_datetime [22271,22290]
name: next_retry_datetime [22271,22290]
===
match
---
expr_stmt [65573,65698]
expr_stmt [65573,65698]
===
match
---
operator: = [26806,26807]
operator: = [26806,26807]
===
match
---
operator: , [26988,26989]
operator: , [26988,26989]
===
match
---
argument [44218,44250]
argument [44218,44250]
===
match
---
trailer [56942,57111]
trailer [56942,57111]
===
match
---
argument [65939,65946]
argument [65939,65946]
===
match
---
argument [35850,35877]
argument [35850,35877]
===
match
---
name: date1 [30034,30039]
name: date1 [30034,30039]
===
match
---
trailer [5307,5317]
trailer [5307,5317]
===
match
---
operator: == [77234,77236]
operator: == [77234,77236]
===
match
---
simple_stmt [77757,77777]
simple_stmt [77757,77777]
===
match
---
arglist [14179,14198]
arglist [14179,14198]
===
match
---
string: '&task_id=op' [46368,46381]
string: '&task_id=op' [46368,46381]
===
match
---
arglist [9302,9365]
arglist [9302,9365]
===
match
---
operator: , [18956,18957]
operator: , [18956,18957]
===
match
---
operator: = [22588,22589]
operator: = [22588,22589]
===
match
---
string: 'test' [8605,8611]
string: 'test' [8605,8611]
===
match
---
name: isinstance [57408,57418]
name: isinstance [57408,57418]
===
match
---
name: task [77198,77202]
name: task [77198,77202]
===
match
---
name: ti [29509,29511]
name: ti [29509,29511]
===
match
---
operator: = [6794,6795]
operator: = [6794,6795]
===
match
---
assert_stmt [8125,8146]
assert_stmt [8125,8146]
===
match
---
name: ti [41842,41844]
name: ti [41842,41844]
===
match
---
simple_stmt [39032,39067]
simple_stmt [39032,39067]
===
match
---
argument [50881,50919]
argument [50881,50919]
===
match
---
operator: , [71921,71922]
operator: , [71921,71922]
===
match
---
name: patch [49376,49381]
name: patch [49376,49381]
===
match
---
atom [78098,78107]
atom [78098,78107]
===
match
---
number: 2017 [41775,41779]
number: 2017 [41775,41779]
===
match
---
operator: = [7767,7768]
operator: = [7767,7768]
===
match
---
operator: = [64636,64637]
operator: = [64636,64637]
===
match
---
operator: , [28523,28524]
operator: , [28523,28524]
===
match
---
trailer [57418,57478]
trailer [57418,57478]
===
match
---
atom_expr [43175,43192]
atom_expr [43175,43192]
===
match
---
number: 1 [30079,30080]
number: 1 [30079,30080]
===
match
---
operator: , [62343,62344]
operator: , [62343,62344]
===
match
---
trailer [72774,72779]
trailer [72774,72779]
===
match
---
name: State [54269,54274]
name: State [54269,54274]
===
match
---
name: expected_duration [25279,25296]
name: expected_duration [25279,25296]
===
match
---
decorator [8844,8890]
decorator [8844,8890]
===
match
---
operator: , [13109,13110]
operator: , [13109,13110]
===
match
---
name: DEFAULT_DATE [4101,4113]
name: DEFAULT_DATE [4101,4113]
===
match
---
simple_stmt [26171,26217]
simple_stmt [26171,26217]
===
match
---
name: python_callable [74361,74376]
name: python_callable [74361,74376]
===
match
---
operator: , [33866,33867]
operator: , [33866,33867]
===
match
---
comparison [7324,7337]
comparison [7324,7337]
===
match
---
operator: = [17123,17124]
operator: = [17123,17124]
===
match
---
operator: = [14766,14767]
operator: = [14766,14767]
===
match
---
trailer [65197,65199]
trailer [65197,65199]
===
match
---
number: 15 [23978,23980]
number: 15 [23978,23980]
===
match
---
simple_stmt [39956,39973]
simple_stmt [39956,39973]
===
match
---
number: 0 [32511,32512]
number: 0 [32511,32512]
===
match
---
assert_stmt [21446,21471]
assert_stmt [21446,21471]
===
match
---
operator: , [76161,76162]
operator: , [76161,76162]
===
match
---
trailer [75487,75492]
trailer [75487,75492]
===
match
---
argument [23504,23521]
argument [23504,23521]
===
match
---
name: _test_previous_dates_setup [53375,53401]
name: _test_previous_dates_setup [53375,53401]
===
match
---
expr_stmt [52261,52310]
expr_stmt [52261,52310]
===
match
---
operator: = [65407,65408]
operator: = [65407,65408]
===
match
---
operator: , [76111,76112]
operator: , [76111,76112]
===
match
---
name: key [39721,39724]
name: key [39721,39724]
===
match
---
name: datetime [41766,41774]
name: datetime [41766,41774]
===
match
---
simple_stmt [66952,66973]
simple_stmt [66952,66973]
===
match
---
annassign [2530,2552]
annassign [2530,2552]
===
match
---
operator: , [32450,32451]
operator: , [32450,32451]
===
match
---
atom_expr [52342,52355]
atom_expr [52342,52355]
===
match
---
operator: { [72304,72305]
operator: { [72304,72305]
===
match
---
simple_stmt [1916,1980]
simple_stmt [1916,1980]
===
match
---
operator: , [32553,32554]
operator: , [32553,32554]
===
match
---
trailer [3495,3497]
trailer [3495,3497]
===
match
---
simple_stmt [47280,47335]
simple_stmt [47280,47335]
===
match
---
trailer [22605,22618]
trailer [22605,22618]
===
match
---
simple_stmt [13686,13703]
simple_stmt [13686,13703]
===
match
---
trailer [22744,22746]
trailer [22744,22746]
===
match
---
simple_stmt [65403,65565]
simple_stmt [65403,65565]
===
match
---
simple_stmt [61301,61334]
simple_stmt [61301,61334]
===
match
---
trailer [3164,3192]
trailer [3164,3192]
===
match
---
operator: = [46173,46174]
operator: = [46173,46174]
===
match
---
trailer [10914,10918]
trailer [10914,10918]
===
match
---
argument [15393,15423]
argument [15393,15423]
===
match
---
name: DAG [48153,48156]
name: DAG [48153,48156]
===
match
---
name: render_template [59834,59849]
name: render_template [59834,59849]
===
match
---
name: ti [26020,26022]
name: ti [26020,26022]
===
match
---
atom_expr [25044,25061]
atom_expr [25044,25061]
===
match
---
name: dag [46144,46147]
name: dag [46144,46147]
===
match
---
name: AirflowFailException [64218,64238]
name: AirflowFailException [64218,64238]
===
match
---
name: state [3382,3387]
name: state [3382,3387]
===
match
---
operator: , [38710,38711]
operator: , [38710,38711]
===
match
---
name: RUNNING [78464,78471]
name: RUNNING [78464,78471]
===
match
---
trailer [5163,5172]
trailer [5163,5172]
===
match
---
number: 0 [11461,11462]
number: 0 [11461,11462]
===
match
---
operator: + [30725,30726]
operator: + [30725,30726]
===
match
---
operator: = [24420,24421]
operator: = [24420,24421]
===
match
---
operator: , [32029,32030]
operator: , [32029,32030]
===
match
---
operator: , [17492,17493]
operator: , [17492,17493]
===
match
---
expr_stmt [2645,2689]
expr_stmt [2645,2689]
===
match
---
arglist [4060,4143]
arglist [4060,4143]
===
match
---
trailer [15101,15103]
trailer [15101,15103]
===
match
---
operator: , [13227,13228]
operator: , [13227,13228]
===
match
---
operator: = [15540,15541]
operator: = [15540,15541]
===
match
---
operator: , [36068,36069]
operator: , [36068,36069]
===
match
---
funcdef [3666,3869]
funcdef [3666,3869]
===
match
---
operator: , [68267,68268]
operator: , [68267,68268]
===
match
---
simple_stmt [78485,78503]
simple_stmt [78485,78503]
===
match
---
name: ti [20911,20913]
name: ti [20911,20913]
===
match
---
string: 'task_id' [69901,69910]
string: 'task_id' [69901,69910]
===
match
---
name: dag [7334,7337]
name: dag [7334,7337]
===
match
---
name: commit [66089,66095]
name: commit [66089,66095]
===
match
---
trailer [15738,15740]
trailer [15738,15740]
===
match
---
name: DAG [55845,55848]
name: DAG [55845,55848]
===
match
---
simple_stmt [73891,73914]
simple_stmt [73891,73914]
===
match
---
name: ti [66925,66927]
name: ti [66925,66927]
===
match
---
trailer [71322,71328]
trailer [71322,71328]
===
match
---
atom_expr [15164,15186]
atom_expr [15164,15186]
===
match
---
name: fail [26685,26689]
name: fail [26685,26689]
===
match
---
atom_expr [66981,67061]
atom_expr [66981,67061]
===
match
---
arglist [40028,40076]
arglist [40028,40076]
===
match
---
atom_expr [31916,31929]
atom_expr [31916,31929]
===
match
---
name: dag [37378,37381]
name: dag [37378,37381]
===
match
---
arglist [10479,10555]
arglist [10479,10555]
===
match
---
name: timedelta [51632,51641]
name: timedelta [51632,51641]
===
match
---
number: 1 [27122,27123]
number: 1 [27122,27123]
===
match
---
name: task [36302,36306]
name: task [36302,36306]
===
match
---
name: commit [45239,45245]
name: commit [45239,45245]
===
match
---
operator: , [32770,32771]
operator: , [32770,32771]
===
match
---
argument [6200,6229]
argument [6200,6229]
===
match
---
trailer [23316,23335]
trailer [23316,23335]
===
match
---
name: date1 [26854,26859]
name: date1 [26854,26859]
===
match
---
name: class_name [12323,12333]
name: class_name [12323,12333]
===
match
---
argument [21943,21973]
argument [21943,21973]
===
match
---
suite [65010,65355]
suite [65010,65355]
===
match
---
operator: , [39052,39053]
operator: , [39052,39053]
===
match
---
operator: = [53897,53898]
operator: = [53897,53898]
===
match
---
parameters [12641,12647]
parameters [12641,12647]
===
match
---
name: timezone [24808,24816]
name: timezone [24808,24816]
===
match
---
name: DEFAULT_DATE [5284,5296]
name: DEFAULT_DATE [5284,5296]
===
match
---
assert_stmt [50351,50377]
assert_stmt [50351,50377]
===
match
---
name: test_overwrite_params_with_dag_run_conf_none [47695,47739]
name: test_overwrite_params_with_dag_run_conf_none [47695,47739]
===
match
---
name: end_date [22367,22375]
name: end_date [22367,22375]
===
match
---
name: patch [35569,35574]
name: patch [35569,35574]
===
match
---
atom_expr [61066,61079]
atom_expr [61066,61079]
===
match
---
name: owner [15535,15540]
name: owner [15535,15540]
===
match
---
operator: , [27828,27829]
operator: , [27828,27829]
===
match
---
expr_stmt [11483,11555]
expr_stmt [11483,11555]
===
match
---
trailer [14284,14298]
trailer [14284,14298]
===
match
---
name: key [40677,40680]
name: key [40677,40680]
===
match
---
string: 'test_run_pooling_task_op' [16182,16208]
string: 'test_run_pooling_task_op' [16182,16208]
===
match
---
string: 'B' [74142,74145]
string: 'B' [74142,74145]
===
match
---
operator: , [23707,23708]
operator: , [23707,23708]
===
match
---
name: TI [28835,28837]
name: TI [28835,28837]
===
match
---
number: 5 [32282,32283]
number: 5 [32282,32283]
===
match
---
trailer [68454,68458]
trailer [68454,68458]
===
match
---
operator: = [68601,68602]
operator: = [68601,68602]
===
match
---
name: State [11542,11547]
name: State [11542,11547]
===
match
---
name: raises [6969,6975]
name: raises [6969,6975]
===
match
---
number: 50 [23047,23049]
number: 50 [23047,23049]
===
match
---
number: 30 [22388,22390]
number: 30 [22388,22390]
===
match
---
atom_expr [66952,66972]
atom_expr [66952,66972]
===
match
---
name: dag [17429,17432]
name: dag [17429,17432]
===
match
---
operator: , [49950,49951]
operator: , [49950,49951]
===
match
---
argument [60635,60686]
argument [60635,60686]
===
match
---
argument [16226,16241]
argument [16226,16241]
===
match
---
operator: { [70140,70141]
operator: { [70140,70141]
===
match
---
argument [79562,79585]
argument [79562,79585]
===
match
---
testlist_comp [33534,33589]
testlist_comp [33534,33589]
===
match
---
parameters [3946,3952]
parameters [3946,3952]
===
match
---
simple_stmt [5891,5932]
simple_stmt [5891,5932]
===
match
---
trailer [18697,18980]
trailer [18697,18980]
===
match
---
string: 'test_op_1' [7539,7550]
string: 'test_op_1' [7539,7550]
===
match
---
operator: , [46567,46568]
operator: , [46567,46568]
===
match
---
operator: , [33097,33098]
operator: , [33097,33098]
===
match
---
name: task [36513,36517]
name: task [36513,36517]
===
match
---
name: raise_skip_exception [17845,17865]
name: raise_skip_exception [17845,17865]
===
match
---
operator: , [11371,11372]
operator: , [11371,11372]
===
match
---
name: skipped [34865,34872]
name: skipped [34865,34872]
===
match
---
comparison [56784,56833]
comparison [56784,56833]
===
match
---
name: done [28210,28214]
name: done [28210,28214]
===
match
---
operator: , [10411,10412]
operator: , [10411,10412]
===
match
---
comparison [71212,71241]
comparison [71212,71241]
===
match
---
operator: , [23754,23755]
operator: , [23754,23755]
===
match
---
trailer [39149,39151]
trailer [39149,39151]
===
match
---
operator: , [32672,32673]
operator: , [32672,32673]
===
match
---
atom_expr [7324,7330]
atom_expr [7324,7330]
===
match
---
decorated [71656,75975]
decorated [71656,75975]
===
match
---
name: email [49616,49621]
name: email [49616,49621]
===
match
---
operator: = [40343,40344]
operator: = [40343,40344]
===
match
---
atom_expr [27571,27643]
atom_expr [27571,27643]
===
match
---
tfpdef [33991,34005]
tfpdef [33991,34005]
===
match
---
expr_stmt [36376,36459]
expr_stmt [36376,36459]
===
match
---
decorator [51535,51549]
decorator [51535,51549]
===
match
---
name: execution_date [13509,13523]
name: execution_date [13509,13523]
===
match
---
operator: , [38722,38723]
operator: , [38722,38723]
===
match
---
operator: , [1074,1075]
operator: , [1074,1075]
===
match
---
operator: , [34097,34098]
operator: , [34097,34098]
===
match
---
atom_expr [44294,44307]
atom_expr [44294,44307]
===
match
---
simple_stmt [2203,2241]
simple_stmt [2203,2241]
===
match
---
atom_expr [78458,78471]
atom_expr [78458,78471]
===
match
---
atom_expr [36954,36992]
atom_expr [36954,36992]
===
match
---
name: State [43395,43400]
name: State [43395,43400]
===
match
---
operator: , [32153,32154]
operator: , [32153,32154]
===
match
---
atom [35397,35462]
atom [35397,35462]
===
match
---
atom_expr [72346,72356]
atom_expr [72346,72356]
===
match
---
argument [4928,4940]
argument [4928,4940]
===
match
---
trailer [31346,31354]
trailer [31346,31354]
===
match
---
trailer [55369,55390]
trailer [55369,55390]
===
match
---
name: scheduler_job [75685,75698]
name: scheduler_job [75685,75698]
===
match
---
name: ti [57204,57206]
name: ti [57204,57206]
===
match
---
trailer [51340,51342]
trailer [51340,51342]
===
match
---
operator: == [21433,21435]
operator: == [21433,21435]
===
match
---
operator: , [32515,32516]
operator: , [32515,32516]
===
match
---
string: 'foo' [37987,37992]
string: 'foo' [37987,37992]
===
match
---
operator: , [7871,7872]
operator: , [7871,7872]
===
match
---
operator: = [46666,46667]
operator: = [46666,46667]
===
match
---
operator: , [44737,44738]
operator: , [44737,44738]
===
match
---
suite [70740,70879]
suite [70740,70879]
===
match
---
simple_stmt [20010,20057]
simple_stmt [20010,20057]
===
match
---
name: end_date [4092,4100]
name: end_date [4092,4100]
===
match
---
name: task_instance_b [75009,75024]
name: task_instance_b [75009,75024]
===
match
---
decorated [53169,53671]
decorated [53169,53671]
===
match
---
operator: == [4807,4809]
operator: == [4807,4809]
===
match
---
name: task [43149,43153]
name: task [43149,43153]
===
match
---
testlist_comp [59078,59134]
testlist_comp [59078,59134]
===
match
---
name: SKIPPED [33575,33582]
name: SKIPPED [33575,33582]
===
match
---
argument [9664,9707]
argument [9664,9707]
===
match
---
atom_expr [34622,34648]
atom_expr [34622,34648]
===
match
---
atom_expr [69211,69253]
atom_expr [69211,69253]
===
match
---
atom_expr [19047,19055]
atom_expr [19047,19055]
===
match
---
simple_stmt [57320,57393]
simple_stmt [57320,57393]
===
match
---
operator: = [21866,21867]
operator: = [21866,21867]
===
match
---
atom_expr [9214,9284]
atom_expr [9214,9284]
===
match
---
name: DummyOperator [50198,50211]
name: DummyOperator [50198,50211]
===
match
---
atom_expr [32300,32313]
atom_expr [32300,32313]
===
match
---
trailer [51304,51306]
trailer [51304,51306]
===
match
---
name: task_state_in_callback [2881,2903]
name: task_state_in_callback [2881,2903]
===
match
---
operator: , [42772,42773]
operator: , [42772,42773]
===
match
---
operator: == [39126,39128]
operator: == [39126,39128]
===
match
---
name: execution_date [54998,55012]
name: execution_date [54998,55012]
===
match
---
name: task_id [13037,13044]
name: task_id [13037,13044]
===
match
---
operator: , [32438,32439]
operator: , [32438,32439]
===
match
---
name: task_ids [37959,37967]
name: task_ids [37959,37967]
===
match
---
name: task [37417,37421]
name: task [37417,37421]
===
match
---
operator: } [47579,47580]
operator: } [47579,47580]
===
match
---
operator: = [18422,18423]
operator: = [18422,18423]
===
match
---
name: PythonOperator [74333,74347]
name: PythonOperator [74333,74347]
===
match
---
name: op4 [8357,8360]
name: op4 [8357,8360]
===
match
---
operator: = [24497,24498]
operator: = [24497,24498]
===
match
---
arglist [39095,39124]
arglist [39095,39124]
===
match
---
operator: } [48851,48852]
operator: } [48851,48852]
===
match
---
string: 'default' [70040,70049]
string: 'default' [70040,70049]
===
match
---
name: State [18387,18392]
name: State [18387,18392]
===
match
---
operator: , [7423,7424]
operator: , [7423,7424]
===
match
---
operator: , [32903,32904]
operator: , [32903,32904]
===
match
---
name: downstream_task [36376,36391]
name: downstream_task [36376,36391]
===
match
---
trailer [17517,17525]
trailer [17517,17525]
===
match
---
number: 0 [24953,24954]
number: 0 [24953,24954]
===
match
---
name: DummyOperator [40093,40106]
name: DummyOperator [40093,40106]
===
match
---
name: dag [41542,41545]
name: dag [41542,41545]
===
match
---
atom [73038,73094]
atom [73038,73094]
===
match
---
name: State [17512,17517]
name: State [17512,17517]
===
match
---
number: 3 [54244,54245]
number: 3 [54244,54245]
===
match
---
trailer [10792,10797]
trailer [10792,10797]
===
match
---
name: dag_run [74655,74662]
name: dag_run [74655,74662]
===
match
---
fstring [67011,67060]
fstring [67011,67060]
===
match
---
comparison [27266,27285]
comparison [27266,27285]
===
match
---
arith_expr [44946,44987]
arith_expr [44946,44987]
===
match
---
fstring_string: ti.finish. [67013,67023]
fstring_string: ti.finish. [67013,67023]
===
match
---
trailer [70005,70009]
trailer [70005,70009]
===
match
---
simple_stmt [20904,20931]
simple_stmt [20904,20931]
===
match
---
name: datetime [46195,46203]
name: datetime [46195,46203]
===
match
---
name: on_execute_callable [60366,60385]
name: on_execute_callable [60366,60385]
===
match
---
operator: = [34962,34963]
operator: = [34962,34963]
===
match
---
string: "override" [48008,48018]
string: "override" [48008,48018]
===
match
---
name: mock [70001,70005]
name: mock [70001,70005]
===
match
---
argument [39005,39022]
argument [39005,39022]
===
match
---
name: state [19763,19768]
name: state [19763,19768]
===
match
---
decorated [77690,77871]
decorated [77690,77871]
===
match
---
argument [57212,57221]
argument [57212,57221]
===
match
---
trailer [3508,3523]
trailer [3508,3523]
===
match
---
trailer [34241,34262]
trailer [34241,34262]
===
match
---
simple_stmt [20519,20524]
simple_stmt [20519,20524]
===
match
---
operator: , [26750,26751]
operator: , [26750,26751]
===
match
---
string: 'test_xcom' [40660,40671]
string: 'test_xcom' [40660,40671]
===
match
---
name: duration [50120,50128]
name: duration [50120,50128]
===
match
---
name: start_date [30511,30521]
name: start_date [30511,30521]
===
match
---
name: airflow [2142,2149]
name: airflow [2142,2149]
===
match
---
name: TI [13256,13258]
name: TI [13256,13258]
===
match
---
name: done [34088,34092]
name: done [34088,34092]
===
match
---
name: fail [64370,64374]
name: fail [64370,64374]
===
match
---
atom [36090,36111]
atom [36090,36111]
===
match
---
name: task_ids [39282,39290]
name: task_ids [39282,39290]
===
match
---
trailer [66525,66741]
trailer [66525,66741]
===
match
---
expr_stmt [11030,11103]
expr_stmt [11030,11103]
===
match
---
name: dep_results [35080,35091]
name: dep_results [35080,35091]
===
match
---
arith_expr [22364,22421]
arith_expr [22364,22421]
===
match
---
number: 1 [28798,28799]
number: 1 [28798,28799]
===
match
---
testlist_comp [76584,76602]
testlist_comp [76584,76602]
===
match
---
trailer [46721,46730]
trailer [46721,46730]
===
match
---
operator: = [16181,16182]
operator: = [16181,16182]
===
match
---
atom_expr [77757,77776]
atom_expr [77757,77776]
===
match
---
argument [16083,16113]
argument [16083,16113]
===
match
---
atom [32139,32187]
atom [32139,32187]
===
match
---
trailer [54154,54175]
trailer [54154,54175]
===
match
---
operator: = [60878,60879]
operator: = [60878,60879]
===
match
---
name: delay [23516,23521]
name: delay [23516,23521]
===
match
---
trailer [28324,28326]
trailer [28324,28326]
===
match
---
operator: = [60848,60849]
operator: = [60848,60849]
===
match
---
name: dag [10277,10280]
name: dag [10277,10280]
===
match
---
atom [12300,12350]
atom [12300,12350]
===
match
---
parameters [77885,77891]
parameters [77885,77891]
===
match
---
name: self [3338,3342]
name: self [3338,3342]
===
match
---
operator: = [3801,3802]
operator: = [3801,3802]
===
match
---
operator: == [21387,21389]
operator: == [21387,21389]
===
match
---
param [53761,53763]
param [53761,53763]
===
match
---
expr_stmt [56302,56448]
expr_stmt [56302,56448]
===
match
---
name: airflow [1320,1327]
name: airflow [1320,1327]
===
match
---
param [2749,2751]
param [2749,2751]
===
match
---
atom [3113,3329]
atom [3113,3329]
===
match
---
operator: = [15692,15693]
operator: = [15692,15693]
===
match
---
trailer [50496,50664]
trailer [50496,50664]
===
match
---
number: 0 [13226,13227]
number: 0 [13226,13227]
===
match
---
name: timedelta [53131,53140]
name: timedelta [53131,53140]
===
match
---
name: ti_list [54654,54661]
name: ti_list [54654,54661]
===
match
---
string: 'dag' [8429,8434]
string: 'dag' [8429,8434]
===
match
---
trailer [77968,77975]
trailer [77968,77975]
===
match
---
atom_expr [17629,17637]
atom_expr [17629,17637]
===
match
---
operator: = [67642,67643]
operator: = [67642,67643]
===
match
---
arglist [43149,43192]
arglist [43149,43192]
===
match
---
operator: { [67049,67050]
operator: { [67049,67050]
===
match
---
name: session [45384,45391]
name: session [45384,45391]
===
match
---
trailer [3078,3086]
trailer [3078,3086]
===
match
---
operator: = [5790,5791]
operator: = [5790,5791]
===
match
---
testlist_comp [57616,57660]
testlist_comp [57616,57660]
===
match
---
argument [56956,56993]
argument [56956,56993]
===
match
---
argument [4608,4659]
argument [4608,4659]
===
match
---
suite [10741,10904]
suite [10741,10904]
===
match
---
simple_stmt [25699,25744]
simple_stmt [25699,25744]
===
match
---
operator: = [28609,28610]
operator: = [28609,28610]
===
match
---
name: task_id [8511,8518]
name: task_id [8511,8518]
===
match
---
operator: = [16646,16647]
operator: = [16646,16647]
===
match
---
name: dependencies_deps [1860,1877]
name: dependencies_deps [1860,1877]
===
match
---
operator: , [53334,53335]
operator: , [53334,53335]
===
match
---
trailer [42020,42036]
trailer [42020,42036]
===
match
---
atom_expr [75077,75092]
atom_expr [75077,75092]
===
match
---
string: 'to' [48565,48569]
string: 'to' [48565,48569]
===
match
---
name: PythonOperator [1616,1630]
name: PythonOperator [1616,1630]
===
match
---
trailer [61599,61609]
trailer [61599,61609]
===
match
---
simple_stmt [6643,6731]
simple_stmt [6643,6731]
===
match
---
atom_expr [46065,46100]
atom_expr [46065,46100]
===
match
---
name: State [14364,14369]
name: State [14364,14369]
===
match
---
argument [23970,23980]
argument [23970,23980]
===
match
---
name: fail [29981,29985]
name: fail [29981,29985]
===
match
---
simple_stmt [34553,34585]
simple_stmt [34553,34585]
===
match
---
name: tzinfo [5989,5995]
name: tzinfo [5989,5995]
===
match
---
operator: , [31694,31695]
operator: , [31694,31695]
===
match
---
arglist [68520,68555]
arglist [68520,68555]
===
match
---
name: base_ti_dep [2006,2017]
name: base_ti_dep [2006,2017]
===
match
---
atom_expr [3506,3525]
atom_expr [3506,3525]
===
match
---
name: try_number [22464,22474]
name: try_number [22464,22474]
===
match
---
expr_stmt [22487,22518]
expr_stmt [22487,22518]
===
match
---
name: ti [77187,77189]
name: ti [77187,77189]
===
match
---
operator: = [44620,44621]
operator: = [44620,44621]
===
match
---
name: task [18678,18682]
name: task [18678,18682]
===
match
---
name: bash_command [68788,68800]
name: bash_command [68788,68800]
===
match
---
operator: = [79011,79012]
operator: = [79011,79012]
===
match
---
operator: , [74507,74508]
operator: , [74507,74508]
===
match
---
argument [61093,61122]
argument [61093,61122]
===
match
---
atom_expr [76239,76256]
atom_expr [76239,76256]
===
match
---
param [20419,20421]
param [20419,20421]
===
match
---
name: run_ti_and_assert [26946,26963]
name: run_ti_and_assert [26946,26963]
===
match
---
operator: = [15954,15955]
operator: = [15954,15955]
===
match
---
argument [31210,31229]
argument [31210,31229]
===
match
---
operator: = [18276,18277]
operator: = [18276,18277]
===
match
---
name: ti_list [53556,53563]
name: ti_list [53556,53563]
===
match
---
name: ti_list [55414,55421]
name: ti_list [55414,55421]
===
match
---
name: execution_date [59739,59753]
name: execution_date [59739,59753]
===
match
---
operator: , [1351,1352]
operator: , [1351,1352]
===
match
---
if_stmt [29368,29411]
if_stmt [29368,29411]
===
match
---
simple_stmt [64390,64438]
simple_stmt [64390,64438]
===
match
---
with_stmt [15114,15187]
with_stmt [15114,15187]
===
match
---
operator: = [60038,60039]
operator: = [60038,60039]
===
match
---
atom_expr [60040,60068]
atom_expr [60040,60068]
===
match
---
name: conf_vars [48692,48701]
name: conf_vars [48692,48701]
===
match
---
operator: = [9031,9032]
operator: = [9031,9032]
===
match
---
parameters [14684,14686]
parameters [14684,14686]
===
match
---
name: create [49426,49432]
name: create [49426,49432]
===
match
---
operator: = [42715,42716]
operator: = [42715,42716]
===
match
---
operator: , [68607,68608]
operator: , [68607,68608]
===
match
---
name: timezone [6134,6142]
name: timezone [6134,6142]
===
match
---
name: execution_date [42818,42832]
name: execution_date [42818,42832]
===
match
---
name: ti_list [53598,53605]
name: ti_list [53598,53605]
===
match
---
simple_stmt [8093,8117]
simple_stmt [8093,8117]
===
match
---
operator: = [74031,74032]
operator: = [74031,74032]
===
match
---
name: datetime [34622,34630]
name: datetime [34622,34630]
===
match
---
operator: { [76876,76877]
operator: { [76876,76877]
===
match
---
name: catchup [54619,54626]
name: catchup [54619,54626]
===
match
---
name: op [7111,7113]
name: op [7111,7113]
===
match
---
comparison [19634,19664]
comparison [19634,19664]
===
match
---
string: 'bar' [16026,16031]
string: 'bar' [16026,16031]
===
match
---
funcdef [43910,44446]
funcdef [43910,44446]
===
match
---
name: passing_status [35863,35877]
name: passing_status [35863,35877]
===
match
---
simple_stmt [17917,17976]
simple_stmt [17917,17976]
===
match
---
string: 'airflow' [22053,22062]
string: 'airflow' [22053,22062]
===
match
---
argument [24767,24783]
argument [24767,24783]
===
match
---
name: task [56704,56708]
name: task [56704,56708]
===
match
---
name: max_active_runs [9758,9773]
name: max_active_runs [9758,9773]
===
match
---
name: owner [7552,7557]
name: owner [7552,7557]
===
match
---
name: utc_date [6123,6131]
name: utc_date [6123,6131]
===
match
---
operator: = [43005,43006]
operator: = [43005,43006]
===
match
---
trailer [64459,64463]
trailer [64459,64463]
===
match
---
trailer [14510,14518]
trailer [14510,14518]
===
match
---
name: FAILED [53857,53863]
name: FAILED [53857,53863]
===
match
---
simple_stmt [24247,24260]
simple_stmt [24247,24260]
===
match
---
name: max_delay [23248,23257]
name: max_delay [23248,23257]
===
match
---
operator: , [24842,24843]
operator: , [24842,24843]
===
match
---
expr_stmt [71520,71578]
expr_stmt [71520,71578]
===
match
---
atom_expr [5160,5177]
atom_expr [5160,5177]
===
match
---
trailer [31295,31311]
trailer [31295,31311]
===
match
---
operator: , [61122,61123]
operator: , [61122,61123]
===
match
---
string: 'airflow' [11391,11400]
string: 'airflow' [11391,11400]
===
match
---
argument [44874,44901]
argument [44874,44901]
===
match
---
name: method_patch [12267,12279]
name: method_patch [12267,12279]
===
match
---
name: dag [13106,13109]
name: dag [13106,13109]
===
match
---
string: 'test_get_num_running_task_instances_dummy' [44640,44683]
string: 'test_get_num_running_task_instances_dummy' [44640,44683]
===
match
---
name: State [72735,72740]
name: State [72735,72740]
===
match
---
name: task_id [68000,68007]
name: task_id [68000,68007]
===
match
---
simple_stmt [27537,27563]
simple_stmt [27537,27563]
===
match
---
operator: = [6132,6133]
operator: = [6132,6133]
===
match
---
argument [6756,6779]
argument [6756,6779]
===
match
---
name: ti [66952,66954]
name: ti [66952,66954]
===
match
---
name: end_date [29685,29693]
name: end_date [29685,29693]
===
match
---
string: """         Test the try_number accessor behaves in various running states         """ [43945,44031]
string: """         Test the try_number accessor behaves in various running states         """ [43945,44031]
===
match
---
operator: , [22112,22113]
operator: , [22112,22113]
===
match
---
operator: , [20366,20367]
operator: , [20366,20367]
===
match
---
name: state [66172,66177]
name: state [66172,66177]
===
match
---
operator: , [56520,56521]
operator: , [56520,56521]
===
match
---
name: schedule_interval [36901,36918]
name: schedule_interval [36901,36918]
===
match
---
name: op [66763,66765]
name: op [66763,66765]
===
match
---
operator: , [47123,47124]
operator: , [47123,47124]
===
match
---
simple_stmt [6573,6606]
simple_stmt [6573,6606]
===
match
---
operator: , [32221,32222]
operator: , [32221,32222]
===
match
---
string: 'all_failed' [33153,33165]
string: 'all_failed' [33153,33165]
===
match
---
name: task [79075,79079]
name: task [79075,79079]
===
match
---
operator: = [6194,6195]
operator: = [6194,6195]
===
match
---
name: context_arg_2 [62792,62805]
name: context_arg_2 [62792,62805]
===
match
---
atom_expr [51468,51488]
atom_expr [51468,51488]
===
match
---
assert_stmt [54647,54721]
assert_stmt [54647,54721]
===
match
---
name: tzinfo [6100,6106]
name: tzinfo [6100,6106]
===
match
---
name: state [55449,55454]
name: state [55449,55454]
===
match
---
operator: , [71462,71463]
operator: , [71462,71463]
===
match
---
operator: , [41167,41168]
operator: , [41167,41168]
===
match
---
argument [57141,57184]
argument [57141,57184]
===
match
---
with_stmt [68511,68644]
with_stmt [68511,68644]
===
match
---
operator: == [27281,27283]
operator: == [27281,27283]
===
match
---
operator: , [76042,76043]
operator: , [76042,76043]
===
match
---
atom_expr [65526,65553]
atom_expr [65526,65553]
===
match
---
argument [50266,50275]
argument [50266,50275]
===
match
---
atom_expr [46166,46225]
atom_expr [46166,46225]
===
match
---
atom_expr [29566,29579]
atom_expr [29566,29579]
===
match
---
simple_stmt [3817,3840]
simple_stmt [3817,3840]
===
match
---
name: run_date [31240,31248]
name: run_date [31240,31248]
===
match
---
simple_stmt [16703,16751]
simple_stmt [16703,16751]
===
match
---
trailer [71288,71290]
trailer [71288,71290]
===
match
---
trailer [56822,56833]
trailer [56822,56833]
===
match
---
name: task [46109,46113]
name: task [46109,46113]
===
match
---
atom_expr [62745,62776]
atom_expr [62745,62776]
===
match
---
name: check_and_change_state_before_execution [43247,43286]
name: check_and_change_state_before_execution [43247,43286]
===
match
---
with_stmt [58122,58217]
with_stmt [58122,58217]
===
match
---
name: run_type [79323,79331]
name: run_type [79323,79331]
===
match
---
atom_expr [61029,61046]
atom_expr [61029,61046]
===
match
---
argument [13948,13978]
argument [13948,13978]
===
match
---
name: value [37488,37493]
name: value [37488,37493]
===
match
---
name: dag [46641,46644]
name: dag [46641,46644]
===
match
---
operator: , [73550,73551]
operator: , [73550,73551]
===
match
---
string: 'test_xcom_1' [37820,37833]
string: 'test_xcom_1' [37820,37833]
===
match
---
argument [56378,56397]
argument [56378,56397]
===
match
---
arglist [59728,59766]
arglist [59728,59766]
===
match
---
trailer [4124,4134]
trailer [4124,4134]
===
match
---
except_clause [25520,25543]
except_clause [25520,25543]
===
match
---
name: mock_concurrency_reached [8973,8997]
name: mock_concurrency_reached [8973,8997]
===
match
---
name: task_id [34493,34500]
name: task_id [34493,34500]
===
match
---
atom_expr [53645,53670]
atom_expr [53645,53670]
===
match
---
trailer [8335,8350]
trailer [8335,8350]
===
match
---
operator: = [26285,26286]
operator: = [26285,26286]
===
match
---
name: airflow [1812,1819]
name: airflow [1812,1819]
===
match
---
trailer [9301,9366]
trailer [9301,9366]
===
match
---
simple_stmt [62938,62975]
simple_stmt [62938,62975]
===
match
---
name: execution_date [61032,61046]
name: execution_date [61032,61046]
===
match
---
atom_expr [20341,20379]
atom_expr [20341,20379]
===
match
---
assert_stmt [21371,21402]
assert_stmt [21371,21402]
===
match
---
simple_stmt [16664,16695]
simple_stmt [16664,16695]
===
match
---
trailer [50644,50653]
trailer [50644,50653]
===
match
---
name: concurrency [9174,9185]
name: concurrency [9174,9185]
===
match
---
name: expected_start_date [29643,29662]
name: expected_start_date [29643,29662]
===
match
---
comparison [22893,22907]
comparison [22893,22907]
===
match
---
name: TI [18248,18250]
name: TI [18248,18250]
===
match
---
name: DAG [1348,1351]
name: DAG [1348,1351]
===
match
---
expr_stmt [26795,26820]
expr_stmt [26795,26820]
===
match
---
comparison [5898,5931]
comparison [5898,5931]
===
match
---
suite [71302,71366]
suite [71302,71366]
===
match
---
operator: = [44915,44916]
operator: = [44915,44916]
===
match
---
name: date [22487,22491]
name: date [22487,22491]
===
match
---
atom_expr [30182,30190]
atom_expr [30182,30190]
===
match
---
number: 5 [32763,32764]
number: 5 [32763,32764]
===
match
---
atom_expr [44860,44902]
atom_expr [44860,44902]
===
match
---
trailer [78230,78232]
trailer [78230,78232]
===
match
---
number: 0 [31901,31902]
number: 0 [31901,31902]
===
match
---
name: ti2 [45089,45092]
name: ti2 [45089,45092]
===
match
---
suite [58788,58874]
suite [58788,58874]
===
match
---
trailer [60196,60206]
trailer [60196,60206]
===
match
---
trailer [38855,38988]
trailer [38855,38988]
===
match
---
simple_stmt [10859,10875]
simple_stmt [10859,10875]
===
match
---
assert_stmt [43417,43443]
assert_stmt [43417,43443]
===
match
---
operator: , [16343,16344]
operator: , [16343,16344]
===
match
---
trailer [49251,49296]
trailer [49251,49296]
===
match
---
trailer [73666,73718]
trailer [73666,73718]
===
match
---
simple_stmt [34331,34433]
simple_stmt [34331,34433]
===
match
---
dotted_name [53170,53190]
dotted_name [53170,53190]
===
match
---
operator: = [38883,38884]
operator: = [38883,38884]
===
match
---
trailer [53374,53401]
trailer [53374,53401]
===
match
---
name: now [47537,47540]
name: now [47537,47540]
===
match
---
arglist [34358,34431]
arglist [34358,34431]
===
match
---
operator: = [28236,28237]
operator: = [28236,28237]
===
match
---
operator: } [70063,70064]
operator: } [70063,70064]
===
match
---
trailer [52268,52310]
trailer [52268,52310]
===
match
---
operator: , [62394,62395]
operator: , [62394,62395]
===
match
---
atom_expr [68833,68849]
atom_expr [68833,68849]
===
match
---
trailer [76096,76135]
trailer [76096,76135]
===
match
---
operator: , [74231,74232]
operator: , [74231,74232]
===
match
---
name: TI [15694,15696]
name: TI [15694,15696]
===
match
---
atom_expr [76480,76493]
atom_expr [76480,76493]
===
match
---
trailer [55635,55643]
trailer [55635,55643]
===
match
---
name: QUEUED [72316,72322]
name: QUEUED [72316,72322]
===
match
---
name: task [47119,47123]
name: task [47119,47123]
===
match
---
name: dag [50835,50838]
name: dag [50835,50838]
===
match
---
name: PythonOperator [63855,63869]
name: PythonOperator [63855,63869]
===
match
---
operator: , [37427,37428]
operator: , [37427,37428]
===
match
---
name: db [3479,3481]
name: db [3479,3481]
===
match
---
trailer [47540,47542]
trailer [47540,47542]
===
match
---
trailer [58770,58777]
trailer [58770,58777]
===
match
---
name: session [1110,1117]
name: session [1110,1117]
===
match
---
atom_expr [8071,8078]
atom_expr [8071,8078]
===
match
---
name: state [19451,19456]
name: state [19451,19456]
===
match
---
simple_stmt [19184,19335]
simple_stmt [19184,19335]
===
match
---
decorator [77690,77704]
decorator [77690,77704]
===
match
---
number: 1 [5250,5251]
number: 1 [5250,5251]
===
match
---
simple_stmt [15940,15964]
simple_stmt [15940,15964]
===
match
---
simple_stmt [46701,46848]
simple_stmt [46701,46848]
===
match
---
name: task [49801,49805]
name: task [49801,49805]
===
match
---
argument [60864,60902]
argument [60864,60902]
===
match
---
assert_stmt [44260,44285]
assert_stmt [44260,44285]
===
match
---
name: ti [29682,29684]
name: ti [29682,29684]
===
match
---
operator: , [40608,40609]
operator: , [40608,40609]
===
match
---
trailer [46212,46224]
trailer [46212,46224]
===
match
---
name: trs [26089,26092]
name: trs [26089,26092]
===
match
---
simple_stmt [25924,25964]
simple_stmt [25924,25964]
===
match
---
operator: = [80205,80206]
operator: = [80205,80206]
===
match
---
funcdef [77708,77871]
funcdef [77708,77871]
===
match
---
number: 3 [18854,18855]
number: 3 [18854,18855]
===
match
---
operator: == [77085,77087]
operator: == [77085,77087]
===
match
---
trailer [41981,41991]
trailer [41981,41991]
===
match
---
operator: , [20285,20286]
operator: , [20285,20286]
===
match
---
name: get_previous_ti [53609,53624]
name: get_previous_ti [53609,53624]
===
match
---
name: DAG [6745,6748]
name: DAG [6745,6748]
===
match
---
trailer [78567,78582]
trailer [78567,78582]
===
match
---
name: DAG [59621,59624]
name: DAG [59621,59624]
===
match
---
trailer [43148,43193]
trailer [43148,43193]
===
match
---
atom [72266,72286]
atom [72266,72286]
===
match
---
simple_stmt [79536,79587]
simple_stmt [79536,79587]
===
match
---
name: ti [65985,65987]
name: ti [65985,65987]
===
match
---
number: 1 [18958,18959]
number: 1 [18958,18959]
===
match
---
name: execution_date [44931,44945]
name: execution_date [44931,44945]
===
match
---
argument [62357,62394]
argument [62357,62394]
===
match
---
trailer [43183,43190]
trailer [43183,43190]
===
match
---
comparison [48585,48612]
comparison [48585,48612]
===
match
---
atom_expr [77812,77834]
atom_expr [77812,77834]
===
match
---
name: timezone [29948,29956]
name: timezone [29948,29956]
===
match
---
operator: = [54864,54865]
operator: = [54864,54865]
===
match
---
name: RUNNING [76209,76216]
name: RUNNING [76209,76216]
===
match
---
trailer [42488,42507]
trailer [42488,42507]
===
match
---
param [43930,43934]
param [43930,43934]
===
match
---
operator: = [51897,51898]
operator: = [51897,51898]
===
match
---
name: DummyOperator [4873,4886]
name: DummyOperator [4873,4886]
===
match
---
trailer [73199,73204]
trailer [73199,73204]
===
match
---
expr_stmt [60912,60936]
expr_stmt [60912,60936]
===
match
---
operator: , [17334,17335]
operator: , [17334,17335]
===
match
---
expr_stmt [9930,10002]
expr_stmt [9930,10002]
===
match
---
trailer [4795,4806]
trailer [4795,4806]
===
match
---
simple_stmt [8693,8711]
simple_stmt [8693,8711]
===
match
---
trailer [13700,13702]
trailer [13700,13702]
===
match
---
name: self [48949,48953]
name: self [48949,48953]
===
match
---
trailer [66289,66443]
trailer [66289,66443]
===
match
---
atom_expr [40817,40825]
atom_expr [40817,40825]
===
match
---
operator: = [61389,61390]
operator: = [61389,61390]
===
match
---
simple_stmt [16381,16435]
simple_stmt [16381,16435]
===
match
---
name: task [31201,31205]
name: task [31201,31205]
===
match
---
simple_stmt [3534,3553]
simple_stmt [3534,3553]
===
match
---
simple_stmt [12385,12417]
simple_stmt [12385,12417]
===
match
---
atom_expr [35760,35887]
atom_expr [35760,35887]
===
match
---
name: SUCCESS [54540,54547]
name: SUCCESS [54540,54547]
===
match
---
suite [8237,8274]
suite [8237,8274]
===
match
---
name: task [20541,20545]
name: task [20541,20545]
===
match
---
operator: , [31857,31858]
operator: , [31857,31858]
===
match
---
name: dag_id [21735,21741]
name: dag_id [21735,21741]
===
match
---
name: date4 [27945,27950]
name: date4 [27945,27950]
===
match
---
name: return_value [12047,12059]
name: return_value [12047,12059]
===
match
---
name: ti [64116,64118]
name: ti [64116,64118]
===
match
---
atom_expr [14440,14448]
atom_expr [14440,14448]
===
match
---
operator: , [15658,15659]
operator: , [15658,15659]
===
match
---
trailer [68922,68924]
trailer [68922,68924]
===
match
---
name: RUNNING [18393,18400]
name: RUNNING [18393,18400]
===
match
---
string: 'D' [72853,72856]
string: 'D' [72853,72856]
===
match
---
trailer [16042,16058]
trailer [16042,16058]
===
match
---
trailer [48391,48393]
trailer [48391,48393]
===
match
---
suite [10268,10959]
suite [10268,10959]
===
match
---
atom_expr [16563,16583]
atom_expr [16563,16583]
===
match
---
operator: , [46635,46636]
operator: , [46635,46636]
===
match
---
name: TestError [42273,42282]
name: TestError [42273,42282]
===
match
---
argument [41040,41047]
argument [41040,41047]
===
match
---
trailer [8300,8318]
trailer [8300,8318]
===
match
---
name: mock_concurrency_reached [8938,8962]
name: mock_concurrency_reached [8938,8962]
===
match
---
atom_expr [19760,19768]
atom_expr [19760,19768]
===
match
---
argument [28568,28588]
argument [28568,28588]
===
match
---
simple_stmt [14486,14519]
simple_stmt [14486,14519]
===
match
---
name: timedelta [20244,20253]
name: timedelta [20244,20253]
===
match
---
string: 'all_success' [31737,31750]
string: 'all_success' [31737,31750]
===
match
---
name: ti [43860,43862]
name: ti [43860,43862]
===
match
---
suite [38289,39734]
suite [38289,39734]
===
match
---
name: task [49894,49898]
name: task [49894,49898]
===
match
---
name: items [74451,74456]
name: items [74451,74456]
===
match
---
name: ti [28898,28900]
name: ti [28898,28900]
===
match
---
comparison [35109,35138]
comparison [35109,35138]
===
match
---
arglist [39282,39311]
arglist [39282,39311]
===
match
---
name: task [15060,15064]
name: task [15060,15064]
===
match
---
name: test_get_rendered_template_fields [68125,68158]
name: test_get_rendered_template_fields [68125,68158]
===
match
---
name: date2 [27704,27709]
name: date2 [27704,27709]
===
match
---
simple_stmt [60338,60353]
simple_stmt [60338,60353]
===
match
---
argument [63239,63246]
argument [63239,63246]
===
match
---
expr_stmt [17984,18234]
expr_stmt [17984,18234]
===
match
---
name: SUCCESS [51522,51529]
name: SUCCESS [51522,51529]
===
match
---
trailer [41412,41432]
trailer [41412,41432]
===
match
---
atom_expr [76523,76534]
atom_expr [76523,76534]
===
match
---
operator: = [43742,43743]
operator: = [43742,43743]
===
match
---
atom [57828,57895]
atom [57828,57895]
===
match
---
funcdef [3923,5326]
funcdef [3923,5326]
===
match
---
expr_stmt [47106,47164]
expr_stmt [47106,47164]
===
match
---
operator: = [15490,15491]
operator: = [15490,15491]
===
match
---
name: execution_date [47504,47518]
name: execution_date [47504,47518]
===
match
---
name: op3 [5173,5176]
name: op3 [5173,5176]
===
match
---
trailer [17432,17446]
trailer [17432,17446]
===
match
---
operator: , [61853,61854]
operator: , [61853,61854]
===
match
---
argument [21795,21840]
argument [21795,21840]
===
match
---
name: task [50266,50270]
name: task [50266,50270]
===
match
---
name: start_date [56854,56864]
name: start_date [56854,56864]
===
match
---
name: ti [49244,49246]
name: ti [49244,49246]
===
match
---
operator: = [14363,14364]
operator: = [14363,14364]
===
match
---
operator: , [60584,60585]
operator: , [60584,60585]
===
match
---
simple_stmt [9535,9544]
simple_stmt [9535,9544]
===
match
---
assert_stmt [29675,29714]
assert_stmt [29675,29714]
===
match
---
string: "override" [47252,47262]
string: "override" [47252,47262]
===
match
---
comparison [54128,54219]
comparison [54128,54219]
===
match
---
string: 'a test value' [57799,57813]
string: 'a test value' [57799,57813]
===
match
---
trailer [18307,18321]
trailer [18307,18321]
===
match
---
operator: = [24558,24559]
operator: = [24558,24559]
===
match
---
trailer [7362,7368]
trailer [7362,7368]
===
match
---
name: SUCCESS [27113,27120]
name: SUCCESS [27113,27120]
===
match
---
import_from [2358,2389]
import_from [2358,2389]
===
match
---
name: session [2156,2163]
name: session [2156,2163]
===
match
---
name: DEFAULT_DATE [49187,49199]
name: DEFAULT_DATE [49187,49199]
===
match
---
atom_expr [54820,54879]
atom_expr [54820,54879]
===
match
---
name: generate_command [67424,67440]
name: generate_command [67424,67440]
===
match
---
trailer [54692,54713]
trailer [54692,54713]
===
match
---
operator: , [27601,27602]
operator: , [27601,27602]
===
match
---
argument [51887,51910]
argument [51887,51910]
===
match
---
operator: = [28215,28216]
operator: = [28215,28216]
===
match
---
trailer [43541,43596]
trailer [43541,43596]
===
match
---
atom_expr [57374,57391]
atom_expr [57374,57391]
===
match
---
name: task [69214,69218]
name: task [69214,69218]
===
match
---
name: TI [43792,43794]
name: TI [43792,43794]
===
match
---
atom_expr [72418,72428]
atom_expr [72418,72428]
===
match
---
name: DAG [38468,38471]
name: DAG [38468,38471]
===
match
---
atom_expr [2615,2632]
atom_expr [2615,2632]
===
match
---
name: DateTime [57469,57477]
name: DateTime [57469,57477]
===
match
---
trailer [22691,22702]
trailer [22691,22702]
===
match
---
operator: , [32906,32907]
operator: , [32906,32907]
===
match
---
number: 0 [33683,33684]
number: 0 [33683,33684]
===
match
---
expr_stmt [51747,51832]
expr_stmt [51747,51832]
===
match
---
name: ti [38884,38886]
name: ti [38884,38886]
===
match
---
name: param [52971,52976]
name: param [52971,52976]
===
match
---
string: 'op' [60748,60752]
string: 'op' [60748,60752]
===
match
---
suite [34202,35179]
suite [34202,35179]
===
match
---
expr_stmt [12267,12351]
expr_stmt [12267,12351]
===
match
---
atom_expr [72804,72817]
atom_expr [72804,72817]
===
match
---
name: get_rendered_template_fields [68724,68752]
name: get_rendered_template_fields [68724,68752]
===
match
---
simple_stmt [4373,4446]
simple_stmt [4373,4446]
===
match
---
name: clear [30681,30686]
name: clear [30681,30686]
===
match
---
atom_expr [63725,63757]
atom_expr [63725,63757]
===
match
---
trailer [4771,4776]
trailer [4771,4776]
===
match
---
name: ti_list [54558,54565]
name: ti_list [54558,54565]
===
match
---
argument [77035,77062]
argument [77035,77062]
===
match
---
operator: = [22052,22053]
operator: = [22052,22053]
===
match
---
operator: = [43790,43791]
operator: = [43790,43791]
===
match
---
trailer [16424,16431]
trailer [16424,16431]
===
match
---
number: 2 [54995,54996]
number: 2 [54995,54996]
===
match
---
argument [55449,55468]
argument [55449,55468]
===
match
---
name: period [23945,23951]
name: period [23945,23951]
===
match
---
argument [38618,38634]
argument [38618,38634]
===
match
---
argument [65778,65805]
argument [65778,65805]
===
match
---
name: task [50271,50275]
name: task [50271,50275]
===
match
---
comparison [21177,21207]
comparison [21177,21207]
===
match
---
name: execution_date [61855,61869]
name: execution_date [61855,61869]
===
match
---
name: datetime [26295,26303]
name: datetime [26295,26303]
===
match
---
argument [23229,23238]
argument [23229,23238]
===
match
---
string: 'B' [71923,71926]
string: 'B' [71923,71926]
===
match
---
argument [15708,15740]
argument [15708,15740]
===
match
---
trailer [22232,22251]
trailer [22232,22251]
===
match
---
trailer [78787,78801]
trailer [78787,78801]
===
match
---
testlist_comp [32496,32560]
testlist_comp [32496,32560]
===
match
---
arglist [36560,36589]
arglist [36560,36589]
===
match
---
operator: = [39558,39559]
operator: = [39558,39559]
===
match
---
trailer [71933,71943]
trailer [71933,71943]
===
match
---
name: op2 [4455,4458]
name: op2 [4455,4458]
===
match
---
name: return_value [12280,12292]
name: return_value [12280,12292]
===
match
---
operator: == [7862,7864]
operator: == [7862,7864]
===
match
---
name: session [11638,11645]
name: session [11638,11645]
===
match
---
string: 'timedelta/no-catchup' [53098,53120]
string: 'timedelta/no-catchup' [53098,53120]
===
match
---
number: 5 [22705,22706]
number: 5 [22705,22706]
===
match
---
trailer [29799,29822]
trailer [29799,29822]
===
match
---
argument [79787,79796]
argument [79787,79796]
===
match
---
operator: == [20708,20710]
operator: == [20708,20710]
===
match
---
name: queue [77093,77098]
name: queue [77093,77098]
===
match
---
name: schedule_interval [51593,51610]
name: schedule_interval [51593,51610]
===
match
---
testlist_comp [12156,12179]
testlist_comp [12156,12179]
===
match
---
argument [17298,17347]
argument [17298,17347]
===
match
---
number: 2016 [36972,36976]
number: 2016 [36972,36976]
===
match
---
name: str [2541,2544]
name: str [2541,2544]
===
match
---
operator: = [55454,55455]
operator: = [55454,55455]
===
match
---
number: 1 [11452,11453]
number: 1 [11452,11453]
===
match
---
atom_expr [9510,9526]
atom_expr [9510,9526]
===
match
---
atom_expr [30318,30359]
atom_expr [30318,30359]
===
match
---
expr [11675,11699]
expr [11675,11699]
===
match
---
name: mark_success [78188,78200]
name: mark_success [78188,78200]
===
match
---
argument [8666,8678]
argument [8666,8678]
===
match
---
operator: = [47213,47214]
operator: = [47213,47214]
===
match
---
simple_stmt [28044,28125]
simple_stmt [28044,28125]
===
match
---
name: jobs [1276,1280]
name: jobs [1276,1280]
===
match
---
argument [39533,39553]
argument [39533,39553]
===
match
---
name: upstream_failed [34929,34944]
name: upstream_failed [34929,34944]
===
match
---
operator: = [26143,26144]
operator: = [26143,26144]
===
match
---
expr_stmt [21666,21708]
expr_stmt [21666,21708]
===
match
---
operator: = [40015,40016]
operator: = [40015,40016]
===
match
---
name: dag [56313,56316]
name: dag [56313,56316]
===
match
---
try_stmt [48404,48480]
try_stmt [48404,48480]
===
match
---
name: Pool [3773,3777]
name: Pool [3773,3777]
===
match
---
simple_stmt [11483,11556]
simple_stmt [11483,11556]
===
match
---
argument [63287,63312]
argument [63287,63312]
===
match
---
trailer [67863,67873]
trailer [67863,67873]
===
match
---
atom [38162,38192]
atom [38162,38192]
===
match
---
number: 10 [79436,79438]
number: 12 [79436,79438]
===
match
---
name: State [19460,19465]
name: State [19460,19465]
===
match
---
argument [68680,68707]
argument [68680,68707]
===
match
---
atom_expr [22494,22518]
atom_expr [22494,22518]
===
match
---
string: 'airflow' [18897,18906]
string: 'airflow' [18897,18906]
===
match
---
expr_stmt [47485,47543]
expr_stmt [47485,47543]
===
match
---
name: DAG [42995,42998]
name: DAG [42995,42998]
===
match
---
operator: = [7601,7602]
operator: = [7601,7602]
===
match
---
operator: , [2747,2748]
operator: , [2747,2748]
===
match
---
operator: , [53075,53076]
operator: , [53075,53076]
===
match
---
trailer [66941,66943]
trailer [66941,66943]
===
match
---
operator: = [62376,62377]
operator: = [62376,62377]
===
match
---
operator: == [36685,36687]
operator: == [36685,36687]
===
match
---
trailer [53027,53082]
trailer [53027,53082]
===
match
---
name: _critical_section_execute_task_instances [75699,75739]
name: _critical_section_execute_task_instances [75699,75739]
===
match
---
operator: , [51089,51090]
operator: , [51089,51090]
===
match
---
trailer [78656,78666]
trailer [78656,78666]
===
match
---
argument [41663,41703]
argument [41663,41703]
===
match
---
raise_stmt [63719,63757]
raise_stmt [63719,63757]
===
match
---
expr_stmt [46235,46417]
expr_stmt [46235,46417]
===
match
---
name: _prev_dates_param_list [53698,53720]
name: _prev_dates_param_list [53698,53720]
===
match
---
string: 'C' [73128,73131]
string: 'C' [73128,73131]
===
match
---
param [53246,53248]
param [53246,53248]
===
match
---
name: callback_wrapper [51403,51419]
name: callback_wrapper [51403,51419]
===
match
---
operator: + [4978,4979]
operator: + [4978,4979]
===
match
---
simple_stmt [55728,55832]
simple_stmt [55728,55832]
===
match
---
name: self [6310,6314]
name: self [6310,6314]
===
match
---
trailer [18506,18512]
trailer [18506,18512]
===
match
---
name: dag [18874,18877]
name: dag [18874,18877]
===
match
---
operator: = [30917,30918]
operator: = [30917,30918]
===
match
---
param [16827,16831]
param [16827,16831]
===
match
---
suite [65394,66195]
suite [65394,66195]
===
match
---
arith_expr [5211,5252]
arith_expr [5211,5252]
===
match
---
operator: = [22157,22158]
operator: = [22157,22158]
===
match
---
operator: , [41588,41589]
operator: , [41588,41589]
===
match
---
comparison [44427,44445]
comparison [44427,44445]
===
match
---
atom_expr [71482,71506]
atom_expr [71482,71506]
===
match
---
trailer [13023,13242]
trailer [13023,13242]
===
match
---
name: serialized_op [80027,80040]
name: serialized_op [80027,80040]
===
match
---
simple_stmt [74324,74394]
simple_stmt [74324,74394]
===
match
---
name: State [44331,44336]
name: State [44331,44336]
===
match
---
operator: , [64586,64587]
operator: , [64586,64587]
===
match
---
simple_stmt [68074,68116]
simple_stmt [68074,68116]
===
match
---
suite [20440,20466]
suite [20440,20466]
===
match
---
trailer [23268,23278]
trailer [23268,23278]
===
match
---
operator: , [40046,40047]
operator: , [40046,40047]
===
match
---
name: UP_FOR_RETRY [27735,27747]
name: UP_FOR_RETRY [27735,27747]
===
match
---
trailer [37466,37476]
trailer [37466,37476]
===
match
---
name: models [42988,42994]
name: models [42988,42994]
===
match
---
trailer [76267,76278]
trailer [76267,76278]
===
match
---
trailer [37800,37810]
trailer [37800,37810]
===
match
---
atom_expr [58127,58167]
atom_expr [58127,58167]
===
match
---
name: bash_command [71046,71058]
name: bash_command [71046,71058]
===
match
---
string: 'test_pool' [20305,20316]
string: 'test_pool' [20305,20316]
===
match
---
expr_stmt [29975,30000]
expr_stmt [29975,30000]
===
match
---
number: 5 [32597,32598]
number: 5 [32597,32598]
===
match
---
name: State [72716,72721]
name: State [72716,72721]
===
match
---
operator: = [8585,8586]
operator: = [8585,8586]
===
match
---
name: execution_date [51075,51089]
name: execution_date [51075,51089]
===
match
---
name: run_date [31010,31018]
name: run_date [31010,31018]
===
match
---
number: 2 [64059,64060]
number: 2 [64059,64060]
===
match
---
name: mock_open [961,970]
name: mock_open [961,970]
===
match
---
operator: = [41639,41640]
operator: = [41639,41640]
===
match
---
operator: = [17607,17608]
operator: = [17607,17608]
===
match
---
operator: , [32401,32402]
operator: , [32401,32402]
===
match
---
arglist [46130,46151]
arglist [46130,46151]
===
match
---
simple_stmt [1134,1171]
simple_stmt [1134,1171]
===
match
---
name: exec_date [40302,40311]
name: exec_date [40302,40311]
===
match
---
name: catchup [55133,55140]
name: catchup [55133,55140]
===
match
---
operator: = [39703,39704]
operator: = [39703,39704]
===
match
---
name: _test_previous_dates_setup [53904,53930]
name: _test_previous_dates_setup [53904,53930]
===
match
---
testlist_star_expr [29988,30000]
testlist_star_expr [29988,30000]
===
match
---
name: session [15955,15962]
name: session [15955,15962]
===
match
---
operator: , [29099,29100]
operator: , [29099,29100]
===
match
---
string: 'test_op_3' [8653,8664]
string: 'test_op_3' [8653,8664]
===
match
---
name: ti [60845,60847]
name: ti [60845,60847]
===
match
---
name: ti [39143,39145]
name: ti [39143,39145]
===
match
---
import_from [2241,2283]
import_from [2241,2283]
===
match
---
atom_expr [16632,16655]
atom_expr [16632,16655]
===
match
---
operator: == [29897,29899]
operator: == [29897,29899]
===
match
---
trailer [9343,9345]
trailer [9343,9345]
===
match
---
name: DagRun [47183,47189]
name: DagRun [47183,47189]
===
match
---
operator: = [76689,76690]
operator: = [76689,76690]
===
match
---
name: date [22715,22719]
name: date [22715,22719]
===
match
---
trailer [36131,36136]
trailer [36131,36136]
===
match
---
name: datetime [61400,61408]
name: datetime [61400,61408]
===
match
---
name: ti [50325,50327]
name: ti [50325,50327]
===
match
---
operator: = [18255,18256]
operator: = [18255,18256]
===
match
---
operator: = [2579,2580]
operator: = [2579,2580]
===
match
---
operator: , [24591,24592]
operator: , [24591,24592]
===
match
---
simple_stmt [1731,1807]
simple_stmt [1731,1807]
===
match
---
name: timezone [38688,38696]
name: timezone [38688,38696]
===
match
---
name: run_with_error [20404,20418]
name: run_with_error [20404,20418]
===
match
---
if_stmt [28277,28327]
if_stmt [28277,28327]
===
match
---
operator: , [17340,17341]
operator: , [17340,17341]
===
match
---
operator: , [20550,20551]
operator: , [20550,20551]
===
match
---
operator: , [33305,33306]
operator: , [33305,33306]
===
match
---
trailer [73902,73913]
trailer [73902,73913]
===
match
---
arglist [45006,45045]
arglist [45006,45045]
===
match
---
param [77886,77890]
param [77886,77890]
===
match
---
operator: , [36929,36930]
operator: , [36929,36930]
===
match
---
argument [17269,17284]
argument [17269,17284]
===
match
---
arglist [37351,37398]
arglist [37351,37398]
===
match
---
param [51593,51649]
param [51593,51649]
===
match
---
trailer [79218,79400]
trailer [79218,79400]
===
match
---
name: TI [58231,58233]
name: TI [58231,58233]
===
match
---
operator: , [27123,27124]
operator: , [27123,27124]
===
match
---
operator: , [56364,56365]
operator: , [56364,56365]
===
match
---
name: dag [37124,37127]
name: dag [37124,37127]
===
match
---
operator: == [50129,50131]
operator: == [50129,50131]
===
match
---
trailer [50265,50316]
trailer [50265,50316]
===
match
---
name: run_ti_and_assert [26713,26730]
name: run_ti_and_assert [26713,26730]
===
match
---
name: catchup [53268,53275]
name: catchup [53268,53275]
===
match
---
trailer [76036,76068]
trailer [76036,76068]
===
match
---
name: op1 [8093,8096]
name: op1 [8093,8096]
===
match
---
trailer [18469,18471]
trailer [18469,18471]
===
match
---
name: body [48504,48508]
name: body [48504,48508]
===
match
---
name: test_mark_success_url [46469,46490]
name: test_mark_success_url [46469,46490]
===
match
---
atom_expr [35058,35068]
atom_expr [35058,35068]
===
match
---
trailer [49994,50003]
trailer [49994,50003]
===
match
---
arglist [16389,16433]
arglist [16389,16433]
===
match
---
trailer [30026,30081]
trailer [30026,30081]
===
match
---
operator: = [58723,58724]
operator: = [58723,58724]
===
match
---
argument [18074,18081]
argument [18074,18081]
===
match
---
name: State [33569,33574]
name: State [33569,33574]
===
match
---
operator: , [64069,64070]
operator: , [64069,64070]
===
match
---
trailer [64412,64437]
trailer [64412,64437]
===
match
---
name: task_id [38564,38571]
name: task_id [38564,38571]
===
match
---
operator: , [69975,69976]
operator: , [69975,69976]
===
match
---
name: ti1 [45168,45171]
name: ti1 [45168,45171]
===
match
---
name: init_state [74292,74302]
name: init_state [74292,74302]
===
match
---
comparison [64940,64970]
comparison [64940,64970]
===
match
---
trailer [38467,38471]
trailer [38467,38471]
===
match
---
operator: = [60921,60922]
operator: = [60921,60922]
===
match
---
suite [77721,77871]
suite [77721,77871]
===
match
---
atom_expr [75009,75029]
atom_expr [75009,75029]
===
match
---
name: state [10198,10203]
name: state [10198,10203]
===
match
---
string: 'op' [50220,50224]
string: 'op' [50220,50224]
===
match
---
simple_stmt [20939,20965]
simple_stmt [20939,20965]
===
match
---
trailer [45058,45064]
trailer [45058,45064]
===
match
---
trailer [6006,6015]
trailer [6006,6015]
===
match
---
name: DagRunType [38957,38967]
name: DagRunType [38957,38967]
===
match
---
name: ti [48342,48344]
name: ti [48342,48344]
===
match
---
name: task [34553,34557]
name: task [34553,34557]
===
match
---
name: task [64129,64133]
name: task [64129,64133]
===
match
---
comparison [20745,20764]
comparison [20745,20764]
===
match
---
operator: , [33499,33500]
operator: , [33499,33500]
===
match
---
number: 2016 [61409,61413]
number: 2016 [61409,61413]
===
match
---
operator: , [63981,63982]
operator: , [63981,63982]
===
match
---
operator: >> [8697,8699]
operator: >> [8697,8699]
===
match
---
name: done [24383,24387]
name: done [24383,24387]
===
match
---
simple_stmt [47442,47477]
simple_stmt [47442,47477]
===
match
---
expr_stmt [9207,9284]
expr_stmt [9207,9284]
===
match
---
atom_expr [29785,29826]
atom_expr [29785,29826]
===
match
---
operator: = [71097,71098]
operator: = [71097,71098]
===
match
---
atom_expr [35721,35746]
atom_expr [35721,35746]
===
match
---
name: timedelta [34631,34640]
name: timedelta [34631,34640]
===
match
---
simple_stmt [44544,44607]
simple_stmt [44544,44607]
===
match
---
name: test_fast_follow [73453,73469]
name: test_fast_follow [73453,73469]
===
match
---
number: 0 [11455,11456]
number: 0 [11455,11456]
===
match
---
name: python_callable [41559,41574]
name: python_callable [41559,41574]
===
match
---
string: "test_handle_failure_on_force_fail" [63069,63104]
string: "test_handle_failure_on_force_fail" [63069,63104]
===
match
---
trailer [39004,39023]
trailer [39004,39023]
===
match
---
trailer [77266,77282]
trailer [77266,77282]
===
match
---
operator: = [62027,62028]
operator: = [62027,62028]
===
match
---
atom_expr [10283,10449]
atom_expr [10283,10449]
===
match
---
arglist [74348,74392]
arglist [74348,74392]
===
match
---
name: dag [79045,79048]
name: dag [79045,79048]
===
match
---
assert_stmt [28926,28951]
assert_stmt [28926,28951]
===
match
---
trailer [50003,50019]
trailer [50003,50019]
===
match
---
trailer [27845,27863]
trailer [27845,27863]
===
match
---
funcdef [66233,67188]
funcdef [66233,67188]
===
match
---
arglist [37477,37499]
arglist [37477,37499]
===
match
---
argument [65465,65488]
argument [65465,65488]
===
match
---
simple_stmt [30175,30205]
simple_stmt [30175,30205]
===
match
---
atom_expr [60850,60903]
atom_expr [60850,60903]
===
match
---
name: TI [40345,40347]
name: TI [40345,40347]
===
match
---
operator: == [12401,12403]
operator: == [12401,12403]
===
match
---
trailer [22860,22864]
trailer [22860,22864]
===
match
---
trailer [38773,38775]
trailer [38773,38775]
===
match
---
name: func [28584,28588]
name: func [28584,28588]
===
match
---
trailer [3212,3238]
trailer [3212,3238]
===
match
---
operator: { [69593,69594]
operator: { [69593,69594]
===
match
---
try_stmt [20436,20524]
try_stmt [20436,20524]
===
match
---
atom_expr [61595,61611]
atom_expr [61595,61611]
===
match
---
argument [50733,50755]
argument [50733,50755]
===
match
---
simple_stmt [38400,38417]
simple_stmt [38400,38417]
===
match
---
simple_stmt [8558,8613]
simple_stmt [8558,8613]
===
match
---
name: UPSTREAM_FAILED [32458,32473]
name: UPSTREAM_FAILED [32458,32473]
===
match
---
atom_expr [52740,52754]
atom_expr [52740,52754]
===
match
---
atom_expr [15797,15814]
atom_expr [15797,15814]
===
match
---
trailer [49475,49479]
trailer [49475,49479]
===
match
---
operator: = [40476,40477]
operator: = [40476,40477]
===
match
---
expr_stmt [21718,21753]
expr_stmt [21718,21753]
===
match
---
name: TI [9935,9937]
name: TI [9935,9937]
===
match
---
trailer [72740,72745]
trailer [72740,72745]
===
match
---
name: ti [64962,64964]
name: ti [64962,64964]
===
match
---
operator: = [79074,79075]
operator: = [79074,79075]
===
match
---
name: State [32372,32377]
name: State [32372,32377]
===
match
---
operator: , [33800,33801]
operator: , [33800,33801]
===
match
---
atom_expr [12062,12117]
atom_expr [12062,12117]
===
match
---
trailer [25881,25890]
trailer [25881,25890]
===
match
---
operator: = [56539,56540]
operator: = [56539,56540]
===
match
---
operator: , [18219,18220]
operator: , [18219,18220]
===
match
---
operator: = [18799,18800]
operator: = [18799,18800]
===
match
---
operator: = [7463,7464]
operator: = [7463,7464]
===
match
---
name: ti [50358,50360]
name: ti [50358,50360]
===
match
---
trailer [10774,10780]
trailer [10774,10780]
===
match
---
name: completed [35109,35118]
name: completed [35109,35118]
===
match
---
name: task [17380,17384]
name: task [17380,17384]
===
match
---
name: start_date [50565,50575]
name: start_date [50565,50575]
===
match
---
funcdef [36166,36717]
funcdef [36166,36717]
===
match
---
trailer [24937,24949]
trailer [24937,24949]
===
match
---
operator: , [33130,33131]
operator: , [33130,33131]
===
match
---
name: ti [16632,16634]
name: ti [16632,16634]
===
match
---
operator: == [49751,49753]
operator: == [49751,49753]
===
match
---
tfpdef [34143,34162]
tfpdef [34143,34162]
===
match
---
name: days [4587,4591]
name: days [4587,4591]
===
match
---
param [57949,57954]
param [57949,57954]
===
match
---
name: mock_on_retry_3 [62983,62998]
name: mock_on_retry_3 [62983,62998]
===
match
---
name: template_context [57505,57521]
name: template_context [57505,57521]
===
match
---
atom [72588,72644]
atom [72588,72644]
===
match
---
trailer [73254,73261]
trailer [73254,73261]
===
match
---
trailer [65938,65976]
trailer [65938,65976]
===
match
---
argument [47493,47502]
argument [47493,47502]
===
match
---
string: 'bar' [16711,16716]
string: 'bar' [16711,16716]
===
match
---
trailer [77078,77084]
trailer [77078,77084]
===
match
---
operator: } [11785,11786]
operator: } [11785,11786]
===
match
---
name: run_type [51136,51144]
name: run_type [51136,51144]
===
match
---
argument [58202,58215]
argument [58202,58215]
===
match
---
name: task [41736,41740]
name: task [41736,41740]
===
match
---
simple_stmt [20594,20620]
simple_stmt [20594,20620]
===
match
---
trailer [25825,25836]
trailer [25825,25836]
===
match
---
expr_stmt [64447,64506]
expr_stmt [64447,64506]
===
match
---
comparison [14493,14518]
comparison [14493,14518]
===
match
---
trailer [48530,48540]
trailer [48530,48540]
===
match
---
name: trs [30312,30315]
name: trs [30312,30315]
===
match
---
operator: = [76947,76948]
operator: = [76947,76948]
===
match
---
operator: , [33308,33309]
operator: , [33308,33309]
===
match
---
arglist [34493,34539]
arglist [34493,34539]
===
match
---
trailer [20851,20855]
trailer [20851,20855]
===
match
---
operator: , [25265,25266]
operator: , [25265,25266]
===
match
---
argument [41169,41176]
argument [41169,41176]
===
match
---
operator: = [19135,19136]
operator: = [19135,19136]
===
match
---
operator: , [76752,76753]
operator: , [76752,76753]
===
match
---
expr_stmt [41334,41349]
expr_stmt [41334,41349]
===
match
---
name: dag_id [67028,67034]
name: dag_id [67028,67034]
===
match
---
trailer [20540,20585]
trailer [20540,20585]
===
match
---
name: NONE [72424,72428]
name: NONE [72424,72428]
===
match
---
operator: , [26898,26899]
operator: , [26898,26899]
===
match
---
name: self [78882,78886]
name: self [78882,78886]
===
match
---
operator: , [38901,38902]
operator: , [38901,38902]
===
match
---
argument [7764,7772]
argument [7764,7772]
===
match
---
trailer [24816,24825]
trailer [24816,24825]
===
match
---
argument [15483,15517]
argument [15483,15517]
===
match
---
argument [25075,25094]
argument [25075,25094]
===
match
---
trailer [43286,43288]
trailer [43286,43288]
===
match
---
name: class_name [11844,11854]
name: class_name [11844,11854]
===
match
---
argument [42010,42036]
argument [42010,42036]
===
match
---
trailer [15644,15665]
trailer [15644,15665]
===
match
---
trailer [77787,77801]
trailer [77787,77801]
===
match
---
arglist [6190,6229]
arglist [6190,6229]
===
match
---
name: task2 [43800,43805]
name: task2 [43800,43805]
===
match
---
assert_stmt [38213,38244]
assert_stmt [38213,38244]
===
match
---
suite [28285,28327]
suite [28285,28327]
===
match
---
atom_expr [65282,65299]
atom_expr [65282,65299]
===
match
---
trailer [9036,9198]
trailer [9036,9198]
===
match
---
trailer [14992,15001]
trailer [14992,15001]
===
match
---
atom_expr [53865,53878]
atom_expr [53865,53878]
===
match
---
operator: , [33791,33792]
operator: , [33791,33792]
===
match
---
parameters [5358,5364]
parameters [5358,5364]
===
match
---
operator: == [55549,55551]
operator: == [55549,55551]
===
match
---
arglist [58234,58272]
arglist [58234,58272]
===
match
---
simple_stmt [26137,26163]
simple_stmt [26137,26163]
===
match
---
simple_stmt [14219,14272]
simple_stmt [14219,14272]
===
match
---
operator: = [15583,15584]
operator: = [15583,15584]
===
match
---
number: 1 [46222,46223]
number: 1 [46222,46223]
===
match
---
trailer [4640,4650]
trailer [4640,4650]
===
match
---
suite [50433,51530]
suite [50433,51530]
===
match
---
name: BashOperator [49042,49054]
name: BashOperator [49042,49054]
===
match
---
arglist [41827,41936]
arglist [41827,41936]
===
match
---
simple_stmt [9482,9498]
simple_stmt [9482,9498]
===
match
---
param [71400,71408]
param [71400,71408]
===
match
---
name: done [27653,27657]
name: done [27653,27657]
===
match
---
operator: = [37081,37082]
operator: = [37081,37082]
===
match
---
argument [69214,69223]
argument [69214,69223]
===
match
---
name: DAG [34284,34287]
name: DAG [34284,34287]
===
match
---
argument [9313,9345]
argument [9313,9345]
===
match
---
operator: , [47974,47975]
operator: , [47974,47975]
===
match
---
trailer [42806,42851]
trailer [42806,42851]
===
match
---
trailer [66970,66972]
trailer [66970,66972]
===
match
---
atom_expr [11517,11534]
atom_expr [11517,11534]
===
match
---
name: method_patch [12527,12539]
name: method_patch [12527,12539]
===
match
---
parameters [63679,63685]
parameters [63679,63685]
===
match
---
trailer [74614,74622]
trailer [74614,74622]
===
match
---
atom_expr [2532,2545]
atom_expr [2532,2545]
===
match
---
name: start_date [4814,4824]
name: start_date [4814,4824]
===
match
---
trailer [12591,12593]
trailer [12591,12593]
===
match
---
name: run_with_error [19414,19428]
name: run_with_error [19414,19428]
===
match
---
trailer [27961,27969]
trailer [27961,27969]
===
match
---
argument [30746,30752]
argument [30746,30752]
===
match
---
name: fail [24317,24321]
name: fail [24317,24321]
===
match
---
name: dag [34519,34522]
name: dag [34519,34522]
===
match
---
name: get_template_context [58295,58315]
name: get_template_context [58295,58315]
===
match
---
argument [16174,16208]
argument [16174,16208]
===
match
---
operator: , [52587,52588]
operator: , [52587,52588]
===
match
---
operator: , [889,890]
operator: , [889,890]
===
match
---
name: self [55713,55717]
name: self [55713,55717]
===
match
---
name: post_execute [42373,42385]
name: post_execute [42373,42385]
===
match
---
name: RUNNING [16533,16540]
name: RUNNING [16533,16540]
===
match
---
simple_stmt [66280,66444]
simple_stmt [66280,66444]
===
match
---
arglist [66758,66794]
arglist [66758,66794]
===
match
---
name: pool_slots [14910,14920]
name: pool_slots [14910,14920]
===
match
---
operator: , [13302,13303]
operator: , [13302,13303]
===
match
---
name: state [35157,35162]
name: state [35157,35162]
===
match
---
operator: , [24846,24847]
operator: , [24846,24847]
===
match
---
arglist [52930,52960]
arglist [52930,52960]
===
match
---
decorator [31565,33904]
decorator [31565,33904]
===
match
---
trailer [72863,72868]
trailer [72863,72868]
===
match
---
trailer [24413,24448]
trailer [24413,24448]
===
match
---
trailer [10768,10774]
trailer [10768,10774]
===
match
---
simple_stmt [63719,63758]
simple_stmt [63719,63758]
===
match
---
name: clear_db_dags [3482,3495]
name: clear_db_dags [3482,3495]
===
match
---
operator: = [34477,34478]
operator: = [34477,34478]
===
match
---
operator: , [7550,7551]
operator: , [7550,7551]
===
match
---
name: create_session [10713,10727]
name: create_session [10713,10727]
===
match
---
atom_expr [75773,75794]
atom_expr [75773,75794]
===
match
---
name: timezone [44233,44241]
name: timezone [44233,44241]
===
match
---
operator: , [69956,69957]
operator: , [69956,69957]
===
match
---
name: op [7353,7355]
name: op [7353,7355]
===
match
---
name: timezone [13285,13293]
name: timezone [13285,13293]
===
match
---
simple_stmt [65252,65355]
simple_stmt [65252,65355]
===
match
---
comparison [79654,79687]
comparison [79654,79687]
===
match
---
trailer [61978,62001]
trailer [61978,62001]
===
match
---
name: PythonOperator [74119,74133]
name: PythonOperator [74119,74133]
===
match
---
argument [4488,4502]
argument [4488,4502]
===
match
---
name: value [38425,38430]
name: value [38425,38430]
===
match
---
param [39783,39787]
param [39783,39787]
===
match
---
atom_expr [56751,56760]
atom_expr [56751,56760]
===
match
---
expr_stmt [44199,44251]
expr_stmt [44199,44251]
===
match
---
trailer [52508,52514]
trailer [52508,52514]
===
match
---
string: 'task' [44149,44155]
string: 'task' [44149,44155]
===
match
---
operator: = [80196,80197]
operator: = [80196,80197]
===
match
---
operator: , [73427,73428]
operator: , [73427,73428]
===
match
---
atom [31736,31785]
atom [31736,31785]
===
match
---
operator: + [5224,5225]
operator: + [5224,5225]
===
match
---
arglist [55849,55933]
arglist [55849,55933]
===
match
---
trailer [20243,20253]
trailer [20243,20253]
===
match
---
number: 2 [50073,50074]
number: 2 [50073,50074]
===
match
---
atom_expr [76150,76217]
atom_expr [76150,76217]
===
match
---
arglist [28453,28810]
arglist [28453,28810]
===
match
---
trailer [15942,15946]
trailer [15942,15946]
===
match
---
argument [40610,40621]
argument [40610,40621]
===
match
---
trailer [76186,76193]
trailer [76186,76193]
===
match
---
comparison [10195,10217]
comparison [10195,10217]
===
match
---
suite [8319,8363]
suite [8319,8363]
===
match
---
name: expected_end_date [29697,29714]
name: expected_end_date [29697,29714]
===
match
---
atom_expr [24901,24918]
atom_expr [24901,24918]
===
match
---
name: ti3 [63322,63325]
name: ti3 [63322,63325]
===
match
---
simple_stmt [71205,71242]
simple_stmt [71205,71242]
===
match
---
assert_stmt [45257,45320]
assert_stmt [45257,45320]
===
match
---
name: method_patch [12218,12230]
name: method_patch [12218,12230]
===
match
---
expr_stmt [40340,40384]
expr_stmt [40340,40384]
===
match
---
operator: , [33094,33095]
operator: , [33094,33095]
===
match
---
name: datetime [47149,47157]
name: datetime [47149,47157]
===
match
---
atom_expr [48201,48332]
atom_expr [48201,48332]
===
match
---
operator: , [32162,32163]
operator: , [32162,32163]
===
match
---
argument [42665,42696]
argument [42665,42696]
===
match
---
trailer [22601,22605]
trailer [22601,22605]
===
match
---
trailer [52750,52754]
trailer [52750,52754]
===
match
---
name: DAG [68180,68183]
name: DAG [68180,68183]
===
match
---
number: 0 [33554,33555]
number: 0 [33554,33555]
===
match
---
atom_expr [46433,46443]
atom_expr [46433,46443]
===
match
---
name: seconds [22410,22417]
name: seconds [22410,22417]
===
match
---
operator: = [56761,56762]
operator: = [56761,56762]
===
match
---
atom [7840,7860]
atom [7840,7860]
===
match
---
argument [31250,31283]
argument [31250,31283]
===
match
---
simple_stmt [42307,42312]
simple_stmt [42307,42312]
===
match
---
trailer [19232,19247]
trailer [19232,19247]
===
match
---
simple_stmt [74655,74738]
simple_stmt [74655,74738]
===
match
---
arglist [34805,35023]
arglist [34805,35023]
===
match
---
name: find_for_task_instance [30333,30355]
name: find_for_task_instance [30333,30355]
===
match
---
operator: = [55896,55897]
operator: = [55896,55897]
===
match
---
name: task_id [9843,9850]
name: task_id [9843,9850]
===
match
---
argument [44714,44728]
argument [44714,44728]
===
match
---
trailer [74682,74737]
trailer [74682,74737]
===
match
---
name: pool [11355,11359]
name: pool [11355,11359]
===
match
---
name: upstream_failed [34913,34928]
name: upstream_failed [34913,34928]
===
match
---
name: Variable [58070,58078]
name: Variable [58070,58078]
===
match
---
name: SUCCESS [54871,54878]
name: SUCCESS [54871,54878]
===
match
---
name: self [17696,17700]
name: self [17696,17700]
===
match
---
name: utcnow [38767,38773]
name: utcnow [38767,38773]
===
match
---
string: "task_instance" [62096,62111]
string: "task_instance" [62096,62111]
===
match
---
simple_stmt [13251,13330]
simple_stmt [13251,13330]
===
match
---
name: ti [19741,19743]
name: ti [19741,19743]
===
match
---
operator: , [16399,16400]
operator: , [16399,16400]
===
match
---
atom [47561,47580]
atom [47561,47580]
===
match
---
operator: = [63137,63138]
operator: = [63137,63138]
===
match
---
operator: = [49218,49219]
operator: = [49218,49219]
===
match
---
trailer [77466,77475]
trailer [77466,77475]
===
match
---
testlist_comp [12207,12230]
testlist_comp [12207,12230]
===
match
---
atom_expr [80057,80082]
atom_expr [80057,80082]
===
match
---
name: airflow [1139,1146]
name: airflow [1139,1146]
===
match
---
trailer [45238,45245]
trailer [45238,45245]
===
match
---
name: start_date [55563,55573]
name: start_date [55563,55573]
===
match
---
atom_expr [58188,58216]
atom_expr [58188,58216]
===
match
---
name: execution_date [15708,15722]
name: execution_date [15708,15722]
===
match
---
name: ti [21535,21537]
name: ti [21535,21537]
===
match
---
name: dag [7764,7767]
name: dag [7764,7767]
===
match
---
param [53783,53790]
param [53783,53790]
===
match
---
operator: = [44176,44177]
operator: = [44176,44177]
===
match
---
operator: = [14920,14921]
operator: = [14920,14921]
===
match
---
atom_expr [38688,38726]
atom_expr [38688,38726]
===
match
---
name: bool [51659,51663]
name: bool [51659,51663]
===
match
---
operator: == [14502,14504]
operator: == [14502,14504]
===
match
---
name: timedelta [40738,40747]
name: timedelta [40738,40747]
===
match
---
string: '1' [69543,69546]
string: '1' [69543,69546]
===
match
---
comparison [20780,20798]
comparison [20780,20798]
===
match
---
trailer [4436,4445]
trailer [4436,4445]
===
match
---
string: 'exit 1' [23459,23467]
string: 'exit 1' [23459,23467]
===
match
---
operator: = [60643,60644]
operator: = [60643,60644]
===
match
---
operator: , [37232,37233]
operator: , [37232,37233]
===
match
---
name: dag [38455,38458]
name: dag [38455,38458]
===
match
---
name: State [20711,20716]
name: State [20711,20716]
===
match
---
argument [40174,40190]
argument [40174,40190]
===
match
---
string: 'op' [46929,46933]
string: 'op' [46929,46933]
===
match
---
name: expected_url [46447,46459]
name: expected_url [46447,46459]
===
match
---
operator: , [72728,72729]
operator: , [72728,72729]
===
match
---
fstring_expr [67049,67059]
fstring_expr [67049,67059]
===
match
---
argument [57007,57037]
argument [57007,57037]
===
match
---
operator: == [71618,71620]
operator: == [71618,71620]
===
match
---
name: DAG [36266,36269]
name: DAG [36266,36269]
===
match
---
name: task_ids [40651,40659]
name: task_ids [40651,40659]
===
match
---
simple_stmt [45401,45465]
simple_stmt [45401,45465]
===
match
---
operator: , [44818,44819]
operator: , [44818,44819]
===
match
---
atom_expr [30763,30904]
atom_expr [30763,30904]
===
match
---
simple_stmt [75051,75094]
simple_stmt [75051,75094]
===
match
---
trailer [37565,37567]
trailer [37565,37567]
===
match
---
decorated [58879,59909]
decorated [58879,59909]
===
match
---
name: ti [79251,79253]
name: ti [79251,79253]
===
match
---
simple_stmt [78785,78829]
simple_stmt [78785,78829]
===
match
---
operator: = [52137,52138]
operator: = [52137,52138]
===
match
---
string: """         test that updating the executor_config propagates to the TaskInstance DB         """ [15272,15368]
string: """         test that updating the executor_config propagates to the TaskInstance DB         """ [15272,15368]
===
match
---
name: session [75506,75513]
name: session [75506,75513]
===
match
---
argument [65606,65633]
argument [65606,65633]
===
match
---
string: 'C' [71809,71812]
string: 'C' [71809,71812]
===
match
---
string: 'to' [49625,49629]
string: 'to' [49625,49629]
===
match
---
name: session [13651,13658]
name: session [13651,13658]
===
match
---
atom_expr [40699,40707]
atom_expr [40699,40707]
===
match
---
string: 'fallback' [57884,57894]
string: 'fallback' [57884,57894]
===
match
---
arglist [58083,58111]
arglist [58083,58111]
===
match
---
trailer [73820,73831]
trailer [73820,73831]
===
match
---
trailer [72315,72322]
trailer [72315,72322]
===
match
---
argument [14070,14077]
argument [14070,14077]
===
match
---
dotted_name [54334,54354]
dotted_name [54334,54354]
===
match
---
arglist [59625,59660]
arglist [59625,59660]
===
match
---
trailer [58339,58355]
trailer [58339,58355]
===
match
---
operator: , [52152,52153]
operator: , [52152,52153]
===
match
---
name: task_c [74196,74202]
name: task_c [74196,74202]
===
match
---
simple_stmt [28302,28327]
simple_stmt [28302,28327]
===
match
---
string: 'airflow' [41640,41649]
string: 'airflow' [41640,41649]
===
match
---
operator: = [76202,76203]
operator: = [76202,76203]
===
match
---
trailer [19187,19201]
trailer [19187,19201]
===
match
---
operator: , [9707,9708]
operator: , [9707,9708]
===
match
---
name: date1 [27596,27601]
name: date1 [27596,27601]
===
match
---
name: ti [41005,41007]
name: ti [41005,41007]
===
match
---
name: try_number [44368,44378]
name: try_number [44368,44378]
===
match
---
name: ti3 [45413,45416]
name: ti3 [45413,45416]
===
match
---
atom_expr [73194,73204]
atom_expr [73194,73204]
===
match
---
trailer [30355,30359]
trailer [30355,30359]
===
match
---
name: execution_date [14330,14344]
name: execution_date [14330,14344]
===
match
---
atom_expr [72005,72018]
atom_expr [72005,72018]
===
match
---
number: 2016 [28789,28793]
number: 2016 [28789,28793]
===
match
---
arglist [20098,20380]
arglist [20098,20380]
===
match
---
trailer [19165,19172]
trailer [19165,19172]
===
match
---
operator: = [63771,63772]
operator: = [63771,63772]
===
match
---
operator: , [40275,40276]
operator: , [40275,40276]
===
match
---
operator: , [36005,36006]
operator: , [36005,36006]
===
match
---
name: DAG [60544,60547]
name: DAG [60544,60547]
===
match
---
with_stmt [58555,58650]
with_stmt [58555,58650]
===
match
---
operator: == [4430,4432]
operator: == [4430,4432]
===
match
---
parameters [8403,8409]
parameters [8403,8409]
===
match
---
operator: , [23625,23626]
operator: , [23625,23626]
===
match
---
name: execution_date [41827,41841]
name: execution_date [41827,41841]
===
match
---
operator: , [36040,36041]
operator: , [36040,36041]
===
match
---
operator: , [76725,76726]
operator: , [76725,76726]
===
match
---
operator: , [35530,35531]
operator: , [35530,35531]
===
match
---
name: add [22633,22636]
name: add [22633,22636]
===
match
---
argument [23279,23289]
argument [23279,23289]
===
match
---
argument [78355,78362]
argument [78355,78362]
===
match
---
name: task_id [47463,47470]
name: task_id [47463,47470]
===
match
---
operator: = [64557,64558]
operator: = [64557,64558]
===
match
---
funcdef [68121,68925]
funcdef [68121,68925]
===
match
---
name: DummyOperator [46609,46622]
name: DummyOperator [46609,46622]
===
match
---
operator: , [40219,40220]
operator: , [40219,40220]
===
match
---
atom_expr [12392,12400]
atom_expr [12392,12400]
===
match
---
name: concurrency [10425,10436]
name: concurrency [10425,10436]
===
match
---
operator: , [22118,22119]
operator: , [22118,22119]
===
match
---
operator: = [23644,23645]
operator: = [23644,23645]
===
match
---
name: execution_date [45018,45032]
name: execution_date [45018,45032]
===
match
---
suite [49792,50137]
suite [49792,50137]
===
match
---
operator: { [16275,16276]
operator: { [16275,16276]
===
match
---
trailer [68787,68800]
trailer [68787,68800]
===
match
---
simple_stmt [40699,40708]
simple_stmt [40699,40708]
===
match
---
argument [17152,17204]
argument [17152,17204]
===
match
---
name: pytest [1002,1008]
name: pytest [1002,1008]
===
match
---
arglist [53098,53155]
arglist [53098,53155]
===
match
---
operator: , [57797,57798]
operator: , [57797,57798]
===
match
---
string: 'A' [72663,72666]
string: 'A' [72663,72666]
===
match
---
name: filter [3252,3258]
name: filter [3252,3258]
===
match
---
argument [46623,46635]
argument [46623,46635]
===
match
---
operator: , [66219,66220]
operator: , [66219,66220]
===
match
---
trailer [26153,26160]
trailer [26153,26160]
===
match
---
operator: , [62464,62465]
operator: , [62464,62465]
===
match
---
operator: , [72322,72323]
operator: , [72322,72323]
===
match
---
name: models [42014,42020]
name: models [42014,42020]
===
match
---
argument [37097,37118]
argument [37097,37118]
===
match
---
trailer [32537,32553]
trailer [32537,32553]
===
match
---
operator: , [33487,33488]
operator: , [33487,33488]
===
match
---
name: callback_wrapper [50442,50458]
name: callback_wrapper [50442,50458]
===
match
---
name: run_type [25108,25116]
name: run_type [25108,25116]
===
match
---
string: '{\n  "a": {\n    "test": "value"\n  }\n}' [58955,58997]
string: '{\n  "a": {\n    "test": "value"\n  }\n}' [58955,58997]
===
match
---
atom_expr [75125,75174]
atom_expr [75125,75174]
===
match
---
name: downstream_ti [36600,36613]
name: downstream_ti [36600,36613]
===
match
---
name: max_delay [21666,21675]
name: max_delay [21666,21675]
===
match
---
atom_expr [40345,40384]
atom_expr [40345,40384]
===
match
---
simple_stmt [64252,64269]
simple_stmt [64252,64269]
===
match
---
operator: , [32962,32963]
operator: , [32962,32963]
===
match
---
import_from [1839,1915]
import_from [1839,1915]
===
match
---
name: datetime [60888,60896]
name: datetime [60888,60896]
===
match
---
param [78160,78165]
param [78160,78165]
===
match
---
operator: , [32897,32898]
operator: , [32897,32898]
===
match
---
comparison [31329,31354]
comparison [31329,31354]
===
match
---
trailer [11490,11555]
trailer [11490,11555]
===
match
---
name: ti [64194,64196]
name: ti [64194,64196]
===
match
---
atom_expr [40729,40755]
atom_expr [40729,40755]
===
match
---
atom_expr [49873,49961]
atom_expr [49873,49961]
===
match
---
trailer [10177,10179]
trailer [10177,10179]
===
match
---
string: 'args' [70166,70172]
string: 'args' [70166,70172]
===
match
---
operator: , [18060,18061]
operator: , [18060,18061]
===
match
---
name: ti [57285,57287]
name: ti [57285,57287]
===
match
---
argument [15782,15814]
argument [15782,15814]
===
match
---
trailer [41844,41859]
trailer [41844,41859]
===
match
---
name: start_date [49176,49186]
name: start_date [49176,49186]
===
match
---
simple_stmt [64116,64169]
simple_stmt [64116,64169]
===
match
---
argument [65856,65875]
argument [65856,65875]
===
match
---
operator: , [48285,48286]
operator: , [48285,48286]
===
match
---
operator: = [65576,65577]
operator: = [65576,65577]
===
match
---
atom_expr [9535,9543]
atom_expr [9535,9543]
===
match
---
string: 'test_run_pooling_task_op' [14030,14056]
string: 'test_run_pooling_task_op' [14030,14056]
===
match
---
atom_expr [43146,43193]
atom_expr [43146,43193]
===
match
---
trailer [65757,65764]
trailer [65757,65764]
===
match
---
name: SUCCESS [72011,72018]
name: SUCCESS [72011,72018]
===
match
---
expr_stmt [38746,38775]
expr_stmt [38746,38775]
===
match
---
atom_expr [4829,4841]
atom_expr [4829,4841]
===
match
---
operator: , [38801,38802]
operator: , [38801,38802]
===
match
---
argument [44633,44683]
argument [44633,44683]
===
match
---
operator: } [70696,70697]
operator: } [70696,70697]
===
match
---
operator: = [3068,3069]
operator: = [3068,3069]
===
match
---
name: ti [22268,22270]
name: ti [22268,22270]
===
match
---
simple_stmt [60436,60450]
simple_stmt [60436,60450]
===
match
---
operator: + [60657,60658]
operator: + [60657,60658]
===
match
---
name: wrap_task_instance [51257,51275]
name: wrap_task_instance [51257,51275]
===
match
---
operator: , [33426,33427]
operator: , [33426,33427]
===
match
---
except_clause [64871,64894]
except_clause [64871,64894]
===
match
---
operator: , [78582,78583]
operator: , [78582,78583]
===
match
---
operator: { [67036,67037]
operator: { [67036,67037]
===
match
---
expr_stmt [50962,50990]
expr_stmt [50962,50990]
===
match
---
simple_stmt [38130,38205]
simple_stmt [38130,38205]
===
match
---
atom [72798,72869]
atom [72798,72869]
===
match
---
operator: = [44801,44802]
operator: = [44801,44802]
===
match
---
simple_stmt [5186,5253]
simple_stmt [5186,5253]
===
match
---
name: owner [6876,6881]
name: owner [6876,6881]
===
match
---
trailer [63358,63373]
trailer [63358,63373]
===
match
---
simple_stmt [28830,28883]
simple_stmt [28830,28883]
===
match
---
atom [71720,71766]
atom [71720,71766]
===
match
---
number: 0 [23715,23716]
number: 0 [23715,23716]
===
match
---
simple_stmt [15050,15105]
simple_stmt [15050,15105]
===
match
---
name: op4 [7856,7859]
name: op4 [7856,7859]
===
match
---
assert_stmt [77363,77398]
assert_stmt [77363,77398]
===
match
---
name: task_id [75166,75173]
name: task_id [75166,75173]
===
match
---
import_as_names [1885,1915]
import_as_names [1885,1915]
===
match
---
comparison [77410,77452]
comparison [77410,77452]
===
match
---
name: template_context [57266,57282]
name: template_context [57266,57282]
===
match
---
trailer [76351,76357]
trailer [76351,76357]
===
match
---
arith_expr [26179,26216]
arith_expr [26179,26216]
===
match
---
name: dag [49120,49123]
name: dag [49120,49123]
===
match
---
trailer [10212,10217]
trailer [10212,10217]
===
match
---
operator: , [17525,17526]
operator: , [17525,17526]
===
match
---
string: 'airflow' [23645,23654]
string: 'airflow' [23645,23654]
===
match
---
name: DagRunType [65747,65757]
name: DagRunType [65747,65757]
===
match
---
trailer [3536,3550]
trailer [3536,3550]
===
match
---
name: ti_list [54194,54201]
name: ti_list [54194,54201]
===
match
---
expr_stmt [74751,74818]
expr_stmt [74751,74818]
===
match
---
simple_stmt [43765,43779]
simple_stmt [43765,43779]
===
match
---
operator: = [14231,14232]
operator: = [14231,14232]
===
match
---
number: 0 [33428,33429]
number: 0 [33428,33429]
===
match
---
operator: , [30926,30927]
operator: , [30926,30927]
===
match
---
operator: , [20186,20187]
operator: , [20186,20187]
===
match
---
simple_stmt [79965,80042]
simple_stmt [79965,80042]
===
match
---
simple_stmt [11989,12022]
simple_stmt [11989,12022]
===
match
---
operator: < [76494,76495]
operator: < [76494,76495]
===
match
---
name: run_type [15861,15869]
name: run_type [15861,15869]
===
match
---
trailer [27230,27236]
trailer [27230,27236]
===
match
---
name: ti [21342,21344]
name: ti [21342,21344]
===
match
---
comparison [27228,27250]
comparison [27228,27250]
===
match
---
operator: == [46926,46928]
operator: == [46926,46928]
===
match
---
name: datetime [4980,4988]
name: datetime [4980,4988]
===
match
---
name: DAG [10283,10286]
name: DAG [10283,10286]
===
match
---
comparison [24935,24954]
comparison [24935,24954]
===
match
---
parameters [11014,11020]
parameters [11014,11020]
===
match
---
operator: == [10798,10800]
operator: == [10798,10800]
===
match
---
name: Session [3079,3086]
name: Session [3079,3086]
===
match
---
expr_stmt [21619,21657]
expr_stmt [21619,21657]
===
match
---
tfpdef [51665,51684]
tfpdef [51665,51684]
===
match
---
decorator [48863,48912]
decorator [48863,48912]
===
match
---
comparison [25879,25911]
comparison [25879,25911]
===
match
---
trailer [47840,47849]
trailer [47840,47849]
===
match
---
atom_expr [9328,9345]
atom_expr [9328,9345]
===
match
---
string: 'task' [35303,35309]
string: 'task' [35303,35309]
===
match
---
name: DagRun [1371,1377]
name: DagRun [1371,1377]
===
match
---
name: TI [79784,79786]
name: TI [79784,79786]
===
match
---
expr_stmt [45055,45080]
expr_stmt [45055,45080]
===
match
---
number: 0 [32037,32038]
number: 0 [32037,32038]
===
match
---
name: state [31122,31127]
name: state [31122,31127]
===
match
---
argument [46794,46816]
argument [46794,46816]
===
match
---
simple_stmt [2448,2494]
simple_stmt [2448,2494]
===
match
---
simple_stmt [36756,36831]
simple_stmt [36756,36831]
===
match
---
fstring [67082,67119]
fstring [67082,67119]
===
match
---
operator: , [32224,32225]
operator: , [32224,32225]
===
match
---
operator: , [10343,10344]
operator: , [10343,10344]
===
match
---
trailer [18285,18292]
trailer [18285,18292]
===
match
---
funcdef [53219,53671]
funcdef [53219,53671]
===
match
---
string: 'mock_' [12466,12473]
string: 'mock_' [12466,12473]
===
match
---
name: datetime [53049,53057]
name: datetime [53049,53057]
===
match
---
trailer [74483,74498]
trailer [74483,74498]
===
match
---
string: 'mock_' [12313,12320]
string: 'mock_' [12313,12320]
===
match
---
operator: = [6844,6845]
operator: = [6844,6845]
===
match
---
name: State [72858,72863]
name: State [72858,72863]
===
match
---
name: ti [77410,77412]
name: ti [77410,77412]
===
match
---
trailer [53995,54011]
trailer [53995,54011]
===
match
---
trailer [66108,66122]
trailer [66108,66122]
===
match
---
atom_expr [26713,26785]
atom_expr [26713,26785]
===
match
---
name: execution_date [52138,52152]
name: execution_date [52138,52152]
===
match
---
operator: , [52906,52907]
operator: , [52906,52907]
===
match
---
trailer [11621,11625]
trailer [11621,11625]
===
match
---
trailer [53563,53566]
trailer [53563,53566]
===
match
---
assert_stmt [37854,37876]
assert_stmt [37854,37876]
===
match
---
name: State [17641,17646]
name: State [17641,17646]
===
match
---
name: date1 [26731,26736]
name: date1 [26731,26736]
===
match
---
number: 5 [32893,32894]
number: 5 [32893,32894]
===
match
---
name: task2 [43773,43778]
name: task2 [43773,43778]
===
match
---
operator: = [63853,63854]
operator: = [63853,63854]
===
match
---
number: 1 [33102,33103]
number: 1 [33102,33103]
===
match
---
simple_stmt [35471,35556]
simple_stmt [35471,35556]
===
match
---
name: State [73175,73180]
name: State [73175,73180]
===
match
---
name: run [64197,64200]
name: run [64197,64200]
===
match
---
atom_expr [44233,44250]
atom_expr [44233,44250]
===
match
---
name: state [65856,65861]
name: state [65856,65861]
===
match
---
trailer [36662,36682]
trailer [36662,36682]
===
match
---
trailer [51029,51043]
trailer [51029,51043]
===
match
---
name: state [78600,78605]
name: state [78600,78605]
===
match
---
name: expected_duration [29749,29766]
name: expected_duration [29749,29766]
===
match
---
name: get_num_running_task_instances [45345,45375]
name: get_num_running_task_instances [45345,45375]
===
match
---
trailer [61556,61566]
trailer [61556,61566]
===
match
---
simple_stmt [8125,8147]
simple_stmt [8125,8147]
===
match
---
operator: , [48253,48254]
operator: , [48253,48254]
===
match
---
name: ti2 [62505,62508]
name: ti2 [62505,62508]
===
match
---
operator: , [63225,63226]
operator: , [63225,63226]
===
match
---
parameters [2742,2752]
parameters [2742,2752]
===
match
---
atom_expr [22268,22292]
atom_expr [22268,22292]
===
match
---
expr_stmt [7574,7628]
expr_stmt [7574,7628]
===
match
---
atom_expr [16318,16356]
atom_expr [16318,16356]
===
match
---
operator: = [5836,5837]
operator: = [5836,5837]
===
match
---
trailer [5548,5595]
trailer [5548,5595]
===
match
---
name: bag_dag [74615,74622]
name: bag_dag [74615,74622]
===
match
---
name: DummyOperator [58188,58201]
name: DummyOperator [58188,58201]
===
match
---
argument [61655,61695]
argument [61655,61695]
===
match
---
operator: = [24007,24008]
operator: = [24007,24008]
===
match
---
suite [48462,48480]
suite [48462,48480]
===
match
---
name: freezegun [1014,1023]
name: freezegun [1014,1023]
===
match
---
expr_stmt [47902,47920]
expr_stmt [47902,47920]
===
match
---
comparison [76480,76507]
comparison [76480,76507]
===
match
---
operator: , [27943,27944]
operator: , [27943,27944]
===
match
---
operator: , [33806,33807]
operator: , [33806,33807]
===
match
---
funcdef [46027,46460]
funcdef [46027,46460]
===
match
---
operator: = [6059,6060]
operator: = [6059,6060]
===
match
---
name: dag_id [63784,63790]
name: dag_id [63784,63790]
===
match
---
name: DEFAULT_DATE [78980,78992]
name: DEFAULT_DATE [78980,78992]
===
match
---
trailer [15946,15963]
trailer [15946,15963]
===
match
---
string: """         Test that task reschedules are handled properly         """ [24090,24161]
string: """         Test that task reschedules are handled properly         """ [24090,24161]
===
match
---
number: 0 [15657,15658]
number: 0 [15657,15658]
===
match
---
name: task [40348,40352]
name: task [40348,40352]
===
match
---
arglist [36513,36531]
arglist [36513,36531]
===
match
---
trailer [74909,74914]
trailer [74909,74914]
===
match
---
number: 0 [33173,33174]
number: 0 [33173,33174]
===
match
---
operator: = [44125,44126]
operator: = [44125,44126]
===
match
---
operator: = [62462,62463]
operator: = [62462,62463]
===
match
---
operator: , [7844,7845]
operator: , [7844,7845]
===
match
---
assert_stmt [57320,57392]
assert_stmt [57320,57392]
===
match
---
name: dag [42648,42651]
name: dag [42648,42651]
===
match
---
operator: , [25137,25138]
operator: , [25137,25138]
===
match
---
string: 'test_op_2' [7602,7613]
string: 'test_op_2' [7602,7613]
===
match
---
comparison [51403,51459]
comparison [51403,51459]
===
match
---
name: execution_date [23756,23770]
name: execution_date [23756,23770]
===
match
---
name: ti [40817,40819]
name: ti [40817,40819]
===
match
---
operator: = [50938,50939]
operator: = [50938,50939]
===
match
---
suite [55719,56873]
suite [55719,56873]
===
match
---
name: execution_date [38887,38901]
name: execution_date [38887,38901]
===
match
---
atom_expr [21453,21466]
atom_expr [21453,21466]
===
match
---
string: 'exit 1' [48277,48285]
string: 'exit 1' [48277,48285]
===
match
---
number: 2016 [34242,34246]
number: 2016 [34242,34246]
===
match
---
atom_expr [71536,71578]
atom_expr [71536,71578]
===
match
---
with_stmt [59616,59711]
with_stmt [59616,59711]
===
match
---
atom_expr [5546,5595]
atom_expr [5546,5595]
===
match
---
operator: = [23952,23953]
operator: = [23952,23953]
===
match
---
operator: , [41892,41893]
operator: , [41892,41893]
===
match
---
name: State [55186,55191]
name: State [55186,55191]
===
match
---
name: get_task_instances [15982,16000]
name: get_task_instances [15982,16000]
===
match
---
operator: = [56962,56963]
operator: = [56962,56963]
===
match
---
arglist [36972,36991]
arglist [36972,36991]
===
match
---
number: 3 [27018,27019]
number: 3 [27018,27019]
===
match
---
operator: @ [76541,76542]
operator: @ [76541,76542]
===
match
---
number: 0 [36987,36988]
number: 0 [36987,36988]
===
match
---
operator: = [41366,41367]
operator: = [41366,41367]
===
match
---
name: done [28346,28350]
name: done [28346,28350]
===
match
---
name: timedelta [23219,23228]
name: timedelta [23219,23228]
===
match
---
name: task_id [49822,49829]
name: task_id [49822,49829]
===
match
---
name: task [46174,46178]
name: task [46174,46178]
===
match
---
name: DEFAULT_DATE [6767,6779]
name: DEFAULT_DATE [6767,6779]
===
match
---
name: dag [24717,24720]
name: dag [24717,24720]
===
match
---
atom_expr [47449,47476]
atom_expr [47449,47476]
===
match
---
name: ti [9559,9561]
name: ti [9559,9561]
===
match
---
trailer [30199,30204]
trailer [30199,30204]
===
match
---
argument [74563,74580]
argument [74563,74580]
===
match
---
testlist_comp [38163,38191]
testlist_comp [38163,38191]
===
match
---
operator: , [55307,55308]
operator: , [55307,55308]
===
match
---
arglist [37959,37992]
arglist [37959,37992]
===
match
---
assert_stmt [66162,66194]
assert_stmt [66162,66194]
===
match
---
name: ti [29823,29825]
name: ti [29823,29825]
===
match
---
operator: , [48733,48734]
operator: , [48733,48734]
===
match
---
name: ti [24970,24972]
name: ti [24970,24972]
===
match
---
number: 1 [6091,6092]
number: 1 [6091,6092]
===
match
---
dotted_name [35940,35960]
dotted_name [35940,35960]
===
match
---
operator: , [73121,73122]
operator: , [73121,73122]
===
match
---
atom_expr [71274,71290]
atom_expr [71274,71290]
===
match
---
name: provide_session [15193,15208]
name: provide_session [15193,15208]
===
match
---
name: ti [5898,5900]
name: ti [5898,5900]
===
match
---
assert_stmt [77180,77207]
assert_stmt [77180,77207]
===
match
---
arglist [65606,65688]
arglist [65606,65688]
===
match
---
name: expected_state [29113,29127]
name: expected_state [29113,29127]
===
match
---
name: ti [44432,44434]
name: ti [44432,44434]
===
match
---
expr_stmt [74110,74179]
expr_stmt [74110,74179]
===
match
---
operator: = [39960,39961]
operator: = [39960,39961]
===
match
---
trailer [11525,11532]
trailer [11525,11532]
===
match
---
trailer [7190,7197]
trailer [7190,7197]
===
match
---
name: FAILED [55178,55184]
name: FAILED [55178,55184]
===
match
---
name: dag [4759,4762]
name: dag [4759,4762]
===
match
---
number: 1 [33799,33800]
number: 1 [33799,33800]
===
match
---
name: key [41044,41047]
name: key [41044,41047]
===
match
---
name: clear_db_pools [77760,77774]
name: clear_db_pools [77760,77774]
===
match
---
decorator [55018,55064]
decorator [55018,55064]
===
match
---
name: task [58614,58618]
name: task [58614,58618]
===
match
---
operator: , [33109,33110]
operator: , [33109,33110]
===
match
---
name: timezone [16318,16326]
name: timezone [16318,16326]
===
match
---
name: params [47968,47974]
name: params [47968,47974]
===
match
---
atom_expr [77410,77428]
atom_expr [77410,77428]
===
match
---
trailer [44434,44445]
trailer [44434,44445]
===
match
---
operator: + [34620,34621]
operator: + [34620,34621]
===
match
---
name: DEFAULT_DATE [4965,4977]
name: DEFAULT_DATE [4965,4977]
===
match
---
simple_stmt [41396,41433]
simple_stmt [41396,41433]
===
match
---
suite [5365,6276]
suite [5365,6276]
===
match
---
trailer [36855,37003]
trailer [36855,37003]
===
match
---
name: test_retry_delay [18522,18538]
name: test_retry_delay [18522,18538]
===
match
---
name: State [25081,25086]
name: State [25081,25086]
===
match
---
operator: = [26231,26232]
operator: = [26231,26232]
===
match
---
expr_stmt [9641,9813]
expr_stmt [9641,9813]
===
match
---
number: 2 [11449,11450]
number: 2 [11449,11450]
===
match
---
trailer [77412,77428]
trailer [77412,77428]
===
match
---
name: self [77909,77913]
name: self [77909,77913]
===
match
---
operator: = [5767,5768]
operator: = [5767,5768]
===
match
---
name: dep [11799,11802]
name: dep [11799,11802]
===
match
---
trailer [62056,62059]
trailer [62056,62059]
===
match
---
name: get_task_instances [16674,16692]
name: get_task_instances [16674,16692]
===
match
---
name: ti1 [37154,37157]
name: ti1 [37154,37157]
===
match
---
operator: = [39479,39480]
operator: = [39479,39480]
===
match
---
simple_stmt [37329,37400]
simple_stmt [37329,37400]
===
match
---
name: start_date [68532,68542]
name: start_date [68532,68542]
===
match
---
atom_expr [15382,15424]
atom_expr [15382,15424]
===
match
---
parameters [77940,77946]
parameters [77940,77946]
===
match
---
string: """         test that running task in an existing pool with mark_success param         update task state as SUCCESS without running task         despite it fails dependency checks.         """ [16842,17034]
string: """         test that running task in an existing pool with mark_success param         update task state as SUCCESS without running task         despite it fails dependency checks.         """ [16842,17034]
===
match
---
param [51650,51664]
param [51650,51664]
===
match
---
argument [39555,39562]
argument [39555,39562]
===
match
---
name: expand [53184,53190]
name: expand [53184,53190]
===
match
---
operator: , [36220,36221]
operator: , [36220,36221]
===
match
---
simple_stmt [15272,15369]
simple_stmt [15272,15369]
===
match
---
name: ti1 [45269,45272]
name: ti1 [45269,45272]
===
match
---
atom_expr [29682,29693]
atom_expr [29682,29693]
===
match
---
name: run [40702,40705]
name: run [40702,40705]
===
match
---
operator: , [69648,69649]
operator: , [69648,69649]
===
match
---
comparison [29888,29930]
comparison [29888,29930]
===
match
---
number: 0 [31818,31819]
number: 0 [31818,31819]
===
match
---
name: task [9943,9947]
name: task [9943,9947]
===
match
---
operator: = [38431,38432]
operator: = [38431,38432]
===
match
---
atom [55171,55229]
atom [55171,55229]
===
match
---
name: execution_date [16475,16489]
name: execution_date [16475,16489]
===
match
---
name: self [66253,66257]
name: self [66253,66257]
===
match
---
simple_stmt [19441,19479]
simple_stmt [19441,19479]
===
match
---
name: key [38400,38403]
name: key [38400,38403]
===
match
---
operator: == [39564,39566]
operator: == [39564,39566]
===
match
---
atom_expr [13193,13231]
atom_expr [13193,13231]
===
match
---
operator: = [74203,74204]
operator: = [74203,74204]
===
match
---
name: task_id [65606,65613]
name: task_id [65606,65613]
===
match
---
argument [22026,22033]
argument [22026,22033]
===
match
---
name: pendulum [57546,57554]
name: pendulum [57546,57554]
===
match
---
name: dag [14700,14703]
name: dag [14700,14703]
===
match
---
param [73517,73533]
param [73517,73533]
===
match
---
atom_expr [9989,10001]
atom_expr [9989,10001]
===
match
---
atom [49549,49569]
atom [49549,49569]
===
match
---
string: '--mark-success' [67889,67905]
string: '--mark-success' [67889,67905]
===
match
---
operator: , [37127,37128]
operator: , [37127,37128]
===
match
---
name: Optional [2565,2573]
name: Optional [2565,2573]
===
match
---
trailer [4059,4144]
trailer [4059,4144]
===
match
---
name: email [50733,50738]
name: email [50733,50738]
===
match
---
param [79520,79524]
param [79520,79524]
===
match
---
argument [14717,14747]
argument [14717,14747]
===
match
---
raise_stmt [24339,24363]
raise_stmt [24339,24363]
===
match
---
string: '@monthly' [38510,38520]
string: '@monthly' [38510,38520]
===
match
---
name: assert_command [68081,68095]
name: assert_command [68081,68095]
===
match
---
assert_stmt [55328,55398]
assert_stmt [55328,55398]
===
match
---
argument [9143,9160]
argument [9143,9160]
===
match
---
name: str [33978,33981]
name: str [33978,33981]
===
match
---
trailer [74668,74682]
trailer [74668,74682]
===
match
---
argument [49141,49162]
argument [49141,49162]
===
match
---
name: State [20883,20888]
name: State [20883,20888]
===
match
---
name: owner [13153,13158]
name: owner [13153,13158]
===
match
---
name: DummyOperator [37083,37096]
name: DummyOperator [37083,37096]
===
match
---
name: TI [17372,17374]
name: TI [17372,17374]
===
match
---
number: 1 [44267,44268]
number: 1 [44267,44268]
===
match
---
simple_stmt [57487,57565]
simple_stmt [57487,57565]
===
match
---
name: ti [19494,19496]
name: ti [19494,19496]
===
match
---
operator: , [32512,32513]
operator: , [32512,32513]
===
match
---
param [61363,61367]
param [61363,61367]
===
match
---
operator: , [18213,18214]
operator: , [18213,18214]
===
match
---
operator: = [59827,59828]
operator: = [59827,59828]
===
match
---
trailer [24692,24703]
trailer [24692,24703]
===
match
---
name: self [57949,57953]
name: self [57949,57953]
===
match
---
trailer [76254,76256]
trailer [76254,76256]
===
match
---
operator: = [20234,20235]
operator: = [20234,20235]
===
match
---
simple_stmt [47930,47985]
simple_stmt [47930,47985]
===
match
---
trailer [34232,34241]
trailer [34232,34241]
===
match
---
arith_expr [12080,12100]
arith_expr [12080,12100]
===
match
---
arglist [41775,41785]
arglist [41775,41785]
===
match
---
name: BaseSensorOperator [1664,1682]
name: BaseSensorOperator [1664,1682]
===
match
---
name: merge [61179,61184]
name: merge [61179,61184]
===
match
---
name: start_date [78283,78293]
name: start_date [78283,78293]
===
match
---
argument [37811,37833]
argument [37811,37833]
===
match
---
number: 5 [34456,34457]
number: 5 [34456,34457]
===
match
---
operator: == [45410,45412]
operator: == [45410,45412]
===
match
---
operator: , [21929,21930]
operator: , [21929,21930]
===
match
---
string: 'UTC' [52194,52199]
string: 'UTC' [52194,52199]
===
match
---
atom_expr [65409,65564]
atom_expr [65409,65564]
===
match
---
atom_expr [39269,39312]
atom_expr [39269,39312]
===
match
---
trailer [71990,71998]
trailer [71990,71998]
===
match
---
operator: , [32393,32394]
operator: , [32393,32394]
===
match
---
name: State [71856,71861]
name: State [71856,71861]
===
match
---
operator: = [65659,65660]
operator: = [65659,65660]
===
match
---
argument [76958,77002]
argument [76958,77002]
===
match
---
name: ti [66133,66135]
name: ti [66133,66135]
===
match
---
expr_stmt [64515,64767]
expr_stmt [64515,64767]
===
match
---
number: 1 [32161,32162]
number: 1 [32161,32162]
===
match
---
assert_stmt [65168,65243]
assert_stmt [65168,65243]
===
match
---
expr_stmt [66280,66443]
expr_stmt [66280,66443]
===
match
---
operator: , [56993,56994]
operator: , [56993,56994]
===
match
---
string: 'op' [46631,46635]
string: 'op' [46631,46635]
===
match
---
name: session [10887,10894]
name: session [10887,10894]
===
match
---
trailer [21420,21432]
trailer [21420,21432]
===
match
---
operator: , [33373,33374]
operator: , [33373,33374]
===
match
---
param [25338,25358]
param [25338,25358]
===
match
---
operator: , [59233,59234]
operator: , [59233,59234]
===
match
---
atom_expr [6962,6993]
atom_expr [6962,6993]
===
match
---
operator: = [20536,20537]
operator: = [20536,20537]
===
match
---
operator: , [59135,59136]
operator: , [59135,59136]
===
match
---
name: state [27231,27236]
name: state [27231,27236]
===
match
---
operator: = [27548,27549]
operator: = [27548,27549]
===
match
---
expr_stmt [49970,50019]
expr_stmt [49970,50019]
===
match
---
name: UPSTREAM_FAILED [32538,32553]
name: UPSTREAM_FAILED [32538,32553]
===
match
---
name: UP_FOR_RESCHEDULE [27619,27636]
name: UP_FOR_RESCHEDULE [27619,27636]
===
match
---
argument [56344,56364]
argument [56344,56364]
===
match
---
decorated [57570,58415]
decorated [57570,58415]
===
match
---
operator: , [42651,42652]
operator: , [42651,42652]
===
match
---
argument [46180,46224]
argument [46180,46224]
===
match
---
name: rollback [16767,16775]
name: rollback [16767,16775]
===
match
---
operator: = [48144,48145]
operator: = [48144,48145]
===
match
---
arglist [68594,68642]
arglist [68594,68642]
===
match
---
name: test_infer_dag [7378,7392]
name: test_infer_dag [7378,7392]
===
match
---
name: python_callable [65644,65659]
name: python_callable [65644,65659]
===
match
---
atom_expr [6796,6832]
atom_expr [6796,6832]
===
match
---
param [78166,78187]
param [78166,78187]
===
match
---
operator: , [14892,14893]
operator: , [14892,14893]
===
match
---
trailer [8293,8300]
trailer [8293,8300]
===
match
---
name: Session [73634,73641]
name: Session [73634,73641]
===
match
---
assert_stmt [71591,71650]
assert_stmt [71591,71650]
===
match
---
atom_expr [50789,50821]
atom_expr [50789,50821]
===
match
---
simple_stmt [40086,40294]
simple_stmt [40086,40294]
===
match
---
simple_stmt [60945,60974]
simple_stmt [60945,60974]
===
match
---
name: DEFAULT_DATE [43743,43755]
name: DEFAULT_DATE [43743,43755]
===
match
---
operator: , [37486,37487]
operator: , [37486,37487]
===
match
---
trailer [16431,16433]
trailer [16431,16433]
===
match
---
operator: , [28799,28800]
operator: , [28799,28800]
===
match
---
name: execution_date [66767,66781]
name: execution_date [66767,66781]
===
match
---
name: task [77386,77390]
name: task [77386,77390]
===
match
---
assert_stmt [51497,51529]
assert_stmt [51497,51529]
===
match
---
import_as_names [875,902]
import_as_names [875,902]
===
match
---
assert_stmt [19344,19369]
assert_stmt [19344,19369]
===
match
---
name: DEFAULT_DATE [44946,44958]
name: DEFAULT_DATE [44946,44958]
===
match
---
name: ti3 [45218,45221]
name: ti3 [45218,45221]
===
match
---
simple_stmt [20773,20799]
simple_stmt [20773,20799]
===
match
---
trailer [77920,77922]
trailer [77920,77922]
===
match
---
arglist [35352,35370]
arglist [35352,35370]
===
match
---
param [19009,19011]
param [19009,19011]
===
match
---
atom_expr [12899,12912]
atom_expr [12899,12912]
===
match
---
name: owner [4928,4933]
name: owner [4928,4933]
===
match
---
argument [18095,18131]
argument [18095,18131]
===
match
---
operator: = [39498,39499]
operator: = [39498,39499]
===
match
---
name: ti [68313,68315]
name: ti [68313,68315]
===
match
---
expr_stmt [46654,46692]
expr_stmt [46654,46692]
===
match
---
trailer [3595,3620]
trailer [3595,3620]
===
match
---
argument [24000,24009]
argument [24000,24009]
===
match
---
expr_stmt [60706,60836]
expr_stmt [60706,60836]
===
match
---
trailer [67010,67061]
trailer [67010,67061]
===
match
---
atom_expr [40017,40077]
atom_expr [40017,40077]
===
match
---
number: 0 [32896,32897]
number: 0 [32896,32897]
===
match
---
atom_expr [20072,20390]
atom_expr [20072,20390]
===
match
---
expr_stmt [73732,73878]
expr_stmt [73732,73878]
===
match
---
trailer [22851,22860]
trailer [22851,22860]
===
match
---
name: self [47740,47744]
name: self [47740,47744]
===
match
---
arglist [50212,50248]
arglist [50212,50248]
===
match
---
simple_stmt [3506,3526]
simple_stmt [3506,3526]
===
match
---
atom [35984,36005]
atom [35984,36005]
===
match
---
operator: , [31828,31829]
operator: , [31828,31829]
===
match
---
number: 2 [53517,53518]
number: 2 [53517,53518]
===
match
---
simple_stmt [36472,36496]
simple_stmt [36472,36496]
===
match
---
operator: = [60857,60858]
operator: = [60857,60858]
===
match
---
atom_expr [44320,44328]
atom_expr [44320,44328]
===
match
---
name: state [61894,61899]
name: state [61894,61899]
===
match
---
simple_stmt [66133,66154]
simple_stmt [66133,66154]
===
match
---
name: session [10733,10740]
name: session [10733,10740]
===
match
---
name: get_previous_ti [53467,53482]
name: get_previous_ti [53467,53482]
===
match
---
assert_stmt [51351,51387]
assert_stmt [51351,51387]
===
match
---
name: func [24621,24625]
name: func [24621,24625]
===
match
---
operator: = [43821,43822]
operator: = [43821,43822]
===
match
---
testlist_comp [31880,31936]
testlist_comp [31880,31936]
===
match
---
name: op [6841,6843]
name: op [6841,6843]
===
match
---
atom_expr [57419,57458]
atom_expr [57419,57458]
===
match
---
expr_stmt [53295,53350]
expr_stmt [53295,53350]
===
match
---
atom_expr [75685,75756]
atom_expr [75685,75756]
===
match
---
atom_expr [58292,58317]
atom_expr [58292,58317]
===
match
---
arglist [7531,7564]
arglist [7531,7564]
===
match
---
operator: , [6754,6755]
operator: , [6754,6755]
===
match
---
decorators [48691,48912]
decorators [48691,48912]
===
match
---
name: DagRunType [79332,79342]
name: DagRunType [79332,79342]
===
match
---
string: 'bash_command' [19949,19963]
string: 'bash_command' [19949,19963]
===
match
---
name: dependencies [74438,74450]
name: dependencies [74438,74450]
===
match
---
name: State [32452,32457]
name: State [32452,32457]
===
match
---
name: session [52218,52225]
name: session [52218,52225]
===
match
---
trailer [14495,14501]
trailer [14495,14501]
===
match
---
name: datetime [60879,60887]
name: datetime [60879,60887]
===
match
---
name: task [30922,30926]
name: task [30922,30926]
===
match
---
name: task [68321,68325]
name: task [68321,68325]
===
match
---
name: dag_id [30480,30486]
name: dag_id [30480,30486]
===
match
---
string: 'test_get_num_running_task_instances' [44568,44605]
string: 'test_get_num_running_task_instances' [44568,44605]
===
match
---
operator: , [52200,52201]
operator: , [52200,52201]
===
match
---
name: state [41873,41878]
name: state [41873,41878]
===
match
---
operator: , [26852,26853]
operator: , [26852,26853]
===
match
---
name: date1 [30041,30046]
name: date1 [30041,30046]
===
match
---
name: end_date [65502,65510]
name: end_date [65502,65510]
===
match
---
name: State [32914,32919]
name: State [32914,32919]
===
match
---
operator: > [76535,76536]
operator: > [76535,76536]
===
match
---
name: provide_session [2187,2202]
name: provide_session [2187,2202]
===
match
---
atom_expr [3534,3552]
atom_expr [3534,3552]
===
match
---
argument [66471,66489]
argument [66471,66489]
===
match
---
assert_stmt [8805,8838]
assert_stmt [8805,8838]
===
match
---
string: 'test_not_requeue_non_requeueable_task_instance_op' [11269,11320]
string: 'test_not_requeue_non_requeueable_task_instance_op' [11269,11320]
===
match
---
operator: = [28842,28843]
operator: = [28842,28843]
===
match
---
operator: = [64603,64604]
operator: = [64603,64604]
===
match
---
name: clear [30130,30135]
name: clear [30130,30135]
===
match
---
arglist [15060,15103]
arglist [15060,15103]
===
match
---
operator: = [60081,60082]
operator: = [60081,60082]
===
match
---
assert_stmt [4373,4445]
assert_stmt [4373,4445]
===
match
---
arglist [27931,27975]
arglist [27931,27975]
===
match
---
argument [22637,22648]
argument [22637,22648]
===
match
---
name: ti [14219,14221]
name: ti [14219,14221]
===
match
---
trailer [45167,45172]
trailer [45167,45172]
===
match
---
arglist [19131,19174]
arglist [19131,19174]
===
match
---
atom_expr [23351,23728]
atom_expr [23351,23728]
===
match
---
name: concurrency [9789,9800]
name: concurrency [9789,9800]
===
match
---
trailer [26846,26902]
trailer [26846,26902]
===
match
---
operator: = [43645,43646]
operator: = [43645,43646]
===
match
---
atom_expr [52481,52498]
atom_expr [52481,52498]
===
match
---
simple_stmt [55955,55990]
simple_stmt [55955,55990]
===
match
---
atom_expr [21143,21161]
atom_expr [21143,21161]
===
match
---
testlist_comp [31800,31864]
testlist_comp [31800,31864]
===
match
---
name: task_id [20098,20105]
name: task_id [20098,20105]
===
match
---
assert_stmt [39075,39134]
assert_stmt [39075,39134]
===
match
---
operator: = [18826,18827]
operator: = [18826,18827]
===
match
---
atom_expr [4056,4144]
atom_expr [4056,4144]
===
match
---
shift_expr [8693,8710]
shift_expr [8693,8710]
===
match
---
operator: = [50491,50492]
operator: = [50491,50492]
===
match
---
atom_expr [65126,65159]
atom_expr [65126,65159]
===
match
---
atom_expr [49249,49296]
atom_expr [49249,49296]
===
match
---
string: 'worker-config' [69633,69648]
string: 'worker-config' [69633,69648]
===
match
---
decorator [77983,78125]
decorator [77983,78125]
===
match
---
argument [51057,51089]
argument [51057,51089]
===
match
---
atom_expr [66081,66097]
atom_expr [66081,66097]
===
match
---
operator: , [31896,31897]
operator: , [31896,31897]
===
match
---
operator: = [5322,5323]
operator: = [5322,5323]
===
match
---
name: run_type [56411,56419]
name: run_type [56411,56419]
===
match
---
name: State [63334,63339]
name: State [63334,63339]
===
match
---
name: datetime [47528,47536]
name: datetime [47528,47536]
===
match
---
string: 'op1' [58210,58215]
string: 'op1' [58210,58215]
===
match
---
name: dag [34271,34274]
name: dag [34271,34274]
===
match
---
name: task [44212,44216]
name: task [44212,44216]
===
match
---
simple_stmt [74594,74642]
simple_stmt [74594,74642]
===
match
---
atom [59560,59584]
atom [59560,59584]
===
match
---
operator: , [33558,33559]
operator: , [33558,33559]
===
match
---
trailer [30686,30688]
trailer [30686,30688]
===
match
---
operator: = [23749,23750]
operator: = [23749,23750]
===
match
---
number: 1 [6085,6086]
number: 1 [6085,6086]
===
match
---
argument [20144,20186]
argument [20144,20186]
===
match
---
atom_expr [56818,56833]
atom_expr [56818,56833]
===
match
---
name: patch [11904,11909]
name: patch [11904,11909]
===
match
---
name: execution_date [17386,17400]
name: execution_date [17386,17400]
===
match
---
atom_expr [44550,44606]
atom_expr [44550,44606]
===
match
---
atom_expr [35489,35554]
atom_expr [35489,35554]
===
match
---
name: DAG [35238,35241]
name: DAG [35238,35241]
===
match
---
name: AirflowException [64396,64412]
name: AirflowException [64396,64412]
===
match
---
name: commit [75514,75520]
name: commit [75514,75520]
===
match
---
suite [69041,71366]
suite [69041,71366]
===
match
---
name: set_state [52326,52335]
name: set_state [52326,52335]
===
match
---
operator: >> [43770,43772]
operator: >> [43770,43772]
===
match
---
operator: , [32159,32160]
operator: , [32159,32160]
===
match
---
expr_stmt [3097,3329]
expr_stmt [3097,3329]
===
match
---
name: State [9571,9576]
name: State [9571,9576]
===
match
---
param [34037,34049]
param [34037,34049]
===
match
---
name: dag [65707,65710]
name: dag [65707,65710]
===
match
---
arith_expr [4101,4143]
arith_expr [4101,4143]
===
match
---
operator: = [20156,20157]
operator: = [20156,20157]
===
match
---
param [34058,34079]
param [34058,34079]
===
match
---
operator: , [65911,65912]
operator: , [65911,65912]
===
match
---
expr_stmt [14761,15037]
expr_stmt [14761,15037]
===
match
---
name: ti [25660,25662]
name: ti [25660,25662]
===
match
---
operator: , [49834,49835]
operator: , [49834,49835]
===
match
---
simple_stmt [53591,53671]
simple_stmt [53591,53671]
===
match
---
operator: = [8079,8080]
operator: = [8079,8080]
===
match
---
operator: = [24620,24621]
operator: = [24620,24621]
===
match
---
with_stmt [35755,35934]
with_stmt [35755,35934]
===
match
---
arglist [28838,28881]
arglist [28838,28881]
===
match
---
argument [66758,66765]
argument [66758,66765]
===
match
---
name: DEFAULT_DATE [73705,73717]
name: DEFAULT_DATE [73705,73717]
===
match
---
name: log_url [46436,46443]
name: log_url [46436,46443]
===
match
---
arglist [41692,41702]
arglist [41692,41702]
===
match
---
trailer [79950,79956]
trailer [79950,79956]
===
match
---
name: task [13003,13007]
name: task [13003,13007]
===
match
---
atom_expr [48421,48429]
atom_expr [48421,48429]
===
match
---
operator: = [24578,24579]
operator: = [24578,24579]
===
match
---
name: end_date [6487,6495]
name: end_date [6487,6495]
===
match
---
arglist [50060,50074]
arglist [50060,50074]
===
match
---
trailer [58233,58273]
trailer [58233,58273]
===
match
---
trailer [67109,67117]
trailer [67109,67117]
===
match
---
import_from [1683,1730]
import_from [1683,1730]
===
match
---
name: dag_id [17060,17066]
name: dag_id [17060,17066]
===
match
---
simple_stmt [12657,12822]
simple_stmt [12657,12822]
===
match
---
name: xcom_pull [37801,37810]
name: xcom_pull [37801,37810]
===
match
---
atom [72304,72357]
atom [72304,72357]
===
match
---
expr_stmt [35042,35092]
expr_stmt [35042,35092]
===
match
---
name: pool_slots [77242,77252]
name: pool_slots [77242,77252]
===
match
---
simple_stmt [79006,79050]
simple_stmt [79006,79050]
===
match
---
name: RUNNING [79298,79305]
name: RUNNING [79298,79305]
===
match
---
trailer [50300,50309]
trailer [50300,50309]
===
match
---
trailer [8510,8545]
trailer [8510,8545]
===
match
---
name: ti [20419,20421]
name: ti [20419,20421]
===
match
---
atom_expr [29298,29306]
atom_expr [29298,29306]
===
match
---
name: start_date [4954,4964]
name: start_date [4954,4964]
===
match
---
name: RUNNING [14370,14377]
name: RUNNING [14370,14377]
===
match
---
name: State [55630,55635]
name: State [55630,55635]
===
match
---
simple_stmt [56614,56662]
simple_stmt [56614,56662]
===
match
---
simple_stmt [5374,5425]
simple_stmt [5374,5425]
===
match
---
argument [45018,45045]
argument [45018,45045]
===
match
---
name: ti [24935,24937]
name: ti [24935,24937]
===
match
---
trailer [71101,71145]
trailer [71101,71145]
===
match
---
string: 'test_check_and_change_state_before_execution' [44064,44110]
string: 'test_check_and_change_state_before_execution' [44064,44110]
===
match
---
name: validate_ti_states [71375,71393]
name: validate_ti_states [71375,71393]
===
match
---
operator: , [18962,18963]
operator: , [18962,18963]
===
match
---
name: now [79114,79117]
name: now [79114,79117]
===
match
---
argument [61476,61498]
argument [61476,61498]
===
match
---
trailer [8111,8116]
trailer [8111,8116]
===
match
---
trailer [12465,12501]
trailer [12465,12501]
===
match
---
number: 0 [33034,33035]
number: 0 [33034,33035]
===
match
---
argument [7678,7690]
argument [7678,7690]
===
match
---
name: exec_date [40716,40725]
name: exec_date [40716,40725]
===
match
---
name: DEFAULT_DATE [5741,5753]
name: DEFAULT_DATE [5741,5753]
===
match
---
simple_stmt [46506,46544]
simple_stmt [46506,46544]
===
match
---
expr_stmt [68653,68708]
expr_stmt [68653,68708]
===
match
---
name: timezone [17309,17317]
name: timezone [17309,17317]
===
match
---
trailer [60900,60902]
trailer [60900,60902]
===
match
---
operator: , [8936,8937]
operator: , [8936,8937]
===
match
---
string: 'test_retry_handling' [20034,20055]
string: 'test_retry_handling' [20034,20055]
===
match
---
trailer [12140,12152]
trailer [12140,12152]
===
match
---
number: 0 [31764,31765]
number: 0 [31764,31765]
===
match
---
name: tis [16728,16731]
name: tis [16728,16731]
===
match
---
operator: = [30872,30873]
operator: = [30872,30873]
===
match
---
trailer [5840,5881]
trailer [5840,5881]
===
match
---
trailer [45272,45303]
trailer [45272,45303]
===
match
---
operator: = [78564,78565]
operator: = [78564,78565]
===
match
---
operator: == [66178,66180]
operator: == [66178,66180]
===
match
---
trailer [22496,22516]
trailer [22496,22516]
===
match
---
simple_stmt [56926,57112]
simple_stmt [56926,57112]
===
match
---
name: refresh_from_db [66136,66151]
name: refresh_from_db [66136,66151]
===
match
---
name: date4 [27931,27936]
name: date4 [27931,27936]
===
match
---
atom_expr [72310,72322]
atom_expr [72310,72322]
===
match
---
simple_stmt [788,804]
simple_stmt [788,804]
===
match
---
expr_stmt [44506,44534]
expr_stmt [44506,44534]
===
match
---
name: UP_FOR_RESCHEDULE [30057,30074]
name: UP_FOR_RESCHEDULE [30057,30074]
===
match
---
name: create_session [2171,2185]
name: create_session [2171,2185]
===
match
---
name: add [11618,11621]
name: add [11618,11621]
===
match
---
atom_expr [40440,40457]
atom_expr [40440,40457]
===
match
---
operator: = [46114,46115]
operator: = [46114,46115]
===
match
---
trailer [34287,34322]
trailer [34287,34322]
===
match
---
operator: , [30046,30047]
operator: , [30046,30047]
===
match
---
string: 'tasks' [67770,67777]
string: 'tasks' [67770,67777]
===
match
---
string: 'try_number' [69939,69951]
string: 'try_number' [69939,69951]
===
match
---
simple_stmt [74110,74180]
simple_stmt [74110,74180]
===
match
---
operator: , [53004,53005]
operator: , [53004,53005]
===
match
---
assert_stmt [50110,50136]
assert_stmt [50110,50136]
===
match
---
name: create_session [10077,10091]
name: create_session [10077,10091]
===
match
---
atom_expr [17923,17975]
atom_expr [17923,17975]
===
match
---
string: 'one_failed' [33349,33361]
string: 'one_failed' [33349,33361]
===
match
---
atom_expr [53022,53082]
atom_expr [53022,53082]
===
match
---
name: State [55215,55220]
name: State [55215,55220]
===
match
---
comparison [29626,29662]
comparison [29626,29662]
===
match
---
name: airflow [1584,1591]
name: airflow [1584,1591]
===
match
---
simple_stmt [27030,27055]
simple_stmt [27030,27055]
===
match
---
trailer [58727,58748]
trailer [58727,58748]
===
match
---
simple_stmt [38530,38738]
simple_stmt [38530,38738]
===
match
---
number: 1 [27284,27285]
number: 1 [27284,27285]
===
match
---
trailer [63745,63757]
trailer [63745,63757]
===
match
---
trailer [74728,74736]
trailer [74728,74736]
===
match
---
trailer [63430,63453]
trailer [63430,63453]
===
match
---
operator: , [32749,32750]
operator: , [32749,32750]
===
match
---
name: date1 [26137,26142]
name: date1 [26137,26142]
===
match
---
trailer [72334,72339]
trailer [72334,72339]
===
match
---
string: 'C' [72020,72023]
string: 'C' [72020,72023]
===
match
---
argument [61760,61793]
argument [61760,61793]
===
match
---
trailer [25501,25503]
trailer [25501,25503]
===
match
---
simple_stmt [7295,7308]
simple_stmt [7295,7308]
===
match
---
name: task2 [16135,16140]
name: task2 [16135,16140]
===
match
---
simple_stmt [15972,16003]
simple_stmt [15972,16003]
===
match
---
atom_expr [54737,54796]
atom_expr [54737,54796]
===
match
---
funcdef [30430,31355]
funcdef [30430,31355]
===
match
---
name: mock [924,928]
name: mock [924,928]
===
match
---
atom_expr [53456,53484]
atom_expr [53456,53484]
===
match
---
name: task [50673,50677]
name: task [50673,50677]
===
match
---
name: get_previous_ti [53520,53535]
name: get_previous_ti [53520,53535]
===
match
---
name: session [61136,61143]
name: session [61136,61143]
===
match
---
operator: , [38716,38717]
operator: , [38716,38717]
===
match
---
name: session [52226,52233]
name: session [52226,52233]
===
match
---
with_item [3720,3747]
with_item [3720,3747]
===
match
---
trailer [64818,64825]
trailer [64818,64825]
===
match
---
name: filter [3206,3212]
name: filter [3206,3212]
===
match
---
operator: , [44872,44873]
operator: , [44872,44873]
===
match
---
name: State [52342,52347]
name: State [52342,52347]
===
match
---
atom_expr [21177,21185]
atom_expr [21177,21185]
===
match
---
trailer [13452,13456]
trailer [13452,13456]
===
match
---
name: owner [8666,8671]
name: owner [8666,8671]
===
match
---
trailer [77436,77452]
trailer [77436,77452]
===
match
---
number: 5 [32683,32684]
number: 5 [32683,32684]
===
match
---
name: opener [49306,49312]
name: opener [49306,49312]
===
match
---
operator: , [30074,30075]
operator: , [30074,30075]
===
match
---
atom_expr [42866,42890]
atom_expr [42866,42890]
===
match
---
name: ti [40440,40442]
name: ti [40440,40442]
===
match
---
name: mock [943,947]
name: mock [943,947]
===
match
---
comparison [30182,30204]
comparison [30182,30204]
===
match
---
operator: , [19140,19141]
operator: , [19140,19141]
===
match
---
operator: = [4655,4656]
operator: = [4655,4656]
===
match
---
operator: = [47518,47519]
operator: = [47518,47519]
===
match
---
trailer [10129,10133]
trailer [10129,10133]
===
match
---
comparison [39269,39321]
comparison [39269,39321]
===
match
---
name: python_callable [63961,63976]
name: python_callable [63961,63976]
===
match
---
name: task [28843,28847]
name: task [28843,28847]
===
match
---
operator: , [59416,59417]
operator: , [59416,59417]
===
match
---
name: value [41334,41339]
name: value [41334,41339]
===
match
---
trailer [57354,57372]
trailer [57354,57372]
===
match
---
name: owner [76113,76118]
name: owner [76113,76118]
===
match
---
atom_expr [72841,72851]
atom_expr [72841,72851]
===
match
---
atom [58910,59364]
atom [58910,59364]
===
match
---
simple_stmt [66750,66796]
simple_stmt [66750,66796]
===
match
---
arglist [52269,52309]
arglist [52269,52309]
===
match
---
name: catchup [51650,51657]
name: catchup [51650,51657]
===
match
---
name: op [6936,6938]
name: op [6936,6938]
===
match
---
string: 'test_run_pooling_task' [16090,16113]
string: 'test_run_pooling_task' [16090,16113]
===
match
---
name: python_callable [24605,24620]
name: python_callable [24605,24620]
===
match
---
name: _run_finished_callback [63431,63453]
name: _run_finished_callback [63431,63453]
===
match
---
name: self [14553,14557]
name: self [14553,14557]
===
match
---
trailer [77390,77398]
trailer [77390,77398]
===
match
---
operator: = [59753,59754]
operator: = [59753,59754]
===
match
---
name: datetime [76982,76990]
name: datetime [76982,76990]
===
match
---
operator: == [31338,31340]
operator: == [31338,31340]
===
match
---
operator: , [32561,32562]
operator: , [32561,32562]
===
match
---
name: op1 [4360,4363]
name: op1 [4360,4363]
===
match
---
simple_stmt [76342,76380]
simple_stmt [76342,76380]
===
match
---
operator: = [48317,48318]
operator: = [48317,48318]
===
match
---
trailer [27703,27754]
trailer [27703,27754]
===
match
---
simple_stmt [48342,48395]
simple_stmt [48342,48395]
===
match
---
name: ti [2777,2779]
name: ti [2777,2779]
===
match
---
atom_expr [9299,9366]
atom_expr [9299,9366]
===
match
---
name: session [13686,13693]
name: session [13686,13693]
===
match
---
name: end_date [22204,22212]
name: end_date [22204,22212]
===
match
---
if_stmt [74282,74394]
if_stmt [74282,74394]
===
match
---
name: models [12935,12941]
name: models [12935,12941]
===
match
---
number: 1 [43442,43443]
number: 1 [43442,43443]
===
match
---
name: TestTaskInstance [3396,3412]
name: TestTaskInstance [3396,3412]
===
match
---
operator: = [34365,34366]
operator: = [34365,34366]
===
match
---
param [23187,23191]
param [23187,23191]
===
match
---
name: ti [44199,44201]
name: ti [44199,44201]
===
match
---
arith_expr [23954,24010]
arith_expr [23954,24010]
===
match
---
atom_expr [11036,11103]
atom_expr [11036,11103]
===
match
---
argument [44920,44929]
argument [44920,44929]
===
match
---
string: 'A' [72376,72379]
string: 'A' [72376,72379]
===
match
---
name: utils [2150,2155]
name: utils [2150,2155]
===
match
---
operator: = [40676,40677]
operator: = [40676,40677]
===
match
---
atom_expr [25823,25836]
atom_expr [25823,25836]
===
match
---
simple_stmt [52012,52249]
simple_stmt [52012,52249]
===
match
---
name: end_date [76499,76507]
name: end_date [76499,76507]
===
match
---
name: end_date [50031,50039]
name: end_date [50031,50039]
===
match
---
operator: = [7695,7696]
operator: = [7695,7696]
===
match
---
simple_stmt [25816,25860]
simple_stmt [25816,25860]
===
match
---
string: """         Tests the option for Operators to push XComs         """ [41257,41325]
string: """         Tests the option for Operators to push XComs         """ [41257,41325]
===
match
---
number: 0 [32099,32100]
number: 0 [32099,32100]
===
match
---
trailer [20253,20264]
trailer [20253,20264]
===
match
---
operator: + [4630,4631]
operator: + [4630,4631]
===
match
---
number: 2 [9801,9802]
number: 2 [9801,9802]
===
match
---
name: execution_date [79254,79268]
name: execution_date [79254,79268]
===
match
---
name: SCHEDULED [52067,52076]
name: SCHEDULED [52067,52076]
===
match
---
trailer [55655,55658]
trailer [55655,55658]
===
match
---
atom_expr [45089,45098]
atom_expr [45089,45098]
===
match
---
suite [54469,55013]
suite [54469,55013]
===
match
---
testlist_comp [32078,32124]
testlist_comp [32078,32124]
===
match
---
suite [59662,59711]
suite [59662,59711]
===
match
---
simple_stmt [22943,22975]
simple_stmt [22943,22975]
===
match
---
simple_stmt [34593,34649]
simple_stmt [34593,34649]
===
match
---
operator: , [54532,54533]
operator: , [54532,54533]
===
match
---
argument [78600,78619]
argument [78600,78619]
===
match
---
name: add [22861,22864]
name: add [22861,22864]
===
match
---
name: op3 [5268,5271]
name: op3 [5268,5271]
===
match
---
name: datetime [64044,64052]
name: datetime [64044,64052]
===
match
---
atom_expr [57127,57194]
atom_expr [57127,57194]
===
match
---
name: all_non_requeueable_deps [11806,11830]
name: all_non_requeueable_deps [11806,11830]
===
match
---
parameters [47047,47053]
parameters [47047,47053]
===
match
---
name: commit [66908,66914]
name: commit [66908,66914]
===
match
---
operator: , [34387,34388]
operator: , [34387,34388]
===
match
---
name: ti [39269,39271]
name: ti [39269,39271]
===
match
---
name: task_id [2523,2530]
name: task_id [2523,2530]
===
match
---
name: state [14358,14363]
name: state [14358,14363]
===
match
---
name: run_as_user [77347,77358]
name: run_as_user [77347,77358]
===
match
---
with_item [78902,78929]
with_item [78902,78929]
===
match
---
suite [17868,17908]
suite [17868,17908]
===
match
---
argument [38597,38604]
argument [38597,38604]
===
match
---
operator: , [2185,2186]
operator: , [2185,2186]
===
match
---
atom_expr [47658,47676]
atom_expr [47658,47676]
===
match
---
name: SUCCESS [54167,54174]
name: SUCCESS [54167,54174]
===
match
---
simple_stmt [30410,30425]
simple_stmt [30410,30425]
===
match
---
expr_stmt [30914,30937]
expr_stmt [30914,30937]
===
match
---
trailer [16335,16356]
trailer [16335,16356]
===
match
---
argument [79070,79079]
argument [79070,79079]
===
match
---
name: TI [16386,16388]
name: TI [16386,16388]
===
match
---
name: self [5359,5363]
name: self [5359,5363]
===
match
---
name: ti [25823,25825]
name: ti [25823,25825]
===
match
---
name: context_arg_3 [63465,63478]
name: context_arg_3 [63465,63478]
===
match
---
name: TI [47111,47113]
name: TI [47111,47113]
===
match
---
name: AirflowException [48445,48461]
name: AirflowException [48445,48461]
===
match
---
name: session [10859,10866]
name: session [10859,10866]
===
match
---
name: execution_date [9949,9963]
name: execution_date [9949,9963]
===
match
---
name: mock_on_retry_2 [62227,62242]
name: mock_on_retry_2 [62227,62242]
===
match
---
name: ti [39638,39640]
name: ti [39638,39640]
===
match
---
string: "override" [47875,47885]
string: "override" [47875,47885]
===
match
---
trailer [6968,6975]
trailer [6968,6975]
===
match
---
operator: , [37981,37982]
operator: , [37981,37982]
===
match
---
operator: , [32165,32166]
operator: , [32165,32166]
===
match
---
atom_expr [60923,60936]
atom_expr [60923,60936]
===
match
---
operator: , [64720,64721]
operator: , [64720,64721]
===
match
---
atom_expr [30990,31074]
atom_expr [30990,31074]
===
match
---
operator: = [67469,67470]
operator: = [67469,67470]
===
match
---
atom_expr [14706,14748]
atom_expr [14706,14748]
===
match
---
number: 0 [20374,20375]
number: 0 [20374,20375]
===
match
---
simple_stmt [42093,42258]
simple_stmt [42093,42258]
===
match
---
trailer [45005,45046]
trailer [45005,45046]
===
match
---
name: state [13304,13309]
name: state [13304,13309]
===
match
---
simple_stmt [43605,43676]
simple_stmt [43605,43676]
===
match
---
name: next_retry_datetime [22725,22744]
name: next_retry_datetime [22725,22744]
===
match
---
atom_expr [30552,30668]
atom_expr [30552,30668]
===
match
---
atom_expr [43424,43438]
atom_expr [43424,43438]
===
match
---
atom_expr [27172,27183]
atom_expr [27172,27183]
===
match
---
name: isinstance [57494,57504]
name: isinstance [57494,57504]
===
match
---
arglist [80201,80261]
arglist [80201,80261]
===
match
---
simple_stmt [77130,77162]
simple_stmt [77130,77162]
===
match
---
name: self [75811,75815]
name: self [75811,75815]
===
match
---
operator: , [26813,26814]
operator: , [26813,26814]
===
match
---
name: task_id [49068,49075]
name: task_id [49068,49075]
===
match
---
trailer [29822,29826]
trailer [29822,29826]
===
match
---
simple_stmt [55407,55478]
simple_stmt [55407,55478]
===
match
---
atom_expr [51753,51832]
atom_expr [51753,51832]
===
match
---
argument [3778,3794]
argument [3778,3794]
===
match
---
import_name [842,855]
import_name [842,855]
===
match
---
name: AirflowException [7198,7214]
name: AirflowException [7198,7214]
===
match
---
atom [33081,33138]
atom [33081,33138]
===
match
---
atom_expr [35238,35260]
atom_expr [35238,35260]
===
match
---
operator: , [53247,53248]
operator: , [53247,53248]
===
match
---
assert_stmt [24928,24954]
assert_stmt [24928,24954]
===
match
---
name: TI [50867,50869]
name: TI [50867,50869]
===
match
---
trailer [5244,5252]
trailer [5244,5252]
===
match
---
decorated [35939,36717]
decorated [35939,36717]
===
match
---
string: 'airflow' [37389,37398]
string: 'airflow' [37389,37398]
===
match
---
simple_stmt [74196,74266]
simple_stmt [74196,74266]
===
match
---
operator: , [14922,14923]
operator: , [14922,14923]
===
match
---
operator: , [38719,38720]
operator: , [38719,38720]
===
match
---
name: expected_duration [25946,25963]
name: expected_duration [25946,25963]
===
match
---
name: __name__ [11965,11973]
name: __name__ [11965,11973]
===
match
---
trailer [15125,15132]
trailer [15125,15132]
===
match
---
name: state [56378,56383]
name: state [56378,56383]
===
match
---
trailer [57382,57391]
trailer [57382,57391]
===
match
---
number: 0 [32360,32361]
number: 0 [32360,32361]
===
match
---
trailer [53537,53552]
trailer [53537,53552]
===
match
---
trailer [57211,57256]
trailer [57211,57256]
===
match
---
operator: , [32524,32525]
operator: , [32524,32525]
===
match
---
name: SUCCESS [55382,55389]
name: SUCCESS [55382,55389]
===
match
---
name: context [60469,60476]
name: context [60469,60476]
===
match
---
name: PythonOperator [17991,18005]
name: PythonOperator [17991,18005]
===
match
---
trailer [8135,8139]
trailer [8135,8139]
===
match
---
trailer [53827,53834]
trailer [53827,53834]
===
match
---
suite [12564,12594]
suite [12564,12594]
===
match
---
string: 'test_xcom_1' [38163,38176]
string: 'test_xcom_1' [38163,38176]
===
match
---
argument [65644,65688]
argument [65644,65688]
===
match
---
string: 'test_generate_command_default_param' [67257,67294]
string: 'test_generate_command_default_param' [67257,67294]
===
match
---
name: test_email_alert_with_config [48920,48948]
name: test_email_alert_with_config [48920,48948]
===
match
---
string: 'test_failure_email' [49005,49025]
string: 'test_failure_email' [49005,49025]
===
match
---
operator: = [24870,24871]
operator: = [24870,24871]
===
match
---
simple_stmt [23058,23090]
simple_stmt [23058,23090]
===
match
---
fstring_end: ' [34512,34513]
fstring_end: ' [34512,34513]
===
match
---
name: TestOperator [42581,42593]
name: TestOperator [42581,42593]
===
match
---
expr_stmt [55955,55989]
expr_stmt [55955,55989]
===
match
---
name: State [27107,27112]
name: State [27107,27112]
===
match
---
string: 'test_pool' [11360,11371]
string: 'test_pool' [11360,11371]
===
match
---
atom_expr [12856,12873]
atom_expr [12856,12873]
===
match
---
operator: , [4065,4066]
operator: , [4065,4066]
===
match
---
arglist [43706,43755]
arglist [43706,43755]
===
match
---
operator: , [53419,53420]
operator: , [53419,53420]
===
match
---
operator: = [5717,5718]
operator: = [5717,5718]
===
match
---
operator: = [48234,48235]
operator: = [48234,48235]
===
match
---
name: task [10458,10462]
name: task [10458,10462]
===
match
---
simple_stmt [45329,45393]
simple_stmt [45329,45393]
===
match
---
name: RUNNING [78612,78619]
name: RUNNING [78612,78619]
===
match
---
name: merge [66063,66068]
name: merge [66063,66068]
===
match
---
trailer [20888,20895]
trailer [20888,20895]
===
match
---
name: ti [78785,78787]
name: ti [78785,78787]
===
match
---
assert_stmt [5261,5325]
assert_stmt [5261,5325]
===
match
---
name: execution_date [18353,18367]
name: execution_date [18353,18367]
===
match
---
testlist_star_expr [26795,26805]
testlist_star_expr [26795,26805]
===
match
---
testlist_star_expr [27030,27040]
testlist_star_expr [27030,27040]
===
match
---
name: mark_success [39005,39017]
name: mark_success [39005,39017]
===
match
---
operator: = [46137,46138]
operator: = [46137,46138]
===
match
---
suite [42294,42312]
suite [42294,42312]
===
match
---
name: datetime [17318,17326]
name: datetime [17318,17326]
===
match
---
name: ti_state_mapping [71482,71498]
name: ti_state_mapping [71482,71498]
===
match
---
name: dag_run [47200,47207]
name: dag_run [47200,47207]
===
match
---
trailer [42767,42779]
trailer [42767,42779]
===
match
---
name: on_execute_callable [60798,60817]
name: on_execute_callable [60798,60817]
===
match
---
name: end_date [5020,5028]
name: end_date [5020,5028]
===
match
---
atom_expr [54194,54219]
atom_expr [54194,54219]
===
match
---
atom_expr [46744,46792]
atom_expr [46744,46792]
===
match
---
arglist [7594,7627]
arglist [7594,7627]
===
match
---
name: execution_date [14312,14326]
name: execution_date [14312,14326]
===
match
---
trailer [70844,70857]
trailer [70844,70857]
===
match
---
trailer [41136,41146]
trailer [41136,41146]
===
match
---
name: dag [16444,16447]
name: dag [16444,16447]
===
match
---
trailer [21395,21402]
trailer [21395,21402]
===
match
---
name: seconds [23970,23977]
name: seconds [23970,23977]
===
match
---
name: ti [44272,44274]
name: ti [44272,44274]
===
match
---
name: ti [22461,22463]
name: ti [22461,22463]
===
match
---
number: 1 [45264,45265]
number: 1 [45264,45265]
===
match
---
name: State [12404,12409]
name: State [12404,12409]
===
match
---
name: content [59850,59857]
name: content [59850,59857]
===
match
---
atom [72710,72780]
atom [72710,72780]
===
match
---
simple_stmt [3631,3661]
simple_stmt [3631,3661]
===
match
---
operator: @ [35939,35940]
operator: @ [35939,35940]
===
match
---
argument [47776,47788]
argument [47776,47788]
===
match
---
trailer [48213,48332]
trailer [48213,48332]
===
match
---
atom_expr [48376,48393]
atom_expr [48376,48393]
===
match
---
string: 'template: {{ti.task_id}}' [49335,49361]
string: 'template: {{ti.task_id}}' [49335,49361]
===
match
---
operator: = [76130,76131]
operator: = [76130,76131]
===
match
---
operator: == [3277,3279]
operator: == [3277,3279]
===
match
---
atom_expr [60659,60686]
atom_expr [60659,60686]
===
match
---
testlist_comp [32336,32400]
testlist_comp [32336,32400]
===
match
---
string: 'execution_date=2018-01-01T00%3A00%3A00%2B00%3A00' [46305,46355]
string: 'execution_date=2018-01-01T00%3A00%3A00%2B00%3A00' [46305,46355]
===
match
---
name: dag [66491,66494]
name: dag [66491,66494]
===
match
---
name: commit [10154,10160]
name: commit [10154,10160]
===
match
---
name: task [47442,47446]
name: task [47442,47446]
===
match
---
name: dag [66495,66498]
name: dag [66495,66498]
===
match
---
name: RUNNING [40483,40490]
name: RUNNING [40483,40490]
===
match
---
name: task [79595,79599]
name: task [79595,79599]
===
match
---
atom_expr [62137,62172]
atom_expr [62137,62172]
===
match
---
atom_expr [54056,54103]
atom_expr [54056,54103]
===
match
---
name: _ [48511,48512]
name: _ [48511,48512]
===
match
---
simple_stmt [6123,6174]
simple_stmt [6123,6174]
===
match
---
operator: , [52705,52706]
operator: , [52705,52706]
===
match
---
operator: } [11973,11974]
operator: } [11973,11974]
===
match
---
operator: = [79540,79541]
operator: = [79540,79541]
===
match
---
operator: = [43661,43662]
operator: = [43661,43662]
===
match
---
operator: , [27047,27048]
operator: , [27047,27048]
===
match
---
operator: , [50068,50069]
operator: , [50068,50069]
===
match
---
name: run_type [14391,14399]
name: run_type [14391,14399]
===
match
---
name: task_a [74854,74860]
name: task_a [74854,74860]
===
match
---
expr_stmt [49306,49362]
expr_stmt [49306,49362]
===
match
---
atom_expr [6745,6780]
atom_expr [6745,6780]
===
match
---
operator: == [76358,76360]
operator: == [76358,76360]
===
match
---
number: 3 [54828,54829]
number: 3 [54828,54829]
===
match
---
comparison [20911,20930]
comparison [20911,20930]
===
match
---
operator: , [66694,66695]
operator: , [66694,66695]
===
match
---
comparison [4792,4824]
comparison [4792,4824]
===
match
---
name: dag [66280,66283]
name: dag [66280,66283]
===
match
---
import_as_names [955,977]
import_as_names [955,977]
===
match
---
operator: , [69565,69566]
operator: , [69565,69566]
===
match
---
trailer [48349,48394]
trailer [48349,48394]
===
match
---
expr_stmt [64776,64828]
expr_stmt [64776,64828]
===
match
---
name: dag_id [43542,43548]
name: dag_id [43542,43548]
===
match
---
simple_stmt [67716,67917]
simple_stmt [67716,67917]
===
match
---
operator: = [23304,23305]
operator: = [23304,23305]
===
match
---
name: session [75748,75755]
name: session [75748,75755]
===
match
---
name: config [2470,2476]
name: config [2470,2476]
===
match
---
param [64351,64355]
param [64351,64355]
===
match
---
number: 2016 [64713,64717]
number: 2016 [64713,64717]
===
match
---
expr_stmt [76027,76068]
expr_stmt [76027,76068]
===
match
---
argument [7657,7676]
argument [7657,7676]
===
match
---
name: date3 [27823,27828]
name: date3 [27823,27828]
===
match
---
name: len [26085,26088]
name: len [26085,26088]
===
match
---
argument [40233,40282]
argument [40233,40282]
===
match
---
simple_stmt [42982,43054]
simple_stmt [42982,43054]
===
match
---
operator: == [64297,64299]
operator: == [64297,64299]
===
match
---
atom_expr [5498,5532]
atom_expr [5498,5532]
===
match
---
expr_stmt [67691,67707]
expr_stmt [67691,67707]
===
match
---
funcdef [18518,19785]
funcdef [18518,19785]
===
match
---
atom_expr [47200,47212]
atom_expr [47200,47212]
===
match
---
operator: , [54626,54627]
operator: , [54626,54627]
===
match
---
name: task [22158,22162]
name: task [22158,22162]
===
match
---
number: 0 [18964,18965]
number: 0 [18964,18965]
===
match
---
name: DEFAULT_DATE [66612,66624]
name: DEFAULT_DATE [66612,66624]
===
match
---
decorated [3437,3661]
decorated [3437,3661]
===
match
---
simple_stmt [995,1009]
simple_stmt [995,1009]
===
match
---
argument [20223,20264]
argument [20223,20264]
===
match
---
arglist [43626,43674]
arglist [43626,43674]
===
match
---
name: op4 [7709,7712]
name: op4 [7709,7712]
===
match
---
arglist [30922,30936]
arglist [30922,30936]
===
match
---
operator: = [17474,17475]
operator: = [17474,17475]
===
match
---
name: dag [43103,43106]
name: dag [43103,43106]
===
match
---
simple_stmt [44260,44286]
simple_stmt [44260,44286]
===
match
---
name: start_date [76281,76291]
name: start_date [76281,76291]
===
match
---
trailer [47775,47789]
trailer [47775,47789]
===
match
---
name: owner [23639,23644]
name: owner [23639,23644]
===
match
---
trailer [3828,3839]
trailer [3828,3839]
===
match
---
name: DummyOperator [38537,38550]
name: DummyOperator [38537,38550]
===
match
---
string: 'task' [44722,44728]
string: 'task' [44722,44728]
===
match
---
string: 'dummy_op' [66479,66489]
string: 'dummy_op' [66479,66489]
===
match
---
comparison [16710,16750]
comparison [16710,16750]
===
match
---
string: 'test_run_pooling_task' [14724,14747]
string: 'test_run_pooling_task' [14724,14747]
===
match
---
name: task_instance_b [75773,75788]
name: task_instance_b [75773,75788]
===
match
---
operator: , [1463,1464]
operator: , [1463,1464]
===
match
---
name: ret [52740,52743]
name: ret [52740,52743]
===
match
---
name: ti [49868,49870]
name: ti [49868,49870]
===
match
---
simple_stmt [76473,76508]
simple_stmt [76473,76508]
===
match
---
expr_stmt [57266,57310]
expr_stmt [57266,57310]
===
match
---
atom_expr [77237,77252]
atom_expr [77237,77252]
===
match
---
decorator [66200,66229]
decorator [66200,66229]
===
match
---
suite [75668,75877]
suite [75668,75877]
===
match
---
number: 0 [31755,31756]
number: 0 [31755,31756]
===
match
---
trailer [67412,67414]
trailer [67412,67414]
===
match
---
string: 'html_content_template' [48795,48818]
string: 'html_content_template' [48795,48818]
===
match
---
operator: , [14955,14956]
operator: , [14955,14956]
===
match
---
operator: = [39048,39049]
operator: = [39048,39049]
===
match
---
operator: = [31220,31221]
operator: = [31220,31221]
===
match
---
number: 0 [33372,33373]
number: 0 [33372,33373]
===
match
---
name: add [9490,9493]
name: add [9490,9493]
===
match
---
string: 'airflow' [14946,14955]
string: 'airflow' [14946,14955]
===
match
---
trailer [21696,21708]
trailer [21696,21708]
===
match
---
name: state [66675,66680]
name: state [66675,66680]
===
match
---
atom_expr [52323,52373]
atom_expr [52323,52373]
===
match
---
name: DAG [41409,41412]
name: DAG [41409,41412]
===
match
---
name: TI [68662,68664]
name: TI [68662,68664]
===
match
---
name: stats_mock [66259,66269]
name: stats_mock [66259,66269]
===
match
---
argument [21697,21707]
argument [21697,21707]
===
match
---
name: query [46787,46792]
name: query [46787,46792]
===
match
---
param [58460,58464]
param [58460,58464]
===
match
---
number: 5 [32291,32292]
number: 5 [32291,32292]
===
match
---
trailer [69058,69113]
trailer [69058,69113]
===
match
---
name: timezone [14161,14169]
name: timezone [14161,14169]
===
match
---
atom_expr [52598,52617]
atom_expr [52598,52617]
===
match
---
name: pool [77190,77194]
name: pool [77190,77194]
===
match
---
name: dag [15978,15981]
name: dag [15978,15981]
===
match
---
name: self [68159,68163]
name: self [68159,68163]
===
match
---
name: SUCCESS [12905,12912]
name: SUCCESS [12905,12912]
===
match
---
name: ti2 [62561,62564]
name: ti2 [62561,62564]
===
match
---
name: timezone [22233,22241]
name: timezone [22233,22241]
===
match
---
number: 1 [9774,9775]
number: 1 [9774,9775]
===
match
---
operator: , [48495,48496]
operator: , [48495,48496]
===
match
---
name: error_message [75862,75875]
name: error_message [75862,75875]
===
match
---
trailer [7728,7773]
trailer [7728,7773]
===
match
---
name: ti [51468,51470]
name: ti [51468,51470]
===
match
---
name: task [43062,43066]
name: task [43062,43066]
===
match
---
funcdef [24290,24388]
funcdef [24290,24388]
===
match
---
operator: = [19156,19157]
operator: = [19156,19157]
===
match
---
suite [44497,45465]
suite [44497,45465]
===
match
---
trailer [3134,3140]
trailer [3134,3140]
===
match
---
expr_stmt [44120,44190]
expr_stmt [44120,44190]
===
match
---
trailer [52976,53012]
trailer [52976,53012]
===
match
---
operator: , [50275,50276]
operator: , [50275,50276]
===
match
---
name: execution_date [25047,25061]
name: execution_date [25047,25061]
===
match
---
operator: + [50624,50625]
operator: + [50624,50625]
===
match
---
expr_stmt [38400,38416]
expr_stmt [38400,38416]
===
match
---
operator: , [959,960]
operator: , [959,960]
===
match
---
atom_expr [20665,20683]
atom_expr [20665,20683]
===
match
---
name: owner [16226,16231]
name: owner [16226,16231]
===
match
---
trailer [3381,3387]
trailer [3381,3387]
===
match
---
operator: , [51122,51123]
operator: , [51122,51123]
===
match
---
name: DummyOperator [47449,47462]
name: DummyOperator [47449,47462]
===
match
---
operator: , [33860,33861]
operator: , [33860,33861]
===
match
---
name: task1 [61620,61625]
name: task1 [61620,61625]
===
match
---
arglist [65282,65313]
arglist [65282,65313]
===
match
---
name: ti [25931,25933]
name: ti [25931,25933]
===
match
---
operator: } [15597,15598]
operator: } [15597,15598]
===
match
---
name: task_id [71031,71038]
name: task_id [71031,71038]
===
match
---
name: self [42078,42082]
name: self [42078,42082]
===
match
---
operator: = [78691,78692]
operator: = [78691,78692]
===
match
---
name: _run_raw_task [51291,51304]
name: _run_raw_task [51291,51304]
===
match
---
trailer [62770,62773]
trailer [62770,62773]
===
match
---
atom_expr [55455,55468]
atom_expr [55455,55468]
===
match
---
name: session [10761,10768]
name: session [10761,10768]
===
match
---
expr_stmt [8625,8679]
expr_stmt [8625,8679]
===
match
---
arglist [66214,66227]
arglist [66214,66227]
===
match
---
comparison [48628,48654]
comparison [48628,48654]
===
match
---
operator: = [5519,5520]
operator: = [5519,5520]
===
match
---
name: scenario [53430,53438]
name: scenario [53430,53438]
===
match
---
trailer [8822,8838]
trailer [8822,8838]
===
match
---
argument [34913,34944]
argument [34913,34944]
===
match
---
atom_expr [38537,38737]
atom_expr [38537,38737]
===
match
---
operator: = [68281,68282]
operator: = [68281,68282]
===
match
---
trailer [49054,49234]
trailer [49054,49234]
===
match
---
atom_expr [37083,37145]
atom_expr [37083,37145]
===
match
---
argument [11334,11341]
argument [11334,11341]
===
match
---
suite [2753,2943]
suite [2753,2943]
===
match
---
atom_expr [40638,40681]
atom_expr [40638,40681]
===
match
---
name: retries [28602,28609]
name: retries [28602,28609]
===
match
---
trailer [34557,34572]
trailer [34557,34572]
===
match
---
dotted_name [2142,2163]
dotted_name [2142,2163]
===
match
---
atom_expr [37160,37200]
atom_expr [37160,37200]
===
match
---
comparison [4380,4412]
comparison [4380,4412]
===
match
---
name: dag [18304,18307]
name: dag [18304,18307]
===
match
---
argument [17060,17108]
argument [17060,17108]
===
match
---
name: dag [23618,23621]
name: dag [23618,23621]
===
match
---
arglist [3778,3803]
arglist [3778,3803]
===
match
---
operator: = [57125,57126]
operator: = [57125,57126]
===
match
---
trailer [30565,30668]
trailer [30565,30668]
===
match
---
operator: = [22816,22817]
operator: = [22816,22817]
===
match
---
name: run_type [52047,52055]
name: run_type [52047,52055]
===
match
---
atom_expr [12429,12451]
atom_expr [12429,12451]
===
match
---
name: dag [13931,13934]
name: dag [13931,13934]
===
match
---
trailer [58315,58317]
trailer [58315,58317]
===
match
---
name: ti [21418,21420]
name: ti [21418,21420]
===
match
---
name: self [24075,24079]
name: self [24075,24079]
===
match
---
simple_stmt [51026,51206]
simple_stmt [51026,51206]
===
match
---
operator: = [24700,24701]
operator: = [24700,24701]
===
match
---
name: task [9307,9311]
name: task [9307,9311]
===
match
---
name: schedule_interval [53249,53266]
name: schedule_interval [53249,53266]
===
match
---
name: SCHEDULED [30884,30893]
name: SCHEDULED [30884,30893]
===
match
---
operator: , [69402,69403]
operator: , [69402,69403]
===
match
---
trailer [17929,17933]
trailer [17929,17933]
===
match
---
comparison [20946,20964]
comparison [20946,20964]
===
match
---
trailer [61239,61241]
trailer [61239,61241]
===
match
---
name: session [60945,60952]
name: session [60945,60952]
===
match
---
operator: = [38197,38198]
operator: = [38197,38198]
===
match
---
name: dag_id [12946,12952]
name: dag_id [12946,12952]
===
match
---
funcdef [27982,30425]
funcdef [27982,30425]
===
match
---
argument [79323,79352]
argument [79323,79352]
===
match
---
name: State [53336,53341]
name: State [53336,53341]
===
match
---
trailer [33574,33582]
trailer [33574,33582]
===
match
---
operator: , [71398,71399]
operator: , [71398,71399]
===
match
---
trailer [4762,4771]
trailer [4762,4771]
===
match
---
dotted_name [2289,2304]
dotted_name [2289,2304]
===
match
---
comparison [29734,29766]
comparison [29734,29766]
===
match
---
dictorsetmaker [70166,70632]
dictorsetmaker [70166,70632]
===
match
---
trailer [52489,52498]
trailer [52489,52498]
===
match
---
string: """     These tests are designed to detect changes in the number of queries executed     when calling _run_raw_task     """ [77561,77684]
string: """     These tests are designed to detect changes in the number of queries executed     when calling _run_raw_task     """ [77561,77684]
===
match
---
name: State [13565,13570]
name: State [13565,13570]
===
match
---
name: content [57955,57962]
name: content [57955,57962]
===
match
---
name: op3 [8819,8822]
name: op3 [8819,8822]
===
match
---
simple_stmt [77785,77804]
simple_stmt [77785,77804]
===
match
---
argument [37488,37499]
argument [37488,37499]
===
match
---
name: ti [64300,64302]
name: ti [64300,64302]
===
match
---
name: TI [78381,78383]
name: TI [78381,78383]
===
match
---
arglist [41509,41704]
arglist [41509,41704]
===
match
---
operator: { [72798,72799]
operator: { [72798,72799]
===
match
---
name: dag_id [67463,67469]
name: dag_id [67463,67469]
===
match
---
trailer [52066,52076]
trailer [52066,52076]
===
match
---
trailer [56652,56660]
trailer [56652,56660]
===
match
---
trailer [53841,53849]
trailer [53841,53849]
===
match
---
argument [78283,78306]
argument [78283,78306]
===
match
---
name: clear_db_pools [3509,3523]
name: clear_db_pools [3509,3523]
===
match
---
name: test_set_state_up_for_retry [75984,76011]
name: test_set_state_up_for_retry [75984,76011]
===
match
---
trailer [43794,43840]
trailer [43794,43840]
===
match
---
name: task [57217,57221]
name: task [57217,57221]
===
match
---
name: expect_completed [35122,35138]
name: expect_completed [35122,35138]
===
match
---
simple_stmt [41474,41715]
simple_stmt [41474,41715]
===
match
---
simple_stmt [68234,68304]
simple_stmt [68234,68304]
===
match
---
simple_stmt [66162,66195]
simple_stmt [66162,66195]
===
match
---
testlist_comp [32879,32934]
testlist_comp [32879,32934]
===
match
---
trailer [51114,51122]
trailer [51114,51122]
===
match
---
trailer [17590,17594]
trailer [17590,17594]
===
match
---
number: 1 [24008,24009]
number: 1 [24008,24009]
===
match
---
operator: , [20209,20210]
operator: , [20209,20210]
===
match
---
simple_stmt [28420,28821]
simple_stmt [28420,28821]
===
match
---
atom_expr [50263,50316]
atom_expr [50263,50316]
===
match
---
trailer [56938,56942]
trailer [56938,56942]
===
match
---
try_stmt [49452,49540]
try_stmt [49452,49540]
===
match
---
trailer [21329,21333]
trailer [21329,21333]
===
match
---
name: task_id [8578,8585]
name: task_id [8578,8585]
===
match
---
name: set_downstream [34558,34572]
name: set_downstream [34558,34572]
===
match
---
atom_expr [48001,48019]
atom_expr [48001,48019]
===
match
---
operator: { [67106,67107]
operator: { [67106,67107]
===
match
---
name: ti [20457,20459]
name: ti [20457,20459]
===
match
---
name: ti [31119,31121]
name: ti [31119,31121]
===
match
---
name: task_b [75032,75038]
name: task_b [75032,75038]
===
match
---
operator: = [51715,51716]
operator: = [51715,51716]
===
match
---
number: 3 [20963,20964]
number: 3 [20963,20964]
===
match
---
name: DummyOperator [63034,63047]
name: DummyOperator [63034,63047]
===
match
---
string: "DummyOperator" [80297,80312]
string: "DummyOperator" [80297,80312]
===
match
---
arglist [55281,55317]
arglist [55281,55317]
===
match
---
trailer [37033,37040]
trailer [37033,37040]
===
match
---
name: schedule_interval [53764,53781]
name: schedule_interval [53764,53781]
===
match
---
and_test [4380,4445]
and_test [4380,4445]
===
match
---
name: scenario [54628,54636]
name: scenario [54628,54636]
===
match
---
number: 1 [20763,20764]
number: 1 [20763,20764]
===
match
---
name: seconds [28656,28663]
name: seconds [28656,28663]
===
match
---
atom_expr [61890,61899]
atom_expr [61890,61899]
===
match
---
operator: , [27034,27035]
operator: , [27034,27035]
===
match
---
operator: , [58998,58999]
operator: , [58998,58999]
===
match
---
simple_stmt [16135,16372]
simple_stmt [16135,16372]
===
match
---
comparison [37861,37876]
comparison [37861,37876]
===
match
---
number: 1 [15011,15012]
number: 1 [15011,15012]
===
match
---
operator: , [57962,57963]
operator: , [57962,57963]
===
match
---
expr_stmt [38784,38828]
expr_stmt [38784,38828]
===
match
---
number: 0 [30238,30239]
number: 0 [30238,30239]
===
match
---
argument [39095,39115]
argument [39095,39115]
===
match
---
expr_stmt [5486,5532]
expr_stmt [5486,5532]
===
match
---
simple_stmt [44387,44412]
simple_stmt [44387,44412]
===
match
---
name: test_execute_queries_count [78133,78159]
name: test_execute_queries_count [78133,78159]
===
match
---
operator: = [17370,17371]
operator: = [17370,17371]
===
match
---
operator: , [73503,73504]
operator: , [73503,73504]
===
match
---
name: create_dagrun [25002,25015]
name: create_dagrun [25002,25015]
===
match
---
atom_expr [57327,57392]
atom_expr [57327,57392]
===
match
---
trailer [23995,23999]
trailer [23995,23999]
===
match
---
name: key [40673,40676]
name: key [40673,40676]
===
match
---
trailer [17558,17568]
trailer [17558,17568]
===
match
---
fstring_start: f' [67082,67084]
fstring_start: f' [67082,67084]
===
match
---
arglist [46623,46644]
arglist [46623,46644]
===
match
---
atom_expr [17588,17613]
atom_expr [17588,17613]
===
match
---
trailer [13456,13460]
trailer [13456,13460]
===
match
---
trailer [58201,58216]
trailer [58201,58216]
===
match
---
operator: = [44329,44330]
operator: = [44329,44330]
===
match
---
atom_expr [44387,44395]
atom_expr [44387,44395]
===
match
---
name: ti [51315,51317]
name: ti [51315,51317]
===
match
---
atom_expr [47490,47543]
atom_expr [47490,47543]
===
match
---
operator: = [15399,15400]
operator: = [15399,15400]
===
match
---
atom_expr [74899,74914]
atom_expr [74899,74914]
===
match
---
comparison [19351,19369]
comparison [19351,19369]
===
match
---
name: ti [50258,50260]
name: ti [50258,50260]
===
match
---
simple_stmt [60408,60424]
simple_stmt [60408,60424]
===
match
---
name: patch [48864,48869]
name: patch [48864,48869]
===
match
---
operator: , [9274,9275]
operator: , [9274,9275]
===
match
---
atom_expr [44432,44445]
atom_expr [44432,44445]
===
match
---
name: task_id [63061,63068]
name: task_id [63061,63068]
===
match
---
operator: = [65962,65963]
operator: = [65962,65963]
===
match
---
operator: , [35440,35441]
operator: , [35440,35441]
===
match
---
expr_stmt [58614,58649]
expr_stmt [58614,58649]
===
match
---
argument [66539,66583]
argument [66539,66583]
===
match
---
name: dag [8143,8146]
name: dag [8143,8146]
===
match
---
name: start_date [29629,29639]
name: start_date [29629,29639]
===
match
---
trailer [51861,51911]
trailer [51861,51911]
===
match
---
name: RUNNING [15840,15847]
name: RUNNING [15840,15847]
===
match
---
operator: , [40490,40491]
operator: , [40490,40491]
===
match
---
name: schedule_interval [53931,53948]
name: schedule_interval [53931,53948]
===
match
---
simple_stmt [9822,9921]
simple_stmt [9822,9921]
===
match
---
argument [11536,11554]
argument [11536,11554]
===
match
---
arglist [58667,58705]
arglist [58667,58705]
===
match
---
argument [26314,26323]
argument [26314,26323]
===
match
---
operator: , [76588,76589]
operator: , [76588,76589]
===
match
---
name: dag_id [9050,9056]
name: dag_id [9050,9056]
===
match
---
argument [52123,52152]
argument [52123,52152]
===
match
---
name: dag [12929,12932]
name: dag [12929,12932]
===
match
---
operator: = [24462,24463]
operator: = [24462,24463]
===
match
---
exprlist [12194,12231]
exprlist [12194,12231]
===
match
---
trailer [29304,29306]
trailer [29304,29306]
===
match
---
string: 'test' [8538,8544]
string: 'test' [8538,8544]
===
match
---
name: ti2 [62594,62597]
name: ti2 [62594,62597]
===
match
---
operator: , [72869,72870]
operator: , [72869,72870]
===
match
---
operator: = [11227,11228]
operator: = [11227,11228]
===
match
---
operator: = [79981,79982]
operator: = [79981,79982]
===
match
---
suite [20502,20524]
suite [20502,20524]
===
match
---
string: 'test_pendulum_template_dates' [56963,56993]
string: 'test_pendulum_template_dates' [56963,56993]
===
match
---
string: 'all_done' [33781,33791]
string: 'all_done' [33781,33791]
===
match
---
name: execution_date [17478,17492]
name: execution_date [17478,17492]
===
match
---
operator: , [36076,36077]
operator: , [36076,36077]
===
match
---
operator: = [12952,12953]
operator: = [12952,12953]
===
match
---
trailer [47627,47641]
trailer [47627,47641]
===
match
---
trailer [41691,41703]
trailer [41691,41703]
===
match
---
operator: , [30893,30894]
operator: , [30893,30894]
===
match
---
atom [8351,8361]
atom [8351,8361]
===
match
---
name: utcnow [9337,9343]
name: utcnow [9337,9343]
===
match
---
name: session [66900,66907]
name: session [66900,66907]
===
match
---
name: raises [8294,8300]
name: raises [8294,8300]
===
match
---
trailer [60667,60677]
trailer [60667,60677]
===
match
---
name: ti [15689,15691]
name: ti [15689,15691]
===
match
---
simple_stmt [50028,50076]
simple_stmt [50028,50076]
===
match
---
name: dag [60983,60986]
name: dag [60983,60986]
===
match
---
operator: , [33672,33673]
operator: , [33672,33673]
===
match
---
with_item [13404,13431]
with_item [13404,13431]
===
match
---
operator: = [4871,4872]
operator: = [4871,4872]
===
match
---
name: get_template_context [59789,59809]
name: get_template_context [59789,59809]
===
match
---
name: state [63326,63331]
name: state [63326,63331]
===
match
---
trailer [10780,10787]
trailer [10780,10787]
===
match
---
name: query [46701,46706]
name: query [46701,46706]
===
match
---
name: ti_list [54883,54890]
name: ti_list [54883,54890]
===
match
---
operator: , [80221,80222]
operator: , [80221,80222]
===
match
---
atom_expr [38758,38775]
atom_expr [38758,38775]
===
match
---
name: clear_db_dags [77788,77801]
name: clear_db_dags [77788,77801]
===
match
---
operator: , [34513,34514]
operator: , [34513,34514]
===
match
---
atom_expr [17512,17525]
atom_expr [17512,17525]
===
match
---
operator: = [3782,3783]
operator: = [3782,3783]
===
match
---
atom_expr [49376,49438]
atom_expr [49376,49438]
===
match
---
name: FAILED [20889,20895]
name: FAILED [20889,20895]
===
match
---
string: 'test_xcom' [40128,40139]
string: 'test_xcom' [40128,40139]
===
match
---
name: self [49786,49790]
name: self [49786,49790]
===
match
---
trailer [77801,77803]
trailer [77801,77803]
===
match
---
name: DEFAULT_DATE [5919,5931]
name: DEFAULT_DATE [5919,5931]
===
match
---
operator: = [18627,18628]
operator: = [18627,18628]
===
match
---
operator: = [66648,66649]
operator: = [66648,66649]
===
match
---
name: owner [4190,4195]
name: owner [4190,4195]
===
match
---
name: value [39316,39321]
name: value [39316,39321]
===
match
---
suite [29256,29411]
suite [29256,29411]
===
match
---
name: op1 [76077,76080]
name: op1 [76077,76080]
===
match
---
name: second_run_state [75844,75860]
name: second_run_state [75844,75860]
===
match
---
name: test_previous_start_date_success [55072,55104]
name: test_previous_start_date_success [55072,55104]
===
match
---
argument [76762,76774]
argument [76762,76774]
===
match
---
testlist_comp [67346,67414]
testlist_comp [67346,67414]
===
match
---
operator: , [18856,18857]
operator: , [18856,18857]
===
match
---
expr_stmt [14700,14748]
expr_stmt [14700,14748]
===
match
---
name: dag [38597,38600]
name: dag [38597,38600]
===
match
---
operator: , [49424,49425]
operator: , [49424,49425]
===
match
---
operator: , [79039,79040]
operator: , [79039,79040]
===
match
---
expr_stmt [62938,62974]
expr_stmt [62938,62974]
===
match
---
number: 2018 [50004,50008]
number: 2018 [50004,50008]
===
match
---
dotted_name [66201,66213]
dotted_name [66201,66213]
===
match
---
atom_expr [60144,60169]
atom_expr [60144,60169]
===
match
---
trailer [76482,76493]
trailer [76482,76493]
===
match
---
name: timezone [17401,17409]
name: timezone [17401,17409]
===
match
---
param [56911,56915]
param [56911,56915]
===
match
---
name: State [71837,71842]
name: State [71837,71842]
===
match
---
simple_stmt [25756,25804]
simple_stmt [25756,25804]
===
match
---
name: BashOperator [71018,71030]
name: BashOperator [71018,71030]
===
match
---
operator: , [32977,32978]
operator: , [32977,32978]
===
match
---
name: isoformat [65188,65197]
name: isoformat [65188,65197]
===
match
---
trailer [57435,57458]
trailer [57435,57458]
===
match
---
operator: = [71569,71570]
operator: = [71569,71570]
===
match
---
suite [3018,3388]
suite [3018,3388]
===
match
---
number: 2 [28795,28796]
number: 2 [28795,28796]
===
match
---
operator: = [58642,58643]
operator: = [58642,58643]
===
match
---
number: 1 [7120,7121]
number: 1 [7120,7121]
===
match
---
atom_expr [25495,25503]
atom_expr [25495,25503]
===
match
---
operator: , [33693,33694]
operator: , [33693,33694]
===
match
---
trailer [3421,3430]
trailer [3421,3430]
===
match
---
operator: = [79142,79143]
operator: = [79142,79143]
===
match
---
simple_stmt [64933,64971]
simple_stmt [64933,64971]
===
match
---
name: ti_list [54128,54135]
name: ti_list [54128,54135]
===
match
---
operator: = [42680,42681]
operator: = [42680,42681]
===
match
---
operator: = [47831,47832]
operator: = [47831,47832]
===
match
---
operator: = [46707,46708]
operator: = [46707,46708]
===
match
---
import_from [2102,2136]
import_from [2102,2136]
===
match
---
name: datetime [6070,6078]
name: datetime [6070,6078]
===
match
---
name: models [24403,24409]
name: models [24403,24409]
===
match
---
operator: == [18501,18503]
operator: == [18501,18503]
===
match
---
name: ti [22145,22147]
name: ti [22145,22147]
===
match
---
operator: , [33376,33377]
operator: , [33376,33377]
===
match
---
name: RUNNING [13571,13578]
name: RUNNING [13571,13578]
===
match
---
arglist [17460,17569]
arglist [17460,17569]
===
match
---
operator: , [11341,11342]
operator: , [11341,11342]
===
match
---
operator: { [72662,72663]
operator: { [72662,72663]
===
match
---
name: naive_datetime [5374,5388]
name: naive_datetime [5374,5388]
===
match
---
name: dag [50487,50490]
name: dag [50487,50490]
===
match
---
arglist [61655,61815]
arglist [61655,61815]
===
match
---
atom [59566,59583]
atom [59566,59583]
===
match
---
operator: = [52659,52660]
operator: = [52659,52660]
===
match
---
number: 0 [53653,53654]
number: 0 [53653,53654]
===
match
---
name: self [53370,53374]
name: self [53370,53374]
===
match
---
string: 'test_not_requeue_non_requeueable_task_instance' [11054,11102]
string: 'test_not_requeue_non_requeueable_task_instance' [11054,11102]
===
match
---
atom_expr [20871,20879]
atom_expr [20871,20879]
===
match
---
name: pendulum [22215,22223]
name: pendulum [22215,22223]
===
match
---
assert_stmt [49703,49758]
assert_stmt [49703,49758]
===
match
---
string: 'test_task_start_end_stats' [66303,66330]
string: 'test_task_start_end_stats' [66303,66330]
===
match
---
trailer [66806,66812]
trailer [66806,66812]
===
match
---
argument [34524,34539]
argument [34524,34539]
===
match
---
name: environ [65206,65213]
name: environ [65206,65213]
===
match
---
name: run [20460,20463]
name: run [20460,20463]
===
match
---
name: execution_date [69225,69239]
name: execution_date [69225,69239]
===
match
---
arglist [18335,18444]
arglist [18335,18444]
===
match
---
name: State [45134,45139]
name: State [45134,45139]
===
match
---
name: start_date [4542,4552]
name: start_date [4542,4552]
===
match
---
number: 2016 [18203,18207]
number: 2016 [18203,18207]
===
match
---
argument [8532,8544]
argument [8532,8544]
===
match
---
param [29082,29100]
param [29082,29100]
===
match
---
string: """         Test that post_execute hook is called with the Operator's result.         The result ('error') will cause an error to be raised and trapped.         """ [42093,42257]
string: """         Test that post_execute hook is called with the Operator's result.         The result ('error') will cause an error to be raised and trapped.         """ [42093,42257]
===
match
---
atom [72662,72692]
atom [72662,72692]
===
match
---
trailer [68389,68391]
trailer [68389,68391]
===
match
---
funcdef [46465,46999]
funcdef [46465,46999]
===
match
---
name: TI [62511,62513]
name: TI [62511,62513]
===
match
---
name: add [10867,10870]
name: add [10867,10870]
===
match
---
argument [78550,78582]
argument [78550,78582]
===
match
---
operator: = [79377,79378]
operator: = [79377,79378]
===
match
---
operator: , [34078,34079]
operator: , [34078,34079]
===
match
---
assert_stmt [80271,80312]
assert_stmt [80271,80312]
===
match
---
operator: = [48276,48277]
operator: = [48276,48277]
===
match
---
name: success_handler [2952,2967]
name: success_handler [2952,2967]
===
match
---
atom [12067,12116]
atom [12067,12116]
===
match
---
operator: = [61433,61434]
operator: = [61433,61434]
===
match
---
name: task [57120,57124]
name: task [57120,57124]
===
match
---
operator: , [14236,14237]
operator: , [14236,14237]
===
match
---
name: asserts [2412,2419]
name: asserts [2412,2419]
===
match
---
trailer [36096,36103]
trailer [36096,36103]
===
match
---
name: RUNNING [51115,51122]
name: RUNNING [51115,51122]
===
match
---
simple_stmt [37665,37699]
simple_stmt [37665,37699]
===
match
---
atom_expr [57505,57544]
atom_expr [57505,57544]
===
match
---
parameters [2967,2982]
parameters [2967,2982]
===
match
---
name: task_a [74803,74809]
name: task_a [74803,74809]
===
match
---
atom_expr [27266,27280]
atom_expr [27266,27280]
===
match
---
name: task [43154,43158]
name: task [43154,43158]
===
match
---
operator: , [64729,64730]
operator: , [64729,64730]
===
match
---
operator: , [59053,59054]
operator: , [59053,59054]
===
match
---
expr_stmt [20065,20390]
expr_stmt [20065,20390]
===
match
---
trailer [57253,57255]
trailer [57253,57255]
===
match
---
trailer [18193,18202]
trailer [18193,18202]
===
match
---
comparison [46863,46890]
comparison [46863,46890]
===
match
---
trailer [15635,15644]
trailer [15635,15644]
===
match
---
name: pool_override [77049,77062]
name: pool_override [77049,77062]
===
match
---
arglist [34242,34261]
arglist [34242,34261]
===
match
---
trailer [43625,43675]
trailer [43625,43675]
===
match
---
name: SKIPPED [32920,32927]
name: SKIPPED [32920,32927]
===
match
---
suite [20423,20524]
suite [20423,20524]
===
match
---
operator: == [49686,49688]
operator: == [49686,49688]
===
match
---
operator: == [21272,21274]
operator: == [21272,21274]
===
match
---
trailer [38791,38828]
trailer [38791,38828]
===
match
---
atom_expr [12267,12292]
atom_expr [12267,12292]
===
match
---
name: successes [34834,34843]
name: successes [34834,34843]
===
match
---
name: State [64940,64945]
name: State [64940,64945]
===
match
---
name: DAG [68516,68519]
name: DAG [68516,68519]
===
match
---
operator: , [33438,33439]
operator: , [33438,33439]
===
match
---
comparison [17629,17654]
comparison [17629,17654]
===
match
---
number: 0 [22117,22118]
number: 0 [22117,22118]
===
match
---
number: 0 [6094,6095]
number: 0 [6094,6095]
===
match
---
name: State [54865,54870]
name: State [54865,54870]
===
match
---
operator: , [73261,73262]
operator: , [73261,73262]
===
match
---
name: task_ids [39695,39703]
name: task_ids [39695,39703]
===
match
---
operator: = [16384,16385]
operator: = [16384,16385]
===
match
---
trailer [51451,51459]
trailer [51451,51459]
===
match
---
atom_expr [27063,27127]
atom_expr [27063,27127]
===
match
---
operator: = [47181,47182]
operator: = [47181,47182]
===
match
---
simple_stmt [7511,7566]
simple_stmt [7511,7566]
===
match
---
name: dag [40157,40160]
name: dag [40157,40160]
===
match
---
name: values [12555,12561]
name: values [12555,12561]
===
match
---
argument [74147,74178]
argument [74147,74178]
===
match
---
name: overwrite_params_with_dag_run_conf [47933,47967]
name: overwrite_params_with_dag_run_conf [47933,47967]
===
match
---
name: _ [49571,49572]
name: _ [49571,49572]
===
match
---
trailer [17416,17418]
trailer [17416,17418]
===
match
---
trailer [78498,78502]
trailer [78498,78502]
===
match
---
operator: , [13268,13269]
operator: , [13268,13269]
===
match
---
operator: = [68579,68580]
operator: = [68579,68580]
===
match
---
atom_expr [56540,56553]
atom_expr [56540,56553]
===
match
---
atom_expr [64300,64308]
atom_expr [64300,64308]
===
match
---
atom_expr [79133,79141]
atom_expr [79133,79141]
===
match
---
expr_stmt [60134,60169]
expr_stmt [60134,60169]
===
match
---
param [43510,43514]
param [43510,43514]
===
match
---
arglist [21795,22126]
arglist [21795,22126]
===
match
---
atom_expr [27913,27976]
atom_expr [27913,27976]
===
match
---
argument [60853,60862]
argument [60853,60862]
===
match
---
operator: , [32610,32611]
operator: , [32610,32611]
===
match
---
name: success_handler [50806,50821]
name: success_handler [50806,50821]
===
match
---
operator: , [31697,31698]
operator: , [31697,31698]
===
match
---
atom_expr [53556,53581]
atom_expr [53556,53581]
===
match
---
operator: , [38490,38491]
operator: , [38490,38491]
===
match
---
testlist_star_expr [27043,27054]
testlist_star_expr [27043,27054]
===
match
---
name: DAG [12942,12945]
name: DAG [12942,12945]
===
match
---
number: 10 [50010,50012]
number: 10 [50010,50012]
===
match
---
simple_stmt [42517,42566]
simple_stmt [42517,42566]
===
match
---
operator: = [61662,61663]
operator: = [61662,61663]
===
match
---
with_stmt [78724,78829]
with_stmt [78724,78829]
===
match
---
name: task_id [67830,67837]
name: task_id [67830,67837]
===
match
---
operator: = [16231,16232]
operator: = [16231,16232]
===
match
---
name: urlparse [46757,46765]
name: urlparse [46757,46765]
===
match
---
operator: , [52105,52106]
operator: , [52105,52106]
===
match
---
number: 2 [33793,33794]
number: 2 [33793,33794]
===
match
---
arglist [76153,76216]
arglist [76153,76216]
===
match
---
name: start_date [5197,5207]
name: start_date [5197,5207]
===
match
---
operator: , [8664,8665]
operator: , [8664,8665]
===
match
---
operator: = [10759,10760]
operator: = [10759,10760]
===
match
---
operator: = [21676,21677]
operator: = [21676,21677]
===
match
---
name: run_date [30809,30817]
name: run_date [30809,30817]
===
match
---
argument [40425,40457]
argument [40425,40457]
===
match
---
name: __name__ [77493,77501]
name: __name__ [77493,77501]
===
match
---
name: retry_exponential_backoff [23535,23560]
name: retry_exponential_backoff [23535,23560]
===
match
---
testlist_star_expr [26692,26704]
testlist_star_expr [26692,26704]
===
match
---
name: RUNNING [44337,44344]
name: RUNNING [44337,44344]
===
match
---
trailer [22290,22292]
trailer [22290,22292]
===
match
---
operator: = [13192,13193]
operator: = [13192,13193]
===
match
---
expr_stmt [59720,59767]
expr_stmt [59720,59767]
===
match
---
string: 'D' [75288,75291]
string: 'D' [75288,75291]
===
match
---
name: run_as_user [77327,77338]
name: run_as_user [77327,77338]
===
match
---
comparison [77370,77398]
comparison [77370,77398]
===
match
---
name: duration [29737,29745]
name: duration [29737,29745]
===
match
---
operator: , [53266,53267]
operator: , [53266,53267]
===
match
---
string: 'bar' [15592,15597]
string: 'bar' [15592,15597]
===
match
---
expr_stmt [24268,24280]
expr_stmt [24268,24280]
===
match
---
simple_stmt [38998,39024]
simple_stmt [38998,39024]
===
match
---
operator: , [6083,6084]
operator: , [6083,6084]
===
match
---
operator: , [33699,33700]
operator: , [33699,33700]
===
match
---
name: State [9353,9358]
name: State [9353,9358]
===
match
---
atom_expr [34344,34432]
atom_expr [34344,34432]
===
match
---
name: mark_success [39486,39498]
name: mark_success [39486,39498]
===
match
---
trailer [60053,60068]
trailer [60053,60068]
===
match
---
string: 'hive_in_python_op' [65103,65122]
string: 'hive_in_python_op' [65103,65122]
===
match
---
operator: , [59353,59354]
operator: , [59353,59354]
===
match
---
name: dag2 [7238,7242]
name: dag2 [7238,7242]
===
match
---
name: RUNNING [17518,17525]
name: RUNNING [17518,17525]
===
match
---
operator: , [34298,34299]
operator: , [34298,34299]
===
match
---
string: 'try_number' [69529,69541]
string: 'try_number' [69529,69541]
===
match
---
operator: = [11516,11517]
operator: = [11516,11517]
===
match
---
name: instance [23816,23824]
name: instance [23816,23824]
===
match
---
string: 'C' [75266,75269]
string: 'C' [75266,75269]
===
match
---
name: execution_date [19233,19247]
name: execution_date [19233,19247]
===
match
---
atom_expr [59829,59867]
atom_expr [59829,59867]
===
match
---
simple_stmt [27259,27286]
simple_stmt [27259,27286]
===
match
---
name: State [51516,51521]
name: State [51516,51521]
===
match
---
string: 'task' [43634,43640]
string: 'task' [43634,43640]
===
match
---
arglist [40651,40680]
arglist [40651,40680]
===
match
---
trailer [9336,9343]
trailer [9336,9343]
===
match
---
atom_expr [44622,44684]
atom_expr [44622,44684]
===
match
---
trailer [56389,56397]
trailer [56389,56397]
===
match
---
trailer [8997,9010]
trailer [8997,9010]
===
match
---
arglist [58356,58372]
arglist [58356,58372]
===
match
---
trailer [64860,64862]
trailer [64860,64862]
===
match
---
name: set_duration [50087,50099]
name: set_duration [50087,50099]
===
match
---
operator: , [48502,48503]
operator: , [48502,48503]
===
match
---
operator: , [25357,25358]
operator: , [25357,25358]
===
match
---
simple_stmt [1807,1839]
simple_stmt [1807,1839]
===
match
---
argument [74061,74092]
argument [74061,74092]
===
match
---
parameters [13808,13814]
parameters [13808,13814]
===
match
---
simple_stmt [39143,39152]
simple_stmt [39143,39152]
===
match
---
name: ti [76145,76147]
name: ti [76145,76147]
===
match
---
testlist_comp [35984,36145]
testlist_comp [35984,36145]
===
match
---
operator: = [44924,44925]
operator: = [44924,44925]
===
match
---
name: DAG [44557,44560]
name: DAG [44557,44560]
===
match
---
name: ti [23984,23986]
name: ti [23984,23986]
===
match
---
arglist [13211,13230]
arglist [13211,13230]
===
match
---
operator: , [33561,33562]
operator: , [33561,33562]
===
match
---
simple_stmt [60078,60126]
simple_stmt [60078,60126]
===
match
---
name: context_arg_1 [62013,62026]
name: context_arg_1 [62013,62026]
===
match
---
name: settings [44516,44524]
name: settings [44516,44524]
===
match
---
operator: = [23063,23064]
operator: = [23063,23064]
===
match
---
arglist [57419,57477]
arglist [57419,57477]
===
match
---
simple_stmt [23098,23137]
simple_stmt [23098,23137]
===
match
---
operator: , [33519,33520]
operator: , [33519,33520]
===
match
---
name: get_previous_start_date [55504,55527]
name: get_previous_start_date [55504,55527]
===
match
---
operator: = [27775,27776]
operator: = [27775,27776]
===
match
---
operator: , [78699,78700]
operator: , [78699,78700]
===
match
---
expr_stmt [24867,24919]
expr_stmt [24867,24919]
===
match
---
name: add [70811,70814]
name: add [70811,70814]
===
match
---
name: DEFAULT_DATE [50576,50588]
name: DEFAULT_DATE [50576,50588]
===
match
---
atom_expr [5391,5424]
atom_expr [5391,5424]
===
match
---
trailer [36559,36590]
trailer [36559,36590]
===
match
---
simple_stmt [40998,41057]
simple_stmt [40998,41057]
===
match
---
expr_stmt [42799,42851]
expr_stmt [42799,42851]
===
match
---
name: trigger_rule [34419,34431]
name: trigger_rule [34419,34431]
===
match
---
string: 'base' [70534,70540]
string: 'base' [70534,70540]
===
match
---
name: State [30837,30842]
name: State [30837,30842]
===
match
---
name: session [75740,75747]
name: session [75740,75747]
===
match
---
parameters [19813,19819]
parameters [19813,19819]
===
match
---
parameters [15242,15262]
parameters [15242,15262]
===
match
---
name: State [35985,35990]
name: State [35985,35990]
===
match
---
number: 0 [18961,18962]
number: 0 [18961,18962]
===
match
---
trailer [46520,46524]
trailer [46520,46524]
===
match
---
name: on_retry_callback [62408,62425]
name: on_retry_callback [62408,62425]
===
match
---
name: AirflowException [24345,24361]
name: AirflowException [24345,24361]
===
match
---
number: 5 [33674,33675]
number: 5 [33674,33675]
===
match
---
string: 'B' [72730,72733]
string: 'B' [72730,72733]
===
match
---
operator: , [18081,18082]
operator: , [18081,18082]
===
match
---
operator: = [21802,21803]
operator: = [21802,21803]
===
match
---
trailer [62717,62719]
trailer [62717,62719]
===
match
---
trailer [20603,20614]
trailer [20603,20614]
===
match
---
operator: , [33496,33497]
operator: , [33496,33497]
===
match
---
atom_expr [18185,18223]
atom_expr [18185,18223]
===
match
---
arglist [66539,66731]
arglist [66539,66731]
===
match
---
name: ti [14493,14495]
name: ti [14493,14495]
===
match
---
name: task_id [74134,74141]
name: task_id [74134,74141]
===
match
---
name: create_session [3720,3734]
name: create_session [3720,3734]
===
match
---
name: set [12895,12898]
name: set [12895,12898]
===
match
---
name: CallbackWrapper [2502,2517]
name: CallbackWrapper [2502,2517]
===
match
---
name: xcom_pull [41137,41146]
name: xcom_pull [41137,41146]
===
match
---
atom_expr [52410,52426]
atom_expr [52410,52426]
===
match
---
trailer [50476,50478]
trailer [50476,50478]
===
match
---
argument [18640,18668]
argument [18640,18668]
===
match
---
operator: , [53863,53864]
operator: , [53863,53864]
===
match
---
name: execution_date [60097,60111]
name: execution_date [60097,60111]
===
match
---
name: expected_try_number [25780,25799]
name: expected_try_number [25780,25799]
===
match
---
simple_stmt [6530,6565]
simple_stmt [6530,6565]
===
match
---
simple_stmt [7131,7144]
simple_stmt [7131,7144]
===
match
---
string: """         Test that task reschedules clearing are handled properly         """ [28044,28124]
string: """         Test that task reschedules clearing are handled properly         """ [28044,28124]
===
match
---
simple_stmt [44199,44252]
simple_stmt [44199,44252]
===
match
---
atom_expr [79067,79120]
atom_expr [79067,79120]
===
match
---
testlist_comp [72191,72542]
testlist_comp [72191,72542]
===
match
---
name: models [13937,13943]
name: models [13937,13943]
===
match
---
trailer [26760,26778]
trailer [26760,26778]
===
match
---
number: 1 [32437,32438]
number: 1 [32437,32438]
===
match
---
name: dag [42644,42647]
name: dag [42644,42647]
===
match
---
trailer [15731,15738]
trailer [15731,15738]
===
match
---
number: 0 [32591,32592]
number: 0 [32591,32592]
===
match
---
expr_stmt [44693,44763]
expr_stmt [44693,44763]
===
match
---
name: start_date [7425,7435]
name: start_date [7425,7435]
===
match
---
name: version [69689,69696]
name: version [69689,69696]
===
match
---
name: execution_date [38869,38883]
name: execution_date [38869,38883]
===
match
---
operator: , [53762,53763]
operator: , [53762,53763]
===
match
---
simple_stmt [75229,75272]
simple_stmt [75229,75272]
===
match
---
operator: = [4195,4196]
operator: = [4195,4196]
===
match
---
trailer [17594,17613]
trailer [17594,17613]
===
match
---
operator: = [20261,20262]
operator: = [20261,20262]
===
match
---
expr_stmt [44854,44902]
expr_stmt [44854,44902]
===
match
---
operator: , [74626,74627]
operator: , [74626,74627]
===
match
---
operator: = [6185,6186]
operator: = [6185,6186]
===
match
---
atom_expr [22950,22974]
atom_expr [22950,22974]
===
match
---
trailer [52015,52029]
trailer [52015,52029]
===
match
---
name: RUNNING [56390,56397]
name: RUNNING [56390,56397]
===
match
---
operator: = [69239,69240]
operator: = [69239,69240]
===
match
---
atom_expr [13686,13702]
atom_expr [13686,13702]
===
match
---
expr_stmt [60538,60697]
expr_stmt [60538,60697]
===
match
---
name: MagicMock [62250,62259]
name: MagicMock [62250,62259]
===
match
---
string: 'bar' [37240,37245]
string: 'bar' [37240,37245]
===
match
---
with_stmt [68370,68460]
with_stmt [68370,68460]
===
match
---
expr_stmt [52681,52723]
expr_stmt [52681,52723]
===
match
---
operator: = [79291,79292]
operator: = [79291,79292]
===
match
---
name: ti [23031,23033]
name: ti [23031,23033]
===
match
---
argument [52170,52200]
argument [52170,52200]
===
match
---
operator: , [10535,10536]
operator: , [10535,10536]
===
match
---
name: wrap_task_instance [2724,2742]
name: wrap_task_instance [2724,2742]
===
match
---
name: dag [79041,79044]
name: dag [79041,79044]
===
match
---
operator: , [50842,50843]
operator: , [50842,50843]
===
match
---
atom_expr [53049,53075]
atom_expr [53049,53075]
===
match
---
atom_expr [4568,4594]
atom_expr [4568,4594]
===
match
---
name: set_downstream [8254,8268]
name: set_downstream [8254,8268]
===
match
---
trailer [34455,34458]
trailer [34455,34458]
===
match
---
name: ti [44387,44389]
name: ti [44387,44389]
===
match
---
name: dag_run [75341,75348]
name: dag_run [75341,75348]
===
match
---
trailer [52480,52544]
trailer [52480,52544]
===
match
---
atom_expr [49278,49295]
atom_expr [49278,49295]
===
match
---
trailer [74954,74972]
trailer [74954,74972]
===
match
---
name: dag [44157,44160]
name: dag [44157,44160]
===
match
---
atom_expr [6187,6230]
atom_expr [6187,6230]
===
match
---
operator: = [64128,64129]
operator: = [64128,64129]
===
match
---
operator: { [70574,70575]
operator: { [70574,70575]
===
match
---
name: datetime [60659,60667]
name: datetime [60659,60667]
===
match
---
name: test_template_with_json_variable_missing [59918,59958]
name: test_template_with_json_variable_missing [59918,59958]
===
match
---
name: State [16527,16532]
name: State [16527,16532]
===
match
---
operator: , [33432,33433]
operator: , [33432,33433]
===
match
---
operator: = [79600,79601]
operator: = [79600,79601]
===
match
---
operator: , [25401,25402]
operator: , [25401,25402]
===
match
---
name: execution_date [53567,53581]
name: execution_date [53567,53581]
===
match
---
dotted_name [2363,2379]
dotted_name [2363,2379]
===
match
---
atom_expr [27798,27870]
atom_expr [27798,27870]
===
match
---
name: _env_var_check_callback [64980,65003]
name: _env_var_check_callback [64980,65003]
===
match
---
expr_stmt [56670,56717]
expr_stmt [56670,56717]
===
match
---
simple_stmt [78943,78994]
simple_stmt [78943,78994]
===
match
---
simple_stmt [53889,53969]
simple_stmt [53889,53969]
===
match
---
trailer [10125,10129]
trailer [10125,10129]
===
match
---
operator: = [54160,54161]
operator: = [54160,54161]
===
match
---
string: 'test_xcom' [39291,39302]
string: 'test_xcom' [39291,39302]
===
match
---
name: DummyOperator [62278,62291]
name: DummyOperator [62278,62291]
===
match
---
name: dag [4845,4848]
name: dag [4845,4848]
===
match
---
arglist [35295,35334]
arglist [35295,35334]
===
match
---
name: run [9538,9541]
name: run [9538,9541]
===
match
---
name: try_number [44435,44445]
name: try_number [44435,44445]
===
match
---
param [69035,69039]
param [69035,69039]
===
match
---
operator: = [28583,28584]
operator: = [28583,28584]
===
match
---
operator: , [31750,31751]
operator: , [31750,31751]
===
match
---
arglist [48227,48322]
arglist [48227,48322]
===
match
---
operator: , [71732,71733]
operator: , [71732,71733]
===
match
---
simple_stmt [67925,68066]
simple_stmt [67925,68066]
===
match
---
param [29018,29038]
param [29018,29038]
===
match
---
operator: = [36953,36954]
operator: = [36953,36954]
===
match
---
number: 1 [50014,50015]
number: 1 [50014,50015]
===
match
---
string: 'test' [6882,6888]
string: 'test' [6882,6888]
===
match
---
name: utcnow [40323,40329]
name: utcnow [40323,40329]
===
match
---
operator: @ [3437,3438]
operator: @ [3437,3438]
===
match
---
name: task [6190,6194]
name: task [6190,6194]
===
match
---
operator: , [18953,18954]
operator: , [18953,18954]
===
match
---
expr_stmt [78257,78307]
expr_stmt [78257,78307]
===
match
---
simple_stmt [49609,49630]
simple_stmt [49609,49630]
===
match
---
simple_stmt [10458,10557]
simple_stmt [10458,10557]
===
match
---
name: dag_id [60488,60494]
name: dag_id [60488,60494]
===
match
---
expr_stmt [71154,71195]
expr_stmt [71154,71195]
===
match
---
name: range [34450,34455]
name: range [34450,34455]
===
match
---
argument [30579,30602]
argument [30579,30602]
===
match
---
name: commit [9518,9524]
name: commit [9518,9524]
===
match
---
trailer [2921,2934]
trailer [2921,2934]
===
match
---
atom_expr [11425,11463]
atom_expr [11425,11463]
===
match
---
testlist_comp [33721,33765]
testlist_comp [33721,33765]
===
match
---
operator: , [32509,32510]
operator: , [32509,32510]
===
match
---
trailer [36623,36644]
trailer [36623,36644]
===
match
---
simple_stmt [50191,50250]
simple_stmt [50191,50250]
===
match
---
name: op [7229,7231]
name: op [7229,7231]
===
match
---
string: 'test_email_alert' [48628,48646]
string: 'test_email_alert' [48628,48646]
===
match
---
name: clear_db_sla_miss [77815,77832]
name: clear_db_sla_miss [77815,77832]
===
match
---
arglist [36323,36362]
arglist [36323,36362]
===
match
---
atom_expr [66405,66432]
atom_expr [66405,66432]
===
match
---
trailer [59788,59809]
trailer [59788,59809]
===
match
---
funcdef [33908,35179]
funcdef [33908,35179]
===
match
---
arith_expr [50611,50653]
arith_expr [50611,50653]
===
match
---
trailer [10813,10817]
trailer [10813,10817]
===
match
---
operator: == [77145,77147]
operator: == [77145,77147]
===
match
---
name: self [78160,78164]
name: self [78160,78164]
===
match
---
name: test_xcom_pull_after_success [38254,38282]
name: test_xcom_pull_after_success [38254,38282]
===
match
---
name: owner [7678,7683]
name: owner [7678,7683]
===
match
---
trailer [56629,56647]
trailer [56629,56647]
===
match
---
operator: = [66494,66495]
operator: = [66494,66495]
===
match
---
assert_stmt [38002,38024]
assert_stmt [38002,38024]
===
match
---
atom_expr [77264,77282]
atom_expr [77264,77282]
===
match
---
atom_expr [8973,9010]
atom_expr [8973,9010]
===
match
---
simple_stmt [22201,22252]
simple_stmt [22201,22252]
===
match
---
operator: = [16526,16527]
operator: = [16526,16527]
===
match
---
trailer [30842,30850]
trailer [30842,30850]
===
match
---
atom_expr [50929,50937]
atom_expr [50929,50937]
===
match
---
expr_stmt [7111,7121]
expr_stmt [7111,7121]
===
match
---
arglist [44794,44843]
arglist [44794,44843]
===
match
---
name: run_id [66539,66545]
name: run_id [66539,66545]
===
match
---
atom_expr [20567,20584]
atom_expr [20567,20584]
===
match
---
argument [64550,64586]
argument [64550,64586]
===
match
---
name: task [13264,13268]
name: task [13264,13268]
===
match
---
atom_expr [54654,54713]
atom_expr [54654,54713]
===
match
---
string: 'task' [67313,67319]
string: 'task' [67313,67319]
===
match
---
operator: = [9645,9646]
operator: = [9645,9646]
===
match
---
trailer [62206,62216]
trailer [62206,62216]
===
match
---
name: start_date [60598,60608]
name: start_date [60598,60608]
===
match
---
trailer [44862,44902]
trailer [44862,44902]
===
match
---
string: """         Test that task retries are handled properly         """ [19829,19896]
string: """         Test that task retries are handled properly         """ [19829,19896]
===
match
---
atom_expr [54302,54327]
atom_expr [54302,54327]
===
match
---
comparison [6246,6275]
comparison [6246,6275]
===
match
---
number: 0 [33313,33314]
number: 0 [33313,33314]
===
match
---
name: context_arg_3 [63530,63543]
name: context_arg_3 [63530,63543]
===
match
---
operator: = [50040,50041]
operator: = [50040,50041]
===
match
---
operator: = [71534,71535]
operator: = [71534,71535]
===
match
---
name: call_args [63499,63508]
name: call_args [63499,63508]
===
match
---
name: SerializedBaseOperator [1784,1806]
name: SerializedBaseOperator [1784,1806]
===
match
---
atom_expr [74570,74580]
atom_expr [74570,74580]
===
match
---
name: ti [50862,50864]
name: ti [50862,50864]
===
match
---
atom_expr [28898,28912]
atom_expr [28898,28912]
===
match
---
operator: , [32432,32433]
operator: , [32432,32433]
===
match
---
simple_stmt [50999,51017]
simple_stmt [50999,51017]
===
match
---
param [48108,48113]
param [48108,48113]
===
match
---
operator: , [79796,79797]
operator: , [79796,79797]
===
match
---
atom_expr [6580,6605]
atom_expr [6580,6605]
===
match
---
operator: , [15006,15007]
operator: , [15006,15007]
===
match
---
name: task [46662,46666]
name: task [46662,46666]
===
match
---
trailer [43426,43438]
trailer [43426,43438]
===
match
---
name: Variable [59533,59541]
name: Variable [59533,59541]
===
match
---
arglist [64124,64167]
arglist [64124,64167]
===
match
---
name: State [54018,54023]
name: State [54018,54023]
===
match
---
operator: , [30509,30510]
operator: , [30509,30510]
===
match
---
name: init_state [75477,75487]
name: init_state [75477,75487]
===
match
---
name: State [55534,55539]
name: State [55534,55539]
===
match
---
atom_expr [53370,53439]
atom_expr [53370,53439]
===
match
---
operator: , [60752,60753]
operator: , [60752,60753]
===
match
---
simple_stmt [6325,6376]
simple_stmt [6325,6376]
===
match
---
operator: , [55199,55200]
operator: , [55199,55200]
===
match
---
string: 'AIRFLOW_CTX_DAG_ID' [65066,65086]
string: 'AIRFLOW_CTX_DAG_ID' [65066,65086]
===
match
---
name: pendulum [986,994]
name: pendulum [986,994]
===
match
---
trailer [62670,62672]
trailer [62670,62672]
===
match
---
name: DummyOperator [77479,77492]
name: DummyOperator [77479,77492]
===
match
---
operator: = [22148,22149]
operator: = [22148,22149]
===
match
---
fstring_string: ti.start. [67084,67093]
fstring_string: ti.start. [67084,67093]
===
match
---
operator: , [72644,72645]
operator: , [72644,72645]
===
match
---
trailer [18202,18223]
trailer [18202,18223]
===
match
---
trailer [18845,18856]
trailer [18845,18856]
===
match
---
operator: , [40671,40672]
operator: , [40671,40672]
===
match
---
number: 1 [61418,61419]
number: 1 [61418,61419]
===
match
---
name: task_id [18711,18718]
name: task_id [18711,18718]
===
match
---
number: 0 [36990,36991]
number: 0 [36990,36991]
===
match
---
name: task_id [2767,2774]
name: task_id [2767,2774]
===
match
---
name: timezone [36954,36962]
name: timezone [36954,36962]
===
match
---
trailer [41957,41961]
trailer [41957,41961]
===
match
---
atom_expr [67161,67182]
atom_expr [67161,67182]
===
match
---
name: dag_id [23317,23323]
name: dag_id [23317,23323]
===
match
---
operator: , [4528,4529]
operator: , [4528,4529]
===
match
---
trailer [28900,28912]
trailer [28900,28912]
===
match
---
operator: , [60281,60282]
operator: , [60281,60282]
===
match
---
name: ti [77137,77139]
name: ti [77137,77139]
===
match
---
dictorsetmaker [47875,47892]
dictorsetmaker [47875,47892]
===
match
---
string: 'test' [7621,7627]
string: 'test' [7621,7627]
===
match
---
testlist_comp [67747,67906]
testlist_comp [67747,67906]
===
match
---
name: owner [4516,4521]
name: owner [4516,4521]
===
match
---
trailer [76366,76379]
trailer [76366,76379]
===
match
---
trailer [79615,79638]
trailer [79615,79638]
===
match
---
name: session [52430,52437]
name: session [52430,52437]
===
match
---
name: ti [15797,15799]
name: ti [15797,15799]
===
match
---
atom_expr [13937,13979]
atom_expr [13937,13979]
===
match
---
name: State [26755,26760]
name: State [26755,26760]
===
match
---
name: ti2 [62644,62647]
name: ti2 [62644,62647]
===
match
---
comparison [77137,77161]
comparison [77137,77161]
===
match
---
trailer [75244,75254]
trailer [75244,75254]
===
match
---
simple_stmt [1579,1631]
simple_stmt [1579,1631]
===
match
---
name: dag_id [13948,13954]
name: dag_id [13948,13954]
===
match
---
operator: , [32669,32670]
operator: , [32669,32670]
===
match
---
argument [5565,5594]
argument [5565,5594]
===
match
---
trailer [44532,44534]
trailer [44532,44534]
===
match
---
operator: = [74852,74853]
operator: = [74852,74853]
===
match
---
trailer [16634,16638]
trailer [16634,16638]
===
match
---
atom_expr [43822,43839]
atom_expr [43822,43839]
===
match
---
expr_stmt [11222,11474]
expr_stmt [11222,11474]
===
match
---
name: run_date [29246,29254]
name: run_date [29246,29254]
===
match
---
name: TestError [42479,42488]
name: TestError [42479,42488]
===
match
---
assert_stmt [46899,46933]
assert_stmt [46899,46933]
===
match
---
operator: = [47109,47110]
operator: = [47109,47110]
===
match
---
name: date4 [26279,26284]
name: date4 [26279,26284]
===
match
---
operator: , [31929,31930]
operator: , [31929,31930]
===
match
---
trailer [32305,32313]
trailer [32305,32313]
===
match
---
operator: , [76422,76423]
operator: , [76422,76423]
===
match
---
trailer [76990,77002]
trailer [76990,77002]
===
match
---
funcdef [76605,77502]
funcdef [76605,77502]
===
match
---
operator: , [76697,76698]
operator: , [76697,76698]
===
match
---
simple_stmt [29675,29715]
simple_stmt [29675,29715]
===
match
---
name: ti [48421,48423]
name: ti [48421,48423]
===
match
---
trailer [60914,60920]
trailer [60914,60920]
===
match
---
name: pool [76735,76739]
name: pool [76735,76739]
===
match
---
operator: , [33746,33747]
operator: , [33746,33747]
===
match
---
string: 'dag2' [7469,7475]
string: 'dag2' [7469,7475]
===
match
---
trailer [47592,47627]
trailer [47592,47627]
===
match
---
name: dep [35073,35076]
name: dep [35073,35076]
===
match
---
operator: { [11942,11943]
operator: { [11942,11943]
===
match
---
name: State [71908,71913]
name: State [71908,71913]
===
match
---
simple_stmt [14700,14749]
simple_stmt [14700,14749]
===
match
---
operator: = [45132,45133]
operator: = [45132,45133]
===
match
---
simple_stmt [38298,38392]
simple_stmt [38298,38392]
===
match
---
operator: = [73742,73743]
operator: = [73742,73743]
===
match
---
atom_expr [29888,29896]
atom_expr [29888,29896]
===
match
---
atom [57615,57661]
atom [57615,57661]
===
match
---
expr_stmt [67424,67523]
expr_stmt [67424,67523]
===
match
---
argument [21854,21875]
argument [21854,21875]
===
match
---
atom_expr [23065,23089]
atom_expr [23065,23089]
===
match
---
atom_expr [30051,30074]
atom_expr [30051,30074]
===
match
---
operator: , [24531,24532]
operator: , [24531,24532]
===
match
---
string: 'test@test.test' [50739,50755]
string: 'test@test.test' [50739,50755]
===
match
---
number: 5 [33301,33302]
number: 5 [33301,33302]
===
match
---
number: 1 [45336,45337]
number: 1 [45336,45337]
===
match
---
atom_expr [32372,32393]
atom_expr [32372,32393]
===
match
---
simple_stmt [79062,79121]
simple_stmt [79062,79121]
===
match
---
trailer [9842,9920]
trailer [9842,9920]
===
match
---
number: 2016 [16336,16340]
number: 2016 [16336,16340]
===
match
---
argument [13718,13735]
argument [13718,13735]
===
match
---
name: assert_command [67328,67342]
name: assert_command [67328,67342]
===
match
---
name: call_count [67172,67182]
name: call_count [67172,67182]
===
match
---
atom_expr [31201,31284]
atom_expr [31201,31284]
===
match
---
atom_expr [42750,42779]
atom_expr [42750,42779]
===
match
---
name: days [65545,65549]
name: days [65545,65549]
===
match
---
name: test_get_rendered_k8s_spec [69008,69034]
name: test_get_rendered_k8s_spec [69008,69034]
===
match
---
operator: = [25980,25981]
operator: = [25980,25981]
===
match
---
number: 6 [36978,36979]
number: 6 [36978,36979]
===
match
---
simple_stmt [4759,4777]
simple_stmt [4759,4777]
===
match
---
simple_stmt [71090,71146]
simple_stmt [71090,71146]
===
match
---
operator: , [26697,26698]
operator: , [26697,26698]
===
match
---
name: start_date [38677,38687]
name: start_date [38677,38687]
===
match
---
name: DEFAULT_DATE [5211,5223]
name: DEFAULT_DATE [5211,5223]
===
match
---
name: clear_db_import_errors [77846,77868]
name: clear_db_import_errors [77846,77868]
===
match
---
operator: = [21923,21924]
operator: = [21923,21924]
===
match
---
name: execution_date [6215,6229]
name: execution_date [6215,6229]
===
match
---
atom_expr [43692,43756]
atom_expr [43692,43756]
===
match
---
operator: , [54503,54504]
operator: , [54503,54504]
===
match
---
atom_expr [46766,46785]
atom_expr [46766,46785]
===
match
---
name: DEFAULT_DATE [22179,22191]
name: DEFAULT_DATE [22179,22191]
===
match
---
trailer [75550,75554]
trailer [75550,75554]
===
match
---
trailer [44403,44411]
trailer [44403,44411]
===
match
---
trailer [10615,10617]
trailer [10615,10617]
===
match
---
arglist [28789,28808]
arglist [28789,28808]
===
match
---
simple_stmt [56028,56078]
simple_stmt [56028,56078]
===
match
---
name: mock_on_retry_1 [61577,61592]
name: mock_on_retry_1 [61577,61592]
===
match
---
arglist [4900,5071]
arglist [4900,5071]
===
match
---
name: execution_date [68332,68346]
name: execution_date [68332,68346]
===
match
---
operator: , [75860,75861]
operator: , [75860,75861]
===
match
---
name: task [64515,64519]
name: task [64515,64519]
===
match
---
expr_stmt [3761,3804]
expr_stmt [3761,3804]
===
match
---
name: dag [51747,51750]
name: dag [51747,51750]
===
match
---
name: now [46995,46998]
name: now [46995,46998]
===
match
---
decorated [54333,55013]
decorated [54333,55013]
===
match
---
name: session [51214,51221]
name: session [51214,51221]
===
match
---
operator: , [53082,53083]
operator: , [53082,53083]
===
match
---
number: 2 [34248,34249]
number: 2 [34248,34249]
===
match
---
import_from [2037,2101]
import_from [2037,2101]
===
match
---
operator: = [56514,56515]
operator: = [56514,56515]
===
match
---
trailer [56430,56437]
trailer [56430,56437]
===
match
---
name: ti [59786,59788]
name: ti [59786,59788]
===
match
---
name: DummyOperator [14768,14781]
name: DummyOperator [14768,14781]
===
match
---
suite [53285,53671]
suite [53285,53671]
===
match
---
simple_stmt [67303,67320]
simple_stmt [67303,67320]
===
match
---
operator: = [44778,44779]
operator: = [44778,44779]
===
match
---
atom_expr [19448,19456]
atom_expr [19448,19456]
===
match
---
expr_stmt [8071,8084]
expr_stmt [8071,8084]
===
match
---
name: ti [5541,5543]
name: ti [5541,5543]
===
match
---
argument [46130,46142]
argument [46130,46142]
===
match
---
param [25248,25266]
param [25248,25266]
===
match
---
expr_stmt [58282,58317]
expr_stmt [58282,58317]
===
match
---
atom_expr [76973,77002]
atom_expr [76973,77002]
===
match
---
assert_stmt [54121,54219]
assert_stmt [54121,54219]
===
match
---
name: start_date [51887,51897]
name: start_date [51887,51897]
===
match
---
name: pytest [76542,76548]
name: pytest [76542,76548]
===
match
---
name: fail [27886,27890]
name: fail [27886,27890]
===
match
---
argument [47463,47475]
argument [47463,47475]
===
match
---
name: context [58865,58872]
name: context [58865,58872]
===
match
---
operator: == [28913,28915]
operator: == [28913,28915]
===
match
---
atom_expr [2917,2934]
atom_expr [2917,2934]
===
match
---
simple_stmt [35344,35372]
simple_stmt [35344,35372]
===
match
---
operator: = [30550,30551]
operator: = [30550,30551]
===
match
---
atom_expr [37674,37698]
atom_expr [37674,37698]
===
match
---
atom_expr [79013,79049]
atom_expr [79013,79049]
===
match
---
atom_expr [7131,7137]
atom_expr [7131,7137]
===
match
---
name: mock_send_email [49575,49590]
name: mock_send_email [49575,49590]
===
match
---
trailer [23840,23842]
trailer [23840,23842]
===
match
---
string: 'D' [75488,75491]
string: 'D' [75488,75491]
===
match
---
name: task [78384,78388]
name: task [78384,78388]
===
match
---
testlist_star_expr [27666,27677]
testlist_star_expr [27666,27677]
===
match
---
name: datetime [23688,23696]
name: datetime [23688,23696]
===
match
---
name: expected_output [59427,59442]
name: expected_output [59427,59442]
===
match
---
operator: , [33302,33303]
operator: , [33302,33303]
===
match
---
atom_expr [27228,27236]
atom_expr [27228,27236]
===
match
---
simple_stmt [30914,30938]
simple_stmt [30914,30938]
===
match
---
number: 0 [13223,13224]
number: 0 [13223,13224]
===
match
---
argument [78384,78393]
argument [78384,78393]
===
match
---
suite [25453,25608]
suite [25453,25608]
===
match
---
name: bash_command [48264,48276]
name: bash_command [48264,48276]
===
match
---
operator: = [75428,75429]
operator: = [75428,75429]
===
match
---
trailer [72423,72428]
trailer [72423,72428]
===
match
---
operator: , [30623,30624]
operator: , [30623,30624]
===
match
---
name: convert_to_utc [6143,6157]
name: convert_to_utc [6143,6157]
===
match
---
name: task_id [74810,74817]
name: task_id [74810,74817]
===
match
---
operator: = [74980,74981]
operator: = [74980,74981]
===
match
---
atom_expr [47803,47856]
atom_expr [47803,47856]
===
match
---
parameters [8931,8963]
parameters [8931,8963]
===
match
---
trailer [5062,5070]
trailer [5062,5070]
===
match
---
trailer [34724,34726]
trailer [34724,34726]
===
match
---
operator: == [3176,3178]
operator: == [3176,3178]
===
match
---
operator: = [39660,39661]
operator: = [39660,39661]
===
match
---
trailer [53466,53482]
trailer [53466,53482]
===
match
---
operator: , [27016,27017]
operator: , [27016,27017]
===
match
---
argument [30831,30850]
argument [30831,30850]
===
match
---
atom_expr [68180,68220]
atom_expr [68180,68220]
===
match
---
simple_stmt [41796,41947]
simple_stmt [41796,41947]
===
match
---
operator: , [32321,32322]
operator: , [32321,32322]
===
match
---
argument [51816,51831]
argument [51816,51831]
===
match
---
operator: = [58586,58587]
operator: = [58586,58587]
===
match
---
name: dag_id [67248,67254]
name: dag_id [67248,67254]
===
match
---
arglist [79616,79637]
arglist [79616,79637]
===
match
---
suite [12254,12502]
suite [12254,12502]
===
match
---
suite [16122,16372]
suite [16122,16372]
===
match
---
arglist [57212,57255]
arglist [57212,57255]
===
match
---
string: 'op_1' [6868,6874]
string: 'op_1' [6868,6874]
===
match
---
funcdef [64366,64438]
funcdef [64366,64438]
===
match
---
trailer [65710,65724]
trailer [65710,65724]
===
match
---
argument [18920,18969]
argument [18920,18969]
===
match
---
name: get_previous_start_date [56789,56812]
name: get_previous_start_date [56789,56812]
===
match
---
assert_stmt [4785,4857]
assert_stmt [4785,4857]
===
match
---
funcdef [6281,6606]
funcdef [6281,6606]
===
match
---
trailer [51617,51648]
trailer [51617,51648]
===
match
---
name: ti1 [37674,37677]
name: ti1 [37674,37677]
===
match
---
comparison [62810,62842]
comparison [62810,62842]
===
match
---
operator: , [33706,33707]
operator: , [33706,33707]
===
match
---
name: task [11690,11694]
name: task [11690,11694]
===
match
---
operator: = [50291,50292]
operator: = [50291,50292]
===
match
---
simple_stmt [80189,80263]
simple_stmt [80189,80263]
===
match
---
operator: = [55169,55170]
operator: = [55169,55170]
===
match
---
simple_stmt [66925,66944]
simple_stmt [66925,66944]
===
match
---
name: datetime [22096,22104]
name: datetime [22096,22104]
===
match
---
operator: = [44202,44203]
operator: = [44202,44203]
===
match
---
simple_stmt [5605,5646]
simple_stmt [5605,5646]
===
match
---
name: parameterized [53677,53690]
name: parameterized [53677,53690]
===
match
---
name: FAILED [73181,73187]
name: FAILED [73181,73187]
===
match
---
name: airflow [2289,2296]
name: airflow [2289,2296]
===
match
---
operator: , [31785,31786]
operator: , [31785,31786]
===
match
---
name: task_id [76682,76689]
name: task_id [76682,76689]
===
match
---
name: pytest [8205,8211]
name: pytest [8205,8211]
===
match
---
argument [23446,23467]
argument [23446,23467]
===
match
---
atom_expr [26241,26270]
atom_expr [26241,26270]
===
match
---
operator: = [15976,15977]
operator: = [15976,15977]
===
match
---
dotted_name [57571,57591]
dotted_name [57571,57591]
===
match
---
name: retry_delay [23504,23515]
name: retry_delay [23504,23515]
===
match
---
trailer [60963,60971]
trailer [60963,60971]
===
match
---
name: op1 [4247,4250]
name: op1 [4247,4250]
===
match
---
operator: , [36976,36977]
operator: , [36976,36977]
===
match
---
argument [30999,31018]
argument [30999,31018]
===
match
---
name: task [48350,48354]
name: task [48350,48354]
===
match
---
arglist [69059,69112]
arglist [69059,69112]
===
match
---
argument [17375,17384]
argument [17375,17384]
===
match
---
name: get_previous_start_date [55425,55448]
name: get_previous_start_date [55425,55448]
===
match
---
operator: = [49256,49257]
operator: = [49256,49257]
===
match
---
name: end_date [5272,5280]
name: end_date [5272,5280]
===
match
---
trailer [61941,61966]
trailer [61941,61966]
===
match
---
number: 4 [32514,32515]
number: 4 [32514,32515]
===
match
---
string: 'op' [50715,50719]
string: 'op' [50715,50719]
===
match
---
name: str [51618,51621]
name: str [51618,51621]
===
match
---
operator: = [4616,4617]
operator: = [4616,4617]
===
match
---
operator: == [40682,40684]
operator: == [40682,40684]
===
match
---
trailer [74562,74581]
trailer [74562,74581]
===
match
---
name: ti [10130,10132]
name: ti [10130,10132]
===
match
---
arglist [43083,43131]
arglist [43083,43131]
===
match
---
number: 1 [16345,16346]
number: 1 [16345,16346]
===
match
---
number: 5 [32363,32364]
number: 5 [32363,32364]
===
match
---
atom_expr [47140,47163]
atom_expr [47140,47163]
===
match
---
atom_expr [78216,78232]
atom_expr [78216,78232]
===
match
---
simple_stmt [77069,77099]
simple_stmt [77069,77099]
===
match
---
argument [5063,5069]
argument [5063,5069]
===
match
---
name: ti [20601,20603]
name: ti [20601,20603]
===
match
---
name: task [46169,46173]
name: task [46169,46173]
===
match
---
trailer [66954,66970]
trailer [66954,66970]
===
match
---
name: execution_date [3285,3299]
name: execution_date [3285,3299]
===
match
---
trailer [39684,39694]
trailer [39684,39694]
===
match
---
name: add [45189,45192]
name: add [45189,45192]
===
match
---
suite [49439,49540]
suite [49439,49540]
===
match
---
operator: = [15085,15086]
operator: = [15085,15086]
===
match
---
name: depends_on_past [30637,30652]
name: depends_on_past [30637,30652]
===
match
---
operator: , [12106,12107]
operator: , [12106,12107]
===
match
---
argument [23668,23717]
argument [23668,23717]
===
match
---
name: value [40685,40690]
name: value [40685,40690]
===
match
---
operator: , [46792,46793]
operator: , [46792,46793]
===
match
---
string: """         Test the availability of variables in templates         """ [58475,58546]
string: """         Test the availability of variables in templates         """ [58475,58546]
===
match
---
argument [76784,76802]
argument [76784,76802]
===
match
---
operator: = [64094,64095]
operator: = [64094,64095]
===
match
---
name: date [22261,22265]
name: date [22261,22265]
===
match
---
operator: = [3111,3112]
operator: = [3111,3112]
===
match
---
expr_stmt [48140,48185]
expr_stmt [48140,48185]
===
match
---
operator: , [24830,24831]
operator: , [24830,24831]
===
match
---
comparison [35154,35178]
comparison [35154,35178]
===
match
---
simple_stmt [43849,43905]
simple_stmt [43849,43905]
===
match
---
name: timezone [43175,43183]
name: timezone [43175,43183]
===
match
---
expr_stmt [38530,38737]
expr_stmt [38530,38737]
===
match
---
name: task [44868,44872]
name: task [44868,44872]
===
match
---
name: execution_date [54176,54190]
name: execution_date [54176,54190]
===
match
---
testlist_comp [32416,32480]
testlist_comp [32416,32480]
===
match
---
operator: @ [53676,53677]
operator: @ [53676,53677]
===
match
---
string: 'airflow' [17275,17284]
string: 'airflow' [17275,17284]
===
match
---
simple_stmt [44294,44312]
simple_stmt [44294,44312]
===
match
---
name: timezone [40244,40252]
name: timezone [40244,40252]
===
match
---
number: 0 [20371,20372]
number: 0 [20371,20372]
===
match
---
string: 'op' [46138,46142]
string: 'op' [46138,46142]
===
match
---
name: context [58715,58722]
name: context [58715,58722]
===
match
---
trailer [80026,80041]
trailer [80026,80041]
===
match
---
name: SCHEDULED [51156,51165]
name: SCHEDULED [51156,51165]
===
match
---
expr_stmt [6385,6520]
expr_stmt [6385,6520]
===
match
---
parameters [58459,58465]
parameters [58459,58465]
===
match
---
name: dag [41796,41799]
name: dag [41796,41799]
===
match
---
simple_stmt [4347,4365]
simple_stmt [4347,4365]
===
match
---
trailer [54893,54908]
trailer [54893,54908]
===
match
---
name: dag [67094,67097]
name: dag [67094,67097]
===
match
---
comparison [77076,77098]
comparison [77076,77098]
===
match
---
name: execution_date [13527,13541]
name: execution_date [13527,13541]
===
match
---
name: self [42967,42971]
name: self [42967,42971]
===
match
---
trailer [7966,7984]
trailer [7966,7984]
===
match
---
trailer [11645,11652]
trailer [11645,11652]
===
match
---
name: next_retry_datetime [22497,22516]
name: next_retry_datetime [22497,22516]
===
match
---
string: 'test_xcom' [40179,40190]
string: 'test_xcom' [40179,40190]
===
match
---
operator: = [47872,47873]
operator: = [47872,47873]
===
match
---
expr_stmt [27653,27677]
expr_stmt [27653,27677]
===
match
---
trailer [48997,49026]
trailer [48997,49026]
===
match
---
simple_stmt [65168,65244]
simple_stmt [65168,65244]
===
match
---
with_stmt [55840,55990]
with_stmt [55840,55990]
===
match
---
simple_stmt [814,826]
simple_stmt [814,826]
===
match
---
atom_expr [17125,17358]
atom_expr [17125,17358]
===
match
---
name: DAG [61442,61445]
name: DAG [61442,61445]
===
match
---
simple_stmt [25495,25504]
simple_stmt [25495,25504]
===
match
---
assert_stmt [68764,68800]
assert_stmt [68764,68800]
===
match
---
operator: = [2848,2849]
operator: = [2848,2849]
===
match
---
name: DEFAULT_DATE [44889,44901]
name: DEFAULT_DATE [44889,44901]
===
match
---
name: set_state [75245,75254]
name: set_state [75245,75254]
===
match
---
operator: = [39720,39721]
operator: = [39720,39721]
===
match
---
atom_expr [23860,23884]
atom_expr [23860,23884]
===
match
---
trailer [71842,71849]
trailer [71842,71849]
===
match
---
dotted_name [2208,2227]
dotted_name [2208,2227]
===
match
---
expr_stmt [79893,79956]
expr_stmt [79893,79956]
===
match
---
funcdef [59375,59909]
funcdef [59375,59909]
===
match
---
atom_expr [37945,37993]
atom_expr [37945,37993]
===
match
---
simple_stmt [34696,35034]
simple_stmt [34696,35034]
===
match
---
simple_stmt [15445,15681]
simple_stmt [15445,15681]
===
match
---
trailer [61178,61184]
trailer [61178,61184]
===
match
---
name: db [77785,77787]
name: db [77785,77787]
===
match
---
operator: = [6340,6341]
operator: = [6340,6341]
===
match
---
argument [6424,6458]
argument [6424,6458]
===
match
---
atom_expr [4632,4659]
atom_expr [4632,4659]
===
match
---
trailer [26303,26313]
trailer [26303,26313]
===
match
---
comparison [16018,16058]
comparison [16018,16058]
===
match
---
arglist [41147,41202]
arglist [41147,41202]
===
match
---
name: patch_dict [12235,12245]
name: patch_dict [12235,12245]
===
match
---
argument [14312,14344]
argument [14312,14344]
===
match
---
suite [7985,8022]
suite [7985,8022]
===
match
---
operator: = [55629,55630]
operator: = [55629,55630]
===
match
---
string: 'no-sched/catchup' [52930,52948]
string: 'no-sched/catchup' [52930,52948]
===
match
---
atom [33010,33067]
atom [33010,33067]
===
match
---
name: self [7393,7397]
name: self [7393,7397]
===
match
---
operator: , [33812,33813]
operator: , [33812,33813]
===
match
---
trailer [3550,3552]
trailer [3550,3552]
===
match
---
simple_stmt [17881,17908]
simple_stmt [17881,17908]
===
match
---
name: fail [24268,24272]
name: fail [24268,24272]
===
match
---
name: ti [25495,25497]
name: ti [25495,25497]
===
match
---
name: DummyOperator [8631,8644]
name: DummyOperator [8631,8644]
===
match
---
operator: , [16340,16341]
operator: , [16340,16341]
===
match
---
atom_expr [8205,8236]
atom_expr [8205,8236]
===
match
---
argument [47125,47163]
argument [47125,47163]
===
match
---
name: test_pool_slots_property [14528,14552]
name: test_pool_slots_property [14528,14552]
===
match
---
name: Variable [1469,1477]
name: Variable [1469,1477]
===
match
---
name: query [46964,46969]
name: query [46964,46969]
===
match
---
trailer [66151,66153]
trailer [66151,66153]
===
match
---
name: op1 [4417,4420]
name: op1 [4417,4420]
===
match
---
name: dag [21086,21089]
name: dag [21086,21089]
===
match
---
number: 0 [32902,32903]
number: 0 [32902,32903]
===
match
---
name: SCHEDULED [61113,61122]
name: SCHEDULED [61113,61122]
===
match
---
simple_stmt [39981,40002]
simple_stmt [39981,40002]
===
match
---
name: downstream_task [36480,36495]
name: downstream_task [36480,36495]
===
match
---
arglist [57080,57099]
arglist [57080,57099]
===
match
---
string: '0 12 * * *' [57025,57037]
string: '0 12 * * *' [57025,57037]
===
match
---
expr_stmt [13988,14210]
expr_stmt [13988,14210]
===
match
---
operator: = [34892,34893]
operator: = [34892,34893]
===
match
---
operator: = [63186,63187]
operator: = [63186,63187]
===
match
---
atom_expr [56384,56397]
atom_expr [56384,56397]
===
match
---
name: ti [77076,77078]
name: ti [77076,77078]
===
match
---
arglist [59546,59605]
arglist [59546,59605]
===
match
---
argument [43160,43192]
argument [43160,43192]
===
match
---
name: start_date [55659,55669]
name: start_date [55659,55669]
===
match
---
name: State [72346,72351]
name: State [72346,72351]
===
match
---
import_as_names [1202,1262]
import_as_names [1202,1262]
===
match
---
atom_expr [3852,3868]
atom_expr [3852,3868]
===
match
---
trailer [7468,7501]
trailer [7468,7501]
===
match
---
atom_expr [43209,43223]
atom_expr [43209,43223]
===
match
---
dotted_name [1268,1294]
dotted_name [1268,1294]
===
match
---
operator: , [16352,16353]
operator: , [16352,16353]
===
match
---
string: 'airflow' [42716,42725]
string: 'airflow' [42716,42725]
===
match
---
number: 10 [78074,78076]
number: 12 [78074,78076]
===
match
---
operator: , [33435,33436]
operator: , [33435,33436]
===
match
---
param [65004,65008]
param [65004,65008]
===
match
---
argument [49822,49834]
argument [49822,49834]
===
match
---
operator: = [66611,66612]
operator: = [66611,66612]
===
match
---
atom_expr [14458,14477]
atom_expr [14458,14477]
===
match
---
name: NONE [36132,36136]
name: NONE [36132,36136]
===
match
---
name: TI [38789,38791]
name: TI [38789,38791]
===
match
---
operator: = [66354,66355]
operator: = [66354,66355]
===
match
---
arglist [51862,51910]
arglist [51862,51910]
===
match
---
atom_expr [2606,2633]
atom_expr [2606,2633]
===
match
---
trailer [66062,66068]
trailer [66062,66068]
===
match
---
name: parameterized [35940,35953]
name: parameterized [35940,35953]
===
match
---
operator: = [17308,17309]
operator: = [17308,17309]
===
match
---
operator: = [73704,73705]
operator: = [73704,73705]
===
match
---
operator: = [52264,52265]
operator: = [52264,52265]
===
match
---
name: python [1704,1710]
name: python [1704,1710]
===
match
---
operator: = [38622,38623]
operator: = [38622,38623]
===
match
---
suite [13815,14519]
suite [13815,14519]
===
match
---
comparison [74285,74302]
comparison [74285,74302]
===
match
---
trailer [48427,48429]
trailer [48427,48429]
===
match
---
simple_stmt [21170,21208]
simple_stmt [21170,21208]
===
match
---
name: TI [36510,36512]
name: TI [36510,36512]
===
match
---
name: state [14496,14501]
name: state [14496,14501]
===
match
---
operator: = [57189,57190]
operator: = [57189,57190]
===
match
---
name: DagRunType [13605,13615]
name: DagRunType [13605,13615]
===
match
---
operator: , [41740,41741]
operator: , [41740,41741]
===
match
---
name: mock_on_failure_3 [63481,63498]
name: mock_on_failure_3 [63481,63498]
===
match
---
name: run [75789,75792]
name: run [75789,75792]
===
match
---
name: task_id [15483,15490]
name: task_id [15483,15490]
===
match
---
name: start_date [57051,57061]
name: start_date [57051,57061]
===
match
---
argument [9050,9092]
argument [9050,9092]
===
match
---
trailer [48156,48185]
trailer [48156,48185]
===
match
---
trailer [62699,62717]
trailer [62699,62717]
===
match
---
atom_expr [71928,71943]
atom_expr [71928,71943]
===
match
---
assert_stmt [46942,46998]
assert_stmt [46942,46998]
===
match
---
operator: , [1240,1241]
operator: , [1240,1241]
===
match
---
operator: == [61317,61319]
operator: == [61317,61319]
===
match
---
operator: = [65475,65476]
operator: = [65475,65476]
===
match
---
simple_stmt [63322,63347]
simple_stmt [63322,63347]
===
match
---
atom_expr [76203,76216]
atom_expr [76203,76216]
===
match
---
name: start_date [40233,40243]
name: start_date [40233,40243]
===
match
---
operator: , [69223,69224]
operator: , [69223,69224]
===
match
---
name: execution_date [30794,30808]
name: execution_date [30794,30808]
===
match
---
number: 3 [32434,32435]
number: 3 [32434,32435]
===
match
---
name: datetime [11434,11442]
name: datetime [11434,11442]
===
match
---
name: ti [40340,40342]
name: ti [40340,40342]
===
match
---
name: task_c [75210,75216]
name: task_c [75210,75216]
===
match
---
simple_stmt [30470,30536]
simple_stmt [30470,30536]
===
match
---
name: dag_run [47976,47983]
name: dag_run [47976,47983]
===
match
---
operator: = [61847,61848]
operator: = [61847,61848]
===
match
---
trailer [76951,77003]
trailer [76951,77003]
===
match
---
name: models [44622,44628]
name: models [44622,44628]
===
match
---
name: param [53092,53097]
name: param [53092,53097]
===
match
---
simple_stmt [62270,62497]
simple_stmt [62270,62497]
===
match
---
name: trigger_rule [34406,34418]
name: trigger_rule [34406,34418]
===
match
---
name: state [54859,54864]
name: state [54859,54864]
===
match
---
simple_stmt [9552,9582]
simple_stmt [9552,9582]
===
match
---
string: 'value' [59055,59062]
string: 'value' [59055,59062]
===
match
---
suite [28035,30425]
suite [28035,30425]
===
match
---
expr_stmt [56614,56661]
expr_stmt [56614,56661]
===
match
---
operator: , [40457,40458]
operator: , [40457,40458]
===
match
---
expr_stmt [69263,70697]
expr_stmt [69263,70697]
===
match
---
import_from [1481,1528]
import_from [1481,1528]
===
match
---
atom_expr [25763,25776]
atom_expr [25763,25776]
===
match
---
atom_expr [71315,71365]
atom_expr [71315,71365]
===
match
---
trailer [66186,66194]
trailer [66186,66194]
===
match
---
simple_stmt [77257,77313]
simple_stmt [77257,77313]
===
match
---
name: dag [40153,40156]
name: dag [40153,40156]
===
match
---
simple_stmt [22261,22293]
simple_stmt [22261,22293]
===
match
---
operator: { [19935,19936]
operator: { [19935,19936]
===
match
---
operator: , [33872,33873]
operator: , [33872,33873]
===
match
---
trailer [23312,23316]
trailer [23312,23316]
===
match
---
trailer [14369,14377]
trailer [14369,14377]
===
match
---
number: 2 [33733,33734]
number: 2 [33733,33734]
===
match
---
trailer [19762,19768]
trailer [19762,19768]
===
match
---
atom_expr [10912,10920]
atom_expr [10912,10920]
===
match
---
name: ti [38998,39000]
name: ti [38998,39000]
===
match
---
name: timedelta [21687,21696]
name: timedelta [21687,21696]
===
match
---
atom_expr [48146,48185]
atom_expr [48146,48185]
===
match
---
name: dagrun_2 [56677,56685]
name: dagrun_2 [56677,56685]
===
match
---
name: op [7295,7297]
name: op [7295,7297]
===
match
---
name: op2 [8812,8815]
name: op2 [8812,8815]
===
match
---
name: ti [52261,52263]
name: ti [52261,52263]
===
match
---
name: result [38220,38226]
name: result [38220,38226]
===
match
---
name: timezone [38758,38766]
name: timezone [38758,38766]
===
match
---
name: State [32692,32697]
name: State [32692,32697]
===
match
---
expr_stmt [46506,46543]
expr_stmt [46506,46543]
===
match
---
atom [33840,33886]
atom [33840,33886]
===
match
---
name: dag [51882,51885]
name: dag [51882,51885]
===
match
---
operator: , [73532,73533]
operator: , [73532,73533]
===
match
---
name: assert_queries_count [2427,2447]
name: assert_queries_count [2427,2447]
===
match
---
atom_expr [22215,22251]
atom_expr [22215,22251]
===
match
---
name: session [45456,45463]
name: session [45456,45463]
===
match
---
name: State [54969,54974]
name: State [54969,54974]
===
match
---
name: tzinfo [6363,6369]
name: tzinfo [6363,6369]
===
match
---
suite [11597,11655]
suite [11597,11655]
===
match
---
simple_stmt [37463,37501]
simple_stmt [37463,37501]
===
match
---
trailer [47148,47157]
trailer [47148,47157]
===
match
---
argument [10619,10637]
argument [10619,10637]
===
match
---
operator: , [69507,69508]
operator: , [69507,69508]
===
match
---
name: DateTime [52490,52498]
name: DateTime [52490,52498]
===
match
---
trailer [79253,79268]
trailer [79253,79268]
===
match
---
expr_stmt [8973,9017]
expr_stmt [8973,9017]
===
match
---
operator: = [26690,26691]
operator: = [26690,26691]
===
match
---
trailer [30184,30190]
trailer [30184,30190]
===
match
---
suite [34459,34585]
suite [34459,34585]
===
match
---
trailer [44367,44378]
trailer [44367,44378]
===
match
---
operator: , [33106,33107]
operator: , [33106,33107]
===
match
---
trailer [46963,46991]
trailer [46963,46991]
===
match
---
name: TestError [42880,42889]
name: TestError [42880,42889]
===
match
---
trailer [71030,71080]
trailer [71030,71080]
===
match
---
name: models [64453,64459]
name: models [64453,64459]
===
match
---
lambdef [73973,73985]
lambdef [73973,73985]
===
match
---
argument [37429,37453]
argument [37429,37453]
===
match
---
operator: = [52364,52365]
operator: = [52364,52365]
===
match
---
name: State [71928,71933]
name: State [71928,71933]
===
match
---
atom [70140,70654]
atom [70140,70654]
===
match
---
atom_expr [74594,74641]
atom_expr [74594,74641]
===
match
---
trailer [76498,76507]
trailer [76498,76507]
===
match
---
operator: , [9092,9093]
operator: , [9092,9093]
===
match
---
name: processor_agent [75953,75968]
name: processor_agent [75953,75968]
===
match
---
simple_stmt [60912,60937]
simple_stmt [60912,60937]
===
match
---
arglist [18949,18968]
arglist [18949,18968]
===
match
---
operator: , [13658,13659]
operator: , [13658,13659]
===
match
---
simple_stmt [979,995]
simple_stmt [979,995]
===
match
---
simple_stmt [37075,37146]
simple_stmt [37075,37146]
===
match
---
name: ti_state_mapping [71409,71425]
name: ti_state_mapping [71409,71425]
===
match
---
name: State [27956,27961]
name: State [27956,27961]
===
match
---
operator: == [54880,54882]
operator: == [54880,54882]
===
match
---
name: str [2574,2577]
name: str [2574,2577]
===
match
---
atom_expr [33569,33582]
atom_expr [33569,33582]
===
match
---
parameters [53754,53791]
parameters [53754,53791]
===
match
---
trailer [57308,57310]
trailer [57308,57310]
===
match
---
trailer [3157,3164]
trailer [3157,3164]
===
match
---
string: '0 0 * * * ' [52841,52853]
string: '0 0 * * * ' [52841,52853]
===
match
---
number: 2016 [18949,18953]
number: 2016 [18949,18953]
===
match
---
number: 0 [32431,32432]
number: 0 [32431,32432]
===
match
---
import_as_names [1348,1478]
import_as_names [1348,1478]
===
match
---
simple_stmt [77909,77923]
simple_stmt [77909,77923]
===
match
---
name: session [9461,9468]
name: session [9461,9468]
===
match
---
trailer [16078,16082]
trailer [16078,16082]
===
match
---
expr_stmt [34658,34687]
expr_stmt [34658,34687]
===
match
---
name: fail [64637,64641]
name: fail [64637,64641]
===
match
---
argument [46673,46691]
argument [46673,46691]
===
match
---
operator: = [60822,60823]
operator: = [60822,60823]
===
match
---
name: task_instance_a [74873,74888]
name: task_instance_a [74873,74888]
===
match
---
suite [6316,6606]
suite [6316,6606]
===
match
---
name: datetime [15636,15644]
name: datetime [15636,15644]
===
match
---
simple_stmt [1529,1579]
simple_stmt [1529,1579]
===
match
---
operator: = [6431,6432]
operator: = [6431,6432]
===
match
---
number: 1 [29605,29606]
number: 1 [29605,29606]
===
match
---
name: pool [28730,28734]
name: pool [28730,28734]
===
match
---
simple_stmt [53360,53440]
simple_stmt [53360,53440]
===
match
---
name: TypeError [7087,7096]
name: TypeError [7087,7096]
===
match
---
trailer [21095,21097]
trailer [21095,21097]
===
match
---
name: task_id [6860,6867]
name: task_id [6860,6867]
===
match
---
name: ti [13457,13459]
name: ti [13457,13459]
===
match
---
number: 1 [53146,53147]
number: 1 [53146,53147]
===
match
---
name: retries [18792,18799]
name: retries [18792,18799]
===
match
---
argument [64135,64167]
argument [64135,64167]
===
match
---
operator: , [31691,31692]
operator: , [31691,31692]
===
match
---
trailer [49948,49950]
trailer [49948,49950]
===
match
---
name: DummyOperator [50680,50693]
name: DummyOperator [50680,50693]
===
match
---
operator: , [11453,11454]
operator: , [11453,11454]
===
match
---
string: "test" [76824,76830]
string: "test" [76824,76830]
===
match
---
operator: -> [77947,77949]
operator: -> [77947,77949]
===
match
---
trailer [7133,7137]
trailer [7133,7137]
===
match
---
name: session [15249,15256]
name: session [15249,15256]
===
match
---
atom [33152,33209]
atom [33152,33209]
===
match
---
operator: = [18077,18078]
operator: = [18077,18078]
===
match
---
name: test_mark_non_runnable_task_as_success [12603,12641]
name: test_mark_non_runnable_task_as_success [12603,12641]
===
match
---
name: RUNNING [45073,45080]
name: RUNNING [45073,45080]
===
match
---
operator: = [67509,67510]
operator: = [67509,67510]
===
match
---
raise_stmt [17881,17907]
raise_stmt [17881,17907]
===
match
---
expr_stmt [20533,20585]
expr_stmt [20533,20585]
===
match
---
name: test_previous_execution_date_success [54387,54423]
name: test_previous_execution_date_success [54387,54423]
===
match
---
argument [50226,50248]
argument [50226,50248]
===
match
---
name: clean_db [3459,3467]
name: clean_db [3459,3467]
===
match
---
operator: == [77339,77341]
operator: == [77339,77341]
===
match
---
trailer [16156,16371]
trailer [16156,16371]
===
match
---
atom_expr [25931,25942]
atom_expr [25931,25942]
===
match
---
name: task_id [43626,43633]
name: task_id [43626,43633]
===
match
---
arglist [5549,5594]
arglist [5549,5594]
===
match
---
name: utcnow [9973,9979]
name: utcnow [9973,9979]
===
match
---
name: self [16827,16831]
name: self [16827,16831]
===
match
---
name: call [67077,67081]
name: call [67077,67081]
===
match
---
operator: { [72266,72267]
operator: { [72266,72267]
===
match
---
trailer [72721,72728]
trailer [72721,72728]
===
match
---
funcdef [67193,67574]
funcdef [67193,67574]
===
match
---
name: now [79831,79834]
name: now [79831,79834]
===
match
---
atom_expr [4220,4234]
atom_expr [4220,4234]
===
match
---
trailer [13491,13673]
trailer [13491,13673]
===
match
---
name: owner [34389,34394]
name: owner [34389,34394]
===
match
---
param [34015,34028]
param [34015,34028]
===
match
---
comparison [47351,47377]
comparison [47351,47377]
===
match
---
name: task [35352,35356]
name: task [35352,35356]
===
match
---
operator: = [61593,61594]
operator: = [61593,61594]
===
match
---
operator: = [20207,20208]
operator: = [20207,20208]
===
match
---
operator: = [53304,53305]
operator: = [53304,53305]
===
match
---
trailer [55191,55199]
trailer [55191,55199]
===
match
---
name: email [48312,48317]
name: email [48312,48317]
===
match
---
trailer [54539,54547]
trailer [54539,54547]
===
match
---
name: dag_id [44561,44567]
name: dag_id [44561,44567]
===
match
---
trailer [64302,64308]
trailer [64302,64308]
===
match
---
expr_stmt [7637,7700]
expr_stmt [7637,7700]
===
match
---
argument [80223,80261]
argument [80223,80261]
===
match
---
name: key [42010,42013]
name: key [42010,42013]
===
match
---
atom_expr [54883,54908]
atom_expr [54883,54908]
===
match
---
operator: = [41541,41542]
operator: = [41541,41542]
===
match
---
name: self [38283,38287]
name: self [38283,38287]
===
match
---
operator: = [68261,68262]
operator: = [68261,68262]
===
match
---
operator: , [23432,23433]
operator: , [23432,23433]
===
match
---
operator: , [71802,71803]
operator: , [71802,71803]
===
match
---
name: datetime [49936,49944]
name: datetime [49936,49944]
===
match
---
name: self [75570,75574]
name: self [75570,75574]
===
match
---
name: ti_list [54737,54744]
name: ti_list [54737,54744]
===
match
---
name: ti_list [53645,53652]
name: ti_list [53645,53652]
===
match
---
name: session [3817,3824]
name: session [3817,3824]
===
match
---
name: DAG [4056,4059]
name: DAG [4056,4059]
===
match
---
name: RUNNING [66687,66694]
name: RUNNING [66687,66694]
===
match
---
atom_expr [24998,25148]
atom_expr [24998,25148]
===
match
---
simple_stmt [37543,37568]
simple_stmt [37543,37568]
===
match
---
comparison [67161,67187]
comparison [67161,67187]
===
match
---
name: session [78236,78243]
name: session [78236,78243]
===
match
---
operator: = [9352,9353]
operator: = [9352,9353]
===
match
---
trailer [52325,52335]
trailer [52325,52335]
===
match
---
name: self [47048,47052]
name: self [47048,47052]
===
match
---
name: ti [50929,50931]
name: ti [50929,50931]
===
match
---
atom_expr [43395,43408]
atom_expr [43395,43408]
===
match
---
argument [64747,64756]
argument [64747,64756]
===
match
---
name: task [74847,74851]
name: task [74847,74851]
===
match
---
expr_stmt [46602,46645]
expr_stmt [46602,46645]
===
match
---
dictorsetmaker [69364,69547]
dictorsetmaker [69364,69547]
===
match
---
funcdef [15213,16778]
funcdef [15213,16778]
===
match
---
arith_expr [22818,22877]
arith_expr [22818,22877]
===
match
---
trailer [22919,22930]
trailer [22919,22930]
===
match
---
atom_expr [6846,6889]
atom_expr [6846,6889]
===
match
---
name: return_value [35659,35671]
name: return_value [35659,35671]
===
match
---
dotted_name [77984,78004]
dotted_name [77984,78004]
===
match
---
number: 0 [55343,55344]
number: 0 [55343,55344]
===
match
---
expr_stmt [75107,75174]
expr_stmt [75107,75174]
===
match
---
argument [7729,7748]
argument [7729,7748]
===
match
---
name: task_ids [37811,37819]
name: task_ids [37811,37819]
===
match
---
number: 1 [76997,76998]
number: 1 [76997,76998]
===
match
---
name: conf [47208,47212]
name: conf [47208,47212]
===
match
---
name: utcnow [14262,14268]
name: utcnow [14262,14268]
===
match
---
name: idx [52660,52663]
name: idx [52660,52663]
===
match
---
name: state [25075,25080]
name: state [25075,25080]
===
match
---
operator: = [15450,15451]
operator: = [15450,15451]
===
match
---
operator: = [38796,38797]
operator: = [38796,38797]
===
match
---
string: 'B' [72678,72681]
string: 'B' [72678,72681]
===
match
---
dictorsetmaker [16276,16288]
dictorsetmaker [16276,16288]
===
match
---
operator: = [47783,47784]
operator: = [47783,47784]
===
match
---
operator: , [23490,23491]
operator: , [23490,23491]
===
match
---
trailer [70726,70728]
trailer [70726,70728]
===
match
---
arglist [23745,23783]
arglist [23745,23783]
===
match
---
atom_expr [77464,77475]
atom_expr [77464,77475]
===
match
---
name: DAG [40024,40027]
name: DAG [40024,40027]
===
match
---
number: 0 [63512,63513]
number: 0 [63512,63513]
===
match
---
string: 'C' [72673,72676]
string: 'C' [72673,72676]
===
match
---
trailer [4832,4841]
trailer [4832,4841]
===
match
---
name: key [41040,41043]
name: key [41040,41043]
===
match
---
trailer [76193,76195]
trailer [76193,76195]
===
match
---
name: refresh_from_db [27195,27210]
name: refresh_from_db [27195,27210]
===
match
---
trailer [77492,77501]
trailer [77492,77501]
===
match
---
atom_expr [76395,76408]
atom_expr [76395,76408]
===
match
---
arglist [39464,39503]
arglist [39464,39503]
===
match
---
name: start_date [58576,58586]
name: start_date [58576,58586]
===
match
---
argument [9758,9775]
argument [9758,9775]
===
match
---
arglist [46744,46837]
arglist [46744,46837]
===
match
---
operator: , [69696,69697]
operator: , [69696,69697]
===
match
---
operator: = [35395,35396]
operator: = [35395,35396]
===
match
---
trailer [13526,13541]
trailer [13526,13541]
===
match
---
argument [14121,14136]
argument [14121,14136]
===
match
---
atom_expr [65578,65698]
atom_expr [65578,65698]
===
match
---
operator: { [71831,71832]
operator: { [71831,71832]
===
match
---
operator: = [11424,11425]
operator: = [11424,11425]
===
match
---
name: DagRunType [2273,2283]
name: DagRunType [2273,2283]
===
match
---
simple_stmt [18623,18670]
simple_stmt [18623,18670]
===
match
---
name: ti1 [37209,37212]
name: ti1 [37209,37212]
===
match
---
operator: + [12088,12089]
operator: + [12088,12089]
===
match
---
string: 'dag_id' [46869,46877]
string: 'dag_id' [46869,46877]
===
match
---
string: 'C' [72282,72285]
string: 'C' [72282,72285]
===
match
---
operator: } [73289,73290]
operator: } [73289,73290]
===
match
---
trailer [10866,10870]
trailer [10866,10870]
===
match
---
trailer [52697,52723]
trailer [52697,52723]
===
match
---
operator: - [22619,22620]
operator: - [22619,22620]
===
match
---
name: end_date [4849,4857]
name: end_date [4849,4857]
===
match
---
param [38283,38287]
param [38283,38287]
===
match
---
argument [10394,10411]
argument [10394,10411]
===
match
---
name: result [37583,37589]
name: result [37583,37589]
===
match
---
comparison [5612,5645]
comparison [5612,5645]
===
match
---
name: task_id [3184,3191]
name: task_id [3184,3191]
===
match
---
number: 2 [14185,14186]
number: 2 [14185,14186]
===
match
---
trailer [19777,19784]
trailer [19777,19784]
===
match
---
name: TIDepStatus [12068,12079]
name: TIDepStatus [12068,12079]
===
match
---
trailer [76981,76990]
trailer [76981,76990]
===
match
---
expr_stmt [5374,5424]
expr_stmt [5374,5424]
===
match
---
simple_stmt [9294,9367]
simple_stmt [9294,9367]
===
match
---
operator: , [56437,56438]
operator: , [56437,56438]
===
match
---
expr_stmt [76265,76291]
expr_stmt [76265,76291]
===
match
---
expr_stmt [23248,23290]
expr_stmt [23248,23290]
===
match
---
operator: = [30521,30522]
operator: = [30521,30522]
===
match
---
name: pool [14091,14095]
name: pool [14091,14095]
===
match
---
trailer [5052,5062]
trailer [5052,5062]
===
match
---
string: 'scheduler' [71721,71732]
string: 'scheduler' [71721,71732]
===
match
---
name: ti [6182,6184]
name: ti [6182,6184]
===
match
---
name: State [72804,72809]
name: State [72804,72809]
===
match
---
name: conf [73485,73489]
name: conf [73485,73489]
===
match
---
name: SUCCESS [55461,55468]
name: SUCCESS [55461,55468]
===
match
---
atom_expr [10948,10958]
atom_expr [10948,10958]
===
match
---
operator: == [59890,59892]
operator: == [59890,59892]
===
match
---
string: """         test that running task which returns AirflowSkipOperator will end         up in a SKIPPED state.         """ [17711,17831]
string: """         test that running task which returns AirflowSkipOperator will end         up in a SKIPPED state.         """ [17711,17831]
===
match
---
name: end_date [22821,22829]
name: end_date [22821,22829]
===
match
---
arith_expr [22590,22649]
arith_expr [22590,22649]
===
match
---
testlist_comp [57676,57727]
testlist_comp [57676,57727]
===
match
---
name: ti3 [63355,63358]
name: ti3 [63355,63358]
===
match
---
trailer [65292,65299]
trailer [65292,65299]
===
match
---
simple_stmt [28360,28412]
simple_stmt [28360,28412]
===
match
---
name: execution_date [15782,15796]
name: execution_date [15782,15796]
===
match
---
name: RUNNING [66002,66009]
name: RUNNING [66002,66009]
===
match
---
name: _env_var_check_callback [65665,65688]
name: _env_var_check_callback [65665,65688]
===
match
---
simple_stmt [5989,6036]
simple_stmt [5989,6036]
===
match
---
operator: , [13541,13542]
operator: , [13541,13542]
===
match
---
name: pool [40174,40178]
name: pool [40174,40178]
===
match
---
operator: , [28796,28797]
operator: , [28796,28797]
===
match
---
name: max_tries [77373,77382]
name: max_tries [77373,77382]
===
match
---
name: execution_date [5851,5865]
name: execution_date [5851,5865]
===
match
---
argument [28656,28665]
argument [28656,28665]
===
match
---
operator: = [8537,8538]
operator: = [8537,8538]
===
match
---
name: datetime [23260,23268]
name: datetime [23260,23268]
===
match
---
name: ti [66069,66071]
name: ti [66069,66071]
===
match
---
atom_expr [59533,59606]
atom_expr [59533,59606]
===
match
---
simple_stmt [19905,20001]
simple_stmt [19905,20001]
===
match
---
atom_expr [31329,31337]
atom_expr [31329,31337]
===
match
---
name: TI [22150,22152]
name: TI [22150,22152]
===
match
---
name: state [52094,52099]
name: state [52094,52099]
===
match
---
atom_expr [14161,14199]
atom_expr [14161,14199]
===
match
---
simple_stmt [6841,6890]
simple_stmt [6841,6890]
===
match
---
operator: = [76823,76824]
operator: = [76823,76824]
===
match
---
argument [57223,57255]
argument [57223,57255]
===
match
---
arglist [6860,6888]
arglist [6860,6888]
===
match
---
name: Session [1125,1132]
name: Session [1125,1132]
===
match
---
string: 'test_raise_airflow_fail_exception' [63891,63926]
string: 'test_raise_airflow_fail_exception' [63891,63926]
===
match
---
arglist [68254,68302]
arglist [68254,68302]
===
match
---
import_from [1579,1630]
import_from [1579,1630]
===
match
---
atom_expr [28835,28882]
atom_expr [28835,28882]
===
match
---
comparison [55414,55477]
comparison [55414,55477]
===
match
---
name: state [25663,25668]
name: state [25663,25668]
===
match
---
argument [38869,38901]
argument [38869,38901]
===
match
---
name: task [79787,79791]
name: task [79787,79791]
===
match
---
operator: , [33505,33506]
operator: , [33505,33506]
===
match
---
trailer [60224,60240]
trailer [60224,60240]
===
match
---
name: max_active_runs [10394,10409]
name: max_active_runs [10394,10409]
===
match
---
operator: = [34383,34384]
operator: = [34383,34384]
===
match
---
parameters [3886,3892]
parameters [3886,3892]
===
match
---
atom_expr [8132,8139]
atom_expr [8132,8139]
===
match
---
operator: = [40312,40313]
operator: = [40312,40313]
===
match
---
name: TI [41728,41730]
name: TI [41728,41730]
===
match
---
atom_expr [7715,7773]
atom_expr [7715,7773]
===
match
---
argument [17934,17974]
argument [17934,17974]
===
match
---
trailer [47527,47536]
trailer [47527,47536]
===
match
---
assert_stmt [22886,22907]
assert_stmt [22886,22907]
===
match
---
number: 10 [66429,66431]
number: 10 [66429,66431]
===
match
---
string: 'a test value' [57646,57660]
string: 'a test value' [57646,57660]
===
match
---
name: models [18629,18635]
name: models [18629,18635]
===
match
---
atom_expr [68375,68391]
atom_expr [68375,68391]
===
match
---
operator: = [48163,48164]
operator: = [48163,48164]
===
match
---
operator: , [58676,58677]
operator: , [58676,58677]
===
match
---
name: dag_run [75835,75842]
name: dag_run [75835,75842]
===
match
---
atom_expr [75187,75207]
atom_expr [75187,75207]
===
match
---
name: run [25498,25501]
name: run [25498,25501]
===
match
---
argument [40651,40671]
argument [40651,40671]
===
match
---
operator: , [67990,67991]
operator: , [67990,67991]
===
match
---
operator: = [78358,78359]
operator: = [78358,78359]
===
match
---
operator: = [66762,66763]
operator: = [66762,66763]
===
match
---
trailer [71328,71356]
trailer [71328,71356]
===
match
---
arglist [76566,76603]
arglist [76566,76603]
===
match
---
dictorsetmaker [16711,16723]
dictorsetmaker [16711,16723]
===
match
---
operator: = [20281,20282]
operator: = [20281,20282]
===
match
---
name: start_date [34300,34310]
name: start_date [34300,34310]
===
match
---
number: 0 [54662,54663]
number: 0 [54662,54663]
===
match
---
suite [68403,68460]
suite [68403,68460]
===
match
---
expr_stmt [28360,28411]
expr_stmt [28360,28411]
===
match
---
and_test [62078,62128]
and_test [62078,62128]
===
match
---
operator: , [12204,12205]
operator: , [12204,12205]
===
match
---
trailer [38152,38204]
trailer [38152,38204]
===
match
---
simple_stmt [35147,35179]
simple_stmt [35147,35179]
===
match
---
operator: = [55960,55961]
operator: = [55960,55961]
===
match
---
operator: = [39059,39060]
operator: = [39059,39060]
===
match
---
assert_stmt [65096,65159]
assert_stmt [65096,65159]
===
match
---
simple_stmt [21371,21403]
simple_stmt [21371,21403]
===
match
---
operator: = [28460,28461]
operator: = [28460,28461]
===
match
---
trailer [56330,56448]
trailer [56330,56448]
===
match
---
parameters [7392,7398]
parameters [7392,7398]
===
match
---
name: task [47806,47810]
name: task [47806,47810]
===
match
---
atom_expr [77730,77748]
atom_expr [77730,77748]
===
match
---
simple_stmt [77213,77253]
simple_stmt [77213,77253]
===
match
---
operator: , [15018,15019]
operator: , [15018,15019]
===
match
---
name: task_id [79616,79623]
name: task_id [79616,79623]
===
match
---
string: "test retry handling" [62613,62634]
string: "test retry handling" [62613,62634]
===
match
---
simple_stmt [47242,47271]
simple_stmt [47242,47271]
===
match
---
decorator [57570,57913]
decorator [57570,57913]
===
match
---
name: dag_id [51771,51777]
name: dag_id [51771,51777]
===
match
---
argument [79630,79637]
argument [79630,79637]
===
match
---
atom_expr [26946,27020]
atom_expr [26946,27020]
===
match
---
name: ti [52393,52395]
name: ti [52393,52395]
===
match
---
name: execution_date [78568,78582]
name: execution_date [78568,78582]
===
match
---
string: 'test_pool' [14096,14107]
string: 'test_pool' [14096,14107]
===
match
---
simple_stmt [66508,66742]
simple_stmt [66508,66742]
===
match
---
name: scenario [53959,53967]
name: scenario [53959,53967]
===
match
---
atom_expr [17991,18234]
atom_expr [17991,18234]
===
match
---
string: 'reschedule' [24579,24591]
string: 'reschedule' [24579,24591]
===
match
---
trailer [4134,4143]
trailer [4134,4143]
===
match
---
atom_expr [56051,56077]
atom_expr [56051,56077]
===
match
---
operator: = [10463,10464]
operator: = [10463,10464]
===
match
---
trailer [37040,37042]
trailer [37040,37042]
===
match
---
arglist [24490,24847]
arglist [24490,24847]
===
match
---
number: 2 [20365,20366]
number: 2 [20365,20366]
===
match
---
operator: = [73816,73817]
operator: = [73816,73817]
===
match
---
number: 60 [26868,26870]
number: 60 [26868,26870]
===
match
---
parameters [10261,10267]
parameters [10261,10267]
===
match
---
name: ti [61029,61031]
name: ti [61029,61031]
===
match
---
atom_expr [16527,16540]
atom_expr [16527,16540]
===
match
---
operator: = [56074,56075]
operator: = [56074,56075]
===
match
---
operator: , [11400,11401]
operator: , [11400,11401]
===
match
---
operator: = [50196,50197]
operator: = [50196,50197]
===
match
---
simple_stmt [24397,24449]
simple_stmt [24397,24449]
===
match
---
atom_expr [8425,8460]
atom_expr [8425,8460]
===
match
---
name: ti_1 [56614,56618]
name: ti_1 [56614,56618]
===
match
---
name: session [45181,45188]
name: session [45181,45188]
===
match
---
argument [68609,68642]
argument [68609,68642]
===
match
---
operator: = [76104,76105]
operator: = [76104,76105]
===
match
---
trailer [75422,75427]
trailer [75422,75427]
===
match
---
suite [79526,80313]
suite [79526,80313]
===
match
---
trailer [55421,55424]
trailer [55421,55424]
===
match
---
string: 'a test value' [58097,58111]
string: 'a test value' [58097,58111]
===
match
---
testlist_star_expr [29975,29985]
testlist_star_expr [29975,29985]
===
match
---
operator: , [33734,33735]
operator: , [33734,33735]
===
match
---
name: end_date [4251,4259]
name: end_date [4251,4259]
===
match
---
suite [76018,76539]
suite [76018,76539]
===
match
---
operator: , [71866,71867]
operator: , [71866,71867]
===
match
---
expr_stmt [79595,79638]
expr_stmt [79595,79638]
===
match
---
simple_stmt [11638,11655]
simple_stmt [11638,11655]
===
match
---
operator: , [33863,33864]
operator: , [33863,33864]
===
match
---
name: stats_mock [67161,67171]
name: stats_mock [67161,67171]
===
match
---
arglist [65939,65975]
arglist [65939,65975]
===
match
---
atom_expr [14364,14377]
atom_expr [14364,14377]
===
match
---
argument [12946,12993]
argument [12946,12993]
===
match
---
string: 'test_no_xcom_push' [41368,41387]
string: 'test_no_xcom_push' [41368,41387]
===
match
---
simple_stmt [62785,62843]
simple_stmt [62785,62843]
===
match
---
atom_expr [23984,24010]
atom_expr [23984,24010]
===
match
---
operator: , [33186,33187]
operator: , [33186,33187]
===
match
---
name: self [2917,2921]
name: self [2917,2921]
===
match
---
number: 2 [33096,33097]
number: 2 [33096,33097]
===
match
---
trailer [74898,74915]
trailer [74898,74915]
===
match
---
atom [33471,33519]
atom [33471,33519]
===
match
---
operator: , [37118,37119]
operator: , [37118,37119]
===
match
---
name: task_id [41358,41365]
name: task_id [41358,41365]
===
match
---
param [17696,17700]
param [17696,17700]
===
match
---
operator: , [27541,27542]
operator: , [27541,27542]
===
match
---
name: timezone [64695,64703]
name: timezone [64695,64703]
===
match
---
operator: , [57458,57459]
operator: , [57458,57459]
===
match
---
trailer [27194,27210]
trailer [27194,27210]
===
match
---
simple_stmt [23202,23240]
simple_stmt [23202,23240]
===
match
---
operator: = [57024,57025]
operator: = [57024,57025]
===
match
---
operator: , [6098,6099]
operator: , [6098,6099]
===
match
---
suite [43516,43905]
suite [43516,43905]
===
match
---
name: max_delay [23127,23136]
name: max_delay [23127,23136]
===
match
---
name: raises [7080,7086]
name: raises [7080,7086]
===
match
---
atom_expr [44272,44285]
atom_expr [44272,44285]
===
match
---
operator: , [32793,32794]
operator: , [32793,32794]
===
match
---
name: result [38130,38136]
name: result [38130,38136]
===
match
---
operator: = [41673,41674]
operator: = [41673,41674]
===
match
---
name: dag_id [28377,28383]
name: dag_id [28377,28383]
===
match
---
simple_stmt [22461,22479]
simple_stmt [22461,22479]
===
match
---
trailer [79469,79471]
trailer [79469,79471]
===
match
---
parameters [17865,17867]
parameters [17865,17867]
===
match
---
argument [11261,11320]
argument [11261,11320]
===
match
---
operator: = [34518,34519]
operator: = [34518,34519]
===
match
---
name: ti [60078,60080]
name: ti [60078,60080]
===
match
---
atom_expr [66559,66583]
atom_expr [66559,66583]
===
match
---
name: start_date [4224,4234]
name: start_date [4224,4234]
===
match
---
name: dag [5807,5810]
name: dag [5807,5810]
===
match
---
name: dag_id [67373,67379]
name: dag_id [67373,67379]
===
match
---
atom_expr [48347,48394]
atom_expr [48347,48394]
===
match
---
atom_expr [66055,66072]
atom_expr [66055,66072]
===
match
---
name: task [15445,15449]
name: task [15445,15449]
===
match
---
simple_stmt [35901,35934]
simple_stmt [35901,35934]
===
match
---
trailer [61204,61211]
trailer [61204,61211]
===
match
---
name: dag [14281,14284]
name: dag [14281,14284]
===
match
---
number: 2 [33363,33364]
number: 2 [33363,33364]
===
match
---
name: expected_rendered_ti_fields [19905,19932]
name: expected_rendered_ti_fields [19905,19932]
===
match
---
name: now [60897,60900]
name: now [60897,60900]
===
match
---
trailer [6946,6948]
trailer [6946,6948]
===
match
---
expr_stmt [67248,67294]
expr_stmt [67248,67294]
===
match
---
string: 'dag' [46885,46890]
string: 'dag' [46885,46890]
===
match
---
except_clause [64211,64238]
except_clause [64211,64238]
===
match
---
atom_expr [40244,40282]
atom_expr [40244,40282]
===
match
---
testlist_comp [32576,32640]
testlist_comp [32576,32640]
===
match
---
expr_stmt [44387,44411]
expr_stmt [44387,44411]
===
match
---
name: state [71612,71617]
name: state [71612,71617]
===
match
---
operator: , [32174,32175]
operator: , [32174,32175]
===
match
---
arglist [40262,40281]
arglist [40262,40281]
===
match
---
string: 'test@test.test' [49842,49858]
string: 'test@test.test' [49842,49858]
===
match
---
name: op1 [5763,5766]
name: op1 [5763,5766]
===
match
---
trailer [15799,15814]
trailer [15799,15814]
===
match
---
string: 'B' [72277,72280]
string: 'B' [72277,72280]
===
match
---
operator: , [15550,15551]
operator: , [15550,15551]
===
match
---
operator: = [2935,2936]
operator: = [2935,2936]
===
match
---
atom_expr [77324,77338]
atom_expr [77324,77338]
===
match
---
number: 0 [15014,15015]
number: 0 [15014,15015]
===
match
---
name: UP_FOR_RETRY [20717,20729]
name: UP_FOR_RETRY [20717,20729]
===
match
---
name: DummyOperator [16143,16156]
name: DummyOperator [16143,16156]
===
match
---
name: TI [19128,19130]
name: TI [19128,19130]
===
match
---
name: SUCCESS [54705,54712]
name: SUCCESS [54705,54712]
===
match
---
name: models [61435,61441]
name: models [61435,61441]
===
match
---
name: run [16635,16638]
name: run [16635,16638]
===
match
---
trailer [22379,22391]
trailer [22379,22391]
===
match
---
argument [51179,51194]
argument [51179,51194]
===
match
---
name: value [41207,41212]
name: value [41207,41212]
===
match
---
string: 'xcom_value' [39989,40001]
string: 'xcom_value' [39989,40001]
===
match
---
simple_stmt [36376,36460]
simple_stmt [36376,36460]
===
match
---
name: ti [67050,67052]
name: ti [67050,67052]
===
match
---
operator: , [20369,20370]
operator: , [20369,20370]
===
match
---
trailer [54775,54796]
trailer [54775,54796]
===
match
---
testlist_star_expr [27550,27562]
testlist_star_expr [27550,27562]
===
match
---
expr_stmt [4455,4670]
expr_stmt [4455,4670]
===
match
---
name: datetime [4568,4576]
name: datetime [4568,4576]
===
match
---
name: dep [11857,11860]
name: dep [11857,11860]
===
match
---
assert_stmt [25756,25803]
assert_stmt [25756,25803]
===
match
---
string: 'airflow' [34530,34539]
string: 'airflow' [34530,34539]
===
match
---
name: task_id [14022,14029]
name: task_id [14022,14029]
===
match
---
number: 0 [20377,20378]
number: 0 [20377,20378]
===
match
---
atom_expr [62029,62062]
atom_expr [62029,62062]
===
match
---
simple_stmt [29940,29966]
simple_stmt [29940,29966]
===
match
---
name: end [75969,75972]
name: end [75969,75972]
===
match
---
name: run_type [78637,78645]
name: run_type [78637,78645]
===
match
---
expr_stmt [47442,47476]
expr_stmt [47442,47476]
===
match
---
trailer [60887,60896]
trailer [60887,60896]
===
match
---
operator: = [21653,21654]
operator: = [21653,21654]
===
match
---
operator: = [75123,75124]
operator: = [75123,75124]
===
match
---
atom_expr [77370,77382]
atom_expr [77370,77382]
===
match
---
name: operator [79856,79864]
name: operator [79856,79864]
===
match
---
name: State [65996,66001]
name: State [65996,66001]
===
match
---
operator: , [11447,11448]
operator: , [11447,11448]
===
match
---
name: test_run_pooling_task_with_skip [17664,17695]
name: test_run_pooling_task_with_skip [17664,17695]
===
match
---
parameters [53239,53276]
parameters [53239,53276]
===
match
---
operator: = [56467,56468]
operator: = [56467,56468]
===
match
---
operator: == [22995,22997]
operator: == [22995,22997]
===
match
---
name: start_date [46569,46579]
name: start_date [46569,46579]
===
match
---
name: datetime [56051,56059]
name: datetime [56051,56059]
===
match
---
trailer [73641,73643]
trailer [73641,73643]
===
match
---
decorator [35939,36162]
decorator [35939,36162]
===
match
---
operator: = [43690,43691]
operator: = [43690,43691]
===
match
---
name: TI [3259,3261]
name: TI [3259,3261]
===
match
---
trailer [71913,71921]
trailer [71913,71921]
===
match
---
operator: , [67476,67477]
operator: , [67476,67477]
===
match
---
name: state [78450,78455]
name: state [78450,78455]
===
match
---
name: owner [7750,7755]
name: owner [7750,7755]
===
match
---
trailer [29891,29896]
trailer [29891,29896]
===
match
---
operator: = [54781,54782]
operator: = [54781,54782]
===
match
---
operator: , [44728,44729]
operator: , [44728,44729]
===
match
---
trailer [70938,70993]
trailer [70938,70993]
===
match
---
name: time [821,825]
name: time [821,825]
===
match
---
operator: } [72247,72248]
operator: } [72247,72248]
===
match
---
trailer [9227,9284]
trailer [9227,9284]
===
match
---
name: ti [18463,18465]
name: ti [18463,18465]
===
match
---
argument [44810,44818]
argument [44810,44818]
===
match
---
simple_stmt [38784,38829]
simple_stmt [38784,38829]
===
match
---
simple_stmt [37576,37598]
simple_stmt [37576,37598]
===
match
---
operator: , [27972,27973]
operator: , [27972,27973]
===
match
---
name: task [60853,60857]
name: task [60853,60857]
===
match
---
simple_stmt [22689,22707]
simple_stmt [22689,22707]
===
match
---
trailer [72846,72851]
trailer [72846,72851]
===
match
---
name: DagRunType [56420,56430]
name: DagRunType [56420,56430]
===
match
---
arglist [47968,47983]
arglist [47968,47983]
===
match
---
name: callback_ran [51375,51387]
name: callback_ran [51375,51387]
===
match
---
simple_stmt [65707,65923]
simple_stmt [65707,65923]
===
match
---
name: dag [79536,79539]
name: dag [79536,79539]
===
match
---
name: State [66681,66686]
name: State [66681,66686]
===
match
---
name: task_id [56709,56716]
name: task_id [56709,56716]
===
match
---
name: parameterized [77984,77997]
name: parameterized [77984,77997]
===
match
---
name: DAG [30476,30479]
name: DAG [30476,30479]
===
match
---
simple_stmt [35380,35463]
simple_stmt [35380,35463]
===
match
---
name: task [69127,69131]
name: task [69127,69131]
===
match
---
param [29174,29205]
param [29174,29205]
===
match
---
operator: , [34404,34405]
operator: , [34404,34405]
===
match
---
trailer [42906,42910]
trailer [42906,42910]
===
match
---
arglist [57505,57563]
arglist [57505,57563]
===
match
---
operator: == [30235,30237]
operator: == [30235,30237]
===
match
---
name: date1 [27088,27093]
name: date1 [27088,27093]
===
match
---
trailer [30148,30164]
trailer [30148,30164]
===
match
---
expr_stmt [59820,59867]
expr_stmt [59820,59867]
===
match
---
operator: = [20105,20106]
operator: = [20105,20106]
===
match
---
name: dag [43646,43649]
name: dag [43646,43649]
===
match
---
name: date3 [27830,27835]
name: date3 [27830,27835]
===
match
---
name: TI [44917,44919]
name: TI [44917,44919]
===
match
---
name: dag [14074,14077]
name: dag [14074,14077]
===
match
---
testlist_comp [72588,72992]
testlist_comp [72588,72992]
===
match
---
name: expected_pod_spec [69263,69280]
name: expected_pod_spec [69263,69280]
===
match
---
operator: , [78353,78354]
operator: , [78353,78354]
===
match
---
atom_expr [50198,50249]
atom_expr [50198,50249]
===
match
---
name: end_date [22624,22632]
name: end_date [22624,22632]
===
match
---
operator: = [37412,37413]
operator: = [37412,37413]
===
match
---
operator: , [36136,36137]
operator: , [36136,36137]
===
match
---
operator: = [5845,5846]
operator: = [5845,5846]
===
match
---
operator: = [44514,44515]
operator: = [44514,44515]
===
match
---
assert_stmt [71205,71241]
assert_stmt [71205,71241]
===
match
---
name: failed [34886,34892]
name: failed [34886,34892]
===
match
---
trailer [63005,63015]
trailer [63005,63015]
===
match
---
param [30455,30459]
param [30455,30459]
===
match
---
operator: , [49416,49417]
operator: , [49416,49417]
===
match
---
arglist [24875,24918]
arglist [24875,24918]
===
match
---
operator: , [6485,6486]
operator: , [6485,6486]
===
match
---
name: start_date [43108,43118]
name: start_date [43108,43118]
===
match
---
atom_expr [14327,14344]
atom_expr [14327,14344]
===
match
---
operator: , [33766,33767]
operator: , [33766,33767]
===
match
---
name: xcom_push [40591,40600]
name: xcom_push [40591,40600]
===
match
---
atom_expr [55186,55199]
atom_expr [55186,55199]
===
match
---
name: execution_date [51946,51960]
name: execution_date [51946,51960]
===
match
---
number: 0 [6097,6098]
number: 0 [6097,6098]
===
match
---
suite [25413,26128]
suite [25413,26128]
===
match
---
operator: , [41038,41039]
operator: , [41038,41039]
===
match
---
operator: = [42614,42615]
operator: = [42614,42615]
===
match
---
operator: = [65943,65944]
operator: = [65943,65944]
===
match
---
operator: = [63479,63480]
operator: = [63479,63480]
===
match
---
trailer [14716,14748]
trailer [14716,14748]
===
match
---
name: task [5549,5553]
name: task [5549,5553]
===
match
---
atom_expr [10600,10617]
atom_expr [10600,10617]
===
match
---
name: timezone [37025,37033]
name: timezone [37025,37033]
===
match
---
trailer [9937,10002]
trailer [9937,10002]
===
match
---
name: self [54568,54572]
name: self [54568,54572]
===
match
---
operator: = [40512,40513]
operator: = [40512,40513]
===
match
---
trailer [78916,78918]
trailer [78916,78918]
===
match
---
trailer [74888,74898]
trailer [74888,74898]
===
match
---
comparison [49645,49694]
comparison [49645,49694]
===
match
---
name: ti [77220,77222]
name: ti [77220,77222]
===
match
---
arglist [26847,26901]
arglist [26847,26901]
===
match
---
name: op_no_dag [6580,6589]
name: op_no_dag [6580,6589]
===
match
---
trailer [23363,23728]
trailer [23363,23728]
===
match
---
number: 0 [33105,33106]
number: 0 [33105,33106]
===
match
---
trailer [50211,50249]
trailer [50211,50249]
===
match
---
assert_stmt [41972,42045]
assert_stmt [41972,42045]
===
match
---
name: assert_command [67539,67553]
name: assert_command [67539,67553]
===
match
---
name: task_id [43706,43713]
name: task_id [43706,43713]
===
match
---
operator: = [5028,5029]
operator: = [5028,5029]
===
match
---
atom_expr [55552,55573]
atom_expr [55552,55573]
===
match
---
expr_stmt [60078,60125]
expr_stmt [60078,60125]
===
match
---
name: tzinfo [6558,6564]
name: tzinfo [6558,6564]
===
match
---
simple_stmt [63465,63515]
simple_stmt [63465,63515]
===
match
---
subscriptlist [51618,51647]
subscriptlist [51618,51647]
===
match
---
name: dag [76131,76134]
name: dag [76131,76134]
===
match
---
name: op1 [7511,7514]
name: op1 [7511,7514]
===
match
---
name: expected_output [57964,57979]
name: expected_output [57964,57979]
===
match
---
name: sensors [1696,1703]
name: sensors [1696,1703]
===
match
---
arglist [49822,49858]
arglist [49822,49858]
===
match
---
assert_stmt [68074,68115]
assert_stmt [68074,68115]
===
match
---
name: owner [11385,11390]
name: owner [11385,11390]
===
match
---
operator: , [21875,21876]
operator: , [21875,21876]
===
match
---
name: session [71294,71301]
name: session [71294,71301]
===
match
---
trailer [48007,48019]
trailer [48007,48019]
===
match
---
operator: , [68530,68531]
operator: , [68530,68531]
===
match
---
string: 'test-dag' [58564,58574]
string: 'test-dag' [58564,58574]
===
match
---
argument [22606,22617]
argument [22606,22617]
===
match
---
name: op [7015,7017]
name: op [7015,7017]
===
match
---
arglist [60740,60826]
arglist [60740,60826]
===
match
---
name: get_previous_execution_date [54665,54692]
name: get_previous_execution_date [54665,54692]
===
match
---
atom [71831,71884]
atom [71831,71884]
===
match
---
operator: = [38756,38757]
operator: = [38756,38757]
===
match
---
atom_expr [56648,56660]
atom_expr [56648,56660]
===
match
---
name: staticmethod [3438,3450]
name: staticmethod [3438,3450]
===
match
---
operator: , [44808,44809]
operator: , [44808,44809]
===
match
---
trailer [28372,28376]
trailer [28372,28376]
===
match
---
name: days [5063,5067]
name: days [5063,5067]
===
match
---
string: 'baz' [16283,16288]
string: 'baz' [16283,16288]
===
match
---
operator: , [44155,44156]
operator: , [44155,44156]
===
match
---
name: DummyOperator [44780,44793]
name: DummyOperator [44780,44793]
===
match
---
name: task [9822,9826]
name: task [9822,9826]
===
match
---
assert_stmt [21411,21437]
assert_stmt [21411,21437]
===
match
---
argument [37129,37144]
argument [37129,37144]
===
match
---
dictorsetmaker [48725,48842]
dictorsetmaker [48725,48842]
===
match
---
atom_expr [80198,80262]
atom_expr [80198,80262]
===
match
---
expr_stmt [43141,43193]
expr_stmt [43141,43193]
===
match
---
operator: = [34222,34223]
operator: = [34222,34223]
===
match
---
trailer [22952,22972]
trailer [22952,22972]
===
match
---
trailer [13300,13302]
trailer [13300,13302]
===
match
---
trailer [34640,34648]
trailer [34640,34648]
===
match
---
name: scheduler_job [75939,75952]
name: scheduler_job [75939,75952]
===
match
---
name: ti_list [55648,55655]
name: ti_list [55648,55655]
===
match
---
name: session [10118,10125]
name: session [10118,10125]
===
match
---
operator: = [39103,39104]
operator: = [39103,39104]
===
match
---
arglist [9050,9188]
arglist [9050,9188]
===
match
---
atom_expr [67124,67145]
atom_expr [67124,67145]
===
match
---
operator: , [51814,51815]
operator: , [51814,51815]
===
match
---
name: datetime [64704,64712]
name: datetime [64704,64712]
===
match
---
operator: , [79385,79386]
operator: , [79385,79386]
===
match
---
trailer [4988,4998]
trailer [4988,4998]
===
match
---
expr_stmt [74534,74581]
expr_stmt [74534,74581]
===
match
---
name: TI [61840,61842]
name: TI [61840,61842]
===
match
---
testlist_comp [32016,32062]
testlist_comp [32016,32062]
===
match
---
argument [44157,44164]
argument [44157,44164]
===
match
---
operator: = [38920,38921]
operator: = [38920,38921]
===
match
---
number: 2016 [22105,22109]
number: 2016 [22105,22109]
===
match
---
parameters [47739,47745]
parameters [47739,47745]
===
match
---
arglist [50004,50018]
arglist [50004,50018]
===
match
---
trailer [34749,35033]
trailer [34749,35033]
===
match
---
number: 2 [27865,27866]
number: 2 [27865,27866]
===
match
---
argument [28760,28809]
argument [28760,28809]
===
match
---
assert_stmt [24963,24988]
assert_stmt [24963,24988]
===
match
---
trailer [18292,18294]
trailer [18292,18294]
===
match
---
simple_stmt [46654,46693]
simple_stmt [46654,46693]
===
match
---
atom_expr [65936,65976]
atom_expr [65936,65976]
===
match
---
operator: , [33546,33547]
operator: , [33546,33547]
===
match
---
operator: , [28716,28717]
operator: , [28716,28717]
===
match
---
number: 2 [27749,27750]
number: 2 [27749,27750]
===
match
---
annassign [2563,2585]
annassign [2563,2585]
===
match
---
arglist [22153,22191]
arglist [22153,22191]
===
match
---
expr_stmt [61620,61825]
expr_stmt [61620,61825]
===
match
---
operator: = [10531,10532]
operator: = [10531,10532]
===
match
---
name: task [11222,11226]
name: task [11222,11226]
===
match
---
number: 0 [33862,33863]
number: 0 [33862,33863]
===
match
---
simple_stmt [49244,49297]
simple_stmt [49244,49297]
===
match
---
name: dag [64447,64450]
name: dag [64447,64450]
===
match
---
name: ti [34808,34810]
name: ti [34808,34810]
===
match
---
expr_stmt [5713,5754]
expr_stmt [5713,5754]
===
match
---
atom_expr [22590,22618]
atom_expr [22590,22618]
===
match
---
trailer [29628,29639]
trailer [29628,29639]
===
match
---
name: done [26679,26683]
name: done [26679,26683]
===
match
---
name: task_d [74324,74330]
name: task_d [74324,74330]
===
match
---
operator: = [10569,10570]
operator: = [10569,10570]
===
match
---
arglist [58131,58166]
arglist [58131,58166]
===
match
---
funcdef [3874,3918]
funcdef [3874,3918]
===
match
---
trailer [10870,10874]
trailer [10870,10874]
===
match
---
trailer [71193,71195]
trailer [71193,71195]
===
match
---
operator: , [27709,27710]
operator: , [27709,27710]
===
match
---
string: "A -> C & B -> C, when A is QUEUED but B has FAILED, C is marked UPSTREAM_FAILED." [73330,73412]
string: "A -> C & B -> C, when A is QUEUED but B has FAILED, C is marked UPSTREAM_FAILED." [73330,73412]
===
match
---
atom_expr [5998,6035]
atom_expr [5998,6035]
===
match
---
argument [53068,53074]
argument [53068,53074]
===
match
---
argument [74348,74359]
argument [74348,74359]
===
match
---
atom_expr [39032,39066]
atom_expr [39032,39066]
===
match
---
name: utcnow [22242,22248]
name: utcnow [22242,22248]
===
match
---
operator: , [46671,46672]
operator: , [46671,46672]
===
match
---
trailer [66122,66124]
trailer [66122,66124]
===
match
---
atom_expr [27840,27863]
atom_expr [27840,27863]
===
match
---
operator: , [73312,73313]
operator: , [73312,73313]
===
match
---
simple_stmt [51747,51833]
simple_stmt [51747,51833]
===
match
---
trailer [40347,40384]
trailer [40347,40384]
===
match
---
operator: , [71635,71636]
operator: , [71635,71636]
===
match
---
operator: = [62540,62541]
operator: = [62540,62541]
===
match
---
string: 'test-dag' [59983,59993]
string: 'test-dag' [59983,59993]
===
match
---
operator: = [71163,71164]
operator: = [71163,71164]
===
match
---
name: DummyOperator [47070,47083]
name: DummyOperator [47070,47083]
===
match
---
trailer [59541,59545]
trailer [59541,59545]
===
match
---
operator: = [13993,13994]
operator: = [13993,13994]
===
match
---
expr_stmt [47173,47191]
expr_stmt [47173,47191]
===
match
---
operator: , [59063,59064]
operator: , [59063,59064]
===
match
---
testlist_comp [72590,72634]
testlist_comp [72590,72634]
===
match
---
atom_expr [6342,6375]
atom_expr [6342,6375]
===
match
---
name: session [3740,3747]
name: session [3740,3747]
===
match
---
simple_stmt [75453,75493]
simple_stmt [75453,75493]
===
match
---
atom_expr [19128,19175]
atom_expr [19128,19175]
===
match
---
atom_expr [63272,63313]
atom_expr [63272,63313]
===
match
---
trailer [60896,60900]
trailer [60896,60900]
===
match
---
assert_stmt [53502,53581]
assert_stmt [53502,53581]
===
match
---
string: 'task' [44802,44808]
string: 'task' [44802,44808]
===
match
---
atom_expr [27240,27250]
atom_expr [27240,27250]
===
match
---
expr_stmt [44911,44988]
expr_stmt [44911,44988]
===
match
---
trailer [15059,15104]
trailer [15059,15104]
===
match
---
trailer [20873,20879]
trailer [20873,20879]
===
match
---
operator: = [60608,60609]
operator: = [60608,60609]
===
match
---
operator: , [15814,15815]
operator: , [15814,15815]
===
match
---
simple_stmt [41723,41788]
simple_stmt [41723,41788]
===
match
---
name: execution_date [52280,52294]
name: execution_date [52280,52294]
===
match
---
name: date3 [26287,26292]
name: date3 [26287,26292]
===
match
---
trailer [31101,31103]
trailer [31101,31103]
===
match
---
name: value [40616,40621]
name: value [40616,40621]
===
match
---
operator: = [53368,53369]
operator: = [53368,53369]
===
match
---
arglist [9664,9803]
arglist [9664,9803]
===
match
---
dotted_name [934,947]
dotted_name [934,947]
===
match
---
operator: , [27013,27014]
operator: , [27013,27014]
===
match
---
expr_stmt [37936,37993]
expr_stmt [37936,37993]
===
match
---
name: TI [67443,67445]
name: TI [67443,67445]
===
match
---
string: 'AIRFLOW_CTX_EXECUTION_DATE' [65214,65242]
string: 'AIRFLOW_CTX_EXECUTION_DATE' [65214,65242]
===
match
---
argument [4067,4090]
argument [4067,4090]
===
match
---
trailer [16082,16114]
trailer [16082,16114]
===
match
---
name: start_date [41663,41673]
name: start_date [41663,41673]
===
match
---
operator: = [18184,18185]
operator: = [18184,18185]
===
match
---
name: task_instance_d [75407,75422]
name: task_instance_d [75407,75422]
===
match
---
name: run [39146,39149]
name: run [39146,39149]
===
match
---
expr_stmt [43605,43675]
expr_stmt [43605,43675]
===
match
---
name: test_try_number [43914,43929]
name: test_try_number [43914,43929]
===
match
---
argument [20027,20055]
argument [20027,20055]
===
match
---
expr_stmt [41396,41432]
expr_stmt [41396,41432]
===
match
---
argument [48255,48262]
argument [48255,48262]
===
match
---
trailer [12251,12253]
trailer [12251,12253]
===
match
---
name: expect_state [35166,35178]
name: expect_state [35166,35178]
===
match
---
string: 'all_done' [33841,33851]
string: 'all_done' [33841,33851]
===
match
---
operator: , [36887,36888]
operator: , [36887,36888]
===
match
---
operator: , [72394,72395]
operator: , [72394,72395]
===
match
---
number: 1 [17336,17337]
number: 1 [17336,17337]
===
match
---
operator: = [62425,62426]
operator: = [62425,62426]
===
match
---
name: task [43795,43799]
name: task [43795,43799]
===
match
---
number: 2 [53606,53607]
number: 2 [53606,53607]
===
match
---
argument [49325,49361]
argument [49325,49361]
===
match
---
name: session [11589,11596]
name: session [11589,11596]
===
match
---
and_test [4220,4267]
and_test [4220,4267]
===
match
---
trailer [43830,43837]
trailer [43830,43837]
===
match
---
name: TI [76949,76951]
name: TI [76949,76951]
===
match
---
operator: , [36575,36576]
operator: , [36575,36576]
===
match
---
operator: = [18853,18854]
operator: = [18853,18854]
===
match
---
number: 2016 [14179,14183]
number: 2016 [14179,14183]
===
match
---
operator: , [61474,61475]
operator: , [61474,61475]
===
match
---
name: ti [21223,21225]
name: ti [21223,21225]
===
match
---
atom_expr [51145,51165]
atom_expr [51145,51165]
===
match
---
operator: == [48562,48564]
operator: == [48562,48564]
===
match
---
operator: , [77033,77034]
operator: , [77033,77034]
===
match
---
operator: = [12060,12061]
operator: = [12060,12061]
===
match
---
operator: , [30602,30603]
operator: , [30602,30603]
===
match
---
operator: , [54617,54618]
operator: , [54617,54618]
===
match
---
operator: = [42521,42522]
operator: = [42521,42522]
===
match
---
simple_stmt [77180,77208]
simple_stmt [77180,77208]
===
match
---
operator: , [32091,32092]
operator: , [32091,32092]
===
match
---
operator: , [38176,38177]
operator: , [38176,38177]
===
match
---
name: now [46688,46691]
name: now [46688,46691]
===
match
---
name: test_execute_callback [60301,60322]
name: test_execute_callback [60301,60322]
===
match
---
name: date2 [26861,26866]
name: date2 [26861,26866]
===
match
---
operator: = [10281,10282]
operator: = [10281,10282]
===
match
---
operator: = [24807,24808]
operator: = [24807,24808]
===
match
---
name: task_id [67040,67047]
name: task_id [67040,67047]
===
match
---
name: task [47811,47815]
name: task [47811,47815]
===
match
---
name: isoformat [67864,67873]
name: isoformat [67864,67873]
===
match
---
trailer [14268,14270]
trailer [14268,14270]
===
match
---
trailer [44274,44285]
trailer [44274,44285]
===
match
---
argument [54963,54982]
argument [54963,54982]
===
match
---
trailer [61031,61046]
trailer [61031,61046]
===
match
---
name: python_callable [74147,74162]
name: python_callable [74147,74162]
===
match
---
operator: , [32764,32765]
operator: , [32764,32765]
===
match
---
assert_stmt [46426,46459]
assert_stmt [46426,46459]
===
match
---
trailer [75739,75756]
trailer [75739,75756]
===
match
---
name: DagRunType [19303,19313]
name: DagRunType [19303,19313]
===
match
---
operator: , [3794,3795]
operator: , [3794,3795]
===
match
---
simple_stmt [30312,30402]
simple_stmt [30312,30402]
===
match
---
operator: , [34944,34945]
operator: , [34944,34945]
===
match
---
arglist [66303,66433]
arglist [66303,66433]
===
match
---
operator: = [9988,9989]
operator: = [9988,9989]
===
match
---
string: 'test' [76119,76125]
string: 'test' [76119,76125]
===
match
---
operator: = [8629,8630]
operator: = [8629,8630]
===
match
---
atom_expr [10207,10217]
atom_expr [10207,10217]
===
match
---
operator: , [48793,48794]
operator: , [48793,48794]
===
match
---
operator: , [32589,32590]
operator: , [32589,32590]
===
match
---
string: "test failure handling" [61942,61965]
string: "test failure handling" [61942,61965]
===
match
---
name: datetime [78419,78427]
name: datetime [78419,78427]
===
match
---
string: "override" [47358,47368]
string: "override" [47358,47368]
===
match
---
name: DEFAULT_DATE [5633,5645]
name: DEFAULT_DATE [5633,5645]
===
match
---
operator: , [26870,26871]
operator: , [26870,26871]
===
match
---
number: 1 [19368,19369]
number: 1 [19368,19369]
===
match
---
name: test_not_requeue_non_requeueable_task_instance [10968,11014]
name: test_not_requeue_non_requeueable_task_instance [10968,11014]
===
match
---
string: 'all_failed' [32879,32891]
string: 'all_failed' [32879,32891]
===
match
---
operator: , [52278,52279]
operator: , [52278,52279]
===
match
---
string: 'airflow' [16232,16241]
string: 'airflow' [16232,16241]
===
match
---
number: 1 [63224,63225]
number: 1 [63224,63225]
===
match
---
trailer [2779,2787]
trailer [2779,2787]
===
match
---
name: execution_date [17460,17474]
name: execution_date [17460,17474]
===
match
---
argument [35058,35091]
argument [35058,35091]
===
match
---
operator: = [40034,40035]
operator: = [40034,40035]
===
match
---
name: end_date [25882,25890]
name: end_date [25882,25890]
===
match
---
operator: , [38934,38935]
operator: , [38934,38935]
===
match
---
atom_expr [29509,29523]
atom_expr [29509,29523]
===
match
---
number: 2 [33745,33746]
number: 2 [33745,33746]
===
match
---
name: execution_date [43807,43821]
name: execution_date [43807,43821]
===
match
---
operator: , [47815,47816]
operator: , [47815,47816]
===
match
---
simple_stmt [51497,51530]
simple_stmt [51497,51530]
===
match
---
name: ti [31083,31085]
name: ti [31083,31085]
===
match
---
trailer [9455,9457]
trailer [9455,9457]
===
match
---
trailer [30129,30135]
trailer [30129,30135]
===
match
---
trailer [74809,74817]
trailer [74809,74817]
===
match
---
name: ti [78376,78378]
name: ti [78376,78378]
===
match
---
operator: = [17379,17380]
operator: = [17379,17380]
===
match
---
name: datetime [18827,18835]
name: datetime [18827,18835]
===
match
---
name: ti [78447,78449]
name: ti [78447,78449]
===
match
---
name: task [30990,30994]
name: task [30990,30994]
===
match
---
number: 0 [32096,32097]
number: 0 [32096,32097]
===
match
---
trailer [52189,52193]
trailer [52189,52193]
===
match
---
name: owner [18145,18150]
name: owner [18145,18150]
===
match
---
operator: = [46164,46165]
operator: = [46164,46165]
===
match
---
operator: = [44567,44568]
operator: = [44567,44568]
===
match
---
dotted_name [55019,55039]
dotted_name [55019,55039]
===
match
---
operator: = [48375,48376]
operator: = [48375,48376]
===
match
---
name: clean_db [3907,3915]
name: clean_db [3907,3915]
===
match
---
simple_stmt [27653,27678]
simple_stmt [27653,27678]
===
match
---
operator: , [33803,33804]
operator: , [33803,33804]
===
match
---
name: DummyOperator [43692,43705]
name: DummyOperator [43692,43705]
===
match
---
name: test_timezone_awareness [5335,5358]
name: test_timezone_awareness [5335,5358]
===
match
---
name: expected_start_date [25840,25859]
name: expected_start_date [25840,25859]
===
match
---
name: dag [51878,51881]
name: dag [51878,51881]
===
match
---
name: dag_id [61446,61452]
name: dag_id [61446,61452]
===
match
---
trailer [14460,14475]
trailer [14460,14475]
===
match
---
name: task2 [62270,62275]
name: task2 [62270,62275]
===
match
---
operator: = [18386,18387]
operator: = [18386,18387]
===
match
---
name: dep_patch [11892,11901]
name: dep_patch [11892,11901]
===
match
---
trailer [58805,58821]
trailer [58805,58821]
===
match
---
operator: , [79305,79306]
operator: , [79305,79306]
===
match
---
simple_stmt [7709,7774]
simple_stmt [7709,7774]
===
match
---
trailer [55424,55448]
trailer [55424,55448]
===
match
---
trailer [38705,38726]
trailer [38705,38726]
===
match
---
name: airflow [2042,2049]
name: airflow [2042,2049]
===
match
---
param [41242,41246]
param [41242,41246]
===
match
---
comparison [60469,60528]
comparison [60469,60528]
===
match
---
assert_stmt [28891,28917]
assert_stmt [28891,28917]
===
match
---
name: all [35054,35057]
name: all [35054,35057]
===
match
---
name: session [3060,3067]
name: session [3060,3067]
===
match
---
name: start_date [59637,59647]
name: start_date [59637,59647]
===
match
---
operator: = [11053,11054]
operator: = [11053,11054]
===
match
---
suite [3470,3661]
suite [3470,3661]
===
match
---
operator: , [37833,37834]
operator: , [37833,37834]
===
match
---
name: DummyOperator [4461,4474]
name: DummyOperator [4461,4474]
===
match
---
atom_expr [13256,13329]
atom_expr [13256,13329]
===
match
---
trailer [43902,43904]
trailer [43902,43904]
===
match
---
name: timezone [49278,49286]
name: timezone [49278,49286]
===
match
---
name: owner [14121,14126]
name: owner [14121,14126]
===
match
---
number: 5 [78099,78100]
number: 7 [78099,78100]
===
match
---
name: SCHEDULED [38968,38977]
name: SCHEDULED [38968,38977]
===
match
---
simple_stmt [57266,57311]
simple_stmt [57266,57311]
===
match
---
number: 1 [20618,20619]
number: 1 [20618,20619]
===
match
---
atom_expr [67077,67120]
atom_expr [67077,67120]
===
match
---
operator: , [4659,4660]
operator: , [4659,4660]
===
match
---
operator: = [26267,26268]
operator: = [26267,26268]
===
match
---
atom [15584,15598]
atom [15584,15598]
===
match
---
expr_stmt [15689,15741]
expr_stmt [15689,15741]
===
match
---
name: ti [47798,47800]
name: ti [47798,47800]
===
match
---
argument [38472,38490]
argument [38472,38490]
===
match
---
name: execution_date [15071,15085]
name: execution_date [15071,15085]
===
match
---
trailer [60677,60686]
trailer [60677,60686]
===
match
---
operator: } [71960,71961]
operator: } [71960,71961]
===
match
---
atom_expr [78263,78307]
atom_expr [78263,78307]
===
match
---
dotted_name [2107,2120]
dotted_name [2107,2120]
===
match
---
name: run_type [16554,16562]
name: run_type [16554,16562]
===
match
---
name: ti [2749,2751]
name: ti [2749,2751]
===
match
---
name: RUNNING [30843,30850]
name: RUNNING [30843,30850]
===
match
---
operator: = [43144,43145]
operator: = [43144,43145]
===
match
---
simple_stmt [38213,38245]
simple_stmt [38213,38245]
===
match
---
atom_expr [40394,40544]
atom_expr [40394,40544]
===
match
---
trailer [11042,11046]
trailer [11042,11046]
===
match
---
argument [8599,8611]
argument [8599,8611]
===
match
---
atom_expr [31083,31103]
atom_expr [31083,31103]
===
match
---
trailer [66423,66432]
trailer [66423,66432]
===
match
---
operator: , [71407,71408]
operator: , [71407,71408]
===
match
---
operator: , [29127,29128]
operator: , [29127,29128]
===
match
---
operator: , [10526,10527]
operator: , [10526,10527]
===
match
---
string: 'test_xcom' [41027,41038]
string: 'test_xcom' [41027,41038]
===
match
---
trailer [3582,3584]
trailer [3582,3584]
===
match
---
name: execution_date [47125,47139]
name: execution_date [47125,47139]
===
match
---
string: 'name' [70526,70532]
string: 'name' [70526,70532]
===
match
---
atom_expr [26990,27013]
atom_expr [26990,27013]
===
match
---
name: task_concurrency [10537,10553]
name: task_concurrency [10537,10553]
===
match
---
atom_expr [59682,59710]
atom_expr [59682,59710]
===
match
---
operator: = [23208,23209]
operator: = [23208,23209]
===
match
---
atom_expr [41005,41048]
atom_expr [41005,41048]
===
match
---
expr_stmt [53889,53968]
expr_stmt [53889,53968]
===
match
---
trailer [54787,54795]
trailer [54787,54795]
===
match
---
atom_expr [79251,79268]
atom_expr [79251,79268]
===
match
---
operator: = [51770,51771]
operator: = [51770,51771]
===
match
---
name: State [56384,56389]
name: State [56384,56389]
===
match
---
expr_stmt [2557,2585]
expr_stmt [2557,2585]
===
match
---
name: TaskReschedule [30318,30332]
name: TaskReschedule [30318,30332]
===
match
---
trailer [46661,46692]
trailer [46661,46692]
===
match
---
atom_expr [57408,57478]
atom_expr [57408,57478]
===
match
---
operator: , [6089,6090]
operator: , [6089,6090]
===
match
---
atom [73223,73290]
atom [73223,73290]
===
match
---
name: task [78389,78393]
name: task [78389,78393]
===
match
---
name: dag [8136,8139]
name: dag [8136,8139]
===
match
---
name: TaskReschedule [29785,29799]
name: TaskReschedule [29785,29799]
===
match
---
operator: , [57100,57101]
operator: , [57100,57101]
===
match
---
name: on_failure_callback [63118,63137]
name: on_failure_callback [63118,63137]
===
match
---
operator: = [51751,51752]
operator: = [51751,51752]
===
match
---
arglist [74683,74736]
arglist [74683,74736]
===
match
---
name: executor_config [16043,16058]
name: executor_config [16043,16058]
===
match
---
simple_stmt [31293,31314]
simple_stmt [31293,31314]
===
match
---
number: 0 [38718,38719]
number: 0 [38718,38719]
===
match
---
name: NONE [73200,73204]
name: NONE [73200,73204]
===
match
---
operator: = [74376,74377]
operator: = [74376,74377]
===
match
---
operator: = [28541,28542]
operator: = [28541,28542]
===
match
---
operator: = [79034,79035]
operator: = [79034,79035]
===
match
---
name: dep_patch [12207,12216]
name: dep_patch [12207,12216]
===
match
---
atom_expr [16072,16114]
atom_expr [16072,16114]
===
match
---
arglist [39533,39562]
arglist [39533,39562]
===
match
---
operator: , [32758,32759]
operator: , [32758,32759]
===
match
---
operator: , [27608,27609]
operator: , [27608,27609]
===
match
---
operator: , [57037,57038]
operator: , [57037,57038]
===
match
---
trailer [65065,65087]
trailer [65065,65087]
===
match
---
operator: == [35163,35165]
operator: == [35163,35165]
===
match
---
name: timezone [9328,9336]
name: timezone [9328,9336]
===
match
---
parameters [9625,9631]
parameters [9625,9631]
===
match
---
name: email [48556,48561]
name: email [48556,48561]
===
match
---
arglist [37811,37844]
arglist [37811,37844]
===
match
---
argument [60740,60752]
argument [60740,60752]
===
match
---
funcdef [18990,19114]
funcdef [18990,19114]
===
match
---
trailer [45375,45392]
trailer [45375,45392]
===
match
---
name: _try_number [25709,25720]
name: _try_number [25709,25720]
===
match
---
expr_stmt [61532,61568]
expr_stmt [61532,61568]
===
match
---
name: delay [23202,23207]
name: delay [23202,23207]
===
match
---
dotted_name [2453,2476]
dotted_name [2453,2476]
===
match
---
trailer [41799,41813]
trailer [41799,41813]
===
match
---
argument [22865,22876]
argument [22865,22876]
===
match
---
name: date [22943,22947]
name: date [22943,22947]
===
match
---
argument [52336,52355]
argument [52336,52355]
===
match
---
operator: = [49186,49187]
operator: = [49186,49187]
===
match
---
comparison [4829,4857]
comparison [4829,4857]
===
match
---
name: task_id [79027,79034]
name: task_id [79027,79034]
===
match
---
simple_stmt [13474,13674]
simple_stmt [13474,13674]
===
match
---
name: body [48681,48685]
name: body [48681,48685]
===
match
---
name: DummyOperator [58621,58634]
name: DummyOperator [58621,58634]
===
match
---
name: SKIPPED [33194,33201]
name: SKIPPED [33194,33201]
===
match
---
simple_stmt [4213,4268]
simple_stmt [4213,4268]
===
match
---
import_as_name [1425,1443]
import_as_name [1425,1443]
===
match
---
trailer [69146,69196]
trailer [69146,69196]
===
match
---
trailer [15880,15890]
trailer [15880,15890]
===
match
---
atom_expr [40477,40490]
atom_expr [40477,40490]
===
match
---
string: "test_queue" [76713,76725]
string: "test_queue" [76713,76725]
===
match
---
operator: = [34928,34929]
operator: = [34928,34929]
===
match
---
atom_expr [15086,15103]
atom_expr [15086,15103]
===
match
---
assert_stmt [31112,31135]
assert_stmt [31112,31135]
===
match
---
trailer [77759,77774]
trailer [77759,77774]
===
match
---
operator: , [26859,26860]
operator: , [26859,26860]
===
match
---
suite [42452,42508]
suite [42452,42508]
===
match
---
arglist [5841,5880]
arglist [5841,5880]
===
match
---
operator: , [18216,18217]
operator: , [18216,18217]
===
match
---
atom_expr [50867,50920]
atom_expr [50867,50920]
===
match
---
string: """         Test that tasks properly take start/end dates from DAGs         """ [3962,4041]
string: """         Test that tasks properly take start/end dates from DAGs         """ [3962,4041]
===
match
---
funcdef [64314,64971]
funcdef [64314,64971]
===
match
---
name: DummyOperator [59682,59695]
name: DummyOperator [59682,59695]
===
match
---
trailer [68782,68787]
trailer [68782,68787]
===
match
---
trailer [53312,53320]
trailer [53312,53320]
===
match
---
simple_stmt [14440,14449]
simple_stmt [14440,14449]
===
match
---
simple_stmt [53810,53880]
simple_stmt [53810,53880]
===
match
---
trailer [56316,56330]
trailer [56316,56330]
===
match
---
operator: = [4100,4101]
operator: = [4100,4101]
===
match
---
trailer [79178,79184]
trailer [79178,79184]
===
match
---
operator: = [13284,13285]
operator: = [13284,13285]
===
match
---
simple_stmt [50929,50954]
simple_stmt [50929,50954]
===
match
---
atom [12206,12231]
atom [12206,12231]
===
match
---
arglist [54600,54636]
arglist [54600,54636]
===
match
---
name: execution_date [37429,37443]
name: execution_date [37429,37443]
===
match
---
trailer [75202,75207]
trailer [75202,75207]
===
match
---
trailer [3086,3088]
trailer [3086,3088]
===
match
---
return_stmt [15050,15104]
return_stmt [15050,15104]
===
match
---
expr_stmt [27764,27789]
expr_stmt [27764,27789]
===
match
---
operator: = [47091,47092]
operator: = [47091,47092]
===
match
---
atom_expr [65055,65087]
atom_expr [65055,65087]
===
match
---
name: serialized_op [79893,79906]
name: serialized_op [79893,79906]
===
match
---
simple_stmt [21619,21658]
simple_stmt [21619,21658]
===
match
---
import_from [1529,1578]
import_from [1529,1578]
===
match
---
string: 'no-sched/no-catchup' [52977,52998]
string: 'no-sched/no-catchup' [52977,52998]
===
match
---
atom [38230,38244]
atom [38230,38244]
===
match
---
name: timedelta [4641,4650]
name: timedelta [4641,4650]
===
match
---
assert_stmt [37576,37597]
assert_stmt [37576,37597]
===
match
---
name: task_ids [41018,41026]
name: task_ids [41018,41026]
===
match
---
operator: = [69174,69175]
operator: = [69174,69175]
===
match
---
name: SUCCESS [54788,54795]
name: SUCCESS [54788,54795]
===
match
---
operator: = [19266,19267]
operator: = [19266,19267]
===
match
---
name: datetime [50301,50309]
name: datetime [50301,50309]
===
match
---
simple_stmt [73615,73644]
simple_stmt [73615,73644]
===
match
---
string: 'test_email_alert_with_config' [49076,49106]
string: 'test_email_alert_with_config' [49076,49106]
===
match
---
argument [76097,76111]
argument [76097,76111]
===
match
---
arglist [69147,69195]
arglist [69147,69195]
===
match
---
trailer [5511,5532]
trailer [5511,5532]
===
match
---
name: session [13445,13452]
name: session [13445,13452]
===
match
---
name: RUNNING [36061,36068]
name: RUNNING [36061,36068]
===
match
---
string: "{{ task.task_id }}" [68282,68302]
string: "{{ task.task_id }}" [68282,68302]
===
match
---
name: execution_date [40425,40439]
name: execution_date [40425,40439]
===
match
---
argument [6190,6198]
argument [6190,6198]
===
match
---
name: utcnow [24910,24916]
name: utcnow [24910,24916]
===
match
---
name: trs [30421,30424]
name: trs [30421,30424]
===
match
---
name: task_ids [38153,38161]
name: task_ids [38153,38161]
===
match
---
atom_expr [45122,45131]
atom_expr [45122,45131]
===
match
---
name: run_with_error [21143,21157]
name: run_with_error [21143,21157]
===
match
---
simple_stmt [26795,26821]
simple_stmt [26795,26821]
===
match
---
argument [61709,61746]
argument [61709,61746]
===
match
---
trailer [32377,32393]
trailer [32377,32393]
===
match
---
name: expected_output [58399,58414]
name: expected_output [58399,58414]
===
match
---
arith_expr [4617,4659]
arith_expr [4617,4659]
===
match
---
number: 2017 [42768,42772]
number: 2017 [42768,42772]
===
match
---
trailer [58130,58167]
trailer [58130,58167]
===
match
---
funcdef [12599,13778]
funcdef [12599,13778]
===
match
---
expr_stmt [10277,10449]
expr_stmt [10277,10449]
===
match
---
number: 4 [32354,32355]
number: 4 [32354,32355]
===
match
---
trailer [68949,68957]
trailer [68949,68957]
===
match
---
name: state [79136,79141]
name: state [79136,79141]
===
match
---
name: task [9207,9211]
name: task [9207,9211]
===
match
---
operator: , [31762,31763]
operator: , [31762,31763]
===
match
---
string: 'schedule_after_task_execution' [71734,71765]
string: 'schedule_after_task_execution' [71734,71765]
===
match
---
name: execution_date [79798,79812]
name: execution_date [79798,79812]
===
match
---
name: TI [35349,35351]
name: TI [35349,35351]
===
match
---
name: datetime [49995,50003]
name: datetime [49995,50003]
===
match
---
name: task_concurrency [9901,9917]
name: task_concurrency [9901,9917]
===
match
---
with_stmt [15377,15681]
with_stmt [15377,15681]
===
match
---
string: '/html_content/path' [48821,48841]
string: '/html_content/path' [48821,48841]
===
match
---
with_stmt [73998,74521]
with_stmt [73998,74521]
===
match
---
operator: , [32641,32642]
operator: , [32641,32642]
===
match
---
operator: = [44721,44722]
operator: = [44721,44722]
===
match
---
name: temp_instance [3097,3110]
name: temp_instance [3097,3110]
===
match
---
name: SUCCESS [54975,54982]
name: SUCCESS [54975,54982]
===
match
---
name: ti [25879,25881]
name: ti [25879,25881]
===
match
---
operator: , [33552,33553]
operator: , [33552,33553]
===
match
---
trailer [62291,62496]
trailer [62291,62496]
===
match
---
operator: , [72556,72557]
operator: , [72556,72557]
===
match
---
operator: = [78947,78948]
operator: = [78947,78948]
===
match
---
atom [71719,71775]
atom [71719,71775]
===
match
---
string: 'B' [73123,73126]
string: 'B' [73123,73126]
===
match
---
trailer [4576,4586]
trailer [4576,4586]
===
match
---
operator: == [23110,23112]
operator: == [23110,23112]
===
match
---
arglist [20359,20378]
arglist [20359,20378]
===
match
---
trailer [21194,21207]
trailer [21194,21207]
===
match
---
parameters [38282,38288]
parameters [38282,38288]
===
match
---
name: state [54776,54781]
name: state [54776,54781]
===
match
---
trailer [6557,6564]
trailer [6557,6564]
===
match
---
operator: , [32681,32682]
operator: , [32681,32682]
===
match
---
operator: = [43102,43103]
operator: = [43102,43103]
===
match
---
operator: , [54428,54429]
operator: , [54428,54429]
===
match
---
argument [21889,21898]
argument [21889,21898]
===
match
---
trailer [25086,25094]
trailer [25086,25094]
===
match
---
name: op1 [7841,7844]
name: op1 [7841,7844]
===
match
---
name: scenario [51665,51673]
name: scenario [51665,51673]
===
match
---
number: 1 [26783,26784]
number: 1 [26783,26784]
===
match
---
name: DummyOperator [35281,35294]
name: DummyOperator [35281,35294]
===
match
---
operator: , [32684,32685]
operator: , [32684,32685]
===
match
---
name: dag [74003,74006]
name: dag [74003,74006]
===
match
---
operator: = [41172,41173]
operator: = [41172,41173]
===
match
---
trailer [63604,63622]
trailer [63604,63622]
===
match
---
name: refresh_from_db [31086,31101]
name: refresh_from_db [31086,31101]
===
match
---
simple_stmt [11222,11475]
simple_stmt [11222,11475]
===
match
---
name: task [76153,76157]
name: task [76153,76157]
===
match
---
name: dag [11338,11341]
name: dag [11338,11341]
===
match
---
operator: , [74359,74360]
operator: , [74359,74360]
===
match
---
operator: , [34249,34250]
operator: , [34249,34250]
===
match
---
name: query [46906,46911]
name: query [46906,46911]
===
match
---
trailer [26249,26259]
trailer [26249,26259]
===
match
---
name: param [53022,53027]
name: param [53022,53027]
===
match
---
operator: , [72762,72763]
operator: , [72762,72763]
===
match
---
name: ti [22849,22851]
name: ti [22849,22851]
===
match
---
operator: , [32370,32371]
operator: , [32370,32371]
===
match
---
simple_stmt [21143,21162]
simple_stmt [21143,21162]
===
match
---
trailer [62612,62635]
trailer [62612,62635]
===
match
---
simple_stmt [66900,66917]
simple_stmt [66900,66917]
===
match
---
trailer [13693,13700]
trailer [13693,13700]
===
match
---
funcdef [75980,76539]
funcdef [75980,76539]
===
match
---
name: state [20702,20707]
name: state [20702,20707]
===
match
---
number: 0 [33176,33177]
number: 0 [33176,33177]
===
match
---
comparison [36660,36716]
comparison [36660,36716]
===
match
---
atom_expr [4380,4394]
atom_expr [4380,4394]
===
match
---
operator: @ [48863,48864]
operator: @ [48863,48864]
===
match
---
expr_stmt [22201,22251]
expr_stmt [22201,22251]
===
match
---
atom_expr [5898,5915]
atom_expr [5898,5915]
===
match
---
simple_stmt [7408,7450]
simple_stmt [7408,7450]
===
match
---
simple_stmt [5833,5882]
simple_stmt [5833,5882]
===
match
---
operator: = [29946,29947]
operator: = [29946,29947]
===
match
---
trailer [63783,63839]
trailer [63783,63839]
===
match
---
operator: , [15247,15248]
operator: , [15247,15248]
===
match
---
operator: , [31700,31701]
operator: , [31700,31701]
===
match
---
name: execution_date [52123,52137]
name: execution_date [52123,52137]
===
match
---
string: 'op' [78349,78353]
string: 'op' [78349,78353]
===
match
---
string: 'test@test.test' [60760,60776]
string: 'test@test.test' [60760,60776]
===
match
---
operator: , [52998,52999]
operator: , [52998,52999]
===
match
---
simple_stmt [1980,2037]
simple_stmt [1980,2037]
===
match
---
trailer [21645,21657]
trailer [21645,21657]
===
match
---
name: ti [27228,27230]
name: ti [27228,27230]
===
match
---
name: downstream_ti [36541,36554]
name: downstream_ti [36541,36554]
===
match
---
operator: , [73006,73007]
operator: , [73006,73007]
===
match
---
operator: , [9311,9312]
operator: , [9311,9312]
===
match
---
name: mock_on_retry_2 [62426,62441]
name: mock_on_retry_2 [62426,62441]
===
match
---
simple_stmt [63589,63625]
simple_stmt [63589,63625]
===
match
---
operator: , [59993,59994]
operator: , [59993,59994]
===
match
---
dictorsetmaker [71832,71883]
dictorsetmaker [71832,71883]
===
match
---
operator: , [13625,13626]
operator: , [13625,13626]
===
match
---
name: param [52819,52824]
name: param [52819,52824]
===
match
---
trailer [60726,60836]
trailer [60726,60836]
===
match
---
trailer [5900,5915]
trailer [5900,5915]
===
match
---
atom_expr [26187,26216]
atom_expr [26187,26216]
===
match
---
name: RUNNING [41885,41892]
name: RUNNING [41885,41892]
===
match
---
expr_stmt [63322,63346]
expr_stmt [63322,63346]
===
match
---
parameters [43929,43935]
parameters [43929,43935]
===
match
---
simple_stmt [42473,42508]
simple_stmt [42473,42508]
===
match
---
atom_expr [11943,11973]
atom_expr [11943,11973]
===
match
---
operator: = [54488,54489]
operator: = [54488,54489]
===
match
---
operator: = [11541,11542]
operator: = [11541,11542]
===
match
---
param [51665,51684]
param [51665,51684]
===
match
---
name: execution_date [76958,76972]
name: execution_date [76958,76972]
===
match
---
name: ti [61223,61225]
name: ti [61223,61225]
===
match
---
operator: , [57090,57091]
operator: , [57090,57091]
===
match
---
name: task [11491,11495]
name: task [11491,11495]
===
match
---
file_input [788,80313]
file_input [788,80313]
===
match
---
number: 0 [14197,14198]
number: 0 [14197,14198]
===
match
---
atom_expr [74831,74851]
atom_expr [74831,74851]
===
match
---
suite [78772,78829]
suite [78772,78829]
===
match
---
decorator [53169,53215]
decorator [53169,53215]
===
match
---
operator: = [9327,9328]
operator: = [9327,9328]
===
match
---
expr_stmt [27537,27562]
expr_stmt [27537,27562]
===
match
---
parameters [21603,21609]
parameters [21603,21609]
===
match
---
name: REQUEUEABLE_DEPS [11746,11762]
name: REQUEUEABLE_DEPS [11746,11762]
===
match
---
trailer [23744,23784]
trailer [23744,23784]
===
match
---
name: SchedulerJob [74550,74562]
name: SchedulerJob [74550,74562]
===
match
---
trailer [26730,26785]
trailer [26730,26785]
===
match
---
expr_stmt [35274,35335]
expr_stmt [35274,35335]
===
match
---
name: datetime [51623,51631]
name: datetime [51623,51631]
===
match
---
atom_expr [66508,66741]
atom_expr [66508,66741]
===
match
---
operator: = [37493,37494]
operator: = [37493,37494]
===
match
---
operator: , [57087,57088]
operator: , [57087,57088]
===
match
---
name: models [51753,51759]
name: models [51753,51759]
===
match
---
argument [20254,20263]
argument [20254,20263]
===
match
---
expr_stmt [22809,22877]
expr_stmt [22809,22877]
===
match
---
name: BashOperator [21769,21781]
name: BashOperator [21769,21781]
===
match
---
name: ti [41955,41957]
name: ti [41955,41957]
===
match
---
operator: } [67034,67035]
operator: } [67034,67035]
===
match
---
fstring_expr [11912,11928]
fstring_expr [11912,11928]
===
match
---
simple_stmt [71007,71081]
simple_stmt [71007,71081]
===
match
---
param [35218,35222]
param [35218,35222]
===
match
---
argument [7615,7627]
argument [7615,7627]
===
match
---
expr_stmt [49549,49600]
expr_stmt [49549,49600]
===
match
---
name: scenario [52608,52616]
name: scenario [52608,52616]
===
match
---
testlist_comp [36126,36143]
testlist_comp [36126,36143]
===
match
---
operator: , [18969,18970]
operator: , [18969,18970]
===
match
---
trailer [61445,61522]
trailer [61445,61522]
===
match
---
argument [5851,5880]
argument [5851,5880]
===
match
---
simple_stmt [43202,43229]
simple_stmt [43202,43229]
===
match
---
name: task_instance_a [75535,75550]
name: task_instance_a [75535,75550]
===
match
---
operator: , [72159,72160]
operator: , [72159,72160]
===
match
---
import_as_names [2171,2202]
import_as_names [2171,2202]
===
match
---
string: 'airflow' [64661,64670]
string: 'airflow' [64661,64670]
===
match
---
suite [78930,79401]
suite [78930,79401]
===
match
---
dotted_name [1320,1334]
dotted_name [1320,1334]
===
match
---
number: 2 [64719,64720]
number: 2 [64719,64720]
===
match
---
operator: = [8562,8563]
operator: = [8562,8563]
===
match
---
operator: , [63285,63286]
operator: , [63285,63286]
===
match
---
name: task [24880,24884]
name: task [24880,24884]
===
match
---
operator: , [40266,40267]
operator: , [40266,40267]
===
match
---
name: pytest [7184,7190]
name: pytest [7184,7190]
===
match
---
comparison [21258,21276]
comparison [21258,21276]
===
match
---
name: state [30831,30836]
name: state [30831,30836]
===
match
---
name: DEFAULT_DATE [48298,48310]
name: DEFAULT_DATE [48298,48310]
===
match
---
name: seconds [21646,21653]
name: seconds [21646,21653]
===
match
---
trailer [21534,21538]
trailer [21534,21538]
===
match
---
trailer [46203,46212]
trailer [46203,46212]
===
match
---
atom_expr [56784,56814]
atom_expr [56784,56814]
===
match
---
simple_stmt [51468,51489]
simple_stmt [51468,51489]
===
match
---
name: expected_task_reschedule_count [29900,29930]
name: expected_task_reschedule_count [29900,29930]
===
match
---
argument [48361,48393]
argument [48361,48393]
===
match
---
argument [5020,5070]
argument [5020,5070]
===
match
---
comparison [77324,77358]
comparison [77324,77358]
===
match
---
atom_expr [7184,7215]
atom_expr [7184,7215]
===
match
---
trailer [41925,41935]
trailer [41925,41935]
===
match
---
operator: , [7762,7763]
operator: , [7762,7763]
===
match
---
name: test_retries_on_other_exceptions [64318,64350]
name: test_retries_on_other_exceptions [64318,64350]
===
match
---
testlist_comp [7866,7890]
testlist_comp [7866,7890]
===
match
---
suite [67626,68116]
suite [67626,68116]
===
match
---
trailer [43705,43756]
trailer [43705,43756]
===
match
---
simple_stmt [27686,27755]
simple_stmt [27686,27755]
===
match
---
name: execution_date [61014,61028]
name: execution_date [61014,61028]
===
match
---
operator: - [12875,12876]
operator: - [12875,12876]
===
match
---
operator: = [78409,78410]
operator: = [78409,78410]
===
match
---
operator: = [45383,45384]
operator: = [45383,45384]
===
match
---
simple_stmt [77812,77835]
simple_stmt [77812,77835]
===
match
---
atom_expr [41842,41859]
atom_expr [41842,41859]
===
match
---
name: start_date [76268,76278]
name: start_date [76268,76278]
===
match
---
name: airflow [1844,1851]
name: airflow [1844,1851]
===
match
---
name: task [63275,63279]
name: task [63275,63279]
===
match
---
operator: } [72868,72869]
operator: } [72868,72869]
===
match
---
operator: = [37943,37944]
operator: = [37943,37944]
===
match
---
for_stmt [71451,71651]
for_stmt [71451,71651]
===
match
---
trailer [17326,17347]
trailer [17326,17347]
===
match
---
name: db [3534,3536]
name: db [3534,3536]
===
match
---
operator: = [76712,76713]
operator: = [76712,76713]
===
match
---
name: pool_override [77107,77120]
name: pool_override [77107,77120]
===
match
---
atom_expr [41757,41786]
atom_expr [41757,41786]
===
match
---
arglist [50266,50315]
arglist [50266,50315]
===
match
---
name: _run_raw_task [78788,78801]
name: _run_raw_task [78788,78801]
===
match
---
testlist_comp [78099,78106]
testlist_comp [78099,78106]
===
match
---
name: DummyOperator [49808,49821]
name: DummyOperator [49808,49821]
===
match
---
arglist [47318,47333]
arglist [47318,47333]
===
match
---
simple_stmt [68313,68361]
simple_stmt [68313,68361]
===
match
---
operator: } [70629,70630]
operator: } [70629,70630]
===
match
---
name: db [3631,3633]
name: db [3631,3633]
===
match
---
operator: == [9568,9570]
operator: == [9568,9570]
===
match
---
trailer [61211,61213]
trailer [61211,61213]
===
match
---
argument [43723,43730]
argument [43723,43730]
===
match
---
name: REQUEUEABLE_DEPS [1885,1901]
name: REQUEUEABLE_DEPS [1885,1901]
===
match
---
argument [53141,53147]
argument [53141,53147]
===
match
---
string: "test_handle_failure" [61453,61474]
string: "test_handle_failure" [61453,61474]
===
match
---
name: task [24875,24879]
name: task [24875,24879]
===
match
---
name: SKIPPED [31922,31929]
name: SKIPPED [31922,31929]
===
match
---
operator: , [33388,33389]
operator: , [33388,33389]
===
match
---
trailer [11532,11534]
trailer [11532,11534]
===
match
---
assert_stmt [29559,29606]
assert_stmt [29559,29606]
===
match
---
name: state [61060,61065]
name: state [61060,61065]
===
match
---
name: python_callable [28568,28583]
name: python_callable [28568,28583]
===
match
---
string: 'test_xcom' [36876,36887]
string: 'test_xcom' [36876,36887]
===
match
---
name: schedule_interval [57007,57024]
name: schedule_interval [57007,57024]
===
match
---
param [71427,71440]
param [71427,71440]
===
match
---
operator: , [1387,1388]
operator: , [1387,1388]
===
match
---
name: mode [28537,28541]
name: mode [28537,28541]
===
match
---
name: sqlalchemy [1095,1105]
name: sqlalchemy [1095,1105]
===
match
---
operator: = [76237,76238]
operator: = [76237,76238]
===
match
---
simple_stmt [8250,8274]
simple_stmt [8250,8274]
===
match
---
simple_stmt [10118,10134]
simple_stmt [10118,10134]
===
match
---
name: ti [44320,44322]
name: ti [44320,44322]
===
match
---
name: op2 [7574,7577]
name: op2 [7574,7577]
===
match
---
name: task_id [4900,4907]
name: task_id [4900,4907]
===
match
---
expr_stmt [11989,12021]
expr_stmt [11989,12021]
===
match
---
name: dummy [1552,1557]
name: dummy [1552,1557]
===
match
---
operator: , [71044,71045]
operator: , [71044,71045]
===
match
---
name: ti [22494,22496]
name: ti [22494,22496]
===
match
---
name: get_previous_ti [54067,54082]
name: get_previous_ti [54067,54082]
===
match
---
trailer [10938,10944]
trailer [10938,10944]
===
match
---
trailer [6354,6362]
trailer [6354,6362]
===
match
---
assert_stmt [19441,19478]
assert_stmt [19441,19478]
===
match
---
name: State [51109,51114]
name: State [51109,51114]
===
match
---
name: ti1 [38139,38142]
name: ti1 [38139,38142]
===
match
---
name: datetime [30727,30735]
name: datetime [30727,30735]
===
match
---
atom_expr [62958,62974]
atom_expr [62958,62974]
===
match
---
string: '2019-01-01T00:00:00+00:00' [52515,52542]
string: '2019-01-01T00:00:00+00:00' [52515,52542]
===
match
---
comparison [7353,7368]
comparison [7353,7368]
===
match
---
argument [7531,7550]
argument [7531,7550]
===
match
---
simple_stmt [11030,11104]
simple_stmt [11030,11104]
===
match
---
simple_stmt [45122,45148]
simple_stmt [45122,45148]
===
match
---
operator: = [17159,17160]
operator: = [17159,17160]
===
match
---
name: execution_date [44874,44888]
name: execution_date [44874,44888]
===
match
---
atom_expr [41796,41946]
atom_expr [41796,41946]
===
match
---
arglist [76097,76134]
arglist [76097,76134]
===
match
---
arglist [52825,52859]
arglist [52825,52859]
===
match
---
operator: = [73776,73777]
operator: = [73776,73777]
===
match
---
name: DagRunType [15870,15880]
name: DagRunType [15870,15880]
===
match
---
trailer [8211,8218]
trailer [8211,8218]
===
match
---
name: pendulum [5998,6006]
name: pendulum [5998,6006]
===
match
---
name: mock_on_retry_1 [62137,62152]
name: mock_on_retry_1 [62137,62152]
===
match
---
param [42078,42082]
param [42078,42082]
===
match
---
name: run_type [30864,30872]
name: run_type [30864,30872]
===
match
---
trailer [6546,6557]
trailer [6546,6557]
===
match
---
testlist_star_expr [27777,27789]
testlist_star_expr [27777,27789]
===
match
---
simple_stmt [43684,43757]
simple_stmt [43684,43757]
===
match
---
name: time [19704,19708]
name: time [19704,19708]
===
match
---
name: return_value [35850,35862]
name: return_value [35850,35862]
===
match
---
operator: = [34310,34311]
operator: = [34310,34311]
===
match
---
trailer [51374,51387]
trailer [51374,51387]
===
match
---
number: 9 [5068,5069]
number: 9 [5068,5069]
===
match
---
name: expected_try_number [29141,29160]
name: expected_try_number [29141,29160]
===
match
---
operator: { [72710,72711]
operator: { [72710,72711]
===
match
---
argument [44931,44987]
argument [44931,44987]
===
match
---
name: str [51988,51991]
name: str [51988,51991]
===
match
---
name: task_instance_c [75107,75122]
name: task_instance_c [75107,75122]
===
match
---
atom_expr [37414,37454]
atom_expr [37414,37454]
===
match
---
name: dagrun_1 [56621,56629]
name: dagrun_1 [56621,56629]
===
match
---
operator: , [26753,26754]
operator: , [26753,26754]
===
match
---
atom_expr [21189,21207]
atom_expr [21189,21207]
===
match
---
trailer [54525,54532]
trailer [54525,54532]
===
match
---
simple_stmt [22658,22680]
simple_stmt [22658,22680]
===
match
---
name: DEFAULT_DATE [6819,6831]
name: DEFAULT_DATE [6819,6831]
===
match
---
name: test_respects_prev_dagrun_dep [35188,35217]
name: test_respects_prev_dagrun_dep [35188,35217]
===
match
---
simple_stmt [37788,37846]
simple_stmt [37788,37846]
===
match
---
name: xcom_pull [39523,39532]
name: xcom_pull [39523,39532]
===
match
---
operator: = [47118,47119]
operator: = [47118,47119]
===
match
---
operator: = [40091,40092]
operator: = [40091,40092]
===
match
---
operator: , [19323,19324]
operator: , [19323,19324]
===
match
---
trailer [13713,13717]
trailer [13713,13717]
===
match
---
trailer [6248,6263]
trailer [6248,6263]
===
match
---
trailer [41495,41714]
trailer [41495,41714]
===
match
---
name: test_check_and_change_state_before_execution [42922,42966]
name: test_check_and_change_state_before_execution [42922,42966]
===
match
---
trailer [16532,16540]
trailer [16532,16540]
===
match
---
name: expected_are_dependents_done [36688,36716]
name: expected_are_dependents_done [36688,36716]
===
match
---
simple_stmt [66106,66125]
simple_stmt [66106,66125]
===
match
---
decorated [48691,49759]
decorated [48691,49759]
===
match
---
name: os [74570,74572]
name: os [74570,74572]
===
match
---
name: ti [40554,40556]
name: ti [40554,40556]
===
match
---
name: run [31206,31209]
name: run [31206,31209]
===
match
---
decorated [8844,9582]
decorated [8844,9582]
===
match
---
suite [3682,3869]
suite [3682,3869]
===
match
---
name: dep [11943,11946]
name: dep [11943,11946]
===
update-node
---
number: 10 [79436,79438]
replace 10 by 12
===
update-node
---
number: 10 [78074,78076]
replace 10 by 12
===
update-node
---
number: 5 [78099,78100]
replace 5 by 7
