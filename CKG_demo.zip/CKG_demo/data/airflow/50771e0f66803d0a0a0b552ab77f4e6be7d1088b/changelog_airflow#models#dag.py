===
match
---
trailer [44631,44641]
trailer [44631,44641]
===
match
---
suite [19890,20154]
suite [19890,20154]
===
match
---
operator: , [99525,99526]
operator: , [99624,99625]
===
match
---
operator: -> [34838,34840]
operator: -> [34838,34840]
===
match
---
trailer [34964,34971]
trailer [34964,34971]
===
match
---
name: self [34991,34995]
name: self [34991,34995]
===
match
---
string: 'LR' [3499,3503]
string: 'LR' [3499,3503]
===
match
---
name: end_date [65263,65271]
name: end_date [65263,65271]
===
match
---
simple_stmt [74943,74953]
simple_stmt [74943,74953]
===
match
---
simple_stmt [64178,64373]
simple_stmt [64178,64373]
===
match
---
operator: = [38564,38565]
operator: = [38564,38565]
===
match
---
subscriptlist [47440,47458]
subscriptlist [47440,47458]
===
match
---
trailer [82580,82643]
trailer [82690,82753]
===
match
---
operator: , [101338,101339]
operator: , [101437,101438]
===
match
---
trailer [83027,83047]
trailer [83126,83146]
===
match
---
param [77588,77602]
param [77588,77602]
===
match
---
trailer [20364,20374]
trailer [20364,20374]
===
match
---
name: tzinfo [14323,14329]
name: tzinfo [14323,14329]
===
match
---
param [25444,25470]
param [25444,25470]
===
match
---
expr_stmt [57018,57047]
expr_stmt [57018,57047]
===
match
---
string: 'idx_next_dagrun_create_after' [96900,96930]
string: 'idx_next_dagrun_create_after' [96999,97029]
===
match
---
operator: = [67964,67965]
operator: = [67964,67965]
===
match
---
name: TI [47539,47541]
name: TI [47539,47541]
===
match
---
name: DagRunState [62357,62368]
name: DagRunState [62357,62368]
===
match
---
dotted_name [106081,106096]
dotted_name [106180,106195]
===
match
---
name: settings [1641,1649]
name: settings [1641,1649]
===
match
---
operator: = [60784,60785]
operator: = [60784,60785]
===
match
---
operator: = [34182,34183]
operator: = [34182,34183]
===
match
---
trailer [13627,13632]
trailer [13627,13632]
===
match
---
operator: = [62281,62282]
operator: = [62281,62282]
===
match
---
simple_stmt [96806,96979]
simple_stmt [96905,97078]
===
match
---
param [11134,11198]
param [11134,11198]
===
match
---
simple_stmt [15423,15470]
simple_stmt [15423,15470]
===
match
---
name: allow_future_exec_dates [49027,49050]
name: allow_future_exec_dates [49027,49050]
===
match
---
trailer [37136,37156]
trailer [37136,37156]
===
match
---
name: AirflowException [53409,53425]
name: AirflowException [53409,53425]
===
match
---
expr_stmt [17122,17189]
expr_stmt [17122,17189]
===
match
---
tfpdef [103044,103060]
tfpdef [103143,103159]
===
match
---
param [33393,33397]
param [33393,33397]
===
match
---
name: session [29927,29934]
name: session [29927,29934]
===
match
---
decorator [102997,103010]
decorator [103096,103109]
===
match
---
trailer [48470,48477]
trailer [48470,48477]
===
match
---
operator: , [57366,57367]
operator: , [57366,57367]
===
match
---
name: roots [58281,58286]
name: roots [58281,58286]
===
match
---
arglist [29146,29257]
arglist [29146,29257]
===
match
---
trailer [49950,49981]
trailer [49950,49981]
===
match
---
argument [88300,88317]
argument [88399,88416]
===
match
---
atom_expr [29288,29317]
atom_expr [29288,29317]
===
match
---
atom_expr [28897,28909]
atom_expr [28897,28909]
===
match
---
simple_stmt [18791,18833]
simple_stmt [18791,18833]
===
match
---
operator: = [12694,12695]
operator: = [12694,12695]
===
match
---
raise_stmt [39528,39603]
raise_stmt [39528,39603]
===
match
---
expr_stmt [68861,68884]
expr_stmt [68861,68884]
===
match
---
atom_expr [40531,40552]
atom_expr [40531,40552]
===
match
---
atom_expr [33859,33891]
atom_expr [33859,33891]
===
match
---
comparison [88211,88239]
comparison [88310,88338]
===
match
---
return_stmt [29384,29395]
return_stmt [29384,29395]
===
match
---
simple_stmt [51920,52010]
simple_stmt [51920,52010]
===
match
---
simple_stmt [97629,97665]
simple_stmt [97728,97764]
===
match
---
name: notin_ [55571,55577]
name: notin_ [55571,55577]
===
match
---
name: Environment [42126,42137]
name: Environment [42126,42137]
===
match
---
trailer [48870,48874]
trailer [48870,48874]
===
match
---
param [106120,106126]
param [106219,106225]
===
match
---
atom_expr [104147,104164]
atom_expr [104246,104263]
===
match
---
trailer [51986,51995]
trailer [51986,51995]
===
match
---
trailer [100782,100790]
trailer [100881,100889]
===
match
---
atom_expr [38882,38900]
atom_expr [38882,38900]
===
match
---
parameters [29545,29601]
parameters [29545,29601]
===
match
---
operator: , [64357,64358]
operator: , [64357,64358]
===
match
---
trailer [80835,80840]
trailer [80835,80840]
===
match
---
suite [51606,51652]
suite [51606,51652]
===
match
---
string: 'end_date' [15245,15255]
string: 'end_date' [15245,15255]
===
match
---
simple_stmt [89942,89959]
simple_stmt [90041,90058]
===
match
---
operator: , [93085,93086]
operator: , [93184,93185]
===
match
---
name: parent_dag [99292,99302]
name: parent_dag [99391,99401]
===
match
---
atom_expr [27938,28001]
atom_expr [27938,28001]
===
match
---
trailer [82630,82640]
trailer [82740,82750]
===
match
---
name: warn [29128,29132]
name: warn [29128,29132]
===
match
---
name: on_success_callback [17158,17177]
name: on_success_callback [17158,17177]
===
match
---
operator: = [36226,36227]
operator: = [36226,36227]
===
match
---
atom_expr [102538,102555]
atom_expr [102637,102654]
===
match
---
atom_expr [38594,38606]
atom_expr [38594,38606]
===
match
---
tfpdef [46737,46761]
tfpdef [46737,46761]
===
match
---
name: key [55082,55085]
name: key [55082,55085]
===
match
---
simple_stmt [54818,54878]
simple_stmt [54818,54878]
===
match
---
expr_stmt [72562,72619]
expr_stmt [72562,72619]
===
match
---
operator: } [100326,100327]
operator: } [100425,100426]
===
match
---
param [33829,33833]
param [33829,33833]
===
match
---
name: all [17940,17943]
name: all [17940,17943]
===
match
---
trailer [97292,97294]
trailer [97391,97393]
===
match
---
return_stmt [99233,99316]
return_stmt [99332,99415]
===
match
---
dotted_name [2402,2429]
dotted_name [2402,2429]
===
match
---
name: int [46066,46069]
name: int [46066,46069]
===
match
---
trailer [82919,82926]
trailer [83018,83025]
===
match
---
funcdef [22096,23610]
funcdef [22096,23610]
===
match
---
name: get_last_dagrun [29618,29633]
name: get_last_dagrun [29618,29633]
===
match
---
simple_stmt [13777,13832]
simple_stmt [13777,13832]
===
match
---
name: is_ [49620,49623]
name: is_ [49620,49623]
===
match
---
comparison [19849,19889]
comparison [19849,19889]
===
match
---
import_from [3177,3233]
import_from [3177,3233]
===
match
---
name: set_state [57091,57100]
name: set_state [57091,57100]
===
match
---
operator: = [18221,18222]
operator: = [18221,18222]
===
match
---
atom_expr [70490,70541]
atom_expr [70490,70541]
===
match
---
name: name [107290,107294]
name: name [107389,107393]
===
match
---
trailer [97408,97413]
trailer [97507,97512]
===
match
---
comparison [48628,48662]
comparison [48628,48662]
===
match
---
comp_op [87639,87645]
comp_op [87738,87744]
===
match
---
tfpdef [46643,46659]
tfpdef [46643,46659]
===
match
---
name: tis [48556,48559]
name: tis [48556,48559]
===
match
---
name: session [74462,74469]
name: session [74462,74469]
===
match
---
operator: = [87614,87615]
operator: = [87713,87714]
===
match
---
name: setter [30135,30141]
name: setter [30135,30141]
===
match
---
operator: , [64747,64748]
operator: , [64747,64748]
===
match
---
trailer [74223,74249]
trailer [74223,74249]
===
match
---
name: timezone [14774,14782]
name: timezone [14774,14782]
===
match
---
return_stmt [32721,32744]
return_stmt [32721,32744]
===
match
---
trailer [100205,100209]
trailer [100304,100308]
===
match
---
operator: , [69202,69203]
operator: , [69202,69203]
===
match
---
name: task_dict [71936,71945]
name: task_dict [71936,71945]
===
match
---
trailer [40407,40414]
trailer [40407,40414]
===
match
---
name: ti_list [67472,67479]
name: ti_list [67472,67479]
===
match
---
tfpdef [12043,12096]
tfpdef [12043,12096]
===
match
---
atom_expr [21681,21710]
atom_expr [21681,21710]
===
match
---
argument [45288,45309]
argument [45288,45309]
===
match
---
trailer [89806,89816]
trailer [89905,89915]
===
match
---
name: TaskInstance [91505,91517]
name: TaskInstance [91604,91616]
===
match
---
name: owner [87242,87247]
name: owner [87341,87346]
===
match
---
trailer [51538,51542]
trailer [51538,51542]
===
match
---
name: session [29668,29675]
name: session [29668,29675]
===
match
---
fstring_end: ' [16417,16418]
fstring_end: ' [16417,16418]
===
match
---
name: self [39959,39963]
name: self [39959,39963]
===
match
---
tfpdef [11290,11325]
tfpdef [11290,11325]
===
match
---
trailer [70401,70413]
trailer [70401,70413]
===
match
---
trailer [42342,42362]
trailer [42342,42362]
===
match
---
name: DagContext [18791,18801]
name: DagContext [18791,18801]
===
match
---
name: UtcDateTime [3085,3096]
name: UtcDateTime [3085,3096]
===
match
---
param [55864,55895]
param [55864,55895]
===
match
---
name: dict [86307,86311]
name: dict [86406,86410]
===
match
---
atom_expr [99622,99633]
atom_expr [99721,99732]
===
match
---
trailer [14850,14865]
trailer [14850,14865]
===
match
---
expr_stmt [74361,74401]
expr_stmt [74361,74401]
===
match
---
name: Context [2188,2195]
name: Context [2188,2195]
===
match
---
expr_stmt [104526,104586]
expr_stmt [104625,104685]
===
match
---
atom [41614,41852]
atom [41614,41852]
===
match
---
suite [18782,18853]
suite [18782,18853]
===
match
---
atom [44943,44978]
atom [44943,44978]
===
match
---
operator: = [74770,74771]
operator: = [74770,74771]
===
match
---
trailer [23931,23948]
trailer [23931,23948]
===
match
---
name: include_dependent_dags [54103,54125]
name: include_dependent_dags [54103,54125]
===
match
---
funcdef [58513,58734]
funcdef [58513,58734]
===
match
---
operator: , [53579,53580]
operator: , [53579,53580]
===
match
---
param [46643,46660]
param [46643,46660]
===
match
---
name: dry_run [62385,62392]
name: dry_run [62385,62392]
===
match
---
atom_expr [96997,97120]
atom_expr [97096,97219]
===
match
---
param [40695,40707]
param [40695,40707]
===
match
---
name: query [44262,44267]
name: query [44262,44267]
===
match
---
trailer [104692,104717]
trailer [104791,104816]
===
match
---
operator: , [57337,57338]
operator: , [57337,57338]
===
match
---
trailer [15099,15113]
trailer [15099,15113]
===
match
---
name: earliest [21500,21508]
name: earliest [21500,21508]
===
match
---
simple_stmt [45091,45597]
simple_stmt [45091,45597]
===
match
---
name: relative_fileloc [32978,32994]
name: relative_fileloc [32978,32994]
===
match
---
name: airflow [2254,2261]
name: airflow [2254,2261]
===
match
---
atom_expr [74121,74139]
atom_expr [74121,74139]
===
match
---
atom_expr [106025,106070]
atom_expr [106124,106169]
===
match
---
decorators [84174,84208]
decorators [84273,84307]
===
match
---
name: query [61747,61752]
name: query [61747,61752]
===
match
---
name: session [89942,89949]
name: session [90041,90048]
===
match
---
atom_expr [14215,14262]
atom_expr [14215,14262]
===
match
---
name: cls [101989,101992]
name: cls [102088,102091]
===
match
---
arglist [50202,50343]
arglist [50202,50343]
===
match
---
name: self [43729,43733]
name: self [43729,43733]
===
match
---
name: Optional [11453,11461]
name: Optional [11453,11461]
===
match
---
name: default [94941,94948]
name: default [95040,95047]
===
match
---
operator: = [65157,65158]
operator: = [65157,65158]
===
match
---
trailer [74930,74933]
trailer [74930,74933]
===
match
---
name: max_active_tasks [97634,97650]
name: max_active_tasks [97733,97749]
===
match
---
dotted_name [31253,31276]
dotted_name [31253,31276]
===
match
---
trailer [61015,61072]
trailer [61015,61072]
===
match
---
tfpdef [45872,45900]
tfpdef [45872,45900]
===
match
---
trailer [53726,53733]
trailer [53726,53733]
===
match
---
name: self [77265,77269]
name: self [77265,77269]
===
match
---
operator: , [44447,44448]
operator: , [44447,44448]
===
match
---
suite [24889,24925]
suite [24889,24925]
===
match
---
param [62096,62101]
param [62096,62101]
===
match
---
atom_expr [18390,18411]
atom_expr [18390,18411]
===
match
---
name: task_ids [32585,32593]
name: task_ids [32585,32593]
===
match
---
trailer [30309,30314]
trailer [30309,30314]
===
match
---
suite [105851,107798]
suite [105950,107897]
===
match
---
operator: = [46177,46178]
operator: = [46177,46178]
===
match
---
trailer [104892,104917]
trailer [104991,105016]
===
match
---
atom_expr [29020,29068]
atom_expr [29020,29068]
===
match
---
name: dag [90770,90773]
name: dag [90869,90872]
===
match
---
name: repr [18632,18636]
name: repr [18632,18636]
===
match
---
name: self [97629,97633]
name: self [97728,97732]
===
match
---
name: paused_dag_ids [100312,100326]
name: paused_dag_ids [100411,100425]
===
match
---
name: executors [79473,79482]
name: executors [79473,79482]
===
match
---
name: following [29276,29285]
name: following [29276,29285]
===
match
---
name: start_date [14829,14839]
name: start_date [14829,14839]
===
match
---
atom_expr [86681,86721]
atom_expr [86780,86820]
===
match
---
name: qry [92165,92168]
name: qry [92264,92267]
===
match
---
name: state [45770,45775]
name: state [45770,45775]
===
match
---
operator: , [80515,80516]
operator: , [80515,80516]
===
match
---
expr_stmt [64385,64399]
expr_stmt [64385,64399]
===
match
---
suite [65771,65793]
suite [65771,65793]
===
match
---
expr_stmt [64944,64962]
expr_stmt [64944,64962]
===
match
---
trailer [34191,34197]
trailer [34191,34197]
===
match
---
operator: != [44427,44429]
operator: != [44427,44429]
===
match
---
trailer [48849,48885]
trailer [48849,48885]
===
match
---
name: default_args [14235,14247]
name: default_args [14235,14247]
===
match
---
trailer [92426,92446]
trailer [92525,92545]
===
match
---
name: get_latest_execution_date [40663,40688]
name: get_latest_execution_date [40663,40688]
===
match
---
simple_stmt [32016,32253]
simple_stmt [32016,32253]
===
match
---
trailer [44365,44380]
trailer [44365,44380]
===
match
---
string: "Attempted to clear too many tasks " [52567,52603]
string: "Attempted to clear too many tasks " [52567,52603]
===
match
---
operator: = [44856,44857]
operator: = [44856,44857]
===
match
---
trailer [96249,96312]
trailer [96348,96411]
===
match
---
trailer [58716,58732]
trailer [58716,58732]
===
match
---
atom [61709,61722]
atom [61709,61722]
===
match
---
atom_expr [68661,68687]
atom_expr [68661,68687]
===
match
---
suite [15896,15948]
suite [15896,15948]
===
match
---
name: self [104101,104105]
name: self [104200,104204]
===
match
---
operator: - [92492,92493]
operator: - [92591,92592]
===
match
---
trailer [77227,77236]
trailer [77227,77236]
===
match
---
name: execution_date [39757,39771]
name: execution_date [39757,39771]
===
match
---
atom_expr [24909,24924]
atom_expr [24909,24924]
===
match
---
parameters [73607,73658]
parameters [73607,73658]
===
match
---
name: DagPickle [2097,2106]
name: DagPickle [2097,2106]
===
match
---
dotted_name [2889,2910]
dotted_name [2889,2910]
===
match
---
simple_stmt [42324,42363]
simple_stmt [42324,42363]
===
match
---
name: run_type [85994,86002]
name: run_type [86093,86101]
===
match
---
name: template_searchpath [15371,15390]
name: template_searchpath [15371,15390]
===
match
---
param [71427,71433]
param [71427,71433]
===
match
---
trailer [72746,72773]
trailer [72746,72773]
===
match
---
return_stmt [107803,107817]
return_stmt [107902,107916]
===
match
---
simple_stmt [97400,97613]
simple_stmt [97499,97712]
===
match
---
name: env [42881,42884]
name: env [42881,42884]
===
match
---
name: state [49279,49284]
name: state [49279,49284]
===
match
---
name: start_dates [24302,24313]
name: start_dates [24302,24313]
===
match
---
comp_if [70594,70637]
comp_if [70594,70637]
===
match
---
simple_stmt [72359,72373]
simple_stmt [72359,72373]
===
match
---
simple_stmt [40349,40609]
simple_stmt [40349,40609]
===
match
---
name: tags [96230,96234]
name: tags [96329,96333]
===
match
---
return_stmt [24969,24991]
return_stmt [24969,24991]
===
match
---
simple_stmt [79591,80151]
simple_stmt [79591,80151]
===
match
---
simple_stmt [68401,68427]
simple_stmt [68401,68427]
===
match
---
expr_stmt [34152,34169]
expr_stmt [34152,34169]
===
match
---
trailer [89861,89865]
trailer [89960,89964]
===
match
---
argument [66848,66869]
argument [66848,66869]
===
match
---
name: template_searchpath [15394,15413]
name: template_searchpath [15394,15413]
===
match
---
operator: = [61696,61697]
operator: = [61696,61697]
===
match
---
atom_expr [43828,43846]
atom_expr [43828,43846]
===
match
---
name: latest [26573,26579]
name: latest [26573,26579]
===
match
---
name: executor [79534,79542]
name: executor [79534,79542]
===
match
---
simple_stmt [73925,73973]
simple_stmt [73925,73973]
===
match
---
with_stmt [106817,107676]
with_stmt [106916,107775]
===
match
---
name: task [58686,58690]
name: task [58686,58690]
===
match
---
operator: , [99805,99806]
operator: , [99904,99905]
===
match
---
name: Session [1549,1556]
name: Session [1549,1556]
===
match
---
atom_expr [48617,48704]
atom_expr [48617,48704]
===
match
---
tfpdef [47101,47122]
tfpdef [47101,47122]
===
match
---
if_stmt [59541,59605]
if_stmt [59541,59605]
===
match
---
simple_stmt [34865,34927]
simple_stmt [34865,34927]
===
match
---
operator: , [97086,97087]
operator: , [97185,97186]
===
match
---
operator: @ [38147,38148]
operator: @ [38147,38148]
===
match
---
suite [72077,72346]
suite [72077,72346]
===
match
---
name: self [69299,69303]
name: self [69299,69303]
===
match
---
atom_expr [82324,82386]
atom_expr [82348,82410]
===
match
---
atom_expr [55950,55964]
atom_expr [55950,55964]
===
match
---
name: dag_id [50240,50246]
name: dag_id [50240,50246]
===
match
---
name: schedules [2515,2524]
name: schedules [2515,2524]
===
match
---
trailer [45039,45047]
trailer [45039,45047]
===
match
---
suite [37218,37775]
suite [37218,37775]
===
match
---
name: filter_task_group [71409,71426]
name: filter_task_group [71409,71426]
===
match
---
name: merge [90812,90817]
name: merge [90911,90916]
===
match
---
operator: = [80888,80889]
operator: = [80888,80889]
===
match
---
name: callback [37121,37129]
name: callback [37121,37129]
===
match
---
name: info [20677,20681]
name: info [20677,20681]
===
match
---
trailer [45116,45136]
trailer [45116,45136]
===
match
---
arglist [45048,45079]
arglist [45048,45079]
===
match
---
atom_expr [17522,17556]
atom_expr [17522,17556]
===
match
---
trailer [92239,92241]
trailer [92338,92340]
===
match
---
dotted_name [4104,4128]
dotted_name [4104,4128]
===
match
---
trailer [37742,37747]
trailer [37742,37747]
===
match
---
name: run_after [24046,24055]
name: run_after [24046,24055]
===
match
---
name: params [12696,12702]
name: params [12696,12702]
===
match
---
funcdef [33382,33523]
funcdef [33382,33523]
===
match
---
name: jinja2 [42119,42125]
name: jinja2 [42119,42125]
===
match
---
name: dag_id [86346,86352]
name: dag_id [86445,86451]
===
match
---
trailer [18916,18940]
trailer [18916,18940]
===
match
---
trailer [89257,89261]
trailer [89356,89360]
===
match
---
name: state [83338,83343]
name: state [83437,83442]
===
match
---
trailer [74675,74706]
trailer [74675,74706]
===
match
---
name: joinedload [1489,1499]
name: joinedload [1489,1499]
===
match
---
name: self [75431,75435]
name: self [75431,75435]
===
match
---
suite [27895,28002]
suite [27895,28002]
===
match
---
name: start_date [76038,76048]
name: start_date [76038,76048]
===
match
---
import_as_names [2642,2664]
import_as_names [2642,2664]
===
match
---
import_from [1833,1877]
import_from [1833,1877]
===
match
---
name: default_args [14680,14692]
name: default_args [14680,14692]
===
match
---
trailer [82334,82386]
trailer [82358,82410]
===
match
---
name: self [40939,40943]
name: self [40939,40943]
===
match
---
operator: = [37469,37470]
operator: = [37469,37470]
===
match
---
name: DeprecationWarning [30396,30414]
name: DeprecationWarning [30396,30414]
===
match
---
name: self [15267,15271]
name: self [15267,15271]
===
match
---
trailer [49146,49161]
trailer [49146,49161]
===
match
---
name: staticmethod [90858,90870]
name: staticmethod [90957,90969]
===
match
---
trailer [48126,48134]
trailer [48126,48134]
===
match
---
operator: , [46159,46160]
operator: , [46159,46160]
===
match
---
operator: = [67645,67646]
operator: = [67645,67646]
===
match
---
operator: = [107019,107020]
operator: = [107118,107119]
===
match
---
operator: { [19687,19688]
operator: { [19687,19688]
===
match
---
decorator [31365,31375]
decorator [31365,31375]
===
match
---
arglist [71798,71817]
arglist [71798,71817]
===
match
---
name: include_parentdag [47132,47149]
name: include_parentdag [47132,47149]
===
match
---
parameters [23641,23704]
parameters [23641,23704]
===
match
---
trailer [97915,97943]
trailer [98014,98042]
===
match
---
name: convert_to_utc [14911,14925]
name: convert_to_utc [14911,14925]
===
match
---
parameters [99520,99576]
parameters [99619,99675]
===
match
---
expr_stmt [82997,83089]
expr_stmt [83096,83188]
===
match
---
argument [23847,23874]
argument [23847,23874]
===
match
---
trailer [25206,25215]
trailer [25206,25215]
===
match
---
atom_expr [103684,103697]
atom_expr [103783,103796]
===
match
---
suite [36246,36303]
suite [36246,36303]
===
match
---
name: get_dag [53301,53308]
name: get_dag [53301,53308]
===
match
---
argument [96958,96970]
argument [97057,97069]
===
match
---
name: dagrun [36389,36395]
name: dagrun [36389,36395]
===
match
---
name: Union [45777,45782]
name: Union [45777,45782]
===
match
---
trailer [49265,49294]
trailer [49265,49294]
===
match
---
suite [53156,54632]
suite [53156,54632]
===
match
---
trailer [103641,103646]
trailer [103740,103745]
===
match
---
suite [66756,68237]
suite [66756,68237]
===
match
---
name: dag_obj [107004,107011]
name: dag_obj [107103,107110]
===
match
---
name: end_date [46385,46393]
name: end_date [46385,46393]
===
match
---
param [99521,99526]
param [99620,99625]
===
match
---
suite [39791,39880]
suite [39791,39880]
===
match
---
operator: = [54034,54035]
operator: = [54034,54035]
===
match
---
operator: , [103771,103772]
operator: , [103870,103871]
===
match
---
argument [21842,21869]
argument [21842,21869]
===
match
---
name: len [89729,89732]
name: len [89828,89831]
===
match
---
operator: , [72138,72139]
operator: , [72138,72139]
===
match
---
atom_expr [65159,65632]
atom_expr [65159,65632]
===
match
---
name: _should_fix_dst [21160,21175]
name: _should_fix_dst [21160,21175]
===
match
---
operator: = [29801,29802]
operator: = [29801,29802]
===
match
---
operator: , [45829,45830]
operator: , [45829,45830]
===
match
---
if_stmt [60910,61073]
if_stmt [60910,61073]
===
match
---
name: subdags [41329,41336]
name: subdags [41329,41336]
===
match
---
atom_expr [49590,49630]
atom_expr [49590,49630]
===
match
---
name: dag [105460,105463]
name: dag [105559,105562]
===
match
---
expr_stmt [74195,74249]
expr_stmt [74195,74249]
===
match
---
name: utils [2897,2902]
name: utils [2897,2902]
===
match
---
lambdef [86702,86720]
lambdef [86801,86819]
===
match
---
decorator [44746,44763]
decorator [44746,44763]
===
match
---
name: copied [71899,71905]
name: copied [71899,71905]
===
match
---
name: s [49705,49706]
name: s [49705,49706]
===
match
---
name: backfill_job [79242,79254]
name: backfill_job [79242,79254]
===
match
---
simple_stmt [96100,96134]
simple_stmt [96199,96233]
===
match
---
trailer [100672,100705]
trailer [100771,100804]
===
match
---
name: int [47350,47353]
name: int [47350,47353]
===
match
---
name: only_running [66963,66975]
name: only_running [66963,66975]
===
match
---
string: 'donot_pickle' [77436,77450]
string: 'donot_pickle' [77436,77450]
===
match
---
name: is_paused [100138,100147]
name: is_paused [100237,100246]
===
match
---
name: get_last_dagrun [29530,29545]
name: get_last_dagrun [29530,29545]
===
match
---
name: timedelta [25025,25034]
name: timedelta [25025,25034]
===
match
---
operator: = [31535,31536]
operator: = [31535,31536]
===
match
---
name: in_ [91677,91680]
name: in_ [91776,91779]
===
match
---
testlist_comp [70682,70737]
testlist_comp [70682,70737]
===
match
---
name: level [75153,75158]
name: level [75153,75158]
===
match
---
number: 2 [23899,23900]
number: 2 [23899,23900]
===
match
---
trailer [28588,28593]
trailer [28588,28593]
===
match
---
atom_expr [47478,47529]
atom_expr [47478,47529]
===
match
---
fstring [16371,16418]
fstring [16371,16418]
===
match
---
trailer [106675,106697]
trailer [106774,106796]
===
match
---
name: next_dagrun_data_interval_end [98187,98216]
name: next_dagrun_data_interval_end [98286,98315]
===
match
---
atom_expr [85643,85667]
atom_expr [85742,85766]
===
match
---
name: cls [108765,108768]
name: cls [108864,108867]
===
match
---
operator: , [90501,90502]
operator: , [90600,90601]
===
match
---
param [46327,46336]
param [46327,46336]
===
match
---
name: NativeEnvironment [1343,1360]
name: NativeEnvironment [1343,1360]
===
match
---
name: task_ids_or_regex [69313,69330]
name: task_ids_or_regex [69313,69330]
===
match
---
string: 'dag_id' [10341,10349]
string: 'dag_id' [10341,10349]
===
match
---
atom_expr [95217,95236]
atom_expr [95316,95335]
===
match
---
for_stmt [85250,85668]
for_stmt [85349,85767]
===
match
---
name: end_date [79675,79683]
name: end_date [79675,79683]
===
match
---
operator: = [64355,64356]
operator: = [64355,64356]
===
match
---
name: warn [21768,21772]
name: warn [21768,21772]
===
match
---
decorator [40638,40655]
decorator [40638,40655]
===
match
---
operator: , [106684,106685]
operator: , [106783,106784]
===
match
---
name: max_active_tasks [31285,31301]
name: max_active_tasks [31285,31301]
===
match
---
trailer [76178,76187]
trailer [76178,76187]
===
match
---
param [33987,33999]
param [33987,33999]
===
match
---
name: DagPickle [74676,74685]
name: DagPickle [74676,74685]
===
match
---
trailer [35223,35229]
trailer [35223,35229]
===
match
---
operator: , [66988,66989]
operator: , [66988,66989]
===
match
---
atom_expr [49134,49161]
atom_expr [49134,49161]
===
match
---
import_name [832,841]
import_name [832,841]
===
match
---
name: Type [1189,1193]
name: Type [1189,1193]
===
match
---
testlist_comp [68527,68590]
testlist_comp [68527,68590]
===
match
---
atom_expr [106549,106571]
atom_expr [106648,106670]
===
match
---
comparison [3980,4021]
comparison [3980,4021]
===
match
---
name: dag [87238,87241]
name: dag [87337,87340]
===
match
---
trailer [51764,51772]
trailer [51764,51772]
===
match
---
atom_expr [34332,34344]
atom_expr [34332,34344]
===
match
---
name: only_running [64974,64986]
name: only_running [64974,64986]
===
match
---
argument [23888,23900]
argument [23888,23900]
===
match
---
parameters [68923,68946]
parameters [68923,68946]
===
match
---
trailer [86928,86936]
trailer [87027,87035]
===
match
---
operator: , [11173,11174]
operator: , [11173,11174]
===
match
---
simple_stmt [40954,41056]
simple_stmt [40954,41056]
===
match
---
atom_expr [86307,86634]
atom_expr [86406,86733]
===
match
---
operator: = [21560,21561]
operator: = [21560,21561]
===
match
---
name: earliest [28786,28794]
name: earliest [28786,28794]
===
match
---
argument [64583,64595]
argument [64583,64595]
===
match
---
name: datetime [966,974]
name: datetime [966,974]
===
match
---
name: parse_args [80387,80397]
name: parse_args [80387,80397]
===
match
---
arglist [84939,84969]
arglist [85038,85068]
===
match
---
atom [85535,85537]
atom [85634,85636]
===
match
---
atom_expr [25275,25338]
atom_expr [25275,25338]
===
match
---
simple_stmt [95887,95918]
simple_stmt [95986,96017]
===
match
---
name: self [42110,42114]
name: self [42110,42114]
===
match
---
trailer [97303,97313]
trailer [97402,97412]
===
match
---
operator: , [11473,11474]
operator: , [11473,11474]
===
match
---
atom_expr [11994,12026]
atom_expr [11994,12026]
===
match
---
simple_stmt [15024,15115]
simple_stmt [15024,15115]
===
match
---
trailer [42037,42043]
trailer [42037,42043]
===
match
---
operator: , [1427,1428]
operator: , [1427,1428]
===
match
---
simple_stmt [55442,55500]
simple_stmt [55442,55500]
===
match
---
name: other [18122,18127]
name: other [18122,18127]
===
match
---
name: NullTimetable [24909,24922]
name: NullTimetable [24909,24922]
===
match
---
trailer [15637,15644]
trailer [15637,15644]
===
match
---
name: BaseOperator [58538,58550]
name: BaseOperator [58538,58550]
===
match
---
atom_expr [35116,35130]
atom_expr [35116,35130]
===
match
---
name: warn [32837,32841]
name: warn [32837,32841]
===
match
---
operator: = [95966,95967]
operator: = [96065,96066]
===
match
---
atom_expr [3980,3999]
atom_expr [3980,3999]
===
match
---
name: count [66021,66026]
name: count [66021,66026]
===
match
---
param [39011,39048]
param [39011,39048]
===
match
---
operator: = [94852,94853]
operator: = [94951,94952]
===
match
---
operator: , [68643,68644]
operator: , [68643,68644]
===
match
---
name: Column [96182,96188]
name: Column [96281,96287]
===
match
---
suite [73866,73917]
suite [73866,73917]
===
match
---
name: include_subdags [65335,65350]
name: include_subdags [65335,65350]
===
match
---
if_stmt [29354,29396]
if_stmt [29354,29396]
===
match
---
simple_stmt [19433,19445]
simple_stmt [19433,19445]
===
match
---
name: str [47259,47262]
name: str [47259,47262]
===
match
---
name: kwargs [97270,97276]
name: kwargs [97369,97375]
===
match
---
trailer [103825,103829]
trailer [103924,103928]
===
match
---
name: __exit__ [18862,18870]
name: __exit__ [18862,18870]
===
match
---
suite [25052,25109]
suite [25052,25109]
===
match
---
trailer [74706,74712]
trailer [74706,74712]
===
match
---
comparison [44359,44393]
comparison [44359,44393]
===
match
---
name: clear [57925,57930]
name: clear [57925,57930]
===
match
---
atom_expr [20677,20694]
atom_expr [20677,20694]
===
match
---
suite [68947,69266]
suite [68947,69266]
===
match
---
name: timetable [27943,27952]
name: timetable [27943,27952]
===
match
---
operator: , [12141,12142]
operator: , [12141,12142]
===
match
---
name: TaskInstance [91548,91560]
name: TaskInstance [91647,91659]
===
match
---
funcdef [80456,83740]
funcdef [80456,83839]
===
match
---
string: "dag_tag" [94243,94252]
string: "dag_tag" [94342,94351]
===
match
---
trailer [14071,14084]
trailer [14071,14084]
===
match
---
parameters [33035,33041]
parameters [33035,33041]
===
match
---
trailer [35124,35130]
trailer [35124,35130]
===
match
---
param [29104,29108]
param [29104,29108]
===
match
---
atom_expr [84834,84851]
atom_expr [84933,84950]
===
match
---
expr_stmt [86896,86936]
expr_stmt [86995,87035]
===
match
---
trailer [95903,95917]
trailer [96002,96016]
===
match
---
name: base [1853,1857]
name: base [1853,1857]
===
match
---
trailer [89294,89300]
trailer [89393,89399]
===
match
---
name: add [83519,83522]
name: add [83618,83621]
===
match
---
trailer [69366,69371]
trailer [69366,69371]
===
match
---
atom [100275,100327]
atom [100374,100426]
===
match
---
name: sla_miss_callback [15830,15847]
name: sla_miss_callback [15830,15847]
===
match
---
atom_expr [55038,55172]
atom_expr [55038,55172]
===
match
---
name: t [70967,70968]
name: t [70967,70968]
===
match
---
simple_stmt [43339,43350]
simple_stmt [43339,43350]
===
match
---
dotted_name [2613,2634]
dotted_name [2613,2634]
===
match
---
atom_expr [4087,4100]
atom_expr [4087,4100]
===
match
---
atom_expr [88437,88460]
atom_expr [88536,88559]
===
match
---
name: fileloc [33189,33196]
name: fileloc [33189,33196]
===
match
---
name: all_tis [67508,67515]
name: all_tis [67508,67515]
===
match
---
trailer [41942,41950]
trailer [41942,41950]
===
match
---
trailer [48620,48627]
trailer [48620,48627]
===
match
---
trailer [11917,11928]
trailer [11917,11928]
===
match
---
param [38192,38197]
param [38192,38197]
===
match
---
expr_stmt [79534,79582]
expr_stmt [79534,79582]
===
match
---
simple_stmt [80273,80308]
simple_stmt [80273,80308]
===
match
---
name: sub_dag [68916,68923]
name: sub_dag [68916,68923]
===
match
---
name: next_dagrun_create_after [96932,96956]
name: next_dagrun_create_after [97031,97055]
===
match
---
atom_expr [61385,61403]
atom_expr [61385,61403]
===
match
---
trailer [11112,11117]
trailer [11112,11117]
===
match
---
name: execution_date [55722,55736]
name: execution_date [55722,55736]
===
match
---
name: access_control [31383,31397]
name: access_control [31383,31397]
===
match
---
trailer [72820,72841]
trailer [72820,72841]
===
match
---
name: session [53329,53336]
name: session [53329,53336]
===
match
---
trailer [48112,48154]
trailer [48112,48154]
===
match
---
name: updated_access_control [19662,19684]
name: updated_access_control [19662,19684]
===
match
---
name: task [76561,76565]
name: task [76561,76565]
===
match
---
name: dag [90818,90821]
name: dag [90917,90920]
===
match
---
name: operators [59222,59231]
name: operators [59222,59231]
===
match
---
operator: = [54324,54325]
operator: = [54324,54325]
===
match
---
param [62514,62527]
param [62514,62527]
===
match
---
dotted_name [79465,79498]
dotted_name [79465,79498]
===
match
---
name: d [74417,74418]
name: d [74417,74418]
===
match
---
for_stmt [48354,48538]
for_stmt [48354,48538]
===
match
---
name: dry_run [67263,67270]
name: dry_run [67263,67270]
===
match
---
expr_stmt [15024,15114]
expr_stmt [15024,15114]
===
match
---
atom_expr [50235,50260]
atom_expr [50235,50260]
===
match
---
trailer [40596,40598]
trailer [40596,40598]
===
match
---
atom_expr [15423,15447]
atom_expr [15423,15447]
===
match
---
argument [80112,80139]
argument [80112,80139]
===
match
---
argument [50319,50342]
argument [50319,50342]
===
match
---
name: most_recent_dag_runs [85768,85788]
name: most_recent_dag_runs [85867,85887]
===
match
---
if_stmt [13933,14330]
if_stmt [13933,14330]
===
match
---
simple_stmt [28982,29070]
simple_stmt [28982,29070]
===
match
---
name: dag_id [106638,106644]
name: dag_id [106737,106743]
===
match
---
comparison [100129,100168]
comparison [100228,100267]
===
match
---
operator: = [107880,107881]
operator: = [107979,107980]
===
match
---
name: owners [87053,87059]
name: owners [87152,87158]
===
match
---
name: Union [47070,47075]
name: Union [47070,47075]
===
match
---
trailer [11062,11072]
trailer [11062,11072]
===
match
---
name: conditions [48326,48336]
name: conditions [48326,48336]
===
match
---
for_stmt [73797,73917]
for_stmt [73797,73917]
===
match
---
name: utcnow [74090,74096]
name: utcnow [74090,74096]
===
match
---
trailer [75684,75728]
trailer [75684,75728]
===
match
---
name: self [18086,18090]
name: self [18086,18090]
===
match
---
arglist [90458,90521]
arglist [90557,90620]
===
match
---
name: self [99026,99030]
name: self [99125,99129]
===
match
---
name: __lt__ [18109,18115]
name: __lt__ [18109,18115]
===
match
---
decorator [29750,29767]
decorator [29750,29767]
===
match
---
dictorsetmaker [19785,19835]
dictorsetmaker [19785,19835]
===
match
---
trailer [87903,87908]
trailer [88002,88007]
===
match
---
trailer [38944,38946]
trailer [38944,38946]
===
match
---
param [29552,29565]
param [29552,29565]
===
match
---
trailer [53522,53699]
trailer [53522,53699]
===
match
---
arglist [94079,94099]
arglist [94178,94198]
===
match
---
operator: , [10492,10493]
operator: , [10492,10493]
===
match
---
operator: = [66584,66585]
operator: = [66584,66585]
===
match
---
suite [70797,71093]
suite [70797,71093]
===
match
---
tfpdef [47203,47220]
tfpdef [47203,47220]
===
match
---
sync_comp_for [58444,58492]
sync_comp_for [58444,58492]
===
match
---
name: node [60949,60953]
name: node [60949,60953]
===
match
---
trailer [13761,13768]
trailer [13761,13768]
===
match
---
comparison [23988,24000]
comparison [23988,24000]
===
match
---
param [17687,17691]
param [17687,17691]
===
match
---
name: Optional [55950,55958]
name: Optional [55950,55958]
===
match
---
suite [66802,67251]
suite [66802,67251]
===
match
---
name: timezone [26582,26590]
name: timezone [26582,26590]
===
match
---
name: DagModel [100190,100198]
name: DagModel [100289,100297]
===
match
---
param [55686,55691]
param [55686,55691]
===
match
---
trailer [34259,34266]
trailer [34259,34266]
===
match
---
suite [101173,101241]
suite [101272,101340]
===
match
---
trailer [101781,101801]
trailer [101880,101900]
===
match
---
suite [91725,92214]
suite [91824,92313]
===
match
---
simple_stmt [96162,96199]
simple_stmt [96261,96298]
===
match
---
testlist_comp [88111,88139]
testlist_comp [88210,88238]
===
match
---
expr_stmt [64885,64931]
expr_stmt [64885,64931]
===
match
---
trailer [11777,11810]
trailer [11777,11810]
===
match
---
atom_expr [86796,86807]
atom_expr [86895,86906]
===
match
---
name: dag [105258,105261]
name: dag [105357,105360]
===
match
---
trailer [10567,10572]
trailer [10567,10572]
===
match
---
name: self [16206,16210]
name: self [16206,16210]
===
match
---
suite [106884,107676]
suite [106983,107775]
===
match
---
simple_stmt [13552,13594]
simple_stmt [13552,13594]
===
match
---
simple_stmt [42810,42855]
simple_stmt [42810,42855]
===
match
---
simple_stmt [817,832]
simple_stmt [817,832]
===
match
---
name: property [58264,58272]
name: property [58264,58272]
===
match
---
trailer [34202,34208]
trailer [34202,34208]
===
match
---
trailer [87005,87012]
trailer [87104,87111]
===
match
---
name: primary [51765,51772]
name: primary [51765,51772]
===
match
---
argument [67146,67173]
argument [67146,67173]
===
match
---
operator: , [83143,83144]
operator: , [83242,83243]
===
match
---
string: "This method is deprecated and will be removed in a future version." [61542,61610]
string: "This method is deprecated and will be removed in a future version." [61542,61610]
===
match
---
atom_expr [104846,104875]
atom_expr [104945,104974]
===
match
---
name: executor [77376,77384]
name: executor [77376,77384]
===
match
---
operator: = [67159,67160]
operator: = [67159,67160]
===
match
---
simple_stmt [32389,32426]
simple_stmt [32389,32426]
===
match
---
name: factory [106112,106119]
name: factory [106211,106218]
===
match
---
name: UtcDateTime [96614,96625]
name: UtcDateTime [96713,96724]
===
match
---
name: session [65538,65545]
name: session [65538,65545]
===
match
---
simple_stmt [33574,33726]
simple_stmt [33574,33726]
===
match
---
trailer [12270,12276]
trailer [12270,12276]
===
match
---
operator: = [19685,19686]
operator: = [19685,19686]
===
match
---
if_stmt [74723,74934]
if_stmt [74723,74934]
===
match
---
trailer [97413,97612]
trailer [97512,97711]
===
match
---
name: t [70627,70628]
name: t [70627,70628]
===
match
---
name: airflow [1838,1845]
name: airflow [1838,1845]
===
match
---
operator: = [71712,71713]
operator: = [71712,71713]
===
match
---
name: Optional [11155,11163]
name: Optional [11155,11163]
===
match
---
atom_expr [85586,85596]
atom_expr [85685,85695]
===
match
---
name: cls [92386,92389]
name: cls [92485,92488]
===
match
---
arglist [11599,11632]
arglist [11599,11632]
===
match
---
name: utils [3270,3275]
name: utils [3270,3275]
===
match
---
simple_stmt [77700,79216]
simple_stmt [77700,79216]
===
match
---
name: visited_external_tis [47408,47428]
name: visited_external_tis [47408,47428]
===
match
---
simple_stmt [16561,16582]
simple_stmt [16561,16582]
===
match
---
atom_expr [39620,39641]
atom_expr [39620,39641]
===
match
---
arglist [20825,20875]
arglist [20825,20875]
===
match
---
trailer [64191,64372]
trailer [64191,64372]
===
match
---
simple_stmt [2832,2884]
simple_stmt [2832,2884]
===
match
---
name: past [57894,57898]
name: past [57894,57898]
===
match
---
name: bulk_write_to_db [89055,89071]
name: bulk_write_to_db [89154,89170]
===
match
---
expr_stmt [14406,14439]
expr_stmt [14406,14439]
===
match
---
name: Column [96663,96669]
name: Column [96762,96768]
===
match
---
name: self [27207,27211]
name: self [27207,27211]
===
match
---
operator: , [10461,10462]
operator: , [10461,10462]
===
match
---
atom_expr [25202,25215]
atom_expr [25202,25215]
===
match
---
atom_expr [59442,59452]
atom_expr [59442,59452]
===
match
---
suite [37639,37775]
suite [37639,37775]
===
match
---
atom_expr [80827,80840]
atom_expr [80827,80840]
===
match
---
atom_expr [48556,48584]
atom_expr [48556,48584]
===
match
---
operator: , [82294,82295]
operator: , [82318,82319]
===
match
---
strings [16303,16418]
strings [16303,16418]
===
match
---
operator: , [29675,29676]
operator: , [29675,29676]
===
match
---
param [10858,10870]
param [10858,10870]
===
match
---
name: session [83511,83518]
name: session [83610,83617]
===
match
---
name: self [68875,68879]
name: self [68875,68879]
===
match
---
if_stmt [61804,61889]
if_stmt [61804,61889]
===
match
---
trailer [76415,76445]
trailer [76415,76445]
===
match
---
not_test [57390,57400]
not_test [57390,57400]
===
match
---
name: self [40689,40693]
name: self [40689,40693]
===
match
---
simple_stmt [38122,38142]
simple_stmt [38122,38142]
===
match
---
expr_stmt [94053,94127]
expr_stmt [94152,94226]
===
match
---
suite [24394,24423]
suite [24394,24423]
===
match
---
parameters [36382,36437]
parameters [36382,36437]
===
match
---
param [47132,47156]
param [47132,47156]
===
match
---
operator: , [85944,85945]
operator: , [86043,86044]
===
match
---
atom_expr [87950,87962]
atom_expr [88049,88061]
===
match
---
expr_stmt [108640,108686]
expr_stmt [108739,108785]
===
match
---
decorator [29505,29522]
decorator [29505,29522]
===
match
---
parameters [104091,104196]
parameters [104190,104295]
===
match
---
argument [37988,38007]
argument [37988,38007]
===
match
---
string: 'extensions' [42569,42581]
string: 'extensions' [42569,42581]
===
match
---
operator: = [36417,36418]
operator: = [36417,36418]
===
match
---
name: dag_id [86598,86604]
name: dag_id [86697,86703]
===
match
---
operator: , [45664,45665]
operator: , [45664,45665]
===
match
---
simple_stmt [32261,32323]
simple_stmt [32261,32323]
===
match
---
name: datetime [98098,98106]
name: datetime [98197,98205]
===
match
---
name: self [31329,31333]
name: self [31329,31333]
===
match
---
name: start_dates [24255,24266]
name: start_dates [24255,24266]
===
match
---
operator: -> [24805,24807]
operator: -> [24805,24807]
===
match
---
name: DagModel [90503,90511]
name: DagModel [90602,90610]
===
match
---
fstring_string: You are about to delete these  [67542,67572]
fstring_string: You are about to delete these  [67542,67572]
===
match
---
name: info [23988,23992]
name: info [23988,23992]
===
match
---
trailer [76987,76997]
trailer [76987,76997]
===
match
---
simple_stmt [34536,34728]
simple_stmt [34536,34728]
===
match
---
trailer [101056,101061]
trailer [101155,101160]
===
match
---
parameters [21258,21270]
parameters [21258,21270]
===
match
---
dotted_name [2295,2308]
dotted_name [2295,2308]
===
match
---
name: interval [27502,27510]
name: interval [27502,27510]
===
match
---
name: altered [57421,57428]
name: altered [57421,57428]
===
match
---
if_stmt [71784,72346]
if_stmt [71784,72346]
===
match
---
name: external_tis [52866,52878]
name: external_tis [52866,52878]
===
match
---
simple_stmt [1002,1032]
simple_stmt [1002,1032]
===
match
---
atom_expr [100856,100878]
atom_expr [100955,100977]
===
match
---
simple_stmt [40718,40786]
simple_stmt [40718,40786]
===
match
---
arglist [94870,94907]
arglist [94969,95006]
===
match
---
trailer [98004,98011]
trailer [98103,98110]
===
match
---
name: session [100078,100085]
name: session [100177,100184]
===
match
---
simple_stmt [31826,31849]
simple_stmt [31826,31849]
===
match
---
atom_expr [83511,83527]
atom_expr [83610,83626]
===
match
---
trailer [43832,43846]
trailer [43832,43846]
===
match
---
trailer [34747,34771]
trailer [34747,34771]
===
match
---
expr_stmt [23920,23976]
expr_stmt [23920,23976]
===
match
---
name: provide_session [84192,84207]
name: provide_session [84291,84306]
===
match
---
suite [33295,33363]
suite [33295,33363]
===
match
---
trailer [92101,92107]
trailer [92200,92206]
===
match
---
trailer [47005,47015]
trailer [47005,47015]
===
match
---
name: keys [72971,72975]
name: keys [72971,72975]
===
match
---
suite [98842,99069]
suite [98941,99168]
===
match
---
trailer [71863,71873]
trailer [71863,71873]
===
match
---
del_stmt [12901,12932]
del_stmt [12901,12932]
===
match
---
name: acyclic [60776,60783]
name: acyclic [60776,60783]
===
match
---
string: 'params' [12878,12886]
string: 'params' [12878,12886]
===
match
---
tfpdef [98790,98832]
tfpdef [98889,98931]
===
match
---
dictorsetmaker [70368,70420]
dictorsetmaker [70368,70420]
===
match
---
name: sql [1573,1576]
name: sql [1573,1576]
===
match
---
name: self [74786,74790]
name: self [74786,74790]
===
match
---
atom_expr [23576,23598]
atom_expr [23576,23598]
===
match
---
name: arguments [106725,106734]
name: arguments [106824,106833]
===
match
---
tfpdef [93376,93399]
tfpdef [93475,93498]
===
match
---
trailer [98186,98216]
trailer [98285,98315]
===
match
---
trailer [76008,76019]
trailer [76008,76019]
===
match
---
name: qry [34178,34181]
name: qry [34178,34181]
===
match
---
trailer [74836,74849]
trailer [74836,74849]
===
match
---
name: get_task [43634,43642]
name: get_task [43634,43642]
===
match
---
param [11483,11555]
param [11483,11555]
===
match
---
name: external_trigger [83262,83278]
name: external_trigger [83361,83377]
===
match
---
name: used_group_ids [71619,71633]
name: used_group_ids [71619,71633]
===
match
---
atom_expr [35019,35048]
atom_expr [35019,35048]
===
match
---
simple_stmt [107515,107573]
simple_stmt [107614,107672]
===
match
---
name: session [3864,3871]
name: session [3864,3871]
===
match
---
name: orm_dag [85460,85467]
name: orm_dag [85559,85566]
===
match
---
name: date_last_automated_dagrun [23535,23561]
name: date_last_automated_dagrun [23535,23561]
===
match
---
name: state [47063,47068]
name: state [47063,47068]
===
match
---
trailer [10557,10573]
trailer [10557,10573]
===
match
---
name: task_id [60632,60639]
name: task_id [60632,60639]
===
match
---
name: params [68794,68800]
name: params [68794,68800]
===
match
---
decorator [33368,33378]
decorator [33368,33378]
===
match
---
operator: == [3899,3901]
operator: == [3899,3901]
===
match
---
operator: } [62019,62020]
operator: } [62019,62020]
===
match
---
param [21259,21264]
param [21259,21264]
===
match
---
operator: = [48744,48745]
operator: = [48744,48745]
===
match
---
param [31097,31102]
param [31097,31102]
===
match
---
trailer [71559,71564]
trailer [71559,71564]
===
match
---
operator: = [108020,108021]
operator: = [108119,108120]
===
match
---
trailer [48874,48884]
trailer [48874,48884]
===
match
---
name: str [93371,93374]
name: str [93470,93473]
===
match
---
trailer [62006,62012]
trailer [62006,62012]
===
match
---
operator: , [54582,54583]
operator: , [54582,54583]
===
match
---
atom_expr [45788,45797]
atom_expr [45788,45797]
===
match
---
expr_stmt [31925,31948]
expr_stmt [31925,31948]
===
match
---
expr_stmt [12563,12611]
expr_stmt [12563,12611]
===
match
---
trailer [86976,86988]
trailer [87075,87087]
===
match
---
suite [32790,32996]
suite [32790,32996]
===
match
---
name: name [87938,87942]
name: name [88037,88041]
===
match
---
expr_stmt [96984,97120]
expr_stmt [97083,97219]
===
match
---
comparison [97065,97086]
comparison [97164,97185]
===
match
---
name: state [50569,50574]
name: state [50569,50574]
===
match
---
trailer [98081,98108]
trailer [98180,98207]
===
match
---
expr_stmt [106431,106473]
expr_stmt [106530,106572]
===
match
---
simple_stmt [3341,3397]
simple_stmt [3341,3397]
===
match
---
trailer [90539,90541]
trailer [90638,90640]
===
match
---
atom_expr [99283,99302]
atom_expr [99382,99401]
===
match
---
name: timezone [28897,28905]
name: timezone [28897,28905]
===
match
---
name: log [105133,105136]
name: log [105232,105235]
===
match
---
expr_stmt [97911,97950]
expr_stmt [98010,98049]
===
match
---
name: session [3605,3612]
name: session [3605,3612]
===
match
---
argument [67819,67836]
argument [67819,67836]
===
match
---
name: timedelta [3371,3380]
name: timedelta [3371,3380]
===
match
---
name: DagModel [99254,99262]
name: DagModel [99353,99361]
===
match
---
trailer [71945,71960]
trailer [71945,71960]
===
match
---
fstring_expr [73951,73960]
fstring_expr [73951,73960]
===
match
---
operator: += [65093,65095]
operator: += [65093,65095]
===
match
---
operator: , [11789,11790]
operator: , [11789,11790]
===
match
---
name: task_dict [73062,73071]
name: task_dict [73062,73071]
===
match
---
trailer [102343,102349]
trailer [102442,102448]
===
match
---
name: downstream_task_id [43398,43416]
name: downstream_task_id [43398,43416]
===
match
---
name: session [88400,88407]
name: session [88499,88506]
===
match
---
name: joinedload [99272,99282]
name: joinedload [99371,99381]
===
match
---
expr_stmt [16472,16494]
expr_stmt [16472,16494]
===
match
---
atom_expr [17940,18015]
atom_expr [17940,18015]
===
match
---
suite [48168,48215]
suite [48168,48215]
===
match
---
trailer [76593,76608]
trailer [76593,76608]
===
match
---
name: utcnow [49096,49102]
name: utcnow [49096,49102]
===
match
---
name: t [73247,73248]
name: t [73247,73248]
===
match
---
name: executor [79745,79753]
name: executor [79745,79753]
===
match
---
atom_expr [24189,24201]
atom_expr [24189,24201]
===
match
---
name: upstream [70988,70996]
name: upstream [70988,70996]
===
match
---
trailer [87828,87832]
trailer [87927,87931]
===
match
---
name: incr [37743,37747]
name: incr [37743,37747]
===
match
---
simple_stmt [94672,94709]
simple_stmt [94771,94808]
===
match
---
suite [24314,24381]
suite [24314,24381]
===
match
---
name: query [35224,35229]
name: query [35224,35229]
===
match
---
name: dag_id [74544,74550]
name: dag_id [74544,74550]
===
match
---
decorated [99146,99317]
decorated [99245,99416]
===
match
---
operator: @ [29505,29506]
operator: @ [29505,29506]
===
match
---
operator: , [37986,37987]
operator: , [37986,37987]
===
match
---
name: interval [25131,25139]
name: interval [25131,25139]
===
match
---
name: DAG [105986,105989]
name: DAG [106085,106088]
===
match
---
name: relationship [96237,96249]
name: relationship [96336,96348]
===
match
---
name: task_dict [76512,76521]
name: task_dict [76512,76521]
===
match
---
name: instance [28955,28963]
name: instance [28955,28963]
===
match
---
operator: @ [33001,33002]
operator: @ [33001,33002]
===
match
---
operator: = [104667,104668]
operator: = [104766,104767]
===
match
---
name: relativedelta [3382,3395]
name: relativedelta [3382,3395]
===
match
---
atom_expr [82665,82713]
atom_expr [82775,82823]
===
match
---
suite [21919,21978]
suite [21919,21978]
===
match
---
comparison [90458,90501]
comparison [90557,90600]
===
match
---
name: TaskInstance [49601,49613]
name: TaskInstance [49601,49613]
===
match
---
operator: , [25480,25481]
operator: , [25480,25481]
===
match
---
name: add [88408,88411]
name: add [88507,88510]
===
match
---
trailer [64900,64907]
trailer [64900,64907]
===
match
---
suite [29602,29745]
suite [29602,29745]
===
match
---
trailer [42766,42796]
trailer [42766,42796]
===
match
---
name: DEFAULT_VIEW_PRESETS [3397,3417]
name: DEFAULT_VIEW_PRESETS [3397,3417]
===
match
---
name: run [38093,38096]
name: run [38093,38096]
===
match
---
atom_expr [76753,76765]
atom_expr [76753,76765]
===
match
---
trailer [88180,88185]
trailer [88279,88284]
===
match
---
operator: } [12707,12708]
operator: } [12707,12708]
===
match
---
for_stmt [88685,88765]
for_stmt [88784,88864]
===
match
---
trailer [61781,61785]
trailer [61781,61785]
===
match
---
name: val [32465,32468]
name: val [32465,32468]
===
match
---
atom_expr [58474,58492]
atom_expr [58474,58492]
===
match
---
name: tasks [77024,77029]
name: tasks [77024,77029]
===
match
---
import_as_names [1057,1229]
import_as_names [1057,1229]
===
match
---
name: TaskInstance [48850,48862]
name: TaskInstance [48850,48862]
===
match
---
atom_expr [101782,101800]
atom_expr [101881,101899]
===
match
---
name: query [74512,74517]
name: query [74512,74517]
===
match
---
name: stacklevel [34704,34714]
name: stacklevel [34704,34714]
===
match
---
dotted_name [2496,2524]
dotted_name [2496,2524]
===
match
---
trailer [28994,29007]
trailer [28994,29007]
===
match
---
name: dag_tag [88291,88298]
name: dag_tag [88390,88397]
===
match
---
trailer [98125,98157]
trailer [98224,98256]
===
match
---
param [38997,39002]
param [38997,39002]
===
match
---
name: exclude_task_ids [58196,58212]
name: exclude_task_ids [58196,58212]
===
match
---
atom_expr [32603,32612]
atom_expr [32603,32612]
===
match
---
trailer [42058,42081]
trailer [42058,42081]
===
match
---
operator: == [101618,101620]
operator: == [101717,101719]
===
match
---
name: __name__ [106688,106696]
name: __name__ [106787,106795]
===
match
---
trailer [85816,85822]
trailer [85915,85921]
===
match
---
operator: { [53447,53448]
operator: { [53447,53448]
===
match
---
param [62480,62505]
param [62480,62505]
===
match
---
atom_expr [22177,22194]
atom_expr [22177,22194]
===
match
---
operator: = [79683,79684]
operator: = [79683,79684]
===
match
---
name: get_prev [22057,22065]
name: get_prev [22057,22065]
===
match
---
name: val [18637,18640]
name: val [18637,18640]
===
match
---
simple_stmt [49117,49175]
simple_stmt [49117,49175]
===
match
---
operator: , [62256,62257]
operator: , [62256,62257]
===
match
---
string: '@once' [36186,36193]
string: '@once' [36186,36193]
===
match
---
expr_stmt [52866,53114]
expr_stmt [52866,53114]
===
match
---
simple_stmt [96573,96627]
simple_stmt [96672,96726]
===
match
---
operator: , [11124,11125]
operator: , [11124,11125]
===
match
---
operator: , [21869,21870]
operator: , [21869,21870]
===
match
---
trailer [23948,23976]
trailer [23948,23976]
===
match
---
name: result [20470,20476]
name: result [20470,20476]
===
match
---
name: dag_id [88300,88306]
name: dag_id [88399,88405]
===
match
---
not_test [19401,19419]
not_test [19401,19419]
===
match
---
trailer [108848,108869]
trailer [108947,108968]
===
match
---
name: ti [37471,37473]
name: ti [37471,37473]
===
match
---
trailer [107489,107491]
trailer [107588,107590]
===
match
---
trailer [17368,17384]
trailer [17368,17384]
===
match
---
comparison [34972,35002]
comparison [34972,35002]
===
match
---
operator: = [79650,79651]
operator: = [79650,79651]
===
match
---
trailer [84991,85021]
trailer [85090,85120]
===
match
---
dotted_name [31855,31871]
dotted_name [31855,31871]
===
match
---
trailer [3972,3979]
trailer [3972,3979]
===
match
---
trailer [87052,87059]
trailer [87151,87158]
===
match
---
if_stmt [88434,88508]
if_stmt [88533,88607]
===
match
---
comp_op [27883,27889]
comp_op [27883,27889]
===
match
---
operator: ** [97304,97306]
operator: ** [97403,97405]
===
match
---
decorator [99164,99181]
decorator [99263,99280]
===
match
---
name: dttm [29312,29316]
name: dttm [29312,29316]
===
match
---
expr_stmt [85460,85507]
expr_stmt [85559,85606]
===
match
---
name: state [49316,49321]
name: state [49316,49321]
===
match
---
simple_stmt [52866,53115]
simple_stmt [52866,53115]
===
match
---
simple_stmt [13602,13640]
simple_stmt [13602,13640]
===
match
---
name: dag_sig [105966,105973]
name: dag_sig [106065,106072]
===
match
---
name: join [65847,65851]
name: join [65847,65851]
===
match
---
number: 3 [61667,61668]
number: 3 [61667,61668]
===
match
---
name: Optional [46395,46403]
name: Optional [46395,46403]
===
match
---
argument [65364,65399]
argument [65364,65399]
===
match
---
name: str [32786,32789]
name: str [32786,32789]
===
match
---
name: self [20931,20935]
name: self [20931,20935]
===
match
---
suite [92148,92214]
suite [92247,92313]
===
match
---
trailer [3365,3396]
trailer [3365,3396]
===
match
---
name: self [31742,31746]
name: self [31742,31746]
===
match
---
trailer [27789,27803]
trailer [27789,27803]
===
match
---
name: warnings [30834,30842]
name: warnings [30834,30842]
===
match
---
trailer [70500,70541]
trailer [70500,70541]
===
match
---
name: filter [49944,49950]
name: filter [49944,49950]
===
match
---
name: int [13628,13631]
name: int [13628,13631]
===
match
---
atom_expr [40824,40845]
atom_expr [40824,40845]
===
match
---
trailer [30572,30709]
trailer [30572,30709]
===
match
---
fstring [61141,61194]
fstring [61141,61194]
===
match
---
operator: , [57235,57236]
operator: , [57235,57236]
===
match
---
atom_expr [60864,60889]
atom_expr [60864,60889]
===
match
---
name: self [24464,24468]
name: self [24464,24468]
===
match
---
argument [97053,97086]
argument [97152,97185]
===
match
---
name: TimeRestriction [21484,21499]
name: TimeRestriction [21484,21499]
===
match
---
name: self [18871,18875]
name: self [18871,18875]
===
match
---
trailer [27974,27987]
trailer [27974,27987]
===
match
---
atom [94097,94099]
atom [94196,94198]
===
match
---
arglist [32855,32943]
arglist [32855,32943]
===
match
---
return_stmt [73887,73916]
return_stmt [73887,73916]
===
match
---
trailer [85922,85926]
trailer [86021,86025]
===
match
---
operator: = [38779,38780]
operator: = [38779,38780]
===
match
---
name: values [32416,32422]
name: values [32416,32422]
===
match
---
suite [57401,57429]
suite [57401,57429]
===
match
---
trailer [52742,52751]
trailer [52742,52751]
===
match
---
atom_expr [106439,106473]
atom_expr [106538,106572]
===
match
---
operator: = [57954,57955]
operator: = [57954,57955]
===
match
---
name: upstream_task_ids [72900,72917]
name: upstream_task_ids [72900,72917]
===
match
---
comparison [27878,27894]
comparison [27878,27894]
===
match
---
comparison [48757,48798]
comparison [48757,48798]
===
match
---
trailer [61858,61873]
trailer [61858,61873]
===
match
---
trailer [43192,43200]
trailer [43192,43200]
===
match
---
name: TaskGroup [12489,12498]
name: TaskGroup [12489,12498]
===
match
---
name: orm_dag [85301,85308]
name: orm_dag [85400,85407]
===
match
---
name: timetables [2554,2564]
name: timetables [2554,2564]
===
match
---
name: missing_dag_id [85327,85341]
name: missing_dag_id [85426,85440]
===
match
---
trailer [88176,88186]
trailer [88275,88285]
===
match
---
name: dttm [22084,22088]
name: dttm [22084,22088]
===
match
---
operator: = [108629,108630]
operator: = [108728,108729]
===
match
---
operator: -> [30780,30782]
operator: -> [30780,30782]
===
match
---
name: _max_active_tasks [31229,31246]
name: _max_active_tasks [31229,31246]
===
match
---
trailer [87304,87321]
trailer [87403,87420]
===
match
---
if_stmt [55200,55603]
if_stmt [55200,55603]
===
match
---
decorator [31057,31077]
decorator [31057,31077]
===
match
---
raise_stmt [16263,16432]
raise_stmt [16263,16432]
===
match
---
trailer [97734,97770]
trailer [97833,97869]
===
match
---
name: concurrency [11440,11451]
name: concurrency [11440,11451]
===
match
---
operator: , [67203,67204]
operator: , [67203,67204]
===
match
---
operator: , [1125,1126]
operator: , [1125,1126]
===
match
---
atom_expr [18658,18686]
atom_expr [18658,18686]
===
match
---
parameters [31889,31907]
parameters [31889,31907]
===
match
---
atom_expr [77223,77242]
atom_expr [77223,77242]
===
match
---
trailer [17233,17253]
trailer [17233,17253]
===
match
---
trailer [92056,92060]
trailer [92155,92159]
===
match
---
trailer [74239,74241]
trailer [74239,74241]
===
match
---
operator: = [57774,57775]
operator: = [57774,57775]
===
match
---
operator: , [3169,3170]
operator: , [3169,3170]
===
match
---
operator: , [69176,69177]
operator: , [69176,69177]
===
match
---
name: dag_ids [61698,61705]
name: dag_ids [61698,61705]
===
match
---
atom_expr [97723,97770]
atom_expr [97822,97869]
===
match
---
trailer [73076,73078]
trailer [73076,73078]
===
match
---
param [44822,44836]
param [44822,44836]
===
match
---
simple_stmt [96754,96801]
simple_stmt [96853,96900]
===
match
---
expr_stmt [33164,33197]
expr_stmt [33164,33197]
===
match
---
name: max_active_tasks [97330,97346]
name: max_active_tasks [97429,97445]
===
match
---
argument [94364,94380]
argument [94463,94479]
===
match
---
not_test [58470,58492]
not_test [58470,58492]
===
match
---
param [18877,18883]
param [18877,18883]
===
match
---
atom_expr [106827,106846]
atom_expr [106926,106945]
===
match
---
name: Set [46800,46803]
name: Set [46800,46803]
===
match
---
name: self [97911,97915]
name: self [98010,98014]
===
match
---
funcdef [103014,104054]
funcdef [103113,104153]
===
match
---
funcdef [31780,31849]
funcdef [31780,31849]
===
match
---
name: task [76938,76942]
name: task [76938,76942]
===
match
---
name: default_view [100648,100660]
name: default_view [100747,100759]
===
match
---
operator: = [54270,54271]
operator: = [54270,54271]
===
match
---
if_stmt [79283,79583]
if_stmt [79283,79583]
===
match
---
trailer [103829,103831]
trailer [103928,103930]
===
match
---
name: timetables [2335,2345]
name: timetables [2335,2345]
===
match
---
expr_stmt [87133,87158]
expr_stmt [87232,87257]
===
match
---
name: new_perm_mapping [19785,19801]
name: new_perm_mapping [19785,19801]
===
match
---
tfpdef [101994,102023]
tfpdef [102093,102122]
===
match
---
name: session [61340,61347]
name: session [61340,61347]
===
match
---
simple_stmt [1514,1557]
simple_stmt [1514,1557]
===
match
---
name: self [73994,73998]
name: self [73994,73998]
===
match
---
argument [70886,70900]
argument [70886,70900]
===
match
---
simple_stmt [30102,30122]
simple_stmt [30102,30122]
===
match
---
name: next_dagrun_data_interval [98038,98063]
name: next_dagrun_data_interval [98137,98162]
===
match
---
operator: ** [42926,42928]
operator: ** [42926,42928]
===
match
---
argument [67776,67797]
argument [67776,67797]
===
match
---
operator: = [14705,14706]
operator: = [14705,14706]
===
match
---
atom_expr [89050,89088]
atom_expr [89149,89187]
===
match
---
if_stmt [19846,20154]
if_stmt [19846,20154]
===
match
---
comparison [102538,102567]
comparison [102637,102666]
===
match
---
name: dict [80726,80730]
name: dict [80726,80730]
===
match
---
arglist [103684,103832]
arglist [103783,103931]
===
match
---
name: self [21135,21139]
name: self [21135,21139]
===
match
---
atom_expr [41273,41305]
atom_expr [41273,41305]
===
match
---
name: DateTime [22186,22194]
name: DateTime [22186,22194]
===
match
---
name: qry [91628,91631]
name: qry [91727,91730]
===
match
---
trailer [59552,59558]
trailer [59552,59558]
===
match
---
operator: , [77526,77527]
operator: , [77526,77527]
===
match
---
atom_expr [41632,41664]
atom_expr [41632,41664]
===
match
---
simple_stmt [74410,74419]
simple_stmt [74410,74419]
===
match
---
operator: = [85309,85310]
operator: = [85408,85409]
===
match
---
operator: @ [35054,35055]
operator: @ [35054,35055]
===
match
---
operator: @ [39914,39915]
operator: @ [39914,39915]
===
match
---
argument [54832,54876]
argument [54832,54876]
===
match
---
param [12350,12394]
param [12350,12394]
===
match
---
name: upstream_list [58479,58492]
name: upstream_list [58479,58492]
===
match
---
name: start_date [46345,46355]
name: start_date [46345,46355]
===
match
---
name: dag_id [86714,86720]
name: dag_id [86813,86819]
===
match
---
simple_stmt [32962,32996]
simple_stmt [32962,32996]
===
match
---
expr_stmt [16206,16236]
expr_stmt [16206,16236]
===
match
---
operator: , [41647,41648]
operator: , [41647,41648]
===
match
---
operator: == [52993,52995]
operator: == [52993,52995]
===
match
---
name: expression [38839,38849]
name: expression [38839,38849]
===
match
---
name: join [33746,33750]
name: join [33746,33750]
===
match
---
operator: , [25508,25509]
operator: , [25508,25509]
===
match
---
trailer [73298,73300]
trailer [73298,73300]
===
match
---
name: datetime [47450,47458]
name: datetime [47450,47458]
===
match
---
suite [21206,21231]
suite [21206,21231]
===
match
---
atom_expr [55578,55600]
atom_expr [55578,55600]
===
match
---
operator: , [53832,53833]
operator: , [53832,53833]
===
match
---
trailer [74657,74668]
trailer [74657,74668]
===
match
---
dotted_name [1317,1335]
dotted_name [1317,1335]
===
match
---
name: filter [55038,55044]
name: filter [55038,55044]
===
match
---
operator: == [59560,59562]
operator: == [59560,59562]
===
match
---
operator: , [75459,75460]
operator: , [75459,75460]
===
match
---
operator: = [21535,21536]
operator: = [21535,21536]
===
match
---
simple_stmt [1247,1263]
simple_stmt [1247,1263]
===
match
---
name: child [72313,72318]
name: child [72313,72318]
===
match
---
trailer [94067,94078]
trailer [94166,94177]
===
match
---
name: stacklevel [20126,20136]
name: stacklevel [20126,20136]
===
match
---
name: task_ids [53819,53827]
name: task_ids [53819,53827]
===
match
---
trailer [16594,16614]
trailer [16594,16614]
===
match
---
name: is_paused_upon_creation [17398,17421]
name: is_paused_upon_creation [17398,17421]
===
match
---
name: in_ [85923,85926]
name: in_ [86022,86025]
===
match
---
simple_stmt [2397,2491]
simple_stmt [2397,2491]
===
match
---
atom_expr [67482,67516]
atom_expr [67482,67516]
===
match
---
import_from [79224,79273]
import_from [79224,79273]
===
match
---
atom_expr [96036,96048]
atom_expr [96135,96147]
===
match
---
operator: = [3310,3311]
operator: = [3310,3311]
===
match
---
operator: = [84867,84868]
operator: = [84966,84967]
===
match
---
name: _schedule_interval [36259,36277]
name: _schedule_interval [36259,36277]
===
match
---
trailer [11319,11325]
trailer [11319,11325]
===
match
---
trailer [49963,49969]
trailer [49963,49969]
===
match
---
comparison [74535,74565]
comparison [74535,74565]
===
match
---
atom_expr [90414,90541]
atom_expr [90513,90640]
===
match
---
return_stmt [22041,22090]
return_stmt [22041,22090]
===
match
---
operator: , [75425,75426]
operator: , [75425,75426]
===
match
---
simple_stmt [34935,35004]
simple_stmt [34935,35004]
===
match
---
name: commit [90843,90849]
name: commit [90942,90948]
===
match
---
expr_stmt [37352,37364]
expr_stmt [37352,37364]
===
match
---
trailer [48138,48153]
trailer [48138,48153]
===
match
---
operator: = [74042,74043]
operator: = [74042,74043]
===
match
---
comparison [51688,51730]
comparison [51688,51730]
===
match
---
fstring_end: ' [16065,16066]
fstring_end: ' [16065,16066]
===
match
---
operator: = [48837,48838]
operator: = [48837,48838]
===
match
---
name: value [35298,35303]
name: value [35298,35303]
===
match
---
suite [87910,88053]
suite [88009,88152]
===
match
---
or_test [74726,74753]
or_test [74726,74753]
===
match
---
trailer [46197,46216]
trailer [46197,46216]
===
match
---
trailer [43302,43329]
trailer [43302,43329]
===
match
---
trailer [22185,22194]
trailer [22185,22194]
===
match
---
operator: , [1499,1500]
operator: , [1499,1500]
===
match
---
trailer [39817,39824]
trailer [39817,39824]
===
match
---
name: str [47440,47443]
name: str [47440,47443]
===
match
---
name: self [48689,48693]
name: self [48689,48693]
===
match
---
operator: { [101822,101823]
operator: { [101921,101922]
===
match
---
operator: = [45430,45431]
operator: = [45430,45431]
===
match
---
arglist [24727,24757]
arglist [24727,24757]
===
match
---
name: items [19732,19737]
name: items [19732,19737]
===
match
---
operator: , [25434,25435]
operator: , [25434,25435]
===
match
---
param [11044,11080]
param [11044,11080]
===
match
---
trailer [100182,100189]
trailer [100281,100288]
===
match
---
trailer [76355,76364]
trailer [76355,76364]
===
match
---
name: filter [101775,101781]
name: filter [101874,101880]
===
match
---
for_stmt [86666,88425]
for_stmt [86765,88524]
===
match
---
name: self [48381,48385]
name: self [48381,48385]
===
match
---
atom_expr [24214,24229]
atom_expr [24214,24229]
===
match
---
atom_expr [87833,87843]
atom_expr [87932,87942]
===
match
---
simple_stmt [13513,13544]
simple_stmt [13513,13544]
===
match
---
expr_stmt [13739,13768]
expr_stmt [13739,13768]
===
match
---
name: task_id [55401,55408]
name: task_id [55401,55408]
===
match
---
comparison [87620,87650]
comparison [87719,87749]
===
match
---
name: self [76507,76511]
name: self [76507,76511]
===
match
---
name: max_recursion_depth [52703,52722]
name: max_recursion_depth [52703,52722]
===
match
---
name: dag_id [91561,91567]
name: dag_id [91660,91666]
===
match
---
name: Optional [104138,104146]
name: Optional [104237,104245]
===
match
---
name: Boolean [95132,95139]
name: Boolean [95231,95238]
===
match
---
simple_stmt [37737,37775]
simple_stmt [37737,37775]
===
match
---
name: query [38932,38937]
name: query [38932,38937]
===
match
---
expr_stmt [79394,79420]
expr_stmt [79394,79420]
===
match
---
name: session [104036,104043]
name: session [104135,104142]
===
match
---
name: min_date [44694,44702]
name: min_date [44694,44702]
===
match
---
simple_stmt [90835,90852]
simple_stmt [90934,90951]
===
match
---
comparison [40855,40883]
comparison [40855,40883]
===
match
---
name: Literal [2642,2649]
name: Literal [2642,2649]
===
match
---
name: session [89080,89087]
name: session [89179,89186]
===
match
---
name: DeprecationWarning [35886,35904]
name: DeprecationWarning [35886,35904]
===
match
---
atom_expr [87175,87190]
atom_expr [87274,87289]
===
match
---
operator: , [1228,1229]
operator: , [1228,1229]
===
match
---
atom_expr [52724,52751]
atom_expr [52724,52751]
===
match
---
string: 'undefined' [42519,42530]
string: 'undefined' [42519,42530]
===
match
---
name: session [55981,55988]
name: session [55981,55988]
===
match
---
operator: = [85359,85360]
operator: = [85458,85459]
===
match
---
name: orm_dag [87406,87413]
name: orm_dag [87505,87512]
===
match
---
name: str [102019,102022]
name: str [102118,102121]
===
match
---
trailer [106554,106569]
trailer [106653,106668]
===
match
---
simple_stmt [30834,31014]
simple_stmt [30834,31014]
===
match
---
operator: = [65238,65239]
operator: = [65238,65239]
===
match
---
operator: = [73245,73246]
operator: = [73245,73246]
===
match
---
param [31308,31318]
param [31308,31318]
===
match
---
name: full_filepath [30236,30249]
name: full_filepath [30236,30249]
===
match
---
argument [53605,53627]
argument [53605,53627]
===
match
---
name: earliest [26502,26510]
name: earliest [26502,26510]
===
match
---
operator: , [55149,55150]
operator: , [55149,55150]
===
match
---
name: task [58677,58681]
name: task [58677,58681]
===
match
---
trailer [29411,29429]
trailer [29411,29429]
===
match
---
arglist [55070,55150]
arglist [55070,55150]
===
match
---
name: self [74134,74138]
name: self [74134,74138]
===
match
---
atom [45098,45596]
atom [45098,45596]
===
match
---
name: next_dagrun_info [21577,21593]
name: next_dagrun_info [21577,21593]
===
match
---
atom_expr [72709,72773]
atom_expr [72709,72773]
===
match
---
trailer [73428,73440]
trailer [73428,73440]
===
match
---
trailer [4072,4074]
trailer [4072,4074]
===
match
---
trailer [27765,27774]
trailer [27765,27774]
===
match
---
name: property [100813,100821]
name: property [100912,100920]
===
match
---
name: include_subdags [67044,67059]
name: include_subdags [67044,67059]
===
match
---
atom_expr [71647,71667]
atom_expr [71647,71667]
===
match
---
name: self [43582,43586]
name: self [43582,43586]
===
match
---
operator: -> [74476,74478]
operator: -> [74476,74478]
===
match
---
trailer [53233,53257]
trailer [53233,53257]
===
match
---
name: infer_data_interval [83028,83047]
name: infer_data_interval [83127,83146]
===
match
---
argument [45185,45206]
argument [45185,45206]
===
match
---
name: state [83332,83337]
name: state [83431,83436]
===
match
---
name: earliest [26555,26563]
name: earliest [26555,26563]
===
match
---
string: 'landing_times' [3459,3474]
string: 'landing_times' [3459,3474]
===
match
---
argument [54080,54125]
argument [54080,54125]
===
match
---
trailer [37979,37986]
trailer [37979,37986]
===
match
---
simple_stmt [1833,1878]
simple_stmt [1833,1878]
===
match
---
name: TaskNotFound [73931,73943]
name: TaskNotFound [73931,73943]
===
match
---
operator: , [20108,20109]
operator: , [20108,20109]
===
match
---
name: Stats [37737,37742]
name: Stats [37737,37742]
===
match
---
name: airflow [59214,59221]
name: airflow [59214,59221]
===
match
---
name: template_searchpath [42343,42362]
name: template_searchpath [42343,42362]
===
match
---
operator: @ [32662,32663]
operator: @ [32662,32663]
===
match
---
argument [50655,50678]
argument [50655,50678]
===
match
---
operator: , [47155,47156]
operator: , [47155,47156]
===
match
---
trailer [70587,70593]
trailer [70587,70593]
===
match
---
trailer [97294,97303]
trailer [97393,97402]
===
match
---
expr_stmt [14675,14814]
expr_stmt [14675,14814]
===
match
---
simple_stmt [1312,1361]
simple_stmt [1312,1361]
===
match
---
suite [49913,49982]
suite [49913,49982]
===
match
---
param [58287,58291]
param [58287,58291]
===
match
---
name: self [74554,74558]
name: self [74554,74558]
===
match
---
not_test [21131,21175]
not_test [21131,21175]
===
match
---
name: task_ids [45674,45682]
name: task_ids [45674,45682]
===
match
---
name: TYPE_CHECKING [3238,3251]
name: TYPE_CHECKING [3238,3251]
===
match
---
string: 'fetch' [62042,62049]
string: 'fetch' [62042,62049]
===
match
---
trailer [76492,76502]
trailer [76492,76502]
===
match
---
operator: = [16959,16960]
operator: = [16959,16960]
===
match
---
name: dag_bag [53293,53300]
name: dag_bag [53293,53300]
===
match
---
name: State [64909,64914]
name: State [64909,64914]
===
match
---
trailer [49854,49858]
trailer [49854,49858]
===
match
---
suite [32007,32323]
suite [32007,32323]
===
match
---
operator: = [105974,105975]
operator: = [106073,106074]
===
match
---
operator: , [30944,30945]
operator: , [30944,30945]
===
match
---
operator: = [77360,77361]
operator: = [77360,77361]
===
match
---
simple_stmt [29384,29396]
simple_stmt [29384,29396]
===
match
---
name: filter_for_tis [51394,51408]
name: filter_for_tis [51394,51408]
===
match
---
name: timetable [24789,24798]
name: timetable [24789,24798]
===
match
---
atom_expr [73733,73756]
atom_expr [73733,73756]
===
match
---
name: bool [46549,46553]
name: bool [46549,46553]
===
match
---
name: provide_session [38953,38968]
name: provide_session [38953,38968]
===
match
---
name: jinja_env_options [42836,42853]
name: jinja_env_options [42836,42853]
===
match
---
name: keys [84845,84849]
name: keys [84944,84948]
===
match
---
operator: = [50949,50950]
operator: = [50949,50950]
===
match
---
name: start_dates [24138,24149]
name: start_dates [24138,24149]
===
match
---
simple_stmt [74009,74016]
simple_stmt [74009,74016]
===
match
---
simple_stmt [75846,75880]
simple_stmt [75846,75880]
===
match
---
not_test [39484,39514]
not_test [39484,39514]
===
match
---
param [93845,93869]
param [93944,93968]
===
match
---
trailer [87182,87190]
trailer [87281,87289]
===
match
---
name: self [38645,38649]
name: self [38645,38649]
===
match
---
decorators [90857,90892]
decorators [90956,90991]
===
match
---
name: min [76412,76415]
name: min [76412,76415]
===
match
---
number: 0 [47356,47357]
number: 0 [47356,47357]
===
match
---
fstring_string: > [98012,98013]
fstring_string: > [98111,98112]
===
match
---
atom_expr [15227,15256]
atom_expr [15227,15256]
===
match
---
suite [52089,52312]
suite [52089,52312]
===
match
---
name: _context_managed_dag [108849,108869]
name: _context_managed_dag [108948,108968]
===
match
---
name: datetime [46820,46828]
name: datetime [46820,46828]
===
match
---
name: get_task_instances [44771,44789]
name: get_task_instances [44771,44789]
===
match
---
name: in_ [92057,92060]
name: in_ [92156,92159]
===
match
---
operator: , [92077,92078]
operator: , [92176,92177]
===
match
---
fstring_string: Inconsistent DagModel:  [98292,98315]
fstring_string: Inconsistent DagModel:  [98391,98414]
===
match
---
atom_expr [68435,68449]
atom_expr [68435,68449]
===
match
---
expr_stmt [103606,103958]
expr_stmt [103705,104057]
===
match
---
simple_stmt [74804,74820]
simple_stmt [74804,74820]
===
match
---
operator: @ [61237,61238]
operator: @ [61237,61238]
===
match
---
name: operators [41503,41512]
name: operators [41503,41512]
===
match
---
name: bool [29846,29850]
name: bool [29846,29850]
===
match
---
trailer [44534,44539]
trailer [44534,44539]
===
match
---
atom_expr [18906,18942]
atom_expr [18906,18942]
===
match
---
string: """     Returns the last dag run for a dag, None if there was none.     Last dag run can be any type of run eg. scheduled or backfilled.     Overridden DagRuns are ignored.     """ [3655,3835]
string: """     Returns the last dag run for a dag, None if there was none.     Last dag run can be any type of run eg. scheduled or backfilled.     Overridden DagRuns are ignored.     """ [3655,3835]
===
match
---
name: upstream_task_ids [72926,72943]
name: upstream_task_ids [72926,72943]
===
match
---
argument [79956,79995]
argument [79956,79995]
===
match
---
if_stmt [24299,24423]
if_stmt [24299,24423]
===
match
---
name: confirm_prompt [67444,67458]
name: confirm_prompt [67444,67458]
===
match
---
operator: = [11767,11768]
operator: = [11767,11768]
===
match
---
simple_stmt [105133,105357]
simple_stmt [105232,105456]
===
match
---
trailer [73392,73394]
trailer [73392,73394]
===
match
---
name: owner [33546,33551]
name: owner [33546,33551]
===
match
---
atom_expr [66136,66288]
atom_expr [66136,66288]
===
match
---
name: self [88806,88810]
name: self [88905,88909]
===
match
---
name: self [17622,17626]
name: self [17622,17626]
===
match
---
operator: } [58221,58222]
operator: } [58221,58222]
===
match
---
name: state [38685,38690]
name: state [38685,38690]
===
match
---
number: 25 [96129,96131]
number: 25 [96228,96230]
===
match
---
trailer [48456,48463]
trailer [48456,48463]
===
match
---
name: fileloc [87197,87204]
name: fileloc [87296,87303]
===
match
---
return_stmt [20163,20192]
return_stmt [20163,20192]
===
match
---
name: warn [97409,97413]
name: warn [97508,97512]
===
match
---
name: List [1145,1149]
name: List [1145,1149]
===
match
---
name: airflow [42887,42894]
name: airflow [42887,42894]
===
match
---
simple_stmt [100888,100977]
simple_stmt [100987,101076]
===
match
---
operator: , [100794,100795]
operator: , [100893,100894]
===
match
---
trailer [15188,15200]
trailer [15188,15200]
===
match
---
trailer [82287,82300]
trailer [82311,82324]
===
match
---
name: dag [88735,88738]
name: dag [88834,88837]
===
match
---
name: only_failed [66934,66945]
name: only_failed [66934,66945]
===
match
---
trailer [37318,37337]
trailer [37318,37337]
===
match
---
arglist [41091,41247]
arglist [41091,41247]
===
match
---
atom [38838,38901]
atom [38838,38901]
===
match
---
fstring_string: <DAG:  [17711,17717]
fstring_string: <DAG:  [17711,17717]
===
match
---
operator: , [66620,66621]
operator: , [66620,66621]
===
match
---
name: self [14230,14234]
name: self [14230,14234]
===
match
---
argument [53819,53832]
argument [53819,53832]
===
match
---
trailer [107847,107849]
trailer [107946,107948]
===
match
---
comparison [35997,36035]
comparison [35997,36035]
===
match
---
decorator [36342,36359]
decorator [36342,36359]
===
match
---
trailer [37415,37420]
trailer [37415,37420]
===
match
---
for_stmt [71730,72346]
for_stmt [71730,72346]
===
match
---
name: warnings [41064,41072]
name: warnings [41064,41072]
===
match
---
name: task_concurrency [87622,87638]
name: task_concurrency [87721,87737]
===
match
---
name: TI [55398,55400]
name: TI [55398,55400]
===
match
---
name: query [38558,38563]
name: query [38558,38563]
===
match
---
trailer [66342,66377]
trailer [66342,66377]
===
match
---
simple_stmt [23458,23610]
simple_stmt [23458,23610]
===
match
---
trailer [30471,30479]
trailer [30471,30479]
===
match
---
trailer [71748,71757]
trailer [71748,71757]
===
match
---
decorator [62056,62073]
decorator [62056,62073]
===
match
---
atom_expr [96781,96800]
atom_expr [96880,96899]
===
match
---
atom_expr [31925,31940]
atom_expr [31925,31940]
===
match
---
param [83803,83807]
param [83902,83906]
===
match
---
name: memo [68265,68269]
name: memo [68265,68269]
===
match
---
name: self [38192,38196]
name: self [38192,38196]
===
match
---
name: property [99075,99083]
name: property [99174,99182]
===
match
---
simple_stmt [86735,86768]
simple_stmt [86834,86867]
===
match
---
expr_stmt [3856,3909]
expr_stmt [3856,3909]
===
match
---
expr_stmt [16908,16963]
expr_stmt [16908,16963]
===
match
---
argument [30428,30440]
argument [30428,30440]
===
match
---
simple_stmt [19108,19390]
simple_stmt [19108,19390]
===
match
---
return_stmt [68893,68906]
return_stmt [68893,68906]
===
match
---
name: include_subdags [50602,50617]
name: include_subdags [50602,50617]
===
match
---
funcdef [73595,73973]
funcdef [73595,73973]
===
match
---
name: DagModel [85076,85084]
name: DagModel [85175,85183]
===
match
---
trailer [17157,17177]
trailer [17157,17177]
===
match
---
trailer [73293,73298]
trailer [73293,73298]
===
match
---
trailer [68483,68492]
trailer [68483,68492]
===
match
---
trailer [87998,88007]
trailer [88097,88106]
===
match
---
name: cached_property [1694,1709]
name: cached_property [1694,1709]
===
match
---
name: next_dagrun_data_interval_start [98993,99024]
name: next_dagrun_data_interval_start [99092,99123]
===
match
---
name: all [54947,54950]
name: all [54947,54950]
===
match
---
parameters [61280,61497]
parameters [61280,61497]
===
match
---
name: List [47081,47085]
name: List [47081,47085]
===
match
---
operator: = [90952,90953]
operator: = [91051,91052]
===
match
---
name: default_args [15145,15157]
name: default_args [15145,15157]
===
match
---
fstring_string:  tasks:\n [67579,67588]
fstring_string:  tasks:\n [67579,67588]
===
match
---
operator: -> [30175,30177]
operator: -> [30175,30177]
===
match
---
return_stmt [57414,57428]
return_stmt [57414,57428]
===
match
---
name: DagRun [85823,85829]
name: DagRun [85922,85928]
===
match
---
simple_stmt [871,881]
simple_stmt [871,881]
===
match
---
operator: = [18382,18383]
operator: = [18382,18383]
===
match
---
name: include_dependent_dags [46525,46547]
name: include_dependent_dags [46525,46547]
===
match
---
name: utcnow [15638,15644]
name: utcnow [15638,15644]
===
match
---
name: max_recursion_depth [50987,51006]
name: max_recursion_depth [50987,51006]
===
match
---
name: self [58456,58460]
name: self [58456,58460]
===
match
---
trailer [44641,44643]
trailer [44641,44643]
===
match
---
simple_stmt [36049,36147]
simple_stmt [36049,36147]
===
match
---
name: task [75633,75637]
name: task [75633,75637]
===
match
---
name: correct_maybe_zipped [2863,2883]
name: correct_maybe_zipped [2863,2883]
===
match
---
atom_expr [47963,47983]
atom_expr [47963,47983]
===
match
---
expr_stmt [71546,71571]
expr_stmt [71546,71571]
===
match
---
arglist [29051,29067]
arglist [29051,29067]
===
match
---
trailer [87895,87909]
trailer [87994,88008]
===
match
---
param [73614,73627]
param [73614,73627]
===
match
---
name: end_date [39977,39985]
name: end_date [39977,39985]
===
match
---
operator: = [80955,80956]
operator: = [80955,80956]
===
match
---
expr_stmt [16441,16463]
expr_stmt [16441,16463]
===
match
---
atom_expr [48850,48884]
atom_expr [48850,48884]
===
match
---
return_stmt [23161,23172]
return_stmt [23161,23172]
===
match
---
name: start_date [57944,57954]
name: start_date [57944,57954]
===
match
---
comparison [98182,98228]
comparison [98281,98327]
===
match
---
fstring_string: next_dagrun_data_interval_start= [98339,98371]
fstring_string: next_dagrun_data_interval_start= [98438,98470]
===
match
---
name: State [3171,3176]
name: State [3171,3176]
===
match
---
atom_expr [25120,25145]
atom_expr [25120,25145]
===
match
---
operator: = [71258,71259]
operator: = [71258,71259]
===
match
---
name: only_failed [64944,64955]
name: only_failed [64944,64955]
===
match
---
operator: , [93226,93227]
operator: , [93325,93326]
===
match
---
name: LoggingMixin [2975,2987]
name: LoggingMixin [2975,2987]
===
match
---
suite [91807,91875]
suite [91906,91974]
===
match
---
name: str [55709,55712]
name: str [55709,55712]
===
match
---
atom_expr [34255,34266]
atom_expr [34255,34266]
===
match
---
atom_expr [103869,103897]
atom_expr [103968,103996]
===
match
---
trailer [48501,48505]
trailer [48501,48505]
===
match
---
decorator [66429,66442]
decorator [66429,66442]
===
match
---
atom_expr [80717,80731]
atom_expr [80717,80731]
===
match
---
name: task_id [91518,91525]
name: task_id [91617,91624]
===
match
---
name: pickle [74739,74745]
name: pickle [74739,74745]
===
match
---
arglist [96839,96883]
arglist [96938,96982]
===
match
---
sync_comp_for [20711,20788]
sync_comp_for [20711,20788]
===
match
---
for_stmt [60513,61073]
for_stmt [60513,61073]
===
match
---
trailer [35968,35986]
trailer [35968,35986]
===
match
---
expr_stmt [57081,57377]
expr_stmt [57081,57377]
===
match
---
name: cols [54859,54863]
name: cols [54859,54863]
===
match
---
name: tis [55549,55552]
name: tis [55549,55552]
===
match
---
name: align [25490,25495]
name: align [25490,25495]
===
match
---
name: permissions [19571,19582]
name: permissions [19571,19582]
===
match
---
name: DeprecationWarning [20843,20861]
name: DeprecationWarning [20843,20861]
===
match
---
simple_stmt [35012,35049]
simple_stmt [35012,35049]
===
match
---
name: execution_date [61950,61964]
name: execution_date [61950,61964]
===
match
---
simple_stmt [3856,3910]
simple_stmt [3856,3910]
===
match
---
operator: -> [22203,22205]
operator: -> [22203,22205]
===
match
---
name: filter [51681,51687]
name: filter [51681,51687]
===
match
---
arglist [14126,14162]
arglist [14126,14162]
===
match
---
trailer [88285,88318]
trailer [88384,88417]
===
match
---
operator: = [82420,82421]
operator: = [82465,82466]
===
match
---
name: warnings [64655,64663]
name: warnings [64655,64663]
===
match
---
name: dag [71932,71935]
name: dag [71932,71935]
===
match
---
trailer [85065,85102]
trailer [85164,85201]
===
match
---
name: fileloc [86904,86911]
name: fileloc [87003,87010]
===
match
---
name: total_ordering [4114,4128]
name: total_ordering [4114,4128]
===
match
---
name: warnings [13313,13321]
name: warnings [13313,13321]
===
match
---
simple_stmt [93783,93793]
simple_stmt [93882,93892]
===
match
---
trailer [55085,55093]
trailer [55085,55093]
===
match
---
param [46703,46728]
param [46703,46728]
===
match
---
operator: = [65381,65382]
operator: = [65381,65382]
===
match
---
name: result [68861,68867]
name: result [68861,68867]
===
match
---
name: bulk_write_to_db [88718,88734]
name: bulk_write_to_db [88817,88833]
===
match
---
trailer [18460,18475]
trailer [18460,18475]
===
match
---
trailer [100137,100147]
trailer [100236,100246]
===
match
---
trailer [48421,48537]
trailer [48421,48537]
===
match
---
name: align [20776,20781]
name: align [20776,20781]
===
match
---
name: end_date [24446,24454]
name: end_date [24446,24454]
===
match
---
parameters [101284,101353]
parameters [101383,101452]
===
match
---
suite [31208,31247]
suite [31208,31247]
===
match
---
name: ExternalTaskMarker [51952,51970]
name: ExternalTaskMarker [51952,51970]
===
match
---
name: default_args [15087,15099]
name: default_args [15087,15099]
===
match
---
name: orm_dag [87896,87903]
name: orm_dag [87995,88002]
===
match
---
suite [82301,82387]
suite [82325,82411]
===
match
---
name: first [44553,44558]
name: first [44553,44558]
===
match
---
name: orm_dag [87175,87182]
name: orm_dag [87274,87281]
===
match
---
name: next_info [21550,21559]
name: next_info [21550,21559]
===
match
---
name: question [66095,66103]
name: question [66095,66103]
===
match
---
name: Base [94143,94147]
name: Base [94242,94246]
===
match
---
arglist [86339,86369]
arglist [86438,86468]
===
match
---
atom [71260,71395]
atom [71260,71395]
===
match
---
operator: @ [89359,89360]
operator: @ [89458,89459]
===
match
---
name: description [87414,87425]
name: description [87513,87524]
===
match
---
string: "dag" [94519,94524]
string: "dag" [94618,94623]
===
match
---
name: DAG [108748,108751]
name: DAG [108847,108850]
===
match
---
tfpdef [45989,46005]
tfpdef [45989,46005]
===
match
---
trailer [87619,87670]
trailer [87718,87769]
===
match
---
atom_expr [98797,98832]
atom_expr [98896,98931]
===
match
---
operator: , [50342,50343]
operator: , [50342,50343]
===
match
---
number: 2 [34715,34716]
number: 2 [34715,34716]
===
match
---
trailer [55559,55602]
trailer [55559,55602]
===
match
---
simple_stmt [3306,3340]
simple_stmt [3306,3340]
===
match
---
atom_expr [14707,14814]
atom_expr [14707,14814]
===
match
---
trailer [15482,15501]
trailer [15482,15501]
===
match
---
name: self [32352,32356]
name: self [32352,32356]
===
match
---
name: stacklevel [21883,21893]
name: stacklevel [21883,21893]
===
match
---
parameters [45639,46190]
parameters [45639,46190]
===
match
---
name: dp [74730,74732]
name: dp [74730,74732]
===
match
---
name: back [107560,107564]
name: back [107659,107663]
===
match
---
name: all [102480,102483]
name: all [102579,102582]
===
match
---
name: next_dagrun_data_interval [104756,104781]
name: next_dagrun_data_interval [104855,104880]
===
match
---
return_stmt [100336,100357]
return_stmt [100435,100456]
===
match
---
name: airflow [2020,2027]
name: airflow [2020,2027]
===
match
---
operator: , [97029,97030]
operator: , [97128,97129]
===
match
---
atom_expr [13840,13854]
atom_expr [13840,13854]
===
match
---
trailer [32972,32995]
trailer [32972,32995]
===
match
---
trailer [99271,99304]
trailer [99370,99403]
===
match
---
name: dag_kwargs [105513,105523]
name: dag_kwargs [105612,105622]
===
match
---
trailer [86467,86473]
trailer [86566,86572]
===
match
---
atom_expr [92464,92482]
atom_expr [92563,92581]
===
match
---
operator: = [57304,57305]
operator: = [57304,57305]
===
match
---
name: Optional [45704,45712]
name: Optional [45704,45712]
===
match
---
operator: { [98467,98468]
operator: { [98566,98567]
===
match
---
trailer [37999,38007]
trailer [37999,38007]
===
match
---
name: external_dag [53365,53377]
name: external_dag [53365,53377]
===
match
---
operator: , [14772,14773]
operator: , [14772,14773]
===
match
---
argument [66887,66904]
argument [66887,66904]
===
match
---
atom_expr [105005,105024]
atom_expr [105104,105123]
===
match
---
trailer [72841,72854]
trailer [72841,72854]
===
match
---
argument [50860,50875]
argument [50860,50875]
===
match
---
funcdef [74445,74953]
funcdef [74445,74953]
===
match
---
trailer [14721,14814]
trailer [14721,14814]
===
match
---
atom_expr [86591,86604]
atom_expr [86690,86703]
===
match
---
name: start_date [13951,13961]
name: start_date [13951,13961]
===
match
---
atom_expr [79545,79582]
atom_expr [79545,79582]
===
match
---
trailer [87548,87565]
trailer [87647,87664]
===
match
---
operator: , [66869,66870]
operator: , [66869,66870]
===
match
---
trailer [109150,109152]
trailer [109249,109251]
===
match
---
name: dttm [29444,29448]
name: dttm [29444,29448]
===
match
---
operator: , [62318,62319]
operator: , [62318,62319]
===
match
---
name: qry [92229,92232]
name: qry [92328,92331]
===
match
---
trailer [101698,101705]
trailer [101797,101804]
===
match
---
annassign [10593,10598]
annassign [10593,10598]
===
match
---
name: session [39620,39627]
name: session [39620,39627]
===
match
---
trailer [21704,21710]
trailer [21704,21710]
===
match
---
name: value [31896,31901]
name: value [31896,31901]
===
match
---
tfpdef [20236,20256]
tfpdef [20236,20256]
===
match
---
trailer [103769,103771]
trailer [103868,103870]
===
match
---
operator: { [16117,16118]
operator: { [16117,16118]
===
match
---
param [62453,62471]
param [62453,62471]
===
match
---
name: tasks [32432,32437]
name: tasks [32432,32437]
===
match
---
name: count [91499,91504]
name: count [91598,91603]
===
match
---
name: get_current [99364,99375]
name: get_current [99463,99474]
===
match
---
atom_expr [80159,80168]
atom_expr [80159,80168]
===
match
---
param [20222,20227]
param [20222,20227]
===
match
---
atom_expr [14346,14371]
atom_expr [14346,14371]
===
match
---
trailer [87140,87150]
trailer [87239,87249]
===
match
---
name: datetime [46366,46374]
name: datetime [46366,46374]
===
match
---
name: task_id [52756,52763]
name: task_id [52756,52763]
===
match
---
operator: = [29594,29595]
operator: = [29594,29595]
===
match
---
simple_stmt [21674,21711]
simple_stmt [21674,21711]
===
match
---
if_stmt [93650,93793]
if_stmt [93749,93892]
===
match
---
operator: , [96287,96288]
operator: , [96386,96387]
===
match
---
name: Set [1169,1172]
name: Set [1169,1172]
===
match
---
name: include_upstream [50279,50295]
name: include_upstream [50279,50295]
===
match
---
param [97244,97249]
param [97343,97348]
===
match
---
trailer [83056,83072]
trailer [83155,83171]
===
match
---
sync_comp_for [70574,70637]
sync_comp_for [70574,70637]
===
match
---
name: getboolean [11918,11928]
name: getboolean [11918,11928]
===
match
---
name: int [11462,11465]
name: int [11462,11465]
===
match
---
name: dag_bag [50905,50912]
name: dag_bag [50905,50912]
===
match
---
name: type [25237,25241]
name: type [25237,25241]
===
match
---
atom_expr [87354,87374]
atom_expr [87453,87473]
===
match
---
atom_expr [53495,53699]
atom_expr [53495,53699]
===
match
---
simple_stmt [105530,105821]
simple_stmt [105629,105920]
===
match
---
trailer [91527,91534]
trailer [91626,91633]
===
match
---
name: stacklevel [23888,23898]
name: stacklevel [23888,23898]
===
match
---
atom_expr [98182,98216]
atom_expr [98281,98315]
===
match
---
name: orm_tag_names [88226,88239]
name: orm_tag_names [88325,88338]
===
match
---
name: timezone [15058,15066]
name: timezone [15058,15066]
===
match
---
trailer [74089,74096]
trailer [74089,74096]
===
match
---
name: getLogger [3320,3329]
name: getLogger [3320,3329]
===
match
---
name: dag [105005,105008]
name: dag [105104,105107]
===
match
---
operator: , [92524,92525]
operator: , [92623,92624]
===
match
---
return_stmt [32389,32425]
return_stmt [32389,32425]
===
match
---
name: start_date [76077,76087]
name: start_date [76077,76087]
===
match
---
trailer [15226,15257]
trailer [15226,15257]
===
match
---
operator: = [44731,44732]
operator: = [44731,44732]
===
match
---
suite [72272,72346]
suite [72272,72346]
===
match
---
suite [64165,64400]
suite [64165,64400]
===
match
---
decorators [89964,89999]
decorators [90063,90098]
===
match
---
not_test [92382,92409]
not_test [92481,92508]
===
match
---
not_test [75813,75832]
not_test [75813,75832]
===
match
---
name: params [12846,12852]
name: params [12846,12852]
===
match
---
name: dag_id [40877,40883]
name: dag_id [40877,40883]
===
match
---
name: query [101759,101764]
name: query [101858,101863]
===
match
---
name: stacklevel [29244,29254]
name: stacklevel [29244,29254]
===
match
---
name: dict [85791,85795]
name: dict [85890,85894]
===
match
---
name: str [75130,75133]
name: str [75130,75133]
===
match
---
name: dag [71314,71317]
name: dag [71314,71317]
===
match
---
param [18871,18876]
param [18871,18876]
===
match
---
name: success [37160,37167]
name: success [37160,37167]
===
match
---
name: security [2262,2270]
name: security [2262,2270]
===
match
---
trailer [50234,50261]
trailer [50234,50261]
===
match
---
name: message [20384,20391]
name: message [20384,20391]
===
match
---
name: dag_run_state [67160,67173]
name: dag_run_state [67160,67173]
===
match
---
trailer [36284,36302]
trailer [36284,36302]
===
match
---
arglist [69249,69264]
arglist [69249,69264]
===
match
---
name: str [45783,45786]
name: str [45783,45786]
===
match
---
operator: = [83237,83238]
operator: = [83336,83337]
===
match
---
trailer [103764,103769]
trailer [103863,103868]
===
match
---
name: tis [65723,65726]
name: tis [65723,65726]
===
match
---
name: str [11113,11116]
name: str [11113,11116]
===
match
---
trailer [92091,92097]
trailer [92190,92196]
===
match
---
operator: <= [61965,61967]
operator: <= [61965,61967]
===
match
---
simple_stmt [10586,10599]
simple_stmt [10586,10599]
===
match
---
name: task_id [34212,34219]
name: task_id [34212,34219]
===
match
---
trailer [74896,74898]
trailer [74896,74898]
===
match
---
fstring_start: f" [98529,98531]
fstring_start: f" [98628,98630]
===
match
---
atom [19784,19836]
atom [19784,19836]
===
match
---
atom_expr [29647,29658]
atom_expr [29647,29658]
===
match
---
name: dagbag [1951,1957]
name: dagbag [1951,1957]
===
match
---
operator: , [14651,14652]
operator: , [14651,14652]
===
match
---
trailer [34208,34220]
trailer [34208,34220]
===
match
---
name: __name__ [41756,41764]
name: __name__ [41756,41764]
===
match
---
operator: = [80645,80646]
operator: = [80645,80646]
===
match
---
operator: , [1487,1488]
operator: , [1487,1488]
===
match
---
name: start_date [44998,45008]
name: start_date [44998,45008]
===
match
---
name: t [24189,24190]
name: t [24189,24190]
===
match
---
param [47025,47054]
param [47025,47054]
===
match
---
atom_expr [76983,76997]
atom_expr [76983,76997]
===
match
---
operator: } [73959,73960]
operator: } [73959,73960]
===
match
---
lambdef [55070,55117]
lambdef [55070,55117]
===
match
---
name: run_type [82399,82407]
name: run_type [82456,82464]
===
match
---
simple_stmt [29119,29268]
simple_stmt [29119,29268]
===
match
---
atom_expr [35667,35687]
atom_expr [35667,35687]
===
match
---
name: session [90414,90421]
name: session [90513,90520]
===
match
---
operator: = [62415,62416]
operator: = [62415,62416]
===
match
---
trailer [73943,73972]
trailer [73943,73972]
===
match
---
simple_stmt [68956,69015]
simple_stmt [68956,69015]
===
match
---
name: state [65294,65299]
name: state [65294,65299]
===
match
---
name: order_by [45530,45538]
name: order_by [45530,45538]
===
match
---
atom_expr [80408,80429]
atom_expr [80408,80429]
===
match
---
simple_stmt [24327,24381]
simple_stmt [24327,24381]
===
match
---
atom_expr [50370,51122]
atom_expr [50370,51122]
===
match
---
atom_expr [15909,15927]
atom_expr [15909,15927]
===
match
---
name: all [86175,86178]
name: all [86274,86277]
===
match
---
name: RUNNING [34298,34305]
name: RUNNING [34298,34305]
===
match
---
operator: = [34714,34715]
operator: = [34714,34715]
===
match
---
name: self [15713,15717]
name: self [15713,15717]
===
match
---
trailer [80162,80166]
trailer [80162,80166]
===
match
---
operator: = [76977,76978]
operator: = [76977,76978]
===
match
---
return_stmt [93293,93323]
return_stmt [93392,93422]
===
match
---
operator: , [70518,70519]
operator: , [70518,70519]
===
match
---
arglist [105424,105488]
arglist [105523,105587]
===
match
---
name: downstream_task_id [93845,93863]
name: downstream_task_id [93944,93962]
===
match
---
if_stmt [48808,48886]
if_stmt [48808,48886]
===
match
---
atom_expr [100092,100107]
atom_expr [100191,100206]
===
match
---
trailer [107876,107878]
trailer [107975,107977]
===
match
---
name: execution_date [53042,53056]
name: execution_date [53042,53056]
===
match
---
simple_stmt [109307,109339]
simple_stmt [109406,109438]
===
match
---
trailer [24505,24514]
trailer [24505,24514]
===
match
---
operator: == [86003,86005]
operator: == [86102,86104]
===
match
---
suite [27164,27191]
suite [27164,27191]
===
match
---
operator: = [53872,53873]
operator: = [53872,53873]
===
match
---
name: warn [34545,34549]
name: warn [34545,34549]
===
match
---
name: graph_sorted [59591,59603]
name: graph_sorted [59591,59603]
===
match
---
trailer [107022,107030]
trailer [107121,107129]
===
match
---
atom_expr [86712,86720]
atom_expr [86811,86819]
===
match
---
simple_stmt [95631,95659]
simple_stmt [95730,95758]
===
match
---
parameters [31712,31718]
parameters [31712,31718]
===
match
---
trailer [80687,80693]
trailer [80687,80693]
===
match
---
name: dag_model [102498,102507]
name: dag_model [102597,102606]
===
match
---
name: getint [97159,97165]
name: getint [97258,97264]
===
match
---
trailer [3557,3574]
trailer [3557,3574]
===
match
---
tfpdef [108743,108751]
tfpdef [108842,108850]
===
match
---
operator: , [53319,53320]
operator: , [53319,53320]
===
match
---
name: only_failed [62181,62192]
name: only_failed [62181,62192]
===
match
---
atom_expr [24338,24380]
atom_expr [24338,24380]
===
match
---
simple_stmt [24902,24925]
simple_stmt [24902,24925]
===
match
---
operator: @ [58499,58500]
operator: @ [58499,58500]
===
match
---
simple_stmt [96485,96519]
simple_stmt [96584,96618]
===
match
---
for_stmt [60572,61073]
for_stmt [60572,61073]
===
match
---
name: val [18514,18517]
name: val [18514,18517]
===
match
---
name: experimental [56968,56980]
name: experimental [56968,56980]
===
match
---
name: SCHEDULED [86081,86090]
name: SCHEDULED [86180,86189]
===
match
---
operator: = [12386,12387]
operator: = [12386,12387]
===
match
---
name: settings [33859,33867]
name: settings [33859,33867]
===
match
---
name: reason [37550,37556]
name: reason [37550,37556]
===
match
---
name: joinedload [84928,84938]
name: joinedload [85027,85037]
===
match
---
param [73608,73613]
param [73608,73613]
===
match
---
trailer [20279,20284]
trailer [20279,20284]
===
match
---
name: SerializedDagModel [108035,108053]
name: SerializedDagModel [108134,108152]
===
match
---
name: TI [55560,55562]
name: TI [55560,55562]
===
match
---
name: self [31195,31199]
name: self [31195,31199]
===
match
---
name: info [20715,20719]
name: info [20715,20719]
===
match
---
simple_stmt [96631,96683]
simple_stmt [96730,96782]
===
match
---
atom_expr [75266,75276]
atom_expr [75266,75276]
===
match
---
param [62328,62376]
param [62328,62376]
===
match
---
suite [48820,48886]
suite [48820,48886]
===
match
---
param [43374,43379]
param [43374,43379]
===
match
---
trailer [24749,24757]
trailer [24749,24757]
===
match
---
name: timezone [14384,14392]
name: timezone [14384,14392]
===
match
---
name: extend [67239,67245]
name: extend [67239,67245]
===
match
---
name: validate_key [13158,13170]
name: validate_key [13158,13170]
===
match
---
simple_stmt [76961,76999]
simple_stmt [76961,76999]
===
match
---
name: task [75076,75080]
name: task [75076,75080]
===
match
---
trailer [42656,42681]
trailer [42656,42681]
===
match
---
param [39057,39086]
param [39057,39086]
===
match
---
suite [38060,38113]
suite [38060,38113]
===
match
---
decorated [99074,99141]
decorated [99173,99240]
===
match
---
name: str [30089,30092]
name: str [30089,30092]
===
match
---
arglist [106457,106472]
arglist [106556,106571]
===
match
---
name: next_dagrun_info [104784,104800]
name: next_dagrun_info [104883,104899]
===
match
---
trailer [85558,85597]
trailer [85657,85696]
===
match
---
trailer [18662,18686]
trailer [18662,18686]
===
match
---
name: NUM_DAGS_PER_DAGRUN_QUERY [97126,97151]
name: NUM_DAGS_PER_DAGRUN_QUERY [97225,97250]
===
match
---
name: task [41888,41892]
name: task [41888,41892]
===
match
---
name: downstream_group_ids [72792,72812]
name: downstream_group_ids [72792,72812]
===
match
---
atom [3498,3522]
atom [3498,3522]
===
match
---
param [12113,12142]
param [12113,12142]
===
match
---
name: coerce_datetime [24347,24362]
name: coerce_datetime [24347,24362]
===
match
---
name: get_run_dates [28011,28024]
name: get_run_dates [28011,28024]
===
match
---
name: property [34376,34384]
name: property [34376,34384]
===
match
---
return_stmt [97984,98014]
return_stmt [98083,98113]
===
match
---
testlist_comp [73559,73588]
testlist_comp [73559,73588]
===
match
---
trailer [23518,23534]
trailer [23518,23534]
===
match
---
trailer [12877,12887]
trailer [12877,12887]
===
match
---
import_from [2608,2664]
import_from [2608,2664]
===
match
---
dictorsetmaker [19486,19643]
dictorsetmaker [19486,19643]
===
match
---
operator: , [62100,62101]
operator: , [62100,62101]
===
match
---
name: tis [49123,49126]
name: tis [49123,49126]
===
match
---
arglist [106826,106871]
arglist [106925,106970]
===
match
---
operator: = [84828,84829]
operator: = [84927,84928]
===
match
---
dictorsetmaker [71303,71317]
dictorsetmaker [71303,71317]
===
match
---
argument [96871,96883]
argument [96970,96982]
===
match
---
name: dag_id [101611,101617]
name: dag_id [101710,101716]
===
match
---
trailer [74668,74675]
trailer [74668,74675]
===
match
---
name: functools [807,816]
name: functools [807,816]
===
match
---
operator: == [38835,38837]
operator: == [38835,38837]
===
match
---
name: cls [108879,108882]
name: cls [108978,108981]
===
match
---
name: self [74456,74460]
name: self [74456,74460]
===
match
---
trailer [72303,72312]
trailer [72303,72312]
===
match
---
operator: == [4000,4002]
operator: == [4000,4002]
===
match
---
simple_stmt [3655,3836]
simple_stmt [3655,3836]
===
match
---
param [43380,43397]
param [43380,43397]
===
match
---
comparison [49312,49327]
comparison [49312,49327]
===
match
---
trailer [41892,41899]
trailer [41892,41899]
===
match
---
argument [13121,13133]
argument [13121,13133]
===
match
---
param [77493,77527]
param [77493,77527]
===
match
---
comparison [100988,101008]
comparison [101087,101107]
===
match
---
parameters [33551,33557]
parameters [33551,33557]
===
match
---
trailer [67390,67411]
trailer [67390,67411]
===
match
---
name: also_include [71061,71073]
name: also_include [71061,71073]
===
match
---
operator: = [47461,47462]
operator: = [47461,47462]
===
match
---
suite [66123,66289]
suite [66123,66289]
===
match
---
operator: , [47506,47507]
operator: , [47506,47507]
===
match
---
suite [101088,101147]
suite [101187,101246]
===
match
---
suite [13258,13544]
suite [13258,13544]
===
match
---
operator: , [42629,42630]
operator: , [42629,42630]
===
match
---
arglist [80418,80428]
arglist [80418,80428]
===
match
---
trailer [20819,20824]
trailer [20819,20824]
===
match
---
operator: = [12429,12430]
operator: = [12429,12430]
===
match
---
simple_stmt [38073,38113]
simple_stmt [38073,38113]
===
match
---
trailer [94869,94908]
trailer [94968,95007]
===
match
---
trailer [31228,31246]
trailer [31228,31246]
===
match
---
fstring_start: f' [16014,16016]
fstring_start: f' [16014,16016]
===
match
---
trailer [73737,73747]
trailer [73737,73747]
===
match
---
name: state [86468,86473]
name: state [86567,86572]
===
match
---
simple_stmt [60776,60791]
simple_stmt [60776,60791]
===
match
---
name: Optional [10892,10900]
name: Optional [10892,10900]
===
match
---
param [29788,29793]
param [29788,29793]
===
match
---
atom_expr [20479,20527]
atom_expr [20479,20527]
===
match
---
suite [49193,49982]
suite [49193,49982]
===
match
---
arglist [87833,87846]
arglist [87932,87945]
===
match
---
name: vars [92459,92463]
name: vars [92558,92562]
===
match
---
name: filter [61936,61942]
name: filter [61936,61942]
===
match
---
trailer [96042,96048]
trailer [96141,96147]
===
match
---
name: self [32459,32463]
name: self [32459,32463]
===
match
---
name: datetime [11018,11026]
name: datetime [11018,11026]
===
match
---
operator: , [80024,80025]
operator: , [80024,80025]
===
match
---
operator: = [68688,68689]
operator: = [68688,68689]
===
match
---
operator: = [52289,52290]
operator: = [52289,52290]
===
match
---
simple_stmt [88714,88765]
simple_stmt [88813,88864]
===
match
---
name: t [73093,73094]
name: t [73093,73094]
===
match
---
trailer [32405,32415]
trailer [32405,32415]
===
match
---
atom_expr [101602,101617]
atom_expr [101701,101716]
===
match
---
name: run_type [82688,82696]
name: run_type [82798,82806]
===
match
---
simple_stmt [44229,44571]
simple_stmt [44229,44571]
===
match
---
for_stmt [53132,54632]
for_stmt [53132,54632]
===
match
---
operator: , [62420,62421]
operator: , [62420,62421]
===
match
---
name: tasks [57114,57119]
name: tasks [57114,57119]
===
match
---
trailer [103872,103897]
trailer [103971,103996]
===
match
---
name: _previous_context_managed_dags [109041,109071]
name: _previous_context_managed_dags [109140,109170]
===
match
---
arglist [97166,97224]
arglist [97265,97323]
===
match
---
atom_expr [76507,76535]
atom_expr [76507,76535]
===
match
---
trailer [104673,104685]
trailer [104772,104784]
===
match
---
operator: = [53827,53828]
operator: = [53827,53828]
===
match
---
expr_stmt [85301,85342]
expr_stmt [85400,85441]
===
match
---
param [46600,46634]
param [46600,46634]
===
match
---
subscriptlist [13861,13878]
subscriptlist [13861,13878]
===
match
---
operator: , [48662,48663]
operator: , [48662,48663]
===
match
---
atom_expr [49752,49891]
atom_expr [49752,49891]
===
match
---
import_as_names [1780,1832]
import_as_names [1780,1832]
===
match
---
operator: = [107365,107366]
operator: = [107464,107465]
===
match
---
name: query [61922,61927]
name: query [61922,61927]
===
match
---
atom_expr [16934,16957]
atom_expr [16934,16957]
===
match
---
atom_expr [51525,51560]
atom_expr [51525,51560]
===
match
---
name: dag [87428,87431]
name: dag [87527,87530]
===
match
---
atom_expr [80626,80644]
atom_expr [80626,80644]
===
match
---
atom_expr [29119,29267]
atom_expr [29119,29267]
===
match
---
name: keys [18405,18409]
name: keys [18405,18409]
===
match
---
trailer [87332,87339]
trailer [87431,87438]
===
match
---
funcdef [90003,90852]
funcdef [90102,90951]
===
match
---
param [47367,47399]
param [47367,47399]
===
match
---
fstring_expr [98371,98411]
fstring_expr [98470,98510]
===
match
---
atom_expr [55013,55190]
atom_expr [55013,55190]
===
match
---
trailer [84729,84756]
trailer [84828,84855]
===
match
---
operator: { [82370,82371]
operator: { [82394,82395]
===
match
---
operator: = [80841,80842]
operator: = [80841,80842]
===
match
---
tfpdef [47165,47193]
tfpdef [47165,47193]
===
match
---
name: dag_model [102538,102547]
name: dag_model [102637,102646]
===
match
---
operator: , [104003,104004]
operator: , [104102,104103]
===
match
---
string: """Yield DagRunInfo using this DAG's timetable between given interval.          DagRunInfo instances yielded if their ``logical_date`` is not earlier         than ``earliest``, nor later than ``latest``. The instances are ordered         by their ``logical_date`` from earliest to latest.          If ``align`` is ``False``, the first run will happen immediately on         ``earliest``, even if it does not fall on the logical timetable schedule.         The default is ``True``, but subdags will ignore this value and always         behave as if this is set to ``False`` for backward compatibility.          Example: A DAG is scheduled to run every midnight (``0 0 * * *``). If         ``earliest`` is ``2021-06-03 23:00:00``, the first DagRunInfo would be         ``2021-06-03 23:00:00`` if ``align=False``, and ``2021-06-04 00:00:00``         if ``align=True``.         """ [25549,26426]
string: """Yield DagRunInfo using this DAG's timetable between given interval.          DagRunInfo instances yielded if their ``logical_date`` is not earlier         than ``earliest``, nor later than ``latest``. The instances are ordered         by their ``logical_date`` from earliest to latest.          If ``align`` is ``False``, the first run will happen immediately on         ``earliest``, even if it does not fall on the logical timetable schedule.         The default is ``True``, but subdags will ignore this value and always         behave as if this is set to ``False`` for backward compatibility.          Example: A DAG is scheduled to run every midnight (``0 0 * * *``). If         ``earliest`` is ``2021-06-03 23:00:00``, the first DagRunInfo would be         ``2021-06-03 23:00:00`` if ``align=False``, and ``2021-06-04 00:00:00``         if ``align=True``.         """ [25549,26426]
===
match
---
atom_expr [25166,25216]
atom_expr [25166,25216]
===
match
---
name: result [54912,54918]
name: result [54912,54918]
===
match
---
trailer [68498,68500]
trailer [68498,68500]
===
match
---
name: DagModel [35247,35255]
name: DagModel [35247,35255]
===
match
---
name: self [31964,31968]
name: self [31964,31968]
===
match
---
arglist [77428,77450]
arglist [77428,77450]
===
match
---
name: task_ids_or_regex [70608,70625]
name: task_ids_or_regex [70608,70625]
===
match
---
name: airflow [2889,2896]
name: airflow [2889,2896]
===
match
---
operator: , [46590,46591]
operator: , [46590,46591]
===
match
---
operator: , [20072,20073]
operator: , [20072,20073]
===
match
---
trailer [105261,105268]
trailer [105360,105367]
===
match
---
name: of [85073,85075]
name: of [85172,85174]
===
match
---
operator: = [92474,92475]
operator: = [92573,92574]
===
match
---
trailer [106661,106671]
trailer [106760,106770]
===
match
---
simple_stmt [72382,72442]
simple_stmt [72382,72442]
===
match
---
name: cols [51426,51430]
name: cols [51426,51430]
===
match
---
arith_expr [54423,54442]
arith_expr [54423,54442]
===
match
---
atom_expr [104959,104978]
atom_expr [105058,105077]
===
match
---
name: tags [87958,87962]
name: tags [88057,88061]
===
match
---
atom_expr [23714,23911]
atom_expr [23714,23911]
===
match
---
name: self [76369,76373]
name: self [76369,76373]
===
match
---
name: t [71299,71300]
name: t [71299,71300]
===
match
---
atom_expr [72313,72327]
atom_expr [72313,72327]
===
match
---
suite [28924,28974]
suite [28924,28974]
===
match
---
trailer [73411,73422]
trailer [73411,73422]
===
match
---
name: property [33369,33377]
name: property [33369,33377]
===
match
---
simple_stmt [17275,17296]
simple_stmt [17275,17296]
===
match
---
name: sys [888,891]
name: sys [888,891]
===
match
---
name: List [43828,43832]
name: List [43828,43832]
===
match
---
name: AirflowException [1780,1796]
name: AirflowException [1780,1796]
===
match
---
trailer [10900,10905]
trailer [10900,10905]
===
match
---
name: TaskInstance [2197,2209]
name: TaskInstance [2197,2209]
===
match
---
trailer [26653,26685]
trailer [26653,26685]
===
match
---
atom_expr [66821,67218]
atom_expr [66821,67218]
===
match
---
if_stmt [24580,24696]
if_stmt [24580,24696]
===
match
---
name: task_id [48494,48501]
name: task_id [48494,48501]
===
match
---
name: run_type [82466,82474]
name: run_type [82511,82519]
===
match
---
trailer [100091,100108]
trailer [100190,100207]
===
match
---
name: get_task_group_dict [72598,72617]
name: get_task_group_dict [72598,72617]
===
match
---
name: get_task [37428,37436]
name: get_task [37428,37436]
===
match
---
name: Optional [80541,80549]
name: Optional [80541,80549]
===
match
---
operator: = [14420,14421]
operator: = [14420,14421]
===
match
---
name: dag_id [44320,44326]
name: dag_id [44320,44326]
===
match
---
name: state [49552,49557]
name: state [49552,49557]
===
match
---
name: bool [11906,11910]
name: bool [11906,11910]
===
match
---
operator: == [86474,86476]
operator: == [86573,86575]
===
match
---
trailer [25415,25434]
trailer [25415,25434]
===
match
---
suite [43176,43234]
suite [43176,43234]
===
match
---
operator: , [83450,83451]
operator: , [83549,83550]
===
match
---
name: decorators [75364,75374]
name: decorators [75364,75374]
===
match
---
name: dag [104545,104548]
name: dag [104644,104647]
===
match
---
name: _previous_context_managed_dags [109116,109146]
name: _previous_context_managed_dags [109215,109245]
===
match
---
atom_expr [62571,62584]
atom_expr [62571,62584]
===
match
---
name: Interval [3075,3083]
name: Interval [3075,3083]
===
match
---
import_from [961,1001]
import_from [961,1001]
===
match
---
name: only_running [66976,66988]
name: only_running [66976,66988]
===
match
---
trailer [36091,36109]
trailer [36091,36109]
===
match
---
operator: = [58117,58118]
operator: = [58117,58118]
===
match
---
operator: ** [106848,106850]
operator: ** [106947,106949]
===
match
---
name: Column [96499,96505]
name: Column [96598,96604]
===
match
---
operator: = [80598,80599]
operator: = [80598,80599]
===
match
---
operator: = [86652,86653]
operator: = [86751,86752]
===
match
---
dotted_name [98717,98749]
dotted_name [98816,98848]
===
match
---
param [99101,99105]
param [99200,99204]
===
match
---
atom_expr [73454,73465]
atom_expr [73454,73465]
===
match
---
operator: @ [99725,99726]
operator: @ [99824,99825]
===
match
---
trailer [13321,13326]
trailer [13321,13326]
===
match
---
name: ID_LEN [94700,94706]
name: ID_LEN [94799,94805]
===
match
---
trailer [19805,19817]
trailer [19805,19817]
===
match
---
name: Column [95643,95649]
name: Column [95742,95748]
===
match
---
atom_expr [29618,29744]
atom_expr [29618,29744]
===
match
---
parameters [103038,103061]
parameters [103137,103160]
===
match
---
atom_expr [42532,42555]
atom_expr [42532,42555]
===
match
---
name: include_upstream [70917,70933]
name: include_upstream [70917,70933]
===
match
---
name: filter [40408,40414]
name: filter [40408,40414]
===
match
---
trailer [34980,34987]
trailer [34980,34987]
===
match
---
operator: @ [31766,31767]
operator: @ [31766,31767]
===
match
---
name: start_date [57859,57869]
name: start_date [57859,57869]
===
match
---
atom_expr [46804,46829]
atom_expr [46804,46829]
===
match
---
suite [18361,18413]
suite [18361,18413]
===
match
---
atom_expr [30718,30730]
atom_expr [30718,30730]
===
match
---
name: session [74804,74811]
name: session [74804,74811]
===
match
---
name: is_ [91864,91867]
name: is_ [91963,91966]
===
match
---
name: Iterable [11175,11183]
name: Iterable [11175,11183]
===
match
---
import_name [817,831]
import_name [817,831]
===
match
---
trailer [80634,80644]
trailer [80634,80644]
===
match
---
dictorsetmaker [85138,85176]
dictorsetmaker [85237,85275]
===
match
---
trailer [85527,85532]
trailer [85626,85631]
===
match
---
operator: = [74926,74927]
operator: = [74926,74927]
===
match
---
name: stacklevel [20863,20873]
name: stacklevel [20863,20873]
===
match
---
operator: = [39041,39042]
operator: = [39041,39042]
===
match
---
funcdef [20198,20899]
funcdef [20198,20899]
===
match
---
operator: = [15056,15057]
operator: = [15056,15057]
===
match
---
name: task [77237,77241]
name: task [77237,77241]
===
match
---
name: State [34292,34297]
name: State [34292,34297]
===
match
---
trailer [27803,27809]
trailer [27803,27809]
===
match
---
operator: == [49381,49383]
operator: == [49381,49383]
===
match
---
name: session [88660,88667]
name: session [88759,88766]
===
match
---
return_stmt [38925,38946]
return_stmt [38925,38946]
===
match
---
return_stmt [34325,34369]
return_stmt [34325,34369]
===
match
---
operator: , [39985,39986]
operator: , [39985,39986]
===
match
---
name: searchpath [42494,42504]
name: searchpath [42494,42504]
===
match
---
name: filter [61761,61767]
name: filter [61761,61767]
===
match
---
param [11395,11431]
param [11395,11431]
===
match
---
name: Column [94315,94321]
name: Column [94414,94420]
===
match
---
operator: = [87060,87061]
operator: = [87159,87160]
===
match
---
name: start_date [50487,50497]
name: start_date [50487,50497]
===
match
---
argument [50805,50838]
argument [50805,50838]
===
match
---
name: dags [84154,84158]
name: dags [84253,84257]
===
match
---
expr_stmt [87578,87670]
expr_stmt [87677,87769]
===
match
---
trailer [32653,32655]
trailer [32653,32655]
===
match
---
trailer [31929,31940]
trailer [31929,31940]
===
match
---
name: getattr [17944,17951]
name: getattr [17944,17951]
===
match
---
simple_stmt [67385,67412]
simple_stmt [67385,67412]
===
match
---
suite [105025,105406]
suite [105124,105505]
===
match
---
name: val [18447,18450]
name: val [18447,18450]
===
match
---
simple_stmt [85610,85631]
simple_stmt [85709,85730]
===
match
---
name: timezone [28797,28805]
name: timezone [28797,28805]
===
match
---
arglist [94634,94666]
arglist [94733,94765]
===
match
---
string: '.' [100791,100794]
string: '.' [100890,100893]
===
match
---
name: days [10980,10984]
name: days [10980,10984]
===
match
---
operator: { [71302,71303]
operator: { [71302,71303]
===
match
---
atom_expr [65896,66050]
atom_expr [65896,66050]
===
match
---
name: include_parentdag [58044,58061]
name: include_parentdag [58044,58061]
===
match
---
suite [94149,94432]
suite [94248,94531]
===
match
---
operator: , [101632,101633]
operator: , [101731,101732]
===
match
---
string: 'end_date' [14583,14593]
string: 'end_date' [14583,14593]
===
match
---
name: group_by [86138,86146]
name: group_by [86237,86245]
===
match
---
atom_expr [74882,74898]
atom_expr [74882,74898]
===
match
---
name: serialized_dag [108005,108019]
name: serialized_dag [108104,108118]
===
match
---
operator: , [39085,39086]
operator: , [39085,39086]
===
match
---
name: node [60830,60834]
name: node [60830,60834]
===
match
---
funcdef [93798,94128]
funcdef [93897,94227]
===
match
---
name: visited_external_tis [51802,51822]
name: visited_external_tis [51802,51822]
===
match
---
name: tis [54943,54946]
name: tis [54943,54946]
===
match
---
operator: + [52348,52349]
operator: + [52348,52349]
===
match
---
number: 10 [97222,97224]
number: 10 [97321,97323]
===
match
---
tfpdef [45732,45760]
tfpdef [45732,45760]
===
match
---
name: dag_id [97044,97050]
name: dag_id [97143,97149]
===
match
---
name: next_dagrun_info [104526,104542]
name: next_dagrun_info [104625,104641]
===
match
---
name: future [55864,55870]
name: future [55864,55870]
===
match
---
expr_stmt [65686,65701]
expr_stmt [65686,65701]
===
match
---
operator: , [68928,68929]
operator: , [68928,68929]
===
match
---
tfpdef [23648,23703]
tfpdef [23648,23703]
===
match
---
name: dag_id [100101,100107]
name: dag_id [100200,100206]
===
match
---
parameters [44789,44867]
parameters [44789,44867]
===
match
---
name: state [49614,49619]
name: state [49614,49619]
===
match
---
name: group [72894,72899]
name: group [72894,72899]
===
match
---
operator: = [13530,13531]
operator: = [13530,13531]
===
match
---
arglist [87738,87848]
arglist [87837,87947]
===
match
---
atom_expr [15655,15671]
atom_expr [15655,15671]
===
match
---
name: is_active [87268,87277]
name: is_active [87367,87376]
===
match
---
name: catchup [16446,16453]
name: catchup [16446,16453]
===
match
---
operator: = [70894,70895]
operator: = [70894,70895]
===
match
---
simple_stmt [15909,15948]
simple_stmt [15909,15948]
===
match
---
trailer [61027,61044]
trailer [61027,61044]
===
match
---
name: get_serialized_fields [92268,92289]
name: get_serialized_fields [92367,92388]
===
match
---
trailer [17397,17421]
trailer [17397,17421]
===
match
---
name: start_date [75614,75624]
name: start_date [75614,75624]
===
match
---
name: warnings [19903,19911]
name: warnings [19903,19911]
===
match
---
comparison [52332,52373]
comparison [52332,52373]
===
match
---
name: tis [55363,55366]
name: tis [55363,55366]
===
match
---
param [77399,77452]
param [77399,77452]
===
match
---
if_stmt [64619,64829]
if_stmt [64619,64829]
===
match
---
dictorsetmaker [100276,100326]
dictorsetmaker [100375,100425]
===
match
---
atom_expr [44943,44985]
atom_expr [44943,44985]
===
match
---
name: concurrency [97250,97261]
name: concurrency [97349,97360]
===
match
---
atom_expr [15478,15501]
atom_expr [15478,15501]
===
match
---
atom_expr [65842,65872]
atom_expr [65842,65872]
===
match
---
decorated [34375,34774]
decorated [34375,34774]
===
match
---
simple_stmt [83561,83576]
simple_stmt [83660,83675]
===
match
---
operator: , [13103,13104]
operator: , [13103,13104]
===
match
---
name: num [20441,20444]
name: num [20441,20444]
===
match
---
name: doc_md [12113,12119]
name: doc_md [12113,12119]
===
match
---
simple_stmt [70849,70902]
simple_stmt [70849,70902]
===
match
---
operator: , [10349,10350]
operator: , [10349,10350]
===
match
---
name: downstream_task_id [93733,93751]
name: downstream_task_id [93832,93850]
===
match
---
name: self [75864,75868]
name: self [75864,75868]
===
match
---
operator: , [97266,97267]
operator: , [97365,97366]
===
match
---
simple_stmt [91992,92131]
simple_stmt [92091,92230]
===
match
---
name: _log [68868,68872]
name: _log [68868,68872]
===
match
---
suite [42868,42963]
suite [42868,42963]
===
match
---
trailer [51976,51981]
trailer [51976,51981]
===
match
---
simple_stmt [22041,22091]
simple_stmt [22041,22091]
===
match
---
operator: , [62123,62124]
operator: , [62123,62124]
===
match
---
simple_stmt [15655,15705]
simple_stmt [15655,15705]
===
match
---
name: default_args [12625,12637]
name: default_args [12625,12637]
===
match
---
simple_stmt [49249,49295]
simple_stmt [49249,49295]
===
match
---
name: task [58712,58716]
name: task [58712,58716]
===
match
---
parameters [21737,21749]
parameters [21737,21749]
===
match
---
operator: , [50838,50839]
operator: , [50838,50839]
===
match
---
operator: = [57280,57281]
operator: = [57280,57281]
===
match
---
simple_stmt [30460,30480]
simple_stmt [30460,30480]
===
match
---
simple_stmt [109219,109234]
simple_stmt [109318,109333]
===
match
---
simple_stmt [43856,44221]
simple_stmt [43856,44221]
===
match
---
trailer [16445,16453]
trailer [16445,16453]
===
match
---
name: TaskInstance [48481,48493]
name: TaskInstance [48481,48493]
===
match
---
string: 'template_searchpath' [92867,92888]
string: 'template_searchpath' [92966,92987]
===
match
---
expr_stmt [91474,91588]
expr_stmt [91573,91687]
===
match
---
atom_expr [31029,31051]
atom_expr [31029,31051]
===
match
---
operator: = [77540,77541]
operator: = [77540,77541]
===
match
---
operator: = [15201,15202]
operator: = [15201,15202]
===
match
---
operator: , [50465,50466]
operator: , [50465,50466]
===
match
---
operator: = [44830,44831]
operator: = [44830,44831]
===
match
---
arglist [75421,75435]
arglist [75421,75435]
===
match
---
atom_expr [40872,40883]
atom_expr [40872,40883]
===
match
---
try_stmt [37571,37775]
try_stmt [37571,37775]
===
match
---
atom_expr [51758,51772]
atom_expr [51758,51772]
===
match
---
operator: , [19557,19558]
operator: , [19557,19558]
===
match
---
name: Boolean [95029,95036]
name: Boolean [95128,95135]
===
match
---
trailer [89865,89867]
trailer [89964,89966]
===
match
---
trailer [71564,71571]
trailer [71564,71571]
===
match
---
atom_expr [31124,31146]
atom_expr [31124,31146]
===
match
---
trailer [13986,13995]
trailer [13986,13995]
===
match
---
argument [106046,106055]
argument [106145,106154]
===
match
---
simple_stmt [16206,16237]
simple_stmt [16206,16237]
===
match
---
operator: = [24689,24690]
operator: = [24689,24690]
===
match
---
param [77024,77029]
param [77024,77029]
===
match
---
name: executor [79394,79402]
name: executor [79394,79402]
===
match
---
expr_stmt [91828,91874]
expr_stmt [91927,91973]
===
match
---
fstring_expr [25287,25298]
fstring_expr [25287,25298]
===
match
---
name: used_group_ids [76594,76608]
name: used_group_ids [76594,76608]
===
match
---
name: state [49384,49389]
name: state [49384,49389]
===
match
---
name: f [107021,107022]
name: f [107120,107121]
===
match
---
simple_stmt [57614,57630]
simple_stmt [57614,57630]
===
match
---
return_stmt [40794,40893]
return_stmt [40794,40893]
===
match
---
trailer [98472,98502]
trailer [98571,98601]
===
match
---
atom_expr [85311,85342]
atom_expr [85410,85441]
===
match
---
name: remote_side [97031,97042]
name: remote_side [97130,97141]
===
match
---
suite [15358,15415]
suite [15358,15415]
===
match
---
expr_stmt [104751,104814]
expr_stmt [104850,104913]
===
match
---
operator: @ [30744,30745]
operator: @ [30744,30745]
===
match
---
expr_stmt [74639,74714]
expr_stmt [74639,74714]
===
match
---
name: f [105838,105839]
name: f [105937,105938]
===
match
---
expr_stmt [76033,76088]
expr_stmt [76033,76088]
===
match
---
operator: = [45344,45345]
operator: = [45344,45345]
===
match
---
name: sqlalchemy [1562,1572]
name: sqlalchemy [1562,1572]
===
match
---
operator: == [53057,53059]
operator: == [53057,53059]
===
match
---
name: dag_id [86760,86766]
name: dag_id [86859,86865]
===
match
---
tfpdef [45770,45798]
tfpdef [45770,45798]
===
match
---
trailer [59408,59453]
trailer [59408,59453]
===
match
---
name: confirm_prompt [62236,62250]
name: confirm_prompt [62236,62250]
===
match
---
atom_expr [71696,71711]
atom_expr [71696,71711]
===
match
---
import_from [56944,57008]
import_from [56944,57008]
===
match
---
name: cols [51436,51440]
name: cols [51436,51440]
===
match
---
number: 2 [84105,84106]
number: 2 [84204,84205]
===
match
---
atom_expr [33247,33267]
atom_expr [33247,33267]
===
match
---
name: start_date [83238,83248]
name: start_date [83337,83347]
===
match
---
operator: , [54442,54443]
operator: , [54442,54443]
===
match
---
param [100749,100753]
param [100848,100852]
===
match
---
tfpdef [80661,80693]
tfpdef [80661,80693]
===
match
---
atom_expr [79405,79420]
atom_expr [79405,79420]
===
match
---
expr_stmt [67639,67680]
expr_stmt [67639,67680]
===
match
---
name: self [89336,89340]
name: self [89435,89439]
===
match
---
name: DAG [92464,92467]
name: DAG [92563,92566]
===
match
---
trailer [45580,45584]
trailer [45580,45584]
===
match
---
name: start_date [80614,80624]
name: start_date [80614,80624]
===
match
---
import_from [2107,2147]
import_from [2107,2147]
===
match
---
name: task_ids_or_regex [53548,53565]
name: task_ids_or_regex [53548,53565]
===
match
---
name: Callable [105841,105849]
name: Callable [105940,105948]
===
match
---
name: dag_id [87837,87843]
name: dag_id [87936,87942]
===
match
---
string: 'stacktrace' [74363,74375]
string: 'stacktrace' [74363,74375]
===
match
---
expr_stmt [61731,61795]
expr_stmt [61731,61795]
===
match
---
name: run_id [82445,82451]
name: run_id [82490,82496]
===
match
---
expr_stmt [74911,74933]
expr_stmt [74911,74933]
===
match
---
trailer [101061,101075]
trailer [101160,101174]
===
match
---
atom [74013,74015]
atom [74013,74015]
===
match
---
trailer [39824,39879]
trailer [39824,39879]
===
match
---
dotted_name [2546,2571]
dotted_name [2546,2571]
===
match
---
expr_stmt [55442,55499]
expr_stmt [55442,55499]
===
match
---
expr_stmt [98988,99068]
expr_stmt [99087,99167]
===
match
---
if_stmt [54786,54954]
if_stmt [54786,54954]
===
match
---
trailer [21149,21159]
trailer [21149,21159]
===
match
---
name: get [36083,36086]
name: get [36083,36086]
===
match
---
operator: = [80324,80325]
operator: = [80324,80325]
===
match
---
name: name [31970,31974]
name: name [31970,31974]
===
match
---
name: base [2346,2350]
name: base [2346,2350]
===
match
---
trailer [66084,66094]
trailer [66084,66094]
===
match
---
name: as_pk_tuple [54789,54800]
name: as_pk_tuple [54789,54800]
===
match
---
comparison [44313,44341]
comparison [44313,44341]
===
match
---
if_stmt [82270,82387]
if_stmt [82294,82411]
===
match
---
operator: , [68572,68573]
operator: , [68572,68573]
===
match
---
name: TI [53039,53041]
name: TI [53039,53041]
===
match
---
expr_stmt [74074,74098]
expr_stmt [74074,74098]
===
match
---
operator: , [20291,20292]
operator: , [20291,20292]
===
match
---
name: State [65097,65102]
name: State [65097,65102]
===
match
---
param [58760,58765]
param [58760,58765]
===
match
---
atom_expr [107350,107364]
atom_expr [107449,107463]
===
match
---
name: merge [89923,89928]
name: merge [90022,90027]
===
match
---
trailer [41642,41664]
trailer [41642,41664]
===
match
---
atom_expr [3549,3574]
atom_expr [3549,3574]
===
match
---
string: 'fetch' [101875,101882]
string: 'fetch' [101974,101981]
===
match
---
for_stmt [75176,75248]
for_stmt [75176,75248]
===
match
---
name: cls [103918,103921]
name: cls [104017,104020]
===
match
---
argument [65499,65516]
argument [65499,65516]
===
match
---
name: recursion_depth [54423,54438]
name: recursion_depth [54423,54438]
===
match
---
argument [57276,57285]
argument [57276,57285]
===
match
---
name: following [29469,29478]
name: following [29469,29478]
===
match
---
trailer [48769,48784]
trailer [48769,48784]
===
match
---
operator: = [19092,19093]
operator: = [19092,19093]
===
match
---
name: cron_presets [2787,2799]
name: cron_presets [2787,2799]
===
match
---
arglist [67776,68108]
arglist [67776,68108]
===
match
---
name: ask_yesno [66085,66094]
name: ask_yesno [66085,66094]
===
match
---
return_stmt [103968,104053]
return_stmt [104067,104152]
===
match
---
param [30529,30534]
param [30529,30534]
===
match
---
annassign [108613,108635]
annassign [108712,108734]
===
match
---
name: self [69229,69233]
name: self [69229,69233]
===
match
---
trailer [100992,101000]
trailer [101091,101099]
===
match
---
name: session [44254,44261]
name: session [44254,44261]
===
match
---
name: include_subdags [54035,54050]
name: include_subdags [54035,54050]
===
match
---
suite [76383,76446]
suite [76383,76446]
===
match
---
name: default_args [14186,14198]
name: default_args [14186,14198]
===
match
---
trailer [68641,68650]
trailer [68641,68650]
===
match
---
simple_stmt [28786,28834]
simple_stmt [28786,28834]
===
match
---
string: '.' [15689,15692]
string: '.' [15689,15692]
===
match
---
operator: , [23646,23647]
operator: , [23646,23647]
===
match
---
simple_stmt [83856,83917]
simple_stmt [83955,84016]
===
match
---
operator: , [105268,105269]
operator: , [105367,105368]
===
match
---
trailer [44527,44534]
trailer [44527,44534]
===
match
---
name: self [14622,14626]
name: self [14622,14626]
===
match
---
name: __doc__ [106975,106982]
name: __doc__ [107074,107081]
===
match
---
argument [54541,54582]
argument [54541,54582]
===
match
---
atom_expr [61768,61794]
atom_expr [61768,61794]
===
match
---
trailer [33753,33759]
trailer [33753,33759]
===
match
---
atom_expr [35247,35262]
atom_expr [35247,35262]
===
match
---
name: only_failed [64860,64871]
name: only_failed [64860,64871]
===
match
---
name: latest_execution_date [40917,40938]
name: latest_execution_date [40917,40938]
===
match
---
operator: = [85075,85076]
operator: = [85174,85175]
===
match
---
suite [93417,93793]
suite [93516,93892]
===
match
---
atom [57120,57126]
atom [57120,57126]
===
match
---
expr_stmt [79591,80150]
expr_stmt [79591,80150]
===
match
---
operator: = [52034,52035]
operator: = [52034,52035]
===
match
---
name: stacklevel [30686,30696]
name: stacklevel [30686,30696]
===
match
---
name: end_date [11044,11052]
name: end_date [11044,11052]
===
match
---
name: expression [1584,1594]
name: expression [1584,1594]
===
match
---
name: airflow [79229,79236]
name: airflow [79229,79236]
===
match
---
name: Optional [80679,80687]
name: Optional [80679,80687]
===
match
---
name: get_concurrency_reached [34748,34771]
name: get_concurrency_reached [34748,34771]
===
match
---
trailer [100198,100205]
trailer [100297,100304]
===
match
---
operator: { [16085,16086]
operator: { [16085,16086]
===
match
---
atom [108684,108686]
atom [108783,108785]
===
match
---
trailer [76059,76070]
trailer [76059,76070]
===
match
---
name: timezone [14411,14419]
name: timezone [14411,14419]
===
match
---
atom_expr [57614,57629]
atom_expr [57614,57629]
===
match
---
operator: = [61449,61450]
operator: = [61449,61450]
===
match
---
simple_stmt [39888,39909]
simple_stmt [39888,39909]
===
match
---
string: 'core' [11599,11605]
string: 'core' [11599,11605]
===
match
---
name: value [107296,107301]
name: value [107395,107400]
===
match
---
argument [84094,84106]
argument [84193,84205]
===
match
---
operator: = [83710,83711]
operator: = [83809,83810]
===
match
---
operator: = [20842,20843]
operator: = [20842,20843]
===
match
---
expr_stmt [44229,44570]
expr_stmt [44229,44570]
===
match
---
trailer [90685,90692]
trailer [90784,90791]
===
match
---
name: with_row_locks [85051,85065]
name: with_row_locks [85150,85164]
===
match
---
operator: , [26662,26663]
operator: , [26662,26663]
===
match
---
trailer [41749,41755]
trailer [41749,41755]
===
match
---
param [40689,40694]
param [40689,40694]
===
match
---
name: session [40801,40808]
name: session [40801,40808]
===
match
---
dotted_name [3262,3286]
dotted_name [3262,3286]
===
match
---
name: query [40809,40814]
name: query [40809,40814]
===
match
---
name: TaskInstanceKey [2211,2226]
name: TaskInstanceKey [2211,2226]
===
match
---
atom_expr [88343,88375]
atom_expr [88442,88474]
===
match
---
name: cls [99433,99436]
name: cls [99532,99535]
===
match
---
suite [14164,14263]
suite [14164,14263]
===
match
---
name: self [89115,89119]
name: self [89214,89218]
===
match
---
operator: -> [30256,30258]
operator: -> [30256,30258]
===
match
---
fstring_string: Invalid values of dag.default_view: only support  [16016,16065]
fstring_string: Invalid values of dag.default_view: only support  [16016,16065]
===
match
---
name: append [24267,24273]
name: append [24267,24273]
===
match
---
string: 'user_defined_macros' [68527,68548]
string: 'user_defined_macros' [68527,68548]
===
match
---
parameters [74455,74475]
parameters [74455,74475]
===
match
---
name: set [47986,47989]
name: set [47986,47989]
===
match
---
name: self [76217,76221]
name: self [76217,76221]
===
match
---
atom_expr [46848,46870]
atom_expr [46848,46870]
===
match
---
suite [74061,74250]
suite [74061,74250]
===
match
---
simple_stmt [49934,49982]
simple_stmt [49934,49982]
===
match
---
suite [23705,24056]
suite [23705,24056]
===
match
---
operator: == [74689,74691]
operator: == [74689,74691]
===
match
---
atom_expr [17198,17226]
atom_expr [17198,17226]
===
match
---
operator: , [58125,58126]
operator: , [58125,58126]
===
match
---
atom_expr [49022,49050]
atom_expr [49022,49050]
===
match
---
operator: = [80079,80080]
operator: = [80079,80080]
===
match
---
suite [51362,51561]
suite [51362,51561]
===
match
---
atom_expr [109085,109109]
atom_expr [109184,109208]
===
match
---
trailer [38092,38112]
trailer [38092,38112]
===
match
---
simple_stmt [89915,89934]
simple_stmt [90014,90033]
===
match
---
atom_expr [17788,17799]
atom_expr [17788,17799]
===
match
---
atom_expr [92459,92490]
atom_expr [92558,92589]
===
match
---
name: DeprecationWarning [13085,13103]
name: DeprecationWarning [13085,13103]
===
match
---
name: get_downstream [75223,75237]
name: get_downstream [75223,75237]
===
match
---
name: provide_session [74425,74440]
name: provide_session [74425,74440]
===
match
---
name: dateutil [1268,1276]
name: dateutil [1268,1276]
===
match
---
trailer [107537,107544]
trailer [107636,107643]
===
match
---
trailer [14582,14594]
trailer [14582,14594]
===
match
---
name: convert_to_utc [15212,15226]
name: convert_to_utc [15212,15226]
===
match
---
operator: , [96856,96857]
operator: , [96955,96956]
===
match
---
operator: = [66819,66820]
operator: = [66819,66820]
===
match
---
name: _task_group [72423,72434]
name: _task_group [72423,72434]
===
match
---
fstring_expr [16117,16131]
fstring_expr [16117,16131]
===
match
---
decorated [41311,41977]
decorated [41311,41977]
===
match
---
argument [50767,50783]
argument [50767,50783]
===
match
---
name: args [80408,80412]
name: args [80408,80412]
===
match
---
trailer [24726,24758]
trailer [24726,24758]
===
match
---
name: setter [98743,98749]
name: setter [98842,98848]
===
match
---
trailer [21576,21593]
trailer [21576,21593]
===
match
---
fstring [17709,17732]
fstring [17709,17732]
===
match
---
name: date_range [2801,2811]
name: date_range [2801,2811]
===
match
---
trailer [70449,70461]
trailer [70449,70461]
===
match
---
name: findall [70600,70607]
name: findall [70600,70607]
===
match
---
operator: = [83131,83132]
operator: = [83230,83231]
===
match
---
name: next_dagrun_data_interval [104641,104666]
name: next_dagrun_data_interval [104740,104765]
===
match
---
operator: @ [55628,55629]
operator: @ [55628,55629]
===
match
---
tfpdef [11973,12026]
tfpdef [11973,12026]
===
match
---
if_stmt [84680,84712]
if_stmt [84779,84811]
===
match
---
operator: } [67596,67597]
operator: } [67596,67597]
===
match
---
operator: , [92820,92821]
operator: , [92919,92920]
===
match
---
funcdef [35343,35688]
funcdef [35343,35688]
===
match
---
name: TypeError [25275,25284]
name: TypeError [25275,25284]
===
match
---
name: copied [71696,71702]
name: copied [71696,71702]
===
match
---
if_stmt [107888,108055]
if_stmt [107987,108154]
===
match
---
operator: } [25297,25298]
operator: } [25297,25298]
===
match
---
name: next_dagrun_info [23932,23948]
name: next_dagrun_info [23932,23948]
===
match
---
name: task [75461,75465]
name: task [75461,75465]
===
match
---
arglist [17952,17965]
arglist [17952,17965]
===
match
---
name: pathlib [100865,100872]
name: pathlib [100964,100971]
===
match
---
atom_expr [38580,38708]
atom_expr [38580,38708]
===
match
---
atom_expr [66387,66402]
atom_expr [66387,66402]
===
match
---
suite [108982,109234]
suite [109081,109333]
===
match
---
name: StrictUndefined [11239,11254]
name: StrictUndefined [11239,11254]
===
match
---
name: Tuple [47434,47439]
name: Tuple [47434,47439]
===
match
---
name: t [73339,73340]
name: t [73339,73340]
===
match
---
tfpdef [101308,101331]
tfpdef [101407,101430]
===
match
---
string: 'end_date' [14693,14703]
string: 'end_date' [14693,14703]
===
match
---
name: end_dates [24583,24592]
name: end_dates [24583,24592]
===
match
---
not_test [27458,27467]
not_test [27458,27467]
===
match
---
param [66600,66621]
param [66600,66621]
===
match
---
trailer [51451,51453]
trailer [51451,51453]
===
match
---
trailer [52847,52849]
trailer [52847,52849]
===
match
---
name: task [52291,52295]
name: task [52291,52295]
===
match
---
trailer [4019,4021]
trailer [4019,4021]
===
match
---
param [20266,20292]
param [20266,20292]
===
match
---
name: f [106097,106098]
name: f [106196,106197]
===
match
---
and_test [50064,50132]
and_test [50064,50132]
===
match
---
name: utcnow [74233,74239]
name: utcnow [74233,74239]
===
match
---
if_stmt [14112,14263]
if_stmt [14112,14263]
===
match
---
atom_expr [23685,23702]
atom_expr [23685,23702]
===
match
---
name: self [24557,24561]
name: self [24557,24561]
===
match
---
name: get [106672,106675]
name: get [106771,106774]
===
match
---
simple_stmt [23714,23912]
simple_stmt [23714,23912]
===
match
---
name: session [99419,99426]
name: session [99518,99525]
===
match
---
name: expiration_date [90486,90501]
name: expiration_date [90585,90600]
===
match
---
simple_stmt [18535,18563]
simple_stmt [18535,18563]
===
match
---
arglist [57944,58223]
arglist [57944,58223]
===
match
---
simple_stmt [12972,13149]
simple_stmt [12972,13149]
===
match
---
funcdef [77004,77243]
funcdef [77004,77243]
===
match
---
operator: = [79788,79789]
operator: = [79788,79789]
===
match
---
name: bool [45858,45862]
name: bool [45858,45862]
===
match
---
operator: , [35582,35583]
operator: , [35582,35583]
===
match
---
operator: = [51068,51069]
operator: = [51068,51069]
===
match
---
name: filter_task_group [72400,72417]
name: filter_task_group [72400,72417]
===
match
---
trailer [72040,72055]
trailer [72040,72055]
===
match
---
name: active_runs_of_dag [104983,105001]
name: active_runs_of_dag [105082,105100]
===
match
---
if_stmt [73838,73917]
if_stmt [73838,73917]
===
match
---
name: arguments [106662,106671]
name: arguments [106761,106770]
===
match
---
name: sync_to_db [88795,88805]
name: sync_to_db [88894,88904]
===
match
---
arglist [94932,94970]
arglist [95031,95069]
===
match
---
name: getattr [17970,17977]
name: getattr [17970,17977]
===
match
---
trailer [40876,40883]
trailer [40876,40883]
===
match
---
atom_expr [68410,68426]
atom_expr [68410,68426]
===
match
---
argument [83703,83718]
argument [83802,83817]
===
match
---
atom_expr [49384,49392]
atom_expr [49384,49392]
===
match
---
name: start_date [65228,65238]
name: start_date [65228,65238]
===
match
---
param [89442,89454]
param [89541,89553]
===
match
---
trailer [88738,88746]
trailer [88837,88845]
===
match
---
string: "DAG" [84255,84260]
string: "DAG" [84354,84359]
===
match
---
name: pathlib [33045,33052]
name: pathlib [33045,33052]
===
match
---
name: true [103765,103769]
name: true [103864,103868]
===
match
---
comparison [20441,20456]
comparison [20441,20456]
===
match
---
name: filter [99438,99444]
name: filter [99537,99543]
===
match
---
operator: @ [41311,41312]
operator: @ [41311,41312]
===
match
---
operator: = [20392,20393]
operator: = [20392,20393]
===
match
---
atom_expr [68803,68814]
atom_expr [68803,68814]
===
match
---
simple_stmt [106431,106474]
simple_stmt [106530,106573]
===
match
---
name: c [18248,18249]
name: c [18248,18249]
===
match
---
arglist [35497,35641]
arglist [35497,35641]
===
match
---
argument [32295,32304]
argument [32295,32304]
===
match
---
string: "Cancelled, nothing was cleared." [66343,66376]
string: "Cancelled, nothing was cleared." [66343,66376]
===
match
---
trailer [21566,21576]
trailer [21566,21576]
===
match
---
trailer [31033,31051]
trailer [31033,31051]
===
match
---
atom_expr [42338,42362]
atom_expr [42338,42362]
===
match
---
trailer [53933,53948]
trailer [53933,53948]
===
match
---
string: 'has_on_success_callback' [93201,93226]
string: 'has_on_success_callback' [93300,93325]
===
match
---
name: end_date [49165,49173]
name: end_date [49165,49173]
===
match
---
trailer [82524,82546]
trailer [82634,82656]
===
match
---
operator: , [77601,77602]
operator: , [77601,77602]
===
match
---
operator: , [3083,3084]
operator: , [3083,3084]
===
match
---
name: bool [55959,55963]
name: bool [55959,55963]
===
match
---
name: frozenset [62571,62580]
name: frozenset [62571,62580]
===
match
---
simple_stmt [101101,101147]
simple_stmt [101200,101246]
===
match
---
name: dag_ids [99787,99794]
name: dag_ids [99886,99893]
===
match
---
simple_stmt [32721,32745]
simple_stmt [32721,32745]
===
match
---
name: task_id [71921,71928]
name: task_id [71921,71928]
===
match
---
simple_stmt [57081,57378]
simple_stmt [57081,57378]
===
match
---
operator: , [58066,58067]
operator: , [58066,58067]
===
match
---
name: self [42652,42656]
name: self [42652,42656]
===
match
---
trailer [18149,18156]
trailer [18149,18156]
===
match
---
name: __init__ [97295,97303]
name: __init__ [97394,97402]
===
match
---
operator: @ [34779,34780]
operator: @ [34779,34780]
===
match
---
trailer [94692,94708]
trailer [94791,94807]
===
match
---
atom_expr [14543,14560]
atom_expr [14543,14560]
===
match
---
atom_expr [80874,80887]
atom_expr [80874,80887]
===
match
---
import_from [12452,12498]
import_from [12452,12498]
===
match
---
atom_expr [13746,13768]
atom_expr [13746,13768]
===
match
---
trailer [79418,79420]
trailer [79418,79420]
===
match
---
name: session [90835,90842]
name: session [90934,90941]
===
match
---
atom_expr [97154,97225]
atom_expr [97253,97324]
===
match
---
trailer [100647,100660]
trailer [100746,100759]
===
match
---
name: helpers [67653,67660]
name: helpers [67653,67660]
===
match
---
sync_comp_for [88118,88139]
sync_comp_for [88217,88238]
===
match
---
arglist [85823,85870]
arglist [85922,85969]
===
match
---
atom_expr [107662,107675]
atom_expr [107761,107774]
===
match
---
atom_expr [46576,46590]
atom_expr [46576,46590]
===
match
---
dotted_name [2993,3014]
dotted_name [2993,3014]
===
match
---
simple_stmt [84861,85032]
simple_stmt [84960,85131]
===
match
---
argument [53921,53948]
argument [53921,53948]
===
match
---
expr_stmt [66315,66324]
expr_stmt [66315,66324]
===
match
---
name: query [91488,91493]
name: query [91587,91592]
===
match
---
if_stmt [24498,24572]
if_stmt [24498,24572]
===
match
---
name: self [73429,73433]
name: self [73429,73433]
===
match
---
operator: = [28764,28765]
operator: = [28764,28765]
===
match
---
trailer [86057,86066]
trailer [86156,86165]
===
match
---
atom_expr [24711,24758]
atom_expr [24711,24758]
===
match
---
number: 3 [20137,20138]
number: 3 [20137,20138]
===
match
---
simple_stmt [96374,96436]
simple_stmt [96473,96535]
===
match
---
param [68259,68264]
param [68259,68264]
===
match
---
name: fileloc [102619,102626]
name: fileloc [102718,102725]
===
match
---
name: DagRun [86147,86153]
name: DagRun [86246,86252]
===
match
---
name: orm_dag [85520,85527]
name: orm_dag [85619,85626]
===
match
---
decorator [83762,83779]
decorator [83861,83878]
===
match
---
name: ti [54926,54928]
name: ti [54926,54928]
===
match
---
operator: , [68935,68936]
operator: , [68935,68936]
===
match
---
name: type [41745,41749]
name: type [41745,41749]
===
match
---
operator: = [55847,55848]
operator: = [55847,55848]
===
match
---
atom_expr [55398,55408]
atom_expr [55398,55408]
===
match
---
operator: , [24743,24744]
operator: , [24743,24744]
===
match
---
decorator [84191,84208]
decorator [84290,84307]
===
match
---
parameters [31301,31319]
parameters [31301,31319]
===
match
---
expr_stmt [13602,13639]
expr_stmt [13602,13639]
===
match
---
name: self [23927,23931]
name: self [23927,23931]
===
match
---
name: __name__ [52743,52751]
name: __name__ [52743,52751]
===
match
---
name: dag_id [17723,17729]
name: dag_id [17723,17729]
===
match
---
trailer [85371,85387]
trailer [85470,85486]
===
match
---
simple_stmt [87221,87248]
simple_stmt [87320,87347]
===
match
---
trailer [50239,50246]
trailer [50239,50246]
===
match
---
atom_expr [103754,103771]
atom_expr [103853,103870]
===
match
---
trailer [11183,11188]
trailer [11183,11188]
===
match
---
trailer [13844,13854]
trailer [13844,13854]
===
match
---
atom_expr [105472,105488]
atom_expr [105571,105587]
===
match
---
trailer [96304,96311]
trailer [96403,96410]
===
match
---
comparison [40478,40513]
comparison [40478,40513]
===
match
---
operator: = [14840,14841]
operator: = [14840,14841]
===
match
---
argument [48571,48582]
argument [48571,48582]
===
match
---
suite [76609,76712]
suite [76609,76712]
===
match
---
simple_stmt [1557,1595]
simple_stmt [1557,1595]
===
match
---
if_stmt [65801,66105]
if_stmt [65801,66105]
===
match
---
name: category [21842,21850]
name: category [21842,21850]
===
match
---
if_stmt [42759,42963]
if_stmt [42759,42963]
===
match
---
name: baseoperator [1898,1910]
name: baseoperator [1898,1910]
===
match
---
operator: -> [104197,104199]
operator: -> [104296,104298]
===
match
---
name: args [68931,68935]
name: args [68931,68935]
===
match
---
trailer [72733,72746]
trailer [72733,72746]
===
match
---
atom_expr [64178,64372]
atom_expr [64178,64372]
===
match
---
trailer [91493,91527]
trailer [91592,91626]
===
match
---
trailer [91844,91874]
trailer [91943,91973]
===
match
---
name: task_id [76943,76950]
name: task_id [76943,76950]
===
match
---
name: other [18094,18099]
name: other [18094,18099]
===
match
---
operator: = [96402,96403]
operator: = [96501,96502]
===
match
---
operator: = [11424,11425]
operator: = [11424,11425]
===
match
---
name: set [84830,84833]
name: set [84929,84932]
===
match
---
trailer [74615,74625]
trailer [74615,74625]
===
match
---
param [31620,31624]
param [31620,31624]
===
match
---
trailer [100161,100166]
trailer [100260,100265]
===
match
---
name: task [59434,59438]
name: task [59434,59438]
===
match
---
atom_expr [71077,71092]
atom_expr [71077,71092]
===
match
---
name: Session [45998,46005]
name: Session [45998,46005]
===
match
---
parameters [92289,92294]
parameters [92388,92393]
===
match
---
atom_expr [22066,22089]
atom_expr [22066,22089]
===
match
---
string: "DagModel" [97019,97029]
string: "DagModel" [97118,97128]
===
match
---
operator: , [96930,96931]
operator: , [97029,97030]
===
match
---
name: __serialized_fields [92427,92446]
name: __serialized_fields [92526,92545]
===
match
---
name: all_tis [67231,67238]
name: all_tis [67231,67238]
===
match
---
param [45839,45863]
param [45839,45863]
===
match
---
operator: , [19706,19707]
operator: , [19706,19707]
===
match
---
operator: , [3219,3220]
operator: , [3219,3220]
===
match
---
atom_expr [73578,73588]
atom_expr [73578,73588]
===
match
---
operator: , [24735,24736]
operator: , [24735,24736]
===
match
---
operator: , [57310,57311]
operator: , [57310,57311]
===
match
---
trailer [98885,98917]
trailer [98984,99016]
===
match
---
suite [67459,67681]
suite [67459,67681]
===
match
---
name: conf [11587,11591]
name: conf [11587,11591]
===
match
---
name: start_date [61877,61887]
name: start_date [61877,61887]
===
match
---
atom_expr [85403,85430]
atom_expr [85502,85529]
===
match
---
operator: - [37361,37362]
operator: - [37361,37362]
===
match
---
atom [29867,30049]
atom [29867,30049]
===
match
---
atom_expr [104888,104917]
atom_expr [104987,105016]
===
match
---
name: bool [47118,47122]
name: bool [47118,47122]
===
match
---
name: DagContext [108063,108073]
name: DagContext [108162,108172]
===
match
---
simple_stmt [95552,95585]
simple_stmt [95651,95684]
===
match
---
or_test [49075,49104]
or_test [49075,49104]
===
match
---
operator: , [69356,69357]
operator: , [69356,69357]
===
match
---
expr_stmt [94830,94908]
expr_stmt [94929,95007]
===
match
---
trailer [51424,51431]
trailer [51424,51431]
===
match
---
name: task_id [73687,73694]
name: task_id [73687,73694]
===
match
---
name: DagRun [40531,40537]
name: DagRun [40531,40537]
===
match
---
name: end_date [57988,57996]
name: end_date [57988,57996]
===
match
---
atom_expr [42652,42681]
atom_expr [42652,42681]
===
match
---
operator: == [18347,18349]
operator: == [18347,18349]
===
match
---
if_stmt [82507,82644]
if_stmt [82617,82754]
===
match
---
operator: , [40564,40565]
operator: , [40564,40565]
===
match
---
name: list [55578,55582]
name: list [55578,55582]
===
match
---
funcdef [99185,99317]
funcdef [99284,99416]
===
match
---
name: timedelta [10970,10979]
name: timedelta [10970,10979]
===
match
---
testlist_comp [24444,24488]
testlist_comp [24444,24488]
===
match
---
operator: = [57739,57740]
operator: = [57739,57740]
===
match
---
comparison [73547,73589]
comparison [73547,73589]
===
match
---
param [12190,12228]
param [12190,12228]
===
match
---
fstring_end: " [98413,98414]
fstring_end: " [98512,98513]
===
match
---
argument [57299,57310]
argument [57299,57310]
===
match
---
suite [25146,25217]
suite [25146,25217]
===
match
---
arglist [106676,106696]
arglist [106775,106795]
===
match
---
trailer [28892,28896]
trailer [28892,28896]
===
match
---
name: t [70865,70866]
name: t [70865,70866]
===
match
---
operator: ** [106464,106466]
operator: ** [106563,106565]
===
match
---
operator: = [44842,44843]
operator: = [44842,44843]
===
match
---
operator: = [74119,74120]
operator: = [74119,74120]
===
match
---
name: filter [91632,91638]
name: filter [91731,91737]
===
match
---
if_stmt [67358,67433]
if_stmt [67358,67433]
===
match
---
name: keys [73072,73076]
name: keys [73072,73076]
===
match
---
operator: = [86739,86740]
operator: = [86838,86839]
===
match
---
argument [103997,104003]
argument [104096,104102]
===
match
---
name: self [30467,30471]
name: self [30467,30471]
===
match
---
name: group [72920,72925]
name: group [72920,72925]
===
match
---
operator: , [62504,62505]
operator: , [62504,62505]
===
match
---
name: orientation [16405,16416]
name: orientation [16405,16416]
===
match
---
name: str [47076,47079]
name: str [47076,47079]
===
match
---
operator: = [95020,95021]
operator: = [95119,95120]
===
match
---
name: run_id [83157,83163]
name: run_id [83256,83262]
===
match
---
suite [49232,49295]
suite [49232,49295]
===
match
---
operator: = [54102,54103]
operator: = [54102,54103]
===
match
---
name: dag [108906,108909]
name: dag [109005,109008]
===
match
---
suite [24669,24696]
suite [24669,24696]
===
match
---
expr_stmt [73314,73395]
expr_stmt [73314,73395]
===
match
---
simple_stmt [37352,37401]
simple_stmt [37352,37401]
===
match
---
param [68930,68936]
param [68930,68936]
===
match
---
atom_expr [74361,74376]
atom_expr [74361,74376]
===
match
---
param [89115,89119]
param [89214,89218]
===
match
---
tfpdef [55942,55964]
tfpdef [55942,55964]
===
match
---
operator: = [50821,50822]
operator: = [50821,50822]
===
match
---
name: delay_on_limit_secs [77555,77574]
name: delay_on_limit_secs [77555,77574]
===
match
---
simple_stmt [20885,20899]
simple_stmt [20885,20899]
===
match
---
tfpdef [11044,11072]
tfpdef [11044,11072]
===
match
---
suite [3950,4023]
suite [3950,4023]
===
match
---
name: self [14406,14410]
name: self [14406,14410]
===
match
---
expr_stmt [89881,89902]
expr_stmt [89980,90001]
===
match
---
operator: = [94262,94263]
operator: = [94361,94362]
===
match
---
name: orm_dag [87260,87267]
name: orm_dag [87359,87366]
===
match
---
name: upstream [70886,70894]
name: upstream [70886,70894]
===
match
---
trailer [37436,37448]
trailer [37436,37448]
===
match
---
name: filter [48750,48756]
name: filter [48750,48756]
===
match
---
string: 'on_failure_callback' [92982,93003]
string: 'on_failure_callback' [93081,93102]
===
match
---
funcdef [28007,29070]
funcdef [28007,29070]
===
match
---
name: qry [91622,91625]
name: qry [91721,91724]
===
match
---
name: utils_date_range [20479,20495]
name: utils_date_range [20479,20495]
===
match
---
trailer [50184,50357]
trailer [50184,50357]
===
match
---
name: self [99521,99525]
name: self [99620,99624]
===
match
---
name: past [57276,57280]
name: past [57276,57280]
===
match
---
operator: , [75239,75240]
operator: , [75239,75240]
===
match
---
funcdef [84212,88765]
funcdef [84311,88864]
===
match
---
string: """         Sorts tasks in topographical order, such that a task comes after any of its         upstream dependencies.          Heavily inspired by:         http://blog.jupo.org/2012/04/06/topological-sorting-acyclic-directed-graphs/          :param include_subdag_tasks: whether to include tasks in subdags, default to False         :return: list of tasks in topological order         """ [58811,59200]
string: """         Sorts tasks in topographical order, such that a task comes after any of its         upstream dependencies.          Heavily inspired by:         http://blog.jupo.org/2012/04/06/topological-sorting-acyclic-directed-graphs/          :param include_subdag_tasks: whether to include tasks in subdags, default to False         :return: list of tasks in topological order         """ [58811,59200]
===
match
---
trailer [61393,61403]
trailer [61393,61403]
===
match
---
operator: , [68072,68073]
operator: , [68072,68073]
===
match
---
operator: @ [84191,84192]
operator: @ [84290,84291]
===
match
---
suite [73441,73473]
suite [73441,73473]
===
match
---
name: child [71843,71848]
name: child [71843,71848]
===
match
---
trailer [100085,100091]
trailer [100184,100190]
===
match
---
atom_expr [107367,107393]
atom_expr [107466,107492]
===
match
---
import_from [2988,3037]
import_from [2988,3037]
===
match
---
atom_expr [17774,17784]
atom_expr [17774,17784]
===
match
---
simple_stmt [2755,2832]
simple_stmt [2755,2832]
===
match
---
operator: , [96418,96419]
operator: , [96517,96518]
===
match
---
decorator [32662,32672]
decorator [32662,32672]
===
match
---
name: include_subdags [67060,67075]
name: include_subdags [67060,67075]
===
match
---
decorator [24061,24078]
decorator [24061,24078]
===
match
---
expr_stmt [67472,67516]
expr_stmt [67472,67516]
===
match
---
atom_expr [44871,44889]
atom_expr [44871,44889]
===
match
---
name: dag_model [102609,102618]
name: dag_model [102708,102717]
===
match
---
simple_stmt [15267,15310]
simple_stmt [15267,15310]
===
match
---
decorated [100812,101241]
decorated [100911,101340]
===
match
---
operator: @ [30055,30056]
operator: @ [30055,30056]
===
match
---
name: str [46436,46439]
name: str [46436,46439]
===
match
---
simple_stmt [21474,21542]
simple_stmt [21474,21542]
===
match
---
funcdef [3577,4101]
funcdef [3577,4101]
===
match
---
operator: = [66041,66042]
operator: = [66041,66042]
===
match
---
name: args [106842,106846]
name: args [106941,106945]
===
match
---
return_stmt [29488,29499]
return_stmt [29488,29499]
===
match
---
parameters [83802,83846]
parameters [83901,83945]
===
match
---
name: List [45788,45792]
name: List [45788,45792]
===
match
---
name: self [76577,76581]
name: self [76577,76581]
===
match
---
name: state [46423,46428]
name: state [46423,46428]
===
match
---
dotted_name [2670,2683]
dotted_name [2670,2683]
===
match
---
name: include_subdags [50618,50633]
name: include_subdags [50618,50633]
===
match
---
name: DagRun [61753,61759]
name: DagRun [61753,61759]
===
match
---
name: task_dict [32639,32648]
name: task_dict [32639,32648]
===
match
---
decorated [19019,20193]
decorated [19019,20193]
===
match
---
atom_expr [12810,12827]
atom_expr [12810,12827]
===
match
---
argument [95038,95051]
argument [95137,95150]
===
match
---
atom_expr [31803,31816]
atom_expr [31803,31816]
===
match
---
atom_expr [72418,72434]
atom_expr [72418,72434]
===
match
---
tfpdef [47299,47316]
tfpdef [47299,47316]
===
match
---
name: int [47388,47391]
name: int [47388,47391]
===
match
---
string: 'test' [92475,92481]
string: 'test' [92574,92580]
===
match
---
trailer [73225,73244]
trailer [73225,73244]
===
match
---
name: self [18145,18149]
name: self [18145,18149]
===
match
---
operator: = [17326,17327]
operator: = [17326,17327]
===
match
---
operator: , [1441,1442]
operator: , [1441,1442]
===
match
---
fstring_end: " [25336,25337]
fstring_end: " [25336,25337]
===
match
---
simple_stmt [881,892]
simple_stmt [881,892]
===
match
---
trailer [11017,11027]
trailer [11017,11027]
===
match
---
name: get_dagrun [38977,38987]
name: get_dagrun [38977,38987]
===
match
---
name: rerun_failed_tasks [80080,80098]
name: rerun_failed_tasks [80080,80098]
===
match
---
trailer [93732,93756]
trailer [93831,93855]
===
match
---
operator: , [29925,29926]
operator: , [29925,29926]
===
match
---
operator: = [50337,50338]
operator: = [50337,50338]
===
match
---
name: str [25141,25144]
name: str [25141,25144]
===
match
---
name: user_defined_macros [12513,12532]
name: user_defined_macros [12513,12532]
===
match
---
operator: = [12638,12639]
operator: = [12638,12639]
===
match
---
name: self [70693,70697]
name: self [70693,70697]
===
match
---
decorated [32328,32426]
decorated [32328,32426]
===
match
---
decorated [101246,101918]
decorated [101345,102017]
===
match
---
simple_stmt [54912,54954]
simple_stmt [54912,54954]
===
match
---
name: pendulum [21442,21450]
name: pendulum [21442,21450]
===
match
---
simple_stmt [31652,31677]
simple_stmt [31652,31677]
===
match
---
simple_stmt [68609,68652]
simple_stmt [68609,68652]
===
match
---
string: 'dag_default_view' [89275,89293]
string: 'dag_default_view' [89374,89392]
===
match
---
subscriptlist [3558,3573]
subscriptlist [3558,3573]
===
match
---
trailer [108768,108789]
trailer [108867,108888]
===
match
---
name: _schedule [21150,21159]
name: _schedule [21150,21159]
===
match
---
string: 'user_defined_macros' [92689,92710]
string: 'user_defined_macros' [92788,92809]
===
match
---
suite [71448,72373]
suite [71448,72373]
===
match
---
atom_expr [49209,49231]
atom_expr [49209,49231]
===
match
---
name: local [77355,77360]
name: local [77355,77360]
===
match
---
atom_expr [107533,107556]
atom_expr [107632,107655]
===
match
---
operator: = [36431,36432]
operator: = [36431,36432]
===
match
---
name: start_date [75851,75861]
name: start_date [75851,75861]
===
match
---
atom_expr [85962,86109]
atom_expr [86061,86208]
===
match
---
atom [84778,84811]
atom [84877,84910]
===
match
---
suite [30093,30122]
suite [30093,30122]
===
match
---
atom_expr [40801,40893]
atom_expr [40801,40893]
===
match
---
argument [79776,79801]
argument [79776,79801]
===
match
---
expr_stmt [26468,26510]
expr_stmt [26468,26510]
===
match
---
funcdef [89398,89959]
funcdef [89497,90058]
===
match
---
atom_expr [76979,76998]
atom_expr [76979,76998]
===
match
---
operator: = [13633,13634]
operator: = [13633,13634]
===
match
---
return_stmt [55228,55241]
return_stmt [55228,55241]
===
match
---
name: task_id [73748,73755]
name: task_id [73748,73755]
===
match
---
atom_expr [98000,98011]
atom_expr [98099,98110]
===
match
---
name: DeprecationWarning [64547,64565]
name: DeprecationWarning [64547,64565]
===
match
---
trailer [15081,15114]
trailer [15081,15114]
===
match
---
operator: = [87482,87483]
operator: = [87581,87582]
===
match
---
name: dag_id [101626,101632]
name: dag_id [101725,101731]
===
match
---
trailer [102886,102896]
trailer [102985,102995]
===
match
---
atom [39488,39514]
atom [39488,39514]
===
match
---
trailer [32400,32425]
trailer [32400,32425]
===
match
---
suite [48243,48585]
suite [48243,48585]
===
match
---
return_stmt [99586,99719]
return_stmt [99685,99818]
===
match
---
suite [104205,105490]
suite [104304,105589]
===
match
---
trailer [87832,87847]
trailer [87931,87946]
===
match
---
trailer [76221,76230]
trailer [76221,76230]
===
match
---
name: ExternalTaskMarker [51926,51944]
name: ExternalTaskMarker [51926,51944]
===
match
---
atom_expr [11714,11732]
atom_expr [11714,11732]
===
match
---
name: next_dagrun_data_interval_end [98925,98954]
name: next_dagrun_data_interval_end [99024,99053]
===
match
---
simple_stmt [57859,57909]
simple_stmt [57859,57909]
===
match
---
expr_stmt [13777,13831]
expr_stmt [13777,13831]
===
match
---
argument [69256,69264]
argument [69256,69264]
===
match
---
name: self [43208,43212]
name: self [43208,43212]
===
match
---
name: callback [37209,37217]
name: callback [37209,37217]
===
match
---
name: include_dependent_dags [47165,47187]
name: include_dependent_dags [47165,47187]
===
match
---
suite [39668,39773]
suite [39668,39773]
===
match
---
operator: , [34266,34267]
operator: , [34266,34267]
===
match
---
if_stmt [108762,108871]
if_stmt [108861,108970]
===
match
---
trailer [23693,23702]
trailer [23693,23702]
===
match
---
operator: , [57285,57286]
operator: , [57285,57286]
===
match
---
param [45989,46006]
param [45989,46006]
===
match
---
atom_expr [85204,85240]
atom_expr [85303,85339]
===
match
---
atom_expr [86824,86837]
atom_expr [86923,86936]
===
match
---
number: 2 [29255,29256]
number: 2 [29255,29256]
===
match
---
name: template_searchpath [42291,42310]
name: template_searchpath [42291,42310]
===
match
---
atom_expr [91628,91705]
atom_expr [91727,91804]
===
match
---
name: orm_dag [87221,87228]
name: orm_dag [87320,87327]
===
match
---
operator: = [94661,94662]
operator: = [94760,94761]
===
match
---
suite [15158,15258]
suite [15158,15258]
===
match
---
name: EdgeInfoType [93876,93888]
name: EdgeInfoType [93975,93987]
===
match
---
operator: = [85093,85094]
operator: = [85192,85193]
===
match
---
name: base_date [44713,44722]
name: base_date [44713,44722]
===
match
---
annassign [16922,16963]
annassign [16922,16963]
===
match
---
number: 1 [50258,50259]
number: 1 [50258,50259]
===
match
---
name: latest [26607,26613]
name: latest [26607,26613]
===
match
---
arglist [37968,38007]
arglist [37968,38007]
===
match
---
trailer [34995,35002]
trailer [34995,35002]
===
match
---
name: replace [100783,100790]
name: replace [100882,100889]
===
match
---
trailer [14125,14163]
trailer [14125,14163]
===
match
---
string: """         Creates a dag run from this dag including the tasks associated with this dag.         Returns the dag run.          :param run_id: defines the run id for this dag run         :type run_id: str         :param run_type: type of DagRun         :type run_type: airflow.utils.types.DagRunType         :param execution_date: the execution date of this dag run         :type execution_date: datetime.datetime         :param state: the state of the dag run         :type state: airflow.utils.state.DagRunState         :param start_date: the date this dag run should be evaluated         :type start_date: datetime         :param external_trigger: whether this dag run is externally triggered         :type external_trigger: bool         :param conf: Dict containing configuration/parameters to pass to the DAG         :type conf: dict         :param creating_job_id: id of the job creating this DagRun         :type creating_job_id: int         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param dag_hash: Hash of Serialized DAG         :type dag_hash: str         :param data_interval: Data interval of the DagRun         :type data_interval: tuple[datetime, datetime] | None         """ [80978,82221]
string: """         Creates a dag run from this dag including the tasks associated with this dag.         Returns the dag run.          :param run_id: defines the run id for this dag run         :type run_id: str         :param run_type: type of DagRun         :type run_type: airflow.utils.types.DagRunType         :param execution_date: the execution date of this dag run         :type execution_date: datetime.datetime         :param state: the state of the dag run         :type state: airflow.utils.state.DagRunState         :param start_date: the date this dag run should be evaluated         :type start_date: datetime         :param external_trigger: whether this dag run is externally triggered         :type external_trigger: bool         :param conf: Dict containing configuration/parameters to pass to the DAG         :type conf: dict         :param creating_job_id: id of the job creating this DagRun         :type creating_job_id: int         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param dag_hash: Hash of Serialized DAG         :type dag_hash: str         :param data_interval: Data interval of the DagRun         :type data_interval: tuple[datetime, datetime] | None         """ [80978,82221]
===
match
---
comparison [27269,27281]
comparison [27269,27281]
===
match
---
trailer [40819,40823]
trailer [40819,40823]
===
match
---
name: start_date [20507,20517]
name: start_date [20507,20517]
===
match
---
expr_stmt [72297,72345]
expr_stmt [72297,72345]
===
match
---
atom_expr [16561,16573]
atom_expr [16561,16573]
===
match
---
suite [68592,68652]
suite [68592,68652]
===
match
---
simple_stmt [74583,74593]
simple_stmt [74583,74593]
===
match
---
tfpdef [104117,104165]
tfpdef [104216,104264]
===
match
---
decorator [90875,90892]
decorator [90974,90991]
===
match
---
name: conf [80043,80047]
name: conf [80043,80047]
===
match
---
funcdef [38168,38947]
funcdef [38168,38947]
===
match
---
atom_expr [105415,105489]
atom_expr [105514,105588]
===
match
---
name: max [76051,76054]
name: max [76051,76054]
===
match
---
operator: , [20774,20775]
operator: , [20774,20775]
===
match
---
atom_expr [24540,24571]
atom_expr [24540,24571]
===
match
---
atom_expr [95975,95987]
atom_expr [96074,96086]
===
match
---
name: include_externally_triggered [3614,3642]
name: include_externally_triggered [3614,3642]
===
match
---
comparison [61852,61887]
comparison [61852,61887]
===
match
---
operator: , [94648,94649]
operator: , [94747,94748]
===
match
---
if_stmt [12942,13149]
if_stmt [12942,13149]
===
match
---
operator: -> [31719,31721]
operator: -> [31719,31721]
===
match
---
atom_expr [109112,109152]
atom_expr [109211,109251]
===
match
---
name: session [101340,101347]
name: session [101439,101446]
===
match
---
suite [75467,76999]
suite [75467,76999]
===
match
---
name: permissions [19486,19497]
name: permissions [19486,19497]
===
match
---
operator: = [15828,15829]
operator: = [15828,15829]
===
match
---
trailer [72597,72617]
trailer [72597,72617]
===
match
---
name: full_filepath [12945,12958]
name: full_filepath [12945,12958]
===
match
---
name: datetime [98822,98830]
name: datetime [98921,98929]
===
match
---
name: run [80163,80166]
name: run [80163,80166]
===
match
---
atom_expr [13792,13815]
atom_expr [13792,13815]
===
match
---
argument [54848,54853]
argument [54848,54853]
===
match
---
name: dag_id [37980,37986]
name: dag_id [37980,37986]
===
match
---
arglist [13344,13486]
arglist [13344,13486]
===
match
---
name: timezone [49087,49095]
name: timezone [49087,49095]
===
match
---
trailer [24445,24454]
trailer [24445,24454]
===
match
---
operator: = [83313,83314]
operator: = [83412,83413]
===
match
---
name: QUEUED [62369,62375]
name: QUEUED [62369,62375]
===
match
---
operator: , [105341,105342]
operator: , [105440,105441]
===
match
---
name: tis [48550,48553]
name: tis [48550,48553]
===
match
---
name: str [11184,11187]
name: str [11184,11187]
===
match
---
name: session [85094,85101]
name: session [85193,85200]
===
match
---
name: pickle_id [74916,74925]
name: pickle_id [74916,74925]
===
match
---
simple_stmt [65666,65677]
simple_stmt [65666,65677]
===
match
---
name: description [10879,10890]
name: description [10879,10890]
===
match
---
trailer [13781,13789]
trailer [13781,13789]
===
match
---
operator: = [77339,77340]
operator: = [77339,77340]
===
match
---
name: earliest [27775,27783]
name: earliest [27775,27783]
===
match
---
decorator [4103,4129]
decorator [4103,4129]
===
match
---
suite [40945,41306]
suite [40945,41306]
===
match
---
name: start_date [40503,40513]
name: start_date [40503,40513]
===
match
---
name: Union [11164,11169]
name: Union [11164,11169]
===
match
---
name: num [20519,20522]
name: num [20519,20522]
===
match
---
atom_expr [44964,44977]
atom_expr [44964,44977]
===
match
---
name: tzinfo [13962,13968]
name: tzinfo [13962,13968]
===
match
---
operator: { [85137,85138]
operator: { [85236,85237]
===
match
---
name: airflow [1936,1943]
name: airflow [1936,1943]
===
match
---
name: TaskInstance [49362,49374]
name: TaskInstance [49362,49374]
===
match
---
simple_stmt [88024,88053]
simple_stmt [88123,88152]
===
match
---
trailer [65851,65872]
trailer [65851,65872]
===
match
---
name: info [105419,105423]
name: info [105518,105522]
===
match
---
name: AirflowException [15980,15996]
name: AirflowException [15980,15996]
===
match
---
name: AirflowException [16269,16285]
name: AirflowException [16269,16285]
===
match
---
name: self [29020,29024]
name: self [29020,29024]
===
match
---
trailer [17650,17662]
trailer [17650,17662]
===
match
---
operator: } [93791,93792]
operator: } [93890,93891]
===
match
---
name: task_dict [73284,73293]
name: task_dict [73284,73293]
===
match
---
operator: , [53948,53949]
operator: , [53948,53949]
===
match
---
trailer [107849,107879]
trailer [107948,107978]
===
match
---
name: session [38580,38587]
name: session [38580,38587]
===
match
---
and_test [76472,76547]
and_test [76472,76547]
===
match
---
simple_stmt [73540,73590]
simple_stmt [73540,73590]
===
match
---
name: states [90946,90952]
name: states [91045,91051]
===
match
---
name: String [94634,94640]
name: String [94733,94739]
===
match
---
name: self [15655,15659]
name: self [15655,15659]
===
match
---
name: timedelta [44964,44973]
name: timedelta [44964,44973]
===
match
---
name: RUNNING [65103,65110]
name: RUNNING [65103,65110]
===
match
---
name: end_date [76421,76429]
name: end_date [76421,76429]
===
match
---
name: last_parsed_time [90467,90483]
name: last_parsed_time [90566,90582]
===
match
---
while_stmt [27872,28002]
while_stmt [27872,28002]
===
match
---
operator: = [17607,17608]
operator: = [17607,17608]
===
match
---
name: dttm [21460,21464]
name: dttm [21460,21464]
===
match
---
name: clear [67749,67754]
name: clear [67749,67754]
===
match
---
expr_stmt [87175,87204]
expr_stmt [87274,87303]
===
match
---
arglist [35964,35991]
arglist [35964,35991]
===
match
---
trailer [51890,51894]
trailer [51890,51894]
===
match
---
name: self [32691,32695]
name: self [32691,32695]
===
match
---
expr_stmt [24682,24695]
expr_stmt [24682,24695]
===
match
---
name: cls [103789,103792]
name: cls [103888,103891]
===
match
---
operator: , [96258,96259]
operator: , [96357,96358]
===
match
---
name: log [102340,102343]
name: log [102439,102442]
===
match
---
suite [93770,93793]
suite [93869,93892]
===
match
---
if_stmt [87927,88008]
if_stmt [88026,88107]
===
match
---
simple_stmt [87354,87394]
simple_stmt [87453,87493]
===
match
---
simple_stmt [19753,19837]
simple_stmt [19753,19837]
===
match
---
name: result [55491,55497]
name: result [55491,55497]
===
match
---
name: orm_tag_names [88094,88107]
name: orm_tag_names [88193,88206]
===
match
---
trailer [50090,50100]
trailer [50090,50100]
===
match
---
atom [37539,37557]
atom [37539,37557]
===
match
---
operator: , [2462,2463]
operator: , [2462,2463]
===
match
---
operator: , [29658,29659]
operator: , [29658,29659]
===
match
---
name: TaskInstance [48628,48640]
name: TaskInstance [48628,48640]
===
match
---
name: flush [83544,83549]
name: flush [83643,83648]
===
match
---
name: self [42033,42037]
name: self [42033,42037]
===
match
---
name: self [41273,41277]
name: self [41273,41277]
===
match
---
import_from [41490,41541]
import_from [41490,41541]
===
match
---
name: str [13861,13864]
name: str [13861,13864]
===
match
---
atom_expr [11507,11554]
atom_expr [11507,11554]
===
match
---
simple_stmt [37524,37559]
simple_stmt [37524,37559]
===
match
---
name: Column [96404,96410]
name: Column [96503,96509]
===
match
---
operator: , [44393,44394]
operator: , [44393,44394]
===
match
---
suite [82257,82453]
suite [82281,82498]
===
match
---
simple_stmt [102675,102703]
simple_stmt [102774,102802]
===
match
---
funcdef [58277,58494]
funcdef [58277,58494]
===
match
---
operator: , [15351,15352]
operator: , [15351,15352]
===
match
---
subscriptlist [46436,46450]
subscriptlist [46436,46450]
===
match
---
name: str [39036,39039]
name: str [39036,39039]
===
match
---
name: Boolean [94932,94939]
name: Boolean [95031,95038]
===
match
---
name: min [45069,45072]
name: min [45069,45072]
===
match
---
trailer [70375,70385]
trailer [70375,70385]
===
match
---
name: state [62014,62019]
name: state [62014,62019]
===
match
---
name: utils [3001,3006]
name: utils [3001,3006]
===
match
---
param [101994,102024]
param [102093,102123]
===
match
---
expr_stmt [15531,15568]
expr_stmt [15531,15568]
===
match
---
name: func [91494,91498]
name: func [91593,91597]
===
match
---
name: get_last_dagrun [3581,3596]
name: get_last_dagrun [3581,3596]
===
match
---
name: _get_task_instances [45620,45639]
name: _get_task_instances [45620,45639]
===
match
---
name: parent_dag [86995,87005]
name: parent_dag [87094,87104]
===
match
---
name: STORE_DAG_CODE [88446,88460]
name: STORE_DAG_CODE [88545,88559]
===
match
---
name: dag_id [48471,48477]
name: dag_id [48471,48477]
===
match
---
operator: { [100275,100276]
operator: { [100374,100375]
===
match
---
operator: = [77677,77678]
operator: = [77677,77678]
===
match
---
name: tii [53567,53570]
name: tii [53567,53570]
===
match
---
operator: = [76767,76768]
operator: = [76767,76768]
===
match
---
fstring_expr [16373,16394]
fstring_expr [16373,16394]
===
match
---
name: max_active_tasks [34353,34369]
name: max_active_tasks [34353,34369]
===
match
---
operator: @ [75313,75314]
operator: @ [75313,75314]
===
match
---
suite [54801,54878]
suite [54801,54878]
===
match
---
simple_stmt [18906,18943]
simple_stmt [18906,18943]
===
match
---
parameters [75075,75090]
parameters [75075,75090]
===
match
---
atom_expr [11587,11633]
atom_expr [11587,11633]
===
match
---
operator: , [44835,44836]
operator: , [44835,44836]
===
match
---
trailer [44558,44560]
trailer [44558,44560]
===
match
---
import_from [2665,2699]
import_from [2665,2699]
===
match
---
name: self [42532,42536]
name: self [42532,42536]
===
match
---
operator: , [95139,95140]
operator: , [95238,95239]
===
match
---
name: latest [27521,27527]
name: latest [27521,27527]
===
match
---
name: TaskInstance [91656,91668]
name: TaskInstance [91755,91767]
===
match
---
name: session [53321,53328]
name: session [53321,53328]
===
match
---
operator: , [107294,107295]
operator: , [107393,107394]
===
match
---
argument [57758,57780]
argument [57758,57780]
===
match
---
atom_expr [88111,88117]
atom_expr [88210,88216]
===
match
---
trailer [31128,31146]
trailer [31128,31146]
===
match
---
name: template_searchpath [15332,15351]
name: template_searchpath [15332,15351]
===
match
---
trailer [55412,55427]
trailer [55412,55427]
===
match
---
trailer [39906,39908]
trailer [39906,39908]
===
match
---
trailer [31577,31584]
trailer [31577,31584]
===
match
---
name: task [75331,75335]
name: task [75331,75335]
===
match
---
param [55942,55972]
param [55942,55972]
===
match
---
operator: , [10987,10988]
operator: , [10987,10988]
===
match
---
atom_expr [11164,11189]
atom_expr [11164,11189]
===
match
---
name: execution_date [4053,4067]
name: execution_date [4053,4067]
===
match
---
operator: , [86090,86091]
operator: , [86189,86190]
===
match
---
trailer [49818,49834]
trailer [49818,49834]
===
match
---
name: jinja_env_options [42928,42945]
name: jinja_env_options [42928,42945]
===
match
---
name: orm_dag [86670,86677]
name: orm_dag [86769,86776]
===
match
---
atom_expr [76561,76573]
atom_expr [76561,76573]
===
match
---
name: pendulum [22066,22074]
name: pendulum [22066,22074]
===
match
---
simple_stmt [35210,35279]
simple_stmt [35210,35279]
===
match
---
operator: } [10521,10522]
operator: } [10521,10522]
===
match
---
trailer [99838,99843]
trailer [99937,99942]
===
match
---
name: exclude_task_ids [54271,54287]
name: exclude_task_ids [54271,54287]
===
match
---
string: '_old_context_manager_dags' [92542,92569]
string: '_old_context_manager_dags' [92641,92668]
===
match
---
name: generate_run_id [82672,82687]
name: generate_run_id [82782,82797]
===
match
---
trailer [70697,70703]
trailer [70697,70703]
===
match
---
trailer [31518,31534]
trailer [31518,31534]
===
match
---
operator: = [26580,26581]
operator: = [26580,26581]
===
match
---
atom_expr [82909,82926]
atom_expr [83008,83025]
===
match
---
tfpdef [39057,39078]
tfpdef [39057,39078]
===
match
---
trailer [74297,74301]
trailer [74297,74301]
===
match
---
simple_stmt [84705,84712]
simple_stmt [84804,84811]
===
match
---
funcdef [66446,68237]
funcdef [66446,68237]
===
match
---
expr_stmt [42426,42640]
expr_stmt [42426,42640]
===
match
---
name: include_externally_triggered [29973,30001]
name: include_externally_triggered [29973,30001]
===
match
---
name: result [68661,68667]
name: result [68661,68667]
===
match
---
trailer [69233,69248]
trailer [69233,69248]
===
match
---
not_test [82510,82546]
not_test [82620,82656]
===
match
---
param [93870,93888]
param [93969,93987]
===
match
---
name: execution_date [55413,55427]
name: execution_date [55413,55427]
===
match
---
operator: , [21087,21088]
operator: , [21087,21088]
===
match
---
name: dry_run [68094,68101]
name: dry_run [68094,68101]
===
match
---
atom_expr [57025,57047]
atom_expr [57025,57047]
===
match
---
trailer [44875,44889]
trailer [44875,44889]
===
match
---
arglist [14743,14796]
arglist [14743,14796]
===
match
---
operator: , [16942,16943]
operator: , [16942,16943]
===
match
---
trailer [60529,60554]
trailer [60529,60554]
===
match
---
atom_expr [48651,48662]
atom_expr [48651,48662]
===
match
---
name: StrictUndefined [11265,11280]
name: StrictUndefined [11265,11280]
===
match
---
atom_expr [18663,18685]
atom_expr [18663,18685]
===
match
---
string: """         Looks for outdated dag level actions (can_dag_read and can_dag_edit) in DAG         access_controls (for example, {'role1': {'can_dag_read'}, 'role2': {'can_dag_read', 'can_dag_edit'}})         and replaces them with updated actions (can_read and can_edit).         """ [19108,19389]
string: """         Looks for outdated dag level actions (can_dag_read and can_dag_edit) in DAG         access_controls (for example, {'role1': {'can_dag_read'}, 'role2': {'can_dag_read', 'can_dag_edit'}})         and replaces them with updated actions (can_read and can_edit).         """ [19108,19389]
===
match
---
trailer [39701,39772]
trailer [39701,39772]
===
match
---
atom_expr [85138,85152]
atom_expr [85237,85251]
===
match
---
not_test [82273,82300]
not_test [82297,82324]
===
match
---
trailer [85854,85869]
trailer [85953,85968]
===
match
---
param [34824,34836]
param [34824,34836]
===
match
---
operator: @ [101923,101924]
operator: @ [102022,102023]
===
match
---
name: value [31103,31108]
name: value [31103,31108]
===
match
---
operator: = [31000,31001]
operator: = [31000,31001]
===
match
---
trailer [31663,31676]
trailer [31663,31676]
===
match
---
simple_stmt [74361,74402]
simple_stmt [74361,74402]
===
match
---
name: getboolean [77417,77427]
name: getboolean [77417,77427]
===
match
---
name: is_subdag [86863,86872]
name: is_subdag [86962,86971]
===
match
---
name: with_row_locks [3111,3125]
name: with_row_locks [3111,3125]
===
match
---
name: dag [74604,74607]
name: dag [74604,74607]
===
match
---
trailer [20319,20329]
trailer [20319,20329]
===
match
---
atom_expr [87456,87481]
atom_expr [87555,87580]
===
match
---
name: ignore_first_depends_on_past [79862,79890]
name: ignore_first_depends_on_past [79862,79890]
===
match
---
tfpdef [73614,73626]
tfpdef [73614,73626]
===
match
---
trailer [74572,74574]
trailer [74572,74574]
===
match
---
name: catchup [16456,16463]
name: catchup [16456,16463]
===
match
---
operator: , [30976,30977]
operator: , [30976,30977]
===
match
---
name: Optional [46357,46365]
name: Optional [46357,46365]
===
match
---
string: 'has_on_failure_callback' [93244,93269]
string: 'has_on_failure_callback' [93343,93368]
===
match
---
trailer [108882,108903]
trailer [108981,109002]
===
match
---
name: cls [104000,104003]
name: cls [104099,104102]
===
match
---
expr_stmt [49249,49294]
expr_stmt [49249,49294]
===
match
---
suite [99403,99475]
suite [99502,99574]
===
match
---
name: task [41643,41647]
name: task [41643,41647]
===
match
---
name: set_edge_info [93802,93815]
name: set_edge_info [93901,93914]
===
match
---
operator: = [109110,109111]
operator: = [109209,109210]
===
match
---
string: 'catchup_by_default' [11942,11962]
string: 'catchup_by_default' [11942,11962]
===
match
---
comp_op [30028,30034]
comp_op [30028,30034]
===
match
---
atom_expr [19717,19739]
atom_expr [19717,19739]
===
match
---
name: OrderedDict [949,960]
name: OrderedDict [949,960]
===
match
---
atom_expr [95569,95584]
atom_expr [95668,95683]
===
match
---
simple_stmt [57414,57429]
simple_stmt [57414,57429]
===
match
---
simple_stmt [59380,59454]
simple_stmt [59380,59454]
===
match
---
funcdef [77248,80169]
funcdef [77248,80169]
===
match
---
trailer [99131,99140]
trailer [99230,99239]
===
match
---
trailer [18513,18518]
trailer [18513,18518]
===
match
---
trailer [23496,23609]
trailer [23496,23609]
===
match
---
name: has_on_failure_callback [17203,17226]
name: has_on_failure_callback [17203,17226]
===
match
---
trailer [49361,49393]
trailer [49361,49393]
===
match
---
param [12151,12181]
param [12151,12181]
===
match
---
atom_expr [21484,21541]
atom_expr [21484,21541]
===
match
---
operator: == [97077,97079]
operator: == [97176,97178]
===
match
---
operator: , [29550,29551]
operator: , [29550,29551]
===
match
---
simple_stmt [26573,26615]
simple_stmt [26573,26615]
===
match
---
name: task [75134,75138]
name: task [75134,75138]
===
match
---
name: d [74152,74153]
name: d [74152,74153]
===
match
---
simple_stmt [14275,14330]
simple_stmt [14275,14330]
===
match
---
operator: , [39975,39976]
operator: , [39975,39976]
===
match
---
name: job [80159,80162]
name: job [80159,80162]
===
match
---
simple_stmt [14406,14440]
simple_stmt [14406,14440]
===
match
---
trailer [51721,51730]
trailer [51721,51730]
===
match
---
name: graph_sorted [59463,59475]
name: graph_sorted [59463,59475]
===
match
---
atom_expr [95293,95312]
atom_expr [95392,95411]
===
match
---
operator: = [15391,15392]
operator: = [15391,15392]
===
match
---
operator: , [75080,75081]
operator: , [75080,75081]
===
match
---
name: upstream_list [60589,60602]
name: upstream_list [60589,60602]
===
match
---
expr_stmt [28937,28973]
expr_stmt [28937,28973]
===
match
---
atom_expr [71306,71311]
atom_expr [71306,71311]
===
match
---
name: filter [85885,85891]
name: filter [85984,85990]
===
match
---
name: self [75455,75459]
name: self [75455,75459]
===
match
---
funcdef [44767,45597]
funcdef [44767,45597]
===
match
---
operator: , [44702,44703]
operator: , [44702,44703]
===
match
---
name: filter [86384,86390]
name: filter [86483,86489]
===
match
---
argument [79862,79919]
argument [79862,79919]
===
match
---
suite [90060,90852]
suite [90159,90951]
===
match
---
fstring_string: Invalid values of dag.orientation: only support  [16305,16353]
fstring_string: Invalid values of dag.orientation: only support  [16305,16353]
===
match
---
operator: = [37355,37356]
operator: = [37355,37356]
===
match
---
param [29808,29841]
param [29808,29841]
===
match
---
trailer [83824,83831]
trailer [83923,83930]
===
match
---
atom_expr [12841,12888]
atom_expr [12841,12888]
===
match
---
name: self [75336,75340]
name: self [75336,75340]
===
match
---
name: self [12563,12567]
name: self [12563,12567]
===
match
---
trailer [80166,80168]
trailer [80166,80168]
===
match
---
operator: , [99208,99209]
operator: , [99307,99308]
===
match
---
name: remove [88037,88043]
name: remove [88136,88142]
===
match
---
operator: , [93723,93724]
operator: , [93822,93823]
===
match
---
expr_stmt [20650,20802]
expr_stmt [20650,20802]
===
match
---
return_stmt [100764,100806]
return_stmt [100863,100905]
===
match
---
suite [18196,18687]
suite [18196,18687]
===
match
---
except_clause [37622,37638]
except_clause [37622,37638]
===
match
---
expr_stmt [16645,16691]
expr_stmt [16645,16691]
===
match
---
name: TIMEZONE [99132,99140]
name: TIMEZONE [99231,99239]
===
match
---
name: execution_date [40538,40552]
name: execution_date [40538,40552]
===
match
---
name: DeprecationWarning [21043,21061]
name: DeprecationWarning [21043,21061]
===
match
---
string: "Passing `max_recursion_depth` to dag.clear() is deprecated." [64686,64747]
string: "Passing `max_recursion_depth` to dag.clear() is deprecated." [64686,64747]
===
match
---
atom_expr [66071,66104]
atom_expr [66071,66104]
===
match
---
name: task [76769,76773]
name: task [76769,76773]
===
match
---
operator: == [49323,49325]
operator: == [49323,49325]
===
match
---
name: timezone [2691,2699]
name: timezone [2691,2699]
===
match
---
decorator [34375,34385]
decorator [34375,34385]
===
match
---
name: qry [92171,92174]
name: qry [92270,92273]
===
match
---
name: staticmethod [89360,89372]
name: staticmethod [89459,89471]
===
match
---
simple_stmt [44930,44986]
simple_stmt [44930,44986]
===
match
---
trailer [30722,30730]
trailer [30722,30730]
===
match
---
operator: = [55547,55548]
operator: = [55547,55548]
===
match
---
suite [28058,29070]
suite [28058,29070]
===
match
---
decorator [83745,83758]
decorator [83844,83857]
===
match
---
name: t [24170,24171]
name: t [24170,24171]
===
match
---
parameters [33392,33398]
parameters [33392,33398]
===
match
---
suite [27736,27811]
suite [27736,27811]
===
match
---
name: t [24459,24460]
name: t [24459,24460]
===
match
---
operator: = [20522,20523]
operator: = [20522,20523]
===
match
---
name: key [86698,86701]
name: key [86797,86800]
===
match
---
trailer [71914,71929]
trailer [71914,71929]
===
match
---
operator: , [55971,55972]
operator: , [55971,55972]
===
match
---
name: self [23465,23469]
name: self [23465,23469]
===
match
---
name: Optional [80919,80927]
name: Optional [80919,80927]
===
match
---
trailer [15331,15357]
trailer [15331,15357]
===
match
---
simple_stmt [75290,75308]
simple_stmt [75290,75308]
===
match
---
name: false [4014,4019]
name: false [4014,4019]
===
match
---
name: cached_property [24765,24780]
name: cached_property [24765,24780]
===
match
---
name: dag [90710,90713]
name: dag [90809,90812]
===
match
---
simple_stmt [109179,109211]
simple_stmt [109278,109310]
===
match
---
arglist [30861,31003]
arglist [30861,31003]
===
match
---
operator: += [20562,20564]
operator: += [20562,20564]
===
match
---
operator: { [94097,94098]
operator: { [94196,94197]
===
match
---
simple_stmt [21280,21424]
simple_stmt [21280,21424]
===
match
---
arglist [97019,97114]
arglist [97118,97213]
===
match
---
atom_expr [43151,43175]
atom_expr [43151,43175]
===
match
---
name: as_pk_tuple [54654,54665]
name: as_pk_tuple [54654,54665]
===
match
---
name: pathlib [101049,101056]
name: pathlib [101148,101155]
===
match
---
string: 'BT' [3517,3521]
string: 'BT' [3517,3521]
===
match
---
name: deactivate_unknown_dags [89402,89425]
name: deactivate_unknown_dags [89501,89524]
===
match
---
if_stmt [70810,70902]
if_stmt [70810,70902]
===
match
---
operator: , [85584,85585]
operator: , [85683,85684]
===
match
---
simple_stmt [35287,35324]
simple_stmt [35287,35324]
===
match
---
sync_comp_for [49543,49557]
sync_comp_for [49543,49557]
===
match
---
name: t [75180,75181]
name: t [75180,75181]
===
match
---
atom_expr [92229,92241]
atom_expr [92328,92340]
===
match
---
atom_expr [87324,87341]
atom_expr [87423,87440]
===
match
---
simple_stmt [42695,42751]
simple_stmt [42695,42751]
===
match
---
operator: * [101786,101787]
operator: * [101885,101886]
===
match
---
name: Optional [100856,100864]
name: Optional [100955,100963]
===
match
---
name: tis [48833,48836]
name: tis [48833,48836]
===
match
---
atom_expr [31629,31642]
atom_expr [31629,31642]
===
match
---
suite [89754,89774]
suite [89853,89873]
===
match
---
if_stmt [51471,51561]
if_stmt [51471,51561]
===
match
---
if_stmt [98118,98621]
if_stmt [98217,98720]
===
match
---
trailer [41887,41900]
trailer [41887,41900]
===
match
---
atom_expr [73339,73395]
atom_expr [73339,73395]
===
match
---
string: 'max_active_tasks_per_dag' [97743,97769]
string: 'max_active_tasks_per_dag' [97842,97868]
===
match
---
param [46083,46115]
param [46083,46115]
===
match
---
name: child [71915,71920]
name: child [71915,71920]
===
match
---
trailer [11231,11255]
trailer [11231,11255]
===
match
---
name: tags [87904,87908]
name: tags [88003,88007]
===
match
---
atom_expr [64655,64828]
atom_expr [64655,64828]
===
match
---
name: graph_sorted [60996,61008]
name: graph_sorted [60996,61008]
===
match
---
arglist [17978,17992]
arglist [17978,17992]
===
match
---
expr_stmt [16590,16636]
expr_stmt [16590,16636]
===
match
---
name: tis [37357,37360]
name: tis [37357,37360]
===
match
---
operator: , [61642,61643]
operator: , [61642,61643]
===
match
---
atom_expr [11409,11423]
atom_expr [11409,11423]
===
match
---
name: dagruns [40625,40632]
name: dagruns [40625,40632]
===
match
---
name: self [74832,74836]
name: self [74832,74836]
===
match
---
name: RePatternType [2651,2664]
name: RePatternType [2651,2664]
===
match
---
funcdef [24785,25339]
funcdef [24785,25339]
===
match
---
funcdef [30511,30739]
funcdef [30511,30739]
===
match
---
simple_stmt [13649,13681]
simple_stmt [13649,13681]
===
match
---
atom_expr [11913,11963]
atom_expr [11913,11963]
===
match
---
string: """Returns the latest date for which at least one dag run exists""" [40718,40785]
string: """Returns the latest date for which at least one dag run exists""" [40718,40785]
===
match
---
name: visited_external_tis [54541,54561]
name: visited_external_tis [54541,54561]
===
match
---
trailer [43155,43175]
trailer [43155,43175]
===
match
---
operator: , [62226,62227]
operator: , [62226,62227]
===
match
---
trailer [18394,18404]
trailer [18394,18404]
===
match
---
name: DagRun [61943,61949]
name: DagRun [61943,61949]
===
match
---
atom_expr [105322,105341]
atom_expr [105421,105440]
===
match
---
name: TaskInstance [92038,92050]
name: TaskInstance [92137,92149]
===
match
---
suite [18265,18643]
suite [18265,18643]
===
match
---
trailer [40808,40814]
trailer [40808,40814]
===
match
---
expr_stmt [74498,74574]
expr_stmt [74498,74574]
===
match
---
operator: , [29102,29103]
operator: , [29102,29103]
===
match
---
argument [67950,67970]
argument [67950,67970]
===
match
---
name: self [76797,76801]
name: self [76797,76801]
===
match
---
argument [94941,94970]
argument [95040,95069]
===
match
---
name: Iterable [46848,46856]
name: Iterable [46848,46856]
===
match
---
arglist [39702,39771]
arglist [39702,39771]
===
match
---
suite [61818,61889]
suite [61818,61889]
===
match
---
decorated [66429,68237]
decorated [66429,68237]
===
match
---
argument [50897,50912]
argument [50897,50912]
===
match
---
name: end_date [53921,53929]
name: end_date [53921,53929]
===
match
---
name: Path [33179,33183]
name: Path [33179,33183]
===
match
---
trailer [72943,72956]
trailer [72943,72956]
===
match
---
name: dag_id [48656,48662]
name: dag_id [48656,48662]
===
match
---
name: upstream_task_id [93822,93838]
name: upstream_task_id [93921,93937]
===
match
---
atom_expr [70627,70636]
atom_expr [70627,70636]
===
match
---
trailer [71757,71764]
trailer [71757,71764]
===
match
---
string: 'core' [77428,77434]
string: 'core' [77428,77434]
===
match
---
atom_expr [92386,92409]
atom_expr [92485,92508]
===
match
---
name: self [77223,77227]
name: self [77223,77227]
===
match
---
trailer [86545,86551]
trailer [86644,86650]
===
match
---
except_clause [101155,101172]
except_clause [101254,101271]
===
match
---
atom_expr [37231,37293]
atom_expr [37231,37293]
===
match
---
name: int [43777,43780]
name: int [43777,43780]
===
match
---
operator: @ [66429,66430]
operator: @ [66429,66430]
===
match
---
simple_stmt [79460,79521]
simple_stmt [79460,79521]
===
match
---
name: subdags [41943,41950]
name: subdags [41943,41950]
===
match
---
operator: * [75115,75116]
operator: * [75115,75116]
===
match
---
atom_expr [11227,11255]
atom_expr [11227,11255]
===
match
---
atom_expr [15629,15646]
atom_expr [15629,15646]
===
match
---
simple_stmt [49681,49722]
simple_stmt [49681,49722]
===
match
---
name: _context_managed_dag [108883,108903]
name: _context_managed_dag [108982,109002]
===
match
---
import_name [788,799]
import_name [788,799]
===
match
---
operator: , [104115,104116]
operator: , [104214,104215]
===
match
---
name: f [106973,106974]
name: f [107072,107073]
===
match
---
operator: , [51026,51027]
operator: , [51026,51027]
===
match
---
trailer [73433,73439]
trailer [73433,73439]
===
match
---
name: donot_pickle [79789,79801]
name: donot_pickle [79789,79801]
===
match
---
atom_expr [13998,14015]
atom_expr [13998,14015]
===
match
---
operator: , [79692,79693]
operator: , [79692,79693]
===
match
---
string: 'user_defined_filters' [92649,92671]
string: 'user_defined_filters' [92748,92770]
===
match
---
name: cls [88714,88717]
name: cls [88813,88816]
===
match
---
name: session [83536,83543]
name: session [83635,83642]
===
match
---
operator: = [97651,97652]
operator: = [97750,97751]
===
match
---
suite [73713,73757]
suite [73713,73757]
===
match
---
name: query [40381,40386]
name: query [40381,40386]
===
match
---
operator: = [68058,68059]
operator: = [68058,68059]
===
match
---
operator: -> [108965,108967]
operator: -> [109064,109066]
===
match
---
operator: , [34658,34659]
operator: , [34658,34659]
===
match
---
trailer [75270,75276]
trailer [75270,75276]
===
match
---
expr_stmt [24606,24655]
expr_stmt [24606,24655]
===
match
---
name: jinja2 [11232,11238]
name: jinja2 [11232,11238]
===
match
---
name: copy [71555,71559]
name: copy [71555,71559]
===
match
---
trailer [98087,98107]
trailer [98186,98206]
===
match
---
operator: = [79937,79938]
operator: = [79937,79938]
===
match
---
operator: = [11191,11192]
operator: = [11191,11192]
===
match
---
atom_expr [25072,25108]
atom_expr [25072,25108]
===
match
---
arglist [105160,105342]
arglist [105259,105441]
===
match
---
name: max [40820,40823]
name: max [40820,40823]
===
match
---
operator: { [74013,74014]
operator: { [74013,74014]
===
match
---
name: dttm [29495,29499]
name: dttm [29495,29499]
===
match
---
name: DagStateChangeCallback [12003,12025]
name: DagStateChangeCallback [12003,12025]
===
match
---
simple_stmt [1657,1710]
simple_stmt [1657,1710]
===
match
---
atom [28989,29069]
atom [28989,29069]
===
match
---
atom_expr [84939,84952]
atom_expr [85038,85051]
===
match
---
name: set [51646,51649]
name: set [51646,51649]
===
match
---
operator: } [82383,82384]
operator: } [82407,82408]
===
match
---
name: task [76522,76526]
name: task [76522,76526]
===
match
---
name: self [30192,30196]
name: self [30192,30196]
===
match
---
name: dag_id [85830,85836]
name: dag_id [85929,85935]
===
match
---
name: TaskInstance [49266,49278]
name: TaskInstance [49266,49278]
===
match
---
name: f_kwargs [107350,107358]
name: f_kwargs [107449,107457]
===
match
---
name: str [45793,45796]
name: str [45793,45796]
===
match
---
name: session [89793,89800]
name: session [89892,89899]
===
match
---
suite [76020,76089]
suite [76020,76089]
===
match
---
name: DagRun [86408,86414]
name: DagRun [86507,86513]
===
match
---
operator: = [89449,89450]
operator: = [89548,89549]
===
match
---
atom_expr [41870,41900]
atom_expr [41870,41900]
===
match
---
simple_stmt [33852,33927]
simple_stmt [33852,33927]
===
match
---
trailer [40823,40846]
trailer [40823,40846]
===
match
---
name: cls [92423,92426]
name: cls [92522,92525]
===
match
---
suite [25540,28002]
suite [25540,28002]
===
match
---
tfpdef [46124,46176]
tfpdef [46124,46176]
===
match
---
name: donot_pickle [77399,77411]
name: donot_pickle [77399,77411]
===
match
---
trailer [24989,24991]
trailer [24989,24991]
===
match
---
trailer [12985,13148]
trailer [12985,13148]
===
match
---
operator: = [69470,69471]
operator: = [69470,69471]
===
match
---
name: append [18625,18631]
name: append [18625,18631]
===
match
---
name: settings [14422,14430]
name: settings [14422,14430]
===
match
---
fstring_string:  not found [73960,73970]
fstring_string:  not found [73960,73970]
===
match
---
name: session [99210,99217]
name: session [99309,99316]
===
match
---
name: __name__ [3330,3338]
name: __name__ [3330,3338]
===
match
---
atom [59478,59480]
atom [59478,59480]
===
match
---
name: is_paused [35313,35322]
name: is_paused [35313,35322]
===
match
---
simple_stmt [15531,15602]
simple_stmt [15531,15602]
===
match
---
name: result [68401,68407]
name: result [68401,68407]
===
match
---
name: in_ [100206,100209]
name: in_ [100305,100308]
===
match
---
decorator [38952,38969]
decorator [38952,38969]
===
match
---
name: user_defined_macros [43213,43232]
name: user_defined_macros [43213,43232]
===
match
---
name: self [41337,41341]
name: self [41337,41341]
===
match
---
operator: , [20226,20227]
operator: , [20226,20227]
===
match
---
name: end_date [14926,14934]
name: end_date [14926,14934]
===
match
---
trailer [55918,55924]
trailer [55918,55924]
===
match
---
suite [69484,73493]
suite [69484,73493]
===
match
---
atom_expr [100865,100877]
atom_expr [100964,100976]
===
match
---
name: dag_run_state [62328,62341]
name: dag_run_state [62328,62341]
===
match
---
trailer [91487,91493]
trailer [91586,91592]
===
match
---
string: 'webserver' [100673,100684]
string: 'webserver' [100772,100783]
===
match
---
name: dag [87062,87065]
name: dag [87161,87164]
===
match
---
name: filter [3882,3888]
name: filter [3882,3888]
===
match
---
name: t [24444,24445]
name: t [24444,24445]
===
match
---
atom_expr [18159,18171]
atom_expr [18159,18171]
===
match
---
atom_expr [14565,14594]
atom_expr [14565,14594]
===
match
---
argument [59409,59452]
argument [59409,59452]
===
match
---
atom [44240,44570]
atom [44240,44570]
===
match
---
expr_stmt [30718,30738]
expr_stmt [30718,30738]
===
match
---
operator: = [58212,58213]
operator: = [58212,58213]
===
match
---
atom_expr [18535,18562]
atom_expr [18535,18562]
===
match
---
trailer [32638,32648]
trailer [32638,32648]
===
match
---
atom [57698,57707]
atom [57698,57707]
===
match
---
simple_stmt [17597,17614]
simple_stmt [17597,17614]
===
match
---
simple_stmt [86780,86809]
simple_stmt [86879,86908]
===
match
---
operator: = [66556,66557]
operator: = [66556,66557]
===
match
---
atom_expr [76351,76364]
atom_expr [76351,76364]
===
match
---
name: all [40593,40596]
name: all [40593,40596]
===
match
---
operator: , [80738,80739]
operator: , [80738,80739]
===
match
---
atom_expr [86780,86808]
atom_expr [86879,86907]
===
match
---
operator: , [83806,83807]
operator: , [83905,83906]
===
match
---
name: filter [52899,52905]
name: filter [52899,52905]
===
match
---
param [32459,32464]
param [32459,32464]
===
match
---
return_stmt [30102,30121]
return_stmt [30102,30121]
===
match
---
trailer [95459,95472]
trailer [95558,95571]
===
match
---
if_stmt [49488,49982]
if_stmt [49488,49982]
===
match
---
funcdef [99088,99141]
funcdef [99187,99240]
===
match
---
operator: = [38228,38229]
operator: = [38228,38229]
===
match
---
operator: -> [74978,74980]
operator: -> [74978,74980]
===
match
---
test [38839,38900]
test [38839,38900]
===
match
---
argument [65530,65545]
argument [65530,65545]
===
match
---
operator: = [65566,65567]
operator: = [65566,65567]
===
match
---
param [35099,35111]
param [35099,35111]
===
match
---
not_test [14375,14392]
not_test [14375,14392]
===
match
---
operator: , [69341,69342]
operator: , [69341,69342]
===
match
---
name: default_view [89341,89353]
name: default_view [89440,89452]
===
match
---
name: utils [1651,1656]
name: utils [1651,1656]
===
match
---
expr_stmt [12508,12554]
expr_stmt [12508,12554]
===
match
---
atom_expr [4035,4075]
atom_expr [4035,4075]
===
match
---
suite [41598,41951]
suite [41598,41951]
===
match
---
param [55700,55713]
param [55700,55713]
===
match
---
if_stmt [13218,13544]
if_stmt [13218,13544]
===
match
---
name: self [14181,14185]
name: self [14181,14185]
===
match
---
trailer [102479,102483]
trailer [102578,102582]
===
match
---
return_stmt [30460,30479]
return_stmt [30460,30479]
===
match
---
name: self [48651,48655]
name: self [48651,48655]
===
match
---
string: 'graph' [3429,3436]
string: 'graph' [3429,3436]
===
match
---
name: difference [85212,85222]
name: difference [85311,85321]
===
match
---
atom [41564,41566]
atom [41564,41566]
===
match
---
suite [4153,94128]
suite [4153,94227]
===
match
---
param [93816,93821]
param [93915,93920]
===
match
---
trailer [35757,35775]
trailer [35757,35775]
===
match
---
name: end_date [79684,79692]
name: end_date [79684,79692]
===
match
---
atom_expr [17718,17729]
atom_expr [17718,17729]
===
match
---
name: DeprecationWarning [64309,64327]
name: DeprecationWarning [64309,64327]
===
match
---
param [36383,36388]
param [36383,36388]
===
match
---
string: 'webserver' [11856,11867]
string: 'webserver' [11856,11867]
===
match
---
operator: = [46831,46832]
operator: = [46831,46832]
===
match
---
string: "Passing `get_tis` to dag.clear() is deprecated. Use `dry_run` parameter instead." [64209,64291]
string: "Passing `get_tis` to dag.clear() is deprecated. Use `dry_run` parameter instead." [64209,64291]
===
match
---
comp_op [102556,102562]
comp_op [102655,102661]
===
match
---
suite [108074,109339]
suite [108173,109438]
===
match
---
name: start_date [53862,53872]
name: start_date [53862,53872]
===
match
---
name: self [25202,25206]
name: self [25202,25206]
===
match
---
operator: , [79942,79943]
operator: , [79942,79943]
===
match
---
name: DagRunType [82909,82919]
name: DagRunType [83008,83018]
===
match
---
trailer [82444,82452]
trailer [82489,82497]
===
match
---
trailer [76742,76752]
trailer [76742,76752]
===
match
---
trailer [80927,80954]
trailer [80927,80954]
===
match
---
atom_expr [67316,67328]
atom_expr [67316,67328]
===
match
---
name: fileloc [10586,10593]
name: fileloc [10586,10593]
===
match
---
string: """File location of the importable dag 'file' relative to the configured DAGs folder.""" [100888,100976]
string: """File location of the importable dag 'file' relative to the configured DAGs folder.""" [100987,101075]
===
match
---
atom_expr [48506,48518]
atom_expr [48506,48518]
===
match
---
name: run_id [39872,39878]
name: run_id [39872,39878]
===
match
---
name: ID_LEN [94329,94335]
name: ID_LEN [94428,94434]
===
match
---
atom_expr [76661,76673]
atom_expr [76661,76673]
===
match
---
name: get_task [57030,57038]
name: get_task [57030,57038]
===
match
---
operator: = [18451,18452]
operator: = [18451,18452]
===
match
---
name: dag [105322,105325]
name: dag [105421,105424]
===
match
---
atom_expr [43189,43233]
atom_expr [43189,43233]
===
match
---
name: end_date [67819,67827]
name: end_date [67819,67827]
===
match
---
atom_expr [42470,42505]
atom_expr [42470,42505]
===
match
---
atom_expr [103975,104053]
atom_expr [104074,104152]
===
match
---
name: session [36424,36431]
name: session [36424,36431]
===
match
---
suite [30550,30739]
suite [30550,30739]
===
match
---
trailer [87463,87481]
trailer [87562,87580]
===
match
---
operator: , [99539,99540]
operator: , [99638,99639]
===
match
---
trailer [84136,84153]
trailer [84235,84252]
===
match
---
name: self [17952,17956]
name: self [17952,17956]
===
match
---
trailer [46365,46375]
trailer [46365,46375]
===
match
---
name: Optional [20271,20279]
name: Optional [20271,20279]
===
match
---
name: dag_tag_orm [88363,88374]
name: dag_tag_orm [88462,88473]
===
match
---
string: "Maximum recursion depth {} reached for {} {}. " [52494,52542]
string: "Maximum recursion depth {} reached for {} {}. " [52494,52542]
===
match
---
name: t [73224,73225]
name: t [73224,73225]
===
match
---
operator: == [38691,38693]
operator: == [38691,38693]
===
match
---
name: stacklevel [64583,64593]
name: stacklevel [64583,64593]
===
match
---
atom_expr [68628,68650]
atom_expr [68628,68650]
===
match
---
operator: , [79801,79802]
operator: , [79801,79802]
===
match
---
name: self [24175,24179]
name: self [24175,24179]
===
match
---
name: update [12853,12859]
name: update [12853,12859]
===
match
---
operator: = [71668,71669]
operator: = [71668,71669]
===
match
---
atom_expr [85480,85507]
atom_expr [85579,85606]
===
match
---
string: "DagBag" [46024,46032]
string: "DagBag" [46024,46032]
===
match
---
name: DagModel [84897,84905]
name: DagModel [84996,85004]
===
match
---
name: dag_id [44335,44341]
name: dag_id [44335,44341]
===
match
---
arglist [55387,55427]
arglist [55387,55427]
===
match
---
operator: = [58793,58794]
operator: = [58793,58794]
===
match
---
arglist [44683,44739]
arglist [44683,44739]
===
match
---
name: coerce_datetime [83057,83072]
name: coerce_datetime [83156,83171]
===
match
---
name: dag [73852,73855]
name: dag [73852,73855]
===
match
---
comp_if [24475,24488]
comp_if [24475,24488]
===
match
---
name: _comps [10322,10328]
name: _comps [10322,10328]
===
match
---
operator: == [101727,101729]
operator: == [101826,101828]
===
match
---
trailer [106974,106982]
trailer [107073,107081]
===
match
---
name: state [53978,53983]
name: state [53978,53983]
===
match
---
name: self [21738,21742]
name: self [21738,21742]
===
match
---
string: 'max_dagruns_to_create_per_loop' [97179,97211]
string: 'max_dagruns_to_create_per_loop' [97278,97310]
===
match
---
atom_expr [14379,14392]
atom_expr [14379,14392]
===
match
---
name: self [44659,44663]
name: self [44659,44663]
===
match
---
trailer [55389,55396]
trailer [55389,55396]
===
match
---
atom_expr [42262,42273]
atom_expr [42262,42273]
===
match
---
import_from [2060,2106]
import_from [2060,2106]
===
match
---
trailer [86137,86146]
trailer [86236,86245]
===
match
---
trailer [94270,94301]
trailer [94369,94400]
===
match
---
name: primary_key [94364,94375]
name: primary_key [94463,94474]
===
match
---
trailer [64186,64191]
trailer [64186,64191]
===
match
---
expr_stmt [34178,34316]
expr_stmt [34178,34316]
===
match
---
name: airflow [12457,12464]
name: airflow [12457,12464]
===
match
---
name: existing_dag_ids [86426,86442]
name: existing_dag_ids [86525,86541]
===
match
---
name: updated_access_control [19867,19889]
name: updated_access_control [19867,19889]
===
match
---
name: tasks [73434,73439]
name: tasks [73434,73439]
===
match
---
suite [60603,60689]
suite [60603,60689]
===
match
---
expr_stmt [95113,95155]
expr_stmt [95212,95254]
===
match
---
trailer [37538,37558]
trailer [37538,37558]
===
match
---
atom_expr [33171,33197]
atom_expr [33171,33197]
===
match
---
name: verify_integrity [83686,83702]
name: verify_integrity [83785,83801]
===
match
---
if_stmt [61897,61978]
if_stmt [61897,61978]
===
match
---
atom [84869,85031]
atom [84968,85130]
===
match
---
trailer [50109,50120]
trailer [50109,50120]
===
match
---
trailer [68492,68498]
trailer [68492,68498]
===
match
---
name: true [100162,100166]
name: true [100261,100265]
===
match
---
trailer [4067,4072]
trailer [4067,4072]
===
match
---
param [62236,62257]
param [62236,62257]
===
match
---
name: Optional [11659,11667]
name: Optional [11659,11667]
===
match
---
name: count [67573,67578]
name: count [67573,67578]
===
match
---
string: "filepath is deprecated, use relative_fileloc instead" [32855,32909]
string: "filepath is deprecated, use relative_fileloc instead" [32855,32909]
===
match
---
import_as_names [3075,3125]
import_as_names [3075,3125]
===
match
---
name: visited_external_tis [51048,51068]
name: visited_external_tis [51048,51068]
===
match
---
suite [32613,32657]
suite [32613,32657]
===
match
---
trailer [95131,95155]
trailer [95230,95254]
===
match
---
funcdef [75057,75248]
funcdef [75057,75248]
===
match
---
atom_expr [46441,46450]
atom_expr [46441,46450]
===
match
---
expr_stmt [68401,68426]
expr_stmt [68401,68426]
===
match
---
name: __hash__ [18181,18189]
name: __hash__ [18181,18189]
===
match
---
tfpdef [10879,10905]
tfpdef [10879,10905]
===
match
---
operator: } [85176,85177]
operator: } [85275,85276]
===
match
---
name: external_trigger [38731,38747]
name: external_trigger [38731,38747]
===
match
---
operator: , [12435,12436]
operator: , [12435,12436]
===
match
---
operator: , [55396,55397]
operator: , [55396,55397]
===
match
---
sync_comp_for [17994,18014]
sync_comp_for [17994,18014]
===
match
---
simple_stmt [17622,17669]
simple_stmt [17622,17669]
===
match
---
name: self [31124,31128]
name: self [31124,31128]
===
match
---
operator: , [46693,46694]
operator: , [46693,46694]
===
match
---
operator: , [90692,90693]
operator: , [90791,90792]
===
match
---
atom_expr [88172,88186]
atom_expr [88271,88285]
===
match
---
name: DeprecationWarning [64765,64783]
name: DeprecationWarning [64765,64783]
===
match
---
trailer [72854,72881]
trailer [72854,72881]
===
match
---
atom_expr [92182,92212]
atom_expr [92281,92311]
===
match
---
testlist_star_expr [98988,99060]
testlist_star_expr [99087,99159]
===
match
---
name: __repr__ [17678,17686]
name: __repr__ [17678,17686]
===
match
---
name: other [17978,17983]
name: other [17978,17983]
===
match
---
trailer [17792,17799]
trailer [17792,17799]
===
match
---
operator: = [72113,72114]
operator: = [72113,72114]
===
match
---
trailer [38677,38708]
trailer [38677,38708]
===
match
---
name: DagRun [44359,44365]
name: DagRun [44359,44365]
===
match
---
except_clause [18575,18591]
except_clause [18575,18591]
===
match
---
operator: , [90944,90945]
operator: , [91043,91044]
===
match
---
operator: @ [32750,32751]
operator: @ [32750,32751]
===
match
---
operator: = [21850,21851]
operator: = [21850,21851]
===
match
---
atom_expr [15980,16146]
atom_expr [15980,16146]
===
match
---
operator: = [67786,67787]
operator: = [67786,67787]
===
match
---
argument [30686,30698]
argument [30686,30698]
===
match
---
atom_expr [101049,101075]
atom_expr [101148,101174]
===
match
---
operator: } [93726,93727]
operator: } [93825,93826]
===
match
---
name: warn [23723,23727]
name: warn [23723,23727]
===
match
---
simple_stmt [94415,94432]
simple_stmt [94514,94531]
===
match
---
string: 'dag_orientation' [11869,11886]
string: 'dag_orientation' [11869,11886]
===
match
---
name: existing_dag_ids [85927,85943]
name: existing_dag_ids [86026,86042]
===
match
---
string: "Passing full_filepath to DAG() is deprecated and has no effect" [13003,13067]
string: "Passing full_filepath to DAG() is deprecated and has no effect" [13003,13067]
===
match
---
operator: = [46033,46034]
operator: = [46033,46034]
===
match
---
name: session [80795,80802]
name: session [80795,80802]
===
match
---
operator: == [103698,103700]
operator: == [103797,103799]
===
match
---
name: state [64885,64890]
name: state [64885,64890]
===
match
---
suite [41343,41977]
suite [41343,41977]
===
match
---
trailer [74867,74869]
trailer [74867,74869]
===
match
---
operator: -> [29843,29845]
operator: -> [29843,29845]
===
match
---
operator: { [37539,37540]
operator: { [37539,37540]
===
match
---
simple_stmt [41352,41418]
simple_stmt [41352,41418]
===
match
---
for_stmt [75257,75308]
for_stmt [75257,75308]
===
match
---
argument [57351,57366]
argument [57351,57366]
===
match
---
atom_expr [72957,72977]
atom_expr [72957,72977]
===
match
---
operator: } [19652,19653]
operator: } [19652,19653]
===
match
---
name: Callable [1076,1084]
name: Callable [1076,1084]
===
match
---
operator: , [30640,30641]
operator: , [30640,30641]
===
match
---
param [45732,45761]
param [45732,45761]
===
match
---
simple_stmt [18075,18100]
simple_stmt [18075,18100]
===
match
---
trailer [50169,50184]
trailer [50169,50184]
===
match
---
param [31398,31402]
param [31398,31402]
===
match
---
trailer [46628,46633]
trailer [46628,46633]
===
match
---
name: dag_id [13203,13209]
name: dag_id [13203,13209]
===
match
---
name: session [99527,99534]
name: session [99626,99633]
===
match
---
tfpdef [47333,47353]
tfpdef [47333,47353]
===
match
---
name: tags [17602,17606]
name: tags [17602,17606]
===
match
---
trailer [70370,70386]
trailer [70370,70386]
===
match
---
name: execution_date [39739,39753]
name: execution_date [39739,39753]
===
match
---
name: self [76488,76492]
name: self [76488,76492]
===
match
---
simple_stmt [28580,28778]
simple_stmt [28580,28778]
===
match
---
string: "The 'concurrency' parameter is deprecated. Please use 'max_active_tasks'." [13344,13419]
string: "The 'concurrency' parameter is deprecated. Please use 'max_active_tasks'." [13344,13419]
===
match
---
atom_expr [46800,46830]
atom_expr [46800,46830]
===
match
---
atom_expr [85550,85597]
atom_expr [85649,85696]
===
match
---
atom_expr [73280,73300]
atom_expr [73280,73300]
===
match
---
atom_expr [56004,56022]
atom_expr [56004,56022]
===
match
---
simple_stmt [39145,39473]
simple_stmt [39145,39473]
===
match
---
trailer [86514,86531]
trailer [86613,86630]
===
match
---
trailer [57621,57627]
trailer [57621,57627]
===
match
---
name: dag_id [3597,3603]
name: dag_id [3597,3603]
===
match
---
name: self [100384,100388]
name: self [100483,100487]
===
match
---
name: __deepcopy__ [68246,68258]
name: __deepcopy__ [68246,68258]
===
match
---
trailer [11855,11887]
trailer [11855,11887]
===
match
---
name: self [15423,15427]
name: self [15423,15427]
===
match
---
name: DagRun [86591,86597]
name: DagRun [86690,86696]
===
match
---
argument [54208,54224]
argument [54208,54224]
===
match
---
name: edge [60576,60580]
name: edge [60576,60580]
===
match
---
trailer [107310,107320]
trailer [107409,107419]
===
match
---
name: in_ [48502,48505]
name: in_ [48502,48505]
===
match
---
operator: , [43817,43818]
operator: , [43817,43818]
===
match
---
trailer [66394,66400]
trailer [66394,66400]
===
match
---
atom_expr [25519,25539]
atom_expr [25519,25539]
===
match
---
decorator [31854,31872]
decorator [31854,31872]
===
match
---
name: pendulum [104147,104155]
name: pendulum [104246,104254]
===
match
---
operator: = [46070,46071]
operator: = [46070,46071]
===
match
---
name: self [12860,12864]
name: self [12860,12864]
===
match
---
trailer [47989,47991]
trailer [47989,47991]
===
match
---
operator: , [45760,45761]
operator: , [45760,45761]
===
match
---
operator: , [66273,66274]
operator: , [66273,66274]
===
match
---
name: v [68474,68475]
name: v [68474,68475]
===
match
---
name: matched_tasks [70555,70568]
name: matched_tasks [70555,70568]
===
match
---
trailer [66094,66104]
trailer [66094,66104]
===
match
---
decorated [38952,39909]
decorated [38952,39909]
===
match
---
trailer [109115,109146]
trailer [109214,109245]
===
match
---
name: conf [11847,11851]
name: conf [11847,11851]
===
match
---
fstring_end: " [98315,98316]
fstring_end: " [98414,98415]
===
match
---
name: ti_list [65832,65839]
name: ti_list [65832,65839]
===
match
---
name: self [18053,18057]
name: self [18053,18057]
===
match
---
name: fileloc [100993,101000]
name: fileloc [101092,101099]
===
match
---
if_stmt [27146,27191]
if_stmt [27146,27191]
===
match
---
operator: = [62392,62393]
operator: = [62392,62393]
===
match
---
atom_expr [94686,94708]
atom_expr [94785,94807]
===
match
---
trailer [91867,91873]
trailer [91966,91972]
===
match
---
name: missing_dag_id [85254,85268]
name: missing_dag_id [85353,85367]
===
match
---
name: push_context_managed_dag [18802,18826]
name: push_context_managed_dag [18802,18826]
===
match
---
simple_stmt [94053,94128]
simple_stmt [94152,94227]
===
match
---
if_stmt [41611,41951]
if_stmt [41611,41951]
===
match
---
tfpdef [73517,73529]
tfpdef [73517,73529]
===
match
---
if_stmt [100985,101034]
if_stmt [101084,101133]
===
match
---
string: """         Simple utility method to set dependency between two tasks that         already have been added to the DAG using add_task()         """ [43427,43573]
string: """         Simple utility method to set dependency between two tasks that         already have been added to the DAG using add_task()         """ [43427,43573]
===
match
---
tfpdef [31308,31318]
tfpdef [31308,31318]
===
match
---
operator: , [89440,89441]
operator: , [89539,89540]
===
match
---
operator: , [22130,22131]
operator: , [22130,22131]
===
match
---
name: get_dagmodel [99189,99201]
name: get_dagmodel [99288,99300]
===
match
---
name: access_control [19405,19419]
name: access_control [19405,19419]
===
match
---
name: local [79303,79308]
name: local [79303,79308]
===
match
---
name: overload [1220,1228]
name: overload [1220,1228]
===
match
---
trailer [33246,33268]
trailer [33246,33268]
===
match
---
name: airflow [3182,3189]
name: airflow [3182,3189]
===
match
---
name: include_subdags [54019,54034]
name: include_subdags [54019,54034]
===
match
---
name: dag_bag [54317,54324]
name: dag_bag [54317,54324]
===
match
---
testlist_comp [98637,98709]
testlist_comp [98736,98808]
===
match
---
operator: == [65766,65768]
operator: == [65766,65768]
===
match
---
trailer [38786,38793]
trailer [38786,38793]
===
match
---
simple_stmt [74995,75048]
simple_stmt [74995,75048]
===
match
---
trailer [34197,34221]
trailer [34197,34221]
===
match
---
if_stmt [104595,104947]
if_stmt [104694,105046]
===
match
---
operator: = [52879,52880]
operator: = [52879,52880]
===
match
---
atom [71714,71716]
atom [71714,71716]
===
match
---
atom_expr [97325,97346]
atom_expr [97424,97445]
===
match
---
if_stmt [19398,19445]
if_stmt [19398,19445]
===
match
---
funcdef [18177,18687]
funcdef [18177,18687]
===
match
---
trailer [17951,17966]
trailer [17951,17966]
===
match
---
operator: = [50219,50220]
operator: = [50219,50220]
===
match
---
suite [108753,108910]
suite [108852,109009]
===
match
---
operator: = [66530,66531]
operator: = [66530,66531]
===
match
---
param [32352,32356]
param [32352,32356]
===
match
---
name: str [80593,80596]
name: str [80593,80596]
===
match
---
if_stmt [24933,24992]
if_stmt [24933,24992]
===
match
---
trailer [14247,14261]
trailer [14247,14261]
===
match
---
atom_expr [96337,96368]
atom_expr [96436,96467]
===
match
---
atom_expr [72041,72054]
atom_expr [72041,72054]
===
match
---
name: param [31958,31963]
name: param [31958,31963]
===
match
---
suite [90973,92242]
suite [91072,92341]
===
match
---
simple_stmt [2322,2397]
simple_stmt [2322,2397]
===
match
---
name: self [35266,35270]
name: self [35266,35270]
===
match
---
decorator [84174,84187]
decorator [84273,84286]
===
match
---
name: update [37532,37538]
name: update [37532,37538]
===
match
---
name: bool [25497,25501]
name: bool [25497,25501]
===
match
---
atom_expr [14824,14839]
atom_expr [14824,14839]
===
match
---
trailer [71797,71818]
trailer [71797,71818]
===
match
---
suite [67372,67433]
suite [67372,67433]
===
match
---
operator: = [77648,77649]
operator: = [77648,77649]
===
match
---
trailer [87431,87443]
trailer [87530,87542]
===
match
---
param [46492,46516]
param [46492,46516]
===
match
---
atom_expr [18384,18412]
atom_expr [18384,18412]
===
match
---
simple_stmt [107820,107840]
simple_stmt [107919,107939]
===
match
---
name: timezone [15203,15211]
name: timezone [15203,15211]
===
match
---
funcdef [62077,66424]
funcdef [62077,66424]
===
match
---
name: UPSTREAM_FAILED [64915,64930]
name: UPSTREAM_FAILED [64915,64930]
===
match
---
expr_stmt [92165,92213]
expr_stmt [92264,92312]
===
match
---
simple_stmt [16645,16692]
simple_stmt [16645,16692]
===
match
---
name: self [73578,73582]
name: self [73578,73582]
===
match
---
name: timezone [44623,44631]
name: timezone [44623,44631]
===
match
---
name: session [43801,43808]
name: session [43801,43808]
===
match
---
if_stmt [106970,107031]
if_stmt [107069,107130]
===
match
---
name: recursion_depth [50950,50965]
name: recursion_depth [50950,50965]
===
match
---
fstring_end: " [98013,98014]
fstring_end: " [98112,98113]
===
match
---
not_test [75629,75648]
not_test [75629,75648]
===
match
---
name: clear [66825,66830]
name: clear [66825,66830]
===
match
---
name: self [94400,94404]
name: self [94499,94503]
===
match
---
tfpdef [80748,80778]
tfpdef [80748,80778]
===
match
---
atom_expr [73852,73865]
atom_expr [73852,73865]
===
match
---
trailer [46149,46176]
trailer [46149,46176]
===
match
---
name: task [51920,51924]
name: task [51920,51924]
===
match
---
arglist [64472,64596]
arglist [64472,64596]
===
match
---
param [55981,55994]
param [55981,55994]
===
match
---
operator: = [77521,77522]
operator: = [77521,77522]
===
match
---
trailer [84254,84261]
trailer [84353,84360]
===
match
---
atom_expr [70368,70386]
atom_expr [70368,70386]
===
match
---
operator: , [14157,14158]
operator: , [14157,14158]
===
match
---
name: models [2028,2034]
name: models [2028,2034]
===
match
---
name: filtered_child [72331,72345]
name: filtered_child [72331,72345]
===
match
---
name: d [74024,74025]
name: d [74024,74025]
===
match
---
name: dag [73454,73457]
name: dag [73454,73457]
===
match
---
name: ti [54937,54939]
name: ti [54937,54939]
===
match
---
operator: , [2385,2386]
operator: , [2385,2386]
===
match
---
name: str [82296,82299]
name: str [82320,82323]
===
match
---
name: timezone [15629,15637]
name: timezone [15629,15637]
===
match
---
expr_stmt [15371,15414]
expr_stmt [15371,15414]
===
match
---
operator: != [19864,19866]
operator: != [19864,19866]
===
match
---
name: type [17788,17792]
name: type [17788,17792]
===
match
---
atom_expr [19571,19613]
atom_expr [19571,19613]
===
match
---
simple_stmt [51870,51903]
simple_stmt [51870,51903]
===
match
---
trailer [14130,14143]
trailer [14130,14143]
===
match
---
string: """         Calculates the following schedule for this dag in UTC.          :param dttm: utc datetime         :return: utc datetime         """ [21280,21423]
string: """         Calculates the following schedule for this dag in UTC.          :param dttm: utc datetime         :return: utc datetime         """ [21280,21423]
===
match
---
name: dag [72957,72960]
name: dag [72957,72960]
===
match
---
name: update [61992,61998]
name: update [61992,61998]
===
match
---
param [29546,29551]
param [29546,29551]
===
match
---
name: convert_to_utc [14851,14865]
name: convert_to_utc [14851,14865]
===
match
---
name: env [43189,43192]
name: env [43189,43192]
===
match
---
name: max_recursion_depth [46083,46102]
name: max_recursion_depth [46083,46102]
===
match
---
operator: , [44803,44804]
operator: , [44803,44804]
===
match
---
argument [67992,68023]
argument [67992,68023]
===
match
---
name: future [57256,57262]
name: future [57256,57262]
===
match
---
name: Schedule [21942,21950]
name: Schedule [21942,21950]
===
match
---
atom_expr [25237,25260]
atom_expr [25237,25260]
===
match
---
atom_expr [70707,70716]
atom_expr [70707,70716]
===
match
---
atom_expr [44485,44513]
atom_expr [44485,44513]
===
match
---
simple_stmt [90565,90758]
simple_stmt [90664,90857]
===
match
---
name: dag_id [74559,74565]
name: dag_id [74559,74565]
===
match
---
param [45808,45830]
param [45808,45830]
===
match
---
factor [107867,107869]
factor [107966,107968]
===
match
---
atom_expr [13982,13995]
atom_expr [13982,13995]
===
match
---
atom_expr [88307,88317]
atom_expr [88406,88416]
===
match
---
suite [103062,104054]
suite [103161,104153]
===
match
---
name: self [14379,14383]
name: self [14379,14383]
===
match
---
trailer [39627,39633]
trailer [39627,39633]
===
match
---
name: include_parentdag [50064,50081]
name: include_parentdag [50064,50081]
===
match
---
name: datetime [80550,80558]
name: datetime [80550,80558]
===
match
---
operator: -> [31626,31628]
operator: -> [31626,31628]
===
match
---
name: state [55756,55761]
name: state [55756,55761]
===
match
---
operator: , [106846,106847]
operator: , [106945,106946]
===
match
---
operator: , [3457,3458]
operator: , [3457,3458]
===
match
---
name: _previous_context_managed_dags [108640,108670]
name: _previous_context_managed_dags [108739,108769]
===
match
---
comparison [48444,48477]
comparison [48444,48477]
===
match
---
operator: = [105399,105400]
operator: = [105498,105499]
===
match
---
operator: = [59476,59477]
operator: = [59476,59477]
===
match
---
string: """         Sets the given edge information on the DAG. Note that this will overwrite,         rather than merge with, existing info.         """ [93899,94044]
string: """         Sets the given edge information on the DAG. Note that this will overwrite,         rather than merge with, existing info.         """ [93998,94143]
===
match
---
operator: @ [99743,99744]
operator: @ [99842,99843]
===
match
---
trailer [89833,89840]
trailer [89932,89939]
===
match
---
atom_expr [96182,96198]
atom_expr [96281,96297]
===
match
---
atom_expr [53873,53891]
atom_expr [53873,53891]
===
match
---
param [90046,90058]
param [90145,90157]
===
match
---
operator: } [93283,93284]
operator: } [93382,93383]
===
match
---
trailer [85891,86124]
trailer [85990,86223]
===
match
---
name: TI [51688,51690]
name: TI [51688,51690]
===
match
---
sync_comp_for [70684,70737]
sync_comp_for [70684,70737]
===
match
---
simple_stmt [91917,91972]
simple_stmt [92016,92071]
===
match
---
name: execution_date [48770,48784]
name: execution_date [48770,48784]
===
match
---
name: self [16645,16649]
name: self [16645,16649]
===
match
---
atom [98636,98710]
atom [98735,98809]
===
match
---
funcdef [88791,89089]
funcdef [88890,89188]
===
match
---
atom_expr [34292,34305]
atom_expr [34292,34305]
===
match
---
trailer [68833,68847]
trailer [68833,68847]
===
match
---
arglist [28607,28767]
arglist [28607,28767]
===
match
---
param [47063,47092]
param [47063,47092]
===
match
---
string: """Folder location of where the DAG object is instantiated.""" [33415,33477]
string: """Folder location of where the DAG object is instantiated.""" [33415,33477]
===
match
---
trailer [27969,28001]
trailer [27969,28001]
===
match
---
name: DR [4050,4052]
name: DR [4050,4052]
===
match
---
trailer [85406,85430]
trailer [85505,85529]
===
match
---
name: perms [19830,19835]
name: perms [19830,19835]
===
match
---
trailer [18801,18826]
trailer [18801,18826]
===
match
---
expr_stmt [36049,36110]
expr_stmt [36049,36110]
===
match
---
operator: = [58091,58092]
operator: = [58091,58092]
===
match
---
simple_stmt [66765,66778]
simple_stmt [66765,66778]
===
match
---
subscriptlist [80934,80952]
subscriptlist [80934,80952]
===
match
---
if_stmt [97322,97771]
if_stmt [97421,97870]
===
match
---
string: '_log' [68840,68846]
string: '_log' [68840,68846]
===
match
---
tfpdef [104107,104115]
tfpdef [104206,104214]
===
match
---
name: default_view [15859,15871]
name: default_view [15859,15871]
===
match
---
operator: , [67928,67929]
operator: , [67928,67929]
===
match
---
trailer [48566,48584]
trailer [48566,48584]
===
match
---
name: root_dag_id [94672,94683]
name: root_dag_id [94771,94782]
===
match
---
trailer [102468,102474]
trailer [102567,102573]
===
match
---
name: first [74707,74712]
name: first [74707,74712]
===
match
---
name: previous_schedule [21720,21737]
name: previous_schedule [21720,21737]
===
match
---
trailer [50376,50383]
trailer [50376,50383]
===
match
---
name: external_trigger [3983,3999]
name: external_trigger [3983,3999]
===
match
---
name: cls [99376,99379]
name: cls [99475,99478]
===
match
---
trailer [83017,83027]
trailer [83116,83126]
===
match
---
name: condition [51550,51559]
name: condition [51550,51559]
===
match
---
simple_stmt [95438,95473]
simple_stmt [95537,95572]
===
match
---
name: visited_external_tis [51623,51643]
name: visited_external_tis [51623,51643]
===
match
---
operator: , [99633,99634]
operator: , [99732,99733]
===
match
---
trailer [103687,103697]
trailer [103786,103796]
===
match
---
arglist [61542,61669]
arglist [61542,61669]
===
match
---
name: state [49220,49225]
name: state [49220,49225]
===
match
---
name: session [85809,85816]
name: session [85908,85915]
===
match
---
name: session [58118,58125]
name: session [58118,58125]
===
match
---
atom_expr [82277,82300]
atom_expr [82301,82324]
===
match
---
trailer [87585,87613]
trailer [87684,87712]
===
match
---
dictorsetmaker [42460,42630]
dictorsetmaker [42460,42630]
===
match
---
name: logical_date [104863,104875]
name: logical_date [104962,104974]
===
match
---
trailer [47483,47529]
trailer [47483,47529]
===
match
---
name: functools [1677,1686]
name: functools [1677,1686]
===
match
---
dotted_name [1838,1857]
dotted_name [1838,1857]
===
match
---
name: TimeRestriction [26638,26653]
name: TimeRestriction [26638,26653]
===
match
---
simple_stmt [20946,21099]
simple_stmt [20946,21099]
===
match
---
trailer [45938,45943]
trailer [45938,45943]
===
match
---
name: self [31925,31929]
name: self [31925,31929]
===
match
---
operator: @ [46255,46256]
operator: @ [46255,46256]
===
match
---
and_test [82897,82983]
and_test [82996,83082]
===
match
---
name: k [68517,68518]
name: k [68517,68518]
===
match
---
trailer [86383,86390]
trailer [86482,86489]
===
match
---
name: schedule_interval [36165,36182]
name: schedule_interval [36165,36182]
===
match
---
atom_expr [14611,14657]
atom_expr [14611,14657]
===
match
---
trailer [49808,49814]
trailer [49808,49814]
===
match
---
name: exclude_task_ids [55101,55117]
name: exclude_task_ids [55101,55117]
===
match
---
name: keys [73294,73298]
name: keys [73294,73298]
===
match
---
atom [3558,3567]
atom [3558,3567]
===
match
---
param [46737,46769]
param [46737,46769]
===
match
---
operator: -> [31201,31203]
operator: -> [31201,31203]
===
match
---
trailer [35963,35992]
trailer [35963,35992]
===
match
---
trailer [15644,15646]
trailer [15644,15646]
===
match
---
trailer [54928,54932]
trailer [54928,54932]
===
match
---
funcdef [101267,101918]
funcdef [101366,102017]
===
match
---
trailer [73702,73712]
trailer [73702,73712]
===
match
---
name: BaseOperator [13866,13878]
name: BaseOperator [13866,13878]
===
match
---
trailer [29633,29744]
trailer [29633,29744]
===
match
---
name: OnceTimetable [2594,2607]
name: OnceTimetable [2594,2607]
===
match
---
name: isinstance [25003,25013]
name: isinstance [25003,25013]
===
match
---
atom_expr [27785,27809]
atom_expr [27785,27809]
===
match
---
simple_stmt [21654,21666]
simple_stmt [21654,21666]
===
match
---
argument [79706,79731]
argument [79706,79731]
===
match
---
atom_expr [83048,83088]
atom_expr [83147,83187]
===
match
---
expr_stmt [24138,24202]
expr_stmt [24138,24202]
===
match
---
simple_stmt [73482,73493]
simple_stmt [73482,73493]
===
match
---
simple_stmt [33734,33782]
simple_stmt [33734,33782]
===
match
---
atom_expr [34242,34251]
atom_expr [34242,34251]
===
match
---
trailer [71764,71766]
trailer [71764,71766]
===
match
---
operator: , [66228,66229]
operator: , [66228,66229]
===
match
---
argument [91780,91805]
argument [91879,91904]
===
match
---
parameters [100383,100389]
parameters [100482,100488]
===
match
---
name: utils [3190,3195]
name: utils [3190,3195]
===
match
---
name: self [100771,100775]
name: self [100870,100874]
===
match
---
argument [53978,53989]
argument [53978,53989]
===
match
---
operator: , [25022,25023]
operator: , [25022,25023]
===
match
---
operator: , [18120,18121]
operator: , [18120,18121]
===
match
---
name: self [98920,98924]
name: self [99019,99023]
===
match
---
param [61290,61295]
param [61290,61295]
===
match
---
trailer [107663,107675]
trailer [107762,107774]
===
match
---
simple_stmt [37656,37721]
simple_stmt [37656,37721]
===
match
---
name: path [101042,101046]
name: path [101141,101145]
===
match
---
name: task_id [71276,71283]
name: task_id [71276,71283]
===
match
---
and_test [60913,60970]
and_test [60913,60970]
===
match
---
atom_expr [15713,15733]
atom_expr [15713,15733]
===
match
---
name: earliest [25397,25405]
name: earliest [25397,25405]
===
match
---
atom_expr [38645,38656]
atom_expr [38645,38656]
===
match
---
simple_stmt [95278,95313]
simple_stmt [95377,95412]
===
match
---
name: f [106449,106450]
name: f [106548,106549]
===
match
---
trailer [96128,96132]
trailer [96227,96231]
===
match
---
name: pickle [864,870]
name: pickle [864,870]
===
match
---
atom_expr [48689,48702]
atom_expr [48689,48702]
===
match
---
operator: = [85533,85534]
operator: = [85632,85633]
===
match
---
operator: , [3427,3428]
operator: , [3427,3428]
===
match
---
operator: , [97559,97560]
operator: , [97658,97659]
===
match
---
name: Literal [45966,45973]
name: Literal [45966,45973]
===
match
---
argument [80348,80363]
argument [80348,80363]
===
match
---
number: 2 [20874,20875]
number: 2 [20874,20875]
===
match
---
atom_expr [31742,31760]
atom_expr [31742,31760]
===
match
---
name: dags [88696,88700]
name: dags [88795,88799]
===
match
---
funcdef [37780,38142]
funcdef [37780,38142]
===
match
---
operator: @ [30127,30128]
operator: @ [30127,30128]
===
match
---
name: State [55763,55768]
name: State [55763,55768]
===
match
---
operator: = [86912,86913]
operator: = [87011,87012]
===
match
---
param [3597,3604]
param [3597,3604]
===
match
---
operator: , [88746,88747]
operator: , [88845,88846]
===
match
---
string: " " [75111,75114]
string: " " [75111,75114]
===
match
---
name: state [91858,91863]
name: state [91957,91962]
===
match
---
name: ignore_task_deps [79832,79848]
name: ignore_task_deps [79832,79848]
===
match
---
simple_stmt [842,857]
simple_stmt [842,857]
===
match
---
trailer [74685,74688]
trailer [74685,74688]
===
match
---
name: str [45939,45942]
name: str [45939,45942]
===
match
---
name: relative_fileloc [33019,33035]
name: relative_fileloc [33019,33035]
===
match
---
trailer [17526,17556]
trailer [17526,17556]
===
match
---
trailer [66076,66084]
trailer [66076,66084]
===
match
---
trailer [24366,24379]
trailer [24366,24379]
===
match
---
operator: @ [99339,99340]
operator: @ [99438,99439]
===
match
---
name: bool [46511,46515]
name: bool [46511,46515]
===
match
---
name: Boolean [95576,95583]
name: Boolean [95675,95682]
===
match
---
trailer [52673,52789]
trailer [52673,52789]
===
match
---
name: info [94123,94127]
name: info [94222,94226]
===
match
---
simple_stmt [68723,68779]
simple_stmt [68723,68779]
===
match
---
parameters [58286,58292]
parameters [58286,58292]
===
match
---
simple_stmt [36311,36337]
simple_stmt [36311,36337]
===
match
---
name: earliest [26654,26662]
name: earliest [26654,26662]
===
match
---
trailer [68694,68714]
trailer [68694,68714]
===
match
---
fstring_start: f" [98290,98292]
fstring_start: f" [98389,98391]
===
match
---
atom_expr [22048,22090]
atom_expr [22048,22090]
===
match
---
name: self [43303,43307]
name: self [43303,43307]
===
match
---
argument [79815,79848]
argument [79815,79848]
===
match
---
trailer [99432,99437]
trailer [99531,99536]
===
match
---
trailer [73315,73336]
trailer [73315,73336]
===
match
---
string: 'RL' [3511,3515]
string: 'RL' [3511,3515]
===
match
---
operator: , [11818,11819]
operator: , [11818,11819]
===
match
---
operator: = [4033,4034]
operator: = [4033,4034]
===
match
---
name: str [73526,73529]
name: str [73526,73529]
===
match
---
operator: = [61928,61929]
operator: = [61928,61929]
===
match
---
expr_stmt [107469,107498]
expr_stmt [107568,107597]
===
match
---
arglist [64686,64814]
arglist [64686,64814]
===
match
---
name: existing_dag_ids [85118,85134]
name: existing_dag_ids [85217,85233]
===
match
---
operator: = [84270,84271]
operator: = [84369,84370]
===
match
---
name: DagRunState [80504,80515]
name: DagRunState [80504,80515]
===
match
---
atom_expr [49796,49834]
atom_expr [49796,49834]
===
match
---
name: copied [72011,72017]
name: copied [72011,72017]
===
match
---
atom_expr [66337,66377]
atom_expr [66337,66377]
===
match
---
expr_stmt [94227,94252]
expr_stmt [94326,94351]
===
match
---
name: filelocs [88498,88506]
name: filelocs [88597,88605]
===
match
---
trailer [76526,76534]
trailer [76526,76534]
===
match
---
trailer [79608,80150]
trailer [79608,80150]
===
match
---
arglist [86408,86554]
arglist [86507,86653]
===
match
---
name: TI [48113,48115]
name: TI [48113,48115]
===
match
---
name: date_last_automated_dagrun [23949,23975]
name: date_last_automated_dagrun [23949,23975]
===
match
---
string: 'start_date' [10401,10413]
string: 'start_date' [10401,10413]
===
match
---
decorator [98716,98750]
decorator [98815,98849]
===
match
---
name: property [75314,75322]
name: property [75314,75322]
===
match
---
param [32691,32695]
param [32691,32695]
===
match
---
name: STATICA_HACK [107891,107903]
name: STATICA_HACK [107990,108002]
===
match
---
string: """Stringified DAGs and operators contain exactly these fields.""" [92304,92370]
string: """Stringified DAGs and operators contain exactly these fields.""" [92403,92469]
===
match
---
operator: = [86989,86990]
operator: = [87088,87089]
===
match
---
expr_stmt [57056,57071]
expr_stmt [57056,57071]
===
match
---
decorated [84174,88765]
decorated [84273,88864]
===
match
---
trailer [26606,26614]
trailer [26606,26614]
===
match
---
simple_stmt [49345,49394]
simple_stmt [49345,49394]
===
match
---
name: airflow [2327,2334]
name: airflow [2327,2334]
===
match
---
name: tis [66174,66177]
name: tis [66174,66177]
===
match
---
name: BACKFILL_JOB [86017,86029]
name: BACKFILL_JOB [86116,86128]
===
match
---
atom_expr [88400,88424]
atom_expr [88499,88523]
===
match
---
simple_stmt [28875,28911]
simple_stmt [28875,28911]
===
match
---
simple_stmt [97126,97226]
simple_stmt [97225,97325]
===
match
---
name: task_id [59415,59422]
name: task_id [59415,59422]
===
match
---
operator: = [20781,20782]
operator: = [20781,20782]
===
match
---
operator: , [64595,64596]
operator: , [64595,64596]
===
match
---
name: permissions [2278,2289]
name: permissions [2278,2289]
===
match
---
fstring_start: f" [73944,73946]
fstring_start: f" [73944,73946]
===
match
---
name: hash_components [18205,18220]
name: hash_components [18205,18220]
===
match
---
name: last_pickled [95278,95290]
name: last_pickled [95377,95389]
===
match
---
atom_expr [11232,11254]
atom_expr [11232,11254]
===
match
---
atom_expr [33896,33918]
atom_expr [33896,33918]
===
match
---
operator: { [92494,92495]
operator: { [92593,92594]
===
match
---
simple_stmt [20163,20193]
simple_stmt [20163,20193]
===
match
---
name: AttributeError [21993,22007]
name: AttributeError [21993,22007]
===
match
---
operator: = [83434,83435]
operator: = [83533,83534]
===
match
---
argument [83125,83143]
argument [83224,83242]
===
match
---
name: cli_parser [80326,80336]
name: cli_parser [80326,80336]
===
match
---
name: as_pk_tuple [54208,54219]
name: as_pk_tuple [54208,54219]
===
match
---
name: stacklevel [32931,32941]
name: stacklevel [32931,32941]
===
match
---
return_stmt [31413,31440]
return_stmt [31413,31440]
===
match
---
name: timezone [87324,87332]
name: timezone [87423,87431]
===
match
---
atom_expr [43582,43663]
atom_expr [43582,43663]
===
match
---
trailer [85884,85891]
trailer [85983,85990]
===
match
---
operator: = [101874,101875]
operator: = [101973,101974]
===
match
---
trailer [61008,61015]
trailer [61008,61015]
===
match
---
operator: , [32463,32464]
operator: , [32463,32464]
===
match
---
if_stmt [25000,25109]
if_stmt [25000,25109]
===
match
---
name: has_task_concurrency_limits [96374,96401]
name: has_task_concurrency_limits [96473,96500]
===
match
---
simple_stmt [925,961]
simple_stmt [925,961]
===
match
---
trailer [38587,38593]
trailer [38587,38593]
===
match
---
trailer [73812,73820]
trailer [73812,73820]
===
match
---
trailer [109088,109109]
trailer [109187,109208]
===
match
---
operator: , [55810,55811]
operator: , [55810,55811]
===
match
---
name: self [37423,37427]
name: self [37423,37427]
===
match
---
name: models [2073,2079]
name: models [2073,2079]
===
match
---
trailer [99282,99303]
trailer [99381,99402]
===
match
---
trailer [97158,97165]
trailer [97257,97264]
===
match
---
trailer [101714,101726]
trailer [101813,101825]
===
match
---
fstring_end: " [53459,53460]
fstring_end: " [53459,53460]
===
match
---
name: replace [15681,15688]
name: replace [15681,15688]
===
match
---
name: unique [96958,96964]
name: unique [97057,97063]
===
match
---
name: set_state [56999,57008]
name: set_state [56999,57008]
===
match
---
expr_stmt [19753,19836]
expr_stmt [19753,19836]
===
match
---
parameters [100846,100852]
parameters [100945,100951]
===
match
---
trailer [15659,15671]
trailer [15659,15671]
===
match
---
name: dag_run_state [68059,68072]
name: dag_run_state [68059,68072]
===
match
---
name: session [48099,48106]
name: session [48099,48106]
===
match
---
trailer [101764,101774]
trailer [101863,101873]
===
match
---
atom_expr [23676,23703]
atom_expr [23676,23703]
===
match
---
trailer [49943,49950]
trailer [49943,49950]
===
match
---
arglist [72133,72146]
arglist [72133,72146]
===
match
---
name: max [24640,24643]
name: max [24640,24643]
===
match
---
trailer [25098,25108]
trailer [25098,25108]
===
match
---
subscriptlist [11170,11188]
subscriptlist [11170,11188]
===
match
---
trailer [11928,11963]
trailer [11928,11963]
===
match
---
trailer [74695,74705]
trailer [74695,74705]
===
match
---
atom_expr [55473,55498]
atom_expr [55473,55498]
===
match
---
name: flush [66395,66400]
name: flush [66395,66400]
===
match
---
operator: , [2649,2650]
operator: , [2649,2650]
===
match
---
trailer [52905,53114]
trailer [52905,53114]
===
match
---
trailer [72873,72878]
trailer [72873,72878]
===
match
---
name: tii [53448,53451]
name: tii [53448,53451]
===
match
---
string: 'dag' [96305,96310]
string: 'dag' [96404,96409]
===
match
---
atom_expr [12121,12134]
atom_expr [12121,12134]
===
match
---
operator: , [48122,48123]
operator: , [48122,48123]
===
match
---
simple_stmt [83099,83503]
simple_stmt [83198,83602]
===
match
---
atom_expr [98881,98917]
atom_expr [98980,99016]
===
match
---
if_stmt [49526,49892]
if_stmt [49526,49892]
===
match
---
operator: = [96497,96498]
operator: = [96596,96597]
===
match
---
operator: = [96995,96996]
operator: = [97094,97095]
===
match
---
name: str [31722,31725]
name: str [31722,31725]
===
match
---
simple_stmt [106008,106071]
simple_stmt [106107,106170]
===
match
---
name: in_ [49970,49973]
name: in_ [49970,49973]
===
match
---
name: DagRun [61852,61858]
name: DagRun [61852,61858]
===
match
---
trailer [44506,44511]
trailer [44506,44511]
===
match
---
arglist [91548,91578]
arglist [91647,91677]
===
match
---
operator: , [13067,13068]
operator: , [13067,13068]
===
match
---
simple_stmt [2665,2700]
simple_stmt [2665,2700]
===
match
---
param [45674,45683]
param [45674,45683]
===
match
---
suite [73821,73917]
suite [73821,73917]
===
match
---
atom_expr [12563,12588]
atom_expr [12563,12588]
===
match
---
parameters [71426,71447]
parameters [71426,71447]
===
match
---
name: find [37963,37967]
name: find [37963,37967]
===
match
---
trailer [31746,31760]
trailer [31746,31760]
===
match
---
param [62158,62172]
param [62158,62172]
===
match
---
operator: , [47357,47358]
operator: , [47357,47358]
===
match
---
return_stmt [74943,74952]
return_stmt [74943,74952]
===
match
---
name: type [82371,82375]
name: type [82395,82399]
===
match
---
or_test [76458,76608]
or_test [76458,76608]
===
match
---
atom_expr [51870,51902]
atom_expr [51870,51902]
===
match
---
name: start_date [66497,66507]
name: start_date [66497,66507]
===
match
---
atom_expr [65097,65110]
atom_expr [65097,65110]
===
match
---
operator: == [39754,39756]
operator: == [39754,39756]
===
match
---
number: 1 [52350,52351]
number: 1 [52350,52351]
===
match
---
simple_stmt [67639,67681]
simple_stmt [67639,67681]
===
match
---
parameters [31963,31994]
parameters [31963,31994]
===
match
---
name: func [40815,40819]
name: func [40815,40819]
===
match
---
for_stmt [90389,90852]
for_stmt [90488,90951]
===
match
---
fstring_start: f" [82335,82337]
fstring_start: f" [82359,82361]
===
match
---
name: self [33896,33900]
name: self [33896,33900]
===
match
---
trailer [74558,74565]
trailer [74558,74565]
===
match
---
name: tasks [87664,87669]
name: tasks [87763,87768]
===
match
---
operator: , [14358,14359]
operator: , [14358,14359]
===
match
---
name: sqlalchemy [1519,1529]
name: sqlalchemy [1519,1529]
===
match
---
name: all [49529,49532]
name: all [49529,49532]
===
match
---
string: 'core' [11519,11525]
string: 'core' [11519,11525]
===
match
---
name: bind [106452,106456]
name: bind [106551,106555]
===
match
---
name: property [31767,31775]
name: property [31767,31775]
===
match
---
param [35740,35744]
param [35740,35744]
===
match
---
atom_expr [37656,37720]
atom_expr [37656,37720]
===
match
---
string: 'jinja_environment_kwargs' [93059,93085]
string: 'jinja_environment_kwargs' [93158,93184]
===
match
---
decorated [35329,35688]
decorated [35329,35688]
===
match
---
name: self [94053,94057]
name: self [94152,94156]
===
match
---
name: upstream_task_id [43596,43612]
name: upstream_task_id [43596,43612]
===
match
---
trailer [83685,83702]
trailer [83784,83801]
===
match
---
trailer [95028,95052]
trailer [95127,95151]
===
match
---
comparison [55082,55117]
comparison [55082,55117]
===
match
---
operator: = [57697,57698]
operator: = [57697,57698]
===
match
---
name: include_dependent_dags [51135,51157]
name: include_dependent_dags [51135,51157]
===
match
---
atom_expr [68378,68392]
atom_expr [68378,68392]
===
match
---
trailer [98805,98832]
trailer [98904,98931]
===
match
---
atom_expr [98121,98157]
atom_expr [98220,98256]
===
match
---
atom_expr [67385,67411]
atom_expr [67385,67411]
===
match
---
operator: = [11845,11846]
operator: = [11845,11846]
===
match
---
trailer [14049,14062]
trailer [14049,14062]
===
match
---
atom_expr [48746,48799]
atom_expr [48746,48799]
===
match
---
subscriptlist [45783,45797]
subscriptlist [45783,45797]
===
match
---
atom_expr [34743,34773]
atom_expr [34743,34773]
===
match
---
return_stmt [68224,68236]
return_stmt [68224,68236]
===
match
---
name: str [33402,33405]
name: str [33402,33405]
===
match
---
name: query [3959,3964]
name: query [3959,3964]
===
match
---
operator: = [57358,57359]
operator: = [57358,57359]
===
match
---
operator: = [68873,68874]
operator: = [68873,68874]
===
match
---
return_stmt [18841,18852]
return_stmt [18841,18852]
===
match
---
string: """A tag name per dag, to allow quick filtering in the DAG view.""" [94154,94221]
string: """A tag name per dag, to allow quick filtering in the DAG view.""" [94253,94320]
===
match
---
argument [50202,50261]
argument [50202,50261]
===
match
---
name: edge_info [16913,16922]
name: edge_info [16913,16922]
===
match
---
param [3605,3613]
param [3605,3613]
===
match
---
operator: = [45390,45391]
operator: = [45390,45391]
===
match
---
name: filter [100122,100128]
name: filter [100221,100227]
===
match
---
name: count [66027,66032]
name: count [66027,66032]
===
match
---
suite [91756,92131]
suite [91855,92230]
===
match
---
operator: , [42505,42506]
operator: , [42505,42506]
===
match
---
trailer [55796,55802]
trailer [55796,55802]
===
match
---
raise_stmt [32479,32561]
raise_stmt [32479,32561]
===
match
---
simple_stmt [74639,74715]
simple_stmt [74639,74715]
===
match
---
name: run_after [104937,104946]
name: run_after [105036,105045]
===
match
---
atom_expr [85051,85108]
atom_expr [85150,85207]
===
match
---
comparison [36160,36193]
comparison [36160,36193]
===
match
---
trailer [91779,91806]
trailer [91878,91905]
===
match
---
operator: , [50633,50634]
operator: , [50633,50634]
===
match
---
name: task_group [32680,32690]
name: task_group [32680,32690]
===
match
---
name: self [76983,76987]
name: self [76983,76987]
===
match
---
name: self [98675,98679]
name: self [98774,98778]
===
match
---
trailer [76965,76976]
trailer [76965,76976]
===
match
---
operator: , [47079,47080]
operator: , [47079,47080]
===
match
---
argument [66021,66032]
argument [66021,66032]
===
match
---
name: task_id [48677,48684]
name: task_id [48677,48684]
===
match
---
name: dags [83808,83812]
name: dags [83907,83911]
===
match
---
atom_expr [104024,104052]
atom_expr [104123,104151]
===
match
---
operator: = [16487,16488]
operator: = [16487,16488]
===
match
---
comp_if [58705,58732]
comp_if [58705,58732]
===
match
---
operator: = [48337,48338]
operator: = [48337,48338]
===
match
---
atom_expr [50154,50357]
atom_expr [50154,50357]
===
match
---
name: task_ids [46327,46335]
name: task_ids [46327,46335]
===
match
---
name: exclude_task_ids [65605,65621]
name: exclude_task_ids [65605,65621]
===
match
---
atom_expr [82757,82884]
atom_expr [82856,82983]
===
match
---
name: ti [37437,37439]
name: ti [37437,37439]
===
match
---
name: self [14543,14547]
name: self [14543,14547]
===
match
---
funcdef [99501,99720]
funcdef [99600,99819]
===
match
---
operator: == [86532,86534]
operator: == [86631,86633]
===
match
---
name: exclude_task_ids [50805,50821]
name: exclude_task_ids [50805,50821]
===
match
---
name: start_date [65239,65249]
name: start_date [65239,65249]
===
match
---
atom_expr [61943,61964]
atom_expr [61943,61964]
===
match
---
name: datetime [20365,20373]
name: datetime [20365,20373]
===
match
---
trailer [107522,107530]
trailer [107621,107629]
===
match
---
trailer [13860,13879]
trailer [13860,13879]
===
match
---
trailer [12214,12220]
trailer [12214,12220]
===
match
---
name: end_date [50539,50547]
name: end_date [50539,50547]
===
match
---
trailer [82375,82383]
trailer [82399,82407]
===
match
---
trailer [18636,18641]
trailer [18636,18641]
===
match
---
tfpdef [39011,39040]
tfpdef [39011,39040]
===
match
---
name: self [37800,37804]
name: self [37800,37804]
===
match
---
not_test [57830,57840]
not_test [57830,57840]
===
match
---
term [75111,75126]
term [75111,75126]
===
match
---
simple_stmt [21124,21176]
simple_stmt [21124,21176]
===
match
---
trailer [34342,34344]
trailer [34342,34344]
===
match
---
string: 'SubDagOperator' [41768,41784]
string: 'SubDagOperator' [41768,41784]
===
match
---
name: info [23920,23924]
name: info [23920,23924]
===
match
---
trailer [86390,86568]
trailer [86489,86667]
===
match
---
comparison [21623,21640]
comparison [21623,21640]
===
match
---
string: "DAG.normalized_schedule_interval() is deprecated." [35812,35863]
string: "DAG.normalized_schedule_interval() is deprecated." [35812,35863]
===
match
---
parameters [34412,34418]
parameters [34412,34418]
===
match
---
sync_comp_for [71348,71385]
sync_comp_for [71348,71385]
===
match
---
operator: { [17717,17718]
operator: { [17717,17718]
===
match
---
operator: , [11197,11198]
operator: , [11197,11198]
===
match
---
name: self [12508,12512]
name: self [12508,12512]
===
match
---
trailer [101705,101742]
trailer [101804,101841]
===
match
---
operator: -> [46191,46193]
operator: -> [46191,46193]
===
match
---
trailer [82687,82713]
trailer [82797,82823]
===
match
---
name: execution_date [48139,48153]
name: execution_date [48139,48153]
===
match
---
operator: , [13485,13486]
operator: , [13485,13486]
===
match
---
decorator [32750,32760]
decorator [32750,32760]
===
match
---
name: end_dates [24644,24653]
name: end_dates [24644,24653]
===
match
---
operator: , [46768,46769]
operator: , [46768,46769]
===
match
---
atom_expr [68753,68778]
atom_expr [68753,68778]
===
match
---
argument [85073,85084]
argument [85172,85183]
===
match
---
simple_stmt [2015,2060]
simple_stmt [2015,2060]
===
match
---
trailer [85621,85630]
trailer [85720,85729]
===
match
---
expr_stmt [107515,107572]
expr_stmt [107614,107671]
===
match
---
trailer [44288,44295]
trailer [44288,44295]
===
match
---
string: 'template_undefined' [93021,93041]
string: 'template_undefined' [93120,93140]
===
match
---
name: timezone [14842,14850]
name: timezone [14842,14850]
===
match
---
name: tis [49584,49587]
name: tis [49584,49587]
===
match
---
name: nativetypes [1324,1335]
name: nativetypes [1324,1335]
===
match
---
trailer [51687,51731]
trailer [51687,51731]
===
match
---
name: get_task [43587,43595]
name: get_task [43587,43595]
===
match
---
trailer [4092,4098]
trailer [4092,4098]
===
match
---
argument [65588,65621]
argument [65588,65621]
===
match
---
trailer [24842,24860]
trailer [24842,24860]
===
match
---
suite [49411,49982]
suite [49411,49982]
===
match
---
atom_expr [84928,84970]
atom_expr [85027,85069]
===
match
---
atom_expr [13552,13574]
atom_expr [13552,13574]
===
match
---
name: Timetable [2387,2396]
name: Timetable [2387,2396]
===
match
---
name: tags [17609,17613]
name: tags [17609,17613]
===
match
---
operator: , [31979,31980]
operator: , [31979,31980]
===
match
---
atom_expr [71899,71929]
atom_expr [71899,71929]
===
match
---
arglist [95132,95154]
arglist [95231,95253]
===
match
---
argument [62022,62049]
argument [62022,62049]
===
match
---
trailer [61767,61795]
trailer [61767,61795]
===
match
---
trailer [91857,91863]
trailer [91956,91962]
===
match
---
trailer [106841,106846]
trailer [106940,106945]
===
match
---
trailer [72791,72812]
trailer [72791,72812]
===
match
---
simple_stmt [37949,38009]
simple_stmt [37949,38009]
===
match
---
operator: , [76070,76071]
operator: , [76070,76071]
===
match
---
simple_stmt [12682,12709]
simple_stmt [12682,12709]
===
match
---
name: parent_dag [50159,50169]
name: parent_dag [50159,50169]
===
match
---
atom_expr [87578,87613]
atom_expr [87677,87712]
===
match
---
name: execution_date [82479,82493]
name: execution_date [82524,82538]
===
match
---
trailer [46403,46413]
trailer [46403,46413]
===
match
---
trailer [51951,52009]
trailer [51951,52009]
===
match
---
name: self [75266,75270]
name: self [75266,75270]
===
match
---
operator: , [77269,77270]
operator: , [77269,77270]
===
match
---
trailer [57060,57064]
trailer [57060,57064]
===
match
---
name: self [16441,16445]
name: self [16441,16445]
===
match
---
name: coerce_datetime [26591,26606]
name: coerce_datetime [26591,26606]
===
match
---
simple_stmt [48093,48155]
simple_stmt [48093,48155]
===
match
---
name: end_dates [24431,24440]
name: end_dates [24431,24440]
===
match
---
operator: , [36387,36388]
operator: , [36387,36388]
===
match
---
trailer [14621,14657]
trailer [14621,14657]
===
match
---
name: self [29788,29792]
name: self [29788,29792]
===
match
---
comparison [14029,14062]
comparison [14029,14062]
===
match
---
operator: = [3418,3419]
operator: = [3418,3419]
===
match
---
simple_stmt [107783,107798]
simple_stmt [107882,107897]
===
match
---
name: path [33358,33362]
name: path [33358,33362]
===
match
---
name: dag_ids [61688,61695]
name: dag_ids [61688,61695]
===
match
---
funcdef [31876,31949]
funcdef [31876,31949]
===
match
---
suite [71874,71961]
suite [71874,71961]
===
match
---
name: base_date [43743,43752]
name: base_date [43743,43752]
===
match
---
operator: == [38642,38644]
operator: == [38642,38644]
===
match
---
suite [97823,97951]
suite [97922,98050]
===
match
---
name: str [74220,74223]
name: str [74220,74223]
===
match
---
atom_expr [87759,87795]
atom_expr [87858,87894]
===
match
---
name: dag_id [90686,90692]
name: dag_id [90785,90791]
===
match
---
atom_expr [53227,53257]
atom_expr [53227,53257]
===
match
---
trailer [35671,35685]
trailer [35671,35685]
===
match
---
simple_stmt [79394,79421]
simple_stmt [79394,79421]
===
match
---
atom_expr [73098,73107]
atom_expr [73098,73107]
===
match
---
name: all_tis [67320,67327]
name: all_tis [67320,67327]
===
match
---
trailer [68867,68872]
trailer [68867,68872]
===
match
---
name: in_ [48871,48874]
name: in_ [48871,48874]
===
match
---
name: searchpath [42324,42334]
name: searchpath [42324,42334]
===
match
---
tfpdef [46083,46107]
tfpdef [46083,46107]
===
match
---
name: get_last_dagrun [29881,29896]
name: get_last_dagrun [29881,29896]
===
match
---
name: start_date [44805,44815]
name: start_date [44805,44815]
===
match
---
name: self [21562,21566]
name: self [21562,21566]
===
match
---
name: task_id [73952,73959]
name: task_id [73952,73959]
===
match
---
operator: , [67970,67971]
operator: , [67970,67971]
===
match
---
trailer [67491,67516]
trailer [67491,67516]
===
match
---
operator: , [15692,15693]
operator: , [15692,15693]
===
match
---
atom_expr [39065,39078]
atom_expr [39065,39078]
===
match
---
name: dag_id [98005,98011]
name: dag_id [98104,98110]
===
match
---
name: sys [107476,107479]
name: sys [107575,107578]
===
match
---
argument [67006,67026]
argument [67006,67026]
===
match
---
atom_expr [86991,87012]
atom_expr [87090,87111]
===
match
---
name: warnings [83925,83933]
name: warnings [84024,84032]
===
match
---
tfpdef [46703,46723]
tfpdef [46703,46723]
===
match
---
name: context [37601,37608]
name: context [37601,37608]
===
match
---
return_stmt [32622,32656]
return_stmt [32622,32656]
===
match
---
simple_stmt [18024,18037]
simple_stmt [18024,18037]
===
match
---
expr_stmt [59380,59453]
expr_stmt [59380,59453]
===
match
---
operator: = [57987,57988]
operator: = [57987,57988]
===
match
---
name: value [31354,31359]
name: value [31354,31359]
===
match
---
name: task_ids_or_regex [70720,70737]
name: task_ids_or_regex [70720,70737]
===
match
---
expr_stmt [101042,101075]
expr_stmt [101141,101174]
===
match
---
name: execution_date [82957,82971]
name: execution_date [83056,83070]
===
match
---
param [39977,39986]
param [39977,39986]
===
match
---
name: not_none_state [49819,49833]
name: not_none_state [49819,49833]
===
match
---
trailer [109292,109297]
trailer [109391,109396]
===
match
---
name: end_date [40556,40564]
name: end_date [40556,40564]
===
match
---
name: bool [47216,47220]
name: bool [47216,47220]
===
match
---
decorated [55628,58258]
decorated [55628,58258]
===
match
---
trailer [24218,24229]
trailer [24218,24229]
===
match
---
atom_expr [25003,25051]
atom_expr [25003,25051]
===
match
---
name: Optional [80874,80882]
name: Optional [80874,80882]
===
match
---
name: cls [84233,84236]
name: cls [84332,84335]
===
match
---
param [21265,21269]
param [21265,21269]
===
match
---
atom_expr [54832,54854]
atom_expr [54832,54854]
===
match
---
simple_stmt [66387,66403]
simple_stmt [66387,66403]
===
match
---
operator: , [34305,34306]
operator: , [34305,34306]
===
match
---
name: get_task_instances_before [43694,43719]
name: get_task_instances_before [43694,43719]
===
match
---
name: user_defined_macros [12535,12554]
name: user_defined_macros [12535,12554]
===
match
---
atom_expr [48187,48214]
atom_expr [48187,48214]
===
match
---
trailer [48414,48421]
trailer [48414,48421]
===
match
---
exprlist [19702,19713]
exprlist [19702,19713]
===
match
---
name: datetime [46166,46174]
name: datetime [46166,46174]
===
match
---
name: DagRunState [62343,62354]
name: DagRunState [62343,62354]
===
match
---
name: BaseOperator [73662,73674]
name: BaseOperator [73662,73674]
===
match
---
for_stmt [88157,88425]
for_stmt [88256,88524]
===
match
---
simple_stmt [107004,107031]
simple_stmt [107103,107130]
===
match
---
name: dag_bound_args [106850,106864]
name: dag_bound_args [106949,106963]
===
match
---
name: schedule_interval [87488,87505]
name: schedule_interval [87587,87604]
===
match
---
trailer [83072,83088]
trailer [83171,83187]
===
match
---
comparison [76472,76502]
comparison [76472,76502]
===
match
---
param [11564,11634]
param [11564,11634]
===
match
---
name: Index [96894,96899]
name: Index [96993,96998]
===
match
---
and_test [79286,79308]
and_test [79286,79308]
===
match
---
operator: = [53251,53252]
operator: = [53251,53252]
===
match
---
return_stmt [58669,58733]
return_stmt [58669,58733]
===
match
---
trailer [23580,23598]
trailer [23580,23598]
===
match
---
operator: , [50783,50784]
operator: , [50783,50784]
===
match
---
trailer [87339,87341]
trailer [87438,87440]
===
match
---
name: TypeError [18582,18591]
name: TypeError [18582,18591]
===
match
---
atom_expr [57647,57791]
atom_expr [57647,57791]
===
match
---
name: dag_bag [50897,50904]
name: dag_bag [50897,50904]
===
match
---
name: dagrun_timeout [11643,11657]
name: dagrun_timeout [11643,11657]
===
match
---
name: is_active [102685,102694]
name: is_active [102784,102793]
===
match
---
name: dag [67745,67748]
name: dag [67745,67748]
===
match
---
atom_expr [87484,87505]
atom_expr [87583,87604]
===
match
---
comparison [39732,39771]
comparison [39732,39771]
===
match
---
argument [50700,50745]
argument [50700,50745]
===
match
---
operator: = [3496,3497]
operator: = [3496,3497]
===
match
---
param [92290,92293]
param [92389,92392]
===
match
---
fstring_end: " [61193,61194]
fstring_end: " [61193,61194]
===
match
---
trailer [45584,45586]
trailer [45584,45586]
===
match
---
atom_expr [80919,80954]
atom_expr [80919,80954]
===
match
---
name: state [65087,65092]
name: state [65087,65092]
===
match
---
simple_stmt [72786,72882]
simple_stmt [72786,72882]
===
match
---
suite [34419,34774]
suite [34419,34774]
===
match
---
simple_stmt [79322,79381]
simple_stmt [79322,79381]
===
match
---
name: session [85610,85617]
name: session [85709,85716]
===
match
---
atom [13882,13884]
atom [13882,13884]
===
match
---
arglist [82288,82299]
arglist [82312,82323]
===
match
---
atom_expr [34348,34369]
atom_expr [34348,34369]
===
match
---
operator: { [67572,67573]
operator: { [67572,67573]
===
match
---
atom_expr [15548,15561]
atom_expr [15548,15561]
===
match
---
name: Optional [11104,11112]
name: Optional [11104,11112]
===
match
---
operator: , [68263,68264]
operator: , [68263,68264]
===
match
---
name: type_name [25288,25297]
name: type_name [25288,25297]
===
match
---
expr_stmt [13982,14015]
expr_stmt [13982,14015]
===
match
---
subscriptlist [46810,46828]
subscriptlist [46810,46828]
===
match
---
expr_stmt [14886,14935]
expr_stmt [14886,14935]
===
match
---
operator: , [79762,79763]
operator: , [79762,79763]
===
match
---
atom_expr [80541,80559]
atom_expr [80541,80559]
===
match
---
name: question [65885,65893]
name: question [65885,65893]
===
match
---
if_stmt [14974,15115]
if_stmt [14974,15115]
===
match
---
tfpdef [61465,61483]
tfpdef [61465,61483]
===
match
---
decorated [58499,58734]
decorated [58499,58734]
===
match
---
name: subdag [61021,61027]
name: subdag [61021,61027]
===
match
---
name: fileloc [86929,86936]
name: fileloc [87028,87035]
===
match
---
trailer [42712,42719]
trailer [42712,42719]
===
match
---
operator: , [72434,72435]
operator: , [72434,72435]
===
match
---
return_stmt [18138,18171]
return_stmt [18138,18171]
===
match
---
trailer [25251,25260]
trailer [25251,25260]
===
match
---
name: self [13840,13844]
name: self [13840,13844]
===
match
---
atom_expr [72382,72397]
atom_expr [72382,72397]
===
match
---
string: 'DAG.tasks can not be modified. Use dag.add_task() instead.' [32500,32560]
string: 'DAG.tasks can not be modified. Use dag.add_task() instead.' [32500,32560]
===
match
---
operator: , [45206,45207]
operator: , [45206,45207]
===
match
---
name: DagModel [90458,90466]
name: DagModel [90557,90565]
===
match
---
name: include_subdag_tasks [58766,58786]
name: include_subdag_tasks [58766,58786]
===
match
---
trailer [37531,37538]
trailer [37531,37538]
===
match
---
name: stats [2303,2308]
name: stats [2303,2308]
===
match
---
name: or_ [48567,48570]
name: or_ [48567,48570]
===
match
---
import_name [842,856]
import_name [842,856]
===
match
---
name: start_date [75869,75879]
name: start_date [75869,75879]
===
match
---
name: add_task [75446,75454]
name: add_task [75446,75454]
===
match
---
decorated [40638,40894]
decorated [40638,40894]
===
match
---
name: orm_tag [88044,88051]
name: orm_tag [88143,88150]
===
match
---
name: self [18190,18194]
name: self [18190,18194]
===
match
---
trailer [49973,49980]
trailer [49973,49980]
===
match
---
name: self [97244,97248]
name: self [97343,97347]
===
match
---
string: 'is_picklable' [74026,74040]
string: 'is_picklable' [74026,74040]
===
match
---
simple_stmt [76738,76774]
simple_stmt [76738,76774]
===
match
---
operator: < [18157,18158]
operator: < [18157,18158]
===
match
---
name: default_args [14072,14084]
name: default_args [14072,14084]
===
match
---
operator: = [48554,48555]
operator: = [48554,48555]
===
match
---
operator: = [20330,20331]
operator: = [20330,20331]
===
match
---
trailer [14295,14308]
trailer [14295,14308]
===
match
---
argument [83332,83343]
argument [83431,83442]
===
match
---
trailer [72687,72706]
trailer [72687,72706]
===
match
---
param [25383,25388]
param [25383,25388]
===
match
---
name: recursion_depth [52296,52311]
name: recursion_depth [52296,52311]
===
match
---
operator: = [62521,62522]
operator: = [62521,62522]
===
match
---
name: include_externally_triggered [99652,99680]
name: include_externally_triggered [99751,99779]
===
match
---
expr_stmt [71244,71395]
expr_stmt [71244,71395]
===
match
---
trailer [96121,96133]
trailer [96220,96232]
===
match
---
trailer [27238,27257]
trailer [27238,27257]
===
match
---
expr_stmt [53482,53699]
expr_stmt [53482,53699]
===
match
---
trailer [95223,95236]
trailer [95322,95335]
===
match
---
name: filter_for_tis [55476,55490]
name: filter_for_tis [55476,55490]
===
match
---
name: end_date [76206,76214]
name: end_date [76206,76214]
===
match
---
name: exclude_task_ids [65588,65604]
name: exclude_task_ids [65588,65604]
===
match
---
atom_expr [28946,28973]
atom_expr [28946,28973]
===
match
---
simple_stmt [12841,12889]
simple_stmt [12841,12889]
===
match
---
name: self [31833,31837]
name: self [31833,31837]
===
match
---
trailer [20824,20876]
trailer [20824,20876]
===
match
---
name: MANUAL [44441,44447]
name: MANUAL [44441,44447]
===
match
---
operator: , [10442,10443]
operator: , [10442,10443]
===
match
---
comparison [71843,71873]
comparison [71843,71873]
===
match
---
name: start_date [24155,24165]
name: start_date [24155,24165]
===
match
---
trailer [28963,28973]
trailer [28963,28973]
===
match
---
name: perm [19806,19810]
name: perm [19806,19810]
===
match
---
name: str [11763,11766]
name: str [11763,11766]
===
match
---
atom_expr [39689,39772]
atom_expr [39689,39772]
===
match
---
annassign [15927,15947]
annassign [15927,15947]
===
match
---
operator: == [100148,100150]
operator: == [100247,100249]
===
match
---
name: task_group [12471,12481]
name: task_group [12471,12481]
===
match
---
param [94400,94404]
param [94499,94503]
===
match
---
operator: , [20517,20518]
operator: , [20517,20518]
===
match
---
tfpdef [46778,46830]
tfpdef [46778,46830]
===
match
---
name: List [99796,99800]
name: List [99895,99899]
===
match
---
atom_expr [76577,76608]
atom_expr [76577,76608]
===
match
---
name: state [57305,57310]
name: state [57305,57310]
===
match
---
trailer [53876,53891]
trailer [53876,53891]
===
match
---
name: include_subdag_tasks [60913,60933]
name: include_subdag_tasks [60913,60933]
===
match
---
name: commit [57331,57337]
name: commit [57331,57337]
===
match
---
name: DagCode [88474,88481]
name: DagCode [88573,88580]
===
match
---
atom_expr [60584,60602]
atom_expr [60584,60602]
===
match
---
name: self [15227,15231]
name: self [15227,15231]
===
match
---
decorators [101923,101957]
decorators [102022,102056]
===
match
---
name: _time_restriction [23581,23598]
name: _time_restriction [23581,23598]
===
match
---
name: collections [930,941]
name: collections [930,941]
===
match
---
trailer [74534,74566]
trailer [74534,74566]
===
match
---
name: include_dependent_dags [50723,50745]
name: include_dependent_dags [50723,50745]
===
match
---
trailer [13556,13574]
trailer [13556,13574]
===
match
---
operator: = [53291,53292]
operator: = [53291,53292]
===
match
---
atom_expr [87984,88007]
atom_expr [88083,88106]
===
match
---
name: LocalExecutor [79367,79380]
name: LocalExecutor [79367,79380]
===
match
---
name: DagModel [34972,34980]
name: DagModel [34972,34980]
===
match
---
trailer [104962,104978]
trailer [105061,105077]
===
match
---
trailer [33052,33057]
trailer [33052,33057]
===
match
---
trailer [38684,38690]
trailer [38684,38690]
===
match
---
operator: == [41765,41767]
operator: == [41765,41767]
===
match
---
trailer [100236,100238]
trailer [100335,100337]
===
match
---
name: task [41750,41754]
name: task [41750,41754]
===
match
---
name: include_downstream [50319,50337]
name: include_downstream [50319,50337]
===
match
---
simple_stmt [35785,35942]
simple_stmt [35785,35942]
===
match
---
operator: = [65894,65895]
operator: = [65894,65895]
===
match
---
operator: } [37556,37557]
operator: } [37556,37557]
===
match
---
name: jinja_environment_kwargs [17462,17486]
name: jinja_environment_kwargs [17462,17486]
===
match
---
argument [86698,86720]
argument [86797,86819]
===
match
---
trailer [89956,89958]
trailer [90055,90057]
===
match
---
param [103044,103060]
param [103143,103159]
===
match
---
trailer [61774,61781]
trailer [61774,61781]
===
match
---
operator: , [84048,84049]
operator: , [84147,84148]
===
match
---
trailer [76757,76765]
trailer [76757,76765]
===
match
---
name: property [58500,58508]
name: property [58500,58508]
===
match
---
atom_expr [35304,35322]
atom_expr [35304,35322]
===
match
---
operator: , [104020,104021]
operator: , [104119,104120]
===
match
---
suite [15011,15115]
suite [15011,15115]
===
match
---
name: active_dag_ids [89426,89440]
name: active_dag_ids [89525,89539]
===
match
---
name: qry [34332,34335]
name: qry [34332,34335]
===
match
---
name: relationship [108022,108034]
name: relationship [108121,108133]
===
match
---
simple_stmt [3177,3234]
simple_stmt [3177,3234]
===
match
---
argument [79933,79942]
argument [79933,79942]
===
match
---
operator: = [73466,73467]
operator: = [73466,73467]
===
match
---
dotted_name [12457,12481]
dotted_name [12457,12481]
===
match
---
name: end_date [49006,49014]
name: end_date [49006,49014]
===
match
---
name: tasks [32346,32351]
name: tasks [32346,32351]
===
match
---
name: user_defined_filters [68758,68778]
name: user_defined_filters [68758,68778]
===
match
---
trailer [3888,3909]
trailer [3888,3909]
===
match
---
name: SerializedDagModel [107972,107990]
name: SerializedDagModel [108071,108089]
===
match
---
operator: + [71371,71372]
operator: + [71371,71372]
===
match
---
name: signature [105976,105985]
name: signature [106075,106084]
===
match
---
operator: = [67198,67199]
operator: = [67198,67199]
===
match
---
name: classmethod [102998,103009]
name: classmethod [103097,103108]
===
match
---
atom_expr [48467,48477]
atom_expr [48467,48477]
===
match
---
operator: @ [31682,31683]
operator: @ [31682,31683]
===
match
---
param [30250,30254]
param [30250,30254]
===
match
---
raise_stmt [15974,16146]
raise_stmt [15974,16146]
===
match
---
string: "Creating DagRun needs either `run_id` or both `run_type` and `execution_date`" [82791,82870]
string: "Creating DagRun needs either `run_id` or both `run_type` and `execution_date`" [82890,82969]
===
match
---
fstring_end: " [82641,82642]
fstring_end: " [82751,82752]
===
match
---
name: is_paused [85468,85477]
name: is_paused [85567,85576]
===
match
---
name: ACTION_CAN_EDIT [19627,19642]
name: ACTION_CAN_EDIT [19627,19642]
===
match
---
trailer [10979,10987]
trailer [10979,10987]
===
match
---
name: self [18461,18465]
name: self [18461,18465]
===
match
---
simple_stmt [84820,84853]
simple_stmt [84919,84952]
===
match
---
if_stmt [98179,98597]
if_stmt [98278,98696]
===
match
---
name: join [67487,67491]
name: join [67487,67491]
===
match
---
param [61373,61411]
param [61373,61411]
===
match
---
trailer [83518,83522]
trailer [83617,83621]
===
match
---
trailer [34549,34727]
trailer [34549,34727]
===
match
---
trailer [72714,72733]
trailer [72714,72733]
===
match
---
comparison [86461,86490]
comparison [86560,86589]
===
match
---
operator: , [3380,3381]
operator: , [3380,3381]
===
match
---
name: dag [104959,104962]
name: dag [105058,105061]
===
match
---
trailer [33867,33891]
trailer [33867,33891]
===
match
---
atom [71302,71318]
atom [71302,71318]
===
match
---
name: stacklevel [30990,31000]
name: stacklevel [30990,31000]
===
match
---
name: DuplicateTaskIdFound [1798,1818]
name: DuplicateTaskIdFound [1798,1818]
===
match
---
operator: , [79919,79920]
operator: , [79919,79920]
===
match
---
atom_expr [105258,105268]
atom_expr [105357,105367]
===
match
---
simple_stmt [73454,73473]
simple_stmt [73454,73473]
===
match
---
trailer [103666,103846]
trailer [103765,103945]
===
match
---
arglist [76416,76444]
arglist [76416,76444]
===
match
---
trailer [75133,75139]
trailer [75133,75139]
===
match
---
trailer [70440,70449]
trailer [70440,70449]
===
match
---
trailer [73457,73465]
trailer [73457,73465]
===
match
---
atom [90400,90551]
atom [90499,90650]
===
match
---
name: dag_ids [61786,61793]
name: dag_ids [61786,61793]
===
match
---
name: partial_subset [57652,57666]
name: partial_subset [57652,57666]
===
match
---
name: append [101699,101705]
name: append [101798,101804]
===
match
---
argument [10980,10986]
argument [10980,10986]
===
match
---
operator: , [105509,105510]
operator: , [105608,105609]
===
match
---
name: self [29288,29292]
name: self [29288,29292]
===
match
---
atom_expr [29881,30015]
atom_expr [29881,30015]
===
match
---
import_from [1032,1231]
import_from [1032,1231]
===
match
---
trailer [101066,101074]
trailer [101165,101173]
===
match
---
atom_expr [97287,97313]
atom_expr [97386,97412]
===
match
---
argument [67492,67515]
argument [67492,67515]
===
match
---
name: dag_bag [46669,46676]
name: dag_bag [46669,46676]
===
match
---
operator: = [47542,47543]
operator: = [47542,47543]
===
match
---
atom_expr [39732,39753]
atom_expr [39732,39753]
===
match
---
argument [32931,32943]
argument [32931,32943]
===
match
---
atom_expr [35266,35277]
atom_expr [35266,35277]
===
match
---
name: ForeignKey [1401,1411]
name: ForeignKey [1401,1411]
===
match
---
or_test [49006,49050]
or_test [49006,49050]
===
match
---
name: sorted [86681,86687]
name: sorted [86780,86786]
===
match
---
name: active_dates [38073,38085]
name: active_dates [38073,38085]
===
match
---
operator: , [67026,67027]
operator: , [67026,67027]
===
match
---
name: warn [19912,19916]
name: warn [19912,19916]
===
match
---
string: "DAG %s is at (or above) max_active_runs (%d of %d), not creating any more runs" [105160,105240]
string: "DAG %s is at (or above) max_active_runs (%d of %d), not creating any more runs" [105259,105339]
===
match
---
name: debug [74302,74307]
name: debug [74302,74307]
===
match
---
name: TaskGroup [3294,3303]
name: TaskGroup [3294,3303]
===
match
---
dotted_name [1603,1620]
dotted_name [1603,1620]
===
match
---
name: kwargs [106865,106871]
name: kwargs [106964,106970]
===
match
---
operator: -> [98834,98836]
operator: -> [98933,98935]
===
match
---
operator: = [95215,95216]
operator: = [95314,95315]
===
match
---
name: session [39987,39994]
name: session [39987,39994]
===
match
---
name: only_failed [67870,67881]
name: only_failed [67870,67881]
===
match
---
name: session [99240,99247]
name: session [99339,99346]
===
match
---
name: include_parentdag [67093,67110]
name: include_parentdag [67093,67110]
===
match
---
testlist_comp [70572,70637]
testlist_comp [70572,70637]
===
match
---
name: conf [11507,11511]
name: conf [11507,11511]
===
match
---
trailer [87196,87204]
trailer [87295,87303]
===
match
---
trailer [90421,90427]
trailer [90520,90526]
===
match
---
name: self [98784,98788]
name: self [98883,98887]
===
match
---
comparison [18086,18099]
comparison [18086,18099]
===
match
---
name: update [54825,54831]
name: update [54825,54831]
===
match
---
name: int [30783,30786]
name: int [30783,30786]
===
match
---
atom_expr [72297,72328]
atom_expr [72297,72328]
===
match
---
string: """Return nodes with no children. These are last to execute and are called leaves or leaf nodes.""" [58561,58660]
string: """Return nodes with no children. These are last to execute and are called leaves or leaf nodes.""" [58561,58660]
===
match
---
name: __name__ [25252,25260]
name: __name__ [25252,25260]
===
match
---
string: "dag.callback_exceptions" [37748,37773]
string: "dag.callback_exceptions" [37748,37773]
===
match
---
name: is_paused_upon_creation [12237,12260]
name: is_paused_upon_creation [12237,12260]
===
match
---
trailer [21957,21967]
trailer [21957,21967]
===
match
---
decorated [38147,38947]
decorated [38147,38947]
===
match
---
operator: , [46306,46307]
operator: , [46306,46307]
===
match
---
suite [58552,58734]
suite [58552,58734]
===
match
---
name: get [19802,19805]
name: get [19802,19805]
===
match
---
simple_stmt [2290,2322]
simple_stmt [2290,2322]
===
match
---
name: include_parentdag [50655,50672]
name: include_parentdag [50655,50672]
===
match
---
name: matched_tasks [70783,70796]
name: matched_tasks [70783,70796]
===
match
---
atom_expr [71932,71960]
atom_expr [71932,71960]
===
match
---
name: DAGS_FOLDER [33256,33267]
name: DAGS_FOLDER [33256,33267]
===
match
---
parameters [31194,31200]
parameters [31194,31200]
===
match
---
name: _access_control [31425,31440]
name: _access_control [31425,31440]
===
match
---
operator: = [68450,68451]
operator: = [68450,68451]
===
match
---
name: Optional [12262,12270]
name: Optional [12262,12270]
===
match
---
name: state [62007,62012]
name: state [62007,62012]
===
match
---
name: r [98409,98410]
name: r [98508,98509]
===
match
---
operator: , [43762,43763]
operator: , [43762,43763]
===
match
---
decorated [30127,30213]
decorated [30127,30213]
===
match
---
trailer [57038,57047]
trailer [57038,57047]
===
match
---
string: " Please use `DAG.iter_dagrun_infos_between(..., align=False)` instead." [20565,20637]
string: " Please use `DAG.iter_dagrun_infos_between(..., align=False)` instead." [20565,20637]
===
match
---
parameters [38987,39135]
parameters [38987,39135]
===
match
---
trailer [100775,100782]
trailer [100874,100881]
===
match
---
name: value [31308,31313]
name: value [31308,31313]
===
match
---
trailer [24273,24290]
trailer [24273,24290]
===
match
---
decorator [45602,45612]
decorator [45602,45612]
===
match
---
name: subdag [59232,59238]
name: subdag [59232,59238]
===
match
---
name: list [32629,32633]
name: list [32629,32633]
===
match
---
funcdef [31174,31247]
funcdef [31174,31247]
===
match
---
name: self [48365,48369]
name: self [48365,48369]
===
match
---
name: f_kwargs [107256,107264]
name: f_kwargs [107355,107363]
===
match
---
trailer [60544,60551]
trailer [60544,60551]
===
match
---
name: self [32634,32638]
name: self [32634,32638]
===
match
---
operator: - [44962,44963]
operator: - [44962,44963]
===
match
---
name: category [20834,20842]
name: category [20834,20842]
===
match
---
trailer [95299,95312]
trailer [95398,95411]
===
match
---
atom_expr [52291,52311]
atom_expr [52291,52311]
===
match
---
trailer [43628,43663]
trailer [43628,43663]
===
match
---
suite [35776,36337]
suite [35776,36337]
===
match
---
trailer [19541,19557]
trailer [19541,19557]
===
match
---
trailer [40380,40386]
trailer [40380,40386]
===
match
---
simple_stmt [89881,89903]
simple_stmt [89980,90002]
===
match
---
atom_expr [92171,92213]
atom_expr [92270,92312]
===
match
---
fstring_string: , but get  [16394,16404]
fstring_string: , but get  [16394,16404]
===
match
---
return_stmt [84126,84168]
return_stmt [84225,84267]
===
match
---
operator: @ [99322,99323]
operator: @ [99421,99422]
===
match
---
name: str [11170,11173]
name: str [11170,11173]
===
match
---
param [46967,46976]
param [46967,46976]
===
match
---
trailer [86799,86807]
trailer [86898,86906]
===
match
---
name: setattr [68609,68616]
name: setattr [68609,68616]
===
match
---
atom_expr [14181,14212]
atom_expr [14181,14212]
===
match
---
name: logical_date [20682,20694]
name: logical_date [20682,20694]
===
match
---
trailer [87380,87393]
trailer [87479,87492]
===
match
---
param [69382,69407]
param [69382,69407]
===
match
---
operator: ! [98502,98503]
operator: ! [98601,98602]
===
match
---
operator: = [99534,99535]
operator: = [99633,99634]
===
match
---
name: task_id [37440,37447]
name: task_id [37440,37447]
===
match
---
trailer [38598,38604]
trailer [38598,38604]
===
match
---
name: _upgrade_outdated_dag_access_control [17332,17368]
name: _upgrade_outdated_dag_access_control [17332,17368]
===
match
---
file_input [788,109339]
file_input [788,109438]
===
match
---
trailer [45792,45797]
trailer [45792,45797]
===
match
---
dotted_name [1519,1541]
dotted_name [1519,1541]
===
match
---
operator: = [97261,97262]
operator: = [97360,97361]
===
match
---
name: self [74972,74976]
name: self [74972,74976]
===
match
---
param [18884,18891]
param [18884,18891]
===
match
---
name: orm_dag [87578,87585]
name: orm_dag [87677,87684]
===
match
---
operator: = [57224,57225]
operator: = [57224,57225]
===
match
---
operator: , [103042,103043]
operator: , [103141,103142]
===
match
---
operator: , [62375,62376]
operator: , [62375,62376]
===
match
---
simple_stmt [24969,24992]
simple_stmt [24969,24992]
===
match
---
name: airflow [2936,2943]
name: airflow [2936,2943]
===
match
---
simple_stmt [48181,48215]
simple_stmt [48181,48215]
===
match
---
argument [79745,79762]
argument [79745,79762]
===
match
---
suite [24956,24992]
suite [24956,24992]
===
match
---
name: as_pk_tuple [51350,51361]
name: as_pk_tuple [51350,51361]
===
match
---
trailer [35483,35651]
trailer [35483,35651]
===
match
---
trailer [76054,76088]
trailer [76054,76088]
===
match
---
testlist_comp [64895,64930]
testlist_comp [64895,64930]
===
match
---
name: self [31620,31624]
name: self [31620,31624]
===
match
---
atom_expr [86461,86473]
atom_expr [86560,86572]
===
match
---
operator: @ [89377,89378]
operator: @ [89476,89477]
===
match
---
funcdef [17674,17733]
funcdef [17674,17733]
===
match
---
trailer [92097,92101]
trailer [92196,92200]
===
match
---
atom_expr [101108,101146]
atom_expr [101207,101245]
===
match
---
trailer [38649,38656]
trailer [38649,38656]
===
match
---
name: max_active_tasks [87526,87542]
name: max_active_tasks [87625,87641]
===
match
---
for_stmt [70774,71093]
for_stmt [70774,71093]
===
match
---
name: commit [101909,101915]
name: commit [102008,102014]
===
match
---
sliceop [107866,107869]
sliceop [107965,107968]
===
match
---
param [31302,31307]
param [31302,31307]
===
match
---
name: is_subdag [27154,27163]
name: is_subdag [27154,27163]
===
match
---
name: visited_external_tis [46124,46144]
name: visited_external_tis [46124,46144]
===
match
---
import_from [1514,1556]
import_from [1514,1556]
===
match
---
trailer [26554,26564]
trailer [26554,26564]
===
match
---
simple_stmt [98246,98597]
simple_stmt [98345,98696]
===
match
---
simple_stmt [99233,99317]
simple_stmt [99332,99416]
===
match
---
if_stmt [15856,16147]
if_stmt [15856,16147]
===
match
---
operator: -> [32358,32360]
operator: -> [32358,32360]
===
match
---
name: schedule [21932,21940]
name: schedule [21932,21940]
===
match
---
name: ORIENTATION_PRESETS [16173,16192]
name: ORIENTATION_PRESETS [16173,16192]
===
match
---
name: dag_bag [62514,62521]
name: dag_bag [62514,62521]
===
match
---
atom_expr [95125,95155]
atom_expr [95224,95254]
===
match
---
param [55077,55080]
param [55077,55080]
===
match
---
name: base_date [44384,44393]
name: base_date [44384,44393]
===
match
---
atom_expr [45704,45722]
atom_expr [45704,45722]
===
match
---
simple_stmt [38018,38036]
simple_stmt [38018,38036]
===
match
---
name: Optional [80626,80634]
name: Optional [80626,80634]
===
match
---
trailer [40537,40552]
trailer [40537,40552]
===
match
---
trailer [44973,44977]
trailer [44973,44977]
===
match
---
sync_comp_for [91790,91805]
sync_comp_for [91889,91904]
===
match
---
number: 2 [31001,31002]
number: 2 [31001,31002]
===
match
---
comparison [91548,91577]
comparison [91647,91676]
===
match
---
trailer [47966,47983]
trailer [47966,47983]
===
match
---
name: partial_subset [50170,50184]
name: partial_subset [50170,50184]
===
match
---
name: states [91955,91961]
name: states [92054,92060]
===
match
---
simple_stmt [43582,43664]
simple_stmt [43582,43664]
===
match
---
trailer [42719,42750]
trailer [42719,42750]
===
match
---
simple_stmt [108879,108910]
simple_stmt [108978,109009]
===
match
---
trailer [17279,17286]
trailer [17279,17286]
===
match
---
number: 2000 [95911,95915]
number: 2000 [96010,96014]
===
match
---
trailer [73057,73079]
trailer [73057,73079]
===
match
---
name: DagRunState [66707,66718]
name: DagRunState [66707,66718]
===
match
---
name: self [40872,40876]
name: self [40872,40876]
===
match
---
name: next_dagrun [96485,96496]
name: next_dagrun [96584,96595]
===
match
---
simple_stmt [3959,4023]
simple_stmt [3959,4023]
===
match
---
trailer [72046,72054]
trailer [72046,72054]
===
match
---
name: cls [93300,93303]
name: cls [93399,93402]
===
match
---
atom_expr [73247,73301]
atom_expr [73247,73301]
===
match
---
operator: = [46108,46109]
operator: = [46108,46109]
===
match
---
funcdef [34389,34774]
funcdef [34389,34774]
===
match
---
trailer [24154,24165]
trailer [24154,24165]
===
match
---
trailer [21450,21459]
trailer [21450,21459]
===
match
---
suite [93890,94128]
suite [93989,94227]
===
match
---
operator: @ [83762,83763]
operator: @ [83861,83862]
===
match
---
name: self [36383,36387]
name: self [36383,36387]
===
match
---
operator: -> [33042,33044]
operator: -> [33042,33044]
===
match
---
name: as_pk_tuple [45451,45462]
name: as_pk_tuple [45451,45462]
===
match
---
name: dag_args [105501,105509]
name: dag_args [105600,105608]
===
match
---
name: task_ids_or_regex [50202,50219]
name: task_ids_or_regex [50202,50219]
===
match
---
name: do_it [67337,67342]
name: do_it [67337,67342]
===
match
---
operator: == [24945,24947]
operator: == [24945,24947]
===
match
---
name: end_date [45224,45232]
name: end_date [45224,45232]
===
match
---
name: staticmethod [89965,89977]
name: staticmethod [90064,90076]
===
match
---
operator: , [57780,57781]
operator: , [57780,57781]
===
match
---
suite [38760,38916]
suite [38760,38916]
===
match
---
name: dags [84806,84810]
name: dags [84905,84909]
===
match
---
name: str [15929,15932]
name: str [15929,15932]
===
match
---
name: dag_model [102877,102886]
name: dag_model [102976,102985]
===
match
---
name: c [18345,18346]
name: c [18345,18346]
===
match
---
atom_expr [53309,53319]
atom_expr [53309,53319]
===
match
---
name: default_args [14296,14308]
name: default_args [14296,14308]
===
match
---
simple_stmt [24014,24026]
simple_stmt [24014,24026]
===
match
---
atom_expr [42720,42749]
atom_expr [42720,42749]
===
match
---
suite [107329,107394]
suite [107428,107493]
===
match
---
operator: , [29230,29231]
operator: , [29230,29231]
===
match
---
suite [99224,99317]
suite [99323,99416]
===
match
---
expr_stmt [49064,49104]
expr_stmt [49064,49104]
===
match
---
trailer [33183,33197]
trailer [33183,33197]
===
match
---
simple_stmt [80246,80264]
simple_stmt [80246,80264]
===
match
---
expr_stmt [68787,68814]
expr_stmt [68787,68814]
===
match
---
atom_expr [101751,101892]
atom_expr [101850,101991]
===
match
---
name: end_date [62158,62166]
name: end_date [62158,62166]
===
match
---
operator: , [58030,58031]
operator: , [58030,58031]
===
match
---
simple_stmt [27908,27919]
simple_stmt [27908,27919]
===
match
---
operator: = [50497,50498]
operator: = [50497,50498]
===
match
---
fstring [82581,82642]
fstring [82691,82752]
===
match
---
operator: , [103719,103720]
operator: , [103818,103819]
===
match
---
atom_expr [71843,71856]
atom_expr [71843,71856]
===
match
---
name: concurrency [97371,97382]
name: concurrency [97470,97481]
===
match
---
simple_stmt [104636,104725]
simple_stmt [104735,104824]
===
match
---
name: timezone [45011,45019]
name: timezone [45011,45019]
===
match
---
name: DagModel [74535,74543]
name: DagModel [74535,74543]
===
match
---
name: external_dag_id [52945,52960]
name: external_dag_id [52945,52960]
===
match
---
atom_expr [20946,21098]
atom_expr [20946,21098]
===
match
---
trailer [14234,14247]
trailer [14234,14247]
===
match
---
atom_expr [86070,86090]
atom_expr [86169,86189]
===
match
---
param [77279,77295]
param [77279,77295]
===
match
---
name: upstream_group_ids [72715,72733]
name: upstream_group_ids [72715,72733]
===
match
---
name: orm_dag [87518,87525]
name: orm_dag [87617,87624]
===
match
---
name: DagRunType [86006,86016]
name: DagRunType [86105,86115]
===
match
---
name: task_id [53571,53578]
name: task_id [53571,53578]
===
match
---
operator: -> [35113,35115]
operator: -> [35113,35115]
===
match
---
expr_stmt [27200,27257]
expr_stmt [27200,27257]
===
match
---
simple_stmt [36207,36233]
simple_stmt [36207,36233]
===
match
---
name: List [58533,58537]
name: List [58533,58537]
===
match
---
atom_expr [24478,24488]
atom_expr [24478,24488]
===
match
---
fstring_string: A cyclic dependency occurred in dag:  [61143,61180]
fstring_string: A cyclic dependency occurred in dag:  [61143,61180]
===
match
---
param [90946,90958]
param [91045,91057]
===
match
---
name: DagRun [39634,39640]
name: DagRun [39634,39640]
===
match
---
simple_stmt [67308,67329]
simple_stmt [67308,67329]
===
match
---
name: self [38997,39001]
name: self [38997,39001]
===
match
---
trailer [35685,35687]
trailer [35685,35687]
===
match
---
name: render_templates [52831,52847]
name: render_templates [52831,52847]
===
match
---
trailer [71848,71856]
trailer [71848,71856]
===
match
---
simple_stmt [2060,2107]
simple_stmt [2060,2107]
===
match
---
name: self [58287,58291]
name: self [58287,58291]
===
match
---
string: """         Returns a boolean indicating whether the max_active_tasks limit for this DAG         has been reached         """ [34018,34143]
string: """         Returns a boolean indicating whether the max_active_tasks limit for this DAG         has been reached         """ [34018,34143]
===
match
---
atom_expr [48099,48154]
atom_expr [48099,48154]
===
match
---
atom [93790,93792]
atom [93889,93891]
===
match
---
name: self [83132,83136]
name: self [83231,83235]
===
match
---
name: task_ids [45154,45162]
name: task_ids [45154,45162]
===
match
---
atom_expr [98637,98673]
atom_expr [98736,98772]
===
match
---
operator: = [80560,80561]
operator: = [80560,80561]
===
match
---
trailer [45551,45566]
trailer [45551,45566]
===
match
---
name: run [77252,77255]
name: run [77252,77255]
===
match
---
name: self [30080,30084]
name: self [30080,30084]
===
match
---
name: order_by [44476,44484]
name: order_by [44476,44484]
===
match
---
operator: = [79403,79404]
operator: = [79403,79404]
===
match
---
trailer [23684,23703]
trailer [23684,23703]
===
match
---
name: other [18059,18064]
name: other [18059,18064]
===
match
---
trailer [49613,49619]
trailer [49613,49619]
===
match
---
name: UtcDateTime [95224,95235]
name: UtcDateTime [95323,95334]
===
match
---
name: TaskNotFound [1820,1832]
name: TaskNotFound [1820,1832]
===
match
---
atom_expr [86354,86369]
atom_expr [86453,86468]
===
match
---
comp_op [85431,85437]
comp_op [85530,85536]
===
match
---
name: airflow [51254,51261]
name: airflow [51254,51261]
===
match
---
simple_stmt [95010,95053]
simple_stmt [95109,95152]
===
match
---
operator: , [11525,11526]
operator: , [11525,11526]
===
match
---
name: dag [86914,86917]
name: dag [87013,87016]
===
match
---
decorator [98020,98030]
decorator [98119,98129]
===
match
---
parameters [31491,31504]
parameters [31491,31504]
===
match
---
name: earliest [29051,29059]
name: earliest [29051,29059]
===
match
---
trailer [44440,44447]
trailer [44440,44447]
===
match
---
param [62536,62585]
param [62536,62585]
===
match
---
and_test [14529,14594]
and_test [14529,14594]
===
match
---
name: self [76004,76008]
name: self [76004,76008]
===
match
---
atom_expr [11847,11887]
atom_expr [11847,11887]
===
match
---
expr_stmt [96631,96682]
expr_stmt [96730,96781]
===
match
---
atom_expr [45777,45798]
atom_expr [45777,45798]
===
match
---
atom_expr [75185,75205]
atom_expr [75185,75205]
===
match
---
atom_expr [85987,86002]
atom_expr [86086,86101]
===
match
---
suite [18897,18943]
suite [18897,18943]
===
match
---
import_from [107930,107990]
import_from [108029,108089]
===
match
---
parameters [101988,102038]
parameters [102087,102137]
===
match
---
trailer [67319,67328]
trailer [67319,67328]
===
match
---
simple_stmt [27485,27529]
simple_stmt [27485,27529]
===
match
---
atom_expr [86741,86767]
atom_expr [86840,86866]
===
match
---
name: self [93816,93820]
name: self [93915,93919]
===
match
---
simple_stmt [66337,66378]
simple_stmt [66337,66378]
===
match
---
operator: , [64907,64908]
operator: , [64907,64908]
===
match
---
suite [50133,51123]
suite [50133,51123]
===
match
---
operator: ... [46226,46229]
operator: ... [46226,46229]
===
match
---
argument [58196,58222]
argument [58196,58222]
===
match
---
name: dag_id [99381,99387]
name: dag_id [99480,99486]
===
match
---
trailer [54946,54950]
trailer [54946,54950]
===
match
---
param [43801,43818]
param [43801,43818]
===
match
---
name: _max_active_tasks [31129,31146]
name: _max_active_tasks [31129,31146]
===
match
---
name: self [29647,29651]
name: self [29647,29651]
===
match
---
atom [89072,89078]
atom [89171,89177]
===
match
---
name: not_none_state [49681,49695]
name: not_none_state [49681,49695]
===
match
---
operator: , [31968,31969]
operator: , [31968,31969]
===
match
---
name: self [20723,20727]
name: self [20723,20727]
===
match
---
name: calculate_dagrun_date_fields [104063,104091]
name: calculate_dagrun_date_fields [104162,104190]
===
match
---
name: __init__ [105990,105998]
name: __init__ [106089,106097]
===
match
---
expr_stmt [15478,15522]
expr_stmt [15478,15522]
===
match
---
operator: , [23833,23834]
operator: , [23833,23834]
===
match
---
name: filter [39818,39824]
name: filter [39818,39824]
===
match
---
simple_stmt [101229,101241]
simple_stmt [101328,101340]
===
match
---
name: globals [107840,107847]
name: globals [107939,107946]
===
match
---
operator: = [57255,57256]
operator: = [57255,57256]
===
match
---
name: self [37656,37660]
name: self [37656,37660]
===
match
---
name: recursion_depth [47333,47348]
name: recursion_depth [47333,47348]
===
match
---
return_stmt [31022,31051]
return_stmt [31022,31051]
===
match
---
operator: , [92737,92738]
operator: , [92836,92837]
===
match
---
param [80614,80652]
param [80614,80652]
===
match
---
suite [102522,102992]
suite [102621,103091]
===
match
---
operator: , [90742,90743]
operator: , [90841,90842]
===
match
---
trailer [48194,48200]
trailer [48194,48200]
===
match
---
argument [65197,65214]
argument [65197,65214]
===
match
---
return_stmt [67424,67432]
return_stmt [67424,67432]
===
match
---
trailer [11461,11466]
trailer [11461,11466]
===
match
---
trailer [12072,12096]
trailer [12072,12096]
===
match
---
name: provide_session [83763,83778]
name: provide_session [83862,83877]
===
match
---
import_from [3038,3125]
import_from [3038,3125]
===
match
---
name: other [18159,18164]
name: other [18159,18164]
===
match
---
trailer [53451,53458]
trailer [53451,53458]
===
match
---
trailer [12922,12932]
trailer [12922,12932]
===
match
---
return_stmt [21219,21230]
return_stmt [21219,21230]
===
match
---
trailer [74133,74139]
trailer [74133,74139]
===
match
---
param [100847,100851]
param [100946,100950]
===
match
---
trailer [28954,28963]
trailer [28954,28963]
===
match
---
name: cron_presets [36070,36082]
name: cron_presets [36070,36082]
===
match
---
for_stmt [41575,41951]
for_stmt [41575,41951]
===
match
---
name: task_id [57699,57706]
name: task_id [57699,57706]
===
match
---
name: task_count [76966,76976]
name: task_count [76966,76976]
===
match
---
argument [51409,51453]
argument [51409,51453]
===
match
---
expr_stmt [68435,68458]
expr_stmt [68435,68458]
===
match
---
trailer [57627,57629]
trailer [57627,57629]
===
match
---
name: State [37994,37999]
name: State [37994,37999]
===
match
---
parameters [100748,100754]
parameters [100847,100853]
===
match
---
name: task_id [48127,48134]
name: task_id [48127,48134]
===
match
---
operator: , [68623,68624]
operator: , [68623,68624]
===
match
---
name: subdags [48370,48377]
name: subdags [48370,48377]
===
match
---
string: '_log' [68584,68590]
string: '_log' [68584,68590]
===
match
---
return_stmt [109307,109338]
return_stmt [109406,109437]
===
match
---
trailer [30113,30121]
trailer [30113,30121]
===
match
---
return_stmt [45091,45596]
return_stmt [45091,45596]
===
match
---
simple_stmt [37461,37512]
simple_stmt [37461,37512]
===
match
---
simple_stmt [17122,17190]
simple_stmt [17122,17190]
===
match
---
trailer [60829,60843]
trailer [60829,60843]
===
match
---
atom_expr [25407,25434]
atom_expr [25407,25434]
===
match
---
name: upstream_list [71079,71092]
name: upstream_list [71079,71092]
===
match
---
name: UtcDateTime [96788,96799]
name: UtcDateTime [96887,96898]
===
match
---
tfpdef [47408,47460]
tfpdef [47408,47460]
===
match
---
atom_expr [102461,102485]
atom_expr [102560,102584]
===
match
---
name: session [83703,83710]
name: session [83802,83809]
===
match
---
dictorsetmaker [101823,101852]
dictorsetmaker [101922,101951]
===
match
---
trailer [31811,31816]
trailer [31811,31816]
===
match
---
operator: + [54439,54440]
operator: + [54439,54440]
===
match
---
operator: >= [48785,48787]
operator: >= [48785,48787]
===
match
---
trailer [86338,86370]
trailer [86437,86469]
===
match
---
trailer [103717,103719]
trailer [103816,103818]
===
match
---
atom_expr [31514,31534]
atom_expr [31514,31534]
===
match
---
trailer [61714,61721]
trailer [61714,61721]
===
match
---
trailer [23469,23479]
trailer [23469,23479]
===
match
---
operator: = [104844,104845]
operator: = [104943,104944]
===
match
---
name: task [76661,76665]
name: task [76661,76665]
===
match
---
simple_stmt [61922,61978]
simple_stmt [61922,61978]
===
match
---
simple_stmt [47955,47992]
simple_stmt [47955,47992]
===
match
---
atom_expr [61710,61721]
atom_expr [61710,61721]
===
match
---
atom_expr [43284,43329]
atom_expr [43284,43329]
===
match
---
suite [42311,42363]
suite [42311,42363]
===
match
---
trailer [71935,71945]
trailer [71935,71945]
===
match
---
simple_stmt [58243,58258]
simple_stmt [58243,58258]
===
match
---
operator: , [46375,46376]
operator: , [46375,46376]
===
match
---
operator: = [66026,66027]
operator: = [66026,66027]
===
match
---
name: int [31204,31207]
name: int [31204,31207]
===
match
---
name: subdags [88739,88746]
name: subdags [88838,88845]
===
match
---
name: cls [66470,66473]
name: cls [66470,66473]
===
match
---
atom_expr [51646,51651]
atom_expr [51646,51651]
===
match
---
name: pickle_id [74616,74625]
name: pickle_id [74616,74625]
===
match
---
name: recursion_depth [52332,52347]
name: recursion_depth [52332,52347]
===
match
---
name: timezone [23510,23518]
name: timezone [23510,23518]
===
match
---
name: self [31420,31424]
name: self [31420,31424]
===
match
---
string: 'start_date' [14248,14260]
string: 'start_date' [14248,14260]
===
match
---
operator: = [65840,65841]
operator: = [65840,65841]
===
match
---
name: partial_subset [69275,69289]
name: partial_subset [69275,69289]
===
match
---
argument [50602,50633]
argument [50602,50633]
===
match
---
return_stmt [35287,35323]
return_stmt [35287,35323]
===
match
---
tfpdef [11483,11504]
tfpdef [11483,11504]
===
match
---
string: """         Returns the number of active "running" dag runs          :param external_trigger: True for externally triggered active dag runs         :type external_trigger: bool         :param session:         :return: number greater than 0 for active dag runs         """ [38244,38515]
string: """         Returns the number of active "running" dag runs          :param external_trigger: True for externally triggered active dag runs         :type external_trigger: bool         :param session:         :return: number greater than 0 for active dag runs         """ [38244,38515]
===
match
---
operator: = [45303,45304]
operator: = [45303,45304]
===
match
---
name: state [91965,91970]
name: state [92064,92069]
===
match
---
string: 'cache_size' [42614,42626]
string: 'cache_size' [42614,42626]
===
match
---
name: dp [74928,74930]
name: dp [74928,74930]
===
match
---
name: dag_id [29652,29658]
name: dag_id [29652,29658]
===
match
---
param [47408,47468]
param [47408,47468]
===
match
---
operator: { [57698,57699]
operator: { [57698,57699]
===
match
---
name: helpers [2903,2910]
name: helpers [2903,2910]
===
match
---
name: also_include [70849,70861]
name: also_include [70849,70861]
===
match
---
trailer [30842,30847]
trailer [30842,30847]
===
match
---
name: DeprecationWarning [69158,69176]
name: DeprecationWarning [69158,69176]
===
match
---
operator: , [105458,105459]
operator: , [105557,105558]
===
match
---
trailer [32836,32841]
trailer [32836,32841]
===
match
---
name: only_running [67916,67928]
name: only_running [67916,67928]
===
match
---
trailer [49619,49623]
trailer [49619,49623]
===
match
---
trailer [66013,66020]
trailer [66013,66020]
===
match
---
decorated [83745,84169]
decorated [83844,84268]
===
match
---
name: task_group [72587,72597]
name: task_group [72587,72597]
===
match
---
tfpdef [80576,80597]
tfpdef [80576,80597]
===
match
---
name: end_date [61420,61428]
name: end_date [61420,61428]
===
match
---
atom_expr [55410,55427]
atom_expr [55410,55427]
===
match
---
name: group [72786,72791]
name: group [72786,72791]
===
match
---
name: tis [55543,55546]
name: tis [55543,55546]
===
match
---
expr_stmt [65885,66050]
expr_stmt [65885,66050]
===
match
---
arglist [53309,53336]
arglist [53309,53336]
===
match
---
operator: , [77434,77435]
operator: , [77434,77435]
===
match
---
name: Optional [13619,13627]
name: Optional [13619,13627]
===
match
---
operator: , [3096,3097]
operator: , [3096,3097]
===
match
---
operator: , [67881,67882]
operator: , [67881,67882]
===
match
---
trailer [72956,72978]
trailer [72956,72978]
===
match
---
atom_expr [106710,106744]
atom_expr [106809,106843]
===
match
---
funcdef [31281,31360]
funcdef [31281,31360]
===
match
---
name: external_dag [53278,53290]
name: external_dag [53278,53290]
===
match
---
name: airflow [2993,3000]
name: airflow [2993,3000]
===
match
---
name: instance [21451,21459]
name: instance [21451,21459]
===
match
---
name: _context_managed_dag [109089,109109]
name: _context_managed_dag [109188,109208]
===
match
---
name: any [87616,87619]
name: any [87715,87718]
===
match
---
atom_expr [51947,52009]
atom_expr [51947,52009]
===
match
---
name: self [33393,33397]
name: self [33393,33397]
===
match
---
operator: , [45309,45310]
operator: , [45309,45310]
===
match
---
name: factory [107790,107797]
name: factory [107889,107896]
===
match
---
operator: , [87847,87848]
operator: , [87946,87947]
===
match
---
trailer [42081,42083]
trailer [42081,42083]
===
match
---
atom_expr [74554,74565]
atom_expr [74554,74565]
===
match
---
trailer [86827,86837]
trailer [86926,86936]
===
match
---
param [32465,32468]
param [32465,32468]
===
match
---
annassign [108670,108686]
annassign [108769,108785]
===
match
---
name: jinja_env_options [42426,42443]
name: jinja_env_options [42426,42443]
===
match
---
name: ti [51996,51998]
name: ti [51996,51998]
===
match
---
suite [102724,102949]
suite [102823,103048]
===
match
---
suite [68140,68216]
suite [68140,68216]
===
match
---
suite [80188,80430]
suite [80188,80430]
===
match
---
expr_stmt [72894,72978]
expr_stmt [72894,72978]
===
match
---
atom_expr [74804,74819]
atom_expr [74804,74819]
===
match
---
arglist [30586,30699]
arglist [30586,30699]
===
match
---
simple_stmt [93426,93560]
simple_stmt [93525,93659]
===
match
---
trailer [49374,49380]
trailer [49374,49380]
===
match
---
suite [92295,93324]
suite [92394,93423]
===
match
---
name: all_tis [67291,67298]
name: all_tis [67291,67298]
===
match
---
operator: = [64393,64394]
operator: = [64393,64394]
===
match
---
operator: = [107833,107834]
operator: = [107932,107933]
===
match
---
name: query [4027,4032]
name: query [4027,4032]
===
match
---
name: path [33164,33168]
name: path [33164,33168]
===
match
---
arglist [66174,66274]
arglist [66174,66274]
===
match
---
trailer [55562,55570]
trailer [55562,55570]
===
match
---
simple_stmt [67231,67251]
simple_stmt [67231,67251]
===
match
---
atom_expr [64441,64610]
atom_expr [64441,64610]
===
match
---
raise_stmt [82751,82884]
raise_stmt [82850,82983]
===
match
---
argument [88748,88763]
argument [88847,88862]
===
match
---
atom_expr [100771,100806]
atom_expr [100870,100905]
===
match
---
simple_stmt [94306,94382]
simple_stmt [94405,94481]
===
match
---
atom_expr [14275,14288]
atom_expr [14275,14288]
===
match
---
operator: , [12393,12394]
operator: , [12393,12394]
===
match
---
simple_stmt [25225,25261]
simple_stmt [25225,25261]
===
match
---
name: dag_id [85916,85922]
name: dag_id [86015,86021]
===
match
---
operator: @ [102997,102998]
operator: @ [103096,103097]
===
match
---
operator: , [70524,70525]
operator: , [70524,70525]
===
match
---
parameters [37799,37805]
parameters [37799,37805]
===
match
---
fstring_string: ,  [98411,98413]
fstring_string: ,  [98510,98512]
===
match
---
simple_stmt [86289,86635]
simple_stmt [86388,86734]
===
match
---
name: dag [87660,87663]
name: dag [87759,87762]
===
match
---
trailer [38096,38111]
trailer [38096,38111]
===
match
---
operator: = [96180,96181]
operator: = [96279,96280]
===
match
---
name: used_group_ids [76919,76933]
name: used_group_ids [76919,76933]
===
match
---
name: str [15353,15356]
name: str [15353,15356]
===
match
---
name: kwargs [106129,106135]
name: kwargs [106228,106234]
===
match
---
operator: , [80604,80605]
operator: , [80604,80605]
===
match
---
operator: = [32299,32300]
operator: = [32299,32300]
===
match
---
tfpdef [73628,73649]
tfpdef [73628,73649]
===
match
---
name: tis [65868,65871]
name: tis [65868,65871]
===
match
---
name: DeltaDataIntervalTimetable [25072,25098]
name: DeltaDataIntervalTimetable [25072,25098]
===
match
---
trailer [57100,57377]
trailer [57100,57377]
===
match
---
arith_expr [44944,44977]
arith_expr [44944,44977]
===
match
---
name: get_current_dag [109260,109275]
name: get_current_dag [109359,109374]
===
match
---
name: tis [49345,49348]
name: tis [49345,49348]
===
match
---
name: int [46758,46761]
name: int [46758,46761]
===
match
---
name: self [68753,68757]
name: self [68753,68757]
===
match
---
name: TaskInstance [45539,45551]
name: TaskInstance [45539,45551]
===
match
---
atom_expr [86914,86936]
atom_expr [87013,87035]
===
match
---
trailer [59547,59559]
trailer [59547,59559]
===
match
---
name: value [31943,31948]
name: value [31943,31948]
===
match
---
name: cli [80178,80181]
name: cli [80178,80181]
===
match
---
trailer [20340,20347]
trailer [20340,20347]
===
match
---
name: _get_task_instances [65164,65183]
name: _get_task_instances [65164,65183]
===
match
---
atom_expr [13649,13666]
atom_expr [13649,13666]
===
match
---
atom_expr [44254,44560]
atom_expr [44254,44560]
===
match
---
name: executor_loader [79483,79498]
name: executor_loader [79483,79498]
===
match
---
simple_stmt [102048,102332]
simple_stmt [102147,102431]
===
match
---
name: dag [73058,73061]
name: dag [73058,73061]
===
match
---
atom_expr [11453,11466]
atom_expr [11453,11466]
===
match
---
name: get_default_executor [79560,79580]
name: get_default_executor [79560,79580]
===
match
---
name: self [17275,17279]
name: self [17275,17279]
===
match
---
simple_stmt [65736,65749]
simple_stmt [65736,65749]
===
match
---
simple_stmt [85768,86191]
simple_stmt [85867,86290]
===
match
---
operator: ** [105511,105513]
operator: ** [105610,105612]
===
match
---
atom_expr [87260,87277]
atom_expr [87359,87376]
===
match
---
atom_expr [11659,11678]
atom_expr [11659,11678]
===
match
---
simple_stmt [74293,74311]
simple_stmt [74293,74311]
===
match
---
argument [20126,20138]
argument [20126,20138]
===
match
---
string: 'dag_id' [106676,106684]
string: 'dag_id' [106775,106783]
===
match
---
simple_stmt [85301,85343]
simple_stmt [85400,85442]
===
match
---
name: __repr__ [97960,97968]
name: __repr__ [98059,98067]
===
match
---
name: utils [3139,3144]
name: utils [3139,3144]
===
match
---
name: combine [45040,45047]
name: combine [45040,45047]
===
match
---
dotted_name [32432,32444]
dotted_name [32432,32444]
===
match
---
simple_stmt [17933,18016]
simple_stmt [17933,18016]
===
match
---
name: timezone [14788,14796]
name: timezone [14788,14796]
===
match
---
name: bulk_write_to_db [84137,84153]
name: bulk_write_to_db [84236,84252]
===
match
---
trailer [20959,21098]
trailer [20959,21098]
===
match
---
operator: = [96661,96662]
operator: = [96760,96761]
===
match
---
operator: , [17753,17754]
operator: , [17753,17754]
===
match
---
name: last_parsed_time [90714,90730]
name: last_parsed_time [90813,90829]
===
match
---
simple_stmt [55004,55191]
simple_stmt [55004,55191]
===
match
---
atom_expr [99445,99455]
atom_expr [99544,99554]
===
match
---
tfpdef [10922,10967]
tfpdef [10922,10967]
===
match
---
name: self [57647,57651]
name: self [57647,57651]
===
match
---
if_stmt [68823,68885]
if_stmt [68823,68885]
===
match
---
decorated [31160,31247]
decorated [31160,31247]
===
match
---
parameters [28024,28057]
parameters [28024,28057]
===
match
---
trailer [15175,15188]
trailer [15175,15188]
===
match
---
operator: , [66945,66946]
operator: , [66945,66946]
===
match
---
trailer [34954,34964]
trailer [34954,34964]
===
match
---
atom_expr [49601,49629]
atom_expr [49601,49629]
===
match
---
operator: , [80785,80786]
operator: , [80785,80786]
===
match
---
name: utils [3051,3056]
name: utils [3051,3056]
===
match
---
trailer [11169,11189]
trailer [11169,11189]
===
match
---
expr_stmt [36259,36302]
expr_stmt [36259,36302]
===
match
---
param [46302,46307]
param [46302,46307]
===
match
---
atom_expr [72641,72668]
atom_expr [72641,72668]
===
match
---
decorator [106080,106100]
decorator [106179,106199]
===
match
---
name: _get_task_instances [50407,50426]
name: _get_task_instances [50407,50426]
===
match
---
name: session [102025,102032]
name: session [102124,102131]
===
match
---
name: self [17663,17667]
name: self [17663,17667]
===
match
---
name: self [101730,101734]
name: self [101829,101833]
===
match
---
expr_stmt [96318,96368]
expr_stmt [96417,96467]
===
match
---
trailer [14760,14772]
trailer [14760,14772]
===
match
---
trailer [89732,89748]
trailer [89831,89847]
===
match
---
trailer [76581,76593]
trailer [76581,76593]
===
match
---
atom_expr [49951,49980]
atom_expr [49951,49980]
===
match
---
operator: = [71553,71554]
operator: = [71553,71554]
===
match
---
atom_expr [87045,87059]
atom_expr [87144,87158]
===
match
---
atom_expr [22206,22226]
atom_expr [22206,22226]
===
match
---
decorated [44746,45597]
decorated [44746,45597]
===
match
---
trailer [107320,107326]
trailer [107419,107425]
===
match
---
name: backref [1480,1487]
name: backref [1480,1487]
===
match
---
name: self [31659,31663]
name: self [31659,31663]
===
match
---
arglist [92038,92107]
arglist [92137,92206]
===
match
---
name: upstream_group_ids [72688,72706]
name: upstream_group_ids [72688,72706]
===
match
---
name: exceptions [1762,1772]
name: exceptions [1762,1772]
===
match
---
name: end_date [76179,76187]
name: end_date [76179,76187]
===
match
---
expr_stmt [102675,102702]
expr_stmt [102774,102801]
===
match
---
name: DagRun [86339,86345]
name: DagRun [86438,86444]
===
match
---
atom_expr [83925,84117]
atom_expr [84024,84216]
===
match
---
comparison [24501,24526]
comparison [24501,24526]
===
match
---
simple_stmt [27177,27191]
simple_stmt [27177,27191]
===
match
---
name: execution_date [57812,57826]
name: execution_date [57812,57826]
===
match
---
trailer [75189,75205]
trailer [75189,75205]
===
match
---
arglist [68617,68650]
arglist [68617,68650]
===
match
---
operator: = [67110,67111]
operator: = [67110,67111]
===
match
---
trailer [90427,90437]
trailer [90526,90536]
===
match
---
atom_expr [96404,96435]
atom_expr [96503,96534]
===
match
---
name: session [40373,40380]
name: session [40373,40380]
===
match
---
name: start_date [46985,46995]
name: start_date [46985,46995]
===
match
---
argument [92468,92481]
argument [92567,92580]
===
match
---
name: task_id [57039,57046]
name: task_id [57039,57046]
===
match
---
funcdef [46269,46904]
funcdef [46269,46904]
===
match
---
comparison [34332,34369]
comparison [34332,34369]
===
match
---
trailer [20753,20788]
trailer [20753,20788]
===
match
---
operator: = [44693,44694]
operator: = [44693,44694]
===
match
---
operator: = [85135,85136]
operator: = [85234,85235]
===
match
---
name: self [33184,33188]
name: self [33184,33188]
===
match
---
trailer [85553,85558]
trailer [85652,85657]
===
match
---
operator: = [55446,55447]
operator: = [55446,55447]
===
match
---
name: hash [18658,18662]
name: hash [18658,18662]
===
match
---
operator: * [106457,106458]
operator: * [106556,106557]
===
match
---
trailer [94426,94431]
trailer [94525,94530]
===
match
---
name: task_id [58214,58221]
name: task_id [58214,58221]
===
match
---
name: TaskInstance [49836,49848]
name: TaskInstance [49836,49848]
===
match
---
name: session [39095,39102]
name: session [39095,39102]
===
match
---
name: __init__ [97235,97243]
name: __init__ [97334,97342]
===
match
---
operator: = [13744,13745]
operator: = [13744,13745]
===
match
---
trailer [102931,102941]
trailer [103030,103040]
===
match
---
arglist [45154,45502]
arglist [45154,45502]
===
match
---
trailer [14925,14935]
trailer [14925,14935]
===
match
---
name: query [3967,3972]
name: query [3967,3972]
===
match
---
name: property [35694,35702]
name: property [35694,35702]
===
match
---
param [100384,100388]
param [100483,100487]
===
match
---
trailer [89884,89894]
trailer [89983,89993]
===
match
---
atom_expr [58694,58704]
atom_expr [58694,58704]
===
match
---
decorated [39914,40633]
decorated [39914,40633]
===
match
---
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_is_paused` method.""" [35372,35461]
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_is_paused` method.""" [35372,35461]
===
match
---
name: append [48415,48421]
name: append [48415,48421]
===
match
---
name: updated_access_control [19753,19775]
name: updated_access_control [19753,19775]
===
match
---
name: datetime [98812,98820]
name: datetime [98911,98919]
===
match
---
param [33552,33556]
param [33552,33556]
===
match
---
string: "Task is missing the start_date parameter" [75685,75727]
string: "Task is missing the start_date parameter" [75685,75727]
===
match
---
name: include_parentdag [54155,54172]
name: include_parentdag [54155,54172]
===
match
---
simple_stmt [107256,107270]
simple_stmt [107355,107369]
===
match
---
operator: = [66259,66260]
operator: = [66259,66260]
===
match
---
trailer [75420,75436]
trailer [75420,75436]
===
match
---
tfpdef [11089,11117]
tfpdef [11089,11117]
===
match
---
simple_stmt [19662,19690]
simple_stmt [19662,19690]
===
match
---
name: value [98854,98859]
name: value [98953,98958]
===
match
---
name: timezone [74081,74089]
name: timezone [74081,74089]
===
match
---
funcdef [31379,31441]
funcdef [31379,31441]
===
match
---
name: dag_id [99627,99633]
name: dag_id [99726,99732]
===
match
---
name: self [23642,23646]
name: self [23642,23646]
===
match
---
operator: { [16404,16405]
operator: { [16404,16405]
===
match
---
name: min [24363,24366]
name: min [24363,24366]
===
match
---
trailer [25460,25469]
trailer [25460,25469]
===
match
---
name: co_filename [13804,13815]
name: co_filename [13804,13815]
===
match
---
name: TaskGroup [17641,17650]
name: TaskGroup [17641,17650]
===
match
---
decorated [102997,104054]
decorated [103096,104153]
===
match
---
name: hasattr [68826,68833]
name: hasattr [68826,68833]
===
match
---
arglist [85987,86091]
arglist [86086,86190]
===
match
---
arglist [49220,49230]
arglist [49220,49230]
===
match
---
atom_expr [88660,88675]
atom_expr [88759,88774]
===
match
---
name: is_fixed_time_schedule [20908,20930]
name: is_fixed_time_schedule [20908,20930]
===
match
---
name: end_date [76222,76230]
name: end_date [76222,76230]
===
match
---
simple_stmt [57918,58234]
simple_stmt [57918,58234]
===
match
---
trailer [72312,72328]
trailer [72312,72328]
===
match
---
funcdef [30232,30480]
funcdef [30232,30480]
===
match
---
parameters [30249,30255]
parameters [30249,30255]
===
match
---
operator: , [53989,53990]
operator: , [53989,53990]
===
match
---
operator: = [37974,37975]
operator: = [37974,37975]
===
match
---
name: TaskInstance [92079,92091]
name: TaskInstance [92178,92190]
===
match
---
parameters [42109,42115]
parameters [42109,42115]
===
match
---
name: DagRun [40855,40861]
name: DagRun [40855,40861]
===
match
---
param [46985,47016]
param [46985,47016]
===
match
---
operator: = [45009,45010]
operator: = [45009,45010]
===
match
---
suite [102966,102992]
suite [103065,103091]
===
match
---
operator: = [64956,64957]
operator: = [64956,64957]
===
match
---
name: _access_control [31519,31534]
name: _access_control [31519,31534]
===
match
---
tfpdef [12293,12333]
tfpdef [12293,12333]
===
match
---
atom_expr [59548,59558]
atom_expr [59548,59558]
===
match
---
argument [65413,65451]
argument [65413,65451]
===
match
---
trailer [84890,84896]
trailer [84989,84995]
===
match
---
name: update [53727,53733]
name: update [53727,53733]
===
match
---
trailer [51981,52008]
trailer [51981,52008]
===
match
---
expr_stmt [72991,73079]
expr_stmt [72991,73079]
===
match
---
trailer [72422,72434]
trailer [72422,72434]
===
match
---
operator: , [39963,39964]
operator: , [39963,39964]
===
match
---
decorator [31682,31692]
decorator [31682,31692]
===
match
---
name: task_dict [73898,73907]
name: task_dict [73898,73907]
===
match
---
simple_stmt [91474,91589]
simple_stmt [91573,91688]
===
match
---
operator: = [106745,106746]
operator: = [106844,106845]
===
match
---
argument [67858,67881]
argument [67858,67881]
===
match
---
atom [25024,25050]
atom [25024,25050]
===
match
---
argument [61045,61070]
argument [61045,61070]
===
match
---
if_stmt [49206,49982]
if_stmt [49206,49982]
===
match
---
comparison [99445,99465]
comparison [99544,99564]
===
match
---
argument [17944,18014]
argument [17944,18014]
===
match
---
param [42110,42114]
param [42110,42114]
===
match
---
atom_expr [31537,31584]
atom_expr [31537,31584]
===
match
---
name: warnings [97400,97408]
name: warnings [97499,97507]
===
match
---
simple_stmt [3257,3304]
simple_stmt [3257,3304]
===
match
---
operator: = [70761,70762]
operator: = [70761,70762]
===
match
---
trailer [12859,12888]
trailer [12859,12888]
===
match
---
name: max_recursion_depth [54492,54511]
name: max_recursion_depth [54492,54511]
===
match
---
name: format [52667,52673]
name: format [52667,52673]
===
match
---
trailer [76037,76048]
trailer [76037,76048]
===
match
---
string: 'core' [94870,94876]
string: 'core' [94969,94975]
===
match
---
operator: = [94923,94924]
operator: = [95022,95023]
===
match
---
if_stmt [91715,92214]
if_stmt [91814,92313]
===
match
---
return_stmt [83729,83739]
return_stmt [83828,83838]
===
match
---
simple_stmt [2931,2988]
simple_stmt [2931,2988]
===
match
---
operator: = [67915,67916]
operator: = [67915,67916]
===
match
---
string: 'start_date' [15100,15112]
string: 'start_date' [15100,15112]
===
match
---
trailer [92463,92483]
trailer [92562,92582]
===
match
---
string: 'start_date' [14977,14989]
string: 'start_date' [14977,14989]
===
match
---
string: "Passing `recursion_depth` to dag.clear() is deprecated." [64472,64529]
string: "Passing `recursion_depth` to dag.clear() is deprecated." [64472,64529]
===
match
---
trailer [18228,18234]
trailer [18228,18234]
===
match
---
operator: = [72329,72330]
operator: = [72329,72330]
===
match
---
operator: { [16961,16962]
operator: { [16961,16962]
===
match
---
decorated [106080,107774]
decorated [106179,107873]
===
match
---
suite [33210,33269]
suite [33210,33269]
===
match
---
name: handle_callback [36367,36382]
name: handle_callback [36367,36382]
===
match
---
operator: = [28944,28945]
operator: = [28944,28945]
===
match
---
name: classmethod [92248,92259]
name: classmethod [92347,92358]
===
match
---
trailer [27774,27810]
trailer [27774,27810]
===
match
---
operator: , [45786,45787]
operator: , [45786,45787]
===
match
---
operator: = [10968,10969]
operator: = [10968,10969]
===
match
---
trailer [76205,76214]
trailer [76205,76214]
===
match
---
name: tasks [70698,70703]
name: tasks [70698,70703]
===
match
---
name: has_task_concurrency_limits [97787,97814]
name: has_task_concurrency_limits [97886,97913]
===
match
---
param [77664,77684]
param [77664,77684]
===
match
---
atom_expr [109284,109297]
atom_expr [109383,109396]
===
match
---
atom_expr [46430,46451]
atom_expr [46430,46451]
===
match
---
operator: = [42444,42445]
operator: = [42444,42445]
===
match
---
trailer [24266,24273]
trailer [24266,24273]
===
match
---
trailer [85926,85944]
trailer [86025,86043]
===
match
---
name: dag_id [37968,37974]
name: dag_id [37968,37974]
===
match
---
operator: = [11073,11074]
operator: = [11073,11074]
===
match
---
name: start_date [45692,45702]
name: start_date [45692,45702]
===
match
---
atom_expr [98806,98831]
atom_expr [98905,98930]
===
match
---
trailer [15809,15827]
trailer [15809,15827]
===
match
---
name: self [42262,42266]
name: self [42262,42266]
===
match
---
arglist [70608,70636]
arglist [70608,70636]
===
match
---
trailer [61438,61448]
trailer [61438,61448]
===
match
---
trailer [42290,42310]
trailer [42290,42310]
===
match
---
trailer [38670,38677]
trailer [38670,38677]
===
match
---
name: child [71798,71803]
name: child [71798,71803]
===
match
---
name: timezone [14707,14715]
name: timezone [14707,14715]
===
match
---
operator: , [39730,39731]
operator: , [39730,39731]
===
match
---
simple_stmt [57638,57792]
simple_stmt [57638,57792]
===
match
---
import_name [881,891]
import_name [881,891]
===
match
---
atom_expr [47035,47053]
atom_expr [47035,47053]
===
match
---
trailer [38085,38092]
trailer [38085,38092]
===
match
---
name: session [99635,99642]
name: session [99734,99741]
===
match
---
suite [66302,66378]
suite [66302,66378]
===
match
---
expr_stmt [15713,15751]
expr_stmt [15713,15751]
===
match
---
operator: , [23598,23599]
operator: , [23598,23599]
===
match
---
simple_stmt [42248,42275]
simple_stmt [42248,42275]
===
match
---
trailer [31637,31642]
trailer [31637,31642]
===
match
---
operator: , [1070,1071]
operator: , [1070,1071]
===
match
---
name: copied [71647,71653]
name: copied [71647,71653]
===
match
---
trailer [100189,100219]
trailer [100288,100318]
===
match
---
operator: = [35214,35215]
operator: = [35214,35215]
===
match
---
trailer [50426,51108]
trailer [50426,51108]
===
match
---
operator: == [103751,103753]
operator: == [103850,103852]
===
match
---
name: parser [80317,80323]
name: parser [80317,80323]
===
match
---
name: info [37240,37244]
name: info [37240,37244]
===
match
---
trailer [69036,69213]
trailer [69036,69213]
===
match
---
operator: = [66895,66896]
operator: = [66895,66896]
===
match
---
simple_stmt [42057,42084]
simple_stmt [42057,42084]
===
match
---
operator: , [64327,64328]
operator: , [64327,64328]
===
match
---
trailer [72970,72975]
trailer [72970,72975]
===
match
---
operator: , [96351,96352]
operator: , [96450,96451]
===
match
---
atom_expr [48628,48647]
atom_expr [48628,48647]
===
match
---
param [28025,28030]
param [28025,28030]
===
match
---
simple_stmt [51249,51310]
simple_stmt [51249,51310]
===
match
---
name: correct_maybe_zipped [102588,102608]
name: correct_maybe_zipped [102687,102707]
===
match
---
simple_stmt [64885,64932]
simple_stmt [64885,64932]
===
match
---
operator: = [45264,45265]
operator: = [45264,45265]
===
match
---
name: Column [95022,95028]
name: Column [95121,95127]
===
match
---
name: task [75421,75425]
name: task [75421,75425]
===
match
---
trailer [48505,48519]
trailer [48505,48519]
===
match
---
simple_stmt [32828,32954]
simple_stmt [32828,32954]
===
match
---
trailer [68413,68421]
trailer [68413,68421]
===
match
---
atom_expr [3967,4022]
atom_expr [3967,4022]
===
match
---
name: execution_date [57140,57154]
name: execution_date [57140,57154]
===
match
---
tfpdef [11897,11910]
tfpdef [11897,11910]
===
match
---
trailer [105985,105999]
trailer [106084,106098]
===
match
---
trailer [13192,13200]
trailer [13192,13200]
===
match
---
atom_expr [86855,86872]
atom_expr [86954,86971]
===
match
---
atom_expr [32969,32995]
atom_expr [32969,32995]
===
match
---
name: also_include [70951,70963]
name: also_include [70951,70963]
===
match
---
name: session [74882,74889]
name: session [74882,74889]
===
match
---
name: dag_bag [53184,53191]
name: dag_bag [53184,53191]
===
match
---
atom_expr [48839,48885]
atom_expr [48839,48885]
===
match
---
operator: = [13880,13881]
operator: = [13880,13881]
===
match
---
operator: = [69400,69401]
operator: = [69400,69401]
===
match
---
if_stmt [102585,102949]
if_stmt [102684,103048]
===
match
---
string: "" [13829,13831]
string: "" [13829,13831]
===
match
---
name: exception [37665,37674]
name: exception [37665,37674]
===
match
---
name: OnceTimetable [24976,24989]
name: OnceTimetable [24976,24989]
===
match
---
operator: = [79831,79832]
operator: = [79831,79832]
===
match
---
name: concurrency_reached [34393,34412]
name: concurrency_reached [34393,34412]
===
match
---
atom_expr [87684,87862]
atom_expr [87783,87961]
===
match
---
operator: , [93374,93375]
operator: , [93473,93474]
===
match
---
simple_stmt [51749,51773]
simple_stmt [51749,51773]
===
match
---
name: _context_managed_dag [109005,109025]
name: _context_managed_dag [109104,109124]
===
match
---
suite [82738,82885]
suite [82837,82984]
===
match
---
operator: = [20873,20874]
operator: = [20873,20874]
===
match
---
trailer [48655,48662]
trailer [48655,48662]
===
match
---
operator: = [91478,91479]
operator: = [91577,91578]
===
match
---
name: warnings [32828,32836]
name: warnings [32828,32836]
===
match
---
simple_stmt [1596,1621]
simple_stmt [1596,1621]
===
match
---
name: task [57056,57060]
name: task [57056,57060]
===
match
---
name: self [31029,31033]
name: self [31029,31033]
===
match
---
operator: -> [33835,33837]
operator: -> [33835,33837]
===
match
---
suite [42044,42084]
suite [42044,42084]
===
match
---
name: root_dag_id [101715,101726]
name: root_dag_id [101814,101825]
===
match
---
name: children [72304,72312]
name: children [72304,72312]
===
match
---
suite [105525,107818]
suite [105624,107917]
===
match
---
operator: , [35614,35615]
operator: , [35614,35615]
===
match
---
simple_stmt [88660,88676]
simple_stmt [88759,88775]
===
match
---
simple_stmt [15760,15797]
simple_stmt [15760,15797]
===
match
---
name: query [90422,90427]
name: query [90521,90526]
===
match
---
operator: = [88755,88756]
operator: = [88854,88855]
===
match
---
name: params [12151,12157]
name: params [12151,12157]
===
match
---
name: current [21594,21601]
name: current [21594,21601]
===
match
---
for_stmt [18244,18643]
for_stmt [18244,18643]
===
match
---
tfpdef [31896,31906]
tfpdef [31896,31906]
===
match
---
name: _get_task_instances [46913,46932]
name: _get_task_instances [46913,46932]
===
match
---
name: __serialized_fields [92390,92409]
name: __serialized_fields [92489,92508]
===
match
---
simple_stmt [97699,97771]
simple_stmt [97798,97870]
===
match
---
name: datetime [11063,11071]
name: datetime [11063,11071]
===
match
---
funcdef [97231,97951]
funcdef [97330,98050]
===
match
---
name: Optional [23676,23684]
name: Optional [23676,23684]
===
match
---
trailer [53789,54609]
trailer [53789,54609]
===
match
---
trailer [38849,38854]
trailer [38849,38854]
===
match
---
suite [102568,102949]
suite [102667,103048]
===
match
---
name: execution_date [80525,80539]
name: execution_date [80525,80539]
===
match
---
trailer [51447,51451]
trailer [51447,51451]
===
match
---
simple_stmt [76902,76952]
simple_stmt [76902,76952]
===
match
---
name: num [43772,43775]
name: num [43772,43775]
===
match
---
trailer [32977,32994]
trailer [32977,32994]
===
match
---
while_stmt [59663,61196]
while_stmt [59663,61196]
===
match
---
name: context [37524,37531]
name: context [37524,37531]
===
match
---
simple_stmt [75476,75594]
simple_stmt [75476,75594]
===
match
---
simple_stmt [16441,16464]
simple_stmt [16441,16464]
===
match
---
atom_expr [35749,35775]
atom_expr [35749,35775]
===
match
---
param [47299,47324]
param [47299,47324]
===
match
---
name: qry [91474,91477]
name: qry [91573,91576]
===
match
---
funcdef [109256,109339]
funcdef [109355,109438]
===
match
---
trailer [84938,84970]
trailer [85037,85069]
===
match
---
number: 2 [30697,30698]
number: 2 [30697,30698]
===
match
---
fstring_end: " [76709,76710]
fstring_end: " [76709,76710]
===
match
---
name: self [17597,17601]
name: self [17597,17601]
===
match
---
operator: , [39047,39048]
operator: , [39047,39048]
===
match
---
arglist [25192,25215]
arglist [25192,25215]
===
match
---
argument [65228,65249]
argument [65228,65249]
===
match
---
decorated [100719,100807]
decorated [100818,100906]
===
match
---
comp_op [24230,24236]
comp_op [24230,24236]
===
match
---
fstring_start: f" [98435,98437]
fstring_start: f" [98534,98536]
===
match
---
trailer [40438,40445]
trailer [40438,40445]
===
match
---
and_test [13221,13257]
and_test [13221,13257]
===
match
---
name: airflow [1626,1633]
name: airflow [1626,1633]
===
match
---
name: traceback [899,908]
name: traceback [899,908]
===
match
---
suite [24001,24026]
suite [24001,24026]
===
match
---
name: first [74567,74572]
name: first [74567,74572]
===
match
---
fstring_start: f" [17709,17711]
fstring_start: f" [17709,17711]
===
match
---
string: '.' [50253,50256]
string: '.' [50253,50256]
===
match
---
param [12403,12436]
param [12403,12436]
===
match
---
string: 'partial' [92728,92737]
string: 'partial' [92827,92836]
===
match
---
name: EdgeInfoType [93404,93416]
name: EdgeInfoType [93503,93515]
===
match
---
atom_expr [74323,74340]
atom_expr [74323,74340]
===
match
---
comparison [39855,39878]
comparison [39855,39878]
===
match
---
simple_stmt [2491,2541]
simple_stmt [2491,2541]
===
match
---
name: exclude_task_ids [45910,45926]
name: exclude_task_ids [45910,45926]
===
match
---
simple_stmt [49584,49631]
simple_stmt [49584,49631]
===
match
---
name: category [35877,35885]
name: category [35877,35885]
===
match
---
operator: = [101347,101348]
operator: = [101446,101447]
===
match
---
expr_stmt [51379,51454]
expr_stmt [51379,51454]
===
match
---
name: next_dagrun_info [22100,22116]
name: next_dagrun_info [22100,22116]
===
match
---
name: utcnow [74861,74867]
name: utcnow [74861,74867]
===
match
---
name: _previous_context_managed_dags [108807,108837]
name: _previous_context_managed_dags [108906,108936]
===
match
---
name: query [4087,4092]
name: query [4087,4092]
===
match
---
trailer [58300,58314]
trailer [58300,58314]
===
match
---
if_stmt [29404,29479]
if_stmt [29404,29479]
===
match
---
param [34413,34417]
param [34413,34417]
===
match
---
suite [90552,90852]
suite [90651,90951]
===
match
---
atom [42261,42274]
atom [42261,42274]
===
match
---
trailer [65183,65632]
trailer [65183,65632]
===
match
---
name: expression [4003,4013]
name: expression [4003,4013]
===
match
---
name: self [30109,30113]
name: self [30109,30113]
===
match
---
trailer [34352,34369]
trailer [34352,34369]
===
match
---
trailer [74517,74527]
trailer [74517,74527]
===
match
---
name: warnings [69023,69031]
name: warnings [69023,69031]
===
match
---
name: ti [52828,52830]
name: ti [52828,52830]
===
match
---
atom_expr [102877,102896]
atom_expr [102976,102995]
===
match
---
operator: , [94095,94096]
operator: , [94194,94195]
===
match
---
atom_expr [95904,95916]
atom_expr [96003,96015]
===
match
---
name: primary_key [94284,94295]
name: primary_key [94383,94394]
===
match
---
atom_expr [38073,38112]
atom_expr [38073,38112]
===
match
---
simple_stmt [76622,76712]
simple_stmt [76622,76712]
===
match
---
if_stmt [91597,91706]
if_stmt [91696,91805]
===
match
---
simple_stmt [19453,19654]
simple_stmt [19453,19654]
===
match
---
decorated [92247,93324]
decorated [92346,93423]
===
match
---
test [37132,37197]
test [37132,37197]
===
match
---
suite [51496,51561]
suite [51496,51561]
===
match
---
simple_stmt [75104,75141]
simple_stmt [75104,75141]
===
match
---
name: conditions [48572,48582]
name: conditions [48572,48582]
===
match
---
decorator [31446,31469]
decorator [31446,31469]
===
match
---
name: dag_by_ids [84765,84775]
name: dag_by_ids [84864,84874]
===
match
---
name: filtered_child [72248,72262]
name: filtered_child [72248,72262]
===
match
---
name: as_pk_tuple [47203,47214]
name: as_pk_tuple [47203,47214]
===
match
---
atom_expr [31420,31440]
atom_expr [31420,31440]
===
match
---
name: states [91799,91805]
name: states [91898,91904]
===
match
---
name: owners [87229,87235]
name: owners [87328,87334]
===
match
---
atom_expr [85520,85532]
atom_expr [85619,85631]
===
match
---
trailer [101801,101808]
trailer [101900,101907]
===
match
---
fstring_end: " [98577,98578]
fstring_end: " [98676,98677]
===
match
---
trailer [87691,87720]
trailer [87790,87819]
===
match
---
operator: * [75123,75124]
operator: * [75123,75124]
===
match
---
argument [21528,21540]
argument [21528,21540]
===
match
---
name: is_paused [103688,103697]
name: is_paused [103787,103796]
===
match
---
simple_stmt [92222,92242]
simple_stmt [92321,92341]
===
match
---
simple_stmt [15371,15415]
simple_stmt [15371,15415]
===
match
---
name: stacklevel [21075,21085]
name: stacklevel [21075,21085]
===
match
---
operator: { [16373,16374]
operator: { [16373,16374]
===
match
---
name: self [29914,29918]
name: self [29914,29918]
===
match
---
trailer [14143,14157]
trailer [14143,14157]
===
match
---
name: self [32594,32598]
name: self [32594,32598]
===
match
---
atom_expr [14783,14796]
atom_expr [14783,14796]
===
match
---
trailer [90511,90521]
trailer [90610,90620]
===
match
---
simple_stmt [30559,30710]
simple_stmt [30559,30710]
===
match
---
parameters [90028,90059]
parameters [90127,90158]
===
match
---
operator: , [11385,11386]
operator: , [11385,11386]
===
match
---
operator: , [92767,92768]
operator: , [92866,92867]
===
match
---
name: ExternalTaskMarker [51703,51721]
name: ExternalTaskMarker [51703,51721]
===
match
---
operator: = [44621,44622]
operator: = [44621,44622]
===
match
---
trailer [60883,60889]
trailer [60883,60889]
===
match
---
operator: = [54491,54492]
operator: = [54491,54492]
===
match
---
expr_stmt [100047,100248]
expr_stmt [100146,100347]
===
match
---
parameters [32351,32357]
parameters [32351,32357]
===
match
---
operator: { [93753,93754]
operator: { [93852,93853]
===
match
---
param [31970,31980]
param [31970,31980]
===
match
---
trailer [17309,17325]
trailer [17309,17325]
===
match
---
atom_expr [41804,41818]
atom_expr [41804,41818]
===
match
---
name: exclude_task_ids [62536,62552]
name: exclude_task_ids [62536,62552]
===
match
---
name: order_by [4041,4049]
name: order_by [4041,4049]
===
match
---
operator: == [91568,91570]
operator: == [91667,91669]
===
match
---
name: validate_key [2918,2930]
name: validate_key [2918,2930]
===
match
---
name: task_dict [76493,76502]
name: task_dict [76493,76502]
===
match
---
atom_expr [11009,11027]
atom_expr [11009,11027]
===
match
---
simple_stmt [87456,87506]
simple_stmt [87555,87605]
===
match
---
funcdef [31696,31761]
funcdef [31696,31761]
===
match
---
atom_expr [75864,75879]
atom_expr [75864,75879]
===
match
---
trailer [14279,14288]
trailer [14279,14288]
===
match
---
operator: , [31496,31497]
operator: , [31496,31497]
===
match
---
name: self [36280,36284]
name: self [36280,36284]
===
match
---
name: self [21259,21263]
name: self [21259,21263]
===
match
---
trailer [35246,35278]
trailer [35246,35278]
===
match
---
name: run [83736,83739]
name: run [83835,83838]
===
match
---
operator: = [95451,95452]
operator: = [95550,95551]
===
match
---
trailer [96410,96435]
trailer [96509,96534]
===
match
---
suite [16250,16433]
suite [16250,16433]
===
match
---
string: 'idx_root_dag_id' [96839,96856]
string: 'idx_root_dag_id' [96938,96955]
===
match
---
operator: @ [44746,44747]
operator: @ [44746,44747]
===
match
---
expr_stmt [91917,91971]
expr_stmt [92016,92070]
===
match
---
name: self [14675,14679]
name: self [14675,14679]
===
match
---
operator: { [42446,42447]
operator: { [42446,42447]
===
match
---
if_stmt [75602,76089]
if_stmt [75602,76089]
===
match
---
name: run_id [39784,39790]
name: run_id [39784,39790]
===
match
---
comp_op [51484,51490]
comp_op [51484,51490]
===
match
---
atom [97101,97114]
atom [97200,97213]
===
match
---
trailer [99608,99719]
trailer [99707,99818]
===
match
---
name: super [97287,97292]
name: super [97386,97391]
===
match
---
expr_stmt [88265,88318]
expr_stmt [88364,88417]
===
match
---
expr_stmt [96573,96626]
expr_stmt [96672,96725]
===
match
---
trailer [74388,74399]
trailer [74388,74399]
===
match
---
and_test [35953,36035]
and_test [35953,36035]
===
match
---
trailer [43287,43295]
trailer [43287,43295]
===
match
---
name: self [15909,15913]
name: self [15909,15913]
===
match
---
param [62133,62149]
param [62133,62149]
===
match
---
decorator [30744,30754]
decorator [30744,30754]
===
match
---
param [106127,106135]
param [106226,106234]
===
match
---
atom_expr [61181,61192]
atom_expr [61181,61192]
===
match
---
name: c [17985,17986]
name: c [17985,17986]
===
match
---
name: provide_session [44747,44762]
name: provide_session [44747,44762]
===
match
---
name: CronDataIntervalTimetable [25166,25191]
name: CronDataIntervalTimetable [25166,25191]
===
match
---
string: """Build a Jinja2 environment.""" [42147,42180]
string: """Build a Jinja2 environment.""" [42147,42180]
===
match
---
name: DagRun [85909,85915]
name: DagRun [86008,86014]
===
match
---
operator: == [36183,36185]
operator: == [36183,36185]
===
match
---
decorated [108915,109234]
decorated [109014,109333]
===
match
---
if_stmt [24211,24291]
if_stmt [24211,24291]
===
match
---
argument [65319,65350]
argument [65319,65350]
===
match
---
argument [104005,104020]
argument [104104,104119]
===
match
---
name: fileloc [95887,95894]
name: fileloc [95986,95993]
===
match
---
return_stmt [94415,94431]
return_stmt [94514,94530]
===
match
---
trailer [33513,33521]
trailer [33513,33521]
===
match
---
name: t [33752,33753]
name: t [33752,33753]
===
match
---
operator: = [96113,96114]
operator: = [96212,96213]
===
match
---
name: _task_group [76582,76593]
name: _task_group [76582,76593]
===
match
---
param [22140,22196]
param [22140,22196]
===
match
---
annassign [51924,52009]
annassign [51924,52009]
===
match
---
trailer [86917,86928]
trailer [87016,87027]
===
match
---
name: provide_session [61238,61253]
name: provide_session [61238,61253]
===
match
---
param [28043,28056]
param [28043,28056]
===
match
---
name: pool [79933,79937]
name: pool [79933,79937]
===
match
---
name: first [4093,4098]
name: first [4093,4098]
===
match
---
trailer [28896,28910]
trailer [28896,28910]
===
match
---
name: recursion_depth [54407,54422]
name: recursion_depth [54407,54422]
===
match
---
name: State [64895,64900]
name: State [64895,64900]
===
match
---
expr_stmt [37413,37448]
expr_stmt [37413,37448]
===
match
---
suite [12828,12933]
suite [12828,12933]
===
match
---
funcdef [31473,31585]
funcdef [31473,31585]
===
match
---
operator: , [11079,11080]
operator: , [11079,11080]
===
match
---
trailer [10949,10967]
trailer [10949,10967]
===
match
---
trailer [86421,86425]
trailer [86520,86524]
===
match
---
name: session [35099,35106]
name: session [35099,35106]
===
match
---
name: qry [35294,35297]
name: qry [35294,35297]
===
match
---
name: dag_id [18150,18156]
name: dag_id [18150,18156]
===
match
---
expr_stmt [71696,71716]
expr_stmt [71696,71716]
===
match
---
argument [97581,97593]
argument [97680,97692]
===
match
---
expr_stmt [28875,28910]
expr_stmt [28875,28910]
===
match
---
operator: , [25034,25035]
operator: , [25034,25035]
===
match
---
atom_expr [39855,39868]
atom_expr [39855,39868]
===
match
---
name: max_recursion_depth [52354,52373]
name: max_recursion_depth [52354,52373]
===
match
---
expr_stmt [65087,65111]
expr_stmt [65087,65111]
===
match
---
name: execution_date [85855,85869]
name: execution_date [85954,85968]
===
match
---
return_stmt [31826,31848]
return_stmt [31826,31848]
===
match
---
operator: = [74850,74851]
operator: = [74850,74851]
===
match
---
name: message [20825,20832]
name: message [20825,20832]
===
match
---
operator: , [62470,62471]
operator: , [62470,62471]
===
match
---
import_from [2322,2396]
import_from [2322,2396]
===
match
---
name: int [11501,11504]
name: int [11501,11504]
===
match
---
name: hash_components [18609,18624]
name: hash_components [18609,18624]
===
match
---
argument [70988,71001]
argument [70988,71001]
===
match
---
trailer [40814,40847]
trailer [40814,40847]
===
match
---
trailer [14198,14212]
trailer [14198,14212]
===
match
---
simple_stmt [33351,33363]
simple_stmt [33351,33363]
===
match
---
name: exclude_task_ids [50822,50838]
name: exclude_task_ids [50822,50838]
===
match
---
strings [19934,20072]
strings [19934,20072]
===
match
---
return_stmt [101022,101033]
return_stmt [101121,101132]
===
match
---
simple_stmt [60811,60844]
simple_stmt [60811,60844]
===
match
---
name: TI [55387,55389]
name: TI [55387,55389]
===
match
---
tfpdef [20266,20284]
tfpdef [20266,20284]
===
match
---
trailer [4052,4067]
trailer [4052,4067]
===
match
---
atom_expr [87891,87909]
atom_expr [87990,88008]
===
match
---
atom_expr [72894,72917]
atom_expr [72894,72917]
===
match
---
name: state [49964,49969]
name: state [49964,49969]
===
match
---
operator: = [11028,11029]
operator: = [11028,11029]
===
match
---
operator: = [45162,45163]
operator: = [45162,45163]
===
match
---
name: _description [31664,31676]
name: _description [31664,31676]
===
match
---
return_stmt [33486,33522]
return_stmt [33486,33522]
===
match
---
argument [29660,29675]
argument [29660,29675]
===
match
---
simple_stmt [95959,95989]
simple_stmt [96058,96088]
===
match
---
name: is_paused_upon_creation [17424,17447]
name: is_paused_upon_creation [17424,17447]
===
match
---
expr_stmt [44998,45081]
expr_stmt [44998,45081]
===
match
---
name: task_id [72047,72054]
name: task_id [72047,72054]
===
match
---
atom_expr [20723,20788]
atom_expr [20723,20788]
===
match
---
tfpdef [61373,61403]
tfpdef [61373,61403]
===
match
---
name: result [55255,55261]
name: result [55255,55261]
===
match
---
name: upstream_task_id [94079,94095]
name: upstream_task_id [94178,94194]
===
match
---
name: self [39842,39846]
name: self [39842,39846]
===
match
---
atom_expr [89729,89748]
atom_expr [89828,89847]
===
match
---
param [89426,89441]
param [89525,89540]
===
match
---
atom_expr [48444,48463]
atom_expr [48444,48463]
===
match
---
name: airflow [2546,2553]
name: airflow [2546,2553]
===
match
---
operator: = [45493,45494]
operator: = [45493,45494]
===
match
---
simple_stmt [15974,16147]
simple_stmt [15974,16147]
===
match
---
suite [17693,17733]
suite [17693,17733]
===
match
---
simple_stmt [101371,101565]
simple_stmt [101470,101664]
===
match
---
string: ", " [33741,33745]
string: ", " [33741,33745]
===
match
---
name: TaskInstance [47544,47556]
name: TaskInstance [47544,47556]
===
match
---
name: d [86712,86713]
name: d [86811,86812]
===
match
---
trailer [15556,15561]
trailer [15556,15561]
===
match
---
name: default [31981,31988]
name: default [31981,31988]
===
match
---
trailer [18389,18412]
trailer [18389,18412]
===
match
---
atom_expr [33741,33781]
atom_expr [33741,33781]
===
match
---
name: all [86619,86622]
name: all [86718,86721]
===
match
---
name: task [59410,59414]
name: task [59410,59414]
===
match
---
name: dag [72382,72385]
name: dag [72382,72385]
===
match
---
trailer [94858,94869]
trailer [94957,94968]
===
match
---
operator: = [12277,12278]
operator: = [12277,12278]
===
match
---
expr_stmt [108991,109025]
expr_stmt [109090,109124]
===
match
---
operator: = [37421,37422]
operator: = [37421,37422]
===
match
---
name: data_interval [82931,82944]
name: data_interval [83030,83043]
===
match
---
name: DagRun [38811,38817]
name: DagRun [38811,38817]
===
match
---
name: append [60877,60883]
name: append [60877,60883]
===
match
---
name: property [30056,30064]
name: property [30056,30064]
===
match
---
operator: = [24416,24417]
operator: = [24416,24417]
===
match
---
name: Optional [11714,11722]
name: Optional [11714,11722]
===
match
---
trailer [88497,88507]
trailer [88596,88606]
===
match
---
name: airflow [107935,107942]
name: airflow [108034,108041]
===
match
---
simple_stmt [74498,74575]
simple_stmt [74498,74575]
===
match
---
operator: = [53565,53566]
operator: = [53565,53566]
===
match
---
name: innerjoin [84954,84963]
name: innerjoin [85053,85062]
===
match
---
testlist_comp [24153,24201]
testlist_comp [24153,24201]
===
match
---
atom_expr [76472,76484]
atom_expr [76472,76484]
===
match
---
operator: , [86352,86353]
operator: , [86451,86452]
===
match
---
param [98064,98068]
param [98163,98167]
===
match
---
simple_stmt [60864,60890]
simple_stmt [60864,60890]
===
match
---
name: ti [51758,51760]
name: ti [51758,51760]
===
match
---
trailer [43595,43613]
trailer [43595,43613]
===
match
---
number: 2 [64812,64813]
number: 2 [64812,64813]
===
match
---
operator: = [19470,19471]
operator: = [19470,19471]
===
match
---
sync_comp_for [58682,58732]
sync_comp_for [58682,58732]
===
match
---
name: dag [83565,83568]
name: dag [83664,83667]
===
match
---
name: DagRun [62000,62006]
name: DagRun [62000,62006]
===
match
---
trailer [97009,97120]
trailer [97108,97219]
===
match
---
suite [26455,26511]
suite [26455,26511]
===
match
---
atom_expr [30301,30451]
atom_expr [30301,30451]
===
match
---
atom_expr [76786,76794]
atom_expr [76786,76794]
===
match
---
simple_stmt [53278,53338]
simple_stmt [53278,53338]
===
match
---
fstring_string: <DAG:  [97993,97999]
fstring_string: <DAG:  [98092,98098]
===
match
---
expr_stmt [66063,66104]
expr_stmt [66063,66104]
===
match
---
atom [76458,76557]
atom [76458,76557]
===
match
---
atom_expr [72991,73016]
atom_expr [72991,73016]
===
match
---
parameters [89425,89455]
parameters [89524,89554]
===
match
---
name: helpers [66077,66084]
name: helpers [66077,66084]
===
match
---
trailer [87413,87425]
trailer [87512,87524]
===
match
---
operator: } [71715,71716]
operator: } [71715,71716]
===
match
---
name: str [12130,12133]
name: str [12130,12133]
===
match
---
operator: , [44820,44821]
operator: , [44820,44821]
===
match
---
name: self [93347,93351]
name: self [93446,93450]
===
match
---
atom_expr [86325,86624]
atom_expr [86424,86723]
===
match
---
atom_expr [60627,60639]
atom_expr [60627,60639]
===
match
---
simple_stmt [37306,37340]
simple_stmt [37306,37340]
===
match
---
suite [18592,18643]
suite [18592,18643]
===
match
---
name: jinja_env_options [42695,42712]
name: jinja_env_options [42695,42712]
===
match
---
name: DateTime [104156,104164]
name: DateTime [104255,104263]
===
match
---
name: warnings [29119,29127]
name: warnings [29119,29127]
===
match
---
operator: , [20349,20350]
operator: , [20349,20350]
===
match
---
operator: - [107867,107868]
operator: - [107966,107967]
===
match
---
name: safe_dag_id [15660,15671]
name: safe_dag_id [15660,15671]
===
match
---
trailer [80412,80417]
trailer [80412,80417]
===
match
---
atom_expr [35294,35323]
atom_expr [35294,35323]
===
match
---
comparison [14529,14560]
comparison [14529,14560]
===
match
---
trailer [18409,18411]
trailer [18409,18411]
===
match
---
argument [45451,45468]
argument [45451,45468]
===
match
---
atom_expr [21442,21465]
atom_expr [21442,21465]
===
match
---
operator: = [97944,97945]
operator: = [98043,98044]
===
match
---
operator: , [42600,42601]
operator: , [42600,42601]
===
match
---
name: expression [100151,100161]
name: expression [100250,100260]
===
match
---
name: execution_date [57872,57886]
name: execution_date [57872,57886]
===
match
---
trailer [77416,77427]
trailer [77416,77427]
===
match
---
name: Set [46194,46197]
name: Set [46194,46197]
===
match
---
name: now [103826,103829]
name: now [103925,103928]
===
match
---
expr_stmt [68153,68162]
expr_stmt [68153,68162]
===
match
---
operator: = [90053,90054]
operator: = [90152,90153]
===
match
---
name: start_date [61807,61817]
name: start_date [61807,61817]
===
match
---
parameters [108959,108964]
parameters [109058,109063]
===
match
---
arglist [89262,89293]
arglist [89361,89392]
===
match
---
operator: @ [45602,45603]
operator: @ [45602,45603]
===
match
---
atom_expr [67745,68126]
atom_expr [67745,68126]
===
match
---
operator: , [61668,61669]
operator: , [61668,61669]
===
match
---
trailer [12686,12693]
trailer [12686,12693]
===
match
---
name: ID_LEN [94641,94647]
name: ID_LEN [94740,94746]
===
match
---
name: func [1443,1447]
name: func [1443,1447]
===
match
---
operator: , [28029,28030]
operator: , [28029,28030]
===
match
---
simple_stmt [89246,89303]
simple_stmt [89345,89402]
===
match
---
name: self [17198,17202]
name: self [17198,17202]
===
match
---
operator: @ [99164,99165]
operator: @ [99263,99264]
===
match
---
trailer [91560,91567]
trailer [91659,91666]
===
match
---
atom_expr [16269,16432]
atom_expr [16269,16432]
===
match
---
name: airflow [41495,41502]
name: airflow [41495,41502]
===
match
---
operator: , [10848,10849]
operator: , [10848,10849]
===
match
---
name: dag [48506,48509]
name: dag [48506,48509]
===
match
---
name: type_name [25225,25234]
name: type_name [25225,25234]
===
match
---
trailer [85842,85847]
trailer [85941,85946]
===
match
---
return_stmt [33852,33926]
return_stmt [33852,33926]
===
match
---
name: tags [88072,88076]
name: tags [88171,88175]
===
match
---
arglist [34242,34306]
arglist [34242,34306]
===
match
---
name: Optional [11311,11319]
name: Optional [11311,11319]
===
match
---
name: Dict [16934,16938]
name: Dict [16934,16938]
===
match
---
operator: , [11887,11888]
operator: , [11887,11888]
===
match
---
name: downstream_list [58717,58732]
name: downstream_list [58717,58732]
===
match
---
name: extend [61009,61015]
name: extend [61009,61015]
===
match
---
suite [82494,82714]
suite [82604,82824]
===
match
---
name: orm_dag [85659,85666]
name: orm_dag [85758,85765]
===
match
---
simple_stmt [88400,88425]
simple_stmt [88499,88524]
===
match
---
name: last_loaded [15615,15626]
name: last_loaded [15615,15626]
===
match
---
parameters [58759,58801]
parameters [58759,58801]
===
match
---
trailer [91638,91705]
trailer [91737,91804]
===
match
---
name: filter [48621,48627]
name: filter [48621,48627]
===
match
---
param [75336,75340]
param [75336,75340]
===
match
---
string: 'is_picklable' [74325,74339]
string: 'is_picklable' [74325,74339]
===
match
---
tfpdef [43743,43762]
tfpdef [43743,43762]
===
match
---
number: 2000 [95982,95986]
number: 2000 [96081,96085]
===
match
---
name: dag_id [86415,86421]
name: dag_id [86514,86520]
===
match
---
name: get_is_active [34804,34817]
name: get_is_active [34804,34817]
===
match
---
operator: , [1110,1111]
operator: , [1110,1111]
===
match
---
name: dag_id [3892,3898]
name: dag_id [3892,3898]
===
match
---
name: stacklevel [28754,28764]
name: stacklevel [28754,28764]
===
match
---
operator: = [102032,102033]
operator: = [102131,102132]
===
match
---
name: value [30535,30540]
name: value [30535,30540]
===
match
---
parameters [31397,31403]
parameters [31397,31403]
===
match
---
name: DagRun [40478,40484]
name: DagRun [40478,40484]
===
match
---
name: DAG [15557,15560]
name: DAG [15557,15560]
===
match
---
name: TaskInstance [48664,48676]
name: TaskInstance [48664,48676]
===
match
---
atom_expr [83013,83089]
atom_expr [83112,83188]
===
match
---
operator: , [61610,61611]
operator: , [61610,61611]
===
match
---
name: query [38588,38593]
name: query [38588,38593]
===
match
---
name: condition [51379,51388]
name: condition [51379,51388]
===
match
---
atom_expr [88474,88507]
atom_expr [88573,88606]
===
match
---
simple_stmt [65153,65633]
simple_stmt [65153,65633]
===
match
---
trailer [103868,103898]
trailer [103967,103997]
===
match
---
name: self [97782,97786]
name: self [97881,97885]
===
match
---
suite [15961,16147]
suite [15961,16147]
===
match
---
name: qry [91992,91995]
name: qry [92091,92094]
===
match
---
import_from [2249,2289]
import_from [2249,2289]
===
match
---
name: tis [49590,49593]
name: tis [49590,49593]
===
match
---
operator: = [29254,29255]
operator: = [29254,29255]
===
match
---
atom_expr [31224,31246]
atom_expr [31224,31246]
===
match
---
argument [95141,95154]
argument [95240,95253]
===
match
---
operator: -> [20357,20359]
operator: -> [20357,20359]
===
match
---
trailer [103635,103641]
trailer [103734,103740]
===
match
---
argument [54926,54952]
argument [54926,54952]
===
match
---
simple_stmt [35660,35688]
simple_stmt [35660,35688]
===
match
---
name: next_dagrun_data_interval [98758,98783]
name: next_dagrun_data_interval [98857,98882]
===
match
---
simple_stmt [67472,67517]
simple_stmt [67472,67517]
===
match
---
operator: , [1399,1400]
operator: , [1399,1400]
===
match
---
funcdef [94387,94432]
funcdef [94486,94531]
===
match
---
name: warnings [28580,28588]
name: warnings [28580,28588]
===
match
---
name: tasks [24469,24474]
name: tasks [24469,24474]
===
match
---
fstring_start: f" [76649,76651]
fstring_start: f" [76649,76651]
===
match
---
name: include_parentdag [46492,46509]
name: include_parentdag [46492,46509]
===
match
---
name: params [12687,12693]
name: params [12687,12693]
===
match
---
simple_stmt [61205,61232]
simple_stmt [61205,61232]
===
match
---
name: query [61831,61836]
name: query [61831,61836]
===
match
---
argument [50987,51026]
argument [50987,51026]
===
match
---
operator: = [83569,83570]
operator: = [83668,83669]
===
match
---
name: last_expired [95438,95450]
name: last_expired [95537,95549]
===
match
---
atom_expr [28797,28833]
atom_expr [28797,28833]
===
match
---
name: do_it [66063,66068]
name: do_it [66063,66068]
===
match
---
name: primary_key [94650,94661]
name: primary_key [94749,94760]
===
match
---
comparison [98121,98165]
comparison [98220,98264]
===
match
---
operator: , [49834,49835]
operator: , [49834,49835]
===
match
---
name: self [43374,43378]
name: self [43374,43378]
===
match
---
expr_stmt [18378,18412]
expr_stmt [18378,18412]
===
match
---
name: tis [48093,48096]
name: tis [48093,48096]
===
match
---
trailer [76752,76766]
trailer [76752,76766]
===
match
---
name: group [71743,71748]
name: group [71743,71748]
===
match
---
trailer [82432,82444]
trailer [82477,82489]
===
match
---
name: states [92205,92211]
name: states [92304,92310]
===
match
---
name: session [40695,40702]
name: session [40695,40702]
===
match
---
parameters [40938,40944]
parameters [40938,40944]
===
match
---
name: all [45581,45584]
name: all [45581,45584]
===
match
---
name: bool [46478,46482]
name: bool [46478,46482]
===
match
---
string: 'kcah_acitats' [107850,107864]
string: 'kcah_acitats' [107949,107963]
===
match
---
name: self [18390,18394]
name: self [18390,18394]
===
match
---
name: property [30219,30227]
name: property [30219,30227]
===
match
---
trailer [17626,17638]
trailer [17626,17638]
===
match
---
name: filter [39695,39701]
name: filter [39695,39701]
===
match
---
funcdef [100826,101241]
funcdef [100925,101340]
===
match
---
operator: , [45682,45683]
operator: , [45682,45683]
===
match
---
number: 1 [37362,37363]
number: 1 [37362,37363]
===
match
---
trailer [32648,32653]
trailer [32648,32653]
===
match
---
argument [41234,41246]
argument [41234,41246]
===
match
---
simple_stmt [94618,94668]
simple_stmt [94717,94767]
===
match
---
trailer [92008,92130]
trailer [92107,92229]
===
match
---
trailer [19737,19739]
trailer [19737,19739]
===
match
---
tfpdef [80817,80840]
tfpdef [80817,80840]
===
match
---
operator: -> [33399,33401]
operator: -> [33399,33401]
===
match
---
name: conf [94854,94858]
name: conf [94953,94957]
===
match
---
trailer [74651,74657]
trailer [74651,74657]
===
match
---
operator: = [10329,10330]
operator: = [10329,10330]
===
match
---
name: dag_id [89834,89840]
name: dag_id [89933,89939]
===
match
---
atom_expr [28580,28777]
atom_expr [28580,28777]
===
match
---
if_stmt [65642,65677]
if_stmt [65642,65677]
===
match
---
name: task_ids [91600,91608]
name: task_ids [91699,91707]
===
match
---
name: ti_key [51895,51901]
name: ti_key [51895,51901]
===
match
---
funcdef [32581,32657]
funcdef [32581,32657]
===
match
---
name: hash [18509,18513]
name: hash [18509,18513]
===
match
---
string: "failed to invoke dag state update callback" [37675,37719]
string: "failed to invoke dag state update callback" [37675,37719]
===
match
---
name: Optional [80827,80835]
name: Optional [80827,80835]
===
match
---
suite [72669,73080]
suite [72669,73080]
===
match
---
atom_expr [76004,76019]
atom_expr [76004,76019]
===
match
---
simple_stmt [2608,2665]
simple_stmt [2608,2665]
===
match
---
name: dag_id [99309,99315]
name: dag_id [99408,99414]
===
match
---
name: offset [44528,44534]
name: offset [44528,44534]
===
match
---
trailer [55840,55846]
trailer [55840,55846]
===
match
---
name: exclude_task_ids [54970,54986]
name: exclude_task_ids [54970,54986]
===
match
---
trailer [3979,4022]
trailer [3979,4022]
===
match
---
trailer [11851,11855]
trailer [11851,11855]
===
match
---
atom_expr [87238,87247]
atom_expr [87337,87346]
===
match
---
arglist [94322,94380]
arglist [94421,94479]
===
match
---
suite [82547,82644]
suite [82657,82754]
===
match
---
expr_stmt [16561,16581]
expr_stmt [16561,16581]
===
match
---
name: DeprecationWarning [23856,23874]
name: DeprecationWarning [23856,23874]
===
match
---
arglist [41643,41663]
arglist [41643,41663]
===
match
---
name: include_subdags [62266,62281]
name: include_subdags [62266,62281]
===
match
---
simple_stmt [76033,76089]
simple_stmt [76033,76089]
===
match
---
atom_expr [104545,104586]
atom_expr [104644,104685]
===
match
---
testlist_comp [20677,20788]
testlist_comp [20677,20788]
===
match
---
name: pendulum [22177,22185]
name: pendulum [22177,22185]
===
match
---
comparison [40432,40460]
comparison [40432,40460]
===
match
---
trailer [108844,108870]
trailer [108943,108969]
===
match
---
name: self [33829,33833]
name: self [33829,33833]
===
match
---
name: get_task [73599,73607]
name: get_task [73599,73607]
===
match
---
name: getattr [18453,18460]
name: getattr [18453,18460]
===
match
---
operator: , [84744,84745]
operator: , [84843,84844]
===
match
---
return_stmt [33351,33362]
return_stmt [33351,33362]
===
match
---
name: current_dag [32277,32288]
name: current_dag [32277,32288]
===
match
---
name: session [45494,45501]
name: session [45494,45501]
===
match
---
name: children [71749,71757]
name: children [71749,71757]
===
match
---
comparison [103789,103831]
comparison [103888,103930]
===
match
---
name: on_success_callback [37137,37156]
name: on_success_callback [37137,37156]
===
match
---
operator: = [67827,67828]
operator: = [67827,67828]
===
match
---
trailer [109146,109150]
trailer [109245,109249]
===
match
---
atom_expr [42286,42310]
atom_expr [42286,42310]
===
match
---
string: 'scheduler' [11929,11940]
string: 'scheduler' [11929,11940]
===
match
---
operator: , [25200,25201]
operator: , [25200,25201]
===
match
---
operator: = [61357,61358]
operator: = [61357,61358]
===
match
---
operator: = [34831,34832]
operator: = [34831,34832]
===
match
---
operator: = [48615,48616]
operator: = [48615,48616]
===
match
---
name: Column [96115,96121]
name: Column [96214,96220]
===
match
---
operator: = [80779,80780]
operator: = [80779,80780]
===
match
---
simple_stmt [70665,70739]
simple_stmt [70665,70739]
===
match
---
return_stmt [25065,25108]
return_stmt [25065,25108]
===
match
---
funcdef [71405,72373]
funcdef [71405,72373]
===
match
---
operator: = [15448,15449]
operator: = [15448,15449]
===
match
---
atom_expr [93653,93667]
atom_expr [93752,93766]
===
match
---
trailer [54824,54831]
trailer [54824,54831]
===
match
---
string: "`DAG.date_range()` is deprecated." [20394,20429]
string: "`DAG.date_range()` is deprecated." [20394,20429]
===
match
---
operator: = [77615,77616]
operator: = [77615,77616]
===
match
---
atom_expr [105369,105398]
atom_expr [105468,105497]
===
match
---
operator: , [11867,11868]
operator: , [11867,11868]
===
match
---
name: DagModel [100129,100137]
name: DagModel [100228,100236]
===
match
---
trailer [36001,36019]
trailer [36001,36019]
===
match
---
for_stmt [77192,77243]
for_stmt [77192,77243]
===
match
---
suite [37806,38142]
suite [37806,38142]
===
match
---
atom_expr [68609,68651]
atom_expr [68609,68651]
===
match
---
suite [97682,97771]
suite [97781,97870]
===
match
---
name: self [77018,77022]
name: self [77018,77022]
===
match
---
name: self [35093,35097]
name: self [35093,35097]
===
match
---
name: all [91776,91779]
name: all [91875,91878]
===
match
---
name: s [49719,49720]
name: s [49719,49720]
===
match
---
expr_stmt [65736,65748]
expr_stmt [65736,65748]
===
match
---
name: cls [109179,109182]
name: cls [109278,109281]
===
match
---
name: self [26479,26483]
name: self [26479,26483]
===
match
---
trailer [39694,39701]
trailer [39694,39701]
===
match
---
funcdef [41325,41977]
funcdef [41325,41977]
===
match
---
suite [65653,65677]
suite [65653,65677]
===
match
---
operator: = [71930,71931]
operator: = [71930,71931]
===
match
---
tfpdef [25444,25469]
tfpdef [25444,25469]
===
match
---
name: end_date [14891,14899]
name: end_date [14891,14899]
===
match
---
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_latest_execution_date` method.""" [40954,41055]
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_latest_execution_date` method.""" [40954,41055]
===
match
---
operator: , [12283,12284]
operator: , [12283,12284]
===
match
---
name: __name__ [51722,51730]
name: __name__ [51722,51730]
===
match
---
trailer [68757,68778]
trailer [68757,68778]
===
match
---
operator: = [67869,67870]
operator: = [67869,67870]
===
match
---
operator: { [73951,73952]
operator: { [73951,73952]
===
match
---
operator: = [54219,54220]
operator: = [54219,54220]
===
match
---
trailer [85000,85007]
trailer [85099,85106]
===
match
---
operator: = [104686,104687]
operator: = [104785,104786]
===
match
---
operator: = [3965,3966]
operator: = [3965,3966]
===
match
---
trailer [86358,86364]
trailer [86457,86463]
===
match
---
name: state [61304,61309]
name: state [61304,61309]
===
match
---
trailer [40847,40854]
trailer [40847,40854]
===
match
---
name: ValueError [82570,82580]
name: ValueError [82680,82690]
===
match
---
parameters [41336,41342]
parameters [41336,41342]
===
match
---
import_from [1621,1656]
import_from [1621,1656]
===
match
---
simple_stmt [103968,104054]
simple_stmt [104067,104153]
===
match
---
trailer [52666,52673]
trailer [52666,52673]
===
match
---
simple_stmt [104827,104876]
simple_stmt [104926,104975]
===
match
---
name: task_id [55563,55570]
name: task_id [55563,55570]
===
match
---
operator: = [37993,37994]
operator: = [37993,37994]
===
match
---
atom_expr [98252,98596]
atom_expr [98351,98695]
===
match
---
name: _get_task_instances [45117,45136]
name: _get_task_instances [45117,45136]
===
match
---
trailer [22176,22195]
trailer [22176,22195]
===
match
---
operator: , [52960,52961]
operator: , [52960,52961]
===
match
---
name: result [55235,55241]
name: result [55235,55241]
===
match
---
if_stmt [76167,76446]
if_stmt [76167,76446]
===
match
---
atom_expr [91656,91690]
atom_expr [91755,91789]
===
match
---
expr_stmt [105966,105999]
expr_stmt [106065,106098]
===
match
---
operator: , [43733,43734]
operator: , [43733,43734]
===
match
---
operator: , [80942,80943]
operator: , [80942,80943]
===
match
---
operator: , [101992,101993]
operator: , [102091,102092]
===
match
---
name: is_paused [94913,94922]
name: is_paused [95012,95021]
===
match
---
operator: = [99396,99397]
operator: = [99495,99496]
===
match
---
atom_expr [87784,87794]
atom_expr [87883,87893]
===
match
---
trailer [51894,51902]
trailer [51894,51902]
===
match
---
trailer [48842,48849]
trailer [48842,48849]
===
match
---
argument [58110,58125]
argument [58110,58125]
===
match
---
operator: -> [99832,99834]
operator: -> [99931,99933]
===
match
---
suite [86722,88425]
suite [86821,88524]
===
match
---
atom_expr [3889,3898]
atom_expr [3889,3898]
===
match
---
fstring_start: f" [25285,25287]
fstring_start: f" [25285,25287]
===
match
---
operator: = [39994,39995]
operator: = [39994,39995]
===
match
---
name: str [11841,11844]
name: str [11841,11844]
===
match
---
name: DagModel [99283,99291]
name: DagModel [99382,99390]
===
match
---
operator: = [80378,80379]
operator: = [80378,80379]
===
match
---
comparison [104983,105024]
comparison [105082,105123]
===
match
---
operator: , [46114,46115]
operator: , [46114,46115]
===
match
---
name: self [32777,32781]
name: self [32777,32781]
===
match
---
funcdef [43690,44741]
funcdef [43690,44741]
===
match
---
trailer [91676,91680]
trailer [91775,91779]
===
match
---
expr_stmt [100258,100327]
expr_stmt [100357,100426]
===
match
---
name: self [37173,37177]
name: self [37173,37177]
===
match
---
operator: , [82533,82534]
operator: , [82643,82644]
===
match
---
atom_expr [17944,17966]
atom_expr [17944,17966]
===
match
---
dotted_name [79229,79254]
dotted_name [79229,79254]
===
match
---
name: add [76934,76937]
name: add [76934,76937]
===
match
---
trailer [71951,71959]
trailer [71951,71959]
===
match
---
trailer [26590,26606]
trailer [26590,26606]
===
match
---
operator: -> [100390,100392]
operator: -> [100489,100491]
===
match
---
decorator [40899,40909]
decorator [40899,40909]
===
match
---
operator: , [77451,77452]
operator: , [77451,77452]
===
match
---
suite [31320,31360]
suite [31320,31360]
===
match
---
parameters [46932,47474]
parameters [46932,47474]
===
match
---
atom_expr [86051,86066]
atom_expr [86150,86165]
===
match
---
dotted_name [31058,31076]
dotted_name [31058,31076]
===
match
---
expr_stmt [38018,38035]
expr_stmt [38018,38035]
===
match
---
name: TI [51391,51393]
name: TI [51391,51393]
===
match
---
trailer [86622,86624]
trailer [86721,86723]
===
match
---
name: DagCode [2007,2014]
name: DagCode [2007,2014]
===
match
---
name: info [84725,84729]
name: info [84824,84828]
===
match
---
string: '__dot__' [100796,100805]
string: '__dot__' [100895,100904]
===
match
---
string: 'schedule_interval' [10423,10442]
string: 'schedule_interval' [10423,10442]
===
match
---
name: next_dagrun_data_interval_start [98642,98673]
name: next_dagrun_data_interval_start [98741,98772]
===
match
---
decorated [88770,89089]
decorated [88869,89188]
===
match
---
operator: = [34155,34156]
operator: = [34155,34156]
===
match
---
operator: == [17785,17787]
operator: == [17785,17787]
===
match
---
fstring_end: " [82384,82385]
fstring_end: " [82408,82409]
===
match
---
name: pendulum [23685,23693]
name: pendulum [23685,23693]
===
match
---
string: """Exposes a CLI specific to this DAG""" [80197,80237]
string: """Exposes a CLI specific to this DAG""" [80197,80237]
===
match
---
name: timezone [13987,13995]
name: timezone [13987,13995]
===
match
---
operator: = [13996,13997]
operator: = [13996,13997]
===
match
---
trailer [91668,91676]
trailer [91767,91775]
===
match
---
param [43398,43416]
param [43398,43416]
===
match
---
name: start_date [79640,79650]
name: start_date [79640,79650]
===
match
---
trailer [12129,12134]
trailer [12129,12134]
===
match
---
name: t [67503,67504]
name: t [67503,67504]
===
match
---
trailer [94699,94707]
trailer [94798,94806]
===
match
---
trailer [90450,90457]
trailer [90549,90556]
===
match
---
atom_expr [107021,107030]
atom_expr [107120,107129]
===
match
---
name: self [74293,74297]
name: self [74293,74297]
===
match
---
trailer [30314,30451]
trailer [30314,30451]
===
match
---
trailer [30567,30572]
trailer [30567,30572]
===
match
---
operator: = [65717,65718]
operator: = [65717,65718]
===
match
---
string: 'gantt' [3450,3457]
string: 'gantt' [3450,3457]
===
match
---
operator: , [50580,50581]
operator: , [50580,50581]
===
match
---
argument [21034,21061]
argument [21034,21061]
===
match
---
name: pathlib [33171,33178]
name: pathlib [33171,33178]
===
match
---
name: inspect [1007,1014]
name: inspect [1007,1014]
===
match
---
operator: = [10906,10907]
operator: = [10906,10907]
===
match
---
name: Column [96036,96042]
name: Column [96135,96141]
===
match
---
name: delay_on_limit_secs [79976,79995]
name: delay_on_limit_secs [79976,79995]
===
match
---
trailer [89054,89071]
trailer [89153,89170]
===
match
---
name: count [68153,68158]
name: count [68153,68158]
===
match
---
name: topological_sort [58743,58759]
name: topological_sort [58743,58759]
===
match
---
trailer [74232,74239]
trailer [74232,74239]
===
match
---
parameters [99100,99106]
parameters [99199,99205]
===
match
---
param [43743,43763]
param [43743,43763]
===
match
---
name: num [20523,20526]
name: num [20523,20526]
===
match
---
name: TaskInstance [92182,92194]
name: TaskInstance [92281,92293]
===
match
---
name: tuple [59585,59590]
name: tuple [59585,59590]
===
match
---
simple_stmt [58324,58423]
simple_stmt [58324,58423]
===
match
---
atom_expr [94322,94336]
atom_expr [94421,94435]
===
match
---
arglist [53819,54583]
arglist [53819,54583]
===
match
---
name: tii [53930,53933]
name: tii [53930,53933]
===
match
---
argument [20496,20517]
argument [20496,20517]
===
match
---
name: dag_ids [100210,100217]
name: dag_ids [100309,100316]
===
match
---
name: task_id [70709,70716]
name: task_id [70709,70716]
===
match
---
name: value [99063,99068]
name: value [99162,99167]
===
match
---
name: Optional [55788,55796]
name: Optional [55788,55796]
===
match
---
return_stmt [65666,65676]
return_stmt [65666,65676]
===
match
---
name: external_tis [53143,53155]
name: external_tis [53143,53155]
===
match
---
name: result [50370,50376]
name: result [50370,50376]
===
match
---
name: property [41312,41320]
name: property [41312,41320]
===
match
---
string: "DAG" [83825,83830]
string: "DAG" [83924,83929]
===
match
---
fstring_start: f' [16083,16085]
fstring_start: f' [16083,16085]
===
match
---
operator: = [79543,79544]
operator: = [79543,79544]
===
match
---
import_as_names [2437,2490]
import_as_names [2437,2490]
===
match
---
name: include_subdags [58010,58025]
name: include_subdags [58010,58025]
===
match
---
name: exclude_task_ids [45414,45430]
name: exclude_task_ids [45414,45430]
===
match
---
name: dirname [33501,33508]
name: dirname [33501,33508]
===
match
---
funcdef [10822,17669]
funcdef [10822,17669]
===
match
---
name: format [50228,50234]
name: format [50228,50234]
===
match
---
name: t [70688,70689]
name: t [70688,70689]
===
match
---
name: f [106686,106687]
name: f [106785,106786]
===
match
---
trailer [12814,12827]
trailer [12814,12827]
===
match
---
if_stmt [61086,61196]
if_stmt [61086,61196]
===
match
---
operator: = [29934,29935]
operator: = [29934,29935]
===
match
---
argument [45486,45501]
argument [45486,45501]
===
match
---
name: session [54362,54369]
name: session [54362,54369]
===
match
---
simple_stmt [43284,43330]
simple_stmt [43284,43330]
===
match
---
comparison [101706,101741]
comparison [101805,101840]
===
match
---
name: dag_ids [61465,61472]
name: dag_ids [61465,61472]
===
match
---
name: copied [72140,72146]
name: copied [72140,72146]
===
match
---
simple_stmt [36447,37113]
simple_stmt [36447,37113]
===
match
---
name: path [33230,33234]
name: path [33230,33234]
===
match
---
name: bool [80688,80692]
name: bool [80688,80692]
===
match
---
string: "This method is deprecated and will be removed in a future version. Please use partial_subset" [69050,69144]
string: "This method is deprecated and will be removed in a future version. Please use partial_subset" [69050,69144]
===
match
---
name: f_sig [106549,106554]
name: f_sig [106648,106653]
===
match
---
operator: , [80422,80423]
operator: , [80422,80423]
===
match
---
expr_stmt [108593,108635]
expr_stmt [108692,108734]
===
match
---
expr_stmt [30192,30212]
expr_stmt [30192,30212]
===
match
---
atom_expr [86408,86443]
atom_expr [86507,86542]
===
match
---
parameters [46292,46844]
parameters [46292,46844]
===
match
---
name: state [49187,49192]
name: state [49187,49192]
===
match
---
param [71434,71446]
param [71434,71446]
===
match
---
operator: = [104043,104044]
operator: = [104142,104143]
===
match
---
param [30535,30540]
param [30535,30540]
===
match
---
atom_expr [75290,75307]
atom_expr [75290,75307]
===
match
---
subscriptlist [46156,46174]
subscriptlist [46156,46174]
===
match
---
argument [21515,21526]
argument [21515,21526]
===
match
---
decorated [24764,25339]
decorated [24764,25339]
===
match
---
name: result [20892,20898]
name: result [20892,20898]
===
match
---
dotted_name [2112,2133]
dotted_name [2112,2133]
===
match
---
operator: * [69249,69250]
operator: * [69249,69250]
===
match
---
string: "DAG.full_filepath is deprecated in favour of fileloc" [30586,30640]
string: "DAG.full_filepath is deprecated in favour of fileloc" [30586,30640]
===
match
---
atom_expr [107840,107879]
atom_expr [107939,107978]
===
match
---
not_test [53180,53191]
not_test [53180,53191]
===
match
---
operator: * [106826,106827]
operator: * [106925,106926]
===
match
---
operator: = [41244,41245]
operator: = [41244,41245]
===
match
---
expr_stmt [74152,74182]
expr_stmt [74152,74182]
===
match
---
arglist [48113,48153]
arglist [48113,48153]
===
match
---
simple_stmt [37592,37610]
simple_stmt [37592,37610]
===
match
---
atom_expr [75668,75728]
atom_expr [75668,75728]
===
match
---
name: copy [12640,12644]
name: copy [12640,12644]
===
match
---
operator: = [12589,12590]
operator: = [12589,12590]
===
match
---
simple_stmt [90982,91466]
simple_stmt [91081,91565]
===
match
---
name: DagRunInfo [27491,27501]
name: DagRunInfo [27491,27501]
===
match
---
testlist_comp [101602,101633]
testlist_comp [101701,101732]
===
match
---
operator: = [14782,14783]
operator: = [14782,14783]
===
match
---
dotted_name [51254,51283]
dotted_name [51254,51283]
===
match
---
operator: = [79718,79719]
operator: = [79718,79719]
===
match
---
trailer [29651,29658]
trailer [29651,29658]
===
match
---
name: d [74361,74362]
name: d [74361,74362]
===
match
---
name: func [86354,86358]
name: func [86453,86457]
===
match
---
operator: , [18468,18469]
operator: , [18468,18469]
===
match
---
name: airflow [2065,2072]
name: airflow [2065,2072]
===
match
---
operator: = [68007,68008]
operator: = [68007,68008]
===
match
---
name: self [13552,13556]
name: self [13552,13556]
===
match
---
name: self [33981,33985]
name: self [33981,33985]
===
match
---
trailer [101785,101800]
trailer [101884,101899]
===
match
---
name: debug [102344,102349]
name: debug [102443,102448]
===
match
---
name: DeprecationWarning [13437,13455]
name: DeprecationWarning [13437,13455]
===
match
---
or_test [12654,12672]
or_test [12654,12672]
===
match
---
funcdef [21716,22091]
funcdef [21716,22091]
===
match
---
operator: , [44341,44342]
operator: , [44341,44342]
===
match
---
expr_stmt [107004,107030]
expr_stmt [107103,107129]
===
match
---
simple_stmt [20554,20638]
simple_stmt [20554,20638]
===
match
---
operator: = [20285,20286]
operator: = [20285,20286]
===
match
---
name: sqlalchemy [1458,1468]
name: sqlalchemy [1458,1468]
===
match
---
name: dates [2774,2779]
name: dates [2774,2779]
===
match
---
name: dag [84779,84782]
name: dag [84878,84881]
===
match
---
suite [89868,89934]
suite [89967,90033]
===
match
---
trailer [87787,87794]
trailer [87886,87893]
===
match
---
trailer [23534,23562]
trailer [23534,23562]
===
match
---
name: AirflowException [75668,75684]
name: AirflowException [75668,75684]
===
match
---
operator: = [102695,102696]
operator: = [102794,102795]
===
match
---
trailer [85007,85011]
trailer [85106,85110]
===
match
---
operator: = [91933,91934]
operator: = [92032,92033]
===
match
---
operator: = [53225,53226]
operator: = [53225,53226]
===
match
---
atom_expr [32401,32424]
atom_expr [32401,32424]
===
match
---
operator: , [48134,48135]
operator: , [48134,48135]
===
match
---
operator: * [106046,106047]
operator: * [106145,106146]
===
match
---
atom_expr [42816,42854]
atom_expr [42816,42854]
===
match
---
operator: = [50456,50457]
operator: = [50456,50457]
===
match
---
trailer [48493,48501]
trailer [48493,48501]
===
match
---
trailer [55582,55600]
trailer [55582,55600]
===
match
---
operator: , [35986,35987]
operator: , [35986,35987]
===
match
---
argument [69249,69254]
argument [69249,69254]
===
match
---
name: TI [52895,52897]
name: TI [52895,52897]
===
match
---
trailer [90849,90851]
trailer [90948,90950]
===
match
---
name: children [71703,71711]
name: children [71703,71711]
===
match
---
name: classmethod [108916,108927]
name: classmethod [109015,109026]
===
match
---
simple_stmt [71647,71683]
simple_stmt [71647,71683]
===
match
---
operator: = [50867,50868]
operator: = [50867,50868]
===
match
---
expr_stmt [55543,55602]
expr_stmt [55543,55602]
===
match
---
if_stmt [89204,89354]
if_stmt [89303,89453]
===
match
---
name: delay_on_limit_secs [79956,79975]
name: delay_on_limit_secs [79956,79975]
===
match
---
name: DagModel [74518,74526]
name: DagModel [74518,74526]
===
match
---
trailer [76420,76429]
trailer [76420,76429]
===
match
---
string: """         Deactivate any DAGs that were last touched by the scheduler before         the expiration date. These DAGs were likely deleted.          :param expiration_date: set inactive DAGs that were touched before this             time         :type expiration_date: datetime         :return: None         """ [90069,90380]
string: """         Deactivate any DAGs that were last touched by the scheduler before         the expiration date. These DAGs were likely deleted.          :param expiration_date: set inactive DAGs that were touched before this             time         :type expiration_date: datetime         :return: None         """ [90168,90479]
===
match
---
simple_stmt [72297,72346]
simple_stmt [72297,72346]
===
match
---
trailer [14229,14262]
trailer [14229,14262]
===
match
---
name: wrapper [105830,105837]
name: wrapper [105929,105936]
===
match
---
comparison [44411,44447]
comparison [44411,44447]
===
match
---
simple_stmt [82318,82387]
simple_stmt [82342,82411]
===
match
---
decorator [58263,58273]
decorator [58263,58273]
===
match
---
trailer [94277,94282]
trailer [94376,94381]
===
match
---
trailer [86795,86808]
trailer [86894,86907]
===
match
---
param [61420,61456]
param [61420,61456]
===
match
---
name: is_paused_at_creation [94830,94851]
name: is_paused_at_creation [94929,94950]
===
match
---
name: of [103997,103999]
name: of [104096,104098]
===
match
---
name: Dict [11373,11377]
name: Dict [11373,11377]
===
match
---
simple_stmt [18609,18643]
simple_stmt [18609,18643]
===
match
---
atom_expr [101062,101074]
atom_expr [101161,101173]
===
match
---
string: 'dag_default_view' [11791,11809]
string: 'dag_default_view' [11791,11809]
===
match
---
simple_stmt [103071,103443]
simple_stmt [103170,103542]
===
match
---
name: fileloc [107523,107530]
name: fileloc [107622,107629]
===
match
---
simple_stmt [105369,105406]
simple_stmt [105468,105505]
===
match
---
name: str [46446,46449]
name: str [46446,46449]
===
match
---
operator: , [51970,51971]
operator: , [51970,51971]
===
match
---
trailer [19497,19528]
trailer [19497,19528]
===
match
---
simple_stmt [40618,40633]
simple_stmt [40618,40633]
===
match
---
argument [83262,83295]
argument [83361,83394]
===
match
---
atom_expr [87660,87669]
atom_expr [87759,87768]
===
match
---
atom_expr [61852,61873]
atom_expr [61852,61873]
===
match
---
trailer [89300,89302]
trailer [89399,89401]
===
match
---
operator: , [36409,36410]
operator: , [36409,36410]
===
match
---
funcdef [83783,84169]
funcdef [83882,84268]
===
match
---
name: root_dag_id [97102,97113]
name: root_dag_id [97201,97212]
===
match
---
atom_expr [60525,60554]
atom_expr [60525,60554]
===
match
---
trailer [55386,55428]
trailer [55386,55428]
===
match
---
comparison [91741,91755]
comparison [91840,91854]
===
match
---
trailer [48862,48870]
trailer [48862,48870]
===
match
---
name: tasks [59553,59558]
name: tasks [59553,59558]
===
match
---
import_from [1263,1311]
import_from [1263,1311]
===
match
---
argument [57680,57707]
argument [57680,57707]
===
match
---
name: key [54929,54932]
name: key [54929,54932]
===
match
---
operator: = [29667,29668]
operator: = [29667,29668]
===
match
---
simple_stmt [107350,107394]
simple_stmt [107449,107493]
===
match
---
operator: , [11940,11941]
operator: , [11940,11941]
===
match
---
name: self [93653,93657]
name: self [93752,93756]
===
match
---
name: state [64838,64843]
name: state [64838,64843]
===
match
---
return_stmt [29611,29744]
return_stmt [29611,29744]
===
match
---
parameters [19077,19098]
parameters [19077,19098]
===
match
---
name: is_active [90774,90783]
name: is_active [90873,90882]
===
match
---
name: false [86546,86551]
name: false [86645,86650]
===
match
---
atom_expr [108879,108903]
atom_expr [108978,109002]
===
match
---
operator: , [99650,99651]
operator: , [99749,99750]
===
match
---
name: warnings [35785,35793]
name: warnings [35785,35793]
===
match
---
atom_expr [85610,85630]
atom_expr [85709,85729]
===
match
---
operator: , [46039,46040]
operator: , [46039,46040]
===
match
---
operator: = [23855,23856]
operator: = [23855,23856]
===
match
---
suite [60555,61073]
suite [60555,61073]
===
match
---
suite [18430,18476]
suite [18430,18476]
===
match
---
dotted_name [3043,3067]
dotted_name [3043,3067]
===
match
---
name: interval [25014,25022]
name: interval [25014,25022]
===
match
---
operator: @ [109239,109240]
operator: @ [109338,109339]
===
match
---
name: self [83013,83017]
name: self [83112,83116]
===
match
---
name: self [58694,58698]
name: self [58694,58698]
===
match
---
operator: = [68408,68409]
operator: = [68408,68409]
===
match
---
simple_stmt [18651,18687]
simple_stmt [18651,18687]
===
match
---
atom_expr [11364,11378]
atom_expr [11364,11378]
===
match
---
atom_expr [103789,103817]
atom_expr [103888,103916]
===
match
---
decorated [74424,74953]
decorated [74424,74953]
===
match
---
operator: , [105240,105241]
operator: , [105339,105340]
===
match
---
name: dag_id [53452,53458]
name: dag_id [53452,53458]
===
match
---
tfpdef [47230,47263]
tfpdef [47230,47263]
===
match
---
name: TI [48136,48138]
name: TI [48136,48138]
===
match
---
simple_stmt [94227,94253]
simple_stmt [94326,94352]
===
match
---
name: earliest [27727,27735]
name: earliest [27727,27735]
===
match
---
operator: @ [84174,84175]
operator: @ [84273,84274]
===
match
---
trailer [88673,88675]
trailer [88772,88774]
===
match
---
operator: @ [31365,31366]
operator: @ [31365,31366]
===
match
---
suite [70652,70739]
suite [70652,70739]
===
match
---
name: fileloc [30472,30479]
name: fileloc [30472,30479]
===
match
---
operator: , [90664,90665]
operator: , [90763,90764]
===
match
---
trailer [27942,27952]
trailer [27942,27952]
===
match
---
return_stmt [18651,18686]
return_stmt [18651,18686]
===
match
---
name: _log [68880,68884]
name: _log [68880,68884]
===
match
---
trailer [92060,92077]
trailer [92159,92176]
===
match
---
name: self [42762,42766]
name: self [42762,42766]
===
match
---
trailer [33255,33267]
trailer [33255,33267]
===
match
---
simple_stmt [106638,106698]
simple_stmt [106737,106797]
===
match
---
operator: } [76673,76674]
operator: } [76673,76674]
===
match
---
name: dag [87193,87196]
name: dag [87292,87295]
===
match
---
operator: { [12706,12707]
operator: { [12706,12707]
===
match
---
operator: = [15933,15934]
operator: = [15933,15934]
===
match
---
name: filters [43288,43295]
name: filters [43288,43295]
===
match
---
operator: , [69372,69373]
operator: , [69372,69373]
===
match
---
argument [79640,79661]
argument [79640,79661]
===
match
---
atom_expr [57918,58233]
atom_expr [57918,58233]
===
match
---
name: dag_id [84783,84789]
name: dag_id [84882,84888]
===
match
---
name: tis [55442,55445]
name: tis [55442,55445]
===
match
---
suite [14658,14815]
suite [14658,14815]
===
match
---
simple_stmt [98881,98962]
simple_stmt [98980,99061]
===
match
---
name: execution_date [44366,44380]
name: execution_date [44366,44380]
===
match
---
atom [38033,38035]
atom [38033,38035]
===
match
---
simple_stmt [82656,82714]
simple_stmt [82766,82824]
===
match
---
simple_stmt [30301,30452]
simple_stmt [30301,30452]
===
match
---
operator: = [72398,72399]
operator: = [72398,72399]
===
match
---
name: count [65711,65716]
name: count [65711,65716]
===
match
---
trailer [49026,49050]
trailer [49026,49050]
===
match
---
parameters [3596,3649]
parameters [3596,3649]
===
match
---
name: Path [33053,33057]
name: Path [33053,33057]
===
match
---
arith_expr [48365,48386]
arith_expr [48365,48386]
===
match
---
name: _downstream_task_ids [73316,73336]
name: _downstream_task_ids [73316,73336]
===
match
---
name: _description [13654,13666]
name: _description [13654,13666]
===
match
---
param [44849,44861]
param [44849,44861]
===
match
---
name: do_it [67693,67698]
name: do_it [67693,67698]
===
match
---
name: lower [11811,11816]
name: lower [11811,11816]
===
match
---
fstring_end: " [67625,67626]
fstring_end: " [67625,67626]
===
match
---
name: Optional [12064,12072]
name: Optional [12064,12072]
===
match
---
name: dttm [74074,74078]
name: dttm [74074,74078]
===
match
---
name: conf [100664,100668]
name: conf [100763,100767]
===
match
---
operator: , [93820,93821]
operator: , [93919,93920]
===
match
---
name: state [50575,50580]
name: state [50575,50580]
===
match
---
fstring_expr [76660,76674]
fstring_expr [76660,76674]
===
match
---
suite [104738,104947]
suite [104837,105046]
===
match
---
atom_expr [53567,53578]
atom_expr [53567,53578]
===
match
---
name: get_template_env [42093,42109]
name: get_template_env [42093,42109]
===
match
---
trailer [49593,49600]
trailer [49593,49600]
===
match
---
name: task_id [73614,73621]
name: task_id [73614,73621]
===
match
---
arglist [68834,68846]
arglist [68834,68846]
===
match
---
trailer [48106,48112]
trailer [48106,48112]
===
match
---
for_stmt [68467,68652]
for_stmt [68467,68652]
===
match
---
parameters [32593,32599]
parameters [32593,32599]
===
match
---
trailer [41072,41077]
trailer [41072,41077]
===
match
---
param [93376,93399]
param [93475,93498]
===
match
---
name: AirflowException [52452,52468]
name: AirflowException [52452,52468]
===
match
---
atom_expr [73224,73244]
atom_expr [73224,73244]
===
match
---
trailer [100209,100218]
trailer [100308,100317]
===
match
---
funcdef [29075,29500]
funcdef [29075,29500]
===
match
---
atom_expr [91834,91874]
atom_expr [91933,91973]
===
match
---
argument [83464,83491]
argument [83563,83590]
===
match
---
name: DagModel [101823,101831]
name: DagModel [101922,101930]
===
match
---
argument [96260,96287]
argument [96359,96386]
===
match
---
simple_stmt [57018,57048]
simple_stmt [57018,57048]
===
match
---
name: str [47086,47089]
name: str [47086,47089]
===
match
---
name: _parent_group [71654,71667]
name: _parent_group [71654,71667]
===
match
---
atom_expr [40449,40460]
atom_expr [40449,40460]
===
match
---
atom_expr [15267,15289]
atom_expr [15267,15289]
===
match
---
trailer [14008,14015]
trailer [14008,14015]
===
match
---
sync_comp_for [84795,84810]
sync_comp_for [84894,84909]
===
match
---
trailer [86174,86178]
trailer [86273,86277]
===
match
---
name: Tuple [80928,80933]
name: Tuple [80928,80933]
===
match
---
suite [54666,55191]
suite [54666,55191]
===
match
---
name: classmethod [101924,101935]
name: classmethod [102023,102034]
===
match
---
name: subdag_lst [41870,41880]
name: subdag_lst [41870,41880]
===
match
---
trailer [71920,71928]
trailer [71920,71928]
===
match
---
name: logging_mixin [2954,2967]
name: logging_mixin [2954,2967]
===
match
---
sync_comp_for [51432,51453]
sync_comp_for [51432,51453]
===
match
---
operator: { [19472,19473]
operator: { [19472,19473]
===
match
---
trailer [39112,39121]
trailer [39112,39121]
===
match
---
atom_expr [89915,89933]
atom_expr [90014,90032]
===
match
---
atom_expr [90565,90757]
atom_expr [90664,90856]
===
match
---
suite [98229,98597]
suite [98328,98696]
===
match
---
expr_stmt [106008,106070]
expr_stmt [106107,106169]
===
match
---
name: run_type [86058,86066]
name: run_type [86157,86165]
===
match
---
operator: @ [32431,32432]
operator: @ [32431,32432]
===
match
---
expr_stmt [95631,95658]
expr_stmt [95730,95757]
===
match
---
trailer [58478,58492]
trailer [58478,58492]
===
match
---
name: timezone [20332,20340]
name: timezone [20332,20340]
===
match
---
expr_stmt [17522,17588]
expr_stmt [17522,17588]
===
match
---
atom_expr [101621,101632]
atom_expr [101720,101731]
===
match
---
operator: = [94375,94376]
operator: = [94474,94475]
===
match
---
name: task_dict [73738,73747]
name: task_dict [73738,73747]
===
match
---
for_stmt [87876,88053]
for_stmt [87975,88152]
===
match
---
name: dag_bag [46015,46022]
name: dag_bag [46015,46022]
===
match
---
name: List [20360,20364]
name: List [20360,20364]
===
match
---
expr_stmt [51517,51560]
expr_stmt [51517,51560]
===
match
---
trailer [53300,53308]
trailer [53300,53308]
===
match
---
atom_expr [73894,73916]
atom_expr [73894,73916]
===
match
---
parameters [105837,105850]
parameters [105936,105949]
===
match
---
name: airflow [2402,2409]
name: airflow [2402,2409]
===
match
---
name: DagModel [35304,35312]
name: DagModel [35304,35312]
===
match
---
atom_expr [47484,47506]
atom_expr [47484,47506]
===
match
---
arglist [75238,75246]
arglist [75238,75246]
===
match
---
name: run_id [80576,80582]
name: run_id [80576,80582]
===
match
---
tfpdef [46385,46413]
tfpdef [46385,46413]
===
match
---
name: dag_id [92468,92474]
name: dag_id [92567,92573]
===
match
---
param [55778,55811]
param [55778,55811]
===
match
---
operator: , [102418,102419]
operator: , [102517,102518]
===
match
---
name: cols [54849,54853]
name: cols [54849,54853]
===
match
---
name: DagRun [44268,44274]
name: DagRun [44268,44274]
===
match
---
parameters [105499,105524]
parameters [105598,105623]
===
match
---
operator: = [50672,50673]
operator: = [50672,50673]
===
match
---
testlist_comp [3499,3521]
testlist_comp [3499,3521]
===
match
---
for_stmt [89782,89934]
for_stmt [89881,90033]
===
match
---
if_stmt [20438,20803]
if_stmt [20438,20803]
===
match
---
name: catchup [11897,11904]
name: catchup [11897,11904]
===
match
---
name: render_template_as_native_obj [12350,12379]
name: render_template_as_native_obj [12350,12379]
===
match
---
parameters [20930,20936]
parameters [20930,20936]
===
match
---
trailer [35028,35048]
trailer [35028,35048]
===
match
---
name: on_success_callback [11973,11992]
name: on_success_callback [11973,11992]
===
match
---
trailer [71702,71711]
trailer [71702,71711]
===
match
---
name: self [17522,17526]
name: self [17522,17526]
===
match
---
name: doc_md [107012,107018]
name: doc_md [107111,107117]
===
match
---
atom_expr [104138,104165]
atom_expr [104237,104264]
===
match
---
trailer [44959,44961]
trailer [44959,44961]
===
match
---
expr_stmt [26573,26614]
expr_stmt [26573,26614]
===
match
---
trailer [23137,23147]
trailer [23137,23147]
===
match
---
operator: , [94336,94337]
operator: , [94435,94436]
===
match
---
atom_expr [74832,74849]
atom_expr [74832,74849]
===
match
---
param [77018,77023]
param [77018,77023]
===
match
---
raise_stmt [61118,61195]
raise_stmt [61118,61195]
===
match
---
atom_expr [51703,51730]
atom_expr [51703,51730]
===
match
---
not_test [79286,79298]
not_test [79286,79298]
===
match
---
operator: { [84778,84779]
operator: { [84877,84878]
===
match
---
arglist [37245,37292]
arglist [37245,37292]
===
match
---
name: provide_session [99340,99355]
name: provide_session [99439,99454]
===
match
---
name: airflow [1603,1610]
name: airflow [1603,1610]
===
match
---
operator: == [40869,40871]
operator: == [40869,40871]
===
match
---
atom_expr [94925,94971]
atom_expr [95024,95070]
===
match
---
name: self [73698,73702]
name: self [73698,73702]
===
match
---
param [109276,109279]
param [109375,109378]
===
match
---
atom_expr [44359,44380]
atom_expr [44359,44380]
===
match
---
number: 0 [46726,46727]
number: 0 [46726,46727]
===
match
---
atom_expr [12064,12096]
atom_expr [12064,12096]
===
match
---
simple_stmt [35140,35202]
simple_stmt [35140,35202]
===
match
---
operator: , [79661,79662]
operator: , [79661,79662]
===
match
---
atom_expr [75223,75247]
atom_expr [75223,75247]
===
match
---
name: latest [21515,21521]
name: latest [21515,21521]
===
match
---
expr_stmt [10586,10598]
expr_stmt [10586,10598]
===
match
---
trailer [109004,109025]
trailer [109103,109124]
===
match
---
decorator [61237,61254]
decorator [61237,61254]
===
match
---
trailer [24623,24639]
trailer [24623,24639]
===
match
---
atom_expr [49836,49864]
atom_expr [49836,49864]
===
match
---
atom_expr [94422,94431]
atom_expr [94521,94530]
===
match
---
name: dag [85355,85358]
name: dag [85454,85457]
===
match
---
arglist [107381,107392]
arglist [107480,107491]
===
match
---
name: or_ [92034,92037]
name: or_ [92133,92136]
===
match
---
name: signature [106439,106448]
name: signature [106538,106547]
===
match
---
trailer [90573,90757]
trailer [90672,90856]
===
match
---
atom_expr [12319,12333]
atom_expr [12319,12333]
===
match
---
name: property [32329,32337]
name: property [32329,32337]
===
match
---
suite [39515,39604]
suite [39515,39604]
===
match
---
trailer [24278,24289]
trailer [24278,24289]
===
match
---
name: cls [103642,103645]
name: cls [103741,103744]
===
match
---
argument [64801,64813]
argument [64801,64813]
===
match
---
name: f_kwargs [107666,107674]
name: f_kwargs [107765,107773]
===
match
---
atom_expr [76738,76766]
atom_expr [76738,76766]
===
match
---
arglist [64209,64358]
arglist [64209,64358]
===
match
---
operator: , [55408,55409]
operator: , [55408,55409]
===
match
---
name: orm [1469,1472]
name: orm [1469,1472]
===
match
---
decorator [30218,30228]
decorator [30218,30228]
===
match
---
name: getint [97728,97734]
name: getint [97827,97833]
===
match
---
name: default_view [87362,87374]
name: default_view [87461,87473]
===
match
---
simple_stmt [14181,14263]
simple_stmt [14181,14263]
===
match
---
name: or_ [101782,101785]
name: or_ [101881,101884]
===
match
---
name: query [51533,51538]
name: query [51533,51538]
===
match
---
operator: = [65137,65138]
operator: = [65137,65138]
===
match
---
trailer [11816,11818]
trailer [11816,11818]
===
match
---
parameters [88805,88825]
parameters [88904,88924]
===
match
---
operator: == [52937,52939]
operator: == [52937,52939]
===
match
---
trailer [21139,21149]
trailer [21139,21149]
===
match
---
atom_expr [44411,44426]
atom_expr [44411,44426]
===
match
---
name: t [42028,42029]
name: t [42028,42029]
===
match
---
name: AirflowException [61124,61140]
name: AirflowException [61124,61140]
===
match
---
argument [20863,20875]
argument [20863,20875]
===
match
---
subscriptlist [16939,16956]
subscriptlist [16939,16956]
===
match
---
name: owner [87077,87082]
name: owner [87176,87181]
===
match
---
simple_stmt [18447,18476]
simple_stmt [18447,18476]
===
match
---
operator: == [99456,99458]
operator: == [99555,99557]
===
match
---
operator: { [107267,107268]
operator: { [107366,107367]
===
match
---
param [24104,24108]
param [24104,24108]
===
match
---
name: dag [88689,88692]
name: dag [88788,88791]
===
match
---
operator: , [67075,67076]
operator: , [67075,67076]
===
match
---
trailer [35303,35323]
trailer [35303,35323]
===
match
---
expr_stmt [37121,37197]
expr_stmt [37121,37197]
===
match
---
atom_expr [69358,69371]
atom_expr [69358,69371]
===
match
---
name: child [71734,71739]
name: child [71734,71739]
===
match
---
name: print [66337,66342]
name: print [66337,66342]
===
match
---
name: Dict [12168,12172]
name: Dict [12168,12172]
===
match
---
trailer [20727,20753]
trailer [20727,20753]
===
match
---
expr_stmt [96374,96435]
expr_stmt [96473,96534]
===
match
---
name: default_args [14570,14582]
name: default_args [14570,14582]
===
match
---
name: str [14653,14656]
name: str [14653,14656]
===
match
---
atom_expr [42033,42043]
atom_expr [42033,42043]
===
match
---
atom_expr [12620,12637]
atom_expr [12620,12637]
===
match
---
name: max_active_runs [11564,11579]
name: max_active_runs [11564,11579]
===
match
---
operator: , [83213,83214]
operator: , [83312,83313]
===
match
---
operator: , [11605,11606]
operator: , [11605,11606]
===
match
---
string: """This method is deprecated in favor of bulk_write_to_db""" [83856,83916]
string: """This method is deprecated in favor of bulk_write_to_db""" [83955,84015]
===
match
---
if_stmt [104956,105406]
if_stmt [105055,105505]
===
match
---
sync_comp_for [65859,65871]
sync_comp_for [65859,65871]
===
match
---
name: provide_session [88771,88786]
name: provide_session [88870,88885]
===
match
---
operator: { [12670,12671]
operator: { [12670,12671]
===
match
---
trailer [73061,73071]
trailer [73061,73071]
===
match
---
name: len [49312,49315]
name: len [49312,49315]
===
match
---
param [66497,66513]
param [66497,66513]
===
match
---
name: render_template_as_native_obj [42767,42796]
name: render_template_as_native_obj [42767,42796]
===
match
---
trailer [14626,14639]
trailer [14626,14639]
===
match
---
comparison [82957,82983]
comparison [83056,83082]
===
match
---
arglist [97735,97769]
arglist [97834,97868]
===
match
---
atom_expr [49362,49380]
atom_expr [49362,49380]
===
match
---
operator: = [66223,66224]
operator: = [66223,66224]
===
match
---
expr_stmt [26624,26685]
expr_stmt [26624,26685]
===
match
---
operator: , [39001,39002]
operator: , [39001,39002]
===
match
---
fstring_string: > [17730,17731]
fstring_string: > [17730,17731]
===
match
---
trailer [55490,55498]
trailer [55490,55498]
===
match
---
operator: = [87151,87152]
operator: = [87250,87251]
===
match
---
atom_expr [74911,74925]
atom_expr [74911,74925]
===
match
---
name: in_ [92201,92204]
name: in_ [92300,92303]
===
match
---
name: on_failure_callback [17234,17253]
name: on_failure_callback [17234,17253]
===
match
---
simple_stmt [25065,25109]
simple_stmt [25065,25109]
===
match
---
trailer [71590,71605]
trailer [71590,71605]
===
match
---
name: dag [105496,105499]
name: dag [105595,105598]
===
match
---
suite [49656,49892]
suite [49656,49892]
===
match
---
name: dag_id [34996,35002]
name: dag_id [34996,35002]
===
match
---
operator: , [86553,86554]
operator: , [86652,86653]
===
match
---
name: query [103636,103641]
name: query [103735,103740]
===
match
---
name: pickle_id [31784,31793]
name: pickle_id [31784,31793]
===
match
---
name: tis [65153,65156]
name: tis [65153,65156]
===
match
---
name: print [67385,67390]
name: print [67385,67390]
===
match
---
trailer [65855,65858]
trailer [65855,65858]
===
match
---
decorator [43669,43686]
decorator [43669,43686]
===
match
---
atom_expr [26638,26685]
atom_expr [26638,26685]
===
match
---
trailer [86994,87005]
trailer [87093,87104]
===
match
---
name: task [76055,76059]
name: task [76055,76059]
===
match
---
name: end_date [57801,57809]
name: end_date [57801,57809]
===
match
---
simple_stmt [61688,61723]
simple_stmt [61688,61723]
===
match
---
operator: = [65742,65743]
operator: = [65742,65743]
===
match
---
operator: = [55925,55926]
operator: = [55925,55926]
===
match
---
simple_stmt [909,925]
simple_stmt [909,925]
===
match
---
name: self [74749,74753]
name: self [74749,74753]
===
match
---
import_as_names [2579,2607]
import_as_names [2579,2607]
===
match
---
operator: = [62250,62251]
operator: = [62250,62251]
===
match
---
dotted_name [2020,2043]
dotted_name [2020,2043]
===
match
---
expr_stmt [107996,108054]
expr_stmt [108095,108153]
===
match
---
name: tis [49249,49252]
name: tis [49249,49252]
===
match
---
operator: , [50875,50876]
operator: , [50875,50876]
===
match
---
parameters [66460,66755]
parameters [66460,66755]
===
match
---
return_stmt [21654,21665]
return_stmt [21654,21665]
===
match
---
atom_expr [87133,87150]
atom_expr [87232,87249]
===
match
---
name: false [103712,103717]
name: false [103811,103816]
===
match
---
simple_stmt [85643,85668]
simple_stmt [85742,85767]
===
match
---
name: x [91794,91795]
name: x [91893,91894]
===
match
---
atom_expr [76416,76429]
atom_expr [76416,76429]
===
match
---
return_stmt [93681,93756]
return_stmt [93780,93855]
===
match
---
name: dag_id [85146,85152]
name: dag_id [85245,85251]
===
match
---
name: Boolean [1384,1391]
name: Boolean [1384,1391]
===
match
---
operator: >= [61874,61876]
operator: >= [61874,61876]
===
match
---
name: overload [45603,45611]
name: overload [45603,45611]
===
match
---
name: TaskInstanceKey [54832,54847]
name: TaskInstanceKey [54832,54847]
===
match
---
trailer [44983,44985]
trailer [44983,44985]
===
match
---
fstring_conversion [98408,98410]
fstring_conversion [98507,98509]
===
match
---
name: cls [109085,109088]
name: cls [109184,109187]
===
match
---
return_stmt [41959,41976]
return_stmt [41959,41976]
===
match
---
suite [65819,66105]
suite [65819,66105]
===
match
---
param [101285,101290]
param [101384,101389]
===
match
---
name: state [92092,92097]
name: state [92191,92196]
===
match
---
suite [31643,31677]
suite [31643,31677]
===
match
---
name: utils [2678,2683]
name: utils [2678,2683]
===
match
---
name: dagpickle [2080,2089]
name: dagpickle [2080,2089]
===
match
---
name: altered [57081,57088]
name: altered [57081,57088]
===
match
---
atom_expr [17153,17177]
atom_expr [17153,17177]
===
match
---
name: dag_id [88311,88317]
name: dag_id [88410,88416]
===
match
---
trailer [42724,42749]
trailer [42724,42749]
===
match
---
trailer [50227,50234]
trailer [50227,50234]
===
match
---
arglist [91656,91691]
arglist [91755,91790]
===
match
---
param [44799,44804]
param [44799,44804]
===
match
---
name: dag_bound_args [106647,106661]
name: dag_bound_args [106746,106760]
===
match
---
operator: , [29792,29793]
operator: , [29792,29793]
===
match
---
name: state [92051,92056]
name: state [92150,92155]
===
match
---
name: filter [92175,92181]
name: filter [92274,92280]
===
match
---
trailer [89922,89928]
trailer [90021,90027]
===
match
---
expr_stmt [104636,104724]
expr_stmt [104735,104823]
===
match
---
atom_expr [52982,52992]
atom_expr [52982,52992]
===
match
---
trailer [38898,38900]
trailer [38898,38900]
===
match
---
name: memo [68435,68439]
name: memo [68435,68439]
===
match
---
name: session [48187,48194]
name: session [48187,48194]
===
match
---
atom_expr [92034,92108]
atom_expr [92133,92207]
===
match
---
simple_stmt [40794,40894]
simple_stmt [40794,40894]
===
match
---
operator: , [45979,45980]
operator: , [45979,45980]
===
match
---
atom_expr [46618,46633]
atom_expr [46618,46633]
===
match
---
param [11290,11333]
param [11290,11333]
===
match
---
trailer [65846,65851]
trailer [65846,65851]
===
match
---
parameters [10834,12442]
parameters [10834,12442]
===
match
---
name: self [68378,68382]
name: self [68378,68382]
===
match
---
name: DagModel [85311,85319]
name: DagModel [85410,85418]
===
match
---
trailer [72770,72772]
trailer [72770,72772]
===
match
---
simple_stmt [101901,101918]
simple_stmt [102000,102017]
===
match
---
not_test [74726,74732]
not_test [74726,74732]
===
match
---
name: warnings [35470,35478]
name: warnings [35470,35478]
===
match
---
name: concurrency [13532,13543]
name: concurrency [13532,13543]
===
match
---
name: external_trigger [80661,80677]
name: external_trigger [80661,80677]
===
match
---
operator: { [97999,98000]
operator: { [98098,98099]
===
match
---
operator: @ [101940,101941]
operator: @ [102039,102040]
===
match
---
expr_stmt [71584,71634]
expr_stmt [71584,71634]
===
match
---
atom_expr [84721,84756]
atom_expr [84820,84855]
===
match
---
name: TI [55410,55412]
name: TI [55410,55412]
===
match
---
name: self [89207,89211]
name: self [89306,89310]
===
match
---
name: bool [12381,12385]
name: bool [12381,12385]
===
match
---
name: fileloc [86800,86807]
name: fileloc [86899,86906]
===
match
---
operator: , [29564,29565]
operator: , [29564,29565]
===
match
---
argument [20776,20787]
argument [20776,20787]
===
match
---
operator: = [53328,53329]
operator: = [53328,53329]
===
match
---
name: include_subdags [68008,68023]
name: include_subdags [68008,68023]
===
match
---
name: include_subdags [65436,65451]
name: include_subdags [65436,65451]
===
match
---
name: include_parentdag [45839,45856]
name: include_parentdag [45839,45856]
===
match
---
name: task_dict [73378,73387]
name: task_dict [73378,73387]
===
match
---
name: dag [104107,104110]
name: dag [104206,104209]
===
match
---
name: log [37236,37239]
name: log [37236,37239]
===
match
---
atom_expr [89881,89894]
atom_expr [89980,89993]
===
match
---
trailer [15211,15226]
trailer [15211,15226]
===
match
---
expr_stmt [17198,17265]
expr_stmt [17198,17265]
===
match
---
trailer [40830,40845]
trailer [40830,40845]
===
match
---
name: self [104688,104692]
name: self [104787,104791]
===
match
---
name: Union [3360,3365]
name: Union [3360,3365]
===
match
---
name: self [17153,17157]
name: self [17153,17157]
===
match
---
arglist [79622,80140]
arglist [79622,80140]
===
match
---
tfpdef [43772,43780]
tfpdef [43772,43780]
===
match
---
argument [94284,94300]
argument [94383,94399]
===
match
---
name: SubDagOperator [41649,41663]
name: SubDagOperator [41649,41663]
===
match
---
operator: + [48378,48379]
operator: + [48378,48379]
===
match
---
name: RUNNING [38000,38007]
name: RUNNING [38000,38007]
===
match
---
trailer [76933,76937]
trailer [76933,76937]
===
match
---
comparison [91780,91789]
comparison [91879,91888]
===
match
---
name: set_is_paused [101271,101284]
name: set_is_paused [101370,101383]
===
match
---
simple_stmt [1972,2015]
simple_stmt [1972,2015]
===
match
---
name: perm [19812,19816]
name: perm [19812,19816]
===
match
---
atom_expr [34991,35002]
atom_expr [34991,35002]
===
match
---
name: orm_dag [87684,87691]
name: orm_dag [87783,87790]
===
match
---
name: end_date [57979,57987]
name: end_date [57979,57987]
===
match
---
name: dags [84238,84242]
name: dags [84337,84341]
===
match
---
operator: = [14213,14214]
operator: = [14213,14214]
===
match
---
trailer [88071,88076]
trailer [88170,88175]
===
match
---
name: bool [55797,55801]
name: bool [55797,55801]
===
match
---
name: dttm [74244,74248]
name: dttm [74244,74248]
===
match
---
string: 'dags_are_paused_at_creation' [94878,94907]
string: 'dags_are_paused_at_creation' [94977,95006]
===
match
---
trailer [61217,61231]
trailer [61217,61231]
===
match
---
dotted_name [1458,1472]
dotted_name [1458,1472]
===
match
---
atom_expr [42695,42750]
atom_expr [42695,42750]
===
match
---
name: bool [101302,101306]
name: bool [101401,101405]
===
match
---
simple_stmt [2107,2148]
simple_stmt [2107,2148]
===
match
---
name: dag_id [48641,48647]
name: dag_id [48641,48647]
===
match
---
name: filter [49127,49133]
name: filter [49127,49133]
===
match
---
name: subdag_task_groups [72641,72659]
name: subdag_task_groups [72641,72659]
===
match
---
trailer [83522,83527]
trailer [83621,83626]
===
match
---
trailer [45047,45080]
trailer [45047,45080]
===
match
---
name: group [71565,71570]
name: group [71565,71570]
===
match
---
trailer [60631,60639]
trailer [60631,60639]
===
match
---
suite [53378,53462]
suite [53378,53462]
===
match
---
simple_stmt [82564,82644]
simple_stmt [82674,82754]
===
match
---
operator: = [96779,96780]
operator: = [96878,96879]
===
match
---
name: cli [80286,80289]
name: cli [80286,80289]
===
match
---
trailer [101124,101146]
trailer [101223,101245]
===
match
---
tfpdef [80614,80644]
tfpdef [80614,80644]
===
match
---
expr_stmt [61922,61977]
expr_stmt [61922,61977]
===
match
---
atom_expr [40373,40598]
atom_expr [40373,40598]
===
match
---
name: self [43151,43155]
name: self [43151,43155]
===
match
---
name: run_id [39862,39868]
name: run_id [39862,39868]
===
match
---
atom_expr [68690,68714]
atom_expr [68690,68714]
===
match
---
operator: = [88290,88291]
operator: = [88389,88390]
===
match
---
name: start_date [28031,28041]
name: start_date [28031,28041]
===
match
---
trailer [39900,39906]
trailer [39900,39906]
===
match
---
atom_expr [20271,20284]
atom_expr [20271,20284]
===
match
---
decorator [38147,38164]
decorator [38147,38164]
===
match
---
operator: = [50904,50905]
operator: = [50904,50905]
===
match
---
name: self [59548,59552]
name: self [59548,59552]
===
match
---
name: DR [3878,3880]
name: DR [3878,3880]
===
match
---
name: group [73019,73024]
name: group [73019,73024]
===
match
---
name: clear_dags [66450,66460]
name: clear_dags [66450,66460]
===
match
---
trailer [18550,18557]
trailer [18550,18557]
===
match
---
trailer [72132,72147]
trailer [72132,72147]
===
match
---
name: tis [37306,37309]
name: tis [37306,37309]
===
match
---
atom_expr [96894,96971]
atom_expr [96993,97070]
===
match
---
name: executor [79290,79298]
name: executor [79290,79298]
===
match
---
simple_stmt [27931,28002]
simple_stmt [27931,28002]
===
match
---
name: qry [34935,34938]
name: qry [34935,34938]
===
match
---
name: classmethod [66430,66441]
name: classmethod [66430,66441]
===
match
---
trailer [71247,71257]
trailer [71247,71257]
===
match
---
name: dry_run [67191,67198]
name: dry_run [67191,67198]
===
match
---
atom [73558,73589]
atom [73558,73589]
===
match
---
name: exclude_task_ids [46600,46616]
name: exclude_task_ids [46600,46616]
===
match
---
tfpdef [10997,11027]
tfpdef [10997,11027]
===
match
---
simple_stmt [96022,96049]
simple_stmt [96121,96148]
===
match
---
suite [42797,42855]
suite [42797,42855]
===
match
---
operator: = [96034,96035]
operator: = [96133,96134]
===
match
---
name: t [71306,71307]
name: t [71306,71307]
===
match
---
name: task [76753,76757]
name: task [76753,76757]
===
match
---
atom_expr [30559,30709]
atom_expr [30559,30709]
===
match
---
string: """         Calculate ``next_dagrun`` and `next_dagrun_create_after``          :param dag: The DAG object         :param most_recent_dag_run: DateTime of most recent run of this dag, or none if not yet scheduled.         :param active_runs_of_dag: Number of currently active runs of this dag         """ [104214,104517]
string: """         Calculate ``next_dagrun`` and `next_dagrun_create_after``          :param dag: The DAG object         :param most_recent_dag_run: DateTime of most recent run of this dag, or none if not yet scheduled.         :param active_runs_of_dag: Number of currently active runs of this dag         """ [104313,104616]
===
match
---
name: downstream_task_id [94101,94119]
name: downstream_task_id [94200,94218]
===
match
---
comparison [60627,60657]
comparison [60627,60657]
===
match
---
atom_expr [87221,87235]
atom_expr [87320,87334]
===
match
---
atom_expr [37423,37448]
atom_expr [37423,37448]
===
match
---
name: next_dagrun_data_interval [98717,98742]
name: next_dagrun_data_interval [98816,98841]
===
match
---
atom_expr [92079,92107]
atom_expr [92178,92206]
===
match
---
trailer [17331,17368]
trailer [17331,17368]
===
match
---
trailer [105142,105356]
trailer [105241,105455]
===
match
---
name: Union [1199,1204]
name: Union [1199,1204]
===
match
---
operator: * [45663,45664]
operator: * [45663,45664]
===
match
---
name: result [68787,68793]
name: result [68787,68793]
===
match
---
trailer [29050,29068]
trailer [29050,29068]
===
match
---
simple_stmt [35470,35652]
simple_stmt [35470,35652]
===
match
---
fstring_end: ' [16131,16132]
fstring_end: ' [16131,16132]
===
match
---
classdef [94434,105490]
classdef [94533,105589]
===
match
---
annassign [13854,13884]
annassign [13854,13884]
===
match
---
name: self [14743,14747]
name: self [14743,14747]
===
match
---
name: compat [1670,1676]
name: compat [1670,1676]
===
match
---
atom_expr [108968,108981]
atom_expr [109067,109080]
===
match
---
name: logging [824,831]
name: logging [824,831]
===
match
---
atom_expr [24363,24379]
atom_expr [24363,24379]
===
match
---
trailer [98679,98709]
trailer [98778,98808]
===
match
---
atom_expr [24444,24454]
atom_expr [24444,24454]
===
match
---
trailer [51995,52007]
trailer [51995,52007]
===
match
---
trailer [75868,75879]
trailer [75868,75879]
===
match
---
name: self [33036,33040]
name: self [33036,33040]
===
match
---
name: expiration_date [90029,90044]
name: expiration_date [90128,90143]
===
match
---
name: _schedule_interval [36049,36067]
name: _schedule_interval [36049,36067]
===
match
---
atom_expr [38839,38856]
atom_expr [38839,38856]
===
match
---
name: operator [51691,51699]
name: operator [51691,51699]
===
match
---
trailer [101915,101917]
trailer [102014,102016]
===
match
---
operator: @ [30485,30486]
operator: @ [30485,30486]
===
match
---
name: self [12841,12845]
name: self [12841,12845]
===
match
---
operator: ! [98408,98409]
operator: ! [98507,98508]
===
match
---
operator: = [58061,58062]
operator: = [58061,58062]
===
match
---
operator: , [21601,21602]
operator: , [21601,21602]
===
match
---
name: user_defined_filters [68730,68750]
name: user_defined_filters [68730,68750]
===
match
---
decorator [101246,101263]
decorator [101345,101362]
===
match
---
tfpdef [46985,47015]
tfpdef [46985,47015]
===
match
---
arglist [103990,104052]
arglist [104089,104151]
===
match
---
operator: , [65516,65517]
operator: , [65516,65517]
===
match
---
name: filter [84985,84991]
name: filter [85084,85090]
===
match
---
operator: } [33779,33780]
operator: } [33779,33780]
===
match
---
tfpdef [11395,11423]
tfpdef [11395,11423]
===
match
---
name: dag_id [85590,85596]
name: dag_id [85689,85695]
===
match
---
name: datetime [61394,61402]
name: datetime [61394,61402]
===
match
---
operator: , [46073,46074]
operator: , [46073,46074]
===
match
---
name: session [86325,86332]
name: session [86424,86431]
===
match
---
name: include_externally_triggered [29706,29734]
name: include_externally_triggered [29706,29734]
===
match
---
name: also_include [70748,70760]
name: also_include [70748,70760]
===
match
---
operator: = [104718,104719]
operator: = [104817,104818]
===
match
---
name: self [68924,68928]
name: self [68924,68928]
===
match
---
raise_stmt [73925,73972]
raise_stmt [73925,73972]
===
match
---
return_stmt [24704,24758]
return_stmt [24704,24758]
===
match
---
operator: , [61294,61295]
operator: , [61294,61295]
===
match
---
trailer [70968,70987]
trailer [70968,70987]
===
match
---
param [17755,17760]
param [17755,17760]
===
match
---
name: _get_task_instances [46273,46292]
name: _get_task_instances [46273,46292]
===
match
---
operator: = [107474,107475]
operator: = [107573,107574]
===
match
---
simple_stmt [3126,3177]
simple_stmt [3126,3177]
===
match
---
atom_expr [98082,98107]
atom_expr [98181,98206]
===
match
---
param [55756,55769]
param [55756,55769]
===
match
---
operator: , [105470,105471]
operator: , [105569,105570]
===
match
---
operator: , [65305,65306]
operator: , [65305,65306]
===
match
---
param [77304,77318]
param [77304,77318]
===
match
---
expr_stmt [104827,104875]
expr_stmt [104926,104974]
===
match
---
param [108738,108742]
param [108837,108841]
===
match
---
trailer [46856,46870]
trailer [46856,46870]
===
match
---
tfpdef [61304,61314]
tfpdef [61304,61314]
===
match
---
name: start_date [67787,67797]
name: start_date [67787,67797]
===
match
---
operator: != [29441,29443]
operator: != [29441,29443]
===
match
---
name: List [108672,108676]
name: List [108771,108775]
===
match
---
trailer [32499,32561]
trailer [32499,32561]
===
match
---
name: AttributeError [32485,32499]
name: AttributeError [32485,32499]
===
match
---
expr_stmt [84820,84852]
expr_stmt [84919,84951]
===
match
---
name: tii [53309,53312]
name: tii [53309,53312]
===
match
---
operator: , [47015,47016]
operator: , [47015,47016]
===
match
---
trailer [49762,49891]
trailer [49762,49891]
===
match
---
trailer [14828,14839]
trailer [14828,14839]
===
match
---
argument [54155,54178]
argument [54155,54178]
===
match
---
trailer [107870,107876]
trailer [107969,107975]
===
match
---
expr_stmt [91622,91705]
expr_stmt [91721,91804]
===
match
---
operator: , [26670,26671]
operator: , [26670,26671]
===
match
---
trailer [88031,88036]
trailer [88130,88135]
===
match
---
trailer [35037,35047]
trailer [35037,35047]
===
match
---
name: query [85817,85822]
name: query [85916,85921]
===
match
---
atom_expr [68826,68847]
atom_expr [68826,68847]
===
match
---
trailer [83111,83502]
trailer [83210,83601]
===
match
---
or_test [54644,54665]
or_test [54644,54665]
===
match
---
string: 'DagTag' [96250,96258]
string: 'DagTag' [96349,96357]
===
match
---
trailer [97786,97814]
trailer [97885,97913]
===
match
---
operator: = [79890,79891]
operator: = [79890,79891]
===
match
---
expr_stmt [53217,53257]
expr_stmt [53217,53257]
===
match
---
simple_stmt [2988,3038]
simple_stmt [2988,3038]
===
match
---
simple_stmt [59463,59509]
simple_stmt [59463,59509]
===
match
---
name: str [33561,33564]
name: str [33561,33564]
===
match
---
trailer [94321,94381]
trailer [94420,94480]
===
match
---
atom_expr [61930,61977]
atom_expr [61930,61977]
===
match
---
trailer [108837,108844]
trailer [108936,108943]
===
match
---
subscriptlist [47076,47090]
subscriptlist [47076,47090]
===
match
---
name: filter [90451,90457]
name: filter [90550,90556]
===
match
---
atom_expr [15024,15055]
atom_expr [15024,15055]
===
match
---
param [55904,55933]
param [55904,55933]
===
match
---
trailer [50383,51122]
trailer [50383,51122]
===
match
---
arglist [96900,96970]
arglist [96999,97069]
===
match
---
name: on_failure_callback [16650,16669]
name: on_failure_callback [16650,16669]
===
match
---
name: subdag_task_groups [72747,72765]
name: subdag_task_groups [72747,72765]
===
match
---
name: _time_restriction [26484,26501]
name: _time_restriction [26484,26501]
===
match
---
name: len [67316,67319]
name: len [67316,67319]
===
match
---
funcdef [58739,61232]
funcdef [58739,61232]
===
match
---
name: get_downstream [75290,75304]
name: get_downstream [75290,75304]
===
match
---
name: DeprecationWarning [34672,34690]
name: DeprecationWarning [34672,34690]
===
match
---
param [75455,75460]
param [75455,75460]
===
match
---
name: _value [18884,18890]
name: _value [18884,18890]
===
match
---
trailer [91837,91844]
trailer [91936,91943]
===
match
---
simple_stmt [83925,84118]
simple_stmt [84024,84217]
===
match
---
argument [57721,57744]
argument [57721,57744]
===
match
---
operator: @ [108692,108693]
operator: @ [108791,108792]
===
match
---
operator: { [19784,19785]
operator: { [19784,19785]
===
match
---
trailer [99426,99432]
trailer [99525,99531]
===
match
---
name: id [74686,74688]
name: id [74686,74688]
===
match
---
suite [75342,75437]
suite [75342,75437]
===
match
---
string: '__dot__' [15694,15703]
string: '__dot__' [15694,15703]
===
match
---
atom_expr [46997,47015]
atom_expr [46997,47015]
===
match
---
atom_expr [36070,36110]
atom_expr [36070,36110]
===
match
---
string: 'on_success_callback' [92943,92964]
string: 'on_success_callback' [93042,93063]
===
match
---
operator: , [66202,66203]
operator: , [66202,66203]
===
match
---
parameters [84232,84276]
parameters [84331,84375]
===
match
---
operator: = [32313,32314]
operator: = [32313,32314]
===
match
---
simple_stmt [107469,107499]
simple_stmt [107568,107598]
===
match
---
return_stmt [65784,65792]
return_stmt [65784,65792]
===
match
---
param [43772,43781]
param [43772,43781]
===
match
---
trailer [68793,68800]
trailer [68793,68800]
===
match
---
trailer [27710,27723]
trailer [27710,27723]
===
match
---
trailer [86551,86553]
trailer [86650,86652]
===
match
---
name: timetable [23470,23479]
name: timetable [23470,23479]
===
match
---
trailer [104640,104666]
trailer [104739,104765]
===
match
---
name: isinstance [82277,82287]
name: isinstance [82301,82311]
===
match
---
trailer [55552,55559]
trailer [55552,55559]
===
match
---
name: params [68808,68814]
name: params [68808,68814]
===
match
---
name: end_date [44822,44830]
name: end_date [44822,44830]
===
match
---
operator: = [103999,104000]
operator: = [104098,104099]
===
match
---
name: session [103044,103051]
name: session [103143,103150]
===
match
---
name: self [76961,76965]
name: self [76961,76965]
===
match
---
operator: = [44712,44713]
operator: = [44712,44713]
===
match
---
atom_expr [109314,109338]
atom_expr [109413,109437]
===
match
---
operator: = [24441,24442]
operator: = [24441,24442]
===
match
---
param [18053,18058]
param [18053,18058]
===
match
---
name: recursion_depth [64412,64427]
name: recursion_depth [64412,64427]
===
match
---
string: r"^{}$" [50220,50227]
string: r"^{}$" [50220,50227]
===
match
---
atom_expr [53060,53095]
atom_expr [53060,53095]
===
match
---
trailer [103711,103717]
trailer [103810,103816]
===
match
---
suite [31916,31949]
suite [31916,31949]
===
match
---
name: value [30733,30738]
name: value [30733,30738]
===
match
---
expr_stmt [38773,38915]
expr_stmt [38773,38915]
===
match
---
trailer [60588,60602]
trailer [60588,60602]
===
match
---
name: copy [71285,71289]
name: copy [71285,71289]
===
match
---
trailer [24561,24570]
trailer [24561,24570]
===
match
---
name: conf [97723,97727]
name: conf [97822,97826]
===
match
---
name: common [56961,56967]
name: common [56961,56967]
===
match
---
trailer [26538,26554]
trailer [26538,26554]
===
match
---
operator: = [30731,30732]
operator: = [30731,30732]
===
match
---
operator: = [37954,37955]
operator: = [37954,37955]
===
match
---
name: utils [2845,2850]
name: utils [2845,2850]
===
match
---
name: ti_key [51749,51755]
name: ti_key [51749,51755]
===
match
---
atom_expr [54912,54953]
atom_expr [54912,54953]
===
match
---
param [88806,88811]
param [88905,88910]
===
match
---
name: Optional [15548,15556]
name: Optional [15548,15556]
===
match
---
not_test [27692,27701]
not_test [27692,27701]
===
match
---
trailer [3891,3898]
trailer [3891,3898]
===
match
---
dotted_name [31447,31468]
dotted_name [31447,31468]
===
match
---
decorator [39914,39931]
decorator [39914,39931]
===
match
---
trailer [52894,52898]
trailer [52894,52898]
===
match
---
name: TI [34209,34211]
name: TI [34209,34211]
===
match
---
name: self [34255,34259]
name: self [34255,34259]
===
match
---
name: int [46720,46723]
name: int [46720,46723]
===
match
---
expr_stmt [72098,72147]
expr_stmt [72098,72147]
===
match
---
trailer [80933,80953]
trailer [80933,80953]
===
match
---
name: Optional [12159,12167]
name: Optional [12159,12167]
===
match
---
trailer [100166,100168]
trailer [100265,100267]
===
match
---
simple_stmt [103606,103959]
simple_stmt [103705,104058]
===
match
---
name: self [17718,17722]
name: self [17718,17722]
===
match
---
decorator [34779,34796]
decorator [34779,34796]
===
match
---
operator: != [27724,27726]
operator: != [27724,27726]
===
match
---
name: self [98372,98376]
name: self [98471,98475]
===
match
---
fstring_string: `run_id` expected to be a str is  [82337,82370]
fstring_string: `run_id` expected to be a str is  [82361,82394]
===
match
---
atom_expr [61212,61231]
atom_expr [61212,61231]
===
match
---
simple_stmt [56944,57009]
simple_stmt [56944,57009]
===
match
---
operator: == [51700,51702]
operator: == [51700,51702]
===
match
---
simple_stmt [67284,67299]
simple_stmt [67284,67299]
===
match
---
operator: = [74502,74503]
operator: = [74502,74503]
===
match
---
operator: , [83295,83296]
operator: , [83394,83395]
===
match
---
trailer [19582,19613]
trailer [19582,19613]
===
match
---
operator: , [46659,46660]
operator: , [46659,46660]
===
match
---
trailer [21772,21906]
trailer [21772,21906]
===
match
---
comparison [82897,82926]
comparison [82996,83025]
===
match
---
name: t [70578,70579]
name: t [70578,70579]
===
match
---
name: intersection [72944,72956]
name: intersection [72944,72956]
===
match
---
atom_expr [27706,27723]
atom_expr [27706,27723]
===
match
---
name: count [65760,65765]
name: count [65760,65765]
===
match
---
name: tasks [33774,33779]
name: tasks [33774,33779]
===
match
---
name: folder [33386,33392]
name: folder [33386,33392]
===
match
---
name: isinstance [82514,82524]
name: isinstance [82624,82634]
===
match
---
trailer [73279,73301]
trailer [73279,73301]
===
match
---
name: DagRunType [82422,82432]
name: DagRunType [82467,82477]
===
match
---
simple_stmt [59209,59286]
simple_stmt [59209,59286]
===
match
---
expr_stmt [107350,107393]
expr_stmt [107449,107492]
===
match
---
comparison [89207,89232]
comparison [89306,89331]
===
match
---
atom_expr [34184,34316]
atom_expr [34184,34316]
===
match
---
trailer [91863,91867]
trailer [91962,91966]
===
match
---
param [80904,80962]
param [80904,80962]
===
match
---
operator: , [11963,11964]
operator: , [11963,11964]
===
match
---
not_test [79434,79446]
not_test [79434,79446]
===
match
---
name: type [17774,17778]
name: type [17774,17778]
===
match
---
expr_stmt [4027,4075]
expr_stmt [4027,4075]
===
match
---
name: DagStateChangeCallback [12073,12095]
name: DagStateChangeCallback [12073,12095]
===
match
---
name: node [60517,60521]
name: node [60517,60521]
===
match
---
and_test [33859,33926]
and_test [33859,33926]
===
match
---
atom_expr [55082,55093]
atom_expr [55082,55093]
===
match
---
name: state [34283,34288]
name: state [34283,34288]
===
match
---
operator: , [30672,30673]
operator: , [30672,30673]
===
match
---
tfpdef [46345,46375]
tfpdef [46345,46375]
===
match
---
operator: * [46956,46957]
operator: * [46956,46957]
===
match
---
name: Dict [16924,16928]
name: Dict [16924,16928]
===
match
---
simple_stmt [41490,41542]
simple_stmt [41490,41542]
===
match
---
name: globals [43193,43200]
name: globals [43193,43200]
===
match
---
operator: = [15627,15628]
operator: = [15627,15628]
===
match
---
expr_stmt [39612,39641]
expr_stmt [39612,39641]
===
match
---
atom [92494,93284]
atom [92593,93383]
===
match
---
strings [16014,16132]
strings [16014,16132]
===
match
---
simple_stmt [19903,20154]
simple_stmt [19903,20154]
===
match
---
name: execution_date [40485,40499]
name: execution_date [40485,40499]
===
match
---
name: list [87891,87895]
name: list [87990,87994]
===
match
---
name: str [99839,99842]
name: str [99938,99941]
===
match
---
funcdef [25344,28002]
funcdef [25344,28002]
===
match
---
string: "Sync %s DAGs" [84730,84744]
string: "Sync %s DAGs" [84829,84843]
===
match
---
name: next_dagrun_create_after [104893,104917]
name: next_dagrun_create_after [104992,105016]
===
match
---
string: 'scheduler' [97166,97177]
string: 'scheduler' [97265,97276]
===
match
---
atom_expr [53759,54609]
atom_expr [53759,54609]
===
match
---
trailer [71905,71914]
trailer [71905,71914]
===
match
---
simple_stmt [51623,51652]
simple_stmt [51623,51652]
===
match
---
name: str [46156,46159]
name: str [46156,46159]
===
match
---
operator: = [65690,65691]
operator: = [65690,65691]
===
match
---
test [107533,107572]
test [107632,107671]
===
match
---
trailer [72925,72943]
trailer [72925,72943]
===
match
---
trailer [54847,54854]
trailer [54847,54854]
===
match
---
operator: , [43780,43781]
operator: , [43780,43781]
===
match
---
name: dag_bag [65559,65566]
name: dag_bag [65559,65566]
===
match
---
argument [97213,97224]
argument [97312,97323]
===
match
---
name: tags [88032,88036]
name: tags [88131,88135]
===
match
---
trailer [15041,15055]
trailer [15041,15055]
===
match
---
number: 0 [68161,68162]
number: 0 [68161,68162]
===
match
---
name: self [18848,18852]
name: self [18848,18852]
===
match
---
name: TaskInstance [48201,48213]
name: TaskInstance [48201,48213]
===
match
---
atom_expr [51444,51453]
atom_expr [51444,51453]
===
match
---
atom_expr [91845,91873]
atom_expr [91944,91972]
===
match
---
name: Collection [83814,83824]
name: Collection [83913,83923]
===
match
---
trailer [95981,95987]
trailer [96080,96086]
===
match
---
operator: = [28882,28883]
operator: = [28882,28883]
===
match
---
operator: = [50295,50296]
operator: = [50295,50296]
===
match
---
name: datetime [982,990]
name: datetime [982,990]
===
match
---
name: self [104636,104640]
name: self [104735,104739]
===
match
---
atom_expr [74852,74869]
atom_expr [74852,74869]
===
match
---
name: str [69367,69370]
name: str [69367,69370]
===
match
---
name: as_pk_tuple [55203,55214]
name: as_pk_tuple [55203,55214]
===
match
---
trailer [33745,33750]
trailer [33745,33750]
===
match
---
simple_stmt [71546,71572]
simple_stmt [71546,71572]
===
match
---
name: utils_date_range [2815,2831]
name: utils_date_range [2815,2831]
===
match
---
simple_stmt [27200,27258]
simple_stmt [27200,27258]
===
match
---
name: edge_info [93658,93667]
name: edge_info [93757,93766]
===
match
---
if_stmt [26435,26511]
if_stmt [26435,26511]
===
match
---
decorator [32567,32577]
decorator [32567,32577]
===
match
---
operator: , [77022,77023]
operator: , [77022,77023]
===
match
---
param [46942,46947]
param [46942,46947]
===
match
---
operator: , [96869,96870]
operator: , [96968,96969]
===
match
---
atom_expr [72400,72441]
atom_expr [72400,72441]
===
match
---
trailer [52468,52811]
trailer [52468,52811]
===
match
---
simple_stmt [104751,104815]
simple_stmt [104850,104914]
===
match
---
parameters [73510,73530]
parameters [73510,73530]
===
match
---
suite [24818,25339]
suite [24818,25339]
===
match
---
name: default [95038,95045]
name: default [95137,95144]
===
match
---
simple_stmt [14886,14936]
simple_stmt [14886,14936]
===
match
---
name: commit [55942,55948]
name: commit [55942,55948]
===
match
---
suite [33843,33927]
suite [33843,33927]
===
match
---
name: check_cycle [80246,80257]
name: check_cycle [80246,80257]
===
match
---
arglist [70501,70540]
arglist [70501,70540]
===
match
---
name: LocalExecutor [79405,79418]
name: LocalExecutor [79405,79418]
===
match
---
name: orm_tag [87880,87887]
name: orm_tag [87979,87986]
===
match
---
return_stmt [19433,19444]
return_stmt [19433,19444]
===
match
---
operator: = [99680,99681]
operator: = [99779,99780]
===
match
---
trailer [42894,42904]
trailer [42894,42904]
===
match
---
trailer [11518,11554]
trailer [11518,11554]
===
match
---
name: name [107359,107363]
name: name [107458,107462]
===
match
---
atom_expr [31659,31676]
atom_expr [31659,31676]
===
match
---
param [73511,73516]
param [73511,73516]
===
match
---
name: earliest [27511,27519]
name: earliest [27511,27519]
===
match
---
name: tuple [18663,18668]
name: tuple [18663,18668]
===
match
---
name: delete [87992,87998]
name: delete [88091,88097]
===
match
---
name: Union [47478,47483]
name: Union [47478,47483]
===
match
---
trailer [22214,22226]
trailer [22214,22226]
===
match
---
name: start_date [67776,67786]
name: start_date [67776,67786]
===
match
---
operator: = [3547,3548]
operator: = [3547,3548]
===
match
---
trailer [11163,11190]
trailer [11163,11190]
===
match
---
trailer [15717,15733]
trailer [15717,15733]
===
match
---
name: full_filepath [11089,11102]
name: full_filepath [11089,11102]
===
match
---
name: mark_success [79719,79731]
name: mark_success [79719,79731]
===
match
---
operator: , [88810,88811]
operator: , [88909,88910]
===
match
---
name: node [60884,60888]
name: node [60884,60888]
===
match
---
name: filter [91528,91534]
name: filter [91627,91633]
===
match
---
name: edge [60627,60631]
name: edge [60627,60631]
===
match
---
name: coerce_datetime [28806,28821]
name: coerce_datetime [28806,28821]
===
match
---
simple_stmt [87406,87444]
simple_stmt [87505,87543]
===
match
---
suite [70832,70902]
suite [70832,70902]
===
match
---
trailer [25241,25251]
trailer [25241,25251]
===
match
---
decorated [90857,92242]
decorated [90956,92341]
===
match
---
name: DAG [106822,106825]
name: DAG [106921,106924]
===
match
---
name: restriction [27989,28000]
name: restriction [27989,28000]
===
match
---
name: query [34192,34197]
name: query [34192,34197]
===
match
---
name: start_date [76060,76070]
name: start_date [76060,76070]
===
match
---
suite [48387,48538]
suite [48387,48538]
===
match
---
operator: , [95036,95037]
operator: , [95135,95136]
===
match
---
trailer [12002,12026]
trailer [12002,12026]
===
match
---
trailer [80417,80429]
trailer [80417,80429]
===
match
---
simple_stmt [2249,2290]
simple_stmt [2249,2290]
===
match
---
suite [61506,62051]
suite [61506,62051]
===
match
---
simple_stmt [48833,48886]
simple_stmt [48833,48886]
===
match
---
operator: * [51425,51426]
operator: * [51425,51426]
===
match
---
trailer [72385,72397]
trailer [72385,72397]
===
match
---
operator: -> [31800,31802]
operator: -> [31800,31802]
===
match
---
suite [20457,20528]
suite [20457,20528]
===
match
---
name: missing_dag_ids [85272,85287]
name: missing_dag_ids [85371,85386]
===
match
---
name: TYPE_CHECKING [1057,1070]
name: TYPE_CHECKING [1057,1070]
===
match
---
name: dag [75427,75430]
name: dag [75427,75430]
===
match
---
operator: = [11118,11119]
operator: = [11118,11119]
===
match
---
name: t [87655,87656]
name: t [87754,87755]
===
match
---
name: Optional [22168,22176]
name: Optional [22168,22176]
===
match
---
operator: } [67578,67579]
operator: } [67578,67579]
===
match
---
trailer [33773,33779]
trailer [33773,33779]
===
match
---
name: k [68471,68472]
name: k [68471,68472]
===
match
---
suite [64642,64829]
suite [64642,64829]
===
match
---
name: include_upstream [69416,69432]
name: include_upstream [69416,69432]
===
match
---
simple_stmt [92165,92214]
simple_stmt [92264,92313]
===
match
---
name: group [72709,72714]
name: group [72709,72714]
===
match
---
name: self [24104,24108]
name: self [24104,24108]
===
match
---
operator: = [62192,62193]
operator: = [62192,62193]
===
match
---
name: filter [49594,49600]
name: filter [49594,49600]
===
match
---
operator: { [67588,67589]
operator: { [67588,67589]
===
match
---
operator: = [66706,66707]
operator: = [66706,66707]
===
match
---
suite [77691,80169]
suite [77691,80169]
===
match
---
argument [57140,57169]
argument [57140,57169]
===
match
---
suite [21641,21666]
suite [21641,21666]
===
match
---
simple_stmt [66063,66105]
simple_stmt [66063,66105]
===
match
---
name: pool [77536,77540]
name: pool [77536,77540]
===
match
---
param [31964,31969]
param [31964,31969]
===
match
---
and_test [82466,82493]
and_test [82511,82550]
===
match
---
name: classmethod [108693,108704]
name: classmethod [108792,108803]
===
match
---
name: next_dagrun_create_after [103793,103817]
name: next_dagrun_create_after [103892,103916]
===
match
---
trailer [88481,88497]
trailer [88580,88596]
===
match
---
fstring_string: they must be either both None or both datetime [98531,98577]
fstring_string: they must be either both None or both datetime [98630,98676]
===
match
---
name: task_group [3276,3286]
name: task_group [3276,3286]
===
match
---
name: Column [95569,95575]
name: Column [95668,95674]
===
match
---
name: property [33529,33537]
name: property [33529,33537]
===
match
---
name: include_externally_triggered [29808,29836]
name: include_externally_triggered [29808,29836]
===
match
---
operator: , [55993,55994]
operator: , [55993,55994]
===
match
---
name: TaskInstanceKey [47967,47982]
name: TaskInstanceKey [47967,47982]
===
match
---
param [73517,73529]
param [73517,73529]
===
match
---
suite [19740,19837]
suite [19740,19837]
===
match
---
simple_stmt [80408,80430]
simple_stmt [80408,80430]
===
match
---
trailer [94348,94362]
trailer [94447,94461]
===
match
---
simple_stmt [24540,24572]
simple_stmt [24540,24572]
===
match
---
trailer [61998,62050]
trailer [61998,62050]
===
match
---
name: nullable [96353,96361]
name: nullable [96452,96460]
===
match
---
simple_stmt [50370,51123]
simple_stmt [50370,51123]
===
match
---
name: upper [107871,107876]
name: upper [107970,107975]
===
match
---
atom_expr [14993,15010]
atom_expr [14993,15010]
===
match
---
param [31981,31993]
param [31981,31993]
===
match
---
simple_stmt [13739,13769]
simple_stmt [13739,13769]
===
match
---
trailer [84849,84851]
trailer [84948,84950]
===
match
---
name: task_ids [48811,48819]
name: task_ids [48811,48819]
===
match
---
atom_expr [19486,19528]
atom_expr [19486,19528]
===
match
---
name: run_backwards [80126,80139]
name: run_backwards [80126,80139]
===
match
---
trailer [99263,99271]
trailer [99362,99370]
===
match
---
suite [51732,54632]
suite [51732,54632]
===
match
---
arglist [49796,49864]
arglist [49796,49864]
===
match
---
name: cron_presets [36023,36035]
name: cron_presets [36023,36035]
===
match
---
atom_expr [14622,14651]
atom_expr [14622,14651]
===
match
---
name: session [84263,84270]
name: session [84362,84369]
===
match
---
atom_expr [59544,59559]
atom_expr [59544,59559]
===
match
---
name: self [17305,17309]
name: self [17305,17309]
===
match
---
name: get_is_paused [35079,35092]
name: get_is_paused [35079,35092]
===
match
---
dotted_name [2936,2967]
dotted_name [2936,2967]
===
match
---
name: dag [87833,87836]
name: dag [87932,87935]
===
match
---
name: back [107533,107537]
name: back [107632,107636]
===
match
---
atom_expr [17597,17606]
atom_expr [17597,17606]
===
match
---
suite [21111,21176]
suite [21111,21176]
===
match
---
name: dag [72583,72586]
name: dag [72583,72586]
===
match
---
or_test [14342,14392]
or_test [14342,14392]
===
match
---
name: tree_view [74962,74971]
name: tree_view [74962,74971]
===
match
---
trailer [44334,44341]
trailer [44334,44341]
===
match
---
name: session [33987,33994]
name: session [33987,33994]
===
match
---
simple_stmt [96230,96313]
simple_stmt [96329,96412]
===
match
---
atom_expr [104751,104781]
atom_expr [104850,104880]
===
match
---
string: """Exclude tasks not included in the subdag from the given TaskGroup.""" [71461,71533]
string: """Exclude tasks not included in the subdag from the given TaskGroup.""" [71461,71533]
===
match
---
decorated [31252,31360]
decorated [31252,31360]
===
match
---
name: tis [55619,55622]
name: tis [55619,55622]
===
match
---
operator: = [53493,53494]
operator: = [53493,53494]
===
match
---
name: as_pk_tuple [65499,65510]
name: as_pk_tuple [65499,65510]
===
match
---
param [104117,104166]
param [104216,104265]
===
match
---
trailer [14679,14692]
trailer [14679,14692]
===
match
---
trailer [15614,15626]
trailer [15614,15626]
===
match
---
operator: , [77620,77621]
operator: , [77620,77621]
===
match
---
name: end_date [20766,20774]
name: end_date [20766,20774]
===
match
---
operator: , [80807,80808]
operator: , [80807,80808]
===
match
---
operator: , [96956,96957]
operator: , [97055,97056]
===
match
---
atom [24443,24489]
atom [24443,24489]
===
match
---
atom_expr [33184,33196]
atom_expr [33184,33196]
===
match
---
dotted_name [1268,1290]
dotted_name [1268,1290]
===
match
---
simple_stmt [73887,73917]
simple_stmt [73887,73917]
===
match
---
name: end_date [24562,24570]
name: end_date [24562,24570]
===
match
---
atom_expr [49940,49981]
atom_expr [49940,49981]
===
match
---
name: external_trigger [38198,38214]
name: external_trigger [38198,38214]
===
match
---
name: children [71906,71914]
name: children [71906,71914]
===
match
---
atom_expr [11054,11072]
atom_expr [11054,11072]
===
match
---
name: String [94271,94277]
name: String [94370,94376]
===
match
---
operator: , [30161,30162]
operator: , [30161,30162]
===
match
---
name: self [35357,35361]
name: self [35357,35361]
===
match
---
name: traceback [74379,74388]
name: traceback [74379,74388]
===
match
---
name: Column [95293,95299]
name: Column [95392,95398]
===
match
---
name: Dict [11418,11422]
name: Dict [11418,11422]
===
match
---
name: is_active [90512,90521]
name: is_active [90611,90620]
===
match
---
operator: , [11685,11686]
operator: , [11685,11686]
===
match
---
name: property [100720,100728]
name: property [100819,100827]
===
match
---
name: log [90565,90568]
name: log [90664,90667]
===
match
---
operator: , [54511,54512]
operator: , [54511,54512]
===
match
---
atom_expr [33769,33779]
atom_expr [33769,33779]
===
match
---
funcdef [18105,18172]
funcdef [18105,18172]
===
match
---
expr_stmt [96754,96800]
expr_stmt [96853,96899]
===
match
---
name: downstream [57214,57224]
name: downstream [57214,57224]
===
match
---
simple_stmt [12508,12555]
simple_stmt [12508,12555]
===
match
---
name: orientation [16158,16169]
name: orientation [16158,16169]
===
match
---
trailer [73024,73044]
trailer [73024,73044]
===
match
---
name: str [10568,10571]
name: str [10568,10571]
===
match
---
operator: , [45058,45059]
operator: , [45058,45059]
===
match
---
operator: , [69437,69438]
operator: , [69437,69438]
===
match
---
name: file [2851,2855]
name: file [2851,2855]
===
match
---
name: include_subdags [48227,48242]
name: include_subdags [48227,48242]
===
match
---
atom_expr [14743,14772]
atom_expr [14743,14772]
===
match
---
decorated [33001,33363]
decorated [33001,33363]
===
match
---
name: info [90569,90573]
name: info [90668,90672]
===
match
---
operator: , [3369,3370]
operator: , [3369,3370]
===
match
---
operator: -> [58530,58532]
operator: -> [58530,58532]
===
match
---
atom_expr [21135,21175]
atom_expr [21135,21175]
===
match
---
name: subdag_lst [41917,41927]
name: subdag_lst [41917,41927]
===
match
---
comparison [74676,74705]
comparison [74676,74705]
===
match
---
name: is_paused_at_creation [94949,94970]
name: is_paused_at_creation [95048,95069]
===
match
---
name: update [43201,43207]
name: update [43201,43207]
===
match
---
operator: -> [31908,31910]
operator: -> [31908,31910]
===
match
---
atom_expr [74220,74249]
atom_expr [74220,74249]
===
match
---
param [103039,103043]
param [103138,103142]
===
match
---
operator: , [76429,76430]
operator: , [76429,76430]
===
match
---
simple_stmt [30718,30739]
simple_stmt [30718,30739]
===
match
---
operator: = [99569,99570]
operator: = [99668,99669]
===
match
---
simple_stmt [16908,16964]
simple_stmt [16908,16964]
===
match
---
trailer [3319,3329]
trailer [3319,3329]
===
match
---
operator: = [41562,41563]
operator: = [41562,41563]
===
match
---
atom_expr [24274,24289]
atom_expr [24274,24289]
===
match
---
name: in_ [89841,89844]
name: in_ [89940,89943]
===
match
---
atom_expr [43303,43328]
atom_expr [43303,43328]
===
match
---
name: FileSystemLoader [42477,42493]
name: FileSystemLoader [42477,42493]
===
match
---
name: parse [53069,53074]
name: parse [53069,53074]
===
match
---
param [10844,10849]
param [10844,10849]
===
match
---
name: conf [77611,77615]
name: conf [77611,77615]
===
match
---
operator: -> [56001,56003]
operator: -> [56001,56003]
===
match
---
name: query [38773,38778]
name: query [38773,38778]
===
match
---
suite [89121,89354]
suite [89220,89453]
===
match
---
operator: = [57191,57192]
operator: = [57191,57192]
===
match
---
name: str [100393,100396]
name: str [100492,100495]
===
match
---
name: Tuple [46804,46809]
name: Tuple [46804,46809]
===
match
---
name: include_downstream [69382,69400]
name: include_downstream [69382,69400]
===
match
---
param [46563,46591]
param [46563,46591]
===
match
---
name: self [42286,42290]
name: self [42286,42290]
===
match
---
atom_expr [60530,60553]
atom_expr [60530,60553]
===
match
---
arglist [19806,19816]
arglist [19806,19816]
===
match
---
name: other [17755,17760]
name: other [17755,17760]
===
match
---
atom_expr [101706,101726]
atom_expr [101805,101825]
===
match
---
name: ORIENTATION_PRESETS [3476,3495]
name: ORIENTATION_PRESETS [3476,3495]
===
match
---
name: TI [51539,51541]
name: TI [51539,51541]
===
match
---
arglist [95029,95051]
arglist [95128,95150]
===
match
---
comparison [35247,35277]
comparison [35247,35277]
===
match
---
param [44837,44848]
param [44837,44848]
===
match
---
trailer [29896,30015]
trailer [29896,30015]
===
match
---
atom_expr [24041,24055]
atom_expr [24041,24055]
===
match
---
name: subdag_lst [41966,41976]
name: subdag_lst [41966,41976]
===
match
---
trailer [40884,40891]
trailer [40884,40891]
===
match
---
operator: , [100684,100685]
operator: , [100783,100784]
===
match
---
trailer [55577,55601]
trailer [55577,55601]
===
match
---
name: dag_id [61186,61192]
name: dag_id [61186,61192]
===
match
---
simple_stmt [100258,100328]
simple_stmt [100357,100427]
===
match
---
suite [49505,49892]
suite [49505,49892]
===
match
---
name: subdags [73813,73820]
name: subdags [73813,73820]
===
match
---
atom_expr [35029,35047]
atom_expr [35029,35047]
===
match
---
trailer [48756,48799]
trailer [48756,48799]
===
match
---
atom_expr [73058,73078]
atom_expr [73058,73078]
===
match
---
name: next_dagrun_create_after [103873,103897]
name: next_dagrun_create_after [103972,103996]
===
match
---
suite [19420,19445]
suite [19420,19445]
===
match
---
param [10879,10913]
param [10879,10913]
===
match
---
operator: , [50678,50679]
operator: , [50678,50679]
===
match
---
name: self [98121,98125]
name: self [98220,98224]
===
match
---
trailer [3982,3999]
trailer [3982,3999]
===
match
---
trailer [52984,52992]
trailer [52984,52992]
===
match
---
sync_comp_for [54855,54876]
sync_comp_for [54855,54876]
===
match
---
operator: = [17227,17228]
operator: = [17227,17228]
===
match
---
comparison [76507,76547]
comparison [76507,76547]
===
match
---
operator: , [71432,71433]
operator: , [71432,71433]
===
match
---
name: back [13819,13823]
name: back [13819,13823]
===
match
---
name: dp [74736,74738]
name: dp [74736,74738]
===
match
---
operator: , [66177,66178]
operator: , [66177,66178]
===
match
---
operator: , [1183,1184]
operator: , [1183,1184]
===
match
---
param [18059,18064]
param [18059,18064]
===
match
---
name: t [75261,75262]
name: t [75261,75262]
===
match
---
if_stmt [23130,23173]
if_stmt [23130,23173]
===
match
---
arglist [86688,86720]
arglist [86787,86819]
===
match
---
argument [75427,75435]
argument [75427,75435]
===
match
---
operator: = [65271,65272]
operator: = [65271,65272]
===
match
---
atom_expr [55369,55428]
atom_expr [55369,55428]
===
match
---
operator: , [82696,82697]
operator: , [82806,82807]
===
match
---
name: schedule_interval [24843,24860]
name: schedule_interval [24843,24860]
===
match
---
operator: , [1418,1419]
operator: , [1418,1419]
===
match
---
trailer [107374,107380]
trailer [107473,107479]
===
match
---
name: start_date [45048,45058]
name: start_date [45048,45058]
===
match
---
name: List [32361,32365]
name: List [32361,32365]
===
match
---
expr_stmt [66815,67218]
expr_stmt [66815,67218]
===
match
---
operator: = [88306,88307]
operator: = [88405,88406]
===
match
---
param [74462,74474]
param [74462,74474]
===
match
---
name: DagRun [39825,39831]
name: DagRun [39825,39831]
===
match
---
name: verbose [77588,77595]
name: verbose [77588,77595]
===
match
---
name: dag_id [3902,3908]
name: dag_id [3902,3908]
===
match
---
trailer [86153,86160]
trailer [86252,86259]
===
match
---
operator: = [87191,87192]
operator: = [87290,87291]
===
match
---
trailer [76435,76444]
trailer [76435,76444]
===
match
---
suite [68848,68885]
suite [68848,68885]
===
match
---
simple_stmt [1453,1514]
simple_stmt [1453,1514]
===
match
---
atom_expr [46395,46413]
atom_expr [46395,46413]
===
match
---
name: DagRun [85987,85993]
name: DagRun [86086,86092]
===
match
---
operator: , [64291,64292]
operator: , [64291,64292]
===
match
---
operator: , [104165,104166]
operator: , [104264,104265]
===
match
---
trailer [55016,55190]
trailer [55016,55190]
===
match
---
name: self [61710,61714]
name: self [61710,61714]
===
match
---
name: callback [37284,37292]
name: callback [37284,37292]
===
match
---
arglist [25131,25144]
arglist [25131,25144]
===
match
---
suite [73784,73917]
suite [73784,73917]
===
match
---
trailer [12980,12985]
trailer [12980,12985]
===
match
---
name: Set [46146,46149]
name: Set [46146,46149]
===
match
---
atom_expr [91998,92130]
atom_expr [92097,92229]
===
match
---
name: session [88748,88755]
name: session [88847,88854]
===
match
---
simple_stmt [17305,17385]
simple_stmt [17305,17385]
===
match
---
name: session [83833,83840]
name: session [83932,83939]
===
match
---
comparison [18345,18360]
comparison [18345,18360]
===
match
---
import_as_names [2358,2396]
import_as_names [2358,2396]
===
match
---
trailer [29429,29440]
trailer [29429,29440]
===
match
---
atom_expr [12418,12427]
atom_expr [12418,12427]
===
match
---
import_name [857,870]
import_name [857,870]
===
match
---
comparison [28845,28861]
comparison [28845,28861]
===
match
---
trailer [35229,35239]
trailer [35229,35239]
===
match
---
simple_stmt [75223,75248]
simple_stmt [75223,75248]
===
match
---
expr_stmt [70360,70421]
expr_stmt [70360,70421]
===
match
---
atom_expr [32634,32655]
atom_expr [32634,32655]
===
match
---
name: String [95975,95981]
name: String [96074,96080]
===
match
---
operator: } [61192,61193]
operator: } [61192,61193]
===
match
---
operator: , [17959,17960]
operator: , [17959,17960]
===
match
---
operator: , [43791,43792]
operator: , [43791,43792]
===
match
---
simple_stmt [1749,1833]
simple_stmt [1749,1833]
===
match
---
name: downstream_task_ids [73025,73044]
name: downstream_task_ids [73025,73044]
===
match
---
trailer [98924,98954]
trailer [99023,99053]
===
match
---
string: 'loader' [42460,42468]
string: 'loader' [42460,42468]
===
match
---
name: filter [49355,49361]
name: filter [49355,49361]
===
match
---
name: session [44724,44731]
name: session [44724,44731]
===
match
---
atom_expr [52494,52789]
atom_expr [52494,52789]
===
match
---
atom_expr [107996,108019]
atom_expr [108095,108118]
===
match
---
name: SubDagOperator [60955,60969]
name: SubDagOperator [60955,60969]
===
match
---
operator: , [1163,1164]
operator: , [1163,1164]
===
match
---
atom_expr [47248,47263]
atom_expr [47248,47263]
===
match
---
trailer [103740,103750]
trailer [103839,103849]
===
match
---
name: TaskInstance [48757,48769]
name: TaskInstance [48757,48769]
===
match
---
operator: , [45862,45863]
operator: , [45862,45863]
===
match
---
operator: = [37130,37131]
operator: = [37130,37131]
===
match
---
trailer [14547,14560]
trailer [14547,14560]
===
match
---
operator: , [30414,30415]
operator: , [30414,30415]
===
match
---
name: max_active_tasks [13577,13593]
name: max_active_tasks [13577,13593]
===
match
---
name: donot_pickle [79776,79788]
name: donot_pickle [79776,79788]
===
match
---
simple_stmt [42147,42181]
simple_stmt [42147,42181]
===
match
---
name: UtcDateTime [95300,95311]
name: UtcDateTime [95399,95410]
===
match
---
atom_expr [70394,70414]
atom_expr [70394,70414]
===
match
---
name: render_template_as_native_obj [17559,17588]
name: render_template_as_native_obj [17559,17588]
===
match
---
name: env [42810,42813]
name: env [42810,42813]
===
match
---
name: _task_group [76907,76918]
name: _task_group [76907,76918]
===
match
---
name: default_args [15029,15041]
name: default_args [15029,15041]
===
match
---
string: 'end_date' [14761,14771]
string: 'end_date' [14761,14771]
===
match
---
name: String [94693,94699]
name: String [94792,94798]
===
match
---
atom_expr [11104,11117]
atom_expr [11104,11117]
===
match
---
name: start [21705,21710]
name: start [21705,21710]
===
match
---
funcdef [35707,36337]
funcdef [35707,36337]
===
match
---
suite [48727,48800]
suite [48727,48800]
===
match
---
operator: = [85049,85050]
operator: = [85148,85149]
===
match
---
trailer [86713,86720]
trailer [86812,86819]
===
match
---
name: self [40449,40453]
name: self [40449,40453]
===
match
---
atom_expr [74692,74705]
atom_expr [74692,74705]
===
match
---
trailer [34221,34228]
trailer [34221,34228]
===
match
---
param [101989,101993]
param [102088,102092]
===
match
---
operator: = [11911,11912]
operator: = [11911,11912]
===
match
---
if_stmt [67441,67681]
if_stmt [67441,67681]
===
match
---
name: Session [61349,61356]
name: Session [61349,61356]
===
match
---
name: Text [96043,96047]
name: Text [96142,96146]
===
match
---
name: datetime [45751,45759]
name: datetime [45751,45759]
===
match
---
operator: , [45501,45502]
operator: , [45501,45502]
===
match
---
fstring_string: , but get  [16107,16117]
fstring_string: , but get  [16107,16117]
===
match
---
argument [83157,83170]
argument [83256,83269]
===
match
---
string: 'core' [97735,97741]
string: 'core' [97834,97840]
===
match
---
name: Optional [80758,80766]
name: Optional [80758,80766]
===
match
---
operator: , [71803,71804]
operator: , [71803,71804]
===
match
---
trailer [107544,107556]
trailer [107643,107655]
===
match
---
atom_expr [18632,18641]
atom_expr [18632,18641]
===
match
---
funcdef [33542,33782]
funcdef [33542,33782]
===
match
---
name: log [74298,74301]
name: log [74298,74301]
===
match
---
name: schedule_interval [87464,87481]
name: schedule_interval [87563,87580]
===
match
---
name: DagModel [84939,84947]
name: DagModel [85038,85046]
===
match
---
operator: = [57089,57090]
operator: = [57089,57090]
===
match
---
name: warn [35794,35798]
name: warn [35794,35798]
===
match
---
atom_expr [103737,103750]
atom_expr [103836,103849]
===
match
---
param [66572,66591]
param [66572,66591]
===
match
---
atom_expr [102340,102438]
atom_expr [102439,102537]
===
match
---
suite [88077,88425]
suite [88176,88524]
===
match
---
operator: , [92631,92632]
operator: , [92730,92731]
===
match
---
simple_stmt [67745,68127]
simple_stmt [67745,68127]
===
match
---
trailer [24556,24571]
trailer [24556,24571]
===
match
---
name: SandboxedEnvironment [42905,42925]
name: SandboxedEnvironment [42905,42925]
===
match
---
operator: = [90939,90940]
operator: = [91038,91039]
===
match
---
expr_stmt [71647,71682]
expr_stmt [71647,71682]
===
match
---
name: max_ [85843,85847]
name: max_ [85942,85946]
===
match
---
operator: = [99061,99062]
operator: = [99160,99161]
===
match
---
operator: , [41246,41247]
operator: , [41246,41247]
===
match
---
simple_stmt [88265,88319]
simple_stmt [88364,88418]
===
match
---
suite [74000,74419]
suite [74000,74419]
===
match
---
operator: , [79848,79849]
operator: , [79848,79849]
===
match
---
trailer [15913,15927]
trailer [15913,15927]
===
match
---
suite [77210,77243]
suite [77210,77243]
===
match
---
simple_stmt [56032,56936]
simple_stmt [56032,56936]
===
match
---
number: 2 [97592,97593]
number: 2 [97691,97692]
===
match
---
name: dagcode [1992,1999]
name: dagcode [1992,1999]
===
match
---
name: with_row_locks [103975,103989]
name: with_row_locks [104074,104088]
===
match
---
name: Tuple [46150,46155]
name: Tuple [46150,46155]
===
match
---
name: intersection [72734,72746]
name: intersection [72734,72746]
===
match
---
fstring_string: \n\nAre you sure? (yes/no):  [67597,67625]
fstring_string: \n\nAre you sure? (yes/no):  [67597,67625]
===
match
---
trailer [49278,49284]
trailer [49278,49284]
===
match
---
name: deepcopy [68633,68641]
name: deepcopy [68633,68641]
===
match
---
trailer [24346,24362]
trailer [24346,24362]
===
match
---
string: 'all,delete-orphan' [96268,96287]
string: 'all,delete-orphan' [96367,96386]
===
match
---
operator: , [93041,93042]
operator: , [93140,93141]
===
match
---
name: dag_hash [83397,83405]
name: dag_hash [83496,83504]
===
match
---
string: 'start_date' [14199,14211]
string: 'start_date' [14199,14211]
===
match
---
arglist [83952,84107]
arglist [84051,84206]
===
match
---
name: str [46815,46818]
name: str [46815,46818]
===
match
---
name: end_date [49064,49072]
name: end_date [49064,49072]
===
match
---
suite [68501,68652]
suite [68501,68652]
===
match
---
simple_stmt [53482,53700]
simple_stmt [53482,53700]
===
match
---
suite [31404,31441]
suite [31404,31441]
===
match
---
name: max_recursion_depth [62480,62499]
name: max_recursion_depth [62480,62499]
===
match
---
suite [85288,85668]
suite [85387,85767]
===
match
---
name: orm_dag [87456,87463]
name: orm_dag [87555,87562]
===
match
---
operator: = [27205,27206]
operator: = [27205,27206]
===
match
---
atom_expr [107004,107018]
atom_expr [107103,107117]
===
match
---
name: session [84160,84167]
name: session [84259,84266]
===
match
---
simple_stmt [30272,30293]
simple_stmt [30272,30293]
===
match
---
trailer [87836,87843]
trailer [87935,87942]
===
match
---
subscriptlist [3366,3395]
subscriptlist [3366,3395]
===
match
---
atom_expr [34841,34855]
atom_expr [34841,34855]
===
match
---
test [57872,57908]
test [57872,57908]
===
match
---
name: _dag_id [30114,30121]
name: _dag_id [30114,30121]
===
match
---
trailer [37177,37197]
trailer [37177,37197]
===
match
---
name: datetime [47044,47052]
name: datetime [47044,47052]
===
match
---
name: self [34413,34417]
name: self [34413,34417]
===
match
---
argument [13473,13485]
argument [13473,13485]
===
match
---
name: datetime [80934,80942]
name: datetime [80934,80942]
===
match
---
name: dag_id [83125,83131]
name: dag_id [83224,83230]
===
match
---
atom [19687,19689]
atom [19687,19689]
===
match
---
name: Path [101057,101061]
name: Path [101156,101160]
===
match
---
atom_expr [105133,105356]
atom_expr [105232,105455]
===
match
---
atom_expr [85460,85477]
atom_expr [85559,85576]
===
match
---
param [30163,30173]
param [30163,30173]
===
match
---
atom_expr [61839,61888]
atom_expr [61839,61888]
===
match
---
name: dag_id [105262,105268]
name: dag_id [105361,105367]
===
match
---
import_from [1972,2014]
import_from [1972,2014]
===
match
---
arglist [71299,71318]
arglist [71299,71318]
===
match
---
atom_expr [100078,100238]
atom_expr [100177,100337]
===
match
---
atom_expr [83561,83568]
atom_expr [83660,83667]
===
match
---
simple_stmt [53403,53462]
simple_stmt [53403,53462]
===
match
---
name: _task_group [17627,17638]
name: _task_group [17627,17638]
===
match
---
simple_stmt [48611,48705]
simple_stmt [48611,48705]
===
match
---
expr_stmt [102922,102948]
expr_stmt [103021,103047]
===
match
---
expr_stmt [105369,105405]
expr_stmt [105468,105504]
===
match
---
import_from [2491,2540]
import_from [2491,2540]
===
match
---
name: functools [75403,75412]
name: functools [75403,75412]
===
match
---
atom [16961,16963]
atom [16961,16963]
===
match
---
argument [45224,45241]
argument [45224,45241]
===
match
---
simple_stmt [85040,85109]
simple_stmt [85139,85208]
===
match
---
name: id [70368,70370]
name: id [70368,70370]
===
match
---
trailer [37600,37609]
trailer [37600,37609]
===
match
---
atom_expr [99240,99316]
atom_expr [99339,99415]
===
match
---
trailer [96787,96800]
trailer [96886,96899]
===
match
---
trailer [18826,18832]
trailer [18826,18832]
===
match
---
simple_stmt [788,800]
simple_stmt [788,800]
===
match
---
atom_expr [108845,108869]
atom_expr [108944,108968]
===
match
---
operator: , [11332,11333]
operator: , [11332,11333]
===
match
---
param [80483,80488]
param [80483,80488]
===
match
---
trailer [68879,68884]
trailer [68879,68884]
===
match
---
expr_stmt [92423,93284]
expr_stmt [92522,93383]
===
match
---
arglist [48628,48703]
arglist [48628,48703]
===
match
---
trailer [102684,102694]
trailer [102783,102793]
===
match
---
operator: = [26528,26529]
operator: = [26528,26529]
===
match
---
trailer [19775,19781]
trailer [19775,19781]
===
match
---
trailer [68439,68449]
trailer [68439,68449]
===
match
---
operator: = [85326,85327]
operator: = [85425,85426]
===
match
---
name: list [32396,32400]
name: list [32396,32400]
===
match
---
param [28031,28042]
param [28031,28042]
===
match
---
trailer [11372,11378]
trailer [11372,11378]
===
match
---
fstring_string:  is not a valid DAG.schedule_interval. [25298,25336]
fstring_string:  is not a valid DAG.schedule_interval. [25298,25336]
===
match
---
atom_expr [67647,67680]
atom_expr [67647,67680]
===
match
---
name: session [51525,51532]
name: session [51525,51532]
===
match
---
param [68924,68929]
param [68924,68929]
===
match
---
number: 2 [30439,30440]
number: 2 [30439,30440]
===
match
---
name: next_dagrun [104674,104685]
name: next_dagrun [104773,104784]
===
match
---
suite [16193,16237]
suite [16193,16237]
===
match
---
operator: , [77294,77295]
operator: , [77294,77295]
===
match
---
atom_expr [26479,26510]
atom_expr [26479,26510]
===
match
---
trailer [37360,37364]
trailer [37360,37364]
===
match
---
name: commit [74890,74896]
name: commit [74890,74896]
===
match
---
name: provide_session [3022,3037]
name: provide_session [3022,3037]
===
match
---
name: next_dagrun_info [104549,104565]
name: next_dagrun_info [104648,104664]
===
match
---
operator: = [73017,73018]
operator: = [73017,73018]
===
match
---
comparison [44582,44598]
comparison [44582,44598]
===
match
---
name: parent_dag [15536,15546]
name: parent_dag [15536,15546]
===
match
---
name: timezone [99092,99100]
name: timezone [99191,99199]
===
match
---
name: value [107387,107392]
name: value [107486,107491]
===
match
---
trailer [102349,102438]
trailer [102448,102537]
===
match
---
trailer [50252,50257]
trailer [50252,50257]
===
match
---
param [77376,77390]
param [77376,77390]
===
match
---
trailer [73387,73392]
trailer [73387,73392]
===
match
---
name: DagBag [1965,1971]
name: DagBag [1965,1971]
===
match
---
tfpdef [12403,12428]
tfpdef [12403,12428]
===
match
---
dotted_name [1977,1999]
dotted_name [1977,1999]
===
match
---
atom_expr [34536,34727]
atom_expr [34536,34727]
===
match
---
name: dag [48358,48361]
name: dag [48358,48361]
===
match
---
name: self [18116,18120]
name: self [18116,18120]
===
match
---
trailer [31837,31848]
trailer [31837,31848]
===
match
---
trailer [33508,33522]
trailer [33508,33522]
===
match
---
return_stmt [58431,58493]
return_stmt [58431,58493]
===
match
---
param [29566,29600]
param [29566,29600]
===
match
---
string: 'timezone' [14360,14370]
string: 'timezone' [14360,14370]
===
match
---
suite [43418,43664]
suite [43418,43664]
===
match
---
operator: = [30438,30439]
operator: = [30438,30439]
===
match
---
name: BaseOperator [71805,71817]
name: BaseOperator [71805,71817]
===
match
---
suite [14595,14815]
suite [14595,14815]
===
match
---
atom_expr [39842,39853]
atom_expr [39842,39853]
===
match
---
trailer [85319,85342]
trailer [85418,85441]
===
match
---
trailer [92001,92008]
trailer [92100,92107]
===
match
---
expr_stmt [37949,38008]
expr_stmt [37949,38008]
===
match
---
expr_stmt [86735,86767]
expr_stmt [86834,86866]
===
match
---
name: self [18253,18257]
name: self [18253,18257]
===
match
---
suite [27282,27548]
suite [27282,27548]
===
match
---
name: task_id [52985,52992]
name: task_id [52985,52992]
===
match
---
name: dag_id [99459,99465]
name: dag_id [99558,99564]
===
match
---
name: self [68690,68694]
name: self [68690,68694]
===
match
---
operator: @ [33932,33933]
operator: @ [33932,33933]
===
match
---
operator: * [106120,106121]
operator: * [106219,106220]
===
match
---
simple_stmt [76201,76231]
simple_stmt [76201,76231]
===
match
---
name: session [62408,62415]
name: session [62408,62415]
===
match
---
trailer [104155,104164]
trailer [104254,104263]
===
match
---
name: jinja_environment_kwargs [12293,12317]
name: jinja_environment_kwargs [12293,12317]
===
match
---
atom_expr [35997,36019]
atom_expr [35997,36019]
===
match
---
operator: { [76660,76661]
operator: { [76660,76661]
===
match
---
operator: = [77411,77412]
operator: = [77411,77412]
===
match
---
operator: ... [46880,46883]
operator: ... [46880,46883]
===
match
---
name: Callable [3549,3557]
name: Callable [3549,3557]
===
match
---
atom_expr [12206,12220]
atom_expr [12206,12220]
===
match
---
return_stmt [24902,24924]
return_stmt [24902,24924]
===
match
---
trailer [85658,85667]
trailer [85757,85766]
===
match
---
operator: = [62118,62119]
operator: = [62118,62119]
===
match
---
name: dag [73801,73804]
name: dag [73801,73804]
===
match
---
operator: , [65574,65575]
operator: , [65574,65575]
===
match
---
name: include_parentdag [66660,66677]
name: include_parentdag [66660,66677]
===
match
---
simple_stmt [31925,31949]
simple_stmt [31925,31949]
===
match
---
string: """         Set the state of a TaskInstance to the given state, and clear its downstream tasks that are         in failed or upstream_failed state.          :param task_id: Task ID of the TaskInstance         :type task_id: str         :param execution_date: execution_date of the TaskInstance         :type execution_date: datetime         :param state: State to set the TaskInstance to         :type state: State         :param upstream: Include all upstream tasks of the given task_id         :type upstream: bool         :param downstream: Include all downstream tasks of the given task_id         :type downstream: bool         :param future: Include all future TaskInstances of the given task_id         :type future: bool         :param commit: Commit changes         :type commit: bool         :param past: Include all past TaskInstances of the given task_id         :type past: bool         """ [56032,56935]
string: """         Set the state of a TaskInstance to the given state, and clear its downstream tasks that are         in failed or upstream_failed state.          :param task_id: Task ID of the TaskInstance         :type task_id: str         :param execution_date: execution_date of the TaskInstance         :type execution_date: datetime         :param state: State to set the TaskInstance to         :type state: State         :param upstream: Include all upstream tasks of the given task_id         :type upstream: bool         :param downstream: Include all downstream tasks of the given task_id         :type downstream: bool         :param future: Include all future TaskInstances of the given task_id         :type future: bool         :param commit: Commit changes         :type commit: bool         :param past: Include all past TaskInstances of the given task_id         :type past: bool         """ [56032,56935]
===
match
---
operator: = [87236,87237]
operator: = [87335,87336]
===
match
---
trailer [74196,74217]
trailer [74196,74217]
===
match
---
name: self [98468,98472]
name: self [98567,98571]
===
match
---
trailer [54918,54925]
trailer [54918,54925]
===
match
---
name: append [41881,41887]
name: append [41881,41887]
===
match
---
name: mark_success [77327,77339]
name: mark_success [77327,77339]
===
match
---
name: dag [73374,73377]
name: dag [73374,73377]
===
match
---
trailer [95974,95988]
trailer [96073,96087]
===
match
---
argument [42834,42853]
argument [42834,42853]
===
match
---
arglist [106046,106069]
arglist [106145,106168]
===
match
---
suite [58315,58494]
suite [58315,58494]
===
match
---
not_test [58708,58732]
not_test [58708,58732]
===
match
---
simple_stmt [34428,34528]
simple_stmt [34428,34528]
===
match
---
trailer [84927,84971]
trailer [85026,85070]
===
match
---
name: dag_id [100776,100782]
name: dag_id [100875,100881]
===
match
---
name: dag_id [30150,30156]
name: dag_id [30150,30156]
===
match
---
and_expr [48443,48519]
and_expr [48443,48519]
===
match
---
atom_expr [46150,46175]
atom_expr [46150,46175]
===
match
---
atom_expr [15140,15157]
atom_expr [15140,15157]
===
match
---
name: bool [55841,55845]
name: bool [55841,55845]
===
match
---
return_stmt [34736,34773]
return_stmt [34736,34773]
===
match
---
name: next_dagrun_info [27222,27238]
name: next_dagrun_info [27222,27238]
===
match
---
name: catchup [21528,21535]
name: catchup [21528,21535]
===
match
---
decorator [33932,33949]
decorator [33932,33949]
===
match
---
name: next_info [21623,21632]
name: next_info [21623,21632]
===
match
---
param [62385,62399]
param [62385,62399]
===
match
---
name: timetable [21567,21576]
name: timetable [21567,21576]
===
match
---
name: task_ids [50448,50456]
name: task_ids [50448,50456]
===
match
---
if_stmt [18342,18476]
if_stmt [18342,18476]
===
match
---
atom_expr [73698,73712]
atom_expr [73698,73712]
===
match
---
operator: , [45468,45469]
operator: , [45468,45469]
===
match
---
name: max_recursion_depth [51007,51026]
name: max_recursion_depth [51007,51026]
===
match
---
number: 0 [59563,59564]
number: 0 [59563,59564]
===
match
---
atom_expr [104827,104843]
atom_expr [104926,104942]
===
match
---
string: 'safe_dag_id' [92587,92600]
string: 'safe_dag_id' [92686,92699]
===
match
---
suite [101009,101034]
suite [101108,101133]
===
match
---
parameters [74971,74977]
parameters [74971,74977]
===
match
---
name: dag [87377,87380]
name: dag [87476,87479]
===
match
---
comparison [104598,104622]
comparison [104697,104721]
===
match
---
suite [14393,14440]
suite [14393,14440]
===
match
---
operator: = [25502,25503]
operator: = [25502,25503]
===
match
---
trailer [88134,88139]
trailer [88233,88238]
===
match
---
name: tis [48746,48749]
name: tis [48746,48749]
===
match
---
atom_expr [26530,26564]
atom_expr [26530,26564]
===
match
---
name: airflow [1977,1984]
name: airflow [1977,1984]
===
match
---
argument [54362,54377]
argument [54362,54377]
===
match
---
atom_expr [52940,52960]
atom_expr [52940,52960]
===
match
---
return_stmt [31735,31760]
return_stmt [31735,31760]
===
match
---
expr_stmt [42810,42854]
expr_stmt [42810,42854]
===
match
---
name: property [31161,31169]
name: property [31161,31169]
===
match
---
if_stmt [70487,70739]
if_stmt [70487,70739]
===
match
---
name: upstream [55778,55786]
name: upstream [55778,55786]
===
match
---
trailer [76982,76998]
trailer [76982,76998]
===
match
---
simple_stmt [99853,100039]
simple_stmt [99952,100138]
===
match
---
trailer [33900,33918]
trailer [33900,33918]
===
match
---
return_stmt [43339,43349]
return_stmt [43339,43349]
===
match
---
name: keys [72874,72878]
name: keys [72874,72878]
===
match
---
operator: , [25387,25388]
operator: , [25387,25388]
===
match
---
operator: , [66512,66513]
operator: , [66512,66513]
===
match
---
name: Session [99816,99823]
name: Session [99915,99922]
===
match
---
name: self [15610,15614]
name: self [15610,15614]
===
match
---
simple_stmt [53720,54632]
simple_stmt [53720,54632]
===
match
---
simple_stmt [31124,31155]
simple_stmt [31124,31155]
===
match
---
number: 0 [87845,87846]
number: 0 [87944,87945]
===
match
---
operator: = [86701,86702]
operator: = [86800,86801]
===
match
---
param [32594,32598]
param [32594,32598]
===
match
---
name: airflow [2295,2302]
name: airflow [2295,2302]
===
match
---
simple_stmt [31514,31585]
simple_stmt [31514,31585]
===
match
---
expr_stmt [87456,87505]
expr_stmt [87555,87604]
===
match
---
name: self [24838,24842]
name: self [24838,24842]
===
match
---
name: Collection [1090,1100]
name: Collection [1090,1100]
===
match
---
name: TaskInstance [91845,91857]
name: TaskInstance [91944,91956]
===
match
---
trailer [27510,27528]
trailer [27510,27528]
===
match
---
operator: , [61490,61491]
operator: , [61490,61491]
===
match
---
atom_expr [37312,37339]
atom_expr [37312,37339]
===
match
---
atom_expr [94315,94381]
atom_expr [94414,94480]
===
match
---
if_stmt [72245,72346]
if_stmt [72245,72346]
===
match
---
tfpdef [11342,11378]
tfpdef [11342,11378]
===
match
---
operator: , [21061,21062]
operator: , [21061,21062]
===
match
---
decorator [35693,35703]
decorator [35693,35703]
===
match
---
name: info [24041,24045]
name: info [24041,24045]
===
match
---
operator: , [67128,67129]
operator: , [67128,67129]
===
match
---
name: Optional [80584,80592]
name: Optional [80584,80592]
===
match
---
expr_stmt [55363,55428]
expr_stmt [55363,55428]
===
match
---
name: include_direct_upstream [69447,69470]
name: include_direct_upstream [69447,69470]
===
match
---
operator: -> [30542,30544]
operator: -> [30542,30544]
===
match
---
parameters [18052,18065]
parameters [18052,18065]
===
match
---
tfpdef [31970,31979]
tfpdef [31970,31979]
===
match
---
trailer [37664,37674]
trailer [37664,37674]
===
match
---
trailer [102547,102555]
trailer [102646,102654]
===
match
---
name: DagModel [35230,35238]
name: DagModel [35230,35238]
===
match
---
operator: = [74377,74378]
operator: = [74377,74378]
===
match
---
trailer [68729,68750]
trailer [68729,68750]
===
match
---
name: append [18551,18557]
name: append [18551,18557]
===
match
---
operator: = [3862,3863]
operator: = [3862,3863]
===
match
---
name: str [61479,61482]
name: str [61479,61482]
===
match
---
name: dag_id [101735,101741]
name: dag_id [101834,101840]
===
match
---
parameters [90922,90972]
parameters [91021,91071]
===
match
---
name: user_defined_filters [11342,11362]
name: user_defined_filters [11342,11362]
===
match
---
operator: = [17487,17488]
operator: = [17487,17488]
===
match
---
param [39987,39999]
param [39987,39999]
===
match
---
name: default_args [12654,12666]
name: default_args [12654,12666]
===
match
---
operator: = [39122,39123]
operator: = [39122,39123]
===
match
---
name: task_type [41809,41818]
name: task_type [41809,41818]
===
match
---
comparison [70707,70737]
comparison [70707,70737]
===
match
---
name: re [878,880]
name: re [878,880]
===
match
---
trailer [60948,60970]
trailer [60948,60970]
===
match
---
simple_stmt [108803,108871]
simple_stmt [108902,108970]
===
match
---
trailer [91504,91526]
trailer [91603,91625]
===
match
---
parameters [75454,75466]
parameters [75454,75466]
===
match
---
name: dag [74498,74501]
name: dag [74498,74501]
===
match
---
name: stacklevel [41234,41244]
name: stacklevel [41234,41244]
===
match
---
name: task_id [71952,71959]
name: task_id [71952,71959]
===
match
---
atom_expr [24557,24570]
atom_expr [24557,24570]
===
match
---
simple_stmt [97984,98015]
simple_stmt [98083,98114]
===
match
---
name: past [57281,57285]
name: past [57281,57285]
===
match
---
suite [42138,43350]
suite [42138,43350]
===
match
---
name: session [57614,57621]
name: session [57614,57621]
===
match
---
operator: = [13667,13668]
operator: = [13667,13668]
===
match
---
operator: = [47392,47393]
operator: = [47392,47393]
===
match
---
operator: = [67480,67481]
operator: = [67480,67481]
===
match
---
operator: , [68582,68583]
operator: , [68582,68583]
===
match
---
if_stmt [52058,52312]
if_stmt [52058,52312]
===
match
---
name: Collection [46618,46628]
name: Collection [46618,46628]
===
match
---
trailer [108676,108681]
trailer [108775,108780]
===
match
---
name: task [57018,57022]
name: task [57018,57022]
===
match
---
name: dag [87738,87741]
name: dag [87837,87840]
===
match
---
name: filter [55466,55472]
name: filter [55466,55472]
===
match
---
arglist [65197,65622]
arglist [65197,65622]
===
match
---
operator: -> [100853,100855]
operator: -> [100952,100954]
===
match
---
name: filter [48843,48849]
name: filter [48843,48849]
===
match
---
trailer [80386,80397]
trailer [80386,80397]
===
match
---
expr_stmt [15423,15469]
expr_stmt [15423,15469]
===
match
---
trailer [18668,18685]
trailer [18668,18685]
===
match
---
string: "The 'can_dag_read' and 'can_dag_edit' permissions are deprecated. " [19934,20002]
string: "The 'can_dag_read' and 'can_dag_edit' permissions are deprecated. " [19934,20002]
===
match
---
name: set [71608,71611]
name: set [71608,71611]
===
match
---
simple_stmt [94830,94909]
simple_stmt [94929,95008]
===
match
---
trailer [75237,75247]
trailer [75237,75247]
===
match
---
name: state [3145,3150]
name: state [3145,3150]
===
match
---
atom_expr [92449,92491]
atom_expr [92548,92590]
===
match
---
atom [70367,70421]
atom [70367,70421]
===
match
---
name: query [55456,55461]
name: query [55456,55461]
===
match
---
suite [20541,20803]
suite [20541,20803]
===
match
---
name: str [61311,61314]
name: str [61311,61314]
===
match
---
operator: = [70365,70366]
operator: = [70365,70366]
===
match
---
arith_expr [52332,52351]
arith_expr [52332,52351]
===
match
---
operator: -> [32697,32699]
operator: -> [32697,32699]
===
match
---
trailer [31424,31440]
trailer [31424,31440]
===
match
---
name: visited_external_tis [51069,51089]
name: visited_external_tis [51069,51089]
===
match
---
dictorsetmaker [37540,37556]
dictorsetmaker [37540,37556]
===
match
---
name: run_type [83357,83365]
name: run_type [83456,83464]
===
match
---
import_from [2290,2321]
import_from [2290,2321]
===
match
---
name: self [104827,104831]
name: self [104926,104930]
===
match
---
trailer [50406,50426]
trailer [50406,50426]
===
match
---
trailer [90466,90483]
trailer [90565,90582]
===
match
---
trailer [72960,72970]
trailer [72960,72970]
===
match
---
operator: , [50912,50913]
operator: , [50912,50913]
===
match
---
atom_expr [3360,3396]
atom_expr [3360,3396]
===
match
---
trailer [21459,21465]
trailer [21459,21465]
===
match
---
parameters [22116,22202]
parameters [22116,22202]
===
match
---
simple_stmt [33067,33156]
simple_stmt [33067,33156]
===
match
---
name: or_ [49792,49795]
name: or_ [49792,49795]
===
match
---
operator: = [83365,83366]
operator: = [83464,83465]
===
match
---
operator: = [62569,62570]
operator: = [62569,62570]
===
match
---
name: state [49974,49979]
name: state [49974,49979]
===
match
---
name: airflow [2670,2677]
name: airflow [2670,2677]
===
match
---
operator: , [83405,83406]
operator: , [83504,83505]
===
match
---
trailer [73101,73107]
trailer [73101,73107]
===
match
---
operator: = [15672,15673]
operator: = [15672,15673]
===
match
---
trailer [32607,32612]
trailer [32607,32612]
===
match
---
expr_stmt [57859,57908]
expr_stmt [57859,57908]
===
match
---
trailer [17943,18015]
trailer [17943,18015]
===
match
---
trailer [19916,20153]
trailer [19916,20153]
===
match
---
name: self [70397,70401]
name: self [70397,70401]
===
match
---
operator: == [82906,82908]
operator: == [83005,83007]
===
match
---
trailer [105373,105398]
trailer [105472,105497]
===
match
---
if_stmt [73765,73917]
if_stmt [73765,73917]
===
match
---
param [62408,62421]
param [62408,62421]
===
match
---
name: orm_dag [87354,87361]
name: orm_dag [87453,87460]
===
match
---
name: dag_id [105464,105470]
name: dag_id [105563,105569]
===
match
---
operator: , [38219,38220]
operator: , [38219,38220]
===
match
---
trailer [69337,69372]
trailer [69337,69372]
===
match
---
simple_stmt [52269,52312]
simple_stmt [52269,52312]
===
match
---
name: restriction [26624,26635]
name: restriction [26624,26635]
===
match
---
operator: , [12103,12104]
operator: , [12103,12104]
===
match
---
operator: = [14900,14901]
operator: = [14900,14901]
===
match
---
trailer [15996,16146]
trailer [15996,16146]
===
match
---
trailer [17126,17150]
trailer [17126,17150]
===
match
---
name: copied [72366,72372]
name: copied [72366,72372]
===
match
---
atom [75110,75127]
atom [75110,75127]
===
match
---
suite [87116,87248]
suite [87215,87347]
===
match
---
name: DAG [108977,108980]
name: DAG [109076,109079]
===
match
---
operator: = [45232,45233]
operator: = [45232,45233]
===
match
---
name: datetime [46404,46412]
name: datetime [46404,46412]
===
match
---
fstring_expr [16085,16107]
fstring_expr [16085,16107]
===
match
---
dotted_name [2327,2350]
dotted_name [2327,2350]
===
match
---
operator: = [59395,59396]
operator: = [59395,59396]
===
match
---
suite [30263,30480]
suite [30263,30480]
===
match
---
name: topological_sort [61028,61044]
name: topological_sort [61028,61044]
===
match
---
operator: { [13882,13883]
operator: { [13882,13883]
===
match
---
decorated [89964,90852]
decorated [90063,90951]
===
match
---
decorator [89982,89999]
decorator [90081,90098]
===
match
---
trailer [24639,24655]
trailer [24639,24655]
===
match
---
tfpdef [99787,99805]
tfpdef [99886,99904]
===
match
---
expr_stmt [67308,67328]
expr_stmt [67308,67328]
===
match
---
trailer [18940,18942]
trailer [18940,18942]
===
match
---
subscriptlist [16929,16957]
subscriptlist [16929,16957]
===
match
---
name: bulk_write_to_db [84216,84232]
name: bulk_write_to_db [84315,84331]
===
match
---
comparison [53039,53095]
comparison [53039,53095]
===
match
---
name: end_date [28845,28853]
name: end_date [28845,28853]
===
match
---
atom_expr [11258,11280]
atom_expr [11258,11280]
===
match
---
suite [74626,74715]
suite [74626,74715]
===
match
---
if_stmt [51789,51853]
if_stmt [51789,51853]
===
match
---
operator: , [35097,35098]
operator: , [35097,35098]
===
match
---
operator: , [97593,97594]
operator: , [97692,97693]
===
match
---
suite [61909,61978]
suite [61909,61978]
===
match
---
name: _getframe [107480,107489]
name: _getframe [107579,107588]
===
match
---
trailer [88112,88117]
trailer [88211,88216]
===
match
---
name: execution_date [83184,83198]
name: execution_date [83283,83297]
===
match
---
trailer [87937,87942]
trailer [88036,88041]
===
match
---
param [30157,30162]
param [30157,30162]
===
match
---
atom_expr [87428,87443]
atom_expr [87527,87542]
===
match
---
name: __tablename__ [94227,94240]
name: __tablename__ [94326,94339]
===
match
---
operator: = [80732,80733]
operator: = [80732,80733]
===
match
---
trailer [64449,64454]
trailer [64449,64454]
===
match
---
name: filter_query [101787,101799]
name: filter_query [101886,101898]
===
match
---
trailer [49389,49392]
trailer [49389,49392]
===
match
---
name: sensors [51262,51269]
name: sensors [51262,51269]
===
match
---
name: matched_tasks [70665,70678]
name: matched_tasks [70665,70678]
===
match
---
if_stmt [67690,68216]
if_stmt [67690,68216]
===
match
---
name: dag_id [87006,87012]
name: dag_id [87105,87111]
===
match
---
atom_expr [20360,20374]
atom_expr [20360,20374]
===
match
---
trailer [21499,21541]
trailer [21499,21541]
===
match
---
simple_stmt [20470,20528]
simple_stmt [20470,20528]
===
match
---
atom_expr [76902,76951]
atom_expr [76902,76951]
===
match
---
name: DagRunInfo [25528,25538]
name: DagRunInfo [25528,25538]
===
match
---
name: default_view [89212,89224]
name: default_view [89311,89323]
===
match
---
operator: = [53621,53622]
operator: = [53621,53622]
===
match
---
atom_expr [90770,90783]
atom_expr [90869,90882]
===
match
---
funcdef [93329,93793]
funcdef [93428,93892]
===
match
---
param [21738,21743]
param [21738,21743]
===
match
---
name: Collection [45928,45938]
name: Collection [45928,45938]
===
match
---
name: session [34824,34831]
name: session [34824,34831]
===
match
---
atom_expr [99419,99474]
atom_expr [99518,99573]
===
match
---
atom_expr [74224,74241]
atom_expr [74224,74241]
===
match
---
name: self [100847,100851]
name: self [100946,100950]
===
match
---
atom_expr [14067,14098]
atom_expr [14067,14098]
===
match
---
not_test [57890,57898]
not_test [57890,57898]
===
match
---
operator: , [93843,93844]
operator: , [93942,93943]
===
match
---
trailer [85145,85152]
trailer [85244,85251]
===
match
---
operator: , [87741,87742]
operator: , [87840,87841]
===
match
---
suite [18066,18100]
suite [18066,18100]
===
match
---
trailer [46809,46829]
trailer [46809,46829]
===
match
---
trailer [43307,43328]
trailer [43307,43328]
===
match
---
atom_expr [71787,71818]
atom_expr [71787,71818]
===
match
---
parameters [43719,43824]
parameters [43719,43824]
===
match
---
name: isoformat [90731,90740]
name: isoformat [90830,90839]
===
match
---
name: self [70450,70454]
name: self [70450,70454]
===
match
---
name: description [31608,31619]
name: description [31608,31619]
===
match
---
param [80497,80516]
param [80497,80516]
===
match
---
tfpdef [46049,46069]
tfpdef [46049,46069]
===
match
---
name: provide_session [101247,101262]
name: provide_session [101346,101361]
===
match
---
simple_stmt [892,909]
simple_stmt [892,909]
===
match
---
name: t [71077,71078]
name: t [71077,71078]
===
match
---
name: dag_id [106747,106753]
name: dag_id [106846,106852]
===
match
---
atom_expr [95453,95472]
atom_expr [95552,95571]
===
match
---
simple_stmt [97287,97314]
simple_stmt [97386,97413]
===
match
---
name: __tablename__ [94503,94516]
name: __tablename__ [94602,94615]
===
match
---
simple_stmt [37231,37294]
simple_stmt [37231,37294]
===
match
---
operator: = [46762,46763]
operator: = [46762,46763]
===
match
---
name: session [74504,74511]
name: session [74504,74511]
===
match
---
operator: ~ [89824,89825]
operator: ~ [89923,89924]
===
match
---
simple_stmt [84765,84812]
simple_stmt [84864,84911]
===
match
---
trailer [12864,12877]
trailer [12864,12877]
===
match
---
suite [109166,109211]
suite [109265,109310]
===
match
---
operator: } [16130,16131]
operator: } [16130,16131]
===
match
---
name: false [38893,38898]
name: false [38893,38898]
===
match
---
trailer [76076,76087]
trailer [76076,76087]
===
match
---
name: property [35330,35338]
name: property [35330,35338]
===
match
---
parameters [35092,35112]
parameters [35092,35112]
===
match
---
atom_expr [104636,104666]
atom_expr [104735,104765]
===
match
---
atom_expr [11311,11325]
atom_expr [11311,11325]
===
match
---
trailer [86597,86604]
trailer [86696,86703]
===
match
---
expr_stmt [20554,20637]
expr_stmt [20554,20637]
===
match
---
atom_expr [33509,33521]
atom_expr [33509,33521]
===
match
---
name: dag_id [40862,40868]
name: dag_id [40862,40868]
===
match
---
atom_expr [20811,20876]
atom_expr [20811,20876]
===
match
---
parameters [30773,30779]
parameters [30773,30779]
===
match
---
suite [32470,32562]
suite [32470,32562]
===
match
---
name: self [18003,18007]
name: self [18003,18007]
===
match
---
if_stmt [82894,83090]
if_stmt [82993,83189]
===
match
---
simple_stmt [29276,29318]
simple_stmt [29276,29318]
===
match
---
tfpdef [31103,31113]
tfpdef [31103,31113]
===
match
---
trailer [75304,75307]
trailer [75304,75307]
===
match
---
name: graph_unsorted [60643,60657]
name: graph_unsorted [60643,60657]
===
match
---
name: state [49499,49504]
name: state [49499,49504]
===
match
---
operator: , [31101,31102]
operator: , [31101,31102]
===
match
---
atom_expr [37737,37774]
atom_expr [37737,37774]
===
match
---
operator: = [31147,31148]
operator: = [31147,31148]
===
match
---
funcdef [68242,68907]
funcdef [68242,68907]
===
match
---
operator: * [68930,68931]
operator: * [68930,68931]
===
match
---
name: sla_miss_callback [11695,11712]
name: sla_miss_callback [11695,11712]
===
match
---
param [80576,80605]
param [80576,80605]
===
match
---
name: task_ids [48694,48702]
name: task_ids [48694,48702]
===
match
---
atom_expr [46146,46176]
atom_expr [46146,46176]
===
match
---
operator: = [74079,74080]
operator: = [74079,74080]
===
match
---
operator: <= [40553,40555]
operator: <= [40553,40555]
===
match
---
trailer [89816,89823]
trailer [89915,89922]
===
match
---
operator: = [87426,87427]
operator: = [87525,87526]
===
match
---
trailer [109182,109203]
trailer [109281,109302]
===
match
---
name: dag_run_state [66260,66273]
name: dag_run_state [66260,66273]
===
match
---
expr_stmt [13188,13209]
expr_stmt [13188,13209]
===
match
---
operator: , [47263,47264]
operator: , [47263,47264]
===
match
---
name: start_date [20754,20764]
name: start_date [20754,20764]
===
match
---
atom_expr [27491,27528]
atom_expr [27491,27528]
===
match
---
name: include_upstream [53605,53621]
name: include_upstream [53605,53621]
===
match
---
param [45910,45944]
param [45910,45944]
===
match
---
sync_comp_for [19818,19835]
sync_comp_for [19818,19835]
===
match
---
operator: , [11280,11281]
operator: , [11280,11281]
===
match
---
operator: = [51523,51524]
operator: = [51523,51524]
===
match
---
tfpdef [46563,46590]
tfpdef [46563,46590]
===
match
---
string: """         Return a DagParam object for current dag.          :param name: dag parameter name.         :param default: fallback value for dag parameter.         :return: DagParam instance for specified name and current dag.         """ [32016,32252]
string: """         Return a DagParam object for current dag.          :param name: dag parameter name.         :param default: fallback value for dag parameter.         :return: DagParam instance for specified name and current dag.         """ [32016,32252]
===
match
---
simple_stmt [65686,65702]
simple_stmt [65686,65702]
===
match
---
string: 'params' [12923,12931]
string: 'params' [12923,12931]
===
match
---
simple_stmt [41064,41258]
simple_stmt [41064,41258]
===
match
---
operator: += [71074,71076]
operator: += [71074,71076]
===
match
---
decorator [32328,32338]
decorator [32328,32338]
===
match
---
name: next_dagrun_data_interval_start [96573,96604]
name: next_dagrun_data_interval_start [96672,96703]
===
match
---
operator: , [93003,93004]
operator: , [93102,93103]
===
match
---
param [41337,41341]
param [41337,41341]
===
match
---
name: append [24550,24556]
name: append [24550,24556]
===
match
---
param [84263,84275]
param [84362,84374]
===
match
---
expr_stmt [94672,94708]
expr_stmt [94771,94807]
===
match
---
name: paused_dag_ids [100258,100272]
name: paused_dag_ids [100357,100371]
===
match
---
atom_expr [17229,17253]
atom_expr [17229,17253]
===
match
---
atom [88110,88140]
atom [88209,88239]
===
match
---
name: ALLOW_FUTURE_EXEC_DATES [33868,33891]
name: ALLOW_FUTURE_EXEC_DATES [33868,33891]
===
match
---
name: airflow [79465,79472]
name: airflow [79465,79472]
===
match
---
name: exclude_task_ids [55583,55599]
name: exclude_task_ids [55583,55599]
===
match
---
operator: , [2209,2210]
operator: , [2209,2210]
===
match
---
expr_stmt [17597,17613]
expr_stmt [17597,17613]
===
match
---
trailer [92232,92239]
trailer [92331,92338]
===
match
---
name: conf [11913,11917]
name: conf [11913,11917]
===
match
---
name: downstream_task_ids [73341,73360]
name: downstream_task_ids [73341,73360]
===
match
---
arglist [84730,84755]
arglist [84829,84854]
===
match
---
suite [85443,85508]
suite [85542,85607]
===
match
---
name: job [79591,79594]
name: job [79591,79594]
===
match
---
trailer [49814,49818]
trailer [49814,49818]
===
match
---
testlist_comp [49699,49720]
testlist_comp [49699,49720]
===
match
---
except_clause [74258,74279]
except_clause [74258,74279]
===
match
---
if_stmt [64409,64611]
if_stmt [64409,64611]
===
match
---
name: airflow [80278,80285]
name: airflow [80278,80285]
===
match
---
return_stmt [31652,31676]
return_stmt [31652,31676]
===
match
---
name: session [103628,103635]
name: session [103727,103734]
===
match
---
operator: @ [19019,19020]
operator: @ [19019,19020]
===
match
---
trailer [100232,100236]
trailer [100331,100335]
===
match
---
operator: == [40446,40448]
operator: == [40446,40448]
===
match
---
name: expression [38882,38892]
name: expression [38882,38892]
===
match
---
operator: , [79626,79627]
operator: , [79626,79627]
===
match
---
name: re [70597,70599]
name: re [70597,70599]
===
match
---
expr_stmt [82656,82713]
expr_stmt [82766,82823]
===
match
---
trailer [103792,103817]
trailer [103891,103916]
===
match
---
trailer [48684,48688]
trailer [48684,48688]
===
match
---
name: start_date [45185,45195]
name: start_date [45185,45195]
===
match
---
trailer [43642,43662]
trailer [43642,43662]
===
match
---
name: dag [87484,87487]
name: dag [87583,87586]
===
match
---
trailer [51760,51764]
trailer [51760,51764]
===
match
---
param [66522,66536]
param [66522,66536]
===
match
---
operator: = [61737,61738]
operator: = [61737,61738]
===
match
---
trailer [38892,38898]
trailer [38892,38898]
===
match
---
fstring_string: Task id ' [76651,76660]
fstring_string: Task id ' [76651,76660]
===
match
---
simple_stmt [107840,107888]
simple_stmt [107939,107987]
===
match
---
name: tis [48740,48743]
name: tis [48740,48743]
===
match
---
name: include_externally_triggered [99541,99569]
name: include_externally_triggered [99640,99668]
===
match
---
strings [98290,98578]
strings [98389,98677]
===
match
---
name: push_context_managed_dag [108713,108737]
name: push_context_managed_dag [108812,108836]
===
match
---
name: path [33496,33500]
name: path [33496,33500]
===
match
---
comp_op [102628,102634]
comp_op [102727,102733]
===
match
---
simple_stmt [15610,15647]
simple_stmt [15610,15647]
===
match
---
trailer [90535,90539]
trailer [90634,90638]
===
match
---
trailer [24922,24924]
trailer [24922,24924]
===
match
---
atom_expr [31329,31351]
atom_expr [31329,31351]
===
match
---
operator: = [27183,27184]
operator: = [27183,27184]
===
match
---
name: is_active [95113,95122]
name: is_active [95212,95221]
===
match
---
for_stmt [67712,68127]
for_stmt [67712,68127]
===
match
---
operator: , [34822,34823]
operator: , [34822,34823]
===
match
---
trailer [60834,60842]
trailer [60834,60842]
===
match
---
atom_expr [14045,14062]
atom_expr [14045,14062]
===
match
---
atom_expr [27207,27257]
atom_expr [27207,27257]
===
match
---
name: orm_dag [85138,85145]
name: orm_dag [85237,85244]
===
match
---
name: self [31492,31496]
name: self [31492,31496]
===
match
---
atom [58676,58733]
atom [58676,58733]
===
match
---
param [80182,80186]
param [80182,80186]
===
match
---
trailer [41303,41305]
trailer [41303,41305]
===
match
---
name: dag_id [52930,52936]
name: dag_id [52930,52936]
===
match
---
name: self [100643,100647]
name: self [100742,100746]
===
match
---
comparison [52061,52088]
comparison [52061,52088]
===
match
---
expr_stmt [74583,74592]
expr_stmt [74583,74592]
===
match
---
name: start [27804,27809]
name: start [27804,27809]
===
match
---
name: include_upstream [57758,57774]
name: include_upstream [57758,57774]
===
match
---
operator: @ [24061,24062]
operator: @ [24061,24062]
===
match
---
trailer [100790,100806]
trailer [100889,100905]
===
match
---
trailer [44511,44513]
trailer [44511,44513]
===
match
---
name: dag_args [106047,106055]
name: dag_args [106146,106154]
===
match
---
decorator [31160,31170]
decorator [31160,31170]
===
match
---
operator: , [80487,80488]
operator: , [80487,80488]
===
match
---
name: tags [12403,12407]
name: tags [12403,12407]
===
match
---
operator: -> [25516,25518]
operator: -> [25516,25518]
===
match
---
simple_stmt [38925,38947]
simple_stmt [38925,38947]
===
match
---
atom_expr [17641,17668]
atom_expr [17641,17668]
===
match
---
name: TaskInstance [49796,49808]
name: TaskInstance [49796,49808]
===
match
---
operator: = [101047,101048]
operator: = [101146,101147]
===
match
---
name: values [71758,71764]
name: values [71758,71764]
===
match
---
parameters [75335,75341]
parameters [75335,75341]
===
match
---
operator: = [77384,77385]
operator: = [77384,77385]
===
match
---
trailer [52929,52936]
trailer [52929,52936]
===
match
---
decorator [99339,99356]
decorator [99438,99455]
===
match
---
name: val [18558,18561]
name: val [18558,18561]
===
match
---
name: d [74323,74324]
name: d [74323,74324]
===
match
---
name: normalized_schedule_interval [35711,35739]
name: normalized_schedule_interval [35711,35739]
===
match
---
operator: , [55854,55855]
operator: , [55854,55855]
===
match
---
fstring_string: Could not find dag  [53428,53447]
fstring_string: Could not find dag  [53428,53447]
===
match
---
atom_expr [90835,90851]
atom_expr [90934,90950]
===
match
---
simple_stmt [69023,69214]
simple_stmt [69023,69214]
===
match
---
operator: , [34690,34691]
operator: , [34690,34691]
===
match
---
atom_expr [95022,95052]
atom_expr [95121,95151]
===
match
---
param [75461,75465]
param [75461,75465]
===
match
---
operator: } [107268,107269]
operator: } [107367,107368]
===
match
---
name: bool [58788,58792]
name: bool [58788,58792]
===
match
---
name: query [39681,39686]
name: query [39681,39686]
===
match
---
comparison [50105,50132]
comparison [50105,50132]
===
match
---
simple_stmt [41870,41901]
simple_stmt [41870,41901]
===
match
---
trailer [105423,105489]
trailer [105522,105588]
===
match
---
name: num [44535,44538]
name: num [44535,44538]
===
match
---
trailer [96669,96682]
trailer [96768,96781]
===
match
---
name: include_parentdag [45327,45344]
name: include_parentdag [45327,45344]
===
match
---
name: self [58524,58528]
name: self [58524,58528]
===
match
---
name: DagTag [94136,94142]
name: DagTag [94235,94241]
===
match
---
operator: = [94625,94626]
operator: = [94724,94725]
===
match
---
operator: = [66773,66774]
operator: = [66773,66774]
===
match
---
trailer [32841,32953]
trailer [32841,32953]
===
match
---
name: format [66014,66020]
name: format [66014,66020]
===
match
---
simple_stmt [100406,100531]
simple_stmt [100505,100630]
===
match
---
atom [49698,49721]
atom [49698,49721]
===
match
---
name: count [67361,67366]
name: count [67361,67366]
===
match
---
simple_stmt [68661,68715]
simple_stmt [68661,68715]
===
match
---
trailer [104146,104165]
trailer [104245,104264]
===
match
---
name: type [82626,82630]
name: type [82736,82740]
===
match
---
name: dag_model [102675,102684]
name: dag_model [102774,102783]
===
match
---
trailer [77236,77242]
trailer [77236,77242]
===
match
---
parameters [77017,77030]
parameters [77017,77030]
===
match
---
funcdef [68912,69266]
funcdef [68912,69266]
===
match
---
name: add_tasks [77008,77017]
name: add_tasks [77008,77017]
===
match
---
name: local_executor [79345,79359]
name: local_executor [79345,79359]
===
match
---
expr_stmt [98881,98961]
expr_stmt [98980,99060]
===
match
---
name: self [15024,15028]
name: self [15024,15028]
===
match
---
name: get_default_view [100367,100383]
name: get_default_view [100466,100482]
===
match
---
name: dag_id [48457,48463]
name: dag_id [48457,48463]
===
match
---
name: DeprecationWarning [32911,32929]
name: DeprecationWarning [32911,32929]
===
match
---
name: QUEUED [66719,66725]
name: QUEUED [66719,66725]
===
match
---
name: session [89915,89922]
name: session [90014,90021]
===
match
---
arglist [30328,30441]
arglist [30328,30441]
===
match
---
name: info [27878,27882]
name: info [27878,27882]
===
match
---
operator: , [47323,47324]
operator: , [47323,47324]
===
match
---
name: dag [89929,89932]
name: dag [90028,90031]
===
match
---
trailer [102608,102627]
trailer [102707,102726]
===
match
---
name: filter [49259,49265]
name: filter [49259,49265]
===
match
---
name: self [18229,18233]
name: self [18229,18233]
===
match
---
name: airflow [2153,2160]
name: airflow [2153,2160]
===
match
---
trailer [45136,45516]
trailer [45136,45516]
===
match
---
name: dag_kwargs [106059,106069]
name: dag_kwargs [106158,106168]
===
match
---
name: setter [31462,31468]
name: setter [31462,31468]
===
match
---
operator: = [66321,66322]
operator: = [66321,66322]
===
match
---
name: DagRun [85848,85854]
name: DagRun [85947,85953]
===
match
---
param [17749,17754]
param [17749,17754]
===
match
---
name: DagParam [2051,2059]
name: DagParam [2051,2059]
===
match
---
name: task_id [73547,73554]
name: task_id [73547,73554]
===
match
---
name: dag_id [18165,18171]
name: dag_id [18165,18171]
===
match
---
atom_expr [69229,69265]
atom_expr [69229,69265]
===
match
---
operator: = [97100,97101]
operator: = [97199,97200]
===
match
---
decorator [89377,89394]
decorator [89476,89493]
===
match
---
classdef [4129,94128]
classdef [4129,94227]
===
match
---
trailer [38593,38607]
trailer [38593,38607]
===
match
---
name: self [16590,16594]
name: self [16590,16594]
===
match
---
operator: += [42335,42337]
operator: += [42335,42337]
===
match
---
arglist [21594,21610]
arglist [21594,21610]
===
match
---
name: interval [27766,27774]
name: interval [27766,27774]
===
match
---
atom_expr [75609,75624]
atom_expr [75609,75624]
===
match
---
name: DagRunType [3209,3219]
name: DagRunType [3209,3219]
===
match
---
name: recursion_depth [46049,46064]
name: recursion_depth [46049,46064]
===
match
---
name: self [15082,15086]
name: self [15082,15086]
===
match
---
name: pickle_info [73982,73993]
name: pickle_info [73982,73993]
===
match
---
name: Session [103053,103060]
name: Session [103152,103159]
===
match
---
name: setter [31070,31076]
name: setter [31070,31076]
===
match
---
name: setter [30500,30506]
name: setter [30500,30506]
===
match
---
atom_expr [16590,16614]
atom_expr [16590,16614]
===
match
---
name: query [39628,39633]
name: query [39628,39633]
===
match
---
name: state [49375,49380]
name: state [49375,49380]
===
match
---
operator: , [57262,57263]
operator: , [57262,57263]
===
match
---
operator: } [19688,19689]
operator: } [19688,19689]
===
match
---
simple_stmt [20650,20803]
simple_stmt [20650,20803]
===
match
---
suite [17800,18016]
suite [17800,18016]
===
match
---
expr_stmt [102448,102485]
expr_stmt [102547,102584]
===
match
---
operator: , [45798,45799]
operator: , [45798,45799]
===
match
---
atom_expr [12508,12532]
atom_expr [12508,12532]
===
match
---
simple_stmt [74767,74792]
simple_stmt [74767,74792]
===
match
---
atom_expr [24175,24185]
atom_expr [24175,24185]
===
match
---
atom [12670,12672]
atom [12670,12672]
===
match
---
simple_stmt [26468,26511]
simple_stmt [26468,26511]
===
match
---
param [99541,99575]
param [99640,99674]
===
match
---
name: dag_model [102922,102931]
name: dag_model [103021,103030]
===
match
---
name: setter [32438,32444]
name: setter [32438,32444]
===
match
---
atom_expr [71584,71605]
atom_expr [71584,71605]
===
match
---
comparison [102588,102653]
comparison [102687,102752]
===
match
---
atom_expr [83682,83719]
atom_expr [83781,83818]
===
match
---
operator: , [96971,96972]
operator: , [97070,97071]
===
match
---
name: self [24214,24218]
name: self [24214,24218]
===
match
---
name: DateTime [25425,25433]
name: DateTime [25425,25433]
===
match
---
name: Index [96833,96838]
name: Index [96932,96937]
===
match
---
name: run_id [82656,82662]
name: run_id [82766,82772]
===
match
---
atom_expr [24255,24290]
atom_expr [24255,24290]
===
match
---
argument [42926,42945]
argument [42926,42945]
===
match
---
operator: } [19835,19836]
operator: } [19835,19836]
===
match
---
operator: , [45350,45351]
operator: , [45350,45351]
===
match
---
name: deepcopy [70441,70449]
name: deepcopy [70441,70449]
===
match
---
name: task [76351,76355]
name: task [76351,76355]
===
match
---
string: """     DAG context is used to keep the current DAG when DAG is used as ContextManager.      You can use DAG as context:      .. code-block:: python          with DAG(             dag_id="example_dag",             default_args=default_args,             schedule_interval="0 0 * * *",             dagrun_timeout=timedelta(minutes=60),         ) as dag:             ...      If you do this the context stores the DAG and whenever new task is created, it will use     such stored DAG as the parent DAG.      """ [108079,108587]
string: """     DAG context is used to keep the current DAG when DAG is used as ContextManager.      You can use DAG as context:      .. code-block:: python          with DAG(             dag_id="example_dag",             default_args=default_args,             schedule_interval="0 0 * * *",             dagrun_timeout=timedelta(minutes=60),         ) as dag:             ...      If you do this the context stores the DAG and whenever new task is created, it will use     such stored DAG as the parent DAG.      """ [108178,108686]
===
match
---
name: self [37132,37136]
name: self [37132,37136]
===
match
---
trailer [87267,87277]
trailer [87366,87376]
===
match
---
tfpdef [80904,80954]
tfpdef [80904,80954]
===
match
---
argument [21075,21087]
argument [21075,21087]
===
match
---
name: session [90804,90811]
name: session [90903,90910]
===
match
---
operator: , [69476,69477]
operator: , [69476,69477]
===
match
---
name: get [100669,100672]
name: get [100768,100771]
===
match
---
decorator [19019,19033]
decorator [19019,19033]
===
match
---
name: foreign_keys [97088,97100]
name: foreign_keys [97187,97199]
===
match
---
name: utc [28906,28909]
name: utc [28906,28909]
===
match
---
fstring_end: " [98507,98508]
fstring_end: " [98606,98607]
===
match
---
name: ti [51669,51671]
name: ti [51669,51671]
===
match
---
operator: , [66032,66033]
operator: , [66032,66033]
===
match
---
name: self [17229,17233]
name: self [17229,17233]
===
match
---
name: TaskInstanceKey [51409,51424]
name: TaskInstanceKey [51409,51424]
===
match
---
argument [58044,58066]
argument [58044,58066]
===
match
---
name: success [36397,36404]
name: success [36397,36404]
===
match
---
name: conditions [48404,48414]
name: conditions [48404,48414]
===
match
---
trailer [48570,48583]
trailer [48570,48583]
===
match
---
name: max_recursion_depth [52061,52080]
name: max_recursion_depth [52061,52080]
===
match
---
argument [83419,83450]
argument [83518,83549]
===
match
---
name: Union [69332,69337]
name: Union [69332,69337]
===
match
---
trailer [11667,11678]
trailer [11667,11678]
===
match
---
trailer [104862,104875]
trailer [104961,104974]
===
match
---
atom [65896,66013]
atom [65896,66013]
===
match
---
name: Interval [96189,96197]
name: Interval [96288,96296]
===
match
---
operator: , [35930,35931]
operator: , [35930,35931]
===
match
---
funcdef [98754,99069]
funcdef [98853,99168]
===
match
---
trailer [42266,42273]
trailer [42266,42273]
===
match
---
name: self [13188,13192]
name: self [13188,13192]
===
match
---
expr_stmt [85040,85108]
expr_stmt [85139,85207]
===
match
---
name: provide_session [99481,99496]
name: provide_session [99580,99595]
===
match
---
operator: , [77578,77579]
operator: , [77578,77579]
===
match
---
trailer [61935,61942]
trailer [61935,61942]
===
match
---
trailer [92204,92212]
trailer [92303,92311]
===
match
---
arglist [66021,66049]
arglist [66021,66049]
===
match
---
simple_stmt [28937,28974]
simple_stmt [28937,28974]
===
match
---
trailer [90713,90730]
trailer [90812,90829]
===
match
---
fstring [16014,16066]
fstring [16014,16066]
===
match
---
expr_stmt [60485,60500]
expr_stmt [60485,60500]
===
match
---
trailer [101112,101124]
trailer [101211,101223]
===
match
---
trailer [44682,44740]
trailer [44682,44740]
===
match
---
simple_stmt [75396,75437]
simple_stmt [75396,75437]
===
match
---
operator: } [62582,62583]
operator: } [62582,62583]
===
match
---
parameters [32776,32782]
parameters [32776,32782]
===
match
---
name: DagRunType [86070,86080]
name: DagRunType [86169,86179]
===
match
---
comparison [17944,17993]
comparison [17944,17993]
===
match
---
return_stmt [4080,4100]
return_stmt [4080,4100]
===
match
---
suite [75649,75729]
suite [75649,75729]
===
match
---
name: get_edge_info [93333,93346]
name: get_edge_info [93432,93445]
===
match
---
expr_stmt [96485,96518]
expr_stmt [96584,96617]
===
match
---
operator: ** [107664,107666]
operator: ** [107763,107765]
===
match
---
string: "You must provide either the execution_date or the run_id" [39544,39602]
string: "You must provide either the execution_date or the run_id" [39544,39602]
===
match
---
if_stmt [101652,101743]
if_stmt [101751,101842]
===
match
---
string: "TaskInstanceKey" [46198,46215]
string: "TaskInstanceKey" [46198,46215]
===
match
---
name: dp [74950,74952]
name: dp [74950,74952]
===
match
---
operator: , [77483,77484]
operator: , [77483,77484]
===
match
---
if_stmt [66114,66378]
if_stmt [66114,66378]
===
match
---
name: datetime [20248,20256]
name: datetime [20248,20256]
===
match
---
decorators [83745,83779]
decorators [83844,83878]
===
match
---
trailer [80397,80399]
trailer [80397,80399]
===
match
---
name: DagModel [94440,94448]
name: DagModel [94539,94547]
===
match
---
name: dag_id [35271,35277]
name: dag_id [35271,35277]
===
match
---
atom_expr [44430,44447]
atom_expr [44430,44447]
===
match
---
operator: , [19642,19643]
operator: , [19642,19643]
===
match
---
name: ValueError [101162,101172]
name: ValueError [101261,101271]
===
match
---
name: ti [37413,37415]
name: ti [37413,37415]
===
match
---
decorator [33787,33797]
decorator [33787,33797]
===
match
---
operator: , [70454,70455]
operator: , [70454,70455]
===
match
---
if_stmt [28842,28974]
if_stmt [28842,28974]
===
match
---
name: memo [70360,70364]
name: memo [70360,70364]
===
match
---
name: interval [24936,24944]
name: interval [24936,24944]
===
match
---
operator: , [92888,92889]
operator: , [92987,92988]
===
match
---
raise_stmt [76622,76711]
raise_stmt [76622,76711]
===
match
---
name: dag_tag [88211,88218]
name: dag_tag [88310,88317]
===
match
---
param [10997,11035]
param [10997,11035]
===
match
---
atom_expr [55872,55886]
atom_expr [55872,55886]
===
match
---
suite [28862,28911]
suite [28862,28911]
===
match
---
argument [85320,85341]
argument [85419,85440]
===
match
---
name: orm_dag [88024,88031]
name: orm_dag [88123,88130]
===
match
---
trailer [13326,13500]
trailer [13326,13500]
===
match
---
argument [65852,65871]
argument [65852,65871]
===
match
---
operator: , [50301,50302]
operator: , [50301,50302]
===
match
---
name: query [84891,84896]
name: query [84990,84995]
===
match
---
name: task [53075,53079]
name: task [53075,53079]
===
match
---
name: TaskInstance [44876,44888]
name: TaskInstance [44876,44888]
===
match
---
simple_stmt [41959,41977]
simple_stmt [41959,41977]
===
match
---
operator: , [53676,53677]
operator: , [53676,53677]
===
match
---
operator: , [21526,21527]
operator: , [21526,21527]
===
match
---
name: task_id [76477,76484]
name: task_id [76477,76484]
===
match
---
name: session [66387,66394]
name: session [66387,66394]
===
match
---
name: default_view [31700,31712]
name: default_view [31700,31712]
===
match
---
name: tags [88135,88139]
name: tags [88234,88238]
===
match
---
name: tis [48617,48620]
name: tis [48617,48620]
===
match
---
atom_expr [15674,15704]
atom_expr [15674,15704]
===
match
---
trailer [72659,72666]
trailer [72659,72666]
===
match
---
name: copy [51972,51976]
name: copy [51972,51976]
===
match
---
name: datetime [20320,20328]
name: datetime [20320,20328]
===
match
---
atom_expr [47508,47528]
atom_expr [47508,47528]
===
match
---
name: state [92195,92200]
name: state [92294,92299]
===
match
---
atom_expr [37975,37986]
atom_expr [37975,37986]
===
match
---
name: warnings [34536,34544]
name: warnings [34536,34544]
===
match
---
trailer [51408,51454]
trailer [51408,51454]
===
match
---
atom_expr [99796,99805]
atom_expr [99895,99904]
===
match
---
trailer [49848,49854]
trailer [49848,49854]
===
match
---
name: dag_id [85001,85007]
name: dag_id [85100,85106]
===
match
---
operator: = [21521,21522]
operator: = [21521,21522]
===
match
---
simple_stmt [18841,18853]
simple_stmt [18841,18853]
===
match
---
for_stmt [66786,67251]
for_stmt [66786,67251]
===
match
---
suite [41853,41951]
suite [41853,41951]
===
match
---
atom_expr [71608,71634]
atom_expr [71608,71634]
===
match
---
operator: , [50547,50548]
operator: , [50547,50548]
===
match
---
string: 'Executing dag callback function: %s' [37245,37282]
string: 'Executing dag callback function: %s' [37245,37282]
===
match
---
trailer [108034,108054]
trailer [108133,108153]
===
match
---
fstring [16083,16132]
fstring [16083,16132]
===
match
---
trailer [50257,50260]
trailer [50257,50260]
===
match
---
name: self [45649,45653]
name: self [45649,45653]
===
match
---
name: update [42713,42719]
name: update [42713,42719]
===
match
---
testlist_comp [91936,91970]
testlist_comp [92035,92069]
===
match
---
operator: , [103995,103996]
operator: , [104094,104095]
===
match
---
suite [54987,55191]
suite [54987,55191]
===
match
---
operator: , [80701,80702]
operator: , [80701,80702]
===
match
---
raise_stmt [82564,82643]
raise_stmt [82674,82753]
===
match
---
operator: , [101289,101290]
operator: , [101388,101389]
===
match
---
name: session [44732,44739]
name: session [44732,44739]
===
match
---
arglist [72418,72440]
arglist [72418,72440]
===
match
---
trailer [96188,96198]
trailer [96287,96297]
===
match
---
name: active_dag_ids [89845,89859]
name: active_dag_ids [89944,89958]
===
match
---
name: self [14126,14130]
name: self [14126,14130]
===
match
---
simple_stmt [76396,76446]
simple_stmt [76396,76446]
===
match
---
simple_stmt [83682,83720]
simple_stmt [83781,83819]
===
match
---
return_stmt [18075,18099]
return_stmt [18075,18099]
===
match
---
trailer [105008,105024]
trailer [105107,105123]
===
match
---
name: cls [103737,103740]
name: cls [103836,103839]
===
match
---
trailer [100864,100878]
trailer [100963,100977]
===
match
---
name: task_id [73908,73915]
name: task_id [73908,73915]
===
match
---
name: name [32295,32299]
name: name [32295,32299]
===
match
---
trailer [76400,76409]
trailer [76400,76409]
===
match
---
operator: -> [61498,61500]
operator: -> [61498,61500]
===
match
---
argument [106464,106472]
argument [106563,106571]
===
match
---
operator: } [57706,57707]
operator: } [57706,57707]
===
match
---
subscript [107865,107869]
subscript [107964,107968]
===
match
---
operator: = [32941,32942]
operator: = [32941,32942]
===
match
---
name: self [98182,98186]
name: self [98281,98285]
===
match
---
name: String [95904,95910]
name: String [96003,96009]
===
match
---
name: role [19702,19706]
name: role [19702,19706]
===
match
---
name: run_backwards [80112,80125]
name: run_backwards [80112,80125]
===
match
---
trailer [72666,72668]
trailer [72666,72668]
===
match
---
name: all [85103,85106]
name: all [85202,85205]
===
match
---
expr_stmt [107256,107269]
expr_stmt [107355,107368]
===
match
---
fstring_string: ' has already been added to the DAG [76674,76709]
fstring_string: ' has already been added to the DAG [76674,76709]
===
match
---
name: TaskInstance [46857,46869]
name: TaskInstance [46857,46869]
===
match
---
operator: , [10391,10392]
operator: , [10391,10392]
===
match
---
name: self [57025,57029]
name: self [57025,57029]
===
match
---
name: first [99467,99472]
name: first [99566,99571]
===
match
---
operator: = [64811,64812]
operator: = [64811,64812]
===
match
---
operator: @ [35329,35330]
operator: @ [35329,35330]
===
match
---
param [35357,35361]
param [35357,35361]
===
match
---
name: align [27177,27182]
name: align [27177,27182]
===
match
---
suite [102897,102949]
suite [102996,103048]
===
match
---
trailer [21159,21175]
trailer [21159,21175]
===
match
---
name: DagModel [84992,85000]
name: DagModel [85091,85099]
===
match
---
operator: = [16670,16671]
operator: = [16670,16671]
===
match
---
expr_stmt [29276,29317]
expr_stmt [29276,29317]
===
match
---
trailer [55465,55472]
trailer [55465,55472]
===
match
---
name: List [58296,58300]
name: List [58296,58300]
===
match
---
name: self [31890,31894]
name: self [31890,31894]
===
match
---
operator: , [28699,28700]
operator: , [28699,28700]
===
match
---
trailer [47492,47506]
trailer [47492,47506]
===
match
---
name: _task_group [32733,32744]
name: _task_group [32733,32744]
===
match
---
argument [49533,49557]
argument [49533,49557]
===
match
---
name: tii [53136,53139]
name: tii [53136,53139]
===
match
---
name: self [70371,70375]
name: self [70371,70375]
===
match
---
simple_stmt [77223,77243]
simple_stmt [77223,77243]
===
match
---
operator: <= [44381,44383]
operator: <= [44381,44383]
===
match
---
atom_expr [104920,104946]
atom_expr [105019,105045]
===
match
---
trailer [86788,86795]
trailer [86887,86894]
===
match
---
atom_expr [14126,14157]
atom_expr [14126,14157]
===
match
---
name: self [16472,16476]
name: self [16472,16476]
===
match
---
simple_stmt [107759,107774]
simple_stmt [107858,107873]
===
match
---
name: get [89258,89261]
name: get [89357,89360]
===
match
---
decorators [99725,99760]
decorators [99824,99859]
===
match
---
string: 'dag_default_view' [100686,100704]
string: 'dag_default_view' [100785,100803]
===
match
---
if_stmt [25117,25217]
if_stmt [25117,25217]
===
match
---
name: cast [51947,51951]
name: cast [51947,51951]
===
match
---
comparison [87930,87962]
comparison [88029,88061]
===
match
---
simple_stmt [32799,32820]
simple_stmt [32799,32820]
===
match
---
decorator [35054,35071]
decorator [35054,35071]
===
match
---
name: task_ids_or_regex [70501,70518]
name: task_ids_or_regex [70501,70518]
===
match
---
atom_expr [32828,32953]
atom_expr [32828,32953]
===
match
---
name: or_ [1449,1452]
name: or_ [1449,1452]
===
match
---
name: downstream [57225,57235]
name: downstream [57225,57235]
===
match
---
operator: , [45653,45654]
operator: , [45653,45654]
===
match
---
number: 2 [35929,35930]
number: 2 [35929,35930]
===
match
---
atom_expr [103918,103947]
atom_expr [104017,104046]
===
match
---
argument [53862,53891]
argument [53862,53891]
===
match
---
expr_stmt [101573,101643]
expr_stmt [101672,101742]
===
match
---
name: session [29660,29667]
name: session [29660,29667]
===
match
---
name: str [3366,3369]
name: str [3366,3369]
===
match
---
simple_stmt [33415,33478]
simple_stmt [33415,33478]
===
match
---
suite [75206,75248]
suite [75206,75248]
===
match
---
operator: = [38214,38215]
operator: = [38214,38215]
===
match
---
name: session [55448,55455]
name: session [55448,55455]
===
match
---
funcdef [35075,35324]
funcdef [35075,35324]
===
match
---
string: 'dag_id' [106735,106743]
string: 'dag_id' [106834,106842]
===
match
---
name: parser [80380,80386]
name: parser [80380,80386]
===
match
---
atom_expr [62357,62375]
atom_expr [62357,62375]
===
match
---
name: Optional [20311,20319]
name: Optional [20311,20319]
===
match
---
trailer [72975,72977]
trailer [72975,72977]
===
match
---
operator: >= [40500,40502]
operator: >= [40500,40502]
===
match
---
name: dag_cycle_tester [2719,2735]
name: dag_cycle_tester [2719,2735]
===
match
---
arglist [90591,90743]
arglist [90690,90842]
===
match
---
operator: , [45270,45271]
operator: , [45270,45271]
===
match
---
trailer [85222,85240]
trailer [85321,85339]
===
match
---
name: self [97325,97329]
name: self [97424,97428]
===
match
---
trailer [14997,15010]
trailer [14997,15010]
===
match
---
name: dag_run_state [66246,66259]
name: dag_run_state [66246,66259]
===
match
---
name: warn [41073,41077]
name: warn [41073,41077]
===
match
---
atom_expr [90458,90483]
atom_expr [90557,90582]
===
match
---
argument [57249,57262]
argument [57249,57262]
===
match
---
name: template_undefined [11207,11225]
name: template_undefined [11207,11225]
===
match
---
param [69447,69477]
param [69447,69477]
===
match
---
name: subdag [41893,41899]
name: subdag [41893,41899]
===
match
---
param [31498,31503]
param [31498,31503]
===
match
---
comparison [38731,38759]
comparison [38731,38759]
===
match
---
name: dag_ids [85204,85211]
name: dag_ids [85303,85310]
===
match
---
simple_stmt [96984,97121]
simple_stmt [97083,97220]
===
match
---
name: scheduler_lock [95552,95566]
name: scheduler_lock [95651,95665]
===
match
---
comp_op [98217,98223]
comp_op [98316,98322]
===
match
---
funcdef [41982,42084]
funcdef [41982,42084]
===
match
---
suite [71819,72056]
suite [71819,72056]
===
match
---
arglist [93707,93727]
arglist [93806,93826]
===
match
---
name: utcnow [20341,20347]
name: utcnow [20341,20347]
===
match
---
name: __enter__ [18766,18775]
name: __enter__ [18766,18775]
===
match
---
name: Optional [39104,39112]
name: Optional [39104,39112]
===
match
---
name: start_date [44930,44940]
name: start_date [44930,44940]
===
match
---
name: FrozenSet [62554,62563]
name: FrozenSet [62554,62563]
===
match
---
trailer [67652,67660]
trailer [67652,67660]
===
match
---
name: e [74278,74279]
name: e [74278,74279]
===
match
---
fstring [76649,76710]
fstring [76649,76710]
===
match
---
expr_stmt [87297,87341]
expr_stmt [87396,87440]
===
match
---
trailer [97329,97346]
trailer [97428,97445]
===
match
---
name: dag_id [90923,90929]
name: dag_id [91022,91028]
===
match
---
trailer [65102,65110]
trailer [65102,65110]
===
match
---
name: warnings [61515,61523]
name: warnings [61515,61523]
===
match
---
name: tuple [61212,61217]
name: tuple [61212,61217]
===
match
---
operator: , [50965,50966]
operator: , [50965,50966]
===
match
---
simple_stmt [80317,80365]
simple_stmt [80317,80365]
===
match
---
funcdef [90896,92242]
funcdef [90995,92341]
===
match
---
decorator [30055,30065]
decorator [30055,30065]
===
match
---
operator: = [91996,91997]
operator: = [92095,92096]
===
match
---
name: TI [55473,55475]
name: TI [55473,55475]
===
match
---
name: session [57351,57358]
name: session [57351,57358]
===
match
---
name: self [59442,59446]
name: self [59442,59446]
===
match
---
parameters [30528,30541]
parameters [30528,30541]
===
match
---
name: Optional [108615,108623]
name: Optional [108714,108722]
===
match
---
decorated [33932,34370]
decorated [33932,34370]
===
match
---
name: task [75382,75386]
name: task [75382,75386]
===
match
---
parameters [99375,99402]
parameters [99474,99501]
===
match
---
name: run_type [83366,83374]
name: run_type [83465,83473]
===
match
---
simple_stmt [40010,40341]
simple_stmt [40010,40341]
===
match
---
operator: { [61999,62000]
operator: { [61999,62000]
===
match
---
name: state [49288,49293]
name: state [49288,49293]
===
match
---
decorated [24061,24759]
decorated [24061,24759]
===
match
---
operator: , [98673,98674]
operator: , [98772,98773]
===
match
---
name: in_ [48685,48688]
name: in_ [48685,48688]
===
match
---
name: state [53984,53989]
name: state [53984,53989]
===
match
---
suite [83847,84169]
suite [83946,84268]
===
match
---
suite [35131,35324]
suite [35131,35324]
===
match
---
simple_stmt [2541,2608]
simple_stmt [2541,2608]
===
match
---
name: pool [79938,79942]
name: pool [79938,79942]
===
match
---
funcdef [19037,20193]
funcdef [19037,20193]
===
match
---
suite [97355,97771]
suite [97454,97870]
===
match
---
expr_stmt [51323,51334]
expr_stmt [51323,51334]
===
match
---
atom_expr [24976,24991]
atom_expr [24976,24991]
===
match
---
operator: = [42814,42815]
operator: = [42814,42815]
===
match
---
atom_expr [106686,106696]
atom_expr [106785,106795]
===
match
---
simple_stmt [1263,1312]
simple_stmt [1263,1312]
===
match
---
trailer [74860,74867]
trailer [74860,74867]
===
match
---
atom_expr [37956,38008]
atom_expr [37956,38008]
===
match
---
name: end_date [65272,65280]
name: end_date [65272,65280]
===
match
---
argument [37495,37510]
argument [37495,37510]
===
match
---
atom_expr [38932,38946]
atom_expr [38932,38946]
===
match
---
operator: , [52751,52752]
operator: , [52751,52752]
===
match
---
trailer [72617,72619]
trailer [72617,72619]
===
match
---
name: filepath [32768,32776]
name: filepath [32768,32776]
===
match
---
trailer [83702,83719]
trailer [83801,83818]
===
match
---
expr_stmt [51920,52009]
expr_stmt [51920,52009]
===
match
---
trailer [88310,88317]
trailer [88409,88416]
===
match
---
name: next_dagrun_create_after [105374,105398]
name: next_dagrun_create_after [105473,105497]
===
match
---
name: task_ids [62110,62118]
name: task_ids [62110,62118]
===
match
---
name: orm_dag [86969,86976]
name: orm_dag [87068,87075]
===
match
---
trailer [11511,11518]
trailer [11511,11518]
===
match
---
operator: = [77312,77313]
operator: = [77312,77313]
===
match
---
name: last_pickled [74837,74849]
name: last_pickled [74837,74849]
===
match
---
operator: = [99217,99218]
operator: = [99316,99317]
===
match
---
name: timezone [24615,24623]
name: timezone [24615,24623]
===
match
---
trailer [82773,82884]
trailer [82872,82983]
===
match
---
trailer [38634,38641]
trailer [38634,38641]
===
match
---
operator: , [33985,33986]
operator: , [33985,33986]
===
match
---
name: ti [37352,37354]
name: ti [37352,37354]
===
match
---
name: upstream_task_id [43380,43396]
name: upstream_task_id [43380,43396]
===
match
---
operator: = [70996,70997]
operator: = [70996,70997]
===
match
---
string: """         Set ``is_active=False`` on the DAGs for which the DAG files have been removed.         Additionally change ``is_active=False`` to ``True`` if the DAG file exists.          :param alive_dag_filelocs: file paths of alive DAGs         :param session: ORM Session         """ [102048,102331]
string: """         Set ``is_active=False`` on the DAGs for which the DAG files have been removed.         Additionally change ``is_active=False`` to ``True`` if the DAG file exists.          :param alive_dag_filelocs: file paths of alive DAGs         :param session: ORM Session         """ [102147,102430]
===
match
---
atom_expr [71555,71571]
atom_expr [71555,71571]
===
match
---
name: airflow [1715,1722]
name: airflow [1715,1722]
===
match
---
operator: = [96877,96878]
operator: = [96976,96977]
===
match
---
atom_expr [87813,87847]
atom_expr [87912,87946]
===
match
---
param [47203,47221]
param [47203,47221]
===
match
---
name: dag [74692,74695]
name: dag [74692,74695]
===
match
---
name: run_id [82233,82239]
name: run_id [82233,82239]
===
match
---
operator: = [57330,57331]
operator: = [57330,57331]
===
match
---
string: 'end_date' [14529,14539]
string: 'end_date' [14529,14539]
===
match
---
name: start_date [48788,48798]
name: start_date [48788,48798]
===
match
---
atom_expr [95968,95988]
atom_expr [96067,96087]
===
match
---
trailer [107326,107328]
trailer [107425,107427]
===
match
---
name: dag_models [102448,102458]
name: dag_models [102547,102557]
===
match
---
arglist [69050,69203]
arglist [69050,69203]
===
match
---
name: settings [101125,101133]
name: settings [101224,101232]
===
match
---
if_stmt [43242,43330]
if_stmt [43242,43330]
===
match
---
decorator [58499,58509]
decorator [58499,58509]
===
match
---
operator: = [29286,29287]
operator: = [29286,29287]
===
match
---
operator: = [85478,85479]
operator: = [85577,85578]
===
match
---
trailer [80766,80778]
trailer [80766,80778]
===
match
---
trailer [73044,73057]
trailer [73044,73057]
===
match
---
name: self [30774,30778]
name: self [30774,30778]
===
match
---
trailer [85106,85108]
trailer [85205,85207]
===
match
---
fstring_start: f" [97991,97993]
fstring_start: f" [98090,98092]
===
match
---
parameters [94399,94405]
parameters [94498,94504]
===
match
---
operator: = [83278,83279]
operator: = [83377,83378]
===
match
---
try_stmt [74057,74402]
try_stmt [74057,74402]
===
match
---
trailer [35270,35277]
trailer [35270,35277]
===
match
---
atom_expr [16645,16669]
atom_expr [16645,16669]
===
match
---
operator: , [20256,20257]
operator: , [20256,20257]
===
match
---
name: following_schedule [21240,21258]
name: following_schedule [21240,21258]
===
match
---
name: on_failure_callback [12043,12062]
name: on_failure_callback [12043,12062]
===
match
---
name: dagrun [2127,2133]
name: dagrun [2127,2133]
===
match
---
atom [48380,48386]
atom [48380,48386]
===
match
---
suite [24129,24759]
suite [24129,24759]
===
match
---
atom_expr [37132,37156]
atom_expr [37132,37156]
===
match
---
atom_expr [33230,33268]
atom_expr [33230,33268]
===
match
---
name: run [83682,83685]
name: run [83781,83784]
===
match
---
trailer [46803,46830]
trailer [46803,46830]
===
match
---
expr_stmt [74767,74791]
expr_stmt [74767,74791]
===
match
---
suite [67728,68127]
suite [67728,68127]
===
match
---
trailer [106456,106473]
trailer [106555,106572]
===
match
---
decorated [35054,35324]
decorated [35054,35324]
===
match
---
name: isinstance [70490,70500]
name: isinstance [70490,70500]
===
match
---
return_stmt [25159,25216]
return_stmt [25159,25216]
===
match
---
operator: { [98371,98372]
operator: { [98470,98471]
===
match
---
name: self [14783,14787]
name: self [14783,14787]
===
match
---
param [47165,47194]
param [47165,47194]
===
match
---
parameters [35356,35362]
parameters [35356,35362]
===
match
---
name: DagRunType [82535,82545]
name: DagRunType [82645,82655]
===
match
---
name: str [10595,10598]
name: str [10595,10598]
===
match
---
if_stmt [50061,51123]
if_stmt [50061,51123]
===
match
---
if_stmt [49003,49175]
if_stmt [49003,49175]
===
match
---
expr_stmt [19662,19689]
expr_stmt [19662,19689]
===
match
---
argument [80038,80047]
argument [80038,80047]
===
match
---
argument [29677,29734]
argument [29677,29734]
===
match
---
atom_expr [14406,14419]
atom_expr [14406,14419]
===
match
---
import_as_names [3158,3176]
import_as_names [3158,3176]
===
match
---
name: str [80836,80839]
name: str [80836,80839]
===
match
---
name: fileloc [30723,30730]
name: fileloc [30723,30730]
===
match
---
trailer [17202,17226]
trailer [17202,17226]
===
match
---
name: has_dag_runs [29775,29787]
name: has_dag_runs [29775,29787]
===
match
---
name: dag [73489,73492]
name: dag [73489,73492]
===
match
---
trailer [85483,85507]
trailer [85582,85606]
===
match
---
name: Optional [45742,45750]
name: Optional [45742,45750]
===
match
---
trailer [74712,74714]
trailer [74712,74714]
===
match
---
trailer [87065,87076]
trailer [87164,87175]
===
match
---
name: deactivate_stale_dags [90007,90028]
name: deactivate_stale_dags [90106,90127]
===
match
---
atom_expr [48404,48537]
atom_expr [48404,48537]
===
match
---
name: self [45112,45116]
name: self [45112,45116]
===
match
---
name: downstream_task_ids [72997,73016]
name: downstream_task_ids [72997,73016]
===
match
---
name: end_date [28043,28051]
name: end_date [28043,28051]
===
match
---
name: task [41931,41935]
name: task [41931,41935]
===
match
---
simple_stmt [65124,65144]
simple_stmt [65124,65144]
===
match
---
name: f_code [107538,107544]
name: f_code [107637,107643]
===
match
---
atom_expr [37413,37420]
atom_expr [37413,37420]
===
match
---
atom_expr [108765,108789]
atom_expr [108864,108888]
===
match
---
trailer [46435,46451]
trailer [46435,46451]
===
match
---
name: str [46810,46813]
name: str [46810,46813]
===
match
---
operator: , [79995,79996]
operator: , [79995,79996]
===
match
---
name: self [12682,12686]
name: self [12682,12686]
===
match
---
operator: = [62143,62144]
operator: = [62143,62144]
===
match
---
atom_expr [10970,10987]
atom_expr [10970,10987]
===
match
---
operator: = [44815,44816]
operator: = [44815,44816]
===
match
---
operator: , [1649,1650]
operator: , [1649,1650]
===
match
---
operator: , [21895,21896]
operator: , [21895,21896]
===
match
---
atom [101588,101643]
atom [101687,101742]
===
match
---
name: BackfillJob [79597,79608]
name: BackfillJob [79597,79608]
===
match
---
simple_stmt [49746,49892]
simple_stmt [49746,49892]
===
match
---
operator: = [62437,62438]
operator: = [62437,62438]
===
match
---
operator: = [66645,66646]
operator: = [66645,66646]
===
match
---
operator: = [103612,103613]
operator: = [103711,103712]
===
match
---
name: include_subdags [45808,45823]
name: include_subdags [45808,45823]
===
match
---
name: access_control [19717,19731]
name: access_control [19717,19731]
===
match
---
simple_stmt [64441,64611]
simple_stmt [64441,64611]
===
match
---
tfpdef [30163,30173]
tfpdef [30163,30173]
===
match
---
atom_expr [39104,39121]
atom_expr [39104,39121]
===
match
---
name: isinstance [15321,15331]
name: isinstance [15321,15331]
===
match
---
expr_stmt [3959,4022]
expr_stmt [3959,4022]
===
match
---
trailer [41935,41942]
trailer [41935,41942]
===
match
---
param [45649,45654]
param [45649,45654]
===
match
---
tfpdef [46461,46482]
tfpdef [46461,46482]
===
match
---
suite [29371,29396]
suite [29371,29396]
===
match
---
suite [20937,21231]
suite [20937,21231]
===
match
---
simple_stmt [69493,70188]
simple_stmt [69493,70188]
===
match
---
name: pickle_id [95631,95640]
name: pickle_id [95730,95739]
===
match
---
operator: = [88277,88278]
operator: = [88376,88377]
===
match
---
trailer [68616,68651]
trailer [68616,68651]
===
match
---
name: session [3007,3014]
name: session [3007,3014]
===
match
---
name: graph_unsorted [60815,60829]
name: graph_unsorted [60815,60829]
===
match
---
name: altered [58250,58257]
name: altered [58250,58257]
===
match
---
funcdef [32342,32426]
funcdef [32342,32426]
===
match
---
expr_stmt [26519,26564]
expr_stmt [26519,26564]
===
match
---
name: timetables [2504,2514]
name: timetables [2504,2514]
===
match
---
name: bool [55919,55923]
name: bool [55919,55923]
===
match
---
trailer [15244,15256]
trailer [15244,15256]
===
match
---
operator: , [57965,57966]
operator: , [57965,57966]
===
match
---
operator: , [92569,92570]
operator: , [92668,92669]
===
match
---
simple_stmt [92423,93285]
simple_stmt [92522,93384]
===
match
---
name: dag_id [34245,34251]
name: dag_id [34245,34251]
===
match
---
name: cls [109037,109040]
name: cls [109136,109139]
===
match
---
trailer [74527,74534]
trailer [74527,74534]
===
match
---
simple_stmt [14824,14878]
simple_stmt [14824,14878]
===
match
---
suite [40709,40894]
suite [40709,40894]
===
match
---
trailer [103659,103666]
trailer [103758,103765]
===
match
---
simple_stmt [66815,67219]
simple_stmt [66815,67219]
===
match
---
operator: = [62355,62356]
operator: = [62355,62356]
===
match
---
simple_stmt [57801,57851]
simple_stmt [57801,57851]
===
match
---
simple_stmt [26624,26686]
simple_stmt [26624,26686]
===
match
---
param [104107,104116]
param [104206,104215]
===
match
---
trailer [26483,26501]
trailer [26483,26501]
===
match
---
operator: @ [35693,35694]
operator: @ [35693,35694]
===
match
---
name: warnings [21759,21767]
name: warnings [21759,21767]
===
match
---
trailer [45712,45722]
trailer [45712,45722]
===
match
---
operator: = [74785,74786]
operator: = [74785,74786]
===
match
---
simple_stmt [75662,75729]
simple_stmt [75662,75729]
===
match
---
name: pickled [74111,74118]
name: pickled [74111,74118]
===
match
---
simple_stmt [64385,64400]
simple_stmt [64385,64400]
===
match
---
name: AttributeError [21191,21205]
name: AttributeError [21191,21205]
===
match
---
name: on_success_callback [16595,16614]
name: on_success_callback [16595,16614]
===
match
---
name: _comps [18008,18014]
name: _comps [18008,18014]
===
match
---
expr_stmt [3306,3339]
expr_stmt [3306,3339]
===
match
---
atom_expr [39702,39715]
atom_expr [39702,39715]
===
match
---
decorated [98716,99069]
decorated [98815,99168]
===
match
---
atom_expr [80928,80953]
atom_expr [80928,80953]
===
match
---
name: TI [55462,55464]
name: TI [55462,55464]
===
match
---
name: task_id [55086,55093]
name: task_id [55086,55093]
===
match
---
string: """         Get the Default DAG View, returns the default config value if DagModel does not         have a value         """ [100406,100530]
string: """         Get the Default DAG View, returns the default config value if DagModel does not         have a value         """ [100505,100629]
===
match
---
import_from [79460,79520]
import_from [79460,79520]
===
match
---
param [77611,77621]
param [77611,77621]
===
match
---
name: filelocs [86643,86651]
name: filelocs [86742,86750]
===
match
---
name: memo [68645,68649]
name: memo [68645,68649]
===
match
---
if_stmt [89726,89774]
if_stmt [89825,89873]
===
match
---
atom_expr [12640,12673]
atom_expr [12640,12673]
===
match
---
operator: , [13455,13456]
operator: , [13455,13456]
===
match
---
name: _schedule_interval [36207,36225]
name: _schedule_interval [36207,36225]
===
match
---
trailer [34228,34316]
trailer [34228,34316]
===
match
---
name: DagRun [39702,39708]
name: DagRun [39702,39708]
===
match
---
parameters [32458,32469]
parameters [32458,32469]
===
match
---
name: query [3856,3861]
name: query [3856,3861]
===
match
---
operator: @ [80435,80436]
operator: @ [80435,80436]
===
match
---
fstring_expr [98467,98505]
fstring_expr [98566,98604]
===
match
---
operator: = [83477,83478]
operator: = [83576,83577]
===
match
---
operator: , [2226,2227]
operator: , [2226,2227]
===
match
---
name: dag [85480,85483]
name: dag [85579,85582]
===
match
---
atom_expr [16924,16958]
atom_expr [16924,16958]
===
match
---
suite [98166,98621]
suite [98265,98720]
===
match
---
suite [24527,24572]
suite [24527,24572]
===
match
---
funcdef [99360,99475]
funcdef [99459,99574]
===
match
---
operator: { [71714,71715]
operator: { [71714,71715]
===
match
---
name: self [15760,15764]
name: self [15760,15764]
===
match
---
atom_expr [55560,55601]
atom_expr [55560,55601]
===
match
---
expr_stmt [20384,20429]
expr_stmt [20384,20429]
===
match
---
expr_stmt [60776,60790]
expr_stmt [60776,60790]
===
match
---
operator: , [92600,92601]
operator: , [92699,92700]
===
match
---
name: tasks [58699,58704]
name: tasks [58699,58704]
===
match
---
name: include_externally_triggered [29566,29594]
name: include_externally_triggered [29566,29594]
===
match
---
trailer [44417,44426]
trailer [44417,44426]
===
match
---
simple_stmt [51517,51561]
simple_stmt [51517,51561]
===
match
---
name: dag [86796,86799]
name: dag [86895,86898]
===
match
---
operator: , [52722,52723]
operator: , [52722,52723]
===
match
---
atom_expr [65719,65727]
atom_expr [65719,65727]
===
match
---
name: not_none_states [92061,92076]
name: not_none_states [92160,92175]
===
match
---
operator: , [1193,1194]
operator: , [1193,1194]
===
match
---
trailer [88036,88043]
trailer [88135,88142]
===
match
---
operator: = [28721,28722]
operator: = [28721,28722]
===
match
---
name: self [13602,13606]
name: self [13602,13606]
===
match
---
name: execution_date [53877,53891]
name: execution_date [53877,53891]
===
match
---
name: as_pk_tuple [45953,45964]
name: as_pk_tuple [45953,45964]
===
match
---
operator: = [38031,38032]
operator: = [38031,38032]
===
match
---
if_stmt [43148,43234]
if_stmt [43148,43234]
===
match
---
comp_op [55094,55100]
comp_op [55094,55100]
===
match
---
atom_expr [47986,47991]
atom_expr [47986,47991]
===
match
---
return_stmt [73540,73589]
return_stmt [73540,73589]
===
match
---
atom [53566,53579]
atom [53566,53579]
===
match
---
suite [61101,61196]
suite [61101,61196]
===
match
---
if_stmt [42649,42751]
if_stmt [42649,42751]
===
match
---
name: info [28990,28994]
name: info [28990,28994]
===
match
---
return_stmt [21674,21710]
return_stmt [21674,21710]
===
match
---
simple_stmt [65711,65728]
simple_stmt [65711,65728]
===
match
---
name: sys [13746,13749]
name: sys [13746,13749]
===
match
---
arglist [23510,23599]
arglist [23510,23599]
===
match
---
param [46669,46694]
param [46669,46694]
===
match
---
operator: , [67173,67174]
operator: , [67173,67174]
===
match
---
operator: = [100273,100274]
operator: = [100372,100373]
===
match
---
operator: = [72813,72814]
operator: = [72813,72814]
===
match
---
name: default_view [15935,15947]
name: default_view [15935,15947]
===
match
---
atom_expr [45031,45080]
atom_expr [45031,45080]
===
match
---
operator: , [99379,99380]
operator: , [99478,99479]
===
match
---
simple_stmt [68175,68216]
simple_stmt [68175,68216]
===
match
---
tfpdef [80497,80515]
tfpdef [80497,80515]
===
match
---
operator: , [65545,65546]
operator: , [65545,65546]
===
match
---
simple_stmt [48326,48342]
simple_stmt [48326,48342]
===
match
---
comparison [26438,26454]
comparison [26438,26454]
===
match
---
operator: = [83337,83338]
operator: = [83436,83437]
===
match
---
name: partial_subset [69234,69248]
name: partial_subset [69234,69248]
===
match
---
atom_expr [51675,51731]
atom_expr [51675,51731]
===
match
---
atom_expr [37524,37558]
atom_expr [37524,37558]
===
match
---
name: ValueError [33284,33294]
name: ValueError [33284,33294]
===
match
---
del_stmt [60811,60843]
del_stmt [60811,60843]
===
match
---
trailer [73283,73293]
trailer [73283,73293]
===
match
---
name: get [93703,93706]
name: get [93802,93805]
===
match
---
operator: , [91690,91691]
operator: , [91789,91790]
===
match
---
operator: , [87795,87796]
operator: , [87894,87895]
===
match
---
name: max_active_tasks [31178,31194]
name: max_active_tasks [31178,31194]
===
match
---
sync_comp_for [67499,67515]
sync_comp_for [67499,67515]
===
match
---
name: session [50860,50867]
name: session [50860,50867]
===
match
---
atom_expr [47430,47460]
atom_expr [47430,47460]
===
match
---
name: root_dag_id [97065,97076]
name: root_dag_id [97164,97175]
===
match
---
name: dags [66797,66801]
name: dags [66797,66801]
===
match
---
name: models [1985,1991]
name: models [1985,1991]
===
match
---
name: dag [48467,48470]
name: dag [48467,48470]
===
match
---
operator: , [94939,94940]
operator: , [95038,95039]
===
match
---
name: next_info [21681,21690]
name: next_info [21681,21690]
===
match
---
atom_expr [107850,107878]
atom_expr [107949,107977]
===
match
---
expr_stmt [59463,59480]
expr_stmt [59463,59480]
===
match
---
trailer [14353,14371]
trailer [14353,14371]
===
match
---
if_stmt [27455,27529]
if_stmt [27455,27529]
===
match
---
and_test [104959,105024]
and_test [105058,105123]
===
match
---
name: self [10844,10848]
name: self [10844,10848]
===
match
---
operator: , [97051,97052]
operator: , [97150,97151]
===
match
---
name: append [108838,108844]
name: append [108937,108943]
===
match
---
trailer [86590,86605]
trailer [86689,86704]
===
match
---
suite [94455,105490]
suite [94554,105589]
===
match
---
name: default_args [15176,15188]
name: default_args [15176,15188]
===
match
---
trailer [20495,20527]
trailer [20495,20527]
===
match
---
name: data_interval [21691,21704]
name: data_interval [21691,21704]
===
match
---
argument [106826,106846]
argument [106925,106945]
===
match
---
funcdef [46909,55623]
funcdef [46909,55623]
===
match
---
trailer [73582,73588]
trailer [73582,73588]
===
match
---
name: qry [91998,92001]
name: qry [92097,92100]
===
match
---
operator: , [27243,27244]
operator: , [27243,27244]
===
match
---
atom_expr [84830,84852]
atom_expr [84929,84951]
===
match
---
atom_expr [74024,74041]
atom_expr [74024,74041]
===
match
---
return_stmt [69222,69265]
return_stmt [69222,69265]
===
match
---
expr_stmt [52269,52311]
expr_stmt [52269,52311]
===
match
---
name: end_date [24506,24514]
name: end_date [24506,24514]
===
match
---
name: session [101901,101908]
name: session [102000,102007]
===
match
---
expr_stmt [76396,76445]
expr_stmt [76396,76445]
===
match
---
except_clause [33277,33294]
except_clause [33277,33294]
===
match
---
name: query [51517,51522]
name: query [51517,51522]
===
match
---
name: arguments [107311,107320]
name: arguments [107410,107419]
===
match
---
trailer [79559,79580]
trailer [79559,79580]
===
match
---
trailer [41277,41303]
trailer [41277,41303]
===
match
---
atom [45431,45433]
atom [45431,45433]
===
match
---
name: AirflowException [82757,82773]
name: AirflowException [82856,82872]
===
match
---
name: DeprecationWarning [28722,28740]
name: DeprecationWarning [28722,28740]
===
match
---
operator: , [29942,29943]
operator: , [29942,29943]
===
match
---
name: filter [48560,48566]
name: filter [48560,48566]
===
match
---
trailer [12167,12173]
trailer [12167,12173]
===
match
---
name: default_view [96100,96112]
name: default_view [96199,96211]
===
match
---
operator: = [87543,87544]
operator: = [87642,87643]
===
match
---
name: func [103821,103825]
name: func [103920,103924]
===
match
---
or_test [39489,39513]
or_test [39489,39513]
===
match
---
operator: = [92447,92448]
operator: = [92546,92547]
===
match
---
param [62110,62124]
param [62110,62124]
===
match
---
trailer [96613,96626]
trailer [96712,96725]
===
match
---
operator: == [89749,89751]
operator: == [89848,89850]
===
match
---
operator: , [18875,18876]
operator: , [18875,18876]
===
match
---
string: 'end_date' [15189,15199]
string: 'end_date' [15189,15199]
===
match
---
name: DagModel [35029,35037]
name: DagModel [35029,35037]
===
match
---
funcdef [80174,80430]
funcdef [80174,80430]
===
match
---
param [80748,80786]
param [80748,80786]
===
match
---
trailer [84984,84991]
trailer [85083,85090]
===
match
---
name: filter [61845,61851]
name: filter [61845,61851]
===
match
---
name: relativedelta [25036,25049]
name: relativedelta [25036,25049]
===
match
---
atom_expr [41888,41899]
atom_expr [41888,41899]
===
match
---
name: state [65300,65305]
name: state [65300,65305]
===
match
---
suite [52374,52812]
suite [52374,52812]
===
match
---
dotted_name [2760,2779]
dotted_name [2760,2779]
===
match
---
number: 2 [28765,28766]
number: 2 [28765,28766]
===
match
---
comparison [82931,82952]
comparison [83030,83051]
===
match
---
param [93822,93844]
param [93921,93943]
===
match
---
decorator [32431,32445]
decorator [32431,32445]
===
match
---
suite [102039,102992]
suite [102138,103091]
===
match
---
operator: , [88298,88299]
operator: , [88397,88398]
===
match
---
expr_stmt [49681,49721]
expr_stmt [49681,49721]
===
match
---
suite [75277,75308]
suite [75277,75308]
===
match
---
atom_expr [89793,89867]
atom_expr [89892,89966]
===
match
---
comparison [39702,39730]
comparison [39702,39730]
===
match
---
arglist [20754,20787]
arglist [20754,20787]
===
match
---
string: """         Returns a subset of the current dag as a deep copy of the current dag         based on a regex that should match one or many tasks, and includes         upstream and downstream neighbours based on the flag passed.          :param task_ids_or_regex: Either a list of task_ids, or a regex to             match against task ids (as a string, or compiled regex pattern).         :type task_ids_or_regex: [str] or str or re.Pattern         :param include_downstream: Include all downstream tasks of matched             tasks, in addition to matched tasks.         :param include_upstream: Include all upstream tasks of matched tasks,             in addition to matched tasks.         """ [69493,70187]
string: """         Returns a subset of the current dag as a deep copy of the current dag         based on a regex that should match one or many tasks, and includes         upstream and downstream neighbours based on the flag passed.          :param task_ids_or_regex: Either a list of task_ids, or a regex to             match against task ids (as a string, or compiled regex pattern).         :type task_ids_or_regex: [str] or str or re.Pattern         :param include_downstream: Include all downstream tasks of matched             tasks, in addition to matched tasks.         :param include_upstream: Include all upstream tasks of matched tasks,             in addition to matched tasks.         """ [69493,70187]
===
match
---
string: "`DAG.is_fixed_time_schedule()` is deprecated." [20973,21020]
string: "`DAG.is_fixed_time_schedule()` is deprecated." [20973,21020]
===
match
---
trailer [49219,49231]
trailer [49219,49231]
===
match
---
name: DagPickle [74479,74488]
name: DagPickle [74479,74488]
===
match
---
name: DEPRECATED_ACTION_CAN_DAG_READ [19498,19528]
name: DEPRECATED_ACTION_CAN_DAG_READ [19498,19528]
===
match
---
name: models [1891,1897]
name: models [1891,1897]
===
match
---
atom_expr [87518,87542]
atom_expr [87617,87641]
===
match
---
name: str [73623,73626]
name: str [73623,73626]
===
match
---
name: backref [96289,96296]
name: backref [96388,96395]
===
match
---
tfpdef [58766,58792]
tfpdef [58766,58792]
===
match
---
name: value [31578,31583]
name: value [31578,31583]
===
match
---
name: next_dagrun_data_interval_end [98680,98709]
name: next_dagrun_data_interval_end [98779,98808]
===
match
---
atom [10331,10522]
atom [10331,10522]
===
match
---
name: List [102014,102018]
name: List [102113,102117]
===
match
---
operator: = [83198,83199]
operator: = [83297,83298]
===
match
---
parameters [80181,80187]
parameters [80181,80187]
===
match
---
name: property [31683,31691]
name: property [31683,31691]
===
match
---
trailer [48115,48122]
trailer [48115,48122]
===
match
---
operator: = [95291,95292]
operator: = [95390,95391]
===
match
---
trailer [85589,85596]
trailer [85688,85695]
===
match
---
name: TimeRestriction [24113,24128]
name: TimeRestriction [24113,24128]
===
match
---
param [33036,33040]
param [33036,33040]
===
match
---
name: self [101285,101289]
name: self [101384,101388]
===
match
---
name: tags [84948,84952]
name: tags [85047,85051]
===
match
---
simple_stmt [48550,48585]
simple_stmt [48550,48585]
===
match
---
name: catchup [24750,24757]
name: catchup [24750,24757]
===
match
---
comparison [24872,24888]
comparison [24872,24888]
===
match
---
operator: = [65205,65206]
operator: = [65205,65206]
===
match
---
parameters [24798,24804]
parameters [24798,24804]
===
match
---
name: pendulum [25416,25424]
name: pendulum [25416,25424]
===
match
---
param [98790,98832]
param [98889,98931]
===
match
---
name: t [87620,87621]
name: t [87719,87720]
===
match
---
trailer [73415,73421]
trailer [73415,73421]
===
match
---
name: dags [66483,66487]
name: dags [66483,66487]
===
match
---
name: orm_dag [87950,87957]
name: orm_dag [88049,88056]
===
match
---
trailer [104565,104586]
trailer [104664,104685]
===
match
---
operator: , [42555,42556]
operator: , [42555,42556]
===
match
---
string: """File location of the importable dag 'file' relative to the configured DAGs folder.""" [33067,33155]
string: """File location of the importable dag 'file' relative to the configured DAGs folder.""" [33067,33155]
===
match
---
arglist [25014,25050]
arglist [25014,25050]
===
match
---
expr_stmt [85118,85177]
expr_stmt [85217,85276]
===
match
---
name: _context_managed_dag [108769,108789]
name: _context_managed_dag [108868,108888]
===
match
---
name: CronDataIntervalTimetable [2437,2462]
name: CronDataIntervalTimetable [2437,2462]
===
match
---
operator: = [40702,40703]
operator: = [40702,40703]
===
match
---
tfpdef [80525,80559]
tfpdef [80525,80559]
===
match
---
atom_expr [45060,45079]
atom_expr [45060,45079]
===
match
---
name: setter [31865,31871]
name: setter [31865,31871]
===
match
---
name: dag [89786,89789]
name: dag [89885,89888]
===
match
---
annassign [13617,13639]
annassign [13617,13639]
===
match
---
name: dag_id [39724,39730]
name: dag_id [39724,39730]
===
match
---
atom_expr [18453,18475]
atom_expr [18453,18475]
===
match
---
atom_expr [17275,17286]
atom_expr [17275,17286]
===
match
---
operator: , [46413,46414]
operator: , [46413,46414]
===
match
---
name: as_pk_tuple [48068,48079]
name: as_pk_tuple [48068,48079]
===
match
---
trailer [67495,67498]
trailer [67495,67498]
===
match
---
name: max_active_tasks [13241,13257]
name: max_active_tasks [13241,13257]
===
match
---
atom_expr [105460,105470]
atom_expr [105559,105569]
===
match
---
operator: , [57200,57201]
operator: , [57200,57201]
===
match
---
arglist [100673,100704]
arglist [100772,100803]
===
match
---
operator: = [64593,64594]
operator: = [64593,64594]
===
match
---
name: access_control [12190,12204]
name: access_control [12190,12204]
===
match
---
trailer [49795,49865]
trailer [49795,49865]
===
match
---
atom_expr [92423,92446]
atom_expr [92522,92545]
===
match
---
trailer [99253,99263]
trailer [99352,99362]
===
match
---
simple_stmt [101573,101644]
simple_stmt [101672,101743]
===
match
---
operator: , [31306,31307]
operator: , [31306,31307]
===
match
---
name: timedelta [11668,11677]
name: timedelta [11668,11677]
===
match
---
name: self [29098,29102]
name: self [29098,29102]
===
match
---
name: get_latest_execution_date [41278,41303]
name: get_latest_execution_date [41278,41303]
===
match
---
operator: = [91832,91833]
operator: = [91931,91932]
===
match
---
operator: = [55965,55966]
operator: = [55965,55966]
===
match
---
name: dagruns [40349,40356]
name: dagruns [40349,40356]
===
match
---
trailer [73071,73076]
trailer [73071,73076]
===
match
---
trailer [59414,59422]
trailer [59414,59422]
===
match
---
trailer [48676,48684]
trailer [48676,48684]
===
match
---
suite [54895,54954]
suite [54895,54954]
===
match
---
comparison [85403,85442]
comparison [85502,85541]
===
match
---
trailer [53570,53578]
trailer [53570,53578]
===
match
---
trailer [37244,37293]
trailer [37244,37293]
===
match
---
tfpdef [46015,46032]
tfpdef [46015,46032]
===
match
---
atom_expr [98988,99024]
atom_expr [99087,99123]
===
match
---
tfpdef [20301,20329]
tfpdef [20301,20329]
===
match
---
atom_expr [70371,70385]
atom_expr [70371,70385]
===
match
---
operator: , [77389,77390]
operator: , [77389,77390]
===
match
---
atom_expr [45966,45979]
atom_expr [45966,45979]
===
match
---
name: user_defined_macros [68668,68687]
name: user_defined_macros [68668,68687]
===
match
---
trailer [72417,72441]
trailer [72417,72441]
===
match
---
operator: , [99387,99388]
operator: , [99486,99487]
===
match
---
name: self [105472,105476]
name: self [105571,105575]
===
match
---
simple_stmt [70430,70478]
simple_stmt [70430,70478]
===
match
---
name: self [80258,80262]
name: self [80258,80262]
===
match
---
name: filter_task_group [72115,72132]
name: filter_task_group [72115,72132]
===
match
---
operator: , [22195,22196]
operator: , [22195,22196]
===
match
---
trailer [94931,94971]
trailer [95030,95070]
===
match
---
expr_stmt [24327,24380]
expr_stmt [24327,24380]
===
match
---
arglist [97435,97594]
arglist [97534,97693]
===
match
---
number: 2 [21894,21895]
number: 2 [21894,21895]
===
match
---
operator: { [71260,71261]
operator: { [71260,71261]
===
match
---
name: session [99807,99814]
name: session [99906,99913]
===
match
---
name: staticmethod [19020,19032]
name: staticmethod [19020,19032]
===
match
---
suite [20375,20899]
suite [20375,20899]
===
match
---
operator: = [69432,69433]
operator: = [69432,69433]
===
match
---
atom_expr [79597,80150]
atom_expr [79597,80150]
===
match
---
tfpdef [11695,11732]
tfpdef [11695,11732]
===
match
---
import_from [2931,2987]
import_from [2931,2987]
===
match
---
parameters [93346,93400]
parameters [93445,93499]
===
match
---
operator: = [99824,99825]
operator: = [99923,99924]
===
match
---
name: tis [54867,54870]
name: tis [54867,54870]
===
match
---
name: log [37661,37664]
name: log [37661,37664]
===
match
---
name: self [68479,68483]
name: self [68479,68483]
===
match
---
operator: @ [31160,31161]
operator: @ [31160,31161]
===
match
---
trailer [43613,43628]
trailer [43613,43628]
===
match
---
name: run [83523,83526]
name: run [83622,83625]
===
match
---
trailer [99291,99302]
trailer [99390,99401]
===
match
---
trailer [91534,91588]
trailer [91633,91687]
===
match
---
string: "Creating ORM DAG for %s" [85559,85584]
string: "Creating ORM DAG for %s" [85658,85683]
===
match
---
name: self [37975,37979]
name: self [37975,37979]
===
match
---
sync_comp_for [24455,24488]
sync_comp_for [24455,24488]
===
match
---
parameters [89114,89120]
parameters [89213,89219]
===
match
---
if_stmt [35950,36303]
if_stmt [35950,36303]
===
match
---
name: run [38048,38051]
name: run [38048,38051]
===
match
---
operator: , [80651,80652]
operator: , [80651,80652]
===
match
---
suite [60971,61073]
suite [60971,61073]
===
match
---
simple_stmt [106549,106572]
simple_stmt [106648,106671]
===
match
---
name: task [75185,75189]
name: task [75185,75189]
===
match
---
operator: = [85789,85790]
operator: = [85888,85889]
===
match
---
name: airflow [2496,2503]
name: airflow [2496,2503]
===
match
---
operator: , [64813,64814]
operator: , [64813,64814]
===
match
---
operator: } [16416,16417]
operator: } [16416,16417]
===
match
---
number: 0 [62469,62470]
number: 0 [62469,62470]
===
match
---
operator: , [2368,2369]
operator: , [2368,2369]
===
match
---
operator: , [104105,104106]
operator: , [104204,104205]
===
match
---
decorator [108692,108705]
decorator [108791,108804]
===
match
---
name: self [31302,31306]
name: self [31302,31306]
===
match
---
return_stmt [23458,23609]
return_stmt [23458,23609]
===
match
---
operator: == [18091,18093]
operator: == [18091,18093]
===
match
---
name: next_dagrun_create_after [104693,104717]
name: next_dagrun_create_after [104792,104816]
===
match
---
operator: , [23562,23563]
operator: , [23562,23563]
===
match
---
name: Dict [12215,12219]
name: Dict [12215,12219]
===
match
---
name: date [44979,44983]
name: date [44979,44983]
===
match
---
operator: = [87322,87323]
operator: = [87421,87422]
===
match
---
if_stmt [102870,102949]
if_stmt [102969,103048]
===
match
---
name: self [14886,14890]
name: self [14886,14890]
===
match
---
simple_stmt [71584,71635]
simple_stmt [71584,71635]
===
match
---
name: logical_date [27975,27987]
name: logical_date [27975,27987]
===
match
---
name: dag [108743,108746]
name: dag [108842,108845]
===
match
---
name: f_sig [106431,106436]
name: f_sig [106530,106535]
===
match
---
suite [76188,76231]
suite [76188,76231]
===
match
---
arglist [27511,27527]
arglist [27511,27527]
===
match
---
name: Optional [22206,22214]
name: Optional [22206,22214]
===
match
---
name: include_subdags [73628,73643]
name: include_subdags [73628,73643]
===
match
---
name: get_is_paused [35672,35685]
name: get_is_paused [35672,35685]
===
match
---
name: timezone [14902,14910]
name: timezone [14902,14910]
===
match
---
name: orm_dag [85622,85629]
name: orm_dag [85721,85728]
===
match
---
trailer [61949,61964]
trailer [61949,61964]
===
match
---
trailer [94100,94120]
trailer [94199,94219]
===
match
---
trailer [94057,94067]
trailer [94156,94166]
===
match
---
operator: { [82625,82626]
operator: { [82735,82736]
===
match
---
name: date_last_automated_dagrun [23648,23674]
name: date_last_automated_dagrun [23648,23674]
===
match
---
name: t [88111,88112]
name: t [88210,88211]
===
match
---
suite [109298,109339]
suite [109397,109438]
===
match
---
atom_expr [71743,71766]
atom_expr [71743,71766]
===
match
---
simple_stmt [61986,62051]
simple_stmt [61986,62051]
===
match
---
operator: , [108741,108742]
operator: , [108840,108841]
===
match
---
except_clause [21986,22007]
except_clause [21986,22007]
===
match
---
expr_stmt [17305,17384]
expr_stmt [17305,17384]
===
match
---
decorator [88770,88787]
decorator [88869,88886]
===
match
---
expr_stmt [49934,49981]
expr_stmt [49934,49981]
===
match
---
string: 'webserver' [11778,11789]
string: 'webserver' [11778,11789]
===
match
---
simple_stmt [98609,98621]
simple_stmt [98708,98720]
===
match
---
operator: = [15562,15563]
operator: = [15562,15563]
===
match
---
simple_stmt [59578,59605]
simple_stmt [59578,59605]
===
match
---
name: property [31591,31599]
name: property [31591,31599]
===
match
---
trailer [101808,101892]
trailer [101907,101991]
===
match
---
name: execution_date [45552,45566]
name: execution_date [45552,45566]
===
match
---
string: 'fileloc' [10452,10461]
string: 'fileloc' [10452,10461]
===
match
---
name: debug [105137,105142]
name: debug [105236,105241]
===
match
---
operator: = [57023,57024]
operator: = [57023,57024]
===
match
---
name: t [33764,33765]
name: t [33764,33765]
===
match
---
operator: , [66748,66749]
operator: , [66748,66749]
===
match
---
atom_expr [19753,19781]
atom_expr [19753,19781]
===
match
---
name: dry_run [66735,66742]
name: dry_run [66735,66742]
===
match
---
name: frozenset [92449,92458]
name: frozenset [92548,92557]
===
match
---
expr_stmt [68723,68778]
expr_stmt [68723,68778]
===
match
---
trailer [49095,49102]
trailer [49095,49102]
===
match
---
name: Optional [10549,10557]
name: Optional [10549,10557]
===
match
---
tfpdef [84238,84261]
tfpdef [84337,84360]
===
match
---
suite [30183,30213]
suite [30183,30213]
===
match
---
simple_stmt [84126,84169]
simple_stmt [84225,84268]
===
match
---
suite [51823,51853]
suite [51823,51853]
===
match
---
fstring_expr [82370,82384]
fstring_expr [82394,82408]
===
match
---
name: mark_success [79706,79718]
name: mark_success [79706,79718]
===
match
---
name: schedule_interval [36092,36109]
name: schedule_interval [36092,36109]
===
match
---
name: query [39812,39817]
name: query [39812,39817]
===
match
---
import_from [2148,2248]
import_from [2148,2248]
===
match
---
simple_stmt [26519,26565]
simple_stmt [26519,26565]
===
match
---
argument [50487,50508]
argument [50487,50508]
===
match
---
name: Base [1873,1877]
name: Base [1873,1877]
===
match
---
name: self [100749,100753]
name: self [100848,100852]
===
match
---
trailer [108004,108019]
trailer [108103,108118]
===
match
---
name: run_type [82897,82905]
name: run_type [82996,83004]
===
match
---
funcdef [17738,18037]
funcdef [17738,18037]
===
match
---
name: is_subdag [95010,95019]
name: is_subdag [95109,95118]
===
match
---
name: old_dag [109226,109233]
name: old_dag [109325,109332]
===
match
---
atom_expr [45928,45943]
atom_expr [45928,45943]
===
match
---
name: dagrun [37312,37318]
name: dagrun [37312,37318]
===
match
---
argument [80009,80024]
argument [80009,80024]
===
match
---
trailer [61851,61888]
trailer [61851,61888]
===
match
---
funcdef [31604,31677]
funcdef [31604,31677]
===
match
---
name: DR [3840,3842]
name: DR [3840,3842]
===
match
---
arglist [85909,86110]
arglist [86008,86209]
===
match
---
atom_expr [36280,36302]
atom_expr [36280,36302]
===
match
---
simple_stmt [43189,43234]
simple_stmt [43189,43234]
===
match
---
name: self [62096,62100]
name: self [62096,62100]
===
match
---
string: "" [107570,107572]
string: "" [107669,107671]
===
match
---
atom [65096,65111]
atom [65096,65111]
===
match
---
name: pickle_id [31855,31864]
name: pickle_id [31855,31864]
===
match
---
name: session [29552,29559]
name: session [29552,29559]
===
match
---
name: data_interval [80904,80917]
name: data_interval [80904,80917]
===
match
---
simple_stmt [35372,35462]
simple_stmt [35372,35462]
===
match
---
name: message [20554,20561]
name: message [20554,20561]
===
match
---
name: active_runs_of_dag [104167,104185]
name: active_runs_of_dag [104266,104284]
===
match
---
expr_stmt [17275,17295]
expr_stmt [17275,17295]
===
match
---
name: self [43629,43633]
name: self [43629,43633]
===
match
---
operator: = [73650,73651]
operator: = [73650,73651]
===
match
---
name: execution_date [38097,38111]
name: execution_date [38097,38111]
===
match
---
arglist [23741,23901]
arglist [23741,23901]
===
match
---
dotted_name [1754,1772]
dotted_name [1754,1772]
===
match
---
operator: = [23898,23899]
operator: = [23898,23899]
===
match
---
tfpdef [101291,101306]
tfpdef [101390,101405]
===
match
---
atom_expr [86896,86911]
atom_expr [86995,87010]
===
match
---
name: doc_md [17289,17295]
name: doc_md [17289,17295]
===
match
---
trailer [27153,27163]
trailer [27153,27163]
===
match
---
name: warn [30843,30847]
name: warn [30843,30847]
===
match
---
decorator [31766,31776]
decorator [31766,31776]
===
match
---
name: self [73808,73812]
name: self [73808,73812]
===
match
---
name: provide_session [101941,101956]
name: provide_session [102040,102055]
===
match
---
argument [50279,50301]
argument [50279,50301]
===
match
---
name: start_date [10997,11007]
name: start_date [10997,11007]
===
match
---
param [39095,39129]
param [39095,39129]
===
match
---
name: x [91780,91781]
name: x [91879,91880]
===
match
---
simple_stmt [66411,66424]
simple_stmt [66411,66424]
===
match
---
simple_stmt [3397,3476]
simple_stmt [3397,3476]
===
match
---
name: conf [89253,89257]
name: conf [89352,89356]
===
match
---
expr_stmt [10528,10580]
expr_stmt [10528,10580]
===
match
---
atom_expr [70397,70413]
atom_expr [70397,70413]
===
match
---
tfpdef [39095,39121]
tfpdef [39095,39121]
===
match
---
operator: == [48648,48650]
operator: == [48648,48650]
===
match
---
decorator [75313,75323]
decorator [75313,75323]
===
match
---
operator: = [96296,96297]
operator: = [96395,96396]
===
match
---
operator: = [104782,104783]
operator: = [104881,104882]
===
match
---
trailer [18624,18631]
trailer [18624,18631]
===
match
---
name: only_running [65124,65136]
name: only_running [65124,65136]
===
match
---
atom_expr [62000,62012]
atom_expr [62000,62012]
===
match
---
operator: , [79731,79732]
operator: , [79731,79732]
===
match
---
name: tzinfo [14009,14015]
name: tzinfo [14009,14015]
===
match
---
name: self [98064,98068]
name: self [98163,98167]
===
match
---
operator: , [11034,11035]
operator: , [11034,11035]
===
match
---
tfpdef [99807,99823]
tfpdef [99906,99922]
===
match
---
name: append [85652,85658]
name: append [85751,85757]
===
match
---
name: Dict [13856,13860]
name: Dict [13856,13860]
===
match
---
name: copy [51977,51981]
name: copy [51977,51981]
===
match
---
name: commit [57324,57330]
name: commit [57324,57330]
===
match
---
atom_expr [67492,67498]
atom_expr [67492,67498]
===
match
---
operator: , [54287,54288]
operator: , [54287,54288]
===
match
---
atom_expr [14675,14704]
atom_expr [14675,14704]
===
match
---
operator: = [20657,20658]
operator: = [20657,20658]
===
match
---
string: 'is_subdag' [92809,92820]
string: 'is_subdag' [92908,92919]
===
match
---
simple_stmt [85355,85388]
simple_stmt [85454,85487]
===
match
---
name: next_dagrun_data_interval_start [98377,98408]
name: next_dagrun_data_interval_start [98476,98507]
===
match
---
simple_stmt [24034,24056]
simple_stmt [24034,24056]
===
match
---
trailer [45538,45567]
trailer [45538,45567]
===
match
---
trailer [74781,74791]
trailer [74781,74791]
===
match
---
name: timezone [74852,74860]
name: timezone [74852,74860]
===
match
---
name: active_runs_of_dag [105286,105304]
name: active_runs_of_dag [105385,105403]
===
match
---
trailer [92389,92409]
trailer [92488,92508]
===
match
---
name: UtcDateTime [95460,95471]
name: UtcDateTime [95559,95570]
===
match
---
operator: @ [90857,90858]
operator: @ [90956,90957]
===
match
---
parameters [18775,18781]
parameters [18775,18781]
===
match
---
operator: * [25479,25480]
operator: * [25479,25480]
===
match
---
trailer [37660,37664]
trailer [37660,37664]
===
match
---
atom_expr [87545,87565]
atom_expr [87644,87664]
===
match
---
atom_expr [108803,108870]
atom_expr [108902,108969]
===
match
---
name: provide_session [29506,29521]
name: provide_session [29506,29521]
===
match
---
import_from [925,960]
import_from [925,960]
===
match
---
atom [91935,91971]
atom [92034,92070]
===
match
---
param [90931,90945]
param [91030,91044]
===
match
---
operator: = [39618,39619]
operator: = [39618,39619]
===
match
---
name: provide_session [90876,90891]
name: provide_session [90975,90990]
===
match
---
suite [68271,68907]
suite [68271,68907]
===
match
---
name: dag_id [48116,48122]
name: dag_id [48116,48122]
===
match
---
name: dag_id [39832,39838]
name: dag_id [39832,39838]
===
match
---
simple_stmt [21759,21907]
simple_stmt [21759,21907]
===
match
---
string: 'reason' [37540,37548]
string: 'reason' [37540,37548]
===
match
---
trailer [15535,15546]
trailer [15535,15546]
===
match
---
name: as_pk_tuple [50767,50778]
name: as_pk_tuple [50767,50778]
===
match
---
comparison [33896,33926]
comparison [33896,33926]
===
match
---
name: do_it [66117,66122]
name: do_it [66117,66122]
===
match
---
dotted_name [2837,2855]
dotted_name [2837,2855]
===
match
---
operator: = [77595,77596]
operator: = [77595,77596]
===
match
---
name: tasks [58461,58466]
name: tasks [58461,58466]
===
match
---
decorator [92247,92260]
decorator [92346,92359]
===
match
---
name: task_dict [70376,70385]
name: task_dict [70376,70385]
===
match
---
expr_stmt [17457,17513]
expr_stmt [17457,17513]
===
match
---
name: setdefault [94068,94078]
name: setdefault [94167,94177]
===
match
---
atom_expr [18253,18264]
atom_expr [18253,18264]
===
match
---
trailer [49623,49629]
trailer [49623,49629]
===
match
---
fstring_expr [17717,17730]
fstring_expr [17717,17730]
===
match
---
operator: , [97741,97742]
operator: , [97840,97841]
===
match
---
trailer [106687,106696]
trailer [106786,106795]
===
match
---
name: self [32728,32732]
name: self [32728,32732]
===
match
---
simple_stmt [52828,52850]
simple_stmt [52828,52850]
===
match
---
trailer [79580,79582]
trailer [79580,79582]
===
match
---
operator: == [34252,34254]
operator: == [34252,34254]
===
match
---
operator: = [88108,88109]
operator: = [88207,88208]
===
match
---
operator: , [1871,1872]
operator: , [1871,1872]
===
match
---
trailer [80549,80559]
trailer [80549,80559]
===
match
---
tfpdef [12190,12220]
tfpdef [12190,12220]
===
match
---
operator: , [68023,68024]
operator: , [68023,68024]
===
match
---
import_from [2541,2607]
import_from [2541,2607]
===
match
---
name: _upgrade_outdated_dag_access_control [19041,19077]
name: _upgrade_outdated_dag_access_control [19041,19077]
===
match
---
simple_stmt [21219,21231]
simple_stmt [21219,21231]
===
match
---
trailer [33234,33246]
trailer [33234,33246]
===
match
---
trailer [14430,14439]
trailer [14430,14439]
===
match
---
string: "or there may be a cyclic dependency." [52628,52666]
string: "or there may be a cyclic dependency." [52628,52666]
===
match
---
name: isinstance [41632,41642]
name: isinstance [41632,41642]
===
match
---
string: """         Returns the list of dag runs between start_date (inclusive) and end_date (inclusive).          :param start_date: The starting execution date of the DagRun to find.         :param end_date: The ending execution date of the DagRun to find.         :param session:         :return: The list of DagRuns found.         """ [40010,40340]
string: """         Returns the list of dag runs between start_date (inclusive) and end_date (inclusive).          :param start_date: The starting execution date of the DagRun to find.         :param end_date: The ending execution date of the DagRun to find.         :param session:         :return: The list of DagRuns found.         """ [40010,40340]
===
match
---
decorated [45602,46250]
decorated [45602,46250]
===
match
---
name: dag_obj [107766,107773]
name: dag_obj [107865,107872]
===
match
---
name: is_active [89885,89894]
name: is_active [89984,89993]
===
match
---
trailer [48627,48704]
trailer [48627,48704]
===
match
---
name: self [73511,73515]
name: self [73511,73515]
===
match
---
suite [21750,22091]
suite [21750,22091]
===
match
---
atom_expr [73808,73820]
atom_expr [73808,73820]
===
match
---
atom_expr [37592,37609]
atom_expr [37592,37609]
===
match
---
string: """     These items are stored in the database for state related information     """ [94529,94613]
string: """     These items are stored in the database for state related information     """ [94628,94712]
===
match
---
simple_stmt [32479,32562]
simple_stmt [32479,32562]
===
match
---
name: end_date [67828,67836]
name: end_date [67828,67836]
===
match
---
tfpdef [12151,12173]
tfpdef [12151,12173]
===
match
---
suite [79447,79583]
suite [79447,79583]
===
match
---
name: result [68900,68906]
name: result [68900,68906]
===
match
---
trailer [68632,68641]
trailer [68632,68641]
===
match
---
operator: , [66725,66726]
operator: , [66725,66726]
===
match
---
operator: , [65350,65351]
operator: , [65350,65351]
===
match
---
operator: , [47220,47221]
operator: , [47220,47221]
===
match
---
name: UtcDateTime [96670,96681]
name: UtcDateTime [96769,96780]
===
match
---
trailer [76476,76484]
trailer [76476,76484]
===
match
---
name: upstream [57183,57191]
name: upstream [57183,57191]
===
match
---
name: self [22126,22130]
name: self [22126,22130]
===
match
---
name: synchronize_session [62022,62041]
name: synchronize_session [62022,62041]
===
match
---
name: task [52940,52944]
name: task [52940,52944]
===
match
---
name: __new__ [68414,68421]
name: __new__ [68414,68421]
===
match
---
name: Optional [12121,12129]
name: Optional [12121,12129]
===
match
---
operator: >= [105002,105004]
operator: >= [105101,105103]
===
match
---
name: result [68617,68623]
name: result [68617,68623]
===
match
---
if_stmt [54641,55191]
if_stmt [54641,55191]
===
match
---
name: last_parsed_time [95198,95214]
name: last_parsed_time [95297,95313]
===
match
---
number: 0 [49390,49391]
number: 0 [49390,49391]
===
match
---
operator: , [46317,46318]
operator: , [46317,46318]
===
match
---
argument [67903,67928]
argument [67903,67928]
===
match
---
name: task [41804,41808]
name: task [41804,41808]
===
match
---
if_stmt [23985,24026]
if_stmt [23985,24026]
===
match
---
argument [66034,66049]
argument [66034,66049]
===
match
---
atom [61999,62020]
atom [61999,62020]
===
match
---
trailer [43295,43302]
trailer [43295,43302]
===
match
---
name: session [57359,57366]
name: session [57359,57366]
===
match
---
expr_stmt [31329,31359]
expr_stmt [31329,31359]
===
match
---
name: qry [35210,35213]
name: qry [35210,35213]
===
match
---
atom_expr [15171,15200]
atom_expr [15171,15200]
===
match
---
operator: @ [40899,40900]
operator: @ [40899,40900]
===
match
---
name: DagModel [107996,108004]
name: DagModel [108095,108103]
===
match
---
name: latest [28875,28881]
name: latest [28875,28881]
===
match
---
decorated [32567,32657]
decorated [32567,32657]
===
match
---
atom_expr [71244,71257]
atom_expr [71244,71257]
===
match
---
simple_stmt [46226,46250]
simple_stmt [46226,46250]
===
match
---
atom_expr [34941,35003]
atom_expr [34941,35003]
===
match
---
atom_expr [72747,72772]
atom_expr [72747,72772]
===
match
---
atom_expr [68875,68884]
atom_expr [68875,68884]
===
match
---
atom_expr [10549,10573]
atom_expr [10549,10573]
===
match
---
name: expression [103701,103711]
name: expression [103800,103810]
===
match
---
trailer [3871,3877]
trailer [3871,3877]
===
match
---
atom_expr [13777,13789]
atom_expr [13777,13789]
===
match
---
name: self [15805,15809]
name: self [15805,15809]
===
match
---
trailer [92050,92056]
trailer [92149,92155]
===
match
---
if_stmt [97368,97771]
if_stmt [97467,97870]
===
match
---
name: filter [74528,74534]
name: filter [74528,74534]
===
match
---
name: t [73559,73560]
name: t [73559,73560]
===
match
---
trailer [102474,102479]
trailer [102573,102578]
===
match
---
operator: = [30696,30697]
operator: = [30696,30697]
===
match
---
trailer [59446,59452]
trailer [59446,59452]
===
match
---
name: start_date [39965,39975]
name: start_date [39965,39975]
===
match
---
trailer [96899,96971]
trailer [96998,97070]
===
match
---
trailer [68180,68215]
trailer [68180,68215]
===
match
---
decorator [74424,74441]
decorator [74424,74441]
===
match
---
name: dag [88307,88310]
name: dag [88406,88409]
===
match
---
suite [104623,104725]
suite [104722,104824]
===
match
---
trailer [53074,53095]
trailer [53074,53095]
===
match
---
simple_stmt [99412,99475]
simple_stmt [99511,99574]
===
match
---
name: filter [89817,89823]
name: filter [89916,89922]
===
match
---
name: task_dict [73703,73712]
name: task_dict [73703,73712]
===
match
---
atom [100064,100248]
atom [100163,100347]
===
match
---
name: TaskInstance [43833,43845]
name: TaskInstance [43833,43845]
===
match
---
operator: @ [89964,89965]
operator: @ [90063,90064]
===
match
---
return_stmt [17702,17732]
return_stmt [17702,17732]
===
match
---
trailer [42925,42946]
trailer [42925,42946]
===
match
---
operator: = [10984,10985]
operator: = [10984,10985]
===
match
---
operator: , [3448,3449]
operator: , [3448,3449]
===
match
---
trailer [28805,28821]
trailer [28805,28821]
===
match
---
trailer [56008,56022]
trailer [56008,56022]
===
match
---
decorated [33787,33927]
decorated [33787,33927]
===
match
---
if_stmt [48713,48800]
if_stmt [48713,48800]
===
match
---
operator: = [96964,96965]
operator: = [97063,97064]
===
match
---
expr_stmt [70849,70901]
expr_stmt [70849,70901]
===
match
---
string: 'template_searchpath' [10471,10492]
string: 'template_searchpath' [10471,10492]
===
match
---
funcdef [18858,18943]
funcdef [18858,18943]
===
match
---
suite [100755,100807]
suite [100854,100906]
===
match
---
name: BaseOperator [32366,32378]
name: BaseOperator [32366,32378]
===
match
---
atom_expr [75633,75648]
atom_expr [75633,75648]
===
match
---
name: self [104751,104755]
name: self [104850,104854]
===
match
---
param [44805,44821]
param [44805,44821]
===
match
---
name: memo [70456,70460]
name: memo [70456,70460]
===
match
---
operator: = [95641,95642]
operator: = [95740,95741]
===
match
---
operator: = [102459,102460]
operator: = [102558,102559]
===
match
---
trailer [14639,14651]
trailer [14639,14651]
===
match
---
suite [100879,101241]
suite [100978,101340]
===
match
---
operator: = [87278,87279]
operator: = [87377,87378]
===
match
---
name: dag_id [91571,91577]
name: dag_id [91670,91676]
===
match
---
name: result [47955,47961]
name: result [47955,47961]
===
match
---
operator: = [31988,31989]
operator: = [31988,31989]
===
match
---
trailer [53425,53461]
trailer [53425,53461]
===
match
---
name: searchpath [42248,42258]
name: searchpath [42248,42258]
===
match
---
name: int [46104,46107]
name: int [46104,46107]
===
match
---
name: filter [92002,92008]
name: filter [92101,92107]
===
match
---
trailer [11238,11254]
trailer [11238,11254]
===
match
---
suite [56023,58258]
suite [56023,58258]
===
match
---
atom_expr [87620,87638]
atom_expr [87719,87737]
===
match
---
operator: , [65451,65452]
operator: , [65451,65452]
===
match
---
operator: , [80139,80140]
operator: , [80139,80140]
===
match
---
atom_expr [96115,96133]
atom_expr [96214,96232]
===
match
---
name: print [75104,75109]
name: print [75104,75109]
===
match
---
atom_expr [86508,86531]
atom_expr [86607,86630]
===
match
---
trailer [20681,20694]
trailer [20681,20694]
===
match
---
operator: = [61315,61316]
operator: = [61315,61316]
===
match
---
expr_stmt [51749,51772]
expr_stmt [51749,51772]
===
match
---
fstring [73944,73971]
fstring [73944,73971]
===
match
---
operator: @ [108915,108916]
operator: @ [109014,109015]
===
match
---
name: self [44799,44803]
name: self [44799,44803]
===
match
---
name: airflow [2705,2712]
name: airflow [2705,2712]
===
match
---
name: timezone [14215,14223]
name: timezone [14215,14223]
===
match
---
param [32777,32781]
param [32777,32781]
===
match
---
string: """     Python dag decorator. Wraps a function into an Airflow DAG.     Accepts kwargs for operator kwarg. Can be used to parametrize DAGs.      :param dag_args: Arguments for DAG object     :type dag_args: Any     :param dag_kwargs: Kwargs for DAG object.     :type dag_kwargs: Any     """ [105530,105820]
string: """     Python dag decorator. Wraps a function into an Airflow DAG.     Accepts kwargs for operator kwarg. Can be used to parametrize DAGs.      :param dag_args: Arguments for DAG object     :type dag_args: Any     :param dag_kwargs: Kwargs for DAG object.     :type dag_kwargs: Any     """ [105629,105919]
===
match
---
name: warn [69032,69036]
name: warn [69032,69036]
===
match
---
name: next_dagrun_info [104920,104936]
name: next_dagrun_info [105019,105035]
===
match
---
name: default_args [14131,14143]
name: default_args [14131,14143]
===
match
---
name: str [16939,16942]
name: str [16939,16942]
===
match
---
argument [57979,57996]
argument [57979,57996]
===
match
---
simple_stmt [88835,89042]
simple_stmt [88934,89141]
===
match
---
name: query [61930,61935]
name: query [61930,61935]
===
match
---
simple_stmt [75351,75387]
simple_stmt [75351,75387]
===
match
---
trailer [42476,42493]
trailer [42476,42493]
===
match
---
name: Exception [74265,74274]
name: Exception [74265,74274]
===
match
---
trailer [96505,96518]
trailer [96604,96617]
===
match
---
name: isinstance [71787,71797]
name: isinstance [71787,71797]
===
match
---
name: jinja_environment_kwargs [17489,17513]
name: jinja_environment_kwargs [17489,17513]
===
match
---
string: """Returns a boolean indicating whether this DAG is active""" [34865,34926]
string: """Returns a boolean indicating whether this DAG is active""" [34865,34926]
===
match
---
name: _pickle_id [13607,13617]
name: _pickle_id [13607,13617]
===
match
---
trailer [34282,34288]
trailer [34282,34288]
===
match
---
number: 100 [94278,94281]
number: 100 [94377,94380]
===
match
---
name: setter [31270,31276]
name: setter [31270,31276]
===
match
---
name: settings [88437,88445]
name: settings [88536,88544]
===
match
---
arglist [29647,29734]
arglist [29647,29734]
===
match
---
trailer [86332,86338]
trailer [86431,86437]
===
match
---
atom_expr [85361,85387]
atom_expr [85460,85486]
===
match
---
if_stmt [76455,76952]
if_stmt [76455,76952]
===
match
---
name: all_tis [66765,66772]
name: all_tis [66765,66772]
===
match
---
name: self [76738,76742]
name: self [76738,76742]
===
match
---
trailer [48369,48377]
trailer [48369,48377]
===
match
---
operator: @ [99480,99481]
operator: @ [99579,99580]
===
match
---
import_as_names [3209,3233]
import_as_names [3209,3233]
===
match
---
param [105838,105849]
param [105937,105948]
===
match
---
operator: , [92791,92792]
operator: , [92890,92891]
===
match
---
atom_expr [86477,86490]
atom_expr [86576,86589]
===
match
---
name: template_undefined [42537,42555]
name: template_undefined [42537,42555]
===
match
---
atom_expr [37471,37511]
atom_expr [37471,37511]
===
match
---
operator: = [55367,55368]
operator: = [55367,55368]
===
match
---
operator: = [62468,62469]
operator: = [62468,62469]
===
match
---
suite [84692,84712]
suite [84791,84811]
===
match
---
name: context [37461,37468]
name: context [37461,37468]
===
match
---
funcdef [105492,107818]
funcdef [105591,107917]
===
match
---
name: bool [73645,73649]
name: bool [73645,73649]
===
match
---
string: 'task_ids' [10359,10369]
string: 'task_ids' [10359,10369]
===
match
---
name: self [99101,99105]
name: self [99200,99204]
===
match
---
atom_expr [11175,11188]
atom_expr [11175,11188]
===
match
---
name: execution_date [83073,83087]
name: execution_date [83172,83186]
===
match
---
name: include_subdags [65319,65334]
name: include_subdags [65319,65334]
===
match
---
comp_op [82972,82978]
comp_op [83071,83077]
===
match
---
simple_stmt [832,842]
simple_stmt [832,842]
===
match
---
name: self [35964,35968]
name: self [35964,35968]
===
match
---
trailer [100100,100107]
trailer [100199,100206]
===
match
---
operator: , [101306,101307]
operator: , [101405,101406]
===
match
---
name: airflow [1883,1890]
name: airflow [1883,1890]
===
match
---
funcdef [89094,89354]
funcdef [89193,89453]
===
match
---
name: include_subdags [73768,73783]
name: include_subdags [73768,73783]
===
match
---
atom_expr [32728,32744]
atom_expr [32728,32744]
===
match
---
name: fileloc [101067,101074]
name: fileloc [101166,101173]
===
match
---
expr_stmt [27177,27190]
expr_stmt [27177,27190]
===
match
---
name: self [35667,35671]
name: self [35667,35671]
===
match
---
atom_expr [4050,4074]
atom_expr [4050,4074]
===
match
---
string: 'end_date' [14640,14650]
string: 'end_date' [14640,14650]
===
match
---
operator: = [12027,12028]
operator: = [12027,12028]
===
match
---
param [33981,33986]
param [33981,33986]
===
match
---
operator: , [92671,92672]
operator: , [92770,92771]
===
match
---
name: earliest [24327,24335]
name: earliest [24327,24335]
===
match
---
name: all [54871,54874]
name: all [54871,54874]
===
match
---
name: timetables [2410,2420]
name: timetables [2410,2420]
===
match
---
name: list [60525,60529]
name: list [60525,60529]
===
match
---
simple_stmt [857,871]
simple_stmt [857,871]
===
match
---
expr_stmt [25225,25260]
expr_stmt [25225,25260]
===
match
---
name: kwargs [68939,68945]
name: kwargs [68939,68945]
===
match
---
param [73994,73998]
param [73994,73998]
===
match
---
name: Optional [12319,12327]
name: Optional [12319,12327]
===
match
---
atom_expr [48481,48519]
atom_expr [48481,48519]
===
match
---
name: end_date [24480,24488]
name: end_date [24480,24488]
===
match
---
operator: = [65299,65300]
operator: = [65299,65300]
===
match
---
fstring_start: f' [16371,16373]
fstring_start: f' [16371,16373]
===
match
---
comparison [73687,73712]
comparison [73687,73712]
===
match
---
trailer [53733,54631]
trailer [53733,54631]
===
match
---
simple_stmt [1233,1247]
simple_stmt [1233,1247]
===
match
---
name: task_ids [48875,48883]
name: task_ids [48875,48883]
===
match
---
atom_expr [73019,73079]
atom_expr [73019,73079]
===
match
---
decorator [80435,80452]
decorator [80435,80452]
===
match
---
operator: , [93269,93270]
operator: , [93368,93369]
===
match
---
simple_stmt [29860,30050]
simple_stmt [29860,30050]
===
match
---
atom [66775,66777]
atom [66775,66777]
===
match
---
trailer [90817,90822]
trailer [90916,90921]
===
match
---
simple_stmt [34178,34317]
simple_stmt [34178,34317]
===
match
---
suite [3252,3304]
suite [3252,3304]
===
match
---
suite [79309,79421]
suite [79309,79421]
===
match
---
simple_stmt [29611,29745]
simple_stmt [29611,29745]
===
match
---
name: os [839,841]
name: os [839,841]
===
match
---
trailer [21593,21611]
trailer [21593,21611]
===
match
---
name: self [76431,76435]
name: self [76431,76435]
===
match
---
trailer [93692,93702]
trailer [93791,93801]
===
match
---
operator: @ [31057,31058]
operator: @ [31057,31058]
===
match
---
arglist [11519,11553]
arglist [11519,11553]
===
match
---
name: dag_by_ids [85361,85371]
name: dag_by_ids [85460,85470]
===
match
---
operator: , [1214,1215]
operator: , [1214,1215]
===
match
---
operator: = [86873,86874]
operator: = [86972,86973]
===
match
---
atom_expr [82514,82546]
atom_expr [82624,82656]
===
match
---
trailer [107011,107018]
trailer [107110,107117]
===
match
---
trailer [90811,90817]
trailer [90910,90916]
===
match
---
name: r [98503,98504]
name: r [98602,98603]
===
match
---
name: visited_external_tis [54562,54582]
name: visited_external_tis [54562,54582]
===
match
---
import_name [892,908]
import_name [892,908]
===
match
---
expr_stmt [36207,36232]
expr_stmt [36207,36232]
===
match
---
name: verbose [80009,80016]
name: verbose [80009,80016]
===
match
---
atom_expr [49255,49294]
atom_expr [49255,49294]
===
match
---
expr_stmt [94306,94381]
expr_stmt [94405,94480]
===
match
---
simple_stmt [22236,23047]
simple_stmt [22236,23047]
===
match
---
operator: = [28795,28796]
operator: = [28795,28796]
===
match
---
trailer [45782,45798]
trailer [45782,45798]
===
match
---
import_name [1247,1262]
import_name [1247,1262]
===
match
---
import_from [1931,1971]
import_from [1931,1971]
===
match
---
operator: = [64844,64845]
operator: = [64844,64845]
===
match
---
string: '*' [86365,86368]
string: '*' [86464,86467]
===
match
---
atom_expr [10558,10572]
atom_expr [10558,10572]
===
match
---
name: state [49849,49854]
name: state [49849,49854]
===
match
---
arglist [84154,84167]
arglist [84253,84266]
===
match
---
atom_expr [21759,21906]
atom_expr [21759,21906]
===
match
---
tfpdef [62536,62568]
tfpdef [62536,62568]
===
match
---
atom [24152,24202]
atom [24152,24202]
===
match
---
trailer [72318,72327]
trailer [72318,72327]
===
match
---
name: user_defined_filters [43250,43270]
name: user_defined_filters [43250,43270]
===
match
---
name: end_date [47025,47033]
name: end_date [47025,47033]
===
match
---
trailer [47511,47528]
trailer [47511,47528]
===
match
---
operator: , [83318,83319]
operator: , [83417,83418]
===
match
---
name: DeprecationWarning [20090,20108]
name: DeprecationWarning [20090,20108]
===
match
---
return_stmt [32962,32995]
return_stmt [32962,32995]
===
match
---
trailer [80592,80597]
trailer [80592,80597]
===
match
---
name: self [58760,58764]
name: self [58760,58764]
===
match
---
trailer [53308,53337]
trailer [53308,53337]
===
match
---
name: Tuple [1178,1183]
name: Tuple [1178,1183]
===
match
---
name: orm_dags [86688,86696]
name: orm_dags [86787,86795]
===
match
---
suite [88701,88765]
suite [88800,88864]
===
match
---
argument [54407,54442]
argument [54407,54442]
===
match
---
arglist [21786,21896]
arglist [21786,21896]
===
match
---
atom_expr [48113,48122]
atom_expr [48113,48122]
===
match
---
trailer [21767,21772]
trailer [21767,21772]
===
match
---
name: warn [30310,30314]
name: warn [30310,30314]
===
match
---
trailer [103859,103868]
trailer [103958,103967]
===
match
---
trailer [105325,105341]
trailer [105424,105440]
===
match
---
not_test [75605,75624]
not_test [75605,75624]
===
match
---
param [36389,36396]
param [36389,36396]
===
match
---
trailer [106825,106872]
trailer [106924,106971]
===
match
---
name: settings [99123,99131]
name: settings [99222,99230]
===
match
---
atom_expr [99593,99719]
atom_expr [99692,99818]
===
match
---
name: include_downstream [70813,70831]
name: include_downstream [70813,70831]
===
match
---
funcdef [75327,75437]
funcdef [75327,75437]
===
match
---
name: is_ [49855,49858]
name: is_ [49855,49858]
===
match
---
atom [64846,64848]
atom [64846,64848]
===
match
---
trailer [33178,33183]
trailer [33178,33183]
===
match
---
simple_stmt [87260,87285]
simple_stmt [87359,87384]
===
match
---
trailer [92483,92488]
trailer [92582,92587]
===
match
---
name: has_task_concurrency_limits [87586,87613]
name: has_task_concurrency_limits [87685,87712]
===
match
---
trailer [15086,15099]
trailer [15086,15099]
===
match
---
sync_comp_for [49701,49720]
sync_comp_for [49701,49720]
===
match
---
operator: , [21020,21021]
operator: , [21020,21021]
===
match
---
name: DagRun [39732,39738]
name: DagRun [39732,39738]
===
match
---
name: copy [68628,68632]
name: copy [68628,68632]
===
match
---
name: DagModel [90428,90436]
name: DagModel [90527,90535]
===
match
---
name: commit [57394,57400]
name: commit [57394,57400]
===
match
---
trailer [38854,38856]
trailer [38854,38856]
===
match
---
operator: = [67314,67315]
operator: = [67314,67315]
===
match
---
operator: , [85071,85072]
operator: , [85170,85171]
===
match
---
argument [69190,69202]
argument [69190,69202]
===
match
---
name: task_id [76666,76673]
name: task_id [76666,76673]
===
match
---
tfpdef [61340,61356]
tfpdef [61340,61356]
===
match
---
name: DeltaDataIntervalTimetable [2464,2490]
name: DeltaDataIntervalTimetable [2464,2490]
===
match
---
name: jinja_environment_kwargs [42725,42749]
name: jinja_environment_kwargs [42725,42749]
===
match
---
name: datetime [98088,98096]
name: datetime [98187,98195]
===
match
---
simple_stmt [12563,12612]
simple_stmt [12563,12612]
===
match
---
name: states [91749,91755]
name: states [91848,91854]
===
match
---
trailer [43207,43233]
trailer [43207,43233]
===
match
---
name: end_date [44704,44712]
name: end_date [44704,44712]
===
match
---
name: dag [73894,73897]
name: dag [73894,73897]
===
match
---
name: _schedule_interval [36318,36336]
name: _schedule_interval [36318,36336]
===
match
---
tfpdef [25490,25501]
tfpdef [25490,25501]
===
match
---
trailer [35798,35941]
trailer [35798,35941]
===
match
---
tfpdef [11207,11255]
tfpdef [11207,11255]
===
match
---
name: _default_view [15914,15927]
name: _default_view [15914,15927]
===
match
---
name: max_active_runs [105326,105341]
name: max_active_runs [105425,105440]
===
match
---
atom_expr [55549,55602]
atom_expr [55549,55602]
===
match
---
atom_expr [91505,91525]
atom_expr [91604,91624]
===
match
---
atom_expr [74676,74688]
atom_expr [74676,74688]
===
match
---
name: pickle_id [74696,74705]
name: pickle_id [74696,74705]
===
match
---
tfpdef [93870,93888]
tfpdef [93969,93987]
===
match
---
operator: , [39853,39854]
operator: , [39853,39854]
===
match
---
name: str [12423,12426]
name: str [12423,12426]
===
match
---
decorator [33001,33011]
decorator [33001,33011]
===
match
---
operator: = [47317,47318]
operator: = [47317,47318]
===
match
---
trailer [88407,88411]
trailer [88506,88510]
===
match
---
simple_stmt [57056,57072]
simple_stmt [57056,57072]
===
match
---
atom_expr [74293,74310]
atom_expr [74293,74310]
===
match
---
param [45692,45723]
param [45692,45723]
===
match
---
name: s [49699,49700]
name: s [49699,49700]
===
match
---
name: self [75609,75613]
name: self [75609,75613]
===
match
---
operator: = [54369,54370]
operator: = [54369,54370]
===
match
---
atom_expr [23927,23976]
atom_expr [23927,23976]
===
match
---
arglist [96344,96367]
arglist [96443,96466]
===
match
---
comparison [61943,61976]
comparison [61943,61976]
===
match
---
if_stmt [67260,67299]
if_stmt [67260,67299]
===
match
---
name: max_recursion_depth [54472,54491]
name: max_recursion_depth [54472,54491]
===
match
---
simple_stmt [89465,89718]
simple_stmt [89564,89817]
===
match
---
name: str [46161,46164]
name: str [46161,46164]
===
match
---
simple_stmt [102983,102992]
simple_stmt [103082,103091]
===
match
---
if_stmt [91773,92131]
if_stmt [91872,92230]
===
match
---
string: 'parent_dag' [92512,92524]
string: 'parent_dag' [92611,92623]
===
match
---
name: confirm_prompt [66600,66614]
name: confirm_prompt [66600,66614]
===
match
---
expr_stmt [72682,72773]
expr_stmt [72682,72773]
===
match
---
name: wrapper [107810,107817]
name: wrapper [107909,107916]
===
match
---
trailer [29918,29925]
trailer [29918,29925]
===
match
---
trailer [104831,104843]
trailer [104930,104942]
===
match
---
name: node [60584,60588]
name: node [60584,60588]
===
match
---
name: start_date [75822,75832]
name: start_date [75822,75832]
===
match
---
name: max_active_runs [105009,105024]
name: max_active_runs [105108,105123]
===
match
---
operator: = [20477,20478]
operator: = [20477,20478]
===
match
---
name: dag [71308,71311]
name: dag [71308,71311]
===
match
---
trailer [44261,44267]
trailer [44261,44267]
===
match
---
name: cls [92290,92293]
name: cls [92389,92392]
===
match
---
atom_expr [107305,107328]
atom_expr [107404,107427]
===
match
---
name: FrozenSet [10558,10567]
name: FrozenSet [10558,10567]
===
match
---
simple_stmt [95113,95156]
simple_stmt [95212,95255]
===
match
---
name: models [107943,107949]
name: models [108042,108048]
===
match
---
name: session [101751,101758]
name: session [101850,101857]
===
match
---
name: copied [72297,72303]
name: copied [72297,72303]
===
match
---
suite [89316,89354]
suite [89415,89453]
===
match
---
name: SubDagOperator [59246,59260]
name: SubDagOperator [59246,59260]
===
match
---
operator: * [105500,105501]
operator: * [105599,105600]
===
match
---
name: external_trigger [38860,38876]
name: external_trigger [38860,38876]
===
match
---
simple_stmt [18138,18172]
simple_stmt [18138,18172]
===
match
---
expr_stmt [42248,42274]
expr_stmt [42248,42274]
===
match
---
operator: } [94098,94099]
operator: } [94197,94198]
===
match
---
expr_stmt [95278,95312]
expr_stmt [95377,95411]
===
match
---
name: param [107375,107380]
name: param [107474,107479]
===
match
---
name: Optional [55872,55880]
name: Optional [55872,55880]
===
match
---
decorator [90857,90871]
decorator [90956,90970]
===
match
---
name: dag_models [102511,102521]
name: dag_models [102610,102620]
===
match
---
atom_expr [90682,90692]
atom_expr [90781,90791]
===
match
---
expr_stmt [24827,24860]
expr_stmt [24827,24860]
===
match
---
arith_expr [71357,71385]
arith_expr [71357,71385]
===
match
---
parameters [38191,38234]
parameters [38191,38234]
===
match
---
simple_stmt [86969,87029]
simple_stmt [87068,87128]
===
match
---
name: ti_list [66034,66041]
name: ti_list [66034,66041]
===
match
---
name: skip_locked [3098,3109]
name: skip_locked [3098,3109]
===
match
---
atom_expr [94693,94707]
atom_expr [94792,94806]
===
match
---
comparison [49533,49542]
comparison [49533,49542]
===
match
---
trailer [66020,66050]
trailer [66020,66050]
===
match
---
argument [35628,35640]
argument [35628,35640]
===
match
---
trailer [44952,44959]
trailer [44952,44959]
===
match
---
operator: , [1084,1085]
operator: , [1084,1085]
===
match
---
string: "`DAG.normalize_schedule()` is deprecated." [29146,29189]
string: "`DAG.normalize_schedule()` is deprecated." [29146,29189]
===
match
---
operator: = [45195,45196]
operator: = [45195,45196]
===
match
---
argument [101855,101882]
argument [101954,101981]
===
match
---
operator: = [94241,94242]
operator: = [94340,94341]
===
match
---
param [75076,75081]
param [75076,75081]
===
match
---
tfpdef [12113,12134]
tfpdef [12113,12134]
===
match
---
name: DagRun [86461,86467]
name: DagRun [86560,86566]
===
match
---
if_stmt [27689,27811]
if_stmt [27689,27811]
===
match
---
trailer [44475,44484]
trailer [44475,44484]
===
match
---
operator: = [82663,82664]
operator: = [82773,82774]
===
match
---
simple_stmt [71461,71534]
simple_stmt [71461,71534]
===
match
---
string: "`DAG.next_dagrun_after_date()` is deprecated. Please use `DAG.next_dagrun_info()` instead." [23741,23833]
string: "`DAG.next_dagrun_after_date()` is deprecated. Please use `DAG.next_dagrun_info()` instead." [23741,23833]
===
match
---
atom_expr [13188,13200]
atom_expr [13188,13200]
===
match
---
suite [84277,88765]
suite [84376,88864]
===
match
---
name: jinja_environment_kwargs [42657,42681]
name: jinja_environment_kwargs [42657,42681]
===
match
---
suite [22008,22033]
suite [22008,22033]
===
match
---
trailer [94640,94648]
trailer [94739,94747]
===
match
---
tfpdef [93353,93374]
tfpdef [93452,93473]
===
match
---
trailer [45019,45030]
trailer [45019,45030]
===
match
---
trailer [64663,64668]
trailer [64663,64668]
===
match
---
name: self [29407,29411]
name: self [29407,29411]
===
match
---
param [90959,90971]
param [91058,91070]
===
match
---
simple_stmt [1032,1232]
simple_stmt [1032,1232]
===
match
---
param [10922,10988]
param [10922,10988]
===
match
---
operator: @ [24764,24765]
operator: @ [24764,24765]
===
match
---
for_stmt [102494,102992]
for_stmt [102593,103091]
===
match
---
name: _max_active_tasks [31334,31351]
name: _max_active_tasks [31334,31351]
===
match
---
operator: = [66858,66859]
operator: = [66858,66859]
===
match
---
suite [55262,55500]
suite [55262,55500]
===
match
---
suite [89233,89303]
suite [89332,89402]
===
match
---
decorated [99480,99720]
decorated [99579,99819]
===
match
---
operator: , [46183,46184]
operator: , [46183,46184]
===
match
---
trailer [48693,48702]
trailer [48693,48702]
===
match
---
if_stmt [49184,49982]
if_stmt [49184,49982]
===
match
---
name: copy [71560,71564]
name: copy [71560,71564]
===
match
---
except_clause [21184,21205]
except_clause [21184,21205]
===
match
---
comparison [29881,30039]
comparison [29881,30039]
===
match
---
trailer [39633,39641]
trailer [39633,39641]
===
match
---
param [90029,90045]
param [90128,90144]
===
match
---
trailer [46583,46590]
trailer [46583,46590]
===
match
---
operator: , [86109,86110]
operator: , [86208,86209]
===
match
---
name: date_range [20202,20212]
name: date_range [20202,20212]
===
match
---
argument [87620,87669]
argument [87719,87768]
===
match
---
number: 0 [65791,65792]
number: 0 [65791,65792]
===
match
---
name: dag_hash [83388,83396]
name: dag_hash [83487,83495]
===
match
---
trailer [19911,19916]
trailer [19911,19916]
===
match
---
name: get_active_runs [37784,37799]
name: get_active_runs [37784,37799]
===
match
---
operator: = [101332,101333]
operator: = [101431,101432]
===
match
---
trailer [16928,16958]
trailer [16928,16958]
===
match
---
trailer [45529,45538]
trailer [45529,45538]
===
match
---
name: int [31315,31318]
name: int [31315,31318]
===
match
---
name: args [106121,106125]
name: args [106220,106224]
===
match
---
simple_stmt [84286,84672]
simple_stmt [84385,84771]
===
match
---
argument [32306,32321]
argument [32306,32321]
===
match
---
argument [96289,96311]
argument [96388,96410]
===
match
---
string: 'params' [68574,68582]
string: 'params' [68574,68582]
===
match
---
name: cls [68422,68425]
name: cls [68422,68425]
===
match
---
trailer [67238,67245]
trailer [67238,67245]
===
match
---
param [69299,69304]
param [69299,69304]
===
match
---
operator: , [96884,96885]
operator: , [96983,96984]
===
match
---
decorator [31252,31277]
decorator [31252,31277]
===
match
---
tfpdef [11440,11466]
tfpdef [11440,11466]
===
match
---
name: Optional [11409,11417]
name: Optional [11409,11417]
===
match
---
name: filter [35240,35246]
name: filter [35240,35246]
===
match
---
trailer [73747,73756]
trailer [73747,73756]
===
match
---
argument [54472,54511]
argument [54472,54511]
===
match
---
tfpdef [22140,22195]
tfpdef [22140,22195]
===
match
---
atom_expr [98372,98408]
atom_expr [98471,98507]
===
match
---
name: airflow [2112,2119]
name: airflow [2112,2119]
===
match
---
operator: , [86029,86030]
operator: , [86128,86129]
===
match
---
if_stmt [51574,51652]
if_stmt [51574,51652]
===
match
---
parameters [77255,77690]
parameters [77255,77690]
===
match
---
expr_stmt [87045,87082]
expr_stmt [87144,87181]
===
match
---
operator: , [54050,54051]
operator: , [54050,54051]
===
match
---
suite [39136,39909]
suite [39136,39909]
===
match
---
suite [64872,64963]
suite [64872,64963]
===
match
---
operator: , [27783,27784]
operator: , [27783,27784]
===
match
---
operator: } [16962,16963]
operator: } [16962,16963]
===
match
---
name: datetime [80635,80643]
name: datetime [80635,80643]
===
match
---
trailer [76665,76673]
trailer [76665,76673]
===
match
---
simple_stmt [39681,39773]
simple_stmt [39681,39773]
===
match
---
dotted_name [80278,80289]
dotted_name [80278,80289]
===
match
---
operator: } [98011,98012]
operator: } [98110,98111]
===
match
---
not_test [53361,53377]
not_test [53361,53377]
===
match
---
atom_expr [98920,98954]
atom_expr [99019,99053]
===
match
---
argument [96353,96367]
argument [96452,96466]
===
match
---
atom_expr [74195,74217]
atom_expr [74195,74217]
===
match
---
name: min_date [44582,44590]
name: min_date [44582,44590]
===
match
---
import_as_names [1865,1877]
import_as_names [1865,1877]
===
match
---
name: align [27696,27701]
name: align [27696,27701]
===
match
---
and_test [14029,14098]
and_test [14029,14098]
===
match
---
operator: = [96335,96336]
operator: = [96434,96435]
===
match
---
name: __tablename__ [102424,102437]
name: __tablename__ [102523,102536]
===
match
---
import_from [1657,1709]
import_from [1657,1709]
===
match
---
operator: , [36422,36423]
operator: , [36422,36423]
===
match
---
suite [27468,27529]
suite [27468,27529]
===
match
---
atom_expr [90503,90521]
atom_expr [90602,90620]
===
match
---
simple_stmt [108593,108636]
simple_stmt [108692,108735]
===
match
---
trailer [18631,18642]
trailer [18631,18642]
===
match
---
name: session [65530,65537]
name: session [65530,65537]
===
match
---
trailer [92467,92482]
trailer [92566,92581]
===
match
---
return_stmt [36311,36336]
return_stmt [36311,36336]
===
match
---
operator: = [14289,14290]
operator: = [14289,14290]
===
match
---
name: TaskInstance [48444,48456]
name: TaskInstance [48444,48456]
===
match
---
name: do_it [65736,65741]
name: do_it [65736,65741]
===
match
---
name: next_dagrun_info [23480,23496]
name: next_dagrun_info [23480,23496]
===
match
---
trailer [92488,92490]
trailer [92587,92589]
===
match
---
name: copied [71584,71590]
name: copied [71584,71590]
===
match
---
tfpdef [46669,46686]
tfpdef [46669,46686]
===
match
---
decorators [99146,99181]
decorators [99245,99280]
===
match
---
param [46345,46376]
param [46345,46376]
===
match
---
not_test [61089,61100]
not_test [61089,61100]
===
match
---
name: x [49533,49534]
name: x [49533,49534]
===
match
---
operator: = [50778,50779]
operator: = [50778,50779]
===
match
---
name: pendulum [28946,28954]
name: pendulum [28946,28954]
===
match
---
funcdef [73498,73590]
funcdef [73498,73590]
===
match
---
name: cls [102420,102423]
name: cls [102519,102522]
===
match
---
atom_expr [76628,76711]
atom_expr [76628,76711]
===
match
---
if_stmt [38728,38916]
if_stmt [38728,38916]
===
match
---
parameters [97243,97277]
parameters [97342,97376]
===
match
---
operator: + [75128,75129]
operator: + [75128,75129]
===
match
---
suite [42682,42751]
suite [42682,42751]
===
match
---
name: tis [49746,49749]
name: tis [49746,49749]
===
match
---
operator: -> [98070,98072]
operator: -> [98169,98171]
===
match
---
name: type [18224,18228]
name: type [18224,18228]
===
match
---
operator: { [10331,10332]
operator: { [10331,10332]
===
match
---
operator: == [44327,44329]
operator: == [44327,44329]
===
match
---
argument [51425,51430]
argument [51425,51430]
===
match
---
atom_expr [28884,28910]
atom_expr [28884,28910]
===
match
---
name: end_date [76356,76364]
name: end_date [76356,76364]
===
match
---
name: updated_access_control [20170,20192]
name: updated_access_control [20170,20192]
===
match
---
expr_stmt [86969,87012]
expr_stmt [87068,87111]
===
match
---
trailer [87228,87235]
trailer [87327,87334]
===
match
---
trailer [68807,68814]
trailer [68807,68814]
===
match
---
expr_stmt [65711,65727]
expr_stmt [65711,65727]
===
match
---
operator: , [57996,57997]
operator: , [57996,57997]
===
match
---
name: str [10901,10904]
name: str [10901,10904]
===
match
---
name: earliest [26468,26476]
name: earliest [26468,26476]
===
match
---
atom_expr [13619,13632]
atom_expr [13619,13632]
===
match
---
name: on_failure_callback [16672,16691]
name: on_failure_callback [16672,16691]
===
match
---
comparison [39825,39853]
comparison [39825,39853]
===
match
---
operator: += [70964,70966]
operator: += [70964,70966]
===
match
---
name: exclude_task_ids [54254,54270]
name: exclude_task_ids [54254,54270]
===
match
---
name: task_id [55700,55707]
name: task_id [55700,55707]
===
match
---
operator: = [80042,80043]
operator: = [80042,80043]
===
match
---
operator: = [42885,42886]
operator: = [42885,42886]
===
match
---
name: default [32306,32313]
name: default [32306,32313]
===
match
---
trailer [75850,75861]
trailer [75850,75861]
===
match
---
atom_expr [72115,72147]
atom_expr [72115,72147]
===
match
---
trailer [31333,31351]
trailer [31333,31351]
===
match
---
name: result [53720,53726]
name: result [53720,53726]
===
match
---
if_stmt [42283,42363]
if_stmt [42283,42363]
===
match
---
import_from [1002,1031]
import_from [1002,1031]
===
match
---
operator: = [21440,21441]
operator: = [21440,21441]
===
match
---
trailer [51680,51687]
trailer [51680,51687]
===
match
---
name: end_date [50530,50538]
name: end_date [50530,50538]
===
match
---
name: DagStateChangeCallback [3524,3546]
name: DagStateChangeCallback [3524,3546]
===
match
---
return_stmt [33734,33781]
return_stmt [33734,33781]
===
match
---
simple_stmt [36259,36303]
simple_stmt [36259,36303]
===
match
---
simple_stmt [87578,87671]
simple_stmt [87677,87770]
===
match
---
operator: { [70367,70368]
operator: { [70367,70368]
===
match
---
return_stmt [99412,99474]
return_stmt [99511,99573]
===
match
---
name: int [11581,11584]
name: int [11581,11584]
===
match
---
atom_expr [51982,52007]
atom_expr [51982,52007]
===
match
---
fstring [67540,67626]
fstring [67540,67626]
===
match
---
operator: = [83840,83841]
operator: = [83939,83940]
===
match
---
name: task_id [76758,76765]
name: task_id [76758,76765]
===
match
---
trailer [54870,54874]
trailer [54870,54874]
===
match
---
expr_stmt [27931,28001]
expr_stmt [27931,28001]
===
match
---
atom_expr [54926,54932]
atom_expr [54926,54932]
===
match
---
name: FrozenSet [1116,1125]
name: FrozenSet [1116,1125]
===
match
---
operator: = [69200,69201]
operator: = [69200,69201]
===
match
---
name: DAG [108677,108680]
name: DAG [108776,108779]
===
match
---
atom_expr [89336,89353]
atom_expr [89435,89452]
===
match
---
parameters [29097,29109]
parameters [29097,29109]
===
match
---
trailer [68382,68392]
trailer [68382,68392]
===
match
---
if_stmt [98851,99069]
if_stmt [98950,99168]
===
match
---
name: Session [46652,46659]
name: Session [46652,46659]
===
match
---
trailer [107479,107489]
trailer [107578,107588]
===
match
---
trailer [85847,85870]
trailer [85946,85969]
===
match
---
name: DagRun [61768,61774]
name: DagRun [61768,61774]
===
match
---
simple_stmt [72562,72620]
simple_stmt [72562,72620]
===
match
---
operator: = [65537,65538]
operator: = [65537,65538]
===
match
---
operator: * [43790,43791]
operator: * [43790,43791]
===
match
---
name: __serialized_fields [10528,10547]
name: __serialized_fields [10528,10547]
===
match
---
not_test [13237,13257]
not_test [13237,13257]
===
match
---
name: kwargs [69258,69264]
name: kwargs [69258,69264]
===
match
---
operator: , [67836,67837]
operator: , [67836,67837]
===
match
---
expr_stmt [80317,80364]
expr_stmt [80317,80364]
===
match
---
operator: = [68751,68752]
operator: = [68751,68752]
===
match
---
operator: , [57169,57170]
operator: , [57169,57170]
===
match
---
simple_stmt [70555,70639]
simple_stmt [70555,70639]
===
match
---
tfpdef [46600,46633]
tfpdef [46600,46633]
===
match
---
name: DateTime [23694,23702]
name: DateTime [23694,23702]
===
match
---
name: start_date [20236,20246]
name: start_date [20236,20246]
===
match
---
trailer [80336,80347]
trailer [80336,80347]
===
match
---
operator: = [75430,75431]
operator: = [75430,75431]
===
match
---
name: Collection [47248,47258]
name: Collection [47248,47258]
===
match
---
name: result [20650,20656]
name: result [20650,20656]
===
match
---
name: warn [64664,64668]
name: warn [64664,64668]
===
match
---
name: self [89073,89077]
name: self [89172,89176]
===
match
---
simple_stmt [38244,38516]
simple_stmt [38244,38516]
===
match
---
name: executor [79438,79446]
name: executor [79438,79446]
===
match
---
trailer [93706,93728]
trailer [93805,93827]
===
match
---
expr_stmt [15610,15646]
expr_stmt [15610,15646]
===
match
---
name: self [50154,50158]
name: self [50154,50158]
===
match
---
atom_expr [74772,74791]
atom_expr [74772,74791]
===
match
---
operator: = [29836,29837]
operator: = [29836,29837]
===
match
---
funcdef [106108,107774]
funcdef [106207,107873]
===
match
---
simple_stmt [1931,1972]
simple_stmt [1931,1972]
===
match
---
atom_expr [77412,77451]
atom_expr [77412,77451]
===
match
---
trailer [38627,38657]
trailer [38627,38657]
===
match
---
name: most_recent_dag_run [104117,104136]
name: most_recent_dag_run [104216,104235]
===
match
---
argument [45327,45350]
argument [45327,45350]
===
match
---
name: typing [1037,1043]
name: typing [1037,1043]
===
match
---
name: self [33509,33513]
name: self [33509,33513]
===
match
---
name: DagBag [53227,53233]
name: DagBag [53227,53233]
===
match
---
funcdef [100363,100714]
funcdef [100462,100813]
===
match
---
operator: , [77366,77367]
operator: , [77366,77367]
===
match
---
operator: , [62171,62172]
operator: , [62171,62172]
===
match
---
name: role [19776,19780]
name: role [19776,19780]
===
match
---
trailer [27211,27221]
trailer [27211,27221]
===
match
---
name: utils [12465,12470]
name: utils [12465,12470]
===
match
---
name: bulk_sync_to_db [88482,88497]
name: bulk_sync_to_db [88581,88596]
===
match
---
decorator [99146,99160]
decorator [99245,99259]
===
match
---
operator: = [79753,79754]
operator: = [79753,79754]
===
match
---
operator: -> [34001,34003]
operator: -> [34001,34003]
===
match
---
name: t [73573,73574]
name: t [73573,73574]
===
match
---
trailer [102483,102485]
trailer [102582,102584]
===
match
---
name: self [101062,101066]
name: self [101161,101165]
===
match
---
name: Literal [46576,46583]
name: Literal [46576,46583]
===
match
---
operator: -> [58293,58295]
operator: -> [58293,58295]
===
match
---
trailer [83543,83549]
trailer [83642,83648]
===
match
---
name: dag [73098,73101]
name: dag [73098,73101]
===
match
---
expr_stmt [3524,3574]
expr_stmt [3524,3574]
===
match
---
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_concurrency_reached` method." [34563,34658]
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_concurrency_reached` method." [34563,34658]
===
match
---
name: DagRun [44485,44491]
name: DagRun [44485,44491]
===
match
---
trailer [94078,94100]
trailer [94177,94199]
===
match
---
suite [59684,61196]
suite [59684,61196]
===
match
---
tfpdef [55756,55768]
tfpdef [55756,55768]
===
match
---
trailer [73373,73395]
trailer [73373,73395]
===
match
---
if_stmt [14339,14440]
if_stmt [14339,14440]
===
match
---
trailer [15688,15704]
trailer [15688,15704]
===
match
---
name: TI [34280,34282]
name: TI [34280,34282]
===
match
---
name: filter [34965,34971]
name: filter [34965,34971]
===
match
---
suite [101362,101918]
suite [101461,102017]
===
match
---
name: bool [45825,45829]
name: bool [45825,45829]
===
match
---
name: session [88756,88763]
name: session [88855,88862]
===
match
---
trailer [11722,11732]
trailer [11722,11732]
===
match
---
name: t [24153,24154]
name: t [24153,24154]
===
match
---
import_as_names [982,1001]
import_as_names [982,1001]
===
match
---
name: max_active_tasks [11483,11499]
name: max_active_tasks [11483,11499]
===
match
---
trailer [39861,39868]
trailer [39861,39868]
===
match
---
tfpdef [45953,45979]
tfpdef [45953,45979]
===
match
---
name: start_date [62133,62143]
name: start_date [62133,62143]
===
match
---
trailer [49315,49322]
trailer [49315,49322]
===
match
---
for_stmt [51665,54632]
for_stmt [51665,54632]
===
match
---
atom [70681,70738]
atom [70681,70738]
===
match
---
string: 'params' [12798,12806]
string: 'params' [12798,12806]
===
match
---
name: include_dependent_dags [54080,54102]
name: include_dependent_dags [54080,54102]
===
match
---
expr_stmt [49746,49891]
expr_stmt [49746,49891]
===
match
---
funcdef [105826,107798]
funcdef [105925,107897]
===
match
---
simple_stmt [91622,91706]
simple_stmt [91721,91805]
===
match
---
argument [65263,65280]
argument [65263,65280]
===
match
---
name: dag_tag [88161,88168]
name: dag_tag [88260,88267]
===
match
---
atom_expr [18791,18832]
atom_expr [18791,18832]
===
match
---
simple_stmt [105966,106000]
simple_stmt [106065,106099]
===
match
---
simple_stmt [15171,15258]
simple_stmt [15171,15258]
===
match
---
atom_expr [86535,86553]
atom_expr [86634,86652]
===
match
---
simple_stmt [58811,59201]
simple_stmt [58811,59201]
===
match
---
decorated [30055,30122]
decorated [30055,30122]
===
match
---
name: str [70521,70524]
name: str [70521,70524]
===
match
---
atom_expr [88127,88139]
atom_expr [88226,88238]
===
match
---
suite [64987,65144]
suite [64987,65144]
===
match
---
trailer [16285,16432]
trailer [16285,16432]
===
match
---
trailer [61478,61483]
trailer [61478,61483]
===
match
---
operator: = [11505,11506]
operator: = [11505,11506]
===
match
---
simple_stmt [24704,24759]
simple_stmt [24704,24759]
===
match
---
trailer [47433,47460]
trailer [47433,47460]
===
match
---
operator: , [43396,43397]
operator: , [43396,43397]
===
match
---
operator: , [93351,93352]
operator: , [93450,93451]
===
match
---
name: past [55904,55908]
name: past [55904,55908]
===
match
---
name: self [14354,14358]
name: self [14354,14358]
===
match
---
tfpdef [45692,45722]
tfpdef [45692,45722]
===
match
---
trailer [99304,99308]
trailer [99403,99407]
===
match
---
trailer [85965,86109]
trailer [86064,86208]
===
match
---
atom_expr [74379,74401]
atom_expr [74379,74401]
===
match
---
name: min_date [44612,44620]
name: min_date [44612,44620]
===
match
---
operator: , [83831,83832]
operator: , [83930,83931]
===
match
---
name: dag [87545,87548]
name: dag [87644,87647]
===
match
---
name: execution_date [53934,53948]
name: execution_date [53934,53948]
===
match
---
atom_expr [76174,76187]
atom_expr [76174,76187]
===
match
---
name: is_active [102932,102941]
name: is_active [103031,103040]
===
match
---
param [11897,11964]
param [11897,11964]
===
match
---
name: end_date [45233,45241]
name: end_date [45233,45241]
===
match
---
name: DagRun [38678,38684]
name: DagRun [38678,38684]
===
match
---
name: self [76902,76906]
name: self [76902,76906]
===
match
---
name: provide_session [99165,99180]
name: provide_session [99264,99279]
===
match
---
name: external_trigger [83279,83295]
name: external_trigger [83378,83394]
===
match
---
simple_stmt [82997,83090]
simple_stmt [83096,83189]
===
match
---
name: dag [70430,70433]
name: dag [70430,70433]
===
match
---
suite [23148,23173]
suite [23148,23173]
===
match
---
string: """:meta private:""" [32799,32819]
string: """:meta private:""" [32799,32819]
===
match
---
string: "The 'DagModel.concurrency' parameter is deprecated. Please use 'max_active_tasks'." [97435,97519]
string: "The 'DagModel.concurrency' parameter is deprecated. Please use 'max_active_tasks'." [97534,97618]
===
match
---
operator: = [61666,61667]
operator: = [61666,61667]
===
match
---
atom_expr [39812,39879]
atom_expr [39812,39879]
===
match
---
name: next_dagrun_data_interval_start [98126,98157]
name: next_dagrun_data_interval_start [98225,98256]
===
match
---
test [57812,57850]
test [57812,57850]
===
match
---
trailer [12512,12532]
trailer [12512,12532]
===
match
---
name: Callable [11723,11731]
name: Callable [11723,11731]
===
match
---
operator: , [68548,68549]
operator: , [68548,68549]
===
match
---
operator: , [47193,47194]
operator: , [47193,47194]
===
match
---
param [108960,108963]
param [109059,109062]
===
match
---
param [66660,66684]
param [66660,66684]
===
match
---
operator: = [35106,35107]
operator: = [35106,35107]
===
match
---
simple_stmt [86643,86657]
simple_stmt [86742,86756]
===
match
---
decorator [89964,89978]
decorator [90063,90077]
===
match
---
trailer [76906,76918]
trailer [76906,76918]
===
match
---
trailer [17662,17668]
trailer [17662,17668]
===
match
---
simple_stmt [16472,16552]
simple_stmt [16472,16552]
===
match
---
trailer [103921,103947]
trailer [104020,104046]
===
match
---
expr_stmt [94913,94971]
expr_stmt [95012,95070]
===
match
---
suite [100397,100714]
suite [100496,100813]
===
match
---
trailer [66718,66725]
trailer [66718,66725]
===
match
---
param [11973,12034]
param [11973,12034]
===
match
---
name: TI [48124,48126]
name: TI [48124,48126]
===
match
---
argument [68094,68107]
argument [68094,68107]
===
match
---
operator: , [13864,13865]
operator: , [13864,13865]
===
match
---
name: dag_bag [47299,47306]
name: dag_bag [47299,47306]
===
match
---
name: dag_id [61775,61781]
name: dag_id [61775,61781]
===
match
---
expr_stmt [96162,96198]
expr_stmt [96261,96297]
===
match
---
comparison [59544,59564]
comparison [59544,59564]
===
match
---
name: env [43284,43287]
name: env [43284,43287]
===
match
---
operator: @ [31854,31855]
operator: @ [31854,31855]
===
match
---
trailer [88445,88460]
trailer [88544,88559]
===
match
---
operator: = [49938,49939]
operator: = [49938,49939]
===
match
---
name: dag [88177,88180]
name: dag [88276,88279]
===
match
---
name: Set [47508,47511]
name: Set [47508,47511]
===
match
---
funcdef [108709,108910]
funcdef [108808,109009]
===
match
---
name: count [67308,67313]
name: count [67308,67313]
===
match
---
trailer [12644,12653]
trailer [12644,12653]
===
match
---
name: RePatternType [69343,69356]
name: RePatternType [69343,69356]
===
match
---
name: len [65719,65722]
name: len [65719,65722]
===
match
---
name: only_failed [66545,66556]
name: only_failed [66545,66556]
===
match
---
operator: , [20861,20862]
operator: , [20861,20862]
===
match
---
name: template_undefined [15483,15501]
name: template_undefined [15483,15501]
===
match
---
expr_stmt [95959,95988]
expr_stmt [96058,96087]
===
match
---
operator: = [87375,87376]
operator: = [87474,87475]
===
match
---
name: end_date [49075,49083]
name: end_date [49075,49083]
===
match
---
string: 'task_dict' [92838,92849]
string: 'task_dict' [92937,92948]
===
match
---
atom [19472,19653]
atom [19472,19653]
===
match
---
name: query [89801,89806]
name: query [89900,89905]
===
match
---
name: Iterable [25519,25527]
name: Iterable [25519,25527]
===
match
---
atom_expr [53448,53458]
atom_expr [53448,53458]
===
match
---
name: category [28713,28721]
name: category [28713,28721]
===
match
---
name: dag [86991,86994]
name: dag [87090,87093]
===
match
---
expr_stmt [74024,74048]
expr_stmt [74024,74048]
===
match
---
tfpdef [12237,12276]
tfpdef [12237,12276]
===
match
---
comparison [12798,12827]
comparison [12798,12827]
===
match
---
trailer [83047,83089]
trailer [83146,83188]
===
match
---
name: tasks [41592,41597]
name: tasks [41592,41597]
===
match
---
name: lower [100706,100711]
name: lower [100805,100810]
===
match
---
name: airflow [3262,3269]
name: airflow [3262,3269]
===
match
---
name: query [74652,74657]
name: query [74652,74657]
===
match
---
atom_expr [106973,106982]
atom_expr [107072,107081]
===
match
---
name: self [44330,44334]
name: self [44330,44334]
===
match
---
suite [24242,24291]
suite [24242,24291]
===
match
---
trailer [72878,72880]
trailer [72878,72880]
===
match
---
trailer [24468,24474]
trailer [24468,24474]
===
match
---
simple_stmt [48740,48800]
simple_stmt [48740,48800]
===
match
---
operator: , [66473,66474]
operator: , [66473,66474]
===
match
---
name: task [76396,76400]
name: task [76396,76400]
===
match
---
name: count [86359,86364]
name: count [86458,86463]
===
match
---
suite [75833,75880]
suite [75833,75880]
===
match
---
suite [55215,55242]
suite [55215,55242]
===
match
---
argument [83357,83374]
argument [83456,83473]
===
match
---
simple_stmt [68224,68237]
simple_stmt [68224,68237]
===
match
---
argument [80061,80098]
argument [80061,80098]
===
match
---
trailer [25424,25433]
trailer [25424,25433]
===
match
---
atom_expr [19785,19817]
atom_expr [19785,19817]
===
match
---
operator: , [20764,20765]
operator: , [20764,20765]
===
match
---
trailer [22056,22065]
trailer [22056,22065]
===
match
---
atom_expr [99026,99060]
atom_expr [99125,99159]
===
match
---
atom_expr [54943,54952]
atom_expr [54943,54952]
===
match
---
simple_stmt [82399,82453]
simple_stmt [82456,82498]
===
match
---
name: access_control [17369,17383]
name: access_control [17369,17383]
===
match
---
name: Optional [80717,80725]
name: Optional [80717,80725]
===
match
---
name: len [76979,76982]
name: len [76979,76982]
===
match
---
name: rerun_failed_tasks [77630,77648]
name: rerun_failed_tasks [77630,77648]
===
match
---
operator: , [38196,38197]
operator: , [38196,38197]
===
match
---
name: session [61739,61746]
name: session [61739,61746]
===
match
---
atom_expr [99123,99140]
atom_expr [99222,99239]
===
match
---
name: get [11774,11777]
name: get [11774,11777]
===
match
---
name: orm_dag [87133,87140]
name: orm_dag [87232,87239]
===
match
---
operator: == [67367,67369]
operator: == [67367,67369]
===
match
---
return_stmt [107759,107773]
return_stmt [107858,107872]
===
match
---
name: str [65852,65855]
name: str [65852,65855]
===
match
---
dotted_name [1715,1736]
dotted_name [1715,1736]
===
match
---
simple_stmt [87984,88008]
simple_stmt [88083,88107]
===
match
---
trailer [70866,70885]
trailer [70866,70885]
===
match
---
simple_stmt [71244,71396]
simple_stmt [71244,71396]
===
match
---
trailer [22065,22090]
trailer [22065,22090]
===
match
---
trailer [16912,16922]
trailer [16912,16922]
===
match
---
name: args [106458,106462]
name: args [106557,106561]
===
match
---
funcdef [30069,30122]
funcdef [30069,30122]
===
match
---
argument [44724,44739]
argument [44724,44739]
===
match
---
string: "\n" [67482,67486]
string: "\n" [67482,67486]
===
match
---
operator: , [43378,43379]
operator: , [43378,43379]
===
match
---
atom_expr [76033,76048]
atom_expr [76033,76048]
===
match
---
trailer [106448,106451]
trailer [106547,106550]
===
match
---
param [11749,11819]
param [11749,11819]
===
match
---
name: dag_id [94306,94312]
name: dag_id [94405,94411]
===
match
---
name: session [46643,46650]
name: session [46643,46650]
===
match
---
param [99787,99806]
param [99886,99905]
===
match
---
name: functools [4104,4113]
name: functools [4104,4113]
===
match
---
expr_stmt [34935,35003]
expr_stmt [34935,35003]
===
match
---
simple_stmt [87684,87863]
simple_stmt [87783,87962]
===
match
---
name: first [39901,39906]
name: first [39901,39906]
===
match
---
argument [28754,28766]
argument [28754,28766]
===
match
---
trailer [3881,3888]
trailer [3881,3888]
===
match
---
name: self [34818,34822]
name: self [34818,34822]
===
match
---
operator: , [93751,93752]
operator: , [93850,93851]
===
match
---
trailer [51532,51538]
trailer [51532,51538]
===
match
---
operator: == [34289,34291]
operator: == [34289,34291]
===
match
---
atom_expr [70583,70593]
atom_expr [70583,70593]
===
match
---
trailer [95649,95658]
trailer [95748,95757]
===
match
---
param [21744,21748]
param [21744,21748]
===
match
---
trailer [44663,44682]
trailer [44663,44682]
===
match
---
simple_stmt [47539,47557]
simple_stmt [47539,47557]
===
match
---
name: c [18467,18468]
name: c [18467,18468]
===
match
---
string: 'user_defined_filters' [68550,68572]
string: 'user_defined_filters' [68550,68572]
===
match
---
atom_expr [97782,97814]
atom_expr [97881,97913]
===
match
---
operator: , [68107,68108]
operator: , [68107,68108]
===
match
---
name: airflow [2613,2620]
name: airflow [2613,2620]
===
match
---
name: DagParam [32268,32276]
name: DagParam [32268,32276]
===
match
---
suite [18492,18563]
suite [18492,18563]
===
match
---
return_stmt [89246,89302]
return_stmt [89345,89401]
===
match
---
name: exclude_task_ids [55513,55529]
name: exclude_task_ids [55513,55529]
===
match
---
operator: @ [90875,90876]
operator: @ [90974,90975]
===
match
---
trailer [61991,61998]
trailer [61991,61998]
===
match
---
suite [60755,61073]
suite [60755,61073]
===
match
---
atom_expr [75846,75861]
atom_expr [75846,75861]
===
match
---
expr_stmt [84765,84811]
expr_stmt [84864,84910]
===
match
---
name: in_ [49815,49818]
name: in_ [49815,49818]
===
match
---
name: access_control [19078,19092]
name: access_control [19078,19092]
===
match
---
atom_expr [44330,44341]
atom_expr [44330,44341]
===
match
---
expr_stmt [107840,107887]
expr_stmt [107939,107986]
===
match
---
name: func [85838,85842]
name: func [85937,85941]
===
match
---
simple_stmt [1710,1749]
simple_stmt [1710,1749]
===
match
---
operator: @ [100719,100720]
operator: @ [100818,100819]
===
match
---
name: task_ids [65206,65214]
name: task_ids [65206,65214]
===
match
---
decorator [101923,101936]
decorator [102022,102035]
===
match
---
name: self [61181,61185]
name: self [61181,61185]
===
match
---
operator: , [21263,21264]
operator: , [21263,21264]
===
match
---
comp_op [38748,38754]
comp_op [38748,38754]
===
match
---
name: Context [3559,3566]
name: Context [3559,3566]
===
match
---
operator: , [39128,39129]
operator: , [39128,39129]
===
match
---
name: get_task [51987,51995]
name: get_task [51987,51995]
===
match
---
import_as_names [2188,2248]
import_as_names [2188,2248]
===
match
---
name: self [33552,33556]
name: self [33552,33556]
===
match
---
trailer [89261,89294]
trailer [89360,89393]
===
match
---
name: cli_parser [80297,80307]
name: cli_parser [80297,80307]
===
match
---
name: t [70707,70708]
name: t [70707,70708]
===
match
---
param [97268,97276]
param [97367,97375]
===
match
---
decorated [32750,32996]
decorated [32750,32996]
===
match
---
atom_expr [29914,29925]
atom_expr [29914,29925]
===
match
---
name: str [62564,62567]
name: str [62564,62567]
===
match
---
argument [104022,104052]
argument [104121,104151]
===
match
---
operator: , [106055,106056]
operator: , [106154,106155]
===
match
---
param [80795,80808]
param [80795,80808]
===
match
---
name: task [52996,53000]
name: task [52996,53000]
===
match
---
name: t [70682,70683]
name: t [70682,70683]
===
match
---
operator: = [29705,29706]
operator: = [29705,29706]
===
match
---
name: end_dates [24540,24549]
name: end_dates [24540,24549]
===
match
---
expr_stmt [21932,21977]
expr_stmt [21932,21977]
===
match
---
name: self [17457,17461]
name: self [17457,17461]
===
match
---
atom_expr [14115,14163]
atom_expr [14115,14163]
===
match
---
name: description [87432,87443]
name: description [87531,87542]
===
match
---
atom_expr [85809,86180]
atom_expr [85908,86279]
===
match
---
name: DAG [17328,17331]
name: DAG [17328,17331]
===
match
---
operator: = [3358,3359]
operator: = [3358,3359]
===
match
---
name: task_dict [18395,18404]
name: task_dict [18395,18404]
===
match
---
trailer [76511,76521]
trailer [76511,76521]
===
match
---
trailer [53000,53017]
trailer [53000,53017]
===
match
---
operator: , [46515,46516]
operator: , [46515,46516]
===
match
---
trailer [89340,89353]
trailer [89439,89452]
===
match
---
param [24799,24803]
param [24799,24803]
===
match
---
atom_expr [48664,48703]
atom_expr [48664,48703]
===
match
---
operator: -> [43825,43827]
operator: -> [43825,43827]
===
match
---
parameters [62086,62591]
parameters [62086,62591]
===
match
---
name: description [96022,96033]
name: description [96121,96132]
===
match
---
name: session [74644,74651]
name: session [74644,74651]
===
match
---
simple_stmt [93899,94045]
simple_stmt [93998,94144]
===
match
---
name: DateTime [25461,25469]
name: DateTime [25461,25469]
===
match
---
string: 'last_loaded' [10502,10515]
string: 'last_loaded' [10502,10515]
===
match
---
atom_expr [100988,101000]
atom_expr [101087,101099]
===
match
---
operator: , [98096,98097]
operator: , [98195,98196]
===
match
---
param [73628,73657]
param [73628,73657]
===
match
---
operator: = [36404,36405]
operator: = [36404,36405]
===
match
---
trailer [14787,14796]
trailer [14787,14796]
===
match
---
tfpdef [55820,55846]
tfpdef [55820,55846]
===
match
---
name: count [68231,68236]
name: count [68231,68236]
===
match
---
string: 'TB' [3505,3509]
string: 'TB' [3505,3509]
===
match
---
operator: , [47289,47290]
operator: , [47289,47290]
===
match
---
atom [3420,3475]
atom [3420,3475]
===
match
---
trailer [73855,73865]
trailer [73855,73865]
===
match
---
name: default_args [14748,14760]
name: default_args [14748,14760]
===
match
---
name: _access_control [17310,17325]
name: _access_control [17310,17325]
===
match
---
if_stmt [44899,45082]
if_stmt [44899,45082]
===
match
---
name: id [71303,71305]
name: id [71303,71305]
===
match
---
operator: , [55768,55769]
operator: , [55768,55769]
===
match
---
name: property [33002,33010]
name: property [33002,33010]
===
match
---
decorated [61237,62051]
decorated [61237,62051]
===
match
---
operator: = [55887,55888]
operator: = [55887,55888]
===
match
---
comparison [73408,73440]
comparison [73408,73440]
===
match
---
name: level [75241,75246]
name: level [75241,75246]
===
match
---
name: functools [106081,106090]
name: functools [106180,106189]
===
match
---
operator: = [96821,96822]
operator: = [96920,96921]
===
match
---
trailer [106569,106571]
trailer [106668,106670]
===
match
---
name: task_id [73841,73848]
name: task_id [73841,73848]
===
match
---
trailer [90457,90522]
trailer [90556,90621]
===
match
---
name: filtered_child [72098,72112]
name: filtered_child [72098,72112]
===
match
---
name: provide_session [29751,29766]
name: provide_session [29751,29766]
===
match
---
name: str [31638,31641]
name: str [31638,31641]
===
match
---
comparison [98854,98867]
comparison [98953,98966]
===
match
---
atom_expr [84244,84261]
atom_expr [84343,84360]
===
match
---
atom_expr [31833,31848]
atom_expr [31833,31848]
===
match
---
parameters [93815,93889]
parameters [93914,93988]
===
match
---
trailer [89928,89933]
trailer [90027,90032]
===
match
---
operator: , [1172,1173]
operator: , [1172,1173]
===
match
---
name: __serialized_fields [93304,93323]
name: __serialized_fields [93403,93422]
===
match
---
operator: = [72581,72582]
operator: = [72581,72582]
===
match
---
name: back [13739,13743]
name: back [13739,13743]
===
match
---
atom_expr [34972,34987]
atom_expr [34972,34987]
===
match
---
name: DeprecationWarning [61624,61642]
name: DeprecationWarning [61624,61642]
===
match
---
name: pendulum [28884,28892]
name: pendulum [28884,28892]
===
match
---
simple_stmt [37413,37449]
simple_stmt [37413,37449]
===
match
---
if_stmt [91738,92214]
if_stmt [91837,92313]
===
match
---
trailer [101625,101632]
trailer [101724,101731]
===
match
---
name: copied [71546,71552]
name: copied [71546,71552]
===
match
---
and_test [74604,74625]
and_test [74604,74625]
===
match
---
name: self [98637,98641]
name: self [98736,98740]
===
match
---
atom_expr [96237,96312]
atom_expr [96336,96411]
===
match
---
trailer [98992,99024]
trailer [99091,99123]
===
match
---
name: dag_id [10858,10864]
name: dag_id [10858,10864]
===
match
---
trailer [83549,83551]
trailer [83648,83650]
===
match
---
trailer [43212,43232]
trailer [43212,43232]
===
match
---
fstring_expr [67572,67579]
fstring_expr [67572,67579]
===
match
---
param [77630,77655]
param [77630,77655]
===
match
---
param [37800,37804]
param [37800,37804]
===
match
---
atom_expr [35785,35941]
atom_expr [35785,35941]
===
match
---
atom_expr [99272,99303]
atom_expr [99371,99402]
===
match
---
argument [50569,50580]
argument [50569,50580]
===
match
---
name: List [44871,44875]
name: List [44871,44875]
===
match
---
name: TI [34152,34154]
name: TI [34152,34154]
===
match
---
operator: @ [98716,98717]
operator: @ [98815,98816]
===
match
---
name: count [38599,38604]
name: count [38599,38604]
===
match
---
operator: = [44941,44942]
operator: = [44941,44942]
===
match
---
trailer [14890,14899]
trailer [14890,14899]
===
match
---
name: task_id [91669,91676]
name: task_id [91768,91775]
===
match
---
operator: = [12135,12136]
operator: = [12135,12136]
===
match
---
string: "\n" [65842,65846]
string: "\n" [65842,65846]
===
match
---
suite [88240,88425]
suite [88339,88524]
===
match
---
operator: , [31894,31895]
operator: , [31894,31895]
===
match
---
name: Optional [11054,11062]
name: Optional [11054,11062]
===
match
---
param [18116,18121]
param [18116,18121]
===
match
---
name: self [57067,57071]
name: self [57067,57071]
===
match
---
operator: -> [24110,24112]
operator: -> [24110,24112]
===
match
---
name: f [107662,107663]
name: f [107761,107762]
===
match
---
trailer [38793,38915]
trailer [38793,38915]
===
match
---
name: Column [94686,94692]
name: Column [94785,94791]
===
match
---
trailer [60551,60553]
trailer [60551,60553]
===
match
---
simple_stmt [69222,69266]
simple_stmt [69222,69266]
===
match
---
name: str [14159,14162]
name: str [14159,14162]
===
match
---
if_stmt [48224,48705]
if_stmt [48224,48705]
===
match
---
expr_stmt [95198,95236]
expr_stmt [95297,95335]
===
match
---
decorators [89359,89394]
decorators [89458,89493]
===
match
---
import_from [80273,80307]
import_from [80273,80307]
===
match
---
atom_expr [86969,86988]
atom_expr [87068,87087]
===
match
---
simple_stmt [31217,31247]
simple_stmt [31217,31247]
===
match
---
name: graph_sorted [61218,61230]
name: graph_sorted [61218,61230]
===
match
---
name: self [30718,30722]
name: self [30718,30722]
===
match
---
operator: = [74341,74342]
operator: = [74341,74342]
===
match
---
name: self [98988,98992]
name: self [99087,99091]
===
match
---
name: task [75817,75821]
name: task [75817,75821]
===
match
---
name: stacklevel [61656,61666]
name: stacklevel [61656,61666]
===
match
---
operator: = [97591,97592]
operator: = [97690,97691]
===
match
---
operator: = [15780,15781]
operator: = [15780,15781]
===
match
---
decorator [99743,99760]
decorator [99842,99859]
===
match
---
trailer [107864,107870]
trailer [107963,107969]
===
match
---
atom_expr [76938,76950]
atom_expr [76938,76950]
===
match
---
name: is_ [92098,92101]
name: is_ [92197,92200]
===
match
---
trailer [17722,17729]
trailer [17722,17729]
===
match
---
param [20301,20350]
param [20301,20350]
===
match
---
trailer [61760,61767]
trailer [61760,61767]
===
match
---
name: self [24745,24749]
name: self [24745,24749]
===
match
---
operator: = [107265,107266]
operator: = [107364,107365]
===
match
---
param [105511,105523]
param [105610,105622]
===
match
---
not_test [44902,44916]
not_test [44902,44916]
===
match
---
name: filter_query [101573,101585]
name: filter_query [101672,101684]
===
match
---
trailer [86425,86443]
trailer [86524,86542]
===
match
---
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_is_paused` method." [35497,35582]
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_is_paused` method." [35497,35582]
===
match
---
name: provide_session [99744,99759]
name: provide_session [99843,99858]
===
match
---
dotted_name [79327,79359]
dotted_name [79327,79359]
===
match
---
parameters [30156,30174]
parameters [30156,30174]
===
match
---
operator: == [74551,74553]
operator: == [74551,74553]
===
match
---
simple_stmt [108991,109026]
simple_stmt [109090,109125]
===
match
---
name: is_active [103741,103750]
name: is_active [103840,103849]
===
match
---
name: property [32663,32671]
name: property [32663,32671]
===
match
---
operator: , [32909,32910]
operator: , [32909,32910]
===
match
---
operator: = [57645,57646]
operator: = [57645,57646]
===
match
---
trailer [11264,11280]
trailer [11264,11280]
===
match
---
trailer [101831,101841]
trailer [101930,101940]
===
match
---
name: Optional [61430,61438]
name: Optional [61430,61438]
===
match
---
import_from [1710,1748]
import_from [1710,1748]
===
match
---
comparison [51792,51822]
comparison [51792,51822]
===
match
---
operator: = [76215,76216]
operator: = [76215,76216]
===
match
---
number: 0 [65769,65770]
number: 0 [65769,65770]
===
match
---
parameters [33980,34000]
parameters [33980,34000]
===
match
---
operator: @ [31252,31253]
operator: @ [31252,31253]
===
match
---
name: self [14291,14295]
name: self [14291,14295]
===
match
---
name: TaskInstance [56009,56021]
name: TaskInstance [56009,56021]
===
match
---
operator: , [10515,10516]
operator: , [10515,10516]
===
match
---
name: self [34348,34352]
name: self [34348,34352]
===
match
---
atom_expr [86006,86029]
atom_expr [86105,86128]
===
match
---
operator: = [15290,15291]
operator: = [15290,15291]
===
match
---
operator: , [83248,83249]
operator: , [83347,83348]
===
match
---
simple_stmt [25549,26427]
simple_stmt [25549,26427]
===
match
---
name: template_searchpath [11134,11153]
name: template_searchpath [11134,11153]
===
match
---
name: orm_dag [88127,88134]
name: orm_dag [88226,88233]
===
match
---
name: UtcDateTime [96506,96517]
name: UtcDateTime [96605,96616]
===
match
---
name: f_back [13762,13768]
name: f_back [13762,13768]
===
match
---
decorated [31057,31155]
decorated [31057,31155]
===
match
---
name: coerce_datetime [26539,26554]
name: coerce_datetime [26539,26554]
===
match
---
funcdef [75442,76999]
funcdef [75442,76999]
===
match
---
name: query [39612,39617]
name: query [39612,39617]
===
match
---
name: getint [11592,11598]
name: getint [11592,11598]
===
match
---
operator: = [46687,46688]
operator: = [46687,46688]
===
match
---
name: not_none_states [91917,91932]
name: not_none_states [92016,92031]
===
match
---
operator: , [30533,30534]
operator: , [30533,30534]
===
match
---
operator: , [31002,31003]
operator: , [31002,31003]
===
match
---
operator: , [30440,30441]
operator: , [30440,30441]
===
match
---
trailer [49969,49973]
trailer [49969,49973]
===
match
---
name: ExternalTaskMarker [52724,52742]
name: ExternalTaskMarker [52724,52742]
===
match
---
trailer [87957,87962]
trailer [88056,88061]
===
match
---
string: "Cancelled, nothing was cleared." [68181,68214]
string: "Cancelled, nothing was cleared." [68181,68214]
===
match
---
name: Optional [55832,55840]
name: Optional [55832,55840]
===
match
---
name: self [12810,12814]
name: self [12810,12814]
===
match
---
name: STATICA_HACK [107820,107832]
name: STATICA_HACK [107919,107931]
===
match
---
param [3614,3648]
param [3614,3648]
===
match
---
name: tasks [73583,73588]
name: tasks [73583,73588]
===
match
---
argument [79675,79692]
argument [79675,79692]
===
match
---
name: from_run_id [82433,82444]
name: from_run_id [82478,82489]
===
match
---
name: dp [74639,74641]
name: dp [74639,74641]
===
match
---
name: Optional [47035,47043]
name: Optional [47035,47043]
===
match
---
operator: { [93790,93791]
operator: { [93889,93890]
===
match
---
name: include_subdags [46461,46476]
name: include_subdags [46461,46476]
===
match
---
name: set [55013,55016]
name: set [55013,55016]
===
match
---
name: value [30207,30212]
name: value [30207,30212]
===
match
---
expr_stmt [64838,64848]
expr_stmt [64838,64848]
===
match
---
simple_stmt [77040,77184]
simple_stmt [77040,77184]
===
match
---
param [77265,77270]
param [77265,77270]
===
match
---
name: DAG [104112,104115]
name: DAG [104211,104214]
===
match
---
comparison [52927,52960]
comparison [52927,52960]
===
match
---
simple_stmt [60485,60501]
simple_stmt [60485,60501]
===
match
---
operator: , [62443,62444]
operator: , [62443,62444]
===
match
---
atom_expr [86752,86766]
atom_expr [86851,86865]
===
match
---
trailer [92174,92181]
trailer [92273,92280]
===
match
---
name: orm_tag [87930,87937]
name: orm_tag [88029,88036]
===
match
---
if_stmt [71840,72056]
if_stmt [71840,72056]
===
match
---
param [46015,46040]
param [46015,46040]
===
match
---
expr_stmt [14275,14329]
expr_stmt [14275,14329]
===
match
---
suite [49559,49631]
suite [49559,49631]
===
match
---
name: Column [95968,95974]
name: Column [96067,96073]
===
match
---
operator: , [55746,55747]
operator: , [55746,55747]
===
match
---
atom [12706,12708]
atom [12706,12708]
===
match
---
name: Optional [12206,12214]
name: Optional [12206,12214]
===
match
---
suite [94406,94432]
suite [94505,94531]
===
match
---
operator: = [102942,102943]
operator: = [103041,103042]
===
match
---
name: state [80497,80502]
name: state [80497,80502]
===
match
---
atom_expr [37437,37447]
atom_expr [37437,37447]
===
match
---
trailer [14223,14229]
trailer [14223,14229]
===
match
---
simple_stmt [85186,85241]
simple_stmt [85285,85340]
===
match
---
name: jobs [79237,79241]
name: jobs [79237,79241]
===
match
---
simple_stmt [102922,102949]
simple_stmt [103021,103048]
===
match
---
name: state [37988,37993]
name: state [37988,37993]
===
match
---
name: execution_date [57155,57169]
name: execution_date [57155,57169]
===
match
---
atom_expr [11155,11190]
atom_expr [11155,11190]
===
match
---
simple_stmt [101686,101743]
simple_stmt [101785,101842]
===
match
---
trailer [89840,89844]
trailer [89939,89943]
===
match
---
name: default_args [14998,15010]
name: default_args [14998,15010]
===
match
---
operator: , [16932,16933]
operator: , [16932,16933]
===
match
---
suite [101673,101743]
suite [101772,101842]
===
match
---
trailer [48640,48647]
trailer [48640,48647]
===
match
---
simple_stmt [66315,66325]
simple_stmt [66315,66325]
===
match
---
name: timezone [44944,44952]
name: timezone [44944,44952]
===
match
---
trailer [83136,83143]
trailer [83235,83242]
===
match
---
comp_op [68519,68525]
comp_op [68519,68525]
===
match
---
name: utcnow [44953,44959]
name: utcnow [44953,44959]
===
match
---
simple_stmt [79224,79274]
simple_stmt [79224,79274]
===
match
---
operator: = [67538,67539]
operator: = [67538,67539]
===
match
---
param [29794,29807]
param [29794,29807]
===
match
---
atom_expr [19903,20153]
atom_expr [19903,20153]
===
match
---
param [39965,39976]
param [39965,39976]
===
match
---
return_stmt [41266,41305]
return_stmt [41266,41305]
===
match
---
string: """         Runs the DAG.          :param start_date: the start date of the range to run         :type start_date: datetime.datetime         :param end_date: the end date of the range to run         :type end_date: datetime.datetime         :param mark_success: True to mark jobs as succeeded without running them         :type mark_success: bool         :param local: True to run the tasks using the LocalExecutor         :type local: bool         :param executor: The executor instance to run the tasks         :type executor: airflow.executor.base_executor.BaseExecutor         :param donot_pickle: True to avoid pickling DAG object and send to workers         :type donot_pickle: bool         :param ignore_task_deps: True to skip upstream tasks         :type ignore_task_deps: bool         :param ignore_first_depends_on_past: True to ignore depends_on_past             dependencies for the first set of tasks only         :type ignore_first_depends_on_past: bool         :param pool: Resource pool to use         :type pool: str         :param delay_on_limit_secs: Time in seconds to wait before next attempt to run             dag run when max_active_runs limit has been reached         :type delay_on_limit_secs: float         :param verbose: Make logging output more verbose         :type verbose: bool         :param conf: user defined dictionary passed from CLI         :type conf: dict         :param rerun_failed_tasks:         :type: bool         :param run_backwards:         :type: bool          """ [77700,79215]
string: """         Runs the DAG.          :param start_date: the start date of the range to run         :type start_date: datetime.datetime         :param end_date: the end date of the range to run         :type end_date: datetime.datetime         :param mark_success: True to mark jobs as succeeded without running them         :type mark_success: bool         :param local: True to run the tasks using the LocalExecutor         :type local: bool         :param executor: The executor instance to run the tasks         :type executor: airflow.executor.base_executor.BaseExecutor         :param donot_pickle: True to avoid pickling DAG object and send to workers         :type donot_pickle: bool         :param ignore_task_deps: True to skip upstream tasks         :type ignore_task_deps: bool         :param ignore_first_depends_on_past: True to ignore depends_on_past             dependencies for the first set of tasks only         :type ignore_first_depends_on_past: bool         :param pool: Resource pool to use         :type pool: str         :param delay_on_limit_secs: Time in seconds to wait before next attempt to run             dag run when max_active_runs limit has been reached         :type delay_on_limit_secs: float         :param verbose: Make logging output more verbose         :type verbose: bool         :param conf: user defined dictionary passed from CLI         :type conf: dict         :param rerun_failed_tasks:         :type: bool         :param run_backwards:         :type: bool          """ [77700,79215]
===
match
---
string: 'start_date' [14085,14097]
string: 'start_date' [14085,14097]
===
match
---
trailer [105418,105423]
trailer [105517,105522]
===
match
---
funcdef [69271,73493]
funcdef [69271,73493]
===
match
---
trailer [52755,52763]
trailer [52755,52763]
===
match
---
atom_expr [73412,73421]
atom_expr [73412,73421]
===
match
---
argument [26672,26684]
argument [26672,26684]
===
match
---
operator: = [67020,67021]
operator: = [67020,67021]
===
match
---
name: dag_id [38650,38656]
name: dag_id [38650,38656]
===
match
---
expr_stmt [15760,15796]
expr_stmt [15760,15796]
===
match
---
param [86709,86710]
param [86808,86809]
===
match
---
simple_stmt [28067,28572]
simple_stmt [28067,28572]
===
match
---
decorated [31446,31585]
decorated [31446,31585]
===
match
---
operator: = [96267,96268]
operator: = [96366,96367]
===
match
---
name: timezone [26530,26538]
name: timezone [26530,26538]
===
match
---
arglist [89072,89087]
arglist [89171,89186]
===
match
---
operator: , [10869,10870]
operator: , [10869,10870]
===
match
---
name: hasattr [14346,14353]
name: hasattr [14346,14353]
===
match
---
name: task [41579,41583]
name: task [41579,41583]
===
match
---
name: set_dag_runs_state [61262,61280]
name: set_dag_runs_state [61262,61280]
===
match
---
name: DagRun [40387,40393]
name: DagRun [40387,40393]
===
match
---
return_stmt [61205,61231]
return_stmt [61205,61231]
===
match
---
name: dag [76791,76794]
name: dag [76791,76794]
===
match
---
simple_stmt [83511,83528]
simple_stmt [83610,83627]
===
match
---
atom_expr [3864,3909]
atom_expr [3864,3909]
===
match
---
name: staticmethod [99726,99738]
name: staticmethod [99825,99837]
===
match
---
trailer [99626,99633]
trailer [99725,99732]
===
match
---
decorated [33368,33523]
decorated [33368,33523]
===
match
---
suite [91896,92131]
suite [91995,92230]
===
match
---
trailer [48559,48566]
trailer [48559,48566]
===
match
---
atom_expr [74152,74167]
atom_expr [74152,74167]
===
match
---
operator: , [3515,3516]
operator: , [3515,3516]
===
match
---
atom_expr [76396,76409]
atom_expr [76396,76409]
===
match
---
simple_stmt [74111,74140]
simple_stmt [74111,74140]
===
match
---
name: tis [65692,65695]
name: tis [65692,65695]
===
match
---
argument [94650,94666]
argument [94749,94765]
===
match
---
name: self [72418,72422]
name: self [72418,72422]
===
match
---
name: pickle [74449,74455]
name: pickle [74449,74455]
===
match
---
operator: = [68101,68102]
operator: = [68101,68102]
===
match
---
if_stmt [48065,48215]
if_stmt [48065,48215]
===
match
---
argument [51048,51089]
argument [51048,51089]
===
match
---
atom_expr [71612,71633]
atom_expr [71612,71633]
===
match
---
name: discard [72033,72040]
name: discard [72033,72040]
===
match
---
name: dag_id [99202,99208]
name: dag_id [99301,99307]
===
match
---
simple_stmt [87133,87159]
simple_stmt [87232,87258]
===
match
---
operator: = [96235,96236]
operator: = [96334,96335]
===
match
---
name: Optional [46997,47005]
name: Optional [46997,47005]
===
match
---
comparison [49134,49173]
comparison [49134,49173]
===
match
---
atom_expr [80584,80597]
atom_expr [80584,80597]
===
match
---
trailer [101774,101781]
trailer [101873,101880]
===
match
---
name: self [42338,42342]
name: self [42338,42342]
===
match
---
param [46461,46483]
param [46461,46483]
===
match
---
trailer [45030,45081]
trailer [45030,45081]
===
match
---
param [18892,18895]
param [18892,18895]
===
match
---
suite [71986,72056]
suite [71986,72056]
===
match
---
name: cls [108845,108848]
name: cls [108944,108947]
===
match
---
name: read_dags_from_db [53234,53251]
name: read_dags_from_db [53234,53251]
===
match
---
atom_expr [51996,52006]
atom_expr [51996,52006]
===
match
---
trailer [93657,93667]
trailer [93756,93766]
===
match
---
trailer [66156,66288]
trailer [66156,66288]
===
match
---
name: DagRunType [44430,44440]
name: DagRunType [44430,44440]
===
match
---
name: task_id [76566,76573]
name: task_id [76566,76573]
===
match
---
atom_expr [80679,80693]
atom_expr [80679,80693]
===
match
---
atom_expr [100664,100713]
atom_expr [100763,100812]
===
match
---
trailer [71289,71298]
trailer [71289,71298]
===
match
---
param [47230,47264]
param [47230,47264]
===
match
---
simple_stmt [31735,31761]
simple_stmt [31735,31761]
===
match
---
name: dag_ids [85012,85019]
name: dag_ids [85111,85118]
===
match
---
arglist [20973,21088]
arglist [20973,21088]
===
match
---
atom_expr [24464,24474]
atom_expr [24464,24474]
===
match
---
atom_expr [32485,32561]
atom_expr [32485,32561]
===
match
---
trailer [97703,97720]
trailer [97802,97819]
===
match
---
operator: , [36395,36396]
operator: , [36395,36396]
===
match
---
atom_expr [89207,89224]
atom_expr [89306,89323]
===
match
---
name: next_dagrun_info [27953,27969]
name: next_dagrun_info [27953,27969]
===
match
---
trailer [109040,109071]
trailer [109139,109170]
===
match
---
param [90923,90930]
param [91022,91029]
===
match
---
parameters [20212,20356]
parameters [20212,20356]
===
match
---
simple_stmt [2148,2249]
simple_stmt [2148,2249]
===
match
---
name: len [73408,73411]
name: len [73408,73411]
===
match
---
trailer [105989,105998]
trailer [106088,106097]
===
match
---
name: dag_bound_args [106008,106022]
name: dag_bound_args [106107,106121]
===
match
---
expr_stmt [70665,70738]
expr_stmt [70665,70738]
===
match
---
import_name [909,924]
import_name [909,924]
===
match
---
comparison [103737,103771]
comparison [103836,103870]
===
match
---
operator: = [20506,20507]
operator: = [20506,20507]
===
match
---
expr_stmt [72786,72881]
expr_stmt [72786,72881]
===
match
---
trailer [74362,74376]
trailer [74362,74376]
===
match
---
name: end_date [66896,66904]
name: end_date [66896,66904]
===
match
---
name: scalar [38938,38944]
name: scalar [38938,38944]
===
match
---
name: cls [99445,99448]
name: cls [99544,99547]
===
match
---
return_stmt [18024,18036]
return_stmt [18024,18036]
===
match
---
atom_expr [102588,102627]
atom_expr [102687,102726]
===
match
---
name: str [47445,47448]
name: str [47445,47448]
===
match
---
atom_expr [50105,50120]
atom_expr [50105,50120]
===
match
---
simple_stmt [55612,55623]
simple_stmt [55612,55623]
===
match
---
operator: = [29559,29560]
operator: = [29559,29560]
===
match
---
operator: , [89078,89079]
operator: , [89177,89178]
===
match
---
trailer [98641,98673]
trailer [98740,98772]
===
match
---
atom_expr [19530,19557]
atom_expr [19530,19557]
===
match
---
name: permissions [19530,19541]
name: permissions [19530,19541]
===
match
---
trailer [85102,85106]
trailer [85201,85205]
===
match
---
param [62266,62287]
param [62266,62287]
===
match
---
decorated [98020,98711]
decorated [98119,98810]
===
match
---
trailer [85829,85836]
trailer [85928,85935]
===
match
---
operator: , [45943,45944]
operator: , [45943,45944]
===
match
---
name: end_date [20301,20309]
name: end_date [20301,20309]
===
match
---
name: Optional [109284,109292]
name: Optional [109383,109391]
===
match
---
param [46124,46184]
param [46124,46184]
===
match
---
subscriptlist [47484,47528]
subscriptlist [47484,47528]
===
match
---
argument [21883,21895]
argument [21883,21895]
===
match
---
string: """         Add a list of tasks to the DAG          :param tasks: a lit of tasks you want to add         :type tasks: list of tasks         """ [77040,77183]
string: """         Add a list of tasks to the DAG          :param tasks: a lit of tasks you want to add         :type tasks: list of tasks         """ [77040,77183]
===
match
---
simple_stmt [70360,70422]
simple_stmt [70360,70422]
===
match
---
name: tis [49117,49120]
name: tis [49117,49120]
===
match
---
param [31492,31497]
param [31492,31497]
===
match
---
trailer [105136,105142]
trailer [105235,105241]
===
match
---
param [99527,99540]
param [99626,99639]
===
match
---
name: property [33788,33796]
name: property [33788,33796]
===
match
---
suite [33565,33782]
suite [33565,33782]
===
match
---
name: synchronize_session [101855,101874]
name: synchronize_session [101954,101973]
===
match
---
simple_stmt [60683,60689]
simple_stmt [60683,60689]
===
match
---
trailer [37674,37720]
trailer [37674,37720]
===
match
---
atom_expr [51688,51699]
atom_expr [51688,51699]
===
match
---
atom [64894,64931]
atom [64894,64931]
===
match
---
parameters [32690,32696]
parameters [32690,32696]
===
match
---
name: cls [109276,109279]
name: cls [109375,109378]
===
match
---
operator: , [46335,46336]
operator: , [46335,46336]
===
match
---
atom_expr [18224,18234]
atom_expr [18224,18234]
===
match
---
fstring [97991,98014]
fstring [98090,98113]
===
match
---
expr_stmt [48181,48214]
expr_stmt [48181,48214]
===
match
---
if_stmt [37206,37775]
if_stmt [37206,37775]
===
match
---
name: f_back [107492,107498]
name: f_back [107591,107597]
===
match
---
name: session [89442,89449]
name: session [89541,89548]
===
match
---
name: dag_id [34260,34266]
name: dag_id [34260,34266]
===
match
---
trailer [34971,35003]
trailer [34971,35003]
===
match
---
name: warnings [30301,30309]
name: warnings [30301,30309]
===
match
---
trailer [74399,74401]
trailer [74399,74401]
===
match
---
operator: , [61455,61456]
operator: , [61455,61456]
===
match
---
trailer [68442,68448]
trailer [68442,68448]
===
match
---
trailer [94633,94667]
trailer [94732,94766]
===
match
---
expr_stmt [96022,96048]
expr_stmt [96121,96147]
===
match
---
name: task_id [73517,73524]
name: task_id [73517,73524]
===
match
---
atom_expr [42762,42796]
atom_expr [42762,42796]
===
match
---
operator: , [83170,83171]
operator: , [83269,83270]
===
match
---
operator: -> [109281,109283]
operator: -> [109380,109382]
===
match
---
name: self [24501,24505]
name: self [24501,24505]
===
match
---
name: start_date [44906,44916]
name: start_date [44906,44916]
===
match
---
trailer [58460,58466]
trailer [58460,58466]
===
match
---
name: bool [33838,33842]
name: bool [33838,33842]
===
match
---
name: task_id [60835,60842]
name: task_id [60835,60842]
===
match
---
trailer [66824,66830]
trailer [66824,66830]
===
match
---
atom_expr [35953,35992]
atom_expr [35953,35992]
===
match
---
name: all [51448,51451]
name: all [51448,51451]
===
match
---
tfpdef [11564,11584]
tfpdef [11564,11584]
===
match
---
atom_expr [41931,41950]
atom_expr [41931,41950]
===
match
---
operator: = [75087,75088]
operator: = [75087,75088]
===
match
---
name: earliest [24407,24415]
name: earliest [24407,24415]
===
match
---
trailer [92037,92108]
trailer [92136,92207]
===
match
---
operator: , [57744,57745]
operator: , [57744,57745]
===
match
---
atom_expr [72920,72978]
atom_expr [72920,72978]
===
match
---
parameters [24103,24109]
parameters [24103,24109]
===
match
---
simple_stmt [25269,25339]
simple_stmt [25269,25339]
===
match
---
atom_expr [88068,88076]
atom_expr [88167,88175]
===
match
---
trailer [49126,49133]
trailer [49126,49133]
===
match
---
name: classmethod [109240,109251]
name: classmethod [109339,109350]
===
match
---
expr_stmt [50146,50357]
expr_stmt [50146,50357]
===
match
---
comparison [34242,34266]
comparison [34242,34266]
===
match
---
name: ORIENTATION_PRESETS [16374,16393]
name: ORIENTATION_PRESETS [16374,16393]
===
match
---
strings [52494,52666]
strings [52494,52666]
===
match
---
operator: } [17729,17730]
operator: } [17729,17730]
===
match
---
operator: = [83163,83164]
operator: = [83262,83263]
===
match
---
fstring_string: Task  [73946,73951]
fstring_string: Task  [73946,73951]
===
match
---
simple_stmt [86855,86880]
simple_stmt [86954,86979]
===
match
---
name: cast [1210,1214]
name: cast [1210,1214]
===
match
---
operator: @ [58263,58264]
operator: @ [58263,58264]
===
match
---
param [74456,74461]
param [74456,74461]
===
match
---
name: self [30250,30254]
name: self [30250,30254]
===
match
---
trailer [100711,100713]
trailer [100810,100812]
===
match
---
name: bool [34004,34008]
name: bool [34004,34008]
===
match
---
name: add [51891,51894]
name: add [51891,51894]
===
match
---
operator: , [1100,1101]
operator: , [1100,1101]
===
match
---
name: timezone [25207,25215]
name: timezone [25207,25215]
===
match
---
name: str [46629,46632]
name: str [46629,46632]
===
match
---
trailer [53507,53522]
trailer [53507,53522]
===
match
---
name: intersection [73267,73279]
name: intersection [73267,73279]
===
match
---
trailer [74307,74310]
trailer [74307,74310]
===
match
---
name: primaryjoin [97053,97064]
name: primaryjoin [97152,97163]
===
match
---
operator: = [12334,12335]
operator: = [12334,12335]
===
match
---
name: BaseOperator [1918,1930]
name: BaseOperator [1918,1930]
===
match
---
name: self [12620,12624]
name: self [12620,12624]
===
match
---
name: ExternalTaskMarker [51291,51309]
name: ExternalTaskMarker [51291,51309]
===
match
---
trailer [55570,55577]
trailer [55570,55577]
===
match
---
name: DagPickle [74658,74667]
name: DagPickle [74658,74667]
===
match
---
trailer [44319,44326]
trailer [44319,44326]
===
match
---
name: only_running [62208,62220]
name: only_running [62208,62220]
===
match
---
name: data_interval [27790,27803]
name: data_interval [27790,27803]
===
match
---
name: TaskInstanceKey [47512,47527]
name: TaskInstanceKey [47512,47527]
===
match
---
import_name [871,880]
import_name [871,880]
===
match
---
name: session [38221,38228]
name: session [38221,38228]
===
match
---
trailer [62563,62568]
trailer [62563,62568]
===
match
---
trailer [25284,25338]
trailer [25284,25338]
===
match
---
expr_stmt [74323,74348]
expr_stmt [74323,74348]
===
match
---
name: dag [66790,66793]
name: dag [66790,66793]
===
match
---
name: dag_run_state [68045,68058]
name: dag_run_state [68045,68058]
===
match
---
trailer [100668,100672]
trailer [100767,100771]
===
match
---
expr_stmt [87221,87247]
expr_stmt [87320,87346]
===
match
---
operator: , [62398,62399]
operator: , [62398,62399]
===
match
---
atom [58438,58493]
atom [58438,58493]
===
match
---
atom_expr [106822,106872]
atom_expr [106921,106971]
===
match
---
if_stmt [102535,102992]
if_stmt [102634,103091]
===
match
---
trailer [38699,38707]
trailer [38699,38707]
===
match
---
name: old_dag [108991,108998]
name: old_dag [109090,109097]
===
match
---
simple_stmt [34018,34144]
simple_stmt [34018,34144]
===
match
---
operator: , [68472,68473]
operator: , [68472,68473]
===
match
---
operator: = [106023,106024]
operator: = [106122,106123]
===
match
---
tfpdef [83808,83831]
tfpdef [83907,83930]
===
match
---
name: dag [57061,57064]
name: dag [57061,57064]
===
match
---
trailer [68421,68426]
trailer [68421,68426]
===
match
---
trailer [91631,91638]
trailer [91730,91737]
===
match
---
name: result [68723,68729]
name: result [68723,68729]
===
match
---
atom_expr [54867,54876]
atom_expr [54867,54876]
===
match
---
operator: = [19782,19783]
operator: = [19782,19783]
===
match
---
operator: } [13883,13884]
operator: } [13883,13884]
===
match
---
trailer [66400,66402]
trailer [66400,66402]
===
match
---
name: recursion_depth [46703,46718]
name: recursion_depth [46703,46718]
===
match
---
name: paused_dag_ids [100047,100061]
name: paused_dag_ids [100146,100160]
===
match
---
arglist [85559,85596]
arglist [85658,85695]
===
match
---
name: info [27269,27273]
name: info [27269,27273]
===
match
---
operator: , [47053,47054]
operator: , [47053,47054]
===
match
---
atom_expr [13951,13968]
atom_expr [13951,13968]
===
match
---
name: Session [47282,47289]
name: Session [47282,47289]
===
match
---
string: 'dag.dag_id' [94349,94361]
string: 'dag.dag_id' [94448,94460]
===
match
---
yield_expr [27485,27528]
yield_expr [27485,27528]
===
match
---
and_test [76351,76382]
and_test [76351,76382]
===
match
---
name: BackfillJob [79262,79273]
name: BackfillJob [79262,79273]
===
match
---
operator: , [3436,3437]
operator: , [3436,3437]
===
match
---
simple_stmt [24827,24861]
simple_stmt [24827,24861]
===
match
---
argument [20519,20526]
argument [20519,20526]
===
match
---
param [99210,99222]
param [99309,99321]
===
match
---
name: p_dag [50401,50406]
name: p_dag [50401,50406]
===
match
---
name: level [75082,75087]
name: level [75082,75087]
===
match
---
trailer [87361,87374]
trailer [87460,87473]
===
match
---
if_stmt [92379,93285]
if_stmt [92478,93384]
===
match
---
operator: = [12221,12222]
operator: = [12221,12222]
===
match
---
name: keys [73388,73392]
name: keys [73388,73392]
===
match
---
operator: , [94362,94363]
operator: , [94461,94462]
===
match
---
operator: * [54848,54849]
operator: * [54848,54849]
===
match
---
funcdef [18042,18100]
funcdef [18042,18100]
===
match
---
operator: , [21828,21829]
operator: , [21828,21829]
===
match
---
operator: = [104918,104919]
operator: = [105017,105018]
===
match
---
name: most_recent_dag_run [104566,104585]
name: most_recent_dag_run [104665,104684]
===
match
---
name: self [80182,80186]
name: self [80182,80186]
===
match
---
name: query [99427,99432]
name: query [99526,99531]
===
match
---
decorated [46255,46904]
decorated [46255,46904]
===
match
---
expr_stmt [3840,3851]
expr_stmt [3840,3851]
===
match
---
name: dag_id [86154,86160]
name: dag_id [86253,86259]
===
match
---
simple_stmt [74152,74183]
simple_stmt [74152,74183]
===
match
---
name: run_id [39507,39513]
name: run_id [39507,39513]
===
match
---
atom_expr [58456,58466]
atom_expr [58456,58466]
===
match
---
name: dag_id [15674,15680]
name: dag_id [15674,15680]
===
match
---
operator: , [29806,29807]
operator: , [29806,29807]
===
match
---
name: str [93840,93843]
name: str [93939,93942]
===
match
---
name: get_task_instances [44664,44682]
name: get_task_instances [44664,44682]
===
match
---
name: limit [103912,103917]
name: limit [104011,104016]
===
match
---
funcdef [74958,75308]
funcdef [74958,75308]
===
match
---
name: t [70572,70573]
name: t [70572,70573]
===
match
---
name: create_root [17651,17662]
name: create_root [17651,17662]
===
match
---
operator: = [66742,66743]
operator: = [66742,66743]
===
match
---
name: TaskInstance [47493,47505]
name: TaskInstance [47493,47505]
===
match
---
trailer [24479,24488]
trailer [24479,24488]
===
match
---
trailer [55455,55461]
trailer [55455,55461]
===
match
---
operator: , [46451,46452]
operator: , [46451,46452]
===
match
---
name: property [31366,31374]
name: property [31366,31374]
===
match
---
operator: ** [104022,104024]
operator: ** [104121,104123]
===
match
---
comparison [68517,68591]
comparison [68517,68591]
===
match
---
name: self [24799,24803]
name: self [24799,24803]
===
match
---
tfpdef [46525,46553]
tfpdef [46525,46553]
===
match
---
name: orm_dags [85040,85048]
name: orm_dags [85139,85147]
===
match
---
name: get_default_view [89098,89114]
name: get_default_view [89197,89213]
===
match
---
funcdef [31954,32323]
funcdef [31954,32323]
===
match
---
suite [49328,49394]
suite [49328,49394]
===
match
---
atom_expr [45742,45760]
atom_expr [45742,45760]
===
match
---
parameters [33828,33834]
parameters [33828,33834]
===
match
---
atom_expr [88735,88746]
atom_expr [88834,88845]
===
match
---
string: "The 'DAG.concurrency' attribute is deprecated. Please use 'DAG.max_active_tasks'." [30861,30944]
string: "The 'DAG.concurrency' attribute is deprecated. Please use 'DAG.max_active_tasks'." [30861,30944]
===
match
---
simple_stmt [74195,74250]
simple_stmt [74195,74250]
===
match
---
return_stmt [101229,101240]
return_stmt [101328,101339]
===
match
---
expr_stmt [65153,65632]
expr_stmt [65153,65632]
===
match
---
return_stmt [93783,93792]
return_stmt [93882,93891]
===
match
---
trailer [80882,80887]
trailer [80882,80887]
===
match
---
trailer [96838,96884]
trailer [96937,96983]
===
match
---
name: existing_dag_ids [85223,85239]
name: existing_dag_ids [85322,85338]
===
match
---
atom_expr [36160,36182]
atom_expr [36160,36182]
===
match
---
name: DEFAULT_VIEW_PRESETS [16086,16106]
name: DEFAULT_VIEW_PRESETS [16086,16106]
===
match
---
trailer [90568,90573]
trailer [90667,90672]
===
match
---
name: DagModel [100092,100100]
name: DagModel [100191,100199]
===
match
---
atom_expr [18003,18014]
atom_expr [18003,18014]
===
match
---
name: tasks [73416,73421]
name: tasks [73416,73421]
===
match
---
atom_expr [94854,94908]
atom_expr [94953,95007]
===
match
---
operator: @ [33528,33529]
operator: @ [33528,33529]
===
match
---
simple_stmt [49064,49105]
simple_stmt [49064,49105]
===
match
---
simple_stmt [22021,22033]
simple_stmt [22021,22033]
===
match
---
name: include_parentdag [67111,67128]
name: include_parentdag [67111,67128]
===
match
---
operator: , [91577,91578]
operator: , [91676,91677]
===
match
---
name: len [59544,59547]
name: len [59544,59547]
===
match
---
atom_expr [76055,76070]
atom_expr [76055,76070]
===
match
---
name: leaves [58517,58523]
name: leaves [58517,58523]
===
match
---
string: '_log' [92785,92791]
string: '_log' [92884,92890]
===
match
---
comparison [97782,97822]
comparison [97881,97921]
===
match
---
name: staticmethod [99147,99159]
name: staticmethod [99246,99258]
===
match
---
atom [20659,20802]
atom [20659,20802]
===
match
---
atom_expr [102922,102941]
atom_expr [103021,103040]
===
match
---
suite [99577,99720]
suite [99676,99819]
===
match
---
expr_stmt [84861,85031]
expr_stmt [84960,85130]
===
match
---
name: tis [65686,65689]
name: tis [65686,65689]
===
match
---
name: paused_dag_ids [100343,100357]
name: paused_dag_ids [100442,100456]
===
match
---
dotted_name [1883,1910]
dotted_name [1883,1910]
===
match
---
import_as_names [2787,2831]
import_as_names [2787,2831]
===
match
---
operator: = [16223,16224]
operator: = [16223,16224]
===
match
---
trailer [22083,22089]
trailer [22083,22089]
===
match
---
param [62181,62199]
param [62181,62199]
===
match
---
simple_stmt [105415,105490]
simple_stmt [105514,105589]
===
match
---
name: task_id [76527,76534]
name: task_id [76527,76534]
===
match
---
name: has_task_concurrency_limits [97916,97943]
name: has_task_concurrency_limits [98015,98042]
===
match
---
operator: , [66683,66684]
operator: , [66683,66684]
===
match
---
name: session [90959,90966]
name: session [91058,91065]
===
match
---
name: dagparam [2035,2043]
name: dagparam [2035,2043]
===
match
---
simple_stmt [13158,13179]
simple_stmt [13158,13179]
===
match
---
trailer [86364,86369]
trailer [86463,86468]
===
match
---
name: provide_session [40639,40654]
name: provide_session [40639,40654]
===
match
---
trailer [40414,40579]
trailer [40414,40579]
===
match
---
not_test [14342,14371]
not_test [14342,14371]
===
match
---
fstring [98529,98578]
fstring [98628,98677]
===
match
---
expr_stmt [42881,42946]
expr_stmt [42881,42946]
===
match
---
name: data_interval [83478,83491]
name: data_interval [83577,83590]
===
match
---
name: access_control [19849,19863]
name: access_control [19849,19863]
===
match
---
operator: == [35263,35265]
operator: == [35263,35265]
===
match
---
decorator [101940,101957]
decorator [102039,102056]
===
match
---
name: t [88122,88123]
name: t [88221,88222]
===
match
---
name: on_success_callback [16617,16636]
name: on_success_callback [16617,16636]
===
match
---
trailer [29292,29311]
trailer [29292,29311]
===
match
---
argument [53321,53336]
argument [53321,53336]
===
match
---
trailer [74543,74550]
trailer [74543,74550]
===
match
---
suite [74986,75308]
suite [74986,75308]
===
match
---
simple_stmt [98988,99069]
simple_stmt [99087,99168]
===
match
---
name: String [94322,94328]
name: String [94421,94427]
===
match
---
name: dag_id [34981,34987]
name: dag_id [34981,34987]
===
match
---
operator: = [101586,101587]
operator: = [101685,101686]
===
match
---
name: ValueError [82324,82334]
name: ValueError [82348,82358]
===
match
---
atom_expr [59585,59604]
atom_expr [59585,59604]
===
match
---
expr_stmt [86855,86879]
expr_stmt [86954,86978]
===
match
---
operator: = [51945,51946]
operator: = [51945,51946]
===
match
---
name: log [85550,85553]
name: log [85649,85652]
===
match
---
atom_expr [97699,97720]
atom_expr [97798,97819]
===
match
---
atom_expr [35470,35651]
atom_expr [35470,35651]
===
match
---
name: warn [64450,64454]
name: warn [64450,64454]
===
match
---
name: task [58439,58443]
name: task [58439,58443]
===
match
---
name: t [75238,75239]
name: t [75238,75239]
===
match
---
name: task_ids [48510,48518]
name: task_ids [48510,48518]
===
match
---
name: dag_id [53313,53319]
name: dag_id [53313,53319]
===
match
---
suite [102654,102703]
suite [102753,102802]
===
match
---
expr_stmt [37461,37511]
expr_stmt [37461,37511]
===
match
---
name: runs [37949,37953]
name: runs [37949,37953]
===
match
---
param [31890,31895]
param [31890,31895]
===
match
---
for_stmt [72628,73080]
for_stmt [72628,73080]
===
match
---
decorated [31682,31761]
decorated [31682,31761]
===
match
---
expr_stmt [85520,85537]
expr_stmt [85619,85636]
===
match
---
operator: == [49285,49287]
operator: == [49285,49287]
===
match
---
name: logging [3312,3319]
name: logging [3312,3319]
===
match
---
operator: <= [49162,49164]
operator: <= [49162,49164]
===
match
---
name: conf [83309,83313]
name: conf [83408,83412]
===
match
---
trailer [88734,88764]
trailer [88833,88863]
===
match
---
atom_expr [76217,76230]
atom_expr [76217,76230]
===
match
---
operator: , [46813,46814]
operator: , [46813,46814]
===
match
---
comparison [52982,53017]
comparison [52982,53017]
===
match
---
operator: = [77289,77290]
operator: = [77289,77290]
===
match
---
comparison [29407,29448]
comparison [29407,29448]
===
match
---
atom_expr [13313,13500]
atom_expr [13313,13500]
===
match
---
name: parent_group [71434,71446]
name: parent_group [71434,71446]
===
match
---
name: pendulum [53060,53068]
name: pendulum [53060,53068]
===
match
---
argument [106457,106462]
argument [106556,106561]
===
match
---
argument [57183,57200]
argument [57183,57200]
===
match
---
atom_expr [82570,82643]
atom_expr [82680,82753]
===
match
---
trailer [88350,88355]
trailer [88449,88454]
===
match
---
trailer [13961,13968]
trailer [13961,13968]
===
match
---
return_stmt [32261,32322]
return_stmt [32261,32322]
===
match
---
operator: } [74014,74015]
operator: } [74014,74015]
===
match
---
operator: = [26636,26637]
operator: = [26636,26637]
===
match
---
atom_expr [94627,94667]
atom_expr [94726,94766]
===
match
---
comp_op [20445,20451]
comp_op [20445,20451]
===
match
---
name: add [74812,74815]
name: add [74812,74815]
===
match
---
trailer [28821,28833]
trailer [28821,28833]
===
match
---
param [30080,30084]
param [30080,30084]
===
match
---
arglist [93733,93755]
arglist [93832,93854]
===
match
---
operator: = [49073,49074]
operator: = [49073,49074]
===
match
---
testlist_comp [70521,70539]
testlist_comp [70521,70539]
===
match
---
suite [60658,60689]
suite [60658,60689]
===
match
---
name: dttm [29391,29395]
name: dttm [29391,29395]
===
match
---
name: filter [100183,100189]
name: filter [100282,100288]
===
match
---
name: x [49547,49548]
name: x [49547,49548]
===
match
---
simple_stmt [50146,50358]
simple_stmt [50146,50358]
===
match
---
operator: @ [36342,36343]
operator: @ [36342,36343]
===
match
---
atom_expr [13602,13617]
atom_expr [13602,13617]
===
match
---
atom_expr [21562,21611]
atom_expr [21562,21611]
===
match
---
name: orm_dag [86855,86862]
name: orm_dag [86954,86961]
===
match
---
name: dag [67716,67719]
name: dag [67716,67719]
===
match
---
fstring [82335,82385]
fstring [82359,82409]
===
match
---
simple_stmt [38558,38719]
simple_stmt [38558,38719]
===
match
---
atom_expr [107476,107498]
atom_expr [107575,107597]
===
match
---
trailer [99247,99253]
trailer [99346,99352]
===
match
---
name: acyclic [61093,61100]
name: acyclic [61093,61100]
===
match
---
operator: = [55803,55804]
operator: = [55803,55804]
===
match
---
operator: = [11326,11327]
operator: = [11326,11327]
===
match
---
name: isinstance [14611,14621]
name: isinstance [14611,14621]
===
match
---
trailer [74915,74925]
trailer [74915,74925]
===
match
---
atom_expr [94634,94648]
atom_expr [94733,94747]
===
match
---
name: session [1534,1541]
name: session [1534,1541]
===
match
---
name: query [61839,61844]
name: query [61839,61844]
===
match
---
operator: , [46975,46976]
operator: , [46975,46976]
===
match
---
operator: , [106462,106463]
operator: , [106561,106562]
===
match
---
import_as_names [1384,1452]
import_as_names [1384,1452]
===
match
---
expr_stmt [67337,67349]
expr_stmt [67337,67349]
===
match
---
name: self [70583,70587]
name: self [70583,70587]
===
match
---
atom_expr [88177,88185]
atom_expr [88276,88284]
===
match
---
atom_expr [58712,58732]
atom_expr [58712,58732]
===
match
---
name: path [101108,101112]
name: path [101207,101211]
===
match
---
operator: , [11633,11634]
operator: , [11633,11634]
===
match
---
trailer [71307,71311]
trailer [71307,71311]
===
match
---
name: p_dag [50146,50151]
name: p_dag [50146,50151]
===
match
---
trailer [61523,61528]
trailer [61523,61528]
===
match
---
suite [64428,64611]
suite [64428,64611]
===
match
---
name: DeprecationWarning [84062,84080]
name: DeprecationWarning [84161,84179]
===
match
---
name: execution_date [61859,61873]
name: execution_date [61859,61873]
===
match
---
tfpdef [80857,80887]
tfpdef [80857,80887]
===
match
---
number: 1 [75162,75163]
number: 1 [75162,75163]
===
match
---
atom_expr [76201,76214]
atom_expr [76201,76214]
===
match
---
trailer [14569,14582]
trailer [14569,14582]
===
match
---
parameters [39958,40000]
parameters [39958,40000]
===
match
---
operator: , [93868,93869]
operator: , [93967,93968]
===
match
---
atom [59409,59429]
atom [59409,59429]
===
match
---
trailer [14865,14877]
trailer [14865,14877]
===
match
---
operator: , [51089,51090]
operator: , [51089,51090]
===
match
---
name: query [84861,84866]
name: query [84960,84965]
===
match
---
name: self [32401,32405]
name: self [32401,32405]
===
match
---
argument [61656,61668]
argument [61656,61668]
===
match
---
name: airflow [1662,1669]
name: airflow [1662,1669]
===
match
---
atom [42583,42600]
atom [42583,42600]
===
match
---
atom_expr [12905,12932]
atom_expr [12905,12932]
===
match
---
trailer [104936,104946]
trailer [105035,105045]
===
match
---
simple_stmt [20384,20430]
simple_stmt [20384,20430]
===
match
---
name: dag_sig [106025,106032]
name: dag_sig [106124,106131]
===
match
---
trailer [103989,104053]
trailer [104088,104152]
===
match
---
operator: , [94282,94283]
operator: , [94381,94382]
===
match
---
operator: * [46316,46317]
operator: * [46316,46317]
===
match
---
suite [107924,108055]
suite [108023,108154]
===
match
---
trailer [71611,71634]
trailer [71611,71634]
===
match
---
name: self [46942,46946]
name: self [46942,46946]
===
match
---
suite [44890,45597]
suite [44890,45597]
===
match
---
name: Timetable [24808,24817]
name: Timetable [24808,24817]
===
match
---
operator: , [11430,11431]
operator: , [11430,11431]
===
match
---
operator: , [32293,32294]
operator: , [32293,32294]
===
match
---
trailer [87720,87862]
trailer [87819,87961]
===
match
---
name: has_on_success_callback [17127,17150]
name: has_on_success_callback [17127,17150]
===
match
---
parameters [30079,30085]
parameters [30079,30085]
===
match
---
return_stmt [29860,30049]
return_stmt [29860,30049]
===
match
---
name: Set [47963,47966]
name: Set [47963,47966]
===
match
---
atom_expr [47081,47090]
atom_expr [47081,47090]
===
match
---
atom_expr [88024,88052]
atom_expr [88123,88151]
===
match
---
funcdef [34800,35049]
funcdef [34800,35049]
===
match
---
argument [50530,50547]
argument [50530,50547]
===
match
---
trailer [24179,24185]
trailer [24179,24185]
===
match
---
name: query [103606,103611]
name: query [103705,103710]
===
match
---
name: NUM_DAGS_PER_DAGRUN_QUERY [103922,103947]
name: NUM_DAGS_PER_DAGRUN_QUERY [104021,104046]
===
match
---
name: self [17749,17753]
name: self [17749,17753]
===
match
---
decorator [100812,100822]
decorator [100911,100921]
===
match
---
comparison [73841,73865]
comparison [73841,73865]
===
match
---
name: qry [35019,35022]
name: qry [35019,35022]
===
match
---
simple_stmt [60996,61073]
simple_stmt [60996,61073]
===
match
---
name: EdgeInfoType [16944,16956]
name: EdgeInfoType [16944,16956]
===
match
---
if_stmt [39781,39880]
if_stmt [39781,39880]
===
match
---
name: TI [34242,34244]
name: TI [34242,34244]
===
match
---
name: owners [95959,95965]
name: owners [96058,96064]
===
match
---
operator: = [39687,39688]
operator: = [39687,39688]
===
match
---
name: val [18378,18381]
name: val [18378,18381]
===
match
---
name: NativeEnvironment [42816,42833]
name: NativeEnvironment [42816,42833]
===
match
---
operator: = [66933,66934]
operator: = [66933,66934]
===
match
---
name: dag_obj [107515,107522]
name: dag_obj [107614,107621]
===
match
---
trailer [14910,14925]
trailer [14910,14925]
===
match
---
string: """         Add a task to the DAG          :param task: the task you want to add         :type task: task         """ [75476,75593]
string: """         Add a task to the DAG          :param task: the task you want to add         :type task: task         """ [75476,75593]
===
match
---
name: bool [12271,12275]
name: bool [12271,12275]
===
match
---
name: self [46302,46306]
name: self [46302,46306]
===
match
---
trailer [12567,12588]
trailer [12567,12588]
===
match
---
name: partial_subset [53508,53522]
name: partial_subset [53508,53522]
===
match
---
name: rerun_failed_tasks [80061,80079]
name: rerun_failed_tasks [80061,80079]
===
match
---
expr_stmt [66765,66777]
expr_stmt [66765,66777]
===
match
---
simple_stmt [89130,89196]
simple_stmt [89229,89295]
===
match
---
operator: , [55932,55933]
operator: , [55932,55933]
===
match
---
atom_expr [80758,80778]
atom_expr [80758,80778]
===
match
---
name: calculate_dagrun_date_fields [87692,87720]
name: calculate_dagrun_date_fields [87791,87819]
===
match
---
return_stmt [17933,18015]
return_stmt [17933,18015]
===
match
---
dictorsetmaker [92512,93270]
dictorsetmaker [92611,93369]
===
match
---
atom_expr [17122,17150]
atom_expr [17122,17150]
===
match
---
trailer [101758,101764]
trailer [101857,101863]
===
match
---
operator: , [55690,55691]
operator: , [55690,55691]
===
match
---
name: Iterable [1131,1139]
name: Iterable [1131,1139]
===
match
---
classdef [108057,109339]
classdef [108156,109438]
===
match
---
trailer [15231,15244]
trailer [15231,15244]
===
match
---
operator: = [49696,49697]
operator: = [49696,49697]
===
match
---
name: parse [14716,14721]
name: parse [14716,14721]
===
match
---
expr_stmt [48326,48341]
expr_stmt [48326,48341]
===
match
---
trailer [89211,89224]
trailer [89310,89323]
===
match
---
trailer [99448,99455]
trailer [99547,99554]
===
match
---
name: execution_date [40831,40845]
name: execution_date [40831,40845]
===
match
---
operator: , [80847,80848]
operator: , [80847,80848]
===
match
---
trailer [74096,74098]
trailer [74096,74098]
===
match
---
name: timezone [14280,14288]
name: timezone [14280,14288]
===
match
---
simple_stmt [1621,1657]
simple_stmt [1621,1657]
===
match
---
simple_stmt [100636,100714]
simple_stmt [100735,100813]
===
match
---
name: String [1429,1435]
name: String [1429,1435]
===
match
---
name: get_tis [64157,64164]
name: get_tis [64157,64164]
===
match
---
atom_expr [75130,75139]
atom_expr [75130,75139]
===
match
---
atom_expr [82422,82452]
atom_expr [82467,82497]
===
match
---
name: kwargs [106466,106472]
name: kwargs [106565,106571]
===
match
---
name: schedule_interval [10922,10939]
name: schedule_interval [10922,10939]
===
match
---
string: "Deactivating DAG ID %s since it was last touched by the scheduler at %s" [90591,90664]
string: "Deactivating DAG ID %s since it was last touched by the scheduler at %s" [90690,90763]
===
match
---
name: parent_dag [86918,86928]
name: parent_dag [87017,87027]
===
match
---
name: fileloc [102548,102555]
name: fileloc [102647,102654]
===
match
---
operator: } [71394,71395]
operator: } [71394,71395]
===
match
---
trailer [37494,37511]
trailer [37494,37511]
===
match
---
decorated [43669,44741]
decorated [43669,44741]
===
match
---
trailer [13653,13666]
trailer [13653,13666]
===
match
---
name: end_date [66887,66895]
name: end_date [66887,66895]
===
match
---
atom_expr [76369,76382]
atom_expr [76369,76382]
===
match
---
operator: @ [101246,101247]
operator: @ [101345,101346]
===
match
---
name: dag_run_state [67146,67159]
name: dag_run_state [67146,67159]
===
match
---
trailer [57930,58233]
trailer [57930,58233]
===
match
---
operator: , [68626,68627]
operator: , [68626,68627]
===
match
---
operator: = [11585,11586]
operator: = [11585,11586]
===
match
---
try_stmt [101084,101241]
try_stmt [101183,101340]
===
match
---
operator: = [12097,12098]
operator: = [12097,12098]
===
match
---
name: list [88172,88176]
name: list [88271,88275]
===
match
---
for_stmt [73089,73396]
for_stmt [73089,73396]
===
match
---
name: downstream [53759,53769]
name: downstream [53759,53769]
===
match
---
param [31896,31906]
param [31896,31906]
===
match
---
name: external_task [51270,51283]
name: external_task [51270,51283]
===
match
---
param [11828,11888]
param [11828,11888]
===
match
---
name: d [86709,86710]
name: d [86808,86809]
===
match
---
name: is_subdag [86828,86837]
name: is_subdag [86927,86936]
===
match
---
atom_expr [38628,38641]
atom_expr [38628,38641]
===
match
---
name: include_subdags [47101,47116]
name: include_subdags [47101,47116]
===
match
---
operator: = [21893,21894]
operator: = [21893,21894]
===
match
---
name: cls [103039,103042]
name: cls [103138,103141]
===
match
---
argument [84954,84969]
argument [85053,85068]
===
match
---
operator: = [29972,29973]
operator: = [29972,29973]
===
match
---
atom [40359,40608]
atom [40359,40608]
===
match
---
name: State [86477,86482]
name: State [86576,86581]
===
match
---
atom_expr [100129,100147]
atom_expr [100228,100246]
===
match
---
atom_expr [89253,89302]
atom_expr [89352,89401]
===
match
---
name: result [54818,54824]
name: result [54818,54824]
===
match
---
atom_expr [102014,102023]
atom_expr [102113,102122]
===
match
---
name: _dag_id [30197,30204]
name: _dag_id [30197,30204]
===
match
---
string: 'last_loaded' [92618,92631]
string: 'last_loaded' [92717,92730]
===
match
---
param [18190,18194]
param [18190,18194]
===
match
---
expr_stmt [13552,13593]
expr_stmt [13552,13593]
===
match
---
operator: , [77683,77684]
operator: , [77683,77684]
===
match
---
operator: , [68838,68839]
operator: , [68838,68839]
===
match
---
atom_expr [69023,69213]
atom_expr [69023,69213]
===
match
---
simple_stmt [13313,13501]
simple_stmt [13313,13501]
===
match
---
string: 'pickling_duration' [74197,74216]
string: 'pickling_duration' [74197,74216]
===
match
---
classdef [94130,94432]
classdef [94229,94531]
===
match
---
operator: = [65604,65605]
operator: = [65604,65605]
===
match
---
name: filelocs [86780,86788]
name: filelocs [86879,86887]
===
match
---
fstring_expr [67588,67597]
fstring_expr [67588,67597]
===
match
---
trailer [68667,68687]
trailer [68667,68687]
===
match
---
expr_stmt [109085,109152]
expr_stmt [109184,109251]
===
match
---
string: 'start_date' [14029,14041]
string: 'start_date' [14029,14041]
===
match
---
name: dag [84791,84794]
name: dag [84890,84893]
===
match
---
arglist [27970,28000]
arglist [27970,28000]
===
match
---
operator: , [92925,92926]
operator: , [93024,93025]
===
match
---
number: 0 [67370,67371]
number: 0 [67370,67371]
===
match
---
dotted_name [30128,30141]
dotted_name [30128,30141]
===
match
---
name: dag [90682,90685]
name: dag [90781,90784]
===
match
---
trailer [92458,92491]
trailer [92557,92590]
===
match
---
operator: , [80894,80895]
operator: , [80894,80895]
===
match
---
name: get_task_instances [37319,37337]
name: get_task_instances [37319,37337]
===
match
---
simple_stmt [94257,94302]
simple_stmt [94356,94401]
===
match
---
param [62430,62444]
param [62430,62444]
===
match
---
import_from [1361,1452]
import_from [1361,1452]
===
match
---
operator: = [80125,80126]
operator: = [80125,80126]
===
match
---
name: typing_compat [2621,2634]
name: typing_compat [2621,2634]
===
match
---
name: task [77196,77200]
name: task [77196,77200]
===
match
---
name: dag_id [39847,39853]
name: dag_id [39847,39853]
===
match
---
trailer [61528,61679]
trailer [61528,61679]
===
match
---
trailer [16938,16957]
trailer [16938,16957]
===
match
---
expr_stmt [35210,35278]
expr_stmt [35210,35278]
===
match
---
trailer [14084,14098]
trailer [14084,14098]
===
match
---
name: t [70778,70779]
name: t [70778,70779]
===
match
---
dotted_name [3131,3150]
dotted_name [3131,3150]
===
match
---
name: all [65696,65699]
name: all [65696,65699]
===
match
---
atom_expr [72855,72880]
atom_expr [72855,72880]
===
match
---
operator: , [40693,40694]
operator: , [40693,40694]
===
match
---
name: RUNNING [86483,86490]
name: RUNNING [86582,86589]
===
match
---
name: task [75846,75850]
name: task [75846,75850]
===
match
---
suite [36036,36147]
suite [36036,36147]
===
match
---
param [12293,12341]
param [12293,12341]
===
match
---
trailer [73897,73907]
trailer [73897,73907]
===
match
---
name: cls [83803,83806]
name: cls [83902,83905]
===
match
---
expr_stmt [74111,74139]
expr_stmt [74111,74139]
===
match
---
if_stmt [15318,15415]
if_stmt [15318,15415]
===
match
---
operator: , [94876,94877]
operator: , [94975,94976]
===
match
---
name: dag_bound_args [106710,106724]
name: dag_bound_args [106809,106823]
===
match
---
trailer [13796,13803]
trailer [13796,13803]
===
match
---
comparison [76561,76608]
comparison [76561,76608]
===
match
---
name: children [72263,72271]
name: children [72263,72271]
===
match
---
param [77536,77546]
param [77536,77546]
===
match
---
name: only_failed [66922,66933]
name: only_failed [66922,66933]
===
match
---
name: warn [20955,20959]
name: warn [20955,20959]
===
match
---
atom_expr [87297,87321]
atom_expr [87396,87420]
===
match
---
trailer [13170,13178]
trailer [13170,13178]
===
match
---
name: conf [80711,80715]
name: conf [80711,80715]
===
match
---
atom_expr [55788,55802]
atom_expr [55788,55802]
===
match
---
operator: , [23900,23901]
operator: , [23900,23901]
===
match
---
decorated [99322,99475]
decorated [99421,99574]
===
match
---
atom_expr [85848,85869]
atom_expr [85947,85968]
===
match
---
operator: = [15502,15503]
operator: = [15502,15503]
===
match
---
name: tasks [59447,59452]
name: tasks [59447,59452]
===
match
---
name: self [65159,65163]
name: self [65159,65163]
===
match
---
operator: , [69144,69145]
operator: , [69144,69145]
===
match
---
operator: = [72918,72919]
operator: = [72918,72919]
===
match
---
name: set_task_instance_state [55653,55676]
name: set_task_instance_state [55653,55676]
===
match
---
parameters [25373,25515]
parameters [25373,25515]
===
match
---
param [58524,58528]
param [58524,58528]
===
match
---
return_stmt [44652,44740]
return_stmt [44652,44740]
===
match
---
comparison [51474,51495]
comparison [51474,51495]
===
match
---
name: cls [102475,102478]
name: cls [102574,102577]
===
match
---
atom_expr [103821,103831]
atom_expr [103920,103930]
===
match
---
name: active_dates [38018,38030]
name: active_dates [38018,38030]
===
match
---
name: root_dag_id [86977,86988]
name: root_dag_id [87076,87087]
===
match
---
name: self [66224,66228]
name: self [66224,66228]
===
match
---
arglist [40432,40565]
arglist [40432,40565]
===
match
---
name: bool [101327,101331]
name: bool [101426,101430]
===
match
---
name: is_subdag [87141,87150]
name: is_subdag [87240,87249]
===
match
---
name: ScheduleInterval [10950,10966]
name: ScheduleInterval [10950,10966]
===
match
---
name: DagModel [89825,89833]
name: DagModel [89924,89932]
===
match
---
operator: , [57707,57708]
operator: , [57707,57708]
===
match
---
return_stmt [100636,100713]
return_stmt [100735,100812]
===
match
---
trailer [86080,86090]
trailer [86179,86189]
===
match
---
atom_expr [26582,26614]
atom_expr [26582,26614]
===
match
---
string: """         Returns edge information for the given pair of tasks if present, and         None if there is no information.         """ [93426,93559]
string: """         Returns edge information for the given pair of tasks if present, and         None if there is no information.         """ [93525,93658]
===
match
---
raise_stmt [53403,53461]
raise_stmt [53403,53461]
===
match
---
name: provide_session [35055,35070]
name: provide_session [35055,35070]
===
match
---
operator: , [53095,53096]
operator: , [53095,53096]
===
match
---
name: models [2161,2167]
name: models [2161,2167]
===
match
---
operator: = [94313,94314]
operator: = [94412,94413]
===
match
---
name: safe_dag_id [100737,100748]
name: safe_dag_id [100836,100847]
===
match
---
atom [70571,70638]
atom [70571,70638]
===
match
---
name: end_date [61968,61976]
name: end_date [61968,61976]
===
match
---
name: dag [87784,87787]
name: dag [87883,87886]
===
match
---
operator: = [53671,53672]
operator: = [53671,53672]
===
match
---
name: doc_md [17280,17286]
name: doc_md [17280,17286]
===
match
---
atom_expr [67231,67250]
atom_expr [67231,67250]
===
match
---
expr_stmt [44612,44643]
expr_stmt [44612,44643]
===
match
---
simple_stmt [18205,18236]
simple_stmt [18205,18236]
===
match
---
funcdef [97956,98015]
funcdef [98055,98114]
===
match
---
atom_expr [84992,85020]
atom_expr [85091,85119]
===
match
---
string: "This method is deprecated and will be removed in a future version. Please use bulk_write_to_db" [83952,84048]
string: "This method is deprecated and will be removed in a future version. Please use bulk_write_to_db" [84051,84147]
===
match
---
operator: , [70392,70393]
operator: , [70392,70393]
===
match
---
argument [57944,57965]
argument [57944,57965]
===
match
---
name: info [27785,27789]
name: info [27785,27789]
===
match
---
trailer [67486,67491]
trailer [67486,67491]
===
match
---
name: Session [43810,43817]
name: Session [43810,43817]
===
match
---
operator: } [16393,16394]
operator: } [16393,16394]
===
match
---
simple_stmt [104214,104518]
simple_stmt [104313,104617]
===
match
---
subscriptlist [69338,69371]
subscriptlist [69338,69371]
===
match
---
trailer [16476,16486]
trailer [16476,16486]
===
match
---
number: 30 [44974,44976]
number: 30 [44974,44976]
===
match
---
argument [67093,67128]
argument [67093,67128]
===
match
---
name: true [38850,38854]
name: true [38850,38854]
===
match
---
simple_stmt [10528,10581]
simple_stmt [10528,10581]
===
match
---
simple_stmt [13982,14016]
simple_stmt [13982,14016]
===
match
---
expr_stmt [3341,3396]
expr_stmt [3341,3396]
===
match
---
decorator [89359,89373]
decorator [89458,89472]
===
match
---
operator: = [98955,98956]
operator: = [99054,99055]
===
match
---
trailer [89949,89956]
trailer [90048,90055]
===
match
---
operator: , [46633,46634]
operator: , [46633,46634]
===
match
---
arglist [61999,62049]
arglist [61999,62049]
===
match
---
param [31713,31717]
param [31713,31717]
===
match
---
return_stmt [99116,99140]
return_stmt [99215,99239]
===
match
---
name: cached_property [24062,24077]
name: cached_property [24062,24077]
===
match
---
funcdef [23615,24056]
funcdef [23615,24056]
===
match
---
name: following [29430,29439]
name: following [29430,29439]
===
match
---
name: warnings [12972,12980]
name: warnings [12972,12980]
===
match
---
trailer [76373,76382]
trailer [76373,76382]
===
match
---
return_stmt [73726,73756]
return_stmt [73726,73756]
===
match
---
operator: , [62286,62287]
operator: , [62286,62287]
===
match
---
trailer [98376,98408]
trailer [98475,98507]
===
match
---
operator: = [48185,48186]
operator: = [48185,48186]
===
match
---
import_from [1557,1594]
import_from [1557,1594]
===
match
---
trailer [80347,80364]
trailer [80347,80364]
===
match
---
trailer [50246,50252]
trailer [50246,50252]
===
match
---
name: _get_task_instances [53770,53789]
name: _get_task_instances [53770,53789]
===
match
---
tfpdef [93845,93868]
tfpdef [93944,93967]
===
match
---
name: kwargs [97306,97312]
name: kwargs [97405,97411]
===
match
---
trailer [99030,99060]
trailer [99129,99159]
===
match
---
suite [29851,30050]
suite [29851,30050]
===
match
---
name: edge_info [93693,93702]
name: edge_info [93792,93801]
===
match
---
simple_stmt [87045,87099]
simple_stmt [87144,87198]
===
match
---
name: missing_dag_id [85372,85386]
name: missing_dag_id [85471,85485]
===
match
---
operator: = [17422,17423]
operator: = [17422,17423]
===
match
---
number: 2 [64356,64357]
number: 2 [64356,64357]
===
match
---
name: func [34198,34202]
name: func [34198,34202]
===
match
---
operator: = [83396,83397]
operator: = [83495,83496]
===
match
---
atom_expr [11769,11818]
atom_expr [11769,11818]
===
match
---
name: start_date [77279,77289]
name: start_date [77279,77289]
===
match
---
name: timetable [27212,27221]
name: timetable [27212,27221]
===
match
---
operator: { [62581,62582]
operator: { [62581,62582]
===
match
---
name: DeprecationWarning [41202,41220]
name: DeprecationWarning [41202,41220]
===
match
---
number: 0 [46072,46073]
number: 0 [46072,46073]
===
match
---
expr_stmt [44930,44985]
expr_stmt [44930,44985]
===
match
---
simple_stmt [61731,61796]
simple_stmt [61731,61796]
===
match
---
operator: = [95045,95046]
operator: = [95144,95145]
===
match
---
name: self [23576,23580]
name: self [23576,23580]
===
match
---
trailer [71305,71312]
trailer [71305,71312]
===
match
---
name: property [30745,30753]
name: property [30745,30753]
===
match
---
name: default [95141,95148]
name: default [95240,95247]
===
match
---
name: next_dagrun_info [104846,104862]
name: next_dagrun_info [104945,104961]
===
match
---
name: self [76072,76076]
name: self [76072,76076]
===
match
---
trailer [28905,28909]
trailer [28905,28909]
===
match
---
operator: , [37282,37283]
operator: , [37282,37283]
===
match
---
operator: = [27936,27937]
operator: = [27936,27937]
===
match
---
operator: = [53929,53930]
operator: = [53929,53930]
===
match
---
decorator [99725,99739]
decorator [99824,99838]
===
match
---
name: next_dagrun_after_date [23619,23641]
name: next_dagrun_after_date [23619,23641]
===
match
---
name: start_date [50498,50508]
name: start_date [50498,50508]
===
match
---
funcdef [45616,46250]
funcdef [45616,46250]
===
match
---
operator: , [100307,100308]
operator: , [100406,100407]
===
match
---
trailer [36086,36110]
trailer [36086,36110]
===
match
---
simple_stmt [41917,41951]
simple_stmt [41917,41951]
===
match
---
name: AirflowException [98252,98268]
name: AirflowException [98351,98367]
===
match
---
trailer [96343,96368]
trailer [96442,96467]
===
match
---
trailer [40453,40460]
trailer [40453,40460]
===
match
---
suite [89456,89959]
suite [89555,90058]
===
match
---
operator: -> [31995,31997]
operator: -> [31995,31997]
===
match
---
atom_expr [30467,30479]
atom_expr [30467,30479]
===
match
---
factor [37361,37363]
factor [37361,37363]
===
match
---
name: dag [66220,66223]
name: dag [66220,66223]
===
match
---
name: dag_id [30073,30079]
name: dag_id [30073,30079]
===
match
---
if_stmt [73405,73473]
if_stmt [73405,73473]
===
match
---
arglist [27775,27809]
arglist [27775,27809]
===
match
---
funcdef [32676,32745]
funcdef [32676,32745]
===
match
---
simple_stmt [66136,66289]
simple_stmt [66136,66289]
===
match
---
if_stmt [39481,39604]
if_stmt [39481,39604]
===
match
---
name: run_backwards [77664,77677]
name: run_backwards [77664,77677]
===
match
---
string: """         Returns a list of dag run execution dates currently running          :return: List of execution dates         """ [37815,37940]
string: """         Returns a list of dag run execution dates currently running          :return: List of execution dates         """ [37815,37940]
===
match
---
name: max_active_tasks [96318,96334]
name: max_active_tasks [96417,96433]
===
match
---
if_stmt [73684,73757]
if_stmt [73684,73757]
===
match
---
name: interval [2421,2429]
name: interval [2421,2429]
===
match
---
name: id [74931,74933]
name: id [74931,74933]
===
match
---
name: _dag_id [13193,13200]
name: _dag_id [13193,13200]
===
match
---
argument [14774,14796]
argument [14774,14796]
===
match
---
operator: = [51756,51757]
operator: = [51756,51757]
===
match
---
trailer [39073,39078]
trailer [39073,39078]
===
match
---
name: relative_to [33235,33246]
name: relative_to [33235,33246]
===
match
---
name: execution_date [39011,39025]
name: execution_date [39011,39025]
===
match
---
operator: , [90957,90958]
operator: , [91056,91057]
===
match
---
name: value [35023,35028]
name: value [35023,35028]
===
match
---
operator: = [50574,50575]
operator: = [50574,50575]
===
match
---
operator: = [66677,66678]
operator: = [66677,66678]
===
match
---
atom [86654,86656]
atom [86753,86755]
===
match
---
name: task [76472,76476]
name: task [76472,76476]
===
match
---
trailer [99437,99444]
trailer [99536,99543]
===
match
---
trailer [15680,15688]
trailer [15680,15688]
===
match
---
name: dag_bag [65567,65574]
name: dag_bag [65567,65574]
===
match
---
operator: @ [4103,4104]
operator: @ [4103,4104]
===
match
---
comp_if [58467,58492]
comp_if [58467,58492]
===
match
---
trailer [89800,89806]
trailer [89899,89905]
===
match
---
name: utils [2713,2718]
name: utils [2713,2718]
===
match
---
funcdef [33953,34370]
funcdef [33953,34370]
===
match
---
param [18122,18127]
param [18122,18127]
===
match
---
operator: = [94517,94518]
operator: = [94616,94617]
===
match
---
trailer [15271,15289]
trailer [15271,15289]
===
match
---
expr_stmt [57638,57791]
expr_stmt [57638,57791]
===
match
---
arith_expr [75110,75139]
arith_expr [75110,75139]
===
match
---
string: """         Ensure the DagModel rows for the given dags are up-to-date in the dag table in the DB, including         calculated fields.          Note that this method can be called for both DAGs and SubDAGs. A SubDag is actually a SubDagOperator.          :param dags: the DAG objects to save to the DB         :type dags: List[airflow.models.dag.DAG]         :return: None         """ [84286,84671]
string: """         Ensure the DagModel rows for the given dags are up-to-date in the dag table in the DB, including         calculated fields.          Note that this method can be called for both DAGs and SubDAGs. A SubDag is actually a SubDagOperator.          :param dags: the DAG objects to save to the DB         :type dags: List[airflow.models.dag.DAG]         :return: None         """ [84385,84770]
===
match
---
name: state [91946,91951]
name: state [92045,92050]
===
match
---
operator: , [45900,45901]
operator: , [45900,45901]
===
match
---
operator: @ [106080,106081]
operator: @ [106179,106180]
===
match
---
operator: = [23925,23926]
operator: = [23925,23926]
===
match
---
trailer [42904,42925]
trailer [42904,42925]
===
match
---
name: str [30170,30173]
name: str [30170,30173]
===
match
---
argument [29927,29942]
argument [29927,29942]
===
match
---
tfpdef [105838,105849]
tfpdef [105937,105948]
===
match
---
name: key [51761,51764]
name: key [51761,51764]
===
match
---
name: simple [2565,2571]
name: simple [2565,2571]
===
match
---
name: str [30259,30262]
name: str [30259,30262]
===
match
---
import_as_name [2801,2831]
import_as_name [2801,2831]
===
match
---
atom_expr [104669,104685]
atom_expr [104768,104784]
===
match
---
operator: = [83011,83012]
operator: = [83110,83111]
===
match
---
name: stacklevel [84094,84104]
name: stacklevel [84193,84203]
===
match
---
operator: = [50617,50618]
operator: = [50617,50618]
===
match
---
simple_stmt [65087,65112]
simple_stmt [65087,65112]
===
match
---
atom_expr [73559,73568]
atom_expr [73559,73568]
===
match
---
tfpdef [61420,61448]
tfpdef [61420,61448]
===
match
---
funcdef [39935,40633]
funcdef [39935,40633]
===
match
---
operator: } [53458,53459]
operator: } [53458,53459]
===
match
---
operator: = [49349,49350]
operator: = [49349,49350]
===
match
---
atom [101822,101853]
atom [101921,101952]
===
match
---
name: back [13792,13796]
name: back [13792,13796]
===
match
---
name: ID_LEN [1865,1871]
name: ID_LEN [1865,1871]
===
match
---
arglist [96250,96311]
arglist [96349,96410]
===
match
---
name: self [105369,105373]
name: self [105468,105472]
===
match
---
atom_expr [100151,100168]
atom_expr [100250,100267]
===
match
---
name: __repr__ [94391,94399]
name: __repr__ [94490,94498]
===
match
---
name: session [35216,35223]
name: session [35216,35223]
===
match
---
name: tags [85528,85532]
name: tags [85627,85631]
===
match
---
name: task_dict [71248,71257]
name: task_dict [71248,71257]
===
match
---
simple_stmt [94503,94525]
simple_stmt [94602,94624]
===
match
---
parameters [18115,18128]
parameters [18115,18128]
===
match
---
operator: , [50261,50262]
operator: , [50261,50262]
===
match
---
funcdef [18762,18853]
funcdef [18762,18853]
===
match
---
operator: , [53627,53628]
operator: , [53627,53628]
===
match
---
name: query [99248,99253]
name: query [99347,99352]
===
match
---
param [58766,58800]
param [58766,58800]
===
match
---
name: ScheduleInterval [3341,3357]
name: ScheduleInterval [3341,3357]
===
match
---
operator: = [48097,48098]
operator: = [48097,48098]
===
match
---
name: run_id [39057,39063]
name: run_id [39057,39063]
===
match
---
trailer [98268,98596]
trailer [98367,98695]
===
match
---
name: self [13649,13653]
name: self [13649,13653]
===
match
---
name: DagTag [88279,88285]
name: DagTag [88378,88384]
===
match
---
suite [97975,98015]
suite [98074,98114]
===
match
---
expr_stmt [15909,15947]
expr_stmt [15909,15947]
===
match
---
operator: = [77477,77478]
operator: = [77477,77478]
===
match
---
number: 0 [67431,67432]
number: 0 [67431,67432]
===
match
---
simple_stmt [74911,74934]
simple_stmt [74911,74934]
===
match
---
expr_stmt [3476,3522]
expr_stmt [3476,3522]
===
match
---
name: DeprecationWarning [35596,35614]
name: DeprecationWarning [35596,35614]
===
match
---
name: Optional [11994,12002]
name: Optional [11994,12002]
===
match
---
name: concurrency [13221,13232]
name: concurrency [13221,13232]
===
match
---
operator: = [67343,67344]
operator: = [67343,67344]
===
match
---
trailer [15066,15081]
trailer [15066,15081]
===
match
---
trailer [4040,4049]
trailer [4040,4049]
===
match
---
argument [29944,30001]
argument [29944,30001]
===
match
---
name: make_aware [45020,45030]
name: make_aware [45020,45030]
===
match
---
expr_stmt [52026,52040]
expr_stmt [52026,52040]
===
match
---
name: scalar [34336,34342]
name: scalar [34336,34342]
===
match
---
name: Optional [11009,11017]
name: Optional [11009,11017]
===
match
---
name: max_active_runs [15736,15751]
name: max_active_runs [15736,15751]
===
match
---
name: _tb [18892,18895]
name: _tb [18892,18895]
===
match
---
name: __class__ [68383,68392]
name: __class__ [68383,68392]
===
match
---
name: latest [28937,28943]
name: latest [28937,28943]
===
match
---
atom_expr [12409,12428]
atom_expr [12409,12428]
===
match
---
trailer [54925,54953]
trailer [54925,54953]
===
match
---
suite [73108,73396]
suite [73108,73396]
===
match
---
param [42009,42013]
param [42009,42013]
===
match
---
trailer [98811,98831]
trailer [98910,98930]
===
match
---
expr_stmt [21432,21465]
expr_stmt [21432,21465]
===
match
---
trailer [86016,86029]
trailer [86115,86128]
===
match
---
expr_stmt [96806,96978]
expr_stmt [96905,97077]
===
match
---
atom_expr [15805,15827]
atom_expr [15805,15827]
===
match
---
if_stmt [53358,53462]
if_stmt [53358,53462]
===
match
---
name: downstream [53482,53492]
name: downstream [53482,53492]
===
match
---
name: conf [97154,97158]
name: conf [97253,97257]
===
match
---
expr_stmt [48740,48799]
expr_stmt [48740,48799]
===
match
---
trailer [55461,55465]
trailer [55461,55465]
===
match
---
operator: = [53983,53984]
operator: = [53983,53984]
===
match
---
suite [42015,42084]
suite [42015,42084]
===
match
---
name: end_date [76374,76382]
name: end_date [76374,76382]
===
match
---
name: self [17122,17126]
name: self [17122,17126]
===
match
---
name: next_dagrun_info [104598,104614]
name: next_dagrun_info [104697,104713]
===
match
---
if_stmt [64857,64963]
if_stmt [64857,64963]
===
match
---
argument [83309,83318]
argument [83408,83417]
===
match
---
comparison [16158,16192]
comparison [16158,16192]
===
match
---
name: dag_id [39709,39715]
name: dag_id [39709,39715]
===
match
---
name: pop_context_managed_dag [18917,18940]
name: pop_context_managed_dag [18917,18940]
===
match
---
operator: = [84104,84105]
operator: = [84203,84204]
===
match
---
name: concurrency [97653,97664]
name: concurrency [97752,97763]
===
match
---
decorated [4103,94128]
decorated [4103,94227]
===
match
---
expr_stmt [76786,76801]
expr_stmt [76786,76801]
===
match
---
name: end_date [66522,66530]
name: end_date [66522,66530]
===
match
---
trailer [104548,104565]
trailer [104647,104664]
===
match
---
atom_expr [30109,30121]
atom_expr [30109,30121]
===
match
---
atom_expr [15203,15257]
atom_expr [15203,15257]
===
match
---
import_from [2884,2930]
import_from [2884,2930]
===
match
---
suite [35363,35688]
suite [35363,35688]
===
match
---
argument [54254,54287]
argument [54254,54287]
===
match
---
trailer [74889,74896]
trailer [74889,74896]
===
match
---
param [80525,80567]
param [80525,80567]
===
match
---
simple_stmt [33486,33523]
simple_stmt [33486,33523]
===
match
---
simple_stmt [17457,17514]
simple_stmt [17457,17514]
===
match
---
name: __init__ [10826,10834]
name: __init__ [10826,10834]
===
match
---
tfpdef [69313,69372]
tfpdef [69313,69372]
===
match
---
operator: , [30698,30699]
operator: , [30698,30699]
===
match
---
operator: ** [106127,106129]
operator: ** [106226,106228]
===
match
---
operator: = [107531,107532]
operator: = [107630,107631]
===
match
---
atom_expr [94271,94282]
atom_expr [94370,94381]
===
match
---
simple_stmt [18378,18413]
simple_stmt [18378,18413]
===
match
---
simple_stmt [42881,42963]
simple_stmt [42881,42963]
===
match
---
name: str [32969,32972]
name: str [32969,32972]
===
match
---
if_stmt [15123,15258]
if_stmt [15123,15258]
===
match
---
name: getboolean [94859,94869]
name: getboolean [94958,94968]
===
match
---
simple_stmt [65784,65793]
simple_stmt [65784,65793]
===
match
---
trailer [60876,60883]
trailer [60876,60883]
===
match
---
name: os [33493,33495]
name: os [33493,33495]
===
match
---
name: v [68642,68643]
name: v [68642,68643]
===
match
---
atom_expr [86147,86160]
atom_expr [86246,86259]
===
match
---
trailer [99800,99805]
trailer [99899,99904]
===
match
---
name: start_date [20496,20506]
name: start_date [20496,20506]
===
match
---
expr_stmt [15805,15847]
expr_stmt [15805,15847]
===
match
---
simple_stmt [101022,101034]
simple_stmt [101121,101133]
===
match
---
funcdef [43355,43664]
funcdef [43355,43664]
===
match
---
name: task_ids [46967,46975]
name: task_ids [46967,46975]
===
match
---
trailer [53312,53319]
trailer [53312,53319]
===
match
---
name: group_id [72319,72327]
name: group_id [72319,72327]
===
match
---
name: self [32973,32977]
name: self [32973,32977]
===
match
---
name: schedule_interval [36002,36019]
name: schedule_interval [36002,36019]
===
match
---
name: info [93870,93874]
name: info [93969,93973]
===
match
---
name: interval [24872,24880]
name: interval [24872,24880]
===
match
---
suite [31726,31761]
suite [31726,31761]
===
match
---
arglist [11778,11809]
arglist [11778,11809]
===
match
---
trailer [55880,55886]
trailer [55880,55886]
===
match
---
name: relationship [1501,1513]
name: relationship [1501,1513]
===
match
---
name: orm_dag [87045,87052]
name: orm_dag [87144,87151]
===
match
---
param [43729,43734]
param [43729,43734]
===
match
---
trailer [54950,54952]
trailer [54950,54952]
===
match
---
name: Optional [11364,11372]
name: Optional [11364,11372]
===
match
---
testlist_comp [59410,59428]
testlist_comp [59410,59428]
===
match
---
name: schedule_interval [15292,15309]
name: schedule_interval [15292,15309]
===
match
---
operator: @ [88770,88771]
operator: @ [88869,88870]
===
match
---
name: future [57249,57255]
name: future [57249,57255]
===
match
---
trailer [71275,71283]
trailer [71275,71283]
===
match
---
operator: = [74168,74169]
operator: = [74168,74169]
===
match
---
operator: , [57126,57127]
operator: , [57126,57127]
===
match
---
string: "DAG.full_filepath is deprecated in favour of fileloc" [30328,30382]
string: "DAG.full_filepath is deprecated in favour of fileloc" [30328,30382]
===
match
---
expr_stmt [61688,61722]
expr_stmt [61688,61722]
===
match
---
simple_stmt [93293,93324]
simple_stmt [93392,93423]
===
match
---
name: DEFAULT_VIEW_PRESETS [15875,15895]
name: DEFAULT_VIEW_PRESETS [15875,15895]
===
match
---
trailer [86345,86352]
trailer [86444,86451]
===
match
---
argument [65559,65574]
argument [65559,65574]
===
match
---
name: executors [79335,79344]
name: executors [79335,79344]
===
match
---
name: alive_dag_filelocs [101994,102012]
name: alive_dag_filelocs [102093,102111]
===
match
---
trailer [52898,52905]
trailer [52898,52905]
===
match
---
name: get [99305,99308]
name: get [99404,99407]
===
match
---
trailer [17461,17486]
trailer [17461,17486]
===
match
---
name: is_paused_upon_creation [85484,85507]
name: is_paused_upon_creation [85583,85606]
===
match
---
string: '_pickle_id' [92755,92767]
string: '_pickle_id' [92854,92866]
===
match
---
name: between [21603,21610]
name: between [21603,21610]
===
match
---
name: dags [84750,84754]
name: dags [84849,84853]
===
match
---
name: dttm [21265,21269]
name: dttm [21265,21269]
===
match
---
trailer [64454,64610]
trailer [64454,64610]
===
match
---
operator: = [97152,97153]
operator: = [97251,97252]
===
match
---
trailer [46445,46450]
trailer [46445,46450]
===
match
---
expr_stmt [21550,21611]
expr_stmt [21550,21611]
===
match
---
name: self [13777,13781]
name: self [13777,13781]
===
match
---
name: concurrency [30762,30773]
name: concurrency [30762,30773]
===
match
---
atom_expr [13856,13879]
atom_expr [13856,13879]
===
match
---
operator: , [73515,73516]
operator: , [73515,73516]
===
match
---
name: self [79622,79626]
name: self [79622,79626]
===
match
---
name: child [71946,71951]
name: child [71946,71951]
===
match
---
operator: { [61180,61181]
operator: { [61180,61181]
===
match
---
string: "Please use 'can_read' and 'can_edit', respectively." [20019,20072]
string: "Please use 'can_read' and 'can_edit', respectively." [20019,20072]
===
match
---
name: stacklevel [35628,35638]
name: stacklevel [35628,35638]
===
match
---
atom_expr [87896,87908]
atom_expr [87995,88007]
===
match
---
atom [58213,58222]
atom [58213,58222]
===
match
---
operator: ** [68937,68939]
operator: ** [68937,68939]
===
match
---
simple_stmt [44998,45082]
simple_stmt [44998,45082]
===
match
---
name: max_active_tasks [87549,87565]
name: max_active_tasks [87648,87664]
===
match
---
trailer [12845,12852]
trailer [12845,12852]
===
match
---
simple_stmt [68372,68393]
simple_stmt [68372,68393]
===
match
---
operator: == [34988,34990]
operator: == [34988,34990]
===
match
---
simple_stmt [24682,24696]
simple_stmt [24682,24696]
===
match
---
atom_expr [22168,22195]
atom_expr [22168,22195]
===
match
---
trailer [76918,76933]
trailer [76918,76933]
===
match
---
number: 1 [107868,107869]
number: 1 [107967,107968]
===
match
---
name: next_dagrun_data_interval_end [98473,98502]
name: next_dagrun_data_interval_end [98572,98601]
===
match
---
name: orm [1530,1533]
name: orm [1530,1533]
===
match
---
suite [70934,71003]
suite [70934,71003]
===
match
---
name: deepcopy [71290,71298]
name: deepcopy [71290,71298]
===
match
---
name: include_direct_upstream [71020,71043]
name: include_direct_upstream [71020,71043]
===
match
---
name: query [52889,52894]
name: query [52889,52894]
===
match
---
atom_expr [94053,94120]
atom_expr [94152,94219]
===
match
---
simple_stmt [85460,85508]
simple_stmt [85559,85607]
===
match
---
name: dry_run [65645,65652]
name: dry_run [65645,65652]
===
match
---
name: filter_query [101686,101698]
name: filter_query [101785,101797]
===
match
---
trailer [33495,33500]
trailer [33495,33500]
===
match
---
simple_stmt [21550,21612]
simple_stmt [21550,21612]
===
match
---
name: len [73425,73428]
name: len [73425,73428]
===
match
---
name: tis [48611,48614]
name: tis [48611,48614]
===
match
---
trailer [29311,29317]
trailer [29311,29317]
===
match
---
suite [97383,97665]
suite [97482,97764]
===
match
---
operator: { [58213,58214]
operator: { [58213,58214]
===
match
---
comparison [17774,17799]
comparison [17774,17799]
===
match
---
operator: , [66590,66591]
operator: , [66590,66591]
===
match
---
trailer [75412,75420]
trailer [75412,75420]
===
match
---
param [99381,99388]
param [99480,99487]
===
match
---
atom_expr [83105,83502]
atom_expr [83204,83601]
===
match
---
name: include_subdags [67992,68007]
name: include_subdags [67992,68007]
===
match
---
expr_stmt [83099,83502]
expr_stmt [83198,83601]
===
match
---
name: query [4035,4040]
name: query [4035,4040]
===
match
---
parameters [34817,34837]
parameters [34817,34837]
===
match
---
trailer [65699,65701]
trailer [65699,65701]
===
match
---
factor [89824,89860]
factor [89923,89959]
===
match
---
name: timedelta [992,1001]
name: timedelta [992,1001]
===
match
---
name: count [66315,66320]
name: count [66315,66320]
===
match
---
simple_stmt [72011,72056]
simple_stmt [72011,72056]
===
match
---
dotted_name [59214,59238]
dotted_name [59214,59238]
===
match
---
argument [88286,88298]
argument [88385,88397]
===
match
---
expr_stmt [85186,85240]
expr_stmt [85285,85339]
===
match
---
name: utc_epoch [44632,44641]
name: utc_epoch [44632,44641]
===
match
---
annassign [10547,10580]
annassign [10547,10580]
===
match
---
suite [62592,66424]
suite [62592,66424]
===
match
---
operator: , [18057,18058]
operator: , [18057,18058]
===
match
---
expr_stmt [68661,68714]
expr_stmt [68661,68714]
===
match
---
atom_expr [91776,91806]
atom_expr [91875,91905]
===
match
---
operator: , [17986,17987]
operator: , [17986,17987]
===
match
---
name: include_externally_triggered [3921,3949]
name: include_externally_triggered [3921,3949]
===
match
---
decorated [35693,36337]
decorated [35693,36337]
===
match
---
operator: = [11467,11468]
operator: = [11467,11468]
===
match
---
trailer [45072,45077]
trailer [45072,45077]
===
match
---
atom_expr [92038,92077]
atom_expr [92137,92176]
===
match
---
trailer [65722,65727]
trailer [65722,65727]
===
match
---
atom_expr [102609,102626]
atom_expr [102708,102725]
===
match
---
atom_expr [47070,47091]
atom_expr [47070,47091]
===
match
---
expr_stmt [95010,95052]
expr_stmt [95109,95151]
===
match
---
operator: , [32304,32305]
operator: , [32304,32305]
===
match
---
operator: = [94684,94685]
operator: = [94783,94784]
===
match
---
operator: = [24613,24614]
operator: = [24613,24614]
===
match
---
simple_stmt [71061,71093]
simple_stmt [71061,71093]
===
match
---
simple_stmt [48404,48538]
simple_stmt [48404,48538]
===
match
---
arglist [35812,35931]
arglist [35812,35931]
===
match
---
comparison [38628,38656]
comparison [38628,38656]
===
match
---
name: self [42009,42013]
name: self [42009,42013]
===
match
---
name: str [31976,31979]
name: str [31976,31979]
===
match
---
expr_stmt [61831,61888]
expr_stmt [61831,61888]
===
match
---
operator: , [47448,47449]
operator: , [47448,47449]
===
match
---
name: deepcopy [12645,12653]
name: deepcopy [12645,12653]
===
match
---
argument [101786,101799]
argument [101885,101898]
===
match
---
name: dag_id [38635,38641]
name: dag_id [38635,38641]
===
match
---
operator: = [57119,57120]
operator: = [57119,57120]
===
match
---
name: following [29361,29370]
name: following [29361,29370]
===
match
---
simple_stmt [92304,92371]
simple_stmt [92403,92470]
===
match
---
trailer [57651,57666]
trailer [57651,57666]
===
match
---
name: warn [30568,30572]
name: warn [30568,30572]
===
match
---
atom_expr [93300,93323]
atom_expr [93399,93422]
===
match
---
string: """         Returns the dag run for a given execution date or run_id if it exists, otherwise         none.          :param execution_date: The execution date of the DagRun to find.         :param run_id: The run_id of the DagRun to find.         :param session:         :return: The DagRun if found, otherwise None.         """ [39145,39472]
string: """         Returns the dag run for a given execution date or run_id if it exists, otherwise         none.          :param execution_date: The execution date of the DagRun to find.         :param run_id: The run_id of the DagRun to find.         :param session:         :return: The DagRun if found, otherwise None.         """ [39145,39472]
===
match
---
if_stmt [21620,21666]
if_stmt [21620,21666]
===
match
---
trailer [11417,11423]
trailer [11417,11423]
===
match
---
sync_comp_for [87651,87669]
sync_comp_for [87750,87768]
===
match
---
name: models [1944,1950]
name: models [1944,1950]
===
match
---
name: _type [18877,18882]
name: _type [18877,18882]
===
match
---
param [20931,20935]
param [20931,20935]
===
match
---
simple_stmt [21932,21978]
simple_stmt [21932,21978]
===
match
---
name: log [84721,84724]
name: log [84820,84823]
===
match
---
comparison [24936,24955]
comparison [24936,24955]
===
match
---
name: dag_id [35256,35262]
name: dag_id [35256,35262]
===
match
---
operator: = [71606,71607]
operator: = [71606,71607]
===
match
---
fstring_expr [61180,61193]
fstring_expr [61180,61193]
===
match
---
string: "TaskGroup" [32700,32711]
string: "TaskGroup" [32700,32711]
===
match
---
atom_expr [99835,99843]
atom_expr [99934,99942]
===
match
---
decorator [108915,108928]
decorator [109014,109027]
===
match
---
trailer [108623,108628]
trailer [108722,108727]
===
match
---
argument [53653,53676]
argument [53653,53676]
===
match
---
number: 2 [21086,21087]
number: 2 [21086,21087]
===
match
---
string: """         Triggers the appropriate callback depending on the value of success, namely the         on_failure_callback or on_success_callback. This method gets the context of a         single TaskInstance part of this DagRun and passes that to the callable along         with a 'reason', primarily to differentiate DagRun failures.          .. note: The logs end up in             ``$AIRFLOW_HOME/logs/scheduler/latest/PROJECT/DAG_FILE.py.log``          :param dagrun: DagRun object         :param success: Flag to specify if failure or success callback should be called         :param reason: Completion reason         :param session: Database session         """ [36447,37112]
string: """         Triggers the appropriate callback depending on the value of success, namely the         on_failure_callback or on_success_callback. This method gets the context of a         single TaskInstance part of this DagRun and passes that to the callable along         with a 'reason', primarily to differentiate DagRun failures.          .. note: The logs end up in             ``$AIRFLOW_HOME/logs/scheduler/latest/PROJECT/DAG_FILE.py.log``          :param dagrun: DagRun object         :param success: Flag to specify if failure or success callback should be called         :param reason: Completion reason         :param session: Database session         """ [36447,37112]
===
match
---
name: options [84920,84927]
name: options [85019,85026]
===
match
---
param [40939,40943]
param [40939,40943]
===
match
---
arglist [76055,76087]
arglist [76055,76087]
===
match
---
param [25397,25435]
param [25397,25435]
===
match
---
name: tasks [32453,32458]
name: tasks [32453,32458]
===
match
---
name: cls [109112,109115]
name: cls [109211,109214]
===
match
---
funcdef [92264,93324]
funcdef [92363,93423]
===
match
---
trailer [72765,72770]
trailer [72765,72770]
===
match
---
trailer [99444,99466]
trailer [99543,99565]
===
match
---
name: on_failure_callback [37178,37197]
name: on_failure_callback [37178,37197]
===
match
---
operator: @ [99146,99147]
operator: @ [99245,99246]
===
match
---
arglist [15332,15356]
arglist [15332,15356]
===
match
---
name: jinja2 [11258,11264]
name: jinja2 [11258,11264]
===
match
---
expr_stmt [57801,57850]
expr_stmt [57801,57850]
===
match
---
funcdef [38973,39909]
funcdef [38973,39909]
===
match
---
if_stmt [24869,24925]
if_stmt [24869,24925]
===
match
---
operator: , [2592,2593]
operator: , [2592,2593]
===
match
---
atom_expr [52927,52936]
atom_expr [52927,52936]
===
match
---
name: include_dependent_dags [45872,45894]
name: include_dependent_dags [45872,45894]
===
match
---
name: datetime [43754,43762]
name: datetime [43754,43762]
===
match
---
simple_stmt [107930,107991]
simple_stmt [108029,108090]
===
match
---
name: orm_tag [87999,88006]
name: orm_tag [88098,88105]
===
match
---
name: max_active_tasks [31253,31269]
name: max_active_tasks [31253,31269]
===
match
---
operator: } [16106,16107]
operator: } [16106,16107]
===
match
---
trailer [87525,87542]
trailer [87624,87641]
===
match
---
operator: , [50508,50509]
operator: , [50508,50509]
===
match
---
suite [13969,14016]
suite [13969,14016]
===
match
---
name: pathlib [849,856]
name: pathlib [849,856]
===
match
---
trailer [84749,84755]
trailer [84848,84854]
===
match
---
operator: = [26679,26680]
operator: = [26679,26680]
===
match
---
atom_expr [34280,34288]
atom_expr [34280,34288]
===
match
---
atom_expr [55448,55499]
atom_expr [55448,55499]
===
match
---
atom_expr [108615,108628]
atom_expr [108714,108727]
===
match
---
name: provide_session [36343,36358]
name: provide_session [36343,36358]
===
match
---
operator: = [17557,17558]
operator: = [17557,17558]
===
match
---
trailer [49755,49762]
trailer [49755,49762]
===
match
---
decorator [99480,99497]
decorator [99579,99596]
===
match
---
trailer [51998,52006]
trailer [51998,52006]
===
match
---
string: 'max_active_runs_per_dag' [11607,11632]
string: 'max_active_runs_per_dag' [11607,11632]
===
match
---
name: concurrency [31085,31096]
name: concurrency [31085,31096]
===
match
---
simple_stmt [2700,2755]
simple_stmt [2700,2755]
===
match
---
operator: = [11679,11680]
operator: = [11679,11680]
===
match
---
trailer [16565,16573]
trailer [16565,16573]
===
match
---
name: end_date [76401,76409]
name: end_date [76401,76409]
===
match
---
name: back [107469,107473]
name: back [107568,107572]
===
match
---
operator: = [86305,86306]
operator: = [86404,86405]
===
match
---
funcdef [29771,30050]
funcdef [29771,30050]
===
match
---
comp_op [24515,24521]
comp_op [24515,24521]
===
match
---
name: Exception [37629,37638]
name: Exception [37629,37638]
===
match
---
atom_expr [94264,94301]
atom_expr [94363,94400]
===
match
---
number: 2 [64594,64595]
number: 2 [64594,64595]
===
match
---
param [83833,83845]
param [83932,83944]
===
match
---
name: self [12905,12909]
name: self [12905,12909]
===
match
---
name: tis [49934,49937]
name: tis [49934,49937]
===
match
---
or_test [12696,12708]
or_test [12696,12708]
===
match
---
operator: = [35928,35929]
operator: = [35928,35929]
===
match
---
name: Column [1393,1399]
name: Column [1393,1399]
===
match
---
atom [85137,85177]
atom [85236,85276]
===
match
---
name: all [89862,89865]
name: all [89961,89964]
===
match
---
operator: = [109204,109205]
operator: = [109303,109304]
===
match
---
dictorsetmaker [33752,33779]
dictorsetmaker [33752,33779]
===
match
---
operator: = [33994,33995]
operator: = [33994,33995]
===
match
---
parameters [98783,98833]
parameters [98882,98932]
===
match
---
atom_expr [109001,109025]
atom_expr [109100,109124]
===
match
---
name: task_id [70629,70636]
name: task_id [70629,70636]
===
match
---
simple_stmt [21432,21466]
simple_stmt [21432,21466]
===
match
---
name: filter [40848,40854]
name: filter [40848,40854]
===
match
---
expr_stmt [39804,39879]
expr_stmt [39804,39879]
===
match
---
expr_stmt [14824,14877]
expr_stmt [14824,14877]
===
match
---
name: query [61731,61736]
name: query [61731,61736]
===
match
---
name: _upgrade_outdated_dag_access_control [31541,31577]
name: _upgrade_outdated_dag_access_control [31541,31577]
===
match
---
operator: = [49750,49751]
operator: = [49750,49751]
===
match
---
trailer [93728,93732]
trailer [93827,93831]
===
match
---
name: iter_dagrun_infos_between [25348,25373]
name: iter_dagrun_infos_between [25348,25373]
===
match
---
simple_stmt [16263,16433]
simple_stmt [16263,16433]
===
match
---
decorated [75313,75437]
decorated [75313,75437]
===
match
---
expr_stmt [49584,49630]
expr_stmt [49584,49630]
===
match
---
operator: , [54377,54378]
operator: , [54377,54378]
===
match
---
name: task_ids_or_regex [57680,57697]
name: task_ids_or_regex [57680,57697]
===
match
---
name: Set [99835,99838]
name: Set [99934,99937]
===
match
---
operator: , [41188,41189]
operator: , [41188,41189]
===
match
---
suite [71044,71093]
suite [71044,71093]
===
match
---
name: query [39804,39809]
name: query [39804,39809]
===
match
---
suite [77031,77243]
suite [77031,77243]
===
match
---
name: provide_session [34780,34795]
name: provide_session [34780,34795]
===
match
---
operator: = [16574,16575]
operator: = [16574,16575]
===
match
---
operator: = [80358,80359]
operator: = [80358,80359]
===
match
---
name: getint [11512,11518]
name: getint [11512,11518]
===
match
---
atom_expr [103628,103948]
atom_expr [103727,104047]
===
match
---
operator: @ [43669,43670]
operator: @ [43669,43670]
===
match
---
operator: = [94121,94122]
operator: = [94220,94221]
===
match
---
operator: , [64783,64784]
operator: , [64783,64784]
===
match
---
atom_expr [61515,61679]
atom_expr [61515,61679]
===
match
---
expr_stmt [71061,71092]
expr_stmt [71061,71092]
===
match
---
trailer [108806,108837]
trailer [108905,108936]
===
match
---
atom_expr [61986,62050]
atom_expr [61986,62050]
===
match
---
name: DagRunState [3158,3169]
name: DagRunState [3158,3169]
===
match
---
trailer [100705,100711]
trailer [100804,100810]
===
match
---
name: get [11852,11855]
name: get [11852,11855]
===
match
---
atom_expr [14422,14439]
atom_expr [14422,14439]
===
match
---
param [12043,12104]
param [12043,12104]
===
match
---
param [20236,20257]
param [20236,20257]
===
match
---
operator: , [98820,98821]
operator: , [98919,98920]
===
match
---
name: relative_fileloc [100830,100846]
name: relative_fileloc [100929,100945]
===
match
---
name: dag_tag_orm [88265,88276]
name: dag_tag_orm [88364,88375]
===
match
---
if_stmt [14608,14815]
if_stmt [14608,14815]
===
match
---
tfpdef [47063,47091]
tfpdef [47063,47091]
===
match
---
number: 1 [10985,10986]
number: 1 [10985,10986]
===
match
---
name: Tuple [98806,98811]
name: Tuple [98905,98910]
===
match
---
comparison [18145,18171]
comparison [18145,18171]
===
match
---
name: task [58448,58452]
name: task [58448,58452]
===
match
---
name: sla_miss_callback [15810,15827]
name: sla_miss_callback [15810,15827]
===
match
---
param [77555,77579]
param [77555,77579]
===
match
---
operator: , [1411,1412]
operator: , [1411,1412]
===
match
---
trailer [91517,91525]
trailer [91616,91624]
===
match
---
name: task_ids [65197,65205]
name: task_ids [65197,65205]
===
match
---
operator: = [13201,13202]
operator: = [13201,13202]
===
match
---
comp_if [49716,49720]
comp_if [49716,49720]
===
match
---
name: all [100233,100236]
name: all [100332,100335]
===
match
---
operator: = [36068,36069]
operator: = [36068,36069]
===
match
---
simple_stmt [104888,104947]
simple_stmt [104987,105046]
===
match
---
simple_stmt [13188,13210]
simple_stmt [13188,13210]
===
match
---
arglist [14622,14656]
arglist [14622,14656]
===
match
---
name: String [96122,96128]
name: String [96221,96227]
===
match
---
name: current [21432,21439]
name: current [21432,21439]
===
match
---
if_stmt [60624,60689]
if_stmt [60624,60689]
===
match
---
if_stmt [53177,53258]
if_stmt [53177,53258]
===
match
---
funcdef [98034,98711]
funcdef [98133,98810]
===
match
---
argument [65294,65305]
argument [65294,65305]
===
match
---
trailer [85915,85922]
trailer [86014,86021]
===
match
---
number: 0 [42628,42629]
number: 0 [42628,42629]
===
match
---
tfpdef [11828,11844]
tfpdef [11828,11844]
===
match
---
name: matched_tasks [71357,71370]
name: matched_tasks [71357,71370]
===
match
---
if_stmt [74601,74715]
if_stmt [74601,74715]
===
match
---
name: orm_dag [87297,87304]
name: orm_dag [87396,87403]
===
match
---
name: Optional [98073,98081]
name: Optional [98172,98180]
===
match
---
expr_stmt [37306,37339]
expr_stmt [37306,37339]
===
match
---
name: stacklevel [13473,13483]
name: stacklevel [13473,13483]
===
match
---
operator: ** [42834,42836]
operator: ** [42834,42836]
===
match
---
name: tis [49940,49943]
name: tis [49940,49943]
===
match
---
trailer [62368,62375]
trailer [62368,62375]
===
match
---
trailer [25527,25539]
trailer [25527,25539]
===
match
---
trailer [85467,85477]
trailer [85566,85576]
===
match
---
simple_stmt [67529,67627]
simple_stmt [67529,67627]
===
match
---
expr_stmt [96100,96133]
expr_stmt [96199,96232]
===
match
---
trailer [11773,11777]
trailer [11773,11777]
===
match
---
name: is_paused [101291,101300]
name: is_paused [101390,101399]
===
match
---
simple_stmt [39528,39604]
simple_stmt [39528,39604]
===
match
---
trailer [53068,53074]
trailer [53068,53074]
===
match
---
name: max_active_runs [104963,104978]
name: max_active_runs [105062,105077]
===
match
---
name: downstream [55820,55830]
name: downstream [55820,55830]
===
match
---
name: all [90536,90539]
name: all [90635,90638]
===
match
---
name: session [102461,102468]
name: session [102560,102567]
===
match
---
name: int [31812,31815]
name: int [31812,31815]
===
match
---
suite [37575,37610]
suite [37575,37610]
===
match
---
atom_expr [53409,53461]
atom_expr [53409,53461]
===
match
---
operator: , [66650,66651]
operator: , [66650,66651]
===
match
---
atom_expr [41064,41257]
atom_expr [41064,41257]
===
match
---
name: latest [26664,26670]
name: latest [26664,26670]
===
match
---
simple_stmt [58561,58661]
simple_stmt [58561,58661]
===
match
---
atom_expr [17328,17384]
atom_expr [17328,17384]
===
match
---
name: provide_session [89983,89998]
name: provide_session [90082,90097]
===
match
---
simple_stmt [12620,12674]
simple_stmt [12620,12674]
===
match
---
atom_expr [27755,27810]
atom_expr [27755,27810]
===
match
---
name: DagContext [18906,18916]
name: DagContext [18906,18916]
===
match
---
name: values [60545,60551]
name: values [60545,60551]
===
match
---
atom_expr [42057,42083]
atom_expr [42057,42083]
===
match
---
name: task_dict [73856,73865]
name: task_dict [73856,73865]
===
match
---
string: 'start_date' [14309,14321]
string: 'start_date' [14309,14321]
===
match
---
if_stmt [82230,82885]
if_stmt [82230,82984]
===
match
---
name: self [55686,55690]
name: self [55686,55690]
===
match
---
operator: = [21482,21483]
operator: = [21482,21483]
===
match
---
name: _task_group [70402,70413]
name: _task_group [70402,70413]
===
match
---
operator: = [35885,35886]
operator: = [35885,35886]
===
match
---
trailer [18257,18264]
trailer [18257,18264]
===
match
---
sync_comp_for [91942,91970]
sync_comp_for [92041,92069]
===
match
---
operator: , [73612,73613]
operator: , [73612,73613]
===
match
---
atom_expr [36087,36109]
atom_expr [36087,36109]
===
match
---
simple_stmt [52026,52041]
simple_stmt [52026,52041]
===
match
---
import_from [1878,1930]
import_from [1878,1930]
===
match
---
parameters [31619,31625]
parameters [31619,31625]
===
match
---
name: print [68175,68180]
name: print [68175,68180]
===
match
---
name: only_failed [58080,58091]
name: only_failed [58080,58091]
===
match
---
suite [43847,44741]
suite [43847,44741]
===
match
---
name: key [55077,55080]
name: key [55077,55080]
===
match
---
name: latest [24737,24743]
name: latest [24737,24743]
===
match
---
operator: = [67059,67060]
operator: = [67059,67060]
===
match
---
trailer [55044,55172]
trailer [55044,55172]
===
match
---
name: DagRun [83105,83111]
name: DagRun [83204,83210]
===
match
---
argument [83227,83248]
argument [83326,83347]
===
match
---
operator: , [86443,86444]
operator: , [86542,86543]
===
match
---
name: bool [55881,55885]
name: bool [55881,55885]
===
match
---
operator: , [83343,83344]
operator: , [83442,83443]
===
match
---
import_from [51249,51309]
import_from [51249,51309]
===
match
---
suite [53192,53258]
suite [53192,53258]
===
match
---
name: bool [45896,45900]
name: bool [45896,45900]
===
match
---
parameters [29787,29842]
parameters [29787,29842]
===
match
---
arglist [100791,100805]
arglist [100890,100904]
===
match
---
operator: , [84236,84237]
operator: , [84335,84336]
===
match
---
name: int [20280,20283]
name: int [20280,20283]
===
match
---
name: DagRun [37956,37962]
name: DagRun [37956,37962]
===
match
---
name: between [21474,21481]
name: between [21474,21481]
===
match
---
trailer [24549,24556]
trailer [24549,24556]
===
match
---
raise_stmt [98246,98596]
raise_stmt [98345,98695]
===
match
---
trailer [22074,22083]
trailer [22074,22083]
===
match
---
simple_stmt [34325,34370]
simple_stmt [34325,34370]
===
match
---
name: utcnow [87333,87339]
name: utcnow [87432,87438]
===
match
---
comparison [14977,15010]
comparison [14977,15010]
===
match
---
arith_expr [74224,74248]
arith_expr [74224,74248]
===
match
---
name: following_schedule [29293,29311]
name: following_schedule [29293,29311]
===
match
---
trailer [12327,12333]
trailer [12327,12333]
===
match
---
atom_expr [100190,100218]
atom_expr [100289,100317]
===
match
---
operator: = [76795,76796]
operator: = [76795,76796]
===
match
---
name: subdag [41936,41942]
name: subdag [41936,41942]
===
match
---
name: get_flat_relatives [70969,70987]
name: get_flat_relatives [70969,70987]
===
match
---
expr_stmt [88094,88140]
expr_stmt [88193,88239]
===
match
---
trailer [104800,104814]
trailer [104899,104913]
===
match
---
atom [68526,68591]
atom [68526,68591]
===
match
---
simple_stmt [68893,68907]
simple_stmt [68893,68907]
===
match
---
simple_stmt [67424,67433]
simple_stmt [67424,67433]
===
match
---
dotted_name [30486,30506]
dotted_name [30486,30506]
===
match
---
param [104101,104106]
param [104200,104205]
===
match
---
operator: = [95567,95568]
operator: = [95666,95667]
===
match
---
simple_stmt [31022,31052]
simple_stmt [31022,31052]
===
match
---
param [102025,102037]
param [102124,102136]
===
match
---
if_stmt [14526,14815]
if_stmt [14526,14815]
===
match
---
suite [43271,43330]
suite [43271,43330]
===
match
---
name: jinja2 [1240,1246]
name: jinja2 [1240,1246]
===
match
---
name: partial [73458,73465]
name: partial [73458,73465]
===
match
---
suite [36438,37775]
suite [36438,37775]
===
match
---
parameters [73993,73999]
parameters [73993,73999]
===
match
---
atom_expr [44944,44961]
atom_expr [44944,44961]
===
match
---
name: start_date [14866,14876]
name: start_date [14866,14876]
===
match
---
name: task [57121,57125]
name: task [57121,57125]
===
match
---
operator: = [66507,66508]
operator: = [66507,66508]
===
match
---
expr_stmt [106710,106753]
expr_stmt [106809,106852]
===
match
---
name: self [31224,31228]
name: self [31224,31228]
===
match
---
trailer [86759,86766]
trailer [86858,86865]
===
match
---
atom_expr [73408,73422]
atom_expr [73408,73422]
===
match
---
sync_comp_for [33760,33779]
sync_comp_for [33760,33779]
===
match
---
atom_expr [91548,91567]
atom_expr [91647,91666]
===
match
---
name: Set [47430,47433]
name: Set [47430,47433]
===
match
---
param [11207,11281]
param [11207,11281]
===
match
---
name: dumps [74128,74133]
name: dumps [74128,74133]
===
match
---
if_stmt [39650,39773]
if_stmt [39650,39773]
===
match
---
name: run_id [82376,82382]
name: run_id [82400,82406]
===
match
---
argument [35877,35904]
argument [35877,35904]
===
match
---
name: clear_task_instances [66136,66156]
name: clear_task_instances [66136,66156]
===
match
---
name: max_recursion_depth [47367,47386]
name: max_recursion_depth [47367,47386]
===
match
---
suite [87963,88008]
suite [88062,88107]
===
match
---
name: session [37503,37510]
name: session [37503,37510]
===
match
---
simple_stmt [29462,29479]
simple_stmt [29462,29479]
===
match
---
suite [91609,91706]
suite [91708,91805]
===
match
---
name: latest [24606,24612]
name: latest [24606,24612]
===
match
---
operator: , [53017,53018]
operator: , [53017,53018]
===
match
---
tfpdef [47132,47155]
tfpdef [47132,47155]
===
match
---
operator: , [53891,53892]
operator: , [53891,53892]
===
match
---
return_stmt [38122,38141]
return_stmt [38122,38141]
===
match
---
atom_expr [24501,24514]
atom_expr [24501,24514]
===
match
---
name: session [85086,85093]
name: session [85185,85192]
===
match
---
name: dag [73280,73283]
name: dag [73280,73283]
===
match
---
name: EdgeInfoType [3221,3233]
name: EdgeInfoType [3221,3233]
===
match
---
tfpdef [55778,55802]
tfpdef [55778,55802]
===
match
---
name: resolve_template_files [42059,42081]
name: resolve_template_files [42059,42081]
===
match
---
param [97969,97973]
param [98068,98072]
===
match
---
trailer [74153,74167]
trailer [74153,74167]
===
match
---
if_stmt [17771,18016]
if_stmt [17771,18016]
===
match
---
name: update [43296,43302]
name: update [43296,43302]
===
match
---
operator: , [28041,28042]
operator: , [28041,28042]
===
match
---
name: query [39895,39900]
name: query [39895,39900]
===
match
---
name: t [42057,42058]
name: t [42057,42058]
===
match
---
simple_stmt [17522,17589]
simple_stmt [17522,17589]
===
match
---
name: filter [38787,38793]
name: filter [38787,38793]
===
match
---
string: 'webserver' [89262,89273]
string: 'webserver' [89361,89372]
===
match
---
atom_expr [73931,73972]
atom_expr [73931,73972]
===
match
---
name: upstream [57192,57200]
name: upstream [57192,57200]
===
match
---
decorated [32662,32745]
decorated [32662,32745]
===
match
---
operator: < [73423,73424]
operator: < [73423,73424]
===
match
---
string: """Returns a list of the subdag objects associated to this DAG""" [41352,41417]
string: """Returns a list of the subdag objects associated to this DAG""" [41352,41417]
===
match
---
name: datetime [80944,80952]
name: datetime [80944,80952]
===
match
---
name: start_date [61373,61383]
name: start_date [61373,61383]
===
match
---
expr_stmt [76961,76998]
expr_stmt [76961,76998]
===
match
---
name: tuple [18384,18389]
name: tuple [18384,18389]
===
match
---
name: classmethod [83746,83757]
name: classmethod [83845,83856]
===
match
---
fstring_string: ;  [98505,98507]
fstring_string: ;  [98604,98606]
===
match
---
trailer [19626,19642]
trailer [19626,19642]
===
match
---
trailer [74815,74819]
trailer [74815,74819]
===
match
---
operator: = [76049,76050]
operator: = [76049,76050]
===
match
---
suite [106137,107774]
suite [106236,107873]
===
match
---
comparison [97325,97354]
comparison [97424,97453]
===
match
---
name: self [68834,68838]
name: self [68834,68838]
===
match
---
name: int [104187,104190]
name: int [104286,104289]
===
match
---
return_stmt [107783,107797]
return_stmt [107882,107896]
===
match
---
name: FAILED [64901,64907]
name: FAILED [64901,64907]
===
match
---
atom_expr [38781,38915]
atom_expr [38781,38915]
===
match
---
name: dttm [29104,29108]
name: dttm [29104,29108]
===
match
---
try_stmt [33206,33363]
try_stmt [33206,33363]
===
match
---
name: include_dependent_dags [50700,50722]
name: include_dependent_dags [50700,50722]
===
match
---
trailer [67670,67680]
trailer [67670,67680]
===
match
---
trailer [91498,91504]
trailer [91597,91603]
===
match
---
operator: , [66535,66536]
operator: , [66535,66536]
===
match
---
trailer [14185,14198]
trailer [14185,14198]
===
match
---
operator: , [103831,103832]
operator: , [103930,103931]
===
match
---
name: dp [74583,74585]
name: dp [74583,74585]
===
match
---
name: int [80883,80886]
name: int [80883,80886]
===
match
---
trailer [87076,87082]
trailer [87175,87181]
===
match
---
name: jinja2 [1317,1323]
name: jinja2 [1317,1323]
===
match
---
name: info [85554,85558]
name: info [85653,85657]
===
match
---
operator: , [77545,77546]
operator: , [77545,77546]
===
match
---
trailer [87663,87669]
trailer [87762,87768]
===
match
---
name: ScheduleInterval [35758,35774]
name: ScheduleInterval [35758,35774]
===
match
---
operator: = [91626,91627]
operator: = [91725,91726]
===
match
---
atom_expr [80326,80364]
atom_expr [80326,80364]
===
match
---
simple_stmt [51379,51455]
simple_stmt [51379,51455]
===
match
---
param [22126,22131]
param [22126,22131]
===
match
---
name: ForeignKey [94338,94348]
name: ForeignKey [94437,94447]
===
match
---
atom_expr [53720,54631]
atom_expr [53720,54631]
===
match
---
name: info [27200,27204]
name: info [27200,27204]
===
match
---
name: Session [39113,39120]
name: Session [39113,39120]
===
match
---
name: dag_id [55390,55396]
name: dag_id [55390,55396]
===
match
---
simple_stmt [30192,30213]
simple_stmt [30192,30213]
===
match
---
name: start_date [28822,28832]
name: start_date [28822,28832]
===
match
---
name: signature [1022,1031]
name: signature [1022,1031]
===
match
---
atom_expr [109179,109203]
atom_expr [109278,109302]
===
match
---
operator: , [66562,66563]
operator: , [66562,66563]
===
match
---
name: visited_external_tis [51870,51890]
name: visited_external_tis [51870,51890]
===
match
---
operator: = [62041,62042]
operator: = [62041,62042]
===
match
---
param [101340,101352]
param [101439,101451]
===
match
---
name: DagRun [39855,39861]
name: DagRun [39855,39861]
===
match
---
name: DeprecationWarning [30654,30672]
name: DeprecationWarning [30654,30672]
===
match
---
comparison [40531,40564]
comparison [40531,40564]
===
match
---
parameters [18189,18195]
parameters [18189,18195]
===
match
---
name: warn [20820,20824]
name: warn [20820,20824]
===
match
---
trailer [83564,83568]
trailer [83663,83667]
===
match
---
not_test [29357,29370]
not_test [29357,29370]
===
match
---
name: state [91936,91941]
name: state [92035,92040]
===
match
---
trailer [72017,72032]
trailer [72017,72032]
===
match
---
simple_stmt [64655,64829]
simple_stmt [64655,64829]
===
match
---
operator: = [26477,26478]
operator: = [26477,26478]
===
match
---
operator: = [21508,21509]
operator: = [21508,21509]
===
match
---
atom_expr [74644,74714]
atom_expr [74644,74714]
===
match
---
name: only_running [66572,66584]
name: only_running [66572,66584]
===
match
---
trailer [26501,26510]
trailer [26501,26510]
===
match
---
trailer [21690,21704]
trailer [21690,21704]
===
match
---
subscriptlist [98088,98106]
subscriptlist [98187,98205]
===
match
---
name: DagRun [44411,44417]
name: DagRun [44411,44417]
===
match
---
trailer [86311,86634]
trailer [86410,86733]
===
match
---
operator: -> [47475,47477]
operator: -> [47475,47477]
===
match
---
name: DeprecationWarning [21851,21869]
name: DeprecationWarning [21851,21869]
===
match
---
operator: = [37502,37503]
operator: = [37502,37503]
===
match
---
decorator [33528,33538]
decorator [33528,33538]
===
match
---
trailer [76942,76950]
trailer [76942,76950]
===
match
---
expr_stmt [41917,41950]
expr_stmt [41917,41950]
===
match
---
name: session [29935,29942]
name: session [29935,29942]
===
match
---
simple_stmt [17198,17266]
simple_stmt [17198,17266]
===
match
---
trailer [95910,95916]
trailer [96009,96015]
===
match
---
atom_expr [84883,85021]
atom_expr [84982,85120]
===
match
---
trailer [37473,37494]
trailer [37473,37494]
===
match
---
name: timezone [24338,24346]
name: timezone [24338,24346]
===
match
---
trailer [86618,86622]
trailer [86717,86721]
===
match
---
trailer [53769,53789]
trailer [53769,53789]
===
match
---
operator: , [45167,45168]
operator: , [45167,45168]
===
match
---
name: Path [100873,100877]
name: Path [100972,100976]
===
match
---
name: Column [95217,95223]
name: Column [95316,95322]
===
match
---
name: user_defined_filters [12568,12588]
name: user_defined_filters [12568,12588]
===
match
---
suite [40001,40633]
suite [40001,40633]
===
match
---
simple_stmt [70748,70766]
simple_stmt [70748,70766]
===
match
---
name: keys [72766,72770]
name: keys [72766,72770]
===
match
---
trailer [73248,73266]
trailer [73248,73266]
===
match
---
name: orm_dag [86896,86903]
name: orm_dag [86995,87002]
===
match
---
param [80661,80702]
param [80661,80702]
===
match
---
operator: , [66904,66905]
operator: , [66904,66905]
===
match
---
funcdef [29526,29745]
funcdef [29526,29745]
===
match
---
name: _max_active_tasks [31034,31051]
name: _max_active_tasks [31034,31051]
===
match
---
operator: = [97721,97722]
operator: = [97820,97821]
===
match
---
atom_expr [50401,51108]
atom_expr [50401,51108]
===
match
---
trailer [51542,51549]
trailer [51542,51549]
===
match
---
simple_stmt [80373,80400]
simple_stmt [80373,80400]
===
match
---
arglist [68642,68649]
arglist [68642,68649]
===
match
---
atom_expr [89825,89860]
atom_expr [89924,89959]
===
match
---
simple_stmt [80159,80169]
simple_stmt [80159,80169]
===
match
---
name: schedule_interval [33901,33918]
name: schedule_interval [33901,33918]
===
match
---
name: session [34184,34191]
name: session [34184,34191]
===
match
---
trailer [104035,104052]
trailer [104134,104151]
===
match
---
name: task_dict [72961,72970]
name: task_dict [72961,72970]
===
match
---
atom_expr [90804,90822]
atom_expr [90903,90921]
===
match
---
try_stmt [21915,22033]
try_stmt [21915,22033]
===
match
---
operator: = [94948,94949]
operator: = [95047,95048]
===
match
---
if_stmt [57387,57429]
if_stmt [57387,57429]
===
match
---
operator: @ [32567,32568]
operator: @ [32567,32568]
===
match
---
comparison [15859,15895]
comparison [15859,15895]
===
match
---
suite [108790,108871]
suite [108889,108970]
===
match
---
name: property [32751,32759]
name: property [32751,32759]
===
match
---
atom_expr [20332,20349]
atom_expr [20332,20349]
===
match
---
atom_expr [101125,101145]
atom_expr [101224,101244]
===
match
---
trailer [74173,74182]
trailer [74173,74182]
===
match
---
operator: = [62166,62167]
operator: = [62166,62167]
===
match
---
param [66483,66488]
param [66483,66488]
===
match
---
trailer [58698,58704]
trailer [58698,58704]
===
match
---
name: session [91480,91487]
name: session [91579,91586]
===
match
---
simple_stmt [100764,100807]
simple_stmt [100863,100906]
===
match
---
name: iter_dagrun_infos_between [29025,29050]
name: iter_dagrun_infos_between [29025,29050]
===
match
---
funcdef [108932,109234]
funcdef [109031,109333]
===
match
---
atom_expr [18145,18156]
atom_expr [18145,18156]
===
match
---
name: isinstance [35953,35963]
name: isinstance [35953,35963]
===
match
---
name: bind_partial [106033,106045]
name: bind_partial [106132,106144]
===
match
---
atom_expr [51972,52008]
atom_expr [51972,52008]
===
match
---
operator: , [35904,35905]
operator: , [35904,35905]
===
match
---
atom_expr [76051,76088]
atom_expr [76051,76088]
===
match
---
decorated [36342,37775]
decorated [36342,37775]
===
match
---
atom_expr [39825,39838]
atom_expr [39825,39838]
===
match
---
simple_stmt [89329,89354]
simple_stmt [89428,89453]
===
match
---
simple_stmt [61831,61889]
simple_stmt [61831,61889]
===
match
---
decorated [31854,31949]
decorated [31854,31949]
===
match
---
name: template_searchpath [15450,15469]
name: template_searchpath [15450,15469]
===
match
---
name: Dict [1106,1110]
name: Dict [1106,1110]
===
match
---
trailer [27221,27238]
trailer [27221,27238]
===
match
---
operator: , [89273,89274]
operator: , [89372,89373]
===
match
---
trailer [42493,42505]
trailer [42493,42505]
===
match
---
operator: , [77654,77655]
operator: , [77654,77655]
===
match
---
argument [32277,32293]
argument [32277,32293]
===
match
---
operator: , [86696,86697]
operator: , [86795,86796]
===
match
---
operator: = [65334,65335]
operator: = [65334,65335]
===
match
---
atom_expr [101901,101917]
atom_expr [102000,102016]
===
match
---
argument [58010,58030]
argument [58010,58030]
===
match
---
operator: = [32288,32289]
operator: = [32288,32289]
===
match
---
name: state [49809,49814]
name: state [49809,49814]
===
match
---
name: BaseOperator [58301,58313]
name: BaseOperator [58301,58313]
===
match
---
parameters [31096,31114]
parameters [31096,31114]
===
match
---
trailer [54831,54877]
trailer [54831,54877]
===
match
---
operator: = [13483,13484]
operator: = [13483,13484]
===
match
---
name: run_id [83164,83170]
name: run_id [83263,83269]
===
match
---
operator: -> [30086,30088]
operator: -> [30086,30088]
===
match
---
name: DagRunInfo [22215,22225]
name: DagRunInfo [22215,22225]
===
match
---
trailer [57029,57038]
trailer [57029,57038]
===
match
---
name: str [93865,93868]
name: str [93964,93967]
===
match
---
name: timetable [21140,21149]
name: timetable [21140,21149]
===
match
---
name: DagRun [44313,44319]
name: DagRun [44313,44319]
===
match
---
string: 'parent_dag' [10379,10391]
string: 'parent_dag' [10379,10391]
===
match
---
argument [99652,99709]
argument [99751,99808]
===
match
---
name: dag_id [99449,99455]
name: dag_id [99548,99554]
===
match
---
operator: , [49225,49226]
operator: , [49225,49226]
===
match
---
name: cls [84133,84136]
name: cls [84232,84235]
===
match
---
operator: = [47354,47355]
operator: = [47354,47355]
===
match
---
trailer [87241,87247]
trailer [87340,87346]
===
match
---
atom_expr [47434,47459]
atom_expr [47434,47459]
===
match
---
return_stmt [74410,74418]
return_stmt [74410,74418]
===
match
---
trailer [13749,13759]
trailer [13749,13759]
===
match
---
expr_stmt [3397,3475]
expr_stmt [3397,3475]
===
match
---
atom_expr [32361,32379]
atom_expr [32361,32379]
===
match
---
name: hash_components [18669,18684]
name: hash_components [18669,18684]
===
match
---
trailer [72262,72271]
trailer [72262,72271]
===
match
---
name: id [68440,68442]
name: id [68440,68442]
===
match
---
funcdef [33015,33363]
funcdef [33015,33363]
===
match
---
name: dags [67723,67727]
name: dags [67723,67727]
===
match
---
name: Boolean [96411,96418]
name: Boolean [96510,96517]
===
match
---
name: creating_job_id [80857,80872]
name: creating_job_id [80857,80872]
===
match
---
trailer [71078,71092]
trailer [71078,71092]
===
match
---
name: airflow [56949,56956]
name: airflow [56949,56956]
===
match
---
trailer [85651,85658]
trailer [85750,85757]
===
match
---
return_stmt [89329,89353]
return_stmt [89428,89452]
===
match
---
trailer [46155,46175]
trailer [46155,46175]
===
match
---
simple_stmt [15478,15523]
simple_stmt [15478,15523]
===
match
---
param [83808,83832]
param [83907,83931]
===
match
---
simple_stmt [104526,104587]
simple_stmt [104625,104686]
===
match
---
name: upstream_task_id [93707,93723]
name: upstream_task_id [93806,93822]
===
match
---
trailer [94328,94336]
trailer [94427,94435]
===
match
---
name: include_dependent_dags [65413,65435]
name: include_dependent_dags [65413,65435]
===
match
---
trailer [14308,14322]
trailer [14308,14322]
===
match
---
arith_expr [92449,93284]
arith_expr [92548,93383]
===
match
---
atom_expr [76961,76976]
atom_expr [76961,76976]
===
match
---
simple_stmt [55228,55242]
simple_stmt [55228,55242]
===
match
---
name: is_subdag [16477,16486]
name: is_subdag [16477,16486]
===
match
---
trailer [52944,52960]
trailer [52944,52960]
===
match
---
sync_comp_for [54933,54952]
sync_comp_for [54933,54952]
===
match
---
trailer [41880,41887]
trailer [41880,41887]
===
match
---
string: 'duration' [3438,3448]
string: 'duration' [3438,3448]
===
match
---
atom_expr [88279,88318]
atom_expr [88378,88417]
===
match
---
name: TimeRestriction [24711,24726]
name: TimeRestriction [24711,24726]
===
match
---
argument [99635,99650]
argument [99734,99749]
===
match
---
name: session [37495,37502]
name: session [37495,37502]
===
match
---
suite [22227,23610]
suite [22227,23610]
===
match
---
name: self [98000,98004]
name: self [98099,98103]
===
match
---
trailer [70987,71002]
trailer [70987,71002]
===
match
---
return_stmt [55612,55622]
return_stmt [55612,55622]
===
match
---
atom_expr [70436,70461]
atom_expr [70436,70461]
===
match
---
name: stacklevel [30428,30438]
name: stacklevel [30428,30438]
===
match
---
operator: , [55894,55895]
operator: , [55894,55895]
===
match
---
trailer [74811,74815]
trailer [74811,74815]
===
match
---
atom_expr [84779,84789]
atom_expr [84878,84888]
===
match
---
name: data_interval [83464,83477]
name: data_interval [83563,83576]
===
match
---
trailer [84782,84789]
trailer [84881,84888]
===
match
---
name: parent_group [71670,71682]
name: parent_group [71670,71682]
===
match
---
atom_expr [62554,62568]
atom_expr [62554,62568]
===
match
---
testlist_comp [96833,96972]
testlist_comp [96932,97071]
===
match
---
trailer [61044,61071]
trailer [61044,61071]
===
match
---
name: Integer [95650,95657]
name: Integer [95749,95756]
===
match
---
name: max_recursion_depth [46737,46756]
name: max_recursion_depth [46737,46756]
===
match
---
name: t [73314,73315]
name: t [73314,73315]
===
match
---
trailer [27501,27510]
trailer [27501,27510]
===
match
---
name: dag_obj [107367,107374]
name: dag_obj [107466,107473]
===
match
---
name: str [39074,39077]
name: str [39074,39077]
===
match
---
funcdef [36363,37775]
funcdef [36363,37775]
===
match
---
name: self [61290,61294]
name: self [61290,61294]
===
match
---
name: __dict__ [68484,68492]
name: __dict__ [68484,68492]
===
match
---
decorated [31590,31677]
decorated [31590,31677]
===
match
---
name: dagrun_timeout [15765,15779]
name: dagrun_timeout [15765,15779]
===
match
---
suite [44599,44644]
suite [44599,44644]
===
match
---
trailer [34544,34549]
trailer [34544,34549]
===
match
---
trailer [86581,86590]
trailer [86680,86689]
===
match
---
operator: -> [32600,32602]
operator: -> [32600,32602]
===
match
---
if_stmt [44579,44644]
if_stmt [44579,44644]
===
match
---
atom_expr [16472,16486]
atom_expr [16472,16486]
===
match
---
name: filter [91838,91844]
name: filter [91937,91943]
===
match
---
param [66693,66726]
param [66693,66726]
===
match
---
atom_expr [93688,93756]
atom_expr [93787,93855]
===
match
---
atom_expr [64909,64930]
atom_expr [64909,64930]
===
match
---
expr_stmt [73224,73301]
expr_stmt [73224,73301]
===
match
---
simple_stmt [34736,34774]
simple_stmt [34736,34774]
===
match
---
argument [50448,50465]
argument [50448,50465]
===
match
---
atom_expr [68723,68750]
atom_expr [68723,68750]
===
match
---
expr_stmt [48833,48885]
expr_stmt [48833,48885]
===
match
---
simple_stmt [91828,91875]
simple_stmt [91927,91974]
===
match
---
trailer [55475,55490]
trailer [55475,55490]
===
match
---
argument [106848,106871]
argument [106947,106970]
===
match
---
operator: , [27987,27988]
operator: , [27987,27988]
===
match
---
name: self [49022,49026]
name: self [49022,49026]
===
match
---
trailer [106724,106734]
trailer [106823,106833]
===
match
---
atom_expr [80246,80263]
atom_expr [80246,80263]
===
match
---
name: keys [92484,92488]
name: keys [92583,92587]
===
match
---
atom_expr [52452,52811]
atom_expr [52452,52811]
===
match
---
name: query [61986,61991]
name: query [61986,61991]
===
match
---
name: airflow [3043,3050]
name: airflow [3043,3050]
===
match
---
name: session [44849,44856]
name: session [44849,44856]
===
match
---
simple_stmt [27541,27548]
simple_stmt [27541,27548]
===
match
---
trailer [14322,14329]
trailer [14322,14329]
===
match
---
atom_expr [71303,71312]
atom_expr [71303,71312]
===
match
---
expr_stmt [97699,97770]
expr_stmt [97798,97869]
===
match
---
if_stmt [70914,71093]
if_stmt [70914,71093]
===
match
---
name: values [72660,72666]
name: values [72660,72666]
===
match
---
name: is_paused [101843,101852]
name: is_paused [101942,101951]
===
match
---
name: _max_active_tasks [13557,13574]
name: _max_active_tasks [13557,13574]
===
match
---
decorated [32431,32562]
decorated [32431,32562]
===
match
---
param [31195,31199]
param [31195,31199]
===
match
---
operator: * [48571,48572]
operator: * [48571,48572]
===
match
---
operator: , [84106,84107]
operator: , [84205,84206]
===
match
---
parameters [17748,17761]
parameters [17748,17761]
===
match
---
suite [99844,100358]
suite [99943,100457]
===
match
---
trailer [72899,72917]
trailer [72899,72917]
===
match
---
trailer [100128,100169]
trailer [100227,100268]
===
match
---
name: dag_parser [80348,80358]
name: dag_parser [80348,80358]
===
match
---
simple_stmt [44612,44644]
simple_stmt [44612,44644]
===
match
---
atom_expr [23133,23147]
atom_expr [23133,23147]
===
match
---
name: get_downstream [75061,75075]
name: get_downstream [75061,75075]
===
match
---
trailer [84919,84927]
trailer [85018,85026]
===
match
---
return_stmt [66411,66423]
return_stmt [66411,66423]
===
match
---
operator: , [65214,65215]
operator: , [65214,65215]
===
match
---
trailer [43586,43595]
trailer [43586,43595]
===
match
---
name: default_args [14627,14639]
name: default_args [14627,14639]
===
match
---
funcdef [40913,41306]
funcdef [40913,41306]
===
match
---
atom_expr [24745,24757]
atom_expr [24745,24757]
===
match
---
if_stmt [12795,12933]
if_stmt [12795,12933]
===
match
---
comp_if [91962,91970]
comp_if [92061,92069]
===
match
---
operator: = [74218,74219]
operator: = [74218,74219]
===
match
---
atom_expr [18509,18518]
atom_expr [18509,18518]
===
match
---
trailer [17778,17784]
trailer [17778,17784]
===
match
---
atom_expr [42119,42137]
atom_expr [42119,42137]
===
match
---
parameters [98063,98069]
parameters [98162,98168]
===
match
---
name: start_date [66848,66858]
name: start_date [66848,66858]
===
match
---
name: airflow [2760,2767]
name: airflow [2760,2767]
===
match
---
name: k [68625,68626]
name: k [68625,68626]
===
match
---
name: Integer [96344,96351]
name: Integer [96443,96450]
===
match
---
operator: , [46837,46838]
operator: , [46837,46838]
===
match
---
name: apply_defaults [106555,106569]
name: apply_defaults [106654,106668]
===
match
---
trailer [28593,28777]
trailer [28593,28777]
===
match
---
operator: = [46724,46725]
operator: = [46724,46725]
===
match
---
name: int [31903,31906]
name: int [31903,31906]
===
match
---
atom_expr [53075,53094]
atom_expr [53075,53094]
===
match
---
atom_expr [70597,70637]
atom_expr [70597,70637]
===
match
---
simple_stmt [38773,38916]
simple_stmt [38773,38916]
===
match
---
name: dag [85403,85406]
name: dag [85502,85505]
===
match
---
operator: , [1391,1392]
operator: , [1391,1392]
===
match
---
name: self [50086,50090]
name: self [50086,50090]
===
match
---
name: append [88356,88362]
name: append [88455,88461]
===
match
---
trailer [32415,32422]
trailer [32415,32422]
===
match
---
expr_stmt [10322,10522]
expr_stmt [10322,10522]
===
match
---
name: flush [57622,57627]
name: flush [57622,57627]
===
match
---
operator: , [40513,40514]
operator: , [40513,40514]
===
match
---
trailer [47085,47090]
trailer [47085,47090]
===
match
---
trailer [89823,89861]
trailer [89922,89960]
===
match
---
atom_expr [87406,87425]
atom_expr [87505,87524]
===
match
---
name: is_active [35038,35047]
name: is_active [35038,35047]
===
match
---
trailer [33750,33781]
trailer [33750,33781]
===
match
---
atom_expr [12159,12173]
atom_expr [12159,12173]
===
match
---
fstring [98290,98316]
fstring [98389,98415]
===
match
---
trailer [13759,13761]
trailer [13759,13761]
===
match
---
argument [44704,44722]
argument [44704,44722]
===
match
---
return_stmt [75396,75436]
return_stmt [75396,75436]
===
match
---
atom_expr [98675,98709]
atom_expr [98774,98808]
===
match
---
simple_stmt [51323,51335]
simple_stmt [51323,51335]
===
match
---
name: TI [52982,52984]
name: TI [52982,52984]
===
match
---
name: scalar [92233,92239]
name: scalar [92332,92338]
===
match
---
trailer [47439,47459]
trailer [47439,47459]
===
match
---
atom_expr [52753,52763]
atom_expr [52753,52763]
===
match
---
tfpdef [55864,55886]
tfpdef [55864,55886]
===
match
---
atom_expr [50086,50100]
atom_expr [50086,50100]
===
match
---
operator: , [20138,20139]
operator: , [20138,20139]
===
match
---
name: deactivate_deleted_dags [101965,101988]
name: deactivate_deleted_dags [102064,102087]
===
match
---
operator: = [21951,21952]
operator: = [21951,21952]
===
match
---
atom_expr [48124,48134]
atom_expr [48124,48134]
===
match
---
name: Column [95125,95131]
name: Column [95224,95230]
===
match
---
trailer [12909,12922]
trailer [12909,12922]
===
match
---
expr_stmt [21474,21541]
expr_stmt [21474,21541]
===
match
---
operator: , [45396,45397]
operator: , [45396,45397]
===
match
---
trailer [85211,85222]
trailer [85310,85321]
===
match
---
expr_stmt [85355,85387]
expr_stmt [85454,85486]
===
match
---
comparison [89729,89753]
comparison [89828,89852]
===
match
---
atom [107267,107269]
atom [107366,107368]
===
match
---
yield_expr [27908,27918]
yield_expr [27908,27918]
===
match
---
tfpdef [45808,45829]
tfpdef [45808,45829]
===
match
---
operator: = [50722,50723]
operator: = [50722,50723]
===
match
---
name: pickle_id [31880,31889]
name: pickle_id [31880,31889]
===
match
---
atom_expr [61430,61448]
atom_expr [61430,61448]
===
match
---
expr_stmt [95438,95472]
expr_stmt [95537,95571]
===
match
---
atom_expr [74612,74625]
atom_expr [74612,74625]
===
match
---
name: DeprecationWarning [29212,29230]
name: DeprecationWarning [29212,29230]
===
match
---
string: "DagBag" [47308,47316]
string: "DagBag" [47308,47316]
===
match
---
param [108743,108751]
param [108842,108850]
===
match
---
simple_stmt [84721,84757]
simple_stmt [84820,84856]
===
match
---
simple_stmt [65832,65873]
simple_stmt [65832,65873]
===
match
---
trailer [18164,18171]
trailer [18164,18171]
===
match
---
operator: -> [35746,35748]
operator: -> [35746,35748]
===
match
---
expr_stmt [67529,67626]
expr_stmt [67529,67626]
===
match
---
simple_stmt [80197,80238]
simple_stmt [80197,80238]
===
match
---
not_test [102873,102896]
not_test [102972,102995]
===
match
---
name: RUNNING [38700,38707]
name: RUNNING [38700,38707]
===
match
---
name: self [31097,31101]
name: self [31097,31101]
===
match
---
suite [14099,14330]
suite [14099,14330]
===
match
---
operator: , [1149,1150]
operator: , [1149,1150]
===
match
---
operator: , [2799,2800]
operator: , [2799,2800]
===
match
---
trailer [101133,101145]
trailer [101232,101244]
===
match
---
trailer [34244,34251]
trailer [34244,34251]
===
match
---
expr_stmt [75153,75163]
expr_stmt [75153,75163]
===
match
---
name: session [45989,45996]
name: session [45989,45996]
===
match
---
simple_stmt [74074,74099]
simple_stmt [74074,74099]
===
match
---
trailer [34849,34855]
trailer [34849,34855]
===
match
---
expr_stmt [48611,48704]
expr_stmt [48611,48704]
===
match
---
trailer [3877,3881]
trailer [3877,3881]
===
match
---
trailer [32732,32744]
trailer [32732,32744]
===
match
---
atom_expr [97629,97650]
atom_expr [97728,97749]
===
match
---
name: ignore_task_deps [79815,79831]
name: ignore_task_deps [79815,79831]
===
match
---
fstring [16303,16354]
fstring [16303,16354]
===
match
---
name: dag_id [100199,100205]
name: dag_id [100298,100304]
===
match
---
simple_stmt [68153,68163]
simple_stmt [68153,68163]
===
match
---
param [36397,36410]
param [36397,36410]
===
match
---
name: TypeError [39534,39543]
name: TypeError [39534,39543]
===
match
---
atom_expr [105986,105998]
atom_expr [106085,106097]
===
match
---
suite [18129,18172]
suite [18129,18172]
===
match
---
simple_stmt [94913,94972]
simple_stmt [95012,95071]
===
match
---
name: _pickle_id [31838,31848]
name: _pickle_id [31838,31848]
===
match
---
return_stmt [73482,73492]
return_stmt [73482,73492]
===
match
---
operator: { [33751,33752]
operator: { [33751,33752]
===
match
---
import_from [1749,1832]
import_from [1749,1832]
===
match
---
not_test [84683,84691]
not_test [84782,84790]
===
match
---
trailer [84844,84849]
trailer [84943,84948]
===
match
---
atom_expr [85791,86190]
atom_expr [85890,86289]
===
match
---
expr_stmt [72382,72441]
expr_stmt [72382,72441]
===
match
---
operator: = [35638,35639]
operator: = [35638,35639]
===
match
---
trailer [92200,92204]
trailer [92299,92303]
===
match
---
arglist [29914,30001]
arglist [29914,30001]
===
match
---
name: subdag [41513,41519]
name: subdag [41513,41519]
===
match
---
operator: = [65510,65511]
operator: = [65510,65511]
===
match
---
name: name [94257,94261]
name: name [94356,94360]
===
match
---
simple_stmt [41551,41567]
simple_stmt [41551,41567]
===
match
---
atom_expr [15531,15546]
atom_expr [15531,15546]
===
match
---
name: set_dependency [43359,43373]
name: set_dependency [43359,43373]
===
match
---
operator: == [48464,48466]
operator: == [48464,48466]
===
match
---
operator: = [84963,84964]
operator: = [85062,85063]
===
match
---
parameters [109275,109280]
parameters [109374,109379]
===
match
---
operator: , [23874,23875]
operator: , [23874,23875]
===
match
---
atom_expr [75403,75436]
atom_expr [75403,75436]
===
match
---
trailer [29127,29132]
trailer [29127,29132]
===
match
---
suite [31115,31155]
suite [31115,31155]
===
match
---
expr_stmt [86643,86656]
expr_stmt [86742,86755]
===
match
---
trailer [97727,97734]
trailer [97826,97833]
===
match
---
name: orm_dags [85643,85651]
name: orm_dags [85742,85750]
===
match
---
name: t [24478,24479]
name: t [24478,24479]
===
match
---
atom_expr [49312,49322]
atom_expr [49312,49322]
===
match
---
fstring_start: f" [67540,67542]
fstring_start: f" [67540,67542]
===
match
---
string: 'SubDagOperator' [41822,41838]
string: 'SubDagOperator' [41822,41838]
===
match
---
operator: } [93754,93755]
operator: } [93853,93854]
===
match
---
name: self [36087,36091]
name: self [36087,36091]
===
match
---
name: ignore_first_depends_on_past [77493,77521]
name: ignore_first_depends_on_past [77493,77521]
===
match
---
operator: } [84810,84811]
operator: } [84909,84910]
===
match
---
atom_expr [18609,18642]
atom_expr [18609,18642]
===
match
---
operator: , [46818,46819]
operator: , [46818,46819]
===
match
---
atom [42446,42640]
atom [42446,42640]
===
match
---
name: co_filename [107545,107556]
name: co_filename [107644,107655]
===
match
---
name: self [89050,89054]
name: self [89149,89153]
===
match
---
try_stmt [18488,18643]
try_stmt [18488,18643]
===
match
---
atom_expr [108022,108054]
atom_expr [108121,108153]
===
match
---
atom_expr [75817,75832]
atom_expr [75817,75832]
===
match
---
tfpdef [93822,93843]
tfpdef [93921,93942]
===
match
---
comparison [15126,15157]
comparison [15126,15157]
===
match
---
name: overload [46256,46264]
name: overload [46256,46264]
===
match
---
param [88812,88824]
param [88911,88923]
===
match
---
name: args [80418,80422]
name: args [80418,80422]
===
match
---
simple_stmt [42426,42641]
simple_stmt [42426,42641]
===
match
---
atom [103614,103958]
atom [103713,104057]
===
match
---
simple_stmt [75153,75164]
simple_stmt [75153,75164]
===
match
---
operator: = [49121,49122]
operator: = [49121,49122]
===
match
---
atom_expr [60996,61072]
atom_expr [60996,61072]
===
match
---
argument [104036,104051]
argument [104135,104150]
===
match
---
atom_expr [41745,41764]
atom_expr [41745,41764]
===
match
---
trailer [73340,73360]
trailer [73340,73360]
===
match
---
decorated [34779,35049]
decorated [34779,35049]
===
match
---
name: include_subdags [66630,66645]
name: include_subdags [66630,66645]
===
match
---
simple_stmt [46880,46904]
simple_stmt [46880,46904]
===
match
---
name: str [32608,32611]
name: str [32608,32611]
===
match
---
suite [17762,18037]
suite [17762,18037]
===
match
---
trailer [101610,101617]
trailer [101709,101716]
===
match
---
tfpdef [46423,46451]
tfpdef [46423,46451]
===
match
---
name: execution_date [39489,39503]
name: execution_date [39489,39503]
===
match
---
name: Schedule [2532,2540]
name: Schedule [2532,2540]
===
match
---
atom_expr [33493,33522]
atom_expr [33493,33522]
===
match
---
operator: = [74469,74470]
operator: = [74469,74470]
===
match
---
name: max_active_tasks [13513,13529]
name: max_active_tasks [13513,13529]
===
match
---
name: task_id [73561,73568]
name: task_id [73561,73568]
===
match
---
dotted_name [41495,41519]
dotted_name [41495,41519]
===
match
---
decorator [100719,100729]
decorator [100818,100828]
===
match
---
name: Tuple [98082,98087]
name: Tuple [98181,98186]
===
match
---
simple_stmt [23920,23977]
simple_stmt [23920,23977]
===
match
---
atom_expr [86339,86352]
atom_expr [86438,86451]
===
match
---
trailer [52888,52894]
trailer [52888,52894]
===
match
---
trailer [70708,70716]
trailer [70708,70716]
===
match
---
name: schedule_interval [35969,35986]
name: schedule_interval [35969,35986]
===
match
---
string: """         Returns the number of task instances in the given DAG.          :param session: ORM session         :param dag_id: ID of the DAG to get the task concurrency of         :type dag_id: unicode         :param task_ids: A list of valid task IDs for the given DAG         :type task_ids: list[unicode]         :param states: A list of states to filter by if supplied         :type states: list[state]         :return: The number of running tasks         :rtype: int         """ [90982,91465]
string: """         Returns the number of task instances in the given DAG.          :param session: ORM session         :param dag_id: ID of the DAG to get the task concurrency of         :type dag_id: unicode         :param task_ids: A list of valid task IDs for the given DAG         :type task_ids: list[unicode]         :param states: A list of states to filter by if supplied         :type states: list[state]         :return: The number of running tasks         :rtype: int         """ [91081,91564]
===
match
---
name: log [3306,3309]
name: log [3306,3309]
===
match
---
name: orm_dag [85157,85164]
name: orm_dag [85256,85263]
===
match
---
fstring_start: f" [98337,98339]
fstring_start: f" [98436,98438]
===
match
---
string: 'start_date' [14144,14156]
string: 'start_date' [14144,14156]
===
match
---
operator: @ [30218,30219]
operator: @ [30218,30219]
===
match
---
argument [58080,58096]
argument [58080,58096]
===
match
---
name: dry_run [64385,64392]
name: dry_run [64385,64392]
===
match
---
fstring [98337,98414]
fstring [98436,98513]
===
match
---
name: task [59424,59428]
name: task [59424,59428]
===
match
---
comparison [41804,41838]
comparison [41804,41838]
===
match
---
expr_stmt [83561,83575]
expr_stmt [83660,83674]
===
match
---
operator: = [16615,16616]
operator: = [16615,16616]
===
match
---
trailer [20347,20349]
trailer [20347,20349]
===
match
---
trailer [36082,36086]
trailer [36082,36086]
===
match
---
sync_comp_for [59430,59452]
sync_comp_for [59430,59452]
===
match
---
if_stmt [3914,4023]
if_stmt [3914,4023]
===
match
---
operator: , [54178,54179]
operator: , [54178,54179]
===
match
---
operator: = [92169,92170]
operator: = [92268,92269]
===
match
---
operator: , [20832,20833]
operator: , [20832,20833]
===
match
---
param [97250,97267]
param [97349,97366]
===
match
---
param [23642,23647]
param [23642,23647]
===
match
---
operator: = [70679,70680]
operator: = [70679,70680]
===
match
---
trailer [99472,99474]
trailer [99571,99573]
===
match
---
atom_expr [42887,42946]
atom_expr [42887,42946]
===
match
---
trailer [95575,95584]
trailer [95674,95683]
===
match
---
testlist_comp [25025,25049]
testlist_comp [25025,25049]
===
match
---
simple_stmt [61118,61196]
simple_stmt [61118,61196]
===
match
---
atom_expr [64895,64907]
atom_expr [64895,64907]
===
match
---
trailer [84947,84952]
trailer [85046,85051]
===
match
---
atom_expr [32629,32656]
atom_expr [32629,32656]
===
match
---
name: dag [88068,88071]
name: dag [88167,88170]
===
match
---
atom_expr [46357,46375]
atom_expr [46357,46375]
===
match
---
trailer [37239,37244]
trailer [37239,37244]
===
match
---
operator: = [104543,104544]
operator: = [104642,104643]
===
match
---
arglist [39825,39878]
arglist [39825,39878]
===
match
---
name: child [72041,72046]
name: child [72041,72046]
===
match
---
operator: @ [38952,38953]
operator: @ [38952,38953]
===
match
---
atom_expr [32268,32322]
atom_expr [32268,32322]
===
match
---
trailer [86862,86872]
trailer [86961,86971]
===
match
---
atom_expr [89942,89958]
atom_expr [90041,90057]
===
match
---
atom_expr [87193,87204]
atom_expr [87292,87303]
===
match
---
name: dag_id [13171,13177]
name: dag_id [13171,13177]
===
match
---
return_stmt [67284,67298]
return_stmt [67284,67298]
===
match
---
funcdef [99764,100358]
funcdef [99863,100457]
===
match
---
name: subdag_task_groups [72562,72580]
name: subdag_task_groups [72562,72580]
===
match
---
trailer [87783,87795]
trailer [87882,87894]
===
match
---
name: Column [94264,94270]
name: Column [94363,94369]
===
match
---
name: latest [25444,25450]
name: latest [25444,25450]
===
match
---
operator: = [21042,21043]
operator: = [21042,21043]
===
match
---
simple_stmt [73726,73757]
simple_stmt [73726,73757]
===
match
---
name: start_date [44683,44693]
name: start_date [44683,44693]
===
match
---
operator: @ [99074,99075]
operator: @ [99173,99174]
===
match
---
name: conf [80038,80042]
name: conf [80038,80042]
===
match
---
import_from [2755,2831]
import_from [2755,2831]
===
match
---
atom_expr [87930,87942]
atom_expr [88029,88041]
===
match
---
operator: = [25235,25236]
operator: = [25235,25236]
===
match
---
operator: = [50152,50153]
operator: = [50152,50153]
===
match
---
argument [66220,66228]
argument [66220,66228]
===
match
---
operator: = [80802,80803]
operator: = [80802,80803]
===
match
---
name: self [35997,36001]
name: self [35997,36001]
===
match
---
arglist [85066,85101]
arglist [85165,85200]
===
match
---
simple_stmt [108079,108588]
simple_stmt [108178,108687]
===
match
---
param [47333,47358]
param [47333,47358]
===
match
---
name: provide_session [62057,62072]
name: provide_session [62057,62072]
===
match
---
name: provide_session [39915,39930]
name: provide_session [39915,39930]
===
match
---
expr_stmt [13513,13543]
expr_stmt [13513,13543]
===
match
---
atom_expr [43245,43270]
atom_expr [43245,43270]
===
match
---
if_stmt [85400,85508]
if_stmt [85499,85607]
===
match
---
name: conf [11769,11773]
name: conf [11769,11773]
===
match
---
name: Optional [61385,61393]
name: Optional [61385,61393]
===
match
---
trailer [71618,71633]
trailer [71618,71633]
===
match
---
simple_stmt [15713,15752]
simple_stmt [15713,15752]
===
match
---
trailer [76565,76573]
trailer [76565,76573]
===
match
---
atom_expr [27970,27987]
atom_expr [27970,27987]
===
match
---
decorated [31365,31441]
decorated [31365,31441]
===
match
---
arglist [11856,11886]
arglist [11856,11886]
===
match
---
simple_stmt [74832,74870]
simple_stmt [74832,74870]
===
match
---
name: alive_dag_filelocs [102635,102653]
name: alive_dag_filelocs [102734,102752]
===
match
---
trailer [100872,100877]
trailer [100971,100976]
===
match
---
suite [33406,33523]
suite [33406,33523]
===
match
---
name: task_dict [32406,32415]
name: task_dict [32406,32415]
===
match
---
raise_stmt [52446,52811]
raise_stmt [52446,52811]
===
match
---
string: "`DAG.get_run_dates()` is deprecated. Please use `DAG.iter_dagrun_infos_between()` instead." [28607,28699]
string: "`DAG.get_run_dates()` is deprecated. Please use `DAG.iter_dagrun_infos_between()` instead." [28607,28699]
===
match
---
operator: = [106645,106646]
operator: = [106744,106745]
===
match
---
argument [34704,34716]
argument [34704,34716]
===
match
---
name: Column [94925,94931]
name: Column [95024,95030]
===
match
---
argument [97031,97051]
argument [97130,97150]
===
match
---
atom_expr [53930,53948]
atom_expr [53930,53948]
===
match
---
atom_expr [68175,68215]
atom_expr [68175,68215]
===
match
---
atom_expr [37173,37197]
atom_expr [37173,37197]
===
match
---
trailer [87621,87638]
trailer [87720,87737]
===
match
---
name: callback [37592,37600]
name: callback [37592,37600]
===
match
---
trailer [62580,62584]
trailer [62580,62584]
===
match
---
operator: , [47091,47092]
operator: , [47091,47092]
===
match
---
operator: , [29059,29060]
operator: , [29059,29060]
===
match
---
trailer [77427,77451]
trailer [77427,77451]
===
match
---
trailer [101908,101915]
trailer [102007,102014]
===
match
---
name: ti_list [67589,67596]
name: ti_list [67589,67596]
===
match
---
name: dag [90393,90396]
name: dag [90492,90495]
===
match
---
name: timezone [74224,74232]
name: timezone [74224,74232]
===
match
---
suite [12959,13149]
suite [12959,13149]
===
match
---
atom_expr [95897,95917]
atom_expr [95996,96016]
===
match
---
name: task [76174,76178]
name: task [76174,76178]
===
match
---
trailer [73266,73279]
trailer [73266,73279]
===
match
---
name: exclude_task_ids [47230,47246]
name: exclude_task_ids [47230,47246]
===
match
---
operator: = [30205,30206]
operator: = [30205,30206]
===
match
---
atom_expr [34198,34220]
atom_expr [34198,34220]
===
match
---
name: get [93729,93732]
name: get [93828,93831]
===
match
---
simple_stmt [3476,3523]
simple_stmt [3476,3523]
===
match
---
name: task [58474,58478]
name: task [58474,58478]
===
match
---
name: airflow [79327,79334]
name: airflow [79327,79334]
===
match
---
simple_stmt [33223,33269]
simple_stmt [33223,33269]
===
match
---
name: next_dagrun_data_interval_end [96631,96660]
name: next_dagrun_data_interval_end [96730,96759]
===
match
---
fstring [53426,53460]
fstring [53426,53460]
===
match
---
operator: @ [62056,62057]
operator: @ [62056,62057]
===
match
---
decorated [89359,89959]
decorated [89458,90058]
===
match
---
name: Dict [12328,12332]
name: Dict [12328,12332]
===
match
---
operator: = [88819,88820]
operator: = [88918,88919]
===
match
---
name: self [16908,16912]
name: self [16908,16912]
===
match
---
operator: -> [42116,42118]
operator: -> [42116,42118]
===
match
---
operator: , [34716,34717]
operator: , [34716,34717]
===
match
---
operator: = [51644,51645]
operator: = [51644,51645]
===
match
---
atom_expr [48136,48153]
atom_expr [48136,48153]
===
match
---
name: dag [73412,73415]
name: dag [73412,73415]
===
match
---
atom_expr [29407,29440]
atom_expr [29407,29440]
===
match
---
atom_expr [52828,52849]
atom_expr [52828,52849]
===
match
---
atom_expr [40432,40445]
atom_expr [40432,40445]
===
match
---
trailer [16649,16669]
trailer [16649,16669]
===
match
---
name: user_defined_macros [43156,43175]
name: user_defined_macros [43156,43175]
===
match
---
name: stacklevel [35918,35928]
name: stacklevel [35918,35928]
===
match
---
arglist [57114,57367]
arglist [57114,57367]
===
match
---
trailer [87779,87783]
trailer [87878,87882]
===
match
---
trailer [101734,101741]
trailer [101833,101840]
===
match
---
simple_stmt [37121,37198]
simple_stmt [37121,37198]
===
match
---
param [66630,66651]
param [66630,66651]
===
match
---
name: end_date [76436,76444]
name: end_date [76436,76444]
===
match
---
name: dag [86824,86827]
name: dag [86923,86926]
===
match
---
name: self [51982,51986]
name: self [51982,51986]
===
match
---
atom_expr [85838,85870]
atom_expr [85937,85969]
===
match
---
name: confirm_prompt [67950,67964]
name: confirm_prompt [67950,67964]
===
match
---
name: run_type [80748,80756]
name: run_type [80748,80756]
===
match
---
name: info [27970,27974]
name: info [27970,27974]
===
match
---
number: 2 [41245,41246]
number: 2 [41245,41246]
===
match
---
argument [45154,45167]
argument [45154,45167]
===
match
---
argument [66963,66988]
argument [66963,66988]
===
match
---
operator: , [17983,17984]
operator: , [17983,17984]
===
match
---
simple_stmt [88343,88376]
simple_stmt [88442,88475]
===
match
---
name: do_it [67639,67644]
name: do_it [67639,67644]
===
match
---
name: Optional [35116,35124]
name: Optional [35116,35124]
===
match
---
trailer [49858,49864]
trailer [49858,49864]
===
match
---
operator: , [11739,11740]
operator: , [11739,11740]
===
match
---
expr_stmt [48093,48154]
expr_stmt [48093,48154]
===
match
---
name: dp [74816,74818]
name: dp [74816,74818]
===
match
---
atom_expr [49123,49174]
atom_expr [49123,49174]
===
match
---
string: "Nothing to clear." [67391,67410]
string: "Nothing to clear." [67391,67410]
===
match
---
name: create_dagrun [80460,80473]
name: create_dagrun [80460,80473]
===
match
---
trailer [76648,76711]
trailer [76648,76711]
===
match
---
atom_expr [82371,82383]
atom_expr [82395,82407]
===
match
---
param [31103,31113]
param [31103,31113]
===
match
---
if_stmt [54967,55191]
if_stmt [54967,55191]
===
match
---
name: session [99643,99650]
name: session [99742,99749]
===
match
---
trailer [12653,12673]
trailer [12653,12673]
===
match
---
fstring [98435,98508]
fstring [98534,98607]
===
match
---
fstring_start: f" [53426,53428]
fstring_start: f" [53426,53428]
===
match
---
trailer [13803,13815]
trailer [13803,13815]
===
match
---
name: warn [83934,83938]
name: warn [84033,84037]
===
match
---
name: parse [14224,14229]
name: parse [14224,14229]
===
match
---
name: func [80413,80417]
name: func [80413,80417]
===
match
---
operator: == [39716,39718]
operator: == [39716,39718]
===
match
---
param [101291,101307]
param [101390,101406]
===
match
---
operator: = [89895,89896]
operator: = [89994,89995]
===
match
---
name: TI [52927,52929]
name: TI [52927,52929]
===
match
---
param [36424,36436]
param [36424,36436]
===
match
---
trailer [15764,15779]
trailer [15764,15779]
===
match
---
name: DagModel [101706,101714]
name: DagModel [101805,101813]
===
match
---
name: time [45073,45077]
name: time [45073,45077]
===
match
---
atom_expr [32973,32994]
atom_expr [32973,32994]
===
match
---
atom_expr [101730,101741]
atom_expr [101829,101840]
===
match
---
argument [96420,96434]
argument [96519,96533]
===
match
---
name: include_downstream [53653,53671]
name: include_downstream [53653,53671]
===
match
---
expr_stmt [39681,39772]
expr_stmt [39681,39772]
===
match
---
name: self [39719,39723]
name: self [39719,39723]
===
match
---
comp_op [87943,87949]
comp_op [88042,88048]
===
match
---
operator: = [94295,94296]
operator: = [94394,94395]
===
match
---
suite [98868,98962]
suite [98967,99061]
===
match
---
name: data_interval [104801,104814]
name: data_interval [104900,104913]
===
match
---
if_stmt [86821,87248]
if_stmt [86920,87347]
===
match
---
arglist [19934,20139]
arglist [19934,20139]
===
match
---
operator: = [85202,85203]
operator: = [85301,85302]
===
match
---
operator: = [62499,62500]
operator: = [62499,62500]
===
match
---
simple_stmt [39804,39880]
simple_stmt [39804,39880]
===
match
---
string: """Returns a boolean indicating whether this DAG is paused""" [35140,35201]
string: """Returns a boolean indicating whether this DAG is paused""" [35140,35201]
===
match
---
name: clear_task_instances [2228,2248]
name: clear_task_instances [2228,2248]
===
match
---
name: warnings [30559,30567]
name: warnings [30559,30567]
===
match
---
name: session [54370,54377]
name: session [54370,54377]
===
match
---
name: self [41587,41591]
name: self [41587,41591]
===
match
---
name: self [21953,21957]
name: self [21953,21957]
===
match
---
simple_stmt [58431,58494]
simple_stmt [58431,58494]
===
match
---
trailer [88667,88673]
trailer [88766,88772]
===
match
---
param [99376,99380]
param [99475,99479]
===
match
---
name: self [15531,15535]
name: self [15531,15535]
===
match
---
atom [48339,48341]
atom [48339,48341]
===
match
---
trailer [64914,64930]
trailer [64914,64930]
===
match
---
trailer [61746,61752]
trailer [61746,61752]
===
match
---
operator: = [54561,54562]
operator: = [54561,54562]
===
match
---
atom [38566,38718]
atom [38566,38718]
===
match
---
simple_stmt [83536,83552]
simple_stmt [83635,83651]
===
match
---
operator: = [62313,62314]
operator: = [62313,62314]
===
match
---
name: resolve_template_files [41986,42008]
name: resolve_template_files [41986,42008]
===
match
---
atom_expr [95643,95658]
atom_expr [95742,95757]
===
match
---
name: task [37416,37420]
name: task [37416,37420]
===
match
---
name: Base [94449,94453]
name: Base [94548,94552]
===
match
---
name: self [29546,29550]
name: self [29546,29550]
===
match
---
tfpdef [80711,80731]
tfpdef [80711,80731]
===
match
---
name: interval [25099,25107]
name: interval [25099,25107]
===
match
---
param [61340,61364]
param [61340,61364]
===
match
---
name: confirm_prompt [67006,67020]
name: confirm_prompt [67006,67020]
===
match
---
name: task_id [51999,52006]
name: task_id [51999,52006]
===
match
---
name: execution_date [82698,82712]
name: execution_date [82808,82822]
===
match
---
name: self [101621,101625]
name: self [101720,101724]
===
match
---
name: str [10866,10869]
name: str [10866,10869]
===
match
---
name: Column [95897,95903]
name: Column [95996,96002]
===
match
---
name: name [94427,94431]
name: name [94526,94530]
===
match
---
comp_op [17178,17184]
comp_op [17178,17184]
===
match
---
name: latest [29061,29067]
name: latest [29061,29067]
===
match
---
name: self [80483,80487]
name: self [80483,80487]
===
match
---
if_stmt [64154,64400]
if_stmt [64154,64400]
===
match
---
operator: , [44847,44848]
operator: , [44847,44848]
===
match
---
name: instance [22075,22083]
name: instance [22075,22083]
===
match
---
operator: , [35640,35641]
operator: , [35640,35641]
===
match
---
param [99202,99209]
param [99301,99308]
===
match
---
name: expression [86535,86545]
name: expression [86634,86644]
===
match
---
suite [74280,74402]
suite [74280,74402]
===
match
---
arglist [82525,82545]
arglist [82635,82655]
===
match
---
operator: = [96361,96362]
operator: = [96460,96461]
===
match
---
trailer [30847,31013]
trailer [30847,31013]
===
match
---
name: self [31794,31798]
name: self [31794,31798]
===
match
---
name: check_cycle [2743,2754]
name: check_cycle [2743,2754]
===
match
---
argument [66246,66273]
argument [66246,66273]
===
match
---
operator: = [3843,3844]
operator: = [3843,3844]
===
match
---
trailer [49354,49361]
trailer [49354,49361]
===
match
---
operator: = [13790,13791]
operator: = [13790,13791]
===
match
---
decorated [30218,30480]
decorated [30218,30480]
===
match
---
name: info [27914,27918]
name: info [27914,27918]
===
match
---
name: including_subdags [101655,101672]
name: including_subdags [101754,101771]
===
match
---
trailer [32422,32424]
trailer [32422,32424]
===
match
---
trailer [85795,86190]
trailer [85894,86289]
===
match
---
name: question [67529,67537]
name: question [67529,67537]
===
match
---
trailer [15028,15041]
trailer [15028,15041]
===
match
---
trailer [86146,86161]
trailer [86245,86260]
===
match
---
decorated [30485,30739]
decorated [30485,30739]
===
match
---
if_stmt [109034,109211]
if_stmt [109133,109310]
===
match
---
comparison [103684,103719]
comparison [103783,103818]
===
match
---
trailer [41755,41764]
trailer [41755,41764]
===
match
---
comparison [74736,74753]
comparison [74736,74753]
===
match
---
trailer [14383,14392]
trailer [14383,14392]
===
match
---
trailer [40891,40893]
trailer [40891,40893]
===
match
---
trailer [49600,49630]
trailer [49600,49630]
===
match
---
name: str [69338,69341]
name: str [69338,69341]
===
match
---
name: session [45486,45493]
name: session [45486,45493]
===
match
---
trailer [103917,103948]
trailer [104016,104047]
===
match
---
name: property [98021,98029]
name: property [98120,98128]
===
match
---
operator: = [13575,13576]
operator: = [13575,13576]
===
match
---
atom_expr [85823,85836]
atom_expr [85922,85935]
===
match
---
name: downstream_group_ids [72821,72841]
name: downstream_group_ids [72821,72841]
===
match
---
fstring [25285,25337]
fstring [25285,25337]
===
match
---
comparison [86508,86553]
comparison [86607,86652]
===
match
---
name: str [35988,35991]
name: str [35988,35991]
===
match
---
trailer [19731,19737]
trailer [19731,19737]
===
match
---
operator: -> [101354,101356]
operator: -> [101453,101455]
===
match
---
arglist [51952,52008]
arglist [51952,52008]
===
match
---
trailer [44491,44506]
trailer [44491,44506]
===
match
---
operator: = [80016,80017]
operator: = [80016,80017]
===
match
---
name: state [57299,57304]
name: state [57299,57304]
===
match
---
operator: , [73626,73627]
operator: , [73626,73627]
===
match
---
atom_expr [53039,53056]
atom_expr [53039,53056]
===
match
---
trailer [34297,34305]
trailer [34297,34305]
===
match
---
atom_expr [71915,71928]
atom_expr [71915,71928]
===
match
---
name: task [76786,76790]
name: task [76786,76790]
===
match
---
number: 1 [54441,54442]
number: 1 [54441,54442]
===
match
---
name: value [31498,31503]
name: value [31498,31503]
===
match
---
trailer [44295,44462]
trailer [44295,44462]
===
match
---
fstring_start: f" [82581,82583]
fstring_start: f" [82691,82693]
===
match
---
operator: = [73337,73338]
operator: = [73337,73338]
===
match
---
trailer [72996,73016]
trailer [72996,73016]
===
match
---
string: """This method is deprecated in favor of partial_subset""" [68956,69014]
string: """This method is deprecated in favor of partial_subset""" [68956,69014]
===
match
---
expr_stmt [48550,48584]
expr_stmt [48550,48584]
===
match
---
tfpdef [45910,45943]
tfpdef [45910,45943]
===
match
---
name: pendulum [1254,1262]
name: pendulum [1254,1262]
===
match
---
name: DagRun [3845,3851]
name: DagRun [3845,3851]
===
match
---
name: pop [109147,109150]
name: pop [109246,109249]
===
match
---
atom_expr [37357,37364]
atom_expr [37357,37364]
===
match
---
string: """         Return (and lock) a list of Dag objects that are due to create a new DagRun.          This will return a resultset of rows  that is row-level-locked with a "SELECT ... FOR UPDATE" query,         you should ensure that any scheduling decisions are made in a single transaction -- as soon as the         transaction is committed it will be unlocked.         """ [103071,103442]
string: """         Return (and lock) a list of Dag objects that are due to create a new DagRun.          This will return a resultset of rows  that is row-level-locked with a "SELECT ... FOR UPDATE" query,         you should ensure that any scheduling decisions are made in a single transaction -- as soon as the         transaction is committed it will be unlocked.         """ [103170,103541]
===
match
---
atom_expr [60938,60970]
atom_expr [60938,60970]
===
match
---
operator: , [58096,58097]
operator: , [58096,58097]
===
match
---
atom_expr [96663,96682]
atom_expr [96762,96781]
===
match
---
comparison [101602,101632]
comparison [101701,101731]
===
match
---
operator: , [61410,61411]
operator: , [61410,61411]
===
match
---
name: args [80373,80377]
name: args [80373,80377]
===
match
---
name: parent_dag [87066,87076]
name: parent_dag [87165,87175]
===
match
---
operator: = [21085,21086]
operator: = [21085,21086]
===
match
---
trailer [55400,55408]
trailer [55400,55408]
===
match
---
name: warnings [23714,23722]
name: warnings [23714,23722]
===
match
---
expr_stmt [47539,47556]
expr_stmt [47539,47556]
===
match
---
name: session [47273,47280]
name: session [47273,47280]
===
match
---
name: State [61317,61322]
name: State [61317,61322]
===
match
---
name: str [67492,67495]
name: str [67492,67495]
===
match
---
operator: = [61065,61066]
operator: = [61065,61066]
===
match
---
operator: == [86067,86069]
operator: == [86166,86168]
===
match
---
trailer [36164,36182]
trailer [36164,36182]
===
match
---
dotted_name [2065,2089]
dotted_name [2065,2089]
===
match
---
name: self [27938,27942]
name: self [27938,27942]
===
match
---
operator: -> [73659,73661]
operator: -> [73659,73661]
===
match
---
operator: = [66975,66976]
operator: = [66975,66976]
===
match
---
operator: , [77317,77318]
operator: , [77317,77318]
===
match
---
atom_expr [102675,102694]
atom_expr [102774,102793]
===
match
---
name: self [68803,68807]
name: self [68803,68807]
===
match
---
name: upstream_task_id [93353,93369]
name: upstream_task_id [93452,93468]
===
match
---
simple_stmt [102448,102486]
simple_stmt [102547,102585]
===
match
---
operator: = [80694,80695]
operator: = [80694,80695]
===
match
---
name: DagRun [40824,40830]
name: DagRun [40824,40830]
===
match
---
name: utils [2768,2773]
name: utils [2768,2773]
===
match
---
name: self [17687,17691]
name: self [17687,17691]
===
match
---
name: include_externally_triggered [29944,29972]
name: include_externally_triggered [29944,29972]
===
match
---
string: "@once" [24948,24955]
string: "@once" [24948,24955]
===
match
---
decorator [31590,31600]
decorator [31590,31600]
===
match
---
simple_stmt [73314,73396]
simple_stmt [73314,73396]
===
match
---
name: earliest [26519,26527]
name: earliest [26519,26527]
===
match
---
name: len [84746,84749]
name: len [84845,84848]
===
match
---
simple_stmt [71899,71961]
simple_stmt [71899,71961]
===
match
---
atom_expr [58533,58551]
atom_expr [58533,58551]
===
match
---
trailer [90730,90740]
trailer [90829,90839]
===
match
---
simple_stmt [52446,52812]
simple_stmt [52446,52812]
===
match
---
atom_expr [97400,97612]
atom_expr [97499,97711]
===
match
---
atom_expr [10892,10905]
atom_expr [10892,10905]
===
match
---
name: get [87780,87783]
name: get [87879,87882]
===
match
---
trailer [12422,12427]
trailer [12422,12427]
===
match
---
name: execution_date [53080,53094]
name: execution_date [53080,53094]
===
match
---
expr_stmt [71899,71960]
expr_stmt [71899,71960]
===
match
---
name: dag_id [83137,83143]
name: dag_id [83236,83242]
===
match
---
operator: , [46482,46483]
operator: , [46482,46483]
===
match
---
name: hash_components [18535,18550]
name: hash_components [18535,18550]
===
match
---
expr_stmt [55004,55190]
expr_stmt [55004,55190]
===
match
---
operator: , [66487,66488]
operator: , [66487,66488]
===
match
---
atom_expr [52881,53114]
atom_expr [52881,53114]
===
match
---
atom_expr [102420,102437]
atom_expr [102519,102536]
===
match
---
name: filter [3973,3979]
name: filter [3973,3979]
===
match
---
suite [99107,99141]
suite [99206,99240]
===
match
---
name: RePatternType [70526,70539]
name: RePatternType [70526,70539]
===
match
---
name: catchup [26672,26679]
name: catchup [26672,26679]
===
match
---
suite [46871,46904]
suite [46871,46904]
===
match
---
argument [57214,57235]
argument [57214,57235]
===
match
---
argument [66922,66945]
argument [66922,66945]
===
match
---
name: DagRun [86051,86057]
name: DagRun [86150,86156]
===
match
---
name: only_running [67903,67915]
name: only_running [67903,67915]
===
match
---
expr_stmt [13840,13884]
expr_stmt [13840,13884]
===
match
---
name: Column [94627,94633]
name: Column [94726,94732]
===
match
---
name: timezone [83048,83056]
name: timezone [83147,83155]
===
match
---
trailer [69031,69036]
trailer [69031,69036]
===
match
---
fstring_end: " [17731,17732]
fstring_end: " [17731,17732]
===
match
---
import_from [1453,1513]
import_from [1453,1513]
===
match
---
name: DagModel [101765,101773]
name: DagModel [101864,101872]
===
match
---
name: graph_sorted [60864,60876]
name: graph_sorted [60864,60876]
===
match
---
return_stmt [109219,109233]
return_stmt [109318,109332]
===
match
---
expr_stmt [49345,49393]
expr_stmt [49345,49393]
===
match
---
trailer [14715,14721]
trailer [14715,14721]
===
match
---
trailer [100121,100128]
trailer [100220,100227]
===
match
---
trailer [88043,88052]
trailer [88142,88151]
===
match
---
expr_stmt [31124,31154]
expr_stmt [31124,31154]
===
match
---
number: 4 [75125,75126]
number: 4 [75125,75126]
===
match
---
name: append [38086,38092]
name: append [38086,38092]
===
match
---
atom_expr [15058,15114]
atom_expr [15058,15114]
===
match
---
operator: = [95123,95124]
operator: = [95222,95223]
===
match
---
trailer [41077,41257]
trailer [41077,41257]
===
match
---
name: or_ [85962,85965]
name: or_ [86061,86064]
===
match
---
string: """         Pause/Un-pause a DAG.          :param is_paused: Is the DAG paused         :param including_subdags: whether to include the DAG's subdags         :param session: session         """ [101371,101564]
string: """         Pause/Un-pause a DAG.          :param is_paused: Is the DAG paused         :param including_subdags: whether to include the DAG's subdags         :param session: session         """ [101470,101663]
===
match
---
name: backref [96297,96304]
name: backref [96396,96403]
===
match
---
expr_stmt [82399,82452]
expr_stmt [82456,82497]
===
match
---
name: num [20266,20269]
name: num [20266,20269]
===
match
---
name: condition [51474,51483]
name: condition [51474,51483]
===
match
---
name: session [88812,88819]
name: session [88911,88918]
===
match
---
simple_stmt [72991,73080]
simple_stmt [72991,73080]
===
match
---
name: perms [19708,19713]
name: perms [19708,19713]
===
match
---
param [46778,46838]
param [46778,46838]
===
match
---
return_stmt [59578,59604]
return_stmt [59578,59604]
===
match
---
name: task [76033,76037]
name: task [76033,76037]
===
match
---
name: pickle [74121,74127]
name: pickle [74121,74127]
===
match
---
trailer [55958,55964]
trailer [55958,55964]
===
match
---
expr_stmt [87354,87393]
expr_stmt [87453,87492]
===
match
---
operator: , [90929,90930]
operator: , [91028,91029]
===
match
---
operator: , [47443,47444]
operator: , [47443,47444]
===
match
---
operator: , [13419,13420]
operator: , [13419,13420]
===
match
---
name: int [31110,31113]
name: int [31110,31113]
===
match
---
expr_stmt [95887,95917]
expr_stmt [95986,96016]
===
match
---
name: DagRun [86508,86514]
name: DagRun [86607,86613]
===
match
---
trailer [45750,45760]
trailer [45750,45760]
===
match
---
try_stmt [21107,21231]
try_stmt [21107,21231]
===
match
---
trailer [42536,42555]
trailer [42536,42555]
===
match
---
name: get_paused_dag_ids [99768,99786]
name: get_paused_dag_ids [99867,99885]
===
match
---
comparison [3889,3908]
comparison [3889,3908]
===
match
---
trailer [34771,34773]
trailer [34771,34773]
===
match
---
dotted_name [1562,1576]
dotted_name [1562,1576]
===
match
---
return_stmt [35012,35048]
return_stmt [35012,35048]
===
match
---
param [80857,80895]
param [80857,80895]
===
match
---
name: session [66195,66202]
name: session [66195,66202]
===
match
---
atom_expr [59410,59422]
atom_expr [59410,59422]
===
match
---
return_stmt [28982,29069]
return_stmt [28982,29069]
===
match
---
trailer [15427,15447]
trailer [15427,15447]
===
match
---
name: t [71274,71275]
name: t [71274,71275]
===
match
---
operator: @ [33368,33369]
operator: @ [33368,33369]
===
match
---
trailer [38620,38627]
trailer [38620,38627]
===
match
---
name: query [39689,39694]
name: query [39689,39694]
===
match
---
trailer [61185,61192]
trailer [61185,61192]
===
match
---
atom_expr [96122,96132]
atom_expr [96221,96231]
===
match
---
name: filter [55553,55559]
name: filter [55553,55559]
===
match
---
name: get_flat_relatives [70867,70885]
name: get_flat_relatives [70867,70885]
===
match
---
simple_stmt [70951,71003]
simple_stmt [70951,71003]
===
match
---
dotted_name [1936,1957]
dotted_name [1936,1957]
===
match
---
param [47101,47123]
param [47101,47123]
===
match
---
decorator [99074,99084]
decorator [99173,99183]
===
match
---
name: self [37231,37235]
name: self [37231,37235]
===
match
---
name: default_args [14050,14062]
name: default_args [14050,14062]
===
match
---
expr_stmt [109179,109210]
expr_stmt [109278,109309]
===
match
---
fstring_string: `run_type` expected to be a DagRunType is  [82583,82625]
fstring_string: `run_type` expected to be a DagRunType is  [82693,82735]
===
match
---
name: warn [64187,64191]
name: warn [64187,64191]
===
match
---
name: align [27462,27467]
name: align [27462,27467]
===
match
---
name: TIMEZONE [14431,14439]
name: TIMEZONE [14431,14439]
===
match
---
name: ACTION_CAN_READ [19542,19557]
name: ACTION_CAN_READ [19542,19557]
===
match
---
import_from [1312,1360]
import_from [1312,1360]
===
match
---
operator: , [55117,55118]
operator: , [55117,55118]
===
match
---
operator: , [10369,10370]
operator: , [10369,10370]
===
match
---
atom_expr [101686,101742]
atom_expr [101785,101841]
===
match
---
arglist [27239,27256]
arglist [27239,27256]
===
match
---
name: ignore_task_deps [77461,77477]
name: ignore_task_deps [77461,77477]
===
match
---
name: dag_id [61715,61721]
name: dag_id [61715,61721]
===
match
---
simple_stmt [31329,31360]
simple_stmt [31329,31360]
===
match
---
name: self [104669,104673]
name: self [104768,104772]
===
match
---
suite [31817,31849]
suite [31817,31849]
===
match
---
atom_expr [83132,83143]
atom_expr [83231,83242]
===
match
---
name: name [88113,88117]
name: name [88212,88216]
===
match
---
param [29098,29103]
param [29098,29103]
===
match
---
name: max_active_runs [15718,15733]
name: max_active_runs [15718,15733]
===
match
---
string: """         Clears a set of task instances associated with the current dag for         a specified date range.          :param task_ids: List of task ids to clear         :type task_ids: List[str]         :param start_date: The minimum execution_date to clear         :type start_date: datetime.datetime or None         :param end_date: The maximum execution_date to clear         :type end_date: datetime.datetime or None         :param only_failed: Only clear failed tasks         :type only_failed: bool         :param only_running: Only clear running tasks.         :type only_running: bool         :param confirm_prompt: Ask for confirmation         :type confirm_prompt: bool         :param include_subdags: Clear tasks in subdags and clear external tasks             indicated by ExternalTaskMarker         :type include_subdags: bool         :param include_parentdag: Clear tasks in the parent dag of the subdag.         :type include_parentdag: bool         :param dag_run_state: state to set DagRun to. If set to False, dagrun state will not             be changed.         :param dry_run: Find the tasks to clear but don't clear them.         :type dry_run: bool         :param session: The sqlalchemy session to use         :type session: sqlalchemy.orm.session.Session         :param dag_bag: The DagBag used to find the dags subdags (Optional)         :type dag_bag: airflow.models.dagbag.DagBag         :param exclude_task_ids: A set of ``task_id`` that should not be cleared         :type exclude_task_ids: frozenset         """ [62601,64145]
string: """         Clears a set of task instances associated with the current dag for         a specified date range.          :param task_ids: List of task ids to clear         :type task_ids: List[str]         :param start_date: The minimum execution_date to clear         :type start_date: datetime.datetime or None         :param end_date: The maximum execution_date to clear         :type end_date: datetime.datetime or None         :param only_failed: Only clear failed tasks         :type only_failed: bool         :param only_running: Only clear running tasks.         :type only_running: bool         :param confirm_prompt: Ask for confirmation         :type confirm_prompt: bool         :param include_subdags: Clear tasks in subdags and clear external tasks             indicated by ExternalTaskMarker         :type include_subdags: bool         :param include_parentdag: Clear tasks in the parent dag of the subdag.         :type include_parentdag: bool         :param dag_run_state: state to set DagRun to. If set to False, dagrun state will not             be changed.         :param dry_run: Find the tasks to clear but don't clear them.         :type dry_run: bool         :param session: The sqlalchemy session to use         :type session: sqlalchemy.orm.session.Session         :param dag_bag: The DagBag used to find the dags subdags (Optional)         :type dag_bag: airflow.models.dagbag.DagBag         :param exclude_task_ids: A set of ``task_id`` that should not be cleared         :type exclude_task_ids: frozenset         """ [62601,64145]
===
match
---
name: warnings [916,924]
name: warnings [916,924]
===
match
---
name: tis [51331,51334]
name: tis [51331,51334]
===
match
---
operator: = [62220,62221]
operator: = [62220,62221]
===
match
---
argument [54019,54050]
argument [54019,54050]
===
match
---
param [68937,68945]
param [68937,68945]
===
match
---
trailer [86687,86721]
trailer [86786,86820]
===
match
---
operator: , [84952,84953]
operator: , [85051,85052]
===
match
---
string: """Get ``num`` task instances before (including) ``base_date``.          The returned list may contain exactly ``num`` task instances. It can         have less if there are less than ``num`` scheduled DAG runs before         ``base_date``, or more if there are manual task runs between the         requested period, which does not count toward ``num``.         """ [43856,44220]
string: """Get ``num`` task instances before (including) ``base_date``.          The returned list may contain exactly ``num`` task instances. It can         have less if there are less than ``num`` scheduled DAG runs before         ``base_date``, or more if there are manual task runs between the         requested period, which does not count toward ``num``.         """ [43856,44220]
===
match
---
decorated [58263,58494]
decorated [58263,58494]
===
match
---
name: parent_dag [96984,96994]
name: parent_dag [97083,97093]
===
match
---
name: self [14275,14279]
name: self [14275,14279]
===
match
---
name: owner [33754,33759]
name: owner [33754,33759]
===
match
---
name: items [68493,68498]
name: items [68493,68498]
===
match
---
operator: == [39869,39871]
operator: == [39869,39871]
===
match
---
name: reason [36411,36417]
name: reason [36411,36417]
===
match
---
name: schedule_interval [96162,96179]
name: schedule_interval [96261,96278]
===
match
---
atom_expr [30192,30204]
atom_expr [30192,30204]
===
match
---
name: DEPRECATED_ACTION_CAN_DAG_EDIT [19583,19613]
name: DEPRECATED_ACTION_CAN_DAG_EDIT [19583,19613]
===
match
---
import_from [3126,3176]
import_from [3126,3176]
===
match
---
operator: == [39839,39841]
operator: == [39839,39841]
===
match
---
for_stmt [107286,107394]
for_stmt [107385,107493]
===
match
---
name: external_task_id [53001,53017]
name: external_task_id [53001,53017]
===
match
---
name: f_sig [107305,107310]
name: f_sig [107404,107409]
===
match
---
funcdef [30146,30213]
funcdef [30146,30213]
===
match
---
atom_expr [50220,50261]
atom_expr [50220,50261]
===
match
---
trailer [75637,75648]
trailer [75637,75648]
===
match
---
string: """         Given a list of known DAGs, deactivate any other DAGs that are         marked as active in the ORM          :param active_dag_ids: list of DAG IDs that are active         :type active_dag_ids: list[unicode]         :return: None         """ [89465,89717]
string: """         Given a list of known DAGs, deactivate any other DAGs that are         marked as active in the ORM          :param active_dag_ids: list of DAG IDs that are active         :type active_dag_ids: list[unicode]         :return: None         """ [89564,89816]
===
match
---
name: executor [79754,79762]
name: executor [79754,79762]
===
match
---
simple_stmt [87175,87205]
simple_stmt [87274,87304]
===
match
---
atom_expr [80380,80399]
atom_expr [80380,80399]
===
match
---
name: Dict [11320,11324]
name: Dict [11320,11324]
===
match
---
name: default_view [16118,16130]
name: default_view [16118,16130]
===
match
---
param [46049,46074]
param [46049,46074]
===
match
---
name: logical_date [27711,27723]
name: logical_date [27711,27723]
===
match
---
simple_stmt [79534,79583]
simple_stmt [79534,79583]
===
match
---
name: logical_date [28995,29007]
name: logical_date [28995,29007]
===
match
---
trailer [105463,105470]
trailer [105562,105569]
===
match
---
operator: , [98788,98789]
operator: , [98887,98888]
===
match
---
name: self [33769,33773]
name: self [33769,33773]
===
match
---
name: skip_locked [104024,104035]
name: skip_locked [104123,104134]
===
match
---
operator: -> [32783,32785]
operator: -> [32783,32785]
===
match
---
name: interval [24827,24835]
name: interval [24827,24835]
===
match
---
operator: = [37310,37311]
operator: = [37310,37311]
===
match
---
name: run_type [82525,82533]
name: run_type [82635,82643]
===
match
---
operator: , [102023,102024]
operator: , [102122,102123]
===
match
---
trailer [59590,59604]
trailer [59590,59604]
===
match
---
name: interval [25192,25200]
name: interval [25192,25200]
===
match
---
name: tis [67246,67249]
name: tis [67246,67249]
===
match
---
decorator [30127,30142]
decorator [30127,30142]
===
match
---
string: "Deactivating DAGs (for which DAG files are deleted) from %s table " [102350,102418]
string: "Deactivating DAGs (for which DAG files are deleted) from %s table " [102449,102517]
===
match
---
atom_expr [41587,41597]
atom_expr [41587,41597]
===
match
---
parameters [97968,97974]
parameters [98067,98073]
===
match
---
trailer [32365,32379]
trailer [32365,32379]
===
match
---
expr_stmt [95552,95584]
expr_stmt [95651,95683]
===
match
---
operator: , [71300,71301]
operator: , [71300,71301]
===
match
---
fstring_start: f' [16303,16305]
fstring_start: f' [16303,16305]
===
match
---
simple_stmt [33164,33198]
simple_stmt [33164,33198]
===
match
---
atom_expr [87062,87082]
atom_expr [87161,87181]
===
match
---
atom_expr [103701,103719]
atom_expr [103800,103818]
===
match
---
name: tis [48181,48184]
name: tis [48181,48184]
===
match
---
for_stmt [19698,19837]
for_stmt [19698,19837]
===
match
---
trailer [44552,44558]
trailer [44552,44558]
===
match
---
trailer [24362,24380]
trailer [24362,24380]
===
match
---
suite [31505,31585]
suite [31505,31585]
===
match
---
name: task [76201,76205]
name: task [76201,76205]
===
match
---
name: Optional [39065,39073]
name: Optional [39065,39073]
===
match
---
simple_stmt [72894,72979]
simple_stmt [72894,72979]
===
match
---
atom [97043,97051]
atom [97142,97150]
===
match
---
atom_expr [38678,38690]
atom_expr [38678,38690]
===
match
---
name: datetime [55738,55746]
name: datetime [55738,55746]
===
match
---
param [45872,45901]
param [45872,45901]
===
match
---
name: options [99264,99271]
name: options [99363,99370]
===
match
---
name: Optional [55910,55918]
name: Optional [55910,55918]
===
match
---
suite [73531,73590]
suite [73531,73590]
===
match
---
atom_expr [37994,38007]
atom_expr [37994,38007]
===
match
---
operator: = [77574,77575]
operator: = [77574,77575]
===
match
---
name: start_date [13936,13946]
name: start_date [13936,13946]
===
match
---
suite [48080,48155]
suite [48080,48155]
===
match
---
decorated [80435,83740]
decorated [80435,83839]
===
match
---
atom_expr [74736,74745]
atom_expr [74736,74745]
===
match
---
simple_stmt [101751,101893]
simple_stmt [101850,101992]
===
match
---
atom_expr [66707,66725]
atom_expr [66707,66725]
===
match
---
name: cls [68410,68413]
name: cls [68410,68413]
===
match
---
trailer [109317,109338]
trailer [109416,109437]
===
match
---
trailer [106864,106871]
trailer [106963,106970]
===
match
---
arglist [34563,34717]
arglist [34563,34717]
===
match
---
if_stmt [51347,51561]
if_stmt [51347,51561]
===
match
---
param [77327,77346]
param [77327,77346]
===
match
---
atom [96823,96978]
atom [96922,97077]
===
match
---
name: is_paused [35347,35356]
name: is_paused [35347,35356]
===
match
---
name: set_downstream [43614,43628]
name: set_downstream [43614,43628]
===
match
---
operator: , [12033,12034]
operator: , [12033,12034]
===
match
---
name: env [43346,43349]
name: env [43346,43349]
===
match
---
trailer [23727,23911]
trailer [23727,23911]
===
match
---
name: _upstream_task_ids [73226,73244]
name: _upstream_task_ids [73226,73244]
===
match
---
name: __doc__ [107023,107030]
name: __doc__ [107122,107129]
===
match
---
for_stmt [42024,42084]
for_stmt [42024,42084]
===
match
---
name: t [65863,65864]
name: t [65863,65864]
===
match
---
name: used_group_ids [71591,71605]
name: used_group_ids [71591,71605]
===
match
---
name: intersection [72842,72854]
name: intersection [72842,72854]
===
match
---
atom_expr [87377,87393]
atom_expr [87476,87492]
===
match
---
name: name [32300,32304]
name: name [32300,32304]
===
match
---
name: downstream_task_id [93376,93394]
name: downstream_task_id [93475,93493]
===
match
---
name: schedule [22048,22056]
name: schedule [22048,22056]
===
match
---
yield_expr [27749,27810]
yield_expr [27749,27810]
===
match
---
trailer [39723,39730]
trailer [39723,39730]
===
match
---
trailer [33188,33196]
trailer [33188,33196]
===
match
---
trailer [85617,85621]
trailer [85716,85720]
===
match
---
trailer [39035,39040]
trailer [39035,39040]
===
match
---
name: _context_managed_dag [109318,109338]
name: _context_managed_dag [109417,109437]
===
match
---
string: 'sla_miss_callback' [92906,92925]
string: 'sla_miss_callback' [93005,93024]
===
match
---
name: ExecutorLoader [79545,79559]
name: ExecutorLoader [79545,79559]
===
match
---
number: 2 [35639,35640]
number: 2 [35639,35640]
===
match
---
suite [19099,20193]
suite [19099,20193]
===
match
---
exprlist [100294,100308]
exprlist [100393,100407]
===
match
---
operator: , [58222,58223]
operator: , [58222,58223]
===
match
---
name: min_date [44229,44237]
name: min_date [44229,44237]
===
match
---
operator: , [47467,47468]
operator: , [47467,47468]
===
match
---
name: group [72632,72637]
name: group [72632,72637]
===
match
---
raise_stmt [75662,75728]
raise_stmt [75662,75728]
===
match
---
name: stacklevel [69190,69200]
name: stacklevel [69190,69200]
===
match
---
trailer [51649,51651]
trailer [51649,51651]
===
match
---
name: group [72682,72687]
name: group [72682,72687]
===
match
---
name: query [48195,48200]
name: query [48195,48200]
===
match
---
operator: , [65399,65400]
operator: , [65399,65400]
===
match
---
atom_expr [48567,48583]
atom_expr [48567,48583]
===
match
---
arglist [14354,14370]
arglist [14354,14370]
===
match
---
name: downstream_task_id [43643,43661]
name: downstream_task_id [43643,43661]
===
match
---
suite [30787,31052]
suite [30787,31052]
===
match
---
name: __ne__ [18046,18052]
name: __ne__ [18046,18052]
===
match
---
operator: , [64529,64530]
operator: , [64529,64530]
===
match
---
operator: = [39810,39811]
operator: = [39810,39811]
===
match
---
name: warnings [20811,20819]
name: warnings [20811,20819]
===
match
---
name: task [76543,76547]
name: task [76543,76547]
===
match
---
operator: = [90966,90967]
operator: = [91065,91066]
===
match
---
name: dags [84687,84691]
name: dags [84786,84790]
===
match
---
operator: } [42639,42640]
operator: } [42639,42640]
===
match
---
atom_expr [40815,40846]
atom_expr [40815,40846]
===
match
---
trailer [11591,11598]
trailer [11591,11598]
===
match
---
name: external_trigger [86515,86531]
name: external_trigger [86614,86630]
===
match
---
name: latest [24682,24688]
name: latest [24682,24688]
===
match
---
expr_stmt [15267,15309]
expr_stmt [15267,15309]
===
match
---
trailer [73360,73373]
trailer [73360,73373]
===
match
---
name: _time_restriction [24086,24103]
name: _time_restriction [24086,24103]
===
match
---
name: session [104013,104020]
name: session [104112,104119]
===
match
---
trailer [85993,86002]
trailer [86092,86101]
===
match
---
name: confirm_prompt [65804,65818]
name: confirm_prompt [65804,65818]
===
match
---
decorator [35329,35339]
decorator [35329,35339]
===
match
---
name: DagRunInfo [2358,2368]
name: DagRunInfo [2358,2368]
===
match
---
simple_stmt [27749,27811]
simple_stmt [27749,27811]
===
match
---
argument [28713,28740]
argument [28713,28740]
===
match
---
name: warnings [64441,64449]
name: warnings [64441,64449]
===
match
---
name: dag [71860,71863]
name: dag [71860,71863]
===
match
---
name: List [61474,61478]
name: List [61474,61478]
===
match
---
atom_expr [82626,82640]
atom_expr [82736,82750]
===
match
---
param [55820,55855]
param [55820,55855]
===
match
---
operator: = [11379,11380]
operator: = [11379,11380]
===
match
---
name: dag [86735,86738]
name: dag [86834,86837]
===
match
---
dictorsetmaker [10341,10516]
dictorsetmaker [10341,10516]
===
match
---
name: query [85066,85071]
name: query [85165,85170]
===
match
---
param [11089,11125]
param [11089,11125]
===
match
---
decorated [40899,41306]
decorated [40899,41306]
===
match
---
operator: = [36278,36279]
operator: = [36278,36279]
===
match
---
param [31794,31798]
param [31794,31798]
===
match
---
param [25490,25509]
param [25490,25509]
===
match
---
name: fileloc [87183,87190]
name: fileloc [87282,87289]
===
match
---
number: 0 [66323,66324]
number: 0 [66323,66324]
===
match
---
operator: , [70625,70626]
operator: , [70625,70626]
===
match
---
name: stacklevel [13121,13131]
name: stacklevel [13121,13131]
===
match
---
name: property [32568,32576]
name: property [32568,32576]
===
match
---
name: visited_external_tis [51577,51597]
name: visited_external_tis [51577,51597]
===
match
---
name: SubDagOperator [41527,41541]
name: SubDagOperator [41527,41541]
===
match
---
name: default_args [12815,12827]
name: default_args [12815,12827]
===
match
---
atom [70763,70765]
atom [70763,70765]
===
match
---
param [62208,62227]
param [62208,62227]
===
match
---
name: node [61016,61020]
name: node [61016,61020]
===
match
---
name: paused_dag_id [100276,100289]
name: paused_dag_id [100375,100388]
===
match
---
sync_comp_for [29008,29068]
sync_comp_for [29008,29068]
===
match
---
simple_stmt [87518,87566]
simple_stmt [87617,87665]
===
match
---
name: access_control [31477,31491]
name: access_control [31477,31491]
===
match
---
param [68265,68269]
param [68265,68269]
===
match
---
trailer [41591,41597]
trailer [41591,41597]
===
match
---
argument [67191,67203]
argument [67191,67203]
===
match
---
string: 'task_ids' [18350,18360]
string: 'task_ids' [18350,18360]
===
match
---
atom_expr [96297,96311]
atom_expr [96396,96410]
===
match
---
trailer [49133,49174]
trailer [49133,49174]
===
match
---
operator: , [45433,45434]
operator: , [45433,45434]
===
match
---
name: stacklevel [64801,64811]
name: stacklevel [64801,64811]
===
match
---
simple_stmt [43427,43574]
simple_stmt [43427,43574]
===
match
---
trailer [35478,35483]
trailer [35478,35483]
===
match
---
simple_stmt [68435,68459]
simple_stmt [68435,68459]
===
match
---
trailer [105476,105488]
trailer [105575,105587]
===
match
---
trailer [48688,48703]
trailer [48688,48703]
===
match
---
operator: = [24150,24151]
operator: = [24150,24151]
===
match
---
name: start_date [57955,57965]
name: start_date [57955,57965]
===
match
---
trailer [23479,23496]
trailer [23479,23496]
===
match
---
name: group_by [86582,86590]
name: group_by [86681,86689]
===
match
---
comparison [34280,34305]
comparison [34280,34305]
===
match
---
simple_stmt [23161,23173]
simple_stmt [23161,23173]
===
match
---
name: default_view [87381,87393]
name: default_view [87480,87492]
===
match
---
operator: @ [40638,40639]
operator: @ [40638,40639]
===
match
---
param [55722,55747]
param [55722,55747]
===
match
---
atom_expr [87616,87670]
atom_expr [87715,87769]
===
match
---
name: classmethod [84175,84186]
name: classmethod [84274,84285]
===
match
---
simple_stmt [24431,24490]
simple_stmt [24431,24490]
===
match
---
operator: } [98410,98411]
operator: } [98509,98510]
===
match
---
operator: , [3612,3613]
operator: , [3612,3613]
===
match
---
operator: , [46727,46728]
operator: , [46727,46728]
===
match
---
trailer [55372,55386]
trailer [55372,55386]
===
match
---
operator: , [92849,92850]
operator: , [92948,92949]
===
match
---
atom [48443,48478]
atom [48443,48478]
===
match
---
operator: = [28051,28052]
operator: = [28051,28052]
===
match
---
name: self [50235,50239]
name: self [50235,50239]
===
match
---
tfpdef [47273,47289]
tfpdef [47273,47289]
===
match
---
simple_stmt [74024,74049]
simple_stmt [74024,74049]
===
match
---
comp_if [24186,24201]
comp_if [24186,24201]
===
match
---
atom_expr [49792,49865]
atom_expr [49792,49865]
===
match
---
operator: , [69254,69255]
operator: , [69254,69255]
===
match
---
simple_stmt [25159,25217]
simple_stmt [25159,25217]
===
match
---
dictorsetmaker [71274,71385]
dictorsetmaker [71274,71385]
===
match
---
name: isinstance [60938,60948]
name: isinstance [60938,60948]
===
match
---
trailer [45077,45079]
trailer [45077,45079]
===
match
---
trailer [102423,102437]
trailer [102522,102536]
===
match
---
name: cls [103869,103872]
name: cls [103968,103971]
===
match
---
atom_expr [15760,15779]
atom_expr [15760,15779]
===
match
---
atom_expr [90710,90742]
atom_expr [90809,90841]
===
match
---
name: expression [103754,103764]
name: expression [103853,103863]
===
match
---
param [11695,11740]
param [11695,11740]
===
match
---
trailer [71653,71667]
trailer [71653,71667]
===
match
---
trailer [11598,11633]
trailer [11598,11633]
===
match
---
atom_expr [17622,17638]
atom_expr [17622,17638]
===
match
---
argument [45259,45270]
argument [45259,45270]
===
match
---
argument [107664,107674]
argument [107763,107773]
===
match
---
param [93353,93375]
param [93452,93474]
===
match
---
funcdef [40659,40894]
funcdef [40659,40894]
===
match
---
operator: , [19810,19811]
operator: , [19810,19811]
===
match
---
trailer [70607,70637]
trailer [70607,70637]
===
match
---
name: property [40900,40908]
name: property [40900,40908]
===
match
---
name: serialized_dag [107950,107964]
name: serialized_dag [108049,108063]
===
match
---
name: jinja2 [42470,42476]
name: jinja2 [42470,42476]
===
match
---
param [93347,93352]
param [93446,93451]
===
match
---
operator: = [33169,33170]
operator: = [33169,33170]
===
match
---
decorators [99322,99356]
decorators [99421,99455]
===
match
---
operator: = [97042,97043]
operator: = [97141,97142]
===
match
---
comparison [38678,38707]
comparison [38678,38707]
===
match
---
operator: , [25139,25140]
operator: , [25139,25140]
===
match
---
trailer [70599,70607]
trailer [70599,70607]
===
match
---
simple_stmt [80978,82222]
simple_stmt [80978,82222]
===
match
---
decorated [33528,33782]
decorated [33528,33782]
===
match
---
operator: = [97064,97065]
operator: = [97163,97164]
===
match
---
name: List [56004,56008]
name: List [56004,56008]
===
match
---
atom_expr [108672,108681]
atom_expr [108771,108780]
===
match
---
trailer [39846,39853]
trailer [39846,39853]
===
match
---
or_test [100643,100713]
or_test [100742,100812]
===
match
---
return_stmt [29462,29478]
return_stmt [29462,29478]
===
match
---
name: RUNNING [61323,61330]
name: RUNNING [61323,61330]
===
match
---
name: scalar [40885,40891]
name: scalar [40885,40891]
===
match
---
name: end_date [45732,45740]
name: end_date [45732,45740]
===
match
---
trailer [4013,4019]
trailer [4013,4019]
===
match
---
string: """Print an ASCII tree representation of the DAG.""" [74995,75047]
string: """Print an ASCII tree representation of the DAG.""" [74995,75047]
===
match
---
param [38221,38233]
param [38221,38233]
===
match
---
name: task_ids [91681,91689]
name: task_ids [91780,91788]
===
match
---
trailer [92181,92213]
trailer [92280,92312]
===
match
---
name: copy [70436,70440]
name: copy [70436,70440]
===
match
---
simple_stmt [800,817]
simple_stmt [800,817]
===
match
---
parameters [69289,69483]
parameters [69289,69483]
===
match
---
testlist_comp [58439,58492]
testlist_comp [58439,58492]
===
match
---
name: session [84883,84890]
name: session [84982,84989]
===
match
---
name: d [74195,74196]
name: d [74195,74196]
===
match
---
atom_expr [69332,69372]
atom_expr [69332,69372]
===
match
---
trailer [82671,82687]
trailer [82781,82797]
===
match
---
name: runs [38055,38059]
name: runs [38055,38059]
===
match
---
name: self [94422,94426]
name: self [94521,94525]
===
match
---
trailer [40386,40394]
trailer [40386,40394]
===
match
---
import_from [75351,75386]
import_from [75351,75386]
===
match
---
operator: @ [98020,98021]
operator: @ [98119,98120]
===
match
---
operator: = [68801,68802]
operator: = [68801,68802]
===
match
---
atom_expr [13158,13178]
atom_expr [13158,13178]
===
match
---
name: Index [1413,1418]
name: Index [1413,1418]
===
match
---
argument [53234,53256]
argument [53234,53256]
===
match
---
atom_expr [3312,3339]
atom_expr [3312,3339]
===
match
---
name: graph_unsorted [59669,59683]
name: graph_unsorted [59669,59683]
===
match
---
exprlist [107290,107301]
exprlist [107389,107400]
===
match
---
name: lower [89295,89300]
name: lower [89394,89399]
===
match
---
trailer [37439,37447]
trailer [37439,37447]
===
match
---
name: last_parsed_time [87305,87321]
name: last_parsed_time [87404,87420]
===
match
---
name: subdag [57918,57924]
name: subdag [57918,57924]
===
match
---
parameters [18870,18896]
parameters [18870,18896]
===
match
---
funcdef [55649,58258]
funcdef [55649,58258]
===
match
---
name: subdag_task_groups [72855,72873]
name: subdag_task_groups [72855,72873]
===
match
---
if_stmt [64971,65144]
if_stmt [64971,65144]
===
match
---
string: """         Given a list of dag_ids, get a set of Paused Dag Ids          :param dag_ids: List of Dag ids         :param session: ORM Session         :return: Paused Dag_ids         """ [99853,100038]
string: """         Given a list of dag_ids, get a set of Paused Dag Ids          :param dag_ids: List of Dag ids         :param session: ORM Session         :return: Paused Dag_ids         """ [99952,100137]
===
match
---
name: unique [96871,96877]
name: unique [96970,96976]
===
match
---
operator: = [45462,45463]
operator: = [45462,45463]
===
match
---
name: state [45265,45270]
name: state [45265,45270]
===
match
---
name: c [17998,17999]
name: c [17998,17999]
===
match
---
trailer [45973,45979]
trailer [45973,45979]
===
match
---
fstring_end: " [73970,73971]
fstring_end: " [73970,73971]
===
match
---
simple_stmt [20811,20877]
simple_stmt [20811,20877]
===
match
---
operator: , [44722,44723]
operator: , [44722,44723]
===
match
---
tfpdef [11643,11678]
tfpdef [11643,11678]
===
match
---
operator: { [93725,93726]
operator: { [93824,93825]
===
match
---
operator: , [80098,80099]
operator: , [80098,80099]
===
match
---
name: filter [38621,38627]
name: filter [38621,38627]
===
match
---
expr_stmt [13649,13680]
expr_stmt [13649,13680]
===
match
---
trailer [35022,35028]
trailer [35022,35028]
===
match
---
parameters [80473,80968]
parameters [80473,80968]
===
match
---
name: graph_unsorted [60530,60544]
name: graph_unsorted [60530,60544]
===
match
---
simple_stmt [24138,24203]
simple_stmt [24138,24203]
===
match
---
argument [29203,29230]
argument [29203,29230]
===
match
---
name: task_id [48863,48870]
name: task_id [48863,48870]
===
match
---
name: DR [3889,3891]
name: DR [3889,3891]
===
match
---
atom_expr [61016,61071]
atom_expr [61016,61071]
===
match
---
trailer [39738,39753]
trailer [39738,39753]
===
match
---
operator: = [66069,66070]
operator: = [66069,66070]
===
match
---
simple_stmt [76786,76802]
simple_stmt [76786,76802]
===
match
---
name: session [50868,50875]
name: session [50868,50875]
===
match
---
name: warnings [20946,20954]
name: warnings [20946,20954]
===
match
---
name: DeprecationWarning [30958,30976]
name: DeprecationWarning [30958,30976]
===
match
---
name: user_defined_filters [43308,43328]
name: user_defined_filters [43308,43328]
===
match
---
name: _comps [18258,18264]
name: _comps [18258,18264]
===
match
---
atom_expr [32396,32425]
atom_expr [32396,32425]
===
match
---
name: tags [88351,88355]
name: tags [88450,88454]
===
match
---
trailer [4098,4100]
trailer [4098,4100]
===
match
---
name: start_date [48716,48726]
name: start_date [48716,48726]
===
match
---
operator: , [87843,87844]
operator: , [87942,87943]
===
match
---
operator: , [46946,46947]
operator: , [46946,46947]
===
match
---
atom_expr [27149,27163]
atom_expr [27149,27163]
===
match
---
atom_expr [72583,72619]
atom_expr [72583,72619]
===
match
---
name: tis [51444,51447]
name: tis [51444,51447]
===
match
---
atom_expr [51391,51454]
atom_expr [51391,51454]
===
match
---
parameters [31793,31799]
parameters [31793,31799]
===
match
---
suite [98109,98711]
suite [98208,98810]
===
match
---
operator: , [47122,47123]
operator: , [47122,47123]
===
match
---
argument [45414,45433]
argument [45414,45433]
===
match
---
parameters [68258,68270]
parameters [68258,68270]
===
match
---
name: self [104888,104892]
name: self [104987,104991]
===
match
---
string: "`DAG.previous_schedule()` is deprecated." [21786,21828]
string: "`DAG.previous_schedule()` is deprecated." [21786,21828]
===
match
---
name: _context_managed_dag [108593,108613]
name: _context_managed_dag [108692,108712]
===
match
---
operator: , [1139,1140]
operator: , [1139,1140]
===
match
---
tfpdef [43801,43817]
tfpdef [43801,43817]
===
match
---
name: tii [53873,53876]
name: tii [53873,53876]
===
match
---
expr_stmt [70430,70461]
expr_stmt [70430,70461]
===
match
---
trailer [48509,48518]
trailer [48509,48518]
===
match
---
arglist [88735,88763]
arglist [88834,88862]
===
match
---
simple_stmt [2884,2931]
simple_stmt [2884,2931]
===
match
---
name: start_date [76009,76019]
name: start_date [76009,76019]
===
match
---
arglist [94271,94300]
arglist [94370,94399]
===
match
---
name: update [54919,54925]
name: update [54919,54925]
===
match
---
parameters [40688,40708]
parameters [40688,40708]
===
match
---
name: task_id [71849,71856]
name: task_id [71849,71856]
===
match
---
not_test [18082,18099]
not_test [18082,18099]
===
match
---
name: warn [28589,28593]
name: warn [28589,28593]
===
match
---
suite [12443,17669]
suite [12443,17669]
===
match
---
atom_expr [72786,72812]
atom_expr [72786,72812]
===
match
---
expr_stmt [31514,31584]
expr_stmt [31514,31584]
===
match
---
comparison [85987,86029]
comparison [86086,86128]
===
match
---
operator: = [31352,31353]
operator: = [31352,31353]
===
match
---
name: creating_job_id [83419,83434]
name: creating_job_id [83518,83533]
===
match
---
name: fileloc [33514,33521]
name: fileloc [33514,33521]
===
match
---
simple_stmt [55363,55429]
simple_stmt [55363,55429]
===
match
---
trailer [57924,57930]
trailer [57924,57930]
===
match
---
name: run [83099,83102]
name: run [83198,83201]
===
match
---
name: __eq__ [17742,17748]
name: __eq__ [17742,17748]
===
match
---
expr_stmt [96230,96312]
expr_stmt [96329,96411]
===
match
---
trailer [44267,44275]
trailer [44267,44275]
===
match
---
atom_expr [84746,84755]
atom_expr [84845,84854]
===
match
---
operator: , [28766,28767]
operator: , [28766,28767]
===
match
---
name: DAG [109293,109296]
name: DAG [109392,109395]
===
match
---
operator: , [1818,1819]
operator: , [1818,1819]
===
match
---
operator: , [62148,62149]
operator: , [62148,62149]
===
match
---
name: session [34941,34948]
name: session [34941,34948]
===
match
---
suite [82984,83090]
suite [83083,83189]
===
match
---
name: child [72133,72138]
name: child [72133,72138]
===
match
---
simple_stmt [14675,14815]
simple_stmt [14675,14815]
===
match
---
tfpdef [47367,47391]
tfpdef [47367,47391]
===
match
---
funcdef [31081,31155]
funcdef [31081,31155]
===
match
---
testlist_comp [28990,29068]
testlist_comp [28990,29068]
===
match
---
name: templates [42895,42904]
name: templates [42895,42904]
===
match
---
simple_stmt [17393,17448]
simple_stmt [17393,17448]
===
match
---
trailer [92194,92200]
trailer [92293,92299]
===
match
---
simple_stmt [88474,88508]
simple_stmt [88573,88607]
===
match
---
operator: , [54332,54333]
operator: , [54332,54333]
===
match
---
name: include_dependent_dags [45368,45390]
name: include_dependent_dags [45368,45390]
===
match
---
name: dag_id [94618,94624]
name: dag_id [94717,94723]
===
match
---
operator: = [99642,99643]
operator: = [99741,99742]
===
match
---
name: ti [52753,52755]
name: ti [52753,52755]
===
match
---
trailer [24643,24654]
trailer [24643,24654]
===
match
---
trailer [89071,89088]
trailer [89170,89187]
===
match
---
operator: , [21513,21514]
operator: , [21513,21514]
===
match
---
name: query [103990,103995]
name: query [104089,104094]
===
match
---
simple_stmt [51844,51853]
simple_stmt [51844,51853]
===
match
---
atom [93753,93755]
atom [93852,93854]
===
match
---
sync_comp_for [24166,24201]
sync_comp_for [24166,24201]
===
match
---
name: tags [88181,88185]
name: tags [88280,88284]
===
match
---
simple_stmt [12452,12499]
simple_stmt [12452,12499]
===
match
---
raise_stmt [25269,25338]
raise_stmt [25269,25338]
===
match
---
fstring_expr [82625,82641]
fstring_expr [82735,82751]
===
match
---
name: end_date [61900,61908]
name: end_date [61900,61908]
===
match
---
simple_stmt [86896,86953]
simple_stmt [86995,87052]
===
match
---
name: state [49710,49715]
name: state [49710,49715]
===
match
---
operator: -> [44868,44870]
operator: -> [44868,44870]
===
match
---
atom_expr [60815,60843]
atom_expr [60815,60843]
===
match
---
operator: = [39079,39080]
operator: = [39079,39080]
===
match
---
operator: = [108682,108683]
operator: = [108781,108782]
===
match
---
annassign [47961,47991]
annassign [47961,47991]
===
match
---
simple_stmt [10322,10523]
simple_stmt [10322,10523]
===
match
---
atom_expr [91494,91526]
atom_expr [91593,91625]
===
match
---
simple_stmt [83729,83740]
simple_stmt [83828,83839]
===
match
---
trailer [21967,21977]
trailer [21967,21977]
===
match
---
name: log [2950,2953]
name: log [2950,2953]
===
match
---
name: provide_session [38148,38163]
name: provide_session [38148,38163]
===
match
---
trailer [99466,99472]
trailer [99565,99571]
===
match
---
name: dag_bag [53217,53224]
name: dag_bag [53217,53224]
===
match
---
operator: , [3509,3510]
operator: , [3509,3510]
===
match
---
operator: - [74242,74243]
operator: - [74242,74243]
===
match
---
name: DagPickle [74772,74781]
name: DagPickle [74772,74781]
===
match
---
param [11643,11686]
param [11643,11686]
===
match
---
name: other [17793,17798]
name: other [17793,17798]
===
match
---
name: dag_ids [84820,84827]
name: dag_ids [84919,84926]
===
match
---
argument [20834,20861]
argument [20834,20861]
===
match
---
param [101308,101339]
param [101407,101438]
===
match
---
comp_op [50121,50127]
comp_op [50121,50127]
===
match
---
name: dag [85586,85589]
name: dag [85685,85688]
===
match
---
trailer [80257,80263]
trailer [80257,80263]
===
match
---
name: session [83711,83718]
name: session [83810,83817]
===
match
---
atom_expr [55832,55846]
atom_expr [55832,55846]
===
match
---
simple_stmt [87297,87342]
simple_stmt [87396,87441]
===
match
---
if_stmt [88208,88425]
if_stmt [88307,88524]
===
match
---
suite [93668,93757]
suite [93767,93856]
===
match
---
name: dagrun_timeout [15782,15796]
name: dagrun_timeout [15782,15796]
===
match
---
operator: = [65435,65436]
operator: = [65435,65436]
===
match
---
param [46385,46414]
param [46385,46414]
===
match
---
operator: = [100062,100063]
operator: = [100161,100162]
===
match
---
suite [80969,83740]
suite [80969,83839]
===
match
---
decorator [55628,55645]
decorator [55628,55645]
===
match
---
atom_expr [75104,75140]
atom_expr [75104,75140]
===
match
---
suite [70542,70639]
suite [70542,70639]
===
match
---
trailer [34948,34954]
trailer [34948,34954]
===
match
---
trailer [67245,67250]
trailer [67245,67250]
===
match
---
operator: @ [29750,29751]
operator: @ [29750,29751]
===
match
---
suite [44917,45082]
suite [44917,45082]
===
match
---
name: _task_group [72386,72397]
name: _task_group [72386,72397]
===
match
---
trailer [14692,14704]
trailer [14692,14704]
===
match
---
atom_expr [68861,68872]
atom_expr [68861,68872]
===
match
---
operator: , [85836,85837]
operator: , [85935,85936]
===
match
---
simple_stmt [98629,98711]
simple_stmt [98728,98810]
===
match
---
expr_stmt [28786,28833]
expr_stmt [28786,28833]
===
match
---
testlist_comp [58677,58732]
testlist_comp [58677,58732]
===
match
---
trailer [33500,33508]
trailer [33500,33508]
===
match
---
simple_stmt [15805,15848]
simple_stmt [15805,15848]
===
match
---
not_test [3917,3949]
not_test [3917,3949]
===
match
---
operator: , [54224,54225]
operator: , [54224,54225]
===
match
---
name: Iterable [69358,69366]
name: Iterable [69358,69366]
===
match
---
operator: , [92710,92711]
operator: , [92809,92810]
===
match
---
fstring_start: f" [61141,61143]
fstring_start: f" [61141,61143]
===
match
---
trailer [72032,72040]
trailer [72032,72040]
===
match
---
param [84233,84237]
param [84332,84336]
===
match
---
name: provide_session [89378,89393]
name: provide_session [89477,89492]
===
match
---
name: dag_id [40439,40445]
name: dag_id [40439,40445]
===
match
---
import_from [2015,2059]
import_from [2015,2059]
===
match
---
param [46525,46554]
param [46525,46554]
===
match
---
number: 2 [13484,13485]
number: 2 [13484,13485]
===
match
---
atom_expr [68440,68448]
atom_expr [68440,68448]
===
match
---
suite [48598,48705]
suite [48598,48705]
===
match
---
tfpdef [55700,55712]
tfpdef [55700,55712]
===
match
---
expr_stmt [47955,47991]
expr_stmt [47955,47991]
===
match
---
return_stmt [101101,101146]
return_stmt [101200,101245]
===
match
---
simple_stmt [39612,39642]
simple_stmt [39612,39642]
===
match
---
trailer [15144,15157]
trailer [15144,15157]
===
match
---
arglist [66848,67204]
arglist [66848,67204]
===
match
---
name: Optional [1155,1163]
name: Optional [1155,1163]
===
match
---
atom_expr [54818,54877]
atom_expr [54818,54877]
===
match
---
name: num_active_runs [87813,87828]
name: num_active_runs [87912,87927]
===
match
---
simple_stmt [24255,24291]
simple_stmt [24255,24291]
===
match
---
operator: = [54172,54173]
operator: = [54172,54173]
===
match
---
atom_expr [17393,17421]
atom_expr [17393,17421]
===
match
---
name: dag [74782,74785]
name: dag [74782,74785]
===
match
---
comparison [49362,49392]
comparison [49362,49392]
===
match
---
atom_expr [45112,45586]
atom_expr [45112,45586]
===
match
---
expr_stmt [70555,70638]
expr_stmt [70555,70638]
===
match
---
atom_expr [96607,96626]
atom_expr [96706,96725]
===
match
---
decorator [46255,46265]
decorator [46255,46265]
===
match
---
operator: , [21742,21743]
operator: , [21742,21743]
===
match
---
trailer [61844,61851]
trailer [61844,61851]
===
match
---
trailer [106045,106070]
trailer [106144,106169]
===
match
---
atom_expr [15082,15113]
atom_expr [15082,15113]
===
match
---
operator: = [10574,10575]
operator: = [10574,10575]
===
match
---
argument [83388,83405]
argument [83487,83504]
===
match
---
name: dag_id [85320,85326]
name: dag_id [85419,85425]
===
match
---
name: self [73608,73612]
name: self [73608,73612]
===
match
---
operator: = [50538,50539]
operator: = [50538,50539]
===
match
---
funcdef [73978,74419]
funcdef [73978,74419]
===
match
---
name: self [100988,100992]
name: self [101087,101091]
===
match
---
simple_stmt [90770,90792]
simple_stmt [90869,90891]
===
match
---
name: filter [44289,44295]
name: filter [44289,44295]
===
match
---
expr_stmt [20470,20527]
expr_stmt [20470,20527]
===
match
---
suite [71767,72346]
suite [71767,72346]
===
match
---
name: result [68452,68458]
name: result [68452,68458]
===
match
---
trailer [14747,14760]
trailer [14747,14760]
===
match
---
import_from [3257,3303]
import_from [3257,3303]
===
match
---
name: result [55143,55149]
name: result [55143,55149]
===
match
---
atom_expr [12682,12693]
atom_expr [12682,12693]
===
match
---
name: MANUAL [82920,82926]
name: MANUAL [83019,83025]
===
match
---
name: self [98881,98885]
name: self [98980,98984]
===
match
---
operator: @ [89982,89983]
operator: @ [90081,90082]
===
match
---
funcdef [21236,21711]
funcdef [21236,21711]
===
match
---
trailer [24190,24201]
trailer [24190,24201]
===
match
---
name: self [24274,24278]
name: self [24274,24278]
===
match
---
name: self [93688,93692]
name: self [93787,93791]
===
match
---
expr_stmt [38558,38718]
expr_stmt [38558,38718]
===
match
---
name: get_last_dagrun [99505,99520]
name: get_last_dagrun [99604,99619]
===
match
---
fstring_end: ' [16353,16354]
fstring_end: ' [16353,16354]
===
match
---
simple_stmt [94529,94614]
simple_stmt [94628,94713]
===
match
---
expr_stmt [97629,97664]
expr_stmt [97728,97763]
===
match
---
name: dttm [21744,21748]
name: dttm [21744,21748]
===
match
---
name: update [50377,50383]
name: update [50377,50383]
===
match
---
name: DagParam [31998,32006]
name: DagParam [31998,32006]
===
match
---
argument [57324,57337]
argument [57324,57337]
===
match
---
name: provide_session [80436,80451]
name: provide_session [80436,80451]
===
match
---
trailer [37967,38008]
trailer [37967,38008]
===
match
---
tfpdef [25397,25434]
tfpdef [25397,25434]
===
match
---
atom_expr [73429,73439]
atom_expr [73429,73439]
===
match
---
operator: } [101852,101853]
operator: } [101951,101952]
===
match
---
trailer [37235,37239]
trailer [37235,37239]
===
match
---
arglist [44313,44448]
arglist [44313,44448]
===
match
---
name: dag_hash [80817,80825]
name: dag_hash [80817,80825]
===
match
---
simple_stmt [100047,100249]
simple_stmt [100146,100348]
===
match
---
name: timetable [21958,21967]
name: timetable [21958,21967]
===
match
---
number: 0 [75088,75089]
number: 0 [75088,75089]
===
match
---
fstring_expr [97999,98012]
fstring_expr [98098,98111]
===
match
---
simple_stmt [4080,4101]
simple_stmt [4080,4101]
===
match
---
argument [35918,35930]
argument [35918,35930]
===
match
---
simple_stmt [74882,74899]
simple_stmt [74882,74899]
===
match
---
name: utils [67647,67652]
name: utils [67647,67652]
===
match
---
operator: = [57154,57155]
operator: = [57154,57155]
===
match
---
name: format_exc [74389,74399]
name: format_exc [74389,74399]
===
match
---
name: self [14824,14828]
name: self [14824,14828]
===
match
---
name: Type [11227,11231]
name: Type [11227,11231]
===
match
---
name: max_recursion_depth [52269,52288]
name: max_recursion_depth [52269,52288]
===
match
---
trailer [52028,52033]
trailer [52028,52033]
===
match
---
name: dag_id [97080,97086]
name: dag_id [97179,97185]
===
match
---
name: conf [1744,1748]
name: conf [1744,1748]
===
match
---
trailer [35239,35246]
trailer [35239,35246]
===
match
---
name: query [51323,51328]
name: query [51323,51328]
===
match
---
operator: = [70569,70570]
operator: = [70569,70570]
===
match
---
atom_expr [55387,55396]
atom_expr [55387,55396]
===
match
---
tfpdef [46492,46515]
tfpdef [46492,46515]
===
match
---
name: task_ids [50457,50465]
name: task_ids [50457,50465]
===
match
---
suite [74489,74953]
suite [74489,74953]
===
match
---
for_stmt [38044,38113]
for_stmt [38044,38113]
===
match
---
name: as_pk_tuple [46563,46574]
name: as_pk_tuple [46563,46574]
===
match
---
name: query [100086,100091]
name: query [100185,100190]
===
match
---
param [45953,45980]
param [45953,45980]
===
match
---
return_stmt [58243,58257]
return_stmt [58243,58257]
===
match
---
number: 2 [69201,69202]
number: 2 [69201,69202]
===
match
---
name: num_active_runs [86289,86304]
name: num_active_runs [86388,86403]
===
match
---
comparison [41745,41784]
comparison [41745,41784]
===
match
---
simple_stmt [97911,97951]
simple_stmt [98010,98050]
===
match
---
atom_expr [10941,10967]
atom_expr [10941,10967]
===
match
---
simple_stmt [13840,13885]
simple_stmt [13840,13885]
===
match
---
suite [36194,36233]
suite [36194,36233]
===
match
---
name: flush [88668,88673]
name: flush [88767,88772]
===
match
---
name: group [71427,71432]
name: group [71427,71432]
===
match
---
name: self [35740,35744]
name: self [35740,35744]
===
match
---
atom_expr [33752,33759]
atom_expr [33752,33759]
===
match
---
name: relative_to [101113,101124]
name: relative_to [101212,101223]
===
match
---
string: 'tree' [3421,3427]
string: 'tree' [3421,3427]
===
match
---
trailer [13606,13617]
trailer [13606,13617]
===
match
---
name: relationship [96997,97009]
name: relationship [97096,97108]
===
match
---
trailer [84896,84906]
trailer [84995,85005]
===
match
---
suite [67699,68127]
suite [67699,68127]
===
match
---
operator: = [11256,11257]
operator: = [11256,11257]
===
match
---
name: self [97969,97973]
name: self [98068,98072]
===
match
---
arglist [52703,52763]
arglist [52703,52763]
===
match
---
name: next_dagrun_create_after [96754,96778]
name: next_dagrun_create_after [96853,96877]
===
match
---
operator: = [17287,17288]
operator: = [17287,17288]
===
match
---
name: is_subdag [23138,23147]
name: is_subdag [23138,23147]
===
match
---
suite [98975,99069]
suite [99074,99168]
===
match
---
name: task [52036,52040]
name: task [52036,52040]
===
match
---
name: include_parentdag [62296,62313]
name: include_parentdag [62296,62313]
===
match
---
name: Collection [84244,84254]
name: Collection [84343,84353]
===
match
---
trailer [25191,25216]
trailer [25191,25216]
===
match
---
trailer [4049,4075]
trailer [4049,4075]
===
match
---
operator: < [90484,90485]
operator: < [90583,90584]
===
match
---
trailer [73907,73916]
trailer [73907,73916]
===
match
---
import_from [2700,2754]
import_from [2700,2754]
===
match
---
string: 'end_date' [15126,15136]
string: 'end_date' [15126,15136]
===
match
---
name: end_date [77304,77312]
name: end_date [77304,77312]
===
match
---
name: end_date [28964,28972]
name: end_date [28964,28972]
===
match
---
tfpdef [55722,55746]
tfpdef [55722,55746]
===
match
---
operator: = [61484,61485]
operator: = [61484,61485]
===
match
---
name: schedule_interval [15272,15289]
name: schedule_interval [15272,15289]
===
match
---
operator: , [84158,84159]
operator: , [84257,84258]
===
match
---
operator: , [41220,41221]
operator: , [41220,41221]
===
match
---
raise_stmt [82318,82386]
raise_stmt [82342,82410]
===
match
---
trailer [70396,70414]
trailer [70396,70414]
===
match
---
name: has_task [73502,73510]
name: has_task [73502,73510]
===
match
---
operator: , [46957,46958]
operator: , [46957,46958]
===
match
---
atom_expr [43629,43662]
atom_expr [43629,43662]
===
match
---
name: info [27706,27710]
name: info [27706,27710]
===
match
---
number: 1 [49326,49327]
number: 1 [49326,49327]
===
match
---
operator: , [64565,64566]
operator: , [64565,64566]
===
match
---
name: result [55004,55010]
name: result [55004,55010]
===
match
---
expr_stmt [76201,76230]
expr_stmt [76201,76230]
===
match
---
name: filter [51543,51549]
name: filter [51543,51549]
===
match
---
name: self [15478,15482]
name: self [15478,15482]
===
match
---
operator: , [77345,77346]
operator: , [77345,77346]
===
match
---
name: desc [44507,44511]
name: desc [44507,44511]
===
match
---
simple_stmt [34152,34170]
simple_stmt [34152,34170]
===
match
---
atom_expr [35964,35986]
atom_expr [35964,35986]
===
match
---
expr_stmt [70748,70765]
expr_stmt [70748,70765]
===
match
---
string: 'start_date' [15042,15054]
string: 'start_date' [15042,15054]
===
match
---
trailer [61140,61195]
trailer [61140,61195]
===
match
---
name: types [3196,3201]
name: types [3196,3201]
===
match
---
operator: , [25469,25470]
operator: , [25469,25470]
===
match
---
simple_stmt [107662,107676]
simple_stmt [107761,107775]
===
match
---
name: max_active_tasks [97704,97720]
name: max_active_tasks [97803,97819]
===
match
---
name: run_type [82631,82639]
name: run_type [82741,82749]
===
match
---
name: log [105415,105418]
name: log [105514,105517]
===
match
---
name: Optional [31629,31637]
name: Optional [31629,31637]
===
match
---
name: self [14067,14071]
name: self [14067,14071]
===
match
---
operator: , [59422,59423]
operator: , [59422,59423]
===
match
---
param [84238,84262]
param [84337,84361]
===
match
---
name: query [51675,51680]
name: query [51675,51680]
===
match
---
operator: , [10413,10414]
operator: , [10413,10414]
===
match
---
operator: , [80961,80962]
operator: , [80961,80962]
===
match
---
testlist_comp [3421,3474]
testlist_comp [3421,3474]
===
match
---
name: warn [12981,12985]
name: warn [12981,12985]
===
match
---
test [13792,13831]
test [13792,13831]
===
match
---
name: mark_tasks [56981,56991]
name: mark_tasks [56981,56991]
===
match
---
funcdef [32764,32996]
funcdef [32764,32996]
===
match
---
name: Optional [25407,25415]
name: Optional [25407,25415]
===
match
---
trailer [88717,88734]
trailer [88816,88833]
===
match
---
name: include_subdag_tasks [61045,61065]
name: include_subdag_tasks [61045,61065]
===
match
---
funcdef [32449,32562]
funcdef [32449,32562]
===
match
---
atom_expr [49529,49558]
atom_expr [49529,49558]
===
match
---
name: start_date [24219,24229]
name: start_date [24219,24229]
===
match
---
trailer [61785,61794]
trailer [61785,61794]
===
match
---
atom_expr [12262,12276]
atom_expr [12262,12276]
===
match
---
trailer [75109,75140]
trailer [75109,75140]
===
match
---
name: utils [66071,66076]
name: utils [66071,66076]
===
match
---
param [77461,77484]
param [77461,77484]
===
match
---
return_stmt [33223,33268]
return_stmt [33223,33268]
===
match
---
simple_stmt [73224,73302]
simple_stmt [73224,73302]
===
match
---
operator: , [62198,62199]
operator: , [62198,62199]
===
match
---
trailer [38604,38606]
trailer [38604,38606]
===
match
---
atom_expr [83814,83831]
atom_expr [83913,83930]
===
match
---
name: DagRunInfo [27755,27765]
name: DagRunInfo [27755,27765]
===
match
---
trailer [39708,39715]
trailer [39708,39715]
===
match
---
arglist [57680,57781]
arglist [57680,57781]
===
match
---
name: desc [4068,4072]
name: desc [4068,4072]
===
match
---
operator: , [46164,46165]
operator: , [46164,46165]
===
match
---
name: verbose [80017,80024]
name: verbose [80017,80024]
===
match
---
atom [18223,18235]
atom [18223,18235]
===
match
---
operator: , [12227,12228]
operator: , [12227,12228]
===
match
---
atom_expr [33045,33057]
atom_expr [33045,33057]
===
match
---
import_from [79322,79380]
import_from [79322,79380]
===
match
---
tfpdef [62328,62354]
tfpdef [62328,62354]
===
match
---
name: pickled [74174,74181]
name: pickled [74174,74181]
===
match
---
name: session [104005,104012]
name: session [104104,104111]
===
match
---
name: __table_args__ [96806,96820]
name: __table_args__ [96905,96919]
===
match
---
decorated [29505,29745]
decorated [29505,29745]
===
match
---
name: default_view [11749,11761]
name: default_view [11749,11761]
===
match
---
atom_expr [34209,34219]
atom_expr [34209,34219]
===
match
---
atom_expr [76072,76087]
atom_expr [76072,76087]
===
match
---
atom_expr [49351,49393]
atom_expr [49351,49393]
===
match
---
name: also_include [71373,71385]
name: also_include [71373,71385]
===
match
---
trailer [30196,30204]
trailer [30196,30204]
===
match
---
operator: = [47984,47985]
operator: = [47984,47985]
===
match
---
arglist [52927,53096]
arglist [52927,53096]
===
match
---
simple_stmt [72098,72148]
simple_stmt [72098,72148]
===
match
---
trailer [24045,24055]
trailer [24045,24055]
===
match
---
operator: = [104012,104013]
operator: = [104111,104112]
===
match
---
operator: , [55712,55713]
operator: , [55712,55713]
===
match
---
name: stacklevel [64345,64355]
name: stacklevel [64345,64355]
===
match
---
arglist [99622,99709]
arglist [99721,99808]
===
match
---
name: add_task [77228,77236]
name: add_task [77228,77236]
===
match
---
trailer [18404,18409]
trailer [18404,18409]
===
match
---
suite [3650,4101]
suite [3650,4101]
===
match
---
atom_expr [74081,74098]
atom_expr [74081,74098]
===
match
---
name: tasks [24180,24185]
name: tasks [24180,24185]
===
match
---
simple_stmt [99116,99141]
simple_stmt [99215,99240]
===
match
---
name: start_date [24279,24289]
name: start_date [24279,24289]
===
match
---
atom_expr [58296,58314]
atom_expr [58296,58314]
===
match
---
decorated [29750,30050]
decorated [29750,30050]
===
match
---
expr_stmt [76738,76773]
expr_stmt [76738,76773]
===
match
---
trailer [47258,47263]
trailer [47258,47263]
===
match
---
name: access_control [31447,31461]
name: access_control [31447,31461]
===
match
---
trailer [67660,67670]
trailer [67660,67670]
===
match
---
atom_expr [24640,24654]
atom_expr [24640,24654]
===
match
---
name: nullable [96420,96428]
name: nullable [96519,96527]
===
match
---
tfpdef [47025,47053]
tfpdef [47025,47053]
===
match
---
operator: <= [103818,103820]
operator: <= [103917,103919]
===
match
---
operator: , [92964,92965]
operator: , [93063,93064]
===
match
---
name: get_num_task_instances [90900,90922]
name: get_num_task_instances [90999,91021]
===
match
---
name: in_ [86422,86425]
name: in_ [86521,86524]
===
match
---
expr_stmt [87260,87284]
expr_stmt [87359,87383]
===
match
---
name: warn [61524,61528]
name: warn [61524,61528]
===
match
---
param [69416,69438]
param [69416,69438]
===
match
---
name: self [31514,31518]
name: self [31514,31518]
===
match
---
name: Optional [98797,98805]
name: Optional [98896,98904]
===
match
---
name: include_downstream [57721,57739]
name: include_downstream [57721,57739]
===
match
---
trailer [102018,102023]
trailer [102117,102122]
===
match
---
simple_stmt [95198,95237]
simple_stmt [95297,95336]
===
match
---
name: user_defined_macros [68695,68714]
name: user_defined_macros [68695,68714]
===
match
---
operator: = [42259,42260]
operator: = [42259,42260]
===
match
---
operator: , [101853,101854]
operator: , [101952,101953]
===
match
---
argument [67044,67075]
argument [67044,67075]
===
match
---
trailer [48749,48756]
trailer [48749,48756]
===
match
---
name: append [86789,86795]
name: append [86888,86894]
===
match
---
atom_expr [73374,73394]
atom_expr [73374,73394]
===
match
---
trailer [70885,70901]
trailer [70885,70901]
===
match
---
decorated [99725,100358]
decorated [99824,100457]
===
match
---
argument [44683,44702]
argument [44683,44702]
===
match
---
name: normalize_schedule [29079,29097]
name: normalize_schedule [29079,29097]
===
match
---
name: DAG [108624,108627]
name: DAG [108723,108726]
===
match
---
operator: , [65249,65250]
operator: , [65249,65250]
===
match
---
operator: @ [100812,100813]
operator: @ [100911,100912]
===
match
---
trailer [45068,45072]
trailer [45068,45072]
===
match
---
name: include_subdags [45288,45303]
name: include_subdags [45288,45303]
===
match
---
suite [74754,74934]
suite [74754,74934]
===
match
---
atom_expr [96499,96518]
atom_expr [96598,96617]
===
match
---
and_test [27692,27735]
and_test [27692,27735]
===
match
---
name: earliest [26438,26446]
name: earliest [26438,26446]
===
match
---
name: t [75305,75306]
name: t [75305,75306]
===
match
---
name: full_filepath [30486,30499]
name: full_filepath [30486,30499]
===
match
---
trailer [20954,20959]
trailer [20954,20959]
===
match
---
operator: = [66614,66615]
operator: = [66614,66615]
===
match
---
name: bool [47151,47155]
name: bool [47151,47155]
===
match
---
name: filter [49756,49762]
name: filter [49756,49762]
===
match
---
dictorsetmaker [84779,84810]
dictorsetmaker [84878,84909]
===
match
---
suite [49051,49175]
suite [49051,49175]
===
match
---
return_stmt [39888,39908]
return_stmt [39888,39908]
===
match
---
suite [88826,89089]
suite [88925,89188]
===
match
---
simple_stmt [107996,108055]
simple_stmt [108095,108154]
===
match
---
name: self [31713,31717]
name: self [31713,31717]
===
match
---
name: tis [49351,49354]
name: tis [49351,49354]
===
match
---
name: str [16929,16932]
name: str [16929,16932]
===
match
---
operator: , [13133,13134]
operator: , [13133,13134]
===
match
---
atom_expr [43208,43232]
atom_expr [43208,43232]
===
match
---
name: utils [2944,2949]
name: utils [2944,2949]
===
match
---
trailer [86414,86421]
trailer [86513,86520]
===
match
---
name: str [49227,49230]
name: str [49227,49230]
===
match
---
suite [47530,55623]
suite [47530,55623]
===
match
---
operator: , [74460,74461]
operator: , [74460,74461]
===
match
---
operator: = [74586,74587]
operator: = [74586,74587]
===
match
---
operator: == [41819,41821]
operator: == [41819,41821]
===
match
---
name: dag [89881,89884]
name: dag [89980,89983]
===
match
---
tfpdef [12350,12385]
tfpdef [12350,12385]
===
match
---
operator: , [45241,45242]
operator: , [45241,45242]
===
match
---
name: warnings [64178,64186]
name: warnings [64178,64186]
===
match
---
name: run [83561,83564]
name: run [83660,83663]
===
match
---
name: sqlalchemy [3057,3067]
name: sqlalchemy [3057,3067]
===
match
---
expr_stmt [87518,87565]
expr_stmt [87617,87664]
===
match
---
string: "DagBag" [46678,46686]
string: "DagBag" [46678,46686]
===
match
---
trailer [18557,18562]
trailer [18557,18562]
===
match
---
number: 2 [32942,32943]
number: 2 [32942,32943]
===
match
---
name: conf [77412,77416]
name: conf [77412,77416]
===
match
---
param [98784,98789]
param [98883,98888]
===
match
---
atom_expr [106647,106697]
atom_expr [106746,106796]
===
match
---
name: dag_bound_args [106827,106841]
name: dag_bound_args [106926,106940]
===
match
---
atom_expr [24615,24655]
atom_expr [24615,24655]
===
match
---
dotted_name [2254,2270]
dotted_name [2254,2270]
===
match
---
name: TaskInstance [49951,49963]
name: TaskInstance [49951,49963]
===
match
---
trailer [32633,32656]
trailer [32633,32656]
===
match
---
expr_stmt [12620,12673]
expr_stmt [12620,12673]
===
match
---
arglist [70450,70460]
arglist [70450,70460]
===
match
---
operator: += [75159,75161]
operator: += [75159,75161]
===
match
---
operator: , [97519,97520]
operator: , [97618,97619]
===
match
---
trailer [23722,23727]
trailer [23722,23727]
===
match
---
name: commit [89950,89956]
name: commit [90049,90055]
===
match
---
operator: = [98918,98919]
operator: = [99017,99018]
===
match
---
name: task_dict [13845,13854]
name: task_dict [13845,13854]
===
match
---
name: str [99801,99804]
name: str [99900,99903]
===
match
---
name: airflow [1754,1761]
name: airflow [1754,1761]
===
match
---
operator: , [3503,3504]
operator: , [3503,3504]
===
match
---
name: start_date [79651,79661]
name: start_date [79651,79661]
===
match
---
name: relativedelta [1298,1311]
name: relativedelta [1298,1311]
===
match
---
name: dag [71244,71247]
name: dag [71244,71247]
===
match
---
atom_expr [14886,14899]
atom_expr [14886,14899]
===
match
---
atom_expr [23465,23609]
atom_expr [23465,23609]
===
match
---
param [30774,30778]
param [30774,30778]
===
match
---
name: orientation [16225,16236]
name: orientation [16225,16236]
===
match
---
operator: = [31941,31942]
operator: = [31941,31942]
===
match
---
atom_expr [71274,71283]
atom_expr [71274,71283]
===
match
---
trailer [14410,14419]
trailer [14410,14419]
===
match
---
name: dag_bag [54325,54332]
name: dag_bag [54325,54332]
===
match
---
operator: += [64891,64893]
operator: += [64891,64893]
===
match
---
name: query [3872,3877]
name: query [3872,3877]
===
match
---
number: 1.0 [77575,77578]
number: 1.0 [77575,77578]
===
match
---
name: self [30529,30533]
name: self [30529,30533]
===
match
---
operator: = [96605,96606]
operator: = [96704,96705]
===
match
---
name: fallback [97213,97221]
name: fallback [97312,97320]
===
match
---
suite [21271,21711]
suite [21271,21711]
===
match
---
atom_expr [61474,61483]
atom_expr [61474,61483]
===
match
---
simple_stmt [1878,1931]
simple_stmt [1878,1931]
===
match
---
name: filter [103660,103666]
name: filter [103759,103765]
===
match
---
arglist [11929,11962]
arglist [11929,11962]
===
match
---
simple_stmt [58669,58734]
simple_stmt [58669,58734]
===
match
---
name: DR [3980,3982]
name: DR [3980,3982]
===
match
---
name: count [66418,66423]
name: count [66418,66423]
===
match
---
name: category [23847,23855]
name: category [23847,23855]
===
match
---
parameters [106119,106136]
parameters [106218,106235]
===
match
---
atom_expr [30834,31013]
atom_expr [30834,31013]
===
match
---
number: 2 [13132,13133]
number: 2 [13132,13133]
===
match
---
if_stmt [65757,65793]
if_stmt [65757,65793]
===
match
---
name: List [12418,12422]
name: List [12418,12422]
===
match
---
decorated [108692,108910]
decorated [108791,109009]
===
match
---
atom_expr [72248,72271]
atom_expr [72248,72271]
===
match
---
suite [97278,97951]
suite [97377,98050]
===
match
---
string: "Setting next_dagrun for %s to %s" [105424,105458]
string: "Setting next_dagrun for %s to %s" [105523,105557]
===
match
---
trailer [58537,58551]
trailer [58537,58551]
===
match
---
operator: = [70434,70435]
operator: = [70434,70435]
===
match
---
expr_stmt [80373,80399]
expr_stmt [80373,80399]
===
match
---
operator: , [62526,62527]
operator: , [62526,62527]
===
match
---
trailer [51393,51408]
trailer [51393,51408]
===
match
---
trailer [107491,107498]
trailer [107590,107597]
===
match
---
string: """         Returns a list of dates between the interval received as parameter using this         dag's schedule interval. Returned dates can be used for execution dates.          :param start_date: The start date of the interval.         :type start_date: datetime         :param end_date: The end date of the interval. Defaults to ``timezone.utcnow()``.         :type end_date: datetime         :return: A list of dates within the interval following the dag's schedule.         :rtype: list         """ [28067,28571]
string: """         Returns a list of dates between the interval received as parameter using this         dag's schedule interval. Returned dates can be used for execution dates.          :param start_date: The start date of the interval.         :type start_date: datetime         :param end_date: The end date of the interval. Defaults to ``timezone.utcnow()``.         :type end_date: datetime         :return: A list of dates within the interval following the dag's schedule.         :rtype: list         """ [28067,28571]
===
match
---
operator: , [97177,97178]
operator: , [97276,97277]
===
match
---
operator: = [34939,34940]
operator: = [34939,34940]
===
match
---
name: cls [109314,109317]
name: cls [109413,109416]
===
match
---
trailer [50158,50169]
trailer [50158,50169]
===
match
---
name: templates [1611,1620]
name: templates [1611,1620]
===
match
---
param [19078,19097]
param [19078,19097]
===
match
---
atom_expr [101823,101841]
atom_expr [101922,101940]
===
match
---
trailer [106671,106675]
trailer [106770,106774]
===
match
---
argument [106057,106069]
argument [106156,106168]
===
match
---
atom_expr [53293,53337]
atom_expr [53293,53337]
===
match
---
name: date_last_automated_dagrun [22140,22166]
name: date_last_automated_dagrun [22140,22166]
===
match
---
name: self [73733,73737]
name: self [73733,73737]
===
match
---
operator: = [76410,76411]
operator: = [76410,76411]
===
match
---
trailer [99308,99316]
trailer [99407,99415]
===
match
---
simple_stmt [31413,31441]
simple_stmt [31413,31441]
===
match
---
arglist [21500,21540]
arglist [21500,21540]
===
match
---
atom_expr [109037,109071]
atom_expr [109136,109170]
===
match
---
name: Column [96607,96613]
name: Column [96706,96712]
===
match
---
name: convert_to_utc [15067,15081]
name: convert_to_utc [15067,15081]
===
match
---
trailer [76790,76794]
trailer [76790,76794]
===
match
---
atom_expr [70967,71002]
atom_expr [70967,71002]
===
match
---
trailer [108976,108981]
trailer [109075,109080]
===
match
---
name: DuplicateTaskIdFound [76628,76648]
name: DuplicateTaskIdFound [76628,76648]
===
match
---
param [80711,80739]
param [80711,80739]
===
match
---
atom_expr [107515,107530]
atom_expr [107614,107629]
===
match
---
name: Optional [35749,35757]
name: Optional [35749,35757]
===
match
---
name: tis [55369,55372]
name: tis [55369,55372]
===
match
---
name: next_dagrun [105477,105488]
name: next_dagrun [105576,105587]
===
match
---
operator: , [30382,30383]
operator: , [30382,30383]
===
match
---
arglist [60949,60969]
arglist [60949,60969]
===
match
---
name: self [34743,34747]
name: self [34743,34747]
===
match
---
operator: , [97248,97249]
operator: , [97347,97348]
===
match
---
simple_stmt [24606,24656]
simple_stmt [24606,24656]
===
match
---
operator: , [69406,69407]
operator: , [69406,69407]
===
match
---
trailer [52830,52847]
trailer [52830,52847]
===
match
---
name: coerce_datetime [24624,24639]
name: coerce_datetime [24624,24639]
===
match
---
if_stmt [3235,3304]
if_stmt [3235,3304]
===
match
---
suite [92410,93285]
suite [92509,93384]
===
match
---
trailer [43200,43207]
trailer [43200,43207]
===
match
---
trailer [76937,76951]
trailer [76937,76951]
===
match
---
name: is_subdag [50091,50100]
name: is_subdag [50091,50100]
===
match
---
name: run_type [44418,44426]
name: run_type [44418,44426]
===
match
---
and_test [13936,13968]
and_test [13936,13968]
===
match
---
name: dag_id [30128,30134]
name: dag_id [30128,30134]
===
match
---
trailer [19801,19805]
trailer [19801,19805]
===
match
---
comparison [65760,65770]
comparison [65760,65770]
===
match
---
operator: , [27519,27520]
operator: , [27519,27520]
===
match
---
trailer [74511,74517]
trailer [74511,74517]
===
match
---
annassign [21940,21977]
annassign [21940,21977]
===
match
---
name: default_args [15232,15244]
name: default_args [15232,15244]
===
match
---
comp_op [17254,17260]
comp_op [17254,17260]
===
match
---
simple_stmt [32622,32657]
simple_stmt [32622,32657]
===
match
---
decorated [101923,102992]
decorated [102022,103091]
===
match
---
atom_expr [94338,94362]
atom_expr [94437,94461]
===
match
---
with_item [106822,106883]
with_item [106921,106982]
===
match
---
decorator [41311,41321]
decorator [41311,41321]
===
match
---
expr_stmt [53278,53337]
expr_stmt [53278,53337]
===
match
---
name: cls [103684,103687]
name: cls [103783,103786]
===
match
---
parameters [17686,17692]
parameters [17686,17692]
===
match
---
operator: , [84261,84262]
operator: , [84360,84361]
===
match
---
name: result [54644,54650]
name: result [54644,54650]
===
match
---
atom_expr [44313,44326]
atom_expr [44313,44326]
===
match
---
operator: = [15734,15735]
operator: = [15734,15735]
===
match
---
name: self [42720,42724]
name: self [42720,42724]
===
match
---
operator: += [41928,41930]
operator: += [41928,41930]
===
match
---
name: TaskInstance [34157,34169]
name: TaskInstance [34157,34169]
===
match
---
funcdef [100733,100807]
funcdef [100832,100906]
===
match
---
param [66735,66749]
param [66735,66749]
===
match
---
simple_stmt [3038,3126]
simple_stmt [3038,3126]
===
match
---
name: restriction [27245,27256]
name: restriction [27245,27256]
===
match
---
name: TaskInstance [49134,49146]
name: TaskInstance [49134,49146]
===
match
---
simple_stmt [17702,17733]
simple_stmt [17702,17733]
===
match
---
atom_expr [76412,76445]
atom_expr [76412,76445]
===
match
---
name: models [1846,1852]
name: models [1846,1852]
===
match
---
simple_stmt [94460,94498]
simple_stmt [94559,94597]
===
match
---
name: default_args [12865,12877]
name: default_args [12865,12877]
===
match
---
name: DagRun [40432,40438]
name: DagRun [40432,40438]
===
match
---
operator: , [50745,50746]
operator: , [50745,50746]
===
match
---
expr_stmt [14181,14262]
expr_stmt [14181,14262]
===
match
---
operator: ** [69256,69258]
operator: ** [69256,69258]
===
match
---
argument [68045,68072]
argument [68045,68072]
===
match
---
atom_expr [76488,76502]
atom_expr [76488,76502]
===
match
---
suite [51158,54632]
suite [51158,54632]
===
match
---
trailer [37962,37967]
trailer [37962,37967]
===
match
---
name: models [2120,2126]
name: models [2120,2126]
===
match
---
atom_expr [70693,70703]
atom_expr [70693,70703]
===
match
---
funcdef [20904,21231]
funcdef [20904,21231]
===
match
---
atom_expr [98468,98502]
atom_expr [98567,98601]
===
match
---
trailer [25130,25145]
trailer [25130,25145]
===
match
---
name: downstream_list [75190,75205]
name: downstream_list [75190,75205]
===
match
---
simple_stmt [53217,53258]
simple_stmt [53217,53258]
===
match
---
name: dag_tag_orm [88412,88423]
name: dag_tag_orm [88511,88522]
===
match
---
trailer [38937,38944]
trailer [38937,38944]
===
match
---
suite [33058,33363]
suite [33058,33363]
===
match
---
operator: , [97211,97212]
operator: , [97310,97311]
===
match
---
expr_stmt [41551,41566]
expr_stmt [41551,41566]
===
match
---
atom_expr [48365,48377]
atom_expr [48365,48377]
===
match
---
funcdef [101961,102992]
funcdef [102060,103091]
===
match
---
name: get_template_context [37474,37494]
name: get_template_context [37474,37494]
===
match
---
name: filter [74669,74675]
name: filter [74669,74675]
===
match
---
argument [50934,50965]
argument [50934,50965]
===
match
---
expr_stmt [65832,65872]
expr_stmt [65832,65872]
===
match
---
tfpdef [11749,11766]
tfpdef [11749,11766]
===
match
---
trailer [37427,37436]
trailer [37427,37436]
===
match
---
name: dag [66821,66824]
name: dag [66821,66824]
===
match
---
trailer [38817,38834]
trailer [38817,38834]
===
match
---
name: tis [65673,65676]
name: tis [65673,65676]
===
match
---
name: e [74308,74309]
name: e [74308,74309]
===
match
---
sync_comp_for [100290,100326]
sync_comp_for [100389,100425]
===
match
---
operator: = [51006,51007]
operator: = [51006,51007]
===
match
---
param [61465,61491]
param [61465,61491]
===
match
---
name: dag_by_ids [86741,86751]
name: dag_by_ids [86840,86850]
===
match
---
trailer [37337,37339]
trailer [37337,37339]
===
match
---
operator: , [80566,80567]
operator: , [80566,80567]
===
match
---
trailer [51549,51560]
trailer [51549,51560]
===
match
---
simple_stmt [68861,68885]
simple_stmt [68861,68885]
===
match
---
atom_expr [20311,20329]
atom_expr [20311,20329]
===
match
---
name: self [50105,50109]
name: self [50105,50109]
===
match
---
name: external_dag [53495,53507]
name: external_dag [53495,53507]
===
match
---
string: """This is only there for backward compatible jinja2 templates""" [89130,89195]
string: """This is only there for backward compatible jinja2 templates""" [89229,89294]
===
match
---
operator: } [82640,82641]
operator: } [82750,82751]
===
match
---
argument [74782,74790]
argument [74782,74790]
===
match
---
operator: = [61837,61838]
operator: = [61837,61838]
===
match
---
name: pendulum [25452,25460]
name: pendulum [25452,25460]
===
match
---
name: state [45259,45264]
name: state [45259,45264]
===
match
---
name: taskinstance [2168,2180]
name: taskinstance [2168,2180]
===
match
---
name: self [97699,97703]
name: self [97798,97802]
===
match
---
operator: = [95895,95896]
operator: = [95994,95995]
===
match
---
name: partial [16566,16573]
name: partial [16566,16573]
===
match
---
name: interval [25242,25250]
name: interval [25242,25250]
===
match
---
param [36411,36423]
param [36411,36423]
===
match
---
name: future [57834,57840]
name: future [57834,57840]
===
match
---
atom_expr [71860,71873]
atom_expr [71860,71873]
===
match
---
name: subdag [57638,57644]
name: subdag [57638,57644]
===
match
---
import_as_names [1480,1513]
import_as_names [1480,1513]
===
match
---
trailer [11810,11816]
trailer [11810,11816]
===
match
---
name: self [16561,16565]
name: self [16561,16565]
===
match
---
arglist [101822,101882]
arglist [101921,101981]
===
match
---
name: execution_date [83199,83213]
name: execution_date [83298,83312]
===
match
---
arglist [18461,18474]
arglist [18461,18474]
===
match
---
trailer [53041,53056]
trailer [53041,53056]
===
match
---
name: _pickle_id [31930,31940]
name: _pickle_id [31930,31940]
===
match
---
trailer [107380,107393]
trailer [107479,107492]
===
match
---
name: ti [52026,52028]
name: ti [52026,52028]
===
match
---
decorator [109239,109252]
decorator [109338,109351]
===
match
---
name: visited_external_tis [46778,46798]
name: visited_external_tis [46778,46798]
===
match
---
trailer [107358,107364]
trailer [107457,107463]
===
match
---
operator: @ [31446,31447]
operator: @ [31446,31447]
===
match
---
atom_expr [39534,39603]
atom_expr [39534,39603]
===
match
---
atom_expr [57091,57377]
atom_expr [57091,57377]
===
match
---
trailer [12852,12859]
trailer [12852,12859]
===
match
---
comparison [17153,17189]
comparison [17153,17189]
===
match
---
atom_expr [76431,76444]
atom_expr [76431,76444]
===
match
---
atom_expr [105976,105999]
atom_expr [106075,106098]
===
match
---
name: is_paused [101832,101841]
name: is_paused [101931,101940]
===
match
---
operator: , [61363,61364]
operator: , [61363,61364]
===
match
---
name: info [27931,27935]
name: info [27931,27935]
===
match
---
name: permissions [19615,19626]
name: permissions [19615,19626]
===
match
---
or_test [41632,41838]
or_test [41632,41838]
===
match
---
name: dp [74767,74769]
name: dp [74767,74769]
===
match
---
expr_stmt [108879,108909]
expr_stmt [108978,109008]
===
match
---
atom_expr [45539,45566]
atom_expr [45539,45566]
===
match
---
name: dag [84799,84802]
name: dag [84898,84901]
===
match
---
parameters [35739,35745]
parameters [35739,35745]
===
match
---
name: next_dagrun_data_interval_start [98886,98917]
name: next_dagrun_data_interval_start [98985,99016]
===
match
---
string: """         Return list of all owners found in DAG tasks.          :return: Comma separated list of owners in DAG tasks         :rtype: str         """ [33574,33725]
string: """         Return list of all owners found in DAG tasks.          :return: Comma separated list of owners in DAG tasks         :rtype: str         """ [33574,33725]
===
match
---
operator: , [90044,90045]
operator: , [90143,90144]
===
match
---
name: stacklevel [97581,97591]
name: stacklevel [97680,97690]
===
match
---
operator: = [58025,58026]
operator: = [58025,58026]
===
match
---
dotted_name [3182,3201]
dotted_name [3182,3201]
===
match
---
name: len [74170,74173]
name: len [74170,74173]
===
match
---
name: earliest [24727,24735]
name: earliest [24727,24735]
===
match
---
argument [45368,45396]
argument [45368,45396]
===
match
---
atom_expr [4003,4021]
atom_expr [4003,4021]
===
match
---
trailer [93303,93323]
trailer [93402,93422]
===
match
---
name: self [15140,15144]
name: self [15140,15144]
===
match
---
tfpdef [55904,55924]
tfpdef [55904,55924]
===
match
---
atom_expr [39719,39730]
atom_expr [39719,39730]
===
match
---
trailer [34335,34342]
trailer [34335,34342]
===
match
---
expr_stmt [91992,92130]
expr_stmt [92091,92229]
===
match
---
expr_stmt [15171,15257]
expr_stmt [15171,15257]
===
match
---
name: query [86333,86338]
name: query [86432,86437]
===
match
---
name: cls [108803,108806]
name: cls [108902,108905]
===
match
---
decorator [99322,99335]
decorator [99421,99434]
===
match
---
operator: , [99024,99025]
operator: , [99123,99124]
===
match
---
name: task_dict [71864,71873]
name: task_dict [71864,71873]
===
match
---
atom_expr [70865,70901]
atom_expr [70865,70901]
===
match
---
fstring_string: next_dagrun_data_interval_end= [98437,98467]
fstring_string: next_dagrun_data_interval_end= [98536,98566]
===
match
---
comparison [67361,67371]
comparison [67361,67371]
===
match
---
name: include_externally_triggered [99681,99709]
name: include_externally_triggered [99780,99808]
===
match
---
tfpdef [104167,104190]
tfpdef [104266,104289]
===
match
---
name: isinstance [49209,49219]
name: isinstance [49209,49219]
===
match
---
trailer [90740,90742]
trailer [90839,90841]
===
match
---
atom_expr [100643,100660]
atom_expr [100742,100759]
===
match
---
param [105500,105510]
param [105599,105609]
===
match
---
name: get [87829,87832]
name: get [87928,87931]
===
match
---
atom_expr [16441,16453]
atom_expr [16441,16453]
===
match
---
atom_expr [14842,14877]
atom_expr [14842,14877]
===
match
---
tfpdef [11134,11190]
tfpdef [11134,11190]
===
match
---
name: datetime [45031,45039]
name: datetime [45031,45039]
===
match
---
trailer [66830,67218]
trailer [66830,67218]
===
match
---
operator: = [49253,49254]
operator: = [49253,49254]
===
match
---
name: start_date [83227,83237]
name: start_date [83326,83336]
===
match
---
name: self [74911,74915]
name: self [74911,74915]
===
match
---
name: str [93396,93399]
name: str [93495,93498]
===
match
---
dictorsetmaker [62000,62019]
dictorsetmaker [62000,62019]
===
match
---
name: execution_date [44492,44506]
name: execution_date [44492,44506]
===
match
---
trailer [27952,27969]
trailer [27952,27969]
===
match
---
expr_stmt [97126,97225]
expr_stmt [97225,97324]
===
match
---
name: start_date [66859,66869]
name: start_date [66859,66869]
===
match
---
name: airflow [3131,3138]
name: airflow [3131,3138]
===
match
---
name: Text [1437,1441]
name: Text [1437,1441]
===
match
---
expr_stmt [94257,94301]
expr_stmt [94356,94400]
===
match
---
string: 'pickle_len' [74154,74166]
string: 'pickle_len' [74154,74166]
===
match
---
name: OrderedDict [59397,59408]
name: OrderedDict [59397,59408]
===
match
---
expr_stmt [70951,71002]
expr_stmt [70951,71002]
===
match
---
name: self [31398,31402]
name: self [31398,31402]
===
match
---
simple_stmt [61515,61680]
simple_stmt [61515,61680]
===
match
---
name: update [101802,101808]
name: update [101901,101907]
===
match
---
trailer [47075,47091]
trailer [47075,47091]
===
match
---
atom_expr [51409,51431]
atom_expr [51409,51431]
===
match
---
suite [106983,107031]
suite [107082,107130]
===
match
---
operator: , [32929,32930]
operator: , [32929,32930]
===
match
---
name: recursion_depth [50934,50949]
name: recursion_depth [50934,50949]
===
match
---
atom [33751,33780]
atom [33751,33780]
===
match
---
operator: , [29189,29190]
operator: , [29189,29190]
===
match
---
return_stmt [72359,72372]
return_stmt [72359,72372]
===
match
---
trailer [42125,42137]
trailer [42125,42137]
===
match
---
name: keys [32649,32653]
name: keys [32649,32653]
===
match
---
name: Integer [1420,1427]
name: Integer [1420,1427]
===
match
---
trailer [49258,49265]
trailer [49258,49265]
===
match
---
sync_comp_for [73569,73588]
sync_comp_for [73569,73588]
===
match
---
name: ignore_first_depends_on_past [79891,79919]
name: ignore_first_depends_on_past [79891,79919]
===
match
---
name: recursion_depth [62453,62468]
name: recursion_depth [62453,62468]
===
match
---
name: dags_needing_dagruns [103018,103038]
name: dags_needing_dagruns [103117,103137]
===
match
---
operator: = [68376,68377]
operator: = [68376,68377]
===
match
---
name: f_code [13797,13803]
name: f_code [13797,13803]
===
match
---
name: Optional [12409,12417]
name: Optional [12409,12417]
===
match
---
not_test [76170,76187]
not_test [76170,76187]
===
match
---
trailer [74127,74133]
trailer [74127,74133]
===
match
---
trailer [106451,106456]
trailer [106550,106555]
===
match
---
operator: = [51389,51390]
operator: = [51389,51390]
===
match
---
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_latest_execution_date` method." [41091,41188]
string: "This attribute is deprecated. Please use `airflow.models.DAG.get_latest_execution_date` method." [41091,41188]
===
match
---
trailer [87991,87998]
trailer [88090,88097]
===
match
---
argument [21500,21513]
argument [21500,21513]
===
match
---
trailer [41808,41818]
trailer [41808,41818]
===
match
---
trailer [51690,51699]
trailer [51690,51699]
===
match
---
name: self [28025,28029]
name: self [28025,28029]
===
match
---
name: full_filepath [30515,30528]
name: full_filepath [30515,30528]
===
match
---
return_stmt [20885,20898]
return_stmt [20885,20898]
===
match
---
trailer [40861,40868]
trailer [40861,40868]
===
match
---
comparison [27706,27735]
comparison [27706,27735]
===
match
---
atom_expr [46194,46216]
atom_expr [46194,46216]
===
match
---
trailer [53079,53094]
trailer [53079,53094]
===
match
---
trailer [83933,83938]
trailer [84032,84037]
===
match
---
name: value [31149,31154]
name: value [31149,31154]
===
match
---
name: bulk_sync_to_db [83787,83802]
name: bulk_sync_to_db [83886,83901]
===
match
---
name: Optional [31803,31811]
name: Optional [31803,31811]
===
match
---
param [66545,66563]
param [66545,66563]
===
match
---
suite [29110,29500]
suite [29110,29500]
===
match
---
trailer [75821,75832]
trailer [75821,75832]
===
match
---
atom_expr [68479,68500]
atom_expr [68479,68500]
===
match
---
trailer [97165,97225]
trailer [97264,97324]
===
match
---
param [77355,77367]
param [77355,77367]
===
match
---
trailer [86751,86767]
trailer [86850,86866]
===
match
---
operator: , [106125,106126]
operator: , [106224,106225]
===
match
---
operator: = [12174,12175]
operator: = [12174,12175]
===
match
---
name: Optional [10941,10949]
name: Optional [10941,10949]
===
match
---
name: cls [108960,108963]
name: cls [109059,109062]
===
match
---
trailer [39831,39838]
trailer [39831,39838]
===
match
---
name: get_concurrency_reached [33957,33980]
name: get_concurrency_reached [33957,33980]
===
match
---
name: configuration [1723,1736]
name: configuration [1723,1736]
===
match
---
param [35093,35098]
param [35093,35098]
===
match
---
trailer [84153,84168]
trailer [84252,84267]
===
match
---
trailer [85822,85871]
trailer [85921,85970]
===
match
---
name: active_dag_ids [89733,89747]
name: active_dag_ids [89832,89846]
===
match
---
operator: = [24336,24337]
operator: = [24336,24337]
===
match
---
name: Union [46430,46435]
name: Union [46430,46435]
===
match
---
trailer [97633,97650]
trailer [97732,97749]
===
match
---
arglist [82688,82712]
arglist [82798,82822]
===
match
---
expr_stmt [15655,15704]
expr_stmt [15655,15704]
===
match
---
name: tis [49752,49755]
name: tis [49752,49755]
===
match
---
operator: @ [34375,34376]
operator: @ [34375,34376]
===
match
---
decorated [109239,109339]
decorated [109338,109438]
===
match
---
operator: = [44238,44239]
operator: = [44238,44239]
===
match
---
name: orientation [16211,16222]
name: orientation [16211,16222]
===
match
---
tfpdef [45839,45862]
tfpdef [45839,45862]
===
match
---
operator: , [2195,2196]
operator: , [2195,2196]
===
match
---
name: self [23133,23137]
name: self [23133,23137]
===
match
---
atom_expr [98073,98108]
atom_expr [98172,98207]
===
match
---
simple_stmt [108640,108687]
simple_stmt [108739,108786]
===
match
---
name: ti_list [66042,66049]
name: ti_list [66042,66049]
===
match
---
operator: = [11733,11734]
operator: = [11733,11734]
===
match
---
trailer [65163,65183]
trailer [65163,65183]
===
match
---
atom_expr [49087,49104]
atom_expr [49087,49104]
===
match
---
annassign [15546,15568]
annassign [15546,15568]
===
match
---
simple_stmt [72682,72774]
simple_stmt [72682,72774]
===
match
---
comparison [86051,86090]
comparison [86150,86189]
===
match
---
comp_if [70704,70737]
comp_if [70704,70737]
===
match
---
name: query [38781,38786]
name: query [38781,38786]
===
match
---
expr_stmt [24431,24489]
expr_stmt [24431,24489]
===
match
---
simple_stmt [107803,107818]
simple_stmt [107902,107917]
===
match
---
trailer [57666,57791]
trailer [57666,57791]
===
match
---
name: orm_dag [86752,86759]
name: orm_dag [86851,86858]
===
match
---
operator: = [17639,17640]
operator: = [17639,17640]
===
match
---
name: folder [42267,42273]
name: folder [42267,42273]
===
match
---
argument [29244,29256]
argument [29244,29256]
===
match
---
suite [34856,35049]
suite [34856,35049]
===
match
---
name: split [50247,50252]
name: split [50247,50252]
===
match
---
atom_expr [19615,19642]
atom_expr [19615,19642]
===
match
---
expr_stmt [24407,24422]
expr_stmt [24407,24422]
===
match
---
string: """Get information about the next DagRun of this dag after ``date_last_automated_dagrun``.          This calculates what time interval the next DagRun should operate on         (its execution date), and when it can be scheduled, , according to the         dag's timetable, start_date, end_date, etc. This doesn't check max         active run or any other "max_active_tasks" type limits, but only         performs calculations based on the various date and interval fields of         this dag and its tasks.          :param date_last_automated_dagrun: The ``max(execution_date)`` of             existing "automated" DagRuns for this dag (scheduled or backfill,             but not manual).         :return: DagRunInfo of the next dagrun, or None if a dagrun is not             going to be scheduled.         """ [22236,23046]
string: """Get information about the next DagRun of this dag after ``date_last_automated_dagrun``.          This calculates what time interval the next DagRun should operate on         (its execution date), and when it can be scheduled, , according to the         dag's timetable, start_date, end_date, etc. This doesn't check max         active run or any other "max_active_tasks" type limits, but only         performs calculations based on the various date and interval fields of         this dag and its tasks.          :param date_last_automated_dagrun: The ``max(execution_date)`` of             existing "automated" DagRuns for this dag (scheduled or backfill,             but not manual).         :return: DagRunInfo of the next dagrun, or None if a dagrun is not             going to be scheduled.         """ [22236,23046]
===
match
---
suite [88187,88425]
suite [88286,88524]
===
match
---
atom_expr [38093,38111]
atom_expr [38093,38111]
===
match
---
fstring_expr [53447,53459]
fstring_expr [53447,53459]
===
match
---
expr_stmt [86289,86634]
expr_stmt [86388,86733]
===
match
---
trailer [42833,42854]
trailer [42833,42854]
===
match
---
name: datetime [61439,61447]
name: datetime [61439,61447]
===
match
---
name: acyclic [60485,60492]
name: acyclic [60485,60492]
===
match
---
suite [34009,34370]
suite [34009,34370]
===
match
---
simple_stmt [41266,41306]
simple_stmt [41266,41306]
===
match
---
name: self [20222,20226]
name: self [20222,20226]
===
match
---
argument [54317,54332]
argument [54317,54332]
===
match
---
name: wraps [106091,106096]
name: wraps [106190,106195]
===
match
---
simple_stmt [82751,82885]
simple_stmt [82850,82984]
===
match
---
name: d [74009,74010]
name: d [74009,74010]
===
match
---
name: execution_date [49147,49161]
name: execution_date [49147,49161]
===
match
---
name: fileloc [13782,13789]
name: fileloc [13782,13789]
===
match
---
expr_stmt [51623,51651]
expr_stmt [51623,51651]
===
match
---
name: intersection [73361,73373]
name: intersection [73361,73373]
===
match
---
name: cls [68372,68375]
name: cls [68372,68375]
===
match
---
name: task [76416,76420]
name: task [76416,76420]
===
match
---
name: query [34949,34954]
name: query [34949,34954]
===
match
---
param [99807,99830]
param [99906,99929]
===
match
---
atom_expr [39027,39040]
atom_expr [39027,39040]
===
match
---
name: self [68259,68263]
name: self [68259,68263]
===
match
---
simple_stmt [64944,64963]
simple_stmt [64944,64963]
===
match
---
operator: = [68159,68160]
operator: = [68159,68160]
===
match
---
name: orientation [11828,11839]
name: orientation [11828,11839]
===
match
---
simple_stmt [85118,85178]
simple_stmt [85217,85277]
===
match
---
operator: , [46439,46440]
operator: , [46439,46440]
===
match
---
arglist [26654,26684]
arglist [26654,26684]
===
match
---
name: dag_obj [106876,106883]
name: dag_obj [106975,106982]
===
match
---
name: Column [96337,96343]
name: Column [96436,96442]
===
match
---
name: tasks [77204,77209]
name: tasks [77204,77209]
===
match
---
arglist [50448,51090]
arglist [50448,51090]
===
match
---
name: include_parentdag [65382,65399]
name: include_parentdag [65382,65399]
===
match
---
atom_expr [14230,14261]
atom_expr [14230,14261]
===
match
---
param [62296,62319]
param [62296,62319]
===
match
---
name: start_date [45196,45206]
name: start_date [45196,45206]
===
match
---
suite [88461,88508]
suite [88560,88607]
===
match
---
operator: , [18465,18466]
operator: , [18465,18466]
===
match
---
atom_expr [73314,73336]
atom_expr [73314,73336]
===
match
---
param [34818,34823]
param [34818,34823]
===
match
---
name: run_id [82288,82294]
name: run_id [82312,82318]
===
match
---
name: states [91718,91724]
name: states [91817,91823]
===
match
---
name: Optional [39027,39035]
name: Optional [39027,39035]
===
match
---
name: self [13982,13986]
name: self [13982,13986]
===
match
---
atom_expr [60830,60842]
atom_expr [60830,60842]
===
match
---
return_stmt [31217,31246]
return_stmt [31217,31246]
===
match
---
operator: , [86490,86491]
operator: , [86589,86590]
===
match
---
name: data_interval [82997,83010]
name: data_interval [83096,83109]
===
match
---
operator: = [75862,75863]
operator: = [75862,75863]
===
match
---
name: task_dict [76743,76752]
name: task_dict [76743,76752]
===
match
---
trailer [89844,89860]
trailer [89943,89959]
===
match
---
trailer [102618,102626]
trailer [102717,102725]
===
match
---
import_name [1233,1246]
import_name [1233,1246]
===
match
---
dotted_name [2153,2180]
dotted_name [2153,2180]
===
match
---
name: self [30157,30161]
name: self [30157,30161]
===
match
---
suite [76725,76952]
suite [76725,76952]
===
match
---
and_test [75605,75648]
and_test [75605,75648]
===
match
---
name: t [71352,71353]
name: t [71352,71353]
===
match
---
operator: , [60953,60954]
operator: , [60953,60954]
===
match
---
name: category [21034,21042]
name: category [21034,21042]
===
match
---
name: t [65856,65857]
name: t [65856,65857]
===
match
---
operator: , [61330,61331]
operator: , [61330,61331]
===
match
---
atom_expr [25452,25469]
atom_expr [25452,25469]
===
match
---
simple_stmt [85550,85598]
simple_stmt [85649,85697]
===
match
---
expr_stmt [18205,18235]
expr_stmt [18205,18235]
===
match
---
name: timetable [83018,83027]
name: timetable [83117,83126]
===
match
---
name: cls [108738,108741]
name: cls [108837,108840]
===
match
---
operator: ** [106057,106059]
operator: ** [106156,106158]
===
match
---
string: """Return nodes with no parents. These are first to execute and are called roots or root nodes.""" [58324,58422]
string: """Return nodes with no parents. These are first to execute and are called roots or root nodes.""" [58324,58422]
===
match
---
name: func [38594,38598]
name: func [38594,38598]
===
match
---
string: "You are about to delete these {count} tasks:\n{ti_list}\n\nAre you sure? (yes/no): " [65914,65999]
string: "You are about to delete these {count} tasks:\n{ti_list}\n\nAre you sure? (yes/no): " [65914,65999]
===
match
---
argument [53548,53579]
argument [53548,53579]
===
match
---
atom_expr [74504,74574]
atom_expr [74504,74574]
===
match
---
operator: @ [31590,31591]
operator: @ [31590,31591]
===
match
---
name: provide_session [33933,33948]
name: provide_session [33933,33948]
===
match
---
operator: , [83491,83492]
operator: , [83590,83591]
===
match
---
suite [109072,109153]
suite [109171,109252]
===
match
---
name: default [32314,32321]
name: default [32314,32321]
===
match
---
name: isinstance [14115,14125]
name: isinstance [14115,14125]
===
match
---
atom_expr [61124,61195]
atom_expr [61124,61195]
===
match
---
operator: = [3642,3643]
operator: = [3642,3643]
===
match
---
operator: , [35863,35864]
operator: , [35863,35864]
===
match
---
expr_stmt [75846,75879]
expr_stmt [75846,75879]
===
match
---
name: orm_dag [88343,88350]
name: orm_dag [88442,88449]
===
match
---
atom_expr [15321,15357]
atom_expr [15321,15357]
===
match
---
operator: >= [34345,34347]
operator: >= [34345,34347]
===
match
---
trailer [25013,25051]
trailer [25013,25051]
===
match
---
expr_stmt [19453,19653]
expr_stmt [19453,19653]
===
match
---
name: TimeRestriction [2370,2385]
name: TimeRestriction [2370,2385]
===
match
---
operator: , [3109,3110]
operator: , [3109,3110]
===
match
---
name: with_entities [55373,55386]
name: with_entities [55373,55386]
===
match
---
argument [97088,97114]
argument [97187,97213]
===
match
---
name: level [75117,75122]
name: level [75117,75122]
===
match
---
operator: = [55011,55012]
operator: = [55011,55012]
===
match
---
name: start_date [24191,24201]
name: start_date [24191,24201]
===
match
---
suite [32380,32426]
suite [32380,32426]
===
match
---
param [104167,104190]
param [104266,104289]
===
match
---
trailer [35297,35303]
trailer [35297,35303]
===
match
---
atom_expr [74170,74182]
atom_expr [74170,74182]
===
match
---
operator: , [47398,47399]
operator: , [47398,47399]
===
match
---
expr_stmt [68372,68392]
expr_stmt [68372,68392]
===
match
---
arglist [83125,83492]
arglist [83224,83591]
===
match
---
exprlist [68471,68475]
exprlist [68471,68475]
===
match
---
operator: } [98504,98505]
operator: } [98603,98604]
===
match
---
name: t [67496,67497]
name: t [67496,67497]
===
match
---
name: warn [35479,35483]
name: warn [35479,35483]
===
match
---
name: classmethod [99323,99334]
name: classmethod [99422,99433]
===
match
---
comparison [17229,17265]
comparison [17229,17265]
===
match
---
name: airflow [2837,2844]
name: airflow [2837,2844]
===
match
---
suite [38235,38947]
suite [38235,38947]
===
match
---
atom_expr [17970,17993]
atom_expr [17970,17993]
===
match
---
arglist [15689,15703]
arglist [15689,15703]
===
match
---
param [47273,47290]
param [47273,47290]
===
match
---
simple_stmt [64838,64849]
simple_stmt [64838,64849]
===
match
---
name: concurrency [31058,31069]
name: concurrency [31058,31069]
===
match
---
operator: } [12671,12672]
operator: } [12671,12672]
===
match
---
trailer [3329,3339]
trailer [3329,3339]
===
match
---
suite [73675,73973]
suite [73675,73973]
===
match
---
name: dag [74612,74615]
name: dag [74612,74615]
===
match
---
name: self [99622,99626]
name: self [99721,99725]
===
match
---
operator: = [17151,17152]
operator: = [17151,17152]
===
match
---
arglist [102350,102437]
arglist [102449,102536]
===
match
---
atom_expr [14291,14329]
atom_expr [14291,14329]
===
match
---
operator: -> [46845,46847]
operator: -> [46845,46847]
===
match
---
funcdef [33801,33927]
funcdef [33801,33927]
===
match
---
param [66470,66474]
param [66470,66474]
===
match
---
simple_stmt [16590,16637]
simple_stmt [16590,16637]
===
match
---
trailer [84724,84729]
trailer [84823,84828]
===
match
---
expr_stmt [94618,94667]
expr_stmt [94717,94766]
===
match
---
operator: , [40460,40461]
operator: , [40460,40461]
===
match
---
atom_expr [25416,25433]
atom_expr [25416,25433]
===
match
---
operator: , [11554,11555]
operator: , [11554,11555]
===
match
---
name: path [101236,101240]
name: path [101335,101339]
===
match
---
operator: = [24836,24837]
operator: = [24836,24837]
===
match
---
name: previous_schedule [29412,29429]
name: previous_schedule [29412,29429]
===
match
---
name: Iterable [47484,47492]
name: Iterable [47484,47492]
===
match
---
expr_stmt [85768,86190]
expr_stmt [85867,86289]
===
match
---
name: in_ [61782,61785]
name: in_ [61782,61785]
===
match
---
operator: != [74746,74748]
operator: != [74746,74748]
===
match
---
simple_stmt [29488,29500]
simple_stmt [29488,29500]
===
match
---
name: id [70394,70396]
name: id [70394,70396]
===
match
---
param [11342,11386]
param [11342,11386]
===
match
---
trailer [103911,103917]
trailer [104010,104016]
===
match
---
operator: ** [97268,97270]
operator: ** [97367,97369]
===
match
---
simple_stmt [90804,90823]
simple_stmt [90903,90922]
===
match
---
operator: , [67797,67798]
operator: , [67797,67798]
===
match
---
name: dag_id [87788,87794]
name: dag_id [87887,87893]
===
match
---
trailer [85011,85020]
trailer [85110,85119]
===
match
---
atom [70520,70540]
atom [70520,70540]
===
match
---
parameters [58523,58529]
parameters [58523,58529]
===
match
---
operator: , [28740,28741]
operator: , [28740,28741]
===
match
---
expr_stmt [49117,49174]
expr_stmt [49117,49174]
===
match
---
param [45770,45799]
param [45770,45799]
===
match
---
trailer [70628,70636]
trailer [70628,70636]
===
match
---
name: qry [91828,91831]
name: qry [91927,91930]
===
match
---
name: default_args [12910,12922]
name: default_args [12910,12922]
===
match
---
simple_stmt [3840,3852]
simple_stmt [3840,3852]
===
match
---
name: perm [19822,19826]
name: perm [19822,19826]
===
match
---
atom_expr [38811,38834]
atom_expr [38811,38834]
===
match
---
trailer [65695,65699]
trailer [65695,65699]
===
match
---
trailer [37747,37774]
trailer [37747,37774]
===
match
---
atom_expr [45011,45081]
atom_expr [45011,45081]
===
match
---
name: DagRun [2141,2147]
name: DagRun [2141,2147]
===
match
---
string: "jinja2.ext.do" [42584,42599]
string: "jinja2.ext.do" [42584,42599]
===
match
---
name: DeprecationWarning [97541,97559]
name: DeprecationWarning [97640,97658]
===
match
---
trailer [39543,39603]
trailer [39543,39603]
===
match
---
comparison [49491,49504]
comparison [49491,49504]
===
match
---
simple_stmt [74323,74349]
simple_stmt [74323,74349]
===
match
---
operator: = [57065,57066]
operator: = [57065,57066]
===
match
---
name: dag_id [29919,29925]
name: dag_id [29919,29925]
===
match
---
trailer [104755,104781]
trailer [104854,104880]
===
match
---
operator: @ [74424,74425]
operator: @ [74424,74425]
===
match
---
trailer [83938,84117]
trailer [84037,84216]
===
match
---
param [39959,39964]
param [39959,39964]
===
match
---
name: self [36160,36164]
name: self [36160,36164]
===
match
---
operator: , [65280,65281]
operator: , [65280,65281]
===
match
---
param [80817,80848]
param [80817,80848]
===
match
---
operator: , [65621,65622]
operator: , [65621,65622]
===
match
---
sync_comp_for [85153,85176]
sync_comp_for [85252,85275]
===
match
---
atom_expr [55910,55924]
atom_expr [55910,55924]
===
match
---
import_from [2397,2490]
import_from [2397,2490]
===
match
---
simple_stmt [94154,94222]
simple_stmt [94253,94321]
===
match
---
parameters [108737,108752]
parameters [108836,108851]
===
match
---
name: external_trigger [38818,38834]
name: external_trigger [38818,38834]
===
match
---
name: next_dagrun [104832,104843]
name: next_dagrun [104931,104942]
===
match
---
operator: , [990,991]
operator: , [990,991]
===
match
---
argument [57114,57126]
argument [57114,57126]
===
match
---
import_from [2832,2883]
import_from [2832,2883]
===
match
---
parameters [99786,99831]
parameters [99885,99930]
===
match
---
trailer [35255,35262]
trailer [35255,35262]
===
match
---
simple_stmt [71696,71717]
simple_stmt [71696,71717]
===
match
---
name: DagModel [101602,101610]
name: DagModel [101701,101709]
===
match
---
operator: = [40357,40358]
operator: = [40357,40358]
===
match
---
atom_expr [14902,14935]
atom_expr [14902,14935]
===
match
---
atom_expr [44659,44740]
atom_expr [44659,44740]
===
match
---
name: start_date [13998,14008]
name: start_date [13998,14008]
===
match
---
name: include_externally_triggered [29677,29705]
name: include_externally_triggered [29677,29705]
===
match
---
name: DagRun [82665,82671]
name: DagRun [82775,82781]
===
match
---
suite [29449,29479]
suite [29449,29479]
===
match
---
import_name [800,816]
import_name [800,816]
===
match
---
simple_stmt [88094,88141]
simple_stmt [88193,88240]
===
match
---
name: c [17958,17959]
name: c [17958,17959]
===
match
---
argument [64345,64357]
argument [64345,64357]
===
match
---
operator: @ [83745,83746]
operator: @ [83844,83845]
===
match
---
name: including_subdags [101308,101325]
name: including_subdags [101407,101424]
===
match
---
name: order_by [103860,103868]
name: order_by [103959,103967]
===
match
---
name: self [17779,17783]
name: self [17779,17783]
===
match
---
name: qry [91834,91837]
name: qry [91933,91936]
===
match
---
name: tasks [42038,42043]
name: tasks [42038,42043]
===
match
---
simple_stmt [102340,102439]
simple_stmt [102439,102538]
===
match
---
operator: , [1204,1205]
operator: , [1204,1205]
===
match
---
atom_expr [39895,39908]
atom_expr [39895,39908]
===
match
---
operator: = [49588,49589]
operator: = [49588,49589]
===
match
---
name: dag_by_ids [84834,84844]
name: dag_by_ids [84933,84943]
===
match
---
atom_expr [74535,74550]
atom_expr [74535,74550]
===
match
---
operator: , [83374,83375]
operator: , [83473,83474]
===
match
---
name: self [25383,25387]
name: self [25383,25387]
===
match
---
name: category [29203,29211]
name: category [29203,29211]
===
match
---
name: get_parser [80337,80347]
name: get_parser [80337,80347]
===
match
---
atom_expr [44623,44643]
atom_expr [44623,44643]
===
match
---
atom_expr [88714,88764]
atom_expr [88813,88863]
===
match
---
trailer [90773,90783]
trailer [90872,90882]
===
match
---
atom_expr [97911,97943]
atom_expr [98010,98042]
===
match
---
trailer [43633,43642]
trailer [43633,43642]
===
match
---
name: is_active [102887,102896]
name: is_active [102986,102995]
===
match
---
operator: , [62020,62021]
operator: , [62020,62021]
===
match
---
trailer [54874,54876]
trailer [54874,54876]
===
match
---
name: upstream_task_ids [73249,73266]
name: upstream_task_ids [73249,73266]
===
match
---
name: List [32603,32607]
name: List [32603,32607]
===
match
---
name: parent_dag [50110,50120]
name: parent_dag [50110,50120]
===
match
---
name: description [13669,13680]
name: description [13669,13680]
===
match
---
trailer [72586,72597]
trailer [72586,72597]
===
match
---
operator: = [16454,16455]
operator: = [16454,16455]
===
match
---
operator: = [20136,20137]
operator: = [20136,20137]
===
match
---
name: task_dict [76988,76997]
name: task_dict [76988,76997]
===
match
---
expr_stmt [40349,40608]
expr_stmt [40349,40608]
===
match
---
atom_expr [71946,71959]
atom_expr [71946,71959]
===
match
---
trailer [55472,55499]
trailer [55472,55499]
===
match
---
atom_expr [61317,61330]
atom_expr [61317,61330]
===
match
---
trailer [73377,73387]
trailer [73377,73387]
===
match
---
trailer [12624,12637]
trailer [12624,12637]
===
match
---
atom_expr [74928,74933]
atom_expr [74928,74933]
===
match
---
name: cascade [96260,96267]
name: cascade [96359,96366]
===
match
---
operator: @ [33787,33788]
operator: @ [33787,33788]
===
match
---
name: add [85618,85621]
name: add [85717,85720]
===
match
---
operator: = [97221,97222]
operator: = [97320,97321]
===
match
---
name: self [14045,14049]
name: self [14045,14049]
===
match
---
name: session [52881,52888]
name: session [52881,52888]
===
match
---
suite [67271,67299]
suite [67271,67299]
===
match
---
name: datetime [45060,45068]
name: datetime [45060,45068]
===
match
---
atom [93725,93727]
atom [93824,93826]
===
match
---
param [38198,38220]
param [38198,38220]
===
match
---
name: next_dagrun_data_interval_end [99031,99060]
name: next_dagrun_data_interval_end [99130,99159]
===
match
---
parameters [99201,99223]
parameters [99300,99322]
===
match
---
operator: , [1796,1797]
operator: , [1796,1797]
===
match
---
name: warn [13322,13326]
name: warn [13322,13326]
===
match
---
return_stmt [98609,98620]
return_stmt [98708,98719]
===
match
---
return_stmt [35660,35687]
return_stmt [35660,35687]
===
match
---
simple_stmt [100336,100358]
simple_stmt [100435,100457]
===
match
---
name: copied [71612,71618]
name: copied [71612,71618]
===
match
---
name: info [29012,29016]
name: info [29012,29016]
===
match
---
name: List [46441,46445]
name: List [46441,46445]
===
match
---
atom_expr [12972,13148]
atom_expr [12972,13148]
===
match
---
atom [15393,15414]
atom [15393,15414]
===
match
---
param [61304,61331]
param [61304,61331]
===
match
---
name: DagRunType [80767,80777]
name: DagRunType [80767,80777]
===
match
---
operator: , [17956,17957]
operator: , [17956,17957]
===
match
---
name: schedule_interval [36285,36302]
name: schedule_interval [36285,36302]
===
match
---
name: count [34203,34208]
name: count [34203,34208]
===
match
---
trailer [40854,40884]
trailer [40854,40884]
===
match
---
atom_expr [65852,65858]
atom_expr [65852,65858]
===
match
---
trailer [16210,16222]
trailer [16210,16222]
===
match
---
expr_stmt [73454,73472]
expr_stmt [73454,73472]
===
match
---
suite [75091,75248]
suite [75091,75248]
===
match
---
name: ExecutorLoader [79506,79520]
name: ExecutorLoader [79506,79520]
===
match
---
operator: , [3567,3568]
operator: , [3567,3568]
===
match
---
simple_stmt [65885,66051]
simple_stmt [65885,66051]
===
match
---
suite [55530,55603]
suite [55530,55603]
===
match
---
operator: , [107385,107386]
operator: , [107484,107485]
===
match
---
if_stmt [16155,16433]
if_stmt [16155,16433]
===
match
---
trailer [48200,48214]
trailer [48200,48214]
===
match
---
comparison [49266,49293]
comparison [49266,49293]
===
match
---
name: tasks [73102,73107]
name: tasks [73102,73107]
===
match
---
trailer [88411,88424]
trailer [88510,88523]
===
match
---
operator: = [51329,51330]
operator: = [51329,51330]
===
match
---
operator: } [71317,71318]
operator: } [71317,71318]
===
match
---
operator: , [84080,84081]
operator: , [84179,84180]
===
match
---
operator: , [3603,3604]
operator: , [3603,3604]
===
match
---
atom_expr [52996,53017]
atom_expr [52996,53017]
===
match
---
name: _context_managed_dag [109183,109203]
name: _context_managed_dag [109282,109302]
===
match
---
atom_expr [21953,21977]
atom_expr [21953,21977]
===
match
---
name: sqlalchemy [1366,1376]
name: sqlalchemy [1366,1376]
===
match
---
operator: > [52352,52353]
operator: > [52352,52353]
===
match
---
atom_expr [35216,35278]
atom_expr [35216,35278]
===
match
---
trailer [88355,88362]
trailer [88454,88461]
===
match
---
simple_stmt [99586,99720]
simple_stmt [99685,99819]
===
match
---
string: """:meta private:""" [30272,30292]
string: """:meta private:""" [30272,30292]
===
match
---
name: _getframe [13750,13759]
name: _getframe [13750,13759]
===
match
---
atom_expr [76522,76534]
atom_expr [76522,76534]
===
match
---
name: group [72815,72820]
name: group [72815,72820]
===
match
---
expr_stmt [94503,94524]
expr_stmt [94602,94623]
===
match
---
name: get_last_dagrun [99593,99608]
name: get_last_dagrun [99692,99707]
===
match
---
name: self [14565,14569]
name: self [14565,14569]
===
match
---
atom_expr [57056,57064]
atom_expr [57056,57064]
===
match
---
name: conf [83314,83318]
name: conf [83413,83417]
===
match
---
name: task [52029,52033]
name: task [52029,52033]
===
match
---
name: args [69250,69254]
name: args [69250,69254]
===
match
---
name: dag_id [40454,40460]
name: dag_id [40454,40460]
===
match
---
simple_stmt [62601,64146]
simple_stmt [62601,64146]
===
match
---
trailer [64668,64828]
trailer [64668,64828]
===
match
---
name: in_ [85008,85011]
name: in_ [85107,85110]
===
match
---
name: user_defined_filters [12591,12611]
name: user_defined_filters [12591,12611]
===
match
---
operator: = [74011,74012]
operator: = [74011,74012]
===
match
---
funcdef [104059,105490]
funcdef [104158,105589]
===
match
---
operator: , [18882,18883]
operator: , [18882,18883]
===
match
---
trailer [44484,44514]
trailer [44484,44514]
===
match
---
trailer [90842,90849]
trailer [90941,90948]
===
match
---
name: name [107381,107385]
name: name [107480,107484]
===
match
---
name: self [17393,17397]
name: self [17393,17397]
===
match
---
trailer [106734,106744]
trailer [106833,106843]
===
match
---
atom_expr [106850,106871]
atom_expr [106949,106970]
===
match
---
name: self [83571,83575]
name: self [83670,83674]
===
match
---
simple_stmt [85520,85538]
simple_stmt [85619,85637]
===
match
---
funcdef [30758,31052]
funcdef [30758,31052]
===
match
---
atom_expr [72815,72881]
atom_expr [72815,72881]
===
match
---
operator: = [96428,96429]
operator: = [96527,96528]
===
match
---
operator: , [85084,85085]
operator: , [85183,85184]
===
match
---
operator: = [54422,54423]
operator: = [54422,54423]
===
match
---
operator: = [57870,57871]
operator: = [57870,57871]
===
match
---
trailer [74738,74745]
trailer [74738,74745]
===
match
---
param [18776,18780]
param [18776,18780]
===
match
---
name: session [99389,99396]
name: session [99488,99495]
===
match
---
name: template_undefined [15504,15522]
name: template_undefined [15504,15522]
===
match
---
param [69313,69373]
param [69313,69373]
===
match
---
name: get_dagruns_between [39939,39958]
name: get_dagruns_between [39939,39958]
===
match
---
return_stmt [98629,98710]
return_stmt [98728,98809]
===
match
---
trailer [17977,17993]
trailer [17977,17993]
===
match
---
comparison [38811,38901]
comparison [38811,38901]
===
match
---
funcdef [42089,43350]
funcdef [42089,43350]
===
match
---
name: datetime [45713,45721]
name: datetime [45713,45721]
===
match
---
name: pop_context_managed_dag [108936,108959]
name: pop_context_managed_dag [109035,109058]
===
match
---
name: query [102469,102474]
name: query [102568,102573]
===
match
---
expr_stmt [87406,87443]
expr_stmt [87505,87542]
===
match
---
trailer [74566,74572]
trailer [74566,74572]
===
match
---
string: """         Save attributes about this DAG to the DB. Note that this method         can be called for both DAGs and SubDAGs. A SubDag is actually a         SubDagOperator.          :return: None         """ [88835,89041]
string: """         Save attributes about this DAG to the DB. Note that this method         can be called for both DAGs and SubDAGs. A SubDag is actually a         SubDagOperator.          :return: None         """ [88934,89140]
===
match
---
simple_stmt [55543,55603]
simple_stmt [55543,55603]
===
match
---
arglist [20496,20526]
arglist [20496,20526]
===
match
---
name: bool [47189,47193]
name: bool [47189,47193]
===
match
---
if_stmt [97779,97951]
if_stmt [97878,98050]
===
match
---
name: query [48107,48112]
name: query [48107,48112]
===
match
---
if_stmt [51132,54632]
if_stmt [51132,54632]
===
match
---
operator: = [74642,74643]
operator: = [74642,74643]
===
match
---
name: intersection [73045,73057]
name: intersection [73045,73057]
===
match
---
simple_stmt [96318,96369]
simple_stmt [96417,96468]
===
match
---
trailer [87487,87505]
trailer [87586,87604]
===
match
---
string: """Table containing DAG properties""" [94460,94497]
string: """Table containing DAG properties""" [94559,94596]
===
match
---
trailer [49102,49104]
trailer [49102,49104]
===
match
---
param [12237,12284]
param [12237,12284]
===
match
---
atom_expr [72011,72055]
atom_expr [72011,72055]
===
match
---
fstring_conversion [98502,98504]
fstring_conversion [98601,98603]
===
match
---
trailer [75613,75624]
trailer [75613,75624]
===
match
---
param [74972,74976]
param [74972,74976]
===
match
---
trailer [69248,69265]
trailer [69248,69265]
===
match
---
import_from [59209,59260]
import_from [59209,59260]
===
match
---
simple_stmt [961,1002]
simple_stmt [961,1002]
===
match
---
trailer [32276,32322]
trailer [32276,32322]
===
match
---
arglist [13003,13134]
arglist [13003,13134]
===
match
---
trailer [93702,93706]
trailer [93801,93805]
===
match
---
trailer [12417,12428]
trailer [12417,12428]
===
match
---
atom_expr [16206,16222]
atom_expr [16206,16222]
===
match
---
name: self [18827,18831]
name: self [18827,18831]
===
match
---
atom_expr [49266,49284]
atom_expr [49266,49284]
===
match
---
atom_expr [104688,104717]
atom_expr [104787,104816]
===
match
---
trailer [86903,86911]
trailer [87002,87010]
===
match
---
name: is_paused_upon_creation [85407,85430]
name: is_paused_upon_creation [85506,85529]
===
match
---
name: self [18776,18780]
name: self [18776,18780]
===
match
---
name: self [80424,80428]
name: self [80424,80428]
===
match
---
arglist [96411,96434]
arglist [96510,96533]
===
match
---
tfpdef [10858,10869]
tfpdef [10858,10869]
===
match
---
name: self [43245,43249]
name: self [43245,43249]
===
match
---
name: template_searchpath [15428,15447]
name: template_searchpath [15428,15447]
===
match
---
funcdef [24082,24759]
funcdef [24082,24759]
===
match
---
name: DagModel [89807,89815]
name: DagModel [89906,89914]
===
match
---
atom_expr [84133,84168]
atom_expr [84232,84267]
===
match
---
simple_stmt [12901,12933]
simple_stmt [12901,12933]
===
match
---
atom_expr [68787,68800]
atom_expr [68787,68800]
===
match
---
name: question [67671,67679]
name: question [67671,67679]
===
match
---
name: State [38694,38699]
name: State [38694,38699]
===
match
---
return_stmt [21124,21175]
return_stmt [21124,21175]
===
match
---
parameters [55676,56000]
parameters [55676,56000]
===
match
---
operator: , [54125,54126]
operator: , [54125,54126]
===
match
---
simple_stmt [93681,93757]
simple_stmt [93780,93856]
===
match
---
operator: , [46005,46006]
operator: , [46005,46006]
===
match
---
arglist [53548,53677]
arglist [53548,53677]
===
match
---
operator: = [95148,95149]
operator: = [95247,95248]
===
match
---
atom_expr [65692,65701]
atom_expr [65692,65701]
===
match
---
return_stmt [92222,92241]
return_stmt [92321,92340]
===
match
---
name: iter_dagrun_infos_between [20728,20753]
name: iter_dagrun_infos_between [20728,20753]
===
match
---
name: group [72991,72996]
name: group [72991,72996]
===
match
---
name: get_tis [62430,62437]
name: get_tis [62430,62437]
===
match
---
atom_expr [91480,91588]
atom_expr [91579,91687]
===
match
---
decorator [30485,30507]
decorator [30485,30507]
===
match
---
trailer [86482,86490]
trailer [86581,86589]
===
match
---
expr_stmt [65124,65143]
expr_stmt [65124,65143]
===
match
---
subscriptlist [98812,98830]
subscriptlist [98911,98929]
===
match
---
name: orm_dags [85168,85176]
name: orm_dags [85267,85275]
===
match
---
operator: = [55988,55989]
operator: = [55988,55989]
===
match
---
trailer [73560,73568]
trailer [73560,73568]
===
match
---
name: used_group_ids [72018,72032]
name: used_group_ids [72018,72032]
===
match
---
trailer [49532,49558]
trailer [49532,49558]
===
match
---
simple_stmt [44652,44741]
simple_stmt [44652,44741]
===
match
---
name: value [30163,30168]
name: value [30163,30168]
===
match
---
decorator [24764,24781]
decorator [24764,24781]
===
match
---
operator: = [72707,72708]
operator: = [72707,72708]
===
match
---
operator: -> [93401,93403]
operator: -> [93500,93502]
===
match
---
name: items [107321,107326]
name: items [107420,107425]
===
match
---
name: tis [66815,66818]
name: tis [66815,66818]
===
match
---
trailer [67754,68126]
trailer [67754,68126]
===
match
---
operator: = [13131,13132]
operator: = [13131,13132]
===
match
---
name: tis [49255,49258]
name: tis [49255,49258]
===
match
---
simple_stmt [24407,24423]
simple_stmt [24407,24423]
===
match
---
dotted_name [56949,56991]
dotted_name [56949,56991]
===
match
---
param [46423,46452]
param [46423,46452]
===
match
---
atom_expr [48757,48784]
atom_expr [48757,48784]
===
match
---
operator: = [60493,60494]
operator: = [60493,60494]
===
match
---
name: provide_session [43670,43685]
name: provide_session [43670,43685]
===
match
---
name: NullTimetable [2579,2592]
name: NullTimetable [2579,2592]
===
match
---
name: name [88286,88290]
name: name [88385,88389]
===
match
---
atom_expr [38694,38707]
atom_expr [38694,38707]
===
match
---
return_stmt [40618,40632]
return_stmt [40618,40632]
===
match
---
name: api [56957,56960]
name: api [56957,56960]
===
match
---
fstring_expr [16404,16417]
fstring_expr [16404,16417]
===
match
---
name: coerce_datetime [23519,23534]
name: coerce_datetime [23519,23534]
===
match
---
operator: == [17967,17969]
operator: == [17967,17969]
===
match
---
trailer [61322,61330]
trailer [61322,61330]
===
match
---
operator: = [61404,61405]
operator: = [61404,61405]
===
match
---
name: self [27149,27153]
name: self [27149,27153]
===
match
---
simple_stmt [4027,4076]
simple_stmt [4027,4076]
===
match
---
name: get_num_active_runs [38172,38191]
name: get_num_active_runs [38172,38191]
===
match
---
name: self [32289,32293]
name: self [32289,32293]
===
match
---
simple_stmt [106710,106754]
simple_stmt [106809,106853]
===
match
---
name: provide_session [55629,55644]
name: provide_session [55629,55644]
===
match
---
name: ask_yesno [67661,67670]
name: ask_yesno [67661,67670]
===
match
---
name: isinstance [25120,25130]
name: isinstance [25120,25130]
===
match
---
name: state [44837,44842]
name: state [44837,44842]
===
match
---
atom_expr [96833,96884]
atom_expr [96932,96983]
===
match
---
simple_stmt [67337,67350]
simple_stmt [67337,67350]
===
match
---
operator: = [57810,57811]
operator: = [57810,57811]
===
match
---
name: default_args [11395,11407]
name: default_args [11395,11407]
===
match
---
expr_stmt [74832,74869]
expr_stmt [74832,74869]
===
match
---
name: missing_dag_ids [85186,85201]
name: missing_dag_ids [85285,85300]
===
match
---
trailer [61020,61027]
trailer [61020,61027]
===
match
---
operator: = [108999,109000]
operator: = [109098,109099]
===
match
---
argument [37968,37986]
argument [37968,37986]
===
match
---
operator: = [108904,108905]
operator: = [109003,109004]
===
match
---
operator: , [1447,1448]
operator: , [1447,1448]
===
match
---
operator: @ [92247,92248]
operator: @ [92346,92347]
===
match
---
name: value [98790,98795]
name: value [98889,98894]
===
match
---
name: task_ids [90931,90939]
name: task_ids [91030,91038]
===
match
---
parameters [42008,42014]
parameters [42008,42014]
===
match
---
trailer [74025,74041]
trailer [74025,74041]
===
match
---
arglist [32277,32321]
arglist [32277,32321]
===
match
---
decorated [62056,66424]
decorated [62056,66424]
===
match
---
name: graph_unsorted [59380,59394]
name: graph_unsorted [59380,59394]
===
match
---
operator: = [83103,83104]
operator: = [83202,83203]
===
match
---
name: user_defined_macros [11290,11309]
name: user_defined_macros [11290,11309]
===
match
---
atom [62581,62583]
atom [62581,62583]
===
match
---
atom_expr [24838,24860]
atom_expr [24838,24860]
===
match
---
atom_expr [23510,23562]
atom_expr [23510,23562]
===
match
---
name: new_perm_mapping [19453,19469]
name: new_perm_mapping [19453,19469]
===
match
---
name: Column [96781,96787]
name: Column [96880,96886]
===
match
---
return_stmt [24014,24025]
return_stmt [24014,24025]
===
match
---
expr_stmt [74009,74015]
expr_stmt [74009,74015]
===
match
---
name: cls [109001,109004]
name: cls [109100,109103]
===
match
---
name: edge_info [94058,94067]
name: edge_info [94157,94166]
===
match
---
name: render_template_as_native_obj [17527,17556]
name: render_template_as_native_obj [17527,17556]
===
match
---
dotted_name [2705,2735]
dotted_name [2705,2735]
===
match
---
name: allow_future_exec_dates [33805,33828]
name: allow_future_exec_dates [33805,33828]
===
match
---
operator: , [45722,45723]
operator: , [45722,45723]
===
match
---
dotted_name [75356,75374]
dotted_name [75356,75374]
===
match
---
name: tis [48839,48842]
name: tis [48839,48842]
===
match
---
trailer [61752,61760]
trailer [61752,61760]
===
match
---
arglist [88286,88317]
arglist [88385,88416]
===
match
---
operator: } [70420,70421]
operator: } [70420,70421]
===
match
---
simple_stmt [90069,90381]
simple_stmt [90168,90480]
===
match
---
if_stmt [52329,52812]
if_stmt [52329,52812]
===
match
---
or_test [61698,61722]
or_test [61698,61722]
===
match
---
argument [97304,97312]
argument [97403,97411]
===
match
---
trailer [47043,47053]
trailer [47043,47053]
===
match
---
operator: , [62584,62585]
operator: , [62584,62585]
===
match
---
argument [83184,83213]
argument [83283,83312]
===
match
---
suite [58802,61232]
suite [58802,61232]
===
match
---
trailer [61942,61977]
trailer [61942,61977]
===
match
---
name: relativedelta [1277,1290]
name: relativedelta [1277,1290]
===
match
---
name: DagRun [38628,38634]
name: DagRun [38628,38634]
===
match
---
trailer [40592,40596]
trailer [40592,40596]
===
match
---
comp_op [88219,88225]
comp_op [88318,88324]
===
match
---
name: subdag_lst [41551,41561]
name: subdag_lst [41551,41561]
===
match
---
operator: , [12340,12341]
operator: , [12340,12341]
===
match
---
trailer [52295,52311]
trailer [52295,52311]
===
match
---
trailer [88362,88375]
trailer [88461,88474]
===
match
---
name: dag_run_state [66693,66706]
name: dag_run_state [66693,66706]
===
match
---
expr_stmt [106638,106697]
expr_stmt [106737,106796]
===
match
---
suite [59565,59605]
suite [59565,59605]
===
match
---
expr_stmt [17622,17668]
expr_stmt [17622,17668]
===
match
---
trailer [44978,44983]
trailer [44978,44983]
===
match
---
import_as_names [1641,1656]
import_as_names [1641,1656]
===
match
---
operator: = [79975,79976]
operator: = [79975,79976]
===
match
---
trailer [40484,40499]
trailer [40484,40499]
===
match
---
dotted_name [107935,107964]
dotted_name [108034,108063]
===
match
---
atom_expr [85909,85944]
atom_expr [86008,86043]
===
match
---
param [23648,23703]
param [23648,23703]
===
match
---
operator: , [10912,10913]
operator: , [10912,10913]
===
match
---
name: session [104044,104051]
name: session [104143,104150]
===
match
---
expr_stmt [90770,90791]
expr_stmt [90869,90890]
===
match
---
name: Optional [108968,108976]
name: Optional [109067,109075]
===
match
---
operator: , [46553,46554]
operator: , [46553,46554]
===
match
---
decorated [31766,31849]
decorated [31766,31849]
===
match
---
expr_stmt [18447,18475]
expr_stmt [18447,18475]
===
match
---
atom_expr [72682,72706]
atom_expr [72682,72706]
===
match
---
simple_stmt [18509,18519]
simple_stmt [18509,18519]
===
match
---
trailer [80725,80731]
trailer [80725,80731]
===
match
---
dotted_name [1662,1686]
dotted_name [1662,1686]
===
match
---
simple_stmt [89767,89774]
simple_stmt [89866,89873]
===
match
---
name: self [15171,15175]
name: self [15171,15175]
===
match
---
trailer [31540,31577]
trailer [31540,31577]
===
match
---
name: only_failed [67858,67869]
name: only_failed [67858,67869]
===
match
---
atom_expr [28990,29007]
atom_expr [28990,29007]
===
match
---
operator: = [84776,84777]
operator: = [84875,84876]
===
match
---
atom_expr [59397,59453]
atom_expr [59397,59453]
===
match
---
operator: , [58764,58765]
operator: , [58764,58765]
===
match
---
name: session [29794,29801]
name: session [29794,29801]
===
match
---
name: ti_key [51792,51798]
name: ti_key [51792,51798]
===
match
---
if_stmt [88065,88425]
if_stmt [88164,88524]
===
match
---
operator: , [1435,1436]
operator: , [1435,1436]
===
match
---
trailer [84833,84852]
trailer [84932,84951]
===
match
---
name: Optional [34841,34849]
name: Optional [34841,34849]
===
match
---
operator: += [70862,70864]
operator: += [70862,70864]
===
match
---
name: DAG [31537,31540]
name: DAG [31537,31540]
===
match
---
trailer [17601,17606]
trailer [17601,17606]
===
match
---
name: copy [795,799]
name: copy [795,799]
===
match
---
simple_stmt [89050,89089]
simple_stmt [89149,89188]
===
match
---
expr_stmt [107820,107839]
expr_stmt [107919,107938]
===
match
---
expr_stmt [42324,42362]
expr_stmt [42324,42362]
===
match
---
operator: = [29211,29212]
operator: = [29211,29212]
===
match
---
name: creating_job_id [83435,83450]
name: creating_job_id [83534,83549]
===
match
---
trailer [74301,74307]
trailer [74301,74307]
===
match
---
name: Column [95453,95459]
name: Column [95552,95558]
===
match
---
operator: , [18890,18891]
operator: , [18890,18891]
===
match
---
decorated [30744,31052]
decorated [30744,31052]
===
match
---
atom_expr [17457,17486]
atom_expr [17457,17486]
===
match
---
atom_expr [71285,71319]
atom_expr [71285,71319]
===
match
---
trailer [35312,35322]
trailer [35312,35322]
===
match
---
expr_stmt [12682,12708]
expr_stmt [12682,12708]
===
match
---
name: filter [34222,34228]
name: filter [34222,34228]
===
match
---
name: DAGS_FOLDER [101134,101145]
name: DAGS_FOLDER [101233,101244]
===
match
---
atom_expr [73425,73440]
atom_expr [73425,73440]
===
match
---
operator: , [69303,69304]
operator: , [69303,69304]
===
match
---
name: tasks [70588,70593]
name: tasks [70588,70593]
===
match
---
atom_expr [17305,17325]
atom_expr [17305,17325]
===
match
---
suite [86838,87099]
suite [86937,87198]
===
match
---
trailer [86178,86180]
trailer [86277,86279]
===
match
---
name: roots [75271,75276]
name: roots [75271,75276]
===
match
---
trailer [43249,43270]
trailer [43249,43270]
===
match
---
operator: = [79595,79596]
operator: = [79595,79596]
===
match
---
atom_expr [83536,83551]
atom_expr [83635,83650]
===
match
---
name: max_recursion_depth [64622,64641]
name: max_recursion_depth [64622,64641]
===
match
---
name: session [90046,90053]
name: session [90145,90152]
===
match
---
operator: , [29256,29257]
operator: , [29256,29257]
===
match
---
trailer [71298,71319]
trailer [71298,71319]
===
match
---
name: datetime [47006,47014]
name: datetime [47006,47014]
===
match
---
operator: = [90784,90785]
operator: = [90883,90884]
===
match
---
number: 0 [89752,89753]
number: 0 [89851,89852]
===
match
---
trailer [91680,91690]
trailer [91779,91789]
===
match
---
name: session [58110,58117]
name: session [58110,58117]
===
match
---
atom_expr [61739,61795]
atom_expr [61739,61795]
===
match
---
name: Stats [2316,2321]
name: Stats [2316,2321]
===
match
---
trailer [74324,74340]
trailer [74324,74340]
===
match
---
comp_op [76536,76542]
comp_op [76536,76542]
===
match
---
string: 'max_active_tasks_per_dag' [11527,11553]
string: 'max_active_tasks_per_dag' [11527,11553]
===
match
---
atom_expr [52026,52033]
atom_expr [52026,52033]
===
match
---
trailer [34211,34219]
trailer [34211,34219]
===
match
---
trailer [76521,76535]
trailer [76521,76535]
===
match
---
simple_stmt [3524,3575]
simple_stmt [3524,3575]
===
match
---
return_stmt [22021,22032]
return_stmt [22021,22032]
===
match
---
name: include_parentdag [65364,65381]
name: include_parentdag [65364,65381]
===
match
---
name: execution_date [39653,39667]
name: execution_date [39653,39667]
===
match
---
suite [32712,32745]
suite [32712,32745]
===
match
---
argument [30990,31002]
argument [30990,31002]
===
match
---
name: partial [75413,75420]
name: partial [75413,75420]
===
match
---
simple_stmt [1361,1453]
simple_stmt [1361,1453]
===
match
---
operator: , [80047,80048]
operator: , [80047,80048]
===
match
---
trailer [106032,106045]
trailer [106131,106144]
===
match
---
operator: & [48479,48480]
operator: & [48479,48480]
===
match
---
import_name [1596,1620]
import_name [1596,1620]
===
match
---
comparison [24214,24241]
comparison [24214,24241]
===
match
---
expr_stmt [104888,104946]
expr_stmt [104987,105045]
===
match
---
name: most_recent_dag_runs [87759,87779]
name: most_recent_dag_runs [87858,87878]
===
match
---
atom_expr [12860,12887]
atom_expr [12860,12887]
===
match
---
name: now [28893,28896]
name: now [28893,28896]
===
match
---
operator: { [25287,25288]
operator: { [25287,25288]
===
match
---
name: settings [33247,33255]
name: settings [33247,33255]
===
match
---
simple_stmt [37815,37941]
simple_stmt [37815,37941]
===
match
---
name: active_dates [38129,38141]
name: active_dates [38129,38141]
===
match
---
funcdef [61258,62051]
funcdef [61258,62051]
===
match
---
simple_stmt [68787,68815]
simple_stmt [68787,68815]
===
match
---
simple_stmt [101042,101076]
simple_stmt [101141,101175]
===
match
---
name: self [68443,68447]
name: self [68443,68447]
===
match
---
expr_stmt [17393,17447]
expr_stmt [17393,17447]
===
match
---
return_stmt [24034,24055]
return_stmt [24034,24055]
===
match
---
param [99389,99401]
param [99488,99500]
===
match
---
name: _schedule [21968,21977]
name: _schedule [21968,21977]
===
match
---
simple_stmt [109085,109153]
simple_stmt [109184,109252]
===
match
---
parameters [43373,43417]
parameters [43373,43417]
===
match
---
name: _default_view [31747,31760]
name: _default_view [31747,31760]
===
match
---
trailer [29024,29050]
trailer [29024,29050]
===
match
---
name: start_dates [24367,24378]
name: start_dates [24367,24378]
===
match
---
name: start_date [75638,75648]
name: start_date [75638,75648]
===
match
---
trailer [29132,29267]
trailer [29132,29267]
===
match
---
operator: , [105304,105305]
operator: , [105403,105404]
===
match
---
operator: -> [33558,33560]
operator: -> [33558,33560]
===
match
---
if_stmt [27266,27548]
if_stmt [27266,27548]
===
match
---
name: session [87984,87991]
name: session [88083,88090]
===
match
---
name: DagModel [34955,34963]
name: DagModel [34955,34963]
===
match
---
atom_expr [40855,40868]
atom_expr [40855,40868]
===
match
---
if_stmt [68514,68652]
if_stmt [68514,68652]
===
match
---
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_concurrency_reached` method.""" [34428,34527]
string: """This attribute is deprecated. Please use `airflow.models.DAG.get_concurrency_reached` method.""" [34428,34527]
===
match
---
operator: , [12180,12181]
operator: , [12180,12181]
===
match
---
comparison [51577,51605]
comparison [51577,51605]
===
match
---
name: filter [38671,38677]
name: filter [38671,38677]
===
match
---
trailer [67748,67754]
trailer [67748,67754]
===
match
---
not_test [49018,49050]
not_test [49018,49050]
===
match
---
operator: = [106437,106438]
operator: = [106536,106537]
===
match
---
suite [24593,24656]
suite [24593,24656]
===
match
---
atom_expr [40478,40499]
atom_expr [40478,40499]
===
match
---
operator: = [12533,12534]
operator: = [12533,12534]
===
match
---
name: default_args [14548,14560]
name: default_args [14548,14560]
===
match
---
param [75082,75089]
param [75082,75089]
===
match
---
name: self [14993,14997]
name: self [14993,14997]
===
match
---
atom_expr [104784,104814]
atom_expr [104883,104913]
===
match
---
name: root_dag_id [96858,96869]
name: root_dag_id [96957,96968]
===
match
---
atom_expr [24153,24165]
atom_expr [24153,24165]
===
match
---
atom_expr [16908,16922]
atom_expr [16908,16922]
===
match
---
suite [46217,46250]
suite [46217,46250]
===
match
---
name: paused_dag_id [100294,100307]
name: paused_dag_id [100393,100406]
===
match
---
param [11440,11474]
param [11440,11474]
===
match
---
trailer [35793,35798]
trailer [35793,35798]
===
match
---
argument [85086,85101]
argument [85185,85200]
===
match
---
atom_expr [15610,15626]
atom_expr [15610,15626]
===
match
---
trailer [18007,18014]
trailer [18007,18014]
===
match
---
name: clear [62081,62086]
name: clear [62081,62086]
===
match
---
operator: @ [32328,32329]
operator: @ [32328,32329]
===
match
---
name: airflow [75356,75363]
name: airflow [75356,75363]
===
insert-node
---
name: DAG [4135,4138]
to
classdef [4129,94128]
at 0
===
insert-node
---
name: LoggingMixin [4139,4151]
to
classdef [4129,94128]
at 1
===
insert-tree
---
simple_stmt [4158,10317]
    string: """     A dag (directed acyclic graph) is a collection of tasks with directional     dependencies. A dag also has a schedule, a start date and an end date     (optional). For each schedule, (say daily or hourly), the DAG needs to run     each individual tasks as their dependencies are met. Certain tasks have     the property of depending on their own past, meaning that they can't run     until their previous schedule (and upstream tasks) are completed.      DAGs essentially act as namespaces for tasks. A task_id can only be     added once to a DAG.      :param dag_id: The id of the DAG; must consist exclusively of alphanumeric         characters, dashes, dots and underscores (all ASCII)     :type dag_id: str     :param description: The description for the DAG to e.g. be shown on the webserver     :type description: str     :param schedule_interval: Defines how often that DAG runs, this         timedelta object gets added to your latest task instance's         execution_date to figure out the next schedule     :type schedule_interval: datetime.timedelta or         dateutil.relativedelta.relativedelta or str that acts as a cron         expression     :param start_date: The timestamp from which the scheduler will         attempt to backfill     :type start_date: datetime.datetime     :param end_date: A date beyond which your DAG won't run, leave to None         for open ended scheduling     :type end_date: datetime.datetime     :param template_searchpath: This list of folders (non relative)         defines where jinja will look for your templates. Order matters.         Note that jinja/airflow includes the path of your DAG file by         default     :type template_searchpath: str or list[str]     :param template_undefined: Template undefined type.     :type template_undefined: jinja2.StrictUndefined     :param user_defined_macros: a dictionary of macros that will be exposed         in your jinja templates. For example, passing ``dict(foo='bar')``         to this argument allows you to ``{{ foo }}`` in all jinja         templates related to this DAG. Note that you can pass any         type of object here.     :type user_defined_macros: dict     :param user_defined_filters: a dictionary of filters that will be exposed         in your jinja templates. For example, passing         ``dict(hello=lambda name: 'Hello %s' % name)`` to this argument allows         you to ``{{ 'world' | hello }}`` in all jinja templates related to         this DAG.     :type user_defined_filters: dict     :param default_args: A dictionary of default parameters to be used         as constructor keyword parameters when initialising operators.         Note that operators have the same hook, and precede those defined         here, meaning that if your dict contains `'depends_on_past': True`         here and `'depends_on_past': False` in the operator's call         `default_args`, the actual value will be `False`.     :type default_args: dict     :param params: a dictionary of DAG level parameters that are made         accessible in templates, namespaced under `params`. These         params can be overridden at the task level.     :type params: dict     :param max_active_tasks: the number of task instances allowed to run         concurrently     :type max_active_tasks: int     :param max_active_runs: maximum number of active DAG runs, beyond this         number of DAG runs in a running state, the scheduler won't create         new active DAG runs     :type max_active_runs: int     :param dagrun_timeout: specify how long a DagRun should be up before         timing out / failing, so that new DagRuns can be created. The timeout         is only enforced for scheduled DagRuns.     :type dagrun_timeout: datetime.timedelta     :param sla_miss_callback: specify a function to call when reporting SLA         timeouts.     :type sla_miss_callback: types.FunctionType     :param default_view: Specify DAG default view (tree, graph, duration,                                                    gantt, landing_times), default tree     :type default_view: str     :param orientation: Specify DAG orientation in graph view (LR, TB, RL, BT), default LR     :type orientation: str     :param catchup: Perform scheduler catchup (or only run latest)? Defaults to True     :type catchup: bool     :param on_failure_callback: A function to be called when a DagRun of this dag fails.         A context dictionary is passed as a single parameter to this function.     :type on_failure_callback: callable     :param on_success_callback: Much like the ``on_failure_callback`` except         that it is executed when the dag succeeds.     :type on_success_callback: callable     :param access_control: Specify optional DAG-level actions, e.g.,         "{'role1': {'can_read'}, 'role2': {'can_read', 'can_edit'}}"     :type access_control: dict     :param is_paused_upon_creation: Specifies if the dag is paused when created for the first time.         If the dag exists already, this flag will be ignored. If this optional parameter         is not specified, the global config setting will be used.     :type is_paused_upon_creation: bool or None     :param jinja_environment_kwargs: additional configuration options to be passed to Jinja         ``Environment`` for template rendering          **Example**: to avoid Jinja from removing a trailing newline from template strings ::              DAG(dag_id='my-dag',                 jinja_environment_kwargs={                     'keep_trailing_newline': True,                     # some other jinja2 Environment options here                 }             )          **See**: `Jinja Environment documentation         <https://jinja.palletsprojects.com/en/2.11.x/api/#jinja2.Environment>`_      :type jinja_environment_kwargs: dict     :param render_template_as_native_obj: If True, uses a Jinja ``NativeEnvironment``         to render templates as native Python types. If False, a Jinja         ``Environment`` is used to render templates as string values.     :type render_template_as_native_obj: bool     :param tags: List of tags to help filtering DAGS in the UI.     :type tags: List[str]     """ [4158,10316]
to
suite [4153,94128]
at 0
===
insert-tree
---
simple_stmt [10603,10817]
    string: """     File path that needs to be imported to load this DAG or subdag.      This may not be an actual file on disk in the case when this DAG is loaded     from a ZIP file or other DAG distribution format.     """ [10603,10816]
to
suite [4153,94128]
at 5
===
move-tree
---
name: run_id [82233,82239]
to
if_stmt [82230,82885]
at 0
===
insert-node
---
if_stmt [82423,82498]
to
suite [82257,82453]
at 1
===
insert-node
---
comparison [82524,82550]
to
and_test [82466,82493]
at 1
===
insert-node
---
suite [82439,82498]
to
if_stmt [82423,82498]
at 1
===
move-tree
---
name: execution_date [82479,82493]
to
comparison [82524,82550]
at 0
===
move-tree
---
simple_stmt [82399,82453]
    expr_stmt [82399,82452]
        name: run_type [82399,82407]
        annassign [82407,82452]
            name: DagRunType [82409,82419]
            operator: = [82420,82421]
            atom_expr [82422,82452]
                name: DagRunType [82422,82432]
                trailer [82432,82444]
                    name: from_run_id [82433,82444]
                trailer [82444,82452]
                    name: run_id [82445,82451]
to
suite [82439,82498]
at 0
===
move-tree
---
operator: = [82420,82421]
to
expr_stmt [82399,82452]
at 1
===
move-tree
---
atom_expr [82422,82452]
    name: DagRunType [82422,82432]
    trailer [82432,82444]
        name: from_run_id [82433,82444]
    trailer [82444,82452]
        name: run_id [82445,82451]
to
expr_stmt [82399,82452]
at 2
===
delete-node
---
name: DAG [4135,4138]
===
===
delete-node
---
name: LoggingMixin [4139,4151]
===
===
delete-tree
---
simple_stmt [4158,10317]
    string: """     A dag (directed acyclic graph) is a collection of tasks with directional     dependencies. A dag also has a schedule, a start date and an end date     (optional). For each schedule, (say daily or hourly), the DAG needs to run     each individual tasks as their dependencies are met. Certain tasks have     the property of depending on their own past, meaning that they can't run     until their previous schedule (and upstream tasks) are completed.      DAGs essentially act as namespaces for tasks. A task_id can only be     added once to a DAG.      :param dag_id: The id of the DAG; must consist exclusively of alphanumeric         characters, dashes, dots and underscores (all ASCII)     :type dag_id: str     :param description: The description for the DAG to e.g. be shown on the webserver     :type description: str     :param schedule_interval: Defines how often that DAG runs, this         timedelta object gets added to your latest task instance's         execution_date to figure out the next schedule     :type schedule_interval: datetime.timedelta or         dateutil.relativedelta.relativedelta or str that acts as a cron         expression     :param start_date: The timestamp from which the scheduler will         attempt to backfill     :type start_date: datetime.datetime     :param end_date: A date beyond which your DAG won't run, leave to None         for open ended scheduling     :type end_date: datetime.datetime     :param template_searchpath: This list of folders (non relative)         defines where jinja will look for your templates. Order matters.         Note that jinja/airflow includes the path of your DAG file by         default     :type template_searchpath: str or list[str]     :param template_undefined: Template undefined type.     :type template_undefined: jinja2.StrictUndefined     :param user_defined_macros: a dictionary of macros that will be exposed         in your jinja templates. For example, passing ``dict(foo='bar')``         to this argument allows you to ``{{ foo }}`` in all jinja         templates related to this DAG. Note that you can pass any         type of object here.     :type user_defined_macros: dict     :param user_defined_filters: a dictionary of filters that will be exposed         in your jinja templates. For example, passing         ``dict(hello=lambda name: 'Hello %s' % name)`` to this argument allows         you to ``{{ 'world' | hello }}`` in all jinja templates related to         this DAG.     :type user_defined_filters: dict     :param default_args: A dictionary of default parameters to be used         as constructor keyword parameters when initialising operators.         Note that operators have the same hook, and precede those defined         here, meaning that if your dict contains `'depends_on_past': True`         here and `'depends_on_past': False` in the operator's call         `default_args`, the actual value will be `False`.     :type default_args: dict     :param params: a dictionary of DAG level parameters that are made         accessible in templates, namespaced under `params`. These         params can be overridden at the task level.     :type params: dict     :param max_active_tasks: the number of task instances allowed to run         concurrently     :type max_active_tasks: int     :param max_active_runs: maximum number of active DAG runs, beyond this         number of DAG runs in a running state, the scheduler won't create         new active DAG runs     :type max_active_runs: int     :param dagrun_timeout: specify how long a DagRun should be up before         timing out / failing, so that new DagRuns can be created. The timeout         is only enforced for scheduled DagRuns.     :type dagrun_timeout: datetime.timedelta     :param sla_miss_callback: specify a function to call when reporting SLA         timeouts.     :type sla_miss_callback: types.FunctionType     :param default_view: Specify DAG default view (tree, graph, duration,                                                    gantt, landing_times), default tree     :type default_view: str     :param orientation: Specify DAG orientation in graph view (LR, TB, RL, BT), default LR     :type orientation: str     :param catchup: Perform scheduler catchup (or only run latest)? Defaults to True     :type catchup: bool     :param on_failure_callback: A function to be called when a DagRun of this dag fails.         A context dictionary is passed as a single parameter to this function.     :type on_failure_callback: callable     :param on_success_callback: Much like the ``on_failure_callback`` except         that it is executed when the dag succeeds.     :type on_success_callback: callable     :param access_control: Specify optional DAG-level actions, e.g.,         "{'role1': {'can_read'}, 'role2': {'can_read', 'can_edit'}}"     :type access_control: dict     :param is_paused_upon_creation: Specifies if the dag is paused when created for the first time.         If the dag exists already, this flag will be ignored. If this optional parameter         is not specified, the global config setting will be used.     :type is_paused_upon_creation: bool or None     :param jinja_environment_kwargs: additional configuration options to be passed to Jinja         ``Environment`` for template rendering          **Example**: to avoid Jinja from removing a trailing newline from template strings ::              DAG(dag_id='my-dag',                 jinja_environment_kwargs={                     'keep_trailing_newline': True,                     # some other jinja2 Environment options here                 }             )          **See**: `Jinja Environment documentation         <https://jinja.palletsprojects.com/en/2.11.x/api/#jinja2.Environment>`_      :type jinja_environment_kwargs: dict     :param render_template_as_native_obj: If True, uses a Jinja ``NativeEnvironment``         to render templates as native Python types. If False, a Jinja         ``Environment`` is used to render templates as string values.     :type render_template_as_native_obj: bool     :param tags: List of tags to help filtering DAGS in the UI.     :type tags: List[str]     """ [4158,10316]
===
delete-tree
---
simple_stmt [10603,10817]
    string: """     File path that needs to be imported to load this DAG or subdag.      This may not be an actual file on disk in the case when this DAG is loaded     from a ZIP file or other DAG distribution format.     """ [10603,10816]
===
delete-node
---
and_test [82233,82256]
===
===
delete-node
---
annassign [82407,82452]
===
===
delete-tree
---
not_test [82727,82737]
    name: run_id [82731,82737]
