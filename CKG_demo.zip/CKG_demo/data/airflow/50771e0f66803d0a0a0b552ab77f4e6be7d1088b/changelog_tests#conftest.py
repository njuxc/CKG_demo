===
match
---
operator: = [4227,4228]
operator: = [4227,4228]
===
match
---
param [22413,22433]
param [22638,22658]
===
match
---
operator: = [12438,12439]
operator: = [12438,12439]
===
match
---
name: os [5464,5466]
name: os [5464,5466]
===
match
---
argument [12419,12458]
argument [12419,12458]
===
match
---
atom_expr [11232,11726]
atom_expr [11232,11726]
===
match
---
fstring_string: \nAirflow home  [6336,6351]
fstring_string: \nAirflow home  [6336,6351]
===
match
---
arglist [13867,13879]
arglist [13867,13879]
===
match
---
trailer [21025,21031]
trailer [21250,21256]
===
match
---
name: pytest [1570,1576]
name: pytest [1570,1576]
===
match
---
suite [21472,21495]
suite [21697,21720]
===
match
---
trailer [18647,18654]
trailer [18647,18654]
===
match
---
name: skip_if_not_marked_with_integration [8410,8445]
name: skip_if_not_marked_with_integration [8410,8445]
===
match
---
atom_expr [19102,19114]
atom_expr [19327,19339]
===
match
---
name: path [6428,6432]
name: path [6428,6432]
===
match
---
if_stmt [20676,20715]
if_stmt [20901,20940]
===
match
---
string: "integration" [8517,8530]
string: "integration" [8517,8530]
===
match
---
string: "--integration" [3926,3941]
string: "--integration" [3926,3941]
===
match
---
arith_expr [11028,11069]
arith_expr [11028,11069]
===
match
---
name: self [20269,20273]
name: self [20494,20498]
===
match
---
expr_stmt [20628,20663]
expr_stmt [20853,20888]
===
match
---
operator: { [6330,6331]
operator: { [6330,6331]
===
match
---
arglist [3262,3554]
arglist [3262,3554]
===
match
---
name: name [13460,13464]
name: name [13460,13464]
===
match
---
name: columns [3439,3446]
name: columns [3439,3446]
===
match
---
operator: , [17527,17528]
operator: , [17527,17528]
===
match
---
trailer [20298,20305]
trailer [20523,20530]
===
match
---
name: parser [3625,3631]
name: parser [3625,3631]
===
match
---
import_from [22242,22291]
import_from [22467,22516]
===
match
---
name: exists [6638,6644]
name: exists [6638,6644]
===
match
---
name: marker [9996,10002]
name: marker [9996,10002]
===
match
---
if_stmt [9145,9202]
if_stmt [9145,9202]
===
match
---
atom_expr [22769,23253]
atom_expr [22994,23478]
===
match
---
simple_stmt [4995,5312]
simple_stmt [4995,5312]
===
match
---
atom_expr [10677,10714]
atom_expr [10677,10714]
===
match
---
name: subprocess [802,812]
name: subprocess [802,812]
===
match
---
param [10951,10955]
param [10951,10955]
===
match
---
trailer [1269,1291]
trailer [1269,1291]
===
match
---
trailer [13184,13194]
trailer [13184,13194]
===
match
---
suite [7483,7593]
suite [7483,7593]
===
match
---
name: marker [12564,12570]
name: marker [12564,12570]
===
match
---
atom_expr [10981,10995]
atom_expr [10981,10995]
===
match
---
name: task_id [22390,22397]
name: task_id [22615,22622]
===
match
---
operator: = [19619,19620]
operator: = [19844,19845]
===
match
---
name: environment_variable_name [11898,11923]
name: environment_variable_name [11898,11923]
===
match
---
name: DagRun [20521,20527]
name: DagRun [20746,20752]
===
match
---
trailer [13323,13349]
trailer [13323,13349]
===
match
---
parameters [9980,9986]
parameters [9980,9986]
===
match
---
parameters [17779,17785]
parameters [17779,17785]
===
match
---
trailer [5358,5378]
trailer [5358,5378]
===
match
---
name: in_ [21181,21184]
name: in_ [21406,21409]
===
match
---
name: request [20031,20038]
name: request [20256,20263]
===
match
---
name: getoption [13314,13323]
name: getoption [13314,13323]
===
match
---
name: app [15371,15374]
name: app [15371,15374]
===
match
---
name: item [13442,13446]
name: item [13442,13446]
===
match
---
name: pytest_print [2743,2755]
name: pytest_print [2743,2755]
===
match
---
name: on_failure_callback [22600,22619]
name: on_failure_callback [22825,22844]
===
match
---
simple_stmt [5651,5773]
simple_stmt [5651,5773]
===
match
---
name: columns [3283,3290]
name: columns [3283,3290]
===
match
---
argument [19135,19143]
argument [19360,19368]
===
match
---
atom_expr [6192,6215]
atom_expr [6192,6215]
===
match
---
name: dummy [22265,22270]
name: dummy [22490,22495]
===
match
---
name: dag_id [22726,22732]
name: dag_id [22951,22957]
===
match
---
name: self [20465,20469]
name: self [20690,20694]
===
match
---
name: iter_markers [13807,13819]
name: iter_markers [13807,13819]
===
match
---
trailer [5554,5562]
trailer [5554,5562]
===
match
---
name: hasattr [19944,19951]
name: hasattr [20169,20176]
===
match
---
name: pool [23191,23195]
name: pool [23416,23420]
===
match
---
operator: = [21101,21102]
operator: = [21326,21327]
===
match
---
string: "SYSTEMS" [4405,4414]
string: "SYSTEMS" [4405,4414]
===
match
---
argument [15350,15365]
argument [15350,15365]
===
match
---
trailer [7920,7937]
trailer [7920,7937]
===
match
---
name: args [9132,9136]
name: args [9132,9136]
===
match
---
trailer [21289,21299]
trailer [21514,21524]
===
match
---
name: self [18234,18238]
name: self [18234,18238]
===
match
---
name: valid_backend_names [12419,12438]
name: valid_backend_names [12419,12438]
===
match
---
string: 'sql' [2068,2073]
string: 'sql' [2068,2073]
===
match
---
parameters [7615,7623]
parameters [7615,7623]
===
match
---
operator: @ [5567,5568]
operator: @ [5567,5568]
===
match
---
name: os [6192,6194]
name: os [6192,6194]
===
match
---
name: DagModel [21307,21315]
name: DagModel [21532,21540]
===
match
---
trailer [6427,6432]
trailer [6427,6432]
===
match
---
name: self [20643,20647]
name: self [20868,20872]
===
match
---
operator: = [6190,6191]
operator: = [6190,6191]
===
match
---
name: reset_environment [1591,1608]
name: reset_environment [1591,1608]
===
match
---
operator: = [4012,4013]
operator: = [4012,4013]
===
match
---
name: os [11103,11105]
name: os [11103,11105]
===
match
---
simple_stmt [13972,14028]
simple_stmt [13972,14028]
===
match
---
name: dagbag [18516,18522]
name: dagbag [18516,18522]
===
match
---
param [14908,14915]
param [14908,14915]
===
match
---
name: get [19633,19636]
name: get [19858,19861]
===
match
---
trailer [18049,18058]
trailer [18049,18058]
===
match
---
name: environ [1349,1356]
name: environ [1349,1356]
===
match
---
simple_stmt [14863,14888]
simple_stmt [14863,14888]
===
match
---
name: environ [1847,1854]
name: environ [1847,1854]
===
match
---
trailer [6309,6367]
trailer [6309,6367]
===
match
---
operator: , [20290,20291]
operator: , [20515,20516]
===
match
---
if_stmt [5341,5565]
if_stmt [5341,5565]
===
match
---
name: sys [820,823]
name: sys [820,823]
===
match
---
trailer [12938,12951]
trailer [12938,12951]
===
match
---
import_from [20484,20541]
import_from [20709,20766]
===
match
---
trailer [20915,20922]
trailer [21140,21147]
===
match
---
simple_stmt [18176,18205]
simple_stmt [18176,18205]
===
match
---
suite [9987,10342]
suite [9987,10342]
===
match
---
number: 2016 [20138,20142]
number: 2016 [20363,20367]
===
match
---
atom_expr [13040,13105]
atom_expr [13040,13105]
===
match
---
trailer [18981,18992]
trailer [18953,18964]
===
match
---
atom_expr [11045,11069]
atom_expr [11045,11069]
===
match
---
operator: , [17253,17254]
operator: , [17253,17254]
===
match
---
trailer [1717,1725]
trailer [1717,1725]
===
match
---
string: "markers" [7653,7662]
string: "markers" [7653,7662]
===
match
---
name: copy [1680,1684]
name: copy [1680,1684]
===
match
---
for_stmt [10668,10908]
for_stmt [10668,10908]
===
match
---
string: "true" [6093,6099]
string: "true" [6093,6099]
===
match
---
name: fixture [21572,21579]
name: fixture [21797,21804]
===
match
---
name: start_date [19758,19768]
name: start_date [19983,19993]
===
match
---
name: selected_integrations_list [13144,13170]
name: selected_integrations_list [13144,13170]
===
match
---
dotted_name [20559,20588]
dotted_name [20784,20813]
===
match
---
name: self [20851,20855]
name: self [21076,21080]
===
match
---
simple_stmt [7496,7569]
simple_stmt [7496,7569]
===
match
---
simple_stmt [5464,5496]
simple_stmt [5464,5496]
===
match
---
string: "quarantined" [10700,10713]
string: "quarantined" [10700,10713]
===
match
---
name: init_env [1658,1666]
name: init_env [1658,1666]
===
match
---
name: request [15483,15490]
name: request [15483,15490]
===
match
---
string: "--backend" [13926,13937]
string: "--backend" [13926,13937]
===
match
---
operator: , [4362,4363]
operator: , [4362,4363]
===
match
---
atom_expr [18588,18608]
atom_expr [18588,18608]
===
match
---
operator: { [6351,6352]
operator: { [6351,6352]
===
match
---
atom_expr [9713,9951]
atom_expr [9713,9951]
===
match
---
trailer [2248,2255]
trailer [2248,2255]
===
match
---
trailer [18299,18315]
trailer [18299,18315]
===
match
---
trailer [5867,5883]
trailer [5867,5883]
===
match
---
atom_expr [2682,2693]
atom_expr [2682,2693]
===
match
---
atom_expr [17493,17503]
atom_expr [17493,17503]
===
match
---
argument [3468,3510]
argument [3468,3510]
===
match
---
expr_stmt [9565,9594]
expr_stmt [9565,9594]
===
match
---
trailer [1261,1269]
trailer [1261,1269]
===
match
---
atom_expr [18472,18494]
atom_expr [18472,18494]
===
match
---
argument [23213,23238]
argument [23438,23463]
===
match
---
trailer [6437,6478]
trailer [6437,6478]
===
match
---
trailer [23305,23315]
trailer [23530,23540]
===
match
---
name: marker [13792,13798]
name: marker [13792,13798]
===
match
---
name: self [21013,21017]
name: self [21238,21242]
===
match
---
atom_expr [10749,10897]
atom_expr [10749,10897]
===
match
---
expr_stmt [3696,3730]
expr_stmt [3696,3730]
===
match
---
operator: @ [1569,1570]
operator: @ [1569,1570]
===
match
---
number: 0 [10304,10305]
number: 0 [10304,10305]
===
match
---
if_stmt [7254,7593]
if_stmt [7254,7593]
===
match
---
operator: , [10306,10307]
operator: , [10306,10307]
===
match
---
name: dag [18790,18793]
name: dag [18790,18793]
===
match
---
name: create_dagrun [18696,18709]
name: create_dagrun [18696,18709]
===
match
---
operator: , [22732,22733]
operator: , [22957,22958]
===
match
---
suite [22702,23340]
suite [22927,23565]
===
match
---
atom_expr [17472,17483]
atom_expr [17472,17483]
===
match
---
atom [2043,2097]
atom [2043,2097]
===
match
---
testlist_comp [7424,7467]
testlist_comp [7424,7467]
===
match
---
trailer [20943,21000]
trailer [21168,21225]
===
match
---
name: item [8494,8498]
name: item [8494,8498]
===
match
---
name: item [12476,12480]
name: item [12476,12480]
===
match
---
name: session [21018,21025]
name: session [21243,21250]
===
match
---
operator: = [4251,4252]
operator: = [4251,4252]
===
match
---
operator: = [8516,8517]
operator: = [8516,8517]
===
match
---
name: dag [18176,18179]
name: dag [18176,18179]
===
match
---
name: self [19753,19757]
name: self [19978,19982]
===
match
---
trailer [21173,21180]
trailer [21398,21405]
===
match
---
trailer [7753,7818]
trailer [7753,7818]
===
match
---
name: skip_if_airflow_2_test [12891,12913]
name: skip_if_airflow_2_test [12891,12913]
===
match
---
trailer [21133,21139]
trailer [21358,21364]
===
match
---
funcdef [10631,10908]
funcdef [10631,10908]
===
match
---
trailer [3740,3750]
trailer [3740,3750]
===
match
---
name: include_quarantined [13354,13373]
name: include_quarantined [13354,13373]
===
match
---
name: columns [2861,2868]
name: columns [2861,2868]
===
match
---
if_stmt [19941,20201]
if_stmt [20166,20426]
===
match
---
name: metavar [3976,3983]
name: metavar [3976,3983]
===
match
---
param [3625,3631]
param [3625,3631]
===
match
---
string: 'count' [2089,2096]
string: 'count' [2089,2096]
===
match
---
operator: , [17503,17504]
operator: , [17503,17504]
===
match
---
import_from [19366,19396]
import_from [19591,19621]
===
match
---
name: dag_ids [20927,20934]
name: dag_ids [21152,21159]
===
match
---
simple_stmt [5968,5975]
simple_stmt [5968,5975]
===
match
---
name: in_ [21061,21064]
name: in_ [21286,21289]
===
match
---
comp_op [11993,11999]
comp_op [11993,11999]
===
match
---
trailer [10408,10429]
trailer [10408,10429]
===
match
---
name: marker [8560,8566]
name: marker [8560,8566]
===
match
---
expr_stmt [22764,23253]
expr_stmt [22989,23478]
===
match
---
operator: != [11213,11215]
operator: != [11213,11215]
===
match
---
fstring [12821,12883]
fstring [12821,12883]
===
match
---
name: self [18025,18029]
name: self [18025,18029]
===
match
---
simple_stmt [1916,1951]
simple_stmt [1916,1951]
===
match
---
param [22566,22591]
param [22791,22816]
===
match
---
string: ": {item}" [12286,12296]
string: ": {item}" [12286,12296]
===
match
---
argument [3951,3966]
argument [3951,3966]
===
match
---
name: airflow [1961,1968]
name: airflow [1961,1968]
===
match
---
string: """     Use freezegun to "stub" sleep, so that it takes no time, but that     ``datetime.now()`` appears to move forwards      If your module under test does ``import time`` and then ``time.sleep``::          def test_something(frozen_sleep):             my_mod.fn_under_test()       If your module under test does ``from time import sleep`` then you will     have to mock that sleep function directly::          def test_something(frozen_sleep, monkeypatch):             monkeypatch.setattr('my_mod.sleep', frozen_sleep)             my_mod.fn_under_test()     """ [14294,14858]
string: """     Use freezegun to "stub" sleep, so that it takes no time, but that     ``datetime.now()`` appears to move forwards      If your module under test does ``import time`` and then ``time.sleep``::          def test_something(frozen_sleep):             my_mod.fn_under_test()       If your module under test does ``from time import sleep`` then you will     have to mock that sleep function directly::          def test_something(frozen_sleep, monkeypatch):             monkeypatch.setattr('my_mod.sleep', frozen_sleep)             my_mod.fn_under_test()     """ [14294,14858]
===
match
---
name: help [4424,4428]
name: help [4424,4428]
===
match
---
simple_stmt [899,916]
simple_stmt [899,916]
===
match
---
name: dag [17747,17750]
name: dag [17747,17750]
===
match
---
string: "You can re-initialize the database by adding --with-db-init flag when running tests." [7087,7173]
string: "You can re-initialize the database by adding --with-db-init flag when running tests." [7087,7173]
===
match
---
simple_stmt [5514,5543]
simple_stmt [5514,5543]
===
match
---
suite [8475,8985]
suite [8475,8985]
===
match
---
name: request [20349,20356]
name: request [20574,20581]
===
match
---
operator: } [19088,19089]
operator: = [19306,19307]
===
match
---
name: value [18065,18070]
name: value [18065,18070]
===
match
---
trailer [2691,2693]
trailer [2691,2693]
===
match
---
expr_stmt [8541,8574]
expr_stmt [8541,8574]
===
match
---
name: item [13526,13530]
name: item [13526,13530]
===
match
---
decorated [15453,21562]
decorated [15453,21787]
===
match
---
dotted_name [14244,14258]
dotted_name [14244,14258]
===
match
---
atom_expr [14970,14987]
atom_expr [14970,14987]
===
match
---
simple_stmt [7823,7910]
simple_stmt [7823,7910]
===
match
---
trailer [15204,15212]
trailer [15204,15212]
===
match
---
name: parser [3704,3710]
name: parser [3704,3710]
===
match
---
param [15483,15490]
param [15483,15490]
===
match
---
atom_expr [1125,1165]
atom_expr [1125,1165]
===
match
---
operator: , [3148,3149]
operator: , [3148,3149]
===
match
---
name: skip_if_airflow_2_test [14212,14234]
name: skip_if_airflow_2_test [14212,14234]
===
match
---
funcdef [19186,20444]
funcdef [19411,20669]
===
match
---
name: __init__ [17327,17335]
name: __init__ [17327,17335]
===
match
---
name: dag_id [20284,20290]
name: dag_id [20509,20515]
===
match
---
string: "AWS_DEFAULT_REGION" [1270,1290]
string: "AWS_DEFAULT_REGION" [1270,1290]
===
match
---
name: include_quarantined [14109,14128]
name: include_quarantined [14109,14128]
===
match
---
suite [15029,15067]
suite [15029,15067]
===
match
---
operator: = [22767,22768]
operator: = [22992,22993]
===
match
---
name: display_sql [3418,3429]
name: display_sql [3418,3429]
===
match
---
operator: = [20406,20407]
operator: = [20631,20632]
===
match
---
name: get [7349,7352]
name: get [7349,7352]
===
match
---
name: addinivalue_line [7737,7753]
name: addinivalue_line [7737,7753]
===
match
---
name: changed_env [1701,1712]
name: changed_env [1701,1712]
===
match
---
simple_stmt [20170,20201]
simple_stmt [20395,20426]
===
match
---
atom_expr [3227,3572]
atom_expr [3227,3572]
===
match
---
arglist [19637,19655]
arglist [19862,19880]
===
match
---
string: 'default_pool' [22447,22461]
string: 'default_pool' [22672,22686]
===
match
---
name: get [11114,11117]
name: get [11114,11117]
===
match
---
string: 'start_date' [20225,20237]
string: 'start_date' [20450,20462]
===
match
---
parameters [21600,21611]
parameters [21825,21836]
===
match
---
expr_stmt [1125,1205]
expr_stmt [1125,1205]
===
match
---
if_stmt [18292,18683]
if_stmt [18292,18683]
===
match
---
name: TaskInstance [21140,21152]
name: TaskInstance [21365,21377]
===
match
---
atom_expr [19621,19656]
atom_expr [19846,19881]
===
match
---
operator: == [5379,5381]
operator: == [5379,5381]
===
match
---
simple_stmt [1616,1654]
simple_stmt [1616,1654]
===
match
---
trailer [9698,9703]
trailer [9698,9703]
===
match
---
if_stmt [7376,7593]
if_stmt [7376,7593]
===
match
---
name: dag [20274,20277]
name: dag [20499,20502]
===
match
---
suite [13752,13784]
suite [13752,13784]
===
match
---
expr_stmt [7188,7249]
expr_stmt [7188,7249]
===
match
---
param [19293,19301]
param [19518,19526]
===
match
---
string: "quarantined: mark test that are in quarantine (i.e. flaky, need to be isolated and fixed)" [8064,8155]
string: "quarantined: mark test that are in quarantine (i.e. flaky, need to be isolated and fixed)" [8064,8155]
===
match
---
name: environment_variable_value [11156,11182]
name: environment_variable_value [11156,11182]
===
match
---
expr_stmt [20170,20200]
expr_stmt [20395,20425]
===
match
---
trailer [20896,20936]
trailer [21121,21161]
===
match
---
atom_expr [20031,20045]
atom_expr [20256,20270]
===
match
---
comparison [9148,9181]
comparison [9148,9181]
===
match
---
name: environ [11106,11113]
name: environ [11106,11113]
===
match
---
name: SerializedDagModel [20870,20888]
name: SerializedDagModel [21095,21113]
===
match
---
string: "session" [15356,15365]
string: "session" [15356,15365]
===
match
---
trailer [7635,7652]
trailer [7635,7652]
===
match
---
operator: , [4186,4187]
operator: , [4186,4187]
===
match
---
simple_stmt [18739,18777]
simple_stmt [18739,18777]
===
match
---
name: marker [13867,13873]
name: marker [13867,13873]
===
match
---
trailer [20922,20926]
trailer [21147,21151]
===
match
---
atom_expr [3901,4145]
atom_expr [3901,4145]
===
match
---
operator: = [13374,13375]
operator: = [13374,13375]
===
match
---
name: dag_maker [15473,15482]
name: dag_maker [15473,15482]
===
match
---
number: 60 [6130,6132]
number: 60 [6130,6132]
===
match
---
simple_stmt [10439,10629]
simple_stmt [10439,10629]
===
match
---
trailer [18270,18277]
trailer [18270,18277]
===
match
---
atom_expr [20213,20238]
atom_expr [20438,20463]
===
match
---
string: 'bob@EXAMPLE.COM' [7450,7467]
string: 'bob@EXAMPLE.COM' [7450,7467]
===
match
---
name: serialized_dag [18556,18570]
name: serialized_dag [18556,18570]
===
match
---
name: skip [10055,10059]
name: skip [10055,10059]
===
match
---
name: executor_config [22884,22899]
name: executor_config [23109,23124]
===
match
---
funcdef [13108,14241]
funcdef [13108,14241]
===
match
---
name: os [1125,1127]
name: os [1125,1127]
===
match
---
simple_stmt [14294,14859]
simple_stmt [14294,14859]
===
match
---
string: "markers" [7847,7856]
string: "markers" [7847,7856]
===
match
---
trailer [10267,10331]
trailer [10267,10331]
===
match
---
operator: = [22511,22512]
operator: = [22736,22737]
===
match
---
argument [17529,17552]
argument [17529,17552]
===
match
---
parameters [2755,2761]
parameters [2755,2761]
===
match
---
name: skip [9213,9217]
name: skip [9213,9217]
===
match
---
fstring_start: f" [12821,12823]
fstring_start: f" [12821,12823]
===
match
---
atom_expr [13442,13479]
atom_expr [13442,13479]
===
match
---
trailer [14201,14207]
trailer [14201,14207]
===
match
---
operator: = [13238,13239]
operator: = [13238,13239]
===
match
---
name: self [19621,19625]
name: self [19846,19850]
===
match
---
atom_expr [15422,15450]
atom_expr [15422,15450]
===
match
---
name: db [1990,1992]
name: db [1990,1992]
===
match
---
name: columns [3503,3510]
name: columns [3503,3510]
===
match
---
name: serialized_model [17811,17827]
name: serialized_model [17811,17827]
===
match
---
name: skip [10731,10735]
name: skip [10731,10735]
===
match
---
trailer [19951,19983]
trailer [20176,20208]
===
match
---
argument [20961,20986]
argument [21186,21211]
===
match
---
name: os [1168,1170]
name: os [1168,1170]
===
match
---
name: environ [6238,6245]
name: environ [6238,6245]
===
match
---
string: "You can force re-initialization the database by adding --with-db-init switch to run-tests." [6763,6855]
string: "You can force re-initialization the database by adding --with-db-init switch to run-tests." [6763,6855]
===
match
---
string: "system" [10029,10037]
string: "system" [10029,10037]
===
match
---
simple_stmt [18132,18139]
simple_stmt [18132,18139]
===
match
---
funcdef [2130,3602]
funcdef [2130,3602]
===
match
---
string: "--include-long-running" [4554,4578]
string: "--include-long-running" [4554,4578]
===
match
---
import_name [16656,16680]
import_name [16656,16680]
===
match
---
not_test [14105,14128]
not_test [14105,14128]
===
match
---
name: tests_directory [1181,1196]
name: tests_directory [1181,1196]
===
match
---
string: "--include-quarantined" [13398,13421]
string: "--include-quarantined" [13398,13421]
===
match
---
funcdef [9960,10342]
funcdef [9960,10342]
===
match
---
name: environ [1672,1679]
name: environ [1672,1679]
===
match
---
name: integration_name [11658,11674]
name: integration_name [11658,11674]
===
match
---
name: key [1871,1874]
name: key [1871,1874]
===
match
---
name: os [6630,6632]
name: os [6630,6632]
===
match
---
simple_stmt [12809,12885]
simple_stmt [12809,12885]
===
match
---
trailer [21039,21046]
trailer [21264,21271]
===
match
---
atom_expr [3185,3586]
atom_expr [3185,3586]
===
match
---
suite [17786,17832]
suite [17786,17832]
===
match
---
trailer [18515,18522]
trailer [18515,18522]
===
match
---
operator: ** [18716,18718]
operator: ** [18716,18718]
===
match
---
simple_stmt [10048,10342]
simple_stmt [10048,10342]
===
match
---
name: pytest [11232,11238]
name: pytest [11232,11238]
===
match
---
name: skip [10446,10450]
name: skip [10446,10450]
===
match
---
simple_stmt [15382,15410]
simple_stmt [15382,15410]
===
match
---
testlist_comp [3133,3169]
testlist_comp [3133,3169]
===
match
---
atom_expr [19164,19176]
atom_expr [19389,19401]
===
match
---
simple_stmt [13144,13212]
simple_stmt [13144,13212]
===
match
---
operator: = [3429,3430]
operator: = [3429,3430]
===
match
---
arglist [20031,20061]
arglist [20256,20286]
===
match
---
name: iter_markers [13447,13459]
name: iter_markers [13447,13459]
===
match
---
operator: = [6091,6092]
operator: = [6091,6092]
===
match
---
name: c [3121,3122]
name: c [3121,3122]
===
match
---
trailer [4963,4990]
trailer [4963,4990]
===
match
---
name: airflow_home [6352,6364]
name: airflow_home [6352,6364]
===
match
---
name: args [9587,9591]
name: args [9587,9591]
===
match
---
argument [4785,4804]
argument [4785,4804]
===
match
---
atom_expr [4529,4722]
atom_expr [4529,4722]
===
match
---
suite [13963,14028]
suite [13963,14028]
===
match
---
name: terminal_reporter [2778,2795]
name: terminal_reporter [2778,2795]
===
match
---
simple_stmt [1990,2003]
simple_stmt [1990,2003]
===
match
---
atom_expr [20643,20662]
atom_expr [20868,20887]
===
match
---
name: freezegun_control [15162,15179]
name: freezegun_control [15162,15179]
===
match
---
trailer [11885,11893]
trailer [11885,11893]
===
match
---
simple_stmt [4150,4323]
simple_stmt [4150,4323]
===
match
---
operator: = [4378,4379]
operator: = [4378,4379]
===
match
---
trailer [5000,5010]
trailer [5000,5010]
===
match
---
name: trigger_rule [22499,22511]
name: trigger_rule [22724,22736]
===
match
---
param [19265,19278]
param [19490,19503]
===
match
---
if_stmt [9603,9688]
if_stmt [9603,9688]
===
match
---
string: " It can be set by specifying backend at breeze startup" [12217,12273]
string: " It can be set by specifying backend at breeze startup" [12217,12273]
===
match
---
parameters [10656,10662]
parameters [10656,10662]
===
match
---
name: config [7914,7920]
name: config [7914,7920]
===
match
---
comparison [3430,3446]
comparison [3430,3446]
===
match
---
name: selected_integrations [8446,8467]
name: selected_integrations [8446,8467]
===
match
---
operator: , [19291,19292]
operator: , [19516,19517]
===
match
---
parameters [15374,15376]
parameters [15374,15376]
===
match
---
trailer [1846,1854]
trailer [1846,1854]
===
match
---
param [12914,12918]
param [12914,12918]
===
match
---
trailer [9591,9594]
trailer [9591,9594]
===
match
---
trailer [20821,20829]
trailer [21046,21054]
===
match
---
operator: = [20980,20981]
operator: = [21205,21206]
===
match
---
atom_expr [21546,21561]
atom_expr [21771,21786]
===
match
---
fstring_string: Home of the user:  [6312,6330]
fstring_string: Home of the user:  [6312,6330]
===
match
---
arglist [3760,3890]
arglist [3760,3890]
===
match
---
trailer [1103,1112]
trailer [1103,1112]
===
match
---
dotted_name [15387,15398]
dotted_name [15387,15398]
===
match
---
trailer [7221,7225]
trailer [7221,7225]
===
match
---
name: credential_file [12732,12747]
name: credential_file [12732,12747]
===
match
---
name: serialized_dag [20574,20588]
name: serialized_dag [20799,20813]
===
match
---
suite [20691,20715]
suite [20916,20940]
===
match
---
operator: = [1166,1167]
operator: = [1166,1167]
===
match
---
name: item [13133,13137]
name: item [13133,13137]
===
match
---
name: item [10892,10896]
name: item [10892,10896]
===
match
---
trailer [19022,19030]
trailer [18997,19005]
===
match
---
trailer [13713,13742]
trailer [13713,13742]
===
match
---
simple_stmt [20319,20373]
simple_stmt [20544,20598]
===
match
---
name: credential_path [12779,12794]
name: credential_path [12779,12794]
===
match
---
name: selected_integrations [8945,8966]
name: selected_integrations [8945,8966]
===
match
---
simple_stmt [13489,13532]
simple_stmt [13489,13532]
===
match
---
operator: = [17484,17485]
operator: = [17484,17485]
===
match
---
trailer [8189,8299]
trailer [8189,8299]
===
match
---
name: pytest [8686,8692]
name: pytest [8686,8692]
===
match
---
operator: } [12873,12874]
operator: } [12873,12874]
===
match
---
string: "system" [9546,9554]
string: "system" [9546,9554]
===
match
---
operator: == [13017,13019]
operator: == [13017,13019]
===
match
---
trailer [21306,21336]
trailer [21531,21561]
===
match
---
operator: = [1713,1714]
operator: = [1713,1714]
===
match
---
simple_stmt [23325,23340]
simple_stmt [23550,23565]
===
match
---
trailer [12591,12615]
trailer [12591,12615]
===
match
---
trailer [18266,18278]
trailer [18266,18278]
===
match
---
trailer [7589,7592]
trailer [7589,7592]
===
match
---
name: in_ [20923,20926]
name: in_ [21148,21151]
===
match
---
simple_stmt [4922,4991]
simple_stmt [4922,4991]
===
match
---
name: dag [17828,17831]
name: dag [17828,17831]
===
match
---
name: valid_backend_names [12000,12019]
name: valid_backend_names [12000,12019]
===
match
---
string: 'trace' [3378,3385]
string: 'trace' [3378,3385]
===
match
---
trailer [15135,15152]
trailer [15135,15152]
===
match
---
atom_expr [1096,1122]
atom_expr [1096,1122]
===
match
---
simple_stmt [19603,19657]
simple_stmt [19828,19882]
===
match
---
operator: , [8062,8063]
operator: , [8062,8063]
===
match
---
import_from [1956,1984]
import_from [1956,1984]
===
match
---
simple_stmt [21542,21562]
simple_stmt [21767,21787]
===
match
---
name: systems_name [9606,9618]
name: systems_name [9606,9618]
===
match
---
name: utils [1969,1974]
name: utils [1969,1974]
===
match
---
name: trace_sql_option [2290,2306]
name: trace_sql_option [2290,2306]
===
match
---
name: item [9431,9435]
name: item [9431,9435]
===
match
---
atom_expr [4150,4322]
atom_expr [4150,4322]
===
match
---
name: session [20856,20863]
name: session [21081,21088]
===
match
---
atom_expr [18176,18204]
atom_expr [18176,18204]
===
match
---
atom_expr [18511,18571]
atom_expr [18511,18571]
===
match
---
name: __version__ [6000,6011]
name: __version__ [6000,6011]
===
match
---
string: "only run tests matching the system specified [google.cloud, google.marketing_platform]" [4429,4517]
string: "only run tests matching the system specified [google.cloud, google.marketing_platform]" [4429,4517]
===
match
---
name: action [4785,4791]
name: action [4785,4791]
===
match
---
simple_stmt [3901,4146]
simple_stmt [3901,4146]
===
match
---
name: os [1715,1717]
name: os [1715,1717]
===
match
---
name: print [7496,7501]
name: print [7496,7501]
===
match
---
atom_expr [13489,13531]
atom_expr [13489,13531]
===
match
---
expr_stmt [6185,6215]
expr_stmt [6185,6215]
===
match
---
operator: = [9088,9089]
operator: = [9088,9089]
===
match
---
name: format [10601,10607]
name: format [10601,10607]
===
match
---
name: item [11692,11696]
name: item [11692,11696]
===
match
---
name: freezegun_control [15307,15324]
name: freezegun_control [15307,15324]
===
match
---
operator: , [12458,12459]
operator: , [12458,12459]
===
match
---
name: marker [13432,13438]
name: marker [13432,13438]
===
match
---
string: "AIRFLOW_HOME" [6250,6264]
string: "AIRFLOW_HOME" [6250,6264]
===
match
---
name: item [13737,13741]
name: item [13737,13741]
===
match
---
trailer [3240,3572]
trailer [3240,3572]
===
match
---
name: self [20005,20009]
name: self [20230,20234]
===
match
---
import_from [17355,17388]
import_from [17355,17388]
===
match
---
name: join [12692,12696]
name: join [12692,12696]
===
match
---
trailer [3079,3102]
trailer [3079,3102]
===
match
---
trailer [17694,17700]
trailer [17694,17700]
===
match
---
decorator [14243,14259]
decorator [14243,14259]
===
match
---
atom_expr [8686,8984]
atom_expr [8686,8984]
===
match
---
name: self [20170,20174]
name: self [20395,20399]
===
match
---
trailer [21336,21343]
trailer [21561,21568]
===
match
---
for_stmt [10382,10629]
for_stmt [10382,10629]
===
match
---
expr_stmt [13885,13938]
expr_stmt [13885,13938]
===
match
---
expr_stmt [15075,15153]
expr_stmt [15075,15153]
===
match
---
name: skip_if_not_marked_with_integration [13575,13610]
name: skip_if_not_marked_with_integration [13575,13610]
===
match
---
del_stmt [21542,21561]
del_stmt [21767,21786]
===
match
---
string: "dags" [1198,1204]
string: "dags" [1198,1204]
===
match
---
name: start_date [18982,18992]
name: start_date [18954,18964]
===
match
---
with_item [22716,22750]
with_item [22941,22975]
===
match
---
comparison [18098,18114]
comparison [18098,18114]
===
match
---
trailer [12707,12711]
trailer [12707,12711]
===
match
---
name: DEFAULT_DATE [20105,20117]
name: DEFAULT_DATE [20330,20342]
===
match
---
operator: = [14881,14882]
operator: = [14881,14882]
===
match
---
name: lazy_object_proxy [17677,17694]
name: lazy_object_proxy [17677,17694]
===
match
---
name: path [6195,6199]
name: path [6195,6199]
===
match
---
simple_stmt [8686,8985]
simple_stmt [8686,8985]
===
match
---
name: print [5398,5403]
name: print [5398,5403]
===
match
---
simple_stmt [9109,9137]
simple_stmt [9109,9137]
===
match
---
atom_expr [17701,17721]
atom_expr [17701,17721]
===
match
---
or_test [17258,17291]
or_test [17258,17291]
===
match
---
trailer [8310,8327]
trailer [8310,8327]
===
match
---
name: selected_backend [9408,9424]
name: selected_backend [9408,9424]
===
match
---
name: selected_systems [9923,9939]
name: selected_systems [9923,9939]
===
match
---
trailer [2265,2278]
trailer [2265,2278]
===
match
---
trailer [17160,17179]
trailer [17160,17179]
===
match
---
name: os [1346,1348]
name: os [1346,1348]
===
match
---
trailer [21046,21074]
trailer [21271,21299]
===
match
---
strings [5086,5267]
strings [5086,5267]
===
match
---
arglist [5583,5612]
arglist [5583,5612]
===
match
---
trailer [6271,6276]
trailer [6271,6276]
===
match
---
operator: } [5264,5265]
operator: } [5264,5265]
===
match
---
argument [9426,9435]
argument [9426,9435]
===
match
---
name: action [4588,4594]
name: action [4588,4594]
===
match
---
trailer [13244,13251]
trailer [13244,13251]
===
match
---
trailer [23271,23285]
trailer [23496,23510]
===
match
---
expr_stmt [11854,11924]
expr_stmt [11854,11924]
===
match
---
operator: , [20519,20520]
operator: , [20744,20745]
===
match
---
name: utils [5527,5532]
name: utils [5527,5532]
===
match
---
simple_stmt [2771,2813]
simple_stmt [2771,2813]
===
match
---
simple_stmt [17237,17292]
simple_stmt [17237,17292]
===
match
---
name: models [17910,17916]
name: models [17910,17916]
===
match
---
expr_stmt [2222,2278]
expr_stmt [2222,2278]
===
match
---
operator: = [3377,3378]
operator: = [3377,3378]
===
match
---
name: name [10695,10699]
name: name [10695,10699]
===
match
---
operator: , [3966,3967]
operator: , [3966,3967]
===
match
---
dotted_name [1961,1974]
dotted_name [1961,1974]
===
match
---
name: skip_system_test [13761,13777]
name: skip_system_test [13761,13777]
===
match
---
name: DagModel [20511,20519]
name: DagModel [20736,20744]
===
match
---
trailer [23285,23316]
trailer [23510,23541]
===
match
---
operator: , [13524,13525]
operator: , [13524,13525]
===
match
---
simple_stmt [13575,13645]
simple_stmt [13575,13645]
===
match
---
simple_stmt [15193,15239]
simple_stmt [15193,15239]
===
match
---
atom_expr [9206,9442]
atom_expr [9206,9442]
===
match
---
with_stmt [22711,23254]
with_stmt [22936,23479]
===
match
---
operator: , [18714,18715]
operator: , [18714,18715]
===
match
---
name: format [12297,12303]
name: format [12297,12303]
===
match
---
name: dag_maker [22716,22725]
name: dag_maker [22941,22950]
===
match
---
trailer [11802,11807]
trailer [11802,11807]
===
match
---
atom_expr [20269,20277]
atom_expr [20494,20502]
===
match
---
name: request [5637,5644]
name: request [5637,5644]
===
match
---
trailer [21017,21025]
trailer [21242,21250]
===
match
---
name: help [4617,4621]
name: help [4617,4621]
===
match
---
name: ExitStack [2823,2832]
name: ExitStack [2823,2832]
===
match
---
string: "--system" [4352,4362]
string: "--system" [4352,4362]
===
match
---
string: "Initializing the DB - forced with --with-db-init switch." [6531,6589]
string: "Initializing the DB - forced with --with-db-init switch." [6531,6589]
===
match
---
argument [23047,23086]
argument [23272,23311]
===
match
---
name: query [20864,20869]
name: query [21089,21094]
===
match
---
argument [3262,3290]
argument [3262,3290]
===
match
---
import_name [785,794]
import_name [785,794]
===
match
---
trailer [1679,1684]
trailer [1679,1684]
===
match
---
atom_expr [18887,18900]
atom_expr [18853,18866]
===
match
---
name: test_utils [1463,1473]
name: test_utils [1463,1473]
===
match
---
name: merge [18410,18415]
name: merge [18410,18415]
===
match
---
name: freezegun_control [14999,15016]
name: freezegun_control [14999,15016]
===
match
---
name: environ [1805,1812]
name: environ [1805,1812]
===
match
---
operator: = [2041,2042]
operator: = [2041,2042]
===
match
---
argument [3080,3101]
argument [3080,3101]
===
match
---
name: pytest [9692,9698]
name: pytest [9692,9698]
===
match
---
atom_expr [4727,4917]
atom_expr [4727,4917]
===
match
---
name: os [6425,6427]
name: os [6425,6427]
===
match
---
name: skip_long_running_test [10348,10370]
name: skip_long_running_test [10348,10370]
===
match
---
name: selected_systems [9622,9638]
name: selected_systems [9622,9638]
===
match
---
name: pytest [5568,5574]
name: pytest [5568,5574]
===
match
---
atom_expr [11796,11807]
atom_expr [11796,11807]
===
match
---
name: DagBag [17486,17492]
name: DagBag [17486,17492]
===
match
---
name: selected_backend [13946,13962]
name: selected_backend [13946,13962]
===
match
---
name: item [9523,9527]
name: item [9523,9527]
===
match
---
name: self [17806,17810]
name: self [17806,17810]
===
match
---
name: environment_variable_name [11118,11143]
name: environment_variable_name [11118,11143]
===
match
---
string: "true" [11216,11222]
string: "true" [11216,11222]
===
match
---
trailer [20869,20889]
trailer [21094,21114]
===
match
---
string: "long_running" [10414,10428]
string: "long_running" [10414,10428]
===
match
---
name: include_examples [17505,17521]
name: include_examples [17505,17521]
===
match
---
param [9480,9497]
param [9480,9497]
===
match
---
trailer [3916,4145]
trailer [3916,4145]
===
match
---
name: group [4995,5000]
name: group [4995,5000]
===
match
---
trailer [8043,8161]
trailer [8043,8161]
===
match
---
name: self [18333,18337]
name: self [18333,18337]
===
match
---
suite [9504,9958]
suite [9504,9958]
===
match
---
simple_stmt [8675,8682]
simple_stmt [8675,8682]
===
match
---
trailer [6062,6070]
trailer [6062,6070]
===
match
---
name: any [3117,3120]
name: any [3117,3120]
===
match
---
expr_stmt [17237,17291]
expr_stmt [17237,17291]
===
match
---
fstring_expr [6351,6365]
fstring_expr [6351,6365]
===
match
---
import_from [5514,5542]
import_from [5514,5542]
===
match
---
name: factory [21546,21553]
name: factory [21771,21778]
===
match
---
name: os [12982,12984]
name: os [12982,12984]
===
match
---
atom_expr [8494,8531]
atom_expr [8494,8531]
===
match
---
name: os [5853,5855]
name: os [5853,5855]
===
match
---
name: airflow [5519,5526]
name: airflow [5519,5526]
===
match
---
comparison [11966,12019]
comparison [11966,12019]
===
match
---
name: marker [11796,11802]
name: marker [11796,11802]
===
match
---
string: "BACKEND" [4228,4237]
string: "BACKEND" [4228,4237]
===
match
---
number: 0 [8572,8573]
number: 0 [8572,8573]
===
match
---
name: airflow_home [6438,6450]
name: airflow_home [6438,6450]
===
match
---
name: addoption [3741,3750]
name: addoption [3741,3750]
===
match
---
name: pytest [12809,12815]
name: pytest [12809,12815]
===
match
---
argument [22884,22915]
argument [23109,23140]
===
match
---
simple_stmt [15415,15451]
simple_stmt [15415,15451]
===
match
---
atom_expr [19753,19768]
atom_expr [19978,19993]
===
match
---
name: dag_id [20916,20922]
name: dag_id [21141,21147]
===
match
---
strings [4013,4138]
strings [4013,4138]
===
match
---
name: on_retry_callback [23104,23121]
name: on_retry_callback [23329,23346]
===
match
---
trailer [1870,1875]
trailer [1870,1875]
===
match
---
atom_expr [2362,2420]
atom_expr [2362,2420]
===
match
---
name: config [13245,13251]
name: config [13245,13251]
===
match
---
suite [6980,7184]
suite [6980,7184]
===
match
---
name: join [1176,1180]
name: join [1176,1180]
===
match
---
name: dag_run [19107,19114]
name: dag_run [19332,19339]
===
match
---
operator: , [6132,6133]
operator: , [6132,6133]
===
match
---
name: want_serialized [16960,16975]
name: want_serialized [16960,16975]
===
match
---
atom_expr [7914,8015]
atom_expr [7914,8015]
===
match
---
operator: + [15124,15125]
operator: + [15124,15125]
===
match
---
suite [6516,6617]
suite [6516,6617]
===
match
---
expr_stmt [19669,19716]
expr_stmt [19894,19941]
===
match
---
atom_expr [12809,12884]
atom_expr [12809,12884]
===
match
---
name: module [19960,19966]
name: module [20185,20191]
===
match
---
atom_expr [17806,17831]
atom_expr [17806,17831]
===
match
---
name: environ [5856,5863]
name: environ [5856,5863]
===
match
---
simple_stmt [20105,20150]
simple_stmt [20330,20375]
===
match
---
expr_stmt [18019,18033]
expr_stmt [18019,18033]
===
match
---
operator: , [5033,5034]
operator: , [5033,5034]
===
match
---
simple_stmt [21481,21495]
simple_stmt [21706,21720]
===
match
---
operator: , [3998,3999]
operator: , [3998,3999]
===
match
---
operator: = [3819,3820]
operator: = [3819,3820]
===
match
---
name: trigger_rule [23226,23238]
name: trigger_rule [23451,23463]
===
match
---
simple_stmt [18019,18034]
simple_stmt [18019,18034]
===
match
---
name: selected_integrations [8606,8627]
name: selected_integrations [8606,8627]
===
match
---
expr_stmt [20319,20372]
expr_stmt [20544,20597]
===
match
---
argument [3976,3998]
argument [3976,3998]
===
match
---
name: session [21554,21561]
name: session [21779,21786]
===
match
---
simple_stmt [13683,13743]
simple_stmt [13683,13743]
===
match
---
atom_expr [20280,20306]
atom_expr [20505,20531]
===
match
---
name: kerberos [7440,7448]
name: kerberos [7440,7448]
===
match
---
string: "~" [6211,6214]
string: "~" [6211,6214]
===
match
---
trailer [2255,2265]
trailer [2255,2265]
===
match
---
name: skip [9699,9703]
name: skip [9699,9703]
===
match
---
name: backend_names [9109,9122]
name: backend_names [9109,9122]
===
match
---
atom_expr [9125,9136]
atom_expr [9125,9136]
===
match
---
name: kwargs [19082,19088]
name: kwargs [19236,19242]
===
match
---
trailer [13380,13387]
trailer [13380,13387]
===
match
---
trailer [1380,1388]
trailer [1380,1388]
===
match
---
expr_stmt [20213,20256]
expr_stmt [20438,20481]
===
match
---
name: help [4247,4251]
name: help [4247,4251]
===
match
---
name: get [7222,7225]
name: get [7222,7225]
===
match
---
string: "store" [5050,5057]
string: "store" [5050,5057]
===
match
---
name: addinivalue_line [8311,8327]
name: addinivalue_line [8311,8327]
===
match
---
name: self [18217,18221]
name: self [18217,18221]
===
match
---
number: 0 [12655,12656]
number: 0 [12655,12656]
===
match
---
simple_stmt [11232,11727]
simple_stmt [11232,11727]
===
match
---
atom_expr [4955,4990]
atom_expr [4955,4990]
===
match
---
string: """     Displays queries from the tests to console.     """ [2158,2217]
string: """     Displays queries from the tests to console.     """ [2158,2217]
===
match
---
name: ALLOWED_TRACE_SQL_COLUMNS [2015,2040]
name: ALLOWED_TRACE_SQL_COLUMNS [2015,2040]
===
match
---
comparison [8586,8627]
comparison [8586,8627]
===
match
---
suite [12796,12885]
suite [12796,12885]
===
match
---
name: self [18588,18592]
name: self [18588,18592]
===
match
---
import_as_names [878,897]
import_as_names [878,897]
===
match
---
trailer [13819,13835]
trailer [13819,13835]
===
match
---
name: trace_sql [2134,2143]
name: trace_sql [2134,2143]
===
match
---
atom_expr [9523,9555]
atom_expr [9523,9555]
===
match
---
operator: , [4910,4911]
operator: , [4910,4911]
===
match
---
name: print [6525,6530]
name: print [6525,6530]
===
match
---
name: SerializedDagModel [18357,18375]
name: SerializedDagModel [18357,18375]
===
match
---
param [17860,17865]
param [17860,17865]
===
match
---
name: want_serialized [19248,19263]
name: want_serialized [19473,19488]
===
match
---
expr_stmt [19535,19555]
expr_stmt [19760,19780]
===
match
---
name: kwargs [19684,19690]
name: kwargs [19909,19915]
===
match
---
argument [8512,8530]
argument [8512,8530]
===
match
---
name: os [792,794]
name: os [792,794]
===
match
---
argument [9941,9950]
argument [9941,9950]
===
match
---
trailer [21283,21289]
trailer [21508,21514]
===
match
---
name: bag_dag [18655,18662]
name: bag_dag [18655,18662]
===
match
---
simple_stmt [9681,9688]
simple_stmt [9681,9688]
===
match
---
param [9498,9502]
param [9498,9502]
===
match
---
string: "The test is skipped because it does not have the right integration marker. " [8707,8784]
string: "The test is skipped because it does not have the right integration marker. " [8707,8784]
===
match
---
trailer [6245,6249]
trailer [6245,6249]
===
match
---
name: display_time [3312,3324]
name: display_time [3312,3324]
===
match
---
param [18716,18724]
param [18716,18724]
===
match
---
name: value [11591,11596]
name: value [11591,11596]
===
match
---
trailer [17614,17616]
trailer [17614,17616]
===
match
---
argument [4372,4387]
argument [4372,4387]
===
match
---
operator: , [18063,18064]
operator: , [18063,18064]
===
match
---
trailer [21299,21306]
trailer [21524,21531]
===
match
---
argument [22933,22972]
argument [23158,23197]
===
match
---
atom_expr [13173,13211]
atom_expr [13173,13211]
===
match
---
trailer [14159,14165]
trailer [14159,14165]
===
match
---
if_stmt [11149,11727]
if_stmt [11149,11727]
===
match
---
sync_comp_for [3123,3170]
sync_comp_for [3123,3170]
===
match
---
parameters [12913,12919]
parameters [12913,12919]
===
match
---
with_stmt [2818,3602]
with_stmt [2818,3602]
===
match
---
name: monkeypatch [15193,15204]
name: monkeypatch [15193,15204]
===
match
---
string: "--with-db-init" [3760,3776]
string: "--with-db-init" [3760,3776]
===
match
---
operator: @ [15453,15454]
operator: @ [15453,15454]
===
match
---
import_name [813,823]
import_name [813,823]
===
match
---
sync_comp_for [2694,2732]
sync_comp_for [2694,2732]
===
match
---
simple_stmt [4529,4723]
simple_stmt [4529,4723]
===
match
---
trailer [6889,6891]
trailer [6889,6891]
===
match
---
trailer [21322,21326]
trailer [21547,21551]
===
match
---
fstring_expr [6330,6336]
fstring_expr [6330,6336]
===
match
---
argument [23157,23168]
argument [23382,23393]
===
match
---
atom_expr [10439,10628]
atom_expr [10439,10628]
===
match
---
atom_expr [3704,3730]
atom_expr [3704,3730]
===
match
---
atom_expr [6304,6367]
atom_expr [6304,6367]
===
match
---
parameters [20464,20470]
parameters [20689,20695]
===
match
---
operator: = [12596,12597]
operator: = [12596,12597]
===
match
---
name: environ [7341,7348]
name: environ [7341,7348]
===
match
---
name: scope [15350,15355]
name: scope [15350,15355]
===
match
---
simple_stmt [20432,20444]
simple_stmt [20657,20669]
===
match
---
name: system [5467,5473]
name: system [5467,5473]
===
match
---
name: dag_model [18222,18231]
name: dag_model [18222,18231]
===
match
---
name: flush [20830,20835]
name: flush [21055,21060]
===
match
---
expr_stmt [12666,12748]
expr_stmt [12666,12748]
===
match
---
argument [15437,15449]
argument [15437,15449]
===
match
---
string: "The test is skipped because it does not have the right system marker. " [9713,9785]
string: "The test is skipped because it does not have the right system marker. " [9713,9785]
===
match
---
not_test [11152,11182]
not_test [11152,11182]
===
match
---
name: integration_name [11045,11061]
name: integration_name [11045,11061]
===
match
---
trailer [11117,11144]
trailer [11117,11144]
===
match
---
name: os [1378,1380]
name: os [1378,1380]
===
match
---
trailer [12696,12748]
trailer [12696,12748]
===
match
---
trailer [8172,8189]
trailer [8172,8189]
===
match
---
operator: , [2057,2058]
operator: , [2057,2058]
===
match
---
operator: = [11657,11658]
operator: = [11657,11658]
===
match
---
atom_expr [19503,19521]
atom_expr [19728,19746]
===
match
---
operator: = [8944,8945]
operator: = [8944,8945]
===
match
---
name: home [6331,6335]
name: home [6331,6335]
===
match
---
atom_expr [20851,21000]
atom_expr [21076,21225]
===
match
---
simple_stmt [15075,15154]
simple_stmt [15075,15154]
===
match
---
simple_stmt [1452,1567]
simple_stmt [1452,1567]
===
match
---
name: _ [10672,10673]
name: _ [10672,10673]
===
match
---
simple_stmt [21440,21463]
simple_stmt [21665,21688]
===
match
---
trailer [12778,12795]
trailer [12778,12795]
===
match
---
name: item [11763,11767]
name: item [11763,11767]
===
match
---
atom_expr [17148,17202]
atom_expr [17148,17202]
===
match
---
atom_expr [13240,13273]
atom_expr [13240,13273]
===
match
---
name: os [17493,17495]
name: os [17493,17495]
===
match
---
string: "markers" [7754,7763]
string: "markers" [7754,7763]
===
match
---
operator: = [12374,12375]
operator: = [12374,12375]
===
match
---
atom_expr [6425,6478]
atom_expr [6425,6478]
===
match
---
if_stmt [2858,3587]
if_stmt [2858,3587]
===
match
---
operator: = [3957,3958]
operator: = [3957,3958]
===
match
---
param [14276,14287]
param [14276,14287]
===
match
---
name: systems_name [9565,9577]
name: systems_name [9565,9577]
===
match
---
string: "Includes long running tests (marked with long_running marker). They are skipped by default." [4622,4715]
string: "Includes long running tests (marked with long_running marker). They are skipped by default." [4622,4715]
===
match
---
expr_stmt [1701,1725]
expr_stmt [1701,1725]
===
match
---
file_input [785,23363]
file_input [785,23588]
===
match
---
trailer [12296,12303]
trailer [12296,12303]
===
match
---
expr_stmt [1658,1686]
expr_stmt [1658,1686]
===
match
---
argument [9084,9098]
argument [9084,9098]
===
match
---
name: metavar [4220,4227]
name: metavar [4220,4227]
===
match
---
simple_stmt [18790,18805]
simple_stmt [18790,18805]
===
match
---
operator: , [3290,3291]
operator: , [3290,3291]
===
match
---
funcdef [20453,21435]
funcdef [20678,21660]
===
match
---
number: 0 [10993,10994]
number: 0 [10993,10994]
===
match
---
name: format [10261,10267]
name: format [10261,10267]
===
match
---
expr_stmt [18790,18804]
expr_stmt [18790,18804]
===
match
---
atom_expr [18977,18992]
atom_expr [18949,18964]
===
match
---
with_item [2823,2848]
with_item [2823,2848]
===
match
---
name: item [12934,12938]
name: item [12934,12938]
===
match
---
dotted_name [22301,22320]
dotted_name [22526,22545]
===
match
---
suite [13836,13881]
suite [13836,13881]
===
match
---
name: seconds [15136,15143]
name: seconds [15136,15143]
===
match
---
expr_stmt [11000,11069]
expr_stmt [11000,11069]
===
match
---
operator: = [9407,9408]
operator: = [9407,9408]
===
match
---
name: dag_ids [21065,21072]
name: dag_ids [21290,21297]
===
match
---
name: serialized_model [18338,18354]
name: serialized_model [18338,18354]
===
match
---
suite [2849,3602]
suite [2849,3602]
===
match
---
name: dag [18152,18155]
name: dag [18152,18155]
===
match
---
name: path [6633,6637]
name: path [6633,6637]
===
match
---
name: dag_id [18271,18277]
name: dag_id [18271,18277]
===
match
---
suite [5336,5565]
suite [5336,5565]
===
match
---
operator: = [22374,22375]
operator: = [22599,22600]
===
match
---
name: self [19535,19539]
name: self [19760,19764]
===
match
---
trailer [7225,7249]
trailer [7225,7249]
===
match
---
atom_expr [13575,13644]
atom_expr [13575,13644]
===
match
---
trailer [19873,19887]
trailer [20098,20112]
===
match
---
operator: , [23335,23336]
operator: , [23560,23561]
===
match
---
operator: = [1376,1377]
operator: = [1376,1377]
===
match
---
parameters [18709,18725]
parameters [18709,18725]
===
match
---
name: request [6486,6493]
name: request [6486,6493]
===
match
---
name: dag [18801,18804]
name: dag [18801,18804]
===
match
---
arglist [18663,18681]
arglist [18663,18681]
===
match
---
string: "Initializing the DB - first time after entering the container.\n" [6684,6750]
string: "Initializing the DB - first time after entering the container.\n" [6684,6750]
===
match
---
name: filter [21154,21160]
name: filter [21379,21385]
===
match
---
atom_expr [8020,8161]
atom_expr [8020,8161]
===
match
---
name: terminal_reporter [2342,2359]
name: terminal_reporter [2342,2359]
===
match
---
trailer [19168,19176]
trailer [19393,19401]
===
match
---
operator: , [1196,1197]
operator: , [1196,1197]
===
match
---
trailer [12820,12884]
trailer [12820,12884]
===
match
---
trailer [10298,10303]
trailer [10298,10303]
===
match
---
simple_stmt [1844,1876]
simple_stmt [1844,1876]
===
match
---
dotted_name [17360,17374]
dotted_name [17360,17374]
===
match
---
param [13133,13137]
param [13133,13137]
===
match
---
name: datetime [878,886]
name: datetime [878,886]
===
match
---
operator: = [9430,9431]
operator: = [9430,9431]
===
match
---
trailer [13446,13459]
trailer [13446,13459]
===
match
---
operator: ** [19293,19295]
operator: ** [19518,19520]
===
match
---
trailer [12766,12771]
trailer [12766,12771]
===
match
---
operator: = [3324,3325]
operator: = [3324,3325]
===
match
---
atom_expr [18234,18278]
atom_expr [18234,18278]
===
match
---
name: c [3127,3128]
name: c [3127,3128]
===
match
---
name: selected_backend [9023,9039]
name: selected_backend [9023,9039]
===
match
---
operator: = [10612,10613]
operator: = [10612,10613]
===
match
---
argument [22800,22815]
argument [23025,23040]
===
match
---
name: args [10988,10992]
name: args [10988,10992]
===
match
---
name: startswith [6032,6042]
name: startswith [6032,6042]
===
match
---
name: dag_id [21054,21060]
name: dag_id [21279,21285]
===
match
---
atom_expr [14212,14240]
atom_expr [14212,14240]
===
match
---
name: devnull [17496,17503]
name: devnull [17496,17503]
===
match
---
name: autouse [2116,2123]
name: autouse [2116,2123]
===
match
---
argument [10695,10713]
argument [10695,10713]
===
match
---
name: clear [18156,18161]
name: clear [18156,18161]
===
match
---
simple_stmt [19535,19556]
simple_stmt [19760,19781]
===
match
---
trailer [10607,10618]
trailer [10607,10618]
===
match
---
or_test [11152,11222]
or_test [11152,11222]
===
match
---
operator: = [3983,3984]
operator: = [3983,3984]
===
match
---
trailer [1135,1165]
trailer [1135,1165]
===
match
---
operator: , [18671,18672]
operator: , [18671,18672]
===
match
---
name: freezegun_control [15268,15285]
name: freezegun_control [15268,15285]
===
match
---
operator: = [3792,3793]
operator: = [3792,3793]
===
match
---
trailer [10023,10038]
trailer [10023,10038]
===
match
---
name: skip_if_not_marked_with_backend [8991,9022]
name: skip_if_not_marked_with_backend [8991,9022]
===
match
---
string: 'op1' [22398,22403]
string: 'op1' [22623,22628]
===
match
---
name: pytest [14244,14250]
name: pytest [14244,14250]
===
match
---
name: perf [1474,1478]
name: perf [1474,1478]
===
match
---
string: "-kt" [7433,7438]
string: "-kt" [7433,7438]
===
match
---
name: start_date [19608,19618]
name: start_date [19833,19843]
===
match
---
trailer [4165,4322]
trailer [4165,4322]
===
match
---
name: exit_stack [3041,3051]
name: exit_stack [3041,3051]
===
match
---
funcdef [1896,2013]
funcdef [1896,2013]
===
match
---
name: item [13639,13643]
name: item [13639,13643]
===
match
---
name: self [19102,19106]
name: self [19327,19331]
===
match
---
trailer [18420,18437]
trailer [18420,18437]
===
match
---
number: 1 [20147,20148]
number: 1 [20372,20373]
===
match
---
operator: = [4791,4792]
operator: = [4791,4792]
===
match
---
trailer [8692,8697]
trailer [8692,8697]
===
match
---
name: args [17276,17280]
name: args [17276,17280]
===
match
---
name: get [6246,6249]
name: get [6246,6249]
===
match
---
operator: , [3805,3806]
operator: , [3805,3806]
===
match
---
name: marker [13518,13524]
name: marker [13518,13524]
===
match
---
suite [5646,7593]
suite [5646,7593]
===
match
---
name: serialized_model [18421,18437]
name: serialized_model [18421,18437]
===
match
---
trailer [21523,21531]
trailer [21748,21756]
===
match
---
suite [13139,14241]
suite [13139,14241]
===
match
---
suite [10377,10629]
suite [10377,10629]
===
match
---
name: type [17860,17864]
name: type [17860,17864]
===
match
---
simple_stmt [6413,6479]
simple_stmt [6413,6479]
===
match
---
fstring_end: " [6365,6366]
fstring_end: " [6365,6366]
===
match
---
trailer [7501,7568]
trailer [7501,7568]
===
match
---
trailer [20889,20896]
trailer [21114,21121]
===
match
---
suite [18626,18683]
suite [18626,18683]
===
match
---
name: request [19952,19959]
name: request [20177,20184]
===
match
---
name: backend_names [9168,9181]
name: backend_names [9168,9181]
===
match
---
operator: = [22429,22430]
operator: = [22654,22655]
===
match
---
comp_op [15017,15023]
comp_op [15017,15023]
===
match
---
atom_expr [15126,15152]
atom_expr [15126,15152]
===
match
---
parameters [15482,15491]
parameters [15482,15491]
===
match
---
name: DagRun [21032,21038]
name: DagRun [21257,21263]
===
match
---
trailer [6614,6616]
trailer [6614,6616]
===
match
---
trailer [11113,11117]
trailer [11113,11117]
===
match
---
arglist [7754,7817]
arglist [7754,7817]
===
match
---
trailer [20137,20149]
trailer [20362,20374]
===
match
---
name: os [1259,1261]
name: os [1259,1261]
===
match
---
operator: , [4237,4238]
operator: , [4237,4238]
===
match
---
trailer [1812,1817]
trailer [1812,1817]
===
match
---
atom_expr [1715,1725]
atom_expr [1715,1725]
===
match
---
name: request [2144,2151]
name: request [2144,2151]
===
match
---
name: getoption [13185,13194]
name: getoption [13185,13194]
===
match
---
operator: = [13824,13825]
operator: = [13824,13825]
===
match
---
name: item [8973,8977]
name: item [8973,8977]
===
match
---
trailer [6994,7183]
trailer [6994,7183]
===
match
---
name: col [2698,2701]
name: col [2698,2701]
===
match
---
trailer [13261,13273]
trailer [13261,13273]
===
match
---
operator: , [18948,18949]
operator: , [18917,18918]
===
match
---
trailer [6110,6139]
trailer [6110,6139]
===
match
---
funcdef [10910,11727]
funcdef [10910,11727]
===
match
---
atom_expr [6525,6590]
atom_expr [6525,6590]
===
match
---
operator: = [2123,2124]
operator: = [2123,2124]
===
match
---
name: environment_variable_name [12326,12351]
name: environment_variable_name [12326,12351]
===
match
---
name: item [12549,12553]
name: item [12549,12553]
===
match
---
name: environment_variable_value [11074,11100]
name: environment_variable_value [11074,11100]
===
match
---
simple_stmt [18397,18439]
simple_stmt [18397,18439]
===
match
---
simple_stmt [16656,16681]
simple_stmt [16656,16681]
===
match
---
string: "COLUMNS" [5295,5304]
string: "COLUMNS" [5295,5304]
===
match
---
atom_expr [13761,13783]
atom_expr [13761,13783]
===
match
---
simple_stmt [13040,13106]
simple_stmt [13040,13106]
===
match
---
funcdef [17841,18683]
funcdef [17841,18683]
===
match
---
name: getoption [13388,13397]
name: getoption [13388,13397]
===
match
---
string: 'all_done' [22512,22522]
string: 'all_done' [22737,22747]
===
match
---
name: item [12914,12918]
name: item [12914,12918]
===
match
---
operator: = [15093,15094]
operator: = [15093,15094]
===
match
---
simple_stmt [6966,6971]
simple_stmt [6966,6971]
===
match
---
funcdef [22344,23340]
funcdef [22569,23565]
===
match
---
atom [22487,22489]
atom [22712,22714]
===
match
---
import_from [19325,19353]
import_from [19550,19578]
===
match
---
name: marker [10981,10987]
name: marker [10981,10987]
===
match
---
arglist [9915,9950]
arglist [9915,9950]
===
match
---
if_stmt [14032,14098]
if_stmt [14032,14098]
===
match
---
string: "RUN_AIRFLOW_1_10" [5359,5377]
string: "RUN_AIRFLOW_1_10" [5359,5377]
===
match
---
name: get [1305,1308]
name: get [1305,1308]
===
match
---
operator: = [1250,1251]
operator: = [1250,1251]
===
match
---
name: request [17148,17155]
name: request [17148,17155]
===
match
---
param [22666,22677]
param [22891,22902]
===
match
---
atom_expr [20817,20837]
atom_expr [21042,21062]
===
match
---
arglist [18059,18081]
arglist [18059,18081]
===
match
---
name: get [11894,11897]
name: get [11894,11897]
===
match
---
name: create_dag [22348,22358]
name: create_dag [22573,22583]
===
match
---
operator: = [11596,11597]
operator: = [11596,11597]
===
match
---
operator: = [5294,5295]
operator: = [5294,5295]
===
match
---
trailer [13046,13051]
trailer [13046,13051]
===
match
---
param [11763,11767]
param [11763,11767]
===
match
---
name: args [10299,10303]
name: args [10299,10303]
===
match
---
name: item [13778,13782]
name: item [13778,13782]
===
match
---
trailer [8697,8984]
trailer [8697,8984]
===
match
---
name: self [21271,21275]
name: self [21496,21500]
===
match
---
operator: = [17256,17257]
operator: = [17256,17257]
===
match
---
decorator [21564,21580]
decorator [21789,21805]
===
match
---
expr_stmt [18455,18494]
expr_stmt [18455,18494]
===
match
---
name: flush [18601,18606]
name: flush [18601,18606]
===
match
---
trailer [18667,18671]
trailer [18667,18671]
===
match
---
name: fixture [5575,5582]
name: fixture [5575,5582]
===
match
---
trailer [5855,5863]
trailer [5855,5863]
===
match
---
atom_expr [11257,11716]
atom_expr [11257,11716]
===
match
---
parameters [5333,5335]
parameters [5333,5335]
===
match
---
name: Proxy [17695,17700]
name: Proxy [17695,17700]
===
match
---
funcdef [12887,13106]
funcdef [12887,13106]
===
match
---
trailer [20217,20224]
trailer [20442,20449]
===
match
---
name: print [5893,5898]
name: print [5893,5898]
===
match
---
simple_stmt [2342,2421]
simple_stmt [2342,2421]
===
match
---
atom_expr [12982,13016]
atom_expr [12982,13016]
===
match
---
atom_expr [15307,15331]
atom_expr [15307,15331]
===
match
---
if_stmt [19729,19888]
if_stmt [19954,20113]
===
match
---
string: "{name} environment variable to be set to 'true' (it is '{value}')." [12136,12204]
string: "{name} environment variable to be set to 'true' (it is '{value}')." [12136,12204]
===
match
---
name: airflow [19414,19421]
name: airflow [19639,19646]
===
match
---
string: "need_serialized_dag" [17180,17201]
string: "need_serialized_dag" [17180,17201]
===
match
---
operator: = [22446,22447]
operator: = [22671,22672]
===
match
---
string: 'sql' [3150,3155]
string: 'sql' [3150,3155]
===
match
---
if_stmt [11929,12511]
if_stmt [11929,12511]
===
match
---
name: seconds [15144,15151]
name: seconds [15144,15151]
===
match
---
string: """     Add options parser for custom plugins     """ [3638,3691]
string: """     Add options parser for custom plugins     """ [3638,3691]
===
match
---
name: lock_file [6413,6422]
name: lock_file [6413,6422]
===
match
---
string: "--backend" [4175,4186]
string: "--backend" [4175,4186]
===
match
---
name: dag_ids [21185,21192]
name: dag_ids [21410,21417]
===
match
---
operator: = [20336,20337]
operator: = [20561,20562]
===
match
---
name: request [2241,2248]
name: request [2241,2248]
===
match
---
atom_expr [4995,5311]
atom_expr [4995,5311]
===
match
---
name: session [21126,21133]
name: session [21351,21358]
===
match
---
expr_stmt [16960,16983]
expr_stmt [16960,16983]
===
match
---
simple_stmt [19409,19444]
simple_stmt [19634,19669]
===
match
---
trailer [7584,7589]
trailer [7584,7589]
===
match
---
expr_stmt [11074,11144]
expr_stmt [11074,11144]
===
match
---
trailer [9399,9436]
trailer [9399,9436]
===
match
---
atom_expr [10048,10341]
atom_expr [10048,10341]
===
match
---
simple_stmt [5893,5960]
simple_stmt [5893,5960]
===
match
---
operator: , [886,887]
operator: , [886,887]
===
match
---
name: dag [18019,18022]
name: dag [18019,18022]
===
match
---
simple_stmt [9565,9595]
simple_stmt [9565,9595]
===
match
---
name: group [4150,4155]
name: group [4150,4155]
===
match
---
name: columns [2671,2678]
name: columns [2671,2678]
===
match
---
name: self [17780,17784]
name: self [17780,17784]
===
match
---
string: "airflow_2" [12957,12968]
string: "airflow_2" [12957,12968]
===
match
---
name: selected_systems_list [13714,13735]
name: selected_systems_list [13714,13735]
===
match
---
atom_expr [5398,5455]
atom_expr [5398,5455]
===
match
---
string: "backend(name): mark test to run with named backend" [7765,7817]
string: "backend(name): mark test to run with named backend" [7765,7817]
===
match
---
atom_expr [20241,20256]
atom_expr [20466,20481]
===
match
---
name: pytest_runtest_setup [13112,13132]
name: pytest_runtest_setup [13112,13132]
===
match
---
string: "with the right system ({system}) is passed to pytest. {item}" [10198,10260]
string: "with the right system ({system}) is passed to pytest. {item}" [10198,10260]
===
match
---
atom_expr [17258,17280]
atom_expr [17258,17280]
===
match
---
operator: = [23225,23226]
operator: = [23450,23451]
===
match
---
trailer [18492,18494]
trailer [18492,18494]
===
match
---
atom_expr [20349,20372]
atom_expr [20574,20597]
===
match
---
name: item [13802,13806]
name: item [13802,13806]
===
match
---
atom_expr [13376,13422]
atom_expr [13376,13422]
===
match
---
trailer [2000,2002]
trailer [2000,2002]
===
match
---
name: timezone [20120,20128]
name: timezone [20345,20353]
===
match
---
name: environ [6063,6070]
name: environ [6063,6070]
===
match
---
trailer [20038,20045]
trailer [20263,20270]
===
match
---
trailer [2727,2732]
trailer [2727,2732]
===
match
---
simple_stmt [7914,8016]
simple_stmt [7914,8016]
===
match
---
expr_stmt [18333,18380]
expr_stmt [18333,18380]
===
match
---
name: skip_quarantined_test [10635,10656]
name: skip_quarantined_test [10635,10656]
===
match
---
name: home [6185,6189]
name: home [6185,6189]
===
match
---
strings [9227,9392]
strings [9227,9392]
===
match
---
expr_stmt [19839,19887]
expr_stmt [20064,20112]
===
match
---
trailer [10992,10995]
trailer [10992,10995]
===
match
---
operator: = [7209,7210]
operator: = [7209,7210]
===
match
---
simple_stmt [20708,20715]
simple_stmt [20933,20940]
===
match
---
trailer [13806,13819]
trailer [13806,13819]
===
match
---
suite [14289,15332]
suite [14289,15332]
===
match
---
simple_stmt [15497,16652]
simple_stmt [15497,16652]
===
match
---
trailer [10886,10897]
trailer [10886,10897]
===
match
---
trailer [11897,11924]
trailer [11897,11924]
===
match
---
operator: = [5602,5603]
operator: = [5602,5603]
===
match
---
string: "w+" [6947,6951]
string: "w+" [6947,6951]
===
match
---
operator: = [10413,10414]
operator: = [10413,10414]
===
match
---
name: item [12877,12881]
name: item [12877,12881]
===
match
---
decorator [1569,1587]
decorator [1569,1587]
===
match
---
operator: = [12641,12642]
operator: = [12641,12642]
===
match
---
operator: = [22952,22953]
operator: = [23177,23178]
===
match
---
name: dag [18267,18270]
name: dag [18267,18270]
===
match
---
name: item [9066,9070]
name: item [9066,9070]
===
match
---
name: item [10608,10612]
name: item [10608,10612]
===
match
---
atom [2681,2733]
atom [2681,2733]
===
match
---
simple_stmt [6105,6140]
simple_stmt [6105,6140]
===
match
---
atom_expr [19603,19618]
atom_expr [19828,19843]
===
match
---
name: email [22666,22671]
name: email [22891,22896]
===
match
---
trailer [22782,23253]
trailer [23007,23478]
===
match
---
trailer [15104,15116]
trailer [15104,15116]
===
match
---
name: count_queries [3066,3079]
name: count_queries [3066,3079]
===
match
---
suite [7388,7470]
suite [7388,7470]
===
match
---
operator: = [4404,4405]
operator: = [4404,4405]
===
match
---
trailer [18221,18231]
trailer [18221,18231]
===
match
---
suite [1611,1876]
suite [1611,1876]
===
match
---
trailer [21139,21153]
trailer [21364,21378]
===
match
---
name: start_date [18938,18948]
name: start_date [18907,18917]
===
match
---
simple_stmt [1062,1124]
simple_stmt [1062,1124]
===
match
---
string: "long_running: mark test that run for a long time (many minutes)" [7949,8014]
string: "long_running: mark test that run for a long time (many minutes)" [7949,8014]
===
match
---
name: name [9084,9088]
name: name [9084,9088]
===
match
---
comparison [12982,13026]
comparison [12982,13026]
===
match
---
name: group [4727,4732]
name: group [4727,4732]
===
match
---
param [22499,22523]
param [22724,22748]
===
match
---
argument [4196,4210]
argument [4196,4210]
===
match
---
operator: , [9424,9425]
operator: , [9424,9425]
===
match
---
argument [3786,3805]
argument [3786,3805]
===
match
---
operator: = [11696,11697]
operator: = [11696,11697]
===
match
---
trailer [18662,18682]
trailer [18662,18682]
===
match
---
operator: == [7278,7280]
operator: == [7278,7280]
===
match
---
string: "True" [1252,1258]
string: "True" [1252,1258]
===
match
---
simple_stmt [14961,14988]
simple_stmt [14961,14988]
===
match
---
suite [18726,19177]
suite [18726,19402]
===
match
---
name: item [14022,14026]
name: item [14022,14026]
===
match
---
trailer [4732,4742]
trailer [4732,4742]
===
match
---
trailer [15329,15331]
trailer [15329,15331]
===
match
---
name: lazy_object_proxy [16663,16680]
name: lazy_object_proxy [16663,16680]
===
match
---
atom_expr [19568,19580]
atom_expr [19793,19805]
===
match
---
name: columns [3389,3396]
name: columns [3389,3396]
===
match
---
or_test [9606,9667]
or_test [9606,9667]
===
match
---
simple_stmt [857,898]
simple_stmt [857,898]
===
match
---
string: "only run tests matching the backend: [sqlite,postgres,mysql]." [4252,4315]
string: "only run tests matching the backend: [sqlite,postgres,mysql]." [4252,4315]
===
match
---
simple_stmt [795,813]
simple_stmt [795,813]
===
match
---
trailer [17604,17614]
trailer [17604,17614]
===
match
---
comparison [7257,7287]
comparison [7257,7287]
===
match
---
name: self [19164,19168]
name: self [19389,19393]
===
match
---
atom_expr [18663,18671]
atom_expr [18663,18671]
===
match
---
operator: , [7662,7663]
operator: , [7662,7663]
===
match
---
param [22471,22490]
param [22696,22715]
===
match
---
operator: , [19216,19217]
operator: , [19441,19442]
===
match
---
argument [12321,12351]
argument [12321,12351]
===
match
---
trailer [21326,21335]
trailer [21551,21560]
===
match
---
trailer [21460,21462]
trailer [21685,21687]
===
match
---
operator: , [2049,2050]
operator: , [2049,2050]
===
match
---
atom_expr [9066,9099]
atom_expr [9066,9099]
===
match
---
dotted_name [21565,21579]
dotted_name [21790,21804]
===
match
---
name: addoption [5001,5010]
name: addoption [5001,5010]
===
match
---
name: selected_integrations [8640,8661]
name: selected_integrations [8640,8661]
===
match
---
string: 'num' [2044,2049]
string: 'num' [2044,2049]
===
match
---
string: "store_true" [4792,4804]
string: "store_true" [4792,4804]
===
match
---
name: environ [12700,12707]
name: environ [12700,12707]
===
match
---
name: upper [11062,11067]
name: upper [11062,11067]
===
match
---
trailer [19959,19966]
trailer [20184,20191]
===
match
---
name: ExitStack [847,856]
name: ExitStack [847,856]
===
match
---
name: action [4196,4202]
name: action [4196,4202]
===
match
---
suite [10957,11727]
suite [10957,11727]
===
match
---
string: "And --include-long-running flag is not passed to pytest. {item}" [10535,10600]
string: "And --include-long-running flag is not passed to pytest. {item}" [10535,10600]
===
match
---
param [17577,17581]
param [17577,17581]
===
match
---
name: models [17368,17374]
name: models [17368,17374]
===
match
---
trailer [19134,19144]
trailer [19359,19369]
===
match
---
simple_stmt [13216,13274]
simple_stmt [13216,13274]
===
match
---
string: "The test requires {integration_name} integration started and " [11257,11320]
string: "The test requires {integration_name} integration started and " [11257,11320]
===
match
---
name: terminal_reporter [2610,2627]
name: terminal_reporter [2610,2627]
===
match
---
name: config [13178,13184]
name: config [13178,13184]
===
match
---
string: 'time' [3325,3331]
string: 'time' [3325,3331]
===
match
---
name: session [21276,21283]
name: session [21501,21508]
===
match
---
operator: , [5595,5596]
operator: , [5595,5596]
===
match
---
name: dag [18678,18681]
name: dag [18678,18681]
===
match
---
operator: , [7763,7764]
operator: , [7763,7764]
===
match
---
name: utils [18752,18757]
name: utils [18752,18757]
===
match
---
name: module [20357,20363]
name: module [20582,20588]
===
match
---
arglist [17493,17552]
arglist [17493,17552]
===
match
---
suite [7624,8404]
suite [7624,8404]
===
match
---
name: settings [19345,19353]
name: settings [19570,19578]
===
match
---
suite [18316,18609]
suite [18316,18609]
===
match
---
atom_expr [7581,7592]
atom_expr [7581,7592]
===
match
---
atom_expr [2241,2278]
atom_expr [2241,2278]
===
match
---
string: "Trace SQL statements. As an argument, you must specify the columns to be " [5086,5161]
string: "Trace SQL statements. As an argument, you must specify the columns to be " [5086,5161]
===
match
---
name: dag [18668,18671]
name: dag [18668,18671]
===
match
---
funcdef [17323,17554]
funcdef [17323,17554]
===
match
---
string: "store" [4203,4210]
string: "store" [4203,4210]
===
match
---
name: DagBag [17382,17388]
name: DagBag [17382,17388]
===
match
---
trailer [19539,19546]
trailer [19764,19771]
===
match
---
name: group [4327,4332]
name: group [4327,4332]
===
match
---
string: "all" [9642,9647]
string: "all" [9642,9647]
===
match
---
name: path [1099,1103]
name: path [1099,1103]
===
match
---
trailer [21201,21258]
trailer [21426,21483]
===
match
---
trailer [18937,18948]
trailer [18906,18917]
===
match
---
name: kwargs [19549,19555]
name: kwargs [19774,19780]
===
match
---
param [7616,7622]
param [7616,7622]
===
match
---
trailer [9527,9540]
trailer [9527,9540]
===
match
---
trailer [6935,6952]
trailer [6935,6952]
===
match
---
simple_stmt [20269,20307]
simple_stmt [20494,20532]
===
match
---
simple_stmt [2671,2734]
simple_stmt [2671,2734]
===
match
---
import_name [899,915]
import_name [899,915]
===
match
---
suite [17884,18683]
suite [17884,18683]
===
match
---
comparison [8631,8661]
comparison [8631,8661]
===
match
---
trailer [17700,17722]
trailer [17700,17722]
===
match
---
trailer [13459,13479]
trailer [13459,13479]
===
match
---
atom_expr [14069,14097]
atom_expr [14069,14097]
===
match
---
string: 'trace' [3141,3148]
string: 'trace' [3141,3148]
===
match
---
simple_stmt [3638,3692]
simple_stmt [3638,3692]
===
match
---
trailer [21064,21073]
trailer [21289,21298]
===
match
---
atom_expr [18357,18380]
atom_expr [18357,18380]
===
match
---
argument [9400,9424]
argument [9400,9424]
===
match
---
name: name [10409,10413]
name: name [10409,10413]
===
match
---
name: delete [21195,21201]
name: delete [21420,21426]
===
match
---
trailer [6637,6644]
trailer [6637,6644]
===
match
---
argument [18547,18570]
argument [18547,18570]
===
match
---
suite [9556,9688]
suite [9556,9688]
===
match
---
string: "Attempting to reset the db using airflow command" [5404,5454]
string: "Attempting to reset the db using airflow command" [5404,5454]
===
match
---
name: skip [13047,13051]
name: skip [13047,13051]
===
match
---
name: self [17854,17858]
name: self [17854,17858]
===
match
---
parameters [14907,14916]
parameters [14907,14916]
===
match
---
name: start [15180,15185]
name: start [15180,15185]
===
match
---
or_test [20338,20372]
or_test [20563,20597]
===
match
---
trailer [2721,2727]
trailer [2721,2727]
===
match
---
argument [4397,4414]
argument [4397,4414]
===
match
---
trailer [9212,9217]
trailer [9212,9217]
===
match
---
name: pytest [12029,12035]
name: pytest [12029,12035]
===
match
---
name: airflow [22247,22254]
name: airflow [22472,22479]
===
match
---
operator: , [12730,12731]
operator: , [12730,12731]
===
match
---
name: resetdb [5555,5562]
name: resetdb [5555,5562]
===
match
---
name: key [1734,1737]
name: key [1734,1737]
===
match
---
simple_stmt [18217,18279]
simple_stmt [18217,18279]
===
match
---
expr_stmt [10962,10995]
expr_stmt [10962,10995]
===
match
---
name: selected_systems [9480,9496]
name: selected_systems [9480,9496]
===
match
---
atom_expr [22716,22743]
atom_expr [22941,22968]
===
match
---
trailer [1684,1686]
trailer [1684,1686]
===
match
---
operator: = [19501,19502]
operator: = [19726,19727]
===
match
---
suite [9100,9202]
suite [9100,9202]
===
match
---
trailer [3209,3586]
trailer [3209,3586]
===
match
---
name: item [12574,12578]
name: item [12574,12578]
===
match
---
operator: , [20145,20146]
operator: , [20370,20371]
===
match
---
return_stmt [17799,17831]
return_stmt [17799,17831]
===
match
---
name: executor_config [22900,22915]
name: executor_config [23125,23140]
===
match
---
string: " It can be set by specifying '--integration {integration_name}' at breeze startup" [11412,11495]
string: " It can be set by specifying '--integration {integration_name}' at breeze startup" [11412,11495]
===
match
---
name: name [12321,12325]
name: name [12321,12325]
===
match
---
operator: = [20636,20637]
operator: = [20861,20862]
===
match
---
trailer [19757,19768]
trailer [19982,19993]
===
match
---
atom_expr [5464,5495]
atom_expr [5464,5495]
===
match
---
trailer [6210,6215]
trailer [6210,6215]
===
match
---
trailer [1098,1103]
trailer [1098,1103]
===
match
---
name: models [19379,19385]
name: models [19604,19610]
===
match
---
trailer [19625,19632]
trailer [19850,19857]
===
match
---
atom [2872,2879]
atom [2872,2879]
===
match
---
trailer [13777,13783]
trailer [13777,13783]
===
match
---
name: path [6272,6276]
name: path [6272,6276]
===
match
---
name: DagRunType [22328,22338]
name: DagRunType [22553,22563]
===
match
---
operator: , [15225,15226]
operator: , [15225,15226]
===
match
---
operator: , [3941,3942]
operator: , [3941,3942]
===
match
---
name: skip_system_test [9964,9980]
name: skip_system_test [9964,9980]
===
match
---
arglist [18531,18570]
arglist [18531,18570]
===
match
---
operator: = [10891,10892]
operator: = [10891,10892]
===
match
---
fstring_string: ] [5265,5266]
fstring_string: ] [5265,5266]
===
match
---
name: utils [22309,22314]
name: utils [22534,22539]
===
match
---
name: skip_if_credential_file_missing [14170,14201]
name: skip_if_credential_file_missing [14170,14201]
===
match
---
simple_stmt [4327,4525]
simple_stmt [4327,4525]
===
match
---
name: environment_variable_name [11000,11025]
name: environment_variable_name [11000,11025]
===
match
---
strings [11257,11518]
strings [11257,11518]
===
match
---
dotted_name [2101,2115]
dotted_name [2101,2115]
===
match
---
trailer [20855,20863]
trailer [21080,21088]
===
match
---
suite [12616,12885]
suite [12616,12885]
===
match
---
trailer [1095,1123]
trailer [1095,1123]
===
match
---
name: addoption [4535,4544]
name: addoption [4535,4544]
===
match
---
trailer [4958,4963]
trailer [4958,4963]
===
match
---
simple_stmt [1125,1206]
simple_stmt [1125,1206]
===
match
---
operator: , [18070,18071]
operator: , [18070,18071]
===
match
---
trailer [20174,20185]
trailer [20399,20410]
===
match
---
trailer [11061,11067]
trailer [11061,11067]
===
match
---
name: task_concurrency [22413,22429]
name: task_concurrency [22638,22654]
===
match
---
name: scope [5597,5602]
name: scope [5597,5602]
===
match
---
name: type [18098,18102]
name: type [18098,18102]
===
match
---
suite [2153,3602]
suite [2153,3602]
===
match
---
expr_stmt [2671,2733]
expr_stmt [2671,2733]
===
match
---
string: "Only tests marked with pytest.mark.system(SYSTEM) are run with SYSTEM" [9794,9865]
string: "Only tests marked with pytest.mark.system(SYSTEM) are run with SYSTEM" [9794,9865]
===
match
---
atom_expr [20319,20335]
atom_expr [20544,20560]
===
match
---
string: "integration(name): mark test to run with named integration" [7664,7724]
string: "integration(name): mark test to run with named integration" [7664,7724]
===
match
---
operator: , [22461,22462]
operator: , [22686,22687]
===
match
---
trailer [1296,1304]
trailer [1296,1304]
===
match
---
name: getoption [13252,13261]
name: getoption [13252,13261]
===
match
---
operator: , [7448,7449]
operator: , [7448,7449]
===
match
---
name: format [9908,9914]
name: format [9908,9914]
===
match
---
atom_expr [18333,18354]
atom_expr [18333,18354]
===
match
---
argument [5067,5277]
argument [5067,5277]
===
match
---
name: kwargs [22736,22742]
name: kwargs [22961,22967]
===
match
---
operator: = [2239,2240]
operator: = [2239,2240]
===
match
---
trailer [10450,10628]
trailer [10450,10628]
===
match
---
arglist [11543,11702]
arglist [11543,11702]
===
match
---
operator: = [5071,5072]
operator: = [5071,5072]
===
match
---
name: item [9981,9985]
name: item [9981,9985]
===
match
---
operator: , [18992,18993]
operator: , [18964,18965]
===
match
---
name: os [7211,7213]
name: os [7211,7213]
===
match
---
operator: , [22522,22523]
operator: , [22747,22748]
===
match
---
name: config [13909,13915]
name: config [13909,13915]
===
match
---
simple_stmt [14170,14208]
simple_stmt [14170,14208]
===
match
---
name: on_success_callback [22532,22551]
name: on_success_callback [22757,22776]
===
match
---
return_stmt [17735,17750]
return_stmt [17735,17750]
===
match
---
name: getattr [20023,20030]
name: getattr [20248,20255]
===
match
---
name: systems [9915,9922]
name: systems [9915,9922]
===
match
---
simple_stmt [6874,6892]
simple_stmt [6874,6892]
===
match
---
name: __version__ [6020,6031]
name: __version__ [6020,6031]
===
match
---
string: 'DEFAULT_DATE' [20047,20061]
string: 'DEFAULT_DATE' [20272,20286]
===
match
---
atom_expr [12029,12510]
atom_expr [12029,12510]
===
match
---
string: "," [4955,4958]
string: "," [4955,4958]
===
match
---
operator: = [22651,22652]
operator: = [22876,22877]
===
match
---
string: "all" [8631,8636]
string: "all" [8631,8636]
===
match
---
trailer [13915,13925]
trailer [13915,13925]
===
match
---
trailer [17495,17503]
trailer [17495,17503]
===
match
---
atom_expr [1168,1205]
atom_expr [1168,1205]
===
match
---
param [17866,17872]
param [17866,17872]
===
match
---
name: self [19907,19911]
name: self [20132,20136]
===
match
---
string: "BACKEND" [11840,11849]
string: "BACKEND" [11840,11849]
===
match
---
arglist [12697,12747]
arglist [12697,12747]
===
match
---
argument [12369,12401]
argument [12369,12401]
===
match
---
simple_stmt [14926,14953]
simple_stmt [14926,14953]
===
match
---
trailer [7340,7348]
trailer [7340,7348]
===
match
---
name: check_call [7412,7422]
name: check_call [7412,7422]
===
match
---
name: iter_markers [10011,10023]
name: iter_markers [10011,10023]
===
match
---
name: pytest [13040,13046]
name: pytest [13040,13046]
===
match
---
string: 'RUN_AIRFLOW_1_10' [6071,6089]
string: 'RUN_AIRFLOW_1_10' [6071,6089]
===
match
---
trailer [6122,6129]
trailer [6122,6129]
===
match
---
trailer [18155,18161]
trailer [18155,18161]
===
match
---
operator: = [18555,18556]
operator: = [18555,18556]
===
match
---
expr_stmt [2015,2097]
expr_stmt [2015,2097]
===
match
---
name: action [3786,3792]
name: action [3786,3792]
===
match
---
simple_stmt [9195,9202]
simple_stmt [9195,9202]
===
match
---
expr_stmt [4922,4990]
expr_stmt [4922,4990]
===
match
---
operator: , [19078,19079]
operator: , [19031,19032]
===
match
---
atom_expr [6486,6515]
atom_expr [6486,6515]
===
match
---
name: addinivalue_line [8173,8189]
name: addinivalue_line [8173,8189]
===
match
---
simple_stmt [785,795]
simple_stmt [785,795]
===
match
---
name: args [12650,12654]
name: args [12650,12654]
===
match
---
trailer [17275,17280]
trailer [17275,17280]
===
match
---
parameters [1908,1910]
parameters [1908,1910]
===
match
---
name: os [5344,5346]
name: os [5344,5346]
===
match
---
trailer [1992,2000]
trailer [1992,2000]
===
match
---
operator: , [2066,2067]
operator: , [2066,2067]
===
match
---
fstring_expr [12876,12882]
fstring_expr [12876,12882]
===
match
---
string: "markers" [8199,8208]
string: "markers" [8199,8208]
===
match
---
name: get [5355,5358]
name: get [5355,5358]
===
match
---
name: group [3735,3740]
name: group [3735,3740]
===
match
---
name: item [13302,13306]
name: item [13302,13306]
===
match
---
simple_stmt [8304,8404]
simple_stmt [8304,8404]
===
match
---
name: item [10313,10317]
name: item [10313,10317]
===
match
---
name: iter_markers [12579,12591]
name: iter_markers [12579,12591]
===
match
---
parameters [8445,8474]
parameters [8445,8474]
===
match
---
atom_expr [18643,18682]
atom_expr [18643,18682]
===
match
---
operator: = [8972,8973]
operator: = [8972,8973]
===
match
---
trailer [1356,1375]
trailer [1356,1375]
===
match
---
fstring_string: displayed as a comma-separated list. Supported values: [f [5176,5233]
fstring_string: displayed as a comma-separated list. Supported values: [f [5176,5233]
===
match
---
strings [7008,7173]
strings [7008,7173]
===
match
---
operator: = [19224,19225]
operator: = [19449,19450]
===
match
---
if_stmt [19457,19522]
if_stmt [19682,19747]
===
match
---
trailer [3710,3719]
trailer [3710,3719]
===
match
---
expr_stmt [1346,1450]
expr_stmt [1346,1450]
===
match
---
atom_expr [20005,20020]
atom_expr [20230,20245]
===
match
---
name: args [11803,11807]
name: args [11803,11807]
===
match
---
name: node [17156,17160]
name: node [17156,17160]
===
match
---
operator: , [19030,19031]
operator: , [19005,19006]
===
match
---
for_stmt [8480,8682]
for_stmt [8480,8682]
===
match
---
name: key [1855,1858]
name: key [1855,1858]
===
match
---
operator: = [18023,18024]
operator: = [18023,18024]
===
match
---
suite [13027,13106]
suite [13027,13106]
===
match
---
param [17854,17859]
param [17854,17859]
===
match
---
for_stmt [1730,1876]
for_stmt [1730,1876]
===
match
---
operator: , [22432,22433]
operator: , [22657,22658]
===
match
---
simple_stmt [3696,3731]
simple_stmt [3696,3731]
===
match
---
name: skip [11239,11243]
name: skip [11239,11243]
===
match
---
name: environment_variable_value [11966,11992]
name: environment_variable_value [11966,11992]
===
match
---
name: credential_file [12625,12640]
name: credential_file [12625,12640]
===
match
---
string: 'test_dag' [19225,19235]
string: 'test_dag' [19450,19460]
===
match
---
name: RUNNING [18893,18900]
name: RUNNING [18859,18866]
===
match
---
name: task_concurrency [22850,22866]
name: task_concurrency [23075,23091]
===
match
---
atom_expr [18152,18163]
atom_expr [18152,18163]
===
match
---
trailer [19572,19580]
trailer [19797,19805]
===
match
---
parameters [17335,17341]
parameters [17335,17341]
===
match
---
trailer [15185,15187]
trailer [15185,15187]
===
match
---
trailer [21160,21194]
trailer [21385,21419]
===
match
---
name: dag [17601,17604]
name: dag [17601,17604]
===
match
---
atom_expr [2705,2732]
atom_expr [2705,2732]
===
match
---
trailer [4332,4342]
trailer [4332,4342]
===
match
---
atom_expr [1259,1291]
atom_expr [1259,1291]
===
match
---
simple_stmt [1346,1451]
simple_stmt [1346,1451]
===
match
---
simple_stmt [8541,8575]
simple_stmt [8541,8575]
===
match
---
atom [5072,5277]
atom [5072,5277]
===
match
---
name: pytest [10439,10445]
name: pytest [10439,10445]
===
match
---
name: item [14202,14206]
name: item [14202,14206]
===
match
---
name: selected_systems_list [13652,13673]
name: selected_systems_list [13652,13673]
===
match
---
simple_stmt [17945,18006]
simple_stmt [17945,18006]
===
match
---
name: write_line [2796,2806]
name: write_line [2796,2806]
===
match
---
operator: , [3829,3830]
operator: , [3829,3830]
===
match
---
name: delete [20937,20943]
name: delete [21162,21168]
===
match
---
arglist [7938,8014]
arglist [7938,8014]
===
match
---
operator: = [9123,9124]
operator: = [9123,9124]
===
match
---
expr_stmt [6060,6099]
expr_stmt [6060,6099]
===
match
---
string: "/files/airflow-breeze-config/keys" [1415,1450]
string: "/files/airflow-breeze-config/keys" [1415,1450]
===
match
---
atom_expr [5552,5564]
atom_expr [5552,5564]
===
match
---
suite [21507,21562]
suite [21732,21787]
===
match
---
parameters [10942,10956]
parameters [10942,10956]
===
match
---
simple_stmt [18152,18164]
simple_stmt [18152,18164]
===
match
---
name: lock_file [6936,6945]
name: lock_file [6936,6945]
===
match
---
name: create_dagrun [19121,19134]
name: create_dagrun [19346,19359]
===
match
---
name: sys [7581,7584]
name: sys [7581,7584]
===
match
---
string: ": {item}" [9382,9392]
string: ": {item}" [9382,9392]
===
match
---
atom_expr [10464,10618]
atom_expr [10464,10618]
===
match
---
param [22686,22695]
param [22911,22920]
===
match
---
suite [9182,9202]
suite [9182,9202]
===
match
---
name: self [19212,19216]
name: self [19437,19441]
===
match
---
import_from [824,856]
import_from [824,856]
===
match
---
operator: = [23009,23010]
operator: = [23234,23235]
===
match
---
funcdef [9445,9958]
funcdef [9445,9958]
===
match
---
param [22600,22625]
param [22825,22850]
===
match
---
argument [12476,12485]
argument [12476,12485]
===
match
---
import_from [857,897]
import_from [857,897]
===
match
---
operator: = [12325,12326]
operator: = [12325,12326]
===
match
---
name: print [6105,6110]
name: print [6105,6110]
===
match
---
comp_op [18103,18109]
comp_op [18103,18109]
===
match
---
simple_stmt [5398,5456]
simple_stmt [5398,5456]
===
match
---
simple_stmt [6599,6617]
simple_stmt [6599,6617]
===
match
---
name: format [11519,11525]
name: format [11519,11525]
===
match
---
string: """     Resets Airflow db.     """ [1916,1950]
string: """     Resets Airflow db.     """ [1916,1950]
===
match
---
operator: = [5049,5050]
operator: = [5049,5050]
===
match
---
operator: = [22397,22398]
operator: = [22622,22623]
===
match
---
atom_expr [5344,5378]
atom_expr [5344,5378]
===
match
---
atom_expr [19684,19716]
atom_expr [19909,19941]
===
match
---
simple_stmt [21013,21109]
simple_stmt [21238,21334]
===
match
---
param [22634,22657]
param [22859,22882]
===
match
---
name: kwargs [18718,18724]
name: kwargs [18718,18724]
===
match
---
name: columns [3335,3342]
name: columns [3335,3342]
===
match
---
name: exit_stack [2838,2848]
name: exit_stack [2838,2848]
===
match
---
name: environ [1128,1135]
name: environ [1128,1135]
===
match
---
name: item [9426,9430]
name: item [9426,9430]
===
match
---
trailer [7736,7753]
trailer [7736,7753]
===
match
---
return_stmt [2771,2812]
return_stmt [2771,2812]
===
match
---
name: integration [8933,8944]
name: integration [8933,8944]
===
match
---
name: dag [23332,23335]
name: dag [23557,23560]
===
match
---
simple_stmt [11074,11145]
simple_stmt [11074,11145]
===
match
---
trailer [12303,12500]
trailer [12303,12500]
===
match
---
trailer [15059,15064]
trailer [15059,15064]
===
match
---
expr_stmt [20269,20306]
expr_stmt [20494,20531]
===
match
---
suite [5505,5565]
suite [5505,5565]
===
match
---
comparison [3487,3510]
comparison [3487,3510]
===
match
---
operator: , [22403,22404]
operator: , [22628,22629]
===
match
---
name: freeze_time [15105,15116]
name: freeze_time [15105,15116]
===
match
---
name: serialized_dag [18531,18545]
name: serialized_dag [18531,18545]
===
match
---
trailer [18677,18681]
trailer [18677,18681]
===
match
---
operator: = [22807,22808]
operator: = [23032,23033]
===
match
---
name: os [1080,1082]
name: os [1080,1082]
===
match
---
name: ALLOWED_TRACE_SQL_COLUMNS [4964,4989]
name: ALLOWED_TRACE_SQL_COLUMNS [4964,4989]
===
match
---
name: item [13173,13177]
name: item [13173,13177]
===
match
---
arglist [22726,22742]
arglist [22951,22967]
===
match
---
name: marker [12643,12649]
name: marker [12643,12649]
===
match
---
simple_stmt [7188,7250]
simple_stmt [7188,7250]
===
match
---
simple_stmt [2645,2651]
simple_stmt [2645,2651]
===
match
---
suite [2880,3104]
suite [2880,3104]
===
match
---
name: self [21121,21125]
name: self [21346,21350]
===
match
---
operator: , [7947,7948]
operator: , [7947,7948]
===
match
---
trailer [11105,11113]
trailer [11105,11113]
===
match
---
name: self [18397,18401]
name: self [18397,18401]
===
match
---
atom_expr [8304,8403]
atom_expr [8304,8403]
===
match
---
simple_stmt [3041,3104]
simple_stmt [3041,3104]
===
match
---
dotted_name [1570,1584]
dotted_name [1570,1584]
===
match
---
name: perf_kit [1479,1487]
name: perf_kit [1479,1487]
===
match
---
trailer [20273,20277]
trailer [20498,20502]
===
match
---
simple_stmt [9206,9443]
simple_stmt [9206,9443]
===
match
---
name: tests_directory [1062,1077]
name: tests_directory [1062,1077]
===
match
---
string: ".airflow_db_initialised" [6452,6477]
string: ".airflow_db_initialised" [6452,6477]
===
match
---
param [19212,19217]
param [19437,19442]
===
match
---
string: """     The dag_maker helps us to create DAG, DagModel, and SerializedDAG automatically.      You have to use the dag_maker as a context manager and it takes     the same argument as DAG::          with dag_maker(dag_id="mydag") as dag:             task1 = DummyOperator(task_id='mytask')             task2 = DummyOperator(task_id='mytask2')      If the DagModel you want to use needs different parameters than the one     automatically created by the dag_maker, you have to update the DagModel as below::          dag_maker.dag_model.is_active = False         session.merge(dag_maker.dag_model)         session.commit()      For any test you use the dag_maker, make sure to create a DagRun::          dag_maker.create_dagrun()      The dag_maker.create_dagrun takes the same arguments as dag.create_dagrun      If you want to operate on serialized DAGs, then either pass ``serialized=True` to the ``dag_maker()``     call, or you can mark your test/class/file with ``@pytest.mark.need_serialized_dag(True)``. In both of     these cases the ``dag`` returned by the context manager will be a lazily-evaluated proxy object to the     SerializedDAG.     """ [15497,16651]
string: """     The dag_maker helps us to create DAG, DagModel, and SerializedDAG automatically.      You have to use the dag_maker as a context manager and it takes     the same argument as DAG::          with dag_maker(dag_id="mydag") as dag:             task1 = DummyOperator(task_id='mytask')             task2 = DummyOperator(task_id='mytask2')      If the DagModel you want to use needs different parameters than the one     automatically created by the dag_maker, you have to update the DagModel as below::          dag_maker.dag_model.is_active = False         session.merge(dag_maker.dag_model)         session.commit()      For any test you use the dag_maker, make sure to create a DagRun::          dag_maker.create_dagrun()      The dag_maker.create_dagrun takes the same arguments as dag.create_dagrun      If you want to operate on serialized DAGs, then either pass ``serialized=True` to the ``dag_maker()``     call, or you can mark your test/class/file with ``@pytest.mark.need_serialized_dag(True)``. In both of     these cases the ``dag`` returned by the context manager will be a lazily-evaluated proxy object to the     SerializedDAG.     """ [15497,16651]
===
match
---
trailer [9392,9399]
trailer [9392,9399]
===
match
---
suite [15492,21562]
suite [15492,21787]
===
match
---
name: www [15395,15398]
name: www [15395,15398]
===
match
---
dotted_name [19371,19385]
dotted_name [19596,19610]
===
match
---
name: os [1802,1804]
name: os [1802,1804]
===
match
---
name: pool [23186,23190]
name: pool [23411,23415]
===
match
---
arglist [9400,9435]
arglist [9400,9435]
===
match
---
operator: , [23195,23196]
operator: , [23420,23421]
===
match
---
string: " AIRFLOW " [6111,6122]
string: " AIRFLOW " [6111,6122]
===
match
---
name: os [1844,1846]
name: os [1844,1846]
===
match
---
name: db [5540,5542]
name: db [5540,5542]
===
match
---
argument [3364,3396]
argument [3364,3396]
===
match
---
name: DEFAULT_DATE [20188,20200]
name: DEFAULT_DATE [20413,20425]
===
match
---
trailer [12771,12778]
trailer [12771,12778]
===
match
---
operator: = [1292,1293]
operator: = [1292,1293]
===
match
---
trailer [18606,18608]
trailer [18606,18608]
===
match
---
expr_stmt [19568,19590]
expr_stmt [19793,19815]
===
match
---
trailer [18238,18246]
trailer [18238,18246]
===
match
---
trailer [18892,18900]
trailer [18858,18866]
===
match
---
name: addinivalue_line [8027,8043]
name: addinivalue_line [8027,8043]
===
match
---
arglist [4554,4716]
arglist [4554,4716]
===
match
---
atom_expr [13802,13835]
atom_expr [13802,13835]
===
match
---
argument [11543,11573]
argument [11543,11573]
===
match
---
string: "The test is skipped because it has quarantined marker. " [10749,10806]
string: "The test is skipped because it has quarantined marker. " [10749,10806]
===
match
---
param [12549,12553]
param [12549,12553]
===
match
---
strings [8707,8925]
strings [8707,8925]
===
match
---
simple_stmt [9692,9958]
simple_stmt [9692,9958]
===
match
---
trailer [9914,9951]
trailer [9914,9951]
===
match
---
trailer [12984,12992]
trailer [12984,12992]
===
match
---
for_stmt [12560,12885]
for_stmt [12560,12885]
===
match
---
atom_expr [15162,15187]
atom_expr [15162,15187]
===
match
---
trailer [18252,18262]
trailer [18252,18262]
===
match
---
name: seconds [14908,14915]
name: seconds [14908,14915]
===
match
---
name: traceback [17873,17882]
name: traceback [17873,17882]
===
match
---
atom_expr [1844,1859]
atom_expr [1844,1859]
===
match
---
name: airflow [17360,17367]
name: airflow [17360,17367]
===
match
---
operator: , [4715,4716]
operator: , [4715,4716]
===
match
---
trailer [13397,13422]
trailer [13397,13422]
===
match
---
argument [13460,13478]
argument [13460,13478]
===
match
---
import_from [19409,19443]
import_from [19634,19668]
===
match
---
fstring [6310,6366]
fstring [6310,6366]
===
match
---
trailer [21194,21201]
trailer [21419,21426]
===
match
---
trailer [18161,18163]
trailer [18161,18163]
===
match
---
operator: , [1544,1545]
operator: , [1544,1545]
===
match
---
funcdef [11729,12511]
funcdef [11729,12511]
===
match
---
name: DagModel [21290,21298]
name: DagModel [21515,21523]
===
match
---
name: os [7338,7340]
name: os [7338,7340]
===
match
---
or_test [11932,12019]
or_test [11932,12019]
===
match
---
name: SerializedDagModel [17987,18005]
name: SerializedDagModel [17987,18005]
===
match
---
name: selected_systems_list [13216,13237]
name: selected_systems_list [13216,13237]
===
match
---
name: want_serialized [17637,17652]
name: want_serialized [17637,17652]
===
match
---
name: skip_if_integration_disabled [13489,13517]
name: skip_if_integration_disabled [13489,13517]
===
match
---
name: op [23337,23339]
name: op [23562,23564]
===
match
---
name: selected_backend [9148,9164]
name: selected_backend [9148,9164]
===
match
---
name: dagbag [18648,18654]
name: dagbag [18648,18654]
===
match
---
arglist [7847,7908]
arglist [7847,7908]
===
match
---
name: _serialized_dag [18477,18492]
name: _serialized_dag [18477,18492]
===
match
---
operator: = [16976,16977]
operator: = [16976,16977]
===
match
---
string: "INTEGRATIONS" [3984,3998]
string: "INTEGRATIONS" [3984,3998]
===
match
---
comparison [15268,15297]
comparison [15268,15297]
===
match
---
name: enter_context [3196,3209]
name: enter_context [3196,3209]
===
match
---
name: lock_file [6645,6654]
name: lock_file [6645,6654]
===
match
---
trailer [7348,7352]
trailer [7348,7352]
===
match
---
simple_stmt [19568,19591]
simple_stmt [19793,19816]
===
match
---
trailer [10445,10450]
trailer [10445,10450]
===
match
---
trailer [20030,20062]
trailer [20255,20287]
===
match
---
string: 'parameters' [3157,3169]
string: 'parameters' [3157,3169]
===
match
---
name: on_failure_callback [23047,23066]
name: on_failure_callback [23272,23291]
===
match
---
name: changed_env [1741,1752]
name: changed_env [1741,1752]
===
match
---
atom_expr [17596,17616]
atom_expr [17596,17616]
===
match
---
name: session [19279,19286]
name: session [19504,19511]
===
match
---
name: default_args [19669,19681]
name: default_args [19894,19906]
===
match
---
name: item [9946,9950]
name: item [9946,9950]
===
match
---
operator: = [4818,4819]
operator: = [4818,4819]
===
match
---
for_stmt [13428,13532]
for_stmt [13428,13532]
===
match
---
atom_expr [7823,7909]
atom_expr [7823,7909]
===
match
---
string: "{name} environment variable to be set to true (it is '{value}')." [11333,11399]
string: "{name} environment variable to be set to true (it is '{value}')." [11333,11399]
===
match
---
strings [12054,12296]
strings [12054,12296]
===
match
---
name: airflow [5985,5992]
name: airflow [5985,5992]
===
match
---
name: DAG [19393,19396]
name: DAG [19618,19621]
===
match
---
operator: = [23121,23122]
operator: = [23346,23347]
===
match
---
name: on_retry_callback [22634,22651]
name: on_retry_callback [22859,22876]
===
match
---
trailer [10303,10306]
trailer [10303,10306]
===
match
---
operator: , [20142,20143]
operator: , [20367,20368]
===
match
---
operator: , [11623,11624]
operator: , [11623,11624]
===
match
---
string: "RUN_AIRFLOW_1_10" [12997,13015]
string: "RUN_AIRFLOW_1_10" [12997,13015]
===
match
---
operator: , [13735,13736]
operator: , [13735,13736]
===
match
---
name: want_serialized [20390,20405]
name: want_serialized [20615,20630]
===
match
---
name: TaskInstance [20529,20541]
name: TaskInstance [20754,20766]
===
match
---
name: self [20817,20821]
name: self [21042,21046]
===
match
---
suite [19818,19888]
suite [20043,20113]
===
match
---
operator: , [22972,22973]
operator: , [23197,23198]
===
match
---
param [22532,22557]
param [22757,22782]
===
match
---
name: display_trace [3364,3377]
name: display_trace [3364,3377]
===
match
---
name: get [19870,19873]
name: get [20095,20098]
===
match
---
name: config [13307,13313]
name: config [13307,13313]
===
match
---
atom_expr [18416,18437]
atom_expr [18416,18437]
===
match
---
suite [13674,13743]
suite [13674,13743]
===
match
---
trailer [19106,19114]
trailer [19331,19339]
===
match
---
name: fixture [1577,1584]
name: fixture [1577,1584]
===
match
---
name: self [19839,19843]
name: self [20064,20068]
===
match
---
simple_stmt [4727,4918]
simple_stmt [4727,4918]
===
match
---
expr_stmt [21440,21462]
expr_stmt [21665,21687]
===
match
---
operator: = [18856,18857]
operator: { [18826,18827]
===
match
---
comparison [9606,9638]
comparison [9606,9638]
===
match
---
name: TaskInstance [21161,21173]
name: TaskInstance [21386,21398]
===
match
---
trailer [11067,11069]
trailer [11067,11069]
===
match
---
trailer [11518,11525]
trailer [11518,11525]
===
match
---
name: on_execute_callback [22990,23009]
name: on_execute_callback [23215,23234]
===
match
---
name: _serialized_dag [17706,17721]
name: _serialized_dag [17706,17721]
===
match
---
name: sqlalchemy [1488,1498]
name: sqlalchemy [1488,1498]
===
match
---
trailer [18375,18380]
trailer [18375,18380]
===
match
---
name: environment_variable_value [12375,12401]
name: environment_variable_value [12375,12401]
===
match
---
operator: ** [19080,19082]
operator: } [19045,19046]
===
match
---
argument [11641,11674]
argument [11641,11674]
===
match
---
simple_stmt [6525,6591]
simple_stmt [6525,6591]
===
match
---
arglist [13518,13530]
arglist [13518,13530]
===
match
---
atom_expr [6060,6090]
atom_expr [6060,6090]
===
match
---
name: testing [15437,15444]
name: testing [15437,15444]
===
match
---
operator: = [6423,6424]
operator: = [6423,6424]
===
match
---
operator: = [22849,22850]
operator: = [23074,23075]
===
match
---
name: marker [10292,10298]
name: marker [10292,10298]
===
match
---
operator: = [3088,3089]
operator: = [3088,3089]
===
match
---
name: __file__ [1113,1121]
name: __file__ [1113,1121]
===
match
---
not_test [19903,19922]
not_test [20128,20147]
===
match
---
name: value [17866,17871]
name: value [17866,17871]
===
match
---
suite [12555,12885]
suite [12555,12885]
===
match
---
atom_expr [18397,18438]
atom_expr [18397,18438]
===
match
---
comparison [3274,3290]
comparison [3274,3290]
===
match
---
atom_expr [19018,19030]
atom_expr [18993,19005]
===
match
---
import_name [916,929]
import_name [916,929]
===
match
---
name: DagFactory [21450,21460]
name: DagFactory [21675,21685]
===
match
---
dotted_name [5568,5582]
dotted_name [5568,5582]
===
match
---
operator: = [20021,20022]
operator: = [20246,20247]
===
match
---
atom_expr [20638,20663]
atom_expr [20863,20888]
===
match
---
trailer [21180,21184]
trailer [21405,21409]
===
match
---
arglist [20284,20305]
arglist [20509,20530]
===
match
---
name: __file__ [20364,20372]
name: __file__ [20589,20597]
===
match
---
arglist [6130,6137]
arglist [6130,6137]
===
match
---
name: state [18758,18763]
name: state [18758,18763]
===
match
---
argument [4247,4315]
argument [4247,4315]
===
match
---
operator: , [18900,18901]
operator: , [18866,18867]
===
match
---
operator: , [11761,11762]
operator: , [11761,11762]
===
match
---
suite [14060,14098]
suite [14060,14098]
===
match
---
simple_stmt [18455,18495]
simple_stmt [18455,18495]
===
match
---
trailer [2685,2691]
trailer [2685,2691]
===
match
---
name: create_dagrun [23272,23285]
name: create_dagrun [23497,23510]
===
match
---
simple_stmt [1658,1687]
simple_stmt [1658,1687]
===
match
---
name: utils [19422,19427]
name: utils [19647,19652]
===
match
---
string: "markers" [8053,8062]
string: "markers" [8053,8062]
===
match
---
trailer [5466,5473]
trailer [5466,5473]
===
match
---
trailer [20389,20405]
trailer [20614,20630]
===
match
---
operator: = [10028,10029]
operator: = [10028,10029]
===
match
---
arglist [7653,7724]
arglist [7653,7724]
===
match
---
name: on_execute_callback [22566,22585]
name: on_execute_callback [22791,22810]
===
match
---
string: 'time' [3133,3139]
string: 'time' [3133,3139]
===
match
---
name: self [18472,18476]
name: self [18472,18476]
===
match
---
name: factory [21487,21494]
name: factory [21712,21719]
===
match
---
if_stmt [19786,19888]
if_stmt [20011,20113]
===
match
---
trailer [13251,13261]
trailer [13251,13261]
===
match
---
trailer [11238,11243]
trailer [11238,11243]
===
match
---
atom_expr [3066,3102]
atom_expr [3066,3102]
===
match
---
name: get_closest_marker [17161,17179]
name: get_closest_marker [17161,17179]
===
match
---
operator: , [17858,17859]
operator: , [17858,17859]
===
match
---
name: skip_if_integration_disabled [10914,10942]
name: skip_if_integration_disabled [10914,10942]
===
match
---
trailer [17476,17483]
trailer [17476,17483]
===
match
---
string: "store_true" [3793,3805]
string: "store_true" [3793,3805]
===
match
---
operator: ** [19068,19070]
operator: ** [19023,19025]
===
match
---
name: freezegun_control [14863,14880]
name: freezegun_control [14863,14880]
===
match
---
name: help [4814,4818]
name: help [4814,4818]
===
match
---
trailer [10010,10023]
trailer [10010,10023]
===
match
---
name: self [20294,20298]
name: self [20519,20523]
===
match
---
operator: , [22694,22695]
operator: , [22919,22920]
===
match
---
simple_stmt [18046,18083]
simple_stmt [18046,18083]
===
match
---
argument [10024,10037]
argument [10024,10037]
===
match
---
simple_stmt [7401,7470]
simple_stmt [7401,7470]
===
match
---
number: 1 [20144,20145]
number: 1 [20369,20370]
===
match
---
if_stmt [6017,6100]
if_stmt [6017,6100]
===
match
---
import_as_names [1531,1564]
import_as_names [1531,1564]
===
match
---
trailer [1175,1180]
trailer [1175,1180]
===
match
---
name: request [2362,2369]
name: request [2362,2369]
===
match
---
operator: , [1563,1564]
operator: , [1563,1564]
===
match
---
expr_stmt [17128,17202]
expr_stmt [17128,17202]
===
match
---
atom_expr [8560,8574]
atom_expr [8560,8574]
===
match
---
simple_stmt [22764,23254]
simple_stmt [22989,23479]
===
match
---
decorated [1878,2013]
decorated [1878,2013]
===
match
---
name: get [12708,12711]
name: get [12708,12711]
===
match
---
name: action [3951,3957]
name: action [3951,3957]
===
match
---
string: "airflow_2: mark tests that works only on Airflow 2.0 / master" [8339,8402]
string: "airflow_2: mark tests that works only on Airflow 2.0 / master" [8339,8402]
===
match
---
operator: = [6233,6234]
operator: = [6233,6234]
===
match
---
trailer [20926,20935]
trailer [21151,21160]
===
match
---
operator: , [3342,3343]
operator: , [3342,3343]
===
match
---
trailer [19869,19873]
trailer [20094,20098]
===
match
---
name: task_id [22808,22815]
name: task_id [23033,23040]
===
match
---
suite [12020,12511]
suite [12020,12511]
===
match
---
argument [5043,5057]
argument [5043,5057]
===
match
---
argument [3312,3342]
argument [3312,3342]
===
match
---
operator: + [11043,11044]
operator: + [11043,11044]
===
match
---
string: "time.sleep" [15213,15225]
string: "time.sleep" [15213,15225]
===
match
---
yield_expr [21481,21494]
yield_expr [21706,21719]
===
match
---
name: environment_variable_value [11186,11212]
name: environment_variable_value [11186,11212]
===
match
---
expr_stmt [14961,14987]
expr_stmt [14961,14987]
===
match
---
name: initial_db_init [5318,5333]
name: initial_db_init [5318,5333]
===
match
---
atom_expr [18191,18203]
atom_expr [18191,18203]
===
match
---
trailer [10600,10607]
trailer [10600,10607]
===
match
---
simple_stmt [19157,19177]
simple_stmt [19382,19402]
===
match
---
trailer [1348,1356]
trailer [1348,1356]
===
match
---
atom_expr [14138,14165]
atom_expr [14138,14165]
===
match
---
name: config [7629,7635]
name: config [7629,7635]
===
match
---
name: kwargs [19540,19546]
name: kwargs [19765,19771]
===
match
---
operator: = [11794,11795]
operator: = [11794,11795]
===
match
---
for_stmt [12925,13106]
for_stmt [12925,13106]
===
match
---
name: on_failure_callback [23067,23086]
name: on_failure_callback [23292,23311]
===
match
---
operator: == [2869,2871]
operator: == [2869,2871]
===
match
---
del_stmt [1798,1817]
del_stmt [1798,1817]
===
match
---
trailer [15212,15238]
trailer [15212,15238]
===
match
---
atom_expr [9692,9957]
atom_expr [9692,9957]
===
match
---
argument [12952,12968]
argument [12952,12968]
===
match
---
operator: { [22487,22488]
operator: { [22712,22713]
===
match
---
trailer [5898,5959]
trailer [5898,5959]
===
match
---
string: "1.10" [6043,6049]
string: "1.10" [6043,6049]
===
match
---
argument [2116,2128]
argument [2116,2128]
===
match
---
name: os [6269,6271]
name: os [6269,6271]
===
match
---
simple_stmt [14138,14166]
simple_stmt [14138,14166]
===
match
---
expr_stmt [19102,19144]
expr_stmt [19327,19369]
===
match
---
name: sync_to_db [18180,18190]
name: sync_to_db [18180,18190]
===
match
---
name: stop [15060,15064]
name: stop [15060,15064]
===
match
---
name: selected_integrations_list [13611,13637]
name: selected_integrations_list [13611,13637]
===
match
---
expr_stmt [1259,1345]
expr_stmt [1259,1345]
===
match
---
name: dest [3815,3819]
name: dest [3815,3819]
===
match
---
atom_expr [10006,10038]
atom_expr [10006,10038]
===
match
---
operator: , [23168,23169]
operator: , [23393,23394]
===
match
---
suite [11223,11727]
suite [11223,11727]
===
match
---
trailer [14985,14987]
trailer [14985,14987]
===
match
---
comparison [2861,2879]
comparison [2861,2879]
===
match
---
trailer [17179,17202]
trailer [17179,17202]
===
match
---
name: format [8926,8932]
name: format [8926,8932]
===
match
---
classdef [17297,21435]
classdef [17297,21660]
===
match
---
operator: = [19286,19287]
operator: = [19511,19512]
===
match
---
name: factory [21516,21523]
name: factory [21741,21748]
===
match
---
string: "The test requires one of {valid_backend_names} backend started and " [12054,12123]
string: "The test requires one of {valid_backend_names} backend started and " [12054,12123]
===
match
---
argument [23286,23315]
argument [23511,23540]
===
match
---
name: marker [9125,9131]
name: marker [9125,9131]
===
match
---
name: pytest_configure [7599,7615]
name: pytest_configure [7599,7615]
===
match
---
name: self [19603,19607]
name: self [19828,19832]
===
match
---
name: initial_db_init [6599,6614]
name: initial_db_init [6599,6614]
===
match
---
name: airflow [18744,18751]
name: airflow [18744,18751]
===
match
---
trailer [5403,5455]
trailer [5403,5455]
===
match
---
comp_op [15286,15292]
comp_op [15286,15292]
===
match
---
name: addoption [4156,4165]
name: addoption [4156,4165]
===
match
---
name: item [10613,10617]
name: item [10613,10617]
===
match
---
name: item [14092,14096]
name: item [14092,14096]
===
match
---
string: "AIRFLOW__CORE__DAGS_FOLDER" [1136,1164]
string: "AIRFLOW__CORE__DAGS_FOLDER" [1136,1164]
===
match
---
name: fake_sleep [15227,15237]
name: fake_sleep [15227,15237]
===
match
---
operator: = [3702,3703]
operator: = [3702,3703]
===
match
---
trailer [19632,19636]
trailer [19857,19861]
===
match
---
operator: , [3776,3777]
operator: , [3776,3777]
===
match
---
trailer [9703,9957]
trailer [9703,9957]
===
match
---
or_test [6235,6298]
or_test [6235,6298]
===
match
---
dotted_name [19414,19427]
dotted_name [19639,19652]
===
match
---
name: State [18771,18776]
name: State [18771,18776]
===
match
---
operator: = [22619,22620]
operator: = [22844,22845]
===
match
---
name: task_id [22800,22807]
name: task_id [23025,23032]
===
match
---
name: airflow [17902,17909]
name: airflow [17902,17909]
===
match
---
name: realpath [1104,1112]
name: realpath [1104,1112]
===
match
---
trailer [17827,17831]
trailer [17827,17831]
===
match
---
name: iter_markers [12939,12951]
name: iter_markers [12939,12951]
===
match
---
arglist [8199,8293]
arglist [8199,8293]
===
match
---
operator: = [20118,20119]
operator: = [20343,20344]
===
match
---
name: dag [22747,22750]
name: dag [22972,22975]
===
match
---
trailer [9540,9555]
trailer [9540,9555]
===
match
---
trailer [17810,17827]
trailer [17810,17827]
===
match
---
operator: , [6450,6451]
operator: , [6450,6451]
===
match
---
operator: , [5304,5305]
operator: , [5304,5305]
===
match
---
if_stmt [6483,7184]
if_stmt [6483,7184]
===
match
---
trailer [21053,21060]
trailer [21278,21285]
===
match
---
atom_expr [18046,18082]
atom_expr [18046,18082]
===
match
---
name: frozen_sleep [14263,14275]
name: frozen_sleep [14263,14275]
===
match
---
operator: @ [14243,14244]
operator: @ [14243,14244]
===
match
---
trailer [1804,1812]
trailer [1804,1812]
===
match
---
atom_expr [18673,18681]
atom_expr [18673,18681]
===
match
---
name: environ [1262,1269]
name: environ [1262,1269]
===
match
---
suite [1911,2013]
suite [1911,2013]
===
match
---
name: executor_config [22471,22486]
name: executor_config [22696,22711]
===
match
---
name: read_dags_from_db [17529,17546]
name: read_dags_from_db [17529,17546]
===
match
---
operator: , [4315,4316]
operator: , [4315,4316]
===
match
---
string: "CREDENTIALS_DIR" [1357,1374]
string: "CREDENTIALS_DIR" [1357,1374]
===
match
---
atom_expr [15042,15066]
atom_expr [15042,15066]
===
match
---
trailer [15064,15066]
trailer [15064,15066]
===
match
---
name: on_success_callback [22953,22972]
name: on_success_callback [23178,23197]
===
match
---
trailer [18530,18571]
trailer [18530,18571]
===
match
---
strings [9713,9907]
strings [9713,9907]
===
match
---
name: freezegun [906,915]
name: freezegun [906,915]
===
match
---
name: pytest_addoption [3608,3624]
name: pytest_addoption [3608,3624]
===
match
---
strings [10464,10600]
strings [10464,10600]
===
match
---
string: """     This fixture creates a `DAG` with a single `DummyOperator` task.     DagRun and DagModel is also created.      Apart from the already existing arguments, any other argument in kwargs     is passed to the DAG and not to the DummyOperator task.      If you have an argument that you want to pass to the DummyOperator that     is not here, please use `default_args` so that the DAG will pass it to the     Task::          dag, task = create_dummy_dag(default_args={'start_date':timezone.datetime(2016, 1, 1)})      You cannot be able to alter the created DagRun or DagModel, use `dag_maker` fixture instead.     """ [21617,22237]
string: """     This fixture creates a `DAG` with a single `DummyOperator` task.     DagRun and DagModel is also created.      Apart from the already existing arguments, any other argument in kwargs     is passed to the DAG and not to the DummyOperator task.      If you have an argument that you want to pass to the DummyOperator that     is not here, please use `default_args` so that the DAG will pass it to the     Task::          dag, task = create_dummy_dag(default_args={'start_date':timezone.datetime(2016, 1, 1)})      You cannot be able to alter the created DagRun or DagModel, use `dag_maker` fixture instead.     """ [21842,22462]
===
match
---
name: DummyOperator [22769,22782]
name: DummyOperator [22994,23007]
===
match
---
argument [10285,10306]
argument [10285,10306]
===
match
---
name: strip [2686,2691]
name: strip [2686,2691]
===
match
---
name: trigger_rule [23213,23225]
name: trigger_rule [23438,23450]
===
match
---
atom [3132,3170]
atom [3132,3170]
===
match
---
trailer [21417,21425]
trailer [21642,21650]
===
match
---
name: airflow [22301,22308]
name: airflow [22526,22533]
===
match
---
suite [19769,19888]
suite [19994,20113]
===
match
---
atom_expr [6105,6139]
atom_expr [6105,6139]
===
match
---
atom_expr [21450,21462]
atom_expr [21675,21687]
===
match
---
name: SerializedDagModel [20596,20614]
name: SerializedDagModel [20821,20839]
===
match
---
name: environment_variable_name [11812,11837]
name: environment_variable_name [11812,11837]
===
match
---
operator: @ [21564,21565]
operator: @ [21789,21790]
===
match
---
atom_expr [20897,20935]
atom_expr [21122,21160]
===
match
---
param [5637,5644]
param [5637,5644]
===
match
---
atom_expr [1346,1375]
atom_expr [1346,1375]
===
match
---
funcdef [18692,19177]
funcdef [18692,19402]
===
match
---
if_stmt [17629,17723]
if_stmt [17629,17723]
===
match
---
trailer [6432,6437]
trailer [6432,6437]
===
match
---
trailer [15179,15185]
trailer [15179,15185]
===
match
---
name: self [18643,18647]
name: self [18643,18647]
===
match
---
operator: = [20239,20240]
operator: = [20464,20465]
===
match
---
simple_stmt [13354,13423]
simple_stmt [13354,13423]
===
match
---
atom_expr [5893,5959]
atom_expr [5893,5959]
===
match
---
suite [18115,18139]
suite [18115,18139]
===
match
---
string: "true" [7281,7287]
string: "true" [7281,7287]
===
match
---
name: session [18593,18600]
name: session [18593,18600]
===
match
---
name: start_date [20246,20256]
name: start_date [20471,20481]
===
match
---
suite [3633,5312]
suite [3633,5312]
===
match
---
simple_stmt [17128,17203]
simple_stmt [17128,17203]
===
match
---
expr_stmt [19603,19656]
expr_stmt [19828,19881]
===
match
---
name: self [17336,17340]
name: self [17336,17340]
===
match
---
atom_expr [19535,19546]
atom_expr [19760,19771]
===
match
---
atom_expr [19907,19922]
atom_expr [20132,20147]
===
match
---
name: credential_path [12858,12873]
name: credential_path [12858,12873]
===
match
---
name: metavar [4397,4404]
name: metavar [4397,4404]
===
match
---
atom_expr [6020,6050]
atom_expr [6020,6050]
===
match
---
name: environ [7214,7221]
name: environ [7214,7221]
===
match
---
name: filter [20890,20896]
name: filter [21115,21121]
===
match
---
suite [10663,10908]
suite [10663,10908]
===
match
---
operator: = [15444,15445]
operator: = [15444,15445]
===
match
---
string: "," [2728,2731]
string: "," [2728,2731]
===
match
---
trailer [20647,20654]
trailer [20872,20879]
===
match
---
parameters [19198,19311]
parameters [19423,19536]
===
match
---
simple_stmt [19102,19145]
simple_stmt [19327,19370]
===
match
---
name: fixture [2108,2115]
name: fixture [2108,2115]
===
match
---
atom_expr [21413,21434]
atom_expr [21638,21659]
===
match
---
trailer [20936,20943]
trailer [21161,21168]
===
match
---
string: "=" [6134,6137]
string: "=" [6134,6137]
===
match
---
name: pytest [9206,9212]
name: pytest [9206,9212]
===
match
---
for_stmt [9052,9202]
for_stmt [9052,9202]
===
match
---
atom_expr [17677,17722]
atom_expr [17677,17722]
===
match
---
trailer [19511,19519]
trailer [19736,19744]
===
match
---
parameters [17576,17582]
parameters [17576,17582]
===
match
---
operator: = [1078,1079]
operator: = [1078,1079]
===
match
---
name: item [13875,13879]
name: item [13875,13879]
===
match
---
name: help [5067,5071]
name: help [5067,5071]
===
match
---
param [22442,22462]
param [22667,22687]
===
match
---
name: settings [19503,19511]
name: settings [19728,19736]
===
match
---
name: init_env [1776,1784]
name: init_env [1776,1784]
===
match
---
name: item [8968,8972]
name: item [8968,8972]
===
match
---
name: root_dag [18547,18555]
name: root_dag [18547,18555]
===
match
---
operator: ** [22734,22736]
operator: ** [22959,22961]
===
match
---
operator: = [2679,2680]
operator: = [2679,2680]
===
match
---
trailer [13866,13880]
trailer [13866,13880]
===
match
---
operator: } [6335,6336]
operator: } [6335,6336]
===
match
---
argument [3815,3829]
argument [3815,3829]
===
match
---
simple_stmt [22242,22292]
simple_stmt [22467,22517]
===
match
---
simple_stmt [3596,3602]
simple_stmt [3596,3602]
===
match
---
name: item [9941,9945]
name: item [9941,9945]
===
match
---
name: kerberos [7379,7387]
name: kerberos [7379,7387]
===
match
---
name: get [19691,19694]
name: get [19916,19919]
===
match
---
atom_expr [2823,2834]
atom_expr [2823,2834]
===
match
---
string: "AWS_DEFAULT_REGION" [1309,1329]
string: "AWS_DEFAULT_REGION" [1309,1329]
===
match
---
name: integration_kerberos [7188,7208]
name: integration_kerberos [7188,7208]
===
match
---
comparison [2610,2635]
comparison [2610,2635]
===
match
---
name: skip_if_not_marked_with_system [9449,9479]
name: skip_if_not_marked_with_system [9449,9479]
===
match
---
operator: = [11547,11548]
operator: = [11547,11548]
===
match
---
dotted_name [15454,15468]
dotted_name [15454,15468]
===
match
---
trailer [10054,10059]
trailer [10054,10059]
===
match
---
simple_stmt [6220,6299]
simple_stmt [6220,6299]
===
match
---
trailer [15425,15436]
trailer [15425,15436]
===
match
---
not_test [20679,20690]
not_test [20904,20915]
===
match
---
name: help [4008,4012]
name: help [4008,4012]
===
match
---
string: "credential_file" [12597,12614]
string: "credential_file" [12597,12614]
===
match
---
atom_expr [12764,12795]
atom_expr [12764,12795]
===
match
---
name: item [13240,13244]
name: item [13240,13244]
===
match
---
param [22368,22381]
param [22593,22606]
===
match
---
suite [1753,1876]
suite [1753,1876]
===
match
---
if_stmt [19900,20201]
if_stmt [20125,20426]
===
match
---
import_from [20554,20614]
import_from [20779,20839]
===
match
---
argument [23186,23195]
argument [23411,23420]
===
match
---
simple_stmt [1259,1346]
simple_stmt [1259,1346]
===
match
---
name: pytest [1879,1885]
name: pytest [1879,1885]
===
match
---
name: os [1294,1296]
name: os [1294,1296]
===
match
---
operator: , [11701,11702]
operator: , [11701,11702]
===
match
---
argument [20292,20305]
argument [20517,20530]
===
match
---
trailer [18401,18409]
trailer [18401,18409]
===
match
---
name: print [6665,6670]
name: print [6665,6670]
===
match
---
simple_stmt [21617,22238]
simple_stmt [21842,22463]
===
match
---
argument [9915,9939]
argument [9915,9939]
===
match
---
string: "store_true" [4595,4607]
string: "store_true" [4595,4607]
===
match
---
suite [2307,2337]
suite [2307,2337]
===
match
---
simple_stmt [6185,6216]
simple_stmt [6185,6216]
===
match
---
string: 'sql' [3430,3435]
string: 'sql' [3430,3435]
===
match
---
name: _ [12929,12930]
name: _ [12929,12930]
===
match
---
import_name [795,812]
import_name [795,812]
===
match
---
string: 'trace' [2059,2066]
string: 'trace' [2059,2066]
===
match
---
name: selected_backend [13885,13901]
name: selected_backend [13885,13901]
===
match
---
string: "The test is skipped because it does not have the right backend marker " [9227,9299]
string: "The test is skipped because it does not have the right backend marker " [9227,9299]
===
match
---
argument [5583,5595]
argument [5583,5595]
===
match
---
simple_stmt [3735,3897]
simple_stmt [3735,3897]
===
match
---
name: on_execute_callback [23010,23029]
name: on_execute_callback [23235,23254]
===
match
---
arglist [8053,8155]
arglist [8053,8155]
===
match
---
string: "Only tests marked with pytest.mark.backend('{backend}') are run" [9308,9373]
string: "Only tests marked with pytest.mark.backend('{backend}') are run" [9308,9373]
===
match
---
name: session [19460,19467]
name: session [19685,19692]
===
match
---
name: iter_markers [10682,10694]
name: iter_markers [10682,10694]
===
match
---
name: airflow [15387,15394]
name: airflow [15387,15394]
===
match
---
trailer [6237,6245]
trailer [6237,6245]
===
match
---
argument [15136,15151]
argument [15136,15151]
===
match
---
trailer [18654,18662]
trailer [18654,18662]
===
match
---
param [2144,2151]
param [2144,2151]
===
match
---
operator: = [8558,8559]
operator: = [8558,8559]
===
match
---
operator: = [20186,20187]
operator: = [20411,20412]
===
match
---
operator: , [2087,2088]
operator: , [2087,2088]
===
match
---
operator: = [22551,22552]
operator: = [22776,22777]
===
match
---
arglist [8933,8977]
arglist [8933,8977]
===
match
---
string: """     Helper that setups Airflow testing environment. It does the same thing     as the old 'run-tests' script.     """ [5651,5772]
string: """     Helper that setups Airflow testing environment. It does the same thing     as the old 'run-tests' script.     """ [5651,5772]
===
match
---
simple_stmt [18588,18609]
simple_stmt [18588,18609]
===
match
---
name: os [12697,12699]
name: os [12697,12699]
===
match
---
operator: , [22489,22490]
operator: , [22714,22715]
===
match
---
suite [13480,13532]
suite [13480,13532]
===
match
---
name: addinivalue_line [7636,7652]
name: addinivalue_line [7636,7652]
===
match
---
operator: = [22671,22672]
operator: = [22896,22897]
===
match
---
name: __enter__ [17605,17614]
name: __enter__ [17605,17614]
===
match
---
trailer [13177,13184]
trailer [13177,13184]
===
match
---
name: join [4959,4963]
name: join [4959,4963]
===
match
---
name: self [18796,18800]
name: self [18796,18800]
===
match
---
operator: = [13171,13172]
operator: = [13171,13172]
===
match
---
atom_expr [1802,1817]
atom_expr [1802,1817]
===
match
---
simple_stmt [13761,13784]
simple_stmt [13761,13784]
===
match
---
string: "--include-quarantined" [4752,4775]
string: "--include-quarantined" [4752,4775]
===
match
---
trailer [20363,20372]
trailer [20588,20597]
===
match
---
name: query [21284,21289]
name: query [21509,21514]
===
match
---
name: datetime [14970,14978]
name: datetime [14970,14978]
===
match
---
atom_expr [7338,7367]
atom_expr [7338,7367]
===
match
---
name: name [9541,9545]
name: name [9541,9545]
===
match
---
trailer [5562,5564]
trailer [5562,5564]
===
match
---
atom_expr [17632,17652]
atom_expr [17632,17652]
===
match
---
trailer [20356,20363]
trailer [20581,20588]
===
match
---
name: name [11543,11547]
name: name [11543,11547]
===
match
---
atom_expr [21516,21533]
atom_expr [21741,21758]
===
match
---
trailer [21060,21064]
trailer [21285,21289]
===
match
---
trailer [1170,1175]
trailer [1170,1175]
===
match
---
trailer [6249,6265]
trailer [6249,6265]
===
match
---
name: kwargs [20299,20305]
name: kwargs [20524,20530]
===
match
---
name: fileloc [19265,19272]
name: fileloc [19490,19497]
===
match
---
operator: , [4578,4579]
operator: , [4578,4579]
===
match
---
operator: = [17546,17547]
operator: = [17546,17547]
===
match
---
name: include_long_running [14039,14059]
name: include_long_running [14039,14059]
===
match
---
name: dag [20324,20327]
name: dag [20549,20552]
===
match
---
operator: = [10699,10700]
operator: = [10699,10700]
===
match
---
operator: , [8966,8967]
operator: , [8966,8967]
===
match
---
name: airflow [20489,20496]
name: airflow [20714,20721]
===
match
---
trailer [15436,15450]
trailer [15436,15450]
===
match
---
trailer [18409,18415]
trailer [18409,18415]
===
match
---
name: expanduser [6200,6210]
name: expanduser [6200,6210]
===
match
---
name: start_date [19844,19854]
name: start_date [20069,20079]
===
match
---
strings [10073,10260]
strings [10073,10260]
===
match
---
name: dag_ids [20683,20690]
name: dag_ids [20908,20915]
===
match
---
trailer [20245,20256]
trailer [20470,20481]
===
match
---
trailer [15116,15153]
trailer [15116,15153]
===
match
---
trailer [3120,3171]
trailer [3120,3171]
===
match
---
parameters [12548,12554]
parameters [12548,12554]
===
match
---
operator: @ [15334,15335]
operator: @ [15334,15335]
===
match
---
simple_stmt [17670,17723]
simple_stmt [17670,17723]
===
match
---
trailer [6670,6865]
trailer [6670,6865]
===
match
---
name: self [18977,18981]
name: self [18949,18953]
===
match
---
trailer [17155,17160]
trailer [17155,17160]
===
match
---
operator: = [10312,10313]
operator: = [10312,10313]
===
match
---
name: subprocess [7401,7411]
name: subprocess [7401,7411]
===
match
---
atom_expr [11103,11144]
atom_expr [11103,11144]
===
match
---
simple_stmt [824,857]
simple_stmt [824,857]
===
match
---
name: value [12369,12374]
name: value [12369,12374]
===
match
---
trailer [18179,18190]
trailer [18179,18190]
===
match
---
atom_expr [13972,14027]
atom_expr [13972,14027]
===
match
---
trailer [21031,21039]
trailer [21256,21264]
===
match
---
parameters [14275,14288]
parameters [14275,14288]
===
match
---
param [19218,19236]
param [19443,19461]
===
match
---
atom_expr [18267,18277]
atom_expr [18267,18277]
===
match
---
name: self [18673,18677]
name: self [18673,18677]
===
match
---
parameters [11754,11768]
parameters [11754,11768]
===
match
---
name: iter_markers [9071,9083]
name: iter_markers [9071,9083]
===
match
---
argument [21219,21244]
argument [21444,21469]
===
match
---
name: timezone [19435,19443]
name: timezone [19660,19668]
===
match
---
name: enter_context [3052,3065]
name: enter_context [3052,3065]
===
match
---
name: option [6501,6507]
name: option [6501,6507]
===
match
---
expr_stmt [13354,13422]
expr_stmt [13354,13422]
===
match
---
simple_stmt [3185,3587]
simple_stmt [3185,3587]
===
match
---
simple_stmt [23345,23363]
simple_stmt [23570,23588]
===
match
---
atom_expr [13904,13938]
atom_expr [13904,13938]
===
match
---
string: 'start_date' [19874,19886]
string: 'start_date' [20099,20111]
===
match
---
operator: , [22866,22867]
operator: , [23091,23092]
===
match
---
name: marker [11755,11761]
name: marker [11755,11761]
===
match
---
trailer [2369,2376]
trailer [2369,2376]
===
match
---
simple_stmt [1691,1697]
simple_stmt [1691,1697]
===
match
---
param [19279,19292]
param [19504,19517]
===
match
---
not_test [2286,2306]
not_test [2286,2306]
===
match
---
suite [21612,23363]
suite [21837,23588]
===
match
---
trailer [20654,20662]
trailer [20879,20887]
===
match
---
suite [20084,20201]
suite [20309,20426]
===
match
---
trailer [10395,10408]
trailer [10395,10408]
===
match
---
atom_expr [6269,6298]
atom_expr [6269,6298]
===
match
---
name: _serialized_dag [17764,17779]
name: _serialized_dag [17764,17779]
===
match
---
trailer [19519,19521]
trailer [19744,19746]
===
match
---
name: pytest [21565,21571]
name: pytest [21790,21796]
===
match
---
param [8446,8468]
param [8446,8468]
===
match
---
decorated [1569,1876]
decorated [1569,1876]
===
match
---
import_from [15382,15409]
import_from [15382,15409]
===
match
---
name: os [6235,6237]
name: os [6235,6237]
===
match
---
operator: , [6286,6287]
operator: , [6286,6287]
===
match
---
fstring_expr [12857,12874]
fstring_expr [12857,12874]
===
match
---
operator: , [7856,7857]
operator: , [7856,7857]
===
match
---
comp_op [1769,1775]
comp_op [1769,1775]
===
match
---
name: name [12952,12956]
name: name [12952,12956]
===
match
---
name: types [22315,22320]
name: types [22540,22545]
===
match
---
name: args [8567,8571]
name: args [8567,8571]
===
match
---
name: config [7823,7829]
name: config [7823,7829]
===
match
---
trailer [21153,21160]
trailer [21378,21385]
===
match
---
name: item [10371,10375]
name: item [10371,10375]
===
match
---
trailer [8566,8571]
trailer [8566,8571]
===
match
---
string: "true" [13020,13026]
string: "true" [13020,13026]
===
match
---
name: commit [21426,21432]
name: commit [21651,21657]
===
match
---
dotted_name [5519,5532]
dotted_name [5519,5532]
===
match
---
operator: , [3155,3156]
operator: , [3155,3156]
===
match
---
name: skip_if_not_marked_with_backend [13972,14003]
name: skip_if_not_marked_with_backend [13972,14003]
===
match
---
name: pytest [10724,10730]
name: pytest [10724,10730]
===
match
---
name: create_dummy_dag [21584,21600]
name: create_dummy_dag [21809,21825]
===
match
---
decorated [14243,15332]
decorated [14243,15332]
===
match
---
trailer [21184,21193]
trailer [21409,21418]
===
match
---
arglist [1181,1204]
arglist [1181,1204]
===
match
---
string: "INTEGRATION_KERBEROS" [7226,7248]
string: "INTEGRATION_KERBEROS" [7226,7248]
===
match
---
name: text [2756,2760]
name: text [2756,2760]
===
match
---
atom_expr [7730,7818]
atom_expr [7730,7818]
===
match
---
trailer [6281,6298]
trailer [6281,6298]
===
match
---
name: addoption [4733,4742]
name: addoption [4733,4742]
===
match
---
name: self [17742,17746]
name: self [17742,17746]
===
match
---
simple_stmt [5980,6012]
simple_stmt [5980,6012]
===
match
---
trailer [12951,12969]
trailer [12951,12969]
===
match
---
atom_expr [21307,21335]
atom_expr [21532,21560]
===
match
---
string: "integration" [13465,13478]
string: "integration" [13465,13478]
===
match
---
funcdef [1587,1876]
funcdef [1587,1876]
===
match
---
name: display_num [3262,3273]
name: display_num [3262,3273]
===
match
---
name: marker [9513,9519]
name: marker [9513,9519]
===
match
---
name: dag_maker [23262,23271]
name: dag_maker [23487,23496]
===
match
---
operator: = [18794,18795]
operator: = [18794,18795]
===
match
---
trailer [18522,18530]
trailer [18522,18530]
===
match
---
trailer [13194,13211]
trailer [13194,13211]
===
match
---
operator: , [13637,13638]
operator: , [13637,13638]
===
match
---
trailer [20323,20327]
trailer [20548,20552]
===
match
---
operator: , [19709,19710]
operator: , [19934,19935]
===
match
---
arglist [19952,19982]
arglist [20177,20207]
===
match
---
suite [12920,13106]
suite [12920,13106]
===
match
---
simple_stmt [20817,20838]
simple_stmt [21042,21063]
===
match
---
atom_expr [21047,21073]
atom_expr [21272,21298]
===
match
---
name: item [10308,10312]
name: item [10308,10312]
===
match
---
name: pool [22442,22446]
name: pool [22667,22671]
===
match
---
suite [17314,21435]
suite [17314,21660]
===
match
---
name: synchronize_session [20961,20980]
name: synchronize_session [21186,21205]
===
match
---
name: name [13820,13824]
name: name [13820,13824]
===
match
---
name: environ [1209,1216]
name: environ [1209,1216]
===
match
---
name: skip_quarantined_test [14138,14159]
name: skip_quarantined_test [14138,14159]
===
match
---
argument [4588,4607]
argument [4588,4607]
===
match
---
operator: = [19247,19248]
operator: = [19472,19473]
===
match
---
trailer [7213,7221]
trailer [7213,7221]
===
match
---
simple_stmt [1701,1726]
simple_stmt [1701,1726]
===
match
---
suite [14917,15188]
suite [14917,15188]
===
match
---
trailer [3065,3103]
trailer [3065,3103]
===
match
---
name: fileloc [20338,20345]
name: fileloc [20563,20570]
===
match
---
atom_expr [19117,19144]
atom_expr [19342,19369]
===
match
---
atom_expr [6989,7183]
atom_expr [6989,7183]
===
match
---
atom_expr [7496,7568]
atom_expr [7496,7568]
===
match
---
trailer [13517,13531]
trailer [13517,13531]
===
match
---
name: tests [1457,1462]
name: tests [1457,1462]
===
match
---
operator: = [11026,11027]
operator: = [11026,11027]
===
match
---
name: integration_name [8586,8602]
name: integration_name [8586,8602]
===
match
---
expr_stmt [1062,1123]
expr_stmt [1062,1123]
===
match
---
dotted_name [15335,15349]
dotted_name [15335,15349]
===
match
---
name: addoption [3907,3916]
name: addoption [3907,3916]
===
match
---
trailer [3906,3916]
trailer [3906,3916]
===
match
---
operator: , [23029,23030]
operator: , [23254,23255]
===
match
---
comparison [5344,5388]
comparison [5344,5388]
===
match
---
operator: = [4621,4622]
operator: = [4621,4622]
===
match
---
dotted_name [17950,17979]
dotted_name [17950,17979]
===
match
---
string: "backend" [9089,9098]
string: "backend" [9089,9098]
===
match
---
name: synchronize_session [21082,21101]
name: synchronize_session [21307,21326]
===
match
---
trailer [14003,14027]
trailer [14003,14027]
===
match
---
name: skip_if_credential_file_missing [12517,12548]
name: skip_if_credential_file_missing [12517,12548]
===
match
---
operator: , [9496,9497]
operator: , [9496,9497]
===
match
---
string: "terminalreporter" [2401,2419]
string: "terminalreporter" [2401,2419]
===
match
---
for_stmt [9992,10342]
for_stmt [9992,10342]
===
match
---
number: 1 [7590,7591]
number: 1 [7590,7591]
===
match
---
name: group [3901,3906]
name: group [3901,3906]
===
match
---
name: filter [21300,21306]
name: filter [21525,21531]
===
match
---
name: item [10006,10010]
name: item [10006,10010]
===
match
---
trailer [6199,6210]
trailer [6199,6210]
===
match
---
argument [13820,13834]
argument [13820,13834]
===
match
---
string: "The test works only with Airflow 2.0 / main branch" [13052,13104]
string: "The test works only with Airflow 2.0 / main branch" [13052,13104]
===
match
---
name: item [14160,14164]
name: item [14160,14164]
===
match
---
name: join [6433,6437]
name: join [6433,6437]
===
match
---
trailer [11243,11726]
trailer [11243,11726]
===
match
---
string: 'default_args' [19695,19709]
string: 'default_args' [19920,19934]
===
match
---
operator: , [11573,11574]
operator: , [11573,11574]
===
match
---
operator: = [3540,3541]
operator: = [3540,3541]
===
match
---
suite [12970,13106]
suite [12970,13106]
===
match
---
name: open [6931,6935]
name: open [6931,6935]
===
match
---
name: credential_path [12666,12681]
name: credential_path [12666,12681]
===
match
---
name: get [1389,1392]
name: get [1389,1392]
===
match
---
name: join [6277,6281]
name: join [6277,6281]
===
match
---
atom_expr [21121,21258]
atom_expr [21346,21483]
===
match
---
return_stmt [15415,15450]
return_stmt [15415,15450]
===
match
---
simple_stmt [14212,14241]
simple_stmt [14212,14241]
===
match
---
name: kerberos [7327,7335]
name: kerberos [7327,7335]
===
match
---
atom_expr [20294,20305]
atom_expr [20519,20530]
===
match
---
name: action [4372,4378]
name: action [4372,4378]
===
match
---
simple_stmt [2007,2013]
simple_stmt [2007,2013]
===
match
---
atom_expr [6931,6952]
atom_expr [6931,6952]
===
match
---
atom_expr [6599,6616]
atom_expr [6599,6616]
===
match
---
name: pytest_print [3089,3101]
name: pytest_print [3089,3101]
===
match
---
suite [7288,7593]
suite [7288,7593]
===
match
---
name: os [12764,12766]
name: os [12764,12766]
===
match
---
name: serialized_dag [18455,18469]
name: serialized_dag [18455,18469]
===
match
---
name: operators [22255,22264]
name: operators [22480,22489]
===
match
---
atom_expr [19952,19966]
atom_expr [20177,20191]
===
match
---
suite [6953,6971]
suite [6953,6971]
===
match
---
simple_stmt [6989,7184]
simple_stmt [6989,7184]
===
match
---
trailer [2400,2420]
trailer [2400,2420]
===
match
---
string: "markers" [7938,7947]
string: "markers" [7938,7947]
===
match
---
name: default_args [19857,19869]
name: default_args [20082,20094]
===
match
---
import_as_names [20511,20541]
import_as_names [20736,20766]
===
match
---
trailer [12578,12591]
trailer [12578,12591]
===
match
---
name: fixture [15342,15349]
name: fixture [15342,15349]
===
match
---
simple_stmt [18643,18683]
simple_stmt [18643,18683]
===
match
---
argument [22734,22742]
argument [22959,22967]
===
match
---
name: fixture [1886,1893]
name: fixture [1886,1893]
===
match
---
name: cleanup [21524,21531]
name: cleanup [21749,21756]
===
match
---
operator: ** [19135,19137]
operator: ** [19360,19362]
===
match
---
name: item [10887,10891]
name: item [10887,10891]
===
match
---
simple_stmt [2330,2337]
simple_stmt [2330,2337]
===
match
---
operator: , [3139,3140]
operator: , [3139,3140]
===
match
---
name: self [19568,19572]
name: self [19793,19797]
===
match
---
simple_stmt [18511,18572]
simple_stmt [18511,18572]
===
match
---
trailer [8511,8531]
trailer [8511,8531]
===
match
---
name: config [7616,7622]
name: config [7616,7622]
===
match
---
trailer [6031,6042]
trailer [6031,6042]
===
match
---
operator: , [23086,23087]
operator: , [23311,23312]
===
match
---
simple_stmt [17735,17751]
simple_stmt [17735,17751]
===
match
---
name: DagFactory [17303,17313]
name: DagFactory [17303,17313]
===
match
---
simple_stmt [20385,20419]
simple_stmt [20610,20644]
===
match
---
argument [3532,3553]
argument [3532,3553]
===
match
---
arglist [19695,19715]
arglist [19920,19940]
===
match
---
trailer [17600,17604]
trailer [17600,17604]
===
match
---
argument [10608,10617]
argument [10608,10617]
===
match
---
comparison [14999,15028]
comparison [14999,15028]
===
match
---
name: kwargs [19295,19301]
name: kwargs [19520,19526]
===
match
---
trailer [1208,1216]
trailer [1208,1216]
===
match
---
operator: , [8337,8338]
operator: , [8337,8338]
===
match
---
simple_stmt [7730,7819]
simple_stmt [7730,7819]
===
match
---
simple_stmt [7327,7368]
simple_stmt [7327,7368]
===
match
---
trailer [18262,18266]
trailer [18262,18266]
===
match
---
atom_expr [7629,7725]
atom_expr [7629,7725]
===
match
---
name: __call__ [19190,19198]
name: __call__ [19415,19423]
===
match
---
name: dag_ids [20628,20635]
name: dag_ids [20853,20860]
===
match
---
name: pytest [15454,15460]
name: pytest [15454,15460]
===
match
---
simple_stmt [20484,20542]
simple_stmt [20709,20767]
===
match
---
name: self [17632,17636]
name: self [17632,17636]
===
match
---
atom_expr [6874,6891]
atom_expr [6874,6891]
===
match
---
name: item [13376,13380]
name: item [13376,13380]
===
match
---
name: DAG [20280,20283]
name: DAG [20505,20508]
===
match
---
string: 'num' [3274,3279]
string: 'num' [3274,3279]
===
match
---
trailer [18337,18354]
trailer [18337,18354]
===
match
---
name: query [21026,21031]
name: query [21251,21256]
===
match
---
operator: , [10949,10950]
operator: , [10949,10950]
===
match
---
fstring_end: " [12882,12883]
fstring_end: " [12882,12883]
===
match
---
trailer [14978,14985]
trailer [14978,14985]
===
match
---
name: skip_long_running_test [14069,14091]
name: skip_long_running_test [14069,14091]
===
match
---
operator: , [4387,4388]
operator: , [4387,4388]
===
match
---
parameters [13132,13138]
parameters [13132,13138]
===
match
---
argument [11591,11623]
argument [11591,11623]
===
match
---
argument [22833,22866]
argument [23058,23091]
===
match
---
import_from [22296,22338]
import_from [22521,22563]
===
match
---
argument [3418,3446]
argument [3418,3446]
===
match
---
trailer [12649,12654]
trailer [12649,12654]
===
match
---
trailer [6276,6281]
trailer [6276,6281]
===
match
---
string: 'CREDENTIALS_DIR' [1393,1410]
string: 'CREDENTIALS_DIR' [1393,1410]
===
match
---
suite [6656,6971]
suite [6656,6971]
===
match
---
trailer [20283,20306]
trailer [20508,20531]
===
match
---
expr_stmt [17472,17553]
expr_stmt [17472,17553]
===
match
---
name: dag_maker [21601,21610]
name: dag_maker [21826,21835]
===
match
---
name: skip [12816,12820]
name: skip [12816,12820]
===
match
---
funcdef [15469,21562]
funcdef [15469,21787]
===
match
---
simple_stmt [12625,12658]
simple_stmt [12625,12658]
===
match
---
simple_stmt [813,824]
simple_stmt [813,824]
===
match
---
atom_expr [5853,5883]
atom_expr [5853,5883]
===
match
---
trailer [17705,17721]
trailer [17705,17721]
===
match
---
argument [21082,21107]
argument [21307,21332]
===
match
---
simple_stmt [2316,2322]
simple_stmt [2316,2322]
===
match
---
expr_stmt [18217,18278]
expr_stmt [18217,18278]
===
match
---
simple_stmt [20851,21001]
simple_stmt [21076,21226]
===
match
---
string: 'num' [2873,2878]
string: 'num' [2873,2878]
===
match
---
trailer [18058,18082]
trailer [18058,18082]
===
match
---
expr_stmt [20005,20062]
expr_stmt [20230,20287]
===
match
---
trailer [7352,7367]
trailer [7352,7367]
===
match
---
name: defaults [18817,18825]
name: kwargs [18817,18823]
===
match
---
arglist [13611,13643]
arglist [13611,13643]
===
match
---
funcdef [15367,15451]
funcdef [15367,15451]
===
match
---
name: print [6989,6994]
name: print [6989,6994]
===
match
---
name: self [18416,18420]
name: self [18416,18420]
===
match
---
trailer [7652,7725]
trailer [7652,7725]
===
match
---
string: " being one of {systems}. {item}" [9874,9907]
string: " being one of {systems}. {item}" [9874,9907]
===
match
---
atom_expr [15193,15238]
atom_expr [15193,15238]
===
match
---
number: 0 [9592,9593]
number: 0 [9592,9593]
===
match
---
trailer [18195,18203]
trailer [18195,18203]
===
match
---
name: models [17958,17964]
name: models [17958,17964]
===
match
---
operator: @ [2100,2101]
operator: @ [2100,2101]
===
match
---
with_stmt [6926,6971]
with_stmt [6926,6971]
===
match
---
suite [19312,20444]
suite [19537,20669]
===
match
---
not_test [11932,11962]
not_test [11932,11962]
===
match
---
try_stmt [21468,21562]
try_stmt [21693,21787]
===
match
---
argument [10887,10896]
argument [10887,10896]
===
match
---
name: create_app [15426,15436]
name: create_app [15426,15436]
===
match
---
trailer [5354,5358]
trailer [5354,5358]
===
match
---
trailer [10987,10992]
trailer [10987,10992]
===
match
---
simple_stmt [18333,18381]
simple_stmt [18333,18381]
===
match
---
simple_stmt [15162,15188]
simple_stmt [15162,15188]
===
match
---
decorated [5567,7593]
decorated [5567,7593]
===
match
---
operator: } [6364,6365]
operator: } [6364,6365]
===
match
---
operator: , [5057,5058]
operator: , [5057,5058]
===
match
---
trailer [9586,9591]
trailer [9586,9591]
===
match
---
return_stmt [23325,23339]
return_stmt [23550,23564]
===
match
---
dotted_name [1879,1893]
dotted_name [1879,1893]
===
match
---
trailer [1087,1095]
trailer [1087,1095]
===
match
---
simple_stmt [23262,23317]
simple_stmt [23487,23542]
===
match
---
name: integration_name [11641,11657]
name: integration_name [11641,11657]
===
match
---
name: want_serialized [18300,18315]
name: want_serialized [18300,18315]
===
match
---
trailer [17492,17553]
trailer [17492,17553]
===
match
---
trailer [1308,1330]
trailer [1308,1330]
===
match
---
trailer [7411,7422]
trailer [7411,7422]
===
match
---
name: op [22764,22766]
name: op [22989,22991]
===
match
---
operator: , [8208,8209]
operator: , [8208,8209]
===
match
---
operator: , [5277,5278]
operator: , [5277,5278]
===
match
---
fstring_start: f" [5174,5176]
fstring_start: f" [5174,5176]
===
match
---
operator: , [20527,20528]
operator: , [20752,20753]
===
match
---
import_from [5980,6011]
import_from [5980,6011]
===
match
---
trailer [2390,2400]
trailer [2390,2400]
===
match
---
decorator [5567,5614]
decorator [5567,5614]
===
match
---
string: "Skipping db initialization. Tests do not require database" [5899,5958]
string: "Skipping db initialization. Tests do not require database" [5899,5958]
===
match
---
name: pluginmanager [2377,2390]
name: pluginmanager [2377,2390]
===
match
---
yield_expr [15243,15259]
yield_expr [15243,15259]
===
match
---
strings [10749,10879]
strings [10749,10879]
===
match
---
string: "--integration" [13195,13210]
string: "--integration" [13195,13210]
===
match
---
string: "Includes quarantined tests (marked with quarantined marker). They are skipped by default." [4819,4910]
string: "Includes quarantined tests (marked with quarantined marker). They are skipped by default." [4819,4910]
===
match
---
name: home [6282,6286]
name: home [6282,6286]
===
match
---
name: item [12481,12485]
name: item [12481,12485]
===
match
---
param [19237,19264]
param [19462,19489]
===
match
---
operator: , [4210,4211]
operator: , [4210,4211]
===
match
---
trailer [9083,9099]
trailer [9083,9099]
===
match
---
simple_stmt [20213,20257]
simple_stmt [20438,20482]
===
match
---
number: 16 [22430,22432]
number: 16 [22655,22657]
===
match
---
atom_expr [10073,10331]
atom_expr [10073,10331]
===
match
---
operator: = [18355,18356]
operator: = [18355,18356]
===
match
---
suite [10039,10342]
suite [10039,10342]
===
match
---
funcdef [14259,15332]
funcdef [14259,15332]
===
match
---
name: split [2722,2727]
name: split [2722,2727]
===
match
---
string: "[cassandra,kerberos,mongo,openldap,rabbitmq,redis,statsd,trino]. " [4071,4138]
string: "[cassandra,kerberos,mongo,openldap,rabbitmq,redis,statsd,trino]. " [4071,4138]
===
match
---
operator: , [4607,4608]
operator: , [4607,4608]
===
match
---
name: airflow [20559,20566]
name: airflow [20784,20791]
===
match
---
name: trace_queries [1550,1563]
name: trace_queries [1550,1563]
===
match
---
name: session [19573,19580]
name: session [19798,19805]
===
match
---
operator: = [22486,22487]
operator: = [22711,22712]
===
match
---
expr_stmt [13144,13211]
expr_stmt [13144,13211]
===
match
---
name: name [10024,10028]
name: name [10024,10028]
===
match
---
operator: ** [20292,20294]
operator: ** [20517,20519]
===
match
---
name: serialized_marker [17210,17227]
name: serialized_marker [17210,17227]
===
match
---
if_stmt [15265,15332]
if_stmt [15265,15332]
===
match
---
name: integration_kerberos [7257,7277]
name: integration_kerberos [7257,7277]
===
match
---
trailer [14091,14097]
trailer [14091,14097]
===
match
---
name: dag_id [19218,19224]
name: dag_id [19443,19449]
===
match
---
name: SCHEDULED [23306,23315]
name: SCHEDULED [23531,23540]
===
match
---
operator: , [19649,19650]
operator: , [19874,19875]
===
match
---
name: exit [7585,7589]
name: exit [7585,7589]
===
match
---
operator: , [22656,22657]
operator: , [22881,22882]
===
match
---
suite [10430,10629]
suite [10430,10629]
===
match
---
operator: , [2073,2074]
operator: , [2073,2074]
===
match
---
name: self [20439,20443]
name: self [20664,20668]
===
match
---
name: airflow_home [6220,6232]
name: airflow_home [6220,6232]
===
match
---
name: backend [9400,9407]
name: backend [9400,9407]
===
match
---
name: environment_variable_name [11548,11573]
name: environment_variable_name [11548,11573]
===
match
---
operator: = [4594,4595]
operator: = [4594,4595]
===
match
---
suite [17342,17554]
suite [17342,17554]
===
match
---
name: airflow [19371,19378]
name: airflow [19596,19603]
===
match
---
expr_stmt [9109,9136]
expr_stmt [9109,9136]
===
match
---
name: self [17472,17476]
name: self [17472,17476]
===
match
---
name: environment_variable_value [11936,11962]
name: environment_variable_value [11936,11962]
===
match
---
operator: = [11101,11102]
operator: = [11101,11102]
===
match
---
funcdef [5614,7593]
funcdef [5614,7593]
===
match
---
if_stmt [1762,1876]
if_stmt [1762,1876]
===
match
---
name: cleanup [20457,20464]
name: cleanup [20682,20689]
===
match
---
trailer [10735,10907]
trailer [10735,10907]
===
match
---
operator: , [19235,19236]
operator: , [19460,19461]
===
match
---
operator: = [19682,19683]
operator: = [19907,19908]
===
match
---
name: pytest_print [3541,3553]
name: pytest_print [3541,3553]
===
match
---
operator: , [22380,22381]
operator: , [22605,22606]
===
match
---
name: default_args [19732,19744]
name: default_args [19957,19969]
===
match
---
argument [8933,8966]
argument [8933,8966]
===
match
---
operator: , [19277,19278]
operator: , [19502,19503]
===
match
---
trailer [10730,10735]
trailer [10730,10735]
===
match
---
param [20465,20469]
param [20690,20694]
===
match
---
param [10657,10661]
param [10657,10661]
===
match
---
name: iter_markers [8499,8511]
name: iter_markers [8499,8511]
===
match
---
operator: , [20045,20046]
operator: , [20270,20271]
===
match
---
trailer [9907,9914]
trailer [9907,9914]
===
match
---
name: integration_name [10962,10978]
name: integration_name [10962,10978]
===
match
---
trailer [1082,1087]
trailer [1082,1087]
===
match
---
string: 'test' [18857,18863]
string: "state" [18844,18851]
===
match
---
operator: = [23162,23163]
operator: = [23387,23388]
===
match
---
atom_expr [17486,17553]
atom_expr [17486,17553]
===
match
---
expr_stmt [20105,20149]
expr_stmt [20330,20374]
===
match
---
decorated [2100,3602]
decorated [2100,3602]
===
match
---
name: session [19583,19590]
name: session [19808,19815]
===
match
---
trailer [15324,15329]
trailer [15324,15329]
===
match
---
name: start_date [20175,20185]
name: start_date [20400,20410]
===
match
---
argument [23104,23139]
argument [23329,23364]
===
match
---
suite [6051,6100]
suite [6051,6100]
===
match
---
comparison [19460,19475]
comparison [19685,19700]
===
match
---
trailer [13387,13397]
trailer [13387,13397]
===
match
---
operator: , [19966,19967]
operator: , [20191,20192]
===
match
---
simple_stmt [17596,17617]
simple_stmt [17596,17617]
===
match
---
if_stmt [14996,15067]
if_stmt [14996,15067]
===
match
---
trailer [6644,6655]
trailer [6644,6655]
===
match
---
atom_expr [19857,19887]
atom_expr [20082,20112]
===
match
---
fstring_start: f" [6310,6312]
fstring_start: f" [6310,6312]
===
match
---
name: app [15422,15425]
name: app [15422,15425]
===
match
---
name: selected_integrations_list [13539,13565]
name: selected_integrations_list [13539,13565]
===
match
---
name: selected_systems [9651,9667]
name: selected_systems [9651,9667]
===
match
---
name: want_serialized [17238,17253]
name: want_serialized [17238,17253]
===
match
---
suite [15298,15332]
suite [15298,15332]
===
match
---
name: db [1982,1984]
name: db [1982,1984]
===
match
---
argument [10409,10428]
argument [10409,10428]
===
match
---
funcdef [17760,17832]
funcdef [17760,17832]
===
match
---
operator: = [14968,14969]
operator: = [14968,14969]
===
match
---
suite [9668,9688]
suite [9668,9688]
===
match
---
argument [22990,23029]
argument [23215,23254]
===
match
---
trailer [21081,21108]
trailer [21306,21333]
===
match
---
trailer [19120,19134]
trailer [19345,19359]
===
match
---
trailer [8932,8978]
trailer [8932,8978]
===
match
---
trailer [21531,21533]
trailer [21756,21758]
===
match
---
trailer [6129,6138]
trailer [6129,6138]
===
match
---
name: key [1765,1768]
name: key [1765,1768]
===
match
---
name: airflow [19330,19337]
name: airflow [19555,19562]
===
match
---
operator: = [15143,15144]
operator: = [15143,15144]
===
match
---
trailer [19911,19922]
trailer [20136,20147]
===
match
---
name: session [19493,19500]
name: session [19718,19725]
===
match
---
name: on_success_callback [22933,22952]
name: on_success_callback [23158,23177]
===
match
---
name: valid_backend_names [11774,11793]
name: valid_backend_names [11774,11793]
===
match
---
funcdef [12513,12885]
funcdef [12513,12885]
===
match
---
trailer [12699,12707]
trailer [12699,12707]
===
match
---
string: "The test is skipped because it has system marker. " [10073,10125]
string: "The test is skipped because it has system marker. " [10073,10125]
===
match
---
trailer [6500,6507]
trailer [6500,6507]
===
match
---
atom_expr [3735,3896]
atom_expr [3735,3896]
===
match
---
name: item [13904,13908]
name: item [13904,13908]
===
match
---
string: "credential_file(name): mark tests that require credential file in CREDENTIALS_DIR" [8210,8293]
string: "credential_file(name): mark tests that require credential file in CREDENTIALS_DIR" [8210,8293]
===
match
---
if_stmt [14102,14166]
if_stmt [14102,14166]
===
match
---
operator: = [9545,9546]
operator: = [9545,9546]
===
match
---
name: monkeypatch [14276,14287]
name: monkeypatch [14276,14287]
===
match
---
simple_stmt [1956,1985]
simple_stmt [1956,1985]
===
match
---
simple_stmt [2659,2666]
simple_stmt [2659,2666]
===
match
---
testlist_comp [2044,2096]
testlist_comp [2044,2096]
===
match
---
name: DagModel [17924,17932]
name: DagModel [17924,17932]
===
match
---
name: fake_sleep [14897,14907]
name: fake_sleep [14897,14907]
===
match
---
suite [19476,19522]
suite [19701,19747]
===
match
---
trailer [12996,13016]
trailer [12996,13016]
===
match
---
name: addoption [4333,4342]
name: addoption [4333,4342]
===
match
---
parameters [9022,9046]
parameters [9022,9046]
===
match
---
return_stmt [23345,23362]
return_stmt [23570,23587]
===
match
---
trailer [13610,13644]
trailer [13610,13644]
===
match
---
name: key [1813,1816]
name: key [1813,1816]
===
match
---
import_from [18739,18776]
import_from [18739,18776]
===
match
---
simple_stmt [8166,8300]
simple_stmt [8166,8300]
===
match
---
simple_stmt [11000,11070]
simple_stmt [11000,11070]
===
match
---
name: display_parameters [3468,3486]
name: display_parameters [3468,3486]
===
match
---
param [10943,10950]
param [10943,10950]
===
match
---
not_test [19749,19768]
not_test [19974,19993]
===
match
---
name: query [18247,18252]
name: query [18247,18252]
===
match
---
trailer [19843,19854]
trailer [20068,20079]
===
match
---
trailer [1127,1135]
trailer [1127,1135]
===
match
---
import_from [17945,18005]
import_from [17945,18005]
===
match
---
operator: = [5590,5591]
operator: = [5590,5591]
===
match
---
operator: = [13902,13903]
operator: = [13902,13903]
===
match
---
name: path [12687,12691]
name: path [12687,12691]
===
match
---
atom_expr [20023,20062]
atom_expr [20248,20287]
===
match
---
name: skip [12036,12040]
name: skip [12036,12040]
===
match
---
operator: = [4202,4203]
operator: = [4202,4203]
===
match
---
param [17780,17784]
param [17780,17784]
===
match
---
suite [20471,21435]
suite [20696,21660]
===
match
---
expr_stmt [13279,13349]
expr_stmt [13279,13349]
===
match
---
name: system [10285,10291]
name: system [10285,10291]
===
match
---
operator: , [4517,4518]
operator: , [4517,4518]
===
match
---
name: format [9393,9399]
name: format [9393,9399]
===
match
---
name: print [6304,6309]
name: print [6304,6309]
===
match
---
expr_stmt [11812,11849]
expr_stmt [11812,11849]
===
match
---
name: DummyOperator [22278,22291]
name: DummyOperator [22503,22516]
===
match
---
parameters [22358,22701]
parameters [22583,22926]
===
match
---
atom_expr [21271,21400]
atom_expr [21496,21625]
===
match
---
name: dag [19117,19120]
name: dag [19342,19345]
===
match
---
name: os [12684,12686]
name: os [12684,12686]
===
match
---
trailer [8925,8932]
trailer [8925,8932]
===
match
---
operator: = [23190,23191]
operator: = [23415,23416]
===
match
---
name: init_env [1862,1870]
name: init_env [1862,1870]
===
match
---
name: airflow [17950,17957]
name: airflow [17950,17957]
===
match
---
name: skip_if_wrong_backend [11733,11754]
name: skip_if_wrong_backend [11733,11754]
===
match
---
name: kwargs [22688,22694]
name: kwargs [22913,22919]
===
match
---
param [21601,21610]
param [21826,21835]
===
match
---
string: """     Resets env variables.     """ [1616,1653]
string: """     Resets env variables.     """ [1616,1653]
===
match
---
operator: ** [22686,22688]
operator: ** [22911,22913]
===
match
---
funcdef [2739,2813]
funcdef [2739,2813]
===
match
---
argument [4424,4517]
argument [4424,4517]
===
match
---
operator: = [15355,15356]
operator: = [15355,15356]
===
match
---
trailer [19690,19694]
trailer [19915,19919]
===
match
---
param [22390,22404]
param [22615,22629]
===
match
---
parameters [3624,3632]
parameters [3624,3632]
===
match
---
trailer [1216,1249]
trailer [1216,1249]
===
match
---
trailer [19636,19656]
trailer [19861,19881]
===
match
---
name: serialized_marker [17128,17145]
name: serialized_marker [17128,17145]
===
match
---
name: os [11883,11885]
name: os [11883,11885]
===
match
---
trailer [13908,13915]
trailer [13908,13915]
===
match
---
operator: , [8467,8468]
operator: , [8467,8468]
===
match
---
name: config [6494,6500]
name: config [6494,6500]
===
match
---
string: 'parameters' [2075,2087]
string: 'parameters' [2075,2087]
===
match
---
name: session [20822,20829]
name: session [21047,21054]
===
match
---
string: "backend" [13825,13834]
string: "backend" [13825,13834]
===
match
---
decorator [1878,1896]
decorator [1878,1896]
===
match
---
name: Session [19512,19519]
name: Session [19737,19744]
===
match
---
operator: , [12351,12352]
operator: , [12351,12352]
===
match
---
trailer [7937,8015]
trailer [7937,8015]
===
match
---
parameters [17853,17883]
parameters [17853,17883]
===
match
---
name: item [10951,10955]
name: item [10951,10955]
===
match
---
or_test [8586,8661]
or_test [8586,8661]
===
match
---
name: default_args [19805,19817]
name: default_args [20030,20042]
===
match
---
comparison [9642,9667]
comparison [9642,9667]
===
match
---
atom_expr [10391,10429]
atom_expr [10391,10429]
===
match
---
param [11755,11762]
param [11755,11762]
===
match
---
name: item [9041,9045]
name: item [9041,9045]
===
match
---
name: factory [21440,21447]
name: factory [21665,21672]
===
match
---
simple_stmt [1206,1259]
simple_stmt [1206,1259]
===
match
---
expr_stmt [1844,1875]
expr_stmt [1844,1875]
===
match
---
decorated [15334,15451]
decorated [15334,15451]
===
match
---
name: action [5043,5049]
name: action [5043,5049]
===
match
---
arglist [6282,6297]
arglist [6282,6297]
===
match
---
atom_expr [9227,9436]
atom_expr [9227,9436]
===
match
---
operator: , [19263,19264]
operator: , [19488,19489]
===
match
---
operator: , [4804,4805]
operator: , [4804,4805]
===
match
---
name: serialized [19237,19247]
name: serialized [19462,19472]
===
match
---
trailer [20128,20137]
trailer [20353,20362]
===
match
---
operator: , [17289,17290]
operator: , [17289,17290]
===
match
---
operator: = [10291,10292]
operator: = [10291,10292]
===
match
---
name: text [2807,2811]
name: text [2807,2811]
===
match
---
trailer [7422,7469]
trailer [7422,7469]
===
match
---
name: path [12767,12771]
name: path [12767,12771]
===
match
---
decorator [15453,15469]
decorator [15453,15469]
===
match
---
name: serialized_marker [17258,17275]
name: serialized_marker [17258,17275]
===
match
---
expr_stmt [11774,11807]
expr_stmt [11774,11807]
===
match
---
name: environ [1381,1388]
name: environ [1381,1388]
===
match
---
operator: , [9039,9040]
operator: , [9039,9040]
===
match
---
expr_stmt [14863,14887]
expr_stmt [14863,14887]
===
match
---
name: config [2249,2255]
name: config [2249,2255]
===
match
---
suite [5389,5496]
suite [5389,5496]
===
match
---
name: getplugin [2391,2400]
name: getplugin [2391,2400]
===
match
---
name: kwargs [20218,20224]
name: kwargs [20443,20449]
===
match
---
operator: , [13873,13874]
operator: , [13873,13874]
===
match
---
argument [5597,5612]
argument [5597,5612]
===
match
---
string: "--trace-sql" [5020,5033]
string: "--trace-sql" [5020,5033]
===
match
---
operator: , [6945,6946]
operator: , [6945,6946]
===
match
---
atom_expr [19839,19854]
atom_expr [20064,20079]
===
match
---
name: start_date [19912,19922]
name: start_date [20137,20147]
===
match
---
name: DagRunType [23295,23305]
name: DagRunType [23520,23530]
===
match
---
atom_expr [8166,8299]
atom_expr [8166,8299]
===
match
---
simple_stmt [15243,15260]
simple_stmt [15243,15260]
===
match
---
simple_stmt [16960,16984]
simple_stmt [16960,16984]
===
match
---
name: session [18239,18246]
name: session [18239,18246]
===
match
---
operator: = [18826,18827]
operator: = [18824,18825]
===
match
---
name: iter_markers [9528,9540]
name: iter_markers [9528,9540]
===
match
---
name: self [18933,18937]
name: self [18902,18906]
===
match
---
trailer [1304,1308]
trailer [1304,1308]
===
match
---
fstring_string: :  [12874,12876]
fstring_string: :  [12874,12876]
===
match
---
operator: , [3510,3511]
operator: , [3510,3511]
===
match
---
simple_stmt [19325,19354]
simple_stmt [19550,19579]
===
match
---
trailer [5346,5354]
trailer [5346,5354]
===
match
---
operator: , [23238,23239]
operator: , [23463,23464]
===
match
---
arglist [4352,4518]
arglist [4352,4518]
===
match
---
trailer [1671,1679]
trailer [1671,1679]
===
match
---
suite [14129,14166]
suite [14129,14166]
===
match
---
name: config [7730,7736]
name: config [7730,7736]
===
match
---
trailer [7846,7909]
trailer [7846,7909]
===
match
---
trailer [21125,21133]
trailer [21350,21358]
===
match
---
operator: } [12881,12882]
operator: } [12881,12882]
===
match
---
trailer [4544,4722]
trailer [4544,4722]
===
match
---
string: "true" [5382,5388]
string: "true" [5382,5388]
===
match
---
operator: = [12956,12957]
operator: = [12956,12957]
===
match
---
argument [4008,4138]
argument [4008,4138]
===
match
---
atom_expr [19944,19983]
atom_expr [20169,20208]
===
match
---
name: dag_id [22368,22374]
name: dag_id [22593,22599]
===
match
---
param [8469,8473]
param [8469,8473]
===
match
---
name: fixture [14251,14258]
name: fixture [14251,14258]
===
match
---
operator: , [17864,17865]
operator: , [17864,17865]
===
match
---
operator: = [4953,4954]
operator: = [4953,4954]
===
match
---
atom_expr [12574,12615]
atom_expr [12574,12615]
===
match
---
string: " being one of {integration}. {item}" [8888,8925]
string: " being one of {integration}. {item}" [8888,8925]
===
match
---
string: "The test is skipped because it has long_running marker. " [10464,10522]
string: "The test is skipped because it has long_running marker. " [10464,10522]
===
match
---
if_stmt [13536,13645]
if_stmt [13536,13645]
===
match
---
suite [22751,23254]
suite [22976,23479]
===
match
---
trailer [6507,6515]
trailer [6507,6515]
===
match
---
operator: , [3889,3890]
operator: , [3889,3890]
===
match
---
suite [19984,20063]
suite [20209,20288]
===
match
---
name: self [18710,18714]
name: self [18710,18714]
===
match
---
operator: = [21448,21449]
operator: = [21673,21674]
===
match
---
trailer [21553,21561]
trailer [21778,21786]
===
match
---
name: pytest [2101,2107]
name: pytest [2101,2107]
===
match
---
operator: = [1860,1861]
operator: = [1860,1861]
===
match
---
trailer [4534,4544]
trailer [4534,4544]
===
match
---
parameters [1608,1610]
parameters [1608,1610]
===
match
---
if_stmt [12979,13106]
if_stmt [12979,13106]
===
match
---
operator: = [23066,23067]
operator: = [23291,23292]
===
match
---
expr_stmt [20385,20418]
expr_stmt [20610,20643]
===
match
---
simple_stmt [13885,13939]
simple_stmt [13885,13939]
===
match
---
param [17336,17340]
param [17336,17340]
===
match
---
operator: = [11881,11882]
operator: = [11881,11882]
===
match
---
argument [10308,10317]
argument [10308,10317]
===
match
---
name: stop [15325,15329]
name: stop [15325,15329]
===
match
---
trailer [12035,12040]
trailer [12035,12040]
===
match
---
argument [21361,21386]
argument [21586,21611]
===
match
---
parameters [10370,10376]
parameters [10370,10376]
===
match
---
suite [3172,3587]
suite [3172,3587]
===
match
---
trailer [17746,17750]
trailer [17746,17750]
===
match
---
trailer [6493,6500]
trailer [6493,6500]
===
match
---
name: config [8304,8310]
name: config [8304,8310]
===
match
---
name: pytest [10048,10054]
name: pytest [10048,10054]
===
match
---
atom [17237,17255]
atom [17237,17255]
===
match
---
parameters [2143,2152]
parameters [2143,2152]
===
match
---
name: create_dag [23352,23362]
name: create_dag [23577,23587]
===
match
---
argument [12592,12614]
argument [12592,12614]
===
match
---
name: environ [12985,12992]
name: environ [12985,12992]
===
match
---
trailer [13925,13938]
trailer [13925,13938]
===
match
---
trailer [10879,10886]
trailer [10879,10886]
===
match
---
operator: , [22556,22557]
operator: , [22781,22782]
===
match
---
trailer [6530,6590]
trailer [6530,6590]
===
match
---
string: "And --include-quarantined flag is passed to pytest. {item}" [10819,10879]
string: "And --include-quarantined flag is passed to pytest. {item}" [10819,10879]
===
match
---
name: format [10880,10886]
name: format [10880,10886]
===
match
---
trailer [18190,18204]
trailer [18190,18204]
===
match
---
atom_expr [4327,4524]
atom_expr [4327,4524]
===
match
---
arglist [22800,23239]
arglist [23025,23464]
===
match
---
string: "INTEGRATION_" [11028,11042]
string: "INTEGRATION_" [11028,11042]
===
match
---
trailer [21343,21400]
trailer [21568,21625]
===
match
---
name: center [6123,6129]
name: center [6123,6129]
===
match
---
name: session [19023,19030]
name: session [18998,19005]
===
match
---
arglist [3926,4139]
arglist [3926,4139]
===
match
---
name: pytest [923,929]
name: pytest [923,929]
===
match
---
argument [9541,9554]
argument [9541,9554]
===
match
---
name: resetdb [1993,2000]
name: resetdb [1993,2000]
===
match
---
operator: = [18470,18471]
operator: = [18470,18471]
===
match
---
simple_stmt [21121,21259]
simple_stmt [21346,21484]
===
match
---
operator: = [2360,2361]
operator: = [2360,2361]
===
match
---
simple_stmt [21516,21534]
simple_stmt [21741,21759]
===
match
---
name: dag [18030,18033]
name: dag [18030,18033]
===
match
---
name: self [17701,17705]
name: self [17701,17705]
===
match
---
name: task_concurrency [22833,22849]
name: task_concurrency [23058,23074]
===
match
---
trailer [20829,20835]
trailer [21054,21060]
===
match
---
trailer [13306,13313]
trailer [13306,13313]
===
match
---
if_stmt [18095,18139]
if_stmt [18095,18139]
===
match
---
trailer [7829,7846]
trailer [7829,7846]
===
match
---
operator: = [19547,19548]
operator: = [19772,19773]
===
match
---
string: "SKIP_INIT_DB" [5868,5882]
string: "SKIP_INIT_DB" [5868,5882]
===
match
---
name: self [20385,20389]
name: self [20610,20614]
===
match
---
operator: = [23294,23295]
operator: = [23519,23520]
===
match
---
simple_stmt [2222,2279]
simple_stmt [2222,2279]
===
match
---
name: _ [10386,10387]
name: _ [10386,10387]
===
match
---
trailer [8327,8403]
trailer [8327,8403]
===
match
---
name: db [5552,5554]
name: db [5552,5554]
===
match
---
name: item [8469,8473]
name: item [8469,8473]
===
match
---
trailer [12815,12820]
trailer [12815,12820]
===
match
---
nonlocal_stmt [14926,14952]
nonlocal_stmt [14926,14952]
===
match
---
import_from [17897,17932]
import_from [17897,17932]
===
match
---
trailer [12040,12510]
trailer [12040,12510]
===
match
---
name: marker [10943,10949]
name: marker [10943,10949]
===
match
---
string: "append" [4379,4387]
string: "append" [4379,4387]
===
match
---
name: DagRun [21047,21053]
name: DagRun [21272,21278]
===
match
---
simple_stmt [10962,10996]
simple_stmt [10962,10996]
===
match
---
atom_expr [7211,7249]
atom_expr [7211,7249]
===
match
---
testlist_comp [17285,17290]
testlist_comp [17285,17290]
===
match
---
trailer [12691,12696]
trailer [12691,12696]
===
match
---
name: self [18511,18515]
name: self [18511,18515]
===
match
---
name: delete [21337,21343]
name: delete [21562,21568]
===
match
---
operator: = [1667,1668]
operator: = [1667,1668]
===
match
---
trailer [13051,13105]
trailer [13051,13105]
===
match
---
string: "System tests are only run when --system flag " [10138,10185]
string: "System tests are only run when --system flag " [10138,10185]
===
match
---
string: "--system" [13262,13272]
string: "--system" [13262,13272]
===
match
---
name: initial_db_init [6874,6889]
name: initial_db_init [6874,6889]
===
match
---
decorated [21564,23363]
decorated [21789,23588]
===
match
---
name: timedelta [888,897]
name: timedelta [888,897]
===
match
---
simple_stmt [19839,19888]
simple_stmt [20064,20113]
===
match
---
name: environment_variable_value [11597,11623]
name: environment_variable_value [11597,11623]
===
match
---
operator: , [22815,22816]
operator: , [23040,23041]
===
match
---
atom_expr [1990,2002]
atom_expr [1990,2002]
===
match
---
name: self [19018,19022]
name: self [18993,18997]
===
match
---
name: session [18402,18409]
name: session [18402,18409]
===
match
---
name: environ [1297,1304]
name: environ [1297,1304]
===
match
---
atom_expr [7401,7469]
atom_expr [7401,7469]
===
match
---
for_stmt [13788,13881]
for_stmt [13788,13881]
===
match
---
trailer [18246,18252]
trailer [18246,18252]
===
match
---
simple_stmt [15042,15067]
simple_stmt [15042,15067]
===
match
---
dotted_name [22247,22270]
dotted_name [22472,22495]
===
match
---
operator: @ [1878,1879]
operator: @ [1878,1879]
===
match
---
name: State [18887,18892]
name: State [18853,18858]
===
match
---
atom_expr [14170,14207]
atom_expr [14170,14207]
===
match
---
atom_expr [1669,1686]
atom_expr [1669,1686]
===
match
---
trailer [17636,17652]
trailer [17636,17652]
===
match
---
name: datetime [862,870]
name: datetime [862,870]
===
match
---
suite [1785,1818]
suite [1785,1818]
===
match
---
name: query [21134,21139]
name: query [21359,21364]
===
match
---
name: trace_sql_option [2705,2721]
name: trace_sql_option [2705,2721]
===
match
---
operator: = [10979,10980]
operator: = [10979,10980]
===
match
---
operator: = [21238,21239]
operator: = [21463,21464]
===
match
---
name: dag_id [21316,21322]
name: dag_id [21541,21547]
===
match
---
simple_stmt [17799,17832]
simple_stmt [17799,17832]
===
match
---
atom_expr [18295,18315]
atom_expr [18295,18315]
===
match
---
argument [4220,4237]
argument [4220,4237]
===
match
---
name: dagbag [20648,20654]
name: dagbag [20873,20879]
===
match
---
string: "airflow" [3720,3729]
string: "airflow" [3720,3729]
===
match
---
name: path [1083,1087]
name: path [1083,1087]
===
match
---
operator: = [17521,17522]
operator: = [17521,17522]
===
match
---
name: config [13381,13387]
name: config [13381,13387]
===
match
---
name: __exit__ [17845,17853]
name: __exit__ [17845,17853]
===
match
---
simple_stmt [17897,17933]
simple_stmt [17897,17933]
===
match
---
name: dirname [1088,1095]
name: dirname [1088,1095]
===
match
---
atom_expr [8707,8978]
atom_expr [8707,8978]
===
match
---
atom_expr [2778,2812]
atom_expr [2778,2812]
===
match
---
string: "session" [5603,5612]
string: "session" [5603,5612]
===
match
---
trailer [6632,6637]
trailer [6632,6637]
===
match
---
name: kwargs [19137,19143]
name: kwargs [19362,19368]
===
match
---
not_test [14035,14059]
not_test [14035,14059]
===
match
---
operator: , [4414,4415]
operator: , [4414,4415]
===
match
---
trailer [21315,21322]
trailer [21540,21547]
===
match
---
trailer [12711,12730]
trailer [12711,12730]
===
match
---
simple_stmt [6060,6100]
simple_stmt [6060,6100]
===
match
---
string: 'time' [2051,2057]
string: 'time' [2051,2057]
===
match
---
trailer [6194,6199]
trailer [6194,6199]
===
match
---
operator: , [22624,22625]
operator: , [22849,22850]
===
match
---
decorator [2100,2130]
decorator [2100,2130]
===
match
---
operator: = [9578,9579]
operator: = [9578,9579]
===
match
---
argument [8968,8977]
argument [8968,8977]
===
match
---
funcdef [14893,15188]
funcdef [14893,15188]
===
match
---
name: session [18196,18203]
name: session [18196,18203]
===
match
---
trailer [1392,1411]
trailer [1392,1411]
===
match
---
operator: = [7336,7337]
operator: = [7336,7337]
===
match
---
if_stmt [8583,8682]
if_stmt [8583,8682]
===
match
---
operator: = [9945,9946]
operator: = [9945,9946]
===
match
---
trailer [3195,3209]
trailer [3195,3209]
===
match
---
suite [2762,2813]
suite [2762,2813]
===
match
---
name: os [6060,6062]
name: os [6060,6062]
===
match
---
trailer [4155,4165]
trailer [4155,4165]
===
match
---
atom_expr [6630,6655]
atom_expr [6630,6655]
===
match
---
name: self [20213,20217]
name: self [20438,20442]
===
match
---
simple_stmt [14069,14098]
simple_stmt [14069,14098]
===
match
---
simple_stmt [5552,5565]
simple_stmt [5552,5565]
===
match
---
atom_expr [1294,1330]
atom_expr [1294,1330]
===
match
---
name: setattr [15205,15212]
name: setattr [15205,15212]
===
match
---
name: print_fn [3532,3540]
name: print_fn [3532,3540]
===
match
---
trailer [20327,20335]
trailer [20552,20560]
===
match
---
string: 'CREDENTIALS_DIR' [12712,12729]
string: 'CREDENTIALS_DIR' [12712,12729]
===
match
---
simple_stmt [19493,19522]
simple_stmt [19718,19747]
===
match
---
comparison [19789,19817]
comparison [20014,20042]
===
match
---
suite [9047,9443]
suite [9047,9443]
===
match
---
string: "--include-long-running" [13324,13348]
string: "--include-long-running" [13324,13348]
===
match
---
param [10371,10375]
param [10371,10375]
===
match
---
suite [2636,2666]
suite [2636,2666]
===
match
---
import_from [1452,1566]
import_from [1452,1566]
===
match
---
trailer [10059,10341]
trailer [10059,10341]
===
match
---
trailer [12654,12657]
trailer [12654,12657]
===
match
---
expr_stmt [13216,13273]
expr_stmt [13216,13273]
===
match
---
operator: , [4775,4776]
operator: , [4775,4776]
===
match
---
name: dagbag [17477,17483]
name: dagbag [17477,17483]
===
match
---
name: models [20497,20503]
name: models [20722,20728]
===
match
---
trailer [18600,18606]
trailer [18600,18606]
===
match
---
simple_stmt [12666,12749]
simple_stmt [12666,12749]
===
match
---
param [17873,17882]
param [17873,17882]
===
match
---
suite [10715,10908]
suite [10715,10908]
===
match
---
trailer [20835,20837]
trailer [21060,21062]
===
match
---
trailer [12686,12691]
trailer [12686,12691]
===
match
---
atom_expr [17742,17750]
atom_expr [17742,17750]
===
match
---
string: "only run tests matching integration specified: " [4013,4062]
string: "only run tests matching integration specified: " [4013,4062]
===
match
---
name: config [8166,8172]
name: config [8166,8172]
===
match
---
trailer [1112,1122]
trailer [1112,1122]
===
match
---
operator: = [20278,20279]
operator: = [20503,20504]
===
match
---
simple_stmt [13845,13881]
simple_stmt [13845,13881]
===
match
---
name: addinivalue_line [7830,7846]
name: addinivalue_line [7830,7846]
===
match
---
atom_expr [12643,12657]
atom_expr [12643,12657]
===
match
---
string: "airflow" [6288,6297]
string: "airflow" [6288,6297]
===
match
---
atom_expr [3117,3171]
atom_expr [3117,3171]
===
match
---
operator: = [22585,22586]
operator: = [22810,22811]
===
match
---
simple_stmt [11774,11808]
simple_stmt [11774,11808]
===
match
---
trailer [1854,1859]
trailer [1854,1859]
===
match
---
atom_expr [10724,10907]
atom_expr [10724,10907]
===
match
---
simple_stmt [6665,6866]
simple_stmt [6665,6866]
===
match
---
name: DagModel [18253,18261]
name: DagModel [18253,18261]
===
match
---
operator: = [3843,3844]
operator: = [3843,3844]
===
match
---
expr_stmt [12625,12657]
expr_stmt [12625,12657]
===
match
---
name: environ [5347,5354]
name: environ [5347,5354]
===
match
---
trailer [18029,18033]
trailer [18029,18033]
===
match
---
funcdef [7595,8404]
funcdef [7595,8404]
===
match
---
string: 'DEFAULT_DATE' [19968,19982]
string: 'DEFAULT_DATE' [20193,20207]
===
match
---
trailer [8571,8574]
trailer [8571,8574]
===
match
---
name: self [17577,17581]
name: self [17577,17581]
===
match
---
name: kwargs [19626,19632]
name: kwargs [19851,19857]
===
match
---
atom_expr [9580,9594]
atom_expr [9580,9594]
===
match
---
name: email [23157,23162]
name: email [23382,23387]
===
match
---
simple_stmt [15307,15332]
simple_stmt [15307,15332]
===
match
---
name: fileloc [20328,20335]
name: fileloc [20553,20560]
===
match
---
arglist [5020,5305]
arglist [5020,5305]
===
match
---
name: dag_id [21174,21180]
name: dag_id [21399,21405]
===
match
---
string: "airflow resetdb -y" [5474,5494]
string: "airflow resetdb -y" [5474,5494]
===
match
---
name: selected_backend [14004,14020]
name: selected_backend [14004,14020]
===
match
---
argument [4814,4910]
argument [4814,4910]
===
match
---
simple_stmt [19366,19397]
simple_stmt [19591,19622]
===
match
---
operator: , [12401,12402]
operator: , [12401,12402]
===
match
---
atom_expr [12697,12730]
atom_expr [12697,12730]
===
match
---
name: include_long_running [13279,13299]
name: include_long_running [13279,13299]
===
match
---
name: email [23163,23168]
name: email [23388,23393]
===
match
---
testlist [23332,23339]
testlist [23557,23564]
===
match
---
name: in_ [21323,21326]
name: in_ [21548,21551]
===
match
---
name: dag_ids [20655,20662]
name: dag_ids [20880,20887]
===
match
---
dotted_name [18744,18763]
dotted_name [18744,18763]
===
match
---
operator: { [5233,5234]
operator: { [5233,5234]
===
match
---
name: count_queries [1531,1544]
name: count_queries [1531,1544]
===
match
---
string: "Only tests marked with pytest.mark.integration(INTEGRATION) are run with INTEGRATION" [8793,8879]
string: "Only tests marked with pytest.mark.integration(INTEGRATION) are run with INTEGRATION" [8793,8879]
===
match
---
operator: = [19272,19273]
operator: = [19497,19498]
===
match
---
comparison [1765,1784]
comparison [1765,1784]
===
match
---
name: os [1096,1098]
name: os [1096,1098]
===
match
---
argument [3121,3170]
argument [3121,3170]
===
match
---
atom_expr [10292,10306]
atom_expr [10292,10306]
===
match
---
string: "KRB5_KTNAME" [7353,7366]
string: "KRB5_KTNAME" [7353,7366]
===
match
---
trailer [21432,21434]
trailer [21657,21659]
===
match
---
name: app [15406,15409]
name: app [15406,15409]
===
match
---
name: delete [21075,21081]
name: delete [21300,21306]
===
match
---
or_test [1378,1450]
or_test [1378,1450]
===
match
---
string: "kinit" [7424,7431]
string: "kinit" [7424,7431]
===
match
---
trailer [19607,19618]
trailer [19832,19843]
===
match
---
or_test [1294,1345]
or_test [1294,1345]
===
match
---
name: filter [21040,21046]
name: filter [21265,21271]
===
match
---
operator: , [7431,7432]
operator: , [7431,7432]
===
match
---
name: os [1206,1208]
name: os [1206,1208]
===
match
---
name: dag_run [19169,19176]
name: dag_run [19394,19401]
===
match
---
name: iter_markers [10396,10408]
name: iter_markers [10396,10408]
===
match
---
trailer [2376,2390]
trailer [2376,2390]
===
match
---
expr_stmt [19493,19521]
expr_stmt [19718,19746]
===
match
---
operator: = [19855,19856]
operator: = [20080,20081]
===
match
---
name: self [18191,18195]
name: self [18191,18195]
===
match
---
trailer [20224,20238]
trailer [20449,20463]
===
match
---
funcdef [10344,10629]
funcdef [10344,10629]
===
match
---
atom_expr [1378,1411]
atom_expr [1378,1411]
===
match
---
name: freezegun_control [14935,14952]
name: freezegun_control [14935,14952]
===
match
---
arglist [14004,14026]
arglist [14004,14026]
===
match
---
name: traceback [18072,18081]
name: traceback [18072,18081]
===
match
---
testlist_comp [2682,2732]
testlist_comp [2682,2732]
===
match
---
arglist [12321,12486]
arglist [12321,12486]
===
match
---
argument [3839,3889]
argument [3839,3889]
===
match
---
arglist [4752,4911]
arglist [4752,4911]
===
match
---
if_stmt [12757,12885]
if_stmt [12757,12885]
===
match
---
comparison [11186,11222]
comparison [11186,11222]
===
match
---
operator: = [19581,19582]
operator: = [19806,19807]
===
match
---
atom_expr [20170,20185]
atom_expr [20395,20410]
===
match
---
trailer [3051,3065]
trailer [3051,3065]
===
match
---
trailer [3750,3896]
trailer [3750,3896]
===
match
---
name: item [10657,10661]
name: item [10657,10661]
===
match
---
name: group [4529,4534]
name: group [4529,4534]
===
match
---
name: utcnow [14979,14985]
name: utcnow [14979,14985]
===
match
---
name: item [9498,9502]
name: item [9498,9502]
===
match
---
trailer [9131,9136]
trailer [9131,9136]
===
match
---
name: item [10391,10395]
name: item [10391,10395]
===
match
---
atom_expr [18796,18804]
atom_expr [18796,18804]
===
match
---
arglist [13714,13741]
arglist [13714,13741]
===
match
---
trailer [1388,1392]
trailer [1388,1392]
===
match
---
atom_expr [11883,11924]
atom_expr [11883,11924]
===
match
---
string: "AIRFLOW__CORE__UNIT_TEST_MODE" [1217,1248]
string: "AIRFLOW__CORE__UNIT_TEST_MODE" [1217,1248]
===
match
---
if_stmt [13649,13784]
if_stmt [13649,13784]
===
match
---
trailer [20863,20869]
trailer [21088,21094]
===
match
---
name: getgroup [3711,3719]
name: getgroup [3711,3719]
===
match
---
operator: = [19115,19116]
operator: = [19340,19341]
===
match
---
trailer [19694,19716]
trailer [19919,19941]
===
match
---
atom_expr [18217,18231]
atom_expr [18217,18231]
===
match
---
operator: = [22899,22900]
operator: = [23124,23125]
===
match
---
trailer [10260,10267]
trailer [10260,10267]
===
match
---
trailer [2806,2812]
trailer [2806,2812]
===
match
---
operator: , [22915,22916]
operator: , [23140,23141]
===
match
---
operator: , [3396,3397]
operator: , [3396,3397]
===
match
---
trailer [9070,9083]
trailer [9070,9083]
===
match
---
suite [15377,15451]
suite [15377,15451]
===
match
---
suite [11769,12511]
suite [11769,12511]
===
match
---
funcdef [17563,17751]
funcdef [17563,17751]
===
match
---
operator: = [18232,18233]
operator: = [18232,18233]
===
match
---
string: "Skipping initializing of the DB as it was initialized already.\n" [7008,7074]
string: "Skipping initializing of the DB as it was initialized already.\n" [7008,7074]
===
match
---
operator: = [4428,4429]
operator: = [4428,4429]
===
match
---
name: freezegun_control [15075,15092]
name: freezegun_control [15075,15092]
===
match
---
string: "Forces database initialization before tests" [3844,3889]
string: "Forces database initialization before tests" [3844,3889]
===
match
---
name: environ [1718,1725]
name: environ [1718,1725]
===
match
---
trailer [2832,2834]
trailer [2832,2834]
===
match
---
operator: , [4138,4139]
operator: , [4138,4139]
===
match
---
expr_stmt [6413,6478]
expr_stmt [6413,6478]
===
match
---
name: print_fn [3080,3088]
name: print_fn [3080,3088]
===
match
---
fstring_end: " [5266,5267]
fstring_end: " [5266,5267]
===
match
---
expr_stmt [2342,2420]
expr_stmt [2342,2420]
===
match
---
simple_stmt [21271,21401]
simple_stmt [21496,21626]
===
match
---
name: fake_sleep [15249,15259]
name: fake_sleep [15249,15259]
===
match
---
for_stmt [9509,9688]
for_stmt [9509,9688]
===
match
---
return_stmt [17670,17722]
return_stmt [17670,17722]
===
match
---
and_test [19732,19768]
and_test [19957,19993]
===
match
---
name: on_retry_callback [23122,23139]
name: on_retry_callback [23347,23364]
===
match
---
name: start_date [20010,20020]
name: start_date [20235,20245]
===
match
---
param [9981,9985]
param [9981,9985]
===
match
---
dotted_name [17902,17916]
dotted_name [17902,17916]
===
match
---
name: SerializedDagModel [20897,20915]
name: SerializedDagModel [21122,21140]
===
match
---
name: getoption [2256,2265]
name: getoption [2256,2265]
===
match
---
atom_expr [1862,1875]
atom_expr [1862,1875]
===
match
---
string: 'parameters' [3487,3499]
string: 'parameters' [3487,3499]
===
match
---
atom_expr [12684,12748]
atom_expr [12684,12748]
===
match
---
name: type [18059,18063]
name: type [18059,18063]
===
match
---
name: freezegun [15095,15104]
name: freezegun [15095,15104]
===
match
---
simple_stmt [2015,2098]
simple_stmt [2015,2098]
===
match
---
decorator [15334,15367]
decorator [15334,15367]
===
match
---
operator: = [13464,13465]
operator: = [13464,13465]
===
match
---
trailer [2795,2806]
trailer [2795,2806]
===
match
---
simple_stmt [1798,1818]
simple_stmt [1798,1818]
===
match
---
name: contextlib [829,839]
name: contextlib [829,839]
===
match
---
fstring [5174,5267]
fstring [5174,5267]
===
match
---
atom_expr [1080,1123]
atom_expr [1080,1123]
===
match
---
fstring_expr [5233,5265]
fstring_expr [5233,5265]
===
match
---
string: 'dag' [22375,22380]
string: 'dag' [22600,22605]
===
match
---
name: exists [12772,12778]
name: exists [12772,12778]
===
match
---
operator: , [7438,7439]
operator: , [7438,7439]
===
match
---
name: addinivalue_line [7921,7937]
name: addinivalue_line [7921,7937]
===
match
---
param [9023,9040]
param [9023,9040]
===
match
---
name: col [2682,2685]
name: col [2682,2685]
===
match
---
arglist [4175,4316]
arglist [4175,4316]
===
match
---
name: get [5864,5867]
name: get [5864,5867]
===
match
---
atom_expr [21161,21193]
atom_expr [21386,21418]
===
match
---
name: self [20319,20323]
name: self [20544,20548]
===
match
---
simple_stmt [17472,17554]
simple_stmt [17472,17554]
===
match
---
if_stmt [13943,14028]
if_stmt [13943,14028]
===
match
---
trailer [20642,20663]
trailer [20867,20888]
===
match
---
expr_stmt [1206,1258]
expr_stmt [1206,1258]
===
match
---
simple_stmt [2158,2218]
simple_stmt [2158,2218]
===
match
---
operator: , [9939,9940]
operator: , [9939,9940]
===
match
---
trailer [9217,9442]
trailer [9217,9442]
===
match
---
funcdef [3604,5312]
funcdef [3604,5312]
===
match
---
funcdef [8987,9443]
funcdef [8987,9443]
===
match
---
name: get [12993,12996]
name: get [12993,12996]
===
match
---
name: utcnow [15117,15123]
name: utcnow [15117,15123]
===
match
---
string: ": {item}" [11508,11518]
string: ": {item}" [11508,11518]
===
match
---
name: config [8020,8026]
name: config [8020,8026]
===
match
---
arglist [6936,6951]
arglist [6936,6951]
===
match
---
name: bag_dag [18523,18530]
name: bag_dag [18523,18530]
===
match
---
name: list [20638,20642]
name: list [20863,20867]
===
match
---
trailer [6042,6050]
trailer [6042,6050]
===
match
---
not_test [6626,6655]
not_test [6626,6655]
===
match
---
param [2756,2760]
param [2756,2760]
===
match
---
name: allowed_trace_sql_columns_list [4922,4952]
name: allowed_trace_sql_columns_list [4922,4952]
===
match
---
atom_expr [13845,13880]
atom_expr [13845,13880]
===
match
---
operator: , [17871,17872]
operator: , [17871,17872]
===
match
---
parameters [9479,9503]
parameters [9479,9503]
===
match
---
trailer [13313,13323]
trailer [13313,13323]
===
match
---
atom_expr [21013,21108]
atom_expr [21238,21333]
===
match
---
argument [11692,11701]
argument [11692,11701]
===
match
---
suite [17653,17723]
suite [17653,17723]
===
match
---
operator: = [17146,17147]
operator: = [17146,17147]
===
match
---
trailer [12992,12996]
trailer [12992,12996]
===
match
---
atom_expr [13302,13349]
atom_expr [13302,13349]
===
match
---
string: "append" [3958,3966]
string: "append" [3958,3966]
===
match
---
trailer [21275,21283]
trailer [21500,21508]
===
match
---
string: "trace_sql" [2266,2277]
string: "trace_sql" [2266,2277]
===
match
---
simple_stmt [11812,11850]
simple_stmt [11812,11850]
===
match
---
name: marker [8484,8490]
name: marker [8484,8490]
===
match
---
operator: { [12876,12877]
operator: { [12876,12877]
===
match
---
string: "markers" [8328,8337]
string: "markers" [8328,8337]
===
match
---
operator: = [11838,11839]
operator: = [11838,11839]
===
match
---
name: os [1669,1671]
name: os [1669,1671]
===
match
---
argument [17505,17527]
argument [17505,17527]
===
match
---
atom_expr [20385,20405]
atom_expr [20610,20630]
===
match
---
string: "db_init" [3820,3829]
string: "db_init" [3820,3829]
===
match
---
dotted_name [20489,20503]
dotted_name [20714,20728]
===
match
---
trailer [8498,8511]
trailer [8498,8511]
===
match
---
name: integration_name [8541,8557]
name: integration_name [8541,8557]
===
match
---
funcdef [8406,8985]
funcdef [8406,8985]
===
match
---
name: self [20241,20245]
name: self [20466,20470]
===
match
---
simple_stmt [13279,13350]
simple_stmt [13279,13350]
===
match
---
atom_expr [15095,15153]
atom_expr [15095,15153]
===
match
---
arith_expr [15117,15152]
arith_expr [15117,15152]
===
match
---
string: 'start_date' [19789,19801]
string: 'start_date' [20014,20026]
===
match
---
param [18710,18715]
param [18710,18715]
===
match
---
name: get [18263,18266]
name: get [18263,18266]
===
match
---
name: utcnow [14961,14967]
name: utcnow [14961,14967]
===
match
---
operator: = [12480,12481]
operator: = [12480,12481]
===
match
---
operator: , [18545,18546]
operator: , [18545,18546]
===
match
---
name: freezegun_control [15042,15059]
name: freezegun_control [15042,15059]
===
match
---
trailer [10694,10714]
trailer [10694,10714]
===
match
---
simple_stmt [11854,11925]
simple_stmt [11854,11925]
===
match
---
trailer [18592,18600]
trailer [18592,18600]
===
match
---
name: path [1171,1175]
name: path [1171,1175]
===
match
---
string: "system(name): mark test to run with named system" [7858,7908]
string: "system(name): mark test to run with named system" [7858,7908]
===
match
---
name: synchronize_session [21219,21238]
name: synchronize_session [21444,21463]
===
match
---
simple_stmt [21413,21435]
simple_stmt [21638,21660]
===
match
---
atom_expr [23262,23316]
atom_expr [23487,23541]
===
match
---
name: trace_queries [3227,3240]
name: trace_queries [3227,3240]
===
match
---
trailer [22725,22743]
trailer [22950,22968]
===
match
---
name: run_type [23286,23294]
name: run_type [23511,23519]
===
match
---
trailer [4342,4524]
trailer [4342,4524]
===
match
---
name: name [8512,8516]
name: name [8512,8516]
===
match
---
name: valid_backend_names [12439,12458]
name: valid_backend_names [12439,12458]
===
match
---
atom_expr [3041,3103]
atom_expr [3041,3103]
===
match
---
return_stmt [19157,19176]
return_stmt [19382,19401]
===
match
---
name: defaults [19070,19078]
name: kwargs [19025,19031]
===
match
---
suite [17583,17751]
suite [17583,17751]
===
match
---
name: skip [8693,8697]
name: skip [8693,8697]
===
match
---
atom_expr [6665,6865]
atom_expr [6665,6865]
===
match
---
trailer [1180,1205]
trailer [1180,1205]
===
match
---
operator: , [12485,12486]
operator: , [12485,12486]
===
match
---
name: self [21413,21417]
name: self [21638,21642]
===
match
---
simple_stmt [7629,7726]
simple_stmt [7629,7726]
===
match
---
funcdef [21580,23363]
funcdef [21805,23588]
===
match
---
string: "us-east-1" [1334,1345]
string: "us-east-1" [1334,1345]
===
match
---
name: serialized [20408,20418]
name: serialized [20633,20643]
===
match
---
testlist_comp [17238,17254]
testlist_comp [17238,17254]
===
match
---
operator: , [3446,3447]
operator: , [3446,3447]
===
match
---
name: datetime [20129,20137]
name: datetime [20354,20362]
===
match
---
operator: } [22488,22489]
operator: } [22713,22714]
===
match
---
simple_stmt [20005,20063]
simple_stmt [20230,20288]
===
match
---
atom_expr [20120,20149]
atom_expr [20345,20374]
===
match
---
suite [8662,8682]
suite [8662,8682]
===
match
---
operator: , [3553,3554]
operator: , [3553,3554]
===
match
---
name: skip_if_wrong_backend [13845,13866]
name: skip_if_wrong_backend [13845,13866]
===
match
---
name: dag [18046,18049]
name: dag [18046,18049]
===
match
---
name: group [3696,3701]
name: group [3696,3701]
===
match
---
funcdef [5314,5565]
funcdef [5314,5565]
===
match
---
name: trace_sql_option [2222,2238]
name: trace_sql_option [2222,2238]
===
match
---
name: pytest [15335,15341]
name: pytest [15335,15341]
===
match
---
name: self [18663,18667]
name: self [18663,18667]
===
match
---
suite [17228,17292]
suite [17228,17292]
===
match
---
suite [1831,1876]
suite [1831,1876]
===
match
---
atom_expr [6235,6265]
atom_expr [6235,6265]
===
match
---
atom_expr [12934,12969]
atom_expr [12934,12969]
===
match
---
argument [5287,5304]
argument [5287,5304]
===
match
---
arglist [15213,15237]
arglist [15213,15237]
===
match
---
if_stmt [17207,17292]
if_stmt [17207,17292]
===
match
---
name: fixture [15461,15468]
name: fixture [15461,15468]
===
match
---
atom_expr [18025,18033]
atom_expr [18025,18033]
===
match
---
comparison [3325,3342]
comparison [3325,3342]
===
match
---
argument [4617,4715]
argument [4617,4715]
===
match
---
string: 'start_date' [19637,19649]
string: 'start_date' [19862,19874]
===
match
---
name: environment_variable_value [11854,11880]
name: environment_variable_value [11854,11880]
===
match
---
name: item [14235,14239]
name: item [14235,14239]
===
match
---
trailer [5473,5495]
trailer [5473,5495]
===
match
---
name: timedelta [15126,15135]
name: timedelta [15126,15135]
===
match
---
simple_stmt [10724,10908]
simple_stmt [10724,10908]
===
match
---
name: item [11697,11701]
name: item [11697,11701]
===
match
---
arglist [20138,20148]
arglist [20363,20373]
===
match
---
name: __enter__ [17567,17576]
name: __enter__ [17567,17576]
===
match
---
trailer [6070,6090]
trailer [6070,6090]
===
match
---
operator: , [22590,22591]
operator: , [22815,22816]
===
match
---
comparison [3378,3396]
comparison [3378,3396]
===
match
---
simple_stmt [12029,12511]
simple_stmt [12029,12511]
===
match
---
atom_expr [23295,23315]
atom_expr [23520,23540]
===
match
---
atom_expr [1206,1249]
atom_expr [1206,1249]
===
match
---
dotted_name [1457,1498]
dotted_name [1457,1498]
===
match
---
name: marker [9056,9062]
name: marker [9056,9062]
===
match
---
atom_expr [6111,6138]
atom_expr [6111,6138]
===
match
---
name: allowed_trace_sql_columns_list [5234,5264]
name: allowed_trace_sql_columns_list [5234,5264]
===
match
---
atom_expr [12054,12500]
atom_expr [12054,12500]
===
match
---
name: autouse [5583,5590]
name: autouse [5583,5590]
===
match
---
simple_stmt [7581,7593]
simple_stmt [7581,7593]
===
match
---
simple_stmt [20554,20615]
simple_stmt [20779,20840]
===
match
---
name: name [12592,12596]
name: name [12592,12596]
===
match
---
simple_stmt [916,930]
simple_stmt [916,930]
===
match
---
simple_stmt [19669,19717]
simple_stmt [19894,19942]
===
match
---
name: synchronize_session [21361,21380]
name: synchronize_session [21586,21605]
===
match
---
name: session [21418,21425]
name: session [21643,21650]
===
match
---
trailer [11893,11897]
trailer [11893,11897]
===
match
---
name: help [3839,3843]
name: help [3839,3843]
===
match
---
suite [5884,5975]
suite [5884,5975]
===
match
---
operator: = [13300,13301]
operator: = [13300,13301]
===
match
---
expr_stmt [6220,6298]
expr_stmt [6220,6298]
===
match
---
name: db_init [6508,6515]
name: db_init [6508,6515]
===
match
---
name: exit_stack [3185,3195]
name: exit_stack [3185,3195]
===
match
---
name: serialized_dag [17965,17979]
name: serialized_dag [17965,17979]
===
match
---
name: marker [9580,9586]
name: marker [9580,9586]
===
match
---
trailer [21074,21081]
trailer [21299,21306]
===
match
---
operator: , [14020,14021]
operator: , [14020,14021]
===
match
---
name: metavar [5287,5294]
name: metavar [5287,5294]
===
match
---
operator: , [22676,22677]
operator: , [22901,22902]
===
match
---
name: skip_if_not_marked_with_system [13683,13713]
name: skip_if_not_marked_with_system [13683,13713]
===
match
---
atom_expr [18933,18948]
atom_expr [18902,18917]
===
match
---
trailer [18800,18804]
trailer [18800,18804]
===
match
---
name: models [20567,20573]
name: models [20792,20798]
===
match
---
name: self [17596,17600]
name: self [17596,17600]
===
match
---
string: "Kerberos enabled! Please setup KRB5_KTNAME environment variable" [7502,7567]
string: "Kerberos enabled! Please setup KRB5_KTNAME environment variable" [7502,7567]
===
match
---
strings [6684,6855]
strings [6684,6855]
===
match
---
expr_stmt [7327,7367]
expr_stmt [7327,7367]
===
match
---
trailer [20009,20020]
trailer [20234,20245]
===
match
---
name: environ [11886,11893]
name: environ [11886,11893]
===
match
---
arglist [10285,10317]
arglist [10285,10317]
===
match
---
trailer [10681,10694]
trailer [10681,10694]
===
match
---
trailer [18415,18438]
trailer [18415,18438]
===
match
---
operator: = [9922,9923]
operator: = [9922,9923]
===
match
---
name: item [10677,10681]
name: item [10677,10681]
===
match
---
name: config [2370,2376]
name: config [2370,2376]
===
match
---
suite [8532,8682]
suite [8532,8682]
===
match
---
operator: , [23139,23140]
operator: , [23364,23365]
===
match
---
trailer [11525,11716]
trailer [11525,11716]
===
match
---
arglist [8328,8402]
arglist [8328,8402]
===
match
---
name: getoption [13916,13925]
name: getoption [13916,13925]
===
match
---
arglist [6438,6477]
arglist [6438,6477]
===
match
---
operator: = [3486,3487]
operator: = [3486,3487]
===
match
---
param [9041,9045]
param [9041,9045]
===
match
---
simple_stmt [22296,22339]
simple_stmt [22521,22564]
===
match
---
simple_stmt [20628,20664]
simple_stmt [20853,20889]
===
match
---
if_stmt [2607,2666]
if_stmt [2607,2666]
===
match
---
suite [19923,20201]
suite [20148,20426]
===
match
---
operator: , [11674,11675]
operator: , [11674,11675]
===
match
---
name: reset_db [1900,1908]
name: reset_db [1900,1908]
===
match
---
simple_stmt [8020,8162]
simple_stmt [8020,8162]
===
match
---
if_stmt [5850,5975]
if_stmt [5850,5975]
===
match
---
trailer [3719,3730]
trailer [3719,3730]
===
match
---
atom_expr [13683,13742]
atom_expr [13683,13742]
===
match
---
suite [13566,13645]
suite [13566,13645]
===
match
---
name: __exit__ [18050,18058]
name: __exit__ [18050,18058]
===
match
---
operator: { [12857,12858]
operator: { [12857,12858]
===
match
---
operator: = [3273,3274]
operator: = [3273,3274]
===
match
---
trailer [4742,4917]
trailer [4742,4917]
===
match
---
simple_stmt [17355,17389]
simple_stmt [17355,17389]
===
match
---
trailer [5863,5867]
trailer [5863,5867]
===
match
---
operator: = [21380,21381]
operator: = [21605,21606]
===
match
---
parameters [5636,5645]
parameters [5636,5645]
===
match
---
trailer [18476,18492]
trailer [18476,18492]
===
match
---
return_stmt [20432,20443]
return_stmt [20657,20668]
===
match
---
atom [17284,17291]
atom [17284,17291]
===
match
---
trailer [21425,21432]
trailer [21650,21657]
===
match
---
operator: = [12682,12683]
operator: = [12682,12683]
===
match
---
simple_stmt [6304,6368]
simple_stmt [6304,6368]
===
match
---
atom [7423,7468]
atom [7423,7468]
===
match
---
if_stmt [2283,2337]
if_stmt [2283,2337]
===
match
---
not_test [12760,12795]
not_test [12760,12795]
===
match
---
fstring_string: The test requires credential file  [12823,12857]
fstring_string: The test requires credential file  [12823,12857]
===
match
---
name: self [18295,18299]
name: self [18295,18299]
===
match
---
name: breeze_test_helper [5618,5636]
name: breeze_test_helper [5618,5636]
===
match
---
trailer [8026,8043]
trailer [8026,8043]
===
match
---
name: dag [18376,18379]
name: dag [18376,18379]
===
match
---
name: dag_ids [21327,21334]
name: dag_ids [21552,21559]
===
match
---
trailer [14234,14240]
trailer [14234,14240]
===
match
---
name: module [20039,20045]
name: module [20264,20270]
===
match
---
trailer [5010,5311]
trailer [5010,5311]
===
insert-node
---
simple_stmt [18817,19047]
to
suite [18726,19177]
at 2
===
insert-node
---
if_stmt [19217,19315]
to
suite [18726,19177]
at 3
===
insert-node
---
expr_stmt [18817,19046]
to
simple_stmt [18817,19047]
at 0
===
insert-node
---
and_test [19220,19271]
to
if_stmt [19217,19315]
at 0
===
insert-node
---
suite [19272,19315]
to
if_stmt [19217,19315]
at 1
===
update-node
---
name: defaults [18817,18825]
replace defaults by kwargs
===
move-tree
---
name: defaults [18817,18825]
to
expr_stmt [18817,19046]
at 0
===
move-tree
---
operator: = [18826,18827]
to
expr_stmt [18817,19046]
at 1
===
insert-node
---
atom [18826,19046]
to
expr_stmt [18817,19046]
at 2
===
insert-node
---
comparison [19220,19242]
to
and_test [19220,19271]
at 0
===
insert-node
---
simple_stmt [19289,19315]
to
suite [19272,19315]
at 0
===
update-node
---
operator: = [18856,18857]
replace = by {
===
move-tree
---
operator: = [18856,18857]
to
atom [18826,19046]
at 0
===
insert-node
---
dictorsetmaker [18844,19032]
to
atom [18826,19046]
at 1
===
update-node
---
operator: ** [19080,19082]
replace ** by }
===
move-tree
---
operator: ** [19080,19082]
to
atom [18826,19046]
at 2
===
move-tree
---
name: kwargs [19082,19088]
to
comparison [19220,19242]
at 2
===
insert-node
---
expr_stmt [19289,19314]
to
simple_stmt [19289,19315]
at 0
===
update-node
---
string: 'test' [18857,18863]
replace 'test' by "state"
===
move-tree
---
string: 'test' [18857,18863]
to
dictorsetmaker [18844,19032]
at 0
===
move-tree
---
atom_expr [18887,18900]
    name: State [18887,18892]
    trailer [18892,18900]
        name: RUNNING [18893,18900]
to
dictorsetmaker [18844,19032]
at 1
===
move-tree
---
operator: , [18900,18901]
to
dictorsetmaker [18844,19032]
at 2
===
move-tree
---
atom_expr [18933,18948]
    name: self [18933,18937]
    trailer [18937,18948]
        name: start_date [18938,18948]
to
dictorsetmaker [18844,19032]
at 4
===
move-tree
---
operator: , [18948,18949]
to
dictorsetmaker [18844,19032]
at 5
===
move-tree
---
atom_expr [18977,18992]
    name: self [18977,18981]
    trailer [18981,18992]
        name: start_date [18982,18992]
to
dictorsetmaker [18844,19032]
at 7
===
move-tree
---
operator: , [18992,18993]
to
dictorsetmaker [18844,19032]
at 8
===
move-tree
---
atom_expr [19018,19030]
    name: self [19018,19022]
    trailer [19022,19030]
        name: session [19023,19030]
to
dictorsetmaker [18844,19032]
at 10
===
move-tree
---
operator: , [19030,19031]
to
dictorsetmaker [18844,19032]
at 11
===
move-tree
---
operator: ** [19068,19070]
to
dictorsetmaker [18844,19032]
at 12
===
update-node
---
name: defaults [19070,19078]
replace defaults by kwargs
===
move-tree
---
name: defaults [19070,19078]
to
dictorsetmaker [18844,19032]
at 13
===
move-tree
---
operator: , [19078,19079]
to
dictorsetmaker [18844,19032]
at 14
===
update-node
---
operator: } [19088,19089]
replace } by =
===
move-tree
---
operator: } [19088,19089]
to
expr_stmt [19289,19314]
at 1
===
delete-node
---
argument [18850,18863]
===
===
delete-node
---
argument [18881,18900]
===
===
delete-node
---
argument [18918,18948]
===
===
delete-node
---
argument [18966,18992]
===
===
delete-node
---
argument [19010,19030]
===
===
delete-node
---
arglist [18850,19031]
===
===
delete-node
---
trailer [18832,19045]
===
===
delete-node
---
atom_expr [18828,19045]
===
===
delete-node
---
expr_stmt [18817,19045]
===
===
delete-node
---
simple_stmt [18817,19046]
===
===
delete-node
---
dictorsetmaker [19068,19088]
===
===
delete-node
---
atom [19067,19089]
===
===
delete-node
---
expr_stmt [19058,19089]
===
===
delete-node
---
simple_stmt [19058,19090]
===
