===
match
---
atom_expr [27606,27626]
atom_expr [27662,27682]
===
match
---
trailer [61147,61167]
trailer [61203,61223]
===
match
---
simple_stmt [28056,28081]
simple_stmt [28112,28137]
===
match
---
string: r"[:\-+.]" [97284,97294]
string: r"[:\-+.]" [97340,97350]
===
match
---
expr_stmt [50005,50039]
expr_stmt [50061,50095]
===
match
---
atom_expr [41034,41053]
atom_expr [41090,41109]
===
match
---
name: SQLCheckOperator [1376,1392]
name: SQLCheckOperator [1376,1392]
===
match
---
atom_expr [25449,25474]
atom_expr [25449,25474]
===
match
---
operator: * [38156,38157]
operator: * [38212,38213]
===
match
---
trailer [78775,78792]
trailer [78831,78848]
===
match
---
atom [29964,31075]
atom [30020,31131]
===
match
---
operator: , [40061,40062]
operator: , [40117,40118]
===
match
---
name: gcp_conn_id [70958,70969]
name: gcp_conn_id [71014,71025]
===
match
---
trailer [74394,74405]
trailer [74450,74461]
===
match
---
argument [86033,86066]
argument [86089,86122]
===
match
---
name: write_disposition [29058,29075]
name: write_disposition [29114,29131]
===
match
---
simple_stmt [13767,13804]
simple_stmt [13767,13804]
===
match
---
name: BaseOperatorLink [2444,2460]
name: BaseOperatorLink [2444,2460]
===
match
---
operator: , [61282,61283]
operator: , [61338,61339]
===
match
---
operator: , [13126,13127]
operator: , [13126,13127]
===
match
---
operator: } [96767,96768]
operator: } [96823,96824]
===
match
---
trailer [51600,51629]
trailer [51656,51685]
===
match
---
argument [30898,30932]
argument [30954,30988]
===
match
---
operator: , [17368,17369]
operator: , [17368,17369]
===
match
---
suite [51148,51457]
suite [51204,51513]
===
match
---
trailer [50189,50205]
trailer [50245,50261]
===
match
---
argument [96319,96351]
argument [96375,96407]
===
match
---
simple_stmt [50087,50130]
simple_stmt [50143,50186]
===
match
---
simple_stmt [67177,67206]
simple_stmt [67233,67262]
===
match
---
parameters [96162,96232]
parameters [96218,96288]
===
match
---
if_stmt [49687,49825]
if_stmt [49743,49881]
===
match
---
atom_expr [29733,29758]
atom_expr [29789,29814]
===
match
---
name: list [26430,26434]
name: list [26430,26434]
===
match
---
tfpdef [66830,66845]
tfpdef [66886,66901]
===
match
---
name: project_id [70653,70663]
name: project_id [70709,70719]
===
match
---
fstring_expr [96750,96768]
fstring_expr [96806,96824]
===
match
---
atom_expr [94873,94887]
atom_expr [94929,94943]
===
match
---
operator: = [95087,95088]
operator: = [95143,95144]
===
match
---
name: self [97400,97404]
name: self [97456,97460]
===
match
---
argument [82427,82463]
argument [82483,82519]
===
match
---
trailer [41555,41618]
trailer [41611,41674]
===
match
---
operator: , [74253,74254]
operator: , [74309,74310]
===
match
---
operator: = [78595,78596]
operator: = [78651,78652]
===
match
---
trailer [25459,25474]
trailer [25459,25474]
===
match
---
name: create_external_table [52160,52181]
name: create_external_table [52216,52237]
===
match
---
operator: , [90921,90922]
operator: , [90977,90978]
===
match
---
operator: = [28723,28724]
operator: = [28779,28780]
===
match
---
operator: = [17540,17541]
operator: = [17540,17541]
===
match
---
suite [70913,71279]
suite [70969,71335]
===
match
---
operator: , [70552,70553]
operator: , [70608,70609]
===
match
---
dotted_name [1531,1571]
dotted_name [1531,1571]
===
match
---
name: self [56481,56485]
name: self [56537,56541]
===
match
---
atom_expr [56966,57104]
atom_expr [57022,57160]
===
match
---
atom_expr [61700,61722]
atom_expr [61756,61778]
===
match
---
name: Dict [38730,38734]
name: Dict [38786,38790]
===
match
---
atom_expr [50005,50023]
atom_expr [50061,50079]
===
match
---
trailer [30455,30476]
trailer [30511,30532]
===
match
---
trailer [25721,25736]
trailer [25721,25736]
===
match
---
operator: = [75056,75057]
operator: = [75112,75113]
===
match
---
name: self [78177,78181]
name: self [78233,78237]
===
match
---
operator: ** [95357,95359]
operator: ** [95413,95415]
===
match
---
trailer [41377,41381]
trailer [41433,41437]
===
match
---
trailer [2798,2839]
trailer [2798,2839]
===
match
---
atom_expr [30210,30234]
atom_expr [30266,30290]
===
match
---
param [38192,38206]
param [38248,38262]
===
match
---
name: impersonation_chain [78576,78595]
name: impersonation_chain [78632,78651]
===
match
---
operator: = [90670,90671]
operator: = [90726,90727]
===
match
---
trailer [90171,90176]
trailer [90227,90232]
===
match
---
operator: , [77712,77713]
operator: , [77768,77769]
===
match
---
subscriptlist [55977,55995]
subscriptlist [56033,56051]
===
match
---
string: 'sql' [25149,25154]
string: 'sql' [25149,25154]
===
match
---
simple_stmt [60598,60826]
simple_stmt [60654,60882]
===
match
---
trailer [77674,77680]
trailer [77730,77736]
===
match
---
operator: , [47775,47776]
operator: , [47831,47832]
===
match
---
argument [2347,2360]
argument [2347,2360]
===
match
---
string: "json" [38022,38028]
string: "json" [38078,38084]
===
match
---
atom_expr [98777,98792]
atom_expr [98833,98848]
===
match
---
operator: , [71028,71029]
operator: , [71084,71085]
===
match
---
argument [17762,17770]
argument [17762,17770]
===
match
---
operator: , [89698,89699]
operator: , [89754,89755]
===
match
---
parameters [31287,31293]
parameters [31343,31349]
===
match
---
simple_stmt [86000,86214]
simple_stmt [86056,86270]
===
match
---
simple_stmt [61104,61135]
simple_stmt [61160,61191]
===
match
---
name: Optional [26602,26610]
name: Optional [26602,26610]
===
match
---
name: use_legacy_sql [13789,13803]
name: use_legacy_sql [13789,13803]
===
match
---
operator: { [52080,52081]
operator: { [52136,52137]
===
match
---
name: self [19000,19004]
name: self [19000,19004]
===
match
---
name: self [39774,39778]
name: self [39830,39834]
===
match
---
name: self [86131,86135]
name: self [86187,86191]
===
match
---
name: labels [29512,29518]
name: labels [29568,29574]
===
match
---
name: self [29570,29574]
name: self [29626,29630]
===
match
---
operator: -> [81440,81442]
operator: -> [81496,81498]
===
match
---
simple_stmt [39326,39391]
simple_stmt [39382,39447]
===
match
---
trailer [97878,97887]
trailer [97934,97943]
===
match
---
name: bq_hook [67646,67653]
name: bq_hook [67702,67709]
===
match
---
tfpdef [48264,48290]
tfpdef [48320,48346]
===
match
---
trailer [74901,74914]
trailer [74957,74970]
===
match
---
name: dttm [2155,2159]
name: dttm [2155,2159]
===
match
---
string: 'CREATE_IF_NEEDED' [26306,26324]
string: 'CREATE_IF_NEEDED' [26306,26324]
===
match
---
atom_expr [27731,27746]
atom_expr [27787,27802]
===
match
---
name: use_legacy_sql [6706,6720]
name: use_legacy_sql [6706,6720]
===
match
---
trailer [97374,97527]
trailer [97430,97583]
===
match
---
argument [28798,28842]
argument [28854,28898]
===
match
---
operator: , [41585,41586]
operator: , [41641,41642]
===
match
---
trailer [86096,86108]
trailer [86152,86164]
===
match
---
fstring_string: BigQuery job  [96716,96729]
fstring_string: BigQuery job  [96772,96785]
===
match
---
operator: , [38399,38400]
operator: , [38455,38456]
===
match
---
operator: , [67518,67519]
operator: , [67574,67575]
===
match
---
simple_stmt [70635,70664]
simple_stmt [70691,70720]
===
match
---
operator: = [28070,28071]
operator: = [28126,28127]
===
match
---
name: table [12901,12906]
name: table [12901,12906]
===
match
---
trailer [41386,41504]
trailer [41442,41560]
===
match
---
operator: , [52670,52671]
operator: , [52726,52727]
===
match
---
atom [94704,94714]
atom [94760,94770]
===
match
---
param [25686,25691]
param [25686,25691]
===
match
---
tfpdef [38409,38442]
tfpdef [38465,38498]
===
match
---
name: Set [1048,1051]
name: Set [1048,1051]
===
match
---
expr_stmt [50732,50778]
expr_stmt [50788,50834]
===
match
---
trailer [73973,73978]
trailer [74029,74034]
===
match
---
argument [9973,9985]
argument [9973,9985]
===
match
---
name: src_fmt_configs [50557,50572]
name: src_fmt_configs [50613,50628]
===
match
---
operator: = [95181,95182]
operator: = [95237,95238]
===
match
---
name: ti [2714,2716]
name: ti [2714,2716]
===
match
---
name: str [95660,95663]
name: str [95716,95719]
===
match
---
name: location [17599,17607]
name: location [17599,17607]
===
match
---
tfpdef [89963,90006]
tfpdef [90019,90062]
===
match
---
name: delegate_to [64107,64118]
name: delegate_to [64163,64174]
===
match
---
trailer [64721,64725]
trailer [64777,64781]
===
match
---
atom_expr [17569,17582]
atom_expr [17569,17582]
===
match
---
atom_expr [95517,95533]
atom_expr [95573,95589]
===
match
---
simple_stmt [90507,90532]
simple_stmt [90563,90588]
===
match
---
name: sql [9820,9823]
name: sql [9820,9823]
===
match
---
name: DeprecationWarning [7037,7055]
name: DeprecationWarning [7037,7055]
===
match
---
name: str [94878,94881]
name: str [94934,94937]
===
match
---
expr_stmt [74540,74570]
expr_stmt [74596,74626]
===
match
---
operator: = [67231,67232]
operator: = [67287,67288]
===
match
---
name: DATASET [77667,77674]
name: DATASET [77723,77730]
===
match
---
trailer [50850,51044]
trailer [50906,51100]
===
match
---
name: self [18430,18434]
name: self [18430,18434]
===
match
---
name: str [9556,9559]
name: str [9556,9559]
===
match
---
suite [19264,31454]
suite [19264,31510]
===
match
---
operator: } [97259,97260]
operator: } [97315,97316]
===
match
---
name: self [90577,90581]
name: self [90633,90637]
===
match
---
argument [9869,9877]
argument [9869,9877]
===
match
---
operator: = [28674,28675]
operator: = [28730,28731]
===
match
---
argument [18634,18667]
argument [18634,18667]
===
match
---
name: str [77756,77759]
name: str [77812,77815]
===
match
---
name: BigQueryGetDatasetOperator [62031,62057]
name: BigQueryGetDatasetOperator [62087,62113]
===
match
---
operator: , [61510,61511]
operator: , [61566,61567]
===
match
---
atom_expr [60395,60408]
atom_expr [60451,60464]
===
match
---
test [61049,61095]
test [61105,61151]
===
match
---
name: self [60952,60956]
name: self [61008,61012]
===
match
---
atom_expr [71114,71278]
atom_expr [71170,71334]
===
match
---
simple_stmt [17238,17278]
simple_stmt [17238,17278]
===
match
---
operator: , [47927,47928]
operator: , [47983,47984]
===
match
---
param [81351,81415]
param [81407,81471]
===
match
---
atom_expr [94909,94922]
atom_expr [94965,94978]
===
match
---
name: __init__ [12858,12866]
name: __init__ [12858,12866]
===
match
---
expr_stmt [95700,95746]
expr_stmt [95756,95802]
===
match
---
param [47604,47625]
param [47660,47681]
===
match
---
name: dataset_id [60109,60119]
name: dataset_id [60165,60175]
===
match
---
name: impersonation_chain [82370,82389]
name: impersonation_chain [82426,82445]
===
match
---
fstring_expr [97079,97092]
fstring_expr [97135,97148]
===
match
---
name: impersonation_chain [56926,56945]
name: impersonation_chain [56982,57001]
===
match
---
trailer [17750,17752]
trailer [17750,17752]
===
match
---
atom_expr [26888,26914]
atom_expr [26888,26914]
===
match
---
tfpdef [90244,90270]
tfpdef [90300,90326]
===
match
---
fstring_end: " [52095,52096]
fstring_end: " [52151,52152]
===
match
---
name: self [31053,31057]
name: self [31109,31113]
===
match
---
atom [94603,94684]
atom [94659,94740]
===
match
---
operator: = [97831,97832]
operator: = [97887,97888]
===
match
---
expr_stmt [25121,25271]
expr_stmt [25121,25271]
===
match
---
trailer [85145,85165]
trailer [85201,85221]
===
match
---
name: self [64508,64512]
name: self [64564,64568]
===
match
---
name: super [67386,67391]
name: super [67442,67447]
===
match
---
name: enum [882,886]
name: enum [882,886]
===
match
---
trailer [97049,97056]
trailer [97105,97112]
===
match
---
expr_stmt [67140,67168]
expr_stmt [67196,67224]
===
match
---
name: self [40979,40983]
name: self [41035,41039]
===
match
---
name: dataset_reference [61682,61699]
name: dataset_reference [61738,61755]
===
match
---
expr_stmt [29955,31075]
expr_stmt [30011,31131]
===
match
---
string: "externalDataConfiguration" [51601,51628]
string: "externalDataConfiguration" [51657,51684]
===
match
---
operator: = [29296,29297]
operator: = [29352,29353]
===
match
---
name: google_cloud_storage_conn_id [50475,50503]
name: google_cloud_storage_conn_id [50531,50559]
===
match
---
trailer [39972,40166]
trailer [40028,40222]
===
match
---
name: hook [96290,96294]
name: hook [96346,96350]
===
match
---
name: job_id [98636,98642]
name: job_id [98692,98698]
===
match
---
name: dataset_id [51992,52002]
name: dataset_id [52048,52058]
===
match
---
operator: , [91230,91231]
operator: , [91286,91287]
===
match
---
funcdef [98593,98831]
funcdef [98649,98887]
===
match
---
param [26407,26443]
param [26407,26443]
===
match
---
name: _DEPRECATION_MSG [7019,7035]
name: _DEPRECATION_MSG [7019,7035]
===
match
---
string: "dataset_resource" [69995,70013]
string: "dataset_resource" [70051,70069]
===
match
---
name: project_id [74395,74405]
name: project_id [74451,74461]
===
match
---
name: name [2569,2573]
name: name [2569,2573]
===
match
---
operator: , [26376,26377]
operator: , [26376,26377]
===
match
---
trailer [98079,98097]
trailer [98135,98153]
===
match
---
name: str [60461,60464]
name: str [60517,60520]
===
match
---
name: labels [30626,30632]
name: labels [30682,30688]
===
match
---
expr_stmt [18601,18778]
expr_stmt [18601,18778]
===
match
---
argument [51886,51912]
argument [51942,51968]
===
match
---
name: hook [28577,28581]
name: hook [28633,28637]
===
match
---
name: Iterable [25727,25735]
name: Iterable [25727,25735]
===
match
---
trailer [28728,28740]
trailer [28784,28796]
===
match
---
string: 'job_id' [31247,31255]
string: 'job_id' [31303,31311]
===
match
---
atom_expr [60985,61001]
atom_expr [61041,61057]
===
match
---
name: DATASET [60043,60050]
name: DATASET [60099,60106]
===
match
---
except_clause [61828,61843]
except_clause [61884,61899]
===
match
---
trailer [90837,90990]
trailer [90893,91046]
===
match
---
operator: -> [64239,64241]
operator: -> [64295,64297]
===
match
---
funcdef [2646,3054]
funcdef [2646,3054]
===
match
---
string: 'table_id' [17135,17145]
string: 'table_id' [17135,17145]
===
match
---
name: self [97668,97672]
name: self [97724,97728]
===
match
---
argument [61346,61374]
argument [61402,61430]
===
match
---
trailer [27735,27746]
trailer [27791,27802]
===
match
---
name: log [85896,85899]
name: log [85952,85955]
===
match
---
atom_expr [7123,7139]
atom_expr [7123,7139]
===
match
---
arglist [61925,61953]
arglist [61981,62009]
===
match
---
operator: , [48481,48482]
operator: , [48537,48538]
===
match
---
parameters [6554,6910]
parameters [6554,6910]
===
match
---
trailer [70292,70297]
trailer [70348,70353]
===
match
---
trailer [7234,7243]
trailer [7234,7243]
===
match
---
simple_stmt [47434,47474]
simple_stmt [47490,47530]
===
match
---
trailer [90696,90716]
trailer [90752,90772]
===
match
---
suite [3487,7339]
suite [3487,7339]
===
match
---
arglist [78492,78621]
arglist [78548,78677]
===
match
---
expr_stmt [27606,27644]
expr_stmt [27662,27700]
===
match
---
name: Conflict [97711,97719]
name: Conflict [97767,97775]
===
match
---
name: str [17689,17692]
name: str [17689,17692]
===
match
---
atom_expr [61439,61452]
atom_expr [61495,61508]
===
match
---
annassign [2528,2545]
annassign [2528,2545]
===
match
---
name: str [77916,77919]
name: str [77972,77975]
===
match
---
atom_expr [2899,2911]
atom_expr [2899,2911]
===
match
---
argument [49650,49662]
argument [49706,49718]
===
match
---
operator: } [60009,60010]
operator: } [60065,60066]
===
match
---
atom_expr [39226,39248]
atom_expr [39282,39304]
===
match
---
operator: = [13054,13055]
operator: = [13054,13055]
===
match
---
name: impersonation_chain [3329,3348]
name: impersonation_chain [3329,3348]
===
match
---
name: view [39567,39571]
name: view [39623,39627]
===
match
---
name: self [64580,64584]
name: self [64636,64640]
===
match
---
name: BIGQUERY_JOB_DETAILS_LINK_FMT [2310,2339]
name: BIGQUERY_JOB_DETAILS_LINK_FMT [2310,2339]
===
match
---
trailer [38387,38392]
trailer [38443,38448]
===
match
---
trailer [78107,78118]
trailer [78163,78174]
===
match
---
trailer [60454,60481]
trailer [60510,60537]
===
match
---
expr_stmt [77578,77634]
expr_stmt [77634,77690]
===
match
---
simple_stmt [70421,70590]
simple_stmt [70477,70646]
===
match
---
atom_expr [39438,39460]
atom_expr [39494,39516]
===
match
---
name: location [48451,48459]
name: location [48507,48515]
===
match
---
simple_stmt [40242,40306]
simple_stmt [40298,40362]
===
match
---
atom_expr [17660,17695]
atom_expr [17660,17695]
===
match
---
param [60425,60489]
param [60481,60545]
===
match
---
simple_stmt [96901,96960]
simple_stmt [96957,97016]
===
match
---
simple_stmt [28519,28560]
simple_stmt [28575,28616]
===
match
---
name: str [47809,47812]
name: str [47865,47868]
===
match
---
operator: = [98802,98803]
operator: = [98858,98859]
===
match
---
name: list_rows [18800,18809]
name: list_rows [18800,18809]
===
match
---
atom_expr [74090,74103]
atom_expr [74146,74159]
===
match
---
operator: , [28740,28741]
operator: , [28796,28797]
===
match
---
atom_expr [75057,75070]
atom_expr [75113,75126]
===
match
---
operator: , [37789,37790]
operator: , [37845,37846]
===
match
---
atom_expr [67386,67412]
atom_expr [67442,67468]
===
match
---
trailer [96819,96831]
trailer [96875,96887]
===
match
---
operator: , [29758,29759]
operator: , [29814,29815]
===
match
---
simple_stmt [10111,10148]
simple_stmt [10111,10148]
===
match
---
name: List [38338,38342]
name: List [38394,38398]
===
match
---
name: template_fields [12658,12673]
name: template_fields [12658,12673]
===
match
---
expr_stmt [28089,28131]
expr_stmt [28145,28187]
===
match
---
argument [74780,74808]
argument [74836,74864]
===
match
---
operator: { [84708,84709]
operator: { [84764,84765]
===
match
---
trailer [81810,81833]
trailer [81866,81889]
===
match
---
name: impersonation_chain [61148,61167]
name: impersonation_chain [61204,61223]
===
match
---
trailer [66771,66777]
trailer [66827,66833]
===
match
---
suite [96832,96875]
suite [96888,96931]
===
match
---
simple_stmt [63895,63937]
simple_stmt [63951,63993]
===
match
---
operator: , [9971,9972]
operator: , [9971,9972]
===
match
---
expr_stmt [7230,7254]
expr_stmt [7230,7254]
===
match
---
name: airflow [1236,1243]
name: airflow [1236,1243]
===
match
---
operator: = [30324,30325]
operator: = [30380,30381]
===
match
---
operator: , [51033,51034]
operator: , [51089,51090]
===
match
---
suite [90384,90774]
suite [90440,90830]
===
match
---
simple_stmt [27653,27684]
simple_stmt [27709,27740]
===
match
---
operator: , [78562,78563]
operator: , [78618,78619]
===
match
---
tfpdef [25746,25786]
tfpdef [25746,25786]
===
match
---
operator: , [78036,78037]
operator: , [78092,78093]
===
match
---
operator: , [40252,40253]
operator: , [40308,40309]
===
match
---
trailer [60919,60930]
trailer [60975,60986]
===
match
---
name: Sequence [13254,13262]
name: Sequence [13254,13262]
===
match
---
name: maximum_bytes_billed [29340,29360]
name: maximum_bytes_billed [29396,29416]
===
match
---
name: tuple [26378,26383]
name: tuple [26378,26383]
===
match
---
trailer [95659,95664]
trailer [95715,95720]
===
match
---
operator: = [47401,47402]
operator: = [47457,47458]
===
match
---
name: str [26300,26303]
name: str [26300,26303]
===
match
---
string: "The bigquery_conn_id parameter has been deprecated. You should pass " [26988,27058]
string: "The bigquery_conn_id parameter has been deprecated. You should pass " [26988,27058]
===
match
---
operator: = [82236,82237]
operator: = [82292,82293]
===
match
---
name: Union [95227,95232]
name: Union [95283,95288]
===
match
---
name: sql [28963,28966]
name: sql [29019,29022]
===
match
---
simple_stmt [28275,28332]
simple_stmt [28331,28388]
===
match
---
argument [28660,28694]
argument [28716,28750]
===
match
---
operator: , [66820,66821]
operator: , [66876,66877]
===
match
---
tfpdef [38809,38832]
tfpdef [38865,38888]
===
match
---
trailer [74641,74650]
trailer [74697,74706]
===
match
---
operator: = [51938,51939]
operator: = [51994,51995]
===
match
---
operator: = [40428,40429]
operator: = [40484,40485]
===
match
---
operator: , [29530,29531]
operator: , [29586,29587]
===
match
---
name: impersonation_chain [28823,28842]
name: impersonation_chain [28879,28898]
===
match
---
atom_expr [9675,9710]
atom_expr [9675,9710]
===
match
---
trailer [13302,13308]
trailer [13302,13308]
===
match
---
atom_expr [41373,41504]
atom_expr [41429,41560]
===
match
---
name: allow_quoted_newlines [52688,52709]
name: allow_quoted_newlines [52744,52765]
===
match
---
argument [39057,39065]
argument [39113,39121]
===
match
---
tfpdef [74078,74103]
tfpdef [74134,74159]
===
match
---
operator: , [48572,48573]
operator: , [48628,48629]
===
match
---
tfpdef [94897,94922]
tfpdef [94953,94978]
===
match
---
expr_stmt [94689,94714]
expr_stmt [94745,94770]
===
match
---
param [74684,74691]
param [74740,74747]
===
match
---
operator: , [38449,38450]
operator: , [38505,38506]
===
match
---
name: delegate_to [51260,51271]
name: delegate_to [51316,51327]
===
match
---
tfpdef [17639,17695]
tfpdef [17639,17695]
===
match
---
string: """     Creates a new, empty table in the specified BigQuery dataset,     optionally with schema.      The schema to be used for the BigQuery table may be specified in one of     two ways. You may either directly pass the schema fields in, or you may     point the operator to a Google Cloud Storage object name. The object in     Google Cloud Storage must be a JSON file with the schema fields in it.     You can also create a table without schema.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryCreateEmptyTableOperator`      :param project_id: The project to create the table into. (templated)     :type project_id: str     :param dataset_id: The dataset to create the table into. (templated)     :type dataset_id: str     :param table_id: The Name of the table to be created. (templated)     :type table_id: str     :param table_resource: Table resource as described in documentation:         https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#Table         If provided all other parameters are ignored.     :type table_resource: Dict[str, Any]     :param schema_fields: If set, the schema field list as defined here:         https://cloud.google.com/bigquery/docs/reference/rest/v2/jobs#configuration.load.schema          **Example**: ::              schema_fields=[{"name": "emp_name", "type": "STRING", "mode": "REQUIRED"},                            {"name": "salary", "type": "INTEGER", "mode": "NULLABLE"}]      :type schema_fields: list     :param gcs_schema_object: Full path to the JSON file containing         schema (templated). For         example: ``gs://test-bucket/dir1/dir2/employee_schema.json``     :type gcs_schema_object: str     :param time_partitioning: configure optional time partitioning fields i.e.         partition by field, type and  expiration as per API specifications.          .. seealso::             https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#timePartitioning     :type time_partitioning: dict     :param bigquery_conn_id: [Optional] The connection ID used to connect to Google Cloud and         interact with the Bigquery service.     :type bigquery_conn_id: str     :param google_cloud_storage_conn_id: [Optional] The connection ID used to connect to Google Cloud.         and interact with the Google Cloud Storage service.     :type google_cloud_storage_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param labels: a dictionary containing labels for the table, passed to BigQuery          **Example (with schema JSON in GCS)**: ::              CreateTable = BigQueryCreateEmptyTableOperator(                 task_id='BigQueryCreateEmptyTableOperator_task',                 dataset_id='ODS',                 table_id='Employees',                 project_id='internal-gcp-project',                 gcs_schema_object='gs://schema-bucket/employee_schema.json',                 bigquery_conn_id='airflow-conn-id',                 google_cloud_storage_conn_id='airflow-conn-id'             )          **Corresponding Schema file** (``employee_schema.json``): ::              [               {                 "mode": "NULLABLE",                 "name": "emp_name",                 "type": "STRING"               },               {                 "mode": "REQUIRED",                 "name": "salary",                 "type": "INTEGER"               }             ]          **Example (with schema in the DAG)**: ::              CreateTable = BigQueryCreateEmptyTableOperator(                 task_id='BigQueryCreateEmptyTableOperator_task',                 dataset_id='ODS',                 table_id='Employees',                 project_id='internal-gcp-project',                 schema_fields=[{"name": "emp_name", "type": "STRING", "mode": "REQUIRED"},                                {"name": "salary", "type": "INTEGER", "mode": "NULLABLE"}],                 bigquery_conn_id='airflow-conn-id-account',                 google_cloud_storage_conn_id='airflow-conn-id'             )     :type labels: dict     :param view: [Optional] A dictionary containing definition for the view.         If set, it will create a view instead of a table:          .. seealso::             https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#ViewDefinition     :type view: dict     :param materialized_view: [Optional] The materialized view definition.     :type materialized_view: dict     :param encryption_configuration: [Optional] Custom encryption configuration (e.g., Cloud KMS keys).         **Example**: ::              encryption_configuration = {                 "kmsKeyName": "projects/testp/locations/us/keyRings/test-kr/cryptoKeys/test-key"             }     :type encryption_configuration: dict     :param location: The location used for the operation.     :type location: str     :param cluster_fields: [Optional] The fields used for clustering.             BigQuery supports clustering for both partitioned and             non-partitioned tables.              .. seealso::                 https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#clustering.fields     :type cluster_fields: list     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     :param exists_ok: If ``True``, ignore "already exists" errors when creating the table.     :type exists_ok: bool     """ [31514,37723]
string: """     Creates a new, empty table in the specified BigQuery dataset,     optionally with schema.      The schema to be used for the BigQuery table may be specified in one of     two ways. You may either directly pass the schema fields in, or you may     point the operator to a Google Cloud Storage object name. The object in     Google Cloud Storage must be a JSON file with the schema fields in it.     You can also create a table without schema.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryCreateEmptyTableOperator`      :param project_id: The project to create the table into. (templated)     :type project_id: str     :param dataset_id: The dataset to create the table into. (templated)     :type dataset_id: str     :param table_id: The Name of the table to be created. (templated)     :type table_id: str     :param table_resource: Table resource as described in documentation:         https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#Table         If provided all other parameters are ignored.     :type table_resource: Dict[str, Any]     :param schema_fields: If set, the schema field list as defined here:         https://cloud.google.com/bigquery/docs/reference/rest/v2/jobs#configuration.load.schema          **Example**: ::              schema_fields=[{"name": "emp_name", "type": "STRING", "mode": "REQUIRED"},                            {"name": "salary", "type": "INTEGER", "mode": "NULLABLE"}]      :type schema_fields: list     :param gcs_schema_object: Full path to the JSON file containing         schema (templated). For         example: ``gs://test-bucket/dir1/dir2/employee_schema.json``     :type gcs_schema_object: str     :param time_partitioning: configure optional time partitioning fields i.e.         partition by field, type and  expiration as per API specifications.          .. seealso::             https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#timePartitioning     :type time_partitioning: dict     :param bigquery_conn_id: [Optional] The connection ID used to connect to Google Cloud and         interact with the Bigquery service.     :type bigquery_conn_id: str     :param google_cloud_storage_conn_id: [Optional] The connection ID used to connect to Google Cloud.         and interact with the Google Cloud Storage service.     :type google_cloud_storage_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param labels: a dictionary containing labels for the table, passed to BigQuery          **Example (with schema JSON in GCS)**: ::              CreateTable = BigQueryCreateEmptyTableOperator(                 task_id='BigQueryCreateEmptyTableOperator_task',                 dataset_id='ODS',                 table_id='Employees',                 project_id='internal-gcp-project',                 gcs_schema_object='gs://schema-bucket/employee_schema.json',                 bigquery_conn_id='airflow-conn-id',                 google_cloud_storage_conn_id='airflow-conn-id'             )          **Corresponding Schema file** (``employee_schema.json``): ::              [               {                 "mode": "NULLABLE",                 "name": "emp_name",                 "type": "STRING"               },               {                 "mode": "REQUIRED",                 "name": "salary",                 "type": "INTEGER"               }             ]          **Example (with schema in the DAG)**: ::              CreateTable = BigQueryCreateEmptyTableOperator(                 task_id='BigQueryCreateEmptyTableOperator_task',                 dataset_id='ODS',                 table_id='Employees',                 project_id='internal-gcp-project',                 schema_fields=[{"name": "emp_name", "type": "STRING", "mode": "REQUIRED"},                                {"name": "salary", "type": "INTEGER", "mode": "NULLABLE"}],                 bigquery_conn_id='airflow-conn-id-account',                 google_cloud_storage_conn_id='airflow-conn-id'             )     :type labels: dict     :param view: [Optional] A dictionary containing definition for the view.         If set, it will create a view instead of a table:          .. seealso::             https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#ViewDefinition     :type view: dict     :param materialized_view: [Optional] The materialized view definition.     :type materialized_view: dict     :param encryption_configuration: [Optional] Custom encryption configuration (e.g., Cloud KMS keys).         **Example**: ::              encryption_configuration = {                 "kmsKeyName": "projects/testp/locations/us/keyRings/test-kr/cryptoKeys/test-key"             }     :type encryption_configuration: dict     :param location: The location used for the operation.     :type location: str     :param cluster_fields: [Optional] The fields used for clustering.             BigQuery supports clustering for both partitioned and             non-partitioned tables.              .. seealso::                 https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#clustering.fields     :type cluster_fields: list     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     :param exists_ok: If ``True``, ignore "already exists" errors when creating the table.     :type exists_ok: bool     """ [31570,37779]
===
match
---
tfpdef [17556,17582]
tfpdef [17556,17582]
===
match
---
operator: , [85467,85468]
operator: , [85523,85524]
===
match
---
operator: , [25468,25469]
operator: , [25468,25469]
===
match
---
atom_expr [51394,51456]
atom_expr [51450,51512]
===
match
---
operator: , [9774,9775]
operator: , [9774,9775]
===
match
---
operator: = [39299,39300]
operator: = [39355,39356]
===
match
---
name: self [18255,18259]
name: self [18255,18259]
===
match
---
atom_expr [25580,25599]
atom_expr [25580,25599]
===
match
---
atom_expr [85723,85739]
atom_expr [85779,85795]
===
match
---
argument [64836,64862]
argument [64892,64918]
===
match
---
argument [2281,2293]
argument [2281,2293]
===
match
---
name: _parse_gcs_url [40267,40281]
name: _parse_gcs_url [40323,40337]
===
match
---
name: self [27927,27931]
name: self [27983,27987]
===
match
---
name: impersonation_chain [40111,40130]
name: impersonation_chain [40167,40186]
===
match
---
name: impersonation_chain [40136,40155]
name: impersonation_chain [40192,40211]
===
match
---
expr_stmt [67177,67205]
expr_stmt [67233,67261]
===
match
---
param [77954,77988]
param [78010,78044]
===
match
---
name: project_id [56760,56770]
name: project_id [56816,56826]
===
match
---
simple_stmt [60878,60907]
simple_stmt [60934,60963]
===
match
---
atom_expr [52710,52736]
atom_expr [52766,52792]
===
match
---
name: value [17272,17277]
name: value [17272,17277]
===
match
---
trailer [90129,90134]
trailer [90185,90190]
===
match
---
trailer [64851,64862]
trailer [64907,64918]
===
match
---
string: ".json" [94705,94712]
string: ".json" [94761,94768]
===
match
---
name: self [31429,31433]
name: self [31485,31489]
===
match
---
name: bigquery_conn_id [13088,13104]
name: bigquery_conn_id [13088,13104]
===
match
---
name: info [82134,82138]
name: info [82190,82194]
===
match
---
simple_stmt [1857,1897]
simple_stmt [1857,1897]
===
match
---
name: Optional [38284,38292]
name: Optional [38340,38348]
===
match
---
trailer [95560,95572]
trailer [95616,95628]
===
match
---
operator: = [86005,86006]
operator: = [86061,86062]
===
match
---
operator: ** [26855,26857]
operator: ** [26855,26857]
===
match
---
name: hook [82409,82413]
name: hook [82465,82469]
===
match
---
atom_expr [51897,51912]
atom_expr [51953,51968]
===
match
---
name: hook [28345,28349]
name: hook [28401,28405]
===
match
---
simple_stmt [60915,60944]
simple_stmt [60971,61000]
===
match
---
operator: , [94712,94713]
operator: , [94768,94769]
===
match
---
atom_expr [77783,77802]
atom_expr [77839,77858]
===
match
---
name: job_id [3046,3052]
name: job_id [3046,3052]
===
match
---
name: super [13358,13363]
name: super [13358,13363]
===
match
---
trailer [2731,2767]
trailer [2731,2767]
===
match
---
operator: = [74557,74558]
operator: = [74613,74614]
===
match
---
atom_expr [78857,78872]
atom_expr [78913,78928]
===
match
---
name: Union [25716,25721]
name: Union [25716,25721]
===
match
---
import_name [902,913]
import_name [902,913]
===
match
---
atom_expr [2536,2545]
atom_expr [2536,2545]
===
match
---
atom_expr [28724,28740]
atom_expr [28780,28796]
===
match
---
atom_expr [74390,74405]
atom_expr [74446,74461]
===
match
---
operator: = [18650,18651]
operator: = [18650,18651]
===
match
---
name: delegate_to [70271,70282]
name: delegate_to [70327,70338]
===
match
---
operator: = [61748,61749]
operator: = [61804,61805]
===
match
---
expr_stmt [97123,97172]
expr_stmt [97179,97228]
===
match
---
string: """     Upsert BigQuery table      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryUpsertTableOperator`      :param dataset_id: A dotted         ``(<project>.|<project>:)<dataset>`` that indicates which dataset         will be updated. (templated)     :type dataset_id: str     :param table_resource: a table resource. see         https://cloud.google.com/bigquery/docs/reference/v2/tables#resource     :type table_resource: dict     :param project_id: The name of the project where we want to update the dataset.         Don't need to provide, if projectId in dataset_reference.     :type project_id: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param delegate_to: The account to impersonate, if any.         For this to work, the service account making the request must have domain-wide         delegation enabled.     :type delegate_to: str     :param location: The location used for the operation.     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [82557,84565]
string: """     Upsert BigQuery table      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryUpsertTableOperator`      :param dataset_id: A dotted         ``(<project>.|<project>:)<dataset>`` that indicates which dataset         will be updated. (templated)     :type dataset_id: str     :param table_resource: a table resource. see         https://cloud.google.com/bigquery/docs/reference/v2/tables#resource     :type table_resource: dict     :param project_id: The name of the project where we want to update the dataset.         Don't need to provide, if projectId in dataset_reference.     :type project_id: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param delegate_to: The account to impersonate, if any.         For this to work, the service account making the request must have domain-wide         delegation enabled.     :type delegate_to: str     :param location: The location used for the operation.     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [82613,84621]
===
match
---
name: key [2826,2829]
name: key [2826,2829]
===
match
---
name: project_id [78806,78816]
name: project_id [78862,78872]
===
match
---
name: kwargs [48616,48622]
name: kwargs [48672,48678]
===
match
---
trailer [17577,17582]
trailer [17577,17582]
===
match
---
expr_stmt [27813,27861]
expr_stmt [27869,27917]
===
match
---
operator: = [64434,64435]
operator: = [64490,64491]
===
match
---
operator: , [95144,95145]
operator: , [95200,95201]
===
match
---
simple_stmt [78333,78380]
simple_stmt [78389,78436]
===
match
---
simple_stmt [49736,49825]
simple_stmt [49792,49881]
===
match
---
name: location [50704,50712]
name: location [50760,50768]
===
match
---
operator: = [78892,78893]
operator: = [78948,78949]
===
match
---
name: self [61486,61490]
name: self [61542,61546]
===
match
---
name: allow_large_results [27556,27575]
name: allow_large_results [27612,27631]
===
match
---
name: int [2530,2533]
name: int [2530,2533]
===
match
---
name: location [7235,7243]
name: location [7235,7243]
===
match
---
simple_stmt [50605,50626]
simple_stmt [50661,50682]
===
match
---
name: gcp_conn_id [90868,90879]
name: gcp_conn_id [90924,90935]
===
match
---
operator: , [56004,56005]
operator: , [56060,56061]
===
match
---
if_stmt [28866,31200]
if_stmt [28922,31256]
===
match
---
param [17508,17547]
param [17508,17547]
===
match
---
name: Optional [74235,74243]
name: Optional [74291,74299]
===
match
---
operator: , [13203,13204]
operator: , [13203,13204]
===
match
---
trailer [97283,97308]
trailer [97339,97364]
===
match
---
string: 'query_params' [25219,25233]
string: 'query_params' [25219,25233]
===
match
---
name: self [27692,27696]
name: self [27748,27752]
===
match
---
name: self [74678,74682]
name: self [74734,74738]
===
match
---
arglist [9816,9877]
arglist [9816,9877]
===
match
---
operator: = [78054,78055]
operator: = [78110,78111]
===
match
---
atom_expr [7162,7170]
atom_expr [7162,7170]
===
match
---
name: dataset_id [61638,61648]
name: dataset_id [61694,61704]
===
match
---
name: re [921,923]
name: re [921,923]
===
match
---
name: bq_hook [56781,56788]
name: bq_hook [56837,56844]
===
match
---
name: str [64001,64004]
name: str [64057,64060]
===
match
---
atom_expr [97571,97592]
atom_expr [97627,97648]
===
match
---
trailer [9815,9878]
trailer [9815,9878]
===
match
---
name: sql [7173,7176]
name: sql [7173,7176]
===
match
---
operator: = [30978,30979]
operator: = [31034,31035]
===
match
---
name: dataset_id [78121,78131]
name: dataset_id [78177,78187]
===
match
---
name: maximum_billing_tier [30362,30382]
name: maximum_billing_tier [30418,30438]
===
match
---
trailer [64128,64133]
trailer [64184,64189]
===
match
---
name: job_id [94979,94985]
name: job_id [95035,95041]
===
match
---
simple_stmt [51581,51656]
simple_stmt [51637,51712]
===
match
---
atom_expr [51581,51639]
atom_expr [51637,51695]
===
match
---
name: gcp_conn_id [74461,74472]
name: gcp_conn_id [74517,74528]
===
match
---
simple_stmt [50732,50779]
simple_stmt [50788,50835]
===
match
---
trailer [25564,25567]
trailer [25564,25567]
===
match
---
operator: = [7288,7289]
operator: = [7288,7289]
===
match
---
atom_expr [51084,51102]
atom_expr [51140,51158]
===
match
---
name: self [10211,10215]
name: self [10211,10215]
===
match
---
operator: { [96750,96751]
operator: { [96806,96807]
===
match
---
name: delegate_to [95575,95586]
name: delegate_to [95631,95642]
===
match
---
expr_stmt [28397,28443]
expr_stmt [28453,28499]
===
match
---
name: self [95556,95560]
name: self [95612,95616]
===
match
---
name: self [13845,13849]
name: self [13845,13849]
===
match
---
tfpdef [48196,48229]
tfpdef [48252,48285]
===
match
---
operator: -> [6911,6913]
operator: -> [6911,6913]
===
match
---
operator: , [56736,56737]
operator: , [56792,56793]
===
match
---
name: Union [9684,9689]
name: Union [9684,9689]
===
match
---
argument [41139,41179]
argument [41195,41235]
===
match
---
atom_expr [2914,2924]
atom_expr [2914,2924]
===
match
---
operator: = [97360,97361]
operator: = [97416,97417]
===
match
---
operator: , [9867,9868]
operator: , [9867,9868]
===
match
---
name: self [52927,52931]
name: self [52983,52987]
===
match
---
and_test [95952,96028]
and_test [96008,96084]
===
match
---
operator: = [94786,94787]
operator: = [94842,94843]
===
match
---
name: self [82279,82283]
name: self [82335,82339]
===
match
---
operator: = [6727,6728]
operator: = [6727,6728]
===
match
---
atom_expr [86268,86283]
atom_expr [86324,86339]
===
match
---
name: delegate_to [77954,77965]
name: delegate_to [78010,78021]
===
match
---
operator: = [29790,29791]
operator: = [29846,29847]
===
match
---
simple_stmt [13972,17080]
simple_stmt [13972,17080]
===
match
---
trailer [19038,19042]
trailer [19038,19042]
===
match
---
name: str [9690,9693]
name: str [9690,9693]
===
match
---
atom_expr [64191,64204]
atom_expr [64247,64260]
===
match
---
testlist_comp [12686,12798]
testlist_comp [12686,12798]
===
match
---
name: sql [29927,29930]
name: sql [29983,29986]
===
match
---
atom_expr [28880,28888]
atom_expr [28936,28944]
===
match
---
name: self [70799,70803]
name: self [70855,70859]
===
match
---
operator: , [52002,52003]
operator: , [52058,52059]
===
match
---
name: context [97332,97339]
name: context [97388,97395]
===
match
---
argument [13388,13399]
argument [13388,13399]
===
match
---
argument [86297,86331]
argument [86353,86387]
===
match
---
simple_stmt [50279,50330]
simple_stmt [50335,50386]
===
match
---
name: self [18911,18915]
name: self [18911,18915]
===
match
---
operator: = [74791,74792]
operator: = [74847,74848]
===
match
---
simple_stmt [84739,84779]
simple_stmt [84795,84835]
===
match
---
tfpdef [47937,47957]
tfpdef [47993,48013]
===
match
---
trailer [6761,6766]
trailer [6761,6766]
===
match
---
atom_expr [48277,48290]
atom_expr [48333,48346]
===
match
---
atom_expr [40979,41001]
atom_expr [41035,41057]
===
match
---
operator: , [40943,40944]
operator: , [40999,41000]
===
match
---
name: google [1138,1144]
name: google [1138,1144]
===
match
---
atom_expr [56080,56307]
atom_expr [56136,56363]
===
match
---
name: job [97691,97694]
name: job [97747,97750]
===
match
---
atom_expr [29010,29040]
atom_expr [29066,29096]
===
match
---
expr_stmt [84571,84675]
expr_stmt [84627,84731]
===
match
---
suite [56067,56351]
suite [56123,56407]
===
match
---
name: materialized_view [41162,41179]
name: materialized_view [41218,41235]
===
match
---
expr_stmt [27447,27489]
expr_stmt [27503,27545]
===
match
---
name: bool [25930,25934]
name: bool [25930,25934]
===
match
---
name: selected_fields [18231,18246]
name: selected_fields [18231,18246]
===
match
---
name: gcp_conn_id [64056,64067]
name: gcp_conn_id [64112,64123]
===
match
---
trailer [17761,17771]
trailer [17761,17771]
===
match
---
trailer [89995,90005]
trailer [90051,90061]
===
match
---
name: gcs_schema_object [39251,39268]
name: gcs_schema_object [39307,39324]
===
match
---
simple_stmt [27692,27723]
simple_stmt [27748,27779]
===
match
---
operator: , [49232,49233]
operator: , [49288,49289]
===
match
---
operator: ** [13325,13327]
operator: ** [13325,13327]
===
match
---
name: self [98777,98781]
name: self [98833,98837]
===
match
---
operator: = [49981,49982]
operator: = [50037,50038]
===
match
---
operator: , [82153,82154]
operator: , [82209,82210]
===
match
---
simple_stmt [56615,56642]
simple_stmt [56671,56698]
===
match
---
suite [29942,31076]
suite [29998,31132]
===
match
---
operator: = [77648,77649]
operator: = [77704,77705]
===
match
---
name: bool [48077,48081]
name: bool [48133,48137]
===
match
---
expr_stmt [69861,69961]
expr_stmt [69917,70017]
===
match
---
atom_expr [50962,50975]
atom_expr [51018,51031]
===
match
---
name: location [86136,86144]
name: location [86192,86200]
===
match
---
name: location [60243,60251]
name: location [60299,60307]
===
match
---
name: self [49879,49883]
name: self [49935,49939]
===
match
---
operator: = [18347,18348]
operator: = [18347,18348]
===
match
---
return_stmt [97270,97308]
return_stmt [97326,97364]
===
match
---
name: log [56696,56699]
name: log [56752,56755]
===
match
---
and_test [51530,51567]
and_test [51586,51623]
===
match
---
string: "This operator is deprecated. Please use `BigQueryInsertJobOperator`." [27234,27304]
string: "This operator is deprecated. Please use `BigQueryInsertJobOperator`." [27264,27334]
===
match
---
expr_stmt [95755,95791]
expr_stmt [95811,95847]
===
match
---
name: table_id [82427,82435]
name: table_id [82483,82491]
===
match
---
funcdef [64496,64929]
funcdef [64552,64985]
===
match
---
name: Optional [94909,94917]
name: Optional [94965,94973]
===
match
---
name: log [82130,82133]
name: log [82186,82189]
===
match
---
argument [18941,18977]
argument [18941,18977]
===
match
---
trailer [95422,95431]
trailer [95478,95487]
===
match
---
simple_stmt [10211,10232]
simple_stmt [10211,10232]
===
match
---
string: 'Deleting: %s' [82139,82153]
string: 'Deleting: %s' [82195,82209]
===
match
---
expr_stmt [80999,81038]
expr_stmt [81055,81094]
===
match
---
dotted_name [1236,1250]
dotted_name [1236,1250]
===
match
---
operator: = [17623,17624]
operator: = [17623,17624]
===
match
---
trailer [48520,48547]
trailer [48576,48603]
===
match
---
trailer [94810,94816]
trailer [94866,94872]
===
match
---
operator: , [40155,40156]
operator: , [40211,40212]
===
match
---
string: """     Creates a new external table in the dataset with the data from Google Cloud     Storage.      The schema to be used for the BigQuery table may be specified in one of     two ways. You may either directly pass the schema fields in, or you may     point the operator to a Google Cloud Storage object name. The object in     Google Cloud Storage must be a JSON file with the schema fields in it.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryCreateExternalTableOperator`      :param bucket: The bucket to point the external table to. (templated)     :type bucket: str     :param source_objects: List of Google Cloud Storage URIs to point         table to. If source_format is 'DATASTORE_BACKUP', the list must only contain a single URI.     :type source_objects: list     :param destination_project_dataset_table: The dotted ``(<project>.)<dataset>.<table>``         BigQuery table to load data into (templated). If ``<project>`` is not included,         project will be the project defined in the connection json.     :type destination_project_dataset_table: str     :param schema_fields: If set, the schema field list as defined here:         https://cloud.google.com/bigquery/docs/reference/rest/v2/jobs#configuration.load.schema          **Example**: ::              schema_fields=[{"name": "emp_name", "type": "STRING", "mode": "REQUIRED"},                            {"name": "salary", "type": "INTEGER", "mode": "NULLABLE"}]          Should not be set when source_format is 'DATASTORE_BACKUP'.     :param table_resource: Table resource as described in documentation:         https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#Table         If provided all other parameters are ignored. External schema from object will be resolved.     :type table_resource: Dict[str, Any]     :type schema_fields: list     :param schema_object: If set, a GCS object path pointing to a .json file that         contains the schema for the table. (templated)     :type schema_object: str     :param source_format: File format of the data.     :type source_format: str     :param compression: [Optional] The compression type of the data source.         Possible values include GZIP and NONE.         The default value is NONE.         This setting is ignored for Google Cloud Bigtable,         Google Cloud Datastore backups and Avro formats.     :type compression: str     :param skip_leading_rows: Number of rows to skip when loading from a CSV.     :type skip_leading_rows: int     :param field_delimiter: The delimiter to use for the CSV.     :type field_delimiter: str     :param max_bad_records: The maximum number of bad records that BigQuery can         ignore when running the job.     :type max_bad_records: int     :param quote_character: The value that is used to quote data sections in a CSV file.     :type quote_character: str     :param allow_quoted_newlines: Whether to allow quoted newlines (true) or not (false).     :type allow_quoted_newlines: bool     :param allow_jagged_rows: Accept rows that are missing trailing optional columns.         The missing values are treated as nulls. If false, records with missing trailing         columns are treated as bad records, and if there are too many bad records, an         invalid error is returned in the job result. Only applicable to CSV, ignored         for other formats.     :type allow_jagged_rows: bool     :param bigquery_conn_id: (Optional) The connection ID used to connect to Google Cloud and         interact with the Bigquery service.     :type bigquery_conn_id: str     :param google_cloud_storage_conn_id: (Optional) The connection ID used to connect to Google Cloud         and interact with the Google Cloud Storage service.     :type google_cloud_storage_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param src_fmt_configs: configure optional fields specific to the source format     :type src_fmt_configs: dict     :param labels: a dictionary containing labels for the table, passed to BigQuery     :type labels: dict     :param encryption_configuration: [Optional] Custom encryption configuration (e.g., Cloud KMS keys).         **Example**: ::              encryption_configuration = {                 "kmsKeyName": "projects/testp/locations/us/keyRings/test-kr/cryptoKeys/test-key"             }     :type encryption_configuration: dict     :param location: The location used for the operation.     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [41729,47150]
string: """     Creates a new external table in the dataset with the data from Google Cloud     Storage.      The schema to be used for the BigQuery table may be specified in one of     two ways. You may either directly pass the schema fields in, or you may     point the operator to a Google Cloud Storage object name. The object in     Google Cloud Storage must be a JSON file with the schema fields in it.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryCreateExternalTableOperator`      :param bucket: The bucket to point the external table to. (templated)     :type bucket: str     :param source_objects: List of Google Cloud Storage URIs to point         table to. If source_format is 'DATASTORE_BACKUP', the list must only contain a single URI.     :type source_objects: list     :param destination_project_dataset_table: The dotted ``(<project>.)<dataset>.<table>``         BigQuery table to load data into (templated). If ``<project>`` is not included,         project will be the project defined in the connection json.     :type destination_project_dataset_table: str     :param schema_fields: If set, the schema field list as defined here:         https://cloud.google.com/bigquery/docs/reference/rest/v2/jobs#configuration.load.schema          **Example**: ::              schema_fields=[{"name": "emp_name", "type": "STRING", "mode": "REQUIRED"},                            {"name": "salary", "type": "INTEGER", "mode": "NULLABLE"}]          Should not be set when source_format is 'DATASTORE_BACKUP'.     :param table_resource: Table resource as described in documentation:         https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#Table         If provided all other parameters are ignored. External schema from object will be resolved.     :type table_resource: Dict[str, Any]     :type schema_fields: list     :param schema_object: If set, a GCS object path pointing to a .json file that         contains the schema for the table. (templated)     :type schema_object: str     :param source_format: File format of the data.     :type source_format: str     :param compression: [Optional] The compression type of the data source.         Possible values include GZIP and NONE.         The default value is NONE.         This setting is ignored for Google Cloud Bigtable,         Google Cloud Datastore backups and Avro formats.     :type compression: str     :param skip_leading_rows: Number of rows to skip when loading from a CSV.     :type skip_leading_rows: int     :param field_delimiter: The delimiter to use for the CSV.     :type field_delimiter: str     :param max_bad_records: The maximum number of bad records that BigQuery can         ignore when running the job.     :type max_bad_records: int     :param quote_character: The value that is used to quote data sections in a CSV file.     :type quote_character: str     :param allow_quoted_newlines: Whether to allow quoted newlines (true) or not (false).     :type allow_quoted_newlines: bool     :param allow_jagged_rows: Accept rows that are missing trailing optional columns.         The missing values are treated as nulls. If false, records with missing trailing         columns are treated as bad records, and if there are too many bad records, an         invalid error is returned in the job result. Only applicable to CSV, ignored         for other formats.     :type allow_jagged_rows: bool     :param bigquery_conn_id: (Optional) The connection ID used to connect to Google Cloud and         interact with the Bigquery service.     :type bigquery_conn_id: str     :param google_cloud_storage_conn_id: (Optional) The connection ID used to connect to Google Cloud         and interact with the Google Cloud Storage service.     :type google_cloud_storage_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param src_fmt_configs: configure optional fields specific to the source format     :type src_fmt_configs: dict     :param labels: a dictionary containing labels for the table, passed to BigQuery     :type labels: dict     :param encryption_configuration: [Optional] Custom encryption configuration (e.g., Cloud KMS keys).         **Example**: ::              encryption_configuration = {                 "kmsKeyName": "projects/testp/locations/us/keyRings/test-kr/cryptoKeys/test-key"             }     :type encryption_configuration: dict     :param location: The location used for the operation.     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [41785,47206]
===
match
---
operator: , [26383,26384]
operator: , [26383,26384]
===
match
---
name: bigquery_conn_id [17508,17524]
name: bigquery_conn_id [17508,17524]
===
match
---
trailer [67741,67752]
trailer [67797,67808]
===
match
---
atom_expr [57041,57056]
atom_expr [57097,57112]
===
match
---
name: template_fields_renderers [37946,37971]
name: template_fields_renderers [38002,38027]
===
match
---
name: self [64672,64676]
name: self [64728,64732]
===
match
---
name: dataset_id [64852,64862]
name: dataset_id [64908,64918]
===
match
---
tfpdef [38626,38648]
tfpdef [38682,38704]
===
match
---
atom_expr [29570,29596]
atom_expr [29626,29652]
===
match
---
trailer [6935,6944]
trailer [6935,6944]
===
match
---
suite [57162,62023]
suite [57218,62079]
===
match
---
name: project_id [39094,39104]
name: project_id [39150,39160]
===
match
---
string: 'impersonation_chain' [66703,66724]
string: 'impersonation_chain' [66759,66780]
===
match
---
name: encryption_configuration [29858,29882]
name: encryption_configuration [29914,29938]
===
match
---
arglist [67686,67795]
arglist [67742,67851]
===
match
---
name: self [52067,52071]
name: self [52123,52127]
===
match
---
trailer [52832,52848]
trailer [52888,52904]
===
match
---
name: table_id [74373,74381]
name: table_id [74429,74437]
===
match
---
name: _DEPRECATION_MSG [9935,9951]
name: _DEPRECATION_MSG [9935,9951]
===
match
---
operator: , [56845,56846]
operator: , [56901,56902]
===
match
---
name: self [12876,12880]
name: self [12876,12880]
===
match
---
operator: = [50573,50574]
operator: = [50629,50630]
===
match
---
operator: , [9604,9605]
operator: , [9604,9605]
===
match
---
operator: , [73891,73892]
operator: , [73947,73948]
===
match
---
atom_expr [78027,78052]
atom_expr [78083,78108]
===
match
---
name: exists_ok [60498,60507]
name: exists_ok [60554,60563]
===
match
---
trailer [96871,96873]
trailer [96927,96929]
===
match
---
operator: = [66924,66925]
operator: = [66980,66981]
===
match
---
operator: , [51434,51435]
operator: , [51490,51491]
===
match
---
atom_expr [97874,97887]
atom_expr [97930,97943]
===
match
---
simple_stmt [2523,2546]
simple_stmt [2523,2546]
===
match
---
operator: = [26078,26079]
operator: = [26078,26079]
===
match
---
name: exists_ok [61215,61224]
name: exists_ok [61271,61280]
===
match
---
operator: , [70395,70396]
operator: , [70451,70452]
===
match
---
trailer [40187,40201]
trailer [40243,40257]
===
match
---
name: BigQueryHook [64542,64554]
name: BigQueryHook [64598,64610]
===
match
---
number: 3 [13673,13674]
number: 3 [13673,13674]
===
match
---
atom_expr [51423,51434]
atom_expr [51479,51490]
===
match
---
name: str [6762,6765]
name: str [6762,6765]
===
match
---
operator: , [97887,97888]
operator: , [97943,97944]
===
match
---
suite [78094,78415]
suite [78150,78471]
===
match
---
operator: , [60183,60184]
operator: , [60239,60240]
===
match
---
param [9727,9757]
param [9727,9757]
===
match
---
atom_expr [81457,81483]
atom_expr [81513,81539]
===
match
---
argument [13464,13501]
argument [13464,13501]
===
match
---
expr_stmt [73820,73859]
expr_stmt [73876,73915]
===
match
---
name: gcp_conn_id [67272,67283]
name: gcp_conn_id [67328,67339]
===
match
---
name: self [67292,67296]
name: self [67348,67352]
===
match
---
param [56014,56023]
param [56070,56079]
===
match
---
atom_expr [25316,25344]
atom_expr [25316,25344]
===
match
---
name: str [85146,85149]
name: str [85202,85205]
===
match
---
atom [19109,19139]
atom [19109,19139]
===
match
---
name: _BigQueryDbHookMixin [7374,7394]
name: _BigQueryDbHookMixin [7374,7394]
===
match
---
trailer [95967,95981]
trailer [96023,96037]
===
match
---
name: isoformat [97161,97170]
name: isoformat [97217,97226]
===
match
---
name: self [90507,90511]
name: self [90563,90567]
===
match
---
trailer [18475,18591]
trailer [18475,18591]
===
match
---
trailer [40336,40522]
trailer [40392,40578]
===
match
---
name: self [56360,56364]
name: self [56416,56420]
===
match
---
simple_stmt [82029,82076]
simple_stmt [82085,82132]
===
match
---
name: exists_ok [39891,39900]
name: exists_ok [39947,39956]
===
match
---
name: dataset_id [41464,41474]
name: dataset_id [41520,41530]
===
match
---
name: job [96730,96733]
name: job [96786,96789]
===
match
---
atom_expr [49962,49980]
atom_expr [50018,50036]
===
match
---
name: self [90452,90456]
name: self [90508,90512]
===
match
---
suite [2161,2380]
suite [2161,2380]
===
match
---
operator: , [97458,97459]
operator: , [97514,97515]
===
match
---
atom_expr [96047,96071]
atom_expr [96103,96127]
===
match
---
classdef [75124,78948]
classdef [75180,79004]
===
match
---
name: self [39998,40002]
name: self [40054,40058]
===
match
---
operator: , [64778,64779]
operator: , [64834,64835]
===
match
---
atom_expr [90507,90520]
atom_expr [90563,90576]
===
match
---
trailer [71135,71278]
trailer [71191,71334]
===
match
---
operator: = [2736,2737]
operator: = [2736,2737]
===
match
---
name: self [27768,27772]
name: self [27824,27828]
===
match
---
trailer [40561,40604]
trailer [40617,40660]
===
match
---
operator: , [25793,25794]
operator: , [25793,25794]
===
match
---
name: cluster_fields [29776,29790]
name: cluster_fields [29832,29846]
===
match
---
name: str [48541,48544]
name: str [48597,48600]
===
match
---
atom_expr [39526,39537]
atom_expr [39582,39593]
===
match
---
name: location [39701,39709]
name: location [39757,39765]
===
match
---
expr_stmt [2095,2120]
expr_stmt [2095,2120]
===
match
---
param [95867,95871]
param [95923,95927]
===
match
---
name: location [85070,85078]
name: location [85126,85134]
===
match
---
name: get_dataset [64824,64835]
name: get_dataset [64880,64891]
===
match
---
name: self [85723,85727]
name: self [85779,85783]
===
match
---
operator: , [52268,52269]
operator: , [52324,52325]
===
match
---
argument [18899,18927]
argument [18899,18927]
===
match
---
name: table_id [91208,91216]
name: table_id [91264,91272]
===
match
---
name: self [56434,56438]
name: self [56490,56494]
===
match
---
operator: = [27954,27955]
operator: = [28010,28011]
===
match
---
name: super [64464,64469]
name: super [64520,64525]
===
match
---
operator: , [63979,63980]
operator: , [64035,64036]
===
match
---
name: BigQueryUIColors [66747,66763]
name: BigQueryUIColors [66803,66819]
===
match
---
atom_expr [40282,40304]
atom_expr [40338,40360]
===
match
---
atom_expr [29519,29530]
atom_expr [29575,29586]
===
match
---
trailer [60989,61001]
trailer [61045,61057]
===
match
---
name: self [60084,60088]
name: self [60140,60144]
===
match
---
trailer [90265,90270]
trailer [90321,90326]
===
match
---
param [73887,73892]
param [73943,73948]
===
match
---
expr_stmt [97355,97527]
expr_stmt [97411,97583]
===
match
---
operator: = [61789,61790]
operator: = [61845,61846]
===
match
---
trailer [55626,55634]
trailer [55682,55690]
===
match
---
expr_stmt [28242,28266]
expr_stmt [28298,28322]
===
match
---
trailer [98684,98689]
trailer [98740,98745]
===
match
---
name: str [78033,78036]
name: str [78089,78092]
===
match
---
operator: = [28817,28818]
operator: = [28873,28874]
===
match
---
name: self [39729,39733]
name: self [39785,39789]
===
match
---
param [64508,64513]
param [64564,64569]
===
match
---
name: self [50634,50638]
name: self [50690,50694]
===
match
---
simple_stmt [56481,56512]
simple_stmt [56537,56568]
===
match
---
string: 'CSV' [47851,47856]
string: 'CSV' [47907,47912]
===
match
---
argument [13515,13534]
argument [13515,13534]
===
match
---
simple_stmt [81766,81797]
simple_stmt [81822,81853]
===
match
---
atom_expr [30272,30292]
atom_expr [30328,30348]
===
match
---
trailer [81473,81483]
trailer [81529,81539]
===
match
---
operator: = [67462,67463]
operator: = [67518,67519]
===
match
---
trailer [26365,26390]
trailer [26365,26390]
===
match
---
tfpdef [48054,48081]
tfpdef [48110,48137]
===
match
---
trailer [85899,85904]
trailer [85955,85960]
===
match
---
operator: = [18833,18834]
operator: = [18833,18834]
===
match
---
name: self [56921,56925]
name: self [56977,56981]
===
match
---
atom_expr [13243,13268]
atom_expr [13243,13268]
===
match
---
import_name [914,923]
import_name [914,923]
===
match
---
expr_stmt [73636,73756]
expr_stmt [73692,73812]
===
match
---
tfpdef [47866,47882]
tfpdef [47922,47938]
===
match
---
name: project_id [94897,94907]
name: project_id [94953,94963]
===
match
---
arglist [39986,40156]
arglist [40042,40212]
===
match
---
decorator [2551,2561]
decorator [2551,2561]
===
match
---
name: table [13388,13393]
name: table [13388,13393]
===
match
---
atom [25535,25600]
atom [25535,25600]
===
match
---
name: row [19110,19113]
name: row [19110,19113]
===
match
---
operator: = [28625,28626]
operator: = [28681,28682]
===
match
---
operator: = [85537,85538]
operator: = [85593,85594]
===
match
---
string: 'sql2' [12742,12748]
string: 'sql2' [12742,12748]
===
match
---
name: gcp_conn_id [81128,81139]
name: gcp_conn_id [81184,81195]
===
match
---
number: 3 [18025,18026]
number: 3 [18025,18026]
===
match
---
trailer [38950,38955]
trailer [39006,39011]
===
match
---
atom_expr [10111,10130]
atom_expr [10111,10130]
===
match
---
atom_expr [52067,52078]
atom_expr [52123,52134]
===
match
---
comparison [97949,97982]
comparison [98005,98038]
===
match
---
atom [1711,1815]
atom [1711,1815]
===
match
---
atom [25495,25519]
atom [25495,25519]
===
match
---
trailer [81380,81407]
trailer [81436,81463]
===
match
---
trailer [18809,19024]
trailer [18809,19024]
===
match
---
param [18430,18435]
param [18430,18435]
===
match
---
string: 'google_cloud_default' [6626,6648]
string: 'google_cloud_default' [6626,6648]
===
match
---
name: Optional [25921,25929]
name: Optional [25921,25929]
===
match
---
trailer [70803,70823]
trailer [70859,70879]
===
match
---
simple_stmt [64370,64401]
simple_stmt [64426,64457]
===
match
---
name: allow_jagged_rows [50363,50380]
name: allow_jagged_rows [50419,50436]
===
match
---
name: self [95595,95599]
name: self [95651,95655]
===
match
---
trailer [25338,25344]
trailer [25338,25344]
===
match
---
arglist [27234,27337]
arglist [27264,27393]
===
match
---
name: self [39526,39530]
name: self [39582,39586]
===
match
---
name: impersonation_chain [13872,13891]
name: impersonation_chain [13872,13891]
===
match
---
name: loads [40556,40561]
name: loads [40612,40617]
===
match
---
name: warnings [26957,26965]
name: warnings [26957,26965]
===
match
---
trailer [2628,2634]
trailer [2628,2634]
===
match
---
atom_expr [25921,25935]
atom_expr [25921,25935]
===
match
---
operator: , [9567,9568]
operator: , [9567,9568]
===
match
---
fstring_expr [2623,2639]
fstring_expr [2623,2639]
===
match
---
atom_expr [18565,18581]
atom_expr [18565,18581]
===
match
---
name: list [26372,26376]
name: list [26372,26376]
===
match
---
operator: = [18910,18911]
operator: = [18910,18911]
===
match
---
name: ignore_if_missing [82483,82500]
name: ignore_if_missing [82539,82556]
===
match
---
classdef [67808,71279]
classdef [67864,71335]
===
match
---
atom_expr [52434,52450]
atom_expr [52490,52506]
===
match
---
operator: , [3231,3232]
operator: , [3231,3232]
===
match
---
param [48451,48482]
param [48507,48538]
===
match
---
name: bigquery_conn_id [6658,6674]
name: bigquery_conn_id [6658,6674]
===
match
---
fstring_string: / [52079,52080]
fstring_string: / [52135,52136]
===
match
---
parameters [70897,70912]
parameters [70953,70968]
===
match
---
atom_expr [18911,18927]
atom_expr [18911,18927]
===
match
---
name: allow_quoted_newlines [49119,49140]
name: allow_quoted_newlines [49175,49196]
===
match
---
trailer [26895,26904]
trailer [26895,26904]
===
match
---
fstring [52059,52096]
fstring [52115,52152]
===
match
---
operator: , [91270,91271]
operator: , [91326,91327]
===
match
---
atom_expr [67253,67269]
atom_expr [67309,67325]
===
match
---
string: 'Fetching Data from %s.%s max results: %s' [18489,18531]
string: 'Fetching Data from %s.%s max results: %s' [18489,18531]
===
match
---
name: result [96550,96556]
name: result [96606,96612]
===
match
---
simple_stmt [39819,39866]
simple_stmt [39875,39922]
===
match
---
name: index [2919,2924]
name: index [2919,2924]
===
match
---
if_stmt [96812,96960]
if_stmt [96868,97016]
===
match
---
trailer [85688,85700]
trailer [85744,85756]
===
match
---
name: dataset_id [85570,85580]
name: dataset_id [85626,85636]
===
match
---
atom_expr [98477,98486]
atom_expr [98533,98542]
===
match
---
operator: = [39461,39462]
operator: = [39517,39518]
===
match
---
operator: = [47883,47884]
operator: = [47939,47940]
===
match
---
operator: , [60488,60489]
operator: , [60544,60545]
===
match
---
name: self [74357,74361]
name: self [74413,74417]
===
match
---
atom_expr [10156,10180]
atom_expr [10156,10180]
===
match
---
atom_expr [6824,6837]
atom_expr [6824,6837]
===
match
---
simple_stmt [74320,74349]
simple_stmt [74376,74405]
===
match
---
operator: = [7171,7172]
operator: = [7171,7172]
===
match
---
simple_stmt [77578,77635]
simple_stmt [77634,77691]
===
match
---
trailer [85159,85164]
trailer [85215,85220]
===
match
---
subscriptlist [64186,64204]
subscriptlist [64242,64260]
===
match
---
operator: , [47715,47716]
operator: , [47771,47772]
===
match
---
operator: , [95093,95094]
operator: , [95149,95150]
===
match
---
atom_expr [85684,85700]
atom_expr [85740,85756]
===
match
---
name: str [9491,9494]
name: str [9491,9494]
===
match
---
operator: = [82317,82318]
operator: = [82373,82374]
===
match
---
atom_expr [60253,60266]
atom_expr [60309,60322]
===
match
---
atom_expr [51738,51776]
atom_expr [51794,51832]
===
match
---
trailer [28532,28559]
trailer [28588,28615]
===
match
---
name: time_partitioning [26530,26547]
name: time_partitioning [26530,26547]
===
match
---
suite [90806,91282]
suite [90862,91338]
===
match
---
param [6895,6904]
param [6895,6904]
===
match
---
simple_stmt [31311,31329]
simple_stmt [31367,31385]
===
match
---
trailer [60042,60050]
trailer [60098,60106]
===
match
---
name: BigQueryHook [56791,56803]
name: BigQueryHook [56847,56859]
===
match
---
name: context [85865,85872]
name: context [85921,85928]
===
match
---
name: ui_color [80999,81007]
name: ui_color [81055,81063]
===
match
---
atom_expr [95811,95833]
atom_expr [95867,95889]
===
match
---
param [48054,48090]
param [48110,48146]
===
match
---
atom_expr [84997,85010]
atom_expr [85053,85066]
===
match
---
name: table_id [18863,18871]
name: table_id [18863,18871]
===
match
---
expr_stmt [39076,39104]
expr_stmt [39132,39160]
===
match
---
trailer [6530,6536]
trailer [6530,6536]
===
match
---
param [47973,47998]
param [48029,48054]
===
match
---
operator: = [52709,52710]
operator: = [52765,52766]
===
match
---
simple_stmt [952,982]
simple_stmt [952,982]
===
match
---
operator: , [70210,70211]
operator: , [70266,70267]
===
match
---
strings [98245,98509]
strings [98301,98565]
===
match
---
name: Optional [26106,26114]
name: Optional [26106,26114]
===
match
---
suite [96649,96771]
suite [96705,96827]
===
match
---
operator: , [67024,67025]
operator: , [67080,67081]
===
match
---
param [26685,26716]
param [26685,26716]
===
match
---
param [38167,38183]
param [38223,38239]
===
match
---
name: bq_hook [61310,61317]
name: bq_hook [61366,61373]
===
match
---
operator: , [77566,77567]
operator: , [77622,77623]
===
match
---
arglist [30023,31009]
arglist [30079,31065]
===
match
---
trailer [40281,40305]
trailer [40337,40361]
===
match
---
atom_expr [31340,31349]
atom_expr [31396,31405]
===
match
---
trailer [52234,52268]
trailer [52290,52324]
===
match
---
name: hook [96186,96190]
name: hook [96242,96246]
===
match
---
name: str [38937,38940]
name: str [38993,38996]
===
match
---
operator: = [2262,2263]
operator: = [2262,2263]
===
match
---
atom_expr [30913,30932]
atom_expr [30969,30988]
===
match
---
trailer [28879,28894]
trailer [28935,28950]
===
match
---
name: self [78245,78249]
name: self [78301,78305]
===
match
---
operator: , [66693,66694]
operator: , [66749,66750]
===
match
---
name: Optional [48277,48285]
name: Optional [48333,48341]
===
match
---
name: project_id [96381,96391]
name: project_id [96437,96447]
===
match
---
atom_expr [18743,18767]
atom_expr [18743,18767]
===
match
---
name: DATASET [63923,63930]
name: DATASET [63979,63986]
===
match
---
operator: = [52433,52434]
operator: = [52489,52490]
===
match
---
name: context [97584,97591]
name: context [97640,97647]
===
match
---
name: rows [19080,19084]
name: rows [19080,19084]
===
match
---
operator: = [50110,50111]
operator: = [50166,50167]
===
match
---
atom_expr [98046,98058]
atom_expr [98102,98114]
===
match
---
atom_expr [55868,55881]
atom_expr [55924,55937]
===
match
---
fstring [31125,31198]
fstring [31181,31254]
===
match
---
name: source_uris [52044,52055]
name: source_uris [52100,52111]
===
match
---
operator: , [17996,17997]
operator: , [17996,17997]
===
match
---
name: bigquery_conn_id [86033,86049]
name: bigquery_conn_id [86089,86105]
===
match
---
argument [40463,40507]
argument [40519,40563]
===
match
---
atom_expr [30383,30408]
atom_expr [30439,30464]
===
match
---
argument [52526,52562]
argument [52582,52618]
===
match
---
name: Optional [6864,6872]
name: Optional [6864,6872]
===
match
---
name: sql [28555,28558]
name: sql [28611,28614]
===
match
---
name: src_fmt_configs [48307,48322]
name: src_fmt_configs [48363,48378]
===
match
---
name: error_result [96755,96767]
name: error_result [96811,96823]
===
match
---
name: self [81066,81070]
name: self [81122,81126]
===
match
---
trailer [47461,47467]
trailer [47517,47523]
===
match
---
trailer [52600,52616]
trailer [52656,52672]
===
match
---
operator: -> [98611,98613]
operator: -> [98667,98669]
===
match
---
name: BigQueryUIColors [84750,84766]
name: BigQueryUIColors [84806,84822]
===
match
---
name: impersonation_chain [40463,40482]
name: impersonation_chain [40519,40538]
===
match
---
arglist [41556,41617]
arglist [41612,41673]
===
match
---
atom_expr [61320,61521]
atom_expr [61376,61577]
===
match
---
operator: = [74371,74372]
operator: = [74427,74428]
===
match
---
name: location [9614,9622]
name: location [9614,9622]
===
match
---
param [26051,26085]
param [26051,26085]
===
match
---
atom [47174,47370]
atom [47230,47426]
===
match
---
trailer [49966,49980]
trailer [50022,50036]
===
match
---
operator: , [13534,13535]
operator: , [13534,13535]
===
match
---
expr_stmt [90540,90568]
expr_stmt [90596,90624]
===
match
---
operator: = [27522,27523]
operator: = [27578,27579]
===
match
---
name: gcp_conn_id [90193,90204]
name: gcp_conn_id [90249,90260]
===
match
---
param [13088,13127]
param [13088,13127]
===
match
---
trailer [51088,51102]
trailer [51144,51158]
===
match
---
atom_expr [96052,96070]
atom_expr [96108,96126]
===
match
---
operator: -> [17728,17730]
operator: -> [17728,17730]
===
match
---
param [38974,38998]
param [39030,39054]
===
match
---
atom_expr [78177,78188]
atom_expr [78233,78244]
===
match
---
name: self [64780,64784]
name: self [64836,64840]
===
match
---
tfpdef [6743,6766]
tfpdef [6743,6766]
===
match
---
simple_stmt [75179,77468]
simple_stmt [75235,77524]
===
match
---
simple_stmt [64294,64323]
simple_stmt [64350,64379]
===
match
---
operator: , [29882,29883]
operator: , [29938,29939]
===
match
---
name: self [30451,30455]
name: self [30507,30511]
===
match
---
name: delegate_to [64627,64638]
name: delegate_to [64683,64694]
===
match
---
operator: = [74198,74199]
operator: = [74254,74255]
===
match
---
name: fields [74441,74447]
name: fields [74497,74503]
===
match
---
atom_expr [81197,81210]
atom_expr [81253,81266]
===
match
---
name: hook [31434,31438]
name: hook [31490,31494]
===
match
---
trailer [29991,30001]
trailer [30047,30057]
===
match
---
name: delegate_to [27697,27708]
name: delegate_to [27753,27764]
===
match
---
atom_expr [50279,50305]
atom_expr [50335,50361]
===
match
---
name: warnings [49344,49352]
name: warnings [49400,49408]
===
match
---
name: BaseOperator [62058,62070]
name: BaseOperator [62114,62126]
===
match
---
name: sql [9816,9819]
name: sql [9816,9819]
===
match
---
name: self [67214,67218]
name: self [67270,67274]
===
match
---
trailer [50236,50252]
trailer [50292,50308]
===
match
---
name: cluster_fields [41039,41053]
name: cluster_fields [41095,41109]
===
match
---
name: BigQueryHook [70932,70944]
name: BigQueryHook [70988,71000]
===
match
---
name: self [97442,97446]
name: self [97498,97502]
===
match
---
name: str [48470,48473]
name: str [48526,48529]
===
match
---
trailer [52877,52884]
trailer [52933,52940]
===
match
---
tfpdef [95051,95086]
tfpdef [95107,95142]
===
match
---
name: warn [9930,9934]
name: warn [9930,9934]
===
match
---
name: delegate_to [18299,18310]
name: delegate_to [18299,18310]
===
match
---
name: dataset_id [67702,67712]
name: dataset_id [67758,67768]
===
match
---
name: self [85971,85975]
name: self [86027,86031]
===
match
---
return_stmt [91000,91281]
return_stmt [91056,91337]
===
match
---
operator: = [30620,30621]
operator: = [30676,30677]
===
match
---
name: labels [38626,38632]
name: labels [38682,38688]
===
match
---
param [26226,26271]
param [26226,26271]
===
match
---
atom_expr [96661,96677]
atom_expr [96717,96733]
===
match
---
expr_stmt [82029,82075]
expr_stmt [82085,82131]
===
match
---
name: impersonation_chain [50759,50778]
name: impersonation_chain [50815,50834]
===
match
---
subscriptlist [70350,70368]
subscriptlist [70406,70424]
===
match
---
trailer [13242,13269]
trailer [13242,13269]
===
match
---
argument [51260,51288]
argument [51316,51344]
===
match
---
param [26280,26325]
param [26280,26325]
===
match
---
atom_expr [40206,40228]
atom_expr [40262,40284]
===
match
---
suite [9790,10232]
suite [9790,10232]
===
match
---
simple_stmt [82125,82184]
simple_stmt [82181,82240]
===
match
---
simple_stmt [78456,78632]
simple_stmt [78512,78688]
===
match
---
string: '.json' [96020,96027]
string: '.json' [96076,96083]
===
match
---
fstring_start: f" [97077,97079]
fstring_start: f" [97133,97135]
===
match
---
name: info [18471,18475]
name: info [18471,18475]
===
match
---
operator: ** [78070,78072]
operator: ** [78126,78128]
===
match
---
name: delegate_to [18681,18692]
name: delegate_to [18681,18692]
===
match
---
subscriptlist [74250,74268]
subscriptlist [74306,74324]
===
match
---
name: delete_contents [57058,57073]
name: delete_contents [57114,57129]
===
match
---
name: __init__ [81465,81473]
name: __init__ [81521,81529]
===
match
---
atom_expr [51711,51777]
atom_expr [51767,51833]
===
match
---
operator: = [52056,52057]
operator: = [52112,52113]
===
match
---
atom_expr [98551,98561]
atom_expr [98607,98617]
===
match
---
operator: , [94646,94647]
operator: , [94702,94703]
===
match
---
arglist [96924,96958]
arglist [96980,97014]
===
match
---
operator: , [52562,52563]
operator: , [52618,52619]
===
match
---
operator: ** [90764,90766]
operator: ** [90820,90822]
===
match
---
trailer [13365,13374]
trailer [13365,13374]
===
match
---
name: self [28767,28771]
name: self [28823,28827]
===
match
---
trailer [30521,30540]
trailer [30577,30596]
===
match
---
simple_stmt [18601,18779]
simple_stmt [18601,18779]
===
match
---
operator: = [51208,51209]
operator: = [51264,51265]
===
match
---
fstring_string: Or, if you want to reattach in this scenario add  [98427,98476]
fstring_string: Or, if you want to reattach in this scenario add  [98483,98532]
===
match
---
argument [29614,29636]
argument [29670,29692]
===
match
---
name: __init__ [66787,66795]
name: __init__ [66843,66851]
===
match
---
trailer [17752,17761]
trailer [17752,17761]
===
match
---
operator: , [25264,25265]
operator: , [25264,25265]
===
match
---
operator: , [67097,67098]
operator: , [67153,67154]
===
match
---
subscriptlist [9690,9708]
subscriptlist [9690,9708]
===
match
---
param [2689,2703]
param [2689,2703]
===
match
---
operator: = [29075,29076]
operator: = [29131,29132]
===
match
---
name: bq_hook [51790,51797]
name: bq_hook [51846,51853]
===
match
---
name: Sequence [17680,17688]
name: Sequence [17680,17688]
===
match
---
operator: , [57028,57029]
operator: , [57084,57085]
===
match
---
operator: , [17629,17630]
operator: , [17629,17630]
===
match
---
tfpdef [74171,74197]
tfpdef [74227,74253]
===
match
---
operator: = [7095,7096]
operator: = [7095,7096]
===
match
---
name: run_table_upsert [86227,86243]
name: run_table_upsert [86283,86299]
===
match
---
tfpdef [96186,96204]
tfpdef [96242,96260]
===
match
---
operator: ** [6954,6956]
operator: ** [6954,6956]
===
match
---
name: max_results [66897,66908]
name: max_results [66953,66964]
===
match
---
expr_stmt [96845,96874]
expr_stmt [96901,96930]
===
match
---
string: 'DATASTORE_BACKUP' [51129,51147]
string: 'DATASTORE_BACKUP' [51185,51203]
===
match
---
name: state [97953,97958]
name: state [98009,98014]
===
match
---
name: impersonation_chain [70826,70845]
name: impersonation_chain [70882,70901]
===
match
---
name: delegate_to [38583,38594]
name: delegate_to [38639,38650]
===
match
---
argument [40916,40943]
argument [40972,40999]
===
match
---
name: impersonation_chain [64436,64455]
name: impersonation_chain [64492,64511]
===
match
---
name: Optional [60212,60220]
name: Optional [60268,60276]
===
match
---
atom_expr [91179,91194]
atom_expr [91235,91250]
===
match
---
if_stmt [51665,52972]
if_stmt [51721,53028]
===
match
---
name: gcp_conn_id [7083,7094]
name: gcp_conn_id [7083,7094]
===
match
---
operator: , [78899,78900]
operator: , [78955,78956]
===
match
---
trailer [3219,3231]
trailer [3219,3231]
===
match
---
name: impersonation_chain [61170,61189]
name: impersonation_chain [61226,61245]
===
match
---
arglist [95963,95986]
arglist [96019,96042]
===
match
---
trailer [51737,51777]
trailer [51793,51833]
===
match
---
operator: , [6384,6385]
operator: , [6384,6385]
===
match
---
atom [9298,9307]
atom [9298,9307]
===
match
---
name: not_found_ok [82465,82477]
name: not_found_ok [82521,82533]
===
match
---
operator: = [64540,64541]
operator: = [64596,64597]
===
match
---
param [96794,96801]
param [96850,96857]
===
match
---
name: List [1022,1026]
name: List [1022,1026]
===
match
---
name: __init__ [95348,95356]
name: __init__ [95404,95412]
===
match
---
name: job [96284,96287]
name: job [96340,96343]
===
match
---
name: gcs_schema_object [40287,40304]
name: gcs_schema_object [40343,40360]
===
match
---
trailer [61753,61762]
trailer [61809,61818]
===
match
---
operator: = [41111,41112]
operator: = [41167,41168]
===
match
---
trailer [64179,64206]
trailer [64235,64262]
===
match
---
name: self [64409,64413]
name: self [64465,64469]
===
match
---
name: sql [31058,31061]
name: sql [31114,31117]
===
match
---
param [94844,94849]
param [94900,94905]
===
match
---
simple_stmt [2995,3054]
simple_stmt [2995,3054]
===
match
---
name: create_disposition [29428,29446]
name: create_disposition [29484,29502]
===
match
---
operator: , [55534,55535]
operator: , [55590,55591]
===
match
---
number: 3 [60809,60810]
number: 3 [60865,60866]
===
match
---
operator: = [61868,61869]
operator: = [61924,61925]
===
match
---
tfpdef [95197,95253]
tfpdef [95253,95309]
===
match
---
name: str [60262,60265]
name: str [60318,60321]
===
match
---
atom_expr [74540,74556]
atom_expr [74596,74612]
===
match
---
operator: = [91216,91217]
operator: = [91272,91273]
===
match
---
name: type [31151,31155]
name: type [31207,31211]
===
match
---
operator: , [9951,9952]
operator: , [9951,9952]
===
match
---
operator: , [90141,90142]
operator: , [90197,90198]
===
match
---
trailer [64584,64596]
trailer [64640,64652]
===
match
---
name: table_resource [49690,49704]
name: table_resource [49746,49760]
===
match
---
name: __init__ [9807,9815]
name: __init__ [9807,9815]
===
match
---
name: max_results [67219,67230]
name: max_results [67275,67286]
===
match
---
name: self [90791,90795]
name: self [90847,90851]
===
match
---
trailer [40088,40097]
trailer [40144,40153]
===
match
---
param [84886,84919]
param [84942,84975]
===
match
---
trailer [73847,73853]
trailer [73903,73909]
===
match
---
or_test [50575,50596]
or_test [50631,50652]
===
match
---
fstring [97190,97261]
fstring [97246,97317]
===
match
---
name: BigQueryUIColors [81010,81026]
name: BigQueryUIColors [81066,81082]
===
match
---
operator: , [81341,81342]
operator: , [81397,81398]
===
match
---
simple_stmt [52044,52139]
simple_stmt [52100,52195]
===
match
---
name: location [85767,85775]
name: location [85823,85831]
===
match
---
operator: , [29596,29597]
operator: , [29652,29653]
===
match
---
string: """Hex colors for BigQuery operators""" [1857,1896]
string: """Hex colors for BigQuery operators""" [1857,1896]
===
match
---
name: self [90692,90696]
name: self [90748,90752]
===
match
---
name: SQLValueCheckOperator [1420,1441]
name: SQLValueCheckOperator [1420,1441]
===
match
---
arglist [13624,13674]
arglist [13624,13674]
===
match
---
operator: , [26570,26571]
operator: , [26570,26571]
===
match
---
simple_stmt [31429,31454]
simple_stmt [31485,31510]
===
match
---
atom_expr [30786,30808]
atom_expr [30842,30864]
===
match
---
atom_expr [41078,41089]
atom_expr [41134,41145]
===
match
---
name: self [28397,28401]
name: self [28453,28457]
===
match
---
operator: = [74982,74983]
operator: = [75038,75039]
===
match
---
operator: , [3405,3406]
operator: , [3405,3406]
===
match
---
name: self [52596,52600]
name: self [52652,52656]
===
match
---
name: priority [28061,28069]
name: priority [28117,28125]
===
match
---
trailer [26759,26765]
trailer [26759,26765]
===
match
---
atom_expr [74235,74270]
atom_expr [74291,74326]
===
match
---
trailer [27384,27410]
trailer [27440,27466]
===
match
---
name: Optional [38634,38642]
name: Optional [38690,38698]
===
match
---
name: QUERY [25333,25338]
name: QUERY [25333,25338]
===
match
---
fstring_start: f" [98245,98247]
fstring_start: f" [98301,98303]
===
match
---
operator: = [13870,13871]
operator: = [13870,13871]
===
match
---
operator: ** [70871,70873]
operator: ** [70927,70929]
===
match
---
trailer [41546,41550]
trailer [41602,41606]
===
match
---
operator: -> [60547,60549]
operator: -> [60603,60605]
===
match
---
simple_stmt [10323,12653]
simple_stmt [10323,12653]
===
match
---
name: dataset_id [78846,78856]
name: dataset_id [78902,78912]
===
match
---
expr_stmt [90614,90644]
expr_stmt [90670,90700]
===
match
---
operator: = [12674,12675]
operator: = [12674,12675]
===
match
---
trailer [74846,74866]
trailer [74902,74922]
===
match
---
expr_stmt [17238,17277]
expr_stmt [17238,17277]
===
match
---
trailer [9339,9345]
trailer [9339,9345]
===
match
---
operator: = [55925,55926]
operator: = [55981,55982]
===
match
---
operator: , [48441,48442]
operator: , [48497,48498]
===
match
---
name: project_id [86345,86355]
name: project_id [86401,86411]
===
match
---
operator: -> [2580,2582]
operator: -> [2580,2582]
===
match
---
name: self [56397,56401]
name: self [56453,56457]
===
match
---
suite [25475,25520]
suite [25475,25520]
===
match
---
operator: = [96855,96856]
operator: = [96911,96912]
===
match
---
name: log [18467,18470]
name: log [18467,18470]
===
match
---
atom_expr [78206,78222]
atom_expr [78262,78278]
===
match
---
operator: = [86267,86268]
operator: = [86323,86324]
===
match
---
dictorsetmaker [47404,47428]
dictorsetmaker [47460,47484]
===
match
---
operator: = [38649,38650]
operator: = [38705,38706]
===
match
---
name: create_disposition [30522,30540]
name: create_disposition [30578,30596]
===
match
---
operator: , [47891,47892]
operator: , [47947,47948]
===
match
---
operator: , [55980,55981]
operator: , [56036,56037]
===
match
---
name: BigQueryHook [28584,28596]
name: BigQueryHook [28640,28652]
===
match
---
test [39463,39517]
test [39519,39573]
===
match
---
suite [6919,7339]
suite [6919,7339]
===
match
---
operator: = [86130,86131]
operator: = [86186,86187]
===
match
---
simple_stmt [64409,64456]
simple_stmt [64465,64512]
===
match
---
name: project_id [60920,60930]
name: project_id [60976,60986]
===
match
---
simple_stmt [60985,61016]
simple_stmt [61041,61072]
===
match
---
trailer [82000,82009]
trailer [82056,82065]
===
match
---
name: self [30517,30521]
name: self [30573,30577]
===
match
---
name: str [6819,6822]
name: str [6819,6822]
===
match
---
name: self [74983,74987]
name: self [75039,75043]
===
match
---
if_stmt [60565,60869]
if_stmt [60621,60925]
===
match
---
operator: = [47924,47925]
operator: = [47980,47981]
===
match
---
argument [82309,82331]
argument [82365,82387]
===
match
---
operator: , [84918,84919]
operator: , [84974,84975]
===
match
---
tfpdef [2665,2687]
tfpdef [2665,2687]
===
match
---
param [78070,78079]
param [78126,78135]
===
match
---
import_from [1183,1230]
import_from [1183,1230]
===
match
---
name: self [30786,30790]
name: self [30842,30846]
===
match
---
trailer [41038,41053]
trailer [41094,41109]
===
match
---
operator: = [97133,97134]
operator: = [97189,97190]
===
match
---
name: BaseOperator [86425,86437]
name: BaseOperator [86481,86493]
===
match
---
name: gcp_conn_id [90619,90630]
name: gcp_conn_id [90675,90686]
===
match
---
operator: = [57040,57041]
operator: = [57096,57097]
===
match
---
atom_expr [50390,50411]
atom_expr [50446,50467]
===
match
---
operator: , [18849,18850]
operator: , [18849,18850]
===
match
---
name: table_resource [85607,85621]
name: table_resource [85663,85677]
===
match
---
name: quote_character [52655,52670]
name: quote_character [52711,52726]
===
match
---
atom_expr [67075,67088]
atom_expr [67131,67144]
===
match
---
name: location [98808,98816]
name: location [98864,98872]
===
match
---
name: pass_value [9825,9835]
name: pass_value [9825,9835]
===
match
---
trailer [90089,90094]
trailer [90145,90150]
===
match
---
atom_expr [81381,81406]
atom_expr [81437,81462]
===
match
---
atom_expr [67140,67155]
atom_expr [67196,67211]
===
match
---
name: bool [60509,60513]
name: bool [60565,60569]
===
match
---
name: Any [97341,97344]
name: Any [97397,97400]
===
match
---
param [12995,13028]
param [12995,13028]
===
match
---
trailer [64374,64386]
trailer [64430,64442]
===
match
---
atom_expr [60952,60965]
atom_expr [61008,61021]
===
match
---
atom_expr [67464,67629]
atom_expr [67520,67685]
===
match
---
trailer [61942,61953]
trailer [61998,62009]
===
match
---
operator: , [67434,67435]
operator: , [67490,67491]
===
match
---
param [84979,85018]
param [85035,85074]
===
match
---
trailer [28523,28527]
trailer [28579,28583]
===
match
---
name: self [40843,40847]
name: self [40899,40903]
===
match
---
atom_expr [48512,48547]
atom_expr [48568,48603]
===
match
---
simple_stmt [9999,10030]
simple_stmt [9999,10030]
===
match
---
fstring_start: f" [52059,52061]
fstring_start: f" [52115,52117]
===
match
---
atom_expr [18834,18849]
atom_expr [18834,18849]
===
match
---
name: maximum_bytes_billed [30430,30450]
name: maximum_bytes_billed [30486,30506]
===
match
---
trailer [70602,70613]
trailer [70658,70669]
===
match
---
name: table_resource [49316,49330]
name: table_resource [49372,49386]
===
match
---
name: date_filter_column [13483,13501]
name: date_filter_column [13483,13501]
===
match
---
name: patch_dataset [71122,71135]
name: patch_dataset [71178,71191]
===
match
---
name: stacklevel [18014,18024]
name: stacklevel [18014,18024]
===
match
---
trailer [77975,77980]
trailer [78031,78036]
===
match
---
name: str [48226,48229]
name: str [48282,48285]
===
match
---
tfpdef [70271,70297]
tfpdef [70327,70353]
===
match
---
argument [30314,30340]
argument [30370,30396]
===
match
---
trailer [85298,85512]
trailer [85354,85568]
===
match
---
name: Union [60455,60460]
name: Union [60511,60516]
===
match
---
name: impersonation_chain [6783,6802]
name: impersonation_chain [6783,6802]
===
match
---
atom_expr [67331,67355]
atom_expr [67387,67411]
===
match
---
operator: = [9983,9984]
operator: = [9983,9984]
===
match
---
name: str [6620,6623]
name: str [6620,6623]
===
match
---
name: self [50048,50052]
name: self [50104,50108]
===
match
---
name: allow_large_results [30190,30209]
name: allow_large_results [30246,30265]
===
match
---
trailer [70676,70688]
trailer [70732,70744]
===
match
---
trailer [55738,55743]
trailer [55794,55799]
===
match
---
atom_expr [82155,82182]
atom_expr [82211,82238]
===
match
---
trailer [98635,98642]
trailer [98691,98698]
===
match
---
name: table_resource [49856,49870]
name: table_resource [49912,49926]
===
match
---
arglist [98746,98816]
arglist [98802,98872]
===
match
---
name: gcp_conn_id [28614,28625]
name: gcp_conn_id [28670,28681]
===
match
---
name: ui_color [6497,6505]
name: ui_color [6497,6505]
===
match
---
name: BigQueryHook [97362,97374]
name: BigQueryHook [97418,97430]
===
match
---
name: udf_config [27736,27746]
name: udf_config [27792,27802]
===
match
---
param [77997,78061]
param [78053,78117]
===
match
---
name: quote_character [50255,50270]
name: quote_character [50311,50326]
===
match
---
operator: = [3045,3046]
operator: = [3045,3046]
===
match
---
testlist_comp [25149,25265]
testlist_comp [25149,25265]
===
match
---
operator: } [89865,89866]
operator: } [89921,89922]
===
match
---
simple_stmt [61198,61225]
simple_stmt [61254,61281]
===
match
---
atom_expr [27813,27838]
atom_expr [27869,27894]
===
match
---
trailer [26662,26667]
trailer [26662,26667]
===
match
---
operator: = [50361,50362]
operator: = [50417,50418]
===
match
---
name: impersonation_chain [67336,67355]
name: impersonation_chain [67392,67411]
===
match
---
string: """     Executes a BigQuery job. Waits for the job to complete and returns job id.     This operator work in the following way:      - it calculates a unique hash of the job using job's configuration or uuid if ``force_rerun`` is True     - creates ``job_id`` in form of         ``[provided_job_id | airflow_{dag_id}_{task_id}_{exec_date}]_{uniqueness_suffix}``     - submits a BigQuery job using the ``job_id``     - if job with given id already exists then it tries to reattach to the job if its not done and its         state is in ``reattach_states``. If the job is done the operator will raise ``AirflowException``.      Using ``force_rerun`` will submit a new job every time without attaching to already existing ones.      For job definition see here:          https://cloud.google.com/bigquery/docs/reference/v2/jobs      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryInsertJobOperator`       :param configuration: The configuration parameter maps directly to BigQuery's         configuration field in the job  object. For more details see         https://cloud.google.com/bigquery/docs/reference/v2/jobs     :type configuration: Dict[str, Any]     :param job_id: The ID of the job. It will be suffixed with hash of job configuration         unless ``force_rerun`` is True.         The ID must contain only letters (a-z, A-Z), numbers (0-9), underscores (_), or         dashes (-). The maximum length is 1,024 characters. If not provided then uuid will         be generated.     :type job_id: str     :param force_rerun: If True then operator will use hash of uuid as job id suffix     :type force_rerun: bool     :param reattach_states: Set of BigQuery job's states in case of which we should reattach         to the job. Should be other than final states.     :param project_id: Google Cloud Project where the job is running     :type project_id: str     :param location: location the job is running     :type location: str     :param gcp_conn_id: The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     :param cancel_on_kill: Flag which indicates whether cancel the hook's job or not, when on_kill is called     :type cancel_on_kill: bool     """ [91372,94579]
string: """     Executes a BigQuery job. Waits for the job to complete and returns job id.     This operator work in the following way:      - it calculates a unique hash of the job using job's configuration or uuid if ``force_rerun`` is True     - creates ``job_id`` in form of         ``[provided_job_id | airflow_{dag_id}_{task_id}_{exec_date}]_{uniqueness_suffix}``     - submits a BigQuery job using the ``job_id``     - if job with given id already exists then it tries to reattach to the job if its not done and its         state is in ``reattach_states``. If the job is done the operator will raise ``AirflowException``.      Using ``force_rerun`` will submit a new job every time without attaching to already existing ones.      For job definition see here:          https://cloud.google.com/bigquery/docs/reference/v2/jobs      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryInsertJobOperator`       :param configuration: The configuration parameter maps directly to BigQuery's         configuration field in the job  object. For more details see         https://cloud.google.com/bigquery/docs/reference/v2/jobs     :type configuration: Dict[str, Any]     :param job_id: The ID of the job. It will be suffixed with hash of job configuration         unless ``force_rerun`` is True.         The ID must contain only letters (a-z, A-Z), numbers (0-9), underscores (_), or         dashes (-). The maximum length is 1,024 characters. If not provided then uuid will         be generated.     :type job_id: str     :param force_rerun: If True then operator will use hash of uuid as job id suffix     :type force_rerun: bool     :param reattach_states: Set of BigQuery job's states in case of which we should reattach         to the job. Should be other than final states.     :param project_id: Google Cloud Project where the job is running     :type project_id: str     :param location: location the job is running     :type location: str     :param gcp_conn_id: The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     :param cancel_on_kill: Flag which indicates whether cancel the hook's job or not, when on_kill is called     :type cancel_on_kill: bool     """ [91428,94635]
===
match
---
name: dataset_id [70121,70131]
name: dataset_id [70177,70187]
===
match
---
atom_expr [90747,90773]
atom_expr [90803,90829]
===
match
---
name: self [18957,18961]
name: self [18957,18961]
===
match
---
name: self [78649,78653]
name: self [78705,78709]
===
match
---
name: kwargs [9768,9774]
name: kwargs [9768,9774]
===
match
---
name: template_fields_renderers [77578,77603]
name: template_fields_renderers [77634,77659]
===
match
---
name: project_id [51886,51896]
name: project_id [51942,51952]
===
match
---
operator: -> [90376,90378]
operator: -> [90432,90434]
===
match
---
atom_expr [52772,52794]
atom_expr [52828,52850]
===
match
---
name: impersonation_chain [7268,7287]
name: impersonation_chain [7268,7287]
===
match
---
operator: , [51868,51869]
operator: , [51924,51925]
===
match
---
tfpdef [17330,17345]
tfpdef [17330,17345]
===
match
---
arglist [31243,31269]
arglist [31299,31325]
===
match
---
dictorsetmaker [77607,77633]
dictorsetmaker [77663,77689]
===
match
---
trailer [70054,70062]
trailer [70110,70118]
===
match
---
string: 'impersonation_chain' [9232,9253]
string: 'impersonation_chain' [9232,9253]
===
match
---
name: self [95755,95759]
name: self [95811,95815]
===
match
---
name: self [52434,52438]
name: self [52490,52494]
===
match
---
operator: = [74406,74407]
operator: = [74462,74463]
===
match
---
operator: = [70969,70970]
operator: = [71025,71026]
===
match
---
operator: , [52956,52957]
operator: , [53012,53013]
===
match
---
expr_stmt [60952,60976]
expr_stmt [61008,61032]
===
match
---
name: delegate_to [48264,48275]
name: delegate_to [48320,48331]
===
match
---
operator: = [30850,30851]
operator: = [30906,30907]
===
match
---
name: labels [13286,13292]
name: labels [13286,13292]
===
match
---
trailer [97030,97032]
trailer [97086,97088]
===
match
---
simple_stmt [18333,18358]
simple_stmt [18333,18358]
===
match
---
name: BigQueryJob [96628,96639]
name: BigQueryJob [96684,96695]
===
match
---
operator: , [12911,12912]
operator: , [12911,12912]
===
match
---
tfpdef [38849,38884]
tfpdef [38905,38940]
===
match
---
atom_expr [91255,91270]
atom_expr [91311,91326]
===
match
---
name: staticmethod [96584,96596]
name: staticmethod [96640,96652]
===
match
---
operator: = [84748,84749]
operator: = [84804,84805]
===
match
---
name: delegate_to [85027,85038]
name: delegate_to [85083,85094]
===
match
---
trailer [67653,67672]
trailer [67709,67728]
===
match
---
name: str [85006,85009]
name: str [85062,85065]
===
match
---
operator: , [30592,30593]
operator: , [30648,30649]
===
match
---
name: table [41476,41481]
name: table [41532,41537]
===
match
---
atom_expr [55971,55996]
atom_expr [56027,56052]
===
match
---
name: str [90090,90093]
name: str [90146,90149]
===
match
---
name: execute [90783,90790]
name: execute [90839,90846]
===
match
---
trailer [49357,49677]
trailer [49413,49733]
===
match
---
operator: = [61438,61439]
operator: = [61494,61495]
===
match
---
expr_stmt [78294,78324]
expr_stmt [78350,78380]
===
match
---
name: dataset_id [78862,78872]
name: dataset_id [78918,78928]
===
match
---
operator: = [61318,61319]
operator: = [61374,61375]
===
match
---
name: self [56755,56759]
name: self [56811,56815]
===
match
---
name: read [96134,96138]
name: read [96190,96194]
===
match
---
arglist [10270,10316]
arglist [10270,10316]
===
match
---
atom_expr [64171,64206]
atom_expr [64227,64262]
===
match
---
operator: { [59981,59982]
operator: { [60037,60038]
===
match
---
trailer [95804,95809]
trailer [95860,95865]
===
match
---
name: Optional [70335,70343]
name: Optional [70391,70399]
===
match
---
string: 'table' [12686,12693]
string: 'table' [12686,12693]
===
match
---
name: str [47712,47715]
name: str [47768,47771]
===
match
---
expr_stmt [50232,50270]
expr_stmt [50288,50326]
===
match
---
atom_expr [85565,85580]
atom_expr [85621,85636]
===
match
---
expr_stmt [70598,70626]
expr_stmt [70654,70682]
===
match
---
name: self [64294,64298]
name: self [64350,64354]
===
match
---
expr_stmt [39183,39217]
expr_stmt [39239,39273]
===
match
---
operator: , [13660,13661]
operator: , [13660,13661]
===
match
---
trailer [7013,7018]
trailer [7013,7018]
===
match
---
except_clause [41513,41528]
except_clause [41569,41584]
===
match
---
expr_stmt [90692,90738]
expr_stmt [90748,90794]
===
match
---
name: info [19043,19047]
name: info [19043,19047]
===
match
---
operator: = [67696,67697]
operator: = [67752,67753]
===
match
---
operator: , [9468,9469]
operator: , [9468,9469]
===
match
---
name: gcp_conn_id [85525,85536]
name: gcp_conn_id [85581,85592]
===
match
---
param [9379,9384]
param [9379,9384]
===
match
---
operator: , [6597,6598]
operator: , [6597,6598]
===
match
---
param [85110,85174]
param [85166,85230]
===
match
---
name: source_format [52391,52404]
name: source_format [52447,52460]
===
match
---
name: self [95375,95379]
name: self [95431,95435]
===
match
---
atom_expr [27447,27469]
atom_expr [27503,27525]
===
match
---
simple_stmt [73761,73816]
simple_stmt [73817,73872]
===
match
---
trailer [6832,6837]
trailer [6832,6837]
===
match
---
arglist [2732,2766]
arglist [2732,2766]
===
match
---
name: table_resource [85976,85990]
name: table_resource [86032,86046]
===
match
---
trailer [30329,30340]
trailer [30385,30396]
===
match
---
name: source_objects [52123,52137]
name: source_objects [52179,52193]
===
match
---
operator: = [3214,3215]
operator: = [3214,3215]
===
match
---
name: Optional [81372,81380]
name: Optional [81428,81436]
===
match
---
name: self [27357,27361]
name: self [27413,27417]
===
match
---
trailer [82133,82138]
trailer [82189,82194]
===
match
---
operator: ** [17762,17764]
operator: ** [17762,17764]
===
match
---
operator: , [81217,81218]
operator: , [81273,81274]
===
match
---
name: delegate_to [81925,81936]
name: delegate_to [81981,81992]
===
match
---
name: value [9346,9351]
name: value [9346,9351]
===
match
---
name: super [90747,90752]
name: super [90803,90808]
===
match
---
trailer [97446,97458]
trailer [97502,97514]
===
match
---
name: self [64763,64767]
name: self [64819,64823]
===
match
---
tfpdef [60425,60481]
tfpdef [60481,60537]
===
match
---
tfpdef [67034,67090]
tfpdef [67090,67146]
===
match
---
name: project_id [39081,39091]
name: project_id [39137,39147]
===
match
---
name: hash_base [96845,96854]
name: hash_base [96901,96910]
===
match
---
trailer [74947,74962]
trailer [75003,75018]
===
match
---
simple_stmt [67454,67630]
simple_stmt [67510,67686]
===
match
---
atom_expr [86007,86213]
atom_expr [86063,86269]
===
match
---
string: 'google_cloud_default' [90212,90234]
string: 'google_cloud_default' [90268,90290]
===
match
---
fstring_string:  is neither a string nor an iterable [31161,31197]
fstring_string:  is neither a string nor an iterable [31217,31253]
===
match
---
operator: { [61917,61918]
operator: { [61973,61974]
===
match
---
atom_expr [96815,96831]
atom_expr [96871,96887]
===
match
---
simple_stmt [48728,48763]
simple_stmt [48784,48819]
===
match
---
name: tab_ref [51701,51708]
name: tab_ref [51757,51764]
===
match
---
simple_stmt [18131,18156]
simple_stmt [18131,18156]
===
match
---
trailer [17827,18041]
trailer [17827,18041]
===
match
---
name: self [39277,39281]
name: self [39333,39337]
===
match
---
param [60283,60325]
param [60339,60381]
===
match
---
atom_expr [78664,78698]
atom_expr [78720,78754]
===
match
---
name: TABLE [73848,73853]
name: TABLE [73904,73909]
===
match
---
simple_stmt [27731,27760]
simple_stmt [27787,27816]
===
match
---
operator: , [74161,74162]
operator: , [74217,74218]
===
match
---
atom [63808,63890]
atom [63864,63946]
===
match
---
trailer [94877,94887]
trailer [94933,94943]
===
match
---
atom_expr [95340,95366]
atom_expr [95396,95422]
===
match
---
atom_expr [64026,64039]
atom_expr [64082,64095]
===
match
---
name: quote_character [52634,52649]
name: quote_character [52690,52705]
===
match
---
name: kwargs [13327,13333]
name: kwargs [13327,13333]
===
match
---
simple_stmt [37946,38030]
simple_stmt [38002,38086]
===
match
---
name: table_id [18136,18144]
name: table_id [18136,18144]
===
match
---
trailer [56759,56770]
trailer [56815,56826]
===
match
---
simple_stmt [85216,85243]
simple_stmt [85272,85299]
===
match
---
name: operator [2737,2745]
name: operator [2737,2745]
===
match
---
name: on_kill [31319,31326]
name: on_kill [31375,31382]
===
match
---
expr_stmt [7083,7113]
expr_stmt [7083,7113]
===
match
---
name: CHECK [12837,12842]
name: CHECK [12837,12842]
===
match
---
operator: , [77759,77760]
operator: , [77815,77816]
===
match
---
operator: = [94963,94964]
operator: = [95019,95020]
===
match
---
trailer [30917,30932]
trailer [30973,30988]
===
match
---
name: Optional [9624,9632]
name: Optional [9624,9632]
===
match
---
name: name [2095,2099]
name: name [2095,2099]
===
match
---
atom_expr [74750,74766]
atom_expr [74806,74822]
===
match
---
argument [57030,57056]
argument [57086,57112]
===
match
---
name: bigquery_conn_id [39301,39317]
name: bigquery_conn_id [39357,39373]
===
match
---
operator: , [97646,97647]
operator: , [97702,97703]
===
match
---
simple_stmt [18462,18592]
simple_stmt [18462,18592]
===
match
---
operator: = [85776,85777]
operator: = [85832,85833]
===
match
---
trailer [85958,85969]
trailer [86014,86025]
===
match
---
trailer [70434,70589]
trailer [70490,70645]
===
match
---
subscriptlist [47712,47720]
subscriptlist [47768,47776]
===
match
---
operator: = [6840,6841]
operator: = [6840,6841]
===
match
---
name: List [38874,38878]
name: List [38930,38934]
===
match
---
name: self [86050,86054]
name: self [86106,86110]
===
match
---
string: "https://console.cloud.google.com/bigquery?j={job_id}" [1636,1690]
string: "https://console.cloud.google.com/bigquery?j={job_id}" [1636,1690]
===
match
---
atom_expr [95418,95431]
atom_expr [95474,95487]
===
match
---
name: job [96546,96549]
name: job [96602,96605]
===
match
---
name: Any [9458,9461]
name: Any [9458,9461]
===
match
---
simple_stmt [41373,41505]
simple_stmt [41429,41561]
===
match
---
operator: = [64310,64311]
operator: = [64366,64367]
===
match
---
atom_expr [61870,61954]
atom_expr [61926,62010]
===
match
---
trailer [81386,81406]
trailer [81442,81462]
===
match
---
name: self [56738,56742]
name: self [56794,56798]
===
match
---
string: 'google_cloud_default' [60302,60324]
string: 'google_cloud_default' [60358,60380]
===
match
---
name: schema_fields [49967,49980]
name: schema_fields [50023,50036]
===
match
---
arglist [28614,28843]
arglist [28670,28899]
===
match
---
name: stacklevel [9973,9983]
name: stacklevel [9973,9983]
===
match
---
expr_stmt [40535,40604]
expr_stmt [40591,40660]
===
match
---
string: '' [2377,2379]
string: '' [2377,2379]
===
match
---
name: Optional [38428,38436]
name: Optional [38484,38492]
===
match
---
argument [3245,3279]
argument [3245,3279]
===
match
---
operator: , [6885,6886]
operator: , [6885,6886]
===
match
---
atom_expr [60212,60226]
atom_expr [60268,60282]
===
match
---
atom_expr [67177,67192]
atom_expr [67233,67248]
===
match
---
name: schema_fields_updates [91048,91069]
name: schema_fields_updates [91104,91125]
===
match
---
name: schema_fields [51504,51517]
name: schema_fields [51560,51573]
===
match
---
trailer [38679,38685]
trailer [38735,38741]
===
match
---
fstring_string:  state. If you  [98305,98320]
fstring_string:  state. If you  [98361,98376]
===
match
---
decorator [2382,2409]
decorator [2382,2409]
===
match
---
trailer [82211,82400]
trailer [82267,82456]
===
match
---
trailer [78945,78947]
trailer [79001,79003]
===
match
---
atom_expr [39960,40166]
atom_expr [40016,40222]
===
match
---
name: value [63931,63936]
name: value [63987,63992]
===
match
---
tfpdef [55718,55743]
tfpdef [55774,55799]
===
match
---
trailer [60403,60408]
trailer [60459,60464]
===
match
---
operator: , [70261,70262]
operator: , [70317,70318]
===
match
---
name: location [3307,3315]
name: location [3307,3315]
===
match
---
operator: , [97918,97919]
operator: , [97974,97975]
===
match
---
name: gcp_conn_id [84928,84939]
name: gcp_conn_id [84984,84995]
===
match
---
name: schema_fields_updates [89963,89984]
name: schema_fields_updates [90019,90040]
===
match
---
name: impersonation_chain [90287,90306]
name: impersonation_chain [90343,90362]
===
match
---
name: dataset_resource [78674,78690]
name: dataset_resource [78730,78746]
===
match
---
fstring_expr [52080,52095]
fstring_expr [52136,52151]
===
match
---
atom_expr [97668,97695]
atom_expr [97724,97751]
===
match
---
atom_expr [86050,86066]
atom_expr [86106,86122]
===
match
---
trailer [70870,70880]
trailer [70926,70936]
===
match
---
operator: = [96911,96912]
operator: = [96967,96968]
===
match
---
name: delegate_to [64389,64400]
name: delegate_to [64445,64456]
===
match
---
name: location [98794,98802]
name: location [98850,98858]
===
match
---
trailer [31451,31453]
trailer [31507,31509]
===
match
---
simple_stmt [90393,90444]
simple_stmt [90449,90500]
===
match
---
name: self [28275,28279]
name: self [28331,28335]
===
match
---
import_name [875,886]
import_name [875,886]
===
match
---
argument [97821,97847]
argument [97877,97903]
===
match
---
operator: , [55556,55557]
operator: , [55612,55613]
===
match
---
param [85070,85101]
param [85126,85157]
===
match
---
trailer [31316,31318]
trailer [31372,31374]
===
match
---
name: dataset_id [64275,64285]
name: dataset_id [64331,64341]
===
match
---
trailer [90397,90419]
trailer [90453,90475]
===
match
---
trailer [56563,56583]
trailer [56619,56639]
===
match
---
parameters [97325,97345]
parameters [97381,97401]
===
match
---
simple_stmt [48654,48675]
simple_stmt [48710,48731]
===
match
---
name: sql [6589,6592]
name: sql [6589,6592]
===
match
---
name: delegate_to [67311,67322]
name: delegate_to [67367,67378]
===
match
---
atom_expr [30851,30876]
atom_expr [30907,30932]
===
match
---
expr_stmt [90452,90498]
expr_stmt [90508,90554]
===
match
---
name: gcp_conn_id [90851,90862]
name: gcp_conn_id [90907,90918]
===
match
---
trailer [18186,18199]
trailer [18186,18199]
===
match
---
name: kwargs [17764,17770]
name: kwargs [17764,17770]
===
match
---
name: max_results [18187,18198]
name: max_results [18187,18198]
===
match
---
name: job_id [97181,97187]
name: job_id [97237,97243]
===
match
---
trailer [82413,82426]
trailer [82469,82482]
===
match
---
operator: = [90823,90824]
operator: = [90879,90880]
===
match
---
name: xcom_pull [2789,2798]
name: xcom_pull [2789,2798]
===
match
---
string: 'destination_project_dataset_table' [47253,47288]
string: 'destination_project_dataset_table' [47309,47344]
===
match
---
param [26334,26398]
param [26334,26398]
===
match
---
simple_stmt [55599,55641]
simple_stmt [55655,55697]
===
match
---
trailer [56742,56753]
trailer [56798,56809]
===
match
---
subscriptlist [95233,95251]
subscriptlist [95289,95307]
===
match
---
atom_expr [90577,90592]
atom_expr [90633,90648]
===
match
---
name: GCSHook [40329,40336]
name: GCSHook [40385,40392]
===
match
---
atom_expr [50923,50939]
atom_expr [50979,50995]
===
match
---
name: self [67594,67598]
name: self [67650,67654]
===
match
---
operator: , [77723,77724]
operator: , [77779,77780]
===
match
---
arglist [82225,82390]
arglist [82281,82446]
===
match
---
trailer [90752,90754]
trailer [90808,90810]
===
match
---
name: md5 [96997,97000]
name: md5 [97053,97056]
===
match
---
string: """     This operator is used to update dataset for your Project in BigQuery.     Use ``fields`` to specify which fields of dataset to update. If a field     is listed in ``fields`` and is ``None`` in dataset, it will be deleted.     If no ``fields`` are provided then all fields of provided ``dataset_resource``     will be used.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryUpdateDatasetOperator`      :param dataset_id: The id of dataset. Don't need to provide,         if datasetId in dataset_reference.     :type dataset_id: str     :param dataset_resource: Dataset resource that will be provided with request body.         https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets#resource     :type dataset_resource: Dict[str, Any]     :param fields: The properties of dataset to change (e.g. "friendly_name").     :type fields: Sequence[str]     :param project_id: The name of the project where we want to create the dataset.         Don't need to provide, if projectId in dataset_reference.     :type project_id: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]      :rtype: dataset         https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets#resource     """ [75179,77467]
string: """     This operator is used to update dataset for your Project in BigQuery.     Use ``fields`` to specify which fields of dataset to update. If a field     is listed in ``fields`` and is ``None`` in dataset, it will be deleted.     If no ``fields`` are provided then all fields of provided ``dataset_resource``     will be used.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryUpdateDatasetOperator`      :param dataset_id: The id of dataset. Don't need to provide,         if datasetId in dataset_reference.     :type dataset_id: str     :param dataset_resource: Dataset resource that will be provided with request body.         https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets#resource     :type dataset_resource: Dict[str, Any]     :param fields: The properties of dataset to change (e.g. "friendly_name").     :type fields: Sequence[str]     :param project_id: The name of the project where we want to create the dataset.         Don't need to provide, if projectId in dataset_reference.     :type project_id: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]      :rtype: dataset         https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets#resource     """ [75235,77523]
===
match
---
atom_expr [50512,50528]
atom_expr [50568,50584]
===
match
---
name: impersonation_chain [97472,97491]
name: impersonation_chain [97528,97547]
===
match
---
atom_expr [9799,9878]
atom_expr [9799,9878]
===
match
---
trailer [66918,66923]
trailer [66974,66979]
===
match
---
string: 'google_cloud_default' [38551,38573]
string: 'google_cloud_default' [38607,38629]
===
match
---
name: maximum_bytes_billed [27875,27895]
name: maximum_bytes_billed [27931,27951]
===
match
---
name: ui_color [94777,94785]
name: ui_color [94833,94841]
===
match
---
operator: = [28305,28306]
operator: = [28361,28362]
===
match
---
simple_stmt [50512,50543]
simple_stmt [50568,50599]
===
match
---
name: Union [26812,26817]
name: Union [26812,26817]
===
match
---
atom_expr [40329,40522]
atom_expr [40385,40578]
===
match
---
name: impersonation_chain [95727,95746]
name: impersonation_chain [95783,95802]
===
match
---
name: view [41117,41121]
name: view [41173,41177]
===
match
---
name: self [30979,30983]
name: self [31035,31039]
===
match
---
name: str [66953,66956]
name: str [67009,67012]
===
match
---
name: str [26704,26707]
name: str [26704,26707]
===
match
---
name: deletion_dataset_table [81091,81113]
name: deletion_dataset_table [81147,81169]
===
match
---
name: warnings [17814,17822]
name: warnings [17814,17822]
===
match
---
name: self [25590,25594]
name: self [25590,25594]
===
match
---
name: location [81311,81319]
name: location [81367,81375]
===
match
---
trailer [41481,41490]
trailer [41537,41546]
===
match
---
operator: , [81301,81302]
operator: , [81357,81358]
===
match
---
simple_stmt [85762,85787]
simple_stmt [85818,85843]
===
match
---
operator: = [39092,39093]
operator: = [39148,39149]
===
match
---
name: kwargs [70389,70395]
name: kwargs [70445,70451]
===
match
---
name: dict [84872,84876]
name: dict [84928,84932]
===
match
---
trailer [75023,75034]
trailer [75079,75090]
===
match
---
name: bigquery_conn_id [26003,26019]
name: bigquery_conn_id [26003,26019]
===
match
---
name: self [61967,61971]
name: self [62023,62027]
===
match
---
simple_stmt [78103,78132]
simple_stmt [78159,78188]
===
match
---
atom_expr [74255,74268]
atom_expr [74311,74324]
===
match
---
expr_stmt [66631,66731]
expr_stmt [66687,66787]
===
match
---
name: self [18550,18554]
name: self [18550,18554]
===
match
---
atom_expr [64717,64796]
atom_expr [64773,64852]
===
match
---
param [47901,47928]
param [47957,47984]
===
match
---
name: sql [9404,9407]
name: sql [9404,9407]
===
match
---
trailer [95356,95366]
trailer [95412,95422]
===
match
---
atom_expr [18131,18144]
atom_expr [18131,18144]
===
match
---
operator: { [52066,52067]
operator: { [52122,52123]
===
match
---
operator: = [26121,26122]
operator: = [26121,26122]
===
match
---
param [81311,81342]
param [81367,81398]
===
match
---
operator: = [10089,10090]
operator: = [10089,10090]
===
match
---
operator: = [91254,91255]
operator: = [91310,91311]
===
match
---
funcdef [9357,10232]
funcdef [9357,10232]
===
match
---
operator: = [86355,86356]
operator: = [86411,86412]
===
match
---
string: "materialized_view" [38001,38020]
string: "materialized_view" [38057,38076]
===
match
---
name: Optional [47754,47762]
name: Optional [47810,47818]
===
match
---
atom_expr [95963,95981]
atom_expr [96019,96037]
===
match
---
operator: , [67794,67795]
operator: , [67850,67851]
===
match
---
atom_expr [38428,38442]
atom_expr [38484,38498]
===
match
---
operator: , [29160,29161]
operator: , [29216,29217]
===
match
---
simple_stmt [39226,39269]
simple_stmt [39282,39325]
===
match
---
trailer [97205,97212]
trailer [97261,97268]
===
match
---
arglist [40580,40602]
arglist [40636,40658]
===
match
---
trailer [98541,98548]
trailer [98597,98604]
===
match
---
operator: = [13524,13525]
operator: = [13524,13525]
===
match
---
arglist [61981,62021]
arglist [62037,62077]
===
match
---
suite [50819,52972]
suite [50875,53028]
===
match
---
name: cluster_fields [39734,39748]
name: cluster_fields [39790,39804]
===
match
---
name: BigQueryUpdateTableSchemaOperator [86391,86424]
name: BigQueryUpdateTableSchemaOperator [86447,86480]
===
match
---
operator: = [52872,52873]
operator: = [52928,52929]
===
match
---
atom_expr [96913,96959]
atom_expr [96969,97015]
===
match
---
tfpdef [12921,12945]
tfpdef [12921,12945]
===
match
---
simple_stmt [78708,78911]
simple_stmt [78764,78967]
===
match
---
expr_stmt [6497,6536]
expr_stmt [6497,6536]
===
match
---
name: labels [30614,30620]
name: labels [30670,30676]
===
match
---
name: gcp_conn_id [86055,86066]
name: gcp_conn_id [86111,86122]
===
match
---
atom_expr [74320,74335]
atom_expr [74376,74391]
===
match
---
name: force_rerun [95614,95625]
name: force_rerun [95670,95681]
===
match
---
name: gcp_conn_id [7128,7139]
name: gcp_conn_id [7128,7139]
===
match
---
simple_stmt [17814,18042]
simple_stmt [17814,18042]
===
match
---
name: self [30621,30625]
name: self [30677,30681]
===
match
---
operator: , [67752,67753]
operator: , [67808,67809]
===
match
---
atom_expr [95992,96028]
atom_expr [96048,96084]
===
match
---
atom_expr [98753,98764]
atom_expr [98809,98820]
===
match
---
not_test [40179,40201]
not_test [40235,40257]
===
match
---
name: view [39560,39564]
name: view [39616,39620]
===
match
---
operator: , [86283,86284]
operator: , [86339,86340]
===
match
---
atom_expr [18333,18346]
atom_expr [18333,18346]
===
match
---
trailer [48285,48290]
trailer [48341,48346]
===
match
---
tfpdef [77954,77980]
tfpdef [78010,78036]
===
match
---
param [94979,95008]
param [95035,95064]
===
match
---
name: bigquery_conn_id [81496,81512]
name: bigquery_conn_id [81552,81568]
===
match
---
trailer [31318,31326]
trailer [31374,31382]
===
match
---
suite [2034,2380]
suite [2034,2380]
===
match
---
name: BigQueryUIColors [25316,25332]
name: BigQueryUIColors [25316,25332]
===
match
---
trailer [67083,67088]
trailer [67139,67144]
===
match
---
trailer [95175,95180]
trailer [95231,95236]
===
match
---
operator: , [25942,25943]
operator: , [25942,25943]
===
match
---
operator: = [40798,40799]
operator: = [40854,40855]
===
match
---
name: self [78817,78821]
name: self [78873,78877]
===
match
---
name: allow_large_results [29141,29160]
name: allow_large_results [29197,29216]
===
match
---
operator: , [17226,17227]
operator: , [17226,17227]
===
match
---
arglist [96319,96455]
arglist [96375,96511]
===
match
---
name: task_ids [2799,2807]
name: task_ids [2799,2807]
===
match
---
param [89938,89943]
param [89994,89999]
===
match
---
simple_stmt [96567,96578]
simple_stmt [96623,96634]
===
match
---
string: 'dataset_id' [77501,77513]
string: 'dataset_id' [77557,77569]
===
match
---
name: BaseOperator [31495,31507]
name: BaseOperator [31551,31563]
===
match
---
name: state [98299,98304]
name: state [98355,98360]
===
match
---
operator: , [52794,52795]
operator: , [52850,52851]
===
match
---
param [17712,17721]
param [17712,17721]
===
match
---
name: Optional [66867,66875]
name: Optional [66923,66931]
===
match
---
name: Optional [84997,85005]
name: Optional [85053,85061]
===
match
---
atom_expr [28275,28304]
atom_expr [28331,28360]
===
match
---
name: location [13173,13181]
name: location [13173,13181]
===
match
---
operator: , [75110,75111]
operator: , [75166,75167]
===
match
---
name: gcp_conn_id [70677,70688]
name: gcp_conn_id [70733,70744]
===
match
---
param [17457,17499]
param [17457,17499]
===
match
---
trailer [78395,78404]
trailer [78451,78460]
===
match
---
expr_stmt [13812,13836]
expr_stmt [13812,13836]
===
match
---
param [28461,28466]
param [28517,28522]
===
match
---
trailer [39823,39843]
trailer [39879,39899]
===
match
---
trailer [61874,61892]
trailer [61930,61948]
===
match
---
name: schema_fields [51066,51079]
name: schema_fields [51122,51135]
===
match
---
simple_stmt [12809,12849]
simple_stmt [12809,12849]
===
match
---
trailer [12842,12848]
trailer [12842,12848]
===
match
---
trailer [67701,67712]
trailer [67757,67768]
===
match
---
parameters [12866,13340]
parameters [12866,13340]
===
match
---
operator: = [95725,95726]
operator: = [95781,95782]
===
match
---
if_stmt [51527,51656]
if_stmt [51583,51712]
===
match
---
operator: , [61452,61453]
operator: , [61508,61509]
===
match
---
trailer [67012,67017]
trailer [67068,67073]
===
match
---
name: self [52386,52390]
name: self [52442,52446]
===
match
---
name: use_legacy_sql [13136,13150]
name: use_legacy_sql [13136,13150]
===
match
---
operator: = [26436,26437]
operator: = [26436,26437]
===
match
---
string: 'google_cloud_default' [95122,95144]
string: 'google_cloud_default' [95178,95200]
===
match
---
name: encryption_configuration [48394,48418]
name: encryption_configuration [48450,48474]
===
match
---
operator: = [30912,30913]
operator: = [30968,30969]
===
match
---
operator: ** [60531,60533]
operator: ** [60587,60589]
===
match
---
argument [61594,61620]
argument [61650,61676]
===
match
---
atom_expr [30979,31008]
atom_expr [31035,31064]
===
match
---
name: self [29010,29014]
name: self [29066,29070]
===
match
---
name: gcs_bucket [40580,40590]
name: gcs_bucket [40636,40646]
===
match
---
name: use_legacy_sql [3245,3259]
name: use_legacy_sql [3245,3259]
===
match
---
simple_stmt [7123,7154]
simple_stmt [7123,7154]
===
match
---
string: 'labels' [25201,25209]
string: 'labels' [25201,25209]
===
match
---
argument [81474,81482]
argument [81530,81538]
===
match
---
operator: * [84820,84821]
operator: * [84876,84877]
===
match
---
simple_stmt [67292,67323]
simple_stmt [67348,67379]
===
match
---
trailer [51991,52002]
trailer [52047,52058]
===
match
---
operator: = [90177,90178]
operator: = [90233,90234]
===
match
---
trailer [78181,78188]
trailer [78237,78244]
===
match
---
name: str [47954,47957]
name: str [48010,48013]
===
match
---
trailer [41116,41121]
trailer [41172,41177]
===
match
---
name: gcp_conn_id [85703,85714]
name: gcp_conn_id [85759,85770]
===
match
---
atom_expr [64780,64795]
atom_expr [64836,64851]
===
match
---
name: Optional [90308,90316]
name: Optional [90364,90372]
===
match
---
trailer [3398,3405]
trailer [3398,3405]
===
match
---
trailer [74324,74335]
trailer [74380,74391]
===
match
---
name: _handle_job_error [97673,97690]
name: _handle_job_error [97729,97746]
===
match
---
trailer [18212,18228]
trailer [18212,18228]
===
match
---
name: create_disposition [29404,29422]
name: create_disposition [29460,29478]
===
match
---
name: job_id [28908,28914]
name: job_id [28964,28970]
===
match
---
name: Iterable [29932,29940]
name: Iterable [29988,29996]
===
match
---
name: _handle_job_error [96605,96622]
name: _handle_job_error [96661,96678]
===
match
---
string: "table_resource" [37975,37991]
string: "table_resource" [38031,38047]
===
match
---
name: self [39226,39230]
name: self [39282,39286]
===
match
---
atom [77491,77573]
atom [77547,77629]
===
match
---
atom_expr [60026,60056]
atom_expr [60082,60112]
===
match
---
simple_stmt [74357,74382]
simple_stmt [74413,74438]
===
match
---
fstring_string:  already exists and is in  [98268,98294]
fstring_string:  already exists and is in  [98324,98350]
===
match
---
classdef [91321,98831]
classdef [91377,98887]
===
match
---
atom_expr [78038,78051]
atom_expr [78094,78107]
===
match
---
param [47634,47673]
param [47690,47729]
===
match
---
operator: = [1908,1909]
operator: = [1908,1909]
===
match
---
name: flatten_results [25904,25919]
name: flatten_results [25904,25919]
===
match
---
expr_stmt [70711,70751]
expr_stmt [70767,70807]
===
match
---
name: Optional [90163,90171]
name: Optional [90219,90227]
===
match
---
name: delegate_to [17556,17567]
name: delegate_to [17556,17567]
===
match
---
operator: = [78770,78771]
operator: = [78826,78827]
===
match
---
atom_expr [60466,60479]
atom_expr [60522,60535]
===
match
---
trailer [51404,51456]
trailer [51460,51512]
===
match
---
name: project_id [64880,64890]
name: project_id [64936,64946]
===
match
---
testlist_comp [59847,59942]
testlist_comp [59903,59998]
===
match
---
expr_stmt [61310,61521]
expr_stmt [61366,61577]
===
match
---
operator: , [64696,64697]
operator: , [64752,64753]
===
match
---
name: job_id [98758,98764]
name: job_id [98814,98820]
===
match
---
argument [41321,41345]
argument [41377,41401]
===
match
---
operator: , [96792,96793]
operator: , [96848,96849]
===
match
---
simple_stmt [69861,69962]
simple_stmt [69917,70018]
===
match
---
subscriptlist [77756,77764]
subscriptlist [77812,77820]
===
match
---
param [48196,48255]
param [48252,48311]
===
match
---
atom_expr [67055,67090]
atom_expr [67111,67146]
===
match
---
operator: = [70733,70734]
operator: = [70789,70790]
===
match
---
simple_stmt [66736,66778]
simple_stmt [66792,66834]
===
match
---
not_test [49312,49330]
not_test [49368,49386]
===
match
---
name: self [18094,18098]
name: self [18094,18098]
===
match
---
name: template_fields_renderers [69966,69991]
name: template_fields_renderers [70022,70047]
===
match
---
operator: = [6690,6691]
operator: = [6690,6691]
===
match
---
name: allow_quoted_newlines [50308,50329]
name: allow_quoted_newlines [50364,50385]
===
match
---
name: delegate_to [40434,40445]
name: delegate_to [40490,40501]
===
match
---
except_clause [97704,97719]
except_clause [97760,97775]
===
match
---
trailer [18620,18778]
trailer [18620,18778]
===
match
---
name: gcs_object [40592,40602]
name: gcs_object [40648,40658]
===
match
---
operator: , [55708,55709]
operator: , [55764,55765]
===
match
---
name: use_legacy_sql [28660,28674]
name: use_legacy_sql [28716,28730]
===
match
---
name: BigQueryIntervalCheckOperator [10240,10269]
name: BigQueryIntervalCheckOperator [10240,10269]
===
match
---
operator: = [89831,89832]
operator: = [89887,89888]
===
match
---
suite [61301,62023]
suite [61357,62079]
===
match
---
argument [96944,96958]
argument [97000,97014]
===
match
---
string: 'view' [37868,37874]
string: 'view' [37924,37930]
===
match
---
atom_expr [98295,98304]
atom_expr [98351,98360]
===
match
---
testlist_comp [63818,63884]
testlist_comp [63874,63940]
===
match
---
expr_stmt [59953,60010]
expr_stmt [60009,60066]
===
match
---
atom_expr [67064,67089]
atom_expr [67120,67145]
===
match
---
operator: , [9271,9272]
operator: , [9271,9272]
===
match
---
trailer [30579,30592]
trailer [30635,30648]
===
match
---
operator: = [71251,71252]
operator: = [71307,71308]
===
match
---
trailer [6812,6839]
trailer [6812,6839]
===
match
---
name: schema_update_options [27932,27953]
name: schema_update_options [27988,28009]
===
match
---
trailer [70974,70986]
trailer [71030,71042]
===
match
---
operator: , [30540,30541]
operator: , [30596,30597]
===
match
---
argument [71241,71267]
argument [71297,71323]
===
match
---
operator: } [97111,97112]
operator: } [97167,97168]
===
match
---
operator: , [89793,89794]
operator: , [89849,89850]
===
match
---
suite [25395,25601]
suite [25395,25601]
===
match
---
simple_stmt [40736,41361]
simple_stmt [40792,41417]
===
match
---
name: BaseOperator [57148,57160]
name: BaseOperator [57204,57216]
===
match
---
trailer [27555,27575]
trailer [27611,27631]
===
match
---
name: bool [9593,9597]
name: bool [9593,9597]
===
match
---
operator: = [64671,64672]
operator: = [64727,64728]
===
match
---
name: impersonation_chain [17639,17658]
name: impersonation_chain [17639,17658]
===
match
---
name: DeprecationWarning [27318,27336]
name: DeprecationWarning [27348,27366]
===
match
---
suite [41529,41619]
suite [41585,41675]
===
match
---
decorated [96583,96771]
decorated [96639,96827]
===
match
---
fstring_string:  failed:  [96741,96750]
fstring_string:  failed:  [96797,96806]
===
match
---
fstring_string: Job with id:  [98247,98260]
fstring_string: Job with id:  [98303,98316]
===
match
---
name: self [95480,95484]
name: self [95536,95540]
===
match
---
name: encryption_configuration [50666,50690]
name: encryption_configuration [50722,50746]
===
match
---
operator: , [37999,38000]
operator: , [38055,38056]
===
match
---
name: self [28917,28921]
name: self [28973,28977]
===
match
---
name: kwargs [60533,60539]
name: kwargs [60589,60595]
===
match
---
name: cluster_fields [26633,26647]
name: cluster_fields [26633,26647]
===
match
---
param [38702,38743]
param [38758,38799]
===
match
---
name: str [74133,74136]
name: str [74189,74192]
===
match
---
atom_expr [85131,85166]
atom_expr [85187,85222]
===
match
---
name: super [9799,9804]
name: super [9799,9804]
===
match
---
name: table_resource [84856,84870]
name: table_resource [84912,84926]
===
match
---
sync_comp_for [52097,52137]
sync_comp_for [52153,52193]
===
match
---
arglist [56817,56946]
arglist [56873,57002]
===
match
---
simple_stmt [82557,84566]
simple_stmt [82613,84622]
===
match
---
operator: , [61620,61621]
operator: , [61676,61677]
===
match
---
name: BigQueryPatchDatasetOperator [67814,67842]
name: BigQueryPatchDatasetOperator [67870,67898]
===
match
---
atom_expr [90257,90270]
atom_expr [90313,90326]
===
match
---
name: project_id [97821,97831]
name: project_id [97877,97887]
===
match
---
name: self [61198,61202]
name: self [61254,61258]
===
match
---
name: source_uris [52331,52342]
name: source_uris [52387,52398]
===
match
---
name: job_id [97085,97091]
name: job_id [97141,97147]
===
match
---
name: context [31208,31215]
name: context [31264,31271]
===
match
---
operator: , [40445,40446]
operator: , [40501,40502]
===
match
---
subscriptlist [73933,73941]
subscriptlist [73989,73997]
===
match
---
name: Optional [95167,95175]
name: Optional [95223,95231]
===
match
---
name: fields [78182,78188]
name: fields [78238,78244]
===
match
---
operator: , [1020,1021]
operator: , [1020,1021]
===
match
---
name: __init__ [17287,17295]
name: __init__ [17287,17295]
===
match
---
name: self [49962,49966]
name: self [50018,50022]
===
match
---
atom_expr [97362,97527]
atom_expr [97418,97583]
===
match
---
operator: = [63806,63807]
operator: = [63862,63863]
===
match
---
name: tab_ref [51939,51946]
name: tab_ref [51995,52002]
===
match
---
argument [67726,67752]
argument [67782,67808]
===
match
---
name: airflow [1531,1538]
name: airflow [1531,1538]
===
match
---
operator: = [78716,78717]
operator: = [78772,78773]
===
match
---
simple_stmt [51701,51778]
simple_stmt [51757,51834]
===
match
---
operator: , [41251,41252]
operator: , [41307,41308]
===
match
---
trailer [30680,30702]
trailer [30736,30758]
===
match
---
name: bucket [51428,51434]
name: bucket [51484,51490]
===
match
---
name: dict [6873,6877]
name: dict [6873,6877]
===
match
---
name: str [55877,55880]
name: str [55933,55936]
===
match
---
name: hashlib [894,901]
name: hashlib [894,901]
===
match
---
name: BaseOperator [1258,1270]
name: BaseOperator [1258,1270]
===
match
---
atom_expr [64257,64272]
atom_expr [64313,64328]
===
match
---
operator: = [30785,30786]
operator: = [30841,30842]
===
match
---
name: self [13728,13732]
name: self [13728,13732]
===
match
---
name: table [41458,41463]
name: table [41514,41519]
===
match
---
name: ti [2170,2172]
name: ti [2170,2172]
===
match
---
atom_expr [47698,47722]
atom_expr [47754,47778]
===
match
---
atom_expr [78245,78266]
atom_expr [78301,78322]
===
match
---
atom_expr [97215,97227]
atom_expr [97271,97283]
===
match
---
operator: = [29360,29361]
operator: = [29416,29417]
===
match
---
name: delete_contents [56457,56472]
name: delete_contents [56513,56528]
===
match
---
argument [30050,30106]
argument [30106,30162]
===
match
---
trailer [28576,28581]
trailer [28632,28637]
===
match
---
name: table_resource [74517,74531]
name: table_resource [74573,74587]
===
match
---
operator: = [90477,90478]
operator: = [90533,90534]
===
match
---
simple_stmt [50138,50177]
simple_stmt [50194,50233]
===
match
---
number: 3 [56291,56292]
number: 3 [56347,56348]
===
match
---
name: impersonation_chain [3354,3373]
name: impersonation_chain [3354,3373]
===
match
---
operator: , [29810,29811]
operator: , [29866,29867]
===
match
---
operator: , [66724,66725]
operator: , [66780,66781]
===
match
---
expr_stmt [28027,28047]
expr_stmt [28083,28103]
===
match
---
name: self [31340,31344]
name: self [31396,31400]
===
match
---
simple_stmt [28242,28267]
simple_stmt [28298,28323]
===
match
---
name: self [96052,96056]
name: self [96108,96112]
===
match
---
name: dict [26469,26473]
name: dict [26469,26473]
===
match
---
funcdef [60062,61261]
funcdef [60118,61317]
===
match
---
operator: = [19107,19108]
operator: = [19107,19108]
===
match
---
name: schema_fields [39204,39217]
name: schema_fields [39260,39273]
===
match
---
operator: , [50897,50898]
operator: , [50953,50954]
===
match
---
string: 'gcp_conn_id' [12703,12716]
string: 'gcp_conn_id' [12703,12716]
===
match
---
subscriptlist [13249,13267]
subscriptlist [13249,13267]
===
match
---
trailer [96928,96942]
trailer [96984,96998]
===
match
---
operator: , [47218,47219]
operator: , [47274,47275]
===
match
---
name: location [97865,97873]
name: location [97921,97929]
===
match
---
name: self [30913,30917]
name: self [30969,30973]
===
match
---
raise_stmt [98201,98527]
raise_stmt [98257,98583]
===
match
---
operator: = [6879,6880]
operator: = [6879,6880]
===
match
---
atom_expr [41604,41617]
atom_expr [41660,41673]
===
match
---
simple_stmt [13812,13837]
simple_stmt [13812,13837]
===
match
---
name: str [73933,73936]
name: str [73989,73992]
===
match
---
trailer [96996,97000]
trailer [97052,97056]
===
match
---
comparison [51107,51147]
comparison [51163,51203]
===
match
---
atom_expr [40131,40155]
atom_expr [40187,40211]
===
match
---
name: BigQueryDeleteTableOperator [78956,78983]
name: BigQueryDeleteTableOperator [79012,79039]
===
match
---
name: google_cloud_storage_conn_id [50444,50472]
name: google_cloud_storage_conn_id [50500,50528]
===
match
---
operator: = [78119,78120]
operator: = [78175,78176]
===
match
---
expr_stmt [18255,18285]
expr_stmt [18255,18285]
===
match
---
tfpdef [63989,64004]
tfpdef [64045,64060]
===
match
---
name: project [41449,41456]
name: project [41505,41512]
===
match
---
expr_stmt [9312,9351]
expr_stmt [9312,9351]
===
match
---
name: gcp_conn_id [17457,17468]
name: gcp_conn_id [17457,17468]
===
match
---
atom_expr [70344,70369]
atom_expr [70400,70425]
===
match
---
name: create_disposition [27503,27521]
name: create_disposition [27559,27577]
===
match
---
simple_stmt [1902,1920]
simple_stmt [1902,1920]
===
match
---
name: log [19039,19042]
name: log [19039,19042]
===
match
---
tfpdef [47901,47923]
tfpdef [47957,47979]
===
match
---
atom_expr [98680,98830]
atom_expr [98736,98886]
===
match
---
operator: = [27896,27897]
operator: = [27952,27953]
===
match
---
name: attr [1080,1084]
name: attr [1080,1084]
===
match
---
tfpdef [6589,6597]
tfpdef [6589,6597]
===
match
---
atom_expr [64409,64433]
atom_expr [64465,64489]
===
match
---
name: self [30851,30855]
name: self [30907,30911]
===
match
---
classdef [19215,31454]
classdef [19215,31510]
===
match
---
operator: , [91154,91155]
operator: , [91210,91211]
===
match
---
atom_expr [96118,96141]
atom_expr [96174,96197]
===
match
---
strings [81557,81672]
strings [81613,81728]
===
match
---
operator: = [59835,59836]
operator: = [59891,59892]
===
match
---
operator: , [37874,37875]
operator: , [37930,37931]
===
match
---
argument [3039,3052]
argument [3039,3052]
===
match
---
name: str [94918,94921]
name: str [94974,94977]
===
match
---
arglist [60629,60811]
arglist [60685,60867]
===
match
---
name: use_legacy_sql [27773,27787]
name: use_legacy_sql [27829,27843]
===
match
---
name: hook [97355,97359]
name: hook [97411,97415]
===
match
---
atom_expr [48461,48474]
atom_expr [48517,48530]
===
match
---
name: BigQueryJob [96236,96247]
name: BigQueryJob [96292,96303]
===
match
---
name: project_id [67182,67192]
name: project_id [67238,67248]
===
match
---
name: dataset_id [91184,91194]
name: dataset_id [91240,91250]
===
match
---
operator: + [2635,2636]
operator: + [2635,2636]
===
match
---
argument [9825,9846]
argument [9825,9846]
===
match
---
param [70314,70378]
param [70370,70434]
===
match
---
name: self [60915,60919]
name: self [60971,60975]
===
match
---
funcdef [56647,57105]
funcdef [56703,57161]
===
match
---
argument [30654,30702]
argument [30710,30758]
===
match
---
name: self [74842,74846]
name: self [74898,74902]
===
match
---
name: execute [97318,97325]
name: execute [97374,97381]
===
match
---
if_stmt [9888,10030]
if_stmt [9888,10030]
===
match
---
name: str [89996,89999]
name: str [90052,90055]
===
match
---
funcdef [74666,75122]
funcdef [74722,75178]
===
match
---
simple_stmt [98680,98831]
simple_stmt [98736,98887]
===
match
---
simple_stmt [56520,56551]
simple_stmt [56576,56607]
===
match
---
simple_stmt [59953,60011]
simple_stmt [60009,60067]
===
match
---
atom_expr [28140,28165]
atom_expr [28196,28221]
===
match
---
operator: , [29636,29637]
operator: , [29692,29693]
===
match
---
operator: , [30702,30703]
operator: , [30758,30759]
===
match
---
operator: -> [26871,26873]
operator: -> [26871,26873]
===
match
---
simple_stmt [97785,97934]
simple_stmt [97841,97990]
===
match
---
operator: , [73936,73937]
operator: , [73992,73993]
===
match
---
param [9766,9775]
param [9766,9775]
===
match
---
trailer [49838,49853]
trailer [49894,49909]
===
match
---
strings [85316,85431]
strings [85372,85487]
===
match
---
name: location [38809,38817]
name: location [38865,38873]
===
match
---
fstring_expr [98476,98487]
fstring_expr [98532,98543]
===
match
---
trailer [61920,61924]
trailer [61976,61980]
===
match
---
operator: , [28465,28466]
operator: , [28521,28522]
===
match
---
name: str [6685,6688]
name: str [6685,6688]
===
match
---
tfpdef [48451,48474]
tfpdef [48507,48530]
===
match
---
name: skip_leading_rows [50112,50129]
name: skip_leading_rows [50168,50185]
===
match
---
parameters [64507,64522]
parameters [64563,64578]
===
match
---
name: TABLE [84767,84772]
name: TABLE [84823,84828]
===
match
---
name: self [40282,40286]
name: self [40338,40342]
===
match
---
atom_expr [10072,10088]
atom_expr [10072,10088]
===
match
---
try_stmt [40675,41619]
try_stmt [40731,41675]
===
match
---
operator: , [89740,89741]
operator: , [89796,89797]
===
match
---
name: row [19127,19130]
name: row [19127,19130]
===
match
---
name: str [38605,38608]
name: str [38661,38664]
===
match
---
operator: = [38686,38687]
operator: = [38742,38743]
===
match
---
name: hooks [1562,1567]
name: hooks [1562,1567]
===
match
---
trailer [38786,38792]
trailer [38842,38848]
===
match
---
param [85183,85192]
param [85239,85248]
===
match
---
expr_stmt [63790,63890]
expr_stmt [63846,63946]
===
match
---
atom_expr [50699,50712]
atom_expr [50755,50768]
===
match
---
name: table_id [38192,38200]
name: table_id [38248,38256]
===
match
---
testlist_comp [77501,77567]
testlist_comp [77557,77623]
===
match
---
trailer [96860,96874]
trailer [96916,96930]
===
match
---
atom_expr [30575,30592]
atom_expr [30631,30648]
===
match
---
suite [6992,7114]
suite [6992,7114]
===
match
---
atom_expr [60121,60134]
atom_expr [60177,60190]
===
match
---
operator: , [77513,77514]
operator: , [77569,77570]
===
match
---
simple_stmt [27447,27490]
simple_stmt [27503,27546]
===
match
---
name: hashlib [96989,96996]
name: hashlib [97045,97052]
===
match
---
operator: } [98486,98487]
operator: } [98542,98543]
===
match
---
operator: = [55882,55883]
operator: = [55938,55939]
===
match
---
operator: = [25787,25788]
operator: = [25787,25788]
===
match
---
tfpdef [85070,85093]
tfpdef [85126,85149]
===
match
---
operator: , [30340,30341]
operator: , [30396,30397]
===
match
---
simple_stmt [86444,89642]
simple_stmt [86500,89698]
===
match
---
trailer [18838,18849]
trailer [18838,18849]
===
match
---
atom_expr [95595,95611]
atom_expr [95651,95667]
===
match
---
name: Optional [38778,38786]
name: Optional [38834,38842]
===
match
---
name: bq_hook [74702,74709]
name: bq_hook [74758,74765]
===
match
---
suite [78447,78948]
suite [78503,79004]
===
match
---
atom_expr [13767,13786]
atom_expr [13767,13786]
===
match
---
name: cancel_query [31439,31451]
name: cancel_query [31495,31507]
===
match
---
trailer [74192,74197]
trailer [74248,74253]
===
match
---
parameters [77698,78085]
parameters [77754,78141]
===
match
---
import_from [1442,1525]
import_from [1442,1525]
===
match
---
param [74038,74069]
param [74094,74125]
===
match
---
name: dict [12941,12945]
name: dict [12941,12945]
===
match
---
operator: , [1051,1052]
operator: , [1051,1052]
===
match
---
name: bq_hook [78456,78463]
name: bq_hook [78512,78519]
===
match
---
name: download [40571,40579]
name: download [40627,40635]
===
match
---
param [64514,64521]
param [64570,64577]
===
match
---
trailer [50091,50109]
trailer [50147,50165]
===
match
---
name: Optional [77967,77975]
name: Optional [78023,78031]
===
match
---
trailer [3189,3416]
trailer [3189,3416]
===
match
---
trailer [95599,95611]
trailer [95655,95667]
===
match
---
simple_stmt [64900,64929]
simple_stmt [64956,64985]
===
match
---
expr_stmt [51483,51517]
expr_stmt [51539,51573]
===
match
---
name: delegate_to [90893,90904]
name: delegate_to [90949,90960]
===
match
---
tfpdef [48355,48377]
tfpdef [48411,48433]
===
match
---
name: str [96222,96225]
name: str [96278,96281]
===
match
---
operator: = [39844,39845]
operator: = [39900,39901]
===
match
---
trailer [31383,31388]
trailer [31439,31444]
===
match
---
operator: = [70576,70577]
operator: = [70632,70633]
===
match
---
operator: = [74336,74337]
operator: = [74392,74393]
===
match
---
name: Optional [6676,6684]
name: Optional [6676,6684]
===
match
---
simple_stmt [64717,64797]
simple_stmt [64773,64853]
===
match
---
tfpdef [25803,25825]
tfpdef [25803,25825]
===
match
---
name: bool [38985,38989]
name: bool [39041,39045]
===
match
---
trailer [29198,29214]
trailer [29254,29270]
===
match
---
operator: , [1392,1393]
operator: , [1392,1393]
===
match
---
string: 'dataset_id' [17113,17125]
string: 'dataset_id' [17113,17125]
===
match
---
trailer [2543,2545]
trailer [2543,2545]
===
match
---
atom_expr [17609,17622]
atom_expr [17609,17622]
===
match
---
atom_expr [9547,9560]
atom_expr [9547,9560]
===
match
---
name: project_id [64864,64874]
name: project_id [64920,64930]
===
match
---
name: BigQueryHook [95820,95832]
name: BigQueryHook [95876,95888]
===
match
---
operator: , [29386,29387]
operator: , [29442,29443]
===
match
---
expr_stmt [50605,50625]
expr_stmt [50661,50681]
===
match
---
param [95051,95094]
param [95107,95150]
===
match
---
name: gcp_conn_id [40354,40365]
name: gcp_conn_id [40410,40421]
===
match
---
trailer [86182,86202]
trailer [86238,86258]
===
match
---
name: self [39326,39330]
name: self [39382,39386]
===
match
---
name: TABLE [81027,81032]
name: TABLE [81083,81088]
===
match
---
argument [30430,30476]
argument [30486,30532]
===
match
---
simple_stmt [26957,27155]
simple_stmt [26957,27185]
===
match
---
name: self [50439,50443]
name: self [50495,50499]
===
match
---
name: force_rerun [95017,95028]
name: force_rerun [95073,95084]
===
match
---
trailer [19042,19047]
trailer [19042,19047]
===
match
---
operator: , [48089,48090]
operator: , [48145,48146]
===
match
---
trailer [56988,57104]
trailer [57044,57160]
===
match
---
operator: = [47849,47850]
operator: = [47905,47906]
===
match
---
name: GCSHook [51172,51179]
name: GCSHook [51228,51235]
===
match
---
suite [2587,2641]
suite [2587,2641]
===
match
---
atom_expr [97400,97416]
atom_expr [97456,97472]
===
match
---
operator: , [13163,13164]
operator: , [13163,13164]
===
match
---
param [39918,39923]
param [39974,39979]
===
match
---
atom_expr [85140,85165]
atom_expr [85196,85221]
===
match
---
parameters [63954,64238]
parameters [64010,64294]
===
match
---
simple_stmt [31208,31271]
simple_stmt [31264,31327]
===
match
---
simple_stmt [18094,18123]
simple_stmt [18094,18123]
===
match
---
name: gcp_conn_id [97405,97416]
name: gcp_conn_id [97461,97472]
===
match
---
operator: , [51288,51289]
operator: , [51344,51345]
===
match
---
param [48394,48442]
param [48450,48498]
===
match
---
arglist [70448,70579]
arglist [70504,70635]
===
match
---
import_from [1526,1602]
import_from [1526,1602]
===
match
---
trailer [60220,60226]
trailer [60276,60282]
===
match
---
operator: = [38443,38444]
operator: = [38499,38500]
===
match
---
comparison [39469,39494]
comparison [39525,39550]
===
match
---
trailer [96337,96351]
trailer [96393,96407]
===
match
---
name: destination_dataset_table [27413,27438]
name: destination_dataset_table [27469,27494]
===
match
---
expr_stmt [9999,10029]
expr_stmt [9999,10029]
===
match
---
operator: , [97847,97848]
operator: , [97903,97904]
===
match
---
classdef [62025,64929]
classdef [62081,64985]
===
match
---
string: 'labels' [6448,6456]
string: 'labels' [6448,6456]
===
match
---
name: key [2281,2284]
name: key [2281,2284]
===
match
---
name: dataset_resource [77733,77749]
name: dataset_resource [77789,77805]
===
match
---
atom_expr [40551,40604]
atom_expr [40607,40660]
===
match
---
suite [85882,86383]
suite [85938,86439]
===
match
---
funcdef [18418,19166]
funcdef [18418,19166]
===
match
---
name: self [39076,39080]
name: self [39132,39136]
===
match
---
tfpdef [90069,90094]
tfpdef [90125,90150]
===
match
---
simple_stmt [64257,64286]
simple_stmt [64313,64342]
===
match
---
name: self [50876,50880]
name: self [50932,50936]
===
match
---
operator: , [77765,77766]
operator: , [77821,77822]
===
match
---
operator: , [25894,25895]
operator: , [25894,25895]
===
match
---
expr_stmt [40242,40305]
expr_stmt [40298,40361]
===
match
---
operator: , [1064,1065]
operator: , [1064,1065]
===
match
---
expr_stmt [39526,39546]
expr_stmt [39582,39602]
===
match
---
name: self [50279,50283]
name: self [50335,50339]
===
match
---
trailer [27361,27365]
trailer [27417,27421]
===
match
---
name: Optional [85131,85139]
name: Optional [85187,85195]
===
match
---
argument [18823,18849]
argument [18823,18849]
===
match
---
name: encryption_configuration [52902,52926]
name: encryption_configuration [52958,52982]
===
match
---
strings [56111,56226]
strings [56167,56282]
===
match
---
name: BaseOperator [53010,53022]
name: BaseOperator [53066,53078]
===
match
---
name: execution_date [2203,2217]
name: execution_date [2203,2217]
===
match
---
atom_expr [52927,52956]
atom_expr [52983,53012]
===
match
---
name: days_back [13515,13524]
name: days_back [13515,13524]
===
match
---
trailer [51503,51517]
trailer [51559,51573]
===
match
---
name: endswith [96011,96019]
name: endswith [96067,96075]
===
match
---
annassign [95809,95840]
annassign [95865,95896]
===
match
---
string: 'Dataset %s already exists.' [61981,62009]
string: 'Dataset %s already exists.' [62037,62065]
===
match
---
trailer [82138,82183]
trailer [82194,82239]
===
match
---
name: self [50605,50609]
name: self [50661,50665]
===
match
---
expr_stmt [85684,85714]
expr_stmt [85740,85770]
===
match
---
operator: = [13482,13483]
operator: = [13482,13483]
===
match
---
atom_expr [64816,64891]
atom_expr [64872,64947]
===
match
---
name: str [70364,70367]
name: str [70420,70423]
===
match
---
operator: = [18066,18067]
operator: = [18066,18067]
===
match
---
param [6743,6774]
param [6743,6774]
===
match
---
name: Union [13243,13248]
name: Union [13243,13248]
===
match
---
name: Optional [60121,60129]
name: Optional [60177,60185]
===
match
---
number: 0 [47996,47997]
number: 0 [48052,48053]
===
match
---
tfpdef [90151,90176]
tfpdef [90207,90232]
===
match
---
dictorsetmaker [89834,89865]
dictorsetmaker [89890,89921]
===
match
---
name: table_resource [85624,85638]
name: table_resource [85680,85694]
===
match
---
name: bigquery_conn_id [81780,81796]
name: bigquery_conn_id [81836,81852]
===
match
---
simple_stmt [53029,55489]
simple_stmt [53085,55545]
===
match
---
name: ui_color [9312,9320]
name: ui_color [9312,9320]
===
match
---
simple_stmt [3170,3417]
simple_stmt [3170,3417]
===
match
---
operator: = [13270,13271]
operator: = [13270,13271]
===
match
---
operator: ** [39007,39009]
operator: ** [39063,39065]
===
match
---
name: tolerance [9858,9867]
name: tolerance [9858,9867]
===
match
---
name: table [13394,13399]
name: table [13394,13399]
===
match
---
atom_expr [26695,26708]
atom_expr [26695,26708]
===
match
---
atom_expr [51272,51288]
atom_expr [51328,51344]
===
match
---
simple_stmt [13358,13568]
simple_stmt [13358,13568]
===
match
---
param [6607,6649]
param [6607,6649]
===
match
---
name: exec_date [97123,97132]
name: exec_date [97179,97188]
===
match
---
parameters [85858,85873]
parameters [85914,85929]
===
match
---
name: self [51436,51440]
name: self [51492,51496]
===
match
---
suite [2863,2888]
suite [2863,2888]
===
match
---
atom_expr [50634,50663]
atom_expr [50690,50719]
===
match
---
funcdef [96147,96578]
funcdef [96203,96634]
===
match
---
expr_stmt [85565,85593]
expr_stmt [85621,85649]
===
match
---
trailer [67598,67618]
trailer [67654,67674]
===
match
---
trailer [66875,66880]
trailer [66931,66936]
===
match
---
name: str [38179,38182]
name: str [38235,38238]
===
match
---
name: bigquery_conn_id [17784,17800]
name: bigquery_conn_id [17784,17800]
===
match
---
operator: = [56828,56829]
operator: = [56884,56885]
===
match
---
name: task_ids [2254,2262]
name: task_ids [2254,2262]
===
match
---
expr_stmt [85525,85555]
expr_stmt [85581,85611]
===
match
---
expr_stmt [97785,97933]
expr_stmt [97841,97989]
===
match
---
if_stmt [98628,98831]
if_stmt [98684,98887]
===
match
---
operator: , [48876,48877]
operator: , [48932,48933]
===
match
---
name: json [96913,96917]
name: json [96969,96973]
===
match
---
trailer [13849,13869]
trailer [13849,13869]
===
match
---
name: delegate_to [27711,27722]
name: delegate_to [27767,27778]
===
match
---
name: BigQueryUIColors [70038,70054]
name: BigQueryUIColors [70094,70110]
===
match
---
name: delegate_to [56876,56887]
name: delegate_to [56932,56943]
===
match
---
name: self [29243,29247]
name: self [29299,29303]
===
match
---
name: self [85602,85606]
name: self [85658,85662]
===
match
---
name: project_id [75100,75110]
name: project_id [75156,75166]
===
match
---
simple_stmt [18208,18247]
simple_stmt [18208,18247]
===
match
---
argument [67403,67411]
argument [67459,67467]
===
match
---
operator: , [86202,86203]
operator: , [86258,86259]
===
match
---
simple_stmt [67331,67378]
simple_stmt [67387,67434]
===
match
---
string: ',' [47960,47963]
string: ',' [48016,48019]
===
match
---
suite [39941,41619]
suite [39997,41675]
===
match
---
operator: , [39922,39923]
operator: , [39978,39979]
===
match
---
atom_expr [50552,50572]
atom_expr [50608,50628]
===
match
---
name: cloud [1145,1150]
name: cloud [1145,1150]
===
match
---
operator: , [60233,60234]
operator: , [60289,60290]
===
match
---
name: project_id [71257,71267]
name: project_id [71313,71323]
===
match
---
fstring_start: f" [31125,31127]
fstring_start: f" [31181,31183]
===
match
---
name: str [64200,64203]
name: str [64256,64259]
===
match
---
operator: } [38028,38029]
operator: } [38084,38085]
===
match
---
tfpdef [73996,74021]
tfpdef [74052,74077]
===
match
---
name: Optional [77831,77839]
name: Optional [77887,77895]
===
match
---
name: airflow [1188,1195]
name: airflow [1188,1195]
===
match
---
string: "Passing table parameters via keywords arguments will be deprecated. " [49375,49445]
string: "Passing table parameters via keywords arguments will be deprecated. " [49431,49501]
===
match
---
atom_expr [91070,91096]
atom_expr [91126,91152]
===
match
---
tfpdef [55941,55997]
tfpdef [55997,56053]
===
match
---
name: Dict [38680,38684]
name: Dict [38736,38740]
===
match
---
operator: , [56945,56946]
operator: , [57001,57002]
===
match
---
trailer [94917,94922]
trailer [94973,94978]
===
match
---
suite [31509,41619]
suite [31565,41675]
===
match
---
operator: , [89999,90000]
operator: , [90055,90056]
===
match
---
funcdef [25364,25601]
funcdef [25364,25601]
===
match
---
operator: = [37745,37746]
operator: = [37801,37802]
===
match
---
arglist [74738,74867]
arglist [74794,74923]
===
match
---
operator: = [82197,82198]
operator: = [82253,82254]
===
match
---
name: self [41542,41546]
name: self [41598,41602]
===
match
---
expr_stmt [95418,95442]
expr_stmt [95474,95498]
===
match
---
trailer [96754,96767]
trailer [96810,96823]
===
match
---
argument [6945,6952]
argument [6945,6952]
===
match
---
name: dataset_id [71165,71175]
name: dataset_id [71221,71231]
===
match
---
name: Optional [90257,90265]
name: Optional [90313,90321]
===
match
---
name: source_object [52081,52094]
name: source_object [52137,52150]
===
match
---
name: delegate_to [66991,67002]
name: delegate_to [67047,67058]
===
match
---
trailer [90763,90773]
trailer [90819,90829]
===
match
---
operator: , [47562,47563]
operator: , [47618,47619]
===
match
---
name: BigQueryJob [1514,1525]
name: BigQueryJob [1514,1525]
===
match
---
param [26855,26864]
param [26855,26864]
===
match
---
operator: = [2192,2193]
operator: = [2192,2193]
===
match
---
name: pass_value [9836,9846]
name: pass_value [9836,9846]
===
match
---
trailer [97575,97583]
trailer [97631,97639]
===
match
---
operator: , [18548,18549]
operator: , [18548,18549]
===
match
---
name: labels [39540,39546]
name: labels [39596,39602]
===
match
---
trailer [56622,56631]
trailer [56678,56687]
===
match
---
parameters [73877,74302]
parameters [73933,74358]
===
match
---
operator: , [96942,96943]
operator: , [96998,96999]
===
match
---
atom_expr [85216,85242]
atom_expr [85272,85298]
===
match
---
name: project_id [96365,96375]
name: project_id [96421,96431]
===
match
---
name: context [97135,97142]
name: context [97191,97198]
===
match
---
name: template_fields [63790,63805]
name: template_fields [63846,63861]
===
match
---
operator: , [26397,26398]
operator: , [26397,26398]
===
match
---
name: str [77976,77979]
name: str [78032,78035]
===
match
---
name: Sequence [60466,60474]
name: Sequence [60522,60530]
===
match
---
trailer [41591,41602]
trailer [41647,41658]
===
match
---
trailer [82440,82463]
trailer [82496,82519]
===
match
---
string: "You can still use external `schema_object`. " [49550,49596]
string: "You can still use external `schema_object`. " [49606,49652]
===
match
---
trailer [2243,2253]
trailer [2243,2253]
===
match
---
name: info [40701,40705]
name: info [40757,40761]
===
match
---
name: super [70854,70859]
name: super [70910,70915]
===
match
---
testlist_comp [37757,37935]
testlist_comp [37813,37991]
===
match
---
parameters [2573,2579]
parameters [2573,2579]
===
match
---
simple_stmt [67862,69856]
simple_stmt [67918,69912]
===
match
---
operator: } [39464,39465]
operator: } [39520,39521]
===
match
---
operator: = [51497,51498]
operator: = [51553,51554]
===
match
---
argument [51306,51350]
argument [51362,51406]
===
match
---
trailer [84906,84911]
trailer [84962,84967]
===
match
---
name: force_rerun [95600,95611]
name: force_rerun [95656,95667]
===
match
---
name: gcp_conn_id [78225,78236]
name: gcp_conn_id [78281,78292]
===
match
---
atom_expr [90121,90134]
atom_expr [90177,90190]
===
match
---
name: self [28488,28492]
name: self [28544,28548]
===
match
---
trailer [81462,81464]
trailer [81518,81520]
===
match
---
name: self [97536,97540]
name: self [97592,97596]
===
match
---
subscriptlist [94878,94886]
subscriptlist [94934,94942]
===
match
---
trailer [98651,98666]
trailer [98707,98722]
===
match
---
name: context [67436,67443]
name: context [67492,67499]
===
match
---
name: self [6564,6568]
name: self [6564,6568]
===
match
---
operator: = [69877,69878]
operator: = [69933,69934]
===
match
---
atom_expr [85080,85093]
atom_expr [85136,85149]
===
match
---
tfpdef [13136,13156]
tfpdef [13136,13156]
===
match
---
tfpdef [38515,38548]
tfpdef [38571,38604]
===
match
---
trailer [40555,40561]
trailer [40611,40617]
===
match
---
tfpdef [64150,64206]
tfpdef [64206,64262]
===
match
---
name: str [17535,17538]
name: str [17535,17538]
===
match
---
suite [2925,2950]
suite [2925,2950]
===
match
---
trailer [26029,26034]
trailer [26029,26034]
===
match
---
name: super [81457,81462]
name: super [81513,81518]
===
match
---
name: destination_dataset_table [30050,30075]
name: destination_dataset_table [30106,30131]
===
match
---
name: template_fields [94585,94600]
name: template_fields [94641,94656]
===
match
---
string: 'google_cloud_default' [70239,70261]
string: 'google_cloud_default' [70295,70317]
===
match
---
name: str [17618,17621]
name: str [17618,17621]
===
match
---
atom [47403,47429]
atom [47459,47485]
===
match
---
fstring_start: f" [98425,98427]
fstring_start: f" [98481,98483]
===
match
---
string: 'project_id' [89750,89762]
string: 'project_id' [89806,89818]
===
match
---
atom_expr [48324,48338]
atom_expr [48380,48394]
===
match
---
name: gcp_conn_id [81886,81897]
name: gcp_conn_id [81942,81953]
===
match
---
operator: = [60366,60367]
operator: = [60422,60423]
===
match
---
name: __init__ [13366,13374]
name: __init__ [13366,13374]
===
match
---
simple_stmt [3135,3162]
simple_stmt [3135,3162]
===
match
---
operator: = [81923,81924]
operator: = [81979,81980]
===
match
---
operator: , [47192,47193]
operator: , [47248,47249]
===
match
---
expr_stmt [64294,64322]
expr_stmt [64350,64378]
===
match
---
operator: = [30732,30733]
operator: = [30788,30789]
===
match
---
trailer [50283,50305]
trailer [50339,50361]
===
match
---
simple_stmt [39183,39218]
simple_stmt [39239,39274]
===
match
---
name: self [91217,91221]
name: self [91273,91277]
===
match
---
string: "The bigquery_conn_id parameter has been deprecated. You should pass the gcp_conn_id parameter." [1717,1813]
string: "The bigquery_conn_id parameter has been deprecated. You should pass the gcp_conn_id parameter." [1717,1813]
===
match
---
trailer [56695,56699]
trailer [56751,56755]
===
match
---
number: 3 [85496,85497]
number: 3 [85552,85553]
===
match
---
name: query_params [30580,30592]
name: query_params [30636,30648]
===
match
---
param [12876,12881]
param [12876,12881]
===
match
---
atom_expr [81392,81405]
atom_expr [81448,81461]
===
match
---
name: bigquery_conn_id [56334,56350]
name: bigquery_conn_id [56390,56406]
===
match
---
param [26003,26042]
param [26003,26042]
===
match
---
suite [98667,98831]
suite [98723,98887]
===
match
---
operator: = [39164,39165]
operator: = [39220,39221]
===
match
---
name: use_legacy_sql [10133,10147]
name: use_legacy_sql [10133,10147]
===
match
---
name: self [67697,67701]
name: self [67753,67757]
===
match
---
param [38809,38840]
param [38865,38896]
===
match
---
atom_expr [74792,74808]
atom_expr [74848,74864]
===
match
---
name: list [26115,26119]
name: list [26115,26119]
===
match
---
name: DeprecationWarning [27121,27139]
name: DeprecationWarning [27121,27139]
===
match
---
argument [78806,78832]
argument [78862,78888]
===
match
---
name: self [71160,71164]
name: self [71216,71220]
===
match
---
trailer [40370,40399]
trailer [40426,40455]
===
match
---
name: time_partitioning [38409,38426]
name: time_partitioning [38465,38482]
===
match
---
name: gcp_conn_id [56500,56511]
name: gcp_conn_id [56556,56567]
===
match
---
operator: , [30234,30235]
operator: , [30290,30291]
===
match
---
name: table_resource [73912,73926]
name: table_resource [73968,73982]
===
match
---
name: str [73974,73977]
name: str [74030,74033]
===
match
---
operator: = [74749,74750]
operator: = [74805,74806]
===
match
---
name: delegate_to [50517,50528]
name: delegate_to [50573,50584]
===
match
---
operator: = [40842,40843]
operator: = [40898,40899]
===
match
---
argument [91168,91194]
argument [91224,91250]
===
match
---
operator: , [95187,95188]
operator: , [95243,95244]
===
match
---
name: self [75057,75061]
name: self [75113,75117]
===
match
---
operator: = [70237,70238]
operator: = [70293,70294]
===
match
---
operator: = [70204,70205]
operator: = [70260,70261]
===
match
---
name: _DEPRECATION_MSG [1692,1708]
name: _DEPRECATION_MSG [1692,1708]
===
match
---
name: datetime [957,965]
name: datetime [957,965]
===
match
---
param [55941,56005]
param [55997,56061]
===
match
---
name: query_params [26407,26419]
name: query_params [26407,26419]
===
match
---
name: Optional [95811,95819]
name: Optional [95867,95875]
===
match
---
trailer [97629,97641]
trailer [97685,97697]
===
match
---
name: impersonation_chain [64414,64433]
name: impersonation_chain [64470,64489]
===
match
---
name: src_fmt_configs [52812,52827]
name: src_fmt_configs [52868,52883]
===
match
---
simple_stmt [39277,39318]
simple_stmt [39333,39374]
===
match
---
name: impersonation_chain [90960,90979]
name: impersonation_chain [91016,91035]
===
match
---
expr_stmt [39819,39865]
expr_stmt [39875,39921]
===
match
---
trailer [90618,90630]
trailer [90674,90686]
===
match
---
trailer [29676,29694]
trailer [29732,29750]
===
match
---
argument [64568,64596]
argument [64624,64652]
===
match
---
operator: , [81432,81433]
operator: , [81488,81489]
===
match
---
name: BigQueryUIColors [38045,38061]
name: BigQueryUIColors [38101,38117]
===
match
---
name: Union [55971,55976]
name: Union [56027,56032]
===
match
---
name: self [29672,29676]
name: self [29728,29732]
===
match
---
operator: , [30408,30409]
operator: , [30464,30465]
===
match
---
return_stmt [64900,64928]
return_stmt [64956,64984]
===
match
---
name: ui_color [47434,47442]
name: ui_color [47490,47498]
===
match
---
simple_stmt [39950,40167]
simple_stmt [40006,40223]
===
match
---
operator: = [40044,40045]
operator: = [40100,40101]
===
match
---
name: self [74943,74947]
name: self [74999,75003]
===
match
---
trailer [78298,78310]
trailer [78354,78366]
===
match
---
name: cancel_on_kill [95760,95774]
name: cancel_on_kill [95816,95830]
===
match
---
import_from [1289,1341]
import_from [1289,1341]
===
match
---
name: gcp_conn_id [67258,67269]
name: gcp_conn_id [67314,67325]
===
match
---
operator: = [94745,94746]
operator: = [94801,94802]
===
match
---
name: gcs_hook [40318,40326]
name: gcs_hook [40374,40382]
===
match
---
expr_stmt [1968,1987]
expr_stmt [1968,1987]
===
match
---
operator: , [38573,38574]
operator: , [38629,38630]
===
match
---
operator: , [25517,25518]
operator: , [25517,25518]
===
match
---
operator: , [30168,30169]
operator: , [30224,30225]
===
match
---
atom_expr [67697,67712]
atom_expr [67753,67768]
===
match
---
funcdef [85847,86383]
funcdef [85903,86439]
===
match
---
name: str [70133,70136]
name: str [70189,70192]
===
match
---
atom_expr [90037,90051]
atom_expr [90093,90107]
===
match
---
name: self [70898,70902]
name: self [70954,70958]
===
match
---
atom_expr [60598,60825]
atom_expr [60654,60881]
===
match
---
expr_stmt [78206,78236]
expr_stmt [78262,78292]
===
match
---
simple_stmt [1085,1133]
simple_stmt [1085,1133]
===
match
---
operator: , [40898,40899]
operator: , [40954,40955]
===
match
---
name: write_disposition [30128,30145]
name: write_disposition [30184,30201]
===
match
---
operator: = [95463,95464]
operator: = [95519,95520]
===
match
---
string: 'dataset_id' [73664,73676]
string: 'dataset_id' [73720,73732]
===
match
---
name: int [18183,18186]
name: int [18183,18186]
===
match
---
string: '.sql' [9299,9305]
string: '.sql' [9299,9305]
===
match
---
argument [78754,78792]
argument [78810,78848]
===
match
---
atom_expr [48521,48546]
atom_expr [48577,48602]
===
match
---
operator: , [2824,2825]
operator: , [2824,2825]
===
match
---
name: DeprecationWarning [9953,9971]
name: DeprecationWarning [9953,9971]
===
match
---
name: skip_leading_rows [48985,49002]
name: skip_leading_rows [49041,49058]
===
match
---
name: self [28572,28576]
name: self [28628,28632]
===
match
---
operator: = [29135,29136]
operator: = [29191,29192]
===
match
---
try_stmt [97602,98528]
try_stmt [97658,98584]
===
match
---
param [63989,64005]
param [64045,64061]
===
match
---
name: dataset_reference [60193,60210]
name: dataset_reference [60249,60266]
===
match
---
param [6589,6598]
param [6589,6598]
===
match
---
expr_stmt [67292,67322]
expr_stmt [67348,67378]
===
match
---
name: bq_hook [91007,91014]
name: bq_hook [91063,91070]
===
match
---
name: self [97874,97878]
name: self [97930,97934]
===
match
---
name: gcp_conn_id [25952,25963]
name: gcp_conn_id [25952,25963]
===
match
---
name: dataset_id [61943,61953]
name: dataset_id [61999,62009]
===
match
---
name: self [50796,50800]
name: self [50852,50856]
===
match
---
atom [73789,73815]
atom [73845,73871]
===
match
---
trailer [67181,67192]
trailer [67237,67248]
===
match
---
operator: = [78816,78817]
operator: = [78872,78873]
===
match
---
name: impersonation_chain [70314,70333]
name: impersonation_chain [70370,70389]
===
match
---
atom_expr [81996,82009]
atom_expr [82052,82065]
===
match
---
argument [30724,30746]
argument [30780,30802]
===
match
---
name: value [66772,66777]
name: value [66828,66833]
===
match
---
trailer [17617,17622]
trailer [17617,17622]
===
match
---
operator: = [50065,50066]
operator: = [50121,50122]
===
match
---
operator: , [85863,85864]
operator: , [85919,85920]
===
match
---
simple_stmt [39399,39430]
simple_stmt [39455,39486]
===
match
---
operator: , [18026,18027]
operator: , [18026,18027]
===
match
---
name: priority [28072,28080]
name: priority [28128,28136]
===
match
---
name: __init__ [90755,90763]
name: __init__ [90811,90819]
===
match
---
name: gcp_conn_id [64350,64361]
name: gcp_conn_id [64406,64417]
===
match
---
name: location [97879,97887]
name: location [97935,97943]
===
match
---
name: priority [30738,30746]
name: priority [30794,30802]
===
match
---
argument [71189,71227]
argument [71245,71283]
===
match
---
operator: = [61168,61169]
operator: = [61224,61225]
===
match
---
operator: = [64846,64847]
operator: = [64902,64903]
===
match
---
expr_stmt [94719,94772]
expr_stmt [94775,94828]
===
match
---
string: "The bigquery_conn_id parameter has been deprecated. You should pass " [56111,56181]
string: "The bigquery_conn_id parameter has been deprecated. You should pass " [56167,56237]
===
match
---
testlist_comp [84599,84669]
testlist_comp [84655,84725]
===
match
---
classdef [64931,67806]
classdef [64987,67862]
===
match
---
string: 'schema_fields_updates' [89675,89698]
string: 'schema_fields_updates' [89731,89754]
===
match
---
name: self [82155,82159]
name: self [82211,82215]
===
match
---
param [25803,25842]
param [25803,25842]
===
match
---
simple_stmt [64532,64708]
simple_stmt [64588,64764]
===
match
---
simple_stmt [74390,74419]
simple_stmt [74446,74475]
===
match
---
if_stmt [96658,96771]
if_stmt [96714,96827]
===
match
---
atom_expr [3394,3405]
atom_expr [3394,3405]
===
match
---
name: __init__ [78396,78404]
name: __init__ [78452,78460]
===
match
---
string: 'google_cloud_default' [38483,38505]
string: 'google_cloud_default' [38539,38561]
===
match
---
name: template_ext [94689,94701]
name: template_ext [94745,94757]
===
match
---
operator: = [61357,61358]
operator: = [61413,61414]
===
match
---
fstring [98342,98404]
fstring [98398,98460]
===
match
---
operator: = [60850,60851]
operator: = [60906,60907]
===
match
---
tfpdef [84856,84876]
tfpdef [84912,84932]
===
match
---
trailer [61202,61212]
trailer [61258,61268]
===
match
---
name: json [909,913]
name: json [909,913]
===
match
---
atom_expr [64180,64205]
atom_expr [64236,64261]
===
match
---
atom_expr [29076,29098]
atom_expr [29132,29154]
===
match
---
trailer [81205,81210]
trailer [81261,81266]
===
match
---
operator: ** [56632,56634]
operator: ** [56688,56690]
===
match
---
arglist [56111,56293]
arglist [56167,56349]
===
match
---
name: self [18533,18537]
name: self [18533,18537]
===
match
---
operator: = [82010,82011]
operator: = [82066,82067]
===
match
---
param [63964,63969]
param [64020,64025]
===
match
---
param [73996,74029]
param [74052,74085]
===
match
---
operator: = [40130,40131]
operator: = [40186,40187]
===
match
---
string: "dataset_resource" [77607,77625]
string: "dataset_resource" [77663,77681]
===
match
---
tfpdef [95154,95180]
tfpdef [95210,95236]
===
match
---
trailer [26811,26838]
trailer [26811,26838]
===
match
---
operator: = [2217,2218]
operator: = [2217,2218]
===
match
---
operator: = [37972,37973]
operator: = [38028,38029]
===
match
---
name: BigQueryGetDatasetTablesOperator [64937,64969]
name: BigQueryGetDatasetTablesOperator [64993,65025]
===
match
---
name: self [31288,31292]
name: self [31344,31348]
===
match
---
name: log [40697,40700]
name: log [40753,40756]
===
match
---
decorated [2382,3054]
decorated [2382,3054]
===
match
---
operator: = [47769,47770]
operator: = [47825,47826]
===
match
---
trailer [77791,77802]
trailer [77847,77858]
===
match
---
name: self [85647,85651]
name: self [85703,85707]
===
match
---
name: execute [28453,28460]
name: execute [28509,28516]
===
match
---
name: BigQueryValueCheckOperator [7347,7373]
name: BigQueryValueCheckOperator [7347,7373]
===
match
---
name: dict [26760,26764]
name: dict [26760,26764]
===
match
---
operator: { [97229,97230]
operator: { [97285,97286]
===
match
---
operator: , [84668,84669]
operator: , [84724,84725]
===
match
---
name: gcp_conn_id [85689,85700]
name: gcp_conn_id [85745,85756]
===
match
---
atom [6369,6463]
atom [6369,6463]
===
match
---
param [9577,9605]
param [9577,9605]
===
match
---
import_from [1231,1288]
import_from [1231,1288]
===
match
---
trailer [86360,86371]
trailer [86416,86427]
===
match
---
simple_stmt [1231,1289]
simple_stmt [1231,1289]
===
match
---
atom_expr [81372,81407]
atom_expr [81428,81463]
===
match
---
tfpdef [47739,47768]
tfpdef [47795,47824]
===
match
---
operator: = [90210,90211]
operator: = [90266,90267]
===
match
---
name: warnings [85285,85293]
name: warnings [85341,85349]
===
match
---
name: impersonation_chain [18748,18767]
name: impersonation_chain [18748,18767]
===
match
---
operator: = [3348,3349]
operator: = [3348,3349]
===
match
---
tfpdef [47604,47624]
tfpdef [47660,47680]
===
match
---
param [38314,38351]
param [38370,38407]
===
match
---
name: str [38293,38296]
name: str [38349,38352]
===
match
---
trailer [39559,39564]
trailer [39615,39620]
===
match
---
operator: = [18956,18957]
operator: = [18956,18957]
===
match
---
name: gcp_conn_id [27672,27683]
name: gcp_conn_id [27728,27739]
===
match
---
name: google_cloud_storage_conn_id [40371,40399]
name: google_cloud_storage_conn_id [40427,40455]
===
match
---
trailer [90316,90343]
trailer [90372,90399]
===
match
---
fstring [97077,97113]
fstring [97133,97169]
===
match
---
param [47682,47730]
param [47738,47786]
===
match
---
name: template_fields_renderers [73761,73786]
name: template_fields_renderers [73817,73842]
===
match
---
argument [52902,52956]
argument [52958,53012]
===
match
---
name: kwargs [85235,85241]
name: kwargs [85291,85297]
===
match
---
name: use_legacy_sql [9577,9591]
name: use_legacy_sql [9577,9591]
===
match
---
name: warnings [70421,70429]
name: warnings [70477,70485]
===
match
---
name: table_resource [51673,51687]
name: table_resource [51729,51743]
===
match
---
argument [56280,56292]
argument [56336,56348]
===
match
---
name: table_id [39155,39163]
name: table_id [39211,39219]
===
match
---
name: delegate_to [40033,40044]
name: delegate_to [40089,40100]
===
match
---
operator: , [59910,59911]
operator: , [59966,59967]
===
match
---
expr_stmt [39631,39687]
expr_stmt [39687,39743]
===
match
---
expr_stmt [18054,18084]
expr_stmt [18054,18084]
===
match
---
name: self [29194,29198]
name: self [29250,29254]
===
match
---
name: sql [1365,1368]
name: sql [1365,1368]
===
match
---
return_stmt [3170,3416]
return_stmt [3170,3416]
===
match
---
testlist_comp [6484,6491]
testlist_comp [6484,6491]
===
match
---
suite [64523,64929]
suite [64579,64985]
===
match
---
name: str [84941,84944]
name: str [84997,85000]
===
match
---
atom_expr [9624,9637]
atom_expr [9624,9637]
===
match
---
name: sql [6945,6948]
name: sql [6945,6948]
===
match
---
name: self [27870,27874]
name: self [27926,27930]
===
match
---
trailer [26703,26708]
trailer [26703,26708]
===
match
---
expr_stmt [97562,97592]
expr_stmt [97618,97648]
===
match
---
name: delegate_to [50911,50922]
name: delegate_to [50967,50978]
===
match
---
trailer [90322,90342]
trailer [90378,90398]
===
match
---
simple_stmt [914,924]
simple_stmt [914,924]
===
match
---
name: BigQueryUIColors [9323,9339]
name: BigQueryUIColors [9323,9339]
===
match
---
operator: = [85701,85702]
operator: = [85757,85758]
===
match
---
name: Dict [38437,38441]
name: Dict [38493,38497]
===
match
---
name: Optional [17660,17668]
name: Optional [17660,17668]
===
match
---
name: impersonation_chain [82345,82364]
name: impersonation_chain [82401,82420]
===
match
---
argument [13662,13674]
argument [13662,13674]
===
match
---
trailer [91034,91281]
trailer [91090,91337]
===
match
---
testlist_comp [73664,73750]
testlist_comp [73720,73806]
===
match
---
name: self [41034,41038]
name: self [41090,41094]
===
match
---
atom_expr [67646,67805]
atom_expr [67702,67861]
===
match
---
expr_stmt [52044,52138]
expr_stmt [52100,52194]
===
match
---
expr_stmt [39580,39622]
expr_stmt [39636,39678]
===
match
---
tfpdef [60109,60134]
tfpdef [60165,60190]
===
match
---
name: on_kill [98597,98604]
name: on_kill [98653,98660]
===
match
---
name: dataset_id [71149,71159]
name: dataset_id [71205,71215]
===
match
---
name: self [40045,40049]
name: self [40101,40105]
===
match
---
name: str [70350,70353]
name: str [70406,70409]
===
match
---
name: self [41284,41288]
name: self [41340,41344]
===
match
---
name: bool [95286,95290]
name: bool [95342,95346]
===
match
---
atom_expr [17249,17277]
atom_expr [17249,17277]
===
match
---
operator: = [85820,85821]
operator: = [85876,85877]
===
match
---
name: Optional [64120,64128]
name: Optional [64176,64184]
===
match
---
atom_expr [78817,78832]
atom_expr [78873,78888]
===
match
---
operator: * [60098,60099]
operator: * [60154,60155]
===
match
---
name: self [27653,27657]
name: self [27709,27713]
===
match
---
name: impersonation_chain [51014,51033]
name: impersonation_chain [51070,51089]
===
match
---
trailer [91183,91194]
trailer [91239,91250]
===
match
---
trailer [50609,50616]
trailer [50665,50672]
===
match
---
name: context [50802,50809]
name: context [50858,50865]
===
match
---
suite [96888,96960]
suite [96944,97016]
===
match
---
operator: = [55782,55783]
operator: = [55838,55839]
===
match
---
name: gcs_hook [51161,51169]
name: gcs_hook [51217,51225]
===
match
---
trailer [95704,95724]
trailer [95760,95780]
===
match
---
name: delegate_to [64375,64386]
name: delegate_to [64431,64442]
===
match
---
funcdef [90779,91282]
funcdef [90835,91338]
===
match
---
operator: = [3301,3302]
operator: = [3301,3302]
===
match
---
expr_stmt [49879,49953]
expr_stmt [49935,50009]
===
match
---
atom_expr [86092,86108]
atom_expr [86148,86164]
===
match
---
parameters [3103,3109]
parameters [3103,3109]
===
match
---
atom_expr [70635,70650]
atom_expr [70691,70706]
===
match
---
tfpdef [64107,64133]
tfpdef [64163,64189]
===
match
---
param [60151,60184]
param [60207,60240]
===
match
---
trailer [48687,48702]
trailer [48743,48758]
===
match
---
name: self [28675,28679]
name: self [28731,28735]
===
match
---
name: bool [48118,48122]
name: bool [48174,48178]
===
match
---
atom_expr [95068,95086]
atom_expr [95124,95142]
===
match
---
fstring_expr [97229,97240]
fstring_expr [97285,97296]
===
match
---
operator: = [13393,13394]
operator: = [13393,13394]
===
match
---
param [38142,38147]
param [38198,38203]
===
match
---
operator: , [25841,25842]
operator: , [25841,25842]
===
match
---
name: cluster_fields [39751,39765]
name: cluster_fields [39807,39821]
===
match
---
name: bq_hook [61548,61555]
name: bq_hook [61604,61611]
===
match
---
name: self [74750,74754]
name: self [74806,74810]
===
match
---
simple_stmt [25528,25601]
simple_stmt [25528,25601]
===
match
---
atom_expr [74184,74197]
atom_expr [74240,74253]
===
match
---
atom_expr [95238,95251]
atom_expr [95294,95307]
===
match
---
operator: , [28966,28967]
operator: , [29022,29023]
===
match
---
atom_expr [17745,17771]
atom_expr [17745,17771]
===
match
---
name: source_format [48925,48938]
name: source_format [48981,48994]
===
match
---
atom_expr [41443,41456]
atom_expr [41499,41512]
===
match
---
argument [90851,90879]
argument [90907,90935]
===
match
---
name: BigQueryHook [86007,86019]
name: BigQueryHook [86063,86075]
===
match
---
name: maximum_billing_tier [29302,29322]
name: maximum_billing_tier [29358,29378]
===
match
---
trailer [38930,38957]
trailer [38986,39013]
===
match
---
trailer [90754,90763]
trailer [90810,90819]
===
match
---
name: self [29136,29140]
name: self [29192,29196]
===
match
---
name: self [67331,67335]
name: self [67387,67391]
===
match
---
name: location [18338,18346]
name: location [18338,18346]
===
match
---
name: self [2574,2578]
name: self [2574,2578]
===
match
---
trailer [82482,82500]
trailer [82538,82556]
===
match
---
expr_stmt [97181,97261]
expr_stmt [97237,97317]
===
match
---
operator: , [77535,77536]
operator: , [77591,77592]
===
match
---
atom [12676,12804]
atom [12676,12804]
===
match
---
atom_expr [70672,70688]
atom_expr [70728,70744]
===
match
---
atom_expr [78103,78118]
atom_expr [78159,78174]
===
match
---
name: impersonation_chain [85110,85129]
name: impersonation_chain [85166,85185]
===
match
---
param [95270,95298]
param [95326,95354]
===
match
---
name: bigquery_conn_id [13702,13718]
name: bigquery_conn_id [13702,13718]
===
match
---
name: encryption_configuration [28280,28304]
name: encryption_configuration [28336,28360]
===
match
---
name: str [13192,13195]
name: str [13192,13195]
===
match
---
name: str [13249,13252]
name: str [13249,13252]
===
match
---
operator: = [73652,73653]
operator: = [73708,73709]
===
match
---
name: kwargs [78407,78413]
name: kwargs [78463,78469]
===
match
---
name: job_id [2354,2360]
name: job_id [2354,2360]
===
match
---
name: project_id [64312,64322]
name: project_id [64368,64378]
===
match
---
trailer [71121,71135]
trailer [71177,71191]
===
match
---
name: delegate_to [86097,86108]
name: delegate_to [86153,86164]
===
match
---
parameters [61277,61292]
parameters [61333,61348]
===
match
---
argument [40033,40061]
argument [40089,40117]
===
match
---
trailer [78673,78690]
trailer [78729,78746]
===
match
---
argument [71000,71028]
argument [71056,71084]
===
match
---
name: kwargs [74289,74295]
name: kwargs [74345,74351]
===
match
---
simple_stmt [28908,29898]
simple_stmt [28964,29954]
===
match
---
operator: { [77606,77607]
operator: { [77662,77663]
===
match
---
operator: - [13025,13026]
operator: - [13025,13026]
===
match
---
name: job_id [97912,97918]
name: job_id [97968,97974]
===
match
---
tfpdef [77819,77844]
tfpdef [77875,77900]
===
match
---
simple_stmt [25488,25520]
simple_stmt [25488,25520]
===
match
---
name: self [57074,57078]
name: self [57130,57134]
===
match
---
name: bigquery_conn_id [6975,6991]
name: bigquery_conn_id [6975,6991]
===
match
---
name: table_resource [51553,51567]
name: table_resource [51609,51623]
===
match
---
param [25711,25737]
param [25711,25737]
===
match
---
trailer [51413,51422]
trailer [51469,51478]
===
match
---
simple_stmt [91372,94580]
simple_stmt [91428,94636]
===
match
---
name: gcp_conn_id [78211,78222]
name: gcp_conn_id [78267,78278]
===
match
---
operator: , [13276,13277]
operator: , [13276,13277]
===
match
---
name: self [39874,39878]
name: self [39930,39934]
===
match
---
operator: , [82097,82098]
operator: , [82153,82154]
===
match
---
arglist [28954,29883]
arglist [29010,29939]
===
match
---
name: stacklevel [70566,70576]
name: stacklevel [70622,70632]
===
match
---
name: dataset_id [90069,90079]
name: dataset_id [90125,90135]
===
match
---
name: self [18462,18466]
name: self [18462,18466]
===
match
---
trailer [17688,17693]
trailer [17688,17693]
===
match
---
name: kwargs [64483,64489]
name: kwargs [64539,64545]
===
match
---
atom_expr [51668,51687]
atom_expr [51724,51743]
===
match
---
argument [52688,52736]
argument [52744,52792]
===
match
---
atom_expr [61649,61664]
atom_expr [61705,61720]
===
match
---
name: self [41331,41335]
name: self [41387,41391]
===
match
---
name: self [95418,95422]
name: self [95474,95478]
===
match
---
trailer [13374,13567]
trailer [13374,13567]
===
match
---
name: str [13263,13266]
name: str [13263,13266]
===
match
---
operator: = [47723,47724]
operator: = [47779,47780]
===
match
---
atom_expr [78294,78310]
atom_expr [78350,78366]
===
match
---
atom_expr [56520,56536]
atom_expr [56576,56592]
===
match
---
name: info [28528,28532]
name: info [28584,28588]
===
match
---
name: delegate_to [71017,71028]
name: delegate_to [71073,71084]
===
match
---
atom_expr [7230,7243]
atom_expr [7230,7243]
===
match
---
name: labels [7323,7329]
name: labels [7323,7329]
===
match
---
name: Optional [48363,48371]
name: Optional [48419,48427]
===
match
---
operator: , [97299,97300]
operator: , [97355,97356]
===
match
---
name: Optional [13106,13114]
name: Optional [13106,13114]
===
match
---
trailer [86054,86066]
trailer [86110,86122]
===
match
---
name: self [86356,86360]
name: self [86412,86416]
===
match
---
tfpdef [13088,13119]
tfpdef [13088,13119]
===
match
---
param [18436,18443]
param [18436,18443]
===
match
---
atom_expr [82237,82253]
atom_expr [82293,82309]
===
match
---
expr_stmt [27870,27918]
expr_stmt [27926,27974]
===
match
---
name: self [17305,17309]
name: self [17305,17309]
===
match
---
name: str [48158,48161]
name: str [48214,48217]
===
match
---
operator: , [67560,67561]
operator: , [67616,67617]
===
match
---
name: self [78206,78210]
name: self [78262,78266]
===
match
---
suite [49331,49678]
suite [49387,49734]
===
match
---
argument [40961,41001]
argument [41017,41057]
===
match
---
name: Optional [70284,70292]
name: Optional [70340,70348]
===
match
---
tfpdef [17457,17473]
tfpdef [17457,17473]
===
match
---
operator: = [47994,47995]
operator: = [48050,48051]
===
match
---
name: dttm [2762,2766]
name: dttm [2762,2766]
===
match
---
operator: , [74994,74995]
operator: , [75050,75051]
===
match
---
name: flatten_results [27611,27626]
name: flatten_results [27667,27682]
===
match
---
trailer [48811,49299]
trailer [48867,49355]
===
match
---
simple_stmt [49344,49678]
simple_stmt [49400,49734]
===
match
---
operator: , [74028,74029]
operator: , [74084,74085]
===
match
---
operator: , [52884,52885]
operator: , [52940,52941]
===
match
---
trailer [30625,30632]
trailer [30681,30688]
===
match
---
operator: = [85495,85496]
operator: = [85551,85552]
===
match
---
trailer [74724,74877]
trailer [74780,74933]
===
match
---
trailer [18915,18927]
trailer [18915,18927]
===
match
---
atom_expr [29791,29810]
atom_expr [29847,29866]
===
match
---
string: "#C0D7FF" [1910,1919]
string: "#C0D7FF" [1910,1919]
===
match
---
name: project_id [98766,98776]
name: project_id [98822,98832]
===
match
---
trailer [39878,39888]
trailer [39934,39944]
===
match
---
operator: , [89720,89721]
operator: , [89776,89777]
===
match
---
atom [59837,59948]
atom [59893,60004]
===
match
---
string: 'sql' [6379,6384]
string: 'sql' [6379,6384]
===
match
---
name: log [61972,61975]
name: log [62028,62031]
===
match
---
atom [59981,60010]
atom [60037,60066]
===
match
---
name: gcp_conn_id [67507,67518]
name: gcp_conn_id [67563,67574]
===
match
---
trailer [2974,2986]
trailer [2974,2986]
===
match
---
string: 'google_cloud_default' [55818,55840]
string: 'google_cloud_default' [55874,55896]
===
match
---
operator: , [17195,17196]
operator: , [17195,17196]
===
match
---
name: dataset_id [39131,39141]
name: dataset_id [39187,39197]
===
match
---
name: self [56691,56695]
name: self [56747,56751]
===
match
---
trailer [47467,47473]
trailer [47523,47529]
===
match
---
simple_stmt [56320,56351]
simple_stmt [56376,56407]
===
match
---
atom_expr [61486,61510]
atom_expr [61542,61566]
===
match
---
name: src_fmt_configs [50575,50590]
name: src_fmt_configs [50631,50646]
===
match
---
name: ui_color [25305,25313]
name: ui_color [25305,25313]
===
match
---
name: table_id [91222,91230]
name: table_id [91278,91286]
===
match
---
name: Optional [74048,74056]
name: Optional [74104,74112]
===
match
---
operator: = [47814,47815]
operator: = [47870,47871]
===
match
---
trailer [50556,50572]
trailer [50612,50628]
===
match
---
suite [56682,57105]
suite [56738,57161]
===
match
---
atom_expr [13106,13119]
atom_expr [13106,13119]
===
match
---
name: google [1465,1471]
name: google [1465,1471]
===
match
---
trailer [18337,18346]
trailer [18337,18346]
===
match
---
param [81424,81433]
param [81480,81489]
===
match
---
expr_stmt [78640,78698]
expr_stmt [78696,78754]
===
match
---
name: template_fields_renderers [84680,84705]
name: template_fields_renderers [84736,84761]
===
match
---
operator: , [48254,48255]
operator: , [48310,48311]
===
match
---
name: delegate_to [56539,56550]
name: delegate_to [56595,56606]
===
match
---
arglist [2254,2293]
arglist [2254,2293]
===
match
---
name: str [81249,81252]
name: str [81305,81308]
===
match
---
name: self [2139,2143]
name: self [2139,2143]
===
match
---
atom_expr [51209,51242]
atom_expr [51265,51298]
===
match
---
atom_expr [56615,56641]
atom_expr [56671,56697]
===
match
---
name: super [31311,31316]
name: super [31367,31372]
===
match
---
operator: = [67270,67271]
operator: = [67326,67327]
===
match
---
name: project_id [95498,95508]
name: project_id [95554,95564]
===
match
---
name: exists_ok [38974,38983]
name: exists_ok [39030,39039]
===
match
---
operator: = [41033,41034]
operator: = [41089,41090]
===
match
---
arglist [97388,97517]
arglist [97444,97573]
===
match
---
operator: , [56262,56263]
operator: , [56318,56319]
===
match
---
trailer [7166,7170]
trailer [7166,7170]
===
match
---
trailer [29921,29941]
trailer [29977,29997]
===
match
---
suite [28476,31271]
suite [28532,31327]
===
match
---
arglist [81557,81739]
arglist [81613,81795]
===
match
---
argument [3293,3315]
argument [3293,3315]
===
match
---
tfpdef [96623,96639]
tfpdef [96679,96695]
===
match
---
name: dict [48333,48337]
name: dict [48389,48393]
===
match
---
atom_expr [90540,90555]
atom_expr [90596,90611]
===
match
---
name: Optional [38721,38729]
name: Optional [38777,38785]
===
match
---
trailer [26817,26837]
trailer [26817,26837]
===
match
---
name: max_bad_records [47973,47988]
name: max_bad_records [48029,48044]
===
match
---
param [74120,74162]
param [74176,74218]
===
match
---
trailer [95246,95251]
trailer [95302,95307]
===
match
---
atom_expr [82436,82463]
atom_expr [82492,82519]
===
match
---
operator: = [70036,70037]
operator: = [70092,70093]
===
match
---
trailer [61332,61521]
trailer [61388,61577]
===
match
---
name: context [56665,56672]
name: context [56721,56728]
===
match
---
operator: , [38742,38743]
operator: , [38798,38799]
===
match
---
name: table_resource [39779,39793]
name: table_resource [39835,39849]
===
match
---
name: self [40647,40651]
name: self [40703,40707]
===
match
---
atom_expr [2624,2634]
atom_expr [2624,2634]
===
match
---
trailer [82129,82133]
trailer [82185,82189]
===
match
---
fstring_end: " [97112,97113]
fstring_end: " [97168,97169]
===
match
---
trailer [70861,70870]
trailer [70917,70926]
===
match
---
trailer [9345,9351]
trailer [9345,9351]
===
match
---
trailer [98700,98830]
trailer [98756,98886]
===
match
---
operator: , [81081,81082]
operator: , [81137,81138]
===
match
---
name: Dict [38787,38791]
name: Dict [38843,38847]
===
match
---
atom_expr [70038,70068]
atom_expr [70094,70124]
===
match
---
param [64014,64047]
param [64070,64103]
===
match
---
operator: = [1930,1931]
operator: = [1930,1931]
===
match
---
atom_expr [71012,71028]
atom_expr [71068,71084]
===
match
---
if_stmt [85252,85556]
if_stmt [85308,85612]
===
match
---
trailer [78740,78910]
trailer [78796,78966]
===
match
---
operator: = [81335,81336]
operator: = [81391,81392]
===
match
---
atom_expr [29136,29160]
atom_expr [29192,29216]
===
match
---
trailer [48604,48613]
trailer [48660,48669]
===
match
---
operator: , [38248,38249]
operator: , [38304,38305]
===
match
---
trailer [26072,26077]
trailer [26072,26077]
===
match
---
simple_stmt [60838,60869]
simple_stmt [60894,60925]
===
match
---
name: delegate_to [74171,74182]
name: delegate_to [74227,74238]
===
match
---
expr_stmt [60015,60056]
expr_stmt [60071,60112]
===
match
---
name: dataset_resource [78776,78792]
name: dataset_resource [78832,78848]
===
match
---
name: job_id [98261,98267]
name: job_id [98317,98323]
===
match
---
name: str [67070,67073]
name: str [67126,67129]
===
match
---
name: bool [90046,90050]
name: bool [90102,90106]
===
match
---
operator: , [13556,13557]
operator: , [13556,13557]
===
match
---
operator: { [97241,97242]
operator: { [97297,97298]
===
match
---
atom_expr [95755,95774]
atom_expr [95811,95830]
===
match
---
operator: , [26270,26271]
operator: , [26270,26271]
===
match
---
simple_stmt [98570,98588]
simple_stmt [98626,98644]
===
match
---
atom [94747,94772]
atom [94803,94828]
===
match
---
atom_expr [86312,86331]
atom_expr [86368,86387]
===
match
---
name: project_id [67195,67205]
name: project_id [67251,67261]
===
match
---
expr_stmt [50552,50596]
expr_stmt [50608,50652]
===
match
---
name: ui_color [63895,63903]
name: ui_color [63951,63959]
===
match
---
trailer [28031,28038]
trailer [28087,28094]
===
match
---
atom_expr [61749,61762]
atom_expr [61805,61818]
===
match
---
name: project_id [60151,60161]
name: project_id [60207,60217]
===
match
---
trailer [98689,98700]
trailer [98745,98756]
===
match
---
simple_stmt [95480,95509]
simple_stmt [95536,95565]
===
match
---
return_stmt [74887,75121]
return_stmt [74943,75177]
===
match
---
name: self [91130,91134]
name: self [91186,91190]
===
match
---
name: project_id [86361,86371]
name: project_id [86417,86427]
===
match
---
name: dataset_id [64785,64795]
name: dataset_id [64841,64851]
===
match
---
parameters [25676,26870]
parameters [25676,26870]
===
match
---
atom_expr [26421,26435]
atom_expr [26421,26435]
===
match
---
simple_stmt [28397,28444]
simple_stmt [28453,28500]
===
match
---
atom_expr [48728,48746]
atom_expr [48784,48802]
===
match
---
trailer [18370,18390]
trailer [18370,18390]
===
match
---
trailer [51742,51776]
trailer [51798,51832]
===
match
---
trailer [61555,61576]
trailer [61611,61632]
===
match
---
name: warn [17823,17827]
name: warn [17823,17827]
===
match
---
param [38515,38574]
param [38571,38630]
===
match
---
atom_expr [18183,18199]
atom_expr [18183,18199]
===
match
---
trailer [9934,9986]
trailer [9934,9986]
===
match
---
name: self [64847,64851]
name: self [64903,64907]
===
match
---
operator: { [61093,61094]
operator: { [61149,61150]
===
match
---
trailer [10115,10130]
trailer [10115,10130]
===
match
---
name: schema_fields [52300,52313]
name: schema_fields [52356,52369]
===
match
---
fstring_start: f" [97190,97192]
fstring_start: f" [97246,97248]
===
match
---
operator: , [37840,37841]
operator: , [37896,37897]
===
match
---
name: context [64514,64521]
name: context [64570,64577]
===
match
---
trailer [64730,64796]
trailer [64786,64852]
===
match
---
operator: = [67356,67357]
operator: = [67412,67413]
===
match
---
name: self [90905,90909]
name: self [90961,90965]
===
match
---
parameters [81056,81439]
parameters [81112,81495]
===
match
---
name: impersonation_chain [9654,9673]
name: impersonation_chain [9654,9673]
===
match
---
name: self [28056,28060]
name: self [28112,28116]
===
match
---
name: warn [60607,60611]
name: warn [60663,60667]
===
match
---
expr_stmt [9283,9307]
expr_stmt [9283,9307]
===
match
---
operator: , [74295,74296]
operator: , [74351,74352]
===
match
---
name: attr [2536,2540]
name: attr [2536,2540]
===
match
---
name: self [61649,61653]
name: self [61705,61709]
===
match
---
expr_stmt [70760,70790]
expr_stmt [70816,70846]
===
match
---
trailer [51797,51816]
trailer [51853,51872]
===
match
---
trailer [85606,85621]
trailer [85662,85677]
===
match
---
atom_expr [40045,40061]
atom_expr [40101,40117]
===
match
---
operator: , [12891,12892]
operator: , [12891,12892]
===
match
---
name: selected_fields [18213,18228]
name: selected_fields [18213,18228]
===
match
---
operator: , [12693,12694]
operator: , [12693,12694]
===
match
---
trailer [82283,82295]
trailer [82339,82351]
===
match
---
atom_expr [60455,60480]
atom_expr [60511,60536]
===
match
---
atom_expr [96376,96391]
atom_expr [96432,96447]
===
match
---
name: self [67778,67782]
name: self [67834,67838]
===
match
---
name: self [78432,78436]
name: self [78488,78492]
===
match
---
atom_expr [19034,19086]
atom_expr [19034,19086]
===
match
---
trailer [81534,81539]
trailer [81590,81595]
===
match
---
operator: = [12818,12819]
operator: = [12818,12819]
===
match
---
dotted_name [1138,1159]
dotted_name [1138,1159]
===
match
---
name: gcp_conn_id [56834,56845]
name: gcp_conn_id [56890,56901]
===
match
---
atom_expr [3002,3053]
atom_expr [3002,3053]
===
match
---
name: isinstance [25449,25459]
name: isinstance [25449,25459]
===
match
---
atom_expr [89882,89910]
atom_expr [89938,89966]
===
match
---
string: "json" [77627,77633]
string: "json" [77683,77689]
===
match
---
trailer [48371,48377]
trailer [48427,48433]
===
match
---
operator: = [81408,81409]
operator: = [81464,81465]
===
match
---
operator: = [28112,28113]
operator: = [28168,28169]
===
match
---
suite [61844,62023]
suite [61900,62079]
===
match
---
operator: , [47594,47595]
operator: , [47650,47651]
===
match
---
if_stmt [51054,51518]
if_stmt [51110,51574]
===
match
---
name: context [90797,90804]
name: context [90853,90860]
===
match
---
name: job [97949,97952]
name: job [98005,98008]
===
match
---
name: self [50390,50394]
name: self [50446,50450]
===
match
---
name: table_id [51930,51938]
name: table_id [51986,51994]
===
match
---
name: project_id [78822,78832]
name: project_id [78878,78888]
===
match
---
trailer [78821,78832]
trailer [78877,78888]
===
match
---
argument [95357,95365]
argument [95413,95421]
===
match
---
operator: = [60227,60228]
operator: = [60283,60284]
===
match
---
atom_expr [60878,60893]
atom_expr [60934,60949]
===
match
---
param [55718,55751]
param [55774,55807]
===
match
---
atom_expr [19076,19085]
atom_expr [19076,19085]
===
match
---
name: Optional [77783,77791]
name: Optional [77839,77847]
===
match
---
operator: , [90006,90007]
operator: , [90062,90063]
===
match
---
atom_expr [85040,85053]
atom_expr [85096,85109]
===
match
---
name: self [97326,97330]
name: self [97382,97386]
===
match
---
name: Optional [84898,84906]
name: Optional [84954,84962]
===
match
---
operator: = [50713,50714]
operator: = [50769,50770]
===
match
---
name: Optional [90121,90129]
name: Optional [90177,90185]
===
match
---
string: 'labels' [9263,9271]
string: 'labels' [9263,9271]
===
match
---
atom_expr [56481,56497]
atom_expr [56537,56553]
===
match
---
name: ti [2786,2788]
name: ti [2786,2788]
===
match
---
operator: , [74204,74205]
operator: , [74260,74261]
===
match
---
name: self [78504,78508]
name: self [78560,78564]
===
match
---
name: uuid4 [96866,96871]
name: uuid4 [96922,96927]
===
match
---
simple_stmt [85565,85594]
simple_stmt [85621,85650]
===
match
---
string: """     Deletes BigQuery tables      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryDeleteTableOperator`      :param deletion_dataset_table: A dotted         ``(<project>.|<project>:)<dataset>.<table>`` that indicates which table         will be deleted. (templated)     :type deletion_dataset_table: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param ignore_if_missing: if True, then return success even if the         requested table does not exist.     :type ignore_if_missing: bool     :param location: The location used for the operation.     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [79003,80898]
string: """     Deletes BigQuery tables      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryDeleteTableOperator`      :param deletion_dataset_table: A dotted         ``(<project>.|<project>:)<dataset>.<table>`` that indicates which table         will be deleted. (templated)     :type deletion_dataset_table: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param ignore_if_missing: if True, then return success even if the         requested table does not exist.     :type ignore_if_missing: bool     :param location: The location used for the operation.     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [79059,80954]
===
match
---
subscriptlist [6819,6837]
subscriptlist [6819,6837]
===
match
---
atom_expr [74842,74866]
atom_expr [74898,74922]
===
match
---
name: str [38879,38882]
name: str [38935,38938]
===
match
---
name: self [40885,40889]
name: self [40941,40945]
===
match
---
name: impersonation_chain [74606,74625]
name: impersonation_chain [74662,74681]
===
match
---
trailer [26557,26563]
trailer [26557,26563]
===
match
---
argument [18014,18026]
argument [18014,18026]
===
match
---
simple_stmt [51378,51457]
simple_stmt [51434,51513]
===
match
---
atom_expr [40267,40305]
atom_expr [40323,40361]
===
match
---
operator: , [48967,48968]
operator: , [49023,49024]
===
match
---
name: max_results [17378,17389]
name: max_results [17378,17389]
===
match
---
name: source_objects [48688,48702]
name: source_objects [48744,48758]
===
match
---
name: run_query [28927,28936]
name: run_query [28983,28992]
===
match
---
trailer [96556,96558]
trailer [96612,96614]
===
match
---
name: project_id [40788,40798]
name: project_id [40844,40854]
===
match
---
argument [97865,97887]
argument [97921,97943]
===
match
---
expr_stmt [50138,50176]
expr_stmt [50194,50232]
===
match
---
operator: , [52616,52617]
operator: , [52672,52673]
===
match
---
name: set [26385,26388]
name: set [26385,26388]
===
match
---
name: template_fields [55494,55509]
name: template_fields [55550,55565]
===
match
---
number: 2 [49661,49662]
number: 2 [49717,49718]
===
match
---
argument [28758,28780]
argument [28814,28836]
===
match
---
name: materialized_view [41139,41156]
name: materialized_view [41195,41212]
===
match
---
operator: , [51350,51351]
operator: , [51406,51407]
===
match
---
operator: = [26505,26506]
operator: = [26505,26506]
===
match
---
string: 'Upserting Dataset: %s with table_resource: %s' [85905,85952]
string: 'Upserting Dataset: %s with table_resource: %s' [85961,86008]
===
match
---
name: str [90266,90269]
name: str [90322,90325]
===
match
---
atom_expr [95556,95572]
atom_expr [95612,95628]
===
match
---
simple_stmt [27606,27645]
simple_stmt [27662,27701]
===
match
---
atom_expr [26751,26765]
atom_expr [26751,26765]
===
match
---
simple_stmt [25404,25438]
simple_stmt [25404,25438]
===
match
---
trailer [17822,17827]
trailer [17822,17827]
===
match
---
trailer [56485,56497]
trailer [56541,56553]
===
match
---
name: gcs_hook [51405,51413]
name: gcs_hook [51461,51469]
===
match
---
operator: } [73814,73815]
operator: } [73870,73871]
===
match
---
expr_stmt [78333,78379]
expr_stmt [78389,78435]
===
match
---
simple_stmt [81867,81898]
simple_stmt [81923,81954]
===
match
---
trailer [64676,64696]
trailer [64732,64752]
===
match
---
name: time_partitioning [29677,29694]
name: time_partitioning [29733,29750]
===
match
---
trailer [25594,25598]
trailer [25594,25598]
===
match
---
operator: , [12716,12717]
operator: , [12716,12717]
===
match
---
argument [52422,52450]
argument [52478,52506]
===
match
---
name: kwargs [74653,74659]
name: kwargs [74709,74715]
===
match
---
operator: , [69923,69924]
operator: , [69979,69980]
===
match
---
argument [30023,30028]
argument [30079,30084]
===
match
---
param [25746,25794]
param [25746,25794]
===
match
---
atom_expr [90614,90630]
atom_expr [90670,90686]
===
match
---
tfpdef [38665,38685]
tfpdef [38721,38741]
===
match
---
name: str [64129,64132]
name: str [64185,64188]
===
match
---
trailer [74499,74514]
trailer [74555,74570]
===
match
---
trailer [64767,64778]
trailer [64823,64834]
===
match
---
name: from_string [51726,51737]
name: from_string [51782,51793]
===
match
---
simple_stmt [78388,78415]
simple_stmt [78444,78471]
===
match
---
param [55799,55841]
param [55855,55897]
===
match
---
expr_stmt [50185,50223]
expr_stmt [50241,50279]
===
match
---
name: self [61400,61404]
name: self [61456,61460]
===
match
---
argument [9816,9823]
argument [9816,9823]
===
match
---
operator: = [81968,81969]
operator: = [82024,82025]
===
match
---
operator: = [96413,96414]
operator: = [96469,96470]
===
match
---
name: delegate_to [90244,90255]
name: delegate_to [90300,90311]
===
match
---
name: Optional [70190,70198]
name: Optional [70246,70254]
===
match
---
string: 'google_cloud_default' [17476,17498]
string: 'google_cloud_default' [17476,17498]
===
match
---
name: download [51414,51422]
name: download [51470,51478]
===
match
---
name: value [84773,84778]
name: value [84829,84834]
===
match
---
trailer [64835,64891]
trailer [64891,64947]
===
match
---
trailer [25781,25786]
trailer [25781,25786]
===
match
---
name: task_id [2817,2824]
name: task_id [2817,2824]
===
match
---
name: self [60878,60882]
name: self [60934,60938]
===
match
---
param [81227,81261]
param [81283,81317]
===
match
---
trailer [41463,41474]
trailer [41519,41530]
===
match
---
name: bq_hook [74894,74901]
name: bq_hook [74950,74957]
===
match
---
param [17599,17630]
param [17599,17630]
===
match
---
string: "The bigquery_conn_id parameter has been deprecated. You should pass " [60629,60699]
string: "The bigquery_conn_id parameter has been deprecated. You should pass " [60685,60755]
===
match
---
operator: , [49662,49663]
operator: , [49718,49719]
===
match
---
name: dataset_id [84831,84841]
name: dataset_id [84887,84897]
===
match
---
operator: , [19074,19075]
operator: , [19074,19075]
===
match
---
trailer [78249,78266]
trailer [78305,78322]
===
match
---
name: Optional [25872,25880]
name: Optional [25872,25880]
===
match
---
name: table_resource [86317,86331]
name: table_resource [86373,86387]
===
match
---
name: get_link [2130,2138]
name: get_link [2130,2138]
===
match
---
name: warn [56089,56093]
name: warn [56145,56149]
===
match
---
param [94858,94888]
param [94914,94944]
===
match
---
name: self [51499,51503]
name: self [51555,51559]
===
match
---
name: dataset_reference [61875,61892]
name: dataset_reference [61931,61948]
===
match
---
expr_stmt [90507,90531]
expr_stmt [90563,90587]
===
match
---
trailer [18569,18581]
trailer [18569,18581]
===
match
---
operator: , [41345,41346]
operator: , [41401,41402]
===
match
---
name: gcp_conn_id [82225,82236]
name: gcp_conn_id [82281,82292]
===
match
---
param [26530,26571]
param [26530,26571]
===
match
---
suite [67131,67413]
suite [67187,67469]
===
match
---
name: bq_hook [50828,50835]
name: bq_hook [50884,50891]
===
match
---
name: self [10039,10043]
name: self [10039,10043]
===
match
---
string: 'ds' [12981,12985]
string: 'ds' [12981,12985]
===
match
---
operator: = [38610,38611]
operator: = [38666,38667]
===
match
---
argument [61638,61664]
argument [61694,61720]
===
match
---
atom_expr [48808,49299]
atom_expr [48864,49355]
===
match
---
name: _job_id [97576,97583]
name: _job_id [97632,97639]
===
match
---
trailer [2187,2223]
trailer [2187,2223]
===
match
---
simple_stmt [51790,52018]
simple_stmt [51846,52074]
===
match
---
atom_expr [41222,41251]
atom_expr [41278,41307]
===
match
---
name: bool [81289,81293]
name: bool [81345,81349]
===
match
---
name: template_fields_renderers [89805,89830]
name: template_fields_renderers [89861,89886]
===
match
---
name: TaskInstance [2175,2187]
name: TaskInstance [2175,2187]
===
match
---
atom_expr [77751,77765]
atom_expr [77807,77821]
===
match
---
name: warn [26966,26970]
name: warn [26966,26970]
===
match
---
trailer [78046,78051]
trailer [78102,78107]
===
match
---
name: template_ext [25276,25288]
name: template_ext [25276,25288]
===
match
---
trailer [70639,70650]
trailer [70695,70706]
===
match
---
operator: , [9412,9413]
operator: , [9412,9413]
===
match
---
param [48491,48555]
param [48547,48611]
===
match
---
operator: = [84912,84913]
operator: = [84968,84969]
===
match
---
operator: = [13745,13746]
operator: = [13745,13746]
===
match
---
atom_expr [64875,64890]
atom_expr [64931,64946]
===
match
---
operator: = [78156,78157]
operator: = [78212,78213]
===
match
---
name: project_id [66855,66865]
name: project_id [66911,66921]
===
match
---
argument [40876,40898]
argument [40932,40954]
===
match
---
operator: , [47306,47307]
operator: , [47362,47363]
===
match
---
name: bq_hook [40744,40751]
name: bq_hook [40800,40807]
===
match
---
name: self [9379,9383]
name: self [9379,9383]
===
match
---
trailer [98097,98102]
trailer [98153,98158]
===
match
---
tfpdef [60283,60299]
tfpdef [60339,60355]
===
match
---
string: "json" [60003,60009]
string: "json" [60059,60065]
===
match
---
name: impersonation_chain [90935,90954]
name: impersonation_chain [90991,91010]
===
match
---
name: table_id [75048,75056]
name: table_id [75104,75112]
===
match
---
suite [2705,3054]
suite [2705,3054]
===
match
---
name: deletion_dataset_table [82441,82463]
name: deletion_dataset_table [82497,82519]
===
match
---
simple_stmt [28027,28048]
simple_stmt [28083,28104]
===
match
---
name: dttm [2689,2693]
name: dttm [2689,2693]
===
match
---
arglist [85316,85498]
arglist [85372,85554]
===
match
---
atom_expr [89986,90006]
atom_expr [90042,90062]
===
match
---
trailer [30855,30876]
trailer [30911,30932]
===
match
---
operator: , [95007,95008]
operator: , [95063,95064]
===
match
---
testlist_comp [55522,55588]
testlist_comp [55578,55644]
===
match
---
name: labels [3387,3393]
name: labels [3387,3393]
===
match
---
name: bool [26153,26157]
name: bool [26153,26157]
===
match
---
operator: = [18793,18794]
operator: = [18793,18794]
===
match
---
operator: = [51271,51272]
operator: = [51327,51328]
===
match
---
name: self [73887,73891]
name: self [73943,73947]
===
match
---
name: schema_update_options [29548,29569]
name: schema_update_options [29604,29625]
===
match
---
atom_expr [26248,26263]
atom_expr [26248,26263]
===
match
---
string: 'google_cloud_default' [48164,48186]
string: 'google_cloud_default' [48220,48242]
===
match
---
tfpdef [60382,60408]
tfpdef [60438,60464]
===
match
---
operator: { [98294,98295]
operator: { [98350,98351]
===
match
---
name: operator [2145,2153]
name: operator [2145,2153]
===
match
---
trailer [40049,40061]
trailer [40105,40117]
===
match
---
trailer [40579,40603]
trailer [40635,40659]
===
match
---
operator: , [38505,38506]
operator: , [38561,38562]
===
match
---
atom_expr [10211,10222]
atom_expr [10211,10222]
===
match
---
expr_stmt [95556,95586]
expr_stmt [95612,95642]
===
match
---
name: impersonation_chain [26782,26801]
name: impersonation_chain [26782,26801]
===
match
---
name: project_id [91244,91254]
name: project_id [91300,91310]
===
match
---
operator: , [49035,49036]
operator: , [49091,49092]
===
match
---
name: str [9704,9707]
name: str [9704,9707]
===
match
---
simple_stmt [50828,51045]
simple_stmt [50884,51101]
===
match
---
name: hooks [1478,1483]
name: hooks [1478,1483]
===
match
---
string: """     Performs a simple value check using sql code.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryValueCheckOperator`      :param sql: the sql to be executed     :type sql: str     :param use_legacy_sql: Whether to use legacy SQL (true)         or standard SQL (false).     :type use_legacy_sql: bool     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param location: The geographic location of the job. See details at:         https://cloud.google.com/bigquery/docs/locations#specifying_your_location     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     :param labels: a dictionary containing labels for the table, passed to BigQuery     :type labels: dict     """ [7424,9138]
string: """     Performs a simple value check using sql code.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryValueCheckOperator`      :param sql: the sql to be executed     :type sql: str     :param use_legacy_sql: Whether to use legacy SQL (true)         or standard SQL (false).     :type use_legacy_sql: bool     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param location: The geographic location of the job. See details at:         https://cloud.google.com/bigquery/docs/locations#specifying_your_location     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     :param labels: a dictionary containing labels for the table, passed to BigQuery     :type labels: dict     """ [7424,9138]
===
match
---
name: bigquery_conn_id [10013,10029]
name: bigquery_conn_id [10013,10029]
===
match
---
name: TABLE [89899,89904]
name: TABLE [89955,89960]
===
match
---
param [89963,90007]
param [90019,90063]
===
match
---
simple_stmt [96845,96875]
simple_stmt [96901,96931]
===
match
---
simple_stmt [13845,13892]
simple_stmt [13845,13892]
===
match
---
atom_expr [2241,2294]
atom_expr [2241,2294]
===
match
---
tfpdef [84831,84846]
tfpdef [84887,84902]
===
match
---
expr_stmt [90393,90443]
expr_stmt [90449,90499]
===
match
---
atom_expr [67778,67794]
atom_expr [67834,67850]
===
match
---
expr_stmt [64331,64361]
expr_stmt [64387,64417]
===
match
---
name: self [18366,18370]
name: self [18366,18370]
===
match
---
simple_stmt [78640,78699]
simple_stmt [78696,78755]
===
match
---
name: BigQueryUIColors [89882,89898]
name: BigQueryUIColors [89938,89954]
===
match
---
operator: = [25137,25138]
operator: = [25137,25138]
===
match
---
simple_stmt [90653,90684]
simple_stmt [90709,90740]
===
match
---
name: rows [19134,19138]
name: rows [19134,19138]
===
match
---
fstring_string: airflow_ [97192,97200]
fstring_string: airflow_ [97248,97256]
===
match
---
operator: , [77987,77988]
operator: , [78043,78044]
===
match
---
string: 'project_id' [73706,73718]
string: 'project_id' [73762,73774]
===
match
---
expr_stmt [39438,39517]
expr_stmt [39494,39573]
===
match
---
atom_expr [52230,52268]
atom_expr [52286,52324]
===
match
---
atom_expr [91130,91154]
atom_expr [91186,91210]
===
match
---
suite [81513,81797]
suite [81569,81853]
===
match
---
string: 'project_id' [77523,77535]
string: 'project_id' [77579,77591]
===
match
---
name: bigquery_conn_id [50881,50897]
name: bigquery_conn_id [50937,50953]
===
match
---
argument [86122,86144]
argument [86178,86200]
===
match
---
suite [9908,10030]
suite [9908,10030]
===
match
---
operator: , [81672,81673]
operator: , [81728,81729]
===
match
---
simple_stmt [6468,6493]
simple_stmt [6468,6493]
===
match
---
name: str [13115,13118]
name: str [13115,13118]
===
match
---
trailer [64199,64204]
trailer [64255,64260]
===
match
---
operator: = [29193,29194]
operator: = [29249,29250]
===
match
---
operator: = [39889,39890]
operator: = [39945,39946]
===
match
---
operator: ** [81424,81426]
operator: ** [81480,81482]
===
match
---
operator: = [48291,48292]
operator: = [48347,48348]
===
match
---
name: api_resource_configs [29712,29732]
name: api_resource_configs [29768,29788]
===
match
---
trailer [98480,98486]
trailer [98536,98542]
===
match
---
operator: = [26158,26159]
operator: = [26158,26159]
===
match
---
operator: = [52771,52772]
operator: = [52827,52828]
===
match
---
operator: , [30028,30029]
operator: , [30084,30085]
===
match
---
name: str [55705,55708]
name: str [55761,55764]
===
match
---
name: kwargs [56634,56640]
name: kwargs [56690,56696]
===
match
---
trailer [61704,61722]
trailer [61760,61778]
===
match
---
operator: , [63830,63831]
operator: , [63886,63887]
===
match
---
name: BigQueryUIColors [60026,60042]
name: BigQueryUIColors [60082,60098]
===
match
---
trailer [84766,84772]
trailer [84822,84828]
===
match
---
name: schema_fields [40652,40665]
name: schema_fields [40708,40721]
===
match
---
atom_expr [31375,31416]
atom_expr [31431,31472]
===
match
---
string: "json" [47422,47428]
string: "json" [47478,47484]
===
match
---
name: BaseOperator [82538,82550]
name: BaseOperator [82594,82606]
===
match
---
trailer [85088,85093]
trailer [85144,85149]
===
match
---
name: str [25822,25825]
name: str [25822,25825]
===
match
---
name: self [2624,2628]
name: self [2624,2628]
===
match
---
operator: = [56290,56291]
operator: = [56346,56347]
===
match
---
parameters [78431,78446]
parameters [78487,78502]
===
match
---
atom_expr [6928,6963]
atom_expr [6928,6963]
===
match
---
operator: , [2153,2154]
operator: , [2153,2154]
===
match
---
string: 'dataset_id' [89708,89720]
string: 'dataset_id' [89764,89776]
===
match
---
trailer [96418,96427]
trailer [96474,96483]
===
match
---
simple_stmt [31102,31200]
simple_stmt [31158,31256]
===
match
---
name: str [81330,81333]
name: str [81386,81389]
===
match
---
name: max_results [18916,18927]
name: max_results [18916,18927]
===
match
---
suite [67857,71279]
suite [67913,71335]
===
match
---
operator: , [49002,49003]
operator: , [49058,49059]
===
match
---
expr_stmt [73761,73815]
expr_stmt [73817,73871]
===
match
---
simple_stmt [78140,78169]
simple_stmt [78196,78225]
===
match
---
name: Optional [26460,26468]
name: Optional [26460,26468]
===
match
---
trailer [39187,39201]
trailer [39243,39257]
===
match
---
trailer [96019,96028]
trailer [96075,96084]
===
match
---
name: Sequence [48532,48540]
name: Sequence [48588,48596]
===
match
---
simple_stmt [85795,85842]
simple_stmt [85851,85898]
===
match
---
operator: -> [85874,85876]
operator: -> [85930,85932]
===
match
---
param [39924,39931]
param [39980,39987]
===
match
---
argument [91208,91230]
argument [91264,91286]
===
match
---
operator: = [30271,30272]
operator: = [30327,30328]
===
match
---
name: stacklevel [60798,60808]
name: stacklevel [60854,60864]
===
match
---
atom_expr [74427,74438]
atom_expr [74483,74494]
===
match
---
name: self [30733,30737]
name: self [30789,30793]
===
match
---
simple_stmt [9312,9352]
simple_stmt [9312,9352]
===
match
---
atom_expr [70970,70986]
atom_expr [71026,71042]
===
match
---
name: compression [48956,48967]
name: compression [49012,49023]
===
match
---
trailer [9703,9708]
trailer [9703,9708]
===
match
---
trailer [52390,52404]
trailer [52446,52460]
===
match
---
raise_stmt [49736,49824]
raise_stmt [49792,49880]
===
match
---
subscriptlist [90323,90341]
subscriptlist [90379,90397]
===
match
---
trailer [96865,96871]
trailer [96921,96927]
===
match
---
simple_stmt [89805,89867]
simple_stmt [89861,89923]
===
match
---
parameters [55658,56029]
parameters [55714,56085]
===
match
---
name: Union [26366,26371]
name: Union [26366,26371]
===
match
---
operator: = [90521,90522]
operator: = [90577,90578]
===
match
---
operator: , [13501,13502]
operator: , [13501,13502]
===
match
---
name: delegate_to [61388,61399]
name: delegate_to [61444,61455]
===
match
---
name: dataset_id [67145,67155]
name: dataset_id [67201,67211]
===
match
---
tfpdef [13173,13196]
tfpdef [13173,13196]
===
match
---
operator: , [64596,64597]
operator: , [64652,64653]
===
match
---
trailer [25929,25935]
trailer [25929,25935]
===
match
---
operator: = [85740,85741]
operator: = [85796,85797]
===
match
---
simple_stmt [26888,26915]
simple_stmt [26888,26915]
===
match
---
string: """     This operator is used to return the dataset specified by dataset_id.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryGetDatasetOperator`      :param dataset_id: The id of dataset. Don't need to provide,         if datasetId in dataset_reference.     :type dataset_id: str     :param project_id: The name of the project where we want to create the dataset.         Don't need to provide, if projectId in dataset_reference.     :type project_id: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]      :rtype: dataset         https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets#resource     """ [62077,63784]
string: """     This operator is used to return the dataset specified by dataset_id.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryGetDatasetOperator`      :param dataset_id: The id of dataset. Don't need to provide,         if datasetId in dataset_reference.     :type dataset_id: str     :param project_id: The name of the project where we want to create the dataset.         Don't need to provide, if projectId in dataset_reference.     :type project_id: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]      :rtype: dataset         https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets#resource     """ [62133,63840]
===
match
---
suite [52031,52972]
suite [52087,53028]
===
match
---
atom_expr [71206,71227]
atom_expr [71262,71283]
===
match
---
name: flatten_results [29199,29214]
name: flatten_results [29255,29270]
===
match
---
simple_stmt [50439,50504]
simple_stmt [50495,50560]
===
match
---
tfpdef [38360,38392]
tfpdef [38416,38448]
===
match
---
name: self [61938,61942]
name: self [61994,61998]
===
match
---
operator: = [1709,1710]
operator: = [1709,1710]
===
match
---
simple_stmt [28572,28858]
simple_stmt [28628,28914]
===
match
---
name: bucket [48659,48665]
name: bucket [48715,48721]
===
match
---
tfpdef [60243,60266]
tfpdef [60299,60322]
===
match
---
string: 'Creating table' [40706,40722]
string: 'Creating table' [40762,40778]
===
match
---
param [81128,81170]
param [81184,81226]
===
match
---
name: location [95434,95442]
name: location [95490,95498]
===
match
---
operator: = [18391,18392]
operator: = [18391,18392]
===
match
---
name: maximum_billing_tier [27818,27838]
name: maximum_billing_tier [27874,27894]
===
match
---
simple_stmt [61143,61190]
simple_stmt [61199,61246]
===
match
---
operator: = [51640,51641]
operator: = [51696,51697]
===
match
---
name: gcp_conn_id [3220,3231]
name: gcp_conn_id [3220,3231]
===
match
---
operator: , [94677,94678]
operator: , [94733,94734]
===
match
---
operator: = [26564,26565]
operator: = [26564,26565]
===
match
---
classdef [86385,91282]
classdef [86441,91338]
===
match
---
name: impersonation_chain [90697,90716]
name: impersonation_chain [90753,90772]
===
match
---
name: field_delimiter [50143,50158]
name: field_delimiter [50199,50214]
===
match
---
name: str [55739,55742]
name: str [55795,55798]
===
match
---
name: impersonation_chain [74847,74866]
name: impersonation_chain [74903,74922]
===
match
---
name: location [61754,61762]
name: location [61810,61818]
===
match
---
operator: = [80920,80921]
operator: = [80976,80977]
===
match
---
name: str [95983,95986]
name: str [96039,96042]
===
match
---
operator: , [41089,41090]
operator: , [41145,41146]
===
match
---
name: source_uris [52343,52354]
name: source_uris [52399,52410]
===
match
---
suite [28506,28858]
suite [28562,28914]
===
match
---
trailer [90544,90555]
trailer [90600,90611]
===
match
---
operator: = [9598,9599]
operator: = [9598,9599]
===
match
---
operator: = [7205,7206]
operator: = [7205,7206]
===
match
---
name: reattach_states [97967,97982]
name: reattach_states [98023,98038]
===
match
---
comp_op [31350,31356]
comp_op [31406,31412]
===
match
---
expr_stmt [2232,2294]
expr_stmt [2232,2294]
===
match
---
name: days_back [12995,13004]
name: days_back [12995,13004]
===
match
---
operator: = [40884,40885]
operator: = [40940,40941]
===
match
---
simple_stmt [67386,67413]
simple_stmt [67442,67469]
===
match
---
operator: , [73718,73719]
operator: , [73774,73775]
===
match
---
name: bool [13152,13156]
name: bool [13152,13156]
===
match
---
param [73912,73943]
param [73968,73999]
===
match
---
operator: , [52848,52849]
operator: , [52904,52905]
===
match
---
trailer [56088,56093]
trailer [56144,56149]
===
match
---
name: maximum_bytes_billed [29366,29386]
name: maximum_bytes_billed [29422,29442]
===
match
---
atom_expr [81945,81967]
atom_expr [82001,82023]
===
match
---
expr_stmt [82192,82400]
expr_stmt [82248,82456]
===
match
---
expr_stmt [28340,28356]
expr_stmt [28396,28412]
===
match
---
simple_stmt [2232,2295]
simple_stmt [2232,2295]
===
match
---
name: to_api_repr [64915,64926]
name: to_api_repr [64971,64982]
===
match
---
name: self [98537,98541]
name: self [98593,98597]
===
match
---
param [70146,70169]
param [70202,70225]
===
match
---
simple_stmt [70672,70703]
simple_stmt [70728,70759]
===
match
---
trailer [2540,2543]
trailer [2540,2543]
===
match
---
operator: = [28256,28257]
operator: = [28312,28313]
===
match
---
fstring_end: " [96768,96769]
fstring_end: " [96824,96825]
===
match
---
name: location [28772,28780]
name: location [28828,28836]
===
match
---
operator: , [17125,17126]
operator: , [17125,17126]
===
match
---
name: self [95634,95638]
name: self [95690,95694]
===
match
---
expr_stmt [39113,39141]
expr_stmt [39169,39197]
===
match
---
atom_expr [71062,71086]
atom_expr [71118,71142]
===
match
---
suite [18453,19166]
suite [18453,19166]
===
match
---
atom_expr [50087,50109]
atom_expr [50143,50165]
===
match
---
expr_stmt [86000,86213]
expr_stmt [86056,86269]
===
match
---
expr_stmt [25276,25300]
expr_stmt [25276,25300]
===
match
---
name: use_legacy_sql [7190,7204]
name: use_legacy_sql [7190,7204]
===
match
---
operator: , [74110,74111]
operator: , [74166,74167]
===
match
---
name: google_cloud_storage_conn_id [48196,48224]
name: google_cloud_storage_conn_id [48252,48280]
===
match
---
name: str [60130,60133]
name: str [60186,60189]
===
match
---
expr_stmt [70027,70068]
expr_stmt [70083,70124]
===
match
---
name: gcp_conn_id [77903,77914]
name: gcp_conn_id [77959,77970]
===
match
---
trailer [10076,10088]
trailer [10076,10088]
===
match
---
operator: * [77722,77723]
operator: * [77778,77779]
===
match
---
import_name [1073,1084]
import_name [1073,1084]
===
match
---
trailer [28822,28842]
trailer [28878,28898]
===
match
---
name: Union [70344,70349]
name: Union [70400,70405]
===
match
---
trailer [81329,81334]
trailer [81385,81390]
===
match
---
name: int [17391,17394]
name: int [17391,17394]
===
match
---
name: self [13900,13904]
name: self [13900,13904]
===
match
---
atom_expr [29623,29636]
atom_expr [29679,29692]
===
match
---
name: self [97832,97836]
name: self [97888,97892]
===
match
---
operator: = [67593,67594]
operator: = [67649,67650]
===
match
---
testlist_comp [94705,94713]
testlist_comp [94761,94769]
===
match
---
operator: } [47428,47429]
operator: } [47484,47485]
===
match
---
name: location [82323,82331]
name: location [82379,82387]
===
match
---
trailer [61609,61620]
trailer [61665,61676]
===
match
---
name: Dict [13303,13307]
name: Dict [13303,13307]
===
match
---
suite [31302,31454]
suite [31358,31510]
===
match
---
param [9404,9413]
param [9404,9413]
===
match
---
operator: , [3315,3316]
operator: , [3315,3316]
===
match
---
operator: , [25233,25234]
operator: , [25233,25234]
===
match
---
param [48355,48385]
param [48411,48441]
===
match
---
operator: ** [78405,78407]
operator: ** [78461,78463]
===
match
---
string: 'labels' [12789,12797]
string: 'labels' [12789,12797]
===
match
---
atom_expr [96861,96873]
atom_expr [96917,96929]
===
match
---
name: gcs_bucket [40242,40252]
name: gcs_bucket [40298,40308]
===
match
---
name: TABLE [38062,38067]
name: TABLE [38118,38123]
===
match
---
name: AirflowException [1214,1230]
name: AirflowException [1214,1230]
===
match
---
name: BigQueryUIColors [1824,1840]
name: BigQueryUIColors [1824,1840]
===
match
---
operator: , [52508,52509]
operator: , [52564,52565]
===
match
---
expr_stmt [1604,1690]
expr_stmt [1604,1690]
===
match
---
operator: = [82477,82478]
operator: = [82533,82534]
===
match
---
simple_stmt [41729,47151]
simple_stmt [41785,47207]
===
match
---
import_from [1085,1132]
import_from [1085,1132]
===
match
---
string: "This operator is deprecated. Please use BigQueryUpdateDatasetOperator." [70448,70520]
string: "This operator is deprecated. Please use BigQueryUpdateDatasetOperator." [70504,70576]
===
match
---
trailer [27610,27626]
trailer [27666,27682]
===
match
---
name: hook [29987,29991]
name: hook [30043,30047]
===
match
---
simple_stmt [70799,70846]
simple_stmt [70855,70902]
===
match
---
tfpdef [48140,48161]
tfpdef [48196,48217]
===
match
---
name: table_id [40876,40884]
name: table_id [40932,40940]
===
match
---
name: labels [41083,41089]
name: labels [41139,41145]
===
match
---
name: table_resource [41289,41303]
name: table_resource [41345,41359]
===
match
---
trailer [10215,10222]
trailer [10215,10222]
===
match
---
name: template_fields [66631,66646]
name: template_fields [66687,66702]
===
match
---
simple_stmt [96969,97033]
simple_stmt [97025,97089]
===
match
---
name: self [41157,41161]
name: self [41213,41217]
===
match
---
atom_expr [74712,74877]
atom_expr [74768,74933]
===
match
---
simple_stmt [27551,27598]
simple_stmt [27607,27654]
===
match
---
name: encryption_configuration [39663,39687]
name: encryption_configuration [39719,39743]
===
match
---
factor [13025,13027]
factor [13025,13027]
===
match
---
atom_expr [13254,13267]
atom_expr [13254,13267]
===
match
---
expr_stmt [70635,70663]
expr_stmt [70691,70719]
===
match
---
name: GCSHook [1579,1586]
name: GCSHook [1579,1586]
===
match
---
sync_comp_for [31044,31061]
sync_comp_for [31100,31117]
===
match
---
name: table_data [19155,19165]
name: table_data [19155,19165]
===
match
---
name: Optional [26021,26029]
name: Optional [26021,26029]
===
match
---
operator: = [38885,38886]
operator: = [38941,38942]
===
match
---
name: str [94996,94999]
name: str [95052,95055]
===
match
---
name: Optional [26695,26703]
name: Optional [26695,26703]
===
match
---
param [67436,67443]
param [67492,67499]
===
match
---
name: api_resource_configs [29738,29758]
name: api_resource_configs [29794,29814]
===
match
---
name: force_rerun [96820,96831]
name: force_rerun [96876,96887]
===
match
---
tfpdef [38167,38182]
tfpdef [38223,38238]
===
match
---
name: DeprecationWarning [85449,85467]
name: DeprecationWarning [85505,85523]
===
match
---
name: Optional [85080,85088]
name: Optional [85136,85144]
===
match
---
name: self [95992,95996]
name: self [96048,96052]
===
match
---
name: uniqueness_suffix [97094,97111]
name: uniqueness_suffix [97150,97167]
===
match
---
name: hook [97791,97795]
name: hook [97847,97851]
===
match
---
name: execute [56651,56658]
name: execute [56707,56714]
===
match
---
trailer [40570,40579]
trailer [40626,40635]
===
match
---
atom_expr [25872,25886]
atom_expr [25872,25886]
===
match
---
trailer [61362,61374]
trailer [61418,61430]
===
match
---
name: Optional [90037,90045]
name: Optional [90093,90101]
===
match
---
trailer [61653,61664]
trailer [61709,61720]
===
match
---
atom_expr [74943,74962]
atom_expr [74999,75018]
===
match
---
trailer [48602,48604]
trailer [48658,48660]
===
match
---
param [60243,60274]
param [60299,60330]
===
match
---
suite [10318,13921]
suite [10318,13921]
===
match
---
name: configuration [95997,96010]
name: configuration [96053,96066]
===
match
---
simple_stmt [2467,2518]
simple_stmt [2467,2518]
===
match
---
argument [82225,82253]
argument [82281,82309]
===
match
---
name: Optional [55730,55738]
name: Optional [55786,55794]
===
match
---
expr_stmt [60838,60868]
expr_stmt [60894,60924]
===
match
---
operator: = [30675,30676]
operator: = [30731,30732]
===
match
---
name: configuration [96338,96351]
name: configuration [96394,96407]
===
match
---
trailer [40705,40723]
trailer [40761,40779]
===
match
---
return_stmt [96567,96577]
return_stmt [96623,96633]
===
match
---
operator: = [30450,30451]
operator: = [30506,30507]
===
match
---
operator: = [18999,19000]
operator: = [18999,19000]
===
match
---
operator: , [96351,96352]
operator: , [96407,96408]
===
match
---
funcdef [78420,78948]
funcdef [78476,79004]
===
match
---
name: str [9633,9636]
name: str [9633,9636]
===
match
---
atom_expr [48420,48434]
atom_expr [48476,48490]
===
match
---
param [26174,26217]
param [26174,26217]
===
match
---
simple_stmt [29955,31076]
simple_stmt [30011,31132]
===
match
---
trailer [56524,56536]
trailer [56580,56592]
===
match
---
atom_expr [74008,74021]
atom_expr [74064,74077]
===
match
---
funcdef [17283,18413]
funcdef [17283,18413]
===
match
---
atom_expr [96290,96465]
atom_expr [96346,96521]
===
match
---
trailer [52776,52794]
trailer [52832,52850]
===
match
---
simple_stmt [25121,25272]
simple_stmt [25121,25272]
===
match
---
operator: ** [39057,39059]
operator: ** [39113,39115]
===
match
---
if_stmt [28485,28858]
if_stmt [28541,28914]
===
match
---
simple_stmt [50552,50597]
simple_stmt [50608,50653]
===
match
---
operator: = [18145,18146]
operator: = [18145,18146]
===
match
---
operator: = [38344,38345]
operator: = [38400,38401]
===
match
---
expr_stmt [70799,70845]
expr_stmt [70855,70901]
===
match
---
argument [82465,82500]
argument [82521,82556]
===
match
---
suite [41724,52972]
suite [41780,53028]
===
match
---
argument [52866,52884]
argument [52922,52940]
===
match
---
argument [51197,51242]
argument [51253,51298]
===
match
---
name: selected_fields [18941,18956]
name: selected_fields [18941,18956]
===
match
---
argument [74651,74659]
argument [74707,74715]
===
match
---
suite [95881,96142]
suite [95937,96198]
===
match
---
operator: = [77981,77982]
operator: = [78037,78038]
===
match
---
atom_expr [6864,6878]
atom_expr [6864,6878]
===
match
---
expr_stmt [1902,1919]
expr_stmt [1902,1919]
===
match
---
atom_expr [27692,27708]
atom_expr [27748,27764]
===
match
---
operator: = [48747,48748]
operator: = [48803,48804]
===
match
---
trailer [74914,75121]
trailer [74970,75177]
===
match
---
operator: , [52450,52451]
operator: , [52506,52507]
===
match
---
name: impersonation_chain [71042,71061]
name: impersonation_chain [71098,71117]
===
match
---
tfpdef [84886,84911]
tfpdef [84942,84967]
===
match
---
trailer [96051,96071]
trailer [96107,96127]
===
match
---
atom_expr [95227,95252]
atom_expr [95283,95308]
===
match
---
dotted_name [1347,1368]
dotted_name [1347,1368]
===
match
---
trailer [78690,78695]
trailer [78746,78751]
===
match
---
trailer [95638,95654]
trailer [95694,95710]
===
match
---
comparison [28488,28505]
comparison [28544,28561]
===
match
---
trailer [67506,67518]
trailer [67562,67574]
===
match
---
atom_expr [40183,40201]
atom_expr [40239,40257]
===
match
---
operator: = [90344,90345]
operator: = [90400,90401]
===
match
---
name: cluster_fields [41019,41033]
name: cluster_fields [41075,41089]
===
match
---
operator: , [26084,26085]
operator: , [26084,26085]
===
match
---
operator: = [74137,74138]
operator: = [74193,74194]
===
match
---
name: template_fields [37729,37744]
name: template_fields [37785,37800]
===
match
---
param [84856,84877]
param [84912,84933]
===
match
---
name: self [51581,51585]
name: self [51637,51641]
===
match
---
trailer [2339,2346]
trailer [2339,2346]
===
match
---
expr_stmt [12809,12848]
expr_stmt [12809,12848]
===
match
---
operator: -> [48580,48582]
operator: -> [48636,48638]
===
match
---
trailer [13191,13196]
trailer [13191,13196]
===
match
---
simple_stmt [50634,50691]
simple_stmt [50690,50747]
===
match
---
suite [2462,3054]
suite [2462,3054]
===
match
---
name: project_id [64299,64309]
name: project_id [64355,64365]
===
match
---
name: cancel_on_kill [95270,95284]
name: cancel_on_kill [95326,95340]
===
match
---
operator: = [85054,85055]
operator: = [85110,85111]
===
match
---
name: kwargs [85185,85191]
name: kwargs [85241,85247]
===
match
---
name: QUERY [94805,94810]
name: QUERY [94861,94866]
===
match
---
operator: , [61762,61763]
operator: , [61818,61819]
===
match
---
operator: , [70902,70903]
operator: , [70958,70959]
===
match
---
operator: , [64231,64232]
operator: , [64287,64288]
===
match
---
fstring_end: " [98508,98509]
fstring_end: " [98564,98565]
===
match
---
name: src_fmt_configs [52833,52848]
name: src_fmt_configs [52889,52904]
===
match
---
operator: , [71086,71087]
operator: , [71142,71143]
===
match
---
name: Optional [48024,48032]
name: Optional [48080,48088]
===
match
---
operator: = [26391,26392]
operator: = [26391,26392]
===
match
---
expr_stmt [51378,51456]
expr_stmt [51434,51512]
===
match
---
name: float [26257,26262]
name: float [26257,26262]
===
match
---
name: bigquery_conn_id [38459,38475]
name: bigquery_conn_id [38515,38531]
===
match
---
operator: = [9835,9836]
operator: = [9835,9836]
===
match
---
name: bigquery_conn_id [60568,60584]
name: bigquery_conn_id [60624,60640]
===
match
---
name: Optional [85040,85048]
name: Optional [85096,85104]
===
match
---
name: List [77792,77796]
name: List [77848,77852]
===
match
---
name: create_disposition [30498,30516]
name: create_disposition [30554,30572]
===
match
---
operator: = [86311,86312]
operator: = [86367,86368]
===
match
---
trailer [96101,96115]
trailer [96157,96171]
===
match
---
expr_stmt [7185,7221]
expr_stmt [7185,7221]
===
match
---
atom_expr [90863,90879]
atom_expr [90919,90935]
===
match
---
operator: , [59941,59942]
operator: , [59997,59998]
===
match
---
operator: ** [95307,95309]
operator: ** [95363,95365]
===
match
---
expr_stmt [95517,95547]
expr_stmt [95573,95603]
===
match
---
name: max_bad_records [50190,50205]
name: max_bad_records [50246,50261]
===
match
---
atom [52058,52138]
atom [52114,52194]
===
match
---
operator: = [7140,7141]
operator: = [7140,7141]
===
match
---
operator: , [2687,2688]
operator: , [2687,2688]
===
match
---
operator: = [52229,52230]
operator: = [52285,52286]
===
match
---
argument [96405,96427]
argument [96461,96483]
===
match
---
name: warnings [943,951]
name: warnings [943,951]
===
match
---
argument [29116,29160]
argument [29172,29216]
===
match
---
operator: = [78503,78504]
operator: = [78559,78560]
===
match
---
operator: = [48435,48436]
operator: = [48491,48492]
===
match
---
atom_expr [18608,18778]
atom_expr [18608,18778]
===
match
---
operator: } [52078,52079]
operator: } [52134,52135]
===
match
---
name: AirflowException [31108,31124]
name: AirflowException [31164,31180]
===
match
---
argument [29512,29530]
argument [29568,29586]
===
match
---
name: dataset_id [56378,56388]
name: dataset_id [56434,56444]
===
match
---
operator: } [61094,61095]
operator: } [61150,61151]
===
match
---
simple_stmt [70854,70881]
simple_stmt [70910,70937]
===
match
---
trailer [86243,86382]
trailer [86299,86438]
===
match
---
operator: = [81294,81295]
operator: = [81350,81351]
===
match
---
name: dataset_id [60883,60893]
name: dataset_id [60939,60949]
===
match
---
atom_expr [28089,28111]
atom_expr [28145,28167]
===
match
---
operator: , [13640,13641]
operator: , [13640,13641]
===
match
---
name: location [13828,13836]
name: location [13828,13836]
===
match
---
name: warnings [7005,7013]
name: warnings [7005,7013]
===
match
---
atom_expr [98577,98587]
atom_expr [98633,98643]
===
match
---
atom_expr [25590,25598]
atom_expr [25590,25598]
===
match
---
name: execute [78424,78431]
name: execute [78480,78487]
===
match
---
operator: = [26839,26840]
operator: = [26839,26840]
===
match
---
atom_expr [57074,57094]
atom_expr [57130,57150]
===
match
---
operator: , [18531,18532]
operator: , [18531,18532]
===
match
---
name: reattach_states [95051,95066]
name: reattach_states [95107,95122]
===
match
---
tfpdef [38192,38205]
tfpdef [38248,38261]
===
match
---
name: self [3215,3219]
name: self [3215,3219]
===
match
---
atom_expr [81526,81753]
atom_expr [81582,81809]
===
match
---
trailer [78550,78562]
trailer [78606,78618]
===
match
---
name: Optional [17526,17534]
name: Optional [17526,17534]
===
match
---
operator: , [12945,12946]
operator: , [12945,12946]
===
match
---
name: int [13018,13021]
name: int [13018,13021]
===
match
---
name: self [27447,27451]
name: self [27503,27507]
===
match
---
expr_stmt [77473,77573]
expr_stmt [77529,77629]
===
match
---
atom_expr [64331,64347]
atom_expr [64387,64403]
===
match
---
name: google_cloud_storage_conn_id [51214,51242]
name: google_cloud_storage_conn_id [51270,51298]
===
match
---
string: 'google_cloud_default' [25971,25993]
string: 'google_cloud_default' [25971,25993]
===
match
---
name: ignore_if_missing [81970,81987]
name: ignore_if_missing [82026,82043]
===
match
---
name: self [40366,40370]
name: self [40422,40426]
===
match
---
operator: , [78792,78793]
operator: , [78848,78849]
===
match
---
import_as_names [1258,1288]
import_as_names [1258,1288]
===
match
---
name: taskinstance [1309,1321]
name: taskinstance [1309,1321]
===
match
---
tfpdef [70121,70136]
tfpdef [70177,70192]
===
match
---
operator: = [48339,48340]
operator: = [48395,48396]
===
match
---
expr_stmt [96969,97032]
expr_stmt [97025,97088]
===
match
---
arglist [29922,29940]
arglist [29978,29996]
===
match
---
name: self [50138,50142]
name: self [50194,50198]
===
match
---
operator: , [6648,6649]
operator: , [6648,6649]
===
match
---
name: Set [95077,95080]
name: Set [95133,95136]
===
match
---
param [13286,13316]
param [13286,13316]
===
match
---
atom_expr [18872,18885]
atom_expr [18872,18885]
===
match
---
trailer [26970,27154]
trailer [26970,27184]
===
match
---
name: self [41112,41116]
name: self [41168,41172]
===
match
---
atom_expr [56397,56412]
atom_expr [56453,56468]
===
match
---
operator: = [85011,85012]
operator: = [85067,85068]
===
match
---
string: "json" [94765,94771]
string: "json" [94821,94827]
===
match
---
name: max_results [67783,67794]
name: max_results [67839,67850]
===
match
---
name: schema_fields [52286,52299]
name: schema_fields [52342,52355]
===
match
---
expr_stmt [9144,9278]
expr_stmt [9144,9278]
===
match
---
expr_stmt [47156,47370]
expr_stmt [47212,47426]
===
match
---
simple_stmt [70027,70069]
simple_stmt [70083,70125]
===
match
---
operator: = [86049,86050]
operator: = [86105,86106]
===
match
---
name: skip_leading_rows [50092,50109]
name: skip_leading_rows [50148,50165]
===
match
---
string: 'project_id' [63840,63852]
string: 'project_id' [63896,63908]
===
match
---
atom_expr [28340,28349]
atom_expr [28396,28405]
===
match
---
import_from [952,981]
import_from [952,981]
===
match
---
param [13136,13164]
param [13136,13164]
===
match
---
name: value [81033,81038]
name: value [81089,81094]
===
match
---
name: self [52118,52122]
name: self [52174,52178]
===
match
---
param [96186,96205]
param [96242,96261]
===
match
---
tfpdef [48307,48338]
tfpdef [48363,48394]
===
match
---
param [3104,3108]
param [3104,3108]
===
match
---
atom_expr [29922,29930]
atom_expr [29978,29986]
===
match
---
name: self [50185,50189]
name: self [50241,50245]
===
match
---
trailer [64185,64205]
trailer [64241,64261]
===
match
---
atom_expr [40429,40445]
atom_expr [40485,40501]
===
match
---
operator: , [60780,60781]
operator: , [60836,60837]
===
match
---
operator: , [67115,67116]
operator: , [67171,67172]
===
match
---
suite [26944,27198]
suite [26944,27228]
===
match
---
simple_stmt [61967,62023]
simple_stmt [62023,62079]
===
match
---
string: """Helper class for constructing BigQuery link.""" [2467,2517]
string: """Helper class for constructing BigQuery link.""" [2467,2517]
===
match
---
expr_stmt [60985,61015]
expr_stmt [61041,61071]
===
match
---
atom_expr [70711,70732]
atom_expr [70767,70788]
===
match
---
return_stmt [2596,2640]
return_stmt [2596,2640]
===
match
---
argument [13413,13450]
argument [13413,13450]
===
match
---
arglist [57002,57094]
arglist [57058,57150]
===
match
---
operator: , [96427,96428]
operator: , [96483,96484]
===
match
---
param [70178,70211]
param [70234,70267]
===
match
---
name: delegate_to [78299,78310]
name: delegate_to [78355,78366]
===
match
---
trailer [39047,39056]
trailer [39103,39112]
===
match
---
name: skip_leading_rows [52468,52485]
name: skip_leading_rows [52524,52541]
===
match
---
operator: = [40083,40084]
operator: = [40139,40140]
===
match
---
param [13037,13079]
param [13037,13079]
===
match
---
operator: = [17441,17442]
operator: = [17441,17442]
===
match
---
atom_expr [7185,7204]
atom_expr [7185,7204]
===
match
---
suite [96678,96771]
suite [96734,96827]
===
match
---
name: dataset_reference [61070,61087]
name: dataset_reference [61126,61143]
===
match
---
arith_expr [2624,2638]
arith_expr [2624,2638]
===
match
---
name: self [95700,95704]
name: self [95756,95760]
===
match
---
trailer [2253,2294]
trailer [2253,2294]
===
match
---
operator: { [2623,2624]
operator: { [2623,2624]
===
match
---
operator: = [38481,38482]
operator: = [38537,38538]
===
match
---
name: job [98477,98480]
name: job [98533,98536]
===
match
---
name: self [98605,98609]
name: self [98661,98665]
===
match
---
atom_expr [13183,13196]
atom_expr [13183,13196]
===
match
---
name: project_id [74408,74418]
name: project_id [74464,74474]
===
match
---
fstring_end: " [97260,97261]
fstring_end: " [97316,97317]
===
match
---
simple_stmt [27380,27439]
simple_stmt [27436,27495]
===
match
---
atom_expr [95218,95253]
atom_expr [95274,95309]
===
match
---
param [17639,17703]
param [17639,17703]
===
match
---
simple_stmt [38034,38074]
simple_stmt [38090,38130]
===
match
---
operator: , [78620,78621]
operator: , [78676,78677]
===
match
---
name: CHECK [6525,6530]
name: CHECK [6525,6530]
===
match
---
atom_expr [97201,97212]
atom_expr [97257,97268]
===
match
---
expr_stmt [69966,70022]
expr_stmt [70022,70078]
===
match
---
operator: , [90101,90102]
operator: , [90157,90158]
===
match
---
atom_expr [96751,96767]
atom_expr [96807,96823]
===
match
---
operator: , [77851,77852]
operator: , [77907,77908]
===
match
---
funcdef [81044,82076]
funcdef [81100,82132]
===
match
---
simple_stmt [28197,28234]
simple_stmt [28253,28290]
===
match
---
dotted_name [1294,1321]
dotted_name [1294,1321]
===
match
---
operator: = [39710,39711]
operator: = [39766,39767]
===
match
---
operator: = [13023,13024]
operator: = [13023,13024]
===
match
---
suite [75174,78948]
suite [75230,79004]
===
match
---
param [60334,60373]
param [60390,60429]
===
match
---
operator: , [86108,86109]
operator: , [86164,86165]
===
match
---
operator: = [28004,28005]
operator: = [28060,28061]
===
match
---
name: dataset_resource [70146,70162]
name: dataset_resource [70202,70218]
===
match
---
param [95307,95316]
param [95363,95372]
===
match
---
name: schema_update_options [30654,30675]
name: schema_update_options [30710,30731]
===
match
---
argument [29058,29098]
argument [29114,29154]
===
match
---
name: template_fields [84571,84586]
name: template_fields [84627,84642]
===
match
---
operator: = [81884,81885]
operator: = [81940,81941]
===
match
---
name: airflow [1347,1354]
name: airflow [1347,1354]
===
match
---
simple_stmt [1073,1085]
simple_stmt [1073,1085]
===
match
---
name: self [81806,81810]
name: self [81862,81866]
===
match
---
suite [13597,13719]
suite [13597,13719]
===
match
---
name: hook [98685,98689]
name: hook [98741,98745]
===
match
---
trailer [64626,64638]
trailer [64682,64694]
===
match
---
trailer [51816,52017]
trailer [51872,52073]
===
match
---
expr_stmt [56520,56550]
expr_stmt [56576,56606]
===
match
---
classdef [7341,10232]
classdef [7341,10232]
===
match
---
name: value [6531,6536]
name: value [6531,6536]
===
match
---
atom_expr [39580,39602]
atom_expr [39636,39658]
===
match
---
tfpdef [12955,12978]
tfpdef [12955,12978]
===
match
---
name: execute [61270,61277]
name: execute [61326,61333]
===
match
---
name: table_id [39166,39174]
name: table_id [39222,39230]
===
match
---
name: self [90863,90867]
name: self [90919,90923]
===
match
---
name: job_id [2232,2238]
name: job_id [2232,2238]
===
match
---
testlist_comp [9172,9272]
testlist_comp [9172,9272]
===
match
---
operator: = [97399,97400]
operator: = [97455,97456]
===
match
---
param [38626,38656]
param [38682,38712]
===
match
---
operator: = [30516,30517]
operator: = [30572,30573]
===
match
---
operator: , [25993,25994]
operator: , [25993,25994]
===
match
---
trailer [74016,74021]
trailer [74072,74077]
===
match
---
operator: = [85581,85582]
operator: = [85637,85638]
===
match
---
operator: = [6624,6625]
operator: = [6624,6625]
===
match
---
trailer [96549,96556]
trailer [96605,96612]
===
match
---
operator: = [18110,18111]
operator: = [18110,18111]
===
match
---
name: schema_fields [40535,40548]
name: schema_fields [40591,40604]
===
match
---
argument [28712,28740]
argument [28768,28796]
===
match
---
name: Dict [60221,60225]
name: Dict [60277,60281]
===
match
---
operator: } [52094,52095]
operator: } [52150,52151]
===
match
---
name: warn [13619,13623]
name: warn [13619,13623]
===
match
---
param [82093,82098]
param [82149,82154]
===
match
---
name: len [19076,19079]
name: len [19076,19079]
===
match
---
name: Optional [9547,9555]
name: Optional [9547,9555]
===
match
---
trailer [78404,78414]
trailer [78460,78470]
===
match
---
name: schema_object [48733,48746]
name: schema_object [48789,48802]
===
match
---
name: location [40075,40083]
name: location [40131,40139]
===
match
---
name: self [85954,85958]
name: self [86010,86014]
===
match
---
simple_stmt [982,1072]
simple_stmt [982,1072]
===
match
---
name: gcp_conn_id [27167,27178]
name: gcp_conn_id [27197,27208]
===
match
---
operator: = [31246,31247]
operator: = [31302,31303]
===
match
---
name: self [39819,39823]
name: self [39875,39879]
===
match
---
name: self [40183,40187]
name: self [40239,40243]
===
match
---
operator: , [60810,60811]
operator: , [60866,60867]
===
match
---
name: self [61605,61609]
name: self [61661,61665]
===
match
---
operator: = [85663,85664]
operator: = [85719,85720]
===
match
---
simple_stmt [64806,64892]
simple_stmt [64862,64948]
===
match
---
name: self [61358,61362]
name: self [61414,61418]
===
match
---
name: sql [27368,27371]
name: sql [27424,27427]
===
match
---
param [38459,38506]
param [38515,38562]
===
match
---
operator: * [89952,89953]
operator: * [90008,90009]
===
match
---
name: BaseOperator [75160,75172]
name: BaseOperator [75216,75228]
===
match
---
operator: , [52404,52405]
operator: , [52460,52461]
===
match
---
trailer [85904,85991]
trailer [85960,86047]
===
match
---
name: time_partitioning [39500,39517]
name: time_partitioning [39556,39573]
===
match
---
atom_expr [40647,40665]
atom_expr [40703,40721]
===
match
---
param [67034,67098]
param [67090,67154]
===
match
---
operator: , [74866,74867]
operator: , [74922,74923]
===
match
---
operator: , [3279,3280]
operator: , [3279,3280]
===
match
---
atom_expr [81240,81253]
atom_expr [81296,81309]
===
match
---
param [47866,47892]
param [47922,47948]
===
match
---
name: self [18565,18569]
name: self [18565,18569]
===
match
---
atom_expr [74244,74269]
atom_expr [74300,74325]
===
match
---
operator: = [74604,74605]
operator: = [74660,74661]
===
match
---
name: location [40089,40097]
name: location [40145,40153]
===
match
---
with_item [96047,96079]
with_item [96103,96135]
===
match
---
trailer [31242,31270]
trailer [31298,31326]
===
match
---
suite [1852,1988]
suite [1852,1988]
===
match
---
operator: = [61648,61649]
operator: = [61704,61705]
===
match
---
atom_expr [38874,38883]
atom_expr [38930,38939]
===
match
---
name: delegate_to [81911,81922]
name: delegate_to [81967,81978]
===
match
---
name: kwargs [81476,81482]
name: kwargs [81532,81538]
===
match
---
param [38752,38800]
param [38808,38856]
===
match
---
operator: = [61002,61003]
operator: = [61058,61059]
===
match
---
trailer [40651,40665]
trailer [40707,40721]
===
match
---
operator: , [41053,41054]
operator: , [41109,41110]
===
match
---
operator: = [27366,27367]
operator: = [27422,27423]
===
match
---
tfpdef [12901,12911]
tfpdef [12901,12911]
===
match
---
name: selected_fields [17410,17425]
name: selected_fields [17410,17425]
===
match
---
arglist [3203,3406]
arglist [3203,3406]
===
match
---
simple_stmt [74495,74532]
simple_stmt [74551,74588]
===
match
---
expr_stmt [78708,78910]
expr_stmt [78764,78966]
===
match
---
tfpdef [38583,38609]
tfpdef [38639,38665]
===
match
---
simple_stmt [39631,39688]
simple_stmt [39687,39744]
===
match
---
name: schema_object [47785,47798]
name: schema_object [47841,47854]
===
match
---
simple_stmt [60015,60057]
simple_stmt [60071,60113]
===
match
---
operator: = [95496,95497]
operator: = [95552,95553]
===
match
---
name: delegate_to [74559,74570]
name: delegate_to [74615,74626]
===
match
---
trailer [6524,6530]
trailer [6524,6530]
===
match
---
name: gcp_conn_id [82242,82253]
name: gcp_conn_id [82298,82309]
===
match
---
operator: , [18709,18710]
operator: , [18709,18710]
===
match
---
operator: = [18606,18607]
operator: = [18606,18607]
===
match
---
name: str [81141,81144]
name: str [81197,81200]
===
match
---
operator: = [98549,98550]
operator: = [98605,98606]
===
match
---
argument [6954,6962]
argument [6954,6962]
===
match
---
name: ui_color [38034,38042]
name: ui_color [38090,38098]
===
match
---
atom_expr [38922,38957]
atom_expr [38978,39013]
===
match
---
simple_stmt [94689,94715]
simple_stmt [94745,94771]
===
match
---
expr_stmt [64532,64707]
expr_stmt [64588,64763]
===
match
---
name: gcp_conn_id [95536,95547]
name: gcp_conn_id [95592,95603]
===
match
---
name: template_fields [73636,73651]
name: template_fields [73692,73707]
===
match
---
trailer [73968,73979]
trailer [74024,74035]
===
match
---
name: self [18208,18212]
name: self [18208,18212]
===
match
---
operator: , [90350,90351]
operator: , [90406,90407]
===
match
---
name: CHECK [1902,1907]
name: CHECK [1902,1907]
===
match
---
trailer [90959,90979]
trailer [91015,91035]
===
match
---
trailer [60956,60965]
trailer [61012,61021]
===
match
---
arglist [28880,28893]
arglist [28936,28949]
===
match
---
trailer [60460,60480]
trailer [60516,60536]
===
match
---
name: BigQueryHook [3177,3189]
name: BigQueryHook [3177,3189]
===
match
---
name: sql [27362,27365]
name: sql [27418,27421]
===
match
---
expr_stmt [61198,61224]
expr_stmt [61254,61280]
===
match
---
operator: = [25826,25827]
operator: = [25826,25827]
===
match
---
name: stacklevel [85485,85495]
name: stacklevel [85541,85551]
===
match
---
trailer [96138,96140]
trailer [96194,96196]
===
match
---
operator: = [30145,30146]
operator: = [30201,30202]
===
match
---
atom_expr [64542,64707]
atom_expr [64598,64763]
===
match
---
trailer [17668,17695]
trailer [17668,17695]
===
match
---
name: time_partitioning [39469,39486]
name: time_partitioning [39525,39542]
===
match
---
name: Optional [95218,95226]
name: Optional [95274,95282]
===
match
---
tfpdef [25904,25935]
tfpdef [25904,25935]
===
match
---
name: maximum_billing_tier [27841,27861]
name: maximum_billing_tier [27897,27917]
===
match
---
atom_expr [26957,27154]
atom_expr [26957,27184]
===
match
---
operator: , [9437,9438]
operator: , [9437,9438]
===
match
---
operator: , [81070,81071]
operator: , [81126,81127]
===
match
---
argument [39986,40019]
argument [40042,40075]
===
match
---
name: impersonation_chain [10183,10202]
name: impersonation_chain [10183,10202]
===
match
---
operator: = [75094,75095]
operator: = [75150,75151]
===
match
---
operator: = [28957,28958]
operator: = [29013,29014]
===
match
---
operator: , [41121,41122]
operator: , [41177,41178]
===
match
---
param [26782,26846]
param [26782,26846]
===
match
---
argument [52199,52268]
argument [52255,52324]
===
match
---
operator: , [38964,38965]
operator: , [39020,39021]
===
match
---
name: dataset_id [62011,62021]
name: dataset_id [62067,62077]
===
match
---
operator: = [17247,17248]
operator: = [17247,17248]
===
match
---
atom_expr [74495,74514]
atom_expr [74551,74570]
===
match
---
string: "the gcp_conn_id parameter." [17932,17960]
string: "the gcp_conn_id parameter." [17932,17960]
===
match
---
string: "dataset_reference" [59982,60001]
string: "dataset_reference" [60038,60057]
===
match
---
name: task [2732,2736]
name: task [2732,2736]
===
match
---
name: dataset_reference [61705,61722]
name: dataset_reference [61761,61778]
===
match
---
operator: = [2402,2403]
operator: = [2402,2403]
===
match
---
expr_stmt [90577,90605]
expr_stmt [90633,90661]
===
match
---
operator: , [60744,60745]
operator: , [60800,60801]
===
match
---
expr_stmt [27692,27722]
expr_stmt [27748,27778]
===
match
---
atom_expr [39150,39163]
atom_expr [39206,39219]
===
match
---
simple_stmt [85602,85639]
simple_stmt [85658,85695]
===
match
---
operator: , [70304,70305]
operator: , [70360,70361]
===
match
---
operator: = [38549,38550]
operator: = [38605,38606]
===
match
---
operator: = [17583,17584]
operator: = [17583,17584]
===
match
---
operator: = [81834,81835]
operator: = [81890,81891]
===
match
---
simple_stmt [82192,82401]
simple_stmt [82248,82457]
===
match
---
expr_stmt [47375,47429]
expr_stmt [47431,47485]
===
match
---
operator: , [96225,96226]
operator: , [96281,96282]
===
match
---
operator: = [29422,29423]
operator: = [29478,29479]
===
match
---
name: value [89905,89910]
name: value [89961,89966]
===
match
---
name: BigQueryUIColors [17249,17265]
name: BigQueryUIColors [17249,17265]
===
match
---
name: Optional [55911,55919]
name: Optional [55967,55975]
===
match
---
trailer [9804,9806]
trailer [9804,9806]
===
match
---
operator: , [28548,28549]
operator: , [28604,28605]
===
match
---
simple_stmt [25305,25345]
simple_stmt [25305,25345]
===
match
---
name: __init__ [94826,94834]
name: __init__ [94882,94890]
===
match
---
atom_expr [48532,48545]
atom_expr [48588,48601]
===
match
---
tfpdef [77903,77919]
tfpdef [77959,77975]
===
match
---
expr_stmt [95634,95691]
expr_stmt [95690,95747]
===
match
---
string: 'Start getting dataset: %s:%s' [64731,64761]
string: 'Start getting dataset: %s:%s' [64787,64817]
===
match
---
string: "configuration" [94748,94763]
string: "configuration" [94804,94819]
===
match
---
name: delegate_to [61123,61134]
name: delegate_to [61179,61190]
===
match
---
name: Conflict [61835,61843]
name: Conflict [61891,61899]
===
match
---
tfpdef [26782,26838]
tfpdef [26782,26838]
===
match
---
string: 'project_id' [37799,37811]
string: 'project_id' [37855,37867]
===
match
---
name: bigquery_conn_id [60852,60868]
name: bigquery_conn_id [60908,60924]
===
match
---
string: 'project_id' [55544,55556]
string: 'project_id' [55600,55612]
===
match
---
expr_stmt [10156,10202]
expr_stmt [10156,10202]
===
match
---
atom_expr [74357,74370]
atom_expr [74413,74426]
===
match
---
trailer [13816,13825]
trailer [13816,13825]
===
match
---
name: template_fields [59819,59834]
name: template_fields [59875,59890]
===
match
---
name: get [61893,61896]
name: get [61949,61952]
===
match
---
trailer [26831,26836]
trailer [26831,26836]
===
match
---
param [2665,2688]
param [2665,2688]
===
match
---
expr_stmt [81906,81936]
expr_stmt [81962,81992]
===
match
---
name: impersonation_chain [77997,78016]
name: impersonation_chain [78053,78072]
===
match
---
operator: , [13399,13400]
operator: , [13399,13400]
===
match
---
atom_expr [78718,78910]
atom_expr [78774,78966]
===
match
---
expr_stmt [50699,50723]
expr_stmt [50755,50779]
===
match
---
trailer [27215,27220]
trailer [27245,27250]
===
match
---
name: str [25722,25725]
name: str [25722,25725]
===
match
---
simple_stmt [67639,67806]
simple_stmt [67695,67862]
===
match
---
trailer [82033,82053]
trailer [82089,82109]
===
match
---
atom_expr [50605,50616]
atom_expr [50661,50672]
===
match
---
operator: , [50939,50940]
operator: , [50995,50996]
===
match
---
testlist_comp [25292,25299]
testlist_comp [25292,25299]
===
match
---
operator: , [26772,26773]
operator: , [26772,26773]
===
match
---
trailer [85895,85899]
trailer [85951,85955]
===
match
---
param [96172,96177]
param [96228,96233]
===
match
---
name: schema_fields [51378,51391]
name: schema_fields [51434,51447]
===
match
---
trailer [30983,31008]
trailer [31039,31064]
===
match
---
operator: , [26216,26217]
operator: , [26216,26217]
===
match
---
name: Optional [78018,78026]
name: Optional [78074,78082]
===
match
---
expr_stmt [13728,13758]
expr_stmt [13728,13758]
===
match
---
name: dataset_id [18538,18548]
name: dataset_id [18538,18548]
===
match
---
atom_expr [56829,56845]
atom_expr [56885,56901]
===
match
---
string: 'table_id' [37779,37789]
string: 'table_id' [37835,37845]
===
match
---
name: len [2899,2902]
name: len [2899,2902]
===
match
---
atom_expr [90081,90094]
atom_expr [90137,90150]
===
match
---
name: project_id [90151,90161]
name: project_id [90207,90217]
===
match
---
operator: = [18272,18273]
operator: = [18272,18273]
===
match
---
operator: , [94881,94882]
operator: , [94937,94938]
===
match
---
simple_stmt [55494,55595]
simple_stmt [55550,55651]
===
match
---
trailer [29427,29446]
trailer [29483,29502]
===
match
---
name: google_cloud_storage_conn_id [39362,39390]
name: google_cloud_storage_conn_id [39418,39446]
===
match
---
operator: , [12779,12780]
operator: , [12779,12780]
===
match
---
param [74171,74205]
param [74227,74261]
===
match
---
trailer [3306,3315]
trailer [3306,3315]
===
match
---
name: BigQueryUIColors [47445,47461]
name: BigQueryUIColors [47501,47517]
===
match
---
operator: , [41441,41442]
operator: , [41497,41498]
===
match
---
name: reattach_states [95639,95654]
name: reattach_states [95695,95710]
===
match
---
name: context [78438,78445]
name: context [78494,78501]
===
match
---
atom_expr [86356,86371]
atom_expr [86412,86427]
===
match
---
atom_expr [39998,40019]
atom_expr [40054,40075]
===
match
---
name: include_policy_tags [90479,90498]
name: include_policy_tags [90535,90554]
===
match
---
operator: , [47332,47333]
operator: , [47388,47389]
===
match
---
name: self [71206,71210]
name: self [71262,71266]
===
match
---
operator: = [18024,18025]
operator: = [18024,18025]
===
match
---
name: time_partitioning [30791,30808]
name: time_partitioning [30847,30864]
===
match
---
operator: , [9394,9395]
operator: , [9394,9395]
===
match
---
name: sql [28954,28957]
name: sql [29010,29013]
===
match
---
name: max_results [67233,67244]
name: max_results [67289,67300]
===
match
---
name: Sequence [85151,85159]
name: Sequence [85207,85215]
===
match
---
trailer [29627,29636]
trailer [29683,29692]
===
match
---
name: str [38545,38548]
name: str [38601,38604]
===
match
---
name: delegate_to [78534,78545]
name: delegate_to [78590,78601]
===
match
---
argument [3387,3405]
argument [3387,3405]
===
match
---
parameters [95866,95872]
parameters [95922,95928]
===
match
---
trailer [52931,52956]
trailer [52987,53012]
===
match
---
name: __init__ [39048,39056]
name: __init__ [39104,39112]
===
match
---
expr_stmt [56320,56350]
expr_stmt [56376,56406]
===
match
---
name: to_api_repr [78934,78945]
name: to_api_repr [78990,79001]
===
match
---
name: format [2340,2346]
name: format [2340,2346]
===
match
---
param [25952,25994]
param [25952,25994]
===
match
---
tfpdef [25952,25968]
tfpdef [25952,25968]
===
match
---
name: self [81945,81949]
name: self [82001,82005]
===
match
---
operator: -> [9782,9784]
operator: -> [9782,9784]
===
match
---
param [77708,77713]
param [77764,77769]
===
match
---
name: job_id [96448,96454]
name: job_id [96504,96510]
===
match
---
name: dataset_id [61857,61867]
name: dataset_id [61913,61923]
===
match
---
funcdef [50784,52972]
funcdef [50840,53028]
===
match
---
operator: @ [2382,2383]
operator: @ [2382,2383]
===
match
---
atom_expr [51436,51454]
atom_expr [51492,51510]
===
match
---
operator: , [90183,90184]
operator: , [90239,90240]
===
match
---
name: project_id [40804,40814]
name: project_id [40860,40870]
===
match
---
fstring [98245,98321]
fstring [98301,98377]
===
match
---
simple_stmt [6497,6537]
simple_stmt [6497,6537]
===
match
---
trailer [57078,57094]
trailer [57134,57150]
===
match
---
suite [3126,3417]
suite [3126,3417]
===
match
---
operator: = [64874,64875]
operator: = [64930,64931]
===
match
---
name: destination_dataset_table [27385,27410]
name: destination_dataset_table [27441,27466]
===
match
---
simple_stmt [9799,9879]
simple_stmt [9799,9879]
===
match
---
name: str [84843,84846]
name: str [84899,84902]
===
match
---
simple_stmt [18788,19025]
simple_stmt [18788,19025]
===
match
---
trailer [56925,56945]
trailer [56981,57001]
===
match
---
operator: = [96332,96333]
operator: = [96388,96389]
===
match
---
name: self [49834,49838]
name: self [49890,49894]
===
match
---
argument [51834,51868]
argument [51890,51924]
===
match
---
atom_expr [41284,41303]
atom_expr [41340,41359]
===
match
---
operator: , [98764,98765]
operator: , [98820,98821]
===
match
---
name: gcp_conn_id [50864,50875]
name: gcp_conn_id [50920,50931]
===
match
---
trailer [55876,55881]
trailer [55932,55937]
===
match
---
operator: = [90904,90905]
operator: = [90960,90961]
===
match
---
arglist [78754,78900]
arglist [78810,78956]
===
match
---
argument [52286,52313]
argument [52342,52369]
===
match
---
atom_expr [96546,96558]
atom_expr [96602,96614]
===
match
---
name: __init__ [6546,6554]
name: __init__ [6546,6554]
===
match
---
simple_stmt [1968,1988]
simple_stmt [1968,1988]
===
match
---
atom_expr [28675,28694]
atom_expr [28731,28750]
===
match
---
name: gcp_conn_id [61363,61374]
name: gcp_conn_id [61419,61430]
===
match
---
name: self [52650,52654]
name: self [52706,52710]
===
match
---
name: impersonation_chain [82056,82075]
name: impersonation_chain [82112,82131]
===
match
---
name: get [61921,61924]
name: get [61977,61980]
===
match
---
operator: , [13315,13316]
operator: , [13315,13316]
===
match
---
atom_expr [25773,25786]
atom_expr [25773,25786]
===
match
---
simple_stmt [39526,39547]
simple_stmt [39582,39603]
===
match
---
atom_expr [39696,39709]
atom_expr [39752,39765]
===
match
---
name: str [2583,2586]
name: str [2583,2586]
===
match
---
operator: = [98776,98777]
operator: = [98832,98833]
===
match
---
trailer [78933,78945]
trailer [78989,79001]
===
match
---
arglist [40354,40508]
arglist [40410,40564]
===
match
---
simple_stmt [89871,89911]
simple_stmt [89927,89967]
===
match
---
operator: = [67018,67019]
operator: = [67074,67075]
===
match
---
operator: , [30932,30933]
operator: , [30988,30989]
===
match
---
operator: = [29009,29010]
operator: = [29065,29066]
===
match
---
name: Sequence [9695,9703]
name: Sequence [9695,9703]
===
match
---
name: labels [29524,29530]
name: labels [29580,29586]
===
match
---
trailer [19079,19085]
trailer [19079,19085]
===
match
---
operator: , [70377,70378]
operator: , [70433,70434]
===
match
---
name: exceptions [1196,1206]
name: exceptions [1196,1206]
===
match
---
operator: = [48162,48163]
operator: = [48218,48219]
===
match
---
operator: , [49175,49176]
operator: , [49231,49232]
===
match
---
name: template_ext [9283,9295]
name: template_ext [9283,9295]
===
match
---
name: gcp_conn_id [51197,51208]
name: gcp_conn_id [51253,51264]
===
match
---
not_test [51057,51079]
not_test [51113,51135]
===
match
---
name: use_legacy_sql [3265,3279]
name: use_legacy_sql [3265,3279]
===
match
---
suite [70411,70881]
suite [70467,70937]
===
match
---
name: location [94939,94947]
name: location [94995,95003]
===
match
---
param [17355,17369]
param [17355,17369]
===
match
---
operator: } [96740,96741]
operator: } [96796,96797]
===
match
---
name: job_id [97050,97056]
name: job_id [97106,97112]
===
match
---
atom_expr [70355,70368]
atom_expr [70411,70424]
===
match
---
simple_stmt [95451,95472]
simple_stmt [95507,95528]
===
match
---
name: schema_object [51441,51454]
name: schema_object [51497,51510]
===
match
---
string: 'impersonation_chain' [55566,55587]
string: 'impersonation_chain' [55622,55643]
===
match
---
name: int [26205,26208]
name: int [26205,26208]
===
match
---
name: delegate_to [28712,28723]
name: delegate_to [28768,28779]
===
match
---
name: impersonation_chain [28402,28421]
name: impersonation_chain [28458,28477]
===
match
---
operator: = [71011,71012]
operator: = [71067,71068]
===
match
---
trailer [51179,51365]
trailer [51235,51421]
===
match
---
name: self [27380,27384]
name: self [27436,27440]
===
match
---
string: 'bucket' [47184,47192]
string: 'bucket' [47240,47248]
===
match
---
tfpdef [90193,90209]
tfpdef [90249,90265]
===
match
---
name: kwargs [6897,6903]
name: kwargs [6897,6903]
===
match
---
parameters [25388,25394]
parameters [25388,25394]
===
match
---
name: property [2552,2560]
name: property [2552,2560]
===
match
---
expr_stmt [10072,10102]
expr_stmt [10072,10102]
===
match
---
name: maximum_billing_tier [29276,29296]
name: maximum_billing_tier [29332,29352]
===
match
---
parameters [67429,67444]
parameters [67485,67500]
===
match
---
name: dataset [64907,64914]
name: dataset [64963,64970]
===
match
---
atom_expr [48024,48037]
atom_expr [48080,48093]
===
match
---
trailer [41335,41345]
trailer [41391,41401]
===
match
---
name: str [48527,48530]
name: str [48583,48586]
===
match
---
param [28467,28474]
param [28523,28530]
===
match
---
trailer [57017,57028]
trailer [57073,57084]
===
match
---
parameters [2658,2704]
parameters [2658,2704]
===
match
---
argument [2390,2407]
argument [2390,2407]
===
match
---
simple_stmt [902,914]
simple_stmt [902,914]
===
match
---
name: Union [1066,1071]
name: Union [1066,1071]
===
match
---
param [25904,25943]
param [25904,25943]
===
match
---
operator: = [27179,27180]
operator: = [27209,27210]
===
match
---
operator: = [28166,28167]
operator: = [28222,28223]
===
match
---
operator: -> [85199,85201]
operator: -> [85255,85257]
===
match
---
trailer [85005,85010]
trailer [85061,85066]
===
match
---
name: __init__ [17753,17761]
name: __init__ [17753,17761]
===
match
---
return_stmt [2995,3053]
return_stmt [2995,3053]
===
match
---
simple_stmt [13728,13759]
simple_stmt [13728,13759]
===
match
---
name: ui_color [12809,12817]
name: ui_color [12809,12817]
===
match
---
operator: = [71061,71062]
operator: = [71117,71118]
===
match
---
atom_expr [30076,30106]
atom_expr [30132,30162]
===
match
---
simple_stmt [81526,81754]
simple_stmt [81582,81810]
===
match
---
trailer [50880,50897]
trailer [50936,50953]
===
match
---
string: "json" [84727,84733]
string: "json" [84783,84789]
===
match
---
argument [41269,41303]
argument [41325,41359]
===
match
---
atom_expr [64580,64596]
atom_expr [64636,64652]
===
match
---
operator: = [74271,74272]
operator: = [74327,74328]
===
match
---
atom_expr [49834,49853]
atom_expr [49890,49909]
===
match
---
operator: , [82331,82332]
operator: , [82387,82388]
===
match
---
param [55760,55790]
param [55816,55846]
===
match
---
trailer [51398,51404]
trailer [51454,51460]
===
match
---
expr_stmt [94585,94684]
expr_stmt [94641,94740]
===
match
---
fstring_end: ' [2639,2640]
fstring_end: ' [2639,2640]
===
match
---
name: impersonation_chain [67358,67377]
name: impersonation_chain [67414,67433]
===
match
---
trailer [60050,60056]
trailer [60106,60112]
===
match
---
operator: = [91129,91130]
operator: = [91185,91186]
===
match
---
name: project_id [67742,67752]
name: project_id [67798,67808]
===
match
---
trailer [30790,30808]
trailer [30846,30864]
===
match
---
operator: , [66930,66931]
operator: , [66986,66987]
===
match
---
operator: , [94969,94970]
operator: , [95025,95026]
===
match
---
atom_expr [95451,95462]
atom_expr [95507,95518]
===
match
---
name: impersonation_chain [50737,50756]
name: impersonation_chain [50793,50812]
===
match
---
operator: = [70651,70652]
operator: = [70707,70708]
===
match
---
trailer [31215,31232]
trailer [31271,31288]
===
match
---
simple_stmt [96691,96771]
simple_stmt [96747,96827]
===
match
---
trailer [50516,50528]
trailer [50572,50584]
===
match
---
trailer [48032,48037]
trailer [48088,48093]
===
match
---
simple_stmt [64464,64491]
simple_stmt [64520,64547]
===
match
---
name: udf_config [29248,29258]
name: udf_config [29304,29314]
===
match
---
operator: = [27839,27840]
operator: = [27895,27896]
===
match
---
name: warnings [13610,13618]
name: warnings [13610,13618]
===
match
---
trailer [94804,94810]
trailer [94860,94866]
===
match
---
testlist_comp [6379,6457]
testlist_comp [6379,6457]
===
match
---
name: str [38245,38248]
name: str [38301,38304]
===
match
---
name: context [39924,39931]
name: context [39980,39987]
===
match
---
operator: = [94601,94602]
operator: = [94657,94658]
===
match
---
name: log [31380,31383]
name: log [31436,31439]
===
match
---
trailer [67391,67393]
trailer [67447,67449]
===
match
---
suite [97606,97696]
suite [97662,97752]
===
match
---
atom_expr [70335,70370]
atom_expr [70391,70426]
===
match
---
string: 'project_id' [59869,59881]
string: 'project_id' [59925,59937]
===
match
---
name: __init__ [60066,60074]
name: __init__ [60122,60130]
===
match
---
name: gcp_conn_id [61004,61015]
name: gcp_conn_id [61060,61071]
===
match
---
operator: = [48666,48667]
operator: = [48722,48723]
===
match
---
name: Optional [26751,26759]
name: Optional [26751,26759]
===
match
---
operator: , [84810,84811]
operator: , [84866,84867]
===
match
---
tfpdef [77733,77765]
tfpdef [77789,77821]
===
match
---
operator: -> [50811,50813]
operator: -> [50867,50869]
===
match
---
name: bq_hook [71114,71121]
name: bq_hook [71170,71177]
===
match
---
atom_expr [70284,70297]
atom_expr [70340,70353]
===
match
---
name: xcom_pull [2244,2253]
name: xcom_pull [2244,2253]
===
match
---
atom_expr [85285,85512]
atom_expr [85341,85568]
===
match
---
atom_expr [96129,96140]
atom_expr [96185,96196]
===
match
---
string: 'table_resource' [84621,84637]
string: 'table_resource' [84677,84693]
===
match
---
funcdef [39906,41619]
funcdef [39962,41675]
===
match
---
operator: * [81080,81081]
operator: * [81136,81137]
===
match
---
expr_stmt [95451,95471]
expr_stmt [95507,95527]
===
match
---
atom_expr [60446,60481]
atom_expr [60502,60537]
===
match
---
atom_expr [50185,50205]
atom_expr [50241,50261]
===
match
---
name: labels [52866,52872]
name: labels [52922,52928]
===
match
---
string: 'Cancelling running query' [31389,31415]
string: 'Cancelling running query' [31445,31471]
===
match
---
trailer [56704,56771]
trailer [56760,56827]
===
match
---
name: dataset_id [17330,17340]
name: dataset_id [17330,17340]
===
match
---
atom_expr [77792,77801]
atom_expr [77848,77857]
===
match
---
atom_expr [52152,52971]
atom_expr [52208,53027]
===
match
---
expr_stmt [56559,56605]
expr_stmt [56615,56661]
===
match
---
name: Optional [48461,48469]
name: Optional [48517,48525]
===
match
---
name: table_resource [74948,74962]
name: table_resource [75004,75018]
===
match
---
operator: = [50159,50160]
operator: = [50215,50216]
===
match
---
operator: , [60539,60540]
operator: , [60595,60596]
===
match
---
operator: , [9177,9178]
operator: , [9177,9178]
===
match
---
name: isinstance [95952,95962]
name: isinstance [96008,96018]
===
match
---
argument [86080,86108]
argument [86136,86164]
===
match
---
name: execution_date [2747,2761]
name: execution_date [2747,2761]
===
match
---
atom_expr [17669,17694]
atom_expr [17669,17694]
===
match
---
operator: = [39997,39998]
operator: = [40053,40054]
===
match
---
trailer [31379,31383]
trailer [31435,31439]
===
match
---
name: __init__ [63946,63954]
name: __init__ [64002,64010]
===
match
---
atom_expr [18957,18977]
atom_expr [18957,18977]
===
match
---
string: "schema_fields_updates" [89834,89857]
string: "schema_fields_updates" [89890,89913]
===
match
---
name: task_id [97220,97227]
name: task_id [97276,97283]
===
match
---
expr_stmt [13845,13891]
expr_stmt [13845,13891]
===
match
---
operator: = [74104,74105]
operator: = [74160,74161]
===
match
---
operator: , [84846,84847]
operator: , [84902,84903]
===
match
---
raise_stmt [31102,31199]
raise_stmt [31158,31255]
===
match
---
name: self [28724,28728]
name: self [28780,28784]
===
match
---
name: info [61976,61980]
name: info [62032,62036]
===
match
---
expr_stmt [18366,18412]
expr_stmt [18366,18412]
===
match
---
name: use_legacy_sql [27790,27804]
name: use_legacy_sql [27846,27860]
===
match
---
name: dataset_resource [78250,78266]
name: dataset_resource [78306,78322]
===
match
---
simple_stmt [80999,81039]
simple_stmt [81055,81095]
===
match
---
name: template_fields_renderers [59953,59978]
name: template_fields_renderers [60009,60034]
===
match
---
atom_expr [28197,28216]
atom_expr [28253,28272]
===
match
---
atom_expr [40562,40603]
atom_expr [40618,40659]
===
match
---
name: context [96794,96801]
name: context [96850,96857]
===
match
---
name: kwargs [70873,70879]
name: kwargs [70929,70935]
===
match
---
trailer [97020,97030]
trailer [97076,97086]
===
match
---
atom_expr [31053,31061]
atom_expr [31109,31117]
===
match
---
name: info [41551,41555]
name: info [41607,41611]
===
match
---
arglist [18489,18581]
arglist [18489,18581]
===
match
---
name: self [29853,29857]
name: self [29909,29913]
===
match
---
name: project_id [78158,78168]
name: project_id [78214,78224]
===
match
---
operator: = [13197,13198]
operator: = [13197,13198]
===
match
---
operator: ** [74651,74653]
operator: ** [74707,74709]
===
match
---
operator: = [10011,10012]
operator: = [10011,10012]
===
match
---
operator: = [70777,70778]
operator: = [70833,70834]
===
match
---
operator: , [48345,48346]
operator: , [48401,48402]
===
match
---
operator: -> [96233,96235]
operator: -> [96289,96291]
===
match
---
name: self [82093,82097]
name: self [82149,82153]
===
match
---
name: labels [50619,50625]
name: labels [50675,50681]
===
match
---
atom_expr [28572,28581]
atom_expr [28628,28637]
===
match
---
string: 'impersonation_chain' [80966,80987]
string: 'impersonation_chain' [81022,81043]
===
match
---
name: open [96047,96051]
name: open [96103,96107]
===
match
---
atom_expr [61358,61374]
atom_expr [61414,61430]
===
match
---
name: str [90130,90133]
name: str [90186,90189]
===
match
---
name: include_policy_tags [91110,91129]
name: include_policy_tags [91166,91185]
===
match
---
tfpdef [70146,70168]
tfpdef [70202,70224]
===
match
---
simple_stmt [39076,39105]
simple_stmt [39132,39161]
===
match
---
dotted_name [1188,1206]
dotted_name [1188,1206]
===
match
---
name: SQLIntervalCheckOperator [1394,1418]
name: SQLIntervalCheckOperator [1394,1418]
===
match
---
operator: = [96375,96376]
operator: = [96431,96432]
===
match
---
arglist [56705,56770]
arglist [56761,56826]
===
match
---
tfpdef [38974,38989]
tfpdef [39030,39045]
===
match
---
operator: = [64348,64349]
operator: = [64404,64405]
===
match
---
name: xcom_push [31233,31242]
name: xcom_push [31289,31298]
===
match
---
name: execute [70890,70897]
name: execute [70946,70953]
===
match
---
operator: = [94923,94924]
operator: = [94979,94980]
===
match
---
expr_stmt [39326,39390]
expr_stmt [39382,39446]
===
match
---
operator: = [84945,84946]
operator: = [85001,85002]
===
match
---
name: Any [38250,38253]
name: Any [38306,38309]
===
match
---
operator: , [39015,39016]
operator: , [39071,39072]
===
match
---
simple_stmt [66631,66732]
simple_stmt [66687,66788]
===
match
---
name: self [30146,30150]
name: self [30202,30206]
===
match
---
operator: = [13431,13432]
operator: = [13431,13432]
===
match
---
operator: } [97239,97240]
operator: } [97295,97296]
===
match
---
expr_stmt [61104,61134]
expr_stmt [61160,61190]
===
match
---
name: self [18693,18697]
name: self [18693,18697]
===
match
---
funcdef [94822,95841]
funcdef [94878,95897]
===
match
---
suite [62072,64929]
suite [62128,64985]
===
match
---
name: gcp_conn_id [10077,10088]
name: gcp_conn_id [10077,10088]
===
match
---
trailer [55976,55996]
trailer [56032,56052]
===
match
---
argument [30562,30592]
argument [30618,30648]
===
match
---
atom_expr [38942,38955]
atom_expr [38998,39011]
===
match
---
name: job_id [98542,98548]
name: job_id [98598,98604]
===
match
---
operator: , [9823,9824]
operator: , [9823,9824]
===
match
---
name: TableReference [1167,1181]
name: TableReference [1167,1181]
===
match
---
operator: = [74022,74023]
operator: = [74078,74079]
===
match
---
tfpdef [95270,95290]
tfpdef [95326,95346]
===
match
---
atom [25139,25271]
atom [25139,25271]
===
match
---
subscriptlist [78033,78051]
subscriptlist [78089,78107]
===
match
---
simple_stmt [50005,50040]
simple_stmt [50061,50096]
===
match
---
expr_stmt [7123,7153]
expr_stmt [7123,7153]
===
match
---
trailer [97540,97545]
trailer [97596,97601]
===
match
---
atom_expr [90163,90176]
atom_expr [90219,90232]
===
match
---
trailer [2271,2279]
trailer [2271,2279]
===
match
---
trailer [60360,60365]
trailer [60416,60421]
===
match
---
arglist [71149,71268]
arglist [71205,71324]
===
match
---
atom_expr [64847,64862]
atom_expr [64903,64918]
===
match
---
name: Optional [17427,17435]
name: Optional [17427,17435]
===
match
---
operator: , [38205,38206]
operator: , [38261,38262]
===
match
---
trailer [39442,39460]
trailer [39498,39516]
===
match
---
trailer [97496,97516]
trailer [97552,97572]
===
match
---
name: self [3302,3306]
name: self [3302,3306]
===
match
---
string: 'impersonation_chain' [77545,77566]
string: 'impersonation_chain' [77601,77622]
===
match
---
operator: = [18871,18872]
operator: = [18871,18872]
===
match
---
name: impersonation_chain [81351,81370]
name: impersonation_chain [81407,81426]
===
match
---
trailer [38873,38884]
trailer [38929,38940]
===
match
---
name: flatten_results [29178,29193]
name: flatten_results [29234,29249]
===
match
---
operator: = [56920,56921]
operator: = [56976,56977]
===
match
---
name: location [7246,7254]
name: location [7246,7254]
===
match
---
trailer [98049,98056]
trailer [98105,98112]
===
match
---
funcdef [96601,96771]
funcdef [96657,96827]
===
match
---
name: google_cloud_storage_conn_id [38515,38543]
name: google_cloud_storage_conn_id [38571,38599]
===
match
---
name: str [81401,81404]
name: str [81457,81460]
===
match
---
atom_expr [71252,71267]
atom_expr [71308,71323]
===
match
---
operator: , [51955,51956]
operator: , [52011,52012]
===
match
---
name: dataset_resource [70716,70732]
name: dataset_resource [70772,70788]
===
match
---
name: dataset_id [18823,18833]
name: dataset_id [18823,18833]
===
match
---
name: Optional [47698,47706]
name: Optional [47754,47762]
===
match
---
operator: = [64273,64274]
operator: = [64329,64330]
===
match
---
name: warn [85294,85298]
name: warn [85350,85354]
===
match
---
expr_stmt [81996,82020]
expr_stmt [82052,82076]
===
match
---
expr_stmt [50439,50503]
expr_stmt [50495,50559]
===
match
---
operator: , [18767,18768]
operator: , [18767,18768]
===
match
---
name: source_objects [47604,47618]
name: source_objects [47660,47674]
===
match
---
fstring_expr [97093,97112]
fstring_expr [97149,97168]
===
match
---
trailer [39230,39248]
trailer [39286,39304]
===
match
---
name: int [47990,47993]
name: int [48046,48049]
===
match
---
trailer [51585,51600]
trailer [51641,51656]
===
match
---
trailer [51946,51955]
trailer [52002,52011]
===
match
---
tfpdef [26003,26034]
tfpdef [26003,26034]
===
match
---
name: self [41373,41377]
name: self [41429,41433]
===
match
---
name: bigquery_conn_id [84979,84995]
name: bigquery_conn_id [85035,85051]
===
match
---
operator: = [26669,26670]
operator: = [26669,26670]
===
match
---
trailer [74243,74270]
trailer [74299,74326]
===
match
---
name: self [7230,7234]
name: self [7230,7234]
===
match
---
name: str [17470,17473]
name: str [17470,17473]
===
match
---
atom_expr [82125,82183]
atom_expr [82181,82239]
===
match
---
simple_stmt [39580,39623]
simple_stmt [39636,39679]
===
match
---
trailer [85766,85775]
trailer [85822,85831]
===
match
---
return_stmt [67639,67805]
return_stmt [67695,67861]
===
match
---
name: location [10044,10052]
name: location [10044,10052]
===
match
---
classdef [71281,75122]
classdef [71337,75178]
===
match
---
name: Optional [81197,81205]
name: Optional [81253,81261]
===
match
---
trailer [50443,50472]
trailer [50499,50528]
===
match
---
operator: = [2353,2354]
operator: = [2353,2354]
===
match
---
operator: @ [25350,25351]
operator: @ [25350,25351]
===
match
---
parameters [90790,90805]
parameters [90846,90861]
===
match
---
name: self [96376,96380]
name: self [96432,96436]
===
match
---
name: Optional [26357,26365]
name: Optional [26357,26365]
===
match
---
name: delegate_to [56859,56870]
name: delegate_to [56915,56926]
===
match
---
atom_expr [30676,30702]
atom_expr [30732,30758]
===
match
---
operator: = [85094,85095]
operator: = [85150,85151]
===
match
---
name: write_disposition [25803,25820]
name: write_disposition [25803,25820]
===
match
---
expr_stmt [1924,1941]
expr_stmt [1924,1941]
===
match
---
operator: { [47403,47404]
operator: { [47459,47460]
===
match
---
name: Sequence [1038,1046]
name: Sequence [1038,1046]
===
match
---
param [61278,61283]
param [61334,61339]
===
match
---
name: bigquery_conn_id [85255,85271]
name: bigquery_conn_id [85311,85327]
===
match
---
name: table_resource [86297,86311]
name: table_resource [86353,86367]
===
match
---
name: BigQueryHook [96192,96204]
name: BigQueryHook [96248,96260]
===
match
---
param [56665,56672]
param [56721,56728]
===
match
---
name: self [56871,56875]
name: self [56927,56931]
===
match
---
trailer [98298,98304]
trailer [98354,98360]
===
match
---
name: str [70293,70296]
name: str [70349,70352]
===
match
---
trailer [85727,85739]
trailer [85783,85795]
===
match
---
operator: , [49101,49102]
operator: , [49157,49158]
===
match
---
name: template_fields [77473,77488]
name: template_fields [77529,77544]
===
match
---
operator: , [52313,52314]
operator: , [52369,52370]
===
match
---
atom_expr [39113,39128]
atom_expr [39169,39184]
===
match
---
trailer [96923,96959]
trailer [96979,97015]
===
match
---
name: self [25389,25393]
name: self [25389,25393]
===
match
---
name: self [97080,97084]
name: self [97136,97140]
===
match
---
name: self [60985,60989]
name: self [61041,61045]
===
match
---
operator: , [30808,30809]
operator: , [30864,30865]
===
match
---
name: flatten_results [27629,27644]
name: flatten_results [27685,27700]
===
match
---
operator: , [85969,85970]
operator: , [86025,86026]
===
match
---
param [47830,47857]
param [47886,47913]
===
match
---
operator: , [90059,90060]
operator: , [90115,90116]
===
match
---
expr_stmt [74320,74348]
expr_stmt [74376,74404]
===
match
---
trailer [40487,40507]
trailer [40543,40563]
===
match
---
operator: = [89880,89881]
operator: = [89936,89937]
===
match
---
atom_expr [90452,90476]
atom_expr [90508,90532]
===
match
---
name: get_dataset_tables [67654,67672]
name: get_dataset_tables [67710,67728]
===
match
---
name: self [70635,70639]
name: self [70691,70695]
===
match
---
param [17330,17346]
param [17330,17346]
===
match
---
classdef [82504,86383]
classdef [82560,86439]
===
match
---
operator: , [81118,81119]
operator: , [81174,81175]
===
match
---
trailer [67063,67090]
trailer [67119,67146]
===
match
---
name: delegate_to [18313,18324]
name: delegate_to [18313,18324]
===
match
---
name: dataset_id [38167,38177]
name: dataset_id [38223,38233]
===
match
---
operator: , [78436,78437]
operator: , [78492,78493]
===
match
---
name: impersonation_chain [55941,55960]
name: impersonation_chain [55997,56016]
===
match
---
operator: = [26617,26618]
operator: = [26617,26618]
===
match
---
operator: , [80956,80957]
operator: , [81012,81013]
===
match
---
parameters [82092,82107]
parameters [82148,82163]
===
match
---
name: schema_object [51089,51102]
name: schema_object [51145,51158]
===
match
---
operator: = [40365,40366]
operator: = [40421,40422]
===
match
---
simple_stmt [74634,74661]
simple_stmt [74690,74717]
===
match
---
name: Optional [17609,17617]
name: Optional [17609,17617]
===
match
---
suite [13349,13921]
suite [13349,13921]
===
match
---
name: encryption_configuration [41197,41221]
name: encryption_configuration [41253,41277]
===
match
---
operator: -> [95323,95325]
operator: -> [95379,95381]
===
match
---
name: self [67177,67181]
name: self [67233,67237]
===
match
---
name: tolerance [9447,9456]
name: tolerance [9447,9456]
===
match
---
simple_stmt [59819,59949]
simple_stmt [59875,60005]
===
match
---
trailer [49352,49357]
trailer [49408,49413]
===
match
---
name: Any [94883,94886]
name: Any [94939,94942]
===
match
---
name: delegate_to [56525,56536]
name: delegate_to [56581,56592]
===
match
---
name: insert_job [96295,96305]
name: insert_job [96351,96361]
===
match
---
expr_stmt [56397,56425]
expr_stmt [56453,56481]
===
match
---
name: self [61870,61874]
name: self [61926,61930]
===
match
---
string: 'job_id' [2830,2838]
string: 'job_id' [2830,2838]
===
match
---
expr_stmt [74390,74418]
expr_stmt [74446,74474]
===
match
---
name: ui_color [17238,17246]
name: ui_color [17238,17246]
===
match
---
classdef [78950,82502]
classdef [79006,82558]
===
match
---
simple_stmt [63790,63891]
simple_stmt [63846,63947]
===
match
---
name: cluster_fields [28219,28233]
name: cluster_fields [28275,28289]
===
match
---
trailer [9632,9637]
trailer [9632,9637]
===
match
---
name: self [41587,41591]
name: self [41643,41647]
===
match
---
operator: = [38833,38834]
operator: = [38889,38890]
===
match
---
name: Optional [64171,64179]
name: Optional [64227,64235]
===
match
---
atom_expr [60163,60176]
atom_expr [60219,60232]
===
match
---
operator: , [82389,82390]
operator: , [82445,82446]
===
match
---
name: self [52710,52714]
name: self [52766,52770]
===
match
---
name: execute [50788,50795]
name: execute [50844,50851]
===
match
---
fstring_string: want to force rerun it consider setting `force_rerun=True`. [98344,98403]
fstring_string: want to force rerun it consider setting `force_rerun=True`. [98400,98459]
===
match
---
string: 'Total extracted rows: %s' [19048,19074]
string: 'Total extracted rows: %s' [19048,19074]
===
match
---
operator: = [48475,48476]
operator: = [48531,48532]
===
match
---
operator: * [9393,9394]
operator: * [9393,9394]
===
match
---
atom_expr [97442,97458]
atom_expr [97498,97514]
===
match
---
string: "_" [97296,97299]
string: "_" [97352,97355]
===
match
---
trailer [81032,81038]
trailer [81088,81094]
===
match
---
trailer [70944,71097]
trailer [71000,71153]
===
match
---
operator: , [9644,9645]
operator: , [9644,9645]
===
match
---
trailer [96122,96128]
trailer [96178,96184]
===
match
---
operator: , [74068,74069]
operator: , [74124,74125]
===
match
---
name: hook [86222,86226]
name: hook [86278,86282]
===
match
---
parameters [70086,70402]
parameters [70142,70458]
===
match
---
param [84928,84970]
param [84984,85026]
===
match
---
operator: = [51392,51393]
operator: = [51448,51449]
===
match
---
string: 'google_cloud_default' [64075,64097]
string: 'google_cloud_default' [64131,64153]
===
match
---
trailer [78653,78660]
trailer [78709,78716]
===
match
---
param [84831,84847]
param [84887,84903]
===
match
---
operator: = [9819,9820]
operator: = [9819,9820]
===
match
---
string: "table_resource" [84709,84725]
string: "table_resource" [84765,84781]
===
match
---
operator: , [74766,74767]
operator: , [74822,74823]
===
match
---
name: __init__ [48605,48613]
name: __init__ [48661,48669]
===
match
---
atom_expr [39326,39359]
atom_expr [39382,39415]
===
match
---
string: "You provided both `table_resource` and exclusive keywords arguments." [49753,49823]
string: "You provided both `table_resource` and exclusive keywords arguments." [49809,49879]
===
match
---
name: ui_color [84739,84747]
name: ui_color [84795,84803]
===
match
---
trailer [78508,78520]
trailer [78564,78576]
===
match
---
name: labels [28041,28047]
name: labels [28097,28103]
===
match
---
atom_expr [67292,67308]
atom_expr [67348,67364]
===
match
---
name: table_resource [49839,49853]
name: table_resource [49895,49909]
===
match
---
name: gcp_conn_id [55799,55810]
name: gcp_conn_id [55855,55866]
===
match
---
operator: = [70689,70690]
operator: = [70745,70746]
===
match
---
operator: , [6456,6457]
operator: , [6456,6457]
===
match
---
operator: } [97212,97213]
operator: } [97268,97269]
===
match
---
suite [31362,31454]
suite [31418,31510]
===
match
---
expr_stmt [19096,19139]
expr_stmt [19096,19139]
===
match
---
operator: = [55608,55609]
operator: = [55664,55665]
===
match
---
name: Union [38931,38936]
name: Union [38987,38992]
===
match
---
trailer [27220,27347]
trailer [27250,27403]
===
match
---
name: kwargs [67109,67115]
name: kwargs [67165,67171]
===
match
---
expr_stmt [18294,18324]
expr_stmt [18294,18324]
===
match
---
trailer [26429,26435]
trailer [26429,26435]
===
match
---
name: gcp_conn_id [66940,66951]
name: gcp_conn_id [66996,67007]
===
match
---
name: delegate_to [26051,26062]
name: delegate_to [26051,26062]
===
match
---
name: BaseOperator [64970,64982]
name: BaseOperator [65026,65038]
===
match
---
name: self [39918,39922]
name: self [39974,39978]
===
match
---
operator: , [28694,28695]
operator: , [28750,28751]
===
match
---
name: hook [18795,18799]
name: hook [18795,18799]
===
match
---
operator: , [17589,17590]
operator: , [17589,17590]
===
match
---
operator: = [52649,52650]
operator: = [52705,52706]
===
match
---
param [12955,12986]
param [12955,12986]
===
match
---
suite [40229,40605]
suite [40285,40661]
===
match
---
parameters [38132,39022]
parameters [38188,39078]
===
match
---
argument [29340,29386]
argument [29396,29442]
===
match
---
operator: = [60135,60136]
operator: = [60191,60192]
===
match
---
param [70904,70911]
param [70960,70967]
===
match
---
operator: , [17702,17703]
operator: , [17702,17703]
===
match
---
name: self [86092,86096]
name: self [86148,86152]
===
match
---
name: stacklevel [49650,49660]
name: stacklevel [49706,49716]
===
match
---
name: self [61749,61753]
name: self [61805,61809]
===
match
---
name: bigquery_conn_id [85539,85555]
name: bigquery_conn_id [85595,85611]
===
match
---
trailer [29926,29930]
trailer [29982,29986]
===
match
---
operator: = [28350,28351]
operator: = [28406,28407]
===
match
---
expr_stmt [39277,39317]
expr_stmt [39333,39373]
===
match
---
operator: , [3467,3468]
operator: , [3467,3468]
===
match
---
operator: = [61399,61400]
operator: = [61455,61456]
===
match
---
operator: = [40482,40483]
operator: = [40538,40539]
===
match
---
with_stmt [96042,96142]
with_stmt [96098,96198]
===
match
---
suite [51470,51518]
suite [51526,51574]
===
match
---
argument [41197,41251]
argument [41253,41307]
===
match
---
expr_stmt [6351,6463]
expr_stmt [6351,6463]
===
match
---
operator: = [78311,78312]
operator: = [78367,78368]
===
match
---
expr_stmt [85795,85841]
expr_stmt [85851,85897]
===
match
---
name: impersonation_chain [28798,28817]
name: impersonation_chain [28854,28873]
===
match
---
name: self [61700,61704]
name: self [61756,61760]
===
match
---
name: rows [18788,18792]
name: rows [18788,18792]
===
match
---
operator: = [51008,51009]
operator: = [51064,51065]
===
match
---
trailer [61404,61416]
trailer [61460,61472]
===
match
---
name: str [38828,38831]
name: str [38884,38887]
===
match
---
expr_stmt [27731,27759]
expr_stmt [27787,27815]
===
match
---
atom [84708,84734]
atom [84764,84790]
===
match
---
string: """     This operator is used to update table for your Project in BigQuery.     Use ``fields`` to specify which fields of table to update. If a field     is listed in ``fields`` and is ``None`` in table, it will be deleted.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryUpdateTableOperator`      :param dataset_id: The id of dataset. Don't need to provide,         if datasetId in table_reference.     :param table_id: The id of table. Don't need to provide,         if tableId in table_reference.     :type table_id: str     :param table_resource: Dataset resource that will be provided with request body.         https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#resource     :type table_resource: Dict[str, Any]     :param fields: The fields of ``table`` to change, spelled as the Table         properties (e.g. "friendly_name").     :type fields: List[str]     :param project_id: The name of the project where we want to create the table.         Don't need to provide, if projectId in table_reference.     :type project_id: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]      :rtype: table         https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#resource     """ [71334,73630]
string: """     This operator is used to update table for your Project in BigQuery.     Use ``fields`` to specify which fields of table to update. If a field     is listed in ``fields`` and is ``None`` in table, it will be deleted.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryUpdateTableOperator`      :param dataset_id: The id of dataset. Don't need to provide,         if datasetId in table_reference.     :param table_id: The id of table. Don't need to provide,         if tableId in table_reference.     :type table_id: str     :param table_resource: Dataset resource that will be provided with request body.         https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#resource     :type table_resource: Dict[str, Any]     :param fields: The fields of ``table`` to change, spelled as the Table         properties (e.g. "friendly_name").     :type fields: List[str]     :param project_id: The name of the project where we want to create the table.         Don't need to provide, if projectId in table_reference.     :type project_id: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]      :rtype: table         https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#resource     """ [71390,73686]
===
match
---
operator: = [55510,55511]
operator: = [55566,55567]
===
match
---
argument [71042,71086]
argument [71098,71142]
===
match
---
operator: , [6490,6491]
operator: , [6490,6491]
===
match
---
operator: , [13027,13028]
operator: , [13027,13028]
===
match
---
name: update_dataset [78726,78740]
name: update_dataset [78782,78796]
===
match
---
argument [97905,97918]
argument [97961,97974]
===
match
---
operator: = [61604,61605]
operator: = [61660,61661]
===
match
---
name: list [18448,18452]
name: list [18448,18452]
===
match
---
trailer [39080,39091]
trailer [39136,39147]
===
match
---
simple_stmt [56559,56606]
simple_stmt [56615,56662]
===
match
---
operator: , [85060,85061]
operator: , [85116,85117]
===
match
---
name: labels [10216,10222]
name: labels [10216,10222]
===
match
---
operator: = [2284,2285]
operator: = [2284,2285]
===
match
---
name: gcp_conn_id [56320,56331]
name: gcp_conn_id [56376,56387]
===
match
---
trailer [50703,50712]
trailer [50759,50768]
===
match
---
operator: = [30075,30076]
operator: = [30131,30132]
===
match
---
operator: , [85497,85498]
operator: , [85553,85554]
===
match
---
name: location [26685,26693]
name: location [26685,26693]
===
match
---
expr_stmt [74702,74877]
expr_stmt [74758,74933]
===
match
---
name: self [50005,50009]
name: self [50061,50065]
===
match
---
trailer [78861,78872]
trailer [78917,78928]
===
match
---
atom_expr [82409,82501]
atom_expr [82465,82557]
===
match
---
name: self [3104,3108]
name: self [3104,3108]
===
match
---
atom_expr [85891,85991]
atom_expr [85947,86047]
===
match
---
operator: , [70986,70987]
operator: , [71042,71043]
===
match
---
operator: { [97200,97201]
operator: { [97256,97257]
===
match
---
name: maximum_billing_tier [26174,26194]
name: maximum_billing_tier [26174,26194]
===
match
---
name: Optional [47800,47808]
name: Optional [47856,47864]
===
match
---
atom_expr [6753,6766]
atom_expr [6753,6766]
===
match
---
name: super [26888,26893]
name: super [26888,26893]
===
match
---
param [60193,60234]
param [60249,60290]
===
match
---
argument [40788,40814]
argument [40844,40870]
===
match
---
operator: , [56022,56023]
operator: , [56078,56079]
===
match
---
name: time_partitioning [28114,28131]
name: time_partitioning [28170,28187]
===
match
---
name: self [64331,64335]
name: self [64387,64391]
===
match
---
operator: , [38655,38656]
operator: , [38711,38712]
===
match
---
atom_expr [6813,6838]
atom_expr [6813,6838]
===
match
---
operator: = [95665,95666]
operator: = [95721,95722]
===
match
---
name: job [96574,96577]
name: job [96630,96633]
===
match
---
name: self [29477,29481]
name: self [29533,29537]
===
match
---
operator: = [39565,39566]
operator: = [39621,39622]
===
match
---
name: use_legacy_sql [7207,7221]
name: use_legacy_sql [7207,7221]
===
match
---
simple_stmt [18164,18200]
simple_stmt [18164,18200]
===
match
---
param [55850,55889]
param [55906,55945]
===
match
---
name: allow_quoted_newlines [52715,52736]
name: allow_quoted_newlines [52771,52792]
===
match
---
name: delegate_to [97430,97441]
name: delegate_to [97486,97497]
===
match
---
trailer [17265,17271]
trailer [17265,17271]
===
match
---
name: bucket [48668,48674]
name: bucket [48724,48730]
===
match
---
trailer [61239,61241]
trailer [61295,61297]
===
match
---
tfpdef [55799,55815]
tfpdef [55855,55871]
===
match
---
tfpdef [95103,95119]
tfpdef [95159,95175]
===
match
---
trailer [26965,26970]
trailer [26965,26970]
===
match
---
name: table_resource [51586,51600]
name: table_resource [51642,51656]
===
match
---
trailer [26114,26120]
trailer [26114,26120]
===
match
---
name: location [10055,10063]
name: location [10055,10063]
===
match
---
operator: } [98267,98268]
operator: } [98323,98324]
===
match
---
atom_expr [13845,13869]
atom_expr [13845,13869]
===
match
---
expr_stmt [28197,28233]
expr_stmt [28253,28289]
===
match
---
atom_expr [78596,78620]
atom_expr [78652,78676]
===
match
---
atom_expr [38778,38792]
atom_expr [38834,38848]
===
match
---
operator: , [13252,13253]
operator: , [13252,13253]
===
match
---
operator: , [41602,41603]
operator: , [41658,41659]
===
match
---
name: hook [97548,97552]
name: hook [97604,97608]
===
match
---
operator: , [9846,9847]
operator: , [9846,9847]
===
match
---
name: Optional [95068,95076]
name: Optional [95124,95132]
===
match
---
operator: , [9693,9694]
operator: , [9693,9694]
===
match
---
name: self [48728,48732]
name: self [48784,48788]
===
match
---
atom_expr [38329,38343]
atom_expr [38385,38399]
===
match
---
trailer [56833,56845]
trailer [56889,56901]
===
match
---
trailer [70349,70369]
trailer [70405,70425]
===
match
---
expr_stmt [27653,27683]
expr_stmt [27709,27739]
===
match
---
operator: = [13912,13913]
operator: = [13912,13913]
===
match
---
operator: = [60300,60301]
operator: = [60356,60357]
===
match
---
param [47583,47595]
param [47639,47651]
===
match
---
trailer [40847,40858]
trailer [40903,40914]
===
match
---
operator: = [96288,96289]
operator: = [96344,96345]
===
match
---
dictorsetmaker [94748,94771]
dictorsetmaker [94804,94827]
===
match
---
atom_expr [51405,51455]
atom_expr [51461,51511]
===
match
---
name: SQLValueCheckOperator [7396,7417]
name: SQLValueCheckOperator [7396,7417]
===
match
---
argument [78492,78520]
argument [78548,78576]
===
match
---
name: sql [25711,25714]
name: sql [25711,25714]
===
match
---
import_name [936,951]
import_name [936,951]
===
match
---
atom_expr [55610,55640]
atom_expr [55666,55696]
===
match
---
param [38272,38305]
param [38328,38361]
===
match
---
simple_stmt [48597,48624]
simple_stmt [48653,48680]
===
match
---
trailer [2979,2985]
trailer [2979,2985]
===
match
---
atom [37974,38029]
atom [38030,38085]
===
match
---
simple_stmt [1526,1603]
simple_stmt [1526,1603]
===
match
---
funcdef [95846,96142]
funcdef [95902,96198]
===
match
---
parameters [66795,67122]
parameters [66851,67178]
===
match
---
atom_expr [28488,28497]
atom_expr [28544,28553]
===
match
---
name: self [30383,30387]
name: self [30439,30443]
===
match
---
trailer [71210,71227]
trailer [71266,71283]
===
match
---
trailer [74361,74370]
trailer [74417,74426]
===
match
---
operator: , [66887,66888]
operator: , [66943,66944]
===
match
---
trailer [18466,18470]
trailer [18466,18470]
===
match
---
argument [78886,78899]
argument [78942,78955]
===
match
---
name: metrics_thresholds [13413,13431]
name: metrics_thresholds [13413,13431]
===
match
---
name: quote_character [50237,50252]
name: quote_character [50293,50308]
===
match
---
expr_stmt [18208,18246]
expr_stmt [18208,18246]
===
match
---
expr_stmt [60915,60943]
expr_stmt [60971,60999]
===
match
---
operator: = [66745,66746]
operator: = [66801,66802]
===
match
---
name: Sequence [81392,81400]
name: Sequence [81448,81456]
===
match
---
name: gcs_schema_object [38360,38377]
name: gcs_schema_object [38416,38433]
===
match
---
atom_expr [55962,55997]
atom_expr [56018,56053]
===
match
---
name: fields [73952,73958]
name: fields [74008,74014]
===
match
---
simple_stmt [17085,17234]
simple_stmt [17085,17234]
===
match
---
trailer [6684,6689]
trailer [6684,6689]
===
match
---
trailer [38604,38609]
trailer [38660,38665]
===
match
---
name: BigQueryHook [39960,39972]
name: BigQueryHook [40016,40028]
===
match
---
string: 'source_objects' [47202,47218]
string: 'source_objects' [47258,47274]
===
match
---
name: dataset_id [91168,91178]
name: dataset_id [91224,91234]
===
match
---
argument [71149,71175]
argument [71205,71231]
===
match
---
name: delegate_to [95154,95165]
name: delegate_to [95210,95221]
===
match
---
trailer [67782,67794]
trailer [67838,67850]
===
match
---
operator: , [60521,60522]
operator: , [60577,60578]
===
match
---
name: fields [78191,78197]
name: fields [78247,78253]
===
match
---
fstring_string: _ [97240,97241]
fstring_string: _ [97296,97297]
===
match
---
trailer [30737,30746]
trailer [30793,30802]
===
match
---
operator: , [38350,38351]
operator: , [38406,38407]
===
match
---
operator: { [97214,97215]
operator: { [97270,97271]
===
match
---
trailer [96917,96923]
trailer [96973,96979]
===
match
---
atom_expr [49742,49824]
atom_expr [49798,49880]
===
match
---
name: Optional [74008,74016]
name: Optional [74064,74072]
===
match
---
trailer [39154,39163]
trailer [39210,39219]
===
match
---
atom_expr [86178,86202]
atom_expr [86234,86258]
===
match
---
name: Sequence [55982,55990]
name: Sequence [56038,56046]
===
match
---
operator: , [26324,26325]
operator: , [26324,26325]
===
match
---
atom_expr [52542,52562]
atom_expr [52598,52618]
===
match
---
arglist [61594,61805]
arglist [61650,61861]
===
match
---
name: execute [85851,85858]
name: execute [85907,85914]
===
match
---
trailer [30001,31027]
trailer [30057,31083]
===
match
---
trailer [98781,98792]
trailer [98837,98848]
===
match
---
fstring_expr [96729,96741]
fstring_expr [96785,96797]
===
match
---
operator: ** [48614,48616]
operator: ** [48670,48672]
===
match
---
name: compression [47866,47877]
name: compression [47922,47933]
===
match
---
string: """     This operator deletes an existing dataset from your Project in Big query.     https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets/delete      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryDeleteDatasetOperator`      :param project_id: The project id of the dataset.     :type project_id: str     :param dataset_id: The dataset to be deleted.     :type dataset_id: str     :param delete_contents: (Optional) Whether to force the deletion even if the dataset is not empty.         Will delete all tables (if any) in the dataset if set to True.         Will raise HttpError 400: "{dataset_id} is still in use" if set to False and dataset is not empty.         The default value is False.     :type delete_contents: bool     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]      **Example**: ::          delete_temp_data = BigQueryDeleteDatasetOperator(             dataset_id='temp-dataset',             project_id='temp-project',             delete_contents=True, # Force the deletion of the dataset as well as its tables (if any).             gcp_conn_id='_my_gcp_conn_',             task_id='Deletetemp',             dag=dag)     """ [53029,55488]
string: """     This operator deletes an existing dataset from your Project in Big query.     https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets/delete      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryDeleteDatasetOperator`      :param project_id: The project id of the dataset.     :type project_id: str     :param dataset_id: The dataset to be deleted.     :type dataset_id: str     :param delete_contents: (Optional) Whether to force the deletion even if the dataset is not empty.         Will delete all tables (if any) in the dataset if set to True.         Will raise HttpError 400: "{dataset_id} is still in use" if set to False and dataset is not empty.         The default value is False.     :type delete_contents: bool     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]      **Example**: ::          delete_temp_data = BigQueryDeleteDatasetOperator(             dataset_id='temp-dataset',             project_id='temp-project',             delete_contents=True, # Force the deletion of the dataset as well as its tables (if any).             gcp_conn_id='_my_gcp_conn_',             task_id='Deletetemp',             dag=dag)     """ [53085,55544]
===
match
---
name: Optional [17569,17577]
name: Optional [17569,17577]
===
match
---
expr_stmt [27167,27197]
expr_stmt [27197,27227]
===
match
---
name: query_params [29482,29494]
name: query_params [29538,29550]
===
match
---
operator: = [13787,13788]
operator: = [13787,13788]
===
match
---
expr_stmt [50279,50329]
expr_stmt [50335,50385]
===
match
---
tfpdef [9577,9597]
tfpdef [9577,9597]
===
match
---
name: BigQueryCheckOperator [3425,3446]
name: BigQueryCheckOperator [3425,3446]
===
match
---
trailer [95521,95533]
trailer [95577,95589]
===
match
---
trailer [13114,13119]
trailer [13114,13119]
===
match
---
string: 'project_id' [66681,66693]
string: 'project_id' [66737,66749]
===
match
---
expr_stmt [50087,50129]
expr_stmt [50143,50185]
===
match
---
string: 'google_cloud_default' [84947,84969]
string: 'google_cloud_default' [85003,85025]
===
match
---
string: 'destination_dataset_table' [25164,25191]
string: 'destination_dataset_table' [25164,25191]
===
match
---
name: destination_dataset_table [28984,29009]
name: destination_dataset_table [29040,29065]
===
match
---
string: 'gcp_conn_id' [6394,6407]
string: 'gcp_conn_id' [6394,6407]
===
match
---
param [90287,90351]
param [90343,90407]
===
match
---
name: compression [52422,52433]
name: compression [52478,52489]
===
match
---
name: schema_update_options [30681,30702]
name: schema_update_options [30737,30758]
===
match
---
param [55668,55673]
param [55724,55729]
===
match
---
operator: = [97188,97189]
operator: = [97244,97245]
===
match
---
name: DATASET [70055,70062]
name: DATASET [70111,70118]
===
match
---
operator: , [6733,6734]
operator: , [6733,6734]
===
match
---
argument [70958,70986]
argument [71014,71042]
===
match
---
argument [28614,28642]
argument [28670,28698]
===
match
---
simple_stmt [19148,19166]
simple_stmt [19148,19166]
===
match
---
trailer [56631,56641]
trailer [56687,56697]
===
match
---
name: int [66919,66922]
name: int [66975,66978]
===
match
---
trailer [41381,41386]
trailer [41437,41442]
===
match
---
suite [91367,98831]
suite [91423,98887]
===
match
---
simple_stmt [84680,84735]
simple_stmt [84736,84791]
===
match
---
atom_expr [78546,78562]
atom_expr [78602,78618]
===
match
---
name: self [25686,25690]
name: self [25686,25690]
===
match
---
atom_expr [61548,61819]
atom_expr [61604,61875]
===
match
---
name: impersonation_chain [28424,28443]
name: impersonation_chain [28480,28499]
===
match
---
atom_expr [74579,74603]
atom_expr [74635,74659]
===
match
---
trailer [77666,77674]
trailer [77722,77730]
===
match
---
operator: = [6481,6482]
operator: = [6481,6482]
===
match
---
fstring_expr [98260,98268]
fstring_expr [98316,98324]
===
match
---
simple_stmt [40692,40724]
simple_stmt [40748,40780]
===
match
---
name: gcp_conn_id [60838,60849]
name: gcp_conn_id [60894,60905]
===
match
---
name: self [70970,70974]
name: self [71026,71030]
===
match
---
name: job [98577,98580]
name: job [98633,98636]
===
match
---
simple_stmt [39874,39901]
simple_stmt [39930,39957]
===
match
---
name: template_fields [25121,25136]
name: template_fields [25121,25136]
===
match
---
name: str [67084,67087]
name: str [67140,67143]
===
match
---
operator: = [7244,7245]
operator: = [7244,7245]
===
match
---
name: self [29733,29737]
name: self [29789,29793]
===
match
---
name: Optional [26649,26657]
name: Optional [26649,26657]
===
match
---
operator: = [39360,39361]
operator: = [39416,39417]
===
match
---
name: list [78664,78668]
name: list [78720,78724]
===
match
---
atom_expr [18651,18667]
atom_expr [18651,18667]
===
match
---
param [81066,81071]
param [81122,81127]
===
match
---
operator: , [12748,12749]
operator: , [12748,12749]
===
match
---
suite [40618,40666]
suite [40674,40722]
===
match
---
trailer [61924,61954]
trailer [61980,62010]
===
match
---
name: bigquery_conn_id [40003,40019]
name: bigquery_conn_id [40059,40075]
===
match
---
classdef [41668,52972]
classdef [41724,53028]
===
match
---
operator: , [41179,41180]
operator: , [41235,41236]
===
match
---
operator: , [80987,80988]
operator: , [81043,81044]
===
match
---
operator: = [39129,39130]
operator: = [39185,39186]
===
match
---
name: cluster_fields [30918,30932]
name: cluster_fields [30974,30988]
===
match
---
name: re [97277,97279]
name: re [97333,97335]
===
match
---
expr_stmt [56360,56388]
expr_stmt [56416,56444]
===
match
---
operator: = [51848,51849]
operator: = [51904,51905]
===
match
---
name: gcp_conn_id [61346,61357]
name: gcp_conn_id [61402,61413]
===
match
---
name: DeprecationWarning [70534,70552]
name: DeprecationWarning [70590,70608]
===
match
---
param [66940,66982]
param [66996,67038]
===
match
---
name: self [67430,67434]
name: self [67486,67490]
===
match
---
operator: = [97569,97570]
operator: = [97625,97626]
===
match
---
name: get_db_hook [3092,3103]
name: get_db_hook [3092,3103]
===
match
---
operator: * [25700,25701]
operator: * [25700,25701]
===
match
---
operator: != [51126,51128]
operator: != [51182,51184]
===
match
---
name: allow_jagged_rows [48099,48116]
name: allow_jagged_rows [48155,48172]
===
match
---
name: _BigQueryDbHookMixin [10270,10290]
name: _BigQueryDbHookMixin [10270,10290]
===
match
---
operator: , [61804,61805]
operator: , [61860,61861]
===
match
---
operator: , [40507,40508]
operator: , [40563,40564]
===
match
---
name: maximum_bytes_billed [26226,26246]
name: maximum_bytes_billed [26226,26246]
===
match
---
trailer [31438,31451]
trailer [31494,31507]
===
match
---
name: dataset_resource [71189,71205]
name: dataset_resource [71245,71261]
===
match
---
name: impersonation_chain [18723,18742]
name: impersonation_chain [18723,18742]
===
match
---
atom_expr [55911,55924]
atom_expr [55967,55980]
===
match
---
atom_expr [6508,6536]
atom_expr [6508,6536]
===
match
---
name: bq_hook [64532,64539]
name: bq_hook [64588,64595]
===
match
---
name: BigQueryUIColors [12820,12836]
name: BigQueryUIColors [12820,12836]
===
match
---
argument [85233,85241]
argument [85289,85297]
===
match
---
tfpdef [60334,60365]
tfpdef [60390,60421]
===
match
---
atom_expr [52486,52508]
atom_expr [52542,52564]
===
match
---
operator: = [84587,84588]
operator: = [84643,84644]
===
match
---
name: str [95233,95236]
name: str [95289,95292]
===
match
---
argument [30768,30808]
argument [30824,30864]
===
match
---
operator: , [18434,18435]
operator: , [18434,18435]
===
match
---
operator: = [96953,96954]
operator: = [97009,97010]
===
match
---
operator: , [48130,48131]
operator: , [48186,48187]
===
match
---
trailer [73932,73942]
trailer [73988,73998]
===
match
---
testlist_comp [9299,9306]
testlist_comp [9299,9306]
===
match
---
simple_stmt [96284,96466]
simple_stmt [96340,96522]
===
match
---
name: self [39580,39584]
name: self [39636,39640]
===
match
---
name: labels [6856,6862]
name: labels [6856,6862]
===
match
---
trailer [81248,81253]
trailer [81304,81309]
===
match
---
atom_expr [39076,39091]
atom_expr [39132,39147]
===
match
---
atom_expr [38231,38255]
atom_expr [38287,38311]
===
match
---
tfpdef [9614,9637]
tfpdef [9614,9637]
===
match
---
name: self [86312,86316]
name: self [86368,86372]
===
match
---
name: str [64186,64189]
name: str [64242,64245]
===
match
---
operator: , [29214,29215]
operator: , [29270,29271]
===
match
---
operator: = [97441,97442]
operator: = [97497,97498]
===
match
---
trailer [39117,39128]
trailer [39173,39184]
===
match
---
atom_expr [40084,40097]
atom_expr [40140,40153]
===
match
---
expr_stmt [1692,1815]
expr_stmt [1692,1815]
===
match
---
operator: , [48044,48045]
operator: , [48100,48101]
===
match
---
trailer [18537,18548]
trailer [18537,18548]
===
match
---
name: warn [70430,70434]
name: warn [70486,70490]
===
match
---
atom_expr [70190,70203]
atom_expr [70246,70259]
===
match
---
tfpdef [38752,38792]
tfpdef [38808,38848]
===
match
---
trailer [95347,95356]
trailer [95403,95412]
===
match
---
trailer [27696,27708]
trailer [27752,27764]
===
match
---
operator: = [51896,51897]
operator: = [51952,51953]
===
match
---
simple_stmt [90577,90606]
simple_stmt [90633,90662]
===
match
---
trailer [29574,29596]
trailer [29630,29652]
===
match
---
name: bigquery_conn_id [48140,48156]
name: bigquery_conn_id [48196,48212]
===
match
---
parameters [74677,74692]
parameters [74733,74748]
===
match
---
name: self [96097,96101]
name: self [96153,96157]
===
match
---
name: labels [50610,50616]
name: labels [50666,50672]
===
match
---
name: kwargs [90362,90368]
name: kwargs [90418,90424]
===
match
---
param [17305,17310]
param [17305,17310]
===
match
---
name: project_id [38272,38282]
name: project_id [38328,38338]
===
match
---
name: _DEPRECATION_MSG [13624,13640]
name: _DEPRECATION_MSG [13624,13640]
===
match
---
trailer [18747,18767]
trailer [18747,18767]
===
match
---
name: Union [6813,6818]
name: Union [6813,6818]
===
match
---
name: use_legacy_sql [28680,28694]
name: use_legacy_sql [28736,28750]
===
match
---
atom_expr [7263,7287]
atom_expr [7263,7287]
===
match
---
operator: ** [61251,61253]
operator: ** [61307,61309]
===
match
---
operator: , [7394,7395]
operator: , [7394,7395]
===
match
---
simple_stmt [81457,81484]
simple_stmt [81513,81540]
===
match
---
name: encryption_configuration [41227,41251]
name: encryption_configuration [41283,41307]
===
match
---
operator: = [41221,41222]
operator: = [41277,41278]
===
match
---
name: hook [95805,95809]
name: hook [95861,95865]
===
match
---
name: source_format [50010,50023]
name: source_format [50066,50079]
===
match
---
tfpdef [26452,26474]
tfpdef [26452,26474]
===
match
---
trailer [71164,71175]
trailer [71220,71231]
===
match
---
name: str [90172,90175]
name: str [90228,90231]
===
match
---
simple_stmt [39040,39067]
simple_stmt [39096,39123]
===
match
---
name: self [95800,95804]
name: self [95856,95860]
===
match
---
operator: -> [95873,95875]
operator: -> [95929,95931]
===
match
---
simple_stmt [97123,97173]
simple_stmt [97179,97229]
===
match
---
tfpdef [9478,9494]
tfpdef [9478,9494]
===
match
---
parameters [56658,56673]
parameters [56714,56729]
===
match
---
name: project_id [74078,74088]
name: project_id [74134,74144]
===
match
---
name: List [47620,47624]
name: List [47676,47680]
===
match
---
name: project_id [90582,90592]
name: project_id [90638,90648]
===
match
---
if_stmt [40176,40666]
if_stmt [40232,40722]
===
match
---
name: self [96924,96928]
name: self [96980,96984]
===
match
---
operator: , [97416,97417]
operator: , [97472,97473]
===
match
---
funcdef [47536,50779]
funcdef [47592,50835]
===
match
---
name: __init__ [77690,77698]
name: __init__ [77746,77754]
===
match
---
name: destination_project_dataset_table [51743,51776]
name: destination_project_dataset_table [51799,51832]
===
match
---
simple_stmt [95700,95747]
simple_stmt [95756,95803]
===
match
---
decorator [25350,25360]
decorator [25350,25360]
===
match
---
expr_stmt [28140,28188]
expr_stmt [28196,28244]
===
match
---
argument [67766,67794]
argument [67822,67850]
===
match
---
name: keys [78691,78695]
name: keys [78747,78751]
===
match
---
atom_expr [51790,52017]
atom_expr [51846,52073]
===
match
---
name: destination_dataset_table [30081,30106]
name: destination_dataset_table [30137,30162]
===
match
---
string: "Please use provide table definition using `table_resource` parameter." [49462,49533]
string: "Please use provide table definition using `table_resource` parameter." [49518,49589]
===
match
---
atom_expr [38045,38073]
atom_expr [38101,38129]
===
match
---
atom_expr [97001,97019]
atom_expr [97057,97075]
===
match
---
name: self [64875,64879]
name: self [64931,64935]
===
match
---
string: 'google_cloud_default' [66959,66981]
string: 'google_cloud_default' [67015,67037]
===
match
---
name: stacklevel [81726,81736]
name: stacklevel [81782,81792]
===
match
---
name: str [17578,17581]
name: str [17578,17581]
===
match
---
atom_expr [82478,82500]
atom_expr [82534,82556]
===
match
---
not_test [2851,2862]
not_test [2851,2862]
===
match
---
name: configuration [96319,96332]
name: configuration [96375,96388]
===
match
---
name: isinstance [29911,29921]
name: isinstance [29967,29977]
===
match
---
name: job_ids [2903,2910]
name: job_ids [2903,2910]
===
match
---
arglist [18823,19014]
arglist [18823,19014]
===
match
---
param [84806,84811]
param [84862,84867]
===
match
---
expr_stmt [37729,37941]
expr_stmt [37785,37997]
===
match
---
argument [67490,67518]
argument [67546,67574]
===
match
---
atom_expr [9684,9709]
atom_expr [9684,9709]
===
match
---
trailer [49883,49917]
trailer [49939,49973]
===
match
---
name: self [85565,85569]
name: self [85621,85625]
===
match
---
param [38409,38450]
param [38465,38506]
===
match
---
simple_stmt [61857,61955]
simple_stmt [61913,62011]
===
match
---
param [50796,50801]
param [50852,50857]
===
match
---
name: template_fields [80904,80919]
name: template_fields [80960,80975]
===
match
---
name: context [70904,70911]
name: context [70960,70967]
===
match
---
number: 100 [17397,17400]
number: 100 [17397,17400]
===
match
---
simple_stmt [924,936]
simple_stmt [924,936]
===
match
---
trailer [91074,91096]
trailer [91130,91152]
===
match
---
trailer [7189,7204]
trailer [7189,7204]
===
match
---
trailer [30150,30168]
trailer [30206,30224]
===
match
---
operator: , [9253,9254]
operator: , [9253,9254]
===
match
---
atom_expr [67544,67560]
atom_expr [67600,67616]
===
match
---
name: project_id [85665,85675]
name: project_id [85721,85731]
===
match
---
trailer [74754,74766]
trailer [74810,74822]
===
match
---
operator: = [95394,95395]
operator: = [95450,95451]
===
match
---
operator: , [7055,7056]
operator: , [7055,7056]
===
match
---
atom_expr [26549,26563]
atom_expr [26549,26563]
===
match
---
param [6783,6847]
param [6783,6847]
===
match
---
trailer [85975,85990]
trailer [86031,86046]
===
match
---
tfpdef [48007,48037]
tfpdef [48063,48093]
===
match
---
tfpdef [55760,55781]
tfpdef [55816,55837]
===
match
---
operator: = [28915,28916]
operator: = [28971,28972]
===
match
---
name: self [31375,31379]
name: self [31431,31435]
===
match
---
operator: { [97079,97080]
operator: { [97135,97136]
===
match
---
simple_stmt [2876,2888]
simple_stmt [2876,2888]
===
match
---
simple_stmt [56966,57105]
simple_stmt [57022,57161]
===
match
---
arglist [86257,86372]
arglist [86313,86428]
===
match
---
atom_expr [55730,55743]
atom_expr [55786,55799]
===
match
---
operator: = [78464,78465]
operator: = [78520,78521]
===
match
---
testlist_comp [29982,31061]
testlist_comp [30038,31117]
===
match
---
name: gcp_conn_id [60990,61001]
name: gcp_conn_id [61046,61057]
===
match
---
argument [82267,82295]
argument [82323,82351]
===
match
---
name: dataset_id [78108,78118]
name: dataset_id [78164,78174]
===
match
---
name: execute [18422,18429]
name: execute [18422,18429]
===
match
---
import_from [982,1071]
import_from [982,1071]
===
match
---
tfpdef [73952,73979]
tfpdef [74008,74035]
===
match
---
expr_stmt [48654,48674]
expr_stmt [48710,48730]
===
match
---
trailer [98554,98561]
trailer [98610,98617]
===
match
---
name: materialized_view [39605,39622]
name: materialized_view [39661,39678]
===
match
---
name: Optional [38329,38337]
name: Optional [38385,38393]
===
match
---
name: cancel_on_kill [98652,98666]
name: cancel_on_kill [98708,98722]
===
match
---
atom_expr [90692,90716]
atom_expr [90748,90772]
===
match
---
tfpdef [26633,26668]
tfpdef [26633,26668]
===
match
---
trailer [81871,81883]
trailer [81927,81939]
===
match
---
operator: , [64512,64513]
operator: , [64568,64569]
===
match
---
name: self [95867,95871]
name: self [95923,95927]
===
match
---
string: 'google_cloud_default' [81147,81169]
string: 'google_cloud_default' [81203,81225]
===
match
---
name: bq_hook [90815,90822]
name: bq_hook [90871,90878]
===
match
---
name: self [28519,28523]
name: self [28575,28579]
===
match
---
operator: , [60415,60416]
operator: , [60471,60472]
===
match
---
operator: = [64207,64208]
operator: = [64263,64264]
===
match
---
trailer [98757,98764]
trailer [98813,98820]
===
match
---
name: gcp_conn_id [7142,7153]
name: gcp_conn_id [7142,7153]
===
match
---
trailer [51853,51868]
trailer [51909,51924]
===
match
---
atom_expr [78333,78357]
atom_expr [78389,78413]
===
match
---
atom_expr [6676,6689]
atom_expr [6676,6689]
===
match
---
operator: = [6767,6768]
operator: = [6767,6768]
===
match
---
arglist [51197,51351]
arglist [51253,51407]
===
match
---
name: gcp_conn_id [90633,90644]
name: gcp_conn_id [90689,90700]
===
match
---
name: self [67140,67144]
name: self [67196,67200]
===
match
---
parameters [28460,28475]
parameters [28516,28531]
===
match
---
suite [17801,18085]
suite [17801,18085]
===
match
---
sync_comp_for [19123,19138]
sync_comp_for [19123,19138]
===
match
---
name: dttm [2218,2222]
name: dttm [2218,2222]
===
match
---
atom_expr [71160,71175]
atom_expr [71216,71231]
===
match
---
trailer [74544,74556]
trailer [74600,74612]
===
match
---
atom_expr [29194,29214]
atom_expr [29250,29270]
===
match
---
trailer [26204,26209]
trailer [26204,26209]
===
match
---
trailer [40210,40228]
trailer [40266,40284]
===
match
---
operator: , [64004,64005]
operator: , [64060,64061]
===
match
---
operator: = [29476,29477]
operator: = [29532,29533]
===
match
---
trailer [29365,29386]
trailer [29421,29442]
===
match
---
name: Optional [60253,60261]
name: Optional [60309,60317]
===
match
---
operator: = [81778,81779]
operator: = [81834,81835]
===
match
---
expr_stmt [13900,13920]
expr_stmt [13900,13920]
===
match
---
name: _ [25575,25576]
name: _ [25575,25576]
===
match
---
operator: , [47672,47673]
operator: , [47728,47729]
===
match
---
atom_expr [97492,97516]
atom_expr [97548,97572]
===
match
---
name: allow_large_results [25851,25870]
name: allow_large_results [25851,25870]
===
match
---
operator: = [56789,56790]
operator: = [56845,56846]
===
match
---
trailer [18697,18709]
trailer [18697,18709]
===
match
---
operator: , [81708,81709]
operator: , [81764,81765]
===
match
---
name: table_id [74038,74046]
name: table_id [74094,74102]
===
match
---
operator: { [73789,73790]
operator: { [73845,73846]
===
match
---
param [48007,48045]
param [48063,48101]
===
match
---
name: self [67737,67741]
name: self [67793,67797]
===
match
---
atom_expr [73969,73978]
atom_expr [74025,74034]
===
match
---
simple_stmt [2714,2768]
simple_stmt [2714,2768]
===
match
---
trailer [73853,73859]
trailer [73909,73915]
===
match
---
string: 'BigQuery Console' [2102,2120]
string: 'BigQuery Console' [2102,2120]
===
match
---
arglist [64836,64890]
arglist [64892,64946]
===
match
---
trailer [78668,78698]
trailer [78724,78754]
===
match
---
name: str [96857,96860]
name: str [96913,96916]
===
match
---
expr_stmt [56481,56511]
expr_stmt [56537,56567]
===
match
---
arglist [85905,85990]
arglist [85961,86046]
===
match
---
trailer [95455,95462]
trailer [95511,95518]
===
match
---
tfpdef [9422,9437]
tfpdef [9422,9437]
===
match
---
operator: , [50800,50801]
operator: , [50856,50857]
===
match
---
if_stmt [25446,25520]
if_stmt [25446,25520]
===
match
---
name: time_partitioning [40961,40978]
name: time_partitioning [41017,41034]
===
match
---
param [90016,90060]
param [90072,90116]
===
match
---
name: project_id [61594,61604]
name: project_id [61650,61660]
===
match
---
name: self [48683,48687]
name: self [48739,48743]
===
match
---
name: allow_jagged_rows [50343,50360]
name: allow_jagged_rows [50399,50416]
===
match
---
param [13213,13277]
param [13213,13277]
===
match
---
name: kwargs [13550,13556]
name: kwargs [13550,13556]
===
match
---
name: location [82012,82020]
name: location [82068,82076]
===
match
---
operator: = [64387,64388]
operator: = [64443,64444]
===
match
---
trailer [67393,67402]
trailer [67449,67458]
===
match
---
trailer [19120,19122]
trailer [19120,19122]
===
match
---
name: self [30076,30080]
name: self [30132,30136]
===
match
---
funcdef [63942,64491]
funcdef [63998,64547]
===
match
---
dictorsetmaker [37975,38028]
dictorsetmaker [38031,38084]
===
match
---
name: str [70233,70236]
name: str [70289,70292]
===
match
---
operator: = [2807,2808]
operator: = [2807,2808]
===
match
---
operator: = [89663,89664]
operator: = [89719,89720]
===
match
---
operator: = [39661,39662]
operator: = [39717,39718]
===
match
---
name: str [55977,55980]
name: str [56033,56036]
===
match
---
name: dataset_id [40848,40858]
name: dataset_id [40904,40914]
===
match
---
trailer [74460,74472]
trailer [74516,74528]
===
match
---
argument [61466,61510]
argument [61522,61566]
===
match
---
simple_stmt [78177,78198]
simple_stmt [78233,78254]
===
match
---
string: 'dataset_id' [63818,63830]
string: 'dataset_id' [63874,63886]
===
match
---
trailer [75099,75110]
trailer [75155,75166]
===
match
---
operator: , [38262,38263]
operator: , [38318,38319]
===
match
---
atom_expr [2975,2985]
atom_expr [2975,2985]
===
match
---
param [77819,77852]
param [77875,77908]
===
match
---
operator: , [67073,67074]
operator: , [67129,67130]
===
match
---
atom_expr [94987,95000]
atom_expr [95043,95056]
===
match
---
import_name [924,935]
import_name [924,935]
===
match
---
operator: , [10290,10291]
operator: , [10290,10291]
===
match
---
expr_stmt [39874,39900]
expr_stmt [39930,39956]
===
match
---
name: max_results [18570,18581]
name: max_results [18570,18581]
===
match
---
simple_stmt [74579,74626]
simple_stmt [74635,74682]
===
match
---
expr_stmt [96284,96465]
expr_stmt [96340,96521]
===
match
---
name: BigQueryHook [61320,61332]
name: BigQueryHook [61376,61388]
===
match
---
expr_stmt [18131,18155]
expr_stmt [18131,18155]
===
match
---
name: enumerate [25580,25589]
name: enumerate [25580,25589]
===
match
---
tfpdef [96214,96225]
tfpdef [96270,96281]
===
match
---
operator: = [97623,97624]
operator: = [97679,97680]
===
match
---
atom_expr [29297,29322]
atom_expr [29353,29378]
===
match
---
trailer [40803,40814]
trailer [40859,40870]
===
match
---
dictorsetmaker [69995,70021]
dictorsetmaker [70051,70077]
===
match
---
name: __init__ [70078,70086]
name: __init__ [70134,70142]
===
match
---
simple_stmt [57167,59814]
simple_stmt [57223,59870]
===
match
---
operator: = [77887,77888]
operator: = [77943,77944]
===
match
---
operator: , [40814,40815]
operator: , [40870,40871]
===
match
---
name: configuration [94858,94871]
name: configuration [94914,94927]
===
match
---
name: template_fields [89647,89662]
name: template_fields [89703,89718]
===
match
---
atom_expr [97962,97982]
atom_expr [98018,98038]
===
match
---
trailer [56699,56704]
trailer [56755,56760]
===
match
---
decorator [96583,96597]
decorator [96639,96653]
===
match
---
operator: , [55789,55790]
operator: , [55845,55846]
===
match
---
expr_stmt [74456,74486]
expr_stmt [74512,74542]
===
match
---
atom [89833,89866]
atom [89889,89922]
===
match
---
atom_expr [28869,28894]
atom_expr [28925,28950]
===
match
---
funcdef [73865,74661]
funcdef [73921,74717]
===
match
---
string: "the gcp_conn_id parameter." [56198,56226]
string: "the gcp_conn_id parameter." [56254,56282]
===
match
---
argument [30362,30408]
argument [30418,30464]
===
match
---
tfpdef [48491,48547]
tfpdef [48547,48603]
===
match
---
name: self [39150,39154]
name: self [39206,39210]
===
match
---
simple_stmt [50185,50224]
simple_stmt [50241,50280]
===
match
---
atom_expr [3349,3373]
atom_expr [3349,3373]
===
match
---
param [13325,13334]
param [13325,13334]
===
match
---
argument [18863,18885]
argument [18863,18885]
===
match
---
expr_stmt [97619,97655]
expr_stmt [97675,97711]
===
match
---
expr_stmt [6468,6492]
expr_stmt [6468,6492]
===
match
---
trailer [96128,96141]
trailer [96184,96197]
===
match
---
name: udf_config [29232,29242]
name: udf_config [29288,29298]
===
match
---
name: str [38477,38480]
name: str [38533,38536]
===
match
---
name: impersonation_chain [64150,64169]
name: impersonation_chain [64206,64225]
===
match
---
trailer [40696,40700]
trailer [40752,40756]
===
match
---
operator: = [27470,27471]
operator: = [27526,27527]
===
match
---
fstring_expr [52066,52079]
fstring_expr [52122,52135]
===
match
---
tfpdef [26580,26616]
tfpdef [26580,26616]
===
match
---
name: str [60475,60478]
name: str [60531,60534]
===
match
---
param [26452,26482]
param [26452,26482]
===
match
---
name: job_id [95456,95462]
name: job_id [95512,95518]
===
match
---
expr_stmt [50390,50430]
expr_stmt [50446,50486]
===
match
---
trailer [89904,89910]
trailer [89960,89966]
===
match
---
name: job_id [96214,96220]
name: job_id [96270,96276]
===
match
---
arglist [86033,86203]
arglist [86089,86259]
===
match
---
atom_expr [82199,82400]
atom_expr [82255,82456]
===
match
---
atom_expr [56755,56770]
atom_expr [56811,56826]
===
match
---
name: impersonation_chain [74214,74233]
name: impersonation_chain [74270,74289]
===
match
---
operator: = [57073,57074]
operator: = [57129,57130]
===
match
---
tfpdef [12995,13022]
tfpdef [12995,13022]
===
match
---
name: api_core [1097,1105]
name: api_core [1097,1105]
===
match
---
simple_stmt [39774,39811]
simple_stmt [39830,39867]
===
match
---
name: sort_keys [96944,96953]
name: sort_keys [97000,97009]
===
match
---
name: sql [25595,25598]
name: sql [25595,25598]
===
match
---
name: BaseOperatorLink [1272,1288]
name: BaseOperatorLink [1272,1288]
===
match
---
string: "schema" [51630,51638]
string: "schema" [51686,51694]
===
match
---
argument [98794,98816]
argument [98850,98872]
===
match
---
atom_expr [77873,77886]
atom_expr [77929,77942]
===
match
---
atom_expr [98075,98102]
atom_expr [98131,98158]
===
match
---
simple_stmt [90540,90569]
simple_stmt [90596,90625]
===
match
---
name: execute [64500,64507]
name: execute [64556,64563]
===
match
---
trailer [38436,38442]
trailer [38492,38498]
===
match
---
string: 'deletion_dataset_table' [80932,80956]
string: 'deletion_dataset_table' [80988,81012]
===
match
---
name: str [95176,95179]
name: str [95232,95235]
===
match
---
simple_stmt [96546,96559]
simple_stmt [96602,96615]
===
match
---
operator: * [47572,47573]
operator: * [47628,47629]
===
match
---
atom_expr [97832,97847]
atom_expr [97888,97903]
===
match
---
atom_expr [39819,39843]
atom_expr [39875,39899]
===
match
---
operator: = [97911,97912]
operator: = [97967,97968]
===
match
---
argument [57002,57028]
argument [57058,57084]
===
match
---
name: table_id [75062,75070]
name: table_id [75118,75126]
===
match
---
operator: , [84637,84638]
operator: , [84693,84694]
===
match
---
name: warn [81535,81539]
name: warn [81591,81595]
===
match
---
atom_expr [2310,2361]
atom_expr [2310,2361]
===
match
---
name: __init__ [56623,56631]
name: __init__ [56679,56687]
===
match
---
operator: , [26845,26846]
operator: , [26845,26846]
===
match
---
name: destination_project_dataset_table [52235,52268]
name: destination_project_dataset_table [52291,52324]
===
match
---
name: compression [52439,52450]
name: compression [52495,52506]
===
match
---
name: uniqueness_suffix [97242,97259]
name: uniqueness_suffix [97298,97315]
===
match
---
tfpdef [85027,85053]
tfpdef [85083,85109]
===
match
---
simple_stmt [18054,18085]
simple_stmt [18054,18085]
===
match
---
operator: , [97330,97331]
operator: , [97386,97387]
===
match
---
operator: = [2100,2101]
operator: = [2100,2101]
===
match
---
trailer [29140,29160]
trailer [29196,29216]
===
match
---
name: dict [26558,26562]
name: dict [26558,26562]
===
match
---
operator: , [90368,90369]
operator: , [90424,90425]
===
match
---
name: dataset_id [41592,41602]
name: dataset_id [41648,41658]
===
match
---
operator: = [56537,56538]
operator: = [56593,56594]
===
match
---
trailer [28554,28558]
trailer [28610,28614]
===
match
---
suite [97720,98528]
suite [97776,98584]
===
match
---
expr_stmt [27498,27542]
expr_stmt [27554,27598]
===
match
---
simple_stmt [56360,56389]
simple_stmt [56416,56445]
===
match
---
trailer [61443,61452]
trailer [61499,61508]
===
match
---
name: labels [49226,49232]
name: labels [49282,49288]
===
match
---
simple_stmt [98537,98562]
simple_stmt [98593,98618]
===
match
---
trailer [3038,3053]
trailer [3038,3053]
===
match
---
name: dict [26611,26615]
name: dict [26611,26615]
===
match
---
tfpdef [38702,38735]
tfpdef [38758,38791]
===
match
---
name: bucket [52072,52078]
name: bucket [52128,52134]
===
match
---
trailer [78210,78222]
trailer [78266,78278]
===
match
---
argument [41071,41089]
argument [41127,41145]
===
match
---
name: Optional [48512,48520]
name: Optional [48568,48576]
===
match
---
name: gcp_conn_id [9478,9489]
name: gcp_conn_id [9478,9489]
===
match
---
name: table_resource [47682,47696]
name: table_resource [47738,47752]
===
match
---
trailer [28596,28857]
trailer [28652,28913]
===
match
---
name: error_result [96665,96677]
name: error_result [96721,96733]
===
match
---
trailer [27990,28003]
trailer [28046,28059]
===
match
---
operator: { [96729,96730]
operator: { [96785,96786]
===
match
---
name: self [82318,82322]
name: self [82374,82378]
===
match
---
name: self [67544,67548]
name: self [67600,67604]
===
match
---
param [70096,70101]
param [70152,70157]
===
match
---
param [77903,77945]
param [77959,78001]
===
match
---
name: self [50232,50236]
name: self [50288,50292]
===
match
---
trailer [86316,86331]
trailer [86372,86387]
===
match
---
atom_expr [18164,18180]
atom_expr [18164,18180]
===
match
---
simple_stmt [51161,51366]
simple_stmt [51217,51422]
===
match
---
name: Optional [38596,38604]
name: Optional [38652,38660]
===
match
---
name: SQLCheckOperator [3469,3485]
name: SQLCheckOperator [3469,3485]
===
match
---
atom_expr [40885,40898]
atom_expr [40941,40954]
===
match
---
param [97326,97331]
param [97382,97387]
===
match
---
param [2574,2578]
param [2574,2578]
===
match
---
string: 'impersonation_chain' [17205,17226]
string: 'impersonation_chain' [17205,17226]
===
match
---
operator: , [84611,84612]
operator: , [84667,84668]
===
match
---
operator: = [50617,50618]
operator: = [50673,50674]
===
match
---
string: """     Performs checks against BigQuery. The ``BigQueryCheckOperator`` expects     a sql query that will return a single row. Each value on that     first row is evaluated using python ``bool`` casting. If any of the     values return ``False`` the check is failed and errors out.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryCheckOperator`      Note that Python bool casting evals the following as ``False``:      * ``False``     * ``0``     * Empty string (``""``)     * Empty list (``[]``)     * Empty dictionary or set (``{}``)      Given a query like ``SELECT COUNT(*) FROM foo``, it will fail only if     the count ``== 0``. You can craft much more complex query that could,     for instance, check that the table has the same number of rows as     the source table upstream, or that the count of today's partition is     greater than yesterday's partition, or that a set of metrics are less     than 3 standard deviation for the 7 day average.      This operator can be used as a data quality check in your pipeline, and     depending on where you put it in your DAG, you have the choice to     stop the critical path, preventing from     publishing dubious data, or on the side and receive email alerts     without stopping the progress of the DAG.      :param sql: the sql to be executed     :type sql: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param use_legacy_sql: Whether to use legacy SQL (true)         or standard SQL (false).     :type use_legacy_sql: bool     :param location: The geographic location of the job. See details at:         https://cloud.google.com/bigquery/docs/locations#specifying_your_location     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     :param labels: a dictionary containing labels for the table, passed to BigQuery     :type labels: dict     """ [3492,6345]
string: """     Performs checks against BigQuery. The ``BigQueryCheckOperator`` expects     a sql query that will return a single row. Each value on that     first row is evaluated using python ``bool`` casting. If any of the     values return ``False`` the check is failed and errors out.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryCheckOperator`      Note that Python bool casting evals the following as ``False``:      * ``False``     * ``0``     * Empty string (``""``)     * Empty list (``[]``)     * Empty dictionary or set (``{}``)      Given a query like ``SELECT COUNT(*) FROM foo``, it will fail only if     the count ``== 0``. You can craft much more complex query that could,     for instance, check that the table has the same number of rows as     the source table upstream, or that the count of today's partition is     greater than yesterday's partition, or that a set of metrics are less     than 3 standard deviation for the 7 day average.      This operator can be used as a data quality check in your pipeline, and     depending on where you put it in your DAG, you have the choice to     stop the critical path, preventing from     publishing dubious data, or on the side and receive email alerts     without stopping the progress of the DAG.      :param sql: the sql to be executed     :type sql: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param use_legacy_sql: Whether to use legacy SQL (true)         or standard SQL (false).     :type use_legacy_sql: bool     :param location: The geographic location of the job. See details at:         https://cloud.google.com/bigquery/docs/locations#specifying_your_location     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     :param labels: a dictionary containing labels for the table, passed to BigQuery     :type labels: dict     """ [3492,6345]
===
match
---
argument [61740,61762]
argument [61796,61818]
===
match
---
name: table_resource [51834,51848]
name: table_resource [51890,51904]
===
match
---
name: project_id [75084,75094]
name: project_id [75140,75150]
===
match
---
name: write_disposition [30151,30168]
name: write_disposition [30207,30224]
===
match
---
trailer [90511,90520]
trailer [90567,90576]
===
match
---
trailer [39733,39748]
trailer [39789,39804]
===
match
---
trailer [7322,7329]
trailer [7322,7329]
===
match
---
operator: -> [96641,96643]
operator: -> [96697,96699]
===
match
---
fstring_expr [97214,97228]
fstring_expr [97270,97284]
===
match
---
argument [13548,13556]
argument [13548,13556]
===
match
---
atom_expr [78466,78631]
atom_expr [78522,78687]
===
match
---
operator: = [47443,47444]
operator: = [47499,47500]
===
match
---
argument [18723,18767]
argument [18723,18767]
===
match
---
name: __init__ [26896,26904]
name: __init__ [26896,26904]
===
match
---
operator: , [31255,31256]
operator: , [31311,31312]
===
match
---
atom_expr [29477,29494]
atom_expr [29533,29550]
===
match
---
trailer [10160,10180]
trailer [10160,10180]
===
match
---
argument [78576,78620]
argument [78632,78676]
===
match
---
argument [97388,97416]
argument [97444,97472]
===
match
---
atom_expr [27380,27410]
atom_expr [27436,27466]
===
match
---
name: self [40799,40803]
name: self [40855,40859]
===
match
---
name: delegate_to [71000,71011]
name: delegate_to [71056,71067]
===
match
---
expr_stmt [40318,40522]
expr_stmt [40374,40578]
===
match
---
name: info [41382,41386]
name: info [41438,41442]
===
match
---
import_as_names [1500,1525]
import_as_names [1500,1525]
===
match
---
operator: = [39416,39417]
operator: = [39472,39473]
===
match
---
expr_stmt [17085,17233]
expr_stmt [17085,17233]
===
match
---
atom_expr [51984,52002]
atom_expr [52040,52058]
===
match
---
operator: , [12985,12986]
operator: , [12985,12986]
===
match
---
trailer [61490,61510]
trailer [61546,61566]
===
match
---
name: encryption_configuration [52932,52956]
name: encryption_configuration [52988,53012]
===
match
---
name: sub [97280,97283]
name: sub [97336,97339]
===
match
---
simple_stmt [81996,82021]
simple_stmt [82052,82077]
===
match
---
name: gcp_conn_id [78492,78503]
name: gcp_conn_id [78548,78559]
===
match
---
argument [52634,52670]
argument [52690,52726]
===
match
---
operator: = [86091,86092]
operator: = [86147,86148]
===
match
---
name: str [77840,77843]
name: str [77896,77899]
===
match
---
expr_stmt [96097,96141]
expr_stmt [96153,96197]
===
match
---
simple_stmt [1183,1231]
simple_stmt [1183,1231]
===
match
---
classdef [1818,1988]
classdef [1818,1988]
===
match
---
and_test [98631,98666]
and_test [98687,98722]
===
match
---
name: schema_fields [51530,51543]
name: schema_fields [51586,51599]
===
match
---
expr_stmt [95480,95508]
expr_stmt [95536,95564]
===
match
---
atom_expr [74894,75121]
atom_expr [74950,75177]
===
match
---
name: s [2388,2389]
name: s [2388,2389]
===
match
---
name: BigQueryHook [67464,67476]
name: BigQueryHook [67520,67532]
===
match
---
name: value [73854,73859]
name: value [73910,73915]
===
match
---
trailer [13262,13267]
trailer [13262,13267]
===
match
---
trailer [60474,60479]
trailer [60530,60535]
===
match
---
trailer [74796,74808]
trailer [74852,74864]
===
match
---
operator: , [26520,26521]
operator: , [26520,26521]
===
match
---
name: self [28880,28884]
name: self [28936,28940]
===
match
---
name: set [95686,95689]
name: set [95742,95745]
===
match
---
operator: = [84706,84707]
operator: = [84762,84763]
===
match
---
atom_expr [29423,29446]
atom_expr [29479,29502]
===
match
---
operator: = [28217,28218]
operator: = [28273,28274]
===
match
---
param [48140,48187]
param [48196,48243]
===
match
---
name: Sequence [26823,26831]
name: Sequence [26823,26831]
===
match
---
name: __init__ [73869,73877]
name: __init__ [73925,73933]
===
match
---
name: Optional [13294,13302]
name: Optional [13294,13302]
===
match
---
tfpdef [17508,17539]
tfpdef [17508,17539]
===
match
---
operator: , [38799,38800]
operator: , [38855,38856]
===
match
---
name: kwargs [56016,56022]
name: kwargs [56072,56078]
===
match
---
name: warn [27216,27220]
name: warn [27246,27250]
===
match
---
trailer [12836,12842]
trailer [12836,12842]
===
match
---
trailer [85651,85662]
trailer [85707,85718]
===
match
---
operator: @ [2551,2552]
operator: @ [2551,2552]
===
match
---
name: Optional [6753,6761]
name: Optional [6753,6761]
===
match
---
name: self [66805,66809]
name: self [66861,66865]
===
match
---
trailer [39056,39066]
trailer [39112,39122]
===
match
---
trailer [85139,85166]
trailer [85195,85222]
===
match
---
operator: , [86066,86067]
operator: , [86122,86123]
===
match
---
atom_expr [28550,28558]
atom_expr [28606,28614]
===
match
---
atom [61093,61095]
atom [61149,61151]
===
match
---
name: max_results [18169,18180]
name: max_results [18169,18180]
===
match
---
atom_expr [97080,97091]
atom_expr [97136,97147]
===
match
---
argument [64481,64489]
argument [64537,64545]
===
match
---
name: __init__ [70862,70870]
name: __init__ [70918,70926]
===
match
---
name: __init__ [84788,84796]
name: __init__ [84844,84852]
===
match
---
name: str [90337,90340]
name: str [90393,90396]
===
match
---
simple_stmt [81945,81988]
simple_stmt [82001,82044]
===
match
---
operator: , [28642,28643]
operator: , [28698,28699]
===
match
---
name: api_resource_configs [30830,30850]
name: api_resource_configs [30886,30906]
===
match
---
operator: = [75018,75019]
operator: = [75074,75075]
===
match
---
atom_expr [38721,38735]
atom_expr [38777,38791]
===
match
---
expr_stmt [78245,78285]
expr_stmt [78301,78341]
===
match
---
testlist_comp [17113,17227]
testlist_comp [17113,17227]
===
match
---
tfpdef [73912,73942]
tfpdef [73968,73998]
===
match
---
name: Optional [60395,60403]
name: Optional [60451,60459]
===
match
---
atom_expr [57013,57028]
atom_expr [57069,57084]
===
match
---
trailer [81464,81473]
trailer [81520,81529]
===
match
---
operator: , [81738,81739]
operator: , [81794,81795]
===
match
---
name: str [85160,85163]
name: str [85216,85219]
===
match
---
string: 'impersonation_chain' [59920,59941]
string: 'impersonation_chain' [59976,59997]
===
match
---
name: self [70598,70602]
name: self [70654,70658]
===
match
---
operator: = [50757,50758]
operator: = [50813,50814]
===
match
---
argument [67686,67712]
argument [67742,67768]
===
match
---
atom_expr [95800,95809]
atom_expr [95856,95865]
===
match
---
atom_expr [28397,28421]
atom_expr [28453,28477]
===
match
---
name: Optional [38671,38679]
name: Optional [38727,38735]
===
match
---
trailer [27817,27838]
trailer [27873,27894]
===
match
---
operator: = [59979,59980]
operator: = [60035,60036]
===
match
---
name: delete_dataset [56974,56988]
name: delete_dataset [57030,57044]
===
match
---
trailer [81949,81967]
trailer [82005,82023]
===
match
---
simple_stmt [74427,74448]
simple_stmt [74483,74504]
===
match
---
trailer [74056,74061]
trailer [74112,74117]
===
match
---
operator: = [25314,25315]
operator: = [25314,25315]
===
match
---
operator: = [61699,61700]
operator: = [61755,61756]
===
match
---
name: delegate_to [61109,61120]
name: delegate_to [61165,61176]
===
match
---
name: metrics_thresholds [13432,13450]
name: metrics_thresholds [13432,13450]
===
match
---
operator: , [90234,90235]
operator: , [90290,90291]
===
match
---
atom_expr [50232,50252]
atom_expr [50288,50308]
===
match
---
number: 3 [70577,70578]
number: 2 [70633,70634]
===
match
---
name: str [60172,60175]
name: str [60228,60231]
===
match
---
operator: = [51983,51984]
operator: = [52039,52040]
===
match
---
atom_expr [38671,38685]
atom_expr [38727,38741]
===
match
---
atom_expr [89991,90005]
atom_expr [90047,90061]
===
match
---
name: encryption_configuration [29828,29852]
name: encryption_configuration [29884,29908]
===
match
---
name: location [13817,13825]
name: location [13817,13825]
===
match
---
name: self [30575,30579]
name: self [30631,30635]
===
match
---
name: self [77708,77712]
name: self [77764,77768]
===
match
---
operator: , [47856,47857]
operator: , [47912,47913]
===
match
---
simple_stmt [48683,48720]
simple_stmt [48739,48776]
===
match
---
argument [86345,86371]
argument [86401,86427]
===
match
---
name: dataset_resource [70735,70751]
name: dataset_resource [70791,70807]
===
match
---
trailer [55919,55924]
trailer [55975,55980]
===
match
---
trailer [82369,82389]
trailer [82425,82445]
===
match
---
name: str [47591,47594]
name: str [47647,47650]
===
match
---
name: self [51849,51853]
name: self [51905,51909]
===
match
---
test [2310,2379]
test [2310,2379]
===
match
---
operator: = [52926,52927]
operator: = [52982,52983]
===
match
---
name: self [41078,41082]
name: self [41134,41138]
===
match
---
simple_stmt [49962,49997]
simple_stmt [50018,50053]
===
match
---
name: hash_base [96901,96910]
name: hash_base [96957,96966]
===
match
---
atom_expr [48597,48623]
atom_expr [48653,48679]
===
match
---
expr_stmt [18094,18122]
expr_stmt [18094,18122]
===
match
---
name: date_filter_column [13464,13482]
name: date_filter_column [13464,13482]
===
match
---
name: labels [3399,3405]
name: labels [3399,3405]
===
match
---
name: kwargs [64225,64231]
name: kwargs [64281,64287]
===
match
---
trailer [95689,95691]
trailer [95745,95747]
===
match
---
argument [2747,2766]
argument [2747,2766]
===
match
---
name: self [70096,70100]
name: self [70152,70156]
===
match
---
name: kwargs [61253,61259]
name: kwargs [61309,61315]
===
match
---
name: format [3032,3038]
name: format [3032,3038]
===
match
---
operator: = [41283,41284]
operator: = [41339,41340]
===
match
---
argument [2732,2745]
argument [2732,2745]
===
match
---
operator: = [50529,50530]
operator: = [50585,50586]
===
match
---
operator: = [51325,51326]
operator: = [51381,51382]
===
match
---
suite [40679,41505]
suite [40735,41561]
===
match
---
argument [40832,40858]
argument [40888,40914]
===
match
---
name: self [18333,18337]
name: self [18333,18337]
===
match
---
name: labels [41071,41077]
name: labels [41127,41133]
===
match
---
tfpdef [38272,38297]
tfpdef [38328,38353]
===
match
---
operator: ** [9869,9871]
operator: ** [9869,9871]
===
match
---
operator: , [47624,47625]
operator: , [47680,47681]
===
match
---
name: ignore_if_missing [81950,81967]
name: ignore_if_missing [82006,82023]
===
match
---
operator: , [47820,47821]
operator: , [47876,47877]
===
match
---
atom_expr [97045,97056]
atom_expr [97101,97112]
===
match
---
name: ti [2241,2243]
name: ti [2241,2243]
===
match
---
atom_expr [13234,13269]
atom_expr [13234,13269]
===
match
---
name: _handle_job_error [98080,98097]
name: _handle_job_error [98136,98153]
===
match
---
operator: , [89762,89763]
operator: , [89818,89819]
===
match
---
name: str [26073,26076]
name: str [26073,26076]
===
match
---
number: 3 [81737,81738]
number: 3 [81793,81794]
===
match
---
operator: , [51242,51243]
operator: , [51298,51299]
===
match
---
simple_stmt [97562,97593]
simple_stmt [97618,97649]
===
match
---
trailer [28279,28304]
trailer [28335,28360]
===
match
---
name: bigquery_conn_id [9529,9545]
name: bigquery_conn_id [9529,9545]
===
match
---
operator: = [95573,95574]
operator: = [95629,95630]
===
match
---
name: project_id [64014,64024]
name: project_id [64070,64080]
===
match
---
name: self [51107,51111]
name: self [51163,51167]
===
match
---
simple_stmt [2170,2224]
simple_stmt [2170,2224]
===
match
---
name: str [74057,74060]
name: str [74113,74116]
===
match
---
name: super [85216,85221]
name: super [85272,85277]
===
match
---
string: """     Checks that the values of metrics given as SQL expressions are within     a certain tolerance of the ones from days_back before.      This method constructs a query like so ::          SELECT {metrics_threshold_dict_key} FROM {table}         WHERE {date_filter_column}=<date>      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryIntervalCheckOperator`      :param table: the table name     :type table: str     :param days_back: number of days between ds and the ds we want to check         against. Defaults to 7 days     :type days_back: int     :param metrics_thresholds: a dictionary of ratios indexed by metrics, for         example 'COUNT(*)': 1.5 would require a 50 percent or less difference         between the current day, and the prior days_back.     :type metrics_thresholds: dict     :param use_legacy_sql: Whether to use legacy SQL (true)         or standard SQL (false).     :type use_legacy_sql: bool     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param location: The geographic location of the job. See details at:         https://cloud.google.com/bigquery/docs/locations#specifying_your_location     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     :param labels: a dictionary containing labels for the table, passed to BigQuery     :type labels: dict     """ [10323,12652]
string: """     Checks that the values of metrics given as SQL expressions are within     a certain tolerance of the ones from days_back before.      This method constructs a query like so ::          SELECT {metrics_threshold_dict_key} FROM {table}         WHERE {date_filter_column}=<date>      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryIntervalCheckOperator`      :param table: the table name     :type table: str     :param days_back: number of days between ds and the ds we want to check         against. Defaults to 7 days     :type days_back: int     :param metrics_thresholds: a dictionary of ratios indexed by metrics, for         example 'COUNT(*)': 1.5 would require a 50 percent or less difference         between the current day, and the prior days_back.     :type metrics_thresholds: dict     :param use_legacy_sql: Whether to use legacy SQL (true)         or standard SQL (false).     :type use_legacy_sql: bool     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param location: The geographic location of the job. See details at:         https://cloud.google.com/bigquery/docs/locations#specifying_your_location     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     :param labels: a dictionary containing labels for the table, passed to BigQuery     :type labels: dict     """ [10323,12652]
===
match
---
name: job [98551,98554]
name: job [98607,98610]
===
match
---
name: Optional [13234,13242]
name: Optional [13234,13242]
===
match
---
param [77733,77766]
param [77789,77822]
===
match
---
name: str [81387,81390]
name: str [81443,81446]
===
match
---
name: project_id [97837,97847]
name: project_id [97893,97903]
===
match
---
operator: = [29671,29672]
operator: = [29727,29728]
===
match
---
argument [30128,30168]
argument [30184,30224]
===
match
---
trailer [78478,78631]
trailer [78534,78687]
===
match
---
name: dataset_id [66830,66840]
name: dataset_id [66886,66896]
===
match
---
operator: , [78520,78521]
operator: , [78576,78577]
===
match
---
name: schema_update_options [29575,29596]
name: schema_update_options [29631,29652]
===
match
---
simple_stmt [50390,50431]
simple_stmt [50446,50487]
===
match
---
return_stmt [78919,78947]
return_stmt [78975,79003]
===
match
---
argument [64652,64696]
argument [64708,64752]
===
match
---
trailer [70764,70776]
trailer [70820,70832]
===
match
---
trailer [90581,90592]
trailer [90637,90648]
===
match
---
atom_expr [13728,13744]
atom_expr [13728,13744]
===
match
---
funcdef [61266,62023]
funcdef [61322,62079]
===
match
---
trailer [56401,56412]
trailer [56457,56468]
===
match
---
import_from [1342,1441]
import_from [1342,1441]
===
match
---
param [90791,90796]
param [90847,90852]
===
match
---
operator: = [73829,73830]
operator: = [73885,73886]
===
match
---
name: cloud [1472,1477]
name: cloud [1472,1477]
===
match
---
operator: = [3259,3260]
operator: = [3259,3260]
===
match
---
name: template_fields_renderers [47375,47400]
name: template_fields_renderers [47431,47456]
===
match
---
name: Optional [26803,26811]
name: Optional [26803,26811]
===
match
---
name: location [39712,39720]
name: location [39768,39776]
===
match
---
name: api_resource_configs [28168,28188]
name: api_resource_configs [28224,28244]
===
match
---
name: self [97962,97966]
name: self [98018,98022]
===
match
---
operator: = [18229,18230]
operator: = [18229,18230]
===
match
---
string: "json" [89859,89865]
string: "json" [89915,89921]
===
match
---
atom [25291,25300]
atom [25291,25300]
===
match
---
operator: , [75034,75035]
operator: , [75090,75091]
===
match
---
trailer [17271,17277]
trailer [17271,17277]
===
match
---
operator: , [77944,77945]
operator: , [78000,78001]
===
match
---
if_stmt [95949,96142]
if_stmt [96005,96198]
===
match
---
name: value [12843,12848]
name: value [12843,12848]
===
match
---
trailer [50052,50064]
trailer [50108,50120]
===
match
---
operator: , [1270,1271]
operator: , [1270,1271]
===
match
---
operator: , [73986,73987]
operator: , [74042,74043]
===
match
---
atom_expr [26021,26034]
atom_expr [26021,26034]
===
match
---
simple_stmt [95595,95626]
simple_stmt [95651,95682]
===
match
---
atom_expr [40692,40723]
atom_expr [40748,40779]
===
match
---
expr_stmt [51581,51655]
expr_stmt [51637,51711]
===
match
---
expr_stmt [89647,89800]
expr_stmt [89703,89856]
===
match
---
trailer [9929,9934]
trailer [9929,9934]
===
match
---
name: str [6833,6836]
name: str [6833,6836]
===
match
---
operator: = [95432,95433]
operator: = [95488,95489]
===
match
---
try_stmt [61531,62023]
try_stmt [61587,62079]
===
match
---
operator: * [12890,12891]
operator: * [12890,12891]
===
match
---
name: quote_character [49086,49101]
name: quote_character [49142,49157]
===
match
---
trailer [1845,1850]
trailer [1845,1850]
===
match
---
operator: = [50024,50025]
operator: = [50080,50081]
===
match
---
tfpdef [17410,17440]
tfpdef [17410,17440]
===
match
---
expr_stmt [49962,49996]
expr_stmt [50018,50052]
===
match
---
atom_expr [78504,78520]
atom_expr [78560,78576]
===
match
---
string: 'task_instance' [31216,31231]
string: 'task_instance' [31272,31287]
===
match
---
operator: ** [48564,48566]
operator: ** [48620,48622]
===
match
---
name: configuration [96057,96070]
name: configuration [96113,96126]
===
match
---
trailer [48526,48546]
trailer [48582,48602]
===
match
---
param [26725,26773]
param [26725,26773]
===
match
---
return_stmt [98570,98587]
return_stmt [98626,98643]
===
match
---
name: impersonation_chain [67574,67593]
name: impersonation_chain [67630,67649]
===
match
---
atom_expr [52596,52616]
atom_expr [52652,52672]
===
match
---
param [85859,85864]
param [85915,85920]
===
match
---
if_stmt [13577,13719]
if_stmt [13577,13719]
===
match
---
name: info [64726,64730]
name: info [64782,64786]
===
match
---
operator: = [56413,56414]
operator: = [56469,56470]
===
match
---
param [82099,82106]
param [82155,82162]
===
match
---
name: destination_project_dataset_table [49884,49917]
name: destination_project_dataset_table [49940,49973]
===
match
---
string: """Get BigQuery DB Hook""" [3135,3161]
string: """Get BigQuery DB Hook""" [3135,3161]
===
match
---
operator: , [56292,56293]
operator: , [56348,56349]
===
match
---
param [26633,26676]
param [26633,26676]
===
match
---
operator: = [77845,77846]
operator: = [77901,77902]
===
match
---
name: key [31243,31246]
name: key [31299,31302]
===
match
---
atom_expr [17814,18041]
atom_expr [17814,18041]
===
match
---
name: Optional [90081,90089]
name: Optional [90137,90145]
===
match
---
trailer [52714,52736]
trailer [52770,52792]
===
match
---
name: str [81206,81209]
name: str [81262,81265]
===
match
---
operator: = [41330,41331]
operator: = [41386,41387]
===
match
---
name: self [97045,97049]
name: self [97101,97105]
===
match
---
operator: , [19013,19014]
operator: , [19013,19014]
===
match
---
name: hook [82192,82196]
name: hook [82248,82252]
===
match
---
name: Dict [48372,48376]
name: Dict [48428,48432]
===
match
---
param [47739,47776]
param [47795,47832]
===
match
---
simple_stmt [77473,77574]
simple_stmt [77529,77630]
===
match
---
funcdef [66783,67413]
funcdef [66839,67469]
===
match
---
param [60084,60089]
param [60140,60145]
===
match
---
name: self [3394,3398]
name: self [3394,3398]
===
match
---
name: BigQueryConsoleIndexableLink [25536,25564]
name: BigQueryConsoleIndexableLink [25536,25564]
===
match
---
operator: , [9222,9223]
operator: , [9222,9223]
===
match
---
string: "#81A0FF" [1954,1963]
string: "#81A0FF" [1954,1963]
===
match
---
name: DATASET [1968,1975]
name: DATASET [1968,1975]
===
match
---
name: Optional [26064,26072]
name: Optional [26064,26072]
===
match
---
name: self [48654,48658]
name: self [48710,48714]
===
match
---
name: destination_project_dataset_table [47634,47667]
name: destination_project_dataset_table [47690,47723]
===
match
---
simple_stmt [10072,10103]
simple_stmt [10072,10103]
===
match
---
trailer [48469,48474]
trailer [48525,48530]
===
match
---
name: Optional [55868,55876]
name: Optional [55924,55932]
===
match
---
funcdef [25664,28444]
funcdef [25664,28500]
===
match
---
atom_expr [39399,39415]
atom_expr [39455,39471]
===
match
---
trailer [38878,38883]
trailer [38934,38939]
===
match
---
operator: = [28766,28767]
operator: = [28822,28823]
===
match
---
operator: , [48297,48298]
operator: , [48353,48354]
===
match
---
operator: , [7035,7036]
operator: , [7035,7036]
===
match
---
name: BigQueryHook [74712,74724]
name: BigQueryHook [74768,74780]
===
match
---
operator: , [38891,38892]
operator: , [38947,38948]
===
match
---
trailer [97690,97695]
trailer [97746,97751]
===
match
---
name: self [50962,50966]
name: self [51018,51022]
===
match
---
atom_expr [94788,94816]
atom_expr [94844,94872]
===
match
---
name: dataset_resource [78754,78770]
name: dataset_resource [78810,78826]
===
match
---
name: kwargs [17714,17720]
name: kwargs [17714,17720]
===
match
---
classdef [52974,57105]
classdef [53030,57161]
===
match
---
atom_expr [60915,60930]
atom_expr [60971,60986]
===
match
---
comparison [2899,2924]
comparison [2899,2924]
===
match
---
simple_stmt [41542,41619]
simple_stmt [41598,41675]
===
match
---
operator: , [25736,25737]
operator: , [25736,25737]
===
match
---
tfpdef [9447,9461]
tfpdef [9447,9461]
===
match
---
name: location [28758,28766]
name: location [28814,28822]
===
match
---
string: 'labels' [37850,37858]
string: 'labels' [37906,37914]
===
match
---
trailer [51629,51639]
trailer [51685,51695]
===
match
---
operator: , [17498,17499]
operator: , [17498,17499]
===
match
---
name: table_resource [41269,41283]
name: table_resource [41325,41339]
===
match
---
atom_expr [98207,98527]
atom_expr [98263,98583]
===
match
---
simple_stmt [73636,73757]
simple_stmt [73692,73813]
===
match
---
operator: = [74515,74516]
operator: = [74571,74572]
===
match
---
tfpdef [60193,60226]
tfpdef [60249,60282]
===
match
---
trailer [78026,78053]
trailer [78082,78109]
===
match
---
argument [61682,61722]
argument [61738,61778]
===
match
---
name: self [82365,82369]
name: self [82421,82425]
===
match
---
name: dataset_id [70616,70626]
name: dataset_id [70672,70682]
===
match
---
atom_expr [61198,61212]
atom_expr [61254,61268]
===
match
---
arglist [6945,6962]
arglist [6945,6962]
===
match
---
simple_stmt [9144,9279]
simple_stmt [9144,9279]
===
match
---
operator: = [2761,2762]
operator: = [2761,2762]
===
match
---
name: selected_fields [18962,18977]
name: selected_fields [18962,18977]
===
match
---
name: str [17675,17678]
name: str [17675,17678]
===
match
---
string: """     Update BigQuery Table Schema     Updates fields on a table schema based on contents of the supplied schema_fields_updates     parameter. The supplied schema does not need to be complete, if the field     already exists in the schema you only need to supply keys & values for the     items you want to patch, just ensure the "name" key is set.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryUpdateTableSchemaOperator`      :param schema_fields_updates: a partial schema resource. see         https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#TableSchema      **Example**: ::          schema_fields_updates=[             {"name": "emp_name", "description": "Some New Description"},             {"name": "salary", "policyTags": {'names': ['some_new_policy_tag']},},             {"name": "departments", "fields": [                 {"name": "name", "description": "Some New Description"},                 {"name": "type", "description": "Some New Description"}             ]},         ]      :type schema_fields_updates: List[dict]     :param include_policy_tags: (Optional) If set to True policy tags will be included in         the update request which requires special permissions even if unchanged (default False)         see https://cloud.google.com/bigquery/docs/column-level-security#roles     :type include_policy_tags: bool     :param dataset_id: A dotted         ``(<project>.|<project>:)<dataset>`` that indicates which dataset         will be updated. (templated)     :type dataset_id: str     :param table_id: The table ID of the requested table. (templated)     :type table_id: str     :param project_id: The name of the project where we want to update the dataset.         Don't need to provide, if projectId in dataset_reference.     :type project_id: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param delegate_to: The account to impersonate, if any.         For this to work, the service account making the request must have domain-wide         delegation enabled.     :type delegate_to: str     :param location: The location used for the operation.     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [86444,89641]
string: """     Update BigQuery Table Schema     Updates fields on a table schema based on contents of the supplied schema_fields_updates     parameter. The supplied schema does not need to be complete, if the field     already exists in the schema you only need to supply keys & values for the     items you want to patch, just ensure the "name" key is set.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryUpdateTableSchemaOperator`      :param schema_fields_updates: a partial schema resource. see         https://cloud.google.com/bigquery/docs/reference/rest/v2/tables#TableSchema      **Example**: ::          schema_fields_updates=[             {"name": "emp_name", "description": "Some New Description"},             {"name": "salary", "policyTags": {'names': ['some_new_policy_tag']},},             {"name": "departments", "fields": [                 {"name": "name", "description": "Some New Description"},                 {"name": "type", "description": "Some New Description"}             ]},         ]      :type schema_fields_updates: List[dict]     :param include_policy_tags: (Optional) If set to True policy tags will be included in         the update request which requires special permissions even if unchanged (default False)         see https://cloud.google.com/bigquery/docs/column-level-security#roles     :type include_policy_tags: bool     :param dataset_id: A dotted         ``(<project>.|<project>:)<dataset>`` that indicates which dataset         will be updated. (templated)     :type dataset_id: str     :param table_id: The table ID of the requested table. (templated)     :type table_id: str     :param project_id: The name of the project where we want to update the dataset.         Don't need to provide, if projectId in dataset_reference.     :type project_id: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param delegate_to: The account to impersonate, if any.         For this to work, the service account making the request must have domain-wide         delegation enabled.     :type delegate_to: str     :param location: The location used for the operation.     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [86500,89697]
===
match
---
name: udf_config [30314,30324]
name: udf_config [30370,30380]
===
match
---
argument [57058,57094]
argument [57114,57150]
===
match
---
simple_stmt [85891,85992]
simple_stmt [85947,86048]
===
match
---
operator: = [49854,49855]
operator: = [49910,49911]
===
match
---
name: isinstance [28869,28879]
name: isinstance [28925,28935]
===
match
---
expr_stmt [7162,7176]
expr_stmt [7162,7176]
===
match
---
name: self [2914,2918]
name: self [2914,2918]
===
match
---
name: job_id [2365,2371]
name: job_id [2365,2371]
===
match
---
tfpdef [25711,25736]
tfpdef [25711,25736]
===
match
---
name: self [74579,74583]
name: self [74635,74639]
===
match
---
atom_expr [41157,41179]
atom_expr [41213,41235]
===
match
---
operator: , [48907,48908]
operator: , [48963,48964]
===
match
---
number: 0 [47926,47927]
number: 0 [47982,47983]
===
match
---
name: Dict [38240,38244]
name: Dict [38296,38300]
===
match
---
argument [96441,96454]
argument [96497,96510]
===
match
---
parameters [2138,2160]
parameters [2138,2160]
===
match
---
operator: , [30876,30877]
operator: , [30932,30933]
===
match
---
atom_expr [25496,25517]
atom_expr [25496,25517]
===
match
---
trailer [50966,50975]
trailer [51022,51031]
===
match
---
string: "the gcp_conn_id parameter." [27075,27103]
string: "the gcp_conn_id parameter." [27075,27103]
===
match
---
name: Optional [48420,48428]
name: Optional [48476,48484]
===
match
---
trailer [56620,56622]
trailer [56676,56678]
===
match
---
operator: = [30209,30210]
operator: = [30265,30266]
===
match
---
name: enum [1841,1845]
name: enum [1841,1845]
===
match
---
name: schema_fields [49983,49996]
name: schema_fields [50039,50052]
===
match
---
tfpdef [90111,90134]
tfpdef [90167,90190]
===
match
---
trailer [29523,29530]
trailer [29579,29586]
===
match
---
fstring_end: " [98320,98321]
fstring_end: " [98376,98377]
===
match
---
name: impersonation_chain [90719,90738]
name: impersonation_chain [90775,90794]
===
match
---
simple_stmt [79003,80899]
simple_stmt [79059,80955]
===
match
---
operator: , [40097,40098]
operator: , [40153,40154]
===
match
---
expr_stmt [78456,78631]
expr_stmt [78512,78687]
===
match
---
fstring_expr [98294,98305]
fstring_expr [98350,98361]
===
match
---
operator: , [18927,18928]
operator: , [18927,18928]
===
match
---
name: self [52873,52877]
name: self [52929,52933]
===
match
---
trailer [30276,30292]
trailer [30332,30348]
===
match
---
atom_expr [28056,28069]
atom_expr [28112,28125]
===
match
---
trailer [82241,82253]
trailer [82297,82309]
===
match
---
trailer [70062,70068]
trailer [70118,70124]
===
match
---
trailer [67402,67412]
trailer [67458,67468]
===
match
---
simple_stmt [27207,27348]
simple_stmt [27237,27404]
===
match
---
name: template_fields [47156,47171]
name: template_fields [47212,47227]
===
match
---
trailer [90045,90051]
trailer [90101,90107]
===
match
---
atom_expr [9735,9749]
atom_expr [9735,9749]
===
match
---
tfpdef [90016,90051]
tfpdef [90072,90107]
===
match
---
expr_stmt [85647,85675]
expr_stmt [85703,85731]
===
match
---
name: self [96172,96176]
name: self [96228,96232]
===
match
---
name: self [29423,29427]
name: self [29479,29483]
===
match
---
name: List [47763,47767]
name: List [47819,47823]
===
match
---
operator: * [66819,66820]
operator: * [66875,66876]
===
match
---
name: List [89986,89990]
name: List [90042,90046]
===
match
---
name: impersonation_chain [67034,67053]
name: impersonation_chain [67090,67109]
===
match
---
operator: = [78545,78546]
operator: = [78601,78602]
===
match
---
operator: , [60088,60089]
operator: , [60144,60145]
===
match
---
trailer [61892,61896]
trailer [61948,61952]
===
match
---
operator: , [60372,60373]
operator: , [60428,60429]
===
match
---
simple_stmt [18366,18413]
simple_stmt [18366,18413]
===
match
---
operator: , [49208,49209]
operator: , [49264,49265]
===
match
---
name: project_id [57018,57028]
name: project_id [57074,57084]
===
match
---
string: 'Table %s.%s.%s created successfully' [41404,41441]
string: 'Table %s.%s.%s created successfully' [41460,41497]
===
match
---
atom_expr [27927,27953]
atom_expr [27983,28009]
===
match
---
name: exceptions [1106,1116]
name: exceptions [1106,1116]
===
match
---
operator: , [75070,75071]
operator: , [75126,75127]
===
match
---
simple_stmt [37729,37942]
simple_stmt [37785,37998]
===
match
---
simple_stmt [1342,1442]
simple_stmt [1342,1442]
===
match
---
trailer [96380,96391]
trailer [96436,96447]
===
match
---
name: configuration [95968,95981]
name: configuration [96024,96037]
===
match
---
trailer [61980,62022]
trailer [62036,62078]
===
match
---
fstring [98425,98509]
fstring [98481,98565]
===
match
---
if_stmt [56047,56351]
if_stmt [56103,56407]
===
match
---
simple_stmt [71334,73631]
simple_stmt [71390,73687]
===
match
---
trailer [95996,96010]
trailer [96052,96066]
===
match
---
operator: = [27627,27628]
operator: = [27683,27684]
===
match
---
name: self [97571,97575]
name: self [97627,97631]
===
match
---
name: impersonation_chain [56564,56583]
name: impersonation_chain [56620,56639]
===
match
---
operator: , [91096,91097]
operator: , [91152,91153]
===
match
---
operator: , [26127,26128]
operator: , [26127,26128]
===
match
---
expr_stmt [39729,39765]
expr_stmt [39785,39821]
===
match
---
suite [96803,97309]
suite [96859,97365]
===
match
---
parameters [96787,96802]
parameters [96843,96858]
===
match
---
trailer [64480,64490]
trailer [64536,64546]
===
match
---
expr_stmt [18788,19024]
expr_stmt [18788,19024]
===
match
---
funcdef [77686,78415]
funcdef [77742,78471]
===
match
---
name: self [51061,51065]
name: self [51117,51121]
===
match
---
name: super [56615,56620]
name: super [56671,56676]
===
match
---
operator: = [95254,95255]
operator: = [95310,95311]
===
match
---
operator: , [70100,70101]
operator: , [70156,70157]
===
match
---
atom_expr [47800,47813]
atom_expr [47856,47869]
===
match
---
name: self [64257,64261]
name: self [64313,64317]
===
match
---
if_stmt [97946,98528]
if_stmt [98002,98584]
===
match
---
name: bucket [47583,47589]
name: bucket [47639,47645]
===
match
---
name: delete_contents [56439,56454]
name: delete_contents [56495,56510]
===
match
---
trailer [67069,67089]
trailer [67125,67145]
===
match
---
expr_stmt [39696,39720]
expr_stmt [39752,39776]
===
match
---
name: location [85778,85786]
name: location [85834,85842]
===
match
---
trailer [7127,7139]
trailer [7127,7139]
===
match
---
operator: = [90135,90136]
operator: = [90191,90192]
===
match
---
trailer [67296,67308]
trailer [67352,67364]
===
match
---
name: bool [95030,95034]
name: bool [95086,95090]
===
match
---
atom_expr [98647,98666]
atom_expr [98703,98722]
===
match
---
name: Optional [1028,1036]
name: Optional [1028,1036]
===
match
---
atom_expr [78649,78660]
atom_expr [78705,78716]
===
match
---
operator: , [85191,85192]
operator: , [85247,85248]
===
match
---
trailer [49752,49824]
trailer [49808,49880]
===
match
---
operator: = [13120,13121]
operator: = [13120,13121]
===
match
---
operator: , [78060,78061]
operator: , [78116,78117]
===
match
---
name: time_partitioning [40984,41001]
name: time_partitioning [41040,41057]
===
match
---
name: Dict [77751,77755]
name: Dict [77807,77811]
===
match
---
name: super [74634,74639]
name: super [74690,74695]
===
match
---
operator: = [40645,40646]
operator: = [40701,40702]
===
match
---
operator: , [9200,9201]
operator: , [9200,9201]
===
match
---
operator: , [66981,66982]
operator: , [67037,67038]
===
match
---
trailer [78393,78395]
trailer [78449,78451]
===
match
---
operator: = [70298,70299]
operator: = [70354,70355]
===
match
---
funcdef [2565,2641]
funcdef [2565,2641]
===
match
---
expr_stmt [67454,67629]
expr_stmt [67510,67685]
===
match
---
trailer [71256,71267]
trailer [71312,71323]
===
match
---
name: self [18294,18298]
name: self [18294,18298]
===
match
---
operator: = [29962,29963]
operator: = [30018,30019]
===
match
---
parameters [94834,95322]
parameters [94890,95378]
===
match
---
simple_stmt [85684,85715]
simple_stmt [85740,85771]
===
match
---
operator: = [77803,77804]
operator: = [77859,77860]
===
match
---
name: project_id [55718,55728]
name: project_id [55774,55784]
===
match
---
tfpdef [17378,17394]
tfpdef [17378,17394]
===
match
---
param [77775,77810]
param [77831,77866]
===
match
---
atom_expr [39729,39748]
atom_expr [39785,39804]
===
match
---
name: uuid [96861,96865]
name: uuid [96917,96921]
===
match
---
argument [3329,3373]
argument [3329,3373]
===
match
---
name: Optional [60446,60454]
name: Optional [60502,60510]
===
match
---
trailer [60882,60893]
trailer [60938,60949]
===
match
---
name: self [84806,84810]
name: self [84862,84866]
===
match
---
name: dataset [64806,64813]
name: dataset [64862,64869]
===
match
---
operator: , [29098,29099]
operator: , [29154,29155]
===
match
---
testlist_comp [80932,80988]
testlist_comp [80988,81044]
===
match
---
name: time_partitioning [39443,39460]
name: time_partitioning [39499,39516]
===
match
---
name: self [30210,30214]
name: self [30266,30270]
===
match
---
name: Union [78027,78032]
name: Union [78083,78088]
===
match
---
trailer [52071,52078]
trailer [52127,52134]
===
match
---
name: BaseOperator [2675,2687]
name: BaseOperator [2675,2687]
===
match
---
expr_stmt [70672,70702]
expr_stmt [70728,70758]
===
match
---
trailer [25332,25338]
trailer [25332,25338]
===
match
---
trailer [97836,97847]
trailer [97892,97903]
===
match
---
name: self [27986,27990]
name: self [28042,28046]
===
match
---
atom [39463,39465]
atom [39519,39521]
===
match
---
name: max_bad_records [52580,52595]
name: max_bad_records [52636,52651]
===
match
---
argument [67532,67560]
argument [67588,67616]
===
match
---
name: impersonation_chain [61491,61510]
name: impersonation_chain [61547,61566]
===
match
---
name: dataset_id [85583,85593]
name: dataset_id [85639,85649]
===
match
---
param [2659,2664]
param [2659,2664]
===
match
---
simple_stmt [74702,74878]
simple_stmt [74758,74934]
===
match
---
name: fields [78893,78899]
name: fields [78949,78955]
===
match
---
operator: = [31262,31263]
operator: = [31318,31319]
===
match
---
simple_stmt [78919,78948]
simple_stmt [78975,79004]
===
match
---
simple_stmt [61548,61820]
simple_stmt [61604,61876]
===
match
---
expr_stmt [77639,77680]
expr_stmt [77695,77736]
===
match
---
name: kwargs [95309,95315]
name: kwargs [95365,95371]
===
match
---
operator: * [73901,73902]
operator: * [73957,73958]
===
match
---
name: compression [50067,50078]
name: compression [50123,50134]
===
match
---
name: bq_hook [56966,56973]
name: bq_hook [57022,57029]
===
match
---
name: location [61444,61452]
name: location [61500,61508]
===
match
---
name: self [18834,18838]
name: self [18834,18838]
===
match
---
operator: = [7067,7068]
operator: = [7067,7068]
===
match
---
operator: , [77809,77810]
operator: , [77865,77866]
===
match
---
argument [18681,18709]
argument [18681,18709]
===
match
---
expr_stmt [74427,74447]
expr_stmt [74483,74503]
===
match
---
trailer [85293,85298]
trailer [85349,85354]
===
match
---
trailer [29014,29040]
trailer [29070,29096]
===
match
---
argument [75048,75070]
argument [75104,75126]
===
match
---
trailer [52122,52137]
trailer [52178,52193]
===
match
---
name: bigquery_conn_id [13580,13596]
name: bigquery_conn_id [13580,13596]
===
match
---
operator: = [52827,52828]
operator: = [52883,52884]
===
match
---
operator: } [70021,70022]
operator: } [70077,70078]
===
match
---
string: "#5F86FF" [1978,1987]
string: "#5F86FF" [1978,1987]
===
match
---
name: bigquery_conn_id [18634,18650]
name: bigquery_conn_id [18634,18650]
===
match
---
name: delegate_to [82284,82295]
name: delegate_to [82340,82351]
===
match
---
atom_expr [96697,96770]
atom_expr [96753,96826]
===
match
---
if_stmt [97042,97114]
if_stmt [97098,97170]
===
match
---
name: self [56659,56663]
name: self [56715,56719]
===
match
---
name: job [96751,96754]
name: job [96807,96810]
===
match
---
name: self [61104,61108]
name: self [61160,61164]
===
match
---
argument [7057,7069]
argument [7057,7069]
===
match
---
argument [61430,61452]
argument [61486,61508]
===
match
---
name: job [96623,96626]
name: job [96679,96682]
===
match
---
name: self [74427,74431]
name: self [74483,74487]
===
match
---
suite [98120,98528]
suite [98176,98584]
===
match
---
simple_stmt [56080,56308]
simple_stmt [56136,56364]
===
match
---
name: pass_value [9422,9432]
name: pass_value [9422,9432]
===
match
---
name: self [98680,98684]
name: self [98736,98740]
===
match
---
atom_expr [73831,73859]
atom_expr [73887,73915]
===
match
---
name: TaskInstance [1329,1341]
name: TaskInstance [1329,1341]
===
match
---
atom_expr [47707,47721]
atom_expr [47763,47777]
===
match
---
operator: = [39958,39959]
operator: = [40014,40015]
===
match
---
simple_stmt [84571,84676]
simple_stmt [84627,84732]
===
match
---
atom_expr [78388,78414]
atom_expr [78444,78470]
===
match
---
name: auto_attribs [2390,2402]
name: auto_attribs [2390,2402]
===
match
---
atom_expr [67594,67618]
atom_expr [67650,67674]
===
match
---
atom_expr [9921,9986]
atom_expr [9921,9986]
===
match
---
name: self [91070,91074]
name: self [91126,91130]
===
match
---
operator: = [18742,18743]
operator: = [18742,18743]
===
match
---
operator: , [74277,74278]
operator: , [74333,74334]
===
match
---
operator: , [26481,26482]
operator: , [26481,26482]
===
match
---
name: max_results [67766,67777]
name: max_results [67822,67833]
===
match
---
operator: ** [56014,56016]
operator: ** [56070,56072]
===
match
---
name: Optional [81240,81248]
name: Optional [81296,81304]
===
match
---
name: gcs_schema_object [39231,39248]
name: gcs_schema_object [39287,39304]
===
match
---
simple_stmt [56397,56426]
simple_stmt [56453,56482]
===
match
---
operator: = [82054,82055]
operator: = [82110,82111]
===
match
---
operator: , [38839,38840]
operator: , [38895,38896]
===
match
---
tfpdef [26051,26077]
tfpdef [26051,26077]
===
match
---
operator: , [17320,17321]
operator: , [17320,17321]
===
match
---
name: delegate_to [90672,90683]
name: delegate_to [90728,90739]
===
match
---
atom_expr [19000,19013]
atom_expr [19000,19013]
===
match
---
simple_stmt [2958,2987]
simple_stmt [2958,2987]
===
match
---
argument [30256,30292]
argument [30312,30348]
===
match
---
name: self [51668,51672]
name: self [51724,51728]
===
match
---
name: str [28890,28893]
name: str [28946,28949]
===
match
---
trailer [60261,60266]
trailer [60317,60322]
===
match
---
name: location [18991,18999]
name: location [18991,18999]
===
match
---
name: delegate_to [70779,70790]
name: delegate_to [70835,70846]
===
match
---
argument [40417,40445]
argument [40473,40501]
===
match
---
string: 'sql' [9172,9177]
string: 'sql' [9172,9177]
===
match
---
argument [2826,2838]
argument [2826,2838]
===
match
---
string: 'Table %s.%s already exists.' [41556,41585]
string: 'Table %s.%s already exists.' [41612,41641]
===
match
---
operator: , [85173,85174]
operator: , [85229,85230]
===
match
---
file_input [821,98831]
file_input [821,98887]
===
match
---
operator: = [61213,61214]
operator: = [61269,61270]
===
match
---
tfpdef [26530,26563]
tfpdef [26530,26563]
===
match
---
simple_stmt [85525,85556]
simple_stmt [85581,85612]
===
match
---
operator: = [66957,66958]
operator: = [67013,67014]
===
match
---
atom_expr [61938,61953]
atom_expr [61994,62009]
===
match
---
name: self [39631,39635]
name: self [39687,39691]
===
match
---
operator: { [50594,50595]
operator: { [50650,50651]
===
match
---
operator: = [17395,17396]
operator: = [17395,17396]
===
match
---
name: value [38068,38073]
name: value [38124,38129]
===
match
---
name: str [13050,13053]
name: str [13050,13053]
===
match
---
name: Optional [60352,60360]
name: Optional [60408,60416]
===
match
---
atom_expr [30146,30168]
atom_expr [30202,30224]
===
match
---
trailer [41226,41251]
trailer [41282,41307]
===
match
---
param [47785,47821]
param [47841,47877]
===
match
---
name: delegate_to [50928,50939]
name: delegate_to [50984,50995]
===
match
---
name: deletion_dataset_table [81811,81833]
name: deletion_dataset_table [81867,81889]
===
match
---
name: str [25470,25473]
name: str [25470,25473]
===
match
---
name: delegate_to [78551,78562]
name: delegate_to [78607,78618]
===
match
---
testlist_comp [89675,89794]
testlist_comp [89731,89850]
===
match
---
expr_stmt [78177,78197]
expr_stmt [78233,78253]
===
match
---
atom_expr [63906,63936]
atom_expr [63962,63992]
===
match
---
name: _BigQueryDbHookMixin [3447,3467]
name: _BigQueryDbHookMixin [3447,3467]
===
match
---
name: job_id [29955,29961]
name: job_id [30011,30017]
===
match
---
operator: { [98260,98261]
operator: { [98316,98317]
===
match
---
name: Enum [1846,1850]
name: Enum [1846,1850]
===
match
---
atom_expr [85151,85164]
atom_expr [85207,85220]
===
match
---
name: encryption_configuration [26725,26749]
name: encryption_configuration [26725,26749]
===
match
---
operator: = [51709,51710]
operator: = [51765,51766]
===
match
---
trailer [39584,39602]
trailer [39640,39658]
===
match
---
name: str [77882,77885]
name: str [77938,77941]
===
match
---
string: "The bigquery_conn_id parameter has been deprecated. You should pass " [81557,81627]
string: "The bigquery_conn_id parameter has been deprecated. You should pass " [81613,81683]
===
match
---
name: prepare_template [95850,95866]
name: prepare_template [95906,95922]
===
match
---
name: dataset_id [73996,74006]
name: dataset_id [74052,74062]
===
match
---
tfpdef [47634,47672]
tfpdef [47690,47728]
===
match
---
operator: , [67618,67619]
operator: , [67674,67675]
===
match
---
trailer [56875,56887]
trailer [56931,56943]
===
match
---
operator: = [73787,73788]
operator: = [73843,73844]
===
match
---
atom_expr [74983,74994]
atom_expr [75039,75050]
===
match
---
atom_expr [95167,95180]
atom_expr [95223,95236]
===
match
---
param [85865,85872]
param [85921,85928]
===
match
---
operator: = [71205,71206]
operator: = [71261,71262]
===
match
---
name: hook [18601,18605]
name: hook [18601,18605]
===
match
---
name: table_resource [39796,39810]
name: table_resource [39852,39866]
===
match
---
name: source_format [51112,51125]
name: source_format [51168,51181]
===
match
---
expr_stmt [64370,64400]
expr_stmt [64426,64456]
===
match
---
string: 'pass_value' [9210,9222]
string: 'pass_value' [9210,9222]
===
match
---
operator: = [40265,40266]
operator: = [40321,40322]
===
match
---
name: self [51009,51013]
name: self [51065,51069]
===
match
---
trailer [29247,29258]
trailer [29303,29314]
===
match
---
trailer [38729,38735]
trailer [38785,38791]
===
match
---
trailer [70363,70368]
trailer [70419,70424]
===
match
---
name: super [17745,17750]
name: super [17745,17750]
===
match
---
name: self [18164,18168]
name: self [18164,18168]
===
match
---
name: impersonation_chain [95705,95724]
name: impersonation_chain [95761,95780]
===
match
---
name: self [28461,28465]
name: self [28517,28521]
===
match
---
name: str [48033,48036]
name: str [48089,48092]
===
match
---
name: value [94811,94816]
name: value [94867,94872]
===
match
---
atom_expr [86131,86144]
atom_expr [86187,86200]
===
match
---
expr_stmt [48683,48719]
expr_stmt [48739,48775]
===
match
---
atom_expr [41112,41121]
atom_expr [41168,41177]
===
match
---
name: self [78669,78673]
name: self [78725,78729]
===
match
---
expr_stmt [2776,2839]
expr_stmt [2776,2839]
===
match
---
trailer [60129,60134]
trailer [60185,60190]
===
match
---
trailer [29080,29098]
trailer [29136,29154]
===
match
---
expr_stmt [97536,97552]
expr_stmt [97592,97608]
===
match
---
name: dataset_id [90545,90555]
name: dataset_id [90601,90611]
===
match
---
name: str [64069,64072]
name: str [64125,64128]
===
match
---
operator: = [27411,27412]
operator: = [27467,27468]
===
match
---
string: "datasetReference" [61897,61915]
string: "datasetReference" [61953,61971]
===
match
---
param [95103,95145]
param [95159,95201]
===
match
---
name: table_resource [38215,38229]
name: table_resource [38271,38285]
===
match
---
name: self [96788,96792]
name: self [96844,96848]
===
match
---
name: delegate_to [82267,82278]
name: delegate_to [82323,82334]
===
match
---
name: attr [2383,2387]
name: attr [2383,2387]
===
match
---
name: impersonation_chain [7290,7309]
name: impersonation_chain [7290,7309]
===
match
---
name: table_id [40890,40898]
name: table_id [40946,40954]
===
match
---
expr_stmt [56434,56472]
expr_stmt [56490,56528]
===
match
---
subscriptlist [89996,90004]
subscriptlist [90052,90060]
===
match
---
operator: , [70578,70579]
operator: , [70634,70635]
===
match
---
return_stmt [19148,19165]
return_stmt [19148,19165]
===
match
---
name: gcp_conn_id [18054,18065]
name: gcp_conn_id [18054,18065]
===
match
---
number: 3 [7068,7069]
number: 3 [7068,7069]
===
match
---
string: 'impersonation_chain' [69933,69954]
string: 'impersonation_chain' [69989,70010]
===
match
---
expr_stmt [10111,10147]
expr_stmt [10111,10147]
===
match
---
operator: , [73902,73903]
operator: , [73958,73959]
===
match
---
tfpdef [17355,17368]
tfpdef [17355,17368]
===
match
---
argument [82345,82389]
argument [82401,82445]
===
match
---
name: self [95963,95967]
name: self [96019,96023]
===
match
---
param [55693,55709]
param [55749,55765]
===
match
---
tfpdef [60151,60176]
tfpdef [60207,60232]
===
match
---
expr_stmt [84680,84734]
expr_stmt [84736,84790]
===
match
---
name: TABLE [47462,47467]
name: TABLE [47518,47523]
===
match
---
name: write_disposition [27452,27469]
name: write_disposition [27508,27525]
===
match
---
name: bool [6722,6726]
name: bool [6722,6726]
===
match
---
operator: = [56870,56871]
operator: = [56926,56927]
===
match
---
name: DATASET [66764,66771]
name: DATASET [66820,66827]
===
match
---
atom_expr [18366,18390]
atom_expr [18366,18390]
===
match
---
name: bigquery_conn_id [18068,18084]
name: bigquery_conn_id [18068,18084]
===
match
---
arglist [13388,13557]
arglist [13388,13557]
===
match
---
operator: ** [67107,67109]
operator: ** [67163,67165]
===
match
---
simple_stmt [74540,74571]
simple_stmt [74596,74627]
===
match
---
name: fields [78654,78660]
name: fields [78710,78716]
===
match
---
operator: = [71159,71160]
operator: = [71215,71216]
===
match
---
name: bq_hook [78718,78725]
name: bq_hook [78774,78781]
===
match
---
expr_stmt [96901,96959]
expr_stmt [96957,97015]
===
match
---
operator: = [64073,64074]
operator: = [64129,64130]
===
match
---
trailer [19113,19120]
trailer [19113,19120]
===
match
---
name: str [95081,95084]
name: str [95137,95140]
===
match
---
operator: , [2279,2280]
operator: , [2279,2280]
===
match
---
operator: = [95001,95002]
operator: = [95057,95058]
===
match
---
argument [51930,51955]
argument [51986,52011]
===
match
---
suite [64247,64491]
suite [64303,64547]
===
match
---
name: BaseOperator [13953,13965]
name: BaseOperator [13953,13965]
===
match
---
trailer [82322,82331]
trailer [82378,82387]
===
match
---
operator: = [96116,96117]
operator: = [96172,96173]
===
match
---
name: self [56520,56524]
name: self [56576,56580]
===
match
---
testlist_comp [66659,66725]
testlist_comp [66715,66781]
===
match
---
trailer [28936,29897]
trailer [28992,29953]
===
match
---
param [9654,9718]
param [9654,9718]
===
match
---
name: value [25339,25344]
name: value [25339,25344]
===
match
---
name: dataset [78708,78715]
name: dataset [78764,78771]
===
match
---
name: self [98075,98079]
name: self [98131,98135]
===
match
---
name: impersonation_chain [50989,51008]
name: impersonation_chain [51045,51064]
===
match
---
trailer [28679,28694]
trailer [28735,28750]
===
match
---
operator: , [47997,47998]
operator: , [48053,48054]
===
match
---
string: 'impersonation_chain' [37913,37934]
string: 'impersonation_chain' [37969,37990]
===
match
---
name: task [2188,2192]
name: task [2188,2192]
===
match
---
operator: , [73676,73677]
operator: , [73732,73733]
===
match
---
trailer [97160,97170]
trailer [97216,97226]
===
match
---
atom_expr [30517,30540]
atom_expr [30573,30596]
===
match
---
atom_expr [95077,95085]
atom_expr [95133,95141]
===
match
---
operator: , [64097,64098]
operator: , [64153,64154]
===
match
---
name: self [27813,27817]
name: self [27869,27873]
===
match
---
name: location [28247,28255]
name: location [28303,28311]
===
match
---
trailer [95759,95774]
trailer [95815,95830]
===
match
---
atom_expr [29672,29694]
atom_expr [29728,29750]
===
match
---
tfpdef [6658,6689]
tfpdef [6658,6689]
===
match
---
simple_stmt [90692,90739]
simple_stmt [90748,90795]
===
match
---
simple_stmt [1604,1691]
simple_stmt [1604,1691]
===
match
---
operator: = [74942,74943]
operator: = [74998,74999]
===
match
---
suite [81448,82076]
suite [81504,82132]
===
match
---
atom_expr [48363,48377]
atom_expr [48419,48433]
===
match
---
operator: = [39538,39539]
operator: = [39594,39595]
===
match
---
argument [56817,56845]
argument [56873,56901]
===
match
---
argument [30498,30540]
argument [30554,30596]
===
match
---
expr_stmt [50512,50542]
expr_stmt [50568,50598]
===
match
---
trailer [70859,70861]
trailer [70915,70917]
===
match
---
name: self [75095,75099]
name: self [75151,75155]
===
match
---
operator: , [29322,29323]
operator: , [29378,29379]
===
match
---
name: Union [48521,48526]
name: Union [48577,48582]
===
match
---
operator: = [50961,50962]
operator: = [51017,51018]
===
match
---
tfpdef [66940,66956]
tfpdef [66996,67012]
===
match
---
trailer [64823,64835]
trailer [64879,64891]
===
match
---
string: 'dataset_id' [55522,55534]
string: 'dataset_id' [55578,55590]
===
match
---
simple_stmt [67214,67245]
simple_stmt [67270,67301]
===
match
---
operator: , [6822,6823]
operator: , [6822,6823]
===
match
---
name: self [28626,28630]
name: self [28682,28686]
===
match
---
name: location [95423,95431]
name: location [95479,95487]
===
match
---
name: context [28467,28474]
name: context [28523,28530]
===
match
---
operator: , [61915,61916]
operator: , [61971,61972]
===
match
---
operator: , [78872,78873]
operator: , [78928,78929]
===
match
---
name: log [64722,64725]
name: log [64778,64781]
===
match
---
atom [17103,17233]
atom [17103,17233]
===
match
---
name: SupportsAbs [13006,13017]
name: SupportsAbs [13006,13017]
===
match
---
atom_expr [97949,97958]
atom_expr [98005,98014]
===
match
---
atom_expr [64370,64386]
atom_expr [64426,64442]
===
match
---
name: self [40692,40696]
name: self [40748,40752]
===
match
---
argument [29828,29882]
argument [29884,29938]
===
match
---
param [50802,50809]
param [50858,50865]
===
match
---
trailer [41448,41456]
trailer [41504,41512]
===
match
---
operator: = [17101,17102]
operator: = [17101,17102]
===
match
---
trailer [96664,96677]
trailer [96720,96733]
===
match
---
trailer [96305,96465]
trailer [96361,96521]
===
match
---
arglist [97284,97307]
arglist [97340,97363]
===
match
---
operator: , [47288,47289]
operator: , [47344,47345]
===
match
---
name: self [74792,74796]
name: self [74848,74852]
===
match
---
atom_expr [28626,28642]
atom_expr [28682,28698]
===
match
---
name: str [85049,85052]
name: str [85105,85108]
===
match
---
name: configuration [95396,95409]
name: configuration [95452,95465]
===
match
---
operator: = [95120,95121]
operator: = [95176,95177]
===
match
---
name: kwargs [95359,95365]
name: kwargs [95415,95421]
===
match
---
name: BaseOperator [41710,41722]
name: BaseOperator [41766,41778]
===
match
---
operator: , [2201,2202]
operator: , [2201,2202]
===
match
---
trailer [96294,96305]
trailer [96350,96361]
===
match
---
simple_stmt [39555,39572]
simple_stmt [39611,39628]
===
match
---
atom_expr [26064,26077]
atom_expr [26064,26077]
===
match
---
operator: , [1586,1587]
operator: , [1586,1587]
===
match
---
operator: = [66881,66882]
operator: = [66937,66938]
===
match
---
name: deletion_dataset_table [81836,81858]
name: deletion_dataset_table [81892,81914]
===
match
---
name: str [67013,67016]
name: str [67069,67072]
===
match
---
operator: = [25289,25290]
operator: = [25289,25290]
===
match
---
trailer [26468,26474]
trailer [26468,26474]
===
match
---
operator: = [90556,90557]
operator: = [90612,90613]
===
match
---
name: template_ext [6468,6480]
name: template_ext [6468,6480]
===
match
---
name: uniqueness_suffix [96969,96986]
name: uniqueness_suffix [97025,97042]
===
match
---
operator: , [89953,89954]
operator: , [90009,90010]
===
match
---
operator: , [70136,70137]
operator: , [70192,70193]
===
match
---
name: DATASET [55627,55634]
name: DATASET [55683,55690]
===
match
---
param [60382,60416]
param [60438,60472]
===
match
---
arglist [70958,71087]
arglist [71014,71143]
===
match
---
operator: = [55816,55817]
operator: = [55872,55873]
===
match
---
trailer [25589,25599]
trailer [25589,25599]
===
match
---
simple_stmt [90452,90499]
simple_stmt [90508,90555]
===
match
---
parameters [98604,98610]
parameters [98660,98666]
===
match
---
name: cluster_fields [28202,28216]
name: cluster_fields [28258,28272]
===
match
---
string: """     This operator retrieves the list of tables in the specified dataset.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryGetDatasetTablesOperator`      :param dataset_id: the dataset ID of the requested dataset.     :type dataset_id: str     :param project_id: (Optional) the project of the requested dataset. If None,         self.project_id will be used.     :type project_id: str     :param max_results: (Optional) the maximum number of tables to return.     :type max_results: int     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [64989,66625]
string: """     This operator retrieves the list of tables in the specified dataset.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryGetDatasetTablesOperator`      :param dataset_id: the dataset ID of the requested dataset.     :type dataset_id: str     :param project_id: (Optional) the project of the requested dataset. If None,         self.project_id will be used.     :type project_id: str     :param max_results: (Optional) the maximum number of tables to return.     :type max_results: int     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [65045,66681]
===
match
---
operator: , [41456,41457]
operator: , [41512,41513]
===
match
---
trailer [64784,64795]
trailer [64840,64851]
===
match
---
arglist [82427,82500]
arglist [82483,82556]
===
match
---
operator: = [6367,6368]
operator: = [6367,6368]
===
match
---
expr_stmt [60878,60906]
expr_stmt [60934,60962]
===
match
---
trailer [81026,81032]
trailer [81082,81088]
===
match
---
trailer [47762,47768]
trailer [47818,47824]
===
match
---
name: source_object [52101,52114]
name: source_object [52157,52170]
===
match
---
operator: , [25690,25691]
operator: , [25690,25691]
===
match
---
name: delegate_to [78313,78324]
name: delegate_to [78369,78380]
===
match
---
name: reattach_states [95667,95682]
name: reattach_states [95723,95738]
===
match
---
trailer [29737,29758]
trailer [29793,29814]
===
match
---
simple_stmt [10039,10064]
simple_stmt [10039,10064]
===
match
---
name: self [97201,97205]
name: self [97257,97261]
===
match
---
atom_expr [28818,28842]
atom_expr [28874,28898]
===
match
---
operator: , [55888,55889]
operator: , [55944,55945]
===
match
---
expr_stmt [18333,18357]
expr_stmt [18333,18357]
===
match
---
trailer [28630,28642]
trailer [28686,28698]
===
match
---
dotted_name [1090,1116]
dotted_name [1090,1116]
===
match
---
operator: , [71175,71176]
operator: , [71231,71232]
===
match
---
atom_expr [41542,41618]
atom_expr [41598,41674]
===
match
---
trailer [3353,3373]
trailer [3353,3373]
===
match
---
name: kwargs_passed [49709,49722]
name: kwargs_passed [49765,49778]
===
match
---
trailer [6944,6963]
trailer [6944,6963]
===
match
---
simple_stmt [95556,95587]
simple_stmt [95612,95643]
===
match
---
parameters [60074,60546]
parameters [60130,60602]
===
match
---
name: delegate_to [97447,97458]
name: delegate_to [97503,97514]
===
match
---
name: self [51209,51213]
name: self [51265,51269]
===
match
---
string: """Helper class for constructing BigQuery link.""" [2039,2089]
string: """Helper class for constructing BigQuery link.""" [2039,2089]
===
match
---
name: self [13767,13771]
name: self [13767,13771]
===
match
---
tfpdef [48099,48122]
tfpdef [48155,48178]
===
match
---
name: self [97215,97219]
name: self [97271,97275]
===
match
---
operator: , [28780,28781]
operator: , [28836,28837]
===
match
---
param [6658,6697]
param [6658,6697]
===
match
---
argument [90893,90921]
argument [90949,90977]
===
match
---
name: job_id [2958,2964]
name: job_id [2958,2964]
===
match
---
trailer [38061,38067]
trailer [38117,38123]
===
match
---
atom_expr [31208,31270]
atom_expr [31264,31326]
===
match
---
name: job [98295,98298]
name: job [98351,98354]
===
match
---
tfpdef [70314,70370]
tfpdef [70370,70426]
===
match
---
name: delegate_to [90658,90669]
name: delegate_to [90714,90725]
===
match
---
operator: = [67193,67194]
operator: = [67249,67250]
===
match
---
operator: , [60324,60325]
operator: , [60380,60381]
===
match
---
name: template_fields_renderers [94719,94744]
name: template_fields_renderers [94775,94800]
===
match
---
expr_stmt [39399,39429]
expr_stmt [39455,39485]
===
match
---
atom_expr [28242,28255]
atom_expr [28298,28311]
===
match
---
name: self [28242,28246]
name: self [28298,28302]
===
match
---
expr_stmt [50048,50078]
expr_stmt [50104,50134]
===
match
---
name: self [98647,98651]
name: self [98703,98707]
===
match
---
operator: = [26709,26710]
operator: = [26709,26710]
===
match
---
trailer [3264,3279]
trailer [3264,3279]
===
match
---
name: str [47669,47672]
name: str [47725,47728]
===
match
---
if_stmt [17781,18085]
if_stmt [17781,18085]
===
match
---
expr_stmt [10211,10231]
expr_stmt [10211,10231]
===
match
---
fstring_start: f" [96714,96716]
fstring_start: f" [96770,96772]
===
match
---
simple_stmt [77639,77681]
simple_stmt [77695,77737]
===
match
---
atom_expr [90905,90921]
atom_expr [90961,90977]
===
match
---
name: allow_large_results [30215,30234]
name: allow_large_results [30271,30290]
===
match
---
atom_expr [39774,39793]
atom_expr [39830,39849]
===
match
---
dotted_name [2383,2389]
dotted_name [2383,2389]
===
match
---
atom_expr [84898,84911]
atom_expr [84954,84967]
===
match
---
tfpdef [47785,47813]
tfpdef [47841,47869]
===
match
---
name: dataset_id [57030,57040]
name: dataset_id [57086,57096]
===
match
---
trailer [66763,66771]
trailer [66819,66827]
===
match
---
trailer [30214,30234]
trailer [30270,30290]
===
match
---
suite [97057,97114]
suite [97113,97170]
===
match
---
name: self [70760,70764]
name: self [70816,70820]
===
match
---
name: max_bad_records [52601,52616]
name: max_bad_records [52657,52672]
===
match
---
suite [17736,18413]
suite [17736,18413]
===
match
---
name: self [51738,51742]
name: self [51794,51798]
===
match
---
atom_expr [74634,74660]
atom_expr [74690,74716]
===
match
---
name: location [96405,96413]
name: location [96461,96469]
===
match
---
atom_expr [26366,26389]
atom_expr [26366,26389]
===
match
---
suite [85207,85842]
suite [85263,85898]
===
match
---
operator: = [78267,78268]
operator: = [78323,78324]
===
match
---
name: template_fields [9144,9159]
name: template_fields [9144,9159]
===
match
---
if_stmt [31337,31454]
if_stmt [31393,31510]
===
match
---
name: update_table [74902,74914]
name: update_table [74958,74970]
===
match
---
name: self [3260,3264]
name: self [3260,3264]
===
match
---
string: 'impersonation_chain' [25243,25264]
string: 'impersonation_chain' [25243,25264]
===
match
---
argument [52331,52354]
argument [52387,52410]
===
match
---
name: Any [1001,1004]
name: Any [1001,1004]
===
match
---
simple_stmt [85647,85676]
simple_stmt [85703,85732]
===
match
---
suite [60585,60869]
suite [60641,60925]
===
match
---
name: str [48286,48289]
name: str [48342,48345]
===
match
---
operator: , [94929,94930]
operator: , [94985,94986]
===
match
---
simple_stmt [1946,1964]
simple_stmt [1946,1964]
===
match
---
simple_stmt [61310,61522]
simple_stmt [61366,61578]
===
match
---
name: dataset_id [64836,64846]
name: dataset_id [64892,64902]
===
match
---
operator: , [26164,26165]
operator: , [26164,26165]
===
match
---
operator: , [41474,41475]
operator: , [41530,41531]
===
match
---
argument [74976,74994]
argument [75032,75050]
===
match
---
param [6564,6569]
param [6564,6569]
===
match
---
atom_expr [39631,39660]
atom_expr [39687,39716]
===
match
---
name: self [40131,40135]
name: self [40187,40191]
===
match
---
name: dataset_id [51973,51983]
name: dataset_id [52029,52039]
===
match
---
name: _parse_gcs_url [1588,1602]
name: _parse_gcs_url [1588,1602]
===
match
---
operator: , [56226,56227]
operator: , [56282,56283]
===
match
---
operator: , [27304,27305]
operator: , [27334,27335]
===
match
---
name: gcp_conn_id [70975,70986]
name: gcp_conn_id [71031,71042]
===
match
---
atom_expr [1841,1850]
atom_expr [1841,1850]
===
match
---
trailer [74249,74269]
trailer [74305,74325]
===
match
---
simple_stmt [2039,2090]
simple_stmt [2039,2090]
===
match
---
string: 'google_cloud_default' [74139,74161]
string: 'google_cloud_default' [74195,74217]
===
match
---
expr_stmt [78103,78131]
expr_stmt [78159,78187]
===
match
---
name: cancel_job [98690,98700]
name: cancel_job [98746,98756]
===
match
---
simple_stmt [19096,19140]
simple_stmt [19096,19140]
===
match
---
atom [9162,9278]
atom [9162,9278]
===
match
---
name: Optional [94949,94957]
name: Optional [95005,95013]
===
match
---
operator: , [77893,77894]
operator: , [77949,77950]
===
match
---
testlist_comp [47184,47364]
testlist_comp [47240,47420]
===
match
---
operator: , [96391,96392]
operator: , [96447,96448]
===
match
---
atom_expr [26823,26836]
atom_expr [26823,26836]
===
match
---
name: flatten_results [30256,30271]
name: flatten_results [30312,30327]
===
match
---
classdef [57107,62023]
classdef [57163,62079]
===
match
---
name: impersonation_chain [85822,85841]
name: impersonation_chain [85878,85897]
===
match
---
name: job [96661,96664]
name: job [96717,96720]
===
match
---
param [70220,70262]
param [70276,70318]
===
match
---
trailer [60611,60825]
trailer [60667,60881]
===
match
---
atom [84589,84675]
atom [84645,84731]
===
match
---
atom_expr [75019,75034]
atom_expr [75075,75090]
===
match
---
operator: = [48038,48039]
operator: = [48094,48095]
===
match
---
name: job_id [3039,3045]
name: job_id [3039,3045]
===
match
---
atom_expr [77650,77680]
atom_expr [77706,77736]
===
match
---
suite [28895,29898]
suite [28951,29954]
===
match
---
operator: , [98792,98793]
operator: , [98848,98849]
===
match
---
operator: = [57012,57013]
operator: = [57068,57069]
===
match
---
name: log [41547,41550]
name: log [41603,41606]
===
match
---
param [94897,94930]
param [94953,94986]
===
match
---
name: schema_fields [48894,48907]
name: schema_fields [48950,48963]
===
match
---
and_test [40179,40228]
and_test [40235,40284]
===
match
---
name: __init__ [25668,25676]
name: __init__ [25668,25676]
===
match
---
suite [96248,96578]
suite [96304,96634]
===
match
---
simple_stmt [90815,90991]
simple_stmt [90871,91047]
===
match
---
simple_stmt [78245,78286]
simple_stmt [78301,78342]
===
match
---
name: self [40429,40433]
name: self [40485,40489]
===
match
---
string: "table_resource" [47404,47420]
string: "table_resource" [47460,47476]
===
match
---
name: self [95451,95455]
name: self [95507,95511]
===
match
---
parameters [39917,39932]
parameters [39973,39988]
===
match
---
trailer [91221,91230]
trailer [91277,91286]
===
match
---
trailer [51725,51737]
trailer [51781,51793]
===
match
---
argument [30954,31008]
argument [31010,31064]
===
match
---
trailer [52181,52971]
trailer [52237,53027]
===
match
---
name: kwargs [39009,39015]
name: kwargs [39065,39071]
===
match
---
name: gcp_conn_id [56817,56828]
name: gcp_conn_id [56873,56884]
===
match
---
operator: = [9321,9322]
operator: = [9321,9322]
===
match
---
string: 'table_id' [89730,89740]
string: 'table_id' [89786,89796]
===
match
---
name: bq_hook [64816,64823]
name: bq_hook [64872,64879]
===
match
---
name: AirflowException [96697,96713]
name: AirflowException [96753,96769]
===
match
---
simple_stmt [1289,1342]
simple_stmt [1289,1342]
===
match
---
name: BigQueryHook [50838,50850]
name: BigQueryHook [50894,50906]
===
match
---
name: self [39555,39559]
name: self [39611,39615]
===
match
---
atom_expr [27357,27365]
atom_expr [27413,27421]
===
match
---
atom_expr [2175,2223]
atom_expr [2175,2223]
===
match
---
atom_expr [17680,17693]
atom_expr [17680,17693]
===
match
---
name: bigquery_conn_id [56050,56066]
name: bigquery_conn_id [56106,56122]
===
match
---
simple_stmt [71107,71279]
simple_stmt [71163,71335]
===
match
---
name: bigquery_conn_id [60334,60350]
name: bigquery_conn_id [60390,60406]
===
match
---
name: hook [28922,28926]
name: hook [28978,28982]
===
match
---
subscriptlist [38245,38253]
subscriptlist [38301,38309]
===
match
---
atom_expr [28027,28038]
atom_expr [28083,28094]
===
match
---
name: location [60968,60976]
name: location [61024,61032]
===
match
---
trailer [27451,27469]
trailer [27507,27525]
===
match
---
expr_stmt [85762,85786]
expr_stmt [85818,85842]
===
match
---
operator: , [84876,84877]
operator: , [84932,84933]
===
match
---
operator: = [97491,97492]
operator: = [97547,97548]
===
match
---
name: dataset_resource [71211,71227]
name: dataset_resource [71267,71283]
===
match
---
trailer [48428,48434]
trailer [48484,48490]
===
match
---
operator: = [56498,56499]
operator: = [56554,56555]
===
match
---
funcdef [70886,71279]
funcdef [70942,71335]
===
match
---
atom_expr [85795,85819]
atom_expr [85851,85875]
===
match
---
trailer [89990,90006]
trailer [90046,90062]
===
match
---
trailer [51422,51455]
trailer [51478,51511]
===
match
---
trailer [96733,96740]
trailer [96789,96796]
===
match
---
operator: , [1046,1047]
operator: , [1046,1047]
===
match
---
name: value [77675,77680]
name: value [77731,77736]
===
match
---
operator: , [26442,26443]
operator: , [26442,26443]
===
match
---
operator: = [86177,86178]
operator: = [86233,86234]
===
match
---
param [48564,48573]
param [48620,48629]
===
match
---
atom_expr [97536,97545]
atom_expr [97592,97601]
===
match
---
atom_expr [64622,64638]
atom_expr [64678,64694]
===
match
---
operator: , [66845,66846]
operator: , [66901,66902]
===
match
---
operator: , [40399,40400]
operator: , [40455,40456]
===
match
---
tfpdef [81128,81144]
tfpdef [81184,81200]
===
match
---
string: 'dataset_id' [37757,37769]
string: 'dataset_id' [37813,37825]
===
match
---
atom_expr [94949,94962]
atom_expr [95005,95018]
===
match
---
operator: , [90795,90796]
operator: , [90851,90852]
===
match
---
operator: -> [61293,61295]
operator: -> [61349,61351]
===
match
---
name: BigQueryCreateEmptyTableOperator [31462,31494]
name: BigQueryCreateEmptyTableOperator [31518,31550]
===
match
---
name: exists_ok [41321,41330]
name: exists_ok [41377,41386]
===
match
---
parameters [50795,50810]
parameters [50851,50866]
===
match
---
name: self [19034,19038]
name: self [19034,19038]
===
match
---
parameters [84796,85198]
parameters [84852,85254]
===
match
---
name: BigQueryConsoleLink [25496,25515]
name: BigQueryConsoleLink [25496,25515]
===
match
---
argument [29654,29694]
argument [29710,29750]
===
match
---
param [2145,2154]
param [2145,2154]
===
match
---
name: gcp_conn_id [67490,67501]
name: gcp_conn_id [67546,67557]
===
match
---
trailer [97142,97160]
trailer [97198,97216]
===
match
---
trailer [67218,67230]
trailer [67274,67286]
===
match
---
atom_expr [56738,56753]
atom_expr [56794,56809]
===
match
---
name: gcp_conn_id [74738,74749]
name: gcp_conn_id [74794,74805]
===
match
---
suite [96080,96142]
suite [96136,96198]
===
match
---
name: location [60957,60965]
name: location [61013,61021]
===
match
---
string: "impersonation_chain" [94656,94677]
string: "impersonation_chain" [94712,94733]
===
match
---
operator: = [60514,60515]
operator: = [60570,60571]
===
match
---
tfpdef [38901,38957]
tfpdef [38957,39013]
===
match
---
testlist_comp [52059,52137]
testlist_comp [52115,52193]
===
match
---
name: api_resource_configs [28145,28165]
name: api_resource_configs [28201,28221]
===
match
---
name: labels [13905,13911]
name: labels [13905,13911]
===
match
---
name: destination_dataset_table [29015,29040]
name: destination_dataset_table [29071,29096]
===
match
---
atom_expr [17427,17440]
atom_expr [17427,17440]
===
match
---
name: SupportsAbs [1053,1064]
name: SupportsAbs [1053,1064]
===
match
---
operator: , [26715,26716]
operator: , [26715,26716]
===
match
---
argument [97430,97458]
argument [97486,97514]
===
match
---
trailer [26371,26389]
trailer [26371,26389]
===
match
---
operator: = [48806,48807]
operator: = [48862,48863]
===
match
---
funcdef [12854,13921]
funcdef [12854,13921]
===
match
---
expr_stmt [56781,56956]
expr_stmt [56837,57012]
===
match
---
operator: = [60894,60895]
operator: = [60950,60951]
===
match
---
argument [31257,31269]
argument [31313,31325]
===
match
---
name: delegate_to [40417,40428]
name: delegate_to [40473,40484]
===
match
---
operator: , [49596,49597]
operator: , [49652,49653]
===
match
---
param [61284,61291]
param [61340,61347]
===
match
---
name: Optional [38819,38827]
name: Optional [38875,38883]
===
match
---
argument [61251,61259]
argument [61307,61315]
===
match
---
name: str [17342,17345]
name: str [17342,17345]
===
match
---
operator: = [60024,60025]
operator: = [60080,60081]
===
match
---
trailer [9555,9560]
trailer [9555,9560]
===
match
---
simple_stmt [74887,75122]
simple_stmt [74943,75178]
===
match
---
param [6706,6734]
param [6706,6734]
===
match
---
atom_expr [56921,56945]
atom_expr [56977,57001]
===
match
---
param [64150,64214]
param [64206,64270]
===
match
---
name: self [18743,18747]
name: self [18743,18747]
===
match
---
atom_expr [38931,38956]
atom_expr [38987,39012]
===
match
---
name: use_legacy_sql [26137,26151]
name: use_legacy_sql [26137,26151]
===
match
---
testlist_comp [48843,49275]
testlist_comp [48899,49331]
===
match
---
atom_expr [40483,40507]
atom_expr [40539,40563]
===
match
---
operator: , [63968,63969]
operator: , [64024,64025]
===
match
---
operator: = [52541,52542]
operator: = [52597,52598]
===
match
---
atom_expr [13006,13022]
atom_expr [13006,13022]
===
match
---
expr_stmt [80904,80994]
expr_stmt [80960,81050]
===
match
---
funcdef [96776,97309]
funcdef [96832,97365]
===
match
---
name: dataset_id [86273,86283]
name: dataset_id [86329,86339]
===
match
---
atom_expr [98803,98816]
atom_expr [98859,98872]
===
match
---
name: self [39399,39403]
name: self [39455,39459]
===
match
---
name: delegate_to [39404,39415]
name: delegate_to [39460,39471]
===
match
---
atom_expr [64120,64133]
atom_expr [64176,64189]
===
match
---
atom_expr [28917,29897]
atom_expr [28973,29953]
===
match
---
atom_expr [67737,67752]
atom_expr [67793,67808]
===
match
---
argument [78534,78562]
argument [78590,78618]
===
match
---
name: exists_ok [61203,61212]
name: exists_ok [61259,61268]
===
match
---
name: project_id [95485,95495]
name: project_id [95541,95551]
===
match
---
operator: { [98476,98477]
operator: { [98532,98533]
===
match
---
name: BaseOperator [71315,71327]
name: BaseOperator [71371,71383]
===
match
---
operator: = [67309,67310]
operator: = [67365,67366]
===
match
---
param [38583,38617]
param [38639,38673]
===
match
---
trailer [19004,19013]
trailer [19004,19013]
===
match
---
atom_expr [70421,70589]
atom_expr [70477,70645]
===
match
---
name: self [85762,85766]
name: self [85818,85822]
===
match
---
name: delegate_to [86080,86091]
name: delegate_to [86136,86147]
===
match
---
tfpdef [6607,6623]
tfpdef [6607,6623]
===
match
---
simple_stmt [90614,90645]
simple_stmt [90670,90701]
===
match
---
string: 'google_cloud_default' [9497,9519]
string: 'google_cloud_default' [9497,9519]
===
match
---
atom_expr [52873,52884]
atom_expr [52929,52940]
===
match
---
name: dataset_id [60896,60906]
name: dataset_id [60952,60962]
===
match
---
name: dataset_id [70603,70613]
name: dataset_id [70659,70669]
===
match
---
expr_stmt [27927,27977]
expr_stmt [27983,28033]
===
match
---
trailer [2918,2924]
trailer [2918,2924]
===
match
---
operator: , [64761,64762]
operator: , [64817,64818]
===
match
---
name: int [47920,47923]
name: int [47976,47979]
===
match
---
name: hook [97642,97646]
name: hook [97698,97702]
===
match
---
atom_expr [51939,51955]
atom_expr [51995,52011]
===
match
---
simple_stmt [28140,28189]
simple_stmt [28196,28245]
===
match
---
simple_stmt [89647,89801]
simple_stmt [89703,89857]
===
match
---
argument [29776,29810]
argument [29832,29866]
===
match
---
name: self [27498,27502]
name: self [27554,27558]
===
match
---
name: gcp_conn_id [74755,74766]
name: gcp_conn_id [74811,74822]
===
match
---
simple_stmt [97181,97262]
simple_stmt [97237,97318]
===
match
---
atom_expr [56871,56887]
atom_expr [56927,56943]
===
match
---
param [98605,98609]
param [98661,98665]
===
match
---
expr_stmt [40736,41360]
expr_stmt [40792,41416]
===
match
---
name: job_id [98555,98561]
name: job_id [98611,98617]
===
match
---
name: job [97619,97622]
name: job [97675,97678]
===
match
---
tfpdef [81227,81253]
tfpdef [81283,81309]
===
match
---
suite [39031,39901]
suite [39087,39957]
===
match
---
name: max_bad_records [49053,49068]
name: max_bad_records [49109,49124]
===
match
---
simple_stmt [1692,1816]
simple_stmt [1692,1816]
===
match
---
operator: -> [18445,18447]
operator: -> [18445,18447]
===
match
---
operator: = [69992,69993]
operator: = [70048,70049]
===
match
---
fstring_string:  to `reattach_states` [98487,98508]
fstring_string:  to `reattach_states` [98543,98564]
===
match
---
expr_stmt [27380,27438]
expr_stmt [27436,27494]
===
match
---
operator: = [41156,41157]
operator: = [41212,41213]
===
match
---
funcdef [6542,7339]
funcdef [6542,7339]
===
match
---
dictorsetmaker [59982,60009]
dictorsetmaker [60038,60065]
===
match
---
parameters [18429,18444]
parameters [18429,18444]
===
match
---
name: self [28340,28344]
name: self [28396,28400]
===
match
---
name: self [90653,90657]
name: self [90709,90713]
===
match
---
atom_expr [31108,31199]
atom_expr [31164,31255]
===
match
---
number: 7 [13026,13027]
number: 7 [13026,13027]
===
match
---
name: self [90540,90544]
name: self [90596,90600]
===
match
---
simple_stmt [875,887]
simple_stmt [875,887]
===
match
---
param [66855,66888]
param [66911,66944]
===
match
---
trailer [19047,19086]
trailer [19047,19086]
===
match
---
atom_expr [67502,67518]
atom_expr [67558,67574]
===
match
---
atom_expr [82029,82053]
atom_expr [82085,82109]
===
match
---
arglist [40788,41346]
arglist [40844,41402]
===
match
---
operator: = [90052,90053]
operator: = [90108,90109]
===
match
---
name: self [90955,90959]
name: self [91011,91015]
===
match
---
operator: = [66647,66648]
operator: = [66703,66704]
===
match
---
trailer [41288,41303]
trailer [41344,41359]
===
match
---
operator: = [10131,10132]
operator: = [10131,10132]
===
match
---
name: allow_quoted_newlines [50284,50305]
name: allow_quoted_newlines [50340,50361]
===
match
---
name: project_id [71241,71251]
name: project_id [71297,71307]
===
match
---
name: self [74390,74394]
name: self [74446,74450]
===
match
---
atom_expr [9695,9708]
atom_expr [9695,9708]
===
match
---
arglist [3447,3485]
arglist [3447,3485]
===
match
---
argument [29404,29446]
argument [29460,29502]
===
match
---
trailer [56438,56454]
trailer [56494,56510]
===
match
---
trailer [27772,27787]
trailer [27828,27843]
===
match
---
suite [97983,98103]
suite [98039,98159]
===
match
---
name: Sequence [74255,74263]
name: Sequence [74311,74319]
===
match
---
name: file [96075,96079]
name: file [96131,96135]
===
match
---
subscriptlist [26372,26388]
subscriptlist [26372,26388]
===
match
---
name: project_id [85652,85662]
name: project_id [85708,85718]
===
match
---
name: Optional [60163,60171]
name: Optional [60219,60227]
===
match
---
name: property [25351,25359]
name: property [25351,25359]
===
match
---
trailer [97017,97019]
trailer [97073,97075]
===
match
---
name: schema_update_options [27956,27977]
name: schema_update_options [28012,28033]
===
match
---
name: uuid [931,935]
name: uuid [931,935]
===
match
---
name: self [78596,78600]
name: self [78652,78656]
===
match
---
operator: = [52595,52596]
operator: = [52651,52652]
===
match
---
expr_stmt [74495,74531]
expr_stmt [74551,74587]
===
match
---
atom_expr [81321,81334]
atom_expr [81377,81390]
===
match
---
simple_stmt [97070,97114]
simple_stmt [97126,97170]
===
match
---
operator: * [63978,63979]
operator: * [64034,64035]
===
match
---
tfpdef [47682,47722]
tfpdef [47738,47778]
===
match
---
name: impersonation_chain [85800,85819]
name: impersonation_chain [85856,85875]
===
match
---
atom [55512,55594]
atom [55568,55650]
===
match
---
trailer [48658,48665]
trailer [48714,48721]
===
match
---
name: str [47845,47848]
name: str [47901,47904]
===
match
---
expr_stmt [59819,59948]
expr_stmt [59875,60004]
===
match
---
name: bq_hook [39950,39957]
name: bq_hook [40006,40013]
===
match
---
operator: , [51912,51913]
operator: , [51968,51969]
===
match
---
atom_expr [90317,90342]
atom_expr [90373,90398]
===
match
---
param [90360,90369]
param [90416,90425]
===
match
---
trailer [51013,51033]
trailer [51069,51089]
===
match
---
name: get_link [2650,2658]
name: get_link [2650,2658]
===
match
---
name: BigQueryUIColors [55610,55626]
name: BigQueryUIColors [55666,55682]
===
match
---
suite [31089,31200]
suite [31145,31256]
===
match
---
string: "json" [73808,73814]
string: "json" [73864,73870]
===
match
---
name: self [56559,56563]
name: self [56615,56619]
===
match
---
trailer [9743,9749]
trailer [9743,9749]
===
match
---
param [97332,97344]
param [97388,97400]
===
match
---
name: job [97785,97788]
name: job [97841,97844]
===
match
---
atom_expr [26460,26474]
atom_expr [26460,26474]
===
match
---
name: job_id [98746,98752]
name: job_id [98802,98808]
===
match
---
name: schema_fields [47739,47752]
name: schema_fields [47795,47808]
===
match
---
name: loads [96123,96128]
name: loads [96179,96184]
===
match
---
name: dumps [96918,96923]
name: dumps [96974,96979]
===
match
---
name: values [19114,19120]
name: values [19114,19120]
===
match
---
operator: , [82253,82254]
operator: , [82309,82310]
===
match
---
trailer [52546,52562]
trailer [52602,52618]
===
match
---
expr_stmt [84739,84778]
expr_stmt [84795,84834]
===
match
---
suite [61535,61820]
suite [61591,61876]
===
match
---
name: priority [29628,29636]
name: priority [29684,29692]
===
match
---
operator: , [49274,49275]
operator: , [49330,49331]
===
match
---
operator: , [9305,9306]
operator: , [9305,9306]
===
match
---
name: location [18349,18357]
name: location [18349,18357]
===
match
---
name: json [96118,96122]
name: json [96174,96178]
===
match
---
name: dataset_id [90558,90568]
name: dataset_id [90614,90624]
===
match
---
operator: , [48530,48531]
operator: , [48586,48587]
===
match
---
subscriptlist [60461,60479]
subscriptlist [60517,60535]
===
match
---
name: schema_update_options [26334,26355]
name: schema_update_options [26334,26355]
===
match
---
string: 'impersonation_chain' [63862,63883]
string: 'impersonation_chain' [63918,63939]
===
match
---
simple_stmt [98201,98528]
simple_stmt [98257,98584]
===
match
---
operator: , [9383,9384]
operator: , [9383,9384]
===
match
---
operator: , [12880,12881]
operator: , [12880,12881]
===
match
---
name: Dict [38643,38647]
name: Dict [38699,38703]
===
match
---
trailer [29301,29322]
trailer [29357,29378]
===
match
---
argument [74738,74766]
argument [74794,74822]
===
match
---
trailer [48613,48623]
trailer [48669,48679]
===
match
---
operator: = [56455,56456]
operator: = [56511,56512]
===
match
---
name: json [40551,40555]
name: json [40607,40611]
===
match
---
trailer [18655,18667]
trailer [18655,18667]
===
match
---
operator: , [37811,37812]
operator: , [37867,37868]
===
match
---
operator: , [30746,30747]
operator: , [30802,30803]
===
match
---
operator: , [90326,90327]
operator: , [90382,90383]
===
match
---
suite [60555,61261]
suite [60611,61317]
===
match
---
name: gcp_conn_id [64568,64579]
name: gcp_conn_id [64624,64635]
===
match
---
name: self [63964,63968]
name: self [64020,64024]
===
match
---
expr_stmt [28056,28080]
expr_stmt [28112,28136]
===
match
---
param [70121,70137]
param [70177,70193]
===
match
---
simple_stmt [18294,18325]
simple_stmt [18294,18325]
===
match
---
operator: = [60267,60268]
operator: = [60323,60324]
===
match
---
atom_expr [74456,74472]
atom_expr [74512,74528]
===
match
---
name: time_partitioning [28094,28111]
name: time_partitioning [28150,28167]
===
match
---
trailer [2346,2361]
trailer [2346,2361]
===
match
---
testlist_comp [25536,25599]
testlist_comp [25536,25599]
===
match
---
tfpdef [90287,90343]
tfpdef [90343,90399]
===
match
---
trailer [97795,97803]
trailer [97851,97859]
===
match
---
name: str [25782,25785]
name: str [25782,25785]
===
match
---
name: self [74456,74460]
name: self [74512,74516]
===
match
---
operator: = [13309,13310]
operator: = [13309,13310]
===
match
---
name: warnings [27207,27215]
name: warnings [27237,27245]
===
match
---
suite [64984,67806]
suite [65040,67862]
===
match
---
operator: = [49918,49919]
operator: = [49974,49975]
===
match
---
param [96214,96226]
param [96270,96282]
===
match
---
name: date_filter_column [12955,12973]
name: date_filter_column [12955,12973]
===
match
---
name: BigQueryHook [82199,82211]
name: BigQueryHook [82255,82267]
===
match
---
name: self [28027,28031]
name: self [28083,28087]
===
match
---
operator: , [37934,37935]
operator: , [37990,37991]
===
match
---
simple_stmt [56434,56473]
simple_stmt [56490,56529]
===
match
---
atom_expr [38284,38297]
atom_expr [38340,38353]
===
match
---
subscriptlist [17675,17693]
subscriptlist [17675,17693]
===
match
---
expr_stmt [10039,10063]
expr_stmt [10039,10063]
===
match
---
operator: = [67501,67502]
operator: = [67557,67558]
===
match
---
name: delegate_to [60382,60393]
name: delegate_to [60438,60449]
===
match
---
operator: { [69994,69995]
operator: { [70050,70051]
===
match
---
simple_stmt [7005,7071]
simple_stmt [7005,7071]
===
match
---
simple_stmt [95517,95548]
simple_stmt [95573,95604]
===
match
---
operator: , [71227,71228]
operator: , [71283,71284]
===
match
---
operator: , [59881,59882]
operator: , [59937,59938]
===
match
---
arglist [50864,51034]
arglist [50920,51090]
===
match
---
simple_stmt [70922,71098]
simple_stmt [70978,71154]
===
match
---
name: str [85089,85092]
name: str [85145,85148]
===
match
---
operator: = [13157,13158]
operator: = [13157,13158]
===
match
---
atom_expr [51326,51350]
atom_expr [51382,51406]
===
match
---
operator: = [97789,97790]
operator: = [97845,97846]
===
match
---
operator: , [17309,17310]
operator: , [17309,17310]
===
match
---
expr_stmt [81867,81897]
expr_stmt [81923,81953]
===
match
---
operator: , [18667,18668]
operator: , [18667,18668]
===
match
---
operator: , [64638,64639]
operator: , [64694,64695]
===
match
---
name: s [31048,31049]
name: s [31104,31105]
===
match
---
operator: , [38692,38693]
operator: , [38748,38749]
===
match
---
atom_expr [78018,78053]
atom_expr [78074,78109]
===
match
---
operator: = [9462,9463]
operator: = [9462,9463]
===
match
---
atom_expr [27551,27575]
atom_expr [27607,27631]
===
match
---
trailer [6872,6878]
trailer [6872,6878]
===
match
---
tfpdef [55850,55881]
tfpdef [55906,55937]
===
match
---
name: gcp_conn_id [60283,60294]
name: gcp_conn_id [60339,60350]
===
match
---
name: update_table_schema [91015,91034]
name: update_table_schema [91071,91090]
===
match
---
operator: , [64046,64047]
operator: , [64102,64103]
===
match
---
name: BigQueryConsoleLink [1996,2015]
name: BigQueryConsoleLink [1996,2015]
===
match
---
operator: , [55750,55751]
operator: , [55806,55807]
===
match
---
tfpdef [13037,13053]
tfpdef [13037,13053]
===
match
---
operator: , [81414,81415]
operator: , [81470,81471]
===
match
---
tfpdef [26685,26708]
tfpdef [26685,26708]
===
match
---
name: gcp_conn_id [28631,28642]
name: gcp_conn_id [28687,28698]
===
match
---
operator: , [97294,97295]
operator: , [97350,97351]
===
match
---
simple_stmt [97355,97528]
simple_stmt [97411,97584]
===
match
---
atom_expr [95952,95987]
atom_expr [96008,96043]
===
match
---
name: self [81996,82000]
name: self [82052,82056]
===
match
---
trailer [96056,96070]
trailer [96112,96126]
===
match
---
trailer [78337,78357]
trailer [78393,78413]
===
match
---
operator: { [39463,39464]
operator: { [39519,39520]
===
match
---
name: DeprecationWarning [81690,81708]
name: DeprecationWarning [81746,81764]
===
match
---
classdef [10234,13921]
classdef [10234,13921]
===
match
---
operator: = [95775,95776]
operator: = [95831,95832]
===
match
---
param [90111,90142]
param [90167,90198]
===
match
---
suite [74693,75122]
suite [74749,75178]
===
match
---
operator: -> [13341,13343]
operator: -> [13341,13343]
===
match
---
name: delegate_to [18698,18709]
name: delegate_to [18698,18709]
===
match
---
name: gcp_conn_id [95103,95114]
name: gcp_conn_id [95159,95170]
===
match
---
atom_expr [56360,56375]
atom_expr [56416,56431]
===
match
---
return_stmt [97070,97113]
return_stmt [97126,97169]
===
match
---
name: str [95247,95250]
name: str [95303,95306]
===
match
---
atom_expr [67214,67230]
atom_expr [67270,67286]
===
match
---
operator: = [38393,38394]
operator: = [38449,38450]
===
match
---
name: destination_project_dataset_table [48843,48876]
name: destination_project_dataset_table [48899,48932]
===
match
---
atom_expr [18462,18591]
atom_expr [18462,18591]
===
match
---
name: gcp_conn_id [13733,13744]
name: gcp_conn_id [13733,13744]
===
match
---
name: materialized_view [38702,38719]
name: materialized_view [38758,38775]
===
match
---
expr_stmt [81806,81858]
expr_stmt [81862,81914]
===
match
---
atom_expr [13812,13825]
atom_expr [13812,13825]
===
match
---
name: self [61143,61147]
name: self [61199,61203]
===
match
---
name: priority [26491,26499]
name: priority [26491,26499]
===
match
---
operator: @ [96583,96584]
operator: @ [96639,96640]
===
match
---
param [73952,73987]
param [74008,74043]
===
match
---
arglist [49375,49663]
arglist [49431,49719]
===
match
---
argument [61388,61416]
argument [61444,61472]
===
match
---
name: skip_leading_rows [47901,47918]
name: skip_leading_rows [47957,47974]
===
match
---
name: bigquery_conn_id [50414,50430]
name: bigquery_conn_id [50470,50486]
===
match
---
name: include_policy_tags [91135,91154]
name: include_policy_tags [91191,91210]
===
match
---
name: template_fields [17085,17100]
name: template_fields [17085,17100]
===
match
---
expr_stmt [64409,64455]
expr_stmt [64465,64511]
===
match
---
name: execute [39910,39917]
name: execute [39966,39973]
===
match
---
param [26580,26624]
param [26580,26624]
===
match
---
name: bq_hook [67454,67461]
name: bq_hook [67510,67517]
===
match
---
simple_stmt [94585,94685]
simple_stmt [94641,94741]
===
match
---
trailer [77755,77765]
trailer [77811,77821]
===
match
---
trailer [85221,85223]
trailer [85277,85279]
===
match
---
string: 'impersonation_chain' [73728,73749]
string: 'impersonation_chain' [73784,73805]
===
match
---
simple_stmt [7185,7222]
simple_stmt [7185,7222]
===
match
---
dictorsetmaker [73790,73814]
dictorsetmaker [73846,73870]
===
match
---
name: hexdigest [97021,97030]
name: hexdigest [97077,97086]
===
match
---
operator: , [30292,30293]
operator: , [30348,30349]
===
match
---
name: BigQueryHook [18608,18620]
name: BigQueryHook [18608,18620]
===
match
---
operator: , [29258,29259]
operator: , [29314,29315]
===
match
---
trailer [50009,50023]
trailer [50065,50079]
===
match
---
operator: , [86371,86372]
operator: , [86427,86428]
===
match
---
name: udf_config [26094,26104]
name: udf_config [26094,26104]
===
match
---
operator: } [61918,61919]
operator: } [61974,61975]
===
match
---
name: super [95340,95345]
name: super [95396,95401]
===
match
---
operator: , [29446,29447]
operator: , [29502,29503]
===
match
---
simple_stmt [95340,95367]
simple_stmt [95396,95423]
===
match
---
simple_stmt [85285,85513]
simple_stmt [85341,85569]
===
match
---
name: time_partitioning [30768,30785]
name: time_partitioning [30824,30841]
===
match
---
string: 'impersonation_chain' [6417,6438]
string: 'impersonation_chain' [6417,6438]
===
match
---
name: loads [51399,51404]
name: loads [51455,51460]
===
match
---
operator: -> [3110,3112]
operator: -> [3110,3112]
===
match
---
simple_stmt [47375,47430]
simple_stmt [47431,47486]
===
match
---
name: priority [29614,29622]
name: priority [29670,29678]
===
match
---
name: gcp_conn_id [3203,3214]
name: gcp_conn_id [3203,3214]
===
match
---
atom_expr [40366,40399]
atom_expr [40422,40455]
===
match
---
trailer [86019,86213]
trailer [86075,86269]
===
match
---
operator: , [62009,62010]
operator: , [62065,62066]
===
match
---
operator: , [71267,71268]
operator: , [71323,71324]
===
match
---
simple_stmt [98046,98059]
simple_stmt [98102,98115]
===
match
---
string: 'impersonation_chain' [84647,84668]
string: 'impersonation_chain' [84703,84724]
===
match
---
fstring_end: " [98403,98404]
fstring_end: " [98459,98460]
===
match
---
tfpdef [26174,26209]
tfpdef [26174,26209]
===
match
---
funcdef [31276,31454]
funcdef [31332,31510]
===
match
---
subscriptlist [26818,26836]
subscriptlist [26818,26836]
===
match
---
simple_stmt [62077,63785]
simple_stmt [62133,63841]
===
match
---
tfpdef [64014,64039]
tfpdef [64070,64095]
===
match
---
name: Optional [77873,77881]
name: Optional [77929,77937]
===
match
---
name: self [86178,86182]
name: self [86234,86238]
===
match
---
name: BigQueryHook [78466,78478]
name: BigQueryHook [78522,78534]
===
match
---
operator: , [96176,96177]
operator: , [96232,96233]
===
match
---
operator: , [70520,70521]
operator: , [70576,70577]
===
match
---
atom_expr [30621,30632]
atom_expr [30677,30688]
===
match
---
name: gcp_conn_id [64585,64596]
name: gcp_conn_id [64641,64652]
===
match
---
atom_expr [28584,28857]
atom_expr [28640,28913]
===
match
---
trailer [63922,63930]
trailer [63978,63986]
===
match
---
name: location [6743,6751]
name: location [6743,6751]
===
match
---
operator: -> [67123,67125]
operator: -> [67179,67181]
===
match
---
operator: , [28842,28843]
operator: , [28898,28899]
===
match
---
name: cluster_fields [38849,38863]
name: cluster_fields [38905,38919]
===
match
---
param [66830,66846]
param [66886,66902]
===
match
---
name: dataset_id [18839,18849]
name: dataset_id [18839,18849]
===
match
---
atom_expr [50439,50472]
atom_expr [50495,50528]
===
match
---
arglist [67490,67619]
arglist [67546,67675]
===
match
---
name: __init__ [89920,89928]
name: __init__ [89976,89984]
===
match
---
return_stmt [2938,2949]
return_stmt [2938,2949]
===
match
---
trailer [70198,70203]
trailer [70254,70259]
===
match
---
operator: = [78647,78648]
operator: = [78703,78704]
===
match
---
argument [98746,98764]
argument [98802,98820]
===
match
---
name: ui_color [70027,70035]
name: ui_color [70083,70091]
===
match
---
operator: ** [26905,26907]
operator: ** [26905,26907]
===
match
---
number: 1 [2637,2638]
number: 1 [2637,2638]
===
match
---
operator: , [26863,26864]
operator: , [26863,26864]
===
match
---
expr_stmt [37946,38029]
expr_stmt [38002,38085]
===
match
---
param [96788,96793]
param [96844,96849]
===
match
---
suite [13967,19166]
suite [13967,19166]
===
match
---
atom_expr [96730,96740]
atom_expr [96786,96796]
===
match
---
name: self [7123,7127]
name: self [7123,7127]
===
match
---
trailer [95080,95085]
trailer [95136,95141]
===
match
---
operator: , [84969,84970]
operator: , [85025,85026]
===
match
---
testlist_comp [25496,25518]
testlist_comp [25496,25518]
===
match
---
trailer [28926,28936]
trailer [28982,28992]
===
match
---
atom_expr [39277,39298]
atom_expr [39333,39354]
===
match
---
operator: , [18563,18564]
operator: , [18563,18564]
===
match
---
atom_expr [28767,28780]
atom_expr [28823,28836]
===
match
---
operator: = [73980,73981]
operator: = [74036,74037]
===
match
---
name: QUERY [1924,1929]
name: QUERY [1924,1929]
===
match
---
argument [41107,41121]
argument [41163,41177]
===
match
---
name: self [64622,64626]
name: self [64678,64682]
===
match
---
trailer [94995,95000]
trailer [95051,95056]
===
match
---
operator: = [29852,29853]
operator: = [29908,29909]
===
match
---
expr_stmt [67214,67244]
expr_stmt [67270,67300]
===
match
---
name: stacklevel [7057,7067]
name: stacklevel [7057,7067]
===
match
---
arglist [52199,52957]
arglist [52255,53013]
===
match
---
name: impersonation_chain [64652,64671]
name: impersonation_chain [64708,64727]
===
match
---
atom_expr [97625,97655]
atom_expr [97681,97711]
===
match
---
operator: , [13333,13334]
operator: , [13333,13334]
===
match
---
name: Union [17669,17674]
name: Union [17669,17674]
===
match
---
name: gcs_schema_object [40211,40228]
name: gcs_schema_object [40267,40284]
===
match
---
name: self [67502,67506]
name: self [67558,67562]
===
match
---
trailer [40135,40155]
trailer [40191,40211]
===
match
---
argument [56859,56887]
argument [56915,56943]
===
match
---
operator: , [17678,17679]
operator: , [17678,17679]
===
match
---
trailer [97583,97592]
trailer [97639,97648]
===
match
---
trailer [95226,95253]
trailer [95282,95309]
===
match
---
name: delete_table [82414,82426]
name: delete_table [82470,82482]
===
match
---
atom_expr [18795,19024]
atom_expr [18795,19024]
===
match
---
operator: ** [74287,74289]
operator: ** [74343,74345]
===
match
---
name: self [78333,78337]
name: self [78389,78393]
===
match
---
operator: , [2745,2746]
operator: , [2745,2746]
===
match
---
name: impersonation_chain [95197,95216]
name: impersonation_chain [95253,95272]
===
match
---
trailer [63930,63936]
trailer [63986,63992]
===
match
---
name: field_delimiter [47937,47952]
name: field_delimiter [47993,48008]
===
match
---
operator: , [90277,90278]
operator: , [90333,90334]
===
match
---
name: str [94958,94961]
name: str [95014,95017]
===
match
---
param [39007,39016]
param [39063,39072]
===
match
---
name: delegate_to [67297,67308]
name: delegate_to [67353,67364]
===
match
---
string: 'impersonation_chain' [89772,89793]
string: 'impersonation_chain' [89828,89849]
===
match
---
atom_expr [81806,81833]
atom_expr [81862,81889]
===
match
---
name: dataset_resource [78269,78285]
name: dataset_resource [78325,78341]
===
match
---
param [6856,6886]
param [6856,6886]
===
match
---
name: self [7162,7166]
name: self [7162,7166]
===
match
---
trailer [40700,40705]
trailer [40756,40761]
===
match
---
trailer [31232,31242]
trailer [31288,31298]
===
match
---
name: log [28524,28527]
name: log [28580,28583]
===
match
---
atom_expr [51172,51365]
atom_expr [51228,51421]
===
match
---
return_stmt [25488,25519]
return_stmt [25488,25519]
===
match
---
name: cluster_fields [29796,29810]
name: cluster_fields [29852,29866]
===
match
---
name: operator_extra_links [25368,25388]
name: operator_extra_links [25368,25388]
===
match
---
funcdef [84784,85842]
funcdef [84840,85898]
===
match
---
name: dataset_id [67158,67168]
name: dataset_id [67214,67224]
===
match
---
name: kwargs [67405,67411]
name: kwargs [67461,67467]
===
match
---
name: table_id [18877,18885]
name: table_id [18877,18885]
===
match
---
name: source_format [52372,52385]
name: source_format [52428,52441]
===
match
---
name: super [48597,48602]
name: super [48653,48658]
===
match
---
arglist [97821,97919]
arglist [97877,97975]
===
match
---
operator: = [60931,60932]
operator: = [60987,60988]
===
match
---
name: str [78047,78050]
name: str [78103,78106]
===
match
---
name: BigQueryUIColors [73831,73847]
name: BigQueryUIColors [73887,73903]
===
match
---
tfpdef [74214,74270]
tfpdef [74270,74326]
===
match
---
param [38215,38263]
param [38271,38319]
===
match
---
operator: = [27788,27789]
operator: = [27844,27845]
===
match
---
operator: , [47729,47730]
operator: , [47785,47786]
===
match
---
name: job_id [97905,97911]
name: job_id [97961,97967]
===
match
---
atom_expr [96333,96351]
atom_expr [96389,96407]
===
match
---
atom_expr [55982,55995]
atom_expr [56038,56051]
===
match
---
name: self [18131,18135]
name: self [18131,18135]
===
match
---
simple_stmt [50232,50271]
simple_stmt [50288,50327]
===
match
---
simple_stmt [52152,52972]
simple_stmt [52208,53028]
===
match
---
operator: = [81008,81009]
operator: = [81064,81065]
===
match
---
name: impersonation_chain [67599,67618]
name: impersonation_chain [67655,67674]
===
match
---
expr_stmt [55599,55640]
expr_stmt [55655,55696]
===
match
---
name: delegate_to [64610,64621]
name: delegate_to [64666,64677]
===
match
---
operator: = [40742,40743]
operator: = [40798,40799]
===
match
---
operator: } [98304,98305]
operator: } [98360,98361]
===
match
---
param [38901,38965]
param [38957,39021]
===
match
---
trailer [74639,74641]
trailer [74695,74697]
===
match
---
operator: = [52342,52343]
operator: = [52398,52399]
===
match
---
expr_stmt [39950,40166]
expr_stmt [40006,40222]
===
match
---
arglist [51834,52003]
arglist [51890,52059]
===
match
---
name: impersonation_chain [60425,60444]
name: impersonation_chain [60481,60500]
===
match
---
operator: , [74962,74963]
operator: , [75018,75019]
===
match
---
trailer [48540,48545]
trailer [48596,48601]
===
match
---
name: dataset_id [75008,75018]
name: dataset_id [75064,75074]
===
match
---
operator: = [2965,2966]
operator: = [2965,2966]
===
match
---
name: Dict [1006,1010]
name: Dict [1006,1010]
===
match
---
name: BigQueryHook [1500,1512]
name: BigQueryHook [1500,1512]
===
match
---
operator: , [26041,26042]
operator: , [26041,26042]
===
match
---
funcdef [82081,82502]
funcdef [82137,82558]
===
match
---
argument [52580,52616]
argument [52636,52672]
===
match
---
name: impersonation_chain [64677,64696]
name: impersonation_chain [64733,64752]
===
match
---
atom_expr [70760,70776]
atom_expr [70816,70832]
===
match
---
name: Optional [67004,67012]
name: Optional [67060,67068]
===
match
---
simple_stmt [6351,6464]
simple_stmt [6351,6464]
===
match
---
simple_stmt [96097,96142]
simple_stmt [96153,96198]
===
match
---
name: table_id [41482,41490]
name: table_id [41538,41546]
===
match
---
string: "json" [37993,37999]
string: "json" [38049,38055]
===
match
---
string: 'schema_object' [47228,47243]
string: 'schema_object' [47284,47299]
===
match
---
name: kwargs [26907,26913]
name: kwargs [26907,26913]
===
match
---
operator: = [50836,50837]
operator: = [50892,50893]
===
match
---
expr_stmt [39555,39571]
expr_stmt [39611,39627]
===
match
---
operator: = [17696,17697]
operator: = [17696,17697]
===
match
---
name: delegate_to [74797,74808]
name: delegate_to [74853,74864]
===
match
---
expr_stmt [13767,13803]
expr_stmt [13767,13803]
===
match
---
atom_expr [18550,18563]
atom_expr [18550,18563]
===
match
---
argument [67574,67618]
argument [67630,67674]
===
match
---
name: self [78857,78861]
name: self [78913,78917]
===
match
---
operator: } [50595,50596]
operator: } [50651,50652]
===
match
---
simple_stmt [40535,40605]
simple_stmt [40591,40661]
===
match
---
trailer [27502,27521]
trailer [27558,27577]
===
match
---
operator: = [30574,30575]
operator: = [30630,30631]
===
match
---
operator: = [74439,74440]
operator: = [74495,74496]
===
match
---
operator: = [60808,60809]
operator: = [60864,60865]
===
match
---
name: bigquery [1151,1159]
name: bigquery [1151,1159]
===
match
---
param [96623,96639]
param [96679,96695]
===
match
---
name: dict [70164,70168]
name: dict [70220,70224]
===
match
---
name: value [55635,55640]
name: value [55691,55696]
===
match
---
operator: , [26675,26676]
operator: , [26675,26676]
===
match
---
name: self [29361,29365]
name: self [29417,29421]
===
match
---
name: sql [6949,6952]
name: sql [6949,6952]
===
match
---
simple_stmt [936,952]
simple_stmt [936,952]
===
match
---
operator: = [39249,39250]
operator: = [39305,39306]
===
match
---
name: self [27606,27610]
name: self [27662,27666]
===
match
---
funcdef [38120,39901]
funcdef [38176,39957]
===
match
---
name: self [40483,40487]
name: self [40539,40543]
===
match
---
atom_expr [56691,56771]
atom_expr [56747,56827]
===
match
---
operator: = [26304,26305]
operator: = [26304,26305]
===
match
---
suite [97346,98588]
suite [97402,98644]
===
match
---
expr_stmt [81766,81796]
expr_stmt [81822,81852]
===
match
---
simple_stmt [10156,10203]
simple_stmt [10156,10203]
===
match
---
name: impersonation_chain [78338,78357]
name: impersonation_chain [78394,78413]
===
match
---
name: self [28958,28962]
name: self [29014,29018]
===
match
---
name: self [2975,2979]
name: self [2975,2979]
===
match
---
name: self [85684,85688]
name: self [85740,85744]
===
match
---
name: BigQueryHook [3113,3125]
name: BigQueryHook [3113,3125]
===
match
---
name: allow_quoted_newlines [48054,48075]
name: allow_quoted_newlines [48110,48131]
===
match
---
trailer [70343,70370]
trailer [70399,70426]
===
match
---
name: cluster_fields [30898,30912]
name: cluster_fields [30954,30968]
===
match
---
name: operator [2263,2271]
name: operator [2263,2271]
===
match
---
trailer [85048,85053]
trailer [85104,85109]
===
match
---
operator: = [18692,18693]
operator: = [18692,18693]
===
match
---
atom_expr [95375,95393]
atom_expr [95431,95449]
===
match
---
operator: , [85149,85150]
operator: , [85205,85206]
===
match
---
suite [71329,75122]
suite [71385,75178]
===
match
---
operator: = [1976,1977]
operator: = [1976,1977]
===
match
---
operator: , [37769,37770]
operator: , [37825,37826]
===
match
---
trailer [40286,40304]
trailer [40342,40360]
===
match
---
simple_stmt [19034,19087]
simple_stmt [19034,19087]
===
match
---
funcdef [55646,56642]
funcdef [55702,56698]
===
match
---
param [81270,81302]
param [81326,81358]
===
match
---
operator: = [25887,25888]
operator: = [25887,25888]
===
match
---
operator: , [37903,37904]
operator: , [37959,37960]
===
match
---
operator: , [56753,56754]
operator: , [56809,56810]
===
match
---
operator: , [52736,52737]
operator: , [52792,52793]
===
match
---
operator: , [66671,66672]
operator: , [66727,66728]
===
match
---
name: self [74320,74324]
name: self [74376,74380]
===
match
---
name: self [78140,78144]
name: self [78196,78200]
===
match
---
atom_expr [18208,18228]
atom_expr [18208,18228]
===
match
---
operator: , [6568,6569]
operator: , [6568,6569]
===
match
---
name: source_format [50026,50039]
name: source_format [50082,50095]
===
match
---
operator: = [27576,27577]
operator: = [27632,27633]
===
match
---
trailer [38642,38648]
trailer [38698,38704]
===
match
---
atom_expr [48683,48702]
atom_expr [48739,48758]
===
match
---
atom_expr [29853,29882]
atom_expr [29909,29938]
===
match
---
expr_stmt [50338,50380]
expr_stmt [50394,50436]
===
match
---
name: max_bad_records [50208,50223]
name: max_bad_records [50264,50279]
===
match
---
name: self [25460,25464]
name: self [25460,25464]
===
match
---
simple_stmt [94719,94773]
simple_stmt [94775,94829]
===
match
---
operator: , [6438,6439]
operator: , [6438,6439]
===
match
---
simple_stmt [56691,56772]
simple_stmt [56747,56828]
===
match
---
argument [51973,52002]
argument [52029,52058]
===
match
---
expr_stmt [61024,61095]
expr_stmt [61080,61151]
===
match
---
name: allow_jagged_rows [52777,52794]
name: allow_jagged_rows [52833,52850]
===
match
---
operator: , [41001,41002]
operator: , [41057,41058]
===
match
---
operator: = [27709,27710]
operator: = [27765,27766]
===
match
---
param [60109,60142]
param [60165,60198]
===
match
---
atom_expr [49879,49917]
atom_expr [49935,49973]
===
match
---
name: delegate_to [50531,50542]
name: delegate_to [50587,50598]
===
match
---
string: "datasetId" [61925,61936]
string: "datasetId" [61981,61992]
===
match
---
simple_stmt [27986,28019]
simple_stmt [28042,28075]
===
match
---
name: self [96815,96819]
name: self [96871,96875]
===
match
---
name: Any [73938,73941]
name: Any [73994,73997]
===
match
---
operator: = [67543,67544]
operator: = [67599,67600]
===
match
---
string: 'Executing: %s' [28533,28548]
string: 'Executing: %s' [28589,28604]
===
match
---
operator: , [17447,17448]
operator: , [17447,17448]
===
match
---
atom_expr [67004,67017]
atom_expr [67060,67073]
===
match
---
trailer [41550,41555]
trailer [41606,41611]
===
match
---
name: location [28258,28266]
name: location [28314,28322]
===
match
---
atom_expr [77967,77980]
atom_expr [78023,78036]
===
match
---
name: super [6928,6933]
name: super [6928,6933]
===
match
---
param [2139,2144]
param [2139,2144]
===
match
---
simple_stmt [13610,13676]
simple_stmt [13610,13676]
===
match
---
simple_stmt [3492,6346]
simple_stmt [3492,6346]
===
match
---
atom_expr [82318,82331]
atom_expr [82374,82387]
===
match
---
raise_stmt [96691,96770]
raise_stmt [96747,96826]
===
match
---
trailer [74263,74268]
trailer [74319,74324]
===
match
---
simple_stmt [40631,40666]
simple_stmt [40687,40722]
===
match
---
argument [52812,52848]
argument [52868,52904]
===
match
---
argument [64864,64890]
argument [64920,64946]
===
match
---
funcdef [3088,3417]
funcdef [3088,3417]
===
match
---
operator: , [12797,12798]
operator: , [12797,12798]
===
match
---
name: query_params [29464,29476]
name: query_params [29520,29532]
===
match
---
strings [26988,27103]
strings [26988,27103]
===
match
---
trailer [97672,97690]
trailer [97728,97746]
===
match
---
suite [95331,95841]
suite [95387,95897]
===
match
---
atom_expr [61024,61046]
atom_expr [61080,61102]
===
match
---
simple_stmt [7083,7114]
simple_stmt [7083,7114]
===
match
---
param [64107,64141]
param [64163,64197]
===
match
---
name: schema_fields [40930,40943]
name: schema_fields [40986,40999]
===
match
---
name: __init__ [6936,6944]
name: __init__ [6936,6944]
===
match
---
trailer [47706,47722]
trailer [47762,47778]
===
match
---
name: use_legacy_sql [10116,10130]
name: use_legacy_sql [10116,10130]
===
match
---
operator: , [38616,38617]
operator: , [38672,38673]
===
match
---
operator: = [48548,48549]
operator: = [48604,48605]
===
match
---
trailer [30080,30106]
trailer [30136,30162]
===
match
---
string: 'google_cloud_default' [48232,48254]
string: 'google_cloud_default' [48288,48310]
===
match
---
expr_stmt [95800,95840]
expr_stmt [95856,95896]
===
match
---
name: gcs_object [40254,40264]
name: gcs_object [40310,40320]
===
match
---
operator: = [81211,81212]
operator: = [81267,81268]
===
match
---
comparison [31340,31361]
comparison [31396,31417]
===
match
---
expr_stmt [47434,47473]
expr_stmt [47490,47529]
===
match
---
name: schema_fields [40916,40929]
name: schema_fields [40972,40985]
===
match
---
trailer [50638,50663]
trailer [50694,50719]
===
match
---
operator: = [17474,17475]
operator: = [17474,17475]
===
match
---
name: str [55812,55815]
name: str [55868,55871]
===
match
---
trailer [38337,38343]
trailer [38393,38399]
===
match
---
operator: , [86331,86332]
operator: , [86387,86388]
===
match
---
operator: , [27139,27140]
operator: , [27139,27140]
===
match
---
name: Sequence [95238,95246]
name: Sequence [95294,95302]
===
match
---
name: api_resource_configs [26580,26600]
name: api_resource_configs [26580,26600]
===
match
---
name: self [10111,10115]
name: self [10111,10115]
===
match
---
operator: { [97093,97094]
operator: { [97149,97150]
===
match
---
name: kwargs [81426,81432]
name: kwargs [81482,81488]
===
match
---
decorated [25350,25601]
decorated [25350,25601]
===
match
---
name: self [52486,52490]
name: self [52542,52546]
===
match
---
name: execute [82085,82092]
name: execute [82141,82148]
===
match
---
operator: = [90271,90272]
operator: = [90327,90328]
===
match
---
string: 'dataset_id' [66659,66671]
string: 'dataset_id' [66715,66727]
===
match
---
name: self [61439,61443]
name: self [61495,61499]
===
match
---
name: location [61430,61438]
name: location [61486,61494]
===
match
---
name: google [1549,1555]
name: google [1549,1555]
===
match
---
operator: = [13700,13701]
operator: = [13700,13701]
===
match
---
name: bool [25881,25885]
name: bool [25881,25885]
===
match
---
name: Sequence [6824,6832]
name: Sequence [6824,6832]
===
match
---
operator: , [47243,47244]
operator: , [47299,47300]
===
match
---
atom_expr [38379,38392]
atom_expr [38435,38448]
===
match
---
suite [85272,85556]
suite [85328,85612]
===
match
---
fstring_expr [31150,31161]
fstring_expr [31206,31217]
===
match
---
name: bigquery_conn_id [26927,26943]
name: bigquery_conn_id [26927,26943]
===
match
---
name: warnings [9921,9929]
name: warnings [9921,9929]
===
match
---
trailer [81539,81753]
trailer [81595,81809]
===
match
---
operator: , [84821,84822]
operator: , [84877,84878]
===
match
---
if_stmt [2848,2888]
if_stmt [2848,2888]
===
match
---
tfpdef [70178,70203]
tfpdef [70234,70259]
===
match
---
name: Sequence [64191,64199]
name: Sequence [64247,64255]
===
match
---
operator: = [9561,9562]
operator: = [9561,9562]
===
match
---
trailer [2902,2911]
trailer [2902,2911]
===
match
---
tfpdef [9654,9710]
tfpdef [9654,9710]
===
match
---
atom_expr [90328,90341]
atom_expr [90384,90397]
===
match
---
atom [69879,69961]
atom [69935,70017]
===
match
---
param [90151,90184]
param [90207,90240]
===
match
---
trailer [71016,71028]
trailer [71072,71084]
===
match
---
trailer [9689,9709]
trailer [9689,9709]
===
match
---
trailer [97000,97020]
trailer [97056,97076]
===
match
---
trailer [28884,28888]
trailer [28940,28944]
===
match
---
operator: , [82295,82296]
operator: , [82351,82352]
===
match
---
suite [86439,91282]
suite [86495,91338]
===
match
---
name: gcp_conn_id [70691,70702]
name: gcp_conn_id [70747,70758]
===
match
---
expr_stmt [39774,39810]
expr_stmt [39830,39866]
===
match
---
atom_expr [85971,85990]
atom_expr [86027,86046]
===
match
---
name: str [17365,17368]
name: str [17365,17368]
===
match
---
name: self [29791,29795]
name: self [29847,29851]
===
match
---
name: self [29623,29627]
name: self [29679,29683]
===
match
---
name: project_id [70178,70188]
name: project_id [70234,70244]
===
match
---
name: models [1244,1250]
name: models [1244,1250]
===
match
---
name: job_id [95465,95471]
name: job_id [95521,95527]
===
match
---
trailer [61250,61260]
trailer [61306,61316]
===
match
---
string: 'dataset_id' [59847,59859]
string: 'dataset_id' [59903,59915]
===
match
---
atom_expr [82279,82295]
atom_expr [82335,82351]
===
match
---
name: Any [90001,90004]
name: Any [90057,90060]
===
match
---
operator: -> [56030,56032]
operator: -> [56086,56088]
===
match
---
atom_expr [50876,50897]
atom_expr [50932,50953]
===
match
---
trailer [97966,97982]
trailer [98022,98038]
===
match
---
operator: -> [82108,82110]
operator: -> [82164,82166]
===
match
---
operator: , [38182,38183]
operator: , [38238,38239]
===
match
---
atom_expr [31311,31328]
atom_expr [31367,31384]
===
match
---
string: "the gcp_conn_id parameter." [60716,60744]
string: "the gcp_conn_id parameter." [60772,60800]
===
match
---
simple_stmt [97536,97553]
simple_stmt [97592,97609]
===
match
---
expr_stmt [70922,71097]
expr_stmt [70978,71153]
===
match
---
trailer [38244,38254]
trailer [38300,38310]
===
match
---
import_as_names [1579,1602]
import_as_names [1579,1602]
===
match
---
simple_stmt [95418,95443]
simple_stmt [95474,95499]
===
match
---
atom_expr [78771,78792]
atom_expr [78827,78848]
===
match
---
trailer [50342,50360]
trailer [50398,50416]
===
match
---
name: self [57041,57045]
name: self [57097,57101]
===
match
---
name: dataset_id [63989,63999]
name: dataset_id [64045,64055]
===
match
---
operator: ** [90360,90362]
operator: ** [90416,90418]
===
match
---
name: job_id [97562,97568]
name: job_id [97618,97624]
===
match
---
operator: = [91069,91070]
operator: = [91125,91126]
===
match
---
trailer [89898,89904]
trailer [89954,89960]
===
match
---
operator: , [67712,67713]
operator: , [67768,67769]
===
match
---
param [67107,67116]
param [67163,67172]
===
match
---
operator: , [61664,61665]
operator: , [61720,61721]
===
match
---
trailer [41608,41617]
trailer [41664,41673]
===
match
---
if_stmt [26924,27198]
if_stmt [26924,27228]
===
match
---
name: index [2980,2985]
name: index [2980,2985]
===
match
---
name: Optional [25773,25781]
name: Optional [25773,25781]
===
match
---
name: dataset_id [74338,74348]
name: dataset_id [74394,74404]
===
match
---
atom_expr [39183,39201]
atom_expr [39239,39257]
===
match
---
atom_expr [96989,97032]
atom_expr [97045,97088]
===
match
---
operator: = [55744,55745]
operator: = [55800,55801]
===
match
---
arglist [7374,7417]
arglist [7374,7417]
===
match
---
operator: ** [81474,81476]
operator: ** [81530,81532]
===
match
---
name: self [51084,51088]
name: self [51140,51144]
===
match
---
tfpdef [66991,67017]
tfpdef [67047,67073]
===
match
---
name: self [96333,96337]
name: self [96389,96393]
===
match
---
name: ValueError [49742,49752]
name: ValueError [49798,49808]
===
match
---
trailer [77881,77886]
trailer [77937,77942]
===
match
---
exprlist [25572,25576]
exprlist [25572,25576]
===
match
---
name: create_empty_table [51798,51816]
name: create_empty_table [51854,51872]
===
match
---
name: Optional [94987,94995]
name: Optional [95043,95051]
===
match
---
arglist [61346,61511]
arglist [61402,61567]
===
match
---
name: BigQueryUIColors [94788,94804]
name: BigQueryUIColors [94844,94860]
===
match
---
trailer [18554,18563]
trailer [18554,18563]
===
match
---
trailer [96010,96019]
trailer [96066,96075]
===
match
---
argument [50864,50897]
argument [50920,50953]
===
match
---
operator: = [50473,50474]
operator: = [50529,50530]
===
match
---
name: self [40084,40088]
name: self [40140,40144]
===
match
---
atom_expr [51548,51567]
atom_expr [51604,51623]
===
match
---
fstring_string: gs:// [52061,52066]
fstring_string: gs:// [52117,52122]
===
match
---
param [66897,66931]
param [66953,66987]
===
match
---
arglist [74928,75111]
arglist [74984,75167]
===
match
---
operator: , [6773,6774]
operator: , [6773,6774]
===
match
---
simple_stmt [82409,82502]
simple_stmt [82465,82558]
===
match
---
atom_expr [2719,2767]
atom_expr [2719,2767]
===
match
---
operator: , [29040,29041]
operator: , [29096,29097]
===
match
---
name: dataset_id [55693,55703]
name: dataset_id [55749,55759]
===
match
---
name: BigQueryCreateEmptyDatasetOperator [57113,57147]
name: BigQueryCreateEmptyDatasetOperator [57169,57203]
===
match
---
name: dataset_id [57046,57056]
name: dataset_id [57102,57112]
===
match
---
sync_comp_for [25568,25599]
sync_comp_for [25568,25599]
===
match
---
name: stacklevel [56280,56290]
name: stacklevel [56336,56346]
===
match
---
trailer [96133,96138]
trailer [96189,96194]
===
match
---
name: self [98803,98807]
name: self [98859,98863]
===
match
---
name: ui_color [55599,55607]
name: ui_color [55655,55663]
===
match
---
name: configuration [95380,95393]
name: configuration [95436,95449]
===
match
---
operator: , [17168,17169]
operator: , [17168,17169]
===
match
---
tfpdef [26137,26157]
tfpdef [26137,26157]
===
match
---
name: job_id [96734,96740]
name: job_id [96790,96796]
===
match
---
name: self [78103,78107]
name: self [78159,78163]
===
match
---
name: labels [7332,7338]
name: labels [7332,7338]
===
match
---
operator: = [2534,2535]
operator: = [2534,2535]
===
match
---
param [90244,90278]
param [90300,90334]
===
match
---
tfpdef [2689,2703]
tfpdef [2689,2703]
===
match
---
name: time_partitioning [29654,29671]
name: time_partitioning [29710,29727]
===
match
---
atom_expr [27498,27521]
atom_expr [27554,27577]
===
match
---
name: bigquery_conn_id [9891,9907]
name: bigquery_conn_id [9891,9907]
===
match
---
trailer [7267,7287]
trailer [7267,7287]
===
match
---
trailer [74987,74994]
trailer [75043,75050]
===
match
---
param [9478,9520]
param [9478,9520]
===
match
---
trailer [78600,78620]
trailer [78656,78676]
===
match
---
param [70271,70305]
param [70327,70361]
===
match
---
atom_expr [86222,86382]
atom_expr [86278,86438]
===
match
---
operator: = [9495,9496]
operator: = [9495,9496]
===
match
---
operator: , [94628,94629]
operator: , [94684,94685]
===
match
---
atom_expr [2808,2824]
atom_expr [2808,2824]
===
match
---
name: Optional [48324,48332]
name: Optional [48380,48388]
===
match
---
operator: * [55682,55683]
operator: * [55738,55739]
===
match
---
operator: , [17546,17547]
operator: , [17546,17547]
===
match
---
simple_stmt [81806,81859]
simple_stmt [81862,81915]
===
match
---
simple_stmt [39729,39766]
simple_stmt [39785,39822]
===
match
---
trailer [74431,74438]
trailer [74487,74494]
===
match
---
trailer [94957,94962]
trailer [95013,95018]
===
match
---
atom_expr [75095,75110]
atom_expr [75151,75166]
===
match
---
name: impersonation_chain [51306,51325]
name: impersonation_chain [51362,51381]
===
match
---
name: self [50923,50927]
name: self [50979,50983]
===
match
---
operator: = [91178,91179]
operator: = [91234,91235]
===
match
---
atom_expr [48654,48665]
atom_expr [48710,48721]
===
match
---
operator: , [60464,60465]
operator: , [60520,60521]
===
match
---
name: self [50552,50556]
name: self [50608,50612]
===
match
---
atom_expr [90825,90990]
atom_expr [90881,91046]
===
match
---
name: delegate_to [95561,95572]
name: delegate_to [95617,95628]
===
match
---
tfpdef [13286,13308]
tfpdef [13286,13308]
===
match
---
operator: = [38043,38044]
operator: = [38099,38100]
===
match
---
name: impersonation_chain [61466,61485]
name: impersonation_chain [61522,61541]
===
match
---
operator: = [67091,67092]
operator: = [67147,67148]
===
match
---
atom_expr [49344,49677]
atom_expr [49400,49733]
===
match
---
name: location [50953,50961]
name: location [51009,51017]
===
match
---
atom_expr [25536,25567]
atom_expr [25536,25567]
===
match
---
operator: , [96204,96205]
operator: , [96260,96261]
===
match
---
name: str [26818,26821]
name: str [26818,26821]
===
match
---
simple_stmt [97668,97696]
simple_stmt [97724,97752]
===
match
---
name: self [85859,85863]
name: self [85915,85919]
===
match
---
atom_expr [78140,78155]
atom_expr [78196,78211]
===
match
---
operator: = [48230,48231]
operator: = [48286,48287]
===
match
---
name: location [50967,50975]
name: location [51023,51031]
===
match
---
param [74678,74683]
param [74734,74739]
===
match
---
trailer [51904,51912]
trailer [51960,51968]
===
match
---
name: _submit_job [96151,96162]
name: _submit_job [96207,96218]
===
match
---
expr_stmt [74357,74381]
expr_stmt [74413,74437]
===
match
---
name: impersonation_chain [40488,40507]
name: impersonation_chain [40544,40563]
===
match
---
operator: = [64814,64815]
operator: = [64870,64871]
===
match
---
name: table_resource [51854,51868]
name: table_resource [51910,51924]
===
match
---
argument [41019,41053]
argument [41075,41109]
===
match
---
atom_expr [95700,95724]
atom_expr [95756,95780]
===
match
---
operator: ** [6895,6897]
operator: ** [6895,6897]
===
match
---
trailer [18298,18310]
trailer [18298,18310]
===
match
---
trailer [38292,38297]
trailer [38348,38353]
===
match
---
name: tab_ref [51984,51991]
name: tab_ref [52040,52047]
===
match
---
trailer [64034,64039]
trailer [64090,64095]
===
match
---
operator: , [47963,47964]
operator: , [48019,48020]
===
match
---
argument [29712,29758]
argument [29768,29814]
===
match
---
name: self [50512,50516]
name: self [50568,50572]
===
match
---
expr_stmt [51161,51365]
expr_stmt [51217,51421]
===
match
---
trailer [57045,57056]
trailer [57101,57112]
===
match
---
operator: -> [70403,70405]
operator: -> [70459,70461]
===
match
---
operator: = [10181,10182]
operator: = [10181,10182]
===
match
---
name: str [90323,90326]
name: str [90379,90382]
===
match
---
param [74078,74111]
param [74134,74167]
===
match
---
string: 'max_results' [17155,17168]
string: 'max_results' [17155,17168]
===
match
---
name: __init__ [67394,67402]
name: __init__ [67450,67458]
===
match
---
name: location [19005,19013]
name: location [19005,19013]
===
match
---
name: json [51394,51398]
name: json [51450,51454]
===
match
---
simple_stmt [18255,18286]
simple_stmt [18255,18286]
===
match
---
param [95017,95042]
param [95073,95098]
===
match
---
trailer [29857,29882]
trailer [29913,29938]
===
match
---
atom_expr [50338,50360]
atom_expr [50394,50416]
===
match
---
simple_stmt [39150,39175]
simple_stmt [39206,39231]
===
match
---
name: result [98050,98056]
name: result [98106,98112]
===
match
---
operator: , [31008,31009]
operator: , [31064,31065]
===
match
---
name: table_id [18147,18155]
name: table_id [18147,18155]
===
match
---
name: context [18436,18443]
name: context [18436,18443]
===
match
---
expr_stmt [67253,67283]
expr_stmt [67309,67339]
===
match
---
atom_expr [9323,9351]
atom_expr [9323,9351]
===
match
---
operator: = [9638,9639]
operator: = [9638,9639]
===
match
---
name: bool [55777,55781]
name: bool [55833,55837]
===
match
---
name: self [78546,78550]
name: self [78602,78606]
===
match
---
name: table_resource [74500,74514]
name: table_resource [74556,74570]
===
match
---
name: project_id [77861,77871]
name: project_id [77917,77927]
===
match
---
trailer [97952,97958]
trailer [98008,98014]
===
match
---
suite [78998,82502]
suite [79054,82558]
===
match
---
name: location [96419,96427]
name: location [96475,96483]
===
match
---
string: 'table_resource' [47316,47332]
string: 'table_resource' [47372,47388]
===
match
---
atom_expr [97791,97933]
atom_expr [97847,97989]
===
match
---
name: delegate_to [67532,67543]
name: delegate_to [67588,67599]
===
match
---
name: destination_dataset_table [25746,25771]
name: destination_dataset_table [25746,25771]
===
match
---
trailer [61896,61920]
trailer [61952,61976]
===
match
---
operator: = [50412,50413]
operator: = [50468,50469]
===
match
---
atom_expr [47754,47768]
atom_expr [47810,47824]
===
match
---
atom_expr [97277,97308]
atom_expr [97333,97364]
===
match
---
param [17410,17448]
param [17410,17448]
===
match
---
name: gcp_conn_id [39986,39997]
name: gcp_conn_id [40042,40053]
===
match
---
name: gcp_conn_id [64336,64347]
name: gcp_conn_id [64392,64403]
===
match
---
atom_expr [10039,10052]
atom_expr [10039,10052]
===
match
---
atom_expr [18255,18271]
atom_expr [18255,18271]
===
match
---
atom_expr [51107,51125]
atom_expr [51163,51181]
===
match
---
operator: , [25573,25574]
operator: , [25573,25574]
===
match
---
argument [74822,74866]
argument [74878,74922]
===
match
---
simple_stmt [7263,7310]
simple_stmt [7263,7310]
===
match
---
fstring_string: _ [97228,97229]
fstring_string: _ [97284,97285]
===
match
---
operator: , [61936,61937]
operator: , [61992,61993]
===
match
---
expr_stmt [78140,78168]
expr_stmt [78196,78224]
===
match
---
name: dataset_id [39118,39128]
name: dataset_id [39174,39184]
===
match
---
operator: = [95834,95835]
operator: = [95890,95891]
===
match
---
name: field_delimiter [50161,50176]
name: field_delimiter [50217,50232]
===
match
---
operator: = [40327,40328]
operator: = [40383,40384]
===
match
---
simple_stmt [80904,80995]
simple_stmt [80960,81051]
===
match
---
simple_stmt [31375,31417]
simple_stmt [31431,31473]
===
match
---
operator: , [9717,9718]
operator: , [9717,9718]
===
match
---
name: write_disposition [27472,27489]
name: write_disposition [27528,27545]
===
match
---
expr_stmt [27357,27371]
expr_stmt [27413,27427]
===
match
---
operator: , [95236,95237]
operator: , [95292,95293]
===
match
---
name: gcp_conn_id [97388,97399]
name: gcp_conn_id [97444,97455]
===
match
---
name: tab_ref [51897,51904]
name: tab_ref [51953,51960]
===
match
---
name: location [86122,86130]
name: location [86178,86186]
===
match
---
name: impersonation_chain [74584,74603]
name: impersonation_chain [74640,74659]
===
match
---
operator: = [25936,25937]
operator: = [25936,25937]
===
match
---
operator: { [31150,31151]
operator: { [31206,31207]
===
match
---
atom_expr [29982,31027]
atom_expr [30038,31083]
===
match
---
name: job_id [31263,31269]
name: job_id [31319,31325]
===
match
---
param [56659,56664]
param [56715,56720]
===
match
---
name: impersonation_chain [71067,71086]
name: impersonation_chain [71123,71142]
===
match
---
operator: , [12732,12733]
operator: , [12732,12733]
===
match
---
atom_expr [56434,56454]
atom_expr [56490,56510]
===
match
---
operator: = [50875,50876]
operator: = [50931,50932]
===
match
---
name: self [78771,78775]
name: self [78827,78831]
===
match
---
name: DeprecationWarning [17978,17996]
name: DeprecationWarning [17978,17996]
===
match
---
operator: = [95291,95292]
operator: = [95347,95348]
===
match
---
dictorsetmaker [84709,84733]
dictorsetmaker [84765,84789]
===
match
---
trailer [18135,18144]
trailer [18135,18144]
===
match
---
name: table [41443,41448]
name: table [41499,41504]
===
match
---
atom_expr [84750,84778]
atom_expr [84806,84834]
===
match
---
name: self [7185,7189]
name: self [7185,7189]
===
match
---
operator: , [56887,56888]
operator: , [56943,56944]
===
match
---
trailer [13623,13675]
trailer [13623,13675]
===
match
---
trailer [38936,38956]
trailer [38992,39012]
===
match
---
atom_expr [39555,39564]
atom_expr [39611,39620]
===
match
---
name: delegate_to [74545,74556]
name: delegate_to [74601,74612]
===
match
---
trailer [10043,10052]
trailer [10043,10052]
===
match
---
operator: = [38990,38991]
operator: = [39046,39047]
===
match
---
trailer [56973,56988]
trailer [57029,57044]
===
match
---
name: ui_color [60015,60023]
name: ui_color [60071,60079]
===
match
---
name: labels [28032,28038]
name: labels [28088,28094]
===
match
---
name: project_id [98782,98792]
name: project_id [98838,98848]
===
match
---
atom_expr [39040,39066]
atom_expr [39096,39122]
===
match
---
name: str [60361,60364]
name: str [60417,60420]
===
match
---
argument [97472,97516]
argument [97528,97572]
===
match
---
name: self [39113,39117]
name: self [39169,39173]
===
match
---
trailer [39700,39709]
trailer [39756,39765]
===
match
---
simple_stmt [86222,86383]
simple_stmt [86278,86439]
===
match
---
name: table_id [74362,74370]
name: table_id [74418,74426]
===
match
---
argument [31243,31255]
argument [31299,31311]
===
match
---
name: Sequence [70355,70363]
name: Sequence [70411,70419]
===
match
---
tfpdef [85110,85166]
tfpdef [85166,85222]
===
match
---
operator: = [78856,78857]
operator: = [78912,78913]
===
match
---
operator: , [61374,61375]
operator: , [61430,61431]
===
match
---
suite [53024,57105]
suite [53080,57161]
===
match
---
name: self [29076,29080]
name: self [29132,29136]
===
match
---
string: "job_id" [94638,94646]
string: "job_id" [94694,94702]
===
match
---
param [25851,25895]
param [25851,25895]
===
match
---
simple_stmt [27167,27198]
simple_stmt [27197,27228]
===
match
---
tfpdef [60498,60513]
tfpdef [60554,60569]
===
match
---
simple_stmt [1442,1526]
simple_stmt [1442,1526]
===
match
---
operator: = [26264,26265]
operator: = [26264,26265]
===
match
---
trailer [31344,31349]
trailer [31400,31405]
===
match
---
classdef [2409,3054]
classdef [2409,3054]
===
match
---
name: self [50699,50703]
name: self [50755,50759]
===
match
---
operator: = [28422,28423]
operator: = [28478,28479]
===
match
---
name: bigquery [1484,1492]
name: bigquery [1484,1492]
===
match
---
operator: = [67156,67157]
operator: = [67212,67213]
===
match
---
string: 'materialized_view' [37884,37903]
string: 'materialized_view' [37940,37959]
===
match
---
atom_expr [26106,26120]
atom_expr [26106,26120]
===
match
---
name: external_project_dataset_table [52199,52229]
name: external_project_dataset_table [52255,52285]
===
match
---
argument [40354,40399]
argument [40410,40455]
===
match
---
expr_stmt [61143,61189]
expr_stmt [61199,61245]
===
match
---
operator: = [85167,85168]
operator: = [85223,85224]
===
match
---
operator: = [18181,18182]
operator: = [18181,18182]
===
match
---
atom_expr [70598,70613]
atom_expr [70654,70669]
===
match
---
operator: = [81254,81255]
operator: = [81310,81311]
===
match
---
name: api_resource_configs [30856,30876]
name: api_resource_configs [30912,30932]
===
match
---
name: BaseOperator [91353,91365]
name: BaseOperator [91409,91421]
===
match
---
atom_expr [78926,78947]
atom_expr [78982,79003]
===
match
---
name: kwargs [6956,6962]
name: kwargs [6956,6962]
===
match
---
trailer [26657,26668]
trailer [26657,26668]
===
match
---
atom_expr [81867,81883]
atom_expr [81923,81939]
===
match
---
operator: = [39749,39750]
operator: = [39805,39806]
===
match
---
name: delegate_to [28729,28740]
name: delegate_to [28785,28796]
===
match
---
name: self [82436,82440]
name: self [82492,82496]
===
match
---
name: str [25965,25968]
name: str [25965,25968]
===
match
---
param [26491,26521]
param [26491,26521]
===
match
---
name: execute [67422,67429]
name: execute [67478,67485]
===
match
---
operator: = [10053,10054]
operator: = [10053,10054]
===
match
---
name: delegate_to [85742,85753]
name: delegate_to [85798,85809]
===
match
---
trailer [51440,51454]
trailer [51496,51510]
===
match
---
argument [90935,90979]
argument [90991,91035]
===
match
---
name: self [29297,29301]
name: self [29353,29357]
===
match
---
atom_expr [40799,40814]
atom_expr [40855,40870]
===
match
---
name: bigquery_conn_id [39282,39298]
name: bigquery_conn_id [39338,39354]
===
match
---
operator: = [28039,28040]
operator: = [28095,28096]
===
match
---
operator: = [40978,40979]
operator: = [41034,41035]
===
match
---
atom [61917,61919]
atom [61973,61975]
===
match
---
name: operator [2665,2673]
name: operator [2665,2673]
===
match
---
name: gcp_conn_id [18656,18667]
name: gcp_conn_id [18656,18667]
===
match
---
operator: , [17345,17346]
operator: , [17345,17346]
===
match
---
name: str [6594,6597]
name: str [6594,6597]
===
match
---
name: on_kill [31280,31287]
name: on_kill [31336,31343]
===
match
---
name: self [67253,67257]
name: self [67309,67313]
===
match
---
return_stmt [2303,2379]
return_stmt [2303,2379]
===
match
---
operator: , [52354,52355]
operator: , [52410,52411]
===
match
---
expr_stmt [50634,50690]
expr_stmt [50690,50746]
===
match
---
string: 'project_id' [69911,69923]
string: 'project_id' [69967,69979]
===
match
---
expr_stmt [95595,95625]
expr_stmt [95651,95681]
===
match
---
funcdef [2126,2380]
funcdef [2126,2380]
===
match
---
name: google [1090,1096]
name: google [1090,1096]
===
match
---
name: Optional [74090,74098]
name: Optional [74146,74154]
===
match
---
tfpdef [26094,26120]
tfpdef [26094,26120]
===
match
---
atom_expr [78669,78697]
atom_expr [78725,78753]
===
match
---
argument [40111,40155]
argument [40167,40211]
===
match
---
name: self [78294,78298]
name: self [78350,78354]
===
match
---
operator: = [29518,29519]
operator: = [29574,29575]
===
match
---
operator: = [38298,38299]
operator: = [38354,38355]
===
match
---
name: delegate_to [67549,67560]
name: delegate_to [67605,67616]
===
match
---
atom_expr [56559,56583]
atom_expr [56615,56639]
===
match
---
string: 'labels' [47298,47306]
string: 'labels' [47354,47362]
===
match
---
operator: = [26475,26476]
operator: = [26475,26476]
===
match
---
atom_expr [52386,52404]
atom_expr [52442,52460]
===
match
---
name: Union [90317,90322]
name: Union [90373,90378]
===
match
---
testlist_comp [69889,69955]
testlist_comp [69945,70011]
===
match
---
name: QUERY [17266,17271]
name: QUERY [17266,17271]
===
match
---
operator: = [40929,40930]
operator: = [40985,40986]
===
match
---
operator: , [6696,6697]
operator: , [6696,6697]
===
match
---
name: project_id [91260,91270]
name: project_id [91316,91326]
===
match
---
expr_stmt [13688,13718]
expr_stmt [13688,13718]
===
match
---
name: compression [50053,50064]
name: compression [50109,50120]
===
match
---
string: "the gcp_conn_id parameter." [81644,81672]
string: "the gcp_conn_id parameter." [81700,81728]
===
match
---
argument [29178,29214]
argument [29234,29270]
===
match
---
argument [98766,98792]
argument [98822,98848]
===
match
---
name: bigquery_conn_id [81179,81195]
name: bigquery_conn_id [81235,81251]
===
match
---
classdef [13923,19166]
classdef [13923,19166]
===
match
---
expr_stmt [7318,7338]
expr_stmt [7318,7338]
===
match
---
if_stmt [2896,2950]
if_stmt [2896,2950]
===
match
---
name: Union [85140,85145]
name: Union [85196,85201]
===
match
---
operator: = [10223,10224]
operator: = [10223,10224]
===
match
---
name: project_id [56415,56425]
name: project_id [56471,56481]
===
match
---
operator: = [61485,61486]
operator: = [61541,61542]
===
match
---
trailer [52490,52508]
trailer [52546,52564]
===
match
---
name: str [84907,84910]
name: str [84963,84966]
===
match
---
atom_expr [77831,77844]
atom_expr [77887,77900]
===
match
---
operator: = [81145,81146]
operator: = [81201,81202]
===
match
---
name: job_id [97301,97307]
name: job_id [97357,97363]
===
match
---
or_test [95667,95691]
or_test [95723,95747]
===
match
---
operator: , [3373,3374]
operator: , [3373,3374]
===
match
---
atom_expr [30733,30746]
atom_expr [30789,30802]
===
match
---
operator: = [70824,70825]
operator: = [70880,70881]
===
match
---
operator: = [60966,60967]
operator: = [61022,61023]
===
match
---
param [48307,48346]
param [48363,48402]
===
match
---
name: super [61234,61239]
name: super [61290,61295]
===
match
---
operator: , [74682,74683]
operator: , [74738,74739]
===
match
---
atom_expr [38240,38254]
atom_expr [38296,38310]
===
match
---
operator: = [9857,9858]
operator: = [9857,9858]
===
match
---
trailer [90867,90879]
trailer [90923,90935]
===
match
---
trailer [31433,31438]
trailer [31489,31494]
===
match
---
atom_expr [98631,98642]
atom_expr [98687,98698]
===
match
---
name: field_delimiter [49020,49035]
name: field_delimiter [49076,49091]
===
match
---
trailer [28060,28069]
trailer [28116,28125]
===
match
---
atom_expr [30451,30476]
atom_expr [30507,30532]
===
match
---
name: str [74099,74102]
name: str [74155,74158]
===
match
---
name: AirflowException [98207,98223]
name: AirflowException [98263,98279]
===
match
---
name: Conflict [1124,1132]
name: Conflict [1124,1132]
===
match
---
atom_expr [95656,95664]
atom_expr [95712,95720]
===
match
---
classdef [1990,2380]
classdef [1990,2380]
===
match
---
simple_stmt [2596,2641]
simple_stmt [2596,2641]
===
match
---
name: super [78388,78393]
name: super [78444,78449]
===
match
---
name: any [48808,48811]
name: any [48864,48867]
===
match
---
atom_expr [96924,96942]
atom_expr [96980,96998]
===
match
---
atom_expr [61967,62022]
atom_expr [62023,62078]
===
match
---
expr_stmt [27551,27597]
expr_stmt [27607,27653]
===
match
---
simple_stmt [49879,49954]
simple_stmt [49935,50010]
===
match
---
name: project_id [57002,57012]
name: project_id [57058,57068]
===
match
---
param [95154,95188]
param [95210,95244]
===
match
---
and_test [49690,49722]
and_test [49746,49778]
===
match
---
name: include_policy_tags [90457,90476]
name: include_policy_tags [90513,90532]
===
match
---
operator: = [97873,97874]
operator: = [97929,97930]
===
match
---
operator: , [63852,63853]
operator: , [63908,63909]
===
match
---
argument [78846,78872]
argument [78902,78928]
===
match
---
expr_stmt [27986,28018]
expr_stmt [28042,28074]
===
match
---
argument [30190,30234]
argument [30246,30290]
===
match
---
trailer [64413,64433]
trailer [64469,64489]
===
match
---
decorated [2551,2641]
decorated [2551,2641]
===
match
---
atom_expr [13610,13675]
atom_expr [13610,13675]
===
match
---
expr_stmt [48792,49299]
expr_stmt [48848,49355]
===
match
---
testlist_star_expr [40242,40264]
testlist_star_expr [40298,40320]
===
match
---
name: kwargs [48566,48572]
name: kwargs [48622,48628]
===
match
---
name: _job_id [96780,96787]
name: _job_id [96836,96843]
===
match
---
expr_stmt [18164,18199]
expr_stmt [18164,18199]
===
match
---
name: Dict [47707,47711]
name: Dict [47763,47767]
===
match
---
atom [69994,70022]
atom [70050,70078]
===
match
---
name: str [31156,31159]
name: str [31212,31215]
===
match
---
simple_stmt [67140,67169]
simple_stmt [67196,67225]
===
match
---
simple_stmt [40318,40523]
simple_stmt [40374,40579]
===
match
---
simple_stmt [94777,94817]
simple_stmt [94833,94873]
===
match
---
param [47558,47563]
param [47614,47619]
===
match
---
operator: = [90954,90955]
operator: = [91010,91011]
===
match
---
name: impersonation_chain [82034,82053]
name: impersonation_chain [82090,82109]
===
match
---
trailer [67672,67805]
trailer [67728,67861]
===
match
---
operator: < [2912,2913]
operator: < [2912,2913]
===
match
---
operator: = [96447,96448]
operator: = [96503,96504]
===
match
---
expr_stmt [39226,39268]
expr_stmt [39282,39324]
===
match
---
expr_stmt [51701,51777]
expr_stmt [51757,51833]
===
match
---
string: "the gcp_conn_id parameter." [85403,85431]
string: "the gcp_conn_id parameter." [85459,85487]
===
match
---
name: Optional [38231,38239]
name: Optional [38287,38295]
===
match
---
operator: , [56663,56664]
operator: , [56719,56720]
===
match
---
name: BigQueryUIColors [77650,77666]
name: BigQueryUIColors [77706,77722]
===
match
---
argument [91048,91096]
argument [91104,91152]
===
match
---
tfpdef [94858,94887]
tfpdef [94914,94943]
===
match
---
operator: = [39202,39203]
operator: = [39258,39259]
===
match
---
operator: } [84733,84734]
operator: } [84789,84790]
===
match
---
name: template_fields [69861,69876]
name: template_fields [69917,69932]
===
match
---
simple_stmt [70598,70627]
simple_stmt [70654,70683]
===
match
---
atom_expr [29361,29386]
atom_expr [29417,29442]
===
match
---
operator: , [55683,55684]
operator: , [55739,55740]
===
match
---
trailer [6818,6838]
trailer [6818,6838]
===
match
---
name: dataset_id [61654,61664]
name: dataset_id [61710,61720]
===
match
---
expr_stmt [7263,7309]
expr_stmt [7263,7309]
===
match
---
name: ui_color [66736,66744]
name: ui_color [66792,66800]
===
match
---
name: self [28089,28093]
name: self [28145,28149]
===
match
---
atom_expr [52828,52848]
atom_expr [52884,52904]
===
match
---
name: TaskInstance [2719,2731]
name: TaskInstance [2719,2731]
===
match
---
name: exists_ok [41336,41345]
name: exists_ok [41392,41401]
===
match
---
operator: , [50975,50976]
operator: , [51031,51032]
===
match
---
operator: = [52485,52486]
operator: = [52541,52542]
===
match
---
name: table_id [90111,90119]
name: table_id [90167,90175]
===
match
---
name: encryption_configuration [50639,50663]
name: encryption_configuration [50695,50719]
===
match
---
trailer [85799,85819]
trailer [85855,85875]
===
match
---
operator: ** [85183,85185]
operator: ** [85239,85241]
===
match
---
name: configuration [96102,96115]
name: configuration [96158,96171]
===
match
---
name: stacklevel [13662,13672]
name: stacklevel [13662,13672]
===
match
---
argument [50989,51033]
argument [51045,51089]
===
match
---
operator: , [95981,95982]
operator: , [96037,96038]
===
match
---
name: sql [25465,25468]
name: sql [25465,25468]
===
match
---
atom_expr [60352,60365]
atom_expr [60408,60421]
===
match
---
atom_expr [66867,66880]
atom_expr [66923,66936]
===
match
---
atom_expr [96097,96115]
atom_expr [96153,96171]
===
match
---
simple_stmt [61234,61261]
simple_stmt [61290,61317]
===
match
---
atom_expr [50732,50756]
atom_expr [50788,50812]
===
match
---
tfpdef [81270,81293]
tfpdef [81326,81349]
===
match
---
name: destination_project_dataset_table [49920,49953]
name: destination_project_dataset_table [49976,50009]
===
match
---
trailer [64335,64347]
trailer [64391,64403]
===
match
---
operator: * [70110,70111]
operator: * [70166,70167]
===
match
---
atom_expr [51499,51517]
atom_expr [51555,51573]
===
match
---
operator: = [51170,51171]
operator: = [51226,51227]
===
match
---
trailer [98223,98527]
trailer [98279,98583]
===
match
---
operator: = [74062,74063]
operator: = [74118,74119]
===
match
---
name: project_id [78145,78155]
name: project_id [78201,78211]
===
match
---
and_test [51057,51147]
and_test [51113,51203]
===
match
---
operator: = [50664,50665]
operator: = [50720,50721]
===
match
---
name: delegate_to [90910,90921]
name: delegate_to [90966,90977]
===
match
---
name: __init__ [74642,74650]
name: __init__ [74698,74706]
===
match
---
suite [74311,74661]
suite [74367,74717]
===
match
---
trailer [64725,64730]
trailer [64781,64786]
===
match
---
atom [66649,66731]
atom [66705,66787]
===
match
---
operator: , [17400,17401]
operator: , [17400,17401]
===
match
---
name: str [74250,74253]
name: str [74306,74309]
===
match
---
operator: = [64621,64622]
operator: = [64677,64678]
===
match
---
name: impersonation_chain [39824,39843]
name: impersonation_chain [39880,39899]
===
match
---
operator: = [41077,41078]
operator: = [41133,41134]
===
match
---
tfpdef [95017,95034]
tfpdef [95073,95090]
===
match
---
argument [60798,60810]
argument [60854,60866]
===
match
---
name: self [96414,96418]
name: self [96470,96474]
===
match
---
atom_expr [70799,70823]
atom_expr [70855,70879]
===
match
---
name: bq_hook [70922,70929]
name: bq_hook [70978,70985]
===
match
---
trailer [86135,86144]
trailer [86191,86200]
===
match
---
operator: = [74710,74711]
operator: = [74766,74767]
===
match
---
tfpdef [26226,26263]
tfpdef [26226,26263]
===
match
---
trailer [13732,13744]
trailer [13732,13744]
===
match
---
operator: = [1634,1635]
operator: = [1634,1635]
===
match
---
tfpdef [17599,17622]
tfpdef [17599,17622]
===
match
---
name: airflow [1447,1454]
name: airflow [1447,1454]
===
match
---
trailer [31155,31160]
trailer [31211,31216]
===
match
---
tfpdef [26280,26303]
tfpdef [26280,26303]
===
match
---
param [26137,26165]
param [26137,26165]
===
match
---
arglist [18634,18768]
arglist [18634,18768]
===
match
---
classdef [3056,3417]
classdef [3056,3417]
===
match
---
simple_stmt [50699,50724]
simple_stmt [50755,50780]
===
match
---
tfpdef [6706,6726]
tfpdef [6706,6726]
===
match
---
name: Optional [13183,13191]
name: Optional [13183,13191]
===
match
---
arglist [28533,28558]
arglist [28589,28614]
===
match
---
operator: = [70614,70615]
operator: = [70670,70671]
===
match
---
atom_expr [27870,27895]
atom_expr [27926,27951]
===
match
---
operator: = [29242,29243]
operator: = [29298,29299]
===
match
---
name: quote_character [48007,48022]
name: quote_character [48063,48078]
===
match
---
name: str [81115,81118]
name: str [81171,81174]
===
match
---
simple_stmt [27357,27372]
simple_stmt [27413,27428]
===
match
---
trailer [28921,28926]
trailer [28977,28982]
===
match
---
operator: = [9750,9751]
operator: = [9750,9751]
===
match
---
operator: { [94747,94748]
operator: { [94803,94804]
===
match
---
subscriptlist [25722,25735]
subscriptlist [25722,25735]
===
match
---
param [55898,55932]
param [55954,55988]
===
match
---
param [26094,26128]
param [26094,26128]
===
match
---
operator: } [97091,97092]
operator: } [97147,97148]
===
match
---
name: job_ids [2776,2783]
name: job_ids [2776,2783]
===
match
---
atom [89665,89800]
atom [89721,89856]
===
match
---
simple_stmt [98075,98103]
simple_stmt [98131,98159]
===
match
---
name: warn [7014,7018]
name: warn [7014,7018]
===
match
---
trailer [17435,17440]
trailer [17435,17440]
===
match
---
name: days_back [13525,13534]
name: days_back [13525,13534]
===
match
---
operator: , [73749,73750]
operator: , [73805,73806]
===
match
---
suite [48588,50779]
suite [48644,50835]
===
match
---
string: 'google_cloud_default' [77922,77944]
string: 'google_cloud_default' [77978,78000]
===
match
---
trailer [6933,6935]
trailer [6933,6935]
===
match
---
trailer [18259,18271]
trailer [18259,18271]
===
match
---
name: self [82029,82033]
name: self [82085,82089]
===
match
---
trailer [51672,51687]
trailer [51728,51743]
===
match
---
expr_stmt [49834,49870]
expr_stmt [49890,49926]
===
match
---
name: bq_hook [52152,52159]
name: bq_hook [52208,52215]
===
match
---
atom_expr [90308,90343]
atom_expr [90364,90399]
===
match
---
name: create_empty_table [40752,40770]
name: create_empty_table [40808,40826]
===
match
---
trailer [51552,51567]
trailer [51608,51623]
===
match
---
name: impersonation_chain [38901,38920]
name: impersonation_chain [38957,38976]
===
match
---
argument [28954,28966]
argument [29010,29022]
===
match
---
name: dataset_id [18099,18109]
name: dataset_id [18099,18109]
===
match
---
operator: , [55840,55841]
operator: , [55896,55897]
===
match
---
simple_stmt [61024,61096]
simple_stmt [61080,61152]
===
match
---
operator: = [90862,90863]
operator: = [90918,90919]
===
match
---
name: self [91255,91259]
name: self [91311,91315]
===
match
---
name: allow_large_results [27578,27597]
name: allow_large_results [27634,27653]
===
match
---
name: Sequence [67075,67083]
name: Sequence [67131,67139]
===
match
---
string: 'dataset_reference' [59891,59910]
string: 'dataset_reference' [59947,59966]
===
match
---
name: deletion_dataset_table [82160,82182]
name: deletion_dataset_table [82216,82238]
===
match
---
trailer [78695,78697]
trailer [78751,78753]
===
match
---
name: create_empty_dataset [61556,61576]
name: create_empty_dataset [61612,61632]
===
match
---
expr_stmt [63895,63936]
expr_stmt [63951,63992]
===
match
---
trailer [50736,50756]
trailer [50792,50812]
===
match
---
trailer [51111,51125]
trailer [51167,51181]
===
match
---
simple_stmt [69966,70023]
simple_stmt [70022,70079]
===
match
---
operator: = [90095,90096]
operator: = [90151,90152]
===
match
---
operator: , [40858,40859]
operator: , [40914,40915]
===
match
---
operator: = [52385,52386]
operator: = [52441,52442]
===
match
---
name: index [2523,2528]
name: index [2523,2528]
===
match
---
name: impersonation_chain [10161,10180]
name: impersonation_chain [10161,10180]
===
match
---
name: List [26658,26662]
name: List [26658,26662]
===
match
---
trailer [51213,51242]
trailer [51269,51298]
===
match
---
name: view [41107,41111]
name: view [41163,41167]
===
match
---
name: self [61790,61794]
name: self [61846,61850]
===
match
---
name: delegate_to [81227,81238]
name: delegate_to [81283,81294]
===
match
---
name: skip_leading_rows [52491,52508]
name: skip_leading_rows [52547,52564]
===
match
---
trailer [28201,28216]
trailer [28257,28272]
===
match
---
trailer [17534,17539]
trailer [17534,17539]
===
match
---
atom_expr [85602,85621]
atom_expr [85658,85677]
===
match
---
argument [64610,64638]
argument [64666,64694]
===
match
---
simple_stmt [49834,49871]
simple_stmt [49890,49927]
===
match
---
simple_stmt [27870,27919]
simple_stmt [27926,27975]
===
match
---
name: Optional [55962,55970]
name: Optional [56018,56026]
===
match
---
name: self [70672,70676]
name: self [70728,70732]
===
match
---
name: self [28550,28554]
name: self [28606,28610]
===
match
---
dotted_name [1447,1492]
dotted_name [1447,1492]
===
match
---
name: labels [9727,9733]
name: labels [9727,9733]
===
match
---
name: job_id [2347,2353]
name: job_id [2347,2353]
===
match
---
strings [49375,49596]
strings [49431,49652]
===
match
---
name: super [39040,39045]
name: super [39096,39101]
===
match
---
operator: , [61416,61417]
operator: , [61472,61473]
===
match
---
atom_expr [2786,2839]
atom_expr [2786,2839]
===
match
---
name: self [13812,13816]
name: self [13812,13816]
===
match
---
expr_stmt [61857,61954]
expr_stmt [61913,62010]
===
match
---
atom_expr [41587,41602]
atom_expr [41643,41658]
===
match
---
name: DeprecationWarning [56244,56262]
name: DeprecationWarning [56300,56318]
===
match
---
name: self [71252,71256]
name: self [71308,71312]
===
match
---
name: job [98098,98101]
name: job [98154,98157]
===
match
---
name: Set [95656,95659]
name: Set [95712,95715]
===
match
---
arglist [9935,9985]
arglist [9935,9985]
===
match
---
name: schema_fields [51642,51655]
name: schema_fields [51698,51711]
===
match
---
name: impersonation_chain [74822,74841]
name: impersonation_chain [74878,74897]
===
match
---
operator: , [85431,85432]
operator: , [85487,85488]
===
match
---
string: 'dataset_id' [69889,69901]
string: 'dataset_id' [69945,69957]
===
match
---
arglist [51423,51454]
arglist [51479,51510]
===
match
---
atom_expr [41331,41345]
atom_expr [41387,41401]
===
match
---
subscriptlist [48527,48545]
subscriptlist [48583,48601]
===
match
---
name: hook [86000,86004]
name: hook [86056,86060]
===
match
---
simple_stmt [50338,50381]
simple_stmt [50394,50437]
===
match
---
operator: = [63904,63905]
operator: = [63960,63961]
===
match
---
name: self [98753,98757]
name: self [98809,98813]
===
match
---
name: Optional [38922,38930]
name: Optional [38978,38986]
===
match
---
atom_expr [73928,73942]
atom_expr [73984,73998]
===
match
---
atom_expr [19110,19122]
atom_expr [19110,19122]
===
match
---
name: self [85795,85799]
name: self [85851,85855]
===
match
---
trailer [51276,51288]
trailer [51332,51344]
===
match
---
name: query_params [28006,28018]
name: query_params [28062,28074]
===
match
---
string: """Return operator extra links""" [25404,25437]
string: """Return operator extra links""" [25404,25437]
===
match
---
operator: , [73942,73943]
operator: , [73998,73999]
===
match
---
simple_stmt [7424,9139]
simple_stmt [7424,9139]
===
match
---
operator: , [96454,96455]
operator: , [96510,96511]
===
match
---
trailer [18470,18475]
trailer [18470,18475]
===
match
---
atom_expr [64464,64490]
atom_expr [64520,64546]
===
match
---
name: Sequence [38942,38950]
name: Sequence [38998,39006]
===
match
---
atom_expr [3260,3279]
atom_expr [3260,3279]
===
match
---
simple_stmt [2095,2121]
simple_stmt [2095,2121]
===
match
---
funcdef [89916,90774]
funcdef [89972,90830]
===
match
---
name: str [74264,74267]
name: str [74320,74323]
===
match
---
simple_stmt [2938,2950]
simple_stmt [2938,2950]
===
match
---
name: encode [97011,97017]
name: encode [97067,97073]
===
match
---
tfpdef [55898,55924]
tfpdef [55954,55980]
===
match
---
operator: , [61722,61723]
operator: , [61778,61779]
===
match
---
name: str [9409,9412]
name: str [9409,9412]
===
match
---
argument [30830,30876]
argument [30886,30932]
===
match
---
expr_stmt [94777,94816]
expr_stmt [94833,94872]
===
match
---
atom_expr [7318,7329]
atom_expr [7318,7329]
===
match
---
name: self [61024,61028]
name: self [61080,61084]
===
match
---
name: self [74495,74499]
name: self [74551,74555]
===
match
---
simple_stmt [2776,2840]
simple_stmt [2776,2840]
===
match
---
name: delegate_to [85728,85739]
name: delegate_to [85784,85795]
===
match
---
operator: ** [64223,64225]
operator: ** [64279,64281]
===
match
---
name: BIGQUERY_JOB_DETAILS_LINK_FMT [1604,1633]
name: BIGQUERY_JOB_DETAILS_LINK_FMT [1604,1633]
===
match
---
atom_expr [52650,52670]
atom_expr [52706,52726]
===
match
---
name: context [74684,74691]
name: context [74740,74747]
===
match
---
param [94939,94970]
param [94995,95026]
===
match
---
simple_stmt [9921,9987]
simple_stmt [9921,9987]
===
match
---
trailer [90336,90341]
trailer [90392,90397]
===
match
---
trailer [61971,61975]
trailer [62027,62031]
===
match
---
name: table_id [18555,18563]
name: table_id [18555,18563]
===
match
---
name: i [25572,25573]
name: i [25572,25573]
===
match
---
operator: , [26623,26624]
operator: , [26623,26624]
===
match
---
trailer [97010,97017]
trailer [97066,97073]
===
match
---
name: index [2629,2634]
name: index [2629,2634]
===
match
---
atom_expr [98537,98548]
atom_expr [98593,98604]
===
match
---
name: value [60051,60056]
name: value [60107,60112]
===
match
---
atom_expr [96414,96427]
atom_expr [96470,96483]
===
match
---
name: str [38388,38391]
name: str [38444,38447]
===
match
---
operator: -> [56674,56676]
operator: -> [56730,56732]
===
match
---
operator: , [82463,82464]
operator: , [82519,82520]
===
match
---
arglist [82139,82182]
arglist [82195,82238]
===
match
---
atom_expr [31151,31160]
atom_expr [31207,31216]
===
match
---
string: 'gcs_schema_object' [37821,37840]
string: 'gcs_schema_object' [37877,37896]
===
match
---
fstring_string: _ [97092,97093]
fstring_string: _ [97148,97149]
===
match
---
name: str [77797,77800]
name: str [77853,77856]
===
match
---
name: Any [47717,47720]
name: Any [47773,47776]
===
match
---
argument [48614,48622]
argument [48670,48678]
===
match
---
argument [52372,52404]
argument [52428,52460]
===
match
---
name: datetime [973,981]
name: datetime [973,981]
===
match
---
operator: = [77489,77490]
operator: = [77545,77546]
===
match
---
operator: = [61121,61122]
operator: = [61177,61178]
===
match
---
operator: = [39794,39795]
operator: = [39850,39851]
===
match
---
operator: = [38958,38959]
operator: = [39014,39015]
===
match
---
name: self [30272,30276]
name: self [30328,30332]
===
match
---
string: 'INTERACTIVE' [26507,26520]
string: 'INTERACTIVE' [26507,26520]
===
match
---
argument [70566,70578]
argument [70622,70634]
===
match
---
name: delegate_to [55898,55909]
name: delegate_to [55954,55965]
===
match
---
name: TableReference [51711,51725]
name: TableReference [51767,51781]
===
match
---
name: materialized_view [39585,39602]
name: materialized_view [39641,39658]
===
match
---
operator: = [60177,60178]
operator: = [60233,60234]
===
match
---
name: maximum_bytes_billed [30456,30476]
name: maximum_bytes_billed [30512,30532]
===
match
---
argument [61780,61804]
argument [61836,61860]
===
match
---
param [60531,60540]
param [60587,60596]
===
match
---
name: gcp_conn_id [78509,78520]
name: gcp_conn_id [78565,78576]
===
match
---
simple_stmt [73820,73860]
simple_stmt [73876,73916]
===
match
---
atom_expr [25716,25736]
atom_expr [25716,25736]
===
match
---
string: 'impersonation_chain' [12758,12779]
string: 'impersonation_chain' [12758,12779]
===
match
---
argument [50911,50939]
argument [50967,50995]
===
match
---
param [67430,67435]
param [67486,67491]
===
match
---
name: self [28197,28201]
name: self [28253,28257]
===
match
---
name: job_id [97648,97654]
name: job_id [97704,97710]
===
match
---
atom [48825,49289]
atom [48881,49345]
===
match
---
name: datetime [2695,2703]
name: datetime [2695,2703]
===
match
---
atom_expr [26196,26209]
atom_expr [26196,26209]
===
match
---
operator: , [18885,18886]
operator: , [18885,18886]
===
match
---
name: dict [9744,9748]
name: dict [9744,9748]
===
match
---
operator: = [9296,9297]
operator: = [9296,9297]
===
match
---
operator: -> [74303,74305]
operator: -> [74359,74361]
===
match
---
suite [82552,86383]
suite [82608,86439]
===
match
---
trailer [40002,40019]
trailer [40058,40075]
===
match
---
name: delegate_to [40050,40061]
name: delegate_to [40106,40117]
===
match
---
name: self [90393,90397]
name: self [90449,90453]
===
match
---
atom_expr [27986,28003]
atom_expr [28042,28059]
===
match
---
name: view [38665,38669]
name: view [38721,38725]
===
match
---
tfpdef [48394,48434]
tfpdef [48450,48490]
===
match
---
name: ui_color [89871,89879]
name: ui_color [89927,89935]
===
match
---
name: schema_fields_updates [90398,90419]
name: schema_fields_updates [90454,90475]
===
match
---
operator: = [38736,38737]
operator: = [38792,38793]
===
match
---
name: impersonation_chain [39846,39865]
name: impersonation_chain [39902,39921]
===
match
---
name: dataset_id [18112,18122]
name: dataset_id [18112,18122]
===
match
---
operator: * [6578,6579]
operator: * [6578,6579]
===
match
---
string: "The bigquery_conn_id parameter has been deprecated. You should pass " [17845,17915]
string: "The bigquery_conn_id parameter has been deprecated. You should pass " [17845,17915]
===
match
---
trailer [27657,27669]
trailer [27713,27725]
===
match
---
name: impersonation_chain [18393,18412]
name: impersonation_chain [18393,18412]
===
match
---
trailer [51065,51079]
trailer [51121,51135]
===
match
---
operator: , [40019,40020]
operator: , [40075,40076]
===
match
---
operator: = [6948,6949]
operator: = [6948,6949]
===
match
---
name: impersonation_chain [86183,86202]
name: impersonation_chain [86239,86258]
===
match
---
operator: , [29494,29495]
operator: , [29550,29551]
===
match
---
name: self [29982,29986]
name: self [30038,30042]
===
match
---
simple_stmt [1924,1942]
simple_stmt [1924,1942]
===
match
---
name: str [95116,95119]
name: str [95172,95175]
===
match
---
tfpdef [47583,47594]
tfpdef [47639,47650]
===
match
---
param [90797,90804]
param [90853,90860]
===
match
---
operator: , [70168,70169]
operator: , [70224,70225]
===
match
---
name: dag_id [97206,97212]
name: dag_id [97262,97268]
===
match
---
operator: = [30382,30383]
operator: = [30438,30439]
===
match
---
name: hook [28493,28497]
name: hook [28549,28553]
===
match
---
operator: = [12979,12980]
operator: = [12979,12980]
===
match
---
operator: = [29732,29733]
operator: = [29788,29789]
===
match
---
trailer [27874,27895]
trailer [27930,27951]
===
match
---
operator: -> [39933,39935]
operator: -> [39989,39991]
===
match
---
name: self [40206,40210]
name: self [40262,40266]
===
match
---
expr_stmt [64806,64891]
expr_stmt [64862,64947]
===
match
---
trailer [90456,90476]
trailer [90512,90532]
===
match
---
param [9529,9568]
param [9529,9568]
===
match
---
operator: = [48378,48379]
operator: = [48434,48435]
===
match
---
name: exists_ok [61780,61789]
name: exists_ok [61836,61845]
===
match
---
tfpdef [26725,26765]
tfpdef [26725,26765]
===
match
---
name: impersonation_chain [13213,13232]
name: impersonation_chain [13213,13232]
===
match
---
name: self [64717,64721]
name: self [64773,64777]
===
match
---
atom_expr [6804,6839]
atom_expr [6804,6839]
===
match
---
trailer [25464,25468]
trailer [25464,25468]
===
match
---
expr_stmt [28572,28857]
expr_stmt [28628,28913]
===
match
---
name: context [61284,61291]
name: context [61340,61347]
===
match
---
argument [86257,86283]
argument [86313,86339]
===
match
---
atom [77606,77634]
atom [77662,77690]
===
match
---
name: cancel_on_kill [95777,95791]
name: cancel_on_kill [95833,95847]
===
match
---
operator: , [17145,17146]
operator: , [17145,17146]
===
match
---
atom_expr [13358,13567]
atom_expr [13358,13567]
===
match
---
name: labels [10225,10231]
name: labels [10225,10231]
===
match
---
trailer [82426,82501]
trailer [82482,82557]
===
match
---
operator: , [6579,6580]
operator: , [6579,6580]
===
match
---
trailer [28771,28780]
trailer [28827,28836]
===
match
---
expr_stmt [90653,90683]
expr_stmt [90709,90739]
===
match
---
param [17378,17401]
param [17378,17401]
===
match
---
operator: = [26210,26211]
operator: = [26210,26211]
===
match
---
name: location [50715,50723]
name: location [50771,50779]
===
match
---
param [95197,95261]
param [95253,95317]
===
match
---
operator: = [70371,70372]
operator: = [70427,70428]
===
match
---
name: gcp_conn_id [70220,70231]
name: gcp_conn_id [70276,70287]
===
match
---
trailer [30387,30408]
trailer [30443,30464]
===
match
---
atom_expr [91007,91281]
atom_expr [91063,91337]
===
match
---
name: DeprecationWarning [13642,13660]
name: DeprecationWarning [13642,13660]
===
match
---
atom_expr [18294,18310]
atom_expr [18294,18310]
===
match
---
trailer [97803,97933]
trailer [97859,97989]
===
match
---
name: query_params [27991,28003]
name: query_params [28047,28059]
===
match
---
name: hash_base [97001,97010]
name: hash_base [97057,97066]
===
match
---
name: BigQueryUIColors [63906,63922]
name: BigQueryUIColors [63962,63978]
===
match
---
name: self [52542,52546]
name: self [52598,52602]
===
match
---
name: bigquery_conn_id [55850,55866]
name: bigquery_conn_id [55906,55922]
===
match
---
trailer [60606,60611]
trailer [60662,60667]
===
match
---
name: providers [1455,1464]
name: providers [1455,1464]
===
match
---
operator: , [85952,85953]
operator: , [86008,86009]
===
match
---
atom_expr [61143,61167]
atom_expr [61199,61223]
===
match
---
operator: = [6506,6507]
operator: = [6506,6507]
===
match
---
name: exists_ok [39879,39888]
name: exists_ok [39935,39944]
===
match
---
tfpdef [97332,97344]
tfpdef [97388,97400]
===
match
---
param [2155,2159]
param [2155,2159]
===
match
---
operator: = [28582,28583]
operator: = [28638,28639]
===
match
---
operator: = [9711,9712]
operator: = [9711,9712]
===
match
---
fstring_string: argument 'sql' of type  [31127,31150]
fstring_string: argument 'sql' of type  [31183,31206]
===
match
---
trailer [56803,56956]
trailer [56859,57012]
===
match
---
name: dataset_id [74325,74335]
name: dataset_id [74381,74391]
===
match
---
name: table_id [90512,90520]
name: table_id [90568,90576]
===
match
---
atom_expr [18094,18109]
atom_expr [18094,18109]
===
match
---
name: info [56700,56704]
name: info [56756,56760]
===
match
---
operator: , [48384,48385]
operator: , [48440,48441]
===
match
---
name: gcp_conn_id [81872,81883]
name: gcp_conn_id [81928,81939]
===
match
---
strings [17845,17960]
strings [17845,17960]
===
match
---
name: self [7263,7267]
name: self [7263,7267]
===
match
---
name: encryption_configuration [30984,31008]
name: encryption_configuration [31040,31064]
===
match
---
simple_stmt [28089,28132]
simple_stmt [28145,28188]
===
match
---
name: kwargs [26857,26863]
name: kwargs [26857,26863]
===
match
---
argument [29276,29322]
argument [29332,29378]
===
match
---
tfpdef [84979,85010]
tfpdef [85035,85066]
===
match
---
name: project_id [56402,56412]
name: project_id [56458,56468]
===
match
---
operator: = [82435,82436]
operator: = [82491,82492]
===
match
---
name: fields [74432,74438]
name: fields [74488,74494]
===
match
---
suite [67445,67806]
suite [67501,67862]
===
match
---
name: __init__ [61242,61250]
name: __init__ [61298,61306]
===
match
---
name: source_objects [48705,48719]
name: source_objects [48761,48775]
===
match
---
simple_stmt [27927,27978]
simple_stmt [27983,28034]
===
match
---
trailer [25880,25886]
trailer [25880,25886]
===
match
---
return_stmt [25528,25600]
return_stmt [25528,25600]
===
match
---
trailer [82159,82182]
trailer [82215,82238]
===
match
---
param [78438,78445]
param [78494,78501]
===
match
---
name: cloud [1556,1561]
name: cloud [1556,1561]
===
match
---
name: warnings [81526,81534]
name: warnings [81582,81590]
===
match
---
simple_stmt [7162,7177]
simple_stmt [7162,7177]
===
match
---
name: schema_fields [40631,40644]
name: schema_fields [40687,40700]
===
match
---
param [74214,74278]
param [74270,74334]
===
match
---
name: metrics_thresholds [12921,12939]
name: metrics_thresholds [12921,12939]
===
match
---
name: bigquery_conn_id [50395,50411]
name: bigquery_conn_id [50451,50467]
===
match
---
operator: , [6846,6847]
operator: , [6846,6847]
===
match
---
name: TABLE [1946,1951]
name: TABLE [1946,1951]
===
match
---
atom_expr [26649,26668]
atom_expr [26649,26668]
===
match
---
operator: , [1512,1513]
operator: , [1512,1513]
===
match
---
operator: = [85622,85623]
operator: = [85678,85679]
===
match
---
operator: -> [78086,78088]
operator: -> [78142,78144]
===
match
---
return_stmt [71107,71278]
return_stmt [71163,71334]
===
match
---
trailer [28093,28111]
trailer [28149,28167]
===
match
---
operator: } [31160,31161]
operator: } [31216,31217]
===
match
---
name: self [98631,98635]
name: self [98687,98691]
===
match
---
trailer [28401,28421]
trailer [28457,28477]
===
match
---
operator: , [40590,40591]
operator: , [40646,40647]
===
match
---
param [9614,9645]
param [9614,9645]
===
match
---
operator: , [86144,86145]
operator: , [86200,86201]
===
match
---
name: self [71062,71066]
name: self [71118,71122]
===
match
---
name: self [56829,56833]
name: self [56885,56889]
===
match
---
param [48264,48298]
param [48320,48354]
===
match
---
trailer [55634,55640]
trailer [55690,55696]
===
match
---
name: schema_fields_updates [90422,90443]
name: schema_fields_updates [90478,90499]
===
match
---
simple_stmt [67253,67284]
simple_stmt [67309,67340]
===
match
---
operator: , [64140,64141]
operator: , [64196,64197]
===
match
---
operator: , [25701,25702]
operator: , [25701,25702]
===
match
---
funcdef [67418,67806]
funcdef [67474,67862]
===
match
---
trailer [48732,48746]
trailer [48788,48802]
===
match
---
operator: , [63883,63884]
operator: , [63939,63940]
===
match
---
name: __init__ [47540,47548]
name: __init__ [47596,47604]
===
match
---
simple_stmt [95375,95410]
simple_stmt [95431,95466]
===
match
---
name: Iterable [1012,1020]
name: Iterable [1012,1020]
===
match
---
operator: = [90631,90632]
operator: = [90687,90688]
===
match
---
trailer [64926,64928]
trailer [64982,64984]
===
match
---
argument [2799,2824]
argument [2799,2824]
===
match
---
argument [91110,91154]
argument [91166,91210]
===
match
---
name: self [50732,50736]
name: self [50788,50792]
===
match
---
simple_stmt [74456,74487]
simple_stmt [74512,74543]
===
match
---
operator: = [95035,95036]
operator: = [95091,95092]
===
match
---
operator: , [73696,73697]
operator: , [73752,73753]
===
match
---
operator: , [1010,1011]
operator: , [1010,1011]
===
match
---
atom_expr [85762,85775]
atom_expr [85818,85831]
===
match
---
string: '.sql' [6484,6490]
string: '.sql' [6484,6490]
===
match
---
atom_expr [41458,41474]
atom_expr [41514,41530]
===
match
---
operator: , [95315,95316]
operator: , [95371,95372]
===
match
---
name: location [82001,82009]
name: location [82057,82065]
===
match
---
string: 'Dataset id: %s Project id: %s' [56705,56736]
string: 'Dataset id: %s Project id: %s' [56761,56792]
===
match
---
argument [29548,29596]
argument [29604,29652]
===
match
---
string: """     This operator is used to patch dataset for your Project in BigQuery.     It only replaces fields that are provided in the submitted dataset resource.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryPatchDatasetOperator`      :param dataset_id: The id of dataset. Don't need to provide,         if datasetId in dataset_reference.     :type dataset_id: str     :param dataset_resource: Dataset resource that will be provided with request body.         https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets#resource     :type dataset_resource: dict     :param project_id: The name of the project where we want to create the dataset.         Don't need to provide, if projectId in dataset_reference.     :type project_id: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]      :rtype: dataset         https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets#resource     """ [67862,69855]
string: """     This operator is used to patch dataset for your Project in BigQuery.     It only replaces fields that are provided in the submitted dataset resource.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryPatchDatasetOperator`      :param dataset_id: The id of dataset. Don't need to provide,         if datasetId in dataset_reference.     :type dataset_id: str     :param dataset_resource: Dataset resource that will be provided with request body.         https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets#resource     :type dataset_resource: dict     :param project_id: The name of the project where we want to create the dataset.         Don't need to provide, if projectId in dataset_reference.     :type project_id: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]      :rtype: dataset         https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets#resource     """ [67918,69911]
===
match
---
trailer [56364,56375]
trailer [56420,56431]
===
match
---
param [66991,67025]
param [67047,67081]
===
match
---
name: self [38142,38146]
name: self [38198,38202]
===
match
---
param [64056,64098]
param [64112,64154]
===
match
---
tfpdef [38314,38343]
tfpdef [38370,38399]
===
match
---
name: self [55668,55672]
name: self [55724,55728]
===
match
---
trailer [28246,28255]
trailer [28302,28311]
===
match
---
arglist [2188,2222]
arglist [2188,2222]
===
match
---
operator: = [77920,77921]
operator: = [77976,77977]
===
match
---
operator: , [90979,90980]
operator: , [91035,91036]
===
match
---
trailer [85232,85242]
trailer [85288,85298]
===
match
---
argument [29464,29494]
argument [29520,29550]
===
match
---
string: "table_resource" [73790,73806]
string: "table_resource" [73846,73862]
===
match
---
argument [96365,96391]
argument [96421,96447]
===
match
---
import_as_names [1376,1441]
import_as_names [1376,1441]
===
match
---
operator: = [47172,47173]
operator: = [47228,47229]
===
match
---
trailer [97170,97172]
trailer [97226,97228]
===
match
---
expr_stmt [50828,51044]
expr_stmt [50884,51100]
===
match
---
name: table_id [90523,90531]
name: table_id [90579,90587]
===
match
---
operator: = [67736,67737]
operator: = [67792,67793]
===
match
---
trailer [31057,31061]
trailer [31113,31117]
===
match
---
operator: , [38304,38305]
operator: , [38360,38361]
===
match
---
simple_stmt [39696,39721]
simple_stmt [39752,39777]
===
match
---
name: delegate_to [74780,74791]
name: delegate_to [74836,74847]
===
match
---
param [38360,38400]
param [38416,38456]
===
match
---
trailer [86272,86283]
trailer [86328,86339]
===
match
---
name: schema_fields [51483,51496]
name: schema_fields [51539,51552]
===
match
---
argument [75084,75110]
argument [75140,75166]
===
match
---
operator: = [56584,56585]
operator: = [56640,56641]
===
match
---
tfpdef [66897,66923]
tfpdef [66953,66979]
===
match
---
name: BIGQUERY_JOB_DETAILS_LINK_FMT [3002,3031]
name: BIGQUERY_JOB_DETAILS_LINK_FMT [3002,3031]
===
match
---
import_as_names [1001,1071]
import_as_names [1001,1071]
===
match
---
name: str [74193,74196]
name: str [74249,74252]
===
match
---
name: allow_jagged_rows [52754,52771]
name: allow_jagged_rows [52810,52827]
===
match
---
trailer [50394,50411]
trailer [50450,50467]
===
match
---
simple_stmt [95800,95841]
simple_stmt [95856,95897]
===
match
---
operator: , [29694,29695]
operator: , [29750,29751]
===
match
---
atom_expr [29911,29941]
atom_expr [29967,29997]
===
match
---
name: flatten_results [30277,30292]
name: flatten_results [30333,30348]
===
match
---
operator: * [17319,17320]
operator: * [17319,17320]
===
match
---
atom_expr [66747,66777]
atom_expr [66803,66833]
===
match
---
operator: = [47958,47959]
operator: = [48014,48015]
===
match
---
trailer [91134,91154]
trailer [91190,91210]
===
match
---
name: fields [78640,78646]
name: fields [78696,78702]
===
match
---
arglist [7019,7069]
arglist [7019,7069]
===
match
---
tfpdef [38215,38255]
tfpdef [38271,38311]
===
match
---
name: impersonation_chain [13850,13869]
name: impersonation_chain [13850,13869]
===
match
---
subscriptlist [38937,38955]
subscriptlist [38993,39011]
===
match
---
atom_expr [39874,39888]
atom_expr [39930,39944]
===
match
---
operator: } [97227,97228]
operator: } [97283,97284]
===
match
---
name: sql [28885,28888]
name: sql [28941,28944]
===
match
---
name: sql [30023,30026]
name: sql [30079,30082]
===
match
---
trailer [55970,55997]
trailer [56026,56053]
===
match
---
trailer [67476,67629]
trailer [67532,67685]
===
match
---
operator: = [1952,1953]
operator: = [1952,1953]
===
match
---
name: self [7318,7322]
name: self [7318,7322]
===
match
---
trailer [97084,97091]
trailer [97140,97147]
===
match
---
fstring_string: _ [97213,97214]
fstring_string: _ [97269,97270]
===
match
---
name: project_id [64768,64778]
name: project_id [64824,64834]
===
match
---
operator: = [2717,2718]
operator: = [2717,2718]
===
match
---
name: self [94844,94848]
name: self [94900,94904]
===
match
---
name: log [41378,41381]
name: log [41434,41437]
===
match
---
string: 'google_cloud_default' [13056,13078]
string: 'google_cloud_default' [13056,13078]
===
match
---
operator: = [78223,78224]
operator: = [78279,78280]
===
match
---
operator: = [50306,50307]
operator: = [50362,50363]
===
match
---
name: gcp_conn_id [95522,95533]
name: gcp_conn_id [95578,95589]
===
match
---
operator: = [78189,78190]
operator: = [78245,78246]
===
match
---
name: field_delimiter [52526,52541]
name: field_delimiter [52582,52597]
===
match
---
name: project_id [60933,60943]
name: project_id [60989,60999]
===
match
---
name: str [90206,90209]
name: str [90262,90265]
===
match
---
param [9422,9438]
param [9422,9438]
===
match
---
name: job [98046,98049]
name: job [98102,98105]
===
match
---
trailer [39778,39793]
trailer [39834,39849]
===
match
---
atom_expr [18693,18709]
atom_expr [18693,18709]
===
match
---
operator: , [64213,64214]
operator: , [64269,64270]
===
match
---
atom_expr [64672,64696]
atom_expr [64728,64752]
===
match
---
name: gcp_conn_id [27658,27669]
name: gcp_conn_id [27714,27725]
===
match
---
name: gcp_conn_id [18274,18285]
name: gcp_conn_id [18274,18285]
===
match
---
string: 'NONE' [47885,47891]
string: 'NONE' [47941,47947]
===
match
---
name: table_id [17355,17363]
name: table_id [17355,17363]
===
match
---
operator: , [97516,97517]
operator: , [97572,97573]
===
match
---
operator: , [26821,26822]
operator: , [26821,26822]
===
match
---
name: Optional [81321,81329]
name: Optional [81377,81385]
===
match
---
name: Union [67064,67069]
name: Union [67120,67125]
===
match
---
trailer [2816,2824]
trailer [2816,2824]
===
match
---
trailer [98807,98816]
trailer [98863,98872]
===
match
---
name: Any [9434,9437]
name: Any [9434,9437]
===
match
---
name: str [47879,47882]
name: str [47935,47938]
===
match
---
operator: , [78078,78079]
operator: , [78134,78135]
===
match
---
trailer [47808,47813]
trailer [47864,47869]
===
match
---
name: maximum_bytes_billed [27898,27918]
name: maximum_bytes_billed [27954,27974]
===
match
---
name: operator [2193,2201]
name: operator [2193,2201]
===
match
---
atom_expr [3302,3315]
atom_expr [3302,3315]
===
match
---
operator: = [50922,50923]
operator: = [50978,50979]
===
match
---
name: self [97492,97496]
name: self [97548,97552]
===
match
---
name: gcs_hook [40562,40570]
name: gcs_hook [40618,40626]
===
match
---
atom_expr [26357,26390]
atom_expr [26357,26390]
===
match
---
name: source_format [47830,47843]
name: source_format [47886,47899]
===
match
---
name: ib [2541,2543]
name: ib [2541,2543]
===
match
---
trailer [18876,18885]
trailer [18876,18885]
===
match
---
trailer [26893,26895]
trailer [26893,26895]
===
match
---
name: fields [74976,74982]
name: fields [75032,75038]
===
match
---
name: fields [74988,74994]
name: fields [75044,75050]
===
match
---
name: self [61278,61282]
name: self [61334,61338]
===
match
---
name: Optional [26421,26429]
name: Optional [26421,26429]
===
match
---
name: Optional [74184,74192]
name: Optional [74240,74248]
===
match
---
name: sql [7167,7170]
name: sql [7167,7170]
===
match
---
name: self [29519,29523]
name: self [29575,29579]
===
match
---
name: encryption_configuration [39636,39660]
name: encryption_configuration [39692,39716]
===
match
---
operator: , [29930,29931]
operator: , [29986,29987]
===
match
---
trailer [28344,28349]
trailer [28400,28405]
===
match
---
tfpdef [26407,26435]
tfpdef [26407,26435]
===
match
---
name: labels [39531,39537]
name: labels [39587,39593]
===
match
---
simple_stmt [13688,13719]
simple_stmt [13688,13719]
===
match
---
suite [56038,56642]
suite [56094,56698]
===
match
---
name: ui_color [77639,77647]
name: ui_color [77695,77703]
===
match
---
name: allow_jagged_rows [49158,49175]
name: allow_jagged_rows [49214,49231]
===
match
---
operator: , [66809,66810]
operator: , [66865,66866]
===
match
---
name: providers [1539,1548]
name: providers [1539,1548]
===
match
---
atom_expr [64763,64778]
atom_expr [64819,64834]
===
match
---
param [70387,70396]
param [70443,70452]
===
match
---
operator: , [37858,37859]
operator: , [37914,37915]
===
match
---
fstring_start: f' [2603,2605]
fstring_start: f' [2603,2605]
===
match
---
trailer [40433,40445]
trailer [40489,40501]
===
match
---
operator: = [29622,29623]
operator: = [29678,29679]
===
match
---
name: execute [74670,74677]
name: execute [74726,74733]
===
match
---
simple_stmt [47156,47371]
simple_stmt [47212,47427]
===
match
---
name: labels [52878,52884]
name: labels [52934,52940]
===
match
---
name: src_fmt_configs [49193,49208]
name: src_fmt_configs [49249,49264]
===
match
---
name: dataset_id [86257,86267]
name: dataset_id [86313,86323]
===
match
---
atom_expr [26812,26837]
atom_expr [26812,26837]
===
match
---
atom_expr [52118,52137]
atom_expr [52174,52193]
===
match
---
name: str [38202,38205]
name: str [38258,38261]
===
match
---
name: table_id [51947,51955]
name: table_id [52003,52011]
===
match
---
simple_stmt [64331,64362]
simple_stmt [64387,64418]
===
match
---
operator: = [27747,27748]
operator: = [27803,27804]
===
match
---
name: Dict [73928,73932]
name: Dict [73984,73988]
===
match
---
trailer [56093,56307]
trailer [56149,56363]
===
match
---
simple_stmt [28340,28389]
simple_stmt [28396,28445]
===
match
---
expr_stmt [95375,95409]
expr_stmt [95431,95465]
===
match
---
simple_stmt [27768,27805]
simple_stmt [27824,27861]
===
match
---
trailer [17674,17694]
trailer [17674,17694]
===
match
---
operator: = [96987,96988]
operator: = [97043,97044]
===
match
---
name: schema_object [48749,48762]
name: schema_object [48805,48818]
===
match
---
name: self [52230,52234]
name: self [52286,52290]
===
match
---
name: str [74017,74020]
name: str [74073,74076]
===
match
---
name: write_disposition [29081,29098]
name: write_disposition [29137,29154]
===
match
---
atom_expr [61790,61804]
atom_expr [61846,61860]
===
match
---
operator: , [48938,48939]
operator: , [48994,48995]
===
match
---
suite [26879,28444]
suite [26879,28500]
===
match
---
name: Optional [38865,38873]
name: Optional [38921,38929]
===
match
---
testlist_comp [94613,94678]
testlist_comp [94669,94734]
===
match
---
name: BaseOperatorLink [2016,2032]
name: BaseOperatorLink [2016,2032]
===
match
---
param [64223,64232]
param [64279,64288]
===
match
---
trailer [39330,39359]
trailer [39386,39415]
===
match
---
name: str [12975,12978]
name: str [12975,12978]
===
match
---
atom_expr [61104,61120]
atom_expr [61160,61176]
===
match
---
classdef [31456,41619]
classdef [31512,41675]
===
match
---
param [38665,38693]
param [38721,38749]
===
match
---
operator: , [81260,81261]
operator: , [81316,81317]
===
match
---
trailer [95232,95252]
trailer [95288,95308]
===
match
---
operator: = [61047,61048]
operator: = [61103,61104]
===
match
---
name: BigQueryInsertJobOperator [91327,91352]
name: BigQueryInsertJobOperator [91383,91408]
===
match
---
name: encryption_configuration [38752,38776]
name: encryption_configuration [38808,38832]
===
match
---
name: allow_large_results [29116,29135]
name: allow_large_results [29172,29191]
===
match
---
name: self [57013,57017]
name: self [57069,57073]
===
match
---
simple_stmt [31514,37724]
simple_stmt [31570,37780]
===
match
---
trailer [97641,97655]
trailer [97697,97711]
===
match
---
trailer [18799,18809]
trailer [18799,18809]
===
match
---
tfpdef [47830,47848]
tfpdef [47886,47904]
===
match
---
expr_stmt [12658,12804]
expr_stmt [12658,12804]
===
match
---
operator: , [85017,85018]
operator: , [85073,85074]
===
match
---
atom_expr [12820,12848]
atom_expr [12820,12848]
===
match
---
operator: = [48703,48704]
operator: = [48759,48760]
===
match
---
trailer [38239,38255]
trailer [38295,38311]
===
match
---
expr_stmt [2170,2223]
expr_stmt [2170,2223]
===
match
---
name: Optional [38379,38387]
name: Optional [38435,38443]
===
match
---
simple_stmt [70760,70791]
simple_stmt [70816,70847]
===
match
---
trailer [96713,96770]
trailer [96769,96826]
===
match
---
param [81179,81218]
param [81235,81274]
===
match
---
name: dataset_id [40832,40842]
name: dataset_id [40888,40898]
===
match
---
atom_expr [74048,74061]
atom_expr [74104,74117]
===
match
---
trailer [64298,64309]
trailer [64354,64365]
===
match
---
name: Dict [94873,94877]
name: Dict [94929,94933]
===
match
---
operator: = [27670,27671]
operator: = [27726,27727]
===
match
---
name: self [51548,51552]
name: self [51604,51608]
===
match
---
operator: = [40549,40550]
operator: = [40605,40606]
===
match
---
tfpdef [47973,47993]
tfpdef [48029,48049]
===
match
---
operator: , [69954,69955]
operator: , [70010,70011]
===
match
---
name: impersonation_chain [78601,78620]
name: impersonation_chain [78657,78676]
===
match
---
operator: , [49068,49069]
operator: , [49124,49125]
===
match
---
trailer [55990,55995]
trailer [56046,56051]
===
match
---
name: job_id [98581,98587]
name: job_id [98637,98643]
===
match
---
parameters [89928,90375]
parameters [89984,90431]
===
match
---
name: kwargs_passed [48792,48805]
name: kwargs_passed [48848,48861]
===
match
---
simple_stmt [91000,91282]
simple_stmt [91056,91338]
===
match
---
operator: , [38997,38998]
operator: , [39053,39054]
===
match
---
trailer [97279,97283]
trailer [97335,97339]
===
match
---
name: self [95517,95521]
name: self [95573,95577]
===
match
---
trailer [61975,61980]
trailer [62031,62036]
===
match
---
tfpdef [81091,81118]
tfpdef [81147,81174]
===
match
---
trailer [18168,18180]
trailer [18168,18180]
===
match
---
atom [80922,80994]
atom [80978,81050]
===
match
---
operator: , [59859,59860]
operator: , [59915,59916]
===
match
---
name: BigQueryUpdateTableOperator [71287,71314]
name: BigQueryUpdateTableOperator [71343,71370]
===
match
---
simple_stmt [70711,70752]
simple_stmt [70767,70808]
===
match
---
trailer [85223,85232]
trailer [85279,85288]
===
match
---
trailer [52159,52181]
trailer [52215,52237]
===
match
---
operator: , [13078,13079]
operator: , [13078,13079]
===
match
---
atom [6483,6492]
atom [6483,6492]
===
match
---
operator: , [81169,81170]
operator: , [81225,81226]
===
match
---
trailer [81910,81922]
trailer [81966,81978]
===
match
---
tfpdef [70220,70236]
tfpdef [70276,70292]
===
match
---
name: ui_color [73820,73828]
name: ui_color [73876,73884]
===
match
---
argument [52754,52794]
argument [52810,52850]
===
match
---
operator: = [70930,70931]
operator: = [70986,70987]
===
match
---
simple_stmt [39438,39518]
simple_stmt [39494,39574]
===
match
---
name: location [82309,82317]
name: location [82365,82373]
===
match
---
simple_stmt [2303,2380]
simple_stmt [2303,2380]
===
match
---
param [25389,25393]
param [25389,25393]
===
match
---
operator: = [7330,7331]
operator: = [7330,7331]
===
match
---
param [78432,78437]
param [78488,78493]
===
match
---
tfpdef [6856,6878]
tfpdef [6856,6878]
===
match
---
tfpdef [9529,9560]
tfpdef [9529,9560]
===
match
---
simple_stmt [6928,6964]
simple_stmt [6928,6964]
===
match
---
name: fields [77775,77781]
name: fields [77831,77837]
===
match
---
name: self [3349,3353]
name: self [3349,3353]
===
match
---
operator: , [1004,1005]
operator: , [1004,1005]
===
match
---
trailer [28492,28497]
trailer [28548,28553]
===
match
---
operator: ** [67403,67405]
operator: ** [67459,67461]
===
match
---
trailer [67257,67269]
trailer [67313,67325]
===
match
---
atom_expr [3215,3231]
atom_expr [3215,3231]
===
match
---
operator: , [38157,38158]
operator: , [38213,38214]
===
match
---
name: state [98481,98486]
name: state [98537,98542]
===
match
---
arglist [19048,19085]
arglist [19048,19085]
===
match
---
name: str [66876,66879]
name: str [66932,66935]
===
match
---
name: udf_config [30330,30340]
name: udf_config [30386,30396]
===
match
---
name: table [40736,40741]
name: table [40792,40797]
===
match
---
arglist [2799,2838]
arglist [2799,2838]
===
match
---
operator: , [27336,27337]
operator: , [27366,27367]
===
match
---
name: Any [77761,77764]
name: Any [77817,77820]
===
match
---
fstring_start: f" [98342,98344]
fstring_start: f" [98398,98400]
===
match
---
name: self [86268,86272]
name: self [86324,86328]
===
match
---
suite [3083,3417]
suite [3083,3417]
===
match
---
expr_stmt [89805,89866]
expr_stmt [89861,89922]
===
match
---
name: BigQueryHook [90825,90837]
name: BigQueryHook [90881,90893]
===
match
---
name: warnings [60598,60606]
name: warnings [60654,60662]
===
match
---
trailer [95076,95086]
trailer [95132,95142]
===
match
---
operator: , [38940,38941]
operator: , [38996,38997]
===
match
---
tfpdef [25851,25886]
tfpdef [25851,25886]
===
match
---
operator: , [9519,9520]
operator: , [9519,9520]
===
match
---
operator: = [38256,38257]
operator: = [38312,38313]
===
match
---
atom_expr [64907,64928]
atom_expr [64963,64984]
===
match
---
name: tolerance [9848,9857]
name: tolerance [9848,9857]
===
match
---
atom_expr [91217,91230]
atom_expr [91273,91286]
===
match
---
tfpdef [81351,81407]
tfpdef [81407,81463]
===
match
---
name: operator [2808,2816]
name: operator [2808,2816]
===
match
---
trailer [85569,85580]
trailer [85625,85636]
===
match
---
name: labels [13914,13920]
name: labels [13914,13920]
===
match
---
tfpdef [81179,81210]
tfpdef [81235,81266]
===
match
---
expr_stmt [89871,89910]
expr_stmt [89927,89966]
===
match
---
operator: , [2663,2664]
operator: , [2663,2664]
===
match
---
name: impersonation_chain [97497,97516]
name: impersonation_chain [97553,97572]
===
match
---
operator: = [95612,95613]
operator: = [95668,95669]
===
match
---
operator: = [48123,48124]
operator: = [48179,48180]
===
match
---
name: gcp_conn_id [9999,10010]
name: gcp_conn_id [9999,10010]
===
match
---
trailer [75061,75070]
trailer [75117,75126]
===
match
---
operator: ** [85233,85235]
operator: ** [85289,85291]
===
match
---
param [81091,81119]
param [81147,81175]
===
match
---
name: gcp_conn_id [13037,13048]
name: gcp_conn_id [13037,13048]
===
match
---
name: delegate_to [39418,39429]
name: delegate_to [39474,39485]
===
match
---
trailer [39635,39660]
trailer [39691,39716]
===
match
---
simple_stmt [27813,27862]
simple_stmt [27869,27918]
===
match
---
name: self [10156,10160]
name: self [10156,10160]
===
match
---
classdef [3419,7339]
classdef [3419,7339]
===
match
---
trailer [64469,64471]
trailer [64525,64527]
===
match
---
trailer [41161,41179]
trailer [41217,41235]
===
match
---
arglist [91048,91271]
arglist [91104,91327]
===
match
---
atom_expr [95480,95495]
atom_expr [95536,95551]
===
match
---
simple_stmt [97619,97656]
simple_stmt [97675,97712]
===
match
---
atom_expr [50138,50158]
atom_expr [50194,50214]
===
match
---
subscriptlist [81387,81405]
subscriptlist [81443,81461]
===
match
---
expr_stmt [55494,55594]
expr_stmt [55550,55650]
===
match
---
name: self [51326,51330]
name: self [51382,51386]
===
match
---
name: Union [64180,64185]
name: Union [64236,64241]
===
match
---
name: self [51272,51276]
name: self [51328,51332]
===
match
---
argument [78405,78413]
argument [78461,78469]
===
match
---
name: Optional [64026,64034]
name: Optional [64082,64090]
===
match
---
atom_expr [81906,81922]
atom_expr [81962,81978]
===
match
---
atom_expr [26803,26838]
atom_expr [26803,26838]
===
match
---
simple_stmt [78206,78237]
simple_stmt [78262,78293]
===
match
---
atom_expr [66910,66923]
atom_expr [66966,66979]
===
match
---
string: """     Fetches the data from a BigQuery table (alternatively fetch data for selected columns)     and returns data in a python list. The number of elements in the returned list will     be equal to the number of rows fetched. Each element in the list will again be a list     where element would represent the columns values for that row.      **Example Result**: ``[['Tony', '10'], ['Mike', '20'], ['Steve', '15']]``      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryGetDataOperator`      .. note::         If you pass fields to ``selected_fields`` which are in different order than the         order of columns already in         BQ table, the data will still be in the order of BQ table.         For example if the BQ table has 3 columns as         ``[A,B,C]`` and you pass 'B,A' in the ``selected_fields``         the data would still be of the form ``'A,B'``.      **Example**: ::          get_data = BigQueryGetDataOperator(             task_id='get_data_from_bq',             dataset_id='test_dataset',             table_id='Transaction_partitions',             max_results=100,             selected_fields='DATE',             gcp_conn_id='airflow-conn-id'         )      :param dataset_id: The dataset ID of the requested table. (templated)     :type dataset_id: str     :param table_id: The table ID of the requested table. (templated)     :type table_id: str     :param max_results: The maximum number of records (rows) to be fetched         from the table. (templated)     :type max_results: int     :param selected_fields: List of fields to return (comma-separated). If         unspecified, all fields are returned.     :type selected_fields: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param location: The location used for the operation.     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [13972,17079]
string: """     Fetches the data from a BigQuery table (alternatively fetch data for selected columns)     and returns data in a python list. The number of elements in the returned list will     be equal to the number of rows fetched. Each element in the list will again be a list     where element would represent the columns values for that row.      **Example Result**: ``[['Tony', '10'], ['Mike', '20'], ['Steve', '15']]``      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryGetDataOperator`      .. note::         If you pass fields to ``selected_fields`` which are in different order than the         order of columns already in         BQ table, the data will still be in the order of BQ table.         For example if the BQ table has 3 columns as         ``[A,B,C]`` and you pass 'B,A' in the ``selected_fields``         the data would still be of the form ``'A,B'``.      **Example**: ::          get_data = BigQueryGetDataOperator(             task_id='get_data_from_bq',             dataset_id='test_dataset',             table_id='Transaction_partitions',             max_results=100,             selected_fields='DATE',             gcp_conn_id='airflow-conn-id'         )      :param dataset_id: The dataset ID of the requested table. (templated)     :type dataset_id: str     :param table_id: The table ID of the requested table. (templated)     :type table_id: str     :param max_results: The maximum number of records (rows) to be fetched         from the table. (templated)     :type max_results: int     :param selected_fields: List of fields to return (comma-separated). If         unspecified, all fields are returned.     :type selected_fields: str     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param location: The location used for the operation.     :type location: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [13972,17079]
===
match
---
param [66805,66810]
param [66861,66866]
===
match
---
name: exec_date [97230,97239]
name: exec_date [97286,97295]
===
match
---
name: __init__ [38124,38132]
name: __init__ [38180,38188]
===
match
---
trailer [52438,52450]
trailer [52494,52506]
===
match
---
operator: , [25725,25726]
operator: , [25725,25726]
===
match
---
import_from [1133,1181]
import_from [1133,1181]
===
match
---
trailer [29795,29810]
trailer [29851,29866]
===
match
---
operator: , [2143,2144]
operator: , [2143,2144]
===
match
---
atom_expr [97135,97172]
atom_expr [97191,97228]
===
match
---
name: ignore_if_missing [81270,81287]
name: ignore_if_missing [81326,81343]
===
match
---
argument [91244,91270]
argument [91300,91326]
===
match
---
argument [30614,30632]
argument [30670,30688]
===
match
---
operator: , [64862,64863]
operator: , [64918,64919]
===
match
---
name: maximum_billing_tier [30388,30408]
name: maximum_billing_tier [30444,30464]
===
match
---
tfpdef [94939,94962]
tfpdef [94995,95018]
===
match
---
name: str [66842,66845]
name: str [66898,66901]
===
match
---
or_test [78649,78698]
or_test [78705,78754]
===
match
---
operator: , [94848,94849]
operator: , [94904,94905]
===
match
---
tfpdef [55693,55708]
tfpdef [55749,55764]
===
match
---
trailer [50927,50939]
trailer [50983,50995]
===
match
---
param [31288,31292]
param [31344,31348]
===
match
---
expr_stmt [85602,85638]
expr_stmt [85658,85694]
===
match
---
operator: , [30106,30107]
operator: , [30162,30163]
===
match
---
param [74287,74296]
param [74343,74352]
===
match
---
suite [51568,51656]
suite [51624,51712]
===
match
---
suite [49723,49825]
suite [49779,49881]
===
match
---
trailer [40889,40898]
trailer [40945,40954]
===
match
---
operator: = [26035,26036]
operator: = [26035,26036]
===
match
---
operator: { [37974,37975]
operator: { [38030,38031]
===
match
---
string: 'dataset_id' [84599,84611]
string: 'dataset_id' [84655,84667]
===
match
---
operator: = [64040,64041]
operator: = [64096,64097]
===
match
---
simple_stmt [64989,66626]
simple_stmt [65045,66682]
===
match
---
name: gcp_conn_id [13747,13758]
name: gcp_conn_id [13747,13758]
===
match
---
argument [3203,3231]
argument [3203,3231]
===
match
---
operator: , [85100,85101]
operator: , [85156,85157]
===
match
---
name: self [27551,27555]
name: self [27607,27611]
===
match
---
simple_stmt [12658,12805]
simple_stmt [12658,12805]
===
match
---
name: google_cloud_storage_conn_id [39331,39359]
name: google_cloud_storage_conn_id [39387,39415]
===
match
---
string: 'execution_date' [97143,97159]
string: 'execution_date' [97199,97215]
===
match
---
name: Optional [73960,73968]
name: Optional [74016,74024]
===
match
---
trailer [40770,41360]
trailer [40826,41416]
===
match
---
operator: , [41303,41304]
operator: , [41359,41360]
===
match
---
trailer [67548,67560]
trailer [67604,67616]
===
match
---
name: value [47468,47473]
name: value [47524,47529]
===
match
---
name: dataset_id [64262,64272]
name: dataset_id [64318,64328]
===
match
---
operator: , [25298,25299]
operator: , [25298,25299]
===
match
---
atom_expr [85954,85969]
atom_expr [86010,86025]
===
match
---
trailer [28527,28532]
trailer [28583,28588]
===
match
---
name: impersonation_chain [18371,18390]
name: impersonation_chain [18371,18390]
===
match
---
tfpdef [77775,77802]
tfpdef [77831,77858]
===
match
---
atom_expr [81010,81038]
atom_expr [81066,81094]
===
match
---
atom_expr [90393,90419]
atom_expr [90449,90475]
===
match
---
atom_expr [30325,30340]
atom_expr [30381,30396]
===
match
---
name: BigQueryCreateExternalTableOperator [41674,41709]
name: BigQueryCreateExternalTableOperator [41730,41765]
===
match
---
string: 'job_id' [2285,2293]
string: 'job_id' [2285,2293]
===
match
---
operator: , [13450,13451]
operator: , [13450,13451]
===
match
---
argument [26905,26913]
argument [26905,26913]
===
match
---
atom_expr [31429,31453]
atom_expr [31485,31509]
===
match
---
operator: , [48186,48187]
operator: , [48242,48243]
===
match
---
trailer [78032,78052]
trailer [78088,78108]
===
match
---
trailer [7018,7070]
trailer [7018,7070]
===
match
---
operator: = [97546,97547]
operator: = [97602,97603]
===
match
---
simple_stmt [60952,60977]
simple_stmt [61008,61033]
===
match
---
trailer [2788,2798]
trailer [2788,2798]
===
match
---
operator: = [55998,55999]
operator: = [56054,56055]
===
match
---
tfpdef [26491,26504]
tfpdef [26491,26504]
===
match
---
name: DeprecationWarning [60762,60780]
name: DeprecationWarning [60818,60836]
===
match
---
trailer [67144,67155]
trailer [67200,67211]
===
match
---
name: job_ids [2855,2862]
name: job_ids [2855,2862]
===
match
---
name: project_id [90595,90605]
name: project_id [90651,90661]
===
match
---
atom_expr [26602,26616]
atom_expr [26602,26616]
===
match
---
trailer [67335,67355]
trailer [67391,67411]
===
match
---
name: Optional [6804,6812]
name: Optional [6804,6812]
===
match
---
name: BigQueryUIColors [6508,6524]
name: BigQueryUIColors [6508,6524]
===
match
---
trailer [74650,74660]
trailer [74706,74716]
===
match
---
name: table_resource [74928,74942]
name: table_resource [74984,74998]
===
match
---
string: """     This operator is used to create new dataset for your Project in BigQuery.     https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets#resource      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryCreateEmptyDatasetOperator`      :param project_id: The name of the project where we want to create the dataset.     :type project_id: str     :param dataset_id: The id of dataset. Don't need to provide, if datasetId in dataset_reference.     :type dataset_id: str     :param location: The geographic location where the dataset should reside.     :type location: str     :param dataset_reference: Dataset reference that could be provided with request body.         More info:         https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets#resource     :type dataset_reference: dict     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     :param exists_ok: If ``True``, ignore "already exists" errors when creating the dataset.     :type exists_ok: bool         **Example**: ::              create_new_dataset = BigQueryCreateEmptyDatasetOperator(                 dataset_id='new-dataset',                 project_id='my-project',                 dataset_reference={"friendlyName": "New Dataset"}                 gcp_conn_id='_my_gcp_conn_',                 task_id='newDatasetCreator',                 dag=dag)     """ [57167,59813]
string: """     This operator is used to create new dataset for your Project in BigQuery.     https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets#resource      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:BigQueryCreateEmptyDatasetOperator`      :param project_id: The name of the project where we want to create the dataset.     :type project_id: str     :param dataset_id: The id of dataset. Don't need to provide, if datasetId in dataset_reference.     :type dataset_id: str     :param location: The geographic location where the dataset should reside.     :type location: str     :param dataset_reference: Dataset reference that could be provided with request body.         More info:         https://cloud.google.com/bigquery/docs/reference/rest/v2/datasets#resource     :type dataset_reference: dict     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     :param exists_ok: If ``True``, ignore "already exists" errors when creating the dataset.     :type exists_ok: bool         **Example**: ::              create_new_dataset = BigQueryCreateEmptyDatasetOperator(                 dataset_id='new-dataset',                 project_id='my-project',                 dataset_reference={"friendlyName": "New Dataset"}                 gcp_conn_id='_my_gcp_conn_',                 task_id='newDatasetCreator',                 dag=dag)     """ [57223,59869]
===
match
---
name: self [74540,74544]
name: self [74596,74600]
===
match
---
operator: = [90717,90718]
operator: = [90773,90774]
===
match
---
name: str [60404,60407]
name: str [60460,60463]
===
match
---
operator: , [30476,30477]
operator: , [30532,30533]
===
match
---
param [12921,12946]
param [12921,12946]
===
match
---
trailer [78144,78155]
trailer [78200,78211]
===
match
---
name: self [2659,2663]
name: self [2659,2663]
===
match
---
name: self [70711,70715]
name: self [70767,70771]
===
match
---
operator: = [90593,90594]
operator: = [90649,90650]
===
match
---
name: self [39438,39442]
name: self [39494,39498]
===
match
---
trailer [71066,71086]
trailer [71122,71142]
===
match
---
name: delete_contents [55760,55775]
name: delete_contents [55816,55831]
===
match
---
operator: , [60141,60142]
operator: , [60197,60198]
===
match
---
name: self [10072,10076]
name: self [10072,10076]
===
match
---
trailer [91014,91034]
trailer [91070,91090]
===
match
---
trailer [97219,97227]
trailer [97275,97283]
===
match
---
atom_expr [85647,85662]
atom_expr [85703,85718]
===
match
---
name: info [85900,85904]
name: info [85956,85960]
===
match
---
operator: , [94887,94888]
operator: , [94943,94944]
===
match
---
operator: -> [39023,39025]
operator: -> [39079,39081]
===
match
---
trailer [29481,29494]
trailer [29537,29550]
===
match
---
arglist [61897,61919]
arglist [61953,61975]
===
match
---
tfpdef [13213,13269]
tfpdef [13213,13269]
===
match
---
trailer [64471,64480]
trailer [64527,64536]
===
match
---
import_name [887,901]
import_name [887,901]
===
match
---
name: warn [49353,49357]
name: warn [49409,49413]
===
match
---
name: Union [74244,74249]
name: Union [74300,74305]
===
match
---
name: self [18872,18876]
name: self [18872,18876]
===
match
---
trailer [26904,26914]
trailer [26904,26914]
===
match
---
name: str [55991,55994]
name: str [56047,56050]
===
match
---
operator: = [13672,13673]
operator: = [13672,13673]
===
match
---
trailer [26256,26263]
trailer [26256,26263]
===
match
---
operator: , [49140,49141]
operator: , [49196,49197]
===
match
---
operator: { [89833,89834]
operator: { [89889,89890]
===
match
---
name: impersonation_chain [56586,56605]
name: impersonation_chain [56642,56661]
===
match
---
trailer [52654,52670]
trailer [52710,52726]
===
match
---
operator: = [29569,29570]
operator: = [29625,29626]
===
match
---
operator: = [2829,2830]
operator: = [2829,2830]
===
match
---
trailer [64914,64926]
trailer [64970,64982]
===
match
---
operator: = [50206,50207]
operator: = [50262,50263]
===
match
---
operator: , [25154,25155]
operator: , [25154,25155]
===
match
---
operator: , [49632,49633]
operator: , [49688,49689]
===
match
---
name: get_job [97796,97803]
name: get_job [97852,97859]
===
match
---
string: 'selected_fields' [17178,17195]
string: 'selected_fields' [17178,17195]
===
match
---
trailer [27931,27953]
trailer [27987,28009]
===
match
---
atom_expr [27207,27347]
atom_expr [27237,27403]
===
match
---
fstring_expr [97200,97213]
fstring_expr [97256,97269]
===
match
---
name: impersonation_chain [70804,70823]
name: impersonation_chain [70860,70879]
===
match
---
atom_expr [40744,41360]
atom_expr [40800,41416]
===
match
---
name: self [30676,30680]
name: self [30732,30736]
===
match
---
tfpdef [74038,74061]
tfpdef [74094,74117]
===
match
---
operator: ** [70387,70389]
operator: ** [70443,70445]
===
match
---
operator: , [89942,89943]
operator: , [89998,89999]
===
match
---
argument [2203,2222]
argument [2203,2222]
===
match
---
simple_stmt [51483,51518]
simple_stmt [51539,51574]
===
match
---
name: schema_fields_updates [91075,91096]
name: schema_fields_updates [91131,91152]
===
match
---
operator: , [64189,64190]
operator: , [64245,64246]
===
match
---
name: location [3293,3301]
name: location [3293,3301]
===
match
---
atom_expr [2967,2986]
atom_expr [2967,2986]
===
match
---
name: self [47558,47562]
name: self [47614,47618]
===
match
---
trailer [95379,95393]
trailer [95435,95449]
===
match
---
name: self [82125,82129]
name: self [82181,82185]
===
match
---
operator: , [81390,81391]
operator: , [81446,81447]
===
match
---
simple_stmt [39113,39142]
simple_stmt [39169,39198]
===
match
---
operator: , [91194,91195]
operator: , [91250,91251]
===
match
---
if_stmt [49309,49678]
if_stmt [49365,49734]
===
match
---
name: location [61740,61748]
name: location [61796,61804]
===
match
---
operator: = [74473,74474]
operator: = [74529,74530]
===
match
---
name: gcp_conn_id [81766,81777]
name: gcp_conn_id [81822,81833]
===
match
---
name: Optional [26248,26256]
name: Optional [26248,26256]
===
match
---
param [70898,70903]
param [70954,70959]
===
match
---
operator: , [17720,17721]
operator: , [17720,17721]
===
match
---
atom_expr [27768,27787]
atom_expr [27824,27843]
===
match
---
name: self [81906,81910]
name: self [81962,81966]
===
match
---
atom_expr [90955,90979]
atom_expr [91011,91035]
===
match
---
name: job_ids [2967,2974]
name: job_ids [2967,2974]
===
match
---
operator: , [55931,55932]
operator: , [55987,55988]
===
match
---
tfpdef [77997,78053]
tfpdef [78053,78109]
===
match
---
name: info [31384,31388]
name: info [31440,31444]
===
match
---
name: Sequence [90328,90336]
name: Sequence [90384,90392]
===
match
---
name: project_id [61610,61620]
name: project_id [61666,61676]
===
match
---
atom_expr [70854,70880]
atom_expr [70910,70936]
===
match
---
arglist [41404,41490]
arglist [41460,41546]
===
match
---
atom_expr [2263,2279]
atom_expr [2263,2279]
===
match
---
expr_stmt [85723,85753]
expr_stmt [85779,85809]
===
match
---
name: self [41604,41608]
name: self [41660,41664]
===
match
---
simple_stmt [85723,85754]
simple_stmt [85779,85810]
===
match
---
name: self [39183,39187]
name: self [39239,39243]
===
match
---
atom_expr [3177,3416]
atom_expr [3177,3416]
===
match
---
trailer [91259,91270]
trailer [91315,91326]
===
match
---
name: Dict [89991,89995]
name: Dict [90047,90051]
===
match
---
argument [29232,29258]
argument [29288,29314]
===
match
---
expr_stmt [2714,2767]
expr_stmt [2714,2767]
===
match
---
param [90069,90102]
param [90125,90158]
===
match
---
expr_stmt [40631,40665]
expr_stmt [40687,40721]
===
match
---
name: hook [31345,31349]
name: hook [31401,31405]
===
match
---
fstring_expr [97241,97260]
fstring_expr [97297,97316]
===
match
---
atom_expr [38596,38609]
atom_expr [38652,38665]
===
match
---
name: __init__ [64472,64480]
name: __init__ [64528,64536]
===
match
---
trailer [97404,97416]
trailer [97460,97472]
===
match
---
operator: = [56332,56333]
operator: = [56388,56389]
===
match
---
trailer [61108,61120]
trailer [61164,61176]
===
match
---
operator: , [48554,48555]
operator: , [48610,48611]
===
match
---
expr_stmt [27768,27804]
expr_stmt [27824,27860]
===
match
---
simple_stmt [48792,49300]
simple_stmt [48848,49356]
===
match
---
atom [50594,50596]
atom [50650,50652]
===
match
---
atom_expr [28519,28559]
atom_expr [28575,28615]
===
match
---
operator: = [52299,52300]
operator: = [52355,52356]
===
match
---
operator: } [77633,77634]
operator: } [77689,77690]
===
match
---
tfpdef [9727,9749]
tfpdef [9727,9749]
===
match
---
simple_stmt [95755,95792]
simple_stmt [95811,95848]
===
match
---
name: gcp_conn_id [74120,74131]
name: gcp_conn_id [74176,74187]
===
match
---
name: self [52772,52776]
name: self [52828,52832]
===
match
---
operator: , [47363,47364]
operator: , [47419,47420]
===
match
---
trailer [9683,9710]
trailer [9683,9710]
===
match
---
name: Dict [48429,48433]
name: Dict [48485,48489]
===
match
---
operator: , [70111,70112]
operator: , [70167,70168]
===
match
---
expr_stmt [98537,98561]
expr_stmt [98593,98617]
===
match
---
trailer [28144,28165]
trailer [28200,28221]
===
match
---
simple_stmt [1133,1182]
simple_stmt [1133,1182]
===
match
---
name: str [26501,26504]
name: str [26501,26504]
===
match
---
strings [60629,60744]
strings [60685,60800]
===
match
---
operator: = [74841,74842]
operator: = [74897,74898]
===
match
---
name: impersonation_chain [56901,56920]
name: impersonation_chain [56957,56976]
===
match
---
simple_stmt [17745,17772]
simple_stmt [17745,17772]
===
match
---
trailer [13771,13786]
trailer [13771,13786]
===
match
---
name: BigQueryUpdateDatasetOperator [75130,75159]
name: BigQueryUpdateDatasetOperator [75186,75215]
===
match
---
name: Sequence [78038,78046]
name: Sequence [78094,78102]
===
match
---
name: encryption_configuration [30954,30978]
name: encryption_configuration [31010,31034]
===
match
---
name: project [51905,51912]
name: project [51961,51968]
===
match
---
name: dataset [78926,78933]
name: dataset [78982,78989]
===
match
---
param [90193,90235]
param [90249,90291]
===
match
---
name: include_policy_tags [90016,90035]
name: include_policy_tags [90072,90091]
===
match
---
trailer [64554,64707]
trailer [64610,64763]
===
match
---
name: kwargs [90766,90772]
name: kwargs [90822,90828]
===
match
---
trailer [39403,39415]
trailer [39459,39471]
===
match
---
number: 3 [9984,9985]
number: 3 [9984,9985]
===
match
---
operator: , [55672,55673]
operator: , [55728,55729]
===
match
---
name: models [1302,1308]
name: models [1302,1308]
===
match
---
name: self [52828,52832]
name: self [52884,52888]
===
match
---
trailer [26610,26616]
trailer [26610,26616]
===
match
---
expr_stmt [74579,74625]
expr_stmt [74635,74681]
===
match
---
atom_expr [40843,40858]
atom_expr [40899,40914]
===
match
---
simple_stmt [13900,13921]
simple_stmt [13900,13921]
===
match
---
atom_expr [38819,38832]
atom_expr [38875,38888]
===
match
---
name: priority [30724,30732]
name: priority [30780,30788]
===
match
---
name: CHECK [9340,9345]
name: CHECK [9340,9345]
===
match
---
fstring_end: " [31197,31198]
fstring_end: " [31253,31254]
===
match
---
trailer [18098,18109]
trailer [18098,18109]
===
match
---
name: self [81867,81871]
name: self [81923,81927]
===
match
---
name: kwargs [78072,78078]
name: kwargs [78128,78134]
===
match
---
name: task_id [2272,2279]
name: task_id [2272,2279]
===
match
---
simple_stmt [95634,95692]
simple_stmt [95690,95748]
===
match
---
trailer [61028,61046]
trailer [61084,61102]
===
match
---
name: _submit_job [97630,97641]
name: _submit_job [97686,97697]
===
match
---
name: dataset_id [56743,56753]
name: dataset_id [56799,56809]
===
match
---
atom_expr [96857,96874]
atom_expr [96913,96930]
===
match
---
operator: = [78358,78359]
operator: = [78414,78415]
===
match
---
trailer [64261,64272]
trailer [64317,64328]
===
match
---
atom [37747,37941]
atom [37803,37997]
===
match
---
name: file [96129,96133]
name: file [96185,96189]
===
match
---
argument [81726,81738]
argument [81782,81794]
===
match
---
parameters [96622,96640]
parameters [96678,96696]
===
match
---
trailer [61576,61819]
trailer [61632,61875]
===
match
---
operator: = [94702,94703]
operator: = [94758,94759]
===
match
---
expr_stmt [39150,39174]
expr_stmt [39206,39230]
===
match
---
name: dataset_reference [61029,61046]
name: dataset_reference [61085,61102]
===
match
---
operator: , [57056,57057]
operator: , [57112,57113]
===
match
---
string: 'WRITE_EMPTY' [25828,25841]
string: 'WRITE_EMPTY' [25828,25841]
===
match
---
expr_stmt [90815,90990]
expr_stmt [90871,91046]
===
match
---
tfpdef [38459,38480]
tfpdef [38515,38536]
===
match
---
trailer [40751,40770]
trailer [40807,40826]
===
match
---
name: dataset_id [85959,85969]
name: dataset_id [86015,86025]
===
match
---
simple_stmt [27498,27543]
simple_stmt [27554,27599]
===
match
---
trailer [51427,51434]
trailer [51483,51490]
===
match
---
atom [73654,73756]
atom [73710,73812]
===
match
---
trailer [3031,3038]
trailer [3031,3038]
===
match
---
trailer [95345,95347]
trailer [95401,95403]
===
match
---
name: SQLIntervalCheckOperator [10292,10316]
name: SQLIntervalCheckOperator [10292,10316]
===
match
---
funcdef [28449,31271]
funcdef [28505,31327]
===
match
---
simple_stmt [90747,90774]
simple_stmt [90803,90830]
===
match
---
name: dataset_id [67686,67696]
name: dataset_id [67742,67752]
===
match
---
name: job_id [96441,96447]
name: job_id [96497,96503]
===
match
---
trailer [90909,90921]
trailer [90965,90977]
===
match
---
operator: = [64579,64580]
operator: = [64635,64636]
===
match
---
operator: = [98752,98753]
operator: = [98808,98809]
===
match
---
atom_expr [56791,56956]
atom_expr [56847,57012]
===
match
---
param [60498,60522]
param [60554,60578]
===
match
---
name: Union [81381,81386]
name: Union [81437,81442]
===
match
---
operator: , [1418,1419]
operator: , [1418,1419]
===
match
---
name: self [90614,90618]
name: self [90670,90674]
===
match
---
param [9447,9469]
param [9447,9469]
===
match
---
name: str [26832,26835]
name: str [26832,26835]
===
match
---
operator: = [26766,26767]
operator: = [26766,26767]
===
match
---
operator: , [74808,74809]
operator: , [74864,74865]
===
match
---
operator: = [60482,60483]
operator: = [60538,60539]
===
match
---
name: str [70199,70202]
name: str [70255,70258]
===
match
---
expr_stmt [2523,2545]
expr_stmt [2523,2545]
===
match
---
arglist [90851,90980]
arglist [90907,91036]
===
match
---
operator: , [55587,55588]
operator: , [55643,55644]
===
match
---
name: udf_config [27749,27759]
name: udf_config [27805,27815]
===
match
---
operator: , [60099,60100]
operator: , [60155,60156]
===
match
---
name: Optional [66910,66918]
name: Optional [66966,66974]
===
match
---
atom_expr [51849,51868]
atom_expr [51905,51924]
===
match
---
trailer [13363,13365]
trailer [13363,13365]
===
match
---
operator: , [9756,9757]
operator: , [9756,9757]
===
match
---
arglist [64568,64697]
arglist [64624,64753]
===
match
---
trailer [74583,74603]
trailer [74639,74659]
===
match
---
name: dataset_id [75024,75034]
name: dataset_id [75080,75090]
===
match
---
atom_expr [95686,95691]
atom_expr [95742,95747]
===
match
---
if_stmt [6972,7114]
if_stmt [6972,7114]
===
match
---
argument [2254,2279]
argument [2254,2279]
===
match
---
name: context [82099,82106]
name: context [82155,82162]
===
match
---
tfpdef [66855,66880]
tfpdef [66911,66936]
===
match
---
trailer [70429,70434]
trailer [70485,70490]
===
match
---
name: self [75019,75023]
name: self [75075,75079]
===
match
---
operator: = [90420,90421]
operator: = [90476,90477]
===
match
---
operator: , [6407,6408]
operator: , [6407,6408]
===
match
---
return_stmt [2876,2887]
return_stmt [2876,2887]
===
match
---
trailer [13618,13623]
trailer [13618,13623]
===
match
---
name: delegate_to [70765,70776]
name: delegate_to [70821,70832]
===
match
---
trailer [84772,84778]
trailer [84828,84834]
===
match
---
atom_expr [50838,51044]
atom_expr [50894,51100]
===
match
---
name: kwargs [39059,39065]
name: kwargs [39115,39121]
===
match
---
atom_expr [61400,61416]
atom_expr [61456,61472]
===
match
---
arglist [17845,18027]
arglist [17845,18027]
===
match
---
funcdef [70074,70881]
funcdef [70130,70937]
===
match
---
operator: = [18311,18312]
operator: = [18311,18312]
===
match
---
argument [28984,29040]
argument [29040,29096]
===
match
---
name: BigQueryConsoleIndexableLink [2415,2443]
name: BigQueryConsoleIndexableLink [2415,2443]
===
match
---
operator: , [30632,30633]
operator: , [30688,30689]
===
match
---
if_stmt [81493,81797]
if_stmt [81549,81853]
===
match
---
operator: = [95534,95535]
operator: = [95590,95591]
===
match
---
operator: = [48082,48083]
operator: = [48138,48139]
===
match
---
trailer [31326,31328]
trailer [31382,31384]
===
match
---
operator: , [1026,1027]
operator: , [1026,1027]
===
match
---
funcdef [97314,98588]
funcdef [97370,98644]
===
match
---
trailer [61794,61804]
trailer [61850,61860]
===
match
---
atom_expr [82365,82389]
atom_expr [82421,82445]
===
match
---
name: str [26663,26666]
name: str [26663,26666]
===
match
---
name: dataset_reference [61049,61066]
name: dataset_reference [61105,61122]
===
match
---
operator: = [67777,67778]
operator: = [67833,67834]
===
match
---
atom_expr [64294,64309]
atom_expr [64350,64365]
===
match
---
name: str [60296,60299]
name: str [60352,60355]
===
match
---
trailer [70715,70732]
trailer [70771,70788]
===
match
---
operator: -> [31294,31296]
operator: -> [31350,31352]
===
match
---
expr_stmt [81945,81987]
expr_stmt [82001,82043]
===
match
---
operator: = [30026,30027]
operator: = [30082,30083]
===
match
---
name: project_id [84886,84896]
name: project_id [84942,84952]
===
match
---
name: value [70063,70068]
name: value [70119,70124]
===
match
---
name: BaseOperator [67843,67855]
name: BaseOperator [67899,67911]
===
match
---
expr_stmt [38034,38073]
expr_stmt [38090,38129]
===
match
---
atom_expr [41476,41490]
atom_expr [41532,41546]
===
match
---
atom_expr [26658,26667]
atom_expr [26658,26667]
===
match
---
name: BigQueryDeleteDatasetOperator [52980,53009]
name: BigQueryDeleteDatasetOperator [53036,53065]
===
match
---
simple_stmt [7318,7339]
simple_stmt [7318,7339]
===
match
---
operator: = [77604,77605]
operator: = [77660,77661]
===
match
---
name: self [71012,71016]
name: self [71068,71072]
===
match
---
trailer [95819,95833]
trailer [95875,95889]
===
match
---
trailer [13017,13022]
trailer [13017,13022]
===
match
---
operator: ** [64481,64483]
operator: ** [64537,64539]
===
match
---
name: str [17436,17439]
name: str [17436,17439]
===
match
---
operator: = [56376,56377]
operator: = [56432,56433]
===
match
---
trailer [28962,28966]
trailer [29018,29022]
===
match
---
name: impersonation_chain [86158,86177]
name: impersonation_chain [86214,86233]
===
match
---
name: str [38951,38954]
name: str [39007,39010]
===
match
---
trailer [78725,78740]
trailer [78781,78796]
===
match
---
name: self [85891,85895]
name: self [85947,85951]
===
match
---
name: self [89938,89942]
name: self [89994,89998]
===
match
---
name: gcp_conn_id [56486,56497]
name: gcp_conn_id [56542,56553]
===
match
---
trailer [86226,86243]
trailer [86282,86299]
===
match
---
name: gcs [1568,1571]
name: gcs [1568,1571]
===
match
---
simple_stmt [25276,25301]
simple_stmt [25276,25301]
===
match
---
string: 'impersonation_chain' [47342,47363]
string: 'impersonation_chain' [47398,47419]
===
match
---
argument [74928,74962]
argument [74984,75018]
===
match
---
string: "#A1BBFF" [1932,1941]
string: "#A1BBFF" [1932,1941]
===
match
---
trailer [13904,13911]
trailer [13904,13911]
===
match
---
arglist [64731,64795]
arglist [64787,64851]
===
match
---
operator: = [2173,2174]
operator: = [2173,2174]
===
match
---
name: use_legacy_sql [13772,13786]
name: use_legacy_sql [13772,13786]
===
match
---
expr_stmt [67331,67377]
expr_stmt [67387,67433]
===
match
---
name: encryption_configuration [28307,28331]
name: encryption_configuration [28363,28387]
===
match
---
atom_expr [51061,51079]
atom_expr [51117,51135]
===
match
---
operator: = [3393,3394]
operator: = [3393,3394]
===
match
---
trailer [39045,39047]
trailer [39101,39103]
===
match
---
trailer [90657,90669]
trailer [90713,90725]
===
match
---
expr_stmt [1946,1963]
expr_stmt [1946,1963]
===
match
---
name: str [55920,55923]
name: str [55976,55979]
===
match
---
subscriptlist [85146,85164]
subscriptlist [85202,85220]
===
match
---
operator: = [38793,38794]
operator: = [38849,38850]
===
match
---
name: create_disposition [26280,26298]
name: create_disposition [26280,26298]
===
match
---
operator: , [28888,28889]
operator: , [28944,28945]
===
match
---
tfpdef [74120,74136]
tfpdef [74176,74192]
===
match
---
name: Optional [67055,67063]
name: Optional [67111,67119]
===
match
---
operator: = [9160,9161]
operator: = [9160,9161]
===
match
---
operator: = [82278,82279]
operator: = [82334,82335]
===
match
---
operator: = [39603,39604]
operator: = [39659,39660]
===
match
---
arglist [97642,97654]
arglist [97698,97710]
===
match
---
testlist_comp [19110,19138]
testlist_comp [19110,19138]
===
match
---
trailer [29986,29991]
trailer [30042,30047]
===
match
---
trailer [81400,81405]
trailer [81456,81461]
===
match
---
name: self [50087,50091]
name: self [50143,50147]
===
match
---
expr_stmt [64257,64285]
expr_stmt [64313,64341]
===
match
---
argument [70871,70879]
argument [70927,70935]
===
match
---
string: 'sql1' [12726,12732]
string: 'sql1' [12726,12732]
===
match
---
operator: , [27103,27104]
operator: , [27103,27104]
===
match
---
name: impersonation_chain [48491,48510]
name: impersonation_chain [48547,48566]
===
match
---
trailer [95962,95987]
trailer [96018,96043]
===
match
---
simple_stmt [81906,81937]
simple_stmt [81962,81993]
===
match
---
argument [90764,90772]
argument [90820,90828]
===
match
---
atom_expr [13294,13308]
atom_expr [13294,13308]
===
match
---
name: kwargs [9871,9877]
name: kwargs [9871,9877]
===
match
---
atom_expr [51009,51033]
atom_expr [51065,51089]
===
match
---
name: gcp_conn_id [6607,6618]
name: gcp_conn_id [6607,6618]
===
match
---
fstring [96714,96769]
fstring [96770,96825]
===
match
---
trailer [40983,41001]
trailer [41039,41057]
===
match
---
string: '.sql' [25292,25298]
string: '.sql' [25292,25298]
===
match
---
name: self [50338,50342]
name: self [50394,50398]
===
match
---
trailer [60171,60176]
trailer [60227,60232]
===
match
---
name: gcp_conn_id [74475,74486]
name: gcp_conn_id [74531,74542]
===
match
---
name: DeprecationWarning [49614,49632]
name: DeprecationWarning [49670,49688]
===
match
---
name: schema_fields [40188,40201]
name: schema_fields [40244,40257]
===
match
---
atom_expr [95634,95654]
atom_expr [95690,95710]
===
match
---
name: project_id [70640,70650]
name: project_id [70696,70706]
===
match
---
name: __init__ [85224,85232]
name: __init__ [85280,85288]
===
match
---
expr_stmt [25305,25344]
expr_stmt [25305,25344]
===
match
---
name: value [31257,31262]
name: value [31313,31318]
===
match
---
name: BigQueryUpsertTableOperator [82510,82537]
name: BigQueryUpsertTableOperator [82566,82593]
===
match
---
name: typing [987,993]
name: typing [987,993]
===
match
---
operator: = [13826,13827]
operator: = [13826,13827]
===
match
---
name: create_disposition [27524,27542]
name: create_disposition [27580,27598]
===
match
---
trailer [25515,25517]
trailer [25515,25517]
===
match
---
param [17556,17590]
param [17556,17590]
===
match
---
name: _BigQueryDbHookMixin [3062,3082]
name: _BigQueryDbHookMixin [3062,3082]
===
match
---
name: encryption_configuration [49250,49274]
name: encryption_configuration [49306,49330]
===
match
---
annassign [95654,95691]
annassign [95710,95747]
===
match
---
name: dataset_id [77819,77829]
name: dataset_id [77875,77885]
===
match
---
tfpdef [26334,26390]
tfpdef [26334,26390]
===
match
---
trailer [13248,13268]
trailer [13248,13268]
===
match
---
atom_expr [25460,25468]
atom_expr [25460,25468]
===
match
---
operator: , [70353,70354]
operator: , [70409,70410]
===
match
---
suite [7419,10232]
suite [7419,10232]
===
match
---
name: query_params [30562,30574]
name: query_params [30618,30630]
===
match
---
operator: , [78832,78833]
operator: , [78888,78889]
===
match
---
name: self [27731,27735]
name: self [27787,27791]
===
match
---
name: gcp_conn_id [18260,18271]
name: gcp_conn_id [18260,18271]
===
match
---
name: self [82237,82241]
name: self [82293,82297]
===
match
---
name: operators [1355,1364]
name: operators [1355,1364]
===
match
---
operator: , [69901,69902]
operator: , [69957,69958]
===
match
---
fstring_string: BigQuery Console # [2605,2623]
fstring_string: BigQuery Console # [2605,2623]
===
match
---
name: table_data [19096,19106]
name: table_data [19096,19106]
===
match
---
name: self [29922,29926]
name: self [29978,29982]
===
match
---
operator: , [17960,17961]
operator: , [17960,17961]
===
match
---
name: max_results [18899,18910]
name: max_results [18899,18910]
===
match
---
name: bigquery_conn_id [7097,7113]
name: bigquery_conn_id [7097,7113]
===
match
---
operator: ** [17712,17714]
operator: ** [17712,17714]
===
match
---
name: configuration [96929,96942]
name: configuration [96985,96998]
===
match
---
operator: ** [9766,9768]
operator: ** [9766,9768]
===
match
---
tfpdef [94979,95000]
tfpdef [95035,95056]
===
match
---
argument [56901,56945]
argument [56957,57001]
===
match
---
name: schema_fields [38314,38327]
name: schema_fields [38370,38383]
===
match
---
atom_expr [61234,61260]
atom_expr [61290,61316]
===
match
---
trailer [31124,31199]
trailer [31180,31255]
===
match
---
suite [98619,98831]
suite [98675,98887]
===
match
---
trailer [77839,77844]
trailer [77895,77900]
===
match
---
trailer [39530,39537]
trailer [39586,39593]
===
match
---
argument [40075,40097]
argument [40131,40153]
===
match
---
suite [82116,82502]
suite [82172,82558]
===
match
---
string: 'gcp_conn_id' [9187,9200]
string: 'gcp_conn_id' [9187,9200]
===
match
---
argument [75008,75034]
argument [75064,75090]
===
match
---
name: self [64370,64374]
name: self [64426,64430]
===
match
---
name: delegate_to [51277,51288]
name: delegate_to [51333,51344]
===
match
---
trailer [31388,31416]
trailer [31444,31472]
===
match
---
operator: , [18977,18978]
operator: , [18977,18978]
===
match
---
name: table_id [41609,41617]
name: table_id [41665,41673]
===
match
---
atom_expr [7005,7070]
atom_expr [7005,7070]
===
match
---
simple_stmt [56781,56957]
simple_stmt [56837,57013]
===
match
---
atom_expr [38634,38648]
atom_expr [38690,38704]
===
match
---
name: __init__ [55650,55658]
name: __init__ [55706,55714]
===
match
---
argument [86158,86202]
argument [86214,86258]
===
match
---
trailer [48332,48338]
trailer [48388,48394]
===
match
---
suite [51688,52018]
suite [51744,52074]
===
match
---
tfpdef [77861,77886]
tfpdef [77917,77942]
===
match
---
trailer [41082,41089]
trailer [41138,41145]
===
match
---
name: str [12908,12911]
name: str [12908,12911]
===
match
---
operator: , [95260,95261]
operator: , [95316,95317]
===
match
---
string: 'table_id' [73686,73696]
string: 'table_id' [73742,73752]
===
match
---
fstring [2603,2640]
fstring [2603,2640]
===
match
---
name: self [18651,18655]
name: self [18651,18655]
===
match
---
name: Optional [9735,9743]
name: Optional [9735,9743]
===
match
---
argument [18991,19013]
argument [18991,19013]
===
match
---
operator: , [6952,6953]
operator: , [6952,6953]
===
match
---
name: self [39696,39700]
name: self [39752,39756]
===
match
---
expr_stmt [2958,2986]
expr_stmt [2958,2986]
===
match
---
trailer [95484,95495]
trailer [95540,95551]
===
match
---
atom_expr [90653,90669]
atom_expr [90709,90725]
===
match
---
name: schema_fields [39188,39201]
name: schema_fields [39244,39257]
===
match
---
expr_stmt [28275,28331]
expr_stmt [28331,28387]
===
match
---
operator: , [6903,6904]
operator: , [6903,6904]
===
match
---
simple_stmt [887,902]
simple_stmt [887,902]
===
match
---
argument [56632,56640]
argument [56688,56696]
===
match
---
trailer [18961,18977]
trailer [18961,18977]
===
match
---
atom_expr [73960,73979]
atom_expr [74016,74035]
===
match
---
trailer [47711,47721]
trailer [47767,47777]
===
match
---
param [77861,77894]
param [77917,77950]
===
match
---
name: Optional [9675,9683]
name: Optional [9675,9683]
===
match
---
name: gcp_conn_id [10091,10102]
name: gcp_conn_id [10091,10102]
===
match
---
simple_stmt [50048,50079]
simple_stmt [50104,50135]
===
match
---
trailer [77796,77801]
trailer [77852,77857]
===
match
---
trailer [39281,39298]
trailer [39337,39354]
===
match
---
name: self [97625,97629]
name: self [97681,97685]
===
match
---
atom_expr [29243,29258]
atom_expr [29299,29314]
===
match
---
param [12901,12912]
param [12901,12912]
===
match
---
expr_stmt [28908,29897]
expr_stmt [28964,29953]
===
match
---
name: List [73969,73973]
name: List [74025,74029]
===
match
---
trailer [98056,98058]
trailer [98112,98114]
===
match
---
atom_expr [18533,18548]
atom_expr [18533,18548]
===
match
---
name: str [26030,26033]
name: str [26030,26033]
===
match
---
trailer [74098,74103]
trailer [74154,74159]
===
match
---
operator: = [2784,2785]
operator: = [2784,2785]
===
match
---
subscriptlist [67070,67088]
subscriptlist [67126,67144]
===
match
---
atom_expr [50048,50064]
atom_expr [50104,50120]
===
match
---
param [38849,38892]
param [38905,38948]
===
match
---
trailer [50142,50158]
trailer [50198,50214]
===
match
---
param [47937,47964]
param [47993,48020]
===
match
---
argument [52468,52508]
argument [52524,52564]
===
match
---
parameters [47548,48579]
parameters [47604,48635]
===
match
---
operator: = [25969,25970]
operator: = [25969,25970]
===
match
---
name: bigquery_conn_id [27181,27197]
name: bigquery_conn_id [27211,27227]
===
match
---
operator: = [50253,50254]
operator: = [50309,50310]
===
match
---
operator: = [81736,81737]
operator: = [81792,81793]
===
match
---
name: labels [26452,26458]
name: labels [26452,26458]
===
match
---
simple_stmt [9283,9308]
simple_stmt [9283,9308]
===
match
---
name: delegate_to [61405,61416]
name: delegate_to [61461,61472]
===
match
---
expr_stmt [48728,48762]
expr_stmt [48784,48818]
===
match
---
trailer [51330,51350]
trailer [51386,51406]
===
match
---
name: project_id [67726,67736]
name: project_id [67782,67792]
===
match
---
name: Optional [26549,26557]
name: Optional [26549,26557]
===
match
---
name: __init__ [9361,9369]
name: __init__ [9361,9369]
===
match
---
param [13173,13204]
param [13173,13204]
===
match
---
name: BigQueryGetDataOperator [13929,13952]
name: BigQueryGetDataOperator [13929,13952]
===
match
---
argument [50953,50975]
argument [51009,51031]
===
match
---
operator: , [25191,25192]
operator: , [25191,25192]
===
match
---
name: self [28140,28144]
name: self [28196,28200]
===
match
---
name: self [30325,30329]
name: self [30381,30385]
===
match
---
name: self [41222,41226]
name: self [41278,41282]
===
match
---
argument [85485,85497]
argument [85541,85553]
===
match
---
operator: , [47573,47574]
operator: , [47629,47630]
===
match
---
name: run_query [29992,30001]
name: run_query [30048,30057]
===
match
---
operator: , [60273,60274]
operator: , [60329,60330]
===
match
---
parameters [9369,9781]
parameters [9369,9781]
===
match
---
name: field_delimiter [52547,52562]
name: field_delimiter [52603,52618]
===
match
---
operator: = [64134,64135]
operator: = [64190,64191]
===
match
---
name: self [82478,82482]
name: self [82534,82538]
===
match
---
name: labels [48355,48361]
name: labels [48411,48417]
===
match
---
name: self [91179,91183]
name: self [91235,91239]
===
match
---
parameters [17295,17727]
parameters [17295,17727]
===
match
---
atom_expr [70932,71097]
atom_expr [70988,71153]
===
match
---
trailer [38067,38073]
trailer [38123,38129]
===
match
---
operator: ** [13548,13550]
operator: ** [13548,13550]
===
match
---
expr_stmt [66736,66777]
expr_stmt [66792,66833]
===
match
---
atom_expr [61605,61620]
atom_expr [61661,61676]
===
match
---
operator: , [25209,25210]
operator: , [25209,25210]
===
match
---
trailer [38827,38832]
trailer [38883,38888]
===
match
---
name: i [25565,25566]
name: i [25565,25566]
===
match
---
argument [2188,2201]
argument [2188,2201]
===
match
---
operator: } [2638,2639]
operator: } [2638,2639]
===
match
---
simple_stmt [7230,7255]
simple_stmt [7230,7255]
===
match
---
tfpdef [64056,64072]
tfpdef [64112,64128]
===
match
---
atom_expr [27653,27669]
atom_expr [27709,27725]
===
match
---
operator: = [2239,2240]
operator: = [2239,2240]
===
match
---
operator: = [49660,49661]
operator: = [49716,49717]
===
match
---
operator: , [95041,95042]
operator: , [95097,95098]
===
match
---
name: impersonation_chain [78360,78379]
name: impersonation_chain [78416,78435]
===
match
---
tfpdef [6783,6839]
tfpdef [6783,6839]
===
match
---
atom_expr [13900,13911]
atom_expr [13900,13911]
===
match
---
name: BaseOperator [78984,78996]
name: BaseOperator [79040,79052]
===
match
---
operator: = [82364,82365]
operator: = [82420,82421]
===
match
---
trailer [9806,9815]
trailer [9806,9815]
===
match
---
param [48099,48131]
param [48155,48187]
===
match
---
name: impersonation_chain [51331,51350]
name: impersonation_chain [51387,51406]
===
match
---
tfpdef [84928,84944]
tfpdef [84984,85000]
===
match
---
name: hook [97541,97545]
name: hook [97597,97601]
===
match
---
name: delete_contents [57079,57094]
name: delete_contents [57135,57150]
===
match
---
name: exists_ok [61795,61804]
name: exists_ok [61851,61860]
===
match
---
tfpdef [9404,9412]
tfpdef [9404,9412]
===
match
---
name: __init__ [81048,81056]
name: __init__ [81104,81112]
===
match
---
tfpdef [81311,81334]
tfpdef [81367,81390]
===
match
---
operator: = [60409,60410]
operator: = [60465,60466]
===
match
---
operator: } [94771,94772]
operator: } [94827,94828]
===
match
---
name: dataset_id [56365,56375]
name: dataset_id [56421,56431]
===
match
---
string: "json" [70015,70021]
string: "json" [70071,70077]
===
match
---
operator: , [90879,90880]
operator: , [90935,90936]
===
match
---
operator: , [1036,1037]
operator: , [1036,1037]
===
match
---
string: "The bigquery_conn_id parameter has been deprecated. You should pass " [85316,85386]
string: "The bigquery_conn_id parameter has been deprecated. You should pass " [85372,85442]
===
match
---
name: str [64035,64038]
name: str [64091,64094]
===
match
---
name: template_fields [6351,6366]
name: template_fields [6351,6366]
===
match
---
arglist [25460,25473]
arglist [25460,25473]
===
match
---
operator: , [95297,95298]
operator: , [95353,95354]
===
match
---
name: fields [78886,78892]
name: fields [78942,78948]
===
match
---
name: airflow [1294,1301]
name: airflow [1294,1301]
===
match
---
operator: , [38146,38147]
operator: , [38202,38203]
===
match
---
name: self [28818,28822]
name: self [28874,28878]
===
match
---
atom_expr [28958,28966]
atom_expr [29014,29022]
===
match
---
name: warnings [56080,56088]
name: warnings [56136,56144]
===
match
---
suite [96029,96142]
suite [96085,96198]
===
match
---
argument [9848,9867]
argument [9848,9867]
===
match
---
string: "configuration" [94613,94628]
string: "configuration" [94669,94684]
===
match
---
trailer [98580,98587]
trailer [98636,98643]
===
match
---
trailer [61241,61250]
trailer [61297,61306]
===
match
---
simple_stmt [78294,78325]
simple_stmt [78350,78381]
===
match
---
param [85027,85061]
param [85083,85117]
===
match
---
name: s [30027,30028]
name: s [30083,30084]
===
match
---
name: self [51423,51427]
name: self [51479,51483]
===
match
---
atom_expr [38865,38884]
atom_expr [38921,38940]
===
match
---
atom_expr [17526,17539]
atom_expr [17526,17539]
===
match
---
name: Conflict [41520,41528]
name: Conflict [41576,41584]
===
match
---
simple_stmt [97270,97309]
simple_stmt [97326,97365]
===
match
---
arglist [26988,27140]
arglist [26988,27170]
===
match
---
name: gcp_conn_id [13688,13699]
name: gcp_conn_id [13688,13699]
===
match
---
trailer [64879,64890]
trailer [64935,64946]
===
match
---
name: Optional [26196,26204]
name: Optional [26196,26204]
===
match
---
atom_expr [47445,47473]
atom_expr [47501,47529]
===
insert-tree
---
simple_stmt [821,875]
    string: """This module contains Google BigQuery operators.""" [821,874]
to
file_input [821,98831]
at 0
===
insert-node
---
name: BigQueryExecuteQueryOperator [19221,19249]
to
classdef [19215,31454]
at 0
===
insert-node
---
name: BaseOperator [19250,19262]
to
classdef [19215,31454]
at 1
===
insert-tree
---
simple_stmt [19269,25116]
    string: """     Executes BigQuery SQL queries in a specific BigQuery database.     This operator does not assert idempotency.      :param sql: the sql code to be executed (templated)     :type sql: Can receive a str representing a sql statement,         a list of str (sql statements), or reference to a template file.         Template reference are recognized by str ending in '.sql'.     :param destination_dataset_table: A dotted         ``(<project>.|<project>:)<dataset>.<table>`` that, if set, will store the results         of the query. (templated)     :type destination_dataset_table: str     :param write_disposition: Specifies the action that occurs if the destination table         already exists. (default: 'WRITE_EMPTY')     :type write_disposition: str     :param create_disposition: Specifies whether the job is allowed to create new tables.         (default: 'CREATE_IF_NEEDED')     :type create_disposition: str     :param allow_large_results: Whether to allow large results.     :type allow_large_results: bool     :param flatten_results: If true and query uses legacy SQL dialect, flattens         all nested and repeated fields in the query results. ``allow_large_results``         must be ``true`` if this is set to ``false``. For standard SQL queries, this         flag is ignored and results are never flattened.     :type flatten_results: bool     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param udf_config: The User Defined Function configuration for the query.         See https://cloud.google.com/bigquery/user-defined-functions for details.     :type udf_config: list     :param use_legacy_sql: Whether to use legacy SQL (true) or standard SQL (false).     :type use_legacy_sql: bool     :param maximum_billing_tier: Positive integer that serves as a multiplier         of the basic price.         Defaults to None, in which case it uses the value set in the project.     :type maximum_billing_tier: int     :param maximum_bytes_billed: Limits the bytes billed for this job.         Queries that will have bytes billed beyond this limit will fail         (without incurring a charge). If unspecified, this will be         set to your project default.     :type maximum_bytes_billed: float     :param api_resource_configs: a dictionary that contain params         'configuration' applied for Google BigQuery Jobs API:         https://cloud.google.com/bigquery/docs/reference/rest/v2/jobs         for example, {'query': {'useQueryCache': False}}. You could use it         if you need to provide some params that are not supported by BigQueryOperator         like args.     :type api_resource_configs: dict     :param schema_update_options: Allows the schema of the destination         table to be updated as a side effect of the load job.     :type schema_update_options: Optional[Union[list, tuple, set]]     :param query_params: a list of dictionary containing query parameter types and         values, passed to BigQuery. The structure of dictionary should look like         'queryParameters' in Google BigQuery Jobs API:         https://cloud.google.com/bigquery/docs/reference/rest/v2/jobs.         For example, [{ 'name': 'corpus', 'parameterType': { 'type': 'STRING' },         'parameterValue': { 'value': 'romeoandjuliet' } }]. (templated)     :type query_params: list     :param labels: a dictionary containing labels for the job/query,         passed to BigQuery     :type labels: dict     :param priority: Specifies a priority for the query.         Possible values include INTERACTIVE and BATCH.         The default value is INTERACTIVE.     :type priority: str     :param time_partitioning: configure optional time partitioning fields i.e.         partition by field, type and expiration as per API specifications.     :type time_partitioning: dict     :param cluster_fields: Request that the result of this query be stored sorted         by one or more columns. BigQuery supports clustering for both partitioned and         non-partitioned tables. The order of columns given determines the sort order.     :type cluster_fields: list[str]     :param location: The geographic location of the job. Required except for         US and EU. See details at         https://cloud.google.com/bigquery/docs/locations#specifying_your_location     :type location: str     :param encryption_configuration: [Optional] Custom encryption configuration (e.g., Cloud KMS keys).         **Example**: ::              encryption_configuration = {                 "kmsKeyName": "projects/testp/locations/us/keyRings/test-kr/cryptoKeys/test-key"             }     :type encryption_configuration: dict     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [19269,25115]
to
suite [19264,31454]
at 0
===
insert-tree
---
argument [27380,27392]
    name: stacklevel [27380,27390]
    operator: = [27390,27391]
    number: 2 [27391,27392]
to
arglist [27234,27337]
at 4
===
insert-node
---
operator: , [27392,27393]
to
arglist [27234,27337]
at 5
===
update-node
---
number: 3 [70577,70578]
replace 3 by 2
===
insert-tree
---
argument [27157,27169]
    name: stacklevel [27157,27167]
    operator: = [27167,27168]
    number: 2 [27168,27169]
to
arglist [26988,27140]
at 4
===
insert-node
---
operator: , [27169,27170]
to
arglist [26988,27140]
at 5
===
delete-tree
---
simple_stmt [821,875]
    string: """This module contains Google BigQuery operators.""" [821,874]
===
delete-node
---
name: BigQueryExecuteQueryOperator [19221,19249]
===
===
delete-node
---
name: BaseOperator [19250,19262]
===
===
delete-tree
---
simple_stmt [19269,25116]
    string: """     Executes BigQuery SQL queries in a specific BigQuery database.     This operator does not assert idempotency.      :param sql: the sql code to be executed (templated)     :type sql: Can receive a str representing a sql statement,         a list of str (sql statements), or reference to a template file.         Template reference are recognized by str ending in '.sql'.     :param destination_dataset_table: A dotted         ``(<project>.|<project>:)<dataset>.<table>`` that, if set, will store the results         of the query. (templated)     :type destination_dataset_table: str     :param write_disposition: Specifies the action that occurs if the destination table         already exists. (default: 'WRITE_EMPTY')     :type write_disposition: str     :param create_disposition: Specifies whether the job is allowed to create new tables.         (default: 'CREATE_IF_NEEDED')     :type create_disposition: str     :param allow_large_results: Whether to allow large results.     :type allow_large_results: bool     :param flatten_results: If true and query uses legacy SQL dialect, flattens         all nested and repeated fields in the query results. ``allow_large_results``         must be ``true`` if this is set to ``false``. For standard SQL queries, this         flag is ignored and results are never flattened.     :type flatten_results: bool     :param gcp_conn_id: (Optional) The connection ID used to connect to Google Cloud.     :type gcp_conn_id: str     :param bigquery_conn_id: (Deprecated) The connection ID used to connect to Google Cloud.         This parameter has been deprecated. You should pass the gcp_conn_id parameter instead.     :type bigquery_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param udf_config: The User Defined Function configuration for the query.         See https://cloud.google.com/bigquery/user-defined-functions for details.     :type udf_config: list     :param use_legacy_sql: Whether to use legacy SQL (true) or standard SQL (false).     :type use_legacy_sql: bool     :param maximum_billing_tier: Positive integer that serves as a multiplier         of the basic price.         Defaults to None, in which case it uses the value set in the project.     :type maximum_billing_tier: int     :param maximum_bytes_billed: Limits the bytes billed for this job.         Queries that will have bytes billed beyond this limit will fail         (without incurring a charge). If unspecified, this will be         set to your project default.     :type maximum_bytes_billed: float     :param api_resource_configs: a dictionary that contain params         'configuration' applied for Google BigQuery Jobs API:         https://cloud.google.com/bigquery/docs/reference/rest/v2/jobs         for example, {'query': {'useQueryCache': False}}. You could use it         if you need to provide some params that are not supported by BigQueryOperator         like args.     :type api_resource_configs: dict     :param schema_update_options: Allows the schema of the destination         table to be updated as a side effect of the load job.     :type schema_update_options: Optional[Union[list, tuple, set]]     :param query_params: a list of dictionary containing query parameter types and         values, passed to BigQuery. The structure of dictionary should look like         'queryParameters' in Google BigQuery Jobs API:         https://cloud.google.com/bigquery/docs/reference/rest/v2/jobs.         For example, [{ 'name': 'corpus', 'parameterType': { 'type': 'STRING' },         'parameterValue': { 'value': 'romeoandjuliet' } }]. (templated)     :type query_params: list     :param labels: a dictionary containing labels for the job/query,         passed to BigQuery     :type labels: dict     :param priority: Specifies a priority for the query.         Possible values include INTERACTIVE and BATCH.         The default value is INTERACTIVE.     :type priority: str     :param time_partitioning: configure optional time partitioning fields i.e.         partition by field, type and expiration as per API specifications.     :type time_partitioning: dict     :param cluster_fields: Request that the result of this query be stored sorted         by one or more columns. BigQuery supports clustering for both partitioned and         non-partitioned tables. The order of columns given determines the sort order.     :type cluster_fields: list[str]     :param location: The geographic location of the job. Required except for         US and EU. See details at         https://cloud.google.com/bigquery/docs/locations#specifying_your_location     :type location: str     :param encryption_configuration: [Optional] Custom encryption configuration (e.g., Cloud KMS keys).         **Example**: ::              encryption_configuration = {                 "kmsKeyName": "projects/testp/locations/us/keyRings/test-kr/cryptoKeys/test-key"             }     :type encryption_configuration: dict     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [19269,25115]
