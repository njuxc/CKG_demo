===
match
---
operator: , [5302,5303]
operator: , [5456,5457]
===
match
---
argument [5419,5435]
argument [5573,5589]
===
match
---
suite [3991,4665]
suite [3991,4819]
===
match
---
name: hooks [924,929]
name: hooks [924,929]
===
match
---
name: Union [841,846]
name: Union [841,846]
===
match
---
trailer [4016,4026]
trailer [4016,4026]
===
match
---
atom_expr [4540,4556]
atom_expr [4694,4710]
===
match
---
expr_stmt [4618,4664]
expr_stmt [4772,4818]
===
match
---
string: "`destination_bucket` is deprecated please use `bucket_name`" [4145,4206]
string: "`destination_bucket` is deprecated please use `bucket_name`" [4162,4223]
===
match
---
atom_expr [5166,5180]
atom_expr [5320,5334]
===
match
---
operator: = [5430,5431]
operator: = [5584,5585]
===
match
---
operator: = [3817,3818]
operator: = [3817,3818]
===
match
---
name: destination_bucket [4099,4117]
name: destination_bucket [4099,4117]
===
match
---
trailer [5260,5342]
trailer [5414,5496]
===
match
---
name: Optional [3554,3562]
name: Optional [3554,3562]
===
match
---
name: Optional [3864,3872]
name: Optional [3864,3872]
===
match
---
string: "destination_bucket" [3295,3315]
string: "destination_bucket" [3295,3315]
===
match
---
import_as_names [821,846]
import_as_names [821,846]
===
match
---
name: folder_id [5130,5139]
name: folder_id [5284,5293]
===
match
---
atom_expr [4472,4485]
atom_expr [4626,4639]
===
match
---
atom_expr [4908,5068]
atom_expr [5062,5222]
===
match
---
name: bucket_name [5291,5302]
name: bucket_name [5445,5456]
===
match
---
name: delegate_to [4988,4999]
name: delegate_to [5142,5153]
===
match
---
classdef [1022,5437]
classdef [1022,5591]
===
match
---
argument [4017,4025]
argument [4017,4025]
===
match
---
operator: , [4407,4408]
operator: , [4501,4502]
===
match
---
param [4682,4687]
param [4836,4841]
===
match
---
dotted_name [893,933]
dotted_name [893,933]
===
match
---
operator: , [3841,3842]
operator: , [3841,3842]
===
match
---
argument [5274,5302]
argument [5428,5456]
===
match
---
atom_expr [3554,3567]
atom_expr [3554,3567]
===
match
---
param [3584,3625]
param [3584,3625]
===
match
---
name: delegate_to [4584,4595]
name: delegate_to [4738,4749]
===
match
---
trailer [5320,5332]
trailer [5474,5486]
===
match
---
operator: = [3878,3879]
operator: = [3878,3879]
===
match
---
trailer [4945,4957]
trailer [5099,5111]
===
match
---
name: gcp_conn_id [3800,3811]
name: gcp_conn_id [3800,3811]
===
match
---
atom_expr [4505,4519]
atom_expr [4659,4673]
===
match
---
simple_stmt [848,888]
simple_stmt [848,888]
===
match
---
trailer [4005,4007]
trailer [4005,4007]
===
match
---
trailer [5389,5436]
trailer [5543,5590]
===
match
---
string: "`destination_object` is deprecated please use `object_name`" [4346,4407]
string: "`destination_object` is deprecated please use `object_name`" [4440,4501]
===
match
---
string: "bucket_name" [3249,3262]
string: "bucket_name" [3249,3262]
===
match
---
atom_expr [4941,4957]
atom_expr [5095,5111]
===
match
---
trailer [4622,4642]
trailer [4776,4796]
===
match
---
atom_expr [4761,4777]
atom_expr [4915,4931]
===
match
---
atom_expr [3915,3950]
atom_expr [3915,3950]
===
match
---
argument [4749,4777]
argument [4903,4931]
===
match
---
tfpdef [3498,3524]
tfpdef [3498,3524]
===
match
---
testlist_comp [3249,3439]
testlist_comp [3249,3439]
===
match
---
param [3736,3751]
param [3736,3751]
===
match
---
atom_expr [4983,4999]
atom_expr [5137,5153]
===
match
---
atom_expr [5316,5332]
atom_expr [5470,5486]
===
match
---
if_stmt [4096,4228]
if_stmt [4096,4305]
===
match
---
argument [5390,5417]
argument [5544,5571]
===
match
---
trailer [4039,4051]
trailer [4039,4051]
===
match
---
expr_stmt [4897,5068]
expr_stmt [5051,5222]
===
match
---
name: bucket_name [5274,5285]
name: bucket_name [5428,5439]
===
match
---
atom_expr [3864,3877]
atom_expr [3864,3877]
===
match
---
name: self [4579,4583]
name: self [4733,4737]
===
match
---
operator: = [5315,5316]
operator: = [5469,5470]
===
match
---
name: GCSHook [4908,4915]
name: GCSHook [5062,5069]
===
match
---
operator: = [3784,3785]
operator: = [3784,3785]
===
match
---
name: self [4540,4544]
name: self [4694,4698]
===
match
---
name: folder_id [4442,4451]
name: folder_id [4596,4605]
===
match
---
simple_stmt [4437,4464]
simple_stmt [4591,4618]
===
match
---
operator: , [4777,4778]
operator: , [4931,4932]
===
match
---
simple_stmt [5364,5437]
simple_stmt [5518,5591]
===
match
---
operator: , [5417,5418]
operator: , [5571,5572]
===
match
---
operator: = [4982,4983]
operator: = [5136,5137]
===
match
---
operator: = [5139,5140]
operator: = [5293,5294]
===
match
---
name: destination_object [3648,3666]
name: destination_object [3648,3666]
===
match
---
operator: , [3285,3286]
operator: , [3285,3286]
===
match
---
operator: , [3315,3316]
operator: , [3315,3316]
===
match
---
simple_stmt [888,949]
simple_stmt [888,949]
===
match
---
operator: , [829,830]
operator: , [829,830]
===
match
---
import_from [848,887]
import_from [848,887]
===
match
---
operator: , [3933,3934]
operator: , [3933,3934]
===
match
---
string: "folder_id" [3355,3366]
string: "folder_id" [3355,3366]
===
match
---
atom_expr [4437,4451]
atom_expr [4591,4605]
===
match
---
operator: = [4718,4719]
operator: = [4872,4873]
===
match
---
trailer [4345,4428]
trailer [4422,4582]
===
match
---
name: object_name [5304,5315]
name: object_name [5458,5469]
===
match
---
suite [1067,5437]
suite [1067,5591]
===
match
---
name: gcp_conn_id [4929,4940]
name: gcp_conn_id [5083,5094]
===
match
---
name: self [5191,5195]
name: self [5345,5349]
===
match
---
atom_expr [4803,4819]
atom_expr [4957,4973]
===
match
---
name: self [4618,4622]
name: self [4772,4776]
===
match
---
expr_stmt [4035,4087]
expr_stmt [4035,4087]
===
match
---
name: GCSHook [941,948]
name: GCSHook [941,948]
===
match
---
name: bucket_name [3498,3509]
name: bucket_name [3498,3509]
===
match
---
trailer [3778,3783]
trailer [3778,3783]
===
match
---
param [3851,3885]
param [3851,3885]
===
match
---
operator: , [3345,3346]
operator: , [3345,3346]
===
match
---
atom_expr [3770,3783]
atom_expr [3770,3783]
===
match
---
name: providers [901,910]
name: providers [901,910]
===
match
---
name: delegate_to [3851,3862]
name: delegate_to [3851,3862]
===
match
---
name: google [972,978]
name: google [972,978]
===
match
---
name: self [4236,4240]
name: self [4313,4317]
===
match
---
name: str [3520,3523]
name: str [3520,3523]
===
match
---
name: Optional [3604,3612]
name: Optional [3604,3612]
===
match
---
param [3541,3575]
param [3541,3575]
===
match
---
import_from [949,1019]
import_from [949,1019]
===
match
---
name: provide_file_and_upload [5237,5260]
name: provide_file_and_upload [5391,5414]
===
match
---
tfpdef [3736,3750]
tfpdef [3736,3750]
===
match
---
name: file_handle [5419,5430]
name: file_handle [5573,5584]
===
match
---
operator: = [4643,4644]
operator: = [4797,4798]
===
match
---
name: drive_id [4477,4485]
name: drive_id [4631,4639]
===
match
---
trailer [4857,4877]
trailer [5011,5031]
===
match
---
operator: = [4906,4907]
operator: = [5060,5061]
===
match
---
operator: , [3574,3575]
operator: , [3574,3575]
===
match
---
name: self [4761,4765]
name: self [4915,4919]
===
match
---
funcdef [4670,5437]
funcdef [4824,5591]
===
match
---
name: get_file_id [5105,5116]
name: get_file_id [5259,5270]
===
match
---
param [3800,3842]
param [3800,3842]
===
match
---
trailer [4007,4016]
trailer [4007,4016]
===
match
---
simple_stmt [786,802]
simple_stmt [786,802]
===
match
---
tfpdef [3760,3783]
tfpdef [3760,3783]
===
match
---
operator: = [5285,5286]
operator: = [5439,5440]
===
match
---
name: file_id [5390,5397]
name: file_id [5544,5551]
===
match
---
operator: = [5397,5398]
operator: = [5551,5552]
===
match
---
trailer [5116,5214]
trailer [5270,5368]
===
match
---
expr_stmt [4236,4288]
expr_stmt [4313,4365]
===
match
---
expr_stmt [4505,4531]
expr_stmt [4659,4685]
===
match
---
name: str [3873,3876]
name: str [3873,3876]
===
match
---
operator: = [4940,4941]
operator: = [5094,5095]
===
match
---
operator: = [3618,3619]
operator: = [3618,3619]
===
match
---
trailer [4583,4595]
trailer [4737,4749]
===
match
---
operator: , [3688,3689]
operator: , [3688,3689]
===
match
---
name: self [3473,3477]
name: self [3473,3477]
===
match
---
trailer [4240,4252]
trailer [4317,4329]
===
match
---
name: file_name [5156,5165]
name: file_name [5310,5319]
===
match
---
argument [5304,5332]
argument [5458,5486]
===
match
---
operator: , [3624,3625]
operator: , [3624,3625]
===
match
---
operator: ** [4017,4019]
operator: ** [4017,4019]
===
match
---
operator: = [4052,4053]
operator: = [4052,4053]
===
match
---
name: object_name [4277,4288]
name: object_name [4354,4365]
===
match
---
name: kwargs [3969,3975]
name: kwargs [3969,3975]
===
match
---
trailer [5037,5057]
trailer [5191,5211]
===
match
---
name: str [3944,3947]
name: str [3944,3947]
===
match
---
operator: , [3438,3439]
operator: , [3438,3439]
===
match
---
atom_expr [4618,4642]
atom_expr [4772,4796]
===
match
---
atom_expr [3935,3948]
atom_expr [3935,3948]
===
match
---
string: "file_name" [3376,3387]
string: "file_name" [3376,3387]
===
match
---
atom_expr [5093,5214]
atom_expr [5247,5368]
===
match
---
operator: , [4206,4207]
operator: , [4223,4224]
===
match
---
name: gcp_conn_id [4946,4957]
name: gcp_conn_id [5100,5111]
===
match
---
with_stmt [5223,5437]
with_stmt [5377,5591]
===
match
---
trailer [3676,3681]
trailer [3676,3681]
===
match
---
operator: = [3682,3683]
operator: = [3682,3683]
===
match
---
operator: , [3366,3367]
operator: , [3366,3367]
===
match
---
name: bucket_name [4076,4087]
name: bucket_name [4076,4087]
===
match
---
name: GoogleDriveHook [1004,1019]
name: GoogleDriveHook [1004,1019]
===
match
---
name: str [3930,3933]
name: str [3930,3933]
===
match
---
simple_stmt [4236,4289]
simple_stmt [4313,4366]
===
match
---
name: __init__ [3455,3463]
name: __init__ [3455,3463]
===
match
---
name: delegate_to [4808,4819]
name: delegate_to [4962,4973]
===
match
---
atom_expr [3511,3524]
atom_expr [3511,3524]
===
match
---
operator: = [4452,4453]
operator: = [4606,4607]
===
match
---
trailer [3519,3524]
trailer [3519,3524]
===
match
---
operator: , [3531,3532]
operator: , [3531,3532]
===
match
---
operator: , [3262,3263]
operator: , [3262,3263]
===
match
---
name: __init__ [4008,4016]
name: __init__ [4008,4016]
===
match
---
name: self [5166,5170]
name: self [5320,5324]
===
match
---
name: file_name [4510,4519]
name: file_name [4664,4673]
===
match
---
name: drive [991,996]
name: drive [991,996]
===
match
---
trailer [5375,5389]
trailer [5529,5543]
===
match
---
funcdef [3451,4665]
funcdef [3451,4819]
===
match
---
operator: = [3237,3238]
operator: = [3237,3238]
===
match
---
trailer [4476,4485]
trailer [4630,4639]
===
match
---
operator: * [3487,3488]
operator: * [3487,3488]
===
match
---
name: object_name [3541,3552]
name: object_name [3541,3552]
===
match
---
atom_expr [5398,5417]
atom_expr [5552,5571]
===
match
---
string: "impersonation_chain" [3417,3438]
string: "impersonation_chain" [3417,3438]
===
match
---
name: destination_object [4255,4273]
name: destination_object [4332,4350]
===
match
---
operator: , [4999,5000]
operator: , [5153,5154]
===
match
---
parameters [3463,3982]
parameters [3463,3982]
===
match
---
name: file [5346,5350]
name: file [5500,5504]
===
match
---
string: """     Writes a Google Drive file into Google Cloud Storage.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:GoogleDriveToGCSOperator`      :param bucket_name: The destination Google cloud storage bucket where the         file should be written to     :type bucket_name: str     :param object_name: The Google Cloud Storage object name for the object created by the operator.         For example: ``path/to/my/file/file.txt``.     :type object_name: str     :param destination_bucket: Same as bucket_name, but for backward compatibly     :type destination_bucket: str     :param destination_object: Same as object_name, but for backward compatibly     :type destination_object: str     :param folder_id: The folder id of the folder in which the Google Drive file resides     :type folder_id: str     :param file_name: The name of the file residing in Google Drive     :type file_name: str     :param drive_id: Optional. The id of the shared Google Drive in which the file resides.     :type drive_id: str     :param gcp_conn_id: The GCP connection ID to use when fetching connection info.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [1072,3215]
string: """     Writes a Google Drive file into Google Cloud Storage.      .. seealso::         For more information on how to use this operator, take a look at the guide:         :ref:`howto/operator:GoogleDriveToGCSOperator`      :param bucket_name: The destination Google cloud storage bucket where the         file should be written to     :type bucket_name: str     :param object_name: The Google Cloud Storage object name for the object created by the operator.         For example: ``path/to/my/file/file.txt``.     :type object_name: str     :param destination_bucket: Same as bucket_name, but for backward compatibly     :type destination_bucket: str     :param destination_object: Same as object_name, but for backward compatibly     :type destination_object: str     :param folder_id: The folder id of the folder in which the Google Drive file resides     :type folder_id: str     :param file_name: The name of the file residing in Google Drive     :type file_name: str     :param drive_id: Optional. The id of the shared Google Drive in which the file resides.     :type drive_id: str     :param gcp_conn_id: The GCP connection ID to use when fetching connection info.     :type gcp_conn_id: str     :param delegate_to: The account to impersonate using domain-wide delegation of authority,         if any. For this to work, the service account making the request must have         domain-wide delegation enabled.     :type delegate_to: str     :param impersonation_chain: Optional service account to impersonate using short-term         credentials, or chained list of accounts required to get the access_token         of the last account in the list, which will be impersonated in the request.         If set as a string, the account must grant the originating account         the Service Account Token Creator IAM role.         If set as a sequence, the identities from the list must grant         Service Account Token Creator IAM role to the directly preceding identity, with first         account from the list granting this role to the originating account (templated).     :type impersonation_chain: Union[str, Sequence[str]]     """ [1072,3215]
===
match
---
name: file_name [3712,3721]
name: file_name [3712,3721]
===
match
---
simple_stmt [4332,4429]
simple_stmt [4409,4583]
===
match
---
argument [4971,4999]
argument [5125,5153]
===
match
---
name: file_metadata [5398,5411]
name: file_metadata [5552,5565]
===
match
---
string: "drive_id" [3397,3407]
string: "drive_id" [3397,3407]
===
match
---
name: warnings [4131,4139]
name: warnings [4131,4139]
===
match
---
operator: , [3407,3408]
operator: , [3407,3408]
===
match
---
operator: = [4253,4254]
operator: = [4330,4331]
===
match
---
name: impersonation_chain [5013,5032]
name: impersonation_chain [5167,5186]
===
match
---
string: "id" [5412,5416]
string: "id" [5566,5570]
===
match
---
simple_stmt [4131,4228]
simple_stmt [4131,4305]
===
match
---
atom_expr [4720,4888]
atom_expr [4874,5042]
===
match
---
name: kwargs [4019,4025]
name: kwargs [4019,4025]
===
match
---
name: object_name [4241,4252]
name: object_name [4318,4329]
===
match
---
operator: = [4802,4803]
operator: = [4956,4957]
===
match
---
expr_stmt [3221,3445]
expr_stmt [3221,3445]
===
match
---
name: file_name [4522,4531]
name: file_name [4676,4685]
===
match
---
name: GoogleDriveHook [4720,4735]
name: GoogleDriveHook [4874,4889]
===
match
---
name: object_name [5321,5332]
name: object_name [5475,5486]
===
match
---
operator: , [4686,4687]
operator: , [4840,4841]
===
match
---
name: typing [807,813]
name: typing [807,813]
===
match
---
trailer [4807,4819]
trailer [4961,4973]
===
match
---
operator: = [3525,3526]
operator: = [3525,3526]
===
match
---
operator: = [4852,4853]
operator: = [5006,5007]
===
match
---
operator: , [5180,5181]
operator: , [5334,5335]
===
match
---
param [3760,3791]
param [3760,3791]
===
match
---
atom [3239,3445]
atom [3239,3445]
===
match
---
name: str [3747,3750]
name: str [3747,3750]
===
match
---
tfpdef [3648,3681]
tfpdef [3648,3681]
===
match
---
name: folder_id [5145,5154]
name: folder_id [5299,5308]
===
match
---
name: Optional [3770,3778]
name: Optional [3770,3778]
===
match
---
atom_expr [3924,3949]
atom_expr [3924,3949]
===
match
---
argument [5130,5154]
argument [5284,5308]
===
match
---
atom_expr [4236,4252]
atom_expr [4313,4329]
===
match
---
operator: = [5091,5092]
operator: = [5245,5246]
===
match
---
string: "destination_object" [3325,3345]
string: "destination_object" [3325,3345]
===
match
---
expr_stmt [4472,4496]
expr_stmt [4626,4650]
===
match
---
name: gcp_conn_id [4559,4570]
name: gcp_conn_id [4713,4724]
===
match
---
name: Sequence [831,839]
name: Sequence [831,839]
===
match
---
name: hooks [985,990]
name: hooks [985,990]
===
match
---
operator: , [3750,3751]
operator: , [3750,3751]
===
match
---
tfpdef [3851,3877]
tfpdef [3851,3877]
===
match
---
name: impersonation_chain [4623,4642]
name: impersonation_chain [4777,4796]
===
match
---
name: airflow [853,860]
name: airflow [853,860]
===
match
---
name: folder_id [4454,4463]
name: folder_id [4608,4617]
===
match
---
trailer [4441,4451]
trailer [4595,4605]
===
match
---
simple_stmt [4000,4027]
simple_stmt [4000,4027]
===
match
---
name: str [3613,3616]
name: str [3613,3616]
===
match
---
parameters [4681,4696]
parameters [4835,4850]
===
match
---
name: gcs_hook [4897,4905]
name: gcs_hook [5051,5059]
===
match
---
name: warn [4341,4345]
name: warn [4418,4422]
===
match
---
name: impersonation_chain [4858,4877]
name: impersonation_chain [5012,5031]
===
match
---
argument [5013,5057]
argument [5167,5211]
===
match
---
simple_stmt [3221,3446]
simple_stmt [3221,3446]
===
match
---
operator: , [4877,4878]
operator: , [5031,5032]
===
match
---
name: delegate_to [4791,4802]
name: delegate_to [4945,4956]
===
match
---
simple_stmt [5077,5215]
simple_stmt [5231,5369]
===
match
---
name: warnings [4332,4340]
name: warnings [4409,4417]
===
match
---
operator: , [3726,3727]
operator: , [3726,3727]
===
match
---
name: drive_id [4488,4496]
name: drive_id [4642,4650]
===
match
---
name: self [4472,4476]
name: self [4626,4630]
===
match
---
arglist [4749,4878]
arglist [4903,5032]
===
match
---
simple_stmt [4897,5069]
simple_stmt [5051,5223]
===
match
---
simple_stmt [802,847]
simple_stmt [802,847]
===
match
---
name: super [4000,4005]
name: super [4000,4005]
===
match
---
trailer [5236,5260]
trailer [5390,5414]
===
match
---
operator: , [4819,4820]
operator: , [4973,4974]
===
match
---
name: str [3779,3782]
name: str [3779,3782]
===
match
---
trailer [4139,4144]
trailer [4139,4144]
===
match
---
name: file [5431,5435]
name: file [5585,5589]
===
match
---
expr_stmt [4579,4609]
expr_stmt [4733,4763]
===
match
---
trailer [4144,4227]
trailer [4144,4304]
===
match
---
name: gdrive_hook [4706,4717]
name: gdrive_hook [4860,4871]
===
match
---
tfpdef [3541,3567]
tfpdef [3541,3567]
===
match
---
trailer [3943,3948]
trailer [3943,3948]
===
match
---
trailer [3872,3877]
trailer [3872,3877]
===
match
---
simple_stmt [4579,4610]
simple_stmt [4733,4764]
===
match
---
name: self [4437,4441]
name: self [4591,4595]
===
match
---
name: providers [962,971]
name: providers [962,971]
===
match
---
trailer [4544,4556]
trailer [4698,4710]
===
match
---
atom_expr [5191,5204]
atom_expr [5345,5358]
===
match
---
file_input [786,5437]
file_input [786,5591]
===
match
---
trailer [5411,5417]
trailer [5565,5571]
===
match
---
tfpdef [3584,3617]
tfpdef [3584,3617]
===
match
---
simple_stmt [4706,4889]
simple_stmt [4860,5043]
===
match
---
argument [4833,4877]
argument [4987,5031]
===
match
---
trailer [5104,5116]
trailer [5258,5270]
===
match
---
or_test [4255,4288]
or_test [4332,4365]
===
match
---
simple_stmt [1072,3216]
simple_stmt [1072,3216]
===
match
---
name: impersonation_chain [4645,4664]
name: impersonation_chain [4799,4818]
===
match
---
dotted_name [853,867]
dotted_name [853,867]
===
match
---
operator: = [4486,4487]
operator: = [4640,4641]
===
match
---
suite [4319,4429]
suite [4396,4583]
===
match
---
name: destination_object [4300,4318]
name: destination_object [4377,4395]
===
match
---
operator: = [5165,5166]
operator: = [5319,5320]
===
match
---
argument [5182,5204]
argument [5336,5358]
===
match
---
name: self [4682,4686]
name: self [4836,4840]
===
match
---
param [3712,3727]
param [3712,3727]
===
match
---
or_test [4054,4087]
or_test [4054,4087]
===
match
---
trailer [5195,5204]
trailer [5349,5358]
===
match
---
trailer [4340,4345]
trailer [4417,4422]
===
match
---
atom_expr [4579,4595]
atom_expr [4733,4749]
===
match
---
suite [4118,4228]
suite [4118,4305]
===
match
---
import_from [802,846]
import_from [802,846]
===
match
---
atom_expr [4035,4051]
atom_expr [4035,4051]
===
match
---
name: Optional [3668,3676]
name: Optional [3668,3676]
===
match
---
param [3894,3958]
param [3894,3958]
===
match
---
name: str [3813,3816]
name: str [3813,3816]
===
match
---
operator: ** [3967,3969]
operator: ** [3967,3969]
===
match
---
trailer [3923,3950]
trailer [3923,3950]
===
match
---
name: airflow [954,961]
name: airflow [954,961]
===
match
---
operator: , [3387,3388]
operator: , [3387,3388]
===
match
---
param [3473,3478]
param [3473,3478]
===
match
---
name: context [4688,4695]
name: context [4842,4849]
===
match
---
name: file_metadata [5077,5090]
name: file_metadata [5231,5244]
===
match
---
operator: = [5190,5191]
operator: = [5344,5345]
===
match
---
string: "google_cloud_default" [3819,3841]
string: "google_cloud_default" [3819,3841]
===
match
---
name: str [3563,3566]
name: str [3563,3566]
===
match
---
string: "object_name" [3272,3285]
string: "object_name" [3272,3285]
===
match
---
operator: , [3975,3976]
operator: , [3975,3976]
===
match
---
name: download_file [5376,5389]
name: download_file [5530,5543]
===
match
---
name: gcs [930,933]
name: gcs [930,933]
===
match
---
name: self [5140,5144]
name: self [5294,5298]
===
match
---
arglist [5390,5435]
arglist [5544,5589]
===
match
---
name: self [4505,4509]
name: self [4659,4663]
===
match
---
simple_stmt [949,1020]
simple_stmt [949,1020]
===
match
---
name: warnings [793,801]
name: warnings [793,801]
===
match
---
expr_stmt [5077,5214]
expr_stmt [5231,5368]
===
match
---
param [3498,3532]
param [3498,3532]
===
match
---
operator: , [3790,3791]
operator: , [3790,3791]
===
match
---
operator: , [3477,3478]
operator: , [3477,3478]
===
match
---
operator: = [3568,3569]
operator: = [3568,3569]
===
match
---
operator: , [3488,3489]
operator: , [3488,3489]
===
match
---
expr_stmt [4706,4888]
expr_stmt [4860,5042]
===
match
---
atom_expr [5286,5302]
atom_expr [5440,5456]
===
match
---
name: Optional [821,829]
name: Optional [821,829]
===
match
---
atom_expr [5140,5154]
atom_expr [5294,5308]
===
match
---
import_from [888,948]
import_from [888,948]
===
match
---
atom_expr [5033,5057]
atom_expr [5187,5211]
===
match
---
name: str [3723,3726]
name: str [3723,3726]
===
match
---
atom_expr [4131,4227]
atom_expr [4131,4304]
===
match
---
name: template_fields [3221,3236]
name: template_fields [3221,3236]
===
match
---
name: google [911,917]
name: google [911,917]
===
match
---
name: BaseOperator [875,887]
name: BaseOperator [875,887]
===
match
---
name: self [4803,4807]
name: self [4957,4961]
===
match
---
with_item [5228,5350]
with_item [5382,5504]
===
match
---
operator: = [3951,3952]
operator: = [3951,3952]
===
match
---
atom_expr [4853,4877]
atom_expr [5007,5031]
===
match
---
name: gcs_hook [5228,5236]
name: gcs_hook [5382,5390]
===
match
---
operator: , [5057,5058]
operator: , [5211,5212]
===
match
---
arglist [4929,5058]
arglist [5083,5212]
===
match
---
name: DeprecationWarning [4208,4226]
name: DeprecationWarning [4241,4259]
===
match
---
trailer [4735,4888]
trailer [4889,5042]
===
match
---
operator: , [3884,3885]
operator: , [3884,3885]
===
match
---
name: impersonation_chain [3894,3913]
name: impersonation_chain [3894,3913]
===
match
---
argument [4929,4957]
argument [5083,5111]
===
match
---
atom_expr [3668,3681]
atom_expr [3668,3681]
===
match
---
argument [5156,5180]
argument [5310,5334]
===
match
---
trailer [3612,3617]
trailer [3612,3617]
===
match
---
trailer [4915,5068]
trailer [5069,5222]
===
match
---
name: airflow [893,900]
name: airflow [893,900]
===
match
---
operator: = [4760,4761]
operator: = [4914,4915]
===
match
---
name: impersonation_chain [4833,4852]
name: impersonation_chain [4987,5006]
===
match
---
if_stmt [4297,4429]
if_stmt [4374,4583]
===
match
---
trailer [3929,3949]
trailer [3929,3949]
===
match
---
name: gcp_conn_id [4766,4777]
name: gcp_conn_id [4920,4931]
===
match
---
name: self [5286,5290]
name: self [5440,5444]
===
match
---
name: DeprecationWarning [4409,4427]
name: DeprecationWarning [4519,4537]
===
match
---
operator: = [4520,4521]
operator: = [4674,4675]
===
match
---
dotted_name [954,996]
dotted_name [954,996]
===
match
---
atom_expr [4000,4026]
atom_expr [4000,4026]
===
match
---
trailer [5144,5154]
trailer [5298,5308]
===
match
---
operator: -> [3983,3985]
operator: -> [3983,3985]
===
match
---
arglist [4145,4226]
arglist [4162,4290]
===
match
---
name: suite [979,984]
name: suite [979,984]
===
match
---
name: bucket_name [4040,4051]
name: bucket_name [4040,4051]
===
match
---
operator: , [5154,5155]
operator: , [5308,5309]
===
match
---
trailer [3562,3567]
trailer [3562,3567]
===
match
---
subscriptlist [3930,3948]
subscriptlist [3930,3948]
===
match
---
name: gdrive_hook [5093,5104]
name: gdrive_hook [5247,5258]
===
match
---
name: destination_bucket [4054,4072]
name: destination_bucket [4054,4072]
===
match
---
name: warn [4140,4144]
name: warn [4140,4144]
===
match
---
simple_stmt [4505,4532]
simple_stmt [4659,4686]
===
match
---
operator: = [4596,4597]
operator: = [4750,4751]
===
match
---
trailer [4765,4777]
trailer [4919,4931]
===
match
---
argument [4791,4819]
argument [4945,4973]
===
match
---
name: BaseOperator [1053,1065]
name: BaseOperator [1053,1065]
===
match
---
name: destination_bucket [3584,3602]
name: destination_bucket [3584,3602]
===
match
---
simple_stmt [4472,4497]
simple_stmt [4626,4651]
===
match
---
atom_expr [3604,3617]
atom_expr [3604,3617]
===
match
---
expr_stmt [4540,4570]
expr_stmt [4694,4724]
===
match
---
trailer [5290,5302]
trailer [5444,5456]
===
match
---
arglist [4346,4427]
arglist [4440,4568]
===
match
---
atom_expr [5364,5436]
atom_expr [5518,5590]
===
match
---
param [3967,3976]
param [3967,3976]
===
match
---
name: gcp_conn_id [4545,4556]
name: gcp_conn_id [4699,4710]
===
match
---
tfpdef [3894,3950]
tfpdef [3894,3950]
===
match
---
simple_stmt [4540,4571]
simple_stmt [4694,4725]
===
match
---
name: execute [4674,4681]
name: execute [4828,4835]
===
match
---
name: delegate_to [4971,4982]
name: delegate_to [5125,5136]
===
match
---
simple_stmt [4035,4088]
simple_stmt [4035,4088]
===
match
---
name: file_name [5171,5180]
name: file_name [5325,5334]
===
match
---
name: self [5316,5320]
name: self [5470,5474]
===
match
---
suite [4697,5437]
suite [4851,5591]
===
match
---
name: drive_id [5182,5190]
name: drive_id [5336,5344]
===
match
---
name: delegate_to [4598,4609]
name: delegate_to [4752,4763]
===
match
---
arglist [5274,5332]
arglist [5428,5486]
===
match
---
name: str [3677,3680]
name: str [3677,3680]
===
match
---
name: self [4941,4945]
name: self [5095,5099]
===
match
---
expr_stmt [4437,4463]
expr_stmt [4591,4617]
===
match
---
operator: = [4557,4558]
operator: = [4711,4712]
===
match
---
param [4688,4695]
param [4842,4849]
===
match
---
name: folder_id [3736,3745]
name: folder_id [3736,3745]
===
match
---
simple_stmt [4618,4665]
simple_stmt [4772,4819]
===
match
---
name: drive_id [5196,5204]
name: drive_id [5350,5358]
===
match
---
name: Optional [3915,3923]
name: Optional [3915,3923]
===
match
---
name: GoogleDriveToGCSOperator [1028,1052]
name: GoogleDriveToGCSOperator [1028,1052]
===
match
---
trailer [5170,5180]
trailer [5324,5334]
===
match
---
name: Optional [3511,3519]
name: Optional [3511,3519]
===
match
---
import_name [786,801]
import_name [786,801]
===
match
---
param [3648,3689]
param [3648,3689]
===
match
---
name: gdrive_hook [5364,5375]
name: gdrive_hook [5518,5529]
===
match
---
trailer [4509,4519]
trailer [4663,4673]
===
match
---
name: self [4983,4987]
name: self [5137,5141]
===
match
---
trailer [4987,4999]
trailer [5141,5153]
===
match
---
name: cloud [918,923]
name: cloud [918,923]
===
match
---
operator: = [5032,5033]
operator: = [5186,5187]
===
match
---
atom_expr [5228,5342]
atom_expr [5382,5496]
===
match
---
suite [5351,5437]
suite [5505,5591]
===
match
---
name: drive_id [3760,3768]
name: drive_id [3760,3768]
===
match
---
atom_expr [4332,4428]
atom_expr [4409,4582]
===
match
---
name: self [5033,5037]
name: self [5187,5191]
===
match
---
tfpdef [3800,3816]
tfpdef [3800,3816]
===
match
---
name: gcp_conn_id [4749,4760]
name: gcp_conn_id [4903,4914]
===
match
---
name: models [861,867]
name: models [861,867]
===
match
---
name: self [4035,4039]
name: self [4035,4039]
===
match
---
tfpdef [3712,3726]
tfpdef [3712,3726]
===
match
---
name: impersonation_chain [5038,5057]
name: impersonation_chain [5192,5211]
===
match
---
operator: , [839,840]
operator: , [839,840]
===
match
---
name: Sequence [3935,3943]
name: Sequence [3935,3943]
===
match
---
operator: , [3957,3958]
operator: , [3957,3958]
===
match
---
name: Union [3924,3929]
name: Union [3924,3929]
===
match
---
operator: , [4957,4958]
operator: , [5111,5112]
===
match
---
arglist [5130,5204]
arglist [5284,5358]
===
match
---
name: self [4853,4857]
name: self [5007,5011]
===
insert-node
---
operator: , [4259,4260]
to
arglist [4145,4226]
at 3
===
insert-tree
---
argument [4277,4289]
    name: stacklevel [4277,4287]
    operator: = [4287,4288]
    number: 2 [4288,4289]
to
arglist [4145,4226]
at 4
===
insert-node
---
operator: , [4289,4290]
to
arglist [4145,4226]
at 5
===
insert-node
---
operator: , [4537,4538]
to
arglist [4346,4427]
at 3
===
insert-tree
---
argument [4555,4567]
    name: stacklevel [4555,4565]
    operator: = [4565,4566]
    number: 2 [4566,4567]
to
arglist [4346,4427]
at 4
===
insert-node
---
operator: , [4567,4568]
to
arglist [4346,4427]
at 5
