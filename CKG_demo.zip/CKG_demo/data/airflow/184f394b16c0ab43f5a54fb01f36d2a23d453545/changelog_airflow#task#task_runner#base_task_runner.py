===
match
---
dotted_name [1000,1018]
dotted_name [1000,1018]
===
match
---
trailer [2010,2022]
trailer [2010,2022]
===
match
---
except_clause [2177,2206]
except_clause [2177,2206]
===
match
---
trailer [6899,6904]
trailer [6899,6904]
===
match
---
trailer [3893,3911]
trailer [3893,3911]
===
match
---
name: log [5541,5544]
name: log [5541,5544]
===
match
---
operator: , [2997,2998]
operator: , [2997,2998]
===
match
---
name: pythonpath_value [3256,3272]
name: pythonpath_value [3256,3272]
===
match
---
name: load_error_file [1089,1104]
name: load_error_file [1089,1104]
===
match
---
name: PYTHONPATH_VAR [1312,1326]
name: PYTHONPATH_VAR [1312,1326]
===
match
---
string: "Planning to run as the %s user" [2405,2437]
string: "Planning to run as the %s user" [2405,2437]
===
match
---
param [4550,4554]
param [4550,4554]
===
match
---
operator: = [5994,5995]
operator: = [5994,5995]
===
match
---
operator: , [5138,5139]
operator: , [5138,5139]
===
match
---
simple_stmt [6987,7013]
simple_stmt [6987,7013]
===
match
---
operator: , [5014,5015]
operator: , [5014,5015]
===
match
---
name: call [6900,6904]
name: call [6900,6904]
===
match
---
string: """Start running the task instance in a subprocess.""" [6208,6262]
string: """Start running the task instance in a subprocess.""" [6208,6262]
===
match
---
suite [1993,2057]
suite [1993,2057]
===
match
---
except_clause [3936,3951]
except_clause [3936,3951]
===
match
---
string: 'PYTHONPATH' [1329,1341]
string: 'PYTHONPATH' [1329,1341]
===
match
---
name: airflow [1054,1061]
name: airflow [1054,1061]
===
match
---
name: run_as_user [2444,2455]
name: run_as_user [2444,2455]
===
match
---
trailer [5849,5857]
trailer [5849,5857]
===
match
---
name: threading [5996,6005]
name: threading [5996,6005]
===
match
---
name: self [5597,5601]
name: self [5597,5601]
===
match
---
operator: , [2988,2989]
operator: , [2988,2989]
===
match
---
if_stmt [1958,2248]
if_stmt [1958,2248]
===
match
---
trailer [4156,4426]
trailer [4156,4426]
===
match
---
trailer [7037,7043]
trailer [7054,7060]
===
match
---
simple_stmt [6889,6953]
simple_stmt [6889,6953]
===
match
---
atom_expr [5847,5864]
atom_expr [5847,5864]
===
match
---
name: run_as_user [2045,2056]
name: run_as_user [2045,2056]
===
match
---
simple_stmt [4792,4817]
simple_stmt [4792,4817]
===
match
---
atom_expr [3132,3166]
atom_expr [3132,3166]
===
match
---
suite [4759,5154]
suite [4759,5154]
===
match
---
trailer [2228,2240]
trailer [2228,2240]
===
match
---
name: append [3304,3310]
name: append [3304,3310]
===
match
---
name: Popen [5663,5668]
name: Popen [5663,5668]
===
match
---
name: models [1062,1068]
name: models [1062,1068]
===
match
---
atom_expr [4880,4900]
atom_expr [4880,4900]
===
match
---
string: 'Running: %s' [5611,5624]
string: 'Running: %s' [5611,5624]
===
match
---
name: pool [4352,4356]
name: pool [4352,4356]
===
match
---
argument [6026,6053]
argument [6026,6053]
===
match
---
operator: + [4119,4120]
operator: + [4119,4120]
===
match
---
atom_expr [6106,6123]
atom_expr [6106,6123]
===
match
---
atom_expr [4121,4426]
atom_expr [4121,4426]
===
match
---
atom_expr [6139,6157]
atom_expr [6139,6157]
===
match
---
atom_expr [5889,5898]
atom_expr [5889,5898]
===
match
---
trailer [5857,5862]
trailer [5857,5862]
===
match
---
string: "Running on host: %s" [5550,5571]
string: "Running on host: %s" [5550,5571]
===
match
---
trailer [4891,4900]
trailer [4891,4900]
===
match
---
name: self [5536,5540]
name: self [5536,5540]
===
match
---
trailer [4067,4076]
trailer [4067,4076]
===
match
---
import_from [1049,1104]
import_from [1049,1104]
===
match
---
or_test [5468,5482]
or_test [5468,5482]
===
match
---
atom_expr [6855,6871]
atom_expr [6855,6871]
===
match
---
simple_stmt [4499,4519]
simple_stmt [4499,4519]
===
match
---
operator: , [4182,4183]
operator: , [4182,4183]
===
match
---
expr_stmt [1871,1921]
expr_stmt [1871,1921]
===
match
---
name: info [4969,4973]
name: info [4969,4973]
===
match
---
import_from [1168,1224]
import_from [1168,1224]
===
match
---
operator: + [5511,5512]
operator: + [5511,5512]
===
match
---
expr_stmt [5491,5526]
expr_stmt [5491,5526]
===
match
---
name: Optional [939,947]
name: Optional [939,947]
===
match
---
trailer [2494,2506]
trailer [2494,2506]
===
match
---
atom_expr [6789,6803]
atom_expr [6789,6803]
===
match
---
trailer [6793,6803]
trailer [6793,6803]
===
match
---
simple_stmt [1225,1268]
simple_stmt [1225,1268]
===
match
---
atom_expr [5652,5909]
atom_expr [5652,5909]
===
match
---
trailer [5668,5909]
trailer [5668,5909]
===
match
---
string: 'core' [2132,2138]
string: 'core' [2132,2138]
===
match
---
name: PYTHONPATH_VAR [3147,3161]
name: PYTHONPATH_VAR [3147,3161]
===
match
---
name: tmp_configuration_copy [3695,3717]
name: tmp_configuration_copy [3695,3717]
===
match
---
name: run_as_user [3899,3910]
name: run_as_user [3899,3910]
===
match
---
trailer [4701,4719]
trailer [4701,4719]
===
match
---
operator: = [2023,2024]
operator: = [2023,2024]
===
match
---
name: run_as_user [2229,2240]
name: run_as_user [2229,2240]
===
match
---
name: utils [1118,1123]
name: utils [1118,1123]
===
match
---
name: configuration [1124,1137]
name: configuration [1124,1137]
===
match
---
atom_expr [3759,3790]
atom_expr [3759,3790]
===
match
---
name: self [3802,3806]
name: self [3802,3806]
===
match
---
atom_expr [6073,6084]
atom_expr [6073,6084]
===
match
---
expr_stmt [2006,2056]
expr_stmt [2006,2056]
===
match
---
operator: , [4234,4235]
operator: , [4234,4235]
===
match
---
operator: , [5801,5802]
operator: , [5801,5802]
===
match
---
name: _cfg_path [6925,6934]
name: _cfg_path [6925,6934]
===
match
---
name: local_task_job [1893,1907]
name: local_task_job [1893,1907]
===
match
---
name: self [2468,2472]
name: self [2468,2472]
===
match
---
operator: , [6918,6919]
operator: , [6918,6919]
===
match
---
operator: = [6124,6125]
operator: = [6124,6125]
===
match
---
expr_stmt [1312,1341]
expr_stmt [1312,1341]
===
match
---
operator: , [947,948]
operator: , [947,948]
===
match
---
expr_stmt [4792,4816]
expr_stmt [4792,4816]
===
match
---
operator: } [3347,3348]
operator: } [3347,3348]
===
match
---
funcdef [1696,4519]
funcdef [1696,4519]
===
match
---
operator: { [3330,3331]
operator: { [3330,3331]
===
match
---
testlist_comp [2982,3025]
testlist_comp [2982,3025]
===
match
---
name: threading [845,854]
name: threading [845,854]
===
match
---
atom_expr [5536,5588]
atom_expr [5536,5588]
===
match
---
atom_expr [6889,6952]
atom_expr [6889,6952]
===
match
---
simple_stmt [7021,7046]
simple_stmt [7038,7063]
===
match
---
suite [1379,7046]
suite [1379,7205]
===
match
---
simple_stmt [2965,3044]
simple_stmt [2965,3044]
===
match
---
dotted_name [961,982]
dotted_name [961,982]
===
match
---
param [5175,5180]
param [5175,5180]
===
match
---
atom_expr [1833,1861]
atom_expr [1833,1861]
===
match
---
name: rstrip [5126,5132]
name: rstrip [5126,5132]
===
match
---
atom [1947,1949]
atom [1947,1949]
===
match
---
name: full_cmd [5491,5499]
name: full_cmd [5491,5499]
===
match
---
trailer [5605,5610]
trailer [5605,5610]
===
match
---
name: local_task_job [4265,4279]
name: local_task_job [4265,4279]
===
match
---
name: env [5843,5846]
name: env [5843,5846]
===
match
---
suite [4925,4948]
suite [4925,4948]
===
match
---
operator: = [4077,4078]
operator: = [4077,4078]
===
match
---
name: Optional [6329,6337]
name: Optional [6329,6337]
===
match
---
operator: = [3723,3724]
operator: = [3723,3724]
===
match
---
name: proc [5645,5649]
name: proc [5645,5649]
===
match
---
name: airflow [1000,1007]
name: airflow [1000,1007]
===
match
---
atom_expr [3740,3756]
atom_expr [3740,3756]
===
match
---
operator: = [3784,3785]
operator: = [3784,3785]
===
match
---
trailer [4573,4589]
trailer [4573,4589]
===
match
---
name: pickle_id [4225,4234]
name: pickle_id [4225,4234]
===
match
---
name: run_as_user [2109,2120]
name: run_as_user [2109,2120]
===
match
---
operator: , [5058,5059]
operator: , [5058,5059]
===
match
---
expr_stmt [3179,3239]
expr_stmt [3179,3239]
===
match
---
name: NotImplementedError [6277,6296]
name: NotImplementedError [6277,6296]
===
match
---
argument [3778,3789]
argument [3778,3789]
===
match
---
operator: , [3161,3162]
operator: , [3161,3162]
===
match
---
name: path [6811,6815]
name: path [6811,6815]
===
match
---
simple_stmt [6106,6131]
simple_stmt [6106,6131]
===
match
---
operator: , [4456,4457]
operator: , [4456,4457]
===
match
---
name: self [4960,4964]
name: self [4960,4964]
===
match
---
simple_stmt [6642,6670]
simple_stmt [6642,6670]
===
match
---
simple_stmt [6166,6178]
simple_stmt [6166,6178]
===
match
---
trailer [6810,6815]
trailer [6810,6815]
===
match
---
arglist [4174,4412]
arglist [4174,4412]
===
match
---
atom [4441,4480]
atom [4441,4480]
===
match
---
operator: = [6946,6947]
operator: = [6946,6947]
===
match
---
arglist [3147,3165]
arglist [3147,3165]
===
match
---
funcdef [6183,6299]
funcdef [6183,6299]
===
match
---
if_stmt [3253,3351]
if_stmt [3253,3351]
===
match
---
name: subprocess [5747,5757]
name: subprocess [5747,5757]
===
match
---
operator: = [2241,2242]
operator: = [2241,2242]
===
match
---
name: self [6855,6859]
name: self [6855,6859]
===
match
---
name: daemon [6117,6123]
name: daemon [6117,6123]
===
match
---
subscriptlist [4574,4588]
subscriptlist [4574,4588]
===
match
---
simple_stmt [5536,5589]
simple_stmt [5536,5589]
===
match
---
atom_expr [4317,4334]
atom_expr [4317,4334]
===
match
---
parameters [6688,6694]
parameters [6688,6694]
===
match
---
atom_expr [4686,4719]
atom_expr [4686,4719]
===
match
---
name: cfg_path [4046,4054]
name: cfg_path [4046,4054]
===
match
---
argument [4174,4182]
argument [4174,4182]
===
match
---
trailer [1965,1980]
trailer [1965,1980]
===
match
---
atom_expr [1816,1862]
atom_expr [1816,1862]
===
match
---
name: net [1244,1247]
name: net [1244,1247]
===
match
---
name: os [6987,6989]
name: os [6987,6989]
===
match
---
expr_stmt [2224,2247]
expr_stmt [2224,2247]
===
match
---
trailer [2404,2456]
trailer [2404,2456]
===
match
---
name: local_task_job [1833,1847]
name: local_task_job [1833,1847]
===
match
---
name: info [5606,5610]
name: info [5606,5610]
===
match
---
atom_expr [5032,5058]
atom_expr [5032,5058]
===
match
---
name: chmod [3718,3723]
name: chmod [3718,3723]
===
match
---
atom_expr [4559,4590]
atom_expr [4559,4590]
===
match
---
arith_expr [4093,4480]
arith_expr [4093,4480]
===
match
---
arglist [6026,6087]
arglist [6026,6087]
===
match
---
name: log [4965,4968]
name: log [4965,4968]
===
match
---
trailer [1847,1861]
trailer [1847,1861]
===
match
---
trailer [6822,6838]
trailer [6822,6838]
===
match
---
trailer [3744,3756]
trailer [3744,3756]
===
match
---
name: KeyError [3943,3951]
name: KeyError [3943,3951]
===
match
---
simple_stmt [1931,1950]
simple_stmt [1931,1950]
===
match
---
name: self [4063,4067]
name: self [4063,4067]
===
match
---
trailer [4567,4590]
trailer [4567,4590]
===
match
---
name: Exception [4579,4588]
name: Exception [4579,4588]
===
match
---
expr_stmt [3684,3730]
expr_stmt [3684,3730]
===
match
---
trailer [5721,5726]
trailer [5721,5726]
===
match
---
name: self [4745,4749]
name: self [4745,4749]
===
match
---
arglist [6905,6951]
arglist [6905,6951]
===
match
---
name: task_instance [1908,1921]
name: task_instance [1908,1921]
===
match
---
name: readline [4806,4814]
name: readline [4806,4814]
===
match
---
atom_expr [3894,3910]
atom_expr [3894,3910]
===
match
---
name: tempfile [885,893]
name: tempfile [885,893]
===
match
---
name: self [1709,1713]
name: self [1709,1713]
===
match
---
atom_expr [6526,6547]
atom_expr [6526,6547]
===
match
---
suite [3365,3731]
suite [3365,3731]
===
match
---
operator: = [3693,3694]
operator: = [3693,3694]
===
match
---
trailer [2394,2398]
trailer [2394,2398]
===
match
---
atom_expr [5513,5526]
atom_expr [5513,5526]
===
match
---
operator: , [4847,4848]
operator: , [4847,4848]
===
match
---
name: terminate [6557,6566]
name: terminate [6557,6566]
===
match
---
expr_stmt [3740,3790]
expr_stmt [3740,3790]
===
match
---
name: airflow [1230,1237]
name: airflow [1230,1237]
===
match
---
operator: = [5796,5797]
operator: = [5796,5797]
===
match
---
name: chmod [2864,2869]
name: chmod [2864,2869]
===
match
---
string: '-H' [3210,3214]
string: '-H' [3210,3214]
===
match
---
name: environ [3135,3142]
name: environ [3135,3142]
===
match
---
string: '\n' [5133,5137]
string: '\n' [5133,5137]
===
match
---
name: task_id [5096,5103]
name: task_id [5096,5103]
===
match
---
trailer [4033,4043]
trailer [4033,4043]
===
match
---
argument [4352,4376]
argument [4352,4376]
===
match
---
name: _read_task_logs [6038,6053]
name: _read_task_logs [6038,6053]
===
match
---
operator: = [5466,5467]
operator: = [5466,5467]
===
match
---
argument [6937,6951]
argument [6937,6951]
===
match
---
operator: = [2869,2870]
operator: = [2869,2870]
===
match
---
name: run_as_user [3004,3015]
name: run_as_user [3004,3015]
===
match
---
suite [2070,2248]
suite [2070,2248]
===
match
---
operator: , [3220,3221]
operator: , [3220,3221]
===
match
---
string: 'sudo' [6906,6912]
string: 'sudo' [6906,6912]
===
match
---
trailer [6859,6871]
trailer [6859,6871]
===
match
---
if_stmt [6852,7013]
if_stmt [6852,7013]
===
match
---
name: run_as_user [2473,2484]
name: run_as_user [2473,2484]
===
match
---
trailer [3866,3878]
trailer [3866,3878]
===
match
---
atom_expr [3853,3923]
atom_expr [3853,3923]
===
match
---
name: local_task_job [4317,4331]
name: local_task_job [4317,4331]
===
match
---
name: mark_success [4280,4292]
name: mark_success [4280,4292]
===
match
---
name: name [4475,4479]
name: name [4475,4479]
===
match
---
expr_stmt [4873,4900]
expr_stmt [4873,4900]
===
match
---
trailer [4805,4814]
trailer [4805,4814]
===
match
---
name: getpwnam [3885,3893]
name: getpwnam [3885,3893]
===
match
---
trailer [5080,5095]
trailer [5080,5095]
===
match
---
atom_expr [5747,5764]
atom_expr [5747,5764]
===
match
---
string: """         Run the task command.          :param run_with: list of tokens to run the task command with e.g. ``['bash', '-c']``         :type run_with: list         :return: the process that was run         :rtype: subprocess.Popen         """ [5205,5448]
string: """         Run the task command.          :param run_with: list of tokens to run the task command with e.g. ``['bash', '-c']``         :type run_with: list         :return: the process that was run         :rtype: subprocess.Popen         """ [5205,5448]
===
match
---
string: "--error-file" [4442,4456]
string: "--error-file" [4442,4456]
===
match
---
atom_expr [2841,2876]
atom_expr [2841,2876]
===
match
---
trailer [6996,7012]
trailer [6996,7012]
===
match
---
atom_expr [6987,7012]
atom_expr [6987,7012]
===
match
---
name: subprocess [827,837]
name: subprocess [827,837]
===
match
---
name: self [6033,6037]
name: self [6033,6037]
===
match
---
import_from [1225,1267]
import_from [1225,1267]
===
match
---
atom_expr [4210,4234]
atom_expr [4210,4234]
===
match
---
operator: = [4878,4879]
operator: = [4878,4879]
===
match
---
trailer [6667,6669]
trailer [6667,6669]
===
match
---
trailer [2980,3043]
trailer [2980,3043]
===
match
---
name: _task_instance [1876,1890]
name: _task_instance [1876,1890]
===
match
---
name: popen_prepend [3290,3303]
name: popen_prepend [3290,3303]
===
match
---
name: debug [2399,2404]
name: debug [2399,2404]
===
match
---
import_from [880,919]
import_from [880,919]
===
match
---
simple_stmt [995,1049]
simple_stmt [995,1049]
===
match
---
suite [6839,7013]
suite [6839,7013]
===
match
---
trailer [6924,6934]
trailer [6924,6934]
===
match
---
name: _cfg_path [7002,7011]
name: _cfg_path [7002,7011]
===
match
---
file_input [787,7046]
file_input [787,7205]
===
match
---
operator: -> [6573,6575]
operator: -> [6573,6575]
===
match
---
operator: , [5898,5899]
operator: , [5898,5899]
===
match
---
name: pw_uid [3912,3918]
name: pw_uid [3912,3918]
===
match
---
name: task_instance [1848,1861]
name: task_instance [1848,1861]
===
match
---
atom_expr [5573,5587]
atom_expr [5573,5587]
===
match
---
if_stmt [2465,3731]
if_stmt [2465,3731]
===
match
---
name: os [817,819]
name: os [817,819]
===
match
---
name: run_command [5163,5174]
name: run_command [5163,5174]
===
match
---
suite [2087,2165]
suite [2087,2165]
===
match
---
testlist_comp [6906,6934]
testlist_comp [6906,6934]
===
match
---
name: remove [6990,6996]
name: remove [6990,6996]
===
match
---
simple_stmt [5491,5527]
simple_stmt [5491,5527]
===
match
---
name: PYTHONPATH_VAR [3314,3328]
name: PYTHONPATH_VAR [3314,3328]
===
match
---
dotted_name [1273,1295]
dotted_name [1273,1295]
===
match
---
if_stmt [3799,4020]
if_stmt [3799,4020]
===
match
---
name: full_cmd [5682,5690]
name: full_cmd [5682,5690]
===
match
---
trailer [6037,6053]
trailer [6037,6053]
===
match
---
raise_stmt [6520,6547]
raise_stmt [6520,6547]
===
match
---
simple_stmt [2830,2877]
simple_stmt [2830,2877]
===
match
---
name: pythonpath_value [3331,3347]
name: pythonpath_value [3331,3347]
===
match
---
operator: = [2121,2122]
operator: = [2121,2122]
===
match
---
dotted_name [1054,1081]
dotted_name [1054,1081]
===
match
---
name: taskinstance [1069,1081]
name: taskinstance [1069,1081]
===
match
---
trailer [5544,5549]
trailer [5544,5549]
===
match
---
name: start [6187,6192]
name: start [6187,6192]
===
match
---
name: cfg_path [3684,3692]
name: cfg_path [3684,3692]
===
match
---
trailer [2127,2131]
trailer [2127,2131]
===
match
---
expr_stmt [2104,2164]
expr_stmt [2104,2164]
===
match
---
trailer [6155,6157]
trailer [6155,6157]
===
match
---
trailer [7025,7037]
trailer [7042,7054]
===
match
---
expr_stmt [3113,3166]
expr_stmt [3113,3166]
===
match
---
name: self [6920,6924]
name: self [6920,6924]
===
match
---
trailer [6815,6822]
trailer [6815,6822]
===
match
---
import_name [838,854]
import_name [838,854]
===
match
---
operator: = [5824,5825]
operator: = [5824,5825]
===
match
---
trailer [4371,4376]
trailer [4371,4376]
===
match
---
simple_stmt [1384,1691]
simple_stmt [1384,1691]
===
match
---
trailer [5095,5103]
trailer [5095,5103]
===
match
---
trailer [6296,6298]
trailer [6296,6298]
===
match
---
operator: = [6032,6033]
operator: = [6032,6033]
===
match
---
simple_stmt [787,810]
simple_stmt [787,810]
===
match
---
trailer [3806,3818]
trailer [3806,3818]
===
match
---
atom_expr [2439,2455]
atom_expr [2439,2455]
===
match
---
and_test [6789,6838]
and_test [6789,6838]
===
match
---
trailer [4125,4140]
trailer [4125,4140]
===
match
---
name: super [1816,1821]
name: super [1816,1821]
===
match
---
trailer [1823,1832]
trailer [1823,1832]
===
match
---
simple_stmt [5645,5910]
simple_stmt [5645,5910]
===
match
---
atom_expr [3885,3918]
atom_expr [3885,3918]
===
match
---
atom_expr [1961,1992]
atom_expr [1961,1992]
===
match
---
testlist_comp [6073,6085]
testlist_comp [6073,6085]
===
match
---
name: full_cmd [5626,5634]
name: full_cmd [5626,5634]
===
match
---
simple_stmt [1268,1311]
simple_stmt [1268,1311]
===
match
---
trailer [6149,6155]
trailer [6149,6155]
===
match
---
simple_stmt [6208,6263]
simple_stmt [6208,6263]
===
match
---
operator: = [4209,4210]
operator: = [4209,4210]
===
match
---
simple_stmt [2224,2248]
simple_stmt [2224,2248]
===
match
---
name: self [2439,2443]
name: self [2439,2443]
===
match
---
name: command_as_list [4141,4156]
name: command_as_list [4141,4156]
===
match
---
name: LoggingMixin [1365,1377]
name: LoggingMixin [1365,1377]
===
match
---
name: airflow [961,968]
name: airflow [961,968]
===
match
---
arglist [2132,2163]
arglist [2132,2163]
===
match
---
operator: + [4439,4440]
operator: + [4439,4440]
===
match
---
trailer [5610,5635]
trailer [5610,5635]
===
match
---
dotted_name [1173,1204]
dotted_name [1173,1204]
===
match
---
name: run_as_user [1981,1992]
name: run_as_user [1981,1992]
===
match
---
trailer [5051,5058]
trailer [5051,5058]
===
match
---
atom_expr [2006,2022]
atom_expr [2006,2022]
===
match
---
simple_stmt [820,838]
simple_stmt [820,838]
===
match
---
string: 'rm' [6914,6918]
string: 'rm' [6914,6918]
===
match
---
try_stmt [3832,4020]
try_stmt [3832,4020]
===
match
---
operator: , [6053,6054]
operator: , [6053,6054]
===
match
---
raise_stmt [6642,6669]
raise_stmt [6642,6669]
===
match
---
string: """     Runs Airflow task instances by invoking the `airflow tasks run` command with raw     mode enabled in a subprocess.      :param local_task_job: The local task job associated with running the         associated task instance.     :type local_task_job: airflow.jobs.local_task_job.LocalTaskJob     """ [1384,1690]
string: """     Runs Airflow task instances by invoking the `airflow tasks run` command with raw     mode enabled in a subprocess.      :param local_task_job: The local task job associated with running the         associated task instance.     :type local_task_job: airflow.jobs.local_task_job.LocalTaskJob     """ [1384,1690]
===
match
---
name: bytes [4849,4854]
name: bytes [4849,4854]
===
match
---
name: os [3853,3855]
name: os [3853,3855]
===
match
---
name: self [5076,5080]
name: self [5076,5080]
===
match
---
name: BaseTaskRunner [1350,1364]
name: BaseTaskRunner [1350,1364]
===
match
---
if_stmt [4913,4948]
if_stmt [4913,4948]
===
match
---
not_test [4916,4924]
not_test [4916,4924]
===
match
---
operator: , [4334,4335]
operator: , [4334,4335]
===
match
---
argument [5740,5764]
argument [5740,5764]
===
match
---
arglist [3862,3922]
arglist [3862,3922]
===
match
---
string: """A callback that should be called when this is done running.""" [6712,6777]
string: """A callback that should be called when this is done running.""" [6712,6777]
===
match
---
suite [4779,5154]
suite [4779,5154]
===
match
---
name: raw [4174,4177]
name: raw [4174,4177]
===
match
---
operator: , [5829,5830]
operator: , [5829,5830]
===
match
---
atom_expr [5996,6097]
atom_expr [5996,6097]
===
match
---
name: get [3143,3146]
name: get [3143,3146]
===
match
---
operator: = [4797,4798]
operator: = [4797,4798]
===
match
---
name: _task_instance [1966,1980]
name: _task_instance [1966,1980]
===
match
---
atom_expr [6920,6934]
atom_expr [6920,6934]
===
match
---
name: run_as_user [6860,6871]
name: run_as_user [6860,6871]
===
match
---
trailer [3878,3883]
trailer [3878,3883]
===
match
---
name: utils [1181,1186]
name: utils [1181,1186]
===
match
---
argument [5778,5801]
argument [5778,5801]
===
match
---
name: args [6067,6071]
name: args [6067,6071]
===
match
---
atom_expr [6277,6298]
atom_expr [6277,6298]
===
match
---
operator: = [5189,5190]
operator: = [5189,5190]
===
match
---
trailer [2108,2120]
trailer [2108,2120]
===
match
---
name: logging_mixin [1191,1204]
name: logging_mixin [1191,1204]
===
match
---
trailer [3146,3166]
trailer [3146,3166]
===
match
---
atom_expr [4499,4511]
atom_expr [4499,4511]
===
match
---
simple_stmt [920,955]
simple_stmt [920,955]
===
match
---
name: int [6338,6341]
name: int [6338,6341]
===
match
---
name: line [4792,4796]
name: line [4792,4796]
===
match
---
parameters [6192,6198]
parameters [6192,6198]
===
match
---
simple_stmt [6139,6158]
simple_stmt [6139,6158]
===
match
---
trailer [5862,5864]
trailer [5862,5864]
===
match
---
atom [6072,6086]
atom [6072,6086]
===
match
---
and_test [2468,2520]
and_test [2468,2520]
===
match
---
operator: , [4577,4578]
operator: , [4577,4578]
===
match
---
funcdef [6553,6670]
funcdef [6553,6670]
===
match
---
name: Optional [4559,4567]
name: Optional [4559,4567]
===
match
---
name: run_with [5502,5510]
name: run_with [5502,5510]
===
match
---
atom_expr [6997,7011]
atom_expr [6997,7011]
===
match
---
name: self [4550,4554]
name: self [4550,4554]
===
match
---
fstring_expr [3313,3329]
fstring_expr [3313,3329]
===
match
---
argument [5878,5898]
argument [5878,5898]
===
match
---
atom [3195,3239]
atom [3195,3239]
===
match
---
argument [5843,5864]
argument [5843,5864]
===
match
---
simple_stmt [956,995]
simple_stmt [956,995]
===
match
---
name: log_reader [6106,6116]
name: log_reader [6106,6116]
===
match
---
funcdef [4524,4720]
funcdef [4524,4720]
===
match
---
atom_expr [3802,3818]
atom_expr [3802,3818]
===
match
---
suite [6343,6548]
suite [6343,6548]
===
match
---
expr_stmt [4063,4490]
expr_stmt [4063,4490]
===
match
---
name: NotImplementedError [6526,6545]
name: NotImplementedError [6526,6545]
===
match
---
name: _error_file [4463,4474]
name: _error_file [4463,4474]
===
match
---
operator: , [6086,6087]
operator: , [6086,6087]
===
match
---
param [5181,5194]
param [5181,5194]
===
match
---
argument [2864,2875]
argument [2864,2875]
===
match
---
simple_stmt [1049,1105]
simple_stmt [1049,1105]
===
match
---
arglist [5682,5899]
arglist [5682,5899]
===
match
---
simple_stmt [5983,6098]
simple_stmt [5983,6098]
===
match
---
number: 0o600 [3724,3729]
number: 0o600 [3724,3729]
===
match
---
string: '-u' [3216,3220]
string: '-u' [3216,3220]
===
match
---
name: mark_success [4252,4264]
name: mark_success [4252,4264]
===
match
---
operator: , [5624,5625]
operator: , [5624,5625]
===
match
---
name: os [5889,5891]
name: os [5889,5891]
===
match
---
name: self [5513,5517]
name: self [5513,5517]
===
match
---
name: self [2006,2010]
name: self [2006,2010]
===
match
---
dotted_name [1230,1247]
dotted_name [1230,1247]
===
match
---
name: _task_instance [5037,5051]
name: _task_instance [5037,5051]
===
match
---
atom_expr [6648,6669]
atom_expr [6648,6669]
===
match
---
param [1715,1729]
param [1715,1729]
===
match
---
atom_expr [2965,3043]
atom_expr [2965,3043]
===
match
---
name: log [5602,5605]
name: log [5602,5605]
===
match
---
atom_expr [6033,6053]
atom_expr [6033,6053]
===
match
---
name: STDOUT [5758,5764]
name: STDOUT [5758,5764]
===
match
---
while_stmt [4768,5154]
while_stmt [4768,5154]
===
match
---
return_stmt [4679,4719]
return_stmt [4679,4719]
===
match
---
operator: , [6912,6913]
operator: , [6912,6913]
===
match
---
suite [4591,4720]
suite [4591,4720]
===
match
---
atom_expr [2104,2120]
atom_expr [2104,2120]
===
match
---
name: self [4499,4503]
name: self [4499,4503]
===
match
---
trailer [5757,5764]
trailer [5757,5764]
===
match
---
atom_expr [5076,5103]
atom_expr [5076,5103]
===
match
---
string: 'default_impersonation' [2140,2163]
string: 'default_impersonation' [2140,2163]
===
match
---
trailer [5517,5526]
trailer [5517,5526]
===
match
---
import_name [820,837]
import_name [820,837]
===
match
---
trailer [5132,5138]
trailer [5132,5138]
===
match
---
name: proc [6073,6077]
name: proc [6073,6077]
===
match
---
suite [4856,4901]
suite [4856,4901]
===
match
---
trailer [5549,5588]
trailer [5549,5588]
===
match
---
atom_expr [1871,1890]
atom_expr [1871,1890]
===
match
---
operator: } [3328,3329]
operator: } [3328,3329]
===
match
---
name: self [6997,7001]
name: self [6997,7001]
===
match
---
atom_expr [4458,4479]
atom_expr [4458,4479]
===
match
---
trailer [2029,2044]
trailer [2029,2044]
===
match
---
simple_stmt [3290,3351]
simple_stmt [3290,3351]
===
match
---
name: cfg_path [4394,4402]
name: cfg_path [4394,4402]
===
match
---
name: airflow [1273,1280]
name: airflow [1273,1280]
===
match
---
trailer [1875,1890]
trailer [1875,1890]
===
match
---
atom [4079,4490]
atom [4079,4490]
===
match
---
import_from [1105,1167]
import_from [1105,1167]
===
match
---
operator: , [3026,3027]
operator: , [3026,3027]
===
match
---
operator: , [3918,3919]
operator: , [3918,3919]
===
match
---
name: self [6789,6793]
name: self [6789,6793]
===
match
---
trailer [2131,2164]
trailer [2131,2164]
===
match
---
name: decode [4885,4891]
name: decode [4885,4891]
===
match
---
import_from [995,1048]
import_from [995,1048]
===
match
---
name: proc [6173,6177]
name: proc [6173,6177]
===
match
---
fstring_start: f' [3311,3313]
fstring_start: f' [3311,3313]
===
match
---
simple_stmt [6520,6548]
simple_stmt [6520,6548]
===
match
---
atom_expr [4702,4718]
atom_expr [4702,4718]
===
match
---
name: self [2999,3003]
name: self [2999,3003]
===
match
---
arglist [2405,2455]
arglist [2405,2455]
===
match
---
operator: = [5888,5889]
operator: = [5888,5889]
===
match
---
trailer [6337,6342]
trailer [6337,6342]
===
match
---
parameters [4549,4555]
parameters [4549,4555]
===
match
---
param [1709,1714]
param [1709,1714]
===
match
---
operator: = [3037,3038]
operator: = [3037,3038]
===
match
---
operator: = [5500,5501]
operator: = [5500,5501]
===
match
---
atom_expr [4960,5153]
atom_expr [4960,5153]
===
match
---
import_from [920,954]
import_from [920,954]
===
match
---
simple_stmt [1168,1225]
simple_stmt [1168,1225]
===
match
---
trailer [1821,1823]
trailer [1821,1823]
===
match
---
simple_stmt [4942,4948]
simple_stmt [4942,4948]
===
match
---
simple_stmt [1312,1342]
simple_stmt [1312,1342]
===
match
---
name: target [6026,6032]
name: target [6026,6032]
===
match
---
trailer [6116,6123]
trailer [6116,6123]
===
match
---
simple_stmt [880,920]
simple_stmt [880,920]
===
match
---
name: tmp_configuration_copy [2841,2863]
name: tmp_configuration_copy [2841,2863]
===
match
---
trailer [4973,5153]
trailer [4973,5153]
===
match
---
name: __init__ [1700,1708]
name: __init__ [1700,1708]
===
match
---
simple_stmt [6271,6299]
simple_stmt [6271,6299]
===
match
---
atom_expr [4357,4376]
atom_expr [4357,4376]
===
match
---
name: __init__ [1824,1832]
name: __init__ [1824,1832]
===
match
---
expr_stmt [5645,5909]
expr_stmt [5645,5909]
===
match
---
name: stderr [5740,5746]
name: stderr [5740,5746]
===
match
---
atom_expr [3222,3238]
atom_expr [3222,3238]
===
match
---
name: self [2104,2108]
name: self [2104,2108]
===
match
---
import_from [956,994]
import_from [956,994]
===
match
---
argument [4252,4292]
argument [4252,4292]
===
match
---
name: run_as_user [3807,3818]
name: run_as_user [3807,3818]
===
match
---
name: cfg_path [3017,3025]
name: cfg_path [3017,3025]
===
match
---
atom_expr [6329,6342]
atom_expr [6329,6342]
===
match
---
name: self [4702,4706]
name: self [4702,4706]
===
match
---
trailer [3855,3861]
trailer [3855,3861]
===
match
---
name: delete [3778,3784]
name: delete [3778,3784]
===
match
---
name: AirflowConfigException [1026,1048]
name: AirflowConfigException [1026,1048]
===
match
---
trailer [5540,5544]
trailer [5540,5544]
===
match
---
arglist [2981,3042]
arglist [2981,3042]
===
match
---
trailer [7001,7011]
trailer [7001,7011]
===
match
---
trailer [3861,3923]
trailer [3861,3923]
===
match
---
argument [5704,5726]
argument [5704,5726]
===
match
---
name: pwd [860,863]
name: pwd [860,863]
===
match
---
name: self [4458,4462]
name: self [4458,4462]
===
match
---
name: copy [5858,5862]
name: copy [5858,5862]
===
match
---
funcdef [6304,6548]
funcdef [6304,6548]
===
match
---
atom_expr [4799,4816]
atom_expr [4799,4816]
===
match
---
name: local_task_job [1715,1729]
name: local_task_job [1715,1729]
===
match
---
operator: , [3208,3209]
operator: , [3208,3209]
===
match
---
atom [6905,6935]
atom [6905,6935]
===
match
---
operator: = [4044,4045]
operator: = [4044,4045]
===
match
---
name: os [6808,6810]
name: os [6808,6810]
===
match
---
name: _cfg_path [6828,6837]
name: _cfg_path [6828,6837]
===
match
---
name: local_task_job [4210,4224]
name: local_task_job [4210,4224]
===
match
---
dotted_name [1110,1137]
dotted_name [1110,1137]
===
match
---
name: job_id [4310,4316]
name: job_id [4310,4316]
===
match
---
param [4745,4750]
param [4745,4750]
===
match
---
name: exceptions [1008,1018]
name: exceptions [1008,1018]
===
match
---
name: line [4920,4924]
name: line [4920,4924]
===
match
---
suite [6581,6670]
suite [6581,6670]
===
match
---
trailer [4814,4816]
trailer [4814,4816]
===
match
---
trailer [2044,2056]
trailer [2044,2056]
===
match
---
name: start [6150,6155]
name: start [6150,6155]
===
match
---
name: on_finish [6679,6688]
name: on_finish [6679,6688]
===
match
---
simple_stmt [2104,2165]
simple_stmt [2104,2165]
===
match
---
name: call [2976,2980]
name: call [2976,2980]
===
match
---
trailer [3003,3015]
trailer [3003,3015]
===
match
---
name: setsid [5892,5898]
name: setsid [5892,5898]
===
match
---
arith_expr [5502,5526]
arith_expr [5502,5526]
===
match
---
atom_expr [6808,6838]
atom_expr [6808,6838]
===
match
---
simple_stmt [4015,4020]
simple_stmt [4015,4020]
===
match
---
name: _cfg_path [4034,4043]
name: _cfg_path [4034,4043]
===
match
---
name: subprocess [2965,2975]
name: subprocess [2965,2975]
===
match
---
operator: , [5764,5765]
operator: , [5764,5765]
===
match
---
argument [6067,6086]
argument [6067,6086]
===
match
---
fstring_expr [3330,3348]
fstring_expr [3330,3348]
===
match
---
operator: , [3015,3016]
operator: , [3015,3016]
===
match
---
simple_stmt [3740,3791]
simple_stmt [3740,3791]
===
match
---
atom_expr [4568,4589]
atom_expr [4568,4589]
===
match
---
name: self [2390,2394]
name: self [2390,2394]
===
match
---
trailer [2398,2404]
trailer [2398,2404]
===
match
---
atom_expr [4265,4292]
atom_expr [4265,4292]
===
match
---
simple_stmt [6712,6778]
simple_stmt [6712,6778]
===
match
---
string: """Return task runtime error if its written to provided error file.""" [4600,4670]
string: """Return task runtime error if its written to provided error file.""" [4600,4670]
===
match
---
name: tmp_configuration_copy [1145,1167]
name: tmp_configuration_copy [1145,1167]
===
match
---
expr_stmt [5983,6097]
expr_stmt [5983,6097]
===
match
---
name: self [7021,7025]
name: self [7038,7042]
===
match
---
trailer [2863,2876]
trailer [2863,2876]
===
match
---
name: self [1871,1875]
name: self [1871,1875]
===
match
---
try_stmt [2083,2248]
try_stmt [2083,2248]
===
match
---
operator: = [4512,4513]
operator: = [4512,4513]
===
match
---
name: Union [4568,4573]
name: Union [4568,4573]
===
match
---
trailer [6989,6996]
trailer [6989,6996]
===
match
---
simple_stmt [4873,4901]
simple_stmt [4873,4901]
===
match
---
trailer [4884,4891]
trailer [4884,4891]
===
match
---
name: id [4332,4334]
name: id [4332,4334]
===
match
---
trailer [2443,2455]
trailer [2443,2455]
===
match
---
trailer [5125,5132]
trailer [5125,5132]
===
match
---
name: _command [5518,5526]
name: _command [5518,5526]
===
match
---
trailer [3898,3910]
trailer [3898,3910]
===
match
---
param [6689,6693]
param [6689,6693]
===
match
---
trailer [1832,1862]
trailer [1832,1862]
===
match
---
operator: = [3757,3758]
operator: = [3757,3758]
===
match
---
operator: = [1891,1892]
operator: = [1891,1892]
===
match
---
atom_expr [5711,5726]
atom_expr [5711,5726]
===
match
---
atom_expr [7021,7045]
atom_expr [7038,7062]
===
match
---
name: close_fds [3028,3037]
name: close_fds [3028,3037]
===
match
---
operator: , [4376,4377]
operator: , [4376,4377]
===
match
---
trailer [6012,6097]
trailer [6012,6097]
===
match
---
atom [2489,2520]
atom [2489,2520]
===
match
---
suite [2521,3351]
suite [2521,3351]
===
match
---
atom_expr [4029,4043]
atom_expr [4029,4043]
===
match
---
operator: , [4292,4293]
operator: , [4292,4293]
===
match
---
suite [2207,2248]
suite [2207,2248]
===
match
---
trailer [1907,1921]
trailer [1907,1921]
===
match
---
import_from [1268,1310]
import_from [1268,1310]
===
match
---
atom_expr [5597,5635]
atom_expr [5597,5635]
===
match
---
name: self [3740,3744]
name: self [3740,3744]
===
match
---
comparison [2490,2519]
comparison [2490,2519]
===
match
---
suite [3952,4020]
suite [3952,4020]
===
match
---
trailer [6904,6952]
trailer [6904,6952]
===
match
---
param [6193,6197]
param [6193,6197]
===
match
---
name: log_reader [5983,5993]
name: log_reader [5983,5993]
===
match
---
operator: = [1945,1946]
operator: = [1945,1946]
===
match
---
string: 'sudo' [3196,3202]
string: 'sudo' [3196,3202]
===
match
---
trailer [5585,5587]
trailer [5585,5587]
===
match
---
atom_expr [3862,3883]
atom_expr [3862,3883]
===
match
---
name: self [3894,3898]
name: self [3894,3898]
===
match
---
name: self [6823,6827]
name: self [6823,6827]
===
match
---
name: _task_instance [2030,2044]
name: _task_instance [2030,2044]
===
match
---
argument [4200,4234]
argument [4200,4234]
===
match
---
simple_stmt [4600,4671]
simple_stmt [4600,4671]
===
match
---
name: stdout [6078,6084]
name: stdout [6078,6084]
===
match
---
operator: , [5103,5104]
operator: , [5103,5104]
===
match
---
trailer [6077,6084]
trailer [6077,6084]
===
match
---
atom_expr [2510,2519]
atom_expr [2510,2519]
===
match
---
name: utils [1238,1243]
name: utils [1238,1243]
===
match
---
trailer [2517,2519]
trailer [2517,2519]
===
match
---
name: conf [2123,2127]
name: conf [2123,2127]
===
match
---
name: isinstance [4832,4842]
name: isinstance [4832,4842]
===
match
---
name: _error_file [3745,3756]
name: _error_file [3745,3756]
===
match
---
operator: = [5650,5651]
operator: = [5650,5651]
===
match
---
atom_expr [2390,2456]
atom_expr [2390,2456]
===
match
---
raise_stmt [6271,6298]
raise_stmt [6271,6298]
===
match
---
name: log [2395,2398]
name: log [2395,2398]
===
match
---
name: subprocess [6889,6899]
name: subprocess [6889,6899]
===
match
---
import_from [855,879]
import_from [855,879]
===
match
---
funcdef [6675,7046]
funcdef [6675,7205]
===
match
---
operator: = [4264,4265]
operator: = [4264,4265]
===
match
---
name: utils [1281,1286]
name: utils [1281,1286]
===
match
---
name: close_fds [6937,6946]
name: close_fds [6937,6946]
===
match
---
name: run_with [5181,5189]
name: run_with [5181,5189]
===
match
---
name: _task_instance [4126,4140]
name: _task_instance [4126,4140]
===
match
---
simple_stmt [838,855]
simple_stmt [838,855]
===
match
---
atom_expr [6823,6837]
atom_expr [6823,6837]
===
match
---
name: popen_prepend [1931,1944]
name: popen_prepend [1931,1944]
===
match
---
suite [5196,6178]
suite [5196,6178]
===
match
---
funcdef [5159,6178]
funcdef [5159,6178]
===
match
---
operator: , [1713,1714]
operator: , [1713,1714]
===
match
---
name: run_with [5457,5465]
name: run_with [5457,5465]
===
match
---
name: run_as_user [3227,3238]
name: run_as_user [3227,3238]
===
match
---
name: cfg_path [2830,2838]
name: cfg_path [2830,2838]
===
match
---
name: self [4121,4125]
name: self [4121,4125]
===
match
---
name: isfile [6816,6822]
name: isfile [6816,6822]
===
match
---
name: self [6689,6693]
name: self [6689,6693]
===
match
---
trailer [5036,5051]
trailer [5036,5051]
===
match
---
simple_stmt [1871,1922]
simple_stmt [1871,1922]
===
match
---
trailer [3303,3310]
trailer [3303,3310]
===
match
---
operator: , [6084,6085]
operator: , [6084,6085]
===
match
---
simple_stmt [810,820]
simple_stmt [810,820]
===
match
---
argument [3718,3729]
argument [3718,3729]
===
match
---
name: info [5545,5549]
name: info [5545,5549]
===
match
---
trailer [1980,1992]
trailer [1980,1992]
===
match
---
arglist [5550,5587]
arglist [5550,5587]
===
match
---
argument [5815,5829]
argument [5815,5829]
===
match
---
operator: , [4749,4750]
operator: , [4749,4750]
===
match
---
name: get [2128,2131]
name: get [2128,2131]
===
match
---
atom_expr [4832,4855]
atom_expr [4832,4855]
===
match
---
operator: = [5846,5847]
operator: = [5846,5847]
===
match
---
number: 0o600 [2870,2875]
number: 0o600 [2870,2875]
===
match
---
simple_stmt [855,880]
simple_stmt [855,880]
===
match
---
name: self [2490,2494]
name: self [2490,2494]
===
match
---
name: log [1187,1190]
name: log [1187,1190]
===
match
---
trailer [2975,2980]
trailer [2975,2980]
===
match
---
atom_expr [1893,1921]
atom_expr [1893,1921]
===
match
---
name: str [4574,4577]
name: str [4574,4577]
===
match
---
expr_stmt [5457,5482]
expr_stmt [5457,5482]
===
match
---
name: _cfg_path [6794,6803]
name: _cfg_path [6794,6803]
===
match
---
suite [6970,7013]
suite [6970,7013]
===
match
---
param [6320,6324]
param [6320,6324]
===
match
---
atom_expr [3695,3730]
atom_expr [3695,3730]
===
match
---
name: environ [5850,5857]
name: environ [5850,5857]
===
match
---
name: _error_file [7026,7037]
name: _error_file [7043,7054]
===
match
---
operator: , [2138,2139]
operator: , [2138,2139]
===
match
---
name: self [3862,3866]
name: self [3862,3866]
===
match
---
trailer [4462,4474]
trailer [4462,4474]
===
match
---
name: run_with [5468,5476]
name: run_with [5468,5476]
===
match
---
fstring_string: = [3329,3330]
fstring_string: = [3329,3330]
===
match
---
funcdef [4725,5154]
funcdef [4725,5154]
===
match
---
simple_stmt [5205,5449]
simple_stmt [5205,5449]
===
match
---
argument [4310,4334]
argument [4310,4334]
===
match
---
string: """         :return: The return code associated with running the task instance or             None if the task is not yet done.         :rtype: int         """ [6352,6511]
string: """         :return: The return code associated with running the task instance or             None if the task is not yet done.         :rtype: int         """ [6352,6511]
===
match
---
name: getpwnam [871,879]
name: getpwnam [871,879]
===
match
---
name: line [4880,4884]
name: line [4880,4884]
===
match
---
expr_stmt [4029,4054]
expr_stmt [4029,4054]
===
match
---
name: name [3879,3883]
name: name [3879,3883]
===
match
---
name: pickle_id [4200,4209]
name: pickle_id [4200,4209]
===
match
---
name: self [5032,5036]
name: self [5032,5036]
===
match
---
if_stmt [6786,7013]
if_stmt [6786,7013]
===
match
---
name: line [4873,4877]
name: line [4873,4877]
===
match
---
trailer [3310,3350]
trailer [3310,3350]
===
match
---
trailer [7043,7045]
trailer [7060,7062]
===
match
---
trailer [5891,5898]
trailer [5891,5898]
===
match
---
name: stream [4751,4757]
name: stream [4751,4757]
===
match
---
simple_stmt [1105,1168]
simple_stmt [1105,1168]
===
match
---
suite [6872,6953]
suite [6872,6953]
===
match
---
name: chown [3856,3861]
name: chown [3856,3861]
===
match
---
trailer [4842,4855]
trailer [4842,4855]
===
match
---
name: self [6320,6324]
name: self [6320,6324]
===
match
---
simple_stmt [5457,5483]
simple_stmt [5457,5483]
===
match
---
parameters [4744,4758]
parameters [4744,4758]
===
match
---
simple_stmt [3179,3240]
simple_stmt [3179,3240]
===
match
---
trailer [4706,4718]
trailer [4706,4718]
===
match
---
name: get_hostname [5573,5585]
name: get_hostname [5573,5585]
===
match
---
name: deserialize_run_error [4528,4549]
name: deserialize_run_error [4528,4549]
===
match
---
argument [3028,3042]
argument [3028,3042]
===
match
---
name: _error_file [3867,3878]
name: _error_file [3867,3878]
===
match
---
operator: = [6071,6072]
operator: = [6071,6072]
===
match
---
fstring_end: ' [3348,3349]
fstring_end: ' [3348,3349]
===
match
---
trailer [4474,4479]
trailer [4474,4479]
===
match
---
arglist [4843,4854]
arglist [4843,4854]
===
match
---
import_as_names [939,954]
import_as_names [939,954]
===
match
---
name: line [5121,5125]
name: line [5121,5125]
===
match
---
name: get_hostname [1255,1267]
name: get_hostname [1255,1267]
===
match
---
expr_stmt [6106,6130]
expr_stmt [6106,6130]
===
match
---
expr_stmt [1931,1949]
expr_stmt [1931,1949]
===
match
---
expr_stmt [4499,4518]
expr_stmt [4499,4518]
===
match
---
simple_stmt [5597,5636]
simple_stmt [5597,5636]
===
match
---
name: popen_prepend [4093,4106]
name: popen_prepend [4093,4106]
===
match
---
name: self [3222,3226]
name: self [3222,3226]
===
match
---
trailer [4503,4511]
trailer [4503,4511]
===
match
---
name: NamedTemporaryFile [901,919]
name: NamedTemporaryFile [901,919]
===
match
---
arglist [5611,5634]
arglist [5611,5634]
===
match
---
simple_stmt [3853,3924]
simple_stmt [3853,3924]
===
match
---
parameters [6566,6572]
parameters [6566,6572]
===
match
---
simple_stmt [6590,6634]
simple_stmt [6590,6634]
===
match
---
fstring [3311,3349]
fstring [3311,3349]
===
match
---
name: NamedTemporaryFile [3759,3777]
name: NamedTemporaryFile [3759,3777]
===
match
---
operator: -> [6326,6328]
operator: -> [6326,6328]
===
match
---
simple_stmt [4679,4720]
simple_stmt [4679,4720]
===
match
---
operator: , [5690,5691]
operator: , [5690,5691]
===
match
---
operator: != [2507,2509]
operator: != [2507,2509]
===
match
---
name: close_fds [5815,5824]
name: close_fds [5815,5824]
===
match
---
string: 'chown' [2990,2997]
string: 'chown' [2990,2997]
===
match
---
testlist_comp [3196,3238]
testlist_comp [3196,3238]
===
match
---
trailer [3134,3142]
trailer [3134,3142]
===
match
---
suite [3819,4020]
suite [3819,4020]
===
match
---
name: AirflowConfigException [2184,2206]
name: AirflowConfigException [2184,2206]
===
match
---
operator: , [5864,5865]
operator: , [5864,5865]
===
match
---
trailer [6545,6547]
trailer [6545,6547]
===
match
---
name: local_task_job [4357,4371]
name: local_task_job [4357,4371]
===
match
---
name: close [7038,7043]
name: close [7055,7060]
===
match
---
name: Thread [6006,6012]
name: Thread [6006,6012]
===
match
---
name: self [6567,6571]
name: self [6567,6571]
===
match
---
operator: = [5710,5711]
operator: = [5710,5711]
===
match
---
atom_expr [2999,3015]
atom_expr [2999,3015]
===
match
---
name: self [5175,5179]
name: self [5175,5179]
===
match
---
operator: , [3202,3203]
operator: , [3202,3203]
===
match
---
operator: - [3920,3921]
operator: - [3920,3921]
===
match
---
operator: = [4356,4357]
operator: = [4356,4357]
===
match
---
name: run_as_user [2011,2022]
name: run_as_user [2011,2022]
===
match
---
name: airflow [1173,1180]
name: airflow [1173,1180]
===
match
---
name: Union [949,954]
name: Union [949,954]
===
match
---
name: self [2025,2029]
name: self [2025,2029]
===
match
---
name: _task_instance [5081,5095]
name: _task_instance [5081,5095]
===
match
---
name: self [2224,2228]
name: self [2224,2228]
===
match
---
atom [2981,3026]
atom [2981,3026]
===
match
---
atom_expr [2224,2240]
atom_expr [2224,2240]
===
match
---
operator: , [5726,5727]
operator: , [5726,5727]
===
match
---
operator: = [4402,4403]
operator: = [4402,4403]
===
match
---
trailer [4224,4234]
trailer [4224,4234]
===
match
---
name: _read_task_logs [4729,4744]
name: _read_task_logs [4729,4744]
===
match
---
trailer [5662,5668]
trailer [5662,5668]
===
match
---
operator: = [2839,2840]
operator: = [2839,2840]
===
match
---
name: subprocess [5711,5721]
name: subprocess [5711,5721]
===
match
---
if_stmt [4829,4901]
if_stmt [4829,4901]
===
match
---
operator: , [5179,5180]
operator: , [5179,5180]
===
match
---
name: _command [4068,4076]
name: _command [4068,4076]
===
match
---
trailer [3911,3918]
trailer [3911,3918]
===
match
---
name: popen_prepend [3179,3192]
name: popen_prepend [3179,3192]
===
match
---
name: NotImplementedError [6648,6667]
name: NotImplementedError [6648,6667]
===
match
---
name: pool [4372,4376]
name: pool [4372,4376]
===
match
---
name: process [4504,4511]
name: process [4504,4511]
===
match
---
suite [6199,6299]
suite [6199,6299]
===
match
---
number: 1 [3921,3922]
number: 1 [3921,3922]
===
match
---
parameters [5174,5195]
parameters [5174,5195]
===
match
---
atom_expr [3290,3350]
atom_expr [3290,3350]
===
match
---
name: stdout [5704,5710]
name: stdout [5704,5710]
===
match
---
name: PIPE [5722,5726]
name: PIPE [5722,5726]
===
match
---
trailer [5601,5605]
trailer [5601,5605]
===
match
---
param [4751,4757]
param [4751,4757]
===
match
---
simple_stmt [3113,3167]
simple_stmt [3113,3167]
===
match
---
name: subprocess [5652,5662]
name: subprocess [5652,5662]
===
match
---
operator: = [3130,3131]
operator: = [3130,3131]
===
match
---
trailer [4331,4334]
trailer [4331,4334]
===
match
---
name: run_as_user [2495,2506]
name: run_as_user [2495,2506]
===
match
---
name: LoggingMixin [1212,1224]
name: LoggingMixin [1212,1224]
===
match
---
trailer [2472,2484]
trailer [2472,2484]
===
match
---
operator: , [4411,4412]
operator: , [4411,4412]
===
match
---
string: 'utf-8' [4892,4899]
string: 'utf-8' [4892,4899]
===
match
---
simple_stmt [2006,2057]
simple_stmt [2006,2057]
===
match
---
atom_expr [4063,4076]
atom_expr [4063,4076]
===
match
---
name: line [4843,4847]
name: line [4843,4847]
===
match
---
name: configuration [969,982]
name: configuration [969,982]
===
match
---
trailer [4140,4156]
trailer [4140,4156]
===
match
---
name: universal_newlines [5778,5796]
name: universal_newlines [5778,5796]
===
match
---
operator: , [5571,5572]
operator: , [5571,5572]
===
match
---
trailer [3717,3730]
trailer [3717,3730]
===
match
---
operator: , [6935,6936]
operator: , [6935,6936]
===
match
---
operator: , [2437,2438]
operator: , [2437,2438]
===
match
---
atom_expr [5121,5138]
atom_expr [5121,5138]
===
match
---
trailer [3777,3790]
trailer [3777,3790]
===
match
---
atom_expr [2123,2164]
atom_expr [2123,2164]
===
match
---
suite [3273,3351]
suite [3273,3351]
===
match
---
name: os [5847,5849]
name: os [5847,5849]
===
match
---
operator: = [4316,4317]
operator: = [4316,4317]
===
match
---
name: preexec_fn [5878,5888]
name: preexec_fn [5878,5888]
===
match
---
name: stream [4799,4805]
name: stream [4799,4805]
===
match
---
operator: = [5746,5747]
operator: = [5746,5747]
===
match
---
simple_stmt [4029,4055]
simple_stmt [4029,4055]
===
match
---
atom_expr [2468,2484]
atom_expr [2468,2484]
===
match
---
return_stmt [6166,6177]
return_stmt [6166,6177]
===
match
---
factor [3920,3922]
factor [3920,3922]
===
match
---
name: self [4029,4033]
name: self [4029,4033]
===
match
---
trailer [4279,4292]
trailer [4279,4292]
===
match
---
name: conf [990,994]
name: conf [990,994]
===
match
---
simple_stmt [4063,4491]
simple_stmt [4063,4491]
===
match
---
simple_stmt [3684,3731]
simple_stmt [3684,3731]
===
match
---
suite [1731,4519]
suite [1731,4519]
===
match
---
name: airflow [1110,1117]
name: airflow [1110,1117]
===
match
---
name: return_code [6308,6319]
name: return_code [6308,6319]
===
match
---
name: pythonpath_value [3113,3129]
name: pythonpath_value [3113,3129]
===
match
---
simple_stmt [6352,6512]
simple_stmt [6352,6512]
===
match
---
trailer [4968,4973]
trailer [4968,4973]
===
match
---
name: getuser [1303,1310]
name: getuser [1303,1310]
===
match
---
parameters [1708,1730]
parameters [1708,1730]
===
match
---
import_name [810,819]
import_name [810,819]
===
match
---
param [6567,6571]
param [6567,6571]
===
match
---
operator: = [1327,1328]
operator: = [1327,1328]
===
match
---
name: getuser [2510,2517]
name: getuser [2510,2517]
===
match
---
simple_stmt [4960,5154]
simple_stmt [4960,5154]
===
match
---
trailer [6827,6837]
trailer [6827,6837]
===
match
---
suite [3836,3924]
suite [3836,3924]
===
match
---
parameters [6319,6325]
parameters [6319,6325]
===
match
---
name: _error_file [4707,4718]
name: _error_file [4707,4718]
===
match
---
name: load_error_file [4686,4701]
name: load_error_file [4686,4701]
===
match
---
string: """Force kill the running task instance.""" [6590,6633]
string: """Force kill the running task instance.""" [6590,6633]
===
match
---
atom [5480,5482]
atom [5480,5482]
===
match
---
name: os [3132,3134]
name: os [3132,3134]
===
match
---
trailer [3226,3238]
trailer [3226,3238]
===
match
---
name: self [6193,6197]
name: self [6193,6197]
===
match
---
operator: -> [6695,6697]
operator: -> [6695,6697]
===
match
---
name: platform [1287,1295]
name: platform [1287,1295]
===
match
---
simple_stmt [2390,2457]
simple_stmt [2390,2457]
===
match
---
atom_expr [2025,2056]
atom_expr [2025,2056]
===
match
---
atom_expr [2490,2506]
atom_expr [2490,2506]
===
match
---
simple_stmt [1816,1863]
simple_stmt [1816,1863]
===
match
---
name: self [1961,1965]
name: self [1961,1965]
===
match
---
arglist [4991,5139]
arglist [4991,5139]
===
match
---
name: log_reader [6139,6149]
name: log_reader [6139,6149]
===
match
---
string: 'Job %s: Subtask %s %s' [4991,5014]
string: 'Job %s: Subtask %s %s' [4991,5014]
===
match
---
name: typing [925,931]
name: typing [925,931]
===
match
---
argument [4394,4411]
argument [4394,4411]
===
match
---
string: """Base task runner""" [787,809]
string: """Base task runner""" [787,809]
===
match
---
operator: , [3214,3215]
operator: , [3214,3215]
===
match
---
operator: { [3313,3314]
operator: { [3313,3314]
===
match
---
suite [6703,7046]
suite [6703,7205]
===
match
---
name: job_id [5052,5058]
name: job_id [5052,5058]
===
match
---
string: 'sudo' [2982,2988]
string: 'sudo' [2982,2988]
===
match
---
operator: , [3883,3884]
operator: , [3883,3884]
===
match
---
testlist_comp [4442,4479]
testlist_comp [4442,4479]
===
match
---
string: '-E' [3204,3208]
string: '-E' [3204,3208]
===
match
---
expr_stmt [2830,2876]
expr_stmt [2830,2876]
===
match
---
operator: -> [4556,4558]
operator: -> [4556,4558]
===
match
---
string: '' [3163,3165]
string: '' [3163,3165]
===
match
---
operator: = [4177,4178]
operator: = [4177,4178]
===
match
---
operator: = [3193,3194]
operator: = [3193,3194]
===
match
---
name: cfg_path [4403,4411]
name: cfg_path [4403,4411]
===
match
---
trailer [3142,3146]
trailer [3142,3146]
===
match
---
trailer [4964,4968]
trailer [4964,4968]
===
match
---
trailer [6005,6012]
trailer [6005,6012]
===
match
---
classdef [1344,7046]
classdef [1344,7205]
===
insert-node
---
try_stmt [7021,7205]
to
suite [6703,7046]
at 2
===
insert-node
---
suite [7025,7063]
to
try_stmt [7021,7205]
at 0
===
move-tree
---
simple_stmt [7021,7046]
    atom_expr [7021,7045]
        name: self [7021,7025]
        trailer [7025,7037]
            name: _error_file [7026,7037]
        trailer [7037,7043]
            name: close [7038,7043]
        trailer [7043,7045]
to
suite [7025,7063]
at 0
