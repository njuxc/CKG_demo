===
match
---
param [2837,2862]
param [2825,2850]
===
match
---
name: TriggerEvent [901,913]
name: TriggerEvent [901,913]
===
match
---
name: delta [2917,2922]
name: delta [2905,2910]
===
match
---
name: self [1709,1713]
name: self [1709,1713]
===
match
---
dictorsetmaker [1699,1720]
dictorsetmaker [1699,1720]
===
match
---
simple_stmt [2494,2526]
simple_stmt [2482,2514]
===
match
---
name: airflow [859,866]
name: airflow [859,866]
===
match
---
name: datetime [808,816]
name: datetime [808,816]
===
match
---
name: datetime [1181,1189]
name: datetime [1181,1189]
===
match
---
operator: != [1423,1425]
operator: != [1423,1425]
===
match
---
atom_expr [2380,2397]
atom_expr [2368,2385]
===
match
---
suite [2568,2924]
suite [2556,2912]
===
match
---
name: Dict [1620,1624]
name: Dict [1620,1624]
===
match
---
trailer [1408,1415]
trailer [1408,1415]
===
match
---
name: timezone [2204,2212]
name: timezone [2219,2227]
===
match
---
suite [1547,1581]
suite [1547,1581]
===
match
---
number: 3600 [2300,2304]
number: 3600 [2289,2293]
===
match
---
suite [1428,1534]
suite [1428,1534]
===
match
---
operator: , [2835,2836]
operator: , [2823,2824]
===
match
---
funcdef [1586,1723]
funcdef [1586,1723]
===
match
---
name: tzinfo [1409,1415]
name: tzinfo [1409,1415]
===
match
---
operator: = [2262,2263]
operator: > [2252,2253]
===
match
---
atom_expr [1366,1398]
atom_expr [1366,1398]
===
match
---
operator: } [1530,1531]
operator: } [1530,1531]
===
match
---
name: moment [1574,1580]
name: moment [1574,1580]
===
match
---
name: triggers [867,875]
name: triggers [867,875]
===
match
---
suite [1191,1581]
suite [1191,1581]
===
match
---
name: timezone [940,948]
name: timezone [940,948]
===
match
---
import_from [914,948]
import_from [914,948]
===
match
---
name: tzinfo [1269,1275]
name: tzinfo [1269,1275]
===
match
---
string: """     Subclass to create DateTimeTriggers based on time delays rather     than exact moments.      While this is its own distinct class here, it will serialise to a     DateTimeTrigger class, since they're operationally the same.     """ [2573,2812]
string: """     Subclass to create DateTimeTriggers based on time delays rather     than exact moments.      While this is its own distinct class here, it will serialise to a     DateTimeTrigger class, since they're operationally the same.     """ [2561,2800]
===
match
---
trailer [1415,1422]
trailer [1415,1422]
===
match
---
atom_expr [2224,2235]
atom_expr [2205,2216]
===
match
---
name: moment [1714,1720]
name: moment [1714,1720]
===
match
---
name: TimeDeltaTrigger [2534,2550]
name: TimeDeltaTrigger [2522,2538]
===
match
---
trailer [1380,1387]
trailer [1380,1387]
===
match
---
name: moment [1164,1170]
name: moment [1164,1170]
===
match
---
name: timedelta [2853,2862]
name: timedelta [2841,2850]
===
match
---
name: self [1158,1162]
name: self [1158,1162]
===
match
---
if_stmt [1259,1581]
if_stmt [1259,1581]
===
match
---
fstring_expr [1514,1531]
fstring_expr [1514,1531]
===
match
---
async_stmt [1728,2526]
async_stmt [1728,2514]
===
match
---
atom_expr [2286,2305]
atom_expr [2269,2294]
===
match
---
operator: } [1720,1721]
operator: } [1720,1721]
===
match
---
argument [2890,2922]
argument [2878,2910]
===
match
---
subscriptlist [1615,1634]
subscriptlist [1615,1634]
===
match
---
fstring_start: f" [1458,1460]
fstring_start: f" [1458,1460]
===
match
---
parameters [1741,1747]
parameters [1741,1747]
===
match
---
operator: { [1698,1699]
operator: { [1698,1699]
===
match
---
name: self [2513,2517]
name: self [2501,2505]
===
match
---
name: self [1742,1746]
name: self [1742,1746]
===
match
---
atom_expr [1303,1348]
atom_expr [1303,1348]
===
match
---
suite [1284,1349]
suite [1284,1349]
===
match
---
name: asyncio [2417,2424]
name: asyncio [2405,2412]
===
match
---
trailer [1614,1635]
trailer [1614,1635]
===
match
---
name: utcnow [2906,2912]
name: utcnow [2894,2900]
===
match
---
fstring_conversion [1528,1530]
fstring_conversion [1528,1530]
===
match
---
name: datetime [2844,2852]
name: datetime [2832,2840]
===
match
---
name: __init__ [1208,1216]
name: __init__ [1208,1216]
===
match
---
name: tzinfo [1381,1387]
name: tzinfo [1381,1387]
===
match
---
name: Dict [841,845]
name: Dict [841,845]
===
match
---
operator: = [2896,2897]
operator: = [2884,2885]
===
match
---
string: """     A trigger that fires exactly once, at the given datetime, give or take     a few seconds.      The provided datetime MUST be in UTC.     """ [991,1139]
string: """     A trigger that fires exactly once, at the given datetime, give or take     a few seconds.      The provided datetime MUST be in UTC.     """ [991,1139]
===
match
---
operator: , [899,900]
operator: , [899,900]
===
match
---
name: utils [927,932]
name: utils [927,932]
===
match
---
name: offset [1416,1422]
name: offset [1416,1422]
===
match
---
funcdef [2818,2924]
funcdef [2806,2912]
===
match
---
operator: > [2378,2379]
operator: > [2366,2367]
===
match
---
suite [2398,2434]
suite [2386,2422]
===
match
---
simple_stmt [1200,1219]
simple_stmt [1200,1219]
===
match
---
name: sleep [2425,2430]
name: sleep [2413,2418]
===
match
---
param [1164,1189]
param [1164,1189]
===
match
---
operator: , [1162,1163]
operator: , [1162,1163]
===
match
---
atom_expr [2844,2862]
atom_expr [2832,2850]
===
match
---
operator: - [2222,2223]
operator: - [2217,2218]
===
match
---
simple_stmt [1441,1534]
simple_stmt [1441,1534]
===
match
---
param [1742,1746]
param [1742,1746]
===
match
---
atom_expr [2513,2524]
atom_expr [2501,2512]
===
match
---
simple_stmt [1645,1723]
simple_stmt [1645,1723]
===
match
---
string: "moment" [1699,1707]
string: "moment" [1699,1707]
===
match
---
simple_stmt [854,914]
simple_stmt [854,914]
===
match
---
or_test [1362,1427]
or_test [1362,1427]
===
match
---
trailer [1205,1207]
trailer [1205,1207]
===
match
---
name: super [2873,2878]
name: super [2861,2866]
===
match
---
operator: + [2915,2916]
operator: + [2903,2904]
===
match
---
name: tzinfo [1522,1528]
name: tzinfo [1522,1528]
===
match
---
trailer [2212,2219]
trailer [2227,2234]
===
match
---
name: typing [822,828]
name: typing [822,828]
===
match
---
string: """         Simple time delay loop until the relevant time is met.          We do have a two-phase delay to save some cycles, but sleeping is so         cheap anyway that it's pretty loose. We also don't just sleep for         "the number of seconds until the time" in case the system clock changes         unexpectedly, or handles a DST change poorly.         """ [1757,2121]
string: """         Simple time delay loop until the relevant time is met.          We do have a two-phase delay to save some cycles, but sleeping is so         cheap anyway that it's pretty loose. We also don't just sleep for         "the number of seconds until the time" in case the system clock changes         unexpectedly, or handles a DST change poorly.         """ [1757,2121]
===
match
---
atom_expr [2411,2433]
atom_expr [2399,2421]
===
match
---
name: serialize [1590,1599]
name: serialize [1590,1599]
===
match
---
atom_expr [1620,1634]
atom_expr [1620,1634]
===
match
---
trailer [1624,1634]
trailer [1624,1634]
===
match
---
name: BaseTrigger [888,899]
name: BaseTrigger [888,899]
===
match
---
operator: , [1628,1629]
operator: , [1628,1629]
===
match
---
atom [1698,1721]
atom [1698,1721]
===
match
---
operator: , [1618,1619]
operator: , [1618,1619]
===
match
---
comparison [1262,1283]
comparison [1262,1283]
===
match
---
name: delta [2837,2842]
name: delta [2825,2830]
===
match
---
trailer [1457,1533]
trailer [1457,1533]
===
match
---
trailer [2889,2923]
trailer [2877,2911]
===
match
---
file_input [786,2924]
file_input [786,2912]
===
match
---
trailer [2219,2221]
trailer [2234,2236]
===
match
---
trailer [2424,2430]
trailer [2412,2418]
===
match
---
name: moment [2890,2896]
name: moment [2878,2884]
===
match
---
trailer [1373,1398]
trailer [1373,1398]
===
match
---
parameters [1599,1605]
parameters [1599,1605]
===
match
---
import_from [817,852]
import_from [817,852]
===
match
---
comparison [2204,2265]
comparison [2204,2255]
===
match
---
name: str [1625,1628]
name: str [1625,1628]
===
match
---
trailer [1216,1218]
trailer [1216,1218]
===
match
---
parameters [2830,2863]
parameters [2818,2851]
===
match
---
trailer [2517,2524]
trailer [2505,2512]
===
match
---
name: utcnow [2213,2219]
name: utcnow [2228,2234]
===
match
---
atom_expr [1560,1571]
atom_expr [1560,1571]
===
match
---
suite [1748,2526]
suite [1748,2514]
===
match
---
name: BaseTrigger [973,984]
name: BaseTrigger [973,984]
===
match
---
operator: -> [1606,1608]
operator: -> [1606,1608]
===
match
---
atom_expr [2500,2525]
atom_expr [2488,2513]
===
match
---
arglist [1374,1397]
arglist [1374,1397]
===
match
---
name: TriggerEvent [2500,2512]
name: TriggerEvent [2488,2500]
===
match
---
name: DateTimeTrigger [2551,2566]
name: DateTimeTrigger [2539,2554]
===
match
---
name: self [2224,2228]
name: self [2205,2209]
===
match
---
comparison [1402,1427]
comparison [1402,1427]
===
match
---
name: moment [2229,2235]
name: moment [2210,2216]
===
match
---
name: airflow [919,926]
name: airflow [919,926]
===
match
---
name: moment [1402,1408]
name: moment [1402,1408]
===
match
---
while_stmt [2198,2307]
while_stmt [2198,2295]
===
match
---
number: 0 [1426,1427]
number: 0 [1426,1427]
===
match
---
trailer [2246,2256]
trailer [2237,2249]
===
match
---
operator: = [1572,1573]
operator: = [1572,1573]
===
match
---
name: ValueError [1303,1313]
name: ValueError [1303,1313]
===
match
---
atom_expr [1447,1533]
atom_expr [1447,1533]
===
match
---
funcdef [1145,1581]
funcdef [1145,1581]
===
match
---
operator: , [845,846]
operator: , [845,846]
===
match
---
param [1600,1604]
param [1600,1604]
===
match
---
import_from [854,913]
import_from [854,913]
===
match
---
trailer [1268,1275]
trailer [1268,1275]
===
match
---
name: __init__ [2822,2830]
name: __init__ [2810,2818]
===
match
---
name: ValueError [1447,1457]
name: ValueError [1447,1457]
===
match
---
arith_expr [2897,2922]
arith_expr [2885,2910]
===
match
---
atom_expr [2897,2914]
atom_expr [2885,2902]
===
match
---
name: Tuple [847,852]
name: Tuple [847,852]
===
match
---
trailer [2370,2377]
trailer [2358,2365]
===
match
---
raise_stmt [1441,1533]
raise_stmt [1441,1533]
===
match
---
arith_expr [2204,2235]
arith_expr [2205,2236]
===
match
---
raise_stmt [1297,1348]
raise_stmt [1297,1348]
===
match
---
operator: , [1387,1388]
operator: , [1387,1388]
===
match
---
string: "You cannot pass naive datetimes" [1314,1347]
string: "You cannot pass naive datetimes" [1314,1347]
===
match
---
param [2831,2836]
param [2819,2824]
===
match
---
fstring [1458,1532]
fstring [1458,1532]
===
match
---
trailer [2512,2525]
trailer [2500,2513]
===
match
---
trailer [1713,1720]
trailer [1713,1720]
===
match
---
tfpdef [1164,1189]
tfpdef [1164,1189]
===
match
---
comparison [2366,2397]
comparison [2354,2385]
===
match
---
name: timedelta [2247,2256]
name: total_hours [2238,2249]
===
match
---
name: moment [2371,2377]
name: moment [2359,2365]
===
match
---
tfpdef [2837,2862]
tfpdef [2825,2850]
===
match
---
name: moment [2518,2524]
name: moment [2506,2512]
===
match
---
name: base [876,880]
name: base [876,880]
===
match
---
name: self [2366,2370]
name: self [2354,2358]
===
match
---
operator: , [839,840]
operator: , [839,840]
===
match
---
simple_stmt [1757,2122]
simple_stmt [1757,2122]
===
match
---
simple_stmt [786,801]
simple_stmt [786,801]
===
match
---
atom_expr [1172,1189]
atom_expr [1172,1189]
===
match
---
trailer [1564,1571]
trailer [1564,1571]
===
match
---
trailer [1313,1348]
trailer [1313,1348]
===
match
---
funcdef [1734,2526]
funcdef [1734,2514]
===
match
---
string: "airflow.triggers.temporal.DateTimeTrigger" [1653,1696]
string: "airflow.triggers.temporal.DateTimeTrigger" [1653,1696]
===
match
---
suite [1636,1723]
suite [1636,1723]
===
match
---
not_test [1362,1398]
not_test [1362,1398]
===
match
---
name: Any [836,839]
name: Any [836,839]
===
match
---
operator: { [1514,1515]
operator: { [1514,1515]
===
match
---
number: 1 [2431,2432]
number: 1 [2419,2420]
===
match
---
suite [986,2526]
suite [986,2514]
===
match
---
name: Any [1630,1633]
name: Any [1630,1633]
===
match
---
simple_stmt [914,949]
simple_stmt [914,949]
===
match
---
name: sleep [2294,2299]
name: sleep [2283,2288]
===
match
---
simple_stmt [817,853]
simple_stmt [817,853]
===
match
---
name: moment [1374,1380]
name: moment [1374,1380]
===
match
---
atom_expr [1709,1720]
atom_expr [1709,1720]
===
match
---
simple_stmt [2279,2307]
simple_stmt [2269,2295]
===
match
---
import_name [801,816]
import_name [801,816]
===
match
---
name: self [2831,2835]
name: self [2819,2823]
===
match
---
name: str [1615,1618]
name: str [1615,1618]
===
match
---
dotted_name [859,880]
dotted_name [859,880]
===
match
---
trailer [2878,2880]
trailer [2866,2868]
===
match
---
name: __init__ [1149,1157]
name: __init__ [1149,1157]
===
match
---
name: timezone [2380,2388]
name: timezone [2368,2376]
===
match
---
trailer [2293,2299]
trailer [2282,2288]
===
match
---
name: __init__ [2881,2889]
name: __init__ [2869,2877]
===
match
---
simple_stmt [801,817]
simple_stmt [801,817]
===
match
---
trailer [1180,1189]
trailer [1180,1189]
===
match
---
atom_expr [1609,1635]
atom_expr [1609,1635]
===
match
---
dotted_name [919,932]
dotted_name [919,932]
===
match
---
trailer [1521,1528]
trailer [1521,1528]
===
match
---
number: 2 [2263,2264]
number: 2 [2254,2255]
===
match
---
classdef [951,2526]
classdef [951,2514]
===
match
---
name: timezone [2897,2905]
name: timezone [2885,2893]
===
match
---
while_stmt [2360,2434]
while_stmt [2348,2422]
===
match
---
testlist_comp [1653,1721]
testlist_comp [1653,1721]
===
match
---
name: run [1738,1741]
name: run [1738,1741]
===
match
---
fstring_end: " [1531,1532]
fstring_end: " [1531,1532]
===
match
---
classdef [2528,2924]
classdef [2516,2912]
===
match
---
simple_stmt [2873,2924]
simple_stmt [2861,2912]
===
match
---
name: utcnow [2389,2395]
name: utcnow [2377,2383]
===
match
---
trailer [2852,2862]
trailer [2840,2850]
===
match
---
trailer [1207,1216]
trailer [1207,1216]
===
match
---
simple_stmt [2411,2434]
simple_stmt [2399,2422]
===
match
---
name: datetime [1172,1180]
name: datetime [1172,1180]
===
match
---
simple_stmt [2573,2813]
simple_stmt [2561,2801]
===
match
---
simple_stmt [991,1140]
simple_stmt [991,1140]
===
match
---
name: moment [1515,1521]
name: moment [1515,1521]
===
match
---
trailer [2905,2912]
trailer [2893,2900]
===
match
---
fstring_string: The passed datetime must be using Pendulum's UTC, not  [1460,1514]
fstring_string: The passed datetime must be using Pendulum's UTC, not  [1460,1514]
===
match
---
return_stmt [1645,1722]
return_stmt [1645,1722]
===
match
---
operator: , [1696,1697]
operator: , [1696,1697]
===
match
---
atom [1652,1722]
atom [1652,1722]
===
match
---
parameters [1157,1190]
parameters [1157,1190]
===
match
---
name: super [1200,1205]
name: super [1200,1205]
===
match
---
name: DateTimeTrigger [957,972]
name: DateTimeTrigger [957,972]
===
match
---
simple_stmt [1560,1581]
simple_stmt [1560,1581]
===
match
---
atom_expr [2204,2221]
atom_expr [2219,2236]
===
match
---
trailer [2430,2433]
trailer [2418,2421]
===
match
---
trailer [2912,2914]
trailer [2900,2902]
===
match
---
atom_expr [1262,1275]
atom_expr [1262,1275]
===
match
---
import_as_names [888,913]
import_as_names [888,913]
===
match
---
trailer [2388,2395]
trailer [2376,2383]
===
match
---
name: hasattr [1366,1373]
name: hasattr [1366,1373]
===
match
---
name: self [1600,1604]
name: self [1600,1604]
===
match
---
name: moment [1262,1268]
name: moment [1262,1268]
===
match
---
suite [2864,2924]
suite [2852,2912]
===
match
---
trailer [2880,2889]
trailer [2868,2877]
===
match
---
atom_expr [1200,1218]
atom_expr [1200,1218]
===
match
---
operator: ! [1528,1529]
operator: ! [1528,1529]
===
match
---
atom_expr [1374,1387]
atom_expr [1374,1387]
===
match
---
name: r [1529,1530]
name: r [1529,1530]
===
match
---
string: "offset" [1389,1397]
string: "offset" [1389,1397]
===
match
---
trailer [2395,2397]
trailer [2383,2385]
===
match
---
expr_stmt [1560,1580]
expr_stmt [1560,1580]
===
match
---
trailer [2228,2235]
trailer [2209,2216]
===
match
---
atom_expr [2873,2923]
atom_expr [2861,2911]
===
match
---
name: Tuple [1609,1614]
name: Tuple [1609,1614]
===
match
---
name: self [1560,1564]
name: self [1560,1564]
===
match
---
atom_expr [2366,2377]
atom_expr [2354,2365]
===
match
---
simple_stmt [1297,1349]
simple_stmt [1297,1349]
===
match
---
name: asyncio [793,800]
name: asyncio [793,800]
===
match
---
yield_expr [2494,2525]
yield_expr [2482,2513]
===
match
---
import_as_names [836,852]
import_as_names [836,852]
===
match
---
name: moment [1565,1571]
name: moment [1565,1571]
===
match
---
subscriptlist [1625,1633]
subscriptlist [1625,1633]
===
match
---
trailer [2299,2305]
trailer [2288,2294]
===
match
---
param [1158,1163]
param [1158,1163]
===
match
---
suite [2266,2307]
suite [2256,2295]
===
match
---
atom_expr [1515,1528]
atom_expr [1515,1528]
===
match
---
import_name [786,800]
import_name [786,800]
===
match
---
name: asyncio [2286,2293]
name: asyncio [2275,2282]
===
match
---
atom_expr [1402,1422]
atom_expr [1402,1422]
===
insert-node
---
atom_expr [2204,2251]
to
comparison [2204,2265]
at 0
===
update-node
---
operator: = [2262,2263]
replace = by >
===
move-tree
---
operator: = [2262,2263]
to
comparison [2204,2265]
at 1
===
move-tree
---
number: 2 [2263,2264]
to
comparison [2204,2265]
at 2
===
insert-node
---
atom [2204,2237]
to
atom_expr [2204,2251]
at 0
===
move-tree
---
trailer [2246,2256]
    name: timedelta [2247,2256]
to
atom_expr [2204,2251]
at 1
===
move-tree
---
atom_expr [2286,2305]
    name: asyncio [2286,2293]
    trailer [2293,2299]
        name: sleep [2294,2299]
    trailer [2299,2305]
        number: 3600 [2300,2304]
to
simple_stmt [2279,2307]
at 0
===
move-tree
---
arith_expr [2204,2235]
    atom_expr [2204,2221]
        name: timezone [2204,2212]
        trailer [2212,2219]
            name: utcnow [2213,2219]
        trailer [2219,2221]
    operator: - [2222,2223]
    atom_expr [2224,2235]
        name: self [2224,2228]
        trailer [2228,2235]
            name: moment [2229,2235]
to
atom [2204,2237]
at 0
===
update-node
---
name: timedelta [2247,2256]
replace timedelta by total_hours
===
delete-node
---
operator: > [2236,2237]
===
===
delete-node
---
argument [2257,2264]
===
===
delete-node
---
trailer [2256,2265]
===
===
delete-node
---
atom_expr [2238,2265]
===
===
delete-node
---
atom [2285,2306]
===
===
delete-node
---
atom_expr [2279,2306]
===
