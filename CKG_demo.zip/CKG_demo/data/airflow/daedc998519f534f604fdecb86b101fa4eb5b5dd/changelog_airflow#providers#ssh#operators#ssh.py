===
match
---
name: log [3621,3624]
name: log [3621,3624]
===
match
---
atom_expr [7415,7441]
atom_expr [7437,7463]
===
match
---
name: stdin [5006,5011]
name: stdin [5006,5011]
===
match
---
raise_stmt [7196,7251]
raise_stmt [7218,7273]
===
match
---
expr_stmt [3118,3140]
expr_stmt [3118,3140]
===
match
---
name: in_buffer [5771,5780]
name: in_buffer [5771,5780]
===
match
---
name: airflow [1063,1070]
name: airflow [1063,1070]
===
match
---
atom_expr [2807,2820]
atom_expr [2807,2820]
===
match
---
atom_expr [5994,6048]
atom_expr [6005,6059]
===
match
---
trailer [3515,3520]
trailer [3515,3520]
===
match
---
name: command [4711,4718]
name: command [4711,4718]
===
match
---
name: channel [6001,6008]
name: channel [6012,6019]
===
match
---
name: recv [5933,5937]
name: recv [5944,5948]
===
match
---
name: remote_host [4329,4340]
name: remote_host [4329,4340]
===
match
---
expr_stmt [5224,5276]
expr_stmt [5224,5276]
===
match
---
trailer [4041,4045]
trailer [4041,4045]
===
match
---
atom_expr [7202,7251]
atom_expr [7224,7273]
===
match
---
suite [3380,7152]
suite [3380,7174]
===
match
---
name: agg_stderr [7024,7034]
name: agg_stderr [7046,7056]
===
match
---
name: ssh_hook [7359,7367]
name: ssh_hook [7381,7389]
===
match
---
except_clause [7161,7182]
except_clause [7183,7204]
===
match
---
trailer [3153,3161]
trailer [3153,3161]
===
match
---
trailer [3520,3573]
trailer [3520,3573]
===
match
---
expr_stmt [5987,6048]
expr_stmt [5998,6059]
===
match
---
name: command [4724,4731]
name: command [4724,4731]
===
match
---
trailer [4532,4536]
trailer [4532,4536]
===
match
---
name: recv_stderr_ready [5938,5955]
name: recv_stderr_ready [5949,5966]
===
match
---
suite [5322,5399]
suite [5322,5399]
===
match
---
import_from [1058,1109]
import_from [1058,1109]
===
match
---
simple_stmt [7341,7407]
simple_stmt [7363,7429]
===
match
---
string: 'sudo' [3259,3265]
string: 'sudo' [3259,3265]
===
match
---
atom_expr [6589,6603]
atom_expr [6611,6625]
===
match
---
string: '.sh' [2588,2593]
string: '.sh' [2588,2593]
===
match
---
atom_expr [4528,4578]
atom_expr [4528,4578]
===
match
---
atom_expr [6635,6668]
atom_expr [6657,6690]
===
match
---
atom_expr [6433,6463]
atom_expr [6455,6485]
===
match
---
param [2668,2703]
param [2668,2703]
===
match
---
trailer [6383,6385]
trailer [6405,6407]
===
match
---
operator: , [4647,4648]
operator: , [4647,4648]
===
match
---
trailer [6145,6152]
trailer [6156,6163]
===
match
---
param [2837,2855]
param [2837,2855]
===
match
---
name: ssh [1029,1032]
name: ssh [1029,1032]
===
match
---
name: line [5987,5991]
name: line [5998,6002]
===
match
---
atom_expr [3870,3883]
atom_expr [3870,3883]
===
match
---
trailer [5363,5371]
trailer [5363,5371]
===
match
---
simple_stmt [6726,6792]
simple_stmt [6748,6814]
===
match
---
name: models [979,985]
name: models [979,985]
===
match
---
atom_expr [3235,3266]
atom_expr [3235,3266]
===
match
---
trailer [5866,5871]
trailer [5866,5871]
===
match
---
name: self [3235,3239]
name: self [3235,3239]
===
match
---
atom_expr [5858,5905]
atom_expr [5858,5916]
===
match
---
trailer [6152,6161]
trailer [6163,6183]
===
match
---
name: self [4565,4569]
name: self [4565,4569]
===
match
---
atom_expr [6124,6174]
atom_expr [6135,6196]
===
match
---
name: line [6141,6145]
name: line [6152,6156]
===
match
---
trailer [4536,4541]
trailer [4536,4541]
===
match
---
string: 'utf-8' [6153,6160]
string: 'utf-8' [6164,6171]
===
match
---
name: stdout [4942,4948]
name: stdout [4942,4948]
===
match
---
suite [3884,3975]
suite [3884,3975]
===
match
---
name: recv [5766,5770]
name: recv [5766,5770]
===
match
---
trailer [3223,3231]
trailer [3223,3231]
===
match
---
return_stmt [7261,7272]
return_stmt [7283,7294]
===
match
---
name: close [6596,6601]
name: close [6618,6623]
===
match
---
param [3331,3338]
param [3331,3338]
===
match
---
expr_stmt [2572,2595]
expr_stmt [2572,2595]
===
match
---
name: b64encode [6931,6940]
name: b64encode [6953,6962]
===
match
---
name: command [3287,3294]
name: command [3287,3294]
===
match
---
argument [3828,3848]
argument [3828,3848]
===
match
---
suite [4020,4341]
suite [4020,4341]
===
match
---
atom_expr [3396,3412]
atom_expr [3396,3412]
===
match
---
trailer [5756,5761]
trailer [5756,5761]
===
match
---
operator: = [5740,5741]
operator: = [5740,5741]
===
match
---
trailer [7093,7151]
trailer [7115,7173]
===
match
---
name: timeout [4795,4802]
name: timeout [4795,4802]
===
match
---
if_stmt [5294,5399]
if_stmt [5294,5399]
===
match
---
simple_stmt [1006,1058]
simple_stmt [1006,1058]
===
match
---
dotted_name [1011,1042]
dotted_name [1011,1042]
===
match
---
atom_expr [3343,3366]
atom_expr [3343,3366]
===
match
---
name: hooks [1033,1038]
name: hooks [1033,1038]
===
match
---
operator: , [2551,2552]
operator: , [2551,2552]
===
match
---
operator: , [2702,2703]
operator: , [2702,2703]
===
match
---
operator: = [2922,2923]
operator: = [2922,2923]
===
match
---
name: command [3123,3130]
name: command [3123,3130]
===
match
---
name: readq [5568,5573]
name: readq [5568,5573]
===
match
---
trailer [7425,7439]
trailer [7447,7461]
===
match
---
name: stdout [4649,4655]
name: stdout [4649,4655]
===
match
---
trailer [5588,5621]
trailer [5588,5621]
===
match
---
arglist [5589,5620]
arglist [5589,5620]
===
match
---
name: __init__ [2980,2988]
name: __init__ [2980,2988]
===
match
---
name: self [3007,3011]
name: self [3007,3011]
===
match
---
name: get_conn [7368,7376]
name: get_conn [7390,7398]
===
match
---
name: channel [5477,5484]
name: channel [5477,5484]
===
match
---
name: command [4366,4373]
name: command [4366,4373]
===
match
---
operator: } [7248,7249]
operator: } [7270,7271]
===
match
---
name: tunnel [7282,7288]
name: tunnel [7304,7310]
===
match
---
operator: = [4760,4761]
operator: = [4760,4761]
===
match
---
atom_expr [7242,7248]
atom_expr [7264,7270]
===
match
---
string: '\n' [5899,5903]
string: '\n' [5910,5914]
===
match
---
name: log [3512,3515]
name: log [3512,3515]
===
match
---
trailer [5892,5898]
trailer [5903,5909]
===
match
---
fstring [7094,7150]
fstring [7116,7172]
===
match
---
name: stdout [6433,6439]
name: stdout [6455,6461]
===
match
---
trailer [2885,2891]
trailer [2885,2891]
===
match
---
if_stmt [3393,3850]
if_stmt [3393,3850]
===
match
---
atom_expr [2877,2891]
atom_expr [2877,2891]
===
match
---
operator: , [870,871]
operator: , [870,871]
===
match
---
atom_expr [7116,7128]
atom_expr [7138,7150]
===
match
---
atom_expr [5766,5780]
atom_expr [5766,5780]
===
match
---
operator: , [2593,2594]
operator: , [2593,2594]
===
match
---
simple_stmt [2523,2568]
simple_stmt [2523,2568]
===
match
---
expr_stmt [5078,5094]
expr_stmt [5078,5094]
===
match
---
suite [3595,3850]
suite [3595,3850]
===
match
---
operator: , [5606,5607]
operator: , [5606,5607]
===
match
---
atom_expr [3810,3826]
atom_expr [3810,3826]
===
match
---
atom_expr [4324,4340]
atom_expr [4324,4340]
===
match
---
string: """Get ssh tunnel""" [7312,7332]
string: """Get ssh tunnel""" [7334,7354]
===
match
---
atom_expr [5742,5782]
atom_expr [5742,5782]
===
match
---
name: agg_stdout [5343,5353]
name: agg_stdout [5343,5353]
===
match
---
trailer [5502,5513]
trailer [5502,5513]
===
match
---
trailer [4413,4453]
trailer [4413,4453]
===
match
---
trailer [3923,3974]
trailer [3923,3974]
===
match
---
operator: = [3232,3233]
operator: = [3232,3233]
===
match
---
trailer [6230,6238]
trailer [6252,6260]
===
match
---
name: kwargs [2941,2947]
name: kwargs [2941,2947]
===
match
---
name: stdout_buffer_length [5377,5397]
name: stdout_buffer_length [5377,5397]
===
match
---
trailer [3624,3629]
trailer [3624,3629]
===
match
---
simple_stmt [2972,2999]
simple_stmt [2972,2999]
===
match
---
simple_stmt [3007,3032]
simple_stmt [3007,3032]
===
match
---
name: recv [6025,6029]
name: recv [6036,6040]
===
match
---
atom_expr [5477,5491]
atom_expr [5477,5491]
===
match
---
while_stmt [5467,6541]
while_stmt [5467,6563]
===
match
---
suite [5958,6175]
suite [5969,6197]
===
match
---
operator: += [5822,5824]
operator: += [5822,5824]
===
match
---
string: "It will replace the remote_host which was defined " [4131,4183]
string: "It will replace the remote_host which was defined " [4131,4183]
===
match
---
atom_expr [2725,2738]
atom_expr [2725,2738]
===
match
---
string: 'utf-8' [7042,7049]
string: 'utf-8' [7064,7071]
===
match
---
operator: ** [2989,2991]
operator: ** [2989,2991]
===
match
---
param [2712,2746]
param [2712,2746]
===
match
---
if_stmt [5685,5906]
if_stmt [5685,5917]
===
match
---
simple_stmt [6589,6604]
simple_stmt [6611,6626]
===
match
---
name: self [5858,5862]
name: self [5858,5862]
===
match
---
simple_stmt [6856,6874]
simple_stmt [6878,6896]
===
match
---
name: self [3991,3995]
name: self [3991,3995]
===
match
---
suite [3486,3574]
suite [3486,3574]
===
match
---
name: get_pty [3270,3277]
name: get_pty [3270,3277]
===
match
---
simple_stmt [6558,6573]
simple_stmt [6580,6595]
===
match
---
if_stmt [6812,6969]
if_stmt [6834,6991]
===
match
---
operator: += [6088,6090]
operator: += [6099,6101]
===
match
---
operator: = [2696,2697]
operator: = [2696,2697]
===
match
---
simple_stmt [5735,5783]
simple_stmt [5735,5783]
===
match
---
name: command [2798,2805]
name: command [2798,2805]
===
match
---
name: get_conn [4486,4494]
name: get_conn [4486,4494]
===
match
---
operator: , [4655,4656]
operator: , [4655,4656]
===
match
---
name: template_ext [2572,2584]
name: template_ext [2572,2584]
===
match
---
name: strip [5893,5898]
name: strip [5904,5909]
===
match
---
trailer [6029,6046]
trailer [6040,6057]
===
match
---
trailer [5765,5781]
trailer [5765,5781]
===
match
---
trailer [5544,5546]
trailer [5544,5546]
===
match
---
simple_stmt [918,966]
simple_stmt [918,966]
===
match
---
expr_stmt [5568,5621]
expr_stmt [5568,5621]
===
match
---
name: environment [3199,3210]
name: environment [3199,3210]
===
match
---
atom_expr [3282,3294]
atom_expr [3282,3294]
===
match
---
operator: = [7352,7353]
operator: = [7374,7375]
===
match
---
name: SSHHook [3790,3797]
name: SSHHook [3790,3797]
===
match
---
fstring_string: , error:  [7129,7138]
fstring_string: , error:  [7151,7160]
===
match
---
operator: = [5245,5246]
operator: = [5245,5246]
===
match
---
expr_stmt [4642,4884]
expr_stmt [4642,4884]
===
match
---
arglist [4711,4866]
arglist [4711,4866]
===
match
---
name: self [3810,3814]
name: self [3810,3814]
===
match
---
operator: += [5354,5356]
operator: += [5354,5356]
===
match
---
file_input [788,7442]
file_input [788,7464]
===
match
---
name: log [4042,4045]
name: log [4042,4045]
===
match
---
operator: ** [2939,2941]
operator: ** [2939,2941]
===
match
---
trailer [6020,6048]
trailer [6031,6059]
===
match
---
atom [3234,3278]
atom [3234,3278]
===
match
---
name: airflow [971,978]
name: airflow [971,978]
===
match
---
name: remote_host [3996,4007]
name: remote_host [3996,4007]
===
match
---
trailer [3814,3826]
trailer [3814,3826]
===
match
---
parameters [3324,3339]
parameters [3324,3339]
===
match
---
name: super [2972,2977]
name: super [2972,2977]
===
match
---
name: timeout [3154,3161]
name: timeout [3154,3161]
===
match
---
name: self [7289,7293]
name: self [7311,7315]
===
match
---
name: self [3219,3223]
name: self [3219,3223]
===
match
---
simple_stmt [6124,6175]
simple_stmt [6135,6197]
===
match
---
name: len [6021,6024]
name: len [6032,6035]
===
match
---
name: select [822,828]
name: select [822,828]
===
match
---
param [2908,2930]
param [2908,2930]
===
match
---
operator: , [3359,3360]
operator: , [3359,3360]
===
match
---
trailer [6364,6372]
trailer [6386,6394]
===
match
---
trailer [7218,7251]
trailer [7240,7273]
===
match
---
param [7289,7293]
param [7311,7315]
===
match
---
simple_stmt [6488,6511]
simple_stmt [6510,6533]
===
match
---
atom_expr [3118,3130]
atom_expr [3118,3130]
===
match
---
operator: , [5598,5599]
operator: , [5598,5599]
===
match
---
atom_expr [6141,6173]
atom_expr [6152,6195]
===
match
---
atom_expr [3774,3787]
atom_expr [3774,3787]
===
match
---
trailer [6297,6305]
trailer [6319,6327]
===
match
---
operator: = [2892,2893]
operator: = [2892,2893]
===
match
---
name: get_pty [2908,2915]
name: get_pty [2908,2915]
===
match
---
name: ssh_client [4666,4676]
name: ssh_client [4666,4676]
===
match
---
name: recv [5757,5761]
name: recv [5757,5761]
===
match
---
simple_stmt [6535,6541]
simple_stmt [6557,6563]
===
match
---
trailer [3461,3485]
trailer [3461,3485]
===
match
---
suite [2963,3308]
suite [2963,3308]
===
match
---
name: command [7121,7128]
name: command [7143,7150]
===
match
---
trailer [4365,4373]
trailer [4365,4373]
===
match
---
import_from [788,816]
import_from [788,816]
===
match
---
atom_expr [2768,2781]
atom_expr [2768,2781]
===
match
---
atom_expr [2678,2695]
atom_expr [2678,2695]
===
match
---
trailer [4328,4340]
trailer [4328,4340]
===
match
---
trailer [4300,4309]
trailer [4300,4309]
===
match
---
trailer [3184,3196]
trailer [3184,3196]
===
match
---
suite [6705,6969]
suite [6727,6991]
===
match
---
name: AirflowException [949,965]
name: AirflowException [949,965]
===
match
---
operator: , [3329,3330]
operator: , [3329,3330]
===
match
---
expr_stmt [6077,6095]
expr_stmt [6088,6106]
===
match
---
name: base64 [793,799]
name: base64 [793,799]
===
match
---
decorator [2601,2617]
decorator [2601,2617]
===
match
---
name: stdout [6635,6641]
name: stdout [6657,6663]
===
match
---
name: str [2777,2780]
name: str [2777,2780]
===
match
---
fstring_string: SSH operator error:  [7221,7241]
fstring_string: SSH operator error:  [7243,7263]
===
match
---
operator: = [2585,2586]
operator: = [2585,2586]
===
match
---
simple_stmt [6077,6096]
simple_stmt [6088,6107]
===
match
---
name: self [4761,4765]
name: self [4761,4765]
===
match
---
atom_expr [3079,3095]
atom_expr [3079,3095]
===
match
---
atom_expr [3040,3056]
atom_expr [3040,3056]
===
match
---
suite [1144,7442]
suite [1144,7464]
===
match
---
comparison [6688,6704]
comparison [6710,6726]
===
match
---
trailer [5513,5515]
trailer [5513,5515]
===
match
---
atom_expr [6931,6968]
atom_expr [6953,6990]
===
match
---
name: configuration [892,905]
name: configuration [892,905]
===
match
---
trailer [6461,6463]
trailer [6483,6485]
===
match
---
simple_stmt [3118,3141]
simple_stmt [3118,3141]
===
match
---
expr_stmt [4296,4340]
expr_stmt [4296,4340]
===
match
---
trailer [4485,4494]
trailer [4485,4494]
===
match
---
name: close [6565,6570]
name: close [6587,6592]
===
match
---
suite [6831,6874]
suite [6853,6896]
===
match
---
name: self [4849,4853]
name: self [4849,4853]
===
match
---
trailer [5250,5276]
trailer [5250,5276]
===
match
---
name: stdout_buffer_length [5224,5244]
name: stdout_buffer_length [5224,5244]
===
match
---
fstring_expr [7115,7129]
fstring_expr [7137,7151]
===
match
---
name: airflow [923,930]
name: airflow [923,930]
===
match
---
name: self [7116,7120]
name: self [7138,7142]
===
match
---
operator: = [5122,5123]
operator: = [5122,5123]
===
match
---
not_test [3866,3883]
not_test [3866,3883]
===
match
---
trailer [3511,3515]
trailer [3511,3515]
===
match
---
name: typing [848,854]
name: typing [848,854]
===
match
---
name: self [3836,3840]
name: self [3836,3840]
===
match
---
operator: = [2821,2822]
operator: = [2821,2822]
===
match
---
trailer [4689,4884]
trailer [4689,4884]
===
match
---
name: channel [5590,5597]
name: channel [5590,5597]
===
match
---
if_stmt [3988,4341]
if_stmt [3988,4341]
===
match
---
name: e [7246,7247]
name: e [7268,7269]
===
match
---
simple_stmt [5811,5830]
simple_stmt [5811,5830]
===
match
---
name: channel [5258,5265]
name: channel [5258,5265]
===
match
---
name: log [6129,6132]
name: log [6140,6143]
===
match
---
trailer [3466,3475]
trailer [3466,3475]
===
match
---
name: channel [5036,5043]
name: channel [5036,5043]
===
match
---
name: readq [5654,5659]
name: readq [5654,5659]
===
match
---
name: command [3133,3140]
name: command [3133,3140]
===
match
---
name: ssh_conn_id [3815,3826]
name: ssh_conn_id [3815,3826]
===
match
---
name: channel [4949,4956]
name: channel [4949,4956]
===
match
---
operator: , [4731,4732]
operator: , [4731,4732]
===
match
---
trailer [6323,6325]
trailer [6345,6347]
===
match
---
operator: , [5602,5603]
operator: , [5602,5603]
===
match
---
name: channel [6642,6649]
name: channel [6664,6671]
===
match
---
fstring_start: f" [7219,7221]
fstring_start: f" [7241,7243]
===
match
---
name: len [5247,5250]
name: len [5247,5250]
===
match
---
name: line [5735,5739]
name: line [5735,5739]
===
match
---
operator: , [2854,2855]
operator: , [2854,2855]
===
match
---
name: self [3433,3437]
name: self [3433,3437]
===
match
---
expr_stmt [3007,3031]
expr_stmt [3007,3031]
===
match
---
name: SSHHook [1050,1057]
name: SSHHook [1050,1057]
===
match
---
name: exceptions [931,941]
name: exceptions [931,941]
===
match
---
name: stderr [6291,6297]
name: stderr [6313,6319]
===
match
---
argument [4837,4865]
argument [4837,4865]
===
match
---
name: Optional [2877,2885]
name: Optional [2877,2885]
===
match
---
name: line [5825,5829]
name: line [5825,5829]
===
match
---
trailer [6601,6603]
trailer [6623,6625]
===
match
---
operator: = [5992,5993]
operator: = [6003,6004]
===
match
---
expr_stmt [4932,4956]
expr_stmt [4932,4956]
===
match
---
trailer [6140,6174]
trailer [6151,6196]
===
match
---
trailer [6167,6173]
trailer [6189,6195]
===
match
---
suite [6991,7152]
suite [7013,7174]
===
match
---
tfpdef [2908,2921]
tfpdef [2908,2921]
===
match
---
operator: = [2539,2540]
operator: = [2539,2540]
===
match
---
name: recv_exit_status [6650,6666]
name: recv_exit_status [6672,6688]
===
match
---
operator: } [7148,7149]
operator: } [7170,7171]
===
match
---
operator: , [2647,2648]
operator: , [2647,2648]
===
match
---
trailer [7245,7248]
trailer [7267,7270]
===
match
---
simple_stmt [788,817]
simple_stmt [788,817]
===
match
---
operator: { [7115,7116]
operator: { [7137,7138]
===
match
---
raise_stmt [4391,4453]
raise_stmt [4391,4453]
===
match
---
atom_expr [6744,6791]
atom_expr [6766,6813]
===
match
---
name: self [4296,4300]
name: self [4296,4300]
===
match
---
simple_stmt [7071,7152]
simple_stmt [7093,7174]
===
match
---
import_from [918,965]
import_from [918,965]
===
match
---
try_stmt [3376,7252]
try_stmt [3376,7274]
===
match
---
trailer [3011,3020]
trailer [3011,3020]
===
match
---
trailer [5871,5905]
trailer [5871,5916]
===
match
---
atom_expr [4719,4731]
atom_expr [4719,4731]
===
match
---
simple_stmt [966,1006]
simple_stmt [966,1006]
===
match
---
name: command [3240,3247]
name: command [3240,3247]
===
match
---
trailer [3797,3849]
trailer [3797,3849]
===
match
---
classdef [1112,7442]
classdef [1112,7464]
===
match
---
argument [3798,3826]
argument [3798,3826]
===
match
---
name: recv [5372,5376]
name: recv [5372,5376]
===
match
---
name: remote_host [3098,3109]
name: remote_host [3098,3109]
===
match
---
expr_stmt [7341,7378]
expr_stmt [7363,7400]
===
match
---
trailer [5371,5376]
trailer [5371,5376]
===
match
---
if_stmt [6195,6541]
if_stmt [6217,6563]
===
match
---
atom_expr [7024,7050]
atom_expr [7046,7072]
===
match
---
name: agg_stderr [5111,5121]
name: agg_stderr [5111,5121]
===
match
---
trailer [5017,5019]
trailer [5017,5019]
===
match
---
name: self [4719,4723]
name: self [4719,4723]
===
match
---
trailer [3258,3266]
trailer [3258,3266]
===
match
---
simple_stmt [3616,3754]
simple_stmt [3616,3754]
===
match
---
string: 'command' [2542,2551]
string: 'command' [2542,2551]
===
match
---
string: 'enable_xcom_pickling' [6768,6790]
string: 'enable_xcom_pickling' [6790,6812]
===
match
---
atom_expr [5357,5398]
atom_expr [5357,5398]
===
match
---
name: self [3396,3400]
name: self [3396,3400]
===
match
---
trailer [7358,7367]
trailer [7380,7389]
===
match
---
strings [4072,4261]
strings [4072,4261]
===
match
---
trailer [7376,7378]
trailer [7398,7400]
===
match
---
simple_stmt [4932,4957]
simple_stmt [4932,4957]
===
match
---
operator: { [7241,7242]
operator: { [7263,7264]
===
match
---
name: ssh_hook [3023,3031]
name: ssh_hook [3023,3031]
===
match
---
simple_stmt [3507,3574]
simple_stmt [3507,3574]
===
match
---
import_from [879,917]
import_from [879,917]
===
match
---
name: self [3040,3044]
name: self [3040,3044]
===
match
---
simple_stmt [4296,4341]
simple_stmt [4296,4341]
===
match
---
raise_stmt [3901,3974]
raise_stmt [3901,3974]
===
match
---
trailer [5898,5904]
trailer [5909,5915]
===
match
---
name: decode [6146,6152]
name: decode [6157,6163]
===
match
---
atom_expr [3907,3974]
atom_expr [3907,3974]
===
match
---
number: 0 [6703,6704]
number: 0 [6725,6726]
===
match
---
name: self [4472,4476]
name: self [4472,4476]
===
match
---
name: ssh_conn_id [3059,3070]
name: ssh_conn_id [3059,3070]
===
match
---
simple_stmt [6433,6464]
simple_stmt [6455,6486]
===
match
---
name: self [3282,3286]
name: self [3282,3286]
===
match
---
suite [5547,6541]
suite [5547,6563]
===
match
---
atom_expr [4397,4453]
atom_expr [4397,4453]
===
match
---
trailer [5937,5955]
trailer [5948,5966]
===
match
---
trailer [2686,2695]
trailer [2686,2695]
===
match
---
name: channel [6440,6447]
name: channel [6462,6469]
===
match
---
atom_expr [7354,7378]
atom_expr [7376,7400]
===
match
---
funcdef [3313,7273]
funcdef [3313,7295]
===
match
---
name: str [7242,7245]
name: str [7264,7267]
===
match
---
atom [2587,2595]
atom [2587,2595]
===
match
---
trailer [3083,3095]
trailer [3083,3095]
===
match
---
name: ssh_conn_id [3401,3412]
name: ssh_conn_id [3401,3412]
===
match
---
atom_expr [4361,4373]
atom_expr [4361,4373]
===
match
---
trailer [7041,7050]
trailer [7063,7072]
===
match
---
atom_expr [6558,6572]
atom_expr [6580,6594]
===
match
---
for_stmt [5642,6175]
for_stmt [5642,6197]
===
match
---
name: agg_stdout [5811,5821]
name: agg_stdout [5811,5821]
===
match
---
if_stmt [3430,3850]
if_stmt [3430,3850]
===
match
---
name: SSHHook [2687,2694]
name: SSHHook [2687,2694]
===
match
---
name: agg_stdout [6941,6951]
name: agg_stdout [6963,6973]
===
match
---
funcdef [7278,7442]
funcdef [7300,7464]
===
match
---
trailer [6238,6256]
trailer [6260,6278]
===
match
---
trailer [6439,6447]
trailer [6461,6469]
===
match
---
simple_stmt [7012,7051]
simple_stmt [7034,7073]
===
match
---
atom_expr [5872,5904]
atom_expr [5872,5915]
===
match
---
trailer [4541,4578]
trailer [4541,4578]
===
match
---
argument [4753,4773]
argument [4753,4773]
===
match
---
import_from [817,842]
import_from [817,842]
===
match
---
atom_expr [6021,6047]
atom_expr [6032,6058]
===
match
---
simple_stmt [5568,5622]
simple_stmt [5568,5622]
===
match
---
name: BaseOperator [1130,1142]
name: BaseOperator [1130,1142]
===
match
---
name: channel [5749,5756]
name: channel [5749,5756]
===
match
---
atom_expr [5251,5275]
atom_expr [5251,5275]
===
match
---
trailer [6008,6020]
trailer [6019,6031]
===
match
---
operator: = [2850,2851]
operator: = [2850,2851]
===
match
---
string: "Running command: %s" [4542,4563]
string: "Running command: %s" [4542,4563]
===
match
---
name: str [2734,2737]
name: str [2734,2737]
===
match
---
name: AirflowException [4397,4413]
name: AirflowException [4397,4413]
===
match
---
if_stmt [3863,3975]
if_stmt [3863,3975]
===
match
---
name: decode [5877,5883]
name: decode [5877,5883]
===
match
---
name: Exception [7168,7177]
name: Exception [7190,7199]
===
match
---
simple_stmt [4642,4885]
simple_stmt [4642,4885]
===
match
---
name: e [7181,7182]
name: e [7203,7204]
===
match
---
name: log [5863,5866]
name: log [5863,5866]
===
match
---
atom_expr [3007,3020]
atom_expr [3007,3020]
===
match
---
name: exit_status_ready [6239,6256]
name: exit_status_ready [6261,6278]
===
match
---
expr_stmt [3219,3307]
expr_stmt [3219,3307]
===
match
---
name: channel [6298,6305]
name: channel [6320,6327]
===
match
---
simple_stmt [6924,6969]
simple_stmt [6946,6991]
===
match
---
name: recv [5646,5650]
name: recv [5646,5650]
===
match
---
trailer [5612,5620]
trailer [5612,5620]
===
match
---
operator: , [4865,4866]
operator: , [4865,4866]
===
match
---
if_stmt [4354,4454]
if_stmt [4354,4454]
===
match
---
name: info [5867,5871]
name: info [5867,5871]
===
match
---
name: ssh [1039,1042]
name: ssh [1039,1042]
===
match
---
trailer [5043,5058]
trailer [5043,5058]
===
match
---
operator: , [2947,2948]
operator: , [2947,2948]
===
match
---
trailer [2776,2781]
trailer [2776,2781]
===
match
---
name: closed [5485,5491]
name: closed [5485,5491]
===
match
---
name: channel [5364,5371]
name: channel [5364,5371]
===
match
---
simple_stmt [1149,2518]
simple_stmt [1149,2518]
===
match
---
trailer [4569,4577]
trailer [4569,4577]
===
match
---
trailer [5761,5782]
trailer [5761,5782]
===
match
---
simple_stmt [7415,7442]
simple_stmt [7437,7464]
===
match
---
trailer [7120,7128]
trailer [7142,7150]
===
match
---
trailer [4050,4279]
trailer [4050,4279]
===
match
---
atom_expr [3507,3573]
atom_expr [3507,3573]
===
match
---
trailer [3778,3787]
trailer [3778,3787]
===
match
---
name: agg_stdout [5078,5088]
name: agg_stdout [5078,5088]
===
match
---
expr_stmt [5343,5398]
expr_stmt [5343,5398]
===
match
---
dotted_name [923,941]
dotted_name [923,941]
===
match
---
name: ssh_client [4500,4510]
name: ssh_client [4500,4510]
===
match
---
suite [6408,6541]
suite [6430,6563]
===
match
---
trailer [5703,5705]
trailer [5703,5705]
===
match
---
fstring_expr [7241,7249]
fstring_expr [7263,7271]
===
match
---
name: select [836,842]
name: select [836,842]
===
match
---
trailer [6666,6668]
trailer [6688,6690]
===
match
---
trailer [6952,6959]
trailer [6974,6981]
===
match
---
trailer [4494,4496]
trailer [4494,4496]
===
match
---
string: "in ssh_hook or predefined in connection of ssh_conn_id." [4204,4261]
string: "in ssh_hook or predefined in connection of ssh_conn_id." [4204,4261]
===
match
---
atom_expr [5006,5019]
atom_expr [5006,5019]
===
match
---
atom_expr [5762,5781]
atom_expr [5762,5781]
===
match
---
fstring_string: error running cmd:  [7096,7115]
fstring_string: error running cmd:  [7118,7137]
===
match
---
name: self [4324,4328]
name: self [4324,4328]
===
match
---
dotted_name [884,905]
dotted_name [884,905]
===
match
---
operator: = [4940,4941]
operator: = [4940,4941]
===
match
---
name: timeout [3828,3835]
name: timeout [3828,3835]
===
match
---
param [2864,2899]
param [2864,2899]
===
match
---
name: stdout [5251,5257]
name: stdout [5251,5257]
===
match
---
return_stmt [6856,6873]
return_stmt [6878,6895]
===
match
---
expr_stmt [6621,6668]
expr_stmt [6643,6690]
===
match
---
trailer [2815,2820]
trailer [2815,2820]
===
match
---
trailer [6759,6791]
trailer [6781,6813]
===
match
---
trailer [3437,3446]
trailer [3437,3446]
===
match
---
atom_expr [3836,3848]
atom_expr [3836,3848]
===
match
---
test [3234,3307]
test [3234,3307]
===
match
---
operator: = [5580,5581]
operator: = [5580,5581]
===
match
---
funcdef [2621,3308]
funcdef [2621,3308]
===
match
---
simple_stmt [3149,3172]
simple_stmt [3149,3172]
===
match
---
simple_stmt [1058,1110]
simple_stmt [1058,1110]
===
match
---
testlist_comp [2542,2566]
testlist_comp [2542,2566]
===
match
---
name: ssh_hook [3875,3883]
name: ssh_hook [3875,3883]
===
match
---
trailer [3620,3624]
trailer [3620,3624]
===
match
---
name: int [2846,2849]
name: int [2846,2849]
===
match
---
atom_expr [6291,6325]
atom_expr [6313,6347]
===
match
---
operator: , [5573,5574]
operator: , [5573,5574]
===
match
---
name: decorators [1077,1087]
name: decorators [1077,1087]
===
match
---
argument [4711,4731]
argument [4711,4731]
===
match
---
atom_expr [4565,4577]
atom_expr [4565,4577]
===
match
---
name: channel [6231,6238]
name: channel [6253,6260]
===
match
---
trailer [6000,6008]
trailer [6011,6019]
===
match
---
expr_stmt [3774,3849]
expr_stmt [3774,3849]
===
match
---
param [2643,2648]
param [2643,2648]
===
match
---
name: stdout [5742,5748]
name: stdout [5742,5748]
===
match
---
atom_expr [3991,4007]
atom_expr [3991,4007]
===
match
---
raise_stmt [7071,7151]
raise_stmt [7093,7173]
===
match
---
simple_stmt [5858,5906]
simple_stmt [5858,5917]
===
match
---
simple_stmt [5224,5277]
simple_stmt [5224,5277]
===
match
---
arglist [3798,3848]
arglist [3798,3848]
===
match
---
simple_stmt [879,918]
simple_stmt [879,918]
===
match
---
string: "Cannot operate without ssh_hook or ssh_conn_id." [3924,3973]
string: "Cannot operate without ssh_hook or ssh_conn_id." [3924,3973]
===
match
---
name: BaseOperator [993,1005]
name: BaseOperator [993,1005]
===
match
---
string: 'utf-8' [5884,5891]
string: 'utf-8' [5884,5891]
===
match
---
simple_stmt [843,878]
simple_stmt [843,878]
===
match
---
trailer [4853,4865]
trailer [4853,4865]
===
match
---
simple_stmt [4037,4280]
simple_stmt [4037,4280]
===
match
---
string: "ssh_hook is not provided or invalid. Trying ssh_conn_id to create SSHHook." [3655,3731]
string: "ssh_hook is not provided or invalid. Trying ssh_conn_id to create SSHHook." [3655,3731]
===
match
---
trailer [7034,7041]
trailer [7056,7063]
===
match
---
name: enable_pickling [6726,6741]
name: enable_pickling [6748,6763]
===
match
---
name: ssh_conn_id [3798,3809]
name: ssh_conn_id [3798,3809]
===
match
---
trailer [5376,5398]
trailer [5376,5398]
===
match
---
trailer [4476,4485]
trailer [4476,4485]
===
match
---
operator: = [2782,2783]
operator: = [2782,2783]
===
match
---
expr_stmt [5811,5829]
expr_stmt [5811,5829]
===
match
---
string: "ssh_conn_id is ignored when ssh_hook is provided." [3521,3572]
string: "ssh_conn_id is ignored when ssh_hook is provided." [3521,3572]
===
match
---
trailer [5484,5491]
trailer [5484,5491]
===
match
---
name: ssh_hook [3012,3020]
name: ssh_hook [3012,3020]
===
match
---
trailer [6132,6140]
trailer [6143,6151]
===
match
---
name: apply_defaults [2602,2616]
name: apply_defaults [2602,2616]
===
match
---
name: stdout [6224,6230]
name: stdout [6246,6252]
===
match
---
name: _ [5575,5576]
name: _ [5575,5576]
===
match
---
trailer [3044,3056]
trailer [3044,3056]
===
match
---
name: kwargs [2991,2997]
name: kwargs [2991,2997]
===
match
---
trailer [3629,3753]
trailer [3629,3753]
===
match
---
trailer [5770,5780]
trailer [5770,5780]
===
match
---
import_as_names [862,877]
import_as_names [862,877]
===
match
---
trailer [5257,5265]
trailer [5257,5265]
===
match
---
operator: = [3057,3058]
operator: = [3057,3058]
===
match
---
trailer [3348,3366]
trailer [3348,3366]
===
match
---
name: agg_stdout [6863,6873]
name: agg_stdout [6885,6895]
===
match
---
name: info [4537,4541]
name: info [4537,4541]
===
match
---
simple_stmt [5987,6049]
simple_stmt [5998,6060]
===
match
---
trailer [6447,6461]
trailer [6469,6483]
===
match
---
name: ssh_hook [3779,3787]
name: ssh_hook [3779,3787]
===
match
---
name: remote_host [2755,2766]
name: remote_host [2755,2766]
===
match
---
fstring [7219,7250]
fstring [7241,7272]
===
match
---
operator: = [3197,3198]
operator: = [3197,3198]
===
match
---
string: b'' [5124,5127]
string: b'' [5124,5127]
===
match
---
atom_expr [5582,5621]
atom_expr [5582,5621]
===
match
---
simple_stmt [5036,5061]
simple_stmt [5036,5061]
===
match
---
atom_expr [5933,5957]
atom_expr [5944,5968]
===
match
---
trailer [5526,5544]
trailer [5526,5544]
===
match
---
name: stdout [6358,6364]
name: stdout [6380,6386]
===
match
---
name: info [3625,3629]
name: info [3625,3629]
===
match
---
name: AirflowException [3907,3923]
name: AirflowException [3907,3923]
===
match
---
name: ssh_hook [3467,3475]
name: ssh_hook [3467,3475]
===
match
---
atom_expr [6488,6510]
atom_expr [6510,6532]
===
match
---
operator: = [6633,6634]
operator: = [6655,6656]
===
match
---
trailer [6649,6666]
trailer [6671,6688]
===
match
---
import_from [843,877]
import_from [843,877]
===
match
---
trailer [6128,6132]
trailer [6139,6143]
===
match
---
name: apply_defaults [1095,1109]
name: apply_defaults [1095,1109]
===
match
---
atom_expr [5036,5060]
atom_expr [5036,5060]
===
match
---
trailer [5748,5756]
trailer [5748,5756]
===
match
---
simple_stmt [5006,5020]
simple_stmt [5006,5020]
===
match
---
name: timeout [3164,3171]
name: timeout [3164,3171]
===
match
---
name: environment [3185,3196]
name: environment [3185,3196]
===
match
---
operator: = [5089,5090]
operator: = [5089,5090]
===
match
---
not_test [4357,4373]
not_test [4357,4373]
===
match
---
name: environment [2864,2875]
name: environment [2864,2875]
===
match
---
operator: @ [2601,2602]
operator: @ [2601,2602]
===
match
---
operator: -> [2955,2957]
operator: -> [2955,2957]
===
match
---
trailer [6024,6047]
trailer [6035,6058]
===
match
---
atom_expr [4666,4884]
atom_expr [4666,4884]
===
match
---
name: exec_command [4677,4689]
name: exec_command [4677,4689]
===
match
---
name: channel [5495,5502]
name: channel [5495,5502]
===
match
---
trailer [5692,5703]
trailer [5692,5703]
===
match
---
atom [5589,5598]
atom [5589,5598]
===
match
---
name: shutdown_write [5044,5058]
name: shutdown_write [5044,5058]
===
match
---
name: error_msg [7139,7148]
name: error_msg [7161,7170]
===
match
---
name: environment [4854,4865]
name: environment [4854,4865]
===
match
---
operator: = [3835,3836]
operator: = [3835,3836]
===
match
---
trailer [6641,6649]
trailer [6663,6671]
===
match
---
string: 'utf-8' [6960,6967]
string: 'utf-8' [6982,6989]
===
match
---
atom_expr [6025,6046]
atom_expr [6036,6057]
===
match
---
atom_expr [5247,5276]
atom_expr [5247,5276]
===
match
---
name: airflow [884,891]
name: airflow [884,891]
===
match
---
trailer [3874,3883]
trailer [3874,3883]
===
match
---
operator: == [6700,6702]
operator: == [6722,6724]
===
match
---
trailer [4723,4731]
trailer [4723,4731]
===
match
---
name: warning [6133,6140]
name: warning [6144,6151]
===
match
---
operator: = [4322,4323]
operator: = [4322,4323]
===
match
---
name: len [5762,5765]
name: len [5762,5765]
===
match
---
trailer [3122,3130]
trailer [3122,3130]
===
match
---
operator: = [3809,3810]
operator: = [3809,3810]
===
match
---
trailer [2979,2988]
trailer [2979,2988]
===
match
---
operator: -> [3340,3342]
operator: -> [3340,3342]
===
match
---
trailer [3840,3848]
trailer [3840,3848]
===
match
---
operator: , [3354,3355]
operator: , [3354,3355]
===
match
---
operator: { [7138,7139]
operator: { [7160,7161]
===
match
---
parameters [2633,2954]
parameters [2633,2954]
===
match
---
trailer [6748,6759]
trailer [6770,6781]
===
match
---
dotted_name [971,985]
dotted_name [971,985]
===
match
---
trailer [4765,4773]
trailer [4765,4773]
===
match
---
operator: , [4815,4816]
operator: , [4815,4816]
===
match
---
atom_expr [3180,3196]
atom_expr [3180,3196]
===
match
---
atom_expr [5519,5546]
atom_expr [5519,5546]
===
match
---
name: close [5012,5017]
name: close [5012,5017]
===
match
---
parameters [7288,7294]
parameters [7310,7316]
===
match
---
atom_expr [3433,3446]
atom_expr [3433,3446]
===
match
---
number: 0 [5320,5321]
number: 0 [5320,5321]
===
match
---
atom_expr [2972,2998]
atom_expr [2972,2998]
===
match
---
name: get_pty [4766,4773]
name: get_pty [4766,4773]
===
match
---
operator: = [3162,3163]
operator: = [3162,3163]
===
match
---
name: AirflowException [7202,7218]
name: AirflowException [7224,7240]
===
match
---
expr_stmt [7012,7050]
expr_stmt [7034,7072]
===
match
---
trailer [5058,5060]
trailer [5058,5060]
===
match
---
simple_stmt [7312,7333]
simple_stmt [7334,7355]
===
match
---
operator: , [2745,2746]
operator: , [2745,2746]
===
match
---
suite [5660,6175]
suite [5660,6197]
===
match
---
name: stdout_buffer_length [5297,5317]
name: stdout_buffer_length [5297,5317]
===
match
---
simple_stmt [3079,3110]
simple_stmt [3079,3110]
===
match
---
name: self [3118,3122]
name: self [3118,3122]
===
match
---
simple_stmt [5111,5128]
simple_stmt [5111,5128]
===
match
---
name: exit_status [6621,6632]
name: exit_status [6643,6654]
===
match
---
name: get_pty [3300,3307]
name: get_pty [3300,3307]
===
match
---
name: recv [5688,5692]
name: recv [5688,5692]
===
match
---
string: """     SSHOperator to execute commands on given remote host using the ssh_hook.      :param ssh_hook: predefined ssh_hook to use for remote execution.         Either `ssh_hook` or `ssh_conn_id` needs to be provided.     :type ssh_hook: airflow.providers.ssh.hooks.ssh.SSHHook     :param ssh_conn_id: connection id from airflow Connections.         `ssh_conn_id` will be ignored if `ssh_hook` is provided.     :type ssh_conn_id: str     :param remote_host: remote host to connect (templated)         Nullable. If provided, it will replace the `remote_host` which was         defined in `ssh_hook` or predefined in the connection of `ssh_conn_id`.     :type remote_host: str     :param command: command to execute on remote host. (templated)     :type command: str     :param timeout: timeout (in seconds) for executing the command. The default is 10 seconds.     :type timeout: int     :param environment: a dict of shell environment variables. Note that the         server will reject them silently if `AcceptEnv` is not set in SSH config.     :type environment: dict     :param get_pty: request a pseudo-terminal from the server. Set to ``True``         to have the remote process killed upon task timeout.         The default is ``False`` but note that `get_pty` is forced to ``True``         when the `command` starts with ``sudo``.     :type get_pty: bool     """ [1149,2517]
string: """     SSHOperator to execute commands on given remote host using the ssh_hook.      :param ssh_hook: predefined ssh_hook to use for remote execution.         Either `ssh_hook` or `ssh_conn_id` needs to be provided.     :type ssh_hook: airflow.providers.ssh.hooks.ssh.SSHHook     :param ssh_conn_id: connection id from airflow Connections.         `ssh_conn_id` will be ignored if `ssh_hook` is provided.     :type ssh_conn_id: str     :param remote_host: remote host to connect (templated)         Nullable. If provided, it will replace the `remote_host` which was         defined in `ssh_hook` or predefined in the connection of `ssh_conn_id`.     :type remote_host: str     :param command: command to execute on remote host. (templated)     :type command: str     :param timeout: timeout (in seconds) for executing the command. The default is 10 seconds.     :type timeout: int     :param environment: a dict of shell environment variables. Note that the         server will reject them silently if `AcceptEnv` is not set in SSH config.     :type environment: dict     :param get_pty: request a pseudo-terminal from the server. Set to ``True``         to have the remote process killed upon task timeout.         The default is ``False`` but note that `get_pty` is forced to ``True``         when the `command` starts with ``sudo``.     :type get_pty: bool     """ [1149,2517]
===
match
---
name: ssh_hook [4301,4309]
name: ssh_hook [4301,4309]
===
match
---
name: SSHOperator [1118,1129]
name: SSHOperator [1118,1129]
===
match
---
name: self [4803,4807]
name: self [4803,4807]
===
match
---
operator: } [7128,7129]
operator: } [7150,7151]
===
match
---
name: timeout [4808,4815]
name: timeout [4808,4815]
===
match
---
name: template_fields [2523,2538]
name: template_fields [2523,2538]
===
match
---
name: channel [6495,6502]
name: channel [6517,6524]
===
match
---
trailer [2977,2979]
trailer [2977,2979]
===
match
---
import_from [1006,1057]
import_from [1006,1057]
===
match
---
operator: = [4664,4665]
operator: = [4664,4665]
===
match
---
name: decode [7035,7041]
name: decode [7057,7063]
===
match
---
trailer [4676,4689]
trailer [4676,4689]
===
match
---
simple_stmt [7196,7252]
simple_stmt [7218,7274]
===
match
---
atom_expr [5495,5515]
atom_expr [5495,5515]
===
match
---
name: ssh_hook [3438,3446]
name: ssh_hook [3438,3446]
===
match
---
name: agg_stderr [6077,6087]
name: agg_stderr [6088,6098]
===
match
---
name: timeout [5613,5620]
name: timeout [5613,5620]
===
match
---
trailer [3247,3258]
trailer [3247,3258]
===
match
---
simple_stmt [6621,6669]
simple_stmt [6643,6691]
===
match
---
suite [7303,7442]
suite [7325,7464]
===
match
---
simple_stmt [5078,5095]
simple_stmt [5078,5095]
===
match
---
name: stdout [6558,6564]
name: stdout [6580,6586]
===
match
---
decorated [2601,3308]
decorated [2601,3308]
===
match
---
name: self [3774,3778]
name: self [3774,3778]
===
match
---
name: self [3325,3329]
name: self [3325,3329]
===
match
---
tfpdef [2798,2820]
tfpdef [2798,2820]
===
match
---
operator: = [4848,4849]
operator: = [4848,4849]
===
match
---
trailer [3239,3247]
trailer [3239,3247]
===
match
---
simple_stmt [817,843]
simple_stmt [817,843]
===
match
---
name: info [4046,4050]
name: info [4046,4050]
===
match
---
operator: , [3826,3827]
operator: , [3826,3827]
===
match
---
operator: , [2827,2828]
operator: , [2827,2828]
===
match
---
name: execute [3317,3324]
name: execute [3317,3324]
===
match
---
trailer [6161,6167]
trailer [6183,6189]
===
match
---
simple_stmt [2572,2596]
simple_stmt [2572,2596]
===
match
---
param [2939,2948]
param [2939,2948]
===
match
---
name: channel [4932,4939]
name: channel [4932,4939]
===
match
---
name: self [7354,7358]
name: self [7376,7380]
===
match
---
atom_expr [4942,4956]
atom_expr [4942,4956]
===
match
---
suite [4374,4454]
suite [4374,4454]
===
match
---
name: channel [6365,6372]
name: channel [6387,6394]
===
match
---
atom [2541,2567]
atom [2541,2567]
===
match
---
trailer [6494,6502]
trailer [6516,6524]
===
match
---
string: "SSH command not specified. Aborting." [4414,4452]
string: "SSH command not specified. Aborting." [4414,4452]
===
match
---
name: b64encode [807,816]
name: b64encode [807,816]
===
match
---
or_test [5473,5546]
or_test [5473,5546]
===
match
---
argument [4795,4815]
argument [4795,4815]
===
match
---
suite [3413,3850]
suite [3413,3850]
===
match
---
name: strip [6162,6167]
name: strip [6184,6189]
===
match
---
string: b'' [5091,5094]
string: b'' [5091,5094]
===
match
---
name: timeout [3841,3848]
name: timeout [3841,3848]
===
match
---
if_stmt [5930,6175]
if_stmt [5941,6197]
===
match
---
name: in_stderr_buffer [6030,6046]
name: in_stderr_buffer [6041,6057]
===
match
---
param [3325,3330]
param [3325,3330]
===
match
---
with_item [4472,4510]
with_item [4472,4510]
===
match
---
name: line [6091,6095]
name: line [6102,6106]
===
match
---
atom [6198,6407]
atom [6220,6429]
===
match
---
name: bool [2917,2921]
name: bool [2917,2921]
===
match
---
name: log [4533,4536]
name: log [4533,4536]
===
match
---
fstring_end: " [7149,7150]
fstring_end: " [7171,7172]
===
match
---
string: 'remote_host' [2553,2566]
string: 'remote_host' [2553,2566]
===
match
---
expr_stmt [3079,3109]
expr_stmt [3079,3109]
===
match
---
suite [6899,6969]
suite [6921,6991]
===
match
---
name: context [3331,3338]
name: context [3331,3338]
===
match
---
tfpdef [2864,2891]
tfpdef [2864,2891]
===
match
---
suite [7183,7252]
suite [7205,7274]
===
match
---
trailer [6564,6570]
trailer [6586,6592]
===
match
---
name: channel [5519,5526]
name: channel [5519,5526]
===
match
---
not_test [6287,6325]
not_test [6309,6347]
===
match
---
name: self [3870,3874]
name: self [3870,3874]
===
match
---
expr_stmt [3180,3210]
expr_stmt [3180,3210]
===
match
---
name: remote_host [3084,3095]
name: remote_host [3084,3095]
===
match
---
expr_stmt [5111,5127]
expr_stmt [5111,5127]
===
match
---
trailer [4045,4050]
trailer [4045,4050]
===
match
---
if_stmt [6685,7152]
if_stmt [6707,7174]
===
match
---
name: conf [913,917]
name: conf [913,917]
===
match
---
tfpdef [2837,2849]
tfpdef [2837,2849]
===
match
---
trailer [6595,6601]
trailer [6617,6623]
===
match
---
name: command [4570,4577]
name: command [4570,4577]
===
match
---
trailer [5876,5883]
trailer [5876,5883]
===
match
---
name: recv_ready [6373,6383]
name: recv_ready [6395,6405]
===
match
---
simple_stmt [4528,4579]
simple_stmt [4528,4579]
===
match
---
testlist_comp [2588,2594]
testlist_comp [2588,2594]
===
match
---
name: ssh_conn_id [3045,3056]
name: ssh_conn_id [3045,3056]
===
match
---
trailer [6502,6508]
trailer [6524,6530]
===
match
---
and_test [6224,6385]
and_test [6246,6407]
===
match
---
trailer [6570,6572]
trailer [6592,6594]
===
match
---
atom_expr [6358,6385]
atom_expr [6380,6407]
===
match
---
name: ssh_conn_id [2712,2723]
name: ssh_conn_id [2712,2723]
===
match
---
operator: , [5576,5577]
operator: , [5576,5577]
===
match
---
comparison [5297,5321]
comparison [5297,5321]
===
match
---
name: stderr [5994,6000]
name: stderr [6005,6011]
===
match
---
name: __init__ [2625,2633]
name: __init__ [2625,2633]
===
match
---
name: self [3079,3083]
name: self [3079,3083]
===
match
---
name: dict [2886,2890]
name: dict [2886,2890]
===
match
---
return_stmt [6924,6968]
return_stmt [6946,6990]
===
match
---
name: close [6503,6508]
name: close [6525,6530]
===
match
---
name: AirflowException [7077,7093]
name: AirflowException [7099,7115]
===
match
---
string: '\n' [6168,6172]
string: '\n' [6190,6194]
===
match
---
name: remote_host [4310,4321]
name: remote_host [4310,4321]
===
match
---
fstring_expr [7138,7149]
fstring_expr [7160,7171]
===
match
---
trailer [5862,5866]
trailer [5862,5866]
===
match
---
operator: -> [7295,7297]
operator: -> [7317,7319]
===
match
---
trailer [6940,6952]
trailer [6962,6974]
===
match
---
operator: > [5318,5319]
operator: > [5318,5319]
===
match
---
or_test [3235,3277]
or_test [3235,3277]
===
match
---
operator: , [2788,2789]
operator: , [2788,2789]
===
match
---
name: decode [6953,6959]
name: decode [6975,6981]
===
match
---
atom [5600,5602]
atom [5600,5602]
===
match
---
name: stdout [5357,5363]
name: stdout [5357,5363]
===
match
---
expr_stmt [3040,3070]
expr_stmt [3040,3070]
===
match
---
arglist [3462,3484]
arglist [3462,3484]
===
match
---
operator: , [3475,3476]
operator: , [3475,3476]
===
match
---
name: timeout [2837,2844]
name: timeout [2837,2844]
===
match
---
trailer [2988,2998]
trailer [2988,2998]
===
match
---
atom_expr [6224,6258]
atom_expr [6246,6280]
===
match
---
name: recv_ready [5693,5703]
name: recv_ready [5693,5703]
===
match
---
simple_stmt [7261,7273]
simple_stmt [7283,7295]
===
match
---
name: Union [3343,3348]
name: Union [3343,3348]
===
match
---
atom_expr [4803,4815]
atom_expr [4803,4815]
===
match
---
simple_stmt [4391,4454]
simple_stmt [4391,4454]
===
match
---
dotted_name [1063,1087]
dotted_name [1063,1087]
===
match
---
operator: = [2739,2740]
operator: = [2739,2740]
===
match
---
name: ssh_hook [2668,2676]
name: ssh_hook [2668,2676]
===
match
---
operator: = [3021,3022]
operator: = [3021,3022]
===
match
---
trailer [5011,5017]
trailer [5011,5017]
===
match
---
arglist [4542,4577]
arglist [4542,4577]
===
match
---
trailer [6305,6323]
trailer [6327,6345]
===
match
---
operator: = [6742,6743]
operator: = [6764,6765]
===
match
---
name: stderr [6589,6595]
name: stderr [6611,6617]
===
match
---
import_from [966,1005]
import_from [966,1005]
===
match
---
name: self [3462,3466]
name: self [3462,3466]
===
match
---
name: bytes [3349,3354]
name: bytes [3349,3354]
===
match
---
name: utils [1071,1076]
name: utils [1071,1076]
===
match
---
atom_expr [5608,5620]
atom_expr [5608,5620]
===
match
---
param [2755,2789]
param [2755,2789]
===
match
---
atom_expr [3149,3161]
atom_expr [3149,3161]
===
match
---
expr_stmt [6726,6791]
expr_stmt [6748,6813]
===
match
---
name: ssh_client [7415,7425]
name: ssh_client [7437,7447]
===
match
---
trailer [3400,3412]
trailer [3400,3412]
===
match
---
fstring_start: f" [7094,7096]
fstring_start: f" [7116,7118]
===
match
---
trailer [7439,7441]
trailer [7461,7463]
===
match
---
atom_expr [4296,4321]
atom_expr [4296,4321]
===
match
---
name: stdin [4642,4647]
name: stdin [4642,4647]
===
match
---
name: Optional [862,870]
name: Optional [862,870]
===
match
---
testlist_star_expr [4642,4663]
testlist_star_expr [4642,4663]
===
match
---
atom_expr [4472,4496]
atom_expr [4472,4496]
===
match
---
arglist [6760,6790]
arglist [6782,6812]
===
match
---
not_test [5473,5491]
not_test [5473,5491]
===
match
---
not_test [6354,6385]
not_test [6376,6407]
===
match
---
name: providers [1019,1028]
name: providers [1019,1028]
===
match
---
suite [4511,7152]
suite [4511,7174]
===
match
---
atom_expr [4849,4865]
atom_expr [4849,4865]
===
match
---
name: str [3356,3359]
name: str [3356,3359]
===
match
---
name: stdout [6488,6494]
name: stdout [6510,6516]
===
match
---
name: self [5608,5612]
name: self [5608,5612]
===
match
---
name: get_pty [3224,3231]
name: get_pty [3224,3231]
===
match
---
operator: = [3131,3132]
operator: = [3131,3132]
===
match
---
name: Optional [2725,2733]
name: Optional [2725,2733]
===
match
---
name: self [3507,3511]
name: self [3507,3511]
===
match
---
name: conf [6744,6748]
name: conf [6766,6770]
===
match
---
trailer [6959,6968]
trailer [6981,6990]
===
match
---
operator: = [7022,7023]
operator: = [7044,7045]
===
match
---
name: self [3149,3153]
name: self [3149,3153]
===
match
---
atom [5604,5606]
atom [5604,5606]
===
match
---
name: str [2816,2819]
name: str [2816,2819]
===
match
---
subscriptlist [3349,3365]
subscriptlist [3349,3365]
===
match
---
name: bool [3361,3365]
name: bool [3361,3365]
===
match
---
simple_stmt [5343,5399]
simple_stmt [5343,5399]
===
match
---
trailer [6372,6383]
trailer [6394,6405]
===
match
---
name: self [2643,2647]
name: self [2643,2647]
===
match
---
name: airflow [1011,1018]
name: airflow [1011,1018]
===
match
---
operator: , [2658,2659]
operator: , [2658,2659]
===
match
---
name: exit_status [6688,6699]
name: exit_status [6710,6721]
===
match
---
operator: = [4802,4803]
operator: = [4802,4803]
===
match
---
and_test [3433,3485]
and_test [3433,3485]
===
match
---
atom_expr [4761,4773]
atom_expr [4761,4773]
===
match
---
operator: , [6766,6767]
operator: , [6788,6789]
===
match
---
name: line [5872,5876]
name: line [5872,5876]
===
match
---
simple_stmt [3901,3975]
simple_stmt [3901,3975]
===
match
---
trailer [7367,7376]
trailer [7389,7398]
===
match
---
atom_expr [3219,3231]
atom_expr [3219,3231]
===
match
---
trailer [6508,6510]
trailer [6530,6532]
===
match
---
atom_expr [3616,3753]
atom_expr [3616,3753]
===
match
---
name: self [6124,6128]
name: self [6135,6139]
===
match
---
name: startswith [3248,3258]
name: startswith [3248,3258]
===
match
---
name: self [4361,4365]
name: self [4361,4365]
===
match
---
trailer [4948,4956]
trailer [4948,4956]
===
match
---
operator: , [2929,2930]
operator: , [2929,2930]
===
match
---
fstring_end: " [7249,7250]
fstring_end: " [7271,7272]
===
match
---
operator: = [4718,4719]
operator: = [4718,4719]
===
match
---
trailer [4309,4321]
trailer [4309,4321]
===
match
---
argument [2989,2997]
argument [2989,2997]
===
match
---
suite [3367,7273]
suite [3367,7295]
===
match
---
expr_stmt [2523,2567]
expr_stmt [2523,2567]
===
match
---
name: Optional [2807,2815]
name: Optional [2807,2815]
===
match
---
trailer [5883,5892]
trailer [5883,5903]
===
match
---
name: self [4528,4532]
name: self [4528,4532]
===
match
---
name: recv_stderr_ready [5527,5544]
name: recv_stderr_ready [5527,5544]
===
match
---
operator: , [4563,4564]
operator: , [4563,4564]
===
match
---
name: shutdown_read [6448,6461]
name: shutdown_read [6470,6483]
===
match
---
name: ssh_hook [4477,4485]
name: ssh_hook [4477,4485]
===
match
---
simple_stmt [3180,3211]
simple_stmt [3180,3211]
===
match
---
name: get_pty [4753,4760]
name: get_pty [4753,4760]
===
match
---
expr_stmt [3149,3171]
expr_stmt [3149,3171]
===
match
---
name: self [3180,3184]
name: self [3180,3184]
===
match
---
name: recv_ready [5503,5513]
name: recv_ready [5503,5513]
===
match
---
name: self [3616,3620]
name: self [3616,3620]
===
match
---
simple_stmt [3219,3308]
simple_stmt [3219,3308]
===
match
---
operator: , [2898,2899]
operator: , [2898,2899]
===
match
---
operator: = [3788,3789]
operator: = [3788,3789]
===
match
---
name: select [5582,5588]
name: select [5582,5588]
===
match
---
trailer [5265,5275]
trailer [5265,5275]
===
match
---
operator: * [2657,2658]
operator: * [2657,2658]
===
match
---
trailer [6256,6258]
trailer [6278,6280]
===
match
---
comp_op [4008,4014]
comp_op [4008,4014]
===
match
---
with_stmt [4467,7152]
with_stmt [4467,7174]
===
match
---
name: isinstance [3451,3461]
name: isinstance [3451,3461]
===
match
---
simple_stmt [3774,3850]
simple_stmt [3774,3850]
===
match
---
name: recv_stderr_ready [6306,6323]
name: recv_stderr_ready [6328,6345]
===
match
---
atom_expr [3462,3475]
atom_expr [3462,3475]
===
match
---
name: info [3516,3520]
name: info [3516,3520]
===
match
---
trailer [4807,4815]
trailer [4807,4815]
===
match
---
comparison [3991,4019]
comparison [3991,4019]
===
match
---
simple_stmt [3040,3071]
simple_stmt [3040,3071]
===
match
---
atom_expr [5688,5705]
atom_expr [5688,5705]
===
match
---
name: in_buffer [5266,5275]
name: in_buffer [5266,5275]
===
match
---
name: _ [5578,5579]
name: _ [5578,5579]
===
match
---
testlist_star_expr [5568,5579]
testlist_star_expr [5568,5579]
===
match
---
name: SSHHook [3477,3484]
name: SSHHook [3477,3484]
===
match
---
expr_stmt [5735,5782]
expr_stmt [5735,5782]
===
match
---
tfpdef [2668,2695]
tfpdef [2668,2695]
===
match
---
param [2798,2828]
param [2798,2828]
===
match
---
name: error_msg [7012,7021]
name: error_msg [7034,7043]
===
match
---
atom_expr [3451,3485]
atom_expr [3451,3485]
===
match
---
name: stderr [4657,4663]
name: stderr [4657,4663]
===
match
---
name: get_transport [7426,7439]
name: get_transport [7448,7461]
===
match
---
operator: , [4773,4774]
operator: , [4773,4774]
===
match
---
atom_expr [3790,3849]
atom_expr [3790,3849]
===
match
---
name: ssh_client [7341,7351]
name: ssh_client [7363,7373]
===
match
---
atom_expr [4037,4279]
atom_expr [4037,4279]
===
match
---
suite [5706,5906]
suite [5706,5917]
===
match
---
name: self [4037,4041]
name: self [4037,4041]
===
match
---
atom_expr [7077,7151]
atom_expr [7099,7173]
===
match
---
name: getboolean [6749,6759]
name: getboolean [6771,6781]
===
match
---
name: Optional [2768,2776]
name: Optional [2768,2776]
===
match
---
number: 10 [2852,2854]
number: 10 [2852,2854]
===
match
---
string: "remote_host is provided explicitly. " [4072,4110]
string: "remote_host is provided explicitly. " [4072,4110]
===
match
---
name: Union [872,877]
name: Union [872,877]
===
match
---
operator: = [3096,3097]
operator: = [3096,3097]
===
match
---
name: enable_pickling [6815,6830]
name: enable_pickling [6837,6852]
===
match
---
tfpdef [2755,2781]
tfpdef [2755,2781]
===
match
---
name: environment [4837,4848]
name: environment [4837,4848]
===
match
---
name: recv_stderr [6009,6020]
name: recv_stderr [6020,6031]
===
match
---
tfpdef [2712,2738]
tfpdef [2712,2738]
===
match
---
trailer [3286,3294]
trailer [3286,3294]
===
match
---
trailer [2733,2738]
trailer [2733,2738]
===
match
---
string: 'core' [6760,6766]
string: 'core' [6782,6788]
===
match
---
name: Optional [2678,2686]
name: Optional [2678,2686]
===
match
---
trailer [3995,4007]
trailer [3995,4007]
===
match
---
trailer [5955,5957]
trailer [5966,5968]
===
insert-node
---
arglist [5884,5902]
to
trailer [5883,5892]
at 0
===
insert-node
---
arglist [6164,6182]
to
trailer [6152,6161]
at 0
===
move-tree
---
string: 'utf-8' [5884,5891]
to
arglist [5884,5902]
at 0
===
move-tree
---
string: 'utf-8' [6153,6160]
to
arglist [6164,6182]
at 0
