===
match
---
funcdef [2967,3555]
funcdef [2967,3555]
===
match
---
trailer [1330,1334]
trailer [1330,1334]
===
match
---
name: MagicMock [6387,6396]
name: MagicMock [6414,6423]
===
match
---
atom_expr [12131,12151]
atom_expr [12158,12178]
===
match
---
simple_stmt [1494,1571]
simple_stmt [1494,1571]
===
match
---
name: ensure_plugins_loaded [4011,4032]
name: ensure_plugins_loaded [4011,4032]
===
match
---
string: 'view' [1543,1549]
string: 'view' [1543,1549]
===
match
---
simple_stmt [12031,12080]
simple_stmt [12058,12107]
===
match
---
simple_stmt [6471,6503]
simple_stmt [6498,6530]
===
match
---
expr_stmt [11624,11647]
expr_stmt [11651,11674]
===
match
---
atom [10036,10050]
atom [10063,10077]
===
match
---
name: modules [9758,9765]
name: modules [9785,9792]
===
match
---
atom_expr [4452,4479]
atom_expr [4452,4479]
===
match
---
atom [7158,7176]
atom [7185,7203]
===
match
---
name: logging [8495,8502]
name: logging [8522,8529]
===
match
---
name: received_logs [8605,8618]
name: received_logs [8632,8645]
===
match
---
name: airflow [11435,11442]
name: airflow [11462,11469]
===
match
---
name: AirflowPlugin [5034,5047]
name: AirflowPlugin [5061,5074]
===
match
---
name: name [2227,2231]
name: name [2227,2231]
===
match
---
suite [9056,10902]
suite [9083,10929]
===
match
---
comparison [8832,8890]
comparison [8859,8917]
===
match
---
name: source [12062,12068]
name: source [12089,12095]
===
match
---
suite [2313,2962]
suite [2313,2962]
===
match
---
name: caplog [3878,3884]
name: caplog [3878,3884]
===
match
---
import_from [1426,1484]
import_from [1426,1484]
===
match
---
trailer [4809,4817]
trailer [4836,4844]
===
match
---
atom [8910,8975]
atom [8937,9002]
===
match
---
name: MacroPlugin [10404,10415]
name: MacroPlugin [10431,10442]
===
match
---
atom [11677,11711]
atom [11704,11738]
===
match
---
with_stmt [6568,6857]
with_stmt [6595,6884]
===
match
---
trailer [1256,1260]
trailer [1256,1260]
===
match
---
simple_stmt [846,872]
simple_stmt [846,872]
===
match
---
operator: = [1516,1517]
operator: = [1516,1517]
===
match
---
operator: , [6172,6173]
operator: , [6199,6200]
===
match
---
for_stmt [10391,10619]
for_stmt [10418,10646]
===
match
---
dotted_name [9218,9241]
dotted_name [9245,9268]
===
match
---
import_from [2322,2387]
import_from [2322,2387]
===
match
---
funcdef [9283,9838]
funcdef [9310,9865]
===
match
---
suite [9912,9938]
suite [9939,9965]
===
match
---
name: appbuilder_views [2456,2472]
name: appbuilder_views [2456,2472]
===
match
---
comparison [2939,2961]
comparison [2939,2961]
===
match
---
testlist_comp [5345,5401]
testlist_comp [5372,5428]
===
match
---
trailer [6854,6856]
trailer [6881,6883]
===
match
---
funcdef [9893,9938]
funcdef [9920,9965]
===
match
---
simple_stmt [11953,12023]
simple_stmt [11980,12050]
===
match
---
trailer [10105,10107]
trailer [10132,10134]
===
match
---
name: self [3722,3726]
name: self [3722,3726]
===
match
---
name: plugins_manager [11902,11917]
name: plugins_manager [11929,11944]
===
match
---
atom_expr [11902,11943]
atom_expr [11929,11970]
===
match
---
trailer [5709,5717]
trailer [5736,5744]
===
match
---
name: mock_dist [8010,8019]
name: mock_dist [8037,8046]
===
match
---
classdef [6990,7177]
classdef [7017,7204]
===
match
---
name: mock_dist [11720,11729]
name: mock_dist [11747,11756]
===
match
---
param [4132,4138]
param [4132,4138]
===
match
---
with_stmt [10060,10902]
with_stmt [10087,10929]
===
match
---
atom_expr [6382,6398]
atom_expr [6409,6425]
===
match
---
simple_stmt [3141,3300]
simple_stmt [3141,3300]
===
match
---
atom_expr [4679,4707]
atom_expr [4706,4734]
===
match
---
argument [7427,7493]
argument [7454,7520]
===
match
---
simple_stmt [3698,3742]
simple_stmt [3698,3742]
===
match
---
operator: == [12248,12250]
operator: == [12275,12277]
===
match
---
atom_expr [1203,1220]
atom_expr [1203,1220]
===
match
---
name: AirflowAdminMenuLinksPlugin [5156,5183]
name: AirflowAdminMenuLinksPlugin [5183,5210]
===
match
---
param [4126,4131]
param [4126,4131]
===
match
---
atom_expr [1518,1570]
atom_expr [1518,1570]
===
match
---
trailer [11502,11504]
trailer [11529,11531]
===
match
---
import_from [11430,11465]
import_from [11457,11492]
===
match
---
operator: = [6613,6614]
operator: = [6640,6641]
===
match
---
name: TestCase [1212,1220]
name: TestCase [1212,1220]
===
match
---
name: view [2819,2823]
name: view [2819,2823]
===
match
---
simple_stmt [8010,8034]
simple_stmt [8037,8061]
===
match
---
operator: == [3797,3799]
operator: == [3797,3799]
===
match
---
name: __class__ [1551,1560]
name: __class__ [1551,1560]
===
match
---
simple_stmt [6813,6857]
simple_stmt [6840,6884]
===
match
---
name: __file__ [11110,11118]
name: __file__ [11137,11145]
===
match
---
name: plugins_manager [4753,4768]
name: plugins_manager [4780,4795]
===
match
---
name: mock_entrypoint [12135,12150]
name: mock_entrypoint [12162,12177]
===
match
---
argument [5447,5479]
argument [5474,5506]
===
match
---
number: 0 [3519,3520]
number: 0 [3519,3520]
===
match
---
name: v_nomenu_appbuilder_package [2542,2569]
name: v_nomenu_appbuilder_package [2542,2569]
===
match
---
atom_expr [2696,2743]
atom_expr [2696,2743]
===
match
---
atom_expr [3800,3807]
atom_expr [3800,3807]
===
match
---
import_name [830,845]
import_name [830,845]
===
match
---
name: self [1899,1903]
name: self [1899,1903]
===
match
---
operator: @ [4252,4253]
operator: @ [4252,4253]
===
match
---
name: mock [8061,8065]
name: mock [8088,8092]
===
match
---
atom_expr [4803,4831]
atom_expr [4830,4858]
===
match
---
fstring [10341,10377]
fstring [10368,10404]
===
match
---
operator: == [2957,2959]
operator: == [2957,2959]
===
match
---
simple_stmt [9796,9838]
simple_stmt [9823,9865]
===
match
---
name: name [3455,3459]
name: name [3455,3459]
===
match
---
operator: , [5990,5991]
operator: , [6017,6018]
===
match
---
dotted_name [2327,2352]
dotted_name [2327,2352]
===
match
---
trailer [7163,7173]
trailer [7190,7200]
===
match
---
name: test_no_log_when_no_plugins [3844,3871]
name: test_no_log_when_no_plugins [3844,3871]
===
match
---
suite [4140,4925]
suite [4140,4952]
===
match
---
simple_stmt [10192,10219]
simple_stmt [10219,10246]
===
match
---
name: name [10896,10900]
name: name [10923,10927]
===
match
---
atom_expr [5975,5990]
atom_expr [6002,6017]
===
match
---
operator: = [3424,3425]
operator: = [3424,3425]
===
match
---
trailer [5137,5139]
trailer [5164,5166]
===
match
---
arglist [8400,8463]
arglist [8427,8490]
===
match
---
trailer [5275,5285]
trailer [5302,5312]
===
match
---
import_from [1006,1067]
import_from [1006,1067]
===
match
---
trailer [11729,11737]
trailer [11756,11764]
===
match
---
simple_stmt [4209,4239]
simple_stmt [4209,4239]
===
match
---
atom_expr [7505,7571]
atom_expr [7532,7598]
===
match
---
name: integrate_macros_plugins [9249,9273]
name: integrate_macros_plugins [9276,9300]
===
match
---
name: name [5062,5066]
name: name [5089,5093]
===
match
---
name: plugins_manager [3966,3981]
name: plugins_manager [3966,3981]
===
match
---
name: plugins [3029,3036]
name: plugins [3029,3036]
===
match
---
operator: = [1122,1123]
operator: = [1122,1123]
===
match
---
import_as_names [7962,8000]
import_as_names [7989,8027]
===
match
---
simple_stmt [10861,10902]
simple_stmt [10888,10929]
===
match
---
operator: = [1074,1075]
operator: = [1074,1075]
===
match
---
simple_stmt [11184,11248]
simple_stmt [11211,11275]
===
match
---
suite [5049,5141]
suite [5076,5168]
===
match
---
name: TestCase [10946,10954]
name: TestCase [10973,10981]
===
match
---
name: mock_dist [12012,12021]
name: mock_dist [12039,12048]
===
match
---
comparison [1654,1698]
comparison [1654,1698]
===
match
---
parameters [3002,3008]
parameters [3002,3008]
===
match
---
expr_stmt [7337,7379]
expr_stmt [7364,7406]
===
match
---
name: airflow [918,925]
name: airflow [918,925]
===
match
---
name: menu_links [7293,7303]
name: menu_links [7320,7330]
===
match
---
name: AirflowTestPropertyPlugin [4452,4477]
name: AirflowTestPropertyPlugin [4452,4477]
===
match
---
simple_stmt [3018,3073]
simple_stmt [3018,3073]
===
match
---
atom [7435,7493]
atom [7462,7520]
===
match
---
name: load_entrypoint_plugins [8566,8589]
name: load_entrypoint_plugins [8593,8616]
===
match
---
name: AirflowAdminMenuLinksPlugin [6642,6669]
name: AirflowAdminMenuLinksPlugin [6669,6696]
===
match
---
name: v_appbuilder_package [2235,2255]
name: v_appbuilder_package [2235,2255]
===
match
---
dictorsetmaker [11678,11710]
dictorsetmaker [11705,11737]
===
match
---
arglist [10876,10900]
arglist [10903,10927]
===
match
---
arglist [6700,6749]
arglist [6727,6776]
===
match
---
name: plugins_manager [11037,11052]
name: plugins_manager [11064,11079]
===
match
---
operator: = [11738,11739]
operator: = [11765,11766]
===
match
---
number: 1 [2031,2032]
number: 1 [2031,2032]
===
match
---
simple_stmt [7248,7280]
simple_stmt [7275,7307]
===
match
---
trailer [2942,2956]
trailer [2942,2956]
===
match
---
atom [6897,6899]
atom [6924,6926]
===
match
---
fstring_expr [8402,8422]
fstring_expr [8429,8449]
===
match
---
operator: = [8451,8452]
operator: = [8478,8479]
===
match
---
name: group [8146,8151]
name: group [8173,8178]
===
match
---
operator: } [11710,11711]
operator: } [11737,11738]
===
match
---
trailer [12230,12247]
trailer [12257,12274]
===
match
---
trailer [1521,1570]
trailer [1521,1570]
===
match
---
name: app [1331,1334]
name: app [1331,1334]
===
match
---
name: name [1669,1673]
name: name [1669,1673]
===
match
---
trailer [11645,11647]
trailer [11672,11674]
===
match
---
operator: , [5370,5371]
operator: , [5397,5398]
===
match
---
name: AirflowNoMenuViewsPlugin [2641,2665]
name: AirflowNoMenuViewsPlugin [2641,2665]
===
match
---
assert_stmt [4796,4842]
assert_stmt [4823,4869]
===
match
---
atom_expr [6700,6715]
atom_expr [6727,6742]
===
match
---
operator: = [8355,8356]
operator: = [8382,8383]
===
match
---
expr_stmt [1838,2000]
expr_stmt [1838,2000]
===
match
---
trailer [9805,9819]
trailer [9832,9846]
===
match
---
name: appbuilder_views [7139,7155]
name: appbuilder_views [7166,7182]
===
match
---
simple_stmt [2456,2505]
simple_stmt [2456,2505]
===
match
---
atom_expr [3530,3554]
atom_expr [3530,3554]
===
match
---
import_from [4495,4530]
import_from [4495,4530]
===
match
---
operator: == [11161,11163]
operator: == [11188,11190]
===
match
---
name: caplog [6684,6690]
name: caplog [6711,6717]
===
match
---
comparison [1725,1747]
comparison [1725,1747]
===
match
---
string: 'module_name_plugin' [11594,11614]
string: 'module_name_plugin' [11621,11641]
===
match
---
classdef [9947,10051]
classdef [9974,10078]
===
match
---
simple_stmt [8762,8813]
simple_stmt [8789,8840]
===
match
---
name: mock [6382,6386]
name: mock [6409,6413]
===
match
---
expr_stmt [6516,6558]
expr_stmt [6543,6585]
===
match
---
atom_expr [6573,6682]
atom_expr [6600,6709]
===
match
---
atom_expr [10937,10954]
atom_expr [10964,10981]
===
match
---
assert_stmt [8825,8890]
assert_stmt [8852,8917]
===
match
---
expr_stmt [11720,11747]
expr_stmt [11747,11774]
===
match
---
assert_stmt [7687,7720]
assert_stmt [7714,7747]
===
match
---
operator: , [7975,7976]
operator: , [8002,8003]
===
match
---
trailer [6396,6398]
trailer [6423,6425]
===
match
---
simple_stmt [4796,4843]
simple_stmt [4823,4870]
===
match
---
atom_expr [8495,8508]
atom_expr [8522,8535]
===
match
---
dotted_name [3023,3048]
dotted_name [3023,3048]
===
match
---
suite [7796,9001]
suite [7823,9028]
===
match
---
trailer [6828,6854]
trailer [6855,6881]
===
match
---
name: airflow [4500,4507]
name: airflow [4500,4507]
===
match
---
trailer [2020,2027]
trailer [2020,2027]
===
match
---
param [11002,11006]
param [11029,11033]
===
match
---
operator: , [8464,8465]
operator: , [8491,8492]
===
match
---
name: mock_dist [11656,11665]
name: mock_dist [11683,11692]
===
match
---
name: caplog [6973,6979]
name: caplog [7000,7006]
===
match
---
parameters [1410,1416]
parameters [1410,1416]
===
match
---
name: name [11529,11533]
name: name [11556,11560]
===
match
---
name: menu_links [5257,5267]
name: menu_links [5284,5294]
===
match
---
testlist_comp [8911,8974]
testlist_comp [8938,9001]
===
match
---
name: links [1838,1843]
name: links [1838,1843]
===
match
---
operator: == [3460,3462]
operator: == [3460,3462]
===
match
---
trailer [5399,5401]
trailer [5426,5428]
===
match
---
name: plugins [4443,4450]
name: plugins [4443,4450]
===
match
---
comparison [6873,6899]
comparison [6900,6926]
===
match
---
comp_if [1937,1990]
comp_if [1937,1990]
===
match
---
atom_expr [2542,2596]
atom_expr [2542,2596]
===
match
---
name: self [6967,6971]
name: self [6994,6998]
===
match
---
arglist [11824,11887]
arglist [11851,11914]
===
match
---
string: "test-entrypoint-plugin==1.0.0: " [12095,12128]
string: "test-entrypoint-plugin==1.0.0: " [12122,12155]
===
match
---
expr_stmt [10301,10378]
expr_stmt [10328,10405]
===
match
---
simple_stmt [7094,7127]
simple_stmt [7121,7154]
===
match
---
import_name [804,818]
import_name [804,818]
===
match
---
assert_stmt [4851,4924]
assert_stmt [4878,4951]
===
match
---
name: menu_item [3189,3198]
name: menu_item [3189,3198]
===
match
---
suite [7572,7678]
suite [7599,7705]
===
match
---
operator: - [4818,4819]
operator: - [4845,4846]
===
match
---
param [2307,2311]
param [2307,2311]
===
match
---
string: "Plugin 'test_admin_views_plugin' may not be compatible with the current Airflow version. " [5735,5826]
string: "Plugin 'test_admin_views_plugin' may not be compatible with the current Airflow version. " [5762,5853]
===
match
---
assert_stmt [8689,8749]
assert_stmt [8716,8776]
===
match
---
atom_expr [7394,7503]
atom_expr [7421,7530]
===
match
---
name: test_entrypoint_plugin_errors_dont_raise_exceptions [7730,7781]
name: test_entrypoint_plugin_errors_dont_raise_exceptions [7757,7808]
===
match
---
name: self [11415,11419]
name: self [11442,11446]
===
match
---
fstring_end: ' [8436,8437]
fstring_end: ' [8463,8464]
===
match
---
simple_stmt [8903,9001]
simple_stmt [8930,9028]
===
match
---
name: admin_views [5108,5119]
name: admin_views [5135,5146]
===
match
---
atom [2475,2504]
atom [2475,2504]
===
match
---
atom_expr [11317,11334]
atom_expr [11344,11361]
===
match
---
atom_expr [11164,11175]
atom_expr [11191,11202]
===
match
---
name: airflow [968,975]
name: airflow [968,975]
===
match
---
atom [5627,6183]
atom [5654,6210]
===
match
---
trailer [6669,6671]
trailer [6696,6698]
===
match
---
simple_stmt [10027,10051]
simple_stmt [10054,10078]
===
match
---
classdef [10904,11335]
classdef [10931,11362]
===
match
---
operator: = [4214,4215]
operator: = [4214,4215]
===
match
---
atom_expr [11513,11533]
atom_expr [11540,11560]
===
match
---
fstring_end: " [10376,10377]
fstring_end: " [10403,10404]
===
match
---
operator: = [6321,6322]
operator: = [6348,6349]
===
match
---
argument [7538,7570]
argument [7565,7597]
===
match
---
suite [6303,6400]
suite [6330,6427]
===
match
---
name: TestPropertyHook [4313,4329]
name: TestPropertyHook [4313,4329]
===
match
---
simple_stmt [3443,3492]
simple_stmt [3443,3492]
===
match
---
string: "test_property_plugin" [4216,4238]
string: "test_property_plugin" [4216,4238]
===
match
---
simple_stmt [4544,4576]
simple_stmt [4544,4603]
===
match
---
expr_stmt [6362,6399]
expr_stmt [6389,6426]
===
match
---
trailer [7311,7321]
trailer [7338,7348]
===
match
---
strings [6008,6157]
strings [6035,6184]
===
match
---
expr_stmt [11062,11119]
expr_stmt [11089,11146]
===
match
---
parameters [4283,4289]
parameters [4283,4289]
===
match
---
operator: = [6538,6539]
operator: = [6565,6566]
===
match
---
expr_stmt [1103,1178]
expr_stmt [1103,1178]
===
match
---
simple_stmt [9847,9884]
simple_stmt [9874,9911]
===
match
---
name: mock [7362,7366]
name: mock [7389,7393]
===
match
---
name: self [4126,4130]
name: self [4126,4130]
===
match
---
name: MacroPlugin [10359,10370]
name: MacroPlugin [10386,10397]
===
match
---
parameters [6966,6980]
parameters [6993,7007]
===
match
---
suite [6458,6559]
suite [6485,6586]
===
match
---
dotted_name [968,979]
dotted_name [968,979]
===
match
---
atom_expr [8130,8151]
atom_expr [8157,8178]
===
match
---
trailer [8269,8281]
trailer [8296,8308]
===
match
---
trailer [11239,11247]
trailer [11266,11274]
===
match
---
classdef [7186,7380]
classdef [7213,7407]
===
match
---
atom_expr [1654,1673]
atom_expr [1654,1673]
===
match
---
suite [6249,6900]
suite [6276,6927]
===
match
---
atom_expr [3757,3796]
atom_expr [3757,3796]
===
match
---
trailer [11086,11109]
trailer [11113,11136]
===
match
---
name: app [1257,1260]
name: app [1257,1260]
===
match
---
name: airflow [9218,9225]
name: airflow [9245,9252]
===
match
---
name: plugin_macros [10301,10314]
name: plugin_macros [10328,10341]
===
match
---
trailer [10370,10375]
trailer [10397,10402]
===
match
---
operator: = [1592,1593]
operator: = [1592,1593]
===
match
---
simple_stmt [7048,7081]
simple_stmt [7075,7108]
===
match
---
simple_stmt [6516,6559]
simple_stmt [6543,6586]
===
match
---
number: 1 [3330,3331]
number: 1 [3330,3331]
===
match
---
name: ERROR [8503,8508]
name: ERROR [8530,8535]
===
match
---
comparison [8910,9000]
comparison [8937,9027]
===
match
---
simple_stmt [8130,8172]
simple_stmt [8157,8199]
===
match
---
name: registered_hooks [4769,4785]
name: registered_hooks [4796,4812]
===
match
---
argument [8439,8463]
argument [8466,8490]
===
match
---
simple_stmt [2514,2598]
simple_stmt [2514,2598]
===
match
---
simple_stmt [1103,1179]
simple_stmt [1103,1179]
===
match
---
name: www [976,979]
name: www [976,979]
===
match
---
operator: , [11861,11862]
operator: , [11888,11889]
===
match
---
name: return_value [8439,8451]
name: return_value [8466,8478]
===
match
---
import_from [846,871]
import_from [846,871]
===
match
---
string: "airflow.plugins_manager" [5659,5684]
string: "airflow.plugins_manager" [5686,5711]
===
match
---
atom_expr [10192,10218]
atom_expr [10219,10245]
===
match
---
operator: { [11677,11678]
operator: { [11704,11705]
===
match
---
simple_stmt [5596,6184]
simple_stmt [5623,6211]
===
match
---
string: 'name' [3547,3553]
string: 'name' [3547,3553]
===
match
---
trailer [7675,7677]
trailer [7702,7704]
===
match
---
atom_expr [1263,1299]
atom_expr [1263,1299]
===
match
---
trailer [1542,1550]
trailer [1542,1550]
===
match
---
atom_expr [2127,2135]
atom_expr [2127,2135]
===
match
---
simple_stmt [3419,3435]
simple_stmt [3419,3435]
===
match
---
expr_stmt [1308,1345]
expr_stmt [1308,1345]
===
match
---
name: self [4284,4288]
name: self [4284,4288]
===
match
---
simple_stmt [5543,5587]
simple_stmt [5570,5614]
===
match
---
name: plugins [7427,7434]
name: plugins [7454,7461]
===
match
---
string: 'importlib.metadata' [1124,1144]
string: 'importlib.metadata' [1124,1144]
===
match
---
name: initialize_web_ui_plugins [6829,6854]
name: initialize_web_ui_plugins [6856,6881]
===
match
---
name: self [3872,3876]
name: self [3872,3876]
===
match
---
operator: = [1324,1325]
operator: = [1324,1325]
===
match
---
testlist_comp [2819,2904]
testlist_comp [2819,2904]
===
match
---
name: AirflowPlugin [6443,6456]
name: AirflowPlugin [6470,6483]
===
match
---
atom_expr [9847,9883]
atom_expr [9874,9910]
===
match
---
trailer [9867,9883]
trailer [9894,9910]
===
match
---
operator: == [6894,6896]
operator: == [6921,6923]
===
match
---
name: self [1252,1256]
name: self [1252,1256]
===
match
---
simple_stmt [7805,7918]
simple_stmt [7832,7945]
===
match
---
name: plugins_manager [9226,9241]
name: plugins_manager [9253,9268]
===
match
---
comparison [7694,7720]
comparison [7721,7747]
===
match
---
operator: = [1844,1845]
operator: = [1844,1845]
===
match
---
simple_stmt [2120,2136]
simple_stmt [2120,2136]
===
match
---
name: logging [811,818]
name: logging [811,818]
===
match
---
operator: , [3876,3877]
operator: , [3876,3877]
===
match
---
trailer [12068,12079]
trailer [12095,12106]
===
match
---
name: mock_plugin_manager [3901,3920]
name: mock_plugin_manager [3901,3920]
===
match
---
string: 'name' [11678,11684]
string: 'name' [11705,11711]
===
match
---
parameters [11001,11007]
parameters [11028,11034]
===
match
---
funcdef [9006,10902]
funcdef [9033,10929]
===
match
---
simple_stmt [7293,7325]
simple_stmt [7320,7352]
===
match
---
name: logging [7521,7528]
name: logging [7548,7555]
===
match
---
import_name [787,803]
import_name [787,803]
===
match
---
assert_stmt [4641,4707]
assert_stmt [4668,4734]
===
match
---
name: logger [5447,5453]
name: logger [5474,5480]
===
match
---
parameters [11414,11420]
parameters [11441,11447]
===
match
---
operator: = [8282,8283]
operator: = [8309,8310]
===
match
---
atom_expr [3463,3491]
atom_expr [3463,3491]
===
match
---
trailer [8399,8464]
trailer [8426,8491]
===
match
---
simple_stmt [3946,3982]
simple_stmt [3946,3982]
===
match
---
trailer [4550,4560]
trailer [4550,4560]
===
match
---
atom_expr [6684,6750]
atom_expr [6711,6777]
===
match
---
name: AirflowPlugin [949,962]
name: AirflowPlugin [949,962]
===
match
---
suite [6751,6857]
suite [6778,6884]
===
match
---
operator: == [7715,7717]
operator: == [7742,7744]
===
match
---
name: self [3003,3007]
name: self [3003,3007]
===
match
---
arglist [5430,5479]
arglist [5457,5506]
===
match
---
funcdef [1380,2264]
funcdef [1380,2264]
===
match
---
simple_stmt [1718,1748]
simple_stmt [1718,1748]
===
match
---
simple_stmt [1252,1300]
simple_stmt [1252,1300]
===
match
---
name: link [3450,3454]
name: link [3450,3454]
===
match
---
name: WARNING [5983,5990]
name: WARNING [6010,6017]
===
match
---
string: "test_admin_views_plugin" [7055,7080]
string: "test_admin_views_plugin" [7082,7107]
===
match
---
operator: == [2880,2882]
operator: == [2880,2882]
===
match
---
name: test_plugin [2341,2352]
name: test_plugin [2341,2352]
===
match
---
name: load_entrypoint_plugins [7977,8000]
name: load_entrypoint_plugins [8004,8027]
===
match
---
operator: { [10358,10359]
operator: { [10385,10386]
===
match
---
operator: = [8102,8103]
operator: = [8129,8130]
===
match
---
trailer [8589,8591]
trailer [8616,8618]
===
match
---
name: AirflowAdminViewsPlugin [5345,5368]
name: AirflowAdminViewsPlugin [5372,5395]
===
match
---
name: source [11062,11068]
name: source [11089,11095]
===
match
---
param [1411,1415]
param [1411,1415]
===
match
---
simple_stmt [2683,2773]
simple_stmt [2683,2773]
===
match
---
name: request [9847,9854]
name: request [9874,9881]
===
match
---
parameters [4980,4994]
parameters [5007,5021]
===
match
---
operator: == [1743,1745]
operator: == [1743,1745]
===
match
---
name: name [3522,3526]
name: name [3522,3526]
===
match
---
fstring_start: f" [10341,10343]
fstring_start: f" [10368,10370]
===
match
---
name: caplog [8621,8627]
name: caplog [8648,8654]
===
match
---
atom_expr [11962,12022]
atom_expr [11989,12049]
===
match
---
name: MagicMock [5128,5137]
name: MagicMock [5155,5164]
===
match
---
operator: , [7503,7504]
operator: , [7530,7531]
===
match
---
name: plugin_views [2786,2798]
name: plugin_views [2786,2798]
===
match
---
atom [7306,7324]
atom [7333,7351]
===
match
---
simple_stmt [9178,9205]
simple_stmt [9205,9232]
===
match
---
trailer [11323,11332]
trailer [11350,11359]
===
match
---
suite [1417,2264]
suite [1417,2264]
===
match
---
name: plugins [1437,1444]
name: plugins [1437,1444]
===
match
---
name: application [1263,1274]
name: application [1263,1274]
===
match
---
atom_expr [8621,8632]
atom_expr [8648,8659]
===
match
---
operator: , [10882,10883]
operator: , [10909,10910]
===
match
---
atom_expr [11236,11247]
atom_expr [11263,11274]
===
match
---
name: view [1617,1621]
name: view [1617,1621]
===
match
---
funcdef [6905,7721]
funcdef [6932,7748]
===
match
---
trailer [10415,10422]
trailer [10442,10449]
===
match
---
strings [5735,5885]
strings [5762,5912]
===
match
---
parameters [3871,3885]
parameters [3871,3885]
===
match
---
name: WARNING [5710,5717]
name: WARNING [5737,5744]
===
match
---
trailer [2665,2667]
trailer [2665,2667]
===
match
---
name: tests [3023,3028]
name: tests [3023,3028]
===
match
---
trailer [11823,11888]
trailer [11850,11915]
===
match
---
name: entrypoint [12069,12079]
name: entrypoint [12096,12106]
===
match
---
name: test_should_return_correct_source_details [11373,11414]
name: test_should_return_correct_source_details [11400,11441]
===
match
---
string: 'airflow.macros' [9820,9836]
string: 'airflow.macros' [9847,9863]
===
match
---
simple_stmt [5494,5530]
simple_stmt [5521,5557]
===
match
---
with_stmt [7389,7678]
with_stmt [7416,7705]
===
match
---
operator: , [8946,8947]
operator: , [8973,8974]
===
match
---
trailer [10945,10954]
trailer [10972,10981]
===
match
---
operator: = [11634,11635]
operator: = [11661,11662]
===
match
---
name: WARNING [6708,6715]
name: WARNING [6735,6742]
===
match
---
name: bp [3800,3802]
name: bp [3800,3802]
===
match
---
name: logging [4561,4568]
name: logging [4561,4568]
===
match
---
name: plugin_views [1579,1591]
name: plugin_views [1579,1591]
===
match
---
string: "test.plugins.test_plugins_manager" [8911,8946]
string: "test.plugins.test_plugins_manager" [8938,8973]
===
match
---
name: caplog [4803,4809]
name: caplog [4830,4836]
===
match
---
operator: = [6379,6380]
operator: = [6406,6407]
===
match
---
name: childs [2217,2223]
name: childs [2217,2223]
===
match
---
name: MagicMock [7312,7321]
name: MagicMock [7339,7348]
===
match
---
name: len [3316,3319]
name: len [3316,3319]
===
match
---
suite [3009,3555]
suite [3009,3555]
===
match
---
name: name [8097,8101]
name: name [8124,8128]
===
match
---
arith_expr [12095,12151]
arith_expr [12122,12178]
===
match
---
trailer [3222,3227]
trailer [3222,3227]
===
match
---
funcdef [4930,6184]
funcdef [4957,6211]
===
match
---
atom_expr [3901,3932]
atom_expr [3901,3932]
===
match
---
simple_stmt [10301,10379]
simple_stmt [10328,10406]
===
match
---
name: plugins_manager [11962,11977]
name: plugins_manager [11989,12004]
===
match
---
name: blueprints [3766,3776]
name: blueprints [3766,3776]
===
match
---
operator: == [4881,4883]
operator: == [4908,4910]
===
match
---
name: self [1308,1312]
name: self [1308,1312]
===
match
---
name: mock [7159,7163]
name: mock [7186,7190]
===
match
---
name: AirflowAdminMenuLinksPlugin [6415,6442]
name: AirflowAdminMenuLinksPlugin [6442,6469]
===
match
---
operator: , [5684,5685]
operator: , [5711,5712]
===
match
---
suite [1243,1375]
suite [1243,1375]
===
match
---
fstring [8400,8437]
fstring [8427,8464]
===
match
---
suite [1222,3808]
suite [1222,3808]
===
match
---
expr_stmt [5108,5140]
expr_stmt [5135,5167]
===
match
---
import_from [9178,9204]
import_from [9205,9231]
===
match
---
name: import_errors [7962,7975]
name: import_errors [7989,8002]
===
match
---
name: logging [6700,6707]
name: logging [6727,6734]
===
match
---
trailer [8393,8399]
trailer [8420,8426]
===
match
---
operator: = [5453,5454]
operator: = [5480,5481]
===
match
---
operator: = [9998,9999]
operator: = [10025,10026]
===
match
---
assert_stmt [6866,6899]
assert_stmt [6893,6926]
===
match
---
simple_stmt [2205,2264]
simple_stmt [2205,2264]
===
match
---
name: appbuilder_class_name [2514,2535]
name: appbuilder_class_name [2514,2535]
===
match
---
simple_stmt [7337,7380]
simple_stmt [7364,7407]
===
match
---
name: plugins_manager [5514,5529]
name: plugins_manager [5541,5556]
===
match
---
name: initialize_web_ui_plugins [5559,5584]
name: initialize_web_ui_plugins [5586,5611]
===
match
---
trailer [3431,3434]
trailer [3431,3434]
===
match
---
arith_expr [12182,12247]
arith_expr [12209,12274]
===
match
---
atom_expr [12251,12268]
atom_expr [12278,12295]
===
match
---
expr_stmt [5212,5243]
expr_stmt [5239,5270]
===
match
---
assert_stmt [3500,3554]
assert_stmt [3500,3554]
===
match
---
name: baseviews [1641,1650]
name: baseviews [1641,1650]
===
match
---
trailer [11332,11334]
trailer [11359,11361]
===
match
---
atom_expr [7307,7323]
atom_expr [7334,7350]
===
match
---
name: airflow [9183,9190]
name: airflow [9210,9217]
===
match
---
operator: = [11491,11492]
operator: = [11518,11519]
===
match
---
atom [11876,11887]
atom [11903,11914]
===
match
---
name: __html__ [12258,12266]
name: __html__ [12285,12293]
===
match
---
trailer [8998,9000]
trailer [9025,9027]
===
match
---
simple_stmt [11569,11615]
simple_stmt [11596,11642]
===
match
---
name: test_flaskappbuilder_views [1384,1410]
name: test_flaskappbuilder_views [1384,1410]
===
match
---
operator: == [4832,4834]
operator: == [4859,4861]
===
match
---
atom_expr [4858,4880]
atom_expr [4885,4907]
===
match
---
name: BaseHook [904,912]
name: BaseHook [904,912]
===
match
---
comparison [2017,2032]
comparison [2017,2032]
===
match
---
simple_stmt [4361,4366]
simple_stmt [4361,4366]
===
match
---
name: version_info [1080,1092]
name: version_info [1080,1092]
===
match
---
trailer [11917,11941]
trailer [11944,11968]
===
match
---
trailer [2184,2196]
trailer [2184,2196]
===
match
---
argument [3921,3931]
argument [3921,3931]
===
match
---
name: appbuilder [1335,1345]
name: appbuilder [1335,1345]
===
match
---
string: "$PLUGINS_FOLDER/test_plugins_manager.py" [11191,11232]
string: "$PLUGINS_FOLDER/test_plugins_manager.py" [11218,11259]
===
match
---
name: set_level [4551,4560]
name: set_level [4551,4560]
===
match
---
operator: = [3147,3148]
operator: = [3147,3148]
===
match
---
operator: , [7786,7787]
operator: , [7813,7814]
===
match
---
simple_stmt [11062,11120]
simple_stmt [11089,11147]
===
match
---
name: mock [867,871]
name: mock [867,871]
===
match
---
comparison [4858,4924]
comparison [4885,4951]
===
match
---
param [4987,4993]
param [5014,5020]
===
match
---
name: base [892,896]
name: base [892,896]
===
match
---
name: records [4865,4872]
name: records [4892,4899]
===
match
---
name: childs [3512,3518]
name: childs [3512,3518]
===
match
---
atom_expr [5303,5412]
atom_expr [5330,5439]
===
match
---
expr_stmt [6471,6502]
expr_stmt [6498,6529]
===
match
---
atom_expr [11720,11737]
atom_expr [11747,11764]
===
match
---
arglist [11995,12021]
arglist [12022,12048]
===
match
---
name: unittest [1203,1211]
name: unittest [1203,1211]
===
match
---
operator: = [11779,11780]
operator: = [11806,11807]
===
match
---
name: levelname [4822,4831]
name: levelname [4849,4858]
===
match
---
operator: == [11233,11235]
operator: == [11260,11262]
===
match
---
name: custom_macro [10037,10049]
name: custom_macro [10064,10076]
===
match
---
name: plugins [2632,2639]
name: plugins [2632,2639]
===
match
---
operator: } [11845,11846]
operator: } [11872,11873]
===
match
---
trailer [8341,8354]
trailer [8368,8381]
===
match
---
comparison [1076,1102]
comparison [1076,1102]
===
match
---
name: macros [10876,10882]
name: macros [10903,10909]
===
match
---
name: str [12131,12134]
name: str [12158,12161]
===
match
---
del_stmt [9750,9783]
del_stmt [9777,9810]
===
match
---
name: mock_plugin_manager [2612,2631]
name: mock_plugin_manager [2612,2631]
===
match
---
simple_stmt [6362,6400]
simple_stmt [6389,6427]
===
match
---
atom [5344,5402]
atom [5371,5429]
===
match
---
atom [6381,6399]
atom [6408,6426]
===
match
---
name: self [2307,2311]
name: self [2307,2311]
===
match
---
argument [2719,2731]
argument [2719,2731]
===
match
---
name: plugins_manager [4683,4698]
name: plugins_manager [4710,4725]
===
match
---
name: airflow [11022,11029]
name: airflow [11049,11056]
===
match
---
trailer [10587,10618]
trailer [10614,10645]
===
match
---
name: name [3803,3807]
name: name [3803,3807]
===
match
---
name: record_tuples [5610,5623]
name: record_tuples [5637,5650]
===
match
---
atom_expr [5702,5717]
atom_expr [5729,5744]
===
match
---
name: AirflowAdminViewsPlugin [6615,6638]
name: AirflowAdminViewsPlugin [6642,6665]
===
match
---
parameters [1236,1242]
parameters [1236,1242]
===
match
---
suite [2670,2962]
suite [2670,2962]
===
match
---
atom [3929,3931]
atom [3929,3931]
===
match
---
name: caplog [5414,5420]
name: caplog [5441,5447]
===
match
---
trailer [8481,8552]
trailer [8508,8579]
===
match
---
simple_stmt [11513,11561]
simple_stmt [11540,11588]
===
match
---
operator: , [5412,5413]
operator: , [5439,5440]
===
match
---
trailer [2846,2856]
trailer [2846,2856]
===
match
---
operator: = [2125,2126]
operator: = [2125,2126]
===
match
---
name: plugins_manager [4588,4603]
name: plugins_manager [4615,4630]
===
match
---
trailer [1728,1742]
trailer [1728,1742]
===
match
---
name: caplog [5603,5609]
name: caplog [5630,5636]
===
match
---
parameters [2306,2312]
parameters [2306,2312]
===
match
---
atom [5270,5288]
atom [5297,5315]
===
match
---
name: mock [8389,8393]
name: mock [8416,8420]
===
match
---
string: "my_fake_module not found" [8769,8795]
string: "my_fake_module not found" [8796,8822]
===
match
---
expr_stmt [7293,7324]
expr_stmt [7320,7351]
===
match
---
trailer [1640,1650]
trailer [1640,1650]
===
match
---
trailer [7113,7123]
trailer [7140,7150]
===
match
---
import_from [9213,9273]
import_from [9240,9300]
===
match
---
number: 1 [4874,4875]
number: 1 [4901,4902]
===
match
---
atom_expr [8284,8323]
atom_expr [8311,8350]
===
match
---
trailer [4625,4627]
trailer [4652,4654]
===
match
---
name: plugins [6606,6613]
name: plugins [6633,6640]
===
match
---
operator: == [2232,2234]
operator: == [2232,2234]
===
match
---
name: appbuilder [3207,3217]
name: appbuilder [3207,3217]
===
match
---
name: plugins_manager [7634,7649]
name: plugins_manager [7661,7676]
===
match
---
operator: = [5067,5068]
operator: = [5094,5095]
===
match
---
name: blueprint [2865,2874]
name: blueprint [2865,2874]
===
match
---
trailer [3518,3521]
trailer [3518,3521]
===
match
---
name: appbuilder_mitem [3530,3546]
name: appbuilder_mitem [3530,3546]
===
match
---
testlist_comp [7436,7492]
testlist_comp [7463,7519]
===
match
---
trailer [5285,5287]
trailer [5312,5314]
===
match
---
name: importlib_metadata [11827,11845]
name: importlib_metadata [11854,11872]
===
match
---
trailer [2631,2669]
trailer [2631,2669]
===
match
---
dotted_name [1431,1456]
dotted_name [1431,1456]
===
match
---
assert_stmt [3698,3741]
assert_stmt [3698,3741]
===
match
---
trailer [11977,11994]
trailer [12004,12021]
===
match
---
simple_stmt [12088,12167]
simple_stmt [12115,12194]
===
match
---
name: plugins_manager [6784,6799]
name: plugins_manager [6811,6826]
===
match
---
name: mock [11636,11640]
name: mock [11663,11667]
===
match
---
name: mock_entrypoint [8081,8096]
name: mock_entrypoint [8108,8123]
===
match
---
name: v_appbuilder_package [2164,2184]
name: v_appbuilder_package [2164,2184]
===
match
---
name: logger [7538,7544]
name: logger [7565,7571]
===
match
---
name: application [2696,2707]
name: application [2696,2707]
===
match
---
atom_expr [7694,7714]
atom_expr [7721,7741]
===
match
---
name: links [2127,2132]
name: links [2127,2132]
===
match
---
atom_expr [10404,10422]
atom_expr [10431,10449]
===
match
---
atom_expr [5414,5480]
atom_expr [5441,5507]
===
match
---
name: self [1326,1330]
name: self [1326,1330]
===
match
---
name: metadata [11666,11674]
name: metadata [11693,11701]
===
match
---
trailer [8195,8202]
trailer [8222,8229]
===
match
---
name: mock_entrypoint [8180,8195]
name: mock_entrypoint [8207,8222]
===
match
---
trailer [3776,3791]
trailer [3776,3791]
===
match
---
trailer [4821,4831]
trailer [4848,4858]
===
match
---
comparison [4648,4707]
comparison [4675,4734]
===
match
---
import_from [6764,6799]
import_from [6791,6826]
===
match
---
string: 'airflow.plugins_manager' [5454,5479]
string: 'airflow.plugins_manager' [5481,5506]
===
match
---
name: hooks [886,891]
name: hooks [886,891]
===
match
---
name: importlib [10317,10326]
name: importlib [10344,10353]
===
match
---
name: links [3141,3146]
name: links [3141,3146]
===
match
---
atom_expr [2017,2027]
atom_expr [2017,2027]
===
match
---
name: airflow [5499,5506]
name: airflow [5526,5533]
===
match
---
testlist_comp [6615,6671]
testlist_comp [6642,6698]
===
match
---
name: mock_entrypoint [11782,11797]
name: mock_entrypoint [11809,11824]
===
match
---
trailer [2132,2135]
trailer [2132,2135]
===
match
---
operator: = [11069,11070]
operator: = [11096,11097]
===
match
---
name: received_logs [8736,8749]
name: received_logs [8763,8776]
===
match
---
import_from [3599,3639]
import_from [3599,3639]
===
match
---
trailer [1949,1954]
trailer [1949,1954]
===
match
---
atom_expr [8979,9000]
atom_expr [9006,9027]
===
match
---
operator: = [11592,11593]
operator: = [11619,11620]
===
match
---
sync_comp_for [1613,1698]
sync_comp_for [1613,1698]
===
match
---
name: self [1237,1241]
name: self [1237,1241]
===
match
---
name: import_module [10327,10340]
name: import_module [10354,10367]
===
match
---
operator: = [7053,7054]
operator: = [7080,7081]
===
match
---
suite [3835,10902]
suite [3835,10929]
===
match
---
trailer [12041,12058]
trailer [12068,12085]
===
match
---
funcdef [4274,4409]
funcdef [4274,4409]
===
match
---
simple_stmt [2144,2197]
simple_stmt [2144,2197]
===
match
---
param [6241,6247]
param [6268,6274]
===
match
---
factor [4873,4875]
factor [4900,4902]
===
match
---
atom_expr [7521,7536]
atom_expr [7548,7563]
===
match
---
operator: = [5268,5269]
operator: = [5295,5296]
===
match
---
trailer [1903,1914]
trailer [1903,1914]
===
match
---
import_from [3018,3072]
import_from [3018,3072]
===
match
---
name: Mock [8027,8031]
name: Mock [8054,8058]
===
match
---
decorator [4252,4262]
decorator [4252,4262]
===
match
---
operator: , [5957,5958]
operator: , [5984,5985]
===
match
---
name: view [2860,2864]
name: view [2860,2864]
===
match
---
name: tests [1011,1016]
name: tests [1011,1016]
===
match
---
suite [3886,4078]
suite [3886,4078]
===
match
---
funcdef [2269,2962]
funcdef [2269,2962]
===
match
---
expr_stmt [11475,11504]
expr_stmt [11502,11531]
===
match
---
trailer [2732,2743]
trailer [2732,2743]
===
match
---
name: mock [11813,11817]
name: mock [11840,11844]
===
match
---
simple_stmt [2322,2388]
simple_stmt [2322,2388]
===
match
---
name: EntryPointSource [11978,11994]
name: EntryPointSource [12005,12021]
===
match
---
string: 'my_fake_module not found' [8296,8322]
string: 'my_fake_module not found' [8323,8349]
===
match
---
string: "Please contact the author of the plugin." [6115,6157]
string: "Please contact the author of the plugin." [6142,6184]
===
match
---
argument [6606,6672]
argument [6633,6699]
===
match
---
number: 9 [1100,1101]
number: 9 [1100,1101]
===
match
---
name: MagicMock [5276,5285]
name: MagicMock [5303,5312]
===
match
---
suite [4482,4787]
suite [4482,4814]
===
match
---
atom_expr [8022,8033]
atom_expr [8049,8060]
===
match
---
name: records [4810,4817]
name: records [4837,4844]
===
match
---
name: caplog [6873,6879]
name: caplog [6900,6906]
===
match
---
atom_expr [11071,11119]
atom_expr [11098,11146]
===
match
---
atom [1096,1102]
atom [1096,1102]
===
match
---
name: source [11164,11170]
name: source [11191,11197]
===
match
---
fstring_expr [11826,11846]
fstring_expr [11853,11873]
===
match
---
simple_stmt [4495,4531]
simple_stmt [4495,4531]
===
match
---
name: ensure_plugins_loaded [4604,4625]
name: ensure_plugins_loaded [4631,4652]
===
match
---
operator: , [1098,1099]
operator: , [1098,1099]
===
match
---
simple_stmt [8180,8241]
simple_stmt [8207,8268]
===
match
---
import_name [819,829]
import_name [819,829]
===
match
---
funcdef [6189,6900]
funcdef [6216,6927]
===
match
---
trailer [1658,1668]
trailer [1658,1668]
===
match
---
string: """Reloads the airflow.macros module such that the symbol table is reset after the test.""" [9317,9408]
string: """Reloads the airflow.macros module such that the symbol table is reset after the test.""" [9344,9435]
===
match
---
name: appbuilder [2836,2846]
name: appbuilder [2836,2846]
===
match
---
operator: , [6640,6641]
operator: , [6667,6668]
===
match
---
assert_stmt [2144,2196]
assert_stmt [2144,2196]
===
match
---
name: link [2151,2155]
name: link [2151,2155]
===
match
---
operator: = [8152,8153]
operator: = [8179,8180]
===
match
---
trailer [11640,11645]
trailer [11667,11672]
===
match
---
name: TestPluginsManager [3816,3834]
name: TestPluginsManager [3816,3834]
===
match
---
testlist_comp [5641,6173]
testlist_comp [5668,6200]
===
match
---
name: v_appbuilder_package [1522,1542]
name: v_appbuilder_package [1522,1542]
===
match
---
atom_expr [1625,1650]
atom_expr [1625,1650]
===
match
---
name: mock_dist [11756,11765]
name: mock_dist [11783,11792]
===
match
---
parameters [9040,9055]
parameters [9067,9082]
===
match
---
simple_stmt [9317,9409]
simple_stmt [9344,9436]
===
match
---
name: name [3792,3796]
name: name [3792,3796]
===
match
---
trailer [9757,9765]
trailer [9784,9792]
===
match
---
comp_if [2857,2904]
comp_if [2857,2904]
===
match
---
atom_expr [3316,3326]
atom_expr [3316,3326]
===
match
---
parameters [9909,9911]
parameters [9936,9938]
===
match
---
simple_stmt [8043,8073]
simple_stmt [8070,8100]
===
match
---
name: property [4253,4261]
name: property [4253,4261]
===
match
---
name: tests [1431,1436]
name: tests [1431,1436]
===
match
---
atom_expr [12155,12166]
atom_expr [12182,12193]
===
match
---
operator: } [10375,10376]
operator: } [10402,10403]
===
match
---
name: items [8993,8998]
name: items [9020,9025]
===
match
---
atom [8452,8463]
atom [8479,8490]
===
match
---
simple_stmt [11256,11335]
simple_stmt [11283,11362]
===
match
---
simple_stmt [8249,8324]
simple_stmt [8276,8351]
===
match
---
trailer [4032,4034]
trailer [4032,4034]
===
match
---
name: appbuilder_class_name [1494,1515]
name: appbuilder_class_name [1494,1515]
===
match
---
operator: = [8203,8204]
operator: = [8230,8231]
===
match
---
name: received_logs [8799,8812]
name: received_logs [8826,8839]
===
match
---
name: AirflowPlugin [5184,5197]
name: AirflowPlugin [5211,5224]
===
match
---
expr_stmt [9993,10014]
expr_stmt [10020,10041]
===
match
---
name: v_nomenu_appbuilder_package [2360,2387]
name: v_nomenu_appbuilder_package [2360,2387]
===
match
---
operator: = [11875,11876]
operator: = [11902,11903]
===
match
---
name: MacroPlugin [10094,10105]
name: MacroPlugin [10121,10132]
===
match
---
operator: , [8508,8509]
operator: , [8535,8536]
===
match
---
name: at_level [6691,6699]
name: at_level [6718,6726]
===
match
---
trailer [2223,2226]
trailer [2223,2226]
===
match
---
trailer [4560,4575]
trailer [4560,4602]
===
match
---
atom_expr [4749,4786]
atom_expr [4776,4813]
===
match
---
operator: , [10601,10602]
operator: , [10628,10629]
===
match
---
suite [3933,4035]
suite [3933,4035]
===
match
---
name: plugins_manager [926,941]
name: plugins_manager [926,941]
===
match
---
string: 'test_plugin' [3777,3790]
string: 'test_plugin' [3777,3790]
===
match
---
comparison [2860,2904]
comparison [2860,2904]
===
match
---
simple_stmt [7687,7721]
simple_stmt [7714,7748]
===
match
---
param [3584,3588]
param [3584,3588]
===
match
---
name: mock_plugin_manager [1048,1067]
name: mock_plugin_manager [1048,1067]
===
match
---
atom [6540,6558]
atom [6567,6585]
===
match
---
name: menu_item [1886,1895]
name: menu_item [1886,1895]
===
match
---
operator: == [5624,5626]
operator: == [5651,5653]
===
match
---
atom_expr [2164,2196]
atom_expr [2164,2196]
===
match
---
name: hasattr [10580,10587]
name: hasattr [10607,10614]
===
match
---
name: MacroPlugin [10884,10895]
name: MacroPlugin [10911,10922]
===
match
---
operator: , [7536,7537]
operator: , [7563,7564]
===
match
---
name: airflow [3951,3958]
name: airflow [3951,3958]
===
match
---
name: appbuilder_mitem [3261,3277]
name: appbuilder_mitem [3261,3277]
===
match
---
trailer [3252,3257]
trailer [3252,3257]
===
match
---
simple_stmt [11902,11944]
simple_stmt [11929,11971]
===
match
---
name: appbuilder_class_name [2883,2904]
name: appbuilder_class_name [2883,2904]
===
match
---
trailer [3479,3491]
trailer [3479,3491]
===
match
---
trailer [3454,3459]
trailer [3454,3459]
===
match
---
operator: = [11534,11535]
operator: = [11561,11562]
===
match
---
name: cleanup_macros [9287,9301]
name: cleanup_macros [9314,9328]
===
match
---
number: 1 [2960,2961]
number: 1 [2960,2961]
===
match
---
operator: + [12129,12130]
operator: + [12156,12157]
===
match
---
simple_stmt [11624,11648]
simple_stmt [11651,11675]
===
match
---
atom_expr [4588,4627]
atom_expr [4615,4654]
===
match
---
name: name [5212,5216]
name: name [5239,5243]
===
match
---
expr_stmt [2514,2597]
expr_stmt [2514,2597]
===
match
---
trailer [7366,7376]
trailer [7393,7403]
===
match
---
name: blueprints [3731,3741]
name: blueprints [3731,3741]
===
match
---
operator: { [11826,11827]
operator: { [11853,11854]
===
match
---
name: str [2538,2541]
name: str [2538,2541]
===
match
---
name: view [2828,2832]
name: view [2828,2832]
===
match
---
name: mock_entrypoint [8043,8058]
name: mock_entrypoint [8070,8085]
===
match
---
name: mock_entrypoint [12231,12246]
name: mock_entrypoint [12258,12273]
===
match
---
name: test_flaskappbuilder_nomenu_views [2273,2306]
name: test_flaskappbuilder_nomenu_views [2273,2306]
===
match
---
atom_expr [11756,11778]
atom_expr [11783,11805]
===
match
---
name: TestEntryPointSource [11343,11363]
name: TestEntryPointSource [11370,11390]
===
match
---
comparison [8769,8812]
comparison [8796,8839]
===
match
---
name: test_plugin [1445,1456]
name: test_plugin [1445,1456]
===
match
---
string: 'test_plugin' [3705,3718]
string: 'test_plugin' [3705,3718]
===
match
---
with_stmt [4418,4787]
with_stmt [4418,4814]
===
match
---
atom [5641,5900]
atom [5668,5927]
===
match
---
funcdef [11369,12269]
funcdef [11396,12296]
===
match
---
operator: = [5217,5218]
operator: = [5244,5245]
===
match
---
atom_expr [11636,11647]
atom_expr [11663,11674]
===
match
---
string: 'DEBUG' [4835,4842]
string: 'DEBUG' [4862,4869]
===
match
---
classdef [4307,4366]
classdef [4307,4366]
===
match
---
classdef [1181,3808]
classdef [1181,3808]
===
match
---
name: appbuilder [1904,1914]
name: appbuilder [1904,1914]
===
match
---
param [4284,4288]
param [4284,4288]
===
match
---
atom_expr [1308,1323]
atom_expr [1308,1323]
===
match
---
name: AirflowPlugin [7020,7033]
name: AirflowPlugin [7047,7060]
===
match
---
suite [7035,7177]
suite [7062,7204]
===
match
---
name: app [3762,3765]
name: app [3762,3765]
===
match
---
simple_stmt [11656,11712]
simple_stmt [11683,11739]
===
match
---
trailer [1978,1990]
trailer [1978,1990]
===
match
---
name: caplog [4132,4138]
name: caplog [4132,4138]
===
match
---
atom_expr [2641,2667]
atom_expr [2641,2667]
===
match
---
fstring_string: .distributions [11846,11860]
fstring_string: .distributions [11873,11887]
===
match
---
name: plugins_manager [7605,7620]
name: plugins_manager [7632,7647]
===
match
---
trailer [5368,5370]
trailer [5395,5397]
===
match
---
suite [5199,5289]
suite [5226,5316]
===
match
---
import_from [5494,5529]
import_from [5521,5556]
===
match
---
string: 'importlib_metadata' [1158,1178]
string: 'importlib_metadata' [1158,1178]
===
match
---
name: plugins [10085,10092]
name: plugins [10112,10119]
===
match
---
name: mock [7307,7311]
name: mock [7334,7338]
===
match
---
simple_stmt [1838,2001]
simple_stmt [1838,2001]
===
match
---
atom_expr [4561,4574]
atom_expr [4561,4574]
===
match
---
simple_stmt [11128,11176]
simple_stmt [11155,11203]
===
match
---
name: mock [11493,11497]
name: mock [11520,11524]
===
match
---
suite [7235,7380]
suite [7262,7407]
===
match
---
trailer [4768,4785]
trailer [4795,4812]
===
match
---
suite [3590,3808]
suite [3590,3808]
===
match
---
trailer [7376,7378]
trailer [7403,7405]
===
match
---
trailer [3206,3217]
trailer [3206,3217]
===
match
---
simple_stmt [3309,3332]
simple_stmt [3309,3332]
===
match
---
decorated [4252,4409]
decorated [4252,4409]
===
match
---
operator: + [12225,12226]
operator: + [12252,12253]
===
match
---
operator: , [6682,6683]
operator: , [6709,6710]
===
match
---
suite [6981,7721]
suite [7008,7748]
===
match
---
param [6235,6240]
param [6262,6267]
===
match
---
simple_stmt [787,804]
simple_stmt [787,804]
===
match
---
simple_stmt [4641,4708]
simple_stmt [4668,4735]
===
match
---
comp_if [1651,1698]
comp_if [1651,1698]
===
match
---
trailer [10084,10109]
trailer [10111,10136]
===
match
---
name: plugins_manager [11071,11086]
name: plugins_manager [11098,11113]
===
match
---
suite [10110,10902]
suite [10137,10929]
===
match
---
name: menu [1920,1924]
name: menu [1920,1924]
===
match
---
name: unittest [10937,10945]
name: unittest [10964,10972]
===
match
---
trailer [11941,11943]
trailer [11968,11970]
===
match
---
trailer [4682,4707]
trailer [4709,4734]
===
match
---
simple_stmt [4383,4409]
simple_stmt [4383,4409]
===
match
---
trailer [12257,12266]
trailer [12284,12293]
===
match
---
assert_stmt [5596,6183]
assert_stmt [5623,6210]
===
match
---
arglist [10588,10617]
arglist [10615,10644]
===
match
---
trailer [5127,5137]
trailer [5154,5164]
===
match
---
name: appbuilder_mitem [3463,3479]
name: appbuilder_mitem [3463,3479]
===
match
---
fstring_start: f' [11824,11826]
fstring_start: f' [11851,11853]
===
match
---
name: module [8196,8202]
name: module [8223,8229]
===
match
---
import_from [7926,8000]
import_from [7953,8027]
===
match
---
expr_stmt [8130,8171]
expr_stmt [8157,8198]
===
match
---
atom_expr [1076,1092]
atom_expr [1076,1092]
===
match
---
atom_expr [10359,10375]
atom_expr [10386,10402]
===
match
---
classdef [6409,6559]
classdef [6436,6586]
===
match
---
argument [1286,1298]
argument [1286,1298]
===
match
---
name: test_app_blueprints [3564,3583]
name: test_app_blueprints [3564,3583]
===
match
---
string: '1.0.0' [11740,11747]
string: '1.0.0' [11767,11774]
===
match
---
name: name [6316,6320]
name: name [6343,6347]
===
match
---
name: mock [7109,7113]
name: mock [7136,7140]
===
match
---
name: AirflowAdminViewsPlugin [7436,7459]
name: AirflowAdminViewsPlugin [7463,7486]
===
match
---
name: view [1608,1612]
name: view [1608,1612]
===
match
---
atom_expr [1326,1345]
atom_expr [1326,1345]
===
match
---
assert_stmt [3750,3807]
assert_stmt [3750,3807]
===
match
---
name: logger [8510,8516]
name: logger [8537,8543]
===
match
---
trailer [3920,3932]
trailer [3920,3932]
===
match
---
operator: , [7461,7462]
operator: , [7488,7489]
===
match
---
expr_stmt [11569,11614]
expr_stmt [11596,11641]
===
match
---
with_stmt [5298,5587]
with_stmt [5325,5614]
===
match
---
name: logging [5702,5709]
name: logging [5729,5736]
===
match
---
trailer [6707,6715]
trailer [6734,6742]
===
match
---
suite [9980,10051]
suite [10007,10078]
===
match
---
simple_stmt [8081,8122]
simple_stmt [8108,8149]
===
match
---
trailer [2569,2577]
trailer [2569,2577]
===
match
---
import_as_name [987,1005]
import_as_name [987,1005]
===
match
---
atom_expr [8061,8072]
atom_expr [8088,8099]
===
match
---
trailer [1079,1092]
trailer [1079,1092]
===
match
---
simple_stmt [9750,9784]
simple_stmt [9777,9811]
===
match
---
trailer [2541,2597]
trailer [2541,2597]
===
match
---
atom_expr [11656,11674]
atom_expr [11683,11701]
===
match
---
name: airflow [7931,7938]
name: airflow [7958,7965]
===
match
---
operator: = [10092,10093]
operator: = [10119,10120]
===
match
---
trailer [10326,10340]
trailer [10353,10367]
===
match
---
trailer [3726,3730]
trailer [3726,3730]
===
match
---
argument [10085,10108]
argument [10112,10135]
===
match
---
name: mock [5271,5275]
name: mock [5298,5302]
===
match
---
comparison [3507,3554]
comparison [3507,3554]
===
match
---
name: application [994,1005]
name: application [994,1005]
===
match
---
atom_expr [11493,11504]
atom_expr [11520,11531]
===
match
---
atom_expr [8566,8591]
atom_expr [8593,8618]
===
match
---
operator: == [1674,1676]
operator: == [1674,1676]
===
match
---
atom_expr [4753,4785]
atom_expr [4780,4812]
===
match
---
name: logger [6717,6723]
name: logger [6744,6750]
===
match
---
arglist [7521,7570]
arglist [7548,7597]
===
match
---
operator: >= [1093,1095]
operator: >= [1093,1095]
===
match
---
name: AirflowAdminMenuLinksPlugin [7192,7219]
name: AirflowAdminMenuLinksPlugin [7219,7246]
===
match
---
name: mock_plugin_manager [5303,5322]
name: mock_plugin_manager [5330,5349]
===
match
---
atom_expr [5271,5287]
atom_expr [5298,5314]
===
match
---
name: plugins_manager [11450,11465]
name: plugins_manager [11477,11492]
===
match
---
comparison [3705,3741]
comparison [3705,3741]
===
match
---
simple_stmt [8332,8375]
simple_stmt [8359,8402]
===
match
---
trailer [4568,4574]
trailer [4568,4574]
===
match
---
name: __name__ [10609,10617]
name: __name__ [10636,10644]
===
match
---
trailer [2718,2732]
trailer [2718,2732]
===
match
---
name: source [11317,11323]
name: source [11344,11350]
===
match
---
trailer [8627,8632]
trailer [8654,8659]
===
match
---
name: macros [10416,10422]
name: macros [10443,10449]
===
match
---
import_from [913,962]
import_from [913,962]
===
match
---
expr_stmt [8332,8374]
expr_stmt [8359,8401]
===
match
---
suite [2443,2505]
suite [2443,2505]
===
match
---
simple_stmt [4044,4078]
simple_stmt [4044,4078]
===
match
---
name: links [2021,2026]
name: links [2021,2026]
===
match
---
name: at_level [8473,8481]
name: at_level [8500,8508]
===
match
---
trailer [2864,2874]
trailer [2864,2874]
===
match
---
name: self [1625,1629]
name: self [1625,1629]
===
match
---
atom_expr [3995,4034]
atom_expr [3995,4034]
===
match
---
name: name [9993,9997]
name: name [10020,10024]
===
match
---
simple_stmt [2010,2033]
simple_stmt [2010,2033]
===
match
---
trailer [8992,8998]
trailer [9019,9025]
===
match
---
operator: = [7106,7107]
operator: = [7133,7134]
===
match
---
comp_if [3240,3289]
comp_if [3240,3289]
===
match
---
simple_stmt [2786,2919]
simple_stmt [2786,2919]
===
match
---
param [3003,3007]
param [3003,3007]
===
match
---
trailer [6879,6893]
trailer [6906,6920]
===
match
---
name: name [10371,10375]
name: name [10398,10402]
===
match
---
string: "airflow.plugins_manager" [5932,5957]
string: "airflow.plugins_manager" [5959,5984]
===
match
---
operator: , [6971,6972]
operator: , [6998,6999]
===
match
---
atom_expr [7436,7461]
atom_expr [7463,7488]
===
match
---
trailer [7321,7323]
trailer [7348,7350]
===
match
---
atom_expr [7463,7492]
atom_expr [7490,7519]
===
match
---
simple_stmt [4588,4628]
simple_stmt [4615,4655]
===
match
---
name: appbuilder [2683,2693]
name: appbuilder [2683,2693]
===
match
---
suite [11008,11335]
suite [11035,11362]
===
match
---
simple_stmt [11430,11466]
simple_stmt [11457,11493]
===
match
---
trailer [4817,4821]
trailer [4844,4848]
===
match
---
classdef [4149,4409]
classdef [4149,4409]
===
match
---
name: admin_views [7094,7105]
name: admin_views [7121,7132]
===
match
---
name: source [12159,12165]
name: source [12186,12192]
===
match
---
name: appbuilder [1630,1640]
name: appbuilder [1630,1640]
===
match
---
trailer [1668,1673]
trailer [1668,1673]
===
match
---
name: mock_entrypoint [8249,8264]
name: mock_entrypoint [8276,8291]
===
match
---
name: mock_dist [11877,11886]
name: mock_dist [11904,11913]
===
match
---
trailer [11765,11778]
trailer [11792,11805]
===
match
---
atom [7108,7126]
atom [7135,7153]
===
match
---
parameters [6234,6248]
parameters [6261,6275]
===
match
---
suite [10423,10619]
suite [10450,10646]
===
match
---
name: v_appbuilder_package [1958,1978]
name: v_appbuilder_package [1958,1978]
===
match
---
simple_stmt [1069,1103]
simple_stmt [1069,1103]
===
match
---
trailer [1560,1569]
trailer [1560,1569]
===
match
---
name: self [9041,9045]
name: self [9068,9072]
===
match
---
name: appbuilder [2733,2743]
name: appbuilder [2733,2743]
===
match
---
operator: , [9045,9046]
operator: , [9072,9073]
===
match
---
file_input [787,12269]
file_input [787,12296]
===
match
---
comparison [1940,1990]
comparison [1940,1990]
===
match
---
atom_expr [7109,7125]
atom_expr [7136,7152]
===
match
---
name: Mock [8066,8070]
name: Mock [8093,8097]
===
match
---
name: patch [11818,11823]
name: patch [11845,11850]
===
match
---
trailer [11994,12022]
trailer [12021,12049]
===
match
---
dotted_name [918,941]
dotted_name [918,941]
===
match
---
trailer [3546,3554]
trailer [3546,3554]
===
match
---
suite [9304,9838]
suite [9331,9865]
===
match
---
name: test_utils [1017,1027]
name: test_utils [1017,1027]
===
match
---
number: 0 [3432,3433]
number: 0 [3432,3433]
===
match
---
atom_expr [6813,6856]
atom_expr [6840,6883]
===
match
---
name: name [1950,1954]
name: name [1950,1954]
===
match
---
name: len [2017,2020]
name: len [2017,2020]
===
match
---
assert_stmt [2010,2032]
assert_stmt [2010,2032]
===
match
---
string: "test_menu_links_plugin" [7255,7279]
string: "test_menu_links_plugin" [7282,7306]
===
match
---
trailer [2226,2231]
trailer [2226,2231]
===
match
---
assert_stmt [4720,4786]
assert_stmt [4747,4813]
===
match
---
name: create_app [1275,1285]
name: create_app [1275,1285]
===
match
---
name: link [3507,3511]
name: link [3507,3511]
===
match
---
param [1237,1241]
param [1237,1241]
===
match
---
atom_expr [6873,6893]
atom_expr [6900,6920]
===
match
---
name: mock_dist [8332,8341]
name: mock_dist [8359,8368]
===
match
---
name: caplog [8466,8472]
name: caplog [8493,8499]
===
match
---
suite [8553,9001]
suite [8580,9028]
===
match
---
param [9041,9046]
param [9068,9073]
===
match
---
param [4981,4986]
param [5008,5013]
===
match
---
name: caplog [4858,4864]
name: caplog [4885,4891]
===
match
---
simple_stmt [963,1006]
simple_stmt [963,1006]
===
match
---
testlist_comp [5932,6158]
testlist_comp [5959,6185]
===
match
---
atom_expr [12062,12079]
atom_expr [12089,12106]
===
match
---
name: plugins_manager [6813,6828]
name: plugins_manager [6840,6855]
===
match
---
name: AirflowAdminViewsPlugin [6264,6287]
name: AirflowAdminViewsPlugin [6291,6314]
===
match
---
name: text [8628,8632]
name: text [8655,8659]
===
match
---
assert_stmt [4044,4077]
assert_stmt [4044,4077]
===
match
---
trailer [4752,4786]
trailer [4779,4813]
===
match
---
atom_expr [2212,2231]
atom_expr [2212,2231]
===
match
---
name: source [11953,11959]
name: source [11980,11986]
===
match
---
name: bp [3637,3639]
name: bp [3637,3639]
===
match
---
operator: = [3928,3929]
operator: = [3928,3929]
===
match
---
name: macros [10027,10033]
name: macros [10054,10060]
===
match
---
simple_stmt [3599,3640]
simple_stmt [3599,3640]
===
match
---
trailer [6638,6640]
trailer [6665,6667]
===
match
---
simple_stmt [10573,10619]
simple_stmt [10600,10646]
===
match
---
atom_expr [11813,11888]
atom_expr [11840,11915]
===
match
---
name: at_level [7512,7520]
name: at_level [7539,7547]
===
match
---
name: MagicMock [7164,7173]
name: MagicMock [7191,7200]
===
match
---
name: py39 [1148,1152]
name: py39 [1148,1152]
===
match
---
testlist_comp [3163,3289]
testlist_comp [3163,3289]
===
match
---
name: source [11240,11246]
name: source [11267,11273]
===
match
---
operator: = [2473,2474]
operator: = [2473,2474]
===
match
---
name: AirflowAdminViewsPlugin [5010,5033]
name: AirflowAdminViewsPlugin [5037,5060]
===
match
---
name: mock_plugin_manager [4423,4442]
name: mock_plugin_manager [4423,4442]
===
match
---
trailer [12158,12166]
trailer [12185,12193]
===
match
---
number: 1 [4819,4820]
number: 1 [4846,4847]
===
match
---
trailer [11528,11533]
trailer [11555,11560]
===
match
---
string: "Please contact the author of the plugin." [5843,5885]
string: "Please contact the author of the plugin." [5870,5912]
===
match
---
name: at_level [5421,5429]
name: at_level [5448,5456]
===
match
---
expr_stmt [4209,4238]
expr_stmt [4209,4238]
===
match
---
name: testing [1286,1293]
name: testing [1286,1293]
===
match
---
atom_expr [8389,8464]
atom_expr [8416,8491]
===
match
---
name: importlib [9796,9805]
name: importlib [9823,9832]
===
match
---
string: 'Loading %d plugin(s) took %.2f seconds' [4884,4924]
string: 'Loading %d plugin(s) took %.2f seconds' [4911,4951]
===
match
---
trailer [10340,10378]
trailer [10367,10405]
===
match
---
number: 0 [2133,2134]
number: 0 [2133,2134]
===
match
---
expr_stmt [2786,2918]
expr_stmt [2786,2918]
===
match
---
string: "<em>test-entrypoint-plugin==1.0.0:</em> " [12182,12224]
string: "<em>test-entrypoint-plugin==1.0.0:</em> " [12209,12251]
===
match
---
trailer [2577,2587]
trailer [2577,2587]
===
match
---
expr_stmt [8180,8240]
expr_stmt [8207,8267]
===
match
---
operator: == [3527,3529]
operator: == [3527,3529]
===
match
---
name: __html__ [11324,11332]
name: __html__ [11351,11359]
===
match
---
return_stmt [9925,9937]
return_stmt [9952,9964]
===
match
---
atom_expr [5543,5586]
atom_expr [5570,5613]
===
match
---
name: cleanup_macros [9868,9882]
name: cleanup_macros [9895,9909]
===
match
---
comparison [3243,3289]
comparison [3243,3289]
===
match
---
name: view [1654,1658]
name: view [1654,1658]
===
match
---
name: appbuilder_class_name [1677,1698]
name: appbuilder_class_name [1677,1698]
===
match
---
name: str [12227,12230]
name: str [12254,12257]
===
match
---
import_from [11017,11052]
import_from [11044,11079]
===
match
---
expr_stmt [8010,8033]
expr_stmt [8037,8060]
===
match
---
string: 'macro_plugin' [10000,10014]
string: 'macro_plugin' [10027,10041]
===
match
---
expr_stmt [7139,7176]
expr_stmt [7166,7203]
===
match
---
name: request [9047,9054]
name: request [9074,9081]
===
match
---
operator: == [11314,11316]
operator: == [11341,11343]
===
match
---
fstring_end: ' [11860,11861]
fstring_end: ' [11887,11888]
===
match
---
atom_expr [1725,1742]
atom_expr [1725,1742]
===
match
---
string: 'test-entrypoint' [8104,8121]
string: 'test-entrypoint' [8131,8148]
===
match
---
simple_stmt [5212,5244]
simple_stmt [5239,5271]
===
match
---
assert_stmt [11256,11334]
assert_stmt [11283,11361]
===
match
---
argument [6717,6749]
argument [6744,6776]
===
match
---
funcdef [3560,3808]
funcdef [3560,3808]
===
match
---
name: WARNING [7529,7536]
name: WARNING [7556,7563]
===
match
---
expr_stmt [8043,8072]
expr_stmt [8070,8099]
===
match
---
name: entry_points [8342,8354]
name: entry_points [8369,8381]
===
match
---
number: 1 [1746,1747]
number: 1 [1746,1747]
===
match
---
trailer [7173,7175]
trailer [7200,7202]
===
match
---
trailer [6690,6699]
trailer [6717,6726]
===
match
---
name: plugin_macros [10588,10601]
name: plugin_macros [10615,10628]
===
match
---
name: create_app [2708,2718]
name: create_app [2708,2718]
===
match
---
simple_stmt [830,846]
simple_stmt [830,846]
===
match
---
name: TestPluginsDirectorySource [10910,10936]
name: TestPluginsDirectorySource [10937,10963]
===
match
---
atom [4451,4480]
atom [4451,4480]
===
match
---
simple_stmt [12175,12269]
simple_stmt [12202,12296]
===
match
---
trailer [4872,4876]
trailer [4899,4903]
===
match
---
atom_expr [12227,12247]
atom_expr [12254,12274]
===
match
---
name: self [7782,7786]
name: self [7809,7813]
===
match
---
atom_expr [10603,10617]
atom_expr [10630,10644]
===
match
---
argument [8510,8542]
argument [8537,8569]
===
match
---
trailer [7123,7125]
trailer [7150,7152]
===
match
---
name: blueprint [1659,1668]
name: blueprint [1659,1668]
===
match
---
operator: = [11960,11961]
operator: = [11987,11988]
===
match
---
atom_expr [5372,5401]
atom_expr [5399,5428]
===
match
---
trailer [12134,12151]
trailer [12161,12178]
===
match
---
operator: == [1955,1957]
operator: == [1955,1957]
===
match
---
operator: = [1293,1294]
operator: = [1293,1294]
===
match
---
operator: == [2161,2163]
operator: == [2161,2163]
===
match
---
trailer [6699,6750]
trailer [6726,6777]
===
match
---
atom_expr [1522,1569]
atom_expr [1522,1569]
===
match
---
atom [1846,2000]
atom [1846,2000]
===
match
---
operator: == [3327,3329]
operator: == [3327,3329]
===
match
---
name: setUp [1231,1236]
name: setUp [1231,1236]
===
match
---
name: test_should_return_correct_path_name [10965,11001]
name: test_should_return_correct_path_name [10992,11028]
===
match
---
atom [5122,5140]
atom [5149,5167]
===
match
---
assert_stmt [12088,12166]
assert_stmt [12115,12193]
===
match
---
import_from [963,1005]
import_from [963,1005]
===
match
---
string: "Plugin 'test_menu_links_plugin' may not be compatible with the current Airflow version. " [6008,6098]
string: "Plugin 'test_menu_links_plugin' may not be compatible with the current Airflow version. " [6035,6125]
===
match
---
name: appbuilder [1313,1323]
name: appbuilder [1313,1323]
===
match
---
simple_stmt [8689,8750]
simple_stmt [8716,8777]
===
match
---
name: plugin_views [2943,2955]
name: plugin_views [2943,2955]
===
match
---
name: AirflowAdminViewsPlugin [6996,7019]
name: AirflowAdminViewsPlugin [7023,7046]
===
match
---
expr_stmt [1069,1102]
expr_stmt [1069,1102]
===
match
---
trailer [11170,11175]
trailer [11197,11202]
===
match
---
name: name [7048,7052]
name: name [7075,7079]
===
match
---
name: initialize_web_ui_plugins [7650,7675]
name: initialize_web_ui_plugins [7677,7702]
===
match
---
trailer [1629,1640]
trailer [1629,1640]
===
match
---
operator: = [8516,8517]
operator: = [8543,8544]
===
match
---
trailer [2255,2263]
trailer [2255,2263]
===
match
---
name: patch [8394,8399]
name: patch [8421,8426]
===
match
---
expr_stmt [7248,7279]
expr_stmt [7275,7306]
===
match
---
name: logging [5430,5437]
name: logging [5457,5464]
===
match
---
classdef [11337,12269]
classdef [11364,12296]
===
match
---
dotted_name [878,896]
dotted_name [878,896]
===
match
---
classdef [5150,5289]
classdef [5177,5316]
===
match
---
atom [6614,6672]
atom [6641,6699]
===
match
---
name: side_effect [8270,8281]
name: side_effect [8297,8308]
===
match
---
name: load_entrypoint_plugins [11918,11941]
name: load_entrypoint_plugins [11945,11968]
===
match
---
string: "test_menu_links_plugin" [6478,6502]
string: "test_menu_links_plugin" [6505,6529]
===
match
---
simple_stmt [7585,7621]
simple_stmt [7612,7648]
===
match
---
name: mock_entrypoint [11569,11584]
name: mock_entrypoint [11596,11611]
===
match
---
expr_stmt [2456,2504]
expr_stmt [2456,2504]
===
match
---
name: len [2939,2942]
name: len [2939,2942]
===
match
---
atom_expr [6642,6671]
atom_expr [6669,6698]
===
match
---
atom_expr [2860,2879]
atom_expr [2860,2879]
===
match
---
name: Mock [11498,11502]
name: Mock [11525,11529]
===
match
---
suite [4290,4409]
suite [4290,4409]
===
match
---
trailer [8070,8072]
trailer [8097,8099]
===
match
---
atom_expr [3261,3289]
atom_expr [3261,3289]
===
match
---
name: name [7248,7252]
name: name [7275,7279]
===
match
---
name: caplog [7694,7700]
name: caplog [7721,7727]
===
match
---
operator: , [4130,4131]
operator: , [4130,4131]
===
match
---
string: "test_admin_views_plugin" [5069,5094]
string: "test_admin_views_plugin" [5096,5121]
===
match
---
atom_expr [1940,1954]
atom_expr [1940,1954]
===
match
---
comparison [4803,4842]
comparison [4830,4869]
===
match
---
name: TestPropertyHook [4391,4407]
name: TestPropertyHook [4391,4407]
===
match
---
name: mock_plugin_manager [7394,7413]
name: mock_plugin_manager [7421,7440]
===
match
---
operator: == [12152,12154]
operator: == [12179,12181]
===
match
---
name: str [4679,4682]
name: str [4706,4709]
===
match
---
trailer [10895,10900]
trailer [10922,10927]
===
match
---
with_stmt [2607,2962]
with_stmt [2607,2962]
===
match
---
simple_stmt [9993,10015]
simple_stmt [10020,10042]
===
match
---
operator: = [5343,5344]
operator: = [5370,5371]
===
match
---
expr_stmt [8605,8632]
expr_stmt [8632,8659]
===
match
---
name: import_module [9806,9819]
name: import_module [9833,9846]
===
match
---
operator: , [5885,5886]
operator: , [5912,5913]
===
match
---
comparison [12038,12079]
comparison [12065,12106]
===
match
---
trailer [3511,3518]
trailer [3511,3518]
===
match
---
fstring_string: airflow.macros. [10343,10358]
fstring_string: airflow.macros. [10370,10385]
===
match
---
name: mock_entrypoint [8130,8145]
name: mock_entrypoint [8157,8172]
===
match
---
suite [5481,5587]
suite [5508,5614]
===
match
---
operator: , [5717,5718]
operator: , [5744,5745]
===
match
---
sync_comp_for [3185,3289]
sync_comp_for [3185,3289]
===
match
---
name: Mock [11641,11645]
name: Mock [11668,11672]
===
match
---
operator: = [11675,11676]
operator: = [11702,11703]
===
match
---
simple_stmt [3995,4035]
simple_stmt [3995,4035]
===
match
---
string: 'airflow.plugins' [8154,8171]
string: 'airflow.plugins' [8181,8198]
===
match
---
simple_stmt [1006,1068]
simple_stmt [1006,1068]
===
match
---
simple_stmt [8566,8592]
simple_stmt [8593,8619]
===
match
---
comparison [3316,3331]
comparison [3316,3331]
===
match
---
atom [4075,4077]
atom [4075,4077]
===
match
---
trailer [11584,11591]
trailer [11611,11618]
===
match
---
expr_stmt [1494,1570]
expr_stmt [1494,1570]
===
match
---
assert_stmt [11128,11175]
assert_stmt [11155,11202]
===
match
---
trailer [3765,3776]
trailer [3765,3776]
===
match
---
name: return_value [11863,11875]
name: return_value [11890,11902]
===
match
---
trailer [4698,4706]
trailer [4725,4733]
===
match
---
comparison [4727,4786]
comparison [4754,4813]
===
match
---
param [9047,9054]
param [9074,9081]
===
match
---
name: appbuilder_mitem [3056,3072]
name: appbuilder_mitem [3056,3072]
===
match
---
name: test_flaskappbuilder_menu_links [2971,3002]
name: test_flaskappbuilder_menu_links [2971,3002]
===
match
---
name: AirflowTestPropertyPlugin [4155,4180]
name: AirflowTestPropertyPlugin [4155,4180]
===
match
---
atom_expr [4683,4706]
atom_expr [4710,4733]
===
match
---
string: 'test-entrypoint-plugin' [11686,11710]
string: 'test-entrypoint-plugin' [11713,11737]
===
match
---
simple_stmt [9065,9170]
simple_stmt [9092,9197]
===
match
---
expr_stmt [3141,3299]
expr_stmt [3141,3299]
===
match
---
operator: == [4072,4074]
operator: == [4072,4074]
===
match
---
name: sys [826,829]
name: sys [826,829]
===
match
---
atom_expr [2151,2160]
atom_expr [2151,2160]
===
match
---
name: mock_plugin_manager [6573,6592]
name: mock_plugin_manager [6600,6619]
===
match
---
expr_stmt [11513,11560]
expr_stmt [11540,11587]
===
match
---
operator: , [5445,5446]
operator: , [5472,5473]
===
match
---
name: str [11236,11239]
name: str [11263,11266]
===
match
---
trailer [4864,4872]
trailer [4891,4899]
===
match
---
simple_stmt [5108,5141]
simple_stmt [5135,5168]
===
match
---
atom_expr [3450,3459]
atom_expr [3450,3459]
===
match
---
suite [10956,11335]
suite [10983,11362]
===
match
---
string: 'test.plugins.test_plugins_manager' [8205,8240]
string: 'test.plugins.test_plugins_manager' [8232,8267]
===
match
---
assert_stmt [12031,12079]
assert_stmt [12058,12106]
===
match
---
name: plugins_manager [4515,4530]
name: plugins_manager [4515,4530]
===
match
---
name: len [1725,1728]
name: len [1725,1728]
===
match
---
expr_stmt [11953,12022]
expr_stmt [11980,12049]
===
match
---
string: 'airflow.plugins_manager' [6724,6749]
string: 'airflow.plugins_manager' [6751,6776]
===
match
---
param [11415,11419]
param [11442,11446]
===
match
---
trailer [9765,9783]
trailer [9792,9810]
===
match
---
fstring_expr [10358,10376]
fstring_expr [10385,10403]
===
match
---
trailer [2155,2160]
trailer [2155,2160]
===
match
---
suite [4196,4409]
suite [4196,4409]
===
match
---
fstring_string: .distributions [8422,8436]
fstring_string: .distributions [8449,8463]
===
match
---
atom_expr [1958,1990]
atom_expr [1958,1990]
===
match
---
trailer [4010,4032]
trailer [4010,4032]
===
match
---
name: mock [8022,8026]
name: mock [8049,8053]
===
match
---
atom [11781,11798]
atom [11808,11825]
===
match
---
assert_stmt [11184,11247]
assert_stmt [11211,11274]
===
match
---
comparison [2212,2263]
comparison [2212,2263]
===
match
---
atom_expr [10317,10378]
atom_expr [10344,10405]
===
match
---
name: import_errors [8979,8992]
name: import_errors [9006,9019]
===
match
---
trailer [9819,9837]
trailer [9846,9864]
===
match
---
atom [7361,7379]
atom [7388,7406]
===
match
---
trailer [8026,8031]
trailer [8053,8058]
===
match
---
operator: == [2028,2030]
operator: == [2028,2030]
===
match
---
atom_expr [6615,6640]
atom_expr [6642,6667]
===
match
---
operator: , [6715,6716]
operator: , [6742,6743]
===
match
---
name: test_should_load_plugins_from_property [4087,4125]
name: test_should_load_plugins_from_property [4087,4125]
===
match
---
trailer [3802,3807]
trailer [3802,3807]
===
match
---
operator: = [7304,7305]
operator: = [7331,7332]
===
match
---
name: appbuilder_menu_items [6516,6537]
name: appbuilder_menu_items [6543,6564]
===
match
---
name: test_should_warning_about_incompatible_plugins [4934,4980]
name: test_should_warning_about_incompatible_plugins [4961,5007]
===
match
---
atom_expr [5345,5370]
atom_expr [5372,5397]
===
match
---
name: tests [2327,2332]
name: tests [2327,2332]
===
match
---
trailer [2707,2718]
trailer [2707,2718]
===
match
---
name: logging [5975,5982]
name: logging [6002,6009]
===
match
---
name: menu [1915,1919]
name: menu [1915,1919]
===
match
---
trailer [2874,2879]
trailer [2874,2879]
===
match
---
dotted_name [3604,3629]
dotted_name [3604,3629]
===
match
---
expr_stmt [6316,6348]
expr_stmt [6343,6375]
===
match
---
name: mock_dist [11624,11633]
name: mock_dist [11651,11660]
===
match
---
string: 'category' [2185,2195]
string: 'category' [2185,2195]
===
match
---
name: str [1518,1521]
name: str [1518,1521]
===
match
---
simple_stmt [3500,3555]
simple_stmt [3500,3555]
===
match
---
atom_expr [8466,8552]
atom_expr [8493,8579]
===
match
---
string: "test_admin_views_plugin" [6323,6348]
string: "test_admin_views_plugin" [6350,6375]
===
match
---
trailer [4057,4071]
trailer [4057,4071]
===
match
---
operator: { [8402,8403]
operator: { [8429,8430]
===
match
---
sync_comp_for [1882,1990]
sync_comp_for [1882,1990]
===
match
---
sync_comp_for [2824,2904]
sync_comp_for [2824,2904]
===
match
---
name: msg [4877,4880]
name: msg [4904,4907]
===
match
---
comparison [3450,3491]
comparison [3450,3491]
===
match
---
name: appbuilder_views [6362,6378]
name: appbuilder_views [6389,6405]
===
match
---
trailer [6386,6396]
trailer [6413,6423]
===
match
---
expr_stmt [2120,2135]
expr_stmt [2120,2135]
===
match
---
comparison [11135,11175]
comparison [11162,11202]
===
match
---
atom_expr [9754,9783]
atom_expr [9781,9810]
===
match
---
name: test_should_not_warning_about_fab_and_flask_admin_plugins [6909,6966]
name: test_should_not_warning_about_fab_and_flask_admin_plugins [6936,6993]
===
match
---
name: self [6235,6239]
name: self [6262,6266]
===
match
---
parameters [7781,7795]
parameters [7808,7822]
===
match
---
trailer [6545,6555]
trailer [6572,6582]
===
match
---
string: 'foo' [9932,9937]
string: 'foo' [9959,9964]
===
match
---
name: __name__ [2588,2596]
name: __name__ [2588,2596]
===
match
---
param [7788,7794]
param [7815,7821]
===
match
---
name: caplog [7505,7511]
name: caplog [7532,7538]
===
match
---
parameters [9301,9303]
parameters [9328,9330]
===
match
---
atom_expr [8081,8101]
atom_expr [8108,8128]
===
match
---
string: 'view' [2570,2576]
string: 'view' [2570,2576]
===
match
---
atom [4390,4408]
atom [4390,4408]
===
match
---
classdef [2397,2505]
classdef [2397,2505]
===
match
---
name: self [3202,3206]
name: self [3202,3206]
===
match
---
atom_expr [6541,6557]
atom_expr [6568,6584]
===
match
---
funcdef [4083,4925]
funcdef [4083,4952]
===
match
---
operator: == [3258,3260]
operator: == [3258,3260]
===
match
---
atom_expr [8180,8202]
atom_expr [8207,8229]
===
match
---
operator: = [4450,4451]
operator: = [4450,4451]
===
match
---
funcdef [10961,11335]
funcdef [10988,11362]
===
match
---
parameters [4125,4139]
parameters [4125,4139]
===
match
---
string: "my_fake_module not found" [8948,8974]
string: "my_fake_module not found" [8975,9001]
===
match
---
name: AirflowPlugin [4181,4194]
name: AirflowPlugin [4181,4194]
===
match
---
import_from [7585,7620]
import_from [7612,7647]
===
match
---
name: source [12251,12257]
name: source [12278,12284]
===
match
---
trailer [1274,1285]
trailer [1274,1285]
===
match
---
simple_stmt [5257,5289]
simple_stmt [5284,5316]
===
match
---
name: WARNING [5438,5445]
name: WARNING [5465,5472]
===
match
---
name: AirflowNoMenuViewsPlugin [2403,2427]
name: AirflowNoMenuViewsPlugin [2403,2427]
===
match
---
trailer [3791,3796]
trailer [3791,3796]
===
match
---
operator: == [12059,12061]
operator: == [12086,12088]
===
match
---
trailer [4876,4880]
trailer [4903,4907]
===
match
---
atom [10093,10108]
atom [10120,10135]
===
match
---
trailer [10216,10218]
trailer [10243,10245]
===
match
---
trailer [10875,10901]
trailer [10902,10928]
===
match
---
name: caplog [4987,4993]
name: caplog [5014,5020]
===
match
---
name: v_nomenu_appbuilder_package [2476,2503]
name: v_nomenu_appbuilder_package [2476,2503]
===
match
---
import_from [873,912]
import_from [873,912]
===
match
---
name: str [4749,4752]
name: str [4776,4779]
===
match
---
expr_stmt [11656,11711]
expr_stmt [11683,11738]
===
match
---
trailer [1919,1924]
trailer [1919,1924]
===
match
---
param [3872,3877]
param [3872,3877]
===
match
---
comparison [4051,4077]
comparison [4051,4077]
===
match
---
name: links [3320,3325]
name: links [3320,3325]
===
match
---
name: MagicMock [7367,7376]
name: MagicMock [7394,7403]
===
match
---
name: __class__ [2578,2587]
name: __class__ [2578,2587]
===
match
---
name: BaseHook [4330,4338]
name: BaseHook [4330,4338]
===
match
---
name: integrate_macros_plugins [10192,10216]
name: integrate_macros_plugins [10219,10243]
===
match
---
comparison [3757,3807]
comparison [3757,3807]
===
match
---
simple_stmt [11756,11799]
simple_stmt [11783,11826]
===
match
---
name: test_plugin [3618,3629]
name: test_plugin [3618,3629]
===
match
---
dotted_name [7931,7954]
dotted_name [7958,7981]
===
match
---
operator: , [8437,8438]
operator: , [8464,8465]
===
match
---
name: str [12155,12158]
name: str [12182,12185]
===
match
---
operator: = [8020,8021]
operator: = [8047,8048]
===
match
---
atom_expr [5123,5139]
atom_expr [5150,5166]
===
match
---
expr_stmt [7048,7080]
expr_stmt [7075,7107]
===
match
---
operator: = [10315,10316]
operator: = [10342,10343]
===
match
---
simple_stmt [4720,4787]
simple_stmt [4747,4814]
===
match
---
expr_stmt [11756,11798]
expr_stmt [11783,11825]
===
match
---
trailer [5982,5990]
trailer [6009,6017]
===
match
---
atom [3149,3299]
atom [3149,3299]
===
match
---
atom [2801,2918]
atom [2801,2918]
===
match
---
string: 'category' [3480,3490]
string: 'category' [3480,3490]
===
match
---
param [7782,7787]
param [7809,7814]
===
match
---
name: PluginsDirectorySource [11087,11109]
name: PluginsDirectorySource [11114,11136]
===
match
---
name: name [2875,2879]
name: name [2875,2879]
===
match
---
name: self [3584,3588]
name: self [3584,3588]
===
match
---
operator: = [8619,8620]
operator: = [8646,8647]
===
match
---
string: 'airflow.macros' [9766,9782]
string: 'airflow.macros' [9793,9809]
===
match
---
atom_expr [3722,3741]
atom_expr [3722,3741]
===
match
---
arglist [8495,8542]
arglist [8522,8569]
===
match
---
suite [11421,12269]
suite [11448,12296]
===
match
---
name: version [11730,11737]
name: version [11757,11764]
===
match
---
name: macro [10603,10608]
name: macro [10630,10635]
===
match
---
name: record_tuples [6880,6893]
name: record_tuples [6907,6920]
===
match
---
name: menu [3223,3227]
name: menu [3223,3227]
===
match
---
name: entry_points [11766,11778]
name: entry_points [11793,11805]
===
match
---
atom_expr [4544,4575]
atom_expr [4544,4602]
===
match
---
name: name [3253,3257]
name: name [3253,3257]
===
match
---
simple_stmt [11720,11748]
simple_stmt [11747,11775]
===
match
---
name: mock_entrypoint [11475,11490]
name: mock_entrypoint [11502,11517]
===
match
---
atom_expr [2836,2856]
atom_expr [2836,2856]
===
match
---
trailer [8031,8033]
trailer [8058,8060]
===
match
---
comparison [8696,8749]
comparison [8723,8776]
===
match
---
simple_stmt [11017,11053]
simple_stmt [11044,11080]
===
match
---
name: MagicMock [6546,6555]
name: MagicMock [6573,6582]
===
match
---
name: name [2156,2160]
name: name [2156,2160]
===
match
---
trailer [7511,7520]
trailer [7538,7547]
===
match
---
trailer [4442,4481]
trailer [4442,4481]
===
match
---
name: plugins_manager [3995,4010]
name: plugins_manager [3995,4010]
===
match
---
expr_stmt [10027,10050]
expr_stmt [10054,10077]
===
match
---
operator: = [7359,7360]
operator: = [7386,7387]
===
match
---
assert_stmt [2205,2263]
assert_stmt [2205,2263]
===
match
---
atom_expr [2939,2956]
atom_expr [2939,2956]
===
match
---
simple_stmt [4851,4925]
simple_stmt [4878,4952]
===
match
---
operator: = [8059,8060]
operator: = [8086,8087]
===
match
---
atom_expr [3243,3257]
atom_expr [3243,3257]
===
match
---
expr_stmt [3419,3434]
expr_stmt [3419,3434]
===
match
---
trailer [4603,4625]
trailer [4630,4652]
===
match
---
operator: = [2694,2695]
operator: = [2694,2695]
===
match
---
simple_stmt [7926,8001]
simple_stmt [7953,8028]
===
match
---
operator: = [1261,1262]
operator: = [1261,1262]
===
match
---
name: mock_entrypoint [11513,11528]
name: mock_entrypoint [11540,11555]
===
match
---
trailer [6555,6557]
trailer [6582,6584]
===
match
---
string: 'category' [1979,1989]
string: 'category' [1979,1989]
===
match
---
name: appbuilder_menu_items [7337,7358]
name: appbuilder_menu_items [7364,7385]
===
match
---
name: plugins [4699,4706]
name: plugins [4726,4733]
===
match
---
trailer [5429,5480]
trailer [5456,5507]
===
match
---
operator: = [2799,2800]
operator: = [2799,2800]
===
match
---
name: hasattr [10868,10875]
name: hasattr [10895,10902]
===
match
---
trailer [7649,7675]
trailer [7676,7702]
===
match
---
param [6967,6972]
param [6994,6999]
===
match
---
trailer [9854,9867]
trailer [9881,9894]
===
match
---
name: received_logs [8877,8890]
name: received_logs [8904,8917]
===
match
---
atom_expr [1252,1260]
atom_expr [1252,1260]
===
match
---
name: caplog [6241,6247]
name: caplog [6268,6274]
===
match
---
simple_stmt [1308,1375]
simple_stmt [1308,1375]
===
match
---
name: sys [1076,1079]
name: sys [1076,1079]
===
match
---
trailer [6592,6682]
trailer [6619,6709]
===
match
---
atom [7718,7720]
atom [7745,7747]
===
match
---
name: menu_item [3163,3172]
name: menu_item [3163,3172]
===
match
---
funcdef [1227,1375]
funcdef [1227,1375]
===
match
---
with_stmt [11808,11944]
with_stmt [11835,11971]
===
match
---
trailer [5584,5586]
trailer [5611,5613]
===
match
---
name: py39 [1069,1073]
name: py39 [1069,1073]
===
match
---
trailer [10608,10617]
trailer [10635,10644]
===
match
---
trailer [7520,7571]
trailer [7547,7598]
===
match
---
string: """         Test that Airflow does not raise an error if there is any Exception because of a plugin.         """ [7805,7917]
string: """         Test that Airflow does not raise an error if there is any Exception because of a plugin.         """ [7832,7944]
===
match
---
expr_stmt [1579,1708]
expr_stmt [1579,1708]
===
match
---
trailer [11497,11502]
trailer [11524,11529]
===
match
---
atom_expr [10868,10901]
atom_expr [10895,10928]
===
match
---
name: menu_item [3243,3252]
name: menu_item [3243,3252]
===
match
---
name: macros [9198,9204]
name: macros [9225,9231]
===
match
---
trailer [3521,3526]
trailer [3521,3526]
===
match
---
simple_stmt [6316,6349]
simple_stmt [6343,6376]
===
match
---
simple_stmt [1579,1709]
simple_stmt [1579,1709]
===
match
---
name: macro [10395,10400]
name: macro [10422,10427]
===
match
---
param [6973,6979]
param [7000,7006]
===
match
---
name: mock_plugins [1028,1040]
name: mock_plugins [1028,1040]
===
match
---
operator: = [2536,2537]
operator: = [2536,2537]
===
match
---
trailer [1211,1220]
trailer [1211,1220]
===
match
---
string: 'name' [2256,2262]
string: 'name' [2256,2262]
===
match
---
name: self [11002,11006]
name: self [11029,11033]
===
match
---
trailer [7413,7503]
trailer [7440,7530]
===
match
---
string: 'AirflowTestPropertyPlugin' [4648,4675]
string: 'AirflowTestPropertyPlugin' [4675,4702]
===
match
---
simple_stmt [913,963]
simple_stmt [913,963]
===
match
---
comparison [2151,2196]
comparison [2151,2196]
===
match
---
name: mock_entrypoint [11995,12010]
name: mock_entrypoint [12022,12037]
===
match
---
atom_expr [9796,9837]
atom_expr [9823,9864]
===
match
---
name: plugins [5336,5343]
name: plugins [5363,5370]
===
match
---
trailer [5609,5623]
trailer [5636,5650]
===
match
---
name: caplog [7788,7794]
name: caplog [7815,7821]
===
match
---
comparison [12182,12268]
comparison [12209,12295]
===
match
---
name: menu_item [1860,1869]
name: menu_item [1860,1869]
===
match
---
string: "<em>$PLUGINS_FOLDER/</em>test_plugins_manager.py" [11263,11313]
string: "<em>$PLUGINS_FOLDER/</em>test_plugins_manager.py" [11290,11340]
===
match
---
name: module [11585,11591]
name: module [11612,11618]
===
match
---
operator: = [10034,10035]
operator: = [10061,10062]
===
match
---
funcdef [7726,9001]
funcdef [7753,9028]
===
match
---
simple_stmt [873,913]
simple_stmt [873,913]
===
match
---
import_from [3946,3981]
import_from [3946,3981]
===
match
---
trailer [1334,1345]
trailer [1334,1345]
===
match
---
name: app [987,990]
name: app [987,990]
===
match
---
simple_stmt [3750,3808]
simple_stmt [3750,3808]
===
match
---
name: link [2212,2216]
name: link [2212,2216]
===
match
---
string: 'category' [3278,3288]
string: 'category' [3278,3288]
===
match
---
fstring_start: f' [8400,8402]
fstring_start: f' [8427,8429]
===
match
---
simple_stmt [1426,1485]
simple_stmt [1426,1485]
===
match
---
comparison [11263,11334]
comparison [11290,11361]
===
match
---
trailer [11109,11119]
trailer [11136,11146]
===
match
---
suite [11364,12269]
suite [11391,12296]
===
match
---
classdef [5004,5141]
classdef [5031,5168]
===
match
---
operator: , [12010,12011]
operator: , [12037,12038]
===
match
---
name: test_registering_plugin_macros [9010,9040]
name: test_registering_plugin_macros [9037,9067]
===
match
---
simple_stmt [2932,2962]
simple_stmt [2932,2962]
===
match
---
operator: , [6157,6158]
operator: , [6184,6185]
===
match
---
operator: = [6723,6724]
operator: = [6750,6751]
===
match
---
parameters [3583,3589]
parameters [3583,3589]
===
match
---
name: AirflowPlugin [6288,6301]
name: AirflowPlugin [6315,6328]
===
match
---
name: __name__ [1561,1569]
name: __name__ [1561,1569]
===
match
---
atom_expr [10094,10107]
atom_expr [10121,10134]
===
match
---
suite [11889,11944]
suite [11916,11971]
===
match
---
name: mock [6541,6545]
name: mock [6568,6572]
===
match
---
atom_expr [3426,3434]
atom_expr [3426,3434]
===
match
---
name: importlib_metadata [8403,8421]
name: importlib_metadata [8430,8448]
===
match
---
name: caplog [4051,4057]
name: caplog [4051,4057]
===
match
---
simple_stmt [8605,8633]
simple_stmt [8632,8660]
===
match
---
name: record_tuples [7701,7714]
name: record_tuples [7728,7741]
===
match
---
atom_expr [2235,2263]
atom_expr [2235,2263]
===
match
---
name: load [8265,8269]
name: load [8292,8296]
===
match
---
string: "Traceback (most recent call last):" [8696,8732]
string: "Traceback (most recent call last):" [8723,8759]
===
match
---
name: unittest [837,845]
name: unittest [837,845]
===
match
---
operator: = [7156,7157]
operator: = [7183,7184]
===
match
---
operator: = [7253,7254]
operator: = [7280,7281]
===
match
---
trailer [11665,11674]
trailer [11692,11701]
===
match
---
assert_stmt [8762,8812]
assert_stmt [8789,8839]
===
match
---
assert_stmt [8903,9000]
assert_stmt [8930,9027]
===
match
---
atom_expr [4423,4481]
atom_expr [4423,4481]
===
match
---
operator: = [7434,7435]
operator: = [7461,7462]
===
match
---
atom_expr [10580,10618]
atom_expr [10607,10645]
===
match
---
name: plugins [3921,3928]
name: plugins [3921,3928]
===
match
---
trailer [8096,8101]
trailer [8123,8128]
===
match
---
operator: } [8421,8422]
operator: } [8448,8449]
===
match
---
atom_expr [2612,2669]
atom_expr [2612,2669]
===
match
---
trailer [7490,7492]
trailer [7517,7519]
===
match
---
name: mock_dist [8453,8462]
name: mock_dist [8480,8489]
===
match
---
assert_stmt [10573,10618]
assert_stmt [10600,10645]
===
match
---
comparison [5603,6183]
comparison [5630,6210]
===
match
---
param [3878,3884]
param [3878,3884]
===
match
---
trailer [8472,8481]
trailer [8499,8508]
===
match
---
name: self [1411,1415]
name: self [1411,1415]
===
match
---
atom_expr [10884,10900]
atom_expr [10911,10927]
===
match
---
testlist_comp [1608,1698]
testlist_comp [1608,1698]
===
match
---
name: custom_macro [9897,9909]
name: custom_macro [9924,9936]
===
match
---
operator: = [6476,6477]
operator: = [6503,6504]
===
match
---
name: plugins [2333,2340]
name: plugins [2333,2340]
===
match
---
atom_expr [2538,2597]
atom_expr [2538,2597]
===
match
---
trailer [8065,8070]
trailer [8092,8097]
===
match
---
number: 0 [2224,2225]
number: 0 [2224,2225]
===
match
---
string: "test_menu_links_plugin" [5219,5243]
string: "test_menu_links_plugin" [5246,5270]
===
match
---
name: mock_entrypoint [12042,12057]
name: mock_entrypoint [12069,12084]
===
match
---
simple_stmt [8825,8891]
simple_stmt [8852,8918]
===
match
---
trailer [1312,1323]
trailer [1312,1323]
===
match
---
name: testing [2719,2726]
name: testing [2719,2726]
===
match
---
name: test_should_not_warning_about_fab_plugins [6193,6234]
name: test_should_not_warning_about_fab_plugins [6220,6261]
===
match
---
name: name [6471,6475]
name: name [6498,6502]
===
match
---
name: airflow [7590,7597]
name: airflow [7617,7624]
===
match
---
string: 'TestPropertyHook' [4727,4745]
string: 'TestPropertyHook' [4754,4772]
===
match
---
suite [4995,6184]
suite [5022,6211]
===
match
---
simple_stmt [6764,6800]
simple_stmt [6791,6827]
===
match
---
name: airflow [6769,6776]
name: airflow [6796,6803]
===
match
---
name: DEBUG [4569,4574]
name: DEBUG [4569,4574]
===
match
---
classdef [3810,10902]
classdef [3810,10929]
===
match
---
with_stmt [3896,4035]
with_stmt [3896,4035]
===
match
---
atom [5914,6172]
atom [5941,6199]
===
match
---
name: TestPluginsRBAC [1187,1202]
name: TestPluginsRBAC [1187,1202]
===
match
---
name: str [12038,12041]
name: str [12065,12068]
===
match
---
name: importlib_metadata [1103,1121]
name: importlib_metadata [1103,1121]
===
match
---
trailer [1914,1919]
trailer [1914,1919]
===
match
---
expr_stmt [8081,8121]
expr_stmt [8108,8148]
===
match
---
atom [1594,1708]
atom [1594,1708]
===
match
---
trailer [3730,3741]
trailer [3730,3741]
===
match
---
name: record_tuples [4058,4071]
name: record_tuples [4058,4071]
===
match
---
trailer [5437,5445]
trailer [5464,5472]
===
match
---
fstring [11824,11861]
fstring [11851,11888]
===
match
---
trailer [3761,3765]
trailer [3761,3765]
===
match
---
name: airflow [878,885]
name: airflow [878,885]
===
match
---
name: AirflowAdminMenuLinksPlugin [7463,7490]
name: AirflowAdminMenuLinksPlugin [7490,7517]
===
match
---
atom_expr [11569,11591]
atom_expr [11596,11618]
===
match
---
simple_stmt [9925,9938]
simple_stmt [9952,9965]
===
match
---
trailer [4477,4479]
trailer [4477,4479]
===
match
---
simple_stmt [804,819]
simple_stmt [804,819]
===
match
---
name: plugins_manager [7939,7954]
name: plugins_manager [7966,7981]
===
match
---
funcdef [3840,4078]
funcdef [3840,4078]
===
match
---
string: 'airflow.plugins_manager' [8517,8542]
string: 'airflow.plugins_manager' [8544,8569]
===
match
---
name: plugin_views [1729,1741]
name: plugin_views [1729,1741]
===
match
---
name: path [11171,11175]
name: path [11198,11202]
===
match
---
trailer [7459,7461]
trailer [7486,7488]
===
match
---
operator: , [6239,6240]
operator: , [6266,6267]
===
match
---
simple_stmt [5062,5095]
simple_stmt [5089,5122]
===
match
---
number: 3 [1097,1098]
number: 3 [1097,1098]
===
match
---
operator: = [5120,5121]
operator: = [5147,5148]
===
match
---
expr_stmt [5257,5288]
expr_stmt [5284,5315]
===
match
---
trailer [7700,7714]
trailer [7727,7741]
===
match
---
atom_expr [10065,10109]
atom_expr [10092,10136]
===
match
---
simple_stmt [819,830]
simple_stmt [819,830]
===
match
---
trailer [5322,5412]
trailer [5349,5439]
===
match
---
expr_stmt [1252,1299]
expr_stmt [1252,1299]
===
match
---
atom_expr [3202,3227]
atom_expr [3202,3227]
===
match
---
operator: = [7544,7545]
operator: = [7571,7572]
===
match
---
argument [4443,4480]
argument [4443,4480]
===
match
---
trailer [8502,8508]
trailer [8529,8535]
===
match
---
name: menu_item [1940,1949]
name: menu_item [1940,1949]
===
match
---
with_stmt [8384,9001]
with_stmt [8411,9028]
===
match
---
trailer [11817,11823]
trailer [11844,11850]
===
match
---
comparison [12095,12166]
comparison [12122,12193]
===
match
---
string: 'airflow.plugins_manager' [7545,7570]
string: 'airflow.plugins_manager' [7572,7597]
===
match
---
assert_stmt [10861,10901]
assert_stmt [10888,10928]
===
match
---
operator: = [2726,2727]
operator: = [2726,2727]
===
match
---
atom_expr [7362,7378]
atom_expr [7389,7405]
===
match
---
name: menu [3218,3222]
name: menu [3218,3222]
===
match
---
trailer [2216,2223]
trailer [2216,2223]
===
match
---
trailer [3319,3326]
trailer [3319,3326]
===
match
---
simple_stmt [7634,7678]
simple_stmt [7661,7705]
===
match
---
name: MacroPlugin [9953,9964]
name: MacroPlugin [9980,9991]
===
match
---
name: AirflowAdminMenuLinksPlugin [5372,5399]
name: AirflowAdminMenuLinksPlugin [5399,5426]
===
match
---
name: baseviews [2847,2856]
name: baseviews [2847,2856]
===
match
---
trailer [3277,3289]
trailer [3277,3289]
===
match
---
name: hooks [4278,4283]
name: hooks [4278,4283]
===
match
---
name: importlib [794,803]
name: importlib [794,803]
===
match
---
simple_stmt [6866,6900]
simple_stmt [6893,6927]
===
match
---
expr_stmt [7094,7126]
expr_stmt [7121,7153]
===
match
---
atom_expr [1899,1924]
atom_expr [1899,1924]
===
match
---
argument [11863,11887]
argument [11890,11914]
===
match
---
trailer [2587,2596]
trailer [2587,2596]
===
match
---
name: self [3757,3761]
name: self [3757,3761]
===
match
---
name: AirflowPlugin [9965,9978]
name: AirflowPlugin [9992,10005]
===
match
---
name: mock [5123,5127]
name: mock [5150,5154]
===
match
---
name: plugins_manager [5543,5558]
name: plugins_manager [5570,5585]
===
match
---
name: sys [9754,9757]
name: sys [9781,9784]
===
match
---
assert_stmt [1718,1747]
assert_stmt [1718,1747]
===
match
---
trailer [8295,8323]
trailer [8322,8350]
===
match
---
simple_stmt [11475,11505]
simple_stmt [11502,11532]
===
match
---
atom_expr [7159,7175]
atom_expr [7186,7202]
===
match
---
return_stmt [4383,4408]
return_stmt [4383,4408]
===
match
---
operator: = [2639,2640]
operator: = [2639,2640]
===
match
---
name: AirflowPlugin [2428,2441]
name: AirflowPlugin [2428,2441]
===
match
---
argument [2632,2668]
argument [2632,2668]
===
match
---
trailer [3217,3222]
trailer [3217,3222]
===
match
---
testlist_comp [1097,1101]
testlist_comp [1097,1101]
===
match
---
trailer [1550,1560]
trailer [1550,1560]
===
match
---
operator: - [4873,4874]
operator: - [4900,4901]
===
match
---
expr_stmt [8249,8323]
expr_stmt [8276,8350]
===
match
---
name: MagicMock [7114,7123]
name: MagicMock [7141,7150]
===
match
---
atom_expr [7634,7677]
atom_expr [7661,7704]
===
match
---
name: addfinalizer [9855,9867]
name: addfinalizer [9882,9894]
===
match
---
assert_stmt [3443,3491]
assert_stmt [3443,3491]
===
match
---
name: plugins [3610,3617]
name: plugins [3610,3617]
===
match
---
atom_expr [12038,12058]
atom_expr [12065,12085]
===
match
---
operator: , [4985,4986]
operator: , [5012,5013]
===
match
---
assert_stmt [3309,3331]
assert_stmt [3309,3331]
===
match
---
atom [2640,2668]
atom [2640,2668]
===
match
---
atom_expr [5430,5445]
atom_expr [5457,5472]
===
match
---
assert_stmt [12175,12268]
assert_stmt [12202,12295]
===
match
---
expr_stmt [5062,5094]
expr_stmt [5089,5121]
===
match
---
name: v_appbuilder_package [1464,1484]
name: v_appbuilder_package [1464,1484]
===
match
---
name: ImportError [8284,8295]
name: ImportError [8311,8322]
===
match
---
name: tests [3604,3609]
name: tests [3604,3609]
===
match
---
suite [4340,4366]
suite [4340,4366]
===
match
---
atom_expr [4051,4071]
atom_expr [4051,4071]
===
match
---
string: "Failed to import plugin test-entrypoint" [8832,8873]
string: "Failed to import plugin test-entrypoint" [8859,8900]
===
match
---
simple_stmt [7139,7177]
simple_stmt [7166,7204]
===
match
---
trailer [8264,8269]
trailer [8291,8296]
===
match
---
trailer [5420,5429]
trailer [5447,5456]
===
match
---
trailer [7528,7536]
trailer [7555,7563]
===
match
---
string: "test_plugins_manager.py" [11135,11160]
string: "test_plugins_manager.py" [11162,11187]
===
match
---
argument [5336,5402]
argument [5363,5429]
===
match
---
name: link [3419,3423]
name: link [3419,3423]
===
match
---
expr_stmt [2683,2743]
expr_stmt [2683,2743]
===
match
---
name: app [3727,3730]
name: app [3727,3730]
===
match
---
dotted_name [1011,1040]
dotted_name [1011,1040]
===
match
---
name: links [3426,3431]
name: links [3426,3431]
===
match
---
name: test_plugin [3037,3048]
name: test_plugin [3037,3048]
===
match
---
name: link [2120,2124]
name: link [2120,2124]
===
match
---
comparison [11191,11247]
comparison [11218,11274]
===
match
---
string: 'test-entrypoint-plugin' [11536,11560]
string: 'test-entrypoint-plugin' [11563,11587]
===
match
---
name: mock_entrypoint [8358,8373]
name: mock_entrypoint [8385,8400]
===
match
---
simple_stmt [9213,9274]
simple_stmt [9240,9301]
===
match
---
atom_expr [8332,8354]
atom_expr [8359,8381]
===
match
---
trailer [5558,5584]
trailer [5585,5611]
===
match
---
factor [4818,4820]
factor [4845,4847]
===
match
---
name: AirflowPlugin [7220,7233]
name: AirflowPlugin [7247,7260]
===
match
---
name: mock_plugin_manager [10065,10084]
name: mock_plugin_manager [10092,10111]
===
match
---
trailer [12266,12268]
trailer [12293,12295]
===
match
---
name: caplog [4544,4550]
name: caplog [4544,4550]
===
match
---
name: unittest [851,859]
name: unittest [851,859]
===
match
---
name: name [4209,4213]
name: name [4209,4213]
===
match
---
string: """         Tests whether macros that originate from plugins are being registered correctly.         """ [9065,9169]
string: """         Tests whether macros that originate from plugins are being registered correctly.         """ [9092,9196]
===
match
---
atom_expr [5603,5623]
atom_expr [5630,5650]
===
match
---
trailer [8145,8151]
trailer [8172,8178]
===
match
---
atom [8357,8374]
atom [8384,8401]
===
match
---
trailer [1285,1299]
trailer [1285,1299]
===
match
---
test [1124,1178]
test [1124,1178]
===
match
---
atom_expr [8249,8281]
atom_expr [8276,8308]
===
match
---
name: self [4981,4985]
name: self [5008,5012]
===
match
---
operator: , [5900,5901]
operator: , [5927,5928]
===
match
---
testlist_comp [1860,1990]
testlist_comp [1860,1990]
===
match
---
atom_expr [3507,3526]
atom_expr [3507,3526]
===
match
---
testlist_comp [5659,5886]
testlist_comp [5686,5913]
===
match
---
classdef [6258,6400]
classdef [6285,6427]
===
match
---
assert_stmt [2932,2961]
assert_stmt [2932,2961]
===
insert-node
---
arglist [4561,4601]
to
trailer [4560,4575]
at 0
===
move-tree
---
atom_expr [4561,4574]
    name: logging [4561,4568]
    trailer [4568,4574]
        name: DEBUG [4569,4574]
to
arglist [4561,4601]
at 0
