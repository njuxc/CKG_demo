===
match
---
atom_expr [2119,2145]
atom_expr [2147,2173]
===
match
---
string: 'new_state' [7027,7038]
string: 'new_state' [7039,7050]
===
match
---
string: "TEST_TASK_ID" [4696,4710]
string: "TEST_TASK_ID" [4716,4730]
===
match
---
operator: , [5207,5208]
operator: , [5219,5220]
===
match
---
trailer [3783,3793]
trailer [3803,3813]
===
match
---
testlist_comp [7230,7256]
testlist_comp [7242,7268]
===
match
---
name: provide_session [1252,1267]
name: provide_session [1280,1295]
===
match
---
operator: , [2899,2900]
operator: , [2927,2928]
===
match
---
operator: , [1571,1572]
operator: , [1599,1600]
===
match
---
atom [1635,1731]
atom [1663,1759]
===
match
---
operator: , [1954,1955]
operator: , [1982,1983]
===
match
---
string: "priority_weight" [2978,2995]
string: "priority_weight" [3006,3023]
===
match
---
operator: , [1131,1132]
operator: , [1116,1117]
===
match
---
atom_expr [1740,1762]
atom_expr [1768,1790]
===
match
---
suite [2064,2190]
suite [2092,2218]
===
match
---
trailer [6838,6864]
trailer [6850,6876]
===
match
---
funcdef [3381,5016]
funcdef [3401,5028]
===
match
---
name: DummyOperator [1188,1201]
name: DummyOperator [1173,1186]
===
match
---
operator: { [1765,1766]
operator: { [1793,1794]
===
match
---
operator: , [2304,2305]
operator: , [2332,2333]
===
match
---
operator: , [5497,5498]
operator: , [5509,5510]
===
match
---
string: "2020-01-03T00:00:00+00:00" [4005,4032]
string: "2020-01-03T00:00:00+00:00" [4025,4052]
===
match
---
name: task [2290,2294]
name: task [2318,2322]
===
match
---
name: serialized_ti [2481,2494]
name: serialized_ti [2509,2522]
===
match
---
trailer [2517,2522]
trailer [2545,2550]
===
match
---
string: "2020-01-01T00:00:00+00:00" [4064,4091]
string: "2020-01-01T00:00:00+00:00" [4084,4111]
===
match
---
string: "dag_id" [4463,4471]
string: "dag_id" [4483,4491]
===
match
---
trailer [2470,2472]
trailer [2498,2500]
===
match
---
string: "pool_slots" [2949,2961]
string: "pool_slots" [2977,2989]
===
match
---
trailer [6121,6130]
trailer [6133,6142]
===
match
---
name: load [6117,6121]
name: load [6129,6133]
===
match
---
name: self [3518,3522]
name: self [3538,3542]
===
match
---
name: test_validation_error [7372,7393]
name: test_validation_error [7384,7405]
===
match
---
operator: } [5699,5700]
operator: } [5711,5712]
===
match
---
operator: = [3633,3634]
operator: = [3653,3654]
===
match
---
operator: = [3710,3711]
operator: = [3730,3731]
===
match
---
name: current_input [6260,6273]
name: current_input [6272,6285]
===
match
---
atom_expr [2456,2472]
atom_expr [2484,2500]
===
match
---
expr_stmt [3594,3739]
expr_stmt [3614,3759]
===
match
---
arglist [3626,3729]
arglist [3646,3749]
===
match
---
name: unittest [5056,5064]
name: unittest [5068,5076]
===
match
---
atom_expr [3802,3818]
atom_expr [3822,3838]
===
match
---
operator: , [4314,4315]
operator: , [4334,4335]
===
match
---
number: 10000 [1949,1954]
number: 10000 [1977,1982]
===
match
---
operator: , [7346,7347]
operator: , [7358,7359]
===
match
---
name: provide_session [3361,3376]
name: provide_session [3381,3396]
===
match
---
trailer [1881,1891]
trailer [1909,1919]
===
match
---
name: query [2127,2132]
name: query [2155,2160]
===
match
---
operator: , [3069,3070]
operator: , [3097,3098]
===
match
---
string: "execution_date" [2696,2712]
string: "execution_date" [2724,2740]
===
match
---
name: current_input [7429,7442]
name: current_input [7441,7454]
===
match
---
name: operators [1165,1174]
name: operators [1150,1159]
===
match
---
trailer [3809,3816]
trailer [3829,3836]
===
match
---
string: "2020-01-01T00:00:00+00:00" [2714,2741]
string: "2020-01-01T00:00:00+00:00" [2742,2769]
===
match
---
atom [3909,4969]
atom [3929,4981]
===
match
---
trailer [3759,3763]
trailer [3779,3783]
===
match
---
operator: = [3841,3842]
operator: = [3861,3862]
===
match
---
name: tzinfo [6820,6826]
name: tzinfo [6832,6838]
===
match
---
operator: = [2557,2558]
operator: = [2585,2586]
===
match
---
name: session [3802,3809]
name: session [3822,3829]
===
match
---
string: "2020-01-03T00:00:00+00:00" [2655,2682]
string: "2020-01-03T00:00:00+00:00" [2683,2710]
===
match
---
name: serialized_ti [3324,3337]
name: serialized_ti [3344,3357]
===
match
---
atom_expr [1484,1509]
atom_expr [1512,1537]
===
match
---
dictorsetmaker [7231,7254]
dictorsetmaker [7243,7266]
===
match
---
operator: , [5732,5733]
operator: , [5744,5745]
===
match
---
string: "include_upstream" [6422,6440]
string: "include_upstream" [6434,6452]
===
match
---
name: task_instance_schema [2497,2517]
name: task_instance_schema [2525,2545]
===
match
---
string: "sla_miss" [3083,3093]
string: "sla_miss" [3111,3121]
===
match
---
operator: , [6941,6942]
operator: , [6953,6954]
===
match
---
string: "executor_config" [4105,4122]
string: "executor_config" [4125,4142]
===
match
---
string: "new_state" [7315,7326]
string: "new_state" [7327,7338]
===
match
---
name: add [2440,2443]
name: add [2468,2471]
===
match
---
decorated [7150,7577]
decorated [7162,7589]
===
match
---
operator: , [2998,2999]
operator: , [3026,3027]
===
match
---
string: "task_id" [4685,4694]
string: "task_id" [4705,4714]
===
match
---
suite [6222,6603]
suite [6234,6615]
===
match
---
trailer [6182,6191]
trailer [6194,6203]
===
match
---
atom [7230,7255]
atom [7242,7267]
===
match
---
name: task [3462,3466]
name: task [3482,3486]
===
match
---
operator: { [6276,6277]
operator: { [6288,6289]
===
match
---
name: self [1612,1616]
name: self [1640,1644]
===
match
---
operator: , [5545,5546]
operator: , [5557,5558]
===
match
---
name: expected_json [2543,2556]
name: expected_json [2571,2584]
===
match
---
atom [5764,5957]
atom [5776,5969]
===
match
---
simple_stmt [1152,1202]
simple_stmt [1137,1187]
===
match
---
simple_stmt [823,839]
simple_stmt [808,824]
===
match
---
simple_stmt [854,894]
simple_stmt [839,879]
===
match
---
testlist_comp [3870,3882]
testlist_comp [3890,3902]
===
match
---
argument [1488,1508]
argument [1516,1536]
===
match
---
trailer [1527,1532]
trailer [1555,1560]
===
match
---
name: self [3420,3424]
name: self [3440,3444]
===
match
---
name: load [7552,7556]
name: load [7564,7568]
===
match
---
operator: , [5610,5611]
operator: , [5622,5623]
===
match
---
name: delete [2181,2187]
name: delete [2209,2215]
===
match
---
operator: } [5368,5369]
operator: } [5380,5381]
===
match
---
dotted_name [1157,1180]
dotted_name [1142,1165]
===
match
---
name: datetime [1450,1458]
name: datetime [1478,1486]
===
match
---
name: TestTaskInstanceSchema [1358,1380]
name: TestTaskInstanceSchema [1386,1408]
===
match
---
name: create_session [1236,1250]
name: create_session [1264,1278]
===
match
---
number: 0 [4183,4184]
number: 0 [4203,4204]
===
match
---
dictorsetmaker [5191,5347]
dictorsetmaker [5203,5359]
===
match
---
atom_expr [3470,3490]
atom_expr [3490,3510]
===
match
---
operator: == [3338,3340]
operator: == [3358,3360]
===
match
---
name: State [1707,1712]
name: State [1735,1740]
===
match
---
expr_stmt [1740,2039]
expr_stmt [1768,2067]
===
match
---
string: "2020-01-02T00:00:00+00:00" [5650,5677]
string: "2020-01-02T00:00:00+00:00" [5662,5689]
===
match
---
atom_expr [6683,6701]
atom_expr [6695,6713]
===
match
---
operator: } [7343,7344]
operator: } [7355,7356]
===
match
---
param [3420,3425]
param [3440,3445]
===
match
---
simple_stmt [2400,2424]
simple_stmt [2428,2452]
===
match
---
string: "TEST_TASK_ID" [1557,1571]
string: "TEST_TASK_ID" [1585,1599]
===
match
---
operator: } [7296,7297]
operator: } [7308,7309]
===
match
---
file_input [786,7577]
file_input [786,7589]
===
match
---
string: "operator" [4198,4208]
string: "operator" [4218,4228]
===
match
---
atom_expr [1535,1602]
atom_expr [1563,1630]
===
match
---
atom [5455,5700]
atom [5467,5712]
===
match
---
operator: @ [5080,5081]
operator: @ [5092,5093]
===
match
---
dictorsetmaker [1779,2029]
dictorsetmaker [1807,2057]
===
match
---
operator: , [7213,7214]
operator: , [7225,7226]
===
match
---
classdef [6133,7577]
classdef [6145,7589]
===
match
---
name: self [6019,6023]
name: self [6031,6035]
===
match
---
suite [2106,2190]
suite [2134,2218]
===
match
---
name: clear_task_instance_form [1004,1028]
name: clear_task_instance_form [989,1013]
===
match
---
simple_stmt [1268,1306]
simple_stmt [1296,1334]
===
match
---
operator: , [3572,3573]
operator: , [3592,3593]
===
match
---
number: 1 [6808,6809]
number: 1 [6820,6821]
===
match
---
atom [6729,7103]
atom [6741,7115]
===
match
---
param [6625,6629]
param [6637,6641]
===
match
---
name: marshmallow [859,870]
name: marshmallow [844,855]
===
match
---
atom_expr [3562,3585]
atom_expr [3582,3605]
===
match
---
name: default_time [1672,1684]
name: default_time [1700,1712]
===
match
---
atom_expr [6255,6273]
atom_expr [6267,6285]
===
match
---
atom [7271,7299]
atom [7283,7311]
===
match
---
number: 100 [1920,1923]
number: 100 [1948,1951]
===
match
---
simple_stmt [1523,1603]
simple_stmt [1551,1631]
===
match
---
name: default_ti_extras [1745,1762]
name: default_ti_extras [1773,1790]
===
match
---
operator: , [3225,3226]
operator: , [3253,3254]
===
match
---
trailer [2439,2443]
trailer [2467,2471]
===
match
---
number: 0 [6814,6815]
number: 0 [6826,6827]
===
match
---
atom_expr [3457,3466]
atom_expr [3477,3486]
===
match
---
simple_stmt [3444,3492]
simple_stmt [3464,3512]
===
match
---
suite [5075,6131]
suite [5087,6143]
===
match
---
arglist [2290,2328]
arglist [2318,2356]
===
match
---
string: "unixname" [4929,4939]
string: "unixname" [4949,4959]
===
match
---
operator: } [6601,6602]
operator: } [6613,6614]
===
match
---
string: "running" [4838,4847]
string: "running" [4858,4867]
===
match
---
number: 10000.0 [3972,3979]
number: 10000.0 [3992,3999]
===
match
---
operator: , [4958,4959]
operator: , [4970,4971]
===
match
---
parameters [6207,6213]
parameters [6219,6225]
===
match
---
dictorsetmaker [3923,4959]
dictorsetmaker [3943,4971]
===
match
---
trailer [6238,6244]
trailer [6250,6256]
===
match
---
argument [3626,3648]
argument [3646,3668]
===
match
---
parameters [3419,3434]
parameters [3439,3454]
===
match
---
operator: , [6812,6813]
operator: , [6824,6825]
===
match
---
atom_expr [7523,7576]
atom_expr [7535,7588]
===
match
---
name: setUp [1409,1414]
name: setUp [1437,1442]
===
match
---
trailer [3863,3868]
trailer [3883,3888]
===
match
---
string: "queued_when" [4400,4413]
string: "queued_when" [4420,4433]
===
match
---
operator: , [3577,3578]
operator: , [3597,3598]
===
match
---
atom [4445,4760]
atom [4465,4780]
===
match
---
operator: = [2495,2496]
operator: = [2523,2524]
===
match
---
expr_stmt [2282,2329]
expr_stmt [2310,2357]
===
match
---
name: airflow [940,947]
name: airflow [925,932]
===
match
---
simple_stmt [3594,3740]
simple_stmt [3614,3760]
===
match
---
string: "max_tries" [4170,4181]
string: "max_tries" [4190,4201]
===
match
---
trailer [2312,2328]
trailer [2340,2356]
===
match
---
name: start_date [1573,1583]
name: start_date [1601,1611]
===
match
---
atom [1765,2039]
atom [1793,2067]
===
match
---
name: setattr [3562,3569]
name: setattr [3582,3589]
===
match
---
suite [7510,7577]
suite [7522,7589]
===
match
---
trailer [1891,1899]
trailer [1919,1927]
===
match
---
atom_expr [1523,1532]
atom_expr [1551,1560]
===
match
---
operator: , [6815,6816]
operator: , [6827,6828]
===
match
---
name: raises [6055,6061]
name: raises [6067,6073]
===
match
---
name: self [1523,1527]
name: self [1551,1555]
===
match
---
name: dag_id [3662,3668]
name: dag_id [3682,3688]
===
match
---
simple_stmt [3772,3794]
simple_stmt [3792,3814]
===
match
---
name: self [3470,3474]
name: self [3490,3494]
===
match
---
string: "reset_dag_runs" [5523,5539]
string: "reset_dag_runs" [5535,5551]
===
match
---
name: load [6678,6682]
name: load [6690,6694]
===
match
---
operator: = [6274,6275]
operator: = [6286,6287]
===
match
---
name: dt [6827,6829]
name: dt [6839,6841]
===
match
---
operator: , [4184,4185]
operator: , [4204,4205]
===
match
---
operator: , [7297,7298]
operator: , [7309,7310]
===
match
---
atom_expr [2497,2534]
atom_expr [2525,2562]
===
match
---
name: self [6683,6687]
name: self [6695,6699]
===
match
---
operator: , [6809,6810]
operator: , [6821,6822]
===
match
---
operator: , [3036,3037]
operator: , [3064,3065]
===
match
---
trailer [6829,6838]
trailer [6841,6850]
===
match
---
operator: , [4249,4250]
operator: , [4269,4270]
===
match
---
with_stmt [2073,2190]
with_stmt [2101,2218]
===
match
---
trailer [6841,6851]
trailer [6853,6863]
===
match
---
string: "end_date" [5571,5581]
string: "end_date" [5583,5593]
===
match
---
name: airflow [1311,1318]
name: airflow [1339,1346]
===
match
---
atom_expr [6174,6191]
atom_expr [6186,6203]
===
match
---
operator: , [6556,6557]
operator: , [6568,6569]
===
match
---
operator: , [3648,3649]
operator: , [3668,3669]
===
match
---
operator: , [3682,3683]
operator: , [3702,3703]
===
match
---
operator: , [1899,1900]
operator: , [1927,1928]
===
match
---
param [1415,1419]
param [1443,1447]
===
match
---
operator: { [3909,3910]
operator: { [3929,3930]
===
match
---
with_stmt [1479,1603]
with_stmt [1507,1631]
===
match
---
string: 'include_downstream' [6879,6899]
string: 'include_downstream' [6891,6911]
===
match
---
trailer [2289,2329]
trailer [2317,2357]
===
match
---
name: expected_result [6711,6726]
name: expected_result [6723,6738]
===
match
---
name: expected_json [3893,3906]
name: expected_json [3913,3926]
===
match
---
import_as_names [1004,1089]
import_as_names [989,1074]
===
match
---
name: self [3457,3461]
name: self [3477,3481]
===
match
---
operator: , [7344,7345]
operator: , [7356,7357]
===
match
---
param [3426,3433]
param [3446,3453]
===
match
---
trailer [7492,7509]
trailer [7504,7521]
===
match
---
trailer [1616,1632]
trailer [1644,1660]
===
match
---
trailer [2384,2386]
trailer [2412,2414]
===
match
---
string: "hostname" [2792,2802]
string: "hostname" [2820,2830]
===
match
---
string: "execution_date" [1649,1665]
string: "execution_date" [1677,1693]
===
match
---
operator: , [4523,4524]
operator: , [4543,4544]
===
match
---
assert_stmt [3317,3354]
assert_stmt [3337,3374]
===
match
---
operator: , [6408,6409]
operator: , [6420,6421]
===
match
---
suite [6193,7577]
suite [6205,7589]
===
match
---
name: TI [1149,1151]
name: TI [1134,1136]
===
match
---
string: "try_number" [3239,3251]
string: "try_number" [3267,3279]
===
match
---
comparison [4985,5015]
comparison [4997,5027]
===
match
---
string: "pool_slots" [4299,4311]
string: "pool_slots" [4319,4331]
===
match
---
dictorsetmaker [1649,1721]
dictorsetmaker [1677,1749]
===
match
---
dictorsetmaker [2573,3298]
dictorsetmaker [2601,3318]
===
match
---
operator: ** [2306,2308]
operator: ** [2334,2336]
===
match
---
suite [3549,3586]
suite [3569,3606]
===
match
---
operator: = [6826,6827]
operator: = [6838,6839]
===
match
---
name: default_ti_extras [3523,3540]
name: default_ti_extras [3543,3560]
===
match
---
param [6019,6024]
param [6031,6036]
===
match
---
with_item [2078,2105]
with_item [2106,2133]
===
match
---
string: "" [4154,4156]
string: "" [4174,4176]
===
match
---
operator: , [4847,4848]
operator: , [4867,4868]
===
match
---
number: 2 [1897,1898]
number: 2 [1925,1926]
===
match
---
expr_stmt [6255,6602]
expr_stmt [6267,6614]
===
match
---
arith_expr [1793,1833]
arith_expr [1821,1861]
===
match
---
operator: , [5255,5256]
operator: , [5267,5268]
===
match
---
operator: , [1833,1834]
operator: , [1861,1862]
===
match
---
string: "start_date" [1779,1791]
string: "start_date" [1807,1819]
===
match
---
name: dummy [1175,1180]
name: dummy [1160,1165]
===
match
---
name: serialized_ti [4985,4998]
name: serialized_ti [4997,5010]
===
match
---
param [6208,6212]
param [6220,6224]
===
match
---
name: raises [7486,7492]
name: raises [7498,7504]
===
match
---
atom_expr [2308,2328]
atom_expr [2336,2356]
===
match
---
name: session [2098,2105]
name: session [2126,2133]
===
match
---
name: dt [6839,6841]
name: dt [6851,6853]
===
match
---
operator: , [3186,3187]
operator: , [3214,3215]
===
match
---
string: "email_sent" [4541,4553]
string: "email_sent" [4561,4573]
===
match
---
operator: , [4760,4761]
operator: , [4780,4781]
===
match
---
number: 2020 [6802,6806]
number: 2020 [6814,6818]
===
match
---
name: serialized_ti [3827,3840]
name: serialized_ti [3847,3860]
===
match
---
name: session [3426,3433]
name: session [3446,3453]
===
match
---
name: default_ti_init [3475,3490]
name: default_ti_init [3495,3510]
===
match
---
name: DAG [1484,1487]
name: DAG [1512,1515]
===
match
---
string: "task_id" [3200,3209]
string: "task_id" [3228,3237]
===
match
---
import_name [786,807]
import_name [786,807]
===
match
---
string: "INVALID_STATE" [7328,7343]
string: "INVALID_STATE" [7340,7355]
===
match
---
operator: , [1466,1467]
operator: , [1494,1495]
===
match
---
simple_stmt [3827,3885]
simple_stmt [3847,3905]
===
match
---
operator: -> [6214,6216]
operator: -> [6226,6228]
===
match
---
atom_expr [3748,3763]
atom_expr [3768,3783]
===
match
---
trailer [2165,2171]
trailer [2193,2199]
===
match
---
name: sla_miss [3594,3602]
name: sla_miss [3614,3622]
===
match
---
string: "max_tries" [2820,2831]
string: "max_tries" [2848,2859]
===
match
---
string: "default_pool" [4271,4285]
string: "default_pool" [4291,4305]
===
match
---
funcdef [6198,6603]
funcdef [6210,6615]
===
match
---
dotted_as_name [793,807]
dotted_as_name [793,807]
===
match
---
string: "default_queue" [2013,2028]
string: "default_queue" [2041,2056]
===
match
---
simple_stmt [6092,6131]
simple_stmt [6104,6143]
===
match
---
name: SlaMiss [3605,3612]
name: SlaMiss [3625,3632]
===
match
---
atom_expr [1813,1833]
atom_expr [1841,1861]
===
match
---
name: expand [5095,5101]
name: expand [5107,5113]
===
match
---
name: parameterized [920,933]
name: parameterized [905,918]
===
match
---
dictorsetmaker [6743,7093]
dictorsetmaker [6755,7105]
===
match
---
number: 1 [1831,1832]
number: 1 [1859,1860]
===
match
---
name: expand [7165,7171]
name: expand [7177,7183]
===
match
---
name: payload [6122,6129]
name: payload [6134,6141]
===
match
---
string: "TEST_TASK_ID" [3211,3225]
string: "TEST_TASK_ID" [3239,3253]
===
match
---
trailer [6851,6854]
trailer [6863,6866]
===
match
---
dictorsetmaker [7273,7296]
dictorsetmaker [7285,7308]
===
match
---
string: "TEST_DAG_ID" [3669,3682]
string: "TEST_DAG_ID" [3689,3702]
===
match
---
operator: = [3907,3908]
operator: = [3927,3928]
===
match
---
operator: { [6729,6730]
operator: { [6741,6742]
===
match
---
operator: , [2875,2876]
operator: , [2903,2904]
===
match
---
expr_stmt [3893,4969]
expr_stmt [3913,4981]
===
match
---
operator: = [1830,1831]
operator: = [1858,1859]
===
match
---
string: 'execution_date' [6772,6788]
string: 'execution_date' [6784,6800]
===
match
---
funcdef [2216,3355]
funcdef [2244,3375]
===
match
---
operator: , [5677,5678]
operator: , [5689,5690]
===
match
---
operator: , [4623,4624]
operator: , [4643,4644]
===
match
---
string: "task_ids" [5902,5912]
string: "task_ids" [5914,5924]
===
match
---
name: parameterized [899,912]
name: parameterized [884,897]
===
match
---
operator: , [4419,4420]
operator: , [4439,4440]
===
match
---
number: 1 [4347,4348]
number: 1 [4367,4368]
===
match
---
atom_expr [6048,6078]
atom_expr [6060,6090]
===
match
---
operator: = [1448,1449]
operator: = [1476,1477]
===
match
---
import_from [1306,1349]
import_from [1334,1377]
===
match
---
decorator [7150,7364]
decorator [7162,7376]
===
match
---
atom [2559,3308]
atom [2587,3328]
===
match
---
name: session [2119,2126]
name: session [2147,2154]
===
match
---
atom_expr [3772,3793]
atom_expr [3792,3813]
===
match
---
name: getuser [4949,4956]
name: getuser [4961,4968]
===
match
---
name: expected_json [5002,5015]
name: expected_json [5014,5027]
===
match
---
name: default_time [3716,3728]
name: default_time [3736,3748]
===
match
---
name: items [2379,2384]
name: items [2407,2412]
===
match
---
arglist [3452,3490]
arglist [3472,3510]
===
match
---
name: key [3504,3507]
name: key [3524,3527]
===
match
---
operator: , [2410,2411]
operator: , [2438,2439]
===
match
---
string: '+0000' [6856,6863]
string: '+0000' [6868,6875]
===
match
---
name: task_id [1549,1556]
name: task_id [1577,1584]
===
match
---
string: "2020-01-02T00:00:00+00:00" [3127,3154]
string: "2020-01-02T00:00:00+00:00" [3155,3182]
===
match
---
trailer [5064,5073]
trailer [5076,5085]
===
match
---
operator: , [4091,4092]
operator: , [4111,4112]
===
match
---
operator: = [3447,3448]
operator: = [3467,3468]
===
match
---
number: 1 [1465,1466]
number: 1 [1493,1494]
===
match
---
operator: , [1720,1721]
operator: , [1748,1749]
===
match
---
name: unittest [6174,6182]
name: unittest [6186,6194]
===
match
---
simple_stmt [3802,3819]
simple_stmt [3822,3839]
===
match
---
dotted_name [1207,1228]
dotted_name [1235,1256]
===
match
---
expr_stmt [2481,2534]
expr_stmt [2509,2562]
===
match
---
name: datetime [6793,6801]
name: datetime [6805,6813]
===
match
---
name: self [1415,1419]
name: self [1443,1447]
===
match
---
operator: , [4156,4157]
operator: , [4176,4177]
===
match
---
atom_expr [6649,6702]
atom_expr [6661,6714]
===
match
---
string: "start_date" [3113,3125]
string: "start_date" [3141,3153]
===
match
---
dictorsetmaker [6290,6592]
dictorsetmaker [6302,6604]
===
match
---
comparison [3324,3354]
comparison [3344,3374]
===
match
---
simple_stmt [1202,1268]
simple_stmt [1230,1296]
===
match
---
with_stmt [6043,6131]
with_stmt [6055,6143]
===
match
---
operator: , [4560,4561]
operator: , [4580,4581]
===
match
---
atom_expr [2078,2094]
atom_expr [2106,2122]
===
match
---
decorated [2195,3355]
decorated [2223,3375]
===
match
---
operator: , [5300,5301]
operator: , [5312,5313]
===
match
---
name: pytest [7479,7485]
name: pytest [7491,7497]
===
match
---
funcdef [6608,7145]
funcdef [6620,7157]
===
match
---
trailer [6687,6701]
trailer [6699,6713]
===
match
---
operator: @ [3360,3361]
operator: @ [3380,3381]
===
match
---
trailer [2299,2304]
trailer [2327,2332]
===
match
---
dictorsetmaker [5481,5678]
dictorsetmaker [5493,5690]
===
match
---
dotted_name [1273,1292]
dotted_name [1301,1320]
===
match
---
import_from [1268,1305]
import_from [1296,1333]
===
match
---
import_from [894,933]
import_from [879,918]
===
match
---
argument [3696,3728]
argument [3716,3748]
===
match
---
name: days [1826,1830]
name: days [1854,1858]
===
match
---
atom_expr [3449,3491]
atom_expr [3469,3511]
===
match
---
simple_stmt [2432,2448]
simple_stmt [2460,2476]
===
match
---
name: test_task_instance_schema_with_sla [3385,3419]
name: test_task_instance_schema_with_sla [3405,3439]
===
match
---
operator: , [3254,3255]
operator: , [3282,3283]
===
match
---
operator: , [4386,4387]
operator: , [4406,4407]
===
match
---
operator: , [5916,5917]
operator: , [5928,5929]
===
match
---
atom_expr [1707,1720]
atom_expr [1735,1748]
===
match
---
name: self [1793,1797]
name: self [1821,1825]
===
match
---
operator: { [5165,5166]
operator: { [5177,5178]
===
match
---
name: task_instance_schema [970,990]
name: task_instance_schema [955,975]
===
match
---
name: tearDown [2049,2057]
name: tearDown [2077,2085]
===
match
---
operator: , [4348,4349]
operator: , [4368,4369]
===
match
---
name: dt [6790,6792]
name: dt [6802,6804]
===
match
---
string: "include_past" [6536,6550]
string: "include_past" [6548,6562]
===
match
---
param [7400,7413]
param [7412,7425]
===
match
---
name: ti [3760,3762]
name: ti [3780,3782]
===
match
---
string: "foo" [7249,7254]
string: "foo" [7261,7266]
===
match
---
arglist [6839,6863]
arglist [6851,6875]
===
match
---
operator: , [1990,1991]
operator: , [2018,2019]
===
match
---
arglist [3570,3584]
arglist [3590,3604]
===
match
---
funcdef [5993,6131]
funcdef [6005,6143]
===
match
---
name: self [2295,2299]
name: self [2323,2327]
===
match
---
string: "execution_date" [4578,4594]
string: "execution_date" [4598,4614]
===
match
---
expr_stmt [1430,1470]
expr_stmt [1458,1498]
===
match
---
string: "duration" [3960,3970]
string: "duration" [3980,3990]
===
match
---
operator: { [7196,7197]
operator: { [7208,7209]
===
match
---
operator: , [2415,2416]
operator: , [2443,2444]
===
match
---
string: "default_pool" [2921,2935]
string: "default_pool" [2949,2963]
===
match
---
param [7394,7399]
param [7406,7411]
===
match
---
import_name [823,838]
import_name [808,823]
===
match
---
testlist_comp [7195,7347]
testlist_comp [7207,7359]
===
match
---
name: payload [6025,6032]
name: payload [6037,6044]
===
match
---
string: "hostname" [4142,4152]
string: "hostname" [4162,4172]
===
match
---
atom [7196,7213]
atom [7208,7225]
===
match
---
name: self [7557,7561]
name: self [7569,7573]
===
match
---
name: dt [1813,1815]
name: dt [1841,1843]
===
match
---
trailer [2360,2378]
trailer [2388,2406]
===
match
---
name: ti [2524,2526]
name: ti [2552,2554]
===
match
---
operator: , [3946,3947]
operator: , [3966,3967]
===
match
---
trailer [7556,7576]
trailer [7568,7588]
===
match
---
string: "only_running" [5326,5340]
string: "only_running" [5338,5352]
===
match
---
trailer [3461,3466]
trailer [3481,3486]
===
match
---
operator: , [5828,5829]
operator: , [5840,5841]
===
match
---
name: airflow [1097,1104]
name: airflow [1082,1089]
===
match
---
testlist_comp [2524,2532]
testlist_comp [2552,2560]
===
match
---
name: add [3780,3783]
name: add [3800,3803]
===
match
---
suite [7415,7577]
suite [7427,7589]
===
match
---
string: "dag_id" [2573,2581]
string: "dag_id" [2601,2609]
===
match
---
name: TI [2133,2135]
name: TI [2161,2163]
===
match
---
name: TI [2287,2289]
name: TI [2315,2317]
===
match
---
operator: } [3307,3308]
operator: } [3327,3328]
===
match
---
string: "state" [4829,4836]
string: "state" [4849,4856]
===
match
---
operator: + [1811,1812]
operator: + [1839,1840]
===
match
---
name: task [1528,1532]
name: task [1556,1560]
===
match
---
name: State [1300,1305]
name: State [1328,1333]
===
match
---
string: 'failed' [7040,7048]
string: 'failed' [7052,7060]
===
match
---
name: utils [1281,1286]
name: utils [1309,1314]
===
match
---
operator: } [1730,1731]
operator: } [1758,1759]
===
match
---
for_stmt [2338,2424]
for_stmt [2366,2452]
===
match
---
suite [6079,6131]
suite [6091,6143]
===
match
---
operator: = [1583,1584]
operator: = [1611,1612]
===
match
---
name: default_time [1864,1876]
name: default_time [1892,1904]
===
match
---
string: "DummyOperator" [4210,4225]
string: "DummyOperator" [4230,4245]
===
match
---
trailer [2407,2423]
trailer [2435,2451]
===
match
---
operator: , [6865,6866]
operator: , [6877,6878]
===
match
---
number: 10000.0 [2622,2629]
number: 10000.0 [2650,2657]
===
match
---
trailer [6682,6702]
trailer [6694,6714]
===
match
---
operator: , [7257,7258]
operator: , [7269,7270]
===
match
---
name: task [3452,3456]
name: task [3472,3476]
===
match
---
atom_expr [2432,2447]
atom_expr [2460,2475]
===
match
---
name: default_ti_extras [2361,2378]
name: default_ti_extras [2389,2406]
===
match
---
string: "duration" [2610,2620]
string: "duration" [2638,2648]
===
match
---
operator: , [6591,6592]
operator: , [6603,6604]
===
match
---
string: 'include_future' [6919,6935]
string: 'include_future' [6931,6947]
===
match
---
operator: , [4032,4033]
operator: , [4052,4053]
===
match
---
suite [1400,5016]
suite [1428,5028]
===
match
---
trailer [6116,6121]
trailer [6128,6133]
===
match
---
operator: == [4999,5001]
operator: == [5011,5013]
===
match
---
dotted_name [5081,5101]
dotted_name [5093,5113]
===
match
---
name: dump [2518,2522]
name: dump [2546,2550]
===
match
---
simple_stmt [2119,2146]
simple_stmt [2147,2174]
===
match
---
operator: , [4915,4916]
operator: , [4935,4936]
===
match
---
string: "dry_run" [5191,5200]
string: "dry_run" [5203,5212]
===
match
---
string: "execution_date" [4046,4062]
string: "execution_date" [4066,4082]
===
match
---
name: setUp [6239,6244]
name: setUp [6251,6256]
===
match
---
suite [6034,6131]
suite [6046,6143]
===
match
---
atom_expr [7424,7464]
atom_expr [7436,7476]
===
match
---
trailer [2187,2189]
trailer [2215,2217]
===
match
---
string: "dry_run" [5812,5821]
string: "dry_run" [5824,5833]
===
match
---
argument [1892,1898]
argument [1920,1926]
===
match
---
name: RUNNING [1713,1720]
name: RUNNING [1741,1748]
===
match
---
operator: , [3466,3467]
operator: , [3486,3487]
===
match
---
operator: = [1896,1897]
operator: = [1924,1925]
===
match
---
simple_stmt [1092,1152]
simple_stmt [1077,1137]
===
match
---
string: "only_failed" [5281,5294]
string: "only_failed" [5293,5306]
===
match
---
import_from [1092,1151]
import_from [1077,1136]
===
match
---
import_from [935,1091]
import_from [920,1076]
===
match
---
operator: , [2834,2835]
operator: , [2862,2863]
===
match
---
dotted_name [940,990]
dotted_name [925,975]
===
match
---
operator: , [5401,5402]
operator: , [5413,5414]
===
match
---
string: "TEST_TASK_ID" [3634,3648]
string: "TEST_TASK_ID" [3654,3668]
===
match
---
param [2264,2271]
param [2292,2299]
===
match
---
name: pytest [6048,6054]
name: pytest [6060,6066]
===
match
---
expr_stmt [6640,6702]
expr_stmt [6652,6714]
===
match
---
operator: } [4968,4969]
operator: } [4980,4981]
===
match
---
string: "executor_config" [2755,2772]
string: "executor_config" [2783,2800]
===
match
---
name: setUp [6202,6207]
name: setUp [6214,6219]
===
match
---
operator: } [2038,2039]
operator: } [2066,2067]
===
match
---
atom [3869,3883]
atom [3889,3903]
===
match
---
name: timedelta [1882,1891]
name: timedelta [1910,1919]
===
match
---
trailer [3546,3548]
trailer [3566,3568]
===
match
---
string: "state" [3168,3175]
string: "state" [3196,3203]
===
match
---
simple_stmt [6255,6603]
simple_stmt [6267,6615]
===
match
---
operator: , [2345,2346]
operator: , [2373,2374]
===
match
---
trailer [2171,2180]
trailer [2199,2208]
===
match
---
operator: , [4285,4286]
operator: , [4305,4306]
===
match
---
simple_stmt [3748,3764]
simple_stmt [3768,3784]
===
match
---
dictorsetmaker [4463,4746]
dictorsetmaker [4483,4766]
===
match
---
name: self [3711,3715]
name: self [3731,3735]
===
match
---
atom_expr [3605,3739]
atom_expr [3625,3759]
===
match
---
exprlist [2342,2352]
exprlist [2370,2380]
===
match
---
suite [2387,2424]
suite [2415,2452]
===
match
---
operator: , [3297,3298]
operator: , [3317,3318]
===
match
---
param [6025,6032]
param [6037,6044]
===
match
---
name: airflow [1273,1280]
name: airflow [1301,1308]
===
match
---
testlist_comp [7314,7345]
testlist_comp [7326,7357]
===
match
---
simple_stmt [7523,7577]
simple_stmt [7535,7589]
===
match
---
operator: @ [7150,7151]
operator: @ [7162,7163]
===
match
---
operator: , [3424,3425]
operator: , [3444,3445]
===
match
---
atom [5786,5939]
atom [5798,5951]
===
match
---
number: 0 [4914,4915]
number: 0 [4934,4935]
===
match
---
import_from [1202,1267]
import_from [1230,1295]
===
match
---
operator: , [6305,6306]
operator: , [6317,6318]
===
match
---
name: self [1584,1588]
name: self [1612,1616]
===
match
---
name: timedelta [6842,6851]
name: timedelta [6854,6863]
===
match
---
string: "print_the_context" [6330,6349]
string: "print_the_context" [6342,6361]
===
match
---
atom [5111,5982]
atom [5123,5994]
===
match
---
name: value [3509,3514]
name: value [3529,3534]
===
match
---
simple_stmt [840,854]
simple_stmt [825,839]
===
match
---
name: override_data [7450,7463]
name: override_data [7462,7475]
===
match
---
number: 0 [6817,6818]
number: 0 [6829,6830]
===
match
---
trailer [7428,7442]
trailer [7440,7454]
===
match
---
name: parameterized [7151,7164]
name: parameterized [7163,7176]
===
match
---
operator: , [2526,2527]
operator: , [2554,2555]
===
match
---
atom [5433,5718]
atom [5445,5730]
===
match
---
operator: { [7314,7315]
operator: { [7326,7327]
===
match
---
atom_expr [4941,4958]
atom_expr [4961,4970]
===
match
---
argument [6820,6864]
argument [6832,6876]
===
match
---
operator: , [2028,2029]
operator: , [2056,2057]
===
match
---
atom_expr [1612,1632]
atom_expr [1640,1660]
===
match
---
name: dt [1879,1881]
name: dt [1907,1909]
===
match
---
operator: , [2682,2683]
operator: , [2710,2711]
===
match
---
operator: , [6522,6523]
operator: , [6534,6535]
===
match
---
atom [7181,7357]
atom [7193,7369]
===
match
---
name: dump [3864,3868]
name: dump [3884,3888]
===
match
---
simple_stmt [935,1092]
simple_stmt [920,1077]
===
match
---
string: "pool" [1968,1974]
string: "pool" [1996,2002]
===
match
---
atom_expr [1430,1447]
atom_expr [1458,1475]
===
match
---
string: "end_date" [1847,1857]
string: "end_date" [1875,1885]
===
match
---
name: session [2432,2439]
name: session [2460,2467]
===
match
---
string: "pid" [4239,4244]
string: "pid" [4259,4264]
===
match
---
atom_expr [1667,1684]
atom_expr [1695,1712]
===
match
---
name: self [2308,2312]
name: self [2336,2340]
===
match
---
name: self [1430,1434]
name: self [1458,1462]
===
match
---
operator: , [3099,3100]
operator: , [3127,3128]
===
match
---
operator: , [7048,7049]
operator: , [7060,7061]
===
match
---
simple_stmt [3317,3355]
simple_stmt [3337,3375]
===
match
---
argument [1549,1571]
argument [1577,1599]
===
match
---
operator: , [6975,6976]
operator: , [6987,6988]
===
match
---
name: task [2300,2304]
name: task [2328,2332]
===
match
---
name: default_time [1798,1810]
name: default_time [1826,1838]
===
match
---
operator: , [1062,1063]
operator: , [1047,1048]
===
match
---
name: add [3756,3759]
name: add [3776,3779]
===
match
---
operator: = [2285,2286]
operator: = [2313,2314]
===
match
---
string: "dry_run" [6290,6299]
string: "dry_run" [6302,6311]
===
match
---
name: self [6208,6212]
name: self [6220,6224]
===
match
---
operator: , [6349,6350]
operator: , [6361,6362]
===
match
---
string: "2020-01-02T00:00:00+00:00" [4788,4815]
string: "2020-01-02T00:00:00+00:00" [4808,4835]
===
match
---
string: "duration" [1937,1947]
string: "duration" [1965,1975]
===
match
---
name: unittest [830,838]
name: unittest [815,823]
===
match
---
simple_stmt [2481,2535]
simple_stmt [2509,2563]
===
match
---
exprlist [3504,3514]
exprlist [3524,3534]
===
match
---
name: set_task_instance_state_form [1034,1062]
name: set_task_instance_state_form [1019,1047]
===
match
---
trailer [2143,2145]
trailer [2171,2173]
===
match
---
name: TestCase [1390,1398]
name: TestCase [1418,1426]
===
match
---
atom_expr [6092,6130]
atom_expr [6104,6142]
===
match
---
string: "reset_dag_runs" [5854,5870]
string: "reset_dag_runs" [5866,5882]
===
match
---
name: task_instance_schema [1068,1088]
name: task_instance_schema [1053,1073]
===
match
---
string: "pool" [4263,4269]
string: "pool" [4283,4289]
===
match
---
name: default_ti_init [2313,2328]
name: default_ti_init [2341,2356]
===
match
---
import_as_names [1119,1151]
import_as_names [1104,1136]
===
match
---
name: DAG [1119,1122]
name: DAG [1104,1107]
===
match
---
operator: { [2559,2560]
operator: { [2587,2588]
===
match
---
operator: , [1088,1089]
operator: , [1073,1074]
===
match
---
name: update [7443,7449]
name: update [7455,7461]
===
match
---
funcdef [2045,2190]
funcdef [2073,2218]
===
match
---
parameters [6018,6033]
parameters [6030,6045]
===
match
---
string: "2020-01-01T00:00:00+00:00" [4596,4623]
string: "2020-01-01T00:00:00+00:00" [4616,4643]
===
match
---
atom [2523,2533]
atom [2551,2561]
===
match
---
operator: } [7254,7255]
operator: } [7266,7267]
===
match
---
decorated [3360,5016]
decorated [3380,5028]
===
match
---
name: TestSetTaskInstanceStateFormSchema [6139,6173]
name: TestSetTaskInstanceStateFormSchema [6151,6185]
===
match
---
parameters [2257,2272]
parameters [2285,2300]
===
match
---
atom_expr [1859,1876]
atom_expr [1887,1904]
===
match
---
name: default_time [1435,1447]
name: default_time [1463,1475]
===
match
---
trailer [1548,1602]
trailer [1576,1630]
===
match
---
simple_stmt [1612,1732]
simple_stmt [1640,1760]
===
match
---
name: models [1105,1111]
name: models [1090,1096]
===
match
---
operator: , [2806,2807]
operator: , [2834,2835]
===
match
---
string: 'dry_run' [6743,6752]
string: 'dry_run' [6755,6764]
===
match
---
name: session [3748,3755]
name: session [3768,3775]
===
match
---
name: self [2058,2062]
name: self [2086,2090]
===
match
---
classdef [1352,5016]
classdef [1380,5028]
===
match
---
string: "start_date" [4774,4786]
string: "start_date" [4794,4806]
===
match
---
name: self [1667,1671]
name: self [1695,1699]
===
match
---
string: "" [2804,2806]
string: "" [2832,2834]
===
match
---
string: 'task_id' [7062,7071]
string: 'task_id' [7074,7083]
===
match
---
atom_expr [1381,1398]
atom_expr [1409,1426]
===
match
---
atom_expr [1879,1899]
atom_expr [1907,1927]
===
match
---
operator: , [4486,4487]
operator: , [4506,4507]
===
match
---
atom_expr [2356,2386]
atom_expr [2384,2414]
===
match
---
operator: , [6854,6855]
operator: , [6866,6867]
===
match
---
name: test_task_instance_schema_without_sla [2220,2257]
name: test_task_instance_schema_without_sla [2248,2285]
===
match
---
atom_expr [3280,3297]
atom_expr [3308,3317]
===
match
---
name: key [2342,2345]
name: key [2370,2373]
===
match
---
operator: , [5971,5972]
operator: , [5983,5984]
===
match
---
operator: , [6486,6487]
operator: , [6498,6499]
===
match
---
atom_expr [3843,3884]
atom_expr [3863,3904]
===
match
---
number: 1 [2963,2964]
number: 1 [2991,2992]
===
match
---
dictorsetmaker [7197,7212]
dictorsetmaker [7209,7224]
===
match
---
name: delete [2137,2143]
name: delete [2165,2171]
===
match
---
name: ValidationError [878,893]
name: ValidationError [863,878]
===
match
---
decorator [5080,5989]
decorator [5092,6001]
===
match
---
trailer [3569,3585]
trailer [3589,3605]
===
match
---
string: "DummyOperator" [2860,2875]
string: "DummyOperator" [2888,2903]
===
match
---
operator: , [1463,1464]
operator: , [1491,1492]
===
match
---
suite [2273,3355]
suite [2301,3375]
===
match
---
operator: , [6806,6807]
operator: , [6818,6819]
===
match
---
trailer [3451,3491]
trailer [3471,3511]
===
match
---
name: query [2166,2171]
name: query [2194,2199]
===
match
---
trailer [7561,7575]
trailer [7573,7587]
===
match
---
trailer [3755,3759]
trailer [3775,3779]
===
match
---
trailer [2180,2187]
trailer [2208,2215]
===
match
---
funcdef [7368,7577]
funcdef [7380,7589]
===
match
---
import_as_names [1236,1267]
import_as_names [1264,1295]
===
match
---
name: SlaMiss [1124,1131]
name: SlaMiss [1109,1116]
===
match
---
trailer [6054,6061]
trailer [6066,6073]
===
match
---
name: ValidationError [7493,7508]
name: ValidationError [7505,7520]
===
match
---
argument [3468,3490]
argument [3488,3510]
===
match
---
trailer [3540,3546]
trailer [3560,3566]
===
match
---
string: "failed" [6583,6591]
string: "failed" [6595,6603]
===
match
---
name: ti [2282,2284]
name: ti [2310,2312]
===
match
---
simple_stmt [7424,7465]
simple_stmt [7436,7477]
===
match
---
atom_expr [1450,1470]
atom_expr [1478,1498]
===
match
---
name: task_instance_schema [3843,3863]
name: task_instance_schema [3863,3883]
===
match
---
atom_expr [2400,2423]
atom_expr [2428,2451]
===
match
---
string: "queue" [3012,3019]
string: "queue" [3040,3047]
===
match
---
atom [7229,7257]
atom [7241,7269]
===
match
---
simple_stmt [2158,2190]
simple_stmt [2186,2218]
===
match
---
atom_expr [6790,6865]
atom_expr [6802,6877]
===
match
---
name: SlaMiss [2172,2179]
name: SlaMiss [2200,2207]
===
match
---
operator: { [7272,7273]
operator: { [7284,7285]
===
match
---
name: ti [2408,2410]
name: ti [2436,2438]
===
match
---
atom_expr [1584,1601]
atom_expr [1612,1629]
===
match
---
name: utils [1215,1220]
name: utils [1243,1248]
===
match
---
string: "description" [4504,4517]
string: "description" [4524,4537]
===
match
---
trailer [2126,2132]
trailer [2154,2160]
===
match
---
string: "unixname" [3268,3278]
string: "unixname" [3296,3306]
===
match
---
string: "pid" [2889,2894]
string: "pid" [2917,2922]
===
match
---
name: create_session [2078,2092]
name: create_session [2106,2120]
===
match
---
number: 1 [6811,6812]
number: 1 [6823,6824]
===
match
---
string: "TEST_DAG_ID" [3933,3946]
string: "TEST_DAG_ID" [3953,3966]
===
match
---
trailer [1671,1684]
trailer [1699,1712]
===
match
---
operator: == [7135,7137]
operator: == [7147,7149]
===
match
---
name: schemas [962,969]
name: schemas [947,954]
===
match
---
trailer [6677,6682]
trailer [6689,6694]
===
match
---
trailer [1588,1601]
trailer [1616,1629]
===
match
---
name: timezone [1325,1333]
name: timezone [1353,1361]
===
match
---
number: 1 [1468,1469]
number: 1 [1496,1497]
===
match
---
name: ti [3870,3872]
name: ti [3890,3892]
===
match
---
decorator [3360,3377]
decorator [3380,3397]
===
match
---
trailer [1825,1833]
trailer [1853,1861]
===
match
---
name: expected_json [3341,3354]
name: expected_json [3361,3374]
===
match
---
parameters [1414,1420]
parameters [1442,1448]
===
match
---
operator: { [4445,4446]
operator: { [4465,4466]
===
match
---
name: session [2264,2271]
name: session [2292,2299]
===
match
---
name: self [6625,6629]
name: self [6637,6641]
===
match
---
atom [5125,5401]
atom [5137,5413]
===
match
---
atom_expr [5056,5073]
atom_expr [5068,5085]
===
match
---
trailer [7449,7464]
trailer [7461,7476]
===
match
---
operator: , [3872,3873]
operator: , [3892,3893]
===
match
---
name: current_input [6688,6701]
name: current_input [6700,6713]
===
match
---
name: task_id [3626,3633]
name: task_id [3646,3653]
===
match
---
operator: , [3154,3155]
operator: , [3182,3183]
===
match
---
name: airflow [1157,1164]
name: airflow [1142,1149]
===
match
---
name: self [6255,6259]
name: self [6267,6271]
===
match
---
trailer [2132,2136]
trailer [2160,2164]
===
match
---
atom_expr [3711,3728]
atom_expr [3731,3748]
===
match
---
operator: , [2629,2630]
operator: , [2657,2658]
===
match
---
operator: = [1633,1634]
operator: = [1661,1662]
===
match
---
name: ti [3570,3572]
name: ti [3590,3592]
===
match
---
string: "timestamp" [4728,4739]
string: "timestamp" [4748,4759]
===
match
---
name: set_task_instance_state_form [7523,7551]
name: set_task_instance_state_form [7535,7563]
===
match
---
name: items [3541,3546]
name: items [3561,3566]
===
match
---
operator: , [5346,5347]
operator: , [5358,5359]
===
match
---
string: "dry_run" [5481,5490]
string: "dry_run" [5493,5502]
===
match
---
string: 'include_past' [6955,6969]
string: 'include_past' [6967,6981]
===
match
---
atom_expr [7557,7575]
atom_expr [7569,7587]
===
match
---
expr_stmt [1612,1731]
expr_stmt [1640,1759]
===
match
---
simple_stmt [2456,2473]
simple_stmt [2484,2501]
===
match
---
name: expected_result [7119,7134]
name: expected_result [7131,7146]
===
match
---
atom [5143,5387]
atom [5155,5399]
===
match
---
name: utils [1319,1324]
name: utils [1347,1352]
===
match
---
name: ValidationError [6062,6077]
name: ValidationError [6074,6089]
===
match
---
funcdef [1405,2040]
funcdef [1433,2068]
===
match
---
operator: , [3728,3729]
operator: , [3748,3749]
===
match
---
name: self [1859,1863]
name: self [1887,1891]
===
match
---
operator: , [1122,1123]
operator: , [1107,1108]
===
match
---
trailer [3715,3728]
trailer [3735,3748]
===
match
---
dotted_name [1311,1333]
dotted_name [1339,1361]
===
match
---
string: "2020-01-01T00:00:00+00:00" [5583,5610]
string: "2020-01-01T00:00:00+00:00" [5595,5622]
===
match
---
import_as_name [1133,1151]
import_as_name [1118,1136]
===
match
---
comparison [7119,7144]
comparison [7131,7156]
===
match
---
trailer [1815,1825]
trailer [1843,1853]
===
match
---
name: TestCase [5065,5073]
name: TestCase [5077,5085]
===
match
---
operator: , [6758,6759]
operator: , [6770,6771]
===
match
---
string: "running" [3177,3186]
string: "running" [3205,3214]
===
match
---
name: state [1287,1292]
name: state [1315,1320]
===
match
---
operator: , [4710,4711]
operator: , [4730,4731]
===
match
---
operator: , [4225,4226]
operator: , [4245,4246]
===
match
---
string: "TEST_DAG_ID" [4473,4486]
string: "TEST_DAG_ID" [4493,4506]
===
match
---
trailer [3816,3818]
trailer [3836,3838]
===
match
---
simple_stmt [1306,1350]
simple_stmt [1334,1378]
===
match
---
string: "pid" [1913,1918]
string: "pid" [1941,1946]
===
match
---
name: sla_miss [3784,3792]
name: sla_miss [3804,3812]
===
match
---
suite [1510,1603]
suite [1538,1631]
===
match
---
operator: , [7013,7014]
operator: , [7025,7026]
===
match
---
name: self [7394,7398]
name: self [7406,7410]
===
match
---
atom [5914,5916]
atom [5926,5928]
===
match
---
name: setattr [2400,2407]
name: setattr [2428,2435]
===
match
---
trailer [1797,1810]
trailer [1825,1838]
===
match
---
name: super [6231,6236]
name: super [6243,6248]
===
match
---
name: ti [3444,3446]
name: ti [3464,3466]
===
match
---
operator: , [7398,7399]
operator: , [7410,7411]
===
match
---
name: TestCase [6183,6191]
name: TestCase [6195,6203]
===
match
---
trailer [2443,2447]
trailer [2471,2475]
===
match
---
string: "{}" [2774,2778]
string: "{}" [2802,2806]
===
match
---
name: commit [3810,3816]
name: commit [3830,3836]
===
match
---
string: "dag_id" [3923,3931]
string: "dag_id" [3943,3951]
===
match
---
operator: , [4886,4887]
operator: , [4906,4907]
===
match
---
string: "reset_dag_runs" [5233,5249]
string: "reset_dag_runs" [5245,5261]
===
match
---
simple_stmt [894,934]
simple_stmt [879,919]
===
match
---
name: DummyOperator [1535,1548]
name: DummyOperator [1563,1576]
===
match
---
string: "queue" [4362,4369]
string: "queue" [4382,4389]
===
match
---
expr_stmt [2543,3308]
expr_stmt [2571,3328]
===
match
---
simple_stmt [7112,7145]
simple_stmt [7124,7157]
===
match
---
name: dag_id [1488,1494]
name: dag_id [1516,1522]
===
match
---
arglist [6802,6864]
arglist [6814,6876]
===
match
---
assert_stmt [4978,5015]
assert_stmt [4990,5027]
===
match
---
name: session [3772,3779]
name: session [3792,3799]
===
match
---
simple_stmt [2282,2330]
simple_stmt [2310,2358]
===
match
---
number: 1 [4313,4314]
number: 1 [4333,4334]
===
match
---
testlist_comp [7272,7298]
testlist_comp [7284,7310]
===
match
---
string: "TEST_TASK_ID" [4872,4886]
string: "TEST_TASK_ID" [4892,4906]
===
match
---
string: "execution_date" [7273,7289]
string: "execution_date" [7285,7301]
===
match
---
operator: , [6446,6447]
operator: , [6458,6459]
===
match
---
trailer [2522,2534]
trailer [2550,2562]
===
match
---
atom_expr [7479,7509]
atom_expr [7491,7521]
===
match
---
operator: @ [2195,2196]
operator: @ [2223,2224]
===
match
---
classdef [5018,6131]
classdef [5030,6143]
===
match
---
name: current_input [7562,7575]
name: current_input [7574,7587]
===
match
---
operator: , [7215,7216]
operator: , [7227,7228]
===
match
---
atom_expr [1793,1810]
atom_expr [1821,1838]
===
match
---
suite [6631,7145]
suite [6643,7157]
===
match
---
operator: = [3603,3604]
operator: = [3623,3624]
===
match
---
operator: , [2778,2779]
operator: , [2806,2807]
===
match
---
param [2058,2062]
param [2086,2090]
===
match
---
trailer [6801,6865]
trailer [6813,6877]
===
match
---
simple_stmt [2543,3309]
simple_stmt [2571,3329]
===
match
---
simple_stmt [786,808]
simple_stmt [786,808]
===
match
---
number: 100 [2896,2899]
number: 100 [2924,2927]
===
match
---
name: timedelta [1816,1825]
name: timedelta [1844,1853]
===
match
---
operator: + [1877,1878]
operator: + [1905,1906]
===
match
---
atom [5415,5732]
atom [5427,5744]
===
match
---
atom_expr [6827,6864]
atom_expr [6839,6876]
===
match
---
string: 'print_the_context' [7073,7092]
string: 'print_the_context' [7085,7104]
===
match
---
trailer [6244,6246]
trailer [6256,6258]
===
match
---
operator: { [5786,5787]
operator: { [5798,5799]
===
match
---
operator: = [3456,3457]
operator: = [3476,3477]
===
match
---
trailer [3522,3540]
trailer [3542,3560]
===
match
---
atom [7314,7344]
atom [7326,7356]
===
match
---
expr_stmt [1523,1602]
expr_stmt [1551,1630]
===
match
---
trailer [3295,3297]
trailer [3315,3317]
===
match
---
trailer [2136,2143]
trailer [2164,2171]
===
match
---
parameters [7393,7414]
parameters [7405,7426]
===
match
---
name: api_connexion [948,961]
name: api_connexion [933,946]
===
match
---
dictorsetmaker [5812,5917]
dictorsetmaker [5824,5929]
===
match
---
simple_stmt [3893,4970]
simple_stmt [3913,4982]
===
match
---
atom [7272,7297]
atom [7284,7309]
===
match
---
operator: { [1635,1636]
operator: { [1663,1664]
===
match
---
operator: = [1556,1557]
operator: = [1584,1585]
===
match
---
operator: , [1923,1924]
operator: , [1951,1952]
===
match
---
atom [5746,5971]
atom [5758,5983]
===
match
---
name: key [2412,2415]
name: key [2440,2443]
===
match
---
operator: , [5876,5877]
operator: , [5888,5889]
===
match
---
string: "start_date" [5636,5648]
string: "start_date" [5648,5660]
===
match
---
string: "queue" [2004,2011]
string: "queue" [2032,2039]
===
match
---
name: override_data [7400,7413]
name: override_data [7412,7425]
===
match
---
operator: , [1684,1685]
operator: , [1712,1713]
===
match
---
string: "include_downstream" [6460,6480]
string: "include_downstream" [6472,6492]
===
match
---
string: "task_id" [7197,7206]
string: "task_id" [7209,7218]
===
match
---
string: 'include_upstream' [6989,7007]
string: 'include_upstream' [7001,7019]
===
match
---
atom_expr [6231,6246]
atom_expr [6243,6258]
===
match
---
name: self [7424,7428]
name: self [7436,7440]
===
match
---
string: "{}" [4124,4128]
string: "{}" [4144,4148]
===
match
---
atom [7313,7346]
atom [7325,7358]
===
match
---
decorated [5080,6131]
decorated [5092,6143]
===
match
---
simple_stmt [6231,6247]
simple_stmt [6243,6259]
===
match
---
import_from [1152,1201]
import_from [1137,1186]
===
match
---
arglist [2408,2422]
arglist [2436,2450]
===
match
---
name: commit [2464,2470]
name: commit [2492,2498]
===
match
---
name: set_task_instance_state_form [6649,6677]
name: set_task_instance_state_form [6661,6689]
===
match
---
trailer [1744,1762]
trailer [1772,1790]
===
match
---
string: "default_queue" [4371,4386]
string: "default_queue" [4391,4406]
===
match
---
dotted_name [7151,7171]
dotted_name [7163,7183]
===
match
---
operator: , [2596,2597]
operator: , [2624,2625]
===
match
---
operator: = [6727,6728]
operator: = [6739,6740]
===
match
---
operator: } [5938,5939]
operator: } [5950,5951]
===
match
---
name: result [7138,7144]
name: result [7150,7156]
===
match
---
number: 1 [2997,2998]
number: 1 [3025,3026]
===
match
---
name: value [2417,2422]
name: value [2445,2450]
===
match
---
string: "include_future" [6500,6516]
string: "include_future" [6512,6528]
===
match
---
operator: , [7299,7300]
operator: , [7311,7312]
===
match
---
name: TestClearTaskInstanceFormSchema [5024,5055]
name: TestClearTaskInstanceFormSchema [5036,5067]
===
match
---
name: session [2456,2463]
name: session [2484,2491]
===
match
---
name: datetime [793,801]
name: datetime [793,801]
===
match
---
string: "task_id" [4861,4870]
string: "task_id" [4881,4890]
===
match
---
atom_expr [2295,2304]
atom_expr [2323,2332]
===
match
---
operator: , [7255,7256]
operator: , [7267,7268]
===
match
---
trailer [6259,6273]
trailer [6271,6285]
===
match
---
name: execution_date [3696,3710]
name: execution_date [3716,3730]
===
match
---
string: "notification_sent" [4641,4660]
string: "notification_sent" [4661,4680]
===
match
---
name: TI [3449,3451]
name: TI [3469,3471]
===
match
---
trailer [3474,3490]
trailer [3494,3510]
===
match
---
string: "NOW" [7291,7296]
string: "NOW" [7303,7308]
===
match
---
name: session [2158,2165]
name: session [2186,2193]
===
match
---
atom [5165,5369]
atom [5177,5381]
===
match
---
operator: , [6905,6906]
operator: , [6917,6918]
===
match
---
operator: = [2294,2295]
operator: = [2322,2323]
===
match
---
operator: , [6818,6819]
operator: , [6830,6831]
===
match
---
trailer [1487,1509]
trailer [1515,1537]
===
match
---
name: days [1892,1896]
name: days [1920,1924]
===
match
---
operator: , [2935,2936]
operator: , [2963,2964]
===
match
---
operator: , [4667,4668]
operator: , [4687,4688]
===
match
---
dotted_name [1097,1111]
dotted_name [1082,1096]
===
match
---
operator: , [3979,3980]
operator: , [3999,4000]
===
match
---
operator: , [4815,4816]
operator: , [4835,4836]
===
match
---
name: clear_task_instance_form [6092,6116]
name: clear_task_instance_form [6104,6128]
===
match
---
decorator [2195,2212]
decorator [2223,2240]
===
match
---
atom_expr [2287,2329]
atom_expr [2315,2357]
===
match
---
operator: = [1494,1495]
operator: = [1522,1523]
===
match
---
operator: } [7102,7103]
operator: } [7114,7115]
===
match
---
name: default_ti_init [1617,1632]
name: default_ti_init [1645,1660]
===
match
---
expr_stmt [6711,7103]
expr_stmt [6723,7115]
===
match
---
name: pytest [847,853]
name: pytest [832,838]
===
match
---
string: "state" [1698,1705]
string: "state" [1726,1733]
===
match
---
operator: , [2741,2742]
operator: , [2769,2770]
===
match
---
operator: , [1250,1251]
operator: , [1278,1279]
===
match
---
name: sla_miss [3874,3882]
name: sla_miss [3894,3902]
===
match
---
operator: { [5455,5456]
operator: { [5467,5468]
===
match
---
trailer [1712,1720]
trailer [1740,1748]
===
match
---
operator: = [1763,1764]
operator: = [1791,1792]
===
match
---
argument [2290,2304]
argument [2318,2332]
===
match
---
atom [6276,6602]
atom [6288,6614]
===
match
---
name: self [2356,2360]
name: self [2384,2388]
===
match
---
number: 0 [6852,6853]
number: 0 [6864,6865]
===
match
---
trailer [7485,7492]
trailer [7497,7504]
===
match
---
string: "TEST_DAG_ID" [1495,1508]
string: "TEST_DAG_ID" [1523,1536]
===
match
---
atom_expr [3518,3548]
atom_expr [3538,3568]
===
match
---
string: "2020-01-01T00:00:00+00:00" [6381,6408]
string: "2020-01-01T00:00:00+00:00" [6393,6420]
===
match
---
operator: = [1533,1534]
operator: = [1561,1562]
===
match
---
name: value [2347,2352]
name: value [2375,2380]
===
match
---
name: timezone [6830,6838]
name: timezone [6842,6850]
===
match
---
arglist [1549,1601]
arglist [1577,1629]
===
match
---
string: "TEST_DAG_ID" [2583,2596]
string: "TEST_DAG_ID" [2611,2624]
===
match
---
operator: , [2262,2263]
operator: , [2290,2291]
===
match
---
trailer [7442,7449]
trailer [7454,7461]
===
match
---
parameters [2057,2063]
parameters [2085,2091]
===
match
---
simple_stmt [1740,2040]
simple_stmt [1768,2068]
===
match
---
param [2258,2263]
param [2286,2291]
===
match
---
number: 100 [4246,4249]
number: 100 [4266,4269]
===
match
---
simple_stmt [6640,6703]
simple_stmt [6652,6715]
===
match
---
trailer [1863,1876]
trailer [1891,1904]
===
match
---
string: "pool" [2913,2919]
string: "pool" [2941,2947]
===
match
---
arith_expr [1859,1899]
arith_expr [1887,1927]
===
match
---
atom_expr [6839,6854]
atom_expr [6851,6866]
===
match
---
name: value [3579,3584]
name: value [3599,3604]
===
match
---
operator: } [4759,4760]
operator: } [4779,4780]
===
match
---
trailer [2378,2384]
trailer [2406,2412]
===
match
---
with_stmt [7474,7577]
with_stmt [7486,7589]
===
match
---
assert_stmt [7112,7144]
assert_stmt [7124,7156]
===
match
---
operator: , [6023,6024]
operator: , [6035,6036]
===
match
---
argument [1826,1832]
argument [1854,1860]
===
match
---
string: "execution_date" [6363,6379]
string: "execution_date" [6375,6391]
===
match
---
testlist_comp [5125,5972]
testlist_comp [5137,5984]
===
match
---
operator: { [7230,7231]
operator: { [7242,7243]
===
match
---
trailer [4956,4958]
trailer [4968,4970]
===
match
---
dictorsetmaker [7315,7343]
dictorsetmaker [7327,7355]
===
match
---
name: default_time [1589,1601]
name: default_time [1617,1629]
===
match
---
for_stmt [3500,3586]
for_stmt [3520,3606]
===
match
---
string: "task_id" [6319,6328]
string: "task_id" [6331,6340]
===
match
---
operator: , [4128,4129]
operator: , [4148,4149]
===
match
---
string: "priority_weight" [4328,4345]
string: "priority_weight" [4348,4365]
===
match
---
string: "default_queue" [3021,3036]
string: "default_queue" [3049,3064]
===
match
---
testlist_comp [7196,7214]
testlist_comp [7208,7226]
===
match
---
number: 0 [3253,3254]
number: 0 [3281,3282]
===
match
---
simple_stmt [6711,7104]
simple_stmt [6723,7116]
===
match
---
trailer [2463,2470]
trailer [2491,2498]
===
match
---
simple_stmt [4978,5016]
simple_stmt [4990,5028]
===
match
---
name: test_success [6612,6624]
name: test_success [6624,6636]
===
match
---
operator: } [7212,7213]
operator: } [7224,7225]
===
match
---
argument [1573,1601]
argument [1601,1629]
===
match
---
number: 2020 [1459,1463]
number: 2020 [1487,1491]
===
match
---
name: test_validation_error [5997,6018]
name: test_validation_error [6009,6030]
===
match
---
string: "end_date" [2643,2653]
string: "end_date" [2671,2681]
===
match
---
trailer [2092,2094]
trailer [2120,2122]
===
match
---
argument [2306,2328]
argument [2334,2356]
===
match
---
parameters [6624,6630]
parameters [6636,6642]
===
match
---
argument [3452,3466]
argument [3472,3486]
===
match
---
name: ti [2444,2446]
name: ti [2472,2474]
===
match
---
trailer [6236,6238]
trailer [6248,6250]
===
match
---
operator: , [3507,3508]
operator: , [3527,3528]
===
match
---
name: result [6640,6646]
name: result [6652,6658]
===
match
---
argument [3662,3682]
argument [3682,3702]
===
match
---
operator: , [1028,1029]
operator: , [1013,1014]
===
match
---
trailer [6061,6078]
trailer [6073,6090]
===
match
---
name: getuser [3288,3295]
name: getuser [3308,3315]
===
match
---
trailer [3779,3783]
trailer [3799,3803]
===
match
---
simple_stmt [1430,1471]
simple_stmt [1458,1499]
===
match
---
string: "default_pool" [1976,1990]
string: "default_pool" [2004,2018]
===
match
---
expr_stmt [3827,3884]
expr_stmt [3847,3904]
===
match
---
string: "end_date" [3993,4003]
string: "end_date" [4013,4023]
===
match
---
atom [7195,7215]
atom [7207,7227]
===
match
---
trailer [6792,6801]
trailer [6804,6813]
===
match
---
name: unittest [1381,1389]
name: unittest [1409,1417]
===
match
---
name: airflow [1207,1214]
name: airflow [1235,1242]
===
match
---
operator: = [6647,6648]
operator: = [6659,6660]
===
match
---
operator: , [4745,4746]
operator: , [4765,4766]
===
match
---
name: datetime [1341,1349]
name: datetime [1369,1377]
===
match
---
suite [3435,5016]
suite [3455,5028]
===
match
---
name: self [2258,2262]
name: self [2286,2290]
===
match
---
string: "operator" [2848,2858]
string: "operator" [2876,2886]
===
match
---
atom_expr [2158,2189]
atom_expr [2186,2217]
===
match
---
string: "queued_when" [3050,3063]
string: "queued_when" [3078,3091]
===
match
---
suite [1421,2040]
suite [1449,2068]
===
match
---
operator: , [7092,7093]
operator: , [7104,7105]
===
match
---
name: self [1740,1744]
name: self [1768,1772]
===
match
---
name: session [1221,1228]
name: session [1249,1256]
===
match
---
import_name [840,853]
import_name [825,838]
===
match
---
string: "new_state" [6570,6581]
string: "new_state" [6582,6593]
===
match
---
name: provide_session [2196,2211]
name: provide_session [2224,2239]
===
match
---
simple_stmt [3562,3586]
simple_stmt [3582,3606]
===
match
---
string: "include_future" [7231,7247]
string: "include_future" [7243,7259]
===
match
---
name: parameterized [5081,5094]
name: parameterized [5093,5106]
===
match
---
arglist [1459,1469]
arglist [1487,1497]
===
match
---
name: dt [805,807]
name: dt [805,807]
===
match
---
trailer [1434,1447]
trailer [1462,1475]
===
match
---
import_from [854,893]
import_from [839,878]
===
match
---
trailer [3868,3884]
trailer [3888,3904]
===
match
---
string: "try_number" [4900,4912]
string: "try_number" [4920,4932]
===
match
---
trailer [3612,3739]
trailer [3632,3759]
===
match
---
operator: = [3668,3669]
operator: = [3688,3689]
===
match
---
name: TaskInstance [1133,1145]
name: TaskInstance [1118,1130]
===
match
---
expr_stmt [3444,3491]
expr_stmt [3464,3511]
===
match
---
trailer [7551,7556]
trailer [7563,7568]
===
match
---
trailer [1458,1470]
trailer [1486,1498]
===
match
---
trailer [1389,1398]
trailer [1417,1426]
===
match
---
number: 0 [2833,2834]
number: 0 [2861,2862]
===
match
---
name: key [3574,3577]
name: key [3594,3597]
===
match
---
operator: , [2964,2965]
operator: , [2992,2993]
===
match
---
operator: ** [3468,3470]
operator: ** [3488,3490]
===
match
---
string: "sla_miss" [4433,4443]
string: "sla_miss" [4453,4463]
===
insert-tree
---
simple_stmt [1187,1230]
    import_from [1187,1229]
        dotted_name [1192,1214]
            name: airflow [1192,1199]
            name: utils [1200,1205]
            name: platform [1206,1214]
        name: getuser [1222,1229]
to
file_input [786,7577]
at 9
===
move-tree
---
name: getuser [3288,3295]
to
atom_expr [3280,3297]
at 0
===
move-tree
---
name: getuser [4949,4956]
to
atom_expr [4941,4958]
at 0
===
delete-tree
---
simple_stmt [808,823]
    import_name [808,822]
        name: getpass [815,822]
===
delete-node
---
name: getpass [3280,3287]
===
===
delete-node
---
trailer [3287,3295]
===
===
delete-node
---
name: getpass [4941,4948]
===
===
delete-node
---
trailer [4948,4956]
===
