===
match
---
name: get_conn [3120,3128]
name: get_conn [3120,3128]
===
match
---
atom_expr [3280,3315]
atom_expr [3280,3315]
===
match
---
trailer [4286,4333]
trailer [4286,4333]
===
match
---
name: login [3415,3420]
name: login [3415,3420]
===
match
---
trailer [3547,3582]
trailer [3547,3582]
===
match
---
name: remote_host [1737,1748]
name: remote_host [1737,1748]
===
match
---
name: winrm_hook [1178,1188]
name: winrm_hook [1178,1188]
===
match
---
trailer [1438,1456]
trailer [1438,1456]
===
match
---
name: remote_host [5099,5110]
name: remote_host [5091,5102]
===
match
---
atom_expr [3443,3462]
atom_expr [3443,3462]
===
match
---
name: connection [4196,4206]
name: connection [4196,4206]
===
match
---
simple_stmt [5076,5140]
simple_stmt [5068,5132]
===
match
---
operator: , [2974,2975]
operator: , [2974,2975]
===
match
---
trailer [3290,3303]
trailer [3290,3303]
===
match
---
name: winrm_hook [4782,4792]
name: winrm_hook [4774,4784]
===
match
---
name: str [3914,3917]
name: str [3914,3917]
===
match
---
trailer [4195,4250]
trailer [4195,4250]
===
match
---
operator: = [4626,4627]
operator: = [4618,4619]
===
match
---
trailer [3076,3099]
trailer [3076,3099]
===
match
---
string: 'ca_trust_path' [3638,3653]
string: 'ca_trust_path' [3638,3653]
===
match
---
string: 'kerberos_delegation' [3942,3963]
string: 'kerberos_delegation' [3942,3963]
===
match
---
trailer [1481,1490]
trailer [1481,1490]
===
match
---
name: patch [4640,4645]
name: patch [4632,4637]
===
match
---
simple_stmt [1621,1668]
simple_stmt [1621,1668]
===
match
---
argument [3537,3582]
argument [3537,3582]
===
match
---
operator: , [2892,2893]
operator: , [2892,2893]
===
match
---
name: self [1148,1152]
name: self [1148,1152]
===
match
---
name: patch [1774,1779]
name: patch [1774,1779]
===
match
---
trailer [3119,3128]
trailer [3119,3128]
===
match
---
trailer [1978,2903]
trailer [1978,2903]
===
match
---
operator: = [1748,1749]
operator: = [1748,1749]
===
match
---
name: message_encryption [4264,4282]
name: message_encryption [4264,4282]
===
match
---
name: return_value [1245,1257]
name: return_value [1245,1257]
===
match
---
fstring_string: http:// [5189,5196]
fstring_string: http:// [5181,5188]
===
match
---
name: username [3395,3403]
name: username [3395,3403]
===
match
---
atom_expr [3918,3964]
atom_expr [3918,3964]
===
match
---
dotted_name [907,921]
dotted_name [907,921]
===
match
---
name: ssh_conn_id [3077,3088]
name: ssh_conn_id [3077,3088]
===
match
---
name: TestWinRMHook [1016,1029]
name: TestWinRMHook [1016,1029]
===
match
---
trailer [3637,3654]
trailer [3637,3654]
===
match
---
atom_expr [3678,3718]
atom_expr [3678,3718]
===
match
---
name: client [1222,1228]
name: client [1222,1228]
===
match
---
decorator [4542,4635]
decorator [4542,4627]
===
match
---
name: assert_called_once_with [3160,3183]
name: assert_called_once_with [3160,3183]
===
match
---
trailer [3971,3973]
trailer [3971,3973]
===
match
---
name: patch [1858,1863]
name: patch [1858,1863]
===
match
---
comparison [3914,3983]
comparison [3914,3983]
===
match
---
name: connection [3344,3354]
name: connection [3344,3354]
===
match
---
operator: , [4823,4824]
operator: , [4815,4816]
===
match
---
name: remote_host [5208,5219]
name: remote_host [5200,5211]
===
match
---
decorator [1498,1563]
decorator [1498,1563]
===
match
---
name: WinRMHook [1727,1736]
name: WinRMHook [1727,1736]
===
match
---
trailer [3229,3253]
trailer [3229,3253]
===
match
---
operator: , [1595,1596]
operator: , [1595,1596]
===
match
---
decorator [1857,2911]
decorator [1857,2911]
===
match
---
name: password [3454,3462]
name: password [3454,3462]
===
match
---
name: conn [1336,1340]
name: conn [1336,1340]
===
match
---
name: read_timeout_sec [3997,4013]
name: read_timeout_sec [3997,4013]
===
match
---
simple_stmt [1329,1362]
simple_stmt [1329,1362]
===
match
---
operator: , [3582,3583]
operator: , [3582,3583]
===
match
---
name: self [1591,1595]
name: self [1591,1595]
===
match
---
argument [3803,3880]
argument [3803,3880]
===
match
---
operator: = [1967,1968]
operator: = [1967,1968]
===
match
---
name: mock_get_connection [3140,3159]
name: mock_get_connection [3140,3159]
===
match
---
fstring_expr [5196,5220]
fstring_expr [5188,5212]
===
match
---
string: 'kerberos_hostname_override' [4220,4248]
string: 'kerberos_hostname_override' [4220,4248]
===
match
---
param [5046,5051]
param [5038,5043]
===
match
---
trailer [3253,4536]
trailer [3253,4536]
===
match
---
argument [4165,4250]
argument [4165,4250]
===
match
---
name: patch [4543,4548]
name: patch [4543,4548]
===
match
---
trailer [3487,3523]
trailer [3487,3523]
===
match
---
decorators [1773,2911]
decorators [1773,2911]
===
match
---
operator: = [3088,3089]
operator: = [3088,3089]
===
match
---
atom_expr [4893,4918]
atom_expr [4885,4910]
===
match
---
trailer [4481,4494]
trailer [4481,4494]
===
match
---
name: test_get_conn_no_endpoint [5020,5045]
name: test_get_conn_no_endpoint [5012,5037]
===
match
---
trailer [3941,3964]
trailer [3941,3964]
===
match
---
name: WinRMHook [4795,4804]
name: WinRMHook [4787,4796]
===
match
---
name: winrm_hook [1211,1221]
name: winrm_hook [1211,1221]
===
match
---
operator: == [4516,4518]
operator: == [4516,4518]
===
match
---
comparison [4467,4525]
comparison [4467,4525]
===
match
---
trailer [4804,4845]
trailer [4796,4837]
===
match
---
atom_expr [3140,3207]
atom_expr [3140,3207]
===
match
---
arglist [1780,1851]
arglist [1780,1851]
===
match
---
operator: , [3880,3881]
operator: , [3880,3881]
===
match
---
operator: = [1189,1190]
operator: = [1189,1190]
===
match
---
operator: , [4525,4526]
operator: , [4525,4526]
===
match
---
suite [4773,4942]
suite [4765,4934]
===
match
---
file_input [790,5276]
file_input [790,5268]
===
match
---
trailer [1695,1713]
trailer [1695,1713]
===
match
---
operator: = [5110,5111]
operator: = [5102,5103]
===
match
---
simple_stmt [806,838]
simple_stmt [806,838]
===
match
---
operator: = [5127,5128]
operator: = [5119,5120]
===
match
---
trailer [1354,1361]
trailer [1354,1361]
===
match
---
trailer [3194,3206]
trailer [3194,3206]
===
match
---
simple_stmt [4855,4877]
simple_stmt [4847,4869]
===
match
---
trailer [3279,3316]
trailer [3279,3316]
===
match
---
name: return_value [1955,1967]
name: return_value [1955,1967]
===
match
---
operator: , [2903,2904]
operator: , [2903,2904]
===
match
---
fstring_expr [5221,5245]
fstring_expr [5213,5237]
===
match
---
trailer [4112,4125]
trailer [4112,4125]
===
match
---
name: cert_key_pem [3732,3744]
name: cert_key_pem [3732,3744]
===
match
---
operator: @ [1498,1499]
operator: @ [1498,1499]
===
match
---
suite [1612,1768]
suite [1612,1768]
===
match
---
expr_stmt [1621,1667]
expr_stmt [1621,1667]
===
match
---
operator: = [3543,3544]
operator: = [3543,3544]
===
match
---
name: get_conn [1757,1765]
name: get_conn [1757,1765]
===
match
---
name: extra_dejson [4029,4041]
name: extra_dejson [4029,4041]
===
match
---
operator: , [4742,4743]
operator: , [4734,4735]
===
match
---
trailer [1634,1646]
trailer [1634,1646]
===
match
---
name: pytest [1682,1688]
name: pytest [1682,1688]
===
match
---
trailer [4874,4876]
trailer [4866,4868]
===
match
---
name: unittest [1030,1038]
name: unittest [1030,1038]
===
match
---
atom_expr [1298,1319]
atom_expr [1298,1319]
===
match
---
simple_stmt [3140,3208]
simple_stmt [3140,3208]
===
match
---
name: str [4371,4374]
name: str [4371,4374]
===
match
---
atom_expr [1470,1492]
atom_expr [1470,1492]
===
match
---
name: autospec [1838,1846]
name: autospec [1838,1846]
===
match
---
name: mock_get_connection [3013,3032]
name: mock_get_connection [3013,3032]
===
match
---
name: airflow [859,866]
name: airflow [859,866]
===
match
---
trailer [3453,3462]
trailer [3453,3462]
===
match
---
operator: = [3483,3484]
operator: = [3483,3484]
===
match
---
argument [3434,3462]
argument [3434,3462]
===
match
---
argument [3596,3655]
argument [3596,3655]
===
match
---
trailer [3853,3879]
trailer [3853,3879]
===
match
---
name: connection [3918,3928]
name: connection [3918,3928]
===
match
---
name: mock_protocol [1621,1634]
name: mock_protocol [1621,1634]
===
match
---
name: Connection [929,939]
name: Connection [929,939]
===
match
---
operator: , [4444,4445]
operator: , [4444,4445]
===
match
---
atom_expr [4471,4506]
atom_expr [4471,4506]
===
match
---
name: self [4738,4742]
name: self [4730,4734]
===
match
---
trailer [3840,3853]
trailer [3840,3853]
===
match
---
atom_expr [3404,3420]
atom_expr [3404,3420]
===
match
---
name: connection [4287,4297]
name: connection [4287,4297]
===
match
---
name: extra_dejson [3929,3941]
name: extra_dejson [3929,3941]
===
match
---
comparison [4893,4941]
comparison [4885,4933]
===
match
---
trailer [4398,4425]
trailer [4398,4425]
===
match
---
name: patch [1055,1060]
name: patch [1055,1060]
===
match
---
operator: , [3316,3317]
operator: , [3316,3317]
===
match
---
name: str [3610,3613]
name: str [3610,3613]
===
match
---
name: connection [3682,3692]
name: connection [3682,3692]
===
match
---
name: connection [3614,3624]
name: connection [3614,3624]
===
match
---
name: return_value [4614,4626]
name: return_value [4606,4618]
===
match
---
name: return_value [4906,4918]
name: return_value [4898,4910]
===
match
---
name: mock [820,824]
name: mock [820,824]
===
match
---
name: WinRMHook [3067,3076]
name: WinRMHook [3067,3076]
===
match
---
name: server_cert_validation [3803,3825]
name: server_cert_validation [3803,3825]
===
match
---
name: connection [3280,3290]
name: connection [3280,3290]
===
match
---
argument [3476,3523]
argument [3476,3523]
===
match
---
name: get_conn [5160,5168]
name: get_conn [5152,5160]
===
match
---
name: mock_protocol [1154,1167]
name: mock_protocol [1154,1167]
===
match
---
name: winrm [985,990]
name: winrm [985,990]
===
match
---
operator: @ [1773,1774]
operator: @ [1773,1774]
===
match
---
name: patch [4948,4953]
name: patch [4940,4945]
===
match
---
operator: = [3677,3678]
operator: = [3677,3678]
===
match
---
operator: { [5221,5222]
operator: { [5213,5214]
===
match
---
operator: == [1341,1343]
operator: == [1341,1343]
===
match
---
trailer [4310,4332]
trailer [4310,4332]
===
match
---
decorated [1773,4537]
decorated [1773,4537]
===
match
---
argument [2087,2892]
argument [2087,2892]
===
match
---
trailer [4297,4310]
trailer [4297,4310]
===
match
---
name: kerberos_delegation [3894,3913]
name: kerberos_delegation [3894,3913]
===
match
---
operator: } [5244,5245]
operator: } [5236,5237]
===
match
---
string: 'airflow.providers.microsoft.winrm.hooks.winrm.Protocol' [1505,1561]
string: 'airflow.providers.microsoft.winrm.hooks.winrm.Protocol' [1505,1561]
===
match
---
trailer [1736,1756]
trailer [1736,1756]
===
match
---
simple_stmt [1470,1493]
simple_stmt [1470,1493]
===
match
---
atom_expr [3830,3879]
atom_expr [3830,3879]
===
match
---
string: 'conn_id' [3089,3098]
string: 'conn_id' [3089,3098]
===
match
---
string: 'airflow.providers.microsoft.winrm.hooks.winrm.getpass.getuser' [4549,4612]
string: 'airflow.providers.microsoft.winrm.hooks.winrm.getuser' [4549,4604]
===
match
---
arglist [3267,4526]
arglist [3267,4526]
===
match
---
argument [3267,3316]
argument [3267,3316]
===
match
---
name: extra [2087,2092]
name: extra [2087,2092]
===
match
---
string: 'true' [4438,4444]
string: 'true' [4438,4444]
===
match
---
trailer [3303,3315]
trailer [3303,3315]
===
match
---
atom_expr [3344,3380]
atom_expr [3344,3380]
===
match
---
name: endpoint [5267,5275]
name: endpoint [5259,5267]
===
match
---
operator: == [4919,4921]
operator: == [4911,4913]
===
match
---
name: lower [3966,3971]
name: lower [3966,3971]
===
match
---
operator: = [1846,1847]
operator: = [1846,1847]
===
match
---
name: mock_protocol [5052,5065]
name: mock_protocol [5044,5057]
===
match
---
trailer [3705,3717]
trailer [3705,3717]
===
match
---
expr_stmt [4782,4845]
expr_stmt [4774,4837]
===
match
---
trailer [1221,1228]
trailer [1221,1228]
===
match
---
trailer [4385,4398]
trailer [4385,4398]
===
match
---
name: connection [3749,3759]
name: connection [3749,3759]
===
match
---
name: test_get_conn_no_username [4712,4737]
name: test_get_conn_no_username [4704,4729]
===
match
---
trailer [4932,4941]
trailer [4924,4933]
===
match
---
name: connection [3548,3558]
name: connection [3548,3558]
===
match
---
argument [3330,3381]
argument [3330,3381]
===
match
---
param [2955,2975]
param [2955,2975]
===
match
---
trailer [3128,3130]
trailer [3128,3130]
===
match
---
trailer [4426,4432]
trailer [4426,4432]
===
match
---
atom_expr [4467,4515]
atom_expr [4467,4515]
===
match
---
name: lower [4427,4432]
name: lower [4427,4432]
===
match
---
assert_stmt [4886,4941]
assert_stmt [4878,4933]
===
match
---
string: 'cert_pem' [3706,3716]
string: 'cert_pem' [3706,3716]
===
match
---
name: models [915,921]
name: models [915,921]
===
match
---
string: 'host' [1749,1755]
string: 'host' [1749,1755]
===
match
---
assert_stmt [5180,5275]
assert_stmt [5172,5267]
===
match
---
name: connection [3488,3498]
name: connection [3488,3498]
===
match
---
trailer [3343,3381]
trailer [3343,3381]
===
match
---
trailer [4101,4151]
trailer [4101,4151]
===
match
---
argument [2022,2041]
argument [2022,2041]
===
match
---
argument [4076,4151]
argument [4076,4151]
===
match
---
parameters [1404,1410]
parameters [1404,1410]
===
match
---
suite [1457,1493]
suite [1457,1493]
===
match
---
name: winrm_hook [5197,5207]
name: winrm_hook [5189,5199]
===
match
---
operator: = [4466,4467]
operator: = [4466,4467]
===
match
---
with_stmt [1677,1768]
with_stmt [1677,1768]
===
match
---
name: connection [3443,3453]
name: connection [3443,3453]
===
match
---
atom_expr [4855,4876]
atom_expr [4847,4868]
===
match
---
trailer [4041,4061]
trailer [4041,4061]
===
match
---
operator: = [1647,1648]
operator: = [1647,1648]
===
match
---
operator: = [2059,2060]
operator: = [2059,2060]
===
match
---
argument [5099,5117]
argument [5091,5109]
===
match
---
arglist [1873,2904]
arglist [1873,2904]
===
match
---
simple_stmt [3054,3100]
simple_stmt [3054,3100]
===
match
---
name: str [3745,3748]
name: str [3745,3748]
===
match
---
atom_expr [5256,5275]
atom_expr [5248,5267]
===
match
---
atom_expr [3749,3788]
atom_expr [3749,3788]
===
match
---
name: side_effect [1635,1646]
name: side_effect [1635,1646]
===
match
---
argument [4825,4844]
argument [4817,4836]
===
match
---
name: WinRMHook [5089,5098]
name: WinRMHook [5081,5090]
===
match
---
trailer [3511,3522]
trailer [3511,3522]
===
match
---
parameters [1147,1168]
parameters [1147,1168]
===
match
---
trailer [4028,4041]
trailer [4028,4041]
===
match
---
funcdef [1367,1493]
funcdef [1367,1493]
===
match
---
name: str [4192,4195]
name: str [4192,4195]
===
match
---
import_from [940,1007]
import_from [940,1007]
===
match
---
name: ca_trust_path [3596,3609]
name: ca_trust_path [3596,3609]
===
match
---
operator: == [4435,4437]
operator: == [4435,4437]
===
match
---
name: AirflowException [1696,1712]
name: AirflowException [1696,1712]
===
match
---
atom_expr [3610,3655]
atom_expr [3610,3655]
===
match
---
operator: { [5196,5197]
operator: { [5188,5189]
===
match
---
atom_expr [3614,3654]
atom_expr [3614,3654]
===
match
---
param [1597,1610]
param [1597,1610]
===
match
---
name: TestCase [1039,1047]
name: TestCase [1039,1047]
===
match
---
argument [1737,1755]
argument [1737,1755]
===
match
---
param [4744,4758]
param [4736,4750]
===
match
---
name: password [4825,4833]
name: password [4817,4825]
===
match
---
trailer [4905,4918]
trailer [4897,4910]
===
match
---
param [2976,2989]
param [2976,2989]
===
match
---
trailer [3367,3380]
trailer [3367,3380]
===
match
---
name: test_get_conn_exists [1127,1147]
name: test_get_conn_exists [1127,1147]
===
match
---
atom_expr [3216,4536]
atom_expr [3216,4536]
===
match
---
name: remote_host [4805,4816]
name: remote_host [4797,4808]
===
match
---
name: winrm_hook [5256,5266]
name: winrm_hook [5248,5258]
===
match
---
parameters [1590,1611]
parameters [1590,1611]
===
match
---
param [1154,1167]
param [1154,1167]
===
match
---
name: extra_dejson [3559,3571]
name: extra_dejson [3559,3571]
===
match
---
name: extra_dejson [3625,3637]
name: extra_dejson [3625,3637]
===
match
---
name: endpoint [3267,3275]
name: endpoint [3267,3275]
===
match
---
string: 'Error' [1659,1666]
string: 'Error' [1659,1666]
===
match
---
name: str [3340,3343]
name: str [3340,3343]
===
match
---
arglist [1992,2893]
arglist [1992,2893]
===
match
---
decorated [4947,5276]
decorated [4939,5268]
===
match
---
atom_expr [3184,3206]
atom_expr [3184,3206]
===
match
---
atom_expr [4192,4250]
atom_expr [4192,4250]
===
match
---
name: connection [4375,4385]
name: connection [4375,4385]
===
match
---
trailer [3772,3788]
trailer [3772,3788]
===
match
---
suite [1049,5276]
suite [1049,5268]
===
match
---
arglist [4805,4844]
arglist [4797,4836]
===
match
---
operator: = [4793,4794]
operator: = [4785,4786]
===
match
---
operator: , [1945,1946]
operator: , [1945,1946]
===
match
---
operator: = [3275,3276]
operator: = [3275,3276]
===
match
---
name: Exception [1649,1658]
name: Exception [1649,1658]
===
match
---
trailer [1658,1667]
trailer [1658,1667]
===
match
---
trailer [4432,4434]
trailer [4432,4434]
===
match
---
name: airflow [907,914]
name: airflow [907,914]
===
match
---
operator: = [3339,3340]
operator: = [3339,3340]
===
match
---
name: login [1992,1997]
name: login [1992,1997]
===
match
---
name: mock_getuser [4759,4771]
name: mock_getuser [4751,4763]
===
match
---
name: str [3276,3279]
name: str [3276,3279]
===
match
---
trailer [4219,4249]
trailer [4219,4249]
===
match
---
name: credssp_disable_tlsv1_2 [4347,4370]
name: credssp_disable_tlsv1_2 [4347,4370]
===
match
---
name: winrm_hook [1298,1308]
name: winrm_hook [1298,1308]
===
match
---
trailer [1756,1765]
trailer [1756,1765]
===
match
---
name: transport [3330,3339]
name: transport [3330,3339]
===
match
---
dotted_name [859,877]
dotted_name [859,877]
===
match
---
funcdef [1567,1768]
funcdef [1567,1768]
===
match
---
name: AirflowException [1439,1455]
name: AirflowException [1439,1455]
===
match
---
atom_expr [4375,4425]
atom_expr [4375,4425]
===
match
---
operator: , [3381,3382]
operator: , [3381,3382]
===
match
---
trailer [1308,1317]
trailer [1308,1317]
===
match
---
trailer [3183,3207]
trailer [3183,3207]
===
match
---
name: open_shell [1258,1268]
name: open_shell [1258,1268]
===
match
---
operator: , [3523,3524]
operator: , [3523,3524]
===
match
---
name: AirflowException [885,901]
name: AirflowException [885,901]
===
match
---
operator: , [4333,4334]
operator: , [4333,4334]
===
match
---
comparison [4371,4444]
comparison [4371,4444]
===
match
---
trailer [3613,3655]
trailer [3613,3655]
===
match
---
name: microsoft [963,972]
name: microsoft [963,972]
===
match
---
simple_stmt [3000,3046]
simple_stmt [3000,3046]
===
match
---
string: 'credssp_disable_tlsv1_2' [4399,4424]
string: 'credssp_disable_tlsv1_2' [4399,4424]
===
match
---
operator: == [5253,5255]
operator: == [5245,5247]
===
match
---
trailer [3829,3880]
trailer [3829,3880]
===
match
---
param [1591,1596]
param [1591,1596]
===
match
---
atom_expr [3826,3880]
atom_expr [3826,3880]
===
match
---
argument [3732,3789]
argument [3732,3789]
===
match
---
param [2949,2954]
param [2949,2954]
===
match
---
name: extra_dejson [4113,4125]
name: extra_dejson [4113,4125]
===
match
---
name: extra_dejson [3841,3853]
name: extra_dejson [3841,3853]
===
match
---
name: int [4014,4017]
name: int [4014,4017]
===
match
---
string: """{                    "endpoint": "endpoint",                    "remote_port": 123,                    "transport": "plaintext",                    "service": "service",                    "keytab": "keytab",                    "ca_trust_path": "ca_trust_path",                    "cert_pem": "cert_pem",                    "cert_key_pem": "cert_key_pem",                    "server_cert_validation": "validate",                    "kerberos_delegation": "true",                    "read_timeout_sec": 124,                    "operation_timeout_sec": 123,                    "kerberos_hostname_override": "kerberos_hostname_override",                    "message_encryption": "auto",                    "credssp_disable_tlsv1_2": "true",                    "send_cbt": "false"                }""" [2093,2892]
string: """{                    "endpoint": "endpoint",                    "remote_port": 123,                    "transport": "plaintext",                    "service": "service",                    "keytab": "keytab",                    "ca_trust_path": "ca_trust_path",                    "cert_pem": "cert_pem",                    "cert_key_pem": "cert_key_pem",                    "server_cert_validation": "validate",                    "kerberos_delegation": "true",                    "read_timeout_sec": 124,                    "operation_timeout_sec": 123,                    "kerberos_hostname_override": "kerberos_hostname_override",                    "message_encryption": "auto",                    "credssp_disable_tlsv1_2": "true",                    "send_cbt": "false"                }""" [2093,2892]
===
match
---
string: 'endpoint' [3304,3314]
string: 'endpoint' [3304,3314]
===
match
---
name: host [2055,2059]
name: host [2055,2059]
===
match
---
param [4738,4743]
param [4730,4735]
===
match
---
funcdef [5016,5276]
funcdef [5008,5268]
===
match
---
atom_expr [1621,1646]
atom_expr [1621,1646]
===
match
---
param [1148,1153]
param [1148,1153]
===
match
---
simple_stmt [1211,1282]
simple_stmt [1211,1282]
===
match
---
atom_expr [4371,4434]
atom_expr [4371,4434]
===
match
---
atom_expr [3544,3582]
atom_expr [3544,3582]
===
match
---
classdef [1010,5276]
classdef [1010,5268]
===
match
---
funcdef [1123,1362]
funcdef [1123,1362]
===
match
---
name: str [3826,3829]
name: str [3826,3829]
===
match
---
trailer [3928,3941]
trailer [3928,3941]
===
match
---
operator: , [3462,3463]
operator: , [3462,3463]
===
match
---
param [1405,1409]
param [1405,1409]
===
match
---
string: 'host' [5111,5117]
string: 'host' [5103,5109]
===
match
---
operator: , [4151,4152]
operator: , [4151,4152]
===
match
---
import_from [806,837]
import_from [806,837]
===
match
---
suite [1714,1768]
suite [1714,1768]
===
match
---
atom_expr [4287,4332]
atom_expr [4287,4332]
===
match
---
name: raises [1689,1695]
name: raises [1689,1695]
===
match
---
decorated [1054,1362]
decorated [1054,1362]
===
match
---
name: extra_dejson [3693,3705]
name: extra_dejson [3693,3705]
===
match
---
name: self [1405,1409]
name: self [1405,1409]
===
match
---
name: lower [4508,4513]
name: lower [4508,4513]
===
match
---
name: username [4933,4941]
name: username [4925,4933]
===
match
---
trailer [1244,1257]
trailer [1244,1257]
===
match
---
decorator [1773,1853]
decorator [1773,1853]
===
match
---
decorator [4947,5012]
decorator [4939,5004]
===
match
---
name: winrm_hook [4922,4932]
name: winrm_hook [4914,4924]
===
match
---
name: pytest [846,852]
name: pytest [846,852]
===
match
---
name: password [5119,5127]
name: password [5111,5119]
===
match
---
atom_expr [1425,1456]
atom_expr [1425,1456]
===
match
---
name: winrm_hook [4855,4865]
name: winrm_hook [4847,4857]
===
match
---
name: WinRMHook [998,1007]
name: WinRMHook [998,1007]
===
match
---
argument [1992,2008]
argument [1992,2008]
===
match
---
decorated [1498,1768]
decorated [1498,1768]
===
match
---
import_name [790,805]
import_name [790,805]
===
match
---
import_from [854,901]
import_from [854,901]
===
match
---
name: raises [1432,1438]
name: raises [1432,1438]
===
match
---
string: 'password' [2031,2041]
string: 'password' [2031,2041]
===
match
---
operator: , [4250,4251]
operator: , [4250,4251]
===
match
---
arglist [5099,5138]
arglist [5091,5130]
===
match
---
operator: , [3789,3790]
operator: , [3789,3790]
===
match
---
simple_stmt [1178,1203]
simple_stmt [1178,1203]
===
match
---
operator: , [1152,1153]
operator: , [1152,1153]
===
match
---
trailer [1317,1319]
trailer [1317,1319]
===
match
---
trailer [5232,5244]
trailer [5224,5236]
===
match
---
fstring_string: /wsman [5245,5251]
fstring_string: /wsman [5237,5243]
===
match
---
name: get_conn [4866,4874]
name: get_conn [4858,4866]
===
match
---
name: unittest [797,805]
name: unittest [797,805]
===
match
---
atom_expr [1030,1047]
atom_expr [1030,1047]
===
match
---
atom_expr [1727,1767]
atom_expr [1727,1767]
===
match
---
atom_expr [3067,3099]
atom_expr [3067,3099]
===
match
---
string: 'true' [4519,4525]
string: 'true' [4519,4525]
===
match
---
dotted_name [945,990]
dotted_name [945,990]
===
match
---
string: 'server_cert_validation' [3854,3878]
string: 'server_cert_validation' [3854,3878]
===
match
---
name: extra_dejson [3291,3303]
name: extra_dejson [3291,3303]
===
match
---
expr_stmt [1211,1281]
expr_stmt [1211,1281]
===
match
---
name: extra_dejson [4207,4219]
name: extra_dejson [4207,4219]
===
match
---
operator: = [1296,1297]
operator: = [1296,1297]
===
match
---
trailer [3624,3637]
trailer [3624,3637]
===
match
---
operator: , [4062,4063]
operator: , [4062,4063]
===
match
---
argument [4614,4633]
argument [4606,4625]
===
match
---
trailer [3965,3971]
trailer [3965,3971]
===
match
---
simple_stmt [790,806]
simple_stmt [790,806]
===
match
---
trailer [1688,1695]
trailer [1688,1695]
===
match
---
operator: @ [1054,1055]
operator: @ [1054,1055]
===
match
---
suite [1411,1493]
suite [1411,1493]
===
match
---
atom_expr [1191,1202]
atom_expr [1191,1202]
===
match
---
atom_expr [3013,3045]
atom_expr [3013,3045]
===
match
---
trailer [1479,1481]
trailer [1479,1481]
===
match
---
atom_expr [3276,3316]
atom_expr [3276,3316]
===
match
---
string: 'message_encryption' [4311,4331]
string: 'message_encryption' [4311,4331]
===
match
---
argument [5119,5138]
argument [5111,5130]
===
match
---
name: str [3678,3681]
name: str [3678,3681]
===
match
---
expr_stmt [1291,1319]
expr_stmt [1291,1319]
===
match
---
name: airflow [945,952]
name: airflow [945,952]
===
match
---
fstring_string: : [5220,5221]
fstring_string: : [5212,5213]
===
match
---
operator: , [2073,2074]
operator: , [2073,2074]
===
match
---
trailer [5266,5275]
trailer [5258,5267]
===
match
---
atom_expr [3340,3381]
atom_expr [3340,3381]
===
match
---
string: 'password' [5128,5138]
string: 'password' [5120,5130]
===
match
---
name: service [3476,3483]
name: service [3476,3483]
===
match
---
atom_expr [4795,4845]
atom_expr [4787,4837]
===
match
---
trailer [1765,1767]
trailer [1765,1767]
===
match
---
name: kerberos_hostname_override [4165,4191]
name: kerberos_hostname_override [4165,4191]
===
match
---
operator: @ [4639,4640]
operator: @ [4631,4632]
===
match
---
suite [1169,1362]
suite [1169,1362]
===
match
---
name: winrm_hook [5149,5159]
name: winrm_hook [5141,5151]
===
match
---
name: str [4283,4286]
name: str [4283,4286]
===
match
---
name: mock_get_connection [2955,2974]
name: mock_get_connection [2955,2974]
===
match
---
name: str [4467,4470]
name: str [4467,4470]
===
match
---
trailer [4507,4513]
trailer [4507,4513]
===
match
---
expr_stmt [3000,3045]
expr_stmt [3000,3045]
===
match
---
trailer [1257,1268]
trailer [1257,1268]
===
match
---
trailer [3759,3772]
trailer [3759,3772]
===
match
---
name: extra_dejson [4298,4310]
name: extra_dejson [4298,4310]
===
match
---
trailer [3498,3511]
trailer [3498,3511]
===
match
---
trailer [3032,3045]
trailer [3032,3045]
===
match
---
argument [4264,4333]
argument [4264,4333]
===
match
---
operator: , [4612,4613]
operator: , [4604,4605]
===
match
---
argument [4458,4525]
argument [4458,4525]
===
match
---
atom_expr [1211,1228]
atom_expr [1211,1228]
===
match
---
trailer [5168,5170]
trailer [5160,5162]
===
match
---
operator: = [4370,4371]
operator: = [4370,4371]
===
match
---
string: 'service' [3512,3521]
string: 'service' [3512,3521]
===
match
---
atom_expr [3484,3523]
atom_expr [3484,3523]
===
match
---
arglist [4549,4633]
arglist [4549,4625]
===
match
---
atom_expr [3745,3789]
atom_expr [3745,3789]
===
match
---
string: 'true' [3977,3983]
string: 'true' [3977,3983]
===
match
---
atom_expr [3914,3973]
atom_expr [3914,3973]
===
match
---
name: int [4098,4101]
name: int [4098,4101]
===
match
---
atom_expr [4014,4062]
atom_expr [4014,4062]
===
match
---
decorator [1054,1119]
decorator [1054,1119]
===
match
---
atom_expr [1649,1667]
atom_expr [1649,1667]
===
match
---
name: extra_dejson [4482,4494]
name: extra_dejson [4482,4494]
===
match
---
atom_expr [3548,3581]
atom_expr [3548,3581]
===
match
---
name: remote_port [5233,5244]
name: remote_port [5225,5236]
===
match
---
name: return_value [1269,1281]
name: return_value [1269,1281]
===
match
---
name: self [5046,5050]
name: self [5038,5042]
===
match
---
operator: , [5050,5051]
operator: , [5042,5043]
===
match
---
argument [2055,2073]
argument [2055,2073]
===
match
---
trailer [5207,5219]
trailer [5199,5211]
===
match
---
operator: = [3011,3012]
operator: = [3011,3012]
===
match
---
name: connection [4471,4481]
name: connection [4471,4481]
===
match
---
trailer [3917,3965]
trailer [3917,3965]
===
match
---
argument [3669,3718]
argument [3669,3718]
===
match
---
name: mock_protocol [1597,1610]
name: mock_protocol [1597,1610]
===
match
---
atom_expr [4102,4150]
atom_expr [4102,4150]
===
match
---
argument [4805,4823]
argument [4797,4815]
===
match
---
trailer [1490,1492]
trailer [1490,1492]
===
match
---
parameters [5045,5066]
parameters [5037,5058]
===
match
---
name: mock_protocol [3216,3229]
name: mock_protocol [3216,3229]
===
match
---
operator: , [3420,3421]
operator: , [3420,3421]
===
match
---
name: test_get_conn_from_connection [2919,2948]
name: test_get_conn_from_connection [2919,2948]
===
match
---
name: assert_called_once_with [3230,3253]
name: assert_called_once_with [3230,3253]
===
match
---
trailer [1431,1438]
trailer [1431,1438]
===
match
---
trailer [3354,3367]
trailer [3354,3367]
===
match
---
atom_expr [5222,5244]
atom_expr [5214,5236]
===
match
---
name: patch [1499,1504]
name: patch [1499,1504]
===
match
---
operator: = [3442,3443]
operator: = [3442,3443]
===
match
---
operator: , [2041,2042]
operator: , [2041,2042]
===
match
---
string: 'keytab' [3572,3580]
string: 'keytab' [3572,3580]
===
match
---
fstring_start: f' [5187,5189]
fstring_start: f' [5179,5181]
===
match
---
argument [3894,3983]
argument [3894,3983]
===
match
---
trailer [4865,4874]
trailer [4857,4866]
===
match
---
trailer [3558,3571]
trailer [3558,3571]
===
match
---
name: cert_pem [3669,3677]
name: cert_pem [3669,3677]
===
match
---
string: 'host' [4817,4823]
string: 'host' [4809,4815]
===
match
---
trailer [3571,3581]
trailer [3571,3581]
===
match
---
expr_stmt [5076,5139]
expr_stmt [5068,5131]
===
match
---
simple_stmt [4886,4942]
simple_stmt [4878,4934]
===
match
---
name: conn [1291,1295]
name: conn [1291,1295]
===
match
---
decorators [4542,4704]
decorators [4542,4696]
===
match
---
simple_stmt [3109,3131]
simple_stmt [3109,3131]
===
match
---
name: keytab [3537,3543]
name: keytab [3537,3543]
===
match
---
atom_expr [5089,5139]
atom_expr [5081,5131]
===
match
---
funcdef [2915,4537]
funcdef [2915,4537]
===
match
---
argument [3395,3420]
argument [3395,3420]
===
match
---
string: 'user' [4627,4633]
string: 'user' [4619,4625]
===
match
---
string: 'username' [1998,2008]
string: 'username' [1998,2008]
===
match
---
string: 'cert_key_pem' [3773,3787]
string: 'cert_key_pem' [3773,3787]
===
match
---
name: test_get_conn_error [1571,1590]
name: test_get_conn_error [1571,1590]
===
match
---
name: connection [3404,3414]
name: connection [3404,3414]
===
match
---
name: unittest [811,819]
name: unittest [811,819]
===
match
---
name: exceptions [867,877]
name: exceptions [867,877]
===
match
---
trailer [4494,4506]
trailer [4494,4506]
===
match
---
simple_stmt [4782,4846]
simple_stmt [4774,4838]
===
match
---
expr_stmt [3054,3099]
expr_stmt [3054,3099]
===
match
---
name: WinRMHook [1470,1479]
name: WinRMHook [1470,1479]
===
match
---
name: operation_timeout_sec [4076,4097]
name: operation_timeout_sec [4076,4097]
===
match
---
name: winrm [973,978]
name: winrm [973,978]
===
match
---
operator: = [3065,3066]
operator: = [3065,3066]
===
match
---
param [5052,5065]
param [5044,5057]
===
match
---
trailer [4513,4515]
trailer [4513,4515]
===
match
---
trailer [5159,5168]
trailer [5151,5160]
===
match
---
fstring [5187,5252]
fstring [5179,5244]
===
match
---
operator: = [2030,2031]
operator: = [2030,2031]
===
match
---
import_from [902,939]
import_from [902,939]
===
match
---
operator: , [1836,1837]
operator: , [1836,1837]
===
match
---
trailer [4206,4219]
trailer [4206,4219]
===
match
---
name: get_conn [1309,1317]
name: get_conn [1309,1317]
===
match
---
operator: == [3974,3976]
operator: == [3974,3976]
===
match
---
argument [3997,4062]
argument [3997,4062]
===
match
---
argument [1838,1851]
argument [1838,1851]
===
match
---
operator: @ [4947,4948]
operator: @ [4939,4940]
===
match
---
operator: = [3744,3745]
operator: = [3744,3745]
===
match
---
string: 'airflow.providers.microsoft.winrm.hooks.winrm.Protocol' [4954,5010]
string: 'airflow.providers.microsoft.winrm.hooks.winrm.Protocol' [4946,5002]
===
match
---
operator: , [2953,2954]
operator: , [2953,2954]
===
match
---
trailer [3692,3705]
trailer [3692,3705]
===
match
---
operator: = [5087,5088]
operator: = [5079,5080]
===
match
---
name: test_get_conn_missing_remote_host [1371,1404]
name: test_get_conn_missing_remote_host [1371,1404]
===
match
---
string: 'airflow.providers.microsoft.winrm.hooks.winrm.Protocol' [1780,1836]
string: 'airflow.providers.microsoft.winrm.hooks.winrm.Protocol' [1780,1836]
===
match
---
operator: = [3403,3404]
operator: = [3403,3404]
===
match
---
comparison [1336,1361]
comparison [1336,1361]
===
match
---
operator: = [4833,4834]
operator: = [4825,4826]
===
match
---
param [4759,4771]
param [4751,4763]
===
match
---
name: providers [953,962]
name: providers [953,962]
===
match
---
atom_expr [4018,4061]
atom_expr [4018,4061]
===
match
---
name: winrm_hook [1344,1354]
name: winrm_hook [1344,1354]
===
match
---
atom_expr [3109,3130]
atom_expr [3109,3130]
===
match
---
string: 'transport' [3368,3379]
string: 'transport' [3368,3379]
===
match
---
name: patch [832,837]
name: patch [832,837]
===
match
---
operator: = [4816,4817]
operator: = [4808,4809]
===
match
---
simple_stmt [1727,1768]
simple_stmt [1727,1768]
===
match
---
with_stmt [1420,1493]
with_stmt [1420,1493]
===
match
---
parameters [2948,2990]
parameters [2948,2990]
===
match
---
trailer [4374,4426]
trailer [4374,4426]
===
match
---
atom_expr [5197,5219]
atom_expr [5189,5211]
===
match
---
string: 'airflow.providers.microsoft.winrm.hooks.winrm.Protocol' [1061,1117]
string: 'airflow.providers.microsoft.winrm.hooks.winrm.Protocol' [1061,1117]
===
match
---
atom_expr [3488,3522]
atom_expr [3488,3522]
===
match
---
name: self [2949,2953]
name: self [2949,2953]
===
match
---
operator: , [3655,3656]
operator: , [3655,3656]
===
match
---
name: connection [4018,4028]
name: connection [4018,4028]
===
match
---
simple_stmt [5149,5171]
simple_stmt [5141,5163]
===
match
---
string: 'remote_host' [2060,2073]
string: 'remote_host' [2060,2073]
===
match
---
name: send_cbt [4458,4466]
name: send_cbt [4458,4466]
===
match
---
name: extra_dejson [3499,3511]
name: extra_dejson [3499,3511]
===
match
---
atom_expr [4196,4249]
atom_expr [4196,4249]
===
match
---
simple_stmt [902,940]
simple_stmt [902,940]
===
match
---
operator: = [1229,1230]
operator: = [1229,1230]
===
match
---
atom_expr [1344,1361]
atom_expr [1344,1361]
===
match
---
simple_stmt [5180,5276]
simple_stmt [5172,5268]
===
match
---
trailer [1038,1047]
trailer [1038,1047]
===
match
---
name: client [1355,1361]
name: client [1355,1361]
===
match
---
trailer [3681,3718]
trailer [3681,3718]
===
match
---
import_name [839,852]
import_name [839,852]
===
match
---
simple_stmt [854,902]
simple_stmt [854,902]
===
match
---
atom_expr [3682,3717]
atom_expr [3682,3717]
===
match
---
name: get_conn [1482,1490]
name: get_conn [1482,1490]
===
match
---
parameters [4737,4772]
parameters [4729,4764]
===
match
---
atom_expr [4922,4941]
atom_expr [4914,4933]
===
match
---
expr_stmt [1178,1202]
expr_stmt [1178,1202]
===
match
---
name: winrm_hook [3109,3119]
name: winrm_hook [3109,3119]
===
match
---
decorator [4639,4704]
decorator [4631,4696]
===
match
---
operator: = [4282,4283]
operator: = [4282,4283]
===
match
---
name: mock_protocol [4744,4757]
name: mock_protocol [4736,4749]
===
match
---
argument [4347,4444]
argument [4347,4444]
===
match
---
name: ssh_conn_id [3195,3206]
name: ssh_conn_id [3195,3206]
===
match
---
atom_expr [4098,4151]
atom_expr [4098,4151]
===
match
---
name: WinRMHook [1191,1200]
name: WinRMHook [1191,1200]
===
match
---
operator: , [3983,3984]
operator: , [3983,3984]
===
match
---
name: mock_protocol [1231,1244]
name: mock_protocol [1231,1244]
===
match
---
simple_stmt [940,1008]
simple_stmt [940,1008]
===
match
---
argument [1955,2903]
argument [1955,2903]
===
match
---
funcdef [4708,4942]
funcdef [4700,4934]
===
match
---
suite [2991,4537]
suite [2991,4537]
===
match
---
trailer [3159,3183]
trailer [3159,3183]
===
match
---
simple_stmt [1291,1320]
simple_stmt [1291,1320]
===
match
---
name: connection [3000,3010]
name: connection [3000,3010]
===
match
---
trailer [4470,4507]
trailer [4470,4507]
===
match
---
atom_expr [1231,1281]
atom_expr [1231,1281]
===
match
---
argument [3077,3098]
argument [3077,3098]
===
match
---
trailer [3748,3789]
trailer [3748,3789]
===
match
---
operator: @ [1857,1858]
operator: @ [1857,1858]
===
match
---
operator: , [4757,4758]
operator: , [4749,4750]
===
match
---
atom_expr [1682,1713]
atom_expr [1682,1713]
===
match
---
string: 'send_cbt' [4495,4505]
string: 'send_cbt' [4495,4505]
===
match
---
trailer [1200,1202]
trailer [1200,1202]
===
match
---
trailer [1268,1281]
trailer [1268,1281]
===
match
---
operator: , [5117,5118]
operator: , [5109,5110]
===
match
---
operator: = [3825,3826]
operator: = [3825,3826]
===
match
---
simple_stmt [839,853]
simple_stmt [839,853]
===
match
---
name: return_value [3033,3045]
name: return_value [3033,3045]
===
match
---
string: 'airflow.providers.microsoft.winrm.hooks.winrm.Protocol' [4646,4702]
string: 'airflow.providers.microsoft.winrm.hooks.winrm.Protocol' [4638,4694]
===
match
---
operator: = [4013,4014]
operator: = [4013,4014]
===
match
---
operator: = [4191,4192]
operator: = [4191,4192]
===
match
---
comparison [5187,5275]
comparison [5179,5267]
===
match
---
name: extra_dejson [4386,4398]
name: extra_dejson [4386,4398]
===
match
---
name: mock_protocol [2976,2989]
name: mock_protocol [2976,2989]
===
match
---
operator: = [3609,3610]
operator: = [3609,3610]
===
match
---
string: 'operation_timeout_sec' [4126,4149]
string: 'operation_timeout_sec' [4126,4149]
===
match
---
name: mock_getuser [4893,4905]
name: mock_getuser [4885,4897]
===
match
---
name: password [3434,3442]
name: password [3434,3442]
===
match
---
operator: , [3718,3719]
operator: , [3718,3719]
===
match
---
simple_stmt [3216,4537]
simple_stmt [3216,4537]
===
match
---
name: extra_dejson [3355,3367]
name: extra_dejson [3355,3367]
===
match
---
atom_expr [1968,2903]
atom_expr [1968,2903]
===
match
---
name: Connection [1968,1978]
name: Connection [1968,1978]
===
match
---
trailer [3414,3420]
trailer [3414,3420]
===
match
---
operator: } [5219,5220]
operator: } [5211,5212]
===
match
---
fstring_end: ' [5251,5252]
fstring_end: ' [5243,5244]
===
match
---
suite [5067,5276]
suite [5059,5268]
===
match
---
operator: = [1997,1998]
operator: = [1997,1998]
===
match
---
name: winrm_hook [3054,3064]
name: winrm_hook [3054,3064]
===
match
---
name: winrm_hook [3184,3194]
name: winrm_hook [3184,3194]
===
match
---
name: connection [3830,3840]
name: connection [3830,3840]
===
match
---
trailer [4125,4150]
trailer [4125,4150]
===
match
---
atom_expr [4283,4333]
atom_expr [4283,4333]
===
match
---
operator: , [2008,2009]
operator: , [2008,2009]
===
match
---
operator: = [3913,3914]
operator: = [3913,3914]
===
match
---
assert_stmt [1329,1361]
assert_stmt [1329,1361]
===
match
---
operator: @ [4542,4543]
operator: @ [4542,4543]
===
match
---
dotted_name [811,824]
dotted_name [811,824]
===
match
---
name: pytest [1425,1431]
name: pytest [1425,1431]
===
match
---
trailer [5098,5139]
trailer [5090,5131]
===
match
---
name: connection [4102,4112]
name: connection [4102,4112]
===
match
---
name: str [3484,3487]
name: str [3484,3487]
===
match
---
name: extra_dejson [3760,3772]
name: extra_dejson [3760,3772]
===
match
---
atom_expr [5149,5170]
atom_expr [5141,5162]
===
match
---
name: password [2022,2030]
name: password [2022,2030]
===
match
---
decorated [4542,4942]
decorated [4542,4934]
===
match
---
name: str [3544,3547]
name: str [3544,3547]
===
match
---
string: 'read_timeout_sec' [4042,4060]
string: 'read_timeout_sec' [4042,4060]
===
match
---
string: 'password' [4834,4844]
string: 'password' [4826,4836]
===
match
---
operator: = [4097,4098]
operator: = [4097,4098]
===
match
---
name: winrm_hook [5076,5086]
name: winrm_hook [5068,5078]
===
match
---
name: winrm_hook [5222,5232]
name: winrm_hook [5214,5224]
===
match
---
trailer [4017,4062]
trailer [4017,4062]
===
match
---
string: 'airflow.providers.microsoft.winrm.hooks.winrm.WinRMHook.get_connection' [1873,1945]
string: 'airflow.providers.microsoft.winrm.hooks.winrm.WinRMHook.get_connection' [1873,1945]
===
match
---
operator: = [2092,2093]
operator: = [2092,2093]
===
match
---
name: hooks [979,984]
name: hooks [979,984]
===
update-node
---
string: 'airflow.providers.microsoft.winrm.hooks.winrm.getpass.getuser' [4549,4612]
replace 'airflow.providers.microsoft.winrm.hooks.winrm.getpass.getuser' by 'airflow.providers.microsoft.winrm.hooks.winrm.getuser'
