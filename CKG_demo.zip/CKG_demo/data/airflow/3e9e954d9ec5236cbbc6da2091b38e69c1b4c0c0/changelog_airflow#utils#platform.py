===
match
---
return_stmt [1888,1906]
return_stmt [1903,1921]
===
match
---
string: "TERM" [1444,1450]
string: "TERM" [1459,1465]
===
match
---
string: "color" [1505,1512]
string: "color" [1520,1527]
===
match
---
import_name [846,855]
import_name [861,870]
===
match
---
expr_stmt [883,916]
expr_stmt [898,931]
===
match
---
simple_stmt [1422,1468]
simple_stmt [1437,1483]
===
match
---
suite [1397,1418]
suite [1412,1433]
===
match
---
simple_stmt [883,917]
simple_stmt [898,932]
===
match
---
return_stmt [1113,1125]
return_stmt [1128,1140]
===
match
---
trailer [1431,1439]
trailer [1446,1454]
===
match
---
return_stmt [1530,1541]
return_stmt [1545,1556]
===
match
---
simple_stmt [1723,1803]
simple_stmt [1738,1818]
===
match
---
name: encoding [1785,1793]
name: encoding [1800,1808]
===
match
---
name: logging [889,896]
name: logging [904,911]
===
match
---
funcdef [1561,1907]
funcdef [1576,1922]
===
match
---
name: logging [838,845]
name: logging [853,860]
===
match
---
name: isatty [1148,1154]
name: isatty [1163,1169]
===
match
---
comparison [1276,1299]
comparison [1291,1314]
===
match
---
atom_expr [1429,1467]
atom_expr [1444,1482]
===
match
---
arglist [1758,1782]
arglist [1773,1797]
===
match
---
if_stmt [1326,1364]
if_stmt [1341,1379]
===
match
---
trailer [896,906]
trailer [911,921]
===
match
---
name: os [853,855]
name: os [868,870]
===
match
---
name: sys [1082,1085]
name: sys [1097,1100]
===
match
---
operator: , [1491,1492]
operator: , [1506,1507]
===
match
---
name: log [883,886]
name: log [898,901]
===
match
---
funcdef [1159,1559]
funcdef [1174,1574]
===
match
---
import_name [856,870]
import_name [871,885]
===
match
---
trailer [1154,1156]
trailer [1169,1171]
===
match
---
name: e [1827,1828]
name: e [1842,1843]
===
match
---
arglist [1082,1102]
arglist [1097,1117]
===
match
---
atom_expr [889,916]
atom_expr [904,931]
===
match
---
simple_stmt [1130,1157]
simple_stmt [1145,1172]
===
match
---
name: environ [1432,1439]
name: environ [1447,1454]
===
match
---
expr_stmt [1723,1802]
expr_stmt [1738,1817]
===
match
---
operator: , [1783,1784]
operator: , [1798,1799]
===
match
---
name: e [1880,1881]
name: e [1895,1896]
===
match
---
suite [1521,1542]
suite [1536,1557]
===
match
---
string: "UTF-8" [1794,1801]
string: "UTF-8" [1809,1816]
===
match
---
string: "linux" [1493,1500]
string: "linux" [1508,1515]
===
match
---
trailer [906,916]
trailer [921,931]
===
match
---
string: 'airflow' [1758,1767]
string: 'airflow' [1773,1782]
===
match
---
simple_stmt [786,831]
simple_stmt [786,831]
===
match
---
name: lower [1460,1465]
name: lower [1475,1480]
===
match
---
expr_stmt [1422,1467]
expr_stmt [1437,1482]
===
match
---
expr_stmt [1687,1705]
expr_stmt [1702,1720]
===
match
---
suite [1200,1559]
suite [1215,1574]
===
match
---
name: pkgutil [863,870]
name: pkgutil [878,885]
===
match
---
name: term [1422,1426]
name: term [1437,1441]
===
match
---
name: debug [1874,1879]
name: debug [1889,1894]
===
match
---
name: git_version [1687,1698]
name: git_version [1702,1713]
===
match
---
simple_stmt [1596,1683]
simple_stmt [1611,1698]
===
match
---
string: """Platform and system specific function.""" [786,830]
string: """Platform and system specific function.""" [786,830]
===
match
---
name: pkgutil [1741,1748]
name: pkgutil [1756,1763]
===
match
---
parameters [929,931]
parameters [944,946]
===
match
---
comparison [1475,1501]
comparison [1490,1516]
===
match
---
simple_stmt [1205,1269]
simple_stmt [1220,1284]
===
match
---
trailer [1439,1443]
trailer [1454,1458]
===
match
---
operator: = [1427,1428]
operator: = [1442,1443]
===
match
---
name: stdout [1141,1147]
name: stdout [1156,1162]
===
match
---
string: "win32" [1292,1299]
string: "win32" [1307,1314]
===
match
---
name: __name__ [907,915]
name: __name__ [922,930]
===
match
---
operator: -> [1192,1194]
operator: -> [1207,1209]
===
match
---
name: is_terminal_support_colors [1163,1189]
name: is_terminal_support_colors [1178,1204]
===
match
---
operator: = [1699,1700]
operator: = [1714,1715]
===
match
---
suite [1104,1126]
suite [1119,1141]
===
match
---
name: environ [1389,1396]
name: environ [1404,1411]
===
match
---
if_stmt [1472,1542]
if_stmt [1487,1557]
===
match
---
return_stmt [1546,1558]
return_stmt [1561,1573]
===
match
---
argument [1785,1801]
argument [1800,1816]
===
match
---
operator: = [1793,1794]
operator: = [1808,1809]
===
match
---
operator: , [1767,1768]
operator: , [1782,1783]
===
match
---
operator: == [1289,1291]
operator: == [1304,1306]
===
match
---
atom_expr [1386,1396]
atom_expr [1401,1411]
===
match
---
atom_expr [1074,1103]
atom_expr [1089,1118]
===
match
---
simple_stmt [1351,1364]
simple_stmt [1366,1379]
===
match
---
arglist [1741,1801]
arglist [1756,1816]
===
match
---
trailer [1879,1882]
trailer [1894,1897]
===
match
---
name: Exception [1814,1823]
name: Exception [1829,1838]
===
match
---
trailer [1147,1154]
trailer [1162,1169]
===
match
---
trailer [1140,1147]
trailer [1155,1162]
===
match
---
arglist [1444,1458]
arglist [1459,1473]
===
match
---
name: term [1516,1520]
name: term [1531,1535]
===
match
---
suite [932,1157]
suite [947,1172]
===
match
---
import_name [831,845]
import_name [846,860]
===
match
---
suite [1342,1364]
suite [1357,1379]
===
match
---
simple_stmt [871,882]
simple_stmt [886,897]
===
match
---
file_input [786,1907]
file_input [786,2736]
===
match
---
testlist_comp [1484,1500]
testlist_comp [1499,1515]
===
match
---
simple_stmt [846,856]
simple_stmt [861,871]
===
match
---
name: git_version [1723,1734]
name: git_version [1738,1749]
===
match
---
trailer [1873,1879]
trailer [1888,1894]
===
match
---
return_stmt [1406,1417]
return_stmt [1421,1432]
===
match
---
simple_stmt [1687,1706]
simple_stmt [1702,1721]
===
match
---
simple_stmt [1530,1542]
simple_stmt [1545,1557]
===
match
---
string: """Returns the git commit hash representing the current version of the application.""" [1596,1682]
string: """Returns the git commit hash representing the current version of the application.""" [1611,1697]
===
match
---
suite [1300,1322]
suite [1315,1337]
===
match
---
name: os [1429,1431]
name: os [1444,1446]
===
match
---
name: get_airflow_git_version [1565,1588]
name: get_airflow_git_version [1580,1603]
===
match
---
atom [1483,1501]
atom [1498,1516]
===
match
---
operator: = [887,888]
operator: = [902,903]
===
match
---
simple_stmt [1546,1559]
simple_stmt [1561,1574]
===
match
---
parameters [1189,1191]
parameters [1204,1206]
===
match
---
suite [1714,1803]
suite [1729,1818]
===
match
---
trailer [1279,1288]
trailer [1294,1303]
===
match
---
comparison [1505,1520]
comparison [1520,1535]
===
match
---
if_stmt [1067,1126]
if_stmt [1082,1141]
===
match
---
trailer [1465,1467]
trailer [1480,1482]
===
match
---
return_stmt [1351,1363]
return_stmt [1366,1378]
===
match
---
simple_stmt [831,846]
simple_stmt [846,861]
===
match
---
string: "COLORTERM" [1371,1382]
string: "COLORTERM" [1386,1397]
===
match
---
funcdef [919,1157]
funcdef [934,1172]
===
match
---
atom_expr [1082,1092]
atom_expr [1097,1107]
===
match
---
simple_stmt [1406,1418]
simple_stmt [1421,1433]
===
match
---
simple_stmt [856,871]
simple_stmt [871,886]
===
match
---
except_clause [1807,1828]
except_clause [1822,1843]
===
match
---
trailer [1740,1802]
trailer [1755,1817]
===
match
---
try_stmt [1710,1883]
try_stmt [1725,1898]
===
match
---
name: str [1737,1740]
name: str [1752,1755]
===
match
---
string: """     Checks if the standard output is connected (is associated with a terminal device) to a tty(-like)     device.     """ [937,1062]
string: """     Checks if the standard output is connected (is associated with a terminal device) to a tty(-like)     device.     """ [952,1077]
===
match
---
name: is_tty [923,929]
name: is_tty [938,944]
===
match
---
if_stmt [1368,1418]
if_stmt [1383,1433]
===
match
---
name: os [1386,1388]
name: os [1401,1403]
===
match
---
not_test [1070,1103]
not_test [1085,1118]
===
match
---
comparison [1371,1396]
comparison [1386,1411]
===
match
---
parameters [1588,1590]
parameters [1603,1605]
===
match
---
atom_expr [1137,1156]
atom_expr [1152,1171]
===
match
---
atom_expr [1737,1802]
atom_expr [1752,1817]
===
match
---
string: """Try to determine if the current terminal supports colors.""" [1205,1268]
string: """Try to determine if the current terminal supports colors.""" [1220,1283]
===
match
---
return_stmt [1309,1321]
return_stmt [1324,1336]
===
match
---
not_test [1329,1341]
not_test [1344,1356]
===
match
---
trailer [1085,1092]
trailer [1100,1107]
===
match
---
name: bool [1195,1199]
name: bool [1210,1214]
===
match
---
trailer [1443,1459]
trailer [1458,1474]
===
match
---
trailer [1339,1341]
trailer [1354,1356]
===
match
---
trailer [1388,1396]
trailer [1403,1411]
===
match
---
simple_stmt [1309,1322]
simple_stmt [1324,1337]
===
match
---
trailer [1748,1757]
trailer [1763,1772]
===
match
---
name: get_data [1749,1757]
name: get_data [1764,1772]
===
match
---
name: get [1440,1443]
name: get [1455,1458]
===
match
---
name: getLogger [897,906]
name: getLogger [912,921]
===
match
---
suite [1861,1883]
suite [1876,1898]
===
match
---
atom_expr [1276,1288]
atom_expr [1291,1303]
===
match
---
simple_stmt [1870,1883]
simple_stmt [1885,1898]
===
match
---
if_stmt [1273,1322]
if_stmt [1288,1337]
===
match
---
trailer [1757,1783]
trailer [1772,1798]
===
match
---
operator: = [1735,1736]
operator: = [1750,1751]
===
match
---
name: hasattr [1074,1081]
name: hasattr [1089,1096]
===
match
---
name: log [1870,1873]
name: log [1885,1888]
===
match
---
return_stmt [1130,1156]
return_stmt [1145,1171]
===
match
---
trailer [1081,1103]
trailer [1096,1118]
===
match
---
name: is_tty [1333,1339]
name: is_tty [1348,1354]
===
match
---
simple_stmt [1888,1907]
simple_stmt [1903,1922]
===
match
---
name: stdout [1086,1092]
name: stdout [1101,1107]
===
match
---
name: platform [1280,1288]
name: platform [1295,1303]
===
match
---
atom_expr [1741,1783]
atom_expr [1756,1798]
===
match
---
string: "isatty" [1094,1102]
string: "isatty" [1109,1117]
===
match
---
string: 'git_version' [1769,1782]
string: 'git_version' [1784,1797]
===
match
---
name: sys [878,881]
name: sys [893,896]
===
match
---
operator: , [1450,1451]
operator: , [1465,1466]
===
match
---
name: sys [1137,1140]
name: sys [1152,1155]
===
match
---
or_test [1475,1520]
or_test [1490,1535]
===
match
---
operator: , [1092,1093]
operator: , [1107,1108]
===
match
---
name: sys [1276,1279]
name: sys [1291,1294]
===
match
---
simple_stmt [1113,1126]
simple_stmt [1128,1141]
===
match
---
atom_expr [1333,1341]
atom_expr [1348,1356]
===
match
---
string: "xterm" [1484,1491]
string: "xterm" [1499,1506]
===
match
---
string: "dumb" [1452,1458]
string: "dumb" [1467,1473]
===
match
---
suite [1591,1907]
suite [1606,1922]
===
match
---
atom_expr [1870,1882]
atom_expr [1885,1897]
===
match
---
trailer [1459,1465]
trailer [1474,1480]
===
match
---
simple_stmt [937,1063]
simple_stmt [952,1078]
===
match
---
import_name [871,881]
import_name [886,896]
===
match
---
name: term [1475,1479]
name: term [1490,1494]
===
match
---
name: git_version [1895,1906]
name: git_version [1910,1921]
===
insert-tree
---
simple_stmt [831,846]
    import_name [831,845]
        name: getpass [838,845]
to
file_input [786,1907]
at 1
===
insert-tree
---
funcdef [1924,2736]
    name: getuser [1928,1935]
    parameters [1935,1937]
    operator: -> [1938,1940]
    name: str [1941,1944]
    suite [1945,2736]
        simple_stmt [1950,2307]
            string: """     Gets the username associated with the current user, or error with a nice     error message if there's no current user.      We don't want to fall back to os.getuid() because not having a username     probably means the rest of the user environment is wrong (e.g. no $HOME).     Explicit failure is better than silently trying to work badly.     """ [1950,2306]
        try_stmt [2311,2736]
            suite [2315,2349]
                simple_stmt [2324,2349]
                    return_stmt [2324,2348]
                        atom_expr [2331,2348]
                            name: getpass [2331,2338]
                            trailer [2338,2346]
                                name: getuser [2339,2346]
                            trailer [2346,2348]
            except_clause [2353,2368]
                name: KeyError [2360,2368]
            suite [2369,2736]
                simple_stmt [2426,2480]
                    import_from [2426,2479]
                        dotted_name [2431,2449]
                            name: airflow [2431,2438]
                            name: exceptions [2439,2449]
                        name: AirflowConfigException [2457,2479]
                simple_stmt [2489,2736]
                    raise_stmt [2489,2735]
                        atom_expr [2495,2735]
                            name: AirflowConfigException [2495,2517]
                            trailer [2517,2735]
                                strings [2531,2725]
                                    string: "The user that Airflow is running as has no username; you must run" [2531,2598]
                                    string: "Airflow as a full user, with a username and home directory, " [2611,2673]
                                    string: "in order for it to function properly." [2686,2725]
to
file_input [786,1907]
at 10
