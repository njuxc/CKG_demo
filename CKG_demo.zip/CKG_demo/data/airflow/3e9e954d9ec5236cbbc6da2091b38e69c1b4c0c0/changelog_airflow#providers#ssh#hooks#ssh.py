===
match
---
name: base64 [865,871]
name: base64 [850,856]
===
match
---
trailer [5428,5434]
trailer [5518,5524]
===
match
---
trailer [3518,3527]
trailer [3608,3617]
===
match
---
operator: = [2452,2453]
operator: = [2542,2543]
===
match
---
name: self [5265,5269]
name: self [5355,5359]
===
match
---
trailer [7090,7092]
trailer [7172,7174]
===
match
---
operator: -> [2772,2774]
operator: -> [2862,2864]
===
match
---
name: str [11604,11607]
name: str [11686,11689]
===
match
---
name: exc_tb [9897,9903]
name: exc_tb [9979,9985]
===
match
---
trailer [4243,4252]
trailer [4333,4342]
===
match
---
expr_stmt [4320,4349]
expr_stmt [4410,4439]
===
match
---
string: "key_file" [4616,4626]
string: "key_file" [4706,4716]
===
match
---
operator: = [5970,5971]
operator: = [6060,6061]
===
match
---
expr_stmt [4407,4435]
expr_stmt [4497,4525]
===
match
---
name: extra_options [5351,5364]
name: extra_options [5441,5454]
===
match
---
name: keepalive_interval [3666,3684]
name: keepalive_interval [3756,3774]
===
match
---
trailer [5860,5892]
trailer [5950,5982]
===
match
---
param [10098,10130]
param [10180,10212]
===
match
---
suite [4917,5026]
suite [5007,5116]
===
match
---
name: config_fd [7186,7195]
name: config_fd [7268,7277]
===
match
---
trailer [6033,6051]
trailer [6123,6141]
===
match
---
expr_stmt [6082,6155]
expr_stmt [6172,6245]
===
match
---
suite [8493,8633]
suite [8575,8715]
===
match
---
name: self [10960,10964]
name: self [11042,11046]
===
match
---
simple_stmt [9131,9172]
simple_stmt [9213,9254]
===
match
---
atom_expr [6846,6862]
atom_expr [6936,6952]
===
match
---
comparison [5194,5243]
comparison [5284,5333]
===
match
---
simple_stmt [11244,11319]
simple_stmt [11326,11401]
===
match
---
name: lower [5668,5673]
name: lower [5758,5763]
===
match
---
name: allow_host_key_change [5730,5751]
name: allow_host_key_change [5820,5841]
===
match
---
trailer [9101,9110]
trailer [9183,9192]
===
match
---
name: key_file [7445,7453]
name: key_file [7527,7535]
===
match
---
arglist [10862,11149]
arglist [10944,11231]
===
match
---
trailer [5641,5666]
trailer [5731,5756]
===
match
---
atom_expr [4691,4704]
atom_expr [4781,4794]
===
match
---
name: ssh_conf [7221,7229]
name: ssh_conf [7303,7311]
===
match
---
operator: == [5437,5439]
operator: == [5527,5529]
===
match
---
if_stmt [7924,8181]
if_stmt [8006,8263]
===
match
---
trailer [8178,8180]
trailer [8260,8262]
===
match
---
trailer [9221,9228]
trailer [9303,9310]
===
match
---
try_stmt [12749,12955]
try_stmt [12831,13037]
===
match
---
atom_expr [5857,5900]
atom_expr [5947,5990]
===
match
---
name: self [10042,10046]
name: self [10124,10128]
===
match
---
atom_expr [8529,8551]
atom_expr [8611,8633]
===
match
---
name: port [8941,8945]
name: port [9023,9027]
===
match
---
if_stmt [9922,10013]
if_stmt [10004,10095]
===
match
---
tfpdef [11573,11589]
tfpdef [11655,11671]
===
match
---
string: "relabeling" [2896,2908]
string: "relabeling" [2986,2998]
===
match
---
name: timeout [8884,8891]
name: timeout [8966,8973]
===
match
---
expr_stmt [4140,4184]
expr_stmt [4230,4274]
===
match
---
name: username [10912,10920]
name: username [10994,11002]
===
match
---
param [12289,12294]
param [12371,12376]
===
match
---
trailer [4954,4977]
trailer [5044,5067]
===
match
---
atom_expr [3630,3642]
atom_expr [3720,3732]
===
match
---
name: username [3140,3148]
name: username [3230,3238]
===
match
---
expr_stmt [10783,10818]
expr_stmt [10865,10900]
===
match
---
dotted_name [985,1000]
dotted_name [970,985]
===
match
---
atom_expr [8589,8605]
atom_expr [8671,8687]
===
match
---
suite [12364,13183]
suite [12446,13265]
===
match
---
simple_stmt [10674,10757]
simple_stmt [10756,10839]
===
match
---
name: self [6890,6894]
name: self [6980,6984]
===
match
---
name: self [9496,9500]
name: self [9578,9582]
===
match
---
name: close [9974,9979]
name: close [10056,10061]
===
match
---
name: remote_host [12232,12243]
name: remote_host [12314,12325]
===
match
---
trailer [8584,8588]
trailer [8666,8670]
===
match
---
name: Union [10694,10699]
name: Union [10776,10781]
===
match
---
expr_stmt [6890,6923]
expr_stmt [6980,7005]
===
match
---
suite [9949,10013]
suite [10031,10095]
===
match
---
name: client_host_keys [8510,8526]
name: client_host_keys [8592,8608]
===
match
---
if_stmt [4197,4266]
if_stmt [4287,4356]
===
match
---
argument [12826,12845]
argument [12908,12927]
===
match
---
name: warnings [11889,11897]
name: warnings [11971,11979]
===
match
---
string: "allow_host_key_change" [5559,5582]
string: "allow_host_key_change" [5649,5672]
===
match
---
operator: = [2690,2691]
operator: = [2780,2781]
===
match
---
name: decodebytes [879,890]
name: decodebytes [864,875]
===
match
---
atom_expr [4842,4885]
atom_expr [4932,4975]
===
match
---
operator: = [3821,3822]
operator: = [3911,3912]
===
match
---
import_name [844,859]
import_name [829,844]
===
match
---
name: self [6176,6180]
name: self [6266,6270]
===
match
---
operator: , [9895,9896]
operator: , [9977,9978]
===
match
---
operator: , [7857,7858]
operator: , [7939,7940]
===
match
---
name: client [11432,11438]
name: client [11514,11520]
===
match
---
trailer [9357,9375]
trailer [9439,9457]
===
match
---
name: host_info [7284,7293]
name: host_info [7366,7375]
===
match
---
name: extra_options [4768,4781]
name: extra_options [4858,4871]
===
match
---
comparison [4365,4389]
comparison [4455,4479]
===
match
---
name: user_ssh_config_filename [7115,7139]
name: user_ssh_config_filename [7197,7221]
===
match
---
simple_stmt [4407,4436]
simple_stmt [4497,4526]
===
match
---
string: """         Creates appropriate paramiko key for given private key          :param private_key: string containing private key         :return: `paramiko.PKey` appropriate for given key         :raises AirflowException: if key cannot be read         """ [12373,12625]
string: """         Creates appropriate paramiko key for given private key          :param private_key: string containing private key         :return: `paramiko.PKey` appropriate for given key         :raises AirflowException: if key cannot be read         """ [12455,12707]
===
match
---
operator: = [7070,7071]
operator: = [7152,7153]
===
match
---
simple_stmt [6622,6878]
simple_stmt [6712,6968]
===
match
---
trailer [8588,8632]
trailer [8670,8714]
===
match
---
trailer [4859,4885]
trailer [4949,4975]
===
match
---
name: os [841,843]
name: os [826,828]
===
match
---
name: ssh_username [10894,10906]
name: ssh_username [10976,10988]
===
match
---
name: conn [4426,4430]
name: conn [4516,4520]
===
match
---
name: warnings [851,859]
name: warnings [836,844]
===
match
---
operator: = [8945,8946]
operator: = [9027,9028]
===
match
---
name: self [3836,3840]
name: self [3926,3930]
===
match
---
or_test [7423,7453]
or_test [7505,7535]
===
match
---
trailer [9594,9599]
trailer [9676,9681]
===
match
---
parameters [11540,11627]
parameters [11622,11709]
===
match
---
trailer [5097,5105]
trailer [5187,5195]
===
match
---
arglist [12219,12255]
arglist [12301,12337]
===
match
---
simple_stmt [2702,2720]
simple_stmt [2792,2810]
===
match
---
atom_expr [4021,4032]
atom_expr [4111,4122]
===
match
---
suite [8650,8752]
suite [8732,8834]
===
match
---
name: SSHClient [7668,7677]
name: SSHClient [7750,7759]
===
match
---
name: conn [4336,4340]
name: conn [4426,4430]
===
match
---
name: str [12308,12311]
name: str [12390,12393]
===
match
---
trailer [4411,4423]
trailer [4501,4513]
===
match
---
string: 'localhost' [10805,10816]
string: 'localhost' [10887,10898]
===
match
---
name: ssh_conn_id [7864,7875]
name: ssh_conn_id [7946,7957]
===
match
---
operator: = [4033,4034]
operator: = [4123,4124]
===
match
---
operator: = [11208,11209]
operator: = [11290,11291]
===
match
---
if_stmt [7004,7589]
if_stmt [7086,7671]
===
match
---
name: key_file [4696,4704]
name: key_file [4786,4794]
===
match
---
name: str [10079,10082]
name: str [10161,10164]
===
match
---
name: os [7007,7009]
name: os [7089,7091]
===
match
---
string: "localhost" [11610,11621]
string: "localhost" [11692,11703]
===
match
---
name: __init__ [3384,3392]
name: __init__ [3474,3482]
===
match
---
atom_expr [8914,8927]
atom_expr [8996,9009]
===
match
---
trailer [7014,7021]
trailer [7096,7103]
===
match
---
name: self [9994,9998]
name: self [10076,10080]
===
match
---
name: update [11359,11365]
name: update [11441,11447]
===
match
---
trailer [9305,9333]
trailer [9387,9415]
===
match
---
atom_expr [6256,6269]
atom_expr [6346,6359]
===
match
---
suite [7154,7197]
suite [7236,7279]
===
match
---
operator: = [9508,9509]
operator: = [9590,9591]
===
match
---
atom_expr [6192,6230]
atom_expr [6282,6320]
===
match
---
name: SSHConfig [7081,7090]
name: SSHConfig [7163,7172]
===
match
---
name: client [4026,4032]
name: client [4116,4122]
===
match
---
trailer [12811,12824]
trailer [12893,12906]
===
match
---
name: self [9925,9929]
name: self [10007,10011]
===
match
---
name: int [11586,11589]
name: int [11668,11671]
===
match
---
param [11550,11555]
param [11632,11637]
===
match
---
name: no_host_key_check [6034,6051]
name: no_host_key_check [6124,6141]
===
match
---
operator: , [2947,2948]
operator: , [3037,3038]
===
match
---
param [10066,10097]
param [10148,10179]
===
match
---
name: DSSKey [2480,2486]
name: DSSKey [2570,2576]
===
match
---
simple_stmt [964,980]
simple_stmt [949,965]
===
match
---
trailer [7114,7140]
trailer [7196,7222]
===
match
---
operator: = [8878,8879]
operator: = [8960,8961]
===
match
---
atom_expr [12803,12824]
atom_expr [12885,12906]
===
match
---
trailer [4171,4183]
trailer [4261,4273]
===
match
---
simple_stmt [3580,3597]
simple_stmt [3670,3687]
===
match
---
expr_stmt [2642,2675]
expr_stmt [2732,2765]
===
match
---
trailer [5125,5136]
trailer [5215,5226]
===
match
---
simple_stmt [4938,5026]
simple_stmt [5028,5116]
===
match
---
name: look_for_keys [9022,9035]
name: look_for_keys [9104,9117]
===
match
---
atom_expr [3442,3458]
atom_expr [3532,3548]
===
match
---
expr_stmt [3481,3505]
expr_stmt [3571,3595]
===
match
---
trailer [6260,6269]
trailer [6350,6359]
===
match
---
name: client [9532,9538]
name: client [9614,9620]
===
match
---
trailer [7602,7607]
trailer [7684,7689]
===
match
---
trailer [7080,7090]
trailer [7162,7172]
===
match
---
atom_expr [3580,3589]
atom_expr [3670,3679]
===
match
---
tfpdef [11556,11571]
tfpdef [11638,11653]
===
match
---
name: paramiko [6192,6200]
name: paramiko [6282,6290]
===
match
---
name: str [12334,12337]
name: str [12416,12419]
===
match
---
name: self [4021,4025]
name: self [4111,4115]
===
match
---
name: port [7615,7619]
name: port [7697,7701]
===
match
---
funcdef [12262,13183]
funcdef [12344,13265]
===
match
---
name: client [9967,9973]
name: client [10049,10055]
===
match
---
operator: -> [3359,3361]
operator: -> [3449,3451]
===
match
---
param [3180,3211]
param [3270,3301]
===
match
---
name: warn [11898,11902]
name: warn [11980,11984]
===
match
---
simple_stmt [4140,4185]
simple_stmt [4230,4275]
===
match
---
operator: = [3420,3421]
operator: = [3510,3511]
===
match
---
atom_expr [7284,7313]
atom_expr [7366,7395]
===
match
---
name: client [9501,9507]
name: client [9583,9589]
===
match
---
name: paramiko [7349,7357]
name: paramiko [7431,7439]
===
match
---
import_name [964,979]
import_name [949,964]
===
match
---
name: remote_port [10048,10059]
name: remote_port [10130,10141]
===
match
---
name: expanduser [6968,6978]
name: expanduser [7050,7060]
===
match
---
name: look_for_keys [9003,9016]
name: look_for_keys [9085,9098]
===
match
---
trailer [4324,4333]
trailer [4414,4423]
===
match
---
tfpdef [3140,3163]
tfpdef [3230,3253]
===
match
---
trailer [8237,8245]
trailer [8319,8327]
===
match
---
comparison [5997,6024]
comparison [6087,6114]
===
match
---
atom_expr [7556,7588]
atom_expr [7638,7670]
===
match
---
operator: , [12243,12244]
operator: , [12325,12326]
===
match
---
atom_expr [7598,7607]
atom_expr [7680,7689]
===
match
---
string: 'This wont protect against Man-In-The-Middle attacks' [8070,8123]
string: 'This wont protect against Man-In-The-Middle attacks' [8152,8205]
===
match
---
arglist [8589,8631]
arglist [8671,8713]
===
match
---
atom_expr [5389,5436]
atom_expr [5479,5526]
===
match
---
atom_expr [4579,4596]
atom_expr [4669,4686]
===
match
---
string: 'private_key' [4786,4799]
string: 'private_key' [4876,4889]
===
match
---
atom_expr [7331,7346]
atom_expr [7413,7428]
===
match
---
name: update [9222,9228]
name: update [9304,9310]
===
match
---
atom_expr [4498,4507]
atom_expr [4588,4597]
===
match
---
trailer [2479,2486]
trailer [2569,2576]
===
match
---
name: str [5857,5860]
name: str [5947,5950]
===
match
---
trailer [7021,7047]
trailer [7103,7129]
===
match
---
suite [1221,13183]
suite [1311,13265]
===
match
---
trailer [9998,10005]
trailer [10080,10087]
===
match
---
name: username [8849,8857]
name: username [8931,8939]
===
match
---
name: client_host_keys [8568,8584]
name: client_host_keys [8650,8666]
===
match
---
name: from_private_key [12786,12802]
name: from_private_key [12868,12884]
===
match
---
name: extra_options [5393,5406]
name: extra_options [5483,5496]
===
match
---
name: lower [5225,5230]
name: lower [5315,5320]
===
match
---
trailer [9188,9193]
trailer [9270,9275]
===
match
---
trailer [11223,11229]
trailer [11305,11311]
===
match
---
name: get_tunnel [12208,12218]
name: get_tunnel [12290,12300]
===
match
---
string: 'identityfile' [7503,7517]
string: 'identityfile' [7585,7599]
===
match
---
testlist_comp [10805,10817]
testlist_comp [10887,10899]
===
match
---
string: "host_key" [5997,6007]
string: "host_key" [6087,6097]
===
match
---
simple_stmt [12373,12626]
simple_stmt [12455,12708]
===
match
---
comp_op [4115,4121]
comp_op [4205,4211]
===
match
---
decorator [2725,2739]
decorator [2815,2829]
===
match
---
atom [7422,7454]
atom [7504,7536]
===
match
---
operator: = [10006,10007]
operator: = [10088,10089]
===
match
---
operator: = [11139,11140]
operator: = [11221,11222]
===
match
---
operator: , [11148,11149]
operator: , [11230,11231]
===
match
---
atom_expr [5624,5675]
atom_expr [5714,5765]
===
match
---
simple_stmt [9496,9517]
simple_stmt [9578,9599]
===
match
---
name: extra_options [6011,6024]
name: extra_options [6101,6114]
===
match
---
trailer [4724,4736]
trailer [4814,4826]
===
match
---
import_name [834,843]
import_name [819,828]
===
match
---
name: int [3305,3308]
name: int [3395,3398]
===
match
---
operator: = [4496,4497]
operator: = [4586,4587]
===
match
---
operator: , [9822,9823]
operator: , [9904,9905]
===
match
---
name: AirflowException [6289,6305]
name: AirflowException [6379,6395]
===
match
---
atom_expr [5194,5232]
atom_expr [5284,5322]
===
match
---
arglist [11916,12176]
arglist [11998,12258]
===
match
---
expr_stmt [3403,3433]
expr_stmt [3493,3523]
===
match
---
name: keepalive_interval [9393,9411]
name: keepalive_interval [9475,9493]
===
match
---
trailer [11897,11902]
trailer [11979,11984]
===
match
---
name: passphrase [12313,12323]
name: passphrase [12395,12405]
===
match
---
expr_stmt [5725,5758]
expr_stmt [5815,5848]
===
match
---
name: timeout [3296,3303]
name: timeout [3386,3393]
===
match
---
name: port [4491,4495]
name: port [4581,4585]
===
match
---
operator: = [6904,6905]
operator: = [6994,6995]
===
match
---
operator: , [3313,3314]
operator: , [3403,3404]
===
match
---
with_stmt [7105,7197]
with_stmt [7187,7279]
===
match
---
atom_expr [4950,5025]
atom_expr [5040,5115]
===
match
---
suite [5244,5287]
suite [5334,5377]
===
match
---
trailer [5898,5900]
trailer [5988,5990]
===
match
---
suite [9412,9487]
suite [9494,9569]
===
match
---
operator: , [938,939]
operator: , [923,924]
===
match
---
name: path [7010,7014]
name: path [7092,7096]
===
match
---
name: user_ssh_config_filename [7022,7046]
name: user_ssh_config_filename [7104,7128]
===
match
---
expr_stmt [11199,11231]
expr_stmt [11281,11313]
===
match
---
name: strip [11224,11229]
name: strip [11306,11311]
===
match
---
trailer [3407,3419]
trailer [3497,3509]
===
match
---
name: host_proxy [10998,11008]
name: host_proxy [11080,11090]
===
match
---
name: path [6963,6967]
name: path [7045,7049]
===
match
---
suite [11186,11319]
suite [11268,11401]
===
match
---
trailer [7667,7677]
trailer [7749,7759]
===
match
---
trailer [9973,9979]
trailer [10055,10061]
===
match
---
param [9878,9887]
param [9960,9969]
===
match
---
trailer [12985,13182]
trailer [13067,13264]
===
match
---
name: get_conn [7641,7649]
name: get_conn [7723,7731]
===
match
---
if_stmt [8464,8752]
if_stmt [8546,8834]
===
match
---
name: remote_host [3097,3108]
name: remote_host [3187,3198]
===
match
---
argument [10934,10969]
argument [11016,11051]
===
match
---
trailer [5111,5141]
trailer [5201,5231]
===
match
---
operator: = [3685,3686]
operator: = [3775,3776]
===
match
---
name: password [9102,9110]
name: password [9184,9192]
===
match
---
trailer [5230,5232]
trailer [5320,5322]
===
match
---
name: str [5389,5392]
name: str [5479,5482]
===
match
---
expr_stmt [4817,4885]
expr_stmt [4907,4975]
===
match
---
if_stmt [8190,8752]
if_stmt [8272,8834]
===
match
---
import_from [860,890]
import_from [845,875]
===
match
---
if_stmt [4902,5026]
if_stmt [4992,5116]
===
match
---
name: key [12870,12873]
name: key [12952,12955]
===
match
---
name: pkey [9189,9193]
name: pkey [9271,9275]
===
match
---
name: self [5725,5729]
name: self [5815,5819]
===
match
---
name: ProxyCommand [7358,7370]
name: ProxyCommand [7440,7452]
===
match
---
trailer [4490,4495]
trailer [4580,4585]
===
match
---
string: 'ssh-rsa' [8607,8616]
string: 'ssh-rsa' [8689,8698]
===
match
---
suite [6609,6924]
suite [6699,7006]
===
match
---
simple_stmt [9842,9854]
simple_stmt [9924,9936]
===
match
---
name: logger [11133,11139]
name: logger [11215,11221]
===
match
---
name: lookup [7230,7236]
name: lookup [7312,7318]
===
match
---
trailer [3446,3458]
trailer [3536,3548]
===
match
---
if_stmt [4362,4436]
if_stmt [4452,4526]
===
match
---
comparison [4451,4468]
comparison [4541,4558]
===
match
---
name: remote_port [11573,11584]
name: remote_port [11655,11666]
===
match
---
atom [5306,5465]
atom [5396,5555]
===
match
---
trailer [6246,6251]
trailer [6336,6341]
===
match
---
trailer [3392,3394]
trailer [3482,3484]
===
match
---
operator: = [3459,3460]
operator: = [3549,3550]
===
match
---
operator: , [3170,3171]
operator: , [3260,3261]
===
match
---
operator: -> [9564,9566]
operator: -> [9646,9648]
===
match
---
atom_expr [7610,7619]
atom_expr [7692,7701]
===
match
---
atom_expr [4648,4661]
atom_expr [4738,4751]
===
match
---
atom_expr [8229,8326]
atom_expr [8311,8408]
===
match
---
simple_stmt [5093,5142]
simple_stmt [5183,5232]
===
match
---
operator: == [5233,5235]
operator: == [5323,5325]
===
match
---
arglist [11383,11408]
arglist [11465,11490]
===
match
---
operator: = [7219,7220]
operator: = [7301,7302]
===
match
---
name: host_proxy [3884,3894]
name: host_proxy [3974,3984]
===
match
---
name: self [7423,7427]
name: self [7505,7509]
===
match
---
operator: = [9318,9319]
operator: = [9400,9401]
===
match
---
atom_expr [5108,5141]
atom_expr [5198,5231]
===
match
---
trailer [3883,3894]
trailer [3973,3984]
===
match
---
suite [4469,4508]
suite [4559,4598]
===
match
---
name: paramiko [2579,2587]
name: paramiko [2669,2677]
===
match
---
trailer [7241,7253]
trailer [7323,7335]
===
match
---
trailer [3584,3589]
trailer [3674,3679]
===
match
---
name: remote_host [3461,3472]
name: remote_host [3551,3562]
===
match
---
string: " %s. Using system's default provided by getpass.getuser()" [6735,6794]
string: " %s. Using system's default provided by getpass.getuser()" [6825,6884]
===
match
---
expr_stmt [2429,2601]
expr_stmt [2519,2691]
===
match
---
name: passphrase [4991,5001]
name: passphrase [5081,5091]
===
match
---
atom_expr [9207,9244]
atom_expr [9289,9326]
===
match
---
trailer [6138,6145]
trailer [6228,6235]
===
match
---
trailer [12689,12691]
trailer [12771,12773]
===
match
---
name: self [6242,6246]
name: self [6332,6336]
===
match
---
name: keepalive_interval [3687,3705]
name: keepalive_interval [3777,3795]
===
match
---
suite [5466,5518]
suite [5556,5608]
===
match
---
trailer [4455,4460]
trailer [4545,4550]
===
match
---
comparison [4200,4221]
comparison [4290,4311]
===
match
---
name: get_transport [9432,9445]
name: get_transport [9514,9527]
===
match
---
name: ssh_exception [12902,12915]
name: ssh_exception [12984,12997]
===
match
---
name: self [3547,3551]
name: self [3637,3641]
===
match
---
name: remote_host [4370,4381]
name: remote_host [4460,4471]
===
match
---
name: base [1126,1130]
name: base [1111,1115]
===
match
---
number: 10 [5138,5140]
number: 10 [5228,5230]
===
match
---
atom_expr [4255,4265]
atom_expr [4345,4355]
===
match
---
atom_expr [6470,6525]
atom_expr [6560,6615]
===
match
---
atom_expr [4523,4533]
atom_expr [4613,4623]
===
match
---
string: 'This method will be removed in Airflow 2.0' [12090,12134]
string: 'This method will be removed in Airflow 2.0' [12172,12216]
===
match
---
name: ssh_conn_id [3408,3419]
name: ssh_conn_id [3498,3509]
===
match
---
trailer [9500,9507]
trailer [9582,9589]
===
match
---
suite [9194,9245]
suite [9276,9327]
===
match
---
tfpdef [3260,3279]
tfpdef [3350,3369]
===
match
---
name: private_key [12295,12306]
name: private_key [12377,12388]
===
match
---
simple_stmt [7171,7197]
simple_stmt [7253,7279]
===
match
---
parameters [9557,9563]
parameters [9639,9645]
===
match
---
name: password [11199,11207]
name: password [11281,11289]
===
match
---
operator: = [10124,10125]
operator: = [10206,10207]
===
match
---
atom_expr [3190,3203]
atom_expr [3280,3293]
===
match
---
import_from [980,1016]
import_from [965,1001]
===
match
---
operator: , [8821,8822]
operator: , [8903,8904]
===
match
---
atom_expr [8805,8821]
atom_expr [8887,8903]
===
match
---
string: "no_host_key_check" [5407,5426]
string: "no_host_key_check" [5497,5516]
===
match
---
operator: = [11404,11405]
operator: = [11486,11487]
===
match
---
name: self [10871,10875]
name: self [10953,10957]
===
match
---
name: int [5108,5111]
name: int [5198,5201]
===
match
---
trailer [7902,7912]
trailer [7984,7994]
===
match
---
name: pkey_type [12704,12713]
name: pkey_type [12786,12795]
===
match
---
argument [4991,5024]
argument [5081,5114]
===
match
---
name: self [11210,11214]
name: self [11292,11296]
===
match
---
operator: = [4577,4578]
operator: = [4667,4668]
===
match
---
string: 'false' [5904,5911]
string: 'false' [5994,6001]
===
match
---
string: 'SSHHook' [9567,9576]
string: 'SSHHook' [9649,9658]
===
match
---
name: self [6256,6260]
name: self [6346,6350]
===
match
---
operator: , [6828,6829]
operator: , [6918,6919]
===
match
---
atom_expr [3481,3494]
atom_expr [3571,3584]
===
match
---
simple_stmt [860,891]
simple_stmt [845,876]
===
match
---
simple_stmt [891,915]
simple_stmt [876,900]
===
match
---
atom_expr [9184,9193]
atom_expr [9266,9275]
===
match
---
name: extra_options [4842,4855]
name: extra_options [4932,4945]
===
match
---
strings [8005,8123]
strings [8087,8205]
===
match
---
expr_stmt [3605,3621]
expr_stmt [3695,3711]
===
match
---
atom_expr [5112,5136]
atom_expr [5202,5226]
===
match
---
name: ssh_port [10862,10870]
name: ssh_port [10944,10952]
===
match
---
argument [11133,11148]
argument [11215,11230]
===
match
---
name: self [6595,6599]
name: self [6685,6689]
===
match
---
atom_expr [9994,10005]
atom_expr [10076,10087]
===
match
---
comp_op [9937,9943]
comp_op [10019,10025]
===
match
---
expr_stmt [8761,9046]
expr_stmt [8843,9128]
===
match
---
operator: = [8843,8844]
operator: = [8925,8926]
===
match
---
name: timeout [3645,3652]
name: timeout [3735,3742]
===
match
---
atom [5537,5703]
atom [5627,5793]
===
match
---
name: host_info [7270,7279]
name: host_info [7352,7361]
===
match
---
not_test [6591,6608]
not_test [6681,6698]
===
match
---
simple_stmt [3630,3653]
simple_stmt [3720,3743]
===
match
---
name: Ed25519Key [2552,2562]
name: Ed25519Key [2642,2652]
===
match
---
name: warnings [9586,9594]
name: warnings [9668,9676]
===
match
---
atom_expr [9234,9243]
atom_expr [9316,9325]
===
match
---
trailer [6305,6417]
trailer [6395,6507]
===
match
---
name: SSHTunnelForwarder [10140,10158]
name: SSHTunnelForwarder [10222,10240]
===
match
---
name: self [8946,8950]
name: self [9028,9032]
===
match
---
atom_expr [12893,12928]
atom_expr [12975,13010]
===
match
---
atom_expr [12350,12363]
atom_expr [12432,12445]
===
match
---
name: StringIO [12803,12811]
name: StringIO [12885,12893]
===
match
---
arglist [4978,5024]
arglist [5068,5114]
===
match
---
atom_expr [7007,7047]
atom_expr [7089,7129]
===
match
---
operator: , [9876,9877]
operator: , [9958,9959]
===
match
---
name: username [3497,3505]
name: username [3587,3595]
===
match
---
argument [9153,9170]
argument [9235,9252]
===
match
---
trailer [4259,4265]
trailer [4349,4355]
===
match
---
name: SSH_PORT [7623,7631]
name: SSH_PORT [7705,7713]
===
match
---
name: str [3119,3122]
name: str [3209,3212]
===
match
---
string: "key_file" [4725,4735]
string: "key_file" [4815,4825]
===
match
---
trailer [11229,11231]
trailer [11311,11313]
===
match
---
name: airflow [1112,1119]
name: airflow [1097,1104]
===
match
---
suite [12736,12955]
suite [12818,13037]
===
match
---
name: SSHClient [7903,7912]
name: SSHClient [7985,7994]
===
match
---
name: get [4856,4859]
name: get [4946,4949]
===
match
---
trailer [12358,12363]
trailer [12440,12445]
===
match
---
name: get_tunnel [10022,10032]
name: get_tunnel [10104,10114]
===
match
---
atom_expr [9131,9171]
atom_expr [9213,9253]
===
match
---
trailer [10911,10920]
trailer [10993,11002]
===
match
---
string: 'ssh_default' [2662,2675]
string: 'ssh_default' [2752,2765]
===
match
---
name: ssh_conn_id [6851,6862]
name: ssh_conn_id [6941,6952]
===
match
---
name: self [4281,4285]
name: self [4371,4375]
===
match
---
operator: } [2600,2601]
operator: } [2690,2691]
===
match
---
or_test [10943,10969]
or_test [11025,11051]
===
match
---
name: extra_options [4630,4643]
name: extra_options [4720,4733]
===
match
---
trailer [9110,9116]
trailer [9192,9198]
===
match
---
string: 'key formats: RSA, DSS, ECDSA, or Ed25519' [13130,13172]
string: 'key formats: RSA, DSS, ECDSA, or Ed25519' [13212,13254]
===
match
---
name: conn [4498,4502]
name: conn [4588,4592]
===
match
---
operator: = [12156,12157]
operator: = [12238,12239]
===
match
---
name: pkey [3585,3589]
name: pkey [3675,3679]
===
match
---
trailer [8197,8215]
trailer [8279,8297]
===
match
---
expr_stmt [3798,3827]
expr_stmt [3888,3917]
===
match
---
string: 'Creating SSH client for conn_id: %s' [7820,7857]
string: 'Creating SSH client for conn_id: %s' [7902,7939]
===
match
---
trailer [3551,3560]
trailer [3641,3650]
===
match
---
expr_stmt [3769,3789]
expr_stmt [3859,3879]
===
match
---
simple_stmt [4239,4266]
simple_stmt [4329,4356]
===
match
---
suite [8451,8752]
suite [8533,8834]
===
match
---
operator: = [9803,9804]
operator: = [9885,9886]
===
match
---
parameters [9871,9904]
parameters [9953,9986]
===
match
---
arglist [8796,9036]
arglist [8878,9118]
===
match
---
trailer [7427,7436]
trailer [7509,7518]
===
match
---
atom_expr [3110,3123]
atom_expr [3200,3213]
===
match
---
name: client [9999,10005]
name: client [10081,10087]
===
match
---
trailer [8156,8178]
trailer [8238,8260]
===
match
---
and_test [4616,4669]
and_test [4706,4759]
===
match
---
name: extra_options [5861,5874]
name: extra_options [5951,5964]
===
match
---
funcdef [11523,12257]
funcdef [11605,12339]
===
match
---
atom_expr [5487,5509]
atom_expr [5577,5599]
===
match
---
name: RSAKey [2588,2594]
name: RSAKey [2678,2684]
===
match
---
suite [12929,12955]
suite [13011,13037]
===
match
---
and_test [5162,5243]
and_test [5252,5333]
===
match
---
param [9872,9877]
param [9954,9959]
===
match
---
simple_stmt [7598,7632]
simple_stmt [7680,7714]
===
match
---
atom_expr [6906,6923]
atom_expr [6996,7005]
===
match
---
name: self [8229,8233]
name: self [8311,8315]
===
match
---
name: self [5951,5955]
name: self [6041,6045]
===
match
---
name: int [11568,11571]
name: int [11650,11653]
===
match
---
string: 'false' [5236,5243]
string: 'false' [5326,5333]
===
match
---
atom_expr [9496,9507]
atom_expr [9578,9589]
===
match
---
param [12295,12312]
param [12377,12394]
===
match
---
string: 'The contextmanager of SSHHook is deprecated.' [9613,9659]
string: 'The contextmanager of SSHHook is deprecated.' [9695,9741]
===
match
---
return_stmt [9842,9853]
return_stmt [9924,9935]
===
match
---
name: DeprecationWarning [9804,9822]
name: DeprecationWarning [9886,9904]
===
match
---
name: port [4503,4507]
name: port [4593,4597]
===
match
---
trailer [7565,7569]
trailer [7647,7651]
===
match
---
name: self [3798,3802]
name: self [3888,3892]
===
match
---
name: username [4205,4213]
name: username [4295,4303]
===
match
---
comparison [4281,4302]
comparison [4371,4392]
===
match
---
atom_expr [10717,10727]
atom_expr [10799,10809]
===
match
---
operator: = [3309,3310]
operator: = [3399,3400]
===
match
---
simple_stmt [3514,3539]
simple_stmt [3604,3629]
===
match
---
trailer [5211,5223]
trailer [5301,5313]
===
match
---
name: self [9097,9101]
name: self [9179,9183]
===
match
---
suite [9073,9172]
suite [9155,9254]
===
match
---
name: create_tunnel [11527,11540]
name: create_tunnel [11609,11622]
===
match
---
suite [5072,5142]
suite [5162,5232]
===
match
---
atom_expr [6595,6608]
atom_expr [6685,6698]
===
match
---
operator: = [3895,3896]
operator: = [3985,3986]
===
match
---
trailer [5892,5898]
trailer [5982,5988]
===
match
---
name: __init__ [2983,2991]
name: __init__ [3073,3081]
===
match
---
name: self [3630,3634]
name: self [3720,3724]
===
match
---
string: 'identityfile' [7570,7584]
string: 'identityfile' [7652,7666]
===
match
---
trailer [4102,4114]
trailer [4192,4204]
===
match
---
param [10042,10047]
param [10124,10129]
===
match
---
name: remote_host [3447,3458]
name: remote_host [3537,3548]
===
match
---
name: log [8234,8237]
name: log [8316,8319]
===
match
---
name: self [7931,7935]
name: self [8013,8017]
===
match
---
simple_stmt [12863,12874]
simple_stmt [12945,12956]
===
match
---
argument [8796,8821]
argument [8878,8903]
===
match
---
expr_stmt [6933,6995]
expr_stmt [7015,7077]
===
match
---
comparison [5559,5599]
comparison [5649,5689]
===
match
---
atom_expr [9284,9333]
atom_expr [9366,9415]
===
match
---
operator: @ [2725,2726]
operator: @ [2815,2816]
===
match
---
name: exc_val [9888,9895]
name: exc_val [9970,9977]
===
match
---
trailer [9461,9486]
trailer [9543,9568]
===
match
---
name: os [6960,6962]
name: os [7042,7044]
===
match
---
arglist [12803,12845]
arglist [12885,12927]
===
match
---
trailer [7335,7346]
trailer [7417,7428]
===
match
---
operator: , [9035,9036]
operator: , [9117,9118]
===
match
---
for_stmt [12700,12955]
for_stmt [12782,13037]
===
match
---
trailer [6978,6995]
trailer [7060,7077]
===
match
---
atom_expr [9925,9936]
atom_expr [10007,10018]
===
match
---
suite [10159,11518]
suite [10241,11600]
===
match
---
simple_stmt [3798,3828]
simple_stmt [3888,3918]
===
match
---
name: pkey [9229,9233]
name: pkey [9311,9315]
===
match
---
and_test [5559,5685]
and_test [5649,5775]
===
match
---
name: conn [4255,4259]
name: conn [4345,4349]
===
match
---
operator: , [9886,9887]
operator: , [9968,9969]
===
match
---
trailer [5434,5436]
trailer [5524,5526]
===
match
---
trailer [7585,7588]
trailer [7667,7670]
===
match
---
operator: = [3958,3959]
operator: = [4048,4049]
===
match
---
trailer [7297,7313]
trailer [7379,7395]
===
match
---
name: conn_name_attr [2607,2621]
name: conn_name_attr [2697,2711]
===
match
---
atom_expr [9257,9270]
atom_expr [9339,9352]
===
match
---
simple_stmt [10828,11160]
simple_stmt [10910,11242]
===
match
---
trailer [4025,4032]
trailer [4115,4122]
===
match
---
trailer [11365,11422]
trailer [11447,11504]
===
match
---
name: username [3486,3494]
name: username [3576,3584]
===
match
---
simple_stmt [844,860]
simple_stmt [829,845]
===
match
---
name: connect_kwargs [9360,9374]
name: connect_kwargs [9442,9456]
===
match
---
simple_stmt [2607,2638]
simple_stmt [2697,2728]
===
match
---
operator: , [3250,3251]
operator: , [3340,3341]
===
match
---
string: 'ed25519' [2532,2541]
string: 'ed25519' [2622,2631]
===
match
---
name: login [4260,4265]
name: login [4350,4355]
===
match
---
name: self [7650,7654]
name: self [7732,7736]
===
match
---
operator: , [11059,11060]
operator: , [11141,11142]
===
match
---
atom_expr [4486,4495]
atom_expr [4576,4585]
===
match
---
name: str [5194,5197]
name: str [5284,5287]
===
match
---
param [3220,3251]
param [3310,3341]
===
match
---
expr_stmt [4754,4800]
expr_stmt [4844,4890]
===
match
---
atom_expr [7859,7875]
atom_expr [7941,7957]
===
match
---
expr_stmt [8510,8551]
expr_stmt [8592,8633]
===
match
---
expr_stmt [4691,4736]
expr_stmt [4781,4826]
===
match
---
operator: = [10802,10803]
operator: = [10884,10885]
===
match
---
comparison [5857,5911]
comparison [5947,6001]
===
match
---
operator: = [5752,5753]
operator: = [5842,5843]
===
match
---
trailer [10705,10715]
trailer [10787,10797]
===
match
---
name: hooks [1120,1125]
name: hooks [1105,1110]
===
match
---
name: key_file [10948,10956]
name: key_file [11030,11038]
===
match
---
simple_stmt [4320,4350]
simple_stmt [4410,4440]
===
match
---
name: compress [5270,5278]
name: compress [5360,5368]
===
match
---
param [10048,10065]
param [10130,10147]
===
match
---
name: remote_port [11107,11118]
name: remote_port [11189,11200]
===
match
---
name: tunnel_kwargs [11244,11257]
name: tunnel_kwargs [11326,11339]
===
match
---
name: host_key [8623,8631]
name: host_key [8705,8713]
===
match
---
operator: = [4840,4841]
operator: = [4930,4931]
===
match
---
operator: = [12834,12835]
operator: = [12916,12917]
===
match
---
simple_stmt [3547,3572]
simple_stmt [3637,3662]
===
match
---
atom_expr [4281,4294]
atom_expr [4371,4384]
===
match
---
name: self [8844,8848]
name: self [8926,8930]
===
match
---
name: private_key [4754,4765]
name: private_key [4844,4855]
===
match
---
name: password [3519,3527]
name: password [3609,3617]
===
match
---
name: client [9343,9349]
name: client [9425,9431]
===
match
---
name: self [9184,9188]
name: self [9266,9270]
===
match
---
trailer [8593,8605]
trailer [8675,8687]
===
match
---
trailer [6599,6608]
trailer [6689,6698]
===
match
---
name: self [4938,4942]
name: self [5028,5032]
===
match
---
operator: , [8605,8606]
operator: , [8687,8688]
===
match
---
string: 'SSH' [2714,2719]
string: 'SSH' [2804,2809]
===
match
---
simple_stmt [4486,4508]
simple_stmt [4576,4598]
===
match
---
operator: = [11092,11093]
operator: = [11174,11175]
===
match
---
atom_expr [9425,9486]
atom_expr [9507,9568]
===
match
---
number: 10 [3311,3313]
number: 10 [3401,3403]
===
match
---
name: pkey [9239,9243]
name: pkey [9321,9325]
===
match
---
trailer [12901,12915]
trailer [12983,12997]
===
match
---
tfpdef [10048,10064]
tfpdef [10130,10146]
===
match
---
expr_stmt [3630,3652]
expr_stmt [3720,3742]
===
match
---
trailer [4166,4184]
trailer [4256,4274]
===
match
---
string: 'This method will be removed in Airflow 2.0' [9737,9781]
string: 'This method will be removed in Airflow 2.0' [9819,9863]
===
match
---
trailer [6921,6923]
trailer [7003,7005]
===
match
---
expr_stmt [3547,3571]
expr_stmt [3637,3661]
===
match
---
param [3040,3045]
param [3130,3135]
===
match
---
name: _default_pkey_mappings [12660,12682]
name: _default_pkey_mappings [12742,12764]
===
match
---
atom_expr [3769,3782]
atom_expr [3859,3872]
===
match
---
trailer [7236,7254]
trailer [7318,7336]
===
match
---
trailer [9228,9244]
trailer [9310,9326]
===
match
---
trailer [9979,9981]
trailer [10061,10063]
===
match
---
name: config_fd [7144,7153]
name: config_fd [7226,7235]
===
match
---
name: int [10711,10714]
name: int [10793,10796]
===
match
---
trailer [10964,10969]
trailer [11046,11051]
===
match
---
name: self [7805,7809]
name: self [7887,7891]
===
match
---
simple_stmt [11345,11423]
simple_stmt [11427,11505]
===
match
---
name: conn_type [2680,2689]
name: conn_type [2770,2779]
===
match
---
operator: , [8955,8956]
operator: , [9037,9038]
===
match
---
operator: = [3615,3616]
operator: = [3705,3706]
===
match
---
name: self [4147,4151]
name: self [4237,4241]
===
match
---
atom_expr [8377,8437]
atom_expr [8459,8519]
===
match
---
trailer [8918,8927]
trailer [9000,9009]
===
match
---
name: compress [3774,3782]
name: compress [3864,3872]
===
match
---
trailer [9349,9357]
trailer [9431,9439]
===
match
---
simple_stmt [4021,4040]
simple_stmt [4111,4130]
===
match
---
operator: , [12311,12312]
operator: , [12393,12394]
===
match
---
name: host_key [3915,3923]
name: host_key [4005,4013]
===
match
---
strings [6654,6794]
strings [6744,6884]
===
match
---
atom_expr [12325,12338]
atom_expr [12407,12420]
===
match
---
operator: = [6099,6100]
operator: = [6189,6190]
===
match
---
param [11591,11621]
param [11673,11703]
===
match
---
trailer [8809,8821]
trailer [8891,8903]
===
match
---
return_stmt [12863,12873]
return_stmt [12945,12955]
===
match
---
if_stmt [9254,9334]
if_stmt [9336,9416]
===
match
---
operator: , [10880,10881]
operator: , [10962,10963]
===
match
---
name: remote_bind_address [11073,11092]
name: remote_bind_address [11155,11174]
===
match
---
trailer [7819,7876]
trailer [7901,7958]
===
match
---
simple_stmt [9207,9245]
simple_stmt [9289,9327]
===
match
---
operator: = [3347,3348]
operator: = [3437,3438]
===
match
---
suite [11650,12257]
suite [11732,12339]
===
match
---
dictorsetmaker [2928,2948]
dictorsetmaker [3018,3038]
===
match
---
atom_expr [10694,10728]
atom_expr [10776,10810]
===
match
---
operator: = [10729,10730]
operator: = [10811,10812]
===
match
---
simple_stmt [7885,7915]
simple_stmt [7967,7997]
===
match
---
operator: , [11589,11590]
operator: , [11671,11672]
===
match
---
expr_stmt [4486,4507]
expr_stmt [4576,4597]
===
match
---
trailer [4855,4859]
trailer [4945,4949]
===
match
---
name: self [7598,7602]
name: self [7680,7684]
===
match
---
operator: = [3561,3562]
operator: = [3651,3652]
===
match
---
raise_stmt [6283,6417]
raise_stmt [6373,6507]
===
match
---
name: password [9153,9161]
name: password [9235,9243]
===
match
---
atom_expr [9097,9118]
atom_expr [9179,9200]
===
match
---
trailer [6850,6862]
trailer [6940,6952]
===
match
---
simple_stmt [12196,12257]
simple_stmt [12278,12339]
===
match
---
name: paramiko [12350,12358]
name: paramiko [12432,12440]
===
match
---
name: self [4167,4171]
name: self [4257,4261]
===
match
---
simple_stmt [5487,5518]
simple_stmt [5577,5608]
===
match
---
operator: } [2961,2962]
operator: } [3051,3052]
===
match
---
simple_stmt [1017,1058]
simple_stmt [1002,1043]
===
match
---
atom_expr [11345,11422]
atom_expr [11427,11504]
===
match
---
atom_expr [8618,8631]
atom_expr [8700,8713]
===
match
---
trailer [9323,9332]
trailer [9405,9414]
===
match
---
atom_expr [4320,4333]
atom_expr [4410,4423]
===
match
---
string: 'utf-8' [6146,6153]
string: 'utf-8' [6236,6243]
===
match
---
atom_expr [4239,4252]
atom_expr [4329,4342]
===
match
---
if_stmt [4613,4737]
if_stmt [4703,4827]
===
match
---
name: _pkey_from_private_key [4955,4977]
name: _pkey_from_private_key [5045,5067]
===
match
---
if_stmt [10647,10819]
if_stmt [10729,10901]
===
match
---
name: password [7428,7436]
name: password [7510,7518]
===
match
---
trailer [8782,9046]
trailer [8864,9128]
===
match
---
name: self [8805,8809]
name: self [8887,8891]
===
match
---
name: pkey [4943,4947]
name: pkey [5033,5037]
===
match
---
trailer [11902,12186]
trailer [11984,12268]
===
match
---
trailer [4340,4349]
trailer [4430,4439]
===
match
---
simple_stmt [9284,9334]
simple_stmt [9366,9416]
===
match
---
name: parse [7180,7185]
name: parse [7262,7267]
===
match
---
name: look_for_keys [3944,3957]
name: look_for_keys [4034,4047]
===
match
---
name: Optional [3150,3158]
name: Optional [3240,3248]
===
match
---
expr_stmt [3836,3870]
expr_stmt [3926,3960]
===
match
---
file_input [787,13183]
file_input [787,13265]
===
match
---
name: SSH_PORT [1008,1016]
name: SSH_PORT [993,1001]
===
match
---
funcdef [2743,2974]
funcdef [2833,3064]
===
match
---
name: username [6895,6903]
name: username [6985,6993]
===
match
---
name: super [3376,3381]
name: super [3466,3471]
===
match
---
simple_stmt [8510,8552]
simple_stmt [8592,8634]
===
match
---
operator: , [11407,11408]
operator: , [11489,11490]
===
match
---
operator: -> [12347,12349]
operator: -> [12429,12431]
===
match
---
name: key_file [7545,7553]
name: key_file [7627,7635]
===
match
---
operator: = [4705,4706]
operator: = [4795,4796]
===
match
---
trailer [7185,7196]
trailer [7267,7278]
===
match
---
name: category [9795,9803]
name: category [9877,9885]
===
match
---
string: "look_for_keys" [5800,5815]
string: "look_for_keys" [5890,5905]
===
match
---
annassign [10692,10756]
annassign [10774,10838]
===
match
---
operator: = [3244,3245]
operator: = [3334,3335]
===
match
---
simple_stmt [915,963]
simple_stmt [900,948]
===
match
---
name: self [4407,4411]
name: self [4497,4501]
===
match
---
expr_stmt [7540,7588]
expr_stmt [7622,7670]
===
match
---
name: remote_host [11465,11476]
name: remote_host [11547,11558]
===
match
---
operator: , [948,949]
operator: , [933,934]
===
match
---
name: extra_options [5058,5071]
name: extra_options [5148,5161]
===
match
---
if_stmt [11169,11423]
if_stmt [11251,11505]
===
match
---
name: local_port [10650,10660]
name: local_port [10732,10742]
===
match
---
operator: = [12339,12340]
operator: = [12421,12422]
===
match
---
simple_stmt [4691,4737]
simple_stmt [4781,4827]
===
match
---
name: local_bind_address [10674,10692]
name: local_bind_address [10756,10774]
===
match
---
operator: = [8804,8805]
operator: = [8886,8887]
===
match
---
comparison [6029,6060]
comparison [6119,6150]
===
match
---
argument [9003,9035]
argument [9085,9117]
===
match
---
atom_expr [2471,2486]
atom_expr [2561,2576]
===
match
---
string: "localhost" [10085,10096]
string: "localhost" [10167,10178]
===
match
---
trailer [12207,12218]
trailer [12289,12300]
===
match
---
if_stmt [7472,7589]
if_stmt [7554,7671]
===
match
---
simple_stmt [3481,3506]
simple_stmt [3571,3596]
===
match
---
expr_stmt [3939,3964]
expr_stmt [4029,4054]
===
match
---
simple_stmt [5265,5287]
simple_stmt [5355,5377]
===
match
---
name: Optional [12325,12333]
name: Optional [12407,12415]
===
match
---
name: no_host_key_check [5492,5509]
name: no_host_key_check [5582,5599]
===
match
---
string: 'ssh_conn_id' [2624,2637]
string: 'ssh_conn_id' [2714,2727]
===
match
---
parameters [2769,2771]
parameters [2859,2861]
===
match
---
name: ssh_conn_id [3422,3433]
name: ssh_conn_id [3512,3523]
===
match
---
operator: = [2660,2661]
operator: = [2750,2751]
===
match
---
trailer [9152,9171]
trailer [9234,9253]
===
match
---
trailer [3665,3684]
trailer [3755,3774]
===
match
---
name: extra_options [4563,4576]
name: extra_options [4653,4666]
===
match
---
operator: -> [11628,11630]
operator: -> [11710,11712]
===
match
---
name: port [3617,3621]
name: port [3707,3711]
===
match
---
name: host_key [8472,8480]
name: host_key [8554,8562]
===
match
---
operator: = [7347,7348]
operator: = [7429,7430]
===
match
---
atom_expr [9059,9072]
atom_expr [9141,9154]
===
match
---
name: airflow [1064,1071]
name: airflow [1049,1056]
===
match
---
string: "hidden_fields" [2855,2870]
string: "hidden_fields" [2945,2960]
===
match
---
name: ssh_conf [7171,7179]
name: ssh_conf [7253,7261]
===
match
---
trailer [4151,4166]
trailer [4241,4256]
===
match
---
suite [4303,4350]
suite [4393,4440]
===
match
---
simple_stmt [12963,13183]
simple_stmt [13045,13265]
===
match
---
param [9897,9903]
param [9979,9985]
===
match
---
param [3097,3131]
param [3187,3221]
===
match
---
atom_expr [7971,8137]
atom_expr [8053,8219]
===
match
---
param [3140,3171]
param [3230,3261]
===
match
---
trailer [10118,10123]
trailer [10200,10205]
===
match
---
suite [4222,4266]
suite [4312,4356]
===
match
---
atom_expr [3661,3684]
atom_expr [3751,3774]
===
match
---
atom_expr [7110,7140]
atom_expr [7192,7222]
===
match
---
name: paramiko [7894,7902]
name: paramiko [7976,7984]
===
match
---
suite [12753,12874]
suite [12835,12956]
===
match
---
name: AirflowException [6470,6486]
name: AirflowException [6560,6576]
===
match
---
trailer [3485,3494]
trailer [3575,3584]
===
match
---
name: SSHTunnelForwarder [11441,11459]
name: SSHTunnelForwarder [11523,11541]
===
match
---
with_item [7110,7153]
with_item [7192,7235]
===
match
---
comparison [4523,4545]
comparison [4613,4635]
===
match
---
trailer [7357,7370]
trailer [7439,7452]
===
match
---
trailer [7444,7453]
trailer [7526,7535]
===
match
---
if_stmt [5303,5518]
if_stmt [5393,5608]
===
match
---
suite [9577,9854]
suite [9659,9936]
===
match
---
operator: = [12774,12775]
operator: = [12856,12857]
===
match
---
operator: , [2486,2487]
operator: , [2576,2577]
===
match
---
trailer [9145,9152]
trailer [9227,9234]
===
match
---
operator: = [2712,2713]
operator: = [2802,2803]
===
match
---
argument [11073,11119]
argument [11155,11201]
===
match
---
name: timeout [5098,5105]
name: timeout [5188,5195]
===
match
---
if_stmt [9181,9245]
if_stmt [9263,9327]
===
match
---
operator: , [3130,3131]
operator: , [3220,3221]
===
match
---
simple_stmt [4754,4801]
simple_stmt [4844,4891]
===
match
---
name: self [3910,3914]
name: self [4000,4004]
===
match
---
name: PKey [12359,12363]
name: PKey [12441,12445]
===
match
---
simple_stmt [2429,2602]
simple_stmt [2519,2692]
===
match
---
trailer [6967,6978]
trailer [7049,7060]
===
match
---
name: self [11460,11464]
name: self [11542,11546]
===
match
---
name: self [3879,3883]
name: self [3969,3973]
===
match
---
operator: , [10816,10817]
operator: , [10898,10899]
===
match
---
name: int [3275,3278]
name: int [3365,3368]
===
match
---
simple_stmt [2789,2826]
simple_stmt [2879,2916]
===
match
---
atom_expr [10943,10956]
atom_expr [11025,11038]
===
match
---
simple_stmt [8667,8752]
simple_stmt [8749,8834]
===
match
---
name: username [4244,4252]
name: username [4334,4342]
===
match
---
name: self [4098,4102]
name: self [4188,4192]
===
match
---
expr_stmt [5093,5141]
expr_stmt [5183,5231]
===
match
---
name: category [12148,12156]
name: category [12230,12238]
===
match
---
simple_stmt [8229,8327]
simple_stmt [8311,8409]
===
match
---
name: self [3040,3044]
name: self [3130,3134]
===
match
---
simple_stmt [6464,6526]
simple_stmt [6554,6616]
===
match
---
operator: , [8857,8858]
operator: , [8939,8940]
===
match
---
name: Optional [3230,3238]
name: Optional [3320,3328]
===
match
---
operator: = [10992,10993]
operator: = [11074,11075]
===
match
---
atom_expr [8412,8436]
atom_expr [8494,8518]
===
match
---
argument [8835,8857]
argument [8917,8939]
===
match
---
string: 'true' [5679,5685]
string: 'true' [5769,5775]
===
match
---
arglist [6654,6863]
arglist [6744,6953]
===
match
---
operator: , [12175,12176]
operator: , [12257,12258]
===
match
---
string: "timeout" [5126,5135]
string: "timeout" [5216,5225]
===
match
---
name: allow_host_key_change [7936,7957]
name: allow_host_key_change [8018,8039]
===
match
---
name: log [6627,6630]
name: log [6717,6720]
===
match
---
suite [3367,7632]
suite [3457,7714]
===
match
---
atom_expr [12203,12256]
atom_expr [12285,12338]
===
match
---
name: password [9162,9170]
name: password [9244,9252]
===
match
---
trailer [11144,11148]
trailer [11226,11230]
===
match
---
operator: = [6958,6959]
operator: = [7040,7041]
===
match
---
string: 'Private key provided cannot be read by paramiko.' [12999,13049]
string: 'Private key provided cannot be read by paramiko.' [13081,13131]
===
match
---
comparison [4648,4669]
comparison [4738,4759]
===
match
---
operator: -> [9905,9907]
operator: -> [9987,9989]
===
match
---
string: "Params key_file and private_key both provided.  Must provide no more than one." [6323,6403]
string: "Params key_file and private_key both provided.  Must provide no more than one." [6413,6493]
===
match
---
atom [2454,2601]
atom [2544,2691]
===
match
---
name: keepalive_interval [3323,3341]
name: keepalive_interval [3413,3431]
===
match
---
trailer [12915,12928]
trailer [12997,13010]
===
match
---
simple_stmt [11659,11881]
simple_stmt [11741,11963]
===
match
---
operator: = [9095,9096]
operator: = [9177,9178]
===
match
---
operator: = [5279,5280]
operator: = [5369,5370]
===
match
---
trailer [10722,10727]
trailer [10804,10809]
===
match
---
atom_expr [8844,8857]
atom_expr [8926,8939]
===
match
---
name: self [3605,3609]
name: self [3695,3699]
===
match
---
name: local_bind_address [11041,11059]
name: local_bind_address [11123,11141]
===
match
---
trailer [5491,5509]
trailer [5581,5599]
===
match
---
name: password [9086,9094]
name: password [9168,9176]
===
match
---
atom_expr [6289,6417]
atom_expr [6379,6507]
===
match
---
name: key_file [3563,3571]
name: key_file [3653,3661]
===
match
---
param [9888,9896]
param [9970,9978]
===
match
---
simple_stmt [12946,12955]
simple_stmt [13028,13037]
===
match
---
tfpdef [3180,3203]
tfpdef [3270,3293]
===
match
---
name: local_port [12245,12255]
name: local_port [12327,12337]
===
match
---
name: self [10943,10947]
name: self [11025,11029]
===
match
---
trailer [8883,8891]
trailer [8965,8973]
===
match
---
name: client [8150,8156]
name: client [8232,8238]
===
match
---
string: 'use get_tunnel() instead. But please note that the' [11974,12026]
string: 'use get_tunnel() instead. But please note that the' [12056,12108]
===
match
---
atom_expr [3798,3820]
atom_expr [3888,3910]
===
match
---
name: log [11145,11148]
name: log [11227,11230]
===
match
---
trailer [5874,5891]
trailer [5964,5981]
===
match
---
name: client [9930,9936]
name: client [10012,10018]
===
match
---
string: """Returns custom field behaviour""" [2789,2825]
string: """Returns custom field behaviour""" [2879,2915]
===
match
---
name: extra_options [5628,5641]
name: extra_options [5718,5731]
===
match
---
simple_stmt [5725,5759]
simple_stmt [5815,5849]
===
match
---
trailer [3634,3642]
trailer [3724,3732]
===
match
---
name: password [11177,11185]
name: password [11259,11267]
===
match
---
trailer [6636,6877]
trailer [6726,6967]
===
match
---
comparison [4098,4126]
comparison [4188,4216]
===
match
---
name: get [7566,7569]
name: get [7648,7651]
===
match
---
return_stmt [9525,9538]
return_stmt [9607,9620]
===
match
---
operator: = [2622,2623]
operator: = [2712,2713]
===
match
---
operator: = [8973,8974]
operator: = [9055,9056]
===
match
---
trailer [8535,8549]
trailer [8617,8631]
===
match
---
name: ssh_conf [7061,7069]
name: ssh_conf [7143,7151]
===
match
---
atom_expr [3547,3560]
atom_expr [3637,3650]
===
match
---
name: get [4782,4785]
name: get [4872,4875]
===
match
---
name: encode [6139,6145]
name: encode [6229,6235]
===
match
---
param [11556,11572]
param [11638,11654]
===
match
---
operator: = [3863,3864]
operator: = [3953,3954]
===
match
---
atom_expr [11889,12186]
atom_expr [11971,12268]
===
match
---
operator: , [10743,10744]
operator: , [10825,10826]
===
match
---
string: "Missing required param: remote_host" [6487,6524]
string: "Missing required param: remote_host" [6577,6614]
===
match
---
simple_stmt [7687,7797]
simple_stmt [7769,7879]
===
match
---
or_test [7610,7631]
or_test [7692,7713]
===
match
---
name: remote_host [6817,6828]
name: remote_host [6907,6918]
===
match
---
atom_expr [4426,4435]
atom_expr [4516,4525]
===
match
---
name: self [7540,7544]
name: self [7622,7626]
===
match
---
simple_stmt [3836,3871]
simple_stmt [3926,3961]
===
match
---
name: password [3530,3538]
name: password [3620,3628]
===
match
---
name: host_pkey_directories [11383,11404]
name: host_pkey_directories [11465,11486]
===
match
---
operator: = [10083,10084]
operator: = [10165,10166]
===
match
---
simple_stmt [7805,7877]
simple_stmt [7887,7959]
===
match
---
atom_expr [3910,3923]
atom_expr [4000,4013]
===
match
---
name: self [7859,7863]
name: self [7941,7945]
===
match
---
if_stmt [7415,7589]
if_stmt [7497,7671]
===
match
---
operator: = [6212,6213]
operator: = [6302,6303]
===
match
---
atom_expr [5198,5223]
atom_expr [5288,5313]
===
match
---
string: 'schema' [2873,2881]
string: 'schema' [2963,2971]
===
match
---
name: extra_options [5176,5189]
name: extra_options [5266,5279]
===
match
---
operator: = [12653,12654]
operator: = [12735,12736]
===
match
---
simple_stmt [834,844]
simple_stmt [819,829]
===
match
---
name: self [4950,4954]
name: self [5040,5044]
===
match
---
suite [2780,2974]
suite [2870,3064]
===
match
---
suite [7048,7589]
suite [7130,7671]
===
match
---
name: remote_host [8594,8605]
name: remote_host [8676,8687]
===
match
---
operator: = [3081,3082]
operator: = [3171,3172]
===
match
---
comparison [5624,5685]
comparison [5714,5775]
===
match
---
expr_stmt [2680,2697]
expr_stmt [2770,2787]
===
match
---
comparison [4616,4643]
comparison [4706,4733]
===
match
---
and_test [7475,7518]
and_test [7557,7600]
===
match
---
simple_stmt [8377,8438]
simple_stmt [8459,8520]
===
match
---
expr_stmt [12634,12691]
expr_stmt [12716,12773]
===
match
---
name: self [3580,3584]
name: self [3670,3674]
===
match
---
name: connect_kwargs [9207,9221]
name: connect_kwargs [9289,9303]
===
match
---
operator: { [2454,2455]
operator: { [2544,2545]
===
match
---
name: host_info [7371,7380]
name: host_info [7453,7462]
===
match
---
simple_stmt [9343,9376]
simple_stmt [9425,9458]
===
match
---
comp_op [4534,4540]
comp_op [4624,4630]
===
match
---
atom [11093,11119]
atom [11175,11201]
===
match
---
operator: , [8989,8990]
operator: , [9071,9072]
===
match
---
name: str [10706,10709]
name: str [10788,10791]
===
match
---
name: self [9558,9562]
name: self [9640,9644]
===
match
---
atom_expr [6242,6251]
atom_expr [6332,6341]
===
match
---
simple_stmt [6176,6231]
simple_stmt [6266,6321]
===
match
---
name: getuser [6914,6921]
name: getuser [6996,7003]
===
match
---
trailer [11358,11365]
trailer [11440,11447]
===
match
---
atom_expr [7805,7876]
atom_expr [7887,7958]
===
match
---
expr_stmt [7598,7631]
expr_stmt [7680,7713]
===
match
---
subscriptlist [10706,10714]
subscriptlist [10788,10796]
===
match
---
suite [11332,11423]
suite [11414,11505]
===
match
---
name: dict [10844,10848]
name: dict [10926,10930]
===
match
---
simple_stmt [6082,6156]
simple_stmt [6172,6246]
===
match
---
tfpdef [11591,11607]
tfpdef [11673,11689]
===
match
---
simple_stmt [9525,9539]
simple_stmt [9607,9621]
===
match
---
name: Dict [934,938]
name: Dict [919,923]
===
match
---
atom_expr [9388,9411]
atom_expr [9470,9493]
===
match
---
name: local_port [10745,10755]
name: local_port [10827,10837]
===
match
---
trailer [9238,9243]
trailer [9320,9325]
===
match
---
atom_expr [5265,5278]
atom_expr [5355,5368]
===
match
---
operator: , [2562,2563]
operator: , [2652,2653]
===
match
---
trailer [8549,8551]
trailer [8631,8633]
===
match
---
name: _pkey_from_private_key [12266,12288]
name: _pkey_from_private_key [12348,12370]
===
match
---
tfpdef [3097,3123]
tfpdef [3187,3213]
===
match
---
trailer [4285,4294]
trailer [4375,4384]
===
match
---
if_stmt [7267,7402]
if_stmt [7349,7484]
===
match
---
param [7650,7654]
param [7732,7736]
===
match
---
expr_stmt [4938,5025]
expr_stmt [5028,5115]
===
match
---
string: 'proxycommand' [7298,7312]
string: 'proxycommand' [7380,7394]
===
match
---
trailer [9298,9305]
trailer [9380,9387]
===
match
---
trailer [4977,5025]
trailer [5067,5115]
===
match
---
name: self [3769,3773]
name: self [3859,3863]
===
match
---
name: self [7440,7444]
name: self [7522,7526]
===
match
---
atom_expr [4147,4184]
atom_expr [4237,4274]
===
match
---
trailer [4942,4947]
trailer [5032,5037]
===
match
---
operator: , [2594,2595]
operator: , [2684,2685]
===
match
---
argument [10983,11008]
argument [11065,11090]
===
match
---
string: 'Remote Identification Change is not verified. ' [8005,8053]
string: 'Remote Identification Change is not verified. ' [8087,8135]
===
match
---
name: extra_options [5819,5832]
name: extra_options [5909,5922]
===
match
---
suite [7314,7402]
suite [7396,7484]
===
match
---
atom_expr [9017,9035]
atom_expr [9099,9117]
===
match
---
atom_expr [6960,6995]
atom_expr [7042,7077]
===
match
---
operator: = [3924,3925]
operator: = [4014,4015]
===
match
---
simple_stmt [7061,7093]
simple_stmt [7143,7175]
===
match
---
simple_stmt [7209,7255]
simple_stmt [7291,7337]
===
match
---
operator: = [9233,9234]
operator: = [9315,9316]
===
match
---
operator: = [4948,4949]
operator: = [5038,5039]
===
match
---
name: port [3260,3264]
name: port [3350,3354]
===
match
---
name: self [4239,4243]
name: self [4329,4333]
===
match
---
trailer [12333,12338]
trailer [12415,12420]
===
match
---
trailer [7384,7400]
trailer [7466,7482]
===
match
---
operator: = [11439,11440]
operator: = [11521,11522]
===
match
---
name: self [9849,9853]
name: self [9931,9935]
===
match
---
trailer [9261,9270]
trailer [9343,9352]
===
match
---
name: self [4200,4204]
name: self [4290,4294]
===
match
---
simple_stmt [3376,3395]
simple_stmt [3466,3485]
===
match
---
name: extra_options [4707,4720]
name: extra_options [4797,4810]
===
match
---
atom_expr [10993,11008]
atom_expr [11075,11090]
===
match
---
trailer [7912,7914]
trailer [7994,7996]
===
match
---
trailer [3383,3392]
trailer [3473,3482]
===
match
---
simple_stmt [980,1017]
simple_stmt [965,1002]
===
match
---
trailer [5406,5427]
trailer [5496,5517]
===
match
---
string: 'Username' [2937,2947]
string: 'Username' [3027,3037]
===
match
---
tfpdef [3296,3308]
tfpdef [3386,3398]
===
match
---
trailer [12218,12256]
trailer [12300,12338]
===
match
---
operator: , [3210,3211]
operator: , [3300,3301]
===
match
---
string: "look_for_keys" [5875,5890]
string: "look_for_keys" [5965,5980]
===
match
---
name: update [11258,11264]
name: update [11340,11346]
===
match
---
name: Optional [3067,3075]
name: Optional [3157,3165]
===
match
---
name: extra_dejson [4584,4596]
name: extra_dejson [4674,4686]
===
match
---
atom_expr [4167,4183]
atom_expr [4257,4273]
===
match
---
string: 'SSHHook.create_tunnel is deprecated, Please' [11916,11961]
string: 'SSHHook.create_tunnel is deprecated, Please' [11998,12043]
===
match
---
atom_expr [9462,9485]
atom_expr [9544,9567]
===
match
---
argument [9358,9374]
argument [9440,9456]
===
match
---
and_test [7270,7313]
and_test [7352,7395]
===
match
---
name: staticmethod [2726,2738]
name: staticmethod [2816,2828]
===
match
---
name: timeout [3635,3642]
name: timeout [3725,3732]
===
match
---
name: Optional [3190,3198]
name: Optional [3280,3288]
===
match
---
simple_stmt [11504,11518]
simple_stmt [11586,11600]
===
match
---
simple_stmt [6283,6418]
simple_stmt [6373,6508]
===
match
---
operator: = [3643,3644]
operator: = [3733,3734]
===
match
---
operator: , [11571,11572]
operator: , [11653,11654]
===
match
---
operator: , [3044,3045]
operator: , [3134,3135]
===
match
---
string: "allow_host_key_change" [5642,5665]
string: "allow_host_key_change" [5732,5755]
===
match
---
operator: , [10064,10065]
operator: , [10146,10147]
===
match
---
simple_stmt [6933,6996]
simple_stmt [7015,7078]
===
match
---
raise_stmt [12963,13182]
raise_stmt [13045,13264]
===
match
---
name: client [9425,9431]
name: client [9507,9513]
===
match
---
string: 'rsa' [2572,2577]
string: 'rsa' [2662,2667]
===
match
---
operator: , [11476,11477]
operator: , [11558,11559]
===
match
---
operator: = [9161,9162]
operator: = [9243,9244]
===
match
---
name: self [9319,9323]
name: self [9401,9405]
===
match
---
trailer [7544,7553]
trailer [7626,7635]
===
match
---
operator: = [4253,4254]
operator: = [4343,4344]
===
match
---
operator: = [4424,4425]
operator: = [4514,4515]
===
match
---
simple_stmt [4563,4597]
simple_stmt [4653,4687]
===
match
---
expr_stmt [7885,7914]
expr_stmt [7967,7996]
===
match
---
name: ssh_conn_id [4172,4183]
name: ssh_conn_id [4262,4273]
===
match
---
suite [5704,5759]
suite [5794,5849]
===
match
---
name: password [11215,11223]
name: password [11297,11305]
===
match
---
simple_stmt [6890,6924]
simple_stmt [6980,7006]
===
match
---
atom [2910,2962]
atom [3000,3052]
===
match
---
trailer [6816,6828]
trailer [6906,6918]
===
match
---
atom_expr [11172,11185]
atom_expr [11254,11267]
===
match
---
param [3260,3287]
param [3350,3377]
===
match
---
operator: = [7554,7555]
operator: = [7636,7637]
===
match
---
name: _default_pkey_mappings [2429,2451]
name: _default_pkey_mappings [2519,2541]
===
match
---
atom_expr [8879,8891]
atom_expr [8961,8973]
===
match
---
atom_expr [11140,11148]
atom_expr [11222,11230]
===
match
---
operator: , [3087,3088]
operator: , [3177,3178]
===
match
---
string: 'proxycommand' [7385,7399]
string: 'proxycommand' [7467,7481]
===
match
---
operator: = [3495,3496]
operator: = [3585,3586]
===
match
---
string: 'No Host Key Verification. This wont protect against Man-In-The-Middle attacks' [8246,8325]
string: 'No Host Key Verification. This wont protect against Man-In-The-Middle attacks' [8328,8407]
===
match
---
argument [6208,6229]
argument [6298,6319]
===
match
---
atom_expr [7440,7453]
atom_expr [7522,7535]
===
match
---
atom_expr [7540,7553]
atom_expr [7622,7635]
===
match
---
suite [6061,6231]
suite [6151,6321]
===
match
---
atom_expr [3266,3279]
atom_expr [3356,3369]
===
match
---
expr_stmt [2607,2637]
expr_stmt [2697,2727]
===
match
---
trailer [3773,3782]
trailer [3863,3872]
===
match
---
name: port [7603,7607]
name: port [7685,7689]
===
match
---
comparison [5389,5447]
comparison [5479,5537]
===
match
---
atom_expr [4938,4947]
atom_expr [5028,5037]
===
match
---
name: self [9257,9261]
name: self [9339,9343]
===
match
---
operator: == [5676,5678]
operator: == [5766,5768]
===
match
---
atom_expr [5725,5751]
atom_expr [5815,5841]
===
match
---
testlist_comp [11094,11118]
testlist_comp [11176,11200]
===
match
---
name: conn [4579,4583]
name: conn [4669,4673]
===
match
---
name: AirflowException [12969,12985]
name: AirflowException [13051,13067]
===
match
---
atom_expr [8946,8955]
atom_expr [9028,9037]
===
match
---
atom_expr [6812,6828]
atom_expr [6902,6918]
===
match
---
operator: , [3286,3287]
operator: , [3376,3377]
===
match
---
atom_expr [8568,8632]
atom_expr [8650,8714]
===
match
---
operator: = [11040,11041]
operator: = [11122,11123]
===
match
---
name: StringIO [906,914]
name: StringIO [891,899]
===
match
---
name: user_ssh_config_filename [6933,6957]
name: user_ssh_config_filename [7015,7039]
===
match
---
suite [7519,7589]
suite [7601,7671]
===
match
---
operator: , [8927,8928]
operator: , [9009,9010]
===
match
---
name: tunnel_kwargs [11345,11358]
name: tunnel_kwargs [11427,11440]
===
match
---
simple_stmt [2680,2698]
simple_stmt [2770,2788]
===
match
---
name: self [8467,8471]
name: self [8549,8553]
===
match
---
string: "username to ssh to host: %s is not specified for connection id" [6654,6718]
string: "username to ssh to host: %s is not specified for connection id" [6744,6808]
===
match
---
name: log [7810,7813]
name: log [7892,7895]
===
match
---
atom_expr [3605,3614]
atom_expr [3695,3704]
===
match
---
simple_stmt [12634,12692]
simple_stmt [12716,12774]
===
match
---
trailer [12802,12846]
trailer [12884,12928]
===
match
---
name: password [4286,4294]
name: password [4376,4384]
===
match
---
name: pkey [10965,10969]
name: pkey [11047,11051]
===
match
---
argument [9306,9332]
argument [9388,9414]
===
match
---
expr_stmt [3661,3705]
expr_stmt [3751,3795]
===
match
---
atom_expr [8150,8180]
atom_expr [8232,8262]
===
match
---
trailer [6200,6207]
trailer [6290,6297]
===
match
---
operator: , [10715,10716]
operator: , [10797,10798]
===
match
---
operator: , [10046,10047]
operator: , [10128,10129]
===
match
---
trailer [5224,5230]
trailer [5314,5320]
===
match
---
atom_expr [10844,11159]
atom_expr [10926,11241]
===
match
---
simple_stmt [9994,10013]
simple_stmt [10076,10095]
===
match
---
trailer [9466,9485]
trailer [9548,9567]
===
match
---
name: self [3661,3665]
name: self [3751,3755]
===
match
---
expr_stmt [3514,3538]
expr_stmt [3604,3628]
===
match
---
name: self [4320,4324]
name: self [4410,4414]
===
match
---
subscriptlist [10700,10727]
subscriptlist [10782,10809]
===
match
---
simple_stmt [9425,9487]
simple_stmt [9507,9569]
===
match
---
trailer [2513,2522]
trailer [2603,2612]
===
match
---
funcdef [9859,10013]
funcdef [9941,10095]
===
match
---
tfpdef [10098,10123]
tfpdef [10180,10205]
===
match
---
trailer [11257,11264]
trailer [11339,11346]
===
match
---
atom_expr [11244,11318]
atom_expr [11326,11400]
===
match
---
name: self [5093,5097]
name: self [5183,5187]
===
match
---
operator: = [6190,6191]
operator: = [6280,6281]
===
match
---
operator: , [11119,11120]
operator: , [11201,11202]
===
match
---
atom_expr [3067,3080]
atom_expr [3157,3170]
===
match
---
name: host [4431,4435]
name: host [4521,4525]
===
match
---
name: self [9234,9238]
name: self [9316,9320]
===
match
---
trailer [4430,4435]
trailer [4520,4525]
===
match
---
raise_stmt [6464,6525]
raise_stmt [6554,6615]
===
match
---
funcdef [2979,7632]
funcdef [3069,7714]
===
match
---
name: dict [8778,8782]
name: dict [8860,8864]
===
match
---
if_stmt [4095,6231]
if_stmt [4185,6321]
===
match
---
trailer [7614,7619]
trailer [7696,7701]
===
match
---
string: 'login' [2928,2935]
string: 'login' [3018,3025]
===
match
---
operator: , [3351,3352]
operator: , [3441,3442]
===
match
---
name: self [3481,3485]
name: self [3571,3575]
===
match
---
suite [9913,10013]
suite [9995,10095]
===
match
---
name: paramiko [7072,7080]
name: paramiko [7154,7162]
===
match
---
name: conn [4140,4144]
name: conn [4230,4234]
===
match
---
name: host_info [7475,7484]
name: host_info [7557,7566]
===
match
---
simple_stmt [7331,7402]
simple_stmt [7413,7484]
===
match
---
name: remote_host [11094,11105]
name: remote_host [11176,11187]
===
match
---
atom_expr [6434,6450]
atom_expr [6524,6540]
===
match
---
operator: = [7892,7893]
operator: = [7974,7975]
===
match
---
name: compress [8905,8913]
name: compress [8987,8995]
===
match
---
operator: = [5510,5511]
operator: = [5600,5601]
===
match
---
atom_expr [10871,10880]
atom_expr [10953,10962]
===
match
---
argument [8969,8989]
argument [9051,9071]
===
match
---
trailer [2551,2562]
trailer [2641,2652]
===
match
---
expr_stmt [9994,10012]
expr_stmt [10076,10094]
===
match
---
trailer [4652,4661]
trailer [4742,4751]
===
match
---
if_stmt [5159,5287]
if_stmt [5249,5377]
===
match
---
atom_expr [5628,5666]
atom_expr [5718,5756]
===
match
---
name: port [4456,4460]
name: port [4546,4550]
===
match
---
operator: == [5901,5903]
operator: == [5991,5993]
===
match
---
operator: , [955,956]
operator: , [940,941]
===
match
---
name: SSHTunnelForwarder [1039,1057]
name: SSHTunnelForwarder [1024,1042]
===
match
---
name: io [896,898]
name: io [881,883]
===
match
---
operator: , [8616,8617]
operator: , [8698,8699]
===
match
---
name: update [9299,9305]
name: update [9381,9387]
===
match
---
operator: , [11554,11555]
operator: , [11636,11637]
===
match
---
name: str [10723,10726]
name: str [10805,10808]
===
match
---
trailer [8978,8989]
trailer [9060,9071]
===
match
---
operator: = [10942,10943]
operator: = [11024,11025]
===
match
---
suite [7455,7589]
suite [7537,7671]
===
match
---
if_stmt [5042,5142]
if_stmt [5132,5232]
===
match
---
name: Dict [2775,2779]
name: Dict [2865,2869]
===
match
---
trailer [7979,7987]
trailer [8061,8069]
===
match
---
arglist [5112,5140]
arglist [5202,5230]
===
match
---
trailer [3802,3820]
trailer [3892,3910]
===
match
---
trailer [10699,10728]
trailer [10781,10810]
===
match
---
name: lower [5429,5434]
name: lower [5519,5524]
===
match
---
name: extra_options [6113,6126]
name: extra_options [6203,6216]
===
match
---
name: self [7971,7975]
name: self [8053,8057]
===
match
---
atom_expr [10960,10969]
atom_expr [11042,11051]
===
match
---
suite [7678,9539]
suite [7760,9621]
===
match
---
name: no_host_key_check [8198,8215]
name: no_host_key_check [8280,8297]
===
match
---
and_test [5800,5911]
and_test [5890,6001]
===
match
---
name: connect_kwargs [9284,9298]
name: connect_kwargs [9366,9380]
===
match
---
operator: -> [10137,10139]
operator: -> [10219,10221]
===
match
---
argument [9229,9243]
argument [9311,9325]
===
match
---
atom_expr [7237,7253]
atom_expr [7319,7335]
===
match
---
trailer [7498,7502]
trailer [7580,7584]
===
match
---
simple_stmt [8150,8181]
simple_stmt [8232,8263]
===
match
---
expr_stmt [4239,4265]
expr_stmt [4329,4355]
===
match
---
name: self [4691,4695]
name: self [4781,4785]
===
match
---
name: self [10993,10997]
name: self [11075,11079]
===
match
---
trailer [8411,8437]
trailer [8493,8519]
===
match
---
expr_stmt [3442,3472]
expr_stmt [3532,3562]
===
match
---
atom [11405,11407]
atom [11487,11489]
===
match
---
atom_expr [10907,10920]
atom_expr [10989,11002]
===
match
---
name: ssh_conn_id [4103,4114]
name: ssh_conn_id [4193,4204]
===
match
---
trailer [4369,4381]
trailer [4459,4471]
===
match
---
name: paramiko [2543,2551]
name: paramiko [2633,2641]
===
match
---
name: self [6029,6033]
name: self [6119,6123]
===
match
---
name: int [3343,3346]
name: int [3433,3436]
===
match
---
expr_stmt [11432,11494]
expr_stmt [11514,11576]
===
match
---
atom_expr [7221,7254]
atom_expr [7303,7336]
===
match
---
name: connect_kwargs [8761,8775]
name: connect_kwargs [8843,8857]
===
match
---
name: debug [6631,6636]
name: debug [6721,6726]
===
match
---
name: str [3239,3242]
name: str [3329,3332]
===
match
---
name: local_bind_address [10783,10801]
name: local_bind_address [10865,10883]
===
match
---
name: host_proxy [8979,8989]
name: host_proxy [9061,9071]
===
match
---
name: self [9017,9021]
name: self [9099,9103]
===
match
---
trailer [7975,7979]
trailer [8057,8061]
===
match
---
trailer [3381,3383]
trailer [3471,3473]
===
match
---
atom_expr [7371,7400]
atom_expr [7453,7482]
===
match
---
name: pkey_type [12776,12785]
name: pkey_type [12858,12867]
===
match
---
name: sshtunnel [1022,1031]
name: sshtunnel [1007,1016]
===
match
---
trailer [3198,3203]
trailer [3288,3293]
===
match
---
name: Optional [3266,3274]
name: Optional [3356,3364]
===
match
---
name: self [3442,3446]
name: self [3532,3536]
===
match
---
operator: , [10096,10097]
operator: , [10178,10179]
===
match
---
trailer [10997,11008]
trailer [11079,11090]
===
match
---
except_clause [12886,12928]
except_clause [12968,13010]
===
match
---
name: lower [5893,5898]
name: lower [5983,5988]
===
match
---
operator: , [11105,11106]
operator: , [11187,11188]
===
match
---
name: SSHTunnelForwarder [11631,11649]
name: SSHTunnelForwarder [11713,11731]
===
match
---
operator: } [2972,2973]
operator: } [3062,3063]
===
match
---
string: "timeout" [5045,5054]
string: "timeout" [5135,5144]
===
match
---
name: key_filename [9306,9318]
name: key_filename [9388,9400]
===
match
---
simple_stmt [9086,9119]
simple_stmt [9168,9201]
===
match
---
strings [9613,9781]
strings [9695,9863]
===
match
---
atom_expr [4768,4800]
atom_expr [4858,4890]
===
match
---
name: paramiko [2505,2513]
name: paramiko [2595,2603]
===
match
---
trailer [7502,7518]
trailer [7584,7600]
===
match
---
parameters [10032,10136]
parameters [10114,10218]
===
match
---
simple_stmt [2642,2676]
simple_stmt [2732,2766]
===
match
---
operator: , [12134,12135]
operator: , [12216,12217]
===
match
---
trailer [11464,11476]
trailer [11546,11558]
===
match
---
tfpdef [3323,3346]
tfpdef [3413,3436]
===
match
---
operator: = [10906,10907]
operator: = [10988,10989]
===
match
---
name: add [8585,8588]
name: add [8667,8670]
===
match
---
trailer [12682,12689]
trailer [12764,12771]
===
match
---
and_test [6242,6269]
and_test [6332,6359]
===
match
---
operator: , [11303,11304]
operator: , [11385,11386]
===
match
---
trailer [8434,8436]
trailer [8516,8518]
===
match
---
operator: , [12293,12294]
operator: , [12375,12376]
===
match
---
atom_expr [7659,7677]
atom_expr [7741,7759]
===
match
---
string: """         Opens a ssh connection to the remote host.          :rtype: paramiko.client.SSHClient         """ [7687,7796]
string: """         Opens a ssh connection to the remote host.          :rtype: paramiko.client.SSHClient         """ [7769,7878]
===
match
---
trailer [3609,3614]
trailer [3699,3704]
===
match
---
string: 'Ensure key provided is valid for one of the following' [13062,13117]
string: 'Ensure key provided is valid for one of the following' [13144,13199]
===
match
---
operator: , [10920,10921]
operator: , [11002,11003]
===
match
---
name: self [12655,12659]
name: self [12737,12741]
===
match
---
atom_expr [5861,5891]
atom_expr [5951,5981]
===
match
---
expr_stmt [3879,3901]
expr_stmt [3969,3991]
===
match
---
operator: ** [9358,9360]
operator: ** [9440,9442]
===
match
---
name: self [6846,6850]
name: self [6936,6940]
===
match
---
simple_stmt [3910,3931]
simple_stmt [4000,4021]
===
match
---
simple_stmt [11432,11495]
simple_stmt [11514,11577]
===
match
---
name: passphrase [12835,12845]
name: passphrase [12917,12927]
===
match
---
decorated [2725,2974]
decorated [2815,3064]
===
match
---
trailer [6112,6155]
trailer [6202,6245]
===
match
---
name: set_missing_host_key_policy [8384,8411]
name: set_missing_host_key_policy [8466,8493]
===
match
---
name: self [3939,3943]
name: self [4029,4033]
===
match
---
name: password [12826,12834]
name: password [12908,12916]
===
match
---
name: private_key_passphrase [4817,4839]
name: private_key_passphrase [4907,4929]
===
match
---
atom_expr [11210,11231]
atom_expr [11292,11313]
===
match
---
name: ECDSAKey [2514,2522]
name: ECDSAKey [2604,2612]
===
match
---
simple_stmt [5951,5978]
simple_stmt [6041,6068]
===
match
---
name: decodebytes [6101,6112]
name: decodebytes [6191,6202]
===
match
---
expr_stmt [3580,3596]
expr_stmt [3670,3686]
===
match
---
name: paramiko [8412,8420]
name: paramiko [8494,8502]
===
match
---
trailer [8848,8857]
trailer [8930,8939]
===
match
---
expr_stmt [3910,3930]
expr_stmt [4000,4020]
===
match
---
name: remote_host [10066,10077]
name: remote_host [10148,10159]
===
match
---
operator: = [3528,3529]
operator: = [3618,3619]
===
match
---
name: paramiko [12893,12901]
name: paramiko [12975,12983]
===
match
---
argument [10862,10880]
argument [10944,10962]
===
match
---
trailer [7813,7819]
trailer [7895,7901]
===
match
---
atom [2872,2882]
atom [2962,2972]
===
match
---
name: remote_port [12219,12230]
name: remote_port [12301,12312]
===
match
---
name: get [7294,7297]
name: get [7376,7379]
===
match
---
simple_stmt [10168,10639]
simple_stmt [10250,10721]
===
match
---
trailer [8420,8434]
trailer [8502,8516]
===
match
---
name: self [9059,9063]
name: self [9141,9145]
===
match
---
name: DeprecationWarning [12157,12175]
name: DeprecationWarning [12239,12257]
===
match
---
import_from [1017,1057]
import_from [1002,1042]
===
match
---
name: Tuple [10700,10705]
name: Tuple [10782,10787]
===
match
---
string: "compress" [5162,5172]
string: "compress" [5252,5262]
===
match
---
trailer [8471,8480]
trailer [8553,8562]
===
match
---
trailer [8950,8955]
trailer [9032,9037]
===
match
---
argument [8941,8955]
argument [9023,9037]
===
match
---
trailer [4720,4724]
trailer [4810,4814]
===
match
---
name: decoded_host_key [6082,6098]
name: decoded_host_key [6172,6188]
===
match
---
name: client [8529,8535]
name: client [8611,8617]
===
match
---
trailer [4781,4785]
trailer [4871,4875]
===
match
---
name: client [7885,7891]
name: client [7967,7973]
===
match
---
param [3054,3088]
param [3144,3178]
===
match
---
name: update [9146,9152]
name: update [9228,9234]
===
match
---
name: client [8377,8383]
name: client [8459,8465]
===
match
---
name: extra_options [5586,5599]
name: extra_options [5676,5689]
===
match
---
name: paramiko [7659,7667]
name: paramiko [7741,7749]
===
match
---
expr_stmt [4563,4596]
expr_stmt [4653,4686]
===
match
---
name: self [4365,4369]
name: self [4455,4459]
===
match
---
atom_expr [3514,3527]
atom_expr [3604,3617]
===
match
---
name: strip [9111,9116]
name: strip [9193,9198]
===
match
---
trailer [10875,10880]
trailer [10957,10962]
===
match
---
simple_stmt [4817,4886]
simple_stmt [4907,4976]
===
match
---
suite [6270,6418]
suite [6360,6508]
===
match
---
funcdef [10018,11518]
funcdef [10100,11600]
===
match
---
argument [9795,9822]
argument [9877,9904]
===
match
---
trailer [5673,5675]
trailer [5763,5765]
===
match
---
atom_expr [3230,3243]
atom_expr [3320,3333]
===
match
---
operator: , [10969,10970]
operator: , [11051,11052]
===
match
---
atom [2841,2973]
atom [2931,3063]
===
match
---
string: '~/.ssh/config' [6979,6994]
string: '~/.ssh/config' [7061,7076]
===
match
---
simple_stmt [3939,3965]
simple_stmt [4029,4055]
===
match
---
atom_expr [9343,9375]
atom_expr [9425,9457]
===
match
---
suite [4670,4737]
suite [4760,4827]
===
match
---
suite [4546,6231]
suite [4636,6321]
===
match
---
name: password [9064,9072]
name: password [9146,9154]
===
match
---
name: ssh_conn_id [3054,3065]
name: ssh_conn_id [3144,3155]
===
match
---
arglist [11460,11493]
arglist [11542,11575]
===
match
---
if_stmt [6239,6418]
if_stmt [6329,6508]
===
match
---
simple_stmt [2834,2974]
simple_stmt [2924,3064]
===
match
---
string: 'order of the parameters have changed' [12039,12077]
string: 'order of the parameters have changed' [12121,12159]
===
match
---
atom_expr [9319,9332]
atom_expr [9401,9414]
===
match
---
operator: , [2882,2883]
operator: , [2972,2973]
===
match
---
trailer [5197,5224]
trailer [5287,5314]
===
match
---
if_stmt [5775,5978]
if_stmt [5865,6068]
===
match
---
trailer [5627,5667]
trailer [5717,5757]
===
match
---
name: self [11172,11176]
name: self [11254,11258]
===
match
---
operator: = [10842,10843]
operator: = [10924,10925]
===
match
---
operator: = [5106,5107]
operator: = [5196,5197]
===
match
---
name: Optional [940,948]
name: Optional [925,933]
===
match
---
name: int [10061,10064]
name: int [10143,10146]
===
match
---
atom_expr [7072,7092]
atom_expr [7154,7174]
===
match
---
trailer [7569,7585]
trailer [7651,7667]
===
match
---
if_stmt [9056,9172]
if_stmt [9138,9254]
===
match
---
name: Optional [3110,3118]
name: Optional [3200,3208]
===
match
---
atom_expr [2505,2522]
atom_expr [2595,2612]
===
match
---
name: ssh_pkey [10934,10942]
name: ssh_pkey [11016,11024]
===
match
---
expr_stmt [7331,7401]
expr_stmt [7413,7483]
===
match
---
name: key [12770,12773]
name: key [12852,12855]
===
match
---
not_test [7927,7957]
not_test [8009,8039]
===
match
---
name: default_conn_name [2642,2659]
name: default_conn_name [2732,2749]
===
match
---
name: Tuple [950,955]
name: Tuple [935,940]
===
match
---
atom_expr [6113,6154]
atom_expr [6203,6244]
===
match
---
operator: { [2841,2842]
operator: { [2931,2932]
===
match
---
return_stmt [2834,2973]
return_stmt [2924,3063]
===
match
---
name: sock [8969,8973]
name: sock [9051,9055]
===
match
---
name: key_file [4653,4661]
name: key_file [4743,4751]
===
match
---
name: extra [4528,4533]
name: extra [4618,4623]
===
match
---
name: host_proxy [7336,7346]
name: host_proxy [7418,7428]
===
match
---
operator: = [3164,3165]
operator: = [3254,3255]
===
match
---
name: Union [957,962]
name: Union [942,947]
===
match
---
name: self [12203,12207]
name: self [12285,12289]
===
match
---
trailer [9929,9936]
trailer [10011,10018]
===
match
---
name: self [10907,10911]
name: self [10989,10993]
===
match
---
suite [10661,10757]
suite [10743,10839]
===
match
---
name: self [9462,9466]
name: self [9544,9548]
===
match
---
name: password [4325,4333]
name: password [4415,4423]
===
match
---
name: local_port [10098,10108]
name: local_port [10180,10190]
===
match
---
expr_stmt [9496,9516]
expr_stmt [9578,9598]
===
match
---
operator: , [2522,2523]
operator: , [2612,2613]
===
match
---
name: config [994,1000]
name: config [979,985]
===
match
---
name: BaseHook [1138,1146]
name: BaseHook [1123,1131]
===
match
---
name: self [4451,4455]
name: self [4541,4545]
===
match
---
trailer [8233,8237]
trailer [8315,8319]
===
match
---
simple_stmt [8568,8633]
simple_stmt [8650,8715]
===
match
---
tfpdef [10066,10082]
tfpdef [10148,10164]
===
match
---
name: password [11295,11303]
name: password [11377,11385]
===
match
---
simple_stmt [1059,1107]
simple_stmt [1044,1092]
===
match
---
operator: = [3124,3125]
operator: = [3214,3215]
===
match
---
simple_stmt [3605,3622]
simple_stmt [3695,3712]
===
match
---
classdef [1149,13183]
classdef [1239,13265]
===
match
---
suite [9271,9334]
suite [9353,9416]
===
match
---
name: __exit__ [9863,9871]
name: __exit__ [9945,9953]
===
match
---
atom_expr [2543,2562]
atom_expr [2633,2652]
===
match
---
operator: = [5001,5002]
operator: = [5091,5092]
===
match
---
trailer [11459,11494]
trailer [11541,11576]
===
match
---
atom_expr [10110,10123]
atom_expr [10192,10205]
===
match
---
operator: , [9781,9782]
operator: , [9863,9864]
===
match
---
dictorsetmaker [2464,2595]
dictorsetmaker [2554,2685]
===
match
---
atom_expr [5951,5969]
atom_expr [6041,6059]
===
match
---
name: warn [9595,9599]
name: warn [9677,9681]
===
match
---
name: self [9872,9876]
name: self [9954,9958]
===
match
---
simple_stmt [12770,12847]
simple_stmt [12852,12929]
===
match
---
atom_expr [5093,5105]
atom_expr [5183,5195]
===
match
---
trailer [9021,9035]
trailer [9103,9117]
===
match
---
atom_expr [6101,6155]
atom_expr [6191,6245]
===
match
---
operator: = [8913,8914]
operator: = [8995,8996]
===
match
---
trailer [7380,7384]
trailer [7462,7466]
===
match
---
trailer [9966,9973]
trailer [10048,10055]
===
match
---
trailer [6486,6525]
trailer [6576,6615]
===
match
---
atom_expr [8974,8989]
atom_expr [9056,9071]
===
match
---
name: get [7499,7502]
name: get [7581,7584]
===
match
---
atom_expr [7423,7436]
atom_expr [7505,7518]
===
match
---
expr_stmt [5951,5977]
expr_stmt [6041,6067]
===
match
---
operator: = [11294,11295]
operator: = [11376,11377]
===
match
---
string: "no_host_key_check" [5328,5347]
string: "no_host_key_check" [5418,5437]
===
match
---
name: get [7381,7384]
name: get [7463,7466]
===
match
---
trailer [6626,6630]
trailer [6716,6720]
===
match
---
operator: ** [11478,11480]
operator: ** [11560,11562]
===
match
---
operator: = [4334,4335]
operator: = [4424,4425]
===
match
---
name: key_file [3552,3560]
name: key_file [3642,3650]
===
match
---
trailer [4527,4533]
trailer [4617,4623]
===
match
---
name: remote_host [6439,6450]
name: remote_host [6529,6540]
===
match
---
name: self [3403,3407]
name: self [3493,3497]
===
match
---
name: get_ui_field_behaviour [2747,2769]
name: get_ui_field_behaviour [2837,2859]
===
match
---
name: self [7237,7241]
name: self [7319,7323]
===
match
---
name: Optional [10110,10118]
name: Optional [10192,10200]
===
match
---
trailer [3158,3163]
trailer [3248,3253]
===
match
---
comparison [9925,9948]
comparison [10007,10030]
===
match
---
name: self [8618,8622]
name: self [8700,8704]
===
match
---
trailer [9431,9445]
trailer [9513,9527]
===
match
---
simple_stmt [11889,12187]
simple_stmt [11971,12269]
===
match
---
trailer [7863,7875]
trailer [7945,7957]
===
match
---
string: 'localhost' [10732,10743]
string: 'localhost' [10814,10825]
===
match
---
expr_stmt [5487,5517]
expr_stmt [5577,5607]
===
match
---
atom_expr [4707,4736]
atom_expr [4797,4826]
===
match
---
trailer [11264,11318]
trailer [11346,11400]
===
match
---
argument [11022,11059]
argument [11104,11141]
===
match
---
atom_expr [6176,6189]
atom_expr [6266,6279]
===
match
---
expr_stmt [4021,4039]
expr_stmt [4111,4129]
===
match
---
if_stmt [5534,5759]
if_stmt [5624,5849]
===
match
---
operator: = [9016,9017]
operator: = [9098,9099]
===
match
---
name: keepalive_interval [9467,9485]
name: keepalive_interval [9549,9567]
===
match
---
trailer [3914,3923]
trailer [4004,4013]
===
match
---
name: self [11140,11144]
name: self [11222,11226]
===
match
---
name: data [6208,6212]
name: data [6298,6302]
===
match
---
name: self [6812,6816]
name: self [6902,6906]
===
match
---
atom_expr [2579,2594]
atom_expr [2669,2684]
===
match
---
name: allowed_pkey_types [12634,12652]
name: allowed_pkey_types [12716,12734]
===
match
---
name: look_for_keys [5956,5969]
name: look_for_keys [6046,6059]
===
match
---
name: extra_options [5112,5125]
name: extra_options [5202,5215]
===
match
---
operator: = [10870,10871]
operator: = [10952,10953]
===
match
---
trailer [9445,9447]
trailer [9527,9529]
===
match
---
name: password [3180,3188]
name: password [3270,3278]
===
match
---
name: no_host_key_check [3803,3820]
name: no_host_key_check [3893,3910]
===
match
---
trailer [7293,7297]
trailer [7375,7379]
===
match
---
name: self [8193,8197]
name: self [8275,8279]
===
match
---
name: allow_host_key_change [3841,3862]
name: allow_host_key_change [3931,3952]
===
match
---
name: self [5487,5491]
name: self [5577,5581]
===
match
---
param [3323,3352]
param [3413,3442]
===
match
---
tfpdef [12313,12338]
tfpdef [12395,12420]
===
match
---
string: """         Creates a tunnel between two hosts. Like ssh -L <LOCAL_PORT>:host:<REMOTE_PORT>.          :param remote_port: The remote port to create a tunnel to         :type remote_port: int         :param remote_host: The remote host to create a tunnel to (default localhost)         :type remote_host: str         :param local_port:  The local port to attach the tunnel to         :type local_port: int          :return: sshtunnel.SSHTunnelForwarder object         """ [10168,10638]
string: """         Creates a tunnel between two hosts. Like ssh -L <LOCAL_PORT>:host:<REMOTE_PORT>.          :param remote_port: The remote port to create a tunnel to         :type remote_port: int         :param remote_host: The remote host to create a tunnel to (default localhost)         :type remote_host: str         :param local_port:  The local port to attach the tunnel to         :type local_port: int          :return: sshtunnel.SSHTunnelForwarder object         """ [10250,10720]
===
match
---
trailer [2587,2594]
trailer [2677,2684]
===
match
---
string: "compress" [5212,5222]
string: "compress" [5302,5312]
===
match
---
name: ssh_proxy [10983,10992]
name: ssh_proxy [11065,11074]
===
match
---
string: 'Please use get_conn() as a contextmanager instead.' [9672,9724]
string: 'Please use get_conn() as a contextmanager instead.' [9754,9806]
===
match
---
string: 'ssh' [2692,2697]
string: 'ssh' [2782,2787]
===
match
---
name: timeout [8871,8878]
name: timeout [8953,8960]
===
match
---
name: host_info [7489,7498]
name: host_info [7571,7580]
===
match
---
trailer [5392,5428]
trailer [5482,5518]
===
match
---
atom_expr [4336,4349]
atom_expr [4426,4439]
===
match
---
operator: = [8527,8528]
operator: = [8609,8610]
===
match
---
name: typing [920,926]
name: typing [905,911]
===
match
---
suite [4127,6231]
suite [4217,6321]
===
match
---
simple_stmt [9962,9982]
simple_stmt [10044,10064]
===
match
---
funcdef [7637,9539]
funcdef [7719,9621]
===
match
---
trailer [10848,11159]
trailer [10930,11241]
===
match
---
trailer [7229,7236]
trailer [7311,7318]
===
match
---
atom_expr [12969,13182]
atom_expr [13051,13264]
===
match
---
name: open [7110,7114]
name: open [7192,7196]
===
match
---
name: remote_host [7242,7253]
name: remote_host [7324,7335]
===
match
---
name: AutoAddPolicy [8421,8434]
name: AutoAddPolicy [8503,8516]
===
match
---
name: key_file [6261,6269]
name: key_file [6351,6359]
===
match
---
expr_stmt [12770,12846]
expr_stmt [12852,12928]
===
match
---
name: remote_host [8810,8821]
name: remote_host [8892,8903]
===
match
---
atom_expr [9962,9981]
atom_expr [10044,10063]
===
match
---
trailer [3274,3279]
trailer [3364,3369]
===
match
---
trailer [5667,5673]
trailer [5757,5763]
===
match
---
trailer [9599,9833]
trailer [9681,9915]
===
match
---
argument [12148,12175]
argument [12230,12257]
===
match
---
name: self [6622,6626]
name: self [6712,6716]
===
match
---
trailer [3075,3080]
trailer [3165,3170]
===
match
---
string: 'false' [5440,5447]
string: 'false' [5530,5537]
===
match
---
simple_stmt [7971,8138]
simple_stmt [8053,8220]
===
match
---
trailer [6180,6189]
trailer [6270,6279]
===
match
---
trailer [6630,6636]
trailer [6720,6726]
===
match
---
arglist [11282,11304]
arglist [11364,11386]
===
match
---
name: self [8974,8978]
name: self [9056,9060]
===
match
---
name: private_key [12812,12823]
name: private_key [12894,12905]
===
match
---
operator: , [6862,6863]
operator: , [6952,6953]
===
match
---
name: private_key [4905,4916]
name: private_key [4995,5006]
===
match
---
name: paramiko [985,993]
name: paramiko [970,978]
===
match
---
import_from [915,962]
import_from [900,947]
===
match
---
name: exceptions [1072,1082]
name: exceptions [1057,1067]
===
match
---
operator: , [5136,5137]
operator: , [5226,5227]
===
match
---
comparison [5800,5832]
comparison [5890,5922]
===
match
---
if_stmt [4520,6231]
if_stmt [4610,6321]
===
match
---
trailer [5955,5969]
trailer [6045,6059]
===
match
---
name: get_host_keys [8536,8549]
name: get_host_keys [8618,8631]
===
match
---
atom [5778,5929]
atom [5868,6019]
===
match
---
if_stmt [5994,6231]
if_stmt [6084,6321]
===
match
---
atom_expr [3939,3957]
atom_expr [4029,4047]
===
match
---
expr_stmt [7209,7254]
expr_stmt [7291,7336]
===
match
---
trailer [4695,4704]
trailer [4785,4794]
===
match
---
atom [10804,10818]
atom [10886,10900]
===
match
---
name: compress [8919,8927]
name: compress [9001,9009]
===
match
---
trailer [5269,5278]
trailer [5359,5368]
===
match
---
atom_expr [11441,11494]
atom_expr [11523,11576]
===
match
---
trailer [6962,6967]
trailer [7044,7049]
===
match
---
name: extra_options [5198,5211]
name: extra_options [5288,5301]
===
match
---
atom_expr [7349,7401]
atom_expr [7431,7483]
===
match
---
trailer [4583,4596]
trailer [4673,4686]
===
match
---
trailer [6145,6154]
trailer [6235,6244]
===
match
---
trailer [3943,3957]
trailer [4033,4047]
===
match
---
trailer [12659,12682]
trailer [12741,12764]
===
match
---
comparison [5045,5071]
comparison [5135,5161]
===
match
---
name: self [9388,9392]
name: self [9470,9474]
===
match
---
trailer [6438,6450]
trailer [6528,6540]
===
match
---
operator: , [2962,2963]
operator: , [3052,3053]
===
match
---
atom_expr [4451,4460]
atom_expr [4541,4550]
===
match
---
name: host_key [6181,6189]
name: host_key [6271,6279]
===
match
---
name: self [7331,7335]
name: self [7413,7417]
===
match
---
atom_expr [8193,8215]
atom_expr [8275,8297]
===
match
---
simple_stmt [9586,9834]
simple_stmt [9668,9916]
===
match
---
comparison [8467,8492]
comparison [8549,8574]
===
match
---
expr_stmt [9086,9118]
expr_stmt [9168,9200]
===
match
---
name: client [11511,11517]
name: client [11593,11599]
===
match
---
trailer [4785,4800]
trailer [4875,4890]
===
match
---
not_test [6430,6450]
not_test [6520,6540]
===
match
---
trailer [4204,4213]
trailer [4294,4303]
===
match
---
trailer [7009,7014]
trailer [7091,7096]
===
match
---
name: hook_name [2702,2711]
name: hook_name [2792,2801]
===
match
---
name: __enter__ [9548,9557]
name: __enter__ [9630,9639]
===
match
---
number: 30 [3349,3351]
number: 30 [3439,3441]
===
match
---
name: isfile [7015,7021]
name: isfile [7097,7103]
===
match
---
expr_stmt [7061,7092]
expr_stmt [7143,7174]
===
match
---
trailer [6126,6138]
trailer [6216,6228]
===
match
---
atom_expr [11460,11476]
atom_expr [11542,11558]
===
match
---
trailer [7179,7185]
trailer [7261,7267]
===
match
---
suite [7958,8181]
suite [8040,8263]
===
match
---
atom_expr [3150,3163]
atom_expr [3240,3253]
===
match
---
atom_expr [12776,12846]
atom_expr [12858,12928]
===
match
---
atom_expr [7931,7957]
atom_expr [8013,8039]
===
match
---
atom_expr [6622,6877]
atom_expr [6712,6967]
===
match
---
name: debug [7814,7819]
name: debug [7896,7901]
===
match
---
simple_stmt [8761,9047]
simple_stmt [8843,9129]
===
match
---
atom_expr [7171,7196]
atom_expr [7253,7278]
===
match
---
trailer [3840,3862]
trailer [3930,3952]
===
match
---
simple_stmt [3879,3902]
simple_stmt [3969,3992]
===
match
---
if_stmt [4448,4508]
if_stmt [4538,4598]
===
match
---
name: username [6600,6608]
name: username [6690,6698]
===
match
---
tfpdef [3220,3243]
tfpdef [3310,3333]
===
match
---
name: str [5624,5627]
name: str [5714,5717]
===
match
---
name: host_info [7556,7565]
name: host_info [7638,7647]
===
match
---
comparison [5328,5364]
comparison [5418,5454]
===
match
---
dictorsetmaker [2855,2963]
dictorsetmaker [2945,3053]
===
match
---
name: conn [4523,4527]
name: conn [4613,4617]
===
match
---
atom_expr [9586,9833]
atom_expr [9668,9915]
===
match
---
argument [8871,8891]
argument [8953,8973]
===
match
---
tfpdef [3054,3080]
tfpdef [3144,3170]
===
match
---
trailer [7935,7957]
trailer [8017,8039]
===
match
---
operator: { [2910,2911]
operator: { [3000,3001]
===
match
---
name: private_key [4978,4989]
name: private_key [5068,5079]
===
match
---
atom_expr [12655,12691]
atom_expr [12737,12773]
===
match
---
expr_stmt [10828,11159]
expr_stmt [10910,11241]
===
match
---
operator: = [11608,11609]
operator: = [11690,11691]
===
match
---
if_stmt [6427,6526]
if_stmt [6517,6616]
===
match
---
operator: , [4989,4990]
operator: , [5079,5080]
===
match
---
trailer [8245,8326]
trailer [8327,8408]
===
match
---
name: port [8951,8955]
name: port [9033,9037]
===
match
---
param [12313,12345]
param [12395,12427]
===
match
---
atom_expr [8467,8480]
atom_expr [8549,8562]
===
match
---
trailer [9063,9072]
trailer [9145,9154]
===
match
---
trailer [9116,9118]
trailer [9198,9200]
===
match
---
name: private_key_passphrase [5002,5024]
name: private_key_passphrase [5092,5114]
===
match
---
name: local_port [11556,11566]
name: local_port [11638,11648]
===
match
---
name: self [4648,4652]
name: self [4738,4742]
===
match
---
trailer [8383,8411]
trailer [8465,8493]
===
match
---
name: values [12683,12689]
name: values [12765,12771]
===
match
---
name: self [6434,6438]
name: self [6524,6528]
===
match
---
parameters [2991,3358]
parameters [3081,3448]
===
match
---
name: allowed_pkey_types [12717,12735]
name: allowed_pkey_types [12799,12817]
===
match
---
name: hostname [8796,8804]
name: hostname [8878,8886]
===
match
---
name: self [8879,8883]
name: self [8961,8965]
===
match
---
name: load_system_host_keys [8157,8178]
name: load_system_host_keys [8239,8260]
===
match
---
name: port [3610,3614]
name: port [3700,3704]
===
match
---
trailer [6894,6903]
trailer [6984,6993]
===
match
---
name: local_bind_address [11022,11040]
name: local_bind_address [11104,11122]
===
match
---
name: warning [8238,8245]
name: warning [8320,8327]
===
match
---
name: RSAKey [6201,6207]
name: RSAKey [6291,6297]
===
match
---
name: AirflowException [1090,1106]
name: AirflowException [1075,1091]
===
match
---
number: 0 [7586,7587]
number: 0 [7668,7669]
===
match
---
name: host_info [7209,7218]
name: host_info [7291,7300]
===
match
---
string: """         Creates tunnel for SSH connection [Deprecated].          :param local_port: local port number         :param remote_port: remote port number         :param remote_host: remote host         :return:         """ [11659,11880]
string: """         Creates tunnel for SSH connection [Deprecated].          :param local_port: local port number         :param remote_port: remote port number         :param remote_host: remote host         :return:         """ [11741,11962]
===
match
---
param [3296,3314]
param [3386,3404]
===
match
---
trailer [8622,8631]
trailer [8704,8713]
===
match
---
atom_expr [7489,7518]
atom_expr [7571,7600]
===
match
---
import_as_names [934,962]
import_as_names [919,947]
===
match
---
param [11573,11590]
param [11655,11672]
===
match
---
name: str [3159,3162]
name: str [3249,3252]
===
match
---
name: paramiko [2471,2479]
name: paramiko [2561,2569]
===
match
---
return_stmt [11504,11517]
return_stmt [11586,11599]
===
match
---
tfpdef [12295,12311]
tfpdef [12377,12393]
===
match
---
simple_stmt [1107,1147]
simple_stmt [1092,1132]
===
match
---
atom_expr [7894,7914]
atom_expr [7976,7996]
===
match
---
operator: -> [7656,7658]
operator: -> [7738,7740]
===
match
---
name: key_file [9262,9270]
name: key_file [9344,9352]
===
match
---
name: str [3076,3079]
name: str [3166,3169]
===
match
---
trailer [5729,5751]
trailer [5819,5841]
===
match
---
expr_stmt [6176,6230]
expr_stmt [6266,6320]
===
match
---
trailer [10947,10956]
trailer [11029,11038]
===
match
---
simple_stmt [11199,11232]
simple_stmt [11281,11314]
===
match
---
name: set_keepalive [9448,9461]
name: set_keepalive [9530,9543]
===
match
---
name: paramiko [971,979]
name: paramiko [956,964]
===
match
---
dotted_name [1064,1082]
dotted_name [1049,1067]
===
match
---
operator: = [4766,4767]
operator: = [4856,4857]
===
match
---
funcdef [9544,9854]
funcdef [9626,9936]
===
match
---
simple_stmt [3442,3473]
simple_stmt [3532,3563]
===
match
---
import_from [891,914]
import_from [876,899]
===
match
---
suite [6451,6526]
suite [6541,6616]
===
match
---
name: username [8835,8843]
name: username [8917,8925]
===
match
---
operator: = [4145,4146]
operator: = [4235,4236]
===
match
---
trailer [9447,9461]
trailer [9529,9543]
===
match
---
name: key_file [9324,9332]
name: key_file [9406,9414]
===
match
---
testlist_comp [10732,10755]
testlist_comp [10814,10837]
===
match
---
expr_stmt [5265,5286]
expr_stmt [5355,5376]
===
match
---
operator: , [12230,12231]
operator: , [12312,12313]
===
match
---
suite [5930,5978]
suite [6020,6068]
===
match
---
argument [11383,11407]
argument [11465,11489]
===
match
---
name: tunnel_kwargs [11480,11493]
name: tunnel_kwargs [11562,11575]
===
match
---
string: 'dsa' [2464,2469]
string: 'dsa' [2554,2559]
===
match
---
comparison [5162,5189]
comparison [5252,5279]
===
match
---
operator: , [8891,8892]
operator: , [8973,8974]
===
match
---
expr_stmt [2702,2719]
expr_stmt [2792,2809]
===
match
---
operator: = [3280,3281]
operator: = [3370,3371]
===
match
---
parameters [7649,7655]
parameters [7731,7737]
===
match
---
name: password [4341,4349]
name: password [4431,4439]
===
match
---
operator: , [10709,10710]
operator: , [10791,10792]
===
match
---
strings [11916,12134]
strings [11998,12216]
===
match
---
name: self [9962,9966]
name: self [10044,10048]
===
match
---
string: 'private_key_passphrase' [4860,4884]
string: 'private_key_passphrase' [4950,4974]
===
match
---
atom_expr [4365,4381]
atom_expr [4455,4471]
===
match
---
name: remote_host [4412,4423]
name: remote_host [4502,4513]
===
match
---
simple_stmt [3403,3434]
simple_stmt [3493,3524]
===
match
---
name: int [10119,10122]
name: int [10201,10204]
===
match
---
atom_expr [3403,3419]
atom_expr [3493,3509]
===
match
---
trailer [12785,12802]
trailer [12867,12884]
===
match
---
name: get_connection [4152,4166]
name: get_connection [4242,4256]
===
match
---
atom_expr [4200,4213]
atom_expr [4290,4303]
===
match
---
trailer [11176,11185]
trailer [11258,11267]
===
match
---
operator: = [7608,7609]
operator: = [7690,7691]
===
match
---
atom_expr [10700,10715]
atom_expr [10782,10797]
===
match
---
string: 'ecdsa' [2496,2503]
string: 'ecdsa' [2586,2593]
===
match
---
name: decoded_host_key [6213,6229]
name: decoded_host_key [6303,6319]
===
match
---
trailer [7809,7813]
trailer [7891,7895]
===
match
---
name: port [10876,10880]
name: port [10958,10962]
===
match
---
and_test [5328,5447]
and_test [5418,5537]
===
match
---
suite [4390,4436]
suite [4480,4526]
===
match
---
suite [8216,8438]
suite [8298,8520]
===
match
---
name: key_file [3220,3228]
name: key_file [3310,3318]
===
match
---
atom [10731,10756]
atom [10813,10838]
===
match
---
trailer [7370,7401]
trailer [7452,7483]
===
match
---
trailer [4502,4507]
trailer [4592,4597]
===
match
---
name: self [7610,7614]
name: self [7692,7696]
===
match
---
name: ssh_password [11282,11294]
name: ssh_password [11364,11376]
===
match
---
name: client [9510,9516]
name: client [9592,9598]
===
match
---
name: self [4486,4490]
name: self [4576,4580]
===
match
---
parameters [12288,12346]
parameters [12370,12428]
===
match
---
simple_stmt [3661,3706]
simple_stmt [3751,3796]
===
match
---
if_stmt [4278,4350]
if_stmt [4368,4440]
===
match
---
if_stmt [9385,9487]
if_stmt [9467,9569]
===
match
---
trailer [3118,3123]
trailer [3208,3213]
===
match
---
suite [10770,10819]
suite [10852,10901]
===
match
---
argument [10894,10920]
argument [10976,11002]
===
match
---
simple_stmt [3769,3790]
simple_stmt [3859,3880]
===
match
---
operator: = [3590,3591]
operator: = [3680,3681]
===
match
---
simple_stmt [7540,7589]
simple_stmt [7622,7671]
===
match
---
name: str [3199,3202]
name: str [3289,3292]
===
match
---
atom_expr [3836,3862]
atom_expr [3926,3952]
===
match
---
arglist [9613,9823]
arglist [9695,9905]
===
match
---
name: self [11550,11554]
name: self [11632,11636]
===
match
---
atom_expr [5393,5427]
atom_expr [5483,5517]
===
match
---
import_from [1059,1106]
import_from [1044,1091]
===
match
---
operator: = [3204,3205]
operator: = [3294,3295]
===
match
---
expr_stmt [10674,10756]
expr_stmt [10756,10838]
===
match
---
atom_expr [8778,9046]
atom_expr [8860,9128]
===
match
---
import_from [1107,1146]
import_from [1092,1131]
===
match
---
name: pkey [6247,6251]
name: pkey [6337,6341]
===
match
---
atom_expr [3376,3394]
atom_expr [3466,3484]
===
match
---
not_test [7418,7454]
not_test [7500,7536]
===
match
---
atom_expr [6890,6903]
atom_expr [6980,6993]
===
match
---
param [9558,9562]
param [9640,9644]
===
match
---
dotted_name [1112,1130]
dotted_name [1097,1115]
===
match
---
name: tunnel_kwargs [10828,10841]
name: tunnel_kwargs [10910,10923]
===
match
---
string: "host_key" [6127,6137]
string: "host_key" [6217,6227]
===
match
---
name: warning [7980,7987]
name: warning [8062,8069]
===
match
---
arglist [7820,7875]
arglist [7902,7957]
===
match
---
name: log [7976,7979]
name: log [8058,8061]
===
match
---
operator: = [8776,8777]
operator: = [8858,8859]
===
match
---
atom_expr [3879,3894]
atom_expr [3969,3984]
===
match
---
return_stmt [12196,12256]
return_stmt [12278,12338]
===
match
---
name: exc_type [9878,9886]
name: exc_type [9960,9968]
===
match
---
trailer [3238,3243]
trailer [3328,3333]
===
match
---
trailer [6207,6230]
trailer [6297,6320]
===
match
---
name: self [8914,8918]
name: self [8996,9000]
===
match
---
trailer [7987,8137]
trailer [8069,8219]
===
match
---
name: remote_host [11591,11602]
name: remote_host [11673,11684]
===
match
---
if_stmt [6588,6924]
if_stmt [6678,7006]
===
match
---
simple_stmt [10783,10819]
simple_stmt [10865,10901]
===
match
---
name: self [3514,3518]
name: self [3604,3608]
===
match
---
strings [12999,13172]
strings [13081,13254]
===
match
---
atom_expr [4407,4423]
atom_expr [4497,4513]
===
match
---
operator: , [11008,11009]
operator: , [11090,11091]
===
match
---
name: connect [9350,9357]
name: connect [9432,9439]
===
match
---
name: connect_kwargs [9131,9145]
name: connect_kwargs [9213,9227]
===
match
---
name: self [12289,12293]
name: self [12371,12375]
===
match
---
argument [8905,8927]
argument [8987,9009]
===
match
---
name: self [8589,8593]
name: self [8671,8675]
===
match
---
operator: = [3783,3784]
operator: = [3873,3874]
===
match
---
trailer [9392,9411]
trailer [9474,9493]
===
match
---
name: get [4721,4724]
name: get [4811,4814]
===
match
---
atom_expr [4098,4114]
atom_expr [4188,4204]
===
match
---
atom_expr [6029,6051]
atom_expr [6119,6141]
===
match
---
operator: , [6794,6795]
operator: , [6884,6885]
===
match
---
and_test [5997,6060]
and_test [6087,6150]
===
match
---
operator: , [12824,12825]
operator: , [12906,12907]
===
match
---
name: SSHException [12916,12928]
name: SSHException [12998,13010]
===
match
---
name: Tuple [10717,10722]
name: Tuple [10799,10804]
===
match
---
argument [11282,11303]
argument [11364,11385]
===
match
---
trailer [11214,11223]
trailer [11296,11305]
===
match
---
argument [11478,11493]
argument [11560,11575]
===
match
---
comp_op [8481,8487]
comp_op [8563,8569]
===
insert-tree
---
simple_stmt [787,819]
    string: """Hook for SSH connections.""" [787,818]
to
file_input [787,13183]
at 0
===
insert-tree
---
try_stmt [1133,1237]
    suite [1137,1185]
        simple_stmt [1142,1185]
            import_from [1142,1184]
                dotted_name [1147,1169]
                    name: airflow [1147,1154]
                    name: utils [1155,1160]
                    name: platform [1161,1169]
                name: getuser [1177,1184]
    except_clause [1185,1203]
        name: ImportError [1192,1203]
    suite [1204,1237]
        simple_stmt [1209,1237]
            import_from [1209,1236]
                name: getpass [1214,1221]
                name: getuser [1229,1236]
to
file_input [787,13183]
at 13
===
insert-node
---
name: SSHHook [1245,1252]
to
classdef [1149,13183]
at 0
===
insert-node
---
name: BaseHook [1253,1261]
to
classdef [1149,13183]
at 1
===
insert-tree
---
simple_stmt [1316,2471]
    string: """     Hook for ssh remote execution using Paramiko.     ref: https://github.com/paramiko/paramiko     This hook also lets you create ssh tunnel and serve as basis for SFTP file transfer      :param ssh_conn_id: connection id from airflow Connections from where all the required         parameters can be fetched like username, password or key_file.         Thought the priority is given to the param passed during init     :type ssh_conn_id: str     :param remote_host: remote host to connect     :type remote_host: str     :param username: username to connect to the remote_host     :type username: str     :param password: password of the username to connect to the remote_host     :type password: str     :param key_file: path to key file to use to connect to the remote_host     :type key_file: str     :param port: port of remote host to connect (Default is paramiko SSH_PORT)     :type port: int     :param timeout: timeout for the attempt to connect to the remote_host.     :type timeout: int     :param keepalive_interval: send a keepalive packet to remote host every         keepalive_interval seconds     :type keepalive_interval: int     """ [1316,2470]
to
suite [1221,13183]
at 0
===
move-tree
---
name: getuser [6914,6921]
to
atom_expr [6906,6923]
at 0
===
delete-tree
---
simple_stmt [787,819]
    string: """Hook for SSH connections.""" [787,818]
===
delete-tree
---
simple_stmt [819,834]
    import_name [819,833]
        name: getpass [826,833]
===
delete-node
---
name: SSHHook [1155,1162]
===
===
delete-node
---
name: BaseHook [1163,1171]
===
===
delete-tree
---
simple_stmt [1226,2381]
    string: """     Hook for ssh remote execution using Paramiko.     ref: https://github.com/paramiko/paramiko     This hook also lets you create ssh tunnel and serve as basis for SFTP file transfer      :param ssh_conn_id: connection id from airflow Connections from where all the required         parameters can be fetched like username, password or key_file.         Thought the priority is given to the param passed during init     :type ssh_conn_id: str     :param remote_host: remote host to connect     :type remote_host: str     :param username: username to connect to the remote_host     :type username: str     :param password: password of the username to connect to the remote_host     :type password: str     :param key_file: path to key file to use to connect to the remote_host     :type key_file: str     :param port: port of remote host to connect (Default is paramiko SSH_PORT)     :type port: int     :param timeout: timeout for the attempt to connect to the remote_host.     :type timeout: int     :param keepalive_interval: send a keepalive packet to remote host every         keepalive_interval seconds     :type keepalive_interval: int     """ [1226,2380]
===
delete-node
---
name: getpass [6906,6913]
===
===
delete-node
---
trailer [6913,6921]
===
