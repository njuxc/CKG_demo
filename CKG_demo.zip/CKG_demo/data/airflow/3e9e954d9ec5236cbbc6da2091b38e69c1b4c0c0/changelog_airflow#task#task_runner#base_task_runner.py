===
match
---
atom_expr [6698,6712]
atom_expr [6718,6732]
===
match
---
name: rstrip [4851,4857]
name: rstrip [4871,4877]
===
match
---
operator: , [1660,1661]
operator: , [1688,1689]
===
match
---
atom_expr [2051,2067]
atom_expr [2079,2095]
===
match
---
name: self [3846,3850]
name: self [3866,3870]
===
match
---
operator: , [4739,4740]
operator: , [4759,4760]
===
match
---
trailer [5855,5862]
trailer [5875,5882]
===
match
---
fstring_string: = [3284,3285]
fstring_string: = [3304,3305]
===
match
---
arglist [3102,3120]
arglist [3122,3140]
===
match
---
name: call [6678,6682]
name: call [6698,6702]
===
match
---
atom_expr [2171,2187]
atom_expr [2199,2215]
===
match
---
name: getuser [2465,2472]
name: getuser [2485,2492]
===
match
---
trailer [5242,5251]
trailer [5262,5271]
===
match
---
trailer [5310,5312]
trailer [5330,5332]
===
match
---
trailer [5669,5676]
trailer [5689,5696]
===
match
---
and_test [2415,2475]
and_test [2443,2495]
===
match
---
operator: , [2943,2944]
operator: , [2963,2964]
===
match
---
if_stmt [6564,6791]
if_stmt [6584,6811]
===
match
---
name: subprocess [5430,5440]
name: subprocess [5450,5460]
===
match
---
name: self [4801,4805]
name: self [4821,4825]
===
match
---
argument [3977,4017]
argument [3997,4037]
===
match
---
atom_expr [2796,2831]
atom_expr [2816,2851]
===
match
---
operator: , [5468,5469]
operator: , [5488,5489]
===
match
---
name: NotImplementedError [6426,6445]
name: NotImplementedError [6446,6465]
===
match
---
operator: -> [6104,6106]
operator: -> [6124,6126]
===
match
---
name: start [5928,5933]
name: start [5948,5953]
===
match
---
trailer [3850,3865]
trailer [3870,3885]
===
match
---
simple_stmt [6420,6448]
simple_stmt [6440,6468]
===
match
---
operator: , [2981,2982]
operator: , [3001,3002]
===
match
---
trailer [4228,4236]
trailer [4248,4256]
===
match
---
simple_stmt [3068,3122]
simple_stmt [3088,3142]
===
match
---
trailer [3181,3193]
trailer [3201,3213]
===
match
---
arglist [6683,6729]
arglist [6703,6749]
===
match
---
import_from [1095,1157]
import_from [1080,1142]
===
match
---
operator: , [3175,3176]
operator: , [3195,3196]
===
match
---
name: line [4645,4649]
name: line [4665,4669]
===
match
---
atom_expr [1818,1837]
atom_expr [1846,1865]
===
match
---
trailer [4616,4625]
trailer [4636,4645]
===
match
---
name: decode [4610,4616]
name: decode [4630,4636]
===
match
---
name: taskinstance [1059,1071]
name: taskinstance [1044,1056]
===
match
---
dotted_name [990,1008]
dotted_name [975,993]
===
match
---
name: self [4427,4431]
name: self [4447,4451]
===
match
---
operator: { [3285,3286]
operator: { [3305,3306]
===
match
---
name: popen_prepend [3818,3831]
name: popen_prepend [3838,3851]
===
match
---
arglist [2352,2402]
arglist [2380,2430]
===
match
---
suite [4316,4445]
suite [4336,4465]
===
match
---
name: run_as_user [1928,1939]
name: run_as_user [1956,1967]
===
match
---
name: name [4200,4204]
name: name [4220,4224]
===
match
---
trailer [4187,4199]
trailer [4207,4219]
===
match
---
trailer [2074,2078]
trailer [2102,2106]
===
match
---
name: load_error_file [4411,4426]
name: load_error_file [4431,4446]
===
match
---
name: Thread [5784,5790]
name: Thread [5804,5810]
===
match
---
name: os [5667,5669]
name: os [5687,5689]
===
match
---
name: airflow [1163,1170]
name: airflow [1148,1155]
===
match
---
atom_expr [5625,5642]
atom_expr [5645,5662]
===
match
---
operator: , [4863,4864]
operator: , [4883,4884]
===
match
---
name: cfg_path [2785,2793]
name: cfg_path [2805,2813]
===
match
---
name: PYTHONPATH_VAR [1259,1273]
name: PYTHONPATH_VAR [1287,1301]
===
match
---
string: '' [3118,3120]
string: '' [3138,3140]
===
match
---
trailer [1822,1837]
trailer [1850,1865]
===
match
---
comparison [2437,2474]
comparison [2465,2494]
===
match
---
operator: , [4904,4905]
operator: , [4924,4925]
===
match
---
name: load_error_file [1079,1094]
name: load_error_file [1064,1079]
===
match
---
name: LoggingMixin [1202,1214]
name: LoggingMixin [1187,1199]
===
match
---
operator: = [2992,2993]
operator: = [3012,3013]
===
match
---
import_name [825,834]
import_name [810,819]
===
match
---
trailer [3792,3801]
trailer [3812,3821]
===
match
---
trailer [2419,2431]
trailer [2469,2481]
===
match
---
string: 'Job %s: Subtask %s %s' [4716,4739]
string: 'Job %s: Subtask %s %s' [4736,4759]
===
match
---
trailer [6815,6821]
trailer [6835,6841]
===
match
---
name: return_code [6086,6097]
name: return_code [6106,6117]
===
match
---
and_test [6567,6616]
and_test [6587,6636]
===
match
---
string: "Running on host: %s" [5275,5296]
string: "Running on host: %s" [5295,5316]
===
match
---
simple_stmt [5944,5956]
simple_stmt [5964,5976]
===
match
---
name: utils [1228,1233]
name: utils [1213,1218]
===
match
---
parameters [4469,4483]
parameters [4489,4503]
===
match
---
simple_stmt [1818,1869]
simple_stmt [1846,1897]
===
match
---
simple_stmt [835,853]
simple_stmt [820,838]
===
match
---
simple_stmt [870,910]
simple_stmt [855,895]
===
match
---
suite [2034,2112]
suite [2062,2140]
===
match
---
operator: = [4914,4915]
operator: = [4934,4935]
===
match
---
name: run_with [5193,5201]
name: run_with [5213,5221]
===
match
---
import_from [1039,1094]
import_from [1024,1079]
===
match
---
operator: , [4302,4303]
operator: , [4322,4323]
===
match
---
name: log_reader [5884,5894]
name: log_reader [5904,5914]
===
match
---
if_stmt [2412,3686]
if_stmt [2440,3706]
===
match
---
simple_stmt [2785,2832]
simple_stmt [2805,2852]
===
match
---
name: local_task_job [1662,1676]
name: local_task_job [1690,1704]
===
match
---
name: get [2075,2078]
name: get [2103,2106]
===
match
---
name: popen_prepend [3134,3147]
name: popen_prepend [3154,3167]
===
match
---
atom_expr [5851,5862]
atom_expr [5871,5882]
===
match
---
suite [3228,3306]
suite [3248,3326]
===
match
---
operator: = [4237,4238]
operator: = [4257,4258]
===
match
---
operator: , [5349,5350]
operator: , [5369,5370]
===
match
---
atom_expr [5430,5687]
atom_expr [5450,5707]
===
match
---
name: airflow [1044,1051]
name: airflow [1029,1036]
===
match
---
operator: = [3934,3935]
operator: = [3954,3955]
===
match
---
atom_expr [3650,3685]
atom_expr [3670,3705]
===
match
---
name: self [5238,5242]
name: self [5258,5262]
===
match
---
name: configuration [1114,1127]
name: configuration [1099,1112]
===
match
---
operator: = [3902,3903]
operator: = [3922,3923]
===
match
---
trailer [6677,6682]
trailer [6697,6702]
===
match
---
expr_stmt [5216,5251]
expr_stmt [5236,5271]
===
match
---
simple_stmt [5917,5936]
simple_stmt [5937,5956]
===
match
---
atom_expr [5811,5831]
atom_expr [5831,5851]
===
match
---
argument [5482,5504]
argument [5502,5524]
===
match
---
suite [1326,6824]
suite [1354,6844]
===
match
---
expr_stmt [3695,3745]
expr_stmt [3715,3765]
===
match
---
funcdef [6453,6824]
funcdef [6473,6844]
===
match
---
trailer [4539,4541]
trailer [4559,4561]
===
match
---
name: line [4846,4850]
name: line [4866,4870]
===
match
---
trailer [1854,1868]
trailer [1882,1896]
===
match
---
operator: + [3844,3845]
operator: + [3864,3865]
===
match
---
simple_stmt [4224,4244]
simple_stmt [4244,4264]
===
match
---
testlist_comp [6684,6712]
testlist_comp [6704,6732]
===
match
---
name: chmod [2819,2824]
name: chmod [2839,2844]
===
match
---
simple_stmt [6799,6824]
simple_stmt [6819,6844]
===
match
---
name: info [5331,5335]
name: info [5351,5355]
===
match
---
suite [6481,6824]
suite [6501,6844]
===
match
---
name: preexec_fn [5656,5666]
name: preexec_fn [5676,5686]
===
match
---
expr_stmt [5182,5207]
expr_stmt [5202,5227]
===
match
---
import_from [985,1038]
import_from [970,1023]
===
match
---
trailer [5446,5687]
trailer [5466,5707]
===
match
---
name: LoggingMixin [1312,1324]
name: LoggingMixin [1340,1352]
===
match
---
suite [5977,6077]
suite [5997,6097]
===
match
---
argument [4077,4101]
argument [4097,4121]
===
match
---
fstring_expr [3268,3284]
fstring_expr [3288,3304]
===
match
---
argument [5804,5831]
argument [5824,5851]
===
match
---
string: """Force kill the running task instance.""" [6368,6411]
string: """Force kill the running task instance.""" [6388,6431]
===
match
---
name: self [6698,6702]
name: self [6718,6722]
===
match
---
atom_expr [1972,2003]
atom_expr [2000,2031]
===
match
---
string: 'sudo' [3151,3157]
string: 'sudo' [3171,3177]
===
match
---
trailer [4426,4444]
trailer [4446,4464]
===
match
---
string: """         :return: The return code associated with running the task instance or             None if the task is not yet done.         :rtype: int         """ [6130,6289]
string: """         :return: The return code associated with running the task instance or             None if the task is not yet done.         :rtype: int         """ [6150,6309]
===
match
---
name: self [6345,6349]
name: self [6365,6369]
===
match
---
raise_stmt [6049,6076]
raise_stmt [6069,6096]
===
match
---
argument [2983,2997]
argument [3003,3017]
===
match
---
name: task_instance [1855,1868]
name: task_instance [1883,1896]
===
match
---
name: run_as_user [6638,6649]
name: run_as_user [6658,6669]
===
match
---
operator: -> [6351,6353]
operator: -> [6371,6373]
===
match
---
atom_expr [2415,2431]
atom_expr [2465,2481]
===
match
---
name: pickle_id [3950,3959]
name: pickle_id [3970,3979]
===
match
---
suite [2476,3306]
suite [2496,3326]
===
match
---
simple_stmt [5261,5314]
simple_stmt [5281,5334]
===
match
---
trailer [2078,2111]
trailer [2106,2139]
===
match
---
name: _command [3793,3801]
name: _command [3813,3821]
===
match
---
name: full_cmd [5460,5468]
name: full_cmd [5480,5488]
===
match
---
trailer [5627,5635]
trailer [5647,5655]
===
match
---
operator: = [5191,5192]
operator: = [5211,5212]
===
match
---
suite [4581,4626]
suite [4601,4646]
===
match
---
funcdef [1643,4244]
funcdef [1671,4264]
===
match
---
or_test [5193,5207]
or_test [5213,5227]
===
match
---
name: self [2337,2341]
name: self [2365,2369]
===
match
---
simple_stmt [1215,1258]
simple_stmt [1200,1243]
===
match
---
name: _task_instance [1823,1837]
name: _task_instance [1851,1865]
===
match
---
trailer [5933,5935]
trailer [5953,5955]
===
match
---
name: AirflowConfigException [1016,1038]
name: AirflowConfigException [1001,1023]
===
match
---
name: remove [6768,6774]
name: remove [6788,6794]
===
match
---
operator: = [3989,3990]
operator: = [4009,4010]
===
match
---
operator: = [2068,2069]
operator: = [2096,2097]
===
match
---
simple_stmt [2171,2195]
simple_stmt [2199,2223]
===
match
---
atom_expr [6799,6823]
atom_expr [6819,6843]
===
match
---
atom_expr [6107,6120]
atom_expr [6127,6140]
===
match
---
operator: , [3157,3158]
operator: , [3177,3178]
===
match
---
operator: , [3169,3170]
operator: , [3189,3190]
===
match
---
name: close_fds [2983,2992]
name: close_fds [3003,3012]
===
match
---
name: NotImplementedError [6055,6074]
name: NotImplementedError [6075,6094]
===
match
---
name: self [6799,6803]
name: self [6819,6823]
===
match
---
trailer [4805,4820]
trailer [4825,4840]
===
match
---
return_stmt [5944,5955]
return_stmt [5964,5975]
===
match
---
import_as_names [929,944]
import_as_names [914,929]
===
match
---
name: _error_file [4432,4443]
name: _error_file [4452,4463]
===
match
---
trailer [2345,2351]
trailer [2373,2379]
===
match
---
argument [3673,3684]
argument [3693,3704]
===
match
---
operator: , [5642,5643]
operator: , [5662,5663]
===
match
---
name: self [4900,4904]
name: self [4920,4924]
===
match
---
string: "--error-file" [4167,4181]
string: "--error-file" [4187,4201]
===
match
---
trailer [3865,3881]
trailer [3885,3901]
===
match
---
trailer [3672,3685]
trailer [3692,3705]
===
match
---
atom_expr [3714,3745]
atom_expr [3734,3765]
===
match
---
operator: = [6724,6725]
operator: = [6744,6745]
===
match
---
argument [4119,4136]
argument [4139,4156]
===
match
---
string: 'default_impersonation' [2087,2110]
string: 'default_impersonation' [2115,2138]
===
match
---
parameters [6344,6350]
parameters [6364,6370]
===
match
---
name: self [3754,3758]
name: self [3774,3778]
===
match
---
name: self [6601,6605]
name: self [6621,6625]
===
match
---
operator: , [5296,5297]
operator: , [5316,5317]
===
match
---
string: '-E' [3159,3163]
string: '-E' [3179,3183]
===
match
---
string: """A callback that should be called when this is done running.""" [6490,6555]
string: """A callback that should be called when this is done running.""" [6510,6575]
===
match
---
name: on_finish [6457,6466]
name: on_finish [6477,6486]
===
match
---
operator: = [1274,1275]
operator: = [1302,1303]
===
match
---
name: self [5322,5326]
name: self [5342,5346]
===
match
---
atom_expr [4685,4878]
atom_expr [4705,4898]
===
match
---
atom_expr [2954,2970]
atom_expr [2974,2990]
===
match
---
string: """     Runs Airflow task instances by invoking the `airflow tasks run` command with raw     mode enabled in a subprocess.      :param local_task_job: The local task job associated with running the         associated task instance.     :type local_task_job: airflow.jobs.local_task_job.LocalTaskJob     """ [1331,1637]
string: """     Runs Airflow task instances by invoking the `airflow tasks run` command with raw     mode enabled in a subprocess.      :param local_task_job: The local task job associated with running the         associated task instance.     :type local_task_job: airflow.jobs.local_task_job.LocalTaskJob     """ [1359,1665]
===
match
---
name: local_task_job [3935,3949]
name: local_task_job [3955,3969]
===
match
---
atom_expr [5322,5360]
atom_expr [5342,5380]
===
match
---
suite [1940,2004]
suite [1968,2032]
===
match
---
name: get_hostname [1245,1257]
name: get_hostname [1230,1242]
===
match
---
trailer [6445,6447]
trailer [6465,6467]
===
match
---
arglist [3899,4137]
arglist [3919,4157]
===
match
---
operator: = [3802,3803]
operator: = [3822,3823]
===
match
---
name: self [3788,3792]
name: self [3808,3812]
===
match
---
import_name [853,869]
import_name [838,854]
===
match
---
name: readline [4531,4539]
name: readline [4551,4559]
===
match
---
name: _task_instance [4806,4820]
name: _task_instance [4826,4840]
===
match
---
trailer [5640,5642]
trailer [5660,5662]
===
match
---
testlist_comp [3151,3193]
testlist_comp [3171,3213]
===
match
---
operator: = [5488,5489]
operator: = [5508,5509]
===
match
---
operator: , [5862,5863]
operator: , [5882,5883]
===
match
---
name: universal_newlines [5556,5574]
name: universal_newlines [5576,5594]
===
match
---
name: cfg_path [3771,3779]
name: cfg_path [3791,3799]
===
match
---
name: stdout [5482,5488]
name: stdout [5502,5508]
===
match
---
operator: = [2794,2795]
operator: = [2814,2815]
===
match
---
operator: = [3712,3713]
operator: = [3732,3733]
===
match
---
atom_expr [6304,6325]
atom_expr [6324,6345]
===
match
---
trailer [4004,4017]
trailer [4024,4037]
===
match
---
atom_expr [4846,4863]
atom_expr [4866,4883]
===
match
---
name: mark_success [3977,3989]
name: mark_success [3997,4009]
===
match
---
name: local_task_job [1840,1854]
name: local_task_job [1868,1882]
===
match
---
name: self [4685,4689]
name: self [4705,4709]
===
match
---
dotted_name [1163,1194]
dotted_name [1148,1179]
===
match
---
name: subprocess [6667,6677]
name: subprocess [6687,6697]
===
match
---
expr_stmt [3639,3685]
expr_stmt [3659,3705]
===
match
---
param [4906,4919]
param [4926,4939]
===
match
---
suite [2154,2195]
suite [2182,2223]
===
match
---
name: self [2954,2958]
name: self [2974,2978]
===
match
---
parameters [4899,4920]
parameters [4919,4940]
===
match
---
fstring [3266,3304]
fstring [3286,3324]
===
match
---
funcdef [6082,6326]
funcdef [6102,6346]
===
match
---
atom_expr [3788,3801]
atom_expr [3808,3821]
===
match
---
name: pickle_id [3925,3934]
name: pickle_id [3945,3954]
===
match
---
name: job_id [4035,4041]
name: job_id [4055,4061]
===
match
---
atom_expr [4293,4314]
atom_expr [4313,4334]
===
match
---
if_stmt [6630,6791]
if_stmt [6650,6811]
===
match
---
simple_stmt [4325,4396]
simple_stmt [4345,4416]
===
match
---
trailer [6803,6815]
trailer [6823,6835]
===
match
---
trailer [2958,2970]
trailer [2978,2990]
===
match
---
dotted_name [1100,1127]
dotted_name [1085,1112]
===
match
---
name: log_reader [5761,5771]
name: log_reader [5781,5791]
===
match
---
operator: = [4603,4604]
operator: = [4623,4624]
===
match
---
return_stmt [4404,4444]
return_stmt [4424,4464]
===
match
---
operator: , [4136,4137]
operator: , [4156,4157]
===
match
---
argument [5518,5542]
argument [5538,5562]
===
match
---
name: _read_task_logs [5816,5831]
name: _read_task_logs [5836,5851]
===
match
---
expr_stmt [1953,2003]
expr_stmt [1981,2031]
===
match
---
trailer [3881,4151]
trailer [3901,4171]
===
match
---
atom_expr [2920,2998]
atom_expr [2940,3018]
===
match
---
name: local_task_job [3990,4004]
name: local_task_job [4010,4024]
===
match
---
argument [5556,5579]
argument [5576,5599]
===
match
---
name: path [6589,6593]
name: path [6609,6613]
===
match
---
string: 'utf-8' [4617,4624]
string: 'utf-8' [4637,4644]
===
match
---
name: BaseTaskRunner [1297,1311]
name: BaseTaskRunner [1325,1339]
===
match
---
operator: , [4101,4102]
operator: , [4121,4122]
===
match
---
name: self [1972,1976]
name: self [2000,2004]
===
match
---
name: log [2342,2345]
name: log [2370,2373]
===
match
---
atom_expr [2457,2474]
atom_expr [2485,2494]
===
match
---
operator: , [5542,5543]
operator: , [5562,5563]
===
match
---
name: models [1052,1058]
name: models [1037,1043]
===
match
---
name: info [4694,4698]
name: info [4714,4718]
===
match
---
trailer [1991,2003]
trailer [2019,2031]
===
match
---
name: self [1953,1957]
name: self [1981,1985]
===
match
---
suite [4504,4879]
suite [4524,4899]
===
match
---
simple_stmt [2920,2999]
simple_stmt [2940,3019]
===
match
---
fstring_expr [3285,3303]
fstring_expr [3305,3323]
===
match
---
name: line [4568,4572]
name: line [4588,4592]
===
match
---
argument [3925,3959]
argument [3945,3979]
===
match
---
import_from [910,944]
import_from [895,929]
===
match
---
name: net [1234,1237]
name: net [1219,1222]
===
match
---
trailer [4857,4863]
trailer [4877,4883]
===
match
---
name: environ [3090,3097]
name: environ [3110,3117]
===
match
---
name: self [2386,2390]
name: self [2414,2418]
===
match
---
atom_expr [1780,1808]
atom_expr [1808,1836]
===
match
---
operator: + [5236,5237]
operator: + [5256,5257]
===
match
---
trailer [6323,6325]
trailer [6343,6345]
===
match
---
trailer [5790,5875]
trailer [5810,5895]
===
match
---
trailer [2175,2187]
trailer [2203,2215]
===
match
---
name: run_command [4888,4899]
name: run_command [4908,4919]
===
match
---
expr_stmt [5423,5687]
expr_stmt [5443,5707]
===
match
---
simple_stmt [825,835]
simple_stmt [810,820]
===
match
---
name: cfg_path [2972,2980]
name: cfg_path [2992,3000]
===
match
---
trailer [6774,6790]
trailer [6794,6810]
===
match
---
name: self [6775,6779]
name: self [6795,6799]
===
match
---
name: airflow [990,997]
name: airflow [975,982]
===
match
---
simple_stmt [3754,3780]
simple_stmt [3774,3800]
===
match
---
arglist [4568,4579]
arglist [4588,4599]
===
match
---
trailer [4689,4693]
trailer [4709,4713]
===
match
---
trailer [4820,4828]
trailer [4840,4848]
===
match
---
simple_stmt [5884,5909]
simple_stmt [5904,5929]
===
match
---
name: run_as_user [2056,2067]
name: run_as_user [2084,2095]
===
match
---
name: run_as_user [2176,2187]
name: run_as_user [2204,2215]
===
match
---
atom_expr [6426,6447]
atom_expr [6446,6467]
===
match
---
file_input [787,6824]
file_input [787,6844]
===
match
---
name: log_reader [5917,5927]
name: log_reader [5937,5947]
===
match
---
string: 'sudo' [6684,6690]
string: 'sudo' [6704,6710]
===
match
---
try_stmt [2030,2195]
try_stmt [2058,2223]
===
match
---
atom_expr [6567,6581]
atom_expr [6587,6601]
===
match
---
name: self [4224,4228]
name: self [4244,4248]
===
match
---
number: 0o600 [2825,2830]
number: 0o600 [2845,2850]
===
match
---
name: debug [2346,2351]
name: debug [2374,2379]
===
match
---
suite [6121,6326]
suite [6141,6346]
===
match
---
name: STDOUT [5536,5542]
name: STDOUT [5556,5562]
===
match
---
import_from [870,909]
import_from [855,894]
===
match
---
param [1656,1661]
param [1684,1689]
===
match
---
simple_stmt [946,985]
simple_stmt [931,970]
===
match
---
name: raw [3899,3902]
name: raw [3919,3922]
===
match
---
name: __init__ [1647,1655]
name: __init__ [1675,1683]
===
match
---
suite [6650,6731]
suite [6670,6751]
===
match
---
expr_stmt [4517,4541]
expr_stmt [4537,4561]
===
match
---
string: 'Running: %s' [5336,5349]
string: 'Running: %s' [5356,5369]
===
match
---
trailer [3758,3768]
trailer [3778,3788]
===
match
---
name: subprocess [5489,5499]
name: subprocess [5509,5519]
===
match
---
testlist_comp [5851,5863]
testlist_comp [5871,5883]
===
match
---
raise_stmt [6298,6325]
raise_stmt [6318,6345]
===
match
---
name: NamedTemporaryFile [891,909]
name: NamedTemporaryFile [876,894]
===
match
---
trailer [4776,4783]
trailer [4796,4803]
===
match
---
parameters [5970,5976]
parameters [5990,5996]
===
match
---
param [5971,5975]
param [5991,5995]
===
match
---
simple_stmt [5761,5876]
simple_stmt [5781,5896]
===
match
---
atom_expr [4524,4541]
atom_expr [4544,4561]
===
match
---
name: log [4690,4693]
name: log [4710,4713]
===
match
---
trailer [4199,4204]
trailer [4219,4224]
===
match
---
name: tmp_configuration_copy [2796,2818]
name: tmp_configuration_copy [2816,2838]
===
match
---
name: self [3695,3699]
name: self [3715,3719]
===
match
---
name: isinstance [4557,4567]
name: isinstance [4577,4587]
===
match
---
expr_stmt [4224,4243]
expr_stmt [4244,4263]
===
match
---
operator: , [3907,3908]
operator: , [3927,3928]
===
match
---
atom [3804,4215]
atom [3824,4235]
===
match
---
trailer [6571,6581]
trailer [6591,6601]
===
match
---
name: stderr [5518,5524]
name: stderr [5538,5544]
===
match
---
name: os [3087,3089]
name: os [3107,3109]
===
match
---
operator: = [1970,1971]
operator: = [1998,1999]
===
match
---
expr_stmt [5884,5908]
expr_stmt [5904,5928]
===
match
---
atom_expr [6586,6616]
atom_expr [6606,6636]
===
match
---
suite [3320,3686]
suite [3340,3706]
===
match
---
operator: = [4081,4082]
operator: = [4101,4102]
===
match
---
name: stream [4476,4482]
name: stream [4496,4502]
===
match
---
name: call [2931,2935]
name: call [2951,2955]
===
match
---
atom_expr [3087,3121]
atom_expr [3107,3141]
===
match
---
atom_expr [3695,3711]
atom_expr [3715,3731]
===
match
---
trailer [3101,3121]
trailer [3121,3141]
===
match
---
name: self [3177,3181]
name: self [3197,3201]
===
match
---
parameters [4274,4280]
parameters [4294,4300]
===
match
---
simple_stmt [6368,6412]
simple_stmt [6388,6432]
===
match
---
operator: , [5504,5505]
operator: , [5524,5525]
===
match
---
name: airflow [1100,1107]
name: airflow [1085,1092]
===
match
---
atom [5205,5207]
atom [5225,5227]
===
match
---
name: proc [5423,5427]
name: proc [5443,5447]
===
match
---
simple_stmt [2337,2404]
simple_stmt [2365,2432]
===
match
---
name: append [3259,3265]
name: append [3279,3285]
===
match
---
name: line [4598,4602]
name: line [4618,4622]
===
match
---
expr_stmt [1818,1868]
expr_stmt [1846,1896]
===
match
---
atom_expr [5261,5313]
atom_expr [5281,5333]
===
match
---
name: mark_success [4005,4017]
name: mark_success [4025,4037]
===
match
---
operator: , [5607,5608]
operator: , [5627,5628]
===
match
---
name: task_instance [1795,1808]
name: task_instance [1823,1836]
===
match
---
funcdef [5961,6077]
funcdef [5981,6097]
===
match
---
trailer [1779,1809]
trailer [1807,1837]
===
match
---
trailer [4609,4616]
trailer [4629,4636]
===
match
---
if_stmt [1905,2195]
if_stmt [1933,2223]
===
match
---
name: self [5811,5815]
name: self [5831,5835]
===
match
---
expr_stmt [3068,3121]
expr_stmt [3088,3141]
===
match
---
trailer [4850,4857]
trailer [4870,4877]
===
match
---
name: proc [5851,5855]
name: proc [5871,5875]
===
match
---
atom_expr [4082,4101]
atom_expr [4102,4121]
===
match
---
trailer [4567,4580]
trailer [4587,4600]
===
match
---
name: Exception [4304,4313]
name: Exception [4324,4333]
===
match
---
param [4476,4482]
param [4496,4502]
===
match
---
name: environ [5628,5635]
name: environ [5648,5655]
===
match
---
name: cfg_path [4119,4127]
name: cfg_path [4139,4147]
===
match
---
simple_stmt [5423,5688]
simple_stmt [5443,5708]
===
match
---
name: copy [5636,5640]
name: copy [5656,5660]
===
match
---
funcdef [6331,6448]
funcdef [6351,6468]
===
match
---
operator: , [5864,5865]
operator: , [5884,5885]
===
match
---
name: subprocess [2920,2930]
name: subprocess [2940,2950]
===
match
---
trailer [2441,2453]
trailer [2447,2459]
===
match
---
trailer [5894,5901]
trailer [5914,5921]
===
match
---
trailer [4431,4443]
trailer [4451,4463]
===
match
---
operator: , [4572,4573]
operator: , [4592,4593]
===
match
---
name: self [1656,1660]
name: self [1684,1688]
===
match
---
dotted_name [951,972]
dotted_name [936,957]
===
match
---
name: int [6116,6119]
name: int [6136,6139]
===
match
---
simple_stmt [6667,6731]
simple_stmt [6687,6751]
===
match
---
simple_stmt [6765,6791]
simple_stmt [6785,6811]
===
match
---
atom_expr [5774,5875]
atom_expr [5794,5895]
===
match
---
name: os [5625,5627]
name: os [5645,5647]
===
match
---
simple_stmt [787,810]
simple_stmt [787,810]
===
match
---
trailer [4298,4314]
trailer [4318,4334]
===
match
---
name: _error_file [4188,4199]
name: _error_file [4208,4219]
===
match
---
argument [3899,3907]
argument [3919,3927]
===
match
---
fstring_end: ' [3303,3304]
fstring_end: ' [3323,3324]
===
match
---
name: self [1818,1822]
name: self [1846,1850]
===
match
---
not_test [4641,4649]
not_test [4661,4669]
===
match
---
operator: , [2384,2385]
operator: , [2412,2413]
===
match
---
trailer [1957,1969]
trailer [1985,1997]
===
match
---
simple_stmt [4404,4445]
simple_stmt [4424,4465]
===
match
---
simple_stmt [6298,6326]
simple_stmt [6318,6346]
===
match
---
name: local_task_job [1780,1794]
name: local_task_job [1808,1822]
===
match
---
expr_stmt [2051,2111]
expr_stmt [2079,2139]
===
match
---
atom_expr [4557,4580]
atom_expr [4577,4600]
===
match
---
simple_stmt [6490,6556]
simple_stmt [6510,6576]
===
match
---
name: _cfg_path [3759,3768]
name: _cfg_path [3779,3788]
===
match
---
param [6345,6349]
param [6365,6369]
===
match
---
name: close [6816,6821]
name: close [6836,6841]
===
match
---
param [4470,4475]
param [4490,4495]
===
match
---
operator: , [4017,4018]
operator: , [4037,4038]
===
match
---
trailer [1912,1927]
trailer [1940,1955]
===
match
---
trailer [5265,5269]
trailer [5285,5289]
===
match
---
trailer [6593,6600]
trailer [6613,6620]
===
match
---
simple_stmt [3639,3686]
simple_stmt [3659,3706]
===
match
---
operator: , [5831,5832]
operator: , [5851,5852]
===
match
---
simple_stmt [853,870]
simple_stmt [838,855]
===
match
---
suite [2017,2195]
suite [2045,2223]
===
match
---
name: popen_prepend [3245,3258]
name: popen_prepend [3265,3278]
===
match
---
name: logging_mixin [1181,1194]
name: logging_mixin [1166,1179]
===
match
---
operator: , [6696,6697]
operator: , [6716,6717]
===
match
---
trailer [3089,3097]
trailer [3109,3117]
===
match
---
operator: = [5902,5903]
operator: = [5922,5923]
===
match
---
name: pool [4097,4101]
name: pool [4117,4121]
===
match
---
name: airflow [951,958]
name: airflow [936,943]
===
match
---
name: tempfile [875,883]
name: tempfile [860,868]
===
match
---
import_from [946,984]
import_from [931,969]
===
match
---
operator: = [5772,5773]
operator: = [5792,5793]
===
match
---
expr_stmt [2171,2194]
expr_stmt [2199,2222]
===
match
---
arglist [5275,5312]
arglist [5295,5332]
===
match
---
operator: = [5624,5625]
operator: = [5644,5645]
===
match
---
name: pool [4077,4081]
name: pool [4097,4101]
===
match
---
name: close_fds [6715,6724]
name: close_fds [6735,6744]
===
match
---
simple_stmt [6049,6077]
simple_stmt [6069,6097]
===
match
---
simple_stmt [3695,3746]
simple_stmt [3715,3766]
===
match
---
name: setsid [5670,5676]
name: setsid [5690,5696]
===
match
---
atom_expr [6775,6789]
atom_expr [6795,6809]
===
match
---
operator: = [5574,5575]
operator: = [5594,5595]
===
match
---
atom [1894,1896]
atom [1922,1924]
===
match
---
simple_stmt [1158,1215]
simple_stmt [1143,1200]
===
match
---
simple_stmt [5986,6041]
simple_stmt [6006,6061]
===
match
---
trailer [5326,5330]
trailer [5346,5350]
===
match
---
atom_expr [1763,1809]
atom_expr [1791,1837]
===
match
---
suite [1678,4244]
suite [1706,4264]
===
match
---
simple_stmt [1095,1158]
simple_stmt [1080,1143]
===
match
---
parameters [6097,6103]
parameters [6117,6123]
===
match
---
operator: , [6713,6714]
operator: , [6733,6734]
===
match
---
name: run_with [5227,5235]
name: run_with [5247,5255]
===
match
---
trailer [3265,3305]
trailer [3285,3325]
===
match
---
trailer [6779,6789]
trailer [6799,6809]
===
match
---
name: PIPE [5500,5504]
name: PIPE [5520,5524]
===
match
---
name: run_as_user [1958,1969]
name: run_as_user [1986,1997]
===
match
---
atom [6683,6713]
atom [6703,6733]
===
match
---
suite [6359,6448]
suite [6379,6468]
===
match
---
operator: , [4059,4060]
operator: , [4079,4080]
===
match
---
atom_expr [5667,5676]
atom_expr [5687,5696]
===
match
---
trailer [2818,2831]
trailer [2838,2851]
===
match
---
operator: -> [4281,4283]
operator: -> [4301,4303]
===
match
---
name: _cfg_path [6703,6712]
name: _cfg_path [6723,6732]
===
match
---
atom_expr [4605,4625]
atom_expr [4625,4645]
===
match
---
suite [4484,4879]
suite [4504,4899]
===
match
---
name: super [1763,1768]
name: super [1791,1796]
===
match
---
argument [4035,4059]
argument [4055,4079]
===
match
---
arglist [2936,2997]
arglist [2956,3017]
===
match
---
atom [2936,2981]
atom [2956,3001]
===
match
---
funcdef [4249,4445]
funcdef [4269,4465]
===
match
---
trailer [3699,3711]
trailer [3719,3731]
===
match
---
trailer [4530,4539]
trailer [4550,4559]
===
match
---
trailer [4693,4698]
trailer [4713,4718]
===
match
---
atom_expr [6765,6790]
atom_expr [6785,6810]
===
match
---
operator: = [3085,3086]
operator: = [3105,3106]
===
match
---
name: command_as_list [3866,3881]
name: command_as_list [3886,3901]
===
match
---
expr_stmt [3788,4215]
expr_stmt [3808,4235]
===
match
---
simple_stmt [1878,1897]
simple_stmt [1906,1925]
===
match
---
testlist_comp [4167,4204]
testlist_comp [4187,4224]
===
match
---
argument [5593,5607]
argument [5613,5627]
===
match
---
trailer [6702,6712]
trailer [6722,6732]
===
match
---
name: self [5971,5975]
name: self [5991,5995]
===
match
---
atom_expr [6633,6649]
atom_expr [6653,6669]
===
match
---
operator: = [5225,5226]
operator: = [5245,5246]
===
match
---
name: info [5270,5274]
name: info [5290,5294]
===
match
---
name: NamedTemporaryFile [3714,3732]
name: NamedTemporaryFile [3734,3752]
===
match
---
trailer [2935,2998]
trailer [2955,3018]
===
match
---
trailer [1927,1939]
trailer [1955,1967]
===
match
---
atom_expr [1953,1969]
atom_expr [1981,1997]
===
match
---
atom_expr [4801,4828]
atom_expr [4821,4848]
===
match
---
name: log [5327,5330]
name: log [5347,5350]
===
match
---
parameters [1655,1677]
parameters [1683,1705]
===
match
---
name: env [5621,5624]
name: env [5641,5644]
===
match
---
simple_stmt [4667,4673]
simple_stmt [4687,4693]
===
match
---
name: PYTHONPATH_VAR [3269,3283]
name: PYTHONPATH_VAR [3289,3303]
===
match
---
trailer [1768,1770]
trailer [1796,1798]
===
match
---
operator: = [4522,4523]
operator: = [4542,4543]
===
match
---
operator: , [2085,2086]
operator: , [2113,2114]
===
match
---
name: AirflowConfigException [2131,2153]
name: AirflowConfigException [2159,2181]
===
match
---
name: self [4275,4279]
name: self [4295,4299]
===
match
---
operator: = [2824,2825]
operator: = [2844,2845]
===
match
---
operator: = [5810,5811]
operator: = [5830,5831]
===
match
---
operator: != [2454,2456]
operator: != [2482,2484]
===
match
---
expr_stmt [3134,3194]
expr_stmt [3154,3214]
===
match
---
expr_stmt [1259,1288]
expr_stmt [1287,1316]
===
match
---
trailer [6821,6823]
trailer [6841,6843]
===
match
---
simple_stmt [1953,2004]
simple_stmt [1981,2032]
===
match
---
name: Union [4293,4298]
name: Union [4313,4318]
===
match
---
atom_expr [3990,4017]
atom_expr [4010,4037]
===
match
---
operator: = [3769,3770]
operator: = [3789,3790]
===
match
---
name: log [1177,1180]
name: log [1162,1165]
===
match
---
operator: = [2188,2189]
operator: = [2216,2217]
===
match
---
if_stmt [3208,3306]
if_stmt [3228,3326]
===
match
---
string: '-u' [3171,3175]
string: '-u' [3191,3195]
===
match
---
operator: -> [6473,6475]
operator: -> [6493,6495]
===
match
---
name: str [4299,4302]
name: str [4319,4322]
===
match
---
fstring_start: f' [3266,3268]
fstring_start: f' [3286,3288]
===
match
---
name: _cfg_path [6780,6789]
name: _cfg_path [6800,6809]
===
match
---
string: 'sudo' [2937,2943]
string: 'sudo' [2957,2963]
===
match
---
name: bytes [4574,4579]
name: bytes [4594,4599]
===
match
---
name: cfg_path [3639,3647]
name: cfg_path [3659,3667]
===
match
---
trailer [1794,1808]
trailer [1822,1836]
===
match
---
name: run_as_user [2420,2431]
name: run_as_user [2470,2481]
===
match
---
name: threading [860,869]
name: threading [845,854]
===
match
---
atom_expr [4284,4315]
atom_expr [4304,4335]
===
match
---
subscriptlist [4299,4313]
subscriptlist [4319,4333]
===
match
---
expr_stmt [1878,1896]
expr_stmt [1906,1924]
===
match
---
name: self [5261,5265]
name: self [5281,5285]
===
match
---
trailer [2055,2067]
trailer [2083,2095]
===
match
---
name: tmp_configuration_copy [3650,3672]
name: tmp_configuration_copy [3670,3692]
===
match
---
simple_stmt [4685,4879]
simple_stmt [4705,4899]
===
match
---
trailer [6588,6593]
trailer [6608,6613]
===
match
---
string: '\n' [4858,4862]
string: '\n' [4878,4882]
===
match
---
name: _task_instance [3851,3865]
name: _task_instance [3871,3885]
===
match
---
name: task_id [4821,4828]
name: task_id [4841,4848]
===
match
---
number: 0o600 [3679,3684]
number: 0o600 [3699,3704]
===
match
---
trailer [5330,5335]
trailer [5350,5355]
===
match
---
name: log [5266,5269]
name: log [5286,5289]
===
match
---
operator: , [937,938]
operator: , [922,923]
===
match
---
name: _task_instance [1913,1927]
name: _task_instance [1941,1955]
===
match
---
param [4900,4905]
param [4920,4925]
===
match
---
parameters [6466,6472]
parameters [6486,6492]
===
match
---
name: subprocess [5525,5535]
name: subprocess [5545,5555]
===
match
---
if_stmt [4638,4673]
if_stmt [4658,4693]
===
match
---
name: _task_instance [1977,1991]
name: _task_instance [2005,2019]
===
match
---
name: args [5845,5849]
name: args [5865,5869]
===
match
---
trailer [5783,5790]
trailer [5803,5810]
===
match
---
name: delete [3733,3739]
name: delete [3753,3759]
===
match
---
string: 'core' [2079,2085]
string: 'core' [2107,2113]
===
match
---
atom_expr [4427,4443]
atom_expr [4447,4463]
===
match
---
string: """Base task runner""" [787,809]
string: """Base task runner""" [787,809]
===
match
---
except_clause [2124,2153]
except_clause [2152,2181]
===
match
---
expr_stmt [2785,2831]
expr_stmt [2805,2851]
===
match
---
atom_expr [3846,4151]
atom_expr [3866,4171]
===
match
---
name: deserialize_run_error [4253,4274]
name: deserialize_run_error [4273,4294]
===
match
---
string: "Planning to run as the %s user" [2352,2384]
string: "Planning to run as the %s user" [2380,2412]
===
match
---
trailer [3258,3265]
trailer [3278,3285]
===
match
---
name: get_hostname [5298,5310]
name: get_hostname [5318,5330]
===
match
---
operator: = [3148,3149]
operator: = [3168,3169]
===
match
---
name: self [4757,4761]
name: self [4777,4781]
===
match
---
name: isfile [6594,6600]
name: isfile [6614,6620]
===
match
---
trailer [3949,3959]
trailer [3969,3979]
===
match
---
string: 'PYTHONPATH' [1276,1288]
string: 'PYTHONPATH' [1304,1316]
===
match
---
atom_expr [5884,5901]
atom_expr [5904,5921]
===
match
---
trailer [5927,5933]
trailer [5947,5953]
===
match
---
simple_stmt [985,1039]
simple_stmt [970,1024]
===
match
---
trailer [5274,5313]
trailer [5294,5333]
===
match
---
operator: = [5849,5850]
operator: = [5869,5870]
===
match
---
name: Optional [929,937]
name: Optional [914,922]
===
match
---
operator: = [3678,3679]
operator: = [3698,3699]
===
match
---
expr_stmt [4598,4625]
expr_stmt [4618,4645]
===
match
---
funcdef [4884,5956]
funcdef [4904,5976]
===
match
---
suite [6748,6791]
suite [6768,6811]
===
match
---
trailer [2390,2402]
trailer [2418,2430]
===
match
---
name: close_fds [5593,5602]
name: close_fds [5613,5622]
===
match
---
testlist_comp [2937,2980]
testlist_comp [2957,3000]
===
match
---
atom_expr [2386,2402]
atom_expr [2414,2430]
===
match
---
name: typing [915,921]
name: typing [900,906]
===
match
---
name: proc [5951,5955]
name: proc [5971,5975]
===
match
---
string: 'chown' [2945,2952]
string: 'chown' [2965,2972]
===
match
---
operator: = [5524,5525]
operator: = [5544,5545]
===
match
---
arglist [5804,5865]
arglist [5824,5885]
===
match
---
trailer [6115,6120]
trailer [6135,6140]
===
match
---
atom_expr [4757,4783]
atom_expr [4777,4803]
===
match
---
name: _error_file [6804,6815]
name: _error_file [6824,6835]
===
match
---
suite [4650,4673]
suite [4670,4693]
===
match
---
simple_stmt [910,945]
simple_stmt [895,930]
===
match
---
argument [5656,5676]
argument [5676,5696]
===
match
---
name: PYTHONPATH_VAR [3102,3116]
name: PYTHONPATH_VAR [3122,3136]
===
match
---
name: terminate [6335,6344]
name: terminate [6355,6364]
===
match
---
simple_stmt [5182,5208]
simple_stmt [5202,5228]
===
match
---
atom_expr [4224,4236]
atom_expr [4244,4256]
===
match
---
simple_stmt [4517,4542]
simple_stmt [4537,4562]
===
match
---
operator: , [4181,4182]
operator: , [4201,4202]
===
match
---
name: subprocess [842,852]
name: subprocess [827,837]
===
match
---
trailer [5499,5504]
trailer [5519,5524]
===
match
---
name: run_as_user [1992,2003]
name: run_as_user [2020,2031]
===
match
---
atom [3150,3194]
atom [3170,3214]
===
match
---
argument [3733,3744]
argument [3753,3764]
===
match
---
simple_stmt [1039,1095]
simple_stmt [1024,1080]
===
match
---
name: _cfg_path [6572,6581]
name: _cfg_path [6592,6601]
===
match
---
operator: = [3648,3649]
operator: = [3668,3669]
===
match
---
name: stdout [5856,5862]
name: stdout [5876,5882]
===
match
---
simple_stmt [1259,1289]
simple_stmt [1287,1317]
===
match
---
operator: , [3959,3960]
operator: , [3979,3980]
===
match
---
name: local_task_job [4042,4056]
name: local_task_job [4062,4076]
===
match
---
name: full_cmd [5216,5224]
name: full_cmd [5236,5244]
===
match
---
simple_stmt [2051,2112]
simple_stmt [2079,2140]
===
match
---
suite [4921,5956]
suite [4941,5976]
===
match
---
trailer [3097,3101]
trailer [3117,3121]
===
match
---
simple_stmt [3788,4216]
simple_stmt [3808,4236]
===
match
---
trailer [4096,4101]
trailer [4116,4121]
===
match
---
name: pythonpath_value [3211,3227]
name: pythonpath_value [3231,3247]
===
match
---
name: utils [1171,1176]
name: utils [1156,1161]
===
match
---
name: pythonpath_value [3068,3084]
name: pythonpath_value [3088,3104]
===
match
---
name: Optional [6107,6115]
name: Optional [6127,6135]
===
match
---
funcdef [4450,4879]
funcdef [4470,4899]
===
match
---
import_from [1158,1214]
import_from [1143,1199]
===
match
---
atom_expr [5489,5504]
atom_expr [5509,5524]
===
match
---
string: """Return task runtime error if its written to provided error file.""" [4325,4395]
string: """Return task runtime error if its written to provided error file.""" [4345,4415]
===
match
---
name: self [4183,4187]
name: self [4203,4207]
===
match
---
operator: , [4783,4784]
operator: , [4803,4804]
===
match
---
name: configuration [959,972]
name: configuration [944,957]
===
match
---
atom_expr [1840,1868]
atom_expr [1868,1896]
===
match
---
name: airflow [1220,1227]
name: airflow [1205,1212]
===
match
---
simple_stmt [1763,1810]
simple_stmt [1791,1838]
===
match
---
arith_expr [3818,4205]
arith_expr [3838,4225]
===
match
---
operator: = [3739,3740]
operator: = [3759,3760]
===
match
---
atom_expr [5525,5542]
atom_expr [5545,5562]
===
match
---
argument [5621,5642]
argument [5641,5662]
===
match
---
name: daemon [5895,5901]
name: daemon [5915,5921]
===
match
---
trailer [4056,4059]
trailer [4076,4079]
===
match
---
atom [4166,4205]
atom [4186,4225]
===
match
---
operator: = [1838,1839]
operator: = [1866,1867]
===
match
---
name: self [4470,4474]
name: self [4490,4494]
===
match
---
name: run_with [5182,5190]
name: run_with [5202,5210]
===
match
---
param [4275,4279]
param [4295,4299]
===
match
---
import_name [835,852]
import_name [820,837]
===
match
---
expr_stmt [3754,3779]
expr_stmt [3774,3799]
===
match
---
operator: , [4474,4475]
operator: , [4494,4495]
===
match
---
name: self [6467,6471]
name: self [6487,6491]
===
match
---
name: chmod [3673,3678]
name: chmod [3693,3698]
===
match
---
simple_stmt [5322,5361]
simple_stmt [5342,5381]
===
match
---
operator: , [3116,3117]
operator: , [3136,3137]
===
match
---
atom_expr [5238,5251]
atom_expr [5258,5271]
===
match
---
operator: = [5666,5667]
operator: = [5686,5687]
===
match
---
trailer [6605,6615]
trailer [6625,6635]
===
match
---
name: _read_task_logs [4454,4469]
name: _read_task_logs [4474,4489]
===
match
---
name: popen_prepend [1878,1891]
name: popen_prepend [1906,1919]
===
match
---
name: self [6633,6637]
name: self [6653,6657]
===
match
---
while_stmt [4493,4879]
while_stmt [4513,4899]
===
match
---
dotted_name [1044,1071]
dotted_name [1029,1056]
===
match
---
expr_stmt [5761,5875]
expr_stmt [5781,5895]
===
match
---
name: id [4057,4059]
name: id [4077,4079]
===
match
---
trailer [5335,5360]
trailer [5355,5380]
===
match
---
operator: { [3268,3269]
operator: { [3288,3289]
===
match
---
name: target [5804,5810]
name: target [5824,5830]
===
match
---
name: run_as_user [2391,2402]
name: run_as_user [2419,2430]
===
match
---
dotted_name [1220,1237]
dotted_name [1205,1222]
===
match
---
operator: , [3163,3164]
operator: , [3183,3184]
===
match
---
atom_expr [2437,2453]
atom_expr [2443,2459]
===
match
---
name: Popen [5441,5446]
name: Popen [5461,5466]
===
match
---
name: self [2051,2055]
name: self [2079,2083]
===
match
---
operator: = [4127,4128]
operator: = [4147,4148]
===
match
---
name: line [4517,4521]
name: line [4537,4541]
===
match
---
name: self [2415,2419]
name: self [2465,2469]
===
match
---
operator: = [1892,1893]
operator: = [1920,1921]
===
match
---
name: threading [5774,5783]
name: threading [5794,5803]
===
match
---
import_from [1215,1257]
import_from [1200,1242]
===
match
---
suite [6617,6791]
suite [6637,6811]
===
match
---
name: run_as_user [2959,2970]
name: run_as_user [2979,2990]
===
match
---
raise_stmt [6420,6447]
raise_stmt [6440,6467]
===
match
---
trailer [2351,2403]
trailer [2379,2431]
===
match
---
trailer [4698,4878]
trailer [4718,4898]
===
match
---
simple_stmt [3134,3195]
simple_stmt [3154,3215]
===
match
---
param [1662,1676]
param [1690,1704]
===
match
---
name: self [6567,6571]
name: self [6587,6591]
===
match
---
trailer [4292,4315]
trailer [4312,4335]
===
match
---
name: self [1908,1912]
name: self [1936,1940]
===
match
---
atom [5850,5864]
atom [5870,5884]
===
match
---
operator: } [3283,3284]
operator: } [3303,3304]
===
match
---
name: NotImplementedError [6304,6323]
name: NotImplementedError [6324,6343]
===
match
---
name: conf [2070,2074]
name: conf [2098,2102]
===
match
---
atom_expr [2070,2111]
atom_expr [2098,2139]
===
match
---
name: run_with [4906,4914]
name: run_with [4926,4934]
===
match
---
operator: + [4164,4165]
operator: + [4184,4185]
===
match
---
trailer [5635,5640]
trailer [5655,5660]
===
match
---
arglist [4716,4864]
arglist [4736,4884]
===
match
---
trailer [2930,2935]
trailer [2950,2955]
===
match
---
name: conf [980,984]
name: conf [965,969]
===
match
---
name: line [4605,4609]
name: line [4625,4629]
===
match
---
simple_stmt [4930,5174]
simple_stmt [4950,5194]
===
match
---
atom_expr [5298,5312]
atom_expr [5318,5332]
===
match
---
trailer [3732,3745]
trailer [3752,3765]
===
match
---
atom_expr [6667,6730]
atom_expr [6687,6750]
===
match
---
arglist [5336,5359]
arglist [5356,5379]
===
match
---
atom_expr [5917,5935]
atom_expr [5937,5955]
===
match
---
name: full_cmd [5351,5359]
name: full_cmd [5371,5379]
===
match
---
arglist [5460,5677]
arglist [5480,5697]
===
match
---
name: __init__ [1771,1779]
name: __init__ [1799,1807]
===
match
---
string: """         Run the task command.          :param run_with: list of tokens to run the task command with e.g. ``['bash', '-c']``         :type run_with: list         :return: the process that was run         :rtype: subprocess.Popen         """ [4930,5173]
string: """         Run the task command.          :param run_with: list of tokens to run the task command with e.g. ``['bash', '-c']``         :type run_with: list         :return: the process that was run         :rtype: subprocess.Popen         """ [4950,5193]
===
match
---
atom_expr [4183,4204]
atom_expr [4203,4224]
===
match
---
simple_stmt [5216,5252]
simple_stmt [5236,5272]
===
match
---
trailer [1770,1779]
trailer [1798,1807]
===
match
---
arith_expr [5227,5251]
arith_expr [5247,5271]
===
match
---
atom_expr [3177,3193]
atom_expr [3197,3213]
===
match
---
name: os [6586,6588]
name: os [6606,6608]
===
match
---
name: tmp_configuration_copy [1135,1157]
name: tmp_configuration_copy [1120,1142]
===
match
---
name: job_id [4777,4783]
name: job_id [4797,4803]
===
match
---
name: start [5965,5970]
name: start [5985,5990]
===
match
---
operator: = [5428,5429]
operator: = [5448,5449]
===
match
---
name: process [4229,4236]
name: process [4249,4256]
===
match
---
atom_expr [3754,3768]
atom_expr [3774,3788]
===
match
---
operator: = [5602,5603]
operator: = [5622,5623]
===
match
---
trailer [2472,2474]
trailer [2492,2494]
===
match
---
operator: , [6690,6691]
operator: , [6710,6711]
===
match
---
operator: , [5579,5580]
operator: , [5599,5600]
===
match
---
name: _task_instance [4762,4776]
name: _task_instance [4782,4796]
===
match
---
if_stmt [4554,4626]
if_stmt [4574,4646]
===
match
---
trailer [5535,5542]
trailer [5555,5562]
===
match
---
argument [5845,5864]
argument [5865,5884]
===
match
---
name: run_as_user [3182,3193]
name: run_as_user [3202,3213]
===
match
---
atom_expr [3935,3959]
atom_expr [3955,3979]
===
match
---
name: self [2171,2175]
name: self [2199,2203]
===
match
---
trailer [5269,5274]
trailer [5289,5294]
===
match
---
param [6467,6471]
param [6487,6491]
===
match
---
trailer [1976,1991]
trailer [2004,2019]
===
match
---
atom [2436,2475]
atom [2464,2495]
===
match
---
simple_stmt [1331,1638]
simple_stmt [1359,1666]
===
match
---
name: pythonpath_value [3286,3302]
name: pythonpath_value [3306,3322]
===
match
---
name: _command [5243,5251]
name: _command [5263,5271]
===
match
---
name: stream [4524,4530]
name: stream [4544,4550]
===
match
---
operator: , [4828,4829]
operator: , [4848,4849]
===
match
---
name: _error_file [3700,3711]
name: _error_file [3720,3731]
===
match
---
name: os [832,834]
name: os [817,819]
===
match
---
name: utils [1108,1113]
name: utils [1093,1098]
===
match
---
simple_stmt [3245,3306]
simple_stmt [3265,3326]
===
match
---
string: 'rm' [6692,6696]
string: 'rm' [6712,6716]
===
match
---
atom_expr [2337,2403]
atom_expr [2365,2431]
===
match
---
name: os [6765,6767]
name: os [6785,6787]
===
match
---
operator: = [4041,4042]
operator: = [4061,4062]
===
match
---
simple_stmt [4598,4626]
simple_stmt [4618,4646]
===
match
---
atom_expr [3245,3305]
atom_expr [3265,3325]
===
match
---
name: get [3098,3101]
name: get [3118,3121]
===
match
---
name: local_task_job [4082,4096]
name: local_task_job [4102,4116]
===
match
---
trailer [6074,6076]
trailer [6094,6096]
===
match
---
operator: , [5676,5677]
operator: , [5696,5697]
===
match
---
atom_expr [6601,6615]
atom_expr [6621,6635]
===
match
---
argument [6715,6729]
argument [6735,6749]
===
match
---
name: cfg_path [4128,4136]
name: cfg_path [4148,4156]
===
match
---
name: _cfg_path [6606,6615]
name: _cfg_path [6626,6635]
===
match
---
trailer [6682,6730]
trailer [6702,6750]
===
match
---
string: '-H' [3165,3169]
string: '-H' [3185,3189]
===
match
---
string: """Start running the task instance in a subprocess.""" [5986,6040]
string: """Start running the task instance in a subprocess.""" [6006,6060]
===
match
---
trailer [4761,4776]
trailer [4781,4796]
===
match
---
name: Union [939,944]
name: Union [924,929]
===
match
---
atom_expr [4042,4059]
atom_expr [4062,4079]
===
match
---
name: run_as_user [2442,2453]
name: run_as_user [2448,2459]
===
match
---
name: Optional [4284,4292]
name: Optional [4304,4312]
===
match
---
trailer [6637,6649]
trailer [6657,6669]
===
match
---
trailer [5440,5446]
trailer [5460,5466]
===
match
---
trailer [6600,6616]
trailer [6620,6636]
===
match
---
arglist [2079,2110]
arglist [2107,2138]
===
match
---
atom_expr [1908,1939]
atom_expr [1936,1967]
===
match
---
trailer [6767,6774]
trailer [6787,6794]
===
match
---
name: exceptions [998,1008]
name: exceptions [983,993]
===
match
---
param [6098,6102]
param [6118,6122]
===
match
---
name: self [6098,6102]
name: self [6118,6122]
===
match
---
classdef [1291,6824]
classdef [1319,6844]
===
match
---
trailer [5815,5831]
trailer [5835,5851]
===
match
---
simple_stmt [6130,6290]
simple_stmt [6150,6310]
===
match
---
operator: , [2970,2971]
operator: , [2990,2991]
===
match
---
argument [2819,2830]
argument [2839,2850]
===
match
---
operator: } [3302,3303]
operator: } [3322,3323]
===
match
---
atom_expr [4411,4444]
atom_expr [4431,4464]
===
match
---
trailer [2341,2345]
trailer [2369,2373]
===
match
---
operator: , [2952,2953]
operator: , [2972,2973]
===
match
---
name: self [2437,2441]
name: self [2443,2447]
===
match
---
atom_expr [6055,6076]
atom_expr [6075,6096]
===
insert-tree
---
simple_stmt [1243,1286]
    import_from [1243,1285]
        dotted_name [1248,1270]
            name: airflow [1248,1255]
            name: utils [1256,1261]
            name: platform [1262,1270]
        name: getuser [1278,1285]
to
file_input [787,6824]
at 13
===
move-tree
---
atom_expr [2437,2453]
    name: self [2437,2441]
    trailer [2441,2453]
        name: run_as_user [2442,2453]
to
and_test [2415,2475]
at 0
===
move-tree
---
atom_expr [2415,2431]
    name: self [2415,2419]
    trailer [2419,2431]
        name: run_as_user [2420,2431]
to
comparison [2437,2474]
at 0
===
move-tree
---
name: getuser [2465,2472]
to
atom_expr [2457,2474]
at 0
===
delete-tree
---
simple_stmt [810,825]
    import_name [810,824]
        name: getpass [817,824]
===
delete-node
---
name: getpass [2457,2464]
===
===
delete-node
---
trailer [2464,2472]
===
