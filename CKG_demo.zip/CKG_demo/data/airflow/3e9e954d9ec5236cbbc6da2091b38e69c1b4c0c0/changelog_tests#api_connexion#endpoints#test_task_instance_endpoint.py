===
match
---
argument [10445,10451]
argument [10449,10455]
===
match
---
name: response [16012,16020]
name: response [16016,16024]
===
match
---
string: "task_id" [8702,8711]
string: "task_id" [8714,8723]
===
match
---
trailer [6389,6401]
trailer [6409,6421]
===
match
---
name: self [2815,2819]
name: self [2843,2847]
===
match
---
string: "task_id" [40155,40164]
string: "task_id" [40159,40168]
===
match
---
atom [24505,24557]
atom [24509,24561]
===
match
---
atom [24504,24590]
atom [24508,24594]
===
match
---
name: RUNNING [32929,32936]
name: RUNNING [32933,32940]
===
match
---
operator: = [2341,2342]
operator: = [2369,2370]
===
match
---
operator: , [19042,19043]
operator: , [19046,19047]
===
match
---
trailer [29023,29031]
trailer [29027,29035]
===
match
---
arith_expr [18937,18978]
arith_expr [18941,18982]
===
match
---
simple_stmt [20997,21176]
simple_stmt [21001,21180]
===
match
---
fstring_string: /clearTaskInstances [31877,31896]
fstring_string: /clearTaskInstances [31881,31900]
===
match
---
name: payload [21157,21164]
name: payload [21161,21168]
===
match
---
suite [39902,40512]
suite [39906,40516]
===
match
---
testlist_comp [22701,22837]
testlist_comp [22705,22841]
===
match
---
atom_expr [7635,7824]
atom_expr [7647,7836]
===
match
---
arglist [43046,43191]
arglist [43050,43195]
===
match
---
name: ACTION_CAN_EDIT [1955,1970]
name: ACTION_CAN_EDIT [1983,1998]
===
match
---
operator: = [38949,38950]
operator: = [38953,38954]
===
match
---
operator: , [34825,34826]
operator: , [34829,34830]
===
match
---
operator: + [26528,26529]
operator: + [26532,26533]
===
match
---
number: 2 [25726,25727]
number: 2 [25730,25731]
===
match
---
name: expected [24801,24809]
name: expected [24805,24813]
===
match
---
operator: { [38080,38081]
operator: { [38084,38085]
===
match
---
dictorsetmaker [24606,24656]
dictorsetmaker [24610,24660]
===
match
---
operator: + [32728,32729]
operator: + [32732,32733]
===
match
---
expr_stmt [37902,38444]
expr_stmt [37906,38448]
===
match
---
assert_stmt [15897,15931]
assert_stmt [15901,15935]
===
match
---
operator: , [21811,21812]
operator: , [21815,21816]
===
match
---
operator: , [24171,24172]
operator: , [24175,24176]
===
match
---
operator: { [17084,17085]
operator: { [17088,17089]
===
match
---
operator: = [29818,29819]
operator: = [29822,29823]
===
match
---
suite [35004,35073]
suite [35008,35077]
===
match
---
operator: = [7366,7367]
operator: = [7378,7379]
===
match
---
trailer [38511,38516]
trailer [38515,38520]
===
match
---
operator: } [31327,31328]
operator: } [31331,31332]
===
match
---
name: dags [38875,38879]
name: dags [38879,38883]
===
match
---
name: airflow [909,916]
name: airflow [894,901]
===
match
---
operator: = [3245,3246]
operator: = [3273,3274]
===
match
---
atom [36424,36506]
atom [36428,36510]
===
match
---
string: "execution_date" [36770,36786]
string: "execution_date" [36774,36790]
===
match
---
trailer [7613,7615]
trailer [7625,7627]
===
match
---
atom_expr [2849,2860]
atom_expr [2877,2888]
===
match
---
funcdef [40517,41146]
funcdef [40521,41150]
===
match
---
trailer [21012,21019]
trailer [21016,21023]
===
match
---
operator: = [33477,33478]
operator: = [33481,33482]
===
match
---
operator: } [18664,18665]
operator: } [18668,18669]
===
match
---
operator: = [27366,27367]
operator: = [27370,27371]
===
match
---
name: client [35668,35674]
name: client [35672,35678]
===
match
---
operator: { [12484,12485]
operator: { [12488,12489]
===
match
---
name: create_task_instances [15668,15689]
name: create_task_instances [15672,15693]
===
match
---
dictorsetmaker [28034,28142]
dictorsetmaker [28038,28146]
===
match
---
suite [40563,41146]
suite [40567,41150]
===
match
---
simple_stmt [23707,23728]
simple_stmt [23711,23732]
===
match
---
name: DagRun [33594,33600]
name: DagRun [33598,33604]
===
match
---
name: session [15645,15652]
name: session [15649,15656]
===
match
---
name: session [16206,16213]
name: session [16210,16217]
===
match
---
expr_stmt [16751,16864]
expr_stmt [16755,16868]
===
match
---
operator: + [36807,36808]
operator: + [36811,36812]
===
match
---
name: DEFAULT_DATETIME_1 [26509,26527]
name: DEFAULT_DATETIME_1 [26513,26531]
===
match
---
name: DEFAULT_DATETIME_1 [29957,29975]
name: DEFAULT_DATETIME_1 [29961,29979]
===
match
---
number: 0 [8964,8965]
number: 0 [8976,8977]
===
match
---
testlist_comp [24505,24589]
testlist_comp [24509,24593]
===
match
---
number: 404 [41784,41787]
number: 404 [41788,41791]
===
match
---
operator: { [7901,7902]
operator: { [7913,7914]
===
match
---
string: "state" [18091,18098]
string: "state" [18095,18102]
===
match
---
trailer [37143,37154]
trailer [37147,37158]
===
match
---
name: key [3971,3974]
name: key [3999,4002]
===
match
---
atom [13388,13834]
atom [13392,13838]
===
match
---
operator: , [18665,18666]
operator: , [18669,18670]
===
match
---
trailer [29990,29998]
trailer [29994,30002]
===
match
---
argument [33316,33342]
argument [33320,33346]
===
match
---
string: "execution_date" [9906,9922]
string: "execution_date" [9910,9926]
===
match
---
atom_expr [29066,29078]
atom_expr [29070,29082]
===
match
---
number: 200 [18661,18664]
number: 200 [18665,18668]
===
match
---
operator: } [12133,12134]
operator: } [12137,12138]
===
match
---
simple_stmt [2146,2196]
simple_stmt [2174,2224]
===
match
---
fstring_start: f" [11297,11299]
fstring_start: f" [11301,11303]
===
match
---
argument [33515,33527]
argument [33519,33531]
===
match
---
string: "test" [40712,40718]
string: "test" [40716,40722]
===
match
---
expr_stmt [7624,7824]
expr_stmt [7636,7836]
===
match
---
operator: @ [17242,17243]
operator: @ [17246,17247]
===
match
---
name: url [15841,15844]
name: url [15845,15848]
===
match
---
operator: , [21830,21831]
operator: , [21834,21835]
===
match
---
name: response [9247,9255]
name: response [9251,9259]
===
match
---
name: expand [22653,22659]
name: expand [22657,22663]
===
match
---
number: 2 [15123,15124]
number: 2 [15127,15128]
===
match
---
name: RUNNING [36730,36737]
name: RUNNING [36734,36741]
===
match
---
operator: ** [3938,3940]
operator: ** [3966,3968]
===
match
---
expr_stmt [23784,24030]
expr_stmt [23788,24034]
===
match
---
atom_expr [28889,28901]
atom_expr [28893,28905]
===
match
---
operator: , [42941,42942]
operator: , [42945,42946]
===
match
---
operator: , [29436,29437]
operator: , [29440,29441]
===
match
---
argument [10524,10530]
argument [10528,10534]
===
match
---
assert_stmt [16635,16687]
assert_stmt [16639,16691]
===
match
---
dictorsetmaker [13970,13991]
dictorsetmaker [13974,13995]
===
match
---
string: "PythonOperator" [8214,8230]
string: "PythonOperator" [8226,8242]
===
match
---
operator: = [4520,4521]
operator: = [4548,4549]
===
match
---
operator: == [22471,22473]
operator: == [22475,22477]
===
match
---
string: "default_pool" [8276,8290]
string: "default_pool" [8288,8302]
===
match
---
name: State [32777,32782]
name: State [32781,32786]
===
match
---
string: "test" [38054,38060]
string: "test" [38058,38064]
===
match
---
operator: , [36226,36227]
operator: , [36230,36231]
===
match
---
string: "state" [26244,26251]
string: "state" [26248,26255]
===
match
---
simple_stmt [4025,4049]
simple_stmt [4053,4077]
===
match
---
atom [18525,18542]
atom [18529,18546]
===
match
---
operator: { [7790,7791]
operator: { [7802,7803]
===
match
---
atom [27284,27439]
atom [27288,27443]
===
match
---
string: "start_date" [21952,21964]
string: "start_date" [21956,21968]
===
match
---
string: "test_queue_3" [15336,15350]
string: "test_queue_3" [15340,15354]
===
match
---
name: self [31535,31539]
name: self [31539,31543]
===
match
---
string: "sleep_for_1" [29274,29287]
string: "sleep_for_1" [29278,29291]
===
match
---
string: "execution_date" [20023,20039]
string: "execution_date" [20027,20043]
===
match
---
arglist [23563,23688]
arglist [23567,23692]
===
match
---
operator: , [30900,30901]
operator: , [30904,30905]
===
match
---
argument [41325,41366]
argument [41329,41370]
===
match
---
operator: } [10373,10374]
operator: } [10377,10378]
===
match
---
operator: , [9516,9517]
operator: , [9520,9521]
===
match
---
trailer [28846,28854]
trailer [28850,28858]
===
match
---
string: "2020-01-02T00:00:00+00:00" [1457,1484]
string: "2020-01-02T00:00:00+00:00" [1485,1512]
===
match
---
param [3298,3318]
param [3326,3346]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [23153,23198]
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [23157,23202]
===
match
---
operator: , [14458,14459]
operator: , [14462,14463]
===
match
---
operator: = [6174,6175]
operator: = [6194,6195]
===
match
---
operator: { [34721,34722]
operator: { [34725,34726]
===
match
---
atom_expr [40484,40504]
atom_expr [40488,40508]
===
match
---
dictorsetmaker [33479,33500]
dictorsetmaker [33483,33504]
===
match
---
dictorsetmaker [19082,19181]
dictorsetmaker [19086,19185]
===
match
---
name: dag [38852,38855]
name: dag [38856,38859]
===
match
---
name: self [2849,2853]
name: self [2877,2881]
===
match
---
operator: } [29536,29537]
operator: } [29540,29541]
===
match
---
name: create_task_instances [24834,24855]
name: create_task_instances [24838,24859]
===
match
---
arglist [9353,9517]
arglist [9357,9521]
===
match
---
trailer [4745,4749]
trailer [4773,4777]
===
match
---
testlist_comp [1721,2008]
testlist_comp [1749,2036]
===
match
---
name: State [33330,33335]
name: State [33334,33339]
===
match
---
trailer [27956,27963]
trailer [27960,27967]
===
match
---
argument [19992,19998]
argument [19996,20002]
===
match
---
operator: , [29513,29514]
operator: , [29517,29518]
===
match
---
trailer [15829,15836]
trailer [15833,15840]
===
match
---
atom [36150,36226]
atom [36154,36230]
===
match
---
atom [29559,29714]
atom [29563,29718]
===
match
---
operator: , [13226,13227]
operator: , [13230,13231]
===
match
---
operator: , [8790,8791]
operator: , [8802,8803]
===
match
---
string: 'task_id' [34668,34677]
string: 'task_id' [34672,34681]
===
match
---
dictorsetmaker [29762,29869]
dictorsetmaker [29766,29873]
===
match
---
expr_stmt [31808,31989]
expr_stmt [31812,31993]
===
match
---
name: single_dag_run [22207,22221]
name: single_dag_run [22211,22225]
===
match
---
trailer [25123,25133]
trailer [25127,25137]
===
match
---
operator: , [12750,12751]
operator: , [12754,12755]
===
match
---
name: State [36856,36861]
name: State [36860,36865]
===
match
---
operator: = [36826,36827]
operator: = [36830,36831]
===
match
---
operator: } [9799,9800]
operator: } [9803,9804]
===
match
---
name: sla_miss [7357,7365]
name: sla_miss [7369,7377]
===
match
---
name: RUNNING [18106,18113]
name: RUNNING [18110,18117]
===
match
---
operator: { [40047,40048]
operator: { [40051,40052]
===
match
---
name: DEFAULT_DATETIME_1 [10963,10981]
name: DEFAULT_DATETIME_1 [10967,10985]
===
match
---
dictorsetmaker [29477,29536]
dictorsetmaker [29481,29540]
===
match
---
name: client [39927,39933]
name: client [39931,39937]
===
match
---
name: state [39196,39201]
name: state [39200,39205]
===
match
---
dictorsetmaker [24220,24264]
dictorsetmaker [24224,24268]
===
match
---
name: response [37400,37408]
name: response [37404,37412]
===
match
---
name: days [11689,11693]
name: days [11693,11697]
===
match
---
name: days [30716,30720]
name: days [30720,30724]
===
match
---
operator: = [15863,15864]
operator: = [15867,15868]
===
match
---
atom_expr [4429,4444]
atom_expr [4457,4472]
===
match
---
atom [27831,27986]
atom [27835,27990]
===
match
---
operator: = [35348,35349]
operator: = [35352,35353]
===
match
---
name: len [3531,3534]
name: len [3559,3562]
===
match
---
dictorsetmaker [36426,36459]
dictorsetmaker [36430,36463]
===
match
---
string: "2020-01-01T00:00:00+00:00" [5373,5400]
string: "2020-01-01T00:00:00+00:00" [5401,5428]
===
match
---
operator: = [3529,3530]
operator: = [3557,3558]
===
match
---
trailer [9246,9256]
trailer [9250,9260]
===
match
---
operator: { [25383,25384]
operator: { [25387,25388]
===
match
---
suite [9304,9571]
suite [9308,9575]
===
match
---
name: session [42943,42950]
name: session [42947,42954]
===
match
---
operator: = [38856,38857]
operator: = [38860,38861]
===
match
---
dictorsetmaker [23628,23686]
dictorsetmaker [23632,23690]
===
match
---
number: 15 [22814,22816]
number: 15 [22818,22820]
===
match
---
operator: } [40084,40085]
operator: } [40088,40089]
===
match
---
operator: { [11929,11930]
operator: { [11933,11934]
===
match
---
operator: { [15232,15233]
operator: { [15236,15237]
===
match
---
atom [17342,17502]
atom [17346,17506]
===
match
---
trailer [4068,4072]
trailer [4096,4100]
===
match
---
operator: = [7789,7790]
operator: = [7801,7802]
===
match
---
name: self [3940,3944]
name: self [3968,3972]
===
match
---
expr_stmt [24873,25051]
expr_stmt [24877,25055]
===
match
---
atom [33749,34956]
atom [33753,34960]
===
match
---
name: status_code [37409,37420]
name: status_code [37413,37424]
===
match
---
atom_expr [1943,1970]
atom_expr [1971,1998]
===
match
---
string: "execution_date_lte" [24606,24626]
string: "execution_date_lte" [24610,24630]
===
match
---
operator: { [2385,2386]
operator: { [2413,2414]
===
match
---
parameters [22937,22987]
parameters [22941,22991]
===
match
---
operator: , [19917,19918]
operator: , [19921,19922]
===
match
---
decorator [36528,36545]
decorator [36532,36549]
===
match
---
argument [1669,1685]
argument [1697,1713]
===
match
---
name: key [4037,4040]
name: key [4065,4068]
===
match
---
operator: = [7396,7397]
operator: = [7408,7409]
===
match
---
trailer [22487,22492]
trailer [22491,22496]
===
match
---
operator: = [20962,20963]
operator: = [20966,20967]
===
match
---
name: single_dag_run [21832,21846]
name: single_dag_run [21836,21850]
===
match
---
operator: , [33978,33979]
operator: , [33982,33983]
===
match
---
dictorsetmaker [39479,39800]
dictorsetmaker [39483,39804]
===
match
---
atom [11489,11716]
atom [11493,11720]
===
match
---
operator: , [27665,27666]
operator: , [27669,27670]
===
match
---
name: self [16736,16740]
name: self [16740,16744]
===
match
---
operator: , [11383,11384]
operator: , [11387,11388]
===
match
---
string: "execution_date" [27310,27326]
string: "execution_date" [27314,27330]
===
match
---
operator: , [15516,15517]
operator: , [15520,15521]
===
match
---
name: status_code [36081,36092]
name: status_code [36085,36096]
===
match
---
operator: = [41216,41217]
operator: = [41220,41221]
===
match
---
param [21813,21815]
param [21817,21819]
===
match
---
dictorsetmaker [5220,5963]
dictorsetmaker [5248,5983]
===
match
---
funcdef [39860,40512]
funcdef [39864,40516]
===
match
---
assert_stmt [17142,17176]
assert_stmt [17146,17180]
===
match
---
string: 'example_python_operator' [34749,34774]
string: 'example_python_operator' [34753,34778]
===
match
---
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [39379,39442]
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [39383,39446]
===
match
---
name: i [4228,4229]
name: i [4256,4257]
===
match
---
operator: = [32893,32894]
operator: = [32897,32898]
===
match
---
atom_expr [26530,26550]
atom_expr [26534,26554]
===
match
---
trailer [3999,4005]
trailer [4027,4033]
===
match
---
string: "test" [16400,16406]
string: "test" [16404,16410]
===
match
---
comparison [25067,25094]
comparison [25071,25098]
===
match
---
name: response [31808,31816]
name: response [31812,31820]
===
match
---
operator: = [33329,33330]
operator: = [33333,33334]
===
match
---
operator: , [36045,36046]
operator: , [36049,36050]
===
match
---
operator: , [38061,38062]
operator: , [38065,38066]
===
match
---
string: "include_future" [42616,42632]
string: "include_future" [42620,42636]
===
match
---
operator: { [18623,18624]
operator: { [18627,18628]
===
match
---
arith_expr [27150,27191]
arith_expr [27154,27195]
===
match
---
operator: , [13072,13073]
operator: , [13076,13077]
===
match
---
number: 0 [6727,6728]
number: 0 [6747,6748]
===
match
---
name: run_type [4637,4645]
name: run_type [4665,4673]
===
match
---
string: "dry_run" [42372,42381]
string: "dry_run" [42376,42385]
===
match
---
name: assert_401 [9236,9246]
name: assert_401 [9240,9250]
===
match
---
string: 'dag_run_id' [34078,34090]
string: 'dag_run_id' [34082,34094]
===
match
---
argument [35344,35555]
argument [35348,35559]
===
match
---
argument [4687,4706]
argument [4715,4734]
===
match
---
comparison [43217,43244]
comparison [43221,43248]
===
match
---
trailer [41768,41780]
trailer [41772,41784]
===
match
---
argument [32597,32603]
argument [32601,32607]
===
match
---
string: "task_id" [7095,7104]
string: "task_id" [7115,7124]
===
match
---
string: "include_future" [41619,41635]
string: "include_future" [41623,41639]
===
match
---
atom [42350,42742]
atom [42354,42746]
===
match
---
name: task_instances [31625,31639]
name: task_instances [31629,31643]
===
match
---
name: _ [21813,21814]
name: _ [21817,21818]
===
match
---
argument [35764,35820]
argument [35768,35824]
===
match
---
name: configured_app [2826,2840]
name: configured_app [2854,2868]
===
match
---
operator: , [26939,26940]
operator: , [26943,26944]
===
match
---
operator: , [30947,30948]
operator: , [30951,30952]
===
match
---
trailer [2494,2504]
trailer [2522,2532]
===
match
---
operator: } [18824,18825]
operator: } [18828,18829]
===
match
---
string: "pool_slots" [5609,5621]
string: "pool_slots" [5637,5649]
===
match
---
number: 1 [19439,19440]
number: 1 [19443,19444]
===
match
---
atom_expr [4602,4619]
atom_expr [4630,4647]
===
match
---
expr_stmt [1564,1589]
expr_stmt [1592,1617]
===
match
---
name: ti_init [3945,3952]
name: ti_init [3973,3980]
===
match
---
operator: { [32527,32528]
operator: { [32531,32532]
===
match
---
name: test_should_respond_200_task_instance_with_sla [7218,7264]
name: test_should_respond_200_task_instance_with_sla [7230,7276]
===
match
---
atom_expr [7289,7324]
atom_expr [7301,7336]
===
match
---
number: 2 [12285,12286]
number: 2 [12289,12290]
===
match
---
trailer [31835,31989]
trailer [31839,31993]
===
match
---
classdef [17179,25146]
classdef [17183,25150]
===
match
---
decorator [9631,15534]
decorator [9635,15538]
===
match
---
operator: , [33097,33098]
operator: , [33101,33102]
===
match
---
operator: { [19385,19386]
operator: { [19389,19390]
===
match
---
atom_expr [30703,30723]
atom_expr [30707,30727]
===
match
---
name: dt [2555,2557]
name: dt [2583,2585]
===
match
---
atom [40104,40457]
atom [40108,40461]
===
match
---
operator: } [41090,41091]
operator: } [41094,41095]
===
match
---
string: "task_instances" [16026,16042]
string: "task_instances" [16030,16046]
===
match
---
number: 2 [26871,26872]
number: 2 [26875,26876]
===
match
---
operator: , [35540,35541]
operator: , [35544,35545]
===
match
---
trailer [4606,4619]
trailer [4634,4647]
===
match
---
comparison [3553,3579]
comparison [3581,3607]
===
match
---
atom_expr [23416,23446]
atom_expr [23420,23450]
===
match
---
string: 'dag_run_id' [34316,34328]
string: 'dag_run_id' [34320,34332]
===
match
---
atom_expr [2555,2575]
atom_expr [2583,2603]
===
match
---
operator: , [13884,13885]
operator: , [13888,13889]
===
match
---
name: SlaMiss [947,954]
name: SlaMiss [932,939]
===
match
---
name: json [40733,40737]
name: json [40737,40741]
===
match
---
string: "/api/v1/dags/example_python_operator/clearTaskInstances" [35693,35750]
string: "/api/v1/dags/example_python_operator/clearTaskInstances" [35697,35754]
===
match
---
argument [21152,21164]
argument [21156,21168]
===
match
---
operator: { [22374,22375]
operator: { [22378,22379]
===
match
---
arith_expr [12169,12210]
arith_expr [12173,12214]
===
match
---
string: "running" [8883,8892]
string: "running" [8895,8904]
===
match
---
string: 'dag_id' [33781,33789]
string: 'dag_id' [33785,33793]
===
match
---
operator: , [18503,18504]
operator: , [18507,18508]
===
match
---
trailer [10444,10452]
trailer [10448,10456]
===
match
---
name: days [25721,25725]
name: days [25725,25729]
===
match
---
name: response [41118,41126]
name: response [41122,41130]
===
match
---
arglist [23068,23102]
arglist [23072,23106]
===
match
---
name: status_code [17158,17169]
name: status_code [17162,17173]
===
match
---
expr_stmt [32420,33108]
expr_stmt [32424,33112]
===
match
---
arglist [3607,3635]
arglist [3635,3663]
===
match
---
operator: = [15779,15780]
operator: = [15783,15784]
===
match
---
operator: } [34230,34231]
operator: } [34234,34235]
===
match
---
operator: { [43141,43142]
operator: { [43145,43146]
===
match
---
number: 2 [17625,17626]
number: 2 [17629,17630]
===
match
---
fstring_string: taskInstances?execution_date_lte= [10134,10167]
fstring_string: taskInstances?execution_date_lte= [10138,10171]
===
match
---
operator: { [24125,24126]
operator: { [24129,24130]
===
match
---
operator: , [1618,1619]
operator: , [1646,1647]
===
match
---
operator: , [5814,5815]
operator: , [5842,5843]
===
match
---
operator: , [27785,27786]
operator: , [27789,27790]
===
match
---
arglist [36944,37108]
arglist [36948,37112]
===
match
---
tfpdef [3261,3281]
tfpdef [3289,3309]
===
match
---
name: upstream [39250,39258]
name: upstream [39254,39262]
===
match
---
argument [23077,23102]
argument [23081,23106]
===
match
---
dictorsetmaker [30841,30948]
dictorsetmaker [30845,30952]
===
match
---
operator: , [1891,1892]
operator: , [1919,1920]
===
match
---
atom_expr [4139,4412]
atom_expr [4167,4440]
===
match
---
trailer [21349,21354]
trailer [21353,21358]
===
match
---
operator: , [31328,31329]
operator: , [31332,31333]
===
match
---
strings [14956,15087]
strings [14960,15091]
===
match
---
name: State [29524,29529]
name: State [29528,29533]
===
match
---
string: "test_pool_2" [17950,17963]
string: "test_pool_2" [17954,17967]
===
match
---
operator: { [38038,38039]
operator: { [38042,38043]
===
match
---
expr_stmt [9083,9227]
expr_stmt [9087,9231]
===
match
---
param [3176,3216]
param [3204,3244]
===
match
---
decorator [31384,31401]
decorator [31388,31405]
===
match
---
number: 5 [35088,35089]
number: 5 [35092,35093]
===
match
---
name: DEFAULT_DATETIME_STR_2 [19704,19726]
name: DEFAULT_DATETIME_STR_2 [19708,19730]
===
match
---
name: State [30603,30608]
name: State [30607,30612]
===
match
---
string: "example_python_operator" [29138,29163]
string: "example_python_operator" [29142,29167]
===
match
---
trailer [31059,31069]
trailer [31063,31073]
===
match
---
string: "task_instances" [23367,23383]
string: "task_instances" [23371,23387]
===
match
---
comparison [32048,32099]
comparison [32052,32103]
===
match
---
operator: , [39159,39160]
operator: , [39163,39164]
===
match
---
simple_stmt [40572,41103]
simple_stmt [40576,41107]
===
match
---
operator: , [22718,22719]
operator: , [22722,22723]
===
match
---
name: DEFAULT_DATETIME_1 [30682,30700]
name: DEFAULT_DATETIME_1 [30686,30704]
===
match
---
name: environ_overrides [31911,31928]
name: environ_overrides [31915,31932]
===
match
---
trailer [42965,42987]
trailer [42969,42991]
===
match
---
operator: = [4267,4268]
operator: = [4295,4296]
===
match
---
name: create_task_instances [23002,23023]
name: create_task_instances [23006,23027]
===
match
---
name: State [13566,13571]
name: State [13570,13575]
===
match
---
trailer [29980,29990]
trailer [29984,29994]
===
match
---
name: State [28712,28717]
name: State [28716,28721]
===
match
---
argument [39046,39058]
argument [39050,39062]
===
match
---
trailer [37131,37135]
trailer [37135,37139]
===
match
---
atom [29476,29537]
atom [29480,29541]
===
match
---
operator: , [26982,26983]
operator: , [26986,26987]
===
match
---
argument [1503,1517]
argument [1531,1545]
===
match
---
name: provide_session [21711,21726]
name: provide_session [21715,21730]
===
match
---
operator: { [4227,4228]
operator: { [4255,4256]
===
match
---
trailer [3041,3048]
trailer [3069,3076]
===
match
---
operator: } [11914,11915]
operator: } [11918,11919]
===
match
---
string: "example_skip_dag" [23084,23102]
string: "example_skip_dag" [23088,23106]
===
match
---
trailer [20230,20240]
trailer [20234,20244]
===
match
---
trailer [37811,37825]
trailer [37815,37829]
===
match
---
trailer [2327,2340]
trailer [2355,2368]
===
match
---
name: clear_db_sla_miss [1318,1335]
name: clear_db_sla_miss [1346,1363]
===
match
---
operator: = [39052,39053]
operator: = [39056,39057]
===
match
---
trailer [11611,11619]
trailer [11615,11623]
===
match
---
operator: } [29306,29307]
operator: } [29310,29311]
===
match
---
simple_stmt [35017,35073]
simple_stmt [35021,35077]
===
match
---
name: post [35675,35679]
name: post [35679,35683]
===
match
---
operator: { [35782,35783]
operator: { [35786,35787]
===
match
---
name: FAILED [25592,25598]
name: FAILED [25596,25602]
===
match
---
operator: = [11616,11617]
operator: = [11620,11621]
===
match
---
name: DEFAULT_DATETIME_1 [20041,20059]
name: DEFAULT_DATETIME_1 [20045,20063]
===
match
---
operator: , [18643,18644]
operator: , [18647,18648]
===
match
---
arglist [33158,33343]
arglist [33162,33347]
===
match
---
name: self [33118,33122]
name: self [33122,33126]
===
match
---
name: self [7532,7536]
name: self [7544,7548]
===
match
---
operator: { [17821,17822]
operator: { [17825,17826]
===
match
---
dictorsetmaker [24506,24556]
dictorsetmaker [24510,24560]
===
match
---
atom_expr [32052,32083]
atom_expr [32056,32087]
===
match
---
name: delete_user [2146,2157]
name: delete_user [2174,2185]
===
match
---
expr_stmt [7357,7560]
expr_stmt [7369,7572]
===
match
---
name: airflow [1147,1154]
name: airflow [1175,1182]
===
match
---
arglist [22297,22424]
arglist [22301,22428]
===
match
---
fstring_string: = [11299,11300]
fstring_string: = [11303,11304]
===
match
---
string: "example_subdag_operator.section-1" [30480,30515]
string: "example_subdag_operator.section-1" [30484,30519]
===
match
---
operator: , [20759,20760]
operator: , [20763,20764]
===
match
---
trailer [36908,36930]
trailer [36912,36934]
===
match
---
operator: = [7531,7532]
operator: = [7543,7544]
===
match
---
decorator [37547,37627]
decorator [37551,37631]
===
match
---
string: "include_future" [39700,39716]
string: "include_future" [39704,39720]
===
match
---
atom_expr [16435,16455]
atom_expr [16439,16459]
===
match
---
atom [7901,9019]
atom [7913,9023]
===
match
---
assert_stmt [22501,22559]
assert_stmt [22505,22563]
===
match
---
atom_expr [30033,30045]
atom_expr [30037,30049]
===
match
---
operator: , [27059,27060]
operator: , [27063,27064]
===
match
---
dictorsetmaker [32243,32401]
dictorsetmaker [32247,32405]
===
match
---
operator: } [11952,11953]
operator: } [11956,11957]
===
match
---
operator: , [31978,31979]
operator: , [31982,31983]
===
match
---
simple_stmt [3037,3105]
simple_stmt [3065,3133]
===
match
---
name: tasks [39224,39229]
name: tasks [39228,39233]
===
match
---
dotted_as_name [792,806]
dotted_as_name [792,806]
===
match
---
operator: = [33296,33297]
operator: = [33300,33301]
===
match
---
param [40557,40561]
param [40561,40565]
===
match
---
operator: , [27963,27964]
operator: , [27967,27968]
===
match
---
string: "execution_date" [30556,30572]
string: "execution_date" [30560,30576]
===
match
---
operator: , [22423,22424]
operator: , [22427,22428]
===
match
---
suite [17237,25146]
suite [17241,25150]
===
match
---
name: self [6176,6180]
name: self [6196,6200]
===
match
---
trailer [23544,23549]
trailer [23548,23553]
===
match
---
argument [4320,4352]
argument [4348,4380]
===
match
---
dictorsetmaker [26722,26835]
dictorsetmaker [26726,26839]
===
match
---
name: task_id [7389,7396]
name: task_id [7401,7408]
===
match
---
string: "{'start_date': ['Not a valid datetime.']}" [36462,36505]
string: "{'start_date': ['Not a valid datetime.']}" [36466,36509]
===
match
---
name: expand [36120,36126]
name: expand [36124,36130]
===
match
---
atom [14096,14264]
atom [14100,14268]
===
match
---
number: 10000 [2691,2696]
number: 10000 [2719,2724]
===
match
---
atom_expr [29624,29644]
atom_expr [29628,29648]
===
match
---
string: "start_date" [25937,25949]
string: "start_date" [25941,25953]
===
match
---
name: DEFAULT_DATETIME_1 [18860,18878]
name: DEFAULT_DATETIME_1 [18864,18882]
===
match
---
operator: , [26737,26738]
operator: , [26741,26742]
===
match
---
string: "execution_date" [6590,6606]
string: "execution_date" [6610,6626]
===
match
---
trailer [28659,28669]
trailer [28663,28673]
===
match
---
atom [24110,24701]
atom [24114,24705]
===
match
---
tfpdef [3225,3244]
tfpdef [3253,3272]
===
match
---
operator: , [28924,28925]
operator: , [28928,28929]
===
match
---
operator: { [6331,6332]
operator: { [6351,6352]
===
match
---
operator: { [26205,26206]
operator: { [26209,26210]
===
match
---
expr_stmt [39338,39825]
expr_stmt [39342,39829]
===
match
---
operator: = [20162,20163]
operator: = [20166,20167]
===
match
---
atom [21115,21138]
atom [21119,21142]
===
match
---
operator: = [30897,30898]
operator: = [30901,30902]
===
match
---
operator: , [9985,9986]
operator: , [9989,9990]
===
match
---
dictorsetmaker [38098,38419]
dictorsetmaker [38102,38423]
===
match
---
name: DEFAULT_DATETIME_STR_1 [10168,10190]
name: DEFAULT_DATETIME_STR_1 [10172,10194]
===
match
---
dictorsetmaker [14851,14874]
dictorsetmaker [14855,14878]
===
match
---
trailer [32065,32083]
trailer [32069,32087]
===
match
---
name: client [16966,16972]
name: client [16970,16976]
===
match
---
trailer [28669,28677]
trailer [28673,28681]
===
match
---
string: "test" [31945,31951]
string: "test" [31949,31955]
===
match
---
operator: = [31970,31971]
operator: = [31974,31975]
===
match
---
testlist_comp [17673,17985]
testlist_comp [17677,17989]
===
match
---
name: count [16564,16569]
name: count [16568,16573]
===
match
---
string: "Naive datetime is disallowed" [24363,24393]
string: "Naive datetime is disallowed" [24367,24397]
===
match
---
operator: , [27986,27987]
operator: , [27990,27991]
===
match
---
number: 2 [11137,11138]
number: 2 [11141,11142]
===
match
---
operator: , [1257,1258]
operator: , [1285,1286]
===
match
---
atom [36151,36193]
atom [36155,36197]
===
match
---
number: 10000.0 [6516,6523]
number: 10000.0 [6536,6543]
===
match
---
operator: , [29537,29538]
operator: , [29541,29542]
===
match
---
operator: , [1928,1929]
operator: , [1956,1957]
===
match
---
name: test_should_respond_200 [20663,20686]
name: test_should_respond_200 [20667,20690]
===
match
---
name: parameterized [25213,25226]
name: parameterized [25217,25230]
===
match
---
operator: { [19329,19330]
operator: { [19333,19334]
===
match
---
string: "clear by task ids" [28407,28426]
string: "clear by task ids" [28411,28430]
===
match
---
number: 2 [29325,29326]
number: 2 [29329,29330]
===
match
---
trailer [37451,37456]
trailer [37455,37460]
===
match
---
expr_stmt [20997,21175]
expr_stmt [21001,21179]
===
match
---
atom [27000,27458]
atom [27004,27462]
===
match
---
trailer [9551,9563]
trailer [9555,9567]
===
match
---
trailer [5154,5166]
trailer [5182,5194]
===
match
---
operator: { [12694,12695]
operator: { [12698,12699]
===
match
---
atom_expr [35663,36056]
atom_expr [35667,36060]
===
match
---
operator: { [36151,36152]
operator: { [36155,36156]
===
match
---
simple_stmt [2490,2807]
simple_stmt [2518,2835]
===
match
---
operator: } [17388,17389]
operator: } [17392,17393]
===
match
---
name: timedelta [10435,10444]
name: timedelta [10439,10448]
===
match
---
suite [7280,9020]
suite [7292,9024]
===
match
---
dictorsetmaker [9823,9882]
dictorsetmaker [9827,9886]
===
match
---
operator: , [18998,18999]
operator: , [19002,19003]
===
match
---
string: "2020-01-02T00:00:00+00:00" [7022,7049]
string: "2020-01-02T00:00:00+00:00" [7042,7069]
===
match
---
name: self [37205,37209]
name: self [37209,37213]
===
match
---
atom [35349,35555]
atom [35353,35559]
===
match
---
operator: , [34930,34931]
operator: , [34934,34935]
===
match
---
operator: = [2824,2825]
operator: = [2852,2853]
===
match
---
param [22979,22986]
param [22983,22990]
===
match
---
name: url [15627,15630]
name: url [15631,15634]
===
match
---
name: expected_response [33729,33746]
name: expected_response [33733,33750]
===
match
---
string: "test" [43157,43163]
string: "test" [43161,43167]
===
match
---
string: "dry_run" [39479,39488]
string: "dry_run" [39483,39492]
===
match
---
strings [10048,10192]
strings [10052,10196]
===
match
---
simple_stmt [16751,16865]
simple_stmt [16755,16869]
===
match
---
atom [13848,14298]
atom [13852,14302]
===
match
---
param [15596,15611]
param [15600,15615]
===
match
---
suite [2229,4775]
suite [2257,4803]
===
match
---
operator: , [39722,39723]
operator: , [39726,39727]
===
match
---
operator: = [9962,9963]
operator: = [9966,9967]
===
match
---
dictorsetmaker [18487,18502]
dictorsetmaker [18491,18506]
===
match
---
suite [20794,21374]
suite [20798,21378]
===
match
---
name: dt [18958,18960]
name: dt [18962,18964]
===
match
---
string: "dag_ids" [23628,23637]
string: "dag_ids" [23632,23641]
===
match
---
operator: } [17964,17965]
operator: } [17968,17969]
===
match
---
trailer [33634,33640]
trailer [33638,33644]
===
match
---
operator: , [13129,13130]
operator: , [13133,13134]
===
match
---
trailer [36821,36829]
trailer [36825,36833]
===
match
---
operator: , [18269,18270]
operator: , [18273,18274]
===
match
---
testlist_comp [23640,23685]
testlist_comp [23644,23689]
===
match
---
atom [24219,24265]
atom [24223,24269]
===
match
---
string: "print_the_context" [8713,8732]
string: "print_the_context" [8725,8744]
===
match
---
name: security [982,990]
name: security [967,975]
===
match
---
name: DEFAULT_DATETIME_STR_1 [19098,19120]
name: DEFAULT_DATETIME_STR_1 [19102,19124]
===
match
---
string: "Naive datetime is disallowed" [42273,42303]
string: "Naive datetime is disallowed" [42277,42307]
===
match
---
name: test_should_respond_200 [31409,31432]
name: test_should_respond_200 [31413,31436]
===
match
---
atom [21934,22050]
atom [21938,22054]
===
match
---
atom [29454,30264]
atom [29458,30268]
===
match
---
dictorsetmaker [43142,43163]
dictorsetmaker [43146,43167]
===
match
---
operator: , [35750,35751]
operator: , [35754,35755]
===
match
---
string: "new_state" [42702,42713]
string: "new_state" [42706,42717]
===
match
---
name: test_utils [1282,1292]
name: test_utils [1310,1320]
===
match
---
dictorsetmaker [12157,12210]
dictorsetmaker [12161,12214]
===
match
---
operator: , [6092,6093]
operator: , [6112,6113]
===
match
---
fstring [12443,12509]
fstring [12447,12513]
===
match
---
operator: , [20249,20250]
operator: , [20253,20254]
===
match
---
decorated [37547,39275]
decorated [37551,39279]
===
match
---
argument [19513,19519]
argument [19517,19523]
===
match
---
string: "REMOTE_USER" [15865,15878]
string: "REMOTE_USER" [15869,15882]
===
match
---
trailer [12279,12287]
trailer [12283,12291]
===
match
---
operator: , [42922,42923]
operator: , [42926,42927]
===
match
---
argument [2047,2077]
argument [2075,2105]
===
match
---
name: assert_401 [35575,35585]
name: assert_401 [35579,35589]
===
match
---
string: "dry_run" [40122,40131]
string: "dry_run" [40126,40135]
===
match
---
operator: , [21855,21856]
operator: , [21859,21860]
===
match
---
atom [26901,27614]
atom [26905,27618]
===
match
---
operator: { [18287,18288]
operator: { [18291,18292]
===
match
---
string: '2020-01-04T00:00:00+00:00' [34623,34650]
string: '2020-01-04T00:00:00+00:00' [34627,34654]
===
match
---
string: 'task_id' [34906,34915]
string: 'task_id' [34910,34919]
===
match
---
operator: } [25797,25798]
operator: } [25801,25802]
===
match
---
atom [12080,12307]
atom [12084,12311]
===
match
---
operator: , [17844,17845]
operator: , [17848,17849]
===
match
---
name: bool [3277,3281]
name: bool [3305,3309]
===
match
---
funcdef [35601,36100]
funcdef [35605,36104]
===
match
---
operator: , [14716,14717]
operator: , [14720,14721]
===
match
---
arith_expr [28636,28677]
arith_expr [28640,28681]
===
match
---
assert_stmt [16580,16626]
assert_stmt [16584,16630]
===
match
---
trailer [3815,3818]
trailer [3843,3846]
===
match
---
operator: = [40737,40738]
operator: = [40741,40742]
===
match
---
suite [35643,36100]
suite [35647,36104]
===
match
---
number: 2 [17983,17984]
number: 2 [17987,17988]
===
match
---
number: 200 [32029,32032]
number: 200 [32033,32036]
===
match
---
suite [36636,37479]
suite [36640,37483]
===
match
---
string: "execution_date" [20189,20205]
string: "execution_date" [20193,20209]
===
match
---
atom [26465,26620]
atom [26469,26624]
===
match
---
dotted_name [2235,2249]
dotted_name [2263,2277]
===
match
---
operator: = [3282,3283]
operator: = [3310,3311]
===
match
---
dictorsetmaker [26491,26598]
dictorsetmaker [26495,26602]
===
match
---
string: "executor_config" [8109,8126]
string: "executor_config" [8121,8138]
===
match
---
name: datetime [1358,1366]
name: datetime [1386,1394]
===
match
---
trailer [22537,22542]
trailer [22541,22546]
===
match
---
string: "2020-01-01T00:00:00+00:00" [8763,8790]
string: "2020-01-01T00:00:00+00:00" [8775,8802]
===
match
---
name: run_type [4320,4328]
name: run_type [4348,4356]
===
match
---
name: post [40595,40599]
name: post [40599,40603]
===
match
---
comparison [16587,16626]
comparison [16591,16630]
===
match
---
operator: } [35819,35820]
operator: } [35823,35824]
===
match
---
argument [20158,20164]
argument [20162,20168]
===
match
---
operator: , [22977,22978]
operator: , [22981,22982]
===
match
---
arith_expr [25687,25728]
arith_expr [25691,25732]
===
match
---
trailer [38879,38906]
trailer [38883,38910]
===
match
---
string: 'detail' [37457,37465]
string: 'detail' [37461,37469]
===
match
---
name: response [37443,37451]
name: response [37447,37455]
===
match
---
string: "execution_date" [9763,9779]
string: "execution_date" [9767,9783]
===
match
---
string: "dag_id" [7915,7923]
string: "dag_id" [7927,7935]
===
match
---
name: self [23123,23127]
name: self [23127,23131]
===
match
---
dictorsetmaker [14391,14412]
dictorsetmaker [14395,14416]
===
match
---
simple_stmt [35138,35169]
simple_stmt [35142,35173]
===
match
---
operator: , [18825,18826]
operator: , [18829,18830]
===
match
---
argument [39101,39134]
argument [39105,39138]
===
match
---
trailer [16205,16241]
trailer [16209,16245]
===
match
---
trailer [16513,16563]
trailer [16517,16567]
===
match
---
string: "state" [33060,33067]
string: "state" [33064,33071]
===
match
---
dictorsetmaker [37325,37346]
dictorsetmaker [37329,37350]
===
match
---
fstring_end: " [10191,10192]
fstring_end: " [10195,10196]
===
match
---
atom [25243,31373]
atom [25247,31377]
===
match
---
simple_stmt [40477,40512]
simple_stmt [40481,40516]
===
match
---
operator: , [28281,28282]
operator: , [28285,28286]
===
match
---
name: mock [37548,37552]
name: mock [37552,37556]
===
match
---
trailer [32888,32896]
trailer [32892,32900]
===
match
---
string: '2020-11-10T12:4po' [36254,36273]
string: '2020-11-10T12:4po' [36258,36277]
===
match
---
name: timedelta [11043,11052]
name: timedelta [11047,11056]
===
match
---
trailer [20807,20829]
trailer [20811,20833]
===
match
---
name: response [23718,23726]
name: response [23722,23730]
===
match
---
string: "pid" [5549,5554]
string: "pid" [5577,5582]
===
match
---
string: 'dag_id' [34739,34747]
string: 'dag_id' [34743,34751]
===
match
---
operator: , [17691,17692]
operator: , [17695,17696]
===
match
---
operator: , [24959,24960]
operator: , [24963,24964]
===
match
---
name: username [2047,2055]
name: username [2075,2083]
===
match
---
operator: , [20476,20477]
operator: , [20480,20481]
===
match
---
string: "module" [1509,1517]
string: "module" [1537,1545]
===
match
---
name: DEFAULT_DATETIME_1 [27150,27168]
name: DEFAULT_DATETIME_1 [27154,27172]
===
match
---
operator: , [40403,40404]
operator: , [40407,40408]
===
match
---
simple_stmt [24873,25052]
simple_stmt [24877,25056]
===
match
---
name: days [28847,28851]
name: days [28851,28855]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/" [13662,13709]
string: "/api/v1/dags/example_python_operator/dagRuns/" [13666,13713]
===
match
---
atom_expr [9945,9965]
atom_expr [9949,9969]
===
match
---
name: self [22938,22942]
name: self [22942,22946]
===
match
---
string: '2020-01-05T00:00:00+00:00' [34861,34888]
string: '2020-01-05T00:00:00+00:00' [34865,34892]
===
match
---
name: dt [10511,10513]
name: dt [10515,10517]
===
match
---
operator: , [31449,31450]
operator: , [31453,31454]
===
match
---
argument [23212,23253]
argument [23216,23257]
===
match
---
name: days [32889,32893]
name: days [32893,32897]
===
match
---
operator: , [15844,15845]
operator: , [15848,15849]
===
match
---
trailer [32782,32790]
trailer [32786,32794]
===
match
---
trailer [32878,32888]
trailer [32882,32892]
===
match
---
number: 200 [15928,15931]
number: 200 [15932,15935]
===
match
---
comparison [41118,41145]
comparison [41122,41149]
===
match
---
name: status_code [15913,15924]
name: status_code [15917,15928]
===
match
---
atom [18090,18114]
atom [18094,18118]
===
match
---
operator: } [33096,33097]
operator: } [33100,33101]
===
match
---
dictorsetmaker [21549,21565]
dictorsetmaker [21553,21569]
===
match
---
simple_stmt [7357,7561]
simple_stmt [7369,7573]
===
match
---
operator: , [29272,29273]
operator: , [29276,29277]
===
match
---
string: "start_date" [10341,10353]
string: "start_date" [10345,10357]
===
match
---
atom [17458,17483]
atom [17462,17487]
===
match
---
arith_expr [11019,11060]
arith_expr [11023,11064]
===
match
---
atom_expr [30880,30900]
atom_expr [30884,30904]
===
match
---
string: "end_date" [5302,5312]
string: "end_date" [5330,5340]
===
match
---
atom_expr [5189,5202]
atom_expr [5217,5230]
===
match
---
simple_stmt [36645,36896]
simple_stmt [36649,36900]
===
match
---
operator: , [13359,13360]
operator: , [13363,13364]
===
match
---
operator: == [17170,17172]
operator: == [17174,17176]
===
match
---
simple_stmt [24039,24074]
simple_stmt [24043,24078]
===
match
---
operator: = [31639,31640]
operator: = [31643,31644]
===
match
---
name: airflow [1015,1022]
name: airflow [1043,1050]
===
match
---
simple_stmt [4061,4077]
simple_stmt [4089,4105]
===
match
---
param [42943,42950]
param [42947,42954]
===
match
---
operator: , [24457,24458]
operator: , [24461,24462]
===
match
---
operator: , [20700,20701]
operator: , [20704,20705]
===
match
---
name: environ_overrides [16366,16383]
name: environ_overrides [16370,16387]
===
match
---
dictorsetmaker [38039,38060]
dictorsetmaker [38043,38064]
===
match
---
operator: , [9216,9217]
operator: , [9220,9221]
===
match
---
atom_expr [2621,2641]
atom_expr [2649,2669]
===
match
---
atom_expr [23041,23103]
atom_expr [23045,23107]
===
match
---
trailer [25533,25543]
trailer [25537,25547]
===
match
---
string: "state" [2448,2455]
string: "state" [2476,2483]
===
match
---
operator: , [24361,24362]
operator: , [24365,24366]
===
match
---
name: json [40099,40103]
name: json [40103,40107]
===
match
---
trailer [16486,16492]
trailer [16490,16496]
===
match
---
atom_expr [26408,26420]
atom_expr [26412,26424]
===
match
---
argument [7476,7508]
argument [7488,7520]
===
match
---
import_from [904,968]
import_from [889,953]
===
match
---
name: client [21013,21019]
name: client [21017,21023]
===
match
---
arglist [37943,38434]
arglist [37947,38438]
===
match
---
operator: , [40873,40874]
operator: , [40877,40878]
===
match
---
trailer [32742,32750]
trailer [32746,32754]
===
match
---
operator: , [4669,4670]
operator: , [4697,4698]
===
match
---
operator: @ [36528,36529]
operator: @ [36532,36533]
===
match
---
name: provide_session [20639,20654]
name: provide_session [20643,20658]
===
match
---
operator: , [2696,2697]
operator: , [2724,2725]
===
match
---
string: "test_queue_1" [17575,17589]
string: "test_queue_1" [17579,17593]
===
match
---
name: days [32743,32747]
name: days [32747,32751]
===
match
---
operator: , [36410,36411]
operator: , [36414,36415]
===
match
---
atom_expr [10511,10531]
atom_expr [10515,10535]
===
match
---
arglist [37235,37374]
arglist [37239,37378]
===
match
---
operator: { [41385,41386]
operator: { [41389,41390]
===
match
---
name: self [20696,20700]
name: self [20700,20704]
===
match
---
string: "start_date" [19386,19398]
string: "start_date" [19390,19402]
===
match
---
operator: == [23447,23449]
operator: == [23451,23453]
===
match
---
atom [36332,36410]
atom [36336,36414]
===
match
---
name: query [16487,16492]
name: query [16491,16496]
===
match
---
name: payload [31971,31978]
name: payload [31975,31982]
===
match
---
operator: == [38517,38519]
operator: == [38521,38523]
===
match
---
operator: , [8230,8231]
operator: , [8242,8243]
===
match
---
operator: = [22136,22137]
operator: = [22140,22141]
===
match
---
operator: , [15643,15644]
operator: , [15647,15648]
===
match
---
fstring_string: ?start_date_gte= [10712,10728]
fstring_string: ?start_date_gte= [10716,10732]
===
match
---
name: self [9324,9328]
name: self [9328,9332]
===
match
---
name: response [16884,16892]
name: response [16888,16896]
===
match
---
trailer [28836,28846]
trailer [28840,28850]
===
match
---
trailer [15960,15977]
trailer [15964,15981]
===
match
---
atom_expr [29801,29821]
atom_expr [29805,29825]
===
match
---
argument [4202,4231]
argument [4230,4259]
===
match
---
trailer [23424,23429]
trailer [23428,23433]
===
match
---
name: autouse [2250,2257]
name: autouse [2278,2285]
===
match
---
argument [30716,30722]
argument [30720,30726]
===
match
---
name: task_instances [3874,3888]
name: task_instances [3902,3916]
===
match
---
param [24792,24800]
param [24796,24804]
===
match
---
operator: , [35165,35166]
operator: , [35169,35170]
===
match
---
operator: , [2795,2796]
operator: , [2823,2824]
===
match
---
trailer [21354,21372]
trailer [21358,21376]
===
match
---
atom [30638,30793]
atom [30642,30797]
===
match
---
dotted_name [1015,1036]
dotted_name [1043,1064]
===
match
---
string: "execution_date" [40837,40853]
string: "execution_date" [40841,40857]
===
match
---
name: State [27226,27231]
name: State [27230,27235]
===
match
---
string: 'example_python_operator' [34035,34060]
string: 'example_python_operator' [34039,34064]
===
match
---
trailer [37845,37853]
trailer [37849,37857]
===
match
---
string: "state" [28119,28126]
string: "state" [28123,28130]
===
match
---
trailer [29636,29644]
trailer [29640,29648]
===
match
---
number: 1 [32602,32603]
number: 1 [32606,32607]
===
match
---
operator: , [21585,21586]
operator: , [21589,21590]
===
match
---
operator: , [27191,27192]
operator: , [27195,27196]
===
match
---
name: count [16642,16647]
name: count [16646,16651]
===
match
---
string: "Test" [1679,1685]
string: "Test" [1707,1713]
===
match
---
name: session [3159,3166]
name: session [3187,3194]
===
match
---
string: 'detail' [25124,25132]
string: 'detail' [25128,25136]
===
match
---
string: "pool" [17777,17783]
string: "pool" [17781,17787]
===
match
---
string: "REMOTE_USER" [37325,37338]
string: "REMOTE_USER" [37329,37342]
===
match
---
atom [24991,25014]
atom [24995,25018]
===
match
---
name: future [39148,39154]
name: future [39152,39158]
===
match
---
trailer [2421,2434]
trailer [2449,2462]
===
match
---
string: "execution_date" [26314,26330]
string: "execution_date" [26318,26334]
===
match
---
operator: , [10845,10846]
operator: , [10849,10850]
===
match
---
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [37943,38006]
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [37947,38010]
===
match
---
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [41248,41311]
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [41252,41315]
===
match
---
name: environ_overrides [43123,43140]
name: environ_overrides [43127,43144]
===
match
---
operator: , [14078,14079]
operator: , [14082,14083]
===
match
---
operator: , [20734,20735]
operator: , [20738,20739]
===
match
---
operator: = [4379,4380]
operator: = [4407,4408]
===
match
---
name: response [32005,32013]
name: response [32009,32017]
===
match
---
operator: == [16534,16536]
operator: == [16538,16540]
===
match
---
simple_stmt [16950,17134]
simple_stmt [16954,17138]
===
match
---
operator: } [2480,2481]
operator: } [2508,2509]
===
match
---
operator: , [26266,26267]
operator: , [26270,26271]
===
match
---
operator: , [34888,34889]
operator: , [34892,34893]
===
match
---
operator: = [41342,41343]
operator: = [41346,41347]
===
match
---
name: permissions [1791,1802]
name: permissions [1819,1830]
===
match
---
string: "pool" [17926,17932]
string: "pool" [17930,17936]
===
match
---
suite [31526,32100]
suite [31530,32104]
===
match
---
argument [39250,39263]
argument [39254,39267]
===
match
---
string: "executor_config" [5414,5431]
string: "executor_config" [5442,5459]
===
match
---
operator: + [20060,20061]
operator: + [20064,20065]
===
match
---
trailer [26532,26542]
trailer [26536,26546]
===
match
---
atom_expr [42961,42996]
atom_expr [42965,43000]
===
match
---
dictorsetmaker [17565,17606]
dictorsetmaker [17569,17610]
===
match
---
string: "include_downstream" [41575,41595]
string: "include_downstream" [41579,41599]
===
match
---
strings [11778,11954]
strings [11782,11958]
===
match
---
name: response [9313,9321]
name: response [9317,9325]
===
match
---
arith_expr [29603,29644]
arith_expr [29607,29648]
===
match
---
operator: } [19362,19363]
operator: } [19366,19367]
===
match
---
atom_expr [36856,36869]
atom_expr [36860,36873]
===
match
---
name: value [4042,4047]
name: value [4070,4075]
===
match
---
name: status_code [38469,38480]
name: status_code [38473,38484]
===
match
---
string: "test" [15880,15886]
string: "test" [15884,15890]
===
match
---
trailer [22458,22470]
trailer [22462,22474]
===
match
---
atom_expr [41218,41744]
atom_expr [41222,41748]
===
match
---
operator: = [33564,33565]
operator: = [33568,33569]
===
match
---
string: "duration" [5269,5279]
string: "duration" [5297,5307]
===
match
---
name: dag_id [3176,3182]
name: dag_id [3204,3210]
===
match
---
operator: == [5203,5205]
operator: == [5231,5233]
===
match
---
argument [31596,31611]
argument [31600,31615]
===
match
---
dictorsetmaker [41344,41365]
dictorsetmaker [41348,41369]
===
match
---
name: self [37670,37674]
name: self [37674,37678]
===
match
---
simple_stmt [39834,39855]
simple_stmt [39838,39859]
===
match
---
operator: } [11696,11697]
operator: } [11700,11701]
===
match
---
suite [32167,35169]
suite [32171,35173]
===
match
---
name: expected_ti [16048,16059]
name: expected_ti [16052,16063]
===
match
---
name: client [16767,16773]
name: client [16771,16777]
===
match
---
string: "execution_date_lte" [20498,20518]
string: "execution_date_lte" [20502,20522]
===
match
---
operator: , [31687,31688]
operator: , [31691,31692]
===
match
---
name: self [3779,3783]
name: self [3807,3811]
===
match
---
trailer [33384,33389]
trailer [33388,33393]
===
match
---
number: 200 [7864,7867]
number: 200 [7876,7879]
===
match
---
trailer [38862,38866]
trailer [38866,38870]
===
match
---
arith_expr [20124,20165]
arith_expr [20128,20169]
===
match
---
dictorsetmaker [24410,24456]
dictorsetmaker [24414,24460]
===
match
---
string: "execution_date" [2399,2415]
string: "execution_date" [2427,2443]
===
match
---
name: dt [11676,11678]
name: dt [11680,11682]
===
match
---
atom [14480,14503]
atom [14484,14507]
===
match
---
name: response [7840,7848]
name: response [7852,7860]
===
match
---
name: self [40583,40587]
name: self [40587,40591]
===
match
---
atom [14934,15105]
atom [14938,15109]
===
match
---
simple_stmt [37754,37894]
simple_stmt [37758,37898]
===
match
---
string: "REMOTE_USER" [16385,16398]
string: "REMOTE_USER" [16389,16402]
===
match
---
string: "execution_date" [8050,8066]
string: "execution_date" [8062,8078]
===
match
---
simple_stmt [6374,6409]
simple_stmt [6394,6429]
===
match
---
trailer [31830,31835]
trailer [31834,31839]
===
match
---
operator: } [27438,27439]
operator: } [27442,27443]
===
match
---
number: 2 [11694,11695]
number: 2 [11698,11699]
===
match
---
atom [27748,27809]
atom [27752,27813]
===
match
---
operator: + [9860,9861]
operator: + [9864,9865]
===
match
---
string: "test_no_permissions" [40063,40084]
string: "test_no_permissions" [40067,40088]
===
match
---
name: DEFAULT_DATETIME_1 [32470,32488]
name: DEFAULT_DATETIME_1 [32474,32492]
===
match
---
string: "hostname" [6686,6696]
string: "hostname" [6706,6716]
===
match
---
operator: , [7197,7198]
operator: , [7209,7210]
===
match
---
name: response [23522,23530]
name: response [23526,23534]
===
match
---
operator: } [31146,31147]
operator: } [31150,31151]
===
match
---
param [31477,31489]
param [31481,31493]
===
match
---
string: "include_future" [40343,40359]
string: "include_future" [40347,40363]
===
match
---
operator: { [14390,14391]
operator: { [14394,14395]
===
match
---
argument [11612,11618]
argument [11616,11622]
===
match
---
testlist_comp [14390,14504]
testlist_comp [14394,14508]
===
match
---
operator: , [33501,33502]
operator: , [33505,33506]
===
match
---
name: self [16261,16265]
name: self [16265,16269]
===
match
---
suite [37542,43296]
suite [37546,43300]
===
match
---
arglist [4970,5120]
arglist [4998,5148]
===
match
---
trailer [41126,41138]
trailer [41130,41142]
===
match
---
operator: , [27439,27440]
operator: , [27443,27444]
===
match
---
trailer [16025,16043]
trailer [16029,16047]
===
match
---
number: 3 [13000,13001]
number: 3 [13004,13005]
===
match
---
name: session [16162,16169]
name: session [16166,16173]
===
match
---
trailer [16976,17133]
trailer [16980,17137]
===
match
---
suite [3362,4775]
suite [3390,4803]
===
match
---
operator: , [24019,24020]
operator: , [24023,24024]
===
match
---
atom_expr [3928,3936]
atom_expr [3956,3964]
===
match
---
operator: == [32085,32087]
operator: == [32089,32091]
===
match
---
string: "include_future" [42129,42145]
string: "include_future" [42133,42149]
===
match
---
operator: + [10430,10431]
operator: + [10434,10435]
===
match
---
atom [29913,30068]
atom [29917,30072]
===
match
---
atom [11431,12006]
atom [11435,12010]
===
match
---
name: RUNNING [27232,27239]
name: RUNNING [27236,27243]
===
match
---
dictorsetmaker [7791,7812]
dictorsetmaker [7803,7824]
===
match
---
dictorsetmaker [18137,18158]
dictorsetmaker [18141,18162]
===
match
---
operator: { [32965,32966]
operator: { [32969,32970]
===
match
---
string: "total_entries" [23430,23445]
string: "total_entries" [23434,23449]
===
match
---
string: "total_entries" [22543,22558]
string: "total_entries" [22547,22562]
===
match
---
operator: } [40456,40457]
operator: } [40460,40461]
===
match
---
operator: , [15351,15352]
operator: , [15355,15356]
===
match
---
dictorsetmaker [6332,6353]
dictorsetmaker [6352,6373]
===
match
---
operator: == [33697,33699]
operator: == [33701,33703]
===
match
---
string: "{'execution_date': ['Not a valid datetime.']}" [42760,42807]
string: "{'execution_date': ['Not a valid datetime.']}" [42764,42811]
===
match
---
atom [17821,17844]
atom [17825,17848]
===
match
---
string: '2020-01-01T00:00:00+00:00' [38720,38747]
string: '2020-01-01T00:00:00+00:00' [38724,38751]
===
match
---
atom [21486,21585]
atom [21490,21589]
===
match
---
param [31499,31511]
param [31503,31515]
===
match
---
atom_expr [38858,38906]
atom_expr [38862,38910]
===
match
---
operator: = [20877,20878]
operator: = [20881,20882]
===
match
---
name: RUNNING [13481,13488]
name: RUNNING [13485,13492]
===
match
---
string: "test_queue_2" [17591,17605]
string: "test_queue_2" [17595,17609]
===
match
---
name: self [24829,24833]
name: self [24833,24837]
===
match
---
string: "description" [8521,8534]
string: "description" [8533,8546]
===
match
---
name: create_task_instances [16184,16205]
name: create_task_instances [16188,16209]
===
match
---
operator: , [22774,22775]
operator: , [22778,22779]
===
match
---
atom [20188,20249]
atom [20192,20253]
===
match
---
operator: , [25728,25729]
operator: , [25732,25733]
===
match
---
operator: { [29736,29737]
operator: { [29740,29741]
===
match
---
dictorsetmaker [33781,33979]
dictorsetmaker [33785,33983]
===
match
---
trailer [20074,20082]
trailer [20078,20086]
===
match
---
atom [32819,32951]
atom [32823,32955]
===
match
---
string: "include_downstream" [40299,40319]
string: "include_downstream" [40303,40323]
===
match
---
name: default_time [4607,4619]
name: default_time [4635,4647]
===
match
---
name: response [43217,43225]
name: response [43221,43229]
===
match
---
name: session [23024,23031]
name: session [23028,23035]
===
match
---
operator: { [8450,8451]
operator: { [8462,8463]
===
match
---
operator: , [33816,33817]
operator: , [33820,33821]
===
match
---
operator: , [26853,26854]
operator: , [26857,26858]
===
match
---
name: session [4061,4068]
name: session [4089,4096]
===
match
---
operator: , [11697,11698]
operator: , [11701,11702]
===
match
---
name: expected_ti [31499,31510]
name: expected_ti [31503,31514]
===
match
---
parameters [16735,16741]
parameters [16739,16745]
===
match
---
operator: = [2088,2089]
operator: = [2116,2117]
===
match
---
string: "execution_date" [28618,28634]
string: "execution_date" [28622,28638]
===
match
---
operator: , [22796,22797]
operator: , [22800,22801]
===
match
---
operator: , [36506,36507]
operator: , [36510,36511]
===
match
---
operator: { [35839,35840]
operator: { [35843,35844]
===
match
---
operator: = [31817,31818]
operator: = [31821,31822]
===
match
---
atom_expr [4490,4721]
atom_expr [4518,4749]
===
match
---
string: 'example_python_operator' [38602,38627]
string: 'example_python_operator' [38606,38631]
===
match
---
trailer [39926,39933]
trailer [39930,39937]
===
match
---
string: "duration" [18487,18497]
string: "duration" [18491,18501]
===
match
---
string: "test" [22390,22396]
string: "test" [22394,22400]
===
match
---
name: payload [43183,43190]
name: payload [43187,43194]
===
match
---
name: dr [4134,4136]
name: dr [4162,4164]
===
match
---
trailer [6432,6437]
trailer [6452,6457]
===
match
---
string: "duration_lte" [18645,18659]
string: "duration_lte" [18649,18663]
===
match
---
trailer [40492,40504]
trailer [40496,40508]
===
match
---
atom_expr [22069,22247]
atom_expr [22073,22251]
===
match
---
name: timedelta [32733,32742]
name: timedelta [32737,32746]
===
match
---
param [32152,32157]
param [32156,32161]
===
match
---
atom_expr [33330,33342]
atom_expr [33334,33346]
===
match
---
simple_stmt [1564,1590]
simple_stmt [1592,1618]
===
match
---
name: DEFAULT_DATETIME_1 [31036,31054]
name: DEFAULT_DATETIME_1 [31040,31058]
===
match
---
trailer [19502,19512]
trailer [19506,19516]
===
match
---
operator: { [27106,27107]
operator: { [27110,27111]
===
match
---
testlist_comp [1791,1848]
testlist_comp [1819,1876]
===
match
---
operator: , [30317,30318]
operator: , [30321,30322]
===
match
---
operator: , [28322,28323]
operator: , [28326,28327]
===
match
---
dictorsetmaker [40122,40443]
dictorsetmaker [40126,40447]
===
match
---
atom_expr [27226,27239]
atom_expr [27230,27243]
===
match
---
operator: , [41366,41367]
operator: , [41370,41371]
===
match
---
operator: , [20374,20375]
operator: , [20378,20379]
===
match
---
operator: { [18525,18526]
operator: { [18529,18530]
===
match
---
name: days [27909,27913]
name: days [27913,27917]
===
match
---
operator: , [17483,17484]
operator: , [17487,17488]
===
match
---
arith_expr [19958,19999]
arith_expr [19962,20003]
===
match
---
trailer [37805,37811]
trailer [37809,37815]
===
match
---
operator: { [9478,9479]
operator: { [9482,9483]
===
match
---
simple_stmt [1271,1336]
simple_stmt [1299,1364]
===
match
---
operator: , [34536,34537]
operator: , [34540,34541]
===
match
---
string: "include_upstream" [42522,42540]
string: "include_upstream" [42526,42544]
===
match
---
name: State [26408,26413]
name: State [26412,26417]
===
match
---
argument [37361,37373]
argument [37365,37377]
===
match
---
name: environ_overrides [24973,24990]
name: environ_overrides [24977,24994]
===
match
---
name: self [43016,43020]
name: self [43020,43024]
===
match
---
operator: , [6038,6039]
operator: , [6058,6059]
===
match
---
name: DEFAULT_DATETIME_STR_1 [1379,1401]
name: DEFAULT_DATETIME_STR_1 [1407,1429]
===
match
---
trailer [9335,9339]
trailer [9339,9343]
===
match
---
trailer [33587,33593]
trailer [33591,33597]
===
match
---
trailer [2157,2179]
trailer [2185,2207]
===
match
---
operator: , [31147,31148]
operator: , [31151,31152]
===
match
---
operator: , [8036,8037]
operator: , [8048,8049]
===
match
---
string: "execution_date" [32452,32468]
string: "execution_date" [32456,32472]
===
match
---
argument [2968,2989]
argument [2996,3017]
===
match
---
arglist [7389,7550]
arglist [7401,7562]
===
match
---
name: expected [43287,43295]
name: expected [43291,43299]
===
match
---
trailer [4945,4952]
trailer [4973,4980]
===
match
---
trailer [43268,43273]
trailer [43272,43277]
===
match
---
testlist_comp [13465,13581]
testlist_comp [13469,13585]
===
match
---
string: "REMOTE_USER" [21116,21129]
string: "REMOTE_USER" [21120,21133]
===
match
---
name: dag_id [23077,23083]
name: dag_id [23081,23087]
===
match
---
atom_expr [6424,6437]
atom_expr [6444,6457]
===
match
---
import_name [785,806]
import_name [785,806]
===
match
---
atom_expr [4025,4048]
atom_expr [4053,4076]
===
match
---
operator: , [27708,27709]
operator: , [27712,27713]
===
match
---
name: expected_ti_count [21249,21266]
name: expected_ti_count [21253,21270]
===
match
---
operator: , [29998,29999]
operator: , [30002,30003]
===
match
---
simple_stmt [15897,15932]
simple_stmt [15901,15936]
===
match
---
name: json [23362,23366]
name: json [23366,23370]
===
match
---
argument [1644,1659]
argument [1672,1687]
===
match
---
operator: , [6931,6932]
operator: , [6951,6952]
===
match
---
string: 'execution_date' [34605,34621]
string: 'execution_date' [34609,34625]
===
match
---
operator: } [27261,27262]
operator: } [27265,27266]
===
match
---
operator: , [43190,43191]
operator: , [43194,43195]
===
match
---
string: 'execution_date' [34843,34859]
string: 'execution_date' [34847,34863]
===
match
---
dictorsetmaker [30556,30615]
dictorsetmaker [30560,30619]
===
match
---
atom [23971,24018]
atom [23975,24022]
===
match
---
name: days [27184,27188]
name: days [27188,27192]
===
match
---
operator: } [13128,13129]
operator: } [13132,13133]
===
match
---
name: response [5189,5197]
name: response [5217,5225]
===
match
---
operator: , [2770,2771]
operator: , [2798,2799]
===
match
---
operator: , [39494,39495]
operator: , [39498,39499]
===
match
---
name: parameterized [868,881]
name: parameterized [853,866]
===
match
---
name: task_instances [3611,3625]
name: task_instances [3639,3653]
===
match
---
operator: + [11597,11598]
operator: + [11601,11602]
===
match
---
assert_stmt [38496,38842]
assert_stmt [38500,38846]
===
match
---
trailer [20323,20331]
trailer [20327,20335]
===
match
---
name: session [31575,31582]
name: session [31579,31586]
===
match
---
operator: , [10229,10230]
operator: , [10233,10234]
===
match
---
dictorsetmaker [29939,30046]
dictorsetmaker [29943,30050]
===
match
---
name: assert_called_once_with [39009,39032]
name: assert_called_once_with [39013,39036]
===
match
---
operator: , [7154,7155]
operator: , [7174,7175]
===
match
---
name: QUEUED [18152,18158]
name: QUEUED [18156,18162]
===
match
---
operator: , [6576,6577]
operator: , [6596,6597]
===
match
---
string: "execution_date" [41967,41983]
string: "execution_date" [41971,41987]
===
match
---
name: days [31070,31074]
name: days [31074,31078]
===
match
---
trailer [16777,16864]
trailer [16781,16868]
===
match
---
number: 15 [22834,22836]
number: 15 [22838,22840]
===
match
---
atom_expr [3985,4007]
atom_expr [4013,4035]
===
match
---
trailer [20064,20074]
trailer [20068,20078]
===
match
---
operator: , [20166,20167]
operator: , [20170,20171]
===
match
---
name: response [35041,35049]
name: response [35045,35053]
===
match
---
string: "{}" [5433,5437]
string: "{}" [5461,5465]
===
match
---
dictorsetmaker [21626,21652]
dictorsetmaker [21630,21656]
===
match
---
operator: , [5729,5730]
operator: , [5757,5758]
===
match
---
name: self [35637,35641]
name: self [35641,35645]
===
match
---
decorated [25212,32100]
decorated [25216,32104]
===
match
---
name: timestamp [7522,7531]
name: timestamp [7534,7543]
===
match
---
simple_stmt [9083,9228]
simple_stmt [9087,9232]
===
match
---
name: State [29856,29861]
name: State [29860,29865]
===
match
---
operator: , [5400,5401]
operator: , [5428,5429]
===
match
---
name: self [3459,3463]
name: self [3487,3491]
===
match
---
simple_stmt [33686,33721]
simple_stmt [33690,33725]
===
match
---
atom_expr [16762,16864]
atom_expr [16766,16868]
===
match
---
atom_expr [22600,22631]
atom_expr [22604,22635]
===
match
---
number: 5 [20329,20330]
number: 5 [20333,20334]
===
match
---
arith_expr [36788,36829]
arith_expr [36792,36833]
===
match
---
name: failed_dag_runs [33548,33563]
name: failed_dag_runs [33552,33567]
===
match
---
string: "print_the_context" [7106,7125]
string: "print_the_context" [7126,7145]
===
match
---
operator: } [11363,11364]
operator: } [11367,11368]
===
match
---
import_from [1185,1270]
import_from [1213,1298]
===
match
---
argument [20864,20891]
argument [20868,20895]
===
match
---
atom_expr [24829,24864]
atom_expr [24833,24868]
===
match
---
operator: , [26682,26683]
operator: , [26686,26687]
===
match
---
name: dt [12267,12269]
name: dt [12271,12273]
===
match
---
simple_stmt [3495,3513]
simple_stmt [3523,3541]
===
match
---
trailer [35105,35110]
trailer [35109,35114]
===
match
---
operator: , [8391,8392]
operator: , [8403,8404]
===
match
---
atom [27106,27262]
atom [27110,27266]
===
match
---
atom_expr [29856,29868]
atom_expr [29860,29872]
===
match
---
operator: == [16593,16595]
operator: == [16597,16599]
===
match
---
dictorsetmaker [11005,11060]
dictorsetmaker [11009,11064]
===
match
---
arith_expr [19400,19441]
arith_expr [19404,19445]
===
match
---
name: default_time [7537,7549]
name: default_time [7549,7561]
===
match
---
operator: == [7861,7863]
operator: == [7873,7875]
===
match
---
trailer [23023,23032]
trailer [23027,23036]
===
match
---
decorator [17242,20634]
decorator [17246,20638]
===
match
---
string: "example_skip_dag" [22776,22794]
string: "example_skip_dag" [22780,22798]
===
match
---
atom_expr [30603,30615]
atom_expr [30607,30619]
===
match
---
atom_expr [23707,23727]
atom_expr [23711,23731]
===
match
---
dictorsetmaker [34263,34455]
dictorsetmaker [34267,34459]
===
match
---
name: payload [22947,22954]
name: payload [22951,22958]
===
match
---
operator: } [27985,27986]
operator: } [27989,27990]
===
match
---
operator: == [9564,9566]
operator: == [9568,9570]
===
match
---
operator: { [21548,21549]
operator: { [21552,21553]
===
match
---
operator: , [15794,15795]
operator: , [15798,15799]
===
match
---
name: single_dag_run [20948,20962]
name: single_dag_run [20952,20966]
===
match
---
operator: , [13599,13600]
operator: , [13603,13604]
===
match
---
assert_stmt [41753,41787]
assert_stmt [41757,41791]
===
match
---
atom_expr [22479,22492]
atom_expr [22483,22496]
===
match
---
operator: , [26887,26888]
operator: , [26891,26892]
===
match
---
operator: , [14916,14917]
operator: , [14920,14921]
===
match
---
dictorsetmaker [28266,28323]
dictorsetmaker [28270,28327]
===
match
---
name: DEFAULT_DATETIME_1 [33001,33019]
name: DEFAULT_DATETIME_1 [33005,33023]
===
match
---
operator: , [38627,38628]
operator: , [38631,38632]
===
match
---
operator: @ [2234,2235]
operator: @ [2262,2263]
===
match
---
atom [24409,24457]
atom [24413,24461]
===
match
---
name: days [29024,29028]
name: days [29028,29032]
===
match
---
name: past [39173,39177]
name: past [39177,39181]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [23563,23608]
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [23567,23612]
===
match
---
trailer [2539,2552]
trailer [2567,2580]
===
match
---
suite [9074,9257]
suite [9078,9261]
===
match
---
name: response [6381,6389]
name: response [6401,6409]
===
match
---
testlist_comp [21424,21688]
testlist_comp [21428,21692]
===
match
---
argument [7389,7416]
argument [7401,7428]
===
match
---
trailer [9864,9874]
trailer [9868,9878]
===
match
---
string: "task_instances" [32066,32082]
string: "task_instances" [32070,32086]
===
match
---
atom_expr [8991,9008]
atom_expr [9003,9012]
===
match
---
operator: } [13488,13489]
operator: } [13492,13493]
===
match
---
simple_stmt [7289,7325]
simple_stmt [7301,7337]
===
match
---
name: DEFAULT_DATETIME_1 [10411,10429]
name: DEFAULT_DATETIME_1 [10415,10433]
===
match
---
operator: , [27416,27417]
operator: , [27420,27421]
===
match
---
name: dag_id [33179,33185]
name: dag_id [33183,33189]
===
match
---
arith_expr [9841,9882]
arith_expr [9845,9886]
===
match
---
simple_stmt [25103,25146]
simple_stmt [25107,25150]
===
match
---
trailer [4496,4721]
trailer [4524,4749]
===
match
---
operator: , [26067,26068]
operator: , [26071,26072]
===
match
---
trailer [3800,3819]
trailer [3828,3847]
===
match
---
trailer [32596,32604]
trailer [32600,32608]
===
match
---
operator: = [32747,32748]
operator: = [32751,32752]
===
match
---
name: client [37918,37924]
name: client [37922,37928]
===
match
---
dictorsetmaker [32983,33083]
dictorsetmaker [32987,33087]
===
match
---
operator: , [29288,29289]
operator: , [29292,29293]
===
match
---
operator: } [30244,30245]
operator: } [30248,30249]
===
match
---
string: "queue" [14804,14811]
string: "queue" [14808,14815]
===
match
---
comparison [22508,22559]
comparison [22512,22563]
===
match
---
number: 2020 [1367,1371]
number: 2020 [1395,1399]
===
match
---
operator: , [18159,18160]
operator: , [18163,18164]
===
match
---
trailer [6062,6084]
trailer [6082,6104]
===
match
---
operator: } [20331,20332]
operator: } [20335,20336]
===
match
---
name: environ_overrides [23212,23229]
name: environ_overrides [23216,23233]
===
match
---
string: "include_future" [38319,38335]
string: "include_future" [38323,38339]
===
match
---
operator: { [22736,22737]
operator: { [22740,22741]
===
match
---
string: "example_python_operator" [27683,27708]
string: "example_python_operator" [27687,27712]
===
match
---
trailer [39365,39825]
trailer [39369,39829]
===
match
---
string: "queue" [14757,14764]
string: "queue" [14761,14768]
===
match
---
operator: , [40771,40772]
operator: , [40775,40776]
===
match
---
operator: , [2077,2078]
operator: , [2105,2106]
===
match
---
operator: , [24690,24691]
operator: , [24694,24695]
===
match
---
operator: , [41461,41462]
operator: , [41465,41466]
===
match
---
name: session [15703,15710]
name: session [15707,15714]
===
match
---
operator: = [6150,6151]
operator: = [6170,6171]
===
match
---
operator: , [41641,41642]
operator: , [41645,41646]
===
match
---
operator: , [10551,10552]
operator: , [10555,10556]
===
match
---
operator: } [20165,20166]
operator: } [20169,20170]
===
match
---
trailer [27173,27183]
trailer [27177,27187]
===
match
---
string: "dry_run" [25900,25909]
string: "dry_run" [25904,25913]
===
match
---
suite [4829,9571]
suite [4857,9575]
===
match
---
operator: } [40718,40719]
operator: } [40722,40723]
===
match
---
operator: , [32329,32330]
operator: , [32333,32334]
===
match
---
name: FAILED [27802,27808]
name: FAILED [27806,27812]
===
match
---
atom_expr [35093,35129]
atom_expr [35097,35133]
===
match
---
trailer [37456,37466]
trailer [37460,37470]
===
match
---
operator: } [23252,23253]
operator: } [23256,23257]
===
match
---
name: task [38944,38948]
name: task [38948,38952]
===
match
---
operator: } [19441,19442]
operator: } [19445,19446]
===
match
---
argument [22411,22423]
argument [22415,22427]
===
match
---
name: timedelta [25711,25720]
name: timedelta [25715,25724]
===
match
---
name: timedelta [27899,27908]
name: timedelta [27903,27912]
===
match
---
operator: { [14480,14481]
operator: { [14484,14485]
===
match
---
string: "execution_date" [42461,42477]
string: "execution_date" [42465,42481]
===
match
---
string: "only_running" [32343,32357]
string: "only_running" [32347,32361]
===
match
---
atom [33478,33501]
atom [33482,33505]
===
match
---
operator: , [5658,5659]
operator: , [5686,5687]
===
match
---
dotted_name [1488,1502]
dotted_name [1516,1530]
===
match
---
operator: = [22178,22179]
operator: = [22182,22183]
===
match
---
operator: , [42255,42256]
operator: , [42259,42260]
===
match
---
argument [2079,2108]
argument [2107,2136]
===
match
---
string: '2020-11-10T12:42:39.442973' [24428,24456]
string: '2020-11-10T12:42:39.442973' [24432,24460]
===
match
---
operator: , [3317,3318]
operator: , [3345,3346]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances?" [11778,11855]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances?" [11782,11859]
===
match
---
name: environ_overrides [7772,7789]
name: environ_overrides [7784,7801]
===
match
---
name: expand [17257,17263]
name: expand [17261,17267]
===
match
---
trailer [19981,19991]
trailer [19985,19995]
===
match
---
string: "TEST_DAG_RUN_ID" [4552,4569]
string: "TEST_DAG_RUN_ID" [4580,4597]
===
match
---
name: client [41223,41229]
name: client [41227,41233]
===
match
---
operator: = [3188,3189]
operator: = [3216,3217]
===
match
---
fstring_string: &start_date_lte= [11324,11340]
fstring_string: &start_date_lte= [11328,11344]
===
match
---
operator: } [18502,18503]
operator: } [18506,18507]
===
match
---
name: task_instances [3801,3815]
name: task_instances [3829,3843]
===
match
---
operator: , [18561,18562]
operator: , [18565,18566]
===
match
---
trailer [1904,1927]
trailer [1932,1955]
===
match
---
operator: = [24990,24991]
operator: = [24994,24995]
===
match
---
operator: + [25706,25707]
operator: + [25710,25711]
===
match
---
name: mock_set_state [37754,37768]
name: mock_set_state [37758,37772]
===
match
---
operator: , [19180,19181]
operator: , [19184,19185]
===
match
---
trailer [3534,3541]
trailer [3562,3569]
===
match
---
string: "dry_run" [30336,30345]
string: "dry_run" [30340,30349]
===
match
---
import_from [969,1009]
import_from [954,994]
===
match
---
operator: , [4393,4394]
operator: , [4421,4422]
===
match
---
name: DEFAULT_DATETIME_STR_2 [11930,11952]
name: DEFAULT_DATETIME_STR_2 [11934,11956]
===
match
---
name: dr [4485,4487]
name: dr [4513,4515]
===
match
---
dictorsetmaker [18091,18113]
dictorsetmaker [18095,18117]
===
match
---
trailer [2557,2567]
trailer [2585,2595]
===
match
---
name: self [4268,4272]
name: self [4296,4300]
===
match
---
for_stmt [3967,4049]
for_stmt [3995,4077]
===
match
---
string: 'dag_run_id' [34792,34804]
string: 'dag_run_id' [34796,34808]
===
match
---
trailer [4765,4772]
trailer [4793,4800]
===
match
---
suite [16126,16688]
suite [16130,16692]
===
match
---
string: "end_date" [12234,12244]
string: "end_date" [12238,12248]
===
match
---
operator: , [19521,19522]
operator: , [19525,19526]
===
match
---
name: response [21270,21278]
name: response [21274,21282]
===
match
---
name: response [24873,24881]
name: response [24877,24885]
===
match
---
trailer [22283,22434]
trailer [22287,22438]
===
match
---
decorated [24079,25146]
decorated [24083,25150]
===
match
---
operator: , [31488,31489]
operator: , [31492,31493]
===
match
---
operator: , [14283,14284]
operator: , [14287,14288]
===
match
---
dictorsetmaker [41403,41719]
dictorsetmaker [41407,41723]
===
match
---
trailer [24833,24855]
trailer [24837,24859]
===
match
---
operator: , [32951,32952]
operator: , [32955,32956]
===
match
---
name: response [40572,40580]
name: response [40576,40584]
===
match
---
assert_stmt [23409,23458]
assert_stmt [23413,23462]
===
match
---
operator: , [28183,28184]
operator: , [28187,28188]
===
match
---
atom_expr [36724,36737]
atom_expr [36728,36741]
===
match
---
operator: } [10751,10752]
operator: } [10755,10756]
===
match
---
operator: , [21687,21688]
operator: , [21691,21692]
===
match
---
atom_expr [5945,5962]
atom_expr [5973,5982]
===
match
---
name: read_dags_from_db [2991,3008]
name: read_dags_from_db [3019,3036]
===
match
---
string: "test duration filter" [12593,12615]
string: "test duration filter" [12597,12619]
===
match
---
atom [17655,17999]
atom [17659,18003]
===
match
---
name: dt [29801,29803]
name: dt [29805,29807]
===
match
---
name: self [3145,3149]
name: self [3173,3177]
===
match
---
string: 'TEST_DAG_RUN_ID' [38663,38680]
string: 'TEST_DAG_RUN_ID' [38667,38684]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [4970,5064]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [4998,5092]
===
match
---
atom [20520,20563]
atom [20524,20567]
===
match
---
decorators [25212,31401]
decorators [25216,31405]
===
match
---
dotted_name [37548,37558]
dotted_name [37552,37562]
===
match
---
string: "test" [1653,1659]
string: "test" [1681,1687]
===
match
---
atom [24604,24690]
atom [24608,24694]
===
match
---
string: "pool" [13970,13976]
string: "pool" [13974,13980]
===
match
---
name: role_name [2079,2088]
name: role_name [2107,2116]
===
match
---
operator: , [25915,25916]
operator: , [25919,25920]
===
match
---
trailer [2819,2823]
trailer [2847,2851]
===
match
---
operator: == [37467,37469]
operator: == [37471,37473]
===
match
---
name: days [32597,32601]
name: days [32601,32605]
===
match
---
name: status_code [32014,32025]
name: status_code [32018,32029]
===
match
---
operator: , [20601,20602]
operator: , [20605,20606]
===
match
---
argument [4167,4180]
argument [4195,4208]
===
match
---
operator: { [26465,26466]
operator: { [26469,26470]
===
match
---
operator: , [18464,18465]
operator: , [18468,18469]
===
match
---
trailer [37714,37736]
trailer [37718,37740]
===
match
---
operator: { [39461,39462]
operator: { [39465,39466]
===
match
---
operator: + [10509,10510]
operator: + [10513,10514]
===
match
---
operator: , [17907,17908]
operator: , [17911,17912]
===
match
---
name: status_code [6390,6401]
name: status_code [6410,6421]
===
match
---
trailer [35054,35072]
trailer [35058,35076]
===
match
---
operator: , [37292,37293]
operator: , [37296,37297]
===
match
---
suite [16941,17177]
suite [16945,17181]
===
match
---
name: timedelta [20065,20074]
name: timedelta [20069,20078]
===
match
---
operator: , [26597,26598]
operator: , [26601,26602]
===
match
---
name: timedelta [27174,27183]
name: timedelta [27178,27187]
===
match
---
operator: } [42254,42255]
operator: } [42258,42259]
===
match
---
argument [1695,2018]
argument [1723,2046]
===
match
---
decorator [36105,36524]
decorator [36109,36528]
===
match
---
dictorsetmaker [23960,24018]
dictorsetmaker [23964,24022]
===
match
---
operator: , [28375,28376]
operator: , [28379,28380]
===
match
---
operator: , [39210,39211]
operator: , [39214,39215]
===
match
---
arith_expr [27875,27916]
arith_expr [27879,27920]
===
match
---
string: "execution_date_gte" [24506,24526]
string: "execution_date_gte" [24510,24530]
===
match
---
operator: } [12210,12211]
operator: } [12214,12215]
===
match
---
operator: { [24409,24410]
operator: { [24413,24414]
===
match
---
trailer [2623,2633]
trailer [2651,2661]
===
match
---
string: "duration" [18526,18536]
string: "duration" [18530,18540]
===
match
---
decorated [2234,3105]
decorated [2262,3133]
===
match
---
trailer [23537,23544]
trailer [23541,23548]
===
match
---
operator: = [37782,37783]
operator: = [37786,37787]
===
match
---
string: "example_python_operator" [25835,25860]
string: "example_python_operator" [25839,25864]
===
match
---
name: test_should_raises_401_unauthenticated [23468,23506]
name: test_should_raises_401_unauthenticated [23472,23510]
===
match
---
string: "task_id" [41915,41924]
string: "task_id" [41919,41928]
===
match
---
operator: , [21874,21875]
operator: , [21878,21879]
===
match
---
atom [42332,42822]
atom [42336,42826]
===
match
---
expr_stmt [2849,2885]
expr_stmt [2877,2913]
===
match
---
name: dt [27896,27898]
name: dt [27900,27902]
===
match
---
name: TestTaskInstanceEndpoint [4803,4827]
name: TestTaskInstanceEndpoint [4831,4855]
===
match
---
atom [9740,9985]
atom [9744,9989]
===
match
---
string: "end_date" [26759,26769]
string: "end_date" [26763,26773]
===
match
---
simple_stmt [16873,16894]
simple_stmt [16877,16898]
===
match
---
atom_expr [16135,16170]
atom_expr [16139,16174]
===
match
---
operator: , [7813,7814]
operator: , [7825,7826]
===
match
---
operator: , [20563,20564]
operator: , [20567,20568]
===
match
---
operator: , [35461,35462]
operator: , [35465,35466]
===
match
---
operator: , [24394,24395]
operator: , [24398,24399]
===
match
---
trailer [37917,37924]
trailer [37921,37928]
===
match
---
atom_expr [21191,21211]
atom_expr [21195,21215]
===
match
---
name: len [16008,16011]
name: len [16012,16015]
===
match
---
name: response [35232,35240]
name: response [35236,35244]
===
match
---
operator: , [17502,17503]
operator: , [17506,17507]
===
match
---
argument [39072,39087]
argument [39076,39091]
===
match
---
operator: = [25725,25726]
operator: = [25729,25730]
===
match
---
name: DEFAULT_DATETIME_1 [11098,11116]
name: DEFAULT_DATETIME_1 [11102,11120]
===
match
---
operator: { [28008,28009]
operator: { [28012,28013]
===
match
---
operator: , [19584,19585]
operator: , [19588,19589]
===
match
---
atom [41385,41733]
atom [41389,41737]
===
match
---
string: "task_id" [8906,8915]
string: "task_id" [8918,8927]
===
match
---
operator: , [29714,29715]
operator: , [29718,29719]
===
match
---
argument [33240,33269]
argument [33244,33273]
===
match
---
arglist [39379,39815]
arglist [39383,39819]
===
match
---
name: self [2323,2327]
name: self [2351,2355]
===
match
---
operator: = [4173,4174]
operator: = [4201,4202]
===
match
---
name: DEFAULT_DATETIME_1 [32855,32873]
name: DEFAULT_DATETIME_1 [32859,32877]
===
match
---
string: "execution_date" [4281,4297]
string: "execution_date" [4309,4325]
===
match
---
param [20721,20735]
param [20725,20739]
===
match
---
name: status_code [23315,23326]
name: status_code [23319,23330]
===
match
---
operator: , [12791,12792]
operator: , [12795,12796]
===
match
---
trailer [22613,22631]
trailer [22617,22635]
===
match
---
argument [26543,26549]
argument [26547,26553]
===
match
---
string: "only_failed" [35441,35454]
string: "only_failed" [35445,35458]
===
match
---
trailer [4772,4774]
trailer [4800,4802]
===
match
---
string: "end_date_lte" [19142,19156]
string: "end_date_lte" [19146,19160]
===
match
---
assert_stmt [21242,21300]
assert_stmt [21246,21304]
===
match
---
trailer [3478,3486]
trailer [3506,3514]
===
match
---
arglist [21410,21699]
arglist [21414,21703]
===
match
---
name: test_should_assert_call_mocked_api [37635,37669]
name: test_should_assert_call_mocked_api [37639,37673]
===
match
---
name: FAILED [28563,28569]
name: FAILED [28567,28573]
===
match
---
string: "example_python_operator" [26657,26682]
string: "example_python_operator" [26661,26686]
===
match
---
atom [28592,28747]
atom [28596,28751]
===
match
---
string: 'print_the_context' [33959,33978]
string: 'print_the_context' [33963,33982]
===
match
---
operator: , [23665,23666]
operator: , [23669,23670]
===
match
---
name: environ_overrides [21097,21114]
name: environ_overrides [21101,21118]
===
match
---
atom_expr [22529,22559]
atom_expr [22533,22563]
===
match
---
atom_expr [38994,39274]
atom_expr [38998,39278]
===
match
---
operator: { [13190,13191]
operator: { [13194,13195]
===
match
---
simple_stmt [23409,23459]
simple_stmt [23413,23463]
===
match
---
name: app [37132,37135]
name: app [37136,37139]
===
match
---
fstring [4209,4231]
fstring [4237,4259]
===
match
---
classdef [4777,9571]
classdef [4805,9575]
===
match
---
string: 'REMOTE_USER' [38039,38052]
string: 'REMOTE_USER' [38043,38056]
===
match
---
operator: , [15710,15711]
operator: , [15714,15715]
===
match
---
name: test_should_respond_200_with_reset_dag_run [32109,32151]
name: test_should_respond_200_with_reset_dag_run [32113,32155]
===
match
---
operator: == [5167,5169]
operator: == [5195,5197]
===
match
---
trailer [33034,33042]
trailer [33038,33046]
===
match
---
operator: { [30992,30993]
operator: { [30996,30997]
===
match
---
trailer [30157,30167]
trailer [30161,30171]
===
match
---
string: "start_date" [36334,36346]
string: "start_date" [36338,36350]
===
match
---
atom [10396,10453]
atom [10400,10457]
===
match
---
trailer [2374,2382]
trailer [2402,2410]
===
match
---
dictorsetmaker [23231,23252]
dictorsetmaker [23235,23256]
===
match
---
name: json [35344,35348]
name: json [35348,35352]
===
match
---
dictorsetmaker [15280,15303]
dictorsetmaker [15284,15307]
===
match
---
argument [30168,30174]
argument [30172,30178]
===
match
---
operator: , [36869,36870]
operator: , [36873,36874]
===
match
---
assert_stmt [41111,41145]
assert_stmt [41115,41149]
===
match
---
name: timedelta [25534,25543]
name: timedelta [25538,25547]
===
match
---
operator: , [13001,13002]
operator: , [13005,13006]
===
match
---
operator: } [36273,36274]
operator: } [36277,36278]
===
match
---
atom [18924,18979]
atom [18928,18983]
===
match
---
operator: , [11159,11160]
operator: , [11163,11164]
===
match
---
fstring_start: f" [10132,10134]
fstring_start: f" [10136,10138]
===
match
---
operator: , [24204,24205]
operator: , [24208,24209]
===
match
---
name: dag_id [33419,33425]
name: dag_id [33423,33429]
===
match
---
arith_expr [12246,12287]
arith_expr [12250,12291]
===
match
---
param [4868,4875]
param [4896,4903]
===
match
---
atom [31929,31952]
atom [31933,31956]
===
match
---
operator: , [28747,28748]
operator: , [28751,28752]
===
match
---
name: dt [26530,26532]
name: dt [26534,26536]
===
match
---
name: single_dag_run [4093,4107]
name: single_dag_run [4121,4135]
===
match
---
argument [33179,33192]
argument [33183,33196]
===
match
---
operator: } [41732,41733]
operator: } [41736,41737]
===
match
---
operator: == [25134,25136]
operator: == [25138,25140]
===
match
---
dictorsetmaker [17777,17798]
dictorsetmaker [17781,17802]
===
match
---
name: test_should_raise_403_forbidden [39864,39895]
name: test_should_raise_403_forbidden [39868,39899]
===
match
---
argument [20948,20977]
argument [20952,20981]
===
match
---
atom_expr [19421,19441]
atom_expr [19425,19445]
===
match
---
operator: } [19916,19917]
operator: } [19920,19921]
===
match
---
operator: } [21652,21653]
operator: } [21656,21657]
===
match
---
name: DagRun [939,945]
name: DagRun [924,930]
===
match
---
atom_expr [27171,27191]
atom_expr [27175,27195]
===
match
---
name: test_should_raises_401_unauthenticated [35178,35216]
name: test_should_raises_401_unauthenticated [35182,35220]
===
match
---
operator: , [28426,28427]
operator: , [28430,28431]
===
match
---
string: "end_date" [12157,12167]
string: "end_date" [12161,12171]
===
match
---
trailer [9874,9882]
trailer [9878,9886]
===
match
---
arith_expr [10490,10531]
arith_expr [10494,10535]
===
match
---
name: self [16935,16939]
name: self [16939,16943]
===
match
---
operator: , [6770,6771]
operator: , [6790,6791]
===
match
---
name: add [4069,4072]
name: add [4097,4100]
===
match
---
arith_expr [33001,33042]
arith_expr [33005,33046]
===
match
---
operator: { [24313,24314]
operator: { [24317,24318]
===
match
---
atom [21424,21687]
atom [21428,21691]
===
match
---
name: response [35586,35594]
name: response [35590,35598]
===
match
---
trailer [27898,27908]
trailer [27902,27912]
===
match
---
if_stmt [3550,3637]
if_stmt [3578,3665]
===
match
---
operator: , [10210,10211]
operator: , [10214,10215]
===
match
---
testlist_comp [15171,15502]
testlist_comp [15175,15506]
===
match
---
name: State [2457,2462]
name: State [2485,2490]
===
match
---
name: add [4742,4745]
name: add [4770,4773]
===
match
---
string: "sla_miss" [6978,6988]
string: "sla_miss" [6998,7008]
===
match
---
trailer [33074,33082]
trailer [33078,33086]
===
match
---
operator: { [23902,23903]
operator: { [23906,23907]
===
match
---
name: test_should_respond_200_dag_ids_filter [22899,22937]
name: test_should_respond_200_dag_ids_filter [22903,22941]
===
match
---
dictorsetmaker [29203,29289]
dictorsetmaker [29207,29293]
===
match
---
name: update_extras [3225,3238]
name: update_extras [3253,3266]
===
match
---
assert_stmt [38453,38487]
assert_stmt [38457,38491]
===
match
---
operator: } [14412,14413]
operator: } [14416,14417]
===
match
---
trailer [22073,22095]
trailer [22077,22099]
===
match
---
trailer [25543,25551]
trailer [25547,25555]
===
match
---
name: len [23349,23352]
name: len [23353,23356]
===
match
---
name: timedelta [29804,29813]
name: timedelta [29808,29817]
===
match
---
operator: { [16384,16385]
operator: { [16388,16389]
===
match
---
name: session [33580,33587]
name: session [33584,33591]
===
match
---
atom_expr [41760,41780]
atom_expr [41764,41784]
===
match
---
string: "end_date" [7997,8007]
string: "end_date" [8009,8019]
===
match
---
operator: , [28360,28361]
operator: , [28364,28365]
===
match
---
string: "Naive datetime is disallowed" [24459,24489]
string: "Naive datetime is disallowed" [24463,24493]
===
match
---
fstring_end: " [33445,33446]
fstring_end: " [33449,33450]
===
match
---
trailer [11131,11139]
trailer [11135,11143]
===
match
---
name: DEFAULT_DATETIME_1 [2343,2361]
name: DEFAULT_DATETIME_1 [2371,2389]
===
match
---
atom [41838,42318]
atom [41842,42322]
===
match
---
atom_expr [12190,12210]
atom_expr [12194,12214]
===
match
---
operator: , [19289,19290]
operator: , [19293,19294]
===
match
---
dictorsetmaker [31930,31951]
dictorsetmaker [31934,31955]
===
match
---
operator: @ [1487,1488]
operator: @ [1515,1516]
===
match
---
atom [18486,18503]
atom [18490,18507]
===
match
---
decorators [41793,42861]
decorators [41797,42865]
===
match
---
operator: } [18978,18979]
operator: } [18982,18983]
===
match
---
operator: , [28164,28165]
operator: , [28168,28169]
===
match
---
operator: , [11991,11992]
operator: , [11995,11996]
===
match
---
atom_expr [4734,4749]
atom_expr [4762,4777]
===
match
---
operator: , [20778,20779]
operator: , [20782,20783]
===
match
---
comparison [17149,17176]
comparison [17153,17180]
===
match
---
name: scope [1503,1508]
name: scope [1531,1536]
===
match
---
suite [2314,3105]
suite [2342,3133]
===
match
---
argument [22164,22193]
argument [22168,22197]
===
match
---
number: 1 [11058,11059]
number: 1 [11062,11063]
===
match
---
atom_expr [3459,3486]
atom_expr [3487,3514]
===
match
---
trailer [11052,11060]
trailer [11056,11064]
===
match
---
name: get [6188,6191]
name: get [6208,6211]
===
match
---
expr_stmt [15814,15888]
expr_stmt [15818,15892]
===
match
---
operator: , [6859,6860]
operator: , [6879,6880]
===
match
---
trailer [23361,23366]
trailer [23365,23370]
===
match
---
operator: = [37911,37912]
operator: = [37915,37916]
===
match
---
trailer [2633,2641]
trailer [2661,2669]
===
match
---
name: status_code [43226,43237]
name: status_code [43230,43241]
===
match
---
name: session [16117,16124]
name: session [16121,16128]
===
match
---
operator: = [39082,39083]
operator: = [39086,39087]
===
match
---
number: 1 [2573,2574]
number: 1 [2601,2602]
===
match
---
atom [18136,18159]
atom [18140,18163]
===
match
---
argument [22356,22397]
argument [22360,22401]
===
match
---
name: days [29814,29818]
name: days [29818,29822]
===
match
---
dotted_name [22639,22659]
dotted_name [22643,22663]
===
match
---
operator: , [22851,22852]
operator: , [22855,22856]
===
match
---
atom [6331,6354]
atom [6351,6374]
===
match
---
argument [15846,15887]
argument [15850,15891]
===
match
---
atom [11004,11061]
atom [11008,11065]
===
match
---
atom [18623,18665]
atom [18627,18669]
===
match
---
operator: = [31074,31075]
operator: = [31078,31079]
===
match
---
assert_stmt [35138,35168]
assert_stmt [35142,35172]
===
match
---
string: """Method to create task instances using kwargs and default arguments""" [3371,3443]
string: """Method to create task instances using kwargs and default arguments""" [3399,3471]
===
match
---
trailer [3506,3512]
trailer [3534,3540]
===
match
---
operator: } [24018,24019]
operator: } [24022,24023]
===
match
---
trailer [5197,5202]
trailer [5225,5230]
===
match
---
operator: , [16853,16854]
operator: , [16857,16858]
===
match
---
name: FAILED [33336,33342]
name: FAILED [33340,33346]
===
match
---
trailer [16965,16972]
trailer [16969,16976]
===
match
---
parameters [3135,3361]
parameters [3163,3389]
===
match
---
dictorsetmaker [20436,20564]
dictorsetmaker [20440,20568]
===
match
---
name: timedelta [28660,28669]
name: timedelta [28664,28673]
===
match
---
string: "test_no_permissions" [9494,9515]
string: "test_no_permissions" [9498,9519]
===
match
---
suite [3837,3893]
suite [3865,3921]
===
match
---
name: task_instance [35024,35037]
name: task_instance [35028,35041]
===
match
---
funcdef [22895,23459]
funcdef [22899,23463]
===
match
---
operator: , [38301,38302]
operator: , [38305,38306]
===
match
---
operator: , [37674,37675]
operator: , [37678,37679]
===
match
---
operator: = [4601,4602]
operator: = [4629,4630]
===
match
---
suite [4008,4049]
suite [4036,4077]
===
match
---
name: session [20843,20850]
name: session [20847,20854]
===
match
---
string: "dry_run" [41878,41887]
string: "dry_run" [41882,41891]
===
match
---
name: response [15904,15912]
name: response [15908,15916]
===
match
---
operator: = [3340,3341]
operator: = [3368,3369]
===
match
---
name: session [37692,37699]
name: session [37696,37703]
===
match
---
atom [9676,10244]
atom [9680,10248]
===
match
---
operator: } [10452,10453]
operator: } [10456,10457]
===
match
---
atom [40738,41091]
atom [40742,41095]
===
match
---
operator: , [17885,17886]
operator: , [17889,17890]
===
match
---
string: "end_date" [21988,21998]
string: "end_date" [21992,22002]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/~/taskInstances" [16290,16352]
string: "/api/v1/dags/example_python_operator/dagRuns/~/taskInstances" [16294,16356]
===
match
---
operator: } [32950,32951]
operator: } [32954,32955]
===
match
---
operator: , [39760,39761]
operator: , [39764,39765]
===
match
---
operator: { [10475,10476]
operator: { [10479,10480]
===
match
---
string: "duration" [12695,12705]
string: "duration" [12699,12709]
===
match
---
name: payload [31490,31497]
name: payload [31494,31501]
===
match
---
trailer [39008,39032]
trailer [39012,39036]
===
match
---
string: "test end date filter ~" [12038,12062]
string: "test end date filter ~" [12042,12066]
===
match
---
trailer [16883,16893]
trailer [16887,16897]
===
match
---
name: task_dict [38955,38964]
name: task_dict [38959,38968]
===
match
---
operator: { [24991,24992]
operator: { [24995,24996]
===
match
---
number: 1 [8318,8319]
number: 1 [8330,8331]
===
match
---
name: TestTaskInstanceEndpoint [17211,17235]
name: TestTaskInstanceEndpoint [17215,17239]
===
match
---
operator: { [25643,25644]
operator: { [25647,25648]
===
match
---
atom [16384,16407]
atom [16388,16411]
===
match
---
string: "example_python_operator" [36972,36997]
string: "example_python_operator" [36976,37001]
===
match
---
string: "pid" [6784,6789]
string: "pid" [6804,6809]
===
match
---
operator: , [13489,13490]
operator: , [13493,13494]
===
match
---
operator: , [3149,3150]
operator: , [3177,3178]
===
match
---
atom [22683,22851]
atom [22687,22855]
===
match
---
name: State [27951,27956]
name: State [27955,27960]
===
match
---
simple_stmt [43005,43202]
simple_stmt [43009,43206]
===
match
---
argument [4587,4619]
argument [4615,4647]
===
match
---
operator: + [11117,11118]
operator: + [11121,11122]
===
match
---
name: DEFAULT_DATETIME_1 [19958,19976]
name: DEFAULT_DATETIME_1 [19962,19980]
===
match
---
operator: } [41365,41366]
operator: } [41369,41370]
===
match
---
operator: , [22477,22478]
operator: , [22481,22482]
===
match
---
atom_expr [16179,16241]
atom_expr [16183,16245]
===
match
---
operator: , [31459,31460]
operator: , [31463,31464]
===
match
---
argument [6137,6155]
argument [6157,6175]
===
match
---
string: "new_state" [40421,40432]
string: "new_state" [40425,40436]
===
match
---
name: test_should_respond_200_with_task_state_in_removed [5983,6033]
name: test_should_respond_200_with_task_state_in_removed [6003,6053]
===
match
---
operator: , [35555,35556]
operator: , [35559,35560]
===
match
---
atom_expr [1791,1818]
atom_expr [1819,1846]
===
match
---
operator: , [11140,11141]
operator: , [11144,11145]
===
match
---
operator: , [8160,8161]
operator: , [8172,8173]
===
match
---
name: MANUAL [4340,4346]
name: MANUAL [4368,4374]
===
match
---
name: self [2601,2605]
name: self [2629,2633]
===
match
---
string: "execution_date" [36677,36693]
string: "execution_date" [36681,36697]
===
match
---
operator: , [42638,42639]
operator: , [42642,42643]
===
match
---
string: "duration" [13191,13201]
string: "duration" [13195,13205]
===
match
---
atom [18793,18825]
atom [18797,18829]
===
match
---
number: 100 [5556,5559]
number: 100 [5584,5587]
===
match
---
string: '2020-11-10T12:42:39.442973' [24236,24264]
string: '2020-11-10T12:42:39.442973' [24240,24268]
===
match
---
trailer [1954,1970]
trailer [1982,1998]
===
match
---
atom_expr [32777,32790]
atom_expr [32781,32794]
===
match
---
operator: , [17863,17864]
operator: , [17867,17868]
===
match
---
operator: , [32896,32897]
operator: , [32900,32901]
===
match
---
testlist_comp [17305,17627]
testlist_comp [17309,17631]
===
match
---
trailer [23429,23446]
trailer [23433,23450]
===
match
---
simple_stmt [5182,5974]
simple_stmt [5210,5994]
===
match
---
operator: = [27188,27189]
operator: = [27192,27193]
===
match
---
parameters [4861,4876]
parameters [4889,4904]
===
match
---
name: DEFAULT_DATETIME_1 [32563,32581]
name: DEFAULT_DATETIME_1 [32567,32585]
===
match
---
name: ti_extras [3990,3999]
name: ti_extras [4018,4027]
===
match
---
string: "dag_ids" [21626,21635]
string: "dag_ids" [21630,21639]
===
match
---
trailer [24054,24066]
trailer [24058,24070]
===
match
---
atom [17731,17754]
atom [17735,17758]
===
match
---
name: client [23128,23134]
name: client [23132,23138]
===
match
---
operator: , [18319,18320]
operator: , [18323,18324]
===
match
---
testlist_comp [13924,14038]
testlist_comp [13928,14042]
===
match
---
assert_stmt [43210,43244]
assert_stmt [43214,43248]
===
match
---
operator: , [13834,13835]
operator: , [13838,13839]
===
match
---
dictorsetmaker [36334,36376]
dictorsetmaker [36338,36380]
===
match
---
atom_expr [6176,6365]
atom_expr [6196,6385]
===
match
---
string: "state" [7063,7070]
string: "state" [7083,7090]
===
match
---
operator: , [34945,34946]
operator: , [34949,34950]
===
match
---
expr_stmt [3495,3512]
expr_stmt [3523,3540]
===
match
---
string: 'dag_id' [34501,34509]
string: 'dag_id' [34505,34513]
===
match
---
operator: } [17435,17436]
operator: } [17439,17440]
===
match
---
operator: , [24590,24591]
operator: , [24594,24595]
===
match
---
operator: , [15594,15595]
operator: , [15598,15599]
===
match
---
name: self [6058,6062]
name: self [6078,6082]
===
match
---
dictorsetmaker [17365,17388]
dictorsetmaker [17369,17392]
===
match
---
operator: , [15610,15611]
operator: , [15614,15615]
===
match
---
param [20702,20704]
param [20706,20708]
===
match
---
operator: , [31497,31498]
operator: , [31501,31502]
===
match
---
name: DEFAULT_DATETIME_1 [39116,39134]
name: DEFAULT_DATETIME_1 [39120,39138]
===
match
---
operator: , [42594,42595]
operator: , [42598,42599]
===
match
---
name: response [21341,21349]
name: response [21345,21353]
===
match
---
dictorsetmaker [24314,24360]
dictorsetmaker [24318,24364]
===
match
---
string: "test" [7806,7812]
string: "test" [7818,7824]
===
match
---
exprlist [3971,3981]
exprlist [3999,4009]
===
match
---
name: provide_session [42845,42860]
name: provide_session [42849,42864]
===
match
---
name: DEFAULT_DATETIME_1 [19344,19362]
name: DEFAULT_DATETIME_1 [19348,19366]
===
match
---
argument [31070,31076]
argument [31074,31080]
===
match
---
string: "test_pool_2" [17785,17798]
string: "test_pool_2" [17789,17802]
===
match
---
string: 'sleep_for_0' [34203,34216]
string: 'sleep_for_0' [34207,34220]
===
match
---
comparison [40484,40511]
comparison [40488,40515]
===
match
---
trailer [27231,27239]
trailer [27235,27243]
===
match
---
string: "test_pool_1" [17740,17753]
string: "test_pool_1" [17744,17757]
===
match
---
name: session [24856,24863]
name: session [24860,24867]
===
match
---
string: "test execution date filter" [9694,9722]
string: "test execution date filter" [9698,9726]
===
match
---
trailer [10434,10444]
trailer [10438,10448]
===
match
---
name: task_instances [21816,21830]
name: task_instances [21820,21834]
===
match
---
fstring_string: &start_date_lte= [10752,10768]
fstring_string: &start_date_lte= [10756,10772]
===
match
---
name: count [33635,33640]
name: count [33639,33644]
===
match
---
arglist [6085,6155]
arglist [6105,6175]
===
match
---
argument [24973,25014]
argument [24977,25018]
===
match
---
assert_stmt [36065,36099]
assert_stmt [36069,36103]
===
match
---
atom_expr [13521,13533]
atom_expr [13525,13537]
===
match
---
atom_expr [33580,33642]
atom_expr [33584,33646]
===
match
---
trailer [41222,41229]
trailer [41226,41233]
===
match
---
trailer [12192,12202]
trailer [12196,12206]
===
match
---
operator: { [18793,18794]
operator: { [18797,18798]
===
match
---
operator: , [21468,21469]
operator: , [21472,21473]
===
match
---
number: 3 [31075,31076]
number: 3 [31079,31080]
===
match
---
operator: + [27894,27895]
operator: + [27898,27899]
===
match
---
name: response [9083,9091]
name: response [9087,9095]
===
match
---
string: "example_python_operator" [26957,26982]
string: "example_python_operator" [26961,26986]
===
match
---
atom_expr [7884,7897]
atom_expr [7896,7909]
===
match
---
name: days [11612,11616]
name: days [11616,11620]
===
match
---
atom_expr [28073,28093]
atom_expr [28077,28097]
===
match
---
string: "executor_config" [6649,6666]
string: "executor_config" [6669,6686]
===
match
---
string: "test_no_permissions" [35798,35819]
string: "test_no_permissions" [35802,35823]
===
match
---
name: parameterized [9632,9645]
name: parameterized [9636,9649]
===
match
---
string: "clear only running" [26919,26939]
string: "clear only running" [26923,26943]
===
match
---
operator: , [19120,19121]
operator: , [19124,19125]
===
match
---
name: DEFAULT_DATETIME_STR_2 [19158,19180]
name: DEFAULT_DATETIME_STR_2 [19162,19184]
===
match
---
name: TestTaskInstanceEndpoint [2204,2228]
name: TestTaskInstanceEndpoint [2232,2256]
===
match
---
arglist [9123,9217]
arglist [9127,9221]
===
match
---
operator: , [37073,37074]
operator: , [37077,37078]
===
match
---
trailer [9098,9105]
trailer [9102,9109]
===
match
---
simple_stmt [17142,17177]
simple_stmt [17146,17181]
===
match
---
operator: { [24605,24606]
operator: { [24609,24610]
===
match
---
operator: = [7490,7491]
operator: = [7502,7503]
===
match
---
name: response [16751,16759]
name: response [16755,16763]
===
match
---
simple_stmt [4429,4445]
simple_stmt [4457,4473]
===
match
---
atom [27726,28183]
atom [27730,28187]
===
match
---
string: "dry_run" [35367,35376]
string: "dry_run" [35371,35380]
===
match
---
operator: , [17436,17437]
operator: , [17440,17441]
===
match
---
simple_stmt [2815,2841]
simple_stmt [2843,2869]
===
match
---
operator: } [28340,28341]
operator: } [28344,28345]
===
match
---
operator: , [23198,23199]
operator: , [23202,23203]
===
match
---
operator: = [2171,2172]
operator: = [2199,2200]
===
match
---
suite [6049,7209]
suite [6069,7221]
===
match
---
simple_stmt [3593,3637]
simple_stmt [3621,3665]
===
match
---
funcdef [5979,7209]
funcdef [5999,7221]
===
match
---
trailer [39360,39365]
trailer [39364,39369]
===
match
---
name: client [7640,7646]
name: client [7652,7658]
===
match
---
name: dt [27349,27351]
name: dt [27353,27355]
===
match
---
operator: = [28090,28091]
operator: = [28094,28095]
===
match
---
string: 'dag_id' [38592,38600]
string: 'dag_id' [38596,38604]
===
match
---
testlist_comp [1722,1775]
testlist_comp [1750,1803]
===
match
---
operator: = [4692,4693]
operator: = [4720,4721]
===
match
---
dictorsetmaker [28618,28725]
dictorsetmaker [28622,28729]
===
match
---
string: "pool" [8268,8274]
string: "pool" [8280,8286]
===
match
---
trailer [20829,20988]
trailer [20833,20992]
===
match
---
operator: , [38799,38800]
operator: , [38803,38804]
===
match
---
dictorsetmaker [30116,30223]
dictorsetmaker [30120,30227]
===
match
---
operator: { [13112,13113]
operator: { [13116,13117]
===
match
---
operator: { [38520,38521]
operator: { [38524,38525]
===
match
---
name: post [39361,39365]
name: post [39365,39369]
===
match
---
trailer [16443,16455]
trailer [16447,16459]
===
match
---
simple_stmt [38944,38986]
simple_stmt [38948,38990]
===
match
---
if_stmt [3683,3893]
if_stmt [3711,3921]
===
match
---
operator: { [35349,35350]
operator: { [35353,35354]
===
match
---
arglist [33403,33528]
arglist [33407,33532]
===
match
---
name: get [15837,15840]
name: get [15841,15844]
===
match
---
atom_expr [11119,11139]
atom_expr [11123,11143]
===
match
---
operator: { [12233,12234]
operator: { [12237,12238]
===
match
---
operator: @ [24079,24080]
operator: @ [24083,24084]
===
match
---
name: State [18191,18196]
name: State [18195,18200]
===
match
---
dictorsetmaker [38592,38800]
dictorsetmaker [38596,38804]
===
match
---
string: "new_state" [41697,41708]
string: "new_state" [41701,41712]
===
match
---
operator: == [15925,15927]
operator: == [15929,15931]
===
match
---
operator: , [42742,42743]
operator: , [42746,42747]
===
match
---
atom [19060,19199]
atom [19064,19203]
===
match
---
name: default_time [2540,2552]
name: default_time [2568,2580]
===
match
---
trailer [13480,13488]
trailer [13484,13492]
===
match
---
name: expected_ti_count [22575,22592]
name: expected_ti_count [22579,22596]
===
match
---
trailer [31768,31770]
trailer [31772,31774]
===
match
---
string: "queued" [18309,18317]
string: "queued" [18313,18321]
===
match
---
name: client [43021,43027]
name: client [43025,43031]
===
match
---
string: "example_python_operator" [16537,16562]
string: "example_python_operator" [16541,16566]
===
match
---
trailer [37877,37881]
trailer [37881,37885]
===
match
---
trailer [17157,17169]
trailer [17161,17173]
===
match
---
atom_expr [7532,7549]
atom_expr [7544,7561]
===
match
---
operator: } [13946,13947]
operator: } [13950,13951]
===
match
---
atom [12694,12711]
atom [12698,12715]
===
match
---
funcdef [1519,2196]
funcdef [1547,2224]
===
match
---
trailer [22599,22632]
trailer [22603,22636]
===
match
---
simple_stmt [24829,24865]
simple_stmt [24833,24869]
===
match
---
parameters [6033,6048]
parameters [6053,6068]
===
match
---
operator: , [6490,6491]
operator: , [6510,6511]
===
match
---
atom [21625,21653]
atom [21629,21657]
===
match
---
atom_expr [30758,30770]
atom_expr [30762,30774]
===
match
---
operator: } [15886,15887]
operator: } [15890,15891]
===
match
---
string: "start_date_lte" [19686,19702]
string: "start_date_lte" [19690,19706]
===
match
---
name: DEFAULT_DATETIME_1 [30859,30877]
name: DEFAULT_DATETIME_1 [30863,30881]
===
match
---
name: self [16111,16115]
name: self [16115,16119]
===
match
---
trailer [35259,35566]
trailer [35263,35570]
===
match
---
name: dt [20542,20544]
name: dt [20546,20548]
===
match
---
simple_stmt [863,903]
simple_stmt [848,888]
===
match
---
atom [30090,30245]
atom [30094,30249]
===
match
---
operator: , [12134,12135]
operator: , [12138,12139]
===
match
---
fstring_string: /api/v1/dags/ [33405,33418]
fstring_string: /api/v1/dags/ [33409,33422]
===
match
---
string: "test start date filter" [10276,10300]
string: "test start date filter" [10280,10304]
===
match
---
operator: { [12156,12157]
operator: { [12160,12161]
===
match
---
operator: = [26547,26548]
operator: = [26551,26552]
===
match
---
comparison [6424,7208]
comparison [6444,7220]
===
match
---
operator: , [34469,34470]
operator: , [34473,34474]
===
match
---
atom [32229,32411]
atom [32233,32415]
===
match
---
comparison [5146,5173]
comparison [5174,5201]
===
match
---
atom [27628,28375]
atom [27632,28379]
===
match
---
name: response [37194,37202]
name: response [37198,37206]
===
match
---
string: "task" [21549,21555]
string: "task" [21553,21559]
===
match
---
name: json [35050,35054]
name: json [35054,35058]
===
match
---
name: days [9958,9962]
name: days [9962,9966]
===
match
---
operator: { [33478,33479]
operator: { [33482,33483]
===
match
---
string: "execution_date" [9823,9839]
string: "execution_date" [9827,9843]
===
match
---
operator: , [5465,5466]
operator: , [5493,5494]
===
match
---
trailer [27351,27361]
trailer [27355,27365]
===
match
---
trailer [21228,21233]
trailer [21232,21237]
===
match
---
string: "execution_date" [19940,19956]
string: "execution_date" [19944,19960]
===
match
---
suite [21890,22633]
suite [21894,22637]
===
match
---
funcdef [20659,21374]
funcdef [20663,21378]
===
match
---
operator: = [1356,1357]
operator: = [1384,1385]
===
match
---
operator: { [19602,19603]
operator: { [19606,19607]
===
match
---
name: timedelta [20314,20323]
name: timedelta [20318,20327]
===
match
---
operator: == [6402,6404]
operator: == [6422,6424]
===
match
---
trailer [4956,5130]
trailer [4984,5158]
===
match
---
name: timedelta [12193,12202]
name: timedelta [12197,12206]
===
match
---
atom_expr [3607,3626]
atom_expr [3635,3654]
===
match
---
operator: , [31446,31447]
operator: , [31450,31451]
===
match
---
operator: = [40581,40582]
operator: = [40585,40586]
===
match
---
dotted_name [1276,1295]
dotted_name [1304,1323]
===
match
---
operator: } [30615,30616]
operator: } [30619,30620]
===
match
---
name: downstream [39072,39082]
name: downstream [39076,39086]
===
match
---
arith_expr [28990,29031]
arith_expr [28994,29035]
===
match
---
name: ACTION_CAN_READ [1876,1891]
name: ACTION_CAN_READ [1904,1919]
===
match
---
name: DEFAULT_DATETIME_STR_2 [11341,11363]
name: DEFAULT_DATETIME_STR_2 [11345,11367]
===
match
---
param [3327,3355]
param [3355,3383]
===
match
---
argument [4374,4393]
argument [4402,4421]
===
match
---
trailer [33144,33353]
trailer [33148,33357]
===
match
---
arglist [22669,22863]
arglist [22673,22867]
===
match
---
arith_expr [25510,25551]
arith_expr [25514,25555]
===
match
---
name: timedelta [20231,20240]
name: timedelta [20235,20244]
===
match
---
trailer [39032,39274]
trailer [39036,39278]
===
match
---
string: "2020-01-03T00:00:00+00:00" [8009,8036]
string: "2020-01-03T00:00:00+00:00" [8021,8048]
===
match
---
number: 100 [18640,18643]
number: 100 [18644,18647]
===
match
---
name: self [23769,23773]
name: self [23773,23777]
===
match
---
name: timedelta [10514,10523]
name: timedelta [10518,10527]
===
match
---
operator: { [18090,18091]
operator: { [18094,18095]
===
match
---
trailer [26590,26597]
trailer [26594,26601]
===
match
---
atom [33763,33993]
atom [33767,33997]
===
match
---
simple_stmt [2323,2362]
simple_stmt [2351,2390]
===
match
---
name: status_code [41769,41780]
name: status_code [41773,41784]
===
match
---
atom [28389,29341]
atom [28393,29345]
===
match
---
string: "2020-01-03T00:00:00+00:00" [5314,5341]
string: "2020-01-03T00:00:00+00:00" [5342,5369]
===
match
---
fstring_string: TEST_DAG_RUN_ID_ [4211,4227]
fstring_string: TEST_DAG_RUN_ID_ [4239,4255]
===
match
---
name: FAILED [26591,26597]
name: FAILED [26595,26601]
===
match
---
trailer [30892,30900]
trailer [30896,30904]
===
match
---
operator: @ [31384,31385]
operator: @ [31388,31389]
===
match
---
trailer [3463,3470]
trailer [3491,3498]
===
match
---
name: DEFAULT_DATETIME_1 [18806,18824]
name: DEFAULT_DATETIME_1 [18810,18828]
===
match
---
testlist_comp [17575,17605]
testlist_comp [17579,17609]
===
match
---
name: dt [20145,20147]
name: dt [20149,20151]
===
match
---
name: TestPostSetTaskInstanceState [37487,37515]
name: TestPostSetTaskInstanceState [37491,37519]
===
match
---
operator: == [22526,22528]
operator: == [22530,22532]
===
match
---
name: response [16655,16663]
name: response [16659,16667]
===
match
---
atom [36425,36460]
atom [36429,36464]
===
match
---
number: 1 [36827,36828]
number: 1 [36831,36832]
===
match
---
simple_stmt [37127,37186]
simple_stmt [37131,37190]
===
match
---
operator: , [2575,2576]
operator: , [2603,2604]
===
match
---
operator: = [27913,27914]
operator: = [27917,27918]
===
match
---
name: utils [1023,1028]
name: utils [1051,1056]
===
match
---
name: RUNNING [2463,2470]
name: RUNNING [2491,2498]
===
match
---
arglist [31575,31722]
arglist [31579,31726]
===
match
---
argument [25721,25727]
argument [25725,25731]
===
match
---
atom_expr [28834,28854]
atom_expr [28838,28858]
===
match
---
trailer [32060,32065]
trailer [32064,32069]
===
match
---
atom_expr [25586,25598]
atom_expr [25590,25602]
===
match
---
trailer [16563,16569]
trailer [16567,16573]
===
match
---
number: 1 [5623,5624]
number: 1 [5651,5652]
===
match
---
arith_expr [29957,29998]
arith_expr [29961,30002]
===
match
---
atom_expr [9862,9882]
atom_expr [9866,9886]
===
match
---
operator: { [14014,14015]
operator: { [14018,14019]
===
match
---
operator: , [8892,8893]
operator: , [8904,8905]
===
match
---
operator: , [35423,35424]
operator: , [35427,35428]
===
match
---
name: username [1644,1652]
name: username [1672,1680]
===
match
---
testlist_comp [17364,17484]
testlist_comp [17368,17488]
===
match
---
name: dag_id [7430,7436]
name: dag_id [7442,7448]
===
match
---
name: expected [36617,36625]
name: expected [36621,36629]
===
match
---
name: self [22997,23001]
name: self [23001,23005]
===
match
---
testlist_comp [36333,36409]
testlist_comp [36337,36413]
===
match
---
name: assert_401 [23707,23717]
name: assert_401 [23711,23721]
===
match
---
argument [33035,33041]
argument [33039,33045]
===
match
---
name: ti_extras [2495,2504]
name: ti_extras [2523,2532]
===
match
---
operator: { [18847,18848]
operator: { [18851,18852]
===
match
---
atom [14390,14413]
atom [14394,14417]
===
match
---
operator: = [9879,9880]
operator: = [9883,9884]
===
match
---
atom_expr [16873,16893]
atom_expr [16877,16897]
===
match
---
number: 2 [30898,30899]
number: 2 [30902,30903]
===
match
---
operator: , [41037,41038]
operator: , [41041,41042]
===
match
---
trailer [3610,3626]
trailer [3638,3654]
===
match
---
name: ti [3905,3907]
name: ti [3933,3935]
===
match
---
name: environ_overrides [40678,40695]
name: environ_overrides [40682,40699]
===
match
---
fstring_expr [11891,11915]
fstring_expr [11895,11919]
===
match
---
trailer [22095,22247]
trailer [22099,22251]
===
match
---
name: DEFAULT_DATETIME_1 [36788,36806]
name: DEFAULT_DATETIME_1 [36792,36810]
===
match
---
operator: , [29120,29121]
operator: , [29124,29125]
===
match
---
name: len [22596,22599]
name: len [22600,22603]
===
match
---
string: "task_instances" [35055,35071]
string: "task_instances" [35059,35075]
===
match
---
string: 'print_the_context' [38965,38984]
string: 'print_the_context' [38969,38988]
===
match
---
simple_stmt [20803,20989]
simple_stmt [20807,20993]
===
match
---
name: dt [30155,30157]
name: dt [30159,30161]
===
match
---
name: post [37217,37221]
name: post [37221,37225]
===
match
---
number: 200 [38484,38487]
number: 200 [38488,38491]
===
match
---
name: update_extras [33283,33296]
name: update_extras [33287,33300]
===
match
---
atom_expr [43016,43201]
atom_expr [43020,43205]
===
match
---
operator: , [35820,35821]
operator: , [35824,35825]
===
match
---
string: "sla_miss" [8438,8448]
string: "sla_miss" [8450,8460]
===
match
---
atom_expr [19979,19999]
atom_expr [19983,20003]
===
match
---
string: "execution_date" [32837,32853]
string: "execution_date" [32841,32857]
===
match
---
name: create_task_instances [16140,16161]
name: create_task_instances [16144,16165]
===
match
---
atom_expr [16514,16533]
atom_expr [16518,16537]
===
match
---
name: self [9298,9302]
name: self [9302,9306]
===
match
---
name: default_time [2422,2434]
name: default_time [2450,2462]
===
match
---
name: DEFAULT_DATETIME_1 [11019,11037]
name: DEFAULT_DATETIME_1 [11023,11041]
===
match
---
operator: } [24456,24457]
operator: } [24460,24461]
===
match
---
operator: = [32435,32436]
operator: = [32439,32440]
===
match
---
string: "test queue filter ~" [15171,15192]
string: "test queue filter ~" [15175,15196]
===
match
---
name: tasks [3535,3540]
name: tasks [3563,3568]
===
match
---
string: "execution_date" [29585,29601]
string: "execution_date" [29589,29605]
===
match
---
comp_op [3568,3574]
comp_op [3596,3602]
===
match
---
operator: , [35383,35384]
operator: , [35387,35388]
===
match
---
operator: == [21267,21269]
operator: == [21271,21273]
===
match
---
name: response [35097,35105]
name: response [35101,35109]
===
match
---
number: 100 [12668,12671]
number: 100 [12672,12675]
===
match
---
operator: , [26373,26374]
operator: , [26377,26378]
===
match
---
trailer [29861,29868]
trailer [29865,29872]
===
match
---
testlist_comp [41838,42823]
testlist_comp [41842,42827]
===
match
---
expr_stmt [43005,43201]
expr_stmt [43009,43205]
===
match
---
name: single_dag_run [20736,20750]
name: single_dag_run [20740,20754]
===
match
---
operator: , [19233,19234]
operator: , [19237,19238]
===
match
---
simple_stmt [3371,3444]
simple_stmt [3399,3472]
===
match
---
simple_stmt [31808,31990]
simple_stmt [31812,31994]
===
match
---
name: task_instances [20905,20919]
name: task_instances [20909,20923]
===
match
---
name: delete_user [1259,1270]
name: delete_user [1287,1298]
===
match
---
param [37670,37675]
param [37674,37679]
===
match
---
name: test_should_respond_200 [15563,15586]
name: test_should_respond_200 [15567,15590]
===
match
---
name: _ [15593,15594]
name: _ [15597,15598]
===
match
---
number: 2 [13818,13819]
number: 2 [13822,13823]
===
match
---
trailer [21340,21373]
trailer [21344,21377]
===
match
---
string: "test" [41359,41365]
string: "test" [41363,41369]
===
match
---
operator: } [10981,10982]
operator: } [10985,10986]
===
match
---
name: json [22411,22415]
name: json [22415,22419]
===
match
---
atom [11511,11543]
atom [11515,11547]
===
match
---
string: "end_date" [18848,18858]
string: "end_date" [18852,18862]
===
match
---
operator: , [21566,21567]
operator: , [21570,21571]
===
match
---
operator: , [27262,27263]
operator: , [27266,27267]
===
match
---
operator: , [41076,41077]
operator: , [41080,41081]
===
match
---
trailer [3057,3104]
trailer [3085,3132]
===
match
---
dictorsetmaker [34739,34931]
dictorsetmaker [34743,34935]
===
match
---
string: "pid" [2655,2660]
string: "pid" [2683,2688]
===
match
---
file_input [785,43296]
file_input [785,43300]
===
match
---
name: len [16651,16654]
name: len [16655,16658]
===
match
---
operator: = [39177,39178]
operator: = [39181,39182]
===
match
---
param [7271,7278]
param [7283,7290]
===
match
---
name: self [42961,42965]
name: self [42965,42969]
===
match
---
number: 1 [11617,11618]
number: 1 [11621,11622]
===
match
---
string: "end_date" [18794,18804]
string: "end_date" [18798,18808]
===
match
---
argument [18894,18900]
argument [18898,18904]
===
match
---
argument [39173,39182]
argument [39177,39186]
===
match
---
expr_stmt [41207,41744]
expr_stmt [41211,41748]
===
match
---
string: "test_queue_2" [15289,15303]
string: "test_queue_2" [15293,15307]
===
match
---
name: client [4946,4952]
name: client [4974,4980]
===
match
---
string: "2020-01-02T00:00:00+00:00" [8833,8860]
string: "2020-01-02T00:00:00+00:00" [8845,8872]
===
match
---
dictorsetmaker [36770,36870]
dictorsetmaker [36774,36874]
===
match
---
operator: { [14850,14851]
operator: { [14854,14855]
===
match
---
trailer [4072,4076]
trailer [4100,4104]
===
match
---
operator: { [11642,11643]
operator: { [11646,11647]
===
match
---
atom [36662,36895]
atom [36666,36899]
===
match
---
string: "execution_date" [27023,27039]
string: "execution_date" [27027,27043]
===
match
---
arglist [16290,16408]
arglist [16294,16412]
===
match
---
operator: , [40281,40282]
operator: , [40285,40286]
===
match
---
operator: , [945,946]
operator: , [930,931]
===
match
---
atom [23639,23686]
atom [23643,23690]
===
match
---
name: update_extras [20878,20891]
name: update_extras [20882,20895]
===
match
---
name: filter [37826,37832]
name: filter [37830,37836]
===
match
---
name: response [16250,16258]
name: response [16254,16262]
===
match
---
operator: , [34454,34455]
operator: , [34458,34459]
===
match
---
name: query [33588,33593]
name: query [33592,33597]
===
match
---
operator: + [11674,11675]
operator: + [11678,11679]
===
match
---
operator: , [12307,12308]
operator: , [12311,12312]
===
match
---
trailer [18883,18893]
trailer [18887,18897]
===
match
---
operator: , [41601,41602]
operator: , [41605,41606]
===
match
---
number: 1 [25549,25550]
number: 1 [25553,25554]
===
match
---
name: response [39845,39853]
name: response [39849,39857]
===
match
---
name: response [20997,21005]
name: response [21001,21009]
===
match
---
name: total_ti [22969,22977]
name: total_ti [22973,22981]
===
match
---
name: DEFAULT_DATETIME_1 [28813,28831]
name: DEFAULT_DATETIME_1 [28817,28835]
===
match
---
operator: , [14631,14632]
operator: , [14635,14636]
===
match
---
argument [12280,12286]
argument [12284,12290]
===
match
---
dictorsetmaker [9906,9965]
dictorsetmaker [9910,9969]
===
match
---
operator: , [39814,39815]
operator: , [39818,39819]
===
match
---
number: 100 [8251,8254]
number: 100 [8263,8266]
===
match
---
simple_stmt [22256,22435]
simple_stmt [22260,22439]
===
match
---
string: "default_queue" [6916,6931]
string: "default_queue" [6936,6951]
===
match
---
operator: , [36738,36739]
operator: , [36742,36743]
===
match
---
atom [15326,15351]
atom [15330,15355]
===
match
---
name: TaskInstance [16514,16526]
name: TaskInstance [16518,16530]
===
match
---
trailer [33640,33642]
trailer [33644,33646]
===
match
---
trailer [36930,37118]
trailer [36934,37122]
===
match
---
name: status_code [33709,33720]
name: status_code [33713,33724]
===
match
---
atom_expr [7491,7508]
atom_expr [7503,7520]
===
match
---
fstring_expr [11929,11953]
fstring_expr [11933,11957]
===
match
---
operator: , [34587,34588]
operator: , [34591,34592]
===
match
---
name: session [32158,32165]
name: session [32162,32169]
===
match
---
operator: { [25466,25467]
operator: { [25470,25471]
===
match
---
atom [12156,12211]
atom [12160,12215]
===
match
---
name: parameterized [17243,17256]
name: parameterized [17247,17260]
===
match
---
operator: , [20750,20751]
operator: , [20754,20755]
===
match
---
name: clear_db_sla_miss [2933,2950]
name: clear_db_sla_miss [2961,2978]
===
match
---
comparison [7840,7867]
comparison [7852,7879]
===
match
---
arith_expr [20041,20082]
arith_expr [20045,20086]
===
match
---
trailer [12202,12210]
trailer [12206,12214]
===
match
---
atom_expr [23306,23326]
atom_expr [23310,23330]
===
match
---
suite [39329,39855]
suite [39333,39859]
===
match
---
name: commit [4766,4772]
name: commit [4794,4800]
===
match
---
operator: , [31209,31210]
operator: , [31213,31214]
===
match
---
trailer [16604,16609]
trailer [16608,16613]
===
match
---
trailer [25075,25087]
trailer [25079,25091]
===
match
---
operator: , [2665,2666]
operator: , [2693,2694]
===
match
---
name: response [25067,25075]
name: response [25071,25079]
===
match
---
name: client [40588,40594]
name: client [40592,40598]
===
match
---
funcdef [23464,23728]
funcdef [23468,23732]
===
match
---
name: dt [25531,25533]
name: dt [25535,25537]
===
match
---
argument [2250,2262]
argument [2278,2290]
===
match
---
trailer [29684,29691]
trailer [29688,29695]
===
match
---
string: "only_running" [35969,35983]
string: "only_running" [35973,35987]
===
match
---
string: "end_date" [36242,36252]
string: "end_date" [36246,36256]
===
match
---
operator: { [15279,15280]
operator: { [15283,15284]
===
match
---
string: "queue" [2746,2753]
string: "queue" [2774,2781]
===
match
---
atom_expr [25067,25087]
atom_expr [25071,25091]
===
match
---
atom_expr [35041,35072]
atom_expr [35045,35076]
===
match
---
string: "/api/v1/dags/example_python_operator/clearTaskInstances" [37235,37292]
string: "/api/v1/dags/example_python_operator/clearTaskInstances" [37239,37296]
===
match
---
param [32158,32165]
param [32162,32169]
===
match
---
operator: { [19060,19061]
operator: { [19064,19065]
===
match
---
string: "example_python_operator" [7437,7462]
string: "example_python_operator" [7449,7474]
===
match
---
number: 4 [33040,33041]
number: 4 [33044,33045]
===
match
---
operator: , [1818,1819]
operator: , [1846,1847]
===
match
---
name: task_instances [3553,3567]
name: task_instances [3581,3595]
===
match
---
argument [41380,41733]
argument [41384,41737]
===
match
---
arith_expr [19479,19520]
arith_expr [19483,19524]
===
match
---
string: "job_id" [2784,2792]
string: "job_id" [2812,2820]
===
match
---
operator: = [32601,32602]
operator: = [32605,32606]
===
match
---
testlist_comp [19879,20333]
testlist_comp [19883,20337]
===
match
---
testlist_comp [25257,31363]
testlist_comp [25261,31367]
===
match
---
name: response [33362,33370]
name: response [33366,33374]
===
match
---
fstring [33403,33446]
fstring [33407,33450]
===
match
---
string: 'execution_date' [38702,38718]
string: 'execution_date' [38706,38722]
===
match
---
operator: = [38079,38080]
operator: = [38083,38084]
===
match
---
operator: , [40137,40138]
operator: , [40141,40142]
===
match
---
string: "with execution date filter" [19811,19839]
string: "with execution date filter" [19815,19843]
===
match
---
operator: , [30616,30617]
operator: , [30620,30621]
===
match
---
operator: , [14056,14057]
operator: , [14060,14061]
===
match
---
expr_stmt [22256,22434]
expr_stmt [22260,22438]
===
match
---
expr_stmt [4930,5130]
expr_stmt [4958,5158]
===
match
---
trailer [37209,37216]
trailer [37213,37220]
===
match
---
trailer [36811,36821]
trailer [36815,36825]
===
match
---
name: sync_to_db [37144,37154]
name: sync_to_db [37148,37158]
===
match
---
operator: , [22116,22117]
operator: , [22120,22121]
===
match
---
operator: , [14665,14666]
operator: , [14669,14670]
===
match
---
argument [38075,38433]
argument [38079,38437]
===
match
---
operator: { [31227,31228]
operator: { [31231,31232]
===
match
---
operator: == [33622,33624]
operator: == [33626,33628]
===
match
---
atom [17934,17964]
atom [17938,17968]
===
match
---
argument [20241,20247]
argument [20245,20251]
===
match
---
comparison [3686,3708]
comparison [3714,3736]
===
match
---
operator: , [21672,21673]
operator: , [21676,21677]
===
match
---
operator: { [11891,11892]
operator: { [11895,11896]
===
match
---
name: json [7893,7897]
name: json [7905,7909]
===
match
---
operator: , [34060,34061]
operator: , [34064,34065]
===
match
---
name: value [3976,3981]
name: value [4004,4009]
===
match
---
operator: , [22862,22863]
operator: , [22866,22867]
===
match
---
funcdef [39280,39855]
funcdef [39284,39859]
===
match
---
trailer [37135,37143]
trailer [37139,37147]
===
match
---
dictorsetmaker [10949,10981]
dictorsetmaker [10953,10985]
===
match
---
trailer [13526,13533]
trailer [13530,13537]
===
match
---
operator: = [2572,2573]
operator: = [2600,2601]
===
match
---
string: "state" [27217,27224]
string: "state" [27221,27228]
===
match
---
operator: , [15370,15371]
operator: , [15374,15375]
===
match
---
operator: , [19839,19840]
operator: , [19843,19844]
===
match
---
atom_expr [15663,15805]
atom_expr [15667,15809]
===
match
---
trailer [3989,3999]
trailer [4017,4027]
===
match
---
atom [13112,13129]
atom [13116,13133]
===
match
---
string: "state" [28880,28887]
string: "state" [28884,28891]
===
match
---
name: DEFAULT_DATETIME_1 [11655,11673]
name: DEFAULT_DATETIME_1 [11659,11677]
===
match
---
string: "task_id" [42409,42418]
string: "task_id" [42413,42422]
===
match
---
atom [13443,13599]
atom [13447,13603]
===
match
---
decorator [22638,22870]
decorator [22642,22874]
===
match
---
parameters [37669,37700]
parameters [37673,37704]
===
match
---
atom_expr [33373,33538]
atom_expr [33377,33542]
===
match
---
name: self [21008,21012]
name: self [21012,21016]
===
match
---
dictorsetmaker [29585,29692]
dictorsetmaker [29589,29696]
===
match
---
atom [30815,30970]
atom [30819,30974]
===
match
---
name: response [39911,39919]
name: response [39915,39923]
===
match
---
name: RUNNING [32505,32512]
name: RUNNING [32509,32516]
===
match
---
operator: , [6830,6831]
operator: , [6850,6851]
===
match
---
string: "new_state" [42215,42226]
string: "new_state" [42219,42230]
===
match
---
string: "clear start date filter" [25275,25300]
string: "clear start date filter" [25279,25304]
===
match
---
operator: , [31510,31511]
operator: , [31514,31515]
===
match
---
operator: + [2619,2620]
operator: + [2647,2648]
===
match
---
atom [10475,10532]
atom [10479,10536]
===
match
---
operator: , [28141,28142]
operator: , [28145,28146]
===
match
---
operator: , [39182,39183]
operator: , [39186,39187]
===
match
---
string: 'execution_date' [33885,33901]
string: 'execution_date' [33889,33905]
===
match
---
name: permissions [1722,1733]
name: permissions [1750,1761]
===
match
---
atom_expr [18881,18901]
atom_expr [18885,18905]
===
match
---
expr_stmt [2323,2361]
expr_stmt [2351,2389]
===
match
---
string: 'task_id' [34192,34201]
string: 'task_id' [34196,34205]
===
match
---
name: dt [19421,19423]
name: dt [19425,19427]
===
match
---
operator: @ [22638,22639]
operator: @ [22642,22643]
===
match
---
name: DEFAULT_DATETIME_1 [27328,27346]
name: DEFAULT_DATETIME_1 [27332,27350]
===
match
---
atom_expr [3779,3819]
atom_expr [3807,3847]
===
match
---
param [9298,9302]
param [9302,9306]
===
match
---
dotted_name [1065,1084]
dotted_name [1093,1112]
===
match
---
operator: , [18247,18248]
operator: , [18251,18252]
===
match
---
name: SlaMiss [7368,7375]
name: SlaMiss [7380,7387]
===
match
---
simple_stmt [35575,35596]
simple_stmt [35579,35600]
===
match
---
argument [6094,6135]
argument [6114,6155]
===
match
---
expr_stmt [39911,40468]
expr_stmt [39915,40472]
===
match
---
operator: , [37690,37691]
operator: , [37694,37695]
===
match
---
comparison [6381,6408]
comparison [6401,6428]
===
match
---
param [42918,42923]
param [42922,42927]
===
match
---
assert_stmt [31998,32032]
assert_stmt [32002,32036]
===
match
---
operator: , [31309,31310]
operator: , [31313,31314]
===
match
---
name: update_extras [15738,15751]
name: update_extras [15742,15755]
===
match
---
dotted_name [909,923]
dotted_name [894,908]
===
match
---
operator: = [23229,23230]
operator: = [23233,23234]
===
match
---
operator: } [33425,33426]
operator: } [33429,33430]
===
match
---
string: "test pool filter" [17673,17691]
string: "test pool filter" [17677,17695]
===
match
---
param [36627,36634]
param [36631,36638]
===
match
---
operator: } [20082,20083]
operator: } [20086,20087]
===
match
---
string: "state" [8874,8881]
string: "state" [8886,8893]
===
match
---
testlist_comp [14330,14651]
testlist_comp [14334,14655]
===
match
---
decorated [21379,22633]
decorated [21383,22637]
===
match
---
atom [24218,24298]
atom [24222,24302]
===
match
---
atom [33566,33677]
atom [33570,33681]
===
match
---
funcdef [35174,35596]
funcdef [35178,35600]
===
match
---
string: "end_date" [2589,2599]
string: "end_date" [2617,2627]
===
match
---
assert_stmt [37436,37478]
assert_stmt [37440,37482]
===
match
---
string: "state" [36847,36854]
string: "state" [36851,36858]
===
match
---
atom_expr [40583,41102]
atom_expr [40587,41106]
===
match
---
name: dt [32730,32732]
name: dt [32734,32736]
===
match
---
trailer [18970,18978]
trailer [18974,18982]
===
match
---
atom [25878,26033]
atom [25882,26037]
===
match
---
operator: , [14350,14351]
operator: , [14354,14355]
===
match
---
trailer [7650,7824]
trailer [7662,7836]
===
match
---
trailer [23067,23103]
trailer [23071,23107]
===
match
---
name: post [39934,39938]
name: post [39938,39942]
===
match
---
atom [38080,38433]
atom [38084,38437]
===
match
---
operator: + [9943,9944]
operator: + [9947,9948]
===
match
---
atom [10926,11159]
atom [10930,11163]
===
match
---
atom_expr [38503,38516]
atom_expr [38507,38520]
===
match
---
name: datetime [1133,1141]
name: datetime [1161,1169]
===
match
---
operator: + [28655,28656]
operator: + [28659,28660]
===
match
---
name: expand [41808,41814]
name: expand [41812,41818]
===
match
---
string: 'TEST_DAG_RUN_ID_3' [34568,34587]
string: 'TEST_DAG_RUN_ID_3' [34572,34591]
===
match
---
fstring_string: = [12445,12446]
fstring_string: = [12449,12450]
===
match
---
string: "default_pool" [2718,2732]
string: "default_pool" [2746,2760]
===
match
---
trailer [28085,28093]
trailer [28089,28097]
===
match
---
trailer [4272,4280]
trailer [4300,4308]
===
match
---
atom [10318,10551]
atom [10322,10555]
===
match
---
operator: { [28946,28947]
operator: { [28950,28951]
===
match
---
operator: , [9008,9009]
operator: , [9012,9013]
===
match
---
dotted_name [41794,41814]
dotted_name [41798,41818]
===
match
---
dictorsetmaker [13925,13946]
dictorsetmaker [13929,13950]
===
match
---
atom_expr [2030,2109]
atom_expr [2058,2137]
===
match
---
import_as_names [931,968]
import_as_names [916,953]
===
match
---
name: DEFAULT_DATETIME_1 [12115,12133]
name: DEFAULT_DATETIME_1 [12119,12137]
===
match
---
string: '2020-11-10T12:42:39.442973' [36164,36192]
string: '2020-11-10T12:42:39.442973' [36168,36196]
===
match
---
number: 2 [18337,18338]
number: 2 [18341,18342]
===
match
---
atom [30992,31147]
atom [30996,31151]
===
match
---
operator: } [7812,7813]
operator: } [7824,7825]
===
match
---
operator: = [31602,31603]
operator: = [31606,31607]
===
match
---
atom_expr [33700,33720]
atom_expr [33704,33724]
===
match
---
string: "execution_date" [25669,25685]
string: "execution_date" [25673,25689]
===
match
---
atom_expr [1594,2025]
atom_expr [1622,2053]
===
match
---
name: response [33700,33708]
name: response [33704,33712]
===
match
---
operator: = [1652,1653]
operator: = [1680,1681]
===
match
---
name: role_name [1669,1678]
name: role_name [1697,1706]
===
match
---
operator: , [24557,24558]
operator: , [24561,24562]
===
match
---
operator: = [7436,7437]
operator: = [7448,7449]
===
match
---
string: "include_past" [42660,42674]
string: "include_past" [42664,42678]
===
match
---
trailer [21283,21300]
trailer [21287,21304]
===
match
---
string: "state" [26399,26406]
string: "state" [26403,26410]
===
match
---
name: response [22529,22537]
name: response [22533,22541]
===
match
---
operator: , [27599,27600]
operator: , [27603,27604]
===
match
---
name: permissions [1972,1983]
name: permissions [2000,2011]
===
match
---
expr_stmt [38852,38906]
expr_stmt [38856,38910]
===
match
---
trailer [9109,9227]
trailer [9113,9231]
===
match
---
name: timedelta [36812,36821]
name: timedelta [36816,36825]
===
match
---
name: DEFAULT_DATETIME_STR_1 [12447,12469]
name: DEFAULT_DATETIME_STR_1 [12451,12473]
===
match
---
comparison [23349,23400]
comparison [23353,23404]
===
match
---
atom_expr [31535,31732]
atom_expr [31539,31736]
===
match
---
operator: = [43014,43015]
operator: = [43018,43019]
===
match
---
name: dag [3503,3506]
name: dag [3531,3534]
===
match
---
atom [22669,22862]
atom [22673,22866]
===
match
---
atom_expr [3341,3354]
atom_expr [3369,3382]
===
match
---
name: assert_401 [16873,16883]
name: assert_401 [16877,16887]
===
match
---
operator: } [32512,32513]
operator: } [32516,32517]
===
match
---
atom_expr [21270,21300]
atom_expr [21274,21304]
===
match
---
operator: , [35499,35500]
operator: , [35503,35504]
===
match
---
argument [39456,39814]
argument [39460,39818]
===
match
---
param [21848,21856]
param [21852,21860]
===
match
---
argument [20075,20081]
argument [20079,20085]
===
match
---
trailer [27908,27916]
trailer [27912,27920]
===
match
---
string: "execution_date" [27132,27148]
string: "execution_date" [27136,27152]
===
match
---
fstring_expr [11300,11324]
fstring_expr [11304,11328]
===
match
---
atom_expr [18100,18113]
atom_expr [18104,18117]
===
match
---
param [22944,22946]
param [22948,22950]
===
match
---
atom [26700,26853]
atom [26704,26857]
===
match
---
operator: = [33039,33040]
operator: = [33043,33044]
===
match
---
operator: , [38379,38380]
operator: , [38383,38384]
===
match
---
trailer [7195,7197]
trailer [7207,7209]
===
match
---
dictorsetmaker [11512,11542]
dictorsetmaker [11516,11546]
===
match
---
operator: , [5595,5596]
operator: , [5623,5624]
===
match
---
atom [21410,21698]
atom [21414,21702]
===
match
---
simple_stmt [41111,41146]
simple_stmt [41115,41150]
===
match
---
dictorsetmaker [18182,18204]
dictorsetmaker [18186,18208]
===
match
---
trailer [1366,1378]
trailer [1394,1406]
===
match
---
string: "try_number" [8950,8962]
string: "try_number" [8962,8974]
===
match
---
name: json [21279,21283]
name: json [21283,21287]
===
match
---
name: expected_ti_count [21857,21874]
name: expected_ti_count [21861,21878]
===
match
---
dictorsetmaker [27520,27579]
dictorsetmaker [27524,27583]
===
match
---
dictorsetmaker [13152,13167]
dictorsetmaker [13156,13171]
===
match
---
string: 'task_instances' [38534,38550]
string: 'task_instances' [38538,38554]
===
match
---
operator: = [28851,28852]
operator: = [28855,28856]
===
match
---
string: "execution_date" [30841,30857]
string: "execution_date" [30845,30861]
===
match
---
string: "pool_slots" [6844,6856]
string: "pool_slots" [6864,6876]
===
match
---
atom [23230,23253]
atom [23234,23257]
===
match
---
name: utils [1111,1116]
name: utils [1139,1144]
===
match
---
atom_expr [3051,3104]
atom_expr [3079,3132]
===
match
---
parameters [36601,36635]
parameters [36605,36639]
===
match
---
string: "state" [28548,28555]
string: "state" [28552,28559]
===
match
---
decorated [41793,43296]
decorated [41797,43300]
===
match
---
classdef [9573,17177]
classdef [9577,17181]
===
match
---
dictorsetmaker [17822,17843]
dictorsetmaker [17826,17847]
===
match
---
operator: , [8936,8937]
operator: , [8948,8949]
===
match
---
name: expected_ti_count [22508,22525]
name: expected_ti_count [22512,22529]
===
match
---
testlist_comp [28509,29102]
testlist_comp [28513,29106]
===
match
---
dictorsetmaker [21509,21525]
dictorsetmaker [21513,21529]
===
match
---
simple_stmt [3453,3487]
simple_stmt [3481,3515]
===
match
---
fstring [11297,11365]
fstring [11301,11369]
===
match
---
name: post [33385,33389]
name: post [33389,33393]
===
match
---
string: 'TEST_DAG_RUN_ID_2' [34330,34349]
string: 'TEST_DAG_RUN_ID_2' [34334,34353]
===
match
---
operator: { [18924,18925]
operator: { [18928,18929]
===
match
---
name: self [31442,31446]
name: self [31446,31450]
===
match
---
argument [31966,31978]
argument [31970,31982]
===
match
---
operator: , [26242,26243]
operator: , [26246,26247]
===
match
---
operator: , [27084,27085]
operator: , [27088,27089]
===
match
---
string: "failed" [33625,33633]
string: "failed" [33629,33637]
===
match
---
param [42924,42932]
param [42928,42936]
===
match
---
dotted_name [1190,1226]
dotted_name [1218,1254]
===
match
---
simple_stmt [7569,7591]
simple_stmt [7581,7603]
===
match
---
operator: = [33220,33221]
operator: = [33224,33225]
===
match
---
simple_stmt [38994,39275]
simple_stmt [38998,39279]
===
match
---
string: "total_entries" [15961,15976]
string: "total_entries" [15965,15980]
===
match
---
name: test_should_respond_200 [4838,4861]
name: test_should_respond_200 [4866,4889]
===
match
---
name: include_examples [3058,3074]
name: include_examples [3086,3102]
===
match
---
operator: , [17324,17325]
operator: , [17328,17329]
===
match
---
atom_expr [23123,23290]
atom_expr [23127,23294]
===
match
---
number: 2 [28359,28360]
number: 2 [28363,28364]
===
match
---
string: "test pool filter ~" [14330,14350]
string: "test pool filter ~" [14334,14354]
===
match
---
testlist_comp [17935,17963]
testlist_comp [17939,17967]
===
match
---
decorator [42844,42861]
decorator [42848,42865]
===
match
---
funcdef [4834,5974]
funcdef [4862,5994]
===
match
---
name: payload [36608,36615]
name: payload [36612,36619]
===
match
---
arglist [6205,6355]
arglist [6225,6375]
===
match
---
operator: , [17589,17590]
operator: , [17593,17594]
===
match
---
name: task_instances [22179,22193]
name: task_instances [22183,22197]
===
match
---
atom [21548,21566]
atom [21552,21570]
===
match
---
operator: , [38341,38342]
operator: , [38345,38346]
===
match
---
name: response [24046,24054]
name: response [24050,24058]
===
match
---
simple_stmt [4930,5131]
simple_stmt [4958,5159]
===
match
---
trailer [4656,4663]
trailer [4684,4691]
===
match
---
operator: , [34692,34693]
operator: , [34696,34697]
===
match
---
operator: , [38680,38681]
operator: , [38684,38685]
===
match
---
operator: , [13622,13623]
operator: , [13626,13627]
===
match
---
name: client [24889,24895]
name: client [24893,24899]
===
match
---
operator: , [32295,32296]
operator: , [32299,32300]
===
match
---
name: ti_init [4273,4280]
name: ti_init [4301,4308]
===
match
---
atom_expr [41118,41138]
atom_expr [41122,41142]
===
match
---
atom [32527,32659]
atom [32531,32663]
===
match
---
trailer [23001,23023]
trailer [23005,23027]
===
match
---
name: dt [10432,10434]
name: dt [10436,10438]
===
match
---
simple_stmt [9236,9257]
simple_stmt [9240,9261]
===
match
---
operator: , [5559,5560]
operator: , [5587,5588]
===
match
---
trailer [4436,4440]
trailer [4464,4468]
===
match
---
simple_stmt [42961,42997]
simple_stmt [42965,43001]
===
match
---
operator: , [15591,15592]
operator: , [15595,15596]
===
match
---
name: get [16774,16777]
name: get [16778,16781]
===
match
---
name: response [17149,17157]
name: response [17153,17161]
===
match
---
fstring_start: f" [10710,10712]
fstring_start: f" [10714,10716]
===
match
---
operator: , [33446,33447]
operator: , [33450,33451]
===
match
---
operator: , [36460,36461]
operator: , [36464,36465]
===
match
---
atom [23902,23940]
atom [23906,23944]
===
match
---
operator: , [39236,39237]
operator: , [39240,39241]
===
match
---
simple_stmt [3521,3542]
simple_stmt [3549,3570]
===
match
---
operator: { [28769,28770]
operator: { [28773,28774]
===
match
---
simple_stmt [31998,32033]
simple_stmt [32002,32037]
===
match
---
operator: @ [41793,41794]
operator: @ [41797,41798]
===
match
---
name: days [2634,2638]
name: days [2662,2666]
===
match
---
name: get_dag [3471,3478]
name: get_dag [3499,3506]
===
match
---
name: expected_response [34986,35003]
name: expected_response [34990,35007]
===
match
---
name: get [16973,16976]
name: get [16977,16980]
===
match
---
arith_expr [2535,2575]
arith_expr [2563,2603]
===
match
---
atom [38038,38061]
atom [38042,38065]
===
match
---
string: "include_downstream" [39656,39676]
string: "include_downstream" [39660,39680]
===
match
---
atom [10591,10811]
atom [10595,10815]
===
match
---
name: RUNNING [32637,32644]
name: RUNNING [32641,32648]
===
match
---
trailer [21920,22060]
trailer [21924,22064]
===
match
---
trailer [12269,12279]
trailer [12273,12283]
===
match
---
operator: = [2383,2384]
operator: = [2411,2412]
===
match
---
trailer [18151,18158]
trailer [18155,18162]
===
match
---
operator: , [32259,32260]
operator: , [32263,32264]
===
match
---
atom_expr [3503,3512]
atom_expr [3531,3540]
===
match
---
operator: { [33418,33419]
operator: { [33422,33423]
===
match
---
name: json [38512,38516]
name: json [38516,38520]
===
match
---
trailer [38874,38879]
trailer [38878,38883]
===
match
---
name: response [41760,41768]
name: response [41764,41772]
===
match
---
name: environ_overrides [22356,22373]
name: environ_overrides [22360,22377]
===
match
---
operator: = [37365,37366]
operator: = [37369,37370]
===
match
---
string: "execution_date" [8595,8611]
string: "execution_date" [8607,8623]
===
match
---
operator: , [28854,28855]
operator: , [28858,28859]
===
match
---
operator: { [37324,37325]
operator: { [37328,37329]
===
match
---
operator: = [31715,31716]
operator: = [31719,31720]
===
match
---
testlist_comp [13048,13360]
testlist_comp [13052,13364]
===
match
---
string: "PythonOperator" [5519,5535]
string: "PythonOperator" [5547,5563]
===
match
---
operator: , [26620,26621]
operator: , [26624,26625]
===
match
---
number: 2 [27367,27368]
number: 2 [27371,27372]
===
match
---
operator: , [29891,29892]
operator: , [29895,29896]
===
match
---
atom [30427,31362]
atom [30431,31366]
===
match
---
name: json [16605,16609]
name: json [16609,16613]
===
match
---
number: 200 [5170,5173]
number: 200 [5198,5201]
===
match
---
number: 2 [10529,10530]
number: 2 [10533,10534]
===
match
---
operator: } [38817,38818]
operator: } [38821,38822]
===
match
---
arith_expr [27328,27369]
arith_expr [27332,27373]
===
match
---
name: response [16596,16604]
name: response [16600,16608]
===
match
---
string: 'REMOTE_USER' [9479,9492]
string: 'REMOTE_USER' [9483,9496]
===
match
---
atom [25383,25444]
atom [25387,25448]
===
match
---
operator: , [11402,11403]
operator: , [11406,11407]
===
match
---
name: response [41207,41215]
name: response [41211,41219]
===
match
---
operator: , [31264,31265]
operator: , [31268,31269]
===
match
---
name: session [21876,21883]
name: session [21880,21887]
===
match
---
string: "dry_run" [27520,27529]
string: "dry_run" [27524,27533]
===
match
---
operator: } [14502,14503]
operator: } [14506,14507]
===
match
---
operator: , [39542,39543]
operator: , [39546,39547]
===
match
---
atom [6109,6135]
atom [6129,6155]
===
match
---
trailer [15912,15924]
trailer [15916,15928]
===
match
---
string: "only_failed" [32309,32322]
string: "only_failed" [32313,32326]
===
match
---
operator: , [36829,36830]
operator: , [36833,36834]
===
match
---
name: State [18100,18105]
name: State [18104,18109]
===
match
---
operator: , [29218,29219]
operator: , [29222,29223]
===
match
---
atom [13190,13207]
atom [13194,13211]
===
match
---
name: dagbag [3042,3048]
name: dagbag [3070,3076]
===
match
---
name: REMOVED [6126,6133]
name: REMOVED [6146,6153]
===
match
---
operator: } [21565,21566]
operator: } [21569,21570]
===
match
---
string: "start_date_gte" [24410,24426]
string: "start_date_gte" [24414,24430]
===
match
---
assert_stmt [40477,40511]
assert_stmt [40481,40515]
===
match
---
atom_expr [27070,27083]
atom_expr [27074,27087]
===
match
---
string: "pool" [2710,2716]
string: "pool" [2738,2744]
===
match
---
expr_stmt [2370,2481]
expr_stmt [2398,2509]
===
match
---
operator: , [6523,6524]
operator: , [6543,6544]
===
match
---
name: task_instances [3686,3700]
name: task_instances [3714,3728]
===
match
---
trailer [40594,40599]
trailer [40598,40603]
===
match
---
trailer [23352,23385]
trailer [23356,23389]
===
match
---
trailer [33601,33608]
trailer [33605,33612]
===
match
---
name: dag_id [16215,16221]
name: dag_id [16219,16225]
===
match
---
simple_stmt [1060,1098]
simple_stmt [1088,1126]
===
match
---
funcdef [7214,9020]
funcdef [7226,9024]
===
match
---
name: timedelta [18884,18893]
name: timedelta [18888,18897]
===
match
---
atom_expr [26585,26597]
atom_expr [26589,26601]
===
match
---
name: session [33158,33165]
name: session [33162,33169]
===
match
---
dictorsetmaker [26314,26421]
dictorsetmaker [26318,26425]
===
match
---
trailer [35096,35129]
trailer [35100,35133]
===
match
---
operator: { [11004,11005]
operator: { [11008,11009]
===
match
---
name: update_extras [15724,15737]
name: update_extras [15728,15741]
===
match
---
operator: , [4706,4707]
operator: , [4734,4735]
===
match
---
name: range [3655,3660]
name: range [3683,3688]
===
match
---
name: FAILED [26259,26265]
name: FAILED [26263,26269]
===
match
---
name: app [38863,38866]
name: app [38867,38870]
===
match
---
operator: , [13207,13208]
operator: , [13211,13212]
===
match
---
name: TestGetTaskInstancesBatch [17185,17210]
name: TestGetTaskInstancesBatch [17189,17214]
===
match
---
trailer [33377,33384]
trailer [33381,33388]
===
match
---
string: "pool" [14481,14487]
string: "pool" [14485,14491]
===
match
---
name: self [23533,23537]
name: self [23537,23541]
===
match
---
operator: = [40695,40696]
operator: = [40699,40700]
===
match
---
name: status_code [7849,7860]
name: status_code [7861,7872]
===
match
---
simple_stmt [22568,22633]
simple_stmt [22572,22637]
===
match
---
operator: = [32227,32228]
operator: = [32231,32232]
===
match
---
operator: } [18158,18159]
operator: } [18162,18163]
===
match
---
trailer [39933,39938]
trailer [39937,39942]
===
match
---
name: dt [19500,19502]
name: dt [19504,19506]
===
match
---
trailer [16183,16205]
trailer [16187,16209]
===
match
---
operator: , [28677,28678]
operator: , [28681,28682]
===
match
---
fstring_end: " [4230,4231]
fstring_end: " [4258,4259]
===
match
---
param [36608,36616]
param [36612,36620]
===
match
---
trailer [11688,11696]
trailer [11692,11700]
===
match
---
name: DEFAULT_DATETIME_1 [12246,12264]
name: DEFAULT_DATETIME_1 [12250,12268]
===
match
---
operator: @ [24712,24713]
operator: @ [24716,24717]
===
match
---
atom_expr [16008,16044]
atom_expr [16012,16048]
===
match
---
decorators [21379,21727]
decorators [21383,21731]
===
match
---
name: DEFAULT_DATETIME_1 [28636,28654]
name: DEFAULT_DATETIME_1 [28640,28658]
===
match
---
operator: , [33226,33227]
operator: , [33230,33231]
===
match
---
dotted_name [25213,25233]
dotted_name [25217,25237]
===
match
---
trailer [37768,37781]
trailer [37772,37785]
===
match
---
name: ti [4033,4035]
name: ti [4061,4063]
===
match
---
comparison [4093,4116]
comparison [4121,4144]
===
match
---
operator: , [30793,30794]
operator: , [30797,30798]
===
match
---
name: FAILED [25437,25443]
name: FAILED [25441,25447]
===
match
---
dictorsetmaker [14436,14457]
dictorsetmaker [14440,14461]
===
match
---
parameters [1537,1558]
parameters [1565,1586]
===
match
---
yield_expr [2131,2140]
yield_expr [2159,2168]
===
match
---
operator: = [39229,39230]
operator: = [39233,39234]
===
match
---
operator: , [39799,39800]
operator: , [39803,39804]
===
match
---
name: configured_app [2290,2304]
name: configured_app [2318,2332]
===
match
---
comparison [16514,16562]
comparison [16518,16566]
===
match
---
operator: = [22221,22222]
operator: = [22225,22226]
===
match
---
trailer [41234,41744]
trailer [41238,41748]
===
match
---
string: "print_the_context" [5871,5890]
string: "print_the_context" [5899,5918]
===
match
---
operator: , [41718,41719]
operator: , [41722,41723]
===
match
---
atom_expr [35097,35128]
atom_expr [35101,35132]
===
match
---
string: "operator" [8202,8212]
string: "operator" [8214,8224]
===
match
---
name: json [33515,33519]
name: json [33519,33523]
===
match
---
atom_expr [37798,37883]
atom_expr [37802,37887]
===
match
---
string: "REMOTE_USER" [7791,7804]
string: "REMOTE_USER" [7803,7816]
===
match
---
operator: @ [36105,36106]
operator: @ [36109,36110]
===
match
---
name: self [39323,39327]
name: self [39327,39331]
===
match
---
name: dt [25708,25710]
name: dt [25712,25714]
===
match
---
operator: = [30172,30173]
operator: = [30176,30177]
===
match
---
argument [27184,27190]
argument [27188,27194]
===
match
---
operator: , [31952,31953]
operator: , [31956,31957]
===
match
---
operator: , [14264,14265]
operator: , [14268,14269]
===
match
---
operator: , [8188,8189]
operator: , [8200,8201]
===
match
---
atom [19247,19779]
atom [19251,19783]
===
match
---
simple_stmt [25060,25095]
simple_stmt [25064,25099]
===
match
---
operator: , [17965,17966]
operator: , [17969,17970]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances?duration_gte=100&duration_lte=200" [13266,13340]
string: "/api/v1/dags/~/dagRuns/~/taskInstances?duration_gte=100&duration_lte=200" [13270,13344]
===
match
---
name: self [40557,40561]
name: self [40561,40565]
===
match
---
operator: = [33371,33372]
operator: = [33375,33376]
===
match
---
tfpdef [3176,3187]
tfpdef [3204,3215]
===
match
---
name: post [23807,23811]
name: post [23811,23815]
===
match
---
atom [13969,13992]
atom [13973,13996]
===
match
---
string: "example_python_operator" [28444,28469]
string: "example_python_operator" [28448,28473]
===
match
---
operator: , [1659,1660]
operator: , [1687,1688]
===
match
---
simple_stmt [16580,16627]
simple_stmt [16584,16631]
===
match
---
atom_expr [2863,2885]
atom_expr [2891,2913]
===
match
---
decorator [22874,22891]
decorator [22878,22895]
===
match
---
operator: { [32229,32230]
operator: { [32233,32234]
===
match
---
atom [24124,24204]
atom [24128,24208]
===
match
---
operator: } [42741,42742]
operator: } [42745,42746]
===
match
---
operator: , [35989,35990]
operator: , [35993,35994]
===
match
---
name: FAILED [30039,30045]
name: FAILED [30043,30049]
===
match
---
string: 'sleep_for_1' [34441,34454]
string: 'sleep_for_1' [34445,34458]
===
match
---
number: 200 [12746,12749]
number: 200 [12750,12753]
===
match
---
operator: , [4298,4299]
operator: , [4326,4327]
===
match
---
operator: , [4619,4620]
operator: , [4647,4648]
===
match
---
operator: , [34707,34708]
operator: , [34711,34712]
===
match
---
trailer [37832,37877]
trailer [37836,37881]
===
match
---
name: test_should_raises_401_unauthenticated [16697,16735]
name: test_should_raises_401_unauthenticated [16701,16739]
===
match
---
import_from [822,847]
import_from [807,832]
===
match
---
atom_expr [20145,20165]
atom_expr [20149,20169]
===
match
---
simple_stmt [2933,2953]
simple_stmt [2961,2981]
===
match
---
dictorsetmaker [28795,28902]
dictorsetmaker [28799,28906]
===
match
---
name: State [30210,30215]
name: State [30214,30219]
===
match
---
atom_expr [10432,10452]
atom_expr [10436,10456]
===
match
---
argument [23884,23940]
argument [23888,23944]
===
match
---
string: "include_subdags" [32377,32394]
string: "include_subdags" [32381,32398]
===
match
---
funcdef [36549,37479]
funcdef [36553,37483]
===
match
---
operator: , [27809,27810]
operator: , [27813,27814]
===
match
---
name: ACTION_CAN_READ [1803,1818]
name: ACTION_CAN_READ [1831,1846]
===
match
---
atom [19329,19363]
atom [19333,19367]
===
match
---
name: dag [38951,38954]
name: dag [38955,38958]
===
match
---
name: create_task_instances [42966,42987]
name: create_task_instances [42970,42991]
===
match
---
dictorsetmaker [31018,31125]
dictorsetmaker [31022,31129]
===
match
---
arith_expr [31036,31077]
arith_expr [31040,31081]
===
match
---
atom_expr [2490,2504]
atom_expr [2518,2532]
===
match
---
operator: , [3626,3627]
operator: , [3654,3655]
===
match
---
operator: , [40457,40458]
operator: , [40461,40462]
===
match
---
operator: , [18583,18584]
operator: , [18587,18588]
===
match
---
operator: == [23386,23388]
operator: == [23390,23392]
===
match
---
operator: , [37373,37374]
operator: , [37377,37378]
===
match
---
operator: = [38037,38038]
operator: = [38041,38042]
===
match
---
operator: , [41945,41946]
operator: , [41949,41950]
===
match
---
operator: , [29691,29692]
operator: , [29695,29696]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/" [12831,12894]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/" [12835,12898]
===
match
---
atom_expr [5146,5166]
atom_expr [5174,5194]
===
match
---
name: TestTaskInstanceEndpoint [9600,9624]
name: TestTaskInstanceEndpoint [9604,9628]
===
match
---
operator: { [13924,13925]
operator: { [13928,13929]
===
match
---
operator: { [34483,34484]
operator: { [34487,34488]
===
match
---
assert_stmt [16428,16462]
assert_stmt [16432,16466]
===
match
---
number: 2 [11990,11991]
number: 2 [11994,11995]
===
match
---
operator: } [28163,28164]
operator: } [28167,28168]
===
match
---
string: "include_upstream" [40257,40275]
string: "include_upstream" [40261,40279]
===
match
---
name: ti [4073,4075]
name: ti [4101,4103]
===
match
---
atom [21637,21652]
atom [21641,21656]
===
match
---
operator: + [11038,11039]
operator: + [11042,11043]
===
match
---
name: self [16961,16965]
name: self [16965,16969]
===
match
---
number: 1 [10228,10229]
number: 1 [10232,10233]
===
match
---
name: fixture [2242,2249]
name: fixture [2270,2277]
===
match
---
operator: , [42723,42724]
operator: , [42727,42728]
===
match
---
name: len [3607,3610]
name: len [3635,3638]
===
match
---
name: provide_session [22875,22890]
name: provide_session [22879,22894]
===
match
---
string: "include_past" [41017,41031]
string: "include_past" [41021,41035]
===
match
---
string: "example_skip_dag" [16222,16240]
string: "example_skip_dag" [16226,16244]
===
match
---
operator: = [3908,3909]
operator: = [3936,3937]
===
match
---
string: "queued_when" [8405,8418]
string: "queued_when" [8417,8430]
===
match
---
string: "state" [27061,27068]
string: "state" [27065,27072]
===
match
---
name: DEFAULT_DATETIME_1 [10490,10508]
name: DEFAULT_DATETIME_1 [10494,10512]
===
match
---
strings [14118,14246]
strings [14122,14250]
===
match
---
name: assert_401 [39834,39844]
name: assert_401 [39838,39848]
===
match
---
name: status_code [41127,41138]
name: status_code [41131,41142]
===
match
---
trailer [16654,16687]
trailer [16658,16691]
===
match
---
testlist_comp [24313,24393]
testlist_comp [24317,24397]
===
match
---
string: "print_the_context" [42420,42439]
string: "print_the_context" [42424,42443]
===
match
---
operator: , [32644,32645]
operator: , [32648,32649]
===
match
---
name: ti_init [3859,3866]
name: ti_init [3887,3894]
===
match
---
trailer [6187,6191]
trailer [6207,6211]
===
match
---
operator: , [42303,42304]
operator: , [42307,42308]
===
match
---
name: DEFAULT_DATETIME_1 [40855,40873]
name: DEFAULT_DATETIME_1 [40859,40877]
===
match
---
string: "start_date_gte" [19624,19640]
string: "start_date_gte" [19628,19644]
===
match
---
operator: , [30462,30463]
operator: , [30466,30467]
===
match
---
name: State [30033,30038]
name: State [30037,30042]
===
match
---
simple_stmt [9536,9571]
simple_stmt [9540,9575]
===
match
---
atom [23959,24019]
atom [23963,24023]
===
match
---
string: "print_the_context" [41926,41945]
string: "print_the_context" [41930,41949]
===
match
---
name: MANUAL [4657,4663]
name: MANUAL [4685,4691]
===
match
---
string: "include_downstream" [42081,42101]
string: "include_downstream" [42085,42105]
===
match
---
simple_stmt [22069,22248]
simple_stmt [22073,22252]
===
match
---
name: State [33069,33074]
name: State [33073,33078]
===
match
---
string: 'example_python_operator' [34273,34298]
string: 'example_python_operator' [34277,34302]
===
match
---
operator: , [5696,5697]
operator: , [5724,5725]
===
match
---
string: 'sleep_for_2' [34679,34692]
string: 'sleep_for_2' [34683,34696]
===
match
---
name: sync_to_db [3016,3026]
name: sync_to_db [3044,3054]
===
match
---
trailer [23366,23384]
trailer [23370,23388]
===
match
---
decorator [24712,24729]
decorator [24716,24733]
===
match
---
dictorsetmaker [12103,12133]
dictorsetmaker [12107,12137]
===
match
---
name: expected_ti [32088,32099]
name: expected_ti [32092,32103]
===
match
---
atom [1863,1928]
atom [1891,1956]
===
match
---
fstring_start: f" [11876,11878]
fstring_start: f" [11880,11882]
===
match
---
name: timedelta [32587,32596]
name: timedelta [32591,32600]
===
match
---
assert_stmt [9536,9570]
assert_stmt [9540,9574]
===
match
---
trailer [2867,2871]
trailer [2895,2899]
===
match
---
operator: } [10531,10532]
operator: } [10535,10536]
===
match
---
string: "execution_date" [29762,29778]
string: "execution_date" [29766,29782]
===
match
---
arith_expr [20521,20562]
arith_expr [20525,20566]
===
match
---
name: DEFAULT_DATETIME_1 [32709,32727]
name: DEFAULT_DATETIME_1 [32713,32731]
===
match
---
operator: , [11061,11062]
operator: , [11065,11066]
===
match
---
number: 2 [12545,12546]
number: 2 [12549,12550]
===
match
---
operator: , [29868,29869]
operator: , [29872,29873]
===
match
---
atom_expr [33609,33621]
atom_expr [33613,33625]
===
match
---
name: days [29991,29995]
name: days [29995,29999]
===
match
---
operator: , [33192,33193]
operator: , [33196,33197]
===
match
---
number: 0 [5492,5493]
number: 0 [5520,5521]
===
match
---
string: "notification_sent" [8658,8677]
string: "notification_sent" [8670,8689]
===
match
---
trailer [29071,29078]
trailer [29075,29082]
===
match
---
name: self [24884,24888]
name: self [24888,24892]
===
match
---
name: timezone [1117,1125]
name: timezone [1145,1153]
===
match
---
name: execution_date [39101,39115]
name: execution_date [39105,39119]
===
match
---
trailer [35247,35254]
trailer [35251,35258]
===
match
---
name: test_should_raises_401_unauthenticated [9029,9067]
name: test_should_raises_401_unauthenticated [9033,9071]
===
match
---
testlist_comp [33763,34946]
testlist_comp [33767,34950]
===
match
---
operator: , [2434,2435]
operator: , [2462,2463]
===
match
---
simple_stmt [16179,16242]
simple_stmt [16183,16246]
===
match
---
param [39323,39327]
param [39327,39331]
===
match
---
operator: , [42059,42060]
operator: , [42063,42064]
===
match
---
operator: = [15737,15738]
operator: = [15741,15742]
===
match
---
string: "task_id" [41436,41445]
string: "task_id" [41440,41449]
===
match
---
name: get [4953,4956]
name: get [4981,4984]
===
match
---
atom [37784,37893]
atom [37788,37897]
===
match
---
string: "start_date" [10476,10488]
string: "start_date" [10480,10492]
===
match
---
expr_stmt [1379,1431]
expr_stmt [1407,1459]
===
match
---
argument [29991,29997]
argument [29995,30001]
===
match
---
operator: , [6964,6965]
operator: , [6984,6985]
===
match
---
operator: , [5437,5438]
operator: , [5465,5466]
===
match
---
operator: } [18463,18464]
operator: } [18467,18468]
===
match
---
name: self [39349,39353]
name: self [39353,39357]
===
match
---
arglist [16990,17123]
arglist [16994,17127]
===
match
---
operator: , [13374,13375]
operator: , [13378,13379]
===
match
---
trailer [7646,7650]
trailer [7658,7662]
===
match
---
number: 3 [18683,18684]
number: 3 [18687,18688]
===
match
---
atom_expr [27896,27916]
atom_expr [27900,27920]
===
match
---
name: counter [3593,3600]
name: counter [3621,3628]
===
match
---
decorated [17242,21374]
decorated [17246,21378]
===
match
---
atom [19879,19917]
atom [19883,19921]
===
match
---
name: session [7599,7606]
name: session [7611,7618]
===
match
---
name: json [39456,39460]
name: json [39460,39464]
===
match
---
string: "default_pool" [5581,5595]
string: "default_pool" [5609,5623]
===
match
---
name: ACTION_CAN_READ [1734,1749]
name: ACTION_CAN_READ [1762,1777]
===
match
---
number: 0 [2794,2795]
number: 0 [2822,2823]
===
match
---
operator: , [13248,13249]
operator: , [13252,13253]
===
match
---
import_from [863,902]
import_from [848,887]
===
match
---
operator: { [18486,18487]
operator: { [18490,18491]
===
match
---
trailer [22542,22559]
trailer [22546,22563]
===
match
---
name: State [32499,32504]
name: State [32503,32508]
===
match
---
name: session [7271,7278]
name: session [7283,7290]
===
match
---
operator: , [15257,15258]
operator: , [15261,15262]
===
match
---
string: "example_skip_dag" [23667,23685]
string: "example_skip_dag" [23671,23689]
===
match
---
operator: , [24657,24658]
operator: , [24661,24662]
===
match
---
testlist_comp [17731,17845]
testlist_comp [17735,17849]
===
match
---
number: 200 [21215,21218]
number: 200 [21219,21222]
===
match
---
testlist_comp [22749,22794]
testlist_comp [22753,22798]
===
match
---
operator: = [1402,1403]
operator: = [1430,1431]
===
match
---
name: timedelta [26356,26365]
name: timedelta [26360,26369]
===
match
---
name: sync_to_db [31758,31768]
name: sync_to_db [31762,31772]
===
match
---
dictorsetmaker [27023,27083]
dictorsetmaker [27027,27087]
===
match
---
name: DEFAULT_DATETIME_1 [11524,11542]
name: DEFAULT_DATETIME_1 [11528,11546]
===
match
---
fstring_expr [12446,12470]
fstring_expr [12450,12474]
===
match
---
assert_stmt [23299,23333]
assert_stmt [23303,23337]
===
match
---
operator: , [38006,38007]
operator: , [38010,38011]
===
match
---
trailer [11601,11611]
trailer [11605,11615]
===
match
---
operator: , [31611,31612]
operator: , [31615,31616]
===
match
---
name: State [25586,25591]
name: State [25590,25595]
===
match
---
operator: @ [9631,9632]
operator: @ [9635,9636]
===
match
---
operator: } [15350,15351]
operator: } [15354,15355]
===
match
---
operator: , [34650,34651]
operator: , [34654,34655]
===
match
---
operator: } [30378,30379]
operator: } [30382,30383]
===
match
---
trailer [16276,16418]
trailer [16280,16422]
===
match
---
name: json [43178,43182]
name: json [43182,43186]
===
match
---
operator: , [40365,40366]
operator: , [40369,40370]
===
match
---
name: DEFAULT_DATETIME_STR_2 [1432,1454]
name: DEFAULT_DATETIME_STR_2 [1460,1482]
===
match
---
number: 404 [41142,41145]
number: 404 [41146,41149]
===
match
---
name: db [1293,1295]
name: db [1321,1323]
===
match
---
string: "state" [36715,36722]
string: "state" [36719,36726]
===
match
---
name: test_should_raise_400_for_naive_and_bad_datetime [42869,42917]
name: test_should_raise_400_for_naive_and_bad_datetime [42873,42921]
===
match
---
decorated [22638,23459]
decorated [22642,23463]
===
match
---
name: TaskInstance [37833,37845]
name: TaskInstance [37837,37849]
===
match
---
name: dag_id [32176,32182]
name: dag_id [32180,32186]
===
match
---
operator: = [39201,39202]
operator: = [39205,39206]
===
match
---
name: session [20780,20787]
name: session [20784,20791]
===
match
---
dictorsetmaker [27857,27964]
dictorsetmaker [27861,27968]
===
match
---
comparison [24046,24073]
comparison [24050,24077]
===
match
---
name: State [30935,30940]
name: State [30939,30944]
===
match
---
trailer [19423,19433]
trailer [19427,19437]
===
match
---
trailer [3922,3953]
trailer [3950,3981]
===
match
---
name: payload [25033,25040]
name: payload [25037,25044]
===
match
---
comparison [37833,37876]
comparison [37837,37880]
===
match
---
name: DEFAULT_DATETIME_STR_1 [11892,11914]
name: DEFAULT_DATETIME_STR_1 [11896,11918]
===
match
---
dictorsetmaker [36677,36737]
dictorsetmaker [36681,36741]
===
match
---
name: self [23507,23511]
name: self [23511,23515]
===
match
---
name: mock [843,847]
name: mock [828,832]
===
match
---
string: "failed" [41710,41718]
string: "failed" [41714,41722]
===
match
---
trailer [23045,23067]
trailer [23049,23071]
===
match
---
name: self [16762,16766]
name: self [16766,16770]
===
match
---
string: "example_python_operator" [22749,22774]
string: "example_python_operator" [22753,22778]
===
match
---
operator: , [1685,1686]
operator: , [1713,1714]
===
match
---
name: FAILED [25769,25775]
name: FAILED [25773,25779]
===
match
---
number: 400 [43241,43244]
number: 400 [43245,43248]
===
match
---
argument [29814,29820]
argument [29818,29824]
===
match
---
number: 403 [40508,40511]
number: 403 [40512,40515]
===
match
---
operator: , [2007,2008]
operator: , [2035,2036]
===
match
---
name: commit [7607,7613]
name: commit [7619,7625]
===
match
---
atom [23627,23687]
atom [23631,23691]
===
match
---
name: self [16179,16183]
name: self [16183,16187]
===
match
---
operator: { [32451,32452]
operator: { [32455,32456]
===
match
---
operator: , [31721,31722]
operator: , [31725,31726]
===
match
---
name: FAILED [28718,28724]
name: FAILED [28722,28728]
===
match
---
name: json [5198,5202]
name: json [5226,5230]
===
match
---
simple_stmt [7624,7825]
simple_stmt [7636,7837]
===
match
---
parameters [40556,40562]
parameters [40560,40566]
===
match
---
dictorsetmaker [11566,11619]
dictorsetmaker [11570,11623]
===
match
---
operator: , [26033,26034]
operator: , [26037,26038]
===
match
---
simple_stmt [23342,23401]
simple_stmt [23346,23405]
===
match
---
name: types [1161,1166]
name: types [1189,1194]
===
match
---
simple_stmt [4734,4750]
simple_stmt [4762,4778]
===
match
---
dictorsetmaker [13512,13533]
dictorsetmaker [13516,13537]
===
match
---
trailer [33593,33601]
trailer [33597,33605]
===
match
---
string: "default_queue" [8376,8391]
string: "default_queue" [8388,8403]
===
match
---
param [21807,21812]
param [21811,21816]
===
match
---
operator: + [29622,29623]
operator: + [29626,29627]
===
match
---
atom_expr [31112,31124]
atom_expr [31116,31128]
===
match
---
operator: , [15105,15106]
operator: , [15109,15110]
===
match
---
string: "print_the_context" [38142,38161]
string: "print_the_context" [38146,38165]
===
match
---
testlist_comp [11511,11698]
testlist_comp [11515,11702]
===
match
---
param [41192,41196]
param [41196,41200]
===
match
---
arglist [22109,22237]
arglist [22113,22241]
===
match
---
trailer [41229,41234]
trailer [41233,41238]
===
match
---
operator: { [34007,34008]
operator: { [34011,34012]
===
match
---
string: "queue" [14851,14858]
string: "queue" [14855,14862]
===
match
---
name: dt [804,806]
name: dt [804,806]
===
match
---
testlist_comp [17287,20617]
testlist_comp [17291,20621]
===
match
---
atom [32451,32513]
atom [32455,32517]
===
match
---
atom [24408,24490]
atom [24412,24494]
===
match
---
trailer [30608,30615]
trailer [30612,30619]
===
match
---
dictorsetmaker [11084,11139]
dictorsetmaker [11088,11143]
===
match
---
operator: = [3457,3458]
operator: = [3485,3486]
===
match
---
trailer [37929,38444]
trailer [37933,38448]
===
match
---
trailer [1762,1775]
trailer [1790,1803]
===
match
---
param [20736,20751]
param [20740,20755]
===
match
---
atom_expr [25431,25443]
atom_expr [25435,25447]
===
match
---
operator: { [17364,17365]
operator: { [17368,17369]
===
match
---
operator: + [28832,28833]
operator: + [28836,28837]
===
match
---
atom_expr [32048,32084]
atom_expr [32052,32088]
===
match
---
trailer [16139,16161]
trailer [16143,16165]
===
match
---
operator: , [13340,13341]
operator: , [13344,13345]
===
match
---
operator: , [31124,31125]
operator: , [31128,31129]
===
match
---
operator: , [29307,29308]
operator: , [29311,29312]
===
match
---
operator: = [3501,3502]
operator: = [3529,3530]
===
match
---
operator: = [24882,24883]
operator: = [24886,24887]
===
match
---
number: 0 [8187,8188]
number: 0 [8199,8200]
===
match
---
for_stmt [3646,4445]
for_stmt [3674,4473]
===
match
---
simple_stmt [21899,22061]
simple_stmt [21903,22065]
===
match
---
assert_stmt [5182,5973]
assert_stmt [5210,5993]
===
match
---
expr_stmt [1337,1378]
expr_stmt [1365,1406]
===
match
---
operator: { [28244,28245]
operator: { [28248,28249]
===
match
---
trailer [15955,15960]
trailer [15959,15964]
===
match
---
name: value [4664,4669]
name: value [4692,4697]
===
match
---
name: client [35248,35254]
name: client [35252,35258]
===
match
---
atom [15210,15370]
atom [15214,15374]
===
match
---
testlist_comp [14697,15125]
testlist_comp [14701,15129]
===
match
---
string: "dry_run" [28266,28275]
string: "dry_run" [28270,28279]
===
match
---
comparison [37400,37427]
comparison [37404,37431]
===
match
---
trailer [7293,7315]
trailer [7305,7327]
===
match
---
number: 1 [26371,26372]
number: 1 [26375,26376]
===
match
---
dictorsetmaker [25384,25443]
dictorsetmaker [25388,25447]
===
match
---
atom_expr [37710,37745]
atom_expr [37714,37749]
===
match
---
trailer [7536,7549]
trailer [7548,7561]
===
match
---
parameters [20686,20793]
parameters [20690,20797]
===
match
---
name: clear_db_runs [1303,1316]
name: clear_db_runs [1331,1344]
===
match
---
dictorsetmaker [5097,5118]
dictorsetmaker [5125,5146]
===
match
---
operator: , [7081,7082]
operator: , [7101,7102]
===
match
---
name: RESOURCE_TASK_INSTANCE [1984,2006]
name: RESOURCE_TASK_INSTANCE [2012,2034]
===
match
---
atom [26081,26887]
atom [26085,26891]
===
match
---
param [3261,3289]
param [3289,3317]
===
match
---
dictorsetmaker [14015,14036]
dictorsetmaker [14019,14040]
===
match
---
operator: , [34774,34775]
operator: , [34778,34779]
===
match
---
funcdef [41151,41788]
funcdef [41155,41792]
===
match
---
operator: = [20245,20246]
operator: = [20249,20250]
===
match
---
string: "TestNoPermissions" [2089,2108]
string: "TestNoPermissions" [2117,2136]
===
match
---
dictorsetmaker [7915,9009]
dictorsetmaker [7927,9013]
===
match
---
operator: } [29890,29891]
operator: } [29894,29895]
===
match
---
atom [17776,17799]
atom [17780,17803]
===
match
---
param [22969,22978]
param [22973,22982]
===
match
---
import_from [1142,1184]
import_from [1170,1212]
===
match
---
trailer [21913,21920]
trailer [21917,21924]
===
match
---
name: len [35093,35096]
name: len [35097,35100]
===
match
---
trailer [15689,15805]
trailer [15693,15809]
===
match
---
atom [11199,11383]
atom [11203,11387]
===
match
---
operator: { [10728,10729]
operator: { [10732,10733]
===
match
---
atom [12655,12672]
atom [12659,12676]
===
match
---
string: "default_pool" [6816,6830]
string: "default_pool" [6836,6850]
===
match
---
arith_expr [20207,20248]
arith_expr [20211,20252]
===
match
---
atom [15232,15257]
atom [15236,15261]
===
match
---
name: response [21191,21199]
name: response [21195,21203]
===
match
---
name: app [2158,2161]
name: app [2186,2189]
===
match
---
operator: , [30413,30414]
operator: , [30417,30418]
===
match
---
operator: , [14298,14299]
operator: , [14302,14303]
===
match
---
operator: , [15625,15626]
operator: , [15629,15630]
===
match
---
param [3159,3167]
param [3187,3195]
===
match
---
name: permissions [1864,1875]
name: permissions [1892,1903]
===
match
---
operator: , [25973,25974]
operator: , [25977,25978]
===
match
---
operator: } [19999,20000]
operator: } [20003,20004]
===
match
---
atom [34483,34707]
atom [34487,34711]
===
match
---
string: "include_past" [39740,39754]
string: "include_past" [39744,39758]
===
match
---
name: i [3889,3890]
name: i [3917,3918]
===
match
---
trailer [4145,4412]
trailer [4173,4440]
===
match
---
name: DEFAULT_DATETIME_1 [26332,26350]
name: DEFAULT_DATETIME_1 [26336,26354]
===
match
---
string: "print_the_context" [40166,40185]
string: "print_the_context" [40170,40189]
===
match
---
operator: , [40442,40443]
operator: , [40446,40447]
===
match
---
assert_stmt [5139,5173]
assert_stmt [5167,5201]
===
match
---
name: patch [37553,37558]
name: patch [37557,37562]
===
match
---
atom [10026,10210]
atom [10030,10214]
===
match
---
operator: { [20414,20415]
operator: { [20418,20419]
===
match
---
operator: , [8503,8504]
operator: , [8515,8516]
===
match
---
name: return_value [37769,37781]
name: return_value [37773,37785]
===
match
---
string: "state" [18288,18295]
string: "state" [18292,18299]
===
match
---
trailer [37881,37883]
trailer [37885,37887]
===
match
---
argument [2634,2640]
argument [2662,2668]
===
match
---
string: "dag_id" [6455,6463]
string: "dag_id" [6475,6483]
===
match
---
operator: , [29031,29032]
operator: , [29035,29036]
===
match
---
operator: , [31077,31078]
operator: , [31081,31082]
===
match
---
name: response [7884,7892]
name: response [7896,7904]
===
match
---
trailer [20157,20165]
trailer [20161,20169]
===
match
---
trailer [16609,16626]
trailer [16613,16630]
===
match
---
dictorsetmaker [14804,14827]
dictorsetmaker [14808,14831]
===
match
---
simple_stmt [6417,7209]
simple_stmt [6437,7221]
===
match
---
simple_stmt [6058,6157]
simple_stmt [6078,6177]
===
match
---
operator: == [41139,41141]
operator: == [41143,41145]
===
match
---
operator: , [42500,42501]
operator: , [42504,42505]
===
match
---
operator: = [23901,23902]
operator: = [23905,23906]
===
match
---
trailer [7495,7508]
trailer [7507,7520]
===
match
---
argument [39196,39210]
argument [39200,39214]
===
match
---
operator: , [7950,7951]
operator: , [7962,7963]
===
match
---
operator: , [17122,17123]
operator: , [17126,17127]
===
match
---
name: timedelta [11122,11131]
name: timedelta [11126,11135]
===
match
---
trailer [16663,16668]
trailer [16667,16672]
===
match
---
operator: , [6728,6729]
operator: , [6748,6749]
===
match
---
name: provide_session [1044,1059]
name: provide_session [1072,1087]
===
match
---
atom_expr [36809,36829]
atom_expr [36813,36833]
===
match
---
operator: == [16045,16047]
operator: == [16049,16051]
===
match
---
operator: = [39460,39461]
operator: = [39464,39465]
===
match
---
operator: = [36971,36972]
operator: = [36975,36976]
===
match
---
name: TaskInstance [956,968]
name: TaskInstance [941,953]
===
match
---
operator: , [22945,22946]
operator: , [22949,22950]
===
match
---
trailer [31749,31757]
trailer [31753,31761]
===
match
---
name: FAILED [29530,29536]
name: FAILED [29534,29540]
===
match
---
name: environ_overrides [23884,23901]
name: environ_overrides [23888,23905]
===
match
---
trailer [3873,3892]
trailer [3901,3920]
===
match
---
atom_expr [31741,31770]
atom_expr [31745,31774]
===
match
---
name: create_task_instances [7294,7315]
name: create_task_instances [7306,7327]
===
match
---
name: response [25110,25118]
name: response [25114,25122]
===
match
---
operator: { [29913,29914]
operator: { [29917,29918]
===
match
---
operator: + [20226,20227]
operator: + [20230,20231]
===
match
---
assert_stmt [7833,7867]
assert_stmt [7845,7879]
===
match
---
atom [38520,38842]
atom [38524,38846]
===
match
---
dotted_name [24080,24100]
dotted_name [24084,24104]
===
match
---
operator: @ [22874,22875]
operator: @ [22878,22879]
===
match
---
operator: , [25014,25015]
operator: , [25018,25019]
===
match
---
string: "duration" [12734,12744]
string: "duration" [12738,12748]
===
match
---
name: State [28889,28894]
name: State [28893,28898]
===
match
---
name: single_dag_run [31701,31715]
name: single_dag_run [31705,31719]
===
match
---
string: "test_queue_3" [17468,17482]
string: "test_queue_3" [17472,17486]
===
match
---
comparison [36072,36099]
comparison [36076,36103]
===
match
---
string: "state" [22022,22029]
string: "state" [22026,22033]
===
match
---
string: "test queue filter" [17305,17324]
string: "test queue filter" [17309,17328]
===
match
---
string: "default_queue" [5681,5696]
string: "default_queue" [5709,5724]
===
match
---
simple_stmt [35652,36057]
simple_stmt [35656,36061]
===
match
---
name: expand [24094,24100]
name: expand [24098,24104]
===
match
---
operator: , [12672,12673]
operator: , [12676,12677]
===
match
---
atom_expr [15825,15888]
atom_expr [15829,15892]
===
match
---
name: client [39354,39360]
name: client [39358,39364]
===
match
---
expr_stmt [4134,4412]
expr_stmt [4162,4440]
===
match
---
name: FAILED [29862,29868]
name: FAILED [29866,29872]
===
match
---
argument [2991,3014]
argument [3019,3042]
===
match
---
suite [16742,16894]
suite [16746,16898]
===
match
---
name: provide_session [36529,36544]
name: provide_session [36533,36548]
===
match
---
atom_expr [28657,28677]
atom_expr [28661,28681]
===
match
---
atom_expr [11040,11060]
atom_expr [11044,11064]
===
match
---
name: pytest [2235,2241]
name: pytest [2263,2269]
===
match
---
name: days [28670,28674]
name: days [28674,28678]
===
match
---
name: session [6085,6092]
name: session [6105,6112]
===
match
---
operator: { [24505,24506]
operator: { [24509,24510]
===
match
---
name: update_extras [20721,20734]
name: update_extras [20725,20738]
===
match
---
fstring_string: /clearTaskInstances [33426,33445]
fstring_string: /clearTaskInstances [33430,33449]
===
match
---
trailer [37216,37221]
trailer [37220,37225]
===
match
---
expr_stmt [38944,38985]
expr_stmt [38948,38989]
===
match
---
operator: , [3936,3937]
operator: , [3964,3965]
===
match
---
parameters [35216,35222]
parameters [35220,35226]
===
match
---
atom_expr [37127,37156]
atom_expr [37131,37160]
===
match
---
operator: , [37107,37108]
operator: , [37111,37112]
===
match
---
operator: , [11417,11418]
operator: , [11421,11422]
===
match
---
operator: { [27284,27285]
operator: { [27288,27289]
===
match
---
operator: , [33993,33994]
operator: , [33997,33998]
===
match
---
name: DEFAULT_DATETIME_1 [26224,26242]
name: DEFAULT_DATETIME_1 [26228,26246]
===
match
---
operator: = [12207,12208]
operator: = [12211,12212]
===
match
---
operator: , [21164,21165]
operator: , [21168,21169]
===
match
---
name: response [22450,22458]
name: response [22454,22462]
===
match
---
number: 1 [6858,6859]
number: 1 [6878,6879]
===
match
---
trailer [22278,22283]
trailer [22282,22287]
===
match
---
expr_stmt [3593,3636]
expr_stmt [3621,3664]
===
match
---
name: response [21220,21228]
name: response [21224,21232]
===
match
---
number: 2 [14649,14650]
number: 2 [14653,14654]
===
match
---
string: "example_python_operator" [32185,32210]
string: "example_python_operator" [32189,32214]
===
match
---
name: session [4913,4920]
name: session [4941,4948]
===
match
---
operator: { [40738,40739]
operator: { [40742,40743]
===
match
---
atom [31227,31328]
atom [31231,31332]
===
match
---
dictorsetmaker [16385,16406]
dictorsetmaker [16389,16410]
===
match
---
name: task [39231,39235]
name: task [39235,39239]
===
match
---
string: "priority_weight" [5638,5655]
string: "priority_weight" [5666,5683]
===
match
---
operator: , [38215,38216]
operator: , [38219,38220]
===
match
---
string: "failed" [39791,39799]
string: "failed" [39795,39803]
===
match
---
trailer [3470,3478]
trailer [3498,3506]
===
match
---
string: "INVALID_TASK" [41447,41461]
string: "INVALID_TASK" [41451,41465]
===
match
---
dictorsetmaker [41878,42237]
dictorsetmaker [41882,42241]
===
match
---
operator: { [17731,17732]
operator: { [17735,17736]
===
match
---
simple_stmt [1185,1271]
simple_stmt [1213,1299]
===
match
---
operator: } [33500,33501]
operator: } [33504,33505]
===
match
---
arglist [21038,21165]
arglist [21042,21169]
===
match
---
testlist_comp [24124,24691]
testlist_comp [24128,24695]
===
match
---
string: "test_queue_1" [14766,14780]
string: "test_queue_1" [14770,14784]
===
match
---
atom_expr [32631,32644]
atom_expr [32635,32648]
===
match
---
string: "queue" [17565,17572]
string: "queue" [17569,17576]
===
match
---
number: 150 [18499,18502]
number: 150 [18503,18506]
===
match
---
name: TaskInstance [3910,3922]
name: TaskInstance [3938,3950]
===
match
---
number: 1 [28675,28676]
number: 1 [28679,28680]
===
match
---
atom_expr [37913,38444]
atom_expr [37917,38448]
===
match
---
atom_expr [43217,43237]
atom_expr [43221,43241]
===
match
---
string: "state" [31103,31110]
string: "state" [31107,31114]
===
match
---
argument [26366,26372]
argument [26370,26376]
===
match
---
number: 2 [26051,26052]
number: 2 [26055,26056]
===
match
---
string: "2020-01-01T00:00:00+00:00" [1404,1431]
string: "2020-01-01T00:00:00+00:00" [1432,1459]
===
match
---
name: State [18146,18151]
name: State [18150,18155]
===
match
---
name: days [11132,11136]
name: days [11136,11140]
===
match
---
trailer [3933,3936]
trailer [3961,3964]
===
match
---
string: 'TEST_DAG_RUN_ID_4' [34806,34825]
string: 'TEST_DAG_RUN_ID_4' [34810,34829]
===
match
---
name: dt [20062,20064]
name: dt [20066,20068]
===
match
---
atom [40696,40719]
atom [40700,40723]
===
match
---
operator: { [36425,36426]
operator: { [36429,36430]
===
match
---
simple_stmt [9313,9528]
simple_stmt [9317,9532]
===
match
---
operator: , [42680,42681]
operator: , [42684,42685]
===
match
---
string: "execution_date" [30116,30132]
string: "execution_date" [30120,30136]
===
match
---
operator: , [34349,34350]
operator: , [34353,34354]
===
match
---
operator: = [25032,25033]
operator: = [25036,25037]
===
match
---
name: State [6120,6125]
name: State [6140,6145]
===
match
---
operator: , [5064,5065]
operator: , [5092,5093]
===
match
---
string: "test start date filter with ~" [10877,10908]
string: "test start date filter with ~" [10881,10912]
===
match
---
testlist_comp [10276,10831]
testlist_comp [10280,10835]
===
match
---
name: SUCCESS [13572,13579]
name: SUCCESS [13576,13583]
===
match
---
atom [18771,18998]
atom [18775,19002]
===
match
---
funcdef [42865,43296]
funcdef [42869,43300]
===
match
---
string: 'REMOTE_USER' [17085,17098]
string: 'REMOTE_USER' [17089,17102]
===
match
---
atom_expr [1972,2006]
atom_expr [2000,2034]
===
match
---
operator: , [6893,6894]
operator: , [6913,6914]
===
match
---
operator: , [29644,29645]
operator: , [29648,29649]
===
match
---
dictorsetmaker [32452,32512]
dictorsetmaker [32456,32516]
===
match
---
suite [9626,17177]
suite [9630,17181]
===
match
---
name: dt [28834,28836]
name: dt [28838,28840]
===
match
---
trailer [38964,38985]
trailer [38968,38989]
===
match
---
operator: , [10244,10245]
operator: , [10248,10249]
===
match
---
name: self [38858,38862]
name: self [38862,38866]
===
match
---
atom_expr [20062,20082]
atom_expr [20066,20086]
===
match
---
atom [6110,6134]
atom [6130,6154]
===
match
---
name: response [36072,36080]
name: response [36076,36084]
===
match
---
operator: , [13800,13801]
operator: , [13804,13805]
===
match
---
operator: } [35554,35555]
operator: } [35558,35559]
===
match
---
operator: { [36752,36753]
operator: { [36756,36757]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [22297,22342]
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [22301,22346]
===
match
---
operator: , [41893,41894]
operator: , [41897,41898]
===
match
---
name: self [4862,4866]
name: self [4890,4894]
===
match
---
name: timedelta [30883,30892]
name: timedelta [30887,30896]
===
match
---
string: "operator" [6742,6752]
string: "operator" [6762,6772]
===
match
---
operator: , [10532,10533]
operator: , [10536,10537]
===
match
---
operator: , [23253,23254]
operator: , [23257,23258]
===
match
---
dictorsetmaker [20272,20331]
dictorsetmaker [20276,20335]
===
match
---
string: "execution_date" [28510,28526]
string: "execution_date" [28514,28530]
===
match
---
trailer [33024,33034]
trailer [33028,33038]
===
match
---
operator: , [3251,3252]
operator: , [3279,3280]
===
match
---
atom_expr [4329,4352]
atom_expr [4357,4380]
===
match
---
name: task_instances [36645,36659]
name: task_instances [36649,36663]
===
match
---
comparison [21191,21218]
comparison [21195,21222]
===
match
---
name: include_examples [2968,2984]
name: include_examples [2996,3012]
===
match
---
dictorsetmaker [35367,35541]
dictorsetmaker [35371,35545]
===
match
---
operator: , [27369,27370]
operator: , [27373,27374]
===
match
---
trailer [20313,20323]
trailer [20317,20327]
===
match
---
argument [22207,22236]
argument [22211,22240]
===
match
---
string: "include_upstream" [40891,40909]
string: "include_upstream" [40895,40913]
===
match
---
name: session [1029,1036]
name: session [1057,1064]
===
match
---
name: dag_run_state [4380,4393]
name: dag_run_state [4408,4421]
===
match
---
atom_expr [24884,25051]
atom_expr [24888,25055]
===
match
---
simple_stmt [32041,32100]
simple_stmt [32045,32104]
===
match
---
name: json [31966,31970]
name: json [31970,31974]
===
match
---
operator: == [16648,16650]
operator: == [16652,16654]
===
match
---
string: "dry_run" [40756,40765]
string: "dry_run" [40760,40769]
===
match
---
string: "state" [30749,30756]
string: "state" [30753,30760]
===
match
---
atom_expr [36904,37118]
atom_expr [36908,37122]
===
match
---
operator: = [21006,21007]
operator: = [21010,21011]
===
match
---
atom [13030,13374]
atom [13034,13378]
===
match
---
dictorsetmaker [18288,18318]
dictorsetmaker [18292,18322]
===
match
---
name: dt [9862,9864]
name: dt [9866,9868]
===
match
---
string: "queue" [5672,5679]
string: "queue" [5700,5707]
===
match
---
operator: } [36883,36884]
operator: } [36887,36888]
===
match
---
operator: , [22942,22943]
operator: , [22946,22947]
===
match
---
name: session [16479,16486]
name: session [16483,16490]
===
match
---
operator: , [11471,11472]
operator: , [11475,11476]
===
match
---
param [36617,36626]
param [36621,36630]
===
match
---
operator: , [30398,30399]
operator: , [30402,30403]
===
match
---
atom_expr [6381,6401]
atom_expr [6401,6421]
===
match
---
operator: , [10573,10574]
operator: , [10577,10578]
===
match
---
operator: , [3354,3355]
operator: , [3382,3383]
===
match
---
operator: = [1678,1679]
operator: = [1706,1707]
===
match
---
trailer [19991,19999]
trailer [19995,20003]
===
match
---
atom_expr [20228,20248]
atom_expr [20232,20252]
===
match
---
name: json [16021,16025]
name: json [16025,16029]
===
match
---
string: "failed" [42715,42723]
string: "failed" [42719,42727]
===
match
---
number: 1 [30721,30722]
number: 1 [30725,30726]
===
match
---
string: "state" [18182,18189]
string: "state" [18186,18193]
===
match
---
assert_stmt [35081,35129]
assert_stmt [35085,35133]
===
match
---
operator: = [4208,4209]
operator: = [4236,4237]
===
match
---
name: test_should_raise_403_forbidden [35605,35636]
name: test_should_raise_403_forbidden [35609,35640]
===
match
---
string: "state" [30024,30031]
string: "state" [30028,30035]
===
match
---
string: "state" [32622,32629]
string: "state" [32626,32633]
===
match
---
trailer [25768,25775]
trailer [25772,25779]
===
match
---
name: dt [2621,2623]
name: dt [2649,2651]
===
match
---
operator: } [27579,27580]
operator: } [27583,27584]
===
match
---
operator: , [23608,23609]
operator: , [23612,23613]
===
match
---
atom_expr [18958,18978]
atom_expr [18962,18982]
===
match
---
expr_stmt [32219,32411]
expr_stmt [32223,32415]
===
match
---
simple_stmt [41207,41745]
simple_stmt [41211,41749]
===
match
---
operator: { [29559,29560]
operator: { [29563,29564]
===
match
---
name: dagbag [3464,3470]
name: dagbag [3492,3498]
===
match
---
operator: = [16221,16222]
operator: = [16225,16226]
===
match
---
operator: , [9446,9447]
operator: , [9450,9451]
===
match
---
operator: } [17843,17844]
operator: } [17847,17848]
===
match
---
operator: } [29100,29101]
operator: } [29104,29105]
===
match
---
expr_stmt [6165,6365]
expr_stmt [6185,6385]
===
match
---
name: sla_miss [7581,7589]
name: sla_miss [7593,7601]
===
match
---
number: 400 [25091,25094]
number: 400 [25095,25098]
===
match
---
operator: , [32750,32751]
operator: , [32754,32755]
===
match
---
operator: } [12749,12750]
operator: } [12753,12754]
===
match
---
trailer [36861,36869]
trailer [36865,36873]
===
match
---
name: json [22609,22613]
name: json [22613,22617]
===
match
---
operator: { [41343,41344]
operator: { [41347,41348]
===
match
---
string: "TEST_DAG_RUN_ID/taskInstances?state=running,queued" [13730,13782]
string: "TEST_DAG_RUN_ID/taskInstances?state=running,queued" [13734,13786]
===
match
---
operator: , [38113,38114]
operator: , [38117,38118]
===
match
---
name: environ_overrides [15846,15863]
name: environ_overrides [15850,15867]
===
match
---
operator: , [13580,13581]
operator: , [13584,13585]
===
match
---
operator: = [15823,15824]
operator: = [15827,15828]
===
match
---
suite [24820,25146]
suite [24824,25150]
===
match
---
name: timedelta [27352,27361]
name: timedelta [27356,27365]
===
match
---
operator: , [7549,7550]
operator: , [7561,7562]
===
match
---
expr_stmt [3905,3953]
expr_stmt [3933,3981]
===
match
---
name: DEFAULT_DATETIME_1 [19400,19418]
name: DEFAULT_DATETIME_1 [19404,19422]
===
match
---
simple_stmt [2370,2482]
simple_stmt [2398,2510]
===
match
---
operator: , [4527,4528]
operator: , [4555,4556]
===
match
---
string: "include_downstream" [40933,40953]
string: "include_downstream" [40937,40957]
===
match
---
name: days [28086,28090]
name: days [28090,28094]
===
match
---
name: dt [30880,30882]
name: dt [30884,30886]
===
match
---
operator: { [15326,15327]
operator: { [15330,15331]
===
match
---
operator: , [32659,32660]
operator: , [32663,32664]
===
match
---
atom [41824,42833]
atom [41828,42837]
===
match
---
operator: , [12561,12562]
operator: , [12565,12566]
===
match
---
operator: , [31582,31583]
operator: , [31586,31587]
===
match
---
testlist_comp [12038,12547]
testlist_comp [12042,12551]
===
match
---
dictorsetmaker [20023,20082]
dictorsetmaker [20027,20086]
===
match
---
name: days [30168,30172]
name: days [30172,30176]
===
match
---
operator: , [27535,27536]
operator: , [27539,27540]
===
match
---
atom [28946,29101]
atom [28950,29105]
===
match
---
trailer [31757,31768]
trailer [31761,31772]
===
match
---
arglist [4514,4707]
arglist [4542,4735]
===
match
---
operator: , [26834,26835]
operator: , [26838,26839]
===
match
---
trailer [15840,15888]
trailer [15844,15892]
===
match
---
expr_stmt [23522,23698]
expr_stmt [23526,23702]
===
match
---
testlist_comp [10340,10533]
testlist_comp [10344,10537]
===
match
---
number: 150 [13164,13167]
number: 150 [13168,13171]
===
match
---
string: "REMOTE_USER" [22375,22388]
string: "REMOTE_USER" [22379,22392]
===
match
---
name: dag_bag [31750,31757]
name: dag_bag [31754,31761]
===
match
---
operator: , [2641,2642]
operator: , [2669,2670]
===
match
---
fstring_string: /api/v1/dags/ [31851,31864]
fstring_string: /api/v1/dags/ [31855,31868]
===
match
---
name: timedelta [20545,20554]
name: timedelta [20549,20558]
===
match
---
name: DEFAULT_DATETIME_1 [27875,27893]
name: DEFAULT_DATETIME_1 [27879,27897]
===
match
---
operator: } [18204,18205]
operator: } [18208,18209]
===
match
---
name: self [7491,7495]
name: self [7503,7507]
===
match
---
string: "unixname" [7168,7178]
string: "unixname" [7188,7198]
===
match
---
string: 'dag_run_id' [33834,33846]
string: 'dag_run_id' [33838,33850]
===
match
---
operator: { [13465,13466]
operator: { [13469,13470]
===
match
---
operator: } [36192,36193]
operator: } [36196,36197]
===
match
---
name: session [37798,37805]
name: session [37802,37809]
===
match
---
fstring_start: f" [33403,33405]
fstring_start: f" [33407,33409]
===
match
---
number: 2 [28852,28853]
number: 2 [28856,28857]
===
match
---
name: self [32152,32156]
name: self [32156,32160]
===
match
---
name: single_dag_run [22222,22236]
name: single_dag_run [22226,22240]
===
match
---
operator: , [28570,28571]
operator: , [28574,28575]
===
match
---
name: FAILED [29685,29691]
name: FAILED [29689,29695]
===
match
---
atom [25361,25817]
atom [25365,25821]
===
match
---
dictorsetmaker [31249,31310]
dictorsetmaker [31253,31314]
===
match
---
name: DagRun [4139,4145]
name: DagRun [4167,4173]
===
match
---
trailer [7639,7646]
trailer [7651,7658]
===
match
---
name: State [13521,13526]
name: State [13525,13530]
===
match
---
name: days [11053,11057]
name: days [11057,11061]
===
match
---
operator: , [18114,18115]
operator: , [18118,18119]
===
match
---
operator: , [19020,19021]
operator: , [19024,19025]
===
match
---
operator: = [9477,9478]
operator: = [9481,9482]
===
match
---
name: tests [1276,1281]
name: tests [1304,1309]
===
match
---
arith_expr [32855,32896]
arith_expr [32859,32900]
===
match
---
name: task_instances [32420,32434]
name: task_instances [32424,32438]
===
match
---
string: "test" [37340,37346]
string: "test" [37344,37350]
===
match
---
operator: , [18902,18903]
operator: , [18906,18907]
===
match
---
atom [38570,38818]
atom [38574,38822]
===
match
---
atom [13556,13580]
atom [13560,13584]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances?queue=test_queue_1,test_queue_2" [15410,15482]
string: "/api/v1/dags/~/dagRuns/~/taskInstances?queue=test_queue_1,test_queue_2" [15414,15486]
===
match
---
name: total_ti [23450,23458]
name: total_ti [23454,23462]
===
match
---
argument [9958,9964]
argument [9962,9968]
===
match
---
operator: , [6700,6701]
operator: , [6720,6721]
===
match
---
operator: , [23940,23941]
operator: , [23944,23945]
===
match
---
suite [35223,35596]
suite [35227,35600]
===
match
---
string: "task_id" [40789,40798]
string: "task_id" [40793,40802]
===
match
---
name: status_code [9552,9563]
name: status_code [9556,9567]
===
match
---
operator: + [30878,30879]
operator: + [30882,30883]
===
match
---
string: 'task_id' [34430,34439]
string: 'task_id' [34434,34443]
===
match
---
name: days [10445,10449]
name: days [10449,10453]
===
match
---
atom [12633,12769]
atom [12637,12773]
===
match
---
operator: , [41311,41312]
operator: , [41315,41316]
===
match
---
operator: , [2989,2990]
operator: , [3017,3018]
===
match
---
name: DEFAULT_DATETIME_1 [28990,29008]
name: DEFAULT_DATETIME_1 [28994,29012]
===
match
---
operator: , [32400,32401]
operator: , [32404,32405]
===
match
---
name: expand [25227,25233]
name: expand [25231,25237]
===
match
---
operator: = [16477,16478]
operator: = [16481,16482]
===
match
---
trailer [18960,18970]
trailer [18964,18974]
===
match
---
string: "failed" [40434,40442]
string: "failed" [40438,40446]
===
match
---
operator: { [20188,20189]
operator: { [20192,20193]
===
match
---
string: "pool" [13925,13931]
string: "pool" [13929,13935]
===
match
---
atom [18297,18318]
atom [18301,18322]
===
match
---
atom [20414,20582]
atom [20418,20586]
===
match
---
name: DEFAULT_DATETIME_1 [10355,10373]
name: DEFAULT_DATETIME_1 [10359,10377]
===
match
---
string: "try_number" [7139,7151]
string: "try_number" [7159,7171]
===
match
---
name: update [3867,3873]
name: update [3895,3901]
===
match
---
simple_stmt [21184,21234]
simple_stmt [21188,21238]
===
match
---
simple_stmt [23041,23104]
simple_stmt [23045,23108]
===
match
---
operator: , [13947,13948]
operator: , [13951,13952]
===
match
---
operator: } [14827,14828]
operator: } [14831,14832]
===
match
---
trailer [4912,4921]
trailer [4940,4949]
===
match
---
atom [24605,24657]
atom [24609,24661]
===
match
---
expr_stmt [37194,37384]
expr_stmt [37198,37388]
===
match
---
operator: , [5288,5289]
operator: , [5316,5317]
===
match
---
operator: , [6635,6636]
operator: , [6655,6656]
===
match
---
operator: { [28592,28593]
operator: { [28596,28597]
===
match
---
string: "state" [28703,28710]
string: "state" [28707,28714]
===
match
---
funcdef [32105,35169]
funcdef [32109,35173]
===
match
---
operator: , [30970,30971]
operator: , [30974,30975]
===
match
---
operator: , [15482,15483]
operator: , [15486,15487]
===
match
---
number: 2 [19763,19764]
number: 2 [19767,19768]
===
match
---
name: dr [4746,4748]
name: dr [4774,4776]
===
match
---
arith_expr [28813,28854]
arith_expr [28817,28858]
===
match
---
name: dag_id [16527,16533]
name: dag_id [16531,16537]
===
match
---
string: "execution_date" [28034,28050]
string: "execution_date" [28038,28054]
===
match
---
name: days [12203,12207]
name: days [12207,12211]
===
match
---
testlist_comp [18031,18339]
testlist_comp [18035,18343]
===
match
---
name: environ_overrides [41325,41342]
name: environ_overrides [41329,41346]
===
match
---
string: 'execution_date' [34367,34383]
string: 'execution_date' [34371,34387]
===
match
---
string: '2020-11-10T12:42:39.442973' [24528,24556]
string: '2020-11-10T12:42:39.442973' [24532,24560]
===
match
---
string: "end_date" [36152,36162]
string: "end_date" [36156,36166]
===
match
---
name: json [15956,15960]
name: json [15960,15964]
===
match
---
operator: { [21934,21935]
operator: { [21938,21939]
===
match
---
trailer [29813,29821]
trailer [29817,29825]
===
match
---
operator: , [4040,4041]
operator: , [4068,4069]
===
match
---
trailer [23717,23727]
trailer [23721,23731]
===
match
---
funcdef [9025,9257]
funcdef [9029,9261]
===
match
---
name: post [24896,24900]
name: post [24900,24904]
===
match
---
trailer [10523,10531]
trailer [10527,10535]
===
match
---
name: _ [20702,20703]
name: _ [20706,20707]
===
match
---
name: session [24811,24818]
name: session [24815,24822]
===
match
---
string: 'dag_run_id' [38649,38661]
string: 'dag_run_id' [38653,38665]
===
match
---
name: expand [21394,21400]
name: expand [21398,21404]
===
match
---
operator: , [18338,18339]
operator: , [18342,18343]
===
match
---
dictorsetmaker [36152,36192]
dictorsetmaker [36156,36196]
===
match
---
name: days [29637,29641]
name: days [29641,29645]
===
match
---
atom [34007,34231]
atom [34011,34235]
===
match
---
name: count [16471,16476]
name: count [16475,16480]
===
match
---
operator: } [27083,27084]
operator: } [27087,27088]
===
match
---
name: timedelta [28076,28085]
name: timedelta [28080,28089]
===
match
---
string: "state" [32914,32921]
string: "state" [32918,32925]
===
match
---
atom [36136,36517]
atom [36140,36521]
===
match
---
testlist_comp [41856,42304]
testlist_comp [41860,42308]
===
match
---
name: models [917,923]
name: models [902,908]
===
match
---
string: "2020-01-03T00:00:00+00:00" [6549,6576]
string: "2020-01-03T00:00:00+00:00" [6569,6596]
===
match
---
operator: } [24360,24361]
operator: } [24364,24365]
===
match
---
assert_stmt [25103,25145]
assert_stmt [25107,25149]
===
match
---
operator: = [33747,33748]
operator: = [33751,33752]
===
match
---
name: dr [4441,4443]
name: dr [4469,4471]
===
match
---
string: "unixname" [8979,8989]
string: "unixname" [8991,9001]
===
match
---
atom_expr [2370,2382]
atom_expr [2398,2410]
===
match
---
operator: , [19562,19563]
operator: , [19566,19567]
===
match
---
operator: , [16407,16408]
operator: , [16411,16412]
===
match
---
name: response [15947,15955]
name: response [15951,15959]
===
match
---
arglist [39046,39264]
arglist [39050,39268]
===
match
---
trailer [7576,7580]
trailer [7588,7592]
===
match
---
name: DEFAULT_DATETIME_1 [20458,20476]
name: DEFAULT_DATETIME_1 [20462,20480]
===
match
---
argument [2568,2574]
argument [2596,2602]
===
match
---
operator: } [31951,31952]
operator: } [31955,31956]
===
match
---
argument [33460,33501]
argument [33464,33505]
===
match
---
expr_stmt [33729,34956]
expr_stmt [33733,34960]
===
match
---
name: client [9099,9105]
name: client [9103,9109]
===
match
---
name: days [36822,36826]
name: days [36826,36830]
===
match
---
atom [17709,17863]
atom [17713,17867]
===
match
---
operator: == [35147,35149]
operator: == [35151,35153]
===
match
---
operator: = [6108,6109]
operator: = [6128,6129]
===
match
---
string: "test queue filter" [14697,14716]
string: "test queue filter" [14701,14720]
===
match
---
name: timedelta [28837,28846]
name: timedelta [28841,28850]
===
match
---
operator: , [14413,14414]
operator: , [14417,14418]
===
match
---
string: 'example_python_operator' [33791,33816]
string: 'example_python_operator' [33795,33820]
===
match
---
operator: , [8319,8320]
operator: , [8331,8332]
===
match
---
name: update_extras [20864,20877]
name: update_extras [20868,20881]
===
match
---
operator: , [32604,32605]
operator: , [32608,32609]
===
match
---
atom_expr [3603,3636]
atom_expr [3631,3664]
===
match
---
string: 'print_the_context' [38780,38799]
string: 'print_the_context' [38784,38803]
===
match
---
decorated [1487,2196]
decorated [1515,2224]
===
match
---
name: parameterized [22639,22652]
name: parameterized [22643,22656]
===
match
---
dictorsetmaker [32545,32645]
dictorsetmaker [32549,32649]
===
match
---
atom [17411,17436]
atom [17415,17440]
===
match
---
string: "queue" [6907,6914]
string: "queue" [6927,6934]
===
match
---
argument [28086,28092]
argument [28090,28096]
===
match
---
operator: , [21138,21139]
operator: , [21142,21143]
===
match
---
simple_stmt [1594,2026]
simple_stmt [1622,2054]
===
match
---
operator: , [41091,41092]
operator: , [41095,41096]
===
match
---
operator: = [37101,37102]
operator: = [37105,37106]
===
match
---
string: "reset_dag_runs" [35401,35417]
string: "reset_dag_runs" [35405,35421]
===
match
---
name: dt [32876,32878]
name: dt [32880,32882]
===
match
---
number: 0 [35167,35168]
number: 0 [35171,35172]
===
match
---
name: environ_overrides [40029,40046]
name: environ_overrides [40033,40050]
===
match
---
comparison [22575,22632]
comparison [22579,22636]
===
match
---
atom_expr [7180,7197]
atom_expr [7200,7209]
===
match
---
string: '2020-01-01T00:00:00+00:00' [33903,33930]
string: '2020-01-01T00:00:00+00:00' [33907,33934]
===
match
---
name: DEFAULT_DATETIME_1 [29780,29798]
name: DEFAULT_DATETIME_1 [29784,29802]
===
match
---
operator: = [23531,23532]
operator: = [23535,23536]
===
match
---
dictorsetmaker [9479,9515]
dictorsetmaker [9483,9519]
===
match
---
name: post [23135,23139]
name: post [23139,23143]
===
match
---
argument [7522,7549]
argument [7534,7561]
===
match
---
dictorsetmaker [19940,19999]
dictorsetmaker [19944,20003]
===
match
---
string: "task_instances" [22614,22630]
string: "task_instances" [22618,22634]
===
match
---
name: response [32052,32060]
name: response [32056,32064]
===
match
---
operator: { [11340,11341]
operator: { [11344,11345]
===
match
---
atom [19602,19745]
atom [19606,19749]
===
match
---
operator: , [5962,5963]
operator: , [5982,5983]
===
match
---
name: json [21350,21354]
name: json [21354,21358]
===
match
---
operator: , [8965,8966]
operator: , [8977,8978]
===
match
---
name: json [22488,22492]
name: json [22492,22496]
===
match
---
string: "include parent dag" [29373,29393]
string: "include parent dag" [29377,29397]
===
match
---
dictorsetmaker [22375,22396]
dictorsetmaker [22379,22400]
===
match
---
operator: + [32874,32875]
operator: + [32878,32879]
===
match
---
operator: , [29341,29342]
operator: , [29345,29346]
===
match
---
string: "include_subdags" [31286,31303]
string: "include_subdags" [31290,31307]
===
match
---
operator: , [8540,8541]
operator: , [8552,8553]
===
match
---
atom [8450,8805]
atom [8462,8817]
===
match
---
operator: , [3288,3289]
operator: , [3316,3317]
===
match
---
name: payload [32219,32226]
name: payload [32223,32230]
===
match
---
simple_stmt [15663,15806]
simple_stmt [15667,15810]
===
match
---
testlist_comp [29476,30246]
testlist_comp [29480,30250]
===
match
---
string: "end_date" [11512,11522]
string: "end_date" [11516,11526]
===
match
---
argument [36965,36997]
argument [36969,37001]
===
match
---
atom [39461,39814]
atom [39465,39818]
===
match
---
name: json [22538,22542]
name: json [22542,22546]
===
match
---
string: "include_upstream" [39614,39632]
string: "include_upstream" [39618,39636]
===
match
---
operator: { [20022,20023]
operator: { [20026,20027]
===
match
---
atom [28244,28341]
atom [28248,28345]
===
match
---
simple_stmt [1010,1060]
simple_stmt [1038,1088]
===
match
---
string: "task_id" [5860,5869]
string: "task_id" [5888,5897]
===
match
---
suite [4117,4445]
suite [4145,4473]
===
match
---
string: "state" [27787,27794]
string: "state" [27791,27798]
===
match
---
trailer [20554,20562]
trailer [20558,20566]
===
match
---
operator: , [26550,26551]
operator: , [26554,26555]
===
match
---
string: "test end date filter" [11449,11471]
string: "test end date filter" [11453,11475]
===
match
---
simple_stmt [16001,16060]
simple_stmt [16005,16064]
===
match
---
operator: = [30720,30721]
operator: = [30724,30725]
===
match
---
fstring_start: f" [31849,31851]
fstring_start: f" [31853,31855]
===
match
---
param [31442,31447]
param [31446,31451]
===
match
---
expr_stmt [4485,4721]
expr_stmt [4513,4749]
===
match
---
trailer [33608,33634]
trailer [33612,33638]
===
match
---
trailer [21199,21211]
trailer [21203,21215]
===
match
---
operator: , [34111,34112]
operator: , [34115,34116]
===
match
---
trailer [35049,35054]
trailer [35053,35058]
===
match
---
operator: , [22236,22237]
operator: , [22240,22241]
===
match
---
string: "state" [29515,29522]
string: "state" [29519,29526]
===
match
---
param [35217,35221]
param [35221,35225]
===
match
---
name: update_extras [6137,6150]
name: update_extras [6157,6170]
===
match
---
operator: = [3601,3602]
operator: = [3629,3630]
===
match
---
string: "only_failed" [35931,35944]
string: "only_failed" [35935,35948]
===
match
---
string: "unixname" [5933,5943]
string: "unixname" [5961,5971]
===
match
---
operator: , [40719,40720]
operator: , [40723,40724]
===
match
---
name: DEFAULT_DATETIME_1 [20124,20142]
name: DEFAULT_DATETIME_1 [20128,20146]
===
match
---
operator: , [25444,25445]
operator: , [25448,25449]
===
match
---
operator: , [9966,9967]
operator: , [9970,9971]
===
match
---
string: "state" [13557,13564]
string: "state" [13561,13568]
===
match
---
operator: { [10167,10168]
operator: { [10171,10172]
===
match
---
operator: , [11543,11544]
operator: , [11547,11548]
===
match
---
string: "end_date" [11566,11576]
string: "end_date" [11570,11580]
===
match
---
operator: , [11181,11182]
operator: , [11185,11186]
===
match
---
name: response [9543,9551]
name: response [9547,9555]
===
match
---
name: DEFAULT_DATETIME_1 [29603,29621]
name: DEFAULT_DATETIME_1 [29607,29625]
===
match
---
operator: = [20919,20920]
operator: = [20923,20924]
===
match
---
operator: { [12655,12656]
operator: { [12659,12660]
===
match
---
string: "example_python_operator" [6465,6490]
string: "example_python_operator" [6485,6510]
===
match
---
operator: , [32936,32937]
operator: , [32940,32941]
===
match
---
name: dt [27171,27173]
name: dt [27175,27177]
===
match
---
operator: , [31347,31348]
operator: , [31351,31352]
===
match
---
simple_stmt [39338,39826]
simple_stmt [39342,39830]
===
match
---
name: get [7647,7650]
name: get [7659,7662]
===
match
---
arglist [20843,20978]
arglist [20847,20982]
===
match
---
dictorsetmaker [10476,10531]
dictorsetmaker [10480,10535]
===
match
---
operator: , [42387,42388]
operator: , [42391,42392]
===
match
---
atom_expr [7599,7615]
atom_expr [7611,7627]
===
match
---
name: response [4930,4938]
name: response [4958,4966]
===
match
---
simple_stmt [31535,31733]
simple_stmt [31539,31737]
===
match
---
atom_expr [13566,13579]
atom_expr [13570,13583]
===
match
---
operator: } [37346,37347]
operator: } [37350,37351]
===
match
---
operator: { [31864,31865]
operator: { [31868,31869]
===
match
---
string: "test_pool_2" [13978,13991]
string: "test_pool_2" [13982,13995]
===
match
---
name: dag_id [33186,33192]
name: dag_id [33190,33196]
===
match
---
name: task_instances [37026,37040]
name: task_instances [37030,37044]
===
match
---
name: self [20803,20807]
name: self [20807,20811]
===
match
---
name: timedelta [18961,18970]
name: timedelta [18965,18974]
===
match
---
name: dt [11040,11042]
name: dt [11044,11046]
===
match
---
comparison [15904,15931]
comparison [15908,15935]
===
match
---
name: self [2863,2867]
name: self [2891,2895]
===
match
---
trailer [25591,25598]
trailer [25595,25602]
===
match
---
string: "state" [25422,25429]
string: "state" [25426,25433]
===
match
---
string: "dry_run" [41403,41412]
string: "dry_run" [41407,41416]
===
match
---
operator: , [20582,20583]
operator: , [20586,20587]
===
match
---
suite [4472,4750]
suite [4500,4778]
===
match
---
string: "state" [29057,29064]
string: "state" [29061,29068]
===
match
---
strings [12831,12964]
strings [12835,12968]
===
match
---
operator: , [1316,1317]
operator: , [1344,1345]
===
match
---
atom [25257,26067]
atom [25261,26071]
===
match
---
operator: = [39154,39155]
operator: = [39158,39159]
===
match
---
name: expected_ti [15632,15643]
name: expected_ti [15636,15647]
===
match
---
atom_expr [25763,25775]
atom_expr [25767,25779]
===
match
---
argument [7430,7462]
argument [7442,7474]
===
match
---
operator: , [8424,8425]
operator: , [8436,8437]
===
match
---
atom [12233,12288]
atom [12237,12292]
===
match
---
name: expected_ti_count [21316,21333]
name: expected_ti_count [21320,21337]
===
match
---
string: '2020-11-10T12:42:39.442973' [24332,24360]
string: '2020-11-10T12:42:39.442973' [24336,24364]
===
match
---
name: json [21152,21156]
name: json [21156,21160]
===
match
---
operator: , [17052,17053]
operator: , [17056,17057]
===
match
---
argument [40678,40719]
argument [40682,40723]
===
match
---
param [6034,6039]
param [6054,6059]
===
match
---
funcdef [23733,24074]
funcdef [23737,24078]
===
match
---
name: session [23068,23075]
name: session [23072,23079]
===
match
---
string: "dry_run" [29203,29212]
string: "dry_run" [29207,29216]
===
match
---
trailer [33615,33621]
trailer [33619,33625]
===
match
---
trailer [36729,36737]
trailer [36733,36741]
===
match
---
name: client [37210,37216]
name: client [37214,37220]
===
match
---
dictorsetmaker [18925,18978]
dictorsetmaker [18929,18982]
===
match
---
argument [40029,40085]
argument [40033,40089]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [24914,24959]
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [24918,24963]
===
match
---
funcdef [16899,17177]
funcdef [16903,17181]
===
match
---
name: dt [29011,29013]
name: dt [29015,29017]
===
match
---
name: session [31512,31519]
name: session [31516,31523]
===
match
---
name: timedelta [11602,11611]
name: timedelta [11606,11615]
===
match
---
argument [40733,41091]
argument [40737,41095]
===
match
---
operator: } [12671,12672]
operator: } [12675,12676]
===
match
---
atom_expr [3801,3818]
atom_expr [3829,3846]
===
match
---
number: 2 [10829,10830]
number: 2 [10833,10834]
===
match
---
operator: , [36951,36952]
operator: , [36955,36956]
===
match
---
string: "example_python_operator" [7925,7950]
string: "example_python_operator" [7937,7962]
===
match
---
name: payload [33520,33527]
name: payload [33524,33531]
===
match
---
operator: , [10374,10375]
operator: , [10378,10379]
===
match
---
name: State [30758,30763]
name: State [30762,30767]
===
match
---
parameters [39322,39328]
parameters [39326,39332]
===
match
---
dictorsetmaker [23903,23939]
dictorsetmaker [23907,23943]
===
match
---
simple_stmt [33362,33539]
simple_stmt [33366,33543]
===
match
---
name: update_extras [15612,15625]
name: update_extras [15616,15629]
===
match
---
operator: , [12288,12289]
operator: , [12292,12293]
===
match
---
atom_expr [30210,30222]
atom_expr [30214,30226]
===
match
---
argument [12203,12209]
argument [12207,12213]
===
match
---
name: days [20075,20079]
name: days [20079,20083]
===
match
---
name: DEFAULT_DATETIME_1 [25687,25705]
name: DEFAULT_DATETIME_1 [25691,25709]
===
match
---
string: "task_id" [38131,38140]
string: "task_id" [38135,38144]
===
match
---
trailer [43225,43237]
trailer [43229,43241]
===
match
---
string: "end_date_gte" [24220,24234]
string: "end_date_gte" [24224,24238]
===
match
---
dictorsetmaker [21116,21137]
dictorsetmaker [21120,21141]
===
match
---
atom [17574,17606]
atom [17578,17610]
===
match
---
trailer [39844,39854]
trailer [39848,39858]
===
match
---
param [9068,9072]
param [9072,9076]
===
match
---
operator: = [1508,1509]
operator: = [1536,1537]
===
match
---
name: add [4437,4440]
name: add [4465,4468]
===
match
---
string: "test_pool_1" [17935,17948]
string: "test_pool_1" [17939,17952]
===
match
---
if_stmt [4454,4750]
if_stmt [4482,4778]
===
match
---
name: status_code [5155,5166]
name: status_code [5183,5194]
===
match
---
argument [37011,37040]
argument [37015,37044]
===
match
---
operator: , [26793,26794]
operator: , [26797,26798]
===
match
---
name: app [2042,2045]
name: app [2070,2073]
===
match
---
expr_stmt [36645,36895]
expr_stmt [36649,36899]
===
match
---
name: app [2137,2140]
name: app [2165,2168]
===
match
---
operator: , [36274,36275]
operator: , [36278,36279]
===
match
---
name: dag_id [3479,3485]
name: dag_id [3507,3513]
===
match
---
trailer [2871,2883]
trailer [2899,2911]
===
match
---
string: "test duration filter" [18385,18407]
string: "test duration filter" [18389,18411]
===
match
---
simple_stmt [37710,37746]
simple_stmt [37714,37750]
===
match
---
string: "execution_date" [25384,25400]
string: "execution_date" [25388,25404]
===
match
---
atom [15153,15516]
atom [15157,15520]
===
match
---
assert_stmt [25060,25094]
assert_stmt [25064,25098]
===
match
---
operator: = [31928,31929]
operator: = [31932,31933]
===
match
---
trailer [26413,26420]
trailer [26417,26424]
===
match
---
number: 1 [27189,27190]
number: 1 [27193,27194]
===
match
---
param [2290,2304]
param [2318,2332]
===
match
---
fstring [31849,31897]
fstring [31853,31901]
===
match
---
string: 'sleep_for_3' [34917,34930]
string: 'sleep_for_3' [34921,34934]
===
match
---
string: "REMOTE_USER" [5097,5110]
string: "REMOTE_USER" [5125,5138]
===
match
---
dictorsetmaker [18848,18901]
dictorsetmaker [18852,18905]
===
match
---
operator: , [20977,20978]
operator: , [20981,20982]
===
match
---
atom [9822,9883]
atom [9826,9887]
===
match
---
param [15587,15592]
param [15591,15596]
===
match
---
parameters [16934,16940]
parameters [16938,16944]
===
match
---
assert_stmt [16001,16059]
assert_stmt [16005,16063]
===
match
---
string: "print_the_context" [37857,37876]
string: "print_the_context" [37861,37880]
===
match
---
trailer [42987,42996]
trailer [42991,43000]
===
match
---
dictorsetmaker [15327,15350]
dictorsetmaker [15331,15354]
===
match
---
name: self [9094,9098]
name: self [9098,9102]
===
match
---
name: tasks [3507,3512]
name: tasks [3535,3540]
===
match
---
atom_expr [37205,37384]
atom_expr [37209,37388]
===
match
---
operator: , [1849,1850]
operator: , [1877,1878]
===
match
---
name: counter [3661,3668]
name: counter [3689,3696]
===
match
---
string: 'REMOTE_USER' [41344,41357]
string: 'REMOTE_USER' [41348,41361]
===
match
---
operator: { [17458,17459]
operator: { [17462,17463]
===
match
---
trailer [38866,38874]
trailer [38870,38878]
===
match
---
operator: , [17948,17949]
operator: , [17952,17953]
===
match
---
operator: , [35873,35874]
operator: , [35877,35878]
===
match
---
string: 'REMOTE_USER' [43142,43155]
string: 'REMOTE_USER' [43146,43159]
===
match
---
fstring_end: " [11364,11365]
fstring_end: " [11368,11369]
===
match
---
number: 1 [1373,1374]
number: 1 [1401,1402]
===
match
---
testlist_comp [9762,9967]
testlist_comp [9766,9971]
===
match
---
name: response [16950,16958]
name: response [16954,16962]
===
match
---
string: 'REMOTE_USER' [35783,35796]
string: 'REMOTE_USER' [35787,35800]
===
match
---
trailer [4952,4956]
trailer [4980,4984]
===
match
---
name: self [35243,35247]
name: self [35247,35251]
===
match
---
operator: , [18684,18685]
operator: , [18688,18689]
===
match
---
operator: , [13819,13820]
operator: , [13823,13824]
===
match
---
operator: } [26442,26443]
operator: } [26446,26447]
===
match
---
name: State [26253,26258]
name: State [26257,26262]
===
match
---
decorated [36105,37479]
decorated [36109,37483]
===
match
---
name: dt [9945,9947]
name: dt [9949,9951]
===
match
---
simple_stmt [36065,36100]
simple_stmt [36069,36104]
===
match
---
argument [5078,5119]
argument [5106,5147]
===
match
---
argument [23267,23279]
argument [23271,23283]
===
match
---
name: provide_session [15539,15554]
name: provide_session [15543,15558]
===
match
---
name: DEFAULT_DATETIME_1 [20207,20225]
name: DEFAULT_DATETIME_1 [20211,20229]
===
match
---
param [31490,31498]
param [31494,31502]
===
match
---
operator: , [36615,36616]
operator: , [36619,36620]
===
match
---
string: "state" [18137,18144]
string: "state" [18141,18148]
===
match
---
operator: , [26052,26053]
operator: , [26056,26057]
===
match
---
operator: , [2161,2162]
operator: , [2189,2190]
===
match
---
dictorsetmaker [25492,25599]
dictorsetmaker [25496,25603]
===
match
---
operator: , [31654,31655]
operator: , [31658,31659]
===
match
---
operator: , [12769,12770]
operator: , [12773,12774]
===
match
---
string: "example_python_operator" [23640,23665]
string: "example_python_operator" [23644,23669]
===
match
---
number: 2 [20560,20561]
number: 2 [20564,20565]
===
match
---
trailer [25118,25123]
trailer [25122,25127]
===
match
---
name: days [12280,12284]
name: days [12284,12288]
===
match
---
name: json [37452,37456]
name: json [37456,37460]
===
match
---
string: "start_date" [11084,11096]
string: "start_date" [11088,11100]
===
match
---
trailer [4440,4444]
trailer [4468,4472]
===
match
---
name: username [2163,2171]
name: username [2191,2199]
===
match
---
operator: } [28923,28924]
operator: } [28927,28928]
===
match
---
operator: { [5096,5097]
operator: { [5124,5125]
===
match
---
name: days [26543,26547]
name: days [26547,26551]
===
match
---
name: FAILED [27957,27963]
name: FAILED [27961,27967]
===
match
---
operator: = [33254,33255]
operator: = [33258,33259]
===
match
---
trailer [37221,37384]
trailer [37225,37388]
===
match
---
number: 403 [24070,24073]
number: 403 [24074,24077]
===
match
---
arglist [2158,2178]
arglist [2186,2206]
===
match
---
trailer [22608,22613]
trailer [22612,22617]
===
match
---
trailer [18196,18204]
trailer [18200,18208]
===
match
---
atom_expr [25531,25551]
atom_expr [25535,25555]
===
match
---
expr_stmt [16250,16418]
expr_stmt [16254,16422]
===
match
---
name: post [37925,37929]
name: post [37929,37933]
===
match
---
trailer [9328,9335]
trailer [9332,9339]
===
match
---
trailer [35679,36056]
trailer [35683,36060]
===
match
---
dictorsetmaker [35857,36031]
dictorsetmaker [35861,36035]
===
match
---
name: response [23306,23314]
name: response [23310,23318]
===
match
---
string: "execution_date" [40203,40219]
string: "execution_date" [40207,40223]
===
match
---
testlist_comp [1943,2006]
testlist_comp [1971,2034]
===
match
---
string: "failed" [41068,41076]
string: "failed" [41072,41080]
===
match
---
name: RESOURCE_TASK_INSTANCE [1905,1927]
name: RESOURCE_TASK_INSTANCE [1933,1955]
===
match
---
atom [18013,18353]
atom [18017,18357]
===
match
---
param [20761,20779]
param [20765,20783]
===
match
---
trailer [23134,23139]
trailer [23138,23143]
===
match
---
argument [25544,25550]
argument [25548,25554]
===
match
---
string: "reset_dag_runs" [35891,35907]
string: "reset_dag_runs" [35895,35911]
===
match
---
atom [27022,27084]
atom [27026,27088]
===
match
---
simple_stmt [37902,38445]
simple_stmt [37906,38449]
===
match
---
simple_stmt [23112,23291]
simple_stmt [23116,23295]
===
match
---
operator: { [18136,18137]
operator: { [18140,18141]
===
match
---
atom [7790,7813]
atom [7802,7825]
===
match
---
name: status_code [24055,24066]
name: status_code [24059,24070]
===
match
---
simple_stmt [32420,33109]
simple_stmt [32424,33113]
===
match
---
testlist_comp [26919,27600]
testlist_comp [26923,27604]
===
match
---
name: timedelta [32879,32888]
name: timedelta [32883,32892]
===
match
---
atom_expr [32923,32936]
atom_expr [32927,32940]
===
match
---
string: "print_the_context" [7397,7416]
string: "print_the_context" [7409,7428]
===
match
---
string: "test pool filter" [13866,13884]
string: "test pool filter" [13870,13888]
===
match
---
name: json [35106,35110]
name: json [35110,35114]
===
match
---
operator: , [29326,29327]
operator: , [29330,29331]
===
match
---
dictorsetmaker [27132,27240]
dictorsetmaker [27136,27244]
===
match
---
param [22947,22955]
param [22951,22959]
===
match
---
name: status_code [25076,25087]
name: status_code [25080,25091]
===
match
---
string: "state" [25754,25761]
string: "state" [25758,25765]
===
match
---
name: test_should_raise_403_forbidden [16903,16934]
name: test_should_raise_403_forbidden [16907,16938]
===
match
---
fstring_start: f" [4209,4211]
fstring_start: f" [4237,4239]
===
match
---
operator: , [22967,22968]
operator: , [22971,22972]
===
match
---
atom_expr [2601,2618]
atom_expr [2629,2646]
===
match
---
argument [9875,9881]
argument [9879,9885]
===
match
---
operator: { [11565,11566]
operator: { [11569,11570]
===
match
---
name: tests [1190,1195]
name: tests [1218,1223]
===
match
---
dictorsetmaker [26206,26265]
dictorsetmaker [26210,26269]
===
match
---
simple_stmt [3726,3731]
simple_stmt [3754,3759]
===
match
---
number: 1 [10450,10451]
number: 1 [10454,10455]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [23825,23870]
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [23829,23874]
===
match
---
operator: == [24067,24069]
operator: == [24071,24073]
===
match
---
atom [36676,36738]
atom [36680,36742]
===
match
---
trailer [24900,25051]
trailer [24904,25055]
===
match
---
trailer [30705,30715]
trailer [30709,30719]
===
match
---
operator: , [28226,28227]
operator: , [28230,28231]
===
match
---
operator: , [41515,41516]
operator: , [41519,41520]
===
match
---
name: client [6181,6187]
name: client [6201,6207]
===
match
---
name: assert_401 [1234,1244]
name: assert_401 [1262,1272]
===
match
---
assert_stmt [6374,6408]
assert_stmt [6394,6428]
===
match
---
atom [28509,28570]
atom [28513,28574]
===
match
---
param [42933,42942]
param [42937,42946]
===
match
---
argument [31668,31687]
argument [31672,31691]
===
match
---
operator: = [10528,10529]
operator: = [10532,10533]
===
match
---
string: 'task_id' [33948,33957]
string: 'task_id' [33952,33961]
===
match
---
param [15632,15644]
param [15636,15648]
===
match
---
dictorsetmaker [18624,18664]
dictorsetmaker [18628,18668]
===
match
---
dictorsetmaker [10341,10373]
dictorsetmaker [10345,10377]
===
match
---
operator: = [4137,4138]
operator: = [4165,4166]
===
match
---
operator: { [17564,17565]
operator: { [17568,17569]
===
match
---
operator: = [41384,41385]
operator: = [41388,41389]
===
match
---
name: self [15663,15667]
name: self [15667,15671]
===
match
---
string: "test start date filter" [19265,19289]
string: "test start date filter" [19269,19293]
===
match
---
operator: , [38433,38434]
operator: , [38437,38438]
===
match
---
name: dt [30703,30705]
name: dt [30707,30709]
===
match
---
atom_expr [16479,16571]
atom_expr [16483,16575]
===
match
---
atom_expr [22267,22434]
atom_expr [22271,22438]
===
match
---
operator: = [22415,22416]
operator: = [22419,22420]
===
match
---
name: test_should_raise_404_not_found_task [41155,41191]
name: test_should_raise_404_not_found_task [41159,41195]
===
match
---
trailer [16011,16044]
trailer [16015,16048]
===
match
---
name: DagBag [931,937]
name: DagBag [916,922]
===
match
---
name: expected [25137,25145]
name: expected [25141,25149]
===
match
---
expr_stmt [33548,33677]
expr_stmt [33552,33681]
===
match
---
operator: } [25013,25014]
operator: } [25017,25018]
===
match
---
string: "test duration filter ~" [13048,13072]
string: "test duration filter ~" [13052,13076]
===
match
---
atom [22736,22796]
atom [22740,22800]
===
match
---
name: json [25119,25123]
name: json [25123,25127]
===
match
---
expr_stmt [16471,16571]
expr_stmt [16475,16575]
===
match
---
atom [1942,2007]
atom [1970,2035]
===
match
---
decorators [22638,22891]
decorators [22642,22895]
===
match
---
operator: , [20000,20001]
operator: , [20004,20005]
===
match
---
string: "test end date filter" [18731,18753]
string: "test end date filter" [18735,18757]
===
match
---
operator: = [40103,40104]
operator: = [40107,40108]
===
match
---
trailer [23139,23290]
trailer [23143,23294]
===
match
---
operator: , [5255,5256]
operator: , [5283,5284]
===
match
---
name: self [31819,31823]
name: self [31823,31827]
===
match
---
trailer [16265,16272]
trailer [16269,16276]
===
match
---
atom [14803,14828]
atom [14807,14832]
===
match
---
operator: , [19726,19727]
operator: , [19730,19731]
===
match
---
atom [14435,14458]
atom [14439,14462]
===
match
---
operator: , [25860,25861]
operator: , [25864,25865]
===
match
---
operator: = [16383,16384]
operator: = [16387,16388]
===
match
---
operator: , [8805,8806]
operator: , [8817,8818]
===
match
---
assert_stmt [37393,37427]
assert_stmt [37397,37431]
===
match
---
string: "" [5463,5465]
string: "" [5491,5493]
===
match
---
string: "include_parentdag" [30353,30372]
string: "include_parentdag" [30357,30376]
===
match
---
trailer [32928,32936]
trailer [32932,32940]
===
match
---
trailer [25710,25720]
trailer [25714,25724]
===
match
---
operator: = [35781,35782]
operator: = [35785,35786]
===
match
---
name: response [40484,40492]
name: response [40488,40496]
===
match
---
name: expected_ti [15981,15992]
name: expected_ti [15985,15996]
===
match
---
parameters [35636,35642]
parameters [35640,35646]
===
match
---
operator: , [40015,40016]
operator: , [40019,40020]
===
match
---
operator: , [17999,18000]
operator: , [18003,18004]
===
match
---
operator: + [30701,30702]
operator: + [30705,30706]
===
match
---
operator: = [1455,1456]
operator: = [1483,1484]
===
match
---
trailer [2950,2952]
trailer [2978,2980]
===
match
---
operator: , [24790,24791]
operator: , [24794,24795]
===
match
---
operator: , [32156,32157]
operator: , [32160,32161]
===
match
---
operator: + [20143,20144]
operator: + [20147,20148]
===
match
---
testlist_comp [19329,19522]
testlist_comp [19333,19526]
===
match
---
assert_stmt [21309,21373]
assert_stmt [21313,21377]
===
match
---
operator: , [21607,21608]
operator: , [21611,21612]
===
match
---
param [21876,21883]
param [21880,21887]
===
match
---
name: session [36944,36951]
name: session [36948,36955]
===
match
---
name: status_code [40493,40504]
name: status_code [40497,40508]
===
match
---
testlist_comp [27022,27440]
testlist_comp [27026,27444]
===
match
---
operator: { [38570,38571]
operator: { [38574,38575]
===
match
---
operator: = [23271,23272]
operator: = [23275,23276]
===
match
---
fstring [11876,11954]
fstring [11880,11958]
===
match
---
string: "execution_date" [29939,29955]
string: "execution_date" [29943,29959]
===
match
---
param [22956,22968]
param [22960,22972]
===
match
---
name: dag_id [36965,36971]
name: dag_id [36969,36975]
===
match
---
name: post [21020,21024]
name: post [21024,21028]
===
match
---
string: "test_no_permissions" [17100,17121]
string: "test_no_permissions" [17104,17125]
===
match
---
name: response [16435,16443]
name: response [16439,16447]
===
match
---
number: 200 [16459,16462]
number: 200 [16463,16466]
===
match
---
atom_expr [29978,29998]
atom_expr [29982,30002]
===
match
---
suite [1559,2196]
suite [1587,2224]
===
match
---
name: create_task_instances [31540,31561]
name: create_task_instances [31544,31565]
===
match
---
atom_expr [32584,32604]
atom_expr [32588,32608]
===
match
---
string: 'detail' [43274,43282]
string: 'detail' [43278,43286]
===
match
---
operator: @ [20638,20639]
operator: @ [20642,20643]
===
match
---
operator: , [39682,39683]
operator: , [39686,39687]
===
match
---
trailer [16161,16170]
trailer [16165,16174]
===
match
---
operator: , [25420,25421]
operator: , [25424,25425]
===
match
---
operator: @ [42844,42845]
operator: @ [42848,42849]
===
match
---
operator: { [19464,19465]
operator: { [19468,19469]
===
match
---
operator: = [29995,29996]
operator: = [29999,30000]
===
match
---
string: "end_date" [18925,18935]
string: "end_date" [18929,18939]
===
match
---
operator: } [17121,17122]
operator: } [17125,17126]
===
match
---
name: DEFAULT_DATETIME_1 [28528,28546]
name: DEFAULT_DATETIME_1 [28532,28550]
===
match
---
operator: , [37040,37041]
operator: , [37044,37045]
===
match
---
expr_stmt [33362,33538]
expr_stmt [33366,33542]
===
match
---
operator: = [35661,35662]
operator: = [35665,35666]
===
match
---
operator: , [5890,5891]
operator: , [5918,5919]
===
match
---
number: 1 [18899,18900]
number: 1 [18903,18904]
===
match
---
name: json [16664,16668]
name: json [16668,16672]
===
match
---
name: FAILED [30216,30222]
name: FAILED [30220,30226]
===
match
---
name: DEFAULT_DATETIME_1 [19898,19916]
name: DEFAULT_DATETIME_1 [19902,19920]
===
match
---
string: "dry_run" [31249,31258]
string: "dry_run" [31253,31262]
===
match
---
string: "state" [5828,5835]
string: "state" [5856,5863]
===
match
---
name: json [23622,23626]
name: json [23626,23630]
===
match
---
atom [29252,29288]
atom [29256,29292]
===
match
---
operator: , [30379,30380]
operator: , [30383,30384]
===
match
---
operator: = [16760,16761]
operator: = [16764,16765]
===
match
---
suite [42952,43296]
suite [42956,43300]
===
match
---
operator: , [30515,30516]
operator: , [30519,30520]
===
match
---
argument [4253,4298]
argument [4281,4326]
===
match
---
arglist [7664,7814]
arglist [7676,7826]
===
match
---
name: DEFAULT_DATETIME_1 [18937,18955]
name: DEFAULT_DATETIME_1 [18941,18959]
===
match
---
trailer [40587,40594]
trailer [40591,40598]
===
match
---
operator: == [41781,41783]
operator: == [41785,41787]
===
match
---
operator: } [11060,11061]
operator: } [11064,11065]
===
match
---
arith_expr [30682,30723]
arith_expr [30686,30727]
===
match
---
string: 'REMOTE_USER' [40048,40061]
string: 'REMOTE_USER' [40052,40065]
===
match
---
name: min [3603,3606]
name: min [3631,3634]
===
match
---
name: execution_date [7476,7490]
name: execution_date [7488,7502]
===
match
---
operator: , [31475,31476]
operator: , [31479,31480]
===
match
---
operator: , [42318,42319]
operator: , [42322,42323]
===
match
---
operator: , [36193,36194]
operator: , [36197,36198]
===
match
---
atom [14014,14037]
atom [14018,14041]
===
match
---
name: response [5146,5154]
name: response [5174,5182]
===
match
---
operator: , [18979,18980]
operator: , [18983,18984]
===
match
---
atom_expr [25110,25133]
atom_expr [25114,25137]
===
match
---
testlist_comp [15232,15352]
testlist_comp [15236,15356]
===
match
---
decorators [36105,36545]
decorators [36109,36549]
===
match
---
atom_expr [2323,2340]
atom_expr [2351,2368]
===
match
---
operator: , [42822,42823]
operator: , [42826,42827]
===
match
---
operator: } [9515,9516]
operator: } [9519,9520]
===
match
---
operator: , [37347,37348]
operator: , [37351,37352]
===
match
---
trailer [9006,9008]
trailer [9010,9012]
===
match
---
name: post [43028,43032]
name: post [43032,43036]
===
match
---
operator: { [12733,12734]
operator: { [12737,12738]
===
match
---
operator: , [8684,8685]
operator: , [8696,8697]
===
match
---
simple_stmt [1098,1142]
simple_stmt [1126,1170]
===
match
---
string: "execution_date" [28795,28811]
string: "execution_date" [28799,28815]
===
match
---
simple_stmt [23784,24031]
simple_stmt [23788,24035]
===
match
---
atom_expr [27404,27416]
atom_expr [27408,27420]
===
match
---
expr_stmt [32176,32210]
expr_stmt [32180,32214]
===
match
---
operator: { [26700,26701]
operator: { [26704,26705]
===
match
---
string: "hostname" [5451,5461]
string: "hostname" [5479,5489]
===
match
---
number: 1 [29642,29643]
number: 1 [29646,29647]
===
match
---
atom [27519,27580]
atom [27523,27584]
===
match
---
parameters [39895,39901]
parameters [39899,39905]
===
match
---
operator: { [21625,21626]
operator: { [21629,21630]
===
match
---
operator: } [19744,19745]
operator: } [19748,19749]
===
match
---
operator: } [28746,28747]
operator: } [28750,28751]
===
match
---
dictorsetmaker [2521,2796]
dictorsetmaker [2549,2824]
===
match
---
operator: } [36044,36045]
operator: } [36048,36049]
===
match
---
operator: } [19198,19199]
operator: } [19202,19203]
===
match
---
operator: } [12469,12470]
operator: } [12473,12474]
===
match
---
operator: = [35241,35242]
operator: = [35245,35246]
===
match
---
operator: = [19438,19439]
operator: = [19442,19443]
===
match
---
number: 4 [20246,20247]
number: 4 [20250,20251]
===
match
---
name: session [4734,4741]
name: session [4762,4769]
===
match
---
name: str [3184,3187]
name: str [3212,3215]
===
match
---
param [31512,31519]
param [31516,31523]
===
match
---
operator: } [43163,43164]
operator: } [43167,43168]
===
match
---
name: DEFAULT_DATETIME_STR_2 [26771,26793]
name: DEFAULT_DATETIME_STR_2 [26775,26797]
===
match
---
string: "PythonOperator" [6754,6770]
string: "PythonOperator" [6774,6790]
===
match
---
fstring_expr [31864,31877]
fstring_expr [31868,31881]
===
match
---
name: permissions [1695,1706]
name: permissions [1723,1734]
===
match
---
name: configured_app [1523,1537]
name: configured_app [1551,1565]
===
match
---
trailer [21024,21175]
trailer [21028,21179]
===
match
---
name: create_task_instances [20808,20829]
name: create_task_instances [20812,20833]
===
match
---
name: session [4868,4875]
name: session [4896,4903]
===
match
---
operator: , [38257,38258]
operator: , [38261,38262]
===
match
---
operator: + [26351,26352]
operator: + [26355,26356]
===
match
---
name: DEFAULT_DATETIME_STR_2 [12485,12507]
name: DEFAULT_DATETIME_STR_2 [12489,12511]
===
match
---
trailer [32732,32742]
trailer [32736,32746]
===
match
---
operator: { [18447,18448]
operator: { [18451,18452]
===
match
---
string: "execution_date" [20106,20122]
string: "execution_date" [20110,20126]
===
match
---
name: days [30893,30897]
name: days [30897,30901]
===
match
---
operator: , [1371,1372]
operator: , [1399,1400]
===
match
---
arglist [1615,2019]
arglist [1643,2047]
===
match
---
argument [32889,32895]
argument [32893,32899]
===
match
---
testlist_comp [9694,10230]
testlist_comp [9698,10234]
===
match
---
comparison [16642,16687]
comparison [16646,16691]
===
match
---
dictorsetmaker [10397,10452]
dictorsetmaker [10401,10456]
===
match
---
operator: } [34468,34469]
operator: } [34472,34473]
===
match
---
operator: , [8254,8255]
operator: , [8266,8267]
===
match
---
atom_expr [1358,1378]
atom_expr [1386,1406]
===
match
---
operator: , [4569,4570]
operator: , [4597,4598]
===
match
---
operator: , [3215,3216]
operator: , [3243,3244]
===
match
---
fstring_end: " [10792,10793]
fstring_end: " [10796,10797]
===
match
---
operator: , [14894,14895]
operator: , [14898,14899]
===
match
---
operator: , [27557,27558]
operator: , [27561,27562]
===
match
---
trailer [9105,9109]
trailer [9109,9113]
===
match
---
trailer [23314,23326]
trailer [23318,23330]
===
match
---
operator: { [6110,6111]
operator: { [6130,6131]
===
match
---
number: 1 [19997,19998]
number: 1 [20001,20002]
===
match
---
name: self [21807,21811]
name: self [21811,21815]
===
match
---
string: "example_python_operator" [8478,8503]
string: "example_python_operator" [8490,8515]
===
match
---
name: expected [37470,37478]
name: expected [37474,37482]
===
match
---
string: "pool" [14391,14397]
string: "pool" [14395,14401]
===
match
---
name: response [22479,22487]
name: response [22483,22491]
===
match
---
operator: , [25598,25599]
operator: , [25602,25603]
===
match
---
atom_expr [12267,12287]
atom_expr [12271,12291]
===
match
---
atom [18847,18902]
atom [18851,18906]
===
match
---
name: json [41380,41384]
name: json [41384,41388]
===
match
---
dictorsetmaker [24992,25013]
dictorsetmaker [24996,25017]
===
match
---
string: "REMOTE_USER" [31930,31943]
string: "REMOTE_USER" [31934,31947]
===
match
---
name: SUCCESS [18197,18204]
name: SUCCESS [18201,18208]
===
match
---
name: DEFAULT_DATETIME_1 [27041,27059]
name: DEFAULT_DATETIME_1 [27045,27063]
===
match
---
name: days [18971,18975]
name: days [18975,18979]
===
match
---
argument [18971,18977]
argument [18975,18981]
===
match
---
atom [29355,30413]
atom [29359,30417]
===
match
---
name: dag_bag [37136,37143]
name: dag_bag [37140,37147]
===
match
---
name: get [16273,16276]
name: get [16277,16280]
===
match
---
name: response [22256,22264]
name: response [22260,22268]
===
match
---
param [15593,15595]
param [15597,15599]
===
match
---
number: 2 [27598,27599]
number: 2 [27602,27603]
===
match
---
operator: } [11542,11543]
operator: } [11546,11547]
===
match
---
expr_stmt [2490,2806]
expr_stmt [2518,2834]
===
match
---
operator: , [17389,17390]
operator: , [17393,17394]
===
match
---
trailer [11042,11052]
trailer [11046,11056]
===
match
---
atom_expr [4886,4921]
atom_expr [4914,4949]
===
match
---
operator: , [40325,40326]
operator: , [40329,40330]
===
match
---
atom_expr [32876,32896]
atom_expr [32880,32900]
===
match
---
operator: } [34706,34707]
operator: } [34710,34711]
===
match
---
number: 100 [13125,13128]
number: 100 [13129,13132]
===
match
---
testlist_comp [24605,24689]
testlist_comp [24609,24693]
===
match
---
operator: , [8732,8733]
operator: , [8744,8745]
===
match
---
operator: = [11136,11137]
operator: = [11140,11141]
===
match
---
arglist [16206,16240]
arglist [16210,16244]
===
match
---
trailer [20147,20157]
trailer [20151,20161]
===
match
---
atom [9905,9966]
atom [9909,9970]
===
match
---
operator: , [42931,42932]
operator: , [42935,42936]
===
match
---
name: DEFAULT_DATETIME_1 [1337,1355]
name: DEFAULT_DATETIME_1 [1365,1383]
===
match
---
operator: } [19520,19521]
operator: } [19524,19525]
===
match
---
number: 200 [18538,18541]
number: 200 [18542,18545]
===
match
---
simple_stmt [6165,6366]
simple_stmt [6185,6386]
===
match
---
argument [39148,39159]
argument [39152,39163]
===
match
---
operator: { [6441,6442]
operator: { [6461,6462]
===
match
---
atom [19307,19540]
atom [19311,19544]
===
match
---
comparison [35024,35072]
comparison [35028,35076]
===
match
---
name: json [35834,35838]
name: json [35838,35842]
===
match
---
fstring [10132,10192]
fstring [10136,10196]
===
match
---
name: timedelta [30158,30167]
name: timedelta [30162,30171]
===
match
---
operator: { [32819,32820]
operator: { [32823,32824]
===
match
---
atom [5206,5973]
atom [5234,5993]
===
match
---
name: self [16135,16139]
name: self [16139,16143]
===
match
---
operator: = [9322,9323]
operator: = [9326,9327]
===
match
---
operator: , [26165,26166]
operator: , [26169,26170]
===
match
---
name: json [32061,32065]
name: json [32065,32069]
===
match
---
operator: } [23939,23940]
operator: } [23943,23944]
===
match
---
operator: = [3098,3099]
operator: = [3126,3127]
===
match
---
atom_expr [27796,27808]
atom_expr [27800,27812]
===
match
---
name: ti_extras [3784,3793]
name: ti_extras [3812,3821]
===
match
---
name: test_should_raise_403_forbidden [23737,23768]
name: test_should_raise_403_forbidden [23741,23772]
===
match
---
string: "queue" [17459,17466]
string: "queue" [17463,17470]
===
match
---
trailer [19512,19520]
trailer [19516,19524]
===
match
---
name: DEFAULT_DATETIME_1 [40221,40239]
name: DEFAULT_DATETIME_1 [40225,40243]
===
match
---
comparison [38503,38842]
comparison [38507,38846]
===
match
---
atom_expr [7368,7560]
atom_expr [7380,7572]
===
match
---
decorator [21379,21706]
decorator [21383,21710]
===
match
---
atom_expr [32730,32750]
atom_expr [32734,32754]
===
match
---
string: "REMOTE_USER" [23231,23244]
string: "REMOTE_USER" [23235,23248]
===
match
---
name: post [41230,41234]
name: post [41234,41238]
===
match
---
name: provide_session [24713,24728]
name: provide_session [24717,24732]
===
match
---
argument [27909,27915]
argument [27913,27919]
===
match
---
string: "test_queue_1" [15242,15256]
string: "test_queue_1" [15246,15260]
===
match
---
atom_expr [2457,2470]
atom_expr [2485,2498]
===
match
---
operator: { [29181,29182]
operator: { [29185,29186]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances?end_date_gte" [12369,12422]
string: "/api/v1/dags/~/dagRuns/~/taskInstances?end_date_gte" [12373,12426]
===
match
---
string: '2020-11-10T12:42:39.442973' [24142,24170]
string: '2020-11-10T12:42:39.442973' [24146,24174]
===
match
---
atom_expr [33069,33082]
atom_expr [33073,33086]
===
match
---
string: "example_python_operator" [26140,26165]
string: "example_python_operator" [26144,26169]
===
match
---
operator: , [42546,42547]
operator: , [42550,42551]
===
match
---
trailer [5960,5962]
trailer [5980,5982]
===
match
---
name: json [23954,23958]
name: json [23958,23962]
===
match
---
testlist_comp [11449,11992]
testlist_comp [11453,11996]
===
match
---
operator: , [5624,5625]
operator: , [5652,5653]
===
match
---
trailer [4741,4745]
trailer [4769,4773]
===
match
---
atom_expr [37443,37466]
atom_expr [37447,37470]
===
match
---
parameters [7264,7279]
parameters [7276,7291]
===
match
---
name: DagRunType [1174,1184]
name: DagRunType [1202,1212]
===
match
---
dictorsetmaker [2399,2471]
dictorsetmaker [2427,2499]
===
match
---
operator: , [41733,41734]
operator: , [41737,41738]
===
match
---
operator: , [16213,16214]
operator: , [16217,16218]
===
match
---
atom_expr [26253,26265]
atom_expr [26257,26269]
===
match
---
number: 2 [2639,2640]
number: 2 [2667,2668]
===
match
---
atom [18287,18319]
atom [18291,18323]
===
match
---
name: query [7341,7346]
name: query [7353,7358]
===
match
---
simple_stmt [904,969]
simple_stmt [889,954]
===
match
---
simple_stmt [43253,43296]
simple_stmt [43257,43300]
===
match
---
operator: } [18318,18319]
operator: } [18322,18323]
===
match
---
argument [3081,3103]
argument [3109,3131]
===
match
---
name: days [20241,20245]
name: days [20245,20249]
===
match
---
arglist [23825,24020]
arglist [23829,24024]
===
match
---
argument [39224,39236]
argument [39228,39240]
===
match
---
name: ti_extras [21904,21913]
name: ti_extras [21908,21917]
===
match
---
param [1538,1557]
param [1566,1585]
===
match
---
string: "start_date_lte" [24314,24330]
string: "start_date_lte" [24318,24334]
===
match
---
trailer [16773,16777]
trailer [16777,16781]
===
match
---
string: "clear only failed" [27646,27665]
string: "clear only failed" [27650,27669]
===
match
---
argument [36822,36828]
argument [36826,36832]
===
match
---
suite [4877,5974]
suite [4905,5994]
===
match
---
operator: = [3927,3928]
operator: = [3955,3956]
===
match
---
string: "Naive datetime is disallowed" [24173,24203]
string: "Naive datetime is disallowed" [24177,24207]
===
match
---
name: timedelta [11679,11688]
name: timedelta [11683,11692]
===
match
---
arglist [41248,41734]
arglist [41252,41738]
===
match
---
operator: , [12006,12007]
operator: , [12010,12011]
===
match
---
number: 2 [18976,18977]
number: 2 [18980,18981]
===
match
---
operator: , [29821,29822]
operator: , [29825,29826]
===
match
---
name: counter [3521,3528]
name: counter [3549,3556]
===
match
---
testlist_comp [21442,21673]
testlist_comp [21446,21677]
===
match
---
operator: = [43182,43183]
operator: = [43186,43187]
===
match
---
operator: , [26639,26640]
operator: , [26643,26644]
===
match
---
operator: , [18307,18308]
operator: , [18311,18312]
===
match
---
param [15645,15652]
param [15649,15656]
===
match
---
name: payload [24792,24799]
name: payload [24796,24803]
===
match
---
operator: , [20332,20333]
operator: , [20336,20337]
===
match
---
name: client [23800,23806]
name: client [23804,23810]
===
match
---
name: len [32048,32051]
name: len [32052,32055]
===
match
---
name: client [23538,23544]
name: client [23542,23548]
===
match
---
string: "new_state" [38397,38408]
string: "new_state" [38401,38412]
===
match
---
trailer [38954,38964]
trailer [38958,38968]
===
match
---
number: 2 [11401,11402]
number: 2 [11405,11406]
===
match
---
trailer [13571,13579]
trailer [13575,13583]
===
match
---
operator: == [22593,22595]
operator: == [22597,22599]
===
match
---
trailer [4663,4669]
trailer [4691,4697]
===
match
---
trailer [26258,26265]
trailer [26262,26269]
===
match
---
parameters [32151,32166]
parameters [32155,32170]
===
match
---
operator: { [36241,36242]
operator: { [36245,36246]
===
match
---
comparison [22450,22477]
comparison [22454,22481]
===
match
---
number: 100 [2662,2665]
number: 100 [2690,2693]
===
match
---
fstring_end: " [12508,12509]
fstring_end: " [12512,12513]
===
match
---
atom_expr [20542,20562]
atom_expr [20546,20566]
===
match
---
name: create_task_instances [6063,6084]
name: create_task_instances [6083,6104]
===
match
---
operator: } [10190,10191]
operator: } [10194,10195]
===
match
---
atom_expr [38460,38480]
atom_expr [38464,38484]
===
match
---
operator: { [30815,30816]
operator: { [30819,30820]
===
match
---
trailer [9957,9965]
trailer [9961,9969]
===
match
---
name: State [26585,26590]
name: State [26589,26594]
===
match
---
dictorsetmaker [19624,19727]
dictorsetmaker [19628,19731]
===
match
---
name: session [7569,7576]
name: session [7581,7588]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [6205,6299]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [6225,6319]
===
match
---
operator: , [29163,29164]
operator: , [29167,29168]
===
match
---
name: client [33378,33384]
name: client [33382,33388]
===
match
---
name: status_code [16444,16455]
name: status_code [16448,16459]
===
match
---
atom_expr [9236,9256]
atom_expr [9240,9260]
===
match
---
trailer [3866,3873]
trailer [3894,3901]
===
match
---
string: "duration" [12656,12666]
string: "duration" [12660,12670]
===
match
---
operator: } [24170,24171]
operator: } [24174,24175]
===
match
---
atom [18181,18205]
atom [18185,18209]
===
match
---
string: "Naive datetime is disallowed" [36379,36409]
string: "Naive datetime is disallowed" [36383,36413]
===
match
---
operator: } [30792,30793]
operator: } [30796,30797]
===
match
---
string: "test_pool_1" [14399,14412]
string: "test_pool_1" [14403,14416]
===
match
---
comparison [15947,15992]
comparison [15951,15996]
===
match
---
trailer [9339,9527]
trailer [9343,9531]
===
match
---
funcdef [15559,16060]
funcdef [15563,16064]
===
match
---
assert_stmt [35017,35072]
assert_stmt [35021,35076]
===
match
---
operator: , [36377,36378]
operator: , [36381,36382]
===
match
---
operator: = [26370,26371]
operator: = [26374,26375]
===
match
---
atom [35782,35820]
atom [35786,35824]
===
match
---
name: self [2535,2539]
name: self [2563,2567]
===
match
---
operator: = [11693,11694]
operator: = [11697,11698]
===
match
---
name: test_should_respond_200_when_task_instance_properties_are_none [21735,21797]
name: test_should_respond_200_when_task_instance_properties_are_none [21739,21801]
===
match
---
number: 2 [28091,28092]
number: 2 [28095,28096]
===
match
---
argument [33283,33302]
argument [33287,33306]
===
match
---
name: payload [20752,20759]
name: payload [20756,20763]
===
match
---
operator: , [25343,25344]
operator: , [25347,25348]
===
match
---
atom [1790,1849]
atom [1818,1877]
===
match
---
arith_expr [29780,29821]
arith_expr [29784,29825]
===
match
---
operator: { [9822,9823]
operator: { [9826,9827]
===
match
---
operator: , [33269,33270]
operator: , [33273,33274]
===
match
---
name: dag_id [4174,4180]
name: dag_id [4202,4208]
===
match
---
trailer [23811,24030]
trailer [23815,24034]
===
match
---
name: days [25544,25548]
name: days [25548,25552]
===
match
---
name: DEFAULT_DATETIME_1 [27767,27785]
name: DEFAULT_DATETIME_1 [27771,27789]
===
match
---
dictorsetmaker [40756,41077]
dictorsetmaker [40760,41081]
===
match
---
argument [11132,11138]
argument [11136,11142]
===
match
---
operator: , [14522,14523]
operator: , [14526,14527]
===
match
---
string: "email_sent" [8558,8570]
string: "email_sent" [8570,8582]
===
match
---
string: "dry_run" [26722,26731]
string: "dry_run" [26726,26735]
===
match
---
operator: , [7269,7270]
operator: , [7281,7282]
===
match
---
arglist [3923,3952]
arglist [3951,3980]
===
match
---
trailer [33122,33144]
trailer [33126,33148]
===
match
---
string: "operator" [5507,5517]
string: "operator" [5535,5545]
===
match
---
atom [19793,20616]
atom [19797,20620]
===
match
---
name: app [2820,2823]
name: app [2848,2851]
===
match
---
fstring [10710,10793]
fstring [10714,10797]
===
match
---
operator: , [14503,14504]
operator: , [14507,14508]
===
match
---
trailer [37825,37832]
trailer [37829,37836]
===
match
---
atom [17287,17641]
atom [17291,17645]
===
match
---
operator: = [25548,25549]
operator: = [25552,25553]
===
match
---
string: "test_pool_3" [17830,17843]
string: "test_pool_3" [17834,17847]
===
match
---
param [37676,37691]
param [37680,37695]
===
match
---
trailer [3346,3354]
trailer [3374,3382]
===
match
---
number: 2 [21671,21672]
number: 2 [21675,21676]
===
match
---
name: environ_overrides [17066,17083]
name: environ_overrides [17070,17087]
===
match
---
name: query [37806,37811]
name: query [37810,37815]
===
match
---
operator: } [8804,8805]
operator: } [8816,8817]
===
match
---
parameters [9297,9303]
parameters [9301,9307]
===
match
---
operator: , [19764,19765]
operator: , [19768,19769]
===
match
---
name: response [23416,23424]
name: response [23420,23428]
===
match
---
operator: = [2638,2639]
operator: = [2666,2667]
===
match
---
testlist_comp [24409,24489]
testlist_comp [24413,24493]
===
match
---
name: session [7316,7323]
name: session [7328,7335]
===
match
---
operator: , [5341,5342]
operator: , [5369,5370]
===
match
---
atom [18068,18224]
atom [18072,18228]
===
match
---
atom [13511,13534]
atom [13515,13538]
===
match
---
name: days [26366,26370]
name: days [26370,26374]
===
match
---
name: State [25763,25768]
name: State [25767,25772]
===
match
---
simple_stmt [41753,41788]
simple_stmt [41757,41792]
===
match
---
import_name [849,862]
import_name [834,847]
===
match
---
operator: , [18050,18051]
operator: , [18054,18055]
===
match
---
operator: } [25620,25621]
operator: } [25624,25625]
===
match
---
operator: , [32790,32791]
operator: , [32794,32795]
===
match
---
operator: = [22265,22266]
operator: = [22269,22270]
===
match
---
operator: , [8577,8578]
operator: , [8589,8590]
===
match
---
operator: { [32673,32674]
operator: { [32677,32678]
===
match
---
fstring_expr [12484,12508]
fstring_expr [12488,12512]
===
match
---
string: "include_past" [41659,41673]
string: "include_past" [41663,41677]
===
match
---
name: main_dag [31603,31611]
name: main_dag [31607,31615]
===
match
---
operator: } [12507,12508]
operator: } [12511,12512]
===
match
---
operator: = [2861,2862]
operator: = [2889,2890]
===
match
---
string: "execution_date" [32983,32999]
string: "execution_date" [32987,33003]
===
match
---
operator: { [36676,36677]
operator: { [36680,36681]
===
match
---
operator: , [38418,38419]
operator: , [38422,38423]
===
match
---
dictorsetmaker [9763,9799]
dictorsetmaker [9767,9803]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [21038,21083]
string: "/api/v1/dags/~/dagRuns/~/taskInstances/list" [21042,21087]
===
match
---
name: response [6424,6432]
name: response [6444,6452]
===
match
---
atom [9762,9800]
atom [9766,9804]
===
match
---
trailer [6180,6187]
trailer [6200,6207]
===
match
---
atom_expr [4061,4076]
atom_expr [4089,4104]
===
match
---
operator: = [2257,2258]
operator: = [2285,2286]
===
match
---
name: self [7289,7293]
name: self [7301,7305]
===
match
---
operator: , [10982,10983]
operator: , [10986,10987]
===
match
---
testlist_comp [36676,36885]
testlist_comp [36680,36889]
===
match
---
atom [15279,15304]
atom [15283,15308]
===
match
---
dotted_name [21380,21400]
dotted_name [21384,21404]
===
match
---
name: DEFAULT_DATETIME_STR_2 [25951,25973]
name: DEFAULT_DATETIME_STR_2 [25955,25977]
===
match
---
simple_stmt [969,1010]
simple_stmt [954,995]
===
match
---
string: "2020-01-01T00:00:00+00:00" [8613,8640]
string: "2020-01-01T00:00:00+00:00" [8625,8652]
===
match
---
name: timedelta [2558,2567]
name: timedelta [2586,2595]
===
match
---
name: response [23112,23120]
name: response [23116,23124]
===
match
---
atom [34721,34945]
atom [34725,34949]
===
match
---
trailer [2041,2109]
trailer [2069,2137]
===
match
---
string: "latest_only" [21638,21651]
string: "latest_only" [21642,21655]
===
match
---
operator: , [35913,35914]
operator: , [35917,35918]
===
match
---
operator: , [3974,3975]
operator: , [4002,4003]
===
match
---
name: session [22979,22986]
name: session [22983,22990]
===
match
---
name: DEFAULT_DATETIME_1 [19479,19497]
name: DEFAULT_DATETIME_1 [19483,19501]
===
match
---
string: "Naive datetime is disallowed" [36195,36225]
string: "Naive datetime is disallowed" [36199,36229]
===
match
---
decorator [41793,42840]
decorator [41797,42844]
===
match
---
operator: , [15751,15752]
operator: , [15755,15756]
===
match
---
string: "pool" [14436,14442]
string: "pool" [14440,14446]
===
match
---
name: request_dag [31865,31876]
name: request_dag [31869,31880]
===
match
---
trailer [32504,32512]
trailer [32508,32516]
===
match
---
operator: = [29641,29642]
operator: = [29645,29646]
===
match
---
string: "execution_date" [39560,39576]
string: "execution_date" [39564,39580]
===
match
---
atom [2507,2806]
atom [2535,2834]
===
match
---
number: 1 [9880,9881]
number: 1 [9884,9885]
===
match
---
trailer [10513,10523]
trailer [10517,10527]
===
match
---
operator: , [41557,41558]
operator: , [41561,41562]
===
match
---
arglist [35273,35556]
arglist [35277,35560]
===
match
---
comparison [37443,37478]
comparison [37447,37482]
===
match
---
simple_stmt [7833,7868]
simple_stmt [7845,7880]
===
match
---
testlist_comp [13112,13208]
testlist_comp [13116,13212]
===
match
---
trailer [23549,23698]
trailer [23553,23702]
===
match
---
operator: = [23958,23959]
operator: = [23962,23963]
===
match
---
operator: , [17641,17642]
operator: , [17645,17646]
===
match
---
name: failed_dag_runs [35150,35165]
name: failed_dag_runs [35154,35169]
===
match
---
name: DEFAULT_DATETIME_1 [20521,20539]
name: DEFAULT_DATETIME_1 [20525,20543]
===
match
---
operator: , [25300,25301]
operator: , [25304,25305]
===
match
---
number: 2 [26548,26549]
number: 2 [26552,26553]
===
match
---
string: "Naive datetime is disallowed" [24267,24297]
string: "Naive datetime is disallowed" [24271,24301]
===
match
---
argument [27362,27368]
argument [27366,27372]
===
match
---
operator: { [11511,11512]
operator: { [11515,11516]
===
match
---
string: "execution_date" [32691,32707]
string: "execution_date" [32695,32711]
===
match
---
operator: , [10830,10831]
operator: , [10834,10835]
===
match
---
string: "start_date" [10949,10961]
string: "start_date" [10953,10965]
===
match
---
operator: , [39058,39059]
operator: , [39062,39063]
===
match
---
operator: , [26420,26421]
operator: , [26424,26425]
===
match
---
number: 4 [30173,30174]
number: 4 [30177,30178]
===
match
---
trailer [15667,15689]
trailer [15671,15693]
===
match
---
trailer [7892,7897]
trailer [7904,7909]
===
match
---
dictorsetmaker [14757,14780]
dictorsetmaker [14761,14784]
===
match
---
operator: , [12329,12330]
operator: , [12333,12334]
===
match
---
operator: } [11619,11620]
operator: } [11623,11624]
===
match
---
dictorsetmaker [13113,13128]
dictorsetmaker [13117,13132]
===
match
---
operator: , [3079,3080]
operator: , [3107,3108]
===
match
---
dictorsetmaker [21952,22036]
dictorsetmaker [21956,22040]
===
match
---
testlist_comp [18731,19219]
testlist_comp [18735,19223]
===
match
---
operator: , [10811,10812]
operator: , [10815,10816]
===
match
---
operator: , [21814,21815]
operator: , [21818,21819]
===
match
---
testlist_comp [12102,12289]
testlist_comp [12106,12293]
===
match
---
param [20705,20720]
param [20709,20724]
===
match
---
param [39896,39900]
param [39900,39904]
===
match
---
operator: + [18879,18880]
operator: + [18883,18884]
===
match
---
string: "pool" [17732,17738]
string: "pool" [17736,17742]
===
match
---
operator: , [5493,5494]
operator: , [5521,5522]
===
match
---
name: dt [31057,31059]
name: dt [31061,31063]
===
match
---
trailer [27409,27416]
trailer [27413,27420]
===
match
---
atom [12733,12750]
atom [12737,12754]
===
match
---
name: TestTaskInstanceEndpoint [25181,25205]
name: TestTaskInstanceEndpoint [25185,25209]
===
match
---
expr_stmt [3521,3541]
expr_stmt [3549,3569]
===
match
---
operator: , [20083,20084]
operator: , [20087,20088]
===
match
---
parameters [9067,9073]
parameters [9071,9077]
===
match
---
trailer [25436,25443]
trailer [25440,25447]
===
match
---
trailer [25720,25728]
trailer [25724,25732]
===
match
---
simple_stmt [7599,7616]
simple_stmt [7611,7628]
===
match
---
name: dt [11119,11121]
name: dt [11123,11125]
===
match
---
name: RUNNING [32783,32790]
name: RUNNING [32787,32794]
===
match
---
operator: , [27580,27581]
operator: , [27584,27585]
===
match
---
name: timedelta [20148,20157]
name: timedelta [20152,20161]
===
match
---
string: 'dag_id' [34025,34033]
string: 'dag_id' [34029,34037]
===
match
---
name: permissions [1943,1954]
name: permissions [1971,1982]
===
match
---
name: i [3816,3817]
name: i [3844,3845]
===
match
---
name: setattr [4025,4032]
name: setattr [4053,4060]
===
match
---
atom [43141,43164]
atom [43145,43168]
===
match
---
operator: = [31681,31682]
operator: = [31685,31686]
===
match
---
atom [20022,20083]
atom [20026,20087]
===
match
---
operator: { [23230,23231]
operator: { [23234,23235]
===
match
---
operator: , [42013,42014]
operator: , [42017,42018]
===
match
---
operator: { [25878,25879]
operator: { [25882,25883]
===
match
---
operator: + [28071,28072]
operator: + [28075,28076]
===
match
---
name: timedelta [33025,33034]
name: timedelta [33029,33038]
===
match
---
name: self [15587,15591]
name: self [15591,15595]
===
match
---
simple_stmt [16428,16463]
simple_stmt [16432,16467]
===
match
---
name: tasks [3495,3500]
name: tasks [3523,3528]
===
match
---
name: dag_id [4514,4520]
name: dag_id [4542,4548]
===
match
---
name: DEFAULT_DATETIME_STR_1 [19642,19664]
name: DEFAULT_DATETIME_STR_1 [19646,19668]
===
match
---
name: State [27796,27801]
name: State [27800,27805]
===
match
---
operator: , [13425,13426]
operator: , [13429,13430]
===
match
---
trailer [32586,32596]
trailer [32590,32600]
===
match
---
operator: = [22373,22374]
operator: = [22377,22378]
===
match
---
string: "max_tries" [6714,6725]
string: "max_tries" [6734,6745]
===
match
---
atom [5096,5119]
atom [5124,5147]
===
match
---
operator: == [43284,43286]
operator: == [43288,43290]
===
match
---
comparison [16008,16059]
comparison [16012,16063]
===
match
---
testlist_comp [18447,18543]
testlist_comp [18451,18547]
===
match
---
operator: , [24265,24266]
operator: , [24269,24270]
===
match
---
name: client [15830,15836]
name: client [15834,15840]
===
match
---
trailer [3783,3793]
trailer [3811,3821]
===
match
---
name: parameterized [889,902]
name: parameterized [874,887]
===
match
---
number: 0 [35145,35146]
number: 0 [35149,35150]
===
match
---
string: "test_pool_2" [14444,14457]
string: "test_pool_2" [14448,14461]
===
match
---
name: days [10524,10528]
name: days [10528,10532]
===
match
---
operator: , [15124,15125]
operator: , [15128,15129]
===
match
---
name: parameterized [24080,24093]
name: parameterized [24084,24097]
===
match
---
atom [30533,31166]
atom [30537,31170]
===
match
---
operator: } [38432,38433]
operator: } [38436,38437]
===
match
---
operator: , [9883,9884]
operator: , [9887,9888]
===
match
---
string: "execution_date" [19880,19896]
string: "execution_date" [19884,19900]
===
match
---
atom_expr [7840,7860]
atom_expr [7852,7872]
===
match
---
string: "REMOTE_USER" [33479,33492]
string: "REMOTE_USER" [33483,33496]
===
match
---
operator: == [15978,15980]
operator: == [15982,15984]
===
match
---
argument [23954,24019]
argument [23958,24023]
===
match
---
operator: , [41679,41680]
operator: , [41683,41684]
===
match
---
trailer [7346,7348]
trailer [7358,7360]
===
match
---
operator: , [17984,17985]
operator: , [17988,17989]
===
match
---
trailer [26542,26550]
trailer [26546,26554]
===
match
---
argument [6313,6354]
argument [6333,6374]
===
match
---
name: execution_date [4253,4267]
name: execution_date [4281,4295]
===
match
---
name: test_should_raise_403_forbidden [9266,9297]
name: test_should_raise_403_forbidden [9270,9301]
===
match
---
operator: } [26265,26266]
operator: } [26269,26270]
===
match
---
name: task_instances [33240,33254]
name: task_instances [33244,33258]
===
match
---
parameters [23506,23512]
parameters [23510,23516]
===
match
---
atom_expr [7569,7590]
atom_expr [7581,7602]
===
match
---
name: FAILED [30764,30770]
name: FAILED [30768,30774]
===
match
---
name: self [37710,37714]
name: self [37714,37718]
===
match
---
simple_stmt [23522,23699]
simple_stmt [23526,23703]
===
match
---
trailer [24895,24900]
trailer [24899,24904]
===
match
---
name: self [6034,6038]
name: self [6054,6058]
===
match
---
name: self [31741,31745]
name: self [31745,31749]
===
match
---
trailer [4280,4298]
trailer [4308,4326]
===
match
---
name: self [42918,42922]
name: self [42922,42926]
===
match
---
operator: , [12982,12983]
operator: , [12986,12987]
===
match
---
name: session [6040,6047]
name: session [6060,6067]
===
match
---
string: "state" [30201,30208]
string: "state" [30205,30212]
===
match
---
param [2284,2289]
param [2312,2317]
===
match
---
param [7265,7270]
param [7277,7282]
===
match
---
operator: , [26014,26015]
operator: , [26018,26019]
===
match
---
string: "hostname" [8146,8156]
string: "hostname" [8158,8168]
===
match
---
operator: { [21508,21509]
operator: { [21512,21513]
===
match
---
operator: -> [2306,2308]
operator: -> [2334,2336]
===
match
---
name: getuser [8999,9006]
name: getuser [9003,9010]
===
match
---
string: "test_no_permissions" [23918,23939]
string: "test_no_permissions" [23922,23943]
===
match
---
operator: , [27614,27615]
operator: , [27618,27619]
===
match
---
trailer [38468,38480]
trailer [38472,38484]
===
match
---
operator: { [24219,24220]
operator: { [24223,24224]
===
match
---
atom [11565,11620]
atom [11569,11624]
===
match
---
string: "example_subdag_operator.section-1" [30282,30317]
string: "example_subdag_operator.section-1" [30286,30321]
===
match
---
operator: , [39134,39135]
operator: , [39138,39139]
===
match
---
strings [10613,10793]
strings [10617,10797]
===
match
---
trailer [21278,21283]
trailer [21282,21287]
===
match
---
atom [14368,14522]
atom [14372,14526]
===
match
---
operator: , [15501,15502]
operator: , [15505,15506]
===
match
---
testlist_comp [10877,11403]
testlist_comp [10881,11407]
===
match
---
atom [10258,10845]
atom [10262,10849]
===
match
---
atom_expr [39349,39825]
atom_expr [39353,39829]
===
match
---
argument [15765,15794]
argument [15769,15798]
===
match
---
operator: , [11738,11739]
operator: , [11742,11743]
===
match
---
simple_stmt [2030,2126]
simple_stmt [2058,2154]
===
match
---
simple_stmt [849,863]
simple_stmt [834,848]
===
match
---
operator: , [4866,4867]
operator: , [4894,4895]
===
match
---
operator: + [27169,27170]
operator: + [27173,27174]
===
match
---
dictorsetmaker [36242,36273]
dictorsetmaker [36246,36277]
===
match
---
operator: = [35838,35839]
operator: = [35842,35843]
===
match
---
argument [25028,25040]
argument [25032,25044]
===
match
---
name: DEFAULT_DATETIME_1 [29495,29513]
name: DEFAULT_DATETIME_1 [29499,29517]
===
match
---
name: days [9875,9879]
name: days [9879,9883]
===
match
---
operator: } [23686,23687]
operator: } [23690,23691]
===
match
---
param [4862,4867]
param [4890,4895]
===
match
---
trailer [32636,32644]
trailer [32640,32648]
===
match
---
atom_expr [19500,19520]
atom_expr [19504,19524]
===
match
---
argument [37306,37347]
argument [37310,37351]
===
match
---
operator: , [2288,2289]
operator: , [2316,2317]
===
match
---
operator: , [27916,27917]
operator: , [27920,27921]
===
match
---
assert_stmt [33686,33720]
assert_stmt [33690,33724]
===
match
---
name: timedelta [26533,26542]
name: timedelta [26537,26546]
===
match
---
comparison [21249,21300]
comparison [21253,21304]
===
match
---
name: environ_overrides [6313,6330]
name: environ_overrides [6333,6350]
===
match
---
dotted_name [36106,36126]
dotted_name [36110,36130]
===
match
---
simple_stmt [785,807]
simple_stmt [785,807]
===
match
---
name: RUNNING [3347,3354]
name: RUNNING [3375,3382]
===
match
---
name: DEFAULT_DATETIME_1 [12169,12187]
name: DEFAULT_DATETIME_1 [12173,12191]
===
match
---
param [24786,24791]
param [24790,24795]
===
match
---
param [36602,36607]
param [36606,36611]
===
match
---
param [15612,15626]
param [15616,15630]
===
match
---
name: DEFAULT_DATETIME_1 [11578,11596]
name: DEFAULT_DATETIME_1 [11582,11600]
===
match
---
dictorsetmaker [19330,19362]
dictorsetmaker [19334,19366]
===
match
---
name: mock_set_state [37676,37690]
name: mock_set_state [37680,37694]
===
match
---
name: dt [33022,33024]
name: dt [33026,33028]
===
match
---
name: session [4429,4436]
name: session [4457,4464]
===
match
---
string: "only_running" [27537,27551]
string: "only_running" [27541,27555]
===
match
---
operator: = [39347,39348]
operator: = [39351,39352]
===
match
---
name: TestGetTaskInstances [9579,9599]
name: TestGetTaskInstances [9583,9603]
===
match
---
string: "include_past" [42173,42187]
string: "include_past" [42177,42191]
===
match
---
string: "failed" [38410,38418]
string: "failed" [38414,38422]
===
match
---
trailer [29529,29536]
trailer [29533,29540]
===
match
---
funcdef [3110,4775]
funcdef [3138,4803]
===
match
---
fstring_string: end_date_gte= [11878,11891]
fstring_string: end_date_gte= [11882,11895]
===
match
---
simple_stmt [16471,16572]
simple_stmt [16475,16576]
===
match
---
operator: , [21083,21084]
operator: , [21087,21088]
===
match
---
param [20696,20701]
param [20700,20705]
===
match
---
trailer [35667,35674]
trailer [35671,35678]
===
match
---
operator: , [4035,4036]
operator: , [4063,4064]
===
match
---
operator: , [41418,41419]
operator: , [41422,41423]
===
match
---
testlist_comp [14756,14876]
testlist_comp [14760,14880]
===
match
---
operator: , [28724,28725]
operator: , [28728,28729]
===
match
---
trailer [1802,1818]
trailer [1830,1846]
===
match
---
operator: , [32805,32806]
operator: , [32809,32810]
===
match
---
name: DEFAULT_DATETIME_1 [39578,39596]
name: DEFAULT_DATETIME_1 [39582,39600]
===
match
---
string: "test_queue_2" [17421,17435]
string: "test_queue_2" [17425,17439]
===
match
---
name: response [22600,22608]
name: response [22604,22612]
===
match
---
operator: { [23627,23628]
operator: { [23631,23632]
===
match
---
string: "only_failed" [27559,27572]
string: "only_failed" [27563,27576]
===
match
---
trailer [1983,2006]
trailer [2011,2034]
===
match
---
name: State [28128,28133]
name: State [28132,28137]
===
match
---
name: airflow [1103,1110]
name: airflow [1131,1138]
===
match
---
assert_stmt [15940,15992]
assert_stmt [15944,15996]
===
match
---
trailer [31561,31732]
trailer [31565,31736]
===
match
---
atom_expr [3940,3952]
atom_expr [3968,3980]
===
match
---
operator: { [30335,30336]
operator: { [30339,30340]
===
match
---
name: days [20324,20328]
name: days [20328,20332]
===
match
---
operator: , [20719,20720]
operator: , [20723,20724]
===
match
---
atom [14734,14894]
atom [14738,14898]
===
match
---
operator: } [5118,5119]
operator: } [5146,5147]
===
match
---
string: "api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [9353,9446]
string: "api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [9357,9450]
===
match
---
operator: , [42193,42194]
operator: , [42197,42198]
===
match
---
name: QUEUED [13527,13533]
name: QUEUED [13531,13537]
===
match
---
simple_stmt [3905,3954]
simple_stmt [3933,3982]
===
match
---
name: task_instances [15765,15779]
name: task_instances [15769,15783]
===
match
---
operator: , [43164,43165]
operator: , [43168,43169]
===
match
---
operator: } [26619,26620]
operator: } [26623,26624]
===
match
---
simple_stmt [33729,34957]
simple_stmt [33733,34961]
===
match
---
string: "test" [6347,6353]
string: "test" [6367,6373]
===
match
---
name: provide_session [31385,31400]
name: provide_session [31389,31404]
===
match
---
atom_expr [38951,38985]
atom_expr [38955,38989]
===
match
---
name: State [1092,1097]
name: State [1120,1125]
===
match
---
operator: , [18542,18543]
operator: , [18546,18547]
===
match
---
name: bool [3240,3244]
name: bool [3268,3272]
===
match
---
dictorsetmaker [30664,30771]
dictorsetmaker [30668,30775]
===
match
---
trailer [7315,7324]
trailer [7327,7336]
===
match
---
string: '2020-11-10T12:42:39.442973' [24628,24656]
string: '2020-11-10T12:42:39.442973' [24632,24660]
===
match
---
operator: , [21653,21654]
operator: , [21657,21658]
===
match
---
name: DagBag [2961,2967]
name: DagBag [2989,2995]
===
match
---
name: app [1564,1567]
name: app [1592,1595]
===
match
---
trailer [2605,2618]
trailer [2633,2646]
===
match
---
operator: } [25443,25444]
operator: } [25447,25448]
===
match
---
name: self [35663,35667]
name: self [35667,35671]
===
match
---
string: "test state filter" [13406,13425]
string: "test state filter" [13410,13429]
===
match
---
dotted_name [974,990]
dotted_name [959,975]
===
match
---
trailer [23127,23134]
trailer [23131,23138]
===
match
---
string: "new_state" [41055,41066]
string: "new_state" [41059,41070]
===
match
---
operator: , [23870,23871]
operator: , [23874,23875]
===
match
---
operator: { [9762,9763]
operator: { [9766,9767]
===
match
---
dictorsetmaker [17085,17121]
dictorsetmaker [17089,17125]
===
match
---
name: self [4886,4890]
name: self [4914,4918]
===
match
---
operator: , [17607,17608]
operator: , [17611,17612]
===
match
---
dotted_name [17243,17263]
dotted_name [17247,17267]
===
match
---
name: post [31831,31835]
name: post [31835,31839]
===
match
---
operator: } [31876,31877]
operator: } [31880,31881]
===
match
---
atom [11642,11697]
atom [11646,11701]
===
match
---
string: "task_instance properties" [21442,21468]
string: "task_instance properties" [21446,21472]
===
match
---
string: "state" [29847,29854]
string: "state" [29851,29858]
===
match
---
operator: { [13969,13970]
operator: { [13973,13974]
===
match
---
assert_stmt [23342,23400]
assert_stmt [23346,23404]
===
match
---
name: i [3650,3651]
name: i [3678,3679]
===
match
---
name: DEFAULT_DATETIME_STR_2 [10769,10791]
name: DEFAULT_DATETIME_STR_2 [10773,10795]
===
match
---
dictorsetmaker [11643,11696]
dictorsetmaker [11647,11700]
===
match
---
operator: + [29976,29977]
operator: + [29980,29981]
===
match
---
string: "default_queue" [2755,2770]
string: "default_queue" [2783,2798]
===
match
---
dictorsetmaker [19880,19916]
dictorsetmaker [19884,19920]
===
match
---
argument [31625,31654]
argument [31629,31658]
===
match
---
string: "" [8158,8160]
string: "" [8170,8172]
===
match
---
string: '2020-01-03T00:00:00+00:00' [34385,34412]
string: '2020-01-03T00:00:00+00:00' [34389,34416]
===
match
---
name: self [41218,41222]
name: self [41222,41226]
===
match
---
operator: , [5846,5847]
operator: , [5874,5875]
===
match
---
testlist_comp [36151,36225]
testlist_comp [36155,36229]
===
match
---
atom [22374,22397]
atom [22378,22401]
===
match
---
operator: , [20891,20892]
operator: , [20895,20896]
===
match
---
name: datetime [792,800]
name: datetime [792,800]
===
match
---
string: "queue" [8367,8374]
string: "queue" [8379,8386]
===
match
---
atom_expr [21341,21372]
atom_expr [21345,21376]
===
match
---
param [21857,21875]
param [21861,21879]
===
match
---
simple_stmt [23299,23334]
simple_stmt [23303,23338]
===
match
---
dictorsetmaker [25669,25776]
dictorsetmaker [25673,25780]
===
match
---
arglist [31849,31979]
arglist [31853,31983]
===
match
---
name: self [35217,35221]
name: self [35221,35225]
===
match
---
argument [3923,3936]
argument [3951,3964]
===
match
---
testlist_comp [18385,18685]
testlist_comp [18389,18689]
===
match
---
operator: { [28509,28510]
operator: { [28513,28514]
===
match
---
name: dt [36809,36811]
name: dt [36813,36815]
===
match
---
name: minimal_app_for_api [1570,1589]
name: minimal_app_for_api [1598,1617]
===
match
---
operator: = [7633,7634]
operator: = [7645,7646]
===
match
---
number: 200 [22474,22477]
number: 200 [22478,22481]
===
match
---
operator: + [12265,12266]
operator: + [12269,12270]
===
match
---
operator: = [39115,39116]
operator: = [39119,39120]
===
match
---
operator: { [13556,13557]
operator: { [13560,13561]
===
match
---
trailer [32051,32084]
trailer [32055,32088]
===
match
---
operator: = [39920,39921]
operator: = [39924,39925]
===
match
---
dictorsetmaker [28972,29079]
dictorsetmaker [28976,29083]
===
match
---
operator: } [22049,22050]
operator: } [22053,22054]
===
match
---
operator: , [28341,28342]
operator: , [28345,28346]
===
match
---
trailer [27801,27808]
trailer [27805,27812]
===
match
---
operator: , [1776,1777]
operator: , [1804,1805]
===
match
---
arglist [1367,1377]
arglist [1395,1405]
===
match
---
operator: = [21114,21115]
operator: = [21118,21119]
===
match
---
name: dag_id [22130,22136]
name: dag_id [22134,22140]
===
match
---
operator: , [35951,35952]
operator: , [35955,35956]
===
match
---
name: app [31746,31749]
name: app [31750,31753]
===
match
---
operator: == [32026,32028]
operator: == [32030,32032]
===
match
---
operator: = [10449,10450]
operator: = [10453,10454]
===
match
---
argument [9460,9516]
argument [9464,9520]
===
match
---
operator: = [23083,23084]
operator: = [23087,23088]
===
match
---
trailer [11678,11688]
trailer [11682,11692]
===
match
---
operator: } [32804,32805]
operator: } [32808,32809]
===
match
---
atom_expr [33022,33042]
atom_expr [33026,33046]
===
match
---
operator: == [23327,23329]
operator: == [23331,23333]
===
match
---
argument [33206,33226]
argument [33210,33230]
===
match
---
operator: = [39258,39259]
operator: = [39262,39263]
===
match
---
trailer [3015,3026]
trailer [3043,3054]
===
match
---
name: RUNNING [33075,33082]
name: RUNNING [33079,33086]
===
match
---
operator: , [6354,6355]
operator: , [6374,6375]
===
match
---
name: update_extras [3748,3761]
name: update_extras [3776,3789]
===
match
---
string: "test_no_permissions" [2056,2077]
string: "test_no_permissions" [2084,2105]
===
match
---
param [31451,31460]
param [31455,31464]
===
match
---
name: RESOURCE_DAG_RUN [1832,1848]
name: RESOURCE_DAG_RUN [1860,1876]
===
match
---
for_stmt [34965,35073]
for_stmt [34969,35077]
===
match
---
atom_expr [2146,2179]
atom_expr [2174,2207]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/~/taskInstances" [16990,17052]
string: "/api/v1/dags/example_python_operator/dagRuns/~/taskInstances" [16994,17056]
===
match
---
name: state [33616,33621]
name: state [33620,33625]
===
match
---
comparison [5189,5973]
comparison [5217,5993]
===
match
---
atom_expr [9094,9227]
atom_expr [9098,9231]
===
match
---
name: default_time [7496,7508]
name: default_time [7508,7520]
===
match
---
number: 100 [6791,6794]
number: 100 [6811,6814]
===
match
---
trailer [30167,30175]
trailer [30171,30179]
===
match
---
name: get [9336,9339]
name: get [9340,9343]
===
match
---
atom_expr [21008,21175]
atom_expr [21012,21179]
===
match
---
operator: , [34412,34413]
operator: , [34416,34417]
===
match
---
operator: = [36660,36661]
operator: = [36664,36665]
===
match
---
funcdef [2268,3105]
funcdef [2296,3133]
===
match
---
name: client [2854,2860]
name: client [2882,2888]
===
match
---
atom [12102,12134]
atom [12106,12138]
===
match
---
name: commit [39046,39052]
name: commit [39050,39056]
===
match
---
string: "queued_when" [6945,6958]
string: "queued_when" [6965,6978]
===
match
---
operator: = [29028,29029]
operator: = [29032,29033]
===
match
---
operator: = [6330,6331]
operator: = [6350,6351]
===
match
---
string: "timestamp" [8750,8761]
string: "timestamp" [8762,8773]
===
match
---
name: RUNNING [36862,36869]
name: RUNNING [36866,36873]
===
match
---
name: environ_overrides [5078,5095]
name: environ_overrides [5106,5123]
===
match
---
param [37692,37699]
param [37696,37703]
===
match
---
operator: , [39638,39639]
operator: , [39642,39643]
===
match
---
parameters [41191,41197]
parameters [41195,41201]
===
match
---
string: "pool" [14015,14021]
string: "pool" [14019,14025]
===
match
---
strings [13662,13782]
strings [13666,13786]
===
match
---
comparison [16435,16462]
comparison [16439,16466]
===
match
---
operator: , [12615,12616]
operator: , [12619,12620]
===
match
---
name: test_utils [1196,1206]
name: test_utils [1224,1234]
===
match
---
atom_expr [32499,32512]
atom_expr [32503,32516]
===
match
---
suite [41198,41788]
suite [41202,41792]
===
match
---
testlist_comp [21508,21567]
testlist_comp [21512,21571]
===
match
---
operator: = [11057,11058]
operator: = [11061,11062]
===
match
---
fstring_expr [4227,4230]
fstring_expr [4255,4258]
===
match
---
argument [23622,23687]
argument [23626,23691]
===
match
---
expr_stmt [3037,3104]
expr_stmt [3065,3132]
===
match
---
name: response [39338,39346]
name: response [39342,39350]
===
match
---
operator: = [3312,3313]
operator: = [3340,3341]
===
match
---
operator: { [27831,27832]
operator: { [27835,27836]
===
match
---
arglist [15703,15795]
arglist [15707,15799]
===
match
---
decorator [1487,1519]
decorator [1515,1547]
===
match
---
name: single_dag_run [3261,3275]
name: single_dag_run [3289,3303]
===
match
---
suite [37701,39275]
suite [37705,39279]
===
match
---
string: "state" [6111,6118]
string: "state" [6131,6138]
===
match
---
operator: , [34216,34217]
operator: , [34220,34221]
===
match
---
name: update_extras [31668,31681]
name: update_extras [31672,31685]
===
match
---
operator: , [43109,43110]
operator: , [43113,43114]
===
match
---
atom [2385,2481]
atom [2413,2509]
===
match
---
param [20752,20760]
param [20756,20764]
===
match
---
string: "include_past" [40383,40397]
string: "include_past" [40387,40401]
===
match
---
name: task_instances [15596,15610]
name: task_instances [15600,15614]
===
match
---
operator: } [14457,14458]
operator: } [14461,14462]
===
match
---
operator: , [38161,38162]
operator: , [38165,38166]
===
match
---
atom_expr [16596,16626]
atom_expr [16600,16630]
===
match
---
name: self [3854,3858]
name: self [3882,3886]
===
match
---
name: State [32631,32636]
name: State [32635,32640]
===
match
---
name: response [38503,38511]
name: response [38507,38515]
===
match
---
operator: , [11716,11717]
operator: , [11720,11721]
===
match
---
operator: = [4551,4552]
operator: = [4579,4580]
===
match
---
simple_stmt [2909,2925]
simple_stmt [2937,2953]
===
match
---
trailer [16492,16506]
trailer [16496,16510]
===
match
---
string: "execution_date" [38179,38195]
string: "execution_date" [38183,38199]
===
match
---
operator: , [18407,18408]
operator: , [18411,18412]
===
match
---
number: 200 [23330,23333]
number: 200 [23334,23337]
===
match
---
atom [20271,20332]
atom [20275,20336]
===
match
---
atom_expr [23349,23385]
atom_expr [23353,23389]
===
match
---
operator: = [16259,16260]
operator: = [16263,16264]
===
match
---
dictorsetmaker [35783,35819]
dictorsetmaker [35787,35823]
===
match
---
operator: } [38060,38061]
operator: } [38064,38065]
===
match
---
trailer [28075,28085]
trailer [28079,28089]
===
match
---
simple_stmt [4886,4922]
simple_stmt [4914,4950]
===
match
---
name: DEFAULT_DATETIME_1 [30574,30592]
name: DEFAULT_DATETIME_1 [30578,30596]
===
match
---
comparison [25110,25145]
comparison [25114,25149]
===
match
---
operator: { [29476,29477]
operator: { [29480,29481]
===
match
---
argument [21097,21138]
argument [21101,21142]
===
match
---
argument [22130,22150]
argument [22134,22154]
===
match
---
simple_stmt [16135,16171]
simple_stmt [16139,16175]
===
match
---
trailer [28133,28141]
trailer [28137,28145]
===
match
---
atom_expr [2933,2952]
atom_expr [2961,2980]
===
match
---
operator: , [25798,25799]
operator: , [25802,25803]
===
match
---
trailer [21019,21024]
trailer [21023,21028]
===
match
---
operator: @ [37547,37548]
operator: @ [37551,37552]
===
match
---
dictorsetmaker [17732,17753]
dictorsetmaker [17736,17757]
===
match
---
param [3145,3150]
param [3173,3178]
===
match
---
operator: == [35090,35092]
operator: == [35094,35096]
===
match
---
name: days [2568,2572]
name: days [2596,2600]
===
match
---
string: "{}" [6668,6672]
string: "{}" [6688,6692]
===
match
---
param [23769,23773]
param [23773,23777]
===
match
---
operator: , [28469,28470]
operator: , [28473,28474]
===
match
---
operator: , [20703,20704]
operator: , [20707,20708]
===
match
---
atom_expr [23795,24030]
atom_expr [23799,24034]
===
match
---
operator: { [27748,27749]
operator: { [27752,27753]
===
match
---
string: "duration" [18448,18458]
string: "duration" [18452,18462]
===
match
---
comparison [33609,33633]
comparison [33613,33637]
===
match
---
atom_expr [37754,37781]
atom_expr [37758,37785]
===
match
---
name: self [36904,36908]
name: self [36908,36912]
===
match
---
dictorsetmaker [20106,20165]
dictorsetmaker [20110,20169]
===
match
---
name: json [6433,6437]
name: json [6453,6457]
===
match
---
trailer [35585,35595]
trailer [35589,35599]
===
match
---
arith_expr [18860,18901]
arith_expr [18864,18905]
===
match
---
arith_expr [32563,32604]
arith_expr [32567,32608]
===
match
---
atom_expr [7333,7348]
atom_expr [7345,7360]
===
match
---
comparison [32005,32032]
comparison [32009,32036]
===
match
---
atom_expr [11599,11619]
atom_expr [11603,11623]
===
match
---
trailer [1733,1749]
trailer [1761,1777]
===
match
---
string: "test" [25007,25013]
string: "test" [25011,25017]
===
match
---
simple_stmt [35081,35130]
simple_stmt [35085,35134]
===
match
---
argument [4545,4569]
argument [4573,4597]
===
match
---
name: State [28557,28562]
name: State [28561,28566]
===
match
---
name: State [32923,32928]
name: State [32927,32932]
===
match
---
operator: , [6794,6795]
operator: , [6814,6815]
===
match
---
dictorsetmaker [17926,17964]
dictorsetmaker [17930,17968]
===
match
---
argument [28670,28676]
argument [28674,28680]
===
match
---
string: "dag_id" [5220,5228]
string: "dag_id" [5248,5256]
===
match
---
string: "execution_date" [26491,26507]
string: "execution_date" [26495,26511]
===
match
---
dictorsetmaker [6455,7198]
dictorsetmaker [6475,7210]
===
match
---
parameters [21797,21889]
parameters [21801,21893]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID" [14956,15018]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID" [14960,15022]
===
match
---
string: "include_downstream" [42568,42588]
string: "include_downstream" [42572,42592]
===
match
---
name: create_user [1594,1605]
name: create_user [1622,1633]
===
match
---
name: post [23545,23549]
name: post [23549,23553]
===
match
---
arglist [2042,2108]
arglist [2070,2136]
===
match
---
string: "dag_id" [8468,8476]
string: "dag_id" [8480,8488]
===
match
---
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [43046,43109]
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [43050,43113]
===
match
---
operator: , [32513,32514]
operator: , [32517,32518]
===
match
---
operator: = [37025,37026]
operator: = [37029,37030]
===
match
---
operator: = [4939,4940]
operator: = [4967,4968]
===
match
---
simple_stmt [16635,16688]
simple_stmt [16639,16692]
===
match
---
operator: , [5535,5536]
operator: , [5563,5564]
===
match
---
operator: , [36318,36319]
operator: , [36322,36323]
===
match
---
arglist [23153,23280]
arglist [23157,23284]
===
match
---
operator: , [15392,15393]
operator: , [15396,15397]
===
match
---
arith_expr [11655,11696]
arith_expr [11659,11700]
===
match
---
operator: , [42107,42108]
operator: , [42111,42112]
===
match
---
string: "priority_weight" [8333,8350]
string: "priority_weight" [8345,8362]
===
match
---
atom_expr [28128,28141]
atom_expr [28132,28145]
===
match
---
name: response [23784,23792]
name: response [23788,23796]
===
match
---
atom_expr [4268,4298]
atom_expr [4296,4326]
===
match
---
simple_stmt [22443,22493]
simple_stmt [22447,22497]
===
match
---
trailer [37154,37156]
trailer [37158,37160]
===
match
---
operator: , [13168,13169]
operator: , [13172,13173]
===
match
---
operator: , [12062,12063]
operator: , [12066,12067]
===
match
---
simple_stmt [22997,23033]
simple_stmt [23001,23037]
===
match
---
atom [26183,26639]
atom [26187,26643]
===
match
---
number: 200 [6405,6408]
number: 200 [6425,6428]
===
match
---
operator: { [2507,2508]
operator: { [2535,2536]
===
match
---
name: timedelta [29627,29636]
name: timedelta [29631,29640]
===
match
---
trailer [6125,6133]
trailer [6145,6153]
===
match
---
name: DEFAULT_DATETIME_1 [9924,9942]
name: DEFAULT_DATETIME_1 [9928,9946]
===
match
---
number: 150 [12707,12710]
number: 150 [12711,12714]
===
match
---
name: TestPostClearTaskInstances [25154,25180]
name: TestPostClearTaskInstances [25158,25184]
===
match
---
trailer [4890,4912]
trailer [4918,4940]
===
match
---
dictorsetmaker [17412,17435]
dictorsetmaker [17416,17439]
===
match
---
name: DEFAULT_DATETIME_1 [36695,36713]
name: DEFAULT_DATETIME_1 [36699,36717]
===
match
---
name: TaskInstance [37812,37824]
name: TaskInstance [37816,37828]
===
match
---
expr_stmt [35652,36056]
expr_stmt [35656,36060]
===
match
---
atom [12347,12527]
atom [12351,12531]
===
match
---
operator: = [37067,37068]
operator: = [37071,37072]
===
match
---
atom_expr [37400,37420]
atom_expr [37404,37424]
===
match
---
operator: } [13167,13168]
operator: } [13171,13172]
===
match
---
operator: , [24809,24810]
operator: , [24813,24814]
===
match
---
trailer [27183,27191]
trailer [27187,27195]
===
match
---
string: 'execution_date' [34129,34145]
string: 'execution_date' [34133,34149]
===
match
---
name: self [33373,33377]
name: self [33377,33381]
===
match
---
argument [37087,37107]
argument [37091,37111]
===
match
---
name: timedelta [2624,2633]
name: timedelta [2652,2661]
===
match
---
string: "execution_date_gte" [20436,20456]
string: "execution_date_gte" [20440,20460]
===
match
---
atom_expr [35575,35595]
atom_expr [35579,35599]
===
match
---
operator: , [9722,9723]
operator: , [9726,9727]
===
match
---
name: filter [16507,16513]
name: filter [16511,16517]
===
match
---
name: State [27404,27409]
name: State [27408,27413]
===
match
---
funcdef [16065,16688]
funcdef [16069,16692]
===
match
---
string: "include_past" [38359,38373]
string: "include_past" [38363,38377]
===
match
---
operator: , [21970,21971]
operator: , [21974,21975]
===
match
---
name: counter [3628,3635]
name: counter [3656,3663]
===
match
---
dictorsetmaker [18526,18541]
dictorsetmaker [18530,18545]
===
match
---
name: response [23353,23361]
name: response [23357,23365]
===
match
---
name: default_time [2606,2618]
name: default_time [2634,2646]
===
match
---
trailer [29013,29023]
trailer [29017,29027]
===
match
---
operator: , [27239,27240]
operator: , [27243,27244]
===
match
---
operator: , [29393,29394]
operator: , [29397,29398]
===
match
---
decorator [15538,15555]
decorator [15542,15559]
===
match
---
trailer [33708,33720]
trailer [33712,33724]
===
match
---
param [16111,16116]
param [16115,16120]
===
match
---
operator: , [14544,14545]
operator: , [14548,14549]
===
match
---
operator: , [17626,17627]
operator: , [17630,17631]
===
match
---
atom [12575,13016]
atom [12579,13020]
===
match
---
string: "start_date" [5773,5785]
string: "start_date" [5801,5813]
===
match
---
atom_expr [2961,3028]
atom_expr [2989,3056]
===
match
---
testlist_comp [19811,20602]
testlist_comp [19815,20606]
===
match
---
name: default_time [2328,2340]
name: default_time [2356,2368]
===
match
---
funcdef [21731,22633]
funcdef [21735,22637]
===
match
---
name: DEFAULT_DATETIME_1 [38197,38215]
name: DEFAULT_DATETIME_1 [38201,38219]
===
match
---
comparison [7884,9019]
comparison [7896,9023]
===
match
---
name: task_instances [22164,22178]
name: task_instances [22168,22182]
===
match
---
name: post [35255,35259]
name: post [35259,35263]
===
match
---
testlist_comp [42350,42808]
testlist_comp [42354,42812]
===
match
---
atom_expr [39834,39854]
atom_expr [39838,39858]
===
match
---
string: "example_python_operator" [25318,25343]
string: "example_python_operator" [25322,25347]
===
match
---
atom [11756,11972]
atom [11760,11976]
===
match
---
atom [18425,18561]
atom [18429,18565]
===
match
---
expr_stmt [16950,17133]
expr_stmt [16954,17137]
===
match
---
testlist_comp [29373,30399]
testlist_comp [29377,30403]
===
match
---
name: main_dag [31451,31459]
name: main_dag [31455,31463]
===
match
---
name: State [36724,36729]
name: State [36728,36733]
===
match
---
name: State [29066,29071]
name: State [29070,29075]
===
match
---
simple_stmt [21242,21301]
simple_stmt [21246,21305]
===
match
---
operator: { [20105,20106]
operator: { [20109,20110]
===
match
---
name: create_task_instances [3114,3135]
name: create_task_instances [3142,3163]
===
match
---
string: "execution_date" [29477,29493]
string: "execution_date" [29481,29497]
===
match
---
string: "duration_gte" [18624,18638]
string: "duration_gte" [18628,18642]
===
match
---
argument [3058,3079]
argument [3086,3107]
===
match
---
trailer [26365,26373]
trailer [26369,26377]
===
match
---
operator: , [1749,1750]
operator: , [1777,1778]
===
match
---
name: permissions [1820,1831]
name: permissions [1848,1859]
===
match
---
string: "test_2" [21557,21565]
string: "test_2" [21561,21569]
===
match
---
import_from [1098,1141]
import_from [1126,1169]
===
match
---
name: self [2490,2494]
name: self [2518,2522]
===
match
---
operator: , [16352,16353]
operator: , [16356,16357]
===
match
---
dictorsetmaker [25900,26015]
dictorsetmaker [25904,26019]
===
match
---
operator: , [5759,5760]
operator: , [5787,5788]
===
match
---
string: "start_date" [10397,10409]
string: "start_date" [10401,10413]
===
match
---
operator: { [13151,13152]
operator: { [13155,13156]
===
match
---
name: DEFAULT_DATETIME_1 [28052,28070]
name: DEFAULT_DATETIME_1 [28056,28074]
===
match
---
operator: , [20351,20352]
operator: , [20355,20356]
===
match
---
simple_stmt [32219,32412]
simple_stmt [32223,32416]
===
match
---
operator: + [18956,18957]
operator: + [18960,18961]
===
match
---
string: 'REMOTE_USER' [24992,25005]
string: 'REMOTE_USER' [24996,25009]
===
match
---
operator: , [7508,7509]
operator: , [7520,7521]
===
match
---
name: State [13475,13480]
name: State [13479,13484]
===
match
---
string: "state" [13512,13519]
string: "state" [13516,13523]
===
match
---
string: "max_tries" [5479,5490]
string: "max_tries" [5507,5518]
===
match
---
operator: , [7983,7984]
operator: , [7995,7996]
===
match
---
name: payload [23272,23279]
name: payload [23276,23283]
===
match
---
operator: , [39263,39264]
operator: , [39267,39268]
===
match
---
name: test_should_raise_400_for_naive_and_bad_datetime [24737,24785]
name: test_should_raise_400_for_naive_and_bad_datetime [24741,24789]
===
match
---
string: 'dag_run_id' [34554,34566]
string: 'dag_run_id' [34558,34570]
===
match
---
atom [36752,36884]
atom [36756,36888]
===
match
---
argument [2163,2178]
argument [2191,2206]
===
match
---
name: _ [22944,22945]
name: _ [22948,22949]
===
match
---
name: days [33035,33039]
name: days [33039,33043]
===
match
---
param [16117,16124]
param [16121,16128]
===
match
---
testlist_comp [36241,36317]
testlist_comp [36245,36321]
===
match
---
name: getuser [7188,7195]
name: getuser [7200,7207]
===
match
---
trailer [3660,3669]
trailer [3688,3697]
===
match
---
argument [4637,4669]
argument [4665,4697]
===
match
---
dictorsetmaker [12734,12749]
dictorsetmaker [12738,12753]
===
match
---
operator: , [18753,18754]
operator: , [18757,18758]
===
match
---
operator: , [35330,35331]
operator: , [35334,35335]
===
match
---
operator: , [29101,29102]
operator: , [29105,29106]
===
match
---
number: 10000.0 [7976,7983]
number: 10000.0 [7988,7995]
===
match
---
operator: , [30222,30223]
operator: , [30226,30227]
===
match
---
name: task_instances [31640,31654]
name: task_instances [31644,31658]
===
match
---
string: "example_python_operator" [27476,27501]
string: "example_python_operator" [27480,27505]
===
match
---
operator: , [2732,2733]
operator: , [2760,2761]
===
match
---
operator: , [22150,22151]
operator: , [22154,22155]
===
match
---
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [39952,40015]
string: "/api/v1/dags/example_python_operator/updateTaskInstancesState" [39956,40019]
===
match
---
trailer [15836,15840]
trailer [15840,15844]
===
match
---
name: api_connexion_utils [1207,1226]
name: api_connexion_utils [1235,1254]
===
match
---
trailer [28562,28569]
trailer [28566,28573]
===
match
---
simple_stmt [822,848]
simple_stmt [807,833]
===
match
---
atom [35839,36045]
atom [35843,36049]
===
match
---
string: "print_the_context" [39523,39542]
string: "print_the_context" [39527,39546]
===
match
---
name: self [39922,39926]
name: self [39926,39930]
===
match
---
string: "Naive datetime is disallowed" [24659,24689]
string: "Naive datetime is disallowed" [24663,24693]
===
match
---
atom_expr [3655,3669]
atom_expr [3683,3697]
===
match
---
operator: , [9800,9801]
operator: , [9804,9805]
===
match
---
operator: , [1970,1971]
operator: , [1998,1999]
===
match
---
trailer [19433,19441]
trailer [19437,19445]
===
match
---
atom_expr [27349,27369]
atom_expr [27353,27373]
===
match
---
name: self [37913,37917]
name: self [37917,37921]
===
match
---
string: "test" [23246,23252]
string: "test" [23250,23256]
===
match
---
name: task_instances [3298,3312]
name: task_instances [3326,3340]
===
match
---
operator: = [21156,21157]
operator: = [21160,21161]
===
match
---
operator: , [8095,8096]
operator: , [8107,8108]
===
match
---
param [24801,24810]
param [24805,24814]
===
match
---
string: "dry_run" [32243,32252]
string: "dry_run" [32247,32256]
===
match
---
string: '2020-11-10T12:42:39.442973' [36348,36376]
string: '2020-11-10T12:42:39.442973' [36352,36380]
===
match
---
name: dag_run_state [33316,33329]
name: dag_run_state [33320,33333]
===
match
---
dictorsetmaker [6111,6133]
dictorsetmaker [6131,6153]
===
match
---
atom_expr [1893,1927]
atom_expr [1921,1955]
===
match
---
atom_expr [18146,18158]
atom_expr [18150,18162]
===
match
---
trailer [24888,24895]
trailer [24892,24899]
===
match
---
argument [43123,43164]
argument [43127,43168]
===
match
---
string: "task" [21509,21515]
string: "task" [21513,21519]
===
match
---
operator: == [37421,37423]
operator: == [37425,37427]
===
match
---
assert_stmt [43253,43295]
assert_stmt [43257,43299]
===
match
---
trailer [2853,2860]
trailer [2881,2888]
===
match
---
trailer [16766,16773]
trailer [16770,16777]
===
match
---
trailer [18105,18113]
trailer [18109,18117]
===
match
---
simple_stmt [38453,38488]
simple_stmt [38457,38492]
===
match
---
dictorsetmaker [13557,13579]
dictorsetmaker [13561,13583]
===
match
---
operator: } [27808,27809]
operator: } [27812,27813]
===
match
---
operator: , [18205,18206]
operator: , [18209,18210]
===
match
---
atom [30555,30616]
atom [30559,30620]
===
match
---
string: "execution_date" [27749,27765]
string: "execution_date" [27753,27769]
===
match
---
name: tasks [3928,3933]
name: tasks [3956,3961]
===
match
---
argument [31911,31952]
argument [31915,31956]
===
match
---
atom_expr [1864,1891]
atom_expr [1892,1919]
===
match
---
name: items [4000,4005]
name: items [4028,4033]
===
match
---
fstring_expr [11340,11364]
fstring_expr [11344,11368]
===
match
---
name: response [35652,35660]
name: response [35656,35664]
===
match
---
string: "execution_date" [41479,41495]
string: "execution_date" [41483,41499]
===
match
---
operator: , [38747,38748]
operator: , [38751,38752]
===
match
---
trailer [31539,31561]
trailer [31543,31565]
===
match
---
name: test_client [2872,2883]
name: test_client [2900,2911]
===
match
---
operator: , [22836,22837]
operator: , [22840,22841]
===
match
---
trailer [43273,43283]
trailer [43277,43287]
===
match
---
operator: , [7416,7417]
operator: , [7428,7429]
===
match
---
operator: , [40664,40665]
operator: , [40668,40669]
===
match
---
operator: , [14781,14782]
operator: , [14785,14786]
===
match
---
operator: { [19879,19880]
operator: { [19883,19884]
===
match
---
assert_stmt [7877,9019]
assert_stmt [7889,9023]
===
match
---
name: timedelta [9948,9957]
name: timedelta [9952,9961]
===
match
---
name: session [42988,42995]
name: session [42992,42999]
===
match
---
operator: , [22816,22817]
operator: , [22820,22821]
===
match
---
name: json [43269,43273]
name: json [43273,43277]
===
match
---
operator: { [17925,17926]
operator: { [17929,17930]
===
match
---
argument [29637,29643]
argument [29641,29647]
===
match
---
atom_expr [6120,6133]
atom_expr [6140,6153]
===
match
---
string: "with dag filter" [22701,22718]
string: "with dag filter" [22705,22722]
===
match
---
string: "include_subdags" [36007,36024]
string: "include_subdags" [36011,36028]
===
match
---
string: '2020-11-10T12:42:39.442973' [41985,42013]
string: '2020-11-10T12:42:39.442973' [41989,42017]
===
match
---
operator: , [42439,42440]
operator: , [42443,42444]
===
match
---
operator: , [14650,14651]
operator: , [14654,14655]
===
match
---
operator: == [21334,21336]
operator: == [21338,21340]
===
match
---
atom [25466,25621]
atom [25470,25625]
===
match
---
name: create_user [2030,2041]
name: create_user [2058,2069]
===
match
---
trailer [40599,41102]
trailer [40603,41106]
===
match
---
string: "state" [32490,32497]
string: "state" [32494,32501]
===
match
---
operator: , [40085,40086]
operator: , [40089,40090]
===
match
---
operator: , [36884,36885]
operator: , [36888,36889]
===
match
---
atom [22748,22795]
atom [22752,22799]
===
match
---
argument [43178,43190]
argument [43182,43194]
===
match
---
trailer [28894,28901]
trailer [28898,28905]
===
match
---
param [35637,35641]
param [35641,35645]
===
match
---
name: _ [31448,31449]
name: _ [31452,31453]
===
match
---
argument [3938,3952]
argument [3966,3980]
===
match
---
atom [18713,19233]
atom [18717,19237]
===
match
---
operator: { [34245,34246]
operator: { [34249,34250]
===
match
---
simple_stmt [39911,40469]
simple_stmt [39915,40473]
===
match
---
name: DagRunType [4646,4656]
name: DagRunType [4674,4684]
===
match
---
trailer [11121,11131]
trailer [11125,11135]
===
match
---
string: 'example_python_operator' [38880,38905]
string: 'example_python_operator' [38884,38909]
===
match
---
operator: , [17524,17525]
operator: , [17528,17529]
===
match
---
string: "example_subdag_operator" [31184,31209]
string: "example_subdag_operator" [31188,31213]
===
match
---
argument [19434,19440]
argument [19438,19444]
===
match
---
dictorsetmaker [13466,13488]
dictorsetmaker [13470,13492]
===
match
---
trailer [3858,3866]
trailer [3886,3894]
===
match
---
name: request_dag [31477,31488]
name: request_dag [31481,31492]
===
match
---
trailer [1831,1848]
trailer [1859,1876]
===
match
---
name: session [4758,4765]
name: session [4786,4793]
===
match
---
atom_expr [15904,15924]
atom_expr [15908,15928]
===
match
---
operator: , [1374,1375]
operator: , [1402,1403]
===
match
---
string: "api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [9123,9216]
string: "api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [9127,9220]
===
match
---
name: airflow [974,981]
name: airflow [959,966]
===
match
---
parameters [2283,2305]
parameters [2311,2333]
===
match
---
string: "example_python_operator" [23972,23997]
string: "example_python_operator" [23976,24001]
===
match
---
name: DagBag [3051,3057]
name: DagBag [3079,3085]
===
match
---
atom [21508,21526]
atom [21512,21530]
===
match
---
name: filter [33602,33608]
name: filter [33606,33612]
===
match
---
operator: } [14036,14037]
operator: } [14040,14041]
===
match
---
operator: , [13534,13535]
operator: , [13538,13539]
===
match
---
atom [28769,28924]
atom [28773,28928]
===
match
---
name: update_extras [37054,37067]
name: update_extras [37058,37071]
===
match
---
atom_expr [43260,43283]
atom_expr [43264,43287]
===
match
---
trailer [7580,7590]
trailer [7592,7602]
===
match
---
name: task [3923,3927]
name: task [3951,3955]
===
match
---
string: "reset_dag_runs" [32273,32289]
string: "reset_dag_runs" [32277,32293]
===
match
---
string: "latest_only" [22137,22150]
string: "latest_only" [22141,22154]
===
match
---
string: "example_python_operator" [28201,28226]
string: "example_python_operator" [28205,28230]
===
match
---
string: "example_skip_dag" [23999,24017]
string: "example_skip_dag" [24003,24021]
===
match
---
operator: { [20271,20272]
operator: { [20275,20276]
===
match
---
number: 403 [9567,9570]
number: 403 [9571,9574]
===
match
---
name: dt [20228,20230]
name: dt [20232,20234]
===
match
---
assert_stmt [6417,7208]
assert_stmt [6437,7220]
===
match
---
operator: + [27347,27348]
operator: + [27351,27352]
===
match
---
name: FAILED [29072,29078]
name: FAILED [29076,29082]
===
match
---
trailer [27075,27083]
trailer [27079,27087]
===
match
---
operator: , [42807,42808]
operator: , [42811,42812]
===
match
---
string: "only_failed" [26815,26828]
string: "only_failed" [26819,26832]
===
match
---
simple_stmt [16250,16419]
simple_stmt [16254,16423]
===
match
---
funcdef [9262,9571]
funcdef [9266,9575]
===
match
---
atom_expr [15947,15977]
atom_expr [15951,15981]
===
match
---
expr_stmt [3453,3486]
expr_stmt [3481,3514]
===
match
---
string: 'dag_id' [34263,34271]
string: 'dag_id' [34267,34275]
===
match
---
operator: , [31362,31363]
operator: , [31366,31367]
===
match
---
simple_stmt [37194,37385]
simple_stmt [37198,37389]
===
match
---
name: permissions [1751,1762]
name: permissions [1779,1790]
===
match
---
trailer [2967,3015]
trailer [2995,3043]
===
match
---
simple_stmt [3779,3820]
simple_stmt [3807,3848]
===
match
---
name: test_should_raises_401_unauthenticated [39284,39322]
name: test_should_raises_401_unauthenticated [39288,39326]
===
match
---
operator: , [30723,30724]
operator: , [30727,30728]
===
match
---
strings [12369,12509]
strings [12373,12513]
===
match
---
simple_stmt [4134,4413]
simple_stmt [4162,4441]
===
match
---
atom [14756,14781]
atom [14760,14785]
===
match
---
name: self [23795,23799]
name: self [23799,23803]
===
match
---
name: FAILED [27410,27416]
name: FAILED [27414,27420]
===
match
---
operator: == [40505,40507]
operator: == [40509,40511]
===
match
---
operator: + [29799,29800]
operator: + [29803,29804]
===
match
---
name: unittest [827,835]
name: unittest [812,820]
===
match
---
string: 'REMOTE_USER' [23903,23916]
string: 'REMOTE_USER' [23907,23920]
===
match
---
string: "2020-01-01T00:00:00+00:00" [6608,6635]
string: "2020-01-01T00:00:00+00:00" [6628,6655]
===
match
---
name: DEFAULT_DATETIME_1 [30134,30152]
name: DEFAULT_DATETIME_1 [30138,30156]
===
match
---
string: 'example_python_operator' [34511,34536]
string: 'example_python_operator' [34515,34540]
===
match
---
operator: == [36093,36095]
operator: == [36097,36099]
===
match
---
simple_stmt [38496,38843]
simple_stmt [38500,38847]
===
match
---
atom [14312,14665]
atom [14316,14669]
===
match
---
atom_expr [3854,3892]
atom_expr [3882,3920]
===
match
---
operator: , [1244,1245]
operator: , [1272,1273]
===
match
---
atom [32437,33108]
atom [32441,33112]
===
match
---
trailer [30940,30947]
trailer [30944,30951]
===
match
---
dictorsetmaker [27310,27417]
dictorsetmaker [27314,27421]
===
match
---
name: RESOURCE_DAG [1763,1775]
name: RESOURCE_DAG [1791,1803]
===
match
---
classdef [25148,37479]
classdef [25152,37483]
===
match
---
number: 2 [29819,29820]
number: 2 [29823,29824]
===
match
---
operator: , [19745,19746]
operator: , [19749,19750]
===
match
---
name: days [20555,20559]
name: days [20559,20563]
===
match
---
name: create_task_instances [36909,36930]
name: create_task_instances [36913,36934]
===
match
---
arglist [4033,4047]
arglist [4061,4075]
===
match
---
operator: , [36030,36031]
operator: , [36034,36035]
===
match
---
operator: , [18353,18354]
operator: , [18357,18358]
===
match
---
operator: = [23793,23794]
operator: = [23797,23798]
===
match
---
atom_expr [6058,6156]
atom_expr [6078,6176]
===
match
---
name: timedelta [29981,29990]
name: timedelta [29985,29994]
===
match
---
operator: , [31897,31898]
operator: , [31901,31902]
===
match
---
name: read_dags_from_db [3081,3098]
name: read_dags_from_db [3109,3126]
===
match
---
name: environ_overrides [9460,9477]
name: environ_overrides [9464,9481]
===
match
---
arglist [16791,16854]
arglist [16795,16858]
===
match
---
name: dt [28657,28659]
name: dt [28661,28663]
===
match
---
string: "include_future" [40977,40993]
string: "include_future" [40981,40997]
===
match
---
atom_expr [2535,2552]
atom_expr [2563,2580]
===
match
---
name: dag_id [31596,31602]
name: dag_id [31600,31606]
===
match
---
atom_expr [32005,32025]
atom_expr [32009,32029]
===
match
---
operator: , [6994,6995]
operator: , [7014,7015]
===
match
---
string: "dag_ids" [22737,22746]
string: "dag_ids" [22741,22750]
===
match
---
name: fixture [1495,1502]
name: fixture [1523,1530]
===
match
---
trailer [21903,21913]
trailer [21907,21917]
===
match
---
name: app [1615,1618]
name: app [1643,1646]
===
match
---
operator: , [6299,6300]
operator: , [6319,6320]
===
match
---
parameters [23768,23774]
parameters [23772,23778]
===
match
---
atom [29181,29307]
atom [29185,29311]
===
match
---
name: dt [29624,29626]
name: dt [29628,29630]
===
match
---
operator: { [10948,10949]
operator: { [10952,10953]
===
match
---
dictorsetmaker [14481,14502]
dictorsetmaker [14485,14506]
===
match
---
atom_expr [4758,4774]
atom_expr [4786,4802]
===
match
---
testlist_comp [27646,28361]
testlist_comp [27650,28365]
===
match
---
atom_expr [29524,29536]
atom_expr [29528,29540]
===
match
---
name: create_task_instances [4891,4912]
name: create_task_instances [4919,4940]
===
match
---
trailer [31117,31124]
trailer [31121,31128]
===
match
---
operator: + [32582,32583]
operator: + [32586,32587]
===
match
---
atom_expr [3874,3891]
atom_expr [3902,3919]
===
match
---
simple_stmt [21309,21374]
simple_stmt [21313,21378]
===
match
---
operator: = [2505,2506]
operator: = [2533,2534]
===
match
---
operator: , [19664,19665]
operator: , [19668,19669]
===
match
---
operator: } [38841,38842]
operator: } [38845,38846]
===
match
---
operator: } [22795,22796]
operator: } [22799,22800]
===
match
---
atom_expr [4941,5130]
atom_expr [4969,5158]
===
match
---
operator: = [19517,19518]
operator: = [19521,19522]
===
match
---
operator: { [31929,31930]
operator: { [31933,31934]
===
match
---
name: session [37737,37744]
name: session [37741,37748]
===
match
---
name: TestGetTaskInstance [4783,4802]
name: TestGetTaskInstance [4811,4830]
===
match
---
number: 2 [32748,32749]
number: 2 [32752,32753]
===
match
---
testlist_comp [28407,29327]
testlist_comp [28411,29331]
===
match
---
testlist_comp [36425,36505]
testlist_comp [36429,36509]
===
match
---
name: FAILED [26414,26420]
name: FAILED [26418,26424]
===
match
---
testlist_comp [32451,33098]
testlist_comp [32455,33102]
===
match
---
atom_expr [30155,30175]
atom_expr [30159,30179]
===
match
---
atom_expr [3531,3541]
atom_expr [3559,3569]
===
match
---
operator: , [22954,22955]
operator: , [22958,22959]
===
match
---
name: dt [20311,20313]
name: dt [20315,20317]
===
match
---
name: dag_id [4521,4527]
name: dag_id [4549,4555]
===
match
---
operator: = [20079,20080]
operator: = [20083,20084]
===
match
---
name: dt [29978,29980]
name: dt [29982,29984]
===
match
---
name: run_id [4545,4551]
name: run_id [4573,4579]
===
match
---
operator: , [18699,18700]
operator: , [18703,18704]
===
match
---
operator: { [23959,23960]
operator: { [23963,23964]
===
match
---
name: dt [32584,32586]
name: dt [32588,32590]
===
match
---
atom [15864,15887]
atom [15868,15891]
===
match
---
atom [32965,33097]
atom [32969,33101]
===
match
---
name: self [21899,21903]
name: self [21903,21907]
===
match
---
atom [1707,2018]
atom [1735,2046]
===
match
---
dictorsetmaker [42372,42724]
dictorsetmaker [42376,42728]
===
match
---
operator: , [21218,21219]
operator: , [21222,21223]
===
match
---
operator: , [10908,10909]
operator: , [10912,10913]
===
match
---
trailer [23806,23811]
trailer [23810,23815]
===
match
---
testlist_comp [12593,13002]
testlist_comp [12597,13006]
===
match
---
number: 4 [30397,30398]
number: 4 [30401,30402]
===
match
---
operator: { [40104,40105]
operator: { [40108,40109]
===
match
---
trailer [37408,37420]
trailer [37412,37424]
===
match
---
name: dt [18881,18883]
name: dt [18885,18887]
===
match
---
operator: } [29713,29714]
operator: } [29717,29718]
===
match
---
parameters [31432,31525]
parameters [31436,31529]
===
match
---
testlist_comp [22683,22852]
testlist_comp [22687,22856]
===
match
---
simple_stmt [37393,37428]
simple_stmt [37397,37432]
===
match
---
name: DagRun [4490,4496]
name: DagRun [4518,4524]
===
match
---
string: "start_date" [19465,19477]
string: "start_date" [19469,19481]
===
match
---
string: "start_date" [19330,19342]
string: "start_date" [19334,19346]
===
match
---
atom [34245,34469]
atom [34249,34473]
===
match
---
param [20780,20787]
param [20784,20791]
===
match
---
string: "queued_when" [5710,5723]
string: "queued_when" [5738,5751]
===
match
---
name: days [27362,27366]
name: days [27366,27370]
===
match
---
name: permissions [1893,1904]
name: permissions [1921,1932]
===
match
---
string: 'TEST_DAG_RUN_ID_1' [34092,34111]
string: 'TEST_DAG_RUN_ID_1' [34096,34115]
===
match
---
name: timedelta [19503,19512]
name: timedelta [19507,19516]
===
match
---
name: days [19513,19517]
name: days [19517,19521]
===
match
---
operator: , [42236,42237]
operator: , [42240,42241]
===
match
---
atom_expr [20311,20331]
atom_expr [20315,20335]
===
match
---
expr_stmt [35232,35566]
expr_stmt [35236,35570]
===
match
---
name: dag_id [4167,4173]
name: dag_id [4195,4201]
===
match
---
operator: , [28901,28902]
operator: , [28905,28906]
===
match
---
atom [13640,13800]
atom [13644,13804]
===
match
---
operator: , [30175,30176]
operator: , [30179,30180]
===
match
---
name: parameterized [36106,36119]
name: parameterized [36110,36123]
===
match
---
arith_expr [28052,28093]
arith_expr [28056,28097]
===
match
---
name: state [4374,4379]
name: state [4402,4407]
===
match
---
simple_stmt [37436,37479]
simple_stmt [37440,37483]
===
match
---
atom_expr [31057,31077]
atom_expr [31061,31081]
===
match
---
operator: , [20850,20851]
operator: , [20854,20855]
===
match
---
operator: , [14875,14876]
operator: , [14879,14880]
===
match
---
name: clear_db_runs [2909,2922]
name: clear_db_runs [2937,2950]
===
match
---
string: "dry_run" [35857,35866]
string: "dry_run" [35861,35870]
===
match
---
name: dt [11599,11601]
name: dt [11603,11605]
===
match
---
atom [18447,18464]
atom [18451,18468]
===
match
---
atom [28487,29120]
atom [28491,29124]
===
match
---
comparison [35088,35129]
comparison [35092,35133]
===
match
---
operator: , [12546,12547]
operator: , [12550,12551]
===
match
---
operator: , [2470,2471]
operator: , [2498,2499]
===
match
---
operator: == [21212,21214]
operator: == [21216,21218]
===
match
---
atom_expr [21899,22060]
atom_expr [21903,22064]
===
match
---
operator: } [6353,6354]
operator: } [6373,6374]
===
match
---
simple_stmt [3854,3893]
simple_stmt [3882,3921]
===
match
---
comparison [35145,35165]
comparison [35149,35169]
===
match
---
string: "test_queue_1" [17374,17388]
string: "test_queue_1" [17378,17392]
===
match
---
name: all [37878,37881]
name: all [37882,37885]
===
match
---
string: "task_instances" [21355,21371]
string: "task_instances" [21359,21375]
===
match
---
string: "duration" [13152,13162]
string: "duration" [13156,13166]
===
match
---
name: State [31112,31117]
name: State [31116,31121]
===
match
---
simple_stmt [36904,37119]
simple_stmt [36908,37123]
===
match
---
trailer [4339,4346]
trailer [4367,4374]
===
match
---
number: 200 [33693,33696]
number: 200 [33697,33700]
===
match
---
trailer [4032,4048]
trailer [4060,4076]
===
match
---
trailer [2922,2924]
trailer [2950,2952]
===
match
---
name: json [21229,21233]
name: json [21233,21237]
===
match
---
argument [29024,29030]
argument [29028,29034]
===
match
---
string: "include_upstream" [42035,42053]
string: "include_upstream" [42039,42057]
===
match
---
operator: , [19442,19443]
operator: , [19446,19447]
===
match
---
atom_expr [31819,31989]
atom_expr [31823,31993]
===
match
---
operator: , [7758,7759]
operator: , [7770,7771]
===
match
---
operator: } [32658,32659]
operator: } [32662,32663]
===
match
---
name: self [2370,2374]
name: self [2398,2402]
===
match
---
operator: } [2805,2806]
operator: } [2833,2834]
===
match
---
arith_expr [9924,9965]
arith_expr [9928,9969]
===
match
---
atom [17364,17389]
atom [17368,17393]
===
match
---
atom [41856,42255]
atom [41860,42259]
===
match
---
operator: , [33042,33043]
operator: , [33046,33047]
===
match
---
string: "state" [27395,27402]
string: "state" [27399,27406]
===
match
---
operator: } [21137,21138]
operator: } [21141,21142]
===
match
---
dictorsetmaker [30336,30378]
dictorsetmaker [30340,30382]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances" [10613,10689]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances" [10617,10693]
===
match
---
operator: = [12284,12285]
operator: = [12288,12289]
===
match
---
name: DEFAULT_DATETIME_1 [9841,9859]
name: DEFAULT_DATETIME_1 [9845,9863]
===
match
---
trailer [43027,43032]
trailer [43031,43036]
===
match
---
fstring_string: &end_date_lte= [11915,11929]
fstring_string: &end_date_lte= [11919,11933]
===
match
---
operator: } [36737,36738]
operator: } [36741,36742]
===
match
---
trailer [30715,30723]
trailer [30719,30727]
===
match
---
operator: , [30245,30246]
operator: , [30249,30250]
===
match
---
operator: , [6672,6673]
operator: , [6692,6693]
===
match
---
atom [13924,13947]
atom [13928,13951]
===
match
---
name: State [29679,29684]
name: State [29683,29688]
===
match
---
trailer [20240,20248]
trailer [20244,20252]
===
match
---
string: "print_the_context" [29253,29272]
string: "print_the_context" [29257,29276]
===
match
---
name: task_instances [20705,20719]
name: task_instances [20709,20723]
===
match
---
name: post [22279,22283]
name: post [22283,22287]
===
match
---
operator: , [13016,13017]
operator: , [13020,13021]
===
match
---
argument [38020,38061]
argument [38024,38065]
===
match
---
atom [19939,20000]
atom [19943,20004]
===
match
---
trailer [9947,9957]
trailer [9951,9961]
===
match
---
atom [10859,11417]
atom [10863,11421]
===
match
---
string: "end_date" [6537,6547]
string: "end_date" [6557,6567]
===
match
---
string: "pid" [8244,8249]
string: "pid" [8256,8261]
===
match
---
trailer [3793,3800]
trailer [3821,3828]
===
match
---
number: 2 [19518,19519]
number: 2 [19522,19523]
===
match
---
operator: { [10768,10769]
operator: { [10772,10773]
===
match
---
atom [9662,15527]
atom [9666,15531]
===
match
---
trailer [4005,4007]
trailer [4033,4035]
===
match
---
string: "/api/v1/dags/INVALID_DAG/updateTaskInstancesState" [40613,40664]
string: "/api/v1/dags/INVALID_DAG/updateTaskInstancesState" [40617,40668]
===
match
---
import_from [1060,1097]
import_from [1088,1125]
===
match
---
operator: , [23075,23076]
operator: , [23079,23080]
===
match
---
name: task_instances [15780,15794]
name: task_instances [15784,15798]
===
match
---
string: "running" [5837,5846]
string: "running" [5865,5874]
===
match
---
dictorsetmaker [19465,19520]
dictorsetmaker [19469,19524]
===
match
---
simple_stmt [7333,7349]
simple_stmt [7345,7361]
===
match
---
trailer [1875,1891]
trailer [1903,1919]
===
match
---
operator: + [31055,31056]
operator: + [31059,31060]
===
match
---
param [31448,31450]
param [31452,31454]
===
match
---
operator: { [36333,36334]
operator: { [36337,36338]
===
match
---
suite [23513,23728]
suite [23517,23732]
===
match
---
decorator [2234,2264]
decorator [2262,2292]
===
match
---
operator: } [17606,17607]
operator: } [17610,17611]
===
match
---
classdef [37481,43296]
classdef [37485,43300]
===
match
---
name: utils [1073,1078]
name: utils [1101,1106]
===
match
---
atom [36240,36318]
atom [36244,36322]
===
match
---
trailer [28717,28724]
trailer [28721,28728]
===
match
---
string: "queue" [15280,15287]
string: "queue" [15284,15291]
===
match
---
operator: , [4352,4353]
operator: , [4380,4381]
===
match
---
operator: , [33082,33083]
operator: , [33086,33087]
===
match
---
dictorsetmaker [12656,12671]
dictorsetmaker [12660,12675]
===
match
---
name: json [37361,37365]
name: json [37365,37369]
===
match
---
operator: , [40819,40820]
operator: , [40823,40824]
===
match
---
funcdef [24733,25146]
funcdef [24737,25150]
===
match
---
name: dt [19979,19981]
name: dt [19983,19985]
===
match
---
string: "queue" [15233,15240]
string: "queue" [15237,15244]
===
match
---
trailer [7848,7860]
trailer [7860,7872]
===
match
---
testlist_comp [26099,26873]
testlist_comp [26103,26877]
===
match
---
string: "only_failed" [25995,26008]
string: "only_failed" [25999,26012]
===
match
---
atom [18367,18699]
atom [18371,18703]
===
match
---
name: DEFAULT_DATETIME_1 [20290,20308]
name: DEFAULT_DATETIME_1 [20294,20312]
===
match
---
operator: } [18113,18114]
operator: } [18117,18118]
===
match
---
testlist_comp [9676,15517]
testlist_comp [9680,15521]
===
match
---
arith_expr [20290,20331]
arith_expr [20294,20335]
===
match
---
operator: , [17754,17755]
operator: , [17758,17759]
===
match
---
trailer [18893,18901]
trailer [18897,18905]
===
match
---
operator: , [8640,8641]
operator: , [8652,8653]
===
match
---
atom_expr [4646,4669]
atom_expr [4674,4697]
===
match
---
name: self [4602,4606]
name: self [4630,4634]
===
match
---
operator: + [20540,20541]
operator: + [20544,20545]
===
match
---
import_as_names [1303,1335]
import_as_names [1331,1363]
===
match
---
operator: = [40046,40047]
operator: = [40050,40051]
===
match
---
name: DEFAULT_DATETIME_1 [25510,25528]
name: DEFAULT_DATETIME_1 [25514,25532]
===
match
---
operator: + [29009,29010]
operator: + [29013,29014]
===
match
---
operator: , [21698,21699]
operator: , [21702,21703]
===
match
---
testlist_comp [27748,28165]
testlist_comp [27752,28169]
===
match
---
name: execution_date [4587,4601]
name: execution_date [4615,4629]
===
match
---
name: response [37902,37910]
name: response [37906,37914]
===
match
---
testlist_comp [26205,26621]
testlist_comp [26209,26625]
===
match
---
operator: { [17776,17777]
operator: { [17780,17781]
===
match
---
operator: { [14435,14436]
operator: { [14439,14440]
===
match
---
string: "new_state" [39778,39789]
string: "new_state" [39782,39793]
===
match
---
operator: , [19779,19780]
operator: , [19783,19784]
===
match
---
string: "total_entries" [16610,16625]
string: "total_entries" [16614,16629]
===
match
---
atom [13090,13226]
atom [13094,13230]
===
match
---
atom_expr [28712,28724]
atom_expr [28716,28728]
===
match
---
fstring_expr [10167,10191]
fstring_expr [10171,10195]
===
match
---
arith_expr [11098,11139]
arith_expr [11102,11143]
===
match
---
name: self [36602,36606]
name: self [36606,36610]
===
match
---
strings [11221,11365]
strings [11225,11369]
===
match
---
testlist_comp [18793,18980]
testlist_comp [18797,18984]
===
match
---
operator: } [36376,36377]
operator: } [36380,36381]
===
match
---
parameters [15586,15653]
parameters [15590,15657]
===
match
---
string: "execution_date" [25492,25508]
string: "execution_date" [25496,25512]
===
match
---
string: "pool_slots" [8304,8316]
string: "pool_slots" [8316,8328]
===
match
---
string: "" [6698,6700]
string: "" [6718,6720]
===
match
---
operator: , [26443,26444]
operator: , [26447,26448]
===
match
---
testlist_comp [24219,24297]
testlist_comp [24223,24301]
===
match
---
dictorsetmaker [32837,32937]
dictorsetmaker [32841,32941]
===
match
---
string: "start_date" [36426,36438]
string: "start_date" [36430,36442]
===
match
---
operator: , [8860,8861]
operator: , [8872,8873]
===
match
---
suite [3670,4445]
suite [3698,4473]
===
match
---
dictorsetmaker [15233,15256]
dictorsetmaker [15237,15260]
===
match
---
argument [28847,28853]
argument [28851,28857]
===
match
---
operator: } [30969,30970]
operator: } [30973,30974]
===
match
---
name: i [3934,3935]
name: i [3962,3963]
===
match
---
operator: = [1568,1569]
operator: = [1596,1597]
===
match
---
name: response [7624,7632]
name: response [7636,7644]
===
match
---
atom_expr [21220,21233]
atom_expr [21224,21237]
===
match
---
operator: , [5119,5120]
operator: , [5147,5148]
===
match
---
name: update [21914,21920]
name: update [21918,21924]
===
match
---
name: pytest [1488,1494]
name: pytest [1516,1522]
===
match
---
name: len [21337,21340]
name: len [21341,21344]
===
match
---
name: FAILED [30941,30947]
name: FAILED [30945,30951]
===
match
---
operator: } [39813,39814]
operator: } [39817,39818]
===
match
---
number: 1 [1376,1377]
number: 1 [1404,1405]
===
match
---
operator: , [22397,22398]
operator: , [22401,22402]
===
match
---
arith_expr [32709,32750]
arith_expr [32713,32754]
===
match
---
name: single_dag_run [33206,33220]
name: single_dag_run [33210,33224]
===
match
---
operator: , [33342,33343]
operator: , [33346,33347]
===
match
---
name: payload [22416,22423]
name: payload [22420,22427]
===
match
---
operator: @ [21710,21711]
operator: @ [21714,21715]
===
match
---
name: session [7333,7340]
name: session [7345,7352]
===
match
---
number: 100 [18460,18463]
number: 100 [18464,18467]
===
match
---
name: client [31824,31830]
name: client [31828,31834]
===
match
---
argument [11689,11695]
argument [11693,11699]
===
match
---
name: self [22267,22271]
name: self [22271,22275]
===
match
---
string: "queue" [17365,17372]
string: "queue" [17369,17376]
===
match
---
operator: + [19419,19420]
operator: + [19423,19424]
===
match
---
operator: , [11620,11621]
operator: , [11624,11625]
===
match
---
name: session [22109,22116]
name: session [22113,22120]
===
match
---
operator: } [14874,14875]
operator: } [14878,14879]
===
match
---
operator: = [23121,23122]
operator: = [23125,23126]
===
match
---
operator: } [17798,17799]
operator: } [17802,17803]
===
match
---
string: "/api/v1/dags/example_python_operator/clearTaskInstances" [35273,35330]
string: "/api/v1/dags/example_python_operator/clearTaskInstances" [35277,35334]
===
match
---
string: "execution_date" [5355,5371]
string: "execution_date" [5383,5399]
===
match
---
string: "removed" [7072,7081]
string: "removed" [7092,7101]
===
match
---
name: single_dag_run [4457,4471]
name: single_dag_run [4485,4499]
===
match
---
string: 'REMOTE_USER' [40697,40710]
string: 'REMOTE_USER' [40701,40714]
===
match
---
operator: { [9905,9906]
operator: { [9909,9910]
===
match
---
dictorsetmaker [15865,15886]
dictorsetmaker [15869,15890]
===
match
---
atom_expr [29679,29691]
atom_expr [29683,29695]
===
match
---
operator: , [18605,18606]
operator: , [18609,18610]
===
match
---
operator: @ [21379,21380]
operator: @ [21383,21384]
===
match
---
operator: , [10008,10009]
operator: , [10012,10013]
===
match
---
operator: , [11972,11973]
operator: , [11976,11977]
===
match
---
name: TestTaskInstanceEndpoint [37516,37540]
name: TestTaskInstanceEndpoint [37520,37544]
===
match
---
operator: = [5095,5096]
operator: = [5123,5124]
===
match
---
string: "only_failed" [28303,28316]
string: "only_failed" [28307,28320]
===
match
---
operator: { [30555,30556]
operator: { [30559,30560]
===
match
---
atom_expr [16012,16043]
atom_expr [16016,16047]
===
match
---
operator: , [19218,19219]
operator: , [19222,19223]
===
match
---
name: task_instance [34969,34982]
name: task_instance [34973,34986]
===
match
---
operator: , [34231,34232]
operator: , [34235,34236]
===
match
---
import_as_names [1234,1270]
import_as_names [1262,1298]
===
match
---
string: "/taskInstances?queue=test_queue_1,test_queue_2" [15039,15087]
string: "/taskInstances?queue=test_queue_1,test_queue_2" [15043,15091]
===
match
---
atom_expr [2815,2823]
atom_expr [2843,2851]
===
match
---
operator: + [12188,12189]
operator: + [12192,12193]
===
match
---
atom_expr [1722,1749]
atom_expr [1750,1777]
===
match
---
operator: = [20328,20329]
operator: = [20332,20333]
===
match
---
name: add [7577,7580]
name: add [7589,7592]
===
match
---
string: "test state filter" [18031,18050]
string: "test state filter" [18035,18054]
===
match
---
name: permissions [998,1009]
name: permissions [983,994]
===
match
---
decorators [17242,20655]
decorators [17246,20659]
===
match
---
name: response [38460,38468]
name: response [38464,38472]
===
match
---
name: expand [9646,9652]
name: expand [9650,9656]
===
match
---
string: "test_1" [21517,21525]
string: "test_1" [21521,21529]
===
match
---
decorator [25212,31380]
decorator [25216,31384]
===
match
---
name: response [43005,43013]
name: response [43009,43017]
===
match
---
fstring_end: " [11953,11954]
fstring_end: " [11957,11958]
===
match
---
arith_expr [26332,26373]
arith_expr [26336,26377]
===
match
---
name: timedelta [31060,31069]
name: timedelta [31064,31073]
===
match
---
operator: } [4229,4230]
operator: } [4257,4258]
===
match
---
operator: { [11300,11301]
operator: { [11304,11305]
===
match
---
trailer [3944,3952]
trailer [3972,3980]
===
match
---
argument [32743,32749]
argument [32747,32753]
===
match
---
operator: , [15630,15631]
operator: , [15634,15635]
===
match
---
comparison [41760,41787]
comparison [41764,41791]
===
match
---
operator: , [34174,34175]
operator: , [34178,34179]
===
match
---
operator: = [16959,16960]
operator: = [16963,16964]
===
match
---
assert_stmt [21184,21233]
assert_stmt [21188,21237]
===
match
---
testlist_comp [12655,12751]
testlist_comp [12659,12755]
===
match
---
name: create_task_instances [22074,22095]
name: create_task_instances [22078,22099]
===
match
---
trailer [39938,40468]
trailer [39942,40472]
===
match
---
trailer [6084,6156]
trailer [6104,6176]
===
match
---
param [16736,16740]
param [16740,16744]
===
match
---
number: 6 [6892,6893]
number: 6 [6912,6913]
===
match
---
operator: } [36459,36460]
operator: } [36463,36464]
===
match
---
string: "include sub dag" [30445,30462]
string: "include sub dag" [30449,30466]
===
match
---
string: "dry_run" [38098,38107]
string: "dry_run" [38102,38111]
===
match
---
atom [24312,24394]
atom [24316,24398]
===
match
---
operator: } [26852,26853]
operator: } [26856,26857]
===
match
---
operator: = [33185,33186]
operator: = [33189,33190]
===
match
---
name: payload [42924,42931]
name: payload [42928,42935]
===
match
---
operator: = [2055,2056]
operator: = [2083,2084]
===
match
---
name: dag_run_state [4693,4706]
name: dag_run_state [4721,4734]
===
match
---
name: DEFAULT_DATETIME_1 [25402,25420]
name: DEFAULT_DATETIME_1 [25406,25424]
===
match
---
argument [15724,15751]
argument [15728,15755]
===
match
---
operator: { [12446,12447]
operator: { [12450,12451]
===
match
---
operator: } [18901,18902]
operator: } [18905,18906]
===
match
---
decorator [24079,24708]
decorator [24083,24712]
===
match
---
operator: , [27458,27459]
operator: , [27462,27463]
===
match
---
operator: == [38481,38483]
operator: == [38485,38487]
===
match
---
trailer [2883,2885]
trailer [2911,2913]
===
match
---
operator: , [34298,34299]
operator: , [34302,34303]
===
match
---
operator: } [28569,28570]
operator: } [28573,28574]
===
match
---
operator: { [15864,15865]
operator: { [15868,15869]
===
match
---
testlist_comp [23972,24017]
testlist_comp [23976,24021]
===
match
---
fstring_expr [10728,10752]
fstring_expr [10732,10756]
===
match
---
argument [16366,16407]
argument [16370,16411]
===
match
---
atom_expr [27951,27963]
atom_expr [27955,27967]
===
match
---
operator: , [5919,5920]
operator: , [5947,5948]
===
match
---
string: "state" [27942,27949]
string: "state" [27946,27953]
===
match
---
trailer [20544,20554]
trailer [20548,20558]
===
match
---
number: 2 [9963,9964]
number: 2 [9967,9968]
===
match
---
string: "try_number" [5904,5916]
string: "try_number" [5932,5944]
===
match
---
param [24811,24818]
param [24815,24822]
===
match
---
import_from [1010,1059]
import_from [1038,1087]
===
match
---
name: FAILED [31118,31124]
name: FAILED [31122,31128]
===
match
---
param [21832,21847]
param [21836,21851]
===
match
---
param [31461,31476]
param [31465,31480]
===
match
---
operator: == [43238,43240]
operator: == [43242,43244]
===
match
---
name: self [7635,7639]
name: self [7647,7651]
===
match
---
atom [24125,24171]
atom [24129,24175]
===
match
---
name: self [41192,41196]
name: self [41196,41200]
===
match
---
name: expected [42933,42941]
name: expected [42937,42945]
===
match
---
number: 2 [19217,19218]
number: 2 [19221,19222]
===
match
---
simple_stmt [32176,32211]
simple_stmt [32180,32215]
===
match
---
fstring_expr [10768,10792]
fstring_expr [10772,10796]
===
match
---
trailer [16972,16976]
trailer [16976,16980]
===
match
---
atom_expr [2417,2434]
atom_expr [2445,2462]
===
match
---
trailer [4346,4352]
trailer [4374,4380]
===
match
---
name: self [39896,39900]
name: self [39900,39904]
===
match
---
arglist [4167,4394]
arglist [4195,4422]
===
match
---
atom [32673,32805]
atom [32677,32809]
===
match
---
string: "test_pool_3" [14023,14036]
string: "test_pool_3" [14027,14040]
===
match
---
operator: , [22035,22036]
operator: , [22039,22040]
===
match
---
name: dag [3453,3456]
name: dag [3481,3484]
===
match
---
expr_stmt [23112,23290]
expr_stmt [23116,23294]
===
match
---
operator: , [14037,14038]
operator: , [14041,14042]
===
match
---
atom [10948,10982]
atom [10952,10986]
===
match
---
operator: , [23997,23998]
operator: , [24001,24002]
===
match
---
atom [14679,15139]
atom [14683,15143]
===
match
---
trailer [26355,26365]
trailer [26359,26369]
===
match
---
simple_stmt [1379,1432]
simple_stmt [1407,1460]
===
match
---
dictorsetmaker [12695,12710]
dictorsetmaker [12699,12714]
===
match
---
operator: , [25817,25818]
operator: , [25821,25822]
===
match
---
comparison [21316,21373]
comparison [21320,21377]
===
match
---
operator: , [25621,25622]
operator: , [25625,25626]
===
match
---
string: "total_entries" [21284,21299]
string: "total_entries" [21288,21303]
===
match
---
atom [10340,10374]
atom [10344,10378]
===
match
---
atom_expr [22450,22470]
atom_expr [22454,22474]
===
match
---
operator: , [36606,36607]
operator: , [36610,36611]
===
match
---
name: dag_bag [38867,38874]
name: dag_bag [38871,38878]
===
match
---
operator: = [37203,37204]
operator: = [37207,37208]
===
match
---
decorator [20638,20655]
decorator [20642,20659]
===
match
---
operator: , [39442,39443]
operator: , [39446,39447]
===
match
---
name: timedelta [19982,19991]
name: timedelta [19986,19995]
===
match
---
operator: , [13992,13993]
operator: , [13996,13997]
===
match
---
operator: { [30638,30639]
operator: { [30642,30643]
===
match
---
expr_stmt [9313,9527]
expr_stmt [9317,9531]
===
match
---
string: "taskInstances?duration_gte=100&duration_lte=200" [12915,12964]
string: "taskInstances?duration_gte=100&duration_lte=200" [12919,12968]
===
match
---
atom_expr [24046,24066]
atom_expr [24050,24070]
===
match
---
name: environ_overrides [37306,37323]
name: environ_overrides [37310,37327]
===
match
---
atom_expr [26353,26373]
atom_expr [26357,26377]
===
match
---
operator: } [15303,15304]
operator: } [15307,15308]
===
match
---
dictorsetmaker [20189,20248]
dictorsetmaker [20193,20252]
===
match
---
operator: , [7049,7050]
operator: , [7069,7070]
===
match
---
operator: + [20309,20310]
operator: + [20313,20314]
===
match
---
operator: , [12527,12528]
operator: , [12531,12532]
===
match
---
operator: , [25775,25776]
operator: , [25779,25780]
===
match
---
operator: { [10340,10341]
operator: { [10344,10345]
===
match
---
name: response [15814,15822]
name: response [15818,15826]
===
match
---
name: self [22069,22073]
name: self [22073,22077]
===
match
---
operator: , [22193,22194]
operator: , [22197,22198]
===
match
---
operator: } [11323,11324]
operator: } [11327,11328]
===
match
---
trailer [35110,35128]
trailer [35114,35132]
===
match
---
operator: } [17753,17754]
operator: } [17757,17758]
===
match
---
simple_stmt [43210,43245]
simple_stmt [43214,43249]
===
match
---
atom_expr [9324,9527]
atom_expr [9328,9531]
===
match
---
arith_expr [11578,11619]
arith_expr [11582,11623]
===
match
---
operator: , [937,938]
operator: , [922,923]
===
match
---
trailer [33335,33342]
trailer [33339,33346]
===
match
---
string: "test_queue_2" [14813,14827]
string: "test_queue_2" [14817,14831]
===
match
---
suite [22988,23459]
suite [22992,23463]
===
match
---
name: task_instances [33255,33269]
name: task_instances [33259,33273]
===
match
---
operator: = [33519,33520]
operator: = [33523,33524]
===
match
---
operator: } [7207,7208]
operator: } [7219,7220]
===
match
---
trailer [30763,30770]
trailer [30767,30774]
===
match
---
name: status_code [21200,21211]
name: status_code [21204,21215]
===
match
---
string: "duration" [13113,13123]
string: "duration" [13117,13127]
===
match
---
param [23507,23511]
param [23511,23515]
===
match
---
string: "start_date" [11005,11017]
string: "start_date" [11009,11021]
===
match
---
name: DEFAULT_DATETIME_1 [9781,9799]
name: DEFAULT_DATETIME_1 [9785,9803]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/~/taskInstances" [16791,16853]
string: "/api/v1/dags/example_python_operator/dagRuns/~/taskInstances" [16795,16857]
===
match
---
dotted_name [9632,9652]
dotted_name [9636,9656]
===
match
---
trailer [43020,43027]
trailer [43024,43031]
===
match
---
operator: { [11083,11084]
operator: { [11087,11088]
===
match
---
atom_expr [9543,9563]
atom_expr [9547,9567]
===
match
---
string: "execution_date" [32545,32561]
string: "execution_date" [32549,32565]
===
match
---
name: self [7265,7269]
name: self [7277,7281]
===
match
---
operator: } [9018,9019]
operator: } [9022,9023]
===
match
---
number: 3 [13358,13359]
number: 3 [13362,13363]
===
match
---
dictorsetmaker [40048,40084]
dictorsetmaker [40052,40088]
===
match
---
atom [29736,29891]
atom [29740,29895]
===
match
---
name: test_should_raise_404_not_found_dag [40521,40556]
name: test_should_raise_404_not_found_dag [40525,40560]
===
match
---
name: task_instances [6094,6108]
name: task_instances [6114,6128]
===
match
---
trailer [16020,16025]
trailer [16024,16029]
===
match
---
atom_expr [23533,23698]
atom_expr [23537,23702]
===
match
---
number: 2 [14282,14283]
number: 2 [14286,14287]
===
match
---
operator: , [954,955]
operator: , [939,940]
===
match
---
trailer [23799,23806]
trailer [23803,23810]
===
match
---
import_from [1271,1335]
import_from [1299,1363]
===
match
---
string: "pool" [5573,5579]
string: "pool" [5601,5607]
===
match
---
string: "duration" [2679,2689]
string: "duration" [2707,2717]
===
match
---
operator: , [27501,27502]
operator: , [27505,27506]
===
match
---
operator: , [3166,3167]
operator: , [3194,3195]
===
match
---
name: get [9106,9109]
name: get [9110,9113]
===
match
---
operator: , [7462,7463]
operator: , [7474,7475]
===
match
---
operator: { [10396,10397]
operator: { [10400,10401]
===
match
---
atom_expr [3910,3953]
atom_expr [3938,3981]
===
match
---
name: dt [28073,28075]
name: dt [28077,28079]
===
match
---
operator: = [3074,3075]
operator: = [3102,3103]
===
match
---
name: client [22272,22278]
name: client [22276,22282]
===
match
---
trailer [1605,2025]
trailer [1633,2053]
===
match
---
atom_expr [23353,23384]
atom_expr [23357,23388]
===
match
---
operator: { [13511,13512]
operator: { [13515,13516]
===
match
---
operator: , [42151,42152]
operator: , [42155,42156]
===
match
---
string: "TEST_DAG_RUN_ID/taskInstances?pool=test_pool_1,test_pool_2" [14186,14246]
string: "TEST_DAG_RUN_ID/taskInstances?pool=test_pool_1,test_pool_2" [14190,14250]
===
match
---
atom [20105,20166]
atom [20109,20170]
===
match
---
name: State [25431,25436]
name: State [25435,25440]
===
match
---
atom [9478,9516]
atom [9482,9520]
===
match
---
trailer [3606,3636]
trailer [3634,3664]
===
match
---
name: app [2868,2871]
name: app [2896,2899]
===
match
---
operator: , [33165,33166]
operator: , [33169,33170]
===
match
---
string: "task_instances" [16669,16685]
string: "task_instances" [16673,16689]
===
match
---
operator: { [5206,5207]
operator: { [5234,5235]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [7664,7758]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/taskInstances/print_the_context" [7676,7770]
===
match
---
simple_stmt [4758,4775]
simple_stmt [4786,4803]
===
match
---
string: "pool" [17822,17828]
string: "pool" [17826,17832]
===
match
---
operator: , [24298,24299]
operator: , [24302,24303]
===
match
---
operator: { [27022,27023]
operator: { [27026,27027]
===
match
---
argument [20905,20934]
argument [20909,20938]
===
match
---
operator: = [3049,3050]
operator: = [3077,3078]
===
match
---
operator: , [19199,19200]
operator: , [19203,19204]
===
match
---
param [15627,15631]
param [15631,15635]
===
match
---
string: "start_date" [2521,2533]
string: "start_date" [2549,2561]
===
match
---
string: "execution_date" [26206,26222]
string: "execution_date" [26210,26226]
===
match
---
atom_expr [36072,36092]
atom_expr [36076,36096]
===
match
---
name: DEFAULT_DATETIME_STR_1 [11301,11323]
name: DEFAULT_DATETIME_STR_1 [11305,11327]
===
match
---
decorators [9631,15555]
decorators [9635,15559]
===
match
---
argument [11053,11059]
argument [11057,11063]
===
match
---
operator: , [12211,12212]
operator: , [12215,12216]
===
match
---
operator: , [12711,12712]
operator: , [12715,12716]
===
match
---
string: "execution_date" [31018,31034]
string: "execution_date" [31022,31038]
===
match
---
operator: , [7125,7126]
operator: , [7145,7146]
===
match
---
operator: @ [15538,15539]
operator: @ [15542,15543]
===
match
---
operator: , [36625,36626]
operator: , [36629,36630]
===
match
---
atom [37324,37347]
atom [37328,37351]
===
match
---
atom_expr [13475,13488]
atom_expr [13479,13492]
===
match
---
suite [25207,37479]
suite [25211,37483]
===
match
---
operator: , [28093,28094]
operator: , [28097,28098]
===
match
---
string: "state" [32768,32775]
string: "state" [32772,32779]
===
match
---
atom [17084,17122]
atom [17088,17126]
===
match
---
string: "2020-01-01T00:00:00+00:00" [8068,8095]
string: "2020-01-01T00:00:00+00:00" [8080,8107]
===
match
---
trailer [30038,30045]
trailer [30042,30049]
===
match
---
string: 'task_id' [38769,38778]
string: 'task_id' [38773,38782]
===
match
---
operator: == [25088,25090]
operator: == [25092,25094]
===
match
---
atom_expr [22997,23032]
atom_expr [23001,23036]
===
match
---
operator: = [4488,4489]
operator: = [4516,4517]
===
match
---
comparison [33693,33720]
comparison [33697,33724]
===
match
---
string: "example_python_operator" [3190,3215]
string: "example_python_operator" [3218,3243]
===
match
---
operator: } [20248,20249]
operator: } [20252,20253]
===
match
---
atom [17925,17965]
atom [17929,17969]
===
match
---
atom [14850,14875]
atom [14854,14879]
===
match
---
arglist [2968,3014]
arglist [2996,3042]
===
match
---
string: "{'end_date': ['Not a valid datetime.']}" [36276,36317]
string: "{'end_date': ['Not a valid datetime.']}" [36280,36321]
===
match
---
name: airflow [1065,1072]
name: airflow [1093,1100]
===
match
---
operator: , [40959,40960]
operator: , [40963,40964]
===
match
---
trailer [16526,16533]
trailer [16530,16537]
===
match
---
operator: , [33930,33931]
operator: , [33934,33935]
===
match
---
string: "task_ids" [29240,29250]
string: "task_ids" [29244,29254]
===
match
---
trailer [31745,31749]
trailer [31749,31753]
===
match
---
trailer [3026,3028]
trailer [3054,3056]
===
match
---
trailer [36080,36092]
trailer [36084,36096]
===
match
---
string: "print_the_context" [40800,40819]
string: "print_the_context" [40804,40823]
===
match
---
string: "test_pool_1" [13933,13946]
string: "test_pool_1" [13937,13950]
===
match
---
operator: + [2553,2554]
operator: + [2581,2582]
===
match
---
operator: , [39087,39088]
operator: , [39091,39092]
===
match
---
testlist_comp [18298,18317]
testlist_comp [18302,18321]
===
match
---
operator: = [28674,28675]
operator: = [28678,28679]
===
match
---
operator: == [37854,37856]
operator: == [37858,37860]
===
match
---
name: days [20158,20162]
name: days [20162,20166]
===
match
---
operator: = [4328,4329]
operator: = [4356,4357]
===
match
---
operator: , [23687,23688]
operator: , [23691,23692]
===
match
---
atom [38552,38832]
atom [38556,38836]
===
match
---
testlist_comp [36150,36507]
testlist_comp [36154,36511]
===
match
---
trailer [2567,2575]
trailer [2595,2603]
===
match
---
name: timedelta [30706,30715]
name: timedelta [30710,30719]
===
match
---
atom [17273,20627]
atom [17277,20631]
===
match
---
name: update [3794,3800]
name: update [3822,3828]
===
match
---
param [16935,16939]
param [16939,16943]
===
match
---
testlist_comp [25275,26053]
testlist_comp [25279,26057]
===
match
---
name: timedelta [12270,12279]
name: timedelta [12274,12283]
===
match
---
testlist_comp [13866,14284]
testlist_comp [13870,14288]
===
match
---
operator: } [14780,14781]
operator: } [14784,14785]
===
match
---
trailer [29626,29636]
trailer [29630,29640]
===
match
---
dictorsetmaker [32691,32791]
dictorsetmaker [32695,32795]
===
match
---
name: getuser [5953,5960]
name: getuser [5973,5980]
===
match
---
operator: { [26288,26289]
operator: { [26292,26293]
===
match
---
name: task_id [37846,37853]
name: task_id [37850,37857]
===
match
---
arith_expr [10411,10452]
arith_expr [10415,10456]
===
match
---
name: self [37127,37131]
name: self [37131,37135]
===
match
---
argument [31701,31721]
argument [31705,31725]
===
match
---
number: 403 [17173,17176]
number: 403 [17177,17180]
===
match
---
atom [19464,19521]
atom [19468,19525]
===
match
---
operator: = [37323,37324]
operator: = [37327,37328]
===
match
---
classdef [2198,4775]
classdef [2226,4803]
===
match
---
name: dt [12190,12192]
name: dt [12194,12196]
===
match
---
operator: , [24799,24800]
operator: , [24803,24804]
===
match
---
operator: = [3008,3009]
operator: = [3036,3037]
===
match
---
name: RUNNING [28134,28141]
name: RUNNING [28138,28145]
===
match
---
simple_stmt [4485,4722]
simple_stmt [4513,4750]
===
match
---
number: 10000.0 [5281,5288]
number: 10000.0 [5309,5316]
===
match
---
comparison [38460,38487]
comparison [38464,38491]
===
match
---
fstring_string: &end_date_lte= [12470,12484]
fstring_string: &end_date_lte= [12474,12488]
===
match
---
name: TaskInstance [16493,16505]
name: TaskInstance [16497,16509]
===
match
---
parameters [42917,42951]
parameters [42921,42955]
===
match
---
operator: , [8290,8291]
operator: , [8302,8303]
===
match
---
name: count [16587,16592]
name: count [16591,16596]
===
match
---
operator: + [19977,19978]
operator: + [19981,19982]
===
match
---
operator: { [17411,17412]
operator: { [17415,17416]
===
match
---
trailer [27361,27369]
trailer [27365,27373]
===
match
---
trailer [16272,16276]
trailer [16276,16280]
===
match
---
name: value [4347,4352]
name: value [4375,4380]
===
match
---
name: expected_ti [23389,23400]
name: expected_ti [23393,23404]
===
match
---
atom [12020,12561]
atom [12024,12565]
===
match
---
name: self [24786,24790]
name: self [24790,24794]
===
match
---
string: 'airflow.api_connexion.endpoints.task_instance_endpoint.set_state' [37559,37625]
string: 'airflow.api_connexion.endpoints.task_instance_endpoint.set_state' [37563,37629]
===
match
---
operator: } [13579,13580]
operator: } [13583,13584]
===
match
---
operator: = [43140,43141]
operator: = [43144,43145]
===
match
---
operator: } [12287,12288]
operator: } [12291,12292]
===
match
---
operator: , [15304,15305]
operator: , [15308,15309]
===
match
---
operator: , [26872,26873]
operator: , [26876,26877]
===
match
---
name: timedelta [9865,9874]
name: timedelta [9869,9878]
===
match
---
string: "2020-01-02T00:00:00+00:00" [5787,5814]
string: "2020-01-02T00:00:00+00:00" [5815,5842]
===
match
---
trailer [31823,31830]
trailer [31827,31834]
===
match
---
name: DEFAULT_DATETIME_STR_1 [10729,10751]
name: DEFAULT_DATETIME_STR_1 [10733,10755]
===
match
---
string: "duration" [7964,7974]
string: "duration" [7976,7986]
===
match
---
arglist [39952,40458]
arglist [39956,40462]
===
match
---
operator: == [7898,7900]
operator: == [7910,7912]
===
match
---
atom_expr [3037,3048]
atom_expr [3065,3076]
===
match
---
trailer [7375,7560]
trailer [7387,7572]
===
match
---
atom_expr [35243,35566]
atom_expr [35247,35570]
===
match
---
operator: { [14803,14804]
operator: { [14807,14808]
===
match
---
operator: } [20581,20582]
operator: } [20585,20586]
===
match
---
string: "end_date" [11643,11653]
string: "end_date" [11647,11657]
===
match
---
operator: } [33992,33993]
operator: } [33996,33997]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/" [10048,10111]
string: "/api/v1/dags/example_python_operator/dagRuns/TEST_DAG_RUN_ID/" [10052,10115]
===
match
---
operator: { [18181,18182]
operator: { [18185,18186]
===
match
---
dictorsetmaker [19386,19441]
dictorsetmaker [19390,19445]
===
match
---
testlist_comp [13406,13820]
testlist_comp [13410,13824]
===
match
---
operator: , [32488,32489]
operator: , [32492,32493]
===
match
---
name: mock_set_state [38994,39008]
name: mock_set_state [38998,39012]
===
match
---
testlist_comp [25383,25799]
testlist_comp [25387,25803]
===
match
---
trailer [39353,39360]
trailer [39357,39364]
===
match
---
operator: , [30592,30593]
operator: , [30596,30597]
===
match
---
name: environ_overrides [33460,33477]
name: environ_overrides [33464,33481]
===
match
---
testlist_comp [18090,18206]
testlist_comp [18094,18210]
===
match
---
operator: , [2045,2046]
operator: , [2073,2074]
===
match
---
trailer [43032,43201]
trailer [43036,43205]
===
match
---
number: 2 [20080,20081]
number: 2 [20084,20085]
===
match
---
number: 400 [37424,37427]
number: 400 [37428,37431]
===
match
---
name: self [23041,23045]
name: self [23045,23049]
===
match
---
string: "print_the_context" [8917,8936]
string: "print_the_context" [8929,8948]
===
match
---
arith_expr [2601,2641]
arith_expr [2629,2669]
===
match
---
dictorsetmaker [13191,13206]
dictorsetmaker [13195,13210]
===
match
---
operator: , [40239,40240]
operator: , [40243,40244]
===
match
---
operator: , [23279,23280]
operator: , [23283,23284]
===
match
---
operator: , [20934,20935]
operator: , [20938,20939]
===
match
---
name: environ_overrides [38020,38037]
name: environ_overrides [38024,38041]
===
match
---
operator: = [20559,20560]
operator: = [20563,20564]
===
match
---
dictorsetmaker [8468,8791]
dictorsetmaker [8480,8803]
===
match
---
atom [19385,19442]
atom [19389,19446]
===
match
---
expr_stmt [37754,37893]
expr_stmt [37758,37897]
===
match
---
operator: } [11139,11140]
operator: } [11143,11144]
===
match
---
arglist [3058,3103]
arglist [3086,3131]
===
match
---
operator: } [12710,12711]
operator: } [12714,12715]
===
match
---
operator: } [13533,13534]
operator: } [13537,13538]
===
match
---
operator: = [2984,2985]
operator: = [3012,3013]
===
match
---
string: "state" [30594,30601]
string: "state" [30598,30605]
===
match
---
operator: } [21525,21526]
operator: } [21529,21530]
===
match
---
operator: , [22004,22005]
operator: , [22008,22009]
===
match
---
number: 6 [8352,8353]
number: 6 [8364,8365]
===
match
---
string: "include_upstream" [38233,38251]
string: "include_upstream" [38237,38255]
===
match
---
argument [20324,20330]
argument [20328,20334]
===
match
---
trailer [16506,16513]
trailer [16510,16517]
===
match
---
operator: = [4645,4646]
operator: = [4673,4674]
===
match
---
operator: , [30351,30352]
operator: , [30355,30356]
===
match
---
atom_expr [17149,17169]
atom_expr [17153,17173]
===
match
---
name: FAILED [28895,28901]
name: FAILED [28899,28905]
===
match
---
suite [3580,3637]
suite [3608,3665]
===
match
---
name: test_should_raise_400_for_naive_and_bad_datetime [36553,36601]
name: test_should_raise_400_for_naive_and_bad_datetime [36557,36605]
===
match
---
trailer [33389,33538]
trailer [33393,33542]
===
match
---
expr_stmt [2815,2840]
expr_stmt [2843,2868]
===
match
---
string: "state" [30926,30933]
string: "state" [30930,30937]
===
match
---
testlist_comp [29253,29287]
testlist_comp [29257,29291]
===
match
---
testlist_comp [30445,31348]
testlist_comp [30449,31352]
===
match
---
operator: , [15192,15193]
operator: , [15196,15197]
===
match
---
operator: , [4231,4232]
operator: , [4259,4260]
===
match
---
argument [35834,36045]
argument [35838,36049]
===
match
---
operator: = [9092,9093]
operator: = [9096,9097]
===
match
---
expr_stmt [1432,1484]
expr_stmt [1460,1512]
===
match
---
atom_expr [1820,1848]
atom_expr [1848,1876]
===
match
---
parameters [16110,16125]
parameters [16114,16129]
===
match
---
atom [40047,40085]
atom [40051,40089]
===
match
---
if_stmt [4090,4445]
if_stmt [4118,4473]
===
match
---
atom [30335,30379]
atom [30339,30383]
===
match
---
name: days [18894,18898]
name: days [18898,18902]
===
match
---
atom [36333,36377]
atom [36337,36381]
===
match
---
arglist [15841,15887]
arglist [15845,15891]
===
match
---
testlist_comp [10948,11141]
testlist_comp [10952,11145]
===
match
---
operator: , [30264,30265]
operator: , [30268,30269]
===
match
---
string: "failed" [42228,42236]
string: "failed" [42232,42240]
===
match
---
argument [16215,16240]
argument [16219,16244]
===
match
---
name: DagRun [33609,33615]
name: DagRun [33613,33619]
===
match
---
trailer [22271,22278]
trailer [22275,22282]
===
match
---
name: task_instances [37011,37025]
name: task_instances [37015,37029]
===
match
---
string: "pool" [6808,6814]
string: "pool" [6828,6834]
===
match
---
param [21816,21831]
param [21820,21835]
===
match
---
operator: , [28546,28547]
operator: , [28550,28551]
===
match
---
string: "max_tries" [8174,8185]
string: "max_tries" [8186,8197]
===
match
---
operator: , [17799,17800]
operator: , [17803,17804]
===
match
---
string: "test_pool_3" [14489,14502]
string: "test_pool_3" [14493,14506]
===
match
---
argument [7772,7813]
argument [7784,7825]
===
match
---
atom [25643,25798]
atom [25647,25802]
===
match
---
name: parameterized [21380,21393]
name: parameterized [21384,21397]
===
match
---
operator: , [24490,24491]
operator: , [24494,24495]
===
match
---
testlist_comp [30555,31148]
testlist_comp [30559,31152]
===
match
---
string: "include_subdags" [35517,35534]
string: "include_subdags" [35521,35538]
===
match
---
operator: { [40696,40697]
operator: { [40700,40701]
===
match
---
string: "end_date" [12103,12113]
string: "end_date" [12107,12117]
===
match
---
atom_expr [28557,28569]
atom_expr [28561,28573]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances?start_date_gte" [11221,11276]
string: "/api/v1/dags/~/dagRuns/~/taskInstances?start_date_gte" [11225,11280]
===
match
---
simple_stmt [15814,15889]
simple_stmt [15818,15893]
===
match
---
operator: , [14828,14829]
operator: , [14832,14833]
===
match
---
string: "example_python_operator" [5230,5255]
string: "example_python_operator" [5258,5283]
===
match
---
number: 3 [29996,29997]
number: 3 [30000,30001]
===
match
---
operator: , [29078,29079]
operator: , [29082,29083]
===
match
---
trailer [31069,31077]
trailer [31073,31081]
===
match
---
number: 6 [5657,5658]
number: 6 [5685,5686]
===
match
---
arglist [40613,41092]
arglist [40617,41096]
===
match
---
atom_expr [21337,21373]
atom_expr [21341,21377]
===
match
---
name: self [9068,9072]
name: self [9072,9076]
===
match
---
atom_expr [20803,20988]
atom_expr [20807,20992]
===
match
---
operator: { [19939,19940]
operator: { [19943,19944]
===
match
---
operator: + [30153,30154]
operator: + [30157,30158]
===
match
---
funcdef [31405,32100]
funcdef [31409,32104]
===
match
---
operator: , [40999,41000]
operator: , [41003,41004]
===
match
---
funcdef [16693,16894]
funcdef [16697,16898]
===
match
---
name: environ_overrides [35764,35781]
name: environ_overrides [35768,35785]
===
match
---
name: DEFAULT_DATETIME_1 [41497,41515]
name: DEFAULT_DATETIME_1 [41501,41519]
===
match
---
dictorsetmaker [38534,38832]
dictorsetmaker [38538,38836]
===
match
---
string: "state" [29670,29677]
string: "state" [29674,29681]
===
match
---
name: days [19992,19996]
name: days [19996,20000]
===
match
---
operator: } [24656,24657]
operator: } [24660,24661]
===
match
---
operator: = [19996,19997]
operator: = [20000,20001]
===
match
---
name: minimal_app_for_api [1538,1557]
name: minimal_app_for_api [1566,1585]
===
match
---
name: json [23425,23429]
name: json [23429,23433]
===
match
---
name: RUNNING [27076,27083]
name: RUNNING [27080,27087]
===
match
---
funcdef [37631,39275]
funcdef [37635,39279]
===
match
---
string: "execution_date" [20272,20288]
string: "execution_date" [20276,20292]
===
match
---
number: 1 [12208,12209]
number: 1 [12212,12213]
===
match
---
operator: , [21526,21527]
operator: , [21530,21531]
===
match
---
assert_stmt [22568,22632]
assert_stmt [22572,22636]
===
match
---
string: "{}" [8128,8132]
string: "{}" [8140,8144]
===
match
---
name: response [6165,6173]
name: response [6185,6193]
===
match
---
string: "test" [2172,2178]
string: "test" [2200,2206]
===
match
---
operator: , [20396,20397]
operator: , [20400,20401]
===
match
---
name: json [25028,25032]
name: json [25032,25036]
===
match
---
string: "state" [25577,25584]
string: "state" [25581,25588]
===
match
---
dictorsetmaker [34501,34693]
dictorsetmaker [34505,34697]
===
match
---
simple_stmt [38852,38936]
simple_stmt [38856,38940]
===
match
---
number: 3 [32894,32895]
number: 3 [32898,32899]
===
match
---
decorator [21710,21727]
decorator [21714,21731]
===
match
---
simple_stmt [22501,22560]
simple_stmt [22505,22564]
===
match
---
operator: , [39596,39597]
operator: , [39600,39601]
===
match
---
arglist [24914,25041]
arglist [24918,25045]
===
match
---
arith_expr [30859,30900]
arith_expr [30863,30904]
===
match
---
name: expected_ti [22956,22967]
name: expected_ti [22960,22971]
===
match
---
suite [3762,3820]
suite [3790,3848]
===
match
---
arith_expr [26509,26550]
arith_expr [26513,26554]
===
match
---
name: State [27070,27075]
name: State [27074,27079]
===
match
---
operator: , [33302,33303]
operator: , [33306,33307]
===
match
---
testlist_comp [24125,24203]
testlist_comp [24129,24207]
===
match
---
trailer [32013,32025]
trailer [32017,32029]
===
match
---
name: state [1079,1084]
name: state [1107,1112]
===
match
---
operator: = [17083,17084]
operator: = [17087,17088]
===
match
---
string: "sla_miss" [5743,5753]
string: "sla_miss" [5771,5781]
===
match
---
simple_stmt [33548,33678]
simple_stmt [33552,33682]
===
match
---
arglist [35693,36046]
arglist [35697,36050]
===
match
---
atom [13151,13168]
atom [13155,13172]
===
match
---
simple_stmt [7877,9020]
simple_stmt [7889,9024]
===
match
---
operator: , [20616,20617]
operator: , [20620,20621]
===
match
---
string: "test" [21131,21137]
string: "test" [21135,21141]
===
match
---
number: 4 [31346,31347]
number: 4 [31350,31351]
===
match
---
assert_stmt [24039,24073]
assert_stmt [24043,24077]
===
match
---
simple_stmt [1337,1379]
simple_stmt [1365,1407]
===
match
---
operator: , [19540,19541]
operator: , [19544,19545]
===
match
---
trailer [7340,7346]
trailer [7352,7358]
===
match
---
dictorsetmaker [17459,17482]
dictorsetmaker [17463,17486]
===
match
---
operator: , [25040,25041]
operator: , [25044,25045]
===
match
---
simple_stmt [2131,2141]
simple_stmt [2159,2169]
===
match
---
operator: } [13991,13992]
operator: } [13995,13996]
===
match
---
operator: , [15139,15140]
operator: , [15143,15144]
===
match
---
operator: = [18975,18976]
operator: = [18979,18980]
===
match
---
dictorsetmaker [12234,12287]
dictorsetmaker [12238,12291]
===
match
---
name: State [3341,3346]
name: State [3369,3374]
===
match
---
name: expected_ti_count [20761,20778]
name: expected_ti_count [20765,20782]
===
match
---
string: "include_downstream" [38275,38295]
string: "include_downstream" [38279,38299]
===
match
---
suite [3709,3731]
suite [3737,3759]
===
match
---
name: response [43260,43268]
name: response [43264,43272]
===
match
---
atom_expr [16651,16687]
atom_expr [16655,16691]
===
match
---
string: "test" [5112,5118]
string: "test" [5140,5146]
===
match
---
dictorsetmaker [28510,28569]
dictorsetmaker [28514,28573]
===
match
---
string: "only_running" [35479,35493]
string: "only_running" [35483,35497]
===
match
---
operator: , [22342,22343]
operator: , [22346,22347]
===
match
---
argument [4514,4527]
argument [4542,4555]
===
match
---
atom [39230,39236]
atom [39234,39240]
===
match
---
operator: } [13206,13207]
operator: } [13210,13211]
===
match
---
name: session [36627,36634]
name: session [36631,36638]
===
match
---
trailer [16668,16686]
trailer [16672,16690]
===
match
---
string: "example_subdag_operator" [29411,29436]
string: "example_subdag_operator" [29415,29440]
===
match
---
number: 0 [5918,5919]
number: 0 [5946,5947]
===
match
---
trailer [37924,37929]
trailer [37928,37933]
===
match
---
string: '2020-11-10T12:4opfo' [42479,42500]
string: '2020-11-10T12:4opfo' [42483,42504]
===
match
---
operator: == [16456,16458]
operator: == [16460,16462]
===
match
---
atom_expr [16655,16686]
atom_expr [16659,16690]
===
match
---
operator: } [17482,17483]
operator: } [17486,17487]
===
match
---
operator: , [31166,31167]
operator: , [31170,31171]
===
match
---
simple_stmt [1432,1485]
simple_stmt [1460,1513]
===
match
---
name: parameterized [41794,41807]
name: parameterized [41798,41811]
===
match
---
atom [13902,14056]
atom [13906,14060]
===
match
---
fstring_end: " [31896,31897]
fstring_end: " [31900,31901]
===
match
---
number: 3 [20600,20601]
number: 3 [20604,20605]
===
match
---
string: "dag_ids" [23960,23969]
string: "dag_ids" [23964,23973]
===
match
---
dotted_name [1103,1125]
dotted_name [1131,1153]
===
match
---
operator: } [26032,26033]
operator: } [26036,26037]
===
match
---
operator: { [27519,27520]
operator: { [27523,27524]
===
match
---
string: "execution_date" [30664,30680]
string: "execution_date" [30668,30684]
===
match
---
string: 'failed' [39202,39210]
string: 'failed' [39206,39214]
===
match
---
operator: , [33527,33528]
operator: , [33531,33532]
===
match
---
trailer [35254,35259]
trailer [35258,35263]
===
match
---
trailer [16569,16571]
trailer [16573,16575]
===
match
---
string: "task_id" [39512,39521]
string: "task_id" [39516,39525]
===
match
---
operator: , [10453,10454]
operator: , [10457,10458]
===
match
---
string: "start_date" [8819,8831]
string: "start_date" [8831,8843]
===
match
---
trailer [29803,29813]
trailer [29807,29817]
===
match
---
number: 2 [15500,15501]
number: 2 [15504,15505]
===
match
---
dictorsetmaker [22737,22795]
dictorsetmaker [22741,22799]
===
match
---
atom [11083,11140]
atom [11087,11144]
===
match
---
operator: } [32410,32411]
operator: } [32414,32415]
===
match
---
atom [6441,7208]
atom [6461,7220]
===
match
---
name: create_user [1246,1257]
name: create_user [1274,1285]
===
match
---
operator: } [10791,10792]
operator: } [10795,10796]
===
match
---
atom_expr [11676,11696]
atom_expr [11680,11700]
===
match
---
name: json [23267,23271]
name: json [23271,23275]
===
match
---
argument [17066,17122]
argument [17070,17126]
===
match
---
string: "state" [26576,26583]
string: "state" [26580,26587]
===
match
---
simple_stmt [5139,5174]
simple_stmt [5167,5202]
===
match
---
simple_stmt [2849,2901]
simple_stmt [2877,2929]
===
match
---
atom [17564,17607]
atom [17568,17611]
===
match
---
operator: + [33020,33021]
operator: + [33024,33025]
===
match
---
atom [1721,1776]
atom [1749,1804]
===
match
---
name: run_id [4202,4208]
name: run_id [4230,4236]
===
match
---
operator: + [19498,19499]
operator: + [19502,19503]
===
match
---
operator: , [36997,36998]
operator: , [37001,37002]
===
match
---
name: utils [1155,1160]
name: utils [1183,1188]
===
match
---
number: 3 [29029,29030]
number: 3 [29033,29034]
===
match
---
dictorsetmaker [18448,18463]
dictorsetmaker [18452,18467]
===
match
---
name: self [15825,15829]
name: self [15829,15833]
===
match
---
comparison [43260,43295]
comparison [43264,43299]
===
match
---
operator: , [19363,19364]
operator: , [19367,19368]
===
match
---
argument [20555,20561]
argument [20559,20565]
===
match
---
atom_expr [25708,25728]
atom_expr [25712,25732]
===
match
---
operator: = [32183,32184]
operator: = [32187,32188]
===
match
---
name: self [3037,3041]
name: self [3065,3069]
===
match
---
atom_expr [33118,33353]
atom_expr [33122,33357]
===
match
---
simple_stmt [35232,35567]
simple_stmt [35236,35571]
===
match
---
name: single_dag_run [37087,37101]
name: single_dag_run [37091,37105]
===
match
---
name: task_instances [31461,31475]
name: task_instances [31465,31479]
===
match
---
operator: , [10300,10301]
operator: , [10304,10305]
===
match
---
name: payload [37366,37373]
name: payload [37370,37377]
===
match
---
name: dag_run_state [3327,3340]
name: dag_run_state [3355,3368]
===
match
---
decorators [24079,24729]
decorators [24083,24733]
===
match
---
string: '2020-11-10T12:4po' [36440,36459]
string: '2020-11-10T12:4po' [36444,36463]
===
match
---
operator: { [12102,12103]
operator: { [12106,12107]
===
match
---
atom_expr [16261,16418]
atom_expr [16265,16422]
===
match
---
name: json [38075,38079]
name: json [38079,38083]
===
match
---
operator: , [30770,30771]
operator: , [30774,30775]
===
match
---
operator: , [16115,16116]
operator: , [16119,16120]
===
match
---
name: DagRunType [4329,4339]
name: DagRunType [4357,4367]
===
match
---
string: "task_instances" [35111,35127]
string: "task_instances" [35115,35131]
===
match
---
operator: } [9965,9966]
operator: } [9969,9970]
===
match
---
comparison [9543,9570]
comparison [9547,9574]
===
match
---
operator: } [16406,16407]
operator: } [16410,16411]
===
match
---
atom_expr [22596,22632]
atom_expr [22600,22636]
===
match
---
operator: , [17546,17547]
operator: , [17550,17551]
===
match
---
operator: } [24556,24557]
operator: } [24560,24561]
===
match
---
trailer [7606,7613]
trailer [7618,7625]
===
match
---
param [3225,3252]
param [3253,3280]
===
match
---
string: "queue" [17412,17419]
string: "queue" [17416,17423]
===
match
---
argument [30893,30899]
argument [30897,30903]
===
match
---
operator: , [40915,40916]
operator: , [40919,40920]
===
match
---
atom [13465,13489]
atom [13469,13493]
===
match
---
string: "test" [33494,33500]
string: "test" [33498,33504]
===
match
---
operator: = [1706,1707]
operator: = [1734,1735]
===
match
---
operator: , [30068,30069]
operator: , [30072,30073]
===
match
---
name: single_dag_run [20963,20977]
name: single_dag_run [20967,20981]
===
match
---
atom [28008,28164]
atom [28012,28168]
===
match
---
operator: @ [25212,25213]
operator: @ [25216,25217]
===
match
---
string: "include_upstream" [41533,41551]
string: "include_upstream" [41537,41555]
===
match
---
operator: { [41856,41857]
operator: { [41860,41861]
===
match
---
comparison [23416,23458]
comparison [23420,23462]
===
match
---
expr_stmt [40572,41102]
expr_stmt [40576,41106]
===
match
---
string: "priority_weight" [6873,6890]
string: "priority_weight" [6893,6910]
===
match
---
number: 0 [7153,7154]
number: 0 [7173,7174]
===
match
---
operator: , [40185,40186]
operator: , [40189,40190]
===
match
---
operator: } [9882,9883]
operator: } [9886,9887]
===
match
---
name: timedelta [19424,19433]
name: timedelta [19428,19437]
===
match
---
string: "Naive datetime is disallowed" [24559,24589]
string: "Naive datetime is disallowed" [24563,24593]
===
match
---
operator: { [30090,30091]
operator: { [30094,30095]
===
match
---
name: self [3985,3989]
name: self [4013,4017]
===
match
---
parameters [24785,24819]
parameters [24789,24823]
===
match
---
atom_expr [37833,37853]
atom_expr [37837,37857]
===
match
---
param [22938,22943]
param [22942,22947]
===
match
---
dictorsetmaker [27749,27808]
dictorsetmaker [27753,27812]
===
match
---
assert_stmt [22443,22492]
assert_stmt [22447,22496]
===
match
---
trailer [24855,24864]
trailer [24859,24868]
===
match
---
simple_stmt [1142,1185]
simple_stmt [1170,1213]
===
match
---
string: "start_date" [7008,7020]
string: "start_date" [7028,7040]
===
match
---
number: 3 [20163,20164]
number: 3 [20167,20168]
===
match
---
atom_expr [2909,2924]
atom_expr [2937,2952]
===
match
---
atom [26205,26266]
atom [26209,26270]
===
match
---
operator: } [5972,5973]
operator: } [5992,5993]
===
match
---
name: pytest [856,862]
name: pytest [841,847]
===
match
---
dictorsetmaker [18794,18824]
dictorsetmaker [18798,18828]
===
match
---
suite [23775,24074]
suite [23779,24078]
===
match
---
string: "clear end date filter" [26099,26122]
string: "clear end date filter" [26103,26126]
===
match
---
operator: , [2018,2019]
operator: , [2046,2047]
===
match
---
operator: + [25529,25530]
operator: + [25533,25534]
===
match
---
operator: , [21846,21847]
operator: , [21850,21851]
===
match
---
operator: = [23626,23627]
operator: = [23630,23631]
===
match
---
string: "/api/v1/dags/example_python_operator/dagRuns/" [14118,14165]
string: "/api/v1/dags/example_python_operator/dagRuns/" [14122,14169]
===
match
---
string: "duration" [6504,6514]
string: "duration" [6524,6534]
===
match
---
atom_expr [30935,30947]
atom_expr [30939,30951]
===
match
---
name: create_task_instances [33123,33144]
name: create_task_instances [33127,33148]
===
match
---
string: "REMOTE_USER" [6332,6345]
string: "REMOTE_USER" [6352,6365]
===
match
---
name: status_code [22459,22470]
name: status_code [22463,22474]
===
match
---
string: "execution_date" [27857,27873]
string: "execution_date" [27861,27877]
===
match
---
operator: { [21115,21116]
operator: { [21119,21120]
===
match
---
operator: } [24264,24265]
operator: } [24268,24269]
===
match
---
comparison [23306,23333]
comparison [23310,23337]
===
match
---
atom [12809,12982]
atom [12813,12986]
===
match
---
operator: } [18541,18542]
operator: } [18545,18546]
===
match
---
simple_stmt [2961,3029]
simple_stmt [2989,3057]
===
match
---
atom [24313,24361]
atom [24317,24365]
===
match
---
suite [15654,16060]
suite [15658,16064]
===
match
---
operator: , [8353,8354]
operator: , [8365,8366]
===
match
---
dictorsetmaker [34025,34217]
dictorsetmaker [34029,34221]
===
match
---
atom_expr [39922,40468]
atom_expr [39926,40472]
===
match
---
trailer [3888,3891]
trailer [3916,3919]
===
match
---
name: ti_init [2375,2382]
name: ti_init [2403,2410]
===
match
---
string: "execution_date" [28972,28988]
string: "execution_date" [28976,28992]
===
match
---
string: "queue" [15327,15334]
string: "queue" [15331,15338]
===
match
---
trailer [30215,30222]
trailer [30219,30226]
===
match
---
name: payload [21848,21855]
name: payload [21852,21859]
===
match
---
operator: , [30045,30046]
operator: , [30049,30050]
===
match
---
string: "/api/v1/dags/~/dagRuns/~/taskInstances?pool=test_pool_1,test_pool_2" [14562,14631]
string: "/api/v1/dags/~/dagRuns/~/taskInstances?pool=test_pool_1,test_pool_2" [14566,14635]
===
match
---
decorated [9631,16060]
decorated [9635,16064]
===
match
---
trailer [35674,35679]
trailer [35678,35683]
===
match
---
operator: { [14756,14757]
operator: { [14760,14761]
===
match
---
string: "end_date_lte" [24126,24140]
string: "end_date_lte" [24130,24144]
===
match
---
operator: , [36713,36714]
operator: , [36717,36718]
===
match
---
string: "running" [18298,18307]
string: "running" [18302,18311]
===
match
---
simple_stmt [31741,31800]
simple_stmt [31745,31804]
===
match
---
operator: } [34944,34945]
operator: } [34948,34949]
===
match
---
operator: , [8132,8133]
operator: , [8144,8145]
===
match
---
testlist_comp [19265,19765]
testlist_comp [19269,19769]
===
match
---
name: task_instances [20920,20934]
name: task_instances [20924,20938]
===
match
---
name: setup_attrs [2272,2283]
name: setup_attrs [2300,2311]
===
match
---
name: self [2417,2421]
name: self [2445,2449]
===
match
---
name: create_task_instances [23046,23067]
name: create_task_instances [23050,23071]
===
match
---
operator: , [26122,26123]
operator: , [26126,26127]
===
match
---
number: 1 [27914,27915]
number: 1 [27918,27919]
===
match
---
atom_expr [1751,1775]
atom_expr [1779,1803]
===
match
---
name: client [9329,9335]
name: client [9333,9339]
===
match
---
assert_stmt [32041,32099]
assert_stmt [32045,32103]
===
match
---
dotted_name [1147,1166]
dotted_name [1175,1194]
===
match
---
name: self [2284,2288]
name: self [2312,2316]
===
match
---
atom_expr [29011,29031]
atom_expr [29015,29035]
===
match
---
dictorsetmaker [40697,40718]
dictorsetmaker [40701,40722]
===
match
---
atom_expr [16961,17133]
atom_expr [16965,17137]
===
match
---
name: days [19434,19438]
name: days [19438,19442]
===
match
---
atom [19857,20351]
atom [19861,20355]
===
match
---
atom [36241,36274]
atom [36245,36278]
===
match
---
name: test_should_respond_200_for_dag_id_filter [16069,16110]
name: test_should_respond_200_for_dag_id_filter [16073,16114]
===
match
---
dictorsetmaker [24126,24170]
dictorsetmaker [24130,24174]
===
match
---
name: state [4687,4692]
name: state [4715,4720]
===
match
---
operator: == [6438,6440]
operator: == [6458,6460]
===
match
---
fstring_start: f" [12443,12445]
fstring_start: f" [12447,12449]
===
match
---
trailer [30882,30892]
trailer [30886,30896]
===
match
---
operator: { [33763,33764]
operator: { [33767,33768]
===
match
---
number: 200 [13203,13206]
number: 200 [13207,13210]
===
match
---
trailer [6191,6365]
trailer [6211,6385]
===
match
---
operator: , [33867,33868]
operator: , [33871,33872]
===
match
---
argument [37054,37073]
argument [37058,37077]
===
match
---
operator: , [32363,32364]
operator: , [32367,32368]
===
match
---
string: "end_date_gte" [19082,19096]
string: "end_date_gte" [19086,19100]
===
match
---
string: "state" [13466,13473]
string: "state" [13470,13477]
===
match
---
trailer [37736,37745]
trailer [37740,37749]
===
match
---
name: dt [26353,26355]
name: dt [26357,26359]
===
match
---
name: timedelta [29014,29023]
name: timedelta [29018,29027]
===
match
---
trailer [2462,2470]
trailer [2490,2498]
===
match
---
operator: } [6133,6134]
operator: } [6153,6154]
===
match
---
simple_stmt [33118,33354]
simple_stmt [33122,33358]
===
match
---
operator: , [6135,6136]
operator: , [6155,6156]
===
match
---
string: 'TEST_DAG_RUN_ID_0' [33848,33867]
string: 'TEST_DAG_RUN_ID_0' [33852,33871]
===
match
---
simple_stmt [15940,15993]
simple_stmt [15944,15997]
===
match
---
name: create_task_instances [37715,37736]
name: create_task_instances [37719,37740]
===
match
---
operator: , [4180,4181]
operator: , [4208,4209]
===
match
---
operator: , [18224,18225]
operator: , [18228,18229]
===
match
---
param [6040,6047]
param [6060,6067]
===
match
---
number: 403 [36096,36099]
number: 403 [36100,36103]
===
match
---
operator: , [25551,25552]
operator: , [25555,25556]
===
match
---
operator: { [42350,42351]
operator: { [42354,42355]
===
match
---
operator: } [30067,30068]
operator: } [30071,30072]
===
match
---
atom_expr [18191,18204]
atom_expr [18195,18208]
===
match
---
operator: } [15256,15257]
operator: } [15260,15261]
===
match
---
string: '2020-01-02T00:00:00+00:00' [34147,34174]
string: '2020-01-02T00:00:00+00:00' [34151,34178]
===
match
---
atom [26288,26443]
atom [26292,26447]
===
match
---
arith_expr [30134,30175]
arith_expr [30138,30179]
===
match
---
testlist_comp [1864,1927]
testlist_comp [1892,1955]
===
match
---
operator: = [18898,18899]
operator: = [18902,18903]
===
match
---
atom [41343,41366]
atom [41347,41370]
===
match
---
fstring_expr [33418,33426]
fstring_expr [33422,33430]
===
match
---
argument [40099,40457]
argument [40103,40461]
===
match
---
name: FAILED [30609,30615]
name: FAILED [30613,30619]
===
match
---
name: client [16266,16272]
name: client [16270,16276]
===
match
---
name: self [4941,4945]
name: self [4969,4973]
===
match
---
string: "test_queue_3" [14860,14874]
string: "test_queue_3" [14864,14878]
===
match
---
operator: } [22396,22397]
operator: } [22400,22401]
===
insert-tree
---
simple_stmt [995,1038]
    import_from [995,1037]
        dotted_name [1000,1022]
            name: airflow [1000,1007]
            name: utils [1008,1013]
            name: platform [1014,1022]
        name: getuser [1030,1037]
to
file_input [785,43296]
at 7
===
move-tree
---
name: getuser [5953,5960]
to
atom_expr [5945,5962]
at 0
===
move-tree
---
name: getuser [7188,7195]
to
atom_expr [7180,7197]
at 0
===
move-tree
---
name: getuser [8999,9006]
to
atom_expr [8991,9008]
at 0
===
delete-tree
---
simple_stmt [807,822]
    import_name [807,821]
        name: getpass [814,821]
===
delete-node
---
name: getpass [5945,5952]
===
===
delete-node
---
trailer [5952,5960]
===
===
delete-node
---
name: getpass [7180,7187]
===
===
delete-node
---
trailer [7187,7195]
===
===
delete-node
---
name: getpass [8991,8998]
===
===
delete-node
---
trailer [8998,9006]
===
