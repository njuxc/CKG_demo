===
match
---
expr_stmt [6644,6677]
expr_stmt [6656,6689]
===
match
---
name: local_task_job [4786,4800]
name: local_task_job [4806,4820]
===
match
---
simple_stmt [7640,7645]
simple_stmt [7652,7657]
===
match
---
atom [4971,5121]
atom [4983,5133]
===
match
---
name: LocalTaskJob [6557,6569]
name: LocalTaskJob [6569,6581]
===
match
---
operator: = [6199,6200]
operator: = [6211,6212]
===
match
---
trailer [7323,7336]
trailer [7335,7348]
===
match
---
simple_stmt [7135,7141]
simple_stmt [7147,7153]
===
match
---
name: test_start_and_terminate [2606,2630]
name: test_start_and_terminate [2634,2658]
===
match
---
operator: , [1407,1408]
operator: , [1435,1436]
===
match
---
trailer [3292,3321]
trailer [3320,3349]
===
match
---
name: processes [3374,3383]
name: processes [3402,3411]
===
match
---
trailer [6045,6052]
trailer [6057,6064]
===
match
---
expr_stmt [1266,1324]
expr_stmt [1294,1352]
===
match
---
name: pgid [6978,6982]
name: pgid [6990,6994]
===
match
---
operator: { [3442,3443]
operator: { [3470,3471]
===
match
---
name: ignore_ti_state [6588,6603]
name: ignore_ti_state [6600,6615]
===
match
---
name: proc [7528,7532]
name: proc [7540,7544]
===
match
---
simple_stmt [4516,4714]
simple_stmt [4536,4734]
===
match
---
name: getpgid [6866,6873]
name: getpgid [6878,6885]
===
match
---
assert_stmt [3477,3516]
assert_stmt [3505,3544]
===
match
---
comp_op [4451,4457]
comp_op [4471,4477]
===
match
---
trailer [6258,6260]
trailer [6270,6272]
===
match
---
trailer [4821,4831]
trailer [4841,4851]
===
match
---
name: task_runner [1087,1098]
name: task_runner [1072,1083]
===
match
---
trailer [4436,4448]
trailer [4456,4468]
===
match
---
atom_expr [7071,7080]
atom_expr [7083,7092]
===
match
---
suite [7081,7167]
suite [7093,7179]
===
match
---
operator: == [7232,7234]
operator: == [7244,7246]
===
match
---
name: MagicMock [3651,3660]
name: MagicMock [3679,3688]
===
match
---
name: pgid [4261,4265]
name: pgid [4281,4285]
===
match
---
name: runner [4013,4019]
name: runner [4033,4039]
===
match
---
assert_stmt [7210,7247]
assert_stmt [7222,7259]
===
match
---
name: task [6502,6506]
name: task [6514,6518]
===
match
---
fstring_string:  is still alive [7349,7364]
fstring_string:  is still alive [7361,7376]
===
match
---
trailer [4800,4814]
trailer [4820,4834]
===
match
---
name: TI [6499,6501]
name: TI [6511,6513]
===
match
---
atom_expr [6499,6541]
atom_expr [6511,6553]
===
match
---
operator: = [2361,2362]
operator: = [2389,2390]
===
match
---
trailer [2753,2767]
trailer [2781,2795]
===
match
---
name: dag [6290,6293]
name: dag [6302,6305]
===
match
---
trailer [6795,6815]
trailer [6807,6827]
===
match
---
name: process [7324,7331]
name: process [7336,7343]
===
match
---
parameters [4492,4506]
parameters [4512,4526]
===
match
---
name: pgid [6831,6835]
name: pgid [6843,6847]
===
match
---
atom [1785,1859]
atom [1813,1887]
===
match
---
number: 3 [6766,6767]
number: 3 [6778,6779]
===
match
---
trailer [4293,4295]
trailer [4313,4315]
===
match
---
atom_expr [4146,4159]
atom_expr [4166,4179]
===
match
---
name: os [6785,6787]
name: os [6797,6799]
===
match
---
trailer [4831,4833]
trailer [4851,4853]
===
match
---
name: include_examples [6106,6122]
name: include_examples [6118,6134]
===
match
---
atom_expr [5170,5204]
atom_expr [5182,5216]
===
match
---
name: models [6039,6045]
name: models [6051,6057]
===
match
---
atom_expr [2739,2779]
atom_expr [2767,2807]
===
match
---
string: 'tasks' [5008,5015]
string: 'tasks' [5020,5027]
===
match
---
string: '2016-01-01' [3927,3939]
string: '2016-01-01' [3947,3959]
===
match
---
name: unlink [5967,5973]
name: unlink [5979,5985]
===
match
---
atom_expr [6653,6677]
atom_expr [6665,6689]
===
match
---
string: "class" [1935,1942]
string: "class" [1963,1970]
===
match
---
name: dictConfig [866,876]
name: dictConfig [851,861]
===
match
---
name: command_as_list [2824,2839]
name: command_as_list [2852,2867]
===
match
---
name: os [6863,6865]
name: os [6875,6877]
===
match
---
import_from [1023,1068]
import_from [1008,1053]
===
match
---
name: local_task_job [3578,3592]
name: local_task_job [3606,3620]
===
match
---
name: time [7153,7157]
name: time [7165,7169]
===
match
---
number: 0 [4121,4122]
number: 0 [4141,4142]
===
match
---
string: 'formatters' [1452,1464]
string: 'formatters' [1480,1492]
===
match
---
atom_expr [7517,7537]
atom_expr [7529,7549]
===
match
---
assert_stmt [5726,5771]
assert_stmt [5738,5783]
===
match
---
name: config [852,858]
name: config [837,843]
===
match
---
assert_stmt [4107,4122]
assert_stmt [4127,4142]
===
match
---
name: pgid [4138,4142]
name: pgid [4158,4162]
===
match
---
comparison [3168,3176]
comparison [3196,3204]
===
match
---
expr_stmt [4222,4267]
expr_stmt [4242,4287]
===
match
---
name: self [2631,2635]
name: self [2659,2663]
===
match
---
trailer [6293,6307]
trailer [6305,6319]
===
match
---
operator: , [1838,1839]
operator: , [1866,1867]
===
match
---
number: 20 [7077,7079]
number: 20 [7089,7091]
===
match
---
name: os [1284,1286]
name: os [1312,1314]
===
match
---
yield_expr [7585,7595]
yield_expr [7597,7607]
===
match
---
name: MagicMock [2719,2728]
name: MagicMock [2747,2756]
===
match
---
param [3563,3567]
param [3591,3595]
===
match
---
name: process [4372,4379]
name: process [4392,4399]
===
match
---
simple_stmt [827,839]
simple_stmt [812,824]
===
match
---
name: TEST_DAG_FOLDER [1266,1281]
name: TEST_DAG_FOLDER [1294,1309]
===
match
---
atom_expr [6557,6609]
atom_expr [6569,6621]
===
match
---
trailer [5567,5575]
trailer [5579,5587]
===
match
---
string: 'logging.StreamHandler' [1644,1667]
string: 'logging.StreamHandler' [1672,1695]
===
match
---
string: 'handlers' [1588,1598]
string: 'handlers' [1616,1626]
===
match
---
parameters [2630,2636]
parameters [2658,2664]
===
match
---
string: 'airflow' [1786,1795]
string: 'airflow' [1814,1823]
===
match
---
name: terminate [3338,3347]
name: terminate [3366,3375]
===
match
---
atom_expr [6270,6281]
atom_expr [6282,6293]
===
match
---
name: utils [1194,1199]
name: utils [1222,1227]
===
match
---
name: task_instance [3630,3643]
name: task_instance [3658,3671]
===
match
---
trailer [6307,6485]
trailer [6319,6497]
===
match
---
simple_stmt [5726,5772]
simple_stmt [5738,5784]
===
match
---
simple_stmt [933,970]
simple_stmt [918,955]
===
match
---
simple_stmt [1023,1069]
simple_stmt [1008,1054]
===
match
---
file_input [787,7645]
file_input [787,7657]
===
match
---
operator: = [4815,4816]
operator: = [4835,4836]
===
match
---
dictorsetmaker [1493,1574]
dictorsetmaker [1521,1602]
===
match
---
atom_expr [4277,4295]
atom_expr [4297,4315]
===
match
---
number: 0 [3175,3176]
number: 0 [3203,3204]
===
match
---
name: getpgid [3203,3210]
name: getpgid [3231,3238]
===
match
---
number: 0.2 [5642,5645]
number: 0.2 [5654,5657]
===
match
---
operator: , [2994,2995]
operator: , [3022,3023]
===
match
---
name: clear [6274,6279]
name: clear [6286,6291]
===
match
---
name: sleep [6760,6765]
name: sleep [6772,6777]
===
match
---
name: local_task_job [4911,4925]
name: local_task_job [4923,4937]
===
match
---
trailer [5662,5672]
trailer [5674,5684]
===
match
---
simple_stmt [6232,6261]
simple_stmt [6244,6273]
===
match
---
name: test_utils [1230,1240]
name: test_utils [1258,1268]
===
match
---
operator: != [6860,6862]
operator: != [6872,6874]
===
match
---
atom_expr [3646,3662]
atom_expr [3674,3690]
===
match
---
trailer [3132,3152]
trailer [3160,3180]
===
match
---
trailer [7163,7166]
trailer [7175,7178]
===
match
---
string: 'version' [1395,1404]
string: 'version' [1423,1432]
===
match
---
name: mock [3595,3599]
name: mock [3623,3627]
===
match
---
expr_stmt [6194,6222]
expr_stmt [6206,6234]
===
match
---
name: readline [7237,7245]
name: readline [7249,7257]
===
match
---
name: process [3426,3433]
name: process [3454,3461]
===
match
---
trailer [3729,3731]
trailer [3749,3751]
===
match
---
fstring_expr [3442,3451]
fstring_expr [3470,3479]
===
match
---
simple_stmt [6290,6486]
simple_stmt [6302,6498]
===
match
---
number: 0.5 [4047,4050]
number: 0.5 [4067,4070]
===
match
---
simple_stmt [2739,2787]
simple_stmt [2767,2815]
===
match
---
name: list [3288,3292]
name: list [3316,3320]
===
match
---
atom_expr [2683,2711]
atom_expr [2711,2739]
===
match
---
name: StandardTaskRunner [3969,3987]
name: StandardTaskRunner [3989,4007]
===
match
---
funcdef [3522,4463]
funcdef [3550,4483]
===
match
---
operator: , [3213,3214]
operator: , [3241,3242]
===
match
---
atom_expr [6242,6260]
atom_expr [6254,6272]
===
match
---
operator: = [6152,6153]
operator: = [6164,6165]
===
match
---
import_from [1146,1180]
import_from [1131,1165]
===
match
---
comparison [3484,3516]
comparison [3512,3544]
===
match
---
decorator [1899,1944]
decorator [1927,1972]
===
match
---
name: jobs [983,987]
name: jobs [968,972]
===
match
---
operator: = [4066,4067]
operator: = [4086,4087]
===
match
---
simple_stmt [4036,4052]
simple_stmt [4056,4072]
===
match
---
name: runner [5161,5167]
name: runner [5173,5179]
===
match
---
decorated [7371,7645]
decorated [7383,7657]
===
match
---
operator: = [6395,6396]
operator: = [6407,6408]
===
match
---
trailer [6632,6634]
trailer [6644,6646]
===
match
---
trailer [5766,5771]
trailer [5778,5783]
===
match
---
simple_stmt [3578,3607]
simple_stmt [3606,3635]
===
match
---
atom_expr [3671,3711]
atom_expr [3699,3739]
===
match
---
string: 'pid' [7464,7469]
string: 'pid' [7476,7481]
===
match
---
name: pgid [7410,7414]
name: pgid [7422,7426]
===
match
---
trailer [1358,1370]
trailer [1386,1398]
===
match
---
string: "Task should be in a different process group to us" [6878,6929]
string: "Task should be in a different process group to us" [6890,6941]
===
match
---
simple_stmt [2391,2407]
simple_stmt [2419,2435]
===
match
---
trailer [3414,3425]
trailer [3442,3453]
===
match
---
operator: } [1767,1768]
operator: } [1795,1796]
===
match
---
atom_expr [2663,2674]
atom_expr [2691,2702]
===
match
---
name: dagbag [6030,6036]
name: dagbag [6042,6048]
===
match
---
operator: != [3197,3199]
operator: != [3225,3227]
===
match
---
fstring_string:  is still alive [3451,3466]
fstring_string:  is still alive [3479,3494]
===
match
---
suite [3569,4463]
suite [3597,4483]
===
match
---
param [4493,4498]
param [4513,4518]
===
match
---
try_stmt [7493,7645]
try_stmt [7505,7657]
===
match
---
trailer [2317,2328]
trailer [2345,2356]
===
match
---
atom_expr [7306,7336]
atom_expr [7318,7348]
===
match
---
simple_stmt [6148,6186]
simple_stmt [6160,6198]
===
match
---
name: runner [4430,4436]
name: runner [4450,4456]
===
match
---
atom_expr [1341,1370]
atom_expr [1369,1398]
===
match
---
name: local_task_job [3671,3685]
name: local_task_job [3699,3713]
===
match
---
atom [1621,1761]
atom [1649,1789]
===
match
---
import_from [1069,1145]
import_from [1054,1130]
===
match
---
atom_expr [7181,7191]
atom_expr [7193,7203]
===
match
---
string: 'stream' [1722,1730]
string: 'stream' [1750,1758]
===
match
---
trailer [6787,6795]
trailer [6799,6807]
===
match
---
name: TI [1066,1068]
name: TI [1051,1053]
===
match
---
suite [7480,7645]
suite [7492,7657]
===
match
---
string: 'task1' [2961,2968]
string: 'task1' [2989,2996]
===
match
---
name: time [3090,3094]
name: time [3118,3122]
===
match
---
operator: = [3798,3799]
operator: = [3818,3819]
===
match
---
dictorsetmaker [1476,1576]
dictorsetmaker [1504,1604]
===
match
---
trailer [5575,5579]
trailer [5587,5591]
===
match
---
name: local_task_job [4842,4856]
name: local_task_job [4862,4876]
===
match
---
simple_stmt [4013,4028]
simple_stmt [4033,4048]
===
match
---
name: range [7071,7076]
name: range [7083,7088]
===
match
---
name: text [5767,5771]
name: text [5779,5783]
===
match
---
assert_stmt [4423,4462]
assert_stmt [4443,4482]
===
match
---
simple_stmt [1219,1265]
simple_stmt [1247,1293]
===
match
---
operator: = [5168,5169]
operator: = [5180,5181]
===
match
---
decorated [1899,2597]
decorated [1927,2625]
===
match
---
name: self [3293,3297]
name: self [3321,3325]
===
match
---
name: sleep [5241,5246]
name: sleep [5253,5258]
===
match
---
simple_stmt [3477,3517]
simple_stmt [3505,3545]
===
match
---
simple_stmt [877,903]
simple_stmt [862,888]
===
match
---
string: 'test_on_kill' [2933,2947]
string: 'test_on_kill' [2961,2975]
===
match
---
name: path [5974,5978]
name: path [5986,5990]
===
match
---
atom_expr [4786,4814]
atom_expr [4806,4834]
===
match
---
name: os [3200,3202]
name: os [3228,3230]
===
match
---
simple_stmt [3960,4004]
simple_stmt [3980,4024]
===
match
---
suite [7497,7596]
suite [7509,7608]
===
match
---
name: session [6459,6466]
name: session [6471,6478]
===
match
---
trailer [3202,3210]
trailer [3230,3238]
===
match
---
name: process [6803,6810]
name: process [6815,6822]
===
match
---
simple_stmt [4911,5122]
simple_stmt [4923,5134]
===
match
---
atom_expr [2337,2360]
atom_expr [2365,2388]
===
match
---
comparison [5733,5771]
comparison [5745,5783]
===
match
---
simple_stmt [6270,6282]
simple_stmt [6282,6294]
===
match
---
simple_stmt [2283,2329]
simple_stmt [2311,2357]
===
match
---
name: sleep [4041,4046]
name: sleep [4061,4066]
===
match
---
name: return_value [4956,4968]
name: return_value [4968,4980]
===
match
---
simple_stmt [2234,2261]
simple_stmt [2262,2289]
===
match
---
operator: { [1785,1786]
operator: { [1813,1814]
===
match
---
name: local_task_job [3988,4002]
name: local_task_job [4008,4022]
===
match
---
name: getpgid [7520,7527]
name: getpgid [7532,7539]
===
match
---
operator: , [3864,3865]
operator: , [3884,3885]
===
match
---
name: open [7181,7185]
name: open [7193,7197]
===
match
---
suite [7197,7248]
suite [7209,7260]
===
match
---
trailer [4093,4097]
trailer [4113,4117]
===
match
---
name: local_task_job [2683,2697]
name: local_task_job [2711,2725]
===
match
---
trailer [7076,7080]
trailer [7088,7092]
===
match
---
trailer [5219,5225]
trailer [5231,5237]
===
match
---
decorator [7371,7385]
decorator [7383,7397]
===
match
---
operator: , [7469,7470]
operator: , [7481,7482]
===
match
---
trailer [7527,7537]
trailer [7539,7549]
===
match
---
operator: = [6603,6604]
operator: = [6615,6616]
===
match
---
name: pgid [7541,7545]
name: pgid [7553,7557]
===
match
---
name: dag [6270,6273]
name: dag [6282,6285]
===
match
---
operator: } [1581,1582]
operator: } [1609,1610]
===
match
---
name: os [824,826]
name: os [809,811]
===
match
---
name: runner [6796,6802]
name: runner [6808,6814]
===
match
---
atom_expr [3615,3643]
atom_expr [3643,3671]
===
match
---
simple_stmt [6824,6840]
simple_stmt [6836,6852]
===
match
---
funcdef [1948,2597]
funcdef [1976,2625]
===
match
---
simple_stmt [6030,6140]
simple_stmt [6042,6152]
===
match
---
name: sleep [3095,3100]
name: sleep [3123,3128]
===
match
---
assert_stmt [3161,3176]
assert_stmt [3189,3204]
===
match
---
number: 0 [7562,7563]
number: 0 [7574,7575]
===
match
---
operator: = [3593,3594]
operator: = [3621,3622]
===
match
---
string: 'airflow' [3814,3823]
string: 'airflow' [3834,3843]
===
match
---
parameters [7409,7415]
parameters [7421,7427]
===
match
---
testlist_comp [3814,3940]
testlist_comp [3834,3960]
===
match
---
name: autouse [1915,1922]
name: autouse [1943,1950]
===
match
---
operator: > [4119,4120]
operator: > [4139,4140]
===
match
---
expr_stmt [2739,2786]
expr_stmt [2767,2814]
===
match
---
import_as_name [1050,1068]
import_as_name [1035,1053]
===
match
---
string: 'test' [2913,2919]
string: 'test' [2941,2947]
===
match
---
trailer [3347,3349]
trailer [3375,3377]
===
match
---
dotted_name [1224,1243]
dotted_name [1252,1271]
===
match
---
trailer [7185,7191]
trailer [7197,7203]
===
match
---
atom_expr [5691,5711]
atom_expr [5703,5723]
===
match
---
dotted_name [1028,1042]
dotted_name [1013,1027]
===
match
---
assert_stmt [3397,3467]
assert_stmt [3425,3495]
===
match
---
argument [6513,6540]
argument [6525,6552]
===
match
---
comparison [4138,4159]
comparison [4158,4179]
===
match
---
string: 'INFO' [1832,1838]
string: 'INFO' [1860,1866]
===
match
---
operator: { [1600,1601]
operator: { [1628,1629]
===
match
---
name: runner [6994,7000]
name: runner [7006,7012]
===
match
---
trailer [3699,3711]
trailer [3727,3739]
===
match
---
name: mock [4766,4770]
name: mock [4786,4790]
===
match
---
simple_stmt [3397,3468]
simple_stmt [3425,3496]
===
match
---
name: State [1213,1218]
name: State [1241,1246]
===
match
---
atom_expr [5236,5251]
atom_expr [5248,5263]
===
match
---
import_name [918,931]
import_name [903,916]
===
match
---
suite [2378,2407]
suite [2406,2435]
===
match
---
name: os [7517,7519]
name: os [7529,7531]
===
match
---
simple_stmt [904,918]
simple_stmt [889,903]
===
match
---
atom [2363,2365]
atom [2391,2393]
===
match
---
simple_stmt [817,827]
simple_stmt [802,812]
===
match
---
name: execution_date [6381,6395]
name: execution_date [6393,6407]
===
match
---
simple_stmt [6618,6635]
simple_stmt [6630,6647]
===
match
---
name: getuser [4893,4900]
name: getuser [4905,4912]
===
match
---
simple_stmt [6016,6021]
simple_stmt [6028,6033]
===
match
---
with_item [7181,7196]
with_item [7193,7208]
===
match
---
name: self [1967,1971]
name: self [1995,1999]
===
match
---
operator: , [1761,1762]
operator: , [1789,1790]
===
match
---
name: runner [3484,3490]
name: runner [3512,3518]
===
match
---
name: dag [6201,6204]
name: dag [6213,6216]
===
match
---
expr_stmt [3740,3950]
expr_stmt [3760,3970]
===
match
---
expr_stmt [5909,5938]
expr_stmt [5921,5950]
===
match
---
expr_stmt [5161,5204]
expr_stmt [5173,5216]
===
match
---
atom_expr [3484,3504]
atom_expr [3512,3532]
===
match
---
trailer [6865,6873]
trailer [6877,6885]
===
match
---
name: run_as_user [3700,3711]
name: run_as_user [3728,3739]
===
match
---
operator: { [1621,1622]
operator: { [1649,1650]
===
match
---
operator: , [2899,2900]
operator: , [2927,2928]
===
match
---
operator: , [4994,4995]
operator: , [5006,5007]
===
match
---
name: commit [6626,6632]
name: commit [6638,6644]
===
match
---
operator: == [7538,7540]
operator: == [7550,7552]
===
match
---
name: caplog [5760,5766]
name: caplog [5772,5778]
===
match
---
name: execution_date [6513,6527]
name: execution_date [6525,6539]
===
match
---
trailer [4870,4882]
trailer [4890,4902]
===
match
---
name: TestStandardTaskRunner [1871,1893]
name: TestStandardTaskRunner [1899,1921]
===
match
---
atom [7463,7478]
atom [7475,7490]
===
match
---
operator: , [1446,1447]
operator: , [1474,1475]
===
match
---
name: airflow_logger [2337,2351]
name: airflow_logger [2365,2379]
===
match
---
name: pgid [3168,3172]
name: pgid [3196,3200]
===
match
---
string: 'AIRFLOW__CORE__DAGS_FOLDER' [1295,1323]
string: 'AIRFLOW__CORE__DAGS_FOLDER' [1323,1351]
===
match
---
trailer [7000,7010]
trailer [7012,7022]
===
match
---
trailer [2728,2730]
trailer [2756,2758]
===
match
---
trailer [3650,3660]
trailer [3678,3688]
===
match
---
name: pid [3148,3151]
name: pid [3176,3179]
===
match
---
name: logging_and_db [1952,1966]
name: logging_and_db [1980,1994]
===
match
---
assert_stmt [7295,7365]
assert_stmt [7307,7377]
===
match
---
expr_stmt [4061,4098]
expr_stmt [4081,4118]
===
match
---
simple_stmt [4131,4213]
simple_stmt [4151,4233]
===
match
---
string: 'class' [1635,1642]
string: 'class' [1663,1670]
===
match
---
name: MagicMock [4822,4831]
name: MagicMock [4842,4851]
===
match
---
simple_stmt [802,817]
simple_stmt [787,802]
===
match
---
string: """         This fixture sets up logging to have a different setup on the way in         (as the test environment does not have enough context for the normal         way to run) and ensures they reset back to normal on the way out.         """ [1982,2225]
string: """         This fixture sets up logging to have a different setup on the way in         (as the test environment does not have enough context for the normal         way to run) and ensures they reset back to normal on the way out.         """ [2010,2253]
===
match
---
name: LOGGING_CONFIG [2245,2259]
name: LOGGING_CONFIG [2273,2287]
===
match
---
trailer [6698,6700]
trailer [6710,6712]
===
match
---
simple_stmt [6778,6816]
simple_stmt [6790,6828]
===
match
---
trailer [4156,4159]
trailer [4176,4179]
===
match
---
name: getpgid [5553,5560]
name: getpgid [5565,5572]
===
match
---
dictorsetmaker [1610,1762]
dictorsetmaker [1638,1790]
===
match
---
name: terminate [7001,7010]
name: terminate [7013,7022]
===
match
---
name: dag_folder [6066,6076]
name: dag_folder [6078,6088]
===
match
---
simple_stmt [6494,6542]
simple_stmt [6506,6554]
===
match
---
name: runner [4277,4283]
name: runner [4297,4303]
===
match
---
operator: = [6783,6784]
operator: = [6795,6796]
===
match
---
name: mock [4817,4821]
name: mock [4837,4841]
===
match
---
name: time [834,838]
name: time [819,823]
===
match
---
trailer [6160,6165]
trailer [6172,6177]
===
match
---
operator: = [6949,6950]
operator: = [6961,6962]
===
match
---
for_stmt [7425,7645]
for_stmt [7437,7657]
===
match
---
simple_stmt [5909,5939]
simple_stmt [5921,5951]
===
match
---
fstring_start: f" [4386,4388]
fstring_start: f" [4406,4408]
===
match
---
trailer [6501,6541]
trailer [6513,6553]
===
match
---
atom_expr [7550,7558]
atom_expr [7562,7570]
===
match
---
trailer [2672,2674]
trailer [2700,2702]
===
match
---
operator: , [5015,5016]
operator: , [5027,5028]
===
match
---
name: pid [6811,6814]
name: pid [6823,6826]
===
match
---
suite [7416,7645]
suite [7428,7657]
===
match
---
trailer [5709,5711]
trailer [5721,5723]
===
match
---
string: """         Test that ensures that clearing in the UI SIGTERMS         the task         """ [5809,5900]
string: """         Test that ensures that clearing in the UI SIGTERMS         the task         """ [5821,5912]
===
match
---
name: psutil [7437,7443]
name: psutil [7449,7455]
===
match
---
name: list [4234,4238]
name: list [4254,4258]
===
match
---
atom_expr [6290,6485]
atom_expr [6302,6497]
===
match
---
expr_stmt [6550,6609]
expr_stmt [6562,6621]
===
match
---
atom_expr [4013,4027]
atom_expr [4033,4047]
===
match
---
name: state [6348,6353]
name: state [6360,6365]
===
match
---
name: processes [6939,6948]
name: processes [6951,6960]
===
match
---
trailer [4856,4870]
trailer [4876,4890]
===
match
---
atom_expr [7324,7335]
atom_expr [7336,7347]
===
match
---
trailer [3987,4003]
trailer [4007,4023]
===
match
---
name: DEFAULT_DATE [6433,6445]
name: DEFAULT_DATE [6445,6457]
===
match
---
trailer [3124,3132]
trailer [3152,3160]
===
match
---
trailer [4379,4383]
trailer [4399,4403]
===
match
---
name: state [1200,1205]
name: state [1228,1233]
===
match
---
name: runner [5561,5567]
name: runner [5573,5579]
===
match
---
name: runner [6644,6650]
name: runner [6656,6662]
===
match
---
name: exists [7105,7111]
name: exists [7117,7123]
===
match
---
trailer [4260,4266]
trailer [4280,4286]
===
match
---
trailer [4078,4098]
trailer [4098,4118]
===
match
---
name: pid [4094,4097]
name: pid [4114,4117]
===
match
---
atom_expr [3714,3731]
atom_expr [3742,3751]
===
match
---
assert_stmt [6848,6929]
assert_stmt [6860,6941]
===
match
---
fstring [5599,5621]
fstring [5611,5633]
===
match
---
trailer [2307,2317]
trailer [2335,2345]
===
match
---
trailer [2351,2360]
trailer [2379,2388]
===
match
---
name: pid [7555,7558]
name: pid [7567,7570]
===
match
---
name: pytest [1900,1906]
name: pytest [1928,1934]
===
match
---
operator: = [3286,3287]
operator: = [3314,3315]
===
match
---
operator: = [6122,6123]
operator: = [6134,6135]
===
match
---
operator: @ [1899,1900]
operator: @ [1927,1928]
===
match
---
name: StandardTaskRunner [1127,1145]
name: StandardTaskRunner [1112,1130]
===
match
---
atom_expr [2300,2328]
atom_expr [2328,2356]
===
match
---
name: airflow [1151,1158]
name: airflow [1136,1143]
===
match
---
trailer [3147,3151]
trailer [3175,3179]
===
match
---
operator: , [3438,3439]
operator: , [3466,3467]
===
match
---
operator: , [1582,1583]
operator: , [1610,1611]
===
match
---
simple_stmt [839,877]
simple_stmt [824,862]
===
match
---
name: os [5550,5552]
name: os [5562,5564]
===
match
---
name: LOGGING_CONFIG [1372,1386]
name: LOGGING_CONFIG [1400,1414]
===
match
---
name: _ [7066,7067]
name: _ [7078,7079]
===
match
---
argument [7457,7478]
argument [7469,7490]
===
match
---
trailer [3100,3105]
trailer [3128,3133]
===
match
---
name: mock [898,902]
name: mock [883,887]
===
match
---
atom_expr [4036,4051]
atom_expr [4056,4071]
===
match
---
trailer [1286,1294]
trailer [1314,1322]
===
match
---
atom [1797,1858]
atom [1825,1886]
===
match
---
operator: = [4232,4233]
operator: = [4252,4253]
===
match
---
operator: = [6432,6433]
operator: = [6444,6445]
===
match
---
simple_stmt [1266,1325]
simple_stmt [1294,1353]
===
match
---
expr_stmt [4749,4777]
expr_stmt [4769,4797]
===
match
---
operator: = [6527,6528]
operator: = [6539,6540]
===
match
---
atom_expr [6618,6634]
atom_expr [6630,6646]
===
match
---
string: 'task1' [3906,3913]
string: 'task1' [3926,3933]
===
match
---
name: get_task [6205,6213]
name: get_task [6217,6225]
===
match
---
operator: , [2878,2879]
operator: , [2906,2907]
===
match
---
name: timezone [1341,1349]
name: timezone [1369,1377]
===
match
---
operator: @ [7371,7372]
operator: @ [7383,7384]
===
match
---
operator: , [3913,3914]
operator: , [3933,3934]
===
match
---
trailer [4448,4450]
trailer [4468,4470]
===
match
---
dotted_name [1900,1914]
dotted_name [1928,1942]
===
match
---
trailer [6250,6258]
trailer [6262,6270]
===
match
---
trailer [3042,3058]
trailer [3070,3086]
===
match
---
name: StandardTaskRunner [3024,3042]
name: StandardTaskRunner [3052,3070]
===
match
---
expr_stmt [6939,6984]
expr_stmt [6951,6996]
===
match
---
assert_stmt [6824,6839]
assert_stmt [6836,6851]
===
match
---
string: 'test' [3858,3864]
string: 'test' [3878,3884]
===
match
---
parameters [1966,1972]
parameters [1994,2000]
===
match
---
simple_stmt [5809,5901]
simple_stmt [5821,5913]
===
match
---
import_as_names [953,969]
import_as_names [938,954]
===
match
---
simple_stmt [1982,2226]
simple_stmt [2010,2254]
===
match
---
atom_expr [6354,6367]
atom_expr [6366,6379]
===
match
---
atom_expr [3426,3437]
atom_expr [3454,3465]
===
match
---
name: return_code [3491,3502]
name: return_code [3519,3530]
===
match
---
trailer [3754,3768]
trailer [3774,3788]
===
match
---
simple_stmt [6194,6223]
simple_stmt [6206,6235]
===
match
---
name: start [5220,5225]
name: start [5232,5237]
===
match
---
operator: , [959,960]
operator: , [944,945]
===
match
---
operator: = [6583,6584]
operator: = [6595,6596]
===
match
---
name: process_iter [7444,7456]
name: process_iter [7456,7468]
===
match
---
import_name [817,826]
import_name [802,811]
===
match
---
dotted_name [1151,1164]
dotted_name [1136,1149]
===
match
---
simple_stmt [2795,3006]
simple_stmt [2823,3034]
===
match
---
name: process [4086,4093]
name: process [4106,4113]
===
match
---
simple_stmt [2592,2597]
simple_stmt [2620,2625]
===
match
---
simple_stmt [2646,2675]
simple_stmt [2674,2703]
===
match
---
trailer [7532,7536]
trailer [7544,7548]
===
match
---
arglist [6066,6129]
arglist [6078,6141]
===
match
---
name: RUNNING [6360,6367]
name: RUNNING [6372,6379]
===
match
---
name: DEFAULT_DATE [6528,6540]
name: DEFAULT_DATE [6540,6552]
===
match
---
name: terminate [4284,4293]
name: terminate [4304,4313]
===
match
---
expr_stmt [3115,3152]
expr_stmt [3143,3180]
===
match
---
name: airflow [1074,1081]
name: airflow [1059,1066]
===
match
---
fstring_end: " [4412,4413]
fstring_end: " [4432,4433]
===
match
---
name: processes [4222,4231]
name: processes [4242,4251]
===
match
---
trailer [2767,2779]
trailer [2795,2807]
===
match
---
trailer [6873,6876]
trailer [6885,6888]
===
match
---
name: getpgid [4071,4078]
name: getpgid [4091,4098]
===
match
---
operator: { [4388,4389]
operator: { [4408,4409]
===
match
---
operator: , [5063,5064]
operator: , [5075,5076]
===
match
---
atom_expr [3969,4003]
atom_expr [3989,4023]
===
match
---
argument [6422,6445]
argument [6434,6457]
===
match
---
name: unittest [882,890]
name: unittest [867,875]
===
match
---
simple_stmt [918,932]
simple_stmt [903,917]
===
match
---
fstring_string:  is still alive [4397,4412]
fstring_string:  is still alive [4417,4432]
===
match
---
name: runner [3015,3021]
name: runner [3043,3049]
===
match
---
name: test_on_kill [5781,5793]
name: test_on_kill [5793,5805]
===
match
---
trailer [5635,5641]
trailer [5647,5653]
===
match
---
name: path [7100,7104]
name: path [7112,7116]
===
match
---
trailer [4770,4775]
trailer [4790,4795]
===
match
---
simple_stmt [3015,3059]
simple_stmt [3043,3087]
===
match
---
name: terminate [5663,5672]
name: terminate [5675,5684]
===
match
---
trailer [6213,6222]
trailer [6225,6234]
===
match
---
string: 'airflow' [2318,2327]
string: 'airflow' [2346,2355]
===
match
---
name: command_as_list [4940,4955]
name: command_as_list [4952,4967]
===
match
---
trailer [5240,5246]
trailer [5252,5258]
===
match
---
string: "test" [6328,6334]
string: "test" [6340,6346]
===
match
---
trailer [6955,6984]
trailer [6967,6996]
===
match
---
trailer [7099,7104]
trailer [7111,7116]
===
match
---
suite [7118,7141]
suite [7130,7153]
===
match
---
string: "ON_KILL_TEST" [7217,7231]
string: "ON_KILL_TEST" [7229,7243]
===
match
---
atom_expr [2795,2852]
atom_expr [2823,2880]
===
match
---
operator: = [4764,4765]
operator: = [4784,4785]
===
match
---
trailer [6671,6677]
trailer [6683,6689]
===
match
---
atom_expr [4430,4450]
atom_expr [4450,4470]
===
match
---
trailer [5552,5560]
trailer [5564,5572]
===
match
---
import_name [827,838]
import_name [812,823]
===
match
---
trailer [3210,3213]
trailer [3238,3241]
===
match
---
trailer [5225,5227]
trailer [5237,5239]
===
match
---
name: runner [3067,3073]
name: runner [3095,3101]
===
match
---
name: process [4309,4316]
name: process [4329,4336]
===
match
---
atom_expr [4817,4833]
atom_expr [4837,4853]
===
match
---
simple_stmt [3067,3082]
simple_stmt [3095,3110]
===
match
---
fstring [3440,3467]
fstring [3468,3495]
===
match
---
name: os [4146,4148]
name: os [4166,4168]
===
match
---
suite [1894,7645]
suite [1922,7657]
===
match
---
suite [7282,7366]
suite [7294,7378]
===
match
---
operator: , [6474,6475]
operator: , [6486,6487]
===
match
---
operator: } [7348,7349]
operator: } [7360,7361]
===
match
---
trailer [3297,3314]
trailer [3325,3342]
===
match
---
expr_stmt [3615,3662]
expr_stmt [3643,3690]
===
match
---
simple_stmt [5964,5980]
simple_stmt [5976,5992]
===
match
---
fstring_expr [5614,5620]
fstring_expr [5626,5632]
===
match
---
operator: != [7559,7561]
operator: != [7571,7573]
===
match
---
trailer [4046,4051]
trailer [4066,4071]
===
match
---
operator: = [2661,2662]
operator: = [2689,2690]
===
match
---
name: getLogger [2308,2317]
name: getLogger [2336,2345]
===
match
---
testlist_comp [4985,5111]
testlist_comp [4997,5123]
===
match
---
simple_stmt [1326,1371]
simple_stmt [1354,1399]
===
match
---
trailer [5598,5622]
trailer [5610,5634]
===
match
---
dotted_name [844,858]
dotted_name [829,843]
===
match
---
operator: = [1339,1340]
operator: = [1367,1368]
===
match
---
simple_stmt [7585,7596]
simple_stmt [7597,7608]
===
match
---
name: runner [3960,3966]
name: runner [3980,3986]
===
match
---
operator: = [6497,6498]
operator: = [6509,6510]
===
match
---
operator: = [3712,3713]
operator: = [3740,3741]
===
match
---
for_stmt [4305,4414]
for_stmt [4325,4434]
===
match
---
atom_expr [6154,6185]
atom_expr [6166,6197]
===
match
---
if_stmt [7094,7141]
if_stmt [7106,7153]
===
match
---
simple_stmt [6644,6678]
simple_stmt [6656,6690]
===
match
---
name: task [6194,6198]
name: task [6206,6210]
===
match
---
name: standard_task_runner [1099,1119]
name: standard_task_runner [1084,1104]
===
match
---
number: 0 [4157,4158]
number: 0 [4177,4178]
===
match
---
string: 'ext://sys.stdout' [1732,1750]
string: 'ext://sys.stdout' [1760,1778]
===
match
---
name: start_date [6422,6432]
name: start_date [6434,6444]
===
match
---
trailer [2809,2823]
trailer [2837,2851]
===
match
---
trailer [6765,6768]
trailer [6777,6780]
===
match
---
operator: = [6327,6328]
operator: = [6339,6340]
===
match
---
except_clause [5988,6002]
except_clause [6000,6014]
===
match
---
name: pid [3434,3437]
name: pid [3462,3465]
===
match
---
name: Mock [4771,4775]
name: Mock [4791,4795]
===
match
---
simple_stmt [2337,2366]
simple_stmt [2365,2394]
===
match
---
suite [6003,6021]
suite [6015,6033]
===
match
---
simple_stmt [4423,4463]
simple_stmt [4443,4483]
===
match
---
name: getuser [3722,3729]
name: getuser [3742,3749]
===
match
---
operator: , [4159,4160]
operator: , [4179,4180]
===
match
---
trailer [6204,6213]
trailer [6216,6225]
===
match
---
atom_expr [6951,6984]
atom_expr [6963,6996]
===
match
---
expr_stmt [6232,6260]
expr_stmt [6244,6272]
===
match
---
atom_expr [6796,6814]
atom_expr [6808,6826]
===
match
---
operator: , [6445,6446]
operator: , [6457,6458]
===
match
---
number: 1 [1365,1366]
number: 1 [1393,1394]
===
match
---
simple_stmt [3671,3732]
simple_stmt [3699,3752]
===
match
---
name: tests [1224,1229]
name: tests [1252,1257]
===
match
---
trailer [3685,3699]
trailer [3713,3727]
===
match
---
trailer [4148,4156]
trailer [4168,4176]
===
match
---
suite [1973,2597]
suite [2001,2625]
===
match
---
fstring_start: f" [7338,7340]
fstring_start: f" [7350,7352]
===
match
---
string: 'console' [1610,1619]
string: 'console' [1638,1647]
===
match
---
name: TEST_DAG_FOLDER [6077,6092]
name: TEST_DAG_FOLDER [6089,6104]
===
match
---
operator: { [1492,1493]
operator: { [1520,1521]
===
match
---
trailer [5973,5979]
trailer [5985,5991]
===
match
---
operator: } [1760,1761]
operator: } [1788,1789]
===
match
---
atom_expr [6755,6768]
atom_expr [6767,6780]
===
match
---
expr_stmt [3578,3606]
expr_stmt [3606,3634]
===
match
---
simple_stmt [5236,5252]
simple_stmt [5248,5264]
===
match
---
simple_stmt [4786,4834]
simple_stmt [4806,4854]
===
match
---
atom_expr [5561,5579]
atom_expr [5573,5591]
===
match
---
operator: , [7336,7337]
operator: , [7348,7349]
===
match
---
fstring_end: " [7364,7365]
fstring_end: " [7376,7377]
===
match
---
argument [6502,6511]
argument [6514,6523]
===
match
---
number: 0 [6838,6839]
number: 0 [6850,6851]
===
match
---
name: pgid [6778,6782]
name: pgid [6790,6794]
===
match
---
expr_stmt [2283,2328]
expr_stmt [2311,2356]
===
match
---
fstring_start: f" [5599,5601]
fstring_start: f" [5611,5613]
===
match
---
assert_stmt [4131,4212]
assert_stmt [4151,4232]
===
match
---
operator: , [6408,6409]
operator: , [6420,6421]
===
match
---
name: local_task_job [3043,3057]
name: local_task_job [3071,3085]
===
match
---
operator: = [2712,2713]
operator: = [2740,2741]
===
match
---
operator: = [3644,3645]
operator: = [3672,3673]
===
match
---
operator: , [2947,2948]
operator: , [2975,2976]
===
match
---
name: pid [4380,4383]
name: pid [4400,4403]
===
match
---
name: TaskInstance [1050,1062]
name: TaskInstance [1035,1047]
===
match
---
arglist [6321,6475]
arglist [6333,6487]
===
match
---
expr_stmt [1372,1862]
expr_stmt [1400,1890]
===
match
---
dictorsetmaker [1798,1857]
dictorsetmaker [1826,1885]
===
match
---
name: runner [5213,5219]
name: runner [5225,5231]
===
match
---
trailer [3314,3320]
trailer [3342,3348]
===
match
---
operator: , [3844,3845]
operator: , [3864,3865]
===
match
---
comparison [7550,7563]
comparison [7562,7575]
===
match
---
atom [1810,1821]
atom [1838,1849]
===
match
---
name: dags [6161,6165]
name: dags [6173,6177]
===
match
---
atom_expr [4234,4267]
atom_expr [4254,4287]
===
match
---
name: handlers [2352,2360]
name: handlers [2380,2388]
===
match
---
simple_stmt [970,1023]
simple_stmt [955,1008]
===
match
---
trailer [3660,3662]
trailer [3688,3690]
===
match
---
name: process [7261,7268]
name: process [7273,7280]
===
match
---
atom [2855,3005]
atom [2883,3033]
===
match
---
if_stmt [7514,7596]
if_stmt [7526,7608]
===
match
---
trailer [2823,2839]
trailer [2851,2867]
===
match
---
fstring [4386,4413]
fstring [4406,4433]
===
match
---
trailer [7104,7111]
trailer [7116,7123]
===
match
---
operator: = [6240,6241]
operator: = [6252,6253]
===
match
---
trailer [5188,5204]
trailer [5200,5216]
===
match
---
name: mock [2714,2718]
name: mock [2742,2746]
===
match
---
fstring_expr [7340,7349]
fstring_expr [7352,7361]
===
match
---
name: models [953,959]
name: models [938,944]
===
match
---
fstring [7338,7365]
fstring [7350,7377]
===
match
---
name: timezone [1172,1180]
name: timezone [1157,1165]
===
match
---
comparison [7517,7545]
comparison [7529,7557]
===
match
---
operator: = [6076,6077]
operator: = [6088,6089]
===
match
---
trailer [3337,3347]
trailer [3365,3375]
===
match
---
trailer [5672,5674]
trailer [5684,5686]
===
match
---
trailer [5966,5973]
trailer [5978,5985]
===
match
---
name: command_as_list [3769,3784]
name: command_as_list [3789,3804]
===
match
---
operator: } [1861,1862]
operator: } [1889,1890]
===
match
---
fstring_expr [4388,4397]
fstring_expr [4408,4417]
===
match
---
name: local_task_job [4749,4763]
name: local_task_job [4769,4783]
===
match
---
string: 'airflow.task' [1476,1490]
string: 'airflow.task' [1504,1518]
===
match
---
trailer [4238,4267]
trailer [4258,4287]
===
match
---
name: utils [1159,1164]
name: utils [1144,1149]
===
match
---
simple_stmt [5684,5718]
simple_stmt [5696,5730]
===
match
---
name: DagBag [6046,6052]
name: DagBag [6058,6064]
===
match
---
name: pgid [3115,3119]
name: pgid [3143,3147]
===
match
---
name: path [5909,5913]
name: path [5921,5925]
===
match
---
fstring_end: " [5620,5621]
fstring_end: " [5632,5633]
===
match
---
simple_stmt [4749,4778]
simple_stmt [4769,4798]
===
match
---
not_test [3404,3438]
not_test [3432,3466]
===
match
---
name: pytest [925,931]
name: pytest [910,916]
===
match
---
operator: = [3120,3121]
operator: = [3148,3149]
===
match
---
name: processes [4320,4329]
name: processes [4340,4349]
===
match
---
simple_stmt [4842,4903]
simple_stmt [4862,4915]
===
match
---
funcdef [4468,5772]
funcdef [4488,5784]
===
match
---
name: processes [3276,3285]
name: processes [3304,3313]
===
match
---
trailer [5246,5251]
trailer [5258,5263]
===
match
---
except_clause [7608,7622]
except_clause [7620,7634]
===
match
---
simple_stmt [7295,7366]
simple_stmt [7307,7378]
===
match
---
comp_op [3505,3511]
comp_op [3533,3539]
===
match
---
atom_expr [3595,3606]
atom_expr [3623,3634]
===
match
---
atom_expr [4079,4097]
atom_expr [4099,4117]
===
match
---
comparison [4430,4462]
comparison [4450,4482]
===
match
---
suite [2469,2597]
suite [2497,2625]
===
match
---
operator: { [1797,1798]
operator: { [1825,1826]
===
match
---
simple_stmt [4107,4123]
simple_stmt [4127,4143]
===
match
---
dictorsetmaker [1635,1751]
dictorsetmaker [1663,1779]
===
match
---
string: 'console' [1811,1820]
string: 'console' [1839,1848]
===
match
---
number: 0.2 [5247,5250]
number: 0.2 [5259,5262]
===
match
---
operator: = [4883,4884]
operator: = [4903,4904]
===
match
---
atom_expr [6039,6139]
atom_expr [6051,6151]
===
match
---
number: 0 [6874,6875]
number: 0 [6886,6887]
===
match
---
simple_stmt [5543,5581]
simple_stmt [5555,5593]
===
match
---
atom_expr [6686,6700]
atom_expr [6698,6712]
===
match
---
atom_expr [5213,5227]
atom_expr [5225,5239]
===
match
---
operator: = [5548,5549]
operator: = [5560,5561]
===
match
---
atom_expr [5656,5674]
atom_expr [5668,5686]
===
match
---
atom_expr [4842,4882]
atom_expr [4862,4902]
===
match
---
trailer [3079,3081]
trailer [3107,3109]
===
match
---
expr_stmt [6494,6541]
expr_stmt [6506,6553]
===
match
---
operator: , [6334,6335]
operator: , [6346,6347]
===
match
---
import_name [904,917]
import_name [889,902]
===
match
---
atom_expr [5589,5622]
atom_expr [5601,5634]
===
match
---
name: runner [5656,5662]
name: runner [5668,5674]
===
match
---
string: 'test' [5029,5035]
string: 'test' [5041,5047]
===
match
---
name: self [6956,6960]
name: self [6968,6972]
===
match
---
name: runner [4079,4085]
name: runner [4099,4105]
===
match
---
trailer [6960,6977]
trailer [6972,6989]
===
match
---
atom_expr [4068,4098]
atom_expr [4088,4118]
===
match
---
name: psutil [911,917]
name: psutil [896,902]
===
match
---
name: return_value [2840,2852]
name: return_value [2868,2880]
===
match
---
simple_stmt [4061,4099]
simple_stmt [4081,4119]
===
match
---
argument [6381,6408]
argument [6393,6420]
===
match
---
simple_stmt [6550,6610]
simple_stmt [6562,6622]
===
match
---
name: os [7097,7099]
name: os [7109,7111]
===
match
---
expr_stmt [2646,2674]
expr_stmt [2674,2702]
===
match
---
expr_stmt [3960,4003]
expr_stmt [3980,4023]
===
match
---
operator: , [1575,1576]
operator: , [1603,1604]
===
match
---
simple_stmt [1181,1219]
simple_stmt [1209,1247]
===
match
---
simple_stmt [5631,5647]
simple_stmt [5643,5659]
===
match
---
string: "/tmp/airflow_on_kill" [5916,5938]
string: "/tmp/airflow_on_kill" [5928,5950]
===
match
---
name: os [4068,4070]
name: os [4088,4090]
===
match
---
name: os [3122,3124]
name: os [3150,3152]
===
match
---
simple_stmt [3276,3322]
simple_stmt [3304,3350]
===
match
---
atom_expr [3331,3349]
atom_expr [3359,3377]
===
match
---
atom_expr [6956,6983]
atom_expr [6968,6995]
===
match
---
name: runner [5691,5697]
name: runner [5703,5709]
===
match
---
name: proc [7429,7433]
name: proc [7441,7445]
===
match
---
name: Exception [2422,2431]
name: Exception [2450,2459]
===
match
---
argument [6588,6608]
argument [6600,6620]
===
match
---
operator: = [3967,3968]
operator: = [3987,3988]
===
match
---
name: run_as_user [4871,4882]
name: run_as_user [4891,4902]
===
match
---
atom_expr [3408,3438]
atom_expr [3436,3466]
===
match
---
suite [4330,4414]
suite [4350,4434]
===
match
---
simple_stmt [1146,1181]
simple_stmt [1131,1166]
===
match
---
name: os [5964,5966]
name: os [5976,5978]
===
match
---
name: task [6507,6511]
name: task [6519,6523]
===
match
---
trailer [7554,7558]
trailer [7566,7570]
===
match
---
trailer [7312,7323]
trailer [7324,7335]
===
match
---
name: sleep [5636,5641]
name: sleep [5648,5653]
===
match
---
name: os [5589,5591]
name: os [5601,5603]
===
match
---
trailer [6359,6367]
trailer [6371,6379]
===
match
---
operator: , [5110,5111]
operator: , [5122,5123]
===
match
---
operator: = [4969,4970]
operator: = [4981,4982]
===
match
---
operator: } [1858,1859]
operator: } [1886,1887]
===
match
---
atom [1466,1582]
atom [1494,1610]
===
match
---
number: 9 [5716,5717]
number: 9 [5728,5729]
===
match
---
import_from [970,1022]
import_from [955,1007]
===
match
---
simple_stmt [6686,6701]
simple_stmt [6698,6713]
===
match
---
simple_stmt [6939,6985]
simple_stmt [6951,6997]
===
match
---
name: dag [6148,6151]
name: dag [6160,6163]
===
match
---
atom_expr [2391,2406]
atom_expr [2419,2434]
===
match
---
arglist [1915,1942]
arglist [1943,1970]
===
match
---
name: process [3140,3147]
name: process [3168,3175]
===
match
---
name: sleep [7158,7163]
name: sleep [7170,7175]
===
match
---
testlist_comp [7464,7477]
testlist_comp [7476,7489]
===
match
---
name: settings [961,969]
name: settings [946,954]
===
match
---
simple_stmt [6755,6769]
simple_stmt [6767,6781]
===
match
---
name: time [5236,5240]
name: time [5248,5252]
===
match
---
operator: = [3022,3023]
operator: = [3050,3051]
===
match
---
name: f [7235,7236]
name: f [7247,7248]
===
match
---
atom_expr [2234,2260]
atom_expr [2262,2288]
===
match
---
simple_stmt [7210,7248]
simple_stmt [7222,7260]
===
match
---
atom_expr [5631,5646]
atom_expr [5643,5658]
===
match
---
trailer [6759,6765]
trailer [6771,6777]
===
match
---
name: local_task_job [2739,2753]
name: local_task_job [2767,2781]
===
match
---
not_test [7302,7336]
not_test [7314,7348]
===
match
---
trailer [4070,4078]
trailer [4090,4098]
===
match
---
dictorsetmaker [1395,1860]
dictorsetmaker [1423,1888]
===
match
---
trailer [6977,6983]
trailer [6989,6995]
===
match
---
argument [6459,6474]
argument [6471,6486]
===
match
---
operator: , [2919,2920]
operator: , [2947,2948]
===
match
---
name: getpgid [4149,4156]
name: getpgid [4169,4176]
===
match
---
name: task_instance [3755,3768]
name: task_instance [3775,3788]
===
match
---
name: DEFAULT_DATE [1326,1338]
name: DEFAULT_DATE [1354,1366]
===
match
---
name: local_task_job [2795,2809]
name: local_task_job [2823,2837]
===
match
---
name: getpgid [3125,3132]
name: getpgid [3153,3160]
===
match
---
operator: { [1466,1467]
operator: { [1494,1495]
===
match
---
name: Mock [3600,3604]
name: Mock [3628,3632]
===
match
---
fstring_string: kill -s KILL  [5601,5614]
fstring_string: kill -s KILL  [5613,5626]
===
match
---
name: LocalTaskJob [1010,1022]
name: LocalTaskJob [995,1007]
===
match
---
name: runner [6686,6692]
name: runner [6698,6704]
===
match
---
trailer [7443,7456]
trailer [7455,7468]
===
match
---
name: time [6755,6759]
name: time [6767,6771]
===
match
---
name: Mock [2668,2672]
name: Mock [2696,2700]
===
match
---
operator: { [5614,5615]
operator: { [5626,5627]
===
match
---
name: _procs_in_pgroup [3298,3314]
name: _procs_in_pgroup [3326,3342]
===
match
---
atom [1389,1862]
atom [1417,1890]
===
match
---
trailer [5641,5646]
trailer [5653,5658]
===
match
---
operator: , [6511,6512]
operator: , [6523,6524]
===
match
---
name: db [1241,1243]
name: db [1269,1271]
===
match
---
operator: = [6651,6652]
operator: = [6663,6664]
===
match
---
trailer [5560,5580]
trailer [5572,5592]
===
match
---
name: local_task_job [3615,3629]
name: local_task_job [3643,3657]
===
match
---
name: task_instance [4926,4939]
name: task_instance [4938,4951]
===
match
---
operator: , [4497,4498]
operator: , [4517,4518]
===
match
---
name: session [6618,6625]
name: session [6630,6637]
===
match
---
string: 'name' [7471,7477]
string: 'name' [7483,7489]
===
match
---
dotted_name [1074,1119]
dotted_name [1059,1104]
===
match
---
name: psutil [3408,3414]
name: psutil [3436,3442]
===
match
---
trailer [4371,4384]
trailer [4391,4404]
===
match
---
simple_stmt [5656,5675]
simple_stmt [5668,5687]
===
match
---
trailer [4040,4046]
trailer [4060,4066]
===
match
---
expr_stmt [5543,5580]
expr_stmt [5555,5592]
===
match
---
name: pgid [3315,3319]
name: pgid [3343,3347]
===
match
---
simple_stmt [5213,5228]
simple_stmt [5225,5240]
===
match
---
simple_stmt [3161,3177]
simple_stmt [3189,3205]
===
match
---
string: 'format' [1493,1501]
string: 'format' [1521,1529]
===
match
---
operator: , [1927,1928]
operator: , [1955,1956]
===
match
---
operator: , [3939,3940]
operator: , [3959,3960]
===
match
---
name: self [5794,5798]
name: self [5806,5810]
===
match
---
operator: != [4143,4145]
operator: != [4163,4165]
===
match
---
trailer [3094,3100]
trailer [3122,3128]
===
match
---
arglist [6502,6540]
arglist [6514,6552]
===
match
---
arglist [1359,1369]
arglist [1387,1397]
===
match
---
name: get [6166,6169]
name: get [6178,6181]
===
match
---
argument [6106,6128]
argument [6118,6140]
===
match
---
operator: = [2853,2854]
operator: = [2881,2882]
===
match
---
string: '[%(asctime)s] {{%(filename)s:%(lineno)d}} %(levelname)s - %(message)s' [1503,1574]
string: '[%(asctime)s] {{%(filename)s:%(lineno)d}} %(levelname)s - %(message)s' [1531,1602]
===
match
---
name: staticmethod [7372,7384]
name: staticmethod [7384,7396]
===
match
---
name: getpgid [6788,6795]
name: getpgid [6800,6807]
===
match
---
name: environ [1287,1294]
name: environ [1315,1322]
===
match
---
atom_expr [6863,6876]
atom_expr [6875,6888]
===
match
---
operator: , [1768,1769]
operator: , [1796,1797]
===
match
---
name: StandardTaskRunner [6653,6671]
name: StandardTaskRunner [6665,6683]
===
match
---
operator: > [6836,6837]
operator: > [6848,6849]
===
match
---
name: logging [844,851]
name: logging [829,836]
===
match
---
name: processes [7272,7281]
name: processes [7284,7293]
===
match
---
name: _procs_in_pgroup [4244,4260]
name: _procs_in_pgroup [4264,4280]
===
match
---
name: process [3363,3370]
name: process [3391,3398]
===
match
---
number: 2 [7164,7165]
number: 2 [7176,7177]
===
match
---
name: clear_db_runs [2391,2404]
name: clear_db_runs [2419,2432]
===
match
---
arglist [6570,6608]
arglist [6582,6620]
===
match
---
name: airflow [1028,1035]
name: airflow [1013,1020]
===
match
---
operator: , [2968,2969]
operator: , [2996,2997]
===
match
---
param [1967,1971]
param [1995,1999]
===
match
---
try_stmt [2374,2597]
try_stmt [2402,2625]
===
match
---
string: 'task1' [6214,6221]
string: 'task1' [6226,6233]
===
match
---
name: Session [6251,6258]
name: Session [6263,6270]
===
match
---
name: proc [7591,7595]
name: proc [7603,7607]
===
match
---
expr_stmt [3015,3058]
expr_stmt [3043,3086]
===
match
---
simple_stmt [3740,3951]
simple_stmt [3760,3971]
===
match
---
trailer [4939,4955]
trailer [4951,4967]
===
match
---
name: time [5631,5635]
name: time [5643,5647]
===
match
---
name: runner [3331,3337]
name: runner [3359,3365]
===
match
---
name: pid_exists [4361,4371]
name: pid_exists [4381,4391]
===
match
---
trailer [6169,6185]
trailer [6181,6197]
===
match
---
name: task_instance [4801,4814]
name: task_instance [4821,4834]
===
match
---
name: session [6467,6474]
name: session [6479,6486]
===
match
---
funcdef [2602,3517]
funcdef [2630,3545]
===
match
---
comparison [6855,6876]
comparison [6867,6888]
===
match
---
try_stmt [5947,6021]
try_stmt [5959,6033]
===
match
---
name: _procs_in_pgroup [6961,6977]
name: _procs_in_pgroup [6973,6989]
===
match
---
trailer [4019,4025]
trailer [4039,4045]
===
match
---
simple_stmt [6848,6930]
simple_stmt [6860,6942]
===
match
---
trailer [6273,6279]
trailer [6285,6291]
===
match
---
simple_stmt [6994,7013]
simple_stmt [7006,7025]
===
match
---
trailer [4360,4371]
trailer [4380,4391]
===
match
---
parameters [5793,5799]
parameters [5805,5811]
===
match
---
trailer [3629,3643]
trailer [3657,3671]
===
match
---
operator: , [6128,6129]
operator: , [6140,6141]
===
match
---
operator: = [1934,1935]
operator: = [1962,1963]
===
match
---
atom_expr [7437,7479]
atom_expr [7449,7491]
===
match
---
trailer [1294,1324]
trailer [1322,1352]
===
match
---
atom_expr [3067,3081]
atom_expr [3095,3109]
===
match
---
trailer [6569,6609]
trailer [6581,6621]
===
match
---
name: test_start_and_terminate_run_as_user [3526,3562]
name: test_start_and_terminate_run_as_user [3554,3590]
===
match
---
operator: = [6506,6507]
operator: = [6518,6519]
===
match
---
atom [3800,3950]
atom [3820,3970]
===
match
---
operator: , [5035,5036]
operator: , [5047,5048]
===
match
---
name: mock [3646,3650]
name: mock [3674,3678]
===
match
---
expr_stmt [6030,6139]
expr_stmt [6042,6151]
===
match
---
simple_stmt [7153,7167]
simple_stmt [7165,7179]
===
match
---
name: models [1036,1042]
name: models [1021,1027]
===
match
---
name: pgid [3192,3196]
name: pgid [3220,3224]
===
match
---
suite [7623,7645]
suite [7635,7657]
===
match
---
name: run_as_user [2768,2779]
name: run_as_user [2796,2807]
===
match
---
operator: = [6353,6354]
operator: = [6365,6366]
===
match
---
name: test_early_reap_exit [4472,4492]
name: test_early_reap_exit [4492,4512]
===
match
---
name: airflow [938,945]
name: airflow [923,930]
===
match
---
trailer [3502,3504]
trailer [3530,3532]
===
match
---
with_stmt [7176,7248]
with_stmt [7188,7260]
===
match
---
string: 'airflow.task' [1694,1708]
string: 'airflow.task' [1722,1736]
===
match
---
operator: = [2780,2781]
operator: = [2808,2809]
===
match
---
trailer [3604,3606]
trailer [3632,3634]
===
match
---
classdef [1865,7645]
classdef [1893,7657]
===
match
---
name: local_task_job [3740,3754]
name: local_task_job [3760,3774]
===
match
---
atom [1600,1768]
atom [1628,1796]
===
match
---
comparison [5691,5717]
comparison [5703,5729]
===
match
---
import_from [1219,1264]
import_from [1247,1292]
===
match
---
comparison [4114,4122]
comparison [4134,4142]
===
match
---
atom_expr [6201,6222]
atom_expr [6213,6234]
===
match
---
simple_stmt [1069,1146]
simple_stmt [1054,1131]
===
match
---
expr_stmt [4911,5121]
expr_stmt [4923,5133]
===
match
---
string: "Task should be in a different process group to us" [3215,3266]
string: "Task should be in a different process group to us" [3243,3294]
===
match
---
atom_expr [4354,4384]
atom_expr [4374,4404]
===
match
---
simple_stmt [3185,3267]
simple_stmt [3213,3295]
===
match
---
operator: = [7462,7463]
operator: = [7474,7475]
===
match
---
name: task_instance [3686,3699]
name: task_instance [3714,3727]
===
match
---
trailer [7111,7117]
trailer [7123,7129]
===
match
---
operator: , [5084,5085]
operator: , [5096,5097]
===
match
---
simple_stmt [1372,1863]
simple_stmt [1400,1891]
===
match
---
name: mock [2663,2667]
name: mock [2691,2695]
===
match
---
trailer [7236,7245]
trailer [7248,7257]
===
match
---
simple_stmt [2683,2731]
simple_stmt [2711,2759]
===
match
---
name: pgid [5543,5547]
name: pgid [5555,5559]
===
match
---
string: 'propagate' [1840,1851]
string: 'propagate' [1868,1879]
===
match
---
atom_expr [7097,7117]
atom_expr [7109,7129]
===
match
---
trailer [3768,3784]
trailer [3788,3804]
===
match
---
string: 'airflow' [2869,2878]
string: 'airflow' [2897,2906]
===
match
---
trailer [4775,4777]
trailer [4795,4797]
===
match
---
funcdef [5777,7366]
funcdef [5789,7378]
===
match
---
atom_expr [3024,3058]
atom_expr [3052,3086]
===
match
---
name: local_task_job [988,1002]
name: local_task_job [973,987]
===
match
---
name: pid [5576,5579]
name: pid [5588,5591]
===
match
---
trailer [3490,3502]
trailer [3518,3530]
===
match
---
number: 2016 [1359,1363]
number: 2016 [1387,1391]
===
match
---
expr_stmt [6778,6815]
expr_stmt [6790,6827]
===
match
---
import_name [802,816]
import_name [787,801]
===
match
---
name: scope [1929,1934]
name: scope [1957,1962]
===
match
---
operator: , [6586,6587]
operator: , [6598,6599]
===
match
---
name: attrs [7457,7462]
name: attrs [7469,7474]
===
match
---
operator: { [7340,7341]
operator: { [7352,7353]
===
match
---
atom_expr [5760,5771]
atom_expr [5772,5783]
===
match
---
name: airflow [1186,1193]
name: airflow [1214,1221]
===
match
---
simple_stmt [5589,5623]
simple_stmt [5601,5635]
===
match
---
operator: , [3892,3893]
operator: , [3912,3913]
===
match
---
parameters [3562,3568]
parameters [3590,3596]
===
match
---
operator: == [5712,5714]
operator: == [5724,5726]
===
match
---
param [5794,5798]
param [5806,5810]
===
match
---
atom_expr [5964,5979]
atom_expr [5976,5991]
===
match
---
name: session [6232,6239]
name: session [6244,6251]
===
match
---
trailer [7519,7527]
trailer [7531,7539]
===
match
---
simple_stmt [4343,4414]
simple_stmt [4363,4434]
===
match
---
operator: , [1750,1751]
operator: , [1778,1779]
===
match
---
string: "running out of memory" [5733,5756]
string: "running out of memory" [5745,5768]
===
match
---
argument [6321,6334]
argument [6333,6346]
===
match
---
suite [4507,5772]
suite [4527,5784]
===
match
---
string: """         Tests that when a child process running a task is killed externally         (e.g. by an OOM error, which we fake here), then we get return code         -9 and a log message.         """ [4516,4713]
string: """         Tests that when a child process running a task is killed externally         (e.g. by an OOM error, which we fake here), then we get return code         -9 and a log message.         """ [4536,4733]
===
match
---
atom_expr [2714,2730]
atom_expr [2742,2758]
===
match
---
atom_expr [3200,3213]
atom_expr [3228,3241]
===
match
---
name: job1 [6672,6676]
name: job1 [6684,6688]
===
match
---
name: task_instance [2754,2767]
name: task_instance [2782,2795]
===
match
---
param [4499,4505]
param [4519,4525]
===
match
---
import_from [933,969]
import_from [918,954]
===
match
---
name: run_id [6321,6327]
name: run_id [6333,6339]
===
match
---
name: pgid [4114,4118]
name: pgid [4134,4138]
===
match
---
trailer [2667,2672]
trailer [2695,2700]
===
match
---
suite [3384,3468]
suite [3412,3496]
===
match
---
atom_expr [7153,7166]
atom_expr [7165,7178]
===
match
---
atom_expr [3288,3321]
atom_expr [3316,3349]
===
match
---
operator: = [6037,6038]
operator: = [6049,6050]
===
match
---
name: create_dagrun [6294,6307]
name: create_dagrun [6306,6319]
===
match
---
name: pgid [5615,5619]
name: pgid [5627,5631]
===
match
---
trailer [4085,4093]
trailer [4105,4113]
===
match
---
argument [6348,6367]
argument [6360,6379]
===
match
---
trailer [6279,6281]
trailer [6291,6293]
===
match
---
argument [6066,6092]
argument [6078,6104]
===
match
---
expr_stmt [2795,3005]
expr_stmt [2823,3033]
===
match
---
name: pid_exists [3415,3425]
name: pid_exists [3443,3453]
===
match
---
operator: } [1857,1858]
operator: } [1885,1886]
===
match
---
dotted_name [975,1002]
dotted_name [960,987]
===
match
---
name: OSError [7615,7622]
name: OSError [7627,7634]
===
match
---
name: psutil [7306,7312]
name: psutil [7318,7324]
===
match
---
string: 'formatter' [1681,1692]
string: 'formatter' [1709,1720]
===
match
---
name: task_instance [2810,2823]
name: task_instance [2838,2851]
===
match
---
import_from [877,902]
import_from [862,887]
===
match
---
name: task_instance [2698,2711]
name: task_instance [2726,2739]
===
match
---
expr_stmt [6148,6185]
expr_stmt [6160,6197]
===
match
---
operator: , [1667,1668]
operator: , [1695,1696]
===
match
---
name: pgid [6855,6859]
name: pgid [6867,6871]
===
match
---
argument [1915,1927]
argument [1943,1955]
===
match
---
dotted_name [1186,1205]
dotted_name [1214,1233]
===
match
---
name: time [4036,4040]
name: time [4056,4060]
===
match
---
name: path [7186,7190]
name: path [7198,7202]
===
match
---
operator: } [3450,3451]
operator: } [3478,3479]
===
match
---
operator: , [4384,4385]
operator: , [4404,4405]
===
match
---
param [7410,7414]
param [7422,7426]
===
match
---
name: State [6354,6359]
name: State [6366,6371]
===
match
---
simple_stmt [2269,2275]
simple_stmt [2297,2303]
===
match
---
atom_expr [4372,4383]
atom_expr [4392,4403]
===
match
---
operator: } [5619,5620]
operator: } [5631,5632]
===
match
---
operator: , [1859,1860]
operator: , [1887,1888]
===
match
---
trailer [2697,2711]
trailer [2725,2739]
===
match
---
name: pgid [4061,4065]
name: pgid [4081,4085]
===
match
---
string: '2016-01-01' [5098,5110]
string: '2016-01-01' [5110,5122]
===
match
---
operator: , [6092,6093]
operator: , [6104,6105]
===
match
---
import_from [1181,1218]
import_from [1209,1246]
===
match
---
trailer [7010,7012]
trailer [7022,7024]
===
match
---
trailer [4955,4968]
trailer [4967,4980]
===
match
---
string: 'task1' [5077,5084]
string: 'task1' [5089,5096]
===
match
---
trailer [4900,4902]
trailer [4912,4914]
===
match
---
name: return_code [4437,4448]
name: return_code [4457,4468]
===
match
---
name: local_task_job [2646,2660]
name: local_task_job [2674,2688]
===
match
---
simple_stmt [4277,4296]
simple_stmt [4297,4316]
===
match
---
string: 'loggers' [1774,1783]
string: 'loggers' [1802,1811]
===
match
---
comparison [6831,6839]
comparison [6843,6851]
===
match
---
simple_stmt [3615,3663]
simple_stmt [3643,3691]
===
match
---
name: job1 [6550,6554]
name: job1 [6562,6566]
===
match
---
atom_expr [4766,4777]
atom_expr [4786,4797]
===
match
---
trailer [7157,7163]
trailer [7169,7175]
===
match
---
trailer [4243,4260]
trailer [4263,4280]
===
match
---
name: logging [2300,2307]
name: logging [2328,2335]
===
match
---
expr_stmt [2683,2730]
expr_stmt [2711,2758]
===
match
---
name: start [6693,6698]
name: start [6705,6710]
===
match
---
string: 'test_on_kill' [6170,6184]
string: 'test_on_kill' [6182,6196]
===
match
---
name: pid_exists [7313,7323]
name: pid_exists [7325,7335]
===
match
---
atom_expr [5550,5580]
atom_expr [5562,5592]
===
match
---
simple_stmt [4222,4268]
simple_stmt [4242,4288]
===
match
---
suite [7564,7596]
suite [7576,7608]
===
match
---
trailer [4025,4027]
trailer [4045,4047]
===
match
---
and_test [7517,7563]
and_test [7529,7575]
===
match
---
operator: > [3173,3174]
operator: > [3201,3202]
===
match
---
name: OSError [5995,6002]
name: OSError [6007,6014]
===
match
---
operator: - [5715,5716]
operator: - [5727,5728]
===
match
---
operator: = [6555,6556]
operator: = [6567,6568]
===
match
---
name: list [6951,6955]
name: list [6963,6967]
===
match
---
name: task [1082,1086]
name: task [1067,1071]
===
match
---
name: return_value [3785,3797]
name: return_value [3805,3817]
===
match
---
string: 'test_on_kill' [5049,5063]
string: 'test_on_kill' [5061,5075]
===
match
---
atom_expr [4885,4902]
atom_expr [4905,4914]
===
match
---
name: process [7341,7348]
name: process [7353,7360]
===
match
---
trailer [3599,3604]
trailer [3627,3632]
===
match
---
name: ti [6494,6496]
name: ti [6506,6508]
===
match
---
assert_stmt [3185,3266]
assert_stmt [3213,3294]
===
match
---
not_test [4350,4384]
not_test [4370,4404]
===
match
---
for_stmt [3359,3468]
for_stmt [3387,3496]
===
match
---
name: _procs_in_pgroup [7393,7409]
name: _procs_in_pgroup [7405,7421]
===
match
---
atom_expr [3090,3105]
atom_expr [3118,3133]
===
match
---
trailer [3425,3438]
trailer [3453,3466]
===
match
---
assert_stmt [5684,5717]
assert_stmt [5696,5729]
===
match
---
number: 1 [1406,1407]
number: 1 [1434,1435]
===
match
---
operator: } [1574,1575]
operator: } [1602,1603]
===
match
---
name: settings [6242,6250]
name: settings [6254,6262]
===
match
---
trailer [3433,3437]
trailer [3461,3465]
===
match
---
fstring_end: " [3466,3467]
fstring_end: " [3494,3495]
===
match
---
dictorsetmaker [1786,1858]
dictorsetmaker [1814,1886]
===
match
---
name: system [5592,5598]
name: system [5604,5610]
===
match
---
name: proc [7550,7554]
name: proc [7562,7566]
===
match
---
string: 'tasks' [2892,2899]
string: 'tasks' [2920,2927]
===
match
---
comparison [3192,3213]
comparison [3220,3241]
===
match
---
string: 'level' [1823,1830]
string: 'level' [1851,1858]
===
match
---
number: 0 [3211,3212]
number: 0 [3239,3240]
===
match
---
trailer [5591,5598]
trailer [5603,5610]
===
match
---
name: airflow_logger [2283,2297]
name: airflow_logger [2311,2325]
===
match
---
atom_expr [7528,7536]
atom_expr [7540,7548]
===
match
---
expr_stmt [3276,3321]
expr_stmt [3304,3349]
===
match
---
import_from [839,876]
import_from [824,861]
===
match
---
name: local_task_job [5189,5203]
name: local_task_job [5201,5215]
===
match
---
comparison [7217,7247]
comparison [7229,7259]
===
match
---
trailer [2839,2852]
trailer [2867,2880]
===
match
---
string: "Task should be in a different process group to us" [4161,4212]
string: "Task should be in a different process group to us" [4181,4232]
===
match
---
name: ti [6584,6586]
name: ti [6596,6598]
===
match
---
fstring_start: f" [3440,3442]
fstring_start: f" [3468,3470]
===
match
---
expr_stmt [4842,4902]
expr_stmt [4862,4914]
===
match
---
operator: , [1363,1364]
operator: , [1391,1392]
===
match
---
suite [5951,5980]
suite [5963,5992]
===
match
---
factor [5715,5717]
factor [5727,5729]
===
match
---
string: 'tasks' [3837,3844]
string: 'tasks' [3857,3864]
===
match
---
string: 'test_on_kill' [3878,3892]
string: 'test_on_kill' [3898,3912]
===
match
---
operator: = [5914,5915]
operator: = [5926,5927]
===
match
---
trailer [3784,3797]
trailer [3804,3817]
===
match
---
name: pid [7533,7536]
name: pid [7545,7548]
===
match
---
except_clause [2415,2431]
except_clause [2443,2459]
===
match
---
trailer [4283,4293]
trailer [4303,4313]
===
match
---
name: task_instance [6570,6583]
name: task_instance [6582,6595]
===
match
---
testlist_comp [2869,2995]
testlist_comp [2897,3023]
===
match
---
name: StandardTaskRunner [5170,5188]
name: StandardTaskRunner [5182,5200]
===
match
---
name: psutil [4354,4360]
name: psutil [4374,4380]
===
match
---
argument [1929,1942]
argument [1957,1970]
===
match
---
name: DEFAULT_DATE [6396,6408]
name: DEFAULT_DATE [6408,6420]
===
match
---
suite [5800,7366]
suite [5812,7378]
===
match
---
operator: , [1821,1822]
operator: , [1849,1850]
===
match
---
trailer [6165,6169]
trailer [6177,6181]
===
match
---
atom_expr [7235,7247]
atom_expr [7247,7259]
===
match
---
param [2631,2635]
param [2659,2663]
===
match
---
simple_stmt [5161,5205]
simple_stmt [5173,5217]
===
match
---
expr_stmt [3671,3731]
expr_stmt [3699,3751]
===
match
---
trailer [2718,2728]
trailer [2746,2756]
===
match
---
name: process [5568,5575]
name: process [5580,5587]
===
match
---
simple_stmt [3331,3350]
simple_stmt [3359,3378]
===
match
---
string: 'handlers' [1798,1808]
string: 'handlers' [1826,1836]
===
match
---
operator: = [1282,1283]
operator: = [1310,1311]
===
match
---
operator: } [4396,4397]
operator: } [4416,4417]
===
match
---
name: self [4493,4497]
name: self [4513,4517]
===
match
---
name: logging [809,816]
name: logging [794,801]
===
match
---
funcdef [7389,7645]
funcdef [7401,7657]
===
match
---
trailer [7331,7335]
trailer [7343,7347]
===
match
---
atom_expr [4239,4266]
atom_expr [4259,4286]
===
match
---
trailer [1349,1358]
trailer [1377,1386]
===
match
---
name: airflow [975,982]
name: airflow [960,967]
===
match
---
atom_expr [3293,3320]
atom_expr [3321,3348]
===
match
---
trailer [3139,3147]
trailer [3167,3175]
===
match
---
operator: , [6367,6368]
operator: , [6379,6380]
===
match
---
trailer [6625,6632]
trailer [6637,6644]
===
match
---
atom_expr [3740,3797]
atom_expr [3760,3817]
===
match
---
name: datetime [1350,1358]
name: datetime [1378,1386]
===
match
---
name: self [3563,3567]
name: self [3591,3595]
===
match
---
operator: , [1708,1709]
operator: , [1736,1737]
===
match
---
operator: , [1366,1367]
operator: , [1394,1395]
===
match
---
trailer [7245,7247]
trailer [7257,7259]
===
match
---
name: clear_db_runs [1251,1264]
name: clear_db_runs [1279,1292]
===
match
---
trailer [6802,6810]
trailer [6814,6822]
===
match
---
name: start [4020,4025]
name: start [4040,4045]
===
match
---
trailer [4925,4939]
trailer [4937,4951]
===
match
---
operator: = [6466,6467]
operator: = [6478,6479]
===
match
---
for_stmt [7257,7366]
for_stmt [7269,7378]
===
match
---
name: caplog [4499,4505]
name: caplog [4519,4525]
===
match
---
name: dictConfig [2234,2244]
name: dictConfig [2262,2272]
===
match
---
name: path [7112,7116]
name: path [7124,7128]
===
match
---
simple_stmt [3115,3153]
simple_stmt [3143,3181]
===
match
---
trailer [6052,6139]
trailer [6064,6151]
===
match
---
string: 'disable_existing_loggers' [1413,1439]
string: 'disable_existing_loggers' [1441,1467]
===
match
---
name: process [4389,4396]
name: process [4409,4416]
===
match
---
string: 'airflow' [4985,4994]
string: 'airflow' [4997,5006]
===
match
---
trailer [7456,7479]
trailer [7468,7491]
===
match
---
trailer [3073,3079]
trailer [3101,3107]
===
match
---
operator: = [1387,1388]
operator: = [1415,1416]
===
match
---
number: 1 [1368,1369]
number: 1 [1396,1397]
===
match
---
name: f [7195,7196]
name: f [7207,7208]
===
match
---
atom_expr [4911,4968]
atom_expr [4923,4980]
===
match
---
operator: , [3823,3824]
operator: , [3843,3844]
===
match
---
argument [6570,6586]
argument [6582,6598]
===
match
---
name: return_code [5698,5709]
name: return_code [5710,5721]
===
match
---
operator: = [1922,1923]
operator: = [1950,1951]
===
match
---
trailer [6692,6698]
trailer [6704,6710]
===
match
---
atom_expr [1284,1324]
atom_expr [1312,1352]
===
match
---
expr_stmt [4786,4833]
expr_stmt [4806,4853]
===
match
---
number: 0.5 [3101,3104]
number: 0.5 [3129,3132]
===
match
---
assert_stmt [4343,4413]
assert_stmt [4363,4433]
===
match
---
name: process [3443,3450]
name: process [3471,3478]
===
match
---
operator: { [1389,1390]
operator: { [1417,1418]
===
match
---
simple_stmt [3090,3106]
simple_stmt [3118,3134]
===
match
---
name: fixture [1907,1914]
name: fixture [1935,1942]
===
match
---
expr_stmt [1326,1370]
expr_stmt [1354,1398]
===
match
---
name: self [4239,4243]
name: self [4259,4263]
===
match
---
suite [2637,3517]
suite [2665,3545]
===
match
---
name: dagbag [6154,6160]
name: dagbag [6166,6172]
===
match
---
name: runner [3133,3139]
name: runner [3161,3167]
===
match
---
for_stmt [7062,7167]
for_stmt [7074,7179]
===
match
---
atom_expr [3122,3152]
atom_expr [3150,3180]
===
match
---
trailer [2244,2260]
trailer [2272,2288]
===
match
---
operator: , [6876,6877]
operator: , [6888,6889]
===
match
---
atom [1492,1575]
atom [1520,1603]
===
match
---
name: pid [7332,7335]
name: pid [7344,7347]
===
match
---
atom_expr [6785,6815]
atom_expr [6797,6827]
===
match
---
trailer [6810,6814]
trailer [6822,6826]
===
match
---
atom_expr [6994,7012]
atom_expr [7006,7024]
===
match
---
operator: = [2298,2299]
operator: = [2326,2327]
===
match
---
string: '2016-01-01' [2982,2994]
string: '2016-01-01' [3010,3022]
===
match
---
atom_expr [3133,3151]
atom_expr [3161,3179]
===
match
---
name: start [3074,3079]
name: start [3102,3107]
===
match
---
trailer [5697,5709]
trailer [5709,5721]
===
match
---
trailer [2404,2406]
trailer [2432,2434]
===
match
---
expr_stmt [2337,2365]
expr_stmt [2365,2393]
===
match
---
name: task_instance [4857,4870]
name: task_instance [4877,4890]
===
insert-tree
---
simple_stmt [1166,1209]
    import_from [1166,1208]
        dotted_name [1171,1193]
            name: airflow [1171,1178]
            name: utils [1179,1184]
            name: platform [1185,1193]
        name: getuser [1201,1208]
to
file_input [787,7645]
at 13
===
move-tree
---
name: getuser [3722,3729]
to
atom_expr [3714,3731]
at 0
===
move-tree
---
name: getuser [4893,4900]
to
atom_expr [4885,4902]
at 0
===
delete-tree
---
simple_stmt [787,802]
    import_name [787,801]
        name: getpass [794,801]
===
delete-node
---
name: getpass [3714,3721]
===
===
delete-node
---
trailer [3721,3729]
===
===
delete-node
---
name: getpass [4885,4892]
===
===
delete-node
---
trailer [4892,4900]
===
