===
match
---
simple_stmt [5679,5728]
simple_stmt [5699,5748]
===
match
---
name: value [2518,2523]
name: value [2538,2543]
===
match
---
if_stmt [5736,5804]
if_stmt [5756,5824]
===
match
---
testlist_comp [10128,10171]
testlist_comp [10148,10191]
===
match
---
sync_comp_for [5770,5802]
sync_comp_for [5790,5822]
===
match
---
atom_expr [11029,11099]
atom_expr [11049,11119]
===
match
---
name: value [2392,2397]
name: value [2412,2417]
===
match
---
name: show [13201,13205]
name: show [13221,13225]
===
match
---
name: debug [12439,12444]
name: debug [12459,12464]
===
match
---
suite [10284,10394]
suite [10304,10414]
===
match
---
arith_expr [3351,3389]
arith_expr [3371,3409]
===
match
---
string: "--version" [8637,8648]
string: "--version" [8657,8668]
===
match
---
simple_stmt [12709,12721]
simple_stmt [12729,12741]
===
match
---
operator: = [11407,11408]
operator: = [11427,11428]
===
match
---
suite [4281,4324]
suite [4301,4344]
===
match
---
string: """Raises when error happens in FileIo.io integration""" [11727,11783]
string: """Raises when error happens in FileIo.io integration""" [11747,11803]
===
match
---
name: Architecture [5017,5029]
name: Architecture [5037,5049]
===
match
---
name: url_parts [2893,2902]
name: url_parts [2913,2922]
===
match
---
trailer [4704,4711]
trailer [4724,4731]
===
match
---
parameters [2488,2501]
parameters [2508,2521]
===
match
---
trailer [9611,9615]
trailer [9631,9635]
===
match
---
name: os [9634,9636]
name: os [9654,9656]
===
match
---
trailer [5708,5714]
trailer [5728,5734]
===
match
---
operator: , [2811,2812]
operator: , [2831,2832]
===
match
---
suite [3584,3615]
suite [3604,3635]
===
match
---
name: __name__ [1344,1352]
name: __name__ [1372,1380]
===
match
---
parameters [5285,5303]
parameters [5305,5323]
===
match
---
name: git_version [9223,9234]
name: git_version [9243,9254]
===
match
---
simple_stmt [9817,9883]
simple_stmt [9837,9903]
===
match
---
string: "table" [10886,10893]
string: "table" [10906,10913]
===
match
---
name: userinfo [2961,2969]
name: userinfo [2981,2989]
===
match
---
testlist_star_expr [2991,3012]
testlist_star_expr [3011,3032]
===
match
---
trailer [4580,4584]
trailer [4600,4604]
===
match
---
operator: , [6942,6943]
operator: , [6962,6963]
===
match
---
argument [11906,11961]
argument [11926,11981]
===
match
---
atom [10024,10054]
atom [10044,10074]
===
match
---
operator: , [7622,7623]
operator: , [7642,7643]
===
match
---
atom_expr [8388,8398]
atom_expr [8408,8418]
===
match
---
atom_expr [13124,13177]
atom_expr [13144,13197]
===
match
---
expr_stmt [12169,12232]
expr_stmt [12189,12252]
===
match
---
expr_stmt [8993,9050]
expr_stmt [9013,9070]
===
match
---
name: value [2418,2423]
name: value [2438,2443]
===
match
---
name: console [11641,11648]
name: console [11661,11668]
===
match
---
expr_stmt [2699,2714]
expr_stmt [2719,2734]
===
match
---
atom_expr [2766,2782]
atom_expr [2786,2802]
===
match
---
trailer [9940,9962]
trailer [9960,9982]
===
match
---
atom_expr [7593,7621]
atom_expr [7613,7641]
===
match
---
operator: = [11092,11093]
operator: = [11112,11113]
===
match
---
name: cmd [5514,5517]
name: cmd [5534,5537]
===
match
---
atom_expr [11812,11842]
atom_expr [11832,11862]
===
match
---
name: grep [8873,8877]
name: grep [8893,8897]
===
match
---
name: userinfo [2671,2679]
name: userinfo [2691,2699]
===
match
---
string: "armv6l" [5070,5078]
string: "armv6l" [5090,5098]
===
match
---
string: "mysql" [9424,9431]
string: "mysql" [9444,9451]
===
match
---
param [10408,10413]
param [10428,10433]
===
match
---
suite [5304,5342]
suite [5324,5362]
===
match
---
simple_stmt [2019,2048]
simple_stmt [2047,2068]
===
match
---
return_stmt [2537,2549]
return_stmt [2557,2569]
===
match
---
trailer [6649,6654]
trailer [6669,6674]
===
match
---
name: conf [6761,6765]
name: conf [6781,6785]
===
match
---
atom [7778,7814]
atom [7798,7834]
===
match
---
name: str [10206,10209]
name: str [10226,10229]
===
match
---
trailer [4593,4601]
trailer [4613,4621]
===
match
---
operator: = [3834,3835]
operator: = [3854,3855]
===
match
---
operator: , [2808,2809]
operator: , [2828,2829]
===
match
---
suite [3508,3562]
suite [3528,3582]
===
match
---
simple_stmt [6988,7132]
simple_stmt [7008,7152]
===
match
---
name: configuration [7364,7377]
name: configuration [7384,7397]
===
match
---
trailer [12714,12720]
trailer [12734,12740]
===
match
---
name: dict [11361,11365]
name: dict [11381,11385]
===
match
---
trailer [8615,8628]
trailer [8635,8648]
===
match
---
simple_stmt [3442,3473]
simple_stmt [3462,3493]
===
match
---
expr_stmt [7297,7459]
expr_stmt [7317,7479]
===
match
---
atom_expr [4140,4161]
atom_expr [4160,4181]
===
match
---
arglist [11879,11899]
arglist [11899,11919]
===
match
---
trailer [10383,10390]
trailer [10403,10410]
===
match
---
name: value [1443,1448]
name: value [1471,1476]
===
match
---
simple_stmt [12848,12909]
simple_stmt [12868,12929]
===
match
---
simple_stmt [8188,8236]
simple_stmt [8208,8256]
===
match
---
string: "psql" [9504,9510]
string: "psql" [9524,9530]
===
match
---
param [1739,1744]
param [1767,1772]
===
match
---
import_as_name [1292,1318]
import_as_name [1320,1346]
===
match
---
operator: = [2287,2288]
operator: = [2307,2308]
===
match
---
name: configuration [7047,7060]
name: configuration [7067,7080]
===
match
---
parameters [1600,1613]
parameters [1628,1641]
===
match
---
trailer [3687,3768]
trailer [3707,3788]
===
match
---
name: p [10335,10336]
name: p [10355,10356]
===
match
---
atom_expr [9698,9730]
atom_expr [9718,9750]
===
match
---
operator: , [10141,10142]
operator: , [10161,10162]
===
match
---
operator: = [8931,8932]
operator: = [8951,8952]
===
match
---
trailer [1989,1994]
trailer [2017,2022]
===
match
---
name: python_location [8117,8132]
name: python_location [8137,8152]
===
match
---
operator: { [10552,10553]
operator: { [10572,10573]
===
match
---
atom_expr [12785,12792]
atom_expr [12805,12812]
===
match
---
operator: = [8830,8831]
operator: = [8850,8851]
===
match
---
trailer [7020,7033]
trailer [7040,7053]
===
match
---
trailer [3698,3705]
trailer [3718,3725]
===
match
---
name: FileIoException [12748,12763]
name: FileIoException [12768,12783]
===
match
---
operator: = [6952,6953]
operator: = [6972,6973]
===
match
---
name: print_as [11124,11132]
name: print_as [11144,11152]
===
match
---
return_stmt [4213,4242]
return_stmt [4233,4262]
===
match
---
simple_stmt [4402,4420]
simple_stmt [4422,4440]
===
match
---
decorated [3915,4344]
decorated [3935,4364]
===
match
---
arglist [8850,8897]
arglist [8870,8917]
===
match
---
atom [8691,8704]
atom [8711,8724]
===
match
---
if_stmt [2617,3661]
if_stmt [2637,3681]
===
match
---
operator: = [5762,5763]
operator: = [5782,5783]
===
match
---
expr_stmt [5679,5727]
expr_stmt [5699,5747]
===
match
---
expr_stmt [1320,1353]
expr_stmt [1348,1381]
===
match
---
simple_stmt [11658,11687]
simple_stmt [11678,11707]
===
match
---
arglist [9941,9961]
arglist [9961,9981]
===
match
---
trailer [11550,11563]
trailer [11570,11583]
===
match
---
parameters [2362,2375]
parameters [2382,2395]
===
match
---
comparison [4096,4119]
comparison [4116,4139]
===
match
---
name: path [9916,9920]
name: path [9936,9940]
===
match
---
name: get_fullname [6025,6037]
name: get_fullname [6045,6057]
===
match
---
expr_stmt [9817,9882]
expr_stmt [9837,9902]
===
match
---
operator: = [2028,2029]
operator: = [2056,2057]
===
match
---
operator: = [3090,3091]
operator: = [3110,3111]
===
match
---
trailer [12680,12700]
trailer [12700,12720]
===
match
---
operator: @ [6578,6579]
operator: @ [6598,6599]
===
match
---
name: console [11577,11584]
name: console [11597,11604]
===
match
---
simple_stmt [12261,12280]
simple_stmt [12281,12300]
===
match
---
operator: = [8003,8004]
operator: = [8023,8024]
===
match
---
name: staticmethod [5348,5360]
name: staticmethod [5368,5380]
===
match
---
import_from [1208,1263]
import_from [1193,1248]
===
match
---
name: ARM [5155,5158]
name: ARM [5175,5178]
===
match
---
name: Architecture [4657,4669]
name: Architecture [4677,4689]
===
match
---
name: FileIoException [12462,12477]
name: FileIoException [12482,12497]
===
match
---
operator: = [10550,10551]
operator: = [10570,10571]
===
match
---
name: property [9543,9551]
name: property [9563,9571]
===
match
---
name: Architecture [4692,4704]
name: Architecture [4712,4724]
===
match
---
atom_expr [10335,10344]
atom_expr [10355,10364]
===
match
---
name: self [1601,1605]
name: self [1629,1633]
===
match
---
suite [12426,12523]
suite [12446,12543]
===
match
---
simple_stmt [1320,1354]
simple_stmt [1348,1382]
===
match
---
trailer [7033,7131]
trailer [7053,7151]
===
match
---
decorated [10244,10394]
decorated [10264,10414]
===
match
---
name: logging [1326,1333]
name: logging [1354,1361]
===
match
---
name: f [5687,5688]
name: f [5707,5708]
===
match
---
atom_expr [11853,11900]
atom_expr [11873,11920]
===
match
---
name: X86_64 [4741,4747]
name: X86_64 [4761,4767]
===
match
---
parameters [6037,6040]
parameters [6057,6060]
===
match
---
trailer [7377,7382]
trailer [7397,7402]
===
match
---
string: """Shows information about Airflow instance""" [10486,10532]
string: """Shows information about Airflow instance""" [10506,10552]
===
match
---
name: process_path [1424,1436]
name: process_path [1452,1464]
===
match
---
name: proc [5490,5494]
name: proc [5510,5514]
===
match
---
or_test [6101,6153]
or_test [6121,6173]
===
match
---
parameters [8581,8587]
parameters [8601,8607]
===
match
---
atom_expr [13043,13059]
atom_expr [13063,13079]
===
match
---
simple_stmt [8815,8899]
simple_stmt [8835,8919]
===
match
---
name: link [12626,12630]
name: link [12646,12650]
===
match
---
param [2148,2153]
param [2168,2173]
===
match
---
argument [7096,7120]
argument [7116,7140]
===
match
---
atom_expr [6450,6474]
atom_expr [6470,6494]
===
match
---
string: "gcloud" [9326,9334]
string: "gcloud" [9346,9354]
===
match
---
operator: { [4642,4643]
operator: { [4662,4663]
===
match
---
funcdef [1499,1580]
funcdef [1527,1608]
===
match
---
string: "i686-64" [4717,4726]
string: "i686-64" [4737,4746]
===
match
---
name: self [11450,11454]
name: self [11470,11474]
===
match
---
decorator [11786,12067]
decorator [11806,12087]
===
match
---
parameters [6609,6615]
parameters [6629,6635]
===
match
---
operator: , [10113,10114]
operator: , [10133,10134]
===
match
---
name: value [2154,2159]
name: value [2174,2179]
===
match
---
name: _upload_text_to_fileio [12071,12093]
name: _upload_text_to_fileio [12091,12113]
===
match
---
name: console [11633,11640]
name: console [11653,11660]
===
match
---
classdef [4346,4613]
classdef [4366,4633]
===
match
---
trailer [5092,5096]
trailer [5112,5116]
===
match
---
string: "@" [3551,3554]
string: "@" [3571,3574]
===
match
---
return_stmt [12372,12398]
return_stmt [12392,12418]
===
match
---
expr_stmt [8659,8705]
expr_stmt [8679,8725]
===
match
---
operator: , [8517,8518]
operator: , [8537,8538]
===
match
---
atom_expr [11577,11594]
atom_expr [11597,11614]
===
match
---
trailer [11612,11617]
trailer [11632,11637]
===
match
---
trailer [7326,7337]
trailer [7346,7357]
===
match
---
trailer [12383,12388]
trailer [12403,12408]
===
match
---
name: home_path [1975,1984]
name: home_path [2003,2012]
===
match
---
string: "text" [12215,12221]
string: "text" [12235,12241]
===
match
---
suite [7932,8547]
suite [7952,8567]
===
match
---
arglist [8225,8234]
arglist [8245,8254]
===
match
---
string: "Failed to send report to file.io service." [12478,12521]
string: "Failed to send report to file.io service." [12498,12541]
===
match
---
name: self [8135,8139]
name: self [8155,8159]
===
match
---
name: username [3138,3146]
name: username [3158,3166]
===
match
---
trailer [12438,12444]
trailer [12458,12464]
===
match
---
operator: , [10054,10055]
operator: , [10074,10075]
===
match
---
operator: { [11060,11061]
operator: { [11080,11081]
===
match
---
param [2154,2159]
param [2174,2179]
===
match
---
name: CYGWIN [3892,3898]
name: CYGWIN [3912,3918]
===
match
---
name: output [11188,11194]
name: output [11208,11214]
===
match
---
atom_expr [12729,12736]
atom_expr [12749,12756]
===
match
---
trailer [8628,8650]
trailer [8648,8670]
===
match
---
param [8582,8586]
param [8602,8606]
===
match
---
operator: , [9221,9222]
operator: , [9241,9242]
===
match
---
suite [2970,3039]
suite [2990,3059]
===
match
---
operator: + [3460,3461]
operator: + [3480,3481]
===
match
---
operator: + [3538,3539]
operator: + [3558,3559]
===
match
---
comparison [5815,5829]
comparison [5835,5849]
===
match
---
string: "Uploading report to file.io service." [12569,12607]
string: "Uploading report to file.io service." [12589,12627]
===
match
---
atom_expr [12462,12522]
atom_expr [12482,12542]
===
match
---
suite [10477,11429]
suite [10497,11449]
===
match
---
name: fallback [7253,7261]
name: fallback [7273,7281]
===
match
---
string: "cloud_sql_proxy" [9366,9383]
string: "cloud_sql_proxy" [9386,9403]
===
match
---
simple_stmt [3892,3910]
simple_stmt [3912,3930]
===
match
---
suite [4200,4243]
suite [4220,4263]
===
match
---
simple_stmt [1208,1264]
simple_stmt [1193,1249]
===
match
---
suite [2161,2337]
suite [2181,2357]
===
match
---
trailer [13082,13094]
trailer [13102,13114]
===
match
---
name: X86_64 [4402,4408]
name: X86_64 [4422,4428]
===
match
---
decorator [12796,12823]
decorator [12816,12843]
===
match
---
operator: , [11148,11149]
operator: , [11168,11169]
===
match
---
string: "kubectl" [9284,9293]
string: "kubectl" [9304,9313]
===
match
---
string: "version" [7491,7500]
string: "version" [7511,7520]
===
match
---
fstring [11043,11081]
fstring [11063,11101]
===
match
---
arith_expr [6271,6306]
arith_expr [6291,6326]
===
match
---
operator: , [5646,5647]
operator: , [5666,5667]
===
match
---
operator: , [8229,8230]
operator: , [8249,8250]
===
match
---
name: process_path [8151,8163]
name: process_path [8171,8183]
===
match
---
param [2369,2374]
param [2389,2394]
===
match
---
name: value [2203,2208]
name: value [2223,2228]
===
match
---
atom [10885,10903]
atom [10905,10923]
===
match
---
operator: , [10082,10083]
operator: , [10102,10103]
===
match
---
name: log [12435,12438]
name: log [12455,12458]
===
match
---
decorated [8552,9537]
decorated [8572,9557]
===
match
---
expr_stmt [8597,8650]
expr_stmt [8617,8670]
===
match
---
param [10427,10467]
param [10447,10487]
===
match
---
operator: = [3147,3148]
operator: = [3167,3168]
===
match
---
operator: -> [1533,1535]
operator: -> [1561,1563]
===
match
---
name: self [2148,2152]
name: self [2168,2172]
===
match
---
name: self [2236,2240]
name: self [2256,2260]
===
match
---
trailer [9860,9863]
trailer [9880,9883]
===
match
---
decorated [12796,13219]
decorated [12816,13239]
===
match
---
name: k [11374,11375]
name: k [11394,11395]
===
match
---
name: print [12779,12784]
name: print [12799,12804]
===
match
---
string: b"Google Cloud SDK" [8878,8897]
string: b"Google Cloud SDK" [8898,8917]
===
match
---
expr_stmt [1773,1830]
expr_stmt [1801,1858]
===
match
---
if_stmt [10872,11429]
if_stmt [10892,11449]
===
match
---
string: "ssh" [8692,8697]
string: "ssh" [8712,8717]
===
match
---
return_stmt [4133,4161]
return_stmt [4153,4181]
===
match
---
name: sys [9873,9876]
name: sys [9893,9896]
===
match
---
simple_stmt [2281,2316]
simple_stmt [2301,2336]
===
match
---
operator: @ [5347,5348]
operator: @ [5367,5368]
===
match
---
atom_expr [8135,8179]
atom_expr [8155,8199]
===
match
---
name: grep [5398,5402]
name: grep [5418,5422]
===
match
---
name: output [11618,11624]
name: output [11638,11644]
===
match
---
atom [8413,8437]
atom [8433,8457]
===
match
---
operator: } [10798,10799]
operator: } [10818,10819]
===
match
---
string: "value" [11150,11157]
string: "value" [11170,11177]
===
match
---
operator: , [10425,10426]
operator: , [10445,10446]
===
match
---
testlist_comp [9216,9234]
testlist_comp [9236,9254]
===
match
---
string: "..." [2450,2455]
string: "..." [2470,2475]
===
match
---
trailer [9876,9881]
trailer [9896,9901]
===
match
---
operator: = [3532,3533]
operator: = [3552,3553]
===
match
---
file_input [785,13219]
file_input [785,13239]
===
match
---
name: mysql_version [8993,9006]
name: mysql_version [9013,9026]
===
match
---
operator: , [9383,9384]
operator: , [9403,9404]
===
match
---
name: version [10337,10344]
name: version [10357,10364]
===
match
---
arglist [11350,11358]
arglist [11370,11378]
===
match
---
return_stmt [9194,9536]
return_stmt [9214,9556]
===
match
---
simple_stmt [5976,6012]
simple_stmt [5996,6032]
===
match
---
return_stmt [7469,7889]
return_stmt [7489,7909]
===
match
---
expr_stmt [4615,5193]
expr_stmt [4635,5213]
===
match
---
string: "Providers info" [10750,10766]
string: "Providers info" [10770,10786]
===
match
---
operator: , [1737,1738]
operator: , [1765,1766]
===
match
---
string: "NOT AVAILABLE" [6807,6822]
string: "NOT AVAILABLE" [6827,6842]
===
match
---
trailer [10588,10602]
trailer [10608,10622]
===
match
---
if_stmt [2922,3101]
if_stmt [2942,3121]
===
match
---
trailer [10772,10788]
trailer [10792,10808]
===
match
---
suite [5592,5628]
suite [5612,5648]
===
match
---
atom_expr [8832,8898]
atom_expr [8852,8918]
===
match
---
simple_stmt [2196,2209]
simple_stmt [2216,2229]
===
match
---
testlist_comp [9028,9048]
testlist_comp [9048,9068]
===
match
---
argument [11551,11562]
argument [11571,11582]
===
match
---
name: python_path [10159,10170]
name: python_path [10179,10190]
===
match
---
trailer [6721,6733]
trailer [6741,6753]
===
match
---
atom_expr [7047,7121]
atom_expr [7067,7141]
===
match
---
name: self [2489,2493]
name: self [2509,2513]
===
match
---
name: airflow_home [10041,10053]
name: airflow_home [10061,10073]
===
match
---
atom_expr [4986,5002]
atom_expr [5006,5022]
===
match
---
name: Architecture [5174,5186]
name: Architecture [5194,5206]
===
match
---
name: List [5387,5391]
name: List [5407,5411]
===
match
---
testlist_comp [7779,7813]
testlist_comp [7799,7833]
===
match
---
trailer [4832,4836]
trailer [4852,4856]
===
match
---
atom [9503,9525]
atom [9523,9545]
===
match
---
if_stmt [5812,5916]
if_stmt [5832,5936]
===
match
---
name: _ [2810,2811]
name: _ [2830,2831]
===
match
---
trailer [12388,12390]
trailer [12408,12410]
===
match
---
operator: = [1985,1986]
operator: = [2013,2014]
===
match
---
trailer [2045,2047]
trailer [2065,2067]
===
match
---
operator: , [7232,7233]
operator: , [7252,7253]
===
match
---
name: anonymizer [7010,7020]
name: anonymizer [7030,7040]
===
match
---
expr_stmt [9059,9120]
expr_stmt [9079,9140]
===
match
---
name: MACOSX [3870,3876]
name: MACOSX [3890,3896]
===
match
---
operator: , [9035,9036]
operator: , [9055,9056]
===
match
---
suite [2502,3769]
suite [2522,3789]
===
match
---
name: args [13164,13168]
name: args [13184,13188]
===
match
---
atom [7730,7764]
atom [7750,7784]
===
match
---
name: record [11551,11557]
name: record [11571,11577]
===
match
---
simple_stmt [12108,12165]
simple_stmt [12128,12185]
===
match
---
operator: , [8787,8788]
operator: , [8807,8808]
===
match
---
argument [5543,5567]
argument [5563,5587]
===
match
---
simple_stmt [4440,4452]
simple_stmt [4460,4472]
===
match
---
name: sys [906,909]
name: sys [891,894]
===
match
---
name: userinfo [2925,2933]
name: userinfo [2945,2953]
===
match
---
param [1601,1606]
param [1629,1634]
===
match
---
suite [4120,4162]
suite [4140,4182]
===
match
---
name: anonymizer [9674,9684]
name: anonymizer [9694,9704]
===
match
---
name: host [3320,3324]
name: host [3340,3344]
===
match
---
name: _airflow_info [10589,10602]
name: _airflow_info [10609,10622]
===
match
---
expr_stmt [5490,5568]
expr_stmt [5510,5588]
===
match
---
name: os [1987,1989]
name: os [2015,2017]
===
match
---
operator: = [12024,12025]
operator: = [12044,12045]
===
match
---
trailer [12043,12063]
trailer [12063,12083]
===
match
---
trailer [2629,2636]
trailer [2649,2656]
===
match
---
trailer [8106,8108]
trailer [8126,8128]
===
match
---
atom [8951,8983]
atom [8971,9003]
===
match
---
suite [2934,3101]
suite [2954,3121]
===
match
---
name: os [9928,9930]
name: os [9948,9950]
===
match
---
trailer [5123,5127]
trailer [5143,5147]
===
match
---
testlist_comp [5687,5726]
testlist_comp [5707,5746]
===
match
---
operator: , [933,934]
operator: , [918,919]
===
match
---
name: sqlite3_version [9059,9074]
name: sqlite3_version [9079,9094]
===
match
---
name: Architecture [4820,4832]
name: Architecture [4840,4852]
===
match
---
simple_stmt [6171,6230]
simple_stmt [6191,6250]
===
match
---
atom [8266,8309]
atom [8286,8329]
===
match
---
operator: , [11167,11168]
operator: , [11187,11188]
===
match
---
name: _send_report_to_fileio [13124,13146]
name: _send_report_to_fileio [13144,13166]
===
match
---
string: "-V" [8699,8703]
string: "-V" [8719,8723]
===
match
---
operator: = [9907,9908]
operator: = [9927,9928]
===
match
---
name: _path_replacements [2241,2259]
name: _path_replacements [2261,2279]
===
match
---
name: self [9572,9576]
name: self [9592,9596]
===
match
---
name: uname [8040,8045]
name: uname [8060,8065]
===
match
---
testlist_comp [8692,8703]
testlist_comp [8712,8723]
===
match
---
name: self [1520,1524]
name: self [1548,1552]
===
match
---
if_stmt [2385,2424]
if_stmt [2405,2444]
===
match
---
trailer [9697,9731]
trailer [9717,9751]
===
match
---
operator: = [2736,2737]
operator: = [2756,2757]
===
match
---
name: List [929,933]
name: List [914,918]
===
match
---
atom_expr [4820,4836]
atom_expr [4840,4856]
===
match
---
dotted_name [1170,1191]
dotted_name [1155,1176]
===
match
---
atom_expr [9755,9786]
atom_expr [9775,9806]
===
match
---
trailer [12444,12447]
trailer [12464,12467]
===
match
---
operator: , [10602,10603]
operator: , [10622,10623]
===
match
---
name: args [12837,12841]
name: args [12857,12861]
===
match
---
decorated [9542,10239]
decorated [9562,10259]
===
match
---
simple_stmt [13196,13219]
simple_stmt [13216,13239]
===
match
---
trailer [2836,2846]
trailer [2856,2866]
===
match
---
operator: = [8046,8047]
operator: = [8066,8067]
===
match
---
operator: , [9489,9490]
operator: , [9509,9510]
===
match
---
import_as_names [969,989]
import_as_names [954,974]
===
match
---
operator: , [9293,9294]
operator: , [9313,9314]
===
match
---
or_test [10819,10863]
or_test [10839,10883]
===
match
---
name: resp [12379,12383]
name: resp [12399,12403]
===
match
---
name: cloud_sql_proxy_version [9385,9408]
name: cloud_sql_proxy_version [9405,9428]
===
match
---
trailer [12390,12398]
trailer [12410,12418]
===
match
---
argument [8873,8897]
argument [8893,8917]
===
match
---
operator: , [12063,12064]
operator: , [12083,12084]
===
match
---
name: join [9936,9940]
name: join [9956,9960]
===
match
---
string: """Upload text file to File.io service and return lnk""" [12108,12164]
string: """Upload text file to File.io service and return lnk""" [12128,12184]
===
match
---
trailer [2265,2267]
trailer [2285,2287]
===
match
---
argument [11967,12013]
argument [11987,12033]
===
match
---
trailer [8937,8950]
trailer [8957,8970]
===
match
---
parameters [5964,5966]
parameters [5984,5986]
===
match
---
trailer [12056,12062]
trailer [12076,12082]
===
match
---
return_stmt [6443,6474]
return_stmt [6463,6494]
===
match
---
trailer [11584,11592]
trailer [11604,11612]
===
match
---
string: " " [11350,11353]
string: " " [11370,11373]
===
match
---
trailer [12784,12793]
trailer [12804,12813]
===
match
---
trailer [12659,12665]
trailer [12679,12685]
===
match
---
name: name [4026,4030]
name: name [4046,4050]
===
match
---
testlist_comp [9326,9350]
testlist_comp [9346,9370]
===
match
---
trailer [6394,6404]
trailer [6414,6424]
===
match
---
trailer [6916,6920]
trailer [6936,6940]
===
match
---
suite [1691,1850]
suite [1719,1878]
===
match
---
name: console [10819,10826]
name: console [10839,10846]
===
match
---
name: airflow_on_path [9891,9906]
name: airflow_on_path [9911,9926]
===
match
---
name: multiplier [11879,11889]
name: multiplier [11899,11909]
===
match
---
name: info [13064,13068]
name: info [13084,13088]
===
match
---
name: split [5709,5714]
name: split [5729,5734]
===
match
---
name: self [7593,7597]
name: self [7613,7617]
===
match
---
trailer [13168,13175]
trailer [13188,13195]
===
match
---
operator: , [2493,2494]
operator: , [2513,2514]
===
match
---
name: ARM [5187,5190]
name: ARM [5207,5210]
===
match
---
trailer [6765,6769]
trailer [6785,6789]
===
match
---
trailer [11132,11195]
trailer [11152,11215]
===
match
---
suite [2398,2424]
suite [2418,2444]
===
match
---
trailer [5668,5670]
trailer [5688,5690]
===
match
---
name: getLogger [1334,1343]
name: getLogger [1362,1371]
===
match
---
simple_stmt [9654,9732]
simple_stmt [9674,9752]
===
match
---
parameters [3948,3950]
parameters [3968,3970]
===
match
---
testlist_comp [7731,7763]
testlist_comp [7751,7783]
===
match
---
name: capture [11585,11592]
name: capture [11605,11612]
===
match
---
comparison [2759,2782]
comparison [2779,2802]
===
match
---
name: Optional [5404,5412]
name: Optional [5424,5432]
===
match
---
string: "x86" [4813,4818]
string: "x86" [4833,4838]
===
match
---
trailer [7069,7121]
trailer [7089,7141]
===
match
---
string: """Exports the info to string""" [11485,11517]
string: """Exports the info to string""" [11505,11537]
===
match
---
return_stmt [6171,6198]
return_stmt [6191,6218]
===
match
---
name: after [12019,12024]
name: after [12039,12044]
===
match
---
expr_stmt [5313,5341]
expr_stmt [5333,5361]
===
match
---
operator: + [6278,6279]
operator: + [6298,6299]
===
match
---
atom_expr [4657,4676]
atom_expr [4677,4696]
===
match
---
name: Architecture [4761,4773]
name: Architecture [4781,4793]
===
match
---
name: _get_version [8616,8628]
name: _get_version [8636,8648]
===
match
---
for_stmt [10978,11196]
for_stmt [10998,11216]
===
match
---
name: output [13211,13217]
name: output [13231,13237]
===
match
---
name: replace [8217,8224]
name: replace [8237,8244]
===
match
---
name: python_location [8519,8534]
name: python_location [8539,8554]
===
match
---
operator: + [6284,6285]
operator: + [6304,6305]
===
match
---
dictorsetmaker [11140,11160]
dictorsetmaker [11160,11180]
===
match
---
simple_stmt [1773,1831]
simple_stmt [1801,1859]
===
match
---
name: o [6063,6064]
name: o [6083,6084]
===
match
---
string: "System info" [10616,10629]
string: "System info" [10636,10649]
===
match
---
atom_expr [11332,11359]
atom_expr [11352,11379]
===
match
---
operator: , [2224,2225]
operator: , [2244,2245]
===
match
---
operator: , [5033,5034]
operator: , [5053,5054]
===
match
---
operator: , [6796,6797]
operator: , [6816,6817]
===
match
---
operator: , [9169,9170]
operator: , [9189,9190]
===
match
---
name: info [11174,11178]
name: info [11194,11198]
===
match
---
atom_expr [13025,13037]
atom_expr [13045,13057]
===
match
---
atom_expr [9077,9120]
atom_expr [9097,9140]
===
match
---
funcdef [10399,11429]
funcdef [10419,11449]
===
match
---
name: str [11472,11475]
name: str [11492,11495]
===
match
---
name: output [13169,13175]
name: output [13189,13195]
===
match
---
testlist_comp [10886,10902]
testlist_comp [10906,10922]
===
match
---
operator: } [12230,12231]
operator: } [12250,12251]
===
match
---
param [5292,5302]
param [5312,5322]
===
match
---
suite [1383,1656]
suite [1411,1684]
===
match
---
atom_expr [5497,5568]
atom_expr [5517,5588]
===
match
---
exprlist [11166,11170]
exprlist [11186,11190]
===
match
---
name: operating_system [7941,7957]
name: operating_system [7961,7977]
===
match
---
simple_stmt [13064,13095]
simple_stmt [13084,13115]
===
match
---
name: suppress_logs_and_warning [1238,1263]
name: suppress_logs_and_warning [1223,1248]
===
match
---
name: process_username [2346,2362]
name: process_username [2366,2382]
===
match
---
name: Protocol [1373,1381]
name: Protocol [1401,1409]
===
match
---
atom_expr [4791,4807]
atom_expr [4811,4827]
===
match
---
trailer [5903,5906]
trailer [5923,5926]
===
match
---
expr_stmt [9587,9645]
expr_stmt [9607,9665]
===
match
---
name: anonymizer [5318,5328]
name: anonymizer [5338,5348]
===
match
---
operator: @ [8552,8553]
operator: @ [8572,8573]
===
match
---
trailer [11009,11011]
trailer [11029,11031]
===
match
---
name: console [11526,11533]
name: console [11546,11553]
===
match
---
name: console [11116,11123]
name: console [11136,11143]
===
match
---
atom_expr [6286,6306]
atom_expr [6306,6326]
===
match
---
name: arch [8340,8344]
name: arch [8360,8364]
===
match
---
testlist_comp [5765,5802]
testlist_comp [5785,5822]
===
match
---
operator: - [2464,2465]
operator: - [2484,2485]
===
match
---
atom_expr [12988,13003]
atom_expr [13008,13023]
===
match
---
name: str [11464,11467]
name: str [11484,11487]
===
match
---
name: plugins_folder [7749,7763]
name: plugins_folder [7769,7783]
===
match
---
name: partition [3024,3033]
name: partition [3044,3053]
===
match
---
simple_stmt [3798,3821]
simple_stmt [3818,3841]
===
match
---
trailer [8216,8224]
trailer [8236,8244]
===
match
---
trailer [5714,5721]
trailer [5734,5741]
===
match
---
simple_stmt [2559,2587]
simple_stmt [2579,2607]
===
match
---
trailer [8836,8849]
trailer [8856,8869]
===
match
---
name: python_path [9817,9828]
name: python_path [9837,9848]
===
match
---
operator: , [4777,4778]
operator: , [4797,4798]
===
match
---
name: _get_version [8938,8950]
name: _get_version [8958,8970]
===
match
---
atom_expr [4220,4242]
atom_expr [4240,4262]
===
match
---
trailer [8062,8064]
trailer [8082,8084]
===
match
---
name: str [3963,3966]
name: str [3983,3986]
===
match
---
arglist [2303,2314]
arglist [2323,2334]
===
match
---
string: "x86_64" [4682,4690]
string: "x86_64" [4702,4710]
===
match
---
atom_expr [10206,10226]
atom_expr [10226,10246]
===
match
---
name: username [3294,3302]
name: username [3314,3322]
===
match
---
atom_expr [13102,13114]
atom_expr [13122,13134]
===
match
---
atom_expr [4301,4323]
atom_expr [4321,4343]
===
match
---
sync_comp_for [6372,6429]
sync_comp_for [6392,6449]
===
match
---
trailer [4862,4866]
trailer [4882,4886]
===
match
---
atom_expr [8732,8806]
atom_expr [8752,8826]
===
match
---
suite [2268,2316]
suite [2288,2336]
===
match
---
operator: = [8133,8134]
operator: = [8153,8154]
===
match
---
string: "plugins_folder" [7731,7747]
string: "plugins_folder" [7751,7767]
===
match
---
dictorsetmaker [2083,2124]
dictorsetmaker [2103,2144]
===
match
---
operator: , [10333,10334]
operator: , [10353,10354]
===
match
---
name: v [11169,11170]
name: v [11189,11190]
===
match
---
atom [9201,9536]
atom [9221,9556]
===
match
---
string: "--version" [9037,9048]
string: "--version" [9057,9068]
===
match
---
string: """Remove pii from paths""" [1466,1493]
string: """Remove pii from paths""" [1494,1521]
===
match
---
name: AirflowInfo [5202,5213]
name: AirflowInfo [5222,5233]
===
match
---
name: module [6054,6060]
name: module [6074,6080]
===
match
---
name: AirflowConsole [10445,10459]
name: AirflowConsole [10465,10479]
===
match
---
funcdef [12067,12523]
funcdef [12087,12543]
===
match
---
string: "system_path" [10069,10082]
string: "system_path" [10089,10102]
===
match
---
simple_stmt [3649,3661]
simple_stmt [3669,3681]
===
match
---
name: process_username [1788,1804]
name: process_username [1816,1832]
===
match
---
name: value [2281,2286]
name: value [2301,2306]
===
match
---
trailer [7213,7218]
trailer [7233,7238]
===
match
---
name: process_path [7174,7186]
name: process_path [7194,7206]
===
match
---
name: v [11159,11160]
name: v [11179,11180]
===
match
---
name: _providers_info [10773,10788]
name: _providers_info [10793,10808]
===
match
---
not_test [2514,2523]
not_test [2534,2543]
===
match
---
atom_expr [12244,12251]
atom_expr [12264,12271]
===
match
---
number: 5 [11840,11841]
number: 5 [11860,11861]
===
match
---
expr_stmt [13064,13094]
expr_stmt [13084,13114]
===
match
---
operator: = [6634,6635]
operator: = [6654,6655]
===
match
---
simple_stmt [3826,3846]
simple_stmt [3846,3866]
===
match
---
test [12988,13059]
test [13008,13079]
===
match
---
name: self [9009,9013]
name: self [9029,9033]
===
match
---
param [12094,12101]
param [12114,12121]
===
match
---
string: "power macintosh" [4967,4984]
string: "power macintosh" [4987,5004]
===
match
---
param [10414,10426]
param [10434,10446]
===
match
---
name: machine [4594,4601]
name: machine [4614,4621]
===
match
---
trailer [2846,2851]
trailer [2866,2871]
===
match
---
trailer [6064,6074]
trailer [6084,6094]
===
match
---
string: "\n" [8225,8229]
string: "\n" [8245,8249]
===
match
---
operator: , [8386,8387]
operator: , [8406,8407]
===
match
---
name: _ [5648,5649]
name: _ [5668,5669]
===
match
---
trailer [11307,11428]
trailer [11327,11448]
===
match
---
name: print [12563,12568]
name: print [12583,12588]
===
match
---
trailer [12568,12608]
trailer [12588,12628]
===
match
---
name: dags_folder [7704,7715]
name: dags_folder [7724,7735]
===
match
---
name: log [1320,1323]
name: log [1348,1351]
===
match
---
trailer [4609,4611]
trailer [4629,4631]
===
match
---
trailer [6710,6721]
trailer [6730,6741]
===
match
---
name: _locale [8428,8435]
name: _locale [8448,8455]
===
match
---
simple_stmt [4370,4397]
simple_stmt [4390,4417]
===
match
---
atom_expr [13071,13094]
atom_expr [13091,13114]
===
match
---
trailer [11820,11839]
trailer [11840,11859]
===
match
---
argument [12019,12063]
argument [12039,12083]
===
match
---
atom_expr [8164,8178]
atom_expr [8184,8198]
===
match
---
name: property [10245,10253]
name: property [10265,10273]
===
match
---
expr_stmt [1975,2010]
expr_stmt [2003,2038]
===
match
---
string: "_" [11355,11358]
string: "_" [11375,11378]
===
match
---
except_clause [12741,12769]
except_clause [12761,12789]
===
match
---
string: "NOT AVAILABLE" [7105,7120]
string: "NOT AVAILABLE" [7125,7140]
===
match
---
name: get [7219,7222]
name: get [7239,7242]
===
match
---
name: sys [8205,8208]
name: sys [8225,8228]
===
match
---
expr_stmt [2595,2608]
expr_stmt [2615,2628]
===
match
---
decorator [5347,5361]
decorator [5367,5381]
===
match
---
suite [12558,12794]
suite [12578,12814]
===
match
---
name: _get_version [9014,9026]
name: _get_version [9034,9046]
===
match
---
classdef [11689,11784]
classdef [11709,11804]
===
match
---
simple_stmt [5892,5916]
simple_stmt [5912,5936]
===
match
---
suite [11476,11687]
suite [11496,11707]
===
match
---
operator: , [9622,9623]
operator: , [9642,9643]
===
match
---
if_stmt [6098,6307]
if_stmt [6118,6327]
===
match
---
atom [7828,7878]
atom [7848,7898]
===
match
---
testlist_comp [8267,8308]
testlist_comp [8287,8328]
===
match
---
name: netloc [3649,3655]
name: netloc [3669,3675]
===
match
---
trailer [7382,7386]
trailer [7402,7406]
===
match
---
name: values [10384,10390]
name: values [10404,10410]
===
match
---
trailer [9684,9697]
trailer [9704,9717]
===
match
---
atom_expr [3954,3967]
atom_expr [3974,3987]
===
match
---
string: "psql" [9163,9169]
string: "psql" [9183,9189]
===
match
---
simple_stmt [1549,1580]
simple_stmt [1577,1608]
===
match
---
expr_stmt [3892,3909]
expr_stmt [3912,3929]
===
match
---
atom [11331,11369]
atom [11351,11389]
===
match
---
operator: } [11064,11065]
operator: } [11084,11085]
===
match
---
expr_stmt [12975,13059]
expr_stmt [12995,13079]
===
match
---
simple_stmt [12372,12399]
simple_stmt [12392,12419]
===
match
---
name: str [12656,12659]
name: str [12676,12679]
===
match
---
operator: = [9007,9008]
operator: = [9027,9028]
===
match
---
name: communicate [5657,5668]
name: communicate [5677,5688]
===
match
---
operator: , [7674,7675]
operator: , [7694,7695]
===
match
---
trailer [4316,4323]
trailer [4336,4343]
===
match
---
trailer [2240,2259]
trailer [2260,2279]
===
match
---
name: _identity [1723,1732]
name: _identity [1751,1760]
===
match
---
name: ARM [5124,5127]
name: ARM [5144,5147]
===
match
---
operator: = [11329,11330]
operator: = [11349,11350]
===
match
---
simple_stmt [12169,12233]
simple_stmt [12189,12253]
===
match
---
if_stmt [3291,3661]
if_stmt [3311,3681]
===
match
---
name: WINDOWS [3826,3833]
name: WINDOWS [3846,3853]
===
match
---
name: X86 [4424,4427]
name: X86 [4444,4447]
===
match
---
atom_expr [6636,6678]
atom_expr [6656,6698]
===
match
---
atom_expr [1326,1353]
atom_expr [1354,1381]
===
match
---
funcdef [1585,1656]
funcdef [1613,1684]
===
match
---
atom_expr [10631,10648]
atom_expr [10651,10668]
===
match
---
string: "arm" [4462,4467]
string: "arm" [4482,4487]
===
match
---
operator: , [9351,9352]
operator: , [9371,9372]
===
match
---
and_test [3490,3507]
and_test [3510,3527]
===
match
---
atom [7636,7674]
atom [7656,7694]
===
match
---
funcdef [9556,10239]
funcdef [9576,10259]
===
match
---
trailer [11878,11900]
trailer [11898,11920]
===
match
---
name: value [2177,2182]
name: value [2197,2202]
===
match
---
name: uname [8392,8397]
name: uname [8412,8417]
===
match
---
name: subprocess [888,898]
name: subprocess [873,883]
===
match
---
trailer [5913,5915]
trailer [5933,5935]
===
match
---
name: psql_version [9129,9141]
name: psql_version [9149,9161]
===
match
---
operator: , [11891,11892]
operator: , [11911,11912]
===
match
---
trailer [5029,5033]
trailer [5049,5053]
===
match
---
trailer [7597,7619]
trailer [7617,7639]
===
match
---
simple_stmt [4052,4083]
simple_stmt [4072,4103]
===
match
---
name: X86 [4833,4836]
name: X86 [4853,4856]
===
match
---
trailer [8749,8806]
trailer [8769,8826]
===
match
---
argument [11181,11194]
argument [11201,11214]
===
match
---
name: property [8553,8561]
name: property [8573,8581]
===
match
---
arglist [6770,6822]
arglist [6790,6842]
===
match
---
return_stmt [4052,4082]
return_stmt [4072,4102]
===
match
---
decorator [6578,6588]
decorator [6598,6608]
===
match
---
name: src [2303,2306]
name: src [2323,2326]
===
match
---
trailer [6179,6189]
trailer [6199,6209]
===
match
---
atom_expr [4268,4280]
atom_expr [4288,4300]
===
match
---
name: conf [6912,6916]
name: conf [6932,6936]
===
match
---
name: __module__ [6143,6153]
name: __module__ [6163,6173]
===
match
---
atom [11138,11179]
atom [11158,11199]
===
match
---
name: _upload_text_to_fileio [12633,12655]
name: _upload_text_to_fileio [12653,12675]
===
match
---
name: self [7158,7162]
name: self [7178,7182]
===
match
---
operator: = [9752,9753]
operator: = [9772,9773]
===
match
---
name: subprocess [5497,5507]
name: subprocess [5517,5527]
===
match
---
simple_stmt [1696,1714]
simple_stmt [1724,1742]
===
match
---
name: k [11332,11333]
name: k [11352,11353]
===
match
---
atom_expr [1987,2010]
atom_expr [2015,2038]
===
match
---
name: configuration [6747,6760]
name: configuration [6767,6780]
===
match
---
operator: , [9950,9951]
operator: , [9970,9971]
===
match
---
string: "ppc64" [5008,5015]
string: "ppc64" [5028,5035]
===
match
---
operator: = [2818,2819]
operator: = [2838,2839]
===
match
---
funcdef [2342,2468]
funcdef [2362,2488]
===
match
---
operator: = [2569,2570]
operator: = [2589,2590]
===
match
---
trailer [5906,5913]
trailer [5926,5933]
===
match
---
expr_stmt [4424,4435]
expr_stmt [4444,4455]
===
match
---
string: """Get current operating system""" [3977,4011]
string: """Get current operating system""" [3997,4031]
===
match
---
trailer [13106,13114]
trailer [13126,13134]
===
match
---
trailer [12655,12666]
trailer [12675,12686]
===
match
---
return_stmt [2432,2467]
return_stmt [2452,2487]
===
match
---
simple_stmt [2056,2126]
simple_stmt [2076,2146]
===
match
---
return_stmt [10003,10238]
return_stmt [10023,10258]
===
match
---
testlist_comp [9462,9488]
testlist_comp [9482,9508]
===
match
---
name: cloud_sql_proxy_version [8907,8930]
name: cloud_sql_proxy_version [8927,8950]
===
match
---
argument [6798,6822]
argument [6818,6842]
===
match
---
trailer [11672,11684]
trailer [11692,11704]
===
match
---
trailer [11003,11009]
trailer [11023,11029]
===
match
---
name: host [2886,2890]
name: host [2906,2910]
===
match
---
operator: = [8609,8610]
operator: = [8629,8630]
===
match
---
suite [13187,13219]
suite [13207,13239]
===
match
---
expr_stmt [8117,8179]
expr_stmt [8137,8199]
===
match
---
suite [1457,1494]
suite [1485,1522]
===
match
---
operator: = [9599,9600]
operator: = [9619,9620]
===
match
---
trailer [10145,10153]
trailer [10165,10173]
===
match
---
operator: == [6126,6128]
operator: == [6146,6148]
===
match
---
atom_expr [6178,6198]
atom_expr [6198,6218]
===
match
---
operator: , [10412,10413]
operator: , [10432,10433]
===
match
---
suite [6154,6230]
suite [6174,6250]
===
match
---
argument [11325,11399]
argument [11345,11419]
===
match
---
operator: = [11187,11188]
operator: = [11207,11208]
===
match
---
simple_stmt [4424,4436]
simple_stmt [4444,4456]
===
match
---
string: "ia64" [4842,4848]
string: "ia64" [4862,4868]
===
match
---
return_stmt [5605,5627]
return_stmt [5625,5647]
===
match
---
name: OperatingSystem [4059,4074]
name: OperatingSystem [4079,4094]
===
match
---
comparison [4256,4280]
comparison [4276,4300]
===
match
---
return_stmt [4332,4343]
return_stmt [4352,4363]
===
match
---
name: url_parts [3731,3740]
name: url_parts [3751,3760]
===
match
---
simple_stmt [1110,1165]
simple_stmt [1095,1150]
===
match
---
name: Optional [935,943]
name: Optional [920,928]
===
match
---
name: get_current [4495,4506]
name: get_current [4515,4526]
===
match
---
name: process_path [9771,9783]
name: process_path [9791,9803]
===
match
---
trailer [10209,10226]
trailer [10229,10246]
===
match
---
name: render_text [13152,13163]
name: render_text [13172,13183]
===
match
---
operator: , [7591,7592]
operator: , [7611,7612]
===
match
---
operator: , [7543,7544]
operator: , [7563,7564]
===
match
---
name: _tools_info [8570,8581]
name: _tools_info [8590,8601]
===
match
---
name: anonymize [13012,13021]
name: anonymize [13032,13041]
===
match
---
trailer [8163,8179]
trailer [8183,8199]
===
match
---
testlist_comp [9832,9881]
testlist_comp [9852,9901]
===
match
---
name: str [10422,10425]
name: str [10442,10445]
===
match
---
expr_stmt [10809,10863]
expr_stmt [10829,10883]
===
match
---
simple_stmt [1388,1415]
simple_stmt [1416,1443]
===
match
---
trailer [2829,2836]
trailer [2849,2856]
===
match
---
expr_stmt [8188,8235]
expr_stmt [8208,8255]
===
match
---
expr_stmt [5636,5670]
expr_stmt [5656,5690]
===
match
---
name: system_path [9740,9751]
name: system_path [9760,9771]
===
match
---
trailer [4110,4119]
trailer [4130,4139]
===
match
---
name: host [3503,3507]
name: host [3523,3527]
===
match
---
string: '.' [6280,6283]
string: '.' [6300,6303]
===
match
---
operator: = [6806,6807]
operator: = [6826,6827]
===
match
---
name: get [6655,6658]
name: get [6675,6678]
===
match
---
funcdef [3933,4344]
funcdef [3953,4364]
===
match
---
trailer [7162,7173]
trailer [7182,7193]
===
match
---
atom_expr [10355,10392]
atom_expr [10375,10412]
===
match
---
decorated [5921,6573]
decorated [5941,6593]
===
match
---
simple_stmt [4549,4613]
simple_stmt [4569,4633]
===
match
---
operator: = [2602,2603]
operator: = [2622,2623]
===
match
---
with_stmt [11572,11650]
with_stmt [11592,11670]
===
match
---
name: _system_info [7913,7925]
name: _system_info [7933,7945]
===
match
---
testlist_comp [11139,11178]
testlist_comp [11159,11198]
===
match
---
suite [3325,3390]
suite [3345,3410]
===
match
---
trailer [9915,9920]
trailer [9935,9940]
===
match
---
suite [4365,4613]
suite [4385,4633]
===
match
---
name: print [12675,12680]
name: print [12695,12700]
===
match
---
operator: = [8081,8082]
operator: = [8101,8102]
===
match
---
funcdef [5939,6573]
funcdef [5959,6593]
===
match
---
string: "Mac OS" [3879,3887]
string: "Mac OS" [3899,3907]
===
match
---
testlist_comp [9424,9446]
testlist_comp [9444,9466]
===
match
---
name: str [5392,5395]
name: str [5412,5415]
===
match
---
operator: , [7500,7501]
operator: , [7520,7521]
===
match
---
parameters [11449,11468]
parameters [11469,11488]
===
match
---
string: """Operating system""" [3798,3820]
string: """Operating system""" [3818,3840]
===
match
---
string: """Returns task logging handler.""" [5976,6011]
string: """Returns task logging handler.""" [5996,6031]
===
match
---
simple_stmt [12729,12737]
simple_stmt [12749,12757]
===
match
---
operator: = [3656,3657]
operator: = [3676,3677]
===
match
---
simple_stmt [855,865]
simple_stmt [840,850]
===
match
---
name: base_log_folder [7798,7813]
name: base_log_folder [7818,7833]
===
match
---
trailer [10635,10648]
trailer [10655,10668]
===
match
---
name: netloc [2595,2601]
name: netloc [2615,2621]
===
match
---
name: OperatingSystem [4301,4316]
name: OperatingSystem [4321,4336]
===
match
---
operator: = [10461,10462]
operator: = [10481,10482]
===
match
---
simple_stmt [12675,12701]
simple_stmt [12695,12721]
===
match
---
simple_stmt [2537,2550]
simple_stmt [2557,2570]
===
match
---
testlist_star_expr [5636,5649]
testlist_star_expr [5656,5669]
===
match
---
try_stmt [6316,6573]
try_stmt [6336,6593]
===
match
---
parameters [5381,5427]
parameters [5401,5447]
===
match
---
name: o [6038,6039]
name: o [6058,6059]
===
match
---
operator: , [7878,7879]
operator: , [7898,7899]
===
match
---
dotted_name [11787,11801]
dotted_name [11807,11821]
===
match
---
name: system_path [9981,9992]
name: system_path [10001,10012]
===
match
---
operator: , [2152,2153]
operator: , [2172,2173]
===
match
---
name: content [12223,12230]
name: content [12243,12250]
===
match
---
name: proc [5652,5656]
name: proc [5672,5676]
===
match
---
expr_stmt [10541,10799]
expr_stmt [10561,10819]
===
match
---
simple_stmt [1889,1942]
simple_stmt [1917,1970]
===
match
---
atom_expr [12563,12608]
atom_expr [12583,12628]
===
match
---
trailer [8017,8029]
trailer [8037,8049]
===
match
---
suite [12617,12737]
suite [12637,12757]
===
match
---
atom [2082,2125]
atom [2102,2145]
===
match
---
simple_stmt [5843,5866]
simple_stmt [5863,5886]
===
match
---
name: CYGWIN [4317,4323]
name: CYGWIN [4337,4343]
===
match
---
string: 'airflow.task' [6405,6419]
string: 'airflow.task' [6425,6439]
===
match
---
name: before_log [11983,11993]
name: before_log [12003,12013]
===
match
---
name: X86 [4804,4807]
name: X86 [4824,4827]
===
match
---
trailer [9912,9993]
trailer [9932,10013]
===
match
---
trailer [13146,13177]
trailer [13166,13197]
===
match
---
del_stmt [1836,1849]
del_stmt [1864,1877]
===
match
---
string: "armv7" [5133,5140]
string: "armv7" [5153,5160]
===
match
---
name: property [6579,6587]
name: property [6599,6607]
===
match
---
name: fallback [6944,6952]
name: fallback [6964,6972]
===
match
---
operator: , [5064,5065]
operator: , [5084,5085]
===
match
---
atom_expr [11361,11368]
atom_expr [11381,11388]
===
match
---
name: self [9077,9081]
name: self [9097,9101]
===
match
---
name: airflow_version [1303,1318]
name: airflow_version [1331,1346]
===
match
---
name: gcloud_version [9336,9350]
name: gcloud_version [9356,9370]
===
match
---
string: 'package-name' [10318,10332]
string: 'package-name' [10338,10352]
===
match
---
name: userinfo [2800,2808]
name: userinfo [2820,2828]
===
match
---
simple_stmt [10293,10394]
simple_stmt [10313,10414]
===
match
---
name: url_parts [2766,2775]
name: url_parts [2786,2795]
===
match
---
atom_expr [3715,3729]
atom_expr [3735,3749]
===
match
---
atom [11139,11161]
atom [11159,11181]
===
match
---
and_test [3294,3324]
and_test [3314,3344]
===
match
---
number: 10 [11897,11899]
number: 10 [11917,11919]
===
match
---
trailer [10153,10158]
trailer [10173,10178]
===
match
---
simple_stmt [11727,11784]
simple_stmt [11747,11804]
===
match
---
atom_expr [13206,13217]
atom_expr [13226,13237]
===
match
---
name: key [10982,10985]
name: key [11002,11005]
===
match
---
expr_stmt [3525,3561]
expr_stmt [3545,3581]
===
match
---
name: DEBUG [12007,12012]
name: DEBUG [12027,12032]
===
match
---
operator: = [12174,12175]
operator: = [12194,12195]
===
match
---
operator: , [7094,7095]
operator: , [7114,7115]
===
match
---
decorator [4473,4487]
decorator [4493,4507]
===
match
---
operator: } [5192,5193]
operator: } [5212,5213]
===
match
---
operator: @ [3915,3916]
operator: @ [3935,3936]
===
match
---
simple_stmt [1165,1208]
simple_stmt [1150,1193]
===
match
---
import_name [881,898]
import_name [866,883]
===
match
---
arglist [7223,7277]
arglist [7243,7297]
===
match
---
atom_expr [5142,5158]
atom_expr [5162,5178]
===
match
---
name: grep [5739,5743]
name: grep [5759,5763]
===
match
---
operator: + [2448,2449]
operator: + [2468,2469]
===
match
---
simple_stmt [7998,8032]
simple_stmt [8018,8052]
===
match
---
operator: , [7716,7717]
operator: , [7736,7737]
===
match
---
string: "ssh" [9250,9255]
string: "ssh" [9270,9275]
===
match
---
operator: } [11160,11161]
operator: } [11180,11181]
===
match
---
name: conf [7061,7065]
name: conf [7081,7085]
===
match
---
trailer [11042,11099]
trailer [11062,11119]
===
match
---
trailer [4601,4603]
trailer [4621,4623]
===
match
---
name: sys [8164,8167]
name: sys [8184,8187]
===
match
---
funcdef [12823,13219]
funcdef [12843,13239]
===
match
---
name: get [7066,7069]
name: get [7086,7089]
===
match
---
name: logging [847,854]
name: logging [832,839]
===
match
---
name: Architecture [4791,4803]
name: Architecture [4811,4823]
===
match
---
name: log [11994,11997]
name: log [12014,12017]
===
match
---
atom [10301,10345]
atom [10321,10365]
===
match
---
name: platform [8048,8056]
name: platform [8068,8076]
===
match
---
import_from [1165,1207]
import_from [1150,1192]
===
match
---
simple_stmt [9891,9994]
simple_stmt [9911,10014]
===
match
---
operator: , [7853,7854]
operator: , [7873,7874]
===
match
---
trailer [3962,3967]
trailer [3982,3987]
===
match
---
testlist_comp [10025,10053]
testlist_comp [10045,10073]
===
match
---
simple_stmt [11029,11100]
simple_stmt [11049,11120]
===
match
---
name: netloc [3525,3531]
name: netloc [3545,3551]
===
match
---
name: executable [8168,8178]
name: executable [8188,8198]
===
match
---
name: sys [4187,4190]
name: sys [4207,4210]
===
match
---
name: str [6129,6132]
name: str [6149,6152]
===
match
---
name: replace [2295,2302]
name: replace [2315,2322]
===
match
---
name: output [11456,11462]
name: output [11476,11482]
===
match
---
name: process_path [9685,9697]
name: process_path [9705,9717]
===
match
---
name: expanduser [1995,2005]
name: expanduser [2023,2033]
===
match
---
string: """Remove pii from URL""" [1630,1655]
string: """Remove pii from URL""" [1658,1683]
===
match
---
name: __class__ [6180,6189]
name: __class__ [6200,6209]
===
match
---
operator: , [10788,10789]
operator: , [10808,10809]
===
match
---
atom_expr [5313,5328]
atom_expr [5333,5348]
===
match
---
name: self [10584,10588]
name: self [10604,10608]
===
match
---
suite [11012,11196]
suite [11032,11216]
===
match
---
string: "base_log_folder" [7779,7796]
string: "base_log_folder" [7799,7816]
===
match
---
name: str [12785,12788]
name: str [12805,12808]
===
match
---
trailer [12477,12522]
trailer [12497,12542]
===
match
---
operator: , [3729,3730]
operator: , [3749,3750]
===
match
---
name: retry [11906,11911]
name: retry [11926,11931]
===
match
---
except_clause [6483,6499]
except_clause [6503,6519]
===
match
---
operator: = [12213,12214]
operator: = [12233,12234]
===
match
---
name: data [5757,5761]
name: data [5777,5781]
===
match
---
arglist [7387,7448]
arglist [7407,7468]
===
match
---
operator: , [8468,8469]
operator: , [8488,8489]
===
match
---
comparison [4175,4199]
comparison [4195,4219]
===
match
---
atom_expr [6856,6979]
atom_expr [6876,6999]
===
match
---
trailer [7337,7350]
trailer [7357,7370]
===
match
---
suite [6247,6307]
suite [6267,6327]
===
match
---
expr_stmt [7998,8031]
expr_stmt [8018,8051]
===
match
---
string: """Compute architecture""" [4370,4396]
string: """Compute architecture""" [4390,4416]
===
match
---
simple_stmt [1007,1023]
simple_stmt [992,1008]
===
match
---
name: process_username [1503,1519]
name: process_username [1531,1547]
===
match
---
operator: = [3224,3225]
operator: = [3244,3245]
===
match
---
operator: , [8338,8339]
operator: , [8358,8359]
===
match
---
operator: , [1524,1525]
operator: , [1552,1553]
===
match
---
param [11450,11455]
param [11470,11475]
===
match
---
operator: , [2999,3000]
operator: , [3019,3020]
===
match
---
testlist_comp [8630,8648]
testlist_comp [8650,8668]
===
match
---
name: os [10143,10145]
name: os [10163,10165]
===
match
---
decorated [4473,4613]
decorated [4493,4633]
===
match
---
atom_expr [7200,7278]
atom_expr [7220,7298]
===
match
---
name: get_current [3937,3948]
name: get_current [3957,3968]
===
match
---
name: remote_base_log_folder [7855,7877]
name: remote_base_log_folder [7875,7897]
===
match
---
name: wait [11848,11852]
name: wait [11868,11872]
===
match
---
arglist [11994,12012]
arglist [12014,12032]
===
match
---
string: "NOT AVAILABLE" [6557,6572]
string: "NOT AVAILABLE" [6577,6592]
===
match
---
operator: , [7747,7748]
operator: , [7767,7768]
===
match
---
name: airflow [1029,1036]
name: airflow [1014,1021]
===
match
---
atom_expr [8673,8705]
atom_expr [8693,8725]
===
match
---
operator: = [3449,3450]
operator: = [3469,3470]
===
match
---
return_stmt [10293,10393]
return_stmt [10313,10413]
===
match
---
name: url_parts [3689,3698]
name: url_parts [3709,3718]
===
match
---
atom_expr [3748,3766]
atom_expr [3768,3786]
===
match
---
param [6610,6614]
param [6630,6634]
===
match
---
atom [8629,8649]
atom [8649,8669]
===
match
---
trailer [4803,4807]
trailer [4823,4827]
===
match
---
operator: = [1324,1325]
operator: = [1352,1353]
===
match
---
return_stmt [2196,2208]
return_stmt [2216,2228]
===
match
---
name: target [2308,2314]
name: target [2328,2334]
===
match
---
atom [8252,8546]
atom [8272,8566]
===
match
---
atom [7688,7716]
atom [7708,7736]
===
match
---
string: "task_logging_handler" [7569,7591]
string: "task_logging_handler" [7589,7611]
===
match
---
trailer [8391,8398]
trailer [8411,8418]
===
match
---
string: "kubectl" [8751,8760]
string: "kubectl" [8771,8780]
===
match
---
string: """Remove pii from username""" [1549,1579]
string: """Remove pii from username""" [1577,1607]
===
match
---
name: platform [4191,4199]
name: platform [4211,4219]
===
match
---
expr_stmt [2559,2586]
expr_stmt [2579,2606]
===
match
---
name: ssh_version [9257,9268]
name: ssh_version [9277,9288]
===
match
---
name: data [11325,11329]
name: data [11345,11349]
===
match
---
try_stmt [12613,12794]
try_stmt [12633,12814]
===
match
---
string: "@" [3462,3465]
string: "@" [3482,3485]
===
match
---
atom [12214,12231]
atom [12234,12251]
===
match
---
string: "core" [7070,7076]
string: "core" [7090,7096]
===
match
---
name: OperatingSystem [7960,7975]
name: OperatingSystem [7980,7995]
===
match
---
atom_expr [2439,2447]
atom_expr [2459,2467]
===
match
---
import_name [865,880]
import_name [850,865]
===
match
---
suite [3060,3101]
suite [3080,3121]
===
match
---
trailer [4271,4280]
trailer [4291,4300]
===
match
---
operator: , [5002,5003]
operator: , [5022,5023]
===
match
---
string: """Show information related to Airflow, system and other.""" [12848,12908]
string: """Show information related to Airflow, system and other.""" [12868,12928]
===
match
---
return_stmt [3670,3768]
return_stmt [3690,3788]
===
match
---
trailer [5507,5513]
trailer [5527,5533]
===
match
---
atom_expr [7158,7288]
atom_expr [7178,7308]
===
match
---
trailer [7186,7288]
trailer [7206,7308]
===
match
---
parameters [12836,12842]
parameters [12856,12862]
===
match
---
operator: , [8697,8698]
operator: , [8717,8718]
===
match
---
dictorsetmaker [4648,5191]
dictorsetmaker [4668,5211]
===
match
---
funcdef [7909,8547]
funcdef [7929,8567]
===
match
---
funcdef [5273,5342]
funcdef [5293,5362]
===
match
---
name: __name__ [6298,6306]
name: __name__ [6318,6326]
===
match
---
suite [1746,1768]
suite [1774,1796]
===
match
---
string: """Anonymizer protocol.""" [1388,1414]
string: """Anonymizer protocol.""" [1416,1442]
===
match
---
trailer [2294,2302]
trailer [2314,2322]
===
match
---
expr_stmt [3342,3389]
expr_stmt [3362,3409]
===
match
---
trailer [1994,2005]
trailer [2022,2033]
===
match
---
operator: , [10648,10649]
operator: , [10668,10669]
===
match
---
testlist_comp [11331,11398]
testlist_comp [11351,11418]
===
match
---
atom [8499,8535]
atom [8519,8555]
===
match
---
argument [6944,6968]
argument [6964,6988]
===
match
---
return_stmt [2411,2423]
return_stmt [2431,2443]
===
match
---
trailer [12248,12251]
trailer [12268,12271]
===
match
---
suite [1540,1580]
suite [1568,1608]
===
match
---
except_clause [5577,5591]
except_clause [5597,5611]
===
match
---
name: ARM [5093,5096]
name: ARM [5113,5116]
===
match
---
name: __init__ [5277,5285]
name: __init__ [5297,5305]
===
match
---
trailer [6142,6153]
trailer [6162,6173]
===
match
---
expr_stmt [2800,2851]
expr_stmt [2820,2871]
===
match
---
operator: , [8859,8860]
operator: , [8879,8880]
===
match
---
name: anonymizer [9760,9770]
name: anonymizer [9780,9790]
===
match
---
atom_expr [3689,3705]
atom_expr [3709,3725]
===
match
---
operator: = [2080,2081]
operator: = [2100,2101]
===
match
---
parameters [1959,1965]
parameters [1987,1993]
===
match
---
operator: , [4711,4712]
operator: , [4731,4732]
===
match
---
atom_expr [5550,5567]
atom_expr [5570,5587]
===
match
---
operator: = [11534,11535]
operator: = [11554,11555]
===
match
---
simple_stmt [12288,12355]
simple_stmt [12308,12375]
===
match
---
operator: , [977,978]
operator: , [962,963]
===
match
---
name: p [9791,9792]
name: p [9811,9812]
===
match
---
trailer [13011,13021]
trailer [13031,13041]
===
match
---
arglist [12044,12062]
arglist [12064,12082]
===
match
---
string: "ppc" [4446,4451]
string: "ppc" [4466,4471]
===
match
---
atom_expr [3677,3768]
atom_expr [3697,3788]
===
match
---
name: str [1536,1539]
name: str [1564,1567]
===
match
---
name: ARM [5061,5064]
name: ARM [5081,5084]
===
match
---
testlist_comp [3689,3766]
testlist_comp [3709,3786]
===
match
---
trailer [7173,7186]
trailer [7193,7206]
===
match
---
if_stmt [2951,3101]
if_stmt [2971,3121]
===
match
---
simple_stmt [7469,7890]
simple_stmt [7489,7910]
===
match
---
name: grep [5790,5794]
name: grep [5810,5814]
===
match
---
name: host [3557,3561]
name: host [3577,3581]
===
match
---
string: "--short=True" [8773,8787]
string: "--short=True" [8793,8807]
===
match
---
argument [5519,5541]
argument [5539,5561]
===
match
---
name: lower [11334,11339]
name: lower [11354,11359]
===
match
---
simple_stmt [11526,11564]
simple_stmt [11546,11584]
===
match
---
simple_stmt [1058,1110]
simple_stmt [1043,1095]
===
match
---
name: o [6286,6287]
name: o [6306,6307]
===
match
---
atom_expr [13196,13218]
atom_expr [13216,13238]
===
match
---
param [1526,1531]
param [1554,1559]
===
match
---
trailer [2579,2586]
trailer [2599,2606]
===
match
---
simple_stmt [6054,6086]
simple_stmt [6074,6106]
===
match
---
operator: , [9235,9236]
operator: , [9255,9256]
===
match
---
trailer [11617,11649]
trailer [11637,11669]
===
match
---
name: join [10154,10158]
name: join [10174,10178]
===
match
---
operator: = [3349,3350]
operator: = [3369,3370]
===
match
---
trailer [9615,9627]
trailer [9635,9647]
===
match
---
expr_stmt [2281,2315]
expr_stmt [2301,2335]
===
match
---
not_test [2173,2182]
not_test [2193,2202]
===
match
---
name: sql_alchemy_conn [7657,7673]
name: sql_alchemy_conn [7677,7693]
===
match
---
operator: , [11454,11455]
operator: , [11474,11475]
===
match
---
name: stdoutdata [5698,5708]
name: stdoutdata [5718,5728]
===
match
---
operator: , [4961,4962]
operator: , [4981,4982]
===
match
---
name: ssh_version [8659,8670]
name: ssh_version [8679,8690]
===
match
---
name: python_version [8470,8484]
name: python_version [8490,8504]
===
match
---
operator: , [6927,6928]
operator: , [6947,6948]
===
match
---
param [5398,5426]
param [5418,5446]
===
match
---
operator: , [7518,7519]
operator: , [7538,7539]
===
match
---
atom_expr [8424,8436]
atom_expr [8444,8456]
===
match
---
and_test [3407,3424]
and_test [3427,3444]
===
match
---
trailer [11396,11398]
trailer [11416,11418]
===
match
---
simple_stmt [5219,5268]
simple_stmt [5239,5288]
===
match
---
string: "darwin" [4175,4183]
string: "darwin" [4195,4203]
===
match
---
suite [11722,11784]
suite [11742,11804]
===
match
---
testlist_comp [9250,9268]
testlist_comp [9270,9288]
===
match
---
operator: -> [11469,11471]
operator: -> [11489,11491]
===
match
---
name: platform [4585,4593]
name: platform [4605,4613]
===
match
---
trailer [4584,4612]
trailer [4604,4632]
===
match
---
comparison [4023,4038]
comparison [4043,4058]
===
match
---
decorator [10244,10254]
decorator [10264,10274]
===
match
---
string: "Report uploaded." [12681,12699]
string: "Report uploaded." [12701,12719]
===
match
---
operator: , [9471,9472]
operator: , [9491,9492]
===
match
---
name: NullAnonymizer [1664,1678]
name: NullAnonymizer [1692,1706]
===
match
---
string: "executor" [6667,6677]
string: "executor" [6687,6697]
===
match
---
string: """Get architecture""" [4518,4540]
string: """Get architecture""" [4538,4560]
===
match
---
name: self [1733,1737]
name: self [1761,1765]
===
match
---
name: host [3610,3614]
name: host [3630,3634]
===
match
---
name: kubectl_version [9295,9310]
name: kubectl_version [9315,9330]
===
match
---
operator: = [9829,9830]
operator: = [9849,9850]
===
match
---
string: "cygwin" [4256,4264]
string: "cygwin" [4276,4284]
===
match
---
name: f [5693,5694]
name: f [5713,5714]
===
match
---
simple_stmt [12456,12523]
simple_stmt [12476,12543]
===
match
---
name: executor [6625,6633]
name: executor [6645,6653]
===
match
---
simple_stmt [2432,2468]
simple_stmt [2452,2488]
===
match
---
string: "Windows" [3836,3845]
string: "Windows" [3856,3865]
===
match
---
name: handler [6376,6383]
name: handler [6396,6403]
===
match
---
atom_expr [5652,5670]
atom_expr [5672,5690]
===
match
---
trailer [12266,12279]
trailer [12286,12299]
===
match
---
name: e [12445,12446]
name: e [12465,12466]
===
match
---
trailer [9603,9611]
trailer [9623,9631]
===
match
---
name: Architecture [4850,4862]
name: Architecture [4870,4882]
===
match
---
atom_expr [5404,5419]
atom_expr [5424,5439]
===
match
---
simple_stmt [11608,11650]
simple_stmt [11628,11670]
===
match
---
operator: , [10692,10693]
operator: , [10712,10713]
===
match
---
arglist [5514,5567]
arglist [5534,5587]
===
match
---
trailer [13210,13217]
trailer [13230,13237]
===
match
---
string: "gcloud" [8851,8859]
string: "gcloud" [8871,8879]
===
match
---
name: __class__ [6065,6074]
name: __class__ [6085,6094]
===
match
---
operator: = [3856,3857]
operator: = [3876,3877]
===
match
---
atom_expr [5815,5824]
atom_expr [5835,5844]
===
match
---
string: "sql_alchemy_conn" [7637,7655]
string: "sql_alchemy_conn" [7657,7675]
===
match
---
import_name [840,854]
import_name [825,839]
===
match
---
trailer [9013,9026]
trailer [9033,9046]
===
match
---
trailer [11993,12013]
trailer [12013,12033]
===
match
---
name: NullAnonymizer [13043,13057]
name: NullAnonymizer [13063,13077]
===
match
---
operator: , [7702,7703]
operator: , [7722,7723]
===
match
---
testlist_comp [9755,9807]
testlist_comp [9775,9827]
===
match
---
name: console [10809,10816]
name: console [10829,10836]
===
match
---
param [1733,1738]
param [1761,1766]
===
match
---
operator: , [5127,5128]
operator: , [5147,5148]
===
match
---
expr_stmt [3215,3258]
expr_stmt [3235,3278]
===
match
---
name: process_url [1589,1600]
name: process_url [1617,1628]
===
match
---
testlist_comp [9163,9182]
testlist_comp [9183,9202]
===
match
---
classdef [1658,1850]
classdef [1686,1878]
===
match
---
suite [5967,6573]
suite [5987,6593]
===
match
---
name: self [10408,10412]
name: self [10428,10432]
===
match
---
name: json [12272,12276]
name: json [12292,12296]
===
match
---
name: Anonymizer [1362,1372]
name: Anonymizer [1390,1400]
===
match
---
operator: @ [11786,11787]
operator: @ [11806,11807]
===
match
---
trailer [11339,11341]
trailer [11359,11361]
===
match
---
string: "${USER}" [2115,2124]
string: "${USER}" [2135,2144]
===
match
---
string: ":" [3362,3365]
string: ":" [3382,3385]
===
match
---
argument [11893,11899]
argument [11913,11919]
===
match
---
name: fallback [7096,7104]
name: fallback [7116,7124]
===
match
---
name: self [9144,9148]
name: self [9164,9168]
===
match
---
simple_stmt [4294,4324]
simple_stmt [4314,4344]
===
match
---
name: sys [4107,4110]
name: sys [4127,4130]
===
match
---
name: args [13025,13029]
name: args [13045,13049]
===
match
---
name: _get_version [8737,8749]
name: _get_version [8757,8769]
===
match
---
trailer [11390,11396]
trailer [11410,11416]
===
match
---
atom_expr [4585,4611]
atom_expr [4605,4631]
===
match
---
string: "SQL_ALCHEMY_CONN" [6778,6796]
string: "SQL_ALCHEMY_CONN" [6798,6816]
===
match
---
trailer [2005,2010]
trailer [2033,2038]
===
match
---
trailer [6362,6371]
trailer [6382,6391]
===
match
---
string: "base_log_folder" [7234,7251]
string: "base_log_folder" [7254,7271]
===
match
---
name: self [2056,2060]
name: self [2076,2080]
===
match
---
name: retry_if_exception_type [11921,11944]
name: retry_if_exception_type [11941,11964]
===
match
---
name: process_path [6872,6884]
name: process_path [6892,6904]
===
match
---
name: conf [7214,7218]
name: conf [7234,7238]
===
match
---
name: info [10987,10991]
name: info [11007,11011]
===
match
---
operator: = [4428,4429]
operator: = [4448,4449]
===
match
---
simple_stmt [2727,2743]
simple_stmt [2747,2763]
===
match
---
string: "architecture" [8324,8338]
string: "architecture" [8344,8358]
===
match
---
testlist_comp [8751,8804]
testlist_comp [8771,8824]
===
match
---
name: anonymizer [13083,13093]
name: anonymizer [13103,13113]
===
match
---
arglist [6659,6677]
arglist [6679,6697]
===
match
---
atom_expr [10436,10460]
atom_expr [10456,10480]
===
match
---
string: "NOT AVAILABLE" [8293,8308]
string: "NOT AVAILABLE" [8313,8328]
===
match
---
import_from [1058,1109]
import_from [1043,1094]
===
match
---
string: "version" [8762,8771]
string: "version" [8782,8791]
===
match
---
string: "dags_folder" [7689,7702]
string: "dags_folder" [7709,7722]
===
match
---
trailer [12033,12043]
trailer [12053,12063]
===
match
---
operator: @ [5921,5922]
operator: @ [5941,5942]
===
match
---
string: "nt" [4034,4038]
string: "nt" [4054,4058]
===
match
---
name: PPC [5030,5033]
name: PPC [5050,5053]
===
match
---
string: "version" [8861,8870]
string: "version" [8881,8890]
===
match
---
atom_expr [12709,12720]
atom_expr [12729,12740]
===
match
---
string: "OS" [8267,8271]
string: "OS" [8287,8291]
===
match
---
operator: , [10204,10205]
operator: , [10224,10225]
===
match
---
expr_stmt [9129,9184]
expr_stmt [9149,9204]
===
match
---
name: line [5774,5778]
name: line [5794,5798]
===
match
---
name: Protocol [1199,1207]
name: Protocol [1184,1192]
===
match
---
name: airflow_home [9654,9666]
name: airflow_home [9674,9686]
===
match
---
suite [3968,4344]
suite [3988,4364]
===
match
---
name: self [8673,8677]
name: self [8693,8697]
===
match
---
testlist_comp [7569,7621]
testlist_comp [7589,7641]
===
match
---
name: _get_version [9082,9094]
name: _get_version [9102,9114]
===
match
---
operator: = [9142,9143]
operator: = [9162,9163]
===
match
---
name: args [13206,13210]
name: args [13226,13230]
===
match
---
name: _tools_info [10681,10692]
name: _tools_info [10701,10712]
===
match
---
name: os [9601,9603]
name: os [9621,9623]
===
match
---
name: query [3741,3746]
name: query [3761,3766]
===
match
---
trailer [7222,7278]
trailer [7242,7298]
===
match
---
atom [8451,8485]
atom [8471,8505]
===
match
---
trailer [11982,11993]
trailer [12002,12013]
===
match
---
name: all_info [10541,10549]
name: all_info [10561,10569]
===
match
---
name: urlsplit [2571,2579]
name: urlsplit [2591,2599]
===
match
---
testlist_comp [10302,10344]
testlist_comp [10322,10364]
===
match
---
atom [7568,7622]
atom [7588,7642]
===
match
---
testlist_comp [8266,8536]
testlist_comp [8286,8556]
===
match
---
simple_stmt [2324,2337]
simple_stmt [2344,2357]
===
match
---
atom_expr [12675,12700]
atom_expr [12695,12720]
===
match
---
if_stmt [4020,4324]
if_stmt [4040,4344]
===
match
---
name: process_path [1773,1785]
name: process_path [1801,1813]
===
match
---
name: self [8832,8836]
name: self [8852,8856]
===
match
---
name: self [8933,8937]
name: self [8953,8957]
===
match
---
name: max [11893,11896]
name: max [11913,11916]
===
match
---
simple_stmt [7297,7460]
simple_stmt [7317,7480]
===
match
---
atom_expr [6747,6823]
atom_expr [6767,6843]
===
match
---
operator: = [10856,10857]
operator: = [10876,10877]
===
match
---
operator: , [10039,10040]
operator: , [10059,10060]
===
match
---
name: process_path [9848,9860]
name: process_path [9868,9880]
===
match
---
name: kubectl_version [8714,8729]
name: kubectl_version [8734,8749]
===
match
---
atom_expr [10676,10692]
atom_expr [10696,10712]
===
match
---
operator: @ [4473,4474]
operator: @ [4493,4494]
===
match
---
atom_expr [4059,4082]
atom_expr [4079,4102]
===
match
---
name: after_log [12034,12043]
name: after_log [12054,12063]
===
match
---
atom_expr [2820,2851]
atom_expr [2840,2871]
===
match
---
trailer [12734,12736]
trailer [12754,12756]
===
match
---
operator: + [3366,3367]
operator: + [3386,3387]
===
match
---
expr_stmt [2671,2686]
expr_stmt [2691,2706]
===
match
---
name: password [2727,2735]
name: password [2747,2755]
===
match
---
name: python_version [8188,8202]
name: python_version [8208,8222]
===
match
---
param [9572,9576]
param [9592,9596]
===
match
---
name: logging [12049,12056]
name: logging [12069,12076]
===
match
---
testlist_comp [8324,8363]
testlist_comp [8344,8383]
===
match
---
string: "linux" [4096,4103]
string: "linux" [4116,4123]
===
match
---
string: "NOT AVAILABLE" [5612,5627]
string: "NOT AVAILABLE" [5632,5647]
===
match
---
trailer [8150,8163]
trailer [8170,8183]
===
match
---
string: "python_path" [10128,10141]
string: "python_path" [10148,10161]
===
match
---
atom [9249,9269]
atom [9269,9289]
===
match
---
operator: } [11368,11369]
operator: } [11388,11389]
===
match
---
suite [6041,6307]
suite [6061,6327]
===
match
---
string: "remote_base_log_folder" [7398,7422]
string: "remote_base_log_folder" [7418,7442]
===
match
---
string: "airflow_home" [10025,10039]
string: "airflow_home" [10045,10059]
===
match
---
name: plugins_folder [6988,7002]
name: plugins_folder [7008,7022]
===
match
---
atom [10552,10799]
atom [10572,10819]
===
match
---
name: path [9931,9935]
name: path [9951,9955]
===
match
---
name: e [12424,12425]
name: e [12444,12445]
===
match
---
trailer [2302,2315]
trailer [2322,2335]
===
match
---
atom_expr [8933,8984]
atom_expr [8953,9004]
===
match
---
operator: , [11179,11180]
operator: , [11199,11200]
===
match
---
name: output [11181,11187]
name: output [11201,11207]
===
match
---
string: "armv7l" [5164,5172]
string: "armv7l" [5184,5192]
===
match
---
trailer [9094,9120]
trailer [9114,9140]
===
match
---
operator: = [4409,4410]
operator: = [4429,4430]
===
match
---
trailer [3033,3038]
trailer [3053,3058]
===
match
---
simple_stmt [8597,8651]
simple_stmt [8617,8671]
===
match
---
simple_stmt [9129,9185]
simple_stmt [9149,9205]
===
match
---
name: self [1437,1441]
name: self [1465,1469]
===
match
---
trailer [8690,8705]
trailer [8710,8725]
===
match
---
import_from [1264,1318]
import_from [1292,1346]
===
match
---
name: logging [6387,6394]
name: logging [6407,6414]
===
match
---
atom_expr [9144,9184]
atom_expr [9164,9204]
===
match
---
atom [9461,9489]
atom [9481,9509]
===
match
---
trailer [6454,6459]
trailer [6474,6479]
===
match
---
name: pathsep [10146,10153]
name: pathsep [10166,10173]
===
match
---
name: src [2221,2224]
name: src [2241,2244]
===
match
---
string: "uname" [8379,8386]
string: "uname" [8399,8406]
===
match
---
operator: @ [9542,9543]
operator: @ [9562,9563]
===
match
---
trailer [4740,4747]
trailer [4760,4767]
===
match
---
name: any [9909,9912]
name: any [9929,9932]
===
match
---
trailer [5560,5567]
trailer [5580,5587]
===
match
---
simple_stmt [865,881]
simple_stmt [850,866]
===
match
---
simple_stmt [5757,5804]
simple_stmt [5777,5824]
===
match
---
not_test [12240,12251]
not_test [12260,12271]
===
match
---
name: output [11401,11407]
name: output [11421,11427]
===
match
---
operator: + [3555,3556]
operator: + [3575,3576]
===
match
---
trailer [6459,6474]
trailer [6479,6494]
===
match
---
simple_stmt [3215,3259]
simple_stmt [3235,3279]
===
match
---
funcdef [6592,7890]
funcdef [6612,7910]
===
match
---
name: all_info [11382,11390]
name: all_info [11402,11410]
===
match
---
suite [5477,5569]
suite [5497,5589]
===
match
---
trailer [3170,3180]
trailer [3190,3200]
===
match
---
name: info [13147,13151]
name: info [13167,13171]
===
match
---
name: host [3420,3424]
name: host [3440,3444]
===
match
---
operator: = [11640,11641]
operator: = [11660,11661]
===
match
---
suite [4509,4613]
suite [4529,4633]
===
match
---
simple_stmt [13124,13178]
simple_stmt [13144,13198]
===
match
---
operator: -> [1614,1616]
operator: -> [1642,1644]
===
match
---
simple_stmt [12563,12609]
simple_stmt [12583,12629]
===
match
---
suite [12843,13219]
suite [12863,13239]
===
match
---
operator: + [3360,3361]
operator: + [3380,3381]
===
match
---
string: "link" [12391,12397]
string: "link" [12411,12417]
===
match
---
trailer [7065,7069]
trailer [7085,7089]
===
match
---
name: providers_manager [1123,1140]
name: providers_manager [1108,1125]
===
match
---
classdef [1852,3769]
classdef [1880,3789]
===
match
---
name: url_parts [2620,2629]
name: url_parts [2640,2649]
===
match
---
atom_expr [11382,11398]
atom_expr [11402,11418]
===
match
---
expr_stmt [5757,5803]
expr_stmt [5777,5823]
===
match
---
name: AirflowConsole [10830,10844]
name: AirflowConsole [10850,10864]
===
match
---
fstring_end: " [11080,11081]
fstring_end: " [11100,11101]
===
match
---
trailer [8849,8898]
trailer [8869,8918]
===
match
---
atom_expr [5017,5033]
atom_expr [5037,5053]
===
match
---
name: stdout [5519,5525]
name: stdout [5539,5545]
===
match
---
operator: = [6854,6855]
operator: = [6874,6875]
===
match
---
name: key [11061,11064]
name: key [11081,11084]
===
match
---
param [1607,1612]
param [1635,1640]
===
match
---
decorator [8552,8562]
decorator [8572,8582]
===
match
---
atom [8850,8871]
atom [8870,8891]
===
match
---
operator: , [7764,7765]
operator: , [7784,7785]
===
match
---
name: data [5782,5786]
name: data [5802,5806]
===
match
---
operator: = [5420,5421]
operator: = [5440,5441]
===
match
---
name: get_current [7976,7987]
name: get_current [7996,8007]
===
match
---
name: output [10875,10881]
name: output [10895,10901]
===
match
---
atom_expr [4945,4961]
atom_expr [4965,4981]
===
match
---
operator: , [11997,11998]
operator: , [12017,12018]
===
match
---
operator: , [11399,11400]
operator: , [11419,11420]
===
match
---
string: "NOT AVAILABLE" [7433,7448]
string: "NOT AVAILABLE" [7453,7468]
===
match
---
trailer [3724,3729]
trailer [3744,3749]
===
match
---
atom_expr [6063,6085]
atom_expr [6083,6105]
===
match
---
testlist_comp [10024,10228]
testlist_comp [10044,10248]
===
match
---
name: version [8209,8216]
name: version [8229,8236]
===
match
---
simple_stmt [2411,2424]
simple_stmt [2431,2444]
===
match
---
trailer [11333,11339]
trailer [11353,11359]
===
match
---
simple_stmt [3081,3101]
simple_stmt [3101,3121]
===
match
---
dictorsetmaker [12215,12230]
dictorsetmaker [12235,12250]
===
match
---
name: handler_names [6460,6473]
name: handler_names [6480,6493]
===
match
---
suite [2183,2209]
suite [2203,2229]
===
match
---
name: url_parts [3715,3724]
name: url_parts [3735,3744]
===
match
---
name: data [12209,12213]
name: data [12229,12233]
===
match
---
name: stop [11807,11811]
name: stop [11827,11831]
===
match
---
simple_stmt [8907,8985]
simple_stmt [8927,9005]
===
match
---
trailer [9930,9935]
trailer [9950,9955]
===
match
---
operator: , [11375,11376]
operator: , [11395,11396]
===
match
---
expr_stmt [2991,3038]
expr_stmt [3011,3058]
===
match
---
string: "git" [8630,8635]
string: "git" [8650,8655]
===
match
---
atom_expr [11665,11686]
atom_expr [11685,11706]
===
match
---
name: anonymizer [8140,8150]
name: anonymizer [8160,8170]
===
match
---
name: parse [956,961]
name: parse [941,946]
===
match
---
trailer [8029,8031]
trailer [8049,8051]
===
match
---
dotted_name [1269,1284]
dotted_name [1297,1312]
===
match
---
string: "remote_base_log_folder" [7829,7853]
string: "remote_base_log_folder" [7849,7873]
===
match
---
trailer [13200,13205]
trailer [13220,13225]
===
match
---
return_stmt [5892,5915]
return_stmt [5912,5935]
===
match
---
atom_expr [7005,7131]
atom_expr [7025,7151]
===
match
---
atom_expr [9909,9993]
atom_expr [9929,10013]
===
match
---
operator: , [1441,1442]
operator: , [1469,1470]
===
match
---
operator: = [8877,8878]
operator: = [8897,8898]
===
match
---
expr_stmt [9740,9808]
expr_stmt [9760,9828]
===
match
---
name: Anonymizer [1679,1689]
name: Anonymizer [1707,1717]
===
match
---
name: FileIoException [11695,11710]
name: FileIoException [11715,11730]
===
match
---
name: anonymizer [5331,5341]
name: anonymizer [5351,5361]
===
match
---
trailer [6404,6420]
trailer [6424,6440]
===
match
---
operator: @ [12796,12797]
operator: @ [12816,12817]
===
match
---
param [5382,5397]
param [5402,5417]
===
match
---
param [7926,7930]
param [7946,7950]
===
match
---
simple_stmt [12975,13060]
simple_stmt [12995,13080]
===
match
---
testlist_comp [9284,9310]
testlist_comp [9304,9330]
===
match
---
trailer [6189,6198]
trailer [6209,6218]
===
match
---
trailer [5513,5568]
trailer [5533,5588]
===
match
---
testlist_comp [10187,10226]
testlist_comp [10207,10246]
===
match
---
name: LINUX [4156,4161]
name: LINUX [4176,4181]
===
match
---
name: show_info [12827,12836]
name: show_info [12847,12856]
===
match
---
name: decode [5907,5913]
name: decode [5927,5933]
===
match
---
name: tenacity [11912,11920]
name: tenacity [11932,11940]
===
match
---
name: anonymizer [6711,6721]
name: anonymizer [6731,6741]
===
match
---
testlist_star_expr [2800,2817]
testlist_star_expr [2820,2837]
===
match
---
trailer [11365,11368]
trailer [11385,11388]
===
match
---
tfpdef [5382,5396]
tfpdef [5402,5416]
===
match
---
atom_expr [11116,11195]
atom_expr [11136,11215]
===
match
---
simple_stmt [4518,4541]
simple_stmt [4538,4561]
===
match
---
atom_expr [10830,10863]
atom_expr [10850,10883]
===
match
---
name: username [2019,2027]
name: username [2047,2055]
===
match
---
testlist_comp [7490,7879]
testlist_comp [7510,7899]
===
match
---
name: staticmethod [5922,5934]
name: staticmethod [5942,5954]
===
match
---
test [3226,3258]
test [3246,3278]
===
match
---
except_clause [12403,12425]
except_clause [12423,12445]
===
match
---
param [5286,5291]
param [5306,5311]
===
match
---
operator: , [7814,7815]
operator: , [7834,7835]
===
match
---
param [12837,12841]
param [12857,12861]
===
match
---
name: home_path [2083,2092]
name: home_path [2103,2112]
===
match
---
name: platform [4272,4280]
name: platform [4292,4300]
===
match
---
name: value [1526,1531]
name: value [1554,1559]
===
match
---
string: """Return tools version.""" [5437,5464]
string: """Return tools version.""" [5457,5484]
===
match
---
atom_expr [12261,12279]
atom_expr [12281,12299]
===
match
---
name: o [6178,6179]
name: o [6198,6199]
===
match
---
decorator [7895,7905]
decorator [7915,7925]
===
match
---
trailer [4235,4242]
trailer [4255,4262]
===
match
---
name: info [12552,12556]
name: info [12572,12576]
===
match
---
operator: , [9447,9448]
operator: , [9467,9468]
===
match
---
string: "arm64" [5102,5109]
string: "arm64" [5122,5129]
===
match
---
name: Anonymizer [1872,1882]
name: Anonymizer [1900,1910]
===
match
---
trailer [11944,11961]
trailer [11964,11981]
===
match
---
atom [10186,10227]
atom [10206,10247]
===
match
---
name: configuration [6636,6649]
name: configuration [6656,6669]
===
match
---
name: v [11377,11378]
name: v [11397,11398]
===
match
---
string: "python_location" [8500,8517]
string: "python_location" [8520,8537]
===
match
---
name: _send_report_to_fileio [12529,12551]
name: _send_report_to_fileio [12549,12571]
===
match
---
if_stmt [2511,2550]
if_stmt [2531,2570]
===
match
---
name: username [3451,3459]
name: username [3471,3479]
===
match
---
not_test [2388,2397]
not_test [2408,2417]
===
match
---
name: value [2458,2463]
name: value [2478,2483]
===
match
---
import_as_names [929,943]
import_as_names [914,928]
===
match
---
string: "--client=True" [8789,8804]
string: "--client=True" [8809,8824]
===
match
---
simple_stmt [1836,1850]
simple_stmt [1864,1878]
===
match
---
name: url_parts [2820,2829]
name: url_parts [2840,2849]
===
match
---
name: requests [12176,12184]
name: requests [12196,12204]
===
match
---
dotted_name [1213,1230]
dotted_name [1198,1215]
===
match
---
import_from [1110,1164]
import_from [1095,1149]
===
match
---
suite [9578,10239]
suite [9598,10259]
===
match
---
name: PPC [4999,5002]
name: PPC [5019,5022]
===
match
---
name: system_path [10100,10111]
name: system_path [10120,10131]
===
match
---
trailer [11349,11359]
trailer [11369,11379]
===
match
---
trailer [4190,4199]
trailer [4210,4219]
===
match
---
expr_stmt [8714,8806]
expr_stmt [8734,8826]
===
match
---
atom_expr [8083,8108]
atom_expr [8103,8128]
===
match
---
atom_expr [8005,8031]
atom_expr [8025,8051]
===
match
---
decorated [5347,5916]
decorated [5367,5936]
===
match
---
atom_expr [10720,10736]
atom_expr [10740,10756]
===
match
---
simple_stmt [3342,3390]
simple_stmt [3362,3410]
===
match
---
operator: = [8203,8204]
operator: = [8223,8224]
===
match
---
trailer [10158,10171]
trailer [10178,10191]
===
match
---
string: "PATH" [9616,9622]
string: "PATH" [9636,9642]
===
match
---
operator: = [1805,1806]
operator: = [1833,1834]
===
match
---
string: "Failed to send report to file.io service." [12310,12353]
string: "Failed to send report to file.io service." [12330,12373]
===
match
---
return_stmt [8245,8546]
return_stmt [8265,8566]
===
match
---
operator: , [9255,9256]
operator: , [9275,9276]
===
match
---
atom_expr [8205,8235]
atom_expr [8225,8255]
===
match
---
atom_expr [8611,8650]
atom_expr [8631,8670]
===
match
---
trailer [11036,11042]
trailer [11056,11062]
===
match
---
trailer [11123,11132]
trailer [11143,11152]
===
match
---
expr_stmt [4402,4419]
expr_stmt [4422,4439]
===
match
---
string: "~" [2006,2009]
string: "~" [2034,2037]
===
match
---
operator: = [2680,2681]
operator: = [2700,2701]
===
match
---
string: ":" [3534,3537]
string: ":" [3554,3557]
===
match
---
string: "Paths info" [10706,10718]
string: "Paths info" [10726,10738]
===
match
---
simple_stmt [1024,1058]
simple_stmt [1009,1043]
===
match
---
atom_expr [9873,9881]
atom_expr [9893,9901]
===
match
---
atom_expr [4023,4030]
atom_expr [4043,4050]
===
match
---
trailer [8056,8062]
trailer [8076,8082]
===
match
---
atom_expr [5899,5915]
atom_expr [5919,5935]
===
match
---
raise_stmt [12288,12354]
raise_stmt [12308,12374]
===
match
---
testlist_comp [7689,7715]
testlist_comp [7709,7735]
===
match
---
atom_expr [7960,7989]
atom_expr [7980,8009]
===
match
---
name: STDOUT [5561,5567]
name: STDOUT [5581,5587]
===
match
---
name: _get_version [8837,8849]
name: _get_version [8857,8869]
===
match
---
return_stmt [4294,4323]
return_stmt [4314,4343]
===
match
---
name: Architecture [4728,4740]
name: Architecture [4748,4760]
===
match
---
trailer [4957,4961]
trailer [4977,4981]
===
match
---
name: self [6610,6614]
name: self [6630,6634]
===
match
---
simple_stmt [4213,4243]
simple_stmt [4233,4263]
===
match
---
expr_stmt [2727,2742]
expr_stmt [2747,2762]
===
match
---
suite [12103,12523]
suite [12123,12543]
===
match
---
string: "cloud_sql_proxy" [8952,8969]
string: "cloud_sql_proxy" [8972,8989]
===
match
---
expr_stmt [3442,3472]
expr_stmt [3462,3492]
===
match
---
testlist_comp [8379,8398]
testlist_comp [8399,8418]
===
match
---
name: log [12044,12047]
name: log [12064,12067]
===
match
---
operator: { [2082,2083]
operator: { [2102,2103]
===
match
---
name: OSError [5584,5591]
name: OSError [5604,5611]
===
match
---
name: line [5765,5769]
name: line [5785,5789]
===
match
---
operator: = [7261,7262]
operator: = [7281,7282]
===
match
---
name: psql_version [9512,9524]
name: psql_version [9532,9544]
===
match
---
atom_expr [12025,12063]
atom_expr [12045,12083]
===
match
---
name: ProvidersManager [1148,1164]
name: ProvidersManager [1133,1149]
===
match
---
try_stmt [5473,5628]
try_stmt [5493,5648]
===
match
---
exprlist [10982,10991]
exprlist [11002,11011]
===
match
---
trailer [5656,5668]
trailer [5676,5688]
===
match
---
name: dags_folder [6842,6853]
name: dags_folder [6862,6873]
===
match
---
atom_expr [10584,10602]
atom_expr [10604,10622]
===
match
---
trailer [9636,9644]
trailer [9656,9664]
===
match
---
trailer [3153,3170]
trailer [3173,3190]
===
match
---
name: Popen [5508,5513]
name: Popen [5528,5533]
===
match
---
name: subprocess [5550,5560]
name: subprocess [5570,5580]
===
match
---
name: _MACHINE_TO_ARCHITECTURE [4556,4580]
name: _MACHINE_TO_ARCHITECTURE [4576,4600]
===
match
---
simple_stmt [2991,3039]
simple_stmt [3011,3059]
===
match
---
string: "${HOME}" [2094,2103]
string: "${HOME}" [2114,2123]
===
match
---
param [6038,6039]
param [6058,6059]
===
match
---
name: __name__ [6190,6198]
name: __name__ [6210,6218]
===
match
---
for_stmt [2217,2316]
for_stmt [2237,2336]
===
match
---
name: join [10095,10099]
name: join [10115,10119]
===
match
---
atom_expr [11536,11563]
atom_expr [11556,11583]
===
match
---
param [2489,2494]
param [2509,2514]
===
match
---
operator: = [4444,4445]
operator: = [4464,4465]
===
match
---
atom_expr [10995,11011]
atom_expr [11015,11031]
===
match
---
name: suppress_logs_and_warning [12797,12822]
name: suppress_logs_and_warning [12817,12842]
===
match
---
operator: , [10893,10894]
operator: , [10913,10914]
===
match
---
decorated [7895,8547]
decorated [7915,8567]
===
match
---
operator: = [2708,2709]
operator: = [2728,2729]
===
match
---
if_stmt [2756,2910]
if_stmt [2776,2930]
===
match
---
atom_expr [11999,12012]
atom_expr [12019,12032]
===
match
---
name: Architecture [4986,4998]
name: Architecture [5006,5018]
===
match
---
trailer [4025,4030]
trailer [4045,4050]
===
match
---
name: conf [7378,7382]
name: conf [7398,7402]
===
match
---
operator: , [8364,8365]
operator: , [8384,8385]
===
match
---
import_from [910,943]
import_from [895,928]
===
match
---
trailer [7009,7020]
trailer [7029,7040]
===
match
---
name: tenacity [11974,11982]
name: tenacity [11994,12002]
===
match
---
atom [5686,5727]
atom [5706,5747]
===
match
---
decorator [5921,5935]
decorator [5941,5955]
===
match
---
name: stderr [5543,5549]
name: stderr [5563,5569]
===
match
---
trailer [7350,7459]
trailer [7370,7479]
===
match
---
testlist_comp [9366,9408]
testlist_comp [9386,9428]
===
match
---
operator: , [9525,9526]
operator: , [9545,9546]
===
match
---
operator: { [12214,12215]
operator: { [12234,12235]
===
match
---
expr_stmt [12626,12666]
expr_stmt [12646,12686]
===
match
---
arglist [6921,6968]
arglist [6941,6988]
===
match
---
or_test [8340,8363]
or_test [8360,8383]
===
match
---
suite [6537,6573]
suite [6557,6593]
===
match
---
operator: , [8437,8438]
operator: , [8457,8458]
===
match
---
operator: , [1605,1606]
operator: , [1633,1634]
===
match
---
factor [2464,2466]
factor [2484,2486]
===
match
---
operator: = [3877,3878]
operator: = [3897,3898]
===
match
---
name: Exception [11711,11720]
name: Exception [11731,11740]
===
match
---
operator: = [11911,11912]
operator: = [11931,11932]
===
match
---
string: "git" [9216,9221]
string: "git" [9236,9241]
===
match
---
simple_stmt [7941,7990]
simple_stmt [7961,8010]
===
match
---
sync_comp_for [5689,5726]
sync_comp_for [5709,5746]
===
match
---
trailer [6733,6833]
trailer [6753,6853]
===
match
---
test [3149,3202]
test [3169,3222]
===
match
---
name: Architecture [4352,4364]
name: Architecture [4372,4384]
===
match
---
atom_expr [3731,3746]
atom_expr [3751,3766]
===
match
---
name: configuration [9698,9711]
name: configuration [9718,9731]
===
match
---
simple_stmt [3525,3562]
simple_stmt [3545,3582]
===
match
---
atom_expr [13164,13175]
atom_expr [13184,13195]
===
match
---
argument [11807,11842]
argument [11827,11862]
===
match
---
trailer [12788,12792]
trailer [12808,12812]
===
match
---
trailer [8089,8106]
trailer [8109,8126]
===
match
---
atom_expr [5698,5721]
atom_expr [5718,5741]
===
match
---
string: b"\n" [5715,5720]
string: b"\n" [5735,5740]
===
match
---
operator: , [10736,10737]
operator: , [10756,10757]
===
match
---
name: platform [872,880]
name: platform [857,865]
===
match
---
operator: , [3705,3706]
operator: , [3725,3726]
===
match
---
atom_expr [8048,8064]
atom_expr [8068,8084]
===
match
---
operator: != [5825,5827]
operator: != [5845,5847]
===
match
---
funcdef [12525,12794]
funcdef [12545,12814]
===
match
---
simple_stmt [3601,3615]
simple_stmt [3621,3635]
===
match
---
atom_expr [12176,12232]
atom_expr [12196,12252]
===
match
---
name: resp [12169,12173]
name: resp [12189,12193]
===
match
---
name: file_io [13030,13037]
name: file_io [13050,13057]
===
match
---
simple_stmt [11485,11518]
simple_stmt [11505,11538]
===
match
---
expr_stmt [3138,3202]
expr_stmt [3158,3222]
===
match
---
operator: , [12013,12014]
operator: , [12033,12034]
===
match
---
name: tenacity [1014,1022]
name: tenacity [999,1007]
===
match
---
string: "i386" [4753,4759]
string: "i386" [4773,4779]
===
match
---
testlist_comp [7829,7877]
testlist_comp [7849,7897]
===
match
---
trailer [10844,10863]
trailer [10864,10883]
===
match
---
name: highlight [11083,11092]
name: highlight [11103,11112]
===
match
---
operator: , [4747,4748]
operator: , [4767,4768]
===
match
---
name: handler [6363,6370]
name: handler [6383,6390]
===
match
---
name: path_elem [9941,9950]
name: path_elem [9961,9970]
===
match
---
name: simple_table [1075,1087]
name: simple_table [1060,1072]
===
match
---
name: _get_version [9149,9161]
name: _get_version [9169,9181]
===
match
---
expr_stmt [9891,9993]
expr_stmt [9911,10013]
===
match
---
operator: = [7156,7157]
operator: = [7176,7177]
===
match
---
funcdef [2473,3769]
funcdef [2493,3789]
===
match
---
exprlist [11374,11378]
exprlist [11394,11398]
===
match
---
atom_expr [2236,2267]
atom_expr [2256,2287]
===
match
---
arith_expr [3451,3472]
arith_expr [3471,3492]
===
match
---
name: process_path [2135,2147]
name: process_path [2155,2167]
===
match
---
operator: = [5650,5651]
operator: = [5670,5671]
===
match
---
name: print [12709,12714]
name: print [12729,12734]
===
match
---
atom_expr [12435,12447]
atom_expr [12455,12467]
===
match
---
name: OperatingSystem [4140,4155]
name: OperatingSystem [4160,4175]
===
match
---
string: "--version" [9107,9118]
string: "--version" [9127,9138]
===
match
---
operator: = [5525,5526]
operator: = [5545,5546]
===
match
---
atom_expr [2458,2467]
atom_expr [2478,2487]
===
match
---
name: cmd [5382,5385]
name: cmd [5402,5405]
===
match
---
name: logging [11999,12006]
name: logging [12019,12026]
===
match
---
name: console [11291,11298]
name: console [11311,11318]
===
match
---
trailer [10094,10099]
trailer [10114,10119]
===
match
---
operator: = [6347,6348]
operator: = [6367,6368]
===
match
---
simple_stmt [6625,6679]
simple_stmt [6645,6699]
===
match
---
simple_stmt [10486,10533]
simple_stmt [10506,10553]
===
match
---
name: v [11366,11367]
name: v [11386,11387]
===
match
---
operator: = [11557,11558]
operator: = [11577,11578]
===
match
---
trailer [10373,10383]
trailer [10393,10403]
===
match
---
atom_expr [7322,7459]
atom_expr [7342,7479]
===
match
---
name: value [2580,2585]
name: value [2600,2605]
===
match
---
trailer [11839,11842]
trailer [11859,11862]
===
match
---
string: "logging" [7387,7396]
string: "logging" [7407,7416]
===
match
---
suite [5879,5916]
suite [5899,5936]
===
match
---
tfpdef [11456,11467]
tfpdef [11476,11487]
===
match
---
name: ex [12789,12791]
name: ex [12809,12811]
===
match
---
atom_expr [5048,5064]
atom_expr [5068,5084]
===
match
---
name: args [13102,13106]
name: args [13122,13126]
===
match
---
simple_stmt [2671,2687]
simple_stmt [2691,2707]
===
match
---
string: "sqlite3" [9462,9471]
string: "sqlite3" [9482,9491]
===
match
---
operator: + [2456,2457]
operator: + [2476,2477]
===
match
---
string: "i686" [4783,4789]
string: "i686" [4803,4809]
===
match
---
name: partition [2837,2846]
name: partition [2857,2866]
===
match
---
argument [11401,11414]
argument [11421,11434]
===
match
---
name: value [2369,2374]
name: value [2389,2394]
===
match
---
param [1960,1964]
param [1988,1992]
===
match
---
expr_stmt [6333,6430]
expr_stmt [6353,6450]
===
match
---
name: render_text [11438,11449]
name: render_text [11458,11469]
===
match
---
operator: = [5684,5685]
operator: = [5704,5705]
===
match
---
arglist [7070,7120]
arglist [7090,7140]
===
match
---
name: self [7926,7930]
name: self [7946,7950]
===
match
---
suite [8588,9537]
suite [8608,9557]
===
match
---
operator: , [3746,3747]
operator: , [3766,3767]
===
match
---
name: fallback [7424,7432]
name: fallback [7444,7452]
===
match
---
name: sqlite3_version [9473,9488]
name: sqlite3_version [9493,9508]
===
match
---
param [11456,11467]
param [11476,11487]
===
match
---
number: 1 [11890,11891]
number: 1 [11910,11911]
===
match
---
expr_stmt [4456,4467]
expr_stmt [4476,4487]
===
match
---
operator: , [5517,5518]
operator: , [5537,5538]
===
match
---
name: items [11004,11009]
name: items [11024,11029]
===
match
---
or_test [13007,13037]
or_test [13027,13057]
===
match
---
name: username [3351,3359]
name: username [3371,3379]
===
match
---
operator: = [6704,6705]
operator: = [6724,6725]
===
match
---
name: data [11133,11137]
name: data [11153,11157]
===
match
---
operator: = [13069,13070]
operator: = [13089,13090]
===
match
---
trailer [9783,9786]
trailer [9803,9806]
===
match
---
name: value [2439,2444]
name: value [2459,2464]
===
match
---
trailer [4074,4082]
trailer [4094,4102]
===
match
---
name: scheme [3699,3705]
name: scheme [3719,3725]
===
match
---
suite [2524,2550]
suite [2544,2570]
===
match
---
atom_expr [3015,3038]
atom_expr [3035,3058]
===
match
---
simple_stmt [6687,6834]
simple_stmt [6707,6854]
===
match
---
operator: , [11900,11901]
operator: , [11920,11921]
===
match
---
string: ", " [6450,6454]
string: ", " [6470,6474]
===
match
---
string: "core" [6770,6776]
string: "core" [6790,6796]
===
match
---
suite [2783,2852]
suite [2803,2872]
===
match
---
parameters [7925,7931]
parameters [7945,7951]
===
match
---
expr_stmt [3649,3660]
expr_stmt [3669,3680]
===
match
---
operator: , [7796,7797]
operator: , [7816,7817]
===
match
---
argument [11133,11179]
argument [11153,11199]
===
match
---
name: self [5313,5317]
name: self [5333,5337]
===
match
---
trailer [5536,5541]
trailer [5556,5561]
===
match
---
arglist [11618,11648]
arglist [11638,11668]
===
match
---
name: process_url [6722,6733]
name: process_url [6742,6753]
===
match
---
name: airflow [1213,1220]
name: airflow [1198,1205]
===
match
---
atom [10010,10238]
atom [10030,10258]
===
match
---
name: sys [4268,4271]
name: sys [4288,4291]
===
match
---
simple_stmt [9587,9646]
simple_stmt [9607,9666]
===
match
---
atom_expr [5080,5096]
atom_expr [5100,5116]
===
match
---
name: FileIoException [11945,11960]
name: FileIoException [11965,11980]
===
match
---
trailer [6871,6884]
trailer [6891,6904]
===
match
---
string: "mysql" [9028,9035]
string: "mysql" [9048,9055]
===
match
---
return_stmt [6264,6306]
return_stmt [6284,6326]
===
match
---
name: resp [12244,12248]
name: resp [12264,12268]
===
match
---
trailer [11861,11878]
trailer [11881,11898]
===
match
---
name: platform [4111,4119]
name: platform [4131,4139]
===
match
---
operator: , [4676,4677]
operator: , [4696,4697]
===
match
---
string: "NOT AVAILABLE" [5850,5865]
string: "NOT AVAILABLE" [5870,5885]
===
match
---
string: ":" [2954,2957]
string: ":" [2974,2977]
===
match
---
import_from [1024,1057]
import_from [1009,1042]
===
match
---
suite [12252,12355]
suite [12272,12375]
===
match
---
trailer [10336,10344]
trailer [10356,10364]
===
match
---
name: anonymizer [5292,5302]
name: anonymizer [5312,5322]
===
match
---
simple_stmt [7140,7289]
simple_stmt [7160,7309]
===
match
---
atom [8323,8364]
atom [8343,8384]
===
match
---
name: _path_replacements [2061,2079]
name: _path_replacements [2081,2099]
===
match
---
name: version [1292,1299]
name: version [1320,1327]
===
match
---
operator: = [7432,7433]
operator: = [7452,7453]
===
match
---
atom [7490,7518]
atom [7510,7538]
===
match
---
fstring_string: \n[bold][green] [11045,11060]
fstring_string: \n[bold][green] [11065,11080]
===
match
---
expr_stmt [6687,6833]
expr_stmt [6707,6853]
===
match
---
sync_comp_for [9787,9807]
sync_comp_for [9807,9827]
===
match
---
testlist_comp [8500,8534]
testlist_comp [8520,8554]
===
match
---
name: bytes [5413,5418]
name: bytes [5433,5438]
===
match
---
name: p [10350,10351]
name: p [10370,10371]
===
match
---
simple_stmt [3870,3888]
simple_stmt [3890,3908]
===
match
---
simple_stmt [6333,6431]
simple_stmt [6353,6451]
===
match
---
name: process_url [1807,1818]
name: process_url [1835,1846]
===
match
---
name: cli [1227,1230]
name: cli [1212,1215]
===
match
---
operator: , [2103,2104]
operator: , [2123,2124]
===
match
---
operator: , [8969,8970]
operator: , [8989,8990]
===
match
---
name: module [6271,6277]
name: module [6291,6297]
===
match
---
funcdef [4491,4613]
funcdef [4511,4633]
===
match
---
name: host [3579,3583]
name: host [3599,3603]
===
match
---
operator: , [11961,11962]
operator: , [11981,11982]
===
match
---
string: "Apache Airflow" [10566,10582]
string: "Apache Airflow" [10586,10602]
===
match
---
operator: -> [3951,3953]
operator: -> [3971,3973]
===
match
---
argument [11618,11631]
argument [11638,11651]
===
match
---
name: netloc [2830,2836]
name: netloc [2850,2856]
===
match
---
trailer [12006,12012]
trailer [12026,12032]
===
match
---
operator: = [8671,8672]
operator: = [8691,8692]
===
match
---
name: host [3468,3472]
name: host [3488,3492]
===
match
---
name: self [10720,10724]
name: self [10740,10744]
===
match
---
name: providers [10374,10383]
name: providers [10394,10403]
===
match
---
name: args [13007,13011]
name: args [13027,13031]
===
match
---
expr_stmt [7941,7989]
expr_stmt [7961,8009]
===
match
---
name: executor [7545,7553]
name: executor [7565,7573]
===
match
---
name: Optional [10436,10444]
name: Optional [10456,10464]
===
match
---
name: module [6119,6125]
name: module [6139,6145]
===
match
---
trailer [5154,5158]
trailer [5174,5178]
===
match
---
name: data [5819,5823]
name: data [5839,5843]
===
match
---
operator: , [5541,5542]
operator: , [5561,5562]
===
match
---
name: password [3490,3498]
name: password [3510,3518]
===
match
---
simple_stmt [12626,12667]
simple_stmt [12646,12687]
===
match
---
trailer [9935,9940]
trailer [9955,9960]
===
match
---
name: self [8732,8736]
name: self [8752,8756]
===
match
---
trailer [12276,12278]
trailer [12296,12298]
===
match
---
name: typing_compat [1178,1191]
name: typing_compat [1163,1176]
===
match
---
name: tenacity [11853,11861]
name: tenacity [11873,11881]
===
match
---
name: process_path [7021,7033]
name: process_path [7041,7053]
===
match
---
name: OperatingSystem [3777,3792]
name: OperatingSystem [3797,3812]
===
match
---
trailer [8208,8216]
trailer [8228,8236]
===
match
---
argument [12209,12231]
argument [12229,12251]
===
match
---
trailer [6911,6916]
trailer [6931,6936]
===
match
---
name: str [1453,1456]
name: str [1481,1484]
===
match
---
name: handlers [6421,6429]
name: handlers [6441,6449]
===
match
---
trailer [9927,9963]
trailer [9947,9983]
===
match
---
name: join [6455,6459]
name: join [6475,6479]
===
match
---
atom [11330,11399]
atom [11350,11419]
===
match
---
atom [9095,9119]
atom [9115,9139]
===
match
---
testlist_comp [8452,8484]
testlist_comp [8472,8504]
===
match
---
suite [4039,4083]
suite [4059,4103]
===
match
---
argument [11879,11891]
argument [11899,11911]
===
match
---
suite [1621,1656]
suite [1649,1684]
===
match
---
name: host [2813,2817]
name: host [2833,2837]
===
match
---
import_name [991,1006]
import_name [976,991]
===
match
---
name: Architecture [8005,8017]
name: Architecture [8025,8037]
===
match
---
name: str [8388,8391]
name: str [8408,8411]
===
match
---
simple_stmt [899,910]
simple_stmt [884,895]
===
match
---
funcdef [1947,2126]
funcdef [1975,2146]
===
match
---
name: ok [12249,12251]
name: ok [12269,12271]
===
match
---
operator: , [9510,9511]
operator: , [9530,9531]
===
match
---
dotted_name [1063,1087]
dotted_name [1048,1072]
===
match
---
name: staticmethod [3916,3928]
name: staticmethod [3936,3948]
===
match
---
decorated [11786,12523]
decorated [11806,12543]
===
match
---
name: password [3004,3012]
name: password [3024,3032]
===
match
---
name: output [11408,11414]
name: output [11428,11434]
===
match
---
name: anonymizer [6861,6871]
name: anonymizer [6881,6891]
===
match
---
expr_stmt [2019,2047]
expr_stmt [2047,2067]
===
match
---
arglist [11325,11414]
arglist [11345,11434]
===
match
---
name: __class__ [6288,6297]
name: __class__ [6308,6317]
===
match
---
trailer [11298,11307]
trailer [11318,11327]
===
match
---
decorator [3915,3929]
decorator [3935,3949]
===
match
---
operator: , [5190,5191]
operator: , [5210,5211]
===
match
---
parameters [12093,12102]
parameters [12113,12122]
===
match
---
string: "Tools info" [10662,10674]
string: "Tools info" [10682,10694]
===
match
---
sync_comp_for [10346,10392]
sync_comp_for [10366,10412]
===
match
---
number: 1 [5828,5829]
number: 1 [5848,5849]
===
match
---
string: "plain" [10895,10902]
string: "plain" [10915,10922]
===
match
---
suite [2869,2910]
suite [2889,2930]
===
match
---
operator: , [3002,3003]
operator: , [3022,3023]
===
match
---
operator: , [8535,8536]
operator: , [8555,8556]
===
match
---
trailer [6884,6979]
trailer [6904,6999]
===
match
---
string: "logging" [7223,7232]
string: "logging" [7243,7252]
===
match
---
atom [9365,9409]
atom [9385,9429]
===
match
---
name: username [3184,3192]
name: username [3204,3212]
===
match
---
operator: { [11139,11140]
operator: { [11159,11160]
===
match
---
operator: , [11631,11632]
operator: , [11651,11652]
===
match
---
operator: + [3549,3550]
operator: + [3569,3570]
===
match
---
name: show [11613,11617]
name: show [11633,11637]
===
match
---
dictorsetmaker [11332,11368]
dictorsetmaker [11352,11388]
===
match
---
suite [5744,5804]
suite [5764,5824]
===
match
---
name: Optional [3954,3962]
name: Optional [3974,3982]
===
match
---
name: tenacity [11812,11820]
name: tenacity [11832,11840]
===
match
---
operator: , [11353,11354]
operator: , [11373,11374]
===
match
---
simple_stmt [6550,6573]
simple_stmt [6570,6593]
===
match
---
number: 1 [2465,2466]
number: 1 [2485,2486]
===
match
---
name: username [3407,3415]
name: username [3427,3435]
===
match
---
expr_stmt [8815,8898]
expr_stmt [8835,8918]
===
match
---
name: _get_version [5369,5381]
name: _get_version [5389,5401]
===
match
---
name: print [11037,11042]
name: print [11057,11062]
===
match
---
string: "" [3658,3660]
string: "" [3678,3680]
===
match
---
atom_expr [6898,6969]
atom_expr [6918,6989]
===
match
---
trailer [9673,9684]
trailer [9693,9704]
===
match
---
name: k [11166,11167]
name: k [11186,11187]
===
match
---
atom [7532,7554]
atom [7552,7574]
===
match
---
name: self [10676,10680]
name: self [10696,10700]
===
match
---
atom [8750,8805]
atom [8770,8825]
===
match
---
name: getuser [2038,2045]
name: getuser [2058,2065]
===
match
---
suite [6320,6475]
suite [6340,6495]
===
match
---
operator: , [3713,3714]
operator: , [3733,3734]
===
match
---
name: lower [4604,4609]
name: lower [4624,4629]
===
match
---
suite [13115,13178]
suite [13135,13198]
===
match
---
string: "core" [6921,6927]
string: "core" [6941,6947]
===
match
---
name: get [7383,7386]
name: get [7403,7406]
===
match
---
atom_expr [7364,7449]
atom_expr [7384,7469]
===
match
---
atom_expr [5111,5127]
atom_expr [5131,5147]
===
match
---
name: username [2991,2999]
name: username [3011,3019]
===
match
---
expr_stmt [6988,7131]
expr_stmt [7008,7151]
===
match
---
name: ProvidersManager [10355,10371]
name: ProvidersManager [10375,10391]
===
match
---
operator: , [5158,5159]
operator: , [5178,5179]
===
match
---
suite [6616,7890]
suite [6636,7910]
===
match
---
import_name [826,839]
import_name [811,824]
===
match
---
operator: , [7655,7656]
operator: , [7675,7676]
===
match
---
name: self [6856,6860]
name: self [6876,6880]
===
match
---
atom_expr [2620,2636]
atom_expr [2640,2656]
===
match
---
simple_stmt [6443,6475]
simple_stmt [6463,6495]
===
match
---
name: PPC [4958,4961]
name: PPC [4978,4981]
===
match
---
trailer [10317,10333]
trailer [10337,10353]
===
match
---
name: X86_64 [4670,4676]
name: X86_64 [4690,4696]
===
match
---
comp_if [5722,5726]
comp_if [5742,5746]
===
match
---
name: _task_logging_handler [7598,7619]
name: _task_logging_handler [7618,7639]
===
match
---
string: "x86_64" [4411,4419]
string: "x86_64" [4431,4439]
===
match
---
operator: , [11842,11843]
operator: , [11862,11863]
===
match
---
expr_stmt [9654,9731]
expr_stmt [9674,9751]
===
match
---
trailer [5186,5190]
trailer [5206,5210]
===
match
---
simple_stmt [8245,8547]
simple_stmt [8265,8567]
===
match
---
classdef [5196,11687]
classdef [5216,11707]
===
match
---
atom_expr [9832,9863]
atom_expr [9852,9883]
===
match
---
argument [11633,11648]
argument [11653,11668]
===
match
---
atom_expr [9669,9731]
atom_expr [9689,9751]
===
match
---
name: __class__ [6133,6142]
name: __class__ [6153,6162]
===
match
---
name: username [2699,2707]
name: username [2719,2727]
===
match
---
atom_expr [2056,2079]
atom_expr [2076,2099]
===
match
---
trailer [9836,9847]
trailer [9856,9867]
===
match
---
atom_expr [11912,11961]
atom_expr [11932,11981]
===
match
---
string: "@" [3379,3382]
string: "@" [3399,3402]
===
match
---
funcdef [6021,6307]
funcdef [6041,6327]
===
match
---
simple_stmt [991,1007]
simple_stmt [976,992]
===
match
---
trailer [7987,7989]
trailer [8007,8009]
===
match
---
arith_expr [2439,2467]
arith_expr [2459,2487]
===
match
---
trailer [5060,5064]
trailer [5080,5084]
===
match
---
name: Architecture [4945,4957]
name: Architecture [4965,4977]
===
match
---
string: "executor" [7533,7543]
string: "executor" [7553,7563]
===
match
---
import_name [1007,1022]
import_name [992,1007]
===
match
---
name: resp [12267,12271]
name: resp [12287,12291]
===
match
---
simple_stmt [4615,5194]
simple_stmt [4635,5214]
===
match
---
name: password [3368,3376]
name: password [3388,3396]
===
match
---
operator: = [8730,8731]
operator: = [8750,8751]
===
match
---
atom_expr [4556,4612]
atom_expr [4576,4632]
===
match
---
operator: = [7958,7959]
operator: = [7978,7979]
===
match
---
suite [3425,3473]
suite [3445,3493]
===
match
---
atom_expr [13147,13176]
atom_expr [13167,13196]
===
match
---
trailer [2775,2782]
trailer [2795,2802]
===
match
---
name: system_path [9796,9807]
name: system_path [9816,9827]
===
match
---
suite [2637,3661]
suite [2657,3681]
===
match
---
operator: , [12047,12048]
operator: , [12067,12068]
===
match
---
arglist [11807,12064]
arglist [11827,12084]
===
match
---
trailer [13057,13059]
trailer [13077,13079]
===
match
---
trailer [9920,9927]
trailer [9940,9947]
===
match
---
name: urlsplit [969,977]
name: urlsplit [954,962]
===
match
---
param [2363,2368]
param [2383,2388]
===
match
---
name: p [9868,9869]
name: p [9888,9889]
===
match
---
arith_expr [3534,3561]
arith_expr [3554,3581]
===
match
---
simple_stmt [12435,12448]
simple_stmt [12455,12468]
===
match
---
simple_stmt [5636,5671]
simple_stmt [5656,5691]
===
match
---
name: airflow_on_path [10210,10225]
name: airflow_on_path [10230,10245]
===
match
---
name: AirflowConsole [1095,1109]
name: AirflowConsole [1080,1094]
===
match
---
name: airflow_version [7502,7517]
name: airflow_version [7522,7537]
===
match
---
atom [9325,9351]
atom [9345,9371]
===
match
---
string: """Do nothing.""" [1696,1713]
string: """Do nothing.""" [1724,1741]
===
match
---
trailer [5818,5824]
trailer [5838,5844]
===
match
---
trailer [9627,9633]
trailer [9647,9653]
===
match
---
string: "airflow_on_path" [10187,10204]
string: "airflow_on_path" [10207,10224]
===
match
---
operator: = [11889,11890]
operator: = [11909,11910]
===
match
---
testlist_comp [10069,10112]
testlist_comp [10089,10132]
===
match
---
simple_stmt [9059,9121]
simple_stmt [9079,9141]
===
match
---
atom_expr [5387,5396]
atom_expr [5407,5416]
===
match
---
name: LINUX [3850,3855]
name: LINUX [3870,3875]
===
match
---
name: conf [6650,6654]
name: conf [6670,6674]
===
match
---
fstring_start: f" [11043,11045]
fstring_start: f" [11063,11065]
===
match
---
if_stmt [2170,2209]
if_stmt [2190,2229]
===
match
---
name: urlunsplit [979,989]
name: urlunsplit [964,974]
===
match
---
operator: = [3013,3014]
operator: = [3033,3034]
===
match
---
trailer [11341,11349]
trailer [11361,11369]
===
match
---
simple_stmt [10003,10239]
simple_stmt [10023,10259]
===
match
---
expr_stmt [4440,4451]
expr_stmt [4460,4471]
===
match
---
operator: + [3383,3384]
operator: + [3403,3404]
===
match
---
operator: + [3377,3378]
operator: + [3397,3398]
===
match
---
operator: , [7396,7397]
operator: , [7416,7417]
===
match
---
name: Architecture [5048,5060]
name: Architecture [5068,5080]
===
match
---
string: "powerpc" [4934,4943]
string: "powerpc" [4954,4963]
===
match
---
operator: , [5396,5397]
operator: , [5416,5417]
===
match
---
name: value [1762,1767]
name: value [1790,1795]
===
match
---
name: self [1960,1964]
name: self [1988,1992]
===
match
---
trailer [9759,9770]
trailer [9779,9790]
===
match
---
name: utils [1221,1226]
name: utils [1206,1211]
===
match
---
operator: , [8771,8772]
operator: , [8791,8792]
===
match
---
name: pathsep [9637,9644]
name: pathsep [9657,9664]
===
match
---
atom [9831,9882]
atom [9851,9902]
===
match
---
name: self [9832,9836]
name: self [9852,9856]
===
match
---
name: print [12729,12734]
name: print [12749,12754]
===
match
---
string: "" [9624,9626]
string: "" [9644,9646]
===
match
---
name: wait_exponential [11862,11878]
name: wait_exponential [11882,11898]
===
match
---
name: items [11391,11396]
name: items [11411,11416]
===
match
---
name: urlunsplit [3677,3687]
name: urlunsplit [3697,3707]
===
match
---
funcdef [11434,11687]
funcdef [11454,11707]
===
match
---
name: locale [8083,8089]
name: locale [8103,8109]
===
match
---
name: _MACHINE_TO_ARCHITECTURE [4615,4639]
name: _MACHINE_TO_ARCHITECTURE [4635,4659]
===
match
---
expr_stmt [3601,3614]
expr_stmt [3621,3634]
===
match
---
simple_stmt [8117,8180]
simple_stmt [8137,8200]
===
match
---
atom_expr [10768,10788]
atom_expr [10788,10808]
===
match
---
operator: = [11137,11138]
operator: = [11157,11158]
===
match
---
name: k [11147,11148]
name: k [11167,11168]
===
match
---
suite [5830,5866]
suite [5850,5886]
===
match
---
name: value [2289,2294]
name: value [2309,2314]
===
match
---
name: password [3307,3315]
name: password [3327,3335]
===
match
---
name: X86 [4774,4777]
name: X86 [4794,4797]
===
match
---
name: fallback [6798,6806]
name: fallback [6818,6826]
===
match
---
name: self [7005,7009]
name: self [7025,7029]
===
match
---
name: get [9612,9615]
name: get [9632,9635]
===
match
---
name: password [3540,3548]
name: password [3560,3568]
===
match
---
operator: , [12207,12208]
operator: , [12227,12228]
===
match
---
parameters [12551,12557]
parameters [12571,12577]
===
match
---
parameters [1732,1745]
parameters [1760,1773]
===
match
---
simple_stmt [1264,1319]
simple_stmt [1292,1347]
===
match
---
trailer [9161,9184]
trailer [9181,9204]
===
match
---
name: property [7896,7904]
name: property [7916,7924]
===
match
---
trailer [9633,9645]
trailer [9653,9665]
===
match
---
operator: , [10985,10986]
operator: , [11005,11006]
===
match
---
operator: = [9075,9076]
operator: = [9095,9096]
===
match
---
atom_expr [12633,12666]
atom_expr [12653,12686]
===
match
---
return_stmt [5843,5865]
return_stmt [5863,5885]
===
match
---
trailer [10303,10317]
trailer [10323,10337]
===
match
---
name: PiiAnonymizer [12988,13001]
name: PiiAnonymizer [13008,13021]
===
match
---
atom_expr [12267,12278]
atom_expr [12287,12298]
===
match
---
atom_expr [10302,10333]
atom_expr [10322,10353]
===
match
---
name: netloc [3601,3607]
name: netloc [3621,3627]
===
match
---
trailer [6132,6142]
trailer [6152,6162]
===
match
---
comp_if [5787,5802]
comp_if [5807,5822]
===
match
---
name: console [11665,11672]
name: console [11685,11692]
===
match
---
expr_stmt [2886,2909]
expr_stmt [2906,2929]
===
match
---
simple_stmt [11291,11429]
simple_stmt [11311,11449]
===
match
---
comparison [6101,6115]
comparison [6121,6135]
===
match
---
name: __init__ [1951,1959]
name: __init__ [1979,1987]
===
match
---
atom_expr [12656,12665]
atom_expr [12676,12685]
===
match
---
simple_stmt [3850,3866]
simple_stmt [3870,3886]
===
match
---
trailer [10444,10460]
trailer [10464,10480]
===
match
---
trailer [13029,13037]
trailer [13049,13057]
===
match
---
testlist_comp [7491,7517]
testlist_comp [7511,7537]
===
match
---
name: _ [3001,3002]
name: _ [3021,3022]
===
match
---
funcdef [10258,10394]
funcdef [10278,10414]
===
match
---
operator: -> [10469,10471]
operator: -> [10489,10491]
===
match
---
operator: , [9311,9312]
operator: , [9331,9332]
===
match
---
name: p [9784,9785]
name: p [9804,9805]
===
match
---
name: self [7322,7326]
name: self [7342,7346]
===
match
---
string: "key" [11140,11145]
string: "key" [11160,11165]
===
match
---
suite [5428,5916]
suite [5448,5936]
===
match
---
argument [11083,11098]
argument [11103,11118]
===
match
---
atom_expr [12779,12793]
atom_expr [12799,12813]
===
match
---
atom_expr [6387,6429]
atom_expr [6407,6449]
===
match
---
operator: , [7422,7423]
operator: , [7442,7443]
===
match
---
name: PIPE [5537,5541]
name: PIPE [5557,5561]
===
match
---
operator: = [5495,5496]
operator: = [5515,5516]
===
match
---
operator: , [9409,9410]
operator: , [9429,9430]
===
match
---
simple_stmt [2886,2910]
simple_stmt [2906,2930]
===
match
---
suite [11595,11650]
suite [11615,11670]
===
match
---
comparison [10875,10903]
comparison [10895,10923]
===
match
---
string: "https://file.io" [12190,12207]
string: "https://file.io" [12210,12227]
===
match
---
trailer [4603,4609]
trailer [4623,4629]
===
match
---
name: process_url [2477,2488]
name: process_url [2497,2508]
===
match
---
simple_stmt [5437,5465]
simple_stmt [5457,5485]
===
match
---
name: operating_system [8273,8289]
name: operating_system [8293,8309]
===
match
---
atom [9754,9808]
atom [9774,9828]
===
match
---
name: FileIoException [12294,12309]
name: FileIoException [12314,12329]
===
match
---
operator: = [4640,4641]
operator: = [4660,4661]
===
match
---
operator: , [2306,2307]
operator: , [2326,2327]
===
match
---
atom_expr [10143,10171]
atom_expr [10163,10191]
===
match
---
operator: , [4866,4867]
operator: , [4886,4887]
===
match
---
atom_expr [6350,6371]
atom_expr [6370,6391]
===
match
---
name: items [2260,2265]
name: items [2280,2285]
===
match
---
name: netloc [3342,3348]
name: netloc [3362,3368]
===
match
---
tfpdef [10414,10425]
tfpdef [10434,10445]
===
match
---
trailer [5317,5328]
trailer [5337,5348]
===
match
---
operator: = [3608,3609]
operator: = [3628,3629]
===
match
---
name: output [10414,10420]
name: output [10434,10440]
===
match
---
atom [9162,9183]
atom [9182,9203]
===
match
---
name: self [10768,10772]
name: self [10788,10792]
===
match
---
simple_stmt [1755,1768]
simple_stmt [1783,1796]
===
match
---
name: link [12715,12719]
name: link [12735,12739]
===
match
---
operator: , [7076,7077]
operator: , [7096,7097]
===
match
---
name: uname [8057,8062]
name: uname [8077,8082]
===
match
---
name: _get_version [8678,8690]
name: _get_version [8698,8710]
===
match
---
testlist_comp [9215,9526]
testlist_comp [9235,9546]
===
match
---
name: _airflow_info [6596,6609]
name: _airflow_info [6616,6629]
===
match
---
name: fragment [3758,3766]
name: fragment [3778,3786]
===
match
---
name: url_parts [2559,2568]
name: url_parts [2579,2588]
===
match
---
testlist_comp [9096,9118]
testlist_comp [9116,9138]
===
match
---
operator: , [5096,5097]
operator: , [5116,5117]
===
match
---
trailer [12184,12189]
trailer [12204,12209]
===
match
---
simple_stmt [11116,11196]
simple_stmt [11136,11216]
===
match
---
operator: = [11973,11974]
operator: = [11993,11994]
===
match
---
trailer [10724,10736]
trailer [10744,10756]
===
match
---
name: username [3081,3089]
name: username [3101,3109]
===
match
---
parameters [2147,2160]
parameters [2167,2180]
===
match
---
string: "airflow" [9952,9961]
string: "airflow" [9972,9981]
===
match
---
simple_stmt [2595,2609]
simple_stmt [2615,2629]
===
match
---
suite [11209,11429]
suite [11229,11449]
===
match
---
atom [7476,7889]
atom [7496,7909]
===
match
---
name: getdefaultlocale [8090,8106]
name: getdefaultlocale [8110,8126]
===
match
---
name: password [3215,3223]
name: password [3235,3243]
===
match
---
name: tenacity [12025,12033]
name: tenacity [12045,12053]
===
match
---
name: environ [9604,9611]
name: environ [9624,9631]
===
match
---
name: process_username [3154,3170]
name: process_username [3174,3190]
===
match
---
atom [9283,9311]
atom [9303,9331]
===
match
---
atom [8378,8399]
atom [8398,8419]
===
match
---
name: data [5899,5903]
name: data [5919,5923]
===
match
---
argument [9913,9992]
argument [9933,10012]
===
match
---
atom_expr [9009,9050]
atom_expr [9029,9070]
===
match
---
suite [2376,2468]
suite [2396,2488]
===
match
---
name: value [1607,1612]
name: value [1635,1640]
===
match
---
atom_expr [2893,2909]
atom_expr [2913,2929]
===
match
---
name: AirflowInfo [13071,13082]
name: AirflowInfo [13091,13102]
===
match
---
name: stop_after_attempt [11821,11839]
name: stop_after_attempt [11841,11859]
===
match
---
simple_stmt [8073,8109]
simple_stmt [8093,8129]
===
match
---
operator: = [1786,1787]
operator: = [1814,1815]
===
match
---
name: WINDOWS [4075,4082]
name: WINDOWS [4095,4102]
===
match
---
funcdef [5365,5916]
funcdef [5385,5936]
===
match
---
return_stmt [4549,4612]
return_stmt [4569,4632]
===
match
---
trailer [6769,6823]
trailer [6789,6843]
===
match
---
operator: , [9334,9335]
operator: , [9354,9355]
===
match
---
param [1437,1442]
param [1465,1470]
===
match
---
atom [10300,10393]
atom [10320,10413]
===
match
---
parameters [10277,10283]
parameters [10297,10303]
===
match
---
atom_expr [2571,2586]
atom_expr [2591,2606]
===
match
---
string: "--version" [8971,8982]
string: "--version" [8991,9002]
===
match
---
name: airflow [1170,1177]
name: airflow [1155,1162]
===
match
---
param [1520,1525]
param [1548,1553]
===
match
---
simple_stmt [3670,3769]
simple_stmt [3690,3789]
===
match
---
operator: , [9269,9270]
operator: , [9289,9290]
===
match
---
sync_comp_for [9964,9992]
sync_comp_for [9984,10012]
===
match
---
number: 0 [5904,5905]
number: 0 [5924,5925]
===
match
---
trailer [13163,13176]
trailer [13183,13196]
===
match
---
trailer [11920,11944]
trailer [11940,11964]
===
match
---
atom_expr [6129,6153]
atom_expr [6149,6173]
===
match
---
name: PiiAnonymizer [1858,1871]
name: PiiAnonymizer [1886,1899]
===
match
---
parameters [10407,10468]
parameters [10427,10488]
===
match
---
atom [5764,5803]
atom [5784,5823]
===
match
---
argument [7253,7277]
argument [7273,7297]
===
match
---
name: subprocess [5526,5536]
name: subprocess [5546,5556]
===
match
---
return_stmt [11658,11686]
return_stmt [11678,11706]
===
match
---
param [2495,2500]
param [2515,2520]
===
match
---
operator: , [9105,9106]
operator: , [9125,9126]
===
match
---
trailer [10099,10112]
trailer [10119,10132]
===
match
---
atom [4642,5193]
atom [4662,5213]
===
match
---
string: "NOT AVAILABLE" [6953,6968]
string: "NOT AVAILABLE" [6973,6988]
===
match
---
dotted_name [949,961]
dotted_name [934,946]
===
match
---
simple_stmt [4133,4162]
simple_stmt [4153,4182]
===
match
---
name: ex [12767,12769]
name: ex [12787,12789]
===
match
---
trailer [10390,10392]
trailer [10410,10412]
===
match
---
classdef [3771,4344]
classdef [3791,4364]
===
match
---
operator: = [11811,11812]
operator: = [11831,11832]
===
match
---
simple_stmt [5313,5342]
simple_stmt [5333,5362]
===
match
---
atom_expr [9928,9962]
atom_expr [9948,9982]
===
match
---
name: os [4023,4025]
name: os [4043,4045]
===
match
---
raise_stmt [12456,12522]
raise_stmt [12476,12542]
===
match
---
operator: = [5329,5330]
operator: = [5349,5350]
===
match
---
name: configuration [6898,6911]
name: configuration [6918,6931]
===
match
---
string: " " [8231,8234]
string: " " [8251,8254]
===
match
---
expr_stmt [3850,3865]
expr_stmt [3870,3885]
===
match
---
name: configuration [7200,7213]
name: configuration [7220,7233]
===
match
---
suite [12770,12794]
suite [12790,12814]
===
match
---
name: username [2105,2113]
name: username [2125,2133]
===
match
---
simple_stmt [2699,2715]
simple_stmt [2719,2735]
===
match
---
name: module [6101,6107]
name: module [6121,6127]
===
match
---
atom_expr [11291,11428]
atom_expr [11311,11448]
===
match
---
trailer [8736,8749]
trailer [8756,8769]
===
match
---
or_test [8273,8308]
or_test [8293,8328]
===
match
---
dotted_name [1115,1140]
dotted_name [1100,1125]
===
match
---
name: value [2544,2549]
name: value [2564,2569]
===
match
---
operator: , [6665,6666]
operator: , [6685,6686]
===
match
---
name: userinfo [3092,3100]
name: userinfo [3112,3120]
===
match
---
operator: , [8309,8310]
operator: , [8329,8330]
===
match
---
name: pathsep [10087,10094]
name: pathsep [10107,10114]
===
match
---
name: post [12185,12189]
name: post [12205,12209]
===
match
---
argument [7424,7448]
argument [7444,7468]
===
match
---
operator: = [3899,3900]
operator: = [3919,3920]
===
match
---
trailer [2463,2467]
trailer [2483,2487]
===
match
---
operator: , [8399,8400]
operator: , [8419,8420]
===
match
---
argument [10845,10862]
argument [10865,10882]
===
match
---
trailer [1343,1353]
trailer [1371,1381]
===
match
---
atom_expr [2289,2315]
atom_expr [2309,2335]
===
match
---
parameters [9571,9577]
parameters [9591,9597]
===
match
---
name: console [10427,10434]
name: console [10447,10454]
===
match
---
import_from [944,989]
import_from [929,974]
===
match
---
name: str [8424,8427]
name: str [8444,8447]
===
match
---
if_stmt [13099,13219]
if_stmt [13119,13239]
===
match
---
dictorsetmaker [10566,10789]
dictorsetmaker [10586,10809]
===
match
---
trailer [11684,11686]
trailer [11704,11706]
===
match
---
simple_stmt [2800,2852]
simple_stmt [2820,2872]
===
match
---
atom_expr [4850,4866]
atom_expr [4870,4886]
===
match
---
operator: = [2891,2892]
operator: = [2911,2912]
===
match
---
atom [10127,10172]
atom [10147,10192]
===
match
---
parameters [4506,4508]
parameters [4526,4528]
===
match
---
simple_stmt [10541,10800]
simple_stmt [10561,10820]
===
match
---
operator: = [7003,7004]
operator: = [7023,7024]
===
match
---
name: netloc [2776,2782]
name: netloc [2796,2802]
===
match
---
trailer [2902,2909]
trailer [2922,2929]
===
match
---
trailer [6287,6297]
trailer [6307,6317]
===
match
---
name: self [5286,5290]
name: self [5306,5310]
===
match
---
name: Architecture [5080,5092]
name: Architecture [5100,5112]
===
match
---
name: os [9913,9915]
name: os [9933,9935]
===
match
---
import_name [899,909]
import_name [884,894]
===
match
---
name: process_path [7338,7350]
name: process_path [7358,7370]
===
match
---
trailer [13205,13218]
trailer [13225,13238]
===
match
---
name: self [10278,10282]
name: self [10298,10302]
===
match
---
name: print [12261,12266]
name: print [12281,12286]
===
match
---
name: _task_logging_handler [5943,5964]
name: _task_logging_handler [5963,5984]
===
match
---
trailer [13151,13163]
trailer [13171,13183]
===
match
---
expr_stmt [8907,8984]
expr_stmt [8927,9004]
===
match
---
name: AirflowConsole [11536,11550]
name: AirflowConsole [11556,11570]
===
match
---
name: provider_info [10304,10317]
name: provider_info [10324,10337]
===
match
---
tfpdef [5398,5419]
tfpdef [5418,5439]
===
match
---
trailer [4998,5002]
trailer [5018,5022]
===
match
---
string: ":" [3034,3037]
string: ":" [3054,3057]
===
match
---
trailer [6297,6306]
trailer [6317,6326]
===
match
---
simple_stmt [1630,1656]
simple_stmt [1658,1684]
===
match
---
atom_expr [13007,13021]
atom_expr [13027,13041]
===
match
---
simple_stmt [8040,8065]
simple_stmt [8060,8085]
===
match
---
testlist_comp [6350,6429]
testlist_comp [6370,6449]
===
match
---
trailer [9081,9094]
trailer [9101,9114]
===
match
---
name: self [10631,10635]
name: self [10651,10655]
===
match
---
operator: + [3466,3467]
operator: + [3486,3487]
===
match
---
trailer [4773,4777]
trailer [4793,4797]
===
match
---
simple_stmt [3138,3203]
simple_stmt [3158,3223]
===
match
---
trailer [5391,5396]
trailer [5411,5416]
===
match
---
operator: , [2367,2368]
operator: , [2387,2388]
===
match
---
name: get [6766,6769]
name: get [6786,6789]
===
match
---
trailer [2444,2447]
trailer [2464,2467]
===
match
---
trailer [6074,6085]
trailer [6094,6105]
===
match
---
operator: = [9667,9668]
operator: = [9687,9688]
===
match
---
name: _system_info [10636,10648]
name: _system_info [10656,10668]
===
match
---
name: get [6917,6920]
name: get [6937,6940]
===
match
---
operator: , [7554,7555]
operator: , [7574,7575]
===
match
---
suite [12363,12399]
suite [12383,12419]
===
match
---
atom_expr [5174,5190]
atom_expr [5194,5210]
===
match
---
name: handler_names [6333,6346]
name: handler_names [6353,6366]
===
match
---
operator: { [11331,11332]
operator: { [11351,11352]
===
match
---
name: MACOSX [4236,4242]
name: MACOSX [4256,4262]
===
match
---
atom_expr [12379,12398]
atom_expr [12399,12418]
===
match
---
simple_stmt [9194,9537]
simple_stmt [9214,9557]
===
match
---
name: value [2331,2336]
name: value [2351,2356]
===
match
---
number: 0 [2445,2446]
number: 0 [2465,2466]
===
match
---
expr_stmt [6054,6085]
expr_stmt [6074,6105]
===
match
---
name: configuration [1044,1057]
name: configuration [1029,1042]
===
match
---
name: json [12384,12388]
name: json [12404,12408]
===
match
---
name: ValueError [12410,12420]
name: ValueError [12430,12440]
===
match
---
name: userinfo [3015,3023]
name: userinfo [3035,3043]
===
match
---
trailer [8950,8984]
trailer [8970,9004]
===
match
---
trailer [12271,12276]
trailer [12291,12296]
===
match
---
name: self [2363,2367]
name: self [2383,2387]
===
match
---
string: """Renders information about Airflow instance""" [5219,5267]
string: """Renders information about Airflow instance""" [5239,5287]
===
match
---
name: _paths_info [9560,9571]
name: _paths_info [9580,9591]
===
match
---
string: "core" [6659,6665]
string: "core" [6679,6685]
===
match
---
name: value [1739,1744]
name: value [1767,1772]
===
match
---
string: "Linux" [3858,3865]
string: "Linux" [3878,3885]
===
match
---
trailer [6654,6658]
trailer [6674,6678]
===
match
---
operator: , [8271,8272]
operator: , [8291,8292]
===
match
---
return_stmt [6550,6572]
return_stmt [6570,6592]
===
match
---
name: ARM [4456,4459]
name: ARM [4476,4479]
===
match
---
operator: = [7104,7105]
operator: = [7124,7125]
===
match
---
suite [5214,11687]
suite [5234,11707]
===
match
---
atom_expr [9601,9645]
atom_expr [9621,9665]
===
match
---
parameters [1436,1449]
parameters [1464,1477]
===
match
---
simple_stmt [881,899]
simple_stmt [866,884]
===
match
---
atom_expr [4761,4777]
atom_expr [4781,4797]
===
match
---
trailer [8167,8178]
trailer [8187,8198]
===
match
---
name: _identity [1840,1849]
name: _identity [1868,1877]
===
match
---
name: netloc [2630,2636]
name: netloc [2650,2656]
===
match
---
simple_stmt [5605,5628]
simple_stmt [5625,5648]
===
match
---
atom_expr [10084,10112]
atom_expr [10104,10132]
===
match
---
trailer [10371,10373]
trailer [10391,10393]
===
match
---
name: os [862,864]
name: os [847,849]
===
match
---
name: host [3385,3389]
name: host [3405,3409]
===
match
---
suite [1966,2126]
suite [1994,2146]
===
match
---
simple_stmt [9740,9809]
simple_stmt [9760,9829]
===
match
---
operator: , [10227,10228]
operator: , [10247,10248]
===
match
---
arglist [11043,11098]
arglist [11063,11118]
===
match
---
name: X86 [4863,4866]
name: X86 [4883,4886]
===
match
---
name: __module__ [6075,6085]
name: __module__ [6095,6105]
===
match
---
operator: , [7251,7252]
operator: , [7271,7272]
===
match
---
name: locale [833,839]
name: locale [818,824]
===
match
---
trailer [6658,6678]
trailer [6678,6698]
===
match
---
arglist [11133,11194]
arglist [11153,11214]
===
match
---
simple_stmt [4456,4468]
simple_stmt [4476,4488]
===
match
---
name: netloc [3442,3448]
name: netloc [3462,3468]
===
match
---
name: anonymizer [12975,12985]
name: anonymizer [12995,13005]
===
match
---
string: "x86" [4430,4435]
string: "x86" [4450,4455]
===
match
---
name: str [1617,1620]
name: str [1645,1648]
===
match
---
name: tenacity [11787,11795]
name: tenacity [11807,11815]
===
match
---
atom [9423,9447]
atom [9443,9467]
===
match
---
simple_stmt [8659,8706]
simple_stmt [8679,8726]
===
match
---
classdef [1356,1656]
classdef [1384,1684]
===
match
---
operator: = [12986,12987]
operator: = [13006,13007]
===
match
---
name: self [9669,9673]
name: self [9689,9693]
===
match
---
expr_stmt [6842,6979]
expr_stmt [6862,6999]
===
match
---
trailer [7386,7449]
trailer [7406,7469]
===
match
---
parameters [1519,1532]
parameters [1547,1560]
===
match
---
trailer [6920,6969]
trailer [6940,6989]
===
match
---
testlist_comp [7533,7553]
testlist_comp [7553,7573]
===
match
---
trailer [7619,7621]
trailer [7639,7641]
===
match
---
operator: = [4460,4461]
operator: = [4480,4481]
===
match
---
name: p [9861,9862]
name: p [9881,9882]
===
match
---
operator: = [10817,10818]
operator: = [10837,10838]
===
match
---
trailer [13001,13003]
trailer [13021,13023]
===
match
---
name: git_version [8597,8608]
name: git_version [8617,8628]
===
match
---
string: "armv6" [5039,5046]
string: "armv6" [5059,5066]
===
match
---
trailer [6860,6871]
trailer [6880,6891]
===
match
---
suite [3793,4344]
suite [3813,4364]
===
match
---
trailer [9770,9783]
trailer [9790,9803]
===
match
---
name: system_path [9587,9598]
name: system_path [9607,9618]
===
match
---
name: export_text [11673,11684]
name: export_text [11693,11704]
===
match
---
atom [6349,6430]
atom [6369,6450]
===
match
---
name: all_info [10995,11003]
name: all_info [11015,11023]
===
match
---
atom_expr [9913,9963]
atom_expr [9933,9983]
===
match
---
simple_stmt [1975,2011]
simple_stmt [2003,2039]
===
match
---
expr_stmt [3826,3845]
expr_stmt [3846,3865]
===
match
---
name: anonymizer [7163,7173]
name: anonymizer [7183,7193]
===
match
---
string: "NOT AVAILABLE" [7262,7277]
string: "NOT AVAILABLE" [7282,7297]
===
match
---
trailer [11592,11594]
trailer [11612,11614]
===
match
---
trailer [6760,6765]
trailer [6780,6785]
===
match
---
operator: @ [10244,10245]
operator: @ [10264,10265]
===
match
---
string: "python_version" [8452,8468]
string: "python_version" [8472,8488]
===
match
---
name: path [1990,1994]
name: path [2018,2022]
===
match
---
atom_expr [11974,12013]
atom_expr [11994,12033]
===
match
---
simple_stmt [6842,6980]
simple_stmt [6862,7000]
===
match
---
sync_comp_for [11370,11398]
sync_comp_for [11390,11418]
===
match
---
atom_expr [3149,3180]
atom_expr [3169,3200]
===
match
---
atom [10068,10113]
atom [10088,10133]
===
match
---
trailer [8427,8436]
trailer [8447,8456]
===
match
---
name: stdoutdata [5636,5646]
name: stdoutdata [5656,5666]
===
match
---
operator: , [5290,5291]
operator: , [5310,5311]
===
match
---
trailer [8677,8690]
trailer [8697,8710]
===
match
---
name: typing [915,921]
name: typing [900,906]
===
match
---
string: "plugins_folder" [7078,7094]
string: "plugins_folder" [7098,7114]
===
match
---
atom_expr [5526,5541]
atom_expr [5546,5561]
===
match
---
name: urllib [949,955]
name: urllib [934,940]
===
match
---
name: self [8611,8615]
name: self [8631,8635]
===
match
---
name: PPC [4440,4443]
name: PPC [4460,4463]
===
match
---
return_stmt [1755,1767]
return_stmt [1783,1795]
===
match
---
name: line [5798,5802]
name: line [5818,5822]
===
match
---
try_stmt [12359,12523]
try_stmt [12379,12543]
===
match
---
name: path_elem [9968,9977]
name: path_elem [9988,9997]
===
match
---
param [12552,12556]
param [12572,12576]
===
match
---
simple_stmt [1466,1494]
simple_stmt [1494,1522]
===
match
---
expr_stmt [6625,6678]
expr_stmt [6645,6698]
===
match
---
testlist_comp [8851,8870]
testlist_comp [8871,8890]
===
match
---
trailer [6420,6429]
trailer [6440,6449]
===
match
---
operator: @ [7895,7896]
operator: @ [7915,7916]
===
match
---
name: airflow [1115,1122]
name: airflow [1100,1107]
===
match
---
string: "@" [2759,2762]
string: "@" [2779,2782]
===
match
---
arglist [9616,9626]
arglist [9636,9646]
===
match
---
suite [10904,11196]
suite [10924,11216]
===
match
---
expr_stmt [3081,3100]
expr_stmt [3101,3120]
===
match
---
operator: = [11896,11897]
operator: = [11916,11917]
===
match
---
name: DEBUG [12057,12062]
name: DEBUG [12077,12082]
===
match
---
name: _locale [8073,8080]
name: _locale [8093,8100]
===
match
---
testlist_comp [8414,8436]
testlist_comp [8434,8456]
===
match
---
name: show_header [10845,10856]
name: show_header [10865,10876]
===
match
---
name: replace [11342,11349]
name: replace [11362,11369]
===
match
---
operator: , [8422,8423]
operator: , [8442,8443]
===
match
---
name: Architecture [5142,5154]
name: Architecture [5162,5174]
===
match
---
funcdef [2131,2337]
funcdef [2151,2357]
===
match
---
simple_stmt [944,990]
simple_stmt [929,975]
===
match
---
name: data [5679,5683]
name: data [5699,5703]
===
match
---
name: get_fullname [6350,6362]
name: get_fullname [6370,6382]
===
match
---
trailer [7218,7222]
trailer [7238,7242]
===
match
---
trailer [4155,4161]
trailer [4175,4181]
===
match
---
expr_stmt [8073,8108]
expr_stmt [8093,8128]
===
match
---
trailer [7975,7987]
trailer [7995,8007]
===
match
---
trailer [3757,3766]
trailer [3777,3786]
===
match
---
suite [1884,3769]
suite [1912,3789]
===
match
---
name: info [13196,13200]
name: info [13216,13220]
===
match
---
name: gcloud_version [8815,8829]
name: gcloud_version [8835,8849]
===
match
---
testlist_comp [9504,9524]
testlist_comp [9524,9544]
===
match
---
string: "@" [2847,2850]
string: "@" [2867,2870]
===
match
---
if_stmt [12237,12355]
if_stmt [12257,12375]
===
match
---
testlist_comp [8952,8982]
testlist_comp [8972,9002]
===
match
---
trailer [12309,12354]
trailer [12329,12374]
===
match
---
comparison [5790,5802]
comparison [5810,5822]
===
match
---
name: file_io [13107,13114]
name: file_io [13127,13134]
===
match
---
atom_expr [9634,9644]
atom_expr [9654,9664]
===
match
---
name: remote_base_log_folder [7297,7319]
name: remote_base_log_folder [7317,7339]
===
match
---
return_stmt [2324,2336]
return_stmt [2344,2356]
===
match
---
trailer [9728,9730]
trailer [9748,9750]
===
match
---
name: output [11625,11631]
name: output [11645,11651]
===
match
---
operator: } [2124,2125]
operator: } [2144,2145]
===
match
---
name: getLogger [6395,6404]
name: getLogger [6415,6424]
===
match
---
string: "amd64" [4648,4655]
string: "amd64" [4668,4675]
===
match
---
name: path [3725,3729]
name: path [3745,3749]
===
match
---
simple_stmt [8714,8807]
simple_stmt [8734,8827]
===
match
---
simple_stmt [12779,12794]
simple_stmt [12799,12814]
===
match
---
trailer [1333,1343]
trailer [1361,1371]
===
match
---
sync_comp_for [9864,9881]
sync_comp_for [9884,9901]
===
match
---
trailer [4669,4676]
trailer [4689,4696]
===
match
---
atom_expr [4728,4747]
atom_expr [4748,4767]
===
match
---
simple_stmt [910,944]
simple_stmt [895,929]
===
match
---
suite [3632,3661]
suite [3652,3681]
===
match
---
trailer [2259,2265]
trailer [2279,2285]
===
match
---
expr_stmt [3870,3887]
expr_stmt [3890,3907]
===
match
---
atom_expr [4187,4199]
atom_expr [4207,4219]
===
match
---
name: OperatingSystem [4220,4235]
name: OperatingSystem [4240,4255]
===
match
---
atom_expr [12049,12062]
atom_expr [12069,12082]
===
match
---
exprlist [2221,2232]
exprlist [2241,2252]
===
match
---
atom [9027,9049]
atom [9047,9069]
===
match
---
name: netloc [3707,3713]
name: netloc [3727,3733]
===
match
---
name: len [5815,5818]
name: len [5835,5838]
===
match
---
tfpdef [10427,10460]
tfpdef [10447,10480]
===
match
---
name: username [3171,3179]
name: username [3191,3199]
===
match
---
name: Exception [6490,6499]
name: Exception [6510,6519]
===
match
---
argument [11848,11900]
argument [11868,11920]
===
match
---
name: get_airflow_home [9712,9728]
name: get_airflow_home [9732,9748]
===
match
---
import_name [855,864]
import_name [840,849]
===
match
---
atom_expr [4692,4711]
atom_expr [4712,4731]
===
match
---
name: anonymizer [9837,9847]
name: anonymizer [9857,9867]
===
match
---
operator: , [6776,6777]
operator: , [6796,6797]
===
match
---
name: _paths_info [10725,10736]
name: _paths_info [10745,10756]
===
match
---
testlist_comp [10301,10392]
testlist_comp [10321,10412]
===
match
---
expr_stmt [2056,2125]
expr_stmt [2076,2145]
===
match
---
atom_expr [11608,11649]
atom_expr [11628,11669]
===
match
---
name: url_parts [3748,3757]
name: url_parts [3768,3777]
===
match
---
trailer [5412,5419]
trailer [5432,5439]
===
match
---
param [10278,10282]
param [10298,10302]
===
match
---
operator: , [4836,4837]
operator: , [4856,4857]
===
match
---
name: target [2226,2232]
name: target [2246,2252]
===
match
---
arglist [12190,12231]
arglist [12210,12251]
===
match
---
operator: = [11624,11625]
operator: = [11644,11645]
===
match
---
operator: , [10172,10173]
operator: , [10192,10193]
===
match
---
trailer [8139,8150]
trailer [8159,8170]
===
match
---
name: console [11029,11036]
name: console [11049,11056]
===
match
---
operator: , [4807,4808]
operator: , [4827,4828]
===
match
---
param [1443,1448]
param [1471,1476]
===
match
---
simple_stmt [826,840]
simple_stmt [811,825]
===
match
---
name: split [9628,9633]
name: split [9648,9653]
===
match
---
simple_stmt [4332,4344]
simple_stmt [4352,4364]
===
match
---
name: get_current [8018,8029]
name: get_current [8038,8049]
===
match
---
name: self [11608,11612]
name: self [11628,11632]
===
match
---
funcdef [1719,1768]
funcdef [1747,1796]
===
match
---
name: _providers_info [10262,10277]
name: _providers_info [10282,10297]
===
match
---
atom [9215,9235]
atom [9235,9255]
===
match
---
name: exists [9921,9927]
name: exists [9941,9947]
===
match
---
name: airflow [1269,1276]
name: airflow [1297,1304]
===
match
---
simple_stmt [8993,9051]
simple_stmt [9013,9071]
===
match
---
name: show [10403,10407]
name: show [10423,10427]
===
match
---
operator: , [11081,11082]
operator: , [11101,11102]
===
match
---
operator: = [11852,11853]
operator: = [11872,11873]
===
match
---
simple_stmt [840,855]
simple_stmt [825,840]
===
match
---
funcdef [8566,9537]
funcdef [8586,9557]
===
match
---
operator: = [5549,5550]
operator: = [5569,5570]
===
match
---
operator: = [1819,1820]
operator: = [1847,1848]
===
match
---
funcdef [1420,1494]
funcdef [1448,1522]
===
match
---
comparison [6119,6153]
comparison [6139,6173]
===
match
---
name: self [8582,8586]
name: self [8602,8606]
===
match
---
name: value [2495,2500]
name: value [2515,2520]
===
match
---
operator: , [9431,9432]
operator: , [9451,9452]
===
match
---
operator: , [8871,8872]
operator: , [8891,8892]
===
match
---
string: "locale" [8414,8422]
string: "locale" [8434,8442]
===
match
---
name: _identity [1821,1830]
name: _identity [1849,1858]
===
match
---
atom [3688,3767]
atom [3708,3787]
===
match
---
name: get [4581,4584]
name: get [4601,4604]
===
match
---
string: """Remove personally identifiable info from path.""" [1889,1941]
string: """Remove personally identifiable info from path.""" [1917,1969]
===
match
---
name: base_log_folder [7140,7155]
name: base_log_folder [7160,7175]
===
match
---
name: path [9877,9881]
name: path [9897,9901]
===
match
---
string: "PASSWORD" [3226,3236]
string: "PASSWORD" [3246,3256]
===
match
---
name: p [10302,10303]
name: p [10322,10323]
===
match
---
trailer [8224,8235]
trailer [8244,8255]
===
match
---
operator: , [8485,8486]
operator: , [8505,8506]
===
match
---
name: cli [1071,1074]
name: cli [1056,1059]
===
match
---
simple_stmt [5490,5569]
simple_stmt [5510,5589]
===
match
---
string: "sqlite3" [9096,9105]
string: "sqlite3" [9116,9125]
===
match
---
operator: = [12631,12632]
operator: = [12651,12652]
===
match
---
operator: = [6061,6062]
operator: = [6081,6082]
===
match
---
name: password [3240,3248]
name: password [3260,3268]
===
match
---
name: retry [11796,11801]
name: retry [11816,11821]
===
match
---
trailer [3023,3033]
trailer [3043,3053]
===
match
---
trailer [9026,9050]
trailer [9046,9070]
===
match
---
name: os [10084,10086]
name: os [10104,10106]
===
match
---
string: "--version" [9171,9182]
string: "--version" [9191,9202]
===
match
---
atom_expr [6706,6833]
atom_expr [6726,6853]
===
match
---
decorated [6578,7890]
decorated [6598,7910]
===
match
---
name: sql_alchemy_conn [6687,6703]
name: sql_alchemy_conn [6707,6723]
===
match
---
expr_stmt [7140,7288]
expr_stmt [7160,7308]
===
match
---
name: requests [998,1006]
name: requests [983,991]
===
match
---
fstring_expr [11060,11065]
fstring_expr [11080,11085]
===
match
---
operator: , [8760,8761]
operator: , [8780,8781]
===
match
---
name: info [12660,12664]
name: info [12680,12684]
===
match
---
sync_comp_for [11162,11178]
sync_comp_for [11182,11198]
===
match
---
trailer [2060,2079]
trailer [2080,2099]
===
match
---
name: self [3149,3153]
name: self [3169,3173]
===
match
---
name: anonymizer [7327,7337]
name: anonymizer [7347,7357]
===
match
---
fstring_string: [/bold][/green] [11065,11080]
fstring_string: [/bold][/green] [11085,11100]
===
match
---
name: self [6706,6710]
name: self [6726,6730]
===
match
---
operator: , [8635,8636]
operator: , [8655,8656]
===
match
---
trailer [9148,9161]
trailer [9168,9181]
===
match
---
name: version [1277,1284]
name: version [1305,1312]
===
match
---
name: f [5725,5726]
name: f [5745,5746]
===
match
---
operator: == [4031,4033]
operator: == [4051,4053]
===
match
---
name: airflow [1063,1070]
name: airflow [1048,1055]
===
match
---
name: self [9755,9759]
name: self [9775,9779]
===
match
---
name: X86_64 [4705,4711]
name: X86_64 [4725,4731]
===
match
---
name: before [11967,11973]
name: before [11987,11993]
===
match
---
decorator [9542,9552]
decorator [9562,9572]
===
match
---
trailer [10086,10094]
trailer [10106,10114]
===
match
---
trailer [10680,10692]
trailer [10700,10712]
===
match
---
name: arch [7998,8002]
name: arch [8018,8022]
===
match
---
name: mysql_version [9433,9446]
name: mysql_version [9453,9466]
===
match
---
name: staticmethod [4474,4486]
name: staticmethod [4494,4506]
===
match
---
testlist_comp [7637,7673]
testlist_comp [7657,7693]
===
match
---
trailer [9711,9728]
trailer [9731,9748]
===
match
---
atom_expr [2030,2047]
atom_expr [2058,2067]
===
match
---
operator: -> [1450,1452]
operator: -> [1478,1480]
===
match
---
operator: = [7320,7321]
operator: = [7340,7341]
===
match
---
trailer [7060,7065]
trailer [7080,7085]
===
match
---
simple_stmt [6264,6307]
simple_stmt [6284,6327]
===
match
---
expr_stmt [8040,8064]
expr_stmt [8060,8084]
===
match
---
name: Architecture [5111,5123]
name: Architecture [5131,5143]
===
match
---
atom_expr [4107,4119]
atom_expr [4127,4139]
===
match
---
comparison [2954,2969]
comparison [2974,2989]
===
match
---
name: print_as [11299,11307]
name: print_as [11319,11327]
===
match
---
string: "NOT AVAILABLE" [8348,8363]
string: "NOT AVAILABLE" [8368,8383]
===
match
---
simple_stmt [10809,10864]
simple_stmt [10829,10884]
===
match
---
name: netloc [2903,2909]
name: netloc [2923,2929]
===
match
---
string: "Cygwin" [3901,3909]
string: "Cygwin" [3921,3929]
===
match
---
expr_stmt [11526,11563]
expr_stmt [11546,11583]
===
match
---
trailer [9847,9860]
trailer [9867,9880]
===
match
---
simple_stmt [3977,4012]
simple_stmt [3997,4032]
===
match
---
trailer [3740,3746]
trailer [3760,3766]
===
match
---
trailer [12189,12232]
trailer [12209,12252]
===
match
---
name: content [12094,12101]
name: content [12114,12121]
===
match
---
atom_expr [12294,12354]
atom_expr [12314,12374]
===
match
---
string: "dags_folder" [6929,6942]
string: "dags_folder" [6949,6962]
===
insert-tree
---
simple_stmt [785,811]
    string: """Config sub-commands""" [785,810]
to
file_input [785,13219]
at 0
===
insert-tree
---
simple_stmt [1249,1292]
    import_from [1249,1291]
        dotted_name [1254,1276]
            name: airflow [1254,1261]
            name: utils [1262,1267]
            name: platform [1268,1276]
        name: getuser [1284,1291]
to
file_input [785,13219]
at 18
===
move-tree
---
name: getuser [2038,2045]
to
atom_expr [2030,2047]
at 0
===
delete-tree
---
simple_stmt [785,811]
    string: """Config sub-commands""" [785,810]
===
delete-tree
---
simple_stmt [811,826]
    import_name [811,825]
        name: getpass [818,825]
===
delete-node
---
name: getpass [2030,2037]
===
===
delete-node
---
trailer [2037,2045]
===
