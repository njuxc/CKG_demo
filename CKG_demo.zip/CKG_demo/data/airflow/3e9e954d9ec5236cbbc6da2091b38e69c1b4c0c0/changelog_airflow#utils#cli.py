===
match
---
name: setup_locations [8027,8042]
name: setup_locations [8013,8028]
===
match
---
simple_stmt [9927,9950]
simple_stmt [9913,9936]
===
match
---
param [8088,8096]
param [8074,8082]
===
match
---
simple_stmt [8158,8229]
simple_stmt [8144,8215]
===
match
---
simple_stmt [9890,9923]
simple_stmt [9876,9909]
===
match
---
trailer [3987,3992]
trailer [3981,3986]
===
match
---
name: T [10388,10389]
name: T [10374,10375]
===
match
---
name: AUTO [10072,10076]
name: AUTO [10058,10062]
===
match
---
simple_stmt [5694,5768]
simple_stmt [5680,5754]
===
match
---
trailer [1528,1550]
trailer [1522,1544]
===
match
---
simple_stmt [1602,1733]
simple_stmt [1596,1727]
===
match
---
dictorsetmaker [9453,9502]
dictorsetmaker [9439,9488]
===
match
---
atom_expr [7273,7303]
atom_expr [7259,7289]
===
match
---
number: 0 [1717,1718]
number: 0 [1711,1712]
===
match
---
fstring_expr [9906,9920]
fstring_expr [9892,9906]
===
match
---
operator: = [8068,8069]
operator: = [8054,8055]
===
match
---
not_test [7204,7217]
not_test [7190,7203]
===
match
---
arglist [10622,10637]
arglist [10608,10623]
===
match
---
fstring_start: f" [9633,9635]
fstring_start: f" [9619,9621]
===
match
---
name: TYPE_CHECKING [1408,1421]
name: TYPE_CHECKING [1402,1415]
===
match
---
name: matched_dags [7308,7320]
name: matched_dags [7294,7306]
===
match
---
name: dag [7324,7327]
name: dag [7310,7313]
===
match
---
operator: , [1087,1088]
operator: , [1072,1073]
===
match
---
name: f [2611,2612]
name: f [2605,2606]
===
match
---
suite [4516,4658]
suite [4510,4652]
===
match
---
trailer [5277,5333]
trailer [5263,5319]
===
match
---
operator: { [9808,9809]
operator: { [9794,9795]
===
match
---
trailer [3129,3146]
trailer [3123,3140]
===
match
---
operator: , [7059,7060]
operator: , [7045,7046]
===
match
---
name: metrics [4663,4670]
name: metrics [4657,4664]
===
match
---
operator: = [7090,7091]
operator: = [7076,7077]
===
match
---
number: 8 [4335,4336]
number: 8 [4329,4330]
===
match
---
name: format [6500,6506]
name: format [6486,6492]
===
match
---
simple_stmt [11056,11081]
simple_stmt [11042,11067]
===
match
---
operator: , [4795,4796]
operator: , [4789,4790]
===
match
---
name: Optional [7046,7054]
name: Optional [7032,7040]
===
match
---
name: th [9475,9477]
name: th [9461,9463]
===
match
---
name: models [1440,1446]
name: models [1434,1440]
===
match
---
trailer [9932,9949]
trailer [9918,9935]
===
match
---
string: 'dag_id' [5062,5070]
string: 'dag_id' [5048,5056]
===
match
---
operator: == [10219,10221]
operator: == [10205,10207]
===
match
---
name: full_command [4607,4619]
name: full_command [4601,4613]
===
match
---
atom_expr [1343,1371]
atom_expr [1337,1365]
===
match
---
name: DagBag [7189,7195]
name: DagBag [7175,7181]
===
match
---
trailer [10573,10579]
trailer [10559,10565]
===
match
---
name: warnings [965,973]
name: warnings [950,958]
===
match
---
comparison [4001,4041]
comparison [3995,4035]
===
match
---
name: subdir [5775,5781]
name: subdir [5761,5767]
===
match
---
simple_stmt [10056,10068]
simple_stmt [10042,10054]
===
match
---
name: _wrapper [10523,10531]
name: _wrapper [10509,10517]
===
match
---
simple_stmt [7968,7999]
simple_stmt [7954,7985]
===
match
---
name: metrics [5148,5155]
name: metrics [5134,5141]
===
match
---
operator: -> [1760,1762]
operator: -> [1754,1756]
===
match
---
operator: , [5440,5441]
operator: , [5426,5427]
===
match
---
name: thread_id [9663,9672]
name: thread_id [9649,9658]
===
match
---
trailer [6779,6787]
trailer [6765,6773]
===
match
---
name: subdir [6024,6030]
name: subdir [6010,6016]
===
match
---
argument [10845,10853]
argument [10831,10839]
===
match
---
name: stream [8943,8949]
name: stream [8929,8935]
===
match
---
operator: = [7682,7683]
operator: = [7668,7669]
===
match
---
trailer [5525,5529]
trailer [5511,5515]
===
match
---
simple_stmt [10713,10745]
simple_stmt [10699,10731]
===
match
---
trailer [5934,5971]
trailer [5920,5957]
===
match
---
dotted_name [6715,6729]
dotted_name [6701,6715]
===
match
---
string: "DAGS_FOLDER variable in settings should be filled." [5849,5901]
string: "DAGS_FOLDER variable in settings should be filled." [5835,5887]
===
match
---
name: pickle_id [7664,7673]
name: pickle_id [7650,7659]
===
match
---
trailer [10734,10744]
trailer [10720,10730]
===
match
---
name: DAGS_FOLDER [5807,5818]
name: DAGS_FOLDER [5793,5804]
===
match
---
name: cast [1098,1102]
name: cast [1083,1087]
===
match
---
param [1480,1484]
param [1474,1478]
===
match
---
param [8971,8975]
param [8957,8961]
===
match
---
name: Namespace [4872,4881]
name: Namespace [4858,4867]
===
match
---
import_name [852,863]
import_name [837,848]
===
match
---
if_stmt [8135,8229]
if_stmt [8121,8215]
===
match
---
parameters [8042,8097]
parameters [8028,8083]
===
match
---
suite [9612,9923]
suite [9598,9909]
===
match
---
string: 'host_name' [5218,5229]
string: 'host_name' [5204,5215]
===
match
---
trailer [8277,8326]
trailer [8263,8312]
===
match
---
name: dag_id [7373,7379]
name: dag_id [7359,7365]
===
match
---
name: str [5683,5686]
name: str [5669,5672]
===
match
---
simple_stmt [8562,8594]
simple_stmt [8548,8580]
===
match
---
trailer [3265,3281]
trailer [3259,3275]
===
match
---
operator: , [3925,3926]
operator: , [3919,3920]
===
match
---
simple_stmt [6100,6164]
simple_stmt [6086,6150]
===
match
---
name: stack [9537,9542]
name: stack [9523,9528]
===
match
---
operator: { [1706,1707]
operator: { [1700,1701]
===
match
---
import_name [889,898]
import_name [874,883]
===
match
---
trailer [1716,1719]
trailer [1710,1713]
===
match
---
trailer [5529,5539]
trailer [5515,5525]
===
match
---
atom_expr [3979,3993]
atom_expr [3973,3987]
===
match
---
simple_stmt [5259,5334]
simple_stmt [5245,5320]
===
match
---
param [7675,7687]
param [7661,7673]
===
match
---
trailer [9625,9632]
trailer [9611,9618]
===
match
---
name: pid [8052,8055]
name: pid [8038,8041]
===
match
---
parameters [1753,1759]
parameters [1747,1753]
===
match
---
string: 'task_id' [5108,5117]
string: 'task_id' [5094,5103]
===
match
---
arglist [8278,8325]
arglist [8264,8311]
===
match
---
atom_expr [4001,4016]
atom_expr [3995,4010]
===
match
---
name: owner [5419,5424]
name: owner [5405,5410]
===
match
---
atom_expr [6370,6524]
atom_expr [6356,6510]
===
match
---
if_stmt [8331,8419]
if_stmt [8317,8405]
===
match
---
name: logging [871,878]
name: logging [856,863]
===
match
---
name: line [9735,9739]
name: line [9721,9725]
===
match
---
parameters [3411,3433]
parameters [3405,3427]
===
match
---
simple_stmt [8820,8852]
simple_stmt [8806,8838]
===
match
---
expr_stmt [7789,7868]
expr_stmt [7775,7854]
===
match
---
fstring_end: ' [8509,8510]
fstring_end: ' [8495,8496]
===
match
---
fstring [1697,1722]
fstring [1691,1716]
===
match
---
argument [5471,5501]
argument [5457,5487]
===
match
---
expr_stmt [5100,5143]
expr_stmt [5086,5129]
===
match
---
atom_expr [11019,11050]
atom_expr [11005,11036]
===
match
---
operator: , [8572,8573]
operator: , [8558,8559]
===
match
---
name: setFormatter [8828,8840]
name: setFormatter [8814,8826]
===
match
---
operator: ** [3085,3087]
operator: ** [3079,3081]
===
match
---
funcdef [1735,3391]
funcdef [1729,3385]
===
match
---
trailer [9490,9500]
trailer [9476,9486]
===
match
---
simple_stmt [10620,10639]
simple_stmt [10606,10625]
===
match
---
return_stmt [3367,3390]
return_stmt [3361,3384]
===
match
---
string: "auto" [10079,10085]
string: "auto" [10065,10071]
===
match
---
operator: = [3870,3871]
operator: = [3864,3865]
===
match
---
name: dag_pickle [7981,7991]
name: dag_pickle [7967,7977]
===
match
---
trailer [3378,3390]
trailer [3372,3384]
===
match
---
atom_expr [5920,5971]
atom_expr [5906,5957]
===
match
---
trailer [3197,3206]
trailer [3191,3200]
===
match
---
fstring_start: f' [4778,4780]
fstring_start: f' [4772,4774]
===
match
---
simple_stmt [6831,6992]
simple_stmt [6817,6978]
===
match
---
expr_stmt [5024,5049]
expr_stmt [5010,5035]
===
match
---
name: DagBag [6737,6743]
name: DagBag [6723,6729]
===
match
---
trailer [7384,7391]
trailer [7370,7377]
===
match
---
name: sys [3984,3987]
name: sys [3978,3981]
===
match
---
trailer [8827,8840]
trailer [8813,8826]
===
match
---
name: Log [3839,3842]
name: Log [3833,3836]
===
match
---
name: func_name [4698,4707]
name: func_name [4692,4701]
===
match
---
not_test [5794,5818]
not_test [5780,5804]
===
match
---
name: OFF [10056,10059]
name: OFF [10042,10045]
===
match
---
name: ColorMode [9958,9967]
name: ColorMode [9944,9953]
===
match
---
operator: = [7321,7322]
operator: = [7307,7308]
===
match
---
param [10539,10547]
param [10525,10533]
===
match
---
trailer [10598,10606]
trailer [10584,10592]
===
match
---
trailer [8174,8179]
trailer [8160,8165]
===
match
---
simple_stmt [941,958]
simple_stmt [926,943]
===
match
---
name: threading [931,940]
name: threading [916,925]
===
match
---
atom_expr [7906,7963]
atom_expr [7892,7949]
===
match
---
name: airflow [3817,3824]
name: airflow [3811,3818]
===
match
---
name: _check_cli_args [1464,1479]
name: _check_cli_args [1458,1473]
===
match
---
classdef [9952,10086]
classdef [9938,10072]
===
match
---
trailer [8840,8851]
trailer [8826,8837]
===
match
---
atom_expr [9787,9852]
atom_expr [9773,9838]
===
match
---
fstring_string: \n# Thread:  [9635,9647]
fstring_string: \n# Thread:  [9621,9633]
===
match
---
suite [4181,4337]
suite [4175,4331]
===
match
---
fstring_expr [8403,8412]
fstring_expr [8389,8398]
===
match
---
name: airflow [1186,1193]
name: airflow [1171,1178]
===
match
---
atom_expr [6837,6991]
atom_expr [6823,6977]
===
match
---
operator: = [6756,6757]
operator: = [6742,6743]
===
match
---
trailer [8871,8880]
trailer [8857,8866]
===
match
---
atom_expr [3984,3992]
atom_expr [3978,3986]
===
match
---
dictorsetmaker [3873,3895]
dictorsetmaker [3867,3889]
===
match
---
simple_stmt [10042,10052]
simple_stmt [10028,10038]
===
match
---
name: dag_id [7385,7391]
name: dag_id [7371,7377]
===
match
---
string: 'task_id' [5491,5500]
string: 'task_id' [5477,5486]
===
match
---
atom_expr [8820,8851]
atom_expr [8806,8837]
===
match
---
trailer [8898,8922]
trailer [8884,8908]
===
match
---
funcdef [1460,1733]
funcdef [1454,1727]
===
match
---
name: ValueError [5838,5848]
name: ValueError [5824,5834]
===
match
---
trailer [4743,4750]
trailer [4737,4744]
===
match
---
simple_stmt [4892,5020]
simple_stmt [4878,5006]
===
match
---
atom_expr [5148,5173]
atom_expr [5134,5159]
===
match
---
atom_expr [8935,8949]
atom_expr [8921,8935]
===
match
---
suite [6095,6606]
suite [6081,6592]
===
match
---
name: models [6723,6729]
name: models [6709,6715]
===
match
---
operator: = [6299,6300]
operator: = [6285,6286]
===
match
---
atom_expr [5282,5292]
atom_expr [5268,5278]
===
match
---
name: args [10591,10595]
name: args [10577,10581]
===
match
---
simple_stmt [4663,4838]
simple_stmt [4657,4824]
===
match
---
name: path [8268,8272]
name: path [8254,8258]
===
match
---
suite [4137,4658]
suite [4131,4652]
===
match
---
name: ValueError [1608,1618]
name: ValueError [1602,1612]
===
match
---
trailer [6023,6031]
trailer [6009,6017]
===
match
---
trailer [10267,10273]
trailer [10253,10259]
===
match
---
atom_expr [7280,7302]
atom_expr [7266,7288]
===
match
---
atom_expr [6586,6605]
atom_expr [6572,6591]
===
match
---
trailer [8860,8871]
trailer [8846,8857]
===
match
---
if_stmt [10205,10256]
if_stmt [10191,10242]
===
match
---
name: session [7675,7682]
name: session [7661,7668]
===
match
---
atom_expr [9907,9919]
atom_expr [9893,9905]
===
match
---
fstring_end: " [9432,9433]
fstring_end: " [9418,9419]
===
match
---
name: _current_frames [9550,9565]
name: _current_frames [9536,9551]
===
match
---
name: DagBag [6195,6201]
name: DagBag [6181,6187]
===
match
---
trailer [4619,4624]
trailer [4613,4618]
===
match
---
string: """     Helps debug deadlocks by printing stacktraces when this gets a SIGQUIT     e.g. kill -s QUIT <PID> or CTRL+\     """ [9238,9362]
string: """     Helps debug deadlocks by printing stacktraces when this gets a SIGQUIT     e.g. kill -s QUIT <PID> or CTRL+\     """ [9224,9348]
===
match
---
name: path [8170,8174]
name: path [8156,8160]
===
match
---
if_stmt [7201,7260]
if_stmt [7187,7246]
===
match
---
name: T [3379,3380]
name: T [3373,3374]
===
match
---
name: subdir [5920,5926]
name: subdir [5906,5912]
===
match
---
name: dag_pickle [7880,7890]
name: dag_pickle [7866,7876]
===
match
---
param [7664,7674]
param [7650,7660]
===
match
---
name: Callable [1362,1370]
name: Callable [1356,1364]
===
match
---
trailer [9917,9919]
trailer [9903,9905]
===
match
---
fstring_expr [9844,9850]
fstring_expr [9830,9836]
===
match
---
fstring_string: = [4578,4579]
fstring_string: = [4572,4573]
===
match
---
return_stmt [3121,3146]
return_stmt [3115,3140]
===
match
---
argument [6545,6573]
argument [6531,6559]
===
match
---
simple_stmt [11019,11051]
simple_stmt [11005,11037]
===
match
---
name: process_subdir [7280,7294]
name: process_subdir [7266,7280]
===
match
---
name: get [5526,5529]
name: get [5512,5515]
===
match
---
trailer [5251,5253]
trailer [5237,5239]
===
match
---
name: matched_dags [7610,7622]
name: matched_dags [7596,7608]
===
match
---
raise_stmt [6364,6524]
raise_stmt [6350,6510]
===
match
---
name: replace [5927,5934]
name: replace [5913,5920]
===
match
---
name: f [3020,3021]
name: f [3014,3015]
===
match
---
name: args [3032,3036]
name: args [3026,3030]
===
match
---
parameters [7037,7098]
parameters [7023,7084]
===
match
---
string: """Returns DAG of a given dag_id""" [6670,6705]
string: """Returns DAG of a given dag_id""" [6656,6691]
===
match
---
trailer [7294,7302]
trailer [7280,7288]
===
match
---
name: code [9508,9512]
name: code [9494,9498]
===
match
---
param [8052,8061]
param [8038,8047]
===
match
---
expr_stmt [8758,8815]
expr_stmt [8744,8801]
===
match
---
simple_stmt [9238,9363]
simple_stmt [9224,9349]
===
match
---
name: join [8365,8369]
name: join [8351,8355]
===
match
---
string: 'parse.' [6958,6966]
string: 'parse.' [6944,6952]
===
match
---
name: filename [9809,9817]
name: filename [9795,9803]
===
match
---
atom_expr [4898,5019]
atom_expr [4884,5005]
===
match
---
name: settings [8899,8907]
name: settings [8885,8893]
===
match
---
tfpdef [6620,6641]
tfpdef [6606,6627]
===
match
---
suite [4883,5020]
suite [4869,5006]
===
match
---
name: metrics [5479,5486]
name: metrics [5465,5472]
===
match
---
param [7074,7097]
param [7060,7083]
===
match
---
simple_stmt [8758,8816]
simple_stmt [8744,8802]
===
match
---
suite [9233,9950]
suite [9219,9936]
===
match
---
trailer [4828,4830]
trailer [4814,4816]
===
match
---
atom_expr [8770,8815]
atom_expr [8756,8801]
===
match
---
name: argv [3988,3992]
name: argv [3982,3986]
===
match
---
trailer [9662,9677]
trailer [9648,9663]
===
match
---
fstring_end: ' [9850,9851]
fstring_end: ' [9836,9837]
===
match
---
name: get_dag [7235,7242]
name: get_dag [7221,7228]
===
match
---
name: subdir [6620,6626]
name: subdir [6606,6612]
===
match
---
expr_stmt [4663,4837]
expr_stmt [4657,4823]
===
match
---
fstring [5363,5381]
fstring [5349,5367]
===
match
---
name: cast [3374,3378]
name: cast [3368,3372]
===
match
---
operator: , [3380,3381]
operator: , [3374,3375]
===
match
---
operator: , [4752,4753]
operator: , [4746,4747]
===
match
---
trailer [3084,3095]
trailer [3078,3089]
===
match
---
atom_expr [3128,3146]
atom_expr [3122,3140]
===
match
---
simple_stmt [8928,8950]
simple_stmt [8914,8936]
===
match
---
name: kwargs [2639,2645]
name: kwargs [2633,2639]
===
match
---
name: os [8265,8267]
name: os [8251,8253]
===
match
---
trailer [3067,3084]
trailer [3061,3078]
===
match
---
fstring_string: .pid [8505,8509]
fstring_string: .pid [8491,8495]
===
match
---
trailer [5848,5902]
trailer [5834,5888]
===
match
---
tfpdef [5666,5687]
tfpdef [5652,5673]
===
match
---
import_from [1288,1337]
import_from [1282,1331]
===
match
---
fstring [8486,8510]
fstring [8472,8496]
===
match
---
name: typing [1040,1046]
name: typing [1025,1031]
===
match
---
name: abspath [5997,6004]
name: abspath [5983,5990]
===
match
---
suite [1765,3391]
suite [1759,3385]
===
match
---
trailer [9766,9773]
trailer [9752,9759]
===
match
---
operator: , [8073,8074]
operator: , [8059,8060]
===
match
---
suite [4354,4658]
suite [4348,4652]
===
match
---
operator: { [9844,9845]
operator: { [9830,9831]
===
match
---
name: line [9907,9911]
name: line [9893,9897]
===
match
---
trailer [9567,9573]
trailer [9553,9559]
===
match
---
atom_expr [10222,10234]
atom_expr [10208,10220]
===
match
---
name: Namespace [995,1004]
name: Namespace [980,989]
===
match
---
trailer [9632,9693]
trailer [9618,9679]
===
match
---
simple_stmt [9023,9148]
simple_stmt [9009,9134]
===
match
---
fstring_end: ' [4579,4580]
fstring_end: ' [4573,4574]
===
match
---
name: use_regex [7074,7083]
name: use_regex [7060,7069]
===
match
---
name: DagModel [6301,6309]
name: DagModel [6287,6295]
===
match
---
name: frame [9191,9196]
name: frame [9177,9182]
===
match
---
import_from [7747,7783]
import_from [7733,7769]
===
match
---
trailer [8369,8418]
trailer [8355,8404]
===
match
---
atom_expr [3020,3030]
atom_expr [3014,3024]
===
match
---
import_from [1104,1132]
import_from [1089,1117]
===
match
---
name: process [8404,8411]
name: process [8390,8397]
===
match
---
fstring_expr [1706,1721]
fstring_expr [1700,1715]
===
match
---
trailer [5128,5132]
trailer [5114,5118]
===
match
---
expr_stmt [10056,10067]
expr_stmt [10042,10053]
===
match
---
trailer [9901,9922]
trailer [9887,9908]
===
match
---
name: dags [6817,6821]
name: dags [6803,6807]
===
match
---
atom [3872,3896]
atom [3866,3890]
===
match
---
fstring_string: .log [8412,8416]
fstring_string: .log [8398,8402]
===
match
---
name: datetime [4735,4743]
name: datetime [4729,4737]
===
match
---
fstring_expr [8311,8320]
fstring_expr [8297,8306]
===
match
---
name: root [8885,8889]
name: root [8871,8875]
===
match
---
trailer [9455,9461]
trailer [9441,9447]
===
match
---
if_stmt [10260,10313]
if_stmt [10246,10299]
===
match
---
name: line_number [9716,9727]
name: line_number [9702,9713]
===
match
---
name: name [9845,9849]
name: name [9831,9835]
===
match
---
operator: = [3207,3208]
operator: = [3201,3202]
===
match
---
dotted_name [1432,1446]
dotted_name [1426,1440]
===
match
---
name: task_instance [5391,5404]
name: task_instance [5377,5390]
===
match
---
trailer [6386,6524]
trailer [6372,6510]
===
match
---
name: full_command [4781,4793]
name: full_command [4775,4787]
===
match
---
trailer [9752,9766]
trailer [9738,9752]
===
match
---
argument [5391,5409]
argument [5377,5395]
===
match
---
parameters [9185,9197]
parameters [9171,9183]
===
match
---
fstring_string: .err [8222,8226]
fstring_string: .err [8208,8212]
===
match
---
parameters [6081,6094]
parameters [6067,6080]
===
match
---
operator: , [3880,3881]
operator: , [3874,3875]
===
match
---
fstring_end: ' [8416,8417]
fstring_end: ' [8402,8403]
===
match
---
expr_stmt [5259,5333]
expr_stmt [5245,5319]
===
match
---
name: stderr [8142,8148]
name: stderr [8128,8134]
===
match
---
name: thread_id [9680,9689]
name: thread_id [9666,9675]
===
match
---
expr_stmt [4607,4657]
expr_stmt [4601,4651]
===
match
---
comp_if [7360,7392]
comp_if [7346,7378]
===
match
---
string: 'execution_date' [5576,5592]
string: 'execution_date' [5562,5578]
===
match
---
trailer [6816,6821]
trailer [6802,6807]
===
match
---
param [8075,8087]
param [8061,8073]
===
match
---
string: "\n" [9933,9937]
string: "\n" [9919,9923]
===
match
---
string: 'task_id' [5133,5142]
string: 'task_id' [5119,5128]
===
match
---
name: args [1480,1484]
name: args [1474,1478]
===
match
---
operator: , [6641,6642]
operator: , [6627,6628]
===
match
---
trailer [9155,9160]
trailer [9141,9146]
===
match
---
import_from [1005,1034]
import_from [990,1019]
===
match
---
atom_expr [1712,1719]
atom_expr [1706,1713]
===
match
---
simple_stmt [7603,7623]
simple_stmt [7589,7609]
===
match
---
name: append [9792,9798]
name: append [9778,9784]
===
match
---
not_test [1558,1592]
not_test [1552,1586]
===
match
---
name: settings [8463,8471]
name: settings [8449,8457]
===
match
---
fstring_start: f" [9373,9375]
fstring_start: f" [9359,9361]
===
match
---
fstring [4982,5009]
fstring [4968,4995]
===
match
---
return_stmt [8928,8949]
return_stmt [8914,8935]
===
match
---
name: airflow [6715,6722]
name: airflow [6701,6708]
===
match
---
suite [4582,4658]
suite [4576,4652]
===
match
---
simple_stmt [8714,8754]
simple_stmt [8700,8740]
===
match
---
operator: , [5461,5462]
operator: , [5447,5448]
===
match
---
name: tmp_dic [5024,5031]
name: tmp_dic [5010,5017]
===
match
---
fstring [8301,8325]
fstring [8287,8311]
===
match
---
argument [3085,3094]
argument [3079,3088]
===
match
---
name: kwargs [10631,10637]
name: kwargs [10617,10623]
===
match
---
name: setup_logging [8600,8613]
name: setup_logging [8586,8599]
===
match
---
trailer [8942,8949]
trailer [8928,8935]
===
match
---
operator: == [7847,7849]
operator: == [7833,7835]
===
match
---
atom_expr [7834,7846]
atom_expr [7820,7832]
===
match
---
fstring_end: " [9920,9921]
fstring_end: " [9906,9907]
===
match
---
suite [3245,3362]
suite [3239,3356]
===
match
---
arglist [11068,11079]
arglist [11054,11065]
===
match
---
name: extract_stack [9753,9766]
name: extract_stack [9739,9752]
===
match
---
atom_expr [5054,5071]
atom_expr [5040,5057]
===
match
---
expr_stmt [1339,1371]
expr_stmt [1333,1365]
===
match
---
operator: { [9679,9680]
operator: { [9665,9666]
===
match
---
try_stmt [3104,3362]
try_stmt [3098,3356]
===
match
---
operator: } [9431,9432]
operator: } [9417,9418]
===
match
---
arglist [7243,7257]
arglist [7229,7243]
===
match
---
operator: { [8311,8312]
operator: { [8297,8298]
===
match
---
raise_stmt [6831,6991]
raise_stmt [6817,6977]
===
match
---
name: dumps [5272,5277]
name: dumps [5258,5263]
===
match
---
name: utils [1194,1199]
name: utils [1179,1184]
===
match
---
simple_stmt [913,924]
simple_stmt [898,909]
===
match
---
simple_stmt [924,941]
simple_stmt [909,926]
===
match
---
name: sensitive_field [4562,4577]
name: sensitive_field [4556,4571]
===
match
---
simple_stmt [9621,9694]
simple_stmt [9607,9680]
===
match
---
simple_stmt [10129,10201]
simple_stmt [10115,10187]
===
match
---
testlist_comp [5303,5330]
testlist_comp [5289,5316]
===
match
---
suite [9774,9923]
suite [9760,9909]
===
match
---
atom_expr [11063,11080]
atom_expr [11049,11066]
===
match
---
arglist [3020,3039]
arglist [3014,3033]
===
match
---
name: DagBag [6758,6764]
name: DagBag [6744,6750]
===
match
---
operator: = [5918,5919]
operator: = [5904,5905]
===
match
---
trailer [5806,5818]
trailer [5792,5804]
===
match
---
atom_expr [7802,7868]
atom_expr [7788,7854]
===
match
---
name: first [7861,7866]
name: first [7847,7852]
===
match
---
comp_op [6803,6809]
comp_op [6789,6795]
===
match
---
string: 'log' [5613,5618]
string: 'log' [5599,5604]
===
match
---
name: str [6090,6093]
name: str [6076,6079]
===
match
---
simple_stmt [879,889]
simple_stmt [864,874]
===
match
---
simple_stmt [3901,3960]
simple_stmt [3895,3954]
===
match
---
fstring_expr [8213,8222]
fstring_expr [8199,8208]
===
match
---
fstring_end: ' [8324,8325]
fstring_end: ' [8310,8311]
===
match
---
fstring_expr [4629,4646]
fstring_expr [4623,4640]
===
match
---
trailer [6966,6973]
trailer [6952,6959]
===
match
---
with_stmt [10665,11051]
with_stmt [10651,11037]
===
match
---
trailer [4013,4016]
trailer [4007,4010]
===
match
---
simple_stmt [9152,9164]
simple_stmt [9138,9150]
===
match
---
file_input [789,11081]
file_input [789,11067]
===
match
---
name: dag_id [5511,5517]
name: dag_id [5497,5503]
===
match
---
name: models [3825,3831]
name: models [3819,3825]
===
match
---
operator: } [9677,9678]
operator: } [9663,9664]
===
match
---
simple_stmt [3367,3391]
simple_stmt [3361,3385]
===
match
---
param [5666,5687]
param [5652,5673]
===
match
---
name: argparse [979,987]
name: argparse [964,972]
===
match
---
trailer [4558,4581]
trailer [4552,4575]
===
match
---
name: isinstance [1562,1572]
name: isinstance [1556,1566]
===
match
---
atom_expr [8899,8921]
atom_expr [8885,8907]
===
match
---
trailer [6007,6012]
trailer [5993,5998]
===
match
---
operator: = [9513,9514]
operator: = [9499,9500]
===
match
---
name: f [3128,3129]
name: f [3122,3123]
===
match
---
trailer [7580,7588]
trailer [7566,7574]
===
match
---
operator: = [1341,1342]
operator: = [1335,1336]
===
match
---
name: metrics [5054,5061]
name: metrics [5040,5047]
===
match
---
name: code [9621,9625]
name: code [9607,9611]
===
match
---
atom_expr [5518,5539]
atom_expr [5504,5525]
===
match
---
simple_stmt [10558,10580]
simple_stmt [10544,10566]
===
match
---
if_stmt [4537,4658]
if_stmt [4531,4652]
===
match
---
name: T [1757,1758]
name: T [1751,1752]
===
match
---
atom_expr [8856,8880]
atom_expr [8842,8866]
===
match
---
dictorsetmaker [5279,5331]
dictorsetmaker [5265,5317]
===
match
---
trailer [1577,1580]
trailer [1571,1574]
===
match
---
name: stdout [8240,8246]
name: stdout [8226,8232]
===
match
---
decorated [2594,3362]
decorated [2588,3356]
===
match
---
atom_expr [9453,9461]
atom_expr [9439,9447]
===
match
---
for_stmt [4476,4658]
for_stmt [4470,4652]
===
match
---
name: session [1307,1314]
name: session [1301,1308]
===
match
---
simple_stmt [9367,9435]
simple_stmt [9353,9421]
===
match
---
operator: { [4991,4992]
operator: { [4977,4978]
===
match
---
string: 'connections' [3882,3895]
string: 'connections' [3876,3889]
===
match
---
name: ON [10232,10234]
name: ON [10218,10220]
===
match
---
name: provide_session [1322,1337]
name: provide_session [1316,1331]
===
match
---
name: pid [8552,8555]
name: pid [8538,8541]
===
match
---
name: datetime [1010,1018]
name: datetime [995,1003]
===
match
---
name: settings [8370,8378]
name: settings [8356,8364]
===
match
---
simple_stmt [1512,1551]
simple_stmt [1506,1545]
===
match
---
import_from [1035,1102]
import_from [1020,1087]
===
match
---
name: path [8360,8364]
name: path [8346,8350]
===
match
---
fstring [4778,4795]
fstring [4772,4789]
===
match
---
trailer [7826,7833]
trailer [7812,7819]
===
match
---
atom_expr [6400,6514]
atom_expr [6386,6500]
===
match
---
trailer [6004,6032]
trailer [5990,6018]
===
match
---
trailer [5926,5934]
trailer [5912,5920]
===
match
---
trailer [10212,10218]
trailer [10198,10204]
===
match
---
atom [9452,9503]
atom [9438,9489]
===
match
---
suite [7218,7260]
suite [7204,7246]
===
match
---
if_stmt [4843,5020]
if_stmt [4829,5006]
===
match
---
trailer [9942,9948]
trailer [9928,9934]
===
match
---
if_stmt [8233,8327]
if_stmt [8219,8313]
===
match
---
number: 0 [9161,9162]
number: 0 [9147,9148]
===
match
---
fstring [9799,9851]
fstring [9785,9837]
===
match
---
name: process_subdir [5651,5665]
name: process_subdir [5637,5651]
===
match
---
simple_stmt [5338,5601]
simple_stmt [5324,5587]
===
match
---
comparison [10263,10290]
comparison [10249,10276]
===
match
---
expr_stmt [7264,7303]
expr_stmt [7250,7289]
===
match
---
name: ON [10042,10044]
name: ON [10028,10030]
===
match
---
operator: { [4673,4674]
operator: { [4667,4668]
===
match
---
operator: } [9849,9850]
operator: } [9835,9836]
===
match
---
import_from [6710,6743]
import_from [6696,6729]
===
match
---
operator: = [5455,5456]
operator: = [5441,5442]
===
match
---
expr_stmt [8351,8418]
expr_stmt [8337,8404]
===
match
---
arglist [8370,8417]
arglist [8356,8403]
===
match
---
trailer [8364,8369]
trailer [8350,8355]
===
match
---
name: print [9367,9372]
name: print [9353,9358]
===
match
---
trailer [6592,6597]
trailer [6578,6583]
===
match
---
atom_expr [5210,5230]
atom_expr [5196,5216]
===
match
---
name: args [1498,1502]
name: args [1492,1496]
===
match
---
atom_expr [1573,1580]
atom_expr [1567,1574]
===
match
---
name: CRITICAL [10785,10793]
name: CRITICAL [10771,10779]
===
match
---
name: formatter [8758,8767]
name: formatter [8744,8753]
===
match
---
if_stmt [1405,1458]
if_stmt [1399,1452]
===
match
---
name: line_number [9827,9838]
name: line_number [9813,9824]
===
match
---
operator: * [4333,4334]
operator: * [4327,4328]
===
match
---
name: idx [4318,4321]
name: idx [4312,4315]
===
match
---
import_name [864,878]
import_name [849,863]
===
match
---
operator: , [9714,9715]
operator: , [9700,9701]
===
match
---
atom_expr [6758,6788]
atom_expr [6744,6774]
===
match
---
operator: = [5404,5405]
operator: = [5390,5391]
===
match
---
atom [7234,7259]
atom [7220,7245]
===
match
---
name: getuser [4821,4828]
name: getuser [4807,4814]
===
match
---
name: subdir [6780,6786]
name: subdir [6766,6772]
===
match
---
name: dag_id [6598,6604]
name: dag_id [6584,6590]
===
match
---
trailer [5239,5251]
trailer [5225,5237]
===
match
---
name: _check_cli_args [10558,10573]
name: _check_cli_args [10544,10559]
===
match
---
operator: } [8411,8412]
operator: } [8397,8398]
===
match
---
name: args [10263,10267]
name: args [10249,10253]
===
match
---
name: tmp_dic [5074,5081]
name: tmp_dic [5060,5067]
===
match
---
name: frame [8976,8981]
name: frame [8962,8967]
===
match
---
name: filter [7827,7833]
name: filter [7813,7819]
===
match
---
suite [8247,8327]
suite [8233,8313]
===
match
---
name: log [5622,5625]
name: log [5608,5611]
===
match
---
operator: } [4655,4656]
operator: } [4649,4650]
===
match
---
name: suppress_logs_and_warning [10359,10384]
name: suppress_logs_and_warning [10345,10370]
===
match
---
trailer [5682,5687]
trailer [5668,5673]
===
match
---
name: str [6651,6654]
name: str [6637,6640]
===
match
---
operator: = [8263,8264]
operator: = [8249,8250]
===
match
---
dotted_name [3817,3831]
dotted_name [3811,3825]
===
match
---
name: DagModel [6203,6211]
name: DagModel [6189,6197]
===
match
---
simple_stmt [4305,4337]
simple_stmt [4299,4331]
===
match
---
operator: , [5593,5594]
operator: , [5579,5580]
===
match
---
trailer [8272,8277]
trailer [8258,8263]
===
match
---
if_stmt [5791,5903]
if_stmt [5777,5889]
===
match
---
atom_expr [10670,10695]
atom_expr [10656,10681]
===
match
---
simple_stmt [5100,5144]
simple_stmt [5086,5130]
===
match
---
fstring [4627,4657]
fstring [4621,4651]
===
match
---
operator: = [5620,5621]
operator: = [5606,5607]
===
match
---
atom_expr [1562,1592]
atom_expr [1556,1586]
===
match
---
atom_expr [5674,5687]
atom_expr [5660,5673]
===
match
---
name: print [9927,9932]
name: print [9913,9918]
===
match
---
import_from [1181,1225]
import_from [1166,1210]
===
match
---
expr_stmt [8444,8511]
expr_stmt [8430,8497]
===
match
---
import_from [6168,6211]
import_from [6154,6197]
===
match
---
name: settings [8278,8286]
name: settings [8264,8272]
===
match
---
fstring_expr [4647,4656]
fstring_expr [4641,4650]
===
match
---
trailer [11026,11034]
trailer [11012,11020]
===
match
---
name: handler [8820,8827]
name: handler [8806,8813]
===
match
---
string: 'error' [3198,3205]
string: 'error' [3192,3199]
===
match
---
name: socket [906,912]
name: socket [891,897]
===
match
---
simple_stmt [899,913]
simple_stmt [884,898]
===
match
---
string: '--conn-password' [3941,3958]
string: '--conn-password' [3935,3952]
===
match
---
simple_stmt [974,1005]
simple_stmt [959,990]
===
match
---
name: getLogger [8698,8707]
name: getLogger [8684,8693]
===
match
---
operator: , [8201,8202]
operator: , [8187,8188]
===
match
---
trailer [1572,1592]
trailer [1566,1586]
===
match
---
fstring_expr [8496,8505]
fstring_expr [8482,8491]
===
match
---
name: _check_cli_args [2965,2980]
name: _check_cli_args [2959,2974]
===
match
---
operator: , [9189,9190]
operator: , [9175,9176]
===
match
---
operator: } [9817,9818]
operator: } [9803,9804]
===
match
---
string: """Creates log file handler for daemon process""" [8629,8678]
string: """Creates log file handler for daemon process""" [8615,8664]
===
match
---
for_stmt [9522,9923]
for_stmt [9508,9909]
===
match
---
return_stmt [8562,8593]
return_stmt [8548,8579]
===
match
---
operator: , [1096,1097]
operator: , [1081,1082]
===
match
---
sync_comp_for [9471,9502]
sync_comp_for [9457,9488]
===
match
---
name: kwargs [10847,10853]
name: kwargs [10833,10839]
===
match
---
name: models [7175,7181]
name: models [7161,7167]
===
match
---
suite [7099,7623]
suite [7085,7609]
===
match
---
trailer [10768,10776]
trailer [10754,10762]
===
match
---
name: dag_id [7581,7587]
name: dag_id [7567,7573]
===
match
---
name: functools [2595,2604]
name: functools [2589,2598]
===
match
---
suite [1593,1733]
suite [1587,1727]
===
match
---
name: code [9890,9894]
name: code [9876,9880]
===
match
---
if_stmt [10588,11051]
if_stmt [10574,11037]
===
match
---
name: _build_metrics [3005,3019]
name: _build_metrics [2999,3013]
===
match
---
argument [3130,3135]
argument [3124,3129]
===
match
---
simple_stmt [7789,7869]
simple_stmt [7775,7855]
===
match
---
trailer [9573,9575]
trailer [9559,9561]
===
match
---
operator: , [8974,8975]
operator: , [8960,8961]
===
match
---
funcdef [8952,9164]
funcdef [8938,9150]
===
match
---
name: args [1573,1577]
name: args [1567,1571]
===
match
---
if_stmt [7873,7964]
if_stmt [7859,7950]
===
match
---
exprlist [9526,9542]
exprlist [9512,9528]
===
match
---
name: log [8088,8091]
name: log [8074,8077]
===
match
---
operator: { [3920,3921]
operator: { [3914,3915]
===
match
---
operator: } [4577,4578]
operator: } [4571,4572]
===
match
---
simple_stmt [7694,7743]
simple_stmt [7680,7729]
===
match
---
trailer [6764,6788]
trailer [6750,6774]
===
match
---
atom_expr [9648,9677]
atom_expr [9634,9663]
===
match
---
simple_stmt [7747,7784]
simple_stmt [7733,7770]
===
match
---
trailer [5347,5600]
trailer [5333,5586]
===
match
---
param [9186,9190]
param [9172,9176]
===
match
---
simple_stmt [2995,3041]
simple_stmt [2989,3035]
===
match
---
name: Optional [6628,6636]
name: Optional [6614,6622]
===
match
---
operator: = [8768,8769]
operator: = [8754,8755]
===
match
---
operator: } [4645,4646]
operator: } [4639,4640]
===
match
---
name: sys [9152,9155]
name: sys [9138,9141]
===
match
---
atom_expr [10591,10606]
atom_expr [10577,10592]
===
match
---
name: process_subdir [6765,6779]
name: process_subdir [6751,6765]
===
match
---
name: get [5184,5187]
name: get [5170,5173]
===
match
---
operator: = [8355,8356]
operator: = [8341,8342]
===
match
---
name: exceptions [1146,1156]
name: exceptions [1131,1141]
===
match
---
operator: , [5948,5949]
operator: , [5934,5935]
===
match
---
trailer [5571,5575]
trailer [5557,5561]
===
match
---
trailer [8378,8391]
trailer [8364,8377]
===
match
---
name: airflow [1109,1116]
name: airflow [1094,1101]
===
match
---
name: idx [4620,4623]
name: idx [4614,4617]
===
match
---
simple_stmt [5911,5972]
simple_stmt [5897,5958]
===
match
---
name: re [896,898]
name: re [881,883]
===
match
---
name: logging [10777,10784]
name: logging [10763,10770]
===
match
---
funcdef [2618,3362]
funcdef [2612,3356]
===
match
---
atom_expr [8536,8556]
atom_expr [8522,8542]
===
match
---
simple_stmt [3190,3211]
simple_stmt [3184,3205]
===
match
---
string: """Creates logging paths""" [8103,8130]
string: """Creates logging paths""" [8089,8116]
===
match
---
suite [4084,4658]
suite [4078,4652]
===
match
---
import_name [941,957]
import_name [926,942]
===
match
---
atom_expr [5176,5205]
atom_expr [5162,5191]
===
match
---
trailer [10286,10290]
trailer [10272,10276]
===
match
---
name: pickle [7992,7998]
name: pickle [7978,7984]
===
match
---
fstring [8393,8417]
fstring [8379,8403]
===
match
---
dictorsetmaker [3921,3958]
dictorsetmaker [3915,3952]
===
match
---
simple_stmt [1133,1181]
simple_stmt [1118,1166]
===
match
---
name: task_id [5471,5478]
name: task_id [5457,5464]
===
match
---
string: 'dag_id could not be found with regex: {}. Either the dag did not exist ' [7463,7536]
string: 'dag_id could not be found with regex: {}. Either the dag did not exist ' [7449,7522]
===
match
---
trailer [7014,7022]
trailer [7000,7008]
===
match
---
trailer [5486,5490]
trailer [5472,5476]
===
match
---
name: dag [7332,7335]
name: dag [7318,7321]
===
match
---
string: "off" [10062,10067]
string: "off" [10048,10053]
===
match
---
trailer [7843,7846]
trailer [7829,7832]
===
match
---
suite [9018,9164]
suite [9004,9150]
===
match
---
fstring_string: = [4646,4647]
fstring_string: = [4640,4641]
===
match
---
name: _wrapper [11071,11079]
name: _wrapper [11057,11065]
===
match
---
name: args [2981,2985]
name: args [2975,2979]
===
match
---
name: abspath [8544,8551]
name: abspath [8530,8537]
===
match
---
simple_stmt [4607,4658]
simple_stmt [4601,4652]
===
match
---
atom_expr [8788,8814]
atom_expr [8774,8800]
===
match
---
name: isinstance [4850,4860]
name: isinstance [4836,4846]
===
match
---
operator: * [10532,10533]
operator: * [10518,10519]
===
match
---
name: simplefilter [10722,10734]
name: simplefilter [10708,10720]
===
match
---
atom_expr [10836,10854]
atom_expr [10822,10840]
===
match
---
name: stdout [8574,8580]
name: stdout [8560,8566]
===
match
---
operator: = [10060,10061]
operator: = [10046,10047]
===
match
---
name: sig [9186,9189]
name: sig [9172,9175]
===
match
---
atom_expr [9621,9693]
atom_expr [9607,9679]
===
match
---
name: addHandler [8861,8871]
name: addHandler [8847,8857]
===
match
---
expr_stmt [5338,5600]
expr_stmt [5324,5586]
===
match
---
strings [6867,6966]
strings [6853,6952]
===
match
---
fstring [4559,4580]
fstring [4553,4574]
===
match
---
string: "*" [4329,4332]
string: "*" [4323,4326]
===
match
---
operator: { [5278,5279]
operator: { [5264,5265]
===
match
---
trailer [4996,5007]
trailer [4982,4993]
===
match
---
operator: = [5517,5518]
operator: = [5503,5504]
===
match
---
string: 'execution_date' [5188,5204]
string: 'execution_date' [5174,5190]
===
match
---
trailer [9937,9942]
trailer [9923,9928]
===
match
---
operator: ** [10539,10541]
operator: ** [10525,10527]
===
match
---
simple_stmt [958,974]
simple_stmt [943,959]
===
match
---
expr_stmt [3190,3210]
expr_stmt [3184,3204]
===
match
---
name: airflow [7752,7759]
name: airflow [7738,7745]
===
match
---
string: """     Builds metrics dict from function args     It assumes that function arguments is from airflow.bin.cli module's function     and has Namespace instance where it optionally contains "dag_id", "task_id",     and "execution_date".      :param func_name: name of function     :param namespace: Namespace instance from argparse     :return: dict with metrics     """ [3439,3807]
string: """     Builds metrics dict from function args     It assumes that function arguments is from airflow.bin.cli module's function     and has Namespace instance where it optionally contains "dag_id", "task_id",     and "execution_date".      :param func_name: name of function     :param namespace: Namespace instance from argparse     :return: dict with metrics     """ [3433,3801]
===
match
---
expr_stmt [3901,3959]
expr_stmt [3895,3953]
===
match
---
raise_stmt [1602,1732]
raise_stmt [1596,1726]
===
match
---
trailer [7365,7372]
trailer [7351,7358]
===
match
---
atom_expr [1518,1550]
atom_expr [1512,1544]
===
match
---
operator: = [9450,9451]
operator: = [9436,9437]
===
match
---
operator: , [9672,9673]
operator: , [9658,9659]
===
match
---
name: catch_warnings [10679,10693]
name: catch_warnings [10665,10679]
===
match
---
strings [6400,6499]
strings [6386,6485]
===
match
---
name: DagPickle [7816,7825]
name: DagPickle [7802,7811]
===
match
---
name: DagPickle [7834,7843]
name: DagPickle [7820,7829]
===
match
---
trailer [9658,9662]
trailer [9644,9648]
===
match
---
raise_stmt [4892,5019]
raise_stmt [4878,5005]
===
match
---
fstring_start: f" [1697,1699]
fstring_start: f" [1691,1693]
===
match
---
number: 8 [4654,4655]
number: 8 [4648,4649]
===
match
---
trailer [5038,5049]
trailer [5024,5035]
===
match
---
simple_stmt [8444,8512]
simple_stmt [8430,8498]
===
match
---
return_stmt [6037,6050]
return_stmt [6023,6036]
===
match
---
operator: , [5409,5410]
operator: , [5395,5396]
===
match
---
name: airflow [1138,1145]
name: airflow [1123,1130]
===
match
---
param [10385,10389]
param [10371,10375]
===
match
---
string: 'DAGS_FOLDER' [5935,5948]
string: 'DAGS_FOLDER' [5921,5934]
===
match
---
name: functools [827,836]
name: functools [827,836]
===
match
---
name: TypeVar [1089,1096]
name: TypeVar [1074,1081]
===
match
---
expr_stmt [3258,3301]
expr_stmt [3252,3295]
===
match
---
argument [5511,5539]
argument [5497,5525]
===
match
---
simple_stmt [6579,6606]
simple_stmt [6565,6592]
===
match
---
name: enumerate [9491,9500]
name: enumerate [9477,9486]
===
match
---
name: namespace [5039,5048]
name: namespace [5025,5034]
===
match
---
trailer [8359,8364]
trailer [8345,8350]
===
match
---
dotted_name [7167,7181]
dotted_name [7153,7167]
===
match
---
operator: = [4671,4672]
operator: = [4665,4666]
===
match
---
trailer [10721,10734]
trailer [10707,10720]
===
match
---
trailer [8697,8707]
trailer [8683,8693]
===
match
---
simple_stmt [1288,1338]
simple_stmt [1282,1332]
===
match
---
fstring_end: " [1721,1722]
fstring_end: " [1715,1716]
===
match
---
atom_expr [6556,6573]
atom_expr [6542,6559]
===
match
---
atom_expr [3314,3361]
atom_expr [3308,3355]
===
match
---
fstring_string: cli_ [5365,5369]
fstring_string: cli_ [5351,5355]
===
match
---
name: filename [9706,9714]
name: filename [9692,9700]
===
match
---
trailer [3036,3039]
trailer [3030,3033]
===
match
---
trailer [10693,10695]
trailer [10679,10681]
===
match
---
operator: , [5501,5502]
operator: , [5487,5488]
===
match
---
name: name [9466,9470]
name: name [9452,9456]
===
match
---
name: warnings [10713,10721]
name: warnings [10699,10707]
===
match
---
comparison [7834,7859]
comparison [7820,7845]
===
match
---
name: subdir [7295,7301]
name: subdir [7281,7287]
===
match
---
name: full_command [4123,4135]
name: full_command [4117,4129]
===
match
---
name: os [8167,8169]
name: os [8153,8155]
===
match
---
name: f [10620,10621]
name: f [10606,10607]
===
match
---
name: dag_id [6507,6513]
name: dag_id [6493,6499]
===
match
---
simple_stmt [3964,3994]
simple_stmt [3958,3988]
===
match
---
if_stmt [8424,8557]
if_stmt [8410,8543]
===
match
---
if_stmt [9865,9923]
if_stmt [9851,9909]
===
match
---
name: get [5487,5490]
name: get [5473,5476]
===
match
---
atom_expr [5605,5619]
atom_expr [5591,5605]
===
match
---
name: AIRFLOW_HOME [8287,8299]
name: AIRFLOW_HOME [8273,8285]
===
match
---
string: 'user' [4805,4811]
string: 'user' [4799,4805]
===
match
---
name: f [10385,10386]
name: f [10371,10372]
===
match
---
name: handler [8935,8942]
name: handler [8921,8928]
===
match
---
simple_stmt [8856,8881]
simple_stmt [8842,8867]
===
match
---
name: startswith [4548,4558]
name: startswith [4542,4552]
===
match
---
name: stdout [8062,8068]
name: stdout [8048,8054]
===
match
---
trailer [9429,9431]
trailer [9415,9417]
===
match
---
not_test [4846,4882]
not_test [4832,4868]
===
match
---
name: traceback [948,957]
name: traceback [933,942]
===
match
---
operator: , [1077,1078]
operator: , [1062,1063]
===
match
---
expr_stmt [6289,6329]
expr_stmt [6275,6315]
===
match
---
atom_expr [4305,4326]
atom_expr [4299,4320]
===
match
---
sync_comp_for [5293,5331]
sync_comp_for [5279,5317]
===
match
---
name: functools [10496,10505]
name: functools [10482,10491]
===
match
---
atom_expr [5034,5049]
atom_expr [5020,5035]
===
match
---
name: tmp_dic [5176,5183]
name: tmp_dic [5162,5169]
===
match
---
name: Namespace [1582,1591]
name: Namespace [1576,1585]
===
match
---
name: func_name [3412,3421]
name: func_name [3406,3415]
===
match
---
suite [5689,6051]
suite [5675,6037]
===
match
---
name: path [5992,5996]
name: path [5978,5982]
===
match
---
name: should_use_colors [10092,10109]
name: should_use_colors [10078,10095]
===
match
---
name: expanduser [6013,6023]
name: expanduser [5999,6009]
===
match
---
argument [10629,10637]
argument [10615,10623]
===
match
---
suite [1503,1551]
suite [1497,1545]
===
match
---
operator: , [8060,8061]
operator: , [8046,8047]
===
match
---
name: sys [920,923]
name: sys [905,908]
===
match
---
expr_stmt [5054,5095]
expr_stmt [5040,5081]
===
match
---
name: TypeVar [1343,1350]
name: TypeVar [1337,1344]
===
match
---
trailer [8471,8484]
trailer [8457,8470]
===
match
---
import_name [899,912]
import_name [884,897]
===
match
---
atom_expr [3284,3301]
atom_expr [3278,3295]
===
match
---
import_name [913,923]
import_name [898,908]
===
match
---
fstring [9373,9433]
fstring [9359,9419]
===
match
---
atom_expr [6301,6329]
atom_expr [6287,6315]
===
match
---
trailer [6499,6506]
trailer [6485,6492]
===
match
---
name: append [9895,9901]
name: append [9881,9887]
===
match
---
simple_stmt [3439,3808]
simple_stmt [3433,3802]
===
match
---
name: process [8312,8319]
name: process [8298,8305]
===
match
---
operator: , [1354,1355]
operator: , [1348,1349]
===
match
---
name: join [8175,8179]
name: join [8161,8165]
===
match
---
name: command [4540,4547]
name: command [4534,4541]
===
match
---
name: Log [5344,5347]
name: Log [5330,5333]
===
match
---
trailer [2980,2986]
trailer [2974,2980]
===
match
---
atom_expr [9743,9773]
atom_expr [9729,9759]
===
match
---
operator: { [4561,4562]
operator: { [4555,4556]
===
match
---
trailer [6012,6023]
trailer [5998,6009]
===
match
---
atom [9515,9517]
atom [9501,9503]
===
match
---
atom_expr [7463,7588]
atom_expr [7449,7574]
===
match
---
name: metrics [5518,5525]
name: metrics [5504,5511]
===
match
---
funcdef [3393,5645]
funcdef [3387,5631]
===
match
---
funcdef [6053,6606]
funcdef [6039,6592]
===
match
---
trailer [8267,8272]
trailer [8253,8258]
===
match
---
trailer [3299,3301]
trailer [3293,3295]
===
match
---
operator: , [5381,5382]
operator: , [5367,5368]
===
match
---
name: logging [11019,11026]
name: logging [11005,11012]
===
match
---
name: logging [8724,8731]
name: logging [8710,8717]
===
match
---
suite [10396,11081]
suite [10382,11067]
===
match
---
decorator [2594,2614]
decorator [2588,2608]
===
match
---
name: dag_pickle [7789,7799]
name: dag_pickle [7775,7785]
===
match
---
string: "Args should be set" [1529,1549]
string: "Args should be set" [1523,1543]
===
match
---
name: socket [5233,5239]
name: socket [5219,5225]
===
match
---
operator: , [9727,9728]
operator: , [9713,9714]
===
match
---
fstring_expr [4991,5008]
fstring_expr [4977,4994]
===
match
---
return_stmt [10244,10255]
return_stmt [10230,10241]
===
match
---
atom_expr [5950,5970]
atom_expr [5936,5956]
===
match
---
arglist [8463,8510]
arglist [8449,8496]
===
match
---
suite [7891,7964]
suite [7877,7950]
===
match
---
operator: = [8688,8689]
operator: = [8674,8675]
===
match
---
name: args [2631,2635]
name: args [2625,2629]
===
match
---
simple_stmt [10317,10353]
simple_stmt [10303,10339]
===
match
---
name: pickle_id [7850,7859]
name: pickle_id [7836,7845]
===
match
---
name: dag_id [7061,7067]
name: dag_id [7047,7053]
===
match
---
name: dags [7010,7014]
name: dags [6996,7000]
===
match
---
name: type [4992,4996]
name: type [4978,4982]
===
match
---
name: code [9787,9791]
name: code [9773,9777]
===
match
---
name: get [5082,5085]
name: get [5068,5071]
===
match
---
return_stmt [6996,7022]
return_stmt [6982,7008]
===
match
---
operator: } [5007,5008]
operator: } [4993,4994]
===
match
---
fstring_expr [4561,4578]
fstring_expr [4555,4572]
===
match
---
operator: , [3030,3031]
operator: , [3024,3025]
===
match
---
expr_stmt [8256,8326]
expr_stmt [8242,8312]
===
match
---
name: airflow [1293,1300]
name: airflow [1287,1294]
===
match
---
name: th [9453,9455]
name: th [9439,9441]
===
match
---
string: 'sub_command' [4683,4696]
string: 'sub_command' [4677,4690]
===
match
---
string: """Expands path to absolute by replacing 'DAGS_FOLDER', '~', '.', etc.""" [5694,5767]
string: """Expands path to absolute by replacing 'DAGS_FOLDER', '~', '.', etc.""" [5680,5753]
===
match
---
name: format [6967,6973]
name: format [6953,6959]
===
match
---
expr_stmt [8158,8228]
expr_stmt [8144,8214]
===
match
---
name: Formatter [8778,8787]
name: Formatter [8764,8773]
===
match
---
name: exit [9156,9160]
name: exit [9142,9146]
===
match
---
trailer [4860,4882]
trailer [4846,4868]
===
match
---
term [4329,4336]
term [4323,4330]
===
match
---
trailer [9894,9901]
trailer [9880,9887]
===
match
---
suite [10815,10855]
suite [10801,10841]
===
match
---
trailer [7866,7868]
trailer [7852,7854]
===
match
---
operator: , [5314,5315]
operator: , [5300,5301]
===
match
---
atom_expr [2965,2986]
atom_expr [2959,2980]
===
match
---
expr_stmt [5605,5625]
expr_stmt [5591,5611]
===
match
---
operator: = [4327,4328]
operator: = [4321,4322]
===
match
---
string: 'dag_id could not be found: {}. Either the dag did not exist or it failed to ' [6867,6945]
string: 'dag_id could not be found: {}. Either the dag did not exist or it failed to ' [6853,6931]
===
match
---
name: log [5338,5341]
name: log [5324,5327]
===
match
---
name: Optional [5674,5682]
name: Optional [5660,5668]
===
match
---
param [3412,3422]
param [3406,3416]
===
match
---
name: utcnow [4744,4750]
name: utcnow [4738,4744]
===
match
---
operator: @ [2594,2595]
operator: @ [2588,2589]
===
match
---
string: "Who hid the pickle!? [missing pickle]" [7923,7962]
string: "Who hid the pickle!? [missing pickle]" [7909,7948]
===
match
---
name: args [10208,10212]
name: args [10194,10198]
===
match
---
strings [4922,5009]
strings [4908,4995]
===
match
---
expr_stmt [5210,5253]
expr_stmt [5196,5239]
===
match
---
atom_expr [3032,3039]
atom_expr [3026,3033]
===
match
---
simple_stmt [7227,7260]
simple_stmt [7213,7246]
===
match
---
name: settings [5798,5806]
name: settings [5784,5792]
===
match
---
simple_stmt [10401,10490]
simple_stmt [10387,10476]
===
match
---
atom_expr [7046,7059]
atom_expr [7032,7045]
===
match
---
operator: , [7072,7073]
operator: , [7058,7059]
===
match
---
if_stmt [6793,6992]
if_stmt [6779,6978]
===
match
---
name: cli_action_loggers [3049,3067]
name: cli_action_loggers [3043,3061]
===
match
---
trailer [7009,7014]
trailer [6995,7000]
===
match
---
operator: = [5231,5232]
operator: = [5217,5218]
===
match
---
name: dags [6593,6597]
name: dags [6579,6583]
===
match
---
name: dagbag [6749,6755]
name: dagbag [6735,6741]
===
match
---
trailer [8286,8299]
trailer [8272,8285]
===
match
---
name: idx [4097,4100]
name: idx [4091,4094]
===
match
---
operator: @ [7625,7626]
operator: @ [7611,7612]
===
match
---
operator: = [3977,3978]
operator: = [3971,3972]
===
match
---
name: AirflowException [1164,1180]
name: AirflowException [1149,1165]
===
match
---
name: sys [9546,9549]
name: sys [9532,9535]
===
match
---
atom_expr [7363,7392]
atom_expr [7349,7378]
===
match
---
string: """Coloring modes. If `auto` is then automatically detected.""" [9973,10036]
string: """Coloring modes. If `auto` is then automatically detected.""" [9959,10022]
===
match
---
name: metrics [5425,5432]
name: metrics [5411,5418]
===
match
---
operator: , [4870,4871]
operator: , [4856,4857]
===
match
---
argument [10838,10843]
argument [10824,10829]
===
match
---
operator: , [8484,8485]
operator: , [8470,8471]
===
match
---
simple_stmt [8530,8557]
simple_stmt [8516,8543]
===
match
---
atom_expr [8885,8922]
atom_expr [8871,8908]
===
match
---
trailer [5271,5277]
trailer [5257,5263]
===
match
---
trailer [5107,5118]
trailer [5093,5104]
===
match
---
trailer [6565,6573]
trailer [6551,6559]
===
match
---
simple_stmt [5148,5206]
simple_stmt [5134,5192]
===
match
---
suite [8098,8594]
suite [8084,8580]
===
match
---
simple_stmt [3223,3229]
simple_stmt [3217,3223]
===
match
---
atom_expr [10620,10638]
atom_expr [10606,10624]
===
match
---
name: pid [8530,8533]
name: pid [8516,8519]
===
match
---
trailer [7449,7598]
trailer [7435,7584]
===
match
---
testlist [8569,8593]
testlist [8555,8579]
===
match
---
suite [6355,6525]
suite [6341,6511]
===
match
---
raise_stmt [7427,7598]
raise_stmt [7413,7584]
===
match
---
fstring_expr [9826,9839]
fstring_expr [9812,9825]
===
match
---
name: f [10512,10513]
name: f [10498,10499]
===
match
---
fstring_expr [9808,9818]
fstring_expr [9794,9804]
===
match
---
name: execution_date [5549,5563]
name: execution_date [5535,5549]
===
match
---
simple_stmt [889,899]
simple_stmt [874,884]
===
match
---
arglist [9663,9676]
arglist [9649,9662]
===
match
---
name: T [10394,10395]
name: T [10380,10381]
===
match
---
name: wrapper [3382,3389]
name: wrapper [3376,3383]
===
match
---
string: """Fetch DAG from the database using pickling""" [7694,7742]
string: """Fetch DAG from the database using pickling""" [7680,7728]
===
match
---
name: os [5989,5991]
name: os [5975,5977]
===
match
---
name: get_dags [7029,7037]
name: get_dags [7015,7023]
===
match
---
simple_stmt [8103,8131]
simple_stmt [8089,8117]
===
match
---
operator: { [9452,9453]
operator: { [9438,9439]
===
match
---
simple_stmt [6529,6575]
simple_stmt [6515,6561]
===
match
---
name: ColorMode [10277,10286]
name: ColorMode [10263,10272]
===
match
---
operator: , [5539,5540]
operator: , [5525,5526]
===
match
---
string: 'users' [3873,3880]
string: 'users' [3867,3874]
===
match
---
atom_expr [4607,4624]
atom_expr [4601,4618]
===
match
---
name: stderr [8158,8164]
name: stderr [8144,8150]
===
match
---
trailer [6321,6329]
trailer [6307,6315]
===
match
---
operator: = [3918,3919]
operator: = [3912,3913]
===
match
---
atom_expr [9420,9431]
atom_expr [9406,9417]
===
match
---
expr_stmt [2995,3040]
expr_stmt [2989,3034]
===
match
---
trailer [4122,4136]
trailer [4116,4130]
===
match
---
trailer [10776,10794]
trailer [10762,10780]
===
match
---
fstring_string: airflow- [8303,8311]
fstring_string: airflow- [8289,8297]
===
match
---
name: dagbag [6810,6816]
name: dagbag [6796,6802]
===
match
---
name: search [7366,7372]
name: search [7352,7358]
===
match
---
operator: , [4830,4831]
operator: , [4816,4817]
===
match
---
name: metrics [3190,3197]
name: metrics [3184,3191]
===
match
---
operator: = [8534,8535]
operator: = [8520,8521]
===
match
---
name: root [8856,8860]
name: root [8842,8846]
===
match
---
name: disable [10769,10776]
name: disable [10755,10762]
===
match
---
suite [3177,3229]
suite [3171,3223]
===
match
---
trailer [11042,11049]
trailer [11028,11035]
===
match
---
atom_expr [4813,4830]
atom_expr [4807,4816]
===
match
---
testlist_comp [7324,7392]
testlist_comp [7310,7378]
===
match
---
simple_stmt [10072,10086]
simple_stmt [10058,10072]
===
match
---
expr_stmt [6749,6788]
expr_stmt [6735,6774]
===
match
---
operator: = [5362,5363]
operator: = [5348,5349]
===
match
---
name: get_dag [6612,6619]
name: get_dag [6598,6605]
===
match
---
operator: * [10838,10839]
operator: * [10824,10825]
===
match
---
name: sensitive_field [4630,4645]
name: sensitive_field [4624,4639]
===
match
---
suite [9873,9923]
suite [9859,9909]
===
match
---
operator: { [8213,8214]
operator: { [8199,8200]
===
match
---
funcdef [7642,8021]
funcdef [7628,8007]
===
match
---
trailer [5432,5440]
trailer [5418,5426]
===
match
---
trailer [5996,6004]
trailer [5982,5990]
===
match
---
number: 0 [1578,1579]
number: 0 [1572,1573]
===
match
---
tfpdef [6082,6093]
tfpdef [6068,6079]
===
match
---
fstring_string: airflow- [8488,8496]
fstring_string: airflow- [8474,8482]
===
match
---
fstring_expr [9647,9678]
fstring_expr [9633,9664]
===
match
---
dotted_name [6173,6187]
dotted_name [6159,6173]
===
match
---
import_name [879,888]
import_name [864,873]
===
match
---
string: '' [9674,9676]
string: '' [9660,9662]
===
match
---
name: AIRFLOW_HOME [8379,8391]
name: AIRFLOW_HOME [8365,8377]
===
match
---
string: 'parse.' [6491,6499]
string: 'parse.' [6477,6485]
===
match
---
operator: = [5174,5175]
operator: = [5160,5161]
===
match
---
name: id_to_name [9648,9658]
name: id_to_name [9634,9644]
===
match
---
not_test [8236,8246]
not_test [8222,8232]
===
match
---
param [2630,2636]
param [2624,2630]
===
match
---
string: """Processes arguments and decides whether to enable color in output""" [10129,10200]
string: """Processes arguments and decides whether to enable color in output""" [10115,10186]
===
match
---
name: airflow [7167,7174]
name: airflow [7153,7160]
===
match
---
name: airflow [6173,6180]
name: airflow [6159,6166]
===
match
---
comparison [4153,4180]
comparison [4147,4174]
===
match
---
name: stdout [8256,8262]
name: stdout [8242,8248]
===
match
---
string: 'or it failed to parse.' [7549,7573]
string: 'or it failed to parse.' [7535,7559]
===
match
---
expr_stmt [3964,3993]
expr_stmt [3958,3987]
===
match
---
suite [1422,1458]
suite [1416,1452]
===
match
---
fstring_start: f' [4627,4629]
fstring_start: f' [4621,4623]
===
match
---
name: get [9659,9662]
name: get [9645,9648]
===
match
---
expr_stmt [8714,8753]
expr_stmt [8700,8739]
===
match
---
name: ValueError [1518,1528]
name: ValueError [1512,1522]
===
match
---
trailer [5490,5501]
trailer [5476,5487]
===
match
---
comparison [6337,6354]
comparison [6323,6340]
===
match
---
string: 'end_datetime' [3266,3280]
string: 'end_datetime' [3260,3274]
===
match
---
atom_expr [8370,8391]
atom_expr [8356,8377]
===
match
---
term [4648,4655]
term [4642,4649]
===
match
---
if_stmt [1491,1551]
if_stmt [1485,1545]
===
match
---
simple_stmt [864,879]
simple_stmt [849,864]
===
match
---
operator: } [9502,9503]
operator: } [9488,9489]
===
match
---
operator: , [2635,2636]
operator: , [2629,2630]
===
match
---
trailer [5061,5071]
trailer [5047,5057]
===
match
---
name: sub_commands_to_check [3848,3869]
name: sub_commands_to_check [3842,3863]
===
match
---
simple_stmt [3812,3843]
simple_stmt [3806,3837]
===
match
---
operator: } [9919,9920]
operator: } [9905,9906]
===
match
---
operator: , [10537,10538]
operator: , [10523,10524]
===
match
---
name: filename [8744,8752]
name: filename [8730,8738]
===
match
---
simple_stmt [8629,8679]
simple_stmt [8615,8665]
===
match
---
return_stmt [7227,7259]
return_stmt [7213,7245]
===
match
---
name: args [3131,3135]
name: args [3125,3129]
===
match
---
name: subdir [5980,5986]
name: subdir [5966,5972]
===
match
---
name: id_to_name [9439,9449]
name: id_to_name [9425,9435]
===
match
---
trailer [5187,5205]
trailer [5173,5191]
===
match
---
trailer [4908,5019]
trailer [4894,5005]
===
match
---
operator: -> [6656,6658]
operator: -> [6642,6644]
===
match
---
string: '--password' [3927,3939]
string: '--password' [3921,3933]
===
match
---
name: dag_id [6082,6088]
name: dag_id [6068,6074]
===
match
---
parameters [10384,10390]
parameters [10370,10376]
===
match
---
comparison [6796,6821]
comparison [6782,6807]
===
match
---
parameters [8613,8623]
parameters [8599,8609]
===
match
---
argument [3351,3360]
argument [3345,3354]
===
match
---
atom_expr [6867,6981]
atom_expr [6853,6967]
===
match
---
name: dag_id [6796,6802]
name: dag_id [6782,6788]
===
match
---
operator: = [10045,10046]
operator: = [10031,10032]
===
match
---
name: settings [5950,5958]
name: settings [5936,5944]
===
match
---
trailer [7054,7059]
trailer [7040,7045]
===
match
---
number: 0 [10596,10597]
number: 0 [10582,10583]
===
match
---
simple_stmt [1181,1226]
simple_stmt [1166,1211]
===
match
---
operator: , [3421,3422]
operator: , [3415,3416]
===
match
---
trailer [6636,6641]
trailer [6622,6627]
===
match
---
name: process [8214,8221]
name: process [8200,8207]
===
match
---
name: cli_action_loggers [3314,3332]
name: cli_action_loggers [3308,3326]
===
match
---
fstring_start: f' [4559,4561]
fstring_start: f' [4553,4555]
===
match
---
fstring_end: ' [4794,4795]
fstring_end: ' [4788,4789]
===
match
---
name: fileloc [6566,6573]
name: fileloc [6552,6559]
===
match
---
if_stmt [1555,1733]
if_stmt [1549,1727]
===
match
---
name: metrics [5100,5107]
name: metrics [5086,5093]
===
match
---
trailer [9422,9429]
trailer [9408,9415]
===
match
---
operator: , [8580,8581]
operator: , [8566,8567]
===
match
---
parameters [1479,1485]
parameters [1473,1479]
===
match
---
name: str [7069,7072]
name: str [7055,7058]
===
match
---
simple_stmt [3121,3147]
simple_stmt [3115,3141]
===
match
---
parameters [10531,10548]
parameters [10517,10534]
===
match
---
name: json [5267,5271]
name: json [5253,5257]
===
match
---
number: 0 [3037,3038]
number: 0 [3031,3032]
===
match
---
trailer [8707,8709]
trailer [8693,8695]
===
match
---
return_stmt [6579,6605]
return_stmt [6565,6591]
===
match
---
suite [8149,8229]
suite [8135,8215]
===
match
---
name: AirflowException [7906,7922]
name: AirflowException [7892,7908]
===
match
---
trailer [3021,3030]
trailer [3015,3024]
===
match
---
trailer [5991,5996]
trailer [5977,5982]
===
match
---
name: dag_model [6337,6346]
name: dag_model [6323,6332]
===
match
---
import_from [974,1004]
import_from [959,989]
===
match
---
atom_expr [10277,10290]
atom_expr [10263,10276]
===
match
---
suite [7418,7599]
suite [7404,7585]
===
match
---
string: 'dag_id could not be found: {}. Either the dag did not exist or it failed to ' [6400,6478]
string: 'dag_id could not be found: {}. Either the dag did not exist or it failed to ' [6386,6464]
===
match
---
name: dag_model [6556,6565]
name: dag_model [6542,6551]
===
match
---
atom [7323,7393]
atom [7309,7379]
===
match
---
name: handler [8714,8721]
name: handler [8700,8707]
===
match
---
atom_expr [8278,8299]
atom_expr [8264,8285]
===
match
---
operator: , [8391,8392]
operator: , [8377,8378]
===
match
---
name: handler [8872,8879]
name: handler [8858,8865]
===
match
---
operator: { [9906,9907]
operator: { [9892,9893]
===
match
---
operator: { [9647,9648]
operator: { [9633,9634]
===
match
---
operator: { [4647,4648]
operator: { [4641,4642]
===
match
---
tfpdef [7061,7072]
tfpdef [7047,7058]
===
match
---
tfpdef [7074,7089]
tfpdef [7060,7075]
===
match
---
name: metrics [2995,3002]
name: metrics [2989,2996]
===
match
---
simple_stmt [9439,9504]
simple_stmt [9425,9490]
===
match
---
name: namespace [3423,3432]
name: namespace [3417,3426]
===
match
---
name: full_command [4001,4013]
name: full_command [3995,4007]
===
match
---
operator: = [5265,5266]
operator: = [5251,5252]
===
match
---
name: FileHandler [8732,8743]
name: FileHandler [8718,8729]
===
match
---
parameters [7663,7688]
parameters [7649,7674]
===
match
---
simple_stmt [2965,2987]
simple_stmt [2959,2981]
===
match
---
operator: , [8050,8051]
operator: , [8036,8037]
===
match
---
simple_stmt [8256,8327]
simple_stmt [8242,8313]
===
match
---
name: dag_folder [6545,6555]
name: dag_folder [6531,6541]
===
match
---
return_stmt [8003,8020]
return_stmt [7989,8006]
===
match
---
atom_expr [3190,3206]
atom_expr [3184,3200]
===
match
---
simple_stmt [1104,1133]
simple_stmt [1089,1118]
===
match
---
operator: , [1067,1068]
operator: , [1052,1053]
===
match
---
name: dag_id [7015,7021]
name: dag_id [7001,7007]
===
match
---
trailer [8538,8543]
trailer [8524,8529]
===
match
---
string: 'host_name' [5303,5314]
string: 'host_name' [5289,5300]
===
match
---
string: 'dag_id' [5530,5538]
string: 'dag_id' [5516,5524]
===
match
---
import_from [3812,3842]
import_from [3806,3836]
===
match
---
operator: , [1580,1581]
operator: , [1574,1575]
===
match
---
name: wrapper [2622,2629]
name: wrapper [2616,2623]
===
match
---
fstring_expr [4780,4794]
fstring_expr [4774,4788]
===
match
---
operator: = [8055,8056]
operator: = [8041,8042]
===
match
---
atom_expr [10208,10218]
atom_expr [10194,10204]
===
match
---
if_stmt [7398,7599]
if_stmt [7384,7585]
===
match
---
trailer [10784,10793]
trailer [10770,10779]
===
match
---
name: args [10574,10578]
name: args [10560,10564]
===
match
---
fstring_string: , in  [9839,9844]
fstring_string: , in  [9825,9830]
===
match
---
name: logging [11035,11042]
name: logging [11021,11028]
===
match
---
expr_stmt [5911,5971]
expr_stmt [5897,5957]
===
match
---
suite [6665,7023]
suite [6651,7009]
===
match
---
param [8062,8074]
param [8048,8060]
===
match
---
name: stderr [8075,8081]
name: stderr [8061,8067]
===
match
---
atom_expr [1608,1732]
atom_expr [1602,1726]
===
match
---
simple_stmt [10761,10795]
simple_stmt [10747,10781]
===
match
---
atom_expr [6628,6641]
atom_expr [6614,6627]
===
match
---
name: settings [8180,8188]
name: settings [8166,8174]
===
match
---
funcdef [5647,6051]
funcdef [5633,6037]
===
match
---
argument [10622,10627]
argument [10608,10613]
===
match
---
operator: * [3130,3131]
operator: * [3124,3125]
===
match
---
arglist [3130,3145]
arglist [3124,3139]
===
match
---
operator: , [9733,9734]
operator: , [9719,9720]
===
match
---
name: dag [7381,7384]
name: dag [7367,7370]
===
match
---
trailer [3019,3040]
trailer [3013,3034]
===
match
---
expr_stmt [5980,6032]
expr_stmt [5966,6018]
===
match
---
atom_expr [5121,5143]
atom_expr [5107,5129]
===
match
---
operator: { [4629,4630]
operator: { [4623,4624]
===
match
---
operator: = [5119,5120]
operator: = [5105,5106]
===
match
---
atom_expr [8463,8484]
atom_expr [8449,8470]
===
match
---
operator: } [4836,4837]
operator: } [4822,4823]
===
match
---
trailer [7815,7826]
trailer [7801,7812]
===
match
---
funcdef [9166,9950]
funcdef [9152,9936]
===
match
---
name: setLevel [8890,8898]
name: setLevel [8876,8884]
===
match
---
name: args [10533,10537]
name: args [10519,10523]
===
match
---
trailer [8796,8814]
trailer [8782,8800]
===
match
---
name: cli_action_loggers [1207,1225]
name: cli_action_loggers [1192,1210]
===
match
---
if_stmt [5772,6033]
if_stmt [5758,6019]
===
match
---
trailer [3983,3993]
trailer [3977,3987]
===
match
---
trailer [5155,5173]
trailer [5141,5159]
===
match
---
expr_stmt [6529,6574]
expr_stmt [6515,6560]
===
match
---
name: models [6181,6187]
name: models [6167,6173]
===
match
---
operator: = [3003,3004]
operator: = [2997,2998]
===
match
---
trailer [8452,8457]
trailer [8438,8443]
===
match
---
operator: , [8588,8589]
operator: , [8574,8575]
===
match
---
operator: = [7979,7980]
operator: = [7965,7966]
===
match
---
name: metrics [5605,5612]
name: metrics [5591,5598]
===
match
---
trailer [11067,11080]
trailer [11053,11066]
===
match
---
for_stmt [4093,4658]
for_stmt [4087,4652]
===
match
---
fstring_string: airflow- [8205,8213]
fstring_string: airflow- [8191,8199]
===
match
---
name: subdir [5911,5917]
name: subdir [5897,5903]
===
match
---
atom_expr [9463,9470]
atom_expr [9449,9456]
===
match
---
trailer [9798,9852]
trailer [9784,9838]
===
match
---
name: subdir [7038,7044]
name: subdir [7024,7030]
===
match
---
name: sigquit_handler [9170,9185]
name: sigquit_handler [9156,9171]
===
match
---
trailer [7242,7258]
trailer [7228,7244]
===
match
---
operator: { [5369,5370]
operator: { [5355,5356]
===
match
---
atom_expr [8450,8511]
atom_expr [8436,8497]
===
match
---
name: process [8043,8050]
name: process [8029,8036]
===
match
---
dotted_name [7752,7766]
dotted_name [7738,7752]
===
match
---
name: os [886,888]
name: os [871,873]
===
match
---
simple_stmt [9973,10037]
simple_stmt [9959,10023]
===
match
---
simple_stmt [10836,10855]
simple_stmt [10822,10841]
===
match
---
atom_expr [4113,4136]
atom_expr [4107,4130]
===
match
---
string: """     Decorates function to execute function at the same time submitting action_logging     but in CLI context. It will call action logger callbacks twice,     one for pre-execution and the other one for post-execution.      Action logger will be called with below keyword parameters:         sub_command : name of sub-command         start_datetime : start datetime instance by utc         end_datetime : end datetime instance by utc         full_command : full command line arguments         user : current user         log : airflow.models.log.Log ORM instance         dag_id : dag id (optional)         task_id : task_id (optional)         execution_date : execution date (optional)         error : exception instance if there's an exception      :param f: function instance     :return: wrapped function     """ [1770,2588]
string: """     Decorates function to execute function at the same time submitting action_logging     but in CLI context. It will call action logger callbacks twice,     one for pre-execution and the other one for post-execution.      Action logger will be called with below keyword parameters:         sub_command : name of sub-command         start_datetime : start datetime instance by utc         end_datetime : end datetime instance by utc         full_command : full command line arguments         user : current user         log : airflow.models.log.Log ORM instance         dag_id : dag id (optional)         task_id : task_id (optional)         execution_date : execution date (optional)         error : exception instance if there's an exception      :param f: function instance     :return: wrapped function     """ [1764,2582]
===
match
---
trailer [6506,6514]
trailer [6492,6500]
===
match
---
fstring_end: " [9691,9692]
fstring_end: " [9677,9678]
===
match
---
operator: -> [10391,10393]
operator: -> [10377,10379]
===
match
---
operator: -> [10116,10118]
operator: -> [10102,10104]
===
match
---
name: stack [9767,9772]
name: stack [9753,9758]
===
match
---
name: metrics [5210,5217]
name: metrics [5196,5203]
===
match
---
string: "ignore" [10735,10743]
string: "ignore" [10721,10729]
===
match
---
atom_expr [9927,9949]
atom_expr [9913,9935]
===
match
---
trailer [7350,7357]
trailer [7336,7343]
===
match
---
parameters [10109,10115]
parameters [10095,10101]
===
match
---
name: wraps [2605,2610]
name: wraps [2599,2604]
===
match
---
suite [8521,8557]
suite [8507,8543]
===
match
---
suite [10235,10256]
suite [10221,10242]
===
match
---
simple_stmt [7162,7196]
simple_stmt [7148,7182]
===
match
---
fstring_end: ' [4656,4657]
fstring_end: ' [4650,4651]
===
match
---
suite [10652,11051]
suite [10638,11037]
===
match
---
operator: = [4625,4626]
operator: = [4619,4620]
===
match
---
name: settings [1124,1132]
name: settings [1109,1117]
===
match
---
atom_expr [6538,6574]
atom_expr [6524,6560]
===
match
---
comparison [10208,10234]
comparison [10194,10220]
===
match
---
raise_stmt [1512,1550]
raise_stmt [1506,1544]
===
match
---
atom_expr [9481,9502]
atom_expr [9467,9488]
===
match
---
param [2637,2645]
param [2631,2639]
===
match
---
return_stmt [10300,10312]
return_stmt [10286,10298]
===
match
---
fstring_string: airflow- [8395,8403]
fstring_string: airflow- [8381,8389]
===
match
---
simple_stmt [3258,3302]
simple_stmt [3252,3296]
===
match
---
tfpdef [1754,1758]
tfpdef [1748,1752]
===
match
---
name: gethostname [5240,5251]
name: gethostname [5226,5237]
===
match
---
trailer [1711,1720]
trailer [1705,1714]
===
match
---
fstring_start: f' [8203,8205]
fstring_start: f' [8189,8191]
===
match
---
expr_stmt [7308,7393]
expr_stmt [7294,7379]
===
match
---
trailer [8787,8815]
trailer [8773,8801]
===
match
---
name: metrics [3258,3265]
name: metrics [3252,3259]
===
match
---
name: airflow [1432,1439]
name: airflow [1426,1433]
===
match
---
name: session [7802,7809]
name: session [7788,7795]
===
match
---
name: dagbag [7003,7009]
name: dagbag [6989,6995]
===
match
---
name: logging [8690,8697]
name: logging [8676,8683]
===
match
---
operator: ** [10845,10847]
operator: ** [10831,10833]
===
match
---
name: enumerate [4113,4122]
name: enumerate [4107,4116]
===
match
---
name: command [4153,4160]
name: command [4147,4154]
===
match
---
param [10110,10114]
param [10096,10100]
===
match
---
expr_stmt [3848,3896]
expr_stmt [3842,3890]
===
match
---
name: get_current [6310,6321]
name: get_current [6296,6307]
===
match
---
name: bound [1356,1361]
name: bound [1350,1355]
===
match
---
operator: = [8448,8449]
operator: = [8434,8435]
===
match
---
param [8614,8622]
param [8600,8608]
===
match
---
operator: = [8722,8723]
operator: = [8708,8709]
===
match
---
operator: { [8403,8404]
operator: { [8389,8390]
===
match
---
trailer [10621,10638]
trailer [10607,10624]
===
match
---
operator: ** [2637,2639]
operator: ** [2631,2633]
===
match
---
string: """     Returns without error on SIGINT or SIGTERM signals in interactive command mode     e.g. CTRL+C or kill <PID>     """ [9023,9147]
string: """     Returns without error on SIGINT or SIGTERM signals in interactive command mode     e.g. CTRL+C or kill <PID>     """ [9009,9133]
===
match
---
atom_expr [7235,7258]
atom_expr [7221,7244]
===
match
---
atom_expr [3005,3040]
atom_expr [2999,3034]
===
match
---
atom_expr [4850,4882]
atom_expr [4836,4868]
===
match
---
suite [10549,11051]
suite [10535,11037]
===
match
---
exprlist [9706,9739]
exprlist [9692,9725]
===
match
---
operator: { [4780,4781]
operator: { [4774,4775]
===
match
---
operator: + [4322,4323]
operator: + [4316,4317]
===
match
---
simple_stmt [8351,8419]
simple_stmt [8337,8405]
===
match
---
operator: , [9535,9536]
operator: , [9521,9522]
===
match
---
atom_expr [8180,8201]
atom_expr [8166,8187]
===
match
---
trailer [6544,6574]
trailer [6530,6560]
===
match
---
atom_expr [10558,10579]
atom_expr [10544,10565]
===
match
---
simple_stmt [1005,1035]
simple_stmt [990,1020]
===
match
---
fstring_start: f" [4982,4984]
fstring_start: f" [4968,4970]
===
match
---
simple_stmt [3314,3362]
simple_stmt [3308,3356]
===
match
---
trailer [8777,8787]
trailer [8763,8773]
===
match
---
param [1754,1758]
param [1748,1752]
===
match
---
operator: , [7673,7674]
operator: , [7659,7660]
===
match
---
name: get [5572,5575]
name: get [5558,5561]
===
match
---
atom_expr [6810,6821]
atom_expr [6796,6807]
===
match
---
name: e [3175,3176]
name: e [3169,3170]
===
match
---
trailer [10350,10352]
trailer [10336,10338]
===
match
---
name: extra [5450,5455]
name: extra [5436,5441]
===
match
---
name: process [8497,8504]
name: process [8483,8490]
===
match
---
expr_stmt [8530,8556]
expr_stmt [8516,8542]
===
match
---
string: 'full_command' [5316,5330]
string: 'full_command' [5302,5316]
===
match
---
name: utils [1301,1306]
name: utils [1295,1300]
===
match
---
name: T [1763,1764]
name: T [1757,1758]
===
match
---
atom_expr [5564,5593]
atom_expr [5550,5579]
===
match
---
name: use_regex [7208,7217]
name: use_regex [7194,7203]
===
match
---
operator: } [5379,5380]
operator: } [5365,5366]
===
match
---
operator: , [3939,3940]
operator: , [3933,3934]
===
match
---
atom [5278,5332]
atom [5264,5318]
===
match
---
simple_stmt [5605,5626]
simple_stmt [5591,5612]
===
match
---
atom_expr [3258,3281]
atom_expr [3252,3275]
===
match
---
param [8976,8981]
param [8962,8967]
===
match
---
funcdef [7025,7623]
funcdef [7011,7609]
===
match
---
trailer [7345,7350]
trailer [7331,7336]
===
match
---
simple_stmt [10300,10313]
simple_stmt [10286,10299]
===
match
---
name: pid [8431,8434]
name: pid [8417,8420]
===
match
---
name: sig [8971,8974]
name: sig [8957,8960]
===
match
---
name: items [9568,9573]
name: items [9554,9559]
===
match
---
name: metrics [3087,3094]
name: metrics [3081,3088]
===
match
---
trailer [8188,8201]
trailer [8174,8187]
===
match
---
operator: , [7249,7250]
operator: , [7235,7236]
===
match
---
name: dagbag [7339,7345]
name: dagbag [7325,7331]
===
match
---
operator: { [3872,3873]
operator: { [3866,3867]
===
match
---
return_stmt [10317,10352]
return_stmt [10303,10338]
===
match
---
not_test [7876,7890]
not_test [7862,7876]
===
match
---
name: AirflowException [7433,7449]
name: AirflowException [7419,7435]
===
match
---
suite [10607,10639]
suite [10593,10625]
===
match
---
operator: = [8091,8092]
operator: = [8077,8078]
===
match
---
atom_expr [9152,9163]
atom_expr [9138,9149]
===
match
---
return_stmt [11056,11080]
return_stmt [11042,11066]
===
match
---
name: path [8539,8543]
name: path [8525,8529]
===
match
---
name: wraps [10506,10511]
name: wraps [10492,10497]
===
match
---
simple_stmt [6168,6212]
simple_stmt [6154,6198]
===
match
---
name: warnings [10670,10678]
name: warnings [10656,10664]
===
match
---
atom_expr [10324,10352]
atom_expr [10310,10338]
===
match
---
name: full_command [4305,4317]
name: full_command [4299,4311]
===
match
---
atom_expr [4992,5007]
atom_expr [4978,4993]
===
match
---
name: pid [8444,8447]
name: pid [8430,8433]
===
match
---
name: logging [10761,10768]
name: logging [10747,10754]
===
match
---
fstring_string: File: " [9801,9808]
fstring_string: File: " [9787,9794]
===
match
---
name: Callable [1069,1077]
name: Callable [1054,1062]
===
match
---
number: 1 [4014,4015]
number: 1 [4008,4009]
===
match
---
name: pickle_dag [8010,8020]
name: pickle_dag [7996,8006]
===
match
---
simple_stmt [9508,9518]
simple_stmt [9494,9504]
===
match
---
sync_comp_for [7328,7392]
sync_comp_for [7314,7378]
===
match
---
decorator [7625,7642]
decorator [7611,7628]
===
match
---
atom_expr [9546,9575]
atom_expr [9532,9561]
===
match
---
name: stderr [8582,8588]
name: stderr [8568,8574]
===
match
---
trailer [5958,5970]
trailer [5944,5956]
===
match
---
trailer [4547,4558]
trailer [4541,4552]
===
match
---
name: OFF [10287,10290]
name: OFF [10273,10276]
===
match
---
name: json [859,863]
name: json [844,848]
===
match
---
operator: } [8504,8505]
operator: } [8490,8491]
===
match
---
name: getpid [9423,9429]
name: getpid [9409,9415]
===
match
---
name: type [1707,1711]
name: type [1701,1705]
===
match
---
operator: = [8081,8082]
operator: = [8067,8068]
===
match
---
name: sensitive_field [4480,4495]
name: sensitive_field [4474,4489]
===
match
---
name: T [11068,11069]
name: T [11054,11055]
===
match
---
trailer [9565,9567]
trailer [9551,9553]
===
match
---
trailer [6853,6991]
trailer [6839,6977]
===
match
---
funcdef [10355,11081]
funcdef [10341,11067]
===
match
---
name: os [8357,8359]
name: os [8343,8345]
===
match
---
param [7061,7073]
param [7047,7059]
===
match
---
name: root [8683,8687]
name: root [8669,8673]
===
match
---
parameters [2629,2646]
parameters [2623,2640]
===
match
---
decorator [10495,10515]
decorator [10481,10501]
===
match
---
name: join [8273,8277]
name: join [8259,8263]
===
match
---
simple_stmt [1035,1103]
simple_stmt [1020,1088]
===
match
---
atom [3920,3959]
atom [3914,3953]
===
match
---
trailer [9465,9470]
trailer [9451,9456]
===
match
---
name: os [9420,9422]
name: os [9406,9408]
===
match
---
arith_expr [4318,4325]
arith_expr [4312,4319]
===
match
---
simple_stmt [5980,6033]
simple_stmt [5966,6019]
===
match
---
trailer [3292,3299]
trailer [3286,3293]
===
match
---
funcdef [6608,7023]
funcdef [6594,7009]
===
match
---
string: """     Decorator to suppress logging and warning messages     in cli functions.     """ [10401,10489]
string: """     Decorator to suppress logging and warning messages     in cli functions.     """ [10387,10475]
===
match
---
string: "namespace argument should be argparse.Namespace instance," [4922,4981]
string: "namespace argument should be argparse.Namespace instance," [4908,4967]
===
match
---
operator: } [4793,4794]
operator: } [4787,4788]
===
match
---
funcdef [10519,11051]
funcdef [10505,11037]
===
match
---
fstring_string: ", line  [9818,9826]
fstring_string: ", line  [9804,9812]
===
match
---
simple_stmt [7104,7158]
simple_stmt [7090,7144]
===
match
---
tfpdef [7038,7059]
tfpdef [7024,7045]
===
match
---
simple_stmt [3049,3096]
simple_stmt [3043,3090]
===
match
---
atom_expr [11035,11049]
atom_expr [11021,11035]
===
match
---
name: traceback [9743,9752]
name: traceback [9729,9738]
===
match
---
fstring_start: f' [5363,5365]
fstring_start: f' [5349,5351]
===
match
---
trailer [10595,10598]
trailer [10581,10584]
===
match
---
name: list [3979,3983]
name: list [3973,3977]
===
match
---
trailer [6597,6605]
trailer [6583,6591]
===
match
---
expr_stmt [4305,4336]
expr_stmt [4299,4330]
===
match
---
atom_expr [6005,6031]
atom_expr [5991,6017]
===
match
---
arglist [8180,8227]
arglist [8166,8213]
===
match
---
simple_stmt [1770,2589]
simple_stmt [1764,2583]
===
match
---
import_as_names [6195,6211]
import_as_names [6181,6197]
===
match
---
string: "T" [1351,1354]
string: "T" [1345,1348]
===
match
---
operator: = [5072,5073]
operator: = [5058,5059]
===
match
---
name: formatter [8841,8850]
name: formatter [8827,8836]
===
match
---
fstring_expr [5369,5380]
fstring_expr [5355,5366]
===
match
---
name: dags [7346,7350]
name: dags [7332,7336]
===
match
---
operator: @ [10495,10496]
operator: @ [10481,10482]
===
match
---
decorated [10495,11051]
decorated [10481,11037]
===
match
---
exprlist [4097,4109]
exprlist [4091,4103]
===
match
---
name: th [9463,9465]
name: th [9449,9451]
===
match
---
operator: { [9419,9420]
operator: { [9405,9406]
===
match
---
simple_stmt [6289,6330]
simple_stmt [6275,6316]
===
match
---
name: metrics [5637,5644]
name: metrics [5623,5630]
===
match
---
name: func_name [5370,5379]
name: func_name [5356,5365]
===
match
---
fstring_end: " [5008,5009]
fstring_end: " [4994,4995]
===
match
---
atom_expr [5798,5818]
atom_expr [5784,5804]
===
match
---
name: f [1754,1755]
name: f [1748,1749]
===
match
---
suite [10696,11051]
suite [10682,11037]
===
match
---
string: "DAG" [6659,6664]
string: "DAG" [6645,6650]
===
match
---
trailer [1618,1732]
trailer [1612,1726]
===
match
---
operator: * [10622,10623]
operator: * [10608,10609]
===
match
---
simple_stmt [6710,6744]
simple_stmt [6696,6730]
===
match
---
name: AIRFLOW_HOME [8189,8201]
name: AIRFLOW_HOME [8175,8187]
===
match
---
dotted_name [1138,1156]
dotted_name [1123,1141]
===
match
---
return_stmt [7603,7622]
return_stmt [7589,7608]
===
match
---
trailer [5132,5143]
trailer [5118,5129]
===
match
---
atom_expr [10263,10273]
atom_expr [10249,10259]
===
match
---
name: get_dag_by_pickle [7646,7663]
name: get_dag_by_pickle [7632,7649]
===
match
---
name: verbose [10599,10606]
name: verbose [10585,10592]
===
match
---
name: Exception [3162,3171]
name: Exception [3156,3165]
===
match
---
simple_stmt [820,837]
simple_stmt [820,837]
===
match
---
name: path [6008,6012]
name: path [5994,5998]
===
match
---
simple_stmt [3848,3897]
simple_stmt [3842,3891]
===
match
---
operator: * [4652,4653]
operator: * [4646,4647]
===
match
---
atom_expr [4735,4752]
atom_expr [4729,4746]
===
match
---
fstring [8203,8227]
fstring [8189,8213]
===
match
---
operator: } [9689,9690]
operator: } [9675,9676]
===
match
---
name: datetime [3284,3292]
name: datetime [3278,3286]
===
match
---
name: args [10623,10627]
name: args [10609,10613]
===
match
---
atom_expr [8357,8418]
atom_expr [8343,8404]
===
match
---
operator: = [8165,8166]
operator: = [8151,8152]
===
match
---
simple_stmt [7264,7304]
simple_stmt [7250,7290]
===
match
---
string: 'full_command' [4762,4776]
string: 'full_command' [4756,4770]
===
match
---
not_test [8334,8341]
not_test [8320,8327]
===
match
---
parameters [5665,5688]
parameters [5651,5674]
===
match
---
trailer [1350,1371]
trailer [1344,1365]
===
match
---
name: name [9729,9733]
name: name [9715,9719]
===
match
---
name: sensitive_fields [4164,4180]
name: sensitive_fields [4158,4174]
===
match
---
atom_expr [7339,7359]
atom_expr [7325,7345]
===
match
---
atom_expr [7981,7998]
atom_expr [7967,7984]
===
match
---
name: dag_id [6322,6328]
name: dag_id [6308,6314]
===
match
---
atom_expr [5838,5902]
atom_expr [5824,5888]
===
match
---
name: AIRFLOW_HOME [8472,8484]
name: AIRFLOW_HOME [8458,8470]
===
match
---
operator: , [4100,4101]
operator: , [4094,4095]
===
match
---
name: DagBag [6538,6544]
name: DagBag [6524,6530]
===
match
---
name: AirflowException [6370,6386]
name: AirflowException [6356,6372]
===
match
---
string: 'start_datetime' [4717,4733]
string: 'start_datetime' [4711,4727]
===
match
---
name: dag_id [7251,7257]
name: dag_id [7237,7243]
===
match
---
except_clause [3155,3176]
except_clause [3149,3170]
===
match
---
fstring_string:    [9904,9906]
fstring_string:    [9890,9892]
===
match
---
if_stmt [6334,6525]
if_stmt [6320,6511]
===
match
---
simple_stmt [6996,7023]
simple_stmt [6982,7009]
===
match
---
name: on_post_execution [3333,3350]
name: on_post_execution [3327,3344]
===
match
---
strings [1632,1722]
strings [1626,1716]
===
match
---
name: datetime [1026,1034]
name: datetime [1011,1019]
===
match
---
fstring_expr [9419,9432]
fstring_expr [9405,9418]
===
match
---
name: join [8458,8462]
name: join [8444,8448]
===
match
---
name: LOGGING_LEVEL [8908,8921]
name: LOGGING_LEVEL [8894,8907]
===
match
---
tfpdef [10385,10389]
tfpdef [10371,10375]
===
match
---
name: get_dag_by_file_location [6057,6081]
name: get_dag_by_file_location [6043,6067]
===
match
---
operator: , [10627,10628]
operator: , [10613,10614]
===
match
---
name: subdir [6044,6050]
name: subdir [6030,6036]
===
match
---
suite [5782,6033]
suite [5768,6019]
===
match
---
name: models [7760,7766]
name: models [7746,7752]
===
match
---
name: str [6637,6640]
name: str [6623,6626]
===
match
---
name: namespace [4861,4870]
name: namespace [4847,4856]
===
match
---
name: pid [8569,8572]
name: pid [8555,8558]
===
match
---
arglist [10838,10853]
arglist [10824,10839]
===
match
---
name: join [9938,9942]
name: join [9924,9928]
===
match
---
trailer [9500,9502]
trailer [9486,9488]
===
match
---
operator: , [3135,3136]
operator: , [3129,3130]
===
match
---
simple_stmt [2656,2957]
simple_stmt [2650,2951]
===
match
---
arglist [7373,7391]
arglist [7359,7377]
===
match
---
name: SIMPLE_LOG_FORMAT [8797,8814]
name: SIMPLE_LOG_FORMAT [8783,8800]
===
match
---
trailer [5612,5619]
trailer [5598,5605]
===
match
---
if_stmt [4150,4658]
if_stmt [4144,4652]
===
match
---
simple_stmt [6670,6706]
simple_stmt [6656,6692]
===
match
---
strings [7463,7573]
strings [7449,7559]
===
match
---
name: __name__ [3022,3030]
name: __name__ [3016,3024]
===
match
---
simple_stmt [7427,7599]
simple_stmt [7413,7585]
===
match
---
atom_expr [5267,5333]
atom_expr [5253,5319]
===
match
---
operator: } [8221,8222]
operator: } [8207,8208]
===
match
---
argument [5549,5593]
argument [5535,5579]
===
match
---
operator: = [7271,7272]
operator: = [7257,7258]
===
match
---
simple_stmt [9787,9853]
simple_stmt [9773,9839]
===
match
---
name: cast [11063,11067]
name: cast [11049,11053]
===
match
---
param [6643,6654]
param [6629,6640]
===
match
---
trailer [4750,4752]
trailer [4744,4746]
===
match
---
trailer [5217,5230]
trailer [5203,5216]
===
match
---
string: """Returns DAG of a given dag_id by looking up file location""" [6100,6163]
string: """Returns DAG of a given dag_id by looking up file location""" [6086,6149]
===
match
---
trailer [10231,10234]
trailer [10217,10220]
===
match
---
atom_expr [5425,5440]
atom_expr [5411,5426]
===
match
---
name: code [9943,9947]
name: code [9929,9933]
===
match
---
atom [4673,4837]
atom [4667,4823]
===
match
---
name: logging [8770,8777]
name: logging [8756,8763]
===
match
---
atom_expr [5479,5501]
atom_expr [5465,5487]
===
match
---
trailer [10678,10693]
trailer [10664,10679]
===
match
---
fstring_end: ' [8226,8227]
fstring_end: ' [8212,8213]
===
match
---
operator: } [9838,9839]
operator: } [9824,9825]
===
match
---
operator: * [2630,2631]
operator: * [2624,2625]
===
match
---
name: log [8351,8354]
name: log [8337,8340]
===
match
---
not_test [8138,8148]
not_test [8124,8134]
===
match
---
raise_stmt [7900,7963]
raise_stmt [7886,7949]
===
match
---
operator: = [6536,6537]
operator: = [6522,6523]
===
match
---
trailer [9911,9917]
trailer [9897,9903]
===
match
---
string: "1st positional argument should be argparse.Namespace instance," [1632,1696]
string: "1st positional argument should be argparse.Namespace instance," [1626,1690]
===
match
---
import_name [958,973]
import_name [943,958]
===
match
---
argument [5357,5381]
argument [5343,5367]
===
match
---
expr_stmt [5148,5205]
expr_stmt [5134,5191]
===
match
---
suite [5819,5903]
suite [5805,5889]
===
match
---
if_stmt [3998,4658]
if_stmt [3992,4652]
===
match
---
name: NOTSET [11043,11049]
name: NOTSET [11029,11035]
===
match
---
name: DAG [1454,1457]
name: DAG [1448,1451]
===
match
---
param [3423,3432]
param [3417,3426]
===
match
---
import_name [924,940]
import_name [909,925]
===
match
---
param [6082,6093]
param [6068,6079]
===
match
---
name: is_terminal_support_colors [10324,10350]
name: is_terminal_support_colors [10310,10336]
===
match
---
name: AirflowException [6837,6853]
name: AirflowException [6823,6839]
===
match
---
arglist [1351,1370]
arglist [1345,1364]
===
match
---
name: id [7844,7846]
name: id [7830,7832]
===
match
---
simple_stmt [5832,5903]
simple_stmt [5818,5889]
===
match
---
atom_expr [8724,8753]
atom_expr [8710,8739]
===
match
---
name: str [7055,7058]
name: str [7041,7044]
===
match
---
name: log [8338,8341]
name: log [8324,8327]
===
match
---
fstring_string: but is  [4984,4991]
fstring_string: but is  [4970,4977]
===
match
---
name: dag_id [6974,6980]
name: dag_id [6960,6966]
===
match
---
operator: = [5987,5988]
operator: = [5973,5974]
===
match
---
atom_expr [9933,9948]
atom_expr [9919,9934]
===
match
---
string: 'dag_id' [5086,5094]
string: 'dag_id' [5072,5080]
===
match
---
operator: , [7379,7380]
operator: , [7365,7366]
===
match
---
atom_expr [7003,7022]
atom_expr [6989,7008]
===
match
---
argument [3137,3145]
argument [3131,3139]
===
match
---
name: command [4102,4109]
name: command [4096,4103]
===
match
---
name: sigint_handler [8956,8970]
name: sigint_handler [8942,8956]
===
match
---
name: k [5279,5280]
name: k [5265,5266]
===
match
---
fstring [9633,9692]
fstring [9619,9678]
===
match
---
import_from [1133,1180]
import_from [1118,1165]
===
match
---
arglist [5357,5594]
arglist [5343,5580]
===
match
---
name: k [5297,5298]
name: k [5283,5284]
===
match
---
trailer [9791,9798]
trailer [9777,9784]
===
match
---
import_from [7162,7195]
import_from [7148,7181]
===
match
---
trailer [9372,9434]
trailer [9358,9420]
===
match
---
name: dagbag [7264,7270]
name: dagbag [7250,7256]
===
match
---
name: provide_session [7626,7641]
name: provide_session [7612,7627]
===
match
---
string: """Returns DAG(s) matching a given regex or dag_id""" [7104,7157]
string: """Returns DAG(s) matching a given regex or dag_id""" [7090,7143]
===
match
---
name: DagBag [7273,7279]
name: DagBag [7259,7265]
===
match
---
not_test [8427,8434]
not_test [8413,8420]
===
match
---
simple_stmt [1427,1458]
simple_stmt [1421,1452]
===
match
---
name: threading [9481,9490]
name: threading [9467,9476]
===
match
---
suite [10879,11051]
suite [10865,11037]
===
match
---
simple_stmt [8003,8021]
simple_stmt [7989,8007]
===
match
---
atom_expr [9890,9922]
atom_expr [9876,9908]
===
match
---
operator: = [3282,3283]
operator: = [3276,3277]
===
match
---
atom_expr [8265,8326]
atom_expr [8251,8312]
===
match
---
operator: { [9826,9827]
operator: { [9812,9813]
===
match
---
dictorsetmaker [4683,4831]
dictorsetmaker [4677,4817]
===
match
---
name: dag_model [6289,6298]
name: dag_model [6275,6284]
===
match
---
expr_stmt [9439,9503]
expr_stmt [9425,9489]
===
match
---
name: re [7363,7365]
name: re [7349,7351]
===
match
---
suite [8435,8512]
suite [8421,8498]
===
match
---
name: metrics [5564,5571]
name: metrics [5550,5557]
===
match
---
for_stmt [9702,9923]
for_stmt [9688,9909]
===
match
---
parameters [6619,6655]
parameters [6605,6641]
===
match
---
trailer [8457,8462]
trailer [8443,8448]
===
match
---
name: kwargs [10541,10547]
name: kwargs [10527,10533]
===
match
---
name: get [5129,5132]
name: get [5115,5118]
===
match
---
atom_expr [7381,7391]
atom_expr [7367,7377]
===
match
---
operator: , [6201,6202]
operator: , [6187,6188]
===
match
---
suite [3434,5645]
suite [3428,5631]
===
match
---
name: ColorMode [10222,10231]
name: ColorMode [10208,10217]
===
match
---
operator: } [8319,8320]
operator: } [8305,8306]
===
match
---
import_as_names [1054,1102]
import_as_names [1039,1087]
===
match
---
number: 1 [4324,4325]
number: 1 [4318,4319]
===
match
---
name: metrics [3353,3360]
name: metrics [3347,3354]
===
match
---
trailer [9549,9565]
trailer [9535,9551]
===
match
---
name: os [8450,8452]
name: os [8436,8438]
===
match
---
not_test [1494,1502]
not_test [1488,1496]
===
match
---
atom_expr [3374,3390]
atom_expr [3368,3384]
===
match
---
atom_expr [5344,5600]
atom_expr [5330,5586]
===
match
---
operator: , [8299,8300]
operator: , [8285,8286]
===
match
---
name: settings [8788,8796]
name: settings [8774,8782]
===
match
---
arglist [3379,3389]
arglist [3373,3383]
===
match
---
name: full_command [3964,3976]
name: full_command [3958,3970]
===
match
---
name: values [7351,7357]
name: values [7337,7343]
===
match
---
name: utcnow [3293,3299]
name: utcnow [3287,3293]
===
match
---
name: vars [5034,5038]
name: vars [5020,5024]
===
match
---
trailer [5085,5095]
trailer [5071,5081]
===
match
---
simple_stmt [6037,6051]
simple_stmt [6023,6037]
===
match
---
argument [1356,1370]
argument [1350,1364]
===
match
---
atom_expr [5074,5095]
atom_expr [5060,5081]
===
match
---
trailer [6973,6981]
trailer [6959,6967]
===
match
---
trailer [8543,8551]
trailer [8529,8537]
===
match
---
operator: = [7800,7801]
operator: = [7786,7787]
===
match
---
operator: = [5032,5033]
operator: = [5018,5019]
===
match
---
operator: = [5424,5425]
operator: = [5410,5411]
===
match
---
simple_stmt [5210,5254]
simple_stmt [5196,5240]
===
match
---
name: tmp_dic [5121,5128]
name: tmp_dic [5107,5114]
===
match
---
atom_expr [6765,6787]
atom_expr [6751,6773]
===
match
---
simple_stmt [8683,8710]
simple_stmt [8669,8696]
===
match
---
param [7038,7060]
param [7024,7046]
===
match
---
name: dagbag [6586,6592]
name: dagbag [6572,6578]
===
match
---
fstring_start: f" [9902,9904]
fstring_start: f" [9888,9890]
===
match
---
dotted_name [10496,10511]
dotted_name [10482,10497]
===
match
---
fstring_string: Dumping stack traces for all threads in PID  [9375,9419]
fstring_string: Dumping stack traces for all threads in PID  [9361,9405]
===
match
---
fstring_string: .out [8320,8324]
fstring_string: .out [8306,8310]
===
match
---
simple_stmt [7900,7964]
simple_stmt [7886,7950]
===
match
---
name: DAGS_FOLDER [5959,5970]
name: DAGS_FOLDER [5945,5956]
===
match
---
trailer [5081,5085]
trailer [5067,5071]
===
match
---
param [10532,10538]
param [10518,10524]
===
match
---
fstring_string: ( [9678,9679]
fstring_string: ( [9664,9665]
===
match
---
operator: = [5563,5564]
operator: = [5549,5550]
===
match
---
name: disable [11027,11034]
name: disable [11013,11020]
===
match
---
operator: = [10077,10078]
operator: = [10063,10064]
===
match
---
decorated [7625,8021]
decorated [7611,8007]
===
match
---
fstring_expr [9679,9690]
fstring_expr [9665,9676]
===
match
---
operator: == [10274,10276]
operator: == [10260,10262]
===
match
---
name: sub_commands_to_check [4020,4041]
name: sub_commands_to_check [4014,4035]
===
match
---
operator: = [5478,5479]
operator: = [5464,5465]
===
match
---
name: TYPE_CHECKING [1054,1067]
name: TYPE_CHECKING [1039,1052]
===
match
---
trailer [4317,4326]
trailer [4311,4320]
===
match
---
name: sensitive_fields [4499,4515]
name: sensitive_fields [4493,4509]
===
match
---
fstring_string: ) [9690,9691]
fstring_string: ) [9676,9677]
===
match
---
expr_stmt [10042,10051]
expr_stmt [10028,10037]
===
match
---
name: ident [9456,9461]
name: ident [9442,9447]
===
match
---
suite [10291,10313]
suite [10277,10299]
===
match
---
trailer [5575,5593]
trailer [5561,5579]
===
match
---
name: path [8453,8457]
name: path [8439,8443]
===
match
---
funcdef [8596,8950]
funcdef [8582,8936]
===
match
---
name: T [1339,1340]
name: T [1333,1334]
===
match
---
trailer [7833,7860]
trailer [7819,7846]
===
match
---
trailer [7922,7963]
trailer [7908,7949]
===
match
---
name: color [10213,10218]
name: color [10199,10204]
===
match
---
operator: } [5331,5332]
operator: } [5317,5318]
===
match
---
arglist [5935,5970]
arglist [5921,5956]
===
match
---
string: """         An wrapper for cli functions. It assumes to have Namespace instance         at 1st positional argument          :param args: Positional argument. It assumes to have Namespace instance             at 1st positional argument         :param kwargs: A passthrough keyword argument         """ [2656,2956]
string: """         An wrapper for cli functions. It assumes to have Namespace instance         at 1st positional argument          :param args: Positional argument. It assumes to have Namespace instance             at 1st positional argument         :param kwargs: A passthrough keyword argument         """ [2650,2950]
===
match
---
name: color [10268,10273]
name: color [10254,10259]
===
match
---
not_test [7401,7417]
not_test [7387,7403]
===
match
---
atom [5302,5331]
atom [5288,5317]
===
match
---
dotted_name [1186,1199]
dotted_name [1171,1184]
===
match
---
import_from [1427,1457]
import_from [1421,1451]
===
match
---
arglist [4861,4881]
arglist [4847,4867]
===
match
---
trailer [8743,8753]
trailer [8729,8739]
===
match
---
name: DagPickle [7774,7783]
name: DagPickle [7760,7769]
===
match
---
name: dagbag [6529,6535]
name: dagbag [6515,6521]
===
match
---
name: event [5357,5362]
name: event [5343,5348]
===
match
---
string: "on" [10047,10051]
string: "on" [10033,10037]
===
match
---
return_stmt [5630,5644]
return_stmt [5616,5630]
===
match
---
trailer [8169,8174]
trailer [8155,8160]
===
match
---
operator: ** [3351,3353]
operator: ** [3345,3347]
===
match
---
name: extra [5456,5461]
name: extra [5442,5447]
===
match
---
simple_stmt [852,864]
simple_stmt [837,849]
===
match
---
name: log [8590,8593]
name: log [8576,8579]
===
match
---
name: _build_metrics [3397,3411]
name: _build_metrics [3391,3405]
===
match
---
operator: { [8496,8497]
operator: { [8482,8483]
===
match
---
string: "*" [4648,4651]
string: "*" [4642,4645]
===
match
---
atom_expr [5989,6032]
atom_expr [5975,6018]
===
match
---
name: bool [7085,7089]
name: bool [7071,7075]
===
match
---
trailer [7372,7392]
trailer [7358,7378]
===
match
---
dotted_name [2595,2610]
dotted_name [2589,2604]
===
match
---
name: on_pre_execution [3068,3084]
name: on_pre_execution [3062,3078]
===
match
---
name: dag_id [6643,6649]
name: dag_id [6629,6635]
===
match
---
name: metrics [5282,5289]
name: metrics [5268,5275]
===
match
---
name: k [5290,5291]
name: k [5276,5277]
===
match
---
name: thread_id [9526,9535]
name: thread_id [9512,9521]
===
match
---
funcdef [8023,8594]
funcdef [8009,8580]
===
match
---
funcdef [10088,10353]
funcdef [10074,10339]
===
match
---
param [8043,8051]
param [8029,8037]
===
match
---
trailer [8462,8511]
trailer [8448,8497]
===
match
---
trailer [7860,7866]
trailer [7846,7852]
===
match
---
string: 'execution_date' [5156,5172]
string: 'execution_date' [5142,5158]
===
match
---
tfpdef [6643,6654]
tfpdef [6629,6640]
===
match
---
name: sensitive_fields [3901,3917]
name: sensitive_fields [3895,3911]
===
match
---
trailer [10837,10854]
trailer [10823,10840]
===
match
---
name: line [9868,9872]
name: line [9854,9858]
===
match
---
name: subdir [7243,7249]
name: subdir [7229,7235]
===
match
---
name: e [3209,3210]
name: e [3203,3204]
===
match
---
trailer [3350,3361]
trailer [3344,3355]
===
match
---
atom_expr [8167,8228]
atom_expr [8153,8214]
===
match
---
fstring_start: f' [9799,9801]
fstring_start: f' [9785,9787]
===
match
---
expr_stmt [7968,7998]
expr_stmt [7954,7984]
===
match
---
operator: = [5342,5343]
operator: = [5328,5329]
===
match
---
trailer [8731,8743]
trailer [8717,8729]
===
match
---
fstring_start: f' [8486,8488]
fstring_start: f' [8472,8474]
===
match
---
fstring_string: but is  [1699,1706]
fstring_string: but is  [1693,1700]
===
match
---
atom_expr [10777,10793]
atom_expr [10763,10779]
===
match
---
name: ValueError [4898,4908]
name: ValueError [4884,4894]
===
match
---
raise_stmt [5832,5902]
raise_stmt [5818,5888]
===
match
---
name: append [9626,9632]
name: append [9612,9618]
===
match
---
atom_expr [1707,1720]
atom_expr [1701,1714]
===
match
---
atom_expr [5100,5118]
atom_expr [5086,5104]
===
match
---
simple_stmt [1339,1404]
simple_stmt [1333,1398]
===
match
---
operator: ** [10629,10631]
operator: ** [10615,10617]
===
match
---
trailer [8907,8921]
trailer [8893,8907]
===
match
---
operator: = [1361,1362]
operator: = [1355,1356]
===
match
---
trailer [5183,5187]
trailer [5169,5173]
===
match
---
suite [1486,1733]
suite [1480,1727]
===
match
---
atom_expr [3049,3095]
atom_expr [3043,3089]
===
match
---
simple_stmt [8885,8923]
simple_stmt [8871,8909]
===
match
---
atom_expr [10761,10794]
atom_expr [10747,10780]
===
match
---
trailer [8179,8228]
trailer [8165,8214]
===
match
---
atom_expr [7433,7598]
atom_expr [7419,7584]
===
match
---
name: os [8536,8538]
name: os [8522,8524]
===
match
---
operator: , [11069,11070]
operator: , [11055,11056]
===
match
---
fstring [9902,9921]
fstring [9888,9907]
===
match
---
name: args [1712,1716]
name: args [1706,1710]
===
match
---
simple_stmt [10244,10256]
simple_stmt [10230,10242]
===
match
---
expr_stmt [8683,8709]
expr_stmt [8669,8695]
===
match
---
name: f [10836,10837]
name: f [10822,10823]
===
match
---
trailer [6309,6321]
trailer [6295,6307]
===
match
---
atom_expr [9367,9434]
atom_expr [9353,9420]
===
match
---
trailer [8889,8898]
trailer [8875,8884]
===
match
---
name: kwargs [3139,3145]
name: kwargs [3133,3139]
===
match
---
simple_stmt [6749,6789]
simple_stmt [6735,6775]
===
match
---
param [9191,9196]
param [9177,9182]
===
match
---
string: 'user' [5433,5439]
string: 'user' [5419,5425]
===
match
---
simple_stmt [5024,5050]
simple_stmt [5010,5036]
===
match
---
arglist [1573,1591]
arglist [1567,1585]
===
match
---
operator: } [3958,3959]
operator: } [3952,3953]
===
match
---
name: os [6005,6007]
name: os [5991,5993]
===
match
---
name: args [10839,10843]
name: args [10825,10829]
===
match
---
name: action_logging [1739,1753]
name: action_logging [1733,1747]
===
match
---
simple_stmt [5054,5096]
simple_stmt [5040,5082]
===
match
---
operator: } [3895,3896]
operator: } [3889,3890]
===
match
---
operator: = [6555,6556]
operator: = [6541,6542]
===
match
---
name: filename [8614,8622]
name: filename [8600,8608]
===
match
---
argument [5419,5440]
argument [5405,5426]
===
match
---
suite [8342,8419]
suite [8328,8405]
===
match
---
suite [9968,10086]
suite [9954,10072]
===
match
---
name: strip [9912,9917]
name: strip [9898,9903]
===
match
---
operator: , [4707,4708]
operator: , [4701,4702]
===
match
---
trailer [5289,5292]
trailer [5275,5278]
===
match
---
suite [8624,8950]
suite [8610,8936]
===
match
---
atom_expr [10713,10744]
atom_expr [10699,10730]
===
match
---
name: query [7810,7815]
name: query [7796,7801]
===
match
---
trailer [7573,7580]
trailer [7559,7566]
===
match
---
suite [6822,6992]
suite [6808,6978]
===
match
---
import_name [820,836]
import_name [820,836]
===
match
---
simple_stmt [6364,6525]
simple_stmt [6350,6511]
===
match
---
simple_stmt [5630,5645]
simple_stmt [5616,5631]
===
match
---
fstring_start: f' [8301,8303]
fstring_start: f' [8287,8289]
===
match
---
name: format [7574,7580]
name: format [7560,7566]
===
match
---
trailer [11034,11050]
trailer [11020,11036]
===
match
---
trailer [7357,7359]
trailer [7343,7345]
===
match
---
name: bool [10119,10123]
name: bool [10105,10109]
===
match
---
trailer [8551,8556]
trailer [8537,8542]
===
match
---
name: args [10110,10114]
name: args [10096,10100]
===
match
---
trailer [7809,7815]
trailer [7795,7801]
===
match
---
fstring_end: ' [5380,5381]
fstring_end: ' [5366,5367]
===
match
---
name: namespace [4997,5006]
name: namespace [4983,4992]
===
match
---
name: subdir [5666,5672]
name: subdir [5652,5658]
===
match
---
atom_expr [8690,8709]
atom_expr [8676,8695]
===
match
---
name: matched_dags [7405,7417]
name: matched_dags [7391,7403]
===
match
---
trailer [7991,7998]
trailer [7977,7984]
===
match
---
suite [10124,10353]
suite [10110,10339]
===
match
---
expr_stmt [10072,10085]
expr_stmt [10058,10071]
===
match
---
operator: , [10843,10844]
operator: , [10829,10830]
===
match
---
operator: , [8086,8087]
operator: , [8072,8073]
===
match
---
dotted_name [1293,1314]
dotted_name [1287,1308]
===
match
---
operator: } [1720,1721]
operator: } [1714,1715]
===
match
---
suite [2647,3362]
suite [2641,3356]
===
match
---
string: '-p' [3921,3925]
string: '-p' [3915,3919]
===
match
---
atom_expr [4540,4581]
atom_expr [4534,4575]
===
match
---
argument [5450,5461]
argument [5436,5447]
===
match
---
name: pickle_dag [7968,7978]
name: pickle_dag [7954,7964]
===
match
---
suite [7689,8021]
suite [7675,8007]
===
match
---
fstring_start: f' [8393,8395]
fstring_start: f' [8379,8381]
===
match
---
param [6620,6642]
param [6606,6628]
===
match
---
expr_stmt [9508,9517]
expr_stmt [9494,9503]
===
match
---
atom_expr [5233,5253]
atom_expr [5219,5239]
===
match
---
simple_stmt [7308,7394]
simple_stmt [7294,7380]
===
match
---
name: extra [5259,5264]
name: extra [5245,5250]
===
match
---
trailer [7279,7303]
trailer [7265,7289]
===
match
---
parameters [8970,8982]
parameters [8956,8968]
===
match
---
trailer [9160,9163]
trailer [9146,9149]
===
match
---
try_stmt [10811,11051]
try_stmt [10797,11037]
===
match
---
operator: ** [3137,3139]
operator: ** [3131,3133]
===
match
---
suite [3108,3147]
suite [3102,3141]
===
match
---
trailer [3332,3350]
trailer [3326,3344]
===
match
---
name: Optional [1079,1087]
name: Optional [1064,1072]
===
insert-tree
---
simple_stmt [789,820]
    string: """Utilities module for cli""" [789,819]
to
file_input [789,11081]
at 0
===
insert-tree
---
simple_stmt [1211,1282]
    import_from [1211,1281]
        dotted_name [1216,1238]
            name: airflow [1216,1223]
            name: utils [1224,1229]
            name: platform [1230,1238]
        import_as_names [1246,1281]
            name: getuser [1246,1253]
            operator: , [1253,1254]
            name: is_terminal_support_colors [1255,1281]
to
file_input [789,11081]
at 19
===
move-tree
---
name: getuser [4821,4828]
to
atom_expr [4813,4830]
at 0
===
delete-tree
---
simple_stmt [789,820]
    string: """Utilities module for cli""" [789,819]
===
delete-tree
---
simple_stmt [837,852]
    import_name [837,851]
        name: getpass [844,851]
===
delete-tree
---
simple_stmt [1226,1288]
    import_from [1226,1287]
        dotted_name [1231,1253]
            name: airflow [1231,1238]
            name: utils [1239,1244]
            name: platform [1245,1253]
        name: is_terminal_support_colors [1261,1287]
===
delete-node
---
name: getpass [4813,4820]
===
===
delete-node
---
trailer [4820,4828]
===
