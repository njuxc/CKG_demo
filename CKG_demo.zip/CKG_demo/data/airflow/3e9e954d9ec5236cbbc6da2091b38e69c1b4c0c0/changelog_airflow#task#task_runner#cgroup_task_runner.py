===
match
---
trailer [3905,3967]
trailer [3925,3987]
===
match
---
name: path_element [4237,4249]
name: path_element [4257,4269]
===
match
---
name: process [8162,8169]
name: process [8182,8189]
===
match
---
expr_stmt [8890,8914]
expr_stmt [8910,8934]
===
match
---
string: "cpu" [5167,5172]
string: "cpu" [5187,5192]
===
match
---
atom_expr [8634,8653]
atom_expr [8654,8673]
===
match
---
name: self [6300,6304]
name: self [6320,6324]
===
match
---
suite [4570,4850]
suite [4590,4870]
===
match
---
name: node [4816,4820]
name: node [4836,4840]
===
match
---
atom_expr [5963,5977]
atom_expr [5983,5997]
===
match
---
name: name_to_node [3861,3873]
name: name_to_node [3881,3893]
===
match
---
name: self [8242,8246]
name: self [8262,8266]
===
match
---
name: resources [5968,5977]
name: resources [5988,5997]
===
match
---
trailer [6717,6790]
trailer [6737,6810]
===
match
---
expr_stmt [3109,3141]
expr_stmt [3137,3169]
===
match
---
name: path_split [3575,3585]
name: path_split [3595,3605]
===
match
---
trailer [7126,7134]
trailer [7146,7154]
===
match
---
simple_stmt [9000,9038]
simple_stmt [9020,9058]
===
match
---
trailer [8608,8624]
trailer [8628,8644]
===
match
---
name: trees [3489,3494]
name: trees [3509,3514]
===
match
---
name: lines [8890,8895]
name: lines [8910,8915]
===
match
---
operator: { [5781,5782]
operator: { [5801,5802]
===
match
---
name: node [4217,4221]
name: node [4237,4241]
===
match
---
atom_expr [8455,8479]
atom_expr [8475,8499]
===
match
---
and_test [5222,5276]
and_test [5242,5296]
===
match
---
simple_stmt [3891,3968]
simple_stmt [3911,3988]
===
match
---
name: resources [5951,5960]
name: resources [5971,5980]
===
match
---
operator: , [8258,8259]
operator: , [8278,8279]
===
match
---
operator: = [6651,6652]
operator: = [6671,6672]
===
match
---
string: "Setting %s with %s CPU shares" [6718,6749]
string: "Setting %s with %s CPU shares" [6738,6769]
===
match
---
name: debug [6345,6350]
name: debug [6365,6370]
===
match
---
name: path_element [4543,4555]
name: path_element [4563,4575]
===
match
---
trailer [4168,4173]
trailer [4188,4193]
===
match
---
name: cgroups [5428,5435]
name: cgroups [5448,5455]
===
match
---
name: _task_instance [5923,5937]
name: _task_instance [5943,5957]
===
match
---
name: file [8872,8876]
name: file [8892,8896]
===
match
---
trailer [6630,6650]
trailer [6650,6670]
===
match
---
name: _finished_running [2896,2913]
name: _finished_running [2924,2941]
===
match
---
suite [7099,8120]
suite [7119,8140]
===
match
---
name: subsystem_cgroup_map [9203,9223]
name: subsystem_cgroup_map [9223,9243]
===
match
---
name: x [4616,4617]
name: x [4636,4637]
===
match
---
comparison [7745,7763]
comparison [7765,7783]
===
match
---
name: group_name [9173,9183]
name: group_name [9193,9203]
===
match
---
name: self [8192,8196]
name: self [8212,8216]
===
match
---
operator: , [7034,7035]
operator: , [7054,7055]
===
match
---
param [8289,8293]
param [8309,8313]
===
match
---
atom_expr [8513,8533]
atom_expr [8533,8553]
===
match
---
simple_stmt [4894,4915]
simple_stmt [4914,4935]
===
match
---
name: mem_cgroup_node [6440,6455]
name: mem_cgroup_node [6460,6475]
===
match
---
operator: = [5961,5962]
operator: = [5981,5982]
===
match
---
expr_stmt [2962,2987]
expr_stmt [2990,3015]
===
match
---
trailer [6390,6406]
trailer [6410,6426]
===
match
---
string: "airflow/{}/{}" [5627,5642]
string: "airflow/{}/{}" [5647,5662]
===
match
---
name: cpu_cgroup_name [6756,6771]
name: cpu_cgroup_name [6776,6791]
===
match
---
trailer [5308,5314]
trailer [5328,5334]
===
match
---
name: self [6904,6908]
name: self [6924,6928]
===
match
---
name: local_task_job [2797,2811]
name: local_task_job [2825,2839]
===
match
---
name: debug [5309,5314]
name: debug [5329,5334]
===
match
---
arglist [6919,6983]
arglist [6939,7003]
===
match
---
name: self [8289,8293]
name: self [8309,8313]
===
match
---
suite [6690,6856]
suite [6710,6876]
===
match
---
name: local_task_job [2839,2853]
name: local_task_job [2867,2881]
===
match
---
parameters [8288,8294]
parameters [8308,8314]
===
match
---
comparison [6669,6689]
comparison [6689,6709]
===
match
---
suite [6323,6517]
suite [6343,6537]
===
match
---
name: _mem_mb_limit [2967,2980]
name: _mem_mb_limit [2995,3008]
===
match
---
comparison [6300,6322]
comparison [6320,6342]
===
match
---
trailer [8588,8603]
trailer [8608,8623]
===
match
---
suite [5287,5566]
suite [5307,5586]
===
match
---
name: self [8455,8459]
name: self [8475,8479]
===
match
---
simple_stmt [5951,6025]
simple_stmt [5971,6045]
===
match
---
name: self [6207,6211]
name: self [6227,6231]
===
match
---
with_item [8843,8876]
with_item [8863,8896]
===
match
---
name: uuid4 [5721,5726]
name: uuid4 [5741,5746]
===
match
---
name: self [3150,3154]
name: self [3178,3182]
===
match
---
operator: , [5446,5447]
operator: , [5466,5467]
===
match
---
simple_stmt [4058,4201]
simple_stmt [4078,4221]
===
match
---
name: _cur_user [3155,3164]
name: _cur_user [3183,3192]
===
match
---
expr_stmt [3482,3506]
expr_stmt [3502,3526]
===
match
---
suite [3586,4251]
suite [3606,4271]
===
match
---
name: error [7786,7791]
name: error [7806,7811]
===
match
---
expr_stmt [6257,6288]
expr_stmt [6277,6308]
===
match
---
atom_expr [6227,6247]
atom_expr [6247,6267]
===
match
---
name: cpu_cgroup_name [5809,5824]
name: cpu_cgroup_name [5829,5844]
===
match
---
operator: , [4299,4300]
operator: , [4319,4320]
===
match
---
dotted_name [1064,1091]
dotted_name [1092,1119]
===
match
---
simple_stmt [6440,6517]
simple_stmt [6460,6537]
===
match
---
simple_stmt [3109,3142]
simple_stmt [3137,3170]
===
match
---
atom_expr [3150,3164]
atom_expr [3178,3192]
===
match
---
trailer [6455,6466]
trailer [6475,6486]
===
match
---
atom_expr [8157,8169]
atom_expr [8177,8189]
===
match
---
if_stmt [4654,4850]
if_stmt [4674,4870]
===
match
---
trailer [8639,8641]
trailer [8659,8661]
===
match
---
operator: } [7067,7068]
operator: } [7087,7088]
===
match
---
operator: , [4969,4970]
operator: , [4989,4990]
===
match
---
trailer [5185,5189]
trailer [5205,5209]
===
match
---
simple_stmt [6067,6098]
simple_stmt [6087,6118]
===
match
---
trailer [3113,3133]
trailer [3141,3161]
===
match
---
return_stmt [4259,4270]
return_stmt [4279,4290]
===
match
---
trailer [8196,8204]
trailer [8216,8224]
===
match
---
name: cpus [6086,6090]
name: cpus [6106,6110]
===
match
---
operator: * [6091,6092]
operator: * [6111,6112]
===
match
---
trailer [5015,5020]
trailer [5035,5040]
===
match
---
parameters [5045,5051]
parameters [5065,5071]
===
match
---
strings [7809,8078]
strings [7829,8098]
===
match
---
name: shares [6830,6836]
name: shares [6850,6856]
===
match
---
atom_expr [4224,4250]
atom_expr [4244,4270]
===
match
---
atom [7025,7070]
atom [7045,7090]
===
match
---
simple_stmt [5513,5547]
simple_stmt [5533,5567]
===
match
---
atom_expr [3109,3133]
atom_expr [3137,3161]
===
match
---
atom_expr [6596,6616]
atom_expr [6616,6636]
===
match
---
operator: { [8950,8951]
operator: { [8970,8971]
===
match
---
trailer [4072,4200]
trailer [4092,4220]
===
match
---
param [7093,7097]
param [7113,7117]
===
match
---
name: log [8265,8268]
name: log [8285,8288]
===
match
---
expr_stmt [8927,8952]
expr_stmt [8947,8972]
===
match
---
name: debug [6913,6918]
name: debug [6933,6938]
===
match
---
comp_op [3854,3860]
comp_op [3874,3880]
===
match
---
expr_stmt [7108,7141]
expr_stmt [7128,7161]
===
match
---
name: process [7127,7134]
name: process [7147,7154]
===
match
---
operator: = [5825,5826]
operator: = [5845,5846]
===
match
---
expr_stmt [3068,3100]
expr_stmt [3096,3128]
===
match
---
name: log [4928,4931]
name: log [4948,4951]
===
match
---
funcdef [3190,4271]
funcdef [3210,4291]
===
match
---
name: self [4923,4927]
name: self [4943,4947]
===
match
---
string: "/" [4526,4529]
string: "/" [4546,4549]
===
match
---
operator: { [5833,5834]
operator: { [5853,5854]
===
match
---
if_stmt [6297,6517]
if_stmt [6317,6537]
===
match
---
suite [8877,9224]
suite [8897,9244]
===
match
---
simple_stmt [1004,1059]
simple_stmt [989,1044]
===
match
---
trailer [2867,2875]
trailer [2895,2903]
===
match
---
expr_stmt [4502,4530]
expr_stmt [4522,4550]
===
match
---
name: self [3891,3895]
name: self [3911,3915]
===
match
---
name: _mem_mb_limit [6111,6124]
name: _mem_mb_limit [6131,6144]
===
match
---
trailer [3995,4009]
trailer [4015,4029]
===
match
---
name: sep [3542,3545]
name: sep [3562,3565]
===
match
---
name: node [4164,4168]
name: node [4184,4188]
===
match
---
simple_stmt [8634,8654]
simple_stmt [8654,8674]
===
match
---
name: self [6227,6231]
name: self [6247,6251]
===
match
---
string: "Setting %s with %s MB of memory" [6351,6384]
string: "Setting %s with %s MB of memory" [6371,6404]
===
match
---
name: process [5518,5525]
name: process [5538,5545]
===
match
---
atom_expr [6626,6650]
atom_expr [6646,6670]
===
match
---
name: self [3209,3213]
name: self [3229,3233]
===
match
---
atom_expr [5300,5500]
atom_expr [5320,5520]
===
match
---
operator: = [9064,9065]
operator: = [9084,9085]
===
match
---
name: name [4976,4980]
name: name [4996,5000]
===
match
---
trailer [6412,6426]
trailer [6432,6446]
===
match
---
arglist [3906,3966]
arglist [3926,3986]
===
match
---
trailer [4996,5010]
trailer [5016,5030]
===
match
---
import_name [869,878]
import_name [854,863]
===
match
---
name: Resources [6013,6022]
name: Resources [6033,6042]
===
match
---
operator: , [5485,5486]
operator: , [5505,5506]
===
match
---
name: _finished_running [8388,8405]
name: _finished_running [8408,8425]
===
match
---
name: Resources [1049,1058]
name: Resources [1034,1043]
===
match
---
expr_stmt [3515,3546]
expr_stmt [3535,3566]
===
match
---
name: name_to_node [4677,4689]
name: name_to_node [4697,4709]
===
match
---
simple_stmt [5804,5848]
simple_stmt [5824,5868]
===
match
---
name: decode [5021,5027]
name: decode [5041,5047]
===
match
---
comparison [4657,4689]
comparison [4677,4709]
===
match
---
name: process [2868,2875]
name: process [2896,2903]
===
match
---
decorator [8659,8673]
decorator [8679,8693]
===
match
---
simple_stmt [6904,6985]
simple_stmt [6924,7005]
===
match
---
operator: , [5710,5711]
operator: , [5730,5731]
===
match
---
suite [3221,4271]
suite [3241,4291]
===
match
---
name: children [3816,3824]
name: children [3836,3844]
===
match
---
expr_stmt [6993,7071]
expr_stmt [7013,7091]
===
match
---
name: reap_process_group [1099,1117]
name: reap_process_group [1127,1145]
===
match
---
trailer [5435,5439]
trailer [5455,5459]
===
match
---
name: strftime [5690,5698]
name: strftime [5710,5718]
===
match
---
name: lines [8977,8982]
name: lines [8997,9002]
===
match
---
operator: } [4640,4641]
operator: } [4660,4661]
===
match
---
funcdef [8275,8654]
funcdef [8295,8674]
===
match
---
expr_stmt [4816,4849]
expr_stmt [4836,4869]
===
match
---
suite [8480,8535]
suite [8500,8555]
===
match
---
name: cpu_cgroup_node [6558,6573]
name: cpu_cgroup_node [6578,6593]
===
match
---
name: process [8197,8204]
name: process [8217,8224]
===
match
---
atom_expr [8843,8868]
atom_expr [8863,8888]
===
match
---
atom_expr [2863,2875]
atom_expr [2891,2903]
===
match
---
trailer [6912,6918]
trailer [6932,6938]
===
match
---
trailer [6022,6024]
trailer [6042,6044]
===
match
---
operator: = [6282,6283]
operator: = [6302,6303]
===
match
---
string: '-g' [7036,7040]
string: '-g' [7056,7060]
===
match
---
simple_stmt [5559,5566]
simple_stmt [5579,5586]
===
match
---
simple_stmt [906,934]
simple_stmt [891,919]
===
match
---
trailer [6054,6058]
trailer [6074,6078]
===
match
---
name: get [5256,5259]
name: get [5276,5279]
===
match
---
name: get [5436,5439]
name: get [5456,5459]
===
match
---
name: decode [4174,4180]
name: decode [4194,4200]
===
match
---
simple_stmt [3984,4024]
simple_stmt [4004,4044]
===
match
---
expr_stmt [5911,5942]
expr_stmt [5931,5962]
===
match
---
name: line_split [9000,9010]
name: line_split [9020,9030]
===
match
---
name: pid_exists [8181,8191]
name: pid_exists [8201,8211]
===
match
---
arglist [8242,8268]
arglist [8262,8288]
===
match
---
name: create_cgroup [3996,4009]
name: create_cgroup [4016,4029]
===
match
---
operator: , [6384,6385]
operator: , [6404,6405]
===
match
---
simple_stmt [8493,8535]
simple_stmt [8513,8555]
===
match
---
trailer [3494,3499]
trailer [3514,3519]
===
match
---
trailer [4975,4980]
trailer [4995,5000]
===
match
---
name: getuser [3175,3182]
name: getuser [3195,3202]
===
match
---
name: task [5981,5985]
name: task [6001,6005]
===
match
---
trailer [5304,5308]
trailer [5324,5328]
===
match
---
trailer [6755,6771]
trailer [6775,6791]
===
match
---
string: """         Create the specified cgroup.          :param path: The path of the cgroup to create.         E.g. cpu/mygroup/mysubgroup         :return: the Node associated with the created cgroup.         :rtype: cgroupspy.nodes.Node         """ [3230,3473]
string: """         Create the specified cgroup.          :param path: The path of the cgroup to create.         E.g. cpu/mygroup/mysubgroup         :return: the Node associated with the created cgroup.         :rtype: cgroupspy.nodes.Node         """ [3250,3493]
===
match
---
trailer [4009,4023]
trailer [4029,4043]
===
match
---
trailer [8497,8512]
trailer [8517,8532]
===
match
---
funcdef [8677,9224]
funcdef [8697,9244]
===
match
---
trailer [5010,5030]
trailer [5030,5050]
===
match
---
atom_expr [5222,5243]
atom_expr [5242,5263]
===
match
---
operator: , [4148,4149]
operator: , [4168,4169]
===
match
---
string: "/" [5273,5276]
string: "/" [5293,5296]
===
match
---
atom_expr [8383,8405]
atom_expr [8403,8425]
===
match
---
name: resources [5986,5995]
name: resources [6006,6015]
===
match
---
name: cpus [6033,6037]
name: cpus [6053,6057]
===
match
---
arglist [4938,4980]
arglist [4958,5000]
===
match
---
name: _mem_mb_limit [6489,6502]
name: _mem_mb_limit [6509,6522]
===
match
---
string: """     Runs the raw Airflow task in a cgroup that has containment for memory and     cpu. It uses the resource requirements defined in the task to construct     the settings for the cgroup.      Cgroup must be mounted first otherwise CgroupTaskRunner     will not be able to work.      cgroup-bin Ubuntu package must be installed to use cgexec command.      Note that this task runner will only work if the Airflow user has root privileges,     e.g. if the airflow user is called `airflow` then the following entries (or an even     less restrictive ones) are needed in the sudoers file (replacing     /CGROUPS_FOLDER with your system's cgroups folder, e.g. '/sys/fs/cgroup/'):     airflow ALL= (root) NOEXEC: /bin/chown /CGROUPS_FOLDER/memory/airflow/*     airflow ALL= (root) NOEXEC: !/bin/chown /CGROUPS_FOLDER/memory/airflow/*..*     airflow ALL= (root) NOEXEC: !/bin/chown /CGROUPS_FOLDER/memory/airflow/* *     airflow ALL= (root) NOEXEC: /bin/chown /CGROUPS_FOLDER/cpu/airflow/*     airflow ALL= (root) NOEXEC: !/bin/chown /CGROUPS_FOLDER/cpu/airflow/*..*     airflow ALL= (root) NOEXEC: !/bin/chown /CGROUPS_FOLDER/cpu/airflow/* *     airflow ALL= (root) NOEXEC: /bin/chmod /CGROUPS_FOLDER/memory/airflow/*     airflow ALL= (root) NOEXEC: !/bin/chmod /CGROUPS_FOLDER/memory/airflow/*..*     airflow ALL= (root) NOEXEC: !/bin/chmod /CGROUPS_FOLDER/memory/airflow/* *     airflow ALL= (root) NOEXEC: /bin/chmod /CGROUPS_FOLDER/cpu/airflow/*     airflow ALL= (root) NOEXEC: !/bin/chmod /CGROUPS_FOLDER/cpu/airflow/*..*     airflow ALL= (root) NOEXEC: !/bin/chmod /CGROUPS_FOLDER/cpu/airflow/* *     """ [1164,2772]
string: """     Runs the raw Airflow task in a cgroup that has containment for memory and     cpu. It uses the resource requirements defined in the task to construct     the settings for the cgroup.      Cgroup must be mounted first otherwise CgroupTaskRunner     will not be able to work.      cgroup-bin Ubuntu package must be installed to use cgexec command.      Note that this task runner will only work if the Airflow user has root privileges,     e.g. if the airflow user is called `airflow` then the following entries (or an even     less restrictive ones) are needed in the sudoers file (replacing     /CGROUPS_FOLDER with your system's cgroups folder, e.g. '/sys/fs/cgroup/'):     airflow ALL= (root) NOEXEC: /bin/chown /CGROUPS_FOLDER/memory/airflow/*     airflow ALL= (root) NOEXEC: !/bin/chown /CGROUPS_FOLDER/memory/airflow/*..*     airflow ALL= (root) NOEXEC: !/bin/chown /CGROUPS_FOLDER/memory/airflow/* *     airflow ALL= (root) NOEXEC: /bin/chown /CGROUPS_FOLDER/cpu/airflow/*     airflow ALL= (root) NOEXEC: !/bin/chown /CGROUPS_FOLDER/cpu/airflow/*..*     airflow ALL= (root) NOEXEC: !/bin/chown /CGROUPS_FOLDER/cpu/airflow/* *     airflow ALL= (root) NOEXEC: /bin/chmod /CGROUPS_FOLDER/memory/airflow/*     airflow ALL= (root) NOEXEC: !/bin/chmod /CGROUPS_FOLDER/memory/airflow/*..*     airflow ALL= (root) NOEXEC: !/bin/chmod /CGROUPS_FOLDER/memory/airflow/* *     airflow ALL= (root) NOEXEC: /bin/chmod /CGROUPS_FOLDER/cpu/airflow/*     airflow ALL= (root) NOEXEC: !/bin/chmod /CGROUPS_FOLDER/cpu/airflow/*..*     airflow ALL= (root) NOEXEC: !/bin/chmod /CGROUPS_FOLDER/cpu/airflow/* *     """ [1192,2800]
===
match
---
name: subsystem_cgroup_map [9139,9159]
name: subsystem_cgroup_map [9159,9179]
===
match
---
name: BaseTaskRunner [1143,1157]
name: BaseTaskRunner [1171,1185]
===
match
---
atom_expr [8898,8914]
atom_expr [8918,8934]
===
match
---
string: "Not creating cgroup %s in %s since it already exists" [4094,4148]
string: "Not creating cgroup %s in %s since it already exists" [4114,4168]
===
match
---
import_from [935,1003]
import_from [920,988]
===
match
---
comparison [5178,5203]
comparison [5198,5223]
===
match
---
expr_stmt [6106,6144]
expr_stmt [6126,6164]
===
match
---
name: node [3948,3952]
name: node [3968,3972]
===
match
---
operator: = [9107,9108]
operator: = [9127,9128]
===
match
---
trailer [7785,7791]
trailer [7805,7811]
===
match
---
name: debug [4932,4937]
name: debug [4952,4957]
===
match
---
trailer [8641,8651]
trailer [8661,8671]
===
match
---
operator: , [4961,4962]
operator: , [4981,4982]
===
match
---
simple_stmt [8223,8270]
simple_stmt [8243,8290]
===
match
---
atom_expr [6257,6281]
atom_expr [6277,6301]
===
match
---
name: psutil [899,905]
name: psutil [884,890]
===
match
---
name: decode [3790,3796]
name: decode [3810,3816]
===
match
---
name: parent [4990,4996]
name: parent [5010,5016]
===
match
---
fstring_end: " [5846,5847]
fstring_end: " [5866,5867]
===
match
---
trailer [6595,6617]
trailer [6615,6637]
===
match
---
trailer [4488,4493]
trailer [4508,4513]
===
match
---
operator: = [3017,3018]
operator: = [3045,3046]
===
match
---
trailer [4723,4758]
trailer [4743,4778]
===
match
---
atom_expr [4627,4640]
atom_expr [4647,4660]
===
match
---
name: path_element [3559,3571]
name: path_element [3579,3591]
===
match
---
name: split [3533,3538]
name: split [3553,3558]
===
match
---
atom_expr [5248,5269]
atom_expr [5268,5289]
===
match
---
atom_expr [5627,5739]
atom_expr [5647,5759]
===
match
---
simple_stmt [6803,6856]
simple_stmt [6823,6876]
===
match
---
atom_expr [8604,8624]
atom_expr [8624,8644]
===
match
---
trailer [8512,8534]
trailer [8532,8554]
===
match
---
atom_expr [6207,6248]
atom_expr [6227,6268]
===
match
---
for_stmt [8965,9184]
for_stmt [8985,9204]
===
match
---
name: root [4489,4493]
name: root [4509,4513]
===
match
---
operator: = [4596,4597]
operator: = [4616,4617]
===
match
---
operator: = [2914,2915]
operator: = [2942,2943]
===
match
---
operator: , [4751,4752]
operator: , [4771,4772]
===
match
---
name: readlines [8903,8912]
name: readlines [8923,8932]
===
match
---
name: open [8843,8847]
name: open [8863,8867]
===
match
---
with_stmt [8838,9224]
with_stmt [8858,9244]
===
match
---
name: uuid [886,890]
name: uuid [871,875]
===
match
---
atom [5154,5204]
atom [5174,5224]
===
match
---
operator: = [5116,5117]
operator: = [5136,5137]
===
match
---
name: _created_mem_cgroup [8460,8479]
name: _created_mem_cgroup [8480,8499]
===
match
---
name: _created_cpu_cgroup [8551,8570]
name: _created_cpu_cgroup [8571,8590]
===
match
---
simple_stmt [5613,5740]
simple_stmt [5633,5760]
===
match
---
atom_expr [5528,5546]
atom_expr [5548,5566]
===
match
---
trailer [5720,5726]
trailer [5740,5746]
===
match
---
trailer [2934,2946]
trailer [2962,2974]
===
match
---
operator: = [3093,3094]
operator: = [3121,3122]
===
match
---
trailer [5166,5173]
trailer [5186,5193]
===
match
---
atom_expr [3528,3546]
atom_expr [3548,3566]
===
match
---
expr_stmt [6558,6617]
expr_stmt [6578,6637]
===
match
---
simple_stmt [6189,6249]
simple_stmt [6209,6269]
===
match
---
string: "%Y-%m-%d" [5699,5709]
string: "%Y-%m-%d" [5719,5729]
===
match
---
name: trees [4476,4481]
name: trees [4496,4501]
===
match
---
name: line [9013,9017]
name: line [9033,9037]
===
match
---
expr_stmt [9000,9037]
expr_stmt [9020,9057]
===
match
---
fstring_string: cpu/ [5829,5833]
fstring_string: cpu/ [5849,5853]
===
match
---
trailer [6777,6789]
trailer [6797,6809]
===
match
---
name: cgroup_name [5834,5845]
name: cgroup_name [5854,5865]
===
match
---
name: get [5472,5475]
name: get [5492,5495]
===
match
---
atom_expr [8546,8570]
atom_expr [8566,8590]
===
match
---
name: return_code [7108,7119]
name: return_code [7128,7139]
===
match
---
operator: = [2947,2948]
operator: = [2975,2976]
===
match
---
name: path_element [3841,3853]
name: path_element [3861,3873]
===
match
---
trailer [4519,4525]
trailer [4539,4545]
===
match
---
name: log [4063,4066]
name: log [4083,4086]
===
match
---
trailer [4835,4849]
trailer [4855,4869]
===
match
---
trailer [8241,8269]
trailer [8261,8289]
===
match
---
name: self [7122,7126]
name: self [7142,7146]
===
match
---
simple_stmt [6106,6145]
simple_stmt [6126,6165]
===
match
---
simple_stmt [3150,3185]
simple_stmt [3178,3205]
===
match
---
simple_stmt [2962,2988]
simple_stmt [2990,3016]
===
match
---
string: """         :return: a mapping between the subsystem name to the cgroup name         :rtype: dict[str, str]         """ [8710,8829]
string: """         :return: a mapping between the subsystem name to the cgroup name         :rtype: dict[str, str]         """ [8730,8849]
===
match
---
atom [8950,8952]
atom [8970,8972]
===
match
---
trailer [9026,9032]
trailer [9046,9052]
===
match
---
operator: = [2876,2877]
operator: = [2904,2905]
===
match
---
name: x [3806,3807]
name: x [3826,3827]
===
match
---
trailer [6707,6711]
trailer [6727,6731]
===
match
---
name: _delete_cgroup [8498,8512]
name: _delete_cgroup [8518,8532]
===
match
---
trailer [5189,5196]
trailer [5209,5216]
===
match
---
name: path_element [4010,4022]
name: path_element [4030,4042]
===
match
---
atom_expr [6336,6427]
atom_expr [6356,6447]
===
match
---
atom_expr [8260,8268]
atom_expr [8280,8288]
===
match
---
number: 2 [9120,9121]
number: 2 [9140,9141]
===
match
---
name: self [6106,6110]
name: self [6126,6130]
===
match
---
name: datetime [845,853]
name: datetime [845,853]
===
match
---
trailer [8902,8912]
trailer [8922,8932]
===
match
---
atom_expr [9013,9037]
atom_expr [9033,9057]
===
match
---
trailer [6226,6248]
trailer [6246,6268]
===
match
---
trailer [4907,4914]
trailer [4927,4934]
===
match
---
atom_expr [3783,3798]
atom_expr [3803,3818]
===
match
---
name: os [876,878]
name: os [861,863]
===
match
---
trailer [6466,6481]
trailer [6486,6501]
===
match
---
name: _cpu_shares [6778,6789]
name: _cpu_shares [6798,6809]
===
match
---
name: group_name [9096,9106]
name: group_name [9116,9126]
===
match
---
expr_stmt [4469,4493]
expr_stmt [4489,4513]
===
match
---
trailer [4927,4931]
trailer [4947,4951]
===
match
---
name: terminate [8129,8138]
name: terminate [8149,8158]
===
match
---
expr_stmt [5951,6024]
expr_stmt [5971,6044]
===
match
---
test [5963,6024]
test [5983,6044]
===
match
---
trailer [6304,6318]
trailer [6324,6338]
===
match
---
expr_stmt [8383,8412]
expr_stmt [8403,8432]
===
match
---
simple_stmt [8383,8413]
simple_stmt [8403,8433]
===
match
---
name: self [3109,3113]
name: self [3137,3141]
===
match
---
name: mem_cgroup_name [5754,5769]
name: mem_cgroup_name [5774,5789]
===
match
---
string: "Deleting cgroup %s/%s" [4938,4961]
string: "Deleting cgroup %s/%s" [4958,4981]
===
match
---
name: self [8139,8143]
name: self [8159,8163]
===
match
---
dotted_name [1009,1041]
dotted_name [994,1026]
===
match
---
if_stmt [8543,8626]
if_stmt [8563,8646]
===
match
---
simple_stmt [6993,7072]
simple_stmt [7013,7092]
===
match
---
name: self [8513,8517]
name: self [8533,8537]
===
match
---
name: self [5918,5922]
name: self [5938,5942]
===
match
---
trailer [4605,4612]
trailer [4625,4632]
===
match
---
param [2797,2811]
param [2825,2839]
===
match
---
operator: = [8948,8949]
operator: = [8968,8969]
===
match
---
operator: @ [8659,8660]
operator: @ [8679,8680]
===
match
---
fstring_expr [5833,5846]
fstring_expr [5853,5866]
===
match
---
name: cpu_cgroup_name [6601,6616]
name: cpu_cgroup_name [6621,6636]
===
match
---
arglist [5663,5729]
arglist [5683,5749]
===
match
---
trailer [3532,3538]
trailer [3552,3558]
===
match
---
expr_stmt [5804,5847]
expr_stmt [5824,5867]
===
match
---
atom_expr [6773,6789]
atom_expr [6793,6809]
===
match
---
testlist_comp [7026,7069]
testlist_comp [7046,7089]
===
match
---
name: self [2791,2795]
name: self [2819,2823]
===
match
---
param [5046,5050]
param [5066,5070]
===
match
---
name: process [8247,8254]
name: process [8267,8274]
===
match
---
parameters [2790,2812]
parameters [2818,2840]
===
match
---
arglist [5332,5486]
arglist [5352,5506]
===
match
---
name: poll [7135,7139]
name: poll [7155,7159]
===
match
---
expr_stmt [3984,4023]
expr_stmt [4004,4043]
===
match
---
operator: = [3989,3990]
operator: = [4009,4010]
===
match
---
atom_expr [6408,6426]
atom_expr [6428,6446]
===
match
---
name: get [5163,5166]
name: get [5183,5186]
===
match
---
name: path [4169,4173]
name: path [4189,4193]
===
match
---
trailer [6829,6836]
trailer [6849,6856]
===
match
---
operator: , [6406,6407]
operator: , [6426,6427]
===
match
---
simple_stmt [935,1004]
simple_stmt [920,989]
===
match
---
trailer [2838,2854]
trailer [2866,2882]
===
match
---
operator: , [6970,6971]
operator: , [6990,6991]
===
match
---
fstring_expr [5781,5794]
fstring_expr [5801,5814]
===
match
---
atom_expr [3167,3184]
atom_expr [3195,3204]
===
match
---
trailer [5471,5475]
trailer [5491,5495]
===
match
---
trailer [8180,8191]
trailer [8200,8211]
===
match
---
trailer [8254,8258]
trailer [8274,8278]
===
match
---
atom_expr [5428,5446]
atom_expr [5448,5466]
===
match
---
expr_stmt [3150,3184]
expr_stmt [3178,3204]
===
match
---
trailer [3895,3899]
trailer [3915,3919]
===
match
---
and_test [8157,8209]
and_test [8177,8229]
===
match
---
trailer [5689,5698]
trailer [5709,5718]
===
match
---
atom_expr [6386,6406]
atom_expr [6406,6426]
===
match
---
simple_stmt [3767,3826]
simple_stmt [3787,3846]
===
match
---
expr_stmt [4217,4250]
expr_stmt [4237,4270]
===
match
---
name: root [3502,3506]
name: root [3522,3526]
===
match
---
atom_expr [7777,8092]
atom_expr [7797,8112]
===
match
---
name: name_to_node [4224,4236]
name: name_to_node [4244,4256]
===
match
---
simple_stmt [2822,2855]
simple_stmt [2850,2883]
===
match
---
simple_stmt [8927,8953]
simple_stmt [8947,8973]
===
match
---
simple_stmt [5108,5143]
simple_stmt [5128,5163]
===
match
---
name: super [8634,8639]
name: super [8654,8659]
===
match
---
expr_stmt [6803,6855]
expr_stmt [6823,6875]
===
match
---
name: mem_cgroup_name [8518,8533]
name: mem_cgroup_name [8538,8553]
===
match
---
operator: } [3824,3825]
operator: } [3844,3845]
===
match
---
fstring_start: f' [7042,7044]
fstring_start: f' [7062,7064]
===
match
---
expr_stmt [2930,2953]
expr_stmt [2958,2981]
===
match
---
operator: = [3134,3135]
operator: = [3162,3163]
===
match
---
atom_expr [5118,5142]
atom_expr [5138,5162]
===
match
---
operator: = [3526,3527]
operator: = [3546,3547]
===
match
---
fstring [7042,7069]
fstring [7062,7089]
===
match
---
name: _create_cgroup [3194,3208]
name: _create_cgroup [3214,3228]
===
match
---
parameters [3208,3220]
parameters [3228,3240]
===
match
---
name: self [2863,2867]
name: self [2891,2895]
===
match
---
operator: = [5625,5626]
operator: = [5645,5646]
===
match
---
operator: * [6510,6511]
operator: * [6530,6531]
===
match
---
name: self [3032,3036]
name: self [3060,3064]
===
match
---
trailer [5140,5142]
trailer [5160,5162]
===
match
---
fstring_expr [7055,7068]
fstring_expr [7075,7088]
===
match
---
return_stmt [9196,9223]
return_stmt [9216,9243]
===
match
---
trailer [5439,5446]
trailer [5459,5466]
===
match
---
simple_stmt [6626,6658]
simple_stmt [6646,6678]
===
match
---
arglist [6718,6789]
arglist [6738,6809]
===
match
---
trailer [4631,4640]
trailer [4651,4660]
===
match
---
name: self [3068,3072]
name: self [3096,3100]
===
match
---
trailer [4180,4182]
trailer [4200,4202]
===
match
---
name: subsystem_cgroup_map [8927,8947]
name: subsystem_cgroup_map [8947,8967]
===
match
---
trailer [8847,8868]
trailer [8867,8888]
===
match
---
atom_expr [5155,5173]
atom_expr [5175,5193]
===
match
---
name: name_to_node [3767,3779]
name: name_to_node [3787,3799]
===
match
---
trailer [6580,6595]
trailer [6600,6615]
===
match
---
name: on_finish [8642,8651]
name: on_finish [8662,8671]
===
match
---
name: cpu_cgroup_node [6803,6818]
name: cpu_cgroup_node [6823,6838]
===
match
---
fstring_end: " [5794,5795]
fstring_end: " [5814,5815]
===
match
---
name: ram [6137,6140]
name: ram [6157,6160]
===
match
---
trailer [8387,8405]
trailer [8407,8425]
===
match
---
name: operator_resources [1023,1041]
name: operator_resources [1008,1026]
===
match
---
atom [3782,3825]
atom [3802,3845]
===
match
---
name: children [4632,4640]
name: children [4652,4660]
===
match
---
simple_stmt [5749,5796]
simple_stmt [5769,5816]
===
match
---
operator: = [7120,7121]
operator: = [7140,7141]
===
match
---
simple_stmt [2891,2922]
simple_stmt [2919,2950]
===
match
---
name: line_split [9066,9076]
name: line_split [9086,9096]
===
match
---
atom_expr [3068,3092]
atom_expr [3096,3120]
===
match
---
operator: = [5770,5771]
operator: = [5790,5791]
===
match
---
trailer [6918,6984]
trailer [6938,7004]
===
match
---
simple_stmt [7108,7142]
simple_stmt [7128,7162]
===
match
---
name: self [6669,6673]
name: self [6689,6693]
===
match
---
name: controller [6819,6829]
name: controller [6839,6849]
===
match
---
trailer [8550,8570]
trailer [8570,8590]
===
match
---
name: self [8260,8264]
name: self [8280,8284]
===
match
---
operator: = [3053,3054]
operator: = [3081,3082]
===
match
---
expr_stmt [6033,6058]
expr_stmt [6053,6078]
===
match
---
trailer [5985,5995]
trailer [6005,6015]
===
match
---
simple_stmt [2863,2883]
simple_stmt [2891,2911]
===
match
---
simple_stmt [6257,6289]
simple_stmt [6277,6309]
===
match
---
trailer [9017,9024]
trailer [9037,9044]
===
match
---
comparison [5981,6007]
comparison [6001,6027]
===
match
---
atom_expr [8493,8534]
atom_expr [8513,8554]
===
match
---
atom_expr [4903,4914]
atom_expr [4923,4934]
===
match
---
name: _cpu_shares [6674,6685]
name: _cpu_shares [6694,6705]
===
match
---
atom_expr [4707,4758]
atom_expr [4727,4778]
===
match
---
expr_stmt [6626,6657]
expr_stmt [6646,6677]
===
match
---
simple_stmt [2930,2954]
simple_stmt [2958,2982]
===
match
---
trailer [6908,6912]
trailer [6928,6932]
===
match
---
if_stmt [8452,8535]
if_stmt [8472,8555]
===
match
---
name: self [8604,8608]
name: self [8624,8628]
===
match
---
funcdef [8125,8270]
funcdef [8145,8290]
===
match
---
atom_expr [8584,8625]
atom_expr [8604,8645]
===
match
---
name: start [5040,5045]
name: start [5060,5065]
===
match
---
trailer [7012,7024]
trailer [7032,7044]
===
match
---
trailer [9076,9079]
trailer [9096,9099]
===
match
---
string: "memory" [5260,5268]
string: "memory" [5280,5288]
===
match
---
atom_expr [9109,9122]
atom_expr [9129,9142]
===
match
---
atom_expr [5716,5728]
atom_expr [5736,5748]
===
match
---
name: _cpu_shares [6844,6855]
name: _cpu_shares [6864,6875]
===
match
---
name: resources [6127,6136]
name: resources [6147,6156]
===
match
---
trailer [4486,4488]
trailer [4506,4508]
===
match
---
name: cpu_cgroup_name [8609,8624]
name: cpu_cgroup_name [8629,8644]
===
match
---
simple_stmt [2996,3024]
simple_stmt [3024,3052]
===
match
---
name: controller [6456,6466]
name: controller [6476,6486]
===
match
---
suite [1159,9224]
suite [1187,9244]
===
match
---
name: log [6708,6711]
name: log [6728,6731]
===
match
---
simple_stmt [4990,5031]
simple_stmt [5010,5051]
===
match
---
name: return_code [7745,7756]
name: return_code [7765,7776]
===
match
---
string: "Cgroup does not exist: %s" [4724,4751]
string: "Cgroup does not exist: %s" [4744,4771]
===
match
---
atom_expr [5513,5525]
atom_expr [5533,5545]
===
match
---
name: __init__ [2830,2838]
name: __init__ [2858,2866]
===
match
---
name: mem_cgroup_name [6391,6406]
name: mem_cgroup_name [6411,6426]
===
match
---
trailer [8603,8625]
trailer [8623,8645]
===
match
---
simple_stmt [6703,6791]
simple_stmt [6723,6811]
===
match
---
name: self [6257,6261]
name: self [6277,6281]
===
match
---
trailer [4236,4250]
trailer [4256,4270]
===
match
---
operator: } [5845,5846]
operator: } [5865,5866]
===
match
---
trailer [3501,3506]
trailer [3521,3526]
===
match
---
if_stmt [3838,4251]
if_stmt [3858,4271]
===
match
---
name: path [3953,3957]
name: path [3973,3977]
===
match
---
name: path_split [4502,4512]
name: path_split [4522,4532]
===
match
---
arglist [6351,6426]
arglist [6371,6446]
===
match
---
name: self [6773,6777]
name: self [6793,6797]
===
match
---
name: return_code [8108,8119]
name: return_code [8128,8139]
===
match
---
atom_expr [6576,6617]
atom_expr [6596,6637]
===
match
---
simple_stmt [9196,9224]
simple_stmt [9216,9244]
===
match
---
name: cpus [6050,6054]
name: cpus [6070,6074]
===
match
---
trailer [8912,8914]
trailer [8932,8934]
===
match
---
operator: = [6038,6039]
operator: = [6058,6059]
===
match
---
name: mem_cgroup_name [3001,3016]
name: mem_cgroup_name [3029,3044]
===
match
---
name: airflow [1009,1016]
name: airflow [994,1001]
===
match
---
expr_stmt [5749,5795]
expr_stmt [5769,5815]
===
match
---
operator: = [6574,6575]
operator: = [6594,6595]
===
match
---
name: path_split [3515,3525]
name: path_split [3535,3545]
===
match
---
trailer [8161,8169]
trailer [8181,8189]
===
match
---
trailer [6261,6281]
trailer [6281,6301]
===
match
---
fstring_start: f" [5827,5829]
fstring_start: f" [5847,5849]
===
match
---
for_stmt [3555,4251]
for_stmt [3575,4271]
===
match
---
operator: = [6837,6838]
operator: = [6857,6858]
===
match
---
atom_expr [2930,2946]
atom_expr [2958,2974]
===
match
---
operator: > [6319,6320]
operator: > [6339,6340]
===
match
---
atom_expr [4058,4200]
atom_expr [4078,4220]
===
match
---
name: parent [4908,4914]
name: parent [4928,4934]
===
match
---
atom_expr [2996,3016]
atom_expr [3024,3044]
===
match
---
name: rstrip [9018,9024]
name: rstrip [9038,9044]
===
match
---
atom_expr [5712,5729]
atom_expr [5732,5749]
===
match
---
atom_expr [2891,2913]
atom_expr [2919,2941]
===
match
---
atom_expr [4823,4849]
atom_expr [4843,4869]
===
match
---
operator: = [3165,3166]
operator: = [3193,3194]
===
match
---
name: datetime [5672,5680]
name: datetime [5692,5700]
===
match
---
name: x [3783,3784]
name: x [3803,3804]
===
match
---
trailer [4062,4066]
trailer [4082,4086]
===
match
---
name: self [5300,5304]
name: self [5320,5324]
===
match
---
name: _cpu_shares [6072,6083]
name: _cpu_shares [6092,6103]
===
match
---
dictorsetmaker [4599,4640]
dictorsetmaker [4619,4660]
===
match
---
string: "cpu" [5190,5195]
string: "cpu" [5210,5215]
===
match
---
import_from [1059,1117]
import_from [1087,1145]
===
match
---
if_stmt [8154,8270]
if_stmt [8174,8290]
===
match
---
trailer [2966,2980]
trailer [2994,3008]
===
match
---
name: debug [3900,3905]
name: debug [3920,3925]
===
match
---
name: self [6993,6997]
name: self [7013,7017]
===
match
---
trailer [7139,7141]
trailer [7159,7161]
===
match
---
operator: = [4901,4902]
operator: = [4921,4922]
===
match
---
expr_stmt [9096,9122]
expr_stmt [9116,9142]
===
match
---
expr_stmt [6067,6097]
expr_stmt [6087,6117]
===
match
---
expr_stmt [4583,4641]
expr_stmt [4603,4661]
===
match
---
name: self [8584,8588]
name: self [8604,8608]
===
match
---
atom_expr [8242,8258]
atom_expr [8262,8278]
===
match
---
number: 0 [6688,6689]
number: 0 [6708,6709]
===
match
---
simple_stmt [788,837]
simple_stmt [788,837]
===
match
---
atom_expr [9066,9079]
atom_expr [9086,9099]
===
match
---
trailer [5967,5977]
trailer [5987,5997]
===
match
---
atom_expr [3948,3966]
atom_expr [3968,3986]
===
match
---
trailer [4600,4605]
trailer [4620,4625]
===
match
---
trailer [6231,6247]
trailer [6251,6267]
===
match
---
name: path [3215,3219]
name: path [3235,3239]
===
match
---
atom_expr [5804,5824]
atom_expr [5824,5844]
===
match
---
simple_stmt [3068,3101]
simple_stmt [3096,3129]
===
match
---
name: node [3984,3988]
name: node [4004,4008]
===
match
---
simple_stmt [892,906]
simple_stmt [877,891]
===
match
---
operator: , [3213,3214]
operator: , [3233,3234]
===
match
---
name: self [8493,8497]
name: self [8513,8517]
===
match
---
string: 'cgexec' [7026,7034]
string: 'cgexec' [7046,7054]
===
match
---
operator: , [6771,6772]
operator: , [6791,6792]
===
match
---
trailer [3000,3016]
trailer [3028,3044]
===
match
---
name: log [6909,6912]
name: log [6929,6932]
===
match
---
simple_stmt [879,891]
simple_stmt [864,876]
===
match
---
atom_expr [2822,2854]
atom_expr [2850,2882]
===
match
---
trailer [8651,8653]
trailer [8671,8673]
===
match
---
trailer [4481,4486]
trailer [4501,4506]
===
match
---
name: node [3482,3486]
name: node [3502,3506]
===
match
---
name: path_element [3934,3946]
name: path_element [3954,3966]
===
match
---
name: cgroup_name [5782,5793]
name: cgroup_name [5802,5813]
===
match
---
name: format [5643,5649]
name: format [5663,5669]
===
match
---
atom_expr [3991,4023]
atom_expr [4011,4043]
===
match
---
name: self [6408,6412]
name: self [6428,6432]
===
match
---
number: 1024 [6512,6516]
number: 1024 [6532,6536]
===
match
---
name: path [4753,4757]
name: path [4773,4777]
===
match
---
name: utils [1017,1022]
name: utils [1002,1007]
===
match
---
atom_expr [3891,3967]
atom_expr [3911,3987]
===
match
---
import_from [906,933]
import_from [891,918]
===
match
---
expr_stmt [5513,5546]
expr_stmt [5533,5566]
===
match
---
name: self [5046,5050]
name: self [5066,5070]
===
match
---
operator: { [4598,4599]
operator: { [4618,4619]
===
match
---
name: self [8546,8550]
name: self [8566,8570]
===
match
---
name: subsystem [9054,9063]
name: subsystem [9074,9083]
===
match
---
atom_expr [6067,6083]
atom_expr [6087,6103]
===
match
---
name: self [5118,5122]
name: self [5138,5142]
===
match
---
trailer [5027,5029]
trailer [5047,5049]
===
match
---
string: "that it was killed due to excessive memory usage. " [7883,7935]
string: "that it was killed due to excessive memory usage. " [7903,7955]
===
match
---
name: cpu_cgroup_name [3037,3052]
name: cpu_cgroup_name [3065,3080]
===
match
---
operator: , [3932,3933]
operator: , [3952,3953]
===
match
---
atom_expr [6300,6318]
atom_expr [6320,6338]
===
match
---
name: split [4520,4525]
name: split [4540,4545]
===
match
---
trailer [9024,9026]
trailer [9044,9046]
===
match
---
name: _get_cgroup_names [5123,5140]
name: _get_cgroup_names [5143,5160]
===
match
---
operator: = [6482,6483]
operator: = [6502,6503]
===
match
---
name: process [6998,7005]
name: process [7018,7025]
===
match
---
name: str [5712,5715]
name: str [5732,5735]
===
match
---
atom_expr [6669,6685]
atom_expr [6689,6705]
===
match
---
funcdef [7077,8120]
funcdef [7097,8140]
===
match
---
trailer [3072,3092]
trailer [3100,3120]
===
match
---
trailer [3957,3964]
trailer [3977,3984]
===
match
---
name: warning [4716,4723]
name: warning [4736,4743]
===
match
---
name: file [8898,8902]
name: file [8918,8922]
===
match
---
trailer [5255,5259]
trailer [5275,5279]
===
match
---
name: process_utils [1078,1091]
name: process_utils [1106,1119]
===
match
---
simple_stmt [8710,8830]
simple_stmt [8730,8850]
===
match
---
trailer [5475,5485]
trailer [5495,5505]
===
match
---
operator: = [6084,6085]
operator: = [6104,6105]
===
match
---
name: run_command [5533,5544]
name: run_command [5553,5564]
===
match
---
atom_expr [9139,9170]
atom_expr [9159,9190]
===
match
---
string: "Creating cgroup %s in %s" [3906,3932]
string: "Creating cgroup %s in %s" [3926,3952]
===
match
---
param [3209,3214]
param [3229,3234]
===
match
---
atom_expr [3811,3824]
atom_expr [3831,3844]
===
match
---
dotted_name [940,981]
dotted_name [925,966]
===
match
---
trailer [2895,2913]
trailer [2923,2941]
===
match
---
name: cgroup_name [6972,6983]
name: cgroup_name [6992,7003]
===
match
---
fstring_string: cpu,memory: [7044,7055]
fstring_string: cpu,memory: [7064,7075]
===
match
---
import_from [1004,1058]
import_from [989,1043]
===
match
---
name: self [7093,7097]
name: self [7113,7117]
===
match
---
name: path [4515,4519]
name: path [4535,4539]
===
match
---
name: name_to_node [4583,4595]
name: name_to_node [4603,4615]
===
match
---
name: self [6703,6707]
name: self [6723,6727]
===
match
---
name: mem_cgroup_name [6232,6247]
name: mem_cgroup_name [6252,6267]
===
match
---
name: utils [1072,1077]
name: utils [1100,1105]
===
match
---
trailer [5229,5233]
trailer [5249,5253]
===
match
---
name: cgroups [5248,5255]
name: cgroups [5268,5275]
===
match
---
expr_stmt [3032,3059]
expr_stmt [3060,3087]
===
match
---
operator: = [4513,4514]
operator: = [4533,4534]
===
match
---
name: self [6576,6580]
name: self [6596,6600]
===
match
---
trailer [2827,2829]
trailer [2855,2857]
===
match
---
atom_expr [6803,6836]
atom_expr [6823,6856]
===
match
---
atom_expr [4923,4981]
atom_expr [4943,5001]
===
match
---
atom [4598,4641]
atom [4618,4661]
===
match
---
atom_expr [4990,5030]
atom_expr [5010,5050]
===
match
---
comp_op [5996,6002]
comp_op [6016,6022]
===
match
---
parameters [7092,7098]
parameters [7112,7118]
===
match
---
suite [8210,8270]
suite [8230,8290]
===
match
---
name: reap_process_group [8223,8241]
name: reap_process_group [8243,8261]
===
match
---
trailer [5517,5525]
trailer [5537,5545]
===
match
---
name: resources [6040,6049]
name: resources [6060,6069]
===
match
---
number: 1024 [6093,6097]
number: 1024 [6113,6117]
===
match
---
trailer [6711,6717]
trailer [6731,6737]
===
match
---
atom_expr [5918,5942]
atom_expr [5938,5962]
===
match
---
name: Tree [4482,4486]
name: Tree [4502,4506]
===
match
---
name: self [7777,7781]
name: self [7797,7801]
===
match
---
name: self [2996,3000]
name: self [3024,3028]
===
match
---
name: self [4058,4062]
name: self [4078,4082]
===
match
---
import_name [838,853]
import_name [838,853]
===
match
---
trailer [5753,5769]
trailer [5773,5789]
===
match
---
atom_expr [6013,6024]
atom_expr [6033,6044]
===
match
---
operator: = [9011,9012]
operator: = [9031,9032]
===
match
---
name: self [2930,2934]
name: self [2958,2962]
===
match
---
name: self [2962,2966]
name: self [2990,2994]
===
match
---
name: cgroup_name [5613,5624]
name: cgroup_name [5633,5644]
===
match
---
name: pid [8255,8258]
name: pid [8275,8278]
===
match
---
name: on_finish [8279,8288]
name: on_finish [8299,8308]
===
match
---
trailer [3541,3545]
trailer [3561,3565]
===
match
---
name: _created_mem_cgroup [6262,6281]
name: _created_mem_cgroup [6282,6301]
===
match
---
name: cgroups [5178,5185]
name: cgroups [5198,5205]
===
match
---
param [2791,2796]
param [2819,2824]
===
match
---
atom_expr [7008,7071]
atom_expr [7028,7091]
===
match
---
name: node [3991,3995]
name: node [4011,4015]
===
match
---
name: node [5011,5015]
name: node [5031,5035]
===
match
---
trailer [4066,4072]
trailer [4086,4092]
===
match
---
trailer [7791,8092]
trailer [7811,8112]
===
match
---
return_stmt [8101,8119]
return_stmt [8121,8139]
===
match
---
name: self [6484,6488]
name: self [6504,6508]
===
match
---
operator: = [5916,5917]
operator: = [5936,5937]
===
match
---
name: x [4599,4600]
name: x [4619,4620]
===
match
---
name: datetime [5663,5671]
name: datetime [5683,5691]
===
match
---
name: self [6751,6755]
name: self [6771,6775]
===
match
---
name: _delete_cgroup [4280,4294]
name: _delete_cgroup [4300,4314]
===
match
---
simple_stmt [4469,4494]
simple_stmt [4489,4514]
===
match
---
string: "memory" [5234,5242]
string: "memory" [5254,5262]
===
match
---
name: self [5528,5532]
name: self [5548,5552]
===
match
---
name: psutil [8174,8180]
name: psutil [8194,8200]
===
match
---
arglist [4094,4182]
arglist [4114,4202]
===
match
---
dictorsetmaker [3783,3824]
dictorsetmaker [3803,3844]
===
match
---
trailer [6344,6350]
trailer [6364,6370]
===
match
---
fstring_end: ' [7068,7069]
fstring_end: ' [7088,7089]
===
match
---
name: delete_cgroup [4997,5010]
name: delete_cgroup [5017,5030]
===
match
---
parameters [4294,4306]
parameters [4314,4326]
===
match
---
name: cgroups [5222,5229]
name: cgroups [5242,5249]
===
match
---
operator: = [8896,8897]
operator: = [8916,8917]
===
match
---
fstring [5772,5795]
fstring [5792,5815]
===
match
---
name: debug [6712,6717]
name: debug [6732,6737]
===
match
---
atom_expr [4164,4182]
atom_expr [4184,4202]
===
match
---
trailer [4711,4715]
trailer [4731,4735]
===
match
---
trailer [6340,6344]
trailer [6360,6364]
===
match
---
if_stmt [5151,5566]
if_stmt [5171,5586]
===
match
---
atom_expr [5178,5196]
atom_expr [5198,5216]
===
match
---
parameters [8698,8700]
parameters [8718,8720]
===
match
---
name: self [2891,2895]
name: self [2919,2923]
===
match
---
atom_expr [5464,5485]
atom_expr [5484,5505]
===
match
---
atom_expr [6040,6058]
atom_expr [6060,6078]
===
match
---
name: self [6839,6843]
name: self [6859,6863]
===
match
---
trailer [3538,3546]
trailer [3558,3566]
===
match
---
atom_expr [6839,6855]
atom_expr [6859,6875]
===
match
---
suite [4307,5031]
suite [4327,5051]
===
match
---
simple_stmt [5911,5943]
simple_stmt [5931,5963]
===
match
---
string: """         Delete the specified cgroup.          :param path: The path of the cgroup to delete.         E.g. cpu/mygroup/mysubgroup         """ [4316,4460]
string: """         Delete the specified cgroup.          :param path: The path of the cgroup to delete.         E.g. cpu/mygroup/mysubgroup         """ [4336,4480]
===
match
---
param [8139,8143]
param [8159,8163]
===
match
---
name: task_runner [953,964]
name: task_runner [938,949]
===
match
---
atom_expr [5011,5029]
atom_expr [5031,5049]
===
match
---
name: _mem_mb_limit [6413,6426]
name: _mem_mb_limit [6433,6446]
===
match
---
name: pid [8205,8208]
name: pid [8225,8228]
===
match
---
operator: } [5793,5794]
operator: } [5813,5814]
===
match
---
atom_expr [8223,8269]
atom_expr [8243,8289]
===
match
---
simple_stmt [8890,8915]
simple_stmt [8910,8935]
===
match
---
trailer [6997,7005]
trailer [7017,7025]
===
match
---
name: self [5513,5517]
name: self [5533,5537]
===
match
---
trailer [3784,3789]
trailer [3804,3809]
===
match
---
name: line [8969,8973]
name: line [8989,8993]
===
match
---
trailer [6136,6140]
trailer [6156,6160]
===
match
---
string: "Already running in a cgroup (cpu: %s memory: %s) so not creating another one" [5332,5410]
string: "Already running in a cgroup (cpu: %s memory: %s) so not creating another one" [5352,5430]
===
match
---
simple_stmt [838,854]
simple_stmt [838,854]
===
match
---
name: _get_cgroup_names [8681,8698]
name: _get_cgroup_names [8701,8718]
===
match
---
operator: , [4162,4163]
operator: , [4182,4183]
===
match
---
trailer [6140,6144]
trailer [6160,6164]
===
match
---
funcdef [4276,5031]
funcdef [4296,5051]
===
match
---
trailer [3952,3957]
trailer [3972,3977]
===
match
---
operator: = [6205,6206]
operator: = [6225,6226]
===
match
---
simple_stmt [4816,4850]
simple_stmt [4836,4870]
===
match
---
operator: = [4474,4475]
operator: = [4494,4495]
===
match
---
trailer [5314,5500]
trailer [5334,5520]
===
match
---
name: staticmethod [8660,8672]
name: staticmethod [8680,8692]
===
match
---
name: self [7008,7012]
name: self [7028,7032]
===
match
---
trailer [3499,3501]
trailer [3519,3521]
===
match
---
suite [4041,4251]
suite [4061,4271]
===
match
---
name: path_element [4836,4848]
name: path_element [4856,4868]
===
match
---
operator: == [7757,7759]
operator: == [7777,7779]
===
match
---
trailer [6843,6855]
trailer [6863,6875]
===
match
---
suite [8295,8654]
suite [8315,8674]
===
match
---
name: CgroupTaskRunner [1126,1142]
name: CgroupTaskRunner [1154,1170]
===
match
---
simple_stmt [1059,1118]
simple_stmt [1087,1146]
===
match
---
name: node [4971,4975]
name: node [4991,4995]
===
match
---
name: _mem_mb_limit [6305,6318]
name: _mem_mb_limit [6325,6338]
===
match
---
simple_stmt [4217,4251]
simple_stmt [4237,4271]
===
match
---
number: 0 [6321,6322]
number: 0 [6341,6342]
===
match
---
name: self [6596,6600]
name: self [6616,6620]
===
match
---
trailer [9159,9170]
trailer [9179,9190]
===
match
---
suite [8145,8270]
suite [8165,8290]
===
match
---
name: task [948,952]
name: task [933,937]
===
match
---
simple_stmt [7777,8093]
simple_stmt [7797,8113]
===
match
---
name: trees [928,933]
name: trees [913,918]
===
match
---
name: self [6626,6630]
name: self [6646,6650]
===
match
---
simple_stmt [4502,4531]
simple_stmt [4522,4551]
===
match
---
simple_stmt [869,879]
simple_stmt [854,864]
===
match
---
name: self [4295,4299]
name: self [4315,4319]
===
match
---
operator: = [3780,3781]
operator: = [3800,3801]
===
match
---
atom_expr [4515,4530]
atom_expr [4535,4550]
===
match
---
name: debug [4067,4072]
name: debug [4087,4092]
===
match
---
name: self [8383,8387]
name: self [8403,8407]
===
match
---
simple_stmt [6033,6059]
simple_stmt [6053,6079]
===
match
---
name: mem_cgroup_node [6189,6204]
name: mem_cgroup_node [6209,6224]
===
match
---
name: airflow [1064,1071]
name: airflow [1092,1099]
===
match
---
suite [8983,9184]
suite [9003,9204]
===
match
---
string: ":" [9033,9036]
string: ":" [9053,9056]
===
match
---
trailer [8517,8533]
trailer [8537,8553]
===
match
---
name: parent [4963,4969]
name: parent [4983,4989]
===
match
---
if_stmt [6666,6856]
if_stmt [6686,6876]
===
match
---
trailer [5922,5937]
trailer [5942,5957]
===
match
---
name: self [8157,8161]
name: self [8177,8181]
===
match
---
or_test [5154,5286]
or_test [5174,5306]
===
match
---
trailer [5715,5729]
trailer [5735,5749]
===
match
---
trailer [6211,6226]
trailer [6231,6246]
===
match
---
simple_stmt [4923,4982]
simple_stmt [4943,5002]
===
match
---
decorated [8659,9224]
decorated [8679,9244]
===
match
---
name: qty [6141,6144]
name: qty [6161,6164]
===
match
---
trailer [5532,5544]
trailer [5552,5564]
===
match
---
simple_stmt [9096,9123]
simple_stmt [9116,9143]
===
match
---
suite [8571,8626]
suite [8591,8646]
===
match
---
operator: = [7006,7007]
operator: = [7026,7027]
===
match
---
atom_expr [2962,2980]
atom_expr [2990,3008]
===
match
---
string: """Task runner for cgroup to run Airflow task""" [788,836]
string: """Task runner for cgroup to run Airflow task""" [788,836]
===
match
---
trailer [5233,5243]
trailer [5253,5263]
===
match
---
name: cgroups [5155,5162]
name: cgroups [5175,5182]
===
match
---
name: cgroups [5464,5471]
name: cgroups [5484,5491]
===
match
---
name: Tree [3495,3499]
name: Tree [3515,3519]
===
match
---
funcdef [5036,7072]
funcdef [5056,7092]
===
match
---
name: _cpu_shares [2935,2946]
name: _cpu_shares [2963,2974]
===
match
---
expr_stmt [4894,4914]
expr_stmt [4914,4934]
===
match
---
name: task [5938,5942]
name: task [5958,5962]
===
match
---
atom_expr [6703,6790]
atom_expr [6723,6810]
===
match
---
operator: = [9171,9172]
operator: = [9191,9192]
===
match
---
simple_stmt [3032,3060]
simple_stmt [3060,3088]
===
match
---
trailer [3182,3184]
trailer [3202,3204]
===
match
---
string: "/proc/self/cgroup" [8848,8867]
string: "/proc/self/cgroup" [8868,8887]
===
match
---
trailer [7134,7139]
trailer [7154,7159]
===
match
---
trailer [5122,5140]
trailer [5142,5160]
===
match
---
name: base_task_runner [965,981]
name: base_task_runner [950,966]
===
match
---
simple_stmt [9054,9080]
simple_stmt [9074,9100]
===
match
---
expr_stmt [6189,6248]
expr_stmt [6209,6268]
===
match
---
expr_stmt [9139,9183]
expr_stmt [9159,9203]
===
match
---
comp_op [4670,4676]
comp_op [4690,4696]
===
match
---
name: self [6067,6071]
name: self [6087,6091]
===
match
---
name: self [6336,6340]
name: self [6356,6360]
===
match
---
classdef [1120,9224]
classdef [1148,9244]
===
match
---
name: task [5963,5967]
name: task [5983,5987]
===
match
---
atom_expr [4599,4614]
atom_expr [4619,4634]
===
match
---
name: log [7782,7785]
name: log [7802,7805]
===
match
---
and_test [5155,5203]
and_test [5175,5223]
===
match
---
simple_stmt [8101,8120]
simple_stmt [8121,8140]
===
match
---
trailer [6818,6829]
trailer [6838,6849]
===
match
---
expr_stmt [2996,3023]
expr_stmt [3024,3051]
===
match
---
trailer [4931,4937]
trailer [4951,4957]
===
match
---
name: uuid [5716,5720]
name: uuid [5736,5740]
===
match
---
name: BaseTaskRunner [989,1003]
name: BaseTaskRunner [974,988]
===
match
---
trailer [5808,5824]
trailer [5828,5844]
===
match
---
name: os [3539,3541]
name: os [3559,3561]
===
match
---
name: task [5911,5915]
name: task [5931,5935]
===
match
---
atom_expr [6904,6984]
atom_expr [6924,7004]
===
match
---
name: path_element [4150,4162]
name: path_element [4170,4182]
===
match
---
trailer [5726,5728]
trailer [5746,5748]
===
match
---
name: log [6341,6344]
name: log [6361,6364]
===
match
---
name: log [5305,5308]
name: log [5325,5328]
===
match
---
simple_stmt [4775,4782]
simple_stmt [4795,4802]
===
match
---
atom_expr [5749,5769]
atom_expr [5769,5789]
===
match
---
atom_expr [6106,6124]
atom_expr [6126,6144]
===
match
---
name: self [6386,6390]
name: self [6406,6410]
===
match
---
name: cgroups [5108,5115]
name: cgroups [5128,5135]
===
match
---
trailer [3796,3798]
trailer [3816,3818]
===
match
---
name: node [3811,3815]
name: node [3831,3835]
===
match
---
name: parent [4894,4900]
name: parent [4914,4920]
===
match
---
name: name [5016,5020]
name: name [5036,5040]
===
match
---
expr_stmt [9054,9079]
expr_stmt [9074,9099]
===
match
---
trailer [6049,6054]
trailer [6069,6074]
===
match
---
name: limit_in_bytes [6467,6481]
name: limit_in_bytes [6487,6501]
===
match
---
name: path [4301,4305]
name: path [4321,4325]
===
match
---
name: super [2822,2827]
name: super [2850,2855]
===
match
---
trailer [6600,6616]
trailer [6620,6636]
===
match
---
name: path_split [4559,4569]
name: path_split [4579,4589]
===
match
---
name: self [4707,4711]
name: self [4727,4731]
===
match
---
name: x [4622,4623]
name: x [4642,4643]
===
match
---
suite [5052,7072]
suite [5072,7092]
===
match
---
atom_expr [8174,8209]
atom_expr [8194,8229]
===
match
---
trailer [6673,6685]
trailer [6693,6705]
===
match
---
name: line_split [9109,9119]
name: line_split [9129,9139]
===
match
---
trailer [5649,5739]
trailer [5669,5759]
===
match
---
number: 137 [7760,7763]
number: 137 [7780,7783]
===
match
---
trailer [5937,5942]
trailer [5957,5962]
===
match
---
atom_expr [6751,6771]
atom_expr [6771,6791]
===
match
---
suite [2813,3185]
suite [2841,3205]
===
match
---
sync_comp_for [3802,3824]
sync_comp_for [3822,3844]
===
match
---
atom_expr [6484,6502]
atom_expr [6504,6522]
===
match
---
simple_stmt [4583,4642]
simple_stmt [4603,4662]
===
match
---
operator: = [6125,6126]
operator: = [6145,6146]
===
match
---
name: log [4712,4715]
name: log [4732,4735]
===
match
---
string: "/" [5200,5203]
string: "/" [5220,5223]
===
match
---
trailer [5642,5649]
trailer [5662,5669]
===
match
---
simple_stmt [4259,4271]
simple_stmt [4279,4291]
===
match
---
string: "Task failed with return code of 137. This may indicate " [7809,7866]
string: "Task failed with return code of 137. This may indicate " [7829,7886]
===
match
---
expr_stmt [3767,3825]
expr_stmt [3787,3845]
===
match
---
operator: , [2795,2796]
operator: , [2823,2824]
===
match
---
name: cgroup_name [7056,7067]
name: cgroup_name [7076,7087]
===
match
---
fstring [5827,5847]
fstring [5847,5867]
===
match
---
expr_stmt [2891,2921]
expr_stmt [2919,2949]
===
match
---
name: path [3528,3532]
name: path [3548,3552]
===
match
---
atom_expr [8192,8208]
atom_expr [8212,8228]
===
match
---
trailer [4525,4530]
trailer [4545,4550]
===
match
---
trailer [8191,8209]
trailer [8211,8229]
===
match
---
number: 1024 [6505,6509]
number: 1024 [6525,6529]
===
match
---
trailer [5680,5687]
trailer [5700,5707]
===
match
---
string: "memory" [5476,5484]
string: "memory" [5496,5504]
===
match
---
simple_stmt [9139,9184]
simple_stmt [9159,9204]
===
match
---
if_stmt [7742,8093]
if_stmt [7762,8113]
===
match
---
atom_expr [6440,6481]
atom_expr [6460,6501]
===
match
---
name: cgroupspy [911,920]
name: cgroupspy [896,905]
===
match
---
atom_expr [4476,4493]
atom_expr [4496,4513]
===
match
---
trailer [6488,6502]
trailer [6508,6522]
===
match
---
name: airflow [940,947]
name: airflow [925,932]
===
match
---
atom_expr [6127,6144]
atom_expr [6147,6164]
===
match
---
simple_stmt [5300,5501]
simple_stmt [5320,5521]
===
match
---
name: get [5186,5189]
name: get [5206,5209]
===
match
---
suite [4690,4782]
suite [4710,4802]
===
match
---
comparison [3841,3873]
comparison [3861,3893]
===
match
---
atom_expr [5663,5710]
atom_expr [5683,5730]
===
match
---
name: self [5749,5753]
name: self [5769,5773]
===
match
---
fstring_string: memory/ [5774,5781]
fstring_string: memory/ [5794,5801]
===
match
---
atom [5208,5286]
atom [5228,5306]
===
match
---
trailer [6110,6124]
trailer [6130,6144]
===
match
---
trailer [3154,3164]
trailer [3182,3192]
===
match
---
name: name_to_node [4823,4835]
name: name_to_node [4843,4855]
===
match
---
term [6484,6516]
term [6504,6536]
===
match
---
operator: * [6503,6504]
operator: * [6523,6524]
===
match
---
trailer [6350,6427]
trailer [6370,6447]
===
match
---
name: subsystem [9160,9169]
name: subsystem [9180,9189]
===
match
---
name: name [4601,4605]
name: name [4621,4625]
===
match
---
string: "resources argument to reserve more memory for your task" [8021,8078]
string: "resources argument to reserve more memory for your task" [8041,8098]
===
match
---
expr_stmt [6440,6516]
expr_stmt [6460,6536]
===
match
---
trailer [4612,4614]
trailer [4632,4634]
===
match
---
expr_stmt [5613,5739]
expr_stmt [5633,5759]
===
match
---
param [4301,4305]
param [4321,4325]
===
match
---
operator: { [3782,3783]
operator: { [3802,3803]
===
match
---
import_name [879,890]
import_name [864,875]
===
match
---
trailer [5687,5689]
trailer [5707,5709]
===
match
---
operator: = [2981,2982]
operator: = [3009,3010]
===
match
---
operator: = [4222,4223]
operator: = [4242,4243]
===
match
---
file_input [788,9224]
file_input [788,9244]
===
match
---
operator: != [5270,5272]
operator: != [5290,5292]
===
match
---
import_name [892,905]
import_name [877,890]
===
match
---
name: __init__ [2782,2790]
name: __init__ [2810,2818]
===
match
---
name: log [3896,3899]
name: log [3916,3919]
===
match
---
operator: , [5410,5411]
operator: , [5430,5431]
===
match
---
name: _create_cgroup [6581,6595]
name: _create_cgroup [6601,6615]
===
match
---
simple_stmt [6336,6428]
simple_stmt [6356,6448]
===
match
---
atom_expr [4971,4980]
atom_expr [4991,5000]
===
match
---
operator: } [8951,8952]
operator: } [8971,8972]
===
match
---
name: _delete_cgroup [8589,8603]
name: _delete_cgroup [8609,8623]
===
match
---
trailer [8246,8254]
trailer [8266,8274]
===
match
---
atom_expr [3539,3545]
atom_expr [3559,3565]
===
match
---
trailer [5020,5027]
trailer [5040,5047]
===
match
---
trailer [8459,8479]
trailer [8479,8499]
===
match
---
parameters [8138,8144]
parameters [8158,8164]
===
match
---
operator: = [4821,4822]
operator: = [4841,4842]
===
match
---
funcdef [2778,3185]
funcdef [2806,3205]
===
match
---
name: _created_cpu_cgroup [6631,6650]
name: _created_cpu_cgroup [6651,6670]
===
match
---
trailer [5544,5546]
trailer [5564,5566]
===
match
---
operator: > [6686,6687]
operator: > [6706,6707]
===
match
---
name: _created_cpu_cgroup [3073,3092]
name: _created_cpu_cgroup [3101,3120]
===
match
---
simple_stmt [6558,6618]
simple_stmt [6578,6638]
===
match
---
trailer [7781,7785]
trailer [7801,7805]
===
match
---
name: get [5230,5233]
name: get [5250,5253]
===
match
---
string: "Please consider optimizing your task or using the " [7952,8004]
string: "Please consider optimizing your task or using the " [7972,8024]
===
match
---
trailer [8264,8268]
trailer [8284,8288]
===
match
---
atom_expr [6993,7005]
atom_expr [7013,7025]
===
match
---
operator: != [5197,5199]
operator: != [5217,5219]
===
match
---
comparison [5248,5276]
comparison [5268,5296]
===
match
---
operator: = [5526,5527]
operator: = [5546,5547]
===
match
---
trailer [3899,3905]
trailer [3919,3925]
===
match
---
atom_expr [7122,7141]
atom_expr [7142,7161]
===
match
---
trailer [5259,5269]
trailer [5279,5289]
===
match
---
trailer [4937,4981]
trailer [4957,5001]
===
match
---
name: decode [3958,3964]
name: decode [3978,3984]
===
match
---
term [6086,6097]
term [6106,6117]
===
match
---
name: split [9027,9032]
name: split [9047,9052]
===
match
---
name: decode [4606,4612]
name: decode [4626,4632]
===
match
---
number: 1 [9077,9078]
number: 1 [9097,9098]
===
match
---
simple_stmt [3482,3507]
simple_stmt [3502,3527]
===
match
---
name: return_code [7081,7092]
name: return_code [7101,7112]
===
match
---
operator: = [8406,8407]
operator: = [8426,8427]
===
match
---
atom_expr [3032,3052]
atom_expr [3060,3080]
===
match
---
trailer [3789,3796]
trailer [3809,3816]
===
match
---
operator: , [3946,3947]
operator: , [3966,3967]
===
match
---
trailer [9119,9122]
trailer [9139,9142]
===
match
---
name: x [3800,3801]
name: x [3820,3821]
===
match
---
suite [3874,4024]
suite [3894,4044]
===
match
---
simple_stmt [4316,4461]
simple_stmt [4336,4481]
===
match
---
param [3215,3219]
param [3235,3239]
===
match
---
simple_stmt [1164,2773]
simple_stmt [1192,2801]
===
match
---
suite [8701,9224]
suite [8721,9244]
===
match
---
expr_stmt [5108,5142]
expr_stmt [5128,5162]
===
match
---
trailer [3036,3052]
trailer [3064,3080]
===
match
---
suite [7764,8093]
suite [7784,8113]
===
match
---
trailer [9032,9037]
trailer [9052,9057]
===
match
---
trailer [2829,2838]
trailer [2857,2866]
===
match
---
trailer [6071,6083]
trailer [6091,6103]
===
match
---
name: qty [6055,6058]
name: qty [6075,6078]
===
match
---
trailer [3815,3824]
trailer [3835,3844]
===
match
---
name: _create_cgroup [6212,6226]
name: _create_cgroup [6232,6246]
===
match
---
sync_comp_for [4618,4640]
sync_comp_for [4638,4660]
===
match
---
suite [4799,4850]
suite [4819,4870]
===
match
---
fstring_start: f" [5772,5774]
fstring_start: f" [5792,5794]
===
match
---
name: name [3785,3789]
name: name [3805,3809]
===
match
---
trailer [8204,8208]
trailer [8224,8228]
===
match
---
name: _created_mem_cgroup [3114,3133]
name: _created_mem_cgroup [3142,3161]
===
match
---
name: node [4266,4270]
name: node [4286,4290]
===
match
---
param [4295,4300]
param [4315,4320]
===
match
---
trailer [3964,3966]
trailer [3984,3986]
===
match
---
trailer [4173,4180]
trailer [4193,4200]
===
match
---
operator: = [3487,3488]
operator: = [3507,3508]
===
match
---
string: "Starting task process with cgroups cpu,memory: %s" [6919,6970]
string: "Starting task process with cgroups cpu,memory: %s" [6939,6990]
===
match
---
atom_expr [3489,3506]
atom_expr [3509,3526]
===
match
---
name: self [5804,5808]
name: self [5824,5828]
===
match
---
trailer [5671,5680]
trailer [5691,5700]
===
match
---
operator: , [7040,7041]
operator: , [7060,7061]
===
match
---
expr_stmt [2863,2882]
expr_stmt [2891,2910]
===
match
---
arglist [4724,4757]
arglist [4744,4777]
===
match
---
name: node [4903,4907]
name: node [4923,4927]
===
match
---
operator: { [7055,7056]
operator: { [7075,7076]
===
match
---
trailer [7024,7071]
trailer [7044,7091]
===
match
---
simple_stmt [3515,3547]
simple_stmt [3535,3567]
===
match
---
for_stmt [4539,4850]
for_stmt [4559,4870]
===
match
---
trailer [5162,5166]
trailer [5182,5186]
===
match
---
simple_stmt [8584,8626]
simple_stmt [8604,8646]
===
match
---
trailer [5698,5710]
trailer [5718,5730]
===
match
---
trailer [4715,4723]
trailer [4735,4743]
===
match
---
name: node [4469,4473]
name: node [4489,4493]
===
match
---
atom_expr [5981,5995]
atom_expr [6001,6015]
===
match
---
name: path_element [4657,4669]
name: path_element [4677,4689]
===
match
---
string: "cpu" [5440,5445]
string: "cpu" [5460,5465]
===
match
---
name: run_command [7013,7024]
name: run_command [7033,7044]
===
match
---
simple_stmt [4707,4759]
simple_stmt [4727,4779]
===
match
---
name: utcnow [5681,5687]
name: utcnow [5701,5707]
===
match
---
name: node [4627,4631]
name: node [4647,4651]
===
match
---
simple_stmt [3230,3474]
simple_stmt [3250,3494]
===
match
---
operator: , [6749,6750]
operator: , [6769,6770]
===
insert-tree
---
simple_stmt [1044,1087]
    import_from [1044,1086]
        dotted_name [1049,1071]
            name: airflow [1049,1056]
            name: utils [1057,1062]
            name: platform [1063,1071]
        name: getuser [1079,1086]
to
file_input [788,9224]
at 9
===
move-tree
---
name: getuser [3175,3182]
to
atom_expr [3167,3184]
at 0
===
delete-tree
---
simple_stmt [854,869]
    import_name [854,868]
        name: getpass [861,868]
===
delete-node
---
name: getpass [3167,3174]
===
===
delete-node
---
trailer [3174,3182]
===
