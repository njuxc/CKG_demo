===
match
---
param [71845,71849]
param [71865,71869]
===
match
---
atom_expr [34668,34711]
atom_expr [34688,34731]
===
match
---
name: VariableJsonAccessor [65978,65998]
name: VariableJsonAccessor [65998,66018]
===
match
---
expr_stmt [82382,82401]
expr_stmt [82402,82421]
===
match
---
trailer [49631,49646]
trailer [49651,49666]
===
match
---
funcdef [55120,56060]
funcdef [55140,56080]
===
match
---
name: self [59153,59157]
name: self [59173,59177]
===
match
---
name: state [24417,24422]
name: state [24437,24442]
===
match
---
parameters [35151,35182]
parameters [35171,35202]
===
match
---
simple_stmt [44304,44378]
simple_stmt [44324,44398]
===
match
---
simple_stmt [45656,45705]
simple_stmt [45676,45725]
===
match
---
simple_stmt [67703,67728]
simple_stmt [67723,67748]
===
match
---
string: 'next_execution_date' [64965,64986]
string: 'next_execution_date' [64985,65006]
===
match
---
atom_expr [5344,5354]
atom_expr [5372,5382]
===
match
---
name: log [43289,43292]
name: log [43309,43312]
===
match
---
argument [15131,15164]
argument [15151,15184]
===
match
---
operator: -> [8348,8350]
operator: -> [8376,8378]
===
match
---
name: render [72302,72308]
name: render [72322,72328]
===
match
---
atom_expr [39107,39130]
atom_expr [39127,39150]
===
match
---
atom_expr [80260,80277]
atom_expr [80280,80297]
===
match
---
operator: = [48971,48972]
operator: = [48991,48992]
===
match
---
name: _queue [81368,81374]
name: _queue [81388,81394]
===
match
---
operator: , [53810,53811]
operator: , [53830,53831]
===
match
---
name: self [42628,42632]
name: self [42648,42652]
===
match
---
operator: = [61827,61828]
operator: = [61847,61848]
===
match
---
comparison [47282,47318]
comparison [47302,47338]
===
match
---
operator: = [41496,41497]
operator: = [41516,41517]
===
match
---
suite [13160,13197]
suite [13180,13217]
===
match
---
name: self [80436,80440]
name: self [80456,80460]
===
match
---
name: contextlib [3288,3298]
name: contextlib [3316,3326]
===
match
---
expr_stmt [10201,10234]
expr_stmt [10229,10262]
===
match
---
operator: , [10610,10611]
operator: , [10638,10639]
===
match
---
return_stmt [69139,69159]
return_stmt [69159,69179]
===
match
---
subscript [82427,82431]
subscript [82447,82451]
===
match
---
name: end_date [24957,24965]
name: end_date [24977,24985]
===
match
---
trailer [39225,39227]
trailer [39245,39247]
===
match
---
funcdef [26444,28070]
funcdef [26464,28090]
===
match
---
not_test [42980,42996]
not_test [43000,43016]
===
match
---
funcdef [30959,32302]
funcdef [30979,32322]
===
match
---
name: email [72652,72657]
name: email [72672,72677]
===
match
---
operator: = [9745,9746]
operator: = [9773,9774]
===
match
---
simple_stmt [49845,49910]
simple_stmt [49865,49930]
===
match
---
name: task_id [26158,26165]
name: task_id [26178,26185]
===
match
---
operator: @ [19146,19147]
operator: @ [19166,19167]
===
match
---
name: dagrun [45946,45952]
name: dagrun [45966,45972]
===
match
---
fstring_string: . [42934,42935]
fstring_string: . [42954,42955]
===
match
---
name: e [67159,67160]
name: e [67179,67180]
===
match
---
name: self [24858,24862]
name: self [24878,24882]
===
match
---
atom_expr [22626,22634]
atom_expr [22646,22654]
===
match
---
operator: , [32811,32812]
operator: , [32831,32832]
===
match
---
operator: , [14320,14321]
operator: , [14340,14341]
===
match
---
atom_expr [40719,40735]
atom_expr [40739,40755]
===
match
---
name: cfg_path [18790,18798]
name: cfg_path [18810,18818]
===
match
---
operator: = [61640,61641]
operator: = [61660,61661]
===
match
---
operator: -> [74733,74735]
operator: -> [74753,74755]
===
match
---
atom_expr [30612,30867]
atom_expr [30632,30887]
===
match
---
name: int [33659,33662]
name: int [33679,33682]
===
match
---
operator: = [23401,23402]
operator: = [23421,23422]
===
match
---
simple_stmt [50618,50680]
simple_stmt [50638,50700]
===
match
---
name: self [68546,68550]
name: self [68566,68570]
===
match
---
import_from [35337,35377]
import_from [35357,35397]
===
match
---
atom_expr [58901,58958]
atom_expr [58921,58978]
===
match
---
arglist [19299,19322]
arglist [19319,19342]
===
match
---
arglist [50577,50607]
arglist [50597,50627]
===
match
---
trailer [40003,40018]
trailer [40023,40038]
===
match
---
operator: = [9993,9994]
operator: = [10021,10022]
===
match
---
operator: } [19774,19775]
operator: } [19794,19795]
===
match
---
trailer [14967,14974]
trailer [14987,14994]
===
match
---
trailer [7266,7274]
trailer [7294,7302]
===
match
---
name: _try_number [13867,13878]
name: _try_number [13887,13898]
===
match
---
operator: { [19372,19373]
operator: { [19392,19393]
===
match
---
name: self [81244,81248]
name: self [81264,81268]
===
match
---
name: session [7374,7381]
name: session [7402,7409]
===
match
---
atom_expr [18059,18089]
atom_expr [18079,18109]
===
match
---
name: TaskInstance [79391,79403]
name: TaskInstance [79411,79423]
===
match
---
trailer [25331,25337]
trailer [25351,25357]
===
match
---
name: dr [7882,7884]
name: dr [7910,7912]
===
match
---
trailer [57868,57889]
trailer [57888,57909]
===
match
---
name: bool [53702,53706]
name: bool [53722,53726]
===
match
---
arglist [82080,82232]
arglist [82100,82252]
===
match
---
trailer [7628,7634]
trailer [7656,7662]
===
match
---
trailer [56599,56603]
trailer [56619,56623]
===
match
---
atom_expr [19290,19323]
atom_expr [19310,19343]
===
match
---
name: id [7412,7414]
name: id [7440,7442]
===
match
---
suite [26847,28049]
suite [26867,28069]
===
match
---
expr_stmt [5989,6010]
expr_stmt [6017,6038]
===
match
---
name: task [62416,62420]
name: task [62436,62440]
===
match
---
trailer [24774,24780]
trailer [24794,24800]
===
match
---
operator: , [53714,53715]
operator: , [53734,53735]
===
match
---
trailer [40896,40905]
trailer [40916,40925]
===
match
---
suite [57072,57122]
suite [57092,57142]
===
match
---
simple_stmt [40682,40711]
simple_stmt [40702,40731]
===
match
---
name: dep_context [30990,31001]
name: dep_context [31010,31021]
===
match
---
atom_expr [22472,22483]
atom_expr [22492,22503]
===
match
---
name: models [66289,66295]
name: models [66309,66315]
===
match
---
trailer [27275,27331]
trailer [27295,27351]
===
match
---
number: 1 [8567,8568]
number: 1 [8595,8596]
===
match
---
trailer [47113,47122]
trailer [47133,47142]
===
match
---
atom_expr [15917,15930]
atom_expr [15937,15950]
===
match
---
exprlist [7139,7152]
exprlist [7167,7180]
===
match
---
operator: += [40736,40738]
operator: += [40756,40758]
===
match
---
name: error [48437,48442]
name: error [48457,48462]
===
match
---
trailer [56967,57012]
trailer [56987,57032]
===
match
---
name: merge [50953,50958]
name: merge [50973,50978]
===
match
---
trailer [19587,19612]
trailer [19607,19632]
===
match
---
suite [43491,43525]
suite [43511,43545]
===
match
---
trailer [42685,42703]
trailer [42705,42723]
===
match
---
fstring_string: .log [19135,19139]
fstring_string: .log [19155,19159]
===
match
---
simple_stmt [43141,43184]
simple_stmt [43161,43204]
===
match
---
atom_expr [35027,35037]
atom_expr [35047,35057]
===
match
---
operator: , [14166,14167]
operator: , [14186,14187]
===
match
---
operator: @ [3287,3288]
operator: @ [3315,3316]
===
match
---
operator: = [71114,71115]
operator: = [71134,71135]
===
match
---
decorated [80826,80906]
decorated [80846,80926]
===
match
---
name: task_id [33915,33922]
name: task_id [33935,33942]
===
match
---
name: _state [81130,81136]
name: _state [81150,81156]
===
match
---
name: run_as_user [80283,80294]
name: run_as_user [80303,80314]
===
match
---
atom_expr [7259,7286]
atom_expr [7287,7314]
===
match
---
name: run_as_user [23443,23454]
name: run_as_user [23463,23474]
===
match
---
simple_stmt [32224,32282]
simple_stmt [32244,32302]
===
match
---
operator: , [16002,16003]
operator: , [16022,16023]
===
match
---
name: pool [18612,18616]
name: pool [18632,18636]
===
match
---
trailer [50147,50157]
trailer [50167,50177]
===
match
---
string: """         Forces the task instance's state to FAILED in the database.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [20676,20838]
string: """         Forces the task instance's state to FAILED in the database.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [20696,20858]
===
match
---
return_stmt [72369,72415]
return_stmt [72389,72435]
===
match
---
name: task_tries [6954,6964]
name: task_tries [6982,6992]
===
match
---
comparison [52950,52986]
comparison [52970,53006]
===
match
---
simple_stmt [62326,62376]
simple_stmt [62346,62396]
===
match
---
trailer [65998,66000]
trailer [66018,66020]
===
match
---
trailer [79857,79865]
trailer [79877,79885]
===
match
---
name: self [48115,48119]
name: self [48135,48139]
===
match
---
arglist [30639,30857]
arglist [30659,30877]
===
match
---
argument [38228,38264]
argument [38248,38284]
===
match
---
name: DagRun [7560,7566]
name: DagRun [7588,7594]
===
match
---
atom_expr [20379,20391]
atom_expr [20399,20411]
===
match
---
name: cmd [18357,18360]
name: cmd [18377,18380]
===
match
---
name: self [45796,45800]
name: self [45816,45820]
===
match
---
name: self [42784,42788]
name: self [42804,42808]
===
match
---
name: ignore_all_deps [53491,53506]
name: ignore_all_deps [53511,53526]
===
match
---
name: sha1 [33825,33829]
name: sha1 [33845,33849]
===
match
---
operator: @ [8316,8317]
operator: @ [8344,8345]
===
match
---
fstring_expr [48771,48789]
fstring_expr [48791,48809]
===
match
---
trailer [5921,5931]
trailer [5949,5959]
===
match
---
operator: , [28030,28031]
operator: , [28050,28051]
===
match
---
decorator [81310,81320]
decorator [81330,81340]
===
match
---
funcdef [34858,35111]
funcdef [34878,35131]
===
match
---
name: datetime [11118,11126]
name: datetime [11146,11154]
===
match
---
operator: = [80140,80141]
operator: = [80160,80161]
===
match
---
operator: , [1347,1348]
operator: , [1332,1333]
===
match
---
dotted_name [1512,1535]
dotted_name [1497,1520]
===
match
---
suite [56578,56623]
suite [56598,56643]
===
match
---
fstring_string: ?task_id= [19678,19687]
fstring_string: ?task_id= [19698,19707]
===
match
---
argument [46177,46195]
argument [46197,46215]
===
match
---
name: info [41331,41335]
name: info [41351,41355]
===
match
---
trailer [68228,68230]
trailer [68248,68250]
===
match
---
factor [82429,82431]
factor [82449,82451]
===
match
---
operator: = [61279,61280]
operator: = [61299,61300]
===
match
---
trailer [77583,77589]
trailer [77603,77609]
===
match
---
atom [60349,60514]
atom [60369,60534]
===
match
---
operator: , [35789,35790]
operator: , [35809,35810]
===
match
---
operator: -> [24182,24184]
operator: -> [24202,24204]
===
match
---
simple_stmt [5065,5141]
simple_stmt [5093,5169]
===
match
---
atom_expr [40334,40365]
atom_expr [40354,40385]
===
match
---
name: context [50481,50488]
name: context [50501,50508]
===
match
---
param [68058,68091]
param [68078,68111]
===
match
---
operator: = [53638,53639]
operator: = [53658,53659]
===
match
---
atom_expr [40382,40398]
atom_expr [40402,40418]
===
match
---
name: self [11325,11329]
name: self [11353,11357]
===
match
---
trailer [3661,3663]
trailer [3689,3691]
===
match
---
name: try_number [6846,6856]
name: try_number [6874,6884]
===
match
---
name: try_number [40248,40258]
name: try_number [40268,40278]
===
match
---
name: self [64033,64037]
name: self [64053,64057]
===
match
---
operator: , [72755,72756]
operator: , [72775,72776]
===
match
---
name: context [3595,3602]
name: context [3623,3630]
===
match
---
atom_expr [23380,23400]
atom_expr [23400,23420]
===
match
---
expr_stmt [80113,80160]
expr_stmt [80133,80180]
===
match
---
trailer [43639,43644]
trailer [43659,43664]
===
match
---
atom_expr [67872,67884]
atom_expr [67892,67904]
===
match
---
name: task [60184,60188]
name: task [60204,60208]
===
match
---
atom [70138,70499]
atom [70158,70519]
===
match
---
trailer [33829,34024]
trailer [33849,34044]
===
match
---
trailer [47890,48029]
trailer [47910,48049]
===
match
---
expr_stmt [52645,52661]
expr_stmt [52665,52681]
===
match
---
atom_expr [77736,77754]
atom_expr [77756,77774]
===
match
---
string: "started running, please use 'airflow tasks render' for debugging the " [67012,67083]
string: "started running, please use 'airflow tasks render' for debugging the " [67032,67103]
===
match
---
operator: , [62007,62008]
operator: , [62027,62028]
===
match
---
name: session [81596,81603]
name: session [81616,81623]
===
match
---
operator: = [24436,24437]
operator: = [24456,24457]
===
match
---
name: test_mode [55288,55297]
name: test_mode [55308,55317]
===
match
---
simple_stmt [9423,9455]
simple_stmt [9451,9483]
===
match
---
name: self [70936,70940]
name: self [70956,70960]
===
match
---
name: tis [77996,77999]
name: tis [78016,78019]
===
match
---
comp_op [51821,51827]
comp_op [51841,51847]
===
match
---
name: self [19116,19120]
name: self [19136,19140]
===
match
---
arglist [21620,21769]
arglist [21640,21789]
===
match
---
fstring_string: &dag_id= [19717,19725]
fstring_string: &dag_id= [19737,19745]
===
match
---
dotted_name [1929,1952]
dotted_name [1914,1937]
===
match
---
name: pool [15416,15420]
name: pool [15436,15440]
===
match
---
name: _run_raw_task [41667,41680]
name: _run_raw_task [41687,41700]
===
match
---
trailer [57909,57915]
trailer [57929,57935]
===
match
---
operator: @ [81458,81459]
operator: @ [81478,81479]
===
match
---
name: dag_id [11198,11204]
name: dag_id [11226,11232]
===
match
---
atom_expr [60231,60246]
atom_expr [60251,60266]
===
match
---
expr_stmt [40382,40418]
expr_stmt [40402,40438]
===
match
---
name: context [50427,50434]
name: context [50447,50454]
===
match
---
operator: -> [80618,80620]
operator: -> [80638,80640]
===
match
---
trailer [56891,56900]
trailer [56911,56920]
===
match
---
atom_expr [35064,35090]
atom_expr [35084,35110]
===
match
---
name: self [63907,63911]
name: self [63927,63931]
===
match
---
trailer [29597,29627]
trailer [29617,29647]
===
match
---
operator: == [79203,79205]
operator: == [79223,79225]
===
match
---
trailer [16026,16031]
trailer [16046,16051]
===
match
---
parameters [4268,4315]
parameters [4296,4343]
===
match
---
atom_expr [76900,76922]
atom_expr [76920,76942]
===
match
---
simple_stmt [34770,34816]
simple_stmt [34790,34836]
===
match
---
atom_expr [24797,24812]
atom_expr [24817,24832]
===
match
---
fstring_expr [19115,19129]
fstring_expr [19135,19149]
===
match
---
name: exc_info [47997,48005]
name: exc_info [48017,48025]
===
match
---
simple_stmt [18687,18709]
simple_stmt [18707,18729]
===
match
---
comparison [27710,27729]
comparison [27730,27749]
===
match
---
argument [15237,15268]
argument [15257,15288]
===
match
---
simple_stmt [27345,27358]
simple_stmt [27365,27378]
===
match
---
decorated [80587,80654]
decorated [80607,80674]
===
match
---
simple_stmt [69221,69273]
simple_stmt [69241,69293]
===
match
---
name: task [64832,64836]
name: task [64852,64856]
===
match
---
string: 'conf' [64607,64613]
string: 'conf' [64627,64633]
===
match
---
name: ti [22798,22800]
name: ti [22818,22820]
===
match
---
operator: = [27352,27353]
operator: = [27372,27373]
===
match
---
name: session [37626,37633]
name: session [37646,37653]
===
match
---
classdef [62671,63580]
classdef [62691,63600]
===
match
---
name: self [71792,71796]
name: self [71812,71816]
===
match
---
name: self [12371,12375]
name: self [12391,12395]
===
match
---
name: dag [14594,14597]
name: dag [14614,14617]
===
match
---
trailer [6845,6856]
trailer [6873,6884]
===
match
---
name: context [43014,43021]
name: context [43034,43041]
===
match
---
term [33673,33725]
term [33693,33745]
===
match
---
atom_expr [24354,24369]
atom_expr [24374,24389]
===
match
---
operator: , [10672,10673]
operator: , [10700,10701]
===
match
---
trailer [12126,12132]
trailer [12146,12152]
===
match
---
name: jinja_context [71402,71415]
name: jinja_context [71422,71435]
===
match
---
name: catchup [27714,27721]
name: catchup [27734,27741]
===
match
---
name: UtcDateTime [2759,2770]
name: UtcDateTime [2787,2798]
===
match
---
import_as_names [1667,1825]
import_as_names [1652,1810]
===
match
---
atom_expr [49858,49909]
atom_expr [49878,49929]
===
match
---
suite [73966,74174]
suite [73986,74194]
===
match
---
trailer [9904,9918]
trailer [9932,9946]
===
match
---
name: self [63229,63233]
name: self [63249,63253]
===
match
---
name: relationship [82606,82618]
name: relationship [82626,82638]
===
match
---
atom_expr [55743,55753]
atom_expr [55763,55773]
===
match
---
simple_stmt [56595,56623]
simple_stmt [56615,56643]
===
match
---
name: self [12682,12686]
name: self [12702,12706]
===
match
---
comparison [20409,20459]
comparison [20429,20479]
===
match
---
name: session [39899,39906]
name: session [39919,39926]
===
match
---
import_from [3068,3125]
import_from [3096,3153]
===
match
---
name: force_fail [57946,57956]
name: force_fail [57966,57976]
===
match
---
trailer [35444,35452]
trailer [35464,35472]
===
match
---
operator: , [68572,68573]
operator: , [68592,68593]
===
match
---
import_from [82492,82532]
import_from [82512,82552]
===
match
---
name: base_url [19628,19636]
name: base_url [19648,19656]
===
match
---
suite [47374,47528]
suite [47394,47548]
===
match
---
suite [18674,18709]
suite [18694,18729]
===
match
---
operator: , [73061,73062]
operator: , [73081,73082]
===
match
---
simple_stmt [61842,61864]
simple_stmt [61862,61884]
===
match
---
expr_stmt [47545,47588]
expr_stmt [47565,47608]
===
match
---
atom_expr [56254,56267]
atom_expr [56274,56287]
===
match
---
expr_stmt [71146,71218]
expr_stmt [71166,71238]
===
match
---
comp_if [47143,47190]
comp_if [47163,47210]
===
match
---
trailer [35046,35059]
trailer [35066,35079]
===
match
---
atom_expr [78760,78779]
atom_expr [78780,78799]
===
match
---
arglist [49632,49645]
arglist [49652,49665]
===
match
---
operator: , [73253,73254]
operator: , [73273,73274]
===
match
---
trailer [71201,71218]
trailer [71221,71238]
===
match
---
string: "Failed when executing execute callback" [52246,52286]
string: "Failed when executing execute callback" [52266,52306]
===
match
---
name: relationship [10894,10906]
name: relationship [10922,10934]
===
match
---
atom_expr [80889,80905]
atom_expr [80909,80925]
===
match
---
suite [4324,4681]
suite [4352,4709]
===
match
---
atom_expr [34613,34642]
atom_expr [34633,34662]
===
match
---
name: FAILED [57107,57113]
name: FAILED [57127,57133]
===
match
---
operator: } [33056,33057]
operator: } [33076,33077]
===
match
---
operator: = [31001,31002]
operator: = [31021,31022]
===
match
---
trailer [44143,44195]
trailer [44163,44215]
===
match
---
operator: = [29787,29788]
operator: = [29807,29808]
===
match
---
trailer [43028,43049]
trailer [43048,43069]
===
match
---
argument [27276,27290]
argument [27296,27310]
===
match
---
name: next_ds_nodash [64937,64951]
name: next_ds_nodash [64957,64971]
===
match
---
name: Optional [53732,53740]
name: Optional [53752,53760]
===
match
---
name: dr [35596,35598]
name: dr [35616,35618]
===
match
---
name: actual_start_date [55586,55603]
name: actual_start_date [55606,55623]
===
match
---
operator: , [26310,26311]
operator: , [26330,26331]
===
match
---
string: "execution date %s has no timezone information. Using default from dag or system" [11560,11641]
string: "execution date %s has no timezone information. Using default from dag or system" [11588,11669]
===
match
---
trailer [5464,5482]
trailer [5492,5510]
===
match
---
operator: = [7209,7210]
operator: = [7237,7238]
===
match
---
name: NamedTuple [7977,7987]
name: NamedTuple [8005,8015]
===
match
---
name: self [71668,71672]
name: self [71688,71692]
===
match
---
operator: = [42827,42828]
operator: = [42847,42848]
===
match
---
string: "exception" [52793,52804]
string: "exception" [52813,52824]
===
match
---
trailer [18633,18640]
trailer [18653,18660]
===
match
---
trailer [55470,55703]
trailer [55490,55723]
===
match
---
trailer [74601,74606]
trailer [74621,74626]
===
match
---
expr_stmt [42853,42890]
expr_stmt [42873,42910]
===
match
---
name: ApiClient [2918,2927]
name: ApiClient [2946,2955]
===
match
---
trailer [6005,6010]
trailer [6033,6038]
===
match
---
operator: = [27913,27914]
operator: = [27933,27934]
===
match
---
operator: { [44634,44635]
operator: { [44654,44655]
===
match
---
name: job_id [18176,18182]
name: job_id [18196,18202]
===
match
---
name: provide_session [23609,23624]
name: provide_session [23629,23644]
===
match
---
return_stmt [8257,8310]
return_stmt [8285,8338]
===
match
---
trailer [79403,79418]
trailer [79423,79438]
===
match
---
trailer [51796,51809]
trailer [51816,51829]
===
match
---
name: job_id [53724,53730]
name: job_id [53744,53750]
===
match
---
argument [54571,54580]
argument [54591,54600]
===
match
---
param [48115,48120]
param [48135,48140]
===
match
---
name: job [7367,7370]
name: job [7395,7398]
===
match
---
operator: } [47973,47974]
operator: } [47993,47994]
===
match
---
name: str [63225,63228]
name: str [63245,63248]
===
match
---
atom_expr [67612,67687]
atom_expr [67632,67707]
===
match
---
trailer [77288,77294]
trailer [77308,77314]
===
match
---
name: task_id [78897,78904]
name: task_id [78917,78924]
===
match
---
if_stmt [5367,5977]
if_stmt [5395,6005]
===
match
---
name: mark_success [41704,41716]
name: mark_success [41724,41736]
===
match
---
name: PodGenerator [3113,3125]
name: PodGenerator [3141,3153]
===
match
---
operator: = [12455,12456]
operator: = [12475,12476]
===
match
---
atom_expr [43508,43524]
atom_expr [43528,43544]
===
match
---
operator: <= [59604,59606]
operator: <= [59624,59626]
===
match
---
trailer [20383,20391]
trailer [20403,20411]
===
match
---
trailer [69096,69098]
trailer [69116,69118]
===
match
---
suite [44852,44940]
suite [44872,44960]
===
match
---
trailer [48436,48442]
trailer [48456,48462]
===
match
---
name: self [80113,80117]
name: self [80133,80137]
===
match
---
name: State [39960,39965]
name: State [39980,39985]
===
match
---
simple_stmt [5989,6011]
simple_stmt [6017,6039]
===
match
---
atom_expr [43959,43990]
atom_expr [43979,44010]
===
match
---
argument [71657,71687]
argument [71677,71707]
===
match
---
name: self [40654,40658]
name: self [40674,40678]
===
match
---
trailer [47170,47190]
trailer [47190,47210]
===
match
---
name: AirflowRescheduleException [1715,1741]
name: AirflowRescheduleException [1700,1726]
===
match
---
suite [12109,12141]
suite [12129,12161]
===
match
---
name: TaskInstance [79182,79194]
name: TaskInstance [79202,79214]
===
match
---
atom_expr [37793,37803]
atom_expr [37813,37823]
===
match
---
argument [71565,71584]
argument [71585,71604]
===
match
---
suite [20518,20551]
suite [20538,20571]
===
match
---
suite [66214,67161]
suite [66234,67181]
===
match
---
trailer [59611,59621]
trailer [59631,59641]
===
match
---
name: duration [72997,73005]
name: duration [73017,73025]
===
match
---
name: Log [57097,57100]
name: Log [57117,57120]
===
match
---
name: generate_command [14933,14949]
name: generate_command [14953,14969]
===
match
---
parameters [80854,80860]
parameters [80874,80880]
===
match
---
name: self [27138,27142]
name: self [27158,27162]
===
match
---
trailer [81261,81266]
trailer [81281,81286]
===
match
---
expr_stmt [43014,43051]
expr_stmt [43034,43071]
===
match
---
name: Exception [56146,56155]
name: Exception [56166,56175]
===
match
---
arglist [74205,74399]
arglist [74225,74419]
===
match
---
name: dep_context [32362,32373]
name: dep_context [32382,32393]
===
match
---
argument [76480,76514]
argument [76500,76534]
===
match
---
operator: , [14299,14300]
operator: , [14319,14320]
===
match
---
atom_expr [61430,61449]
atom_expr [61450,61469]
===
match
---
trailer [62420,62428]
trailer [62440,62448]
===
match
---
string: '%Y%m%dT%H%M%S' [41576,41591]
string: '%Y%m%dT%H%M%S' [41596,41611]
===
match
---
operator: @ [18873,18874]
operator: @ [18893,18894]
===
match
---
tfpdef [53616,53637]
tfpdef [53636,53657]
===
match
---
name: task [25944,25948]
name: task [25964,25968]
===
match
---
name: end_date [40897,40905]
name: end_date [40917,40925]
===
match
---
name: hostname [22435,22443]
name: hostname [22455,22463]
===
match
---
name: self [60455,60459]
name: self [60475,60479]
===
match
---
suite [27852,27936]
suite [27872,27956]
===
match
---
trailer [48737,48739]
trailer [48757,48759]
===
match
---
operator: , [29609,29610]
operator: , [29629,29630]
===
match
---
name: Integer [10055,10062]
name: Integer [10083,10090]
===
match
---
trailer [62240,62248]
trailer [62260,62268]
===
match
---
name: ignore_schedule [27626,27641]
name: ignore_schedule [27646,27661]
===
match
---
decorated [81541,82380]
decorated [81561,82400]
===
match
---
arglist [47410,47432]
arglist [47430,47452]
===
match
---
name: get_rendered_template_fields [66179,66207]
name: get_rendered_template_fields [66199,66227]
===
match
---
annassign [80498,80514]
annassign [80518,80534]
===
match
---
name: quote [19232,19237]
name: quote [19252,19257]
===
match
---
trailer [40565,40570]
trailer [40585,40590]
===
match
---
name: str [80621,80624]
name: str [80641,80644]
===
match
---
operator: , [56844,56845]
operator: , [56864,56865]
===
match
---
atom_expr [56595,56622]
atom_expr [56615,56642]
===
match
---
name: loader [71045,71051]
name: loader [71065,71071]
===
match
---
name: XCom [23935,23939]
name: XCom [23955,23959]
===
match
---
if_stmt [5168,6041]
if_stmt [5196,6069]
===
match
---
operator: = [14315,14316]
operator: = [14335,14336]
===
match
---
operator: , [1882,1883]
operator: , [1867,1868]
===
match
---
operator: = [60347,60348]
operator: = [60367,60368]
===
match
---
name: in_ [79130,79133]
name: in_ [79150,79153]
===
match
---
atom_expr [72992,73005]
atom_expr [73012,73025]
===
match
---
simple_stmt [71326,71417]
simple_stmt [71346,71437]
===
match
---
decorated [80659,80728]
decorated [80679,80748]
===
match
---
name: execution_date [11959,11973]
name: execution_date [11987,12001]
===
match
---
atom_expr [77565,77808]
atom_expr [77585,77828]
===
match
---
arglist [7680,7803]
arglist [7708,7831]
===
match
---
suite [31925,32170]
suite [31945,32190]
===
match
---
name: retries [59576,59583]
name: retries [59596,59603]
===
match
---
parameters [77430,77445]
parameters [77450,77465]
===
match
---
name: on_success_callback [53063,53082]
name: on_success_callback [53083,53102]
===
match
---
trailer [40342,40350]
trailer [40362,40370]
===
match
---
trailer [62499,62506]
trailer [62519,62526]
===
match
---
if_stmt [80389,80479]
if_stmt [80409,80499]
===
match
---
operator: , [38362,38363]
operator: , [38382,38383]
===
match
---
number: 1 [13997,13998]
number: 1 [14017,14018]
===
match
---
param [77437,77444]
param [77457,77464]
===
match
---
suite [25461,26418]
suite [25481,26438]
===
match
---
name: VariableAccessor [66027,66043]
name: VariableAccessor [66047,66063]
===
match
---
and_test [14663,14721]
and_test [14683,14741]
===
match
---
name: execution_date [10755,10769]
name: execution_date [10783,10797]
===
match
---
trailer [72152,72189]
trailer [72172,72209]
===
match
---
annassign [8113,8118]
annassign [8141,8146]
===
match
---
name: self [20847,20851]
name: self [20867,20871]
===
match
---
atom_expr [77341,77369]
atom_expr [77361,77389]
===
match
---
name: replace [62110,62117]
name: replace [62130,62137]
===
match
---
name: error [52808,52813]
name: error [52828,52833]
===
match
---
name: task [59960,59964]
name: task [59980,59984]
===
match
---
fstring_end: " [19738,19739]
fstring_end: " [19758,19759]
===
match
---
operator: , [22900,22901]
operator: , [22920,22921]
===
match
---
trailer [79314,79321]
trailer [79334,79341]
===
match
---
name: self [73946,73950]
name: self [73966,73970]
===
match
---
atom_expr [11337,11370]
atom_expr [11365,11398]
===
match
---
name: Variable [2062,2070]
name: Variable [2047,2055]
===
match
---
operator: , [30830,30831]
operator: , [30850,30851]
===
match
---
atom_expr [58508,58520]
atom_expr [58528,58540]
===
match
---
comparison [78646,78664]
comparison [78666,78684]
===
match
---
param [80938,80942]
param [80958,80962]
===
match
---
name: previous_schedule [61412,61429]
name: previous_schedule [61432,61449]
===
match
---
atom_expr [42738,42775]
atom_expr [42758,42795]
===
match
---
name: self [72900,72904]
name: self [72920,72924]
===
match
---
name: State [30918,30923]
name: State [30938,30943]
===
match
---
if_stmt [4071,4104]
if_stmt [4099,4132]
===
match
---
trailer [62151,62166]
trailer [62171,62186]
===
match
---
name: DateTime [30437,30445]
name: DateTime [30457,30465]
===
match
---
name: models [1937,1943]
name: models [1922,1928]
===
match
---
operator: = [37685,37686]
operator: = [37705,37706]
===
match
---
trailer [24077,24079]
trailer [24097,24099]
===
match
---
name: Optional [41781,41789]
name: Optional [41801,41809]
===
match
---
param [4722,4730]
param [4750,4758]
===
match
---
expr_stmt [60121,60135]
expr_stmt [60141,60155]
===
match
---
atom_expr [82289,82318]
atom_expr [82309,82338]
===
match
---
trailer [78973,78981]
trailer [78993,79001]
===
match
---
operator: @ [41637,41638]
operator: @ [41657,41658]
===
match
---
dictorsetmaker [70554,70564]
dictorsetmaker [70574,70584]
===
match
---
name: TaskInstance [82129,82141]
name: TaskInstance [82149,82161]
===
match
---
atom_expr [37718,37732]
atom_expr [37738,37752]
===
match
---
suite [70524,71417]
suite [70544,71437]
===
match
---
trailer [50157,50175]
trailer [50177,50195]
===
match
---
simple_stmt [37702,37733]
simple_stmt [37722,37753]
===
match
---
operator: == [25338,25340]
operator: == [25358,25360]
===
match
---
simple_stmt [35192,35329]
simple_stmt [35212,35349]
===
match
---
name: add [57170,57173]
name: add [57190,57193]
===
match
---
operator: , [28998,28999]
operator: , [29018,29019]
===
match
---
dictorsetmaker [76964,77086]
dictorsetmaker [76984,77106]
===
match
---
expr_stmt [72900,72965]
expr_stmt [72920,72985]
===
match
---
trailer [49334,49339]
trailer [49354,49359]
===
match
---
atom [18754,18777]
atom [18774,18797]
===
match
---
name: taskfail [1944,1952]
name: taskfail [1929,1937]
===
match
---
expr_stmt [58239,58284]
expr_stmt [58259,58304]
===
match
---
name: datetime [15618,15626]
name: datetime [15638,15646]
===
match
---
parameters [4707,4774]
parameters [4735,4802]
===
match
---
trailer [8545,8569]
trailer [8573,8597]
===
match
---
simple_stmt [81507,81536]
simple_stmt [81527,81556]
===
match
---
trailer [64357,64388]
trailer [64377,64408]
===
match
---
name: self [25124,25128]
name: self [25144,25148]
===
match
---
atom_expr [80077,80088]
atom_expr [80097,80108]
===
match
---
trailer [11246,11254]
trailer [11274,11282]
===
match
---
operator: -> [81102,81104]
operator: -> [81122,81124]
===
match
---
name: tis [7797,7800]
name: tis [7825,7828]
===
match
---
atom_expr [3257,3284]
atom_expr [3285,3312]
===
match
---
name: self [13132,13136]
name: self [13152,13156]
===
match
---
name: num [47682,47685]
name: num [47702,47705]
===
match
---
trailer [68470,68477]
trailer [68490,68497]
===
match
---
simple_stmt [60644,60690]
simple_stmt [60664,60710]
===
match
---
funcdef [41663,45705]
funcdef [41683,45725]
===
match
---
trailer [26285,26291]
trailer [26305,26311]
===
match
---
name: session [21572,21579]
name: session [21592,21599]
===
match
---
name: replace [69496,69503]
name: replace [69516,69523]
===
match
---
param [77996,78049]
param [78016,78069]
===
match
---
suite [8640,8799]
suite [8668,8827]
===
match
---
operator: , [18650,18651]
operator: , [18670,18671]
===
match
---
name: get [64053,64056]
name: get [64073,64076]
===
match
---
trailer [68545,68572]
trailer [68565,68592]
===
match
---
operator: = [62045,62046]
operator: = [62065,62066]
===
match
---
name: ti [22626,22628]
name: ti [22646,22648]
===
match
---
name: ignore_all_deps [53975,53990]
name: ignore_all_deps [53995,54010]
===
match
---
trailer [79595,79617]
trailer [79615,79637]
===
match
---
operator: , [14204,14205]
operator: , [14224,14225]
===
match
---
name: self [40811,40815]
name: self [40831,40835]
===
match
---
simple_stmt [18743,18779]
simple_stmt [18763,18799]
===
match
---
operator: = [39690,39691]
operator: = [39710,39711]
===
match
---
name: state [5992,5997]
name: state [6020,6025]
===
match
---
expr_stmt [24797,24846]
expr_stmt [24817,24866]
===
match
---
arglist [32245,32280]
arglist [32265,32300]
===
match
---
argument [10015,10029]
argument [10043,10057]
===
match
---
expr_stmt [61819,61833]
expr_stmt [61839,61853]
===
match
---
argument [38443,38476]
argument [38463,38496]
===
match
---
name: with_row_locks [46084,46098]
name: with_row_locks [46104,46118]
===
match
---
name: timezone [39060,39068]
name: timezone [39080,39088]
===
match
---
suite [36095,41410]
suite [36115,41430]
===
match
---
arglist [53930,54293]
arglist [53950,54313]
===
match
---
suite [24443,25088]
suite [24463,25108]
===
match
---
fstring_end: ' [57004,57005]
fstring_end: ' [57024,57025]
===
match
---
trailer [9816,9850]
trailer [9844,9878]
===
match
---
expr_stmt [34660,34711]
expr_stmt [34680,34731]
===
match
---
name: str [81343,81346]
name: str [81363,81366]
===
match
---
arglist [6843,6896]
arglist [6871,6924]
===
match
---
simple_stmt [37570,37597]
simple_stmt [37590,37617]
===
match
---
operator: , [21054,21055]
operator: , [21074,21075]
===
match
---
operator: , [50675,50676]
operator: , [50695,50696]
===
match
---
name: queued_dttm [10201,10212]
name: queued_dttm [10229,10240]
===
match
---
name: Index [10628,10633]
name: Index [10656,10661]
===
match
---
name: String [10183,10189]
name: String [10211,10217]
===
match
---
name: dag [5370,5373]
name: dag [5398,5401]
===
match
---
string: "Current context is not equal to the state at context stack. Expected=%s, got=%s" [3743,3824]
string: "Current context is not equal to the state at context stack. Expected=%s, got=%s" [3771,3852]
===
match
---
simple_stmt [40892,40913]
simple_stmt [40912,40933]
===
match
---
name: test_mode [44185,44194]
name: test_mode [44205,44214]
===
match
---
atom_expr [48598,48643]
atom_expr [48618,48663]
===
match
---
name: task [50656,50660]
name: task [50676,50680]
===
match
---
atom_expr [40654,40668]
atom_expr [40674,40688]
===
match
---
operator: , [59370,59371]
operator: , [59390,59391]
===
match
---
param [14330,14340]
param [14350,14360]
===
match
---
name: self [23850,23854]
name: self [23870,23874]
===
match
---
atom_expr [32224,32281]
atom_expr [32244,32301]
===
match
---
if_stmt [6131,7287]
if_stmt [6159,7315]
===
match
---
operator: = [61581,61582]
operator: = [61601,61602]
===
match
---
name: delay [34660,34665]
name: delay [34680,34685]
===
match
---
tfpdef [56166,56191]
tfpdef [56186,56211]
===
match
---
name: Optional [26486,26494]
name: Optional [26506,26514]
===
match
---
comparison [53183,53217]
comparison [53203,53237]
===
match
---
fstring_start: f" [32990,32992]
fstring_start: f" [33010,33012]
===
match
---
name: get_previous_ti [28536,28551]
name: get_previous_ti [28556,28571]
===
match
---
operator: = [70884,70885]
operator: = [70904,70905]
===
match
---
atom_expr [62147,62192]
atom_expr [62167,62212]
===
match
---
arglist [44144,44194]
arglist [44164,44214]
===
match
---
string: 'dag' [60161,60166]
string: 'dag' [60181,60186]
===
match
---
if_stmt [58722,59001]
if_stmt [58742,59021]
===
match
---
simple_stmt [45600,45617]
simple_stmt [45620,45637]
===
match
---
trailer [5427,5436]
trailer [5455,5464]
===
match
---
operator: , [60159,60160]
operator: , [60179,60180]
===
match
---
trailer [26244,26259]
trailer [26264,26279]
===
match
---
name: self [41267,41271]
name: self [41287,41291]
===
match
---
simple_stmt [68193,68231]
simple_stmt [68213,68251]
===
match
---
trailer [52624,52631]
trailer [52644,52651]
===
match
---
operator: , [32378,32379]
operator: , [32398,32399]
===
match
---
param [18904,18908]
param [18924,18928]
===
match
---
string: 'Exception:<br>{{exception_html}}<br>' [69833,69871]
string: 'Exception:<br>{{exception_html}}<br>' [69853,69891]
===
match
---
operator: , [8547,8548]
operator: , [8575,8576]
===
match
---
name: XCom [77341,77345]
name: XCom [77361,77365]
===
match
---
name: dag_id [19731,19737]
name: dag_id [19751,19757]
===
match
---
simple_stmt [27869,27936]
simple_stmt [27889,27956]
===
match
---
atom_expr [74183,74409]
atom_expr [74203,74429]
===
match
---
string: '%Y-%m-%d' [61947,61957]
string: '%Y-%m-%d' [61967,61977]
===
match
---
trailer [62629,62661]
trailer [62649,62681]
===
match
---
name: self [41369,41373]
name: self [41389,41393]
===
match
---
name: Column [10103,10109]
name: Column [10131,10137]
===
match
---
return_stmt [67703,67727]
return_stmt [67723,67747]
===
match
---
trailer [48304,48306]
trailer [48324,48326]
===
match
---
simple_stmt [39042,39078]
simple_stmt [39062,39098]
===
match
---
trailer [52929,52934]
trailer [52949,52954]
===
match
---
name: self [23991,23995]
name: self [24011,24015]
===
match
---
name: dag_id [77658,77664]
name: dag_id [77678,77684]
===
match
---
name: get [19584,19587]
name: get [19604,19607]
===
match
---
operator: , [51953,51954]
operator: , [51973,51974]
===
match
---
tfpdef [35924,35942]
tfpdef [35944,35962]
===
match
---
name: executor_config [10304,10319]
name: executor_config [10332,10347]
===
match
---
arith_expr [8549,8568]
arith_expr [8577,8596]
===
match
---
trailer [78325,78328]
trailer [78345,78348]
===
match
---
trailer [60591,60603]
trailer [60611,60623]
===
match
---
operator: , [28446,28447]
operator: , [28466,28467]
===
match
---
simple_stmt [37605,37665]
simple_stmt [37625,37685]
===
match
---
name: state [43201,43206]
name: state [43221,43226]
===
match
---
operator: , [16078,16079]
operator: , [16098,16099]
===
match
---
name: self [73127,73131]
name: self [73147,73151]
===
match
---
name: str [80090,80093]
name: str [80110,80113]
===
match
---
name: TR [39165,39167]
name: TR [39185,39187]
===
match
---
funcdef [8576,8799]
funcdef [8604,8827]
===
match
---
name: __getattr__ [63014,63025]
name: __getattr__ [63034,63045]
===
match
---
name: path [14735,14739]
name: path [14755,14759]
===
match
---
argument [15368,15375]
argument [15388,15395]
===
match
---
name: debug [31822,31827]
name: debug [31842,31847]
===
match
---
try_stmt [54352,54857]
try_stmt [54372,54877]
===
match
---
tfpdef [74585,74606]
tfpdef [74605,74626]
===
match
---
expr_stmt [21566,21779]
expr_stmt [21586,21799]
===
match
---
name: on_failure_callback [52835,52854]
name: on_failure_callback [52855,52874]
===
match
---
name: execution_date [6079,6093]
name: execution_date [6107,6121]
===
match
---
trailer [59971,59976]
trailer [59991,59996]
===
match
---
if_stmt [52075,52154]
if_stmt [52095,52174]
===
match
---
trailer [77934,77947]
trailer [77954,77967]
===
match
---
return_stmt [35020,35110]
return_stmt [35040,35130]
===
match
---
trailer [43485,43490]
trailer [43505,43510]
===
match
---
operator: = [79853,79854]
operator: = [79873,79874]
===
match
---
trailer [18360,18367]
trailer [18380,18387]
===
match
---
atom_expr [53158,53167]
atom_expr [53178,53187]
===
match
---
trailer [60230,60247]
trailer [60250,60267]
===
match
---
name: execution_date [11989,12003]
name: execution_date [12017,12031]
===
match
---
trailer [81287,81304]
trailer [81307,81324]
===
match
---
atom_expr [68067,68084]
atom_expr [68087,68104]
===
match
---
atom_expr [31854,31924]
atom_expr [31874,31944]
===
match
---
name: utils [2618,2623]
name: utils [2603,2608]
===
match
---
name: Optional [29773,29781]
name: Optional [29793,29801]
===
match
---
suite [64412,64577]
suite [64432,64597]
===
match
---
name: self [43024,43028]
name: self [43044,43048]
===
match
---
operator: = [10046,10047]
operator: = [10074,10075]
===
match
---
operator: , [24003,24004]
operator: , [24023,24024]
===
match
---
name: RUNNING [40802,40809]
name: RUNNING [40822,40829]
===
match
---
name: context [68193,68200]
name: context [68213,68220]
===
match
---
trailer [72223,72270]
trailer [72243,72290]
===
match
---
trailer [82618,82626]
trailer [82638,82646]
===
match
---
import_from [59985,60011]
import_from [60005,60031]
===
match
---
name: self [58598,58602]
name: self [58618,58622]
===
match
---
name: str [80694,80697]
name: str [80714,80717]
===
match
---
trailer [55331,55340]
trailer [55351,55360]
===
match
---
name: _try_number [9796,9807]
name: _try_number [9824,9835]
===
match
---
name: execution_date [15019,15033]
name: execution_date [15039,15053]
===
match
---
operator: { [56988,56989]
operator: { [57008,57009]
===
match
---
name: verbose_aware_logger [31760,31780]
name: verbose_aware_logger [31780,31800]
===
match
---
trailer [23407,23429]
trailer [23427,23449]
===
match
---
tfpdef [29174,29194]
tfpdef [29194,29214]
===
match
---
comparison [51814,51832]
comparison [51834,51852]
===
match
---
trailer [43978,43990]
trailer [43998,44010]
===
match
---
trailer [62248,62257]
trailer [62268,62277]
===
match
---
name: test_mode [37575,37584]
name: test_mode [37595,37604]
===
match
---
with_stmt [51419,51542]
with_stmt [51439,51562]
===
match
---
name: passed [32905,32911]
name: passed [32925,32931]
===
match
---
parameters [28104,28110]
parameters [28124,28130]
===
match
---
simple_stmt [51597,51617]
simple_stmt [51617,51637]
===
match
---
name: TaskInstance [21718,21730]
name: TaskInstance [21738,21750]
===
match
---
expr_stmt [6600,7188]
expr_stmt [6628,7216]
===
match
---
name: ignore_all_deps [15086,15101]
name: ignore_all_deps [15106,15121]
===
match
---
operator: , [68477,68478]
operator: , [68497,68498]
===
match
---
if_stmt [76897,77370]
if_stmt [76917,77390]
===
match
---
simple_stmt [17966,18022]
simple_stmt [17986,18042]
===
match
---
simple_stmt [55042,55066]
simple_stmt [55062,55086]
===
match
---
simple_stmt [43592,43619]
simple_stmt [43612,43639]
===
match
---
if_stmt [18609,18659]
if_stmt [18629,18679]
===
match
---
atom_expr [45536,45557]
atom_expr [45556,45577]
===
match
---
simple_stmt [26347,26364]
simple_stmt [26367,26384]
===
match
---
argument [59372,59393]
argument [59392,59413]
===
match
---
name: pod [69126,69129]
name: pod [69146,69149]
===
match
---
name: task [46647,46651]
name: task [46667,46671]
===
match
---
param [74509,74514]
param [74529,74534]
===
match
---
decorated [29098,29697]
decorated [29118,29717]
===
match
---
name: rendered_k8s_spec [67477,67494]
name: rendered_k8s_spec [67497,67514]
===
match
---
expr_stmt [22701,22728]
expr_stmt [22721,22748]
===
match
---
name: pendulum [1208,1216]
name: pendulum [1193,1201]
===
match
---
operator: , [53520,53521]
operator: , [53540,53541]
===
match
---
param [13276,13281]
param [13296,13301]
===
match
---
with_item [4380,4408]
with_item [4408,4436]
===
match
---
operator: = [58251,58252]
operator: = [58271,58272]
===
match
---
atom_expr [23338,23353]
atom_expr [23358,23373]
===
match
---
operator: = [55199,55200]
operator: = [55219,55220]
===
match
---
operator: , [68612,68613]
operator: , [68632,68633]
===
match
---
string: "run" [17993,17998]
string: "run" [18013,18018]
===
match
---
operator: , [1258,1259]
operator: , [1243,1244]
===
match
---
atom_expr [11263,11272]
atom_expr [11291,11300]
===
match
---
operator: = [20583,20584]
operator: = [20603,20604]
===
match
---
name: self [11288,11292]
name: self [11316,11320]
===
match
---
parameters [64234,64411]
parameters [64254,64431]
===
match
---
expr_stmt [57974,58042]
expr_stmt [57994,58062]
===
match
---
operator: = [53707,53708]
operator: = [53727,53728]
===
match
---
dotted_name [1596,1617]
dotted_name [1581,1602]
===
match
---
operator: , [41438,41439]
operator: , [41458,41459]
===
match
---
string: """Log URL for TaskInstance""" [19187,19217]
string: """Log URL for TaskInstance""" [19207,19237]
===
match
---
return_stmt [8471,8570]
return_stmt [8499,8598]
===
match
---
trailer [20929,20936]
trailer [20949,20956]
===
match
---
name: _executor_config [80118,80134]
name: _executor_config [80138,80154]
===
match
---
name: full_filepath [14692,14705]
name: full_filepath [14712,14725]
===
match
---
import_from [2026,2070]
import_from [2011,2055]
===
match
---
simple_stmt [59506,59551]
simple_stmt [59526,59571]
===
match
---
suite [59027,59060]
suite [59047,59080]
===
match
---
suite [67589,67695]
suite [67609,67715]
===
match
---
name: state [29174,29179]
name: state [29194,29199]
===
match
---
operator: { [45006,45007]
operator: { [45026,45027]
===
match
---
string: """Load and return error from error file""" [3974,4017]
string: """Load and return error from error file""" [4002,4045]
===
match
---
string: """         Immediately runs the task (without checking or changing db state         before execution) and then sets the appropriate final state after         completion and runs any post-execute callbacks. Meant to be called         only after another function changes the state to running.          :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [41926,42612]
string: """         Immediately runs the task (without checking or changing db state         before execution) and then sets the appropriate final state after         completion and runs any post-execute callbacks. Meant to be called         only after another function changes the state to running.          :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [41946,42632]
===
match
---
atom_expr [7699,7708]
atom_expr [7727,7736]
===
match
---
operator: { [33007,33008]
operator: { [33027,33028]
===
match
---
atom_expr [43537,43579]
atom_expr [43557,43599]
===
match
---
fstring_end: " [49350,49351]
fstring_end: " [49370,49371]
===
match
---
name: verbose [41156,41163]
name: verbose [41176,41183]
===
match
---
atom_expr [18965,18996]
atom_expr [18985,19016]
===
match
---
simple_stmt [60584,60606]
simple_stmt [60604,60626]
===
match
---
trailer [24819,24830]
trailer [24839,24850]
===
match
---
name: result [51498,51504]
name: result [51518,51524]
===
match
---
trailer [57092,57096]
trailer [57112,57116]
===
match
---
dotted_name [1894,1912]
dotted_name [1879,1897]
===
match
---
name: force_fail [44338,44348]
name: force_fail [44358,44368]
===
match
---
trailer [11807,11816]
trailer [11835,11844]
===
match
---
name: filter [7397,7403]
name: filter [7425,7431]
===
match
---
name: queue [80509,80514]
name: queue [80529,80534]
===
match
---
name: session [38595,38602]
name: session [38615,38622]
===
match
---
name: task_id [15580,15587]
name: task_id [15600,15607]
===
match
---
funcdef [51923,52324]
funcdef [51943,52344]
===
match
---
name: bool [53470,53474]
name: bool [53490,53494]
===
match
---
operator: == [53116,53118]
operator: == [53136,53138]
===
match
---
operator: = [26525,26526]
operator: = [26545,26546]
===
match
---
atom_expr [5520,5532]
atom_expr [5548,5560]
===
match
---
string: 'json' [65970,65976]
string: 'json' [65990,65996]
===
match
---
term [34171,34192]
term [34191,34212]
===
match
---
simple_stmt [48598,48644]
simple_stmt [48618,48664]
===
match
---
atom_expr [58147,58168]
atom_expr [58167,58188]
===
match
---
atom_expr [46898,46909]
atom_expr [46918,46929]
===
match
---
name: get [64519,64522]
name: get [64539,64542]
===
match
---
name: dict [71539,71543]
name: dict [71559,71563]
===
match
---
annassign [79894,79924]
annassign [79914,79944]
===
match
---
simple_stmt [79874,79925]
simple_stmt [79894,79945]
===
match
---
trailer [71989,71995]
trailer [72009,72015]
===
match
---
operator: @ [81142,81143]
operator: @ [81162,81163]
===
match
---
atom_expr [55369,55388]
atom_expr [55389,55408]
===
match
---
name: conf [68020,68024]
name: conf [68040,68044]
===
match
---
operator: , [3824,3825]
operator: , [3852,3853]
===
match
---
operator: , [78030,78031]
operator: , [78050,78051]
===
match
---
trailer [82157,82166]
trailer [82177,82186]
===
match
---
name: items [7082,7087]
name: items [7110,7115]
===
match
---
trailer [61788,61809]
trailer [61808,61829]
===
match
---
trailer [71194,71201]
trailer [71214,71221]
===
match
---
simple_stmt [60339,60515]
simple_stmt [60359,60535]
===
match
---
trailer [45419,45434]
trailer [45439,45454]
===
match
---
name: self [41690,41694]
name: self [41710,41714]
===
match
---
atom_expr [5919,5931]
atom_expr [5947,5959]
===
match
---
atom_expr [4022,4045]
atom_expr [4050,4073]
===
match
---
simple_stmt [48886,48980]
simple_stmt [48906,49000]
===
match
---
param [59853,59858]
param [59873,59878]
===
match
---
trailer [60843,60858]
trailer [60863,60878]
===
match
---
trailer [46905,46909]
trailer [46925,46929]
===
match
---
name: session [31916,31923]
name: session [31936,31943]
===
match
---
operator: = [35868,35869]
operator: = [35888,35889]
===
match
---
name: delete [7224,7230]
name: delete [7252,7258]
===
match
---
name: renderedtifields [67280,67296]
name: renderedtifields [67300,67316]
===
match
---
atom_expr [68981,69010]
atom_expr [69001,69030]
===
match
---
operator: , [53481,53482]
operator: , [53501,53502]
===
match
---
name: IO [1052,1054]
name: IO [1037,1039]
===
match
---
argument [30844,30856]
argument [30864,30876]
===
match
---
simple_stmt [51183,51255]
simple_stmt [51203,51275]
===
match
---
trailer [6970,6972]
trailer [6998,7000]
===
match
---
name: item [64057,64061]
name: item [64077,64081]
===
match
---
name: jinja_env [70997,71006]
name: jinja_env [71017,71026]
===
match
---
name: executor_config [68799,68814]
name: executor_config [68819,68834]
===
match
---
trailer [67521,67523]
trailer [67541,67543]
===
match
---
operator: , [10403,10404]
operator: , [10431,10432]
===
match
---
name: qry [21887,21890]
name: qry [21907,21910]
===
match
---
operator: , [15164,15165]
operator: , [15184,15185]
===
match
---
simple_stmt [50973,50990]
simple_stmt [50993,51010]
===
match
---
name: self [29760,29764]
name: self [29780,29784]
===
match
---
operator: , [15662,15663]
operator: , [15682,15683]
===
match
---
string: """Only Renders Templates for the TI""" [54889,54928]
string: """Only Renders Templates for the TI""" [54909,54948]
===
match
---
expr_stmt [60057,60068]
expr_stmt [60077,60088]
===
match
---
name: scalar [77800,77806]
name: scalar [77820,77826]
===
match
---
simple_stmt [14913,15468]
simple_stmt [14933,15488]
===
match
---
comp_op [27650,27656]
comp_op [27670,27676]
===
match
---
number: 1 [60791,60792]
number: 1 [60811,60812]
===
match
---
atom_expr [11207,11218]
atom_expr [11235,11246]
===
match
---
expr_stmt [77250,77296]
expr_stmt [77270,77316]
===
match
---
if_stmt [13129,13197]
if_stmt [13149,13217]
===
match
---
name: DagRun [35445,35451]
name: DagRun [35465,35471]
===
match
---
name: log [29511,29514]
name: log [29531,29534]
===
match
---
name: self [19527,19531]
name: self [19547,19551]
===
match
---
name: current_state [19879,19892]
name: current_state [19899,19912]
===
match
---
atom_expr [36001,36014]
atom_expr [36021,36034]
===
match
---
operator: , [65552,65553]
operator: , [65572,65573]
===
match
---
atom_expr [24699,24761]
atom_expr [24719,24781]
===
match
---
name: log [58349,58352]
name: log [58369,58372]
===
match
---
name: extend [18527,18533]
name: extend [18547,18553]
===
match
---
if_stmt [12100,12141]
if_stmt [12120,12161]
===
match
---
trailer [40350,40365]
trailer [40370,40385]
===
match
---
param [55143,55148]
param [55163,55168]
===
match
---
simple_stmt [72202,72271]
simple_stmt [72222,72291]
===
match
---
name: BaseJob [7346,7353]
name: BaseJob [7374,7381]
===
match
---
name: datetime [8090,8098]
name: datetime [8118,8126]
===
match
---
atom_expr [3946,3967]
atom_expr [3974,3995]
===
match
---
operator: = [59264,59265]
operator: = [59284,59285]
===
match
---
name: self [26120,26124]
name: self [26140,26144]
===
match
---
simple_stmt [41210,41288]
simple_stmt [41230,41308]
===
match
---
name: execution_date [8074,8088]
name: execution_date [8102,8116]
===
match
---
atom [70553,70565]
atom [70573,70585]
===
match
---
operator: , [10618,10619]
operator: , [10646,10647]
===
match
---
name: session [45696,45703]
name: session [45716,45723]
===
match
---
atom_expr [32794,32811]
atom_expr [32814,32831]
===
match
---
funcdef [8138,8311]
funcdef [8166,8339]
===
match
---
decorated [32307,32950]
decorated [32327,32970]
===
match
---
operator: , [59646,59647]
operator: , [59666,59667]
===
match
---
trailer [79067,79074]
trailer [79087,79094]
===
match
---
param [41773,41802]
param [41793,41822]
===
match
---
name: commit [40479,40485]
name: commit [40499,40505]
===
match
---
name: ti [5952,5954]
name: ti [5980,5982]
===
match
---
trailer [82092,82099]
trailer [82112,82119]
===
match
---
name: max_tries [70941,70950]
name: max_tries [70961,70970]
===
match
---
operator: = [10083,10084]
operator: = [10111,10112]
===
match
---
name: ti [21910,21912]
name: ti [21930,21932]
===
match
---
atom_expr [45266,45277]
atom_expr [45286,45297]
===
match
---
simple_stmt [62481,62508]
simple_stmt [62501,62528]
===
match
---
name: REQUEUEABLE_DEPS [39585,39601]
name: REQUEUEABLE_DEPS [39605,39621]
===
match
---
and_test [11452,11512]
and_test [11480,11540]
===
match
---
name: Any [3208,3211]
name: Any [3236,3239]
===
match
---
operator: = [38602,38603]
operator: = [38622,38623]
===
match
---
name: property [80912,80920]
name: property [80932,80940]
===
match
---
atom_expr [55011,55020]
atom_expr [55031,55040]
===
match
---
simple_stmt [5505,5533]
simple_stmt [5533,5561]
===
match
---
trailer [43145,43161]
trailer [43165,43181]
===
match
---
name: self [11193,11197]
name: self [11221,11225]
===
match
---
argument [39899,39914]
argument [39919,39934]
===
match
---
operator: } [19113,19114]
operator: } [19133,19134]
===
match
---
dotted_name [13239,13256]
dotted_name [13259,13276]
===
match
---
operator: == [6762,6764]
operator: == [6790,6792]
===
match
---
name: self [37793,37797]
name: self [37813,37817]
===
match
---
name: self [11263,11267]
name: self [11291,11295]
===
match
---
name: execution_date [73929,73943]
name: execution_date [73949,73963]
===
match
---
suite [44664,44688]
suite [44684,44708]
===
match
---
import_name [835,849]
import_name [820,834]
===
match
---
trailer [82107,82115]
trailer [82127,82135]
===
match
---
name: pool [14330,14334]
name: pool [14350,14354]
===
match
---
name: task_id [68491,68498]
name: task_id [68511,68518]
===
match
---
string: 'execution_date is {}; received {})' [74079,74115]
string: 'execution_date is {}; received {})' [74099,74135]
===
match
---
param [74623,74650]
param [74643,74670]
===
match
---
atom_expr [60839,60858]
atom_expr [60859,60878]
===
match
---
name: dag [46652,46655]
name: dag [46672,46675]
===
match
---
name: default_var [63555,63566]
name: default_var [63575,63586]
===
match
---
trailer [18134,18164]
trailer [18154,18184]
===
match
---
trailer [31791,31796]
trailer [31811,31816]
===
match
---
operator: == [77650,77652]
operator: == [77670,77672]
===
match
---
name: execution_date [35510,35524]
name: execution_date [35530,35544]
===
match
---
trailer [51524,51541]
trailer [51544,51561]
===
match
---
name: REQUEUEABLE_DEPS [38248,38264]
name: REQUEUEABLE_DEPS [38268,38284]
===
match
---
name: self [66679,66683]
name: self [66699,66703]
===
match
---
string: "%s dependency '%s' PASSED: %s, %s" [32670,32705]
string: "%s dependency '%s' PASSED: %s, %s" [32690,32725]
===
match
---
operator: = [39885,39886]
operator: = [39905,39906]
===
match
---
name: dag_id [9533,9539]
name: dag_id [9561,9567]
===
match
---
operator: = [22624,22625]
operator: = [22644,22645]
===
match
---
name: TaskInstance [82180,82192]
name: TaskInstance [82200,82212]
===
match
---
name: self [68678,68682]
name: self [68698,68702]
===
match
---
name: min_backoff [33645,33656]
name: min_backoff [33665,33676]
===
match
---
name: sentry [2199,2205]
name: sentry [2184,2190]
===
match
---
operator: , [77771,77772]
operator: , [77791,77792]
===
match
---
trailer [23486,23496]
trailer [23506,23516]
===
match
---
trailer [57923,57930]
trailer [57943,57950]
===
match
---
operator: , [58644,58645]
operator: , [58664,58665]
===
match
---
atom_expr [20911,20921]
atom_expr [20931,20941]
===
match
---
atom_expr [51048,51124]
atom_expr [51068,51144]
===
match
---
param [19172,19176]
param [19192,19196]
===
match
---
string: 'BASE_URL' [19601,19611]
string: 'BASE_URL' [19621,19631]
===
match
---
name: DagRun [7635,7641]
name: DagRun [7663,7669]
===
match
---
name: render [72099,72105]
name: render [72119,72125]
===
match
---
except_clause [52162,52185]
except_clause [52182,52205]
===
match
---
name: Column [9747,9753]
name: Column [9775,9781]
===
match
---
name: ts [60698,60700]
name: ts [60718,60720]
===
match
---
param [4763,4772]
param [4791,4800]
===
match
---
trailer [38515,38536]
trailer [38535,38556]
===
match
---
atom_expr [78972,78981]
atom_expr [78992,79001]
===
match
---
parameters [55142,55220]
parameters [55162,55240]
===
match
---
name: self [63195,63199]
name: self [63215,63219]
===
match
---
name: PodGenerator [68772,68784]
name: PodGenerator [68792,68804]
===
match
---
name: base_job [82509,82517]
name: base_job [82529,82537]
===
match
---
param [11102,11127]
param [11130,11155]
===
match
---
trailer [26291,26295]
trailer [26311,26315]
===
match
---
trailer [46151,46278]
trailer [46171,46298]
===
match
---
name: lock_for_update [37643,37658]
name: lock_for_update [37663,37678]
===
match
---
trailer [10339,10353]
trailer [10367,10381]
===
match
---
name: task [41363,41367]
name: task [41383,41387]
===
match
---
name: dag_id [79315,79321]
name: dag_id [79335,79341]
===
match
---
name: log [43513,43516]
name: log [43533,43536]
===
match
---
name: session [59281,59288]
name: session [59301,59308]
===
match
---
if_stmt [45494,45591]
if_stmt [45514,45611]
===
match
---
atom_expr [50651,50670]
atom_expr [50671,50690]
===
match
---
name: session [23895,23902]
name: session [23915,23922]
===
match
---
name: property [80660,80668]
name: property [80680,80688]
===
match
---
name: task_id [77711,77718]
name: task_id [77731,77738]
===
match
---
operator: == [77755,77757]
operator: == [77775,77777]
===
match
---
simple_stmt [81658,82018]
simple_stmt [81678,82038]
===
match
---
suite [79013,79235]
suite [79033,79255]
===
match
---
trailer [50958,50964]
trailer [50978,50984]
===
match
---
name: execution_date [60460,60474]
name: execution_date [60480,60494]
===
match
---
trailer [48839,48856]
trailer [48859,48876]
===
match
---
trailer [80307,80313]
trailer [80327,80333]
===
match
---
operator: } [49345,49346]
operator: } [49365,49366]
===
match
---
operator: , [26506,26507]
operator: , [26526,26527]
===
match
---
trailer [40448,40454]
trailer [40468,40474]
===
match
---
atom_expr [78347,78359]
atom_expr [78367,78379]
===
match
---
name: set_current_context [3318,3337]
name: set_current_context [3346,3365]
===
match
---
name: airflow [2257,2264]
name: airflow [2242,2249]
===
match
---
import_from [1969,2025]
import_from [1954,2010]
===
match
---
name: self [19172,19176]
name: self [19192,19196]
===
match
---
operator: , [43835,43836]
operator: , [43855,43856]
===
match
---
name: debug [73030,73035]
name: debug [73050,73055]
===
match
---
operator: , [59694,59695]
operator: , [59714,59715]
===
match
---
name: self [50959,50963]
name: self [50979,50983]
===
match
---
trailer [11542,11688]
trailer [11570,11716]
===
match
---
name: uselist [11027,11034]
name: uselist [11055,11062]
===
match
---
name: NamedTemporaryFile [1014,1032]
name: NamedTemporaryFile [999,1017]
===
match
---
decorated [13884,13999]
decorated [13904,14019]
===
match
---
name: self [40557,40561]
name: self [40577,40581]
===
match
---
name: delay_backoff_in_seconds [34686,34710]
name: delay_backoff_in_seconds [34706,34730]
===
match
---
trailer [54398,54411]
trailer [54418,54431]
===
match
---
name: PodGenerator [68419,68431]
name: PodGenerator [68439,68451]
===
match
---
operator: , [15268,15269]
operator: , [15288,15289]
===
match
---
atom_expr [21498,21556]
atom_expr [21518,21576]
===
match
---
name: dep_status [32137,32147]
name: dep_status [32157,32167]
===
match
---
name: session [35431,35438]
name: session [35451,35458]
===
match
---
trailer [50326,50355]
trailer [50346,50375]
===
match
---
name: pickle_id [14634,14643]
name: pickle_id [14654,14663]
===
match
---
decorator [12468,12483]
decorator [12488,12503]
===
match
---
atom_expr [80800,80820]
atom_expr [80820,80840]
===
match
---
operator: = [77854,77855]
operator: = [77874,77875]
===
match
---
if_stmt [24855,25060]
if_stmt [24875,25080]
===
match
---
trailer [45840,45851]
trailer [45860,45871]
===
match
---
decorator [59807,59824]
decorator [59827,59844]
===
match
---
operator: { [65952,65953]
operator: { [65972,65973]
===
match
---
operator: , [26195,26196]
operator: , [26215,26216]
===
match
---
operator: { [19770,19771]
operator: { [19790,19791]
===
match
---
operator: = [46856,46857]
operator: = [46876,46877]
===
match
---
decorator [80826,80836]
decorator [80846,80856]
===
match
---
trailer [68019,68024]
trailer [68039,68044]
===
match
---
trailer [22866,22872]
trailer [22886,22892]
===
match
---
name: self [59566,59570]
name: self [59586,59590]
===
match
---
atom_expr [59216,59230]
atom_expr [59236,59250]
===
match
---
name: task_id [68564,68571]
name: task_id [68584,68591]
===
match
---
expr_stmt [51498,51541]
expr_stmt [51518,51561]
===
match
---
expr_stmt [48266,48306]
expr_stmt [48286,48326]
===
match
---
atom_expr [64178,64186]
atom_expr [64198,64206]
===
match
---
funcdef [81086,81137]
funcdef [81106,81157]
===
match
---
simple_stmt [24088,24105]
simple_stmt [24108,24125]
===
match
---
name: self [8342,8346]
name: self [8370,8374]
===
match
---
atom_expr [79816,79825]
atom_expr [79836,79845]
===
match
---
name: end_date [72922,72930]
name: end_date [72942,72950]
===
match
---
trailer [22064,22073]
trailer [22084,22093]
===
match
---
string: "Received SIGTERM. Terminating subprocesses." [48443,48488]
string: "Received SIGTERM. Terminating subprocesses." [48463,48508]
===
match
---
atom_expr [27883,27935]
atom_expr [27903,27955]
===
match
---
name: self [71719,71723]
name: self [71739,71743]
===
match
---
suite [3145,3167]
suite [3173,3195]
===
match
---
operator: , [1874,1875]
operator: , [1859,1860]
===
match
---
name: session [24088,24095]
name: session [24108,24115]
===
match
---
simple_stmt [63907,63923]
simple_stmt [63927,63943]
===
match
---
param [41690,41695]
param [41710,41715]
===
match
---
operator: , [30988,30989]
operator: , [31008,31009]
===
match
---
name: self [55743,55747]
name: self [55763,55767]
===
match
---
operator: = [80504,80505]
operator: = [80524,80525]
===
match
---
atom [66722,66762]
atom [66742,66782]
===
match
---
comparison [44620,44663]
comparison [44640,44683]
===
match
---
return_stmt [13205,13232]
return_stmt [13225,13252]
===
match
---
name: session [50973,50980]
name: session [50993,51000]
===
match
---
operator: , [55534,55535]
operator: , [55554,55555]
===
match
---
name: task_id_by_key [5065,5079]
name: task_id_by_key [5093,5107]
===
match
---
trailer [10328,10354]
trailer [10356,10382]
===
match
---
trailer [48764,48820]
trailer [48784,48840]
===
match
---
name: item [64523,64527]
name: item [64543,64547]
===
match
---
param [53655,53682]
param [53675,53702]
===
match
---
atom_expr [61771,61809]
atom_expr [61791,61829]
===
match
---
test [60536,60571]
test [60556,60591]
===
match
---
simple_stmt [72720,72775]
simple_stmt [72740,72795]
===
match
---
trailer [61719,61727]
trailer [61739,61747]
===
match
---
name: reason [32844,32850]
name: reason [32864,32870]
===
match
---
name: Union [74542,74547]
name: Union [74562,74567]
===
match
---
atom_expr [4653,4680]
atom_expr [4681,4708]
===
match
---
expr_stmt [12588,12610]
expr_stmt [12608,12630]
===
match
---
name: try_number [33950,33960]
name: try_number [33970,33980]
===
match
---
if_stmt [39090,39329]
if_stmt [39110,39349]
===
match
---
operator: , [22945,22946]
operator: , [22965,22966]
===
match
---
name: task_id [79195,79202]
name: task_id [79215,79222]
===
match
---
expr_stmt [7919,7952]
expr_stmt [7947,7980]
===
match
---
name: execution_date [20445,20459]
name: execution_date [20465,20479]
===
match
---
simple_stmt [43313,43320]
simple_stmt [43333,43340]
===
match
---
name: state [33065,33070]
name: state [33085,33090]
===
match
---
return_stmt [8716,8798]
return_stmt [8744,8826]
===
match
---
simple_stmt [900,916]
simple_stmt [885,901]
===
match
---
parameters [24175,24181]
parameters [24195,24201]
===
match
---
expr_stmt [79874,79924]
expr_stmt [79894,79944]
===
match
---
name: task_copy [54962,54971]
name: task_copy [54982,54991]
===
match
---
operator: , [47424,47425]
operator: , [47444,47445]
===
match
---
expr_stmt [10239,10273]
expr_stmt [10267,10301]
===
match
---
tfpdef [73159,73169]
tfpdef [73179,73189]
===
match
---
string: """Render templates in the operator fields.""" [68110,68156]
string: """Render templates in the operator fields.""" [68130,68176]
===
match
---
simple_stmt [71780,71821]
simple_stmt [71800,71841]
===
match
---
simple_stmt [66785,67161]
simple_stmt [66805,67181]
===
match
---
name: is_eligible_to_retry [59470,59490]
name: is_eligible_to_retry [59490,59510]
===
match
---
suite [66768,67161]
suite [66788,67181]
===
match
---
operator: @ [80826,80827]
operator: @ [80846,80847]
===
match
---
trailer [3951,3967]
trailer [3979,3995]
===
match
---
name: List [1077,1081]
name: List [1062,1066]
===
match
---
name: debug [23859,23864]
name: debug [23879,23884]
===
match
---
trailer [52144,52153]
trailer [52164,52173]
===
match
---
simple_stmt [59040,59060]
simple_stmt [59060,59080]
===
match
---
funcdef [25417,26418]
funcdef [25437,26438]
===
match
---
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [70282,70326]
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [70302,70346]
===
match
---
name: dag_id [44998,45004]
name: dag_id [45018,45024]
===
match
---
dotted_name [48191,48222]
dotted_name [48211,48242]
===
match
---
trailer [41362,41367]
trailer [41382,41387]
===
match
---
atom_expr [42681,42729]
atom_expr [42701,42749]
===
match
---
name: value [13317,13322]
name: value [13337,13342]
===
match
---
trailer [57096,57121]
trailer [57116,57141]
===
match
---
trailer [40247,40258]
trailer [40267,40278]
===
match
---
name: TaskInstance [27263,27275]
name: TaskInstance [27283,27295]
===
match
---
trailer [80282,80294]
trailer [80302,80314]
===
match
---
trailer [50426,50435]
trailer [50446,50455]
===
match
---
suite [81267,81305]
suite [81287,81325]
===
match
---
atom_expr [81194,81204]
atom_expr [81214,81224]
===
match
---
simple_stmt [10035,10091]
simple_stmt [10063,10119]
===
match
---
return_stmt [81187,81204]
return_stmt [81207,81224]
===
match
---
argument [15340,15354]
argument [15360,15374]
===
match
---
string: """         Get datetime of the next retry if the task instance fails. For exponential         backoff, retry_delay is used as base and will be converted to seconds.         """ [33119,33296]
string: """         Get datetime of the next retry if the task instance fails. For exponential         backoff, retry_delay is used as base and will be converted to seconds.         """ [33139,33316]
===
match
---
name: task [11268,11272]
name: task [11296,11300]
===
match
---
param [48130,48134]
param [48150,48154]
===
match
---
trailer [39991,39995]
trailer [40011,40015]
===
match
---
fstring_expr [19725,19738]
fstring_expr [19745,19758]
===
match
---
name: merge [59048,59053]
name: merge [59068,59073]
===
match
---
operator: = [23662,23663]
operator: = [23682,23683]
===
match
---
operator: = [32453,32454]
operator: = [32473,32474]
===
match
---
suite [54880,55094]
suite [54900,55114]
===
match
---
name: self [57905,57909]
name: self [57925,57929]
===
match
---
name: Index [1313,1318]
name: Index [1298,1303]
===
match
---
operator: = [30150,30151]
operator: = [30170,30171]
===
match
---
trailer [71091,71101]
trailer [71111,71121]
===
match
---
name: Column [9995,10001]
name: Column [10023,10029]
===
match
---
atom [18641,18657]
atom [18661,18677]
===
match
---
param [81096,81100]
param [81116,81120]
===
match
---
atom_expr [12122,12132]
atom_expr [12142,12152]
===
match
---
name: commit [38664,38670]
name: commit [38684,38690]
===
match
---
name: autoescape [71104,71114]
name: autoescape [71124,71134]
===
match
---
name: registered [50196,50206]
name: registered [50216,50226]
===
match
---
trailer [40881,40883]
trailer [40901,40903]
===
match
---
simple_stmt [52426,52594]
simple_stmt [52446,52614]
===
match
---
return_stmt [72061,72122]
return_stmt [72081,72142]
===
match
---
name: self [22496,22500]
name: self [22516,22520]
===
match
---
operator: = [3160,3161]
operator: = [3188,3189]
===
match
---
operator: = [10174,10175]
operator: = [10202,10203]
===
match
---
name: ignore_depends_on_past [38403,38425]
name: ignore_depends_on_past [38423,38445]
===
match
---
expr_stmt [76445,76687]
expr_stmt [76465,76707]
===
match
---
atom_expr [20945,20964]
atom_expr [20965,20984]
===
match
---
name: self [21036,21040]
name: self [21056,21060]
===
match
---
simple_stmt [22858,22908]
simple_stmt [22878,22928]
===
match
---
name: self [45291,45295]
name: self [45311,45315]
===
match
---
simple_stmt [74749,76376]
simple_stmt [74769,76396]
===
match
---
operator: , [18218,18219]
operator: , [18238,18239]
===
match
---
suite [7517,7953]
suite [7545,7981]
===
match
---
operator: = [19577,19578]
operator: = [19597,19598]
===
match
---
name: error [56477,56482]
name: error [56497,56502]
===
match
---
trailer [27137,27158]
trailer [27157,27178]
===
match
---
name: UtcDateTime [9629,9640]
name: UtcDateTime [9657,9668]
===
match
---
parameters [30409,30415]
parameters [30429,30435]
===
match
---
operator: = [58145,58146]
operator: = [58165,58166]
===
match
---
name: xcom [77250,77254]
name: xcom [77270,77274]
===
match
---
operator: , [10777,10778]
operator: , [10805,10806]
===
match
---
name: State [5251,5256]
name: State [5279,5284]
===
match
---
trailer [37797,37803]
trailer [37817,37823]
===
match
---
name: update [70732,70738]
name: update [70752,70758]
===
match
---
simple_stmt [72369,72416]
simple_stmt [72389,72436]
===
match
---
name: pool [54254,54258]
name: pool [54274,54278]
===
match
---
operator: @ [12468,12469]
operator: @ [12488,12489]
===
match
---
name: self [23259,23263]
name: self [23279,23283]
===
match
---
expr_stmt [22416,22443]
expr_stmt [22436,22463]
===
match
---
simple_stmt [81043,81067]
simple_stmt [81063,81087]
===
match
---
arglist [24714,24760]
arglist [24734,24780]
===
match
---
name: dag_id [8744,8750]
name: dag_id [8772,8778]
===
match
---
operator: = [37658,37659]
operator: = [37678,37679]
===
match
---
trailer [68249,68272]
trailer [68269,68292]
===
match
---
name: ti [5919,5921]
name: ti [5947,5949]
===
match
---
dotted_name [1635,1653]
dotted_name [1620,1638]
===
match
---
name: self [11984,11988]
name: self [12012,12016]
===
match
---
operator: , [20391,20392]
operator: , [20411,20412]
===
match
---
fstring_string: dag. [48767,48771]
fstring_string: dag. [48787,48791]
===
match
---
operator: } [19737,19738]
operator: } [19757,19758]
===
match
---
parameters [80937,80943]
parameters [80957,80963]
===
match
---
trailer [10008,10013]
trailer [10036,10041]
===
match
---
name: instance [61780,61788]
name: instance [61800,61808]
===
match
---
param [59859,59871]
param [59879,59891]
===
match
---
name: Stats [50618,50623]
name: Stats [50638,50643]
===
match
---
name: signal [48598,48604]
name: signal [48618,48624]
===
match
---
import_from [2415,2457]
import_from [2400,2442]
===
match
---
fstring_string: . [33020,33021]
fstring_string: . [33040,33041]
===
match
---
expr_stmt [8057,8069]
expr_stmt [8085,8097]
===
match
---
name: _execution_date [82216,82231]
name: _execution_date [82236,82251]
===
match
---
atom_expr [23259,23269]
atom_expr [23279,23289]
===
match
---
operator: = [54079,54080]
operator: = [54099,54100]
===
match
---
name: count [77584,77589]
name: count [77604,77609]
===
match
---
trailer [7921,7932]
trailer [7949,7960]
===
match
---
name: self [54874,54878]
name: self [54894,54898]
===
match
---
trailer [41118,41126]
trailer [41138,41146]
===
match
---
name: html_content_err [71326,71342]
name: html_content_err [71346,71362]
===
match
---
name: state [20531,20536]
name: state [20551,20556]
===
match
---
name: TaskInstanceStateType [79566,79587]
name: TaskInstanceStateType [79586,79607]
===
match
---
trailer [37609,37625]
trailer [37629,37645]
===
match
---
name: ignore_task_deps [18327,18343]
name: ignore_task_deps [18347,18363]
===
match
---
except_clause [49926,49947]
except_clause [49946,49967]
===
match
---
expr_stmt [5417,5445]
expr_stmt [5445,5473]
===
match
---
name: merge [55945,55950]
name: merge [55965,55970]
===
match
---
trailer [68601,68612]
trailer [68621,68632]
===
match
---
atom [64593,66169]
atom [64613,66189]
===
match
---
trailer [22292,22303]
trailer [22312,22323]
===
match
---
suite [25130,25391]
suite [25150,25411]
===
match
---
name: session [36067,36074]
name: session [36087,36094]
===
match
---
argument [78895,78917]
argument [78915,78937]
===
match
---
atom_expr [80535,80541]
atom_expr [80555,80561]
===
match
---
operator: = [34685,34686]
operator: = [34705,34706]
===
match
---
name: task_copy [50490,50499]
name: task_copy [50510,50519]
===
match
---
suite [38032,40517]
suite [38052,40537]
===
match
---
name: params [62630,62636]
name: params [62650,62656]
===
match
---
operator: = [58313,58314]
operator: = [58333,58334]
===
match
---
expr_stmt [61543,61557]
expr_stmt [61563,61577]
===
match
---
name: next_retry_datetime [33084,33103]
name: next_retry_datetime [33104,33123]
===
match
---
operator: = [61916,61917]
operator: = [61936,61937]
===
match
---
name: end_date [9701,9709]
name: end_date [9729,9737]
===
match
---
name: exc_info [50161,50169]
name: exc_info [50181,50189]
===
match
---
string: 'ti_dag_date' [10634,10647]
string: 'ti_dag_date' [10662,10675]
===
match
---
name: max_tries [22379,22388]
name: max_tries [22399,22408]
===
match
---
expr_stmt [80436,80478]
expr_stmt [80456,80498]
===
match
---
name: REQUEUEABLE_DEPS [2349,2365]
name: REQUEUEABLE_DEPS [2334,2350]
===
match
---
name: _pool [80308,80313]
name: _pool [80328,80333]
===
match
---
simple_stmt [22416,22444]
simple_stmt [22436,22464]
===
match
---
trailer [26157,26165]
trailer [26177,26185]
===
match
---
name: COLLATION_ARGS [10407,10421]
name: COLLATION_ARGS [10435,10449]
===
match
---
trailer [54795,54801]
trailer [54815,54821]
===
match
---
if_stmt [60181,60248]
if_stmt [60201,60268]
===
match
---
annassign [80358,80380]
annassign [80378,80400]
===
match
---
name: dag [64645,64648]
name: dag [64665,64668]
===
match
---
name: models [60273,60279]
name: models [60293,60299]
===
match
---
trailer [29845,29854]
trailer [29865,29874]
===
match
---
operator: , [31906,31907]
operator: , [31926,31927]
===
match
---
operator: , [65106,65107]
operator: , [65126,65127]
===
match
---
argument [59448,59459]
argument [59468,59479]
===
match
---
simple_stmt [54336,54343]
simple_stmt [54356,54363]
===
match
---
simple_stmt [30612,30868]
simple_stmt [30632,30888]
===
match
---
trailer [51850,51860]
trailer [51870,51880]
===
match
---
name: airflow [2130,2137]
name: airflow [2115,2122]
===
match
---
name: refresh_from_db [42743,42758]
name: refresh_from_db [42763,42778]
===
match
---
atom_expr [64770,64808]
atom_expr [64790,64828]
===
match
---
operator: = [60129,60130]
operator: = [60149,60150]
===
match
---
name: prepare_for_execution [48283,48304]
name: prepare_for_execution [48303,48324]
===
match
---
atom_expr [4380,4402]
atom_expr [4408,4430]
===
match
---
name: state [10771,10776]
name: state [10799,10804]
===
match
---
atom_expr [8507,8519]
atom_expr [8535,8547]
===
match
---
expr_stmt [61632,61682]
expr_stmt [61652,61702]
===
match
---
name: extend [18063,18069]
name: extend [18083,18089]
===
match
---
atom_expr [59174,59195]
atom_expr [59194,59215]
===
match
---
if_stmt [41455,41593]
if_stmt [41475,41613]
===
match
---
name: stacklevel [29012,29022]
name: stacklevel [29032,29042]
===
match
---
atom_expr [54609,54622]
atom_expr [54629,54642]
===
match
---
operator: , [11126,11127]
operator: , [11154,11155]
===
match
---
trailer [45011,45019]
trailer [45031,45039]
===
match
---
name: RUNNING_DEPS [38233,38245]
name: RUNNING_DEPS [38253,38265]
===
match
---
name: pod [68413,68416]
name: pod [68433,68436]
===
match
---
name: max_tries [23487,23496]
name: max_tries [23507,23516]
===
match
---
trailer [19042,19072]
trailer [19062,19092]
===
match
---
name: ti [79962,79964]
name: ti [79982,79984]
===
match
---
atom_expr [26120,26131]
atom_expr [26140,26151]
===
match
---
decorator [30364,30374]
decorator [30384,30394]
===
match
---
trailer [39951,39957]
trailer [39971,39977]
===
match
---
operator: , [57208,57209]
operator: , [57228,57229]
===
match
---
name: max_tries [40285,40294]
name: max_tries [40305,40314]
===
match
---
name: Session [35167,35174]
name: Session [35187,35194]
===
match
---
operator: = [29077,29078]
operator: = [29097,29098]
===
match
---
atom_expr [72631,72681]
atom_expr [72651,72701]
===
match
---
name: with_try_number [8580,8595]
name: with_try_number [8608,8623]
===
match
---
simple_stmt [59985,60012]
simple_stmt [60005,60032]
===
match
---
operator: , [4675,4676]
operator: , [4703,4704]
===
match
---
trailer [27885,27905]
trailer [27905,27925]
===
match
---
atom_expr [44993,45004]
atom_expr [45013,45024]
===
match
---
name: models [1902,1908]
name: models [1887,1893]
===
match
---
trailer [40561,40565]
trailer [40581,40585]
===
match
---
atom_expr [54749,54774]
atom_expr [54769,54794]
===
match
---
simple_stmt [8074,8099]
simple_stmt [8102,8127]
===
match
---
trailer [61512,61533]
trailer [61532,61553]
===
match
---
name: self [52741,52745]
name: self [52761,52765]
===
match
---
name: unixname [9923,9931]
name: unixname [9951,9959]
===
match
---
name: self [40682,40686]
name: self [40702,40706]
===
match
---
name: dag_run [67872,67879]
name: dag_run [67892,67899]
===
match
---
operator: , [65074,65075]
operator: , [65094,65095]
===
match
---
try_stmt [72614,72775]
try_stmt [72634,72795]
===
match
---
operator: - [34643,34644]
operator: - [34663,34664]
===
match
---
name: self [72437,72441]
name: self [72457,72461]
===
match
---
name: t [78949,78950]
name: t [78969,78970]
===
match
---
trailer [5390,5399]
trailer [5418,5427]
===
match
---
fstring_string: . [45005,45006]
fstring_string: . [45025,45026]
===
match
---
atom [18070,18088]
atom [18090,18108]
===
match
---
argument [15047,15072]
argument [15067,15092]
===
match
---
testlist [8264,8310]
testlist [8292,8338]
===
match
---
name: ti [26024,26026]
name: ti [26044,26046]
===
match
---
trailer [48800,48808]
trailer [48820,48828]
===
match
---
name: commit [55973,55979]
name: commit [55993,55999]
===
match
---
trailer [71883,71894]
trailer [71903,71914]
===
match
---
trailer [51441,51459]
trailer [51461,51479]
===
match
---
name: email [72741,72746]
name: email [72761,72766]
===
match
---
trailer [58983,58993]
trailer [59003,59013]
===
match
---
name: FAILED [20930,20936]
name: FAILED [20950,20956]
===
match
---
except_clause [43231,43270]
except_clause [43251,43290]
===
match
---
name: dag_id [10649,10655]
name: dag_id [10677,10683]
===
match
---
name: dag_id [10738,10744]
name: dag_id [10766,10772]
===
match
---
name: self [74259,74263]
name: self [74279,74283]
===
match
---
simple_stmt [58975,59001]
simple_stmt [58995,59021]
===
match
---
operator: , [54213,54214]
operator: , [54233,54234]
===
match
---
name: dag_ids [76549,76556]
name: dag_ids [76569,76576]
===
match
---
trailer [18367,18394]
trailer [18387,18414]
===
match
---
trailer [29510,29514]
trailer [29530,29534]
===
match
---
operator: = [31029,31030]
operator: = [31049,31050]
===
match
---
trailer [8770,8785]
trailer [8798,8813]
===
match
---
simple_stmt [1033,1118]
simple_stmt [1018,1103]
===
match
---
string: 'outlets' [65021,65030]
string: 'outlets' [65041,65050]
===
match
---
operator: , [66602,66603]
operator: , [66622,66623]
===
match
---
name: date [41533,41537]
name: date [41553,41557]
===
match
---
atom_expr [7893,7906]
atom_expr [7921,7934]
===
match
---
name: context [49197,49204]
name: context [49217,49224]
===
match
---
name: merge [6031,6036]
name: merge [6059,6064]
===
match
---
atom_expr [33910,33922]
atom_expr [33930,33942]
===
match
---
operator: , [65007,65008]
operator: , [65027,65028]
===
match
---
name: cmd [18059,18062]
name: cmd [18079,18082]
===
match
---
argument [28032,28047]
argument [28052,28067]
===
match
---
trailer [53876,53916]
trailer [53896,53936]
===
match
---
name: end_date [45078,45086]
name: end_date [45098,45106]
===
match
---
name: Optional [28606,28614]
name: Optional [28626,28634]
===
match
---
operator: == [24901,24903]
operator: == [24921,24923]
===
match
---
trailer [52954,52974]
trailer [52974,52994]
===
match
---
name: bool [15735,15739]
name: bool [15755,15759]
===
match
---
name: force_fail [59372,59382]
name: force_fail [59392,59402]
===
match
---
expr_stmt [9423,9454]
expr_stmt [9451,9482]
===
match
---
trailer [33871,33990]
trailer [33891,34010]
===
match
---
name: try_number [71657,71667]
name: try_number [71677,71687]
===
match
---
string: '' [62009,62011]
string: '' [62029,62031]
===
match
---
name: reschedule_exception [44051,44071]
name: reschedule_exception [44071,44091]
===
match
---
if_stmt [59721,59784]
if_stmt [59741,59804]
===
match
---
simple_stmt [62981,62997]
simple_stmt [63001,63017]
===
match
---
name: self [48835,48839]
name: self [48855,48859]
===
match
---
name: registered [49845,49855]
name: registered [49865,49875]
===
match
---
atom_expr [69434,69455]
atom_expr [69454,69475]
===
match
---
simple_stmt [7526,7592]
simple_stmt [7554,7620]
===
match
---
expr_stmt [60339,60514]
expr_stmt [60359,60534]
===
match
---
operator: } [19420,19421]
operator: } [19440,19441]
===
match
---
name: dag_id [33902,33908]
name: dag_id [33922,33928]
===
match
---
parameters [22934,22966]
parameters [22954,22986]
===
match
---
atom_expr [18357,18394]
atom_expr [18377,18414]
===
match
---
operator: , [39764,39765]
operator: , [39784,39785]
===
match
---
string: "tasks" [17984,17991]
string: "tasks" [18004,18011]
===
match
---
name: task [60155,60159]
name: task [60175,60179]
===
match
---
trailer [11496,11512]
trailer [11524,11540]
===
match
---
atom_expr [40780,40817]
atom_expr [40800,40837]
===
match
---
simple_stmt [63107,63137]
simple_stmt [63127,63157]
===
match
---
atom_expr [11526,11688]
atom_expr [11554,11716]
===
match
---
trailer [22308,22320]
trailer [22328,22340]
===
match
---
simple_stmt [60824,60896]
simple_stmt [60844,60916]
===
match
---
name: conf [19290,19294]
name: conf [19310,19314]
===
match
---
operator: , [32592,32593]
operator: , [32612,32613]
===
match
---
simple_stmt [79243,79491]
simple_stmt [79263,79511]
===
match
---
operator: , [20651,20652]
operator: , [20671,20672]
===
match
---
operator: , [17998,17999]
operator: , [18018,18019]
===
match
---
string: 'ti' [70554,70558]
string: 'ti' [70574,70578]
===
match
---
name: UP_FOR_RETRY [35047,35059]
name: UP_FOR_RETRY [35067,35079]
===
match
---
trailer [11171,11173]
trailer [11199,11201]
===
match
---
name: Sentry [45732,45738]
name: Sentry [45752,45758]
===
match
---
simple_stmt [44934,44940]
simple_stmt [44954,44960]
===
match
---
string: 'execution_date can not be in the past (current ' [74013,74062]
string: 'execution_date can not be in the past (current ' [74033,74082]
===
match
---
name: airflow [2191,2198]
name: airflow [2176,2183]
===
match
---
expr_stmt [69071,69130]
expr_stmt [69091,69150]
===
match
---
simple_stmt [22456,22484]
simple_stmt [22476,22504]
===
match
---
name: prev_ti [30286,30293]
name: prev_ti [30306,30313]
===
match
---
name: __repr__ [64135,64143]
name: __repr__ [64155,64163]
===
match
---
string: 'execution_date' [45337,45353]
string: 'execution_date' [45357,45373]
===
match
---
atom [33703,33724]
atom [33723,33744]
===
match
---
atom_expr [5122,5138]
atom_expr [5150,5166]
===
match
---
trailer [19237,19270]
trailer [19257,19290]
===
match
---
name: warning [40343,40350]
name: warning [40363,40370]
===
match
---
atom_expr [19579,19612]
atom_expr [19599,19632]
===
match
---
operator: = [14740,14741]
operator: = [14760,14761]
===
match
---
expr_stmt [62385,62443]
expr_stmt [62405,62463]
===
match
---
arglist [9629,9658]
arglist [9657,9686]
===
match
---
import_from [2991,3063]
import_from [3019,3091]
===
match
---
name: self [66208,66212]
name: self [66228,66232]
===
match
---
operator: , [39201,39202]
operator: , [39221,39222]
===
match
---
trailer [30338,30358]
trailer [30358,30378]
===
match
---
name: cmd [18124,18127]
name: cmd [18144,18147]
===
match
---
and_test [78949,78998]
and_test [78969,79018]
===
match
---
operator: = [9620,9621]
operator: = [9648,9649]
===
match
---
atom_expr [20409,20436]
atom_expr [20429,20456]
===
match
---
name: conf [19034,19038]
name: conf [19054,19058]
===
match
---
operator: @ [77375,77376]
operator: @ [77395,77396]
===
match
---
name: property [13329,13337]
name: property [13349,13357]
===
match
---
simple_stmt [67804,67849]
simple_stmt [67824,67869]
===
match
---
param [35845,35876]
param [35865,35896]
===
match
---
trailer [27668,27686]
trailer [27688,27706]
===
match
---
string: "Clearing XCom data" [23865,23885]
string: "Clearing XCom data" [23885,23905]
===
match
---
name: next_ds_nodash [61566,61580]
name: next_ds_nodash [61586,61600]
===
match
---
comp_op [52975,52981]
comp_op [52995,53001]
===
match
---
name: str [80315,80318]
name: str [80335,80338]
===
match
---
operator: = [74258,74259]
operator: = [74278,74279]
===
match
---
trailer [30887,30911]
trailer [30907,30931]
===
match
---
atom_expr [53245,53272]
atom_expr [53265,53292]
===
match
---
trailer [52766,52768]
trailer [52786,52788]
===
match
---
operator: , [15072,15073]
operator: , [15092,15093]
===
match
---
raise_stmt [73979,74173]
raise_stmt [73999,74193]
===
match
---
name: state [5243,5248]
name: state [5271,5276]
===
match
---
name: self [41322,41326]
name: self [41342,41346]
===
match
---
operator: == [78686,78688]
operator: == [78706,78708]
===
match
---
expr_stmt [80487,80514]
expr_stmt [80507,80534]
===
match
---
decorator [19854,19871]
decorator [19874,19891]
===
match
---
operator: , [43890,43891]
operator: , [43910,43911]
===
match
---
operator: = [26863,26864]
operator: = [26883,26884]
===
match
---
strings [19653,19838]
strings [19673,19858]
===
match
---
operator: , [41879,41880]
operator: , [41899,41900]
===
match
---
decorator [35604,35621]
decorator [35624,35641]
===
match
---
operator: = [52401,52402]
operator: = [52421,52422]
===
match
---
operator: = [11756,11757]
operator: = [11784,11785]
===
match
---
suite [80247,80295]
suite [80267,80315]
===
match
---
atom_expr [48919,48978]
atom_expr [48939,48998]
===
match
---
name: get [71942,71945]
name: get [71962,71965]
===
match
---
trailer [62300,62308]
trailer [62320,62328]
===
match
---
name: airflow [1894,1901]
name: airflow [1879,1886]
===
match
---
argument [71045,71102]
argument [71065,71122]
===
match
---
name: task_instance_scheduling_decisions [46955,46989]
name: task_instance_scheduling_decisions [46975,47009]
===
match
---
trailer [30089,30093]
trailer [30109,30113]
===
match
---
simple_stmt [1828,1889]
simple_stmt [1813,1874]
===
match
---
simple_stmt [19279,19324]
simple_stmt [19299,19344]
===
match
---
trailer [25346,25359]
trailer [25366,25379]
===
match
---
operator: , [82166,82167]
operator: , [82186,82187]
===
match
---
atom_expr [20238,20493]
atom_expr [20258,20513]
===
match
---
atom_expr [28018,28030]
atom_expr [28038,28050]
===
match
---
name: get_previous_ti [26448,26463]
name: get_previous_ti [26468,26483]
===
match
---
name: Column [1298,1304]
name: Column [1283,1289]
===
match
---
name: signal [48605,48611]
name: signal [48625,48631]
===
match
---
trailer [58348,58352]
trailer [58368,58372]
===
match
---
name: DagRun [82571,82577]
name: DagRun [82591,82597]
===
match
---
decorator [81210,81220]
decorator [81230,81240]
===
match
---
atom_expr [58483,58494]
atom_expr [58503,58514]
===
match
---
name: max_tries [40659,40668]
name: max_tries [40679,40688]
===
match
---
fstring_string: = [49346,49347]
fstring_string: = [49366,49367]
===
match
---
argument [64063,64084]
argument [64083,64104]
===
match
---
trailer [20487,20491]
trailer [20507,20511]
===
match
---
name: incr [37840,37844]
name: incr [37860,37864]
===
match
---
trailer [30099,30133]
trailer [30119,30153]
===
match
---
trailer [11329,11334]
trailer [11357,11362]
===
match
---
name: str [18148,18151]
name: str [18168,18171]
===
match
---
fstring_string: /log?execution_date= [19352,19372]
fstring_string: /log?execution_date= [19372,19392]
===
match
---
trailer [72904,72913]
trailer [72924,72933]
===
match
---
name: failed [31737,31743]
name: failed [31757,31763]
===
match
---
operator: = [54284,54285]
operator: = [54304,54305]
===
match
---
atom [7698,7723]
atom [7726,7751]
===
match
---
atom_expr [79796,79808]
atom_expr [79816,79828]
===
match
---
trailer [80013,80022]
trailer [80033,80042]
===
match
---
name: task [52830,52834]
name: task [52850,52854]
===
match
---
name: self [35490,35494]
name: self [35510,35514]
===
match
---
atom_expr [59068,59084]
atom_expr [59088,59104]
===
match
---
suite [54323,54343]
suite [54343,54363]
===
match
---
atom [67543,67583]
atom [67563,67603]
===
match
---
operator: = [62396,62397]
operator: = [62416,62417]
===
match
---
name: airflow [2792,2799]
name: airflow [2820,2827]
===
match
---
name: airflow_context_vars [49150,49170]
name: airflow_context_vars [49170,49190]
===
match
---
trailer [67979,67984]
trailer [67999,68004]
===
match
---
decorator [24154,24164]
decorator [24174,24184]
===
match
---
name: self [11704,11708]
name: self [11732,11736]
===
match
---
simple_stmt [7198,7251]
simple_stmt [7226,7279]
===
match
---
suite [52103,52154]
suite [52123,52174]
===
match
---
trailer [31882,31924]
trailer [31902,31944]
===
match
---
param [74659,74693]
param [74679,74713]
===
match
---
name: task [43123,43127]
name: task [43143,43147]
===
match
---
trailer [12034,12045]
trailer [12062,12073]
===
match
---
name: Column [10215,10221]
name: Column [10243,10249]
===
match
---
trailer [34622,34626]
trailer [34642,34646]
===
match
---
string: 'Marking task as SKIPPED. ' [43662,43689]
string: 'Marking task as SKIPPED. ' [43682,43709]
===
match
---
trailer [40787,40791]
trailer [40807,40811]
===
match
---
return_stmt [80793,80820]
return_stmt [80813,80840]
===
match
---
trailer [42926,42933]
trailer [42946,42953]
===
match
---
trailer [50480,50500]
trailer [50500,50520]
===
match
---
name: dag_run [67786,67793]
name: dag_run [67806,67813]
===
match
---
name: self [23291,23295]
name: self [23311,23315]
===
match
---
simple_stmt [66679,66703]
simple_stmt [66699,66723]
===
match
---
for_stmt [7363,7483]
for_stmt [7391,7511]
===
match
---
name: passed [32805,32811]
name: passed [32825,32831]
===
match
---
name: self [12440,12444]
name: self [12460,12464]
===
match
---
name: on_retry_callback [53188,53205]
name: on_retry_callback [53208,53225]
===
match
---
operator: , [8168,8169]
operator: , [8196,8197]
===
match
---
name: str [16094,16097]
name: str [16114,16117]
===
match
---
trailer [39196,39219]
trailer [39216,39239]
===
match
---
name: self [52652,52656]
name: self [52672,52676]
===
match
---
name: session [37634,37641]
name: session [37654,37661]
===
match
---
name: info [41219,41223]
name: info [41239,41243]
===
match
---
trailer [60192,60199]
trailer [60212,60219]
===
match
---
operator: -> [81250,81252]
operator: -> [81270,81272]
===
match
---
operator: = [71574,71575]
operator: = [71594,71595]
===
match
---
name: iso [19373,19376]
name: iso [19393,19396]
===
match
---
argument [27923,27934]
argument [27943,27954]
===
match
---
name: dag_id [11011,11017]
name: dag_id [11039,11045]
===
match
---
atom_expr [21620,21639]
atom_expr [21640,21659]
===
match
---
trailer [46954,46989]
trailer [46974,47009]
===
match
---
name: self [22935,22939]
name: self [22955,22959]
===
match
---
arglist [69504,69516]
arglist [69524,69536]
===
match
---
param [41440,41444]
param [41460,41464]
===
match
---
operator: = [23586,23587]
operator: = [23606,23607]
===
match
---
simple_stmt [41555,41593]
simple_stmt [41575,41613]
===
match
---
decorator [59090,59107]
decorator [59110,59127]
===
match
---
operator: , [67784,67785]
operator: , [67804,67805]
===
match
---
operator: , [15626,15627]
operator: , [15646,15647]
===
match
---
name: delay [34809,34814]
name: delay [34829,34834]
===
match
---
name: self [8150,8154]
name: self [8178,8182]
===
match
---
name: self [48315,48319]
name: self [48335,48339]
===
match
---
name: self [29160,29164]
name: self [29180,29184]
===
match
---
name: execute [51517,51524]
name: execute [51537,51544]
===
match
---
funcdef [19875,20611]
funcdef [19895,20631]
===
match
---
name: self [81096,81100]
name: self [81116,81120]
===
match
---
tfpdef [53530,53558]
tfpdef [53550,53578]
===
match
---
name: try_number [33709,33719]
name: try_number [33729,33739]
===
match
---
operator: = [20922,20923]
operator: = [20942,20943]
===
match
---
trailer [7396,7403]
trailer [7424,7431]
===
match
---
name: execution_date [11102,11116]
name: execution_date [11130,11144]
===
match
---
name: exception [58984,58993]
name: exception [59004,59013]
===
match
---
atom_expr [40951,40970]
atom_expr [40971,40990]
===
match
---
name: query [60375,60380]
name: query [60395,60400]
===
match
---
if_stmt [59010,59060]
if_stmt [59030,59080]
===
match
---
decorator [15473,15487]
decorator [15493,15507]
===
match
---
argument [45898,45911]
argument [45918,45931]
===
match
---
name: COLLATION_ARGS [9494,9508]
name: COLLATION_ARGS [9522,9536]
===
match
---
operator: = [5249,5250]
operator: = [5277,5278]
===
match
---
name: self [26818,26822]
name: self [26838,26842]
===
match
---
dotted_name [2938,2968]
dotted_name [2966,2996]
===
match
---
operator: = [44909,44910]
operator: = [44929,44930]
===
match
---
name: total_seconds [72950,72963]
name: total_seconds [72970,72983]
===
match
---
suite [6149,7287]
suite [6177,7315]
===
match
---
operator: , [44353,44354]
operator: , [44373,44374]
===
match
---
name: log [58980,58983]
name: log [59000,59003]
===
match
---
atom_expr [78895,78904]
atom_expr [78915,78924]
===
match
---
if_stmt [52947,53092]
if_stmt [52967,53112]
===
match
---
name: self [49038,49042]
name: self [49058,49062]
===
match
---
atom_expr [5171,5179]
atom_expr [5199,5207]
===
match
---
decorator [81072,81082]
decorator [81092,81102]
===
match
---
fstring [19715,19739]
fstring [19735,19759]
===
match
---
name: ti_key_str [65652,65662]
name: ti_key_str [65672,65682]
===
match
---
name: session [60367,60374]
name: session [60387,60394]
===
match
---
atom_expr [52950,52974]
atom_expr [52970,52994]
===
match
---
trailer [13866,13878]
trailer [13886,13898]
===
match
---
name: DagRun [35371,35377]
name: DagRun [35391,35397]
===
match
---
return_stmt [28524,28553]
return_stmt [28544,28573]
===
match
---
name: DagRun [45960,45966]
name: DagRun [45980,45986]
===
match
---
name: render [72217,72223]
name: render [72237,72243]
===
match
---
suite [19469,19849]
suite [19489,19869]
===
match
---
trailer [82316,82318]
trailer [82336,82338]
===
match
---
operator: == [26385,26387]
operator: == [26405,26407]
===
match
---
operator: , [9509,9510]
operator: , [9537,9538]
===
match
---
name: TaskInstance [26209,26221]
name: TaskInstance [26229,26241]
===
match
---
name: pool [22547,22551]
name: pool [22567,22571]
===
match
---
name: session [31908,31915]
name: session [31928,31935]
===
match
---
arglist [10722,10776]
arglist [10750,10804]
===
match
---
name: test_mode [59361,59370]
name: test_mode [59381,59390]
===
match
---
if_stmt [42977,43129]
if_stmt [42997,43149]
===
match
---
name: email_on_failure [58152,58168]
name: email_on_failure [58172,58188]
===
match
---
operator: -> [81171,81173]
operator: -> [81191,81193]
===
match
---
operator: ** [72106,72108]
operator: ** [72126,72128]
===
match
---
atom_expr [59040,59059]
atom_expr [59060,59079]
===
match
---
operator: = [62636,62637]
operator: = [62656,62657]
===
match
---
name: TaskInstance [82046,82058]
name: TaskInstance [82066,82078]
===
match
---
name: self [76424,76428]
name: self [76444,76448]
===
match
---
atom_expr [50879,50892]
atom_expr [50899,50912]
===
match
---
param [63969,63974]
param [63989,63994]
===
match
---
string: """         Checks on whether the task instance is in the right state and timeframe         to be retried.         """ [34893,35011]
string: """         Checks on whether the task instance is in the right state and timeframe         to be retried.         """ [34913,35031]
===
match
---
param [53576,53607]
param [53596,53627]
===
match
---
arglist [10002,10029]
arglist [10030,10057]
===
match
---
operator: = [9847,9848]
operator: = [9875,9876]
===
match
---
string: """         Returns whether or not all the conditions are met for this task instance to be run         given the context for the dependencies (e.g. a task instance being force run from         the UI will ignore some dependencies).          :param dep_context: The execution context that determines the dependencies that             should be evaluated.         :type dep_context: DepContext         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param verbose: whether log details on failed dependencies on             info or debug log level         :type verbose: bool         """ [31046,31678]
string: """         Returns whether or not all the conditions are met for this task instance to be run         given the context for the dependencies (e.g. a task instance being force run from         the UI will ignore some dependencies).          :param dep_context: The execution context that determines the dependencies that             should be evaluated.         :type dep_context: DepContext         :param session: database session         :type session: sqlalchemy.orm.session.Session         :param verbose: whether log details on failed dependencies on             info or debug log level         :type verbose: bool         """ [31066,31698]
===
match
---
trailer [79909,79924]
trailer [79929,79944]
===
match
---
trailer [62535,62576]
trailer [62555,62596]
===
match
---
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [45182,45252]
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [45202,45272]
===
match
---
parameters [81095,81101]
parameters [81115,81121]
===
match
---
simple_stmt [40594,40674]
simple_stmt [40614,40694]
===
match
---
trailer [68503,68511]
trailer [68523,68531]
===
match
---
operator: = [9966,9967]
operator: = [9994,9995]
===
match
---
argument [9511,9527]
argument [9539,9555]
===
match
---
name: List [3232,3236]
name: List [3260,3264]
===
match
---
simple_stmt [60121,60136]
simple_stmt [60141,60156]
===
match
---
trailer [22872,22907]
trailer [22892,22927]
===
match
---
simple_stmt [50866,50893]
simple_stmt [50886,50913]
===
match
---
atom_expr [55937,55956]
atom_expr [55957,55976]
===
match
---
name: state [35032,35037]
name: state [35052,35057]
===
match
---
name: self [34878,34882]
name: self [34898,34902]
===
match
---
operator: , [10647,10648]
operator: , [10675,10676]
===
match
---
name: context [53004,53011]
name: context [53024,53031]
===
match
---
atom_expr [67360,67409]
atom_expr [67380,67429]
===
match
---
name: self [35064,35068]
name: self [35084,35088]
===
match
---
suite [54356,54671]
suite [54376,54691]
===
match
---
simple_stmt [11263,11280]
simple_stmt [11291,11308]
===
match
---
trailer [19257,19267]
trailer [19277,19287]
===
match
---
expr_stmt [61842,61863]
expr_stmt [61862,61883]
===
match
---
name: State [65341,65346]
name: State [65361,65366]
===
match
---
name: provide_session [41617,41632]
name: provide_session [41637,41652]
===
match
---
parameters [21035,21078]
parameters [21055,21098]
===
match
---
name: execution_date [7772,7786]
name: execution_date [7800,7814]
===
match
---
operator: , [65578,65579]
operator: , [65598,65599]
===
match
---
atom_expr [43196,43206]
atom_expr [43216,43226]
===
match
---
trailer [24801,24812]
trailer [24821,24832]
===
match
---
trailer [11534,11542]
trailer [11562,11570]
===
match
---
atom_expr [11325,11334]
atom_expr [11353,11362]
===
match
---
argument [51861,51880]
argument [51881,51900]
===
match
---
name: XCOM_RETURN_KEY [51865,51880]
name: XCOM_RETURN_KEY [51885,51900]
===
match
---
name: dag_id [8041,8047]
name: dag_id [8069,8075]
===
match
---
tfpdef [53576,53598]
tfpdef [53596,53618]
===
match
---
name: pickle_id [15307,15316]
name: pickle_id [15327,15336]
===
match
---
name: session [53798,53805]
name: session [53818,53825]
===
match
---
name: Exception [4304,4313]
name: Exception [4332,4341]
===
match
---
string: "--subdir" [18755,18765]
string: "--subdir" [18775,18785]
===
match
---
name: self [24113,24117]
name: self [24133,24137]
===
match
---
atom_expr [58534,58584]
atom_expr [58554,58604]
===
match
---
subscriptlist [8165,8183]
subscriptlist [8193,8211]
===
match
---
name: self [44085,44089]
name: self [44105,44109]
===
match
---
atom_expr [81253,81266]
atom_expr [81273,81286]
===
match
---
operator: = [23497,23498]
operator: = [23517,23518]
===
match
---
atom [72916,72949]
atom [72936,72969]
===
match
---
string: '' [12165,12167]
string: '' [12185,12187]
===
match
---
name: execution_date [78820,78834]
name: execution_date [78840,78854]
===
match
---
number: 256 [10117,10120]
number: 256 [10145,10148]
===
match
---
name: ti [79816,79818]
name: ti [79836,79838]
===
match
---
operator: -> [59301,59303]
operator: -> [59321,59323]
===
match
---
trailer [72996,73005]
trailer [73016,73025]
===
match
---
name: str [53777,53780]
name: str [53797,53800]
===
match
---
name: self [62981,62985]
name: self [63001,63005]
===
match
---
atom_expr [66791,67153]
atom_expr [66811,67173]
===
match
---
operator: = [35943,35944]
operator: = [35963,35964]
===
match
---
name: ignore_task_deps [53576,53592]
name: ignore_task_deps [53596,53612]
===
match
---
trailer [4140,4146]
trailer [4168,4174]
===
match
---
name: dagrun [82557,82563]
name: dagrun [82577,82583]
===
match
---
name: extend [18747,18753]
name: extend [18767,18773]
===
match
---
simple_stmt [58195,58227]
simple_stmt [58215,58247]
===
match
---
trailer [31985,32169]
trailer [32005,32189]
===
match
---
name: task_tries [7062,7072]
name: task_tries [7090,7100]
===
match
---
trailer [78742,78933]
trailer [78762,78953]
===
match
---
name: with_row_locks [2772,2786]
name: with_row_locks [2800,2814]
===
match
---
trailer [53916,54303]
trailer [53936,54323]
===
match
---
operator: = [50584,50585]
operator: = [50604,50605]
===
match
---
name: make_aware [11878,11888]
name: make_aware [11906,11916]
===
match
---
name: are_dependents_done [25421,25440]
name: are_dependents_done [25441,25460]
===
match
---
name: lock_for_update [82255,82270]
name: lock_for_update [82275,82290]
===
match
---
name: provide_session [20996,21011]
name: provide_session [21016,21031]
===
match
---
operator: = [48276,48277]
operator: = [48296,48297]
===
match
---
decorated [18873,19141]
decorated [18893,19161]
===
match
---
trailer [72740,72746]
trailer [72760,72766]
===
match
---
trailer [34024,34034]
trailer [34044,34054]
===
match
---
atom_expr [8549,8564]
atom_expr [8577,8592]
===
match
---
trailer [81518,81535]
trailer [81538,81555]
===
match
---
trailer [72568,72594]
trailer [72588,72614]
===
match
---
atom_expr [26541,26565]
atom_expr [26561,26585]
===
match
---
if_stmt [40921,40971]
if_stmt [40941,40991]
===
match
---
funcdef [72780,73078]
funcdef [72800,73098]
===
match
---
test [54708,54774]
test [54728,54794]
===
match
---
name: task_copy [51597,51606]
name: task_copy [51617,51626]
===
match
---
name: self [40449,40453]
name: self [40469,40473]
===
match
---
name: task [49641,49645]
name: task [49661,49665]
===
match
---
atom_expr [15876,15889]
atom_expr [15896,15909]
===
match
---
suite [45643,45705]
suite [45663,45725]
===
match
---
simple_stmt [850,862]
simple_stmt [835,847]
===
match
---
simple_stmt [2186,2220]
simple_stmt [2171,2205]
===
match
---
atom_expr [60758,60815]
atom_expr [60778,60835]
===
match
---
operator: = [54167,54168]
operator: = [54187,54188]
===
match
---
comparison [24890,24922]
comparison [24910,24942]
===
match
---
name: session [47704,47711]
name: session [47724,47731]
===
match
---
name: bool [53594,53598]
name: bool [53614,53618]
===
match
---
trailer [18984,18994]
trailer [19004,19014]
===
match
---
name: log [50144,50147]
name: log [50164,50167]
===
match
---
simple_stmt [41926,42613]
simple_stmt [41946,42633]
===
match
---
operator: , [50672,50673]
operator: , [50692,50693]
===
match
---
name: self [31854,31858]
name: self [31874,31878]
===
match
---
simple_stmt [1969,2026]
simple_stmt [1954,2011]
===
match
---
operator: , [68557,68558]
operator: , [68577,68578]
===
match
---
atom_expr [64788,64807]
atom_expr [64808,64827]
===
match
---
name: self [52300,52304]
name: self [52320,52324]
===
match
---
simple_stmt [78188,78200]
simple_stmt [78208,78220]
===
match
---
name: self [44304,44308]
name: self [44324,44328]
===
match
---
simple_stmt [69527,69569]
simple_stmt [69547,69589]
===
match
---
atom_expr [25939,25948]
atom_expr [25959,25968]
===
match
---
name: commit [50981,50987]
name: commit [51001,51007]
===
match
---
arglist [62367,62374]
arglist [62387,62394]
===
match
---
name: email [58952,58957]
name: email [58972,58977]
===
match
---
operator: { [19386,19387]
operator: { [19406,19407]
===
match
---
operator: == [35038,35040]
operator: == [35058,35060]
===
match
---
name: Optional [68067,68075]
name: Optional [68087,68095]
===
match
---
simple_stmt [42853,42891]
simple_stmt [42873,42911]
===
match
---
name: task_copy [51432,51441]
name: task_copy [51452,51461]
===
match
---
atom_expr [81443,81452]
atom_expr [81463,81472]
===
match
---
name: fd [4406,4408]
name: fd [4434,4436]
===
match
---
name: pendulum [64770,64778]
name: pendulum [64790,64798]
===
match
---
atom_expr [33817,34036]
atom_expr [33837,34056]
===
match
---
trailer [22672,22688]
trailer [22692,22708]
===
match
---
expr_stmt [22831,22848]
expr_stmt [22851,22868]
===
match
---
atom_expr [55652,55688]
atom_expr [55672,55708]
===
match
---
atom_expr [82583,82603]
atom_expr [82603,82623]
===
match
---
name: try_number [6098,6108]
name: try_number [6126,6136]
===
match
---
name: dag_model [10882,10891]
name: dag_model [10910,10919]
===
match
---
name: _update_ti_state_for_sensing [50745,50773]
name: _update_ti_state_for_sensing [50765,50793]
===
match
---
trailer [59075,59082]
trailer [59095,59102]
===
match
---
operator: = [15252,15253]
operator: = [15272,15273]
===
match
---
operator: , [69199,69200]
operator: , [69219,69220]
===
match
---
expr_stmt [60824,60895]
expr_stmt [60844,60915]
===
match
---
try_stmt [49820,50176]
try_stmt [49840,50196]
===
match
---
trailer [50934,50936]
trailer [50954,50956]
===
match
---
number: 1 [13231,13232]
number: 1 [13251,13252]
===
match
---
name: str [80500,80503]
name: str [80520,80523]
===
match
---
trailer [61493,61512]
trailer [61513,61532]
===
match
---
name: TaskInstanceKey [81411,81426]
name: TaskInstanceKey [81431,81446]
===
match
---
name: Index [10582,10587]
name: Index [10610,10615]
===
match
---
param [20647,20652]
param [20667,20672]
===
match
---
name: self [38511,38515]
name: self [38531,38535]
===
match
---
atom_expr [64510,64576]
atom_expr [64530,64596]
===
match
---
name: item [63131,63135]
name: item [63151,63155]
===
match
---
simple_stmt [39148,39228]
simple_stmt [39168,39248]
===
match
---
name: sqlalchemy [2741,2751]
name: sqlalchemy [2769,2779]
===
match
---
name: task [47486,47490]
name: task [47506,47510]
===
match
---
name: info [40603,40607]
name: info [40623,40627]
===
match
---
name: Any [64343,64346]
name: Any [64363,64366]
===
match
---
simple_stmt [67606,67695]
simple_stmt [67626,67715]
===
match
---
trailer [24305,24370]
trailer [24325,24390]
===
match
---
name: Exception [49933,49942]
name: Exception [49953,49962]
===
match
---
fstring_end: ' [48818,48819]
fstring_end: ' [48838,48839]
===
match
---
trailer [25943,25948]
trailer [25963,25968]
===
match
---
name: task_id [11247,11254]
name: task_id [11275,11282]
===
match
---
atom_expr [7374,7434]
atom_expr [7402,7462]
===
match
---
name: state [11128,11133]
name: state [11156,11161]
===
match
---
trailer [42632,42637]
trailer [42652,42657]
===
match
---
funcdef [62945,62997]
funcdef [62965,63017]
===
match
---
name: task [65574,65578]
name: task [65594,65598]
===
match
---
name: conf [67980,67984]
name: conf [68000,68004]
===
match
---
name: ignore_depends_on_past [54004,54026]
name: ignore_depends_on_past [54024,54046]
===
match
---
simple_stmt [4209,4248]
simple_stmt [4237,4276]
===
match
---
name: self [8507,8511]
name: self [8535,8539]
===
match
---
simple_stmt [8716,8799]
simple_stmt [8744,8827]
===
match
---
operator: = [59866,59867]
operator: = [59886,59887]
===
match
---
trailer [62231,62240]
trailer [62251,62260]
===
match
---
trailer [72089,72098]
trailer [72109,72118]
===
match
---
name: queue [23277,23282]
name: queue [23297,23302]
===
match
---
suite [55298,55318]
suite [55318,55338]
===
match
---
trailer [23263,23269]
trailer [23283,23289]
===
match
---
operator: = [9771,9772]
operator: = [9799,9800]
===
match
---
simple_stmt [68344,68370]
simple_stmt [68364,68390]
===
match
---
trailer [76428,76435]
trailer [76448,76455]
===
match
---
suite [39930,40517]
suite [39950,40537]
===
match
---
atom_expr [22100,22110]
atom_expr [22120,22130]
===
match
---
simple_stmt [820,835]
simple_stmt [805,820]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.         """ [30456,30603]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.         """ [30476,30623]
===
match
---
operator: , [36021,36022]
operator: , [36041,36042]
===
match
---
simple_stmt [24452,24650]
simple_stmt [24472,24670]
===
match
---
atom_expr [7076,7089]
atom_expr [7104,7117]
===
match
---
operator: } [67684,67685]
operator: } [67704,67705]
===
match
---
operator: { [64593,64594]
operator: { [64613,64614]
===
match
---
atom_expr [24858,24868]
atom_expr [24878,24888]
===
match
---
name: dep_context [31701,31712]
name: dep_context [31721,31732]
===
match
---
trailer [69039,69057]
trailer [69059,69077]
===
match
---
funcdef [67733,68026]
funcdef [67753,68046]
===
match
---
trailer [11211,11218]
trailer [11239,11246]
===
match
---
atom_expr [60367,60500]
atom_expr [60387,60520]
===
match
---
trailer [54442,54670]
trailer [54462,54690]
===
match
---
name: provide_session [73084,73099]
name: provide_session [73104,73119]
===
match
---
name: self [64109,64113]
name: self [64129,64133]
===
match
---
fstring_start: f" [47912,47914]
fstring_start: f" [47932,47934]
===
match
---
name: ignore_task_deps [38460,38476]
name: ignore_task_deps [38480,38496]
===
match
---
name: context [53357,53364]
name: context [53377,53384]
===
match
---
name: ti [80228,80230]
name: ti [80248,80250]
===
match
---
operator: , [73131,73132]
operator: , [73151,73152]
===
match
---
name: task_id [11232,11239]
name: task_id [11260,11267]
===
match
---
name: log [40687,40690]
name: log [40707,40710]
===
match
---
operator: , [66045,66046]
operator: , [66065,66066]
===
match
---
operator: { [19725,19726]
operator: { [19745,19746]
===
match
---
string: "task" [47426,47432]
string: "task" [47446,47452]
===
match
---
name: self [69195,69199]
name: self [69215,69219]
===
match
---
name: refresh_from_task [42686,42703]
name: refresh_from_task [42706,42723]
===
match
---
operator: = [39747,39748]
operator: = [39767,39768]
===
match
---
name: property [12654,12662]
name: property [12674,12682]
===
match
---
simple_stmt [23482,23512]
simple_stmt [23502,23532]
===
match
---
name: _safe_date [58663,58673]
name: _safe_date [58683,58693]
===
match
---
atom_expr [63536,63579]
atom_expr [63556,63599]
===
match
---
name: mark_success [15060,15072]
name: mark_success [15080,15092]
===
match
---
trailer [40641,40652]
trailer [40661,40672]
===
match
---
trailer [11143,11148]
trailer [11171,11176]
===
match
---
trailer [20915,20921]
trailer [20935,20941]
===
match
---
operator: , [64527,64528]
operator: , [64547,64548]
===
match
---
name: task_id [5334,5341]
name: task_id [5362,5369]
===
match
---
trailer [6030,6036]
trailer [6058,6064]
===
match
---
arglist [64523,64575]
arglist [64543,64595]
===
match
---
name: self [80077,80081]
name: self [80097,80101]
===
match
---
operator: , [56198,56199]
operator: , [56218,56219]
===
match
---
name: context [51533,51540]
name: context [51553,51560]
===
match
---
name: State [39107,39112]
name: State [39127,39132]
===
match
---
name: self [39947,39951]
name: self [39967,39971]
===
match
---
name: dag_run [62653,62660]
name: dag_run [62673,62680]
===
match
---
name: session [40471,40478]
name: session [40491,40498]
===
match
---
atom_expr [49364,49392]
atom_expr [49384,49412]
===
match
---
name: queued_dttm [22746,22757]
name: queued_dttm [22766,22777]
===
match
---
param [16048,16079]
param [16068,16099]
===
match
---
name: refresh_from_db [44090,44105]
name: refresh_from_db [44110,44125]
===
match
---
name: date [41491,41495]
name: date [41511,41515]
===
match
---
not_test [69430,69455]
not_test [69450,69475]
===
match
---
atom_expr [80436,80457]
atom_expr [80456,80477]
===
match
---
simple_stmt [21566,21780]
simple_stmt [21586,21800]
===
match
---
name: log [32639,32642]
name: log [32659,32662]
===
match
---
atom_expr [6630,7122]
atom_expr [6658,7150]
===
match
---
operator: , [7107,7108]
operator: , [7135,7136]
===
match
---
comparison [25327,25359]
comparison [25347,25379]
===
match
---
operator: == [77703,77705]
operator: == [77723,77725]
===
match
---
name: DateTime [29846,29854]
name: DateTime [29866,29874]
===
match
---
name: k [49344,49345]
name: k [49364,49365]
===
match
---
name: timezone [42873,42881]
name: timezone [42893,42901]
===
match
---
trailer [77281,77287]
trailer [77301,77307]
===
match
---
simple_stmt [39947,39971]
simple_stmt [39967,39991]
===
match
---
trailer [22378,22388]
trailer [22398,22408]
===
match
---
suite [20667,20990]
suite [20687,21010]
===
match
---
operator: -> [45816,45818]
operator: -> [45836,45838]
===
match
---
name: dep_status [32553,32563]
name: dep_status [32573,32583]
===
match
---
atom_expr [46120,46278]
atom_expr [46140,46298]
===
match
---
operator: , [72657,72658]
operator: , [72677,72678]
===
match
---
operator: = [3639,3640]
operator: = [3667,3668]
===
match
---
name: context [53235,53242]
name: context [53255,53262]
===
match
---
operator: , [49050,49051]
operator: , [49070,49071]
===
match
---
trailer [30329,30338]
trailer [30349,30358]
===
match
---
return_stmt [41398,41409]
return_stmt [41418,41429]
===
match
---
operator: -> [78051,78053]
operator: -> [78071,78073]
===
match
---
name: self [43068,43072]
name: self [43088,43092]
===
match
---
name: timedelta [983,992]
name: timedelta [968,977]
===
match
---
fstring_string: operator_successes_ [50631,50650]
fstring_string: operator_successes_ [50651,50670]
===
match
---
atom_expr [5424,5445]
atom_expr [5452,5473]
===
match
---
trailer [43521,43524]
trailer [43541,43544]
===
match
---
atom_expr [27263,27331]
atom_expr [27283,27351]
===
match
---
atom_expr [77907,77915]
atom_expr [77927,77935]
===
match
---
atom_expr [80142,80160]
atom_expr [80162,80180]
===
match
---
trailer [7771,7786]
trailer [7799,7814]
===
match
---
operator: = [70551,70552]
operator: = [70571,70572]
===
match
---
trailer [50987,50989]
trailer [51007,51009]
===
match
---
operator: = [14250,14251]
operator: = [14270,14271]
===
match
---
operator: = [27114,27115]
operator: = [27134,27135]
===
match
---
name: provide_session [29099,29114]
name: provide_session [29119,29134]
===
match
---
trailer [5242,5248]
trailer [5270,5276]
===
match
---
name: dag_id [6665,6671]
name: dag_id [6693,6699]
===
match
---
operator: , [71902,71903]
operator: , [71922,71923]
===
match
---
name: BaseJob [7404,7411]
name: BaseJob [7432,7439]
===
match
---
atom_expr [19521,19559]
atom_expr [19541,19579]
===
match
---
trailer [13136,13142]
trailer [13156,13162]
===
match
---
name: result [51665,51671]
name: result [51685,51691]
===
match
---
atom_expr [60147,60167]
atom_expr [60167,60187]
===
match
---
name: rendered_k8s_spec [67425,67442]
name: rendered_k8s_spec [67445,67462]
===
match
---
string: '%Y%m%dT%H%M%S' [58628,58643]
string: '%Y%m%dT%H%M%S' [58648,58663]
===
match
---
string: 'BASE_URL' [19312,19322]
string: 'BASE_URL' [19332,19342]
===
match
---
atom_expr [57021,57046]
atom_expr [57041,57066]
===
match
---
atom_expr [22798,22804]
atom_expr [22818,22824]
===
match
---
atom_expr [26170,26194]
atom_expr [26190,26214]
===
match
---
name: int [80049,80052]
name: int [80069,80072]
===
match
---
name: task_id [79352,79359]
name: task_id [79372,79379]
===
match
---
classdef [63589,64577]
classdef [63609,64597]
===
match
---
operator: < [35091,35092]
operator: < [35111,35112]
===
match
---
operator: , [10073,10074]
operator: , [10101,10102]
===
match
---
name: is_smart_sensor_compatible [49673,49699]
name: is_smart_sensor_compatible [49693,49719]
===
match
---
param [80612,80616]
param [80632,80636]
===
match
---
test [31783,31827]
test [31803,31847]
===
match
---
operator: = [11335,11336]
operator: = [11363,11364]
===
match
---
operator: , [65613,65614]
operator: , [65633,65634]
===
match
---
name: self [44269,44273]
name: self [44289,44293]
===
match
---
name: TaskInstance [79289,79301]
name: TaskInstance [79309,79321]
===
match
---
operator: = [14160,14161]
operator: = [14180,14181]
===
match
---
operator: , [63074,63075]
operator: , [63094,63095]
===
match
---
name: airflow [2076,2083]
name: airflow [2061,2068]
===
match
---
name: cmd [18577,18580]
name: cmd [18597,18600]
===
match
---
simple_stmt [79933,79976]
simple_stmt [79953,79996]
===
match
---
name: dag_id [80605,80611]
name: dag_id [80625,80631]
===
match
---
name: task [59571,59575]
name: task [59591,59595]
===
match
---
name: all [7429,7432]
name: all [7457,7460]
===
match
---
simple_stmt [21821,21856]
simple_stmt [21841,21876]
===
match
---
simple_stmt [64102,64118]
simple_stmt [64122,64138]
===
match
---
operator: { [47961,47962]
operator: { [47981,47982]
===
match
---
name: state [12135,12140]
name: state [12155,12160]
===
match
---
operator: } [62412,62413]
operator: } [62432,62433]
===
match
---
param [63381,63440]
param [63401,63460]
===
match
---
name: task_type [50661,50670]
name: task_type [50681,50690]
===
match
---
trailer [23902,23908]
trailer [23922,23928]
===
match
---
atom_expr [29506,29558]
atom_expr [29526,29578]
===
match
---
suite [81034,81067]
suite [81054,81087]
===
match
---
suite [42964,43223]
suite [42984,43243]
===
match
---
name: dag_id [79819,79825]
name: dag_id [79839,79845]
===
match
---
name: self [80685,80689]
name: self [80705,80709]
===
match
---
raise_stmt [48534,48588]
raise_stmt [48554,48608]
===
match
---
name: execution_date [27143,27157]
name: execution_date [27163,27177]
===
match
---
operator: == [24037,24039]
operator: == [24057,24059]
===
match
---
operator: @ [80587,80588]
operator: @ [80607,80608]
===
match
---
atom_expr [61642,61682]
atom_expr [61662,61702]
===
match
---
name: task [53151,53155]
name: task [53171,53175]
===
match
---
atom_expr [5297,5306]
atom_expr [5325,5334]
===
match
---
trailer [64644,64648]
trailer [64664,64668]
===
match
---
name: var [64038,64041]
name: var [64058,64061]
===
match
---
name: execution_date [8771,8785]
name: execution_date [8799,8813]
===
match
---
decorated [81380,81453]
decorated [81400,81473]
===
match
---
atom_expr [8542,8569]
atom_expr [8570,8597]
===
match
---
name: self [80641,80645]
name: self [80661,80665]
===
match
---
simple_stmt [43508,43525]
simple_stmt [43528,43545]
===
match
---
name: bool [35739,35743]
name: bool [35759,35763]
===
match
---
name: Column [9622,9628]
name: Column [9650,9656]
===
match
---
simple_stmt [2505,2562]
simple_stmt [2490,2547]
===
match
---
name: queue [23264,23269]
name: queue [23284,23289]
===
match
---
atom [18534,18545]
atom [18554,18565]
===
match
---
operator: { [70553,70554]
operator: { [70573,70574]
===
match
---
name: provide_session [56066,56081]
name: provide_session [56086,56101]
===
match
---
name: state [54721,54726]
name: state [54741,54746]
===
match
---
name: session [42767,42774]
name: session [42787,42794]
===
match
---
expr_stmt [55011,55032]
expr_stmt [55031,55052]
===
match
---
atom_expr [52605,52615]
atom_expr [52625,52635]
===
match
---
trailer [74296,74303]
trailer [74316,74323]
===
match
---
name: airflow [48191,48198]
name: airflow [48211,48218]
===
match
---
operator: = [38459,38460]
operator: = [38479,38480]
===
match
---
operator: = [60454,60455]
operator: = [60474,60475]
===
match
---
name: bool [53508,53512]
name: bool [53528,53532]
===
match
---
trailer [47618,47686]
trailer [47638,47706]
===
match
---
simple_stmt [2026,2071]
simple_stmt [2011,2056]
===
match
---
trailer [77276,77288]
trailer [77296,77308]
===
match
---
name: add [57093,57096]
name: add [57113,57116]
===
match
---
operator: , [70852,70853]
operator: , [70872,70873]
===
match
---
name: self [13367,13371]
name: self [13387,13391]
===
match
---
string: "&upstream=false" [19789,19806]
string: "&upstream=false" [19809,19826]
===
match
---
name: self [64144,64148]
name: self [64164,64168]
===
match
---
operator: @ [25093,25094]
operator: @ [25113,25114]
===
match
---
param [45796,45801]
param [45816,45821]
===
match
---
name: SHUTDOWN [5257,5265]
name: SHUTDOWN [5285,5293]
===
match
---
param [12504,12508]
param [12524,12528]
===
match
---
name: self [72642,72646]
name: self [72662,72666]
===
match
---
trailer [30305,30316]
trailer [30325,30336]
===
match
---
funcdef [56086,59085]
funcdef [56106,59105]
===
match
---
expr_stmt [23380,23429]
expr_stmt [23400,23449]
===
match
---
trailer [58319,58334]
trailer [58339,58354]
===
match
---
name: _date_or_empty [43913,43927]
name: _date_or_empty [43933,43947]
===
match
---
name: prev_attempted_tries [13346,13366]
name: prev_attempted_tries [13366,13386]
===
match
---
name: DeprecationWarning [28980,28998]
name: DeprecationWarning [29000,29018]
===
match
---
operator: = [54546,54547]
operator: = [54566,54567]
===
match
---
name: try_number [8602,8612]
name: try_number [8630,8640]
===
match
---
comparison [37793,37820]
comparison [37813,37840]
===
match
---
name: airflow [2938,2945]
name: airflow [2966,2973]
===
match
---
name: Optional [11135,11143]
name: Optional [11163,11171]
===
match
---
name: pool [23325,23329]
name: pool [23345,23349]
===
match
---
operator: , [54292,54293]
operator: , [54312,54313]
===
match
---
expr_stmt [22613,22634]
expr_stmt [22633,22654]
===
match
---
trailer [33997,34006]
trailer [34017,34026]
===
match
---
trailer [61727,61736]
trailer [61747,61756]
===
match
---
name: test_mode [65694,65703]
name: test_mode [65714,65723]
===
match
---
expr_stmt [14841,14865]
expr_stmt [14861,14885]
===
match
---
trailer [7411,7414]
trailer [7439,7442]
===
match
---
atom_expr [19034,19072]
atom_expr [19054,19092]
===
match
---
name: TaskInstance [26145,26157]
name: TaskInstance [26165,26177]
===
match
---
name: TR [6744,6746]
name: TR [6772,6774]
===
match
---
name: dag_id [7687,7693]
name: dag_id [7715,7721]
===
match
---
trailer [59592,59603]
trailer [59612,59623]
===
match
---
name: pod_template_file [68993,69010]
name: pod_template_file [69013,69030]
===
match
---
operator: + [19637,19638]
operator: + [19657,19658]
===
match
---
name: String [10110,10116]
name: String [10138,10144]
===
match
---
name: state [22105,22110]
name: state [22125,22130]
===
match
---
name: exception_html [71621,71635]
name: exception_html [71641,71655]
===
match
---
trailer [9555,9581]
trailer [9583,9609]
===
match
---
for_stmt [7855,7953]
for_stmt [7883,7981]
===
match
---
name: path [71990,71994]
name: path [72010,72014]
===
match
---
atom_expr [51674,51708]
atom_expr [51694,51728]
===
match
---
operator: , [50778,50779]
operator: , [50798,50799]
===
match
---
name: self [19102,19106]
name: self [19122,19126]
===
match
---
if_stmt [18717,18779]
if_stmt [18737,18799]
===
match
---
name: prev_ti [30142,30149]
name: prev_ti [30162,30169]
===
match
---
atom_expr [39042,39057]
atom_expr [39062,39077]
===
match
---
argument [54110,54141]
argument [54130,54161]
===
match
---
operator: = [14128,14129]
operator: = [14148,14149]
===
match
---
operator: = [11034,11035]
operator: = [11062,11063]
===
match
---
name: TaskInstance [21620,21632]
name: TaskInstance [21640,21652]
===
match
---
operator: , [44754,44755]
operator: , [44774,44775]
===
match
---
operator: , [78852,78853]
operator: , [78872,78873]
===
match
---
operator: , [7145,7146]
operator: , [7173,7174]
===
match
---
trailer [58602,58613]
trailer [58622,58633]
===
match
---
trailer [11182,11184]
trailer [11210,11212]
===
match
---
operator: == [78835,78837]
operator: == [78855,78857]
===
match
---
string: """         Generates the shell command required to execute this task instance.          :param dag_id: DAG ID         :type dag_id: str         :param task_id: Task ID         :type task_id: str         :param execution_date: Execution date for the task         :type execution_date: datetime         :param mark_success: Whether to mark the task as successful         :type mark_success: bool         :param ignore_all_deps: Ignore all ignorable dependencies.             Overrides the other ignore_* parameters.         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past parameter of DAGs             (e.g. for Backfills)         :type ignore_depends_on_past: bool         :param ignore_task_deps: Ignore task-specific dependencies such as depends_on_past             and trigger rule         :type ignore_task_deps: bool         :param ignore_ti_state: Ignore the task instance's previous failure/success         :type ignore_ti_state: bool         :param local: Whether to run the task locally         :type local: bool         :param pickle_id: If the DAG was serialized to the DB, the ID             associated with the pickled DAG         :type pickle_id: Optional[int]         :param file_path: path to the file containing the DAG definition         :type file_path: Optional[str]         :param raw: raw mode (needs more details)         :type raw: Optional[bool]         :param job_id: job ID (needs more details)         :type job_id: Optional[int]         :param pool: the Airflow pool that the task should run in         :type pool: Optional[str]         :param cfg_path: the Path to the configuration file         :type cfg_path: Optional[str]         :return: shell command that can be used to run the task instance         :rtype: list[str]         """ [16108,17916]
string: """         Generates the shell command required to execute this task instance.          :param dag_id: DAG ID         :type dag_id: str         :param task_id: Task ID         :type task_id: str         :param execution_date: Execution date for the task         :type execution_date: datetime         :param mark_success: Whether to mark the task as successful         :type mark_success: bool         :param ignore_all_deps: Ignore all ignorable dependencies.             Overrides the other ignore_* parameters.         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past parameter of DAGs             (e.g. for Backfills)         :type ignore_depends_on_past: bool         :param ignore_task_deps: Ignore task-specific dependencies such as depends_on_past             and trigger rule         :type ignore_task_deps: bool         :param ignore_ti_state: Ignore the task instance's previous failure/success         :type ignore_ti_state: bool         :param local: Whether to run the task locally         :type local: bool         :param pickle_id: If the DAG was serialized to the DB, the ID             associated with the pickled DAG         :type pickle_id: Optional[int]         :param file_path: path to the file containing the DAG definition         :type file_path: Optional[str]         :param raw: raw mode (needs more details)         :type raw: Optional[bool]         :param job_id: job ID (needs more details)         :type job_id: Optional[int]         :param pool: the Airflow pool that the task should run in         :type pool: Optional[str]         :param cfg_path: the Path to the configuration file         :type cfg_path: Optional[str]         :return: shell command that can be used to run the task instance         :rtype: list[str]         """ [16128,17936]
===
match
---
atom_expr [78870,78918]
atom_expr [78890,78938]
===
match
---
suite [45913,48065]
suite [45933,48085]
===
match
---
operator: = [54405,54406]
operator: = [54425,54426]
===
match
---
atom_expr [5549,5561]
atom_expr [5577,5589]
===
match
---
atom_expr [56887,56900]
atom_expr [56907,56920]
===
match
---
fstring [50629,50672]
fstring [50649,50692]
===
match
---
param [52362,52407]
param [52382,52427]
===
match
---
operator: , [64648,64649]
operator: , [64668,64669]
===
match
---
trailer [45544,45550]
trailer [45564,45570]
===
match
---
name: task_reschedule [39302,39317]
name: task_reschedule [39322,39337]
===
match
---
trailer [56476,56494]
trailer [56496,56514]
===
match
---
trailer [26360,26363]
trailer [26380,26383]
===
match
---
name: email [58750,58755]
name: email [58770,58775]
===
match
---
atom_expr [18148,18162]
atom_expr [18168,18182]
===
match
---
operator: , [71733,71734]
operator: , [71753,71754]
===
match
---
name: UP_FOR_RETRY [58214,58226]
name: UP_FOR_RETRY [58234,58246]
===
match
---
arglist [44742,44777]
arglist [44762,44797]
===
match
---
trailer [46133,46141]
trailer [46153,46161]
===
match
---
atom_expr [28788,29035]
atom_expr [28808,29055]
===
match
---
atom_expr [6872,6896]
atom_expr [6900,6924]
===
match
---
name: commit [24096,24102]
name: commit [24116,24122]
===
match
---
trailer [77799,77806]
trailer [77819,77826]
===
match
---
trailer [62460,62467]
trailer [62480,62487]
===
match
---
suite [62577,62662]
suite [62597,62682]
===
match
---
trailer [14992,15000]
trailer [15012,15020]
===
match
---
operator: , [34036,34037]
operator: , [34056,34057]
===
match
---
name: total_seconds [25044,25057]
name: total_seconds [25064,25077]
===
match
---
trailer [22434,22443]
trailer [22454,22463]
===
match
---
operator: , [41694,41695]
operator: , [41714,41715]
===
match
---
name: str [24424,24427]
name: str [24444,24447]
===
match
---
atom_expr [59682,59712]
atom_expr [59702,59732]
===
match
---
atom_expr [44620,44630]
atom_expr [44640,44650]
===
match
---
argument [39874,39897]
argument [39894,39917]
===
match
---
trailer [80527,80532]
trailer [80547,80552]
===
match
---
name: max [8542,8545]
name: max [8570,8573]
===
match
---
name: task_id [28023,28030]
name: task_id [28043,28050]
===
match
---
name: var [63234,63237]
name: var [63254,63257]
===
match
---
simple_stmt [13173,13197]
simple_stmt [13193,13217]
===
match
---
trailer [45097,45104]
trailer [45117,45124]
===
match
---
operator: = [5056,5057]
operator: = [5084,5085]
===
match
---
name: self [80031,80035]
name: self [80051,80055]
===
match
---
simple_stmt [69734,70102]
simple_stmt [69754,70122]
===
match
---
trailer [50811,50816]
trailer [50831,50836]
===
match
---
param [36067,36080]
param [36087,36100]
===
match
---
dotted_name [2257,2284]
dotted_name [2242,2269]
===
match
---
name: self [39987,39991]
name: self [40007,40011]
===
match
---
name: context [51692,51699]
name: context [51712,51719]
===
match
---
name: in_ [26166,26169]
name: in_ [26186,26189]
===
match
---
operator: , [53645,53646]
operator: , [53665,53666]
===
match
---
name: Variable [63118,63126]
name: Variable [63138,63146]
===
match
---
name: _safe_date [58539,58549]
name: _safe_date [58559,58569]
===
match
---
operator: = [65340,65341]
operator: = [65360,65361]
===
match
---
expr_stmt [78338,78359]
expr_stmt [78358,78379]
===
match
---
parameters [20646,20666]
parameters [20666,20686]
===
match
---
name: SIGTERM [48619,48626]
name: SIGTERM [48639,48646]
===
match
---
import_name [820,834]
import_name [805,819]
===
match
---
trailer [24688,24690]
trailer [24708,24710]
===
match
---
dotted_name [1123,1135]
dotted_name [1108,1120]
===
match
---
name: task_copy [48502,48511]
name: task_copy [48522,48531]
===
match
---
name: self [14071,14075]
name: self [14091,14095]
===
match
---
comparison [39093,39130]
comparison [39113,39150]
===
match
---
operator: , [10744,10745]
operator: , [10772,10773]
===
match
---
name: TaskInstance [20303,20315]
name: TaskInstance [20323,20335]
===
match
---
atom_expr [23895,24079]
atom_expr [23915,24099]
===
match
---
name: task_id [23980,23987]
name: task_id [24000,24007]
===
match
---
name: SUCCESS [30924,30931]
name: SUCCESS [30944,30951]
===
match
---
name: self [56595,56599]
name: self [56615,56619]
===
match
---
operator: , [68511,68512]
operator: , [68531,68532]
===
match
---
name: timezone [50919,50927]
name: timezone [50939,50947]
===
match
---
name: warning [39996,40003]
name: warning [40016,40023]
===
match
---
import_as_names [973,992]
import_as_names [958,977]
===
match
---
trailer [33041,33056]
trailer [33061,33076]
===
match
---
trailer [47165,47170]
trailer [47185,47190]
===
match
---
name: dag_id [35480,35486]
name: dag_id [35500,35506]
===
match
---
name: DagRun [35473,35479]
name: DagRun [35493,35499]
===
match
---
operator: , [25445,25446]
operator: , [25465,25466]
===
match
---
name: skippable_task_ids [47300,47318]
name: skippable_task_ids [47320,47338]
===
match
---
trailer [12592,12602]
trailer [12612,12622]
===
match
---
name: self [80889,80893]
name: self [80909,80913]
===
match
---
name: hasattr [69434,69441]
name: hasattr [69454,69461]
===
match
---
string: '-' [61728,61731]
string: '-' [61748,61751]
===
match
---
name: last_dagrun [27952,27963]
name: last_dagrun [27972,27983]
===
match
---
expr_stmt [32441,32482]
expr_stmt [32461,32502]
===
match
---
atom_expr [68499,68511]
atom_expr [68519,68531]
===
match
---
trailer [10721,10777]
trailer [10749,10805]
===
match
---
name: filter [21600,21606]
name: filter [21620,21626]
===
match
---
name: values_ordered_by_id [77203,77223]
name: values_ordered_by_id [77223,77243]
===
match
---
name: pop [3658,3661]
name: pop [3686,3689]
===
match
---
operator: = [9437,9438]
operator: = [9465,9466]
===
match
---
param [14071,14076]
param [14091,14096]
===
match
---
atom_expr [72302,72359]
atom_expr [72322,72379]
===
match
---
name: self [45317,45321]
name: self [45337,45341]
===
match
---
atom [18698,18707]
atom [18718,18727]
===
match
---
atom_expr [31965,32169]
atom_expr [31985,32189]
===
match
---
expr_stmt [61749,61809]
expr_stmt [61769,61829]
===
match
---
simple_stmt [42813,42844]
simple_stmt [42833,42864]
===
match
---
funcdef [4683,7953]
funcdef [4711,7981]
===
match
---
string: "Webserver does not have access to User-defined Macros or Filters " [66829,66896]
string: "Webserver does not have access to User-defined Macros or Filters " [66849,66916]
===
match
---
atom_expr [8264,8275]
atom_expr [8292,8303]
===
match
---
trailer [56530,56560]
trailer [56550,56580]
===
match
---
tfpdef [15797,15818]
tfpdef [15817,15838]
===
match
---
name: error [56616,56621]
name: error [56636,56641]
===
match
---
expr_stmt [72202,72270]
expr_stmt [72222,72290]
===
match
---
name: ceil [33668,33672]
name: ceil [33688,33692]
===
match
---
comparison [78760,78789]
comparison [78780,78809]
===
match
---
operator: -> [80861,80863]
operator: -> [80881,80883]
===
match
---
atom_expr [10894,11071]
atom_expr [10922,11099]
===
match
---
operator: , [28966,28967]
operator: , [28986,28987]
===
match
---
trailer [68957,68980]
trailer [68977,69000]
===
match
---
operator: = [23301,23302]
operator: = [23321,23322]
===
match
---
if_stmt [18667,18709]
if_stmt [18687,18729]
===
match
---
atom_expr [57918,57930]
atom_expr [57938,57950]
===
match
---
decorated [3287,3897]
decorated [3315,3925]
===
match
---
name: dag_id [74285,74291]
name: dag_id [74305,74311]
===
match
---
arglist [67913,67984]
arglist [67933,68004]
===
match
---
number: 1 [22599,22600]
number: 1 [22619,22620]
===
match
---
simple_stmt [49515,49554]
simple_stmt [49535,49574]
===
match
---
name: log [30090,30093]
name: log [30110,30113]
===
match
---
operator: , [36057,36058]
operator: , [36077,36078]
===
match
---
name: dag_id [19107,19113]
name: dag_id [19127,19133]
===
match
---
return_stmt [24283,24370]
return_stmt [24303,24390]
===
match
---
name: self [68559,68563]
name: self [68579,68583]
===
match
---
simple_stmt [22831,22849]
simple_stmt [22851,22869]
===
match
---
trailer [23442,23454]
trailer [23462,23474]
===
match
---
name: get [63127,63130]
name: get [63147,63150]
===
match
---
simple_stmt [56957,57013]
simple_stmt [56977,57033]
===
match
---
simple_stmt [17925,17958]
simple_stmt [17945,17978]
===
match
---
name: log [58906,58909]
name: log [58926,58929]
===
match
---
arith_expr [40280,40298]
arith_expr [40300,40318]
===
match
---
atom_expr [55431,55713]
atom_expr [55451,55733]
===
match
---
name: commit [20981,20987]
name: commit [21001,21007]
===
match
---
expr_stmt [10127,10160]
expr_stmt [10155,10188]
===
match
---
simple_stmt [3539,3572]
simple_stmt [3567,3600]
===
match
---
name: Session [26517,26524]
name: Session [26537,26544]
===
match
---
name: drs [7865,7868]
name: drs [7893,7896]
===
match
---
suite [33382,34816]
suite [33402,34836]
===
match
---
trailer [42841,42843]
trailer [42861,42863]
===
match
---
except_clause [66715,66767]
except_clause [66735,66787]
===
match
---
name: self [70885,70889]
name: self [70905,70909]
===
match
---
simple_stmt [45571,45591]
simple_stmt [45591,45611]
===
match
---
operator: , [38313,38314]
operator: , [38333,38334]
===
match
---
name: cmd [18812,18815]
name: cmd [18832,18835]
===
match
---
operator: , [1767,1768]
operator: , [1752,1753]
===
match
---
suite [58182,58335]
suite [58202,58355]
===
match
---
operator: , [14075,14076]
operator: , [14095,14096]
===
match
---
name: Exception [59185,59194]
name: Exception [59205,59214]
===
match
---
simple_stmt [12030,12050]
simple_stmt [12058,12078]
===
match
---
expr_stmt [42621,42637]
expr_stmt [42641,42657]
===
match
---
name: state [24755,24760]
name: state [24775,24780]
===
match
---
param [67778,67785]
param [67798,67805]
===
match
---
name: func [1355,1359]
name: func [1340,1344]
===
match
---
name: executor_config [80145,80160]
name: executor_config [80165,80180]
===
match
---
name: String [10002,10008]
name: String [10030,10036]
===
match
---
operator: , [74692,74693]
operator: , [74712,74713]
===
match
---
name: e [44324,44325]
name: e [44344,44345]
===
match
---
name: get_template_context [59832,59852]
name: get_template_context [59852,59872]
===
match
---
operator: == [5180,5182]
operator: == [5208,5210]
===
match
---
atom_expr [6744,6761]
atom_expr [6772,6789]
===
match
---
operator: != [14706,14708]
operator: != [14726,14728]
===
match
---
name: contextlib [794,804]
name: contextlib [794,804]
===
match
---
import_from [82537,82577]
import_from [82557,82597]
===
match
---
name: execution_date [17931,17945]
name: execution_date [17951,17965]
===
match
---
operator: , [71848,71849]
operator: , [71868,71869]
===
match
---
operator: , [8764,8765]
operator: , [8792,8793]
===
match
---
name: property [81311,81319]
name: property [81331,81339]
===
match
---
with_stmt [71980,72045]
with_stmt [72000,72065]
===
match
---
string: "Marking task as UP_FOR_RETRY." [58253,58284]
string: "Marking task as UP_FOR_RETRY." [58273,58304]
===
match
---
name: registered [49785,49795]
name: registered [49805,49815]
===
match
---
fstring_expr [19372,19377]
fstring_expr [19392,19397]
===
match
---
operator: , [41356,41357]
operator: , [41376,41377]
===
match
---
operator: -> [3934,3936]
operator: -> [3962,3964]
===
match
---
name: bool [35777,35781]
name: bool [35797,35801]
===
match
---
name: self [39284,39288]
name: self [39304,39308]
===
match
---
argument [70926,70950]
argument [70946,70970]
===
match
---
name: task [61485,61489]
name: task [61505,61509]
===
match
---
operator: @ [56065,56066]
operator: @ [56085,56086]
===
match
---
name: hasattr [60147,60154]
name: hasattr [60167,60174]
===
match
---
trailer [18199,18206]
trailer [18219,18226]
===
match
---
string: "Recording the task instance as FAILED" [20862,20901]
string: "Recording the task instance as FAILED" [20882,20921]
===
match
---
name: self [81492,81496]
name: self [81512,81516]
===
match
---
operator: = [42796,42797]
operator: = [42816,42817]
===
match
---
trailer [40844,40852]
trailer [40864,40872]
===
match
---
name: pool [15421,15425]
name: pool [15441,15445]
===
match
---
trailer [40658,40668]
trailer [40678,40688]
===
match
---
operator: = [64042,64043]
operator: = [64062,64063]
===
match
---
name: ti [79907,79909]
name: ti [79927,79929]
===
match
---
not_test [54315,54322]
not_test [54335,54342]
===
match
---
trailer [54428,54442]
trailer [54448,54462]
===
match
---
number: 1000 [9912,9916]
number: 1000 [9940,9944]
===
match
---
name: Context [3347,3354]
name: Context [3375,3382]
===
match
---
simple_stmt [66356,66442]
simple_stmt [66376,66462]
===
match
---
simple_stmt [54962,55003]
simple_stmt [54982,55023]
===
match
---
param [51973,51977]
param [51993,51997]
===
match
---
trailer [54720,54726]
trailer [54740,54746]
===
match
---
trailer [60883,60895]
trailer [60903,60915]
===
match
---
string: """Functions that need to be run before a Task is executed""" [51988,52049]
string: """Functions that need to be run before a Task is executed""" [52008,52069]
===
match
---
name: task_copy [49663,49672]
name: task_copy [49683,49692]
===
match
---
atom_expr [8478,8570]
atom_expr [8506,8598]
===
match
---
name: self [43959,43963]
name: self [43979,43983]
===
match
---
trailer [12193,12195]
trailer [12213,12215]
===
match
---
operator: = [78428,78429]
operator: = [78448,78449]
===
match
---
arglist [79055,79220]
arglist [79075,79240]
===
match
---
name: test_mode [59205,59214]
name: test_mode [59225,59234]
===
match
---
trailer [5113,5139]
trailer [5141,5167]
===
match
---
simple_stmt [26575,26804]
simple_stmt [26595,26824]
===
match
---
operator: = [39634,39635]
operator: = [39654,39655]
===
match
---
trailer [40043,40051]
trailer [40063,40071]
===
match
---
name: self [67192,67196]
name: self [67212,67216]
===
match
---
subscriptlist [74548,74566]
subscriptlist [74568,74586]
===
match
---
expr_stmt [22100,22121]
expr_stmt [22120,22141]
===
match
---
name: next_try_number [13902,13917]
name: next_try_number [13922,13937]
===
match
---
operator: , [35875,35876]
operator: , [35895,35896]
===
match
---
operator: , [41901,41902]
operator: , [41921,41922]
===
match
---
trailer [48918,48979]
trailer [48938,48999]
===
match
---
name: Iterable [78001,78009]
name: Iterable [78021,78029]
===
match
---
name: deserialize_json [64554,64570]
name: deserialize_json [64574,64590]
===
match
---
name: overwrite_params_with_dag_run_conf [67737,67771]
name: overwrite_params_with_dag_run_conf [67757,67791]
===
match
---
string: "%s. State set to NONE." [40197,40221]
string: "%s. State set to NONE." [40217,40241]
===
match
---
atom_expr [22787,22795]
atom_expr [22807,22815]
===
match
---
name: AirflowFailException [44230,44250]
name: AirflowFailException [44250,44270]
===
match
---
name: RUNNING_DEPS [2367,2379]
name: RUNNING_DEPS [2352,2364]
===
match
---
name: session [26029,26036]
name: session [26049,26056]
===
match
---
suite [80423,80479]
suite [80443,80499]
===
match
---
name: error_fd [54787,54795]
name: error_fd [54807,54815]
===
match
---
string: 'kcah_acitats' [82412,82426]
string: 'kcah_acitats' [82432,82446]
===
match
---
name: _CURRENT_CONTEXT [3641,3657]
name: _CURRENT_CONTEXT [3669,3685]
===
match
---
trailer [80491,80498]
trailer [80511,80518]
===
match
---
param [63303,63313]
param [63323,63333]
===
match
---
tfpdef [59167,59195]
tfpdef [59187,59215]
===
match
---
atom_expr [13978,13994]
atom_expr [13998,14014]
===
match
---
name: session [20945,20952]
name: session [20965,20972]
===
match
---
simple_stmt [72522,72606]
simple_stmt [72542,72626]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28815,28966]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28835,28986]
===
match
---
name: dag_run [46947,46954]
name: dag_run [46967,46974]
===
match
---
name: dag [27354,27357]
name: dag [27374,27377]
===
match
---
arith_expr [19339,19422]
arith_expr [19359,19442]
===
match
---
name: SKIPPED [43611,43618]
name: SKIPPED [43631,43638]
===
match
---
arglist [62004,62011]
arglist [62024,62031]
===
match
---
atom_expr [67898,67985]
atom_expr [67918,68005]
===
match
---
name: mark_success [35924,35936]
name: mark_success [35944,35956]
===
match
---
name: task_copy [51357,51366]
name: task_copy [51377,51386]
===
match
---
name: Sentry [41638,41644]
name: Sentry [41658,41664]
===
match
---
decorator [45731,45753]
decorator [45751,45773]
===
match
---
argument [65488,65507]
argument [65508,65527]
===
match
---
trailer [6886,6896]
trailer [6914,6924]
===
match
---
name: error_file [44355,44365]
name: error_file [44375,44385]
===
match
---
trailer [57889,57891]
trailer [57909,57911]
===
match
---
atom_expr [67998,68025]
atom_expr [68018,68045]
===
match
---
operator: = [21570,21571]
operator: = [21590,21591]
===
match
---
trailer [20285,20474]
trailer [20305,20494]
===
match
---
trailer [77657,77664]
trailer [77677,77684]
===
match
---
atom_expr [39960,39970]
atom_expr [39980,39990]
===
match
---
operator: = [12133,12134]
operator: = [12153,12154]
===
match
---
operator: = [22542,22543]
operator: = [22562,22563]
===
match
---
trailer [48912,48918]
trailer [48932,48938]
===
match
---
name: airflow [2510,2517]
name: airflow [2495,2502]
===
match
---
operator: = [41723,41724]
operator: = [41743,41744]
===
match
---
name: exceptions [1643,1653]
name: exceptions [1628,1638]
===
match
---
expr_stmt [20911,20936]
expr_stmt [20931,20956]
===
match
---
name: jinja_env [71780,71789]
name: jinja_env [71800,71809]
===
match
---
operator: = [51672,51673]
operator: = [51692,51693]
===
match
---
trailer [45077,45086]
trailer [45097,45106]
===
match
---
atom_expr [8159,8184]
atom_expr [8187,8212]
===
match
---
operator: , [70904,70905]
operator: , [70924,70925]
===
match
---
subscriptlist [3952,3966]
subscriptlist [3980,3994]
===
match
---
name: vals_kv [76936,76943]
name: vals_kv [76956,76963]
===
match
---
string: '%Y-%m-%d' [60884,60894]
string: '%Y-%m-%d' [60904,60914]
===
match
---
name: jinja_context [70718,70731]
name: jinja_context [70738,70751]
===
match
---
dotted_name [45931,45952]
dotted_name [45951,45972]
===
match
---
tfpdef [56128,56156]
tfpdef [56148,56176]
===
match
---
name: nullable [10075,10083]
name: nullable [10103,10111]
===
match
---
name: Any [1056,1059]
name: Any [1041,1044]
===
match
---
simple_stmt [23520,23564]
simple_stmt [23540,23584]
===
match
---
string: "Refreshing TaskInstance %s from DB" [21513,21549]
string: "Refreshing TaskInstance %s from DB" [21533,21569]
===
match
---
name: conditions [6600,6610]
name: conditions [6628,6638]
===
match
---
expr_stmt [39538,39828]
expr_stmt [39558,39848]
===
match
---
trailer [24681,24688]
trailer [24701,24708]
===
match
---
decorators [45710,45753]
decorators [45730,45773]
===
match
---
suite [68180,68231]
suite [68200,68251]
===
match
---
name: ID_LEN [9484,9490]
name: ID_LEN [9512,9518]
===
match
---
simple_stmt [48315,48337]
simple_stmt [48335,48357]
===
match
---
atom_expr [43592,43602]
atom_expr [43612,43622]
===
match
---
atom_expr [5564,5577]
atom_expr [5592,5605]
===
match
---
expr_stmt [3624,3663]
expr_stmt [3652,3691]
===
match
---
trailer [54801,54803]
trailer [54821,54823]
===
match
---
trailer [74122,74159]
trailer [74142,74179]
===
match
---
trailer [20491,20493]
trailer [20511,20513]
===
match
---
name: TaskReschedule [55456,55470]
name: TaskReschedule [55476,55490]
===
match
---
simple_stmt [1409,1464]
simple_stmt [1394,1449]
===
match
---
trailer [47711,47718]
trailer [47731,47738]
===
match
---
simple_stmt [14578,14598]
simple_stmt [14598,14618]
===
match
---
operator: = [10320,10321]
operator: = [10348,10349]
===
match
---
name: format [33865,33871]
name: format [33885,33891]
===
match
---
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.json.variable_name }}`` or             ``{{ var.json.get('variable_name', {'fall': 'back'}) }}``.             """ [63629,63857]
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.json.variable_name }}`` or             ``{{ var.json.get('variable_name', {'fall': 'back'}) }}``.             """ [63649,63877]
===
match
---
atom_expr [49038,49050]
atom_expr [49058,49070]
===
match
---
dotted_name [2076,2095]
dotted_name [2061,2080]
===
match
---
name: fd [4677,4679]
name: fd [4705,4707]
===
match
---
suite [53218,53366]
suite [53238,53386]
===
match
---
name: ti [5240,5242]
name: ti [5268,5270]
===
match
---
name: default_var [64529,64540]
name: default_var [64549,64560]
===
match
---
name: getattr [41498,41505]
name: getattr [41518,41525]
===
match
---
name: warning [49978,49985]
name: warning [49998,50005]
===
match
---
name: dr [27785,27787]
name: dr [27805,27807]
===
match
---
name: __table__ [7214,7223]
name: __table__ [7242,7251]
===
match
---
param [48121,48129]
param [48141,48149]
===
match
---
and_test [7491,7516]
and_test [7519,7544]
===
match
---
trailer [68563,68571]
trailer [68583,68591]
===
match
---
string: 'ti_state' [10688,10698]
string: 'ti_state' [10716,10726]
===
match
---
name: task_id [78436,78443]
name: task_id [78456,78463]
===
match
---
atom_expr [79339,79359]
atom_expr [79359,79379]
===
match
---
operator: @ [81541,81542]
operator: @ [81561,81562]
===
match
---
name: session [46300,46307]
name: session [46320,46327]
===
match
---
name: hostname [9887,9895]
name: hostname [9915,9923]
===
match
---
name: self [33897,33901]
name: self [33917,33921]
===
match
---
atom_expr [10284,10299]
atom_expr [10312,10327]
===
match
---
atom_expr [77075,77085]
atom_expr [77095,77105]
===
match
---
name: str [79613,79616]
name: str [79633,79636]
===
match
---
trailer [5296,5307]
trailer [5324,5335]
===
match
---
expr_stmt [62981,62996]
expr_stmt [63001,63016]
===
match
---
trailer [55083,55091]
trailer [55103,55111]
===
match
---
trailer [40442,40448]
trailer [40462,40468]
===
match
---
name: job_id [54547,54553]
name: job_id [54567,54573]
===
match
---
name: _run_finished_callback [52333,52355]
name: _run_finished_callback [52353,52375]
===
match
---
param [11090,11095]
param [11118,11123]
===
match
---
trailer [47885,47890]
trailer [47905,47910]
===
match
---
name: self [23950,23954]
name: self [23970,23974]
===
match
---
trailer [28017,28048]
trailer [28037,28068]
===
match
---
name: params [62481,62487]
name: params [62501,62507]
===
match
---
atom_expr [30883,30932]
atom_expr [30903,30952]
===
match
---
import_from [1118,1148]
import_from [1103,1133]
===
match
---
name: item [63991,63995]
name: item [64011,64015]
===
match
---
name: OperationalError [47740,47756]
name: OperationalError [47760,47776]
===
match
---
name: task_retries [5580,5592]
name: task_retries [5608,5620]
===
match
---
name: task [33351,33355]
name: task [33371,33375]
===
match
---
suite [77237,77370]
suite [77257,77390]
===
match
---
arglist [46692,46862]
arglist [46712,46882]
===
match
---
trailer [3555,3562]
trailer [3583,3590]
===
match
---
atom_expr [23950,23961]
atom_expr [23970,23981]
===
match
---
atom_expr [21887,21898]
atom_expr [21907,21918]
===
match
---
name: dag [60189,60192]
name: dag [60209,60212]
===
match
---
name: ti [5549,5551]
name: ti [5577,5579]
===
match
---
atom_expr [7456,7465]
atom_expr [7484,7493]
===
match
---
atom_expr [57101,57113]
atom_expr [57121,57133]
===
match
---
name: yesterday_ds [62288,62300]
name: yesterday_ds [62308,62320]
===
match
---
simple_stmt [34143,34193]
simple_stmt [34163,34213]
===
match
---
name: self [68203,68207]
name: self [68223,68227]
===
match
---
name: dag [60236,60239]
name: dag [60256,60259]
===
match
---
trailer [42940,42948]
trailer [42960,42968]
===
match
---
comparison [78972,78998]
comparison [78992,79018]
===
match
---
atom_expr [49242,49409]
atom_expr [49262,49429]
===
match
---
name: bool [59259,59263]
name: bool [59279,59283]
===
match
---
simple_stmt [62135,62193]
simple_stmt [62155,62213]
===
match
---
atom_expr [7919,7932]
atom_expr [7947,7960]
===
match
---
operator: { [33036,33037]
operator: { [33056,33057]
===
match
---
atom_expr [22456,22469]
atom_expr [22476,22489]
===
match
---
suite [8185,8311]
suite [8213,8339]
===
match
---
atom_expr [26486,26499]
atom_expr [26506,26519]
===
match
---
tfpdef [53655,53673]
tfpdef [53675,53693]
===
match
---
operator: = [15147,15148]
operator: = [15167,15168]
===
match
---
expr_stmt [53235,53272]
expr_stmt [53255,53292]
===
match
---
name: _prepare_and_execute_task_with_callbacks [43073,43113]
name: _prepare_and_execute_task_with_callbacks [43093,43133]
===
match
---
name: email_for_state [58297,58312]
name: email_for_state [58317,58332]
===
match
---
parameters [77995,78050]
parameters [78015,78070]
===
match
---
if_stmt [61206,61534]
if_stmt [61226,61554]
===
match
---
string: 'utf-8' [33998,34005]
string: 'utf-8' [34018,34025]
===
match
---
operator: , [77435,77436]
operator: , [77455,77456]
===
match
---
operator: = [60108,60109]
operator: = [60128,60129]
===
match
---
name: task_id [47285,47292]
name: task_id [47305,47312]
===
match
---
trailer [51614,51616]
trailer [51634,51636]
===
match
---
atom_expr [6114,6124]
atom_expr [6142,6152]
===
match
---
atom [19639,19848]
atom [19659,19868]
===
match
---
name: self [59642,59646]
name: self [59662,59666]
===
match
---
atom_expr [65253,65369]
atom_expr [65273,65389]
===
match
---
name: renderedtifields [66296,66312]
name: renderedtifields [66316,66332]
===
match
---
operator: , [58566,58567]
operator: , [58586,58587]
===
match
---
atom_expr [74013,74159]
atom_expr [74033,74179]
===
match
---
return_stmt [41601,41610]
return_stmt [41621,41630]
===
match
---
atom_expr [65032,65044]
atom_expr [65052,65064]
===
match
---
funcdef [53392,54857]
funcdef [53412,54877]
===
match
---
name: session [77437,77444]
name: session [77457,77464]
===
match
---
name: use_default [70512,70523]
name: use_default [70532,70543]
===
match
---
funcdef [81394,81453]
funcdef [81414,81473]
===
match
---
trailer [56946,56948]
trailer [56966,56968]
===
match
---
name: ID_LEN [1876,1882]
name: ID_LEN [1861,1867]
===
match
---
name: dag_id [60432,60438]
name: dag_id [60452,60458]
===
match
---
expr_stmt [54937,54953]
expr_stmt [54957,54973]
===
match
---
trailer [33914,33922]
trailer [33934,33942]
===
match
---
name: Union [78010,78015]
name: Union [78030,78035]
===
match
---
name: self [55143,55147]
name: self [55163,55167]
===
match
---
trailer [74541,74568]
trailer [74561,74588]
===
match
---
atom_expr [9622,9659]
atom_expr [9650,9687]
===
match
---
string: """Write error into error file by path""" [4329,4370]
string: """Write error into error file by path""" [4357,4398]
===
match
---
atom_expr [22544,22551]
atom_expr [22564,22571]
===
match
---
name: staticmethod [15474,15486]
name: staticmethod [15494,15506]
===
match
---
atom_expr [10103,10122]
atom_expr [10131,10150]
===
match
---
atom_expr [52369,52400]
atom_expr [52389,52420]
===
match
---
operator: , [41837,41838]
operator: , [41857,41858]
===
match
---
atom [26296,26326]
atom [26316,26346]
===
match
---
expr_stmt [31760,31827]
expr_stmt [31780,31847]
===
match
---
name: pool_slots [10035,10045]
name: pool_slots [10063,10073]
===
match
---
number: 2 [28503,28504]
number: 2 [28523,28524]
===
match
---
tfpdef [74623,74631]
tfpdef [74643,74651]
===
match
---
trailer [10290,10299]
trailer [10318,10327]
===
match
---
trailer [78009,78049]
trailer [78029,78069]
===
match
---
name: _log [11330,11334]
name: _log [11358,11362]
===
match
---
operator: = [37585,37586]
operator: = [37605,37606]
===
match
---
operator: , [43776,43777]
operator: , [43796,43797]
===
match
---
argument [15416,15425]
argument [15436,15445]
===
match
---
name: res [54319,54322]
name: res [54339,54342]
===
match
---
name: context [43114,43121]
name: context [43134,43141]
===
match
---
trailer [27142,27157]
trailer [27162,27177]
===
match
---
name: get [19295,19298]
name: get [19315,19318]
===
match
---
name: session [1484,1491]
name: session [1469,1476]
===
match
---
suite [21087,22908]
suite [21107,22928]
===
match
---
arglist [28018,28047]
arglist [28038,28067]
===
match
---
import_from [2071,2124]
import_from [2056,2109]
===
match
---
expr_stmt [63907,63922]
expr_stmt [63927,63942]
===
match
---
operator: , [29764,29765]
operator: , [29784,29785]
===
match
---
name: ignore_all_deps [14113,14128]
name: ignore_all_deps [14133,14148]
===
match
---
trailer [71941,71945]
trailer [71961,71965]
===
match
---
string: '%Y%m%dT%H%M%S' [62176,62191]
string: '%Y%m%dT%H%M%S' [62196,62211]
===
match
---
trailer [43288,43292]
trailer [43308,43312]
===
match
---
trailer [82192,82207]
trailer [82212,82227]
===
match
---
not_test [27734,27753]
not_test [27754,27773]
===
match
---
atom_expr [9542,9600]
atom_expr [9570,9628]
===
match
---
trailer [10389,10423]
trailer [10417,10451]
===
match
---
name: self [55488,55492]
name: self [55508,55512]
===
match
---
argument [51882,51894]
argument [51902,51914]
===
match
---
trailer [19556,19558]
trailer [19576,19578]
===
match
---
name: result [50453,50459]
name: result [50473,50479]
===
match
---
name: rollback [48054,48062]
name: rollback [48074,48082]
===
match
---
name: execution_date [61518,61532]
name: execution_date [61538,61552]
===
match
---
fstring [49341,49351]
fstring [49361,49371]
===
match
---
dotted_name [7317,7338]
dotted_name [7345,7366]
===
match
---
name: str [81174,81177]
name: str [81194,81197]
===
match
---
name: str [74628,74631]
name: str [74648,74651]
===
match
---
trailer [28276,28281]
trailer [28296,28301]
===
match
---
arglist [21513,21555]
arglist [21533,21575]
===
match
---
suite [31037,32302]
suite [31057,32322]
===
match
---
name: str [29782,29785]
name: str [29802,29805]
===
match
---
suite [61368,61534]
suite [61388,61554]
===
match
---
name: self [80938,80942]
name: self [80958,80962]
===
match
---
trailer [58151,58168]
trailer [58171,58188]
===
match
---
trailer [30620,30625]
trailer [30640,30645]
===
match
---
atom_expr [9810,9850]
atom_expr [9838,9878]
===
match
---
operator: , [74575,74576]
operator: , [74595,74596]
===
match
---
string: """Send alert email with exception information.""" [72463,72513]
string: """Send alert email with exception information.""" [72483,72533]
===
match
---
suite [12688,13233]
suite [12708,13253]
===
match
---
comparison [73929,73965]
comparison [73949,73985]
===
match
---
trailer [24095,24102]
trailer [24115,24122]
===
match
---
expr_stmt [72136,72189]
expr_stmt [72156,72209]
===
match
---
trailer [72077,72089]
trailer [72097,72109]
===
match
---
trailer [5381,5390]
trailer [5409,5418]
===
match
---
atom_expr [80280,80294]
atom_expr [80300,80314]
===
match
---
operator: = [37493,37494]
operator: = [37513,37514]
===
match
---
name: self [8494,8498]
name: self [8522,8526]
===
match
---
simple_stmt [19187,19218]
simple_stmt [19207,19238]
===
match
---
atom_expr [22036,22047]
atom_expr [22056,22067]
===
match
---
tfpdef [26479,26499]
tfpdef [26499,26519]
===
match
---
string: '' [61733,61735]
string: '' [61753,61755]
===
match
---
name: subject [72522,72529]
name: subject [72542,72549]
===
match
---
trailer [21506,21512]
trailer [21526,21532]
===
match
---
operator: = [44766,44767]
operator: = [44786,44787]
===
match
---
name: dep_status [32794,32804]
name: dep_status [32814,32824]
===
match
---
simple_stmt [53334,53366]
simple_stmt [53354,53386]
===
match
---
name: task_id [78883,78890]
name: task_id [78903,78910]
===
match
---
expr_stmt [72522,72605]
expr_stmt [72542,72625]
===
match
---
atom_expr [23543,23563]
atom_expr [23563,23583]
===
match
---
simple_stmt [13382,13530]
simple_stmt [13402,13550]
===
match
---
simple_stmt [1562,1591]
simple_stmt [1547,1576]
===
match
---
trailer [64836,64843]
trailer [64856,64863]
===
match
---
trailer [54617,54622]
trailer [54637,54642]
===
match
---
atom_expr [19688,19700]
atom_expr [19708,19720]
===
match
---
atom_expr [82606,82626]
atom_expr [82626,82646]
===
match
---
trailer [47609,47613]
trailer [47629,47633]
===
match
---
operator: , [59705,59706]
operator: , [59725,59726]
===
match
---
operator: = [41831,41832]
operator: = [41851,41852]
===
match
---
expr_stmt [80077,80104]
expr_stmt [80097,80124]
===
match
---
argument [54640,54655]
argument [54660,54675]
===
match
---
not_test [14630,14643]
not_test [14650,14663]
===
match
---
not_test [25961,25989]
not_test [25981,26009]
===
match
---
atom_expr [45415,45446]
atom_expr [45435,45466]
===
match
---
name: _try_number [22309,22320]
name: _try_number [22329,22340]
===
match
---
name: k [49356,49357]
name: k [49376,49377]
===
match
---
name: non_requeueable_dep_context [38170,38197]
name: non_requeueable_dep_context [38190,38217]
===
match
---
expr_stmt [11984,12020]
expr_stmt [12012,12048]
===
match
---
name: on_execute_callback [52125,52144]
name: on_execute_callback [52145,52164]
===
match
---
operator: = [28039,28040]
operator: = [28059,28060]
===
match
---
operator: = [10213,10214]
operator: = [10241,10242]
===
match
---
funcdef [32328,32950]
funcdef [32348,32970]
===
match
---
atom_expr [23850,23886]
atom_expr [23870,23906]
===
match
---
name: where [7233,7238]
name: where [7261,7266]
===
match
---
name: get_template_context [43029,43049]
name: get_template_context [43049,43069]
===
match
---
string: """         Clears all XCom data from the database for the task instance          :param session: SQLAlchemy ORM Session         :type session: Session         """ [23678,23841]
string: """         Clears all XCom data from the database for the task instance          :param session: SQLAlchemy ORM Session         :type session: Session         """ [23698,23861]
===
match
---
atom_expr [57162,57242]
atom_expr [57182,57262]
===
match
---
simple_stmt [40780,40818]
simple_stmt [40800,40838]
===
match
---
expr_stmt [68413,69022]
expr_stmt [68433,69042]
===
match
---
trailer [44323,44377]
trailer [44343,44397]
===
match
---
trailer [68648,68659]
trailer [68668,68679]
===
match
---
simple_stmt [80169,80209]
simple_stmt [80189,80229]
===
match
---
operator: = [15957,15958]
operator: = [15977,15978]
===
match
---
name: force_fail [59383,59393]
name: force_fail [59403,59413]
===
match
---
expr_stmt [22456,22483]
expr_stmt [22476,22503]
===
match
---
atom_expr [74123,74142]
atom_expr [74143,74162]
===
match
---
atom_expr [14963,14974]
atom_expr [14983,14994]
===
match
---
operator: , [76647,76648]
operator: , [76667,76668]
===
match
---
operator: = [56192,56193]
operator: = [56212,56213]
===
match
---
name: all [20488,20491]
name: all [20508,20511]
===
match
---
and_test [14785,14827]
and_test [14805,14847]
===
match
---
trailer [11943,11958]
trailer [11971,11986]
===
match
---
parameters [80611,80617]
parameters [80631,80637]
===
match
---
name: key [74209,74212]
name: key [74229,74232]
===
match
---
trailer [60380,60388]
trailer [60400,60408]
===
match
---
name: frame [48373,48378]
name: frame [48393,48398]
===
match
---
if_stmt [68165,68231]
if_stmt [68185,68251]
===
match
---
suite [72001,72045]
suite [72021,72065]
===
match
---
operator: = [52739,52740]
operator: = [52759,52760]
===
match
---
trailer [40607,40673]
trailer [40627,40693]
===
match
---
name: self [81283,81287]
name: self [81303,81307]
===
match
---
funcdef [69165,72416]
funcdef [69185,72436]
===
match
---
name: self [33060,33064]
name: self [33080,33084]
===
match
---
name: self [21976,21980]
name: self [21996,22000]
===
match
---
operator: = [5518,5519]
operator: = [5546,5547]
===
match
---
trailer [30923,30931]
trailer [30943,30951]
===
match
---
trailer [77612,77786]
trailer [77632,77806]
===
match
---
trailer [35509,35524]
trailer [35529,35544]
===
match
---
name: ti [22036,22038]
name: ti [22056,22058]
===
match
---
name: pool_slots [22585,22595]
name: pool_slots [22605,22615]
===
match
---
operator: , [1359,1360]
operator: , [1344,1345]
===
match
---
name: execution_date [76480,76494]
name: execution_date [76500,76514]
===
match
---
name: self [45415,45419]
name: self [45435,45439]
===
match
---
name: warn [28797,28801]
name: warn [28817,28821]
===
match
---
simple_stmt [76415,76436]
simple_stmt [76435,76456]
===
match
---
name: datetime [80775,80783]
name: datetime [80795,80803]
===
match
---
atom_expr [42829,42843]
atom_expr [42849,42863]
===
match
---
trailer [41505,41517]
trailer [41525,41537]
===
match
---
suite [44072,44215]
suite [44092,44235]
===
match
---
trailer [20421,20436]
trailer [20441,20456]
===
match
---
suite [25990,26015]
suite [26010,26035]
===
match
---
name: self [32276,32280]
name: self [32296,32300]
===
match
---
operator: -> [8156,8158]
operator: -> [8184,8186]
===
match
---
simple_stmt [19621,19849]
simple_stmt [19641,19869]
===
match
---
trailer [77363,77369]
trailer [77383,77389]
===
match
---
if_stmt [67418,67695]
if_stmt [67438,67715]
===
match
---
trailer [42758,42775]
trailer [42778,42795]
===
match
---
name: defaultdict [5122,5133]
name: defaultdict [5150,5161]
===
match
---
trailer [41867,41872]
trailer [41887,41892]
===
match
---
simple_stmt [50139,50176]
simple_stmt [50159,50196]
===
match
---
operator: , [10815,10816]
operator: , [10843,10844]
===
match
---
suite [7989,8799]
suite [8017,8827]
===
match
---
trailer [21512,21556]
trailer [21532,21576]
===
match
---
trailer [42904,42909]
trailer [42924,42929]
===
match
---
trailer [27285,27290]
trailer [27305,27310]
===
match
---
name: unixname [22461,22469]
name: unixname [22481,22489]
===
match
---
name: retries [23504,23511]
name: retries [23524,23531]
===
match
---
suite [52417,53366]
suite [52437,53386]
===
match
---
name: pool_override [37542,37555]
name: pool_override [37562,37575]
===
match
---
expr_stmt [12371,12387]
expr_stmt [12391,12407]
===
match
---
name: task [66598,66602]
name: task [66618,66622]
===
match
---
trailer [26066,26074]
trailer [26086,26094]
===
match
---
name: getLogger [11345,11354]
name: getLogger [11373,11382]
===
match
---
name: test_mode [37587,37596]
name: test_mode [37607,37616]
===
match
---
trailer [48945,48978]
trailer [48965,48998]
===
match
---
operator: , [79439,79440]
operator: , [79459,79460]
===
match
---
name: dag_id [76557,76563]
name: dag_id [76577,76583]
===
match
---
string: """Executes Task (optionally with a Timeout) and pushes Xcom results""" [51183,51254]
string: """Executes Task (optionally with a Timeout) and pushes Xcom results""" [51203,51274]
===
match
---
operator: , [55688,55689]
operator: , [55708,55709]
===
match
---
name: query [7629,7634]
name: query [7657,7662]
===
match
---
string: 'Host: {{ti.hostname}}<br>' [69941,69968]
string: 'Host: {{ti.hostname}}<br>' [69961,69988]
===
match
---
name: sanitize_for_serialization [69099,69125]
name: sanitize_for_serialization [69119,69145]
===
match
---
simple_stmt [52785,52814]
simple_stmt [52805,52834]
===
match
---
name: executor_config [23525,23540]
name: executor_config [23545,23560]
===
match
---
name: self [80766,80770]
name: self [80786,80790]
===
match
---
string: 'test_mode' [65676,65687]
string: 'test_mode' [65696,65707]
===
match
---
atom_expr [49605,49646]
atom_expr [49625,49666]
===
match
---
name: lazy_object_proxy [1183,1200]
name: lazy_object_proxy [1168,1185]
===
match
---
trailer [73995,74173]
trailer [74015,74193]
===
match
---
operator: , [32601,32602]
operator: , [32621,32622]
===
match
---
dictorsetmaker [7769,7800]
dictorsetmaker [7797,7828]
===
match
---
name: execution_date [78391,78405]
name: execution_date [78411,78425]
===
match
---
trailer [45372,45387]
trailer [45392,45407]
===
match
---
testlist_comp [66723,66761]
testlist_comp [66743,66781]
===
match
---
simple_stmt [1464,1507]
simple_stmt [1449,1492]
===
match
---
atom_expr [3923,3932]
atom_expr [3951,3960]
===
match
---
name: execution_date [15602,15616]
name: execution_date [15622,15636]
===
match
---
name: task_id [42941,42948]
name: task_id [42961,42968]
===
match
---
atom_expr [68392,68404]
atom_expr [68412,68424]
===
match
---
string: "Starting attempt %s of %s" [40608,40635]
string: "Starting attempt %s of %s" [40628,40655]
===
match
---
name: update [60224,60230]
name: update [60244,60250]
===
match
---
expr_stmt [22787,22804]
expr_stmt [22807,22824]
===
match
---
trailer [47409,47433]
trailer [47429,47453]
===
match
---
atom_expr [7769,7786]
atom_expr [7797,7814]
===
match
---
trailer [24127,24148]
trailer [24147,24168]
===
match
---
trailer [3202,3212]
trailer [3230,3240]
===
match
---
atom_expr [40401,40418]
atom_expr [40421,40438]
===
match
---
operator: , [72666,72667]
operator: , [72686,72687]
===
match
---
simple_stmt [11918,11975]
simple_stmt [11946,12003]
===
match
---
trailer [29663,29672]
trailer [29683,29692]
===
match
---
expr_stmt [66356,66441]
expr_stmt [66376,66461]
===
match
---
trailer [27787,27817]
trailer [27807,27837]
===
match
---
atom_expr [7742,7802]
atom_expr [7770,7830]
===
match
---
trailer [52377,52400]
trailer [52397,52420]
===
match
---
simple_stmt [44120,44196]
simple_stmt [44140,44216]
===
match
---
trailer [72594,72605]
trailer [72614,72625]
===
match
---
atom_expr [33663,33726]
atom_expr [33683,33746]
===
match
---
operator: = [46805,46806]
operator: = [46825,46826]
===
match
---
argument [54194,54213]
argument [54214,54233]
===
match
---
trailer [32638,32642]
trailer [32658,32662]
===
match
---
name: self [77431,77435]
name: self [77451,77455]
===
match
---
atom_expr [31716,31728]
atom_expr [31736,31748]
===
match
---
name: Optional [74593,74601]
name: Optional [74613,74621]
===
match
---
trailer [46338,46340]
trailer [46358,46360]
===
match
---
name: utils [2735,2740]
name: utils [2763,2768]
===
match
---
trailer [27817,27834]
trailer [27837,27854]
===
match
---
atom_expr [24673,24690]
atom_expr [24693,24710]
===
match
---
atom_expr [74533,74568]
atom_expr [74553,74588]
===
match
---
arglist [47619,47685]
arglist [47639,47705]
===
match
---
string: 'ti_pool' [10793,10802]
string: 'ti_pool' [10821,10830]
===
match
---
trailer [35068,35088]
trailer [35088,35108]
===
match
---
operator: = [54472,54473]
operator: = [54492,54493]
===
match
---
name: self [37673,37677]
name: self [37693,37697]
===
match
---
name: task [62456,62460]
name: task [62476,62480]
===
match
---
string: 'dag' [64633,64638]
string: 'dag' [64653,64658]
===
match
---
funcdef [35137,35599]
funcdef [35157,35619]
===
match
---
trailer [64787,64808]
trailer [64807,64828]
===
match
---
name: sql [1523,1526]
name: sql [1508,1511]
===
match
---
name: end_date [55332,55340]
name: end_date [55352,55360]
===
match
---
name: ti [22472,22474]
name: ti [22492,22494]
===
match
---
expr_stmt [67340,67409]
expr_stmt [67360,67429]
===
match
---
param [16012,16039]
param [16032,16059]
===
match
---
atom_expr [20355,20375]
atom_expr [20375,20395]
===
match
---
operator: , [53990,53991]
operator: , [54010,54011]
===
match
---
suite [18730,18779]
suite [18750,18799]
===
match
---
simple_stmt [80487,80515]
simple_stmt [80507,80535]
===
match
---
if_stmt [70509,72360]
if_stmt [70529,72380]
===
match
---
name: Exception [56484,56493]
name: Exception [56504,56513]
===
match
---
operator: ** [10405,10407]
operator: ** [10433,10435]
===
match
---
string: """         Return the try number that this task number will be when it is actually         run.          If the TaskInstance is currently running, this will match the column in the         database, in all other cases this will be incremented.         """ [12697,12953]
string: """         Return the try number that this task number will be when it is actually         run.          If the TaskInstance is currently running, this will match the column in the         database, in all other cases this will be incremented.         """ [12717,12973]
===
match
---
atom_expr [3539,3571]
atom_expr [3567,3599]
===
match
---
trailer [21579,21585]
trailer [21599,21605]
===
match
---
name: conf [19579,19583]
name: conf [19599,19603]
===
match
---
name: item [63549,63553]
name: item [63569,63573]
===
match
---
name: get_hostname [42829,42841]
name: get_hostname [42849,42861]
===
match
---
trailer [40795,40816]
trailer [40815,40836]
===
match
---
simple_stmt [31965,32170]
simple_stmt [31985,32190]
===
match
---
name: PodGenerator [68945,68957]
name: PodGenerator [68965,68977]
===
match
---
simple_stmt [61313,61355]
simple_stmt [61333,61375]
===
match
---
name: execution_date [78671,78685]
name: execution_date [78691,78705]
===
match
---
testlist_comp [10582,10870]
testlist_comp [10610,10898]
===
match
---
expr_stmt [49150,49229]
expr_stmt [49170,49249]
===
match
---
name: file_path [18767,18776]
name: file_path [18787,18796]
===
match
---
simple_stmt [7919,7953]
simple_stmt [7947,7981]
===
match
---
trailer [18746,18753]
trailer [18766,18773]
===
match
---
if_stmt [56788,56853]
if_stmt [56808,56873]
===
match
---
atom_expr [64349,64388]
atom_expr [64369,64408]
===
match
---
expr_stmt [68378,68404]
expr_stmt [68398,68424]
===
match
---
name: ignore_all_deps [39635,39650]
name: ignore_all_deps [39655,39670]
===
match
---
atom_expr [50919,50936]
atom_expr [50939,50956]
===
match
---
tfpdef [56242,56267]
tfpdef [56262,56287]
===
match
---
simple_stmt [53151,53168]
simple_stmt [53171,53188]
===
match
---
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [69884,69928]
string: 'Log: <a href="{{ti.log_url}}">Link</a><br>' [69904,69948]
===
match
---
atom_expr [21643,21654]
atom_expr [21663,21674]
===
match
---
trailer [14593,14597]
trailer [14613,14617]
===
match
---
simple_stmt [64033,64086]
simple_stmt [64053,64106]
===
match
---
atom_expr [62221,62257]
atom_expr [62241,62277]
===
match
---
name: str [29190,29193]
name: str [29210,29213]
===
match
---
simple_stmt [28788,29036]
simple_stmt [28808,29056]
===
match
---
not_test [40924,40937]
not_test [40944,40957]
===
match
---
trailer [74354,74369]
trailer [74374,74389]
===
match
---
trailer [7655,7662]
trailer [7683,7690]
===
match
---
operator: = [45087,45088]
operator: = [45107,45108]
===
match
---
operator: , [35750,35751]
operator: , [35770,35771]
===
match
---
name: airflow [82542,82549]
name: airflow [82562,82569]
===
match
---
trailer [12062,12071]
trailer [12090,12099]
===
match
---
simple_stmt [48717,48740]
simple_stmt [48737,48760]
===
match
---
return_stmt [13173,13196]
return_stmt [13193,13216]
===
match
---
suite [60200,60248]
suite [60220,60268]
===
match
---
atom_expr [9780,9790]
atom_expr [9808,9818]
===
match
---
name: content [72090,72097]
name: content [72110,72117]
===
match
---
param [24411,24416]
param [24431,24436]
===
match
---
arith_expr [60839,60873]
arith_expr [60859,60893]
===
match
---
expr_stmt [39148,39227]
expr_stmt [39168,39247]
===
match
---
atom_expr [45089,45106]
atom_expr [45109,45126]
===
match
---
trailer [41335,41389]
trailer [41355,41409]
===
match
---
name: self [39197,39201]
name: self [39217,39221]
===
match
---
fstring_string: . [48789,48790]
fstring_string: . [48809,48810]
===
match
---
decorator [45710,45727]
decorator [45730,45747]
===
match
---
operator: -> [53818,53820]
operator: -> [53838,53840]
===
match
---
name: get_failed_dep_statuses [31859,31882]
name: get_failed_dep_statuses [31879,31902]
===
match
---
name: session [59403,59410]
name: session [59423,59430]
===
match
---
operator: = [52650,52651]
operator: = [52670,52671]
===
match
---
parameters [19171,19177]
parameters [19191,19197]
===
match
---
simple_stmt [55906,55928]
simple_stmt [55926,55948]
===
match
---
name: test_mode [41740,41749]
name: test_mode [41760,41769]
===
match
---
atom_expr [55456,55703]
atom_expr [55476,55723]
===
match
---
trailer [24998,25007]
trailer [25018,25027]
===
match
---
suite [52987,53092]
suite [53007,53112]
===
match
---
atom_expr [52378,52399]
atom_expr [52398,52419]
===
match
---
operator: } [33019,33020]
operator: } [33039,33040]
===
match
---
expr_stmt [11325,11370]
expr_stmt [11353,11398]
===
match
---
name: mark_success [15047,15059]
name: mark_success [15067,15079]
===
match
---
name: XCom [77075,77079]
name: XCom [77095,77099]
===
match
---
atom_expr [26145,26195]
atom_expr [26165,26215]
===
match
---
tfpdef [36031,36050]
tfpdef [36051,36070]
===
match
---
atom_expr [32502,32518]
atom_expr [32522,32538]
===
match
---
name: task [47474,47478]
name: task [47494,47498]
===
match
---
arglist [58674,58701]
arglist [58694,58721]
===
match
---
name: state [40831,40836]
name: state [40851,40856]
===
match
---
operator: = [20660,20661]
operator: = [20680,20681]
===
match
---
operator: , [72441,72442]
operator: , [72461,72462]
===
match
---
name: e [67693,67694]
name: e [67713,67714]
===
match
---
simple_stmt [58344,58714]
simple_stmt [58364,58734]
===
match
---
atom_expr [32634,32869]
atom_expr [32654,32889]
===
match
---
name: _executor_config [81519,81535]
name: _executor_config [81539,81555]
===
match
---
simple_stmt [82402,82450]
simple_stmt [82422,82470]
===
match
---
atom_expr [41562,41592]
atom_expr [41582,41612]
===
match
---
trailer [71078,71083]
trailer [71098,71103]
===
match
---
name: State [57101,57106]
name: State [57121,57126]
===
match
---
simple_stmt [40382,40419]
simple_stmt [40402,40439]
===
match
---
trailer [20251,20265]
trailer [20271,20285]
===
match
---
trailer [56421,56431]
trailer [56441,56451]
===
match
---
name: var [62986,62989]
name: var [63006,63009]
===
match
---
funcdef [63936,64118]
funcdef [63956,64138]
===
match
---
suite [53138,53366]
suite [53158,53386]
===
match
---
trailer [49056,49063]
trailer [49076,49083]
===
match
---
simple_stmt [80337,80381]
simple_stmt [80357,80401]
===
match
---
name: from_string [71355,71366]
name: from_string [71375,71386]
===
match
---
trailer [43049,43051]
trailer [43069,43071]
===
match
---
name: upper [82433,82438]
name: upper [82453,82458]
===
match
---
simple_stmt [26812,26832]
simple_stmt [26832,26852]
===
match
---
name: ti [21821,21823]
name: ti [21841,21843]
===
match
---
operator: , [10833,10834]
operator: , [10861,10862]
===
match
---
name: default_html_content_err [70111,70135]
name: default_html_content_err [70131,70155]
===
match
---
name: pendulum [30321,30329]
name: pendulum [30341,30349]
===
match
---
name: Dict [1061,1065]
name: Dict [1046,1050]
===
match
---
trailer [58352,58357]
trailer [58372,58377]
===
match
---
trailer [24909,24922]
trailer [24929,24942]
===
match
---
trailer [55373,55386]
trailer [55393,55406]
===
match
---
and_test [27710,27753]
and_test [27730,27773]
===
match
---
trailer [35031,35037]
trailer [35051,35057]
===
match
---
argument [6838,6972]
argument [6866,7000]
===
match
---
expr_stmt [46628,46880]
expr_stmt [46648,46900]
===
match
---
name: State [57918,57923]
name: State [57938,57943]
===
match
---
simple_stmt [40435,40455]
simple_stmt [40455,40475]
===
match
---
name: orm [1425,1428]
name: orm [1410,1413]
===
match
---
name: render_k8s_pod_yaml [68291,68310]
name: render_k8s_pod_yaml [68311,68330]
===
match
---
name: test_mode [57062,57071]
name: test_mode [57082,57091]
===
match
---
suite [23669,24149]
suite [23689,24169]
===
match
---
operator: = [44348,44349]
operator: = [44368,44369]
===
match
---
name: self [24319,24323]
name: self [24339,24343]
===
match
---
name: conf [1625,1629]
name: conf [1610,1614]
===
match
---
arglist [38554,38624]
arglist [38574,38644]
===
match
---
raise_stmt [66785,67160]
raise_stmt [66805,67180]
===
match
---
name: pool_slots [23343,23353]
name: pool_slots [23363,23373]
===
match
---
and_test [30286,30358]
and_test [30306,30378]
===
match
---
fstring_string: / [19114,19115]
fstring_string: / [19134,19135]
===
match
---
dotted_name [2031,2054]
dotted_name [2016,2039]
===
match
---
name: String [9477,9483]
name: String [9505,9511]
===
match
---
atom_expr [41817,41830]
atom_expr [41837,41850]
===
match
---
trailer [7238,7250]
trailer [7266,7278]
===
match
---
arglist [72642,72680]
arglist [72662,72700]
===
match
---
name: result [51888,51894]
name: result [51908,51914]
===
match
---
name: self [56869,56873]
name: self [56889,56893]
===
match
---
trailer [55351,55358]
trailer [55371,55378]
===
match
---
trailer [39046,39057]
trailer [39066,39077]
===
match
---
name: _run_raw_task [54429,54442]
name: _run_raw_task [54449,54462]
===
match
---
atom_expr [68772,68815]
atom_expr [68792,68835]
===
match
---
trailer [42703,42729]
trailer [42723,42749]
===
match
---
name: get_task_instance [28000,28017]
name: get_task_instance [28020,28037]
===
match
---
trailer [57026,57031]
trailer [57046,57051]
===
match
---
operator: , [38476,38477]
operator: , [38496,38497]
===
match
---
name: exception [50148,50157]
name: exception [50168,50177]
===
match
---
trailer [26880,26897]
trailer [26900,26917]
===
match
---
atom_expr [80523,80532]
atom_expr [80543,80552]
===
match
---
atom_expr [77930,77953]
atom_expr [77950,77973]
===
match
---
suite [41164,41390]
suite [41184,41410]
===
match
---
trailer [6078,6093]
trailer [6106,6121]
===
match
---
name: incr [56963,56967]
name: incr [56983,56987]
===
match
---
trailer [37706,37715]
trailer [37726,37735]
===
match
---
trailer [24940,24949]
trailer [24960,24969]
===
match
---
argument [37643,37663]
argument [37663,37683]
===
match
---
expr_stmt [60527,60571]
expr_stmt [60547,60591]
===
match
---
name: task_id [45012,45019]
name: task_id [45032,45039]
===
match
---
name: self [72564,72568]
name: self [72584,72588]
===
match
---
operator: = [32373,32374]
operator: = [32393,32394]
===
match
---
trailer [6808,6998]
trailer [6836,7026]
===
match
---
import_from [1507,1560]
import_from [1492,1545]
===
match
---
name: debug [67907,67912]
name: debug [67927,67932]
===
match
---
name: self [31813,31817]
name: self [31833,31837]
===
match
---
name: pool [9988,9992]
name: pool [10016,10020]
===
match
---
arglist [62249,62256]
arglist [62269,62276]
===
match
---
string: 'BASE_LOG_FOLDER' [19054,19071]
string: 'BASE_LOG_FOLDER' [19074,19091]
===
match
---
name: XCom [2120,2124]
name: XCom [2105,2109]
===
match
---
operator: , [1824,1825]
operator: , [1809,1810]
===
match
---
arglist [68459,69012]
arglist [68479,69032]
===
match
---
suite [27964,28049]
suite [27984,28069]
===
match
---
name: merge [20953,20958]
name: merge [20973,20978]
===
match
---
name: context [52731,52738]
name: context [52751,52758]
===
match
---
name: task_id [18008,18015]
name: task_id [18028,18035]
===
match
---
funcdef [59466,59622]
funcdef [59486,59642]
===
match
---
trailer [60870,60873]
trailer [60890,60893]
===
match
---
trailer [37535,37561]
trailer [37555,37581]
===
match
---
string: """         The start date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29865,30076]
string: """         The start date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29885,30096]
===
match
---
atom_expr [61281,61300]
atom_expr [61301,61320]
===
match
---
name: replace [62224,62231]
name: replace [62244,62251]
===
match
---
trailer [18069,18089]
trailer [18089,18109]
===
match
---
name: ti [6037,6039]
name: ti [6065,6067]
===
match
---
name: yesterday_ds [66090,66102]
name: yesterday_ds [66110,66122]
===
match
---
name: task_id [62421,62428]
name: task_id [62441,62448]
===
match
---
funcdef [63278,63580]
funcdef [63298,63600]
===
match
---
atom_expr [57905,57915]
atom_expr [57925,57935]
===
match
---
simple_stmt [68413,69023]
simple_stmt [68433,69043]
===
match
---
suite [35183,35599]
suite [35203,35619]
===
match
---
trailer [23503,23511]
trailer [23523,23531]
===
match
---
expr_stmt [71326,71416]
expr_stmt [71346,71436]
===
match
---
name: incr [50694,50698]
name: incr [50714,50718]
===
match
---
operator: = [29022,29023]
operator: = [29042,29043]
===
match
---
operator: = [46183,46184]
operator: = [46203,46204]
===
match
---
simple_stmt [14892,14904]
simple_stmt [14912,14924]
===
match
---
name: TaskInstance [78807,78819]
name: TaskInstance [78827,78839]
===
match
---
operator: = [53599,53600]
operator: = [53619,53620]
===
match
---
parameters [68310,68316]
parameters [68330,68336]
===
match
---
name: dep_context [32502,32513]
name: dep_context [32522,32533]
===
match
---
return_stmt [64102,64117]
return_stmt [64122,64137]
===
match
---
atom_expr [80714,80727]
atom_expr [80734,80747]
===
match
---
trailer [23914,23921]
trailer [23934,23941]
===
match
---
simple_stmt [56512,56561]
simple_stmt [56532,56581]
===
match
---
expr_stmt [22647,22688]
expr_stmt [22667,22708]
===
match
---
trailer [49973,49977]
trailer [49993,49997]
===
match
---
name: log [40040,40043]
name: log [40060,40063]
===
match
---
trailer [82353,82359]
trailer [82373,82379]
===
match
---
parameters [25440,25460]
parameters [25460,25480]
===
match
---
name: executor_config [81476,81491]
name: executor_config [81496,81511]
===
match
---
operator: , [10602,10603]
operator: , [10630,10631]
===
match
---
name: filter [77606,77612]
name: filter [77626,77632]
===
match
---
atom_expr [25068,25087]
atom_expr [25088,25107]
===
match
---
operator: , [63973,63974]
operator: , [63993,63994]
===
match
---
trailer [62366,62375]
trailer [62386,62395]
===
match
---
simple_stmt [69464,69518]
simple_stmt [69484,69538]
===
match
---
fstring_expr [19386,19400]
fstring_expr [19406,19420]
===
match
---
tfpdef [41740,41755]
tfpdef [41760,41775]
===
match
---
or_test [27644,27694]
or_test [27664,27714]
===
match
---
atom_expr [47459,47478]
atom_expr [47479,47498]
===
match
---
simple_stmt [71501,71767]
simple_stmt [71521,71787]
===
match
---
atom_expr [41256,41265]
atom_expr [41276,41285]
===
match
---
name: min_backoff [34157,34168]
name: min_backoff [34177,34188]
===
match
---
name: provide_session [55100,55115]
name: provide_session [55120,55135]
===
match
---
trailer [77079,77085]
trailer [77099,77105]
===
match
---
operator: , [80402,80403]
operator: , [80422,80423]
===
match
---
operator: , [70950,70951]
operator: , [70970,70971]
===
match
---
operator: , [8600,8601]
operator: , [8628,8629]
===
match
---
name: task [72736,72740]
name: task [72756,72760]
===
match
---
name: func [77579,77583]
name: func [77599,77603]
===
match
---
trailer [27347,27351]
trailer [27367,27371]
===
match
---
operator: = [71343,71344]
operator: = [71363,71364]
===
match
---
expr_stmt [21882,21898]
expr_stmt [21902,21918]
===
match
---
operator: = [43207,43208]
operator: = [43227,43228]
===
match
---
trailer [29581,29597]
trailer [29601,29617]
===
match
---
trailer [45535,45558]
trailer [45555,45578]
===
match
---
name: task_id [23996,24003]
name: task_id [24016,24023]
===
match
---
trailer [32587,32615]
trailer [32607,32635]
===
match
---
param [35730,35751]
param [35750,35771]
===
match
---
atom [17972,18021]
atom [17992,18041]
===
match
---
name: datetime [80000,80008]
name: datetime [80020,80028]
===
match
---
atom_expr [32100,32119]
atom_expr [32120,32139]
===
match
---
operator: , [79373,79374]
operator: , [79393,79394]
===
match
---
simple_stmt [9988,10031]
simple_stmt [10016,10059]
===
match
---
trailer [40485,40487]
trailer [40505,40507]
===
match
---
suite [66645,67161]
suite [66665,67181]
===
match
---
arglist [10634,10671]
arglist [10662,10699]
===
match
---
name: execution_date [60708,60722]
name: execution_date [60728,60742]
===
match
---
name: context [52145,52152]
name: context [52165,52172]
===
match
---
operator: = [41795,41796]
operator: = [41815,41816]
===
match
---
atom_expr [77277,77287]
atom_expr [77297,77307]
===
match
---
simple_stmt [1217,1275]
simple_stmt [1202,1260]
===
match
---
suite [48415,48589]
suite [48435,48609]
===
match
---
name: self [63884,63888]
name: self [63904,63908]
===
match
---
name: task_id [8757,8764]
name: task_id [8785,8792]
===
match
---
operator: = [27783,27784]
operator: = [27803,27804]
===
match
---
name: State [54730,54735]
name: State [54750,54755]
===
match
---
name: delay [33673,33678]
name: delay [33693,33698]
===
match
---
name: dag_run [60339,60346]
name: dag_run [60359,60366]
===
match
---
name: _Variable__NO_DEFAULT_SENTINEL [63409,63439]
name: _Variable__NO_DEFAULT_SENTINEL [63429,63459]
===
match
---
classdef [8801,79491]
classdef [8829,79511]
===
match
---
suite [67443,67695]
suite [67463,67715]
===
match
---
return_stmt [34824,34852]
return_stmt [34844,34872]
===
match
---
name: e [49946,49947]
name: e [49966,49967]
===
match
---
atom_expr [47605,47686]
atom_expr [47625,47706]
===
match
---
trailer [48618,48626]
trailer [48638,48646]
===
match
---
operator: @ [45731,45732]
operator: @ [45751,45752]
===
match
---
trailer [51860,51895]
trailer [51880,51915]
===
match
---
fstring [32990,33074]
fstring [33010,33094]
===
match
---
name: Optional [78054,78062]
name: Optional [78074,78082]
===
match
---
expr_stmt [39284,39328]
expr_stmt [39304,39348]
===
match
---
suite [67460,67524]
suite [67480,67544]
===
match
---
name: ignore_all_deps [37749,37764]
name: ignore_all_deps [37769,37784]
===
match
---
fstring_start: f" [19676,19678]
fstring_start: f" [19696,19698]
===
match
---
atom_expr [5938,5950]
atom_expr [5966,5978]
===
match
---
name: TaskInstance [78760,78772]
name: TaskInstance [78780,78792]
===
match
---
operator: , [50592,50593]
operator: , [50612,50613]
===
match
---
name: jinja2 [1222,1228]
name: jinja2 [1207,1213]
===
match
---
atom_expr [79391,79418]
atom_expr [79411,79438]
===
match
---
atom_expr [3641,3663]
atom_expr [3669,3691]
===
match
---
suite [44433,44801]
suite [44453,44821]
===
match
---
name: self [60759,60763]
name: self [60779,60783]
===
match
---
operator: = [10143,10144]
operator: = [10171,10172]
===
match
---
operator: = [81603,81604]
operator: = [81623,81624]
===
match
---
name: property [28076,28084]
name: property [28096,28104]
===
match
---
funcdef [59111,59461]
funcdef [59131,59481]
===
match
---
atom_expr [79855,79865]
atom_expr [79875,79885]
===
match
---
atom [77137,77183]
atom [77157,77203]
===
match
---
atom_expr [45600,45616]
atom_expr [45620,45636]
===
match
---
name: dates [7076,7081]
name: dates [7104,7109]
===
match
---
name: TaskInstance [21668,21680]
name: TaskInstance [21688,21700]
===
match
---
name: ti [82377,82379]
name: ti [82397,82399]
===
match
---
name: dag_run [64673,64680]
name: dag_run [64693,64700]
===
match
---
name: dag_id [78648,78654]
name: dag_id [78668,78674]
===
match
---
comparison [47146,47190]
comparison [47166,47210]
===
match
---
simple_stmt [32933,32950]
simple_stmt [32953,32970]
===
match
---
atom_expr [58975,59000]
atom_expr [58995,59020]
===
match
---
name: Integer [10291,10298]
name: Integer [10319,10326]
===
match
---
name: state [27923,27928]
name: state [27943,27948]
===
match
---
name: self [8277,8281]
name: self [8305,8309]
===
match
---
name: session [46990,46997]
name: session [47010,47017]
===
match
---
trailer [23360,23371]
trailer [23380,23391]
===
match
---
trailer [41825,41830]
trailer [41845,41850]
===
match
---
atom_expr [68012,68024]
atom_expr [68032,68044]
===
match
---
expr_stmt [79933,79975]
expr_stmt [79953,79995]
===
match
---
funcdef [74436,77370]
funcdef [74456,77390]
===
match
---
param [72437,72442]
param [72457,72462]
===
match
---
name: next_ds [64898,64905]
name: next_ds [64918,64925]
===
match
---
operator: } [7722,7723]
operator: } [7750,7751]
===
match
---
decorated [73083,74410]
decorated [73103,74430]
===
match
---
name: sqlalchemy [1469,1479]
name: sqlalchemy [1454,1464]
===
match
---
arglist [72731,72773]
arglist [72751,72793]
===
match
---
simple_stmt [81276,81305]
simple_stmt [81296,81325]
===
match
---
try_stmt [66658,67161]
try_stmt [66678,67181]
===
match
---
name: next_execution_date [61789,61808]
name: next_execution_date [61809,61828]
===
match
---
name: property [81073,81081]
name: property [81093,81101]
===
match
---
param [4713,4717]
param [4741,4745]
===
match
---
trailer [66043,66045]
trailer [66063,66065]
===
match
---
name: dispose [41119,41126]
name: dispose [41139,41146]
===
match
---
import_from [45926,45966]
import_from [45946,45986]
===
match
---
expr_stmt [20219,20503]
expr_stmt [20239,20523]
===
match
---
trailer [50980,50987]
trailer [51000,51007]
===
match
---
simple_stmt [4050,4067]
simple_stmt [4078,4095]
===
match
---
dotted_name [2610,2640]
dotted_name [2595,2625]
===
match
---
parameters [19892,19912]
parameters [19912,19932]
===
match
---
operator: { [19687,19688]
operator: { [19707,19708]
===
match
---
suite [81498,81536]
suite [81518,81556]
===
match
---
suite [76923,77224]
suite [76943,77244]
===
match
---
atom_expr [35093,35110]
atom_expr [35113,35130]
===
match
---
name: duration [73068,73076]
name: duration [73088,73096]
===
match
---
name: str [4281,4284]
name: str [4309,4312]
===
match
---
not_test [4074,4082]
not_test [4102,4110]
===
match
---
argument [51525,51540]
argument [51545,51560]
===
match
---
operator: , [30184,30185]
operator: , [30204,30205]
===
match
---
operator: , [74212,74213]
operator: , [74232,74233]
===
match
---
argument [74383,74398]
argument [74403,74418]
===
match
---
trailer [23858,23864]
trailer [23878,23884]
===
match
---
name: str [15991,15994]
name: str [16011,16014]
===
match
---
name: context [3563,3570]
name: context [3591,3598]
===
match
---
simple_stmt [52918,52935]
simple_stmt [52938,52955]
===
match
---
suite [11724,11818]
suite [11752,11846]
===
match
---
argument [39916,39928]
argument [39936,39948]
===
match
---
trailer [8268,8275]
trailer [8296,8303]
===
match
---
trailer [34640,34642]
trailer [34660,34662]
===
match
---
name: task [68245,68249]
name: task [68265,68269]
===
match
---
string: "--ignore-dependencies" [18369,18392]
string: "--ignore-dependencies" [18389,18412]
===
match
---
funcdef [24397,25088]
funcdef [24417,25108]
===
match
---
dotted_name [2882,2910]
dotted_name [2910,2938]
===
match
---
trailer [28022,28030]
trailer [28042,28050]
===
match
---
operator: , [74551,74552]
operator: , [74571,74572]
===
match
---
operator: = [17970,17971]
operator: = [17990,17991]
===
match
---
name: value [77080,77085]
name: value [77100,77105]
===
match
---
name: Optional [1095,1103]
name: Optional [1080,1088]
===
match
---
trailer [69503,69517]
trailer [69523,69537]
===
match
---
atom_expr [48502,48521]
atom_expr [48522,48541]
===
match
---
name: get_dep_statuses [32571,32587]
name: get_dep_statuses [32591,32607]
===
match
---
name: execution_date [61286,61300]
name: execution_date [61306,61320]
===
match
---
operator: { [44992,44993]
operator: { [45012,45013]
===
match
---
arglist [43114,43127]
arglist [43134,43147]
===
match
---
trailer [79964,79975]
trailer [79984,79995]
===
match
---
trailer [68720,68736]
trailer [68740,68756]
===
match
---
trailer [69495,69503]
trailer [69515,69523]
===
match
---
name: str [3952,3955]
name: str [3980,3983]
===
match
---
arglist [49197,49228]
arglist [49217,49248]
===
match
---
decorated [26423,28070]
decorated [26443,28090]
===
match
---
simple_stmt [47545,47589]
simple_stmt [47565,47609]
===
match
---
operator: = [76585,76586]
operator: = [76605,76606]
===
match
---
operator: , [64808,64809]
operator: , [64828,64829]
===
match
---
atom_expr [52741,52768]
atom_expr [52761,52788]
===
match
---
operator: { [7768,7769]
operator: { [7796,7797]
===
match
---
name: downstream_task_ids [26175,26194]
name: downstream_task_ids [26195,26214]
===
match
---
funcdef [54862,55094]
funcdef [54882,55114]
===
match
---
name: task [52078,52082]
name: task [52098,52102]
===
match
---
operator: , [10869,10870]
operator: , [10897,10898]
===
match
---
trailer [33678,33692]
trailer [33698,33712]
===
match
---
suite [32912,32950]
suite [32932,32970]
===
match
---
suite [5321,6041]
suite [5349,6069]
===
match
---
param [81402,81406]
param [81422,81426]
===
match
---
operator: , [44336,44337]
operator: , [44356,44357]
===
match
---
name: Index [10716,10721]
name: Index [10744,10749]
===
match
---
param [81334,81338]
param [81354,81358]
===
match
---
operator: @ [59807,59808]
operator: @ [59827,59828]
===
match
---
expr_stmt [27345,27357]
expr_stmt [27365,27377]
===
match
---
operator: , [79219,79220]
operator: , [79239,79240]
===
match
---
simple_stmt [44681,44688]
simple_stmt [44701,44708]
===
match
---
comparison [77630,77664]
comparison [77650,77684]
===
match
---
name: ti [48946,48948]
name: ti [48966,48968]
===
match
---
trailer [9911,9917]
trailer [9939,9945]
===
match
---
decorated [12468,12648]
decorated [12488,12668]
===
match
---
name: task [37488,37492]
name: task [37508,37512]
===
match
---
atom_expr [77630,77649]
atom_expr [77650,77669]
===
match
---
name: task [52645,52649]
name: task [52665,52669]
===
match
---
name: dag_id [48782,48788]
name: dag_id [48802,48808]
===
match
---
simple_stmt [80793,80821]
simple_stmt [80813,80841]
===
match
---
name: log [41327,41330]
name: log [41347,41350]
===
match
---
trailer [62524,62535]
trailer [62544,62555]
===
match
---
trailer [29262,29271]
trailer [29282,29291]
===
match
---
atom_expr [45836,45912]
atom_expr [45856,45932]
===
match
---
name: self [47605,47609]
name: self [47625,47629]
===
match
---
arglist [3743,3882]
arglist [3771,3910]
===
match
---
operator: = [55214,55215]
operator: = [55234,55235]
===
match
---
name: filepath [14713,14721]
name: filepath [14733,14741]
===
match
---
name: xcom_push [51851,51860]
name: xcom_push [51871,51880]
===
match
---
name: self [22456,22460]
name: self [22476,22480]
===
match
---
operator: = [15447,15448]
operator: = [15467,15468]
===
match
---
arith_expr [60759,60793]
arith_expr [60779,60813]
===
match
---
funcdef [59828,66170]
funcdef [59848,66190]
===
match
---
trailer [26042,26076]
trailer [26062,26096]
===
match
---
trailer [14949,15467]
trailer [14969,15487]
===
match
---
operator: , [26327,26328]
operator: , [26347,26348]
===
match
---
atom_expr [55621,55634]
atom_expr [55641,55654]
===
match
---
atom_expr [40035,40317]
atom_expr [40055,40337]
===
match
---
operator: = [22580,22581]
operator: = [22600,22601]
===
match
---
arglist [44324,44376]
arglist [44344,44396]
===
match
---
name: state [9765,9770]
name: state [9793,9798]
===
match
---
name: self [8752,8756]
name: self [8780,8784]
===
match
---
name: raw [15368,15371]
name: raw [15388,15391]
===
match
---
name: session [59859,59866]
name: session [59879,59886]
===
match
---
trailer [40686,40690]
trailer [40706,40710]
===
match
---
name: state [43597,43602]
name: state [43617,43622]
===
match
---
name: VariableAccessor [62677,62693]
name: VariableAccessor [62697,62713]
===
match
---
expr_stmt [3168,3187]
expr_stmt [3196,3215]
===
match
---
try_stmt [58769,59001]
try_stmt [58789,59021]
===
match
---
name: self [53447,53451]
name: self [53467,53471]
===
match
---
trailer [23864,23886]
trailer [23884,23906]
===
match
---
simple_stmt [14379,14570]
simple_stmt [14399,14590]
===
match
---
operator: , [44897,44898]
operator: , [44917,44918]
===
match
---
simple_stmt [9796,9851]
simple_stmt [9824,9879]
===
match
---
name: self [12504,12508]
name: self [12524,12528]
===
match
---
simple_stmt [1630,1828]
simple_stmt [1615,1813]
===
match
---
name: self [12058,12062]
name: self [12086,12090]
===
match
---
string: "/success" [19653,19663]
string: "/success" [19673,19683]
===
match
---
name: DagRun [82619,82625]
name: DagRun [82639,82645]
===
match
---
atom_expr [55343,55360]
atom_expr [55363,55380]
===
match
---
trailer [60707,60722]
trailer [60727,60742]
===
match
---
name: state [30173,30178]
name: state [30193,30198]
===
match
---
trailer [65334,65355]
trailer [65354,65375]
===
match
---
atom_expr [52078,52102]
atom_expr [52098,52122]
===
match
---
annassign [8047,8052]
annassign [8075,8080]
===
match
---
suite [4422,4458]
suite [4450,4486]
===
match
---
lambdef [65451,65508]
lambdef [65471,65528]
===
match
---
name: timezone [35093,35101]
name: timezone [35113,35121]
===
match
---
argument [9583,9599]
argument [9611,9627]
===
match
---
string: 'start_date' [58614,58626]
string: 'start_date' [58634,58646]
===
match
---
param [53461,53482]
param [53481,53502]
===
match
---
name: task_copy [51163,51172]
name: task_copy [51183,51192]
===
match
---
return_stmt [78731,78933]
return_stmt [78751,78953]
===
match
---
operator: = [80202,80203]
operator: = [80222,80223]
===
match
---
simple_stmt [57905,57931]
simple_stmt [57925,57951]
===
match
---
name: verbose_aware_logger [32224,32244]
name: verbose_aware_logger [32244,32264]
===
match
---
argument [54598,54622]
argument [54618,54642]
===
match
---
parameters [54873,54879]
parameters [54893,54899]
===
match
---
trailer [53356,53365]
trailer [53376,53385]
===
match
---
name: actual_start_date [42853,42870]
name: actual_start_date [42873,42890]
===
match
---
name: dag [14709,14712]
name: dag [14729,14732]
===
match
---
name: jinja2 [1169,1175]
name: jinja2 [1154,1160]
===
match
---
trailer [40865,40869]
trailer [40885,40889]
===
match
---
name: os [40872,40874]
name: os [40892,40894]
===
match
---
name: self [59607,59611]
name: self [59627,59631]
===
match
---
trailer [4059,4064]
trailer [4087,4092]
===
match
---
name: state [53110,53115]
name: state [53130,53135]
===
match
---
expr_stmt [17966,18021]
expr_stmt [17986,18041]
===
match
---
operator: , [74398,74399]
operator: , [74418,74419]
===
match
---
name: Tuple [79590,79595]
name: Tuple [79610,79615]
===
match
---
name: cmd [18687,18690]
name: cmd [18707,18710]
===
match
---
atom_expr [5378,5399]
atom_expr [5406,5427]
===
match
---
name: kube_config [68378,68389]
name: kube_config [68398,68409]
===
match
---
name: TaskInstance [82583,82595]
name: TaskInstance [82603,82615]
===
match
---
expr_stmt [21976,22007]
expr_stmt [21996,22027]
===
match
---
name: dag_id [43799,43805]
name: dag_id [43819,43825]
===
match
---
name: jinja_env [71345,71354]
name: jinja_env [71365,71374]
===
match
---
name: cfg_path [15439,15447]
name: cfg_path [15459,15467]
===
match
---
name: self [40035,40039]
name: self [40055,40059]
===
match
---
simple_stmt [18857,18868]
simple_stmt [18877,18888]
===
match
---
operator: , [65821,65822]
operator: , [65841,65842]
===
match
---
trailer [76984,77002]
trailer [77004,77022]
===
match
---
param [14085,14104]
param [14105,14124]
===
match
---
operator: = [74208,74209]
operator: = [74228,74229]
===
match
---
name: self [11227,11231]
name: self [11255,11259]
===
match
---
name: execution_date [19532,19546]
name: execution_date [19552,19566]
===
match
---
operator: = [68417,68418]
operator: = [68437,68438]
===
match
---
funcdef [13342,13879]
funcdef [13362,13899]
===
match
---
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [70029,70091]
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [70049,70111]
===
match
---
trailer [15990,15995]
trailer [16010,16015]
===
match
---
expr_stmt [53151,53167]
expr_stmt [53171,53187]
===
match
---
operator: = [43177,43178]
operator: = [43197,43198]
===
match
---
atom_expr [22113,22121]
atom_expr [22133,22141]
===
match
---
arglist [62232,62239]
arglist [62252,62259]
===
match
---
name: init_run_context [77828,77844]
name: init_run_context [77848,77864]
===
match
---
atom_expr [71052,71102]
atom_expr [71072,71122]
===
match
---
atom_expr [38200,38491]
atom_expr [38220,38511]
===
match
---
name: session [39203,39210]
name: session [39223,39230]
===
match
---
name: self [61513,61517]
name: self [61533,61537]
===
match
---
decorated [8124,8311]
decorated [8152,8339]
===
match
---
name: execution_date [8526,8540]
name: execution_date [8554,8568]
===
match
---
argument [46743,46767]
argument [46763,46787]
===
match
---
except_clause [3126,3144]
except_clause [3154,3172]
===
match
---
name: ignore_ti_state [15237,15252]
name: ignore_ti_state [15257,15272]
===
match
---
name: operator [22720,22728]
name: operator [22740,22748]
===
match
---
decorated [81210,81305]
decorated [81230,81325]
===
match
---
name: commit [59076,59082]
name: commit [59096,59102]
===
match
---
trailer [41789,41794]
trailer [41809,41814]
===
match
---
name: self [54944,54948]
name: self [54964,54968]
===
match
---
name: first [78430,78435]
name: first [78450,78455]
===
match
---
operator: , [58584,58585]
operator: , [58604,58605]
===
match
---
name: xcom [77312,77316]
name: xcom [77332,77336]
===
match
---
name: query [20246,20251]
name: query [20266,20271]
===
match
---
trailer [53162,53167]
trailer [53182,53187]
===
match
---
argument [39619,39650]
argument [39639,39670]
===
match
---
operator: = [53156,53157]
operator: = [53176,53177]
===
match
---
name: execution_date [11497,11511]
name: execution_date [11525,11539]
===
match
---
name: extend [18634,18640]
name: extend [18654,18660]
===
match
---
if_stmt [41153,41390]
if_stmt [41173,41410]
===
match
---
trailer [26549,26565]
trailer [26569,26585]
===
match
---
operator: , [32274,32275]
operator: , [32294,32295]
===
match
---
number: 256 [10009,10012]
number: 256 [10037,10040]
===
match
---
parameters [68051,68092]
parameters [68071,68112]
===
match
---
name: utils [2428,2433]
name: utils [2413,2418]
===
match
---
name: pool [54571,54575]
name: pool [54591,54595]
===
match
---
trailer [8743,8750]
trailer [8771,8778]
===
match
---
atom_expr [10183,10195]
atom_expr [10211,10223]
===
match
---
atom_expr [35041,35059]
atom_expr [35061,35079]
===
match
---
operator: = [31945,31946]
operator: = [31965,31966]
===
match
---
power [33698,33724]
power [33718,33744]
===
match
---
name: state [10700,10705]
name: state [10728,10733]
===
match
---
name: task [34732,34736]
name: task [34752,34756]
===
match
---
param [14290,14300]
param [14310,14320]
===
match
---
atom_expr [60703,60734]
atom_expr [60723,60754]
===
match
---
name: Exception [72697,72706]
name: Exception [72717,72726]
===
match
---
expr_stmt [27771,27834]
expr_stmt [27791,27854]
===
match
---
parameters [13366,13372]
parameters [13386,13392]
===
match
---
operator: , [43805,43806]
operator: , [43825,43826]
===
match
---
name: bool [35971,35975]
name: bool [35991,35995]
===
match
---
name: SUCCESS [65500,65507]
name: SUCCESS [65520,65527]
===
match
---
suite [51833,51896]
suite [51853,51916]
===
match
---
yield_expr [3589,3602]
yield_expr [3617,3630]
===
match
---
name: airflow [1635,1642]
name: airflow [1620,1627]
===
match
---
tfpdef [64252,64261]
tfpdef [64272,64281]
===
match
---
name: client [2893,2899]
name: client [2921,2927]
===
match
---
name: pickle [879,885]
name: pickle [864,870]
===
match
---
atom_expr [41369,41388]
atom_expr [41389,41408]
===
match
---
name: _priority_weight [80342,80358]
name: _priority_weight [80362,80378]
===
match
---
trailer [56140,56156]
trailer [56160,56176]
===
match
---
not_test [57058,57071]
not_test [57078,57091]
===
match
---
operator: , [10988,10989]
operator: , [11016,11017]
===
match
---
name: task_id [5347,5354]
name: task_id [5375,5382]
===
match
---
trailer [55046,55063]
trailer [55066,55083]
===
match
---
atom_expr [42922,42933]
atom_expr [42942,42953]
===
match
---
trailer [10001,10030]
trailer [10029,10058]
===
match
---
name: next_ds_nodash [61695,61709]
name: next_ds_nodash [61715,61729]
===
match
---
name: session [50945,50952]
name: session [50965,50972]
===
match
---
operator: == [79419,79421]
operator: == [79439,79441]
===
match
---
return_stmt [19082,19140]
return_stmt [19102,19160]
===
match
---
operator: , [13280,13281]
operator: , [13300,13301]
===
match
---
name: raw [15947,15950]
name: raw [15967,15970]
===
match
---
name: Optional [36037,36045]
name: Optional [36057,36065]
===
match
---
trailer [8498,8505]
trailer [8526,8533]
===
match
---
param [48373,48378]
param [48393,48398]
===
match
---
name: log [67903,67906]
name: log [67923,67926]
===
match
---
tfpdef [41847,41872]
tfpdef [41867,41892]
===
match
---
if_stmt [11701,11905]
if_stmt [11729,11933]
===
match
---
name: test_mode [45633,45642]
name: test_mode [45653,45662]
===
match
---
name: state [24783,24788]
name: state [24803,24808]
===
match
---
param [15711,15748]
param [15731,15768]
===
match
---
operator: , [54240,54241]
operator: , [54260,54261]
===
match
---
name: pool [41811,41815]
name: pool [41831,41835]
===
match
---
trailer [55972,55979]
trailer [55992,55999]
===
match
---
name: dag_id [78353,78359]
name: dag_id [78373,78379]
===
match
---
simple_stmt [71930,71960]
simple_stmt [71950,71980]
===
match
---
name: Optional [68320,68328]
name: Optional [68340,68348]
===
match
---
name: self [80487,80491]
name: self [80507,80511]
===
match
---
name: api_client [2900,2910]
name: api_client [2928,2938]
===
match
---
simple_stmt [20847,20903]
simple_stmt [20867,20923]
===
match
---
atom_expr [3232,3245]
atom_expr [3260,3273]
===
match
---
name: dag_id [14968,14974]
name: dag_id [14988,14994]
===
match
---
param [68052,68057]
param [68072,68077]
===
match
---
name: log [73026,73029]
name: log [73046,73049]
===
match
---
funcdef [13898,13999]
funcdef [13918,14019]
===
match
---
tfpdef [77996,78049]
tfpdef [78016,78069]
===
match
---
operator: , [64843,64844]
operator: , [64863,64864]
===
match
---
operator: { [48771,48772]
operator: { [48791,48792]
===
match
---
tfpdef [56208,56224]
tfpdef [56228,56244]
===
match
---
simple_stmt [53004,53042]
simple_stmt [53024,53062]
===
match
---
operator: , [64388,64389]
operator: , [64408,64409]
===
match
---
trailer [64518,64522]
trailer [64538,64542]
===
match
---
name: self [33346,33350]
name: self [33366,33370]
===
match
---
operator: = [72034,72035]
operator: = [72054,72055]
===
match
---
operator: = [56268,56269]
operator: = [56288,56289]
===
match
---
name: UP_FOR_RESCHEDULE [55762,55779]
name: UP_FOR_RESCHEDULE [55782,55799]
===
match
---
operator: , [35835,35836]
operator: , [35855,35856]
===
match
---
trailer [38663,38670]
trailer [38683,38690]
===
match
---
fstring_end: " [19421,19422]
fstring_end: " [19441,19442]
===
match
---
name: sqlalchemy [1370,1380]
name: sqlalchemy [1355,1365]
===
match
---
atom_expr [59318,59411]
atom_expr [59338,59431]
===
match
---
name: get_hostname [37718,37730]
name: get_hostname [37738,37750]
===
match
---
expr_stmt [45073,45106]
expr_stmt [45093,45126]
===
match
---
atom_expr [5282,5307]
atom_expr [5310,5335]
===
match
---
operator: , [41367,41368]
operator: , [41387,41388]
===
match
---
name: self [71460,71464]
name: self [71480,71484]
===
match
---
funcdef [3899,4248]
funcdef [3927,4276]
===
match
---
name: task_type [56994,57003]
name: task_type [57014,57023]
===
match
---
operator: , [8750,8751]
operator: , [8778,8779]
===
match
---
atom_expr [44085,44107]
atom_expr [44105,44127]
===
match
---
atom_expr [54944,54953]
atom_expr [54964,54973]
===
match
---
trailer [24310,24317]
trailer [24330,24337]
===
match
---
arglist [37626,37663]
arglist [37646,37683]
===
match
---
operator: , [71102,71103]
operator: , [71122,71123]
===
match
---
for_stmt [66496,66632]
for_stmt [66516,66652]
===
match
---
name: exception [72443,72452]
name: exception [72463,72472]
===
match
---
name: TaskInstanceKey [7961,7976]
name: TaskInstanceKey [7989,8004]
===
match
---
operator: @ [13238,13239]
operator: @ [13258,13259]
===
match
---
name: update [49434,49440]
name: update [49454,49460]
===
match
---
argument [28492,28504]
argument [28512,28524]
===
match
---
trailer [26822,26827]
trailer [26842,26847]
===
match
---
operator: = [70837,70838]
operator: = [70857,70858]
===
match
---
simple_stmt [44446,44469]
simple_stmt [44466,44489]
===
match
---
operator: = [5998,5999]
operator: = [6026,6027]
===
match
---
name: post_execute [50564,50576]
name: post_execute [50584,50596]
===
match
---
expr_stmt [78368,78405]
expr_stmt [78388,78425]
===
match
---
operator: = [79588,79589]
operator: = [79608,79609]
===
match
---
operator: = [7466,7467]
operator: = [7494,7495]
===
match
---
trailer [40598,40602]
trailer [40618,40622]
===
match
---
suite [5197,5308]
suite [5225,5336]
===
match
---
import_from [952,992]
import_from [937,977]
===
match
---
name: finished [24878,24886]
name: finished [24898,24906]
===
match
---
atom_expr [45073,45086]
atom_expr [45093,45106]
===
match
---
fstring_expr [62400,62413]
fstring_expr [62420,62433]
===
match
---
if_stmt [26840,28049]
if_stmt [26860,28069]
===
match
---
simple_stmt [41601,41611]
simple_stmt [41621,41631]
===
match
---
name: Exception [58833,58842]
name: Exception [58853,58862]
===
match
---
expr_stmt [27869,27935]
expr_stmt [27889,27955]
===
match
---
suite [82271,82319]
suite [82291,82339]
===
match
---
decorator [20995,21012]
decorator [21015,21032]
===
match
---
name: filter [26077,26083]
name: filter [26097,26103]
===
match
---
atom_expr [9549,9581]
atom_expr [9577,9609]
===
match
---
name: self [28018,28022]
name: self [28038,28042]
===
match
---
trailer [48721,48737]
trailer [48741,48757]
===
match
---
name: execution_date [61340,61354]
name: execution_date [61360,61374]
===
match
---
argument [71400,71415]
argument [71420,71435]
===
match
---
operator: ** [71400,71402]
operator: ** [71420,71422]
===
match
---
simple_stmt [24210,24275]
simple_stmt [24230,24295]
===
match
---
atom_expr [68419,69022]
atom_expr [68439,69042]
===
match
---
param [77851,77860]
param [77871,77880]
===
match
---
name: self [30085,30089]
name: self [30105,30109]
===
match
---
atom_expr [47102,47122]
atom_expr [47122,47142]
===
match
---
simple_stmt [57085,57122]
simple_stmt [57105,57142]
===
match
---
name: isoformat [17946,17955]
name: isoformat [17966,17975]
===
match
---
trailer [52681,52701]
trailer [52701,52721]
===
match
---
atom [49340,49393]
atom [49360,49413]
===
match
---
atom_expr [14757,14769]
atom_expr [14777,14789]
===
match
---
operator: = [62219,62220]
operator: = [62239,62240]
===
match
---
name: ignore_all_deps [15672,15687]
name: ignore_all_deps [15692,15707]
===
match
---
simple_stmt [37488,37505]
simple_stmt [37508,37525]
===
match
---
name: Optional [15876,15884]
name: Optional [15896,15904]
===
match
---
name: sqlalchemy [1512,1522]
name: sqlalchemy [1497,1507]
===
match
---
trailer [55015,55020]
trailer [55035,55040]
===
match
---
trailer [9683,9696]
trailer [9711,9724]
===
match
---
trailer [71723,71733]
trailer [71743,71753]
===
match
---
trailer [47571,47588]
trailer [47591,47608]
===
match
---
name: failed [32182,32188]
name: failed [32202,32208]
===
match
---
name: dill [1157,1161]
name: dill [1142,1146]
===
match
---
trailer [50952,50958]
trailer [50972,50978]
===
match
---
operator: = [57986,57987]
operator: = [58006,58007]
===
match
---
decorator [32307,32324]
decorator [32327,32344]
===
match
---
name: self [43823,43827]
name: self [43843,43847]
===
match
---
operator: = [68465,68466]
operator: = [68485,68486]
===
match
---
trailer [67912,67985]
trailer [67932,68005]
===
match
---
simple_stmt [72136,72190]
simple_stmt [72156,72210]
===
match
---
name: prev_execution_date [65189,65208]
name: prev_execution_date [65209,65228]
===
match
---
operator: = [82442,82443]
operator: = [82462,82463]
===
match
---
parameters [67191,67197]
parameters [67211,67217]
===
match
---
atom_expr [24333,24352]
atom_expr [24353,24372]
===
match
---
return_stmt [79243,79490]
return_stmt [79263,79510]
===
match
---
name: file_path [18720,18729]
name: file_path [18740,18749]
===
match
---
atom_expr [50139,50175]
atom_expr [50159,50195]
===
match
---
name: qry [82350,82353]
name: qry [82370,82373]
===
match
---
operator: = [61401,61402]
operator: = [61421,61422]
===
match
---
name: debug [32643,32648]
name: debug [32663,32668]
===
match
---
atom_expr [80360,80373]
atom_expr [80380,80393]
===
match
---
name: Optional [41859,41867]
name: Optional [41879,41887]
===
match
---
name: default_subject [72173,72188]
name: default_subject [72193,72208]
===
match
---
name: timeout [51424,51431]
name: timeout [51444,51451]
===
match
---
operator: = [20537,20538]
operator: = [20557,20558]
===
match
---
operator: } [45019,45020]
operator: } [45039,45040]
===
match
---
operator: , [77718,77719]
operator: , [77738,77739]
===
match
---
operator: = [15101,15102]
operator: = [15121,15122]
===
match
---
operator: = [21071,21072]
operator: = [21091,21092]
===
match
---
argument [29598,29609]
argument [29618,29629]
===
match
---
suite [32974,33075]
suite [32994,33095]
===
match
---
name: provide_session [29703,29718]
name: provide_session [29723,29738]
===
match
---
expr_stmt [47459,47527]
expr_stmt [47479,47547]
===
match
---
operator: , [10013,10014]
operator: , [10041,10042]
===
match
---
trailer [72857,72866]
trailer [72877,72886]
===
match
---
trailer [41223,41287]
trailer [41243,41307]
===
match
---
simple_stmt [56321,56363]
simple_stmt [56341,56383]
===
match
---
operator: } [45004,45005]
operator: } [45024,45025]
===
match
---
operator: , [58494,58495]
operator: , [58514,58515]
===
match
---
name: pickle [4653,4659]
name: pickle [4681,4687]
===
match
---
suite [24201,24371]
suite [24221,24391]
===
match
---
name: execute [7267,7274]
name: execute [7295,7302]
===
match
---
operator: , [15937,15938]
operator: , [15957,15958]
===
match
---
trailer [49425,49433]
trailer [49445,49453]
===
match
---
trailer [71366,71392]
trailer [71386,71412]
===
match
---
simple_stmt [4022,4046]
simple_stmt [4050,4074]
===
match
---
simple_stmt [67898,67986]
simple_stmt [67918,68006]
===
match
---
name: _task_id [80719,80727]
name: _task_id [80739,80747]
===
match
---
name: pendulum [29655,29663]
name: pendulum [29675,29683]
===
match
---
operator: = [55341,55342]
operator: = [55361,55362]
===
match
---
operator: , [77073,77074]
operator: , [77093,77094]
===
match
---
expr_stmt [12122,12140]
expr_stmt [12142,12160]
===
match
---
name: send_email [2447,2457]
name: send_email [2432,2442]
===
match
---
return_stmt [80965,80986]
return_stmt [80985,81006]
===
match
---
string: """Initialize the attributes that aren't stored in the DB""" [12519,12579]
string: """Initialize the attributes that aren't stored in the DB""" [12539,12599]
===
match
---
trailer [71672,71683]
trailer [71692,71703]
===
match
---
annassign [80313,80328]
annassign [80333,80348]
===
match
---
name: next_execution_date [61463,61482]
name: next_execution_date [61483,61502]
===
match
---
operator: = [37555,37556]
operator: = [37575,37576]
===
match
---
operator: @ [19428,19429]
operator: @ [19448,19449]
===
match
---
expr_stmt [9923,9954]
expr_stmt [9951,9982]
===
match
---
trailer [19391,19399]
trailer [19411,19419]
===
match
---
operator: , [68697,68698]
operator: , [68717,68718]
===
match
---
expr_stmt [34569,34647]
expr_stmt [34589,34667]
===
match
---
atom [47037,47208]
atom [47057,47228]
===
match
---
name: task [53334,53338]
name: task [53354,53358]
===
match
---
operator: , [1110,1111]
operator: , [1095,1096]
===
match
---
name: generate_command [15495,15511]
name: generate_command [15515,15531]
===
match
---
string: 'params' [65058,65066]
string: 'params' [65078,65086]
===
match
---
simple_stmt [43631,44006]
simple_stmt [43651,44026]
===
match
---
atom [18588,18599]
atom [18608,18619]
===
match
---
trailer [7428,7432]
trailer [7456,7460]
===
match
---
operator: = [15059,15060]
operator: = [15079,15080]
===
match
---
name: self [22416,22420]
name: self [22436,22440]
===
match
---
name: extend [18816,18822]
name: extend [18836,18842]
===
match
---
simple_stmt [1924,1969]
simple_stmt [1909,1954]
===
match
---
atom_expr [32521,32535]
atom_expr [32541,32555]
===
match
---
string: "Failed to register in sensor service.Continue to run task in non smart sensor mode." [50011,50096]
string: "Failed to register in sensor service.Continue to run task in non smart sensor mode." [50031,50116]
===
match
---
funcdef [12487,12648]
funcdef [12507,12668]
===
match
---
atom_expr [56989,57003]
atom_expr [57009,57023]
===
match
---
name: dag_id [23940,23946]
name: dag_id [23960,23966]
===
match
---
operator: , [64000,64001]
operator: , [64020,64021]
===
match
---
name: str [15589,15592]
name: str [15609,15612]
===
match
---
trailer [39317,39328]
trailer [39337,39348]
===
match
---
atom_expr [29828,29855]
atom_expr [29848,29875]
===
match
---
trailer [34626,34640]
trailer [34646,34660]
===
match
---
trailer [7170,7176]
trailer [7198,7204]
===
match
---
name: NONE [6006,6010]
name: NONE [6034,6038]
===
match
---
trailer [40478,40485]
trailer [40498,40505]
===
match
---
suite [13373,13879]
suite [13393,13899]
===
match
---
trailer [37517,37535]
trailer [37537,37555]
===
match
---
name: self [40826,40830]
name: self [40846,40850]
===
match
---
simple_stmt [64503,64577]
simple_stmt [64523,64597]
===
match
---
atom_expr [61513,61532]
atom_expr [61533,61552]
===
match
---
trailer [23461,23473]
trailer [23481,23493]
===
match
---
atom_expr [80011,80022]
atom_expr [80031,80042]
===
match
---
atom_expr [58790,58813]
atom_expr [58810,58833]
===
match
---
name: hr_line_break [40696,40709]
name: hr_line_break [40716,40729]
===
match
---
name: start_date [7922,7932]
name: start_date [7950,7960]
===
match
---
name: or_ [6805,6808]
name: or_ [6833,6836]
===
match
---
operator: = [19013,19014]
operator: = [19033,19034]
===
match
---
trailer [21829,21845]
trailer [21849,21865]
===
match
---
operator: , [52387,52388]
operator: , [52407,52408]
===
match
---
trailer [71083,71091]
trailer [71103,71111]
===
match
---
trailer [18284,18315]
trailer [18304,18335]
===
match
---
name: timeout [2859,2866]
name: timeout [2887,2894]
===
match
---
argument [76577,76594]
argument [76597,76614]
===
match
---
trailer [28535,28551]
trailer [28555,28571]
===
match
---
tfpdef [63991,64000]
tfpdef [64011,64020]
===
match
---
name: self [35528,35532]
name: self [35548,35552]
===
match
---
expr_stmt [41491,41517]
expr_stmt [41511,41537]
===
match
---
name: task_id [47519,47526]
name: task_id [47539,47546]
===
match
---
param [14113,14135]
param [14133,14155]
===
match
---
name: expected_state [3624,3638]
name: expected_state [3652,3666]
===
match
---
name: self [44865,44869]
name: self [44885,44889]
===
match
---
name: __table_args__ [10555,10569]
name: __table_args__ [10583,10597]
===
match
---
name: try_number [8554,8564]
name: try_number [8582,8592]
===
match
---
name: XCom [23909,23913]
name: XCom [23929,23933]
===
match
---
simple_stmt [52231,52288]
simple_stmt [52251,52308]
===
match
---
string: '-' [62309,62312]
string: '-' [62329,62332]
===
match
---
name: render_templates [48955,48971]
name: render_templates [48975,48991]
===
match
---
name: ignore_task_deps [15131,15147]
name: ignore_task_deps [15151,15167]
===
match
---
expr_stmt [23338,23371]
expr_stmt [23358,23391]
===
match
---
decorated [19854,20611]
decorated [19874,20631]
===
match
---
name: self [74350,74354]
name: self [74370,74374]
===
match
---
import_as_names [2103,2124]
import_as_names [2088,2109]
===
match
---
operator: , [59393,59394]
operator: , [59413,59414]
===
match
---
trailer [22745,22757]
trailer [22765,22777]
===
match
---
name: SUCCESS [54736,54743]
name: SUCCESS [54756,54763]
===
match
---
operator: , [31006,31007]
operator: , [31026,31027]
===
match
---
argument [68711,68738]
argument [68731,68758]
===
match
---
operator: , [37867,37868]
operator: , [37887,37888]
===
match
---
name: ti [5213,5215]
name: ti [5241,5243]
===
match
---
name: dagrun [60280,60286]
name: dagrun [60300,60306]
===
match
---
name: first [60493,60498]
name: first [60513,60518]
===
match
---
name: property [8317,8325]
name: property [8345,8353]
===
match
---
name: dag [27665,27668]
name: dag [27685,27688]
===
match
---
name: RenderedTaskInstanceFields [66320,66346]
name: RenderedTaskInstanceFields [66340,66366]
===
match
---
operator: == [78982,78984]
operator: == [79002,79004]
===
match
---
operator: } [57003,57004]
operator: } [57023,57024]
===
match
---
name: task [56874,56878]
name: task [56894,56898]
===
match
---
name: debug [24122,24127]
name: debug [24142,24147]
===
match
---
param [55190,55206]
param [55210,55226]
===
match
---
operator: = [68715,68716]
operator: = [68735,68736]
===
match
---
name: self [24770,24774]
name: self [24790,24794]
===
match
---
expr_stmt [59960,59976]
expr_stmt [59980,59996]
===
match
---
trailer [10587,10618]
trailer [10615,10646]
===
match
---
operator: = [61710,61711]
operator: = [61730,61731]
===
match
---
simple_stmt [12371,12388]
simple_stmt [12391,12408]
===
match
---
simple_stmt [35589,35599]
simple_stmt [35609,35619]
===
match
---
operator: , [4302,4303]
operator: , [4330,4331]
===
match
---
operator: = [37633,37634]
operator: = [37653,37654]
===
match
---
name: error [4286,4291]
name: error [4314,4319]
===
match
---
arglist [54460,54656]
arglist [54480,54676]
===
match
---
name: dict [68329,68333]
name: dict [68349,68353]
===
match
---
name: execution_date [76500,76514]
name: execution_date [76520,76534]
===
match
---
atom_expr [8723,8798]
atom_expr [8751,8826]
===
match
---
operator: { [19130,19131]
operator: { [19150,19151]
===
match
---
name: ignore_depends_on_past [18406,18428]
name: ignore_depends_on_past [18426,18448]
===
match
---
arglist [48612,48642]
arglist [48632,48662]
===
match
---
arglist [72309,72358]
arglist [72329,72378]
===
match
---
trailer [45336,45354]
trailer [45356,45374]
===
match
---
atom_expr [51507,51541]
atom_expr [51527,51561]
===
match
---
trailer [21730,21745]
trailer [21750,21765]
===
match
---
import_as_names [1236,1274]
import_as_names [1221,1259]
===
match
---
operator: , [7802,7803]
operator: , [7830,7831]
===
match
---
trailer [43827,43835]
trailer [43847,43855]
===
match
---
trailer [81054,81066]
trailer [81074,81086]
===
match
---
name: state [39098,39103]
name: state [39118,39123]
===
match
---
trailer [23384,23400]
trailer [23404,23420]
===
match
---
parameters [63194,63200]
parameters [63214,63220]
===
match
---
name: self [48949,48953]
name: self [48969,48973]
===
match
---
atom_expr [47704,47720]
atom_expr [47724,47740]
===
match
---
atom_expr [22647,22667]
atom_expr [22667,22687]
===
match
---
name: str [41826,41829]
name: str [41846,41849]
===
match
---
operator: , [11673,11674]
operator: , [11701,11702]
===
match
---
trailer [80893,80905]
trailer [80913,80925]
===
match
---
name: utcnow [7944,7950]
name: utcnow [7972,7978]
===
match
---
param [59281,59294]
param [59301,59314]
===
match
---
name: Float [9754,9759]
name: Float [9782,9787]
===
match
---
name: the_log [19092,19099]
name: the_log [19112,19119]
===
match
---
operator: , [54096,54097]
operator: , [54116,54117]
===
match
---
name: session [29211,29218]
name: session [29231,29238]
===
match
---
param [30984,30989]
param [31004,31009]
===
match
---
param [73141,73150]
param [73161,73170]
===
match
---
expr_stmt [46940,46998]
expr_stmt [46960,47018]
===
match
---
name: self [33313,33317]
name: self [33333,33337]
===
match
---
name: task [37500,37504]
name: task [37520,37524]
===
match
---
trailer [22628,22634]
trailer [22648,22654]
===
match
---
operator: , [66510,66511]
operator: , [66530,66531]
===
match
---
trailer [31821,31827]
trailer [31841,31847]
===
match
---
trailer [71796,71801]
trailer [71816,71821]
===
match
---
name: refresh_from_task [37518,37535]
name: refresh_from_task [37538,37555]
===
match
---
trailer [80976,80986]
trailer [80996,81006]
===
match
---
operator: , [46811,46812]
operator: , [46831,46832]
===
match
---
name: self [66436,66440]
name: self [66456,66460]
===
match
---
operator: , [49899,49900]
operator: , [49919,49920]
===
match
---
param [30410,30414]
param [30430,30434]
===
match
---
decorated [80911,80987]
decorated [80931,81007]
===
match
---
name: ti_hash [34171,34178]
name: ti_hash [34191,34198]
===
match
---
name: error [59448,59453]
name: error [59468,59473]
===
match
---
trailer [44466,44468]
trailer [44486,44488]
===
match
---
operator: = [79905,79906]
operator: = [79925,79926]
===
match
---
name: airflow [2463,2470]
name: airflow [2448,2455]
===
match
---
name: ti [47245,47247]
name: ti [47265,47267]
===
match
---
atom_expr [39987,40018]
atom_expr [40007,40038]
===
match
---
except_clause [44809,44851]
except_clause [44829,44871]
===
match
---
simple_stmt [11984,12021]
simple_stmt [12012,12049]
===
match
---
name: next_ds [61543,61550]
name: next_ds [61563,61570]
===
match
---
simple_stmt [5462,5489]
simple_stmt [5490,5517]
===
match
---
name: TR [6872,6874]
name: TR [6900,6902]
===
match
---
arith_expr [33704,33723]
arith_expr [33724,33743]
===
match
---
name: ti [6095,6097]
name: ti [6123,6125]
===
match
---
parameters [18903,18909]
parameters [18923,18929]
===
match
---
atom_expr [62288,62317]
atom_expr [62308,62337]
===
match
---
trailer [26357,26360]
trailer [26377,26380]
===
match
---
arglist [41224,41286]
arglist [41244,41306]
===
match
---
name: ds_nodash [62095,62104]
name: ds_nodash [62115,62124]
===
match
---
name: execution_date [74355,74369]
name: execution_date [74375,74389]
===
match
---
simple_stmt [18124,18165]
simple_stmt [18144,18185]
===
match
---
decorated [12653,13233]
decorated [12673,13253]
===
match
---
trailer [27999,28017]
trailer [28019,28037]
===
match
---
trailer [31817,31821]
trailer [31837,31841]
===
match
---
arglist [49895,49908]
arglist [49915,49928]
===
match
---
atom_expr [33037,33056]
atom_expr [33057,33076]
===
match
---
trailer [18452,18482]
trailer [18472,18502]
===
match
---
name: self [11526,11530]
name: self [11554,11558]
===
match
---
name: isoformat [19547,19556]
name: isoformat [19567,19576]
===
match
---
name: self [50852,50856]
name: self [50872,50876]
===
match
---
name: task [56862,56866]
name: task [56882,56886]
===
match
---
trailer [41126,41128]
trailer [41146,41148]
===
match
---
name: provide_session [53372,53387]
name: provide_session [53392,53407]
===
match
---
atom_expr [28268,28515]
atom_expr [28288,28535]
===
match
---
atom_expr [44269,44291]
atom_expr [44289,44311]
===
match
---
name: exception [70792,70801]
name: exception [70812,70821]
===
match
---
trailer [20315,20322]
trailer [20335,20342]
===
match
---
operator: = [68677,68678]
operator: = [68697,68698]
===
match
---
name: bool [35902,35906]
name: bool [35922,35926]
===
match
---
name: state [26479,26484]
name: state [26499,26504]
===
match
---
dotted_name [1414,1428]
dotted_name [1399,1413]
===
match
---
name: test_mode [54194,54203]
name: test_mode [54214,54223]
===
match
---
operator: = [34594,34595]
operator: = [34614,34615]
===
match
---
try_stmt [52058,52324]
try_stmt [52078,52344]
===
match
---
name: self [57210,57214]
name: self [57230,57234]
===
match
---
atom_expr [71501,71766]
atom_expr [71521,71786]
===
match
---
name: verbose [31022,31029]
name: verbose [31042,31049]
===
match
---
string: 'logging' [19043,19052]
string: 'logging' [19063,19072]
===
match
---
name: iso [18017,18020]
name: iso [18037,18040]
===
match
---
suite [29856,30359]
suite [29876,30379]
===
match
---
trailer [51431,51476]
trailer [51451,51496]
===
match
---
atom_expr [51787,51809]
atom_expr [51807,51829]
===
match
---
name: start_date [57215,57225]
name: start_date [57235,57245]
===
match
---
name: e [44742,44743]
name: e [44762,44763]
===
match
---
name: _start_date [79938,79949]
name: _start_date [79958,79969]
===
match
---
trailer [37839,37844]
trailer [37859,37864]
===
match
---
trailer [32513,32518]
trailer [32533,32538]
===
match
---
trailer [80537,80541]
trailer [80557,80561]
===
match
---
trailer [45321,45336]
trailer [45341,45356]
===
match
---
name: ts [65841,65843]
name: ts [65861,65863]
===
match
---
name: airflow [45931,45938]
name: airflow [45951,45958]
===
match
---
trailer [23295,23300]
trailer [23315,23320]
===
match
---
name: bool [56220,56224]
name: bool [56240,56244]
===
match
---
name: timedelta [60781,60790]
name: timedelta [60801,60810]
===
match
---
atom_expr [40826,40836]
atom_expr [40846,40856]
===
match
---
atom_expr [80220,80246]
atom_expr [80240,80266]
===
match
---
trailer [79037,79234]
trailer [79057,79254]
===
match
---
name: get_previous_ti [29582,29597]
name: get_previous_ti [29602,29617]
===
match
---
comparison [79339,79373]
comparison [79359,79393]
===
match
---
number: 1 [37869,37870]
number: 1 [37889,37890]
===
match
---
argument [9564,9580]
argument [9592,9608]
===
match
---
atom_expr [43209,43222]
atom_expr [43229,43242]
===
match
---
fstring_expr [48790,48809]
fstring_expr [48810,48829]
===
match
---
string: '' [62123,62125]
string: '' [62143,62145]
===
match
---
name: reconstructor [12469,12482]
name: reconstructor [12489,12502]
===
match
---
decorator [77375,77392]
decorator [77395,77412]
===
match
---
simple_stmt [52645,52662]
simple_stmt [52665,52682]
===
match
---
trailer [35561,35567]
trailer [35581,35587]
===
match
---
trailer [61995,62003]
trailer [62015,62023]
===
match
---
atom_expr [82412,82440]
atom_expr [82432,82460]
===
match
---
operator: , [74237,74238]
operator: , [74257,74258]
===
match
---
trailer [51075,51124]
trailer [51095,51144]
===
match
---
name: self [13212,13216]
name: self [13232,13236]
===
match
---
simple_stmt [79984,80023]
simple_stmt [80004,80043]
===
match
---
trailer [3562,3571]
trailer [3590,3599]
===
match
---
suite [60168,60635]
suite [60188,60655]
===
match
---
name: log_message [58077,58088]
name: log_message [58097,58108]
===
match
---
operator: + [34169,34170]
operator: + [34189,34190]
===
match
---
name: error [4447,4452]
name: error [4475,4480]
===
match
---
suite [8871,79491]
suite [8899,79511]
===
match
---
operator: = [53513,53514]
operator: = [53533,53534]
===
match
---
name: debug [24708,24713]
name: debug [24728,24733]
===
match
---
name: pickle_id [15865,15874]
name: pickle_id [15885,15894]
===
match
---
trailer [11766,11777]
trailer [11794,11805]
===
match
---
atom_expr [81125,81136]
atom_expr [81145,81156]
===
match
---
name: ts_nodash [65870,65879]
name: ts_nodash [65890,65899]
===
match
---
name: self [32968,32972]
name: self [32988,32992]
===
match
---
trailer [47490,47494]
trailer [47510,47514]
===
match
---
name: pool_override [42710,42723]
name: pool_override [42730,42743]
===
match
---
operator: , [58520,58521]
operator: , [58540,58541]
===
match
---
trailer [55910,55922]
trailer [55930,55942]
===
match
---
param [21056,21077]
param [21076,21097]
===
match
---
operator: , [15701,15702]
operator: , [15721,15722]
===
match
---
name: TR [7211,7213]
name: TR [7239,7241]
===
match
---
name: query [46128,46133]
name: query [46148,46153]
===
match
---
arglist [56834,56851]
arglist [56854,56871]
===
match
---
parameters [33103,33109]
parameters [33123,33129]
===
match
---
name: try_number [6860,6870]
name: try_number [6888,6898]
===
match
---
name: self [41434,41438]
name: self [41454,41458]
===
match
---
name: pool [10804,10808]
name: pool [10832,10836]
===
match
---
name: task_copy [48266,48275]
name: task_copy [48286,48295]
===
match
---
name: start_date [24802,24812]
name: start_date [24822,24832]
===
match
---
name: Any [74736,74739]
name: Any [74756,74759]
===
match
---
import_from [1275,1364]
import_from [1260,1349]
===
match
---
expr_stmt [19226,19270]
expr_stmt [19246,19290]
===
match
---
name: bool [74680,74684]
name: bool [74700,74704]
===
match
---
string: '' [62314,62316]
string: '' [62334,62336]
===
match
---
name: self [41506,41510]
name: self [41526,41530]
===
match
---
operator: , [6779,6780]
operator: , [6807,6808]
===
match
---
trailer [22791,22795]
trailer [22811,22815]
===
match
---
if_stmt [44617,44801]
if_stmt [44637,44821]
===
match
---
trailer [71267,71289]
trailer [71287,71309]
===
match
---
name: KubeConfig [68392,68402]
name: KubeConfig [68412,68422]
===
match
---
simple_stmt [69031,69063]
simple_stmt [69051,69083]
===
match
---
operator: , [45277,45278]
operator: , [45297,45298]
===
match
---
number: 1000 [9948,9952]
number: 1000 [9976,9980]
===
match
---
name: UP_FOR_RETRY [24910,24922]
name: UP_FOR_RETRY [24930,24942]
===
match
---
suite [59309,59461]
suite [59329,59481]
===
match
---
decorator [77959,77973]
decorator [77979,77993]
===
match
---
atom_expr [57174,57241]
atom_expr [57194,57261]
===
match
---
or_test [22582,22600]
or_test [22602,22620]
===
match
---
arglist [9477,9527]
arglist [9505,9555]
===
match
---
name: dag_id [60416,60422]
name: dag_id [60436,60442]
===
match
---
atom_expr [6838,6897]
atom_expr [6866,6925]
===
match
---
name: self [37513,37517]
name: self [37533,37537]
===
match
---
name: handle_failure [59323,59337]
name: handle_failure [59343,59357]
===
match
---
name: task [11242,11246]
name: task [11270,11274]
===
match
---
name: default_var [63381,63392]
name: default_var [63401,63412]
===
match
---
atom_expr [17931,17957]
atom_expr [17951,17977]
===
match
---
operator: = [76531,76532]
operator: = [76551,76552]
===
match
---
atom_expr [22741,22757]
atom_expr [22761,22777]
===
match
---
operator: , [38593,38594]
operator: , [38613,38614]
===
match
---
name: rendered_task_instance_fields [66530,66559]
name: rendered_task_instance_fields [66550,66579]
===
match
---
trailer [56609,56622]
trailer [56629,56642]
===
match
---
name: self [50322,50326]
name: self [50342,50346]
===
match
---
argument [76608,76647]
argument [76628,76667]
===
match
---
atom_expr [43631,44005]
atom_expr [43651,44025]
===
match
---
name: provide_session [74416,74431]
name: provide_session [74436,74451]
===
match
---
tfpdef [15757,15779]
tfpdef [15777,15799]
===
match
---
simple_stmt [72283,72360]
simple_stmt [72303,72380]
===
match
---
atom_expr [65341,65354]
atom_expr [65361,65374]
===
match
---
trailer [79194,79202]
trailer [79214,79222]
===
match
---
name: dag [14648,14651]
name: dag [14668,14671]
===
match
---
trailer [22762,22774]
trailer [22782,22794]
===
match
---
atom_expr [68597,68612]
atom_expr [68617,68632]
===
match
---
operator: , [73220,73221]
operator: , [73240,73241]
===
match
---
name: operator_helpers [2624,2640]
name: operator_helpers [2609,2625]
===
match
---
name: fallback [45898,45906]
name: fallback [45918,45926]
===
match
---
name: conf [64615,64619]
name: conf [64635,64639]
===
match
---
argument [37626,37641]
argument [37646,37661]
===
match
---
name: task [58745,58749]
name: task [58765,58769]
===
match
---
trailer [35101,35108]
trailer [35121,35128]
===
match
---
name: self [30984,30988]
name: self [31004,31008]
===
match
---
simple_stmt [2605,2672]
simple_stmt [2590,2657]
===
match
---
decorator [50720,50737]
decorator [50740,50757]
===
match
---
simple_stmt [27256,27332]
simple_stmt [27276,27352]
===
match
---
operator: = [51699,51700]
operator: = [51719,51720]
===
match
---
atom_expr [73946,73965]
atom_expr [73966,73985]
===
match
---
operator: , [26477,26478]
operator: , [26497,26498]
===
match
---
operator: , [58469,58470]
operator: , [58489,58490]
===
match
---
yield_expr [32933,32949]
yield_expr [32953,32969]
===
match
---
name: session [46308,46315]
name: session [46328,46335]
===
match
---
trailer [35465,35472]
trailer [35485,35492]
===
match
---
atom_expr [68203,68230]
atom_expr [68223,68250]
===
match
---
atom_expr [66388,66441]
atom_expr [66408,66461]
===
match
---
operator: , [48128,48129]
operator: , [48148,48149]
===
match
---
atom_expr [42899,42951]
atom_expr [42919,42971]
===
match
---
name: property [80827,80835]
name: property [80847,80855]
===
match
---
atom_expr [82032,82242]
atom_expr [82052,82262]
===
match
---
fstring_end: " [47974,47975]
fstring_end: " [47994,47995]
===
match
---
number: 1 [55926,55927]
number: 1 [55946,55947]
===
match
---
name: str [19916,19919]
name: str [19936,19939]
===
match
---
operator: + [40295,40296]
operator: + [40315,40316]
===
match
---
atom_expr [33704,33719]
atom_expr [33724,33739]
===
match
---
suite [11513,11975]
suite [11541,12003]
===
match
---
simple_stmt [2220,2252]
simple_stmt [2205,2237]
===
match
---
name: log [56517,56520]
name: log [56537,56540]
===
match
---
trailer [44869,44884]
trailer [44889,44904]
===
match
---
trailer [49985,50118]
trailer [50005,50138]
===
match
---
atom_expr [53183,53205]
atom_expr [53203,53225]
===
match
---
decorator [28559,28569]
decorator [28579,28589]
===
match
---
name: task_copy [48772,48781]
name: task_copy [48792,48801]
===
match
---
operator: , [27290,27291]
operator: , [27310,27311]
===
match
---
atom_expr [62416,62428]
atom_expr [62436,62448]
===
match
---
atom_expr [6805,6998]
atom_expr [6833,7026]
===
match
---
trailer [43292,43297]
trailer [43312,43317]
===
match
---
expr_stmt [12440,12462]
expr_stmt [12460,12482]
===
match
---
name: get [63545,63548]
name: get [63565,63568]
===
match
---
funcdef [63010,63169]
funcdef [63030,63189]
===
match
---
name: AirflowSmartSensorException [51048,51075]
name: AirflowSmartSensorException [51068,51095]
===
match
---
atom_expr [20440,20459]
atom_expr [20460,20479]
===
match
---
operator: , [71687,71688]
operator: , [71707,71708]
===
match
---
trailer [72098,72105]
trailer [72118,72125]
===
match
---
operator: @ [77959,77960]
operator: @ [77979,77980]
===
match
---
argument [78646,78716]
argument [78666,78736]
===
match
---
simple_stmt [26024,26339]
simple_stmt [26044,26359]
===
match
---
operator: , [79084,79085]
operator: , [79104,79105]
===
match
---
name: execution_date [11889,11903]
name: execution_date [11917,11931]
===
match
---
name: execution_date [82193,82207]
name: execution_date [82213,82227]
===
match
---
trailer [66565,66567]
trailer [66585,66587]
===
match
---
trailer [4298,4314]
trailer [4326,4342]
===
match
---
return_stmt [63218,63238]
return_stmt [63238,63258]
===
match
---
name: deserialize_model_file [68958,68980]
name: deserialize_model_file [68978,69000]
===
match
---
funcdef [64227,64577]
funcdef [64247,64597]
===
match
---
trailer [45434,45446]
trailer [45454,45466]
===
match
---
atom_expr [47282,47292]
atom_expr [47302,47312]
===
match
---
name: TaskInstance [77682,77694]
name: TaskInstance [77702,77714]
===
match
---
name: provide_session [25397,25412]
name: provide_session [25417,25432]
===
match
---
fstring_expr [14756,14770]
fstring_expr [14776,14790]
===
match
---
name: self [60839,60843]
name: self [60859,60863]
===
match
---
trailer [5566,5577]
trailer [5594,5605]
===
match
---
name: STATICA_HACK [82382,82394]
name: STATICA_HACK [82402,82414]
===
match
---
name: delete_old_records [49019,49037]
name: delete_old_records [49039,49057]
===
match
---
name: dag [5424,5427]
name: dag [5452,5455]
===
match
---
name: dag_id [20331,20337]
name: dag_id [20351,20357]
===
match
---
operator: = [12046,12047]
operator: = [12074,12075]
===
match
---
arglist [10688,10705]
arglist [10716,10733]
===
match
---
name: state [10612,10617]
name: state [10640,10645]
===
match
---
operator: , [59657,59658]
operator: , [59677,59678]
===
match
---
name: state [22116,22121]
name: state [22136,22141]
===
match
---
name: Log [45536,45539]
name: Log [45556,45559]
===
match
---
trailer [4384,4402]
trailer [4412,4430]
===
match
---
operator: = [56291,56292]
operator: = [56311,56312]
===
match
---
trailer [24121,24127]
trailer [24141,24147]
===
match
---
expr_stmt [5549,5596]
expr_stmt [5577,5624]
===
match
---
name: get_task [5428,5436]
name: get_task [5456,5464]
===
match
---
name: render_template_fields [68250,68272]
name: render_template_fields [68270,68292]
===
match
---
trailer [56520,56530]
trailer [56540,56550]
===
match
---
atom_expr [42873,42890]
atom_expr [42893,42910]
===
match
---
simple_stmt [40951,40971]
simple_stmt [40971,40991]
===
match
---
atom_expr [22760,22774]
atom_expr [22780,22794]
===
match
---
name: session [60584,60591]
name: session [60604,60611]
===
match
---
dotted_name [2727,2751]
dotted_name [2755,2779]
===
match
---
name: delay [33305,33310]
name: delay [33325,33330]
===
match
---
atom_expr [25368,25390]
atom_expr [25388,25410]
===
match
---
operator: , [24427,24428]
operator: , [24447,24448]
===
match
---
except_clause [4466,4482]
except_clause [4494,4510]
===
match
---
import_from [1409,1463]
import_from [1394,1448]
===
match
---
trailer [9974,9983]
trailer [10002,10011]
===
match
---
suite [2872,3126]
suite [2900,3154]
===
match
---
string: """Returns SQLAlchemy filter to query selected task instances""" [78091,78155]
string: """Returns SQLAlchemy filter to query selected task instances""" [78111,78175]
===
match
---
name: self [11090,11094]
name: self [11118,11122]
===
match
---
simple_stmt [69416,69456]
simple_stmt [69436,69476]
===
match
---
simple_stmt [58790,58814]
simple_stmt [58810,58834]
===
match
---
trailer [44289,44291]
trailer [44309,44311]
===
match
---
argument [27906,27921]
argument [27926,27941]
===
match
---
name: ignore_depends_on_past [38380,38402]
name: ignore_depends_on_past [38400,38422]
===
match
---
name: self [19238,19242]
name: self [19258,19262]
===
match
---
trailer [59424,59447]
trailer [59444,59467]
===
match
---
name: rendered_k8s_spec [67340,67357]
name: rendered_k8s_spec [67360,67377]
===
match
---
if_stmt [40750,40818]
if_stmt [40770,40838]
===
match
---
name: integrate_macros_plugins [60021,60045]
name: integrate_macros_plugins [60041,60065]
===
match
---
fstring_string: <TaskInstance:  [32992,33007]
fstring_string: <TaskInstance:  [33012,33027]
===
match
---
simple_stmt [2933,2987]
simple_stmt [2961,3015]
===
match
---
operator: , [1800,1801]
operator: , [1785,1786]
===
match
---
name: get [77146,77149]
name: get [77166,77169]
===
match
---
arglist [19043,19071]
arglist [19063,19091]
===
match
---
name: task [54974,54978]
name: task [54994,54998]
===
match
---
comparison [82080,82115]
comparison [82100,82135]
===
match
---
trailer [79937,79949]
trailer [79957,79969]
===
match
---
parameters [11089,11156]
parameters [11117,11184]
===
match
---
name: filter_by [60406,60415]
name: filter_by [60426,60435]
===
match
---
operator: = [19230,19231]
operator: = [19250,19251]
===
match
---
string: 'end_date' [43979,43989]
string: 'end_date' [43999,44009]
===
match
---
operator: , [15326,15327]
operator: , [15346,15347]
===
match
---
simple_stmt [72900,72966]
simple_stmt [72920,72986]
===
match
---
name: error_file [4385,4395]
name: error_file [4413,4423]
===
match
---
simple_stmt [22741,22775]
simple_stmt [22761,22795]
===
match
---
name: self [39093,39097]
name: self [39113,39117]
===
match
---
name: outlets [65037,65044]
name: outlets [65057,65064]
===
match
---
trailer [79271,79454]
trailer [79291,79474]
===
match
---
name: schedulable_ti [47340,47354]
name: schedulable_ti [47360,47374]
===
match
---
name: job_ids [5282,5289]
name: job_ids [5310,5317]
===
match
---
operator: , [33922,33923]
operator: , [33942,33943]
===
match
---
trailer [80196,80201]
trailer [80216,80221]
===
match
---
operator: == [82100,82102]
operator: == [82120,82122]
===
match
---
atom_expr [76453,76687]
atom_expr [76473,76707]
===
match
---
simple_stmt [33786,34072]
simple_stmt [33806,34092]
===
match
---
atom_expr [32567,32615]
atom_expr [32587,32635]
===
match
---
trailer [71818,71820]
trailer [71838,71840]
===
match
---
operator: , [15855,15856]
operator: , [15875,15876]
===
match
---
atom_expr [22532,22541]
atom_expr [22552,22561]
===
match
---
annassign [79808,79825]
annassign [79828,79845]
===
match
---
arglist [56477,56493]
arglist [56497,56513]
===
match
---
name: _CURRENT_CONTEXT [3539,3555]
name: _CURRENT_CONTEXT [3567,3583]
===
match
---
trailer [55442,55713]
trailer [55462,55733]
===
match
---
name: test_mode [54513,54522]
name: test_mode [54533,54542]
===
match
---
name: TaskInstanceKey [79596,79611]
name: TaskInstanceKey [79616,79631]
===
match
---
for_stmt [31836,32170]
for_stmt [31856,32190]
===
match
---
name: mark_success [18033,18045]
name: mark_success [18053,18065]
===
match
---
simple_stmt [60743,60816]
simple_stmt [60763,60836]
===
match
---
operator: = [31744,31745]
operator: = [31764,31765]
===
match
---
name: state [29766,29771]
name: state [29786,29791]
===
match
---
atom_expr [50554,50608]
atom_expr [50574,50628]
===
match
---
name: get_hostname [2592,2604]
name: get_hostname [2577,2589]
===
match
---
simple_stmt [78308,78329]
simple_stmt [78328,78349]
===
match
---
trailer [50807,50811]
trailer [50827,50831]
===
match
---
name: _try_number [13303,13314]
name: _try_number [13323,13334]
===
match
---
atom_expr [62981,62989]
atom_expr [63001,63009]
===
match
---
name: timezone [11808,11816]
name: timezone [11836,11844]
===
match
---
number: 2 [33722,33723]
number: 2 [33742,33743]
===
match
---
trailer [8511,8519]
trailer [8539,8547]
===
match
---
arglist [10916,11065]
arglist [10944,11093]
===
match
---
operator: -> [81340,81342]
operator: -> [81360,81362]
===
match
---
name: params [60240,60246]
name: params [60260,60266]
===
match
---
atom_expr [26865,26897]
atom_expr [26885,26917]
===
match
---
trailer [18697,18708]
trailer [18717,18728]
===
match
---
operator: , [62542,62543]
operator: , [62562,62563]
===
match
---
trailer [58993,59000]
trailer [59013,59020]
===
match
---
name: self [43141,43145]
name: self [43161,43165]
===
match
---
operator: , [15402,15403]
operator: , [15422,15423]
===
match
---
name: ignore_all_deps [38282,38297]
name: ignore_all_deps [38302,38317]
===
match
---
trailer [33064,33070]
trailer [33084,33090]
===
match
---
name: mark_success [53655,53667]
name: mark_success [53675,53687]
===
match
---
string: 'TaskInstanceKey' [8351,8368]
string: 'TaskInstanceKey' [8379,8396]
===
match
---
trailer [72949,72963]
trailer [72969,72983]
===
match
---
name: bool [56186,56190]
name: bool [56206,56210]
===
match
---
name: session [54285,54292]
name: session [54305,54312]
===
match
---
name: self [40861,40865]
name: self [40881,40885]
===
match
---
name: self [79834,79838]
name: self [79854,79858]
===
match
---
operator: , [21654,21655]
operator: , [21674,21675]
===
match
---
operator: = [22715,22716]
operator: = [22735,22736]
===
match
---
name: self [55951,55955]
name: self [55971,55975]
===
match
---
return_stmt [63153,63168]
return_stmt [63173,63188]
===
match
---
param [69195,69200]
param [69215,69220]
===
match
---
param [59659,59662]
param [59679,59682]
===
match
---
name: task [56989,56993]
name: task [57009,57013]
===
match
---
atom_expr [38511,38638]
atom_expr [38531,38658]
===
match
---
name: self [21692,21696]
name: self [21712,21716]
===
match
---
operator: @ [23608,23609]
operator: @ [23628,23629]
===
match
---
funcdef [15491,18868]
funcdef [15511,18888]
===
match
---
trailer [77262,77276]
trailer [77282,77296]
===
match
---
atom_expr [79312,79321]
atom_expr [79332,79341]
===
match
---
operator: = [74390,74391]
operator: = [74410,74411]
===
match
---
suite [11835,11905]
suite [11863,11933]
===
match
---
trailer [32642,32648]
trailer [32662,32668]
===
match
---
decorator [29098,29115]
decorator [29118,29135]
===
match
---
trailer [5093,5140]
trailer [5121,5168]
===
match
---
suite [47434,47528]
suite [47454,47548]
===
match
---
name: refresh_from_task [22917,22934]
name: refresh_from_task [22937,22954]
===
match
---
name: task [26823,26827]
name: task [26843,26847]
===
match
---
name: FileSystemLoader [71059,71075]
name: FileSystemLoader [71079,71095]
===
match
---
trailer [4029,4045]
trailer [4057,4073]
===
match
---
trailer [33026,33034]
trailer [33046,33054]
===
match
---
name: self [51846,51850]
name: self [51866,51870]
===
match
---
import_from [48186,48256]
import_from [48206,48276]
===
match
---
atom [60758,60794]
atom [60778,60814]
===
match
---
name: session [23655,23662]
name: session [23675,23682]
===
match
---
expr_stmt [69464,69517]
expr_stmt [69484,69537]
===
match
---
trailer [40570,40585]
trailer [40590,40605]
===
match
---
operator: , [55188,55189]
operator: , [55208,55209]
===
match
---
name: ignore_depends_on_past [39668,39690]
name: ignore_depends_on_past [39688,39710]
===
match
---
atom_expr [25011,25024]
atom_expr [25031,25044]
===
match
---
operator: = [46640,46641]
operator: = [46660,46661]
===
match
---
atom_expr [38656,38672]
atom_expr [38676,38692]
===
match
---
decorated [30364,30933]
decorated [30384,30953]
===
match
---
not_test [78167,78174]
not_test [78187,78194]
===
match
---
operator: = [73247,73248]
operator: = [73267,73268]
===
match
---
import_as_names [1298,1364]
import_as_names [1283,1349]
===
match
---
operator: = [34666,34667]
operator: = [34686,34687]
===
match
---
atom_expr [79590,79617]
atom_expr [79610,79637]
===
match
---
name: ti_deps [2265,2272]
name: ti_deps [2250,2257]
===
match
---
parameters [3918,3933]
parameters [3946,3961]
===
match
---
name: try_number [68602,68612]
name: try_number [68622,68632]
===
match
---
trailer [54978,55000]
trailer [54998,55020]
===
match
---
simple_stmt [25470,25924]
simple_stmt [25490,25944]
===
match
---
parameters [72796,72802]
parameters [72816,72822]
===
match
---
arith_expr [25011,25042]
arith_expr [25031,25062]
===
match
---
name: self [68597,68601]
name: self [68617,68621]
===
match
---
atom_expr [63400,63439]
atom_expr [63420,63459]
===
match
---
param [8150,8154]
param [8178,8182]
===
match
---
name: prev_execution_date [61875,61894]
name: prev_execution_date [61895,61914]
===
match
---
trailer [77589,77591]
trailer [77609,77611]
===
match
---
param [19893,19898]
param [19913,19918]
===
match
---
simple_stmt [13855,13879]
simple_stmt [13875,13899]
===
match
---
trailer [24323,24331]
trailer [24343,24351]
===
match
---
trailer [19267,19269]
trailer [19287,19289]
===
match
---
argument [39203,39218]
argument [39223,39238]
===
match
---
name: self [22787,22791]
name: self [22807,22811]
===
match
---
simple_stmt [21498,21557]
simple_stmt [21518,21577]
===
match
---
name: self [13276,13280]
name: self [13296,13300]
===
match
---
simple_stmt [18274,18316]
simple_stmt [18294,18336]
===
match
---
simple_stmt [1365,1409]
simple_stmt [1350,1394]
===
match
---
funcdef [25107,25391]
funcdef [25127,25411]
===
match
---
atom_expr [60021,60047]
atom_expr [60041,60067]
===
match
---
argument [44756,44777]
argument [44776,44797]
===
match
---
arglist [66593,66630]
arglist [66613,66650]
===
match
---
name: TaskReschedule [2011,2025]
name: TaskReschedule [1996,2010]
===
match
---
comparison [52605,52631]
comparison [52625,52651]
===
match
---
name: self [24040,24044]
name: self [24060,24064]
===
match
---
expr_stmt [14578,14597]
expr_stmt [14598,14617]
===
match
---
name: self [22060,22064]
name: self [22080,22084]
===
match
---
name: UndefinedError [67568,67582]
name: UndefinedError [67588,67602]
===
match
---
name: session [24429,24436]
name: session [24449,24456]
===
match
---
trailer [10054,10090]
trailer [10082,10118]
===
match
---
simple_stmt [50322,50358]
simple_stmt [50342,50378]
===
match
---
not_test [40753,40766]
not_test [40773,40786]
===
match
---
atom_expr [70936,70950]
atom_expr [70956,70970]
===
match
---
param [14176,14205]
param [14196,14225]
===
match
---
name: ti [80506,80508]
name: ti [80526,80528]
===
match
---
name: on_kill [48512,48519]
name: on_kill [48532,48539]
===
match
---
trailer [6634,7122]
trailer [6662,7150]
===
match
---
decorated [55099,56060]
decorated [55119,56080]
===
match
---
simple_stmt [16108,17917]
simple_stmt [16128,17937]
===
match
---
trailer [51473,51475]
trailer [51493,51495]
===
match
---
fstring_string: . [45020,45021]
fstring_string: . [45040,45041]
===
match
---
operator: , [32060,32061]
operator: , [32080,32081]
===
match
---
atom_expr [55515,55534]
atom_expr [55535,55554]
===
match
---
not_test [25364,25390]
not_test [25384,25410]
===
match
---
decorator [81380,81390]
decorator [81400,81410]
===
match
---
name: State [7468,7473]
name: State [7496,7501]
===
match
---
name: task [48320,48324]
name: task [48340,48344]
===
match
---
simple_stmt [12588,12648]
simple_stmt [12608,12668]
===
match
---
name: default_var [64330,64341]
name: default_var [64350,64361]
===
match
---
param [15797,15827]
param [15817,15847]
===
match
---
name: task_id [5391,5398]
name: task_id [5419,5426]
===
match
---
name: reason [32148,32154]
name: reason [32168,32174]
===
match
---
trailer [71514,71521]
trailer [71534,71541]
===
match
---
name: timezone [11475,11483]
name: timezone [11503,11511]
===
match
---
name: or_ [6613,6616]
name: or_ [6641,6644]
===
match
---
annassign [80088,80104]
annassign [80108,80124]
===
match
---
trailer [22393,22403]
trailer [22413,22423]
===
match
---
name: params [62500,62506]
name: params [62520,62526]
===
match
---
simple_stmt [22564,22601]
simple_stmt [22584,22621]
===
match
---
atom_expr [74292,74303]
atom_expr [74312,74323]
===
match
---
name: self [73063,73067]
name: self [73083,73087]
===
match
---
trailer [52896,52904]
trailer [52916,52924]
===
match
---
simple_stmt [40557,40586]
simple_stmt [40577,40606]
===
match
---
return_stmt [13971,13998]
return_stmt [13991,14018]
===
match
---
name: debug [30094,30099]
name: debug [30114,30119]
===
match
---
atom_expr [76980,77010]
atom_expr [77000,77030]
===
match
---
name: String [9549,9555]
name: String [9577,9583]
===
match
---
decorated [56065,59085]
decorated [56085,59105]
===
match
---
number: 1 [8546,8547]
number: 1 [8574,8575]
===
match
---
name: self [25368,25372]
name: self [25388,25392]
===
match
---
trailer [25075,25081]
trailer [25095,25101]
===
match
---
param [77845,77850]
param [77865,77870]
===
match
---
simple_stmt [80436,80479]
simple_stmt [80456,80499]
===
match
---
name: replace [62301,62308]
name: replace [62321,62328]
===
match
---
simple_stmt [38656,38673]
simple_stmt [38676,38693]
===
match
---
name: self [12030,12034]
name: self [12058,12062]
===
match
---
atom_expr [39060,39077]
atom_expr [39080,39097]
===
match
---
expr_stmt [33645,33727]
expr_stmt [33665,33747]
===
match
---
name: item [63065,63069]
name: item [63085,63089]
===
match
---
expr_stmt [58077,58116]
expr_stmt [58097,58136]
===
match
---
expr_stmt [23572,23602]
expr_stmt [23592,23622]
===
match
---
atom_expr [23588,23602]
atom_expr [23608,23622]
===
match
---
operator: -> [41909,41911]
operator: -> [41929,41931]
===
match
---
trailer [11958,11974]
trailer [11986,12002]
===
match
---
name: task [11311,11315]
name: task [11339,11343]
===
match
---
name: html_content [72202,72214]
name: html_content [72222,72234]
===
match
---
parameters [59852,59872]
parameters [59872,59892]
===
match
---
simple_stmt [32634,32870]
simple_stmt [32654,32890]
===
match
---
arglist [73036,73076]
arglist [73056,73096]
===
match
---
atom [33697,33725]
atom [33717,33745]
===
match
---
name: in_ [7694,7697]
name: in_ [7722,7725]
===
match
---
name: self [59690,59694]
name: self [59710,59714]
===
match
---
name: on_kill [51607,51614]
name: on_kill [51627,51634]
===
match
---
name: Proxy [65428,65433]
name: Proxy [65448,65453]
===
match
---
decorator [24376,24393]
decorator [24396,24413]
===
match
---
return_stmt [41555,41592]
return_stmt [41575,41612]
===
match
---
simple_stmt [44969,45036]
simple_stmt [44989,45056]
===
match
---
operator: -> [81408,81410]
operator: -> [81428,81430]
===
match
---
suite [58884,59001]
suite [58904,59021]
===
match
---
name: self [20959,20963]
name: self [20979,20983]
===
match
---
expr_stmt [60743,60815]
expr_stmt [60763,60835]
===
match
---
atom_expr [60861,60873]
atom_expr [60881,60893]
===
match
---
name: format [74116,74122]
name: format [74136,74142]
===
match
---
name: try_number [12035,12045]
name: try_number [12063,12073]
===
match
---
simple_stmt [55965,55982]
simple_stmt [55985,56002]
===
match
---
atom_expr [23320,23329]
atom_expr [23340,23349]
===
match
---
simple_stmt [31737,31752]
simple_stmt [31757,31772]
===
match
---
atom_expr [71937,71959]
atom_expr [71957,71979]
===
match
---
string: """         Set TaskInstance state.          :param state: State to set for the TI         :type state: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [24452,24649]
string: """         Set TaskInstance state.          :param state: State to set for the TI         :type state: str         :param session: SQLAlchemy ORM Session         :type session: Session         """ [24472,24669]
===
match
---
decorator [25093,25103]
decorator [25113,25123]
===
match
---
name: session [60618,60625]
name: session [60638,60645]
===
match
---
expr_stmt [3251,3284]
expr_stmt [3279,3312]
===
match
---
decorated [59090,59461]
decorated [59110,59481]
===
match
---
name: context [48857,48864]
name: context [48877,48884]
===
match
---
expr_stmt [31687,31728]
expr_stmt [31707,31748]
===
match
---
simple_stmt [59673,59713]
simple_stmt [59693,59733]
===
match
---
name: read [4060,4064]
name: read [4088,4092]
===
match
---
trailer [45483,45485]
trailer [45503,45505]
===
match
---
operator: , [57008,57009]
operator: , [57028,57029]
===
match
---
operator: = [15655,15656]
operator: = [15675,15676]
===
match
---
operator: == [6857,6859]
operator: == [6885,6887]
===
match
---
import_name [1201,1216]
import_name [1186,1201]
===
match
---
simple_stmt [7994,8036]
simple_stmt [8022,8064]
===
match
---
dotted_name [41638,41658]
dotted_name [41658,41678]
===
match
---
operator: } [66059,66060]
operator: } [66079,66080]
===
match
---
simple_stmt [3714,3897]
simple_stmt [3742,3925]
===
match
---
name: qry [21566,21569]
name: qry [21586,21589]
===
match
---
suite [56392,56432]
suite [56412,56452]
===
match
---
name: iso [17925,17928]
name: iso [17945,17948]
===
match
---
return_stmt [29044,29092]
return_stmt [29064,29112]
===
match
---
atom [65952,66060]
atom [65972,66080]
===
match
---
expr_stmt [61463,61533]
expr_stmt [61483,61553]
===
match
---
atom_expr [65459,65508]
atom_expr [65479,65528]
===
match
---
operator: { [19115,19116]
operator: { [19135,19136]
===
match
---
atom_expr [40839,40852]
atom_expr [40859,40872]
===
match
---
suite [41478,41593]
suite [41498,41613]
===
match
---
atom_expr [30419,30446]
atom_expr [30439,30466]
===
match
---
operator: ** [9564,9566]
operator: ** [9592,9594]
===
match
---
name: query [76445,76450]
name: query [76465,76470]
===
match
---
operator: = [68845,68846]
operator: = [68865,68866]
===
match
---
name: email [2434,2439]
name: email [2419,2424]
===
match
---
argument [60440,60474]
argument [60460,60494]
===
match
---
simple_stmt [67477,67524]
simple_stmt [67497,67544]
===
match
---
trailer [53124,53137]
trailer [53144,53157]
===
match
---
name: ti [80535,80537]
name: ti [80555,80557]
===
match
---
name: dict [70756,70760]
name: dict [70776,70780]
===
match
---
name: convert_to_utc [11944,11958]
name: convert_to_utc [11972,11986]
===
match
---
atom_expr [71879,71908]
atom_expr [71899,71928]
===
match
---
try_stmt [46005,48065]
try_stmt [46025,48085]
===
match
---
trailer [39219,39225]
trailer [39239,39245]
===
match
---
argument [54063,54096]
argument [54083,54116]
===
match
---
name: lock_for_update [43558,43573]
name: lock_for_update [43578,43593]
===
match
---
name: warnings [907,915]
name: warnings [892,900]
===
match
---
trailer [56993,57003]
trailer [57013,57023]
===
match
---
simple_stmt [53866,54304]
simple_stmt [53886,54324]
===
match
---
name: end_date [25016,25024]
name: end_date [25036,25044]
===
match
---
name: contextmanager [3299,3313]
name: contextmanager [3327,3341]
===
match
---
trailer [49196,49229]
trailer [49216,49249]
===
match
---
trailer [50466,50480]
trailer [50486,50500]
===
match
---
comparison [13132,13159]
comparison [13152,13179]
===
match
---
name: dr [7859,7861]
name: dr [7887,7889]
===
match
---
atom_expr [37807,37820]
atom_expr [37827,37840]
===
match
---
trailer [63911,63915]
trailer [63931,63935]
===
match
---
arglist [39874,39928]
arglist [39894,39948]
===
match
---
trailer [34731,34736]
trailer [34751,34756]
===
match
---
argument [27292,27330]
argument [27312,27350]
===
match
---
param [15602,15627]
param [15622,15647]
===
match
---
name: cmd [18743,18746]
name: cmd [18763,18766]
===
match
---
operator: , [72543,72544]
operator: , [72563,72564]
===
match
---
operator: , [26131,26132]
operator: , [26151,26152]
===
match
---
name: session [20653,20660]
name: session [20673,20680]
===
match
---
name: ID_LEN [9556,9562]
name: ID_LEN [9584,9590]
===
match
---
operator: , [68815,68816]
operator: , [68835,68836]
===
match
---
name: Optional [29828,29836]
name: Optional [29848,29856]
===
match
---
param [59648,59658]
param [59668,59678]
===
match
---
trailer [33322,33334]
trailer [33342,33354]
===
match
---
name: str [79849,79852]
name: str [79869,79872]
===
match
---
argument [10340,10352]
argument [10368,10380]
===
match
---
name: dag_id [46177,46183]
name: dag_id [46197,46203]
===
match
---
name: jinja_context [71501,71514]
name: jinja_context [71521,71534]
===
match
---
name: DeprecationWarning [30812,30830]
name: DeprecationWarning [30832,30850]
===
match
---
if_stmt [38504,38702]
if_stmt [38524,38722]
===
match
---
trailer [7943,7950]
trailer [7971,7978]
===
match
---
name: self [21551,21555]
name: self [21571,21575]
===
match
---
arglist [35473,35547]
arglist [35493,35567]
===
match
---
operator: = [74719,74720]
operator: = [74739,74740]
===
match
---
simple_stmt [2415,2458]
simple_stmt [2400,2443]
===
match
---
atom_expr [37513,37561]
atom_expr [37533,37581]
===
match
---
name: signal_handler [48350,48364]
name: signal_handler [48370,48384]
===
match
---
name: e [44254,44255]
name: e [44274,44275]
===
match
---
subscriptlist [79596,79616]
subscriptlist [79616,79636]
===
match
---
arith_expr [5564,5596]
arith_expr [5592,5624]
===
match
---
param [34878,34882]
param [34898,34902]
===
match
---
argument [49537,49552]
argument [49557,49572]
===
match
---
operator: = [11059,11060]
operator: = [11087,11088]
===
match
---
trailer [26396,26416]
trailer [26416,26436]
===
match
---
atom_expr [50866,50876]
atom_expr [50886,50896]
===
match
---
name: jobs [7325,7329]
name: jobs [7353,7357]
===
match
---
simple_stmt [8041,8053]
simple_stmt [8069,8081]
===
match
---
operator: } [7800,7801]
operator: } [7828,7829]
===
match
---
suite [78175,78200]
suite [78195,78220]
===
match
---
and_test [51787,51832]
and_test [51807,51852]
===
match
---
dotted_name [2191,2205]
dotted_name [2176,2190]
===
match
---
name: self [13180,13184]
name: self [13200,13204]
===
match
---
name: AirflowSmartSensorException [1773,1800]
name: AirflowSmartSensorException [1758,1785]
===
match
---
param [15636,15663]
param [15656,15683]
===
match
---
operator: , [59293,59294]
operator: , [59313,59314]
===
match
---
name: ds [60644,60646]
name: ds [60664,60666]
===
match
---
name: f [72036,72037]
name: f [72056,72057]
===
match
---
operator: , [67970,67971]
operator: , [67990,67991]
===
match
---
name: path [71930,71934]
name: path [71950,71954]
===
match
---
trailer [23324,23329]
trailer [23344,23349]
===
match
---
atom_expr [73985,74173]
atom_expr [74005,74193]
===
match
---
param [80685,80689]
param [80705,80709]
===
match
---
trailer [52318,52323]
trailer [52338,52343]
===
match
---
tfpdef [53461,53474]
tfpdef [53481,53494]
===
match
---
funcdef [59627,59802]
funcdef [59647,59822]
===
match
---
name: error [58807,58812]
name: error [58827,58832]
===
match
---
trailer [43200,43206]
trailer [43220,43226]
===
match
---
operator: , [59157,59158]
operator: , [59177,59178]
===
match
---
trailer [48442,48489]
trailer [48462,48509]
===
match
---
not_test [26972,26978]
not_test [26992,26998]
===
match
---
simple_stmt [3150,3167]
simple_stmt [3178,3195]
===
match
---
atom_expr [46947,46998]
atom_expr [46967,47018]
===
match
---
atom_expr [42646,42660]
atom_expr [42666,42680]
===
match
---
simple_stmt [80882,80906]
simple_stmt [80902,80926]
===
match
---
parameters [19462,19468]
parameters [19482,19488]
===
match
---
name: expunge_all [60592,60603]
name: expunge_all [60612,60623]
===
match
---
name: self [19726,19730]
name: self [19746,19750]
===
match
---
trailer [22617,22623]
trailer [22637,22643]
===
match
---
trailer [53249,53270]
trailer [53269,53290]
===
match
---
trailer [9786,9790]
trailer [9814,9818]
===
match
---
expr_stmt [62201,62257]
expr_stmt [62221,62277]
===
match
---
name: pool_override [22947,22960]
name: pool_override [22967,22980]
===
match
---
number: 1 [57007,57008]
number: 1 [57027,57028]
===
match
---
trailer [64177,64187]
trailer [64197,64207]
===
match
---
return_stmt [27227,27238]
return_stmt [27247,27258]
===
match
---
atom_expr [18743,18778]
atom_expr [18763,18798]
===
match
---
name: info [46940,46944]
name: info [46960,46964]
===
match
---
string: 'subject_template' [72153,72171]
string: 'subject_template' [72173,72191]
===
match
---
operator: = [68085,68086]
operator: = [68105,68106]
===
match
---
name: getLogger [3265,3274]
name: getLogger [3293,3302]
===
match
---
name: models [2039,2045]
name: models [2024,2030]
===
match
---
name: self [22613,22617]
name: self [22633,22637]
===
match
---
name: AirflowException [67612,67628]
name: AirflowException [67632,67648]
===
match
---
name: XCOM_RETURN_KEY [74634,74649]
name: XCOM_RETURN_KEY [74654,74669]
===
match
---
name: self [23572,23576]
name: self [23592,23596]
===
match
---
suite [28631,29093]
suite [28651,29113]
===
match
---
name: self [52925,52929]
name: self [52945,52949]
===
match
---
name: or_ [1361,1364]
name: or_ [1346,1349]
===
match
---
import_name [850,861]
import_name [835,846]
===
match
---
name: logging [842,849]
name: logging [827,834]
===
match
---
name: instance [30330,30338]
name: instance [30350,30358]
===
match
---
trailer [6718,7021]
trailer [6746,7049]
===
match
---
for_stmt [5145,6126]
for_stmt [5173,6154]
===
match
---
tfpdef [15711,15739]
tfpdef [15731,15759]
===
match
---
trailer [21853,21855]
trailer [21873,21875]
===
match
---
atom_expr [48992,49064]
atom_expr [49012,49084]
===
match
---
name: TaskInstanceKey [8723,8738]
name: TaskInstanceKey [8751,8766]
===
match
---
atom_expr [40435,40454]
atom_expr [40455,40474]
===
match
---
name: jinja_context [71299,71312]
name: jinja_context [71319,71332]
===
match
---
name: hostname [42818,42826]
name: hostname [42838,42846]
===
match
---
operator: { [67682,67683]
operator: { [67702,67703]
===
match
---
operator: = [14897,14898]
operator: = [14917,14918]
===
match
---
param [64330,64389]
param [64350,64409]
===
match
---
name: read [72038,72042]
name: read [72058,72062]
===
match
---
trailer [80462,80478]
trailer [80482,80498]
===
match
---
name: replace [62359,62366]
name: replace [62379,62386]
===
match
---
import_from [2458,2504]
import_from [2443,2489]
===
match
---
operator: = [54849,54850]
operator: = [54869,54870]
===
match
---
name: Exception [52169,52178]
name: Exception [52189,52198]
===
match
---
argument [46221,46255]
argument [46241,46275]
===
match
---
trailer [9628,9659]
trailer [9656,9687]
===
match
---
atom_expr [48717,48739]
atom_expr [48737,48759]
===
match
---
name: enrich_errors [45739,45752]
name: enrich_errors [45759,45772]
===
match
---
argument [54254,54263]
argument [54274,54283]
===
match
---
suite [40767,40818]
suite [40787,40838]
===
match
---
name: pool [22537,22541]
name: pool [22557,22561]
===
match
---
name: self [8521,8525]
name: self [8549,8553]
===
match
---
suite [42997,43129]
suite [43017,43149]
===
match
---
name: self [68052,68056]
name: self [68072,68076]
===
match
---
operator: @ [30364,30365]
operator: @ [30384,30385]
===
match
---
atom_expr [40243,40258]
atom_expr [40263,40278]
===
match
---
name: dep_status [32939,32949]
name: dep_status [32959,32969]
===
match
---
fstring_string: Skipping mini scheduling run due to exception:  [47914,47961]
fstring_string: Skipping mini scheduling run due to exception:  [47934,47981]
===
match
---
name: t [79155,79156]
name: t [79175,79176]
===
match
---
trailer [25081,25087]
trailer [25101,25107]
===
match
---
atom_expr [67972,67984]
atom_expr [67992,68004]
===
match
---
string: 'next_ds' [64887,64896]
string: 'next_ds' [64907,64916]
===
match
---
name: self [35152,35156]
name: self [35172,35176]
===
match
---
trailer [44655,44662]
trailer [44675,44682]
===
match
---
operator: = [38619,38620]
operator: = [38639,38640]
===
match
---
name: dep [32495,32498]
name: dep [32515,32518]
===
match
---
name: self [46184,46188]
name: self [46204,46208]
===
match
---
name: self [81050,81054]
name: self [81070,81074]
===
match
---
name: provide_session [35605,35620]
name: provide_session [35625,35640]
===
match
---
name: self [47877,47881]
name: self [47897,47901]
===
match
---
name: Context [59876,59883]
name: Context [59896,59903]
===
match
---
simple_stmt [23572,23603]
simple_stmt [23592,23623]
===
match
---
name: next_execution_date [61313,61332]
name: next_execution_date [61333,61352]
===
match
---
trailer [79114,79129]
trailer [79134,79149]
===
match
---
name: dag_id [68471,68477]
name: dag_id [68491,68497]
===
match
---
trailer [82059,82066]
trailer [82079,82086]
===
match
---
tfpdef [35845,35867]
tfpdef [35865,35887]
===
match
---
not_test [32890,32911]
not_test [32910,32931]
===
match
---
funcdef [66175,67161]
funcdef [66195,67181]
===
match
---
trailer [79253,79490]
trailer [79273,79510]
===
match
---
name: self [46692,46696]
name: self [46712,46716]
===
match
---
trailer [68011,68025]
trailer [68031,68045]
===
match
---
decorator [63252,63266]
decorator [63272,63286]
===
match
---
param [3919,3932]
param [3947,3960]
===
match
---
name: are_dependencies_met [30963,30983]
name: are_dependencies_met [30983,31003]
===
match
---
name: dag_run [82596,82603]
name: dag_run [82616,82623]
===
match
---
trailer [41111,41118]
trailer [41131,41138]
===
match
---
atom_expr [11166,11184]
atom_expr [11194,11212]
===
match
---
name: error_file [44910,44920]
name: error_file [44930,44940]
===
match
---
simple_stmt [68110,68157]
simple_stmt [68130,68177]
===
match
---
trailer [15018,15033]
trailer [15038,15053]
===
match
---
name: pickle_id [15317,15326]
name: pickle_id [15337,15346]
===
match
---
name: airflow [2308,2315]
name: airflow [2293,2300]
===
match
---
suite [18183,18234]
suite [18203,18254]
===
match
---
name: self [31783,31787]
name: self [31803,31807]
===
match
---
atom_expr [5082,5140]
atom_expr [5110,5168]
===
match
---
name: State [65494,65499]
name: State [65514,65519]
===
match
---
string: '-' [62118,62121]
string: '-' [62138,62141]
===
match
---
trailer [63126,63130]
trailer [63146,63150]
===
match
---
name: self [58658,58662]
name: self [58678,58682]
===
match
---
trailer [45470,45483]
trailer [45490,45503]
===
match
---
param [33104,33108]
param [33124,33128]
===
match
---
operator: , [68659,68660]
operator: , [68679,68680]
===
match
---
arglist [71946,71958]
arglist [71966,71978]
===
match
---
trailer [35479,35486]
trailer [35499,35506]
===
match
---
string: 'html_content_template' [72309,72332]
string: 'html_content_template' [72329,72352]
===
match
---
operator: = [30193,30194]
operator: = [30213,30214]
===
match
---
argument [71104,71119]
argument [71124,71139]
===
match
---
name: isinstance [56466,56476]
name: isinstance [56486,56496]
===
match
---
atom_expr [18812,18848]
atom_expr [18832,18868]
===
match
---
name: Tuple [1105,1110]
name: Tuple [1090,1095]
===
match
---
suite [14722,14772]
suite [14742,14792]
===
match
---
string: '%Y%m%dT%H%M%S' [58568,58583]
string: '%Y%m%dT%H%M%S' [58588,58603]
===
match
---
name: tomorrow_ds_nodash [62326,62344]
name: tomorrow_ds_nodash [62346,62364]
===
match
---
name: session [46120,46127]
name: session [46140,46147]
===
match
---
operator: @ [59090,59091]
operator: @ [59110,59111]
===
match
---
trailer [44089,44105]
trailer [44109,44125]
===
match
---
trailer [30172,30202]
trailer [30192,30222]
===
match
---
atom_expr [72933,72948]
atom_expr [72953,72968]
===
match
---
name: state [81090,81095]
name: state [81110,81115]
===
match
---
simple_stmt [4780,5044]
simple_stmt [4808,5072]
===
match
---
name: State [24872,24877]
name: State [24892,24897]
===
match
---
expr_stmt [51665,51708]
expr_stmt [51685,51728]
===
match
---
if_stmt [18030,18090]
if_stmt [18050,18110]
===
match
---
name: State [52619,52624]
name: State [52639,52644]
===
match
---
name: use_default [69416,69427]
name: use_default [69436,69447]
===
match
---
name: ti [22717,22719]
name: ti [22737,22739]
===
match
---
operator: = [26500,26501]
operator: = [26520,26521]
===
match
---
simple_stmt [66276,66347]
simple_stmt [66296,66367]
===
match
---
expr_stmt [49845,49909]
expr_stmt [49865,49929]
===
match
---
trailer [65487,65508]
trailer [65507,65528]
===
match
---
name: first [78347,78352]
name: first [78367,78372]
===
match
---
name: state [20916,20921]
name: state [20936,20941]
===
match
---
name: context_to_airflow_vars [49173,49196]
name: context_to_airflow_vars [49193,49216]
===
match
---
name: result [51911,51917]
name: result [51931,51937]
===
match
---
trailer [61489,61493]
trailer [61509,61513]
===
match
---
decorated [64201,64577]
decorated [64221,64597]
===
match
---
expr_stmt [54700,54774]
expr_stmt [54720,54794]
===
match
---
param [66208,66212]
param [66228,66232]
===
match
---
name: retry_exponential_backoff [33356,33381]
name: retry_exponential_backoff [33376,33401]
===
match
---
name: dep_context [32455,32466]
name: dep_context [32475,32486]
===
match
---
arglist [63549,63578]
arglist [63569,63598]
===
match
---
string: "Setting task state for %s to %s" [24714,24747]
string: "Setting task state for %s to %s" [24734,24767]
===
match
---
name: self [52231,52235]
name: self [52251,52255]
===
match
---
name: log_url [19164,19171]
name: log_url [19184,19191]
===
match
---
trailer [33901,33908]
trailer [33921,33928]
===
match
---
atom_expr [74259,74271]
atom_expr [74279,74291]
===
match
---
operator: , [73149,73150]
operator: , [73169,73170]
===
match
---
strings [69771,70091]
strings [69791,70111]
===
match
---
operator: } [19700,19701]
operator: } [19720,19721]
===
match
---
trailer [40386,40398]
trailer [40406,40418]
===
match
---
atom_expr [54730,54743]
atom_expr [54750,54763]
===
match
---
operator: , [72383,72384]
operator: , [72403,72404]
===
match
---
trailer [48062,48064]
trailer [48082,48084]
===
match
---
trailer [63548,63579]
trailer [63568,63599]
===
match
---
name: state [20577,20582]
name: state [20597,20602]
===
match
---
trailer [78320,78325]
trailer [78340,78345]
===
match
---
simple_stmt [55369,55389]
simple_stmt [55389,55409]
===
match
---
argument [44899,44920]
argument [44919,44940]
===
match
---
atom_expr [68559,68571]
atom_expr [68579,68591]
===
match
---
name: partial_dag [46628,46639]
name: partial_dag [46648,46659]
===
match
---
trailer [19298,19323]
trailer [19318,19343]
===
match
---
name: str [8170,8173]
name: str [8198,8201]
===
match
---
operator: , [4395,4396]
operator: , [4423,4424]
===
match
---
string: 'Airflow alert: {{ti}}' [69545,69568]
string: 'Airflow alert: {{ti}}' [69565,69588]
===
match
---
simple_stmt [66585,66632]
simple_stmt [66605,66652]
===
match
---
operator: , [71584,71585]
operator: , [71604,71605]
===
match
---
with_stmt [50402,50501]
with_stmt [50422,50521]
===
match
---
arglist [32670,32851]
arglist [32690,32871]
===
match
---
name: iso [19771,19774]
name: iso [19791,19794]
===
match
---
if_stmt [57943,58117]
if_stmt [57963,58137]
===
match
---
trailer [82411,82441]
trailer [82431,82461]
===
match
---
simple_stmt [22100,22122]
simple_stmt [22120,22142]
===
match
---
operator: , [41510,41511]
operator: , [41530,41531]
===
match
---
operator: = [14275,14276]
operator: = [14295,14296]
===
match
---
name: and_ [6630,6634]
name: and_ [6658,6662]
===
match
---
name: tis [7719,7722]
name: tis [7747,7750]
===
match
---
expr_stmt [50901,50936]
expr_stmt [50921,50956]
===
match
---
name: self [33037,33041]
name: self [33057,33061]
===
match
---
name: params [60193,60199]
name: params [60213,60219]
===
match
---
simple_stmt [72631,72682]
simple_stmt [72651,72702]
===
match
---
param [32968,32972]
param [32988,32992]
===
match
---
operator: = [22796,22797]
operator: = [22816,22817]
===
match
---
atom_expr [26054,26074]
atom_expr [26074,26094]
===
match
---
operator: , [49639,49640]
operator: , [49659,49660]
===
match
---
name: self [14584,14588]
name: self [14604,14608]
===
match
---
operator: = [47035,47036]
operator: = [47055,47056]
===
match
---
name: are_dependencies_met [39853,39873]
name: are_dependencies_met [39873,39893]
===
match
---
funcdef [77977,79491]
funcdef [77997,79511]
===
match
---
name: previous_ti_success [28577,28596]
name: previous_ti_success [28597,28616]
===
match
---
atom_expr [5240,5248]
atom_expr [5268,5276]
===
match
---
simple_stmt [77930,77954]
simple_stmt [77950,77974]
===
match
---
simple_stmt [70718,70984]
simple_stmt [70738,71004]
===
match
---
operator: , [59271,59272]
operator: , [59291,59292]
===
match
---
simple_stmt [51498,51542]
simple_stmt [51518,51562]
===
match
---
name: self [19893,19897]
name: self [19913,19917]
===
match
---
atom_expr [51432,51475]
atom_expr [51452,51495]
===
match
---
name: hr_line_break [40004,40017]
name: hr_line_break [40024,40037]
===
match
---
name: utils [2518,2523]
name: utils [2503,2508]
===
match
---
trailer [77806,77808]
trailer [77826,77828]
===
match
---
name: start_date [9664,9674]
name: start_date [9692,9702]
===
match
---
name: make_aware [11767,11777]
name: make_aware [11795,11805]
===
match
---
decorator [12653,12663]
decorator [12673,12683]
===
match
---
operator: = [15371,15372]
operator: = [15391,15392]
===
match
---
trailer [33355,33381]
trailer [33375,33401]
===
match
---
trailer [9548,9600]
trailer [9576,9628]
===
match
---
name: start_date [72938,72948]
name: start_date [72958,72968]
===
match
---
name: test_mode [53691,53700]
name: test_mode [53711,53720]
===
match
---
atom_expr [14848,14865]
atom_expr [14868,14885]
===
match
---
atom_expr [34831,34844]
atom_expr [34851,34864]
===
match
---
name: html_content [72668,72680]
name: html_content [72688,72700]
===
match
---
atom_expr [35490,35501]
atom_expr [35510,35521]
===
match
---
trailer [11877,11888]
trailer [11905,11916]
===
match
---
trailer [78894,78918]
trailer [78914,78938]
===
match
---
trailer [58213,58226]
trailer [58233,58246]
===
match
---
atom_expr [29655,29696]
atom_expr [29675,29716]
===
match
---
trailer [73067,73076]
trailer [73087,73096]
===
match
---
name: fd [4454,4456]
name: fd [4482,4484]
===
match
---
simple_stmt [22787,22805]
simple_stmt [22807,22825]
===
match
---
name: property [24155,24163]
name: property [24175,24183]
===
match
---
name: pid [10278,10281]
name: pid [10306,10309]
===
match
---
trailer [49042,49050]
trailer [49062,49070]
===
match
---
arglist [77061,77085]
arglist [77081,77105]
===
match
---
trailer [34835,34844]
trailer [34855,34864]
===
match
---
trailer [80117,80134]
trailer [80137,80154]
===
match
---
parameters [64143,64149]
parameters [64163,64169]
===
match
---
operator: = [71790,71791]
operator: = [71810,71811]
===
match
---
name: _state [80082,80088]
name: _state [80102,80108]
===
match
---
name: execution_date [21731,21745]
name: execution_date [21751,21765]
===
match
---
param [26473,26478]
param [26493,26498]
===
match
---
name: self [52605,52609]
name: self [52625,52629]
===
match
---
trailer [59047,59053]
trailer [59067,59073]
===
match
---
name: self [77907,77911]
name: self [77927,77931]
===
match
---
funcdef [79750,80542]
funcdef [79770,80562]
===
match
---
expr_stmt [11193,11218]
expr_stmt [11221,11246]
===
match
---
trailer [49390,49392]
trailer [49410,49412]
===
match
---
and_test [72853,72886]
and_test [72873,72906]
===
match
---
suite [80956,80987]
suite [80976,81007]
===
match
---
name: self [81402,81406]
name: self [81422,81426]
===
match
---
atom_expr [78316,78328]
atom_expr [78336,78348]
===
match
---
name: TaskInstanceKey [24185,24200]
name: TaskInstanceKey [24205,24220]
===
match
---
operator: = [29812,29813]
operator: = [29832,29833]
===
match
---
name: e [44850,44851]
name: e [44870,44871]
===
match
---
return_stmt [35589,35598]
return_stmt [35609,35618]
===
match
---
operator: = [79814,79815]
operator: = [79834,79835]
===
match
---
suite [19178,19423]
suite [19198,19443]
===
match
---
operator: @ [8124,8125]
operator: @ [8152,8153]
===
match
---
name: ti [47252,47254]
name: ti [47272,47274]
===
match
---
name: pickle_id [14266,14275]
name: pickle_id [14286,14295]
===
match
---
simple_stmt [56405,56432]
simple_stmt [56425,56452]
===
match
---
operator: , [51971,51972]
operator: , [51991,51992]
===
match
---
suite [72707,72775]
suite [72727,72795]
===
match
---
operator: == [79309,79311]
operator: == [79329,79331]
===
match
---
name: self [32588,32592]
name: self [32608,32612]
===
match
---
if_stmt [32887,32950]
if_stmt [32907,32970]
===
match
---
comparison [79391,79439]
comparison [79411,79459]
===
match
---
name: exc [52182,52185]
name: exc [52202,52205]
===
match
---
simple_stmt [29282,29498]
simple_stmt [29302,29518]
===
match
---
operator: , [76563,76564]
operator: , [76583,76584]
===
match
---
name: pickler [10340,10347]
name: pickler [10368,10375]
===
match
---
name: value [77282,77287]
name: value [77302,77307]
===
match
---
operator: = [76494,76495]
operator: = [76514,76515]
===
match
---
name: Stats [2246,2251]
name: Stats [2231,2236]
===
match
---
operator: = [14229,14230]
operator: = [14249,14250]
===
match
---
number: 0 [12048,12049]
number: 0 [12076,12077]
===
match
---
name: dag_id [8499,8505]
name: dag_id [8527,8533]
===
match
---
expr_stmt [80523,80541]
expr_stmt [80543,80561]
===
match
---
suite [52218,52324]
suite [52238,52344]
===
match
---
simple_stmt [77544,77819]
simple_stmt [77564,77839]
===
match
---
name: dep_status [32833,32843]
name: dep_status [32853,32863]
===
match
---
atom_expr [19232,19270]
atom_expr [19252,19290]
===
match
---
suite [66662,66703]
suite [66682,66723]
===
match
---
arglist [46177,46256]
arglist [46197,46276]
===
match
---
simple_stmt [9664,9697]
simple_stmt [9692,9725]
===
match
---
return_stmt [80634,80653]
return_stmt [80654,80673]
===
match
---
decorated [30938,32302]
decorated [30958,32322]
===
match
---
name: RUNNING [7899,7906]
name: RUNNING [7927,7934]
===
match
---
name: ti [80321,80323]
name: ti [80341,80343]
===
match
---
trailer [60625,60632]
trailer [60645,60652]
===
match
---
param [51949,51954]
param [51969,51974]
===
match
---
suite [4515,4681]
suite [4543,4709]
===
match
---
decorator [80659,80669]
decorator [80679,80689]
===
match
---
name: _priority_weight [81288,81304]
name: _priority_weight [81308,81324]
===
match
---
trailer [6882,6886]
trailer [6910,6914]
===
match
---
name: DagRun [7742,7748]
name: DagRun [7770,7776]
===
match
---
name: t [78669,78670]
name: t [78689,78690]
===
match
---
expr_stmt [82284,82318]
expr_stmt [82304,82338]
===
match
---
operator: , [65767,65768]
operator: , [65787,65788]
===
match
---
atom_expr [18687,18708]
atom_expr [18707,18728]
===
match
---
name: command_as_list [68721,68736]
name: command_as_list [68741,68756]
===
match
---
name: self [13918,13922]
name: self [13938,13942]
===
match
---
name: xcom_push [73108,73117]
name: xcom_push [73128,73137]
===
match
---
arglist [58916,58957]
arglist [58936,58977]
===
match
---
trailer [57100,57120]
trailer [57120,57140]
===
match
---
trailer [20952,20958]
trailer [20972,20978]
===
match
---
name: str [80197,80200]
name: str [80217,80220]
===
match
---
name: content [72026,72033]
name: content [72046,72053]
===
match
---
name: session [25068,25075]
name: session [25088,25095]
===
match
---
comparison [79182,79219]
comparison [79202,79239]
===
match
---
trailer [25372,25388]
trailer [25392,25408]
===
match
---
name: self [25011,25015]
name: self [25031,25035]
===
match
---
atom_expr [10215,10234]
atom_expr [10243,10262]
===
match
---
name: context [53083,53090]
name: context [53103,53110]
===
match
---
string: 'TaskInstance' [28615,28629]
string: 'TaskInstance' [28635,28649]
===
match
---
name: e [47760,47761]
name: e [47780,47781]
===
match
---
name: pool_slots [23361,23371]
name: pool_slots [23381,23391]
===
match
---
string: "Task failed with exception" [56531,56559]
string: "Task failed with exception" [56551,56579]
===
match
---
atom_expr [26043,26075]
atom_expr [26063,26095]
===
match
---
name: timezone [40401,40409]
name: timezone [40421,40429]
===
match
---
atom_expr [11193,11204]
atom_expr [11221,11232]
===
match
---
operator: @ [13884,13885]
operator: @ [13904,13905]
===
match
---
name: Integer [10265,10272]
name: Integer [10293,10300]
===
match
---
name: dag_run [68012,68019]
name: dag_run [68032,68039]
===
match
---
name: item [64252,64256]
name: item [64272,64276]
===
match
---
string: """         Pull XComs that optionally meet certain criteria.          The default value for `key` limits the search to XComs         that were returned by other tasks (as opposed to those that were pushed         manually). To remove this filter, pass key=None (or any desired value).          If a single task_id string is provided, the result is the value of the         most recent matching XCom from that task_id. If multiple task_ids are         provided, a tuple of matching values is returned. None is returned         whenever no matches are found.          :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. The default key is 'return_value', also             available as a constant XCOM_RETURN_KEY. This key is automatically             given to XComs returned by tasks (as opposed to being pushed             manually). To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_id: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: Sqlalchemy ORM Session         :type session: Session         """ [74749,76375]
string: """         Pull XComs that optionally meet certain criteria.          The default value for `key` limits the search to XComs         that were returned by other tasks (as opposed to those that were pushed         manually). To remove this filter, pass key=None (or any desired value).          If a single task_id string is provided, the result is the value of the         most recent matching XCom from that task_id. If multiple task_ids are         provided, a tuple of matching values is returned. None is returned         whenever no matches are found.          :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. The default key is 'return_value', also             available as a constant XCOM_RETURN_KEY. This key is automatically             given to XComs returned by tasks (as opposed to being pushed             manually). To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_id: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: Sqlalchemy ORM Session         :type session: Session         """ [74769,76395]
===
match
---
trailer [38210,38491]
trailer [38230,38511]
===
match
---
atom_expr [65494,65507]
atom_expr [65514,65527]
===
match
---
operator: , [6671,6672]
operator: , [6699,6700]
===
match
---
dictorsetmaker [65970,66046]
dictorsetmaker [65990,66066]
===
match
---
name: context [49537,49544]
name: context [49557,49564]
===
match
---
name: Optional [80188,80196]
name: Optional [80208,80216]
===
match
---
name: self [43794,43798]
name: self [43814,43818]
===
match
---
simple_stmt [8103,8119]
simple_stmt [8131,8147]
===
match
---
name: property [81211,81219]
name: property [81231,81239]
===
match
---
string: 'tomorrow_ds' [65741,65754]
string: 'tomorrow_ds' [65761,65774]
===
match
---
suite [45511,45591]
suite [45531,45611]
===
match
---
name: previous_scheduled_date [27182,27205]
name: previous_scheduled_date [27202,27225]
===
match
---
expr_stmt [26024,26338]
expr_stmt [26044,26358]
===
match
---
trailer [43072,43113]
trailer [43092,43133]
===
match
---
name: primaryjoin [10936,10947]
name: primaryjoin [10964,10975]
===
match
---
operator: , [78918,78919]
operator: , [78938,78939]
===
match
---
name: State [20924,20929]
name: State [20944,20949]
===
match
---
name: prev_ds_nodash [61842,61856]
name: prev_ds_nodash [61862,61876]
===
match
---
operator: + [5578,5579]
operator: + [5606,5607]
===
match
---
param [51163,51172]
param [51183,51192]
===
match
---
operator: = [29603,29604]
operator: = [29623,29624]
===
match
---
expr_stmt [47226,47319]
expr_stmt [47246,47339]
===
match
---
decorator [64201,64215]
decorator [64221,64235]
===
match
---
name: self [41256,41260]
name: self [41276,41280]
===
match
---
decorator [3287,3314]
decorator [3315,3342]
===
match
---
raise_stmt [67606,67694]
raise_stmt [67626,67714]
===
match
---
operator: == [79075,79077]
operator: == [79095,79097]
===
match
---
atom_expr [25341,25359]
atom_expr [25361,25379]
===
match
---
arglist [55488,55689]
arglist [55508,55709]
===
match
---
import_from [1828,1888]
import_from [1813,1873]
===
match
---
name: str [64174,64177]
name: str [64194,64197]
===
match
---
name: task_copy [50554,50563]
name: task_copy [50574,50583]
===
match
---
operator: , [15456,15457]
operator: , [15476,15477]
===
match
---
string: 'ti' [65717,65721]
string: 'ti' [65737,65741]
===
match
---
param [41704,41731]
param [41724,41751]
===
match
---
name: exception_html [69464,69478]
name: exception_html [69484,69498]
===
match
---
name: task_id [47146,47153]
name: task_id [47166,47173]
===
match
---
name: add [6110,6113]
name: add [6138,6141]
===
match
---
import_name [886,899]
import_name [871,884]
===
match
---
arglist [50481,50499]
arglist [50501,50519]
===
match
---
operator: , [9640,9641]
operator: , [9668,9669]
===
match
---
name: self [21643,21647]
name: self [21663,21667]
===
match
---
trailer [9476,9528]
trailer [9504,9556]
===
match
---
trailer [32843,32850]
trailer [32863,32870]
===
match
---
name: get_dagrun [26870,26880]
name: get_dagrun [26890,26900]
===
match
---
name: pid [40866,40869]
name: pid [40886,40889]
===
match
---
name: in_env_var_format [49206,49223]
name: in_env_var_format [49226,49243]
===
match
---
name: Environment [71016,71027]
name: Environment [71036,71047]
===
match
---
number: 0 [9848,9849]
number: 0 [9876,9877]
===
match
---
arith_expr [34157,34192]
arith_expr [34177,34212]
===
match
---
trailer [23342,23353]
trailer [23362,23373]
===
match
---
argument [49206,49228]
argument [49226,49248]
===
match
---
trailer [71945,71959]
trailer [71965,71979]
===
match
---
name: queued_dttm [40387,40398]
name: queued_dttm [40407,40418]
===
match
---
name: first [21848,21853]
name: first [21868,21873]
===
match
---
name: dag_id [45271,45277]
name: dag_id [45291,45297]
===
match
---
param [55168,55189]
param [55188,55209]
===
match
---
string: 'Failed to send email to: %s' [58916,58945]
string: 'Failed to send email to: %s' [58936,58965]
===
match
---
argument [63555,63578]
argument [63575,63598]
===
match
---
trailer [67386,67403]
trailer [67406,67423]
===
match
---
parameters [8341,8347]
parameters [8369,8375]
===
match
---
atom_expr [10002,10013]
atom_expr [10030,10041]
===
match
---
fstring_string: operator_failures_ [56970,56988]
fstring_string: operator_failures_ [56990,57008]
===
match
---
name: task [55016,55020]
name: task [55036,55040]
===
match
---
trailer [24707,24713]
trailer [24727,24733]
===
match
---
simple_stmt [10095,10123]
simple_stmt [10123,10151]
===
match
---
number: 2 [33698,33699]
number: 2 [33718,33719]
===
match
---
string: '%Y%m%dT%H%M%S' [58686,58701]
string: '%Y%m%dT%H%M%S' [58706,58721]
===
match
---
funcdef [81472,81536]
funcdef [81492,81556]
===
match
---
name: dag_id [68551,68557]
name: dag_id [68571,68577]
===
match
---
expr_stmt [23482,23511]
expr_stmt [23502,23531]
===
match
---
simple_stmt [41103,41145]
simple_stmt [41123,41165]
===
match
---
name: self [55369,55373]
name: self [55389,55393]
===
match
---
name: partial_dag [46912,46923]
name: partial_dag [46932,46943]
===
match
---
name: task_id [10746,10753]
name: task_id [10774,10781]
===
match
---
suite [68101,68282]
suite [68121,68302]
===
match
---
decorated [59807,66170]
decorated [59827,66190]
===
match
---
operator: , [19599,19600]
operator: , [19619,19620]
===
match
---
trailer [80645,80653]
trailer [80665,80673]
===
match
---
name: get [63282,63285]
name: get [63302,63305]
===
match
---
operator: @ [80733,80734]
operator: @ [80753,80754]
===
match
---
name: XCom [24017,24021]
name: XCom [24037,24041]
===
match
---
trailer [28281,28515]
trailer [28301,28535]
===
match
---
name: session [50780,50787]
name: session [50800,50807]
===
match
---
simple_stmt [47226,47320]
simple_stmt [47246,47340]
===
match
---
parameters [81491,81497]
parameters [81511,81517]
===
match
---
suite [14828,14866]
suite [14848,14886]
===
match
---
name: schedulable_ti [47410,47424]
name: schedulable_ti [47430,47444]
===
match
---
trailer [77345,77363]
trailer [77365,77383]
===
match
---
param [25447,25459]
param [25467,25479]
===
match
---
suite [67198,67728]
suite [67218,67748]
===
match
---
atom_expr [16058,16071]
atom_expr [16078,16091]
===
match
---
simple_stmt [9959,9984]
simple_stmt [9987,10012]
===
match
---
name: airflow [66281,66288]
name: airflow [66301,66308]
===
match
---
suite [80625,80654]
suite [80645,80674]
===
match
---
param [14309,14321]
param [14329,14341]
===
match
---
name: instance [29664,29672]
name: instance [29684,29692]
===
match
---
arglist [26097,26328]
arglist [26117,26348]
===
match
---
name: DepContext [32470,32480]
name: DepContext [32490,32500]
===
match
---
string: "--mark-success" [18071,18087]
string: "--mark-success" [18091,18107]
===
match
---
comp_op [47293,47299]
comp_op [47313,47319]
===
match
---
atom_expr [61335,61354]
atom_expr [61355,61374]
===
match
---
name: dag_id [76387,76393]
name: dag_id [76407,76413]
===
match
---
string: """Returns TaskInstanceKey with provided ``try_number``""" [8649,8707]
string: """Returns TaskInstanceKey with provided ``try_number``""" [8677,8735]
===
match
---
name: key [71904,71907]
name: key [71924,71927]
===
match
---
trailer [77002,77010]
trailer [77022,77030]
===
match
---
name: self [45552,45556]
name: self [45572,45576]
===
match
---
param [81596,81609]
param [81616,81629]
===
match
---
name: path [15350,15354]
name: path [15370,15374]
===
match
---
name: hostname [12154,12162]
name: hostname [12174,12182]
===
match
---
param [69201,69210]
param [69221,69230]
===
match
---
trailer [11798,11803]
trailer [11826,11831]
===
match
---
name: email_for_state [58725,58740]
name: email_for_state [58745,58760]
===
match
---
simple_stmt [3168,3188]
simple_stmt [3196,3216]
===
match
---
argument [29012,29024]
argument [29032,29044]
===
match
---
arith_expr [34831,34852]
arith_expr [34851,34872]
===
match
---
name: bool [15843,15847]
name: bool [15863,15867]
===
match
---
name: delay [34770,34775]
name: delay [34790,34795]
===
match
---
funcdef [68031,68282]
funcdef [68051,68302]
===
match
---
operator: = [10381,10382]
operator: = [10409,10410]
===
match
---
name: send_email [72720,72730]
name: send_email [72740,72750]
===
match
---
name: dag_id [78658,78664]
name: dag_id [78678,78684]
===
match
---
simple_stmt [55990,56060]
simple_stmt [56010,56080]
===
match
---
operator: , [40258,40259]
operator: , [40278,40279]
===
match
---
name: int [33796,33799]
name: int [33816,33819]
===
match
---
expr_stmt [9855,9882]
expr_stmt [9883,9910]
===
match
---
name: SUCCESS [65347,65354]
name: SUCCESS [65367,65374]
===
match
---
tfpdef [35158,35174]
tfpdef [35178,35194]
===
match
---
trailer [30093,30099]
trailer [30113,30119]
===
match
---
atom_expr [48428,48489]
atom_expr [48448,48509]
===
match
---
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [70152,70201]
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [70172,70221]
===
match
---
trailer [23276,23282]
trailer [23296,23302]
===
match
---
name: self [44722,44726]
name: self [44742,44746]
===
match
---
operator: ** [33700,33702]
operator: ** [33720,33722]
===
match
---
name: TaskInstance [82080,82092]
name: TaskInstance [82100,82112]
===
match
---
name: log [43636,43639]
name: log [43656,43659]
===
match
---
name: state [45027,45032]
name: state [45047,45052]
===
match
---
name: math [857,861]
name: math [842,846]
===
match
---
trailer [62308,62317]
trailer [62328,62337]
===
match
---
name: str [63997,64000]
name: str [64017,64020]
===
match
---
trailer [11777,11817]
trailer [11805,11845]
===
match
---
name: session [40951,40958]
name: session [40971,40978]
===
match
---
trailer [25015,25024]
trailer [25035,25044]
===
match
---
simple_stmt [39538,39829]
simple_stmt [39558,39849]
===
match
---
funcdef [18887,19141]
funcdef [18907,19161]
===
match
---
name: next_execution_date [61599,61618]
name: next_execution_date [61619,61638]
===
match
---
expr_stmt [62095,62126]
expr_stmt [62115,62146]
===
match
---
atom_expr [33796,34071]
atom_expr [33816,34091]
===
match
---
atom_expr [80096,80104]
atom_expr [80116,80124]
===
match
---
atom_expr [51597,51616]
atom_expr [51617,51636]
===
match
---
operator: , [20337,20338]
operator: , [20357,20358]
===
match
---
parameters [66207,66213]
parameters [66227,66233]
===
match
---
name: tis [78914,78917]
name: tis [78934,78937]
===
match
---
name: mark_success [38019,38031]
name: mark_success [38039,38051]
===
match
---
trailer [40801,40809]
trailer [40821,40829]
===
match
---
trailer [70731,70738]
trailer [70751,70758]
===
match
---
operator: @ [12653,12654]
operator: @ [12673,12674]
===
match
---
name: cfg_path [16048,16056]
name: cfg_path [16068,16076]
===
match
---
operator: = [15740,15741]
operator: = [15760,15761]
===
match
---
name: self [22288,22292]
name: self [22308,22312]
===
match
---
simple_stmt [35337,35403]
simple_stmt [35357,35423]
===
match
---
parameters [81020,81026]
parameters [81040,81046]
===
match
---
name: ti [22544,22546]
name: ti [22564,22566]
===
match
---
atom_expr [41781,41794]
atom_expr [41801,41814]
===
match
---
operator: { [49343,49344]
operator: { [49363,49364]
===
match
---
operator: == [6662,6664]
operator: == [6690,6692]
===
match
---
return_stmt [77334,77369]
return_stmt [77354,77389]
===
match
---
name: prev_ds_nodash [61971,61985]
name: prev_ds_nodash [61991,62005]
===
match
---
operator: = [58206,58207]
operator: = [58226,58227]
===
match
---
name: TaskInstance [79339,79351]
name: TaskInstance [79359,79371]
===
match
---
atom_expr [62047,62085]
atom_expr [62067,62105]
===
match
---
name: session [42759,42766]
name: session [42779,42786]
===
match
---
operator: , [14256,14257]
operator: , [14276,14277]
===
match
---
atom_expr [3937,3968]
atom_expr [3965,3996]
===
match
---
tfpdef [29211,29227]
tfpdef [29231,29247]
===
match
---
comparison [21620,21654]
comparison [21640,21674]
===
match
---
trailer [21890,21896]
trailer [21910,21916]
===
match
---
name: Proxy [65271,65276]
name: Proxy [65291,65296]
===
match
---
name: self [65689,65693]
name: self [65709,65713]
===
match
---
trailer [45104,45106]
trailer [45124,45126]
===
match
---
name: jinja_context [72108,72121]
name: jinja_context [72128,72141]
===
match
---
operator: = [71667,71668]
operator: = [71687,71688]
===
match
---
trailer [10687,10706]
trailer [10715,10734]
===
match
---
not_test [11471,11512]
not_test [11499,11540]
===
match
---
atom_expr [41859,41872]
atom_expr [41879,41892]
===
match
---
atom_expr [48278,48306]
atom_expr [48298,48326]
===
match
---
fstring_start: f' [48765,48767]
fstring_start: f' [48785,48787]
===
match
---
name: session [35158,35165]
name: session [35178,35185]
===
match
---
trailer [70760,70969]
trailer [70780,70989]
===
match
---
operator: = [60701,60702]
operator: = [60721,60722]
===
match
---
simple_stmt [61259,61301]
simple_stmt [61279,61321]
===
match
---
argument [38554,38593]
argument [38574,38613]
===
match
---
suite [5159,6126]
suite [5187,6154]
===
match
---
atom_expr [74542,74567]
atom_expr [74562,74587]
===
match
---
string: "Marking success for %s on %s" [41224,41254]
string: "Marking success for %s on %s" [41244,41274]
===
match
---
name: dag_run [67860,67867]
name: dag_run [67880,67887]
===
match
---
trailer [22546,22551]
trailer [22566,22571]
===
match
---
trailer [58357,58713]
trailer [58377,58733]
===
match
---
atom_expr [53768,53781]
atom_expr [53788,53801]
===
match
---
name: stacklevel [28492,28502]
name: stacklevel [28512,28522]
===
match
---
trailer [10189,10195]
trailer [10217,10223]
===
match
---
operator: , [15532,15533]
operator: , [15552,15553]
===
match
---
name: dag_id [78961,78967]
name: dag_id [78981,78987]
===
match
---
funcdef [81156,81205]
funcdef [81176,81225]
===
match
---
expr_stmt [21821,21855]
expr_stmt [21841,21875]
===
match
---
testlist_comp [18755,18776]
testlist_comp [18775,18796]
===
match
---
name: value [51882,51887]
name: value [51902,51907]
===
match
---
operator: } [49349,49350]
operator: } [49369,49370]
===
match
---
trailer [48604,48611]
trailer [48624,48631]
===
match
---
name: self [40637,40641]
name: self [40657,40661]
===
match
---
simple_stmt [11166,11185]
simple_stmt [11194,11213]
===
match
---
simple_stmt [45466,45486]
simple_stmt [45486,45506]
===
match
---
name: staticmethod [63253,63265]
name: staticmethod [63273,63285]
===
match
---
dotted_name [2996,3042]
dotted_name [3024,3070]
===
match
---
name: create_pod_id [3050,3063]
name: create_pod_id [3078,3091]
===
match
---
name: dag_run [60554,60561]
name: dag_run [60574,60581]
===
match
---
name: try_number [70890,70900]
name: try_number [70910,70920]
===
match
---
expr_stmt [56405,56431]
expr_stmt [56425,56451]
===
match
---
operator: } [19099,19100]
operator: } [19119,19120]
===
match
---
name: provide_session [26424,26439]
name: provide_session [26444,26459]
===
match
---
operator: } [62441,62442]
operator: } [62461,62462]
===
match
---
name: pool [54259,54263]
name: pool [54279,54283]
===
match
---
name: __repr__ [63186,63194]
name: __repr__ [63206,63214]
===
match
---
suite [53826,54857]
suite [53846,54877]
===
match
---
operator: , [23961,23962]
operator: , [23981,23982]
===
match
---
raise_stmt [51042,51124]
raise_stmt [51062,51144]
===
match
---
arglist [34600,34646]
arglist [34620,34666]
===
match
---
name: max [5934,5937]
name: max [5962,5965]
===
match
---
if_stmt [18555,18601]
if_stmt [18575,18621]
===
match
---
operator: = [50169,50170]
operator: = [50189,50190]
===
match
---
atom_expr [61988,62012]
atom_expr [62008,62032]
===
match
---
operator: = [3246,3247]
operator: = [3274,3275]
===
match
---
name: self [20911,20915]
name: self [20931,20935]
===
match
---
trailer [43610,43618]
trailer [43630,43638]
===
match
---
name: State [26297,26302]
name: State [26317,26322]
===
match
---
name: UP_FOR_RESCHEDULE [39113,39130]
name: UP_FOR_RESCHEDULE [39133,39150]
===
match
---
name: value [73159,73164]
name: value [73179,73184]
===
match
---
string: "--ignore-depends-on-past" [18454,18480]
string: "--ignore-depends-on-past" [18474,18500]
===
match
---
expr_stmt [23259,23282]
expr_stmt [23279,23302]
===
match
---
return_stmt [19621,19848]
return_stmt [19641,19868]
===
match
---
name: error [54700,54705]
name: error [54720,54725]
===
match
---
suite [69212,72416]
suite [69232,72436]
===
match
---
name: self [72933,72937]
name: self [72953,72957]
===
match
---
name: dag_run [67972,67979]
name: dag_run [67992,67999]
===
match
---
name: dag_id [42927,42933]
name: dag_id [42947,42953]
===
match
---
tfpdef [4286,4314]
tfpdef [4314,4342]
===
match
---
operator: = [54125,54126]
operator: = [54145,54146]
===
match
---
comparison [82129,82166]
comparison [82149,82186]
===
match
---
string: 'execution_date' [64752,64768]
string: 'execution_date' [64772,64788]
===
match
---
atom_expr [13146,13159]
atom_expr [13166,13179]
===
match
---
param [74702,74726]
param [74722,74746]
===
match
---
name: retries [5525,5532]
name: retries [5553,5560]
===
match
---
operator: , [82231,82232]
operator: , [82251,82252]
===
match
---
suite [46009,47721]
suite [46029,47741]
===
match
---
name: _handle_reschedule [55124,55142]
name: _handle_reschedule [55144,55162]
===
match
---
trailer [22024,22033]
trailer [22044,22053]
===
match
---
dotted_name [2420,2439]
dotted_name [2405,2424]
===
match
---
name: max_tries [5941,5950]
name: max_tries [5969,5978]
===
match
---
fstring_expr [42921,42934]
fstring_expr [42941,42954]
===
match
---
name: TR [39170,39172]
name: TR [39190,39192]
===
match
---
simple_stmt [72463,72514]
simple_stmt [72483,72534]
===
match
---
comp_op [53206,53212]
comp_op [53226,53232]
===
match
---
name: BooleanClauseList [1543,1560]
name: BooleanClauseList [1528,1545]
===
match
---
atom_expr [78807,78834]
atom_expr [78827,78854]
===
match
---
decorator [19428,19438]
decorator [19448,19458]
===
match
---
trailer [64052,64056]
trailer [64072,64076]
===
match
---
trailer [7223,7230]
trailer [7251,7258]
===
match
---
name: self [24952,24956]
name: self [24972,24976]
===
match
---
trailer [11803,11807]
trailer [11831,11835]
===
match
---
funcdef [81224,81305]
funcdef [81244,81325]
===
match
---
name: execution_date [33042,33056]
name: execution_date [33062,33076]
===
match
---
name: items [7171,7176]
name: items [7199,7204]
===
match
---
trailer [60154,60167]
trailer [60174,60187]
===
match
---
decorator [56065,56082]
decorator [56085,56102]
===
match
---
trailer [40791,40817]
trailer [40811,40837]
===
match
---
name: log [22863,22866]
name: log [22883,22886]
===
match
---
name: session [28032,28039]
name: session [28052,28059]
===
match
---
name: Integer [1320,1327]
name: Integer [1305,1312]
===
match
---
name: timedelta [34668,34677]
name: timedelta [34688,34697]
===
match
---
decorated [77375,77819]
decorated [77395,77839]
===
match
---
expr_stmt [10095,10122]
expr_stmt [10123,10150]
===
match
---
dotted_name [7531,7552]
dotted_name [7559,7580]
===
match
---
simple_stmt [13205,13233]
simple_stmt [13225,13253]
===
match
---
operator: = [35976,35977]
operator: = [35996,35997]
===
match
---
name: environ [49426,49433]
name: environ [49446,49453]
===
match
---
name: dag_id [26125,26131]
name: dag_id [26145,26151]
===
match
---
simple_stmt [62590,62662]
simple_stmt [62610,62682]
===
match
---
trailer [40416,40418]
trailer [40436,40438]
===
match
---
expr_stmt [70537,70565]
expr_stmt [70557,70585]
===
match
---
atom_expr [71985,71995]
atom_expr [72005,72015]
===
match
---
operator: = [60534,60535]
operator: = [60554,60555]
===
match
---
operator: = [61769,61770]
operator: = [61789,61790]
===
match
---
trailer [43857,43872]
trailer [43877,43892]
===
match
---
name: Optional [81253,81261]
name: Optional [81273,81281]
===
match
---
name: task_id [77150,77157]
name: task_id [77170,77177]
===
match
---
atom_expr [48835,48873]
atom_expr [48855,48893]
===
match
---
operator: = [12072,12073]
operator: = [12100,12101]
===
match
---
name: stacklevel [30844,30854]
name: stacklevel [30864,30874]
===
match
---
trailer [71255,71267]
trailer [71275,71287]
===
match
---
operator: == [52616,52618]
operator: == [52636,52638]
===
match
---
expr_stmt [22020,22047]
expr_stmt [22040,22067]
===
match
---
parameters [13917,13923]
parameters [13937,13943]
===
match
---
atom_expr [6095,6108]
atom_expr [6123,6136]
===
match
---
argument [54004,54049]
argument [54024,54069]
===
match
---
name: ignore_ti_state [39782,39797]
name: ignore_ti_state [39802,39817]
===
match
---
operator: , [30798,30799]
operator: , [30818,30819]
===
match
---
suite [28111,28554]
suite [28131,28574]
===
match
---
suite [41446,41611]
suite [41466,41631]
===
match
---
trailer [3236,3245]
trailer [3264,3273]
===
match
---
name: dag [14688,14691]
name: dag [14708,14711]
===
match
---
operator: , [70801,70802]
operator: , [70821,70822]
===
match
---
operator: = [82395,82396]
operator: = [82415,82416]
===
match
---
name: cmd [18630,18633]
name: cmd [18650,18653]
===
match
---
string: "Executing %s on %s" [41336,41356]
string: "Executing %s on %s" [41356,41376]
===
match
---
trailer [21647,21654]
trailer [21667,21674]
===
match
---
name: end_date [72858,72866]
name: end_date [72878,72886]
===
match
---
expr_stmt [52918,52934]
expr_stmt [52938,52954]
===
match
---
atom_expr [56903,56920]
atom_expr [56923,56940]
===
match
---
operator: , [1093,1094]
operator: , [1078,1079]
===
match
---
fstring_expr [67682,67685]
fstring_expr [67702,67705]
===
match
---
suite [27206,27239]
suite [27226,27259]
===
match
---
operator: , [32154,32155]
operator: , [32174,32175]
===
match
---
suite [56450,56853]
suite [56470,56873]
===
match
---
name: property [18874,18882]
name: property [18894,18902]
===
match
---
name: Any [63394,63397]
name: Any [63414,63417]
===
match
---
string: """Remake the key by subtracting 1 from try number to match in memory information""" [8378,8462]
string: """Remake the key by subtracting 1 from try number to match in memory information""" [8406,8490]
===
match
---
atom_expr [22020,22033]
atom_expr [22040,22053]
===
match
---
trailer [22584,22595]
trailer [22604,22615]
===
match
---
dotted_name [82542,82563]
dotted_name [82562,82583]
===
match
---
operator: , [46767,46768]
operator: , [46787,46788]
===
match
---
name: drs [7601,7604]
name: drs [7629,7632]
===
match
---
comparison [26209,26259]
comparison [26229,26279]
===
match
---
trailer [23921,24070]
trailer [23941,24090]
===
match
---
trailer [20278,20285]
trailer [20298,20305]
===
match
---
trailer [63544,63548]
trailer [63564,63568]
===
match
---
trailer [53740,53745]
trailer [53760,53765]
===
match
---
operator: { [19091,19092]
operator: { [19111,19112]
===
match
---
trailer [4446,4457]
trailer [4474,4485]
===
match
---
name: self [81590,81594]
name: self [81610,81614]
===
match
---
atom_expr [25010,25059]
atom_expr [25030,25079]
===
match
---
name: prev_ti [29673,29680]
name: prev_ti [29693,29700]
===
match
---
operator: = [22508,22509]
operator: = [22528,22529]
===
match
---
name: dag_id [78783,78789]
name: dag_id [78803,78809]
===
match
---
name: str [79810,79813]
name: str [79830,79833]
===
match
---
string: 'core' [62536,62542]
string: 'core' [62556,62562]
===
match
---
name: ti [22076,22078]
name: ti [22096,22098]
===
match
---
name: Column [9867,9873]
name: Column [9895,9901]
===
match
---
arglist [40796,40815]
arglist [40816,40835]
===
match
---
name: task_id [21697,21704]
name: task_id [21717,21724]
===
match
---
name: self [20440,20444]
name: self [20460,20464]
===
match
---
trailer [3925,3932]
trailer [3953,3960]
===
match
---
name: priority_weight [22652,22667]
name: priority_weight [22672,22687]
===
match
---
atom_expr [21994,22007]
atom_expr [22014,22027]
===
match
---
name: Optional [73195,73203]
name: Optional [73215,73223]
===
match
---
operator: , [15375,15376]
operator: , [15395,15396]
===
match
---
suite [8369,8571]
suite [8397,8599]
===
match
---
import_from [1217,1274]
import_from [1202,1259]
===
match
---
name: following_schedule [61494,61512]
name: following_schedule [61514,61532]
===
match
---
operator: = [54233,54234]
operator: = [54253,54254]
===
match
---
name: self [51148,51152]
name: self [51168,51172]
===
match
---
arglist [58614,58643]
arglist [58634,58663]
===
match
---
fstring_expr [19770,19775]
fstring_expr [19790,19795]
===
match
---
suite [64016,64118]
suite [64036,64138]
===
match
---
trailer [18587,18600]
trailer [18607,18620]
===
match
---
expr_stmt [3214,3250]
expr_stmt [3242,3278]
===
match
---
simple_stmt [28058,28070]
simple_stmt [28078,28090]
===
match
---
param [19463,19467]
param [19483,19487]
===
match
---
operator: = [48325,48326]
operator: = [48345,48346]
===
match
---
trailer [7473,7482]
trailer [7501,7510]
===
match
---
name: self [58508,58512]
name: self [58528,58532]
===
match
---
name: session [55207,55214]
name: session [55227,55234]
===
match
---
atom_expr [6843,6856]
atom_expr [6871,6884]
===
match
---
simple_stmt [2380,2415]
simple_stmt [2365,2400]
===
match
---
testlist_comp [18136,18162]
testlist_comp [18156,18182]
===
match
---
simple_stmt [69139,69160]
simple_stmt [69159,69180]
===
match
---
trailer [30346,30357]
trailer [30366,30377]
===
match
---
trailer [63111,63115]
trailer [63131,63135]
===
match
---
trailer [80173,80186]
trailer [80193,80206]
===
match
---
string: 'ti_state_lkp' [10722,10736]
string: 'ti_state_lkp' [10750,10764]
===
match
---
tfpdef [74702,74718]
tfpdef [74722,74738]
===
match
---
name: end_date [55626,55634]
name: end_date [55646,55654]
===
match
---
name: self [40892,40896]
name: self [40912,40916]
===
match
---
name: dag_id [24311,24317]
name: dag_id [24331,24337]
===
match
---
simple_stmt [5417,5446]
simple_stmt [5445,5474]
===
match
---
operator: @ [28559,28560]
operator: @ [28579,28580]
===
match
---
name: max_tries [70926,70935]
name: max_tries [70946,70955]
===
match
---
name: integrate_macros_plugins [2161,2185]
name: integrate_macros_plugins [2146,2170]
===
match
---
atom_expr [77041,77086]
atom_expr [77061,77106]
===
match
---
argument [70823,70852]
argument [70843,70872]
===
match
---
string: 'Rescheduling task, marking task as UP_FOR_RESCHEDULE' [56004,56058]
string: 'Rescheduling task, marking task as UP_FOR_RESCHEDULE' [56024,56078]
===
match
---
trailer [18969,18984]
trailer [18989,19004]
===
match
---
file_input [787,82682]
file_input [787,82702]
===
match
---
atom [7607,7846]
atom [7635,7874]
===
match
---
name: self [19463,19467]
name: self [19483,19487]
===
match
---
operator: = [64347,64348]
operator: = [64367,64368]
===
match
---
simple_stmt [80523,80542]
simple_stmt [80543,80562]
===
match
---
trailer [71485,71487]
trailer [71505,71507]
===
match
---
fstring_start: f' [42910,42912]
fstring_start: f' [42930,42932]
===
match
---
operator: , [5950,5951]
operator: , [5978,5979]
===
match
---
dotted_name [2830,2851]
dotted_name [2858,2879]
===
match
---
name: dag_run [60121,60128]
name: dag_run [60141,60148]
===
match
---
trailer [47473,47478]
trailer [47493,47498]
===
match
---
arglist [33817,34057]
arglist [33837,34077]
===
match
---
operator: @ [81072,81073]
operator: @ [81092,81093]
===
match
---
operator: = [25454,25455]
operator: = [25474,25475]
===
match
---
operator: = [39210,39211]
operator: = [39230,39231]
===
match
---
name: enrich_errors [41645,41658]
name: enrich_errors [41665,41678]
===
match
---
string: 'html_content_template' [72224,72247]
string: 'html_content_template' [72244,72267]
===
match
---
atom_expr [14584,14597]
atom_expr [14604,14617]
===
match
---
simple_stmt [56862,56879]
simple_stmt [56882,56899]
===
match
---
name: TaskInstance [77736,77748]
name: TaskInstance [77756,77768]
===
match
---
name: self [43196,43200]
name: self [43216,43220]
===
match
---
name: DagRun [7680,7686]
name: DagRun [7708,7714]
===
match
---
simple_stmt [23895,24080]
simple_stmt [23915,24100]
===
match
---
operator: = [25008,25009]
operator: = [25028,25029]
===
match
---
trailer [48282,48304]
trailer [48302,48324]
===
match
---
name: context [51700,51707]
name: context [51720,51727]
===
match
---
atom_expr [43024,43051]
atom_expr [43044,43071]
===
match
---
dotted_name [82497,82517]
dotted_name [82517,82537]
===
match
---
expr_stmt [31938,31951]
expr_stmt [31958,31971]
===
match
---
trailer [50143,50147]
trailer [50163,50167]
===
match
---
string: 'try_number' [9817,9829]
string: 'try_number' [9845,9857]
===
match
---
string: 'Submitting %s to sensor service' [50817,50850]
string: 'Submitting %s to sensor service' [50837,50870]
===
match
---
atom_expr [21749,21768]
atom_expr [21769,21788]
===
match
---
name: self [56929,56933]
name: self [56949,56953]
===
match
---
simple_stmt [3068,3126]
simple_stmt [3096,3154]
===
match
---
operator: , [15826,15827]
operator: , [15846,15847]
===
match
---
atom_expr [79289,79308]
atom_expr [79309,79328]
===
match
---
if_stmt [60144,60635]
if_stmt [60164,60655]
===
match
---
trailer [48611,48643]
trailer [48631,48663]
===
match
---
name: globals [82402,82409]
name: globals [82422,82429]
===
match
---
trailer [56873,56878]
trailer [56893,56898]
===
match
---
return_stmt [78188,78199]
return_stmt [78208,78219]
===
match
---
trailer [57169,57173]
trailer [57189,57193]
===
match
---
fstring_end: ' [42949,42950]
fstring_end: ' [42969,42970]
===
match
---
trailer [46651,46655]
trailer [46671,46675]
===
match
---
name: self [45368,45372]
name: self [45388,45392]
===
match
---
name: defaultdict [940,951]
name: defaultdict [925,936]
===
match
---
sync_comp_for [6926,6972]
sync_comp_for [6954,7000]
===
match
---
trailer [77578,77592]
trailer [77598,77612]
===
match
---
expr_stmt [48315,48336]
expr_stmt [48335,48356]
===
match
---
name: Optional [74533,74541]
name: Optional [74553,74561]
===
match
---
operator: = [51532,51533]
operator: = [51552,51553]
===
match
---
atom_expr [29051,29092]
atom_expr [29071,29112]
===
match
---
trailer [22536,22541]
trailer [22556,22561]
===
match
---
simple_stmt [58129,58169]
simple_stmt [58149,58189]
===
match
---
trailer [47503,47527]
trailer [47523,47547]
===
match
---
return_stmt [80882,80905]
return_stmt [80902,80925]
===
match
---
name: deps [38228,38232]
name: deps [38248,38252]
===
match
---
name: render_templates [55047,55063]
name: render_templates [55067,55083]
===
match
---
name: render [71393,71399]
name: render [71413,71419]
===
match
---
return_stmt [82370,82379]
return_stmt [82390,82399]
===
match
---
name: end_date [80014,80022]
name: end_date [80034,80042]
===
match
---
name: State [52891,52896]
name: State [52911,52916]
===
match
---
suite [79787,80542]
suite [79807,80562]
===
match
---
trailer [46670,46880]
trailer [46690,46900]
===
match
---
operator: , [4757,4758]
operator: , [4785,4786]
===
match
---
argument [10998,11017]
argument [11026,11045]
===
match
---
expr_stmt [9736,9760]
expr_stmt [9764,9788]
===
match
---
name: pendulum [29837,29845]
name: pendulum [29857,29865]
===
match
---
name: verbose [38612,38619]
name: verbose [38632,38639]
===
match
---
name: self [82103,82107]
name: self [82123,82127]
===
match
---
simple_stmt [42621,42638]
simple_stmt [42641,42658]
===
match
---
name: foreign_keys [10998,11010]
name: foreign_keys [11026,11038]
===
match
---
trailer [4134,4140]
trailer [4162,4168]
===
match
---
operator: @ [80911,80912]
operator: @ [80931,80932]
===
match
---
atom_expr [29837,29854]
atom_expr [29857,29874]
===
match
---
name: self [35716,35720]
name: self [35736,35740]
===
match
---
name: bool [15814,15818]
name: bool [15834,15838]
===
match
---
name: email_on_retry [58320,58334]
name: email_on_retry [58340,58354]
===
match
---
simple_stmt [67340,67410]
simple_stmt [67360,67430]
===
match
---
name: mark_success [41180,41192]
name: mark_success [41200,41212]
===
match
---
trailer [33672,33726]
trailer [33692,33746]
===
match
---
operator: , [72247,72248]
operator: , [72267,72268]
===
match
---
operator: = [29618,29619]
operator: = [29638,29639]
===
match
---
trailer [33799,34071]
trailer [33819,34091]
===
match
---
trailer [50927,50934]
trailer [50947,50954]
===
match
---
name: refresh_from_db [44451,44466]
name: refresh_from_db [44471,44486]
===
match
---
name: state [44625,44630]
name: state [44645,44650]
===
match
---
simple_stmt [74183,74410]
simple_stmt [74203,74430]
===
match
---
if_stmt [47395,47528]
if_stmt [47415,47548]
===
match
---
simple_stmt [60021,60048]
simple_stmt [60041,60068]
===
match
---
name: ignore_depends_on_past [15711,15733]
name: ignore_depends_on_past [15731,15753]
===
match
---
atom_expr [29673,29695]
atom_expr [29693,29715]
===
match
---
atom_expr [10048,10090]
atom_expr [10076,10118]
===
match
---
name: subject [72659,72666]
name: subject [72679,72686]
===
match
---
trailer [55944,55950]
trailer [55964,55970]
===
match
---
atom_expr [29245,29272]
atom_expr [29265,29292]
===
match
---
trailer [55492,55497]
trailer [55512,55517]
===
match
---
trailer [63233,63237]
trailer [63253,63257]
===
match
---
atom_expr [79033,79234]
atom_expr [79053,79254]
===
match
---
atom_expr [9941,9953]
atom_expr [9969,9981]
===
match
---
sync_comp_for [47087,47190]
sync_comp_for [47107,47210]
===
match
---
trailer [49977,49985]
trailer [49997,50005]
===
match
---
trailer [18690,18697]
trailer [18710,18717]
===
match
---
name: loads [4135,4140]
name: loads [4163,4168]
===
match
---
simple_stmt [12440,12463]
simple_stmt [12460,12483]
===
match
---
trailer [40409,40416]
trailer [40429,40436]
===
match
---
if_stmt [53180,53366]
if_stmt [53200,53386]
===
match
---
param [35716,35721]
param [35736,35741]
===
match
---
simple_stmt [34893,35012]
simple_stmt [34913,35032]
===
match
---
operator: , [27921,27922]
operator: , [27941,27942]
===
match
---
simple_stmt [27626,27695]
simple_stmt [27646,27715]
===
match
---
string: 'email' [71946,71953]
string: 'email' [71966,71973]
===
match
---
name: Optional [59216,59224]
name: Optional [59236,59244]
===
match
---
name: min_backoff [34181,34192]
name: min_backoff [34201,34212]
===
match
---
simple_stmt [9460,9529]
simple_stmt [9488,9557]
===
match
---
trailer [28796,28801]
trailer [28816,28821]
===
match
---
operator: = [76627,76628]
operator: = [76647,76648]
===
match
---
suite [43361,44006]
suite [43381,44026]
===
match
---
atom_expr [10176,10196]
atom_expr [10204,10224]
===
match
---
dotted_name [2567,2584]
dotted_name [2552,2569]
===
match
---
name: dates [7147,7152]
name: dates [7175,7180]
===
match
---
name: AirflowSkipException [43335,43355]
name: AirflowSkipException [43355,43375]
===
match
---
name: e [50158,50159]
name: e [50178,50179]
===
match
---
simple_stmt [7882,7907]
simple_stmt [7910,7935]
===
match
---
name: _run_finished_callback [59425,59447]
name: _run_finished_callback [59445,59467]
===
match
---
simple_stmt [82537,82578]
simple_stmt [82557,82598]
===
match
---
fstring [14742,14771]
fstring [14762,14791]
===
match
---
and_test [58725,58755]
and_test [58745,58775]
===
match
---
name: open [71985,71989]
name: open [72005,72009]
===
match
---
name: conf [71879,71883]
name: conf [71899,71903]
===
match
---
decorated [81310,81375]
decorated [81330,81395]
===
match
---
operator: = [26816,26817]
operator: = [26836,26837]
===
match
---
decorated [25093,25391]
decorated [25113,25411]
===
match
---
trailer [60431,60438]
trailer [60451,60458]
===
match
---
name: defaultdict [5082,5093]
name: defaultdict [5110,5121]
===
match
---
name: property [13885,13893]
name: property [13905,13913]
===
match
---
simple_stmt [23850,23887]
simple_stmt [23870,23907]
===
match
---
simple_stmt [11741,11818]
simple_stmt [11769,11846]
===
match
---
arglist [39197,39218]
arglist [39217,39238]
===
match
---
name: pool_slots [22569,22579]
name: pool_slots [22589,22599]
===
match
---
name: dag_id [6655,6661]
name: dag_id [6683,6689]
===
match
---
operator: = [42766,42767]
operator: = [42786,42787]
===
match
---
name: dr [26976,26978]
name: dr [26996,26998]
===
match
---
param [13282,13287]
param [13302,13307]
===
match
---
fstring [56968,57005]
fstring [56988,57025]
===
match
---
operator: , [48626,48627]
operator: , [48646,48647]
===
match
---
comparison [6744,6779]
comparison [6772,6807]
===
match
---
arglist [40073,40299]
arglist [40093,40319]
===
match
---
suite [56312,59085]
suite [56332,59105]
===
match
---
trailer [67879,67884]
trailer [67899,67904]
===
match
---
operator: @ [15473,15474]
operator: @ [15493,15494]
===
match
---
simple_stmt [9765,9792]
simple_stmt [9793,9820]
===
match
---
suite [4112,4147]
suite [4140,4175]
===
match
---
operator: , [11641,11642]
operator: , [11669,11670]
===
match
---
name: UtcDateTime [10222,10233]
name: UtcDateTime [10250,10261]
===
match
---
name: merge [40959,40964]
name: merge [40979,40984]
===
match
---
expr_stmt [5334,5354]
expr_stmt [5362,5382]
===
match
---
name: dagrun [7546,7552]
name: dagrun [7574,7580]
===
match
---
name: render_templates [68035,68051]
name: render_templates [68055,68071]
===
match
---
atom_expr [20303,20322]
atom_expr [20323,20342]
===
match
---
atom_expr [24904,24922]
atom_expr [24924,24942]
===
match
---
trailer [65693,65703]
trailer [65713,65723]
===
match
---
name: dag [26843,26846]
name: dag [26863,26866]
===
match
---
operator: -> [30416,30418]
operator: -> [30436,30438]
===
match
---
name: qry [82289,82292]
name: qry [82309,82312]
===
match
---
dotted_name [3288,3313]
dotted_name [3316,3341]
===
match
---
name: seconds [34678,34685]
name: seconds [34698,34705]
===
match
---
trailer [48856,48873]
trailer [48876,48893]
===
match
---
name: job_id [15974,15980]
name: job_id [15994,16000]
===
match
---
suite [18429,18483]
suite [18449,18503]
===
match
---
trailer [44124,44143]
trailer [44144,44163]
===
match
---
trailer [6113,6125]
trailer [6141,6153]
===
match
---
name: state [65488,65493]
name: state [65508,65513]
===
match
---
name: pool [42724,42728]
name: pool [42744,42748]
===
match
---
operator: , [2365,2366]
operator: , [2350,2351]
===
match
---
simple_stmt [35020,35111]
simple_stmt [35040,35131]
===
match
---
name: self [19409,19413]
name: self [19429,19433]
===
match
---
name: ignore_all_deps [15102,15117]
name: ignore_all_deps [15122,15137]
===
match
---
arglist [77630,77772]
arglist [77650,77792]
===
match
---
tfpdef [63065,63074]
tfpdef [63085,63094]
===
match
---
name: info [50812,50816]
name: info [50832,50836]
===
match
---
expr_stmt [43592,43618]
expr_stmt [43612,43638]
===
match
---
trailer [18526,18533]
trailer [18546,18553]
===
match
---
if_stmt [57055,57122]
if_stmt [57075,57142]
===
match
---
tfpdef [63303,63312]
tfpdef [63323,63332]
===
match
---
atom_expr [33008,33019]
atom_expr [33028,33039]
===
match
---
trailer [13151,13159]
trailer [13171,13179]
===
match
---
trailer [40723,40735]
trailer [40743,40755]
===
match
---
name: try_number [22293,22303]
name: try_number [22313,22323]
===
match
---
trailer [53338,53356]
trailer [53358,53376]
===
match
---
name: delete [24071,24077]
name: delete [24091,24097]
===
match
---
trailer [78062,78081]
trailer [78082,78101]
===
match
---
name: String [10390,10396]
name: String [10418,10424]
===
match
---
trailer [61670,61682]
trailer [61690,61702]
===
match
---
simple_stmt [25932,25949]
simple_stmt [25952,25969]
===
match
---
decorator [29702,29719]
decorator [29722,29739]
===
match
---
atom_expr [11135,11148]
atom_expr [11163,11176]
===
match
---
trailer [12375,12379]
trailer [12395,12399]
===
match
---
number: 1 [5595,5596]
number: 1 [5623,5624]
===
match
---
operator: = [69085,69086]
operator: = [69105,69106]
===
match
---
trailer [71521,71766]
trailer [71541,71786]
===
match
---
string: """Run TaskInstance""" [53835,53857]
string: """Run TaskInstance""" [53855,53877]
===
match
---
trailer [33708,33719]
trailer [33728,33739]
===
match
---
operator: , [50488,50489]
operator: , [50508,50509]
===
match
---
atom_expr [34727,34752]
atom_expr [34747,34772]
===
match
---
operator: = [54972,54973]
operator: = [54992,54993]
===
match
---
name: has_option [71884,71894]
name: has_option [71904,71914]
===
match
---
name: key [81398,81401]
name: key [81418,81421]
===
match
---
atom_expr [69031,69062]
atom_expr [69051,69082]
===
match
---
suite [44705,44801]
suite [44725,44821]
===
match
---
name: context [48121,48128]
name: context [48141,48148]
===
match
---
name: String [9905,9911]
name: String [9933,9939]
===
match
---
atom_expr [22564,22579]
atom_expr [22584,22599]
===
match
---
suite [51979,52324]
suite [51999,52344]
===
match
---
string: "Exporting the following env vars:\n%s" [49273,49312]
string: "Exporting the following env vars:\n%s" [49293,49332]
===
match
---
if_stmt [32179,32215]
if_stmt [32199,32235]
===
match
---
name: RUNNING [5189,5196]
name: RUNNING [5217,5224]
===
match
---
operator: = [15287,15288]
operator: = [15307,15308]
===
match
---
operator: @ [41616,41617]
operator: @ [41636,41637]
===
match
---
name: Stats [42899,42904]
name: Stats [42919,42924]
===
match
---
name: Context [68076,68083]
name: Context [68096,68103]
===
match
---
atom_expr [53119,53137]
atom_expr [53139,53157]
===
match
---
trailer [10848,10869]
trailer [10876,10897]
===
match
---
import_from [2220,2251]
import_from [2205,2236]
===
match
---
argument [53930,53945]
argument [53950,53965]
===
match
---
name: clear_xcom_data [23633,23648]
name: clear_xcom_data [23653,23668]
===
match
---
not_test [47398,47433]
not_test [47418,47453]
===
match
---
trailer [18822,18848]
trailer [18842,18868]
===
match
---
if_stmt [71876,72045]
if_stmt [71896,72065]
===
match
---
name: tis [7513,7516]
name: tis [7541,7544]
===
match
---
atom_expr [3198,3212]
atom_expr [3226,3240]
===
match
---
name: XCom [76980,76984]
name: XCom [77000,77004]
===
match
---
name: execution_date [12006,12020]
name: execution_date [12034,12048]
===
match
---
operator: , [81608,81609]
operator: , [81628,81629]
===
match
---
trailer [47284,47292]
trailer [47304,47312]
===
match
---
name: error_fd [54609,54617]
name: error_fd [54629,54637]
===
match
---
name: task_ids [76577,76585]
name: task_ids [76597,76605]
===
match
---
name: int [8614,8617]
name: int [8642,8645]
===
match
---
operator: , [4031,4032]
operator: , [4059,4060]
===
match
---
name: context [49545,49552]
name: context [49565,49572]
===
match
---
name: data [4141,4145]
name: data [4169,4173]
===
match
---
trailer [43297,43300]
trailer [43317,43320]
===
match
---
name: iso [19226,19229]
name: iso [19246,19249]
===
match
---
operator: -= [55923,55925]
operator: -= [55943,55945]
===
match
---
atom_expr [77061,77073]
atom_expr [77081,77093]
===
match
---
atom_expr [23272,23282]
atom_expr [23292,23302]
===
match
---
name: query [7382,7387]
name: query [7410,7415]
===
match
---
operator: = [63398,63399]
operator: = [63418,63419]
===
match
---
comparison [26097,26131]
comparison [26117,26151]
===
match
---
funcdef [64131,64188]
funcdef [64151,64208]
===
match
---
name: session [29619,29626]
name: session [29639,29646]
===
match
---
atom_expr [33346,33381]
atom_expr [33366,33401]
===
match
---
name: raw [77851,77854]
name: raw [77871,77874]
===
match
---
return_stmt [4092,4103]
return_stmt [4120,4131]
===
match
---
atom [69757,70101]
atom [69777,70121]
===
match
---
name: handle_failure_with_callback [59115,59143]
name: handle_failure_with_callback [59135,59163]
===
match
---
name: task_id [49043,49050]
name: task_id [49063,49070]
===
match
---
tfpdef [35960,35975]
tfpdef [35980,35995]
===
match
---
name: Integer [9975,9982]
name: Integer [10003,10010]
===
match
---
name: task [25965,25969]
name: task [25985,25989]
===
match
---
operator: , [51152,51153]
operator: , [51172,51173]
===
match
---
name: pod_mutation_hook [69040,69057]
name: pod_mutation_hook [69060,69077]
===
match
---
operator: , [73169,73170]
operator: , [73189,73190]
===
match
---
param [74523,74576]
param [74543,74596]
===
match
---
name: Stats [56957,56962]
name: Stats [56977,56982]
===
match
---
tfpdef [53762,53781]
tfpdef [53782,53801]
===
match
---
trailer [77694,77702]
trailer [77714,77722]
===
match
---
name: self [43537,43541]
name: self [43557,43561]
===
match
---
name: job [82505,82508]
name: job [82525,82528]
===
match
---
name: load_error_file [3903,3918]
name: load_error_file [3931,3946]
===
match
---
string: """         The execution date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29282,29497]
string: """         The execution date from property previous_ti_success.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [29302,29517]
===
match
---
string: "at task runtime. Attempt %s of " [40143,40176]
string: "at task runtime. Attempt %s of " [40163,40196]
===
match
---
operator: { [42921,42922]
operator: { [42941,42942]
===
match
---
trailer [50355,50357]
trailer [50375,50377]
===
match
---
name: error [4669,4674]
name: error [4697,4702]
===
match
---
name: self [24749,24753]
name: self [24769,24773]
===
match
---
name: exception [69485,69494]
name: exception [69505,69514]
===
match
---
name: session [59040,59047]
name: session [59060,59067]
===
match
---
simple_stmt [52300,52324]
simple_stmt [52320,52344]
===
match
---
name: str [8165,8168]
name: str [8193,8196]
===
match
---
name: self [29577,29581]
name: self [29597,29601]
===
match
---
string: '-' [62367,62370]
string: '-' [62387,62390]
===
match
---
name: log_filepath [18891,18903]
name: log_filepath [18911,18923]
===
match
---
name: context [52855,52862]
name: context [52875,52882]
===
match
---
simple_stmt [77907,77922]
simple_stmt [77927,77942]
===
match
---
and_test [29643,29696]
and_test [29663,29716]
===
match
---
simple_stmt [10201,10235]
simple_stmt [10229,10263]
===
match
---
comparison [6652,6671]
comparison [6680,6699]
===
match
---
name: error [56846,56851]
name: error [56866,56871]
===
match
---
decorator [74415,74432]
decorator [74435,74452]
===
match
---
operator: = [40906,40907]
operator: = [40926,40927]
===
match
---
for_stmt [32491,32950]
for_stmt [32511,32970]
===
match
---
name: timezone [2406,2414]
name: timezone [2391,2399]
===
match
---
expr_stmt [50866,50892]
expr_stmt [50886,50912]
===
match
---
expr_stmt [55906,55927]
expr_stmt [55926,55947]
===
match
---
expr_stmt [40826,40852]
expr_stmt [40846,40872]
===
match
---
atom_expr [8521,8540]
atom_expr [8549,8568]
===
match
---
arglist [20303,20460]
arglist [20323,20480]
===
match
---
operator: -> [29825,29827]
operator: -> [29845,29847]
===
match
---
sync_comp_for [7135,7178]
sync_comp_for [7163,7206]
===
match
---
atom_expr [18523,18546]
atom_expr [18543,18566]
===
match
---
simple_stmt [5048,5061]
simple_stmt [5076,5089]
===
match
---
trailer [7418,7427]
trailer [7446,7455]
===
match
---
decorator [8124,8134]
decorator [8152,8162]
===
match
---
name: provide_session [45711,45726]
name: provide_session [45731,45746]
===
match
---
name: in_ [6883,6886]
name: in_ [6911,6914]
===
match
---
trailer [19242,19257]
trailer [19262,19277]
===
match
---
simple_stmt [61463,61534]
simple_stmt [61483,61554]
===
match
---
name: DepContext [31716,31726]
name: DepContext [31736,31746]
===
match
---
atom_expr [9477,9509]
atom_expr [9505,9537]
===
match
---
name: info [43640,43644]
name: info [43660,43664]
===
match
---
simple_stmt [80260,80295]
simple_stmt [80280,80315]
===
match
---
operator: } [19399,19400]
operator: } [19419,19420]
===
match
---
atom_expr [46692,46721]
atom_expr [46712,46741]
===
match
---
name: update [62488,62494]
name: update [62508,62514]
===
match
---
name: state [37798,37803]
name: state [37818,37823]
===
match
---
suite [80698,80728]
suite [80718,80748]
===
match
---
name: all [78945,78948]
name: all [78965,78968]
===
match
---
operator: , [1081,1082]
operator: , [1066,1067]
===
match
---
trailer [33350,33355]
trailer [33370,33375]
===
match
---
if_stmt [18491,18547]
if_stmt [18511,18567]
===
match
---
string: "--ignore-all-dependencies" [18286,18313]
string: "--ignore-all-dependencies" [18306,18333]
===
match
---
string: 'ds' [64694,64698]
string: 'ds' [64714,64718]
===
match
---
string: "airflow" [17973,17982]
string: "airflow" [17993,18002]
===
match
---
operator: , [62121,62122]
operator: , [62141,62142]
===
match
---
simple_stmt [50803,50858]
simple_stmt [50823,50878]
===
match
---
arglist [71565,71734]
arglist [71585,71754]
===
match
---
trailer [65433,65522]
trailer [65453,65542]
===
match
---
number: 1 [40739,40740]
number: 1 [40759,40760]
===
match
---
trailer [60405,60415]
trailer [60425,60435]
===
match
---
suite [18799,18849]
suite [18819,18869]
===
match
---
trailer [26124,26131]
trailer [26144,26151]
===
match
---
trailer [7414,7418]
trailer [7442,7446]
===
match
---
atom_expr [58947,58957]
atom_expr [58967,58977]
===
match
---
name: task [53183,53187]
name: task [53203,53207]
===
match
---
name: self [15014,15018]
name: self [15034,15038]
===
match
---
atom_expr [77706,77718]
atom_expr [77726,77738]
===
match
---
operator: , [41254,41255]
operator: , [41274,41275]
===
match
---
name: self [24890,24894]
name: self [24910,24914]
===
match
---
atom_expr [73195,73213]
atom_expr [73215,73233]
===
match
---
atom_expr [82350,82361]
atom_expr [82370,82381]
===
match
---
fstring [48765,48819]
fstring [48785,48839]
===
match
---
name: test_mode [12593,12602]
name: test_mode [12613,12622]
===
match
---
atom_expr [65410,65522]
atom_expr [65430,65542]
===
match
---
operator: , [37540,37541]
operator: , [37560,37561]
===
match
---
operator: = [45906,45907]
operator: = [45926,45927]
===
match
---
dotted_name [1833,1852]
dotted_name [1818,1837]
===
match
---
name: context [51154,51161]
name: context [51174,51181]
===
match
---
or_test [24858,24922]
or_test [24878,24942]
===
match
---
name: utils [2575,2580]
name: utils [2560,2565]
===
match
---
name: html_content_err [72283,72299]
name: html_content_err [72303,72319]
===
match
---
simple_stmt [76445,76688]
simple_stmt [76465,76708]
===
match
---
name: utils [2838,2843]
name: utils [2866,2871]
===
match
---
suite [5614,5977]
suite [5642,6005]
===
match
---
name: self [42646,42650]
name: self [42666,42670]
===
match
---
name: Stats [50688,50693]
name: Stats [50708,50713]
===
match
---
atom_expr [43853,43890]
atom_expr [43873,43910]
===
match
---
trailer [64792,64807]
trailer [64812,64827]
===
match
---
trailer [58749,58755]
trailer [58769,58775]
===
match
---
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [69771,69820]
string: 'Try {{try_number}} out of {{max_tries + 1}}<br>' [69791,69840]
===
match
---
parameters [41433,41445]
parameters [41453,41465]
===
match
---
string: "{}#{}#{}#{}" [33851,33864]
string: "{}#{}#{}#{}" [33871,33884]
===
match
---
number: 0 [26358,26359]
number: 0 [26378,26379]
===
match
---
trailer [79135,79150]
trailer [79155,79170]
===
match
---
tfpdef [3919,3932]
tfpdef [3947,3960]
===
match
---
import_from [1924,1968]
import_from [1909,1953]
===
match
---
operator: , [2770,2771]
operator: , [2798,2799]
===
match
---
atom_expr [47551,47588]
atom_expr [47571,47608]
===
match
---
operator: , [64873,64874]
operator: , [64893,64894]
===
match
---
operator: , [1103,1104]
operator: , [1088,1089]
===
match
---
trailer [62594,62629]
trailer [62614,62649]
===
match
---
trailer [53062,53082]
trailer [53082,53102]
===
match
---
name: and_ [1349,1353]
name: and_ [1334,1338]
===
match
---
name: dag_id [58488,58494]
name: dag_id [58508,58514]
===
match
---
string: "-" [37979,37982]
string: "-" [37999,38002]
===
match
---
expr_stmt [82345,82361]
expr_stmt [82365,82381]
===
match
---
expr_stmt [31737,31751]
expr_stmt [31757,31771]
===
match
---
atom_expr [82631,82657]
atom_expr [82651,82677]
===
match
---
atom_expr [13298,13314]
atom_expr [13318,13334]
===
match
---
name: job_id [5300,5306]
name: job_id [5328,5334]
===
match
---
name: _task_id [82158,82166]
name: _task_id [82178,82186]
===
match
---
name: session [73230,73237]
name: session [73250,73257]
===
match
---
name: execution_date [60440,60454]
name: execution_date [60460,60474]
===
match
---
comparison [6843,6870]
comparison [6871,6898]
===
match
---
name: isoformat [19258,19267]
name: isoformat [19278,19287]
===
match
---
atom_expr [59607,59621]
atom_expr [59627,59641]
===
match
---
trailer [9940,9954]
trailer [9968,9982]
===
match
---
trailer [34677,34711]
trailer [34697,34731]
===
match
---
simple_stmt [38689,38702]
simple_stmt [38709,38722]
===
match
---
suite [4775,7953]
suite [4803,7981]
===
match
---
name: task_copy [48791,48800]
name: task_copy [48811,48820]
===
match
---
trailer [60188,60192]
trailer [60208,60212]
===
match
---
trailer [4664,4680]
trailer [4692,4708]
===
match
---
name: str [56141,56144]
name: str [56161,56164]
===
match
---
trailer [61339,61354]
trailer [61359,61374]
===
match
---
name: prev_ti [30298,30305]
name: prev_ti [30318,30325]
===
match
---
trailer [73203,73213]
trailer [73223,73233]
===
match
---
trailer [16066,16071]
trailer [16086,16091]
===
match
---
arith_expr [72917,72948]
arith_expr [72937,72968]
===
match
---
name: info [43517,43521]
name: info [43537,43541]
===
match
---
funcdef [45757,48065]
funcdef [45777,48085]
===
match
---
operator: , [7060,7061]
operator: , [7088,7089]
===
match
---
operator: , [74513,74514]
operator: , [74533,74534]
===
match
---
name: str [15926,15929]
name: str [15946,15949]
===
match
---
operator: = [63116,63117]
operator: = [63136,63137]
===
match
---
atom_expr [9968,9983]
atom_expr [9996,10011]
===
match
---
trailer [79365,79373]
trailer [79385,79393]
===
match
---
trailer [7830,7834]
trailer [7858,7862]
===
match
---
operator: , [42708,42709]
operator: , [42728,42729]
===
match
---
operator: , [28478,28479]
operator: , [28498,28499]
===
match
---
atom_expr [77138,77158]
atom_expr [77158,77178]
===
match
---
name: nullable [10015,10023]
name: nullable [10043,10051]
===
match
---
name: self [28597,28601]
name: self [28617,28621]
===
match
---
param [29795,29818]
param [29815,29838]
===
match
---
simple_stmt [48145,48178]
simple_stmt [48165,48198]
===
match
---
trailer [56603,56609]
trailer [56623,56629]
===
match
---
name: schedulable_ti [47504,47518]
name: schedulable_ti [47524,47538]
===
match
---
string: '' [59799,59801]
string: '' [59819,59821]
===
match
---
operator: = [14334,14335]
operator: = [14354,14355]
===
match
---
simple_stmt [77250,77297]
simple_stmt [77270,77317]
===
match
---
decorated [81458,81536]
decorated [81478,81556]
===
match
---
name: task_id [26067,26074]
name: task_id [26087,26094]
===
match
---
simple_stmt [24283,24371]
simple_stmt [24303,24391]
===
match
---
expr_stmt [72026,72044]
expr_stmt [72046,72064]
===
match
---
trailer [55063,55065]
trailer [55083,55085]
===
match
---
operator: , [48010,48011]
operator: , [48030,48031]
===
match
---
name: warning [40044,40051]
name: warning [40064,40071]
===
match
---
name: self [18904,18908]
name: self [18924,18928]
===
match
---
operator: ** [71297,71299]
operator: ** [71317,71319]
===
match
---
operator: , [45354,45355]
operator: , [45374,45375]
===
match
---
atom_expr [80506,80514]
atom_expr [80526,80534]
===
match
---
name: settings [69031,69039]
name: settings [69051,69059]
===
match
---
operator: = [63916,63917]
operator: = [63936,63937]
===
match
---
trailer [72937,72948]
trailer [72957,72968]
===
match
---
parameters [8149,8155]
parameters [8177,8183]
===
match
---
operator: = [9710,9711]
operator: = [9738,9739]
===
match
---
operator: = [27928,27929]
operator: = [27948,27949]
===
match
---
dotted_name [3073,3105]
dotted_name [3101,3133]
===
match
---
simple_stmt [26860,26898]
simple_stmt [26880,26918]
===
match
---
arglist [27276,27330]
arglist [27296,27350]
===
match
---
expr_stmt [4050,4066]
expr_stmt [4078,4094]
===
match
---
name: max_tries [5922,5931]
name: max_tries [5950,5959]
===
match
---
name: ti [6076,6078]
name: ti [6104,6106]
===
match
---
name: ID_LEN [10397,10403]
name: ID_LEN [10425,10431]
===
match
---
name: task [52657,52661]
name: task [52677,52681]
===
match
---
if_stmt [61596,61810]
if_stmt [61616,61830]
===
match
---
operator: = [37969,37970]
operator: = [37989,37990]
===
match
---
name: start_date [39318,39328]
name: start_date [39338,39348]
===
match
---
name: ti [5344,5346]
name: ti [5372,5374]
===
match
---
name: self [45266,45270]
name: self [45286,45290]
===
match
---
trailer [56933,56946]
trailer [56953,56966]
===
match
---
atom_expr [60423,60438]
atom_expr [60443,60458]
===
match
---
name: self [45073,45077]
name: self [45093,45097]
===
match
---
classdef [79620,82380]
classdef [79640,82400]
===
match
---
simple_stmt [21882,21899]
simple_stmt [21902,21919]
===
match
---
subscriptlist [4299,4313]
subscriptlist [4327,4341]
===
match
---
name: Stats [37834,37839]
name: Stats [37854,37859]
===
match
---
name: fmt [59779,59782]
name: fmt [59799,59802]
===
match
---
trailer [3725,3896]
trailer [3753,3924]
===
match
---
simple_stmt [54424,54671]
simple_stmt [54444,54691]
===
match
---
operator: , [44886,44887]
operator: , [44906,44907]
===
match
---
name: task_id [82142,82149]
name: task_id [82162,82169]
===
match
---
name: clear_xcom_data [48722,48737]
name: clear_xcom_data [48742,48757]
===
match
---
name: priority_weight_total [23408,23429]
name: priority_weight_total [23428,23449]
===
match
---
name: execution_date [80751,80765]
name: execution_date [80771,80785]
===
match
---
suite [58773,58814]
suite [58793,58834]
===
match
---
operator: = [43022,43023]
operator: = [43042,43043]
===
match
---
parameters [32967,32973]
parameters [32987,32993]
===
match
---
trailer [39288,39299]
trailer [39308,39319]
===
match
---
name: ignore_all_deps [38298,38313]
name: ignore_all_deps [38318,38333]
===
match
---
operator: == [78655,78657]
operator: == [78675,78677]
===
match
---
and_test [35027,35110]
and_test [35047,35130]
===
match
---
name: super [11166,11171]
name: super [11194,11199]
===
match
---
string: 'ts_nodash_with_tz' [65893,65912]
string: 'ts_nodash_with_tz' [65913,65932]
===
match
---
simple_stmt [72061,72123]
simple_stmt [72081,72143]
===
match
---
name: value [74232,74237]
name: value [74252,74257]
===
match
---
operator: = [22304,22305]
operator: = [22324,22325]
===
match
---
fstring_start: f' [50629,50631]
fstring_start: f' [50649,50651]
===
match
---
suite [11157,12463]
suite [11185,12483]
===
match
---
name: error [56444,56449]
name: error [56464,56469]
===
match
---
trailer [26827,26831]
trailer [26847,26851]
===
match
---
atom_expr [18220,18231]
atom_expr [18240,18251]
===
match
---
name: signal_handler [48628,48642]
name: signal_handler [48648,48662]
===
match
---
trailer [48519,48521]
trailer [48539,48541]
===
match
---
name: Union [59174,59179]
name: Union [59194,59199]
===
match
---
name: models [2084,2090]
name: models [2069,2075]
===
match
---
testlist_comp [26297,26325]
testlist_comp [26317,26345]
===
match
---
operator: = [70791,70792]
operator: = [70811,70812]
===
match
---
simple_stmt [23380,23430]
simple_stmt [23400,23450]
===
match
---
operator: , [56156,56157]
operator: , [56176,56177]
===
match
---
expr_stmt [33786,34071]
expr_stmt [33806,34091]
===
match
---
name: e [67587,67588]
name: e [67607,67608]
===
match
---
name: queued_by_job_id [10239,10255]
name: queued_by_job_id [10267,10283]
===
match
---
operator: , [58626,58627]
operator: , [58646,58647]
===
match
---
atom_expr [36037,36050]
atom_expr [36057,36070]
===
match
---
atom_expr [68240,68281]
atom_expr [68260,68301]
===
match
---
suite [54687,54857]
suite [54707,54877]
===
match
---
name: KeyboardInterrupt [44828,44845]
name: KeyboardInterrupt [44848,44865]
===
match
---
name: SENSING [50885,50892]
name: SENSING [50905,50912]
===
match
---
simple_stmt [29636,29697]
simple_stmt [29656,29717]
===
match
---
expr_stmt [27626,27694]
expr_stmt [27646,27714]
===
match
---
name: replace [61720,61727]
name: replace [61740,61747]
===
match
---
trailer [23979,23987]
trailer [23999,24007]
===
match
---
operator: , [53566,53567]
operator: , [53586,53587]
===
match
---
trailer [41465,41477]
trailer [41485,41497]
===
match
---
name: Column [9810,9816]
name: Column [9838,9844]
===
match
---
funcdef [51130,51918]
funcdef [51150,51938]
===
match
---
arglist [8739,8797]
arglist [8767,8825]
===
match
---
if_stmt [18403,18483]
if_stmt [18423,18503]
===
match
---
simple_stmt [73278,73899]
simple_stmt [73298,73919]
===
match
---
atom_expr [55552,55568]
atom_expr [55572,55588]
===
match
---
trailer [6075,6094]
trailer [6103,6122]
===
match
---
atom_expr [55990,56059]
atom_expr [56010,56079]
===
match
---
operator: , [21549,21550]
operator: , [21569,21570]
===
match
---
name: airflow [1974,1981]
name: airflow [1959,1966]
===
match
---
simple_stmt [63629,63858]
simple_stmt [63649,63878]
===
match
---
name: log [23855,23858]
name: log [23875,23878]
===
match
---
param [15521,15533]
param [15541,15553]
===
match
---
name: str [41790,41793]
name: str [41810,41813]
===
match
---
name: downstream_task_ids [47171,47190]
name: downstream_task_ids [47191,47210]
===
match
---
name: dag_id [79302,79308]
name: dag_id [79322,79328]
===
match
---
if_stmt [66450,67161]
if_stmt [66470,67181]
===
match
---
operator: = [62105,62106]
operator: = [62125,62126]
===
match
---
atom_expr [42628,42637]
atom_expr [42648,42657]
===
match
---
expr_stmt [37702,37732]
expr_stmt [37722,37752]
===
match
---
testlist_comp [18824,18846]
testlist_comp [18844,18866]
===
match
---
name: warning [3718,3725]
name: warning [3746,3753]
===
match
---
simple_stmt [787,805]
simple_stmt [787,805]
===
match
---
simple_stmt [18357,18395]
simple_stmt [18377,18415]
===
match
---
argument [68586,68612]
argument [68606,68632]
===
match
---
atom_expr [23403,23429]
atom_expr [23423,23449]
===
match
---
testlist_comp [49341,49392]
testlist_comp [49361,49412]
===
match
---
return_stmt [79026,79234]
return_stmt [79046,79254]
===
match
---
operator: = [69755,69756]
operator: = [69775,69776]
===
match
---
name: _queue [80492,80498]
name: _queue [80512,80518]
===
match
---
name: self [58534,58538]
name: self [58554,58558]
===
match
---
name: e [47962,47963]
name: e [47982,47983]
===
match
---
simple_stmt [61819,61834]
simple_stmt [61839,61854]
===
match
---
name: provide_session [24377,24392]
name: provide_session [24397,24412]
===
match
---
decorated [41616,45705]
decorated [41636,45725]
===
match
---
name: airflow [2031,2038]
name: airflow [2016,2023]
===
match
---
param [14144,14167]
param [14164,14187]
===
match
---
name: self [41358,41362]
name: self [41378,41382]
===
match
---
trailer [6692,7107]
trailer [6720,7135]
===
match
---
except_clause [47733,47761]
except_clause [47753,47781]
===
match
---
name: dep_context [39874,39885]
name: dep_context [39894,39905]
===
match
---
tfpdef [15580,15592]
tfpdef [15600,15612]
===
match
---
operator: -> [59873,59875]
operator: -> [59893,59895]
===
match
---
name: modded_hash [34600,34611]
name: modded_hash [34620,34631]
===
match
---
simple_stmt [19515,19560]
simple_stmt [19535,19580]
===
match
---
operator: = [14097,14098]
operator: = [14117,14118]
===
match
---
arglist [42704,42728]
arglist [42724,42748]
===
match
---
name: self [42813,42817]
name: self [42833,42837]
===
match
---
string: 'start_date' [43928,43940]
string: 'start_date' [43948,43960]
===
match
---
testlist_comp [47245,47318]
testlist_comp [47265,47338]
===
match
---
simple_stmt [2303,2380]
simple_stmt [2288,2365]
===
match
---
name: models [48199,48205]
name: models [48219,48225]
===
match
---
trailer [11292,11310]
trailer [11320,11338]
===
match
---
trailer [78896,78904]
trailer [78916,78924]
===
match
---
name: task [23272,23276]
name: task [23292,23296]
===
match
---
name: self [43284,43288]
name: self [43304,43308]
===
match
---
name: exception [56521,56530]
name: exception [56541,56550]
===
match
---
parameters [71844,71858]
parameters [71864,71878]
===
match
---
name: warnings [28268,28276]
name: warnings [28288,28296]
===
match
---
simple_stmt [59928,59952]
simple_stmt [59948,59972]
===
match
---
simple_stmt [31760,31828]
simple_stmt [31780,31848]
===
match
---
trailer [71296,71313]
trailer [71316,71333]
===
match
---
trailer [32147,32154]
trailer [32167,32174]
===
match
---
trailer [32525,32530]
trailer [32545,32550]
===
match
---
trailer [10116,10121]
trailer [10144,10149]
===
match
---
suite [51402,51542]
suite [51422,51562]
===
match
---
name: ignore_ti_state [54110,54125]
name: ignore_ti_state [54130,54145]
===
match
---
arglist [50158,50174]
arglist [50178,50194]
===
match
---
name: dag [61408,61411]
name: dag [61428,61431]
===
match
---
string: '<br>' [69510,69516]
string: '<br>' [69530,69536]
===
match
---
trailer [8756,8764]
trailer [8784,8792]
===
match
---
arglist [23935,24060]
arglist [23955,24080]
===
match
---
string: "Failed to load task run error" [4216,4247]
string: "Failed to load task run error" [4244,4275]
===
match
---
decorated [24376,25088]
decorated [24396,25108]
===
match
---
operator: = [46082,46083]
operator: = [46102,46103]
===
match
---
name: task [42621,42625]
name: task [42641,42645]
===
match
---
name: prev_attempted_tries [5955,5975]
name: prev_attempted_tries [5983,6003]
===
match
---
trailer [23954,23961]
trailer [23974,23981]
===
match
---
simple_stmt [29865,30077]
simple_stmt [29885,30097]
===
match
---
name: context [48865,48872]
name: context [48885,48892]
===
match
---
atom_expr [24088,24104]
atom_expr [24108,24124]
===
match
---
name: datetime [79896,79904]
name: datetime [79916,79924]
===
match
---
name: refresh_from_db [43542,43557]
name: refresh_from_db [43562,43577]
===
match
---
trailer [79351,79359]
trailer [79371,79379]
===
match
---
name: date [68673,68677]
name: date [68693,68697]
===
match
---
atom_expr [60184,60199]
atom_expr [60204,60219]
===
match
---
name: skippable_task_ids [47016,47034]
name: skippable_task_ids [47036,47054]
===
match
---
name: activate_dag_runs [7491,7508]
name: activate_dag_runs [7519,7536]
===
match
---
string: 'ti_failures' [57032,57045]
string: 'ti_failures' [57052,57065]
===
match
---
string: '' [62237,62239]
string: '' [62257,62259]
===
match
---
operator: , [4452,4453]
operator: , [4480,4481]
===
match
---
operator: , [63439,63440]
operator: , [63459,63460]
===
match
---
operator: } [48788,48789]
operator: } [48808,48809]
===
match
---
name: self [55327,55331]
name: self [55347,55351]
===
match
---
name: execution_date [19243,19257]
name: execution_date [19263,19277]
===
match
---
trailer [62985,62989]
trailer [63005,63009]
===
match
---
trailer [12089,12091]
trailer [12109,12111]
===
match
---
operator: , [8173,8174]
operator: , [8201,8202]
===
match
---
name: self [18965,18969]
name: self [18985,18989]
===
match
---
return_stmt [59756,59783]
return_stmt [59776,59803]
===
match
---
name: deserialize_value [77346,77363]
name: deserialize_value [77366,77383]
===
match
---
parameters [51147,51173]
parameters [51167,51193]
===
match
---
name: provide_session [50721,50736]
name: provide_session [50741,50756]
===
match
---
argument [38380,38425]
argument [38400,38445]
===
match
---
simple_stmt [53235,53273]
simple_stmt [53255,53293]
===
match
---
name: result [50594,50600]
name: result [50614,50620]
===
match
---
trailer [14691,14705]
trailer [14711,14725]
===
match
---
operator: = [14293,14294]
operator: = [14313,14314]
===
match
---
param [67772,67777]
param [67792,67797]
===
match
---
atom [18285,18314]
atom [18305,18334]
===
match
---
trailer [58915,58958]
trailer [58935,58978]
===
match
---
funcdef [81562,82380]
funcdef [81582,82400]
===
match
---
operator: } [77099,77100]
operator: } [77119,77120]
===
match
---
atom_expr [77653,77664]
atom_expr [77673,77684]
===
match
---
tfpdef [15602,15626]
tfpdef [15622,15646]
===
match
---
trailer [46989,46998]
trailer [47009,47018]
===
match
---
name: overwrite_params_with_dag_run_conf [62595,62629]
name: overwrite_params_with_dag_run_conf [62615,62649]
===
match
---
name: html_content_err [72545,72561]
name: html_content_err [72565,72581]
===
match
---
atom_expr [49663,49701]
atom_expr [49683,49721]
===
match
---
annassign [80186,80208]
annassign [80206,80228]
===
match
---
name: getboolean [45841,45851]
name: getboolean [45861,45871]
===
match
---
name: force_fail [57846,57856]
name: force_fail [57866,57876]
===
match
---
arglist [19588,19611]
arglist [19608,19631]
===
match
---
operator: = [48005,48006]
operator: = [48025,48026]
===
match
---
operator: @ [45710,45711]
operator: @ [45730,45731]
===
match
---
simple_stmt [10360,10424]
simple_stmt [10388,10452]
===
match
---
name: State [44635,44640]
name: State [44655,44660]
===
match
---
arglist [5938,5975]
arglist [5966,6003]
===
match
---
simple_stmt [24994,25060]
simple_stmt [25014,25080]
===
match
---
operator: = [11010,11011]
operator: = [11038,11039]
===
match
---
simple_stmt [24770,24789]
simple_stmt [24790,24809]
===
match
---
arglist [57101,57119]
arglist [57121,57139]
===
match
---
name: qry [21826,21829]
name: qry [21846,21849]
===
match
---
expr_stmt [79566,79617]
expr_stmt [79586,79637]
===
match
---
simple_stmt [53289,53318]
simple_stmt [53309,53338]
===
match
---
name: include_direct_upstream [46833,46856]
name: include_direct_upstream [46853,46876]
===
match
---
name: kube_config [68885,68896]
name: kube_config [68905,68916]
===
match
---
parameters [81164,81170]
parameters [81184,81190]
===
match
---
operator: @ [24376,24377]
operator: @ [24396,24397]
===
match
---
name: state [80099,80104]
name: state [80119,80124]
===
match
---
expr_stmt [60644,60689]
expr_stmt [60664,60709]
===
match
---
name: self [42738,42742]
name: self [42758,42762]
===
match
---
name: get_email_subject_content [69169,69194]
name: get_email_subject_content [69189,69214]
===
match
---
name: fd [4022,4024]
name: fd [4050,4052]
===
match
---
number: 1 [71686,71687]
number: 1 [71706,71707]
===
match
---
simple_stmt [64167,64188]
simple_stmt [64187,64208]
===
match
---
simple_stmt [43068,43129]
simple_stmt [43088,43149]
===
match
---
name: task [5417,5421]
name: task [5445,5449]
===
match
---
simple_stmt [82631,82682]
simple_stmt [82651,82702]
===
match
---
name: dag_id [35495,35501]
name: dag_id [35515,35521]
===
match
---
atom_expr [13132,13142]
atom_expr [13152,13162]
===
match
---
parameters [81243,81249]
parameters [81263,81269]
===
match
---
name: downstream_task_ids [46702,46721]
name: downstream_task_ids [46722,46741]
===
match
---
fstring_string: &task_id= [19377,19386]
fstring_string: &task_id= [19397,19406]
===
match
---
trailer [50623,50628]
trailer [50643,50648]
===
match
---
atom_expr [47402,47433]
atom_expr [47422,47453]
===
match
---
name: dr [7919,7921]
name: dr [7947,7949]
===
match
---
tfpdef [73141,73149]
tfpdef [73161,73169]
===
match
---
name: str [56263,56266]
name: str [56283,56286]
===
match
---
name: bool [41751,41755]
name: bool [41771,41775]
===
match
---
operator: , [45446,45447]
operator: , [45466,45467]
===
match
---
name: self [72917,72921]
name: self [72937,72941]
===
match
---
atom_expr [23356,23371]
atom_expr [23376,23391]
===
match
---
atom_expr [79102,79164]
atom_expr [79122,79184]
===
match
---
name: self [32078,32082]
name: self [32098,32102]
===
match
---
operator: = [46910,46911]
operator: = [46930,46931]
===
match
---
name: verbose [35730,35737]
name: verbose [35750,35757]
===
match
---
operator: , [21040,21041]
operator: , [21060,21061]
===
match
---
name: NONE [39966,39970]
name: NONE [39986,39990]
===
match
---
trailer [68075,68084]
trailer [68095,68104]
===
match
---
name: session [25447,25454]
name: session [25467,25474]
===
match
---
simple_stmt [60698,60735]
simple_stmt [60718,60755]
===
match
---
trailer [72042,72044]
trailer [72062,72064]
===
match
---
name: handle_failure [44727,44741]
name: handle_failure [44747,44761]
===
match
---
name: self [34831,34835]
name: self [34851,34855]
===
match
---
name: jinja2 [71009,71015]
name: jinja2 [71029,71035]
===
match
---
import_from [1889,1923]
import_from [1874,1908]
===
match
---
suite [76402,76436]
suite [76422,76456]
===
match
---
trailer [62494,62507]
trailer [62514,62527]
===
match
---
name: self [12122,12126]
name: self [12142,12146]
===
match
---
trailer [60603,60605]
trailer [60623,60625]
===
match
---
comparison [78669,78703]
comparison [78689,78723]
===
match
---
expr_stmt [77114,77183]
expr_stmt [77134,77203]
===
match
---
operator: , [9562,9563]
operator: , [9590,9591]
===
match
---
name: _try_number [55557,55568]
name: _try_number [55577,55588]
===
match
---
name: ignore_ti_state [15797,15812]
name: ignore_ti_state [15817,15832]
===
match
---
name: log [40599,40602]
name: log [40619,40622]
===
match
---
simple_stmt [23291,23330]
simple_stmt [23311,23350]
===
match
---
operator: , [54655,54656]
operator: , [54675,54676]
===
match
---
param [14245,14257]
param [14265,14277]
===
match
---
operator: { [33021,33022]
operator: { [33041,33042]
===
match
---
operator: = [31894,31895]
operator: = [31914,31915]
===
match
---
operator: = [46235,46236]
operator: = [46255,46256]
===
match
---
name: stats [2233,2238]
name: stats [2218,2223]
===
match
---
trailer [62175,62192]
trailer [62195,62212]
===
match
---
name: XCom [23975,23979]
name: XCom [23995,23999]
===
match
---
name: end_date [57232,57240]
name: end_date [57252,57260]
===
match
---
name: List [16089,16093]
name: List [16109,16113]
===
match
---
operator: = [38232,38233]
operator: = [38252,38253]
===
match
---
simple_stmt [35412,35580]
simple_stmt [35432,35600]
===
match
---
name: key [51861,51864]
name: key [51881,51884]
===
match
---
subscriptlist [3203,3211]
subscriptlist [3231,3239]
===
match
---
name: pool [81160,81164]
name: pool [81180,81184]
===
match
---
name: DateTime [29263,29271]
name: DateTime [29283,29291]
===
match
---
param [11096,11101]
param [11124,11129]
===
match
---
operator: = [41896,41897]
operator: = [41916,41917]
===
match
---
trailer [79133,79164]
trailer [79153,79184]
===
match
---
atom_expr [37605,37664]
atom_expr [37625,37684]
===
match
---
name: execution_date [33929,33943]
name: execution_date [33949,33963]
===
match
---
suite [74740,77370]
suite [74760,77390]
===
match
---
name: dag [14578,14581]
name: dag [14598,14601]
===
match
---
name: self [79984,79988]
name: self [80004,80008]
===
match
---
trailer [23854,23858]
trailer [23874,23878]
===
match
---
param [25441,25446]
param [25461,25466]
===
match
---
atom_expr [42784,42795]
atom_expr [42804,42815]
===
match
---
name: actual_start_date [44144,44161]
name: actual_start_date [44164,44181]
===
match
---
name: bool [53554,53558]
name: bool [53574,53578]
===
match
---
not_test [57860,57891]
not_test [57880,57911]
===
match
---
if_stmt [27175,27239]
if_stmt [27195,27259]
===
match
---
name: TaskInstance [14920,14932]
name: TaskInstance [14940,14952]
===
match
---
atom_expr [24952,24965]
atom_expr [24972,24985]
===
match
---
arglist [62536,62575]
arglist [62556,62595]
===
match
---
name: t [79003,79004]
name: t [79023,79024]
===
match
---
trailer [80368,80373]
trailer [80388,80393]
===
match
---
operator: = [12380,12381]
operator: = [12400,12401]
===
match
---
atom_expr [40280,40294]
atom_expr [40300,40314]
===
match
---
name: Sentry [2213,2219]
name: Sentry [2198,2204]
===
match
---
name: content [71850,71857]
name: content [71870,71877]
===
match
---
fstring_string: / [19100,19101]
fstring_string: / [19120,19121]
===
match
---
name: log [49974,49977]
name: log [49994,49997]
===
match
---
name: session [26508,26515]
name: session [26528,26535]
===
match
---
atom_expr [49969,50118]
atom_expr [49989,50138]
===
match
---
operator: , [52360,52361]
operator: , [52380,52381]
===
match
---
trailer [64522,64576]
trailer [64542,64596]
===
match
---
trailer [53109,53115]
trailer [53129,53135]
===
match
---
name: execution_timeout [51442,51459]
name: execution_timeout [51462,51479]
===
match
---
trailer [74127,74142]
trailer [74147,74162]
===
match
---
arglist [45142,45447]
arglist [45162,45467]
===
match
---
param [81610,81631]
param [81630,81651]
===
match
---
argument [48955,48977]
argument [48975,48997]
===
match
---
trailer [29189,29194]
trailer [29209,29214]
===
match
---
simple_stmt [51633,51639]
simple_stmt [51653,51659]
===
match
---
trailer [34034,34036]
trailer [34054,34056]
===
match
---
suite [32536,32950]
suite [32556,32970]
===
match
---
name: self [81363,81367]
name: self [81383,81387]
===
match
---
atom_expr [71009,71133]
atom_expr [71029,71153]
===
match
---
name: self [79796,79800]
name: self [79816,79820]
===
match
---
name: renderedtifields [48206,48222]
name: renderedtifields [48226,48242]
===
match
---
operator: = [76556,76557]
operator: = [76576,76577]
===
match
---
fstring_expr [19130,19135]
fstring_expr [19150,19155]
===
match
---
operator: @ [80659,80660]
operator: @ [80679,80680]
===
match
---
import_from [67260,67330]
import_from [67280,67350]
===
match
---
name: airflow [1567,1574]
name: airflow [1552,1559]
===
match
---
atom_expr [34778,34815]
atom_expr [34798,34835]
===
match
---
simple_stmt [50688,50715]
simple_stmt [50708,50735]
===
match
---
string: 'prev_execution_date_success' [65222,65251]
string: 'prev_execution_date_success' [65242,65271]
===
match
---
trailer [72921,72930]
trailer [72941,72950]
===
match
---
simple_stmt [40861,40884]
simple_stmt [40881,40904]
===
match
---
operator: , [74649,74650]
operator: , [74669,74670]
===
match
---
operator: = [80009,80010]
operator: = [80029,80030]
===
match
---
simple_stmt [3589,3603]
simple_stmt [3617,3631]
===
match
---
name: get_previous_dagrun [27886,27905]
name: get_previous_dagrun [27906,27925]
===
match
---
atom_expr [39170,39227]
atom_expr [39190,39247]
===
match
---
trailer [4064,4066]
trailer [4092,4094]
===
match
---
return_stmt [80707,80727]
return_stmt [80727,80747]
===
match
---
name: task [5520,5524]
name: task [5548,5552]
===
match
---
name: signum [48365,48371]
name: signum [48385,48391]
===
match
---
name: self [8264,8268]
name: self [8292,8296]
===
match
---
name: task_id_by_key [6050,6064]
name: task_id_by_key [6078,6092]
===
match
---
trailer [60427,60431]
trailer [60447,60451]
===
match
---
testlist_star_expr [72522,72561]
testlist_star_expr [72542,72581]
===
match
---
return_stmt [81276,81304]
return_stmt [81296,81324]
===
match
---
fstring_start: f' [56968,56970]
fstring_start: f' [56988,56990]
===
match
---
name: deserialize_value [76985,77002]
name: deserialize_value [77005,77022]
===
match
---
name: provide_session [20617,20632]
name: provide_session [20637,20652]
===
match
---
operator: = [47549,47550]
operator: = [47569,47570]
===
match
---
atom_expr [10329,10353]
atom_expr [10357,10381]
===
match
---
name: self [23520,23524]
name: self [23540,23544]
===
match
---
trailer [63130,63136]
trailer [63150,63156]
===
match
---
name: log [24118,24121]
name: log [24138,24141]
===
match
---
name: get_template_env [71802,71818]
name: get_template_env [71822,71838]
===
match
---
operator: = [53937,53938]
operator: = [53957,53958]
===
match
---
string: """Key used to identify task instance.""" [7994,8035]
string: """Key used to identify task instance.""" [8022,8063]
===
match
---
param [67786,67793]
param [67806,67813]
===
match
---
name: Optional [15917,15925]
name: Optional [15937,15945]
===
match
---
simple_stmt [60217,60248]
simple_stmt [60237,60268]
===
match
---
atom_expr [79907,79924]
atom_expr [79927,79944]
===
match
---
decorated [81072,81137]
decorated [81092,81157]
===
match
---
simple_stmt [24658,24691]
simple_stmt [24678,24711]
===
match
---
argument [71297,71312]
argument [71317,71332]
===
match
---
argument [15389,15402]
argument [15409,15422]
===
match
---
atom_expr [6954,6972]
atom_expr [6982,7000]
===
match
---
name: execution_date [27292,27306]
name: execution_date [27312,27326]
===
match
---
name: airflow [59990,59997]
name: airflow [60010,60017]
===
match
---
import_from [2505,2561]
import_from [2490,2546]
===
match
---
operator: , [22939,22940]
operator: , [22959,22960]
===
match
---
atom_expr [14709,14721]
atom_expr [14729,14741]
===
match
---
atom_expr [48886,48979]
atom_expr [48906,48999]
===
match
---
atom_expr [46642,46880]
atom_expr [46662,46900]
===
match
---
name: execution_date [24045,24059]
name: execution_date [24065,24079]
===
match
---
atom_expr [50945,50964]
atom_expr [50965,50984]
===
match
---
fstring_expr [19687,19701]
fstring_expr [19707,19721]
===
match
---
name: get_template_context [53019,53039]
name: get_template_context [53039,53059]
===
match
---
name: _try_number [81055,81066]
name: _try_number [81075,81086]
===
match
---
simple_stmt [3188,3213]
simple_stmt [3216,3241]
===
match
---
name: task [46697,46701]
name: task [46717,46721]
===
match
---
operator: @ [81380,81381]
operator: @ [81400,81401]
===
match
---
operator: = [52923,52924]
operator: = [52943,52944]
===
match
---
atom_expr [70718,70983]
atom_expr [70738,71003]
===
match
---
trailer [22104,22110]
trailer [22124,22130]
===
match
---
name: retry_delay [33323,33334]
name: retry_delay [33343,33354]
===
match
---
name: subject [71146,71153]
name: subject [71166,71173]
===
match
---
name: TR [6843,6845]
name: TR [6871,6873]
===
match
---
simple_stmt [63529,63580]
simple_stmt [63549,63600]
===
match
---
atom_expr [72564,72605]
atom_expr [72584,72625]
===
match
---
trailer [5133,5138]
trailer [5161,5166]
===
match
---
operator: * [33695,33696]
operator: * [33715,33716]
===
match
---
name: duration [22065,22073]
name: duration [22085,22093]
===
match
---
funcdef [22913,23603]
funcdef [22933,23623]
===
match
---
atom_expr [13212,13228]
atom_expr [13232,13248]
===
match
---
simple_stmt [7456,7483]
simple_stmt [7484,7511]
===
match
---
name: helpers [2477,2484]
name: helpers [2462,2469]
===
match
---
name: pendulum [61771,61779]
name: pendulum [61791,61799]
===
match
---
strings [45142,45252]
strings [45162,45272]
===
match
---
simple_stmt [30085,30134]
simple_stmt [30105,30154]
===
match
---
fstring_expr [42935,42949]
fstring_expr [42955,42969]
===
match
---
name: mark_success [54460,54472]
name: mark_success [54480,54492]
===
match
---
name: first [78385,78390]
name: first [78405,78410]
===
match
---
name: task [48130,48134]
name: task [48150,48154]
===
match
---
name: self [68240,68244]
name: self [68260,68264]
===
match
---
name: ignore_ti_state [39798,39813]
name: ignore_ti_state [39818,39833]
===
match
---
name: self [80337,80341]
name: self [80357,80361]
===
match
---
arglist [59338,59410]
arglist [59358,59430]
===
match
---
trailer [48432,48436]
trailer [48452,48456]
===
match
---
trailer [73950,73965]
trailer [73970,73985]
===
match
---
name: f [71999,72000]
name: f [72019,72020]
===
match
---
name: ignore_depends_on_past [53530,53552]
name: ignore_depends_on_past [53550,53572]
===
match
---
operator: = [33657,33658]
operator: = [33677,33678]
===
match
---
suite [58756,59001]
suite [58776,59021]
===
match
---
suite [57957,58043]
suite [57977,58063]
===
match
---
argument [65335,65354]
argument [65355,65374]
===
match
---
trailer [33317,33322]
trailer [33337,33342]
===
match
---
atom_expr [45571,45590]
atom_expr [45591,45610]
===
match
---
name: attr [41512,41516]
name: attr [41532,41536]
===
match
---
operator: = [51505,51506]
operator: = [51525,51526]
===
match
---
string: 'Host: {{ti.hostname}}<br>' [70339,70366]
string: 'Host: {{ti.hostname}}<br>' [70359,70386]
===
match
---
name: utcnow [35102,35108]
name: utcnow [35122,35128]
===
match
---
name: timer [48759,48764]
name: timer [48779,48784]
===
match
---
trailer [61228,61245]
trailer [61248,61265]
===
match
---
atom_expr [9773,9791]
atom_expr [9801,9819]
===
match
---
name: execution_date [26245,26259]
name: execution_date [26265,26279]
===
match
---
name: args [43486,43490]
name: args [43506,43510]
===
match
---
fstring_end: " [14770,14771]
fstring_end: " [14790,14791]
===
match
---
trailer [80399,80422]
trailer [80419,80442]
===
match
---
operator: - [8565,8566]
operator: - [8593,8594]
===
match
---
name: getattr [59682,59689]
name: getattr [59702,59709]
===
match
---
name: self [50774,50778]
name: self [50794,50798]
===
match
---
name: get_rendered_k8s_spec [67170,67191]
name: get_rendered_k8s_spec [67190,67211]
===
match
---
name: dep_context [31687,31698]
name: dep_context [31707,31718]
===
match
---
import_from [2252,2302]
import_from [2237,2287]
===
match
---
funcdef [80840,80906]
funcdef [80860,80926]
===
match
---
suite [32394,32950]
suite [32414,32970]
===
match
---
atom_expr [40471,40487]
atom_expr [40491,40507]
===
match
---
name: SUCCESS [43215,43222]
name: SUCCESS [43235,43242]
===
match
---
parameters [74449,74732]
parameters [74469,74752]
===
match
---
parameters [35668,36086]
parameters [35688,36106]
===
match
---
operator: , [53681,53682]
operator: , [53701,53702]
===
match
---
operator: = [68531,68532]
operator: = [68551,68552]
===
match
---
operator: = [5932,5933]
operator: = [5960,5961]
===
match
---
trailer [73025,73029]
trailer [73045,73049]
===
match
---
operator: , [77849,77850]
operator: , [77869,77870]
===
match
---
trailer [5551,5561]
trailer [5579,5589]
===
match
---
operator: = [61333,61334]
operator: = [61353,61354]
===
match
---
argument [59338,59349]
argument [59358,59369]
===
match
---
operator: , [65522,65523]
operator: , [65542,65543]
===
match
---
comparison [5171,5196]
comparison [5199,5224]
===
match
---
name: raw [77912,77915]
name: raw [77932,77935]
===
match
---
name: dr [27883,27885]
name: dr [27903,27905]
===
match
---
param [29760,29765]
param [29780,29785]
===
match
---
trailer [18062,18069]
trailer [18082,18089]
===
match
---
name: get_previous_start_date [30888,30911]
name: get_previous_start_date [30908,30931]
===
match
---
trailer [81129,81136]
trailer [81149,81156]
===
match
---
simple_stmt [34824,34853]
simple_stmt [34844,34873]
===
match
---
trailer [20245,20251]
trailer [20265,20271]
===
match
---
name: bool [36090,36094]
name: bool [36110,36114]
===
match
---
funcdef [72421,72775]
funcdef [72441,72795]
===
match
---
trailer [80098,80104]
trailer [80118,80124]
===
match
---
name: value [74226,74231]
name: value [74246,74251]
===
match
---
expr_stmt [5240,5265]
expr_stmt [5268,5293]
===
match
---
parameters [48114,48135]
parameters [48134,48155]
===
match
---
name: TaskInstance [79102,79114]
name: TaskInstance [79122,79134]
===
match
---
atom_expr [54380,54411]
atom_expr [54400,54431]
===
match
---
trailer [51366,51384]
trailer [51386,51404]
===
match
---
param [28597,28601]
param [28617,28621]
===
match
---
suite [66483,66632]
suite [66503,66652]
===
match
---
operator: == [20323,20325]
operator: == [20343,20345]
===
match
---
name: self [28105,28109]
name: self [28125,28129]
===
match
---
expr_stmt [82026,82242]
expr_stmt [82046,82262]
===
match
---
name: exception_html [70823,70837]
name: exception_html [70843,70857]
===
match
---
not_test [37769,37788]
not_test [37789,37808]
===
match
---
name: extend [18691,18697]
name: extend [18711,18717]
===
match
---
string: """Get the email subject content for exceptions.""" [69221,69272]
string: """Get the email subject content for exceptions.""" [69241,69292]
===
match
---
name: t [78646,78647]
name: t [78666,78667]
===
match
---
name: provide_session [59808,59823]
name: provide_session [59828,59843]
===
match
---
simple_stmt [64429,64487]
simple_stmt [64449,64507]
===
match
---
name: info [45124,45128]
name: info [45144,45148]
===
match
---
trailer [5524,5532]
trailer [5552,5560]
===
match
---
decorated [63252,63580]
decorated [63272,63600]
===
match
---
atom_expr [81050,81066]
atom_expr [81070,81086]
===
match
---
name: bool [35863,35867]
name: bool [35883,35887]
===
match
---
operator: , [4729,4730]
operator: , [4757,4758]
===
match
---
trailer [52609,52615]
trailer [52629,52635]
===
match
---
fstring_end: ' [45033,45034]
fstring_end: ' [45053,45054]
===
match
---
name: timezone [45089,45097]
name: timezone [45109,45117]
===
match
---
trailer [7834,7836]
trailer [7862,7864]
===
match
---
expr_stmt [22496,22519]
expr_stmt [22516,22539]
===
match
---
name: error [52240,52245]
name: error [52260,52265]
===
match
---
trailer [33990,33997]
trailer [34010,34017]
===
match
---
name: and_ [6714,6718]
name: and_ [6742,6746]
===
match
---
name: self [67404,67408]
name: self [67424,67428]
===
match
---
atom_expr [72146,72189]
atom_expr [72166,72209]
===
match
---
trailer [66435,66441]
trailer [66455,66461]
===
match
---
simple_stmt [57162,57243]
simple_stmt [57182,57263]
===
match
---
fstring_end: " [19775,19776]
fstring_end: " [19795,19796]
===
match
---
operator: , [64951,64952]
operator: , [64971,64972]
===
match
---
trailer [80718,80727]
trailer [80738,80747]
===
match
---
atom_expr [9934,9954]
atom_expr [9962,9982]
===
match
---
operator: , [57113,57114]
operator: , [57133,57134]
===
match
---
name: delete [54399,54405]
name: delete [54419,54425]
===
match
---
name: info [47886,47890]
name: info [47906,47910]
===
match
---
simple_stmt [12058,12092]
simple_stmt [12086,12112]
===
match
---
expr_stmt [12030,12049]
expr_stmt [12058,12077]
===
match
---
name: in_ [7764,7767]
name: in_ [7792,7795]
===
match
---
simple_stmt [34569,34648]
simple_stmt [34589,34668]
===
match
---
name: pool [36031,36035]
name: pool [36051,36055]
===
match
---
trailer [63164,63168]
trailer [63184,63188]
===
match
---
trailer [7701,7708]
trailer [7729,7736]
===
match
---
param [35158,35181]
param [35178,35201]
===
match
---
simple_stmt [59756,59784]
simple_stmt [59776,59804]
===
match
---
trailer [18815,18822]
trailer [18835,18842]
===
match
---
subscriptlist [59180,59194]
subscriptlist [59200,59214]
===
match
---
operator: -> [29242,29244]
operator: -> [29262,29264]
===
match
---
if_stmt [56463,56623]
if_stmt [56483,56643]
===
match
---
name: email_alert [72425,72436]
name: email_alert [72445,72456]
===
match
---
trailer [24358,24369]
trailer [24378,24389]
===
match
---
trailer [74263,74271]
trailer [74283,74291]
===
match
---
trailer [43635,43639]
trailer [43655,43659]
===
match
---
funcdef [23629,24149]
funcdef [23649,24169]
===
match
---
name: params [67998,68004]
name: params [68018,68024]
===
match
---
name: XCom [77277,77281]
name: XCom [77297,77301]
===
match
---
name: execution_date [68683,68697]
name: execution_date [68703,68717]
===
match
---
tfpdef [41704,41722]
tfpdef [41724,41742]
===
match
---
return_stmt [30279,30358]
return_stmt [30299,30378]
===
match
---
name: Column [10322,10328]
name: Column [10350,10356]
===
match
---
name: delay_backoff_in_seconds [34569,34593]
name: delay_backoff_in_seconds [34589,34613]
===
match
---
fstring_start: f" [14742,14744]
fstring_start: f" [14762,14764]
===
match
---
name: instance [62056,62064]
name: instance [62076,62084]
===
match
---
operator: , [45303,45304]
operator: , [45323,45324]
===
match
---
atom [44634,44663]
atom [44654,44683]
===
match
---
decorator [41637,41659]
decorator [41657,41679]
===
match
---
simple_stmt [3974,4018]
simple_stmt [4002,4046]
===
match
---
simple_stmt [19929,20211]
simple_stmt [19949,20231]
===
match
---
name: start_date [30347,30357]
name: start_date [30367,30377]
===
match
---
name: models [82550,82556]
name: models [82570,82576]
===
match
---
operator: = [70935,70936]
operator: = [70955,70956]
===
match
---
sync_comp_for [77027,77086]
sync_comp_for [77047,77106]
===
match
---
simple_stmt [57974,58043]
simple_stmt [57994,58063]
===
match
---
operator: , [1054,1055]
operator: , [1039,1040]
===
match
---
param [14214,14236]
param [14234,14256]
===
match
---
simple_stmt [79650,79745]
simple_stmt [79670,79765]
===
match
---
name: ignore_all_deps [39619,39634]
name: ignore_all_deps [39639,39654]
===
match
---
name: previous_ti [28093,28104]
name: previous_ti [28113,28124]
===
match
---
operator: , [37641,37642]
operator: , [37661,37662]
===
match
---
name: args [68711,68715]
name: args [68731,68735]
===
match
---
simple_stmt [52120,52154]
simple_stmt [52140,52174]
===
match
---
operator: == [54727,54729]
operator: == [54747,54749]
===
match
---
name: t [78708,78709]
name: t [78728,78729]
===
match
---
except_clause [72690,72706]
except_clause [72710,72726]
===
match
---
name: task [5483,5487]
name: task [5511,5515]
===
match
---
atom_expr [52619,52631]
atom_expr [52639,52651]
===
match
---
trailer [52656,52661]
trailer [52676,52681]
===
match
---
name: provide_session [30939,30954]
name: provide_session [30959,30974]
===
match
---
trailer [37625,37664]
trailer [37645,37684]
===
match
---
trailer [51459,51473]
trailer [51479,51493]
===
match
---
name: exc [1381,1384]
name: exc [1366,1369]
===
match
---
trailer [80144,80160]
trailer [80164,80180]
===
match
---
simple_stmt [58901,58959]
simple_stmt [58921,58979]
===
match
---
name: kubernetes [2882,2892]
name: kubernetes [2910,2920]
===
match
---
decorated [45710,48065]
decorated [45730,48085]
===
match
---
operator: = [53012,53013]
operator: = [53032,53033]
===
match
---
parameters [80684,80690]
parameters [80704,80710]
===
match
---
string: "--local" [18589,18598]
string: "--local" [18609,18618]
===
match
---
atom_expr [5213,5222]
atom_expr [5241,5250]
===
match
---
trailer [40964,40970]
trailer [40984,40990]
===
match
---
name: schedule_interval [27669,27686]
name: schedule_interval [27689,27706]
===
match
---
simple_stmt [81356,81375]
simple_stmt [81376,81395]
===
match
---
atom_expr [45115,45457]
atom_expr [45135,45477]
===
match
---
param [15947,15965]
param [15967,15985]
===
match
---
trailer [76499,76514]
trailer [76519,76534]
===
match
---
name: dag_id [19414,19420]
name: dag_id [19434,19440]
===
match
---
name: dag_id [18000,18006]
name: dag_id [18020,18026]
===
match
---
operator: = [74291,74292]
operator: = [74311,74312]
===
match
---
operator: , [43990,43991]
operator: , [44010,44011]
===
match
---
suite [56495,56561]
suite [56515,56581]
===
match
---
trailer [10792,10833]
trailer [10820,10861]
===
match
---
name: dry_run [55084,55091]
name: dry_run [55104,55111]
===
match
---
trailer [43596,43602]
trailer [43616,43622]
===
match
---
simple_stmt [12697,12954]
simple_stmt [12717,12974]
===
match
---
simple_stmt [72820,72842]
simple_stmt [72840,72862]
===
match
---
trailer [81447,81452]
trailer [81467,81472]
===
match
---
param [67192,67196]
param [67212,67216]
===
match
---
atom_expr [40979,40995]
atom_expr [40999,41015]
===
match
---
name: v [49359,49360]
name: v [49379,49380]
===
match
---
atom [3248,3250]
atom [3276,3278]
===
match
---
name: execution_date [46221,46235]
name: execution_date [46241,46255]
===
match
---
name: filter [7656,7662]
name: filter [7684,7690]
===
match
---
simple_stmt [66223,66268]
simple_stmt [66243,66288]
===
match
---
name: context [68058,68065]
name: context [68078,68085]
===
match
---
comparison [77682,77718]
comparison [77702,77738]
===
match
---
suite [4200,4248]
suite [4228,4276]
===
match
---
name: xcom_pull [74440,74449]
name: xcom_pull [74460,74469]
===
match
---
atom_expr [53334,53365]
atom_expr [53354,53385]
===
match
---
param [8596,8601]
param [8624,8629]
===
match
---
decorator [8316,8326]
decorator [8344,8354]
===
match
---
trailer [59322,59337]
trailer [59342,59357]
===
match
---
name: strftime [60875,60883]
name: strftime [60895,60903]
===
match
---
name: typing [1038,1044]
name: typing [1023,1029]
===
match
---
simple_stmt [59068,59085]
simple_stmt [59088,59105]
===
match
---
name: FAILED [57924,57930]
name: FAILED [57944,57950]
===
match
---
operator: = [51887,51888]
operator: = [51907,51908]
===
match
---
name: ValueError [73985,73995]
name: ValueError [74005,74015]
===
match
---
simple_stmt [1118,1149]
simple_stmt [1103,1134]
===
match
---
comparison [76387,76401]
comparison [76407,76421]
===
match
---
trailer [33864,33871]
trailer [33884,33891]
===
match
---
trailer [49433,49440]
trailer [49453,49460]
===
match
---
trailer [26302,26310]
trailer [26322,26330]
===
match
---
name: task [54949,54953]
name: task [54969,54973]
===
match
---
atom_expr [58344,58713]
atom_expr [58364,58733]
===
match
---
atom_expr [52925,52934]
atom_expr [52945,52954]
===
match
---
name: items [66560,66565]
name: items [66580,66585]
===
match
---
operator: , [59857,59858]
operator: , [59877,59878]
===
match
---
operator: , [72332,72333]
operator: , [72352,72353]
===
match
---
trailer [39562,39828]
trailer [39582,39848]
===
match
---
trailer [7748,7763]
trailer [7776,7791]
===
match
---
trailer [21845,21847]
trailer [21865,21867]
===
match
---
name: NamedTemporaryFile [54380,54398]
name: NamedTemporaryFile [54400,54418]
===
match
---
name: execution_date [79136,79150]
name: execution_date [79156,79170]
===
match
---
operator: , [69446,69447]
operator: , [69466,69467]
===
match
---
name: dag_run [46074,46081]
name: dag_run [46094,46101]
===
match
---
return_stmt [19332,19422]
return_stmt [19352,19442]
===
match
---
operator: = [53974,53975]
operator: = [53994,53995]
===
match
---
operator: , [33908,33909]
operator: , [33928,33929]
===
match
---
name: state [10810,10815]
name: state [10838,10843]
===
match
---
trailer [49255,49409]
trailer [49275,49429]
===
match
---
fstring_string: DAGS_FOLDER/ [14744,14756]
fstring_string: DAGS_FOLDER/ [14764,14776]
===
match
---
trailer [10633,10672]
trailer [10661,10700]
===
match
---
arglist [14963,15457]
arglist [14983,15477]
===
match
---
expr_stmt [12058,12091]
expr_stmt [12086,12111]
===
match
---
tfpdef [24417,24427]
tfpdef [24437,24447]
===
match
---
name: ti [79471,79473]
name: ti [79491,79493]
===
match
---
name: inlets [64837,64843]
name: inlets [64857,64863]
===
match
---
trailer [48556,48588]
trailer [48576,48608]
===
match
---
decorator [35116,35133]
decorator [35136,35153]
===
match
---
simple_stmt [14735,14772]
simple_stmt [14755,14792]
===
match
---
operator: , [55205,55206]
operator: , [55225,55226]
===
match
---
trailer [9947,9953]
trailer [9975,9981]
===
match
---
trailer [13302,13314]
trailer [13322,13334]
===
match
---
name: Session [1499,1506]
name: Session [1484,1491]
===
match
---
trailer [29253,29272]
trailer [29273,29292]
===
match
---
trailer [58909,58915]
trailer [58929,58935]
===
match
---
atom [25010,25043]
atom [25030,25063]
===
match
---
argument [39580,39601]
argument [39600,39621]
===
match
---
fstring_start: f" [49341,49343]
fstring_start: f" [49361,49363]
===
match
---
atom_expr [37495,37504]
atom_expr [37515,37524]
===
match
---
name: self [13862,13866]
name: self [13882,13886]
===
match
---
name: ts_nodash [62135,62144]
name: ts_nodash [62155,62164]
===
match
---
name: self [22701,22705]
name: self [22721,22725]
===
match
---
suite [32616,32950]
suite [32636,32970]
===
match
---
name: dep_status [32894,32904]
name: dep_status [32914,32924]
===
match
---
operator: , [55147,55148]
operator: , [55167,55168]
===
match
---
trailer [14813,14827]
trailer [14833,14847]
===
match
---
name: Variable [64510,64518]
name: Variable [64530,64538]
===
match
---
atom_expr [58208,58226]
atom_expr [58228,58246]
===
match
---
name: error_file [56834,56844]
name: error_file [56854,56864]
===
match
---
if_stmt [18098,18165]
if_stmt [18118,18185]
===
match
---
atom_expr [45368,45401]
atom_expr [45388,45421]
===
match
---
name: state [13137,13142]
name: state [13157,13162]
===
match
---
name: task [62495,62499]
name: task [62515,62519]
===
match
---
trailer [55747,55753]
trailer [55767,55773]
===
match
---
param [63043,63048]
param [63063,63068]
===
match
---
name: RenderedTaskInstanceFields [66388,66414]
name: RenderedTaskInstanceFields [66408,66434]
===
match
---
name: timezone [55343,55351]
name: timezone [55363,55371]
===
match
---
operator: , [39650,39651]
operator: , [39670,39671]
===
match
---
number: 0 [20542,20543]
number: 0 [20562,20563]
===
match
---
name: _run_finished_callback [54821,54843]
name: _run_finished_callback [54841,54863]
===
match
---
try_stmt [2868,3167]
try_stmt [2896,3195]
===
match
---
simple_stmt [33305,33335]
simple_stmt [33325,33355]
===
match
---
name: self [41210,41214]
name: self [41230,41234]
===
match
---
operator: , [66614,66615]
operator: , [66634,66635]
===
match
---
name: execution_date [10657,10671]
name: execution_date [10685,10699]
===
match
---
name: ti [5149,5151]
name: ti [5177,5179]
===
match
---
name: kubernetes [3004,3014]
name: kubernetes [3032,3042]
===
match
---
parameters [73117,73260]
parameters [73137,73280]
===
match
---
name: self [76495,76499]
name: self [76515,76519]
===
match
---
name: job_id [9959,9965]
name: job_id [9987,9993]
===
match
---
operator: = [71718,71719]
operator: = [71738,71739]
===
match
---
import_from [2303,2379]
import_from [2288,2364]
===
match
---
suite [14879,14904]
suite [14899,14924]
===
match
---
trailer [78015,78048]
trailer [78035,78068]
===
match
---
name: timeout [2844,2851]
name: timeout [2872,2879]
===
match
---
simple_stmt [872,886]
simple_stmt [857,871]
===
match
---
trailer [5256,5265]
trailer [5284,5293]
===
match
---
trailer [55979,55981]
trailer [55999,56001]
===
match
---
trailer [61429,61450]
trailer [61449,61470]
===
match
---
trailer [52308,52318]
trailer [52328,52338]
===
match
---
operator: , [10808,10809]
operator: , [10836,10837]
===
match
---
name: ti [5171,5173]
name: ti [5199,5201]
===
match
---
name: utcnow [42882,42888]
name: utcnow [42902,42908]
===
match
---
name: self [39042,39046]
name: self [39062,39066]
===
match
---
atom_expr [40557,40585]
atom_expr [40577,40605]
===
match
---
name: state [20545,20550]
name: state [20565,20570]
===
match
---
atom_expr [30085,30133]
atom_expr [30105,30153]
===
match
---
name: task [23403,23407]
name: task [23423,23427]
===
match
---
operator: = [27642,27643]
operator: = [27662,27663]
===
match
---
name: next_execution_date [64988,65007]
name: next_execution_date [65008,65027]
===
match
---
atom_expr [43823,43835]
atom_expr [43843,43855]
===
match
---
operator: , [8519,8520]
operator: , [8547,8548]
===
match
---
operator: = [15200,15201]
operator: = [15220,15221]
===
match
---
parameters [56104,56303]
parameters [56124,56323]
===
match
---
name: log_message [58239,58250]
name: log_message [58259,58270]
===
match
---
tfpdef [15947,15956]
tfpdef [15967,15976]
===
match
---
name: str [53741,53744]
name: str [53761,53764]
===
match
---
argument [30186,30201]
argument [30206,30221]
===
match
---
name: execution_date [11778,11792]
name: execution_date [11806,11820]
===
match
---
dotted_name [1974,2003]
dotted_name [1959,1988]
===
match
---
name: dag [27348,27351]
name: dag [27368,27371]
===
match
---
name: mark_success [14085,14097]
name: mark_success [14105,14117]
===
match
---
name: _try_number [13983,13994]
name: _try_number [14003,14014]
===
match
---
param [32362,32379]
param [32382,32399]
===
match
---
simple_stmt [44085,44108]
simple_stmt [44105,44128]
===
match
---
operator: , [56144,56145]
operator: , [56164,56165]
===
match
---
atom_expr [64832,64843]
atom_expr [64852,64863]
===
match
---
name: bool [41718,41722]
name: bool [41738,41742]
===
match
---
operator: = [24781,24782]
operator: = [24801,24802]
===
match
---
atom_expr [37702,37715]
atom_expr [37722,37735]
===
match
---
name: mark_success_url [19446,19462]
name: mark_success_url [19466,19482]
===
match
---
expr_stmt [35412,35579]
expr_stmt [35432,35599]
===
match
---
trailer [9779,9791]
trailer [9807,9819]
===
match
---
trailer [7662,7817]
trailer [7690,7845]
===
match
---
simple_stmt [32403,32433]
simple_stmt [32423,32453]
===
match
---
name: self [59967,59971]
name: self [59987,59991]
===
match
---
suite [64150,64188]
suite [64170,64208]
===
match
---
trailer [82359,82361]
trailer [82379,82381]
===
match
---
suite [3701,3897]
suite [3729,3925]
===
match
---
operator: = [31015,31016]
operator: = [31035,31036]
===
match
---
name: schedulable_tis [47358,47373]
name: schedulable_tis [47378,47393]
===
match
---
operator: , [41470,41471]
operator: , [41490,41491]
===
match
---
atom_expr [53058,53091]
atom_expr [53078,53111]
===
match
---
name: os [4033,4035]
name: os [4061,4063]
===
match
---
name: log [41215,41218]
name: log [41235,41238]
===
match
---
expr_stmt [9887,9918]
expr_stmt [9915,9946]
===
match
---
operator: , [1683,1684]
operator: , [1668,1669]
===
match
---
simple_stmt [4435,4458]
simple_stmt [4463,4486]
===
match
---
or_test [31701,31728]
or_test [31721,31748]
===
match
---
string: 'Log file: {{ti.log_filepath}}<br>' [70379,70414]
string: 'Log file: {{ti.log_filepath}}<br>' [70399,70434]
===
match
---
name: dag_id [33013,33019]
name: dag_id [33033,33039]
===
match
---
simple_stmt [44865,44922]
simple_stmt [44885,44942]
===
match
---
simple_stmt [9887,9919]
simple_stmt [9915,9947]
===
match
---
name: jinja_env [72068,72077]
name: jinja_env [72088,72097]
===
match
---
name: execution_date [26222,26236]
name: execution_date [26242,26256]
===
match
---
atom [35417,35579]
atom [35437,35599]
===
match
---
name: session [57085,57092]
name: session [57105,57112]
===
match
---
fstring_string: ]> [33071,33073]
fstring_string: ]> [33091,33093]
===
match
---
operator: , [76594,76595]
operator: , [76614,76615]
===
match
---
funcdef [77396,77819]
funcdef [77416,77839]
===
match
---
name: TaskInstance [79773,79785]
name: TaskInstance [79793,79805]
===
match
---
name: full_filepath [14852,14865]
name: full_filepath [14872,14885]
===
match
---
with_stmt [48748,50609]
with_stmt [48768,50629]
===
match
---
simple_stmt [11325,11371]
simple_stmt [11353,11399]
===
match
---
term [37979,37987]
term [37999,38007]
===
match
---
simple_stmt [18919,18951]
simple_stmt [18939,18971]
===
match
---
name: set_error_file [56819,56833]
name: set_error_file [56839,56853]
===
match
---
string: '-' [62232,62235]
string: '-' [62252,62255]
===
match
---
atom_expr [9898,9918]
atom_expr [9926,9946]
===
match
---
atom_expr [54816,54856]
atom_expr [54836,54876]
===
match
---
argument [54277,54292]
argument [54297,54312]
===
match
---
name: set_state [24401,24410]
name: set_state [24421,24430]
===
match
---
name: strftime [59770,59778]
name: strftime [59790,59798]
===
match
---
simple_stmt [46898,46924]
simple_stmt [46918,46944]
===
match
---
name: log [40562,40565]
name: log [40582,40585]
===
match
---
atom_expr [72036,72044]
atom_expr [72056,72064]
===
match
---
name: dag [5378,5381]
name: dag [5406,5409]
===
match
---
simple_stmt [20531,20551]
simple_stmt [20551,20571]
===
match
---
name: merge [25076,25081]
name: merge [25096,25101]
===
match
---
name: models [35350,35356]
name: models [35370,35376]
===
match
---
name: tis [5155,5158]
name: tis [5183,5186]
===
match
---
name: date_attr [59696,59705]
name: date_attr [59716,59725]
===
match
---
funcdef [29119,29697]
funcdef [29139,29717]
===
match
---
atom_expr [79250,79490]
atom_expr [79270,79510]
===
match
---
trailer [80081,80088]
trailer [80101,80108]
===
match
---
expr_stmt [9988,10030]
expr_stmt [10016,10058]
===
match
---
expr_stmt [57905,57930]
expr_stmt [57925,57950]
===
match
---
trailer [51516,51524]
trailer [51536,51544]
===
match
---
name: Exception [3957,3966]
name: Exception [3985,3994]
===
match
---
name: render [71195,71201]
name: render [71215,71221]
===
match
---
operator: -> [73261,73263]
operator: -> [73281,73283]
===
match
---
name: task [23320,23324]
name: task [23340,23344]
===
match
---
name: set_error_file [4254,4268]
name: set_error_file [4282,4296]
===
match
---
atom_expr [28606,28630]
atom_expr [28626,28650]
===
match
---
simple_stmt [55074,55094]
simple_stmt [55094,55114]
===
match
---
operator: , [14235,14236]
operator: , [14255,14256]
===
match
---
trailer [77642,77649]
trailer [77662,77669]
===
match
---
name: task [45007,45011]
name: task [45027,45031]
===
match
---
simple_stmt [78368,78406]
simple_stmt [78388,78426]
===
match
---
atom_expr [79134,79150]
atom_expr [79154,79170]
===
match
---
name: info [58353,58357]
name: info [58373,58377]
===
match
---
param [64252,64262]
param [64272,64282]
===
match
---
name: primary_key [9511,9522]
name: primary_key [9539,9550]
===
match
---
name: dag_run [61221,61228]
name: dag_run [61241,61248]
===
match
---
name: state [27929,27934]
name: state [27949,27954]
===
match
---
suite [67885,68026]
suite [67905,68046]
===
match
---
atom_expr [78385,78405]
atom_expr [78405,78425]
===
match
---
name: self [74292,74296]
name: self [74312,74316]
===
match
---
name: task_id [9460,9467]
name: task_id [9488,9495]
===
match
---
testlist_comp [18642,18656]
testlist_comp [18662,18676]
===
match
---
simple_stmt [72992,73013]
simple_stmt [73012,73033]
===
match
---
name: state [52610,52615]
name: state [52630,52635]
===
match
---
trailer [14932,14949]
trailer [14952,14969]
===
match
---
operator: { [76946,76947]
operator: { [76966,76967]
===
match
---
name: self [44620,44624]
name: self [44640,44644]
===
match
---
if_stmt [49660,50358]
if_stmt [49680,50378]
===
match
---
atom_expr [33924,33943]
atom_expr [33944,33963]
===
match
---
number: 20 [9787,9789]
number: 20 [9815,9817]
===
match
---
atom_expr [11984,12003]
atom_expr [12012,12031]
===
match
---
name: str [11144,11147]
name: str [11172,11175]
===
match
---
atom_expr [54716,54726]
atom_expr [54736,54746]
===
match
---
trailer [68798,68814]
trailer [68818,68834]
===
match
---
atom_expr [11935,11974]
atom_expr [11963,12002]
===
match
---
operator: = [38297,38298]
operator: = [38317,38318]
===
match
---
trailer [43541,43557]
trailer [43561,43577]
===
match
---
fstring_expr [45006,45020]
fstring_expr [45026,45040]
===
match
---
operator: , [10802,10803]
operator: , [10830,10831]
===
match
---
name: TR [6652,6654]
name: TR [6680,6682]
===
match
---
name: merge [40443,40448]
name: merge [40463,40468]
===
match
---
param [15836,15856]
param [15856,15876]
===
match
---
suite [26979,27332]
suite [26999,27352]
===
match
---
name: task [22941,22945]
name: task [22961,22965]
===
match
---
name: try_number [59593,59603]
name: try_number [59613,59623]
===
match
---
name: dep_context [39886,39897]
name: dep_context [39906,39917]
===
match
---
operator: = [73214,73215]
operator: = [73234,73235]
===
match
---
atom_expr [46184,46195]
atom_expr [46204,46215]
===
match
---
name: run_id [65546,65552]
name: run_id [65566,65572]
===
match
---
trailer [6094,6109]
trailer [6122,6137]
===
match
---
trailer [44640,44648]
trailer [44660,44668]
===
match
---
name: one [46335,46338]
name: one [46355,46358]
===
match
---
suite [22818,22849]
suite [22838,22869]
===
match
---
operator: = [69479,69480]
operator: = [69499,69500]
===
match
---
name: test_mode [56422,56431]
name: test_mode [56442,56451]
===
match
---
expr_stmt [62025,62085]
expr_stmt [62045,62105]
===
match
---
atom_expr [26392,26416]
atom_expr [26412,26436]
===
match
---
simple_stmt [20911,20937]
simple_stmt [20931,20957]
===
match
---
name: dag [47491,47494]
name: dag [47511,47514]
===
match
---
simple_stmt [80031,80069]
simple_stmt [80051,80089]
===
match
---
number: 1 [34645,34646]
number: 1 [34665,34666]
===
match
---
trailer [77145,77149]
trailer [77165,77169]
===
match
---
name: session [74383,74390]
name: session [74403,74410]
===
match
---
trailer [44273,44289]
trailer [44293,44309]
===
match
---
suite [72454,72775]
suite [72474,72795]
===
match
---
name: append [3556,3562]
name: append [3584,3590]
===
match
---
name: Column [10383,10389]
name: Column [10411,10417]
===
match
---
arglist [41466,41476]
arglist [41486,41496]
===
match
---
name: error_file [56791,56801]
name: error_file [56811,56821]
===
match
---
parameters [59143,59300]
parameters [59163,59320]
===
match
---
simple_stmt [46628,46881]
simple_stmt [46648,46901]
===
match
---
atom_expr [22717,22728]
atom_expr [22737,22748]
===
match
---
atom_expr [55488,55497]
atom_expr [55508,55517]
===
match
---
name: task_id [74251,74258]
name: task_id [74271,74278]
===
match
---
name: ti [7699,7701]
name: ti [7727,7729]
===
match
---
trailer [52235,52239]
trailer [52255,52259]
===
match
---
expr_stmt [11852,11904]
expr_stmt [11880,11932]
===
match
---
name: _task_id [79839,79847]
name: _task_id [79859,79867]
===
match
---
param [28105,28109]
param [28125,28129]
===
match
---
comparison [35503,35547]
comparison [35523,35567]
===
match
---
name: refresh_from_db [37610,37625]
name: refresh_from_db [37630,37645]
===
match
---
operator: = [54575,54576]
operator: = [54595,54596]
===
match
---
name: result [77003,77009]
name: result [77023,77029]
===
match
---
name: task_id [20368,20375]
name: task_id [20388,20395]
===
match
---
expr_stmt [61381,61450]
expr_stmt [61401,61470]
===
match
---
name: task [53058,53062]
name: task [53078,53082]
===
match
---
trailer [60763,60778]
trailer [60783,60798]
===
match
---
name: _CURRENT_CONTEXT [3214,3230]
name: _CURRENT_CONTEXT [3242,3258]
===
match
---
trailer [55950,55956]
trailer [55970,55976]
===
match
---
expr_stmt [61259,61300]
expr_stmt [61279,61320]
===
match
---
trailer [49246,49250]
trailer [49266,49270]
===
match
---
simple_stmt [6023,6041]
simple_stmt [6051,6069]
===
match
---
name: tomorrow_ds [60824,60835]
name: tomorrow_ds [60844,60855]
===
match
---
trailer [80323,80328]
trailer [80343,80348]
===
match
---
atom_expr [72068,72122]
atom_expr [72088,72142]
===
match
---
tfpdef [11102,11126]
tfpdef [11130,11154]
===
match
---
name: ignore_task_deps [39748,39764]
name: ignore_task_deps [39768,39784]
===
match
---
operator: = [45809,45810]
operator: = [45829,45830]
===
match
---
operator: , [58945,58946]
operator: , [58965,58966]
===
match
---
name: operator [22706,22714]
name: operator [22726,22734]
===
match
---
operator: , [6998,6999]
operator: , [7026,7027]
===
match
---
name: TaskFail [57174,57182]
name: TaskFail [57194,57202]
===
match
---
trailer [67906,67912]
trailer [67926,67932]
===
match
---
simple_stmt [2722,2787]
simple_stmt [2750,2815]
===
match
---
operator: = [74569,74570]
operator: = [74589,74590]
===
match
---
atom_expr [44650,44662]
atom_expr [44670,44682]
===
match
---
atom_expr [41458,41477]
atom_expr [41478,41497]
===
match
---
expr_stmt [71444,71487]
expr_stmt [71464,71507]
===
match
---
simple_stmt [49242,49410]
simple_stmt [49262,49430]
===
match
---
argument [47997,48010]
argument [48017,48030]
===
match
---
operator: , [41265,41266]
operator: , [41285,41286]
===
match
---
atom_expr [35431,35569]
atom_expr [35451,35589]
===
match
---
operator: , [63312,63313]
operator: , [63332,63333]
===
match
---
trailer [40338,40342]
trailer [40358,40362]
===
match
---
name: debug [29515,29520]
name: debug [29535,29540]
===
match
---
dictorsetmaker [44635,44662]
dictorsetmaker [44655,44682]
===
match
---
name: BaseJob [7388,7395]
name: BaseJob [7416,7423]
===
match
---
param [53616,53646]
param [53636,53666]
===
match
---
expr_stmt [80031,80068]
expr_stmt [80051,80088]
===
match
---
suite [18261,18316]
suite [18281,18336]
===
match
---
if_stmt [41177,41390]
if_stmt [41197,41410]
===
match
---
trailer [9753,9760]
trailer [9781,9788]
===
match
---
trailer [69098,69125]
trailer [69118,69145]
===
match
---
name: html_content_err [72757,72773]
name: html_content_err [72777,72793]
===
match
---
trailer [45851,45912]
trailer [45871,45932]
===
match
---
string: """     Clears a set of task instances, but makes sure the running ones     get killed.      :param tis: a list of task instances     :param session: current session     :param activate_dag_runs: flag to check for active dag run     :param dag: DAG object     """ [4780,5043]
string: """     Clears a set of task instances, but makes sure the running ones     get killed.      :param tis: a list of task instances     :param session: current session     :param activate_dag_runs: flag to check for active dag run     :param dag: DAG object     """ [4808,5071]
===
match
---
if_stmt [37742,37875]
if_stmt [37762,37895]
===
match
---
trailer [61946,61958]
trailer [61966,61978]
===
match
---
expr_stmt [77907,77921]
expr_stmt [77927,77941]
===
match
---
number: 16 [34054,34056]
number: 16 [34074,34076]
===
match
---
trailer [72641,72681]
trailer [72661,72701]
===
match
---
import_name [1150,1161]
import_name [1135,1146]
===
match
---
name: self [8291,8295]
name: self [8319,8323]
===
match
---
atom_expr [78646,78654]
atom_expr [78666,78674]
===
match
---
expr_stmt [24994,25059]
expr_stmt [25014,25079]
===
match
---
name: task_id [8282,8289]
name: task_id [8310,8317]
===
match
---
name: Optional [29245,29253]
name: Optional [29265,29273]
===
match
---
string: "Dependencies not met for %s, dependency '%s' FAILED: %s" [32003,32060]
string: "Dependencies not met for %s, dependency '%s' FAILED: %s" [32023,32080]
===
match
---
atom_expr [62456,62467]
atom_expr [62476,62487]
===
match
---
trailer [52245,52287]
trailer [52265,52307]
===
match
---
operator: , [65931,65932]
operator: , [65951,65952]
===
match
---
trailer [44741,44778]
trailer [44761,44798]
===
match
---
name: get_previous_start_date [29727,29750]
name: get_previous_start_date [29747,29770]
===
match
---
expr_stmt [70997,71133]
expr_stmt [71017,71153]
===
match
---
simple_stmt [25320,25391]
simple_stmt [25340,25411]
===
match
---
atom_expr [45540,45550]
atom_expr [45560,45570]
===
match
---
atom_expr [45291,45303]
atom_expr [45311,45323]
===
match
---
name: pendulum [62047,62055]
name: pendulum [62067,62075]
===
match
---
simple_stmt [55011,55033]
simple_stmt [55031,55053]
===
match
---
operator: + [19348,19349]
operator: + [19368,19369]
===
match
---
tfpdef [73230,73246]
tfpdef [73250,73266]
===
match
---
name: signal [893,899]
name: signal [878,884]
===
match
---
try_stmt [3576,3897]
try_stmt [3604,3925]
===
match
---
name: key [71845,71848]
name: key [71865,71868]
===
match
---
trailer [68402,68404]
trailer [68422,68424]
===
match
---
simple_stmt [6600,7189]
simple_stmt [6628,7217]
===
match
---
name: e [43269,43270]
name: e [43289,43290]
===
match
---
operator: == [82150,82152]
operator: == [82170,82172]
===
match
---
name: IO [3923,3925]
name: IO [3951,3953]
===
match
---
atom_expr [82402,82441]
atom_expr [82422,82461]
===
match
---
atom_expr [57097,57120]
atom_expr [57117,57140]
===
match
---
name: execution_date [78368,78382]
name: execution_date [78388,78402]
===
match
---
simple_stmt [18523,18547]
simple_stmt [18543,18567]
===
match
---
name: SUCCESS [29084,29091]
name: SUCCESS [29104,29111]
===
match
---
decorated [19146,19423]
decorated [19166,19443]
===
match
---
with_stmt [4375,4681]
with_stmt [4403,4709]
===
match
---
comparison [78807,78852]
comparison [78827,78872]
===
match
---
argument [15439,15456]
argument [15459,15476]
===
match
---
name: task_id [80677,80684]
name: task_id [80697,80704]
===
match
---
operator: = [39550,39551]
operator: = [39570,39571]
===
match
---
name: job_id [22513,22519]
name: job_id [22533,22539]
===
match
---
trailer [10182,10196]
trailer [10210,10224]
===
match
---
name: dag_run [47551,47558]
name: dag_run [47571,47578]
===
match
---
string: 'end_date' [58674,58684]
string: 'end_date' [58694,58704]
===
match
---
argument [46833,46861]
argument [46853,46881]
===
match
---
operator: @ [35604,35605]
operator: @ [35624,35625]
===
match
---
name: error_file [44756,44766]
name: error_file [44776,44786]
===
match
---
name: date [41562,41566]
name: date [41582,41586]
===
match
---
operator: -> [36087,36089]
operator: -> [36107,36109]
===
match
---
suite [50207,50358]
suite [50227,50378]
===
match
---
expr_stmt [72992,73012]
expr_stmt [73012,73032]
===
match
---
operator: - [38246,38247]
operator: - [38266,38267]
===
match
---
name: Tuple [8159,8164]
name: Tuple [8187,8192]
===
match
---
atom_expr [33060,33070]
atom_expr [33080,33090]
===
match
---
name: prev_execution_date [61918,61937]
name: prev_execution_date [61938,61957]
===
match
---
simple_stmt [71231,71314]
simple_stmt [71251,71334]
===
match
---
string: 'previously_succeeded' [37845,37867]
string: 'previously_succeeded' [37865,37887]
===
match
---
name: __repr__ [32959,32967]
name: __repr__ [32979,32987]
===
match
---
param [50774,50779]
param [50794,50799]
===
match
---
atom_expr [53872,54303]
atom_expr [53892,54323]
===
match
---
name: context [3842,3849]
name: context [3870,3877]
===
match
---
atom_expr [22670,22688]
atom_expr [22690,22708]
===
match
---
atom_expr [60838,60895]
atom_expr [60858,60915]
===
match
---
atom_expr [39947,39957]
atom_expr [39967,39977]
===
match
---
operator: @ [50720,50721]
operator: @ [50740,50741]
===
match
---
trailer [20544,20550]
trailer [20564,20570]
===
match
---
trailer [37730,37732]
trailer [37750,37752]
===
match
---
name: PickleType [1329,1339]
name: PickleType [1314,1324]
===
match
---
suite [39131,39329]
suite [39151,39349]
===
match
---
operator: = [62990,62991]
operator: = [63010,63011]
===
match
---
name: is_premature [25111,25123]
name: is_premature [25131,25143]
===
match
---
simple_stmt [13298,13323]
simple_stmt [13318,13343]
===
match
---
suite [57892,58169]
suite [57912,58189]
===
match
---
atom_expr [40682,40710]
atom_expr [40702,40730]
===
match
---
name: v [49348,49349]
name: v [49368,49369]
===
match
---
trailer [5937,5976]
trailer [5965,6004]
===
match
---
parameters [50773,50793]
parameters [50793,50813]
===
match
---
trailer [58794,58806]
trailer [58814,58826]
===
match
---
trailer [82438,82440]
trailer [82458,82460]
===
match
---
name: current_time [24969,24981]
name: current_time [24989,25001]
===
match
---
atom_expr [7404,7427]
atom_expr [7432,7455]
===
match
---
name: current_time [24658,24670]
name: current_time [24678,24690]
===
match
---
param [79763,79768]
param [79783,79788]
===
match
---
name: first [82311,82316]
name: first [82331,82336]
===
match
---
name: dag [14757,14760]
name: dag [14777,14780]
===
match
---
name: execution_date [7749,7763]
name: execution_date [7777,7791]
===
match
---
name: ignore_task_deps [54080,54096]
name: ignore_task_deps [54100,54116]
===
match
---
param [41434,41439]
param [41454,41459]
===
match
---
name: all [7831,7834]
name: all [7859,7862]
===
match
---
atom_expr [4293,4314]
atom_expr [4321,4342]
===
match
---
if_stmt [3672,3897]
if_stmt [3700,3925]
===
match
---
operator: = [82604,82605]
operator: = [82624,82625]
===
match
---
expr_stmt [58195,58226]
expr_stmt [58215,58246]
===
match
---
name: self [53245,53249]
name: self [53265,53269]
===
match
---
comparison [24017,24059]
comparison [24037,24079]
===
match
---
argument [68752,68815]
argument [68772,68835]
===
match
---
name: total_seconds [51460,51473]
name: total_seconds [51480,51493]
===
match
---
operator: , [15896,15897]
operator: , [15916,15917]
===
match
---
name: task_ids [6887,6895]
name: task_ids [6915,6923]
===
match
---
expr_stmt [61566,61587]
expr_stmt [61586,61607]
===
match
---
trailer [26391,26417]
trailer [26411,26437]
===
match
---
strings [70152,70489]
strings [70172,70509]
===
match
---
atom_expr [52877,52887]
atom_expr [52897,52907]
===
match
---
name: FAILED [52625,52631]
name: FAILED [52645,52651]
===
match
---
simple_stmt [77455,77502]
simple_stmt [77475,77522]
===
match
---
string: "--force" [18535,18544]
string: "--force" [18555,18564]
===
match
---
operator: = [55021,55022]
operator: = [55041,55042]
===
match
---
name: self [79933,79937]
name: self [79953,79957]
===
match
---
parameters [12503,12509]
parameters [12523,12529]
===
match
---
name: self [60649,60653]
name: self [60669,60673]
===
match
---
atom_expr [21668,21688]
atom_expr [21688,21708]
===
match
---
trailer [48758,48764]
trailer [48778,48784]
===
match
---
parameters [81333,81339]
parameters [81353,81359]
===
match
---
funcdef [21016,22908]
funcdef [21036,22928]
===
match
---
param [81492,81496]
param [81512,81516]
===
match
---
operator: = [10347,10348]
operator: = [10375,10376]
===
match
---
name: end_date [22025,22033]
name: end_date [22045,22053]
===
match
---
name: dag_id [82093,82099]
name: dag_id [82113,82119]
===
match
---
trailer [38536,38638]
trailer [38556,38658]
===
match
---
simple_stmt [9533,9601]
simple_stmt [9561,9629]
===
match
---
operator: = [22389,22390]
operator: = [22409,22410]
===
match
---
atom_expr [30428,30445]
atom_expr [30448,30465]
===
match
---
name: ApiClient [69087,69096]
name: ApiClient [69107,69116]
===
match
---
operator: = [42723,42724]
operator: = [42743,42744]
===
match
---
name: self [68466,68470]
name: self [68486,68490]
===
match
---
name: __name__ [3275,3283]
name: __name__ [3303,3311]
===
match
---
operator: = [68636,68637]
operator: = [68656,68657]
===
match
---
atom_expr [80392,80422]
atom_expr [80412,80442]
===
match
---
name: task [58315,58319]
name: task [58335,58339]
===
match
---
suite [21869,21899]
suite [21889,21919]
===
match
---
fstring_string: __ [62429,62431]
fstring_string: __ [62449,62451]
===
match
---
atom_expr [34596,34647]
atom_expr [34616,34667]
===
match
---
name: _date_or_empty [45322,45336]
name: _date_or_empty [45342,45356]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.             """ [30639,30798]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_start_date` method.             """ [30659,30818]
===
match
---
name: default_subject [71178,71193]
name: default_subject [71198,71213]
===
match
---
name: session [55965,55972]
name: session [55985,55992]
===
match
---
operator: , [39813,39814]
operator: , [39833,39834]
===
match
---
name: self [33704,33708]
name: self [33724,33728]
===
match
---
param [14266,14281]
param [14286,14301]
===
match
---
name: UndefinedError [1260,1274]
name: UndefinedError [1245,1259]
===
match
---
name: state [39952,39957]
name: state [39972,39977]
===
match
---
simple_stmt [79834,79866]
simple_stmt [79854,79886]
===
match
---
name: State [6000,6005]
name: State [6028,6033]
===
match
---
try_stmt [42960,45036]
try_stmt [42980,45056]
===
match
---
atom_expr [19238,19269]
atom_expr [19258,19289]
===
match
---
simple_stmt [32202,32215]
simple_stmt [32222,32235]
===
match
---
trailer [7693,7697]
trailer [7721,7725]
===
match
---
trailer [53018,53039]
trailer [53038,53059]
===
match
---
trailer [32110,32119]
trailer [32130,32139]
===
match
---
param [3338,3354]
param [3366,3382]
===
match
---
name: refresh_from_task [5465,5482]
name: refresh_from_task [5493,5510]
===
match
---
parameters [81401,81407]
parameters [81421,81427]
===
match
---
expr_stmt [71231,71313]
expr_stmt [71251,71333]
===
match
---
if_stmt [52674,52864]
if_stmt [52694,52884]
===
match
---
name: session [30194,30201]
name: session [30214,30221]
===
match
---
trailer [20987,20989]
trailer [21007,21009]
===
match
---
name: dump [4442,4446]
name: dump [4470,4474]
===
match
---
string: 'ti_dag_state' [10588,10602]
string: 'ti_dag_state' [10616,10630]
===
match
---
import_from [2605,2671]
import_from [2590,2656]
===
match
---
operator: , [15117,15118]
operator: , [15137,15138]
===
match
---
simple_stmt [3361,3535]
simple_stmt [3389,3563]
===
match
---
operator: = [74231,74232]
operator: = [74251,74252]
===
match
---
trailer [46696,46701]
trailer [46716,46721]
===
match
---
atom_expr [59566,59583]
atom_expr [59586,59603]
===
match
---
name: dry_run [54866,54873]
name: dry_run [54886,54893]
===
match
---
name: self [68794,68798]
name: self [68814,68818]
===
match
---
funcdef [80747,80821]
funcdef [80767,80841]
===
match
---
operator: , [74369,74370]
operator: , [74389,74390]
===
match
---
return_stmt [51904,51917]
return_stmt [51924,51937]
===
match
---
name: __init__ [79754,79762]
name: __init__ [79774,79782]
===
match
---
operator: @ [20995,20996]
operator: @ [21015,21016]
===
match
---
operator: = [12603,12604]
operator: = [12623,12624]
===
match
---
name: activate_dag_runs [4735,4752]
name: activate_dag_runs [4763,4780]
===
match
---
name: reconstructor [1436,1449]
name: reconstructor [1421,1434]
===
match
---
name: queue [10095,10100]
name: queue [10123,10128]
===
match
---
name: str [4665,4668]
name: str [4693,4696]
===
match
---
name: total_seconds [34627,34640]
name: total_seconds [34647,34660]
===
match
---
suite [50436,50501]
suite [50456,50521]
===
match
---
name: state [24863,24868]
name: state [24883,24888]
===
match
---
name: dump [4660,4664]
name: dump [4688,4692]
===
match
---
funcdef [3314,3897]
funcdef [3342,3925]
===
match
---
atom_expr [56135,56156]
atom_expr [56155,56176]
===
match
---
annassign [8064,8069]
annassign [8092,8097]
===
match
---
name: execution_date [74317,74331]
name: execution_date [74337,74351]
===
match
---
simple_stmt [886,900]
simple_stmt [871,885]
===
match
---
name: provide_session [35117,35132]
name: provide_session [35137,35152]
===
match
---
name: _safe_date [59631,59641]
name: _safe_date [59651,59661]
===
match
---
suite [22967,23603]
suite [22987,23623]
===
match
---
string: "previous_start_date was called" [30100,30132]
string: "previous_start_date was called" [30120,30152]
===
match
---
name: try_number [24359,24369]
name: try_number [24379,24389]
===
match
---
operator: , [76676,76677]
operator: , [76696,76697]
===
match
---
name: self [12149,12153]
name: self [12169,12173]
===
match
---
argument [42759,42774]
argument [42779,42794]
===
match
---
trailer [58662,58673]
trailer [58682,58693]
===
match
---
simple_stmt [22613,22635]
simple_stmt [22633,22655]
===
match
---
string: 'Exception:<br>Failed attempt to attach error logs<br>' [70214,70269]
string: 'Exception:<br>Failed attempt to attach error logs<br>' [70234,70289]
===
match
---
arglist [4030,4044]
arglist [4058,4072]
===
match
---
name: self [43592,43596]
name: self [43612,43616]
===
match
---
name: AirflowRescheduleException [44021,44047]
name: AirflowRescheduleException [44041,44067]
===
match
---
param [15865,15897]
param [15885,15917]
===
match
---
name: ds_nodash [62432,62441]
name: ds_nodash [62452,62461]
===
match
---
atom_expr [9712,9731]
atom_expr [9740,9759]
===
match
---
string: """         Based on this instance's try_number, this will calculate         the number of previously attempted tries, defaulting to 0.         """ [13382,13529]
string: """         Based on this instance's try_number, this will calculate         the number of previously attempted tries, defaulting to 0.         """ [13402,13549]
===
match
---
name: state [25332,25337]
name: state [25352,25357]
===
match
---
name: queued_by_job [82644,82657]
name: queued_by_job [82664,82677]
===
match
---
name: self [20379,20383]
name: self [20399,20403]
===
match
---
name: Iterable [74553,74561]
name: Iterable [74573,74581]
===
match
---
name: update [68005,68011]
name: update [68025,68031]
===
match
---
operator: = [71051,71052]
operator: = [71071,71072]
===
match
---
trailer [46646,46651]
trailer [46666,46671]
===
match
---
simple_stmt [21976,22008]
simple_stmt [21996,22028]
===
match
---
name: utils [2685,2690]
name: utils [2713,2718]
===
match
---
operator: , [24747,24748]
operator: , [24767,24768]
===
match
---
expr_stmt [14607,14651]
expr_stmt [14627,14671]
===
match
---
trailer [54764,54774]
trailer [54784,54794]
===
match
---
trailer [21753,21768]
trailer [21773,21788]
===
match
---
name: dag_run [60536,60543]
name: dag_run [60556,60563]
===
match
---
operator: , [32772,32773]
operator: , [32792,32793]
===
match
---
string: "%s" [56610,56614]
string: "%s" [56630,56634]
===
match
---
name: iso [19515,19518]
name: iso [19535,19538]
===
match
---
atom_expr [56177,56191]
atom_expr [56197,56211]
===
match
---
trailer [46701,46721]
trailer [46721,46741]
===
match
---
trailer [7087,7089]
trailer [7115,7117]
===
match
---
atom_expr [47962,47973]
atom_expr [47982,47993]
===
match
---
name: session [48046,48053]
name: session [48066,48073]
===
match
---
trailer [73029,73035]
trailer [73049,73055]
===
match
---
name: Context [51964,51971]
name: Context [51984,51991]
===
match
---
param [41740,41764]
param [41760,41784]
===
match
---
name: sqlalchemy [1414,1424]
name: sqlalchemy [1399,1409]
===
match
---
name: lazy_object_proxy [65410,65427]
name: lazy_object_proxy [65430,65447]
===
match
---
name: Optional [80360,80368]
name: Optional [80380,80388]
===
match
---
fstring_string: ti.finish. [44982,44992]
fstring_string: ti.finish. [45002,45012]
===
match
---
argument [15307,15326]
argument [15327,15346]
===
match
---
operator: , [9829,9830]
operator: , [9857,9858]
===
match
---
name: self [72871,72875]
name: self [72891,72895]
===
match
---
simple_stmt [10555,10877]
simple_stmt [10583,10905]
===
match
---
decorated [53371,54857]
decorated [53391,54877]
===
match
---
name: task [41261,41265]
name: task [41281,41285]
===
match
---
name: SUCCESS [26318,26325]
name: SUCCESS [26338,26345]
===
match
---
name: ti [79769,79771]
name: ti [79789,79791]
===
match
---
atom_expr [51424,51476]
atom_expr [51444,51496]
===
match
---
string: """Return Number of running TIs from the DB""" [77455,77501]
string: """Return Number of running TIs from the DB""" [77475,77521]
===
match
---
operator: , [62312,62313]
operator: , [62332,62333]
===
match
---
name: pod_id [68525,68531]
name: pod_id [68545,68551]
===
match
---
operator: = [60836,60837]
operator: = [60856,60857]
===
match
---
string: "Immediate failure requested. Marking task as FAILED." [57988,58042]
string: "Immediate failure requested. Marking task as FAILED." [58008,58062]
===
match
---
operator: = [46307,46308]
operator: = [46327,46328]
===
match
---
operator: , [62252,62253]
operator: , [62272,62273]
===
match
---
name: Optional [56177,56185]
name: Optional [56197,56205]
===
match
---
operator: , [58444,58445]
operator: , [58464,58465]
===
match
---
operator: @ [81210,81211]
operator: @ [81230,81231]
===
match
---
operator: , [65879,65880]
operator: , [65899,65900]
===
match
---
string: """         Copy common attributes from the given task.          :param task: The task object to copy from         :type task: airflow.models.BaseOperator         :param pool_override: Use the pool_override instead of task's pool         :type pool_override: str         """ [22976,23250]
string: """         Copy common attributes from the given task.          :param task: The task object to copy from         :type task: airflow.models.BaseOperator         :param pool_override: Use the pool_override instead of task's pool         :type pool_override: str         """ [22996,23270]
===
match
---
operator: = [59343,59344]
operator: = [59363,59364]
===
match
---
expr_stmt [54962,55002]
expr_stmt [54982,55022]
===
match
---
name: default_html_content [69734,69754]
name: default_html_content [69754,69774]
===
match
---
fstring [19752,19776]
fstring [19772,19796]
===
match
---
suite [4409,4681]
suite [4437,4709]
===
match
---
operator: { [50650,50651]
operator: { [50670,50671]
===
match
---
trailer [71165,71177]
trailer [71185,71197]
===
match
---
trailer [40284,40294]
trailer [40304,40314]
===
match
---
name: self [25082,25086]
name: self [25102,25106]
===
match
---
operator: = [72144,72145]
operator: = [72164,72165]
===
match
---
operator: = [9594,9595]
operator: = [9622,9623]
===
match
---
string: 'TaskInstanceKey' [8622,8639]
string: 'TaskInstanceKey' [8650,8667]
===
match
---
trailer [43644,44005]
trailer [43664,44025]
===
match
---
atom_expr [72916,72965]
atom_expr [72936,72985]
===
match
---
decorated [24154,24371]
decorated [24174,24391]
===
match
---
atom [60838,60874]
atom [60858,60894]
===
match
---
trailer [21585,21599]
trailer [21605,21619]
===
match
---
operator: = [9865,9866]
operator: = [9893,9894]
===
match
---
operator: , [72529,72530]
operator: , [72549,72550]
===
match
---
trailer [48319,48324]
trailer [48339,48344]
===
match
---
return_stmt [59792,59801]
return_stmt [59812,59821]
===
match
---
param [73127,73132]
param [73147,73152]
===
match
---
name: run [53396,53399]
name: run [53416,53419]
===
match
---
name: schedulable_ti [47459,47473]
name: schedulable_ti [47479,47493]
===
match
---
trailer [11713,11721]
trailer [11741,11749]
===
match
---
if_stmt [55285,55318]
if_stmt [55305,55338]
===
match
---
name: error [54844,54849]
name: error [54864,54869]
===
match
---
string: "Marking task as FAILED." [58091,58116]
string: "Marking task as FAILED." [58111,58136]
===
match
---
name: AirflowException [48540,48556]
name: AirflowException [48560,48576]
===
match
---
operator: , [19310,19311]
operator: , [19330,19331]
===
match
---
name: dag [46906,46909]
name: dag [46926,46929]
===
match
---
name: num [47545,47548]
name: num [47565,47568]
===
match
---
name: self [40243,40247]
name: self [40263,40267]
===
match
---
arith_expr [38233,38264]
arith_expr [38253,38284]
===
match
---
arglist [32588,32614]
arglist [32608,32634]
===
match
---
atom_expr [47258,47278]
atom_expr [47278,47298]
===
match
---
trailer [54820,54843]
trailer [54840,54863]
===
match
---
operator: , [8540,8541]
operator: , [8568,8569]
===
match
---
suite [58060,58117]
suite [58080,58137]
===
match
---
name: BaseJob [82525,82532]
name: BaseJob [82545,82552]
===
match
---
name: task [62401,62405]
name: task [62421,62425]
===
match
---
name: int [80369,80372]
name: int [80389,80392]
===
match
---
name: path [14892,14896]
name: path [14912,14916]
===
match
---
trailer [43161,43183]
trailer [43181,43203]
===
match
---
name: task [34787,34791]
name: task [34807,34811]
===
match
---
name: relationship [82660,82672]
name: relationship [82680,82692]
===
match
---
name: timedelta [60861,60870]
name: timedelta [60881,60890]
===
match
---
name: Column [10145,10151]
name: Column [10173,10179]
===
match
---
param [80855,80859]
param [80875,80879]
===
match
---
atom_expr [78001,78049]
atom_expr [78021,78069]
===
match
---
except_clause [44223,44255]
except_clause [44243,44275]
===
match
---
name: Column [9934,9940]
name: Column [9962,9968]
===
match
---
name: execution_date [41374,41388]
name: execution_date [41394,41408]
===
match
---
atom_expr [77758,77771]
atom_expr [77778,77791]
===
match
---
trailer [27905,27935]
trailer [27925,27955]
===
match
---
operator: , [3206,3207]
operator: , [3234,3235]
===
match
---
trailer [47558,47571]
trailer [47578,47591]
===
match
---
trailer [77947,77953]
trailer [77967,77973]
===
match
---
name: Integer [10152,10159]
name: Integer [10180,10187]
===
match
---
name: Session [29804,29811]
name: Session [29824,29831]
===
match
---
atom_expr [26097,26116]
atom_expr [26117,26136]
===
match
---
atom_expr [44635,44648]
atom_expr [44655,44668]
===
match
---
suite [18111,18165]
suite [18131,18185]
===
match
---
name: mark_success [54155,54167]
name: mark_success [54175,54187]
===
match
---
name: external_executor_id [10360,10380]
name: external_executor_id [10388,10408]
===
match
---
name: handle_failure [44309,44323]
name: handle_failure [44329,44343]
===
match
---
atom_expr [71668,71683]
atom_expr [71688,71703]
===
match
---
trailer [52124,52144]
trailer [52144,52164]
===
match
---
operator: = [76422,76423]
operator: = [76442,76443]
===
match
---
operator: = [61857,61858]
operator: = [61877,61878]
===
match
---
expr_stmt [22288,22320]
expr_stmt [22308,22340]
===
match
---
atom_expr [59763,59783]
atom_expr [59783,59803]
===
match
---
atom_expr [61403,61450]
atom_expr [61423,61470]
===
match
---
trailer [18127,18134]
trailer [18147,18154]
===
match
---
name: var [64183,64186]
name: var [64203,64206]
===
match
---
operator: = [51864,51865]
operator: = [51884,51885]
===
match
---
name: test_mode [54204,54213]
name: test_mode [54224,54233]
===
match
---
name: state [30912,30917]
name: state [30932,30937]
===
match
---
operator: , [45800,45801]
operator: , [45820,45821]
===
match
---
operator: = [59680,59681]
operator: = [59700,59701]
===
match
---
operator: = [10256,10257]
operator: = [10284,10285]
===
match
---
operator: , [14974,14975]
operator: , [14994,14995]
===
match
---
atom_expr [13862,13878]
atom_expr [13882,13898]
===
match
---
name: mark_success [42984,42996]
name: mark_success [43004,43016]
===
match
---
trailer [80508,80514]
trailer [80528,80534]
===
match
---
operator: , [77664,77665]
operator: , [77684,77685]
===
match
---
simple_stmt [55937,55957]
simple_stmt [55957,55977]
===
match
---
return_stmt [4209,4247]
return_stmt [4237,4275]
===
match
---
exprlist [7046,7072]
exprlist [7074,7100]
===
match
---
param [11128,11155]
param [11156,11183]
===
match
---
name: self [24699,24703]
name: self [24719,24723]
===
match
---
name: provide_session [77376,77391]
name: provide_session [77396,77411]
===
match
---
atom_expr [11475,11512]
atom_expr [11503,11540]
===
match
---
import_from [2722,2786]
import_from [2750,2814]
===
match
---
name: rendered_k8s_spec [67710,67727]
name: rendered_k8s_spec [67730,67747]
===
match
---
arglist [59690,59711]
arglist [59710,59731]
===
match
---
arglist [48946,48977]
arglist [48966,48997]
===
match
---
operator: , [26259,26260]
operator: , [26279,26280]
===
match
---
import_as_names [2759,2786]
import_as_names [2787,2814]
===
match
---
atom_expr [7882,7890]
atom_expr [7910,7918]
===
match
---
operator: = [19906,19907]
operator: = [19926,19927]
===
match
---
trailer [26076,26083]
trailer [26096,26103]
===
match
---
operator: , [14134,14135]
operator: , [14154,14155]
===
match
---
atom_expr [27988,28048]
atom_expr [28008,28068]
===
match
---
name: tis [79160,79163]
name: tis [79180,79183]
===
match
---
trailer [49536,49553]
trailer [49556,49573]
===
match
---
simple_stmt [49969,50119]
simple_stmt [49989,50139]
===
match
---
operator: , [63553,63554]
operator: , [63573,63574]
===
match
---
atom_expr [64109,64117]
atom_expr [64129,64137]
===
match
---
simple_stmt [70111,70500]
simple_stmt [70131,70520]
===
match
---
decorator [23608,23625]
decorator [23628,23645]
===
match
---
operator: = [68498,68499]
operator: = [68518,68519]
===
match
---
name: execution_date [74332,74346]
name: execution_date [74352,74366]
===
match
---
decorated [80733,80821]
decorated [80753,80841]
===
match
---
string: 'scheduler' [45852,45863]
string: 'scheduler' [45872,45883]
===
match
---
simple_stmt [59559,59622]
simple_stmt [59579,59642]
===
match
---
simple_stmt [20973,20990]
simple_stmt [20993,21010]
===
match
---
atom_expr [23572,23585]
atom_expr [23592,23605]
===
match
---
trailer [55998,56003]
trailer [56018,56023]
===
match
---
operator: -> [81027,81029]
operator: -> [81047,81049]
===
match
---
name: provide_session [59091,59106]
name: provide_session [59111,59126]
===
match
---
simple_stmt [58239,58285]
simple_stmt [58259,58305]
===
match
---
return_stmt [27981,28048]
return_stmt [28001,28068]
===
match
---
trailer [26053,26075]
trailer [26073,26095]
===
match
---
import_from [2787,2824]
import_from [2815,2852]
===
match
---
operator: = [35907,35908]
operator: = [35927,35928]
===
match
---
name: log [50808,50811]
name: log [50828,50831]
===
match
---
name: schedulable_tis [47263,47278]
name: schedulable_tis [47283,47298]
===
match
---
simple_stmt [79026,79235]
simple_stmt [79046,79255]
===
match
---
name: State [77758,77763]
name: State [77778,77783]
===
match
---
trailer [74115,74122]
trailer [74135,74142]
===
match
---
name: task [60231,60235]
name: task [60251,60255]
===
match
---
sync_comp_for [78704,78716]
sync_comp_for [78724,78736]
===
match
---
fstring_expr [44992,45005]
fstring_expr [45012,45025]
===
match
---
string: 'Log file: {{ti.log_filepath}}<br>' [69981,70016]
string: 'Log file: {{ti.log_filepath}}<br>' [70001,70036]
===
match
---
name: clear_task_instances [4687,4707]
name: clear_task_instances [4715,4735]
===
match
---
simple_stmt [77334,77370]
simple_stmt [77354,77390]
===
match
---
atom_expr [71156,71218]
atom_expr [71176,71238]
===
match
---
atom_expr [9905,9917]
atom_expr [9933,9945]
===
match
---
name: result [50601,50607]
name: result [50621,50627]
===
match
---
name: _date_or_empty [45420,45434]
name: _date_or_empty [45440,45454]
===
match
---
simple_stmt [25068,25088]
simple_stmt [25088,25108]
===
match
---
atom_expr [79984,79998]
atom_expr [80004,80018]
===
match
---
name: sqlalchemy [1280,1290]
name: sqlalchemy [1265,1275]
===
match
---
atom_expr [71345,71416]
atom_expr [71365,71436]
===
match
---
trailer [15925,15930]
trailer [15945,15950]
===
match
---
name: ti [22760,22762]
name: ti [22780,22782]
===
match
---
atom_expr [24040,24059]
atom_expr [24060,24079]
===
match
---
name: timezone [11758,11766]
name: timezone [11786,11794]
===
match
---
trailer [8295,8310]
trailer [8323,8338]
===
match
---
arglist [8494,8569]
arglist [8522,8597]
===
match
---
atom_expr [12371,12379]
atom_expr [12391,12399]
===
match
---
name: XCom [77061,77065]
name: XCom [77081,77085]
===
match
---
name: or_ [79250,79253]
name: or_ [79270,79273]
===
match
---
if_stmt [26969,27332]
if_stmt [26989,27352]
===
match
---
arglist [8546,8568]
arglist [8574,8596]
===
match
---
expr_stmt [11263,11279]
expr_stmt [11291,11307]
===
match
---
expr_stmt [18959,18996]
expr_stmt [18979,19016]
===
match
---
name: exception [70782,70791]
name: exception [70802,70811]
===
match
---
name: get_template_context [52746,52766]
name: get_template_context [52766,52786]
===
match
---
simple_stmt [1201,1217]
simple_stmt [1186,1202]
===
match
---
string: """Get Airflow Variable value""" [63480,63512]
string: """Get Airflow Variable value""" [63500,63532]
===
match
---
name: _try_number [55911,55922]
name: _try_number [55931,55942]
===
match
---
name: info [40691,40695]
name: info [40711,40715]
===
match
---
name: VariableJsonAccessor [63595,63615]
name: VariableJsonAccessor [63615,63635]
===
match
---
name: task [57183,57187]
name: task [57203,57207]
===
match
---
trailer [5482,5488]
trailer [5510,5516]
===
match
---
name: self [29051,29055]
name: self [29071,29075]
===
match
---
trailer [58673,58702]
trailer [58693,58722]
===
match
---
comp_op [52702,52708]
comp_op [52722,52728]
===
match
---
name: task [61403,61407]
name: task [61423,61427]
===
match
---
simple_stmt [48502,48522]
simple_stmt [48522,48542]
===
match
---
name: kube_config [2957,2968]
name: kube_config [2985,2996]
===
match
---
atom_expr [24113,24148]
atom_expr [24133,24168]
===
match
---
atom_expr [68637,68659]
atom_expr [68657,68679]
===
match
---
trailer [52304,52308]
trailer [52324,52328]
===
match
---
name: queue [22618,22623]
name: queue [22638,22643]
===
match
---
name: context [50577,50584]
name: context [50597,50604]
===
match
---
trailer [39995,40003]
trailer [40015,40023]
===
match
---
name: defaultdict [5102,5113]
name: defaultdict [5130,5141]
===
match
---
name: error_fd [54369,54377]
name: error_fd [54389,54397]
===
match
---
decorators [41616,41659]
decorators [41636,41679]
===
match
---
simple_stmt [51904,51918]
simple_stmt [51924,51938]
===
match
---
name: Integer [9831,9838]
name: Integer [9859,9866]
===
match
---
name: extend [18581,18587]
name: extend [18601,18607]
===
match
---
atom_expr [15014,15033]
atom_expr [15034,15053]
===
match
---
atom_expr [22831,22841]
atom_expr [22851,22861]
===
match
---
atom_expr [80303,80313]
atom_expr [80323,80333]
===
match
---
tfpdef [11128,11148]
tfpdef [11156,11176]
===
match
---
trailer [7387,7396]
trailer [7415,7424]
===
match
---
name: self [55621,55625]
name: self [55641,55645]
===
match
---
trailer [77710,77718]
trailer [77730,77738]
===
match
---
name: task [11799,11803]
name: task [11827,11831]
===
match
---
name: strftime [60795,60803]
name: strftime [60815,60823]
===
match
---
funcdef [19160,19423]
funcdef [19180,19443]
===
match
---
name: dep [32567,32570]
name: dep [32587,32590]
===
match
---
argument [27818,27833]
argument [27838,27853]
===
match
---
fstring_expr [56988,57004]
fstring_expr [57008,57024]
===
match
---
operator: = [57916,57917]
operator: = [57936,57937]
===
match
---
name: base_worker_pod [68929,68944]
name: base_worker_pod [68949,68964]
===
match
---
if_stmt [54312,54343]
if_stmt [54332,54363]
===
match
---
operator: , [24415,24416]
operator: , [24435,24436]
===
match
---
name: self [82211,82215]
name: self [82231,82235]
===
match
---
atom_expr [27138,27157]
atom_expr [27158,27177]
===
match
---
expr_stmt [24658,24690]
expr_stmt [24678,24710]
===
match
---
name: RenderedTaskInstanceFields [67360,67386]
name: RenderedTaskInstanceFields [67380,67406]
===
match
---
trailer [45660,45695]
trailer [45680,45715]
===
match
---
simple_stmt [54889,54929]
simple_stmt [54909,54949]
===
match
---
string: 'tomorrow_ds_nodash' [65781,65801]
string: 'tomorrow_ds_nodash' [65801,65821]
===
match
---
suite [49702,50358]
suite [49722,50378]
===
match
---
name: execution_date [20422,20436]
name: execution_date [20442,20456]
===
match
---
fstring_expr [62415,62429]
fstring_expr [62435,62449]
===
match
---
atom_expr [47481,47527]
atom_expr [47501,47547]
===
match
---
trailer [77065,77073]
trailer [77085,77093]
===
match
---
name: on_success_callback [52955,52974]
name: on_success_callback [52975,52994]
===
match
---
funcdef [28573,29093]
funcdef [28593,29113]
===
match
---
simple_stmt [63480,63513]
simple_stmt [63500,63533]
===
match
---
name: Optional [30419,30427]
name: Optional [30439,30447]
===
match
---
simple_stmt [27981,28049]
simple_stmt [28001,28069]
===
match
---
trailer [7634,7642]
trailer [7662,7670]
===
match
---
trailer [61285,61300]
trailer [61305,61320]
===
match
---
simple_stmt [48046,48065]
simple_stmt [48066,48085]
===
match
---
operator: , [65727,65728]
operator: , [65747,65748]
===
match
---
expr_stmt [9460,9528]
expr_stmt [9488,9556]
===
match
---
name: self [68311,68315]
name: self [68331,68335]
===
match
---
operator: + [13995,13996]
operator: + [14015,14016]
===
match
---
argument [31883,31906]
argument [31903,31926]
===
match
---
name: tempfile [998,1006]
name: tempfile [983,991]
===
match
---
name: Variable [63400,63408]
name: Variable [63420,63428]
===
match
---
fstring_end: ' [50671,50672]
fstring_end: ' [50691,50692]
===
match
---
atom_expr [30152,30202]
atom_expr [30172,30222]
===
match
---
name: warn [28277,28281]
name: warn [28297,28301]
===
match
---
name: airflow [60265,60272]
name: airflow [60285,60292]
===
match
---
name: LoggingMixin [2549,2561]
name: LoggingMixin [2534,2546]
===
match
---
string: "TaskInstance.dag_id == DagModel.dag_id" [10948,10988]
string: "TaskInstance.dag_id == DagModel.dag_id" [10976,11016]
===
match
---
suite [63463,63580]
suite [63483,63600]
===
match
---
operator: @ [63252,63253]
operator: @ [63272,63273]
===
match
---
name: provide_session [32308,32323]
name: provide_session [32328,32343]
===
match
---
operator: , [1311,1312]
operator: , [1296,1297]
===
match
---
name: self [79763,79767]
name: self [79783,79787]
===
match
---
name: self [49242,49246]
name: self [49262,49266]
===
match
---
trailer [32570,32587]
trailer [32590,32607]
===
match
---
expr_stmt [10278,10299]
expr_stmt [10306,10327]
===
match
---
string: "TaskInstance" [78016,78030]
string: "TaskInstance" [78036,78050]
===
match
---
atom_expr [39093,39103]
atom_expr [39113,39123]
===
match
---
annassign [3230,3250]
annassign [3258,3278]
===
match
---
trailer [7381,7387]
trailer [7409,7415]
===
match
---
name: self [58790,58794]
name: self [58810,58814]
===
match
---
name: log_message [58458,58469]
name: log_message [58478,58489]
===
match
---
trailer [48781,48788]
trailer [48801,48808]
===
match
---
atom_expr [7935,7952]
atom_expr [7963,7980]
===
match
---
param [53491,53521]
param [53511,53541]
===
match
---
operator: = [24671,24672]
operator: = [24691,24692]
===
match
---
trailer [6874,6882]
trailer [6902,6910]
===
match
---
name: utcnow [45098,45104]
name: utcnow [45118,45124]
===
match
---
if_stmt [39244,39329]
if_stmt [39264,39349]
===
match
---
name: Union [56135,56140]
name: Union [56155,56160]
===
match
---
operator: = [39058,39059]
operator: = [39078,39079]
===
match
---
name: self [59054,59058]
name: self [59074,59078]
===
match
---
trailer [20958,20964]
trailer [20978,20984]
===
match
---
operator: = [69543,69544]
operator: = [69563,69564]
===
match
---
trailer [7459,7465]
trailer [7487,7493]
===
match
---
simple_stmt [78091,78156]
simple_stmt [78111,78176]
===
match
---
operator: = [22668,22669]
operator: = [22688,22689]
===
match
---
operator: , [38425,38426]
operator: , [38445,38446]
===
match
---
atom_expr [82660,82681]
atom_expr [82680,82701]
===
match
---
trailer [40690,40695]
trailer [40710,40715]
===
match
---
string: """         Call callback defined for finished state change.          NOTE: Only invoke this function from caller of self._run_raw_task or         self.run         """ [52426,52593]
string: """         Call callback defined for finished state change.          NOTE: Only invoke this function from caller of self._run_raw_task or         self.run         """ [52446,52613]
===
match
---
name: ti [22582,22584]
name: ti [22602,22604]
===
match
---
name: first [77289,77294]
name: first [77309,77314]
===
match
---
trailer [52383,52399]
trailer [52403,52419]
===
match
---
trailer [24021,24036]
trailer [24041,24056]
===
match
---
name: params [67964,67970]
name: params [67984,67990]
===
match
---
atom_expr [63118,63136]
atom_expr [63138,63156]
===
match
---
return_stmt [28058,28069]
return_stmt [28078,28089]
===
match
---
trailer [68272,68281]
trailer [68292,68301]
===
match
---
trailer [79129,79133]
trailer [79149,79153]
===
match
---
name: utils [2800,2805]
name: utils [2828,2833]
===
match
---
argument [53959,53990]
argument [53979,54010]
===
match
---
name: self [12588,12592]
name: self [12608,12612]
===
match
---
name: session [45524,45531]
name: session [45544,45551]
===
match
---
name: ignore_all_deps [18245,18260]
name: ignore_all_deps [18265,18280]
===
match
---
operator: = [16032,16033]
operator: = [16052,16053]
===
match
---
comparison [56374,56391]
comparison [56394,56411]
===
match
---
operator: , [32119,32120]
operator: , [32139,32140]
===
match
---
dotted_name [2792,2811]
dotted_name [2820,2839]
===
match
---
name: error [54850,54855]
name: error [54870,54875]
===
match
---
name: tis [4713,4716]
name: tis [4741,4744]
===
match
---
simple_stmt [50901,50937]
simple_stmt [50921,50957]
===
match
---
name: mark_success [15636,15648]
name: mark_success [15656,15668]
===
match
---
arglist [9484,9508]
arglist [9512,9536]
===
match
---
name: self [77930,77934]
name: self [77950,77954]
===
match
---
simple_stmt [11227,11255]
simple_stmt [11255,11283]
===
match
---
return_stmt [81507,81535]
return_stmt [81527,81555]
===
match
---
atom_expr [24936,24949]
atom_expr [24956,24969]
===
match
---
name: item [63303,63307]
name: item [63323,63327]
===
match
---
atom_expr [33851,34006]
atom_expr [33871,34026]
===
match
---
operator: , [24059,24060]
operator: , [24079,24080]
===
match
---
name: job_id [42789,42795]
name: job_id [42809,42815]
===
match
---
trailer [45695,45704]
trailer [45715,45724]
===
match
---
name: dag [60428,60431]
name: dag [60448,60451]
===
match
---
expr_stmt [11918,11974]
expr_stmt [11946,12002]
===
match
---
param [15757,15788]
param [15777,15808]
===
match
---
string: "wb" [4397,4401]
string: "wb" [4425,4429]
===
match
---
operator: = [54608,54609]
operator: = [54628,54629]
===
match
---
argument [51692,51707]
argument [51712,51727]
===
match
---
name: ds [64700,64702]
name: ds [64720,64722]
===
match
---
name: logging [3257,3264]
name: logging [3285,3292]
===
match
---
simple_stmt [54787,54804]
simple_stmt [54807,54824]
===
match
---
param [31022,31035]
param [31042,31055]
===
match
---
operator: = [53559,53560]
operator: = [53579,53580]
===
match
---
or_test [57846,57891]
or_test [57866,57911]
===
match
---
name: task [27286,27290]
name: task [27306,27310]
===
match
---
trailer [41566,41575]
trailer [41586,41595]
===
match
---
atom_expr [82180,82207]
atom_expr [82200,82227]
===
match
---
atom_expr [43908,43941]
atom_expr [43928,43961]
===
match
---
string: 'task_instance' [65592,65607]
string: 'task_instance' [65612,65627]
===
match
---
name: ts_nodash_with_tz [62201,62218]
name: ts_nodash_with_tz [62221,62238]
===
match
---
return_stmt [59559,59621]
return_stmt [59579,59641]
===
match
---
name: State [50879,50884]
name: State [50899,50904]
===
match
---
trailer [7230,7232]
trailer [7258,7260]
===
match
---
name: Optional [36001,36009]
name: Optional [36021,36029]
===
match
---
operator: = [74331,74332]
operator: = [74351,74352]
===
match
---
atom_expr [24815,24830]
atom_expr [24835,24850]
===
match
---
name: filter_for_tis [77981,77995]
name: filter_for_tis [78001,78015]
===
match
---
name: models [1982,1988]
name: models [1967,1973]
===
match
---
name: task_id [47091,47098]
name: task_id [47111,47118]
===
match
---
name: Optional [26541,26549]
name: Optional [26561,26569]
===
match
---
name: self [64178,64182]
name: self [64198,64202]
===
match
---
simple_stmt [42738,42776]
simple_stmt [42758,42796]
===
match
---
operator: } [70564,70565]
operator: } [70584,70585]
===
match
---
name: AirflowTaskTimeout [51561,51579]
name: AirflowTaskTimeout [51581,51599]
===
match
---
name: task_ids [74523,74531]
name: task_ids [74543,74551]
===
match
---
name: self [55515,55519]
name: self [55535,55539]
===
match
---
name: context [3693,3700]
name: context [3721,3728]
===
match
---
name: tis [78171,78174]
name: tis [78191,78194]
===
match
---
trailer [53296,53309]
trailer [53316,53329]
===
match
---
name: self [59318,59322]
name: self [59338,59342]
===
match
---
decorated [25396,26418]
decorated [25416,26438]
===
match
---
atom_expr [6076,6093]
atom_expr [6104,6121]
===
match
---
atom_expr [19015,19073]
atom_expr [19035,19093]
===
match
---
string: """Is task instance is eligible for retry""" [59506,59550]
string: """Is task instance is eligible for retry""" [59526,59570]
===
match
---
atom_expr [4128,4146]
atom_expr [4156,4174]
===
match
---
simple_stmt [12176,12196]
simple_stmt [12196,12216]
===
match
---
name: dag_id [74297,74303]
name: dag_id [74317,74323]
===
match
---
name: _execution_date [80805,80820]
name: _execution_date [80825,80840]
===
match
---
name: ti [7791,7793]
name: ti [7819,7821]
===
match
---
expr_stmt [60698,60734]
expr_stmt [60718,60754]
===
match
---
trailer [62003,62012]
trailer [62023,62032]
===
match
---
operator: = [36051,36052]
operator: = [36071,36072]
===
match
---
name: hashlib [827,834]
name: hashlib [812,819]
===
match
---
trailer [56911,56918]
trailer [56931,56938]
===
match
---
expr_stmt [80169,80208]
expr_stmt [80189,80228]
===
match
---
name: execution_date [55520,55534]
name: execution_date [55540,55554]
===
match
---
operator: , [17982,17983]
operator: , [18002,18003]
===
match
---
suite [72618,72682]
suite [72638,72702]
===
match
---
trailer [35567,35569]
trailer [35587,35589]
===
match
---
trailer [21896,21898]
trailer [21916,21918]
===
match
---
argument [54503,54522]
argument [54523,54542]
===
match
---
name: duration [9736,9744]
name: duration [9764,9772]
===
match
---
atom_expr [72642,72657]
atom_expr [72662,72677]
===
match
---
simple_stmt [48992,49065]
simple_stmt [49012,49085]
===
match
---
name: html_content [71231,71243]
name: html_content [71251,71263]
===
match
---
simple_stmt [3251,3285]
simple_stmt [3279,3313]
===
match
---
import_from [1365,1408]
import_from [1350,1393]
===
match
---
trailer [7697,7724]
trailer [7725,7752]
===
match
---
name: session [56284,56291]
name: session [56304,56311]
===
match
---
name: ti [82345,82347]
name: ti [82365,82367]
===
match
---
trailer [82066,82242]
trailer [82086,82262]
===
match
---
name: log [48433,48436]
name: log [48453,48456]
===
match
---
name: xcom [2091,2095]
name: xcom [2076,2080]
===
match
---
trailer [22420,22429]
trailer [22440,22449]
===
match
---
name: job_id [5216,5222]
name: job_id [5244,5250]
===
match
---
tfpdef [35799,35827]
tfpdef [35819,35847]
===
match
---
trailer [7403,7428]
trailer [7431,7456]
===
match
---
name: self [55011,55015]
name: self [55031,55035]
===
match
---
trailer [52881,52887]
trailer [52901,52907]
===
match
---
name: Base [1884,1888]
name: Base [1869,1873]
===
match
---
operator: , [39914,39915]
operator: , [39934,39935]
===
match
---
operator: @ [24154,24155]
operator: @ [24174,24175]
===
match
---
name: execution_date [78689,78703]
name: execution_date [78709,78723]
===
match
---
trailer [62064,62085]
trailer [62084,62105]
===
match
---
name: count [26048,26053]
name: count [26068,26073]
===
match
---
name: State [43605,43610]
name: State [43625,43630]
===
match
---
name: key [80538,80541]
name: key [80558,80561]
===
match
---
atom_expr [52891,52904]
atom_expr [52911,52924]
===
match
---
string: """Fetch rendered template fields from DB""" [67207,67251]
string: """Fetch rendered template fields from DB""" [67227,67271]
===
match
---
operator: , [64261,64262]
operator: , [64281,64282]
===
match
---
atom_expr [9747,9760]
atom_expr [9775,9788]
===
match
---
funcdef [80601,80654]
funcdef [80621,80674]
===
match
---
name: getuser [12082,12089]
name: getuser [12102,12109]
===
match
---
name: job_id [54234,54240]
name: job_id [54254,54260]
===
match
---
operator: = [71620,71621]
operator: = [71640,71641]
===
match
---
name: is_container [76900,76912]
name: is_container [76920,76932]
===
match
---
param [81590,81595]
param [81610,81615]
===
match
---
trailer [71058,71075]
trailer [71078,71095]
===
match
---
annassign [39163,39227]
annassign [39183,39247]
===
match
---
name: t [78909,78910]
name: t [78929,78930]
===
match
---
trailer [53187,53205]
trailer [53207,53225]
===
match
---
name: job_id [15389,15395]
name: job_id [15409,15415]
===
match
---
operator: , [15964,15965]
operator: , [15984,15985]
===
match
---
name: self [33945,33949]
name: self [33965,33969]
===
match
---
trailer [32904,32911]
trailer [32924,32931]
===
match
---
atom [37978,37988]
atom [37998,38008]
===
match
---
operator: , [11040,11041]
operator: , [11068,11069]
===
match
---
simple_stmt [57021,57047]
simple_stmt [57041,57067]
===
match
---
name: default_subject [69527,69542]
name: default_subject [69547,69562]
===
match
---
name: State [13146,13151]
name: State [13166,13171]
===
match
---
trailer [11888,11904]
trailer [11916,11932]
===
match
---
name: task_id [47059,47066]
name: task_id [47079,47086]
===
match
---
operator: , [10062,10063]
operator: , [10090,10091]
===
match
---
atom [60066,60068]
atom [60086,60088]
===
match
---
operator: , [54580,54581]
operator: , [54600,54601]
===
match
---
argument [34678,34710]
argument [34698,34730]
===
match
---
name: str [69481,69484]
name: str [69501,69504]
===
match
---
name: subject [72376,72383]
name: subject [72396,72403]
===
match
---
name: operator [23577,23585]
name: operator [23597,23605]
===
match
---
suite [5400,5597]
suite [5428,5625]
===
match
---
simple_stmt [53058,53092]
simple_stmt [53078,53112]
===
match
---
trailer [58905,58909]
trailer [58925,58929]
===
match
---
operator: , [53451,53452]
operator: , [53471,53472]
===
match
---
atom_expr [23457,23473]
atom_expr [23477,23493]
===
match
---
testlist_comp [67544,67582]
testlist_comp [67564,67602]
===
match
---
trailer [69057,69062]
trailer [69077,69082]
===
match
---
name: session [29611,29618]
name: session [29631,29638]
===
match
---
name: self [58195,58199]
name: self [58215,58219]
===
match
---
suite [3580,3603]
suite [3608,3631]
===
match
---
string: '\n' [69504,69508]
string: '\n' [69524,69528]
===
match
---
operator: ** [9492,9494]
operator: ** [9520,9522]
===
match
---
operator: = [22470,22471]
operator: = [22490,22491]
===
match
---
operator: = [77255,77256]
operator: = [77275,77276]
===
match
---
operator: = [50600,50601]
operator: = [50620,50621]
===
match
---
simple_stmt [43014,43052]
simple_stmt [43034,43072]
===
match
---
atom_expr [12176,12195]
atom_expr [12196,12215]
===
match
---
argument [39782,39813]
argument [39802,39833]
===
match
---
name: signal [48612,48618]
name: signal [48632,48638]
===
match
---
name: _set_context [77935,77947]
name: _set_context [77955,77967]
===
match
---
name: the_log [19005,19012]
name: the_log [19025,19032]
===
match
---
name: self [55990,55994]
name: self [56010,56014]
===
match
---
trailer [3274,3284]
trailer [3302,3312]
===
match
---
name: _date_or_empty [43858,43872]
name: _date_or_empty [43878,43892]
===
match
---
string: 'end_date' [45435,45445]
string: 'end_date' [45455,45465]
===
match
---
name: self [81514,81518]
name: self [81534,81538]
===
match
---
trailer [60653,60668]
trailer [60673,60688]
===
match
---
name: task_id [77066,77073]
name: task_id [77086,77093]
===
match
---
fstring_expr [62431,62442]
fstring_expr [62451,62462]
===
match
---
trailer [70738,70983]
trailer [70758,71003]
===
match
---
expr_stmt [63107,63136]
expr_stmt [63127,63156]
===
match
---
decorated [13328,13879]
decorated [13348,13899]
===
match
---
if_stmt [51354,51709]
if_stmt [51374,51729]
===
match
---
name: in_ [78891,78894]
name: in_ [78911,78914]
===
match
---
atom_expr [48791,48808]
atom_expr [48811,48828]
===
match
---
param [50780,50792]
param [50800,50812]
===
match
---
param [41847,41880]
param [41867,41900]
===
match
---
comparison [23975,24003]
comparison [23995,24023]
===
match
---
string: """     Sets the current execution context to the provided context object.     This method should be called once per Task execution, before calling operator.execute.     """ [3361,3534]
string: """     Sets the current execution context to the provided context object.     This method should be called once per Task execution, before calling operator.execute.     """ [3389,3562]
===
match
---
trailer [19583,19587]
trailer [19603,19607]
===
match
---
string: '%Y-%m-%d' [60678,60688]
string: '%Y-%m-%d' [60698,60708]
===
match
---
operator: , [65843,65844]
operator: , [65863,65864]
===
match
---
trailer [53776,53781]
trailer [53796,53801]
===
match
---
name: execution_date [74144,74158]
name: execution_date [74164,74178]
===
match
---
name: task_id [19121,19128]
name: task_id [19141,19148]
===
match
---
name: error [59344,59349]
name: error [59364,59369]
===
match
---
name: task_copy [49515,49524]
name: task_copy [49535,49544]
===
match
---
atom_expr [57085,57121]
atom_expr [57105,57141]
===
match
---
trailer [35494,35501]
trailer [35514,35521]
===
match
---
name: context_to_airflow_vars [2648,2671]
name: context_to_airflow_vars [2633,2656]
===
match
---
operator: = [71007,71008]
operator: = [71027,71028]
===
match
---
operator: -> [80772,80774]
operator: -> [80792,80794]
===
match
---
atom_expr [5952,5975]
atom_expr [5980,6003]
===
match
---
trailer [53039,53041]
trailer [53059,53061]
===
match
---
atom_expr [7680,7724]
atom_expr [7708,7752]
===
match
---
atom_expr [80641,80653]
atom_expr [80661,80673]
===
match
---
expr_stmt [27090,27158]
expr_stmt [27110,27178]
===
match
---
expr_stmt [54369,54411]
expr_stmt [54389,54431]
===
match
---
trailer [33824,33829]
trailer [33844,33849]
===
match
---
arglist [62630,62660]
arglist [62650,62680]
===
match
---
operator: = [53243,53244]
operator: = [53263,53264]
===
match
---
fstring_string:  [ [33057,33059]
fstring_string:  [ [33077,33079]
===
match
---
return_stmt [14913,15467]
return_stmt [14933,15487]
===
match
---
atom_expr [9995,10030]
atom_expr [10023,10058]
===
match
---
atom_expr [52785,52805]
atom_expr [52805,52825]
===
match
---
atom_expr [14920,15467]
atom_expr [14940,15487]
===
match
---
funcdef [63871,63923]
funcdef [63891,63943]
===
match
---
atom_expr [21572,21779]
atom_expr [21592,21799]
===
match
---
name: get_template_context [53250,53270]
name: get_template_context [53270,53290]
===
match
---
operator: , [15223,15224]
operator: , [15243,15244]
===
match
---
name: refresh_from_db [43146,43161]
name: refresh_from_db [43166,43181]
===
match
---
simple_stmt [77871,77899]
simple_stmt [77891,77919]
===
match
---
name: exception [71575,71584]
name: exception [71595,71604]
===
match
---
name: append [5290,5296]
name: append [5318,5324]
===
match
---
name: task [58947,58951]
name: task [58967,58971]
===
match
---
param [52356,52361]
param [52376,52381]
===
match
---
name: Optional [41817,41825]
name: Optional [41837,41845]
===
match
---
fstring_string: .duration [48809,48818]
fstring_string: .duration [48829,48838]
===
match
---
simple_stmt [42899,42952]
simple_stmt [42919,42972]
===
match
---
atom_expr [82080,82099]
atom_expr [82100,82119]
===
match
---
arith_expr [13978,13998]
arith_expr [13998,14018]
===
match
---
simple_stmt [78414,78444]
simple_stmt [78434,78464]
===
match
---
name: self [59588,59592]
name: self [59608,59612]
===
match
---
name: tomorrow_ds [65756,65767]
name: tomorrow_ds [65776,65787]
===
match
---
subscriptlist [78016,78047]
subscriptlist [78036,78067]
===
match
---
name: collections [921,932]
name: collections [906,917]
===
match
---
name: start_date [39289,39299]
name: start_date [39309,39319]
===
match
---
name: Session [73239,73246]
name: Session [73259,73266]
===
match
---
simple_stmt [48428,48490]
simple_stmt [48448,48510]
===
match
---
atom_expr [18196,18233]
atom_expr [18216,18253]
===
match
---
name: tis [78713,78716]
name: tis [78733,78736]
===
match
---
trailer [21632,21639]
trailer [21652,21659]
===
match
---
name: task_id [21681,21688]
name: task_id [21701,21708]
===
match
---
simple_stmt [58077,58117]
simple_stmt [58097,58137]
===
match
---
atom_expr [23520,23540]
atom_expr [23540,23560]
===
match
---
name: TemplateAssertionError [67544,67566]
name: TemplateAssertionError [67564,67586]
===
match
---
parameters [62957,62963]
parameters [62977,62983]
===
match
---
param [23655,23667]
param [23675,23687]
===
match
---
name: kubernetes [3081,3091]
name: kubernetes [3109,3119]
===
match
---
trailer [19546,19556]
trailer [19566,19576]
===
match
---
name: field_name [66604,66614]
name: field_name [66624,66634]
===
match
---
operator: @ [29098,29099]
operator: @ [29118,29119]
===
match
---
name: ds [62107,62109]
name: ds [62127,62129]
===
match
---
trailer [3264,3274]
trailer [3292,3302]
===
match
---
decorated [23608,24149]
decorated [23628,24169]
===
match
---
operator: = [56225,56226]
operator: = [56245,56246]
===
match
---
suite [63090,63169]
suite [63110,63189]
===
match
---
name: ti [5938,5940]
name: ti [5966,5968]
===
match
---
name: TaskInstance [20355,20367]
name: TaskInstance [20375,20387]
===
match
---
simple_stmt [22288,22362]
simple_stmt [22308,22382]
===
match
---
name: bool [15689,15693]
name: bool [15709,15713]
===
match
---
operator: , [1327,1328]
operator: , [1312,1313]
===
match
---
simple_stmt [10278,10300]
simple_stmt [10306,10328]
===
match
---
operator: = [14357,14358]
operator: = [14377,14378]
===
match
---
trailer [58512,58520]
trailer [58532,58540]
===
match
---
name: start_date [80844,80854]
name: start_date [80864,80874]
===
match
---
trailer [72037,72042]
trailer [72057,72062]
===
match
---
name: bool [15650,15654]
name: bool [15670,15674]
===
match
---
name: ignore_task_deps [15757,15773]
name: ignore_task_deps [15777,15793]
===
match
---
name: Column [10176,10182]
name: Column [10204,10210]
===
match
---
name: SUCCESS [37813,37820]
name: SUCCESS [37833,37840]
===
match
---
suite [77317,77370]
suite [77337,77390]
===
match
---
argument [44338,44353]
argument [44358,44373]
===
match
---
name: airflow_context_vars [49441,49461]
name: airflow_context_vars [49461,49481]
===
match
---
annassign [79949,79975]
annassign [79969,79995]
===
match
---
simple_stmt [37834,37875]
simple_stmt [37854,37895]
===
match
---
name: PickleType [10329,10339]
name: PickleType [10357,10367]
===
match
---
tfpdef [35885,35906]
tfpdef [35905,35926]
===
match
---
name: test_mode [12445,12454]
name: test_mode [12465,12474]
===
match
---
name: UtcDateTime [9684,9695]
name: UtcDateTime [9712,9723]
===
match
---
suite [73269,74410]
suite [73289,74430]
===
match
---
name: self [13298,13302]
name: self [13318,13322]
===
match
---
name: str [8066,8069]
name: str [8094,8097]
===
match
---
param [45802,45814]
param [45822,45834]
===
match
---
simple_stmt [8378,8463]
simple_stmt [8406,8491]
===
match
---
trailer [10221,10234]
trailer [10249,10262]
===
match
---
trailer [79818,79825]
trailer [79838,79845]
===
match
---
name: self [50866,50870]
name: self [50886,50890]
===
match
---
simple_stmt [72026,72045]
simple_stmt [72046,72065]
===
match
---
operator: , [68915,68916]
operator: , [68935,68936]
===
match
---
atom_expr [14988,15000]
atom_expr [15008,15020]
===
match
---
name: self [50462,50466]
name: self [50482,50486]
===
match
---
name: info [47258,47262]
name: info [47278,47282]
===
match
---
name: get_template_context [71465,71485]
name: get_template_context [71485,71505]
===
match
---
expr_stmt [37673,37693]
expr_stmt [37693,37713]
===
match
---
name: on_execute_callback [52083,52102]
name: on_execute_callback [52103,52122]
===
match
---
trailer [34786,34791]
trailer [34806,34811]
===
match
---
arglist [24306,24369]
arglist [24326,24389]
===
match
---
operator: , [34611,34612]
operator: , [34631,34632]
===
match
---
simple_stmt [7312,7354]
simple_stmt [7340,7382]
===
match
---
expr_stmt [40861,40883]
expr_stmt [40881,40903]
===
match
---
tfpdef [15974,15995]
tfpdef [15994,16015]
===
match
---
expr_stmt [39042,39077]
expr_stmt [39062,39097]
===
match
---
name: hashlib [33817,33824]
name: hashlib [33837,33844]
===
match
---
name: result [51814,51820]
name: result [51834,51840]
===
match
---
trailer [39097,39103]
trailer [39117,39123]
===
match
---
name: _try_number [40724,40735]
name: _try_number [40744,40755]
===
match
---
operator: , [35983,35984]
operator: , [36003,36004]
===
match
---
name: DagRun [46134,46140]
name: DagRun [46154,46160]
===
match
---
name: State [2819,2824]
name: State [2847,2852]
===
match
---
name: __init__ [63875,63883]
name: __init__ [63895,63903]
===
match
---
name: strftime [62167,62175]
name: strftime [62187,62195]
===
match
---
operator: , [59237,59238]
operator: , [59257,59258]
===
match
---
atom_expr [57189,57208]
atom_expr [57209,57228]
===
match
---
trailer [49339,49394]
trailer [49359,49414]
===
match
---
operator: = [56901,56902]
operator: = [56921,56922]
===
match
---
trailer [42888,42890]
trailer [42908,42910]
===
match
---
atom_expr [79962,79975]
atom_expr [79982,79995]
===
match
---
name: str [81105,81108]
name: str [81125,81128]
===
match
---
name: ignore_task_deps [35845,35861]
name: ignore_task_deps [35865,35881]
===
match
---
comparison [24858,24886]
comparison [24878,24906]
===
match
---
trailer [66592,66631]
trailer [66612,66651]
===
match
---
argument [42710,42728]
argument [42730,42748]
===
match
---
argument [74226,74237]
argument [74246,74257]
===
match
---
name: execution_date [60844,60858]
name: execution_date [60864,60878]
===
match
---
name: ti [79422,79424]
name: ti [79442,79444]
===
match
---
name: self [80260,80264]
name: self [80280,80284]
===
match
---
operator: @ [26423,26424]
operator: @ [26443,26444]
===
match
---
atom_expr [74593,74606]
atom_expr [74613,74626]
===
match
---
operator: = [15694,15695]
operator: = [15714,15715]
===
match
---
atom_expr [5989,5997]
atom_expr [6017,6025]
===
match
---
if_stmt [61872,62086]
if_stmt [61892,62106]
===
match
---
operator: , [53606,53607]
operator: , [53626,53627]
===
match
---
comparison [27644,27661]
comparison [27664,27681]
===
match
---
operator: , [14362,14363]
operator: , [14382,14383]
===
match
---
name: var [64114,64117]
name: var [64134,64137]
===
match
---
operator: = [15819,15820]
operator: = [15839,15840]
===
match
---
name: task [47166,47170]
name: task [47186,47190]
===
match
---
argument [76549,76563]
argument [76569,76583]
===
match
---
operator: { [62415,62416]
operator: { [62435,62436]
===
match
---
suite [3356,3897]
suite [3384,3925]
===
match
---
atom_expr [76495,76514]
atom_expr [76515,76534]
===
match
---
name: previous_scheduled_date [27307,27330]
name: previous_scheduled_date [27327,27350]
===
match
---
trailer [65346,65354]
trailer [65366,65374]
===
match
---
try_stmt [4108,4248]
try_stmt [4136,4276]
===
match
---
except_clause [44404,44432]
except_clause [44424,44452]
===
match
---
trailer [47262,47278]
trailer [47282,47298]
===
match
---
name: execution_date [11918,11932]
name: execution_date [11946,11960]
===
match
---
param [22941,22946]
param [22961,22966]
===
match
---
trailer [80804,80820]
trailer [80824,80840]
===
match
---
name: self [59491,59495]
name: self [59511,59515]
===
match
---
name: self [22564,22568]
name: self [22584,22588]
===
match
---
operator: , [35720,35721]
operator: , [35740,35741]
===
match
---
simple_stmt [19332,19423]
simple_stmt [19352,19443]
===
match
---
name: len [26388,26391]
name: len [26408,26411]
===
match
---
simple_stmt [18812,18849]
simple_stmt [18832,18869]
===
match
---
operator: = [7933,7934]
operator: = [7961,7962]
===
match
---
name: self [22741,22745]
name: self [22761,22765]
===
match
---
name: min [34778,34781]
name: min [34798,34801]
===
match
---
parameters [13275,13288]
parameters [13295,13308]
===
match
---
expr_stmt [69527,69568]
expr_stmt [69547,69588]
===
match
---
operator: { [7698,7699]
operator: { [7726,7727]
===
match
---
suite [61895,62086]
suite [61915,62106]
===
match
---
simple_stmt [2787,2825]
simple_stmt [2815,2853]
===
match
---
name: ignore_task_deps [54063,54079]
name: ignore_task_deps [54083,54099]
===
match
---
string: "&downstream=false" [19819,19838]
string: "&downstream=false" [19839,19858]
===
match
---
trailer [60803,60815]
trailer [60823,60835]
===
match
---
import_from [60260,60300]
import_from [60280,60320]
===
match
---
name: raw [18670,18673]
name: raw [18690,18693]
===
match
---
arglist [39580,39814]
arglist [39600,39834]
===
match
---
operator: = [65493,65494]
operator: = [65513,65514]
===
match
---
argument [79267,79480]
argument [79287,79500]
===
match
---
name: reduced [8334,8341]
name: reduced [8362,8369]
===
match
---
operator: , [64680,64681]
operator: , [64700,64701]
===
match
---
simple_stmt [54700,54775]
simple_stmt [54720,54795]
===
match
---
argument [68875,68915]
argument [68895,68935]
===
match
---
tfpdef [8602,8617]
tfpdef [8630,8645]
===
match
---
operator: = [68884,68885]
operator: = [68904,68905]
===
match
---
operator: = [41756,41757]
operator: = [41776,41777]
===
match
---
string: '%Y-%m-%d' [61671,61681]
string: '%Y-%m-%d' [61691,61701]
===
match
---
name: try_number [71673,71683]
name: try_number [71693,71703]
===
match
---
expr_stmt [43196,43222]
expr_stmt [43216,43242]
===
match
---
name: dependencies_deps [2324,2341]
name: dependencies_deps [2309,2326]
===
match
---
expr_stmt [26347,26363]
expr_stmt [26367,26383]
===
match
---
expr_stmt [67477,67523]
expr_stmt [67497,67543]
===
match
---
trailer [6964,6970]
trailer [6992,6998]
===
match
---
trailer [37499,37504]
trailer [37519,37524]
===
match
---
name: self [63160,63164]
name: self [63180,63184]
===
match
---
name: end_date [80929,80937]
name: end_date [80949,80957]
===
match
---
name: self [82153,82157]
name: self [82173,82177]
===
match
---
trailer [41326,41330]
trailer [41346,41350]
===
match
---
name: task_id [24324,24331]
name: task_id [24344,24351]
===
match
---
name: self [77948,77952]
name: self [77968,77972]
===
match
---
trailer [7767,7802]
trailer [7795,7830]
===
match
---
expr_stmt [10165,10196]
expr_stmt [10193,10224]
===
match
---
atom_expr [68320,68334]
atom_expr [68340,68354]
===
match
---
name: result [76964,76970]
name: result [76984,76990]
===
match
---
operator: , [11100,11101]
operator: , [11128,11129]
===
match
---
operator: = [18963,18964]
operator: = [18983,18984]
===
match
---
operator: { [33059,33060]
operator: { [33079,33080]
===
match
---
name: session [45571,45578]
name: session [45591,45598]
===
match
---
atom_expr [56957,57012]
atom_expr [56977,57032]
===
match
---
atom_expr [4435,4457]
atom_expr [4463,4485]
===
match
---
simple_stmt [10127,10161]
simple_stmt [10155,10189]
===
match
---
operator: = [14846,14847]
operator: = [14866,14867]
===
match
---
suite [51385,51639]
suite [51405,51659]
===
match
---
name: task [71797,71801]
name: task [71817,71821]
===
match
---
name: TaskInstance [20409,20421]
name: TaskInstance [20429,20441]
===
match
---
simple_stmt [77196,77224]
simple_stmt [77216,77244]
===
match
---
atom_expr [52830,52863]
atom_expr [52850,52883]
===
match
---
name: ignore_ti_state [54126,54141]
name: ignore_ti_state [54146,54161]
===
match
---
atom_expr [71792,71820]
atom_expr [71812,71840]
===
match
---
param [22935,22940]
param [22955,22960]
===
match
---
trailer [22862,22866]
trailer [22882,22886]
===
match
---
name: extend [18200,18206]
name: extend [18220,18226]
===
match
---
arith_expr [71668,71687]
arith_expr [71688,71707]
===
match
---
trailer [78645,78717]
trailer [78665,78737]
===
match
---
parameters [23648,23668]
parameters [23668,23688]
===
match
---
trailer [65306,65334]
trailer [65326,65354]
===
match
---
trailer [43912,43927]
trailer [43932,43947]
===
match
---
operator: , [63047,63048]
operator: , [63067,63068]
===
match
---
name: ti [20515,20517]
name: ti [20535,20537]
===
match
---
trailer [74191,74409]
trailer [74211,74429]
===
match
---
name: session [57162,57169]
name: session [57182,57189]
===
match
---
name: lock_for_update [43162,43177]
name: lock_for_update [43182,43197]
===
match
---
name: self [47481,47485]
name: self [47501,47505]
===
match
---
atom_expr [40637,40652]
atom_expr [40657,40672]
===
match
---
dotted_name [2130,2153]
dotted_name [2115,2138]
===
match
---
trailer [59778,59783]
trailer [59798,59803]
===
match
---
name: TemplateAssertionError [66723,66745]
name: TemplateAssertionError [66743,66765]
===
match
---
and_test [5370,5399]
and_test [5398,5427]
===
match
---
operator: = [28502,28503]
operator: = [28522,28523]
===
match
---
name: get_many [76458,76466]
name: get_many [76478,76486]
===
match
---
name: State [58208,58213]
name: State [58228,58233]
===
match
---
comparison [52677,52713]
comparison [52697,52733]
===
match
---
name: _run_execute_callback [49610,49631]
name: _run_execute_callback [49630,49651]
===
match
---
suite [13289,13323]
suite [13309,13343]
===
match
---
decorator [80911,80921]
decorator [80931,80941]
===
match
---
string: "DagModel" [10916,10926]
string: "DagModel" [10944,10954]
===
match
---
operator: , [71953,71954]
operator: , [71973,71974]
===
match
---
atom_expr [78430,78443]
atom_expr [78450,78463]
===
match
---
name: task_id [45296,45303]
name: task_id [45316,45323]
===
match
---
operator: , [32082,32083]
operator: , [32102,32103]
===
match
---
suite [81178,81205]
suite [81198,81225]
===
match
---
simple_stmt [40719,40741]
simple_stmt [40739,40761]
===
match
---
name: self [43908,43912]
name: self [43928,43932]
===
match
---
name: execution_date [73179,73193]
name: execution_date [73199,73213]
===
match
---
simple_stmt [6050,6126]
simple_stmt [6078,6154]
===
match
---
name: dep_context [31895,31906]
name: dep_context [31915,31926]
===
match
---
name: ti [80011,80013]
name: ti [80031,80033]
===
match
---
param [59247,59272]
param [59267,59292]
===
match
---
operator: , [34056,34057]
operator: , [34076,34077]
===
match
---
trailer [71289,71296]
trailer [71309,71316]
===
match
---
name: property [8125,8133]
name: property [8153,8161]
===
match
---
name: self [19688,19692]
name: self [19708,19712]
===
match
---
atom_expr [41358,41367]
atom_expr [41378,41387]
===
match
---
name: html_content [72531,72543]
name: html_content [72551,72563]
===
match
---
name: prev_ti [29567,29574]
name: prev_ti [29587,29594]
===
match
---
name: hostname [37707,37715]
name: hostname [37727,37735]
===
match
---
name: previous_schedule [27120,27137]
name: previous_schedule [27140,27157]
===
match
---
name: airflow [2996,3003]
name: airflow [3024,3031]
===
match
---
simple_stmt [80965,80987]
simple_stmt [80985,81007]
===
match
---
comp_if [47279,47318]
comp_if [47299,47338]
===
match
---
suite [14370,15468]
suite [14390,15488]
===
match
---
expr_stmt [61313,61354]
expr_stmt [61333,61374]
===
match
---
name: pool [37556,37560]
name: pool [37576,37580]
===
match
---
param [56208,56233]
param [56228,56253]
===
match
---
param [53762,53789]
param [53782,53809]
===
match
---
name: render_templates [48840,48856]
name: render_templates [48860,48876]
===
match
---
atom_expr [60759,60778]
atom_expr [60779,60798]
===
match
---
name: ti_key_str [62385,62395]
name: ti_key_str [62405,62415]
===
match
---
atom_expr [35473,35486]
atom_expr [35493,35506]
===
match
---
operator: = [9522,9523]
operator: = [9550,9551]
===
match
---
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [70427,70489]
string: 'Mark success: <a href="{{ti.mark_success_url}}">Link</a><br>' [70447,70509]
===
match
---
return_stmt [38689,38701]
return_stmt [38709,38721]
===
match
---
simple_stmt [49423,49463]
simple_stmt [49443,49483]
===
match
---
name: tomorrow_ds_nodash [65803,65821]
name: tomorrow_ds_nodash [65823,65841]
===
match
---
param [41811,41838]
param [41831,41858]
===
match
---
name: self [50139,50143]
name: self [50159,50163]
===
match
---
operator: , [45863,45864]
operator: , [45883,45884]
===
match
---
simple_stmt [11193,11219]
simple_stmt [11221,11247]
===
match
---
import_name [1176,1200]
import_name [1161,1185]
===
match
---
not_test [39844,39929]
not_test [39864,39949]
===
match
---
simple_stmt [44208,44215]
simple_stmt [44228,44235]
===
match
---
param [24417,24428]
param [24437,24448]
===
match
---
number: 1 [40297,40298]
number: 1 [40317,40318]
===
match
---
simple_stmt [4329,4371]
simple_stmt [4357,4399]
===
match
---
name: bool [15952,15956]
name: bool [15972,15976]
===
match
---
expr_stmt [55327,55360]
expr_stmt [55347,55380]
===
match
---
name: bool [15775,15779]
name: bool [15795,15799]
===
match
---
simple_stmt [29567,29628]
simple_stmt [29587,29648]
===
match
---
string: "--job-id" [18208,18218]
string: "--job-id" [18228,18238]
===
match
---
atom [77551,77818]
atom [77571,77838]
===
match
---
expr_stmt [58129,58168]
expr_stmt [58149,58188]
===
match
---
name: getboolean [62525,62535]
name: getboolean [62545,62555]
===
match
---
name: dag_id [77643,77649]
name: dag_id [77663,77669]
===
match
---
name: error [59338,59343]
name: error [59358,59363]
===
match
---
trailer [71801,71818]
trailer [71821,71838]
===
match
---
name: prev_ti [29643,29650]
name: prev_ti [29663,29670]
===
match
---
atom_expr [69087,69130]
atom_expr [69107,69150]
===
match
---
name: _date_or_empty [45373,45387]
name: _date_or_empty [45393,45407]
===
match
---
name: UtcDateTime [9719,9730]
name: UtcDateTime [9747,9758]
===
match
---
suite [44256,44396]
suite [44276,44416]
===
match
---
simple_stmt [47605,47687]
simple_stmt [47625,47707]
===
match
---
name: dag_id [68459,68465]
name: dag_id [68479,68485]
===
match
---
name: queued_dttm [22763,22774]
name: queued_dttm [22783,22794]
===
match
---
string: "Task received SIGTERM signal" [48557,48587]
string: "Task received SIGTERM signal" [48577,48607]
===
match
---
atom_expr [18124,18164]
atom_expr [18144,18184]
===
match
---
name: UP_FOR_RETRY [25347,25359]
name: UP_FOR_RETRY [25367,25379]
===
match
---
expr_stmt [79796,79825]
expr_stmt [79816,79845]
===
match
---
suite [78718,78934]
suite [78738,78954]
===
match
---
name: timezone [11935,11943]
name: timezone [11963,11971]
===
match
---
trailer [19038,19042]
trailer [19058,19062]
===
match
---
expr_stmt [56887,56920]
expr_stmt [56907,56940]
===
match
---
name: SimpleTaskInstance [79626,79644]
name: SimpleTaskInstance [79646,79664]
===
match
---
operator: = [9653,9654]
operator: = [9681,9682]
===
match
---
operator: , [48371,48372]
operator: , [48391,48392]
===
match
---
name: ignore_depends_on_past [39691,39713]
name: ignore_depends_on_past [39711,39733]
===
match
---
name: cmd [18274,18277]
name: cmd [18294,18297]
===
match
---
name: incr [57027,57031]
name: incr [57047,57051]
===
match
---
name: mark_success [54168,54180]
name: mark_success [54188,54200]
===
match
---
trailer [23939,23946]
trailer [23959,23966]
===
match
---
atom_expr [5183,5196]
atom_expr [5211,5224]
===
match
---
trailer [57031,57046]
trailer [57051,57066]
===
match
---
name: verbose [39916,39923]
name: verbose [39936,39943]
===
match
---
exprlist [66500,66526]
exprlist [66520,66546]
===
match
---
atom_expr [7156,7178]
atom_expr [7184,7206]
===
match
---
operator: , [57005,57006]
operator: , [57025,57026]
===
match
---
atom_expr [31783,31796]
atom_expr [31803,31816]
===
match
---
atom_expr [16089,16098]
atom_expr [16109,16118]
===
match
---
name: try_number [6930,6940]
name: try_number [6958,6968]
===
match
---
simple_stmt [8194,8249]
simple_stmt [8222,8277]
===
match
---
trailer [22038,22047]
trailer [22058,22067]
===
match
---
trailer [69484,69495]
trailer [69504,69515]
===
match
---
name: priority_weight [23385,23400]
name: priority_weight [23405,23420]
===
match
---
name: task [26170,26174]
name: task [26190,26194]
===
match
---
arglist [80400,80421]
arglist [80420,80441]
===
match
---
trailer [60459,60474]
trailer [60479,60494]
===
match
---
operator: + [60859,60860]
operator: + [60879,60880]
===
match
---
string: "rendering of template_fields." [67104,67135]
string: "rendering of template_fields." [67124,67155]
===
match
---
trailer [50870,50876]
trailer [50890,50896]
===
match
---
operator: , [11094,11095]
operator: , [11122,11123]
===
match
---
trailer [39075,39077]
trailer [39095,39097]
===
match
---
suite [49948,50176]
suite [49968,50196]
===
match
---
trailer [82643,82657]
trailer [82663,82677]
===
match
---
name: airflow_context_vars [49364,49384]
name: airflow_context_vars [49384,49404]
===
match
---
name: str [73146,73149]
name: str [73166,73169]
===
match
---
operator: { [19408,19409]
operator: { [19428,19429]
===
match
---
parameters [63951,64015]
parameters [63971,64035]
===
match
---
trailer [40602,40607]
trailer [40622,40627]
===
match
---
name: task [51973,51977]
name: task [51993,51997]
===
match
---
operator: = [10023,10024]
operator: = [10051,10052]
===
match
---
name: filter [82060,82066]
name: filter [82080,82086]
===
match
---
expr_stmt [76936,77100]
expr_stmt [76956,77120]
===
match
---
argument [38331,38362]
argument [38351,38382]
===
match
---
simple_stmt [70997,71134]
simple_stmt [71017,71154]
===
match
---
decorator [26423,26440]
decorator [26443,26460]
===
match
---
name: _run_execute_callback [51927,51948]
name: _run_execute_callback [51947,51968]
===
match
---
number: 1 [10072,10073]
number: 1 [10100,10101]
===
match
---
param [59205,59238]
param [59225,59258]
===
match
---
atom_expr [73021,73077]
atom_expr [73041,73097]
===
match
---
import_from [2672,2721]
import_from [2700,2749]
===
match
---
trailer [55386,55388]
trailer [55406,55408]
===
match
---
operator: = [27881,27882]
operator: = [27901,27902]
===
match
---
name: execution_date [11659,11673]
name: execution_date [11687,11701]
===
match
---
name: airflow [1596,1603]
name: airflow [1581,1588]
===
match
---
suite [39263,39329]
suite [39283,39349]
===
match
---
operator: = [73006,73007]
operator: = [73026,73027]
===
match
---
argument [54399,54410]
argument [54419,54430]
===
match
---
string: '-' [62004,62007]
string: '-' [62024,62027]
===
match
---
name: _try_number [80036,80047]
name: _try_number [80056,80067]
===
match
---
name: ti [6114,6116]
name: ti [6142,6144]
===
match
---
atom_expr [45007,45019]
atom_expr [45027,45039]
===
match
---
dotted_name [2510,2541]
dotted_name [2495,2526]
===
match
---
name: dag_id [20316,20322]
name: dag_id [20336,20342]
===
match
---
simple_stmt [13971,13999]
simple_stmt [13991,14019]
===
match
---
name: get [64231,64234]
name: get [64251,64254]
===
match
---
name: filter_by [46142,46151]
name: filter_by [46162,46171]
===
match
---
suite [71909,72045]
suite [71929,72065]
===
match
---
operator: , [72746,72747]
operator: , [72766,72767]
===
match
---
comparison [54716,54743]
comparison [54736,54763]
===
match
---
name: execution_date [18970,18984]
name: execution_date [18990,19004]
===
match
---
name: t [78972,78973]
name: t [78992,78993]
===
match
---
operator: == [39104,39106]
operator: == [39124,39126]
===
match
---
name: first_task_id [79206,79219]
name: first_task_id [79226,79239]
===
match
---
name: key [73141,73144]
name: key [73161,73164]
===
match
---
trailer [49609,49631]
trailer [49629,49651]
===
match
---
expr_stmt [53289,53317]
expr_stmt [53309,53337]
===
match
---
operator: } [47207,47208]
operator: } [47227,47228]
===
match
---
argument [39668,39713]
argument [39688,39733]
===
match
---
name: test_mode [44888,44897]
name: test_mode [44908,44917]
===
match
---
string: """Return TI Context""" [59928,59951]
string: """Return TI Context""" [59948,59971]
===
match
---
string: """Sets the log context.""" [77871,77898]
string: """Sets the log context.""" [77891,77918]
===
match
---
name: Column [9712,9718]
name: Column [9740,9746]
===
match
---
argument [74285,74303]
argument [74305,74323]
===
match
---
suite [34884,35111]
suite [34904,35131]
===
match
---
name: open [4380,4384]
name: open [4408,4412]
===
match
---
expr_stmt [72283,72359]
expr_stmt [72303,72379]
===
match
---
simple_stmt [78731,78934]
simple_stmt [78751,78954]
===
match
---
name: next_retry_datetime [35069,35088]
name: next_retry_datetime [35089,35108]
===
match
---
string: 'next_ds_nodash' [64919,64935]
string: 'next_ds_nodash' [64939,64955]
===
match
---
argument [70874,70904]
argument [70894,70924]
===
match
---
name: task_id [19693,19700]
name: task_id [19713,19720]
===
match
---
name: utcnow [39069,39075]
name: utcnow [39089,39095]
===
match
---
funcdef [24168,24371]
funcdef [24188,24391]
===
match
---
simple_stmt [79796,79826]
simple_stmt [79816,79846]
===
match
---
param [32380,32392]
param [32400,32412]
===
match
---
suite [81109,81137]
suite [81129,81157]
===
match
---
operator: = [5422,5423]
operator: = [5450,5451]
===
match
---
trailer [60722,60732]
trailer [60742,60752]
===
match
---
operator: , [65662,65663]
operator: , [65682,65683]
===
match
---
or_test [74332,74369]
or_test [74352,74389]
===
match
---
trailer [8164,8184]
trailer [8192,8212]
===
match
---
if_stmt [72850,73013]
if_stmt [72870,73033]
===
match
---
dotted_name [67265,67296]
dotted_name [67285,67316]
===
match
---
operator: @ [64201,64202]
operator: @ [64221,64222]
===
match
---
suite [7303,7483]
suite [7331,7511]
===
match
---
name: session [38656,38663]
name: session [38676,38683]
===
match
---
name: context [68172,68179]
name: context [68192,68199]
===
match
---
name: debug [21507,21512]
name: debug [21527,21532]
===
match
---
trailer [68736,68738]
trailer [68756,68758]
===
match
---
arglist [44885,44920]
arglist [44905,44940]
===
match
---
name: email_for_state [58129,58144]
name: email_for_state [58149,58164]
===
match
---
name: test_mode [59017,59026]
name: test_mode [59037,59046]
===
match
---
or_test [24952,24981]
or_test [24972,25001]
===
match
---
trailer [24703,24707]
trailer [24723,24727]
===
match
---
name: bool [59225,59229]
name: bool [59245,59249]
===
match
---
trailer [41330,41335]
trailer [41350,41355]
===
match
---
trailer [44997,45004]
trailer [45017,45024]
===
match
---
operator: = [50460,50461]
operator: = [50480,50481]
===
match
---
simple_stmt [10165,10197]
simple_stmt [10193,10225]
===
match
---
operator: , [50850,50851]
operator: , [50870,50871]
===
match
---
expr_stmt [8074,8098]
expr_stmt [8102,8126]
===
match
---
trailer [62358,62366]
trailer [62378,62386]
===
match
---
simple_stmt [46940,46999]
simple_stmt [46960,47019]
===
match
---
tfpdef [41773,41794]
tfpdef [41793,41814]
===
match
---
trailer [58549,58584]
trailer [58569,58604]
===
match
---
string: """Set TI duration""" [72820,72841]
string: """Set TI duration""" [72840,72861]
===
match
---
if_stmt [5210,5308]
if_stmt [5238,5336]
===
match
---
if_stmt [62453,62508]
if_stmt [62473,62528]
===
match
---
suite [48821,50609]
suite [48841,50629]
===
match
---
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28295,28446]
string: """             This attribute is deprecated.             Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.             """ [28315,28466]
===
match
---
fstring_start: f' [44980,44982]
fstring_start: f' [45000,45002]
===
match
---
name: ti [5564,5566]
name: ti [5592,5594]
===
match
---
string: 'value' [66018,66025]
string: 'value' [66038,66045]
===
match
---
name: self [40334,40338]
name: self [40354,40358]
===
match
---
operator: , [29024,29025]
operator: , [29044,29045]
===
match
---
atom_expr [52652,52661]
atom_expr [52672,52681]
===
match
---
tfpdef [53724,53745]
tfpdef [53744,53765]
===
match
---
name: file_path [15340,15349]
name: file_path [15360,15369]
===
match
---
comparison [77736,77771]
comparison [77756,77791]
===
match
---
atom_expr [25027,25042]
atom_expr [25047,25062]
===
match
---
name: models [45939,45945]
name: models [45959,45965]
===
match
---
arglist [29598,29626]
arglist [29618,29646]
===
match
---
number: 1000 [10190,10194]
number: 1000 [10218,10222]
===
match
---
name: state [7885,7890]
name: state [7913,7918]
===
match
---
simple_stmt [2991,3064]
simple_stmt [3019,3092]
===
match
---
name: log_message [57974,57985]
name: log_message [57994,58005]
===
match
---
name: self [33022,33026]
name: self [33042,33046]
===
match
---
return_stmt [63529,63579]
return_stmt [63549,63599]
===
match
---
name: airflow [2677,2684]
name: airflow [2705,2712]
===
match
---
trailer [11344,11354]
trailer [11372,11382]
===
match
---
atom_expr [68716,68738]
atom_expr [68736,68758]
===
match
---
trailer [68992,69010]
trailer [69012,69030]
===
match
---
name: key [74623,74626]
name: key [74643,74646]
===
match
---
string: ':' [62249,62252]
string: ':' [62269,62272]
===
match
---
name: self [24936,24940]
name: self [24956,24960]
===
match
---
name: self [62590,62594]
name: self [62610,62614]
===
match
---
name: dep_context [31883,31894]
name: dep_context [31903,31914]
===
match
---
comparison [78949,78967]
comparison [78969,78987]
===
match
---
trailer [58806,58813]
trailer [58826,58833]
===
match
---
name: airflow [2610,2617]
name: airflow [2595,2602]
===
match
---
name: pid [22792,22795]
name: pid [22812,22815]
===
match
---
name: self [44446,44450]
name: self [44466,44470]
===
match
---
name: seek [4025,4029]
name: seek [4053,4057]
===
match
---
trailer [14588,14593]
trailer [14608,14613]
===
match
---
trailer [21847,21853]
trailer [21867,21873]
===
match
---
simple_stmt [3624,3664]
simple_stmt [3652,3692]
===
match
---
dotted_name [35342,35363]
dotted_name [35362,35383]
===
match
---
name: log [39992,39995]
name: log [40012,40015]
===
match
---
name: strftime [41567,41575]
name: strftime [41587,41595]
===
match
---
operator: , [67776,67777]
operator: , [67796,67797]
===
match
---
trailer [20851,20855]
trailer [20871,20875]
===
match
---
name: state [2806,2811]
name: state [2834,2839]
===
match
---
param [64144,64148]
param [64164,64168]
===
match
---
name: start_date [21997,22007]
name: start_date [22017,22027]
===
match
---
name: _execute_task [51134,51147]
name: _execute_task [51154,51167]
===
match
---
name: self [58344,58348]
name: self [58364,58368]
===
match
---
param [21042,21055]
param [21062,21075]
===
match
---
trailer [37574,37584]
trailer [37594,37604]
===
match
---
name: subject [72748,72755]
name: subject [72768,72775]
===
match
---
simple_stmt [7259,7287]
simple_stmt [7287,7315]
===
match
---
expr_stmt [50453,50500]
expr_stmt [50473,50520]
===
match
---
operator: - [25025,25026]
operator: - [25045,25046]
===
match
---
name: try_number [8103,8113]
name: try_number [8131,8141]
===
match
---
name: with_entities [77263,77276]
name: with_entities [77283,77296]
===
match
---
trailer [59224,59230]
trailer [59244,59250]
===
match
---
atom_expr [62520,62576]
atom_expr [62540,62596]
===
match
---
operator: , [53788,53789]
operator: , [53808,53809]
===
match
---
string: 'dag_run' [64662,64671]
string: 'dag_run' [64682,64691]
===
match
---
suite [82332,82362]
suite [82352,82382]
===
match
---
operator: , [65208,65209]
operator: , [65228,65229]
===
match
---
name: dag_id [74585,74591]
name: dag_id [74605,74611]
===
match
---
trailer [22568,22579]
trailer [22588,22599]
===
match
---
name: engine [41112,41118]
name: engine [41132,41138]
===
match
---
name: test_mode [40928,40937]
name: test_mode [40948,40957]
===
match
---
trailer [24713,24761]
trailer [24733,24781]
===
match
---
name: try_number [13265,13275]
name: try_number [13285,13295]
===
match
---
name: get_previous_start_date [65464,65487]
name: get_previous_start_date [65484,65507]
===
match
---
trailer [43512,43516]
trailer [43532,43536]
===
match
---
argument [68929,69011]
argument [68949,69031]
===
match
---
comparison [53105,53137]
comparison [53125,53157]
===
match
---
name: dag_id [7139,7145]
name: dag_id [7167,7173]
===
match
---
operator: , [29234,29235]
operator: , [29254,29255]
===
match
---
operator: , [35950,35951]
operator: , [35970,35971]
===
match
---
simple_stmt [45115,45458]
simple_stmt [45135,45478]
===
match
---
atom_expr [41498,41517]
atom_expr [41518,41537]
===
match
---
trailer [52745,52766]
trailer [52765,52786]
===
match
---
name: Column [9542,9548]
name: Column [9570,9576]
===
match
---
with_item [71985,72000]
with_item [72005,72020]
===
match
---
name: AirflowFailException [1689,1709]
name: AirflowFailException [1674,1694]
===
match
---
trailer [6064,6075]
trailer [6092,6103]
===
match
---
trailer [24117,24121]
trailer [24137,24141]
===
match
---
name: e [43522,43523]
name: e [43542,43543]
===
match
---
name: pid [22801,22804]
name: pid [22821,22824]
===
match
---
simple_stmt [59420,59461]
simple_stmt [59440,59481]
===
match
---
fstring_expr [50650,50671]
fstring_expr [50670,50691]
===
match
---
arglist [28295,28505]
arglist [28315,28525]
===
match
---
atom_expr [20326,20337]
atom_expr [20346,20357]
===
match
---
atom_expr [40792,40816]
atom_expr [40812,40836]
===
match
---
atom_expr [26297,26310]
atom_expr [26317,26330]
===
match
---
name: previous_scheduled_date [27090,27113]
name: previous_scheduled_date [27110,27133]
===
match
---
name: self [48428,48432]
name: self [48448,48452]
===
match
---
param [63195,63199]
param [63215,63219]
===
match
---
funcdef [52329,53366]
funcdef [52349,53386]
===
match
---
operator: , [981,982]
operator: , [966,967]
===
match
---
name: delete_qry [7198,7208]
name: delete_qry [7226,7236]
===
match
---
trailer [52854,52863]
trailer [52874,52883]
===
match
---
if_stmt [18242,18316]
if_stmt [18262,18336]
===
match
---
simple_stmt [49150,49230]
simple_stmt [49170,49250]
===
match
---
name: fd [4057,4059]
name: fd [4085,4087]
===
match
---
atom_expr [6613,7188]
atom_expr [6641,7216]
===
match
---
suite [7869,7953]
suite [7897,7981]
===
match
---
name: schedulable_tis [47226,47241]
name: schedulable_tis [47246,47261]
===
match
---
name: logging [11337,11344]
name: logging [11365,11372]
===
match
---
operator: = [35415,35416]
operator: = [35435,35436]
===
match
---
simple_stmt [55743,55780]
simple_stmt [55763,55800]
===
match
---
trailer [64037,64041]
trailer [64057,64061]
===
match
---
if_stmt [45833,48065]
if_stmt [45853,48085]
===
match
---
name: self [56512,56516]
name: self [56532,56536]
===
match
---
atom_expr [76424,76435]
atom_expr [76444,76455]
===
match
---
argument [50577,50592]
argument [50597,50612]
===
match
---
trailer [60415,60475]
trailer [60435,60495]
===
match
---
atom_expr [52231,52287]
atom_expr [52251,52307]
===
match
---
funcdef [48346,48589]
funcdef [48366,48609]
===
match
---
operator: = [54512,54513]
operator: = [54532,54533]
===
match
---
name: session [76661,76668]
name: session [76681,76688]
===
match
---
name: job_id [54227,54233]
name: job_id [54247,54253]
===
match
---
operator: != [3690,3692]
operator: != [3718,3720]
===
match
---
name: self [37605,37609]
name: self [37625,37629]
===
match
---
operator: = [76944,76945]
operator: = [76964,76965]
===
match
---
operator: -> [52409,52411]
operator: -> [52429,52431]
===
match
---
operator: = [60647,60648]
operator: = [60667,60668]
===
match
---
name: DepContext [2292,2302]
name: DepContext [2277,2287]
===
match
---
name: execution_date [11852,11866]
name: execution_date [11880,11894]
===
match
---
operator: , [14280,14281]
operator: , [14300,14301]
===
match
---
operator: , [31020,31021]
operator: , [31040,31041]
===
match
---
operator: , [18836,18837]
operator: , [18856,18857]
===
match
---
operator: , [41801,41802]
operator: , [41821,41822]
===
match
---
trailer [37844,37874]
trailer [37864,37894]
===
match
---
trailer [44979,45035]
trailer [44999,45055]
===
match
---
name: airflow [2385,2392]
name: airflow [2370,2377]
===
match
---
operator: - [82429,82430]
operator: - [82449,82450]
===
match
---
trailer [21996,22007]
trailer [22016,22027]
===
match
---
name: self [54424,54428]
name: self [54444,54448]
===
match
---
simple_stmt [40979,40996]
simple_stmt [40999,41016]
===
match
---
name: items [6965,6970]
name: items [6993,6998]
===
match
---
trailer [57182,57241]
trailer [57202,57261]
===
match
---
expr_stmt [47016,47208]
expr_stmt [47036,47228]
===
match
---
suite [18564,18601]
suite [18584,18621]
===
match
---
expr_stmt [79984,80022]
expr_stmt [80004,80042]
===
match
---
name: execution_timeout [51367,51384]
name: execution_timeout [51387,51404]
===
match
---
name: self [43508,43512]
name: self [43528,43532]
===
match
---
atom_expr [54424,54670]
atom_expr [54444,54690]
===
match
---
decorator [25396,25413]
decorator [25416,25433]
===
match
---
expr_stmt [25932,25948]
expr_stmt [25952,25968]
===
match
---
atom_expr [8277,8289]
atom_expr [8305,8317]
===
match
---
tfpdef [59205,59230]
tfpdef [59225,59250]
===
match
---
name: reschedule_exception [44163,44183]
name: reschedule_exception [44183,44203]
===
match
---
expr_stmt [46074,46340]
expr_stmt [46094,46360]
===
match
---
trailer [71399,71416]
trailer [71419,71436]
===
match
---
operator: = [35782,35783]
operator: = [35802,35803]
===
match
---
operator: = [49796,49797]
operator: = [49816,49817]
===
match
---
operator: = [23270,23271]
operator: = [23290,23291]
===
match
---
name: self [62958,62962]
name: self [62978,62982]
===
match
---
operator: @ [25396,25397]
operator: @ [25416,25417]
===
match
---
name: State [29078,29083]
name: State [29098,29103]
===
match
---
operator: -> [4316,4318]
operator: -> [4344,4346]
===
match
---
sync_comp_for [78905,78917]
sync_comp_for [78925,78937]
===
match
---
expr_stmt [23520,23563]
expr_stmt [23540,23583]
===
match
---
name: error_file [44767,44777]
name: error_file [44787,44797]
===
match
---
param [53447,53452]
param [53467,53472]
===
match
---
operator: = [74607,74608]
operator: = [74627,74628]
===
match
---
simple_stmt [36104,37480]
simple_stmt [36124,37500]
===
match
---
operator: = [10282,10283]
operator: = [10310,10311]
===
match
---
atom_expr [51846,51895]
atom_expr [51866,51915]
===
match
---
atom_expr [60584,60605]
atom_expr [60604,60625]
===
match
---
name: max [34623,34626]
name: max [34643,34646]
===
match
---
trailer [67403,67409]
trailer [67423,67429]
===
match
---
trailer [4668,4675]
trailer [4696,4703]
===
match
---
name: dep_status [31840,31850]
name: dep_status [31860,31870]
===
match
---
name: self [35027,35031]
name: self [35047,35051]
===
match
---
name: verbose [53938,53945]
name: verbose [53958,53965]
===
match
---
expr_stmt [58297,58334]
expr_stmt [58317,58354]
===
match
---
number: 0 [26361,26362]
number: 0 [26381,26382]
===
match
---
suite [18344,18395]
suite [18364,18415]
===
match
---
fstring_expr [47961,47974]
fstring_expr [47981,47994]
===
match
---
trailer [43872,43890]
trailer [43892,43910]
===
match
---
name: sanitized_pod [69146,69159]
name: sanitized_pod [69166,69179]
===
match
---
name: self [52877,52881]
name: self [52897,52901]
===
match
---
atom_expr [15982,15995]
atom_expr [16002,16015]
===
match
---
trailer [9873,9882]
trailer [9901,9910]
===
match
---
name: UndefinedError [66747,66761]
name: UndefinedError [66767,66781]
===
match
---
trailer [6109,6113]
trailer [6137,6141]
===
match
---
name: str [18220,18223]
name: str [18240,18243]
===
match
---
simple_stmt [30876,30933]
simple_stmt [30896,30953]
===
match
---
atom_expr [27345,27351]
atom_expr [27365,27371]
===
match
---
trailer [34599,34647]
trailer [34619,34667]
===
match
---
name: self [32521,32525]
name: self [32541,32545]
===
match
---
name: force_fail [56208,56218]
name: force_fail [56228,56238]
===
match
---
parameters [79762,79786]
parameters [79782,79806]
===
match
---
atom_expr [57227,57240]
atom_expr [57247,57260]
===
match
---
atom_expr [62107,62126]
atom_expr [62127,62146]
===
match
---
trailer [7686,7693]
trailer [7714,7721]
===
match
---
operator: == [37804,37806]
operator: == [37824,37826]
===
match
---
operator: , [51161,51162]
operator: , [51181,51182]
===
match
---
simple_stmt [71146,71219]
simple_stmt [71166,71239]
===
match
---
name: execute [51684,51691]
name: execute [51704,51711]
===
match
---
name: str [3203,3206]
name: str [3231,3234]
===
match
---
funcdef [13261,13323]
funcdef [13281,13343]
===
match
---
simple_stmt [9701,9732]
simple_stmt [9729,9760]
===
match
---
tfpdef [16012,16031]
tfpdef [16032,16051]
===
match
---
name: end_date [34836,34844]
name: end_date [34856,34864]
===
match
---
expr_stmt [62326,62375]
expr_stmt [62346,62395]
===
match
---
decorator [20616,20633]
decorator [20636,20653]
===
match
---
parameters [14023,14369]
parameters [14043,14389]
===
match
---
operator: == [23988,23990]
operator: == [24008,24010]
===
match
---
number: 0 [4030,4031]
number: 0 [4058,4059]
===
match
---
name: _priority_weight [80441,80457]
name: _priority_weight [80461,80477]
===
match
---
operator: , [66158,66159]
operator: , [66178,66179]
===
match
---
atom_expr [41322,41389]
atom_expr [41342,41409]
===
match
---
expr_stmt [42646,42672]
expr_stmt [42666,42692]
===
match
---
arglist [71895,71907]
arglist [71915,71927]
===
match
---
trailer [33667,33672]
trailer [33687,33692]
===
match
---
name: state [5174,5179]
name: state [5202,5207]
===
match
---
operator: = [29575,29576]
operator: = [29595,29596]
===
match
---
atom_expr [32894,32911]
atom_expr [32914,32931]
===
match
---
atom_expr [20924,20936]
atom_expr [20944,20956]
===
match
---
name: datetime [73204,73212]
name: datetime [73224,73232]
===
match
---
trailer [45123,45128]
trailer [45143,45148]
===
match
---
trailer [42650,42660]
trailer [42670,42680]
===
match
---
name: dag_id [6068,6074]
name: dag_id [6096,6102]
===
match
---
name: self [67898,67902]
name: self [67918,67922]
===
match
---
trailer [59447,59460]
trailer [59467,59480]
===
match
---
string: '' [62372,62374]
string: '' [62392,62394]
===
match
---
operator: @ [30938,30939]
operator: @ [30958,30959]
===
match
---
name: XCom [74183,74187]
name: XCom [74203,74207]
===
match
---
trailer [38670,38672]
trailer [38690,38692]
===
match
---
atom_expr [42813,42826]
atom_expr [42833,42846]
===
match
---
simple_stmt [49785,49804]
simple_stmt [49805,49824]
===
match
---
name: self [81443,81447]
name: self [81463,81467]
===
match
---
suite [45824,48065]
suite [45844,48085]
===
match
---
lambdef [5094,5139]
lambdef [5122,5167]
===
match
---
atom_expr [49330,49394]
atom_expr [49350,49414]
===
match
---
name: get_templated_fields [66415,66435]
name: get_templated_fields [66435,66455]
===
match
---
trailer [47881,47885]
trailer [47901,47905]
===
match
---
arith_expr [70885,70904]
arith_expr [70905,70924]
===
match
---
trailer [35108,35110]
trailer [35128,35130]
===
match
---
trailer [59689,59712]
trailer [59709,59732]
===
match
---
trailer [11483,11496]
trailer [11511,11524]
===
match
---
name: set_duration [72784,72796]
name: set_duration [72804,72816]
===
match
---
simple_stmt [61632,61683]
simple_stmt [61652,61703]
===
match
---
name: filepath [14761,14769]
name: filepath [14781,14789]
===
match
---
decorator [73083,73100]
decorator [73103,73120]
===
match
---
name: dag [61490,61493]
name: dag [61510,61513]
===
match
---
name: execution_date [11452,11466]
name: execution_date [11480,11494]
===
match
---
param [81165,81169]
param [81185,81189]
===
match
---
simple_stmt [9855,9883]
simple_stmt [9883,9911]
===
match
---
import_from [2562,2604]
import_from [2547,2589]
===
match
---
name: task_copy [51507,51516]
name: task_copy [51527,51536]
===
match
---
string: 'ds_nodash' [64716,64727]
string: 'ds_nodash' [64736,64747]
===
match
---
name: _update_ti_state_for_sensing [50327,50355]
name: _update_ti_state_for_sensing [50347,50375]
===
match
---
atom_expr [48612,48626]
atom_expr [48632,48646]
===
match
---
decorated [35604,41410]
decorated [35624,41430]
===
match
---
atom_expr [24290,24370]
atom_expr [24310,24390]
===
match
---
simple_stmt [80077,80105]
simple_stmt [80097,80125]
===
match
---
name: test_mode [45501,45510]
name: test_mode [45521,45530]
===
match
---
operator: , [78789,78790]
operator: , [78809,78810]
===
match
---
name: dagrun [35357,35363]
name: dagrun [35377,35383]
===
match
---
trailer [62405,62412]
trailer [62425,62432]
===
match
---
name: __getattr__ [63940,63951]
name: __getattr__ [63960,63971]
===
match
---
string: "airflow.task" [11355,11369]
string: "airflow.task" [11383,11397]
===
match
---
trailer [16093,16098]
trailer [16113,16118]
===
match
---
name: info [31792,31796]
name: info [31812,31816]
===
match
---
trailer [29781,29786]
trailer [29801,29806]
===
match
---
operator: , [20459,20460]
operator: , [20479,20480]
===
match
---
fstring_expr [33036,33057]
fstring_expr [33056,33077]
===
match
---
operator: , [10698,10699]
operator: , [10726,10727]
===
match
---
atom_expr [50407,50435]
atom_expr [50427,50455]
===
match
---
trailer [25057,25059]
trailer [25077,25079]
===
match
---
name: warn [30621,30625]
name: warn [30641,30645]
===
match
---
atom [76946,77100]
atom [76966,77120]
===
match
---
trailer [3657,3661]
trailer [3685,3689]
===
match
---
operator: = [70136,70137]
operator: = [70156,70157]
===
match
---
operator: = [15890,15891]
operator: = [15910,15911]
===
match
---
name: State [43209,43214]
name: State [43229,43234]
===
match
---
atom_expr [22582,22595]
atom_expr [22602,22615]
===
match
---
suite [80784,80821]
suite [80804,80841]
===
match
---
operator: = [38346,38347]
operator: = [38366,38367]
===
match
---
trailer [18206,18233]
trailer [18226,18253]
===
match
---
trailer [79838,79847]
trailer [79858,79867]
===
match
---
operator: , [28504,28505]
operator: , [28524,28525]
===
match
---
name: Stats [57021,57026]
name: Stats [57041,57046]
===
match
---
atom_expr [49515,49553]
atom_expr [49535,49573]
===
match
---
trailer [24070,24077]
trailer [24090,24097]
===
match
---
atom_expr [24770,24780]
atom_expr [24790,24800]
===
match
---
suite [66568,66632]
suite [66588,66652]
===
match
---
parameters [81589,81632]
parameters [81609,81652]
===
match
---
if_stmt [38012,40517]
if_stmt [38032,40537]
===
match
---
dotted_name [1370,1384]
dotted_name [1355,1369]
===
match
---
dotted_name [2463,2484]
dotted_name [2448,2469]
===
match
---
trailer [67501,67521]
trailer [67521,67541]
===
match
---
atom_expr [29773,29786]
atom_expr [29793,29806]
===
match
---
name: self [63107,63111]
name: self [63127,63131]
===
match
---
atom_expr [6065,6074]
atom_expr [6093,6102]
===
match
---
operator: = [38565,38566]
operator: = [38585,38586]
===
match
---
atom_expr [80188,80201]
atom_expr [80208,80221]
===
match
---
trailer [65427,65433]
trailer [65447,65453]
===
match
---
simple_stmt [1507,1561]
simple_stmt [1492,1546]
===
match
---
simple_stmt [82583,82627]
simple_stmt [82603,82647]
===
match
---
name: str [36010,36013]
name: str [36030,36033]
===
match
---
operator: , [66745,66746]
operator: , [66765,66766]
===
match
---
expr_stmt [42813,42843]
expr_stmt [42833,42863]
===
match
---
decorated [13238,13323]
decorated [13258,13343]
===
match
---
string: 'email' [71895,71902]
string: 'email' [71915,71922]
===
match
---
trailer [55625,55634]
trailer [55645,55654]
===
match
---
trailer [68004,68011]
trailer [68024,68031]
===
match
---
tfpdef [35993,36014]
tfpdef [36013,36034]
===
match
---
name: pool_override [23303,23316]
name: pool_override [23323,23336]
===
match
---
tfpdef [74523,74568]
tfpdef [74543,74588]
===
match
---
if_stmt [20512,20590]
if_stmt [20532,20610]
===
match
---
name: settings [1582,1590]
name: settings [1567,1575]
===
match
---
argument [39731,39764]
argument [39751,39784]
===
match
---
parameters [63285,63462]
parameters [63305,63482]
===
match
---
name: job_ids [7419,7426]
name: job_ids [7447,7454]
===
match
---
trailer [31726,31728]
trailer [31746,31748]
===
match
---
import_as_names [1860,1888]
import_as_names [1845,1873]
===
match
---
operator: = [81625,81626]
operator: = [81645,81646]
===
match
---
atom_expr [80031,80047]
atom_expr [80051,80067]
===
match
---
expr_stmt [23291,23329]
expr_stmt [23311,23349]
===
match
---
operator: @ [13328,13329]
operator: @ [13348,13349]
===
match
---
number: 1 [82430,82431]
number: 1 [82450,82451]
===
match
---
name: ti [7769,7771]
name: ti [7797,7799]
===
match
---
name: expected_state [3867,3881]
name: expected_state [3895,3909]
===
match
---
string: '\n' [49330,49334]
string: '\n' [49350,49354]
===
match
---
name: pendulum [30428,30436]
name: pendulum [30448,30456]
===
match
---
operator: @ [53371,53372]
operator: @ [53391,53392]
===
match
---
trailer [46127,46133]
trailer [46147,46153]
===
match
---
simple_stmt [50554,50609]
simple_stmt [50574,50629]
===
match
---
name: datetime [973,981]
name: datetime [958,966]
===
match
---
name: state [30179,30184]
name: state [30199,30204]
===
match
---
arglist [9817,9849]
arglist [9845,9877]
===
match
---
param [29160,29165]
param [29180,29185]
===
match
---
operator: , [11064,11065]
operator: , [11092,11093]
===
match
---
suite [48136,50715]
suite [48156,50735]
===
match
---
name: os [71076,71078]
name: os [71096,71098]
===
match
---
comparison [59588,59621]
comparison [59608,59641]
===
match
---
name: Session [74711,74718]
name: Session [74731,74738]
===
match
---
decorated [19428,19849]
decorated [19448,19869]
===
match
---
trailer [24956,24965]
trailer [24976,24985]
===
match
---
operator: = [39958,39959]
operator: = [39978,39979]
===
match
---
operator: = [42626,42627]
operator: = [42646,42647]
===
match
---
name: self [81165,81169]
name: self [81185,81189]
===
match
---
atom_expr [68546,68557]
atom_expr [68566,68577]
===
match
---
atom_expr [23991,24003]
atom_expr [24011,24023]
===
match
---
name: ignore_ti_state [18494,18509]
name: ignore_ti_state [18514,18529]
===
match
---
argument [54844,54855]
argument [54864,54875]
===
match
---
name: self [19387,19391]
name: self [19407,19411]
===
match
---
atom_expr [13180,13196]
atom_expr [13200,13216]
===
match
---
simple_stmt [24797,24847]
simple_stmt [24817,24867]
===
match
---
operator: = [9540,9541]
operator: = [9568,9569]
===
match
---
param [13367,13371]
param [13387,13391]
===
match
---
suite [59664,59802]
suite [59684,59822]
===
match
---
atom_expr [39552,39828]
atom_expr [39572,39848]
===
match
---
operator: , [64702,64703]
operator: , [64722,64723]
===
match
---
name: Log [40792,40795]
name: Log [40812,40815]
===
match
---
name: self [24411,24415]
name: self [24431,24435]
===
match
---
return_stmt [32290,32301]
return_stmt [32310,32321]
===
match
---
name: log [11531,11534]
name: log [11559,11562]
===
match
---
operator: , [45252,45253]
operator: , [45272,45273]
===
match
---
atom_expr [11227,11239]
atom_expr [11255,11267]
===
match
---
annassign [8088,8098]
annassign [8116,8126]
===
match
---
name: dep_status [32753,32763]
name: dep_status [32773,32783]
===
match
---
atom_expr [34782,34807]
atom_expr [34802,34827]
===
match
---
parameters [25123,25129]
parameters [25143,25149]
===
match
---
operator: , [54522,54523]
operator: , [54542,54543]
===
match
---
name: self [46236,46240]
name: self [46256,46260]
===
match
---
tfpdef [15906,15930]
tfpdef [15926,15950]
===
match
---
comp_op [47154,47160]
comp_op [47174,47180]
===
match
---
name: session [59395,59402]
name: session [59415,59422]
===
match
---
name: self [33104,33108]
name: self [33124,33128]
===
match
---
operator: = [34776,34777]
operator: = [34796,34797]
===
match
---
param [56114,56119]
param [56134,56139]
===
match
---
name: RenderedTaskInstanceFields [48919,48945]
name: RenderedTaskInstanceFields [48939,48965]
===
match
---
name: path [71079,71083]
name: path [71099,71103]
===
match
---
string: """         Checks dependencies and then sets state to RUNNING if they are met. Returns         True if and only if state is set to RUNNING, which implies that task should be         executed, in preparation for _run_raw_task          :param verbose: whether to turn on more verbose logging         :type verbose: bool         :param ignore_all_deps: Ignore all of the non-critical dependencies, just runs         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past DAG attribute         :type ignore_depends_on_past: bool         :param ignore_task_deps: Don't check the dependencies of this TaskInstance's task         :type ignore_task_deps: bool         :param ignore_ti_state: Disregards previous task instance state         :type ignore_ti_state: bool         :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param job_id: Job (BackfillJob / LocalTaskJob / SchedulerJob) ID         :type job_id: str         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         :return: whether the state was changed to running or not         :rtype: bool         """ [36104,37479]
string: """         Checks dependencies and then sets state to RUNNING if they are met. Returns         True if and only if state is set to RUNNING, which implies that task should be         executed, in preparation for _run_raw_task          :param verbose: whether to turn on more verbose logging         :type verbose: bool         :param ignore_all_deps: Ignore all of the non-critical dependencies, just runs         :type ignore_all_deps: bool         :param ignore_depends_on_past: Ignore depends_on_past DAG attribute         :type ignore_depends_on_past: bool         :param ignore_task_deps: Don't check the dependencies of this TaskInstance's task         :type ignore_task_deps: bool         :param ignore_ti_state: Disregards previous task instance state         :type ignore_ti_state: bool         :param mark_success: Don't run the task, mark its state as success         :type mark_success: bool         :param test_mode: Doesn't record success or failure in the DB         :type test_mode: bool         :param job_id: Job (BackfillJob / LocalTaskJob / SchedulerJob) ID         :type job_id: str         :param pool: specifies the pool to use to run the task instance         :type pool: str         :param session: SQLAlchemy ORM Session         :type session: Session         :return: whether the state was changed to running or not         :rtype: bool         """ [36124,37499]
===
match
---
name: job_id [15396,15402]
name: job_id [15416,15422]
===
match
---
simple_stmt [22496,22520]
simple_stmt [22516,22540]
===
match
---
name: ti [80460,80462]
name: ti [80480,80482]
===
match
---
name: self [30410,30414]
name: self [30430,30434]
===
match
---
name: path [14841,14845]
name: path [14861,14865]
===
match
---
name: info [49251,49255]
name: info [49271,49275]
===
match
---
operator: = [9896,9897]
operator: = [9924,9925]
===
match
---
operator: , [49312,49313]
operator: , [49332,49333]
===
match
---
trailer [46240,46255]
trailer [46260,46275]
===
match
---
operator: = [5080,5081]
operator: = [5108,5109]
===
match
---
atom_expr [66593,66602]
atom_expr [66613,66622]
===
match
---
trailer [7950,7952]
trailer [7978,7980]
===
match
---
operator: , [56118,56119]
operator: , [56138,56139]
===
match
---
simple_stmt [20945,20965]
simple_stmt [20965,20985]
===
match
---
trailer [50576,50608]
trailer [50596,50628]
===
match
---
atom_expr [4057,4066]
atom_expr [4085,4094]
===
match
---
suite [33110,34853]
suite [33130,34873]
===
match
---
name: session [27818,27825]
name: session [27838,27845]
===
match
---
name: innerjoin [11050,11059]
name: innerjoin [11078,11087]
===
match
---
trailer [57231,57240]
trailer [57251,57260]
===
match
---
name: XCom [76453,76457]
name: XCom [76473,76477]
===
match
---
name: RUNNING [40845,40852]
name: RUNNING [40865,40872]
===
match
---
simple_stmt [20219,20504]
simple_stmt [20239,20524]
===
match
---
trailer [29836,29855]
trailer [29856,29875]
===
match
---
atom_expr [79874,79894]
atom_expr [79894,79914]
===
match
---
trailer [62223,62231]
trailer [62243,62251]
===
match
---
atom_expr [18577,18600]
atom_expr [18597,18620]
===
match
---
trailer [18580,18587]
trailer [18600,18607]
===
match
---
name: execution_date [9605,9619]
name: execution_date [9633,9647]
===
match
---
trailer [78882,78890]
trailer [78902,78910]
===
match
---
parameters [34877,34883]
parameters [34897,34903]
===
match
---
atom_expr [43141,43183]
atom_expr [43161,43203]
===
match
---
trailer [19526,19559]
trailer [19546,19579]
===
match
---
name: test_mode [56166,56175]
name: test_mode [56186,56195]
===
match
---
operator: * [37983,37984]
operator: * [38003,38004]
===
match
---
trailer [82308,82310]
trailer [82328,82330]
===
match
---
trailer [50563,50576]
trailer [50583,50596]
===
match
---
name: context [53289,53296]
name: context [53309,53316]
===
match
---
trailer [43963,43978]
trailer [43983,43998]
===
match
---
name: self [51949,51953]
name: self [51969,51973]
===
match
---
simple_stmt [82492,82533]
simple_stmt [82512,82553]
===
match
---
operator: , [55568,55569]
operator: , [55588,55589]
===
match
---
name: ti [20219,20221]
name: ti [20239,20241]
===
match
---
name: hexdigest [34025,34034]
name: hexdigest [34045,34054]
===
match
---
name: task [25932,25936]
name: task [25952,25956]
===
match
---
name: task [14589,14593]
name: task [14609,14613]
===
match
---
simple_stmt [44390,44396]
simple_stmt [44410,44416]
===
match
---
simple_stmt [69071,69131]
simple_stmt [69091,69151]
===
match
---
operator: , [39897,39898]
operator: , [39917,39918]
===
match
---
trailer [43927,43941]
trailer [43947,43961]
===
match
---
string: "Task Duration set to %s" [73036,73061]
string: "Task Duration set to %s" [73056,73081]
===
match
---
operator: , [62643,62644]
operator: , [62663,62664]
===
match
---
trailer [72308,72359]
trailer [72328,72379]
===
match
---
simple_stmt [82382,82402]
simple_stmt [82402,82422]
===
match
---
name: task [42936,42940]
name: task [42956,42960]
===
match
---
arglist [62309,62316]
arglist [62329,62336]
===
match
---
name: property [81459,81467]
name: property [81479,81487]
===
match
---
name: ti [20539,20541]
name: ti [20559,20561]
===
match
---
try_stmt [67456,67695]
try_stmt [67476,67715]
===
match
---
trailer [69441,69455]
trailer [69461,69475]
===
match
---
name: __tablename__ [9423,9436]
name: __tablename__ [9451,9464]
===
match
---
atom_expr [5102,5139]
atom_expr [5130,5167]
===
match
---
string: 'webserver' [19588,19599]
string: 'webserver' [19608,19619]
===
match
---
name: cfg_path [18838,18846]
name: cfg_path [18858,18866]
===
match
---
name: session [41889,41896]
name: session [41909,41916]
===
match
---
operator: = [31915,31916]
operator: = [31935,31936]
===
match
---
suite [24923,25060]
suite [24943,25080]
===
match
---
name: count [26347,26352]
name: count [26367,26372]
===
match
---
not_test [45629,45642]
not_test [45649,45662]
===
match
---
operator: = [40837,40838]
operator: = [40857,40858]
===
match
---
name: min [34596,34599]
name: min [34616,34619]
===
match
---
atom_expr [24017,24036]
atom_expr [24037,24056]
===
match
---
name: extend [18361,18367]
name: extend [18381,18387]
===
match
---
atom_expr [80337,80358]
atom_expr [80357,80378]
===
match
---
atom_expr [49173,49229]
atom_expr [49193,49249]
===
match
---
atom_expr [32470,32482]
atom_expr [32490,32502]
===
match
---
param [51955,51972]
param [51975,51992]
===
match
---
name: bool [53633,53637]
name: bool [53653,53657]
===
match
---
name: render_k8s_pod_yaml [67502,67521]
name: render_k8s_pod_yaml [67522,67541]
===
match
---
suite [12510,12648]
suite [12530,12668]
===
match
---
name: COLLATION_ARGS [1860,1874]
name: COLLATION_ARGS [1845,1859]
===
match
---
name: strftime [60669,60677]
name: strftime [60689,60697]
===
match
---
trailer [10396,10422]
trailer [10424,10450]
===
match
---
operator: = [23455,23456]
operator: = [23475,23476]
===
match
---
atom [18207,18232]
atom [18227,18252]
===
match
---
operator: = [3255,3256]
operator: = [3283,3284]
===
match
---
fstring_expr [33021,33035]
fstring_expr [33041,33055]
===
match
---
parameters [41680,41908]
parameters [41700,41928]
===
match
---
operator: } [33034,33035]
operator: } [33054,33055]
===
match
---
atom_expr [43284,43300]
atom_expr [43304,43320]
===
match
---
name: dag_id [78338,78344]
name: dag_id [78358,78364]
===
match
---
atom_expr [53105,53115]
atom_expr [53125,53135]
===
match
---
simple_stmt [993,1033]
simple_stmt [978,1018]
===
match
---
operator: = [24950,24951]
operator: = [24970,24971]
===
match
---
decorator [41616,41633]
decorator [41636,41653]
===
match
---
name: AirflowException [1667,1683]
name: AirflowException [1652,1668]
===
match
---
operator: = [33794,33795]
operator: = [33814,33815]
===
match
---
operator: , [9838,9839]
operator: , [9866,9867]
===
match
---
trailer [77149,77158]
trailer [77169,77178]
===
match
---
trailer [43557,43579]
trailer [43577,43599]
===
match
---
name: hasattr [80220,80227]
name: hasattr [80240,80247]
===
match
---
atom_expr [66530,66567]
atom_expr [66550,66587]
===
match
---
atom_expr [65689,65703]
atom_expr [65709,65723]
===
match
---
string: 'Marking task as SUCCESS. ' [45142,45169]
string: 'Marking task as SUCCESS. ' [45162,45189]
===
match
---
trailer [28801,29035]
trailer [28821,29055]
===
match
---
operator: , [62235,62236]
operator: , [62255,62256]
===
match
---
name: self [23380,23384]
name: self [23400,23404]
===
match
---
name: commit [40987,40993]
name: commit [41007,41013]
===
match
---
decorator [30938,30955]
decorator [30958,30975]
===
match
---
trailer [36009,36014]
trailer [36029,36034]
===
match
---
name: dag_id [46189,46195]
name: dag_id [46209,46215]
===
match
---
name: operator [10165,10173]
name: operator [10193,10201]
===
match
---
name: pickle_id [18101,18110]
name: pickle_id [18121,18130]
===
match
---
decorated [50720,51125]
decorated [50740,51145]
===
match
---
simple_stmt [81118,81137]
simple_stmt [81138,81157]
===
match
---
operator: , [49204,49205]
operator: , [49224,49225]
===
match
---
return_stmt [81043,81066]
return_stmt [81063,81086]
===
match
---
name: self [63969,63973]
name: self [63989,63993]
===
match
---
name: has_task [5382,5390]
name: has_task [5410,5418]
===
match
---
for_stmt [32549,32950]
for_stmt [32569,32970]
===
match
---
name: session [29795,29802]
name: session [29815,29822]
===
match
---
name: commit [60626,60632]
name: commit [60646,60652]
===
match
---
operator: = [53870,53871]
operator: = [53890,53891]
===
match
---
operator: = [74632,74633]
operator: = [74652,74653]
===
match
---
name: self [22020,22024]
name: self [22040,22044]
===
match
---
name: log [24704,24707]
name: log [24724,24727]
===
match
---
operator: = [11273,11274]
operator: = [11301,11302]
===
match
---
trailer [6616,7188]
trailer [6644,7216]
===
match
---
atom_expr [22416,22429]
atom_expr [22436,22449]
===
match
---
name: task_ids [76586,76594]
name: task_ids [76606,76614]
===
match
---
name: dag_id [76429,76435]
name: dag_id [76449,76455]
===
match
---
if_stmt [82450,82682]
if_stmt [82470,82702]
===
match
---
expr_stmt [9605,9659]
expr_stmt [9633,9687]
===
match
---
name: lock_for_update [21792,21807]
name: lock_for_update [21812,21827]
===
match
---
name: self [32727,32731]
name: self [32747,32751]
===
match
---
trailer [5289,5296]
trailer [5317,5324]
===
match
---
name: self [54816,54820]
name: self [54836,54840]
===
match
---
number: 1 [50674,50675]
number: 1 [50694,50695]
===
match
---
operator: = [64540,64541]
operator: = [64560,64561]
===
match
---
expr_stmt [14892,14903]
expr_stmt [14912,14923]
===
match
---
name: hasattr [47402,47409]
name: hasattr [47422,47429]
===
match
---
name: base_url [19568,19576]
name: base_url [19588,19596]
===
match
---
simple_stmt [60527,60572]
simple_stmt [60547,60592]
===
match
---
atom_expr [72853,72866]
atom_expr [72873,72886]
===
match
---
operator: = [50787,50788]
operator: = [50807,50808]
===
match
---
simple_stmt [41322,41390]
simple_stmt [41342,41410]
===
match
---
name: prev_ds [61819,61826]
name: prev_ds [61839,61846]
===
match
---
name: macros [60005,60011]
name: macros [60025,60031]
===
match
---
name: commit [47712,47718]
name: commit [47732,47738]
===
match
---
name: error [56128,56133]
name: error [56148,56153]
===
match
---
suite [79645,82380]
suite [79665,82400]
===
match
---
name: DepContext [38200,38210]
name: DepContext [38220,38230]
===
match
---
subscriptlist [52384,52398]
subscriptlist [52404,52418]
===
match
---
atom_expr [26818,26831]
atom_expr [26838,26851]
===
match
---
argument [54155,54180]
argument [54175,54200]
===
match
---
trailer [34781,34815]
trailer [34801,34835]
===
match
---
trailer [45270,45277]
trailer [45290,45297]
===
match
---
string: 'schedule_after_task_execution' [45865,45896]
string: 'schedule_after_task_execution' [45885,45916]
===
match
---
operator: } [14769,14770]
operator: } [14789,14790]
===
match
---
operator: = [74685,74686]
operator: = [74705,74706]
===
match
---
atom_expr [62481,62507]
atom_expr [62501,62527]
===
match
---
name: self [45466,45470]
name: self [45486,45490]
===
match
---
operator: = [77135,77136]
operator: = [77155,77156]
===
match
---
trailer [58487,58494]
trailer [58507,58514]
===
match
---
name: next_execution_date [61642,61661]
name: next_execution_date [61662,61681]
===
match
---
name: self [77706,77710]
name: self [77726,77730]
===
match
---
trailer [49018,49037]
trailer [49038,49057]
===
match
---
argument [71709,71733]
argument [71729,71753]
===
match
---
trailer [74187,74191]
trailer [74207,74211]
===
match
---
name: self [26473,26477]
name: self [26493,26497]
===
match
---
operator: , [79611,79612]
operator: , [79631,79632]
===
match
---
simple_stmt [59318,59412]
simple_stmt [59338,59432]
===
match
---
return_stmt [30876,30932]
return_stmt [30896,30952]
===
match
---
name: dag_id [23955,23961]
name: dag_id [23975,23981]
===
match
---
name: state [20605,20610]
name: state [20625,20630]
===
match
---
if_stmt [43481,43525]
if_stmt [43501,43545]
===
match
---
argument [62630,62643]
argument [62650,62663]
===
match
---
name: field_name [66500,66510]
name: field_name [66520,66530]
===
match
---
name: self [40382,40386]
name: self [40402,40406]
===
match
---
operator: = [61986,61987]
operator: = [62006,62007]
===
match
---
atom_expr [11794,11816]
atom_expr [11822,11844]
===
match
---
name: pool [16012,16016]
name: pool [16032,16036]
===
match
---
simple_stmt [18959,18997]
simple_stmt [18979,19017]
===
match
---
arglist [22873,22906]
arglist [22893,22926]
===
match
---
if_stmt [50193,50358]
if_stmt [50213,50378]
===
match
---
name: task_id [43828,43835]
name: task_id [43848,43855]
===
match
---
operator: = [71458,71459]
operator: = [71478,71479]
===
match
---
trailer [80264,80277]
trailer [80284,80297]
===
match
---
funcdef [63182,63239]
funcdef [63202,63259]
===
match
---
operator: } [33070,33071]
operator: } [33090,33091]
===
match
---
operator: = [62652,62653]
operator: = [62672,62673]
===
match
---
trailer [11231,11239]
trailer [11259,11267]
===
match
---
trailer [40051,40317]
trailer [40071,40337]
===
match
---
operator: , [40221,40222]
operator: , [40241,40242]
===
match
---
expr_stmt [5505,5532]
expr_stmt [5533,5560]
===
match
---
operator: = [68390,68391]
operator: = [68410,68411]
===
match
---
arglist [28815,29025]
arglist [28835,29045]
===
match
---
name: exec2 [58994,58999]
name: exec2 [59014,59019]
===
match
---
operator: = [21885,21886]
operator: = [21905,21906]
===
match
---
atom_expr [56869,56878]
atom_expr [56889,56898]
===
match
---
name: exception [69201,69210]
name: exception [69221,69230]
===
match
---
parameters [29150,29241]
parameters [29170,29261]
===
match
---
trailer [50628,50679]
trailer [50648,50699]
===
match
---
atom_expr [9470,9528]
atom_expr [9498,9556]
===
match
---
atom_expr [26273,26327]
atom_expr [26293,26347]
===
match
---
decorator [55099,55116]
decorator [55119,55136]
===
match
---
name: KubeConfig [2976,2986]
name: KubeConfig [3004,3014]
===
match
---
operator: = [9932,9933]
operator: = [9960,9961]
===
match
---
trailer [79988,79998]
trailer [80008,80018]
===
match
---
param [51154,51162]
param [51174,51182]
===
match
---
name: e [66766,66767]
name: e [66786,66787]
===
match
---
name: self [49052,49056]
name: self [49072,49076]
===
match
---
trailer [59082,59084]
trailer [59102,59104]
===
match
---
atom_expr [60781,60793]
atom_expr [60801,60813]
===
match
---
string: 'inlets' [64822,64830]
string: 'inlets' [64842,64850]
===
match
---
name: try_number [40642,40652]
name: try_number [40662,40672]
===
match
---
name: self [46642,46646]
name: self [46662,46666]
===
match
---
operator: } [60067,60068]
operator: } [60087,60088]
===
match
---
operator: -> [72803,72805]
operator: -> [72823,72825]
===
match
---
argument [59351,59370]
argument [59371,59390]
===
match
---
argument [50161,50174]
argument [50181,50194]
===
match
---
except_clause [51554,51579]
except_clause [51574,51599]
===
match
---
operator: , [46255,46256]
operator: , [46275,46276]
===
match
---
arglist [37536,37560]
arglist [37556,37580]
===
match
---
simple_stmt [70537,70566]
simple_stmt [70557,70586]
===
match
---
name: first [39220,39225]
name: first [39240,39245]
===
match
---
trailer [20367,20375]
trailer [20387,20395]
===
match
---
argument [38612,38624]
argument [38632,38644]
===
match
---
atom_expr [3714,3896]
atom_expr [3742,3924]
===
match
---
trailer [45607,45614]
trailer [45627,45634]
===
match
---
string: 'prev_ds' [65088,65097]
string: 'prev_ds' [65108,65117]
===
match
---
name: timezone [24673,24681]
name: timezone [24693,24701]
===
match
---
atom_expr [26355,26363]
atom_expr [26375,26383]
===
match
---
if_stmt [21789,21899]
if_stmt [21809,21919]
===
match
---
operator: , [76535,76536]
operator: , [76555,76556]
===
match
---
simple_stmt [1275,1365]
simple_stmt [1260,1350]
===
match
---
decorated [81142,81205]
decorated [81162,81225]
===
match
---
trailer [23995,24003]
trailer [24015,24023]
===
match
---
name: utcnow [40410,40416]
name: utcnow [40430,40436]
===
match
---
name: set_current_context [50407,50426]
name: set_current_context [50427,50446]
===
match
---
name: cmd [18864,18867]
name: cmd [18884,18887]
===
match
---
trailer [57214,57225]
trailer [57234,57245]
===
match
---
name: params [65068,65074]
name: params [65088,65094]
===
match
---
name: context [49901,49908]
name: context [49921,49928]
===
match
---
operator: = [41873,41874]
operator: = [41893,41894]
===
match
---
simple_stmt [19478,19507]
simple_stmt [19498,19527]
===
match
---
not_test [59013,59026]
not_test [59033,59046]
===
match
---
name: State [5183,5188]
name: State [5211,5216]
===
match
---
simple_stmt [2252,2303]
simple_stmt [2237,2288]
===
match
---
expr_stmt [82402,82449]
expr_stmt [82422,82469]
===
match
---
string: 'ts' [65835,65839]
string: 'ts' [65855,65859]
===
match
---
expr_stmt [7601,7846]
expr_stmt [7629,7874]
===
match
---
return_stmt [20598,20610]
return_stmt [20618,20630]
===
match
---
arglist [49273,49395]
arglist [49293,49415]
===
match
---
name: ts [62221,62223]
name: ts [62241,62243]
===
match
---
name: Column [10284,10290]
name: Column [10312,10318]
===
match
---
string: """         Get the very latest state from the database, if a session is passed,         we use and looking up the state becomes part of the session, otherwise         a new session is used.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [19929,20210]
string: """         Get the very latest state from the database, if a session is passed,         we use and looking up the state becomes part of the session, otherwise         a new session is used.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [19949,20230]
===
match
---
name: full_filepath [14814,14827]
name: full_filepath [14834,14847]
===
match
---
trailer [20330,20337]
trailer [20350,20357]
===
match
---
name: set_duration [55374,55386]
name: set_duration [55394,55406]
===
match
---
name: error [58910,58915]
name: error [58930,58935]
===
match
---
string: 'start_date' [45388,45400]
string: 'start_date' [45408,45420]
===
match
---
simple_stmt [63153,63169]
simple_stmt [63173,63189]
===
match
---
name: self [80612,80616]
name: self [80632,80636]
===
match
---
atom_expr [68794,68814]
atom_expr [68814,68834]
===
match
---
trailer [61937,61946]
trailer [61957,61966]
===
match
---
name: datetime [8175,8183]
name: datetime [8203,8211]
===
match
---
param [59491,59495]
param [59511,59515]
===
match
---
simple_stmt [37955,38003]
simple_stmt [37975,38023]
===
match
---
operator: , [53752,53753]
operator: , [53772,53773]
===
match
---
operator: , [32705,32706]
operator: , [32725,32726]
===
match
---
decorator [53371,53388]
decorator [53391,53408]
===
match
---
name: self [37495,37499]
name: self [37515,37519]
===
match
---
simple_stmt [50945,50965]
simple_stmt [50965,50985]
===
match
---
name: ignore_ti_state [53616,53631]
name: ignore_ti_state [53636,53651]
===
match
---
operator: , [50159,50160]
operator: , [50179,50180]
===
match
---
operator: , [41730,41731]
operator: , [41750,41751]
===
match
---
expr [32502,32535]
expr [32522,32555]
===
match
---
fstring_expr [19091,19100]
fstring_expr [19111,19120]
===
match
---
name: dag [11804,11807]
name: dag [11832,11835]
===
match
---
operator: , [3881,3882]
operator: , [3909,3910]
===
match
---
name: jinja_env [71246,71255]
name: jinja_env [71266,71275]
===
match
---
name: Column [9898,9904]
name: Column [9926,9932]
===
match
---
simple_stmt [26003,26015]
simple_stmt [26023,26035]
===
match
---
trailer [55761,55779]
trailer [55781,55799]
===
match
---
name: strftime [61938,61946]
name: strftime [61958,61966]
===
match
---
expr_stmt [69734,70101]
expr_stmt [69754,70121]
===
match
---
param [8342,8346]
param [8370,8374]
===
match
---
trailer [8738,8798]
trailer [8766,8826]
===
match
---
name: or_ [6689,6692]
name: or_ [6717,6720]
===
match
---
name: self [13978,13982]
name: self [13998,14002]
===
match
---
operator: = [15420,15421]
operator: = [15440,15441]
===
match
---
trailer [49894,49909]
trailer [49914,49929]
===
match
---
operator: , [29164,29165]
operator: , [29184,29185]
===
match
---
suite [38639,38702]
suite [38659,38722]
===
match
---
return_stmt [18857,18867]
return_stmt [18877,18887]
===
match
---
name: total_seconds [33679,33692]
name: total_seconds [33699,33712]
===
match
---
name: ti [21994,21996]
name: ti [22014,22016]
===
match
---
trailer [69125,69130]
trailer [69145,69150]
===
match
---
arglist [60416,60474]
arglist [60436,60494]
===
match
---
name: first [82354,82359]
name: first [82374,82379]
===
match
---
trailer [11708,11713]
trailer [11736,11741]
===
match
---
name: property [80734,80742]
name: property [80754,80762]
===
match
---
expr_stmt [7198,7250]
expr_stmt [7226,7278]
===
match
---
operator: = [4766,4767]
operator: = [4794,4795]
===
match
---
operator: , [7724,7725]
operator: , [7752,7753]
===
match
---
operator: , [9490,9491]
operator: , [9518,9519]
===
match
---
atom_expr [23975,23987]
atom_expr [23995,24007]
===
match
---
simple_stmt [44269,44292]
simple_stmt [44289,44312]
===
match
---
name: key [76528,76531]
name: key [76548,76551]
===
match
---
name: task_copy [48327,48336]
name: task_copy [48347,48356]
===
match
---
name: end_date [24941,24949]
name: end_date [24961,24969]
===
match
---
argument [46300,46315]
argument [46320,46335]
===
match
---
name: ti [22391,22393]
name: ti [22411,22413]
===
match
---
name: NamedTuple [1083,1093]
name: NamedTuple [1068,1078]
===
match
---
argument [54540,54553]
argument [54560,54573]
===
match
---
name: TaskInstance [81636,81648]
name: TaskInstance [81656,81668]
===
match
---
name: String [9941,9947]
name: String [9969,9975]
===
match
---
name: property [81381,81389]
name: property [81401,81409]
===
match
---
name: task [72647,72651]
name: task [72667,72671]
===
match
---
param [54874,54878]
param [54894,54898]
===
match
---
operator: = [80053,80054]
operator: = [80073,80074]
===
match
---
fstring_expr [49343,49346]
fstring_expr [49363,49366]
===
match
---
trailer [26221,26236]
trailer [26241,26256]
===
match
---
simple_stmt [37673,37694]
simple_stmt [37693,37714]
===
match
---
atom_expr [64174,64187]
atom_expr [64194,64207]
===
match
---
atom_expr [21976,21991]
atom_expr [21996,22011]
===
match
---
name: self [40965,40969]
name: self [40985,40989]
===
match
---
trailer [47718,47720]
trailer [47738,47740]
===
match
---
name: TaskInstance [77630,77642]
name: TaskInstance [77650,77662]
===
match
---
name: max_tries [9855,9864]
name: max_tries [9883,9892]
===
match
---
simple_stmt [73979,74174]
simple_stmt [73999,74194]
===
match
---
name: int [8115,8118]
name: int [8143,8146]
===
match
---
simple_stmt [28268,28516]
simple_stmt [28288,28536]
===
match
---
name: str [52384,52387]
name: str [52404,52407]
===
match
---
name: orm [1480,1483]
name: orm [1465,1468]
===
match
---
expr_stmt [55743,55779]
expr_stmt [55763,55799]
===
match
---
string: 'prev_execution_date' [65166,65187]
string: 'prev_execution_date' [65186,65207]
===
match
---
suite [77862,77954]
suite [77882,77974]
===
match
---
simple_stmt [835,850]
simple_stmt [820,835]
===
match
---
operator: , [56274,56275]
operator: , [56294,56295]
===
match
---
name: task_id [68504,68511]
name: task_id [68524,68531]
===
match
---
name: task_retries [5505,5517]
name: task_retries [5533,5545]
===
match
---
operator: = [76451,76452]
operator: = [76471,76472]
===
match
---
trailer [41260,41265]
trailer [41280,41285]
===
match
---
arglist [49038,49063]
arglist [49058,49083]
===
match
---
name: RenderedTaskInstanceFields [48992,49018]
name: RenderedTaskInstanceFields [49012,49038]
===
match
---
name: os [19015,19017]
name: os [19035,19037]
===
match
---
operator: = [66386,66387]
operator: = [66406,66407]
===
match
---
name: self [64788,64792]
name: self [64808,64812]
===
match
---
name: TaskInstance [21586,21598]
name: TaskInstance [21606,21618]
===
match
---
trailer [29514,29520]
trailer [29534,29540]
===
match
---
trailer [12444,12454]
trailer [12464,12474]
===
match
---
fstring_expr [19101,19114]
fstring_expr [19121,19134]
===
match
---
name: in_ [7415,7418]
name: in_ [7443,7446]
===
match
---
operator: == [20376,20378]
operator: == [20396,20398]
===
match
---
operator: , [44183,44184]
operator: , [44203,44204]
===
match
---
operator: , [29201,29202]
operator: , [29221,29222]
===
match
---
name: params [62637,62643]
name: params [62657,62663]
===
match
---
name: deserialize_json [64063,64079]
name: deserialize_json [64083,64099]
===
match
---
sync_comp_for [7042,7089]
sync_comp_for [7070,7117]
===
match
---
atom_expr [25965,25989]
atom_expr [25985,26009]
===
match
---
name: log [3251,3254]
name: log [3279,3282]
===
match
---
atom_expr [50462,50500]
atom_expr [50482,50520]
===
match
---
argument [72106,72121]
argument [72126,72141]
===
match
---
except_clause [67536,67588]
except_clause [67556,67608]
===
match
---
operator: , [79321,79322]
operator: , [79341,79342]
===
match
---
expr_stmt [10035,10090]
expr_stmt [10063,10118]
===
match
---
operator: , [18765,18766]
operator: , [18785,18786]
===
match
---
operator: = [4055,4056]
operator: = [4083,4084]
===
match
---
trailer [39112,39130]
trailer [39132,39150]
===
match
---
name: Union [52378,52383]
name: Union [52398,52403]
===
match
---
name: _run_mini_scheduler_on_child_tasks [45761,45795]
name: _run_mini_scheduler_on_child_tasks [45781,45815]
===
match
---
expr_stmt [8103,8118]
expr_stmt [8131,8146]
===
match
---
simple_stmt [11526,11689]
simple_stmt [11554,11717]
===
match
---
name: BooleanClauseList [78063,78080]
name: BooleanClauseList [78083,78100]
===
match
---
operator: = [67495,67496]
operator: = [67515,67516]
===
match
---
testlist_comp [77138,77182]
testlist_comp [77158,77202]
===
match
---
decorated [74415,77370]
decorated [74435,77390]
===
match
---
operator: = [5342,5343]
operator: = [5370,5371]
===
match
---
simple_stmt [30456,30604]
simple_stmt [30476,30624]
===
match
---
operator: + [34845,34846]
operator: + [34865,34866]
===
match
---
atom_expr [19102,19113]
atom_expr [19122,19133]
===
match
---
trailer [29055,29071]
trailer [29075,29091]
===
match
---
decorator [28075,28085]
decorator [28095,28105]
===
match
---
operator: , [40298,40299]
operator: , [40318,40319]
===
match
---
name: self [22831,22835]
name: self [22851,22855]
===
match
---
atom_expr [20539,20550]
atom_expr [20559,20570]
===
match
---
argument [68829,68861]
argument [68849,68881]
===
match
---
trailer [62166,62175]
trailer [62186,62195]
===
match
---
name: are_dependencies_met [38516,38536]
name: are_dependencies_met [38536,38556]
===
match
---
trailer [80341,80358]
trailer [80361,80378]
===
match
---
name: error [59167,59172]
name: error [59187,59192]
===
match
---
name: first_task_id [78414,78427]
name: first_task_id [78434,78447]
===
match
---
name: task_copy [51787,51796]
name: task_copy [51807,51816]
===
match
---
operator: @ [74415,74416]
operator: @ [74435,74436]
===
match
---
sync_comp_for [49352,49392]
sync_comp_for [49372,49412]
===
match
---
operator: , [54622,54623]
operator: , [54642,54643]
===
match
---
name: task [42704,42708]
name: task [42724,42728]
===
match
---
trailer [45119,45123]
trailer [45139,45143]
===
match
---
atom_expr [55074,55093]
atom_expr [55094,55113]
===
match
---
trailer [3717,3725]
trailer [3745,3753]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28120,28259]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28140,28279]
===
match
---
atom_expr [50688,50714]
atom_expr [50708,50734]
===
match
---
atom [18135,18163]
atom [18155,18183]
===
match
---
name: dag_id [78951,78957]
name: dag_id [78971,78977]
===
match
---
name: raw [14290,14293]
name: raw [14310,14313]
===
match
---
operator: , [14339,14340]
operator: , [14359,14360]
===
match
---
atom_expr [61221,61245]
atom_expr [61241,61265]
===
match
---
name: raw [15372,15375]
name: raw [15392,15395]
===
match
---
operator: = [35175,35176]
operator: = [35195,35196]
===
match
---
except_clause [58826,58851]
except_clause [58846,58871]
===
match
---
operator: , [72397,72398]
operator: , [72417,72418]
===
match
---
simple_stmt [47016,47209]
simple_stmt [47036,47229]
===
match
---
atom_expr [10258,10273]
atom_expr [10286,10301]
===
match
---
simple_stmt [52830,52864]
simple_stmt [52850,52884]
===
match
---
name: downstream_task_ids [26397,26416]
name: downstream_task_ids [26417,26436]
===
match
---
trailer [10151,10160]
trailer [10179,10188]
===
match
---
fstring [47912,47975]
fstring [47932,47995]
===
match
---
name: yesterday_ds [60743,60755]
name: yesterday_ds [60763,60775]
===
match
---
trailer [82292,82308]
trailer [82312,82328]
===
match
---
name: execution_date [60764,60778]
name: execution_date [60784,60798]
===
match
---
trailer [82595,82603]
trailer [82615,82623]
===
match
---
name: error_file [4269,4279]
name: error_file [4297,4307]
===
match
---
name: ignore_ti_state [38347,38362]
name: ignore_ti_state [38367,38382]
===
match
---
name: math [33663,33667]
name: math [33683,33687]
===
match
---
operator: = [30854,30855]
operator: = [30874,30875]
===
match
---
funcdef [71834,72123]
funcdef [71854,72143]
===
match
---
atom_expr [26240,26259]
atom_expr [26260,26279]
===
match
---
expr_stmt [46898,46923]
expr_stmt [46918,46943]
===
match
---
name: first [21891,21896]
name: first [21911,21916]
===
match
---
name: _run_as_user [80265,80277]
name: _run_as_user [80285,80297]
===
match
---
name: e [43298,43299]
name: e [43318,43319]
===
match
---
name: query [77573,77578]
name: query [77593,77598]
===
match
---
name: _start_date [80894,80905]
name: _start_date [80914,80925]
===
match
---
operator: = [47479,47480]
operator: = [47499,47500]
===
match
---
suite [63616,64577]
suite [63636,64597]
===
match
---
trailer [65463,65487]
trailer [65483,65507]
===
match
---
operator: = [37716,37717]
operator: = [37736,37737]
===
match
---
name: executor_config [23548,23563]
name: executor_config [23568,23583]
===
match
---
simple_stmt [43196,43223]
simple_stmt [43216,43243]
===
match
---
trailer [52082,52102]
trailer [52102,52122]
===
match
---
atom_expr [29254,29271]
atom_expr [29274,29291]
===
match
---
atom_expr [78054,78081]
atom_expr [78074,78101]
===
match
---
operator: = [49223,49224]
operator: = [49243,49244]
===
match
---
name: self [80855,80859]
name: self [80875,80879]
===
match
---
name: session [32380,32387]
name: session [32400,32407]
===
match
---
name: start_date [30306,30316]
name: start_date [30326,30336]
===
match
---
name: dep_context [32603,32614]
name: dep_context [32623,32634]
===
match
---
name: self [73021,73025]
name: self [73041,73045]
===
match
---
name: variable [2046,2054]
name: variable [2031,2039]
===
match
---
operator: , [2118,2119]
operator: , [2103,2104]
===
match
---
lambdef [5114,5138]
lambdef [5142,5166]
===
match
---
if_stmt [27707,27936]
if_stmt [27727,27956]
===
match
---
operator: , [9581,9582]
operator: , [9609,9610]
===
match
---
atom [47244,47319]
atom [47264,47339]
===
match
---
funcdef [8330,8571]
funcdef [8358,8599]
===
match
---
simple_stmt [19226,19271]
simple_stmt [19246,19291]
===
match
---
name: debug [22867,22872]
name: debug [22887,22892]
===
match
---
trailer [7213,7223]
trailer [7241,7251]
===
match
---
atom_expr [14810,14827]
atom_expr [14830,14847]
===
match
---
simple_stmt [43284,43301]
simple_stmt [43304,43321]
===
match
---
name: test_mode [56405,56414]
name: test_mode [56425,56434]
===
match
---
simple_stmt [19005,19074]
simple_stmt [19025,19094]
===
match
---
fstring_string: ti.start. [42912,42921]
fstring_string: ti.start. [42932,42941]
===
match
---
name: self [53105,53109]
name: self [53125,53129]
===
match
---
name: models [67273,67279]
name: models [67293,67299]
===
match
---
trailer [77294,77296]
trailer [77314,77316]
===
match
---
atom_expr [66585,66631]
atom_expr [66605,66651]
===
match
---
operator: , [15293,15294]
operator: , [15313,15314]
===
match
---
parameters [67771,67794]
parameters [67791,67814]
===
match
---
expr_stmt [10555,10876]
expr_stmt [10583,10904]
===
match
---
decorated [35116,35599]
decorated [35136,35619]
===
match
---
trailer [71354,71366]
trailer [71374,71386]
===
match
---
atom_expr [78669,78685]
atom_expr [78689,78705]
===
match
---
string: "%d downstream tasks scheduled from follow-on schedule check" [47619,47680]
string: "%d downstream tasks scheduled from follow-on schedule check" [47639,47700]
===
match
---
atom_expr [8739,8750]
atom_expr [8767,8778]
===
match
---
param [56166,56199]
param [56186,56219]
===
match
---
operator: { [19101,19102]
operator: { [19121,19122]
===
match
---
atom_expr [10787,10833]
atom_expr [10815,10861]
===
match
---
name: max_retry_delay [34737,34752]
name: max_retry_delay [34757,34772]
===
match
---
tfpdef [53491,53512]
tfpdef [53511,53532]
===
match
---
string: 'webserver' [19299,19310]
string: 'webserver' [19319,19330]
===
match
---
operator: , [10655,10656]
operator: , [10683,10684]
===
match
---
operator: = [47242,47243]
operator: = [47262,47263]
===
match
---
atom_expr [66679,66702]
atom_expr [66699,66722]
===
match
---
operator: @ [32307,32308]
operator: @ [32327,32328]
===
match
---
trailer [56962,56967]
trailer [56982,56987]
===
match
---
operator: -> [56304,56306]
operator: -> [56324,56326]
===
match
---
name: self [14963,14967]
name: self [14983,14987]
===
match
---
name: previous_start_date_success [30382,30409]
name: previous_start_date_success [30402,30429]
===
match
---
operator: = [42871,42872]
operator: = [42891,42892]
===
match
---
name: dep_context [2273,2284]
name: dep_context [2258,2269]
===
match
---
name: self [80169,80173]
name: self [80189,80193]
===
match
---
name: error_file [56242,56252]
name: error_file [56262,56272]
===
match
---
param [24176,24180]
param [24196,24200]
===
match
---
string: """Returns a tuple that identifies the task instance uniquely""" [24210,24274]
string: """Returns a tuple that identifies the task instance uniquely""" [24230,24294]
===
match
---
atom_expr [80113,80134]
atom_expr [80133,80154]
===
match
---
string: """         Make an XCom available for tasks to pull.          :param key: A key for the XCom         :type key: str         :param value: A value for the XCom. The value is pickled and stored             in the database.         :type value: any picklable object         :param execution_date: if provided, the XCom will not be visible until             this date. This can be used, for example, to send a message to a             task on a future date without it being immediately visible.         :type execution_date: datetime         :param session: Sqlalchemy ORM Session         :type session: Session         """ [73278,73898]
string: """         Make an XCom available for tasks to pull.          :param key: A key for the XCom         :type key: str         :param value: A value for the XCom. The value is pickled and stored             in the database.         :type value: any picklable object         :param execution_date: if provided, the XCom will not be visible until             this date. This can be used, for example, to send a message to a             task on a future date without it being immediately visible.         :type execution_date: datetime         :param session: Sqlalchemy ORM Session         :type session: Session         """ [73298,73918]
===
match
---
atom_expr [8766,8785]
atom_expr [8794,8813]
===
match
---
name: exception_html [70838,70852]
name: exception_html [70858,70872]
===
match
---
trailer [65499,65507]
trailer [65519,65527]
===
match
---
simple_stmt [51665,51709]
simple_stmt [51685,51729]
===
match
---
operator: = [59360,59361]
operator: = [59380,59381]
===
match
---
name: session [31008,31015]
name: session [31028,31035]
===
match
---
name: task [26392,26396]
name: task [26412,26416]
===
match
---
name: dag_id [11212,11218]
name: dag_id [11240,11246]
===
match
---
name: ignore_task_deps [15148,15164]
name: ignore_task_deps [15168,15184]
===
match
---
expr_stmt [5919,5976]
expr_stmt [5947,6004]
===
match
---
name: property [80993,81001]
name: property [81013,81021]
===
match
---
suite [18510,18547]
suite [18530,18567]
===
match
---
trailer [18151,18162]
trailer [18171,18182]
===
match
---
expr_stmt [68193,68230]
expr_stmt [68213,68250]
===
match
---
atom_expr [54787,54803]
atom_expr [54807,54823]
===
match
---
parameters [32355,32393]
parameters [32375,32413]
===
match
---
simple_stmt [27090,27159]
simple_stmt [27110,27179]
===
match
---
trailer [58979,58983]
trailer [58999,59003]
===
match
---
name: dag_id [76415,76421]
name: dag_id [76435,76441]
===
match
---
comparison [21668,21704]
comparison [21688,21724]
===
match
---
atom_expr [22374,22388]
atom_expr [22394,22408]
===
match
---
name: test_mode [44327,44336]
name: test_mode [44347,44356]
===
match
---
argument [26881,26896]
argument [26901,26916]
===
match
---
atom_expr [67497,67523]
atom_expr [67517,67543]
===
match
---
atom_expr [30918,30931]
atom_expr [30938,30951]
===
match
---
trailer [80227,80246]
trailer [80247,80266]
===
match
---
trailer [49699,49701]
trailer [49719,49721]
===
match
---
name: downstream_task_ids [25970,25989]
name: downstream_task_ids [25990,26009]
===
match
---
decorator [13238,13257]
decorator [13258,13277]
===
match
---
name: airflow [1833,1840]
name: airflow [1818,1825]
===
match
---
name: filter [35466,35472]
name: filter [35486,35492]
===
match
---
name: provide_session [2706,2721]
name: provide_session [2734,2749]
===
match
---
name: ti [80096,80098]
name: ti [80116,80118]
===
match
---
trailer [49867,49894]
trailer [49887,49914]
===
match
---
name: priority_weight [10127,10142]
name: priority_weight [10155,10170]
===
match
---
name: is_localized [11484,11496]
name: is_localized [11512,11524]
===
match
---
operator: , [53945,53946]
operator: , [53965,53966]
===
match
---
param [63884,63888]
param [63904,63908]
===
match
---
try_stmt [51398,51639]
try_stmt [51418,51659]
===
match
---
name: state [45545,45550]
name: state [45565,45570]
===
match
---
operator: = [67358,67359]
operator: = [67378,67379]
===
match
---
name: self [61281,61285]
name: self [61301,61305]
===
match
---
operator: , [16038,16039]
operator: , [16058,16059]
===
match
---
operator: = [15349,15350]
operator: = [15369,15370]
===
match
---
trailer [29520,29558]
trailer [29540,29578]
===
match
---
name: bool [35938,35942]
name: bool [35958,35962]
===
match
---
name: context [51525,51532]
name: context [51545,51552]
===
match
---
simple_stmt [18059,18090]
simple_stmt [18079,18110]
===
match
---
string: 'execution_date' [43873,43889]
string: 'execution_date' [43893,43909]
===
match
---
trailer [50693,50698]
trailer [50713,50718]
===
match
---
operator: = [69428,69429]
operator: = [69448,69449]
===
match
---
expr_stmt [10360,10423]
expr_stmt [10388,10451]
===
match
---
atom_expr [22858,22907]
atom_expr [22878,22927]
===
match
---
operator: , [32731,32732]
operator: , [32751,32752]
===
match
---
name: deps [32531,32535]
name: deps [32551,32555]
===
match
---
name: with_entities [77047,77060]
name: with_entities [77067,77080]
===
match
---
operator: = [39797,39798]
operator: = [39817,39818]
===
match
---
expr_stmt [71780,71820]
expr_stmt [71800,71840]
===
match
---
trailer [22474,22483]
trailer [22494,22503]
===
match
---
operator: = [58089,58090]
operator: = [58109,58110]
===
match
---
string: "Refreshed TaskInstance %s" [22873,22900]
string: "Refreshed TaskInstance %s" [22893,22920]
===
match
---
expr_stmt [61695,61736]
expr_stmt [61715,61756]
===
match
---
param [53691,53715]
param [53711,53735]
===
match
---
tfpdef [29795,29811]
tfpdef [29815,29831]
===
match
---
trailer [7763,7767]
trailer [7791,7795]
===
match
---
if_stmt [62517,62662]
if_stmt [62537,62682]
===
match
---
atom_expr [10716,10777]
atom_expr [10744,10805]
===
match
---
name: self [50803,50807]
name: self [50823,50827]
===
match
---
operator: , [18006,18007]
operator: , [18026,18027]
===
match
---
name: dag_id [79068,79074]
name: dag_id [79088,79094]
===
match
---
name: ti [5462,5464]
name: ti [5490,5492]
===
match
---
atom_expr [33897,33908]
atom_expr [33917,33928]
===
match
---
comparison [79289,79321]
comparison [79309,79341]
===
match
---
atom_expr [56466,56494]
atom_expr [56486,56514]
===
match
---
name: primary_key [9642,9653]
name: primary_key [9670,9681]
===
match
---
param [56284,56297]
param [56304,56317]
===
match
---
name: partial_subset [46656,46670]
name: partial_subset [46676,46690]
===
match
---
name: dep_context [39538,39549]
name: dep_context [39558,39569]
===
match
---
except_clause [44014,44071]
except_clause [44034,44091]
===
match
---
if_stmt [76384,76436]
if_stmt [76404,76456]
===
match
---
name: default_var [64541,64552]
name: default_var [64561,64572]
===
match
---
name: join [49335,49339]
name: join [49355,49359]
===
match
---
operator: , [23653,23654]
operator: , [23673,23674]
===
match
---
operator: = [56867,56868]
operator: = [56887,56888]
===
match
---
trailer [64778,64787]
trailer [64798,64807]
===
match
---
expr_stmt [22060,22087]
expr_stmt [22080,22107]
===
match
---
name: dep_name [32111,32119]
name: dep_name [32131,32139]
===
match
---
operator: == [20437,20439]
operator: == [20457,20459]
===
match
---
expr_stmt [19005,19073]
expr_stmt [19025,19093]
===
match
---
operator: , [43121,43122]
operator: , [43141,43142]
===
match
---
name: ti_deps [2316,2323]
name: ti_deps [2301,2308]
===
match
---
suite [55221,56060]
suite [55241,56080]
===
match
---
arglist [4385,4401]
arglist [4413,4429]
===
match
---
argument [37542,37560]
argument [37562,37580]
===
match
---
name: str [63071,63074]
name: str [63091,63094]
===
match
---
simple_stmt [32290,32302]
simple_stmt [32310,32322]
===
match
---
suite [20564,20590]
suite [20584,20610]
===
match
---
name: incr [44975,44979]
name: incr [44995,44999]
===
match
---
string: '%Y-%m-%d' [60804,60814]
string: '%Y-%m-%d' [60824,60834]
===
match
---
simple_stmt [61566,61588]
simple_stmt [61586,61608]
===
match
---
name: property [19429,19437]
name: property [19449,19457]
===
match
---
trailer [62487,62494]
trailer [62507,62514]
===
match
---
name: partial_dag [47102,47113]
name: partial_dag [47122,47133]
===
match
---
arglist [10055,10089]
arglist [10083,10117]
===
match
---
operator: = [36074,36075]
operator: = [36094,36095]
===
match
---
arglist [37845,37873]
arglist [37865,37893]
===
match
---
string: 'prev_ds_nodash' [65120,65136]
string: 'prev_ds_nodash' [65140,65156]
===
match
---
atom_expr [12030,12045]
atom_expr [12058,12073]
===
match
---
name: self [81021,81025]
name: self [81041,81045]
===
match
---
name: session [74391,74398]
name: session [74411,74418]
===
match
---
param [56128,56157]
param [56148,56177]
===
match
---
atom_expr [48753,48820]
atom_expr [48773,48840]
===
match
---
trailer [26165,26169]
trailer [26185,26189]
===
match
---
suite [29273,29697]
suite [29293,29717]
===
match
---
name: error [20856,20861]
name: error [20876,20881]
===
match
---
name: job_id [35993,35999]
name: job_id [36013,36019]
===
match
---
name: conf [62520,62524]
name: conf [62540,62544]
===
match
---
funcdef [73104,74410]
funcdef [73124,74430]
===
match
---
trailer [74561,74566]
trailer [74581,74586]
===
match
---
name: self [32634,32638]
name: self [32654,32658]
===
match
---
name: ti [7713,7715]
name: ti [7741,7743]
===
match
---
simple_stmt [45524,45559]
simple_stmt [45544,45579]
===
match
---
name: dr [35412,35414]
name: dr [35432,35434]
===
match
---
atom_expr [22060,22073]
atom_expr [22080,22093]
===
match
---
fstring_end: " [19701,19702]
fstring_end: " [19721,19722]
===
match
---
operator: , [67566,67567]
operator: , [67586,67587]
===
match
---
name: TaskReschedule [3173,3187]
name: TaskReschedule [3201,3215]
===
match
---
name: Column [9773,9779]
name: Column [9801,9807]
===
match
---
trailer [62109,62117]
trailer [62129,62137]
===
match
---
name: _run_mini_scheduler_on_child_tasks [45661,45695]
name: _run_mini_scheduler_on_child_tasks [45681,45715]
===
match
---
trailer [80035,80047]
trailer [80055,80067]
===
match
---
trailer [72105,72122]
trailer [72125,72142]
===
match
---
name: default_html_content_err [71367,71391]
name: default_html_content_err [71387,71411]
===
match
---
name: task_reschedule [39148,39163]
name: task_reschedule [39168,39183]
===
match
---
operator: , [62370,62371]
operator: , [62390,62391]
===
match
---
operator: , [8785,8786]
operator: , [8813,8814]
===
match
---
name: Optional [56254,56262]
name: Optional [56274,56282]
===
match
---
name: try_number [70874,70884]
name: try_number [70894,70904]
===
match
---
argument [70782,70801]
argument [70802,70821]
===
match
---
atom_expr [62401,62412]
atom_expr [62421,62432]
===
match
---
atom_expr [39848,39929]
atom_expr [39868,39949]
===
match
---
simple_stmt [39987,40019]
simple_stmt [40007,40039]
===
match
---
name: error_file [44366,44376]
name: error_file [44386,44396]
===
match
---
name: self [40280,40284]
name: self [40300,40304]
===
match
---
for_stmt [47336,47528]
for_stmt [47356,47548]
===
match
---
name: self [65609,65613]
name: self [65629,65633]
===
match
---
atom_expr [82129,82149]
atom_expr [82149,82169]
===
match
---
expr_stmt [53004,53041]
expr_stmt [53024,53061]
===
match
---
argument [43558,43578]
argument [43578,43598]
===
match
---
operator: , [15000,15001]
operator: , [15020,15021]
===
match
---
trailer [56185,56191]
trailer [56205,56211]
===
match
---
trailer [49037,49064]
trailer [49057,49084]
===
match
---
name: airflow [2225,2232]
name: airflow [2210,2217]
===
match
---
atom [18823,18847]
atom [18843,18867]
===
match
---
name: _try_number [13217,13228]
name: _try_number [13237,13248]
===
match
---
name: task_reschedule [39247,39262]
name: task_reschedule [39267,39282]
===
match
---
name: xcom [77364,77368]
name: xcom [77384,77388]
===
match
---
name: self [68716,68720]
name: self [68736,68740]
===
match
---
operator: = [14628,14629]
operator: = [14648,14649]
===
match
---
not_test [37745,37764]
not_test [37765,37784]
===
match
---
trailer [13216,13228]
trailer [13236,13248]
===
match
---
atom_expr [77257,77296]
atom_expr [77277,77316]
===
match
---
name: task_copy [55074,55083]
name: task_copy [55094,55103]
===
match
---
funcdef [19442,19849]
funcdef [19462,19869]
===
match
---
name: Exception [4473,4482]
name: Exception [4501,4510]
===
match
---
string: '' [62254,62256]
string: '' [62274,62276]
===
match
---
trailer [33012,33019]
trailer [33032,33039]
===
match
---
name: vals_kv [77138,77145]
name: vals_kv [77158,77165]
===
match
---
name: self [55552,55556]
name: self [55572,55576]
===
match
---
operator: == [21746,21748]
operator: == [21766,21768]
===
match
---
trailer [22719,22728]
trailer [22739,22748]
===
match
---
arglist [69442,69454]
arglist [69462,69474]
===
match
---
funcdef [81324,81375]
funcdef [81344,81395]
===
match
---
trailer [50905,50916]
trailer [50925,50936]
===
match
---
name: ignore_depends_on_past [14176,14198]
name: ignore_depends_on_past [14196,14218]
===
match
---
suite [63201,63239]
suite [63221,63259]
===
match
---
atom_expr [22076,22087]
atom_expr [22096,22107]
===
match
---
name: session [26889,26896]
name: session [26909,26916]
===
match
---
operator: == [26237,26239]
operator: == [26257,26259]
===
match
---
atom_expr [22510,22519]
atom_expr [22530,22539]
===
match
---
arglist [76480,76677]
arglist [76500,76697]
===
match
---
name: handle_failure [44870,44884]
name: handle_failure [44890,44904]
===
match
---
name: date_attr [59648,59657]
name: date_attr [59668,59677]
===
match
---
suite [19920,20611]
suite [19940,20631]
===
match
---
name: task [52677,52681]
name: task [52697,52701]
===
match
---
param [81021,81025]
param [81041,81045]
===
match
---
name: Variable [64044,64052]
name: Variable [64064,64072]
===
match
---
suite [16099,18868]
suite [16119,18888]
===
match
---
simple_stmt [43537,43580]
simple_stmt [43557,43600]
===
match
---
name: prev_ds [61908,61915]
name: prev_ds [61928,61935]
===
match
---
name: self [67772,67776]
name: self [67792,67796]
===
match
---
name: ti [22113,22115]
name: ti [22133,22135]
===
match
---
suite [72887,72966]
suite [72907,72986]
===
match
---
name: ti [80280,80282]
name: ti [80300,80302]
===
match
---
simple_stmt [30279,30359]
simple_stmt [30299,30379]
===
match
---
sync_comp_for [79151,79163]
sync_comp_for [79171,79183]
===
match
---
tfpdef [4269,4284]
tfpdef [4297,4312]
===
match
---
atom_expr [76964,76978]
atom_expr [76984,76998]
===
match
---
operator: , [54180,54181]
operator: , [54200,54201]
===
match
---
atom_expr [26209,26236]
atom_expr [26229,26256]
===
match
---
trailer [10906,11071]
trailer [10934,11099]
===
match
---
suite [52062,52154]
suite [52082,52174]
===
match
---
trailer [67902,67906]
trailer [67922,67926]
===
match
---
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [43706,43776]
string: 'dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [43726,43796]
===
match
---
atom_expr [32753,32772]
atom_expr [32773,32792]
===
match
---
simple_stmt [9923,9955]
simple_stmt [9951,9983]
===
match
---
trailer [59575,59583]
trailer [59595,59603]
===
match
---
name: ignore_depends_on_past [35799,35821]
name: ignore_depends_on_past [35819,35841]
===
match
---
atom_expr [80487,80498]
atom_expr [80507,80518]
===
match
---
name: task_copy [51674,51683]
name: task_copy [51694,51703]
===
match
---
name: exception [72595,72604]
name: exception [72615,72624]
===
match
---
name: Index [10682,10687]
name: Index [10710,10715]
===
match
---
operator: = [80533,80534]
operator: = [80553,80554]
===
match
---
atom_expr [18630,18658]
atom_expr [18650,18678]
===
match
---
trailer [45295,45303]
trailer [45315,45323]
===
match
---
name: run_id [60527,60533]
name: run_id [60547,60553]
===
match
---
name: unixname [12063,12071]
name: unixname [12091,12099]
===
match
---
name: context [52785,52792]
name: context [52805,52812]
===
match
---
operator: } [19134,19135]
operator: } [19154,19155]
===
match
---
operator: , [11792,11793]
operator: , [11820,11821]
===
match
---
trailer [25388,25390]
trailer [25408,25410]
===
match
---
operator: = [54026,54027]
operator: = [54046,54047]
===
match
---
atom_expr [45022,45032]
atom_expr [45042,45052]
===
match
---
name: session [30186,30193]
name: session [30206,30213]
===
match
---
trailer [60677,60689]
trailer [60697,60709]
===
match
---
fstring [42910,42950]
fstring [42930,42970]
===
match
---
name: State [26312,26317]
name: State [26332,26337]
===
match
---
name: TR [3168,3170]
name: TR [3196,3198]
===
match
---
argument [62645,62660]
argument [62665,62680]
===
match
---
arglist [70782,70951]
arglist [70802,70971]
===
match
---
simple_stmt [45073,45107]
simple_stmt [45093,45127]
===
match
---
name: pickle_id [18152,18161]
name: pickle_id [18172,18181]
===
match
---
tfpdef [3338,3354]
tfpdef [3366,3382]
===
match
---
name: self [22858,22862]
name: self [22878,22882]
===
match
---
operator: , [56614,56615]
operator: , [56634,56635]
===
match
---
argument [10075,10089]
argument [10103,10117]
===
match
---
trailer [24102,24104]
trailer [24122,24124]
===
match
---
arglist [61728,61735]
arglist [61748,61755]
===
match
---
trailer [55358,55360]
trailer [55378,55380]
===
match
---
name: rendered_task_instance_fields [66356,66385]
name: rendered_task_instance_fields [66376,66405]
===
match
---
name: State [40796,40801]
name: State [40816,40821]
===
match
---
trailer [65036,65044]
trailer [65056,65064]
===
match
---
trailer [76912,76922]
trailer [76932,76942]
===
match
---
strings [43662,43776]
strings [43682,43796]
===
match
---
trailer [26109,26116]
trailer [26129,26136]
===
match
---
simple_stmt [56887,56921]
simple_stmt [56907,56941]
===
match
---
trailer [68207,68228]
trailer [68227,68248]
===
match
---
simple_stmt [40471,40488]
simple_stmt [40491,40508]
===
match
---
argument [30912,30931]
argument [30932,30951]
===
match
---
operator: = [22111,22112]
operator: = [22131,22132]
===
match
---
name: execution_date [79910,79924]
name: execution_date [79930,79944]
===
match
---
return_stmt [77196,77223]
return_stmt [77216,77243]
===
match
---
name: task [27276,27280]
name: task [27296,27300]
===
match
---
name: conditions [7239,7249]
name: conditions [7267,7277]
===
match
---
argument [10064,10073]
argument [10092,10101]
===
match
---
operator: = [12004,12005]
operator: = [12032,12033]
===
match
---
atom_expr [79055,79074]
atom_expr [79075,79094]
===
match
---
suite [3615,3897]
suite [3643,3925]
===
match
---
operator: = [68596,68597]
operator: = [68616,68617]
===
match
---
name: ti [22510,22512]
name: ti [22530,22532]
===
match
---
name: test_mode [54503,54512]
name: test_mode [54523,54532]
===
match
---
trailer [28614,28630]
trailer [28634,28650]
===
match
---
operator: , [35501,35502]
operator: , [35521,35522]
===
match
---
expr_stmt [14735,14771]
expr_stmt [14755,14791]
===
match
---
name: task_ids [6942,6950]
name: task_ids [6970,6978]
===
match
---
argument [59395,59410]
argument [59415,59430]
===
match
---
trailer [47485,47490]
trailer [47505,47510]
===
match
---
name: verbose [53930,53937]
name: verbose [53950,53957]
===
match
---
trailer [39965,39970]
trailer [39985,39990]
===
match
---
tfpdef [16048,16071]
tfpdef [16068,16091]
===
match
---
atom_expr [77682,77702]
atom_expr [77702,77722]
===
match
---
operator: < [73944,73945]
operator: < [73964,73965]
===
match
---
operator: , [38610,38611]
operator: , [38630,38631]
===
match
---
name: ti [22306,22308]
name: ti [22326,22328]
===
match
---
name: task_id [79858,79865]
name: task_id [79878,79885]
===
match
---
expr_stmt [10304,10354]
expr_stmt [10332,10382]
===
match
---
and_test [61209,61245]
and_test [61229,61265]
===
match
---
name: session [6023,6030]
name: session [6051,6058]
===
match
---
name: TaskInstance [26273,26285]
name: TaskInstance [26293,26305]
===
match
---
name: self [49895,49899]
name: self [49915,49919]
===
match
---
operator: -> [26538,26540]
operator: -> [26558,26560]
===
match
---
string: """         The task instance for the task that ran before this task instance.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [26575,26803]
string: """         The task instance for the task that ran before this task instance.          :param state: If passed, it only take into account instances of a specific state.         :param session: SQLAlchemy ORM Session         """ [26595,26823]
===
match
---
name: self [25027,25031]
name: self [25047,25051]
===
match
---
simple_stmt [14841,14866]
simple_stmt [14861,14886]
===
match
---
operator: , [1318,1319]
operator: , [1303,1304]
===
match
---
atom_expr [21692,21704]
atom_expr [21712,21724]
===
match
---
tfpdef [15636,15654]
tfpdef [15656,15674]
===
match
---
suite [5223,5308]
suite [5251,5336]
===
match
---
param [26479,26507]
param [26499,26527]
===
match
---
param [59642,59647]
param [59662,59667]
===
match
---
trailer [24862,24868]
trailer [24882,24888]
===
match
---
trailer [72963,72965]
trailer [72983,72985]
===
match
---
atom_expr [25327,25337]
atom_expr [25347,25357]
===
match
---
trailer [61661,61670]
trailer [61681,61690]
===
match
---
name: Union [1112,1117]
name: Union [1097,1102]
===
match
---
import_name [862,871]
import_name [847,856]
===
match
---
name: Optional [16018,16026]
name: Optional [16038,16046]
===
match
---
simple_stmt [4653,4681]
simple_stmt [4681,4709]
===
match
---
operator: , [15592,15593]
operator: , [15612,15613]
===
match
---
name: run_as_user [23462,23473]
name: run_as_user [23482,23493]
===
match
---
operator: - [33720,33721]
operator: - [33740,33741]
===
match
---
name: job_ids [5048,5055]
name: job_ids [5076,5083]
===
match
---
name: TaskInstanceKey [78032,78047]
name: TaskInstanceKey [78052,78067]
===
match
---
if_stmt [41530,41593]
if_stmt [41550,41613]
===
match
---
operator: = [15316,15317]
operator: = [15336,15337]
===
match
---
name: dep_context [32441,32452]
name: dep_context [32461,32472]
===
match
---
operator: , [65044,65045]
operator: , [65064,65065]
===
match
---
name: state [12103,12108]
name: state [12123,12128]
===
match
---
strings [40073,40221]
strings [40093,40241]
===
match
---
operator: , [74725,74726]
operator: , [74745,74746]
===
match
---
trailer [60498,60500]
trailer [60518,60520]
===
match
---
atom_expr [7621,7836]
atom_expr [7649,7864]
===
match
---
argument [68459,68477]
argument [68479,68497]
===
match
---
decorator [19146,19156]
decorator [19166,19176]
===
match
---
name: on_failure_callback [52682,52701]
name: on_failure_callback [52702,52721]
===
match
---
name: task [11207,11211]
name: task [11235,11239]
===
match
---
operator: = [23354,23355]
operator: = [23374,23375]
===
match
---
name: net [2581,2584]
name: net [2566,2569]
===
match
---
name: max_tries [59612,59621]
name: max_tries [59632,59641]
===
match
---
name: SKIPPED [26303,26310]
name: SKIPPED [26323,26330]
===
match
---
decorated [29702,30359]
decorated [29722,30379]
===
match
---
name: task [65032,65036]
name: task [65052,65056]
===
match
---
name: str [74602,74605]
name: str [74622,74625]
===
match
---
trailer [19413,19420]
trailer [19433,19440]
===
match
---
comparison [14688,14721]
comparison [14708,14741]
===
match
---
param [35960,35984]
param [35980,36004]
===
match
---
operator: , [33943,33944]
operator: , [33963,33964]
===
match
---
operator: = [54942,54943]
operator: = [54962,54963]
===
match
---
expr_stmt [78308,78328]
expr_stmt [78328,78348]
===
match
---
operator: , [10706,10707]
operator: , [10734,10735]
===
match
---
atom_expr [50803,50857]
atom_expr [50823,50877]
===
match
---
trailer [60492,60498]
trailer [60512,60518]
===
match
---
name: hr_line_break [40351,40364]
name: hr_line_break [40371,40384]
===
match
---
decorated [15473,18868]
decorated [15493,18888]
===
match
---
operator: , [10736,10737]
operator: , [10764,10765]
===
match
---
atom_expr [72720,72774]
atom_expr [72740,72794]
===
match
---
name: jinja_context [71204,71217]
name: jinja_context [71224,71237]
===
match
---
name: task_id [79366,79373]
name: task_id [79386,79393]
===
match
---
fstring_start: f" [67629,67631]
fstring_start: f" [67649,67651]
===
match
---
trailer [77046,77060]
trailer [77066,77080]
===
match
---
name: session [21042,21049]
name: session [21062,21069]
===
match
---
trailer [56262,56267]
trailer [56282,56287]
===
match
---
name: ts_nodash_with_tz [65914,65931]
name: ts_nodash_with_tz [65934,65951]
===
match
---
name: task_id [58513,58520]
name: task_id [58533,58540]
===
match
---
name: state [29072,29077]
name: state [29092,29097]
===
match
---
operator: = [17929,17930]
operator: = [17949,17950]
===
match
---
name: RenderedTaskInstanceFields [48230,48256]
name: RenderedTaskInstanceFields [48250,48276]
===
match
---
expr_stmt [49785,49803]
expr_stmt [49805,49823]
===
match
---
name: state [7460,7465]
name: state [7488,7493]
===
match
---
trailer [45614,45616]
trailer [45634,45636]
===
match
---
operator: = [82287,82288]
operator: = [82307,82308]
===
match
---
expr_stmt [19568,19612]
expr_stmt [19588,19632]
===
match
---
simple_stmt [5334,5355]
simple_stmt [5362,5383]
===
match
---
param [29211,29235]
param [29231,29255]
===
match
---
return_stmt [29636,29696]
return_stmt [29656,29716]
===
match
---
arglist [72224,72269]
arglist [72244,72289]
===
match
---
trailer [82039,82045]
trailer [82059,82065]
===
match
---
and_test [14630,14651]
and_test [14650,14671]
===
match
---
simple_stmt [78338,78360]
simple_stmt [78358,78380]
===
match
---
atom_expr [78945,79012]
atom_expr [78965,79032]
===
match
---
name: session [40435,40442]
name: session [40455,40462]
===
match
---
return_stmt [81356,81374]
return_stmt [81376,81394]
===
match
---
dotted_name [60265,60286]
dotted_name [60285,60306]
===
match
---
atom_expr [12058,12071]
atom_expr [12086,12099]
===
match
---
operator: - [72931,72932]
operator: - [72951,72952]
===
match
---
name: default_html_content_err [72334,72358]
name: default_html_content_err [72354,72378]
===
match
---
trailer [19017,19022]
trailer [19037,19042]
===
match
---
simple_stmt [59960,59977]
simple_stmt [59980,59997]
===
match
---
name: airflow [82497,82504]
name: airflow [82517,82524]
===
match
---
name: session [19899,19906]
name: session [19919,19926]
===
match
---
name: self [44120,44124]
name: self [44140,44144]
===
match
---
suite [26566,28070]
suite [26586,28090]
===
match
---
name: pod [69058,69061]
name: pod [69078,69081]
===
match
---
expr_stmt [53866,54303]
expr_stmt [53886,54323]
===
match
---
name: task [59972,59976]
name: task [59992,59996]
===
match
---
atom_expr [80321,80328]
atom_expr [80341,80348]
===
match
---
name: task_id [14993,15000]
name: task_id [15013,15020]
===
match
---
name: Optional [52369,52377]
name: Optional [52389,52397]
===
match
---
name: and_ [78738,78742]
name: and_ [78758,78762]
===
match
---
parameters [12681,12687]
parameters [12701,12707]
===
match
---
name: base [1848,1852]
name: base [1833,1837]
===
match
---
operator: , [81594,81595]
operator: , [81614,81615]
===
match
---
atom_expr [72731,72746]
atom_expr [72751,72766]
===
match
---
operator: , [54141,54142]
operator: , [54161,54162]
===
match
---
atom_expr [57210,57225]
atom_expr [57230,57245]
===
match
---
trailer [41271,41286]
trailer [41291,41306]
===
match
---
name: Dict [3198,3202]
name: Dict [3226,3230]
===
match
---
name: airflow [7317,7324]
name: airflow [7345,7352]
===
match
---
name: logging_mixin [2528,2541]
name: logging_mixin [2513,2526]
===
match
---
trailer [77911,77915]
trailer [77931,77935]
===
match
---
name: self [50651,50655]
name: self [50671,50675]
===
match
---
trailer [82672,82681]
trailer [82692,82701]
===
match
---
return_stmt [26003,26014]
return_stmt [26023,26034]
===
match
---
name: self [24176,24180]
name: self [24196,24200]
===
match
---
name: load_error_file [54749,54764]
name: load_error_file [54769,54784]
===
match
---
param [24429,24441]
param [24449,24461]
===
match
---
param [15672,15702]
param [15692,15722]
===
match
---
operator: = [82658,82659]
operator: = [82678,82679]
===
match
---
name: Exception [4158,4167]
name: Exception [4186,4195]
===
match
---
operator: = [16072,16073]
operator: = [16092,16093]
===
match
---
funcdef [11077,12463]
funcdef [11105,12483]
===
match
---
expr_stmt [22564,22600]
expr_stmt [22584,22620]
===
match
---
atom_expr [69481,69517]
atom_expr [69501,69537]
===
match
---
operator: , [51880,51881]
operator: , [51900,51901]
===
match
---
trailer [79878,79894]
trailer [79898,79914]
===
match
---
name: warning [11535,11542]
name: warning [11563,11570]
===
match
---
name: task [58147,58151]
name: task [58167,58171]
===
match
---
sync_comp_for [78999,79011]
sync_comp_for [79019,79031]
===
match
---
atom_expr [62495,62506]
atom_expr [62515,62526]
===
match
---
atom_expr [6714,7021]
atom_expr [6742,7049]
===
match
---
name: _date_or_empty [43964,43978]
name: _date_or_empty [43984,43998]
===
match
---
name: session [77565,77572]
name: session [77585,77592]
===
match
---
name: self [25327,25331]
name: self [25347,25351]
===
match
---
trailer [12153,12162]
trailer [12173,12182]
===
match
---
operator: , [1339,1340]
operator: , [1324,1325]
===
match
---
import_name [787,804]
import_name [787,804]
===
match
---
name: bool [35823,35827]
name: bool [35843,35847]
===
match
---
name: airflow [67265,67272]
name: airflow [67285,67292]
===
match
---
atom_expr [10582,10618]
atom_expr [10610,10646]
===
match
---
name: cmd [17966,17969]
name: cmd [17986,17989]
===
match
---
name: cmd [18523,18526]
name: cmd [18543,18546]
===
match
---
name: self [45022,45026]
name: self [45042,45046]
===
match
---
name: max_tries [5552,5561]
name: max_tries [5580,5589]
===
match
---
import_from [2186,2219]
import_from [2171,2204]
===
match
---
operator: , [54263,54264]
operator: , [54283,54284]
===
match
---
name: dill [10348,10352]
name: dill [10376,10380]
===
match
---
name: DepContext [39552,39562]
name: DepContext [39572,39582]
===
match
---
operator: = [71935,71936]
operator: = [71955,71956]
===
match
---
name: execution_date [11741,11755]
name: execution_date [11769,11783]
===
match
---
atom_expr [4665,4675]
atom_expr [4693,4703]
===
match
---
simple_stmt [61749,61810]
simple_stmt [61769,61830]
===
match
---
string: 'prev_start_date_success' [65383,65408]
string: 'prev_start_date_success' [65403,65428]
===
match
---
name: html_content_err [72399,72415]
name: html_content_err [72419,72435]
===
match
---
simple_stmt [46074,46341]
simple_stmt [46094,46361]
===
match
---
trailer [59179,59195]
trailer [59199,59215]
===
match
---
decorator [13884,13894]
decorator [13904,13914]
===
match
---
trailer [78950,78957]
trailer [78970,78977]
===
match
---
funcdef [77824,77954]
funcdef [77844,77974]
===
match
---
trailer [26047,26053]
trailer [26067,26073]
===
match
---
name: self [22100,22104]
name: self [22120,22124]
===
match
---
name: delete_qry [7275,7285]
name: delete_qry [7303,7313]
===
match
---
number: 1 [40671,40672]
number: 1 [40691,40692]
===
match
---
name: state [12127,12132]
name: state [12147,12152]
===
match
---
trailer [29071,29092]
trailer [29091,29112]
===
match
---
atom_expr [26312,26325]
atom_expr [26332,26345]
===
match
---
atom_expr [68466,68477]
atom_expr [68486,68497]
===
match
---
atom_expr [6689,7107]
atom_expr [6717,7135]
===
match
---
operator: == [35487,35489]
operator: == [35507,35509]
===
match
---
subscriptlist [56141,56155]
subscriptlist [56161,56175]
===
match
---
simple_stmt [18577,18601]
simple_stmt [18597,18621]
===
match
---
trailer [45026,45032]
trailer [45046,45052]
===
match
---
arglist [11778,11816]
arglist [11806,11844]
===
match
---
atom [5058,5060]
atom [5086,5088]
===
match
---
trailer [10264,10273]
trailer [10292,10301]
===
match
---
name: parse [1130,1135]
name: parse [1115,1120]
===
match
---
atom_expr [48540,48588]
atom_expr [48560,48608]
===
match
---
simple_stmt [5282,5308]
simple_stmt [5310,5336]
===
match
---
expr_stmt [69416,69455]
expr_stmt [69436,69475]
===
match
---
name: SUCCESS [52897,52904]
name: SUCCESS [52917,52924]
===
match
---
name: create_pod_id [68532,68545]
name: create_pod_id [68552,68565]
===
match
---
operator: , [65703,65704]
operator: , [65723,65724]
===
match
---
operator: , [1065,1066]
operator: , [1050,1051]
===
match
---
trailer [78772,78779]
trailer [78792,78799]
===
match
---
atom_expr [63907,63915]
atom_expr [63927,63935]
===
match
---
name: test_mode [42663,42672]
name: test_mode [42683,42692]
===
match
---
name: airflow [35342,35349]
name: airflow [35362,35369]
===
match
---
fstring_string: &dag_id= [19400,19408]
fstring_string: &dag_id= [19420,19428]
===
match
---
string: "previous_execution_date was called" [29521,29557]
string: "previous_execution_date was called" [29541,29577]
===
match
---
simple_stmt [40504,40517]
simple_stmt [40524,40537]
===
match
---
atom_expr [20847,20902]
atom_expr [20867,20922]
===
match
---
arith_expr [37971,37988]
arith_expr [37991,38008]
===
match
---
name: self [33008,33012]
name: self [33028,33032]
===
match
---
tfpdef [64330,64346]
tfpdef [64350,64366]
===
match
---
parameters [80765,80771]
parameters [80785,80791]
===
match
---
operator: = [62345,62346]
operator: = [62365,62366]
===
match
---
simple_stmt [51988,52050]
simple_stmt [52008,52070]
===
match
---
fstring_start: f" [19089,19091]
fstring_start: f" [19109,19111]
===
match
---
trailer [19022,19033]
trailer [19042,19053]
===
match
---
operator: = [54258,54259]
operator: = [54278,54279]
===
match
---
operator: = [38402,38403]
operator: = [38422,38423]
===
match
---
trailer [71015,71027]
trailer [71035,71047]
===
match
---
name: error [56604,56609]
name: error [56624,56629]
===
match
---
name: session [27906,27913]
name: session [27926,27933]
===
match
---
name: task [53163,53167]
name: task [53183,53187]
===
match
---
name: str [16067,16070]
name: str [16087,16090]
===
match
---
name: error [59454,59459]
name: error [59474,59479]
===
match
---
operator: , [44648,44649]
operator: , [44668,44669]
===
match
---
suite [78082,79491]
suite [78102,79511]
===
match
---
trailer [58538,58549]
trailer [58558,58569]
===
match
---
name: render [71290,71296]
name: render [71310,71316]
===
match
---
trailer [52792,52805]
trailer [52812,52825]
===
match
---
trailer [60239,60246]
trailer [60259,60266]
===
match
---
string: "Rescheduling due to concurrency limits reached " [40073,40122]
string: "Rescheduling due to concurrency limits reached " [40093,40142]
===
match
---
name: jinja_context [70537,70550]
name: jinja_context [70557,70570]
===
match
---
name: self [42681,42685]
name: self [42701,42705]
===
match
---
fstring [62398,62443]
fstring [62418,62463]
===
match
---
import_from [2125,2185]
import_from [2110,2170]
===
match
---
comparison [20303,20337]
comparison [20323,20357]
===
match
---
simple_stmt [862,872]
simple_stmt [847,857]
===
match
---
simple_stmt [916,952]
simple_stmt [901,937]
===
match
---
trailer [33928,33943]
trailer [33948,33963]
===
match
---
name: plugins_manager [2138,2153]
name: plugins_manager [2123,2138]
===
match
---
atom_expr [4033,4044]
atom_expr [4061,4072]
===
match
---
name: max_tries [71724,71733]
name: max_tries [71744,71753]
===
match
---
atom_expr [79182,79202]
atom_expr [79202,79222]
===
match
---
simple_stmt [12122,12141]
simple_stmt [12142,12161]
===
match
---
param [29174,29202]
param [29194,29222]
===
match
---
simple_stmt [61908,61959]
simple_stmt [61928,61979]
===
match
---
simple_stmt [59792,59802]
simple_stmt [59812,59822]
===
match
---
name: do_xcom_push [51797,51809]
name: do_xcom_push [51817,51829]
===
match
---
comparison [82180,82231]
comparison [82200,82251]
===
match
---
suite [4083,4104]
suite [4111,4132]
===
match
---
operator: -> [16086,16088]
operator: -> [16106,16108]
===
match
---
atom_expr [55906,55922]
atom_expr [55926,55942]
===
match
---
fstring_end: " [62442,62443]
fstring_end: " [62462,62463]
===
match
---
name: self [22902,22906]
name: self [22922,22926]
===
match
---
trailer [76457,76466]
trailer [76477,76486]
===
match
---
name: init_on_load [12491,12503]
name: init_on_load [12511,12523]
===
match
---
operator: , [80230,80231]
operator: , [80250,80251]
===
match
---
param [22947,22965]
param [22967,22985]
===
match
---
parameters [8595,8618]
parameters [8623,8646]
===
match
---
trailer [35472,35548]
trailer [35492,35568]
===
match
---
name: self [37570,37574]
name: self [37590,37594]
===
match
---
name: _execution_date [79879,79894]
name: _execution_date [79899,79914]
===
match
---
operator: , [8289,8290]
operator: , [8317,8318]
===
match
---
testlist_comp [18208,18231]
testlist_comp [18228,18251]
===
match
---
operator: } [42933,42934]
operator: } [42953,42954]
===
match
---
import_name [872,885]
import_name [857,870]
===
match
---
name: Log [1920,1923]
name: Log [1905,1908]
===
match
---
name: dr [27345,27347]
name: dr [27365,27367]
===
match
---
suite [71431,72360]
suite [71451,72380]
===
match
---
name: lock_for_update [81610,81625]
name: lock_for_update [81630,81645]
===
match
---
trailer [68793,68815]
trailer [68813,68835]
===
match
---
trailer [21606,21779]
trailer [21626,21799]
===
match
---
simple_stmt [7601,7847]
simple_stmt [7629,7875]
===
match
---
trailer [17945,17955]
trailer [17965,17975]
===
match
---
name: from_obj [68785,68793]
name: from_obj [68805,68813]
===
match
---
operator: = [22034,22035]
operator: = [22054,22055]
===
match
---
operator: , [36079,36080]
operator: , [36099,36100]
===
match
---
operator: -> [68317,68319]
operator: -> [68337,68339]
===
match
---
trailer [42881,42888]
trailer [42901,42908]
===
match
---
operator: , [66102,66103]
operator: , [66122,66123]
===
match
---
name: self [81334,81338]
name: self [81354,81358]
===
match
---
operator: = [62145,62146]
operator: = [62165,62166]
===
match
---
name: info [47614,47618]
name: info [47634,47638]
===
match
---
name: start_date [39047,39057]
name: start_date [39067,39077]
===
match
---
name: task_id [8057,8064]
name: task_id [8085,8092]
===
match
---
suite [37821,37875]
suite [37841,37895]
===
match
---
string: "--pickle" [18136,18146]
string: "--pickle" [18156,18166]
===
match
---
name: next_execution_date [61749,61768]
name: next_execution_date [61769,61788]
===
match
---
name: task [23588,23592]
name: task [23608,23612]
===
match
---
trailer [26494,26499]
trailer [26514,26519]
===
match
---
name: warnings [30612,30620]
name: warnings [30632,30640]
===
match
---
argument [78949,79011]
argument [78969,79031]
===
match
---
name: State [24904,24909]
name: State [24924,24929]
===
match
---
param [19899,19911]
param [19919,19931]
===
match
---
name: ti [21882,21884]
name: ti [21902,21904]
===
match
---
name: actual_start_date [55149,55166]
name: actual_start_date [55169,55186]
===
match
---
atom_expr [45656,45704]
atom_expr [45676,45724]
===
match
---
atom_expr [65978,66000]
atom_expr [65998,66020]
===
match
---
name: log [40339,40342]
name: log [40359,40362]
===
match
---
atom_expr [10145,10160]
atom_expr [10173,10188]
===
match
---
simple_stmt [42646,42673]
simple_stmt [42666,42693]
===
match
---
operator: , [1075,1076]
operator: , [1060,1061]
===
match
---
name: run_id [60544,60550]
name: run_id [60564,60570]
===
match
---
arglist [34782,34814]
arglist [34802,34834]
===
match
---
trailer [22705,22714]
trailer [22725,22734]
===
match
---
name: dr [26860,26862]
name: dr [26880,26882]
===
match
---
name: self [65459,65463]
name: self [65479,65483]
===
match
---
trailer [61411,61429]
trailer [61431,61449]
===
match
---
atom_expr [22288,22303]
atom_expr [22308,22323]
===
match
---
name: cfg_path [14349,14357]
name: cfg_path [14369,14377]
===
match
---
expr_stmt [19279,19323]
expr_stmt [19299,19343]
===
match
---
name: self [55906,55910]
name: self [55926,55930]
===
match
---
operator: = [80278,80279]
operator: = [80298,80299]
===
match
---
import_from [1591,1629]
import_from [1576,1614]
===
match
---
name: lazy_object_proxy [65253,65270]
name: lazy_object_proxy [65273,65290]
===
match
---
suite [51174,51918]
suite [51194,51938]
===
match
---
tfpdef [68058,68084]
tfpdef [68078,68104]
===
match
---
trailer [41373,41388]
trailer [41393,41408]
===
match
---
name: airflow [2567,2574]
name: airflow [2552,2559]
===
match
---
name: self [77653,77657]
name: self [77673,77677]
===
match
---
name: priority_weight [81228,81243]
name: priority_weight [81248,81263]
===
match
---
name: log [52236,52239]
name: log [52256,52259]
===
match
---
trailer [26169,26195]
trailer [26189,26215]
===
match
---
atom [7768,7801]
atom [7796,7829]
===
match
---
name: lock_for_update [21056,21071]
name: lock_for_update [21076,21091]
===
match
---
number: 1 [57010,57011]
number: 1 [57030,57031]
===
match
---
atom_expr [39284,39299]
atom_expr [39304,39319]
===
match
---
simple_stmt [1591,1630]
simple_stmt [1576,1615]
===
match
---
operator: = [53746,53747]
operator: = [53766,53767]
===
match
---
name: staticmethod [77960,77972]
name: staticmethod [77980,77992]
===
match
---
trailer [81198,81204]
trailer [81218,81224]
===
match
---
operator: = [78383,78384]
operator: = [78403,78404]
===
match
---
simple_stmt [41398,41410]
simple_stmt [41418,41430]
===
match
---
simple_stmt [44795,44801]
simple_stmt [44815,44821]
===
match
---
suite [59919,66170]
suite [59939,66190]
===
match
---
if_stmt [21907,22849]
if_stmt [21927,22869]
===
match
---
operator: = [53310,53311]
operator: = [53330,53331]
===
match
---
trailer [12180,12193]
trailer [12200,12213]
===
match
---
decorator [80587,80597]
decorator [80607,80617]
===
match
---
name: Column [10258,10264]
name: Column [10286,10292]
===
match
---
name: State [44650,44655]
name: State [44670,44675]
===
match
---
arglist [72153,72188]
arglist [72173,72208]
===
match
---
name: replace [61996,62003]
name: replace [62016,62023]
===
match
---
name: timedelta [34613,34622]
name: timedelta [34633,34642]
===
match
---
trailer [80440,80457]
trailer [80460,80477]
===
match
---
operator: , [35156,35157]
operator: , [35176,35177]
===
match
---
expr_stmt [9796,9850]
expr_stmt [9824,9878]
===
match
---
argument [68491,68511]
argument [68511,68531]
===
match
---
trailer [55556,55568]
trailer [55576,55588]
===
match
---
operator: , [64619,64620]
operator: , [64639,64640]
===
match
---
arglist [4665,4679]
arglist [4693,4707]
===
match
---
arglist [57183,57240]
arglist [57203,57260]
===
match
---
if_stmt [18324,18395]
if_stmt [18344,18415]
===
match
---
atom_expr [68945,69011]
atom_expr [68965,69031]
===
match
---
expr_stmt [24936,24981]
expr_stmt [24956,25001]
===
match
---
suite [67795,68026]
suite [67815,68046]
===
match
---
atom_expr [27710,27721]
atom_expr [27730,27741]
===
match
---
name: get_previous_execution_date [29123,29150]
name: get_previous_execution_date [29143,29170]
===
match
---
name: task_id [76971,76978]
name: task_id [76991,76998]
===
match
---
operator: = [48948,48949]
operator: = [48968,48969]
===
match
---
tfpdef [73179,73213]
tfpdef [73199,73233]
===
match
---
name: self [45585,45589]
name: self [45605,45609]
===
match
---
trailer [74547,74567]
trailer [74567,74587]
===
match
---
expr_stmt [19515,19559]
expr_stmt [19535,19579]
===
match
---
name: force_fail [59247,59257]
name: force_fail [59267,59277]
===
match
---
operator: , [79164,79165]
operator: , [79184,79185]
===
match
---
expr_stmt [80260,80294]
expr_stmt [80280,80314]
===
match
---
arglist [51861,51894]
arglist [51881,51914]
===
match
---
operator: = [19288,19289]
operator: = [19308,19309]
===
match
---
lambdef [65294,65355]
lambdef [65314,65375]
===
match
---
name: dag [14848,14851]
name: dag [14868,14871]
===
match
---
trailer [72646,72651]
trailer [72666,72671]
===
match
---
name: dag [26828,26831]
name: dag [26848,26851]
===
match
---
name: AirflowException [44411,44427]
name: AirflowException [44431,44447]
===
match
---
trailer [6116,6124]
trailer [6144,6152]
===
match
---
operator: = [27825,27826]
operator: = [27845,27846]
===
match
---
atom_expr [77579,77591]
atom_expr [77599,77611]
===
match
---
argument [9642,9658]
argument [9670,9686]
===
match
---
operator: = [54378,54379]
operator: = [54398,54399]
===
match
---
name: task_id [78974,78981]
name: task_id [78994,79001]
===
match
---
operator: @ [28075,28076]
operator: @ [28095,28096]
===
match
---
argument [60416,60438]
argument [60436,60458]
===
match
---
param [29766,29794]
param [29786,29814]
===
match
---
operator: = [78314,78315]
operator: = [78334,78335]
===
match
---
string: 'yesterday_ds_nodash' [66116,66137]
string: 'yesterday_ds_nodash' [66136,66157]
===
match
---
string: "XCom data cleared" [24128,24147]
string: "XCom data cleared" [24148,24167]
===
match
---
atom_expr [58658,58702]
atom_expr [58678,58722]
===
match
---
import_from [2933,2986]
import_from [2961,3014]
===
match
---
expr_stmt [62266,62317]
expr_stmt [62286,62337]
===
match
---
simple_stmt [47704,47721]
simple_stmt [47724,47741]
===
match
---
name: is_eligible_to_retry [57869,57889]
name: is_eligible_to_retry [57889,57909]
===
match
---
name: session [74702,74709]
name: session [74722,74729]
===
match
---
operator: = [54647,54648]
operator: = [54667,54668]
===
match
---
argument [71202,71217]
argument [71222,71237]
===
match
---
trailer [17955,17957]
trailer [17975,17977]
===
match
---
trailer [42788,42795]
trailer [42808,42815]
===
match
---
name: context [49632,49639]
name: context [49652,49659]
===
match
---
name: task_id [33027,33034]
name: task_id [33047,33054]
===
match
---
trailer [59570,59575]
trailer [59590,59595]
===
match
---
operator: = [34155,34156]
operator: = [34175,34176]
===
match
---
operator: @ [20616,20617]
operator: @ [20636,20637]
===
match
---
trailer [35438,35444]
trailer [35458,35464]
===
match
---
trailer [14851,14865]
trailer [14871,14885]
===
match
---
trailer [29083,29091]
trailer [29103,29111]
===
match
---
arith_expr [40654,40672]
arith_expr [40674,40692]
===
match
---
simple_stmt [60057,60093]
simple_stmt [60077,60113]
===
match
---
atom_expr [26388,26417]
atom_expr [26408,26437]
===
match
---
simple_stmt [62095,62127]
simple_stmt [62115,62147]
===
match
---
name: _end_date [79989,79998]
name: _end_date [80009,80018]
===
match
---
name: kube_image [68626,68636]
name: kube_image [68646,68656]
===
match
---
suite [77446,77819]
suite [77466,77839]
===
match
---
atom_expr [70756,70969]
atom_expr [70776,70989]
===
match
---
operator: = [10892,10893]
operator: = [10920,10921]
===
match
---
name: get_previous_ti [29056,29071]
name: get_previous_ti [29076,29091]
===
match
---
suite [81649,82380]
suite [81669,82400]
===
match
---
name: SHUTDOWN [7474,7482]
name: SHUTDOWN [7502,7510]
===
match
---
atom_expr [81514,81535]
atom_expr [81534,81555]
===
match
---
arglist [6744,6999]
arglist [6772,7027]
===
match
---
trailer [59769,59778]
trailer [59789,59798]
===
match
---
name: session [45802,45809]
name: session [45822,45829]
===
match
---
name: end_date [56892,56900]
name: end_date [56912,56920]
===
match
---
name: self [33910,33914]
name: self [33930,33934]
===
match
---
name: test_mode [59351,59360]
name: test_mode [59371,59380]
===
match
---
simple_stmt [40334,40366]
simple_stmt [40354,40386]
===
match
---
name: and_ [79033,79037]
name: and_ [79053,79057]
===
match
---
name: last_dagrun [27988,27999]
name: last_dagrun [28008,28019]
===
match
---
simple_stmt [39284,39329]
simple_stmt [39304,39349]
===
match
---
operator: { [48790,48791]
operator: { [48810,48811]
===
match
---
name: State [7893,7898]
name: State [7921,7926]
===
match
---
trailer [5940,5950]
trailer [5968,5978]
===
match
---
name: self [58975,58979]
name: self [58995,58999]
===
match
---
trailer [71177,71194]
trailer [71197,71214]
===
match
---
name: AirflowSkipException [1747,1767]
name: AirflowSkipException [1732,1752]
===
match
---
atom_expr [23935,23946]
atom_expr [23955,23966]
===
match
---
name: tis [78321,78324]
name: tis [78341,78344]
===
match
---
arglist [58550,58583]
arglist [58570,58603]
===
match
---
name: RUNNING [77764,77771]
name: RUNNING [77784,77791]
===
match
---
name: self [20647,20651]
name: self [20667,20671]
===
match
---
name: max_tries [22394,22403]
name: max_tries [22414,22423]
===
match
---
trailer [30625,30867]
trailer [30645,30887]
===
match
---
arglist [80228,80245]
arglist [80248,80265]
===
match
---
name: task_type [23593,23602]
name: task_type [23613,23622]
===
match
---
atom [18368,18393]
atom [18388,18413]
===
match
---
name: task [64640,64644]
name: task [64660,64664]
===
match
---
atom_expr [41103,41128]
atom_expr [41123,41148]
===
match
---
atom_expr [11869,11904]
atom_expr [11897,11932]
===
match
---
name: prev_execution_date [62025,62044]
name: prev_execution_date [62045,62064]
===
match
---
operator: = [60422,60423]
operator: = [60442,60443]
===
match
---
name: render_templates [66684,66700]
name: render_templates [66704,66720]
===
match
---
funcdef [80673,80728]
funcdef [80693,80748]
===
match
---
string: """Prepare Task for Execution""" [48145,48177]
string: """Prepare Task for Execution""" [48165,48197]
===
match
---
trailer [68445,69022]
trailer [68465,69042]
===
match
---
name: XCOM_RETURN_KEY [2103,2118]
name: XCOM_RETURN_KEY [2088,2103]
===
match
---
expr_stmt [37955,37988]
expr_stmt [37975,38008]
===
match
---
atom_expr [6050,6125]
atom_expr [6078,6153]
===
match
---
name: State [53119,53124]
name: State [53139,53144]
===
match
---
operator: , [1353,1354]
operator: , [1338,1339]
===
match
---
argument [76528,76535]
argument [76548,76555]
===
match
---
name: pod_generator [3092,3105]
name: pod_generator [3120,3133]
===
match
---
name: str [8049,8052]
name: str [8077,8080]
===
match
---
import_from [1630,1827]
import_from [1615,1812]
===
match
---
name: construct_pod [68432,68445]
name: construct_pod [68452,68465]
===
match
---
name: self [52356,52360]
name: self [52376,52380]
===
match
---
trailer [8553,8564]
trailer [8581,8592]
===
match
---
comparison [35064,35110]
comparison [35084,35130]
===
match
---
decorated [28559,29093]
decorated [28579,29113]
===
match
---
argument [74251,74271]
argument [74271,74291]
===
match
---
name: self [48717,48721]
name: self [48737,48741]
===
match
---
name: jinja_context [71444,71457]
name: jinja_context [71464,71477]
===
match
---
name: expanduser [19023,19033]
name: expanduser [19043,19053]
===
match
---
trailer [61779,61788]
trailer [61799,61808]
===
match
---
name: query [77257,77262]
name: query [77277,77282]
===
match
---
name: utcnow [56912,56918]
name: utcnow [56932,56938]
===
match
---
name: log [56600,56603]
name: log [56620,56623]
===
match
---
atom_expr [47877,48029]
atom_expr [47897,48049]
===
match
---
operator: = [68771,68772]
operator: = [68791,68792]
===
match
---
trailer [48511,48519]
trailer [48531,48539]
===
match
---
simple_stmt [12519,12580]
simple_stmt [12539,12600]
===
match
---
name: task [52120,52124]
name: task [52140,52144]
===
match
---
and_test [25327,25390]
and_test [25347,25410]
===
match
---
operator: = [54706,54707]
operator: = [54726,54727]
===
match
---
operator: @ [81310,81311]
operator: @ [81330,81331]
===
match
---
simple_stmt [10882,11072]
simple_stmt [10910,11100]
===
match
---
expr_stmt [33305,33334]
expr_stmt [33325,33354]
===
match
---
name: extend [18278,18284]
name: extend [18298,18304]
===
match
---
decorated [20616,20990]
decorated [20636,21010]
===
match
---
simple_stmt [22374,22404]
simple_stmt [22394,22424]
===
match
---
operator: = [22430,22431]
operator: = [22450,22451]
===
match
---
name: get_previous_execution_date [65307,65334]
name: get_previous_execution_date [65327,65354]
===
match
---
operator: = [72300,72301]
operator: = [72320,72321]
===
match
---
simple_stmt [37513,37562]
simple_stmt [37533,37582]
===
match
---
simple_stmt [34660,34712]
simple_stmt [34680,34732]
===
match
---
operator: , [15354,15355]
operator: , [15374,15375]
===
match
---
operator: , [1059,1060]
operator: , [1044,1045]
===
match
---
param [53724,53753]
param [53744,53773]
===
match
---
name: UP_FOR_RETRY [53125,53137]
name: UP_FOR_RETRY [53145,53157]
===
match
---
operator: = [59231,59232]
operator: = [59251,59252]
===
match
---
name: include_downstream [46743,46761]
name: include_downstream [46763,46781]
===
match
---
name: execution_date [74128,74142]
name: execution_date [74148,74162]
===
match
---
name: ignore_ti_state [37773,37788]
name: ignore_ti_state [37793,37808]
===
match
---
name: airflow [2727,2734]
name: airflow [2755,2762]
===
match
---
operator: = [46761,46762]
operator: = [46781,46782]
===
match
---
name: list [78316,78320]
name: list [78336,78340]
===
match
---
name: exception [52309,52318]
name: exception [52329,52338]
===
match
---
name: hasattr [80392,80399]
name: hasattr [80412,80419]
===
match
---
tfpdef [63381,63397]
tfpdef [63401,63417]
===
match
---
atom_expr [49423,49462]
atom_expr [49443,49482]
===
match
---
number: 2 [30855,30856]
number: 2 [30875,30876]
===
match
---
name: utcnow [55352,55358]
name: utcnow [55372,55378]
===
match
---
atom_expr [71460,71487]
atom_expr [71480,71507]
===
match
---
simple_stmt [42681,42730]
simple_stmt [42701,42750]
===
match
---
trailer [77572,77578]
trailer [77592,77598]
===
match
---
string: "exception" [53297,53308]
string: "exception" [53317,53328]
===
match
---
trailer [29680,29695]
trailer [29700,29715]
===
match
---
simple_stmt [24699,24762]
simple_stmt [24719,24782]
===
match
---
name: ignore_depends_on_past [54027,54049]
name: ignore_depends_on_past [54047,54069]
===
match
---
name: self [29506,29510]
name: self [29526,29530]
===
match
---
return_stmt [32983,33074]
return_stmt [33003,33094]
===
match
---
string: "Dependencies all met for %s" [32245,32274]
string: "Dependencies all met for %s" [32265,32294]
===
match
---
name: execution_date [64793,64807]
name: execution_date [64813,64827]
===
match
---
name: self [24797,24801]
name: self [24817,24821]
===
match
---
name: Column [9470,9476]
name: Column [9498,9504]
===
match
---
trailer [47963,47973]
trailer [47983,47993]
===
match
---
name: Context [3237,3244]
name: Context [3265,3272]
===
match
---
trailer [18640,18658]
trailer [18660,18678]
===
match
---
trailer [82310,82316]
trailer [82330,82336]
===
match
---
name: test_mode [44745,44754]
name: test_mode [44765,44774]
===
match
---
operator: , [10753,10754]
operator: , [10781,10782]
===
match
---
simple_stmt [81436,81453]
simple_stmt [81456,81473]
===
match
---
tfpdef [35730,35743]
tfpdef [35750,35763]
===
match
---
operator: , [74271,74272]
operator: , [74291,74292]
===
match
---
name: test_mode [35960,35969]
name: test_mode [35980,35989]
===
match
---
name: first [35562,35567]
name: first [35582,35587]
===
match
---
name: deps [32514,32518]
name: deps [32534,32538]
===
match
---
name: isoformat [18985,18994]
name: isoformat [19005,19014]
===
match
---
fstring_end: " [67685,67686]
fstring_end: " [67705,67706]
===
match
---
name: task [60423,60427]
name: task [60443,60447]
===
match
---
trailer [25031,25042]
trailer [25051,25062]
===
match
---
argument [6714,7089]
argument [6742,7117]
===
match
---
name: task [54937,54941]
name: task [54957,54961]
===
match
---
name: key [74205,74208]
name: key [74225,74228]
===
match
---
atom_expr [33673,33694]
atom_expr [33693,33714]
===
match
---
atom_expr [64044,64085]
atom_expr [64064,64105]
===
match
---
name: error [52362,52367]
name: error [52382,52387]
===
match
---
name: execution_date [6765,6779]
name: execution_date [6793,6807]
===
match
---
operator: ** [71202,71204]
operator: ** [71222,71224]
===
match
---
trailer [77605,77612]
trailer [77625,77632]
===
match
---
trailer [78948,79012]
trailer [78968,79032]
===
match
---
trailer [25969,25989]
trailer [25989,26009]
===
match
---
name: STATICA_HACK [82453,82465]
name: STATICA_HACK [82473,82485]
===
match
---
simple_stmt [5549,5597]
simple_stmt [5577,5625]
===
match
---
simple_stmt [4092,4104]
simple_stmt [4120,4132]
===
match
---
annassign [80047,80068]
annassign [80067,80088]
===
match
---
name: session [76669,76676]
name: session [76689,76696]
===
match
---
name: self [53872,53876]
name: self [53892,53896]
===
match
---
name: task [32526,32530]
name: task [32546,32550]
===
match
---
operator: , [46278,46279]
operator: , [46298,46299]
===
match
---
name: state [77749,77754]
name: state [77769,77774]
===
match
---
atom_expr [60649,60689]
atom_expr [60669,60709]
===
match
---
trailer [33662,33727]
trailer [33682,33747]
===
match
---
operator: = [20222,20223]
operator: = [20242,20243]
===
match
---
argument [79134,79163]
argument [79154,79183]
===
match
---
name: self [61430,61434]
name: self [61450,61454]
===
match
---
name: FAILED [44656,44662]
name: FAILED [44676,44682]
===
match
---
name: session [2691,2698]
name: session [2719,2726]
===
match
---
name: task_id [48801,48808]
name: task_id [48821,48828]
===
match
---
name: self [74123,74127]
name: self [74143,74147]
===
match
---
name: check_and_change_state_before_execution [35629,35668]
name: check_and_change_state_before_execution [35649,35688]
===
match
---
simple_stmt [45926,45992]
simple_stmt [45946,46012]
===
match
---
atom_expr [10682,10706]
atom_expr [10710,10734]
===
match
---
operator: = [15848,15849]
operator: = [15868,15869]
===
match
---
argument [15086,15117]
argument [15106,15137]
===
match
---
name: sanitized_pod [69071,69084]
name: sanitized_pod [69091,69104]
===
match
---
name: current_time [24834,24846]
name: current_time [24854,24866]
===
match
---
name: TemplateAssertionError [1236,1258]
name: TemplateAssertionError [1221,1243]
===
match
---
name: ignore_all_deps [53959,53974]
name: ignore_all_deps [53979,53994]
===
match
---
name: datetime [79951,79959]
name: datetime [79971,79979]
===
match
---
trailer [66807,67153]
trailer [66827,67173]
===
match
---
trailer [23524,23540]
trailer [23544,23560]
===
match
---
if_stmt [33343,34816]
if_stmt [33363,34836]
===
match
---
atom_expr [42936,42948]
atom_expr [42956,42968]
===
match
---
name: query [35439,35444]
name: query [35459,35464]
===
match
---
argument [68673,68697]
argument [68693,68717]
===
match
---
decorated [77959,79491]
decorated [77979,79511]
===
match
---
name: execution_date [73910,73924]
name: execution_date [73930,73944]
===
match
---
name: pendulum [29254,29262]
name: pendulum [29274,29282]
===
match
---
simple_stmt [60618,60635]
simple_stmt [60638,60655]
===
match
---
trailer [31858,31882]
trailer [31878,31902]
===
match
---
name: ready_for_retry [25373,25388]
name: ready_for_retry [25393,25408]
===
match
---
name: ti [26355,26357]
name: ti [26375,26377]
===
match
---
operator: , [1709,1710]
operator: , [1694,1695]
===
match
---
name: self [58901,58905]
name: self [58921,58925]
===
match
---
name: extend [18128,18134]
name: extend [18148,18154]
===
match
---
name: TaskInstance [79055,79067]
name: TaskInstance [79075,79087]
===
match
---
atom_expr [72900,72913]
atom_expr [72920,72933]
===
match
---
name: ignore_ti_state [14214,14229]
name: ignore_ti_state [14234,14249]
===
match
---
operator: = [15996,15997]
operator: = [16016,16017]
===
match
---
atom_expr [68532,68572]
atom_expr [68552,68592]
===
match
---
name: log [49247,49250]
name: log [49267,49270]
===
match
---
trailer [72875,72886]
trailer [72895,72906]
===
match
---
name: self [62147,62151]
name: self [62167,62171]
===
match
---
trailer [30427,30446]
trailer [30447,30466]
===
match
---
param [36031,36058]
param [36051,36078]
===
match
---
trailer [60223,60230]
trailer [60243,60250]
===
match
---
name: str [41868,41871]
name: str [41888,41891]
===
match
---
operator: = [56415,56416]
operator: = [56435,56436]
===
match
---
operator: + [37976,37977]
operator: + [37996,37997]
===
match
---
operator: = [31781,31782]
operator: = [31801,31802]
===
match
---
decorator [80992,81002]
decorator [81012,81022]
===
match
---
trailer [40958,40964]
trailer [40978,40984]
===
match
---
atom_expr [59420,59460]
atom_expr [59440,59480]
===
match
---
operator: = [43573,43574]
operator: = [43593,43594]
===
match
---
operator: = [59453,59454]
operator: = [59473,59474]
===
match
---
operator: , [29793,29794]
operator: , [29813,29814]
===
match
---
atom_expr [80169,80186]
atom_expr [80189,80206]
===
match
---
name: result [77031,77037]
name: result [77051,77057]
===
match
---
operator: } [19128,19129]
operator: } [19148,19149]
===
match
---
trailer [6067,6074]
trailer [6095,6102]
===
match
---
trailer [40830,40836]
trailer [40850,40856]
===
match
---
name: execution_date [61435,61449]
name: execution_date [61455,61469]
===
match
---
atom_expr [27116,27158]
atom_expr [27136,27178]
===
match
---
name: ti [82284,82286]
name: ti [82304,82306]
===
match
---
string: """         Returns a command that can be executed anywhere where airflow is         installed. This command is part of the message sent to executors by         the orchestrator.         """ [14379,14569]
string: """         Returns a command that can be executed anywhere where airflow is         installed. This command is part of the message sent to executors by         the orchestrator.         """ [14399,14589]
===
match
---
atom_expr [71719,71733]
atom_expr [71739,71753]
===
match
---
name: Optional [3937,3945]
name: Optional [3965,3973]
===
match
---
name: ti [5989,5991]
name: ti [6017,6019]
===
match
---
name: execution_date [60654,60668]
name: execution_date [60674,60688]
===
match
---
dotted_name [1469,1491]
dotted_name [1454,1476]
===
match
---
funcdef [68287,69160]
funcdef [68307,69180]
===
match
---
name: count [26379,26384]
name: count [26399,26404]
===
match
---
trailer [68328,68334]
trailer [68348,68354]
===
match
---
trailer [68244,68249]
trailer [68264,68269]
===
match
---
name: priority_weight [80463,80478]
name: priority_weight [80483,80498]
===
match
---
arglist [41506,41516]
arglist [41526,41536]
===
match
---
name: Optional [53768,53776]
name: Optional [53788,53796]
===
match
---
simple_stmt [80303,80329]
simple_stmt [80323,80349]
===
match
---
operator: -> [68093,68095]
operator: -> [68113,68115]
===
match
---
atom_expr [45466,45485]
atom_expr [45486,45505]
===
match
---
simple_stmt [82345,82362]
simple_stmt [82365,82382]
===
match
---
name: dag_run [46898,46905]
name: dag_run [46918,46925]
===
match
---
comparison [35473,35501]
comparison [35493,35521]
===
match
---
name: verbose_aware_logger [31965,31985]
name: verbose_aware_logger [31985,32005]
===
match
---
arglist [68546,68571]
arglist [68566,68591]
===
match
---
trailer [55091,55093]
trailer [55111,55113]
===
match
---
name: kube_config [68637,68648]
name: kube_config [68657,68668]
===
match
---
operator: , [39601,39602]
operator: , [39621,39622]
===
match
---
atom_expr [52120,52153]
atom_expr [52140,52173]
===
match
---
name: job_id [42798,42804]
name: job_id [42818,42824]
===
match
---
funcdef [35625,41410]
funcdef [35645,41430]
===
match
---
import_from [2825,2866]
import_from [2853,2894]
===
match
---
operator: , [46195,46196]
operator: , [46215,46216]
===
match
---
sync_comp_for [79467,79480]
sync_comp_for [79487,79500]
===
match
---
trailer [58951,58957]
trailer [58971,58977]
===
match
---
name: ti [80400,80402]
name: ti [80420,80422]
===
match
---
expr_stmt [70111,70499]
expr_stmt [70131,70519]
===
match
---
name: try_number [8787,8797]
name: try_number [8815,8825]
===
match
---
name: property [25094,25102]
name: property [25114,25122]
===
match
---
trailer [55994,55998]
trailer [56014,56018]
===
match
---
string: "--cfg-path" [18824,18836]
string: "--cfg-path" [18844,18856]
===
match
---
name: filter [20279,20285]
name: filter [20299,20305]
===
match
---
funcdef [80925,80987]
funcdef [80945,81007]
===
match
---
atom_expr [49052,49063]
atom_expr [49072,49083]
===
match
---
operator: = [26353,26354]
operator: = [26373,26374]
===
match
---
atom_expr [58315,58334]
atom_expr [58335,58354]
===
match
---
arglist [47912,48011]
arglist [47932,48031]
===
match
---
trailer [41214,41218]
trailer [41234,41238]
===
match
---
name: iso [18959,18962]
name: iso [18979,18982]
===
match
---
trailer [19692,19700]
trailer [19712,19720]
===
match
---
atom_expr [22391,22403]
atom_expr [22411,22423]
===
match
---
name: Float [1306,1311]
name: Float [1291,1296]
===
match
---
trailer [55519,55534]
trailer [55539,55554]
===
match
---
trailer [76970,76978]
trailer [76990,76998]
===
match
---
funcdef [28089,28554]
funcdef [28109,28574]
===
match
---
atom_expr [24994,25007]
atom_expr [25014,25027]
===
match
---
arglist [45852,45911]
arglist [45872,45931]
===
match
---
operator: } [45032,45033]
operator: } [45052,45053]
===
match
---
operator: { [49347,49348]
operator: { [49367,49368]
===
match
---
operator: = [49856,49857]
operator: = [49876,49877]
===
match
---
parameters [45795,45815]
parameters [45815,45835]
===
match
---
operator: = [36015,36016]
operator: = [36035,36036]
===
match
---
name: self [63043,63047]
name: self [63063,63067]
===
match
---
trailer [42909,42951]
trailer [42929,42971]
===
match
---
name: html_content [72385,72397]
name: html_content [72405,72417]
===
match
---
tfpdef [15836,15847]
tfpdef [15856,15867]
===
match
---
name: int [81030,81033]
name: int [81050,81053]
===
match
---
name: handle_failure [56090,56104]
name: handle_failure [56110,56124]
===
match
---
param [25124,25128]
param [25144,25148]
===
match
---
funcdef [32955,33075]
funcdef [32975,33095]
===
match
---
atom_expr [71539,71752]
atom_expr [71559,71772]
===
match
---
return_stmt [32202,32214]
return_stmt [32222,32234]
===
match
---
param [79769,79785]
param [79789,79805]
===
match
---
name: ti [80055,80057]
name: ti [80075,80077]
===
match
---
trailer [5188,5196]
trailer [5216,5224]
===
match
---
simple_stmt [29506,29559]
simple_stmt [29526,29579]
===
match
---
name: namespace [68875,68884]
name: namespace [68895,68904]
===
match
---
name: jinja2 [71052,71058]
name: jinja2 [71072,71078]
===
match
---
atom_expr [6000,6010]
atom_expr [6028,6038]
===
match
---
funcdef [20637,20990]
funcdef [20657,21010]
===
match
---
name: task [55493,55497]
name: task [55513,55517]
===
match
---
name: ignore_ti_state [35885,35900]
name: ignore_ti_state [35905,35920]
===
match
---
expr_stmt [9533,9600]
expr_stmt [9561,9628]
===
match
---
simple_stmt [50453,50501]
simple_stmt [50473,50521]
===
match
---
string: """Overwrite Task Params with DagRun.conf""" [67804,67848]
string: """Overwrite Task Params with DagRun.conf""" [67824,67868]
===
match
---
trailer [78670,78685]
trailer [78690,78705]
===
match
---
name: var [63912,63915]
name: var [63932,63935]
===
match
---
operator: , [39713,39714]
operator: , [39733,39734]
===
match
---
operator: } [42948,42949]
operator: } [42968,42969]
===
match
---
name: session [26881,26888]
name: session [26901,26908]
===
match
---
name: ImportError [3133,3144]
name: ImportError [3161,3172]
===
match
---
dotted_name [2308,2341]
dotted_name [2293,2326]
===
match
---
funcdef [41415,41611]
funcdef [41435,41631]
===
match
---
argument [74205,74212]
argument [74225,74232]
===
match
---
name: result [59673,59679]
name: result [59693,59699]
===
match
---
trailer [40039,40043]
trailer [40059,40063]
===
match
---
parameters [29750,29824]
parameters [29770,29844]
===
match
---
name: session [40979,40986]
name: session [40999,41006]
===
match
---
trailer [61407,61411]
trailer [61427,61431]
===
match
---
name: _run_as_user [80174,80186]
name: _run_as_user [80194,80206]
===
match
---
atom_expr [39302,39328]
atom_expr [39322,39348]
===
match
---
trailer [62117,62126]
trailer [62137,62146]
===
match
---
name: next_ds [61712,61719]
name: next_ds [61732,61739]
===
match
---
trailer [21680,21688]
trailer [21700,21708]
===
match
---
name: job_id [37687,37693]
name: job_id [37707,37713]
===
match
---
name: next_ds [61632,61639]
name: next_ds [61652,61659]
===
match
---
name: urllib [1123,1129]
name: urllib [1108,1114]
===
match
---
operator: = [26888,26889]
operator: = [26908,26909]
===
match
---
comparison [79055,79084]
comparison [79075,79104]
===
match
---
name: e [43484,43485]
name: e [43504,43505]
===
match
---
name: dag_id [15521,15527]
name: dag_id [15541,15547]
===
match
---
suite [34753,34816]
suite [34773,34836]
===
match
---
name: int [81262,81265]
name: int [81282,81285]
===
match
---
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28640,28779]
string: """         This attribute is deprecated.         Please use `airflow.models.taskinstance.TaskInstance.get_previous_ti` method.         """ [28660,28799]
===
match
---
operator: = [64079,64080]
operator: = [64099,64100]
===
match
---
name: get_previous_ti [30157,30172]
name: get_previous_ti [30177,30192]
===
match
---
simple_stmt [62201,62258]
simple_stmt [62221,62278]
===
match
---
atom_expr [47161,47190]
atom_expr [47181,47210]
===
match
---
simple_stmt [2877,2928]
simple_stmt [2905,2956]
===
match
---
argument [71606,71635]
argument [71626,71655]
===
match
---
atom_expr [22306,22320]
atom_expr [22326,22340]
===
match
---
fstring_string: &execution_date= [19754,19770]
fstring_string: &execution_date= [19774,19790]
===
match
---
name: SEEK_SET [4036,4044]
name: SEEK_SET [4064,4072]
===
match
---
trailer [33692,33694]
trailer [33712,33714]
===
match
---
name: ti [22432,22434]
name: ti [22452,22454]
===
match
---
atom_expr [12440,12454]
atom_expr [12460,12474]
===
match
---
funcdef [4250,4681]
funcdef [4278,4709]
===
match
---
argument [11027,11040]
argument [11055,11068]
===
match
---
suite [72811,73078]
suite [72831,73098]
===
match
---
name: has_dag [11714,11721]
name: has_dag [11742,11749]
===
match
---
argument [38595,38610]
argument [38615,38630]
===
match
---
operator: = [22842,22843]
operator: = [22862,22863]
===
match
---
fstring_expr [33007,33020]
fstring_expr [33027,33040]
===
match
---
operator: = [24813,24814]
operator: = [24833,24834]
===
match
---
atom_expr [22701,22714]
atom_expr [22721,22734]
===
match
---
name: self [26865,26869]
name: self [26885,26889]
===
match
---
param [4269,4285]
param [4297,4313]
===
match
---
name: self [66593,66597]
name: self [66613,66617]
===
match
---
atom_expr [48772,48788]
atom_expr [48792,48808]
===
match
---
comparison [59724,59742]
comparison [59744,59762]
===
match
---
name: incr [50624,50628]
name: incr [50644,50648]
===
match
---
name: self [41466,41470]
name: self [41486,41490]
===
match
---
operator: = [38198,38199]
operator: = [38218,38219]
===
match
---
tfpdef [26508,26524]
tfpdef [26528,26544]
===
match
---
operator: , [68056,68057]
operator: , [68076,68077]
===
match
---
trailer [6654,6661]
trailer [6682,6689]
===
match
---
trailer [18753,18778]
trailer [18773,18798]
===
match
---
trailer [77060,77086]
trailer [77080,77106]
===
match
---
simple_stmt [51846,51896]
simple_stmt [51866,51916]
===
match
---
atom_expr [72917,72930]
atom_expr [72937,72950]
===
match
---
expr_stmt [60101,60112]
expr_stmt [60121,60132]
===
match
---
parameters [51948,51978]
parameters [51968,51998]
===
match
---
simple_stmt [54816,54857]
simple_stmt [54836,54877]
===
match
---
name: _dag_id [79801,79808]
name: _dag_id [79821,79828]
===
match
---
name: _dag_id [82108,82115]
name: _dag_id [82128,82135]
===
match
---
operator: , [8505,8506]
operator: , [8533,8534]
===
match
---
name: expected_state [3675,3689]
name: expected_state [3703,3717]
===
match
---
expr_stmt [9959,9983]
expr_stmt [9987,10011]
===
match
---
trailer [49672,49699]
trailer [49692,49719]
===
match
---
tfpdef [15672,15693]
tfpdef [15692,15713]
===
match
---
name: raw [77918,77921]
name: raw [77938,77941]
===
match
---
name: self [57115,57119]
name: self [57135,57139]
===
match
---
name: property [30365,30373]
name: property [30385,30393]
===
match
---
operator: = [15780,15781]
operator: = [15800,15801]
===
match
---
name: Index [10787,10792]
name: Index [10815,10820]
===
match
---
name: query [26037,26042]
name: query [26057,26062]
===
match
---
trailer [78352,78359]
trailer [78372,78379]
===
match
---
operator: + [40669,40670]
operator: + [40689,40690]
===
match
---
name: os [49423,49425]
name: os [49443,49445]
===
match
---
name: execution_date [24022,24036]
name: execution_date [24042,24056]
===
match
---
name: info [40566,40570]
name: info [40586,40590]
===
match
---
operator: , [11017,11018]
operator: , [11045,11046]
===
match
---
atom_expr [63225,63238]
atom_expr [63245,63258]
===
match
---
name: self [25939,25943]
name: self [25959,25963]
===
match
---
operator: = [60756,60757]
operator: = [60776,60777]
===
match
---
operator: == [35525,35527]
operator: == [35545,35547]
===
match
---
tfpdef [79769,79785]
tfpdef [79789,79805]
===
match
---
operator: , [34807,34808]
operator: , [34827,34828]
===
match
---
fstring_start: f" [19715,19717]
fstring_start: f" [19735,19737]
===
match
---
trailer [71894,71908]
trailer [71914,71928]
===
match
---
atom_expr [7211,7250]
atom_expr [7239,7278]
===
match
---
name: refresh_from_db [21020,21035]
name: refresh_from_db [21040,21055]
===
match
---
atom_expr [24306,24317]
atom_expr [24326,24337]
===
match
---
operator: , [55166,55167]
operator: , [55186,55187]
===
match
---
trailer [65270,65276]
trailer [65290,65296]
===
match
---
trailer [43798,43805]
trailer [43818,43825]
===
match
---
fstring [19676,19702]
fstring [19696,19722]
===
match
---
name: refresh_from_db [44274,44289]
name: refresh_from_db [44294,44309]
===
match
---
simple_stmt [48534,48589]
simple_stmt [48554,48609]
===
match
---
sync_comp_for [77159,77182]
sync_comp_for [77179,77202]
===
match
---
operator: == [21640,21642]
operator: == [21660,21662]
===
match
---
name: self [34782,34786]
name: self [34802,34806]
===
match
---
atom_expr [74553,74566]
atom_expr [74573,74586]
===
match
---
return_stmt [64586,66169]
return_stmt [64606,66189]
===
match
---
name: rendered_value [66616,66630]
name: rendered_value [66636,66650]
===
match
---
atom_expr [80972,80986]
atom_expr [80992,81006]
===
match
---
simple_stmt [5919,5977]
simple_stmt [5947,6005]
===
match
---
name: _key [80528,80532]
name: _key [80548,80552]
===
match
---
atom_expr [37570,37584]
atom_expr [37590,37604]
===
match
---
name: Union [3946,3951]
name: Union [3974,3979]
===
match
---
trailer [82215,82231]
trailer [82235,82251]
===
match
---
name: datetime [957,965]
name: datetime [942,950]
===
match
---
name: ignore_task_deps [38443,38459]
name: ignore_task_deps [38463,38479]
===
match
---
operator: , [1449,1450]
operator: , [1434,1435]
===
match
---
operator: , [68861,68862]
operator: , [68881,68882]
===
match
---
name: TaskInstance [26054,26066]
name: TaskInstance [26074,26086]
===
match
---
name: self [40719,40723]
name: self [40739,40743]
===
match
---
expr_stmt [29567,29627]
expr_stmt [29587,29647]
===
match
---
operator: = [21992,21993]
operator: = [22012,22013]
===
match
---
atom_expr [81363,81374]
atom_expr [81383,81394]
===
match
---
atom_expr [59588,59603]
atom_expr [59608,59623]
===
match
---
expr_stmt [56862,56878]
expr_stmt [56882,56898]
===
match
---
name: TaskFail [1960,1968]
name: TaskFail [1945,1953]
===
match
---
name: str [26495,26498]
name: str [26515,26518]
===
match
---
decorated [20995,22908]
decorated [21015,22928]
===
match
---
import_from [993,1032]
import_from [978,1017]
===
match
---
string: """Handle Failure for the TaskInstance""" [56321,56362]
string: """Handle Failure for the TaskInstance""" [56341,56382]
===
match
---
name: dep_context [38554,38565]
name: dep_context [38574,38585]
===
match
---
name: ignore_task_deps [39731,39747]
name: ignore_task_deps [39751,39767]
===
match
---
suite [52714,52864]
suite [52734,52884]
===
match
---
name: set [5134,5137]
name: set [5162,5165]
===
match
---
suite [3969,4248]
suite [3997,4276]
===
match
---
name: try_number [81010,81020]
name: try_number [81030,81040]
===
match
---
name: try_number [68586,68596]
name: try_number [68606,68616]
===
match
---
trailer [40986,40993]
trailer [41006,41013]
===
match
---
name: self [23338,23342]
name: self [23358,23362]
===
match
---
operator: = [3196,3197]
operator: = [3224,3225]
===
match
---
atom [20224,20503]
atom [20244,20523]
===
match
---
name: self [12176,12180]
name: self [12196,12200]
===
match
---
trailer [60543,60550]
trailer [60563,60570]
===
match
---
string: "--raw" [18699,18706]
string: "--raw" [18719,18726]
===
match
---
name: query [77041,77046]
name: query [77061,77066]
===
match
---
decorator [81142,81152]
decorator [81162,81172]
===
match
---
atom_expr [40861,40869]
atom_expr [40881,40889]
===
match
---
name: state [57910,57915]
name: state [57930,57935]
===
match
---
name: session [39211,39218]
name: session [39231,39238]
===
match
---
name: execution_date [78838,78852]
name: execution_date [78858,78872]
===
match
---
expr_stmt [64033,64085]
expr_stmt [64053,64105]
===
match
---
trailer [64182,64186]
trailer [64202,64206]
===
match
---
atom_expr [71076,71101]
atom_expr [71096,71121]
===
match
---
name: reschedule_exception [55652,55672]
name: reschedule_exception [55672,55692]
===
match
---
name: info [43293,43297]
name: info [43313,43317]
===
match
---
name: str [36046,36049]
name: str [36066,36069]
===
match
---
trailer [31787,31791]
trailer [31807,31811]
===
match
---
param [35799,35836]
param [35819,35856]
===
match
---
atom_expr [29577,29627]
atom_expr [29597,29647]
===
match
---
atom_expr [11704,11723]
atom_expr [11732,11751]
===
match
---
trailer [51691,51708]
trailer [51711,51728]
===
match
---
name: State [25341,25346]
name: State [25361,25366]
===
match
---
name: self [14988,14992]
name: self [15008,15012]
===
match
---
name: context [3338,3345]
name: context [3366,3373]
===
match
---
name: task_id [6875,6882]
name: task_id [6903,6910]
===
match
---
operator: = [60064,60065]
operator: = [60084,60085]
===
match
---
name: session [59068,59075]
name: session [59088,59095]
===
match
---
name: error_fd [54765,54773]
name: error_fd [54785,54793]
===
match
---
name: self [79874,79878]
name: self [79894,79898]
===
match
---
name: verbose [31800,31807]
name: verbose [31820,31827]
===
match
---
atom_expr [68885,68915]
atom_expr [68905,68935]
===
match
---
arglist [32003,32155]
arglist [32023,32175]
===
match
---
name: ti [22670,22672]
name: ti [22690,22692]
===
match
---
param [12682,12686]
param [12702,12706]
===
match
---
trailer [47613,47618]
trailer [47633,47638]
===
match
---
simple_stmt [33119,33297]
simple_stmt [33139,33317]
===
match
---
name: exception [71565,71574]
name: exception [71585,71594]
===
match
---
tfpdef [52362,52400]
tfpdef [52382,52420]
===
match
---
name: self [80303,80307]
name: self [80323,80327]
===
match
---
operator: @ [73083,73084]
operator: @ [73103,73104]
===
match
---
name: state [52882,52887]
name: state [52902,52907]
===
match
---
name: info [55999,56003]
name: info [56019,56023]
===
match
---
name: DagRun [60294,60300]
name: DagRun [60314,60320]
===
match
---
simple_stmt [18630,18659]
simple_stmt [18650,18679]
===
match
---
name: DeprecationWarning [28460,28478]
name: DeprecationWarning [28480,28498]
===
match
---
name: bool [53669,53673]
name: bool [53689,53693]
===
match
---
name: yesterday_ds_nodash [62266,62285]
name: yesterday_ds_nodash [62286,62305]
===
match
---
operator: , [44743,44744]
operator: , [44763,44764]
===
match
---
expr_stmt [40719,40740]
expr_stmt [40739,40760]
===
match
---
name: task [37536,37540]
name: task [37556,37560]
===
match
---
operator: = [71154,71155]
operator: = [71174,71175]
===
match
---
parameters [28596,28602]
parameters [28616,28622]
===
match
---
operator: , [35914,35915]
operator: , [35934,35935]
===
match
---
operator: = [39906,39907]
operator: = [39926,39927]
===
match
---
atom_expr [33313,33334]
atom_expr [33333,33354]
===
match
---
name: var [63165,63168]
name: var [63185,63188]
===
match
---
atom_expr [46084,46340]
atom_expr [46104,46360]
===
match
---
operator: , [46315,46316]
operator: , [46335,46336]
===
match
---
name: start_date [24820,24830]
name: start_date [24840,24850]
===
match
---
name: get_num_running_task_instances [77400,77430]
name: get_num_running_task_instances [77420,77450]
===
match
---
comp_op [59731,59737]
comp_op [59751,59757]
===
match
---
name: state [24775,24780]
name: state [24795,24800]
===
match
---
simple_stmt [55327,55361]
simple_stmt [55347,55381]
===
match
---
trailer [11354,11370]
trailer [11382,11398]
===
match
---
name: task [48278,48282]
name: task [48298,48302]
===
match
---
param [35152,35157]
param [35172,35177]
===
match
---
name: key [71955,71958]
name: key [71975,71978]
===
match
---
name: task_id [74264,74271]
name: task_id [74284,74291]
===
match
---
name: execution_date [35533,35547]
name: execution_date [35553,35567]
===
match
---
arglist [11560,11674]
arglist [11588,11702]
===
match
---
suite [27754,27835]
suite [27774,27855]
===
match
---
number: 1 [60871,60872]
number: 1 [60891,60892]
===
match
---
trailer [48053,48062]
trailer [48073,48082]
===
match
---
name: execution_date [41272,41286]
name: execution_date [41292,41306]
===
match
---
if_stmt [57843,58335]
if_stmt [57863,58355]
===
match
---
name: deps [39580,39584]
name: deps [39600,39604]
===
match
---
string: 'task' [65566,65572]
string: 'task' [65586,65592]
===
match
---
name: local [15288,15293]
name: local [15308,15313]
===
match
---
trailer [56918,56920]
trailer [56938,56940]
===
match
---
operator: = [52806,52807]
operator: = [52826,52827]
===
match
---
operator: , [8275,8276]
operator: , [8303,8304]
===
match
---
name: dag_run [61209,61216]
name: dag_run [61229,61236]
===
match
---
name: self [68499,68503]
name: self [68519,68523]
===
match
---
name: prev_ds [65099,65106]
name: prev_ds [65119,65126]
===
match
---
simple_stmt [47459,47528]
simple_stmt [47479,47548]
===
match
---
param [63065,63075]
param [63085,63095]
===
match
---
trailer [77748,77754]
trailer [77768,77774]
===
match
---
name: self [43853,43857]
name: self [43873,43877]
===
match
---
simple_stmt [79566,79618]
simple_stmt [79586,79638]
===
match
---
number: 2 [29023,29024]
number: 2 [29043,29044]
===
match
---
if_stmt [78639,78934]
if_stmt [78659,78954]
===
match
---
simple_stmt [82284,82319]
simple_stmt [82304,82339]
===
match
---
trailer [66683,66700]
trailer [66703,66720]
===
match
---
operator: , [10860,10861]
operator: , [10888,10889]
===
match
---
param [8602,8617]
param [8630,8645]
===
match
---
name: items [49385,49390]
name: items [49405,49410]
===
match
---
import_from [66276,66346]
import_from [66296,66366]
===
match
---
name: tis [79477,79480]
name: tis [79497,79500]
===
match
---
name: ignore_ti_state [38331,38346]
name: ignore_ti_state [38351,38366]
===
match
---
name: strftime [61662,61670]
name: strftime [61682,61690]
===
match
---
name: start_date [72876,72886]
name: start_date [72896,72906]
===
match
---
string: """         Construct a TaskInstance from the database based on the primary key          :param session: DB session.         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :return: the task instance constructed         """ [81658,82017]
string: """         Construct a TaskInstance from the database based on the primary key          :param session: DB session.         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :return: the task instance constructed         """ [81678,82037]
===
match
---
operator: = [14198,14199]
operator: = [14218,14219]
===
match
---
simple_stmt [2562,2605]
simple_stmt [2547,2590]
===
match
---
operator: } [50670,50671]
operator: } [50690,50691]
===
match
---
param [55149,55167]
param [55169,55187]
===
match
---
and_test [59566,59621]
and_test [59586,59641]
===
match
---
name: include_upstream [46789,46805]
name: include_upstream [46809,46825]
===
match
---
atom_expr [29181,29194]
atom_expr [29201,29214]
===
match
---
trailer [68896,68915]
trailer [68916,68935]
===
match
---
name: include_prior_dates [76628,76647]
name: include_prior_dates [76648,76667]
===
match
---
simple_stmt [42784,42805]
simple_stmt [42804,42825]
===
match
---
operator: = [49544,49545]
operator: = [49564,49565]
===
match
---
name: prev_ds [61988,61995]
name: prev_ds [62008,62015]
===
match
---
name: init_on_load [12181,12193]
name: init_on_load [12201,12213]
===
match
---
trailer [45387,45401]
trailer [45407,45421]
===
match
---
expr_stmt [37570,37596]
expr_stmt [37590,37616]
===
match
---
simple_stmt [19082,19141]
simple_stmt [19102,19161]
===
match
---
param [30990,31007]
param [31010,31027]
===
match
---
sync_comp_for [7787,7800]
sync_comp_for [7815,7828]
===
match
---
name: dirname [71084,71091]
name: dirname [71104,71111]
===
match
---
string: 'task_instance_key_str' [65627,65650]
string: 'task_instance_key_str' [65647,65670]
===
match
---
name: Context [3188,3195]
name: Context [3216,3223]
===
match
---
testlist_comp [44817,44845]
testlist_comp [44837,44865]
===
match
---
name: State [55756,55761]
name: State [55776,55781]
===
match
---
operator: -> [21079,21081]
operator: -> [21099,21101]
===
match
---
name: execution_date [62152,62166]
name: execution_date [62172,62186]
===
match
---
operator: = [53475,53476]
operator: = [53495,53496]
===
match
---
simple_stmt [54369,54412]
simple_stmt [54389,54432]
===
match
---
name: kubernetes_helper_functions [3015,3042]
name: kubernetes_helper_functions [3043,3070]
===
match
---
not_test [68168,68179]
not_test [68188,68199]
===
match
---
name: key [76532,76535]
name: key [76552,76555]
===
match
---
suite [59497,59622]
suite [59517,59642]
===
match
---
simple_stmt [60260,60326]
simple_stmt [60280,60346]
===
match
---
operator: , [59349,59350]
operator: , [59369,59370]
===
match
---
simple_stmt [58297,58335]
simple_stmt [58317,58355]
===
match
---
not_test [67421,67442]
not_test [67441,67462]
===
match
---
expr_stmt [82583,82626]
expr_stmt [82603,82646]
===
match
---
argument [43162,43182]
argument [43182,43202]
===
match
---
trailer [19033,19073]
trailer [19053,19093]
===
match
---
operator: , [4716,4717]
operator: , [4744,4745]
===
match
---
name: attr [41440,41444]
name: attr [41460,41464]
===
match
---
name: Optional [16058,16066]
name: Optional [16078,16086]
===
match
---
operator: = [49171,49172]
operator: = [49191,49192]
===
match
---
name: Index [10843,10848]
name: Index [10871,10876]
===
match
---
except_clause [4151,4167]
except_clause [4179,4195]
===
match
---
string: 'yesterday_ds' [66074,66088]
string: 'yesterday_ds' [66094,66108]
===
match
---
simple_stmt [22060,22088]
simple_stmt [22080,22108]
===
match
---
name: log [20852,20855]
name: log [20872,20875]
===
match
---
param [73230,73254]
param [73250,73274]
===
match
---
operator: - [5593,5594]
operator: - [5621,5622]
===
match
---
trailer [19106,19113]
trailer [19126,19133]
===
match
---
name: add [45532,45535]
name: add [45552,45555]
===
match
---
trailer [49384,49390]
trailer [49404,49410]
===
match
---
import_from [2877,2927]
import_from [2905,2955]
===
match
---
name: log [31818,31821]
name: log [31838,31841]
===
match
---
trailer [39172,39196]
trailer [39192,39216]
===
match
---
expr_stmt [3150,3166]
expr_stmt [3178,3194]
===
match
---
trailer [28551,28553]
trailer [28571,28573]
===
match
---
name: job_id [41773,41779]
name: job_id [41793,41799]
===
match
---
simple_stmt [30142,30203]
simple_stmt [30162,30223]
===
match
---
name: self [33924,33928]
name: self [33944,33948]
===
match
---
name: task_id [6117,6124]
name: task_id [6145,6152]
===
match
---
suite [21808,21856]
suite [21828,21876]
===
match
---
trailer [66700,66702]
trailer [66720,66722]
===
match
---
name: execution_date [79115,79129]
name: execution_date [79135,79149]
===
match
---
import_name [900,915]
import_name [885,900]
===
match
---
name: self [11794,11798]
name: self [11822,11826]
===
match
---
trailer [60790,60793]
trailer [60810,60813]
===
match
---
atom_expr [21718,21745]
atom_expr [21738,21765]
===
match
---
name: register_in_sensor_service [49868,49894]
name: register_in_sensor_service [49888,49914]
===
match
---
trailer [11530,11534]
trailer [11558,11562]
===
match
---
simple_stmt [71444,71488]
simple_stmt [71464,71508]
===
match
---
param [41889,41902]
param [41909,41922]
===
match
---
name: hasattr [41458,41465]
name: hasattr [41478,41485]
===
match
---
atom_expr [9677,9696]
atom_expr [9705,9724]
===
match
---
operator: , [74303,74304]
operator: , [74323,74324]
===
match
---
name: get_dagrun [35141,35151]
name: get_dagrun [35161,35171]
===
match
---
number: 1 [70903,70904]
number: 1 [70923,70924]
===
match
---
name: get_template_context [68208,68228]
name: get_template_context [68228,68248]
===
match
---
string: "--pool" [18642,18650]
string: "--pool" [18662,18670]
===
match
---
name: state [26286,26291]
name: state [26306,26311]
===
match
---
operator: @ [55099,55100]
operator: @ [55119,55120]
===
match
---
expr_stmt [20531,20550]
expr_stmt [20551,20570]
===
match
---
trailer [55672,55688]
trailer [55692,55708]
===
match
---
parameters [53399,53817]
parameters [53419,53837]
===
match
---
name: str [59180,59183]
name: str [59200,59203]
===
match
---
trailer [22651,22667]
trailer [22671,22687]
===
match
---
simple_stmt [60101,60113]
simple_stmt [60121,60133]
===
match
---
name: test_mode [55190,55199]
name: test_mode [55210,55219]
===
match
---
simple_stmt [22701,22729]
simple_stmt [22721,22749]
===
match
---
atom_expr [61712,61736]
atom_expr [61732,61756]
===
match
---
simple_stmt [952,993]
simple_stmt [937,978]
===
match
---
name: session [4722,4729]
name: session [4750,4757]
===
match
---
trailer [32244,32281]
trailer [32264,32301]
===
match
---
return_stmt [27256,27331]
return_stmt [27276,27351]
===
match
---
name: _dag_id [80646,80653]
name: _dag_id [80666,80673]
===
match
---
name: timezone [11869,11877]
name: timezone [11897,11905]
===
match
---
simple_stmt [4121,4147]
simple_stmt [4149,4175]
===
match
---
operator: , [64738,64739]
operator: , [64758,64759]
===
match
---
name: self [81194,81198]
name: self [81214,81218]
===
match
---
param [73159,73170]
param [73179,73190]
===
match
---
simple_stmt [26372,26418]
simple_stmt [26392,26438]
===
match
---
operator: , [71635,71636]
operator: , [71655,71656]
===
match
---
trailer [46655,46670]
trailer [46675,46690]
===
match
---
atom_expr [12074,12091]
atom_expr [12102,12111]
===
match
---
simple_stmt [80113,80161]
simple_stmt [80133,80181]
===
match
---
name: Exception [44817,44826]
name: Exception [44837,44846]
===
match
---
name: datetime [80947,80955]
name: datetime [80967,80975]
===
match
---
operator: , [64061,64062]
operator: , [64081,64082]
===
match
---
trailer [53270,53272]
trailer [53290,53292]
===
match
---
name: ignore_task_deps [14144,14160]
name: ignore_task_deps [14164,14180]
===
match
---
name: task [23499,23503]
name: task [23519,23523]
===
match
---
string: "worker-config" [68846,68861]
string: "worker-config" [68866,68881]
===
match
---
name: self [30883,30887]
name: self [30903,30907]
===
match
---
name: encode [33991,33997]
name: encode [34011,34017]
===
match
---
comparison [52877,52904]
comparison [52897,52924]
===
match
---
trailer [45531,45535]
trailer [45551,45555]
===
match
---
trailer [19531,19546]
trailer [19551,19566]
===
match
---
name: pre_execute [49525,49536]
name: pre_execute [49545,49556]
===
match
---
fstring_string:   [33035,33036]
fstring_string:   [33055,33056]
===
match
---
return_stmt [4121,4146]
return_stmt [4149,4174]
===
match
---
simple_stmt [31938,31952]
simple_stmt [31958,31972]
===
match
---
number: 1 [50677,50678]
number: 1 [50697,50698]
===
match
---
simple_stmt [22020,22048]
simple_stmt [22040,22068]
===
match
---
trailer [71543,71752]
trailer [71563,71772]
===
match
---
operator: , [6940,6941]
operator: , [6968,6969]
===
match
---
simple_stmt [55311,55318]
simple_stmt [55331,55338]
===
match
---
atom_expr [68678,68697]
atom_expr [68698,68717]
===
match
---
name: self [28531,28535]
name: self [28551,28555]
===
match
---
trailer [71464,71485]
trailer [71484,71505]
===
match
---
name: dag [14810,14813]
name: dag [14830,14833]
===
match
---
operator: , [21768,21769]
operator: , [21788,21789]
===
match
---
name: self [45540,45544]
name: self [45560,45564]
===
match
---
name: priority_weight [22673,22688]
name: priority_weight [22693,22708]
===
match
---
decorator [13328,13338]
decorator [13348,13358]
===
match
---
name: models [1841,1847]
name: models [1826,1832]
===
match
---
trailer [35088,35090]
trailer [35108,35110]
===
match
---
param [48365,48372]
param [48385,48392]
===
match
---
simple_stmt [23678,23842]
simple_stmt [23698,23862]
===
match
---
simple_stmt [1162,1176]
simple_stmt [1147,1161]
===
match
---
name: datetime [80864,80872]
name: datetime [80884,80892]
===
match
---
operator: , [40809,40810]
operator: , [40829,40830]
===
match
---
trailer [24337,24352]
trailer [24357,24372]
===
match
---
expr_stmt [30142,30202]
expr_stmt [30162,30222]
===
match
---
operator: == [78780,78782]
operator: == [78800,78802]
===
match
---
simple_stmt [31687,31729]
simple_stmt [31707,31749]
===
match
---
string: "task_instance" [9439,9454]
string: "task_instance" [9467,9482]
===
match
---
argument [10405,10421]
argument [10433,10449]
===
match
---
operator: , [55603,55604]
operator: , [55623,55624]
===
match
---
name: default_var [63567,63578]
name: default_var [63587,63598]
===
match
---
operator: -> [81633,81635]
operator: -> [81653,81655]
===
match
---
expr_stmt [7882,7906]
expr_stmt [7910,7934]
===
match
---
atom_expr [22432,22443]
atom_expr [22452,22463]
===
match
---
trailer [50660,50670]
trailer [50680,50690]
===
match
---
atom_expr [74350,74369]
atom_expr [74370,74389]
===
match
---
arglist [43662,43991]
arglist [43682,44011]
===
match
---
suite [41538,41593]
suite [41558,41613]
===
match
---
dictorsetmaker [47059,47190]
dictorsetmaker [47079,47210]
===
match
---
name: duration [24999,25007]
name: duration [25019,25027]
===
match
---
trailer [11721,11723]
trailer [11749,11751]
===
match
---
except_clause [43328,43360]
except_clause [43348,43380]
===
match
---
atom_expr [30298,30316]
atom_expr [30318,30336]
===
match
---
string: """Filepath for TaskInstance""" [18919,18950]
string: """Filepath for TaskInstance""" [18939,18970]
===
match
---
name: log [52305,52308]
name: log [52325,52328]
===
match
---
suite [68335,69160]
suite [68355,69180]
===
match
---
atom_expr [60618,60634]
atom_expr [60638,60654]
===
match
---
trailer [80057,80068]
trailer [80077,80088]
===
match
---
decorated [28075,28554]
decorated [28095,28574]
===
match
---
name: local [18558,18563]
name: local [18578,18583]
===
match
---
param [53798,53811]
param [53818,53831]
===
match
---
operator: , [54553,54554]
operator: , [54573,54574]
===
match
---
name: Column [10048,10054]
name: Column [10076,10082]
===
match
---
operator: { [47037,47038]
operator: { [47057,47058]
===
match
---
simple_stmt [28524,28554]
simple_stmt [28544,28574]
===
match
---
name: provide_session [19855,19870]
name: provide_session [19875,19890]
===
match
---
fstring_expr [49347,49350]
fstring_expr [49367,49370]
===
match
---
atom_expr [19116,19128]
atom_expr [19136,19148]
===
match
---
atom_expr [44120,44195]
atom_expr [44140,44215]
===
match
---
suite [59743,59784]
suite [59763,59804]
===
match
---
simple_stmt [51042,51125]
simple_stmt [51062,51145]
===
match
---
param [35924,35951]
param [35944,35971]
===
match
---
arglist [10849,10868]
arglist [10877,10896]
===
match
---
name: exception_html [71606,71620]
name: exception_html [71626,71640]
===
match
---
simple_stmt [20577,20590]
simple_stmt [20597,20610]
===
match
---
name: session [39907,39914]
name: session [39927,39934]
===
match
---
name: self [49605,49609]
name: self [49625,49629]
===
match
---
operator: , [69508,69509]
operator: , [69528,69529]
===
match
---
name: Variable [64349,64357]
name: Variable [64369,64377]
===
match
---
comparison [26379,26417]
comparison [26399,26437]
===
match
---
name: task [23356,23360]
name: task [23376,23380]
===
match
---
trailer [10109,10122]
trailer [10137,10150]
===
match
---
name: e [44885,44886]
name: e [44905,44906]
===
match
---
expr_stmt [59673,59712]
expr_stmt [59693,59732]
===
match
---
suite [51580,51639]
suite [51600,51659]
===
match
---
arith_expr [34613,34646]
arith_expr [34633,34666]
===
match
---
name: key [24172,24175]
name: key [24192,24195]
===
match
---
trailer [22078,22087]
trailer [22098,22107]
===
match
---
name: session [20238,20245]
name: session [20258,20265]
===
match
---
trailer [24044,24059]
trailer [24064,24079]
===
match
---
trailer [30436,30445]
trailer [30456,30465]
===
match
---
string: 'task' [69448,69454]
string: 'task' [69468,69474]
===
match
---
trailer [60045,60047]
trailer [60065,60067]
===
match
---
name: filter [23915,23921]
name: filter [23935,23941]
===
match
---
name: start_date [50906,50916]
name: start_date [50926,50936]
===
match
---
operator: } [44662,44663]
operator: } [44682,44683]
===
match
---
operator: , [61731,61732]
operator: , [61751,61752]
===
match
---
atom_expr [45317,45354]
atom_expr [45337,45374]
===
match
---
name: session [55431,55438]
name: session [55451,55458]
===
match
---
operator: = [3171,3172]
operator: = [3199,3200]
===
match
---
decorator [18873,18883]
decorator [18893,18903]
===
match
---
atom_expr [72871,72886]
atom_expr [72891,72906]
===
match
---
trailer [66559,66565]
trailer [66579,66585]
===
match
---
operator: , [10926,10927]
operator: , [10954,10955]
===
match
---
parameters [69194,69211]
parameters [69214,69231]
===
match
---
operator: , [41763,41764]
operator: , [41783,41784]
===
match
---
fstring_string: / [19129,19130]
fstring_string: / [19149,19150]
===
match
---
trailer [47518,47526]
trailer [47538,47546]
===
match
---
name: self [57864,57868]
name: self [57884,57888]
===
match
---
name: log [47610,47613]
name: log [47630,47633]
===
match
---
expr_stmt [20577,20589]
expr_stmt [20597,20609]
===
match
---
trailer [56003,56059]
trailer [56023,56079]
===
match
---
arglist [4447,4456]
arglist [4475,4484]
===
match
---
trailer [8493,8570]
trailer [8521,8598]
===
match
---
trailer [4659,4664]
trailer [4687,4692]
===
match
---
trailer [15884,15889]
trailer [15904,15909]
===
match
---
if_stmt [27949,28049]
if_stmt [27969,28069]
===
match
---
name: Any [73166,73169]
name: Any [73186,73189]
===
match
---
tfpdef [15521,15532]
tfpdef [15541,15552]
===
match
---
expr_stmt [80303,80328]
expr_stmt [80323,80348]
===
match
---
atom_expr [64640,64648]
atom_expr [64660,64668]
===
match
---
trailer [44974,44979]
trailer [44994,44999]
===
match
---
simple_stmt [25139,25255]
simple_stmt [25159,25275]
===
match
---
suite [62964,62997]
suite [62984,63017]
===
match
---
suite [40938,40971]
suite [40958,40991]
===
match
---
trailer [13982,13994]
trailer [14002,14014]
===
match
---
name: String [1341,1347]
name: String [1326,1332]
===
match
---
atom_expr [80460,80478]
atom_expr [80480,80498]
===
match
---
name: schedulable_tis [47572,47587]
name: schedulable_tis [47592,47607]
===
match
---
name: queue [81328,81333]
name: queue [81348,81353]
===
match
---
name: pool [53762,53766]
name: pool [53782,53786]
===
match
---
operator: = [53805,53806]
operator: = [53825,53826]
===
match
---
name: settings [41103,41111]
name: settings [41123,41131]
===
match
---
trailer [45128,45457]
trailer [45148,45477]
===
match
---
name: self [67497,67501]
name: self [67517,67521]
===
match
---
operator: -> [80691,80693]
operator: -> [80711,80713]
===
match
---
simple_stmt [22976,23251]
simple_stmt [22996,23271]
===
match
---
dictorsetmaker [7699,7722]
dictorsetmaker [7727,7750]
===
match
---
funcdef [30378,30933]
funcdef [30398,30953]
===
match
---
annassign [79847,79865]
annassign [79867,79885]
===
match
---
expr_stmt [61908,61958]
expr_stmt [61928,61978]
===
match
---
string: """     Simplified Task Instance.      Used to send data between processes via Queues.     """ [79650,79744]
string: """     Simplified Task Instance.      Used to send data between processes via Queues.     """ [79670,79764]
===
match
---
suite [51652,51709]
suite [51672,51729]
===
match
---
string: 'macros' [64857,64865]
string: 'macros' [64877,64885]
===
match
---
name: try_number [80058,80068]
name: try_number [80078,80088]
===
match
---
name: result [59724,59730]
name: result [59744,59750]
===
match
---
operator: = [22960,22961]
operator: = [22980,22981]
===
match
---
operator: , [49357,49358]
operator: , [49377,49378]
===
match
---
name: TaskInstanceKey [8478,8493]
name: TaskInstanceKey [8506,8521]
===
match
---
atom_expr [78949,78957]
atom_expr [78969,78977]
===
match
---
atom_expr [23499,23511]
atom_expr [23519,23531]
===
match
---
name: dag_id [8269,8275]
name: dag_id [8297,8303]
===
match
---
operator: = [61551,61552]
operator: = [61571,61572]
===
match
---
operator: = [9675,9676]
operator: = [9703,9704]
===
match
---
name: self [24333,24337]
name: self [24353,24357]
===
match
---
name: start_date [21981,21991]
name: start_date [22001,22011]
===
match
---
name: execution_date [7046,7060]
name: execution_date [7074,7088]
===
match
---
arglist [41336,41388]
arglist [41356,41408]
===
match
---
param [59167,59196]
param [59187,59216]
===
match
---
operator: , [24317,24318]
operator: , [24337,24338]
===
match
---
name: task_ids [77174,77182]
name: task_ids [77194,77202]
===
match
---
trailer [50655,50660]
trailer [50675,50680]
===
match
---
trailer [22835,22841]
trailer [22855,22861]
===
match
---
name: _handle_reschedule [44125,44143]
name: _handle_reschedule [44145,44163]
===
match
---
parameters [24410,24442]
parameters [24430,24462]
===
match
---
trailer [7884,7890]
trailer [7912,7918]
===
match
---
sliceop [82428,82431]
sliceop [82448,82451]
===
match
---
atom_expr [44969,45035]
atom_expr [44989,45055]
===
match
---
name: jinja_env [71156,71165]
name: jinja_env [71176,71185]
===
match
---
simple_stmt [80707,80728]
simple_stmt [80727,80748]
===
match
---
atom_expr [10390,10422]
atom_expr [10418,10450]
===
match
---
suite [51477,51542]
suite [51497,51562]
===
match
---
operator: @ [29702,29703]
operator: @ [29722,29723]
===
match
---
expr_stmt [79834,79865]
expr_stmt [79854,79885]
===
match
---
expr_stmt [23438,23473]
expr_stmt [23458,23493]
===
match
---
argument [30173,30184]
argument [30193,30204]
===
match
---
name: kubernetes [2946,2956]
name: kubernetes [2974,2984]
===
match
---
suite [72979,73013]
suite [72999,73033]
===
match
---
operator: , [49394,49395]
operator: , [49414,49415]
===
match
---
name: self [45656,45660]
name: self [45676,45680]
===
match
---
atom [44816,44846]
atom [44836,44866]
===
match
---
name: self [81125,81129]
name: self [81145,81149]
===
match
---
dictorsetmaker [64607,66159]
dictorsetmaker [64627,66179]
===
match
---
name: dag_id [21633,21639]
name: dag_id [21653,21659]
===
match
---
trailer [79301,79308]
trailer [79321,79328]
===
match
---
name: self [59853,59857]
name: self [59873,59877]
===
match
---
name: executor_namespace [68897,68915]
name: executor_namespace [68917,68935]
===
match
---
simple_stmt [64586,66170]
simple_stmt [64606,66190]
===
match
---
atom_expr [53014,53041]
atom_expr [53034,53061]
===
match
---
name: task [42922,42926]
name: task [42942,42946]
===
match
---
if_stmt [7488,7953]
if_stmt [7516,7981]
===
match
---
simple_stmt [52731,52769]
simple_stmt [52751,52789]
===
match
---
operator: = [40870,40871]
operator: = [40890,40891]
===
match
---
name: quote [1143,1148]
name: quote [1128,1133]
===
match
---
operator: = [33311,33312]
operator: = [33331,33332]
===
match
---
arith_expr [13212,13232]
arith_expr [13232,13252]
===
match
---
simple_stmt [13933,13963]
simple_stmt [13953,13983]
===
match
---
tfpdef [53691,53706]
tfpdef [53711,53726]
===
match
---
operator: = [79960,79961]
operator: = [79980,79981]
===
match
---
trailer [51606,51614]
trailer [51626,51634]
===
match
---
string: 'ti_successes' [50699,50713]
string: 'ti_successes' [50719,50733]
===
match
---
simple_stmt [68240,68282]
simple_stmt [68260,68302]
===
match
---
operator: = [22758,22759]
operator: = [22778,22779]
===
match
---
param [74585,74614]
param [74605,74634]
===
match
---
expr_stmt [78414,78443]
expr_stmt [78434,78463]
===
match
---
operator: = [29195,29196]
operator: = [29215,29216]
===
match
---
name: self [30152,30156]
name: self [30172,30176]
===
match
---
operator: , [1741,1742]
operator: , [1726,1727]
===
match
---
name: and_ [79267,79271]
name: and_ [79287,79291]
===
match
---
name: self [56114,56118]
name: self [56134,56138]
===
match
---
atom_expr [78738,78933]
atom_expr [78758,78953]
===
match
---
name: AirflowTaskTimeout [1806,1824]
name: AirflowTaskTimeout [1791,1809]
===
match
---
name: self [65302,65306]
name: self [65322,65326]
===
match
---
import_from [2380,2414]
import_from [2365,2399]
===
match
---
simple_stmt [76936,77101]
simple_stmt [76956,77121]
===
match
---
name: query [21580,21585]
name: query [21600,21605]
===
match
---
atom_expr [33945,33960]
atom_expr [33965,33980]
===
match
---
simple_stmt [33645,33728]
simple_stmt [33665,33748]
===
match
---
name: TaskInstance [82631,82643]
name: TaskInstance [82651,82663]
===
match
---
name: Column [9968,9974]
name: Column [9996,10002]
===
match
---
atom_expr [61918,61958]
atom_expr [61938,61978]
===
match
---
simple_stmt [5240,5266]
simple_stmt [5268,5294]
===
match
---
trailer [60732,60734]
trailer [60752,60754]
===
match
---
name: mark_success [54473,54485]
name: mark_success [54493,54505]
===
match
---
name: job_id [54540,54546]
name: job_id [54560,54566]
===
match
---
operator: = [13315,13316]
operator: = [13335,13336]
===
match
---
name: max_retry_delay [34792,34807]
name: max_retry_delay [34812,34827]
===
match
---
name: self [27281,27285]
name: self [27301,27305]
===
match
---
name: State [40839,40844]
name: State [40859,40864]
===
match
---
name: with_for_update [21830,21845]
name: with_for_update [21850,21865]
===
match
---
trailer [44884,44921]
trailer [44904,44941]
===
match
---
name: write [48913,48918]
name: write [48933,48938]
===
match
---
trailer [78890,78894]
trailer [78910,78914]
===
match
---
name: set_duration [45471,45483]
name: set_duration [45491,45503]
===
match
---
simple_stmt [48266,48307]
simple_stmt [48286,48327]
===
match
---
operator: = [80094,80095]
operator: = [80114,80115]
===
match
---
name: Column [9677,9683]
name: Column [9705,9711]
===
match
---
trailer [82426,82432]
trailer [82446,82452]
===
match
---
param [20653,20665]
param [20673,20685]
===
match
---
operator: , [15425,15426]
operator: , [15445,15446]
===
match
---
operator: , [47975,47976]
operator: , [47995,47996]
===
match
---
atom_expr [23438,23454]
atom_expr [23458,23474]
===
match
---
atom_expr [32833,32850]
atom_expr [32853,32870]
===
match
---
atom_expr [19387,19399]
atom_expr [19407,19419]
===
match
---
comparison [23935,23961]
comparison [23955,23981]
===
match
---
atom_expr [40872,40883]
atom_expr [40892,40903]
===
match
---
and_test [73910,73965]
and_test [73930,73985]
===
match
---
atom_expr [8494,8505]
atom_expr [8522,8533]
===
match
---
name: macros [64867,64873]
name: macros [64887,64893]
===
match
---
name: prev_ds_nodash [65138,65152]
name: prev_ds_nodash [65158,65172]
===
match
---
name: get_email_subject_content [72569,72594]
name: get_email_subject_content [72589,72614]
===
match
---
name: first [78308,78313]
name: first [78328,78333]
===
match
---
name: max_tries [71709,71718]
name: max_tries [71729,71738]
===
match
---
atom_expr [31813,31827]
atom_expr [31833,31847]
===
match
---
operator: , [58684,58685]
operator: , [58704,58705]
===
match
---
name: property [81143,81151]
name: property [81163,81171]
===
match
---
arglist [10793,10832]
arglist [10821,10860]
===
match
---
operator: == [23947,23949]
operator: == [23967,23969]
===
match
---
trailer [78819,78834]
trailer [78839,78854]
===
match
---
if_stmt [78942,79235]
if_stmt [78962,79255]
===
match
---
trailer [11310,11316]
trailer [11338,11344]
===
match
---
trailer [4024,4029]
trailer [4052,4057]
===
match
---
name: self [55042,55046]
name: self [55062,55066]
===
match
---
name: __file__ [71092,71100]
name: __file__ [71112,71120]
===
match
---
name: state [27644,27649]
name: state [27664,27669]
===
match
---
operator: - [60779,60780]
operator: - [60799,60800]
===
match
---
atom_expr [50973,50989]
atom_expr [50993,51009]
===
match
---
name: self [56887,56891]
name: self [56907,56911]
===
match
---
if_stmt [39841,40517]
if_stmt [39861,40537]
===
match
---
name: dag_id [78773,78779]
name: dag_id [78793,78799]
===
match
---
operator: = [72914,72915]
operator: = [72934,72935]
===
match
---
exprlist [49356,49360]
exprlist [49376,49380]
===
match
---
name: airflow [2420,2427]
name: airflow [2405,2412]
===
match
---
operator: , [38264,38265]
operator: , [38284,38285]
===
match
---
name: get [19039,19042]
name: get [19059,19062]
===
match
---
operator: = [5562,5563]
operator: = [5590,5591]
===
match
---
suite [32189,32215]
suite [32209,32235]
===
match
---
trailer [6842,6897]
trailer [6870,6925]
===
match
---
trailer [11197,11204]
trailer [11225,11232]
===
match
---
trailer [59053,59059]
trailer [59073,59079]
===
match
---
name: error_file [44899,44909]
name: error_file [44919,44929]
===
match
---
string: """Get failed Dependencies""" [32403,32432]
string: """Get failed Dependencies""" [32423,32452]
===
match
---
atom_expr [10110,10121]
atom_expr [10138,10149]
===
match
---
dotted_name [2677,2698]
dotted_name [2705,2726]
===
match
---
trailer [7274,7286]
trailer [7302,7314]
===
match
---
trailer [56833,56852]
trailer [56853,56872]
===
match
---
name: replace [62241,62248]
name: replace [62261,62268]
===
match
---
name: State [35041,35046]
name: State [35061,35066]
===
match
---
suite [52905,53092]
suite [52925,53112]
===
match
---
operator: { [62431,62432]
operator: { [62451,62452]
===
match
---
trailer [49440,49462]
trailer [49460,49482]
===
match
---
atom_expr [11288,11316]
atom_expr [11316,11344]
===
match
---
name: getpid [40875,40881]
name: getpid [40895,40901]
===
match
---
argument [64529,64552]
argument [64549,64572]
===
match
---
trailer [56516,56520]
trailer [56536,56540]
===
match
---
name: conf [45836,45840]
name: conf [45856,45860]
===
match
---
name: error_file [41847,41857]
name: error_file [41867,41877]
===
match
---
operator: , [54049,54050]
operator: , [54069,54070]
===
match
---
simple_stmt [49605,49647]
simple_stmt [49625,49667]
===
match
---
simple_stmt [61543,61558]
simple_stmt [61563,61578]
===
match
---
trailer [43113,43128]
trailer [43133,43148]
===
match
---
name: context [50585,50592]
name: context [50605,50612]
===
match
---
atom_expr [56819,56852]
atom_expr [56839,56872]
===
match
---
atom_expr [46236,46255]
atom_expr [46256,46275]
===
match
---
name: state [55748,55753]
name: state [55768,55773]
===
match
---
tfpdef [29766,29786]
tfpdef [29786,29806]
===
match
---
operator: , [68738,68739]
operator: , [68758,68759]
===
match
---
param [15580,15593]
param [15600,15613]
===
match
---
name: reschedule_date [55673,55688]
name: reschedule_date [55693,55708]
===
match
---
operator: = [31699,31700]
operator: = [31719,31720]
===
match
---
argument [11050,11064]
argument [11078,11092]
===
match
---
arith_expr [19628,19848]
arith_expr [19648,19868]
===
match
---
name: path [19018,19022]
name: path [19038,19042]
===
match
---
argument [68525,68572]
argument [68545,68592]
===
match
---
name: session [20973,20980]
name: session [20993,21000]
===
match
---
name: self [24994,24998]
name: self [25014,25018]
===
match
---
name: e [44431,44432]
name: e [44451,44452]
===
match
---
name: __init__ [11081,11089]
name: __init__ [11109,11117]
===
match
---
atom_expr [16018,16031]
atom_expr [16038,16051]
===
match
---
if_stmt [82252,82362]
if_stmt [82272,82382]
===
match
---
name: task_id [5437,5444]
name: task_id [5465,5472]
===
match
---
atom_expr [19527,19558]
atom_expr [19547,19578]
===
match
---
atom_expr [63229,63237]
atom_expr [63249,63257]
===
match
---
name: _end_date [80977,80986]
name: _end_date [80997,81006]
===
match
---
not_test [27178,27205]
not_test [27198,27225]
===
match
---
operator: , [30856,30857]
operator: , [30876,30877]
===
match
---
atom_expr [6023,6040]
atom_expr [6051,6068]
===
match
---
param [15906,15938]
param [15926,15958]
===
match
---
trailer [71075,71102]
trailer [71095,71122]
===
match
---
name: primary [8142,8149]
name: primary [8170,8177]
===
match
---
operator: , [14103,14104]
operator: , [14123,14124]
===
match
---
operator: , [15787,15788]
operator: , [15807,15808]
===
match
---
name: task [23457,23461]
name: task [23477,23481]
===
match
---
name: taskreschedule [1989,2003]
name: taskreschedule [1974,1988]
===
match
---
trailer [7232,7238]
trailer [7260,7266]
===
match
---
arglist [9549,9599]
arglist [9577,9627]
===
match
---
string: """URL to mark TI success""" [19478,19506]
string: """URL to mark TI success""" [19498,19526]
===
match
---
trailer [27713,27721]
trailer [27733,27741]
===
match
---
name: set_duration [56934,56946]
name: set_duration [56954,56966]
===
match
---
name: priority_weight [10817,10832]
name: priority_weight [10845,10860]
===
match
---
name: task [52930,52934]
name: task [52950,52954]
===
match
---
name: self [23438,23442]
name: self [23458,23462]
===
match
---
argument [10936,10988]
argument [10964,11016]
===
match
---
param [31008,31021]
param [31028,31041]
===
match
---
trailer [55438,55442]
trailer [55458,55462]
===
match
---
trailer [32530,32535]
trailer [32550,32555]
===
match
---
trailer [21696,21704]
trailer [21716,21724]
===
match
---
atom_expr [71246,71313]
atom_expr [71266,71333]
===
match
---
param [56242,56275]
param [56262,56295]
===
match
---
name: data [4050,4054]
name: data [4078,4082]
===
match
---
suite [81427,81453]
suite [81447,81473]
===
match
---
operator: = [39923,39924]
operator: = [39943,39944]
===
match
---
parameters [52355,52408]
parameters [52375,52428]
===
match
---
name: Optional [15982,15990]
name: Optional [16002,16010]
===
match
---
name: include_prior_dates [74659,74678]
name: include_prior_dates [74679,74698]
===
match
---
operator: = [11867,11868]
operator: = [11895,11896]
===
match
---
trailer [78390,78405]
trailer [78410,78425]
===
match
---
name: RenderedTaskInstanceFields [48886,48912]
name: RenderedTaskInstanceFields [48906,48932]
===
match
---
simple_stmt [2672,2722]
simple_stmt [2700,2750]
===
match
---
atom_expr [70885,70900]
atom_expr [70905,70920]
===
match
---
param [59153,59158]
param [59173,59178]
===
match
---
trailer [22460,22469]
trailer [22480,22489]
===
match
---
name: log [3714,3717]
name: log [3742,3745]
===
match
---
atom_expr [79933,79949]
atom_expr [79953,79969]
===
match
---
argument [6630,7178]
argument [6658,7206]
===
match
---
name: kube_image [68649,68659]
name: kube_image [68669,68679]
===
match
---
atom_expr [53732,53745]
atom_expr [53752,53765]
===
match
---
name: task_ids [47114,47122]
name: task_ids [47134,47142]
===
match
---
name: pool [80324,80328]
name: pool [80344,80348]
===
match
---
trailer [14712,14721]
trailer [14732,14741]
===
match
---
import_as_names [1436,1463]
import_as_names [1421,1448]
===
match
---
comparison [20355,20391]
comparison [20375,20411]
===
match
---
name: Integer [9874,9881]
name: Integer [9902,9909]
===
match
---
trailer [21980,21991]
trailer [22000,22011]
===
match
---
trailer [71392,71399]
trailer [71412,71419]
===
match
---
name: t [79134,79135]
name: t [79154,79155]
===
match
---
name: local [15282,15287]
name: local [15302,15307]
===
match
---
atom_expr [33022,33034]
atom_expr [33042,33054]
===
match
---
expr_stmt [9664,9696]
expr_stmt [9692,9724]
===
match
---
trailer [5436,5445]
trailer [5464,5473]
===
match
---
atom_expr [80055,80068]
atom_expr [80075,80088]
===
match
---
operator: = [54203,54204]
operator: = [54223,54224]
===
match
---
param [21036,21041]
param [21056,21061]
===
match
---
argument [48946,48953]
argument [48966,48973]
===
match
---
simple_stmt [2825,2867]
simple_stmt [2853,2895]
===
match
---
fstring_expr [45021,45033]
fstring_expr [45041,45053]
===
match
---
operator: = [40399,40400]
operator: = [40419,40420]
===
match
---
atom_expr [40796,40809]
atom_expr [40816,40829]
===
match
---
name: fmt [59659,59662]
name: fmt [59679,59682]
===
match
---
operator: , [44161,44162]
operator: , [44181,44182]
===
match
---
name: test_mode [40757,40766]
name: test_mode [40777,40786]
===
match
---
simple_stmt [14607,14652]
simple_stmt [14627,14672]
===
match
---
simple_stmt [62385,62444]
simple_stmt [62405,62464]
===
match
---
fstring_start: f" [62398,62400]
fstring_start: f" [62418,62420]
===
match
---
simple_stmt [54937,54954]
simple_stmt [54957,54974]
===
match
---
trailer [61517,61532]
trailer [61537,61552]
===
match
---
operator: , [76514,76515]
operator: , [76534,76535]
===
match
---
operator: == [26117,26119]
operator: == [26137,26139]
===
match
---
trailer [60632,60634]
trailer [60652,60654]
===
match
---
trailer [50884,50892]
trailer [50904,50912]
===
match
---
trailer [22512,22519]
trailer [22532,22539]
===
match
---
trailer [41575,41592]
trailer [41595,41612]
===
match
---
operator: , [79767,79768]
operator: , [79787,79788]
===
match
---
string: 'run_as_user' [80232,80245]
string: 'run_as_user' [80252,80265]
===
match
---
operator: = [10947,10948]
operator: = [10975,10976]
===
match
---
strings [66829,67135]
strings [66849,67155]
===
match
---
expr_stmt [5065,5140]
expr_stmt [5093,5168]
===
match
---
import_from [7312,7353]
import_from [7340,7381]
===
match
---
atom_expr [66027,66045]
atom_expr [66047,66065]
===
match
---
name: execution_date [73951,73965]
name: execution_date [73971,73985]
===
match
---
operator: = [59288,59289]
operator: = [59308,59309]
===
match
---
name: job_id [22501,22507]
name: job_id [22521,22527]
===
match
---
operator: } [48808,48809]
operator: } [48828,48829]
===
match
---
tfpdef [41811,41830]
tfpdef [41831,41850]
===
match
---
name: base_url [19279,19287]
name: base_url [19299,19307]
===
match
---
name: configuration [1604,1617]
name: configuration [1589,1602]
===
match
---
name: Exception [52389,52398]
name: Exception [52409,52418]
===
match
---
name: construct_task_instance [81566,81589]
name: construct_task_instance [81586,81609]
===
match
---
operator: = [76668,76669]
operator: = [76688,76689]
===
match
---
name: self [72853,72857]
name: self [72873,72877]
===
match
---
operator: , [56296,56297]
operator: , [56316,56317]
===
match
---
operator: = [26027,26028]
operator: = [26047,26048]
===
match
---
trailer [57106,57113]
trailer [57126,57133]
===
match
---
fstring_start: f" [19350,19352]
fstring_start: f" [19370,19372]
===
match
---
trailer [68550,68557]
trailer [68570,68577]
===
match
---
name: str [16027,16030]
name: str [16047,16050]
===
match
---
name: test_mode [56374,56383]
name: test_mode [56394,56403]
===
match
---
parameters [30983,31036]
parameters [31003,31056]
===
match
---
trailer [22800,22804]
trailer [22820,22824]
===
match
---
name: render [72146,72152]
name: render [72166,72172]
===
match
---
operator: = [10101,10102]
operator: = [10129,10130]
===
match
---
operator: = [25937,25938]
operator: = [25957,25958]
===
match
---
simple_stmt [29044,29093]
simple_stmt [29064,29113]
===
match
---
suite [62694,63580]
suite [62714,63600]
===
match
---
suite [13924,13999]
suite [13944,14019]
===
match
---
simple_stmt [40826,40853]
simple_stmt [40846,40873]
===
match
---
trailer [46188,46195]
trailer [46208,46215]
===
match
---
import_from [1562,1590]
import_from [1547,1575]
===
match
---
simple_stmt [63218,63239]
simple_stmt [63238,63259]
===
match
---
expr_stmt [62135,62192]
expr_stmt [62155,62212]
===
match
---
operator: = [30917,30918]
operator: = [30937,30938]
===
match
---
arglist [10588,10617]
arglist [10616,10645]
===
match
---
simple_stmt [56819,56853]
simple_stmt [56839,56873]
===
match
---
trailer [30156,30172]
trailer [30176,30192]
===
match
---
return_stmt [81118,81136]
return_stmt [81138,81156]
===
match
---
operator: , [66060,66061]
operator: , [66080,66081]
===
match
---
name: yesterday_ds_nodash [66139,66158]
name: yesterday_ds_nodash [66159,66178]
===
match
---
param [77431,77436]
param [77451,77456]
===
match
---
name: dag_id [7702,7708]
name: dag_id [7730,7736]
===
match
---
param [13918,13922]
param [13938,13942]
===
match
---
arglist [56610,56621]
arglist [56630,56641]
===
match
---
operator: , [43941,43942]
operator: , [43961,43962]
===
match
---
trailer [60874,60883]
trailer [60894,60903]
===
match
---
name: start_date [25032,25042]
name: start_date [25052,25062]
===
match
---
name: result [59763,59769]
name: result [59783,59789]
===
match
---
simple_stmt [24113,24149]
simple_stmt [24133,24169]
===
match
---
simple_stmt [67998,68026]
simple_stmt [68018,68046]
===
match
---
operator: , [56482,56483]
operator: , [56502,56503]
===
match
---
arglist [6652,7108]
arglist [6680,7136]
===
match
---
name: and_ [6838,6842]
name: and_ [6866,6870]
===
match
---
name: self [80714,80718]
name: self [80734,80738]
===
match
---
name: session [32594,32601]
name: session [32614,32621]
===
match
---
atom_expr [32137,32154]
atom_expr [32157,32174]
===
match
---
fstring_string: Unable to render a k8s spec for this taskinstance:  [67631,67682]
fstring_string: Unable to render a k8s spec for this taskinstance:  [67651,67702]
===
match
---
name: rendered_task_instance_fields [66453,66482]
name: rendered_task_instance_fields [66473,66502]
===
match
---
param [81244,81248]
param [81264,81268]
===
match
---
name: e [67683,67684]
name: e [67703,67704]
===
match
---
name: self [61335,61339]
name: self [61355,61359]
===
match
---
atom_expr [11758,11817]
atom_expr [11786,11845]
===
match
---
name: with_for_update [82293,82308]
name: with_for_update [82313,82328]
===
match
---
operator: = [27306,27307]
operator: = [27326,27327]
===
match
---
name: subject [72136,72143]
name: subject [72156,72163]
===
match
---
name: set [74188,74191]
name: set [74208,74211]
===
match
---
operator: = [44365,44366]
operator: = [44385,44386]
===
match
---
name: TaskInstance [26097,26109]
name: TaskInstance [26117,26129]
===
match
---
name: self [47161,47165]
name: self [47181,47185]
===
match
---
operator: { [42935,42936]
operator: { [42955,42956]
===
match
---
if_stmt [51784,51896]
if_stmt [51804,51916]
===
match
---
name: self [69442,69446]
name: self [69462,69466]
===
match
---
trailer [54735,54743]
trailer [54755,54763]
===
match
---
name: TaskInstance [78870,78882]
name: TaskInstance [78890,78902]
===
match
---
trailer [23576,23585]
trailer [23596,23605]
===
match
---
operator: , [19897,19898]
operator: , [19917,19918]
===
match
---
name: session [28040,28047]
name: session [28060,28067]
===
match
---
name: _safe_date [58603,58613]
name: _safe_date [58623,58633]
===
match
---
atom_expr [5251,5265]
atom_expr [5279,5293]
===
match
---
trailer [57193,57208]
trailer [57213,57228]
===
match
---
name: cmd [18196,18199]
name: cmd [18216,18219]
===
match
---
argument [15178,15223]
argument [15198,15243]
===
match
---
funcdef [33080,34853]
funcdef [33100,34873]
===
match
---
trailer [46334,46338]
trailer [46354,46358]
===
match
---
atom_expr [63160,63168]
atom_expr [63180,63188]
===
match
---
string: 'var' [65945,65950]
string: 'var' [65965,65970]
===
match
---
operator: = [78345,78346]
operator: = [78365,78366]
===
match
---
sync_comp_for [7709,7722]
sync_comp_for [7737,7750]
===
match
---
operator: , [46721,46722]
operator: , [46741,46742]
===
match
---
trailer [26174,26194]
trailer [26194,26214]
===
match
---
name: log [2524,2527]
name: log [2509,2512]
===
match
---
name: values_ordered_by_id [77114,77134]
name: values_ordered_by_id [77134,77154]
===
match
---
simple_stmt [47877,48030]
simple_stmt [47897,48050]
===
match
---
operator: , [21704,21705]
operator: , [21724,21725]
===
match
---
suite [81347,81375]
suite [81367,81395]
===
match
---
trailer [8281,8289]
trailer [8309,8317]
===
match
---
name: COLLATION_ARGS [9566,9580]
name: COLLATION_ARGS [9594,9608]
===
match
---
name: unixname [22475,22483]
name: unixname [22495,22503]
===
match
---
name: self [54716,54720]
name: self [54736,54740]
===
match
---
expr_stmt [11741,11817]
expr_stmt [11769,11845]
===
match
---
arglist [71045,71119]
arglist [71065,71139]
===
match
---
name: self [22532,22536]
name: self [22552,22556]
===
match
---
atom_expr [50322,50357]
atom_expr [50342,50377]
===
match
---
name: property [28560,28568]
name: property [28580,28588]
===
match
---
name: primary_key [9583,9594]
name: primary_key [9611,9622]
===
match
---
annassign [80134,80160]
annassign [80154,80180]
===
match
---
param [35885,35915]
param [35905,35935]
===
match
---
name: task [11709,11713]
name: task [11737,11741]
===
match
---
name: self [8739,8743]
name: self [8767,8771]
===
match
---
name: prev_execution_date [61381,61400]
name: prev_execution_date [61401,61420]
===
match
---
name: utcnow [50928,50934]
name: utcnow [50948,50954]
===
match
---
name: in_ [26292,26295]
name: in_ [26312,26315]
===
match
---
name: Stats [44969,44974]
name: Stats [44989,44994]
===
match
---
if_stmt [45626,45705]
if_stmt [45646,45725]
===
match
---
trailer [49524,49536]
trailer [49544,49556]
===
match
---
operator: = [80458,80459]
operator: = [80478,80479]
===
match
---
name: self [74509,74513]
name: self [74529,74533]
===
match
---
trailer [81367,81374]
trailer [81387,81394]
===
match
---
atom_expr [82211,82231]
atom_expr [82231,82251]
===
match
---
name: log [21503,21506]
name: log [21523,21526]
===
match
---
atom_expr [10383,10423]
atom_expr [10411,10451]
===
match
---
operator: , [54485,54486]
operator: , [54505,54506]
===
match
---
name: ApiClient [3150,3159]
name: ApiClient [3178,3187]
===
match
---
suite [82486,82682]
suite [82506,82702]
===
match
---
testlist [72376,72415]
testlist [72396,72435]
===
match
---
name: start_date [79965,79975]
name: start_date [79985,79995]
===
match
---
name: task [44993,44997]
name: task [45013,45017]
===
match
---
arglist [64057,64084]
arglist [64077,64104]
===
match
---
operator: , [45401,45402]
operator: , [45421,45422]
===
match
---
trailer [57173,57242]
trailer [57193,57262]
===
match
---
operator: = [48864,48865]
operator: = [48884,48885]
===
match
---
operator: -> [8619,8621]
operator: -> [8647,8649]
===
match
---
number: 80 [37985,37987]
number: 80 [38005,38007]
===
match
---
expr_stmt [26860,26897]
expr_stmt [26880,26917]
===
match
---
operator: = [21824,21825]
operator: = [21844,21845]
===
match
---
trailer [44450,44466]
trailer [44470,44486]
===
match
---
name: params [67778,67784]
name: params [67798,67804]
===
match
---
number: 1 [37872,37873]
number: 1 [37892,37893]
===
match
---
operator: , [32360,32361]
operator: , [32380,32381]
===
match
---
operator: , [4284,4285]
operator: , [4312,4313]
===
match
---
name: str [74548,74551]
name: str [74568,74571]
===
match
---
param [72797,72801]
param [72817,72821]
===
match
---
atom_expr [5934,5976]
atom_expr [5962,6004]
===
match
---
name: task_ids [76913,76921]
name: task_ids [76933,76941]
===
match
---
trailer [19730,19737]
trailer [19750,19757]
===
match
---
operator: = [46945,46946]
operator: = [46965,46966]
===
match
---
trailer [60668,60677]
trailer [60688,60697]
===
match
---
name: ignore_schedule [27738,27753]
name: ignore_schedule [27758,27773]
===
match
---
return_stmt [26372,26417]
return_stmt [26392,26437]
===
match
---
simple_stmt [28640,28780]
simple_stmt [28660,28800]
===
match
---
arglist [9556,9580]
arglist [9584,9608]
===
match
---
expr_stmt [22741,22774]
expr_stmt [22761,22794]
===
match
---
name: task_id [19392,19399]
name: task_id [19412,19419]
===
match
---
trailer [45578,45584]
trailer [45598,45604]
===
match
---
name: local [14245,14250]
name: local [14265,14270]
===
match
---
trailer [60794,60803]
trailer [60814,60823]
===
match
---
trailer [18223,18231]
trailer [18243,18251]
===
match
---
name: ti [6065,6067]
name: ti [6093,6095]
===
match
---
name: state [29598,29603]
name: state [29618,29623]
===
match
---
operator: , [10769,10770]
operator: , [10797,10798]
===
match
---
simple_stmt [28120,28260]
simple_stmt [28140,28280]
===
match
---
name: _date_or_empty [41419,41433]
name: _date_or_empty [41439,41453]
===
match
---
simple_stmt [1176,1201]
simple_stmt [1161,1186]
===
match
---
argument [54227,54240]
argument [54247,54260]
===
match
---
expr_stmt [22374,22403]
expr_stmt [22394,22423]
===
match
---
suite [63890,63923]
suite [63910,63943]
===
match
---
name: dag_id [79078,79084]
name: dag_id [79098,79104]
===
match
---
atom_expr [27281,27290]
atom_expr [27301,27310]
===
match
---
operator: = [68201,68202]
operator: = [68221,68222]
===
match
---
operator: , [44325,44326]
operator: , [44345,44346]
===
match
---
trailer [39068,39075]
trailer [39088,39095]
===
match
---
suite [56802,56853]
suite [56822,56873]
===
match
---
decorated [8316,8571]
decorated [8344,8599]
===
match
---
simple_stmt [56929,56949]
simple_stmt [56949,56969]
===
match
---
name: session [27826,27833]
name: session [27846,27853]
===
match
---
name: error_file [54598,54608]
name: error_file [54618,54628]
===
match
---
name: utcnow [24682,24688]
name: utcnow [24702,24708]
===
match
---
trailer [21502,21506]
trailer [21522,21526]
===
match
---
trailer [7176,7178]
trailer [7204,7206]
===
match
---
trailer [45584,45590]
trailer [45604,45610]
===
match
---
trailer [33949,33960]
trailer [33969,33980]
===
match
---
trailer [24894,24900]
trailer [24914,24920]
===
match
---
expr_stmt [7456,7482]
expr_stmt [7484,7510]
===
match
---
name: self [23482,23486]
name: self [23502,23506]
===
match
---
param [35760,35790]
param [35780,35810]
===
match
---
name: default_html_content [72249,72269]
name: default_html_content [72269,72289]
===
match
---
name: extend [18446,18452]
name: extend [18466,18472]
===
match
---
operator: = [21049,21050]
operator: = [21069,21070]
===
match
---
operator: { [14756,14757]
operator: { [14776,14777]
===
match
---
name: session [38603,38610]
name: session [38623,38630]
===
match
---
atom_expr [43794,43805]
atom_expr [43814,43825]
===
match
---
simple_stmt [8057,8070]
simple_stmt [8085,8098]
===
match
---
string: '%s dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [58371,58444]
string: '%s dag_id=%s, task_id=%s, execution_date=%s, start_date=%s, end_date=%s' [58391,58464]
===
match
---
arglist [58371,58703]
arglist [58391,58723]
===
match
---
string: """         Returns whether a task is in UP_FOR_RETRY state and its retry interval         has elapsed.         """ [25139,25254]
string: """         Returns whether a task is in UP_FOR_RETRY state and its retry interval         has elapsed.         """ [25159,25274]
===
match
---
operator: = [68944,68945]
operator: = [68964,68965]
===
match
---
name: staticmethod [64202,64214]
name: staticmethod [64222,64234]
===
match
---
expr_stmt [34770,34815]
expr_stmt [34790,34835]
===
match
---
simple_stmt [23438,23474]
simple_stmt [23458,23494]
===
match
---
name: task_copy [49858,49867]
name: task_copy [49878,49887]
===
match
---
expr_stmt [38170,38491]
expr_stmt [38190,38511]
===
match
---
name: relationship [1451,1463]
name: relationship [1436,1448]
===
match
---
sync_comp_for [47248,47318]
sync_comp_for [47268,47338]
===
match
---
name: statement [47964,47973]
name: statement [47984,47993]
===
match
---
name: task_id_by_key [7156,7170]
name: task_id_by_key [7184,7198]
===
match
---
name: airflow [7531,7538]
name: airflow [7559,7566]
===
match
---
string: """Setting Next Try Number""" [13933,13962]
string: """Setting Next Try Number""" [13953,13982]
===
match
---
simple_stmt [23259,23283]
simple_stmt [23279,23303]
===
match
---
name: pod_override_object [68752,68771]
name: pod_override_object [68772,68791]
===
match
---
name: Iterable [1067,1075]
name: Iterable [1052,1060]
===
match
---
operator: = [82030,82031]
operator: = [82050,82051]
===
match
---
atom_expr [35503,35524]
atom_expr [35523,35544]
===
match
---
if_stmt [78164,78200]
if_stmt [78184,78220]
===
match
---
decorator [80733,80743]
decorator [80753,80763]
===
match
---
string: 'priority_weight' [80404,80421]
string: 'priority_weight' [80424,80441]
===
match
---
trailer [4441,4446]
trailer [4469,4474]
===
match
---
trailer [11173,11182]
trailer [11201,11210]
===
match
---
operator: , [59195,59196]
operator: , [59215,59216]
===
match
---
tfpdef [74659,74684]
tfpdef [74679,74704]
===
match
---
argument [48857,48872]
argument [48877,48892]
===
match
---
name: self [57227,57231]
name: self [57247,57251]
===
match
---
trailer [7432,7434]
trailer [7460,7462]
===
match
---
name: execution_date [8296,8310]
name: execution_date [8324,8338]
===
match
---
name: query_for_task_instance [39173,39196]
name: query_for_task_instance [39193,39216]
===
match
---
operator: , [74613,74614]
operator: , [74633,74634]
===
match
---
string: """Fetch rendered template fields from DB""" [66223,66267]
string: """Fetch rendered template fields from DB""" [66243,66287]
===
match
---
name: res [53866,53869]
name: res [53886,53889]
===
match
---
operator: , [1304,1305]
operator: , [1289,1290]
===
match
---
simple_stmt [1150,1162]
simple_stmt [1135,1147]
===
match
---
name: self [25441,25445]
name: self [25461,25465]
===
match
---
name: _try_number [13185,13196]
name: _try_number [13205,13216]
===
match
---
name: data [4078,4082]
name: data [4106,4110]
===
match
---
parameters [72436,72453]
parameters [72456,72473]
===
match
---
operator: = [64570,64571]
operator: = [64590,64591]
===
match
---
atom_expr [7468,7482]
atom_expr [7496,7510]
===
match
---
name: params [60217,60223]
name: params [60237,60243]
===
match
---
trailer [21599,21606]
trailer [21619,21626]
===
match
---
name: airflow [1929,1936]
name: airflow [1914,1921]
===
match
---
name: dag [26812,26815]
name: dag [26832,26835]
===
match
---
name: verbose [53461,53468]
name: verbose [53481,53488]
===
match
---
name: state [24895,24900]
name: state [24915,24920]
===
match
---
name: error [20641,20646]
name: error [20661,20666]
===
match
---
argument [38282,38313]
argument [38302,38333]
===
match
---
trailer [11267,11272]
trailer [11295,11300]
===
match
---
atom_expr [79267,79454]
atom_expr [79287,79474]
===
match
---
and_test [67860,67884]
and_test [67880,67904]
===
match
---
operator: , [74142,74143]
operator: , [74162,74163]
===
match
---
name: dag_id [10604,10610]
name: dag_id [10632,10638]
===
match
---
atom_expr [23291,23300]
atom_expr [23311,23320]
===
match
---
name: DagRun [60381,60387]
name: DagRun [60401,60407]
===
match
---
operator: } [62428,62429]
operator: } [62448,62449]
===
match
---
name: raw [12376,12379]
name: raw [12396,12399]
===
match
---
expr_stmt [17925,17957]
expr_stmt [17945,17977]
===
match
---
name: property [80588,80596]
name: property [80608,80616]
===
match
---
name: add [40788,40791]
name: add [40808,40811]
===
match
---
name: value [13282,13287]
name: value [13302,13307]
===
match
---
trailer [5346,5354]
trailer [5374,5382]
===
match
---
atom_expr [60536,60550]
atom_expr [60556,60570]
===
match
---
funcdef [48070,50715]
funcdef [48090,50735]
===
match
---
trailer [3945,3968]
trailer [3973,3996]
===
match
---
trailer [20444,20459]
trailer [20464,20479]
===
match
---
trailer [78435,78443]
trailer [78455,78463]
===
match
---
trailer [9718,9731]
trailer [9746,9759]
===
match
---
simple_stmt [8649,8708]
simple_stmt [8677,8736]
===
match
---
trailer [58199,58205]
trailer [58219,58225]
===
match
---
name: all [78642,78645]
name: all [78662,78665]
===
match
---
name: warnings [28788,28796]
name: warnings [28808,28816]
===
match
---
name: int [15885,15888]
name: int [15905,15908]
===
match
---
trailer [79800,79808]
trailer [79820,79828]
===
match
---
name: self [50901,50905]
name: self [50921,50925]
===
match
---
simple_stmt [21096,21490]
simple_stmt [21116,21510]
===
match
---
trailer [44726,44741]
trailer [44746,44761]
===
match
---
name: self [70560,70564]
name: self [70580,70584]
===
match
---
string: """Render k8s pod yaml""" [68344,68369]
string: """Render k8s pod yaml""" [68364,68389]
===
match
---
operator: = [53674,53675]
operator: = [53694,53695]
===
match
---
operator: % [34179,34180]
operator: % [34199,34200]
===
match
---
string: """Get Airflow Variable after deserializing JSON value""" [64429,64486]
string: """Get Airflow Variable after deserializing JSON value""" [64449,64506]
===
match
---
trailer [72730,72774]
trailer [72750,72794]
===
match
---
trailer [14760,14769]
trailer [14780,14789]
===
match
---
not_test [38015,38031]
not_test [38035,38051]
===
match
---
operator: = [7891,7892]
operator: = [7919,7920]
===
match
---
suite [41193,41288]
suite [41213,41308]
===
match
---
name: log [45120,45123]
name: log [45140,45143]
===
match
---
trailer [82409,82411]
trailer [82429,82431]
===
match
---
argument [68626,68659]
argument [68646,68679]
===
match
---
operator: , [37870,37871]
operator: , [37890,37891]
===
match
---
name: self [24354,24358]
name: self [24374,24378]
===
match
---
name: exec2 [58846,58851]
name: exec2 [58866,58871]
===
match
---
atom_expr [27785,27834]
atom_expr [27805,27854]
===
match
---
param [63991,64001]
param [64011,64021]
===
match
---
atom_expr [44865,44921]
atom_expr [44885,44941]
===
match
---
operator: = [71244,71245]
operator: = [71264,71265]
===
match
---
name: file_path [15906,15915]
name: file_path [15926,15935]
===
match
---
decorator [81458,81468]
decorator [81478,81488]
===
match
---
name: execution_date [57194,57208]
name: execution_date [57214,57228]
===
match
---
operator: @ [80992,80993]
operator: @ [81012,81013]
===
match
---
name: task_id [77163,77170]
name: task_id [77183,77190]
===
match
---
atom_expr [27665,27686]
atom_expr [27685,27706]
===
match
---
trailer [44308,44323]
trailer [44328,44343]
===
match
---
operator: = [42661,42662]
operator: = [42681,42682]
===
match
---
name: SUCCESS [44641,44648]
name: SUCCESS [44661,44668]
===
match
---
dotted_name [2385,2398]
dotted_name [2370,2383]
===
match
---
arglist [79289,79440]
arglist [79309,79460]
===
match
---
operator: , [57225,57226]
operator: , [57245,57246]
===
match
---
trailer [26869,26880]
trailer [26889,26900]
===
match
---
operator: , [3955,3956]
operator: , [3983,3984]
===
match
---
atom_expr [50618,50679]
atom_expr [50638,50699]
===
match
---
name: self [21498,21502]
name: self [21518,21522]
===
match
---
operator: = [50917,50918]
operator: = [50937,50938]
===
match
---
name: last_dagrun [27869,27880]
name: last_dagrun [27889,27900]
===
match
---
operator: = [11933,11934]
operator: = [11961,11962]
===
match
---
arglist [45540,45556]
arglist [45560,45576]
===
match
---
trailer [82432,82438]
trailer [82452,82458]
===
match
---
operator: = [35744,35745]
operator: = [35764,35765]
===
match
---
expr_stmt [71930,71959]
expr_stmt [71950,71979]
===
match
---
name: end_date [22039,22047]
name: end_date [22059,22067]
===
match
---
name: delay [34847,34852]
name: delay [34867,34872]
===
match
---
simple_stmt [22532,22552]
simple_stmt [22552,22572]
===
match
---
simple_stmt [61695,61737]
simple_stmt [61715,61757]
===
match
---
name: dag_id [49057,49063]
name: dag_id [49077,49083]
===
match
---
trailer [82141,82149]
trailer [82161,82169]
===
match
---
trailer [43516,43521]
trailer [43536,43541]
===
match
---
if_stmt [73907,74174]
if_stmt [73927,74194]
===
match
---
trailer [50698,50714]
trailer [50718,50734]
===
match
---
simple_stmt [8257,8311]
simple_stmt [8285,8339]
===
match
---
name: provide_session [81542,81557]
name: provide_session [81562,81577]
===
match
---
operator: = [9808,9809]
operator: = [9836,9837]
===
match
---
suite [71859,72123]
suite [71879,72143]
===
match
---
argument [46789,46811]
argument [46809,46831]
===
match
---
atom_expr [19726,19737]
atom_expr [19746,19757]
===
match
---
operator: = [80319,80320]
operator: = [80339,80340]
===
match
---
name: try_number [12671,12681]
name: try_number [12691,12701]
===
match
---
name: job [7456,7459]
name: job [7484,7487]
===
match
---
simple_stmt [68378,68405]
simple_stmt [68398,68425]
===
match
---
name: property [19147,19155]
name: property [19167,19175]
===
match
---
atom_expr [18442,18482]
atom_expr [18462,18502]
===
match
---
atom_expr [43484,43490]
atom_expr [43504,43510]
===
match
---
name: state [50871,50876]
name: state [50891,50896]
===
match
---
operator: , [15747,15748]
operator: , [15767,15768]
===
match
---
trailer [26083,26338]
trailer [26103,26358]
===
match
---
suite [61246,61355]
suite [61266,61375]
===
match
---
name: queue [22629,22634]
name: queue [22649,22654]
===
match
---
operator: = [53782,53783]
operator: = [53802,53803]
===
match
---
operator: , [48953,48954]
operator: , [48973,48974]
===
match
---
name: execution_date [79425,79439]
name: execution_date [79445,79459]
===
match
---
simple_stmt [80634,80654]
simple_stmt [80654,80674]
===
match
---
funcdef [12667,13233]
funcdef [12687,13253]
===
match
---
string: 'TaskInstance' [26550,26564]
string: 'TaskInstance' [26570,26584]
===
match
---
atom_expr [52300,52323]
atom_expr [52320,52343]
===
match
---
trailer [18277,18284]
trailer [18297,18304]
===
match
---
atom_expr [78642,78717]
atom_expr [78662,78737]
===
match
---
tfpdef [35760,35781]
tfpdef [35780,35801]
===
match
---
simple_stmt [20598,20611]
simple_stmt [20618,20631]
===
match
---
suite [49824,49910]
suite [49844,49930]
===
match
---
trailer [58613,58644]
trailer [58633,58664]
===
match
---
if_stmt [56371,56432]
if_stmt [56391,56452]
===
match
---
atom_expr [41267,41286]
atom_expr [41287,41306]
===
match
---
name: should_pass_filepath [14607,14627]
name: should_pass_filepath [14627,14647]
===
match
---
name: kube_config [68981,68992]
name: kube_config [69001,69012]
===
match
---
trailer [64113,64117]
trailer [64133,64137]
===
match
---
name: self [8549,8553]
name: self [8577,8581]
===
match
---
operator: = [80374,80375]
operator: = [80394,80395]
===
match
---
if_stmt [7292,7483]
if_stmt [7320,7511]
===
match
---
trailer [59337,59411]
trailer [59357,59431]
===
match
---
name: render [71838,71844]
name: render [71858,71864]
===
match
---
name: self [80972,80976]
name: self [80992,80996]
===
match
---
argument [29072,29091]
argument [29092,29111]
===
match
---
name: TaskInstance [20252,20264]
name: TaskInstance [20272,20284]
===
match
---
name: state [22836,22841]
name: state [22856,22861]
===
match
---
name: check_and_change_state_before_execution [53877,53916]
name: check_and_change_state_before_execution [53897,53936]
===
match
---
name: _execute_task [50467,50480]
name: _execute_task [50487,50500]
===
match
---
return_stmt [81436,81452]
return_stmt [81456,81472]
===
match
---
name: send_email [72631,72641]
name: send_email [72651,72661]
===
match
---
atom_expr [63107,63115]
atom_expr [63127,63135]
===
match
---
trailer [52834,52854]
trailer [52854,52874]
===
match
---
exprlist [6930,6950]
exprlist [6958,6978]
===
match
---
param [73179,73221]
param [73199,73241]
===
match
---
trailer [46098,46334]
trailer [46118,46354]
===
match
---
arglist [62118,62125]
arglist [62138,62145]
===
match
---
expr_stmt [42784,42804]
expr_stmt [42804,42824]
===
match
---
name: tomorrow_ds [62347,62358]
name: tomorrow_ds [62367,62378]
===
match
---
name: cfg_path [15448,15456]
name: cfg_path [15468,15476]
===
match
---
trailer [11988,12003]
trailer [12016,12031]
===
match
---
decorator [81541,81558]
decorator [81561,81578]
===
match
---
simple_stmt [55431,55714]
simple_stmt [55451,55734]
===
match
---
name: task_id [77695,77702]
name: task_id [77715,77722]
===
match
---
simple_stmt [62025,62086]
simple_stmt [62045,62106]
===
match
---
arglist [50629,50678]
arglist [50649,50698]
===
match
---
name: session [45600,45607]
name: session [45620,45627]
===
match
---
trailer [63228,63238]
trailer [63248,63258]
===
match
---
import_name [1162,1175]
import_name [1147,1160]
===
match
---
operator: , [64905,64906]
operator: , [64925,64926]
===
match
---
string: 'ts_nodash' [65857,65868]
string: 'ts_nodash' [65877,65888]
===
match
---
funcdef [81006,81067]
funcdef [81026,81087]
===
match
---
argument [54460,54485]
argument [54480,54505]
===
match
---
operator: = [12163,12164]
operator: = [12183,12184]
===
match
---
dotted_name [66281,66312]
dotted_name [66301,66332]
===
match
---
import_from [7526,7566]
import_from [7554,7594]
===
match
---
name: str [74562,74565]
name: str [74582,74585]
===
match
---
name: job_id [10862,10868]
name: job_id [10890,10896]
===
match
---
operator: , [46861,46862]
operator: , [46881,46882]
===
match
---
name: execution_date [79404,79418]
name: execution_date [79424,79438]
===
match
---
name: try_number [13239,13249]
name: try_number [13259,13269]
===
match
---
name: setter [13250,13256]
name: setter [13270,13276]
===
match
---
trailer [64056,64085]
trailer [64076,64105]
===
match
---
name: task_id [8512,8519]
name: task_id [8540,8547]
===
match
---
operator: , [6870,6871]
operator: , [6898,6899]
===
match
---
name: self [53158,53162]
name: self [53178,53182]
===
match
---
operator: , [65369,65370]
operator: , [65389,65390]
===
match
---
atom_expr [81283,81304]
atom_expr [81303,81324]
===
match
---
operator: = [72215,72216]
operator: = [72235,72236]
===
match
---
operator: , [60438,60439]
operator: , [60458,60459]
===
match
---
atom_expr [33659,33727]
atom_expr [33679,33747]
===
match
---
atom_expr [62590,62661]
atom_expr [62610,62681]
===
match
---
name: ti_hash [33786,33793]
name: ti_hash [33806,33813]
===
match
---
decorated [80992,81067]
decorated [81012,81087]
===
match
---
operator: , [44826,44827]
operator: , [44846,44847]
===
match
---
param [68311,68315]
param [68331,68335]
===
match
---
dotted_name [45732,45752]
dotted_name [45752,45772]
===
match
---
name: session [54640,54647]
name: session [54660,54667]
===
match
---
name: self [32356,32360]
name: self [32376,32380]
===
match
---
string: """         Returns the DagRun for this TaskInstance          :param session: SQLAlchemy ORM Session         :return: DagRun         """ [35192,35328]
string: """         Returns the DagRun for this TaskInstance          :param session: SQLAlchemy ORM Session         :return: DagRun         """ [35212,35348]
===
match
---
if_stmt [80217,80295]
if_stmt [80237,80315]
===
match
---
name: var [63112,63115]
name: var [63132,63135]
===
match
---
name: context [68273,68280]
name: context [68293,68300]
===
match
---
operator: , [48119,48120]
operator: , [48139,48140]
===
match
---
suite [61619,61810]
suite [61639,61830]
===
match
---
name: prepare_for_execution [54979,55000]
name: prepare_for_execution [54999,55020]
===
match
---
name: self [24306,24310]
name: self [24326,24330]
===
match
---
name: str [15529,15532]
name: str [15549,15552]
===
match
---
if_stmt [18173,18234]
if_stmt [18193,18254]
===
match
---
atom_expr [6652,6661]
atom_expr [6680,6689]
===
match
---
trailer [78647,78654]
trailer [78667,78674]
===
match
---
name: utils [2471,2476]
name: utils [2456,2461]
===
match
---
trailer [42742,42758]
trailer [42762,42778]
===
match
---
name: job_id [14309,14315]
name: job_id [14329,14335]
===
match
---
name: merge [45579,45584]
name: merge [45599,45604]
===
match
---
name: task [42633,42637]
name: task [42653,42657]
===
match
---
simple_stmt [18442,18483]
simple_stmt [18462,18503]
===
match
---
name: reschedule_exception [55168,55188]
name: reschedule_exception [55188,55208]
===
match
---
atom_expr [18274,18315]
atom_expr [18294,18335]
===
match
---
operator: = [29228,29229]
operator: = [29248,29249]
===
match
---
atom_expr [55327,55340]
atom_expr [55347,55360]
===
match
---
trailer [26036,26042]
trailer [26056,26062]
===
match
---
operator: = [19519,19520]
operator: = [19539,19540]
===
match
---
name: session [7621,7628]
name: session [7649,7656]
===
match
---
suite [44956,45036]
suite [44976,45056]
===
match
---
argument [15282,15293]
argument [15302,15313]
===
match
---
trailer [63408,63439]
trailer [63428,63459]
===
match
---
name: execution_date [29681,29695]
name: execution_date [29701,29715]
===
match
---
expr_stmt [8041,8052]
expr_stmt [8069,8080]
===
match
---
fstring [44980,45034]
fstring [45000,45054]
===
match
---
operator: , [24352,24353]
operator: , [24372,24373]
===
match
---
name: ignore_depends_on_past [15178,15200]
name: ignore_depends_on_past [15198,15220]
===
match
---
operator: = [82348,82349]
operator: = [82368,82369]
===
match
---
name: self [39848,39852]
name: self [39868,39872]
===
match
---
trailer [6097,6108]
trailer [6125,6136]
===
match
---
string: "\n" [37971,37975]
string: "\n" [37991,37995]
===
match
---
expr_stmt [40892,40912]
expr_stmt [40912,40932]
===
match
---
simple_stmt [23338,23372]
simple_stmt [23358,23392]
===
match
---
atom_expr [14688,14705]
atom_expr [14708,14725]
===
match
---
trailer [7898,7906]
trailer [7926,7934]
===
match
---
operator: , [15033,15034]
operator: , [15053,15054]
===
match
---
trailer [82045,82059]
trailer [82065,82079]
===
match
---
parameters [63025,63089]
parameters [63045,63109]
===
match
---
operator: @ [19854,19855]
operator: @ [19874,19875]
===
match
---
trailer [18994,18996]
trailer [19014,19016]
===
match
---
trailer [20861,20902]
trailer [20881,20922]
===
match
---
simple_stmt [61381,61451]
simple_stmt [61401,61471]
===
match
---
operator: = [15931,15932]
operator: = [15951,15952]
===
match
---
operator: -> [28603,28605]
operator: -> [28623,28625]
===
match
---
suite [21913,22805]
suite [21933,22825]
===
match
---
return_stmt [77544,77818]
return_stmt [77564,77838]
===
match
---
if_stmt [11449,11975]
if_stmt [11477,12003]
===
match
---
atom_expr [53289,53309]
atom_expr [53309,53329]
===
match
---
expr_stmt [82631,82681]
expr_stmt [82651,82701]
===
match
---
trailer [68784,68793]
trailer [68804,68813]
===
match
---
name: session [27914,27921]
name: session [27934,27941]
===
match
---
fstring_expr [19408,19421]
fstring_expr [19428,19441]
===
match
---
atom_expr [10843,10869]
atom_expr [10871,10897]
===
match
---
name: self [34727,34731]
name: self [34747,34751]
===
match
---
suite [18617,18659]
suite [18637,18679]
===
match
---
trailer [46141,46151]
trailer [46161,46171]
===
match
---
simple_stmt [61971,62013]
simple_stmt [61991,62033]
===
match
---
name: prev_ti [30339,30346]
name: prev_ti [30359,30366]
===
match
---
fstring_end: " [19139,19140]
fstring_end: " [19159,19160]
===
match
---
suite [62468,62508]
suite [62488,62528]
===
match
---
trailer [5991,5997]
trailer [6019,6025]
===
match
---
import_as_names [1052,1117]
import_as_names [1037,1102]
===
match
---
trailer [34736,34752]
trailer [34756,34772]
===
match
---
simple_stmt [44722,44779]
simple_stmt [44742,44799]
===
match
---
atom_expr [47504,47526]
atom_expr [47524,47546]
===
match
---
name: OperationalError [1392,1408]
name: OperationalError [1377,1393]
===
match
---
name: attr [41472,41476]
name: attr [41492,41496]
===
match
---
trailer [8525,8540]
trailer [8553,8568]
===
match
---
name: qry [82026,82029]
name: qry [82046,82049]
===
match
---
string: 'dag_run_conf_overrides_params' [62544,62575]
string: 'dag_run_conf_overrides_params' [62564,62595]
===
match
---
suite [43271,43320]
suite [43291,43340]
===
match
---
name: self [43631,43635]
name: self [43651,43655]
===
match
---
name: from_string [71256,71267]
name: from_string [71276,71287]
===
match
---
trailer [44624,44630]
trailer [44644,44650]
===
match
---
string: 'ti_job_id' [10849,10860]
string: 'ti_job_id' [10877,10888]
===
match
---
if_stmt [67857,68026]
if_stmt [67877,68046]
===
match
---
name: log [55995,55998]
name: log [56015,56018]
===
match
---
name: __init__ [11174,11182]
name: __init__ [11202,11210]
===
match
---
import_from [1464,1506]
import_from [1449,1491]
===
match
---
trailer [27119,27137]
trailer [27139,27157]
===
match
---
atom_expr [58195,58205]
atom_expr [58215,58225]
===
match
---
operator: - [71684,71685]
operator: - [71704,71705]
===
match
---
name: execution_date [24338,24352]
name: execution_date [24358,24372]
===
match
---
trailer [25043,25057]
trailer [25063,25077]
===
match
---
expr_stmt [9765,9791]
expr_stmt [9793,9819]
===
match
---
argument [31908,31923]
argument [31928,31943]
===
match
---
name: dep_status [32100,32110]
name: dep_status [32120,32130]
===
match
---
trailer [39852,39873]
trailer [39872,39893]
===
match
---
fstring [19089,19140]
fstring [19109,19160]
===
match
---
operator: = [35828,35829]
operator: = [35848,35849]
===
match
---
and_test [78646,78703]
and_test [78666,78723]
===
match
---
operator: = [11149,11150]
operator: = [11177,11178]
===
match
---
name: local [15836,15841]
name: local [15856,15861]
===
match
---
string: 'run_id' [65536,65544]
string: 'run_id' [65556,65564]
===
match
---
name: params [62461,62467]
name: params [62481,62487]
===
match
---
fstring [67629,67686]
fstring [67649,67706]
===
match
---
operator: , [18015,18016]
operator: , [18035,18036]
===
match
---
strings [74013,74115]
strings [74033,74135]
===
match
---
trailer [66597,66602]
trailer [66617,66622]
===
match
---
string: "Updating task params (%s) with DagRun.conf (%s)" [67913,67962]
string: "Updating task params (%s) with DagRun.conf (%s)" [67933,67982]
===
match
---
name: ti [79855,79857]
name: ti [79875,79877]
===
match
---
argument [64554,64575]
argument [64574,64595]
===
match
---
trailer [45539,45557]
trailer [45559,45577]
===
match
---
comparison [27665,27694]
comparison [27685,27714]
===
match
---
name: instance [64779,64787]
name: instance [64799,64807]
===
match
---
name: params [60057,60063]
name: params [60077,60083]
===
match
---
operator: + [13229,13230]
operator: + [13249,13250]
===
match
---
atom_expr [61485,61533]
atom_expr [61505,61553]
===
match
---
name: modded_hash [34143,34154]
name: modded_hash [34163,34174]
===
match
---
operator: = [14582,14583]
operator: = [14602,14603]
===
match
---
atom_expr [59967,59976]
atom_expr [59987,59996]
===
match
---
trailer [5215,5222]
trailer [5243,5250]
===
match
---
name: self [80800,80804]
name: self [80820,80824]
===
match
---
trailer [65276,65369]
trailer [65296,65389]
===
match
---
name: self [80523,80527]
name: self [80543,80547]
===
match
---
name: _key [81448,81452]
name: _key [81468,81472]
===
match
---
name: session [54648,54655]
name: session [54668,54675]
===
match
---
atom [18453,18481]
atom [18473,18501]
===
match
---
atom_expr [50901,50916]
atom_expr [50921,50936]
===
match
---
simple_stmt [10304,10355]
simple_stmt [10332,10383]
===
match
---
name: ti [5297,5299]
name: ti [5325,5327]
===
match
---
expr_stmt [52785,52813]
expr_stmt [52805,52833]
===
match
---
operator: == [21689,21691]
operator: == [21709,21711]
===
match
---
name: _pool [81199,81204]
name: _pool [81219,81224]
===
match
---
name: hr_line_break [37955,37968]
name: hr_line_break [37975,37988]
===
match
---
atom [10572,10876]
atom [10600,10904]
===
match
---
operator: = [62286,62287]
operator: = [62306,62307]
===
match
---
name: self [49969,49973]
name: self [49989,49993]
===
match
---
operator: = [10071,10072]
operator: = [10099,10100]
===
match
---
return_stmt [64167,64187]
return_stmt [64187,64207]
===
match
---
simple_stmt [27771,27835]
simple_stmt [27791,27855]
===
match
---
atom_expr [56417,56431]
atom_expr [56437,56451]
===
match
---
not_test [38507,38638]
not_test [38527,38658]
===
match
---
simple_stmt [53835,53858]
simple_stmt [53855,53878]
===
match
---
operator: = [39584,39585]
operator: = [39604,39605]
===
match
---
name: self [77845,77849]
name: self [77865,77869]
===
match
---
suite [18910,19141]
suite [18930,19161]
===
match
---
name: str [64258,64261]
name: str [64278,64281]
===
match
---
atom_expr [48046,48064]
atom_expr [48066,48084]
===
match
---
name: __init__ [62949,62957]
name: __init__ [62969,62977]
===
match
---
name: ti [79312,79314]
name: ti [79332,79334]
===
match
---
operator: = [7605,7606]
operator: = [7633,7634]
===
match
---
trailer [66414,66435]
trailer [66434,66455]
===
match
---
tfpdef [59247,59263]
tfpdef [59267,59283]
===
match
---
parameters [3337,3355]
parameters [3365,3383]
===
match
---
import_from [1033,1117]
import_from [1018,1102]
===
match
---
name: session [40780,40787]
name: session [40800,40807]
===
match
---
trailer [60374,60380]
trailer [60394,60400]
===
match
---
operator: , [55497,55498]
operator: , [55517,55518]
===
match
---
trailer [20855,20861]
trailer [20875,20881]
===
match
---
trailer [34791,34807]
trailer [34811,34827]
===
match
---
trailer [62055,62064]
trailer [62075,62084]
===
match
---
name: pool [54576,54580]
name: pool [54596,54600]
===
match
---
atom_expr [8752,8764]
atom_expr [8780,8792]
===
match
---
argument [29611,29626]
argument [29631,29646]
===
match
---
trailer [55000,55002]
trailer [55020,55022]
===
match
---
simple_stmt [1889,1924]
simple_stmt [1874,1909]
===
match
---
try_stmt [4418,4681]
try_stmt [4446,4709]
===
match
---
name: State [37807,37812]
name: State [37827,37832]
===
match
---
atom_expr [24319,24331]
atom_expr [24339,24351]
===
match
---
name: airflow [2830,2837]
name: airflow [2858,2865]
===
match
---
name: state [65335,65340]
name: state [65355,65360]
===
match
---
not_test [45497,45510]
not_test [45517,45530]
===
match
---
operator: = [55754,55755]
operator: = [55774,55775]
===
match
---
name: ignore_ti_state [15253,15268]
name: ignore_ti_state [15273,15288]
===
match
---
atom_expr [40892,40905]
atom_expr [40912,40925]
===
match
---
name: self [56417,56421]
name: self [56437,56441]
===
match
---
operator: -> [80944,80946]
operator: -> [80964,80966]
===
match
---
name: dag [27710,27713]
name: dag [27730,27733]
===
match
---
atom_expr [51357,51384]
atom_expr [51377,51404]
===
match
---
trailer [20980,20987]
trailer [21000,21007]
===
match
---
name: task [11096,11100]
name: task [11124,11128]
===
match
---
operator: = [39168,39169]
operator: = [39188,39189]
===
match
---
name: self [59420,59424]
name: self [59440,59444]
===
match
---
atom_expr [24890,24900]
atom_expr [24910,24920]
===
match
---
string: "Task successfully registered in smart sensor." [51076,51123]
string: "Task successfully registered in smart sensor." [51096,51143]
===
match
---
operator: , [32850,32851]
operator: , [32870,32871]
===
match
---
name: setattr [66585,66592]
name: setattr [66605,66612]
===
match
---
or_test [32455,32482]
or_test [32475,32502]
===
match
---
name: should_pass_filepath [14785,14805]
name: should_pass_filepath [14805,14825]
===
match
---
param [14349,14363]
param [14369,14383]
===
match
---
trailer [32763,32772]
trailer [32783,32792]
===
match
---
name: self [26240,26244]
name: self [26260,26264]
===
match
---
operator: = [22074,22075]
operator: = [22094,22095]
===
match
---
trailer [70940,70950]
trailer [70960,70970]
===
match
---
atom_expr [78010,78048]
atom_expr [78030,78068]
===
match
---
name: dag_id [26110,26116]
name: dag_id [26130,26136]
===
match
---
testlist_comp [17973,18020]
testlist_comp [17993,18040]
===
match
---
name: default [10064,10071]
name: default [10092,10099]
===
match
---
name: self [60703,60707]
name: self [60723,60727]
===
match
---
param [15974,16003]
param [15994,16023]
===
match
---
expr_stmt [9701,9731]
expr_stmt [9729,9759]
===
match
---
name: self [57189,57193]
name: self [57209,57213]
===
match
---
name: self [24815,24819]
name: self [24835,24839]
===
match
---
arglist [50817,50856]
arglist [50837,50876]
===
match
---
classdef [7955,8799]
classdef [7983,8827]
===
match
---
name: failed [31938,31944]
name: failed [31958,31964]
===
match
---
simple_stmt [81187,81205]
simple_stmt [81207,81225]
===
match
---
funcdef [29723,30359]
funcdef [29743,30379]
===
match
---
name: tis [79008,79011]
name: tis [79028,79031]
===
match
---
atom_expr [65302,65355]
atom_expr [65322,65375]
===
match
---
name: try_number [5567,5577]
name: try_number [5595,5605]
===
match
---
expr_stmt [39947,39970]
expr_stmt [39967,39990]
===
match
---
parameters [77844,77861]
parameters [77864,77881]
===
match
---
param [55207,55219]
param [55227,55239]
===
match
---
operator: = [77916,77917]
operator: = [77936,77937]
===
match
---
operator: = [59402,59403]
operator: = [59422,59423]
===
match
---
atom_expr [44722,44778]
atom_expr [44742,44798]
===
match
---
simple_stmt [11288,11317]
simple_stmt [11316,11345]
===
match
---
name: duration [72905,72913]
name: duration [72925,72933]
===
match
---
operator: == [78958,78960]
operator: == [78978,78980]
===
match
---
operator: , [40635,40636]
operator: , [40655,40656]
===
match
---
operator: , [19052,19053]
operator: , [19072,19073]
===
match
---
simple_stmt [62266,62318]
simple_stmt [62286,62338]
===
match
---
name: dag_run [62645,62652]
name: dag_run [62665,62672]
===
match
---
atom_expr [43068,43128]
atom_expr [43088,43148]
===
match
---
import_from [916,951]
import_from [901,936]
===
match
---
comparison [35027,35059]
comparison [35047,35079]
===
match
---
operator: == [82208,82210]
operator: == [82228,82230]
===
match
---
name: self [58483,58487]
name: self [58503,58507]
===
match
---
atom_expr [11242,11254]
atom_expr [11270,11282]
===
match
---
trailer [32804,32811]
trailer [32824,32831]
===
match
---
comparison [3675,3700]
comparison [3703,3728]
===
match
---
simple_stmt [77114,77184]
simple_stmt [77134,77204]
===
match
---
trailer [44105,44107]
trailer [44125,44127]
===
match
---
operator: , [24753,24754]
operator: , [24773,24774]
===
match
---
param [32356,32361]
param [32376,32381]
===
match
---
trailer [54843,54856]
trailer [54863,54876]
===
match
---
atom_expr [56929,56948]
atom_expr [56949,56968]
===
match
---
name: utils [2393,2398]
name: utils [2378,2383]
===
match
---
atom_expr [43605,43618]
atom_expr [43625,43638]
===
match
---
operator: == [79360,79362]
operator: == [79380,79382]
===
match
---
name: run_id [60101,60107]
name: run_id [60121,60127]
===
match
---
atom_expr [56512,56560]
atom_expr [56532,56580]
===
match
---
name: prev_execution_date [62065,62084]
name: prev_execution_date [62085,62104]
===
match
---
name: t [78895,78896]
name: t [78915,78916]
===
match
---
trailer [41218,41223]
trailer [41238,41243]
===
match
---
param [71850,71857]
param [71870,71877]
===
match
---
fstring_string: __ [62413,62415]
fstring_string: __ [62433,62435]
===
match
---
name: ti [80142,80144]
name: ti [80162,80164]
===
match
---
name: duration [22079,22087]
name: duration [22099,22107]
===
match
---
name: dag_id [62406,62412]
name: dag_id [62426,62432]
===
match
---
operator: , [65152,65153]
operator: , [65172,65173]
===
match
---
name: incr [42905,42909]
name: incr [42925,42929]
===
match
---
name: TaskInstanceKey [24290,24305]
name: TaskInstanceKey [24310,24325]
===
match
---
suite [41305,41390]
suite [41325,41410]
===
match
---
trailer [23908,23914]
trailer [23928,23934]
===
match
---
trailer [24877,24886]
trailer [24897,24906]
===
match
---
expr_stmt [3188,3212]
expr_stmt [3216,3240]
===
match
---
trailer [40874,40881]
trailer [40894,40901]
===
match
---
trailer [22500,22507]
trailer [22520,22527]
===
match
---
atom_expr [79422,79439]
atom_expr [79442,79459]
===
match
---
expr_stmt [24770,24788]
expr_stmt [24790,24808]
===
match
---
name: self [23649,23653]
name: self [23669,23673]
===
match
---
operator: = [6611,6612]
operator: = [6639,6640]
===
match
---
operator: = [9468,9469]
operator: = [9496,9497]
===
match
---
atom_expr [40594,40673]
atom_expr [40614,40693]
===
match
---
atom_expr [26029,26338]
atom_expr [26049,26358]
===
match
---
name: from_string [71166,71177]
name: from_string [71186,71197]
===
match
---
name: self [53014,53018]
name: self [53034,53038]
===
match
---
operator: { [45021,45022]
operator: { [45041,45042]
===
match
---
fstring [19350,19422]
fstring [19370,19442]
===
match
---
name: self [37702,37706]
name: self [37722,37726]
===
match
---
string: """         Refreshes the task instance from the database based on the primary key          :param session: SQLAlchemy ORM Session         :type session: Session         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :type lock_for_update: bool         """ [21096,21489]
string: """         Refreshes the task instance from the database based on the primary key          :param session: SQLAlchemy ORM Session         :type session: Session         :param lock_for_update: if True, indicates that the database should             lock the TaskInstance (issuing a FOR UPDATE clause) until the             session is committed.         :type lock_for_update: bool         """ [21116,21509]
===
match
---
param [26508,26531]
param [26528,26551]
===
match
---
trailer [50816,50857]
trailer [50836,50877]
===
match
---
operator: , [82115,82116]
operator: , [82135,82136]
===
match
---
operator: -> [19913,19915]
operator: -> [19933,19935]
===
match
---
name: name [54618,54622]
name: name [54638,54642]
===
match
---
atom_expr [12588,12602]
atom_expr [12608,12622]
===
match
---
trailer [79424,79439]
trailer [79444,79459]
===
match
---
name: get_k8s_pod_yaml [67387,67403]
name: get_k8s_pod_yaml [67407,67423]
===
match
---
name: running [13152,13159]
name: running [13172,13179]
===
match
---
atom_expr [58745,58755]
atom_expr [58765,58775]
===
match
---
operator: = [15395,15396]
operator: = [15415,15416]
===
match
---
trailer [18445,18452]
trailer [18465,18472]
===
match
---
atom_expr [79363,79373]
atom_expr [79383,79393]
===
match
---
name: commit [45608,45614]
name: commit [45628,45634]
===
match
---
operator: = [39300,39301]
operator: = [39320,39321]
===
match
---
if_stmt [56441,56853]
if_stmt [56461,56873]
===
match
---
name: self [72797,72801]
name: self [72817,72821]
===
match
---
operator: = [59382,59383]
operator: = [59402,59403]
===
match
---
name: pickle [4128,4134]
name: pickle [4156,4162]
===
match
---
param [80766,80770]
param [80786,80790]
===
match
---
atom_expr [22613,22623]
atom_expr [22633,22643]
===
match
---
name: Session [29220,29227]
name: Session [29240,29247]
===
match
---
operator: , [72171,72172]
operator: , [72191,72192]
===
match
---
operator: = [72562,72563]
operator: = [72582,72583]
===
match
---
atom_expr [37834,37874]
atom_expr [37854,37894]
===
match
---
name: rendered_value [66512,66526]
name: rendered_value [66532,66546]
===
match
---
arglist [74123,74158]
arglist [74143,74178]
===
match
---
arglist [31883,31923]
arglist [31903,31943]
===
match
---
name: first_task_id [78985,78998]
name: first_task_id [79005,79018]
===
match
---
or_test [24815,24846]
or_test [24835,24866]
===
match
---
name: DagRun [35503,35509]
name: DagRun [35523,35529]
===
match
---
argument [9840,9849]
argument [9868,9877]
===
match
---
and_test [37745,37820]
and_test [37765,37840]
===
match
---
arglist [46120,46316]
arglist [46140,46336]
===
match
---
operator: , [69011,69012]
operator: , [69031,69032]
===
match
---
import_as_names [2349,2379]
import_as_names [2334,2364]
===
match
---
expr_stmt [13298,13322]
expr_stmt [13318,13342]
===
match
---
atom_expr [79834,79847]
atom_expr [79854,79867]
===
match
---
param [4286,4314]
param [4314,4342]
===
match
---
name: ds_nodash [64729,64738]
name: ds_nodash [64749,64758]
===
match
---
name: ready_for_retry [34862,34877]
name: ready_for_retry [34882,34897]
===
match
---
arglist [40608,40672]
arglist [40628,40692]
===
match
---
trailer [26317,26325]
trailer [26337,26345]
===
match
---
arglist [33897,33960]
arglist [33917,33980]
===
match
---
name: self [21749,21753]
name: self [21769,21773]
===
match
---
name: exc [52319,52322]
name: exc [52339,52342]
===
match
---
name: dag_id [21648,21654]
name: dag_id [21668,21674]
===
match
---
name: os [869,871]
name: os [854,856]
===
match
---
atom_expr [10322,10354]
atom_expr [10350,10382]
===
match
---
name: schedule_tis [47559,47571]
name: schedule_tis [47579,47591]
===
match
---
trailer [68682,68697]
trailer [68702,68717]
===
match
---
string: """         Checks whether the immediate dependents of this task instance have succeeded or have been skipped.         This is meant to be used by wait_for_downstream.          This is useful when you do not want to start processing the next         schedule of a task until the dependents are done. For instance,         if the task DROPs and recreates a table.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [25470,25923]
string: """         Checks whether the immediate dependents of this task instance have succeeded or have been skipped.         This is meant to be used by wait_for_downstream.          This is useful when you do not want to start processing the next         schedule of a task until the dependents are done. For instance,         if the task DROPs and recreates a table.          :param session: SQLAlchemy ORM Session         :type session: Session         """ [25490,25943]
===
match
---
trailer [23547,23563]
trailer [23567,23583]
===
match
---
name: close [54796,54801]
name: close [54816,54821]
===
match
---
if_stmt [18787,18849]
if_stmt [18807,18869]
===
match
---
trailer [20541,20544]
trailer [20561,20564]
===
match
---
string: '' [41608,41610]
string: '' [41628,41630]
===
match
---
simple_stmt [20676,20839]
simple_stmt [20696,20859]
===
match
---
trailer [37812,37820]
trailer [37832,37840]
===
match
---
simple_stmt [41491,41518]
simple_stmt [41511,41538]
===
match
---
funcdef [67166,67728]
funcdef [67186,67748]
===
match
---
name: dag [4763,4766]
name: dag [4791,4794]
===
match
---
atom_expr [62347,62375]
atom_expr [62367,62395]
===
match
---
name: ti [47282,47284]
name: ti [47302,47304]
===
match
---
name: state [29604,29609]
name: state [29624,29629]
===
match
---
name: update [71515,71521]
name: update [71535,71541]
===
match
---
name: task_copy [55023,55032]
name: task_copy [55043,55052]
===
match
---
atom_expr [8291,8310]
atom_expr [8319,8338]
===
match
---
operator: = [11205,11206]
operator: = [11233,11234]
===
match
---
trailer [43214,43222]
trailer [43234,43242]
===
match
---
name: log [1909,1912]
name: log [1894,1897]
===
match
---
name: last_dagrun [27771,27782]
name: last_dagrun [27791,27802]
===
match
---
operator: = [61483,61484]
operator: = [61503,61504]
===
match
---
string: "when Dag Serialization is enabled. Hence for the task that have not yet " [66917,66991]
string: "when Dag Serialization is enabled. Hence for the task that have not yet " [66937,67011]
===
match
---
atom_expr [37673,37684]
atom_expr [37693,37704]
===
match
---
simple_stmt [9736,9761]
simple_stmt [9764,9789]
===
match
---
name: execution_date [21754,21768]
name: execution_date [21774,21788]
===
match
---
name: from_string [72078,72089]
name: from_string [72098,72109]
===
match
---
atom_expr [44446,44468]
atom_expr [44466,44488]
===
match
---
param [4735,4758]
param [4763,4786]
===
match
---
simple_stmt [27227,27239]
simple_stmt [27247,27259]
===
match
---
operator: , [47680,47681]
operator: , [47700,47701]
===
match
---
name: models [7539,7545]
name: models [7567,7573]
===
match
---
name: should_pass_filepath [14663,14683]
name: should_pass_filepath [14683,14703]
===
match
---
trailer [5299,5306]
trailer [5327,5334]
===
match
---
name: self [72731,72735]
name: self [72751,72755]
===
match
---
operator: , [40652,40653]
operator: , [40672,40673]
===
match
---
atom_expr [73063,73076]
atom_expr [73083,73096]
===
match
---
name: base_url [19339,19347]
name: base_url [19359,19367]
===
match
---
name: test_mode [42651,42660]
name: test_mode [42671,42680]
===
match
---
atom_expr [10628,10672]
atom_expr [10656,10700]
===
match
---
expr_stmt [22532,22551]
expr_stmt [22552,22571]
===
match
---
trailer [60235,60239]
trailer [60255,60259]
===
match
---
param [35993,36022]
param [36013,36042]
===
match
---
atom_expr [35528,35547]
atom_expr [35548,35567]
===
match
---
simple_stmt [22647,22689]
simple_stmt [22667,22709]
===
match
---
return_stmt [13855,13878]
return_stmt [13875,13898]
===
match
---
name: self [72992,72996]
name: self [73012,73016]
===
match
---
atom_expr [72217,72270]
atom_expr [72237,72290]
===
match
---
expr_stmt [61971,62012]
expr_stmt [61991,62032]
===
match
---
trailer [32648,32869]
trailer [32668,32889]
===
match
---
trailer [4035,4044]
trailer [4063,4072]
===
match
---
name: Any [80136,80139]
name: Any [80156,80159]
===
match
---
simple_stmt [67207,67252]
simple_stmt [67227,67272]
===
match
---
name: Union [4293,4298]
name: Union [4321,4326]
===
match
---
param [53530,53567]
param [53550,53587]
===
match
---
parameters [59641,59663]
parameters [59661,59683]
===
match
---
parameters [48364,48379]
parameters [48384,48399]
===
match
---
arglist [38228,38477]
arglist [38248,38497]
===
match
---
name: get_failed_dep_statuses [32332,32355]
name: get_failed_dep_statuses [32352,32375]
===
match
---
name: AirflowSmartSensorException [43238,43265]
name: AirflowSmartSensorException [43258,43285]
===
match
---
simple_stmt [8471,8571]
simple_stmt [8499,8599]
===
match
---
atom_expr [54974,55002]
atom_expr [54994,55022]
===
match
---
param [72443,72452]
param [72463,72472]
===
match
---
trailer [35532,35547]
trailer [35552,35567]
===
match
---
simple_stmt [3214,3251]
simple_stmt [3242,3279]
===
match
---
funcdef [50741,51125]
funcdef [50761,51145]
===
match
---
name: AirflowException [66791,66807]
name: AirflowException [66811,66827]
===
match
---
argument [9492,9508]
argument [9520,9536]
===
match
---
atom_expr [82103,82115]
atom_expr [82123,82135]
===
match
---
trailer [19294,19298]
trailer [19314,19318]
===
match
---
name: session [55937,55944]
name: session [55957,55964]
===
match
---
operator: , [55634,55635]
operator: , [55654,55655]
===
match
---
name: ignore_depends_on_past [15201,15223]
name: ignore_depends_on_past [15221,15243]
===
match
---
atom_expr [19409,19420]
atom_expr [19429,19440]
===
match
---
simple_stmt [62707,62932]
simple_stmt [62727,62952]
===
match
---
param [23649,23654]
param [23669,23674]
===
match
---
trailer [68431,68445]
trailer [68451,68465]
===
match
---
name: log [31788,31791]
name: log [31808,31811]
===
match
---
if_stmt [25958,26015]
if_stmt [25978,26035]
===
match
---
expr_stmt [5048,5060]
expr_stmt [5076,5088]
===
match
---
trailer [72651,72657]
trailer [72671,72677]
===
match
---
name: query [82040,82045]
name: query [82060,82065]
===
match
---
string: '' [60110,60112]
string: '' [60130,60132]
===
match
---
name: ignore_all_deps [35760,35775]
name: ignore_all_deps [35780,35795]
===
match
---
trailer [39873,39929]
trailer [39893,39949]
===
match
---
suite [47762,48065]
suite [47782,48085]
===
match
---
atom_expr [52677,52701]
atom_expr [52697,52721]
===
match
---
expr_stmt [76415,76435]
expr_stmt [76435,76455]
===
match
---
expr_stmt [37488,37504]
expr_stmt [37508,37524]
===
match
---
operator: | [32519,32520]
operator: | [32539,32540]
===
match
---
name: dag [27116,27119]
name: dag [27136,27139]
===
match
---
funcdef [14004,15468]
funcdef [14024,15488]
===
match
---
comparison [21718,21768]
comparison [21738,21788]
===
match
---
name: task [52950,52954]
name: task [52970,52974]
===
match
---
trailer [6746,6761]
trailer [6774,6789]
===
match
---
simple_stmt [10239,10274]
simple_stmt [10267,10302]
===
match
---
operator: { [62400,62401]
operator: { [62420,62421]
===
match
---
parameters [59490,59496]
parameters [59510,59516]
===
match
---
suite [41917,45705]
suite [41937,45725]
===
match
---
name: _Variable__NO_DEFAULT_SENTINEL [64358,64388]
name: _Variable__NO_DEFAULT_SENTINEL [64378,64408]
===
match
---
operator: - [70901,70902]
operator: - [70921,70922]
===
match
---
name: command_as_list [14008,14023]
name: command_as_list [14028,14043]
===
match
---
fstring_expr [33059,33071]
fstring_expr [33079,33091]
===
match
---
name: context [51955,51962]
name: context [51975,51982]
===
match
---
simple_stmt [24936,24982]
simple_stmt [24956,25002]
===
match
---
operator: , [18146,18147]
operator: , [18166,18167]
===
match
---
string: """Return task instance primary key part of the key""" [8194,8248]
string: """Return task instance primary key part of the key""" [8222,8276]
===
match
---
name: scheduler_job_id [68829,68845]
name: scheduler_job_id [68849,68865]
===
match
---
atom_expr [55042,55065]
atom_expr [55062,55085]
===
match
---
argument [50594,50607]
argument [50614,50627]
===
match
---
trailer [54948,54953]
trailer [54968,54973]
===
match
---
arglist [30173,30201]
arglist [30193,30221]
===
match
---
simple_stmt [82370,82380]
simple_stmt [82390,82400]
===
match
---
operator: , [58702,58703]
operator: , [58722,58723]
===
match
---
if_stmt [34724,34816]
if_stmt [34744,34836]
===
match
---
name: pool [23296,23300]
name: pool [23316,23320]
===
match
---
atom_expr [9867,9882]
atom_expr [9895,9910]
===
match
---
name: refresh_from_task [11293,11310]
name: refresh_from_task [11321,11338]
===
match
---
trailer [68980,69011]
trailer [69000,69031]
===
match
---
operator: , [66000,66001]
operator: , [66020,66021]
===
match
---
name: hostname [22421,22429]
name: hostname [22441,22449]
===
match
---
name: isoformat [60723,60732]
name: isoformat [60743,60752]
===
match
---
trailer [71027,71133]
trailer [71047,71153]
===
match
---
tfpdef [51955,51971]
tfpdef [51975,51991]
===
match
---
operator: , [4771,4772]
operator: , [4799,4800]
===
match
---
name: task [52918,52922]
name: task [52938,52942]
===
match
---
trailer [53082,53091]
trailer [53102,53111]
===
match
---
simple_stmt [32441,32483]
simple_stmt [32461,32503]
===
match
---
name: ti [79363,79365]
name: ti [79383,79385]
===
match
---
operator: = [50877,50878]
operator: = [50897,50898]
===
match
---
parameters [15511,16085]
parameters [15531,16105]
===
match
---
trailer [9483,9509]
trailer [9511,9537]
===
match
---
name: job_ids [7295,7302]
name: job_ids [7323,7330]
===
match
---
simple_stmt [48186,48257]
simple_stmt [48206,48277]
===
match
---
trailer [7081,7087]
trailer [7109,7115]
===
match
---
operator: { [60066,60067]
operator: { [60086,60087]
===
match
---
name: execution_date [6747,6761]
name: execution_date [6775,6789]
===
match
---
name: self [8596,8600]
name: self [8624,8628]
===
match
---
name: func [26043,26047]
name: func [26063,26067]
===
match
---
name: RenderedTaskInstanceFields [67304,67330]
name: RenderedTaskInstanceFields [67324,67350]
===
match
---
name: job_id [18224,18230]
name: job_id [18244,18250]
===
match
---
trailer [49250,49255]
trailer [49270,49275]
===
match
---
operator: @ [35116,35117]
operator: @ [35136,35137]
===
match
---
trailer [19120,19128]
trailer [19140,19148]
===
match
---
fstring_end: " [33073,33074]
fstring_end: " [33093,33094]
===
match
---
name: email_alert [58795,58806]
name: email_alert [58815,58826]
===
match
---
name: job_id [37678,37684]
name: job_id [37698,37704]
===
match
---
name: state [58200,58205]
name: state [58220,58225]
===
match
---
simple_stmt [9605,9660]
simple_stmt [9633,9688]
===
match
---
simple_stmt [19568,19613]
simple_stmt [19588,19633]
===
match
---
name: String [9780,9786]
name: String [9808,9814]
===
match
---
name: external_trigger [61229,61245]
name: external_trigger [61249,61265]
===
match
---
atom_expr [48315,48324]
atom_expr [48335,48344]
===
match
---
return_stmt [25320,25390]
return_stmt [25340,25410]
===
match
---
expr_stmt [12149,12167]
expr_stmt [12169,12187]
===
match
---
simple_stmt [48835,48874]
simple_stmt [48855,48894]
===
match
---
name: str [63309,63312]
name: str [63329,63332]
===
match
---
trailer [77763,77771]
trailer [77783,77791]
===
match
---
operator: = [59965,59966]
operator: = [59985,59986]
===
match
---
atom_expr [60455,60474]
atom_expr [60475,60494]
===
match
---
name: task [23543,23547]
name: task [23563,23567]
===
match
---
param [51148,51153]
param [51168,51173]
===
match
---
atom_expr [41210,41287]
atom_expr [41230,41307]
===
match
---
argument [76661,76676]
argument [76681,76696]
===
match
---
name: bytes [3926,3931]
name: bytes [3954,3959]
===
match
---
name: Variable [63536,63544]
name: Variable [63556,63564]
===
match
---
operator: , [59183,59184]
operator: , [59203,59204]
===
match
---
operator: = [43603,43604]
operator: = [43623,43624]
===
match
---
name: hr_line_break [40571,40584]
name: hr_line_break [40591,40604]
===
match
---
param [62958,62962]
param [62978,62982]
===
match
---
expr_stmt [26812,26831]
expr_stmt [26832,26851]
===
match
---
name: base_job [7330,7338]
name: base_job [7358,7366]
===
match
---
trailer [32480,32482]
trailer [32500,32502]
===
match
---
argument [74317,74369]
argument [74337,74389]
===
match
---
name: prev_execution_date [61259,61278]
name: prev_execution_date [61279,61298]
===
match
---
name: session [54277,54284]
name: session [54297,54304]
===
match
---
simple_stmt [38170,38492]
simple_stmt [38190,38512]
===
match
---
trailer [70889,70900]
trailer [70909,70920]
===
match
---
number: 0 [78326,78327]
number: 0 [78346,78347]
===
match
---
annassign [79998,80022]
annassign [80018,80042]
===
match
---
name: Optional [29181,29189]
name: Optional [29201,29209]
===
match
---
trailer [73035,73077]
trailer [73055,73097]
===
match
---
atom_expr [23482,23496]
atom_expr [23502,23516]
===
match
---
fstring_start: f" [19752,19754]
fstring_start: f" [19772,19774]
===
match
---
atom_expr [30321,30358]
atom_expr [30341,30378]
===
match
---
dotted_name [2225,2238]
dotted_name [2210,2223]
===
match
---
trailer [61434,61449]
trailer [61454,61469]
===
match
---
name: execution_date [46241,46255]
name: execution_date [46261,46275]
===
match
---
operator: , [64552,64553]
operator: , [64572,64573]
===
match
---
name: self [45115,45119]
name: self [45135,45139]
===
match
---
atom_expr [58598,58644]
atom_expr [58618,58664]
===
match
---
atom_expr [82153,82166]
atom_expr [82173,82186]
===
match
---
name: pickle [4435,4441]
name: pickle [4463,4469]
===
match
---
name: fd [3919,3921]
name: fd [3947,3949]
===
match
---
if_stmt [77309,77370]
if_stmt [77329,77390]
===
match
---
operator: = [11240,11241]
operator: = [11268,11269]
===
match
---
atom_expr [44304,44377]
atom_expr [44324,44397]
===
match
---
expr_stmt [80337,80380]
expr_stmt [80357,80400]
===
match
---
atom_expr [30339,30357]
atom_expr [30359,30377]
===
match
---
name: BaseJob [82673,82680]
name: BaseJob [82693,82700]
===
match
---
operator: , [24331,24332]
operator: , [24351,24352]
===
match
---
simple_stmt [12149,12168]
simple_stmt [12169,12188]
===
match
---
name: on_retry_callback [53339,53356]
name: on_retry_callback [53359,53376]
===
match
---
parameters [63883,63889]
parameters [63903,63909]
===
match
---
name: query [23903,23908]
name: query [23923,23928]
===
match
---
argument [44355,44376]
argument [44375,44396]
===
match
---
operator: } [19376,19377]
operator: } [19396,19397]
===
match
---
atom_expr [64033,64041]
atom_expr [64053,64061]
===
match
---
name: timezone [7935,7943]
name: timezone [7963,7971]
===
match
---
operator: , [56232,56233]
operator: , [56252,56253]
===
match
---
suite [52632,52864]
suite [52652,52884]
===
match
---
name: self [65723,65727]
name: self [65743,65747]
===
match
---
expr_stmt [11227,11254]
expr_stmt [11255,11282]
===
match
---
simple_stmt [2071,2125]
simple_stmt [2056,2110]
===
match
---
atom_expr [29078,29091]
atom_expr [29098,29111]
===
match
---
name: include_prior_dates [76608,76627]
name: include_prior_dates [76628,76647]
===
match
---
trailer [51683,51691]
trailer [51703,51711]
===
match
---
operator: = [30178,30179]
operator: = [30198,30199]
===
match
---
atom_expr [57864,57891]
atom_expr [57884,57911]
===
match
---
name: airflow [3073,3080]
name: airflow [3101,3108]
===
match
---
simple_stmt [40035,40318]
simple_stmt [40055,40338]
===
match
---
simple_stmt [2125,2186]
simple_stmt [2110,2171]
===
match
---
atom_expr [45524,45558]
atom_expr [45544,45578]
===
match
---
name: self [22374,22378]
name: self [22394,22398]
===
match
---
name: task_id_by_key [6134,6148]
name: task_id_by_key [6162,6176]
===
match
---
trailer [76466,76687]
trailer [76486,76707]
===
match
---
arglist [27906,27934]
arglist [27926,27954]
===
match
---
operator: , [3849,3850]
operator: , [3877,3878]
===
match
---
name: e [43359,43360]
name: e [43379,43380]
===
match
---
operator: = [27280,27281]
operator: = [27300,27301]
===
match
---
arglist [10397,10421]
arglist [10425,10449]
===
match
---
suite [18046,18090]
suite [18066,18110]
===
match
---
trailer [36045,36050]
trailer [36065,36070]
===
match
---
trailer [52239,52245]
trailer [52259,52265]
===
match
---
if_stmt [52602,53366]
if_stmt [52622,53386]
===
match
---
operator: , [45550,45551]
operator: , [45570,45571]
===
match
---
simple_stmt [73021,73078]
simple_stmt [73041,73098]
===
match
---
operator: , [57187,57188]
operator: , [57207,57208]
===
match
---
name: Stats [48753,48758]
name: Stats [48773,48778]
===
match
---
name: timezone [56903,56911]
name: timezone [56923,56931]
===
match
---
trailer [30911,30932]
trailer [30931,30952]
===
match
---
trailer [23592,23602]
trailer [23612,23622]
===
match
---
name: is_container [2492,2504]
name: is_container [2477,2489]
===
match
---
trailer [5954,5975]
trailer [5982,6003]
===
match
---
arglist [78760,78919]
arglist [78780,78939]
===
match
---
name: self [20326,20330]
name: self [20346,20350]
===
match
---
operator: = [23541,23542]
operator: = [23561,23562]
===
match
---
tfpdef [15865,15889]
tfpdef [15885,15909]
===
match
---
suite [7443,7483]
suite [7471,7511]
===
match
---
atom_expr [55756,55779]
atom_expr [55776,55799]
===
match
---
trailer [37677,37684]
trailer [37697,37704]
===
match
---
expr_stmt [34143,34192]
expr_stmt [34163,34212]
===
match
---
operator: = [32387,32388]
operator: = [32407,32408]
===
match
---
name: error [53312,53317]
name: error [53332,53337]
===
match
---
atom_expr [21826,21855]
atom_expr [21846,21875]
===
match
---
operator: , [17991,17992]
operator: , [18011,18012]
===
match
---
atom_expr [28531,28553]
atom_expr [28551,28573]
===
match
---
arglist [60155,60166]
arglist [60175,60186]
===
match
---
operator: == [52888,52890]
operator: == [52908,52910]
===
match
---
trailer [67628,67687]
trailer [67648,67707]
===
match
---
trailer [5173,5179]
trailer [5201,5207]
===
match
---
atom_expr [12149,12162]
atom_expr [12169,12182]
===
match
---
name: cmd [18442,18445]
name: cmd [18462,18465]
===
match
---
name: default_html_content [71268,71288]
name: default_html_content [71288,71308]
===
match
---
simple_stmt [18196,18234]
simple_stmt [18216,18254]
===
match
---
simple_stmt [2458,2505]
simple_stmt [2443,2490]
===
match
---
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.value.variable_name }}`` or             ``{{ var.value.get('variable_name', 'fallback') }}``.             """ [62707,62931]
string: """             Wrapper around Variable. This way you can get variables in             templates by using ``{{ var.value.variable_name }}`` or             ``{{ var.value.get('variable_name', 'fallback') }}``.             """ [62727,62951]
===
match
---
atom_expr [22496,22507]
atom_expr [22516,22527]
===
match
---
name: self [8766,8770]
name: self [8794,8798]
===
match
---
name: task [33318,33322]
name: task [33338,33342]
===
match
---
name: session [7259,7266]
name: session [7287,7294]
===
match
---
name: elements [1527,1535]
name: elements [1512,1520]
===
match
---
trailer [40993,40995]
trailer [41013,41015]
===
match
---
name: conf [71937,71941]
name: conf [71957,71961]
===
match
---
expr_stmt [52731,52768]
expr_stmt [52751,52788]
===
match
---
trailer [26295,26327]
trailer [26315,26347]
===
match
---
trailer [13184,13196]
trailer [13204,13216]
===
match
---
suite [80873,80906]
suite [80893,80926]
===
match
---
atom_expr [20973,20989]
atom_expr [20993,21009]
===
match
---
operator: } [66168,66169]
operator: } [66188,66189]
===
match
---
name: quote [19521,19526]
name: quote [19541,19546]
===
match
---
string: 'execution_date' [58550,58566]
string: 'execution_date' [58570,58586]
===
match
---
arglist [56968,57011]
arglist [56988,57031]
===
match
---
name: task_id [20384,20391]
name: task_id [20404,20411]
===
match
---
name: add [55439,55442]
name: add [55459,55462]
===
match
---
name: non_requeueable_dep_context [38566,38593]
name: non_requeueable_dep_context [38586,38613]
===
match
---
name: iso [19131,19134]
name: iso [19151,19154]
===
match
---
parameters [26463,26537]
parameters [26483,26557]
===
match
---
name: self [40594,40598]
name: self [40614,40618]
===
match
---
suite [50794,51125]
suite [50814,51145]
===
match
---
atom_expr [5462,5488]
atom_expr [5490,5516]
===
match
---
suite [30447,30933]
suite [30467,30953]
===
match
---
trailer [47494,47503]
trailer [47514,47523]
===
match
---
name: pool [18652,18656]
name: pool [18672,18676]
===
match
---
operator: , [45896,45897]
operator: , [45916,45917]
===
match
---
atom_expr [24872,24886]
atom_expr [24892,24906]
===
match
---
trailer [40695,40710]
trailer [40715,40730]
===
match
---
simple_stmt [31046,31679]
simple_stmt [31066,31699]
===
match
---
name: self [22647,22651]
name: self [22667,22671]
===
match
---
simple_stmt [67260,67331]
simple_stmt [67280,67351]
===
match
---
name: session [82032,82039]
name: session [82052,82059]
===
match
---
atom_expr [55965,55981]
atom_expr [55985,56001]
===
match
---
name: get_task [47495,47503]
name: get_task [47515,47523]
===
match
---
trailer [29672,29696]
trailer [29692,29716]
===
match
---
name: default [9840,9847]
name: default [9868,9875]
===
match
---
name: get_previous_scheduled_dagrun [27788,27817]
name: get_previous_scheduled_dagrun [27808,27837]
===
match
---
atom_expr [60217,60247]
atom_expr [60237,60267]
===
match
---
operator: = [10570,10571]
operator: = [10598,10599]
===
match
---
trailer [22115,22121]
trailer [22135,22141]
===
match
---
or_test [23303,23329]
or_test [23323,23349]
===
match
---
operator: = [4752,4753]
operator: = [4780,4781]
===
match
---
simple_stmt [11852,11905]
simple_stmt [11880,11933]
===
match
---
trailer [6036,6040]
trailer [6064,6068]
===
match
---
name: task [11275,11279]
name: task [11303,11307]
===
match
---
name: log [47882,47885]
name: log [47902,47905]
===
match
---
name: _prepare_and_execute_task_with_callbacks [48074,48114]
name: _prepare_and_execute_task_with_callbacks [48094,48134]
===
match
---
name: str [4299,4302]
name: str [4327,4330]
===
match
---
operator: , [67962,67963]
operator: , [67982,67983]
===
match
---
simple_stmt [32983,33075]
simple_stmt [33003,33095]
===
match
---
name: dep_name [32764,32772]
name: dep_name [32784,32792]
===
match
---
if_stmt [14660,14904]
if_stmt [14680,14924]
===
match
---
return_stmt [40504,40516]
return_stmt [40524,40536]
===
match
---
trailer [18533,18546]
trailer [18553,18566]
===
match
---
name: conf [67880,67884]
name: conf [67900,67904]
===
match
---
trailer [42817,42826]
trailer [42837,42846]
===
match
---
operator: = [63566,63567]
operator: = [63586,63587]
===
match
---
expr_stmt [10882,11071]
expr_stmt [10910,11099]
===
match
---
simple_stmt [82026,82243]
simple_stmt [82046,82263]
===
match
---
return_stmt [64503,64576]
return_stmt [64523,64596]
===
match
---
trailer [72735,72740]
trailer [72755,72760]
===
insert-tree
---
simple_stmt [2657,2700]
    import_from [2657,2699]
        dotted_name [2662,2684]
            name: airflow [2662,2669]
            name: utils [2670,2675]
            name: platform [2676,2684]
        name: getuser [2692,2699]
to
file_input [787,82682]
at 44
===
insert-node
---
name: TaskInstance [8835,8847]
to
classdef [8801,79491]
at 0
===
insert-tree
---
arglist [8848,8866]
    name: Base [8848,8852]
    operator: , [8852,8853]
    name: LoggingMixin [8854,8866]
to
classdef [8801,79491]
at 1
===
insert-tree
---
simple_stmt [8904,9446]
    string: """     Task instances store the state of a task instance. This table is the     authority and single source of truth around what tasks have run and the     state they are in.      The SqlAlchemy model doesn't have a SqlAlchemy foreign key to the task or     dag model deliberately to have more control over transactions.      Database transactions on this table should insure double triggers and     any confusion around what task instances are or aren't ready to run     even while multiple schedulers may be firing task instances.     """ [8904,9445]
to
suite [8871,79491]
at 0
===
move-tree
---
name: getuser [12082,12089]
to
atom_expr [12074,12091]
at 0
===
delete-tree
---
simple_stmt [805,820]
    import_name [805,819]
        name: getpass [812,819]
===
delete-node
---
name: TaskInstance [8807,8819]
===
===
delete-tree
---
arglist [8820,8838]
    name: Base [8820,8824]
    operator: , [8824,8825]
    name: LoggingMixin [8826,8838]
===
delete-tree
---
simple_stmt [8876,9418]
    string: """     Task instances store the state of a task instance. This table is the     authority and single source of truth around what tasks have run and the     state they are in.      The SqlAlchemy model doesn't have a SqlAlchemy foreign key to the task or     dag model deliberately to have more control over transactions.      Database transactions on this table should insure double triggers and     any confusion around what task instances are or aren't ready to run     even while multiple schedulers may be firing task instances.     """ [8876,9417]
===
delete-node
---
name: getpass [12074,12081]
===
===
delete-node
---
trailer [12081,12089]
===
