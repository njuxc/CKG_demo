===
match
---
name: String [904,910]
name: String [889,895]
===
match
---
name: super [3786,3791]
name: super [3806,3811]
===
match
---
trailer [6884,6886]
trailer [6904,6906]
===
match
---
expr_stmt [2890,3036]
expr_stmt [2918,3064]
===
match
---
param [3265,3279]
param [3293,3307]
===
match
---
name: primaryjoin [2939,2950]
name: primaryjoin [2967,2978]
===
match
---
suite [6818,6928]
suite [6838,6948]
===
match
---
argument [3803,3808]
argument [3823,3828]
===
match
---
name: state [9189,9194]
name: state [9209,9214]
===
match
---
name: session [7769,7776]
name: session [7789,7796]
===
match
---
atom_expr [7529,7588]
atom_expr [7549,7608]
===
match
---
operator: = [3455,3456]
operator: = [3483,3484]
===
match
---
funcdef [3863,4324]
funcdef [3883,4344]
===
match
---
name: ExecutorLoader [1197,1211]
name: ExecutorLoader [1182,1196]
===
match
---
arith_expr [8615,8657]
arith_expr [8635,8677]
===
match
---
name: state [8999,9004]
name: state [9019,9024]
===
match
---
atom_expr [8323,8399]
atom_expr [8343,8419]
===
match
---
arglist [3207,3239]
arglist [3235,3267]
===
match
---
name: kill [7335,7339]
name: kill [7355,7359]
===
match
---
atom_expr [8714,8730]
atom_expr [8734,8750]
===
match
---
name: heartrate [6856,6865]
name: heartrate [6876,6885]
===
match
---
trailer [2568,2614]
trailer [2596,2642]
===
match
---
atom_expr [2317,2330]
atom_expr [2345,2358]
===
match
---
name: Column [2192,2198]
name: Column [2220,2226]
===
match
---
name: latest_heartbeat [7251,7267]
name: latest_heartbeat [7271,7287]
===
match
---
expr_stmt [8755,8781]
expr_stmt [8775,8801]
===
match
---
argument [8114,8129]
argument [8134,8149]
===
match
---
atom_expr [9285,9302]
atom_expr [9305,9322]
===
match
---
trailer [2283,2285]
trailer [2311,2313]
===
match
---
name: heartrate [3595,3604]
name: heartrate [3623,3632]
===
match
---
simple_stmt [3435,3490]
simple_stmt [3463,3518]
===
match
---
atom_expr [2901,3036]
atom_expr [2929,3064]
===
match
---
trailer [5384,5386]
trailer [5404,5406]
===
match
---
trailer [8094,8113]
trailer [8114,8133]
===
match
---
name: self [7431,7435]
name: self [7451,7455]
===
match
---
string: 'job_type_heart' [2569,2585]
string: 'job_type_heart' [2597,2613]
===
match
---
simple_stmt [7470,7607]
simple_stmt [7490,7627]
===
match
---
atom_expr [7635,7660]
atom_expr [7655,7680]
===
match
---
name: state [2657,2662]
name: state [2685,2690]
===
match
---
name: session [5064,5071]
name: session [5084,5091]
===
match
---
name: provide_session [1618,1633]
name: provide_session [1646,1661]
===
match
---
expr_stmt [7623,7660]
expr_stmt [7643,7680]
===
match
---
suite [5740,8546]
suite [5760,8566]
===
match
---
name: self [7886,7890]
name: self [7906,7910]
===
match
---
trailer [3696,3698]
trailer [3716,3718]
===
match
---
tfpdef [5707,5730]
tfpdef [5727,5750]
===
match
---
param [5707,5738]
param [5727,5758]
===
match
---
name: error [5290,5295]
name: error [5310,5315]
===
match
---
operator: == [4773,4775]
operator: == [4793,4795]
===
match
---
simple_stmt [1291,1344]
simple_stmt [1276,1329]
===
match
---
name: merge [9327,9332]
name: merge [9347,9352]
===
match
---
with_stmt [7082,7268]
with_stmt [7102,7288]
===
match
---
simple_stmt [7850,7870]
simple_stmt [7870,7890]
===
match
---
name: taskinstance [1311,1323]
name: taskinstance [1296,1308]
===
match
---
trailer [7196,7202]
trailer [7216,7222]
===
match
---
trailer [4315,4321]
trailer [4335,4341]
===
match
---
expr_stmt [7013,7055]
expr_stmt [7033,7075]
===
match
---
name: ID_LEN [2131,2137]
name: ID_LEN [2159,2165]
===
match
---
atom_expr [8503,8524]
atom_expr [8523,8544]
===
match
---
name: latest_heartbeat [7039,7055]
name: latest_heartbeat [7059,7075]
===
match
---
name: relationship [2901,2913]
name: relationship [2929,2941]
===
match
---
operator: = [3679,3680]
operator: = [3707,3708]
===
match
---
expr_stmt [9111,9137]
expr_stmt [9131,9157]
===
match
---
trailer [8998,9004]
trailer [9018,9024]
===
match
---
name: State [1715,1720]
name: State [1743,1748]
===
match
---
name: __mapper_args__ [2449,2464]
name: __mapper_args__ [2477,2492]
===
match
---
trailer [4766,4772]
trailer [4786,4792]
===
match
---
comparison [2951,2988]
comparison [2979,3016]
===
match
---
name: utils [1581,1586]
name: utils [1609,1614]
===
match
---
try_stmt [8887,9372]
try_stmt [8907,9392]
===
match
---
name: self [6889,6893]
name: self [6909,6913]
===
match
---
trailer [5122,5124]
trailer [5142,5144]
===
match
---
name: self [8256,8260]
name: self [8276,8280]
===
match
---
name: state [2150,2155]
name: state [2178,2183]
===
match
---
name: utcnow [4816,4822]
name: utcnow [4836,4842]
===
match
---
name: self [7246,7250]
name: self [7266,7270]
===
match
---
simple_stmt [8030,8073]
simple_stmt [8050,8093]
===
match
---
atom_expr [7530,7547]
atom_expr [7550,7567]
===
match
---
simple_stmt [5370,5387]
simple_stmt [5390,5407]
===
match
---
operator: , [2585,2586]
operator: , [2613,2614]
===
match
---
param [3883,3887]
param [3903,3907]
===
match
---
expr_stmt [2291,2331]
expr_stmt [2319,2359]
===
match
---
name: latest_heartbeat [7891,7907]
name: latest_heartbeat [7911,7927]
===
match
---
atom_expr [8256,8279]
atom_expr [8276,8299]
===
match
---
trailer [5350,5356]
trailer [5370,5376]
===
match
---
simple_stmt [8503,8546]
simple_stmt [8523,8566]
===
match
---
arglist [2846,2876]
arglist [2874,2904]
===
match
---
param [4965,4977]
param [4985,4997]
===
match
---
trailer [3461,3470]
trailer [3489,3498]
===
match
---
trailer [9332,9338]
trailer [9352,9358]
===
match
---
string: """Callback that is called during heartbeat. This method should be overwritten.""" [5599,5681]
string: """Callback that is called during heartbeat. This method should be overwritten.""" [5619,5701]
===
match
---
suite [7453,7661]
suite [7473,7681]
===
match
---
trailer [8331,8341]
trailer [8351,8361]
===
match
---
name: session [1033,1040]
name: session [1018,1025]
===
match
---
and_test [4762,4913]
and_test [4782,4933]
===
match
---
simple_stmt [8222,8311]
simple_stmt [8242,8331]
===
match
---
operator: ** [3303,3305]
operator: ** [3331,3333]
===
match
---
name: self [8323,8327]
name: self [8343,8347]
===
match
---
name: latest_heartbeat [6801,6817]
name: latest_heartbeat [6821,6837]
===
match
---
import_from [1246,1290]
import_from [1231,1275]
===
match
---
name: order_by [4269,4277]
name: order_by [4289,4297]
===
match
---
simple_stmt [4243,4324]
simple_stmt [4263,4344]
===
match
---
atom_expr [3457,3489]
atom_expr [3485,3517]
===
match
---
name: heartbeat_callback [5551,5569]
name: heartbeat_callback [5571,5589]
===
match
---
trailer [8609,8614]
trailer [8629,8634]
===
match
---
name: Integer [2068,2075]
name: Integer [2096,2103]
===
match
---
string: 'JOB_HEARTBEAT_SEC' [3220,3239]
string: 'JOB_HEARTBEAT_SEC' [3248,3267]
===
match
---
trailer [9293,9300]
trailer [9313,9320]
===
match
---
trailer [8232,8310]
trailer [8252,8330]
===
match
---
name: orm [971,974]
name: orm [956,959]
===
match
---
simple_stmt [9355,9372]
simple_stmt [9375,9392]
===
match
---
import_from [1103,1150]
import_from [1088,1135]
===
match
---
atom_expr [3905,3924]
atom_expr [3925,3944]
===
match
---
name: String [2124,2130]
name: String [2152,2158]
===
match
---
argument [2863,2876]
argument [2891,2904]
===
match
---
operator: = [3564,3565]
operator: = [3592,3593]
===
match
---
name: grace_multiplier [4897,4913]
name: grace_multiplier [4917,4933]
===
match
---
simple_stmt [9319,9339]
simple_stmt [9339,9359]
===
match
---
simple_stmt [6997,7004]
simple_stmt [7017,7024]
===
match
---
arglist [2923,3030]
arglist [2951,3058]
===
match
---
import_from [1525,1567]
import_from [1510,1552]
===
match
---
name: ID_LEN [1278,1284]
name: ID_LEN [1263,1269]
===
match
---
suite [9252,9372]
suite [9272,9392]
===
match
---
name: BaseJob [5078,5085]
name: BaseJob [5098,5105]
===
match
---
operator: = [7244,7245]
operator: = [7264,7265]
===
match
---
import_as_names [982,1012]
import_as_names [967,997]
===
match
---
trailer [2802,2819]
trailer [2830,2847]
===
match
---
name: conf [3732,3736]
name: conf [3752,3756]
===
match
---
name: utcnow [7539,7545]
name: utcnow [7559,7565]
===
match
---
operator: @ [3842,3843]
operator: @ [3862,3863]
===
match
---
string: 'idx_job_state_heartbeat' [2630,2655]
string: 'idx_job_state_heartbeat' [2658,2683]
===
match
---
string: "Job shut down externally." [5418,5445]
string: "Job shut down externally." [5438,5465]
===
match
---
operator: = [2088,2089]
operator: = [2116,2117]
===
match
---
name: Optional [847,855]
name: Optional [832,840]
===
match
---
name: self [9184,9188]
name: self [9204,9208]
===
match
---
number: 0 [7639,7640]
number: 0 [7659,7660]
===
match
---
string: '_start' [8649,8657]
string: '_start' [8669,8677]
===
match
---
name: TaskInstance [1331,1343]
name: TaskInstance [1316,1328]
===
match
---
name: kwargs [3812,3818]
name: kwargs [3832,3838]
===
match
---
import_from [1683,1720]
import_from [1711,1748]
===
match
---
with_item [8714,8741]
with_item [8734,8761]
===
match
---
name: session [9319,9326]
name: session [9339,9346]
===
match
---
dotted_name [1639,1663]
dotted_name [1667,1691]
===
match
---
atom_expr [4762,4772]
atom_expr [4782,4792]
===
match
---
trailer [3791,3793]
trailer [3811,3813]
===
match
---
simple_stmt [2336,2373]
simple_stmt [2364,2401]
===
match
---
name: executor_loader [1174,1189]
name: executor_loader [1159,1174]
===
match
---
operator: = [4364,4365]
operator: = [4384,4385]
===
match
---
name: create_session [1602,1616]
name: create_session [1630,1644]
===
match
---
expr_stmt [2215,2249]
expr_stmt [2243,2277]
===
match
---
name: log [1487,1490]
name: log [1472,1475]
===
match
---
trailer [3574,3581]
trailer [3602,3609]
===
match
---
name: self [9269,9273]
name: self [9289,9293]
===
match
---
name: get_hostname [1555,1567]
name: get_hostname [1540,1552]
===
match
---
simple_stmt [1212,1246]
simple_stmt [1197,1231]
===
match
---
atom_expr [9124,9137]
atom_expr [9144,9157]
===
match
---
name: kill [4954,4958]
name: kill [4974,4978]
===
match
---
atom_expr [8755,8765]
atom_expr [8775,8785]
===
match
---
trailer [3736,3743]
trailer [3756,3763]
===
match
---
trailer [5093,5116]
trailer [5113,5136]
===
match
---
name: self [3435,3439]
name: self [3463,3467]
===
match
---
operator: = [2106,2107]
operator: = [2134,2135]
===
match
---
trailer [2171,2175]
trailer [2199,2203]
===
match
---
simple_stmt [1064,1103]
simple_stmt [1049,1088]
===
match
---
name: __class__ [9397,9406]
name: __class__ [9417,9426]
===
match
---
trailer [6877,6884]
trailer [6897,6904]
===
match
---
name: utcnow [7919,7925]
name: utcnow [7939,7945]
===
match
---
funcdef [5452,5542]
funcdef [5472,5562]
===
match
---
atom_expr [9479,9536]
atom_expr [9499,9556]
===
match
---
atom_expr [2423,2443]
atom_expr [2451,2471]
===
match
---
name: __tablename__ [2029,2042]
name: __tablename__ [2057,2070]
===
match
---
name: self [7284,7288]
name: self [7304,7308]
===
match
---
atom_expr [2563,2614]
atom_expr [2591,2642]
===
match
---
operator: , [5325,5326]
operator: , [5345,5346]
===
match
---
trailer [8638,8644]
trailer [8658,8664]
===
match
---
name: limit [4307,4312]
name: limit [4327,4332]
===
match
---
name: is_alive [4333,4341]
name: is_alive [4353,4361]
===
match
---
expr_stmt [8994,9020]
expr_stmt [9014,9040]
===
match
---
atom_expr [3542,3563]
atom_expr [3570,3591]
===
match
---
name: session [8734,8741]
name: session [8754,8761]
===
match
---
operator: , [8373,8374]
operator: , [8393,8394]
===
match
---
name: latest_heartbeat [2664,2680]
name: latest_heartbeat [2692,2708]
===
match
---
import_from [1064,1102]
import_from [1049,1087]
===
match
---
name: e [5234,5235]
name: e [5254,5255]
===
match
---
operator: , [2075,2076]
operator: , [2103,2104]
===
match
---
with_item [7749,7776]
with_item [7769,7796]
===
match
---
decorated [4929,5447]
decorated [4949,5467]
===
match
---
trailer [9115,9121]
trailer [9135,9141]
===
match
---
name: self [8090,8094]
name: self [8110,8114]
===
match
---
name: utils [1424,1429]
name: utils [1409,1414]
===
match
---
name: String [2395,2401]
name: String [2423,2429]
===
match
---
name: timezone [1402,1410]
name: timezone [1387,1395]
===
match
---
import_from [1291,1343]
import_from [1276,1328]
===
match
---
name: query [4258,4263]
name: query [4278,4283]
===
match
---
atom_expr [5370,5386]
atom_expr [5390,5406]
===
match
---
name: end_date [2254,2262]
name: end_date [2282,2290]
===
match
---
name: self [7550,7554]
name: self [7570,7574]
===
match
---
name: latest_heartbeat [4282,4298]
name: latest_heartbeat [4302,4318]
===
match
---
try_stmt [7065,8546]
try_stmt [7085,8566]
===
match
---
trailer [8055,8072]
trailer [8075,8092]
===
match
---
simple_stmt [955,1013]
simple_stmt [940,998]
===
match
---
arglist [3803,3818]
arglist [3823,3838]
===
match
---
string: "This method needs to be overridden" [9499,9535]
string: "This method needs to be overridden" [9519,9555]
===
match
---
trailer [4884,4894]
trailer [4904,4914]
===
match
---
name: TaskInstance [2742,2754]
name: TaskInstance [2770,2782]
===
match
---
param [3888,3900]
param [3908,3920]
===
match
---
dotted_name [1251,1270]
dotted_name [1236,1255]
===
match
---
import_from [1376,1410]
import_from [1361,1395]
===
match
---
comp_op [3605,3611]
comp_op [3633,3639]
===
match
---
trailer [7435,7452]
trailer [7455,7472]
===
match
---
trailer [7925,7927]
trailer [7945,7947]
===
match
---
name: latest_heartbeat [8056,8072]
name: latest_heartbeat [8076,8092]
===
match
---
atom_expr [2965,2987]
atom_expr [2993,3015]
===
match
---
simple_stmt [1468,1525]
simple_stmt [1453,1510]
===
match
---
operator: ** [3810,3812]
operator: ** [3830,3832]
===
match
---
parameters [8558,8564]
parameters [8578,8584]
===
match
---
simple_stmt [8755,8782]
simple_stmt [8775,8802]
===
match
---
atom_expr [4880,4894]
atom_expr [4900,4914]
===
match
---
simple_stmt [8908,8924]
simple_stmt [8928,8944]
===
match
---
trailer [3546,3563]
trailer [3574,3591]
===
match
---
simple_stmt [3181,3241]
simple_stmt [3209,3269]
===
match
---
dotted_name [1069,1090]
dotted_name [1054,1075]
===
match
---
number: 1 [9434,9435]
number: 1 [9454,9455]
===
match
---
name: latest_heartbeat [3547,3563]
name: latest_heartbeat [3575,3591]
===
match
---
trailer [7101,7103]
trailer [7121,7123]
===
match
---
name: self [5281,5285]
name: self [5301,5305]
===
match
---
operator: = [7908,7909]
operator: = [7928,7929]
===
match
---
name: timezone [9285,9293]
name: timezone [9305,9313]
===
match
---
simple_stmt [5191,5206]
simple_stmt [5211,5226]
===
match
---
name: unixname [3670,3678]
name: unixname [3698,3706]
===
match
---
simple_stmt [3630,3657]
simple_stmt [3658,3685]
===
match
---
argument [2939,2988]
argument [2967,3016]
===
match
---
expr_stmt [3361,3426]
expr_stmt [3389,3454]
===
match
---
name: sqlalchemy [862,872]
name: sqlalchemy [847,857]
===
match
---
name: timezone [5148,5156]
name: timezone [5168,5176]
===
match
---
name: first [4316,4321]
name: first [4336,4341]
===
match
---
operator: , [1616,1617]
operator: , [1644,1645]
===
match
---
atom_expr [2310,2331]
atom_expr [2338,2359]
===
match
---
operator: , [893,894]
operator: , [878,879]
===
match
---
trailer [3802,3819]
trailer [3822,3839]
===
match
---
trailer [7554,7571]
trailer [7574,7591]
===
match
---
trailer [7586,7588]
trailer [7606,7608]
===
match
---
atom_expr [2124,2138]
atom_expr [2152,2166]
===
match
---
comparison [3595,3616]
comparison [3623,3644]
===
match
---
number: 2.1 [4365,4368]
number: 2.1 [4385,4388]
===
match
---
name: latest_heartbeat [7436,7452]
name: latest_heartbeat [7456,7472]
===
match
---
name: airflow [1639,1646]
name: airflow [1667,1674]
===
match
---
name: getint [3737,3743]
name: getint [3757,3763]
===
match
---
dotted_name [1108,1126]
dotted_name [1093,1111]
===
match
---
name: NotImplementedError [9479,9498]
name: NotImplementedError [9499,9518]
===
match
---
name: Column [2310,2316]
name: Column [2338,2344]
===
match
---
operator: - [6866,6867]
operator: - [6886,6887]
===
match
---
parameters [5463,5469]
parameters [5483,5489]
===
match
---
file_input [790,9537]
file_input [790,9557]
===
match
---
name: utcnow [9294,9300]
name: utcnow [9314,9320]
===
match
---
funcdef [4329,4924]
funcdef [4349,4944]
===
match
---
simple_stmt [3934,4235]
simple_stmt [3954,4255]
===
match
---
atom_expr [2388,2407]
atom_expr [2416,2435]
===
match
---
atom_expr [7087,7103]
atom_expr [7107,7123]
===
match
---
simple_stmt [7189,7209]
simple_stmt [7209,7229]
===
match
---
simple_stmt [5133,5166]
simple_stmt [5153,5186]
===
match
---
trailer [8921,8923]
trailer [8941,8943]
===
match
---
argument [2764,2820]
argument [2792,2848]
===
match
---
trailer [2845,2877]
trailer [2873,2905]
===
match
---
dotted_name [1018,1040]
dotted_name [1003,1025]
===
match
---
name: primary_key [2077,2088]
name: primary_key [2105,2116]
===
match
---
name: stats [1357,1362]
name: stats [1342,1347]
===
match
---
name: unixname [2412,2420]
name: unixname [2440,2448]
===
match
---
atom_expr [5108,5115]
atom_expr [5128,5135]
===
match
---
name: utils [1538,1543]
name: utils [1523,1528]
===
match
---
import_from [828,855]
import_from [813,840]
===
match
---
string: 'polymorphic_identity' [2496,2518]
string: 'polymorphic_identity' [2524,2546]
===
match
---
name: job [5357,5360]
name: job [5377,5380]
===
match
---
simple_stmt [1683,1721]
simple_stmt [1711,1749]
===
match
---
name: latest_heartbeat [2597,2613]
name: latest_heartbeat [2625,2641]
===
match
---
name: self [4762,4766]
name: self [4782,4786]
===
match
---
atom_expr [8051,8072]
atom_expr [8071,8092]
===
match
---
operator: < [4878,4879]
operator: < [4898,4899]
===
match
---
name: incr [8610,8614]
name: incr [8630,8634]
===
match
---
name: query [5072,5077]
name: query [5092,5097]
===
match
---
expr_stmt [2181,2210]
expr_stmt [2209,2238]
===
match
---
name: latest_heartbeat [7555,7571]
name: latest_heartbeat [7575,7591]
===
match
---
trailer [8270,8279]
trailer [8290,8299]
===
match
---
name: max_tis_per_query [3712,3729]
name: max_tis_per_query [3732,3749]
===
match
---
expr_stmt [8030,8072]
expr_stmt [8050,8092]
===
match
---
trailer [8619,8629]
trailer [8639,8649]
===
match
---
expr_stmt [6763,6784]
expr_stmt [6783,6804]
===
match
---
name: __name__ [8390,8398]
name: __name__ [8410,8418]
===
match
---
simple_stmt [5599,5682]
simple_stmt [5619,5702]
===
match
---
atom_expr [4250,4323]
atom_expr [4270,4343]
===
match
---
expr_stmt [7402,7415]
expr_stmt [7422,7435]
===
match
---
operator: = [2190,2191]
operator: = [2218,2219]
===
match
---
name: String [2199,2205]
name: String [2227,2233]
===
match
---
expr_stmt [3630,3656]
expr_stmt [3658,3684]
===
match
---
name: self [8615,8619]
name: self [8635,8639]
===
match
---
arith_expr [8233,8303]
arith_expr [8253,8323]
===
match
---
argument [2998,3029]
argument [3026,3057]
===
match
---
decorated [3825,4324]
decorated [3845,4344]
===
match
---
name: session [8114,8121]
name: session [8134,8141]
===
match
---
string: 'on_kill() method failed: %s' [5296,5325]
string: 'on_kill() method failed: %s' [5316,5345]
===
match
---
name: latest_heartbeat [2291,2307]
name: latest_heartbeat [2319,2335]
===
match
---
trailer [5295,5334]
trailer [5315,5354]
===
match
---
simple_stmt [3665,3699]
simple_stmt [3693,3719]
===
match
---
trailer [9396,9406]
trailer [9416,9426]
===
match
---
atom_expr [6868,6927]
atom_expr [6888,6947]
===
match
---
name: _execute [8913,8921]
name: _execute [8933,8941]
===
match
---
atom_expr [7550,7571]
atom_expr [7570,7591]
===
match
---
trailer [5136,5145]
trailer [5156,5165]
===
match
---
trailer [4306,4312]
trailer [4326,4332]
===
match
---
trailer [8759,8765]
trailer [8779,8785]
===
match
---
atom_expr [9197,9209]
atom_expr [9217,9229]
===
match
---
name: foreign [991,998]
name: foreign [976,983]
===
match
---
atom_expr [8824,8840]
atom_expr [8844,8860]
===
match
---
trailer [2964,2988]
trailer [2992,3016]
===
match
---
name: self [8755,8759]
name: self [8775,8779]
===
match
---
trailer [7250,7267]
trailer [7270,7287]
===
match
---
name: airflow [1296,1303]
name: airflow [1281,1288]
===
match
---
name: conf [3193,3197]
name: conf [3221,3225]
===
match
---
trailer [4263,4268]
trailer [4283,4288]
===
match
---
trailer [4863,4865]
trailer [4883,4885]
===
match
---
name: timezone [6869,6877]
name: timezone [6889,6897]
===
match
---
simple_stmt [2694,2885]
simple_stmt [2722,2913]
===
match
---
name: on_kill [5456,5463]
name: on_kill [5476,5483]
===
match
---
trailer [7918,7925]
trailer [7938,7945]
===
match
---
name: seconds_remaining [6763,6780]
name: seconds_remaining [6783,6800]
===
match
---
simple_stmt [9473,9537]
simple_stmt [9493,9557]
===
match
---
name: Column [880,886]
name: Column [865,871]
===
match
---
parameters [3882,3901]
parameters [3902,3921]
===
match
---
name: __init__ [3794,3802]
name: __init__ [3814,3822]
===
match
---
trailer [5285,5289]
trailer [5305,5309]
===
match
---
operator: , [2494,2495]
operator: , [2522,2523]
===
match
---
string: 'queued_by_job' [2846,2861]
string: 'queued_by_job' [2874,2889]
===
match
---
operator: = [2465,2466]
operator: = [2493,2494]
===
match
---
string: "%s heartbeat got an exception" [8342,8373]
string: "%s heartbeat got an exception" [8362,8393]
===
match
---
name: sleep_for [7402,7411]
name: sleep_for [7422,7431]
===
match
---
comparison [4762,4789]
comparison [4782,4809]
===
match
---
name: backref [982,989]
name: backref [967,974]
===
match
---
atom_expr [2838,2877]
atom_expr [2866,2905]
===
match
---
expr_stmt [5133,5165]
expr_stmt [5153,5185]
===
match
---
name: sleep_for [7679,7688]
name: sleep_for [7699,7708]
===
match
---
name: dag_id [2099,2105]
name: dag_id [2127,2133]
===
match
---
name: models [1225,1231]
name: models [1210,1216]
===
match
---
trailer [4268,4277]
trailer [4288,4297]
===
match
---
atom_expr [5148,5165]
atom_expr [5168,5185]
===
match
---
try_stmt [5174,5335]
try_stmt [5194,5355]
===
match
---
name: seconds_remaining [6940,6957]
name: seconds_remaining [6960,6977]
===
match
---
name: previous_heartbeat [7013,7031]
name: previous_heartbeat [7033,7051]
===
match
---
operator: = [8525,8526]
operator: = [8545,8546]
===
match
---
string: 'creating_job' [3014,3028]
string: 'creating_job' [3042,3056]
===
match
---
funcdef [3246,3820]
funcdef [3274,3840]
===
match
---
name: session [4250,4257]
name: session [4270,4277]
===
match
---
operator: = [7412,7413]
operator: = [7432,7433]
===
match
---
name: SUCCESS [9013,9020]
name: SUCCESS [9033,9040]
===
match
---
parameters [5700,5739]
parameters [5720,5759]
===
match
---
name: self [7034,7038]
name: self [7054,7058]
===
match
---
name: RUNNING [8774,8781]
name: RUNNING [8794,8801]
===
match
---
name: SUCCESS [9130,9137]
name: SUCCESS [9150,9157]
===
match
---
name: net [1544,1547]
name: net [1529,1532]
===
match
---
atom_expr [7298,7312]
atom_expr [7318,7332]
===
match
---
trailer [2429,2443]
trailer [2457,2471]
===
match
---
simple_stmt [8824,8841]
simple_stmt [8844,8861]
===
match
---
dotted_name [1473,1504]
dotted_name [1458,1489]
===
match
---
trailer [3502,3513]
trailer [3530,3541]
===
match
---
name: only_if_necessary [5707,5724]
name: only_if_necessary [5727,5744]
===
match
---
dotted_name [1217,1231]
dotted_name [1202,1216]
===
match
---
name: self [5464,5468]
name: self [5484,5488]
===
match
---
name: airflow [1530,1537]
name: airflow [1515,1522]
===
match
---
operator: , [4346,4347]
operator: , [4366,4367]
===
match
---
suite [7115,7268]
suite [7135,7288]
===
match
---
name: Column [2423,2429]
name: Column [2451,2457]
===
match
---
operator: , [8303,8304]
operator: , [8323,8324]
===
match
---
name: self [8806,8810]
name: self [8826,8830]
===
match
---
trailer [2436,2442]
trailer [2464,2470]
===
match
---
simple_stmt [4988,5050]
simple_stmt [5008,5070]
===
match
---
operator: * [3803,3804]
operator: * [3823,3824]
===
match
---
trailer [9326,9332]
trailer [9346,9352]
===
match
---
atom_expr [6796,6817]
atom_expr [6816,6837]
===
match
---
operator: , [2138,2139]
operator: , [2166,2167]
===
match
---
name: Stats [9381,9386]
name: Stats [9401,9406]
===
match
---
operator: == [7295,7297]
operator: == [7315,7317]
===
match
---
suite [7777,8177]
suite [7797,8197]
===
match
---
operator: + [9424,9425]
operator: + [9444,9445]
===
match
---
atom_expr [2790,2819]
atom_expr [2818,2847]
===
match
---
name: kwargs [3305,3311]
name: kwargs [3333,3339]
===
match
---
arglist [8233,8309]
arglist [8253,8329]
===
match
---
suite [3313,3820]
suite [3341,3840]
===
match
---
operator: - [6887,6888]
operator: - [6907,6908]
===
match
---
name: self [7512,7516]
name: self [7532,7536]
===
match
---
atom_expr [3681,3698]
atom_expr [3709,3718]
===
match
---
name: convert_camel_to_snake [1445,1467]
name: convert_camel_to_snake [1430,1452]
===
match
---
atom_expr [5064,5124]
atom_expr [5084,5144]
===
match
---
name: models [1304,1310]
name: models [1289,1295]
===
match
---
name: Index [2563,2568]
name: Index [2591,2596]
===
match
---
simple_stmt [7225,7268]
simple_stmt [7245,7288]
===
match
---
name: log [8152,8155]
name: log [8172,8175]
===
match
---
except_clause [5214,5235]
except_clause [5234,5255]
===
match
---
name: log [5286,5289]
name: log [5306,5309]
===
match
---
atom_expr [2061,2094]
atom_expr [2089,2122]
===
match
---
dictorsetmaker [2468,2529]
dictorsetmaker [2496,2557]
===
match
---
string: """Will be called when an external kill command is received""" [5479,5541]
string: """Will be called when an external kill command is received""" [5499,5561]
===
match
---
name: BaseJob [5094,5101]
name: BaseJob [5114,5121]
===
match
---
name: airflow [1156,1163]
name: airflow [1141,1148]
===
match
---
atom_expr [9111,9121]
atom_expr [9131,9141]
===
match
---
comparison [5094,5115]
comparison [5114,5135]
===
match
---
name: AirflowException [1134,1150]
name: AirflowException [1119,1135]
===
match
---
raise_stmt [5395,5446]
raise_stmt [5415,5466]
===
match
---
name: self [3707,3711]
name: self [3727,3731]
===
match
---
name: on_kill [5196,5203]
name: on_kill [5216,5223]
===
match
---
testlist_comp [2563,2682]
testlist_comp [2591,2710]
===
match
---
param [4959,4964]
param [4979,4984]
===
match
---
operator: = [2837,2838]
operator: = [2865,2866]
===
match
---
operator: , [8660,8661]
operator: , [8680,8681]
===
match
---
string: """         Return the most recent job of this type, if any, based on last         heartbeat received.          This method should be called on a subclass (i.e. on SchedulerJob) to         return jobs of that type.          :param session: Database session         :rtype: BaseJob or None         """ [3934,4234]
string: """         Return the most recent job of this type, if any, based on last         heartbeat received.          This method should be called on a subclass (i.e. on SchedulerJob) to         return jobs of that type.          :param session: Database session         :rtype: BaseJob or None         """ [3954,4254]
===
match
---
trailer [3013,3029]
trailer [3041,3057]
===
match
---
decorators [3825,3859]
decorators [3845,3879]
===
match
---
atom_expr [7431,7452]
atom_expr [7451,7472]
===
match
---
param [9458,9462]
param [9478,9482]
===
match
---
name: primaryjoin [2764,2775]
name: primaryjoin [2792,2803]
===
match
---
trailer [5417,5446]
trailer [5437,5466]
===
match
---
name: state [1702,1707]
name: state [1730,1735]
===
match
---
string: 'scheduler' [3207,3218]
string: 'scheduler' [3235,3246]
===
match
---
name: OperationalError [938,954]
name: OperationalError [923,939]
===
match
---
name: exception [8332,8341]
name: exception [8352,8361]
===
match
---
parameters [5569,5589]
parameters [5589,5609]
===
match
---
operator: = [4972,4973]
operator: = [4992,4993]
===
match
---
trailer [9421,9423]
trailer [9441,9443]
===
match
---
trailer [2198,2210]
trailer [2226,2238]
===
match
---
operator: = [6781,6782]
operator: = [6801,6802]
===
match
---
atom [6868,6911]
atom [6888,6931]
===
match
---
name: airflow [1573,1580]
name: airflow [1601,1608]
===
match
---
trailer [9202,9209]
trailer [9222,9229]
===
match
---
trailer [4849,4863]
trailer [4869,4883]
===
match
---
import_from [1212,1245]
import_from [1197,1230]
===
match
---
trailer [2401,2406]
trailer [2429,2434]
===
match
---
name: utils [1647,1652]
name: utils [1675,1680]
===
match
---
atom_expr [3361,3374]
atom_expr [3389,3402]
===
match
---
trailer [8113,8130]
trailer [8133,8150]
===
match
---
atom_expr [5094,5104]
atom_expr [5114,5124]
===
match
---
operator: , [902,903]
operator: , [887,888]
===
match
---
name: end_date [9274,9282]
name: end_date [9294,9302]
===
match
---
atom_expr [3338,3352]
atom_expr [3366,3380]
===
match
---
operator: = [3336,3337]
operator: = [3364,3365]
===
match
---
name: state [7289,7294]
name: state [7309,7314]
===
match
---
atom_expr [7189,7208]
atom_expr [7209,7228]
===
match
---
import_from [1568,1633]
import_from [1596,1661]
===
match
---
atom_expr [5133,5145]
atom_expr [5153,5165]
===
match
---
trailer [8805,8811]
trailer [8825,8831]
===
match
---
name: session [7944,7951]
name: session [7964,7971]
===
match
---
name: airflow [1473,1480]
name: airflow [1458,1465]
===
match
---
operator: = [5146,5147]
operator: = [5166,5167]
===
match
---
name: id [2056,2058]
name: id [2084,2086]
===
match
---
name: incr [9387,9391]
name: incr [9407,9411]
===
match
---
name: self [3361,3365]
name: self [3389,3393]
===
match
---
operator: + [8647,8648]
operator: + [8667,8668]
===
match
---
operator: = [2351,2352]
operator: = [2379,2380]
===
match
---
operator: = [8766,8767]
operator: = [8786,8787]
===
match
---
atom_expr [9184,9194]
atom_expr [9204,9214]
===
match
---
operator: , [2988,2989]
operator: , [3016,3017]
===
match
---
name: job_type [2486,2494]
name: job_type [2514,2522]
===
match
---
name: commit [7952,7958]
name: commit [7972,7978]
===
match
---
simple_stmt [1634,1683]
simple_stmt [1662,1711]
===
match
---
arith_expr [6851,6927]
arith_expr [6871,6947]
===
match
---
name: executor [3366,3374]
name: executor [3394,3402]
===
match
---
name: UtcDateTime [2235,2246]
name: UtcDateTime [2263,2274]
===
match
---
name: _execute [9449,9457]
name: _execute [9469,9477]
===
match
---
operator: = [2386,2387]
operator: = [2414,2415]
===
match
---
parameters [4958,4978]
parameters [4978,4998]
===
match
---
operator: = [2156,2157]
operator: = [2184,2185]
===
match
---
comparison [4806,4913]
comparison [4826,4933]
===
match
---
name: session [5343,5350]
name: session [5363,5370]
===
match
---
trailer [3470,3480]
trailer [3498,3508]
===
match
---
name: UtcDateTime [2317,2328]
name: UtcDateTime [2345,2356]
===
match
---
operator: = [2551,2552]
operator: = [2579,2580]
===
match
---
name: State [9007,9012]
name: State [9027,9032]
===
match
---
arith_expr [9392,9432]
arith_expr [9412,9452]
===
match
---
arglist [2569,2613]
arglist [2597,2641]
===
match
---
number: 0 [6783,6784]
number: 0 [6803,6804]
===
match
---
name: id [2776,2778]
name: id [2804,2806]
===
match
---
trailer [5377,5384]
trailer [5397,5404]
===
match
---
name: utils [1696,1701]
name: utils [1724,1729]
===
match
---
name: utcnow [3525,3531]
name: utcnow [3553,3559]
===
match
---
name: session [4965,4972]
name: session [4985,4992]
===
match
---
name: State [4776,4781]
name: State [4796,4801]
===
match
---
if_stmt [7281,7342]
if_stmt [7301,7362]
===
match
---
name: Column [2108,2114]
name: Column [2136,2142]
===
match
---
operator: = [3514,3515]
operator: = [3542,3543]
===
match
---
simple_stmt [3542,3584]
simple_stmt [3570,3612]
===
match
---
trailer [9415,9421]
trailer [9435,9441]
===
match
---
name: AirflowException [5401,5417]
name: AirflowException [5421,5437]
===
match
---
trailer [3524,3531]
trailer [3552,3559]
===
match
---
name: self [3322,3326]
name: self [3350,3354]
===
match
---
funcdef [8551,9440]
funcdef [8571,9460]
===
match
---
simple_stmt [8794,8812]
simple_stmt [8814,8832]
===
match
---
name: models [1259,1265]
name: models [1244,1250]
===
match
---
arith_expr [7512,7588]
arith_expr [7532,7608]
===
match
---
trailer [2067,2094]
trailer [2095,2122]
===
match
---
operator: = [3375,3376]
operator: = [3403,3404]
===
match
---
atom_expr [3389,3426]
atom_expr [3417,3454]
===
match
---
expr_stmt [3322,3352]
expr_stmt [3350,3380]
===
match
---
name: FAILED [9203,9209]
name: FAILED [9223,9229]
===
match
---
suite [5268,5335]
suite [5288,5355]
===
match
---
operator: , [2929,2930]
operator: , [2957,2958]
===
match
---
name: backref [2998,3005]
name: backref [3026,3033]
===
match
---
trailer [9369,9371]
trailer [9389,9391]
===
match
---
name: SHUTDOWN [7304,7312]
name: SHUTDOWN [7324,7332]
===
match
---
atom [7490,7606]
atom [7510,7626]
===
match
---
operator: - [7527,7528]
operator: - [7547,7548]
===
match
---
operator: = [7633,7634]
operator: = [7653,7654]
===
match
---
atom [4806,4849]
atom [4826,4869]
===
match
---
atom_expr [2199,2209]
atom_expr [2227,2237]
===
match
---
name: latest_heartbeat [6894,6910]
name: latest_heartbeat [6914,6930]
===
match
---
atom_expr [8090,8130]
atom_expr [8110,8150]
===
match
---
trailer [8773,8781]
trailer [8793,8801]
===
match
---
atom_expr [3566,3583]
atom_expr [3594,3611]
===
match
---
name: task_instances_enqueued [2694,2717]
name: task_instances_enqueued [2722,2745]
===
match
---
name: executor [3265,3273]
name: executor [3293,3301]
===
match
---
operator: = [2899,2900]
operator: = [2927,2928]
===
match
---
classdef [1723,9537]
classdef [1751,9557]
===
match
---
trailer [3350,3352]
trailer [3378,3380]
===
match
---
number: 1 [8662,8663]
number: 1 [8682,8683]
===
match
---
name: self [8503,8507]
name: self [8523,8527]
===
match
---
name: sleep [7673,7678]
name: sleep [7693,7698]
===
match
---
operator: , [2614,2615]
operator: , [2642,2643]
===
match
---
name: heartbeat [5691,5700]
name: heartbeat [5711,5720]
===
match
---
atom_expr [7886,7907]
atom_expr [7906,7927]
===
match
---
param [8559,8563]
param [8579,8583]
===
match
---
dotted_name [960,974]
dotted_name [945,959]
===
match
---
trailer [3197,3206]
trailer [3225,3234]
===
match
---
atom_expr [8853,8873]
atom_expr [8873,8893]
===
match
---
trailer [8161,8176]
trailer [8181,8196]
===
match
---
expr_stmt [3665,3698]
expr_stmt [3693,3718]
===
match
---
import_from [1013,1062]
import_from [998,1047]
===
match
---
import_from [1634,1682]
import_from [1662,1710]
===
match
---
name: __name__ [3481,3489]
name: __name__ [3509,3517]
===
match
---
operator: = [2263,2264]
operator: = [2291,2292]
===
match
---
string: 'max_tis_per_query' [3757,3776]
string: 'max_tis_per_query' [3777,3796]
===
match
---
name: Exception [5221,5230]
name: Exception [5241,5250]
===
match
---
trailer [3424,3426]
trailer [3452,3454]
===
match
---
trailer [8151,8155]
trailer [8171,8175]
===
match
---
name: convert_camel_to_snake [8233,8255]
name: convert_camel_to_snake [8253,8275]
===
match
---
atom_expr [2395,2406]
atom_expr [2423,2434]
===
match
---
name: orm [1029,1032]
name: orm [1014,1017]
===
match
---
operator: , [5705,5706]
operator: , [5725,5726]
===
match
---
suite [1757,9537]
suite [1785,9557]
===
match
---
name: State [9124,9129]
name: State [9144,9149]
===
match
---
expr_stmt [7470,7606]
expr_stmt [7490,7626]
===
match
---
name: utcnow [6878,6884]
name: utcnow [6898,6904]
===
match
---
trailer [9188,9194]
trailer [9208,9214]
===
match
---
simple_stmt [5395,5447]
simple_stmt [5415,5467]
===
match
---
name: previous_heartbeat [8527,8545]
name: previous_heartbeat [8547,8565]
===
match
---
trailer [4298,4303]
trailer [4318,4323]
===
match
---
name: lower [9416,9421]
name: lower [9436,9441]
===
match
---
atom_expr [4807,4824]
atom_expr [4827,4844]
===
match
---
simple_stmt [7013,7056]
simple_stmt [7033,7076]
===
match
---
atom [2553,2688]
atom [2581,2716]
===
match
---
name: commit [9363,9369]
name: commit [9383,9389]
===
match
---
atom_expr [8908,8923]
atom_expr [8928,8943]
===
match
---
number: 1 [8659,8660]
number: 1 [8679,8680]
===
match
---
trailer [2205,2209]
trailer [2233,2237]
===
match
---
simple_stmt [5281,5335]
simple_stmt [5301,5355]
===
match
---
trailer [8912,8921]
trailer [8932,8941]
===
match
---
decorator [4929,4946]
decorator [4949,4966]
===
match
---
name: State [9197,9202]
name: State [9217,9222]
===
match
---
name: State [7298,7303]
name: State [7318,7323]
===
match
---
funcdef [5687,8546]
funcdef [5707,8566]
===
match
---
atom_expr [2158,2176]
atom_expr [2186,2204]
===
match
---
import_as_names [880,910]
import_as_names [865,895]
===
match
---
simple_stmt [1376,1411]
simple_stmt [1361,1396]
===
match
---
simple_stmt [1411,1468]
simple_stmt [1396,1453]
===
match
---
simple_stmt [9269,9303]
simple_stmt [9289,9323]
===
match
---
name: String [2360,2366]
name: String [2388,2394]
===
match
---
with_item [7087,7114]
with_item [7107,7134]
===
match
---
string: '_end' [9426,9432]
string: '_end' [9446,9452]
===
match
---
dotted_name [916,930]
dotted_name [901,915]
===
match
---
trailer [5077,5086]
trailer [5097,5106]
===
match
---
trailer [8507,8524]
trailer [8527,8544]
===
match
---
name: end_date [5137,5145]
name: end_date [5157,5165]
===
match
---
trailer [7863,7869]
trailer [7883,7889]
===
match
---
trailer [4257,4263]
trailer [4277,4283]
===
match
---
atom_expr [3732,3777]
atom_expr [3752,3797]
===
match
---
simple_stmt [857,911]
simple_stmt [842,896]
===
match
---
name: SystemExit [9040,9050]
name: SystemExit [9060,9070]
===
match
---
operator: -> [3902,3904]
operator: -> [3922,3924]
===
match
---
suite [8891,9021]
suite [8911,9041]
===
match
---
trailer [4303,4305]
trailer [4323,4325]
===
match
---
number: 0 [6960,6961]
number: 0 [6980,6981]
===
match
---
argument [2077,2093]
argument [2105,2121]
===
match
---
name: Column [2228,2234]
name: Column [2256,2262]
===
match
---
simple_stmt [1246,1291]
simple_stmt [1231,1276]
===
match
---
name: getuser [3689,3696]
name: getuser [3709,3716]
===
match
---
simple_stmt [3707,3778]
simple_stmt [3727,3798]
===
match
---
operator: , [3029,3030]
operator: , [3057,3058]
===
match
---
simple_stmt [2150,2177]
simple_stmt [2178,2205]
===
match
---
trailer [7857,7863]
trailer [7877,7883]
===
match
---
trailer [7890,7907]
trailer [7910,7927]
===
match
---
name: String [2165,2171]
name: String [2193,2199]
===
match
---
operator: = [5731,5732]
operator: = [5751,5752]
===
match
---
trailer [7202,7208]
trailer [7222,7228]
===
match
---
atom_expr [7034,7055]
atom_expr [7054,7075]
===
match
---
atom_expr [5191,5205]
atom_expr [5211,5225]
===
match
---
trailer [8155,8161]
trailer [8175,8181]
===
match
---
trailer [8389,8398]
trailer [8409,8418]
===
match
---
name: __name__ [9407,9415]
name: __name__ [9427,9435]
===
match
---
name: get_hostname [3338,3350]
name: get_hostname [3366,3378]
===
match
---
string: """         Is this job currently alive.          We define alive as in a state of RUNNING, and having sent a heartbeat         within a multiple of the heartrate (default of 2.1)          :param grace_multiplier: multiplier of heartrate to require heart beat             within         :type grace_multiplier: number         :rtype: boolean         """ [4379,4732]
string: """         Is this job currently alive.          We define alive as in a state of RUNNING, and having sent a heartbeat         within a multiple of the heartrate (default of 2.1)          :param grace_multiplier: multiplier of heartrate to require heart beat             within         :type grace_multiplier: number         :rtype: boolean         """ [4399,4752]
===
match
---
name: self [4880,4884]
name: self [4900,4904]
===
match
---
expr_stmt [3498,3533]
expr_stmt [3526,3561]
===
match
---
name: self [8051,8055]
name: self [8071,8075]
===
match
---
trailer [3793,3802]
trailer [3813,3822]
===
match
---
name: heartrate [3635,3644]
name: heartrate [3663,3672]
===
match
---
atom_expr [9355,9371]
atom_expr [9375,9391]
===
match
---
name: airflow [1416,1423]
name: airflow [1401,1408]
===
match
---
atom_expr [3665,3678]
atom_expr [3693,3706]
===
match
---
name: self [5570,5574]
name: self [5590,5594]
===
match
---
name: creating_job_id [2972,2987]
name: creating_job_id [3000,3015]
===
match
---
name: Integer [895,902]
name: Integer [880,887]
===
match
---
suite [8565,9440]
suite [8585,9460]
===
match
---
param [5464,5468]
param [5484,5488]
===
match
---
param [5576,5588]
param [5596,5608]
===
match
---
except_clause [9150,9166]
except_clause [9170,9186]
===
match
---
suite [4979,5447]
suite [4999,5467]
===
match
---
trailer [5289,5295]
trailer [5309,5315]
===
match
---
operator: , [989,990]
operator: , [974,975]
===
match
---
simple_stmt [7673,7690]
simple_stmt [7693,7710]
===
match
---
name: self [4827,4831]
name: self [4847,4851]
===
match
---
name: airflow [1069,1076]
name: airflow [1054,1061]
===
match
---
trailer [4815,4822]
trailer [4835,4842]
===
match
---
name: self [3498,3502]
name: self [3526,3530]
===
match
---
atom_expr [7512,7526]
atom_expr [7532,7546]
===
match
---
atom_expr [9269,9282]
atom_expr [9289,9302]
===
match
---
return_stmt [4741,4923]
return_stmt [4761,4943]
===
match
---
name: self [7864,7868]
name: self [7884,7888]
===
match
---
trailer [7951,7958]
trailer [7971,7978]
===
match
---
name: merge [7858,7863]
name: merge [7878,7883]
===
match
---
operator: , [4963,4964]
operator: , [4983,4984]
===
match
---
name: conf [1098,1102]
name: conf [1083,1087]
===
match
---
except_clause [9033,9050]
except_clause [9053,9070]
===
match
---
name: Stats [8604,8609]
name: Stats [8624,8629]
===
match
---
operator: , [1284,1285]
operator: , [1269,1270]
===
match
---
name: self [8868,8872]
name: self [8888,8892]
===
match
---
import_from [1344,1375]
import_from [1329,1360]
===
match
---
name: hostname [2377,2385]
name: hostname [2405,2413]
===
match
---
name: start_date [3503,3513]
name: start_date [3531,3541]
===
match
---
name: session [3888,3895]
name: session [3908,3915]
===
match
---
string: """Handles on_kill callback and updates state in database.""" [4988,5049]
string: """Handles on_kill callback and updates state in database.""" [5008,5069]
===
match
---
name: self [4959,4963]
name: self [4979,4983]
===
match
---
operator: = [9005,9006]
operator: = [9025,9026]
===
match
---
operator: == [2779,2781]
operator: == [2807,2809]
===
match
---
name: session [8824,8831]
name: session [8844,8851]
===
match
---
suite [8209,8546]
suite [8229,8566]
===
match
---
name: __class__ [8620,8629]
name: __class__ [8640,8649]
===
match
---
operator: = [8121,8122]
operator: = [8141,8142]
===
match
---
atom_expr [2782,2820]
atom_expr [2810,2848]
===
match
---
arglist [2630,2680]
arglist [2658,2708]
===
match
---
operator: = [3273,3274]
operator: = [3301,3302]
===
match
---
name: logging_mixin [1491,1504]
name: logging_mixin [1476,1489]
===
match
---
dotted_name [1156,1189]
dotted_name [1141,1174]
===
match
---
operator: = [3005,3006]
operator: = [3033,3034]
===
match
---
param [3259,3264]
param [3287,3292]
===
match
---
trailer [7678,7689]
trailer [7698,7709]
===
match
---
number: 500 [2367,2370]
number: 500 [2395,2398]
===
match
---
name: State [8768,8773]
name: State [8788,8793]
===
match
---
simple_stmt [828,856]
simple_stmt [813,841]
===
match
---
trailer [2114,2145]
trailer [2142,2173]
===
match
---
simple_stmt [8090,8131]
simple_stmt [8110,8151]
===
match
---
atom_expr [5343,5361]
atom_expr [5363,5381]
===
match
---
param [5570,5575]
param [5590,5595]
===
match
---
simple_stmt [1103,1151]
simple_stmt [1088,1136]
===
match
---
name: cls [4264,4267]
name: cls [4284,4287]
===
match
---
name: session [5576,5583]
name: session [5596,5603]
===
match
---
simple_stmt [3361,3427]
simple_stmt [3389,3455]
===
match
---
name: self [8994,8998]
name: self [9014,9018]
===
match
---
comparison [7284,7312]
comparison [7304,7332]
===
match
---
simple_stmt [2536,2689]
simple_stmt [2564,2717]
===
match
---
simple_stmt [805,828]
simple_stmt [790,813]
===
match
---
trailer [6925,6927]
trailer [6945,6947]
===
match
---
name: backref [3006,3013]
name: backref [3034,3041]
===
match
---
import_as_names [1278,1290]
import_as_names [1263,1275]
===
match
---
name: relationship [2720,2732]
name: relationship [2748,2760]
===
match
---
param [5701,5706]
param [5721,5726]
===
match
---
simple_stmt [9381,9440]
simple_stmt [9401,9460]
===
match
---
simple_stmt [2029,2051]
simple_stmt [2057,2079]
===
match
---
atom_expr [2228,2249]
atom_expr [2256,2277]
===
match
---
name: session [8122,8129]
name: session [8142,8149]
===
match
---
atom_expr [2360,2371]
atom_expr [2388,2399]
===
match
---
simple_stmt [2412,2444]
simple_stmt [2440,2472]
===
match
---
name: id [2951,2953]
name: id [2979,2981]
===
match
---
simple_stmt [7330,7342]
simple_stmt [7350,7362]
===
match
---
atom_expr [7330,7341]
atom_expr [7350,7361]
===
match
---
number: 20 [2172,2174]
number: 20 [2200,2202]
===
match
---
parameters [3258,3312]
parameters [3286,3340]
===
match
---
operator: - [4825,4826]
operator: - [4845,4846]
===
match
---
name: self [9392,9396]
name: self [9412,9416]
===
match
---
if_stmt [6793,6928]
if_stmt [6813,6948]
===
match
---
operator: = [7488,7489]
operator: = [7508,7509]
===
match
---
name: __class__ [3471,3480]
name: __class__ [3499,3508]
===
match
---
name: session [1587,1594]
name: session [1615,1622]
===
match
---
atom_expr [2353,2372]
atom_expr [2381,2400]
===
match
---
name: utils [1481,1486]
name: utils [1466,1471]
===
match
---
import_from [1468,1524]
import_from [1453,1509]
===
match
---
suite [3925,4324]
suite [3945,4344]
===
match
---
trailer [3206,3240]
trailer [3234,3268]
===
match
---
name: commit [8832,8838]
name: commit [8852,8858]
===
match
---
name: self [3630,3634]
name: self [3658,3662]
===
match
---
string: 'polymorphic_on' [2468,2484]
string: 'polymorphic_on' [2496,2512]
===
match
---
atom_expr [2108,2145]
atom_expr [2136,2173]
===
match
---
trailer [2789,2820]
trailer [2817,2848]
===
match
---
trailer [3581,3583]
trailer [3609,3611]
===
match
---
simple_stmt [8604,8665]
simple_stmt [8624,8685]
===
match
---
suite [7313,7342]
suite [7333,7362]
===
match
---
name: __name__ [8271,8279]
name: __name__ [8291,8299]
===
match
---
atom_expr [2430,2442]
atom_expr [2458,2470]
===
match
---
simple_stmt [2254,2287]
simple_stmt [2282,2315]
===
match
---
simple_stmt [5343,5362]
simple_stmt [5363,5382]
===
match
---
trailer [6855,6865]
trailer [6875,6885]
===
match
---
import_as_names [1602,1633]
import_as_names [1630,1661]
===
match
---
name: airflow [1381,1388]
name: airflow [1366,1373]
===
match
---
trailer [8629,8638]
trailer [8649,8658]
===
match
---
operator: , [3278,3279]
operator: , [3306,3307]
===
match
---
trailer [8867,8873]
trailer [8887,8893]
===
match
---
name: heartrate [3181,3190]
name: heartrate [3209,3218]
===
match
---
string: """         Heartbeats update the job's entry in the database with a timestamp         for the latest_heartbeat and allows for the job to be killed         externally. This allows at the system level to monitor what is         actually active.          For instance, an old heartbeat for SchedulerJob would mean something         is wrong.          This also allows for any job to be killed externally, regardless         of who is running it or on which machine it is running.          Note that if your heart rate is set to 60 seconds and you call this         method after 10 seconds of processing since the last heartbeat, it         will sleep 50 seconds to complete the 60 seconds and keep a steady         heart rate. If you go over 60 seconds before calling it, it won't         sleep at all.          :param only_if_necessary: If the heartbeat is not yet due then do             nothing (don't update column, don't call ``heartbeat_callback``)         :type only_if_necessary: boolean         """ [5749,6754]
string: """         Heartbeats update the job's entry in the database with a timestamp         for the latest_heartbeat and allows for the job to be killed         externally. This allows at the system level to monitor what is         actually active.          For instance, an old heartbeat for SchedulerJob would mean something         is wrong.          This also allows for any job to be killed externally, regardless         of who is running it or on which machine it is running.          Note that if your heart rate is set to 60 seconds and you call this         method after 10 seconds of processing since the last heartbeat, it         will sleep 50 seconds to complete the 60 seconds and keep a steady         heart rate. If you go over 60 seconds before calling it, it won't         sleep at all.          :param only_if_necessary: If the heartbeat is not yet due then do             nothing (don't update column, don't call ``heartbeat_callback``)         :type only_if_necessary: boolean         """ [5769,6774]
===
match
---
simple_stmt [5479,5542]
simple_stmt [5499,5562]
===
match
---
name: create_session [7749,7763]
name: create_session [7769,7783]
===
match
---
name: Column [2061,2067]
name: Column [2089,2095]
===
match
---
simple_stmt [8147,8177]
simple_stmt [8167,8197]
===
match
---
arglist [9392,9438]
arglist [9412,9458]
===
match
---
name: sleep [822,827]
name: sleep [807,812]
===
match
---
name: cls [3883,3886]
name: cls [3903,3906]
===
match
---
operator: , [2662,2663]
operator: , [2690,2691]
===
match
---
simple_stmt [8323,8400]
simple_stmt [8343,8420]
===
match
---
trailer [3531,3533]
trailer [3559,3561]
===
match
---
name: total_seconds [6912,6925]
name: total_seconds [6932,6945]
===
match
---
trailer [7288,7294]
trailer [7308,7314]
===
match
---
operator: = [9122,9123]
operator: = [9142,9143]
===
match
---
atom_expr [5327,5333]
atom_expr [5347,5353]
===
match
---
name: id [5102,5104]
name: id [5122,5124]
===
match
---
operator: = [3645,3646]
operator: = [3673,3674]
===
match
---
name: backref [2830,2837]
name: backref [2858,2865]
===
match
---
trailer [7538,7545]
trailer [7558,7565]
===
match
---
raise_stmt [9473,9536]
raise_stmt [9493,9556]
===
match
---
trailer [7958,7960]
trailer [7978,7980]
===
match
---
trailer [3365,3374]
trailer [3393,3402]
===
match
---
operator: > [6958,6959]
operator: > [6978,6979]
===
match
---
trailer [3326,3335]
trailer [3354,3363]
===
match
---
trailer [7638,7660]
trailer [7658,7680]
===
match
---
trailer [5156,5163]
trailer [5176,5183]
===
match
---
simple_stmt [7623,7661]
simple_stmt [7643,7681]
===
match
---
name: airflow [1251,1258]
name: airflow [1236,1243]
===
match
---
name: Base [1286,1290]
name: Base [1271,1275]
===
match
---
suite [6984,7004]
suite [7004,7024]
===
match
---
name: state [4767,4772]
name: state [4787,4792]
===
match
---
with_stmt [7744,8177]
with_stmt [7764,8197]
===
match
---
decorator [3842,3859]
decorator [3862,3879]
===
match
---
trailer [7334,7339]
trailer [7354,7359]
===
match
---
operator: , [9432,9433]
operator: , [9452,9453]
===
match
---
expr_stmt [3707,3777]
expr_stmt [3727,3797]
===
match
---
term [4880,4913]
term [4900,4933]
===
match
---
name: latest_heartbeat [8508,8524]
name: latest_heartbeat [8528,8544]
===
match
---
name: relationship [1000,1012]
name: relationship [985,997]
===
match
---
trailer [2394,2407]
trailer [2422,2435]
===
match
---
arith_expr [4807,4848]
arith_expr [4827,4868]
===
match
---
name: TaskInstance [2790,2802]
name: TaskInstance [2818,2830]
===
match
---
operator: = [3730,3731]
operator: = [3750,3751]
===
match
---
operator: , [3886,3887]
operator: , [3906,3907]
===
match
---
import_from [955,1012]
import_from [940,997]
===
match
---
name: debug [8156,8161]
name: debug [8176,8181]
===
match
---
simple_stmt [3322,3353]
simple_stmt [3350,3381]
===
match
---
name: executor_class [3440,3454]
name: executor_class [3468,3482]
===
match
---
if_stmt [6937,7004]
if_stmt [6957,7024]
===
match
---
number: 1000 [2437,2441]
number: 1000 [2465,2469]
===
match
---
name: only_if_necessary [6966,6983]
name: only_if_necessary [6986,7003]
===
match
---
name: self [4342,4346]
name: self [4362,4366]
===
match
---
string: '[heartbeat]' [8162,8175]
string: '[heartbeat]' [8182,8195]
===
match
---
name: self [8559,8563]
name: self [8579,8583]
===
match
---
operator: @ [3825,3826]
operator: @ [3845,3846]
===
match
---
name: base [1266,1270]
name: base [1251,1255]
===
match
---
simple_stmt [6763,6785]
simple_stmt [6783,6805]
===
match
---
trailer [5086,5093]
trailer [5106,5113]
===
match
---
atom_expr [6889,6910]
atom_expr [6909,6930]
===
match
---
name: Column [2353,2359]
name: Column [2381,2387]
===
match
---
name: heartrate [3647,3656]
name: heartrate [3675,3684]
===
match
---
name: get_default_executor [3404,3424]
name: get_default_executor [3432,3452]
===
match
---
name: sqlalchemy [960,970]
name: sqlalchemy [945,955]
===
match
---
name: DagRun [2923,2929]
name: DagRun [2951,2957]
===
match
---
trailer [3743,3777]
trailer [3763,3797]
===
match
---
operator: { [2467,2468]
operator: { [2495,2496]
===
match
---
name: self [8375,8379]
name: self [8395,8399]
===
match
---
arith_expr [6869,6910]
arith_expr [6889,6930]
===
match
---
trailer [9498,9536]
trailer [9518,9556]
===
match
---
name: session [5370,5377]
name: session [5390,5397]
===
match
---
name: Index [888,893]
name: Index [873,878]
===
match
---
name: __name__ [8630,8638]
name: __name__ [8650,8658]
===
match
---
operator: , [3301,3302]
operator: , [3329,3330]
===
match
---
simple_stmt [1344,1376]
simple_stmt [1329,1361]
===
match
---
simple_stmt [1568,1634]
simple_stmt [1596,1662]
===
match
---
trailer [3669,3678]
trailer [3697,3706]
===
match
---
atom_expr [3006,3029]
atom_expr [3034,3057]
===
match
---
simple_stmt [8574,8596]
simple_stmt [8594,8616]
===
match
---
expr_stmt [2536,2688]
expr_stmt [2564,2716]
===
match
---
name: backref [2838,2845]
name: backref [2866,2873]
===
match
---
name: Optional [3905,3913]
name: Optional [3925,3933]
===
match
---
trailer [5112,5115]
trailer [5132,5135]
===
match
---
simple_stmt [2890,3037]
simple_stmt [2918,3065]
===
match
---
trailer [8801,8805]
trailer [8821,8825]
===
match
---
expr_stmt [8503,8545]
expr_stmt [8523,8565]
===
match
---
expr_stmt [2056,2094]
expr_stmt [2084,2122]
===
match
---
operator: , [2754,2755]
operator: , [2782,2783]
===
match
---
name: bool [5726,5730]
name: bool [5746,5750]
===
match
---
argument [3810,3818]
argument [3830,3838]
===
match
---
operator: = [2043,2044]
operator: = [2071,2072]
===
match
---
suite [9167,9232]
suite [9187,9252]
===
match
---
operator: , [2655,2656]
operator: , [2683,2684]
===
match
---
arglist [2068,2093]
arglist [2096,2121]
===
match
---
simple_stmt [9111,9138]
simple_stmt [9131,9158]
===
match
---
atom_expr [4827,4848]
atom_expr [4847,4868]
===
match
---
trailer [3913,3924]
trailer [3933,3944]
===
match
---
name: sqlalchemy [1653,1663]
name: sqlalchemy [1681,1691]
===
match
---
suite [7069,8177]
suite [7089,8197]
===
match
---
trailer [8341,8399]
trailer [8361,8419]
===
match
---
expr_stmt [2336,2372]
expr_stmt [2364,2400]
===
match
---
atom_expr [7246,7267]
atom_expr [7266,7287]
===
match
---
trailer [4312,4315]
trailer [4332,4335]
===
match
---
trailer [6893,6910]
trailer [6913,6930]
===
match
---
name: merge [7197,7202]
name: merge [7217,7222]
===
match
---
trailer [8255,8280]
trailer [8275,8300]
===
match
---
atom_expr [7673,7689]
atom_expr [7693,7709]
===
match
---
operator: = [5062,5063]
operator: = [5082,5083]
===
match
---
arglist [8615,8663]
arglist [8635,8683]
===
match
---
trailer [7545,7547]
trailer [7565,7567]
===
match
---
name: str [5327,5330]
name: str [5347,5350]
===
match
---
expr_stmt [6831,6927]
expr_stmt [6851,6947]
===
match
---
name: previous_heartbeat [8030,8048]
name: previous_heartbeat [8050,8068]
===
match
---
name: heartrate [4885,4894]
name: heartrate [4905,4914]
===
match
---
name: job [5133,5136]
name: job [5153,5156]
===
match
---
arglist [5296,5333]
arglist [5316,5353]
===
match
---
simple_stmt [9226,9232]
simple_stmt [9246,9252]
===
match
---
operator: = [9283,9284]
operator: = [9303,9304]
===
match
---
name: make_transient [1048,1062]
name: make_transient [1033,1047]
===
match
---
atom_expr [3322,3335]
atom_expr [3350,3363]
===
match
---
simple_stmt [2291,2332]
simple_stmt [2319,2360]
===
match
---
atom_expr [8604,8664]
atom_expr [8624,8684]
===
match
---
name: args [3297,3301]
name: args [3325,3329]
===
match
---
simple_stmt [9184,9210]
simple_stmt [9204,9230]
===
match
---
name: dag_runs [2890,2898]
name: dag_runs [2918,2926]
===
match
---
number: 1 [9437,9438]
number: 1 [9457,9458]
===
match
---
expr_stmt [7225,7267]
expr_stmt [7245,7287]
===
match
---
trailer [8838,8840]
trailer [8858,8860]
===
match
---
name: self [7330,7334]
name: self [7350,7354]
===
match
---
name: self [7203,7207]
name: self [7223,7227]
===
match
---
trailer [9300,9302]
trailer [9320,9322]
===
match
---
trailer [7339,7341]
trailer [7359,7361]
===
match
---
operator: * [3296,3297]
operator: * [3324,3325]
===
match
---
atom_expr [8794,8811]
atom_expr [8814,8831]
===
match
---
name: executor [3377,3385]
name: executor [3405,3413]
===
match
---
dotted_name [1688,1707]
dotted_name [1716,1735]
===
match
---
name: self [9111,9115]
name: self [9131,9135]
===
match
---
name: first [5117,5122]
name: first [5137,5142]
===
match
---
name: String [2430,2436]
name: String [2458,2464]
===
match
---
arglist [8342,8398]
arglist [8362,8418]
===
match
---
expr_stmt [2694,2884]
expr_stmt [2722,2912]
===
match
---
simple_stmt [6831,6928]
simple_stmt [6851,6948]
===
match
---
name: start_date [2215,2225]
name: start_date [2243,2253]
===
match
---
atom_expr [3707,3729]
atom_expr [3727,3749]
===
match
---
simple_stmt [5749,6755]
simple_stmt [5769,6775]
===
match
---
name: airflow [1349,1356]
name: airflow [1334,1341]
===
match
---
simple_stmt [8994,9021]
simple_stmt [9014,9041]
===
match
---
atom [7529,7572]
atom [7549,7592]
===
match
---
operator: = [8049,8050]
operator: = [8069,8070]
===
match
---
name: ExecutorLoader [3389,3403]
name: ExecutorLoader [3417,3431]
===
match
---
expr_stmt [3542,3583]
expr_stmt [3570,3611]
===
match
---
trailer [2359,2372]
trailer [2387,2400]
===
match
---
operator: , [3263,3264]
operator: , [3291,3292]
===
match
---
trailer [4781,4789]
trailer [4801,4809]
===
match
---
trailer [9386,9391]
trailer [9406,9411]
===
match
---
expr_stmt [3181,3240]
expr_stmt [3209,3268]
===
match
---
atom_expr [7944,7960]
atom_expr [7964,7980]
===
match
---
atom_expr [8768,8781]
atom_expr [8788,8801]
===
match
---
operator: - [7548,7549]
operator: - [7568,7569]
===
match
---
name: cls [4278,4281]
name: cls [4298,4301]
===
match
---
name: RUNNING [4782,4789]
name: RUNNING [4802,4809]
===
match
---
name: LoggingMixin [1512,1524]
name: LoggingMixin [1497,1509]
===
match
---
operator: = [2059,2060]
operator: = [2087,2088]
===
match
---
operator: , [998,999]
operator: , [983,984]
===
match
---
return_stmt [4243,4323]
return_stmt [4263,4343]
===
match
---
expr_stmt [2254,2286]
expr_stmt [2282,2314]
===
match
---
name: __class__ [8261,8270]
name: __class__ [8281,8290]
===
match
---
trailer [5071,5077]
trailer [5091,5097]
===
match
---
name: job_type [2587,2595]
name: job_type [2615,2623]
===
match
---
name: merge [5351,5356]
name: merge [5371,5376]
===
match
---
trailer [2164,2176]
trailer [2192,2204]
===
match
---
dotted_name [1416,1437]
dotted_name [1401,1422]
===
match
---
operator: = [9195,9196]
operator: = [9215,9216]
===
match
---
name: airflow [1217,1224]
name: airflow [1202,1209]
===
match
---
trailer [2913,3036]
trailer [2941,3064]
===
match
---
name: utcnow [3575,3581]
name: utcnow [3603,3609]
===
match
---
name: helpers [1430,1437]
name: helpers [1415,1422]
===
match
---
operator: , [3294,3295]
operator: , [3322,3323]
===
match
---
name: uselist [2863,2870]
name: uselist [2891,2898]
===
match
---
operator: , [3755,3756]
operator: , [3775,3776]
===
match
---
suite [9464,9537]
suite [9484,9557]
===
match
---
dotted_name [1296,1323]
dotted_name [1281,1308]
===
match
---
atom_expr [3786,3819]
atom_expr [3806,3839]
===
match
---
name: airflow [1108,1115]
name: airflow [1093,1100]
===
match
---
trailer [7516,7526]
trailer [7536,7546]
===
match
---
simple_stmt [911,955]
simple_stmt [896,940]
===
match
---
trailer [2234,2249]
trailer [2262,2277]
===
match
---
parameters [4341,4369]
parameters [4361,4389]
===
match
---
trailer [2271,2286]
trailer [2299,2314]
===
match
---
arglist [7639,7659]
arglist [7659,7679]
===
match
---
name: __init__ [3250,3258]
name: __init__ [3278,3286]
===
match
---
param [4348,4368]
param [4368,4388]
===
match
---
import_from [805,827]
import_from [790,812]
===
match
---
name: seconds_remaining [7470,7487]
name: seconds_remaining [7490,7507]
===
match
---
name: latest_heartbeat [4832,4848]
name: latest_heartbeat [4852,4868]
===
match
---
atom_expr [2624,2681]
atom_expr [2652,2709]
===
match
---
atom_expr [2265,2286]
atom_expr [2293,2314]
===
match
---
name: hostname [3327,3335]
name: hostname [3355,3363]
===
match
---
trailer [3439,3454]
trailer [3467,3482]
===
match
---
simple_stmt [3498,3534]
simple_stmt [3526,3562]
===
match
---
name: state [8760,8765]
name: state [8780,8785]
===
match
---
string: "job" [2045,2050]
string: "job" [2073,2078]
===
match
---
operator: = [7032,7033]
operator: = [7052,7053]
===
match
---
atom_expr [3630,3644]
atom_expr [3658,3672]
===
match
---
name: provide_session [4930,4945]
name: provide_session [4950,4965]
===
match
---
trailer [5116,5122]
trailer [5136,5142]
===
match
---
name: Index [2624,2629]
name: Index [2652,2657]
===
match
---
name: self [6851,6855]
name: self [6871,6875]
===
match
---
name: self [9458,9462]
name: self [9478,9482]
===
match
---
simple_stmt [7886,7928]
simple_stmt [7906,7948]
===
match
---
name: timezone [7910,7918]
name: timezone [7930,7938]
===
match
---
name: incr [8228,8232]
name: incr [8248,8252]
===
match
---
number: 1 [8305,8306]
number: 1 [8325,8326]
===
match
---
operator: , [2681,2682]
operator: , [2709,2710]
===
match
---
name: session [8794,8801]
name: session [8814,8821]
===
match
---
name: make_transient [8853,8867]
name: make_transient [8873,8887]
===
match
---
expr_stmt [9269,9302]
expr_stmt [9289,9322]
===
match
---
atom_expr [2165,2175]
atom_expr [2193,2203]
===
match
---
operator: = [2308,2309]
operator: = [2336,2337]
===
match
---
param [3280,3295]
param [3308,3323]
===
match
---
name: desc [4299,4303]
name: desc [4319,4323]
===
match
---
atom_expr [7910,7927]
atom_expr [7930,7947]
===
match
---
name: session [9355,9362]
name: session [9375,9382]
===
match
---
simple_stmt [4741,4924]
simple_stmt [4761,4944]
===
match
---
name: self [3542,3546]
name: self [3570,3574]
===
match
---
trailer [6911,6925]
trailer [6931,6945]
===
match
---
atom_expr [4776,4789]
atom_expr [4796,4809]
===
match
---
trailer [8379,8389]
trailer [8399,8409]
===
match
---
simple_stmt [7944,7961]
simple_stmt [7964,7981]
===
match
---
simple_stmt [1525,1568]
simple_stmt [1510,1553]
===
match
---
simple_stmt [2181,2211]
simple_stmt [2209,2239]
===
match
---
trailer [9362,9369]
trailer [9382,9389]
===
match
---
trailer [5356,5361]
trailer [5376,5381]
===
match
---
param [4342,4347]
param [4362,4367]
===
match
---
atom_expr [8615,8646]
atom_expr [8635,8666]
===
match
---
arith_expr [7530,7571]
arith_expr [7550,7591]
===
match
---
name: executors [1164,1173]
name: executors [1149,1158]
===
match
---
atom_expr [8994,9004]
atom_expr [9014,9024]
===
match
---
name: self [9333,9337]
name: self [9353,9357]
===
match
---
except_clause [8185,8208]
except_clause [8205,8228]
===
match
---
arglist [2124,2139]
arglist [2152,2167]
===
match
---
atom_expr [9381,9439]
atom_expr [9401,9459]
===
match
---
atom_expr [9319,9338]
atom_expr [9339,9358]
===
match
---
trailer [9012,9020]
trailer [9032,9040]
===
match
---
atom_expr [4806,4865]
atom_expr [4826,4885]
===
match
---
name: lower [8639,8644]
name: lower [8659,8664]
===
match
---
atom_expr [2272,2285]
atom_expr [2300,2313]
===
match
---
trailer [3403,3424]
trailer [3431,3452]
===
match
---
name: time [810,814]
name: time [795,799]
===
match
---
expr_stmt [3435,3489]
expr_stmt [3463,3517]
===
match
---
name: self [3259,3263]
name: self [3287,3291]
===
match
---
atom_expr [7749,7765]
atom_expr [7769,7785]
===
match
---
atom_expr [4278,4305]
atom_expr [4298,4325]
===
match
---
name: DagRun [1239,1245]
name: DagRun [1224,1230]
===
match
---
simple_stmt [2377,2408]
simple_stmt [2405,2436]
===
match
---
name: timezone [4807,4815]
name: timezone [4827,4835]
===
match
---
atom_expr [5401,5446]
atom_expr [5421,5466]
===
match
---
simple_stmt [4379,4733]
simple_stmt [4399,4753]
===
match
---
suite [3617,3657]
suite [3645,3685]
===
match
---
name: state [9116,9121]
name: state [9136,9141]
===
match
---
name: UtcDateTime [2272,2283]
name: UtcDateTime [2300,2311]
===
match
---
trailer [2366,2371]
trailer [2394,2399]
===
match
---
trailer [4277,4306]
trailer [4297,4326]
===
match
---
name: previous_heartbeat [7225,7243]
name: previous_heartbeat [7245,7263]
===
match
---
operator: == [5105,5107]
operator: == [5125,5127]
===
match
---
trailer [8227,8232]
trailer [8247,8252]
===
match
---
name: self [3665,3669]
name: self [3693,3697]
===
match
---
simple_stmt [1013,1063]
simple_stmt [998,1048]
===
match
---
trailer [7572,7586]
trailer [7592,7606]
===
match
---
trailer [8728,8730]
trailer [8748,8750]
===
match
---
operator: } [2529,2530]
operator: } [2557,2558]
===
match
---
trailer [2246,2248]
trailer [2274,2276]
===
match
---
import_from [857,910]
import_from [842,895]
===
match
---
atom_expr [3498,3513]
atom_expr [3526,3541]
===
match
---
name: airflow [1688,1695]
name: airflow [1716,1723]
===
match
---
operator: = [2421,2422]
operator: = [2449,2450]
===
match
---
atom [2467,2530]
atom [2495,2558]
===
match
---
trailer [9391,9439]
trailer [9411,9459]
===
match
---
suite [5178,5206]
suite [5198,5226]
===
match
---
param [3303,3311]
param [3331,3339]
===
match
---
name: OperationalError [8192,8208]
name: OperationalError [8212,8228]
===
match
---
expr_stmt [2377,2407]
expr_stmt [2405,2435]
===
match
---
suite [4370,4924]
suite [4390,4944]
===
match
---
name: foreign [2957,2964]
name: foreign [2985,2992]
===
match
---
suite [9051,9138]
suite [9071,9158]
===
match
---
name: Stats [8222,8227]
name: Stats [8242,8247]
===
match
---
number: 0 [7414,7415]
number: 0 [7434,7435]
===
match
---
import_from [1411,1467]
import_from [1396,1452]
===
match
---
atom_expr [2957,2988]
atom_expr [2985,3016]
===
match
---
name: heartbeat_callback [8095,8113]
name: heartbeat_callback [8115,8133]
===
match
---
trailer [3480,3489]
trailer [3508,3517]
===
match
---
simple_stmt [1151,1212]
simple_stmt [1136,1197]
===
match
---
expr_stmt [2449,2530]
expr_stmt [2477,2558]
===
match
---
name: __table_args__ [2536,2550]
name: __table_args__ [2564,2578]
===
match
---
number: 1 [4313,4314]
number: 1 [4333,4334]
===
match
---
name: session [7189,7196]
name: session [7209,7216]
===
match
---
simple_stmt [2215,2250]
simple_stmt [2243,2278]
===
match
---
or_test [3377,3426]
or_test [3405,3454]
===
match
---
name: self [6796,6800]
name: self [6816,6820]
===
match
---
name: timezone [7530,7538]
name: timezone [7550,7558]
===
match
---
name: job [5058,5061]
name: job [5078,5081]
===
match
---
trailer [5203,5205]
trailer [5223,5225]
===
match
---
name: grace_multiplier [4348,4364]
name: grace_multiplier [4368,4384]
===
match
---
comparison [6940,6961]
comparison [6960,6981]
===
match
---
string: 'scheduler' [3744,3755]
string: 'scheduler' [3764,3775]
===
match
---
expr_stmt [9184,9209]
expr_stmt [9204,9229]
===
match
---
trailer [7763,7765]
trailer [7783,7785]
===
match
---
simple_stmt [2099,2146]
simple_stmt [2127,2174]
===
match
---
if_stmt [3592,3657]
if_stmt [3620,3685]
===
match
---
name: sqlalchemy [1018,1028]
name: sqlalchemy [1003,1013]
===
match
---
dotted_name [1530,1547]
dotted_name [1515,1532]
===
match
---
name: configuration [1077,1090]
name: configuration [1062,1075]
===
match
---
operator: = [3191,3192]
operator: = [3219,3220]
===
match
---
operator: , [2861,2862]
operator: , [2889,2890]
===
match
---
atom_expr [2192,2210]
atom_expr [2220,2238]
===
match
---
name: self [8908,8912]
name: self [8928,8932]
===
match
---
number: 1 [8308,8309]
number: 1 [8328,8329]
===
match
---
trailer [6800,6817]
trailer [6820,6837]
===
match
---
trailer [7303,7312]
trailer [7323,7332]
===
match
---
name: commit [5378,5384]
name: commit [5398,5404]
===
match
---
dotted_name [1349,1362]
dotted_name [1334,1347]
===
match
---
name: utils [1389,1394]
name: utils [1374,1379]
===
match
---
operator: == [2954,2956]
operator: == [2982,2984]
===
match
---
expr_stmt [7886,7927]
expr_stmt [7906,7947]
===
match
---
name: self [5701,5705]
name: self [5721,5725]
===
match
---
name: Column [2265,2271]
name: Column [2293,2299]
===
match
---
operator: = [2870,2871]
operator: = [2898,2899]
===
match
---
operator: = [3289,3290]
operator: = [3317,3318]
===
match
---
trailer [8614,8664]
trailer [8634,8684]
===
match
---
expr_stmt [2412,2443]
expr_stmt [2440,2471]
===
match
---
operator: , [3218,3219]
operator: , [3246,3247]
===
match
---
arglist [2742,2878]
arglist [2770,2906]
===
match
---
trailer [8644,8646]
trailer [8664,8666]
===
match
---
trailer [8260,8270]
trailer [8280,8290]
===
match
---
name: provide_session [3843,3858]
name: provide_session [3863,3878]
===
match
---
string: 'BaseJob' [3914,3923]
string: 'BaseJob' [3934,3943]
===
match
---
trailer [9273,9282]
trailer [9293,9302]
===
match
---
operator: , [8657,8658]
operator: , [8677,8678]
===
match
---
suite [8742,9372]
suite [8762,9392]
===
match
---
funcdef [9445,9537]
funcdef [9465,9557]
===
match
---
trailer [4321,4323]
trailer [4341,4343]
===
match
---
name: self [8147,8151]
name: self [8167,8171]
===
match
---
suite [5470,5542]
suite [5490,5562]
===
match
---
name: total_seconds [4850,4863]
name: total_seconds [4870,4883]
===
match
---
operator: , [2877,2878]
operator: , [2905,2906]
===
match
---
suite [5590,5682]
suite [5610,5702]
===
match
---
name: timezone [3566,3574]
name: timezone [3594,3602]
===
match
---
atom_expr [8147,8176]
atom_expr [8167,8196]
===
match
---
name: self [5191,5195]
name: self [5211,5215]
===
match
---
trailer [2316,2331]
trailer [2344,2359]
===
match
---
import_from [1151,1211]
import_from [1136,1196]
===
match
---
name: job_type [2181,2189]
name: job_type [2209,2217]
===
match
---
atom_expr [8233,8280]
atom_expr [8253,8300]
===
match
---
trailer [2971,2987]
trailer [2999,3015]
===
match
---
name: sleep_for [7623,7632]
name: sleep_for [7643,7652]
===
match
---
operator: , [3808,3809]
operator: , [3828,3829]
===
match
---
operator: , [2595,2596]
operator: , [2623,2624]
===
match
---
trailer [4822,4824]
trailer [4842,4844]
===
match
---
name: getfloat [3198,3206]
name: getfloat [3226,3234]
===
match
---
operator: @ [4929,4930]
operator: @ [4949,4950]
===
match
---
atom_expr [6851,6865]
atom_expr [6871,6885]
===
match
---
with_stmt [8709,9372]
with_stmt [8729,9392]
===
match
---
operator: , [886,887]
operator: , [871,872]
===
match
---
operator: = [2226,2227]
operator: = [2254,2255]
===
match
---
name: args [3804,3808]
name: args [3824,3828]
===
match
---
import_from [911,954]
import_from [896,939]
===
match
---
simple_stmt [8853,8874]
simple_stmt [8873,8894]
===
match
---
operator: , [8306,8307]
operator: , [8326,8327]
===
match
---
name: Stats [1370,1375]
name: Stats [1355,1360]
===
match
---
dotted_name [1573,1594]
dotted_name [1601,1622]
===
match
---
trailer [8831,8838]
trailer [8851,8858]
===
match
---
trailer [2328,2330]
trailer [2356,2358]
===
match
---
name: e [5331,5332]
name: e [5351,5352]
===
match
---
trailer [2130,2138]
trailer [2158,2166]
===
match
---
operator: = [6849,6850]
operator: = [6869,6870]
===
match
---
name: Column [2158,2164]
name: Column [2186,2192]
===
match
---
trailer [4831,4848]
trailer [4851,4868]
===
match
---
name: DagRun [2965,2971]
name: DagRun [2993,2999]
===
match
---
param [3296,3302]
param [3324,3330]
===
match
---
name: id [5113,5115]
name: id [5133,5135]
===
match
---
trailer [9406,9415]
trailer [9426,9435]
===
match
---
name: add [8802,8805]
name: add [8822,8825]
===
match
---
operator: = [5583,5584]
operator: = [5603,5604]
===
match
---
name: Exception [9157,9166]
name: Exception [9177,9186]
===
match
---
name: max [7635,7638]
name: max [7655,7658]
===
match
---
name: self [3457,3461]
name: self [3485,3489]
===
match
---
simple_stmt [3786,3820]
simple_stmt [3806,3840]
===
match
---
atom [4748,4923]
atom [4768,4943]
===
match
---
string: """Starts the job.""" [8574,8595]
string: """Starts the job.""" [8594,8615]
===
match
---
simple_stmt [2056,2095]
simple_stmt [2084,2123]
===
match
---
trailer [3711,3729]
trailer [3731,3749]
===
match
---
operator: , [5574,5575]
operator: , [5594,5595]
===
match
---
atom_expr [2235,2248]
atom_expr [2263,2276]
===
match
---
trailer [8327,8331]
trailer [8347,8351]
===
match
---
name: timezone [3516,3524]
name: timezone [3544,3552]
===
match
---
atom_expr [8375,8398]
atom_expr [8395,8418]
===
match
---
funcdef [4950,5447]
funcdef [4970,5467]
===
match
---
name: UtcDateTime [1671,1682]
name: UtcDateTime [1699,1710]
===
match
---
atom_expr [7850,7869]
atom_expr [7870,7889]
===
match
---
simple_stmt [2449,2531]
simple_stmt [2477,2559]
===
match
---
simple_stmt [5058,5125]
simple_stmt [5078,5145]
===
match
---
string: 'BaseJob' [2520,2529]
string: 'BaseJob' [2548,2557]
===
match
---
number: 500 [2402,2405]
number: 500 [2430,2433]
===
match
---
atom_expr [3435,3454]
atom_expr [3463,3482]
===
match
---
name: run [8555,8558]
name: run [8575,8578]
===
match
---
name: executor_class [2336,2350]
name: executor_class [2364,2378]
===
match
---
argument [2830,2877]
argument [2858,2905]
===
match
---
atom_expr [9392,9423]
atom_expr [9412,9443]
===
match
---
atom_expr [6869,6886]
atom_expr [6889,6906]
===
match
---
expr_stmt [2029,2050]
expr_stmt [2057,2078]
===
match
---
atom_expr [8222,8310]
atom_expr [8242,8330]
===
match
---
trailer [4281,4298]
trailer [4301,4318]
===
match
---
atom_expr [3193,3240]
atom_expr [3221,3268]
===
match
---
name: sqlalchemy [916,926]
name: sqlalchemy [901,911]
===
match
---
operator: , [7640,7641]
operator: , [7660,7661]
===
match
---
name: filter [5087,5093]
name: filter [5107,5113]
===
match
---
name: create_session [7087,7101]
name: create_session [7107,7121]
===
match
---
expr_stmt [2099,2145]
expr_stmt [2127,2173]
===
match
---
funcdef [5547,5682]
funcdef [5567,5702]
===
match
---
expr_stmt [2150,2176]
expr_stmt [2178,2204]
===
match
---
operator: , [9435,9436]
operator: , [9455,9456]
===
match
---
name: seconds_remaining [7642,7659]
name: seconds_remaining [7662,7679]
===
match
---
name: __class__ [8380,8389]
name: __class__ [8400,8409]
===
match
---
name: utcnow [5157,5163]
name: utcnow [5177,5183]
===
match
---
name: heartrate [7517,7526]
name: heartrate [7537,7546]
===
match
---
name: typing [833,839]
name: typing [818,824]
===
match
---
comparison [2776,2820]
comparison [2804,2848]
===
match
---
atom_expr [9007,9020]
atom_expr [9027,9040]
===
match
---
name: most_recent_job [3867,3882]
name: most_recent_job [3887,3902]
===
match
---
trailer [2629,2681]
trailer [2657,2709]
===
match
---
atom_expr [3516,3533]
atom_expr [3544,3561]
===
match
---
operator: = [2950,2951]
operator: = [2978,2979]
===
match
---
parameters [9457,9463]
parameters [9477,9483]
===
match
---
operator: = [2718,2719]
operator: = [2746,2747]
===
match
---
decorator [3825,3838]
decorator [3845,3858]
===
match
---
name: exc [927,930]
name: exc [912,915]
===
match
---
name: total_seconds [7573,7586]
name: total_seconds [7593,7606]
===
match
---
name: seconds_remaining [6831,6848]
name: seconds_remaining [6851,6868]
===
match
---
string: '_heartbeat_failure' [8283,8303]
string: '_heartbeat_failure' [8303,8323]
===
match
---
name: self [5108,5112]
name: self [5128,5132]
===
match
---
and_test [6940,6983]
and_test [6960,7003]
===
match
---
name: log [8328,8331]
name: log [8348,8351]
===
match
---
number: 30 [2206,2208]
number: 30 [2234,2236]
===
match
---
operator: = [2775,2776]
operator: = [2803,2804]
===
match
---
name: heartrate [3280,3289]
name: heartrate [3308,3317]
===
match
---
name: create_session [8714,8728]
name: create_session [8734,8748]
===
match
---
name: classmethod [3826,3837]
name: classmethod [3846,3857]
===
match
---
trailer [2732,2884]
trailer [2760,2912]
===
match
---
trailer [5101,5104]
trailer [5121,5124]
===
match
---
name: Column [2388,2394]
name: Column [2416,2422]
===
match
---
expr_stmt [5058,5124]
expr_stmt [5078,5144]
===
match
---
name: executor [3462,3470]
name: executor [3490,3498]
===
match
---
name: exceptions [1116,1126]
name: exceptions [1101,1111]
===
match
---
trailer [9129,9137]
trailer [9149,9157]
===
match
---
operator: , [2820,2821]
operator: , [2848,2849]
===
match
---
if_stmt [7428,7661]
if_stmt [7448,7681]
===
match
---
name: foreign [2782,2789]
name: foreign [2810,2817]
===
match
---
trailer [5163,5165]
trailer [5183,5185]
===
match
---
atom_expr [7284,7294]
atom_expr [7304,7314]
===
match
---
operator: = [3895,3896]
operator: = [3915,3916]
===
match
---
name: session [7850,7857]
name: session [7870,7877]
===
match
---
trailer [7038,7055]
trailer [7058,7075]
===
match
---
name: session [7107,7114]
name: session [7127,7134]
===
match
---
simple_stmt [7402,7416]
simple_stmt [7422,7436]
===
match
---
trailer [5195,5203]
trailer [5215,5223]
===
match
---
operator: * [4895,4896]
operator: * [4915,4916]
===
match
---
name: queued_by_job_id [2803,2819]
name: queued_by_job_id [2831,2847]
===
match
---
trailer [3634,3644]
trailer [3662,3672]
===
match
---
atom_expr [2720,2884]
atom_expr [2748,2912]
===
match
---
operator: + [8281,8282]
operator: + [8301,8302]
===
match
---
trailer [5330,5333]
trailer [5350,5353]
===
match
---
arglist [3744,3776]
arglist [3764,3796]
===
match
---
atom_expr [5281,5334]
atom_expr [5301,5354]
===
match
---
dotted_name [1381,1394]
dotted_name [1366,1379]
===
insert-tree
---
simple_stmt [1553,1596]
    import_from [1553,1595]
        dotted_name [1558,1580]
            name: airflow [1558,1565]
            name: utils [1566,1571]
            name: platform [1572,1580]
        name: getuser [1588,1595]
to
file_input [790,9537]
at 18
===
insert-node
---
name: BaseJob [1757,1764]
to
classdef [1723,9537]
at 0
===
insert-tree
---
arglist [1765,1783]
    name: Base [1765,1769]
    operator: , [1769,1770]
    name: LoggingMixin [1771,1783]
to
classdef [1723,9537]
at 1
===
insert-tree
---
simple_stmt [1790,2052]
    string: """     Abstract class to be derived for jobs. Jobs are processing items with state     and duration that aren't task instances. For instance a BackfillJob is     a collection of task instance runs, but should have its own state, start     and end time.     """ [1790,2051]
to
suite [1757,9537]
at 0
===
insert-tree
---
simple_stmt [3070,3204]
    string: """     TaskInstances which have been enqueued by this Job.      Only makes sense for SchedulerJob and BackfillJob instances.     """ [3070,3203]
to
suite [1757,9537]
at 17
===
move-tree
---
name: getuser [3689,3696]
to
atom_expr [3681,3698]
at 0
===
delete-tree
---
simple_stmt [790,805]
    import_name [790,804]
        name: getpass [797,804]
===
delete-node
---
name: BaseJob [1729,1736]
===
===
delete-tree
---
arglist [1737,1755]
    name: Base [1737,1741]
    operator: , [1741,1742]
    name: LoggingMixin [1743,1755]
===
delete-tree
---
simple_stmt [1762,2024]
    string: """     Abstract class to be derived for jobs. Jobs are processing items with state     and duration that aren't task instances. For instance a BackfillJob is     a collection of task instance runs, but should have its own state, start     and end time.     """ [1762,2023]
===
delete-tree
---
simple_stmt [3042,3176]
    string: """     TaskInstances which have been enqueued by this Job.      Only makes sense for SchedulerJob and BackfillJob instances.     """ [3042,3175]
===
delete-node
---
name: getpass [3681,3688]
===
===
delete-node
---
trailer [3688,3696]
===
