===
match
---
operator: , [1306,1307]
operator: , [1306,1307]
===
match
---
name: frozen_sleep [5156,5168]
name: frozen_sleep [5148,5160]
===
match
---
trailer [5324,5344]
trailer [5316,5336]
===
match
---
name: job [2661,2664]
name: job [2661,2664]
===
match
---
name: test_heartbeat_failed [3454,3475]
name: test_heartbeat_failed [3454,3475]
===
match
---
operator: = [2358,2359]
operator: = [2358,2359]
===
match
---
atom_expr [1604,1616]
atom_expr [1604,1616]
===
match
---
name: hb_callback [5643,5654]
name: hb_callback [5635,5646]
===
match
---
trailer [1913,1921]
trailer [1913,1921]
===
match
---
atom_expr [1698,1726]
atom_expr [1698,1726]
===
match
---
dictorsetmaker [1249,1282]
dictorsetmaker [1249,1282]
===
match
---
simple_stmt [5410,5427]
simple_stmt [5402,5419]
===
match
---
lambdef [1706,1725]
lambdef [1706,1725]
===
match
---
argument [4666,4678]
argument [4658,4670]
===
match
---
name: add [2412,2415]
name: add [2412,2415]
===
match
---
atom_expr [3259,3289]
atom_expr [3259,3289]
===
match
---
name: test_job [5037,5045]
name: test_job [5029,5037]
===
match
---
name: datetime [2736,2744]
name: datetime [2736,2744]
===
match
---
operator: , [2347,2348]
operator: , [2347,2348]
===
match
---
trailer [3185,3191]
trailer [3185,3191]
===
match
---
trailer [2664,2673]
trailer [2664,2673]
===
match
---
operator: , [3949,3950]
operator: , [3949,3950]
===
match
---
parameters [5149,5182]
parameters [5141,5174]
===
match
---
expr_stmt [2232,2316]
expr_stmt [2232,2316]
===
match
---
operator: = [3517,3518]
operator: = [3517,3518]
===
match
---
string: 'MockJob' [1273,1282]
string: 'MockJob' [1273,1282]
===
match
---
expr_stmt [1692,1726]
expr_stmt [1692,1726]
===
match
---
trailer [5421,5426]
trailer [5413,5418]
===
match
---
simple_stmt [4570,4632]
simple_stmt [4562,4624]
===
match
---
operator: = [4675,4676]
operator: = [4667,4668]
===
match
---
name: airflow [1037,1044]
name: airflow [1037,1044]
===
match
---
simple_stmt [5643,5668]
simple_stmt [5635,5660]
===
match
---
import_from [1154,1199]
import_from [1154,1199]
===
match
---
name: Mock [3639,3643]
name: Mock [3639,3643]
===
match
---
suite [1663,1828]
suite [1663,1828]
===
match
---
assert_stmt [2654,2683]
assert_stmt [2654,2683]
===
match
---
operator: = [4549,4550]
operator: = [4541,4542]
===
match
---
trailer [5203,5211]
trailer [5195,5203]
===
match
---
name: unixname [4999,5007]
name: unixname [4991,4999]
===
match
---
simple_stmt [2896,2927]
simple_stmt [2896,2927]
===
match
---
comparison [5737,5764]
comparison [5729,5756]
===
match
---
assert_stmt [5073,5125]
assert_stmt [5065,5117]
===
match
---
name: seconds [2876,2883]
name: seconds [2876,2883]
===
match
---
simple_stmt [5357,5398]
simple_stmt [5349,5390]
===
match
---
simple_stmt [4934,4975]
simple_stmt [4926,4967]
===
match
---
operator: = [2190,2191]
operator: = [2190,2191]
===
match
---
operator: - [2284,2285]
operator: - [2284,2285]
===
match
---
atom_expr [1937,1951]
atom_expr [1937,1951]
===
match
---
name: self [4347,4351]
name: self [4339,4343]
===
match
---
name: job [1692,1695]
name: job [1692,1695]
===
match
---
atom_expr [3107,3133]
atom_expr [3107,3133]
===
match
---
name: state [1135,1140]
name: state [1135,1140]
===
match
---
arglist [3792,3831]
arglist [3792,3831]
===
match
---
operator: = [4686,4687]
operator: = [4678,4679]
===
match
---
name: session [3603,3610]
name: session [3603,3610]
===
match
---
comparison [4801,4825]
comparison [4793,4817]
===
match
---
name: session [2534,2541]
name: session [2534,2541]
===
match
---
suite [3611,4085]
suite [3611,4085]
===
match
---
number: 10 [4823,4825]
number: 10 [4815,4817]
===
match
---
atom_expr [2192,2219]
atom_expr [2192,2219]
===
match
---
expr_stmt [4641,4722]
expr_stmt [4633,4714]
===
match
---
trailer [2411,2415]
trailer [2411,2415]
===
match
---
name: old_job [2182,2189]
name: old_job [2182,2189]
===
match
---
atom_expr [4570,4604]
atom_expr [4562,4596]
===
match
---
import_name [790,805]
import_name [790,805]
===
match
---
trailer [3125,3133]
trailer [3125,3133]
===
match
---
assert_stmt [1597,1628]
assert_stmt [1597,1628]
===
match
---
operator: = [2333,2334]
operator: = [2333,2334]
===
match
---
number: 60 [3566,3568]
number: 60 [3566,3568]
===
match
---
atom_expr [2232,2256]
atom_expr [2232,2256]
===
match
---
name: sys [1679,1682]
name: sys [1679,1682]
===
match
---
trailer [1539,1543]
trailer [1539,1543]
===
match
---
atom_expr [2631,2644]
atom_expr [2631,2644]
===
match
---
expr_stmt [3886,3960]
expr_stmt [3886,3960]
===
match
---
trailer [2444,2450]
trailer [2444,2450]
===
match
---
operator: = [3652,3653]
operator: = [3652,3653]
===
match
---
operator: ** [1375,1377]
operator: ** [1375,1377]
===
match
---
trailer [2450,2452]
trailer [2450,2452]
===
match
---
simple_stmt [3182,3208]
simple_stmt [3182,3208]
===
match
---
name: datetime [3259,3267]
name: datetime [3259,3267]
===
match
---
name: executors [934,943]
name: executors [934,943]
===
match
---
name: state [1566,1571]
name: state [1566,1571]
===
match
---
assert_stmt [1555,1588]
assert_stmt [1555,1588]
===
match
---
name: heartbeat [3978,3987]
name: heartbeat [3978,3987]
===
match
---
operator: = [5481,5482]
operator: = [5473,5474]
===
match
---
simple_stmt [2591,2646]
simple_stmt [2591,2646]
===
match
---
name: job [2591,2594]
name: job [2591,2594]
===
match
---
simple_stmt [1032,1067]
simple_stmt [1032,1067]
===
match
---
name: test_essential_attr [4327,4346]
name: test_essential_attr [4319,4338]
===
match
---
operator: , [4351,4352]
operator: , [4343,4344]
===
match
---
operator: = [5315,5316]
operator: = [5307,5308]
===
match
---
name: jobs [1003,1007]
name: jobs [1003,1007]
===
match
---
simple_stmt [2375,2392]
simple_stmt [2375,2392]
===
match
---
simple_stmt [4983,5022]
simple_stmt [4975,5014]
===
match
---
name: job [2025,2028]
name: job [2025,2028]
===
match
---
operator: , [3480,3481]
operator: , [3480,3481]
===
match
---
operator: == [1771,1773]
operator: == [1771,1773]
===
match
---
simple_stmt [2437,2453]
simple_stmt [2437,2453]
===
match
---
param [5170,5181]
param [5162,5173]
===
match
---
expr_stmt [5357,5397]
expr_stmt [5349,5389]
===
match
---
atom_expr [1803,1815]
atom_expr [1803,1815]
===
match
---
name: job [1803,1806]
name: job [1803,1806]
===
match
---
trailer [2069,2078]
trailer [2069,2078]
===
match
---
atom [4102,4136]
atom [4102,4136]
===
match
---
name: SequentialExecutor [971,989]
name: SequentialExecutor [971,989]
===
match
---
atom_expr [4738,4761]
atom_expr [4730,4753]
===
match
---
name: self [5150,5154]
name: self [5142,5146]
===
match
---
name: hostname [4898,4906]
name: hostname [4890,4898]
===
match
---
expr_stmt [3694,3764]
expr_stmt [3694,3764]
===
match
---
trailer [2415,2424]
trailer [2415,2424]
===
match
---
operator: = [4497,4498]
operator: = [4489,4490]
===
match
---
name: timezone [2716,2724]
name: timezone [2716,2724]
===
match
---
suite [1409,1437]
suite [1409,1437]
===
match
---
name: test_job [4990,4998]
name: test_job [4982,4990]
===
match
---
name: session [5439,5446]
name: session [5431,5438]
===
match
---
name: latest_heartbeat [2697,2713]
name: latest_heartbeat [2697,2713]
===
match
---
name: heartrate [4810,4819]
name: heartrate [4802,4811]
===
match
---
operator: { [1248,1249]
operator: { [1248,1249]
===
match
---
string: "testuser" [5011,5021]
string: "testuser" [5003,5013]
===
match
---
trailer [5045,5051]
trailer [5037,5043]
===
match
---
trailer [3987,3989]
trailer [3987,3989]
===
match
---
assert_stmt [2896,2926]
assert_stmt [2896,2926]
===
match
---
name: job [1999,2002]
name: job [1999,2002]
===
match
---
simple_stmt [1999,2009]
simple_stmt [1999,2009]
===
match
---
decorated [3399,4085]
decorated [3399,4085]
===
match
---
operator: = [5624,5625]
operator: = [5616,5617]
===
match
---
name: job [4010,4013]
name: job [4010,4013]
===
match
---
simple_stmt [1597,1629]
simple_stmt [1597,1629]
===
match
---
comparison [2661,2683]
comparison [2661,2683]
===
match
---
simple_stmt [1116,1154]
simple_stmt [1116,1154]
===
match
---
name: session [2161,2168]
name: session [2161,2168]
===
match
---
simple_stmt [5581,5630]
simple_stmt [5573,5622]
===
match
---
funcdef [1289,1385]
funcdef [1289,1385]
===
match
---
name: self [1485,1489]
name: self [1485,1489]
===
match
---
trailer [1363,1365]
trailer [1363,1365]
===
match
---
name: utcnow [3248,3254]
name: utcnow [3248,3254]
===
match
---
trailer [1434,1436]
trailer [1434,1436]
===
match
---
name: heartrate [2349,2358]
name: heartrate [2349,2358]
===
match
---
comparison [1562,1588]
comparison [1562,1588]
===
match
---
import_from [1116,1153]
import_from [1116,1153]
===
match
---
trailer [3726,3736]
trailer [3726,3736]
===
match
---
trailer [4535,4548]
trailer [4527,4540]
===
match
---
simple_stmt [3142,3173]
simple_stmt [3142,3173]
===
match
---
with_item [3583,3610]
with_item [3583,3610]
===
match
---
simple_stmt [2814,2888]
simple_stmt [2814,2888]
===
match
---
atom_expr [2038,2050]
atom_expr [2038,2050]
===
match
---
name: exc [892,895]
name: exc [892,895]
===
match
---
param [1308,1313]
param [1308,1313]
===
match
---
simple_stmt [2059,2091]
simple_stmt [2059,2091]
===
match
---
atom [4101,4144]
atom [4101,4144]
===
match
---
atom_expr [1735,1744]
atom_expr [1735,1744]
===
match
---
simple_stmt [3694,3765]
simple_stmt [3694,3765]
===
match
---
operator: = [2215,2216]
operator: = [2215,2216]
===
match
---
atom_expr [5270,5286]
atom_expr [5262,5278]
===
match
---
simple_stmt [3216,3290]
simple_stmt [3216,3290]
===
match
---
dotted_name [1072,1093]
dotted_name [1072,1093]
===
match
---
operator: , [3953,3954]
operator: , [3953,3954]
===
match
---
operator: @ [4090,4091]
operator: @ [4090,4091]
===
match
---
decorator [4150,4218]
decorator [4150,4218]
===
match
---
name: base_job [1008,1016]
name: base_job [1008,1016]
===
match
---
suite [2169,2553]
suite [2169,2553]
===
match
---
arglist [2605,2644]
arglist [2605,2644]
===
match
---
simple_stmt [4794,4826]
simple_stmt [4786,4818]
===
match
---
atom_expr [3845,3865]
atom_expr [3845,3865]
===
match
---
name: job [3149,3152]
name: job [3149,3152]
===
match
---
simple_stmt [1230,1284]
simple_stmt [1230,1284]
===
match
---
name: test_job [4841,4849]
name: test_job [4833,4841]
===
match
---
trailer [2604,2645]
trailer [2604,2645]
===
match
---
trailer [3643,3681]
trailer [3643,3681]
===
match
---
name: RUNNING [3824,3831]
name: RUNNING [3824,3831]
===
match
---
operator: - [2734,2735]
operator: - [2734,2735]
===
match
---
name: airflow [995,1002]
name: airflow [995,1002]
===
match
---
funcdef [1634,1828]
funcdef [1634,1828]
===
match
---
name: RuntimeError [1901,1913]
name: RuntimeError [1901,1913]
===
match
---
name: latest_heartbeat [2240,2256]
name: latest_heartbeat [2240,2256]
===
match
---
trailer [4459,4461]
trailer [4451,4453]
===
match
---
atom_expr [5357,5377]
atom_expr [5349,5369]
===
match
---
name: State [2631,2636]
name: State [2631,2636]
===
match
---
name: create_session [2141,2155]
name: create_session [2141,2155]
===
match
---
trailer [4809,4819]
trailer [4801,4811]
===
match
---
name: job [1735,1738]
name: job [1735,1738]
===
match
---
name: SUCCESS [1581,1588]
name: SUCCESS [1581,1588]
===
match
---
assert_stmt [4934,4974]
assert_stmt [4926,4966]
===
match
---
name: self [2576,2580]
name: self [2576,2580]
===
match
---
expr_stmt [3778,3832]
expr_stmt [3778,3832]
===
match
---
trailer [1764,1770]
trailer [1764,1770]
===
match
---
name: timedelta [3548,3557]
name: timedelta [3548,3557]
===
match
---
arglist [3644,3680]
arglist [3644,3680]
===
match
---
name: test_utils [1165,1175]
name: test_utils [1165,1175]
===
match
---
name: func [1338,1342]
name: func [1338,1342]
===
match
---
suite [1457,5765]
suite [1457,5757]
===
match
---
operator: , [4038,4039]
operator: , [4038,4039]
===
match
---
name: timedelta [2745,2754]
name: timedelta [2745,2754]
===
match
---
name: heartrate [5331,5340]
name: heartrate [5323,5332]
===
match
---
name: utcnow [5389,5395]
name: utcnow [5381,5387]
===
match
---
trailer [1365,1374]
trailer [1365,1374]
===
match
---
dotted_name [1121,1140]
dotted_name [1121,1140]
===
match
---
operator: = [2257,2258]
operator: = [2257,2258]
===
match
---
name: state [3186,3191]
name: state [3186,3191]
===
match
---
operator: == [2035,2037]
operator: == [2035,2037]
===
match
---
decorator [4271,4319]
decorator [4271,4311]
===
match
---
decorated [4090,5126]
decorated [4090,5118]
===
match
---
trailer [1717,1722]
trailer [1717,1722]
===
match
---
name: create_session [3583,3597]
name: create_session [3583,3597]
===
match
---
name: dag_id [4680,4686]
name: dag_id [4672,4678]
===
match
---
name: is_alive [3153,3161]
name: is_alive [3153,3161]
===
match
---
name: __init__ [1366,1374]
name: __init__ [1366,1374]
===
match
---
name: old_job [2259,2266]
name: old_job [2259,2266]
===
match
---
name: heartrate [2611,2620]
name: heartrate [2611,2620]
===
match
---
comparison [2066,2090]
comparison [2066,2090]
===
match
---
arith_expr [3519,3569]
arith_expr [3519,3569]
===
match
---
atom_expr [1425,1436]
atom_expr [1425,1436]
===
match
---
operator: = [3565,3566]
operator: = [3565,3566]
===
match
---
operator: , [2204,2205]
operator: , [2204,2205]
===
match
---
trailer [1722,1725]
trailer [1722,1725]
===
match
---
trailer [1742,1744]
trailer [1742,1744]
===
match
---
simple_stmt [2018,2051]
simple_stmt [2018,2051]
===
match
---
suite [4405,5126]
suite [4397,5118]
===
match
---
string: 'airflow.jobs.base_job.get_hostname' [4229,4265]
string: 'airflow.jobs.base_job.get_hostname' [4229,4265]
===
match
---
trailer [2865,2875]
trailer [2865,2875]
===
match
---
name: patch [4223,4228]
name: patch [4223,4228]
===
match
---
trailer [2673,2675]
trailer [2673,2675]
===
match
---
return_stmt [1418,1436]
return_stmt [1418,1436]
===
match
---
trailer [2915,2917]
trailer [2915,2917]
===
match
---
parameters [3475,3502]
parameters [3475,3502]
===
match
---
comp_op [1816,1822]
comp_op [1816,1822]
===
match
---
suite [1324,1385]
suite [1324,1385]
===
match
---
atom_expr [2837,2854]
atom_expr [2837,2854]
===
match
---
name: airflow [926,933]
name: airflow [926,933]
===
match
---
name: run [2003,2006]
name: run [2003,2006]
===
match
---
atom_expr [2375,2391]
atom_expr [2375,2391]
===
match
---
comparison [2025,2050]
comparison [2025,2050]
===
match
---
operator: = [5378,5379]
operator: = [5370,5371]
===
match
---
operator: == [1572,1574]
operator: == [1572,1574]
===
match
---
arith_expr [3087,3133]
arith_expr [3087,3133]
===
match
---
trailer [3308,3317]
trailer [3308,3317]
===
match
---
name: FAILED [2044,2050]
name: FAILED [2044,2050]
===
match
---
operator: == [4031,4033]
operator: == [4031,4033]
===
match
---
name: return_value [4484,4496]
name: return_value [4476,4488]
===
match
---
trailer [5555,5565]
trailer [5547,5557]
===
match
---
trailer [2480,2496]
trailer [2480,2496]
===
match
---
suite [1861,2091]
suite [1861,2091]
===
match
---
trailer [5748,5755]
trailer [5740,5747]
===
match
---
operator: - [3257,3258]
operator: - [3257,3258]
===
match
---
operator: = [3237,3238]
operator: = [3237,3238]
===
match
---
atom_expr [3539,3569]
atom_expr [3539,3569]
===
match
---
trailer [3791,3832]
trailer [3791,3832]
===
match
---
atom_expr [4708,4721]
atom_expr [4700,4713]
===
match
---
trailer [2342,2362]
trailer [2342,2362]
===
match
---
name: latest_heartbeat [2267,2283]
name: latest_heartbeat [2267,2283]
===
match
---
name: job [1536,1539]
name: job [1536,1539]
===
match
---
name: utcnow [2725,2731]
name: utcnow [2725,2731]
===
match
---
name: heartbeat [5556,5565]
name: heartbeat [5548,5557]
===
match
---
simple_stmt [5680,5718]
simple_stmt [5672,5710]
===
match
---
name: setattr [5204,5211]
name: setattr [5196,5203]
===
match
---
parameters [1879,1881]
parameters [1879,1881]
===
match
---
atom_expr [2693,2713]
atom_expr [2693,2713]
===
match
---
trailer [2636,2644]
trailer [2636,2644]
===
match
---
operator: = [2630,2631]
operator: = [2630,2631]
===
match
---
name: commit [5447,5453]
name: commit [5439,5445]
===
match
---
operator: , [841,842]
operator: , [841,842]
===
match
---
import_from [806,848]
import_from [806,848]
===
match
---
trailer [2239,2256]
trailer [2239,2256]
===
match
---
operator: = [2312,2313]
operator: = [2312,2313]
===
match
---
name: job [3778,3781]
name: job [3778,3781]
===
match
---
trailer [3736,3749]
trailer [3736,3749]
===
match
---
simple_stmt [3886,3961]
simple_stmt [3886,3961]
===
match
---
name: utcnow [3096,3102]
name: utcnow [3096,3102]
===
match
---
name: is_alive [2907,2915]
name: is_alive [2907,2915]
===
match
---
funcdef [3450,4085]
funcdef [3450,4085]
===
match
---
name: job [3216,3219]
name: job [3216,3219]
===
match
---
name: SequentialExecutor [4441,4459]
name: SequentialExecutor [4433,4451]
===
match
---
trailer [1513,1527]
trailer [1513,1527]
===
match
---
expr_stmt [3845,3872]
expr_stmt [3845,3872]
===
match
---
name: hb_callback [5527,5538]
name: hb_callback [5519,5530]
===
match
---
name: seconds [2755,2762]
name: seconds [2755,2762]
===
match
---
trailer [2744,2754]
trailer [2744,2754]
===
match
---
comparison [4010,4038]
comparison [4010,4038]
===
match
---
name: state [4702,4707]
name: state [4694,4699]
===
match
---
trailer [4013,4030]
trailer [4013,4030]
===
match
---
name: name [3662,3666]
name: name [3662,3666]
===
match
---
trailer [2304,2316]
trailer [2304,2316]
===
match
---
simple_stmt [5030,5065]
simple_stmt [5022,5057]
===
match
---
operator: - [3105,3106]
operator: - [3105,3106]
===
match
---
atom [1248,1283]
atom [1248,1283]
===
match
---
trailer [5616,5629]
trailer [5608,5621]
===
match
---
parameters [1402,1408]
parameters [1402,1408]
===
match
---
name: job [1931,1934]
name: job [1931,1934]
===
match
---
trailer [5388,5395]
trailer [5380,5387]
===
match
---
atom_expr [5037,5051]
atom_expr [5029,5043]
===
match
---
name: end_date [1807,1815]
name: end_date [1807,1815]
===
match
---
simple_stmt [806,849]
simple_stmt [806,849]
===
match
---
name: state [2625,2630]
name: state [2625,2630]
===
match
---
atom_expr [2716,2733]
atom_expr [2716,2733]
===
match
---
assert_stmt [2775,2804]
assert_stmt [2775,2804]
===
match
---
simple_stmt [2182,2220]
simple_stmt [2182,2220]
===
match
---
string: "Completed jobs even with recent heartbeat should not be alive" [3330,3393]
string: "Completed jobs even with recent heartbeat should not be alive" [3330,3393]
===
match
---
name: MockJob [4652,4659]
name: MockJob [4644,4651]
===
match
---
trailer [2266,2283]
trailer [2266,2283]
===
match
---
name: mock_create_session [3482,3501]
name: mock_create_session [3482,3501]
===
match
---
trailer [1374,1384]
trailer [1374,1384]
===
match
---
import_from [850,875]
import_from [850,875]
===
match
---
name: job [5422,5425]
name: job [5414,5417]
===
match
---
trailer [2852,2854]
trailer [2852,2854]
===
match
---
parameters [1484,1490]
parameters [1484,1490]
===
match
---
arglist [5212,5255]
arglist [5204,5247]
===
match
---
expr_stmt [2693,2766]
expr_stmt [2693,2766]
===
match
---
argument [2755,2765]
argument [2755,2765]
===
match
---
simple_stmt [1555,1589]
simple_stmt [1555,1589]
===
match
---
name: raises [1965,1971]
name: raises [1965,1971]
===
match
---
simple_stmt [3298,3394]
simple_stmt [3298,3394]
===
match
---
operator: { [4101,4102]
operator: { [4101,4102]
===
match
---
name: mock_getuser [4353,4365]
name: mock_getuser [4345,4357]
===
match
---
operator: = [4707,4708]
operator: = [4699,4700]
===
match
---
arith_expr [2837,2887]
arith_expr [2837,2887]
===
match
---
name: job [5502,5505]
name: job [5494,5497]
===
match
---
atom_expr [1999,2008]
atom_expr [1999,2008]
===
match
---
name: create_session [5270,5284]
name: create_session [5262,5276]
===
match
---
simple_stmt [1692,1727]
simple_stmt [1692,1727]
===
match
---
operator: = [1696,1697]
operator: = [1696,1697]
===
match
---
name: job [1604,1607]
name: job [1604,1607]
===
match
---
arglist [2200,2218]
arglist [2200,2218]
===
match
---
trailer [2199,2219]
trailer [2199,2219]
===
match
---
name: old_job [2416,2423]
name: old_job [2416,2423]
===
match
---
operator: = [3918,3919]
operator: = [3918,3919]
===
match
---
assert_stmt [2018,2050]
assert_stmt [2018,2050]
===
match
---
suite [5298,5765]
suite [5290,5757]
===
match
---
operator: , [5241,5242]
operator: , [5233,5234]
===
match
---
name: timedelta [2295,2304]
name: timedelta [2295,2304]
===
match
---
atom_expr [4841,4856]
atom_expr [4833,4848]
===
match
---
atom_expr [2286,2316]
atom_expr [2286,2316]
===
match
---
param [1657,1661]
param [1657,1661]
===
match
---
operator: = [5711,5712]
operator: = [5703,5704]
===
match
---
atom_expr [2534,2552]
atom_expr [2534,2552]
===
match
---
arith_expr [2716,2766]
arith_expr [2716,2766]
===
match
---
operator: , [2609,2610]
operator: , [2609,2610]
===
match
---
atom_expr [4010,4030]
atom_expr [4010,4030]
===
match
---
expr_stmt [4523,4561]
expr_stmt [4515,4553]
===
match
---
operator: = [3807,3808]
operator: = [3807,3808]
===
match
---
name: latest_heartbeat [3220,3236]
name: latest_heartbeat [3220,3236]
===
match
---
simple_stmt [3974,3990]
simple_stmt [3974,3990]
===
match
---
operator: , [4700,4701]
operator: , [4692,4693]
===
match
---
operator: == [4907,4909]
operator: == [4899,4901]
===
match
---
name: job [2517,2520]
name: job [2517,2520]
===
match
---
testlist_comp [4103,4135]
testlist_comp [4103,4135]
===
match
---
name: session [5410,5417]
name: session [5402,5409]
===
match
---
suite [2582,3394]
suite [2582,3394]
===
match
---
expr_stmt [3624,3681]
expr_stmt [3624,3681]
===
match
---
operator: == [5052,5054]
operator: == [5044,5046]
===
match
---
operator: = [1343,1344]
operator: = [1343,1344]
===
match
---
simple_stmt [1358,1385]
simple_stmt [1358,1385]
===
match
---
dotted_name [881,895]
dotted_name [881,895]
===
match
---
string: 'airflow.jobs.base_job.create_session' [3406,3444]
string: 'airflow.jobs.base_job.create_session' [3406,3444]
===
match
---
dotted_name [1159,1182]
dotted_name [1159,1182]
===
match
---
comparison [4738,4785]
comparison [4730,4777]
===
match
---
import_from [876,919]
import_from [876,919]
===
match
---
simple_stmt [1067,1116]
simple_stmt [1067,1116]
===
match
---
name: session [2404,2411]
name: session [2404,2411]
===
match
---
assert_stmt [4834,4873]
assert_stmt [4826,4865]
===
match
---
string: "Force fail" [3937,3949]
string: "Force fail" [3937,3949]
===
match
---
argument [3662,3680]
argument [3662,3680]
===
match
---
argument [5331,5343]
argument [5323,5335]
===
match
---
trailer [5417,5421]
trailer [5409,5413]
===
match
---
atom_expr [3639,3681]
atom_expr [3639,3681]
===
match
---
name: __init__ [1293,1301]
name: __init__ [1293,1301]
===
match
---
name: job [5311,5314]
name: job [5303,5306]
===
match
---
trailer [3823,3831]
trailer [3823,3831]
===
match
---
name: airflow [1121,1128]
name: airflow [1121,1128]
===
match
---
trailer [3267,3277]
trailer [3267,3277]
===
match
---
name: test_heartbeat [5135,5149]
name: test_heartbeat [5127,5141]
===
match
---
string: 'airflow.jobs.base_job.getpass.getuser' [4278,4317]
string: 'airflow.jobs.base_job.getuser' [4278,4309]
===
match
---
trailer [3199,3207]
trailer [3199,3207]
===
match
---
operator: == [5098,5100]
operator: == [5090,5092]
===
match
---
operator: , [5154,5155]
operator: , [5146,5147]
===
match
---
simple_stmt [790,806]
simple_stmt [790,806]
===
match
---
trailer [2696,2713]
trailer [2696,2713]
===
match
---
string: 'max_tis_per_query' [4116,4135]
string: 'max_tis_per_query' [4116,4135]
===
match
---
number: 10 [2359,2361]
number: 10 [2359,2361]
===
match
---
name: State [4708,4713]
name: State [4700,4705]
===
match
---
trailer [2294,2304]
trailer [2294,2304]
===
match
---
expr_stmt [1230,1283]
expr_stmt [1230,1283]
===
match
---
name: test_job [4941,4949]
name: test_job [4933,4941]
===
match
---
atom_expr [3087,3104]
atom_expr [3087,3104]
===
match
---
name: session [2437,2444]
name: session [2437,2444]
===
match
---
dotted_name [811,824]
dotted_name [811,824]
===
match
---
atom_expr [3216,3236]
atom_expr [3216,3236]
===
match
---
atom_expr [4941,4967]
atom_expr [4933,4959]
===
match
---
name: days [3126,3130]
name: days [3126,3130]
===
match
---
operator: = [3130,3131]
operator: = [3130,3131]
===
match
---
trailer [2155,2157]
trailer [2155,2157]
===
match
---
name: MockJob [3784,3791]
name: MockJob [3784,3791]
===
match
---
name: mock_sequential_executor [4414,4438]
name: mock_sequential_executor [4406,4430]
===
match
---
argument [2497,2512]
argument [2497,2512]
===
match
---
name: ANY [832,835]
name: ANY [832,835]
===
match
---
name: max_tis_per_query [4950,4967]
name: max_tis_per_query [4942,4959]
===
match
---
number: 21 [2884,2886]
number: 21 [2884,2886]
===
match
---
argument [3644,3660]
argument [3644,3660]
===
match
---
atom_expr [4523,4548]
atom_expr [4515,4540]
===
match
---
name: heartrate [4666,4675]
name: heartrate [4658,4667]
===
match
---
import_from [990,1031]
import_from [990,1031]
===
match
---
atom_expr [2903,2917]
atom_expr [2903,2917]
===
match
---
name: config [1176,1182]
name: config [1176,1182]
===
match
---
operator: = [2714,2715]
operator: = [2714,2715]
===
match
---
name: RUNNING [2637,2644]
name: RUNNING [2637,2644]
===
match
---
decorator [3399,3446]
decorator [3399,3446]
===
match
---
trailer [3277,3289]
trailer [3277,3289]
===
match
---
name: mock_hostname [4470,4483]
name: mock_hostname [4462,4475]
===
match
---
name: session [2375,2382]
name: session [2375,2382]
===
match
---
name: RUNNING [4714,4721]
name: RUNNING [4706,4713]
===
match
---
operator: } [3952,3953]
operator: } [3952,3953]
===
match
---
operator: = [1504,1505]
operator: = [1504,1505]
===
match
---
name: heartrate [2206,2215]
name: heartrate [2206,2215]
===
match
---
with_item [5270,5297]
with_item [5262,5289]
===
match
---
name: seconds [3278,3285]
name: seconds [3278,3285]
===
match
---
dotted_name [995,1016]
dotted_name [995,1016]
===
match
---
name: mock_session [3886,3898]
name: mock_session [3886,3898]
===
match
---
assert_stmt [5030,5064]
assert_stmt [5022,5056]
===
match
---
funcdef [1462,1629]
funcdef [1462,1629]
===
match
---
atom_expr [2814,2834]
atom_expr [2814,2834]
===
match
---
comparison [2903,2926]
comparison [2903,2926]
===
match
---
atom_expr [3920,3960]
atom_expr [3920,3960]
===
match
---
operator: == [4820,4822]
operator: == [4812,4814]
===
match
---
operator: == [5008,5010]
operator: == [5000,5002]
===
match
---
trailer [4591,4604]
trailer [4583,4596]
===
match
---
assert_stmt [4731,4785]
assert_stmt [4723,4777]
===
match
---
name: seconds [2305,2312]
name: seconds [2305,2312]
===
match
---
simple_stmt [5439,5456]
simple_stmt [5431,5448]
===
match
---
name: session [2505,2512]
name: session [2505,2512]
===
match
---
name: run [1739,1742]
name: run [1739,1742]
===
match
---
funcdef [1833,2091]
funcdef [1833,2091]
===
match
---
name: exit [1718,1722]
name: exit [1718,1722]
===
match
---
trailer [1565,1571]
trailer [1565,1571]
===
match
---
operator: = [2762,2763]
operator: = [2762,2763]
===
match
---
atom_expr [1714,1725]
atom_expr [1714,1725]
===
match
---
arith_expr [2259,2316]
arith_expr [2259,2316]
===
match
---
with_stmt [1960,2009]
with_stmt [1960,2009]
===
match
---
operator: = [4605,4606]
operator: = [4597,4598]
===
match
---
name: session [1086,1093]
name: session [1086,1093]
===
match
---
name: mock_getuser [4523,4535]
name: mock_getuser [4515,4527]
===
match
---
decorator [4090,4146]
decorator [4090,4146]
===
match
---
atom_expr [4801,4819]
atom_expr [4793,4811]
===
match
---
simple_stmt [2232,2317]
simple_stmt [2232,2317]
===
match
---
arglist [2343,2361]
arglist [2343,2361]
===
match
---
funcdef [4323,5126]
funcdef [4315,5118]
===
match
---
expr_stmt [2329,2362]
expr_stmt [2329,2362]
===
match
---
dictorsetmaker [4102,4143]
dictorsetmaker [4102,4143]
===
match
---
atom_expr [4889,4906]
atom_expr [4881,4898]
===
match
---
name: job [2814,2817]
name: job [2814,2817]
===
match
---
argument [3558,3568]
argument [3558,3568]
===
match
---
name: timezone [2837,2845]
name: timezone [2837,2845]
===
match
---
operator: = [3866,3867]
operator: = [3866,3867]
===
match
---
string: "SequentialExecutor" [4765,4785]
string: "SequentialExecutor" [4757,4777]
===
match
---
expr_stmt [1500,1527]
expr_stmt [1500,1527]
===
match
---
name: job [5552,5555]
name: job [5544,5547]
===
match
---
simple_stmt [876,920]
simple_stmt [876,920]
===
match
---
argument [2349,2361]
argument [2349,2361]
===
match
---
param [4353,4366]
param [4345,4358]
===
match
---
trailer [4659,4722]
trailer [4651,4714]
===
match
---
name: State [2038,2043]
name: State [2038,2043]
===
match
---
comparison [5080,5125]
comparison [5072,5117]
===
match
---
name: abort [1874,1879]
name: abort [1874,1879]
===
match
---
name: mock_create_session [3694,3713]
name: mock_create_session [3694,3713]
===
match
---
atom_expr [2404,2424]
atom_expr [2404,2424]
===
match
---
name: State [1148,1153]
name: State [1148,1153]
===
match
---
name: MockJob [2335,2342]
name: MockJob [2335,2342]
===
match
---
name: test_job [4641,4649]
name: test_job [4633,4641]
===
match
---
atom_expr [1575,1588]
atom_expr [1575,1588]
===
match
---
param [5156,5169]
param [5148,5161]
===
match
---
name: latest_heartbeat [4014,4030]
name: latest_heartbeat [4014,4030]
===
match
---
name: State [3194,3199]
name: State [3194,3199]
===
match
---
name: __mapper_args__ [1230,1245]
name: __mapper_args__ [1230,1245]
===
match
---
expr_stmt [1333,1349]
expr_stmt [1333,1349]
===
match
---
atom_expr [5581,5629]
atom_expr [5573,5621]
===
match
---
name: timezone [1058,1066]
name: timezone [1058,1066]
===
match
---
argument [4702,4721]
argument [4694,4713]
===
match
---
with_item [2141,2168]
with_item [2141,2168]
===
match
---
expr_stmt [4470,4514]
expr_stmt [4462,4506]
===
match
---
operator: = [2883,2884]
operator: = [2883,2884]
===
match
---
name: job [1761,1764]
name: job [1761,1764]
===
match
---
name: job [2693,2696]
name: job [2693,2696]
===
match
---
simple_stmt [1754,1788]
simple_stmt [1754,1788]
===
match
---
name: MockJob [2473,2480]
name: MockJob [2473,2480]
===
match
---
name: frozen_sleep [5243,5255]
name: frozen_sleep [5235,5247]
===
match
---
trailer [3898,3905]
trailer [3898,3905]
===
match
---
simple_stmt [4470,4515]
simple_stmt [4462,4507]
===
match
---
expr_stmt [3216,3289]
expr_stmt [3216,3289]
===
match
---
name: MockJob [5317,5324]
name: MockJob [5309,5316]
===
match
---
name: State [1575,1580]
name: State [1575,1580]
===
match
---
assert_stmt [4003,4084]
assert_stmt [4003,4084]
===
match
---
trailer [3254,3256]
trailer [3254,3256]
===
match
---
name: test_job [4738,4746]
name: test_job [4730,4738]
===
match
---
name: timezone [3087,3095]
name: timezone [3087,3095]
===
match
---
name: end_date [1608,1616]
name: end_date [1608,1616]
===
match
---
name: kwargs [1377,1383]
name: kwargs [1377,1383]
===
match
---
trailer [1971,1985]
trailer [1971,1985]
===
match
---
assert_stmt [2466,2520]
assert_stmt [2466,2520]
===
match
---
number: 20 [2763,2765]
number: 20 [2763,2765]
===
match
---
name: job [3845,3848]
name: job [3845,3848]
===
match
---
simple_stmt [5192,5257]
simple_stmt [5184,5249]
===
match
---
simple_stmt [1931,1952]
simple_stmt [1931,1952]
===
match
---
name: patch [4272,4277]
name: patch [4272,4277]
===
match
---
name: state [3812,3817]
name: state [3812,3817]
===
match
---
assert_stmt [3298,3393]
assert_stmt [3298,3393]
===
match
---
name: _execute [1394,1402]
name: _execute [1394,1402]
===
match
---
atom_expr [3583,3599]
atom_expr [3583,3599]
===
match
---
simple_stmt [1796,1828]
simple_stmt [1796,1828]
===
match
---
trailer [5683,5693]
trailer [5675,5685]
===
match
---
suite [3503,4085]
suite [3503,4085]
===
match
---
expr_stmt [2591,2645]
expr_stmt [2591,2645]
===
match
---
expr_stmt [5311,5344]
expr_stmt [5303,5336]
===
match
---
name: timedelta [3116,3125]
name: timedelta [3116,3125]
===
match
---
name: self [1302,1306]
name: self [1302,1306]
===
match
---
name: dag_id [4850,4856]
name: dag_id [4842,4848]
===
match
---
string: "running" [5055,5064]
string: "running" [5047,5056]
===
match
---
name: abort [1945,1950]
name: abort [1945,1950]
===
match
---
operator: = [2835,2836]
operator: = [2835,2836]
===
match
---
atom_expr [1774,1787]
atom_expr [1774,1787]
===
match
---
name: reset_mock [5655,5665]
name: reset_mock [5647,5657]
===
match
---
name: job [2329,2332]
name: job [2329,2332]
===
match
---
trailer [5395,5397]
trailer [5387,5389]
===
match
---
simple_stmt [4641,4723]
simple_stmt [4633,4715]
===
match
---
operator: @ [4150,4151]
operator: @ [4150,4151]
===
match
---
expr_stmt [2814,2887]
expr_stmt [2814,2887]
===
match
---
trailer [1705,1726]
trailer [1705,1726]
===
match
---
name: kwargs [1316,1322]
name: kwargs [1316,1322]
===
match
---
argument [5694,5716]
argument [5686,5708]
===
match
---
atom_expr [1562,1571]
atom_expr [1562,1571]
===
match
---
atom_expr [3149,3163]
atom_expr [3149,3163]
===
match
---
atom_expr [3974,3989]
atom_expr [3974,3989]
===
match
---
simple_stmt [990,1032]
simple_stmt [990,1032]
===
match
---
name: func [1345,1349]
name: func [1345,1349]
===
match
---
param [2576,2580]
param [2576,2580]
===
match
---
assert_stmt [3142,3172]
assert_stmt [3142,3172]
===
match
---
atom_expr [2259,2283]
atom_expr [2259,2283]
===
match
---
string: "test_hostname" [4910,4925]
string: "test_hostname" [4902,4917]
===
match
---
string: "example_dag" [4687,4700]
string: "example_dag" [4679,4692]
===
match
---
atom_expr [2473,2513]
atom_expr [2473,2513]
===
match
---
name: test_job [4801,4809]
name: test_job [4793,4801]
===
match
---
parameters [2575,2581]
parameters [2575,2581]
===
match
---
name: add [2383,2386]
name: add [2383,2386]
===
match
---
trailer [2382,2386]
trailer [2382,2386]
===
match
---
simple_stmt [5552,5568]
simple_stmt [5544,5560]
===
match
---
expr_stmt [3182,3207]
expr_stmt [3182,3207]
===
match
---
param [1314,1322]
param [1314,1322]
===
match
---
atom [3951,3953]
atom [3951,3953]
===
match
---
argument [3798,3810]
argument [3798,3810]
===
match
---
atom_expr [1358,1384]
atom_expr [1358,1384]
===
match
---
name: sqlalchemy [881,891]
name: sqlalchemy [881,891]
===
match
---
operator: = [4439,4440]
operator: = [4431,4432]
===
match
---
suite [1882,1922]
suite [1882,1922]
===
match
---
with_stmt [5265,5765]
with_stmt [5257,5757]
===
match
---
operator: } [1282,1283]
operator: } [1282,1283]
===
match
---
trailer [2541,2550]
trailer [2541,2550]
===
match
---
atom_expr [3694,3749]
atom_expr [3694,3749]
===
match
---
string: 'scheduler' [4103,4114]
string: 'scheduler' [4103,4114]
===
match
---
name: job [5680,5683]
name: job [5672,5675]
===
match
---
argument [2305,2315]
argument [2305,2315]
===
match
---
trailer [2794,2796]
trailer [2794,2796]
===
match
---
name: State [1774,1779]
name: State [1774,1779]
===
match
---
name: unittest [811,819]
name: unittest [811,819]
===
match
---
name: conf_vars [4091,4100]
name: conf_vars [4091,4100]
===
match
---
parameters [2120,2126]
parameters [2120,2126]
===
match
---
operator: = [2504,2505]
operator: = [2504,2505]
===
match
---
operator: , [1312,1313]
operator: , [1312,1313]
===
match
---
comparison [1604,1628]
comparison [1604,1628]
===
match
---
argument [5617,5628]
argument [5609,5620]
===
match
---
simple_stmt [2775,2805]
simple_stmt [2775,2805]
===
match
---
import_as_names [832,848]
import_as_names [832,848]
===
match
---
param [4367,4381]
param [4359,4373]
===
match
---
string: "example_dag" [4860,4873]
string: "example_dag" [4852,4865]
===
match
---
trailer [3848,3865]
trailer [3848,3865]
===
match
---
name: mock_default_executor [4570,4591]
name: mock_default_executor [4562,4583]
===
match
---
classdef [1202,1437]
classdef [1202,1437]
===
match
---
name: job [2903,2906]
name: job [2903,2906]
===
match
---
atom_expr [1333,1342]
atom_expr [1333,1342]
===
match
---
name: self [1855,1859]
name: self [1855,1859]
===
match
---
simple_stmt [2693,2767]
simple_stmt [2693,2767]
===
match
---
trailer [3547,3557]
trailer [3547,3557]
===
match
---
name: MockJob [2597,2604]
name: MockJob [2597,2604]
===
match
---
argument [2625,2644]
argument [2625,2644]
===
match
---
operator: = [3666,3667]
operator: = [3666,3667]
===
match
---
assert_stmt [1796,1827]
assert_stmt [1796,1827]
===
match
---
name: mock_session [3752,3764]
name: mock_session [3752,3764]
===
match
---
name: datetime [2857,2865]
name: datetime [2857,2865]
===
match
---
name: func [1308,1312]
name: func [1308,1312]
===
match
---
number: 1 [3131,3132]
number: 1 [3131,3132]
===
match
---
name: MockJob [1208,1215]
name: MockJob [1208,1215]
===
match
---
simple_stmt [3064,3134]
simple_stmt [3064,3134]
===
match
---
name: monkeypatch [5192,5203]
name: monkeypatch [5184,5195]
===
match
---
comparison [4841,4873]
comparison [4833,4865]
===
match
---
trailer [4949,4967]
trailer [4941,4959]
===
match
---
string: 'airflow.jobs.base_job.sleep' [5212,5241]
string: 'airflow.jobs.base_job.sleep' [5204,5233]
===
match
---
trailer [4998,5007]
trailer [4990,4999]
===
match
---
name: assert_called_once_with [5593,5616]
name: assert_called_once_with [5585,5608]
===
match
---
trailer [5665,5667]
trailer [5657,5659]
===
match
---
atom_expr [4652,4722]
atom_expr [4644,4714]
===
match
---
name: job [1562,1565]
name: job [1562,1565]
===
match
---
atom_expr [2597,2645]
atom_expr [2597,2645]
===
match
---
name: timezone [3519,3527]
name: timezone [3519,3527]
===
match
---
name: datetime [3539,3547]
name: datetime [3539,3547]
===
match
---
name: most_recent_job [2481,2496]
name: most_recent_job [2481,2496]
===
match
---
name: hb_callback [5581,5592]
name: hb_callback [5573,5584]
===
match
---
atom_expr [4470,4496]
atom_expr [4462,4488]
===
match
---
name: job [2387,2390]
name: job [2387,2390]
===
match
---
trailer [4713,4721]
trailer [4705,4713]
===
match
---
suite [1986,2009]
suite [1986,2009]
===
match
---
atom_expr [5680,5717]
atom_expr [5672,5709]
===
match
---
trailer [2043,2050]
trailer [2043,2050]
===
match
---
number: 0 [1723,1724]
number: 0 [1723,1724]
===
match
---
atom_expr [4990,5007]
atom_expr [4982,4999]
===
match
---
name: latest_heartbeat [5361,5377]
name: latest_heartbeat [5353,5369]
===
match
---
name: timezone [5380,5388]
name: timezone [5372,5380]
===
match
---
name: return_value [3714,3726]
name: return_value [3714,3726]
===
match
---
comparison [1761,1787]
comparison [1761,1787]
===
match
---
trailer [1806,1815]
trailer [1806,1815]
===
match
---
arglist [4660,4721]
arglist [4652,4713]
===
match
---
parameters [1656,1662]
parameters [1656,1662]
===
match
---
atom_expr [5552,5567]
atom_expr [5544,5559]
===
match
---
name: mock_sequential_executor [5101,5125]
name: mock_sequential_executor [5093,5117]
===
match
---
comparison [2473,2520]
comparison [2473,2520]
===
match
---
funcdef [1390,1437]
funcdef [1390,1437]
===
match
---
trailer [5211,5256]
trailer [5203,5248]
===
match
---
name: side_effect [3906,3917]
name: side_effect [3906,3917]
===
match
---
simple_stmt [1735,1745]
simple_stmt [1735,1745]
===
match
---
trailer [2754,2766]
trailer [2754,2766]
===
match
---
trailer [3095,3102]
trailer [3095,3102]
===
match
---
trailer [3115,3125]
trailer [3115,3125]
===
match
---
atom_expr [3784,3832]
atom_expr [3784,3832]
===
match
---
name: add [5418,5421]
name: add [5410,5413]
===
match
---
expr_stmt [2182,2219]
expr_stmt [2182,2219]
===
match
---
trailer [3247,3254]
trailer [3247,3254]
===
match
---
trailer [1580,1588]
trailer [1580,1588]
===
match
---
name: self [3476,3480]
name: self [3476,3480]
===
match
---
operator: == [2514,2516]
operator: == [2514,2516]
===
match
---
assert_stmt [4882,4925]
assert_stmt [4874,4917]
===
match
---
name: super [1358,1363]
name: super [1358,1363]
===
match
---
name: job [2066,2069]
name: job [2066,2069]
===
match
---
param [1403,1407]
param [1403,1407]
===
match
---
name: sequential_executor [944,963]
name: sequential_executor [944,963]
===
match
---
with_stmt [2136,2553]
with_stmt [2136,2553]
===
match
---
param [4382,4403]
param [4374,4395]
===
match
---
name: test_state_sysexit [1638,1656]
name: test_state_sysexit [1638,1656]
===
match
---
trailer [5693,5717]
trailer [5685,5709]
===
match
---
operator: , [3810,3811]
operator: , [3810,3811]
===
match
---
argument [4680,4700]
argument [4672,4692]
===
match
---
trailer [5453,5455]
trailer [5445,5447]
===
match
---
atom_expr [5502,5524]
atom_expr [5494,5516]
===
match
---
trailer [3534,3536]
trailer [3534,3536]
===
match
---
name: return_value [3737,3749]
name: return_value [3737,3749]
===
match
---
operator: , [5329,5330]
operator: , [5321,5322]
===
match
---
simple_stmt [1418,1437]
simple_stmt [1418,1437]
===
match
---
number: 10 [3286,3288]
number: 10 [3286,3288]
===
match
---
dotted_name [1037,1050]
dotted_name [1037,1050]
===
match
---
assert_stmt [4983,5021]
assert_stmt [4975,5013]
===
match
---
assert_stmt [2059,2090]
assert_stmt [2059,2090]
===
match
---
simple_stmt [5469,5490]
simple_stmt [5461,5482]
===
match
---
atom_expr [3519,3536]
atom_expr [3519,3536]
===
match
---
name: is_alive [2665,2673]
name: is_alive [2665,2673]
===
match
---
name: OperationalError [3920,3936]
name: OperationalError [3920,3936]
===
match
---
operator: , [4664,4665]
operator: , [4656,4657]
===
match
---
name: func [1430,1434]
name: func [1430,1434]
===
match
---
name: test_state_failed [1837,1854]
name: test_state_failed [1837,1854]
===
match
---
name: raises [869,875]
name: raises [869,875]
===
match
---
operator: , [835,836]
operator: , [835,836]
===
match
---
param [3476,3481]
param [3476,3481]
===
match
---
number: 10 [2621,2623]
number: 10 [2621,2623]
===
match
---
atom_expr [5192,5256]
atom_expr [5184,5248]
===
match
---
name: session [3653,3660]
name: session [3653,3660]
===
match
---
assert_stmt [1754,1787]
assert_stmt [1754,1787]
===
match
---
name: executor_class [4747,4761]
name: executor_class [4739,4753]
===
match
---
arith_expr [3239,3289]
arith_expr [3239,3289]
===
match
---
trailer [4746,4761]
trailer [4738,4753]
===
match
---
trailer [5487,5489]
trailer [5479,5481]
===
match
---
name: when [4034,4038]
name: when [4034,4038]
===
match
---
expr_stmt [5502,5538]
expr_stmt [5494,5530]
===
match
---
name: session [5290,5297]
name: session [5282,5289]
===
match
---
name: job [3064,3067]
name: job [3064,3067]
===
match
---
atom_expr [2066,2078]
atom_expr [2066,2078]
===
match
---
name: OperationalError [903,919]
name: OperationalError [903,919]
===
match
---
trailer [5360,5377]
trailer [5352,5369]
===
match
---
operator: { [3951,3952]
operator: { [3951,3952]
===
match
---
atom_expr [5380,5397]
atom_expr [5372,5389]
===
match
---
atom_expr [2661,2675]
atom_expr [2661,2675]
===
match
---
operator: == [4857,4859]
operator: == [4849,4851]
===
match
---
trailer [3713,3726]
trailer [3713,3726]
===
match
---
comparison [3305,3328]
comparison [3305,3328]
===
match
---
trailer [2731,2733]
trailer [2731,2733]
===
match
---
name: job [1500,1503]
name: job [1500,1503]
===
match
---
name: mock_session [3624,3636]
name: mock_session [3624,3636]
===
match
---
simple_stmt [850,876]
simple_stmt [850,876]
===
match
---
operator: = [2620,2621]
operator: = [2620,2621]
===
match
---
trailer [1429,1434]
trailer [1429,1434]
===
match
---
atom_expr [1506,1527]
atom_expr [1506,1527]
===
match
---
funcdef [2096,2553]
funcdef [2096,2553]
===
match
---
simple_stmt [1333,1350]
simple_stmt [1333,1350]
===
match
---
atom_expr [1536,1545]
atom_expr [1536,1545]
===
match
---
atom_expr [1901,1921]
atom_expr [1901,1921]
===
match
---
name: heartbeat_callback [5506,5524]
name: heartbeat_callback [5498,5516]
===
match
---
simple_stmt [3624,3682]
simple_stmt [3624,3682]
===
match
---
argument [2611,2623]
argument [2611,2623]
===
match
---
comparison [4889,4925]
comparison [4881,4917]
===
match
---
atom_expr [3194,3207]
atom_expr [3194,3207]
===
match
---
argument [1375,1383]
argument [1375,1383]
===
match
---
operator: = [1935,1936]
operator: = [1935,1936]
===
match
---
atom_expr [5080,5097]
atom_expr [5072,5089]
===
match
---
operator: == [4762,4764]
operator: == [4754,4756]
===
match
---
name: MockJob [2192,2199]
name: MockJob [2192,2199]
===
match
---
operator: @ [4222,4223]
operator: @ [4222,4223]
===
match
---
simple_stmt [1154,1200]
simple_stmt [1154,1200]
===
match
---
name: state [2029,2034]
name: state [2029,2034]
===
match
---
trailer [1607,1616]
trailer [1607,1616]
===
match
---
name: conf_vars [1190,1199]
name: conf_vars [1190,1199]
===
match
---
comp_op [1617,1623]
comp_op [1617,1623]
===
match
---
string: "test_hostname" [4499,4514]
string: "test_hostname" [4491,4506]
===
match
---
name: timedelta [2866,2875]
name: timedelta [2866,2875]
===
match
---
simple_stmt [5311,5345]
simple_stmt [5303,5337]
===
match
---
atom_expr [3064,3084]
atom_expr [3064,3084]
===
match
---
name: executor [5089,5097]
name: executor [5081,5089]
===
match
---
trailer [2550,2552]
trailer [2550,2552]
===
match
---
name: return_value [4536,4548]
name: return_value [4528,4540]
===
match
---
trailer [5565,5567]
trailer [5557,5559]
===
match
---
name: test_is_alive [2562,2575]
name: test_is_alive [2562,2575]
===
match
---
name: hb_callback [5469,5480]
name: hb_callback [5461,5472]
===
match
---
argument [3278,3288]
argument [3278,3288]
===
match
---
trailer [5592,5616]
trailer [5584,5608]
===
match
---
name: self [1403,1407]
name: self [1403,1407]
===
match
---
argument [2206,2218]
argument [2206,2218]
===
match
---
trailer [1738,1742]
trailer [1738,1742]
===
match
---
simple_stmt [1536,1546]
simple_stmt [1536,1546]
===
match
---
operator: = [2595,2596]
operator: = [2595,2596]
===
match
---
atom_expr [2736,2766]
atom_expr [2736,2766]
===
match
---
name: job [2782,2785]
name: job [2782,2785]
===
match
---
name: datetime [2286,2294]
name: datetime [2286,2294]
===
match
---
atom_expr [2025,2034]
atom_expr [2025,2034]
===
match
---
expr_stmt [4570,4631]
expr_stmt [4562,4623]
===
match
---
name: self [1657,1661]
name: self [1657,1661]
===
match
---
atom_expr [5317,5344]
atom_expr [5309,5336]
===
match
---
name: Mock [837,841]
name: Mock [837,841]
===
match
---
name: latest_heartbeat [3849,3865]
name: latest_heartbeat [3849,3865]
===
match
---
name: run [1540,1543]
name: run [1540,1543]
===
match
---
name: RuntimeError [1972,1984]
name: RuntimeError [1972,1984]
===
match
---
funcdef [5131,5765]
funcdef [5123,5757]
===
match
---
name: MockJob [1506,1513]
name: MockJob [1506,1513]
===
match
---
operator: = [3750,3751]
operator: = [3750,3751]
===
match
---
name: latest_heartbeat [2818,2834]
name: latest_heartbeat [2818,2834]
===
match
---
number: 20 [2313,2315]
number: 20 [2313,2315]
===
match
---
simple_stmt [4882,4926]
simple_stmt [4874,4918]
===
match
---
name: datetime [3107,3115]
name: datetime [3107,3115]
===
match
---
name: TestBaseJob [1445,1456]
name: TestBaseJob [1445,1456]
===
match
---
name: utcnow [3528,3534]
name: utcnow [3528,3534]
===
match
---
operator: @ [3399,3400]
operator: @ [3399,3400]
===
match
---
operator: , [3660,3661]
operator: , [3660,3661]
===
match
---
operator: = [3192,3193]
operator: = [3192,3193]
===
match
---
funcdef [2558,3394]
funcdef [2558,3394]
===
match
---
trailer [3102,3104]
trailer [3102,3104]
===
match
---
name: MockJob [1937,1944]
name: MockJob [1937,1944]
===
match
---
import_name [1672,1682]
import_name [1672,1682]
===
match
---
operator: = [4650,4651]
operator: = [4642,4643]
===
match
---
argument [2876,2886]
argument [2876,2886]
===
match
---
simple_stmt [921,990]
simple_stmt [921,990]
===
match
---
simple_stmt [2654,2684]
simple_stmt [2654,2684]
===
match
---
name: state [5046,5051]
name: state [5038,5043]
===
match
---
name: mock [820,824]
name: mock [820,824]
===
match
---
trailer [3067,3084]
trailer [3067,3084]
===
match
---
trailer [2785,2794]
trailer [2785,2794]
===
match
---
lambdef [1514,1526]
lambdef [1514,1526]
===
match
---
atom_expr [2857,2887]
atom_expr [2857,2887]
===
match
---
import_from [1067,1115]
import_from [1067,1115]
===
match
---
trailer [1779,1787]
trailer [1779,1787]
===
match
---
name: pytest [855,861]
name: pytest [855,861]
===
match
---
file_input [790,5765]
file_input [790,5757]
===
match
---
name: MockJob [1698,1705]
name: MockJob [1698,1705]
===
match
---
name: heartbeat [5684,5693]
name: heartbeat [5676,5685]
===
match
---
dotted_name [926,963]
dotted_name [926,963]
===
match
---
name: patch [843,848]
name: patch [843,848]
===
match
---
suite [2127,2553]
suite [2127,2553]
===
match
---
simple_stmt [4731,4786]
simple_stmt [4723,4778]
===
match
---
simple_stmt [2466,2521]
simple_stmt [2466,2521]
===
match
---
trailer [2002,2006]
trailer [2002,2006]
===
match
---
name: when [3868,3872]
name: when [3868,3872]
===
match
---
name: latest_heartbeat [3068,3084]
name: latest_heartbeat [3068,3084]
===
match
---
trailer [3977,3987]
trailer [3977,3987]
===
match
---
name: timezone [3239,3247]
name: timezone [3239,3247]
===
match
---
string: "attribute not updated when heartbeat fails" [4040,4084]
string: "attribute not updated when heartbeat fails" [4040,4084]
===
match
---
assert_stmt [4794,4825]
assert_stmt [4786,4817]
===
match
---
name: self [1425,1429]
name: self [1425,1429]
===
match
---
atom_expr [3886,3917]
atom_expr [3886,3917]
===
match
---
import_from [1032,1066]
import_from [1032,1066]
===
match
---
trailer [3597,3599]
trailer [3597,3599]
===
match
---
simple_stmt [1895,1922]
simple_stmt [1895,1922]
===
match
---
name: commit [3899,3905]
name: commit [3899,3905]
===
match
---
name: test_state_success [1466,1484]
name: test_state_success [1466,1484]
===
match
---
name: utils [1129,1134]
name: utils [1129,1134]
===
match
---
operator: } [4143,4144]
operator: } [4143,4144]
===
match
---
name: is_alive [3309,3317]
name: is_alive [3309,3317]
===
match
---
name: BaseJob [1216,1223]
name: BaseJob [1216,1223]
===
match
---
trailer [1944,1951]
trailer [1944,1951]
===
match
---
name: end_date [2070,2078]
name: end_date [2070,2078]
===
match
---
name: is_alive [2786,2794]
name: is_alive [2786,2794]
===
match
---
atom_expr [1761,1770]
atom_expr [1761,1770]
===
match
---
operator: , [4365,4366]
operator: , [4357,4358]
===
match
---
name: Mock [5483,5487]
name: Mock [5475,5479]
===
match
---
trailer [2386,2391]
trailer [2386,2391]
===
match
---
simple_stmt [4523,4562]
simple_stmt [4515,4554]
===
match
---
atom_expr [5643,5667]
atom_expr [5635,5659]
===
match
---
name: create_session [1101,1115]
name: create_session [1101,1115]
===
match
---
name: hb_callback [5737,5748]
name: hb_callback [5729,5740]
===
match
---
operator: , [4114,4115]
operator: , [4114,4115]
===
match
---
arglist [5325,5343]
arglist [5317,5335]
===
match
---
name: return_value [4592,4604]
name: return_value [4584,4596]
===
match
---
trailer [2845,2852]
trailer [2845,2852]
===
match
---
name: heartrate [3798,3807]
name: heartrate [3798,3807]
===
match
---
name: test_job [5080,5088]
name: test_job [5072,5080]
===
match
---
simple_stmt [1672,1683]
simple_stmt [1672,1683]
===
match
---
operator: , [4678,4679]
operator: , [4670,4671]
===
match
---
operator: , [3328,3329]
operator: , [3328,3329]
===
match
---
operator: , [4380,4381]
operator: , [4372,4373]
===
match
---
trailer [5654,5665]
trailer [5646,5657]
===
match
---
suite [1491,1629]
suite [1491,1629]
===
match
---
parameters [1854,1860]
parameters [1854,1860]
===
match
---
expr_stmt [3512,3569]
expr_stmt [3512,3569]
===
match
---
operator: , [3796,3797]
operator: , [3796,3797]
===
match
---
operator: , [5168,5169]
operator: , [5160,5161]
===
match
---
name: test_most_recent_job [2100,2120]
name: test_most_recent_job [2100,2120]
===
match
---
name: timedelta [3268,3277]
name: timedelta [3268,3277]
===
match
---
simple_stmt [2534,2553]
simple_stmt [2534,2553]
===
match
---
number: 100 [4971,4974]
number: 100 [4963,4966]
===
match
---
simple_stmt [4003,4085]
simple_stmt [4003,4085]
===
match
---
suite [5183,5765]
suite [5175,5757]
===
match
---
trailer [3219,3236]
trailer [3219,3236]
===
match
---
number: 10 [5341,5343]
number: 10 [5333,5335]
===
match
---
name: session [5617,5624]
name: session [5609,5616]
===
match
---
operator: = [5340,5341]
operator: = [5332,5333]
===
match
---
expr_stmt [4414,4461]
expr_stmt [4406,4453]
===
match
---
operator: = [3817,3818]
operator: = [3817,3818]
===
match
---
string: "MockSession" [3667,3680]
string: "MockSession" [3667,3680]
===
match
---
operator: - [2855,2856]
operator: - [2855,2856]
===
match
---
simple_stmt [5073,5126]
simple_stmt [5065,5118]
===
match
---
param [4347,4352]
param [4339,4344]
===
match
---
string: 'airflow.jobs.base_job.ExecutorLoader.get_default_executor' [4157,4216]
string: 'airflow.jobs.base_job.ExecutorLoader.get_default_executor' [4157,4216]
===
match
---
name: rollback [2542,2550]
name: rollback [2542,2550]
===
match
---
operator: = [5525,5526]
operator: = [5517,5518]
===
match
---
name: mock_default_executor [4382,4403]
name: mock_default_executor [4374,4395]
===
match
---
expr_stmt [3064,3133]
expr_stmt [3064,3133]
===
match
---
simple_stmt [1500,1528]
simple_stmt [1500,1528]
===
match
---
with_stmt [3578,4085]
with_stmt [3578,4085]
===
match
---
param [3482,3501]
param [3482,3501]
===
match
---
name: airflow [1072,1079]
name: airflow [1072,1079]
===
match
---
operator: = [1246,1247]
operator: = [1246,1247]
===
match
---
number: 10 [3808,3810]
number: 10 [3808,3810]
===
match
---
trailer [3905,3917]
trailer [3905,3917]
===
match
---
arglist [3937,3959]
arglist [3937,3959]
===
match
---
name: when [3512,3516]
name: when [3512,3516]
===
match
---
param [1485,1489]
param [1485,1489]
===
match
---
name: flush [2445,2450]
name: flush [2445,2450]
===
match
---
expr_stmt [1931,1951]
expr_stmt [1931,1951]
===
match
---
name: mock_hostname [4367,4380]
name: mock_hostname [4359,4372]
===
match
---
simple_stmt [4414,4462]
simple_stmt [4406,4454]
===
match
---
name: utils [1045,1050]
name: utils [1045,1050]
===
match
---
trailer [2875,2887]
trailer [2875,2887]
===
match
---
name: only_if_necessary [5694,5711]
name: only_if_necessary [5686,5703]
===
match
---
name: self [2121,2125]
name: self [2121,2125]
===
match
---
parameters [4346,4404]
parameters [4338,4396]
===
match
---
assert_stmt [5730,5764]
assert_stmt [5722,5756]
===
match
---
operator: = [3782,3783]
operator: = [3782,3783]
===
match
---
atom_expr [5483,5489]
atom_expr [5475,5481]
===
match
---
operator: = [3285,3286]
operator: = [3285,3286]
===
match
---
trailer [5446,5453]
trailer [5438,5445]
===
match
---
name: State [3818,3823]
name: State [3818,3823]
===
match
---
argument [3126,3132]
argument [3126,3132]
===
match
---
param [5150,5155]
param [5142,5147]
===
match
---
name: seconds [3558,3565]
name: seconds [3558,3565]
===
match
---
operator: = [3085,3086]
operator: = [3085,3086]
===
match
---
decorators [4090,4319]
decorators [4090,4311]
===
match
---
operator: @ [4271,4272]
operator: @ [4271,4272]
===
match
---
parameters [1301,1323]
parameters [1301,1323]
===
match
---
name: patch [4151,4156]
name: patch [4151,4156]
===
match
---
operator: = [3637,3638]
operator: = [3637,3638]
===
match
---
trailer [4483,4496]
trailer [4475,4488]
===
match
---
name: datetime [797,805]
name: datetime [797,805]
===
match
---
trailer [2028,2034]
trailer [2028,2034]
===
match
---
trailer [2724,2731]
trailer [2724,2731]
===
match
---
atom_expr [2335,2362]
atom_expr [2335,2362]
===
match
---
atom_expr [5410,5426]
atom_expr [5402,5418]
===
match
---
atom_expr [3239,3256]
atom_expr [3239,3256]
===
match
---
comp_op [2079,2085]
comp_op [2079,2085]
===
match
---
name: old_job [2232,2239]
name: old_job [2232,2239]
===
match
---
trailer [5284,5286]
trailer [5276,5278]
===
match
---
string: "fail" [1914,1920]
string: "fail" [1914,1920]
===
match
---
classdef [1439,5765]
classdef [1439,5757]
===
match
---
string: "testuser" [4551,4561]
string: "testuser" [4543,4553]
===
match
---
simple_stmt [3778,3833]
simple_stmt [3778,3833]
===
match
---
name: mock_sequential_executor [4607,4631]
name: mock_sequential_executor [4599,4623]
===
match
---
trailer [2906,2915]
trailer [2906,2915]
===
match
---
atom_expr [4441,4461]
atom_expr [4433,4453]
===
match
---
import_from [921,989]
import_from [921,989]
===
match
---
trailer [3527,3534]
trailer [3527,3534]
===
match
---
param [2121,2125]
param [2121,2125]
===
match
---
atom_expr [5439,5455]
atom_expr [5431,5447]
===
match
---
trailer [4849,4856]
trailer [4841,4848]
===
match
---
simple_stmt [3512,3570]
simple_stmt [3512,3570]
===
match
---
operator: - [3537,3538]
operator: - [3537,3538]
===
match
---
name: __enter__ [3727,3736]
name: __enter__ [3727,3736]
===
match
---
param [1302,1307]
param [1302,1307]
===
match
---
comparison [5037,5064]
comparison [5029,5056]
===
match
---
trailer [3557,3569]
trailer [3557,3569]
===
match
---
trailer [2006,2008]
trailer [2006,2008]
===
match
---
name: self [1333,1337]
name: self [1333,1337]
===
match
---
comparison [1803,1827]
comparison [1803,1827]
===
match
---
comparison [2782,2804]
comparison [2782,2804]
===
match
---
simple_stmt [5730,5765]
simple_stmt [5722,5757]
===
match
---
trailer [2817,2834]
trailer [2817,2834]
===
match
---
trailer [3161,3163]
trailer [3161,3163]
===
match
---
comparison [4990,5021]
comparison [4982,5013]
===
match
---
number: 10 [2216,2218]
number: 10 [2216,2218]
===
match
---
trailer [2496,2513]
trailer [2496,2513]
===
match
---
name: job [3305,3308]
name: job [3305,3308]
===
match
---
operator: ** [1314,1316]
operator: ** [1314,1316]
===
match
---
name: utcnow [2846,2852]
name: utcnow [2846,2852]
===
match
---
trailer [3317,3319]
trailer [3317,3319]
===
match
---
string: 'polymorphic_identity' [1249,1271]
string: 'polymorphic_identity' [1249,1271]
===
match
---
simple_stmt [5502,5539]
simple_stmt [5494,5531]
===
match
---
comparison [3149,3172]
comparison [3149,3172]
===
match
---
decorator [4222,4267]
decorator [4222,4267]
===
match
---
operator: , [2623,2624]
operator: , [2623,2624]
===
match
---
string: '100' [4138,4143]
string: '100' [4138,4143]
===
match
---
name: session [2497,2504]
name: session [2497,2504]
===
match
---
trailer [5088,5097]
trailer [5080,5089]
===
match
---
atom_expr [2782,2796]
atom_expr [2782,2796]
===
match
---
simple_stmt [2404,2425]
simple_stmt [2404,2425]
===
match
---
name: SUCCESS [1780,1787]
name: SUCCESS [1780,1787]
===
match
---
name: state [1765,1770]
name: state [1765,1770]
===
match
---
suite [1225,1437]
suite [1225,1437]
===
match
---
trailer [1543,1545]
trailer [1543,1545]
===
match
---
atom_expr [5737,5755]
atom_expr [5729,5747]
===
match
---
raise_stmt [1895,1921]
raise_stmt [1895,1921]
===
match
---
trailer [3936,3960]
trailer [3936,3960]
===
match
---
atom_expr [3305,3319]
atom_expr [3305,3319]
===
match
---
name: job [5357,5360]
name: job [5349,5352]
===
match
---
atom_expr [2437,2452]
atom_expr [2437,2452]
===
match
---
name: monkeypatch [5170,5181]
name: monkeypatch [5162,5173]
===
match
---
expr_stmt [5469,5489]
expr_stmt [5461,5481]
===
match
---
trailer [1337,1342]
trailer [1337,1342]
===
match
---
name: tests [1159,1164]
name: tests [1159,1164]
===
match
---
atom_expr [3182,3191]
atom_expr [3182,3191]
===
match
---
simple_stmt [4834,4874]
simple_stmt [4826,4866]
===
match
---
name: job [3182,3185]
name: job [3182,3185]
===
match
---
name: job [3974,3977]
name: job [3974,3977]
===
match
---
argument [3812,3831]
argument [3812,3831]
===
match
---
comparison [4941,4974]
comparison [4933,4966]
===
match
---
atom_expr [2141,2157]
atom_expr [2141,2157]
===
match
---
funcdef [1870,1922]
funcdef [1870,1922]
===
match
---
atom_expr [1965,1985]
atom_expr [1965,1985]
===
match
---
operator: == [4968,4970]
operator: == [4960,4962]
===
match
---
trailer [4897,4906]
trailer [4889,4898]
===
match
---
name: SUCCESS [3200,3207]
name: SUCCESS [3200,3207]
===
match
---
name: ANY [5625,5628]
name: ANY [5617,5620]
===
match
---
name: patch [3400,3405]
name: patch [3400,3405]
===
match
---
simple_stmt [2329,2363]
simple_stmt [2329,2363]
===
match
---
simple_stmt [3845,3873]
simple_stmt [3845,3873]
===
match
---
param [1855,1859]
param [1855,1859]
===
match
---
trailer [5505,5524]
trailer [5497,5516]
===
match
---
name: sys [1714,1717]
name: sys [1714,1717]
===
match
---
name: BaseJob [1024,1031]
name: BaseJob [1024,1031]
===
match
---
name: spec_set [3644,3652]
name: spec_set [3644,3652]
===
match
---
name: test_job [4889,4897]
name: test_job [4881,4889]
===
match
---
name: utils [1080,1085]
name: utils [1080,1085]
===
match
---
atom_expr [3818,3831]
atom_expr [3818,3831]
===
match
---
name: called [5749,5755]
name: called [5741,5747]
===
match
---
trailer [3152,3161]
trailer [3152,3161]
===
match
---
number: 10 [4676,4678]
number: 10 [4668,4670]
===
update-node
---
string: 'airflow.jobs.base_job.getpass.getuser' [4278,4317]
replace 'airflow.jobs.base_job.getpass.getuser' by 'airflow.jobs.base_job.getuser'
