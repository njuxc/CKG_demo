===
match
---
atom_expr [8315,8358]
atom_expr [8405,8448]
===
match
---
suite [7548,7616]
suite [7638,7706]
===
match
---
atom_expr [10728,10756]
atom_expr [10810,10838]
===
match
---
name: kerberos_hostname_override [8450,8476]
name: kerberos_hostname_override [8540,8566]
===
match
---
name: bool [5201,5205]
name: bool [5291,5295]
===
match
---
comparison [8547,8584]
comparison [8637,8674]
===
match
---
name: kerberos_hostname_override [10560,10586]
name: kerberos_hostname_override [10642,10668]
===
match
---
name: cert_pem [7574,7582]
name: cert_pem [7664,7672]
===
match
---
operator: = [10024,10025]
operator: = [10106,10107]
===
match
---
name: self [9428,9432]
name: self [9518,9522]
===
match
---
name: self [9674,9678]
name: self [9756,9760]
===
match
---
name: self [5336,5340]
name: self [5426,5430]
===
match
---
name: Optional [4485,4493]
name: Optional [4575,4583]
===
match
---
trailer [5989,6008]
trailer [6079,6098]
===
match
---
name: self [6101,6105]
name: self [6191,6195]
===
match
---
trailer [9860,10819]
trailer [9942,10901]
===
match
---
atom_expr [6631,6647]
atom_expr [6721,6737]
===
match
---
simple_stmt [11105,11131]
simple_stmt [11187,11213]
===
match
---
operator: = [6182,6183]
operator: = [6272,6273]
===
match
---
operator: = [10658,10659]
operator: = [10740,10741]
===
match
---
param [5092,5135]
param [5182,5225]
===
match
---
suite [8424,8528]
suite [8514,8618]
===
match
---
operator: = [11027,11028]
operator: = [11109,11110]
===
match
---
name: airflow [914,921]
name: airflow [899,906]
===
match
---
trailer [6436,6448]
trailer [6526,6538]
===
match
---
name: keytab [10102,10108]
name: keytab [10184,10190]
===
match
---
expr_stmt [7688,7742]
expr_stmt [7778,7832]
===
match
---
operator: = [8164,8165]
operator: = [8254,8255]
===
match
---
trailer [9100,9139]
trailer [9190,9229]
===
match
---
name: str [8479,8482]
name: str [8569,8572]
===
match
---
name: self [7328,7332]
name: self [7418,7422]
===
match
---
trailer [6431,6449]
trailer [6521,6539]
===
match
---
simple_stmt [11143,11177]
simple_stmt [11225,11259]
===
match
---
trailer [11165,11176]
trailer [11247,11258]
===
match
---
name: remote_port [9724,9735]
name: remote_port [9806,9817]
===
match
---
atom_expr [6877,6907]
atom_expr [6967,6997]
===
match
---
name: kerberos_delegation [7984,8003]
name: kerberos_delegation [8074,8093]
===
match
---
atom_expr [9719,9735]
atom_expr [9801,9817]
===
match
---
name: self [10447,10451]
name: self [10529,10533]
===
match
---
name: log [6283,6286]
name: log [6373,6376]
===
match
---
argument [10430,10468]
argument [10512,10550]
===
match
---
operator: , [10408,10409]
operator: , [10490,10491]
===
match
---
expr_stmt [7217,7261]
expr_stmt [7307,7351]
===
match
---
expr_stmt [5482,5506]
expr_stmt [5572,5596]
===
match
---
operator: , [4379,4380]
operator: , [4469,4470]
===
match
---
operator: = [10155,10156]
operator: = [10237,10238]
===
match
---
simple_stmt [10922,10969]
simple_stmt [11004,11051]
===
match
---
name: remote_host [9433,9444]
name: remote_host [9523,9534]
===
match
---
comparison [7520,7547]
comparison [7610,7637]
===
match
---
name: winrm_protocol [10941,10955]
name: winrm_protocol [11023,11037]
===
match
---
atom_expr [9522,9539]
atom_expr [9612,9621]
===
match
---
name: service [4666,4673]
name: service [4756,4763]
===
match
---
name: info [10842,10846]
name: info [10924,10928]
===
match
---
name: lower [8048,8053]
name: lower [8138,8143]
===
match
---
atom_expr [6718,6728]
atom_expr [6808,6818]
===
match
---
name: self [10892,10896]
name: self [10974,10978]
===
match
---
trailer [8482,8527]
trailer [8572,8617]
===
match
---
file_input [789,11205]
file_input [789,11287]
===
match
---
argument [9926,9950]
argument [10008,10032]
===
match
---
name: Protocol [9852,9860]
name: Protocol [9934,9942]
===
match
---
atom_expr [7708,7742]
atom_expr [7798,7832]
===
match
---
string: 'true' [8059,8065]
string: 'true' [8149,8155]
===
match
---
name: username [5465,5473]
name: username [5555,5563]
===
match
---
name: extra_options [8571,8584]
name: extra_options [8661,8674]
===
match
---
simple_stmt [7979,8066]
simple_stmt [8069,8156]
===
match
---
trailer [9804,9810]
trailer [9886,9892]
===
match
---
name: credssp_disable_tlsv1_2 [10733,10756]
name: credssp_disable_tlsv1_2 [10815,10838]
===
match
---
name: int [6998,7001]
name: int [7088,7091]
===
match
---
expr_stmt [6586,6615]
expr_stmt [6676,6705]
===
match
---
simple_stmt [8967,9032]
simple_stmt [9057,9122]
===
match
---
name: service [5520,5527]
name: service [5610,5617]
===
match
---
expr_stmt [11017,11092]
expr_stmt [11099,11174]
===
match
---
name: ssh_conn_id [6368,6379]
name: ssh_conn_id [6458,6469]
===
match
---
operator: = [9688,9689]
operator: = [9770,9771]
===
match
---
name: extra_options [7293,7306]
name: extra_options [7383,7396]
===
match
---
operator: = [4499,4500]
operator: = [4589,4590]
===
match
---
atom_expr [5062,5075]
atom_expr [5152,5165]
===
match
---
name: debug [6287,6292]
name: debug [6377,6382]
===
match
---
simple_stmt [6586,6616]
simple_stmt [6676,6706]
===
match
---
string: "service" [7250,7259]
string: "service" [7340,7349]
===
match
---
if_stmt [6715,9032]
if_stmt [6805,9122]
===
match
---
name: read_timeout_sec [5813,5829]
name: read_timeout_sec [5903,5919]
===
match
---
comparison [6812,6839]
comparison [6902,6929]
===
match
---
operator: = [5353,5354]
operator: = [5443,5444]
===
match
---
atom_expr [10156,10174]
atom_expr [10238,10256]
===
match
---
operator: , [4725,4726]
operator: , [4815,4816]
===
match
---
name: AirflowException [11149,11165]
name: AirflowException [11231,11247]
===
match
---
suite [6656,6702]
suite [6746,6792]
===
match
---
operator: = [5174,5175]
operator: = [5264,5265]
===
match
---
name: self [5449,5453]
name: self [5539,5543]
===
match
---
atom_expr [6521,6531]
atom_expr [6611,6621]
===
match
---
expr_stmt [5264,5294]
expr_stmt [5354,5384]
===
match
---
name: self [6631,6635]
name: self [6721,6725]
===
match
---
argument [10560,10618]
argument [10642,10700]
===
match
---
name: extra_options [8721,8734]
name: extra_options [8811,8824]
===
match
---
operator: = [4610,4611]
operator: = [4700,4701]
===
match
---
string: 'plaintext' [4565,4576]
string: 'plaintext' [4655,4666]
===
match
---
trailer [5340,5352]
trailer [5430,5442]
===
match
---
string: 'HTTP' [4681,4687]
string: 'HTTP' [4771,4777]
===
match
---
name: credssp_disable_tlsv1_2 [6069,6092]
name: credssp_disable_tlsv1_2 [6159,6182]
===
match
---
comparison [7762,7803]
comparison [7852,7893]
===
match
---
atom_expr [10109,10120]
atom_expr [10191,10202]
===
match
---
comparison [6547,6568]
comparison [6637,6658]
===
match
---
trailer [7829,7852]
trailer [7919,7942]
===
match
---
trailer [10160,10174]
trailer [10242,10256]
===
match
---
return_stmt [6250,6268]
return_stmt [6340,6358]
===
match
---
number: 5985 [4534,4538]
number: 5985 [4624,4628]
===
match
---
string: "kerberos_delegation" [8024,8045]
string: "kerberos_delegation" [8114,8135]
===
match
---
simple_stmt [5857,5908]
simple_stmt [5947,5998]
===
match
---
expr_stmt [5916,5976]
expr_stmt [6006,6066]
===
match
---
operator: = [5594,5595]
operator: = [5684,5685]
===
match
---
name: keytab [10114,10120]
name: keytab [10196,10202]
===
match
---
name: log [10838,10841]
name: log [10920,10923]
===
match
---
name: extra_options [8483,8496]
name: extra_options [8573,8586]
===
match
---
name: int [8315,8318]
name: int [8405,8408]
===
match
---
trailer [8760,8784]
trailer [8850,8874]
===
match
---
name: service [10060,10067]
name: service [10142,10149]
===
match
---
name: extra_options [6881,6894]
name: extra_options [6971,6984]
===
match
---
suite [11004,11177]
suite [11086,11259]
===
match
---
name: server_cert_validation [7830,7852]
name: server_cert_validation [7920,7942]
===
match
---
trailer [5757,5777]
trailer [5847,5867]
===
match
---
name: lower [8859,8864]
name: lower [8949,8954]
===
match
---
fstring_string: http:// [9692,9699]
fstring_string: http:// [9774,9781]
===
match
---
name: remote_host [4472,4483]
name: remote_host [4562,4573]
===
match
---
trailer [7345,7370]
trailer [7435,7460]
===
match
---
simple_stmt [7825,7900]
simple_stmt [7915,7990]
===
match
---
atom_expr [8813,8866]
atom_expr [8903,8956]
===
match
---
argument [10016,10038]
argument [10098,10120]
===
match
---
atom_expr [9236,9493]
atom_expr [9326,9583]
===
match
---
operator: = [6147,6148]
operator: = [6237,6238]
===
match
---
string: "cert_pem" [7520,7530]
string: "cert_pem" [7610,7620]
===
match
---
name: extra_options [7589,7602]
name: extra_options [7679,7692]
===
match
---
atom_expr [7688,7705]
atom_expr [7778,7795]
===
match
---
name: winrm_protocol [6167,6181]
name: winrm_protocol [6257,6271]
===
match
---
argument [10142,10174]
argument [10224,10256]
===
match
---
operator: , [4854,4855]
operator: , [4944,4945]
===
match
---
name: username [5454,5462]
name: username [5544,5552]
===
match
---
simple_stmt [7569,7616]
simple_stmt [7659,7706]
===
match
---
not_test [9205,9222]
not_test [9295,9312]
===
match
---
name: self [5985,5989]
name: self [6075,6079]
===
match
---
name: self [5414,5418]
name: self [5504,5508]
===
match
---
name: self [7979,7983]
name: self [8069,8073]
===
match
---
atom_expr [7346,7369]
atom_expr [7436,7459]
===
match
---
name: client [6230,6236]
name: client [6320,6326]
===
match
---
trailer [5920,5947]
trailer [6010,6037]
===
match
---
trailer [10072,10080]
trailer [10154,10162]
===
match
---
param [4375,4380]
param [4465,4470]
===
match
---
string: "operation_timeout_sec" [8333,8356]
string: "operation_timeout_sec" [8423,8446]
===
match
---
name: transport [9941,9950]
name: transport [10023,10032]
===
match
---
atom_expr [6774,6791]
atom_expr [6864,6881]
===
match
---
name: exceptions [922,932]
name: exceptions [907,917]
===
match
---
trailer [8864,8866]
trailer [8954,8956]
===
match
---
if_stmt [6924,7032]
if_stmt [7014,7122]
===
match
---
simple_stmt [5336,5367]
simple_stmt [5426,5457]
===
match
---
atom_expr [8006,8055]
atom_expr [8096,8145]
===
match
---
comparison [8983,9031]
comparison [9073,9121]
===
match
---
name: BaseHook [988,996]
name: BaseHook [973,981]
===
match
---
name: cert_key_pem [10258,10270]
name: cert_key_pem [10340,10352]
===
match
---
name: credssp_disable_tlsv1_2 [10704,10727]
name: credssp_disable_tlsv1_2 [10786,10809]
===
match
---
atom_expr [6334,6350]
atom_expr [6424,6440]
===
match
---
operator: , [4422,4423]
operator: , [4512,4513]
===
match
---
tfpdef [4993,5019]
tfpdef [5083,5109]
===
match
---
param [4914,4948]
param [5004,5038]
===
match
---
trailer [4798,4803]
trailer [4888,4893]
===
match
---
fstring_expr [11057,11075]
fstring_expr [11139,11157]
===
match
---
name: service [7222,7229]
name: service [7312,7319]
===
match
---
atom_expr [6135,6146]
atom_expr [6225,6236]
===
match
---
operator: , [4656,4657]
operator: , [4746,4747]
===
match
---
trailer [5379,5391]
trailer [5469,5481]
===
match
---
name: winrm_protocol [9835,9849]
name: winrm_protocol [9917,9931]
===
match
---
name: operation_timeout_sec [5862,5883]
name: operation_timeout_sec [5952,5973]
===
match
---
name: Optional [862,870]
name: Optional [847,855]
===
match
---
trailer [6677,6689]
trailer [6767,6779]
===
match
---
number: 20 [5022,5024]
number: 20 [5112,5114]
===
match
---
trailer [7135,7148]
trailer [7225,7238]
===
match
---
string: "server_cert_validation" [7762,7786]
string: "server_cert_validation" [7852,7876]
===
match
---
string: "username to WinRM to host: %s is not specified for connection id" [9268,9334]
string: "username to WinRM to host: %s is not specified for connection id" [9358,9424]
===
match
---
if_stmt [6222,6269]
if_stmt [6312,6359]
===
match
---
atom_expr [9936,9950]
atom_expr [10018,10032]
===
match
---
name: get_connection [6417,6431]
name: get_connection [6507,6521]
===
match
---
name: str [7465,7468]
name: str [7555,7558]
===
match
---
tfpdef [4780,4803]
tfpdef [4870,4893]
===
match
---
trailer [7448,7462]
trailer [7538,7552]
===
match
---
name: extra_options [7469,7482]
name: extra_options [7559,7572]
===
match
---
atom_expr [4596,4609]
atom_expr [4686,4699]
===
match
---
suite [7307,7371]
suite [7397,7461]
===
match
---
string: "cert_pem" [7603,7613]
string: "cert_pem" [7693,7703]
===
match
---
name: self [9700,9704]
name: self [9782,9786]
===
match
---
atom_expr [4636,4649]
atom_expr [4726,4739]
===
match
---
trailer [10896,10908]
trailer [10978,10990]
===
match
---
operator: = [6410,6411]
operator: = [6500,6501]
===
match
---
name: hooks [970,975]
name: hooks [955,960]
===
match
---
trailer [7573,7582]
trailer [7663,7672]
===
match
---
operator: = [5020,5021]
operator: = [5110,5111]
===
match
---
name: self [5575,5579]
name: self [5665,5669]
===
match
---
name: cert_key_pem [5671,5683]
name: cert_key_pem [5761,5773]
===
match
---
tfpdef [4515,4531]
tfpdef [4605,4621]
===
match
---
suite [8735,8899]
suite [8825,8989]
===
match
---
simple_stmt [7444,7501]
simple_stmt [7534,7591]
===
match
---
atom_expr [8166,8204]
atom_expr [8256,8294]
===
match
---
raise_stmt [11143,11176]
raise_stmt [11225,11258]
===
match
---
name: self [6334,6338]
name: self [6424,6428]
===
match
---
atom_expr [6412,6449]
atom_expr [6502,6539]
===
match
---
trailer [8610,8629]
trailer [8700,8719]
===
match
---
atom_expr [4402,4415]
atom_expr [4492,4505]
===
match
---
atom_expr [7589,7614]
atom_expr [7679,7704]
===
match
---
operator: = [6009,6010]
operator: = [6099,6100]
===
match
---
dotted_name [914,932]
dotted_name [899,917]
===
match
---
expr_stmt [5575,5609]
expr_stmt [5665,5699]
===
match
---
trailer [9810,9812]
trailer [9892,9894]
===
match
---
name: remote_host [9053,9064]
name: remote_host [9143,9154]
===
match
---
name: operation_timeout_sec [5886,5907]
name: operation_timeout_sec [5976,5997]
===
match
---
operator: , [5024,5025]
operator: , [5114,5115]
===
match
---
operator: , [10342,10343]
operator: , [10424,10425]
===
match
---
simple_stmt [5916,5977]
simple_stmt [6006,6067]
===
match
---
trailer [10926,10933]
trailer [11008,11015]
===
match
---
string: "service" [7169,7178]
string: "service" [7259,7268]
===
match
---
trailer [6292,6351]
trailer [6382,6441]
===
match
---
operator: = [10108,10109]
operator: = [10190,10191]
===
match
---
trailer [7105,7115]
trailer [7195,7205]
===
match
---
name: str [4843,4846]
name: str [4933,4936]
===
match
---
trailer [8169,8204]
trailer [8259,8294]
===
match
---
if_stmt [8544,8673]
if_stmt [8634,8763]
===
match
---
return_stmt [11186,11204]
return_stmt [11268,11286]
===
match
---
suite [8265,8359]
suite [8355,8449]
===
match
---
name: extra_options [7066,7079]
name: extra_options [7156,7169]
===
match
---
name: str [4675,4678]
name: str [4765,4768]
===
match
---
trailer [7983,8003]
trailer [8073,8093]
===
match
---
name: str [5071,5074]
name: str [5161,5164]
===
match
---
trailer [8290,8312]
trailer [8380,8402]
===
match
---
name: self [7569,7573]
name: self [7659,7663]
===
match
---
trailer [9704,9716]
trailer [9786,9798]
===
match
---
fstring_expr [9718,9736]
fstring_expr [9800,9818]
===
match
---
trailer [8023,8046]
trailer [8113,8136]
===
match
---
name: read_timeout_sec [8147,8163]
name: read_timeout_sec [8237,8253]
===
match
---
trailer [5418,5428]
trailer [5508,5518]
===
match
---
atom_expr [11149,11176]
atom_expr [11231,11258]
===
match
---
param [4864,4905]
param [4954,4995]
===
match
---
operator: == [8867,8869]
operator: == [8957,8959]
===
match
---
atom_expr [6257,6268]
atom_expr [6347,6358]
===
match
---
name: operation_timeout_sec [4993,5014]
name: operation_timeout_sec [5083,5104]
===
match
---
operator: = [5076,5077]
operator: = [5166,5167]
===
match
---
atom_expr [10659,10682]
atom_expr [10741,10764]
===
match
---
name: Optional [5112,5120]
name: Optional [5202,5210]
===
match
---
name: self [10109,10113]
name: self [10191,10195]
===
match
---
try_stmt [9753,11177]
try_stmt [9835,11259]
===
match
---
name: str [4559,4562]
name: str [4649,4652]
===
match
---
name: str [4759,4762]
name: str [4849,4852]
===
match
---
atom_expr [10922,10933]
atom_expr [11004,11015]
===
match
---
atom_expr [10936,10968]
atom_expr [11018,11050]
===
match
---
trailer [7001,7031]
trailer [7091,7121]
===
match
---
name: self [9830,9834]
name: self [9912,9916]
===
match
---
expr_stmt [5692,5744]
expr_stmt [5782,5834]
===
match
---
trailer [5812,5829]
trailer [5902,5919]
===
match
---
tfpdef [5144,5173]
tfpdef [5234,5263]
===
match
---
suite [7804,7900]
suite [7894,7990]
===
match
---
if_stmt [7916,8066]
if_stmt [8006,8156]
===
match
---
string: 'validate' [4894,4904]
string: 'validate' [4984,4994]
===
match
---
atom_expr [6979,6995]
atom_expr [7069,7085]
===
match
---
name: extra_options [8319,8332]
name: extra_options [8409,8422]
===
match
---
atom [8787,8898]
atom [8877,8988]
===
match
---
atom_expr [8142,8163]
atom_expr [8232,8253]
===
match
---
string: "keytab" [7281,7289]
string: "keytab" [7371,7379]
===
match
---
operator: = [4416,4417]
operator: = [4506,4507]
===
match
---
operator: = [5463,5464]
operator: = [5553,5554]
===
match
---
expr_stmt [6405,6449]
expr_stmt [6495,6539]
===
match
---
name: keytab [5560,5566]
name: keytab [5650,5656]
===
match
---
simple_stmt [6101,6126]
simple_stmt [6191,6216]
===
match
---
trailer [6880,6907]
trailer [6970,6997]
===
match
---
if_stmt [8375,8528]
if_stmt [8465,8618]
===
match
---
name: remote_host [9705,9716]
name: remote_host [9787,9798]
===
match
---
trailer [6590,6599]
trailer [6680,6689]
===
match
---
trailer [8830,8857]
trailer [8920,8947]
===
match
---
comp_op [6380,6386]
comp_op [6470,6476]
===
match
---
operator: = [6115,6116]
operator: = [6205,6206]
===
match
---
argument [10490,10538]
argument [10572,10620]
===
match
---
name: host [6697,6701]
name: host [6787,6791]
===
match
---
operator: = [4719,4720]
operator: = [4809,4810]
===
match
---
param [4586,4617]
param [4676,4707]
===
match
---
trailer [11109,11113]
trailer [11191,11195]
===
match
---
string: "kerberos_hostname_override" [8378,8406]
string: "kerberos_hostname_override" [8468,8496]
===
match
---
atom_expr [8445,8476]
atom_expr [8535,8566]
===
match
---
atom_expr [8170,8203]
atom_expr [8260,8293]
===
match
---
name: send_cbt [6106,6114]
name: send_cbt [6196,6204]
===
match
---
name: self [6547,6551]
name: self [6637,6641]
===
match
---
trailer [8635,8672]
trailer [8725,8762]
===
match
---
if_stmt [9041,9140]
if_stmt [9131,9230]
===
match
---
name: ssh_conn_id [6437,6448]
name: ssh_conn_id [6527,6538]
===
match
---
trailer [7221,7229]
trailer [7311,7319]
===
match
---
name: Optional [5062,5070]
name: Optional [5152,5160]
===
match
---
atom_expr [7217,7229]
atom_expr [7307,7319]
===
match
---
trailer [10257,10270]
trailer [10339,10352]
===
match
---
name: self [10659,10663]
name: self [10741,10745]
===
match
---
atom_expr [9830,9849]
atom_expr [9912,9931]
===
match
---
atom_expr [9700,9716]
atom_expr [9782,9798]
===
match
---
string: "remote_port" [7016,7029]
string: "remote_port" [7106,7119]
===
match
---
operator: = [4650,4651]
operator: = [4740,4741]
===
match
---
atom_expr [9209,9222]
atom_expr [9299,9312]
===
match
---
name: self [10025,10029]
name: self [10107,10111]
===
match
---
name: str [7855,7858]
name: str [7945,7948]
===
match
---
if_stmt [9770,10820]
if_stmt [9852,10902]
===
match
---
name: self [8606,8610]
name: self [8696,8700]
===
match
---
name: AirflowException [940,956]
name: AirflowException [925,941]
===
match
---
name: error_msg [11017,11026]
name: error_msg [11099,11108]
===
match
---
string: "ca_trust_path" [7483,7498]
string: "ca_trust_path" [7573,7588]
===
match
---
name: Optional [4596,4604]
name: Optional [4686,4694]
===
match
---
operator: = [5558,5559]
operator: = [5648,5649]
===
match
---
argument [10704,10756]
argument [10786,10838]
===
match
---
if_stmt [9640,9744]
if_stmt [9722,9826]
===
match
---
atom_expr [5112,5125]
atom_expr [5202,5215]
===
match
---
operator: , [6332,6333]
operator: , [6422,6423]
===
match
---
name: operation_timeout_sec [10490,10511]
name: operation_timeout_sec [10572,10593]
===
match
---
operator: , [4983,4984]
operator: , [5073,5074]
===
match
---
expr_stmt [8286,8358]
expr_stmt [8376,8448]
===
match
---
name: str [4494,4497]
name: str [4584,4587]
===
match
---
atom_expr [7569,7582]
atom_expr [7659,7672]
===
match
---
name: extra_options [7182,7195]
name: extra_options [7272,7285]
===
match
---
expr_stmt [8142,8204]
expr_stmt [8232,8294]
===
match
---
operator: = [5830,5831]
operator: = [5920,5921]
===
match
---
if_stmt [8082,8205]
if_stmt [8172,8295]
===
match
---
name: self [6673,6677]
name: self [6763,6767]
===
match
---
name: log [11110,11113]
name: log [11192,11195]
===
match
---
trailer [5453,5462]
trailer [5543,5552]
===
match
---
operator: = [7853,7854]
operator: = [7943,7944]
===
match
---
atom_expr [5808,5829]
atom_expr [5898,5919]
===
match
---
atom_expr [7002,7030]
atom_expr [7092,7120]
===
match
---
arglist [9268,9479]
arglist [9358,9569]
===
match
---
comparison [8006,8065]
comparison [8096,8155]
===
match
---
name: str [4605,4608]
name: str [4695,4698]
===
match
---
string: "transport" [7051,7062]
string: "transport" [7141,7152]
===
match
---
atom_expr [7101,7115]
atom_expr [7191,7205]
===
match
---
operator: , [10800,10801]
operator: , [10882,10883]
===
match
---
trailer [10846,10909]
trailer [10928,10991]
===
match
---
comp_op [6729,6735]
comp_op [6819,6825]
===
match
---
comparison [8692,8734]
comparison [8782,8824]
===
match
---
tfpdef [4586,4609]
tfpdef [4676,4699]
===
match
---
trailer [11113,11119]
trailer [11195,11201]
===
match
---
simple_stmt [9506,9540]
simple_stmt [9596,9622]
===
match
---
atom_expr [9891,9904]
atom_expr [9973,9986]
===
match
---
atom_expr [10384,10408]
atom_expr [10466,10490]
===
match
---
operator: , [10890,10891]
operator: , [10972,10973]
===
match
---
name: winrm [877,882]
name: winrm [862,867]
===
match
---
name: username [9972,9980]
name: username [10054,10062]
===
match
---
trailer [8332,8357]
trailer [8422,8447]
===
match
---
trailer [11062,11074]
trailer [11144,11156]
===
match
---
name: kerberos_delegation [4914,4933]
name: kerberos_delegation [5004,5023]
===
match
---
suite [9757,10969]
suite [9839,11051]
===
match
---
atom_expr [6225,6236]
atom_expr [6315,6326]
===
match
---
operator: = [5281,5282]
operator: = [5371,5372]
===
match
---
name: read_timeout_sec [10430,10446]
name: read_timeout_sec [10512,10528]
===
match
---
name: str [5121,5124]
name: str [5211,5214]
===
match
---
atom_expr [8319,8357]
atom_expr [8409,8447]
===
match
---
simple_stmt [5414,5441]
simple_stmt [5504,5531]
===
match
---
operator: = [10934,10935]
operator: = [11016,11017]
===
match
---
tfpdef [4914,4939]
tfpdef [5004,5029]
===
match
---
name: conn [6602,6606]
name: conn [6692,6696]
===
match
---
name: username [9511,9519]
name: username [9601,9609]
===
match
---
operator: , [4947,4948]
operator: , [5037,5038]
===
match
---
simple_stmt [6861,6908]
simple_stmt [6951,6998]
===
match
---
operator: = [7583,7584]
operator: = [7673,7674]
===
match
---
name: ca_trust_path [10142,10155]
name: ca_trust_path [10224,10237]
===
match
---
trailer [10516,10538]
trailer [10598,10620]
===
match
---
trailer [8053,8055]
trailer [8143,8145]
===
match
---
trailer [10209,10218]
trailer [10291,10300]
===
match
---
name: self [11058,11062]
name: self [11140,11144]
===
match
---
trailer [9432,9444]
trailer [9522,9534]
===
match
---
name: self [10315,10319]
name: self [10397,10401]
===
match
---
atom_expr [5753,5777]
atom_expr [5843,5867]
===
match
---
atom_expr [5264,5280]
atom_expr [5354,5370]
===
match
---
atom_expr [6547,6560]
atom_expr [6637,6650]
===
match
---
name: self [10728,10732]
name: self [10810,10814]
===
match
---
suite [9661,9744]
suite [9743,9826]
===
match
---
atom_expr [7469,7499]
atom_expr [7559,7589]
===
match
---
operator: = [6875,6876]
operator: = [6965,6966]
===
match
---
if_stmt [7517,7616]
if_stmt [7607,7706]
===
match
---
except_clause [10978,11003]
except_clause [11060,11085]
===
match
---
suite [6488,6532]
suite [6578,6622]
===
match
---
atom_expr [7122,7148]
atom_expr [7212,7238]
===
match
---
suite [7196,7262]
suite [7286,7352]
===
match
---
name: extra_options [7712,7725]
name: extra_options [7802,7815]
===
match
---
name: extra_options [8107,8120]
name: extra_options [8197,8210]
===
match
---
operator: , [5134,5135]
operator: , [5224,5225]
===
match
---
name: extra_options [6944,6957]
name: extra_options [7034,7047]
===
match
---
expr_stmt [5985,6029]
expr_stmt [6075,6119]
===
match
---
name: transport [9926,9935]
name: transport [10008,10017]
===
match
---
comparison [6927,6957]
comparison [7017,7047]
===
match
---
name: client [6262,6268]
name: client [6352,6358]
===
match
---
name: keytab [7333,7339]
name: keytab [7423,7429]
===
match
---
atom_expr [8817,8857]
atom_expr [8907,8947]
===
match
---
name: str [7118,7121]
name: str [7208,7211]
===
match
---
trailer [6778,6791]
trailer [6868,6881]
===
match
---
expr_stmt [5808,5848]
expr_stmt [5898,5938]
===
match
---
atom_expr [6162,6181]
atom_expr [6252,6271]
===
match
---
operator: = [4563,4564]
operator: = [4653,4654]
===
match
---
if_stmt [8689,8899]
if_stmt [8779,8989]
===
match
---
name: str [4451,4454]
name: str [4541,4544]
===
match
---
name: error_msg [11120,11129]
name: error_msg [11202,11211]
===
match
---
name: int [4975,4978]
name: int [5065,5068]
===
match
---
atom_expr [5692,5719]
atom_expr [5782,5809]
===
match
---
name: str [7342,7345]
name: str [7432,7435]
===
match
---
operator: = [7706,7707]
operator: = [7796,7797]
===
match
---
atom_expr [4834,4847]
atom_expr [4924,4937]
===
match
---
simple_stmt [6673,6702]
simple_stmt [6763,6792]
===
match
---
operator: , [4687,4688]
operator: , [4777,4778]
===
match
---
name: extra_options [6826,6839]
name: extra_options [6916,6929]
===
match
---
atom_expr [10315,10342]
atom_expr [10397,10424]
===
match
---
simple_stmt [8445,8528]
simple_stmt [8535,8618]
===
match
---
operator: = [10511,10512]
operator: = [10593,10594]
===
match
---
trailer [10663,10682]
trailer [10745,10764]
===
match
---
suite [7958,8066]
suite [8048,8156]
===
match
---
name: password [10030,10038]
name: password [10112,10120]
===
match
---
trailer [5550,5557]
trailer [5640,5647]
===
match
---
name: cert_pem [4780,4788]
name: cert_pem [4870,4878]
===
match
---
tfpdef [4864,4891]
tfpdef [4954,4981]
===
match
---
atom_expr [11193,11204]
atom_expr [11275,11286]
===
match
---
name: self [6432,6436]
name: self [6522,6526]
===
match
---
string: "remote_port" [6927,6940]
string: "remote_port" [7017,7030]
===
match
---
operator: = [8313,8314]
operator: = [8403,8404]
===
match
---
operator: , [10080,10081]
operator: , [10162,10163]
===
match
---
name: cert_pem [5623,5631]
name: cert_pem [5713,5721]
===
match
---
trailer [5622,5631]
trailer [5712,5721]
===
match
---
atom_expr [11058,11074]
atom_expr [11140,11156]
===
match
---
name: self [10936,10940]
name: self [11018,11022]
===
match
---
string: "kerberos_delegation" [7919,7940]
string: "kerberos_delegation" [8009,8030]
===
match
---
name: extra_options [7002,7015]
name: extra_options [7092,7105]
===
match
---
trailer [9510,9519]
trailer [9600,9609]
===
match
---
comparison [6363,6391]
comparison [6453,6481]
===
match
---
name: self [6225,6229]
name: self [6315,6319]
===
match
---
comparison [7051,7079]
comparison [7141,7169]
===
match
---
trailer [7711,7742]
trailer [7801,7832]
===
match
---
operator: , [10218,10219]
operator: , [10300,10301]
===
match
---
name: self [11193,11197]
name: self [11275,11279]
===
match
---
name: client [6140,6146]
name: client [6230,6236]
===
match
---
atom_expr [8987,9012]
atom_expr [9077,9102]
===
match
---
trailer [9213,9222]
trailer [9303,9312]
===
match
---
operator: , [9994,9995]
operator: , [10076,10077]
===
match
---
name: str [8632,8635]
name: str [8722,8725]
===
match
---
simple_stmt [8142,8205]
simple_stmt [8232,8295]
===
match
---
name: self [6363,6367]
name: self [6453,6457]
===
match
---
name: str [4411,4414]
name: str [4501,4504]
===
match
---
name: kerberos_hostname_override [10592,10618]
name: kerberos_hostname_override [10674,10700]
===
match
---
name: client [11198,11204]
name: client [11280,11286]
===
match
---
name: extra_options [7409,7422]
name: extra_options [7499,7512]
===
match
---
tfpdef [4957,4978]
tfpdef [5047,5068]
===
match
---
trailer [4758,4763]
trailer [4848,4853]
===
match
---
name: conn [6774,6778]
name: conn [6864,6868]
===
match
---
expr_stmt [8967,9031]
expr_stmt [9057,9121]
===
match
---
operator: = [5496,5497]
operator: = [5586,5587]
===
match
---
trailer [7249,7260]
trailer [7339,7350]
===
match
---
simple_stmt [5375,5406]
simple_stmt [5465,5496]
===
match
---
tfpdef [5092,5125]
tfpdef [5182,5215]
===
match
---
name: endpoint [9882,9890]
name: endpoint [9964,9972]
===
match
---
operator: = [10252,10253]
operator: = [10334,10335]
===
match
---
atom_expr [10512,10538]
atom_expr [10594,10620]
===
match
---
name: server_cert_validation [5697,5719]
name: server_cert_validation [5787,5809]
===
match
---
expr_stmt [7328,7370]
expr_stmt [7418,7460]
===
match
---
name: cert_key_pem [7693,7705]
name: cert_key_pem [7783,7795]
===
match
---
trailer [5307,5316]
trailer [5397,5406]
===
match
---
string: "endpoint" [6812,6822]
string: "endpoint" [6902,6912]
===
match
---
name: self [5482,5486]
name: self [5572,5576]
===
match
---
fstring [11029,11092]
fstring [11111,11174]
===
match
---
trailer [8009,8047]
trailer [8099,8137]
===
match
---
simple_stmt [5303,5328]
simple_stmt [5393,5418]
===
match
---
import_from [957,996]
import_from [942,981]
===
match
---
name: server_cert_validation [10292,10314]
name: server_cert_validation [10374,10396]
===
match
---
atom_expr [7342,7370]
atom_expr [7432,7460]
===
match
---
name: self [5303,5307]
name: self [5393,5397]
===
match
---
expr_stmt [5618,5642]
expr_stmt [5708,5732]
===
match
---
name: protocol [883,891]
name: protocol [868,876]
===
match
---
simple_stmt [6278,6352]
simple_stmt [6368,6442]
===
match
---
expr_stmt [8756,8898]
expr_stmt [8846,8988]
===
match
---
trailer [9651,9660]
trailer [9733,9742]
===
match
---
string: "cert_key_pem" [7726,7740]
string: "cert_key_pem" [7816,7830]
===
match
---
name: ca_trust_path [5596,5609]
name: ca_trust_path [5686,5699]
===
match
---
operator: , [10038,10039]
operator: , [10120,10121]
===
match
---
string: "transport" [7136,7147]
string: "transport" [7226,7237]
===
match
---
string: "kerberos_hostname_override" [8497,8525]
string: "kerberos_hostname_override" [8587,8615]
===
match
---
atom_expr [8636,8671]
atom_expr [8726,8761]
===
match
---
operator: = [10204,10205]
operator: = [10286,10287]
===
match
---
fstring_string: , error:  [11075,11084]
fstring_string: , error:  [11157,11166]
===
match
---
name: self [9647,9651]
name: self [9729,9733]
===
match
---
atom_expr [9674,9687]
atom_expr [9756,9769]
===
match
---
trailer [9723,9735]
trailer [9805,9817]
===
match
---
simple_stmt [5515,5538]
simple_stmt [5605,5628]
===
match
---
expr_stmt [8445,8527]
expr_stmt [8535,8617]
===
match
---
argument [10778,10800]
argument [10860,10882]
===
match
---
trailer [6416,6431]
trailer [6506,6521]
===
match
---
dotted_name [877,891]
dotted_name [862,876]
===
match
---
atom_expr [5916,5947]
atom_expr [6006,6037]
===
match
---
expr_stmt [5651,5683]
expr_stmt [5741,5773]
===
match
---
operator: = [5206,5207]
operator: = [5296,5297]
===
match
---
atom_expr [8479,8527]
atom_expr [8569,8617]
===
match
---
name: cert_pem [5634,5642]
name: cert_pem [5724,5732]
===
match
---
name: self [6162,6166]
name: self [6252,6256]
===
match
---
name: conn [6718,6722]
name: conn [6808,6812]
===
match
---
name: debug [9245,9250]
name: debug [9335,9340]
===
match
---
operator: = [10383,10384]
operator: = [10465,10466]
===
match
---
trailer [6282,6286]
trailer [6372,6376]
===
match
---
name: message_encryption [6011,6029]
name: message_encryption [6101,6119]
===
match
---
atom_expr [7825,7852]
atom_expr [7915,7942]
===
match
---
atom_expr [9791,9812]
atom_expr [9873,9894]
===
match
---
atom_expr [6505,6518]
atom_expr [6595,6608]
===
match
---
param [5144,5182]
param [5234,5272]
===
match
---
operator: = [4848,4849]
operator: = [4938,4939]
===
match
---
name: self [5375,5379]
name: self [5465,5469]
===
match
---
if_stmt [7632,7743]
if_stmt [7722,7833]
===
match
---
name: extra_options [8932,8945]
name: extra_options [9022,9035]
===
match
---
name: extra_options [7122,7135]
name: extra_options [7212,7225]
===
match
---
name: username [6471,6479]
name: username [6561,6569]
===
match
---
name: password [6552,6560]
name: password [6642,6650]
===
match
---
param [4780,4811]
param [4870,4901]
===
match
---
name: bool [5169,5173]
name: bool [5259,5263]
===
match
---
name: kerberos_delegation [10389,10408]
name: kerberos_delegation [10471,10490]
===
match
---
operator: , [9950,9951]
operator: , [10032,10033]
===
match
---
name: error_msg [11166,11175]
name: error_msg [11248,11257]
===
match
---
operator: = [10727,10728]
operator: = [10809,10810]
===
match
---
name: password [10016,10024]
name: password [10098,10106]
===
match
---
trailer [7332,7339]
trailer [7422,7429]
===
match
---
suite [6741,9032]
suite [6831,9122]
===
match
---
name: Optional [4636,4644]
name: Optional [4726,4734]
===
match
---
operator: = [10314,10315]
operator: = [10396,10397]
===
match
---
atom_expr [5515,5527]
atom_expr [5605,5617]
===
match
---
trailer [10841,10846]
trailer [10923,10928]
===
match
---
name: cert_pem [10196,10204]
name: cert_pem [10278,10286]
===
match
---
suite [9813,10820]
suite [9895,10902]
===
match
---
expr_stmt [6162,6188]
expr_stmt [6252,6278]
===
match
---
name: self [8445,8449]
name: self [8535,8539]
===
match
---
if_stmt [7166,7262]
if_stmt [7256,7352]
===
match
---
expr_stmt [9830,10819]
expr_stmt [9912,10901]
===
match
---
simple_stmt [6758,6792]
simple_stmt [6848,6882]
===
match
---
trailer [10029,10038]
trailer [10111,10120]
===
match
---
name: remote_host [11063,11074]
name: remote_host [11145,11156]
===
match
---
if_stmt [6360,9032]
if_stmt [6450,9122]
===
match
---
atom_expr [8967,8980]
atom_expr [9057,9070]
===
match
---
simple_stmt [8286,8359]
simple_stmt [8376,8449]
===
match
---
tfpdef [4389,4415]
tfpdef [4479,4505]
===
match
---
name: ssh_conn_id [4389,4400]
name: ssh_conn_id [4479,4490]
===
match
---
operator: = [10067,10068]
operator: = [10149,10150]
===
match
---
name: lower [9014,9019]
name: lower [9104,9109]
===
match
---
expr_stmt [10922,10968]
expr_stmt [11004,11050]
===
match
---
trailer [10319,10342]
trailer [10401,10424]
===
match
---
param [4820,4855]
param [4910,4945]
===
match
---
name: get_conn [6198,6206]
name: get_conn [6288,6296]
===
match
---
atom_expr [6881,6906]
atom_expr [6971,6996]
===
match
---
trailer [6722,6728]
trailer [6812,6818]
===
match
---
if_stmt [7048,7150]
if_stmt [7138,7240]
===
match
---
name: ssh_conn_id [9467,9478]
name: ssh_conn_id [9557,9568]
===
match
---
name: username [4586,4594]
name: username [4676,4684]
===
match
---
trailer [8858,8864]
trailer [8948,8954]
===
match
---
dotted_name [962,980]
dotted_name [947,965]
===
match
---
trailer [9895,9904]
trailer [9977,9986]
===
match
---
operator: = [4532,4533]
operator: = [4622,4623]
===
match
---
name: strip [9805,9810]
name: strip [9887,9892]
===
match
---
name: str [4645,4648]
name: str [4735,4738]
===
match
---
atom_expr [10833,10909]
atom_expr [10915,10991]
===
match
---
name: extra_options [7790,7803]
name: extra_options [7880,7893]
===
match
---
name: self [4375,4379]
name: self [4465,4469]
===
match
---
if_stmt [7387,7501]
if_stmt [7477,7591]
===
match
---
simple_stmt [9078,9140]
simple_stmt [9168,9230]
===
match
---
simple_stmt [909,957]
simple_stmt [894,942]
===
match
---
string: "credssp_disable_tlsv1_2" [8692,8717]
string: "credssp_disable_tlsv1_2" [8782,8807]
===
match
---
name: self [9462,9466]
name: self [9552,9556]
===
match
---
trailer [6286,6292]
trailer [6376,6382]
===
match
---
operator: = [8981,8982]
operator: = [9071,9072]
===
match
---
atom_expr [10447,10468]
atom_expr [10529,10550]
===
match
---
name: open_shell [10956,10966]
name: open_shell [11038,11048]
===
match
---
string: "Establishing WinRM connection to host: %s" [10847,10890]
string: "Establishing WinRM connection to host: %s" [10929,10972]
===
match
---
name: transport [7106,7115]
name: transport [7196,7205]
===
match
---
simple_stmt [6505,6532]
simple_stmt [6595,6622]
===
match
---
trailer [6696,6701]
trailer [6786,6791]
===
match
---
argument [10292,10342]
argument [10374,10424]
===
match
---
operator: = [5632,5633]
operator: = [5722,5723]
===
match
---
name: transport [5431,5440]
name: transport [5521,5530]
===
match
---
atom_expr [5575,5593]
atom_expr [5665,5683]
===
match
---
name: self [5264,5268]
name: self [5354,5358]
===
match
---
name: conn [6405,6409]
name: conn [6495,6499]
===
match
---
expr_stmt [7569,7615]
expr_stmt [7659,7705]
===
match
---
if_stmt [8221,8359]
if_stmt [8311,8449]
===
match
---
name: ca_trust_path [10161,10174]
name: ca_trust_path [10243,10256]
===
match
---
atom_expr [7465,7500]
atom_expr [7555,7590]
===
match
---
trailer [4450,4455]
trailer [4540,4545]
===
match
---
tfpdef [4697,4718]
tfpdef [4787,4808]
===
match
---
atom_expr [8632,8672]
atom_expr [8722,8762]
===
match
---
name: operation_timeout_sec [8291,8312]
name: operation_timeout_sec [8381,8402]
===
match
---
expr_stmt [6038,6092]
expr_stmt [6128,6182]
===
match
---
trailer [5120,5125]
trailer [5210,5215]
===
match
---
atom_expr [4705,4718]
atom_expr [4795,4808]
===
match
---
operator: = [9980,9981]
operator: = [10062,10063]
===
match
---
suite [6840,6908]
suite [6930,6998]
===
match
---
simple_stmt [7217,7262]
simple_stmt [7307,7352]
===
match
---
atom_expr [7855,7899]
atom_expr [7945,7989]
===
match
---
name: log [9241,9244]
name: log [9331,9334]
===
match
---
expr_stmt [5546,5566]
expr_stmt [5636,5656]
===
match
---
param [5034,5083]
param [5124,5173]
===
match
---
trailer [5519,5527]
trailer [5609,5617]
===
match
---
name: ssh_conn_id [5269,5280]
name: ssh_conn_id [5359,5370]
===
match
---
name: endpoint [9652,9660]
name: endpoint [9734,9742]
===
match
---
name: self [10068,10072]
name: self [10150,10154]
===
match
---
expr_stmt [5449,5473]
expr_stmt [5539,5563]
===
match
---
operator: , [9478,9479]
operator: , [9568,9569]
===
match
---
atom_expr [6363,6379]
atom_expr [6453,6469]
===
match
---
trailer [9466,9478]
trailer [9556,9568]
===
match
---
if_stmt [6809,6908]
if_stmt [6899,6998]
===
match
---
name: kerberos_hostname_override [5034,5060]
name: kerberos_hostname_override [5124,5150]
===
match
---
name: self [9891,9895]
name: self [9973,9977]
===
match
---
operator: = [6067,6068]
operator: = [6157,6158]
===
match
---
name: credssp_disable_tlsv1_2 [8761,8784]
name: credssp_disable_tlsv1_2 [8851,8874]
===
match
---
name: password [9796,9804]
name: password [9878,9886]
===
match
---
name: extra_options [7859,7872]
name: extra_options [7949,7962]
===
match
---
name: Optional [4750,4758]
name: Optional [4840,4848]
===
match
---
name: ssh_conn_id [5283,5294]
name: ssh_conn_id [5373,5384]
===
match
---
name: remote_port [4515,4526]
name: remote_port [4605,4616]
===
match
---
expr_stmt [6861,6907]
expr_stmt [6951,6997]
===
match
---
name: extra_dejson [6779,6791]
name: extra_dejson [6869,6881]
===
match
---
arglist [9882,10801]
arglist [9964,10883]
===
match
---
operator: = [5720,5721]
operator: = [5810,5811]
===
match
---
and_test [9773,9812]
and_test [9855,9894]
===
match
---
operator: = [6519,6520]
operator: = [6609,6610]
===
match
---
name: send_cbt [6117,6125]
name: send_cbt [6207,6215]
===
match
---
if_stmt [6463,6532]
if_stmt [6553,6622]
===
match
---
name: server_cert_validation [5722,5744]
name: server_cert_validation [5812,5834]
===
match
---
operator: , [5212,5213]
operator: , [5302,5303]
===
match
---
suite [6237,6269]
suite [6327,6359]
===
match
---
simple_stmt [5985,6030]
simple_stmt [6075,6120]
===
match
---
name: extra_options [8636,8649]
name: extra_options [8726,8739]
===
match
---
param [5191,5213]
param [5281,5303]
===
match
---
trailer [9250,9493]
trailer [9340,9583]
===
match
---
operator: == [9022,9024]
operator: == [9112,9114]
===
match
---
import_from [872,907]
import_from [857,892]
===
match
---
name: endpoint [4432,4440]
name: endpoint [4522,4530]
===
match
---
atom_expr [8010,8046]
atom_expr [8100,8136]
===
match
---
name: self [6412,6416]
name: self [6502,6506]
===
match
---
name: extra_options [7236,7249]
name: extra_options [7326,7339]
===
match
---
name: __init__ [4357,4365]
name: __init__ [4447,4455]
===
match
---
param [4697,4726]
param [4787,4816]
===
match
---
trailer [4604,4609]
trailer [4694,4699]
===
match
---
suite [9065,9140]
suite [9155,9230]
===
match
---
name: Optional [4705,4713]
name: Optional [4795,4803]
===
match
---
atom_expr [9852,10819]
atom_expr [9934,10901]
===
match
---
fstring_start: f" [11029,11031]
fstring_start: f" [11111,11113]
===
match
---
simple_stmt [11186,11205]
simple_stmt [11268,11287]
===
match
---
tfpdef [4432,4455]
tfpdef [4522,4545]
===
match
---
atom_expr [10787,10800]
atom_expr [10869,10882]
===
match
---
string: "message_encryption" [8650,8670]
string: "message_encryption" [8740,8760]
===
match
---
name: self [8756,8760]
name: self [8846,8850]
===
match
---
trailer [5655,5668]
trailer [5745,5758]
===
match
---
name: self [10384,10388]
name: self [10466,10470]
===
match
---
atom_expr [10205,10218]
atom_expr [10287,10300]
===
match
---
atom_expr [4442,4455]
atom_expr [4532,4545]
===
match
---
string: "keytab" [7360,7368]
string: "keytab" [7450,7458]
===
match
---
comparison [6466,6487]
comparison [6556,6577]
===
match
---
trailer [9013,9019]
trailer [9103,9109]
===
match
---
parameters [6206,6212]
parameters [6296,6302]
===
match
---
suite [8585,8673]
suite [8675,8763]
===
match
---
operator: { [11084,11085]
operator: { [11166,11167]
===
match
---
name: error [11085,11090]
name: error [11167,11172]
===
match
---
atom_expr [8983,9021]
atom_expr [9073,9111]
===
match
---
name: Optional [4442,4450]
name: Optional [4532,4540]
===
match
---
name: service [5530,5537]
name: service [5620,5627]
===
match
---
name: self [10253,10257]
name: self [10335,10339]
===
match
---
name: self [10512,10516]
name: self [10594,10598]
===
match
---
atom_expr [9647,9660]
atom_expr [9729,9742]
===
match
---
expr_stmt [5375,5405]
expr_stmt [5465,5495]
===
match
---
expr_stmt [7979,8065]
expr_stmt [8069,8155]
===
match
---
name: extra_options [8987,9000]
name: extra_options [9077,9090]
===
match
---
trailer [6229,6236]
trailer [6319,6326]
===
match
---
string: 'true' [9025,9031]
string: 'true' [9115,9121]
===
match
---
name: transport [4548,4557]
name: transport [4638,4647]
===
match
---
name: self [9773,9777]
name: self [9855,9859]
===
match
---
trailer [8183,8203]
trailer [8273,8293]
===
match
---
suite [8121,8205]
suite [8211,8295]
===
match
---
name: str [8006,8009]
name: str [8096,8099]
===
match
---
expr_stmt [5753,5799]
expr_stmt [5843,5889]
===
match
---
operator: = [5948,5949]
operator: = [6038,6039]
===
match
---
trailer [6042,6066]
trailer [6132,6156]
===
match
---
fstring_expr [11084,11091]
fstring_expr [11166,11173]
===
match
---
name: password [6591,6599]
name: password [6681,6689]
===
match
---
name: self [9048,9052]
name: self [9138,9142]
===
match
---
name: bool [4935,4939]
name: bool [5025,5029]
===
match
---
atom_expr [7236,7260]
atom_expr [7326,7350]
===
match
---
name: message_encryption [10640,10658]
name: message_encryption [10722,10740]
===
match
---
atom_expr [7979,8003]
atom_expr [8069,8093]
===
match
---
atom_expr [7444,7462]
atom_expr [7534,7552]
===
match
---
simple_stmt [6135,6154]
simple_stmt [6225,6244]
===
match
---
operator: -> [5220,5222]
operator: -> [5310,5312]
===
match
---
trailer [9795,9804]
trailer [9877,9886]
===
match
---
name: getuser [9530,9537]
name: getuser [9612,9619]
===
match
---
name: read_timeout_sec [10452,10468]
name: read_timeout_sec [10534,10550]
===
match
---
string: 'auto' [5128,5134]
string: 'auto' [5218,5224]
===
match
---
operator: , [9410,9411]
operator: , [9500,9501]
===
match
---
trailer [7725,7741]
trailer [7815,7831]
===
match
---
atom_expr [6466,6479]
atom_expr [6556,6569]
===
match
---
name: cert_key_pem [10240,10252]
name: cert_key_pem [10322,10334]
===
match
---
name: ca_trust_path [4735,4748]
name: ca_trust_path [4825,4838]
===
match
---
operator: , [4505,4506]
operator: , [4595,4596]
===
match
---
comparison [6631,6655]
comparison [6721,6745]
===
match
---
name: endpoint [5308,5316]
name: endpoint [5398,5406]
===
match
---
operator: = [10786,10787]
operator: = [10868,10869]
===
match
---
operator: { [11057,11058]
operator: { [11139,11140]
===
match
---
trailer [9940,9950]
trailer [10022,10032]
===
match
---
operator: = [7230,7231]
operator: = [7320,7321]
===
match
---
simple_stmt [6979,7032]
simple_stmt [7069,7122]
===
match
---
comparison [8224,8264]
comparison [8314,8354]
===
match
---
simple_stmt [5808,5849]
simple_stmt [5898,5939]
===
match
---
fstring_start: f' [9690,9692]
fstring_start: f' [9772,9774]
===
match
---
param [4993,5025]
param [5083,5115]
===
match
---
trailer [6367,6379]
trailer [6457,6469]
===
match
---
trailer [11197,11204]
trailer [11279,11286]
===
match
---
simple_stmt [10833,10910]
simple_stmt [10915,10992]
===
match
---
if_stmt [9202,9540]
if_stmt [9292,9622]
===
match
---
atom_expr [5618,5631]
atom_expr [5708,5721]
===
match
---
fstring_string: /wsman [9736,9742]
fstring_string: /wsman [9818,9824]
===
match
---
suite [7080,7150]
suite [7170,7240]
===
match
---
operator: { [9718,9719]
operator: { [9800,9801]
===
match
---
simple_stmt [8756,8899]
simple_stmt [8846,8989]
===
match
---
operator: = [8785,8786]
operator: = [8875,8876]
===
match
---
trailer [10837,10841]
trailer [10919,10923]
===
match
---
simple_stmt [5482,5507]
simple_stmt [5572,5597]
===
match
---
strings [9268,9410]
strings [9358,9500]
===
match
---
tfpdef [4472,4498]
tfpdef [4562,4588]
===
match
---
fstring_end: " [11091,11092]
fstring_end: " [11173,11174]
===
match
---
name: server_cert_validation [10320,10342]
name: server_cert_validation [10402,10424]
===
match
---
name: str [8813,8816]
name: str [8903,8906]
===
match
---
simple_stmt [5575,5610]
simple_stmt [5665,5700]
===
match
---
name: extra [6723,6728]
name: extra [6813,6818]
===
match
---
atom_expr [7859,7898]
atom_expr [7949,7988]
===
match
---
operator: , [4770,4771]
operator: , [4860,4861]
===
match
---
expr_stmt [5515,5537]
expr_stmt [5605,5627]
===
match
---
name: self [5753,5757]
name: self [5843,5847]
===
match
---
string: "credssp_disable_tlsv1_2" [8831,8856]
string: "credssp_disable_tlsv1_2" [8921,8946]
===
match
---
param [4515,4539]
param [4605,4629]
===
match
---
expr_stmt [7825,7899]
expr_stmt [7915,7989]
===
match
---
expr_stmt [6505,6531]
expr_stmt [6595,6621]
===
match
---
name: AirflowException [9084,9100]
name: AirflowException [9174,9190]
===
match
---
atom_expr [5336,5352]
atom_expr [5426,5442]
===
match
---
name: self [10787,10791]
name: self [10869,10873]
===
match
---
param [4957,4984]
param [5047,5074]
===
match
---
name: self [10833,10837]
name: self [10915,10919]
===
match
---
name: remote_port [5394,5405]
name: remote_port [5484,5495]
===
match
---
name: self [6505,6509]
name: self [6595,6599]
===
match
---
simple_stmt [6038,6093]
simple_stmt [6128,6183]
===
match
---
operator: , [4462,4463]
operator: , [4552,4553]
===
match
---
atom_expr [8756,8784]
atom_expr [8846,8874]
===
match
---
operator: , [10468,10469]
operator: , [10550,10551]
===
match
---
trailer [6894,6906]
trailer [6984,6996]
===
match
---
trailer [10732,10756]
trailer [10814,10838]
===
match
---
trailer [9000,9012]
trailer [9090,9102]
===
match
---
string: "operation_timeout_sec" [8224,8247]
string: "operation_timeout_sec" [8314,8337]
===
match
---
name: self [7825,7829]
name: self [7915,7919]
===
match
---
trailer [8496,8526]
trailer [8586,8616]
===
match
---
string: 'true' [8870,8876]
string: 'true' [8960,8966]
===
match
---
string: "read_timeout_sec" [8085,8103]
string: "read_timeout_sec" [8175,8193]
===
match
---
operator: = [6690,6691]
operator: = [6780,6781]
===
match
---
name: message_encryption [10664,10682]
name: message_encryption [10746,10764]
===
match
---
name: int [5016,5019]
name: int [5106,5109]
===
match
---
simple_stmt [7328,7371]
simple_stmt [7418,7461]
===
match
---
name: self [8286,8290]
name: self [8376,8380]
===
match
---
expr_stmt [6135,6153]
expr_stmt [6225,6243]
===
match
---
param [4389,4423]
param [4479,4513]
===
match
---
trailer [5253,5255]
trailer [5343,5345]
===
match
---
trailer [4410,4415]
trailer [4500,4505]
===
match
---
trailer [4842,4847]
trailer [4932,4937]
===
match
---
trailer [8649,8671]
trailer [8739,8761]
===
match
---
atom_expr [6038,6066]
atom_expr [6128,6156]
===
match
---
suite [9223,9540]
suite [9313,9622]
===
match
---
name: self [5808,5812]
name: self [5898,5902]
===
match
---
operator: , [4538,4539]
operator: , [4628,4629]
===
match
---
trailer [6983,6995]
trailer [7073,7085]
===
match
---
funcdef [4353,6189]
funcdef [4443,6279]
===
match
---
name: self [6207,6211]
name: self [6297,6301]
===
match
---
comparison [6718,6740]
comparison [6808,6830]
===
match
---
name: str [7708,7711]
name: str [7798,7801]
===
match
---
simple_stmt [5692,5745]
simple_stmt [5782,5835]
===
match
---
operator: = [10446,10447]
operator: = [10528,10529]
===
match
---
trailer [7588,7615]
trailer [7678,7705]
===
match
---
name: str [4799,4802]
name: str [4889,4892]
===
match
---
name: self [9981,9985]
name: self [10063,10067]
===
match
---
if_stmt [7759,7900]
if_stmt [7849,7990]
===
match
---
operator: , [9904,9905]
operator: , [9986,9987]
===
match
---
simple_stmt [5546,5567]
simple_stmt [5636,5657]
===
match
---
param [4548,4577]
param [4638,4667]
===
match
---
name: server_cert_validation [4864,4886]
name: server_cert_validation [4954,4976]
===
match
---
name: remote_host [10897,10908]
name: remote_host [10979,10990]
===
match
---
expr_stmt [6673,6701]
expr_stmt [6763,6791]
===
match
---
name: str [8983,8986]
name: str [9073,9076]
===
match
---
simple_stmt [11017,11093]
simple_stmt [11099,11175]
===
match
---
param [4666,4688]
param [4756,4778]
===
match
---
operator: , [10756,10757]
operator: , [10838,10839]
===
match
---
trailer [10955,10966]
trailer [11037,11048]
===
match
---
suite [6569,6616]
suite [6659,6706]
===
match
---
trailer [9244,9250]
trailer [9334,9340]
===
match
---
name: endpoint [6866,6874]
name: endpoint [6956,6964]
===
match
---
atom_expr [6101,6114]
atom_expr [6191,6204]
===
match
---
fstring_expr [9699,9717]
fstring_expr [9781,9799]
===
match
---
atom_expr [7232,7261]
atom_expr [7322,7351]
===
match
---
atom_expr [10587,10618]
atom_expr [10669,10700]
===
match
---
suite [6392,9032]
suite [6482,9122]
===
match
---
trailer [5579,5593]
trailer [5669,5683]
===
match
---
trailer [7015,7030]
trailer [7105,7120]
===
match
---
name: self [7217,7221]
name: self [7307,7311]
===
match
---
argument [10060,10080]
argument [10142,10162]
===
match
---
argument [10102,10120]
argument [10184,10202]
===
match
---
operator: , [5181,5182]
operator: , [5271,5272]
===
match
---
simple_stmt [5618,5643]
simple_stmt [5708,5733]
===
match
---
trailer [9052,9064]
trailer [9142,9154]
===
match
---
name: credssp_disable_tlsv1_2 [6043,6066]
name: credssp_disable_tlsv1_2 [6133,6156]
===
match
---
name: __init__ [5245,5253]
name: __init__ [5335,5343]
===
match
---
trailer [9985,9994]
trailer [10067,10076]
===
match
---
operator: = [8477,8478]
operator: = [8567,8568]
===
match
---
name: kerberos_delegation [10364,10383]
name: kerberos_delegation [10446,10465]
===
match
---
name: Exception [10985,10994]
name: Exception [11067,11076]
===
match
---
trailer [9777,9786]
trailer [9859,9868]
===
match
---
operator: } [11090,11091]
operator: } [11172,11173]
===
match
---
trailer [10966,10968]
trailer [11048,11050]
===
match
---
trailer [10113,10120]
trailer [10195,10202]
===
match
---
atom_expr [11105,11130]
atom_expr [11187,11212]
===
match
---
trailer [5244,5253]
trailer [5334,5343]
===
match
---
name: Protocol [899,907]
name: Protocol [884,892]
===
match
---
name: self [7688,7692]
name: self [7778,7782]
===
match
---
operator: = [9935,9936]
operator: = [10017,10018]
===
match
---
atom_expr [6998,7031]
atom_expr [7088,7121]
===
match
---
operator: = [4940,4941]
operator: = [5030,5031]
===
match
---
atom_expr [6673,6689]
atom_expr [6763,6779]
===
match
---
simple_stmt [5651,5684]
simple_stmt [5741,5774]
===
match
---
operator: = [10586,10587]
operator: = [10668,10669]
===
match
---
name: extra_options [7346,7359]
name: extra_options [7436,7449]
===
match
---
trailer [8816,8858]
trailer [8906,8948]
===
match
---
trailer [10451,10468]
trailer [10533,10550]
===
match
---
string: "server_cert_validation" [7873,7897]
string: "server_cert_validation" [7963,7987]
===
match
---
trailer [9834,9849]
trailer [9916,9931]
===
match
---
trailer [9678,9687]
trailer [9760,9769]
===
match
---
simple_stmt [6405,6450]
simple_stmt [6495,6540]
===
match
---
trailer [5861,5883]
trailer [5951,5973]
===
match
---
string: "send_cbt" [9001,9011]
string: "send_cbt" [9091,9101]
===
match
---
name: send_cbt [5191,5199]
name: send_cbt [5281,5289]
===
match
---
trailer [5486,5495]
trailer [5576,5585]
===
match
---
name: cert_pem [10210,10218]
name: cert_pem [10292,10300]
===
match
---
operator: = [9520,9521]
operator: = [9610,9611]
===
match
---
name: ssh_conn_id [6339,6350]
name: ssh_conn_id [6429,6440]
===
match
---
name: username [9214,9222]
name: username [9304,9312]
===
match
---
operator: { [9699,9700]
operator: { [9781,9782]
===
match
---
tfpdef [4626,4649]
tfpdef [4716,4739]
===
match
---
name: password [5487,5495]
name: password [5577,5585]
===
match
---
simple_stmt [6250,6269]
simple_stmt [6340,6359]
===
match
---
atom_expr [7712,7741]
atom_expr [7802,7831]
===
match
---
trailer [7858,7899]
trailer [7948,7989]
===
match
---
operator: , [4576,4577]
operator: , [4666,4667]
===
match
---
trailer [7602,7614]
trailer [7692,7704]
===
match
---
name: self [6586,6590]
name: self [6676,6680]
===
match
---
name: str [6877,6880]
name: str [6967,6970]
===
match
---
if_stmt [7278,7371]
if_stmt [7368,7461]
===
match
---
trailer [8971,8980]
trailer [9061,9070]
===
match
---
operator: = [7463,7464]
operator: = [7553,7554]
===
match
---
atom_expr [10025,10038]
atom_expr [10107,10120]
===
match
---
atom_expr [8483,8526]
atom_expr [8573,8616]
===
match
---
name: kerberos_hostname_override [5921,5947]
name: kerberos_hostname_override [6011,6037]
===
match
---
trailer [7468,7500]
trailer [7558,7590]
===
match
---
name: super [5237,5242]
name: super [5327,5332]
===
match
---
expr_stmt [5857,5907]
expr_stmt [5947,5997]
===
match
---
string: "send_cbt" [8918,8928]
string: "send_cbt" [9008,9018]
===
match
---
number: 30 [4981,4983]
number: 30 [5071,5073]
===
match
---
trailer [7482,7499]
trailer [7572,7589]
===
match
---
name: extra_options [7534,7547]
name: extra_options [7624,7637]
===
match
---
name: self [6257,6261]
name: self [6347,6351]
===
match
---
simple_stmt [9674,9744]
simple_stmt [9756,9826]
===
match
---
name: airflow [962,969]
name: airflow [947,954]
===
match
---
comparison [7390,7422]
comparison [7480,7512]
===
match
---
name: remote_port [5380,5391]
name: remote_port [5470,5481]
===
match
---
name: extra_options [7653,7666]
name: extra_options [7743,7756]
===
match
---
fstring_end: ' [9742,9743]
fstring_end: ' [9824,9825]
===
match
---
expr_stmt [5414,5440]
expr_stmt [5504,5530]
===
match
---
param [4735,4771]
param [4825,4861]
===
match
---
not_test [9643,9660]
not_test [9725,9742]
===
match
---
name: self [5546,5550]
name: self [5636,5640]
===
match
---
comparison [7635,7666]
comparison [7725,7756]
===
match
---
name: self [5618,5622]
name: self [5708,5712]
===
match
---
expr_stmt [5336,5366]
expr_stmt [5426,5456]
===
match
---
string: "Missing required param: remote_host" [9101,9138]
string: "Missing required param: remote_host" [9191,9228]
===
match
---
name: self [9209,9213]
name: self [9299,9303]
===
match
---
operator: = [4804,4805]
operator: = [4894,4895]
===
match
---
arglist [10847,10908]
arglist [10929,10990]
===
match
---
name: extra_options [8170,8183]
name: extra_options [8260,8273]
===
match
---
name: extra_options [6758,6771]
name: extra_options [6848,6861]
===
match
---
operator: = [6996,6997]
operator: = [7086,7087]
===
match
---
argument [10640,10682]
argument [10722,10764]
===
match
---
operator: = [4979,4980]
operator: = [5069,5070]
===
match
---
atom_expr [6278,6351]
atom_expr [6368,6441]
===
match
---
string: 'Creating WinRM client for conn_id: %s' [6293,6332]
string: 'Creating WinRM client for conn_id: %s' [6383,6422]
===
match
---
if_stmt [6544,6616]
if_stmt [6634,6706]
===
match
---
trailer [6606,6615]
trailer [6696,6705]
===
match
---
param [6207,6211]
param [6297,6301]
===
match
---
name: self [9791,9795]
name: self [9873,9877]
===
match
---
atom_expr [10068,10080]
atom_expr [10150,10162]
===
match
---
name: send_cbt [8972,8980]
name: send_cbt [9062,9070]
===
match
---
trailer [5070,5075]
trailer [5160,5165]
===
match
---
suite [5228,6189]
suite [5318,6279]
===
match
---
trailer [4644,4649]
trailer [4734,4739]
===
match
---
funcdef [6194,11205]
funcdef [6284,11287]
===
match
---
arglist [6293,6350]
arglist [6383,6440]
===
match
---
operator: , [10174,10175]
operator: , [10256,10257]
===
match
---
simple_stmt [5449,5474]
simple_stmt [5539,5564]
===
match
---
operator: = [5884,5885]
operator: = [5974,5975]
===
match
---
name: send_cbt [10778,10786]
name: send_cbt [10860,10868]
===
match
---
atom_expr [5482,5495]
atom_expr [5572,5585]
===
match
---
atom_expr [6692,6701]
atom_expr [6782,6791]
===
match
---
name: Optional [4402,4410]
name: Optional [4492,4500]
===
match
---
trailer [6338,6350]
trailer [6428,6440]
===
match
---
simple_stmt [957,997]
simple_stmt [942,982]
===
match
---
argument [10196,10218]
argument [10278,10300]
===
match
---
comparison [7281,7306]
comparison [7371,7396]
===
match
---
operator: = [5392,5393]
operator: = [5482,5483]
===
match
---
trailer [6105,6114]
trailer [6195,6204]
===
match
---
name: endpoint [9679,9687]
name: endpoint [9761,9769]
===
match
---
atom_expr [5985,6008]
atom_expr [6075,6098]
===
match
---
operator: = [9850,9851]
operator: = [9932,9933]
===
match
---
name: self [10156,10160]
name: self [10238,10242]
===
match
---
trailer [6509,6518]
trailer [6599,6608]
===
match
---
name: extra_options [8010,8023]
name: extra_options [8100,8113]
===
match
---
name: self [10205,10209]
name: self [10287,10291]
===
match
---
operator: , [10120,10121]
operator: , [10202,10203]
===
match
---
operator: = [9890,9891]
operator: = [9972,9973]
===
match
---
name: password [5498,5506]
name: password [5588,5596]
===
match
---
name: self [6135,6139]
name: self [6225,6229]
===
match
---
suite [7667,7743]
suite [7757,7833]
===
match
---
tfpdef [4735,4763]
tfpdef [4825,4853]
===
match
---
operator: = [5317,5318]
operator: = [5407,5408]
===
match
---
tfpdef [5191,5205]
tfpdef [5281,5295]
===
match
---
string: " %s. Using system's default provided by getpass.getuser()" [9351,9410]
string: " %s. Using system's default provided by getpass.getuser()" [9441,9500]
===
match
---
param [4626,4657]
param [4716,4747]
===
match
---
name: self [5515,5519]
name: self [5605,5609]
===
match
---
simple_stmt [843,871]
simple_stmt [828,856]
===
match
---
operator: = [7340,7341]
operator: = [7430,7431]
===
match
---
operator: = [5429,5430]
operator: = [5519,5520]
===
match
---
name: int [8166,8169]
name: int [8256,8259]
===
match
---
name: self [9936,9940]
name: self [10018,10022]
===
match
---
simple_stmt [7688,7743]
simple_stmt [7778,7833]
===
match
---
trailer [9019,9021]
trailer [9109,9111]
===
match
---
operator: , [4616,4617]
operator: , [4706,4707]
===
match
---
name: error [10998,11003]
name: error [11080,11085]
===
match
---
expr_stmt [6979,7031]
expr_stmt [7069,7121]
===
match
---
name: login [6526,6531]
name: login [6616,6621]
===
match
---
name: Optional [4834,4842]
name: Optional [4924,4932]
===
match
---
name: base [976,980]
name: base [961,965]
===
match
---
operator: } [9716,9717]
operator: } [9798,9799]
===
match
---
name: typing [848,854]
name: typing [833,839]
===
match
---
trailer [8146,8163]
trailer [8236,8253]
===
match
---
suite [7423,7501]
suite [7513,7591]
===
match
---
name: extra_options [8251,8264]
name: extra_options [8341,8354]
===
match
---
trailer [5268,5280]
trailer [5358,5370]
===
match
---
trailer [7692,7705]
trailer [7782,7795]
===
match
---
operator: , [4904,4905]
operator: , [4994,4995]
===
match
---
comparison [8085,8120]
comparison [8175,8210]
===
match
---
argument [10240,10270]
argument [10322,10352]
===
match
---
name: self [7101,7105]
name: self [7191,7195]
===
match
---
simple_stmt [5264,5295]
simple_stmt [5354,5385]
===
match
---
name: username [6510,6518]
name: username [6600,6608]
===
match
---
atom_expr [4750,4763]
atom_expr [4840,4853]
===
match
---
name: transport [5419,5428]
name: transport [5509,5518]
===
match
---
atom_expr [8606,8629]
atom_expr [8696,8719]
===
match
---
name: endpoint [9896,9904]
name: endpoint [9978,9986]
===
match
---
trailer [6525,6531]
trailer [6615,6621]
===
match
---
name: error [11114,11119]
name: error [11196,11201]
===
match
---
name: ca_trust_path [7449,7462]
name: ca_trust_path [7539,7552]
===
match
---
expr_stmt [8606,8672]
expr_stmt [8696,8762]
===
match
---
atom_expr [6432,6448]
atom_expr [6522,6538]
===
match
---
parameters [4365,5219]
parameters [4455,5309]
===
match
---
atom_expr [5375,5391]
atom_expr [5465,5481]
===
match
---
operator: == [8056,8058]
operator: == [8146,8148]
===
match
---
tfpdef [4666,4678]
tfpdef [4756,4768]
===
match
---
trailer [10940,10955]
trailer [11022,11037]
===
match
---
atom_expr [9048,9064]
atom_expr [9138,9154]
===
match
---
name: operation_timeout_sec [10517,10538]
name: operation_timeout_sec [10599,10620]
===
match
---
fstring [9690,9743]
fstring [9772,9825]
===
match
---
trailer [6865,6874]
trailer [6955,6964]
===
match
---
trailer [7121,7149]
trailer [7211,7239]
===
match
---
atom_expr [5414,5428]
atom_expr [5504,5518]
===
match
---
name: send_cbt [10792,10800]
name: send_cbt [10874,10882]
===
match
---
comparison [8918,8945]
comparison [9008,9035]
===
match
---
name: username [9986,9994]
name: username [10068,10076]
===
match
---
atom_expr [9428,9444]
atom_expr [9518,9534]
===
match
---
simple_stmt [9236,9494]
simple_stmt [9326,9584]
===
match
---
not_test [9044,9064]
not_test [9134,9154]
===
match
---
name: credssp_disable_tlsv1_2 [5144,5167]
name: credssp_disable_tlsv1_2 [5234,5257]
===
match
---
trailer [8318,8358]
trailer [8408,8448]
===
match
---
tfpdef [5034,5075]
tfpdef [5124,5165]
===
match
---
trailer [9537,9539]
trailer [9619,9621]
===
match
---
name: read_timeout_sec [5832,5848]
name: read_timeout_sec [5922,5938]
===
match
---
name: extra_options [8410,8423]
name: extra_options [8500,8513]
===
match
---
simple_stmt [9830,10820]
simple_stmt [9912,10902]
===
match
---
if_stmt [6628,6702]
if_stmt [6718,6792]
===
match
---
operator: , [10538,10539]
operator: , [10620,10621]
===
match
---
operator: } [11074,11075]
operator: } [11156,11157]
===
match
---
atom_expr [7328,7339]
atom_expr [7418,7429]
===
match
---
trailer [7872,7898]
trailer [7962,7988]
===
match
---
name: self [7444,7448]
name: self [7534,7538]
===
match
---
simple_stmt [8606,8673]
simple_stmt [8696,8763]
===
match
---
name: self [6278,6282]
name: self [6368,6372]
===
match
---
trailer [10388,10408]
trailer [10470,10490]
===
match
---
string: "cert_key_pem" [7635,7649]
string: "cert_key_pem" [7725,7739]
===
match
---
atom_expr [5857,5883]
atom_expr [5947,5973]
===
match
---
atom_expr [5237,5255]
atom_expr [5327,5345]
===
match
---
expr_stmt [6101,6125]
expr_stmt [6191,6215]
===
match
---
operator: = [4892,4893]
operator: = [4982,4983]
===
match
---
operator: = [5669,5670]
operator: = [5759,5760]
===
match
---
trailer [6139,6146]
trailer [6229,6236]
===
match
---
atom_expr [6586,6599]
atom_expr [6676,6689]
===
match
---
atom_expr [4485,4498]
atom_expr [4575,4588]
===
match
---
tfpdef [4548,4562]
tfpdef [4638,4652]
===
match
---
name: service [10073,10080]
name: service [10155,10162]
===
match
---
simple_stmt [6162,6189]
simple_stmt [6252,6279]
===
match
---
import_from [909,956]
import_from [894,941]
===
match
---
atom_expr [9506,9519]
atom_expr [9596,9609]
===
match
---
operator: = [4679,4680]
operator: = [4769,4770]
===
match
---
trailer [6470,6479]
trailer [6560,6569]
===
match
---
operator: = [5126,5127]
operator: = [5216,5217]
===
match
---
name: keytab [5551,5557]
name: keytab [5641,5647]
===
match
---
name: self [5857,5861]
name: self [5947,5951]
===
match
---
name: str [4714,4717]
name: str [4804,4807]
===
match
---
name: self [5916,5920]
name: self [6006,6010]
===
match
---
name: self [6466,6470]
name: self [6556,6560]
===
match
---
operator: = [7116,7117]
operator: = [7206,7207]
===
match
---
operator: , [5082,5083]
operator: , [5172,5173]
===
match
---
name: kerberos_hostname_override [5950,5976]
name: kerberos_hostname_override [6040,6066]
===
match
---
comparison [8378,8423]
comparison [8468,8513]
===
match
---
trailer [6551,6560]
trailer [6641,6650]
===
match
---
operator: = [8630,8631]
operator: = [8720,8721]
===
match
---
name: self [9719,9723]
name: self [9801,9805]
===
match
---
name: str [7585,7588]
name: str [7675,7678]
===
match
---
operator: = [5528,5529]
operator: = [5618,5619]
===
match
---
expr_stmt [6758,6791]
expr_stmt [6848,6881]
===
match
---
operator: , [10618,10619]
operator: , [10700,10701]
===
match
---
trailer [6166,6181]
trailer [6256,6271]
===
match
---
atom_expr [8286,8312]
atom_expr [8376,8402]
===
match
---
trailer [7359,7369]
trailer [7449,7459]
===
match
---
atom_expr [7585,7615]
atom_expr [7675,7705]
===
match
---
operator: , [4810,4811]
operator: , [4900,4901]
===
match
---
name: password [9778,9786]
name: password [9860,9868]
===
match
---
name: password [6607,6615]
name: password [6697,6705]
===
match
---
comparison [7919,7957]
comparison [8009,8047]
===
match
---
name: extra_options [7944,7957]
name: extra_options [8034,8047]
===
match
---
atom_expr [9773,9786]
atom_expr [9855,9868]
===
match
---
name: message_encryption [5092,5110]
name: message_encryption [5182,5200]
===
match
---
trailer [7235,7261]
trailer [7325,7351]
===
match
---
trailer [8047,8053]
trailer [8137,8143]
===
match
---
trailer [10591,10618]
trailer [10673,10700]
===
match
---
name: self [8967,8971]
name: self [9057,9061]
===
match
---
atom_expr [5546,5557]
atom_expr [5636,5647]
===
match
---
name: message_encryption [8611,8629]
name: message_encryption [8701,8719]
===
match
---
trailer [5242,5244]
trailer [5332,5334]
===
match
---
name: remote_port [6984,6995]
name: remote_port [7074,7085]
===
match
---
operator: , [10270,10271]
operator: , [10352,10353]
===
match
---
name: self [9506,9510]
name: self [9596,9600]
===
match
---
trailer [4713,4718]
trailer [4803,4808]
===
match
---
atom_expr [9981,9994]
atom_expr [10063,10076]
===
match
---
operator: } [9735,9736]
operator: } [9817,9818]
===
match
---
name: remote_host [5341,5352]
name: remote_host [5431,5442]
===
match
---
raise_stmt [9078,9139]
raise_stmt [9168,9229]
===
match
---
atom_expr [5449,5462]
atom_expr [5539,5552]
===
match
---
name: self [6038,6042]
name: self [6128,6132]
===
match
---
simple_stmt [872,908]
simple_stmt [857,893]
===
match
---
name: extra_options [8817,8830]
name: extra_options [8907,8920]
===
match
---
name: keytab [4697,4703]
name: keytab [4787,4793]
===
match
---
string: "ca_trust_path" [7390,7405]
string: "ca_trust_path" [7480,7495]
===
match
---
trailer [6635,6647]
trailer [6725,6737]
===
match
---
atom_expr [5303,5316]
atom_expr [5393,5406]
===
match
---
name: remote_host [6678,6689]
name: remote_host [6768,6779]
===
match
---
operator: = [6772,6773]
operator: = [6862,6863]
===
match
---
name: str [4888,4891]
name: str [4978,4981]
===
match
---
operator: , [9444,9445]
operator: , [9534,9535]
===
match
---
atom_expr [9084,9139]
atom_expr [9174,9229]
===
match
---
atom_expr [6861,6874]
atom_expr [6951,6964]
===
match
---
name: self [8142,8146]
name: self [8232,8236]
===
match
---
atom_expr [4790,4803]
atom_expr [4880,4893]
===
match
---
name: endpoint [5319,5327]
name: endpoint [5409,5417]
===
match
---
name: message_encryption [5990,6008]
name: message_encryption [6080,6098]
===
match
---
trailer [8986,9013]
trailer [9076,9103]
===
match
---
name: kerberos_delegation [5780,5799]
name: kerberos_delegation [5870,5889]
===
match
---
atom_expr [10253,10270]
atom_expr [10335,10352]
===
match
---
operator: , [10682,10683]
operator: , [10764,10765]
===
match
---
name: Optional [4790,4798]
name: Optional [4880,4888]
===
match
---
name: conn [6521,6525]
name: conn [6611,6615]
===
match
---
name: password [4626,4634]
name: password [4716,4724]
===
match
---
expr_stmt [9506,9539]
expr_stmt [9596,9621]
===
match
---
tfpdef [4820,4847]
tfpdef [4910,4937]
===
match
---
name: self [9236,9240]
name: self [9326,9330]
===
match
---
string: "endpoint" [6895,6905]
string: "endpoint" [6985,6995]
===
match
---
name: self [10922,10926]
name: self [11004,11008]
===
match
---
operator: = [8004,8005]
operator: = [8094,8095]
===
match
---
param [4432,4463]
param [4522,4553]
===
match
---
suite [8946,9032]
suite [9036,9122]
===
match
---
argument [10364,10408]
argument [10446,10490]
===
match
---
classdef [1140,11205]
classdef [1230,11287]
===
match
---
trailer [9240,9244]
trailer [9330,9334]
===
match
---
name: conn [6692,6696]
name: conn [6782,6786]
===
match
---
simple_stmt [7101,7150]
simple_stmt [7191,7240]
===
match
---
expr_stmt [9674,9743]
expr_stmt [9756,9825]
===
match
---
comparison [8813,8876]
comparison [8903,8966]
===
match
---
trailer [5696,5719]
trailer [5786,5809]
===
match
---
argument [9882,9904]
argument [9964,9986]
===
match
---
trailer [4493,4498]
trailer [4583,4588]
===
match
---
expr_stmt [5303,5327]
expr_stmt [5393,5417]
===
match
---
string: "message_encryption" [8547,8567]
string: "message_encryption" [8637,8657]
===
match
---
name: read_timeout_sec [4957,4973]
name: read_timeout_sec [5047,5063]
===
match
---
atom_expr [5651,5668]
atom_expr [5741,5758]
===
match
---
operator: = [4456,4457]
operator: = [4546,4547]
===
match
---
name: cert_key_pem [4820,4832]
name: cert_key_pem [4910,4922]
===
match
---
fstring_string: : [9717,9718]
fstring_string: : [9799,9800]
===
match
---
name: self [10587,10591]
name: self [10669,10673]
===
match
---
atom_expr [6602,6615]
atom_expr [6692,6705]
===
match
---
name: self [6979,6983]
name: self [7069,7073]
===
match
---
trailer [10791,10800]
trailer [10873,10882]
===
match
---
name: remote_host [6636,6647]
name: remote_host [6726,6737]
===
match
---
trailer [8449,8476]
trailer [8539,8566]
===
match
---
name: self [5692,5696]
name: self [5782,5786]
===
match
---
simple_stmt [5237,5256]
simple_stmt [5327,5346]
===
match
---
import_from [843,870]
import_from [828,855]
===
match
---
param [4472,4506]
param [4562,4596]
===
match
---
name: cert_key_pem [5656,5668]
name: cert_key_pem [5746,5758]
===
match
---
suite [1166,11205]
suite [1256,11287]
===
match
---
suite [6958,7032]
suite [7048,7122]
===
match
---
operator: = [4764,4765]
operator: = [4854,4855]
===
match
---
name: self [6861,6865]
name: self [6951,6955]
===
match
---
name: remote_host [5355,5366]
name: remote_host [5445,5456]
===
match
---
trailer [6261,6268]
trailer [6351,6358]
===
match
---
suite [6213,11205]
suite [6303,11287]
===
match
---
argument [9972,9994]
argument [10054,10076]
===
match
---
operator: = [5778,5779]
operator: = [5868,5869]
===
match
---
trailer [11119,11130]
trailer [11201,11212]
===
match
---
simple_stmt [5753,5800]
simple_stmt [5843,5890]
===
match
---
expr_stmt [7101,7149]
expr_stmt [7191,7239]
===
match
---
fstring_string: Error connecting to host:  [11031,11057]
fstring_string: Error connecting to host:  [11113,11139]
===
match
---
name: int [4528,4531]
name: int [4618,4621]
===
match
---
atom_expr [9462,9478]
atom_expr [9552,9568]
===
match
---
atom_expr [10892,10908]
atom_expr [10974,10990]
===
match
---
name: client [10927,10933]
name: client [11009,11015]
===
match
---
name: self [11105,11109]
name: self [11187,11191]
===
match
---
atom_expr [7118,7149]
atom_expr [7208,7239]
===
match
---
name: ca_trust_path [5580,5593]
name: ca_trust_path [5670,5683]
===
match
---
name: kerberos_delegation [5758,5777]
name: kerberos_delegation [5848,5867]
===
match
---
string: "read_timeout_sec" [8184,8202]
string: "read_timeout_sec" [8274,8292]
===
match
---
name: self [5651,5655]
name: self [5741,5745]
===
match
---
operator: = [6600,6601]
operator: = [6690,6691]
===
match
---
name: str [7232,7235]
name: str [7322,7325]
===
match
---
if_stmt [8915,9032]
if_stmt [9005,9122]
===
match
---
comparison [7169,7195]
comparison [7259,7285]
===
match
---
expr_stmt [7444,7500]
expr_stmt [7534,7590]
===
insert-tree
---
simple_stmt [789,828]
    string: """Hook for winrm remote execution.""" [789,827]
to
file_input [789,11205]
at 0
===
insert-tree
---
try_stmt [983,1087]
    suite [987,1035]
        simple_stmt [992,1035]
            import_from [992,1034]
                dotted_name [997,1019]
                    name: airflow [997,1004]
                    name: utils [1005,1010]
                    name: platform [1011,1019]
                name: getuser [1027,1034]
    except_clause [1035,1053]
        name: ImportError [1042,1053]
    suite [1054,1087]
        simple_stmt [1059,1087]
            import_from [1059,1086]
                name: getpass [1064,1071]
                name: getuser [1079,1086]
to
file_input [789,11205]
at 7
===
insert-node
---
name: WinRMHook [1236,1245]
to
classdef [1140,11205]
at 0
===
insert-node
---
name: BaseHook [1246,1254]
to
classdef [1140,11205]
at 1
===
insert-tree
---
simple_stmt [1261,4438]
    string: """     Hook for winrm remote execution using pywinrm.      :seealso: https://github.com/diyan/pywinrm/blob/master/winrm/protocol.py      :param ssh_conn_id: connection id from airflow Connections from where         all the required parameters can be fetched like username and password.         Thought the priority is given to the param passed during init     :type ssh_conn_id: str     :param endpoint: When not set, endpoint will be constructed like this:         'http://{remote_host}:{remote_port}/wsman'     :type endpoint: str     :param remote_host: Remote host to connect to. Ignored if `endpoint` is set.     :type remote_host: str     :param remote_port: Remote port to connect to. Ignored if `endpoint` is set.     :type remote_port: int     :param transport: transport type, one of 'plaintext' (default), 'kerberos', 'ssl', 'ntlm', 'credssp'     :type transport: str     :param username: username to connect to the remote_host     :type username: str     :param password: password of the username to connect to the remote_host     :type password: str     :param service: the service name, default is HTTP     :type service: str     :param keytab: the path to a keytab file if you are using one     :type keytab: str     :param ca_trust_path: Certification Authority trust path     :type ca_trust_path: str     :param cert_pem: client authentication certificate file path in PEM format     :type cert_pem: str     :param cert_key_pem: client authentication certificate key file path in PEM format     :type cert_key_pem: str     :param server_cert_validation: whether server certificate should be validated on         Python versions that support it; one of 'validate' (default), 'ignore'     :type server_cert_validation: str     :param kerberos_delegation: if True, TGT is sent to target server to         allow multiple hops     :type kerberos_delegation: bool     :param read_timeout_sec: maximum seconds to wait before an HTTP connect/read times out (default 30).         This value should be slightly higher than operation_timeout_sec,         as the server can block *at least* that long.     :type read_timeout_sec: int     :param operation_timeout_sec: maximum allowed time in seconds for any single wsman         HTTP operation (default 20). Note that operation timeouts while receiving output         (the only wsman operation that should take any significant time,         and where these timeouts are expected) will be silently retried indefinitely.     :type operation_timeout_sec: int     :param kerberos_hostname_override: the hostname to use for the kerberos exchange         (defaults to the hostname in the endpoint URL)     :type kerberos_hostname_override: str     :param message_encryption: Will encrypt the WinRM messages if set         and the transport auth supports message encryption. (Default 'auto')     :type message_encryption: str     :param credssp_disable_tlsv1_2: Whether to disable TLSv1.2 support and work with older         protocols like TLSv1.0, default is False     :type credssp_disable_tlsv1_2: bool     :param send_cbt: Will send the channel bindings over a HTTPS channel (Default: True)     :type send_cbt: bool     """ [1261,4437]
to
suite [1166,11205]
at 0
===
move-tree
---
name: getuser [9530,9537]
to
atom_expr [9522,9539]
at 0
===
delete-tree
---
simple_stmt [789,828]
    string: """Hook for winrm remote execution.""" [789,827]
===
delete-tree
---
simple_stmt [828,843]
    import_name [828,842]
        name: getpass [835,842]
===
delete-node
---
name: WinRMHook [1146,1155]
===
===
delete-node
---
name: BaseHook [1156,1164]
===
===
delete-tree
---
simple_stmt [1171,4348]
    string: """     Hook for winrm remote execution using pywinrm.      :seealso: https://github.com/diyan/pywinrm/blob/master/winrm/protocol.py      :param ssh_conn_id: connection id from airflow Connections from where         all the required parameters can be fetched like username and password.         Thought the priority is given to the param passed during init     :type ssh_conn_id: str     :param endpoint: When not set, endpoint will be constructed like this:         'http://{remote_host}:{remote_port}/wsman'     :type endpoint: str     :param remote_host: Remote host to connect to. Ignored if `endpoint` is set.     :type remote_host: str     :param remote_port: Remote port to connect to. Ignored if `endpoint` is set.     :type remote_port: int     :param transport: transport type, one of 'plaintext' (default), 'kerberos', 'ssl', 'ntlm', 'credssp'     :type transport: str     :param username: username to connect to the remote_host     :type username: str     :param password: password of the username to connect to the remote_host     :type password: str     :param service: the service name, default is HTTP     :type service: str     :param keytab: the path to a keytab file if you are using one     :type keytab: str     :param ca_trust_path: Certification Authority trust path     :type ca_trust_path: str     :param cert_pem: client authentication certificate file path in PEM format     :type cert_pem: str     :param cert_key_pem: client authentication certificate key file path in PEM format     :type cert_key_pem: str     :param server_cert_validation: whether server certificate should be validated on         Python versions that support it; one of 'validate' (default), 'ignore'     :type server_cert_validation: str     :param kerberos_delegation: if True, TGT is sent to target server to         allow multiple hops     :type kerberos_delegation: bool     :param read_timeout_sec: maximum seconds to wait before an HTTP connect/read times out (default 30).         This value should be slightly higher than operation_timeout_sec,         as the server can block *at least* that long.     :type read_timeout_sec: int     :param operation_timeout_sec: maximum allowed time in seconds for any single wsman         HTTP operation (default 20). Note that operation timeouts while receiving output         (the only wsman operation that should take any significant time,         and where these timeouts are expected) will be silently retried indefinitely.     :type operation_timeout_sec: int     :param kerberos_hostname_override: the hostname to use for the kerberos exchange         (defaults to the hostname in the endpoint URL)     :type kerberos_hostname_override: str     :param message_encryption: Will encrypt the WinRM messages if set         and the transport auth supports message encryption. (Default 'auto')     :type message_encryption: str     :param credssp_disable_tlsv1_2: Whether to disable TLSv1.2 support and work with older         protocols like TLSv1.0, default is False     :type credssp_disable_tlsv1_2: bool     :param send_cbt: Will send the channel bindings over a HTTPS channel (Default: True)     :type send_cbt: bool     """ [1171,4347]
===
delete-node
---
name: getpass [9522,9529]
===
===
delete-node
---
trailer [9529,9537]
===
