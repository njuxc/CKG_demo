===
match
---
parameters [2588,2672]
parameters [2588,2672]
===
match
---
name: running_slots [5820,5833]
name: running_slots [5835,5848]
===
match
---
operator: = [3321,3322]
operator: = [3321,3322]
===
match
---
operator: , [3423,3424]
operator: , [3423,3424]
===
match
---
operator: -> [6978,6980]
operator: -> [7023,7025]
===
match
---
name: count [4357,4362]
name: count [4357,4362]
===
match
---
operator: , [5257,5258]
operator: , [5257,5258]
===
match
---
funcdef [5816,6353]
funcdef [5831,6383]
===
match
---
operator: = [2519,2520]
operator: = [2519,2520]
===
match
---
dotted_name [1098,1119]
dotted_name [1098,1119]
===
match
---
operator: , [3651,3652]
operator: , [3651,3652]
===
match
---
trailer [3836,3860]
trailer [3836,3860]
===
match
---
decorators [2534,2569]
decorators [2534,2569]
===
match
---
atom_expr [3490,3505]
atom_expr [3490,3505]
===
match
---
name: Iterable [813,821]
name: Iterable [813,821]
===
match
---
name: Base [1434,1438]
name: Base [1434,1438]
===
match
---
simple_stmt [1914,2132]
simple_stmt [1914,2132]
===
match
---
name: filter [6220,6226]
name: filter [6238,6244]
===
match
---
name: float [7197,7202]
name: float [7242,7247]
===
match
---
operator: @ [1817,1818]
operator: @ [1817,1818]
===
match
---
return_stmt [5053,5207]
return_stmt [5053,5207]
===
match
---
atom_expr [5728,5750]
atom_expr [5731,5753]
===
match
---
name: float [6981,6986]
name: float [7026,7031]
===
match
---
parameters [6395,6419]
parameters [6425,6449]
===
match
---
simple_stmt [4939,5045]
simple_stmt [4939,5045]
===
match
---
dotted_name [904,926]
dotted_name [904,926]
===
match
---
name: Pool [2161,2165]
name: Pool [2161,2165]
===
match
---
operator: { [3303,3304]
operator: { [3303,3304]
===
match
---
comparison [2174,2196]
comparison [2174,2196]
===
match
---
simple_stmt [2305,2459]
simple_stmt [2305,2459]
===
match
---
suite [5858,6353]
suite [5873,6383]
===
match
---
string: "queued" [4426,4434]
string: "queued" [4426,4434]
===
match
---
operator: @ [2534,2535]
operator: @ [2534,2535]
===
match
---
operator: , [3499,3500]
operator: , [3499,3500]
===
match
---
trailer [6888,6895]
trailer [6921,6928]
===
match
---
classdef [1423,7285]
classdef [1423,7330]
===
match
---
name: Session [2280,2287]
name: Session [2280,2287]
===
match
---
number: 256 [1581,1584]
number: 256 [1581,1584]
===
match
---
simple_stmt [5286,5468]
simple_stmt [5286,5468]
===
match
---
operator: = [3649,3650]
operator: = [3649,3650]
===
match
---
trailer [3284,3300]
trailer [3284,3300]
===
match
---
if_stmt [4657,4885]
if_stmt [4657,4885]
===
match
---
parameters [1749,1755]
parameters [1749,1755]
===
match
---
expr_stmt [1560,1599]
expr_stmt [1560,1599]
===
match
---
tfpdef [6960,6976]
tfpdef [7005,7021]
===
match
---
name: self [1776,1780]
name: self [1776,1780]
===
match
---
name: Pool [3337,3341]
name: Pool [3337,3341]
===
match
---
trailer [6780,6787]
trailer [6813,6820]
===
match
---
name: airflow [1192,1199]
name: airflow [1192,1199]
===
match
---
trailer [3719,3793]
trailer [3719,3793]
===
match
---
name: func [894,898]
name: func [894,898]
===
match
---
operator: ** [3442,3444]
operator: ** [3442,3444]
===
match
---
name: TaskInstance [6651,6663]
name: TaskInstance [6681,6693]
===
match
---
name: group_by [3875,3883]
name: group_by [3875,3883]
===
match
---
decorated [5213,5790]
decorated [5213,5805]
===
match
---
trailer [5652,5684]
trailer [5655,5687]
===
match
---
name: queued [1395,1401]
name: queued [1395,1401]
===
match
---
name: stats_dict [4818,4828]
name: stats_dict [4818,4828]
===
match
---
operator: } [5206,5207]
operator: } [5206,5207]
===
match
---
name: stats_dict [4616,4626]
name: stats_dict [4616,4626]
===
match
---
decorators [1817,1852]
decorators [1817,1852]
===
match
---
name: primary_key [1538,1549]
name: primary_key [1538,1549]
===
match
---
atom_expr [4630,4643]
atom_expr [4630,4643]
===
match
---
name: TypedDict [1127,1136]
name: TypedDict [1127,1136]
===
match
---
argument [1587,1598]
argument [1587,1598]
===
match
---
operator: , [5196,5197]
operator: , [5196,5197]
===
match
---
trailer [6754,6765]
trailer [6787,6798]
===
match
---
trailer [6839,6875]
trailer [6872,6908]
===
match
---
trailer [5665,5670]
trailer [5668,5673]
===
match
---
trailer [2173,2197]
trailer [2173,2197]
===
match
---
fstring_string: . [4556,4557]
fstring_string: . [4556,4557]
===
match
---
name: Tuple [833,838]
name: Tuple [833,838]
===
match
---
string: """         Get the number of slots used by running tasks at the moment.          :param session: SQLAlchemy ORM Session         :return: the used number of slots         """ [5867,6041]
string: """         Get the number of slots used by running tasks at the moment.          :param session: SQLAlchemy ORM Session         :return: the used number of slots         """ [5882,6056]
===
match
---
string: 'slots' [5132,5139]
string: 'slots' [5132,5139]
===
match
---
parameters [6953,6977]
parameters [6998,7022]
===
match
---
name: Integer [1641,1648]
name: Integer [1641,1648]
===
match
---
operator: , [821,822]
operator: , [821,822]
===
match
---
string: "total" [4671,4678]
string: "total" [4671,4678]
===
match
---
simple_stmt [2706,3178]
simple_stmt [2706,3178]
===
match
---
name: state [5718,5723]
name: state [5721,5726]
===
match
---
trailer [6226,6258]
trailer [6244,6276]
===
match
---
name: pool_name [3534,3543]
name: pool_name [3534,3543]
===
match
---
operator: , [5151,5152]
operator: , [5151,5152]
===
match
---
simple_stmt [788,839]
simple_stmt [788,839]
===
match
---
simple_stmt [5476,5554]
simple_stmt [5476,5554]
===
match
---
trailer [3417,3460]
trailer [3417,3460]
===
match
---
name: TaskInstance [3739,3751]
name: TaskInstance [3739,3751]
===
match
---
operator: , [5838,5839]
operator: , [5853,5854]
===
match
---
for_stmt [4014,4560]
for_stmt [4014,4560]
===
match
---
string: "queued" [4389,4397]
string: "queued" [4389,4397]
===
match
---
name: TypedDict [1303,1312]
name: TypedDict [1303,1312]
===
match
---
name: session [1156,1163]
name: session [1156,1163]
===
match
---
name: session [3323,3330]
name: session [3323,3330]
===
match
---
atom_expr [3444,3459]
atom_expr [3444,3459]
===
match
---
operator: @ [2211,2212]
operator: @ [2211,2212]
===
match
---
simple_stmt [6137,6353]
simple_stmt [6152,6383]
===
match
---
annassign [4090,4134]
annassign [4090,4134]
===
match
---
trailer [4119,4123]
trailer [4119,4123]
===
match
---
atom_expr [2474,2528]
atom_expr [2474,2528]
===
match
---
simple_stmt [3315,3360]
simple_stmt [3315,3360]
===
match
---
name: Pool [1429,1433]
name: Pool [1429,1433]
===
match
---
atom_expr [4739,4757]
atom_expr [4739,4757]
===
match
---
simple_stmt [1445,1479]
simple_stmt [1445,1479]
===
match
---
name: self [5834,5838]
name: self [5849,5853]
===
match
---
operator: - [7174,7175]
operator: - [7219,7220]
===
match
---
name: taskinstance [3206,3218]
name: taskinstance [3206,3218]
===
match
---
name: query [3509,3514]
name: query [3509,3514]
===
match
---
name: provide_session [6359,6374]
name: provide_session [6389,6404]
===
match
---
or_test [6144,6352]
or_test [6176,6372]
===
match
---
trailer [7164,7170]
trailer [7209,7215]
===
match
---
trailer [6335,6337]
trailer [6353,6355]
===
match
---
name: self [6809,6813]
name: self [6842,6846]
===
match
---
string: """Dictionary containing Pool Stats""" [1319,1357]
string: """Dictionary containing Pool Stats""" [1319,1357]
===
match
---
name: utils [1200,1205]
name: utils [1200,1205]
===
match
---
trailer [3932,3936]
trailer [3932,3936]
===
match
---
decorated [2534,4907]
decorated [2534,4907]
===
match
---
trailer [3915,3921]
trailer [3915,3921]
===
match
---
operator: = [1520,1521]
operator: = [1520,1521]
===
match
---
argument [3643,3651]
argument [3643,3651]
===
match
---
name: session [6960,6967]
name: session [7005,7012]
===
match
---
simple_stmt [899,942]
simple_stmt [899,942]
===
match
---
operator: = [3618,3619]
operator: = [3618,3619]
===
match
---
decorator [2552,2569]
decorator [2552,2569]
===
match
---
name: provide_session [1836,1851]
name: provide_session [1836,1851]
===
match
---
simple_stmt [5563,5790]
simple_stmt [5563,5805]
===
match
---
subscriptlist [2681,2695]
subscriptlist [2681,2695]
===
match
---
trailer [6193,6204]
trailer [6211,6222]
===
match
---
name: Dict [3280,3284]
name: Dict [3280,3284]
===
match
---
factor [4760,4762]
factor [4760,4762]
===
match
---
atom_expr [6733,6766]
atom_expr [6766,6799]
===
match
---
trailer [5678,5683]
trailer [5681,5686]
===
match
---
for_stmt [4601,4885]
for_stmt [4601,4885]
===
match
---
trailer [7275,7284]
trailer [7320,7329]
===
match
---
name: DEFAULT_POOL_NAME [2493,2510]
name: DEFAULT_POOL_NAME [2493,2510]
===
match
---
operator: , [4028,4029]
operator: , [4028,4029]
===
match
---
suite [4930,5208]
suite [4930,5208]
===
match
---
name: Session [6411,6418]
name: Session [6441,6448]
===
match
---
operator: * [2598,2599]
operator: * [2598,2599]
===
match
---
name: state_count_by_pool [4047,4066]
name: state_count_by_pool [4047,4066]
===
match
---
operator: = [4112,4113]
operator: = [4112,4113]
===
match
---
expr_stmt [4739,4762]
expr_stmt [4739,4762]
===
match
---
operator: @ [5213,5214]
operator: @ [5213,5214]
===
match
---
name: lock_rows [3372,3381]
name: lock_rows [3372,3381]
===
match
---
name: provide_session [2230,2245]
name: provide_session [2230,2245]
===
match
---
name: session [6158,6165]
name: session [6176,6183]
===
match
---
name: to_json [4916,4923]
name: to_json [4916,4923]
===
match
---
atom_expr [3759,3792]
atom_expr [3759,3792]
===
match
---
name: Session [934,941]
name: Session [934,941]
===
match
---
param [5253,5258]
param [5253,5258]
===
match
---
trailer [4100,4111]
trailer [4100,4111]
===
match
---
trailer [3751,3757]
trailer [3751,3757]
===
match
---
import_from [943,990]
import_from [943,990]
===
match
---
expr_stmt [1626,1660]
expr_stmt [1626,1660]
===
match
---
trailer [5704,5752]
trailer [5707,5755]
===
match
---
trailer [2166,2173]
trailer [2166,2173]
===
match
---
atom_expr [1522,1555]
atom_expr [1522,1555]
===
match
---
name: State [6301,6306]
name: State [6319,6324]
===
match
---
parameters [4923,4929]
parameters [4923,4929]
===
match
---
comparison [4660,4685]
comparison [4660,4685]
===
match
---
simple_stmt [1697,1732]
simple_stmt [1697,1732]
===
match
---
simple_stmt [4894,4907]
simple_stmt [4894,4907]
===
match
---
return_stmt [7190,7209]
return_stmt [7235,7254]
===
match
---
atom_expr [3739,3757]
atom_expr [3739,3757]
===
match
---
funcdef [4912,5208]
funcdef [4912,5208]
===
match
---
name: in_ [3833,3836]
name: in_ [3833,3836]
===
match
---
name: TaskInstance [6090,6102]
name: TaskInstance [6105,6117]
===
match
---
name: nowait [3444,3450]
name: nowait [3444,3450]
===
match
---
param [6954,6959]
param [6999,7004]
===
match
---
return_stmt [5563,5789]
return_stmt [5563,5804]
===
match
---
name: stats_dict [4797,4807]
name: stats_dict [4797,4807]
===
match
---
simple_stmt [1765,1812]
simple_stmt [1765,1812]
===
match
---
simple_stmt [1247,1285]
simple_stmt [1247,1285]
===
match
---
name: unique [1587,1593]
name: unique [1587,1593]
===
match
---
fstring_string: Unexpected state. Expected values:  [4503,4538]
fstring_string: Unexpected state. Expected values:  [4503,4538]
===
match
---
atom_expr [4660,4679]
atom_expr [4660,4679]
===
match
---
operator: , [3288,3289]
operator: , [3288,3289]
===
match
---
operator: = [2659,2660]
operator: = [2659,2660]
===
match
---
name: utils [1260,1265]
name: utils [1260,1265]
===
match
---
name: __tablename__ [1484,1497]
name: __tablename__ [1484,1497]
===
match
---
string: 'inf' [7203,7208]
string: 'inf' [7248,7253]
===
match
---
name: session [3433,3440]
name: session [3433,3440]
===
match
---
name: Iterable [3481,3489]
name: Iterable [3481,3489]
===
match
---
name: str [2681,2684]
name: str [2681,2684]
===
match
---
decorated [6358,6913]
decorated [6388,6958]
===
match
---
return_stmt [6137,6352]
return_stmt [6152,6382]
===
match
---
name: list [5728,5732]
name: list [5731,5735]
===
match
---
name: pool_name [4019,4028]
name: pool_name [4019,4028]
===
match
---
funcdef [5234,5790]
funcdef [5234,5805]
===
match
---
funcdef [2250,2529]
funcdef [2250,2529]
===
match
---
tfpdef [2271,2287]
tfpdef [2271,2287]
===
match
---
name: filter [2167,2173]
name: filter [2167,2173]
===
match
---
name: pool_name [4605,4614]
name: pool_name [4605,4614]
===
match
---
name: TaskInstance [5705,5717]
name: TaskInstance [5708,5720]
===
match
---
operator: , [2684,2685]
operator: , [2684,2685]
===
match
---
string: """         Get the number of slots used by queued tasks at the moment.          :param session: SQLAlchemy ORM Session         :return: the used number of slots         """ [6429,6602]
string: """         Get the number of slots used by queued tasks at the moment.          :param session: SQLAlchemy ORM Session         :return: the used number of slots         """ [6459,6632]
===
match
---
name: exceptions [956,966]
name: exceptions [956,966]
===
match
---
simple_stmt [4080,4135]
simple_stmt [4080,4135]
===
match
---
operator: = [4436,4437]
operator: = [4436,4437]
===
match
---
name: self [1750,1754]
name: self [1750,1754]
===
match
---
name: str [1772,1775]
name: str [1772,1775]
===
match
---
expr_stmt [3273,3305]
expr_stmt [3273,3305]
===
match
---
annassign [1401,1406]
annassign [1401,1406]
===
match
---
operator: } [4555,4556]
operator: } [4555,4556]
===
match
---
expr_stmt [3995,4005]
expr_stmt [3995,4005]
===
match
---
name: String [880,886]
name: String [880,886]
===
match
---
simple_stmt [6996,7149]
simple_stmt [7041,7194]
===
match
---
simple_stmt [3273,3306]
simple_stmt [3273,3306]
===
match
---
expr_stmt [1378,1390]
expr_stmt [1378,1390]
===
match
---
name: session [5584,5591]
name: session [5587,5594]
===
match
---
comparison [4380,4397]
comparison [4380,4397]
===
match
---
operator: = [2625,2626]
operator: = [2625,2626]
===
match
---
name: Text [1686,1690]
name: Text [1686,1690]
===
match
---
trailer [3936,3938]
trailer [3936,3938]
===
match
---
tfpdef [5840,5856]
tfpdef [5855,5871]
===
match
---
annassign [4000,4005]
annassign [4000,4005]
===
match
---
expr_stmt [3470,3520]
expr_stmt [3470,3520]
===
match
---
operator: = [1715,1716]
operator: = [1715,1716]
===
match
---
trailer [5606,5631]
trailer [5609,5634]
===
match
---
trailer [6278,6315]
trailer [6296,6333]
===
match
---
name: count [4037,4042]
name: count [4037,4042]
===
match
---
trailer [6895,6897]
trailer [6928,6930]
===
match
---
arglist [3613,3659]
arglist [3613,3659]
===
match
---
trailer [3806,3813]
trailer [3806,3813]
===
match
---
name: get_default_pool [2254,2270]
name: get_default_pool [2254,2270]
===
match
---
name: TaskInstance [3720,3732]
name: TaskInstance [3720,3732]
===
match
---
trailer [6219,6226]
trailer [6237,6244]
===
match
---
name: airflow [996,1003]
name: airflow [996,1003]
===
match
---
trailer [6176,6180]
trailer [6194,6198]
===
match
---
trailer [4500,4559]
trailer [4500,4559]
===
match
---
atom_expr [4818,4837]
atom_expr [4818,4837]
===
match
---
operator: = [1549,1550]
operator: = [1549,1550]
===
match
---
name: TaskInstance [6742,6754]
name: TaskInstance [6775,6787]
===
match
---
return_stmt [2140,2205]
return_stmt [2140,2205]
===
match
---
name: models [6624,6630]
name: models [6654,6660]
===
match
---
suite [7177,7210]
suite [7222,7255]
===
match
---
argument [3613,3630]
argument [3613,3630]
===
match
---
number: 0 [3658,3659]
number: 0 [3658,3659]
===
match
---
trailer [3341,3346]
trailer [3341,3346]
===
match
---
atom_expr [5180,5196]
atom_expr [5180,5196]
===
match
---
atom [5060,5207]
atom [5060,5207]
===
match
---
atom_expr [3814,3860]
atom_expr [3814,3860]
===
match
---
name: taskinstance [5496,5508]
name: taskinstance [5496,5508]
===
match
---
comparison [7160,7176]
comparison [7205,7221]
===
match
---
name: self [6954,6958]
name: self [6999,7003]
===
match
---
import_from [5476,5528]
import_from [5476,5528]
===
match
---
name: open_slots [6943,6953]
name: open_slots [6988,6998]
===
match
---
name: all [3515,3518]
name: all [3515,3518]
===
match
---
simple_stmt [4333,4363]
simple_stmt [4333,4363]
===
match
---
suite [4165,4191]
suite [4165,4191]
===
match
---
name: models [6063,6069]
name: models [6078,6084]
===
match
---
name: queued_slots [6383,6395]
name: queued_slots [6413,6425]
===
match
---
trailer [4807,4815]
trailer [4807,4815]
===
match
---
operator: @ [2229,2230]
operator: @ [2229,2230]
===
match
---
name: open [1411,1415]
name: open [1411,1415]
===
match
---
number: 1 [4761,4762]
number: 1 [4761,4762]
===
match
---
arglist [1641,1659]
arglist [1641,1659]
===
match
---
name: pool_slots [5620,5630]
name: pool_slots [5623,5633]
===
match
---
decorator [1817,1831]
decorator [1817,1831]
===
match
---
name: with_row_locks [1232,1246]
name: with_row_locks [1232,1246]
===
match
---
operator: = [4355,4356]
operator: = [4355,4356]
===
match
---
trailer [6171,6206]
trailer [6189,6224]
===
match
---
name: pools [4901,4906]
name: pools [4901,4906]
===
match
---
operator: = [3601,3602]
operator: = [3601,3602]
===
match
---
return_stmt [7236,7284]
return_stmt [7281,7329]
===
match
---
trailer [7202,7209]
trailer [7247,7254]
===
match
---
name: id [1517,1519]
name: id [1517,1519]
===
match
---
number: 1 [4684,4685]
number: 1 [4684,4685]
===
match
---
name: filter [5646,5652]
name: filter [5649,5655]
===
match
---
name: scalar [6329,6335]
name: scalar [6347,6353]
===
match
---
operator: = [3639,3640]
operator: = [3639,3640]
===
match
---
name: session [5840,5847]
name: session [5855,5862]
===
match
---
dotted_name [3191,3218]
dotted_name [3191,3218]
===
match
---
name: EXECUTION_STATES [3842,3858]
name: EXECUTION_STATES [3842,3858]
===
match
---
atom_expr [3481,3506]
atom_expr [3481,3506]
===
match
---
trailer [6732,6767]
trailer [6765,6800]
===
match
---
atom_expr [2147,2205]
atom_expr [2147,2205]
===
match
---
name: int [1403,1406]
name: int [1403,1406]
===
match
---
name: Pool [2488,2492]
name: Pool [2488,2492]
===
match
---
atom_expr [6158,6337]
atom_expr [6176,6355]
===
match
---
funcdef [6939,7285]
funcdef [6984,7330]
===
match
---
factor [7174,7176]
factor [7219,7221]
===
match
---
expr_stmt [1484,1511]
expr_stmt [1484,1511]
===
match
---
trailer [7247,7253]
trailer [7292,7298]
===
match
---
dotted_name [1252,1271]
dotted_name [1252,1271]
===
match
---
trailer [6291,6297]
trailer [6309,6315]
===
match
---
atom_expr [6788,6805]
atom_expr [6821,6838]
===
match
---
dotted_name [6616,6643]
dotted_name [6646,6673]
===
match
---
simple_stmt [4415,4444]
simple_stmt [4415,4444]
===
match
---
name: PoolStats [2686,2695]
name: PoolStats [2686,2695]
===
match
---
name: session [2147,2154]
name: session [2147,2154]
===
match
---
name: int [3501,3504]
name: int [3501,3504]
===
match
---
name: Column [863,869]
name: Column [863,869]
===
match
---
operator: , [3346,3347]
operator: , [3346,3347]
===
match
---
if_stmt [7157,7285]
if_stmt [7202,7330]
===
match
---
param [1869,1879]
param [1869,1879]
===
match
---
simple_stmt [7236,7285]
simple_stmt [7281,7330]
===
match
---
name: pool [3897,3901]
name: pool [3897,3901]
===
match
---
name: self [6248,6252]
name: self [6266,6270]
===
match
---
atom_expr [4114,4134]
atom_expr [4114,4134]
===
match
---
trailer [1685,1691]
trailer [1685,1691]
===
match
---
atom_expr [3584,3600]
atom_expr [3584,3600]
===
match
---
name: state [3916,3921]
name: state [3916,3921]
===
match
---
suite [3382,3461]
suite [3382,3461]
===
match
---
atom_expr [1772,1786]
atom_expr [1772,1786]
===
match
---
import_from [788,838]
import_from [788,838]
===
match
---
name: provide_session [5214,5229]
name: provide_session [5214,5229]
===
match
---
dotted_name [1033,1068]
dotted_name [1033,1068]
===
match
---
trailer [6852,6858]
trailer [6885,6891]
===
match
---
tfpdef [5259,5275]
tfpdef [5259,5275]
===
match
---
name: count [3995,4000]
name: count [3995,4000]
===
match
---
suite [1440,7285]
suite [1440,7330]
===
match
---
name: query [3395,3400]
name: query [3395,3400]
===
match
---
name: Pool [3348,3352]
name: Pool [3348,3352]
===
match
---
parameters [1868,1904]
parameters [1868,1904]
===
match
---
name: session [2520,2527]
name: session [2520,2527]
===
match
---
return_stmt [6698,6912]
return_stmt [6728,6957]
===
match
---
decorator [6358,6375]
decorator [6388,6405]
===
match
---
name: session [3706,3713]
name: session [3706,3713]
===
match
---
operator: == [7171,7173]
operator: == [7216,7218]
===
match
---
dotted_name [948,966]
dotted_name [948,966]
===
match
---
string: 'description' [5165,5178]
string: 'description' [5165,5178]
===
match
---
trailer [2197,2203]
trailer [2197,2203]
===
match
---
name: QUEUED [6868,6874]
name: QUEUED [6901,6907]
===
match
---
dotted_name [1142,1163]
dotted_name [1142,1163]
===
match
---
name: id [5085,5087]
name: id [5085,5087]
===
match
---
suite [5277,5790]
suite [5277,5805]
===
match
---
atom_expr [4840,4861]
atom_expr [4840,4861]
===
match
---
name: total [1363,1368]
name: total [1363,1368]
===
match
---
name: func [6172,6176]
name: func [6190,6194]
===
match
---
simple_stmt [1363,1374]
simple_stmt [1363,1374]
===
match
---
simple_stmt [5867,6042]
simple_stmt [5882,6057]
===
match
---
name: get [4120,4123]
name: get [4120,4123]
===
match
---
name: pool [6814,6818]
name: pool [6847,6851]
===
match
---
trailer [3495,3505]
trailer [3495,3505]
===
match
---
parameters [5252,5276]
parameters [5252,5276]
===
match
---
trailer [4635,4641]
trailer [4635,4641]
===
match
---
trailer [2160,2166]
trailer [2160,2166]
===
match
---
operator: , [2665,2666]
operator: , [2665,2666]
===
match
---
name: taskinstance [6070,6082]
name: taskinstance [6085,6097]
===
match
---
atom_expr [2676,2696]
atom_expr [2676,2696]
===
match
---
name: session [6719,6726]
name: session [6752,6759]
===
match
---
string: "running" [4344,4353]
string: "running" [4344,4353]
===
match
---
subscriptlist [3285,3299]
subscriptlist [3285,3299]
===
match
---
atom_expr [6840,6858]
atom_expr [6873,6891]
===
match
---
simple_stmt [840,899]
simple_stmt [840,899]
===
match
---
import_from [899,941]
import_from [899,941]
===
match
---
operator: - [4683,4684]
operator: - [4683,4684]
===
match
---
operator: = [3432,3433]
operator: = [3432,3433]
===
match
---
subscriptlist [3496,3504]
subscriptlist [3496,3504]
===
match
---
suite [4644,4885]
suite [4644,4885]
===
match
---
simple_stmt [5053,5208]
simple_stmt [5053,5208]
===
match
---
expr_stmt [1363,1373]
expr_stmt [1363,1373]
===
match
---
operator: @ [2552,2553]
operator: @ [2552,2553]
===
match
---
name: with_row_locks [3403,3417]
name: with_row_locks [3403,3417]
===
match
---
string: "queued" [4875,4883]
string: "queued" [4875,4883]
===
match
---
comparison [6227,6257]
comparison [6245,6275]
===
match
---
atom [3303,3305]
atom [3303,3305]
===
match
---
name: get_pool [1860,1868]
name: get_pool [1860,1868]
===
match
---
trailer [1775,1786]
trailer [1775,1786]
===
match
---
simple_stmt [1411,1421]
simple_stmt [1411,1421]
===
match
---
name: scalar [5766,5772]
name: scalar [5769,5775]
===
match
---
arglist [1529,1554]
arglist [1529,1554]
===
match
---
expr_stmt [3315,3359]
expr_stmt [3315,3359]
===
match
---
simple_stmt [991,1028]
simple_stmt [991,1028]
===
match
---
name: self [7160,7164]
name: self [7205,7209]
===
match
---
if_stmt [4147,4191]
if_stmt [4147,4191]
===
match
---
param [5834,5839]
param [5849,5854]
===
match
---
name: int [1417,1420]
name: int [1417,1420]
===
match
---
funcdef [6379,6913]
funcdef [6409,6958]
===
match
---
trailer [6306,6314]
trailer [6324,6332]
===
match
---
atom_expr [5607,5630]
atom_expr [5610,5633]
===
match
---
simple_stmt [4182,4191]
simple_stmt [4182,4191]
===
match
---
name: query [6166,6171]
name: query [6184,6189]
===
match
---
operator: , [1536,1537]
operator: , [1536,1537]
===
match
---
operator: == [5671,5673]
operator: == [5674,5676]
===
match
---
or_test [6705,6912]
or_test [6752,6947]
===
match
---
trailer [6813,6818]
trailer [6846,6851]
===
match
---
atom_expr [5674,5683]
atom_expr [5677,5686]
===
match
---
arith_expr [4818,4884]
arith_expr [4818,4884]
===
match
---
operator: == [4303,4305]
operator: == [4303,4305]
===
match
---
dotted_name [1192,1216]
dotted_name [1192,1216]
===
match
---
name: stats_dict [4660,4670]
name: stats_dict [4660,4670]
===
match
---
comparison [6840,6874]
comparison [6873,6907]
===
match
---
name: pool [3733,3737]
name: pool [3733,3737]
===
match
---
name: staticmethod [1818,1830]
name: staticmethod [1818,1830]
===
match
---
import_as_names [1224,1246]
import_as_names [1224,1246]
===
match
---
operator: @ [6358,6359]
operator: @ [6388,6389]
===
match
---
name: PoolStats [3290,3299]
name: PoolStats [3290,3299]
===
match
---
name: airflow [6055,6062]
name: airflow [6070,6077]
===
match
---
name: slots [7165,7170]
name: slots [7210,7215]
===
match
---
operator: , [6958,6959]
operator: , [7003,7004]
===
match
---
atom_expr [4333,4354]
atom_expr [4333,4354]
===
match
---
name: TaskInstance [6227,6239]
name: TaskInstance [6245,6257]
===
match
---
name: Session [5849,5856]
name: Session [5864,5871]
===
match
---
operator: == [2184,2186]
operator: == [2184,2186]
===
match
---
name: session [919,926]
name: session [919,926]
===
match
---
if_stmt [3369,3461]
if_stmt [3369,3461]
===
match
---
name: pool [6240,6244]
name: pool [6258,6262]
===
match
---
operator: , [3737,3738]
operator: , [3737,3738]
===
match
---
argument [1650,1659]
argument [1650,1659]
===
match
---
simple_stmt [1626,1661]
simple_stmt [1626,1661]
===
match
---
expr_stmt [1665,1691]
expr_stmt [1665,1691]
===
match
---
param [1880,1903]
param [1880,1903]
===
match
---
name: pool [2179,2183]
name: pool [2179,2183]
===
match
---
name: sqlalchemy [1206,1216]
name: sqlalchemy [1206,1216]
===
match
---
import_from [1093,1136]
import_from [1093,1136]
===
match
---
name: airflow [1033,1040]
name: airflow [1033,1040]
===
match
---
suite [2296,2529]
suite [2296,2529]
===
match
---
name: self [4924,4928]
name: self [4924,4928]
===
match
---
operator: = [3507,3508]
operator: = [3507,3508]
===
match
---
simple_stmt [1517,1556]
simple_stmt [1517,1556]
===
match
---
name: filter [6781,6787]
name: filter [6814,6820]
===
match
---
arglist [2488,2527]
arglist [2488,2527]
===
match
---
trailer [1580,1585]
trailer [1580,1585]
===
match
---
arith_expr [7243,7284]
arith_expr [7288,7329]
===
match
---
name: TaskInstance [3884,3896]
name: TaskInstance [3884,3896]
===
match
---
atom_expr [5109,5118]
atom_expr [5109,5118]
===
match
---
name: sum [3764,3767]
name: sum [3764,3767]
===
match
---
decorator [5213,5230]
decorator [5213,5230]
===
match
---
atom_expr [5584,5774]
atom_expr [5587,5777]
===
match
---
trailer [5084,5087]
trailer [5084,5087]
===
match
---
trailer [5184,5196]
trailer [5184,5196]
===
match
---
decorator [5795,5812]
decorator [5810,5827]
===
match
---
funcdef [1737,1812]
funcdef [1737,1812]
===
match
---
atom_expr [2174,2183]
atom_expr [2174,2183]
===
match
---
name: session [6402,6409]
name: session [6432,6439]
===
match
---
name: TaskInstance [6788,6800]
name: TaskInstance [6821,6833]
===
match
---
name: pools [4114,4119]
name: pools [4114,4119]
===
match
---
name: description [1665,1676]
name: description [1665,1676]
===
match
---
operator: { [4538,4539]
operator: { [4538,4539]
===
match
---
import_from [840,898]
import_from [840,898]
===
match
---
name: Column [1634,1640]
name: Column [1634,1640]
===
match
---
trailer [3612,3660]
trailer [3612,3660]
===
match
---
atom_expr [6719,6897]
atom_expr [6752,6930]
===
match
---
trailer [6800,6805]
trailer [6833,6838]
===
match
---
name: pool_name [1869,1878]
name: pool_name [1869,1878]
===
match
---
name: state [4030,4035]
name: state [4030,4035]
===
match
---
trailer [3813,3861]
trailer [3813,3861]
===
match
---
trailer [4749,4757]
trailer [4749,4757]
===
match
---
param [1750,1754]
param [1750,1754]
===
match
---
name: PoolStats [1293,1302]
name: PoolStats [1293,1302]
===
match
---
trailer [6787,6819]
trailer [6820,6852]
===
match
---
annassign [1415,1420]
annassign [1415,1420]
===
match
---
name: query [3315,3320]
name: query [3315,3320]
===
match
---
trailer [1573,1599]
trailer [1573,1599]
===
match
---
trailer [5765,5772]
trailer [5768,5775]
===
match
---
name: RUNNING [6307,6314]
name: RUNNING [6325,6332]
===
match
---
param [2642,2666]
param [2642,2666]
===
match
---
simple_stmt [6611,6689]
simple_stmt [6641,6719]
===
match
---
name: total_slots [3619,3630]
name: total_slots [3619,3630]
===
match
---
name: models [5489,5495]
name: models [5489,5495]
===
match
---
name: airflow [6616,6623]
name: airflow [6646,6653]
===
match
---
import_from [1187,1246]
import_from [1187,1246]
===
match
---
atom_expr [7160,7170]
atom_expr [7205,7215]
===
match
---
atom_expr [1567,1599]
atom_expr [1567,1599]
===
match
---
operator: , [1585,1586]
operator: , [1585,1586]
===
match
---
name: pool [1781,1785]
name: pool [1781,1785]
===
match
---
trailer [3352,3358]
trailer [3352,3358]
===
match
---
name: default [1650,1657]
name: default [1650,1657]
===
match
---
name: state [1266,1271]
name: state [1266,1271]
===
match
---
trailer [6165,6171]
trailer [6183,6189]
===
match
---
operator: , [5087,5088]
operator: , [5087,5088]
===
match
---
atom_expr [6742,6765]
atom_expr [6775,6798]
===
match
---
name: query [3418,3423]
name: query [3418,3423]
===
match
---
name: pool_slots [6194,6204]
name: pool_slots [6212,6222]
===
match
---
name: TaskInstance [5607,5619]
name: TaskInstance [5610,5622]
===
match
---
string: 'default_pool' [1717,1731]
string: 'default_pool' [1717,1731]
===
match
---
param [5840,5856]
param [5855,5871]
===
match
---
string: """         Get Pool stats (Number of Running, Queued, Open & Total tasks)          If ``lock_rows`` is True, and the database engine in use supports the ``NOWAIT`` syntax, then a         non-blocking lock will be attempted -- if the lock is not available then SQLAlchemy will throw an         OperationalError.          :param lock_rows: Should we attempt to obtain a row-level lock on all the Pool rows returns         :param session: SQLAlchemy ORM Session         """ [2706,3177]
string: """         Get Pool stats (Number of Running, Queued, Open & Total tasks)          If ``lock_rows`` is True, and the database engine in use supports the ``NOWAIT`` syntax, then a         non-blocking lock will be attempted -- if the lock is not available then SQLAlchemy will throw an         OperationalError.          :param lock_rows: Should we attempt to obtain a row-level lock on all the Pool rows returns         :param session: SQLAlchemy ORM Session         """ [2706,3177]
===
match
---
operator: , [3901,3902]
operator: , [3901,3902]
===
match
---
tfpdef [6402,6418]
tfpdef [6432,6448]
===
match
---
atom_expr [7243,7253]
atom_expr [7288,7298]
===
match
---
name: slots [1626,1631]
name: slots [1626,1631]
===
match
---
trailer [3336,3359]
trailer [3336,3359]
===
match
---
name: list [3837,3841]
name: list [3837,3841]
===
match
---
operator: - [4862,4863]
operator: - [4862,4863]
===
match
---
trailer [6252,6257]
trailer [6270,6275]
===
match
---
import_from [3186,3238]
import_from [3186,3238]
===
match
---
exprlist [4605,4626]
exprlist [4605,4626]
===
match
---
name: state_count_by_pool [3670,3689]
name: state_count_by_pool [3670,3689]
===
match
---
expr_stmt [4415,4443]
expr_stmt [4415,4443]
===
match
---
name: TaskInstance [6840,6852]
name: TaskInstance [6873,6885]
===
match
---
parameters [5833,5857]
parameters [5848,5872]
===
match
---
atom_expr [3403,3460]
atom_expr [3403,3460]
===
match
---
name: get_pool [2479,2487]
name: get_pool [2479,2487]
===
match
---
name: TaskInstance [5653,5665]
name: TaskInstance [5656,5668]
===
match
---
name: slots_stats [2577,2588]
name: slots_stats [2577,2588]
===
match
---
name: pool_name [2187,2196]
name: pool_name [2187,2196]
===
match
---
atom_expr [3884,3901]
atom_expr [3884,3901]
===
match
---
name: Column [1679,1685]
name: Column [1679,1685]
===
match
---
arglist [1574,1598]
arglist [1574,1598]
===
match
---
name: open [3653,3657]
name: open [3653,3657]
===
match
---
name: Integer [1529,1536]
name: Integer [1529,1536]
===
match
---
name: Column [1567,1573]
name: Column [1567,1573]
===
match
---
name: filter [6833,6839]
name: filter [6866,6872]
===
match
---
trailer [3489,3506]
trailer [3489,3506]
===
match
---
name: session [7276,7283]
name: session [7321,7328]
===
match
---
name: bool [2620,2624]
name: bool [2620,2624]
===
match
---
atom [3692,3932]
atom [3692,3932]
===
match
---
name: filter [5698,5704]
name: filter [5701,5707]
===
match
---
name: state [6853,6858]
name: state [6886,6891]
===
match
---
trailer [6832,6839]
trailer [6865,6872]
===
match
---
simple_stmt [1665,1692]
simple_stmt [1665,1692]
===
match
---
operator: -> [2673,2675]
operator: -> [2673,2675]
===
match
---
operator: , [5118,5119]
operator: , [5118,5119]
===
match
---
simple_stmt [1187,1247]
simple_stmt [1187,1247]
===
match
---
name: pool [5679,5683]
name: pool [5682,5686]
===
match
---
suite [6420,6913]
suite [6450,6958]
===
match
---
operator: { [5060,5061]
operator: { [5060,5061]
===
match
---
simple_stmt [1137,1187]
simple_stmt [1137,1187]
===
match
---
name: self [5253,5257]
name: self [5253,5257]
===
match
---
name: occupied_slots [5238,5252]
name: occupied_slots [5238,5252]
===
match
---
atom_expr [3603,3660]
atom_expr [3603,3660]
===
match
---
trailer [5723,5727]
trailer [5726,5730]
===
match
---
tfpdef [2609,2624]
tfpdef [2609,2624]
===
match
---
name: sqlalchemy [904,914]
name: sqlalchemy [904,914]
===
match
---
string: "total" [4829,4836]
string: "total" [4829,4836]
===
match
---
atom_expr [2488,2510]
atom_expr [2488,2510]
===
match
---
name: Dict [2676,2680]
name: Dict [2676,2680]
===
match
---
name: TaskInstance [3814,3826]
name: TaskInstance [3814,3826]
===
match
---
name: slots [3353,3358]
name: slots [3353,3358]
===
match
---
name: staticmethod [2535,2547]
name: staticmethod [2535,2547]
===
match
---
name: stats_dict [4739,4749]
name: stats_dict [4739,4749]
===
match
---
trailer [4123,4134]
trailer [4123,4134]
===
match
---
param [4924,4928]
param [4924,4928]
===
match
---
expr_stmt [3670,3938]
expr_stmt [3670,3938]
===
match
---
name: occupied_slots [7261,7275]
name: occupied_slots [7306,7320]
===
match
---
decorator [1835,1852]
decorator [1835,1852]
===
match
---
if_stmt [4294,4560]
if_stmt [4294,4560]
===
match
---
name: PoolStats [4101,4110]
name: PoolStats [4101,4110]
===
match
---
param [2609,2633]
param [2609,2633]
===
match
---
import_from [6611,6663]
import_from [6641,6693]
===
match
---
dictorsetmaker [5074,5197]
dictorsetmaker [5074,5197]
===
match
---
number: 0 [3640,3641]
number: 0 [3640,3641]
===
match
---
name: self [7243,7247]
name: self [7288,7292]
===
match
---
name: state [4297,4302]
name: state [4297,4302]
===
match
---
name: session [1880,1887]
name: session [1880,1887]
===
match
---
name: Session [1889,1896]
name: Session [1889,1896]
===
match
---
operator: = [1632,1633]
operator: = [1632,1633]
===
match
---
simple_stmt [1560,1600]
simple_stmt [1560,1600]
===
match
---
name: nowait [1224,1230]
name: nowait [1224,1230]
===
match
---
tfpdef [2642,2658]
tfpdef [2642,2658]
===
match
---
trailer [2178,2183]
trailer [2178,2183]
===
match
---
name: pool_slots [3781,3791]
name: pool_slots [3781,3791]
===
match
---
name: provide_session [5796,5811]
name: provide_session [5811,5826]
===
match
---
string: """         Get the number of slots open at the moment.          :param session: SQLAlchemy ORM Session         :return: the number of slots         """ [6996,7148]
string: """         Get the number of slots open at the moment.          :param session: SQLAlchemy ORM Session         :return: the number of slots         """ [7041,7193]
===
match
---
fstring_start: f" [4501,4503]
fstring_start: f" [4501,4503]
===
match
---
name: provide_session [6919,6934]
name: provide_session [6964,6979]
===
match
---
suite [4686,4763]
suite [4686,4763]
===
match
---
simple_stmt [1484,1512]
simple_stmt [1484,1512]
===
match
---
expr_stmt [4797,4884]
expr_stmt [4797,4884]
===
match
---
operator: , [878,879]
operator: , [878,879]
===
match
---
operator: , [2599,2600]
operator: , [2599,2600]
===
match
---
name: self [5674,5678]
name: self [5677,5681]
===
match
---
name: state [6292,6297]
name: state [6310,6315]
===
match
---
trailer [5591,5597]
trailer [5594,5600]
===
match
---
tfpdef [1880,1896]
tfpdef [1880,1896]
===
match
---
atom_expr [3337,3346]
atom_expr [3337,3346]
===
match
---
name: models [1004,1010]
name: models [1004,1010]
===
match
---
atom_expr [3348,3358]
atom_expr [3348,3358]
===
match
---
name: running [3632,3639]
name: running [3632,3639]
===
match
---
decorated [5795,6353]
decorated [5810,6383]
===
match
---
operator: = [3657,3658]
operator: = [3657,3658]
===
match
---
simple_stmt [6050,6128]
simple_stmt [6065,6143]
===
match
---
suite [4461,4560]
suite [4461,4560]
===
match
---
fstring [4501,4558]
fstring [4501,4558]
===
match
---
operator: , [3630,3631]
operator: , [3630,3631]
===
match
---
argument [2512,2527]
argument [2512,2527]
===
match
---
name: session [5259,5266]
name: session [5259,5266]
===
match
---
string: 'id' [5074,5078]
string: 'id' [5074,5078]
===
match
---
name: TaskInstance [3903,3915]
name: TaskInstance [3903,3915]
===
match
---
simple_stmt [3670,3939]
simple_stmt [3670,3939]
===
match
---
operator: , [4035,4036]
operator: , [4035,4036]
===
match
---
operator: , [811,812]
operator: , [811,812]
===
match
---
simple_stmt [3470,3521]
simple_stmt [3470,3521]
===
match
---
annassign [3479,3520]
annassign [3479,3520]
===
match
---
funcdef [1856,2206]
funcdef [1856,2206]
===
match
---
operator: = [4758,4759]
operator: = [4758,4759]
===
match
---
or_test [5570,5789]
or_test [5587,5794]
===
match
---
name: int [1370,1373]
name: int [1370,1373]
===
match
---
decorator [2211,2225]
decorator [2211,2225]
===
match
---
name: PoolStats [3603,3612]
name: PoolStats [3603,3612]
===
match
---
argument [1538,1554]
argument [1538,1554]
===
match
---
simple_stmt [3186,3264]
simple_stmt [3186,3264]
===
match
---
name: pool [3342,3346]
name: pool [3342,3346]
===
match
---
import_from [1028,1092]
import_from [1028,1092]
===
match
---
suite [7223,7285]
suite [7268,7330]
===
match
---
trailer [5619,5630]
trailer [5622,5633]
===
match
---
atom_expr [5653,5670]
atom_expr [5656,5673]
===
match
---
operator: = [4816,4817]
operator: = [4816,4817]
===
match
---
name: str [3496,3499]
name: str [3496,3499]
===
match
---
simple_stmt [2467,2529]
simple_stmt [2467,2529]
===
match
---
operator: = [1498,1499]
operator: = [1498,1499]
===
match
---
name: session [2271,2278]
name: session [2271,2278]
===
match
---
name: TaskInstance [6181,6193]
name: TaskInstance [6199,6211]
===
match
---
operator: == [4386,4388]
operator: == [4386,4388]
===
match
---
trailer [2492,2510]
trailer [2492,2510]
===
match
---
trailer [2680,2696]
trailer [2680,2696]
===
match
---
suite [1905,2206]
suite [1905,2206]
===
match
---
name: stats_dict [4080,4090]
name: stats_dict [4080,4090]
===
match
---
comparison [6788,6818]
comparison [6821,6851]
===
match
---
name: airflow [3191,3198]
name: airflow [3191,3198]
===
match
---
dotted_name [5481,5508]
dotted_name [5481,5508]
===
match
---
atom_expr [3692,3938]
atom_expr [3692,3938]
===
match
---
string: 'pool' [5101,5107]
string: 'pool' [5101,5107]
===
match
---
trailer [4850,4861]
trailer [4850,4861]
===
match
---
trailer [3518,3520]
trailer [3518,3520]
===
match
---
expr_stmt [3584,3660]
expr_stmt [3584,3660]
===
match
---
atom_expr [4484,4559]
atom_expr [4484,4559]
===
match
---
name: self [5109,5113]
name: self [5109,5113]
===
match
---
suite [4780,4885]
suite [4780,4885]
===
match
---
name: session [3425,3432]
name: session [3425,3432]
===
match
---
name: TaskInstance [3226,3238]
name: TaskInstance [3226,3238]
===
match
---
suite [1314,1421]
suite [1314,1421]
===
match
---
atom_expr [6248,6257]
atom_expr [6266,6275]
===
match
---
suite [4067,4560]
suite [4067,4560]
===
match
---
for_stmt [3529,3661]
for_stmt [3529,3661]
===
match
---
name: count [4438,4443]
name: count [4438,4443]
===
match
---
suite [6987,7285]
suite [7032,7330]
===
match
---
name: ti_deps [1041,1048]
name: ti_deps [1041,1048]
===
match
---
trailer [6737,6741]
trailer [6770,6774]
===
match
---
atom_expr [3280,3300]
atom_expr [3280,3300]
===
match
---
atom_expr [3768,3791]
atom_expr [3768,3791]
===
match
---
string: "running" [4306,4315]
string: "running" [4306,4315]
===
match
---
name: state [4380,4385]
name: state [4380,4385]
===
match
---
decorator [6918,6935]
decorator [6963,6980]
===
match
---
arglist [3337,3358]
arglist [3337,3358]
===
match
---
operator: == [4680,4682]
operator: == [4680,4682]
===
match
---
annassign [1385,1390]
annassign [1385,1390]
===
match
---
operator: @ [5795,5796]
operator: @ [5810,5811]
===
match
---
name: sum [6177,6180]
name: sum [6195,6198]
===
match
---
name: pool_slots [6755,6765]
name: pool_slots [6788,6798]
===
match
---
name: pool_rows [3561,3570]
name: pool_rows [3561,3570]
===
match
---
simple_stmt [3584,3661]
simple_stmt [3584,3661]
===
match
---
expr_stmt [3395,3460]
expr_stmt [3395,3460]
===
match
---
atom_expr [5598,5631]
atom_expr [5601,5634]
===
match
---
expr_stmt [4080,4134]
expr_stmt [4080,4134]
===
match
---
name: session [3451,3458]
name: session [3451,3458]
===
match
---
name: orm [915,918]
name: orm [915,918]
===
match
---
name: __repr__ [1741,1749]
name: __repr__ [1741,1749]
===
match
---
trailer [6726,6732]
trailer [6759,6765]
===
match
---
name: pool_rows [3470,3479]
name: pool_rows [3470,3479]
===
match
---
name: provide_session [1171,1186]
name: provide_session [1171,1186]
===
match
---
name: Session [6969,6976]
name: Session [7014,7021]
===
match
---
trailer [1780,1785]
trailer [1780,1785]
===
match
---
name: description [5185,5196]
name: description [5185,5196]
===
match
---
trailer [2487,2528]
trailer [2487,2528]
===
match
---
trailer [6867,6874]
trailer [6900,6907]
===
match
---
name: staticmethod [2212,2224]
name: staticmethod [2212,2224]
===
match
---
number: 0 [5788,5789]
number: 0 [5793,5794]
===
match
---
string: "open" [4750,4756]
string: "open" [4750,4756]
===
match
---
name: pool [6253,6257]
name: pool [6271,6275]
===
match
---
simple_stmt [7190,7210]
simple_stmt [7235,7255]
===
match
---
expr_stmt [1697,1731]
expr_stmt [1697,1731]
===
match
---
expr_stmt [1411,1420]
expr_stmt [1411,1420]
===
match
---
name: airflow [5481,5488]
name: airflow [5481,5488]
===
match
---
name: items [4636,4641]
name: items [4636,4641]
===
match
---
simple_stmt [1028,1093]
simple_stmt [1028,1093]
===
match
---
name: AirflowException [974,990]
name: AirflowException [974,990]
===
match
---
annassign [3278,3305]
annassign [3278,3305]
===
match
---
decorated [1817,2206]
decorated [1817,2206]
===
match
---
operator: , [2632,2633]
operator: , [2632,2633]
===
match
---
trailer [3832,3836]
trailer [3832,3836]
===
match
---
trailer [3589,3600]
trailer [3589,3600]
===
match
---
name: airflow [1142,1149]
name: airflow [1142,1149]
===
match
---
operator: = [1897,1898]
operator: = [1897,1898]
===
match
---
name: pools [4630,4635]
name: pools [4630,4635]
===
match
---
import_from [1137,1186]
import_from [1137,1186]
===
match
---
name: airflow [948,955]
name: airflow [948,955]
===
match
---
string: """         Get the Pool with specific pool name from the Pools.          :param pool_name: The pool name of the Pool to get.         :param session: SQLAlchemy ORM Session         :return: the pool object         """ [1914,2131]
string: """         Get the Pool with specific pool name from the Pools.          :param pool_name: The pool name of the Pool to get.         :param session: SQLAlchemy ORM Session         :return: the pool object         """ [1914,2131]
===
match
---
expr_stmt [1395,1406]
expr_stmt [1395,1406]
===
match
---
name: query [6727,6732]
name: query [6760,6765]
===
match
---
name: EXECUTION_STATES [5733,5749]
name: EXECUTION_STATES [5736,5752]
===
match
---
suite [2697,4907]
suite [2697,4907]
===
match
---
trailer [3874,3883]
trailer [3874,3883]
===
match
---
number: 0 [6351,6352]
number: 0 [6371,6372]
===
match
---
simple_stmt [943,991]
simple_stmt [943,991]
===
match
---
name: airflow [1098,1105]
name: airflow [1098,1105]
===
match
---
name: DEFAULT_POOL_NAME [1697,1714]
name: DEFAULT_POOL_NAME [1697,1714]
===
match
---
testlist_comp [4019,4042]
testlist_comp [4019,4042]
===
match
---
operator: = [3301,3302]
operator: = [3301,3302]
===
match
---
operator: , [886,887]
operator: , [886,887]
===
match
---
trailer [1528,1555]
trailer [1528,1555]
===
match
---
operator: = [3401,3402]
operator: = [3401,3402]
===
match
---
decorator [2229,2246]
decorator [2229,2246]
===
match
---
trailer [5597,5632]
trailer [5600,5635]
===
match
---
name: total [3613,3618]
name: total [3613,3618]
===
match
---
string: """the class to get Pool info.""" [1445,1478]
string: """the class to get Pool info.""" [1445,1478]
===
match
---
simple_stmt [1093,1137]
simple_stmt [1093,1137]
===
match
---
testlist_comp [3534,3556]
testlist_comp [3534,3556]
===
match
---
dotted_name [996,1015]
dotted_name [996,1015]
===
match
---
name: scalar [6889,6895]
name: scalar [6922,6928]
===
match
---
trailer [6239,6244]
trailer [6257,6262]
===
match
---
argument [3632,3641]
argument [3632,3641]
===
match
---
name: models [3199,3205]
name: models [3199,3205]
===
match
---
operator: , [6400,6401]
operator: , [6430,6431]
===
match
---
atom_expr [7197,7209]
atom_expr [7242,7254]
===
match
---
atom_expr [7256,7284]
atom_expr [7301,7329]
===
match
---
name: int [4002,4005]
name: int [4002,4005]
===
match
---
arglist [3418,3459]
arglist [3418,3459]
===
match
---
suite [4316,4363]
suite [4316,4363]
===
match
---
atom_expr [1634,1660]
atom_expr [1634,1660]
===
match
---
name: first [2198,2203]
name: first [2198,2203]
===
match
---
atom_expr [3903,3921]
atom_expr [3903,3921]
===
match
---
decorated [6918,7285]
decorated [6963,7330]
===
match
---
name: taskinstance [6631,6643]
name: taskinstance [6661,6673]
===
match
---
simple_stmt [4797,4885]
simple_stmt [4797,4885]
===
match
---
atom_expr [1679,1691]
atom_expr [1679,1691]
===
match
---
return_stmt [2467,2528]
return_stmt [2467,2528]
===
match
---
name: self [6396,6400]
name: self [6426,6430]
===
match
---
comparison [5653,5683]
comparison [5656,5686]
===
match
---
name: Pool [2174,2178]
name: Pool [2174,2178]
===
match
---
raise_stmt [4478,4559]
raise_stmt [4478,4559]
===
match
---
name: stats_dict [4333,4343]
name: stats_dict [4333,4343]
===
match
---
factor [4683,4685]
factor [4683,4685]
===
match
---
trailer [5732,5750]
trailer [5735,5753]
===
match
---
decorated [2211,2529]
decorated [2211,2529]
===
match
---
trailer [5645,5652]
trailer [5648,5655]
===
match
---
trailer [3883,3922]
trailer [3883,3922]
===
match
---
operator: == [6806,6808]
operator: == [6839,6841]
===
match
---
simple_stmt [1395,1407]
simple_stmt [1395,1407]
===
match
---
operator: , [892,893]
operator: , [892,893]
===
match
---
atom_expr [1574,1585]
atom_expr [1574,1585]
===
match
---
expr_stmt [1517,1555]
expr_stmt [1517,1555]
===
match
---
name: slots [5146,5151]
name: slots [5146,5151]
===
match
---
classdef [1287,1421]
classdef [1287,1421]
===
match
---
param [6960,6976]
param [7005,7021]
===
match
---
name: typing [793,799]
name: typing [793,799]
===
match
---
comparison [4297,4315]
comparison [4297,4315]
===
match
---
name: func [5598,5602]
name: func [5601,5605]
===
match
---
name: self [7256,7260]
name: self [7301,7305]
===
match
---
name: Integer [871,878]
name: Integer [871,878]
===
match
---
operator: , [3757,3758]
operator: , [3757,3758]
===
match
---
operator: = [3690,3691]
operator: = [3690,3691]
===
match
---
operator: = [1593,1594]
operator: = [1593,1594]
===
match
---
expr_stmt [4333,4362]
expr_stmt [4333,4362]
===
match
---
string: """         Get the number of slots used by running/queued tasks at the moment.          :param session: SQLAlchemy ORM Session         :return: the used number of slots         """ [5286,5467]
string: """         Get the number of slots used by running/queued tasks at the moment.          :param session: SQLAlchemy ORM Session         :return: the used number of slots         """ [5286,5467]
===
match
---
name: sum [6738,6741]
name: sum [6771,6774]
===
match
---
name: all [3933,3936]
name: all [3933,3936]
===
match
---
trailer [1640,1660]
trailer [1640,1660]
===
match
---
name: Column [1522,1528]
name: Column [1522,1528]
===
match
---
trailer [5602,5606]
trailer [5605,5609]
===
match
---
atom_expr [6181,6204]
atom_expr [6199,6222]
===
match
---
name: pools [3273,3278]
name: pools [3273,3278]
===
match
---
operator: , [1648,1649]
operator: , [1648,1649]
===
match
---
operator: , [4614,4615]
operator: , [4614,4615]
===
match
---
trailer [3826,3832]
trailer [3826,3832]
===
match
---
operator: = [1657,1658]
operator: = [1657,1658]
===
match
---
name: typing_compat [1106,1119]
name: typing_compat [1106,1119]
===
match
---
name: stats_dict [4154,4164]
name: stats_dict [4154,4164]
===
match
---
comparison [6279,6314]
comparison [6297,6332]
===
match
---
trailer [5113,5118]
trailer [5113,5118]
===
match
---
operator: == [6298,6300]
operator: == [6316,6318]
===
match
---
arglist [3884,3921]
arglist [3884,3921]
===
match
---
atom_expr [4092,4111]
atom_expr [4092,4111]
===
match
---
trailer [7260,7275]
trailer [7305,7320]
===
match
---
operator: , [2510,2511]
operator: , [2510,2511]
===
match
---
import_from [6050,6102]
import_from [6065,6117]
===
match
---
name: utils [1150,1155]
name: utils [1150,1155]
===
match
---
name: total_slots [3545,3556]
name: total_slots [3545,3556]
===
match
---
param [5259,5275]
param [5259,5275]
===
match
---
simple_stmt [1378,1391]
simple_stmt [1378,1391]
===
match
---
number: 0 [3650,3651]
number: 0 [3650,3651]
===
match
---
trailer [3767,3792]
trailer [3767,3792]
===
match
---
atom_expr [3720,3737]
atom_expr [3720,3737]
===
match
---
trailer [5145,5151]
trailer [5145,5151]
===
match
---
name: pool_name [4124,4133]
name: pool_name [4124,4133]
===
match
---
parameters [2270,2295]
parameters [2270,2295]
===
match
---
argument [3425,3440]
argument [3425,3440]
===
match
---
number: 0 [6911,6912]
number: 0 [6946,6947]
===
match
---
name: sqlalchemy [845,855]
name: sqlalchemy [845,855]
===
match
---
operator: - [4838,4839]
operator: - [4838,4839]
===
match
---
name: airflow [1252,1259]
name: airflow [1252,1259]
===
match
---
name: pool [5114,5118]
name: pool [5114,5118]
===
match
---
name: self [5141,5145]
name: self [5141,5145]
===
match
---
name: TaskInstance [6279,6291]
name: TaskInstance [6297,6309]
===
match
---
trailer [2154,2160]
trailer [2154,2160]
===
match
---
param [6396,6401]
param [6426,6431]
===
match
---
string: """         Get the Pool in a json structure          :return: the pool object in json format         """ [4939,5044]
string: """         Get the Pool in a json structure          :return: the pool object in json format         """ [4939,5044]
===
match
---
argument [3653,3659]
argument [3653,3659]
===
match
---
atom_expr [1776,1785]
atom_expr [1776,1785]
===
match
---
name: TaskInstance [3768,3780]
name: TaskInstance [3768,3780]
===
match
---
decorators [2211,2246]
decorators [2211,2246]
===
match
---
name: State [6862,6867]
name: State [6895,6900]
===
match
---
name: stats_dict [4415,4425]
name: stats_dict [4415,4425]
===
match
---
trailer [4828,4837]
trailer [4828,4837]
===
match
---
atom_expr [3323,3359]
atom_expr [3323,3359]
===
match
---
atom_expr [6227,6244]
atom_expr [6245,6262]
===
match
---
name: query [3331,3336]
name: query [3331,3336]
===
match
---
name: session [2512,2519]
name: session [2512,2519]
===
match
---
atom_expr [6172,6205]
atom_expr [6190,6223]
===
match
---
argument [3442,3459]
argument [3442,3459]
===
match
---
operator: , [3641,3642]
operator: , [3641,3642]
===
match
---
operator: , [3440,3441]
operator: , [3440,3441]
===
match
---
atom_expr [4864,4884]
atom_expr [4864,4884]
===
match
---
file_input [788,7285]
file_input [788,7330]
===
match
---
simple_stmt [4739,4763]
simple_stmt [4739,4763]
===
match
---
operator: , [869,870]
operator: , [869,870]
===
match
---
name: Dict [807,811]
name: Dict [807,811]
===
match
---
operator: , [1878,1879]
operator: , [1878,1879]
===
match
---
name: String [1574,1580]
name: String [1574,1580]
===
match
---
name: pool_name [3590,3599]
name: pool_name [3590,3599]
===
match
---
name: query [5592,5597]
name: query [5595,5600]
===
match
---
fstring_end: " [4557,4558]
fstring_end: " [4557,4558]
===
match
---
suite [4398,4444]
suite [4398,4444]
===
match
---
name: func [3759,3763]
name: func [3759,3763]
===
match
---
trailer [6328,6335]
trailer [6346,6353]
===
match
---
name: stats_dict [4840,4850]
name: stats_dict [4840,4850]
===
match
---
number: 0 [1658,1659]
number: 0 [1658,1659]
===
match
---
name: EXECUTION_STATES [1076,1092]
name: EXECUTION_STATES [1076,1092]
===
match
---
import_from [991,1027]
import_from [991,1027]
===
match
---
trailer [4425,4435]
trailer [4425,4435]
===
match
---
trailer [3841,3859]
trailer [3841,3859]
===
match
---
name: self [5080,5084]
name: self [5080,5084]
===
match
---
name: Text [888,892]
name: Text [888,892]
===
match
---
atom_expr [3706,3922]
atom_expr [3706,3922]
===
match
---
name: query [3714,3719]
name: query [3714,3719]
===
match
---
atom_expr [5080,5087]
atom_expr [5080,5087]
===
match
---
name: State [1279,1284]
name: State [1279,1284]
===
match
---
string: "open" [4808,4814]
string: "open" [4808,4814]
===
match
---
operator: , [3543,3544]
operator: , [3543,3544]
===
match
---
name: self [5180,5184]
name: self [5180,5184]
===
match
---
operator: = [2288,2289]
operator: = [2288,2289]
===
match
---
operator: == [6245,6247]
operator: == [6263,6265]
===
match
---
trailer [3514,3518]
trailer [3514,3518]
===
match
---
trailer [4874,4884]
trailer [4874,4884]
===
match
---
name: pool [6801,6805]
name: pool [6834,6838]
===
match
---
name: pool [5666,5670]
name: pool [5669,5673]
===
match
---
operator: } [3304,3305]
operator: } [3304,3305]
===
match
---
name: Session [5268,5275]
name: Session [5268,5275]
===
match
---
simple_stmt [6429,6603]
simple_stmt [6459,6633]
===
match
---
name: EXECUTION_STATES [4539,4555]
name: EXECUTION_STATES [4539,4555]
===
match
---
name: sum [5603,5606]
name: sum [5606,5609]
===
match
---
import_as_names [807,838]
import_as_names [807,838]
===
match
---
name: provide_session [2553,2568]
name: provide_session [2553,2568]
===
match
---
trailer [4641,4643]
trailer [4641,4643]
===
match
---
atom [4018,4043]
atom [4018,4043]
===
match
---
name: int [1387,1390]
name: int [1387,1390]
===
match
---
string: """         Get the Pool of the default_pool from the Pools.          :param session: SQLAlchemy ORM Session         :return: the pool object         """ [2305,2458]
string: """         Get the Pool of the default_pool from the Pools.          :param session: SQLAlchemy ORM Session         :return: the pool object         """ [2305,2458]
===
match
---
number: 1 [7175,7176]
number: 1 [7220,7221]
===
match
---
name: Tuple [3490,3495]
name: Tuple [3490,3495]
===
match
---
trailer [6180,6205]
trailer [6198,6223]
===
match
---
name: Optional [4092,4100]
name: Optional [4092,4100]
===
match
---
dotted_name [6055,6082]
dotted_name [6070,6097]
===
match
---
simple_stmt [6698,6913]
simple_stmt [6728,6958]
===
match
---
simple_stmt [3395,3461]
simple_stmt [3395,3461]
===
match
---
atom_expr [3837,3859]
atom_expr [3837,3859]
===
match
---
name: Optional [823,831]
name: Optional [823,831]
===
match
---
name: func [6733,6737]
name: func [6766,6770]
===
match
---
atom_expr [6809,6818]
atom_expr [6842,6851]
===
match
---
name: pool [1560,1564]
name: pool [1560,1564]
===
match
---
operator: == [6859,6861]
operator: == [6892,6894]
===
match
---
atom_expr [4797,4815]
atom_expr [4797,4815]
===
match
---
operator: , [1230,1231]
operator: , [1230,1231]
===
match
---
simple_stmt [4478,4560]
simple_stmt [4478,4560]
===
match
---
atom_expr [5141,5151]
atom_expr [5141,5151]
===
match
---
atom_expr [3509,3520]
atom_expr [3509,3520]
===
match
---
name: Pool [2474,2478]
name: Pool [2474,2478]
===
match
---
atom_expr [4415,4435]
atom_expr [4415,4435]
===
match
---
name: AirflowException [4484,4500]
name: AirflowException [4484,4500]
===
match
---
operator: - [4760,4761]
operator: - [4760,4761]
===
match
---
simple_stmt [1319,1358]
simple_stmt [1319,1358]
===
match
---
funcdef [2573,4907]
funcdef [2573,4907]
===
match
---
fstring_expr [4538,4556]
fstring_expr [4538,4556]
===
match
---
suite [1756,1812]
suite [1756,1812]
===
match
---
simple_stmt [3995,4006]
simple_stmt [3995,4006]
===
match
---
name: session [2642,2649]
name: session [2642,2649]
===
match
---
name: slots [7248,7253]
name: slots [7293,7298]
===
match
---
trailer [3713,3719]
trailer [3713,3719]
===
match
---
trailer [2478,2487]
trailer [2478,2487]
===
match
---
trailer [6741,6766]
trailer [6774,6799]
===
match
---
string: "slot_pool" [1500,1511]
string: "slot_pool" [1500,1511]
===
match
---
trailer [2203,2205]
trailer [2203,2205]
===
match
---
operator: = [1677,1678]
operator: = [1677,1678]
===
match
---
trailer [5717,5723]
trailer [5720,5726]
===
match
---
name: filter [6272,6278]
name: filter [6290,6296]
===
match
---
name: lock_rows [2609,2618]
name: lock_rows [2609,2618]
===
match
---
import_as_names [863,898]
import_as_names [863,898]
===
match
---
atom_expr [6279,6297]
atom_expr [6297,6315]
===
match
---
decorator [2534,2548]
decorator [2534,2548]
===
match
---
suite [3571,3661]
suite [3571,3661]
===
match
---
param [2271,2294]
param [2271,2294]
===
match
---
trailer [5697,5704]
trailer [5700,5707]
===
match
---
operator: @ [6918,6919]
operator: @ [6963,6964]
===
match
---
not_test [4150,4164]
not_test [4150,4164]
===
match
---
operator: - [7254,7255]
operator: - [7299,7300]
===
match
---
name: Base [1023,1027]
name: Base [1023,1027]
===
match
---
name: running [1378,1385]
name: running [1378,1385]
===
match
---
atom_expr [6301,6314]
atom_expr [6319,6332]
===
match
---
operator: , [831,832]
operator: , [831,832]
===
match
---
arglist [3720,3792]
arglist [3720,3792]
===
match
---
name: state [3827,3832]
name: state [3827,3832]
===
match
---
name: dependencies_states [1049,1068]
name: dependencies_states [1049,1068]
===
match
---
annassign [1368,1373]
annassign [1368,1373]
===
match
---
trailer [6271,6278]
trailer [6289,6296]
===
match
---
trailer [3450,3459]
trailer [3450,3459]
===
match
---
trailer [3330,3336]
trailer [3330,3336]
===
match
---
atom [3533,3557]
atom [3533,3557]
===
match
---
name: Session [2651,2658]
name: Session [2651,2658]
===
match
---
name: str [3285,3288]
name: str [3285,3288]
===
match
---
name: in_ [5724,5727]
name: in_ [5727,5730]
===
match
---
atom_expr [6862,6874]
atom_expr [6895,6907]
===
match
---
trailer [5727,5751]
trailer [5730,5754]
===
match
---
string: "running" [4851,4860]
string: "running" [4851,4860]
===
match
---
name: TaskInstance [5516,5528]
name: TaskInstance [5516,5528]
===
match
---
name: filter [3807,3813]
name: filter [3807,3813]
===
match
---
trailer [3896,3901]
trailer [3896,3901]
===
match
---
trailer [5772,5774]
trailer [5775,5777]
===
match
---
name: query [2155,2160]
name: query [2155,2160]
===
match
---
name: queued [3643,3649]
name: queued [3643,3649]
===
match
---
import_from [1247,1284]
import_from [1247,1284]
===
match
---
operator: @ [1835,1836]
operator: @ [1835,1836]
===
match
---
operator: = [1565,1566]
operator: = [1565,1566]
===
match
---
trailer [4343,4354]
trailer [4343,4354]
===
match
---
param [6402,6418]
param [6432,6448]
===
match
---
return_stmt [4894,4906]
return_stmt [4894,4906]
===
match
---
return_stmt [1765,1786]
return_stmt [1765,1786]
===
match
---
trailer [3780,3791]
trailer [3780,3791]
===
match
---
name: pools [3584,3589]
name: pools [3584,3589]
===
match
---
name: state [3752,3757]
name: state [3752,3757]
===
match
---
trailer [4670,4679]
trailer [4670,4679]
===
match
---
simple_stmt [2140,2206]
simple_stmt [2140,2206]
===
match
---
trailer [3763,3767]
trailer [3763,3767]
===
match
---
name: stats_dict [4864,4874]
name: stats_dict [4864,4874]
===
match
---
trailer [3732,3737]
trailer [3732,3737]
===
match
---
name: base [1011,1015]
name: base [1011,1015]
===
match
---
atom_expr [5705,5751]
atom_expr [5708,5754]
===
insert-node
---
atom_expr [5570,5804]
to
return_stmt [5563,5789]
at 0
===
insert-node
---
atom_expr [6159,6382]
to
return_stmt [6137,6352]
at 0
===
insert-node
---
atom_expr [6735,6957]
to
return_stmt [6698,6912]
at 0
===
insert-node
---
trailer [5573,5804]
to
atom_expr [5570,5804]
at 1
===
insert-node
---
trailer [6162,6382]
to
atom_expr [6159,6382]
at 1
===
insert-node
---
trailer [6738,6957]
to
atom_expr [6735,6957]
at 1
===
move-tree
---
or_test [5570,5789]
    atom [5570,5784]
        atom_expr [5584,5774]
            name: session [5584,5591]
            trailer [5591,5597]
                name: query [5592,5597]
            trailer [5597,5632]
                atom_expr [5598,5631]
                    name: func [5598,5602]
                    trailer [5602,5606]
                        name: sum [5603,5606]
                    trailer [5606,5631]
                        atom_expr [5607,5630]
                            name: TaskInstance [5607,5619]
                            trailer [5619,5630]
                                name: pool_slots [5620,5630]
            trailer [5645,5652]
                name: filter [5646,5652]
            trailer [5652,5684]
                comparison [5653,5683]
                    atom_expr [5653,5670]
                        name: TaskInstance [5653,5665]
                        trailer [5665,5670]
                            name: pool [5666,5670]
                    operator: == [5671,5673]
                    atom_expr [5674,5683]
                        name: self [5674,5678]
                        trailer [5678,5683]
                            name: pool [5679,5683]
            trailer [5697,5704]
                name: filter [5698,5704]
            trailer [5704,5752]
                atom_expr [5705,5751]
                    name: TaskInstance [5705,5717]
                    trailer [5717,5723]
                        name: state [5718,5723]
                    trailer [5723,5727]
                        name: in_ [5724,5727]
                    trailer [5727,5751]
                        atom_expr [5728,5750]
                            name: list [5728,5732]
                            trailer [5732,5750]
                                name: EXECUTION_STATES [5733,5749]
            trailer [5765,5772]
                name: scalar [5766,5772]
            trailer [5772,5774]
    number: 0 [5788,5789]
to
trailer [5573,5804]
at 0
===
move-tree
---
or_test [6144,6352]
    atom [6144,6347]
        atom_expr [6158,6337]
            name: session [6158,6165]
            trailer [6165,6171]
                name: query [6166,6171]
            trailer [6171,6206]
                atom_expr [6172,6205]
                    name: func [6172,6176]
                    trailer [6176,6180]
                        name: sum [6177,6180]
                    trailer [6180,6205]
                        atom_expr [6181,6204]
                            name: TaskInstance [6181,6193]
                            trailer [6193,6204]
                                name: pool_slots [6194,6204]
            trailer [6219,6226]
                name: filter [6220,6226]
            trailer [6226,6258]
                comparison [6227,6257]
                    atom_expr [6227,6244]
                        name: TaskInstance [6227,6239]
                        trailer [6239,6244]
                            name: pool [6240,6244]
                    operator: == [6245,6247]
                    atom_expr [6248,6257]
                        name: self [6248,6252]
                        trailer [6252,6257]
                            name: pool [6253,6257]
            trailer [6271,6278]
                name: filter [6272,6278]
            trailer [6278,6315]
                comparison [6279,6314]
                    atom_expr [6279,6297]
                        name: TaskInstance [6279,6291]
                        trailer [6291,6297]
                            name: state [6292,6297]
                    operator: == [6298,6300]
                    atom_expr [6301,6314]
                        name: State [6301,6306]
                        trailer [6306,6314]
                            name: RUNNING [6307,6314]
            trailer [6328,6335]
                name: scalar [6329,6335]
            trailer [6335,6337]
    number: 0 [6351,6352]
to
trailer [6162,6382]
at 0
===
move-tree
---
or_test [6705,6912]
    atom [6705,6907]
        atom_expr [6719,6897]
            name: session [6719,6726]
            trailer [6726,6732]
                name: query [6727,6732]
            trailer [6732,6767]
                atom_expr [6733,6766]
                    name: func [6733,6737]
                    trailer [6737,6741]
                        name: sum [6738,6741]
                    trailer [6741,6766]
                        atom_expr [6742,6765]
                            name: TaskInstance [6742,6754]
                            trailer [6754,6765]
                                name: pool_slots [6755,6765]
            trailer [6780,6787]
                name: filter [6781,6787]
            trailer [6787,6819]
                comparison [6788,6818]
                    atom_expr [6788,6805]
                        name: TaskInstance [6788,6800]
                        trailer [6800,6805]
                            name: pool [6801,6805]
                    operator: == [6806,6808]
                    atom_expr [6809,6818]
                        name: self [6809,6813]
                        trailer [6813,6818]
                            name: pool [6814,6818]
            trailer [6832,6839]
                name: filter [6833,6839]
            trailer [6839,6875]
                comparison [6840,6874]
                    atom_expr [6840,6858]
                        name: TaskInstance [6840,6852]
                        trailer [6852,6858]
                            name: state [6853,6858]
                    operator: == [6859,6861]
                    atom_expr [6862,6874]
                        name: State [6862,6867]
                        trailer [6867,6874]
                            name: QUEUED [6868,6874]
            trailer [6888,6895]
                name: scalar [6889,6895]
            trailer [6895,6897]
    number: 0 [6911,6912]
to
trailer [6738,6957]
at 0
===
move-tree
---
atom_expr [5584,5774]
    name: session [5584,5591]
    trailer [5591,5597]
        name: query [5592,5597]
    trailer [5597,5632]
        atom_expr [5598,5631]
            name: func [5598,5602]
            trailer [5602,5606]
                name: sum [5603,5606]
            trailer [5606,5631]
                atom_expr [5607,5630]
                    name: TaskInstance [5607,5619]
                    trailer [5619,5630]
                        name: pool_slots [5620,5630]
    trailer [5645,5652]
        name: filter [5646,5652]
    trailer [5652,5684]
        comparison [5653,5683]
            atom_expr [5653,5670]
                name: TaskInstance [5653,5665]
                trailer [5665,5670]
                    name: pool [5666,5670]
            operator: == [5671,5673]
            atom_expr [5674,5683]
                name: self [5674,5678]
                trailer [5678,5683]
                    name: pool [5679,5683]
    trailer [5697,5704]
        name: filter [5698,5704]
    trailer [5704,5752]
        atom_expr [5705,5751]
            name: TaskInstance [5705,5717]
            trailer [5717,5723]
                name: state [5718,5723]
            trailer [5723,5727]
                name: in_ [5724,5727]
            trailer [5727,5751]
                atom_expr [5728,5750]
                    name: list [5728,5732]
                    trailer [5732,5750]
                        name: EXECUTION_STATES [5733,5749]
    trailer [5765,5772]
        name: scalar [5766,5772]
    trailer [5772,5774]
to
or_test [5570,5789]
at 0
===
move-tree
---
atom_expr [6158,6337]
    name: session [6158,6165]
    trailer [6165,6171]
        name: query [6166,6171]
    trailer [6171,6206]
        atom_expr [6172,6205]
            name: func [6172,6176]
            trailer [6176,6180]
                name: sum [6177,6180]
            trailer [6180,6205]
                atom_expr [6181,6204]
                    name: TaskInstance [6181,6193]
                    trailer [6193,6204]
                        name: pool_slots [6194,6204]
    trailer [6219,6226]
        name: filter [6220,6226]
    trailer [6226,6258]
        comparison [6227,6257]
            atom_expr [6227,6244]
                name: TaskInstance [6227,6239]
                trailer [6239,6244]
                    name: pool [6240,6244]
            operator: == [6245,6247]
            atom_expr [6248,6257]
                name: self [6248,6252]
                trailer [6252,6257]
                    name: pool [6253,6257]
    trailer [6271,6278]
        name: filter [6272,6278]
    trailer [6278,6315]
        comparison [6279,6314]
            atom_expr [6279,6297]
                name: TaskInstance [6279,6291]
                trailer [6291,6297]
                    name: state [6292,6297]
            operator: == [6298,6300]
            atom_expr [6301,6314]
                name: State [6301,6306]
                trailer [6306,6314]
                    name: RUNNING [6307,6314]
    trailer [6328,6335]
        name: scalar [6329,6335]
    trailer [6335,6337]
to
or_test [6144,6352]
at 0
===
move-tree
---
atom_expr [6719,6897]
    name: session [6719,6726]
    trailer [6726,6732]
        name: query [6727,6732]
    trailer [6732,6767]
        atom_expr [6733,6766]
            name: func [6733,6737]
            trailer [6737,6741]
                name: sum [6738,6741]
            trailer [6741,6766]
                atom_expr [6742,6765]
                    name: TaskInstance [6742,6754]
                    trailer [6754,6765]
                        name: pool_slots [6755,6765]
    trailer [6780,6787]
        name: filter [6781,6787]
    trailer [6787,6819]
        comparison [6788,6818]
            atom_expr [6788,6805]
                name: TaskInstance [6788,6800]
                trailer [6800,6805]
                    name: pool [6801,6805]
            operator: == [6806,6808]
            atom_expr [6809,6818]
                name: self [6809,6813]
                trailer [6813,6818]
                    name: pool [6814,6818]
    trailer [6832,6839]
        name: filter [6833,6839]
    trailer [6839,6875]
        comparison [6840,6874]
            atom_expr [6840,6858]
                name: TaskInstance [6840,6852]
                trailer [6852,6858]
                    name: state [6853,6858]
            operator: == [6859,6861]
            atom_expr [6862,6874]
                name: State [6862,6867]
                trailer [6867,6874]
                    name: QUEUED [6868,6874]
    trailer [6888,6895]
        name: scalar [6889,6895]
    trailer [6895,6897]
to
or_test [6705,6912]
at 0
===
delete-node
---
atom [5570,5784]
===
===
delete-node
---
atom [6144,6347]
===
===
delete-node
---
atom [6705,6907]
===
