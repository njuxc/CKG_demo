===
match
---
name: execution_date [9276,9290]
name: execution_date [9243,9257]
===
match
---
name: UtcDateTime [1828,1839]
name: UtcDateTime [1828,1839]
===
match
---
atom_expr [9359,9377]
atom_expr [9326,9344]
===
match
---
import_from [1370,1418]
import_from [1370,1418]
===
match
---
operator: = [1783,1784]
operator: = [1783,1784]
===
match
---
suite [8563,8931]
suite [8530,8898]
===
match
---
simple_stmt [13654,13667]
simple_stmt [13621,13634]
===
match
---
expr_stmt [1546,1567]
expr_stmt [1546,1567]
===
match
---
operator: , [1753,1754]
operator: , [1753,1754]
===
match
---
name: Union [873,878]
name: Union [873,878]
===
match
---
name: airflow [1268,1275]
name: airflow [1268,1275]
===
match
---
name: result [12292,12298]
name: result [12259,12265]
===
match
---
name: conf [13348,13352]
name: conf [13315,13319]
===
match
---
name: classmethod [2913,2924]
name: classmethod [2913,2924]
===
match
---
name: associationproxy [967,983]
name: associationproxy [967,983]
===
match
---
trailer [9317,9319]
trailer [9284,9286]
===
match
---
expr_stmt [3441,3480]
expr_stmt [3441,3480]
===
match
---
operator: = [6185,6186]
operator: = [6152,6153]
===
match
---
trailer [12582,12612]
trailer [12549,12579]
===
match
---
name: append [8886,8892]
name: append [8853,8859]
===
match
---
argument [13387,13438]
argument [13354,13405]
===
match
---
fstring_start: f" [13396,13398]
fstring_start: f" [13363,13365]
===
match
---
name: query [11613,11618]
name: query [11580,11585]
===
match
---
xor_expr [7937,7980]
xor_expr [7904,7947]
===
match
---
param [4087,4116]
param [4054,4083]
===
match
---
argument [5957,5972]
argument [5924,5939]
===
match
---
name: value [12814,12819]
name: value [12781,12786]
===
match
---
atom_expr [8243,8268]
atom_expr [8210,8235]
===
match
---
trailer [3367,3373]
trailer [3367,3373]
===
match
---
trailer [3783,3785]
trailer [3751,3753]
===
match
---
operator: = [3398,3399]
operator: = [3398,3399]
===
match
---
name: pendulum [4052,4060]
name: pendulum [4019,4027]
===
match
---
expr_stmt [9176,9239]
expr_stmt [9143,9206]
===
match
---
name: include_prior_dates [6397,6416]
name: include_prior_dates [6364,6383]
===
match
---
suite [3040,3950]
suite [3040,3917]
===
match
---
operator: = [3358,3359]
operator: = [3358,3359]
===
match
---
trailer [12394,12405]
trailer [12361,12372]
===
match
---
name: execution_date [8897,8911]
name: execution_date [8864,8878]
===
match
---
name: default [1841,1848]
name: default [1841,1848]
===
match
---
operator: == [11320,11322]
operator: == [11287,11289]
===
match
---
name: execution_date [11437,11451]
name: execution_date [11404,11418]
===
match
---
tfpdef [4160,4204]
tfpdef [4127,4171]
===
match
---
not_test [3128,3175]
not_test [3128,3175]
===
match
---
trailer [3425,3427]
trailer [3425,3427]
===
match
---
parameters [6118,6507]
parameters [6085,6474]
===
match
---
decorator [9422,9435]
decorator [9389,9402]
===
match
---
operator: } [9740,9741]
operator: } [9707,9708]
===
match
---
operator: = [1766,1767]
operator: = [1766,1767]
===
match
---
atom_expr [2471,2509]
atom_expr [2471,2509]
===
match
---
expr_stmt [1683,1705]
expr_stmt [1683,1705]
===
match
---
fstring [9690,9742]
fstring [9657,9709]
===
match
---
arglist [1988,2038]
arglist [1988,2038]
===
match
---
name: session [6477,6484]
name: session [6444,6451]
===
match
---
atom_expr [3821,3923]
atom_expr [3789,3891]
===
match
---
try_stmt [12639,12821]
try_stmt [12606,12788]
===
match
---
expr_stmt [5720,5991]
expr_stmt [5687,5958]
===
match
---
simple_stmt [13229,13269]
simple_stmt [13196,13236]
===
match
---
atom_expr [6354,6379]
atom_expr [6321,6346]
===
match
---
name: cls [3617,3620]
name: cls [3586,3589]
===
match
---
param [9476,9482]
param [9443,9449]
===
match
---
operator: = [3874,3875]
operator: = [3842,3843]
===
match
---
trailer [6252,6257]
trailer [6219,6224]
===
match
---
trailer [2778,2800]
trailer [2778,2800]
===
match
---
name: execution_date [5580,5594]
name: execution_date [5547,5561]
===
match
---
simple_stmt [2761,2803]
simple_stmt [2761,2803]
===
match
---
parameters [9470,9496]
parameters [9437,9463]
===
match
---
tfpdef [6274,6319]
tfpdef [6241,6286]
===
match
---
name: init_on_load [2538,2550]
name: init_on_load [2538,2550]
===
match
---
trailer [11625,11627]
trailer [11592,11594]
===
match
---
name: primary_key [2022,2033]
name: primary_key [2022,2033]
===
match
---
dotted_name [1221,1242]
dotted_name [1221,1242]
===
match
---
arglist [2060,2110]
arglist [2060,2110]
===
match
---
dotted_name [3301,3322]
dotted_name [3301,3322]
===
match
---
suite [9391,9417]
suite [9358,9384]
===
match
---
trailer [9290,9295]
trailer [9257,9262]
===
match
---
name: UnpicklingError [12532,12547]
name: UnpicklingError [12499,12514]
===
match
---
param [3026,3038]
param [3026,3038]
===
match
---
tfpdef [9877,9920]
tfpdef [9844,9887]
===
match
---
trailer [13479,13496]
trailer [13446,13463]
===
match
---
operator: ** [1736,1738]
operator: ** [1736,1738]
===
match
---
arglist [11274,11331]
arglist [11241,11298]
===
match
---
name: is_container [8380,8392]
name: is_container [8347,8359]
===
match
---
operator: , [4271,4272]
operator: , [4238,4239]
===
match
---
trailer [8998,9036]
trailer [8965,9003]
===
match
---
trailer [12491,12505]
trailer [12458,12472]
===
match
---
name: COLLATION_ARGS [1152,1166]
name: COLLATION_ARGS [1152,1166]
===
match
---
raise_stmt [8783,8865]
raise_stmt [8750,8832]
===
match
---
operator: @ [2912,2913]
operator: @ [2912,2913]
===
match
---
operator: , [3889,3890]
operator: , [3857,3858]
===
match
---
name: dag_id [8512,8518]
name: dag_id [8479,8485]
===
match
---
if_stmt [3273,3481]
if_stmt [3273,3481]
===
match
---
name: cls [9471,9474]
name: cls [9438,9441]
===
match
---
atom_expr [12572,12612]
atom_expr [12539,12579]
===
match
---
name: cls [9299,9302]
name: cls [9266,9269]
===
match
---
name: int [6456,6459]
name: int [6423,6426]
===
match
---
name: self [2821,2825]
name: self [2821,2825]
===
match
---
name: execution_date [9877,9891]
name: execution_date [9844,9858]
===
match
---
fstring_end: ' [9741,9742]
fstring_end: ' [9708,9709]
===
match
---
name: dag_id [3724,3730]
name: dag_id [3693,3699]
===
match
---
simple_stmt [9122,9163]
simple_stmt [9089,9130]
===
match
---
operator: , [9955,9956]
operator: , [9922,9923]
===
match
---
operator: = [2280,2281]
operator: = [2280,2281]
===
match
---
testlist_comp [12728,12768]
testlist_comp [12695,12735]
===
match
---
operator: = [1715,1716]
operator: = [1715,1716]
===
match
---
name: value [11886,11891]
name: value [11853,11858]
===
match
---
name: isinstance [9535,9545]
name: isinstance [9502,9512]
===
match
---
string: "Exactly one of execution_date or run_id must be passed" [11160,11216]
string: "Exactly one of execution_date or run_id must be passed" [11127,11183]
===
match
---
name: airflow [1125,1132]
name: airflow [1125,1132]
===
match
---
name: XCom [3833,3837]
name: XCom [3801,3805]
===
match
---
name: provide_session [2930,2945]
name: provide_session [2930,2945]
===
match
---
operator: , [6363,6364]
operator: , [6330,6331]
===
match
---
trailer [11277,11284]
trailer [11244,11251]
===
match
---
string: 'UTF-8' [11900,11907]
string: 'UTF-8' [11867,11874]
===
match
---
name: task_ids [8201,8209]
name: task_ids [8168,8176]
===
match
---
decorated [3955,6063]
decorated [3922,6030]
===
match
---
arglist [12406,12436]
arglist [12373,12403]
===
match
---
atom_expr [6166,6183]
atom_expr [6133,6150]
===
match
---
suite [8476,8531]
suite [8443,8498]
===
match
---
operator: = [1560,1561]
operator: = [1560,1561]
===
match
---
operator: = [2227,2228]
operator: = [2227,2228]
===
match
---
atom_expr [9717,9740]
atom_expr [9684,9707]
===
match
---
name: filters [8493,8500]
name: filters [8460,8467]
===
match
---
name: value [2766,2771]
name: value [2766,2771]
===
match
---
name: cls [8319,8322]
name: cls [8286,8289]
===
match
---
name: Optional [4229,4237]
name: Optional [4196,4204]
===
match
---
operator: = [5769,5770]
operator: = [5736,5737]
===
match
---
name: ValueError [8789,8799]
name: ValueError [8756,8766]
===
match
---
comparison [5607,5621]
comparison [5574,5588]
===
match
---
name: BaseXCom [13487,13495]
name: BaseXCom [13454,13462]
===
match
---
name: include_prior_dates [8543,8562]
name: include_prior_dates [8510,8529]
===
match
---
trailer [11899,11908]
trailer [11866,11875]
===
match
---
trailer [3205,3263]
trailer [3205,3263]
===
match
---
name: commit [3941,3947]
name: flush [3909,3914]
===
match
---
decorator [2515,2530]
decorator [2515,2530]
===
match
---
trailer [2488,2509]
trailer [2488,2509]
===
match
---
string: """and_(             BaseXCom.dag_id == foreign(DagRun.dag_id),             BaseXCom.execution_date == foreign(DagRun.execution_date)         )""" [2281,2427]
string: """and_(             BaseXCom.dag_id == foreign(DagRun.dag_id),             BaseXCom.execution_date == foreign(DagRun.execution_date)         )""" [2281,2427]
===
match
---
name: fallback [13387,13395]
name: fallback [13354,13362]
===
match
---
operator: @ [6068,6069]
operator: @ [6035,6036]
===
match
---
atom_expr [6157,6184]
atom_expr [6124,6151]
===
match
---
operator: = [1424,1425]
operator: = [1424,1425]
===
match
---
simple_stmt [1683,1706]
simple_stmt [1683,1706]
===
match
---
simple_stmt [8783,8866]
simple_stmt [8750,8833]
===
match
---
raise_stmt [9674,9743]
raise_stmt [9641,9710]
===
match
---
atom_expr [3195,3263]
atom_expr [3195,3263]
===
match
---
operator: , [2020,2021]
operator: , [2020,2021]
===
match
---
simple_stmt [2462,2510]
simple_stmt [2462,2510]
===
match
---
except_clause [11917,11947]
except_clause [11884,11914]
===
match
---
return_stmt [12787,12820]
return_stmt [12754,12787]
===
match
---
atom_expr [12583,12611]
atom_expr [12550,12578]
===
match
---
name: provide_session [3973,3988]
name: provide_session [3940,3955]
===
match
---
not_test [10887,10897]
not_test [10854,10864]
===
match
---
name: query [9257,9262]
name: query [9224,9229]
===
match
---
operator: , [5784,5785]
operator: , [5751,5752]
===
match
---
raise_stmt [5636,5710]
raise_stmt [5603,5677]
===
match
---
simple_stmt [11961,12229]
simple_stmt [11928,12196]
===
match
---
if_stmt [8540,9037]
if_stmt [8507,9004]
===
match
---
trailer [2241,2457]
trailer [2241,2457]
===
match
---
operator: = [2444,2445]
operator: = [2444,2445]
===
match
---
suite [13497,13646]
suite [13464,13613]
===
match
---
argument [3847,3858]
argument [3815,3826]
===
match
---
trailer [11892,11899]
trailer [11859,11866]
===
match
---
string: "Could not serialize the XCom value into JSON." [11988,12035]
string: "Could not serialize the XCom value into JSON." [11955,12002]
===
match
---
funcdef [13271,13687]
funcdef [13238,13654]
===
match
---
simple_stmt [2566,2753]
simple_stmt [2566,2753]
===
match
---
name: self [13263,13267]
name: self [13230,13234]
===
match
---
name: String [2060,2066]
name: String [2060,2066]
===
match
---
trailer [1987,2039]
trailer [1987,2039]
===
match
---
trailer [3610,3616]
trailer [3579,3585]
===
match
---
name: append [8992,8998]
name: append [8959,8965]
===
match
---
atom [5606,5622]
atom [5573,5589]
===
match
---
trailer [9061,9067]
trailer [9028,9034]
===
match
---
trailer [5983,5989]
trailer [5950,5956]
===
match
---
param [6141,6192]
param [6108,6159]
===
match
---
name: cls [9864,9867]
name: cls [9831,9834]
===
match
---
decorator [3955,3968]
decorator [3922,3935]
===
match
---
name: logging_mixin [1286,1299]
name: logging_mixin [1286,1299]
===
match
---
string: """         Deserialize method which is used to reconstruct ORM XCom object.          This method should be overridden in custom XCom backends to avoid         unnecessary request or other resource consuming operations when         creating XCom orm model. This is used when viewing XCom listing         in the webserver, for example.         """ [12874,13220]
string: """         Deserialize method which is used to reconstruct ORM XCom object.          This method should be overridden in custom XCom backends to avoid         unnecessary request or other resource consuming operations when         creating XCom orm model. This is used when viewing XCom listing         in the webserver, for example.         """ [12841,13187]
===
match
---
operator: = [11539,11540]
operator: = [11506,11507]
===
match
---
trailer [13362,13439]
trailer [13329,13406]
===
match
---
name: run_id [9222,9228]
name: run_id [9189,9195]
===
match
---
name: TypeError [11937,11946]
name: TypeError [11904,11913]
===
match
---
comparison [11415,11451]
comparison [11382,11418]
===
match
---
operator: , [9474,9475]
operator: , [9441,9442]
===
match
---
expr_stmt [1809,1881]
expr_stmt [1809,1881]
===
match
---
operator: @ [12252,12253]
operator: @ [12219,12220]
===
match
---
name: value [12499,12504]
name: value [12466,12471]
===
match
---
simple_stmt [9046,9090]
simple_stmt [9013,9057]
===
match
---
name: task_id [4160,4167]
name: task_id [4127,4134]
===
match
---
atom_expr [2866,2878]
atom_expr [2866,2878]
===
match
---
name: log [1420,1423]
name: log [1420,1423]
===
match
---
simple_stmt [3441,3481]
simple_stmt [3441,3481]
===
match
---
name: append [8501,8507]
name: append [8468,8474]
===
match
---
operator: = [2772,2773]
operator: = [2772,2773]
===
match
---
operator: , [9649,9650]
operator: , [9616,9617]
===
match
---
name: delete [9464,9470]
name: delete [9431,9437]
===
match
---
suite [3176,3264]
suite [3176,3264]
===
match
---
name: Column [1821,1827]
name: Column [1821,1827]
===
match
---
operator: , [1050,1051]
operator: , [1050,1051]
===
match
---
name: Optional [4130,4138]
name: Optional [4097,4105]
===
match
---
trailer [8235,8242]
trailer [8202,8209]
===
match
---
trailer [9198,9206]
trailer [9165,9173]
===
match
---
name: str [6360,6363]
name: str [6327,6330]
===
match
---
arglist [13363,13438]
arglist [13330,13405]
===
match
---
name: execution_date [3875,3889]
name: execution_date [3843,3857]
===
match
---
atom_expr [1981,2039]
atom_expr [1981,2039]
===
match
---
name: BaseXCom [13610,13618]
name: BaseXCom [13577,13585]
===
match
---
suite [9109,9240]
suite [9076,9207]
===
match
---
name: self [2774,2778]
name: self [2774,2778]
===
match
---
trailer [8134,8150]
trailer [8101,8117]
===
match
---
name: key [8139,8142]
name: key [8106,8109]
===
match
---
name: dagrun [3316,3322]
name: dagrun [3316,3322]
===
match
---
xor_expr [5579,5622]
xor_expr [5546,5589]
===
match
---
string: "core" [13363,13369]
string: "core" [13330,13336]
===
match
---
suite [12455,12506]
suite [12422,12473]
===
match
---
atom_expr [9299,9319]
atom_expr [9266,9286]
===
match
---
name: dumps [11830,11835]
name: dumps [11797,11802]
===
match
---
operator: { [2865,2866]
operator: { [2865,2866]
===
match
---
param [10022,10046]
param [9989,10013]
===
match
---
argument [5825,5832]
argument [5792,5799]
===
match
---
import_from [1009,1079]
import_from [1009,1079]
===
match
---
arglist [2067,2091]
arglist [2067,2091]
===
match
---
string: " then you need to enable pickle support for XCom" [12121,12171]
string: " then you need to enable pickle support for XCom" [12088,12138]
===
match
---
tfpdef [4324,4340]
tfpdef [4291,4307]
===
match
---
atom_expr [2060,2092]
atom_expr [2060,2092]
===
match
---
name: key [3838,3841]
name: key [3806,3809]
===
match
---
trailer [3391,3421]
trailer [3391,3421]
===
match
---
trailer [11829,11835]
trailer [11796,11802]
===
match
---
fstring_expr [2865,2879]
fstring_expr [2865,2879]
===
match
---
try_stmt [11851,12247]
try_stmt [11818,12214]
===
match
---
if_stmt [8576,8866]
if_stmt [8543,8833]
===
match
---
string: 'UTF-8' [12603,12610]
string: 'UTF-8' [12570,12577]
===
match
---
import_name [800,814]
import_name [800,814]
===
match
---
name: resolve_xcom_backend [13275,13295]
name: resolve_xcom_backend [13242,13262]
===
match
---
name: session [4324,4331]
name: session [4291,4298]
===
match
---
name: execution_date [3680,3694]
name: execution_date [3649,3663]
===
match
---
atom_expr [8493,8530]
atom_expr [8460,8497]
===
match
---
trailer [8507,8530]
trailer [8474,8497]
===
match
---
atom_expr [3933,3949]
atom_expr [3901,3916]
===
match
---
name: is_container [8188,8200]
name: is_container [8155,8167]
===
match
---
name: append [8236,8242]
name: append [8203,8209]
===
match
---
atom_expr [3603,3759]
atom_expr [3572,3728]
===
match
---
raise_stmt [7994,8068]
raise_stmt [7961,8035]
===
match
---
parameters [9854,10052]
parameters [9821,10019]
===
match
---
if_stmt [8185,8344]
if_stmt [8152,8311]
===
match
---
trailer [11159,11217]
trailer [11126,11184]
===
match
---
string: """         Called by the ORM after the instance has been loaded from the DB or otherwise reconstituted         i.e automatically deserialize Xcom value when loading from DB.         """ [2566,2752]
string: """         Called by the ORM after the instance has been loaded from the DB or otherwise reconstituted         i.e automatically deserialize Xcom value when loading from DB.         """ [2566,2752]
===
match
---
trailer [1730,1753]
trailer [1730,1753]
===
match
---
name: dag_id [2984,2990]
name: dag_id [2984,2990]
===
match
---
comparison [11114,11128]
comparison [11081,11095]
===
match
---
trailer [11578,11585]
trailer [11545,11552]
===
match
---
name: orm_deserialize_value [12830,12851]
name: orm_deserialize_value [12797,12818]
===
match
---
operator: = [6494,6495]
operator: = [6461,6462]
===
match
---
operator: , [12748,12749]
operator: , [12715,12716]
===
match
---
if_stmt [9330,9417]
if_stmt [9297,9384]
===
match
---
trailer [4060,4069]
trailer [4027,4036]
===
match
---
name: reconstructor [1052,1065]
name: reconstructor [1052,1065]
===
match
---
name: timestamp [1809,1818]
name: timestamp [1809,1818]
===
match
---
atom_expr [12525,12547]
atom_expr [12492,12514]
===
match
---
suite [11466,11597]
suite [11433,11564]
===
match
---
trailer [9275,9290]
trailer [9242,9257]
===
match
---
trailer [12576,12582]
trailer [12543,12549]
===
match
---
name: pendulum [887,895]
name: pendulum [887,895]
===
match
---
trailer [4138,4143]
trailer [4105,4110]
===
match
---
argument [3392,3405]
argument [3392,3405]
===
match
---
trailer [9067,9072]
trailer [9034,9039]
===
match
---
fstring_string: " ( [2862,2865]
fstring_string: " ( [2862,2865]
===
match
---
operator: = [9490,9491]
operator: = [9457,9458]
===
match
---
tfpdef [10022,10038]
tfpdef [9989,10005]
===
match
---
name: append [8128,8134]
name: append [8095,8101]
===
match
---
name: execution_date [8915,8929]
name: execution_date [8882,8896]
===
match
---
suite [10898,10972]
suite [10865,10939]
===
match
---
import_as_names [1152,1180]
import_as_names [1152,1180]
===
match
---
fstring [2843,2906]
fstring [2843,2906]
===
match
---
name: association_proxy [2471,2488]
name: association_proxy [2471,2488]
===
match
---
import_from [947,1008]
import_from [947,1008]
===
match
---
argument [5755,5784]
argument [5722,5751]
===
match
---
atom_expr [2229,2457]
atom_expr [2229,2457]
===
match
---
raise_stmt [10911,10971]
raise_stmt [10878,10938]
===
match
---
trailer [13262,13268]
trailer [13229,13235]
===
match
---
operator: , [9927,9928]
operator: , [9894,9895]
===
match
---
name: error [11965,11970]
name: error [11932,11937]
===
match
---
name: Any [12311,12314]
name: Any [12278,12281]
===
match
---
name: DagRun [11513,11519]
name: DagRun [11480,11486]
===
match
---
trailer [12697,12706]
trailer [12664,12673]
===
match
---
operator: , [1065,1066]
operator: , [1065,1066]
===
match
---
name: task_id [8323,8330]
name: task_id [8290,8297]
===
match
---
name: cls [8893,8896]
name: cls [8860,8863]
===
match
---
comparison [3720,3740]
comparison [3689,3709]
===
match
---
dotted_name [9127,9148]
dotted_name [9094,9115]
===
match
---
name: Union [4238,4243]
name: Union [4205,4210]
===
match
---
trailer [12732,12748]
trailer [12699,12715]
===
match
---
operator: , [3718,3719]
operator: , [3687,3688]
===
match
---
atom_expr [2853,2861]
atom_expr [2853,2861]
===
match
---
name: resolve_xcom_backend [13696,13716]
name: resolve_xcom_backend [13663,13683]
===
match
---
suite [8971,9037]
suite [8938,9004]
===
match
---
string: "DagRun" [2251,2259]
string: "DagRun" [2251,2259]
===
match
---
atom_expr [10917,10971]
atom_expr [10884,10938]
===
match
---
name: dag_id [5884,5890]
name: dag_id [5851,5857]
===
match
---
return_stmt [9404,9416]
return_stmt [9371,9383]
===
match
---
name: loads [12672,12677]
name: loads [12639,12644]
===
match
---
operator: , [4150,4151]
operator: , [4117,4118]
===
match
---
if_stmt [13444,13667]
if_stmt [13411,13634]
===
match
---
dotted_name [1325,1346]
dotted_name [1325,1346]
===
match
---
arglist [5755,5973]
arglist [5722,5940]
===
match
---
name: limit [9333,9338]
name: limit [9300,9305]
===
match
---
atom_expr [1849,1864]
atom_expr [1849,1864]
===
match
---
fstring_expr [2852,2862]
fstring_expr [2852,2862]
===
match
---
operator: = [2033,2034]
operator: = [2033,2034]
===
match
---
atom_expr [4358,4371]
atom_expr [4325,4338]
===
match
---
name: key [2963,2966]
name: key [2963,2966]
===
match
---
atom_expr [3642,3649]
atom_expr [3611,3618]
===
match
---
name: Base [1176,1180]
name: Base [1176,1180]
===
match
---
operator: { [13609,13610]
operator: { [13576,13577]
===
match
---
trailer [12800,12806]
trailer [12767,12773]
===
match
---
operator: = [1901,1902]
operator: = [1901,1902]
===
match
---
comparison [11087,11109]
comparison [11054,11076]
===
match
---
fstring_expr [2882,2903]
fstring_expr [2882,2903]
===
match
---
name: COLLATION_ARGS [2077,2091]
name: COLLATION_ARGS [2077,2091]
===
match
---
name: session [3603,3610]
name: session [3572,3579]
===
match
---
operator: ^ [5604,5605]
operator: ^ [5571,5572]
===
match
---
name: str [4139,4142]
name: str [4106,4109]
===
match
---
trailer [11770,11802]
trailer [11737,11769]
===
match
---
atom_expr [3833,3922]
atom_expr [3801,3890]
===
match
---
trailer [8799,8865]
trailer [8766,8832]
===
match
---
trailer [9910,9919]
trailer [9877,9886]
===
match
---
trailer [8200,8210]
trailer [8167,8177]
===
match
---
trailer [6217,6222]
trailer [6184,6189]
===
match
---
name: staticmethod [11634,11646]
name: staticmethod [11601,11613]
===
match
---
trailer [3616,3621]
trailer [3585,3590]
===
match
---
if_stmt [9627,9744]
if_stmt [9594,9711]
===
match
---
for_stmt [9596,9777]
for_stmt [9563,9744]
===
match
---
arglist [1828,1880]
arglist [1828,1880]
===
match
---
if_stmt [8353,8531]
if_stmt [8320,8498]
===
match
---
tfpdef [6440,6460]
tfpdef [6407,6427]
===
match
---
name: JSONDecodeError [12733,12748]
name: JSONDecodeError [12700,12715]
===
match
---
name: cls [11308,11311]
name: cls [11275,11278]
===
match
---
name: utils [1333,1338]
name: utils [1333,1338]
===
match
---
trailer [12671,12677]
trailer [12638,12644]
===
match
---
simple_stmt [8228,8270]
simple_stmt [8195,8237]
===
match
---
decorator [12252,12266]
decorator [12219,12233]
===
match
---
suite [13298,13687]
suite [13265,13654]
===
match
---
param [9937,9956]
param [9904,9923]
===
match
---
name: execution_date [5770,5784]
name: execution_date [5737,5751]
===
match
---
operator: , [5943,5944]
operator: , [5910,5911]
===
match
---
trailer [9262,9271]
trailer [9229,9238]
===
match
---
simple_stmt [1546,1568]
simple_stmt [1546,1568]
===
match
---
simple_stmt [1568,1601]
simple_stmt [1568,1601]
===
match
---
name: key [4125,4128]
name: key [4092,4095]
===
match
---
suite [12548,12613]
suite [12515,12580]
===
match
---
name: filter [11408,11414]
name: filter [11375,11381]
===
match
---
return_stmt [6023,6042]
return_stmt [5990,6009]
===
match
---
suite [12770,12821]
suite [12737,12788]
===
match
---
operator: = [6423,6424]
operator: = [6390,6391]
===
match
---
trailer [8127,8134]
trailer [8094,8101]
===
match
---
name: ValueError [5642,5652]
name: ValueError [5609,5619]
===
match
---
trailer [2765,2771]
trailer [2765,2771]
===
match
---
funcdef [2534,2803]
funcdef [2534,2803]
===
match
---
name: xcoms [9546,9551]
name: xcoms [9513,9518]
===
match
---
name: isinstance [9634,9644]
name: isinstance [9601,9611]
===
match
---
trailer [5732,5741]
trailer [5699,5708]
===
match
---
suite [3283,3481]
suite [3283,3481]
===
match
---
trailer [8991,8998]
trailer [8958,8965]
===
match
---
simple_stmt [800,815]
simple_stmt [800,815]
===
match
---
simple_stmt [1777,1805]
simple_stmt [1777,1805]
===
match
---
expr_stmt [13689,13718]
expr_stmt [13656,13685]
===
match
---
operator: = [9949,9950]
operator: = [9916,9917]
===
match
---
name: Union [4178,4183]
name: Union [4145,4150]
===
match
---
name: key [5825,5828]
name: key [5792,5795]
===
match
---
operator: = [6223,6224]
operator: = [6190,6191]
===
match
---
atom_expr [9756,9776]
atom_expr [9723,9743]
===
match
---
name: cls [2958,2961]
name: cls [2958,2961]
===
match
---
name: value [3853,3858]
name: value [3821,3826]
===
match
---
name: ValueError [3195,3205]
name: ValueError [3195,3205]
===
match
---
return_stmt [12660,12707]
return_stmt [12627,12674]
===
match
---
name: dag_ids [8449,8456]
name: dag_ids [8416,8423]
===
match
---
name: String [1724,1730]
name: String [1724,1730]
===
match
---
name: cls [9272,9275]
name: cls [9239,9242]
===
match
---
name: str [4104,4107]
name: str [4071,4074]
===
match
---
name: Column [1903,1909]
name: Column [1903,1909]
===
match
---
string: " If you are using pickle instead of JSON for XCom," [12052,12104]
string: " If you are using pickle instead of JSON for XCom," [12019,12071]
===
match
---
operator: -> [12858,12860]
operator: -> [12825,12827]
===
match
---
simple_stmt [12472,12506]
simple_stmt [12439,12473]
===
match
---
trailer [8242,8269]
trailer [8209,8236]
===
match
---
fstring_string: ` is not a subclass of ` [13585,13609]
fstring_string: ` is not a subclass of ` [13552,13576]
===
match
---
name: provide_session [1354,1369]
name: provide_session [1354,1369]
===
match
---
trailer [11311,11319]
trailer [11278,11286]
===
match
---
return_stmt [12565,12612]
return_stmt [12532,12579]
===
match
---
argument [3860,3889]
argument [3828,3857]
===
match
---
name: provide_session [6086,6101]
name: provide_session [6053,6068]
===
match
---
tfpdef [4087,4108]
tfpdef [4054,4075]
===
match
---
tfpdef [6477,6493]
tfpdef [6444,6460]
===
match
---
name: ValueError [11925,11935]
name: ValueError [11892,11902]
===
match
---
name: session [5965,5972]
name: session [5932,5939]
===
match
---
argument [1923,1939]
argument [1923,1939]
===
match
---
operator: @ [9807,9808]
operator: @ [9774,9775]
===
match
---
name: Query [6511,6516]
name: Query [6478,6483]
===
match
---
string: "XCom" [12300,12306]
string: "XCom" [12267,12273]
===
match
---
name: DateTime [4061,4069]
name: DateTime [4028,4036]
===
match
---
operator: = [3006,3007]
operator: = [3006,3007]
===
match
---
name: self [2866,2870]
name: self [2866,2870]
===
match
---
operator: = [2105,2106]
operator: = [2105,2106]
===
match
---
operator: , [2259,2260]
operator: , [2259,2260]
===
match
---
dotted_name [11484,11505]
dotted_name [11451,11472]
===
match
---
operator: , [3011,3012]
operator: , [3011,3012]
===
match
---
trailer [11260,11341]
trailer [11227,11308]
===
match
---
name: cls [3642,3645]
name: cls [3611,3614]
===
match
---
operator: = [10039,10040]
operator: = [10006,10007]
===
match
---
name: Iterable [853,861]
name: Iterable [853,861]
===
match
---
name: DagRun [11572,11578]
name: DagRun [11539,11545]
===
match
---
operator: = [10006,10007]
operator: = [9973,9974]
===
match
---
trailer [1723,1772]
trailer [1723,1772]
===
match
---
name: xcoms [9572,9577]
name: xcoms [9539,9544]
===
match
---
name: airflow [9127,9134]
name: airflow [9094,9101]
===
match
---
parameters [12851,12857]
parameters [12818,12824]
===
match
---
atom_expr [2774,2802]
atom_expr [2774,2802]
===
match
---
name: execution_date [11419,11433]
name: execution_date [11386,11400]
===
match
---
param [12292,12306]
param [12259,12273]
===
match
---
operator: = [3456,3457]
operator: = [3456,3457]
===
match
---
simple_stmt [2044,2112]
simple_stmt [2044,2112]
===
match
---
name: utcnow [1858,1864]
name: utcnow [1858,1864]
===
match
---
decorators [9807,9841]
decorators [9774,9808]
===
match
---
name: value [2968,2973]
name: value [2968,2973]
===
match
---
trailer [12806,12820]
trailer [12773,12787]
===
match
---
arglist [1724,1771]
arglist [1724,1771]
===
match
---
simple_stmt [3603,3760]
simple_stmt [3572,3729]
===
match
---
simple_stmt [11533,11597]
simple_stmt [11500,11564]
===
match
---
name: clazz [13340,13345]
name: clazz [13307,13312]
===
match
---
expr_stmt [2462,2509]
expr_stmt [2462,2509]
===
match
---
simple_stmt [3769,3786]
simple_stmt [3738,3754]
===
match
---
name: relationship [1067,1079]
name: relationship [1067,1079]
===
match
---
comparison [5580,5602]
comparison [5547,5569]
===
match
---
name: add [3829,3832]
name: add [3797,3800]
===
match
---
operator: = [9978,9979]
operator: = [9945,9946]
===
match
---
name: session [10022,10029]
name: session [9989,9996]
===
match
---
operator: , [10012,10013]
operator: , [9979,9980]
===
match
---
name: task_id [2871,2878]
name: task_id [2871,2878]
===
match
---
name: run_id [9232,9238]
name: run_id [9199,9205]
===
match
---
name: run_id [3013,3019]
name: run_id [3013,3019]
===
match
---
name: Any [848,851]
name: Any [848,851]
===
match
---
name: UtcDateTime [1910,1921]
name: UtcDateTime [1910,1921]
===
match
---
atom_expr [6304,6317]
atom_expr [6271,6284]
===
match
---
funcdef [12826,13269]
funcdef [12793,13236]
===
match
---
trailer [11835,11842]
trailer [11802,11809]
===
match
---
name: Query [1036,1041]
name: Query [1036,1041]
===
match
---
atom_expr [4052,4069]
atom_expr [4019,4036]
===
match
---
param [4027,4078]
param [3994,4045]
===
match
---
name: primaryjoin [2269,2280]
name: primaryjoin [2269,2280]
===
match
---
name: decode [12691,12697]
name: decode [12658,12664]
===
match
---
atom_expr [5642,5710]
atom_expr [5609,5677]
===
match
---
atom_expr [3720,3730]
atom_expr [3689,3699]
===
match
---
trailer [3465,3480]
trailer [3465,3480]
===
match
---
name: result [5720,5726]
name: result [5687,5693]
===
match
---
name: query [9249,9254]
name: query [9216,9221]
===
match
---
name: task_id [1971,1978]
name: task_id [1971,1978]
===
match
---
name: get_many [6110,6118]
name: get_many [6077,6085]
===
match
---
simple_stmt [10911,10972]
simple_stmt [10878,10939]
===
match
---
name: query [11533,11538]
name: query [11500,11505]
===
match
---
if_stmt [11351,11597]
if_stmt [11318,11564]
===
match
---
name: is_container [1250,1262]
name: is_container [1250,1262]
===
match
---
operator: = [9578,9579]
operator: = [9545,9546]
===
match
---
name: classmethod [9808,9819]
name: classmethod [9775,9786]
===
match
---
import_from [3296,3336]
import_from [3296,3336]
===
match
---
param [4221,4272]
param [4188,4239]
===
match
---
trailer [13618,13627]
trailer [13585,13594]
===
match
---
argument [1736,1752]
argument [1736,1752]
===
match
---
suite [4372,6063]
suite [4339,6030]
===
match
---
funcdef [9845,11628]
funcdef [9812,11595]
===
match
---
raise_stmt [3189,3263]
raise_stmt [3189,3263]
===
match
---
name: query [9046,9051]
name: query [9013,9018]
===
match
---
funcdef [3993,6063]
funcdef [3960,6030]
===
match
---
name: airflow [1325,1332]
name: airflow [1325,1332]
===
match
---
operator: , [9867,9868]
operator: , [9834,9835]
===
match
---
name: pickle [822,828]
name: pickle [822,828]
===
match
---
operator: , [6229,6230]
operator: , [6196,6197]
===
match
---
simple_stmt [896,947]
simple_stmt [896,947]
===
match
---
trailer [4177,4204]
trailer [4144,4171]
===
match
---
simple_stmt [3296,3337]
simple_stmt [3296,3337]
===
match
---
atom_expr [1903,1940]
atom_expr [1903,1940]
===
match
---
number: 512 [1731,1734]
number: 512 [1731,1734]
===
match
---
argument [1841,1864]
argument [1841,1864]
===
match
---
operator: = [9255,9256]
operator: = [9222,9223]
===
match
---
name: task_id [10987,10994]
name: task_id [10954,10961]
===
match
---
name: cls [8999,9002]
name: cls [8966,8969]
===
match
---
name: Optional [9893,9901]
name: Optional [9860,9868]
===
match
---
atom_expr [4189,4202]
atom_expr [4156,4169]
===
match
---
name: Iterable [6365,6373]
name: Iterable [6332,6340]
===
match
---
name: encode [11893,11899]
name: encode [11860,11866]
===
match
---
trailer [8322,8330]
trailer [8289,8297]
===
match
---
arglist [9272,9319]
arglist [9239,9286]
===
match
---
simple_stmt [880,896]
simple_stmt [880,896]
===
match
---
name: include_prior_dates [4281,4300]
name: include_prior_dates [4248,4267]
===
match
---
parameters [2957,3039]
parameters [2957,3039]
===
match
---
trailer [11759,11770]
trailer [11726,11737]
===
match
---
dotted_name [1086,1107]
dotted_name [1086,1107]
===
match
---
trailer [1909,1940]
trailer [1909,1940]
===
match
---
simple_stmt [11143,11218]
simple_stmt [11110,11185]
===
match
---
expr_stmt [8078,8090]
expr_stmt [8045,8057]
===
match
---
name: key [2858,2861]
name: key [2858,2861]
===
match
---
dotted_name [1014,1028]
dotted_name [1014,1028]
===
match
---
name: value [11671,11676]
name: value [11638,11643]
===
match
---
atom_expr [12479,12505]
atom_expr [12446,12472]
===
match
---
comparison [11274,11294]
comparison [11241,11261]
===
match
---
name: delete [11619,11625]
name: delete [11586,11592]
===
match
---
name: conf [12390,12394]
name: conf [12357,12361]
===
match
---
trailer [6359,6379]
trailer [6326,6346]
===
match
---
name: one [3422,3425]
name: one [3422,3425]
===
match
---
name: dag_id [3399,3405]
name: dag_id [3399,3405]
===
match
---
atom_expr [6293,6318]
atom_expr [6260,6285]
===
match
---
fstring_expr [13609,13628]
fstring_expr [13576,13595]
===
match
---
if_stmt [7930,8069]
if_stmt [7897,8036]
===
match
---
dotted_name [1268,1299]
dotted_name [1268,1299]
===
match
---
name: Column [1785,1791]
name: Column [1785,1791]
===
match
---
name: cls [6128,6131]
name: cls [6095,6098]
===
match
---
atom_expr [8120,8150]
atom_expr [8087,8117]
===
match
---
trailer [8246,8254]
trailer [8213,8221]
===
match
---
atom_expr [9535,9558]
atom_expr [9502,9525]
===
match
---
trailer [12531,12547]
trailer [12498,12514]
===
match
---
name: utils [1229,1234]
name: utils [1229,1234]
===
match
---
if_stmt [3125,3264]
if_stmt [3125,3264]
===
match
---
operator: , [1921,1922]
operator: , [1921,1922]
===
match
---
arglist [9645,9655]
arglist [9612,9622]
===
match
---
name: pickle [12479,12485]
name: pickle [12446,12452]
===
match
---
name: query [9359,9364]
name: query [9326,9331]
===
match
---
trailer [4257,4262]
trailer [4224,4229]
===
match
---
atom_expr [4130,4143]
atom_expr [4097,4110]
===
match
---
operator: , [9481,9482]
operator: , [9448,9449]
===
match
---
trailer [5652,5710]
trailer [5619,5677]
===
match
---
name: value [12590,12595]
name: value [12557,12562]
===
match
---
name: session [9483,9490]
name: session [9450,9457]
===
match
---
atom_expr [3658,3676]
atom_expr [3627,3645]
===
match
---
name: self [2853,2857]
name: self [2853,2857]
===
match
---
atom [8088,8090]
atom [8055,8057]
===
match
---
operator: = [4341,4342]
operator: = [4308,4309]
===
match
---
name: value [11836,11841]
name: value [11803,11808]
===
match
---
name: str [4184,4187]
name: str [4151,4154]
===
match
---
param [2963,2967]
param [2963,2967]
===
match
---
operator: , [6131,6132]
operator: , [6098,6099]
===
match
---
simple_stmt [5720,5992]
simple_stmt [5687,5959]
===
match
---
argument [2003,2019]
argument [2003,2019]
===
match
---
param [9994,10013]
param [9961,9980]
===
match
---
arglist [3642,3740]
arglist [3611,3709]
===
match
---
expr_stmt [3521,3556]
expr_stmt [3490,3525]
===
match
---
operator: = [3914,3915]
operator: = [3882,3883]
===
match
---
operator: , [10045,10046]
operator: , [10012,10013]
===
match
---
comparison [8944,8970]
comparison [8911,8937]
===
match
---
atom_expr [4169,4204]
atom_expr [4136,4171]
===
match
---
expr_stmt [2761,2802]
expr_stmt [2761,2802]
===
match
---
atom_expr [8789,8865]
atom_expr [8756,8832]
===
match
---
name: str [6299,6302]
name: str [6266,6269]
===
match
---
atom [7937,7961]
atom [7904,7928]
===
match
---
name: session [11235,11242]
name: session [11202,11209]
===
match
---
name: append [8312,8318]
name: append [8279,8285]
===
match
---
name: limit [9371,9376]
name: limit [9338,9343]
===
match
---
name: delete [9764,9770]
name: delete [9731,9737]
===
match
---
simple_stmt [6051,6063]
simple_stmt [6018,6030]
===
match
---
arglist [1995,2019]
arglist [1995,2019]
===
match
---
trailer [11551,11564]
trailer [11518,11531]
===
match
---
trailer [9721,9731]
trailer [9688,9698]
===
match
---
simple_stmt [10070,10702]
simple_stmt [10037,10669]
===
match
---
name: str [4258,4261]
name: str [4225,4228]
===
match
---
simple_stmt [1181,1216]
simple_stmt [1181,1216]
===
match
---
trailer [3837,3922]
trailer [3805,3890]
===
match
---
name: clazz [13570,13575]
name: clazz [13537,13542]
===
match
---
name: dag_ids [5876,5883]
name: dag_ids [5843,5850]
===
match
---
operator: = [3841,3842]
operator: = [3809,3810]
===
match
---
fstring_expr [13418,13437]
fstring_expr [13385,13404]
===
match
---
string: "dag_run" [2489,2498]
string: "dag_run" [2489,2498]
===
match
---
name: xcoms [9608,9613]
name: xcoms [9575,9580]
===
match
---
import_name [880,895]
import_name [880,895]
===
match
---
operator: , [4187,4188]
operator: , [4154,4155]
===
match
---
name: Optional [6447,6455]
name: Optional [6414,6422]
===
match
---
operator: = [8086,8087]
operator: = [8053,8054]
===
match
---
trailer [11253,11260]
trailer [11220,11227]
===
match
---
operator: = [4144,4145]
operator: = [4111,4112]
===
match
---
name: json [11875,11879]
name: json [11842,11846]
===
match
---
name: dag_id [2044,2050]
name: dag_id [2044,2050]
===
match
---
string: "xcom" [1699,1705]
string: "xcom" [1699,1705]
===
match
---
param [6274,6327]
param [6241,6294]
===
match
---
operator: = [6320,6321]
operator: = [6287,6288]
===
match
---
name: dag_id [11278,11284]
name: dag_id [11245,11251]
===
match
---
arglist [2489,2508]
arglist [2489,2508]
===
match
---
trailer [2857,2861]
trailer [2857,2861]
===
match
---
simple_stmt [12565,12613]
simple_stmt [12532,12580]
===
match
---
suite [11948,12247]
suite [11915,12214]
===
match
---
name: key [3646,3649]
name: key [3615,3618]
===
match
---
name: run_id [5805,5811]
name: run_id [5772,5778]
===
match
---
operator: = [4109,4110]
operator: = [4076,4077]
===
match
---
trailer [4051,4070]
trailer [4018,4037]
===
match
---
operator: = [5964,5965]
operator: = [5931,5932]
===
match
---
operator: = [1584,1585]
operator: = [1584,1585]
===
match
---
operator: , [3858,3859]
operator: , [3826,3827]
===
match
---
name: COLLATION_ARGS [2005,2019]
name: COLLATION_ARGS [2005,2019]
===
match
---
name: timezone [1849,1857]
name: timezone [1849,1857]
===
match
---
decorators [2912,2946]
decorators [2912,2946]
===
match
---
name: classmethod [6069,6080]
name: classmethod [6036,6047]
===
match
---
trailer [8318,8343]
trailer [8285,8310]
===
match
---
simple_stmt [9506,9524]
simple_stmt [9473,9491]
===
match
---
simple_stmt [3049,3117]
simple_stmt [3049,3117]
===
match
---
name: commit [3777,3783]
name: flush [3746,3751]
===
match
---
name: str [4244,4247]
name: str [4211,4214]
===
match
---
name: utils [1276,1281]
name: utils [1276,1281]
===
match
---
if_stmt [13462,13646]
if_stmt [13429,13613]
===
match
---
name: Optional [863,871]
name: Optional [863,871]
===
match
---
parameters [12291,12307]
parameters [12258,12274]
===
match
---
suite [12643,12708]
suite [12610,12675]
===
match
---
name: key [6239,6242]
name: key [6206,6209]
===
match
---
name: models [9135,9141]
name: models [9102,9108]
===
match
---
expr_stmt [9572,9587]
expr_stmt [9539,9554]
===
match
---
name: xcom [9600,9604]
name: xcom [9567,9571]
===
match
---
name: decode [12596,12602]
name: decode [12563,12569]
===
match
---
trailer [2066,2092]
trailer [2066,2092]
===
match
---
name: models [1133,1139]
name: models [1133,1139]
===
match
---
operator: , [4211,4212]
operator: , [4178,4179]
===
match
---
name: filters [8878,8885]
name: filters [8845,8852]
===
match
---
not_test [10983,10994]
not_test [10950,10961]
===
match
---
atom_expr [13236,13268]
atom_expr [13203,13235]
===
match
---
name: cls [3720,3723]
name: cls [3689,3692]
===
match
---
trailer [3628,3750]
trailer [3597,3719]
===
match
---
operator: } [13627,13628]
operator: } [13594,13595]
===
match
---
trailer [2800,2802]
trailer [2800,2802]
===
match
---
name: json [795,799]
name: json [795,799]
===
match
---
trailer [11618,11625]
trailer [11585,11592]
===
match
---
suite [8364,8531]
suite [8331,8498]
===
match
---
operator: = [3852,3853]
operator: = [3820,3821]
===
match
---
name: DagRun [9215,9221]
name: DagRun [9182,9188]
===
match
---
string: 'core' [12406,12412]
string: 'core' [12373,12379]
===
match
---
trailer [8885,8892]
trailer [8852,8859]
===
match
---
name: str [10002,10005]
name: str [9969,9972]
===
match
---
name: run_id [3414,3420]
name: run_id [3414,3420]
===
match
---
atom_expr [3769,3785]
atom_expr [3738,3753]
===
match
---
operator: , [6264,6265]
operator: , [6231,6232]
===
match
---
name: conf [11755,11759]
name: conf [11722,11726]
===
match
---
simple_stmt [1263,1320]
simple_stmt [1263,1320]
===
match
---
operator: @ [2929,2930]
operator: @ [2929,2930]
===
match
---
name: filter [9208,9214]
name: filter [9175,9181]
===
match
---
trailer [8433,8458]
trailer [8400,8425]
===
match
---
comparison [3696,3718]
comparison [3665,3687]
===
match
---
trailer [12690,12697]
trailer [12657,12664]
===
match
---
operator: == [8143,8145]
operator: == [8110,8112]
===
match
---
atom_expr [6244,6257]
atom_expr [6211,6224]
===
match
---
name: value [3847,3852]
name: value [3815,3820]
===
match
---
atom_expr [12390,12437]
atom_expr [12357,12404]
===
match
---
operator: = [6258,6259]
operator: = [6225,6226]
===
match
---
name: xcoms [9581,9586]
name: xcoms [9548,9553]
===
match
---
operator: , [13369,13370]
operator: , [13336,13337]
===
match
---
decorators [3955,3989]
decorators [3922,3956]
===
match
---
name: UtcDateTime [1407,1418]
name: UtcDateTime [1407,1418]
===
match
---
trailer [6174,6183]
trailer [6141,6150]
===
match
---
operator: = [9182,9183]
operator: = [9149,9150]
===
match
---
simple_stmt [2219,2458]
simple_stmt [2219,2458]
===
match
---
name: TypeError [10917,10926]
name: TypeError [10884,10893]
===
match
---
name: logging [807,814]
name: logging [807,814]
===
match
---
name: key [3842,3845]
name: key [3810,3813]
===
match
---
name: nullable [1866,1874]
name: nullable [1866,1874]
===
match
---
atom_expr [9902,9919]
atom_expr [9869,9886]
===
match
---
name: set [2954,2957]
name: set [2954,2957]
===
match
---
fstring_end: " [13630,13631]
fstring_end: " [13597,13598]
===
match
---
name: query [3611,3616]
name: query [3580,3585]
===
match
---
testlist_comp [11925,11946]
testlist_comp [11892,11913]
===
match
---
trailer [4103,4108]
trailer [4070,4075]
===
match
---
name: desc [9313,9317]
name: desc [9280,9284]
===
match
---
fstring_end: ' [2905,2906]
fstring_end: ' [2905,2906]
===
match
---
number: 49344 [1562,1567]
number: 49344 [1562,1567]
===
match
---
return_stmt [6051,6062]
return_stmt [6018,6029]
===
match
---
return_stmt [11606,11627]
return_stmt [11573,11594]
===
match
---
atom_expr [9054,9089]
atom_expr [9021,9056]
===
match
---
parameters [4004,4354]
parameters [3971,4321]
===
match
---
name: result [6003,6009]
name: result [5970,5976]
===
match
---
operator: , [925,926]
operator: , [925,926]
===
match
---
simple_stmt [8878,8931]
simple_stmt [8845,8898]
===
match
---
name: ID_LEN [1995,2001]
name: ID_LEN [1995,2001]
===
match
---
import_from [1263,1319]
import_from [1263,1319]
===
match
---
param [2975,2983]
param [2975,2983]
===
match
---
name: COLLATION_ARGS [1738,1752]
name: COLLATION_ARGS [1738,1752]
===
match
---
name: utils [1194,1199]
name: utils [1194,1199]
===
match
---
simple_stmt [11394,11453]
simple_stmt [11361,11420]
===
match
---
simple_stmt [12874,13221]
simple_stmt [12841,13188]
===
match
---
atom_expr [6209,6222]
atom_expr [6176,6189]
===
match
---
operator: , [851,852]
operator: , [851,852]
===
match
---
name: timestamp [9303,9312]
name: timestamp [9270,9279]
===
match
---
name: execution_date [8579,8593]
name: execution_date [8546,8560]
===
match
---
atom_expr [11308,11319]
atom_expr [11275,11286]
===
match
---
xor_expr [3132,3175]
xor_expr [3132,3175]
===
match
---
name: execution_date [11087,11101]
name: execution_date [11054,11068]
===
match
---
trailer [9271,9320]
trailer [9238,9287]
===
match
---
suite [8402,8459]
suite [8369,8426]
===
match
---
comparison [8579,8601]
comparison [8546,8568]
===
match
---
fstring_string:  @  [2879,2882]
fstring_string:  @  [2879,2882]
===
match
---
name: query [9062,9067]
name: query [9029,9034]
===
match
---
simple_stmt [9176,9240]
simple_stmt [9143,9207]
===
match
---
name: LargeBinary [1792,1803]
name: LargeBinary [1792,1803]
===
match
---
trailer [3776,3783]
trailer [3745,3751]
===
match
---
tfpdef [9937,9948]
tfpdef [9904,9915]
===
match
---
operator: ^ [3157,3158]
operator: ^ [3157,3158]
===
match
---
atom_expr [1426,1453]
atom_expr [1426,1453]
===
match
---
atom_expr [4095,4108]
atom_expr [4062,4075]
===
match
---
comparison [3658,3694]
comparison [3627,3663]
===
match
---
name: filters [8078,8085]
name: filters [8045,8052]
===
match
---
atom_expr [12728,12748]
atom_expr [12695,12715]
===
match
---
tfpdef [4125,4143]
tfpdef [4092,4110]
===
match
---
suite [12865,13269]
suite [12832,13236]
===
match
---
return_stmt [12472,12505]
return_stmt [12439,12472]
===
match
---
operator: { [13569,13570]
operator: { [13536,13537]
===
match
---
name: execution_date [3860,3874]
name: execution_date [3828,3842]
===
match
---
decorated [11633,12247]
decorated [11600,12214]
===
match
---
param [9864,9868]
param [9831,9835]
===
match
---
trailer [8426,8433]
trailer [8393,8400]
===
match
---
name: task_id [3711,3718]
name: task_id [3680,3687]
===
match
---
atom_expr [6365,6378]
atom_expr [6332,6345]
===
match
---
suite [11803,11843]
suite [11770,11810]
===
match
---
simple_stmt [13671,13687]
simple_stmt [13638,13654]
===
match
---
suite [6517,9417]
suite [6484,9384]
===
match
---
trailer [9545,9558]
trailer [9512,9525]
===
match
---
expr_stmt [1886,1940]
expr_stmt [1886,1940]
===
match
---
expr_stmt [1971,2039]
expr_stmt [1971,2039]
===
match
---
string: 'UTF-8' [12698,12705]
string: 'UTF-8' [12665,12672]
===
match
---
name: primary_key [2094,2105]
name: primary_key [2094,2105]
===
match
---
name: dagrun [11499,11505]
name: dagrun [11466,11472]
===
match
---
name: value [3521,3526]
name: value [3490,3495]
===
match
---
xor_expr [11086,11129]
xor_expr [11053,11096]
===
match
---
name: XCom [9651,9655]
name: XCom [9618,9622]
===
match
---
string: """Serialize Xcom value to str or pickled object""" [11692,11743]
string: """Serialize Xcom value to str or pickled object""" [11659,11710]
===
match
---
comparison [7965,7979]
comparison [7932,7946]
===
match
---
trailer [11564,11571]
trailer [11531,11538]
===
match
---
not_test [9630,9656]
not_test [9597,9623]
===
match
---
name: DagRun [3374,3380]
name: DagRun [3374,3380]
===
match
---
argument [5876,5890]
argument [5843,5857]
===
match
---
name: XCOM_RETURN_KEY [1568,1583]
name: XCOM_RETURN_KEY [1568,1583]
===
match
---
atom_expr [12794,12820]
atom_expr [12761,12787]
===
match
---
name: execution_date [11354,11368]
name: execution_date [11321,11335]
===
match
---
name: task_ids [5846,5854]
name: task_ids [5813,5821]
===
match
---
param [4125,4151]
param [4092,4118]
===
match
---
name: cls [8135,8138]
name: cls [8102,8105]
===
match
---
operator: @ [9824,9825]
operator: @ [9791,9792]
===
match
---
param [2992,3012]
param [2992,3012]
===
match
---
operator: -> [12308,12310]
operator: -> [12275,12277]
===
match
---
name: session [3933,3940]
name: session [3901,3908]
===
match
---
argument [1755,1771]
argument [1755,1771]
===
match
---
operator: = [5828,5829]
operator: = [5795,5796]
===
match
---
dotted_name [1375,1399]
dotted_name [1375,1399]
===
match
---
return_stmt [11868,11908]
return_stmt [11835,11875]
===
match
---
operator: , [2966,2967]
operator: , [2966,2967]
===
match
---
operator: = [2051,2052]
operator: = [2051,2052]
===
match
---
name: Optional [4043,4051]
name: Optional [4010,4018]
===
match
---
decorated [2912,3950]
decorated [2912,3917]
===
match
---
trailer [1791,1804]
trailer [1791,1804]
===
match
---
trailer [6312,6317]
trailer [6279,6284]
===
match
---
trailer [9644,9656]
trailer [9611,9623]
===
match
---
name: result [6030,6036]
name: result [5997,6003]
===
match
---
simple_stmt [8078,8091]
simple_stmt [8045,8058]
===
match
---
argument [1866,1880]
argument [1866,1880]
===
match
---
atom_expr [4043,4070]
atom_expr [4010,4037]
===
match
---
operator: , [5811,5812]
operator: , [5778,5779]
===
match
---
operator: == [3650,3652]
operator: == [3619,3621]
===
match
---
operator: , [1734,1735]
operator: , [1734,1735]
===
match
---
operator: , [2973,2974]
operator: , [2973,2974]
===
match
---
decorator [11633,11647]
decorator [11600,11614]
===
match
---
simple_stmt [6526,7922]
simple_stmt [6493,7889]
===
match
---
trailer [9689,9743]
trailer [9656,9710]
===
match
---
trailer [11418,11433]
trailer [11385,11400]
===
match
---
argument [2075,2091]
argument [2075,2091]
===
match
---
param [3013,3025]
param [3013,3025]
===
match
---
trailer [8138,8142]
trailer [8105,8109]
===
match
---
atom_expr [3458,3480]
atom_expr [3458,3480]
===
match
---
name: reconstructor [2516,2529]
name: reconstructor [2516,2529]
===
match
---
return_stmt [13671,13686]
return_stmt [13638,13653]
===
match
---
name: dag_run [3350,3357]
name: dag_run [3350,3357]
===
match
---
name: filter_by [3382,3391]
name: filter_by [3382,3391]
===
match
---
operator: = [5727,5728]
operator: = [5694,5695]
===
match
---
suite [8172,8344]
suite [8139,8311]
===
match
---
operator: , [5862,5863]
operator: , [5829,5830]
===
match
---
name: session [3026,3033]
name: session [3026,3033]
===
match
---
simple_stmt [9249,9321]
simple_stmt [9216,9288]
===
match
---
simple_stmt [5636,5711]
simple_stmt [5603,5678]
===
match
---
trailer [9901,9920]
trailer [9868,9887]
===
match
---
simple_stmt [9785,9802]
simple_stmt [9752,9769]
===
match
---
name: classmethod [9423,9434]
name: classmethod [9390,9401]
===
match
---
trailer [8511,8518]
trailer [8478,8485]
===
match
---
comparison [3642,3656]
comparison [3611,3625]
===
match
---
name: result [12492,12498]
name: result [12459,12465]
===
match
---
name: clazz [13447,13452]
name: clazz [13414,13419]
===
match
---
name: uselist [2437,2444]
name: uselist [2437,2444]
===
match
---
trailer [3750,3757]
trailer [3719,3726]
===
match
---
trailer [2059,2111]
trailer [2059,2111]
===
match
---
name: dag_ids [6336,6343]
name: dag_ids [6303,6310]
===
match
---
atom [11113,11129]
atom [11080,11096]
===
match
---
classdef [1603,13269]
classdef [1603,13236]
===
match
---
expr_stmt [11227,11341]
expr_stmt [11194,11308]
===
match
---
trailer [11964,11970]
trailer [11931,11937]
===
match
---
name: include_prior_dates [5924,5943]
name: include_prior_dates [5891,5910]
===
match
---
param [2821,2825]
param [2821,2825]
===
match
---
comparison [9215,9238]
comparison [9182,9205]
===
match
---
simple_stmt [947,1009]
simple_stmt [947,1009]
===
match
---
name: limit [9365,9370]
name: limit [9332,9337]
===
match
---
name: task_ids [8334,8342]
name: task_ids [8301,8309]
===
match
---
name: pendulum [6166,6174]
name: pendulum [6133,6141]
===
match
---
operator: = [11233,11234]
operator: = [11200,11201]
===
match
---
fstring_expr [13569,13585]
fstring_expr [13536,13552]
===
match
---
atom_expr [11274,11284]
atom_expr [11241,11251]
===
match
---
if_stmt [9099,9240]
if_stmt [9066,9207]
===
match
---
fstring [13543,13631]
fstring [13510,13598]
===
match
---
name: orm [1025,1028]
name: orm [1025,1028]
===
match
---
operator: , [938,939]
operator: , [938,939]
===
match
---
trailer [12813,12819]
trailer [12780,12786]
===
match
---
name: task_id [3899,3906]
name: task_id [3867,3874]
===
match
---
simple_stmt [815,829]
simple_stmt [815,829]
===
match
---
suite [12626,12821]
suite [12593,12788]
===
match
---
name: clazz [13661,13666]
name: clazz [13628,13633]
===
match
---
comparison [8508,8529]
comparison [8475,8496]
===
match
---
param [9483,9495]
param [9450,9462]
===
match
---
dotted_name [1186,1199]
dotted_name [1186,1199]
===
match
---
name: models [3309,3315]
name: models [3309,3315]
===
match
---
trailer [9370,9377]
trailer [9337,9344]
===
match
---
tfpdef [12292,12306]
tfpdef [12259,12273]
===
match
---
atom_expr [9184,9239]
atom_expr [9151,9206]
===
match
---
name: join [11547,11551]
name: join [11514,11518]
===
match
---
name: task_id [3891,3898]
name: task_id [3859,3866]
===
match
---
arglist [2251,2451]
arglist [2251,2451]
===
match
---
param [4160,4212]
param [4127,4179]
===
match
---
name: airflow [1375,1382]
name: airflow [1375,1382]
===
match
---
name: filter [9073,9079]
name: filter [9040,9046]
===
match
---
atom_expr [4249,4262]
atom_expr [4216,4229]
===
match
---
trailer [2887,2902]
trailer [2887,2902]
===
match
---
if_stmt [8100,8151]
if_stmt [8067,8118]
===
match
---
trailer [9799,9801]
trailer [9766,9768]
===
match
---
trailer [6298,6318]
trailer [6265,6285]
===
match
---
operator: = [9921,9922]
operator: = [9888,9889]
===
match
---
trailer [5741,5983]
trailer [5708,5950]
===
match
---
not_test [13465,13496]
not_test [13432,13463]
===
match
---
atom_expr [8319,8330]
atom_expr [8286,8297]
===
match
---
atom_expr [11235,11341]
atom_expr [11202,11308]
===
match
---
operator: , [11935,11936]
operator: , [11902,11903]
===
match
---
name: Union [6293,6298]
name: Union [6260,6265]
===
match
---
trailer [8311,8318]
trailer [8278,8285]
===
match
---
param [6397,6431]
param [6364,6398]
===
match
---
fstring [13396,13438]
fstring [13363,13405]
===
match
---
operator: , [2498,2499]
operator: , [2498,2499]
===
match
---
suite [5623,5711]
suite [5590,5678]
===
match
---
operator: == [3677,3679]
operator: == [3646,3648]
===
match
---
operator: = [4307,4308]
operator: = [4274,4275]
===
match
---
atom_expr [6345,6380]
atom_expr [6312,6347]
===
match
---
subscriptlist [4184,4202]
subscriptlist [4151,4169]
===
match
---
name: value [1777,1782]
name: value [1777,1782]
===
match
---
name: XCom [13689,13693]
name: XCom [13656,13660]
===
match
---
operator: @ [9439,9440]
operator: @ [9406,9407]
===
match
---
name: delete [3751,3757]
name: delete [3720,3726]
===
match
---
name: timezone [1207,1215]
name: timezone [1207,1215]
===
match
---
name: primary_key [1923,1934]
name: primary_key [1923,1934]
===
match
---
atom_expr [8984,9036]
atom_expr [8951,9003]
===
match
---
suite [11130,11218]
suite [11097,11185]
===
match
---
name: result [12583,12589]
name: result [12550,12556]
===
match
---
trailer [9002,9017]
trailer [8969,8984]
===
match
---
name: dag_id [4221,4227]
name: dag_id [4188,4194]
===
match
---
simple_stmt [12660,12708]
simple_stmt [12627,12675]
===
match
---
operator: -> [10053,10055]
operator: -> [10020,10022]
===
match
---
name: DagRun [9156,9162]
name: DagRun [9123,9129]
===
match
---
trailer [1994,2020]
trailer [1994,2020]
===
match
---
trailer [12595,12602]
trailer [12562,12569]
===
match
---
decorator [9807,9820]
decorator [9774,9787]
===
match
---
operator: ^ [7962,7963]
operator: ^ [7929,7930]
===
match
---
trailer [11414,11452]
trailer [11381,11419]
===
match
---
trailer [3421,3425]
trailer [3421,3425]
===
match
---
name: execution_date [9003,9017]
name: execution_date [8970,8984]
===
match
---
name: classmethod [3956,3967]
name: classmethod [3923,3934]
===
match
---
name: provide_session [9825,9840]
name: provide_session [9792,9807]
===
match
---
trailer [13575,13584]
trailer [13542,13551]
===
match
---
atom_expr [8508,8518]
atom_expr [8475,8485]
===
match
---
trailer [8892,8930]
trailer [8859,8897]
===
match
---
atom_expr [4178,4203]
atom_expr [4145,4170]
===
match
---
trailer [12602,12611]
trailer [12569,12578]
===
match
---
arglist [11771,11801]
arglist [11738,11768]
===
match
---
operator: , [871,872]
operator: , [871,872]
===
match
---
operator: , [3845,3846]
operator: , [3813,3814]
===
match
---
operator: * [9080,9081]
operator: * [9047,9048]
===
match
---
trailer [8392,8401]
trailer [8359,8368]
===
match
---
name: Session [10031,10038]
name: Session [9998,10005]
===
match
---
trailer [4197,4202]
trailer [4164,4169]
===
match
---
name: typing [834,840]
name: typing [834,840]
===
match
---
simple_stmt [788,800]
simple_stmt [788,800]
===
match
---
string: 'enable_xcom_pickling' [12414,12436]
string: 'enable_xcom_pickling' [12381,12403]
===
match
---
name: run_id [7965,7971]
name: run_id [7932,7938]
===
match
---
name: task_id [11312,11319]
name: task_id [11279,11286]
===
match
---
name: dag_run [2219,2226]
name: dag_run [2219,2226]
===
match
---
simple_stmt [1320,1370]
simple_stmt [1320,1370]
===
match
---
trailer [1827,1881]
trailer [1827,1881]
===
match
---
decorator [6068,6081]
decorator [6035,6048]
===
match
---
name: pickle [11823,11829]
name: pickle [11790,11796]
===
match
---
tfpdef [11671,11681]
tfpdef [11638,11648]
===
match
---
name: dag_run [3458,3465]
name: dag_run [3458,3465]
===
match
---
trailer [8254,8258]
trailer [8221,8225]
===
match
---
trailer [3549,3556]
trailer [3518,3525]
===
match
---
name: deserialize_value [12274,12291]
name: deserialize_value [12241,12258]
===
match
---
operator: ** [2003,2005]
operator: ** [2003,2005]
===
match
---
operator: , [2073,2074]
operator: , [2073,2074]
===
match
---
simple_stmt [4381,5564]
simple_stmt [4348,5531]
===
match
---
param [4281,4315]
param [4248,4282]
===
match
---
name: filters [8984,8991]
name: filters [8951,8958]
===
match
---
name: __name__ [13619,13627]
name: __name__ [13586,13594]
===
match
---
atom_expr [5729,5991]
atom_expr [5696,5958]
===
match
---
funcdef [11651,12247]
funcdef [11618,12214]
===
match
---
trailer [8444,8448]
trailer [8411,8415]
===
match
---
operator: = [5804,5805]
operator: = [5771,5772]
===
match
---
name: cls [5729,5732]
name: cls [5696,5699]
===
match
---
name: run_id [2462,2468]
name: run_id [2462,2468]
===
match
---
operator: = [3527,3528]
operator: = [3496,3497]
===
match
---
atom_expr [3360,3427]
atom_expr [3360,3427]
===
match
---
name: execution_date [6141,6155]
name: execution_date [6108,6122]
===
match
---
simple_stmt [1216,1263]
simple_stmt [1216,1263]
===
match
---
name: task_id [2975,2982]
name: task_id [2975,2982]
===
match
---
operator: , [4347,4348]
operator: , [4314,4315]
===
match
---
operator: = [13694,13695]
operator: = [13661,13662]
===
match
---
atom_expr [8434,8457]
atom_expr [8401,8424]
===
match
---
operator: , [4115,4116]
operator: , [4082,4083]
===
match
---
subscriptlist [4244,4262]
subscriptlist [4211,4229]
===
match
---
atom_expr [9215,9228]
atom_expr [9182,9195]
===
match
---
string: """         Store an XCom value.          :return: None         """ [3049,3116]
string: """         Store an XCom value.          :return: None         """ [3049,3116]
===
match
---
name: execution_date [1886,1900]
name: execution_date [1886,1900]
===
match
---
parameters [2820,2826]
parameters [2820,2826]
===
match
---
operator: } [2902,2903]
operator: } [2902,2903]
===
match
---
operator: == [11285,11287]
operator: == [11252,11254]
===
match
---
argument [2022,2038]
argument [2022,2038]
===
match
---
trailer [3381,3391]
trailer [3381,3391]
===
match
---
name: filters [8228,8235]
name: filters [8195,8202]
===
match
---
name: __tablename__ [1683,1696]
name: __tablename__ [1683,1696]
===
match
---
operator: = [5923,5924]
operator: = [5890,5891]
===
match
---
name: key [8146,8149]
name: key [8113,8116]
===
match
---
name: getboolean [11760,11770]
name: getboolean [11727,11737]
===
match
---
trailer [9221,9228]
trailer [9188,9195]
===
match
---
name: query [9411,9416]
name: query [9378,9383]
===
match
---
atom_expr [9680,9743]
atom_expr [9647,9710]
===
match
---
comparison [8135,8149]
comparison [8102,8116]
===
match
---
name: airflow [1186,1193]
name: airflow [1186,1193]
===
match
---
name: filters [9081,9088]
name: filters [9048,9055]
===
match
---
atom_expr [9272,9297]
atom_expr [9239,9264]
===
match
---
trailer [11546,11551]
trailer [11513,11518]
===
match
---
name: TypeError [13516,13525]
name: TypeError [13483,13492]
===
match
---
name: dagrun [9142,9148]
name: dagrun [9109,9115]
===
match
---
trailer [9214,9239]
trailer [9181,9206]
===
match
---
operator: = [13395,13396]
operator: = [13362,13363]
===
match
---
string: 'core' [11771,11777]
string: 'core' [11738,11744]
===
match
---
atom_expr [9893,9920]
atom_expr [9860,9887]
===
match
---
suite [10061,11628]
suite [10028,11595]
===
match
---
atom_expr [11961,12228]
atom_expr [11928,12195]
===
match
---
name: association_proxy [991,1008]
name: association_proxy [991,1008]
===
match
---
trailer [12589,12595]
trailer [12556,12562]
===
match
---
name: Iterable [4189,4197]
name: Iterable [4156,4164]
===
match
---
trailer [3373,3381]
trailer [3373,3381]
===
match
---
arglist [3392,3420]
arglist [3392,3420]
===
match
---
name: key [8103,8106]
name: key [8070,8073]
===
match
---
name: staticmethod [12253,12265]
name: staticmethod [12220,12232]
===
match
---
param [2984,2991]
param [2984,2991]
===
match
---
simple_stmt [9756,9777]
simple_stmt [9723,9744]
===
match
---
argument [5904,5943]
argument [5871,5910]
===
match
---
return_stmt [11816,11842]
return_stmt [11783,11809]
===
match
---
funcdef [9460,9802]
funcdef [9427,9769]
===
match
---
string: "Exactly one of execution_date or run_id must be passed" [8011,8067]
string: "Exactly one of execution_date or run_id must be passed" [7978,8034]
===
match
---
operator: , [9297,9298]
operator: , [9264,9265]
===
match
---
decorator [9824,9841]
decorator [9791,9808]
===
match
---
name: dag_run [9199,9206]
name: dag_run [9166,9173]
===
match
---
trailer [9731,9740]
trailer [9698,9707]
===
match
---
comparison [8319,8342]
comparison [8286,8309]
===
match
---
name: key [1711,1714]
name: key [1711,1714]
===
match
---
name: run_id [11589,11595]
name: run_id [11556,11562]
===
match
---
operator: = [5883,5884]
operator: = [5850,5851]
===
match
---
name: query [11243,11248]
name: query [11210,11215]
===
match
---
atom_expr [6030,6042]
atom_expr [5997,6009]
===
match
---
argument [3891,3906]
argument [3859,3874]
===
match
---
simple_stmt [3189,3264]
simple_stmt [3189,3264]
===
match
---
operator: = [1934,1935]
operator: = [1934,1935]
===
match
---
comparison [7938,7960]
comparison [7905,7927]
===
match
---
trailer [4237,4264]
trailer [4204,4231]
===
match
---
trailer [9302,9312]
trailer [9269,9279]
===
match
---
name: cls [11415,11418]
name: cls [11382,11385]
===
match
---
simple_stmt [13510,13646]
simple_stmt [13477,13613]
===
match
---
operator: , [6302,6303]
operator: , [6269,6270]
===
match
---
param [6128,6132]
param [6095,6099]
===
match
---
name: Session [1043,1050]
name: Session [1043,1050]
===
match
---
operator: , [6387,6388]
operator: , [6354,6355]
===
match
---
atom_expr [2761,2771]
atom_expr [2761,2771]
===
match
---
if_stmt [5572,5711]
if_stmt [5539,5678]
===
match
---
trailer [9312,9317]
trailer [9279,9284]
===
match
---
suite [9339,9378]
suite [9306,9345]
===
match
---
name: log [1282,1285]
name: log [1282,1285]
===
match
---
atom_expr [6284,6319]
atom_expr [6251,6286]
===
match
---
name: Session [4333,4340]
name: Session [4300,4307]
===
match
---
trailer [1443,1453]
trailer [1443,1453]
===
match
---
simple_stmt [1711,1773]
simple_stmt [1711,1773]
===
match
---
operator: , [6191,6192]
operator: , [6158,6159]
===
match
---
name: task_id [8247,8254]
name: task_id [8214,8221]
===
match
---
name: cls [8243,8246]
name: cls [8210,8213]
===
match
---
atom [12727,12769]
atom [12694,12736]
===
match
---
operator: , [13485,13486]
operator: , [13452,13453]
===
match
---
name: filters [8120,8127]
name: filters [8087,8094]
===
match
---
name: serialize_value [3534,3549]
name: serialize_value [3503,3518]
===
match
---
simple_stmt [2836,2907]
simple_stmt [2836,2907]
===
match
---
trailer [4183,4203]
trailer [4150,4170]
===
match
---
suite [2827,2907]
suite [2827,2907]
===
match
---
atom [11086,11110]
atom [11053,11077]
===
match
---
file_input [788,13719]
file_input [788,13686]
===
match
---
simple_stmt [9572,9588]
simple_stmt [9539,9555]
===
match
---
decorated [6068,9417]
decorated [6035,9384]
===
match
---
strings [11988,12214]
strings [11955,12181]
===
match
---
decorators [6068,6102]
decorators [6035,6069]
===
match
---
name: dumps [11880,11885]
name: dumps [11847,11852]
===
match
---
name: order_by [9263,9271]
name: order_by [9230,9238]
===
match
---
name: primary_key [1755,1766]
name: primary_key [1755,1766]
===
match
---
name: dag_ids [8522,8529]
name: dag_ids [8489,8496]
===
match
---
atom_expr [1988,2020]
atom_expr [1988,2020]
===
match
---
name: query [9184,9189]
name: query [9151,9156]
===
match
---
operator: == [9018,9020]
operator: == [8985,8987]
===
match
---
suite [8107,8151]
suite [8074,8118]
===
match
---
name: TypeError [11014,11023]
name: TypeError [10981,10990]
===
match
---
operator: , [11294,11295]
operator: , [11261,11262]
===
match
---
fstring_expr [9716,9741]
fstring_expr [9683,9708]
===
match
---
operator: = [1874,1875]
operator: = [1874,1875]
===
match
---
param [6440,6468]
param [6407,6435]
===
match
---
trailer [9770,9776]
trailer [9737,9743]
===
match
---
name: conf [1115,1119]
name: conf [1115,1119]
===
match
---
name: self [2761,2765]
name: self [2761,2765]
===
match
---
simple_stmt [12324,12379]
simple_stmt [12291,12346]
===
match
---
name: loads [12801,12806]
name: loads [12768,12773]
===
match
---
expr_stmt [3350,3427]
expr_stmt [3350,3427]
===
match
---
operator: { [2852,2853]
operator: { [2852,2853]
===
match
---
parameters [13295,13297]
parameters [13262,13264]
===
match
---
name: cls [3696,3699]
name: cls [3665,3668]
===
match
---
raise_stmt [11008,11069]
raise_stmt [10975,11036]
===
match
---
trailer [9295,9297]
trailer [9262,9264]
===
match
---
suite [9497,9802]
suite [9464,9769]
===
match
---
atom_expr [4229,4264]
atom_expr [4196,4231]
===
match
---
argument [2437,2450]
argument [2437,2450]
===
match
---
name: str [6313,6316]
name: str [6280,6283]
===
match
---
trailer [9792,9799]
trailer [9759,9766]
===
match
---
operator: -> [6508,6510]
operator: -> [6475,6477]
===
match
---
name: query [9176,9181]
name: query [9143,9148]
===
match
---
name: result [12678,12684]
name: result [12645,12651]
===
match
---
return_stmt [13654,13666]
return_stmt [13621,13633]
===
match
---
atom_expr [11402,11452]
atom_expr [11369,11419]
===
match
---
name: UnicodeDecodeError [12750,12768]
name: UnicodeDecodeError [12717,12735]
===
match
---
operator: = [3019,3020]
operator: = [3019,3020]
===
match
---
name: task_ids [6274,6282]
name: task_ids [6241,6249]
===
match
---
operator: , [1839,1840]
operator: , [1839,1840]
===
match
---
name: __name__ [13428,13436]
name: __name__ [13395,13403]
===
match
---
expr_stmt [11394,11452]
expr_stmt [11361,11419]
===
match
---
not_test [7933,7980]
not_test [7900,7947]
===
match
---
simple_stmt [11227,11342]
simple_stmt [11194,11309]
===
match
---
name: airflow [11484,11491]
name: airflow [11451,11458]
===
match
---
name: run_id [3407,3413]
name: run_id [3407,3413]
===
match
---
tfpdef [4221,4264]
tfpdef [4188,4231]
===
match
---
name: str [6218,6221]
name: str [6185,6188]
===
match
---
name: Optional [4169,4177]
name: Optional [4136,4144]
===
match
---
name: execution_date [8944,8958]
name: execution_date [8911,8925]
===
match
---
trailer [9194,9207]
trailer [9161,9174]
===
match
---
atom_expr [11415,11433]
atom_expr [11382,11400]
===
match
---
operator: , [861,862]
operator: , [861,862]
===
match
---
name: getboolean [12395,12405]
name: getboolean [12362,12372]
===
match
---
suite [7981,8069]
suite [7948,8036]
===
match
---
name: dag_run [11556,11563]
name: dag_run [11523,11530]
===
match
---
if_stmt [10884,10972]
if_stmt [10851,10939]
===
match
---
name: dag_ids [8356,8363]
name: dag_ids [8323,8330]
===
match
---
operator: , [6467,6468]
operator: , [6434,6435]
===
match
---
operator: = [1979,1980]
operator: = [1979,1980]
===
match
---
operator: , [1174,1175]
operator: , [1174,1175]
===
match
---
name: configuration [1094,1107]
name: configuration [1094,1107]
===
match
---
operator: , [13385,13386]
operator: , [13352,13353]
===
match
---
atom_expr [11875,11908]
atom_expr [11842,11875]
===
match
---
atom_expr [8380,8401]
atom_expr [8347,8368]
===
match
---
trailer [8896,8911]
trailer [8863,8878]
===
match
---
operator: , [9551,9552]
operator: , [9518,9519]
===
match
---
name: task_id [5855,5862]
name: task_id [5822,5829]
===
match
---
atom_expr [11755,11802]
atom_expr [11722,11769]
===
match
---
name: Union [6354,6359]
name: Union [6321,6326]
===
match
---
name: commit [9793,9799]
name: commit [9760,9766]
===
match
---
decorator [3972,3989]
decorator [3939,3956]
===
match
---
name: query [11394,11399]
name: query [11361,11366]
===
match
---
expr_stmt [2219,2457]
expr_stmt [2219,2457]
===
match
---
trailer [9072,9079]
trailer [9039,9046]
===
match
---
comparison [3160,3174]
comparison [3160,3174]
===
match
---
simple_stmt [11008,11070]
simple_stmt [10975,11037]
===
match
---
name: serialize_value [11655,11670]
name: serialize_value [11622,11637]
===
match
---
operator: , [11777,11778]
operator: , [11744,11745]
===
match
---
name: dag_id [10891,10897]
name: dag_id [10858,10864]
===
match
---
name: DateTime [6175,6183]
name: DateTime [6142,6150]
===
match
---
simple_stmt [7994,8069]
simple_stmt [7961,8036]
===
match
---
param [2958,2962]
param [2958,2962]
===
match
---
name: execution_date [3466,3480]
name: execution_date [3466,3480]
===
match
---
simple_stmt [8120,8151]
simple_stmt [8087,8118]
===
match
---
expr_stmt [2044,2111]
expr_stmt [2044,2111]
===
match
---
operator: @ [6085,6086]
operator: @ [6052,6053]
===
match
---
name: value [12685,12690]
name: value [12652,12657]
===
match
---
atom_expr [4238,4263]
atom_expr [4205,4230]
===
match
---
tfpdef [4027,4070]
tfpdef [3994,4037]
===
match
---
name: str [9974,9977]
name: str [9941,9944]
===
match
---
name: loads [12486,12491]
name: loads [12453,12458]
===
match
---
name: getLogger [1434,1443]
name: getLogger [1434,1443]
===
match
---
name: cls [9195,9198]
name: cls [9162,9165]
===
match
---
funcdef [6106,9417]
funcdef [6073,9384]
===
match
---
expr_stmt [1711,1772]
expr_stmt [1711,1772]
===
match
---
operator: , [2092,2093]
operator: , [2092,2093]
===
match
---
name: append [8427,8433]
name: append [8394,8400]
===
match
---
simple_stmt [11868,11909]
simple_stmt [11835,11876]
===
match
---
operator: = [6461,6462]
operator: = [6428,6429]
===
match
---
param [9471,9475]
param [9438,9442]
===
match
---
name: dag_id [3915,3921]
name: dag_id [3883,3889]
===
match
---
name: get_many [5733,5741]
name: get_many [5700,5708]
===
match
---
name: filters [8304,8311]
name: filters [8271,8278]
===
match
---
atom_expr [11572,11585]
atom_expr [11539,11552]
===
match
---
trailer [3828,3832]
trailer [3796,3800]
===
match
---
atom_expr [11149,11217]
atom_expr [11116,11184]
===
match
---
name: query [11227,11232]
name: query [11194,11199]
===
match
---
trailer [6036,6042]
trailer [6003,6009]
===
match
---
name: execution_date [2992,3006]
name: execution_date [2992,3006]
===
match
---
name: Session [6486,6493]
name: Session [6453,6460]
===
match
---
argument [3908,3921]
argument [3876,3889]
===
match
---
name: execution_date [3441,3455]
name: execution_date [3441,3455]
===
match
---
name: task_id [3700,3707]
name: task_id [3669,3676]
===
match
---
tfpdef [4281,4306]
tfpdef [4248,4273]
===
match
---
name: session [5957,5964]
name: session [5924,5931]
===
match
---
simple_stmt [1081,1120]
simple_stmt [1081,1120]
===
match
---
if_stmt [8377,8531]
if_stmt [8344,8498]
===
match
---
name: helpers [1235,1242]
name: helpers [1235,1242]
===
match
---
decorated [9807,11628]
decorated [9774,11595]
===
match
---
name: BaseXCom [13419,13427]
name: BaseXCom [13386,13394]
===
match
---
trailer [11555,11563]
trailer [11522,11530]
===
match
---
string: "clear() missing required argument: dag_id" [10927,10970]
string: "clear() missing required argument: dag_id" [10894,10937]
===
match
---
name: airflow [1221,1228]
name: airflow [1221,1228]
===
match
---
name: pickle [12525,12531]
name: pickle [12492,12498]
===
match
---
suite [8211,8270]
suite [8178,8237]
===
match
---
name: __name__ [1444,1452]
name: __name__ [1444,1452]
===
match
---
string: """Resolves custom XCom class""" [13303,13335]
string: """Resolves custom XCom class""" [13270,13302]
===
match
---
atom_expr [13419,13436]
atom_expr [13386,13403]
===
match
---
name: relationship [2229,2241]
name: relationship [2229,2241]
===
match
---
name: filter [11565,11571]
name: filter [11532,11538]
===
match
---
name: xcom [9645,9649]
name: xcom [9612,9616]
===
match
---
fstring_string: Your custom XCom class ` [13545,13569]
fstring_string: Your custom XCom class ` [13512,13536]
===
match
---
trailer [6165,6184]
trailer [6132,6151]
===
match
---
trailer [9364,9370]
trailer [9331,9337]
===
match
---
operator: , [2961,2962]
operator: , [2961,2962]
===
match
---
name: bool [6418,6422]
name: bool [6385,6389]
===
match
---
trailer [11248,11253]
trailer [11215,11220]
===
match
---
name: LargeBinary [927,938]
name: LargeBinary [927,938]
===
match
---
atom_expr [8999,9017]
atom_expr [8966,8984]
===
match
---
param [6239,6265]
param [6206,6232]
===
match
---
trailer [11571,11596]
trailer [11538,11563]
===
match
---
param [4014,4018]
param [3981,3985]
===
match
---
expr_stmt [1568,1600]
expr_stmt [1568,1600]
===
match
---
suite [10995,11070]
suite [10962,11037]
===
match
---
trailer [6292,6319]
trailer [6259,6286]
===
match
---
name: result [12807,12813]
name: result [12774,12780]
===
match
---
simple_stmt [11606,11628]
simple_stmt [11573,11595]
===
match
---
name: session [9756,9763]
name: session [9723,9730]
===
match
---
name: __name__ [9732,9740]
name: __name__ [9699,9707]
===
match
---
suite [12438,12613]
suite [12405,12580]
===
match
---
fstring_string: airflow.models.xcom. [13398,13418]
fstring_string: airflow.models.xcom. [13365,13385]
===
match
---
operator: @ [9422,9423]
operator: @ [9389,9390]
===
match
---
atom_expr [12492,12504]
atom_expr [12459,12471]
===
match
---
name: dag_id [11288,11294]
name: dag_id [11255,11261]
===
match
---
atom_expr [3529,3556]
atom_expr [3498,3525]
===
match
---
name: Optional [4095,4103]
name: Optional [4062,4070]
===
match
---
atom_expr [11552,11563]
atom_expr [11519,11530]
===
match
---
name: airflow [3301,3308]
name: airflow [3301,3308]
===
match
---
name: ValueError [11149,11159]
name: ValueError [11116,11126]
===
match
---
fstring_string: )> [2903,2905]
fstring_string: )> [2903,2905]
===
match
---
name: ID_LEN [1168,1174]
name: ID_LEN [1168,1174]
===
match
---
simple_stmt [9352,9378]
simple_stmt [9319,9345]
===
match
---
operator: = [4071,4072]
operator: = [4038,4039]
===
match
---
name: limit [6440,6445]
name: limit [6407,6412]
===
match
---
except_clause [12518,12547]
except_clause [12485,12514]
===
match
---
name: run_id [5798,5804]
name: run_id [5765,5771]
===
match
---
decorated [9422,9802]
decorated [9389,9769]
===
match
---
name: run_id [9994,10000]
name: run_id [9961,9967]
===
match
---
name: query [3368,3373]
name: query [3368,3373]
===
match
---
simple_stmt [11692,11744]
simple_stmt [11659,11711]
===
match
---
name: execution_date [7938,7952]
name: execution_date [7905,7919]
===
match
---
name: sqlalchemy [901,911]
name: sqlalchemy [901,911]
===
match
---
param [9877,9928]
param [9844,9895]
===
match
---
simple_stmt [1120,1181]
simple_stmt [1120,1181]
===
match
---
name: Iterable [4249,4257]
name: Iterable [4216,4224]
===
match
---
if_stmt [12387,12821]
if_stmt [12354,12788]
===
match
---
name: execution_date [2888,2902]
name: execution_date [2888,2902]
===
match
---
operator: , [4017,4018]
operator: , [3984,3985]
===
match
---
trailer [3533,3549]
trailer [3502,3518]
===
match
---
atom_expr [8419,8458]
atom_expr [8386,8425]
===
match
---
simple_stmt [1809,1882]
simple_stmt [1809,1882]
===
match
---
name: BaseXCom [13678,13686]
name: BaseXCom [13645,13653]
===
match
---
operator: ** [2075,2077]
operator: ** [2075,2077]
===
match
---
trailer [4243,4263]
trailer [4210,4230]
===
match
---
name: String [940,946]
name: String [940,946]
===
match
---
name: sqlalchemy [1014,1024]
name: sqlalchemy [1014,1024]
===
match
---
operator: , [3405,3406]
operator: , [3405,3406]
===
match
---
simple_stmt [3350,3428]
simple_stmt [3350,3428]
===
match
---
if_stmt [8160,8344]
if_stmt [8127,8311]
===
match
---
operator: = [6381,6382]
operator: = [6348,6349]
===
match
---
name: json [12728,12732]
name: json [12695,12699]
===
match
---
operator: , [3694,3695]
operator: , [3663,3664]
===
match
---
tfpdef [6141,6184]
tfpdef [6108,6151]
===
match
---
operator: == [8519,8521]
operator: == [8486,8488]
===
match
---
expr_stmt [9249,9320]
expr_stmt [9216,9287]
===
match
---
name: get_one [3997,4004]
name: get_one [3964,3971]
===
match
---
param [12852,12856]
param [12819,12823]
===
match
---
trailer [1433,1443]
trailer [1433,1443]
===
match
---
operator: , [6500,6501]
operator: , [6467,6468]
===
match
---
name: execution_date [9021,9035]
name: execution_date [8988,9002]
===
match
---
name: execution_date [3133,3147]
name: execution_date [3133,3147]
===
match
---
name: task_id [11323,11330]
name: task_id [11290,11297]
===
match
---
atom [11924,11947]
atom [11891,11914]
===
match
---
atom_expr [3696,3707]
atom_expr [3665,3676]
===
match
---
trailer [13427,13436]
trailer [13394,13403]
===
match
---
import_as_names [919,946]
import_as_names [919,946]
===
match
---
import_from [896,946]
import_from [896,946]
===
match
---
name: xcom [9771,9775]
name: xcom [9738,9742]
===
match
---
string: """Deserialize XCom value from str or pickle object""" [12324,12378]
string: """Deserialize XCom value from str or pickle object""" [12291,12345]
===
match
---
name: self [2883,2887]
name: self [2883,2887]
===
match
---
operator: = [9052,9053]
operator: = [9019,9020]
===
match
---
name: deserialize_value [13245,13262]
name: deserialize_value [13212,13229]
===
match
---
trailer [3699,3707]
trailer [3668,3676]
===
match
---
operator: @ [2515,2516]
operator: @ [2515,2516]
===
match
---
param [6477,6501]
param [6444,6468]
===
match
---
name: Optional [6244,6252]
name: Optional [6211,6219]
===
match
---
string: """         Retrieve an XCom value, optionally meeting certain criteria. Returns None         of there are no results.          ``run_id`` and ``execution_date`` are mutually exclusive.          :param execution_date: Execution date for the task         :type execution_date: pendulum.datetime         :param run_id: Dag run id for the task         :type run_id: str         :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. To remove the filter, pass key=None.         :type key: str         :param task_id: Only XComs from task with matching id will be             pulled. Can pass None to remove the filter.         :type task_id: str         :param dag_id: If provided, only pulls XCom from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XCom from the current             execution_date are returned. If True, XCom from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: database session         :type session: sqlalchemy.orm.session.Session         """ [4381,5563]
string: """         Retrieve an XCom value, optionally meeting certain criteria. Returns None         of there are no results.          ``run_id`` and ``execution_date`` are mutually exclusive.          :param execution_date: Execution date for the task         :type execution_date: pendulum.datetime         :param run_id: Dag run id for the task         :type run_id: str         :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. To remove the filter, pass key=None.         :type key: str         :param task_id: Only XComs from task with matching id will be             pulled. Can pass None to remove the filter.         :type task_id: str         :param dag_id: If provided, only pulls XCom from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_id: str         :param include_prior_dates: If False, only XCom from the current             execution_date are returned. If True, XCom from previous dates             are returned as well.         :type include_prior_dates: bool         :param session: database session         :type session: sqlalchemy.orm.session.Session         """ [4348,5530]
===
match
---
name: LoggingMixin [1307,1319]
name: LoggingMixin [1307,1319]
===
match
---
param [6201,6230]
param [6168,6197]
===
match
---
atom [5579,5603]
atom [5546,5570]
===
match
---
import_from [1081,1119]
import_from [1081,1119]
===
match
---
name: filter [3622,3628]
name: filter [3591,3597]
===
match
---
atom_expr [13610,13627]
atom_expr [13577,13594]
===
match
---
fstring_string: <XCom " [2845,2852]
fstring_string: <XCom " [2845,2852]
===
match
---
expr_stmt [11533,11596]
expr_stmt [11500,11563]
===
match
---
name: provide_session [9440,9455]
name: provide_session [9407,9422]
===
match
---
name: Optional [6157,6165]
name: Optional [6124,6132]
===
match
---
atom_expr [8304,8343]
atom_expr [8271,8310]
===
match
---
simple_stmt [1370,1419]
simple_stmt [1370,1419]
===
match
---
name: Any [12861,12864]
name: Any [12828,12831]
===
match
---
simple_stmt [1420,1454]
simple_stmt [1420,1454]
===
match
---
operator: = [4205,4206]
operator: = [4172,4173]
===
match
---
name: Column [1717,1723]
name: Column [1717,1723]
===
match
---
name: airflow [1086,1093]
name: airflow [1086,1093]
===
match
---
trailer [12677,12707]
trailer [12644,12674]
===
match
---
simple_stmt [8419,8459]
simple_stmt [8386,8426]
===
match
---
tfpdef [6201,6222]
tfpdef [6168,6189]
===
match
---
tfpdef [9994,10005]
tfpdef [9961,9972]
===
match
---
name: utils [1383,1388]
name: utils [1383,1388]
===
match
---
expr_stmt [13340,13439]
expr_stmt [13307,13406]
===
match
---
simple_stmt [3933,3950]
simple_stmt [3901,3917]
===
match
---
param [9965,9985]
param [9932,9952]
===
match
---
atom_expr [1724,1753]
atom_expr [1724,1753]
===
match
---
atom [3132,3156]
atom [3132,3156]
===
match
---
except_clause [12720,12769]
except_clause [12687,12736]
===
match
---
operator: @ [3972,3973]
operator: @ [3939,3940]
===
match
---
operator: { [13418,13419]
operator: { [13385,13386]
===
match
---
operator: { [9716,9717]
operator: { [9683,9684]
===
match
---
trailer [9079,9089]
trailer [9046,9056]
===
match
---
suite [2557,2803]
suite [2557,2803]
===
match
---
operator: ^ [11111,11112]
operator: ^ [11078,11079]
===
match
---
atom_expr [9785,9801]
atom_expr [9752,9768]
===
match
---
atom_expr [9195,9206]
atom_expr [9162,9173]
===
match
---
import_from [9122,9162]
import_from [9089,9129]
===
match
---
trailer [3947,3949]
trailer [3914,3916]
===
match
---
simple_stmt [13340,13440]
simple_stmt [13307,13407]
===
match
---
simple_stmt [8304,8344]
simple_stmt [8271,8311]
===
match
---
name: ext [963,966]
name: ext [963,966]
===
match
---
argument [9080,9088]
argument [9047,9055]
===
match
---
argument [5846,5862]
argument [5813,5829]
===
match
---
trailer [8437,8444]
trailer [8404,8411]
===
match
---
import_from [1120,1180]
import_from [1120,1180]
===
match
---
trailer [3645,3649]
trailer [3614,3618]
===
match
---
atom_expr [2883,2902]
atom_expr [2883,2902]
===
match
---
if_stmt [11079,11218]
if_stmt [11046,11185]
===
match
---
simple_stmt [12241,12247]
simple_stmt [12208,12214]
===
match
---
fstring_string: `. [13628,13630]
fstring_string: `. [13595,13597]
===
match
---
comp_op [8959,8965]
comp_op [8926,8932]
===
match
---
name: run_id [6201,6207]
name: run_id [6168,6174]
===
match
---
name: BaseXCom [13236,13244]
name: BaseXCom [13203,13211]
===
match
---
import_name [815,828]
import_name [815,828]
===
match
---
string: """Delete Xcom""" [9506,9523]
string: """Delete Xcom""" [9473,9490]
===
match
---
operator: -> [4355,4357]
operator: -> [4322,4324]
===
match
---
name: Column [2053,2059]
name: Column [2053,2059]
===
match
---
name: cls [11274,11277]
name: cls [11241,11244]
===
match
---
tfpdef [6336,6380]
tfpdef [6303,6347]
===
match
---
trailer [1857,1864]
trailer [1857,1864]
===
match
---
operator: , [12412,12413]
operator: , [12379,12380]
===
match
---
name: in_ [8255,8258]
name: in_ [8222,8225]
===
match
---
name: ValueError [8000,8010]
name: ValueError [7967,7977]
===
match
---
name: issubclass [13469,13479]
name: issubclass [13436,13446]
===
match
---
trailer [11885,11892]
trailer [11852,11859]
===
match
---
name: run_id [3276,3282]
name: run_id [3276,3282]
===
match
---
operator: @ [3955,3956]
operator: @ [3922,3923]
===
match
---
not_test [5575,5622]
not_test [5542,5589]
===
match
---
atom_expr [13570,13584]
atom_expr [13537,13551]
===
match
---
atom_expr [8135,8142]
atom_expr [8102,8109]
===
match
---
trailer [13525,13645]
trailer [13492,13612]
===
match
---
name: include_prior_dates [5904,5923]
name: include_prior_dates [5871,5890]
===
match
---
atom_expr [13696,13718]
atom_expr [13663,13685]
===
match
---
funcdef [2950,3950]
funcdef [2950,3917]
===
match
---
operator: = [3898,3899]
operator: = [3866,3867]
===
match
---
atom_expr [13348,13439]
atom_expr [13315,13406]
===
match
---
simple_stmt [12787,12821]
simple_stmt [12754,12788]
===
match
---
operator: , [6430,6431]
operator: , [6397,6398]
===
match
---
name: Optional [4358,4366]
name: Optional [4325,4333]
===
match
---
operator: @ [11633,11634]
operator: @ [11600,11601]
===
match
---
operator: , [3024,3025]
operator: , [3024,3025]
===
match
---
comparison [8999,9035]
comparison [8966,9002]
===
match
---
import_from [11479,11519]
import_from [11446,11486]
===
match
---
name: dag_id [3734,3740]
name: dag_id [3703,3709]
===
match
---
operator: , [1864,1865]
operator: , [1864,1865]
===
match
---
suite [11855,11909]
suite [11822,11876]
===
match
---
argument [3838,3845]
argument [3806,3813]
===
match
---
tfpdef [6239,6257]
tfpdef [6206,6224]
===
match
---
trailer [13716,13718]
trailer [13683,13685]
===
match
---
operator: , [1041,1042]
operator: , [1041,1042]
===
match
---
atom [7964,7980]
atom [7931,7947]
===
match
---
operator: , [9984,9985]
operator: , [9951,9952]
===
match
---
simple_stmt [9404,9417]
simple_stmt [9371,9384]
===
match
---
simple_stmt [9674,9744]
simple_stmt [9641,9711]
===
match
---
name: join [9190,9194]
name: join [9157,9161]
===
match
---
operator: = [1819,1820]
operator: = [1819,1820]
===
match
---
dotted_name [1125,1144]
dotted_name [1125,1144]
===
match
---
decorators [9422,9456]
decorators [9389,9423]
===
match
---
trailer [3661,3676]
trailer [3630,3645]
===
match
---
name: Column [1981,1987]
name: Column [1981,1987]
===
match
---
parameters [2550,2556]
parameters [2550,2556]
===
match
---
decorated [12252,12821]
decorated [12219,12788]
===
match
---
tfpdef [6397,6422]
tfpdef [6364,6389]
===
match
---
operator: <= [8912,8914]
operator: <= [8879,8881]
===
match
---
operator: , [2982,2983]
operator: , [2982,2983]
===
match
---
suite [8602,8866]
suite [8569,8833]
===
match
---
simple_stmt [8984,9037]
simple_stmt [8951,9004]
===
match
---
comparison [11572,11595]
comparison [11539,11562]
===
match
---
argument [5798,5811]
argument [5765,5778]
===
match
---
comparison [3133,3155]
comparison [3133,3155]
===
match
---
suite [9614,9777]
suite [9581,9744]
===
match
---
param [2551,2555]
param [2551,2555]
===
match
---
string: 'enable_xcom_pickling' [11779,11801]
string: 'enable_xcom_pickling' [11746,11768]
===
match
---
name: session [3360,3367]
name: session [3360,3367]
===
match
---
tfpdef [9965,9977]
tfpdef [9932,9944]
===
match
---
argument [2094,2110]
argument [2094,2110]
===
match
---
operator: , [5832,5833]
operator: , [5799,5800]
===
match
---
name: value [3550,3555]
name: value [3519,3524]
===
match
---
operator: = [1848,1849]
operator: = [1848,1849]
===
match
---
suite [11381,11453]
suite [11348,11420]
===
match
---
arglist [13480,13495]
arglist [13447,13462]
===
match
---
operator: = [5854,5855]
operator: = [5821,5822]
===
match
---
trailer [8258,8268]
trailer [8225,8235]
===
match
---
name: session [9785,9792]
name: session [9752,9759]
===
match
---
string: "Exactly one of execution_date or run_id must be passed" [3206,3262]
string: "Exactly one of execution_date or run_id must be passed" [3206,3262]
===
match
---
operator: , [5972,5973]
operator: , [5939,5940]
===
match
---
name: loads [12577,12582]
name: loads [12544,12549]
===
match
---
trailer [3621,3628]
trailer [3590,3597]
===
match
---
name: cls [3658,3661]
name: cls [3627,3630]
===
match
---
suite [6010,6043]
suite [5977,6010]
===
match
---
name: pickle [12794,12800]
name: pickle [12761,12767]
===
match
---
operator: = [3413,3414]
operator: = [3413,3414]
===
match
---
operator: } [2878,2879]
operator: } [2878,2879]
===
match
---
operator: = [13346,13347]
operator: = [13313,13314]
===
match
---
decorator [9439,9456]
decorator [9406,9423]
===
match
---
argument [3407,3420]
argument [3407,3420]
===
match
---
trailer [13352,13362]
trailer [13319,13329]
===
match
---
trailer [10926,10971]
trailer [10893,10938]
===
match
---
comparison [8893,8929]
comparison [8860,8896]
===
match
---
trailer [12405,12437]
trailer [12372,12404]
===
match
---
subscriptlist [6360,6378]
subscriptlist [6327,6345]
===
match
---
name: __class__ [9722,9731]
name: __class__ [9689,9698]
===
match
---
atom_expr [1785,1804]
atom_expr [1785,1804]
===
match
---
name: dag_ids [8393,8400]
name: dag_ids [8360,8367]
===
match
---
name: clear [9849,9854]
name: clear [9816,9821]
===
match
---
import_as_names [1036,1079]
import_as_names [1036,1079]
===
match
---
name: session [9054,9061]
name: session [9021,9028]
===
match
---
funcdef [12270,12821]
funcdef [12237,12788]
===
match
---
suite [13453,13667]
suite [13420,13634]
===
match
---
if_stmt [10980,11070]
if_stmt [10947,11037]
===
match
---
name: dag_id [3908,3914]
name: dag_id [3876,3882]
===
match
---
trailer [12684,12690]
trailer [12651,12657]
===
match
---
operator: , [4314,4315]
operator: , [4281,4282]
===
match
---
string: "clear() missing required argument: task_id" [11024,11068]
string: "clear() missing required argument: task_id" [10991,11035]
===
match
---
decorator [6085,6102]
decorator [6052,6069]
===
match
---
fstring_start: f' [2843,2845]
fstring_start: f' [2843,2845]
===
match
---
name: clazz [13480,13485]
name: clazz [13447,13452]
===
match
---
expr_stmt [9046,9089]
expr_stmt [9013,9056]
===
match
---
simple_stmt [11479,11520]
simple_stmt [11446,11487]
===
match
---
name: dag_id [9937,9943]
name: dag_id [9904,9910]
===
match
---
name: run_id [11579,11585]
name: run_id [11546,11552]
===
match
---
name: execution_date [4027,4041]
name: execution_date [3994,4008]
===
match
---
trailer [8448,8457]
trailer [8415,8424]
===
match
---
trailer [12498,12504]
trailer [12465,12471]
===
match
---
atom_expr [11014,11069]
atom_expr [10981,11036]
===
match
---
import_as_names [848,878]
import_as_names [848,878]
===
match
---
simple_stmt [8493,8531]
simple_stmt [8460,8498]
===
match
---
operator: , [3656,3657]
operator: , [3625,3626]
===
match
---
name: pendulum [9902,9910]
name: pendulum [9869,9877]
===
match
---
trailer [11879,11885]
trailer [11846,11852]
===
match
---
trailer [8500,8507]
trailer [8467,8474]
===
match
---
name: cls [8508,8511]
name: cls [8475,8478]
===
match
---
operator: } [13436,13437]
operator: } [13403,13404]
===
match
---
name: filters [8419,8426]
name: filters [8386,8393]
===
match
---
atom_expr [8878,8930]
atom_expr [8845,8897]
===
match
---
comp_op [11369,11375]
comp_op [11336,11342]
===
match
---
return_stmt [13229,13268]
return_stmt [13196,13235]
===
match
---
atom [3159,3175]
atom [3159,3175]
===
match
---
operator: , [11330,11331]
operator: , [11297,11298]
===
match
---
name: key [5829,5832]
name: key [5796,5799]
===
match
---
name: cls [11249,11252]
name: cls [11216,11219]
===
match
---
arglist [9546,9557]
arglist [9513,9524]
===
match
---
string: "Using include_prior_dates needs an execution_date to be passed" [8800,8864]
string: "Using include_prior_dates needs an execution_date to be passed" [8767,8831]
===
match
---
operator: == [3731,3733]
operator: == [3700,3702]
===
match
---
simple_stmt [1009,1080]
simple_stmt [1009,1080]
===
match
---
return_stmt [2836,2906]
return_stmt [2836,2906]
===
match
---
string: "Exactly one of execution_date or run_id must be passed" [5653,5709]
string: "Exactly one of execution_date or run_id must be passed" [5620,5676]
===
match
---
name: Any [11678,11681]
name: Any [11645,11648]
===
match
---
name: DagRun [3330,3336]
name: DagRun [3330,3336]
===
match
---
operator: == [9229,9231]
operator: == [9196,9198]
===
match
---
name: sqlalchemy [952,962]
name: sqlalchemy [952,962]
===
match
---
name: Column [919,925]
name: Column [919,925]
===
match
---
operator: { [2882,2883]
operator: { [2882,2883]
===
match
---
name: str [9945,9948]
name: str [9912,9915]
===
match
---
suite [9657,9744]
suite [9624,9711]
===
match
---
name: XCom [3529,3533]
name: XCom [3498,3502]
===
match
---
comparison [11354,11380]
comparison [11321,11347]
===
match
---
operator: = [1697,1698]
operator: = [1697,1698]
===
match
---
atom_expr [12667,12707]
atom_expr [12634,12674]
===
match
---
operator: , [3906,3907]
operator: , [3874,3875]
===
match
---
trailer [6373,6378]
trailer [6340,6345]
===
match
---
name: MAX_XCOM_SIZE [1546,1559]
name: MAX_XCOM_SIZE [1546,1559]
===
match
---
funcdef [2808,2907]
funcdef [2808,2907]
===
match
---
name: json [12667,12671]
name: json [12634,12638]
===
match
---
name: query [11541,11546]
name: query [11508,11513]
===
match
---
trailer [9763,9770]
trailer [9730,9737]
===
match
---
arglist [3838,3921]
arglist [3806,3889]
===
match
---
operator: == [11586,11588]
operator: == [11553,11555]
===
match
---
name: cls [4014,4017]
name: cls [3981,3984]
===
match
---
operator: , [4077,4078]
operator: , [4044,4045]
===
match
---
atom_expr [12678,12706]
atom_expr [12645,12673]
===
match
---
operator: , [2450,2451]
operator: , [2450,2451]
===
match
---
suite [12315,12821]
suite [12282,12788]
===
match
---
name: cls [11552,11555]
name: cls [11519,11522]
===
match
---
import_from [1320,1369]
import_from [1320,1369]
===
match
---
trailer [11023,11069]
trailer [10990,11036]
===
match
---
decorated [2515,2803]
decorated [2515,2803]
===
match
---
name: session [1339,1346]
name: session [1339,1346]
===
match
---
atom [9580,9587]
atom [9547,9554]
===
match
---
name: TypeError [9680,9689]
name: TypeError [9647,9656]
===
match
---
operator: == [11434,11436]
operator: == [11401,11403]
===
match
---
name: value [6037,6042]
name: value [6004,6009]
===
match
---
name: orm_deserialize_value [2779,2800]
name: orm_deserialize_value [2779,2800]
===
match
---
trailer [8010,8068]
trailer [7977,8035]
===
match
---
atom_expr [11541,11596]
atom_expr [11508,11563]
===
match
---
raise_stmt [13510,13645]
raise_stmt [13477,13612]
===
match
---
simple_stmt [6023,6043]
simple_stmt [5990,6010]
===
match
---
atom_expr [9257,9320]
atom_expr [9224,9287]
===
match
---
atom_expr [8893,8911]
atom_expr [8860,8878]
===
match
---
atom_expr [2053,2111]
atom_expr [2053,2111]
===
match
---
atom_expr [11823,11842]
atom_expr [11790,11809]
===
match
---
if_stmt [9532,9588]
if_stmt [9499,9555]
===
match
---
trailer [9189,9194]
trailer [9156,9161]
===
match
---
name: execution_date [3662,3676]
name: execution_date [3631,3645]
===
match
---
operator: = [2469,2470]
operator: = [2469,2470]
===
match
---
trailer [13244,13262]
trailer [13211,13229]
===
match
---
expr_stmt [1420,1453]
expr_stmt [1420,1453]
===
match
---
name: in_ [8445,8448]
name: in_ [8412,8415]
===
match
---
trailer [3832,3923]
trailer [3800,3891]
===
match
---
simple_stmt [13689,13719]
simple_stmt [13656,13686]
===
match
---
comparison [11308,11330]
comparison [11275,11297]
===
match
---
name: session [3769,3776]
name: session [3738,3745]
===
match
---
raise_stmt [11143,11217]
raise_stmt [11110,11184]
===
match
---
name: str [4198,4201]
name: str [4165,4168]
===
match
---
import_from [1181,1215]
import_from [1181,1215]
===
match
---
name: dag_id [3392,3398]
name: dag_id [3392,3398]
===
match
---
atom_expr [13469,13496]
atom_expr [13436,13463]
===
match
---
string: """         Composes a query to get one or more values from the xcom table.          ``run_id`` and ``execution_date`` are mutually exclusive.          :param execution_date: Execution date for the task         :type execution_date: pendulum.datetime         :param run_id: Dag run id for the task         :type run_id: str         :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_ids: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_ids: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param limit: If required, limit the number of returned objects.             XCom objects can be quite big and you might want to limit the             number of rows.         :type limit: int         :param session: database session         :type session: sqlalchemy.orm.session.Session         """ [6526,7921]
string: """         Composes a query to get one or more values from the xcom table.          ``run_id`` and ``execution_date`` are mutually exclusive.          :param execution_date: Execution date for the task         :type execution_date: pendulum.datetime         :param run_id: Dag run id for the task         :type run_id: str         :param key: A key for the XCom. If provided, only XComs with matching             keys will be returned. To remove the filter, pass key=None.         :type key: str         :param task_ids: Only XComs from tasks with matching ids will be             pulled. Can pass None to remove the filter.         :type task_ids: str or iterable of strings (representing task_ids)         :param dag_ids: If provided, only pulls XComs from this DAG.             If None (default), the DAG of the calling task is used.         :type dag_ids: str         :param include_prior_dates: If False, only XComs from the current             execution_date are returned. If True, XComs from previous dates             are returned as well.         :type include_prior_dates: bool         :param limit: If required, limit the number of returned objects.             XCom objects can be quite big and you might want to limit the             number of rows.         :type limit: int         :param session: database session         :type session: sqlalchemy.orm.session.Session         """ [6493,7888]
===
match
---
atom_expr [8188,8210]
atom_expr [8155,8177]
===
match
---
name: Any [4367,4370]
name: Any [4334,4337]
===
match
---
name: first [5984,5989]
name: first [5951,5956]
===
match
---
if_stmt [6000,6043]
if_stmt [5967,6010]
===
match
---
trailer [12485,12491]
trailer [12452,12458]
===
match
---
simple_stmt [1971,2040]
simple_stmt [1971,2040]
===
match
---
simple_stmt [1886,1941]
simple_stmt [1886,1941]
===
match
---
name: desc [9291,9295]
name: desc [9258,9262]
===
match
---
not_test [11082,11129]
not_test [11049,11096]
===
match
---
atom_expr [9634,9656]
atom_expr [9601,9623]
===
match
---
name: String [1988,1994]
name: String [1988,1994]
===
match
---
trailer [4366,4371]
trailer [4333,4338]
===
match
---
operator: , [4247,4248]
operator: , [4214,4215]
===
match
---
param [6336,6388]
param [6303,6355]
===
match
---
expr_stmt [1777,1804]
expr_stmt [1777,1804]
===
match
---
simple_stmt [13303,13336]
simple_stmt [13270,13303]
===
match
---
operator: == [8331,8333]
operator: == [8298,8300]
===
match
---
name: dag_id [8438,8444]
name: dag_id [8405,8411]
===
match
---
name: sqlalchemy [1389,1399]
name: sqlalchemy [1389,1399]
===
match
---
atom_expr [12807,12819]
atom_expr [12774,12786]
===
match
---
fstring_start: f' [9690,9692]
fstring_start: f' [9657,9659]
===
match
---
name: key [3653,3656]
name: key [3622,3625]
===
match
---
simple_stmt [11816,11843]
simple_stmt [11783,11810]
===
match
---
suite [1638,13269]
suite [1638,13236]
===
match
---
name: run_id [11114,11120]
name: run_id [11081,11087]
===
match
---
name: base [1140,1144]
name: base [1140,1144]
===
match
---
subscriptlist [6299,6317]
subscriptlist [6266,6284]
===
match
---
name: ID_LEN [2067,2073]
name: ID_LEN [2067,2073]
===
match
---
name: self [2551,2555]
name: self [2551,2555]
===
match
---
name: json [12572,12576]
name: json [12539,12543]
===
match
---
operator: , [1166,1167]
operator: , [1166,1167]
===
match
---
name: __repr__ [2812,2820]
name: __repr__ [2812,2820]
===
match
---
simple_stmt [3821,3924]
simple_stmt [3789,3892]
===
match
---
name: Optional [6209,6217]
name: Optional [6176,6184]
===
match
---
string: " in your airflow config." [12188,12214]
string: " in your airflow config." [12155,12181]
===
match
---
name: run_id [3160,3166]
name: run_id [3160,3166]
===
match
---
operator: , [2001,2002]
operator: , [2001,2002]
===
match
---
import_from [829,878]
import_from [829,878]
===
match
---
name: task_ids [8163,8171]
name: task_ids [8130,8138]
===
match
---
name: log [11961,11964]
name: log [11928,11931]
===
match
---
name: Optional [6284,6292]
name: Optional [6251,6259]
===
match
---
name: logging [1426,1433]
name: logging [1426,1433]
===
match
---
fstring_start: f" [13543,13545]
fstring_start: f" [13510,13512]
===
match
---
trailer [11242,11248]
trailer [11209,11215]
===
match
---
atom_expr [6447,6460]
atom_expr [6414,6427]
===
match
---
dotted_name [952,983]
dotted_name [952,983]
===
match
---
decorator [2912,2925]
decorator [2912,2925]
===
match
---
name: models [11492,11498]
name: models [11459,11465]
===
match
---
suite [11683,12247]
suite [11650,12214]
===
match
---
operator: , [6326,6327]
operator: , [6293,6294]
===
match
---
name: cls [9068,9071]
name: cls [9035,9038]
===
match
---
trailer [2870,2878]
trailer [2870,2878]
===
match
---
trailer [11970,12228]
trailer [11937,12195]
===
match
---
suite [8287,8344]
suite [8254,8311]
===
match
---
name: run_id [5607,5613]
name: run_id [5574,5580]
===
match
---
operator: } [2861,2862]
operator: } [2861,2862]
===
match
---
trailer [3757,3759]
trailer [3726,3728]
===
match
---
simple_stmt [3521,3557]
simple_stmt [3490,3526]
===
match
---
arglist [1910,1939]
arglist [1910,1939]
===
match
---
name: bool [4302,4306]
name: bool [4269,4273]
===
match
---
name: self [12852,12856]
name: self [12819,12823]
===
match
---
name: Optional [6345,6353]
name: Optional [6312,6320]
===
match
---
trailer [6455,6460]
trailer [6422,6427]
===
match
---
simple_stmt [829,879]
simple_stmt [829,879]
===
match
---
argument [2269,2427]
argument [2269,2427]
===
match
---
trailer [9207,9214]
trailer [9174,9181]
===
match
---
parameters [11670,11682]
parameters [11637,11649]
===
match
---
trailer [3723,3730]
trailer [3692,3699]
===
match
---
name: task_id [9965,9972]
name: task_id [9932,9939]
===
match
---
operator: , [2427,2428]
operator: , [2427,2428]
===
match
---
atom_expr [1821,1881]
atom_expr [1821,1881]
===
match
---
trailer [3940,3947]
trailer [3908,3914]
===
match
---
trailer [5989,5991]
trailer [5956,5958]
===
match
---
param [11671,11681]
param [11638,11648]
===
match
---
name: str [6253,6256]
name: str [6220,6223]
===
match
---
suite [9559,9588]
suite [9526,9555]
===
match
---
name: __name__ [13576,13584]
name: __name__ [13543,13551]
===
match
---
name: execution_date [5755,5769]
name: execution_date [5722,5736]
===
match
---
import_name [788,799]
import_name [788,799]
===
match
---
name: run_id [9102,9108]
name: run_id [9069,9075]
===
match
---
atom_expr [1717,1772]
atom_expr [1717,1772]
===
match
---
name: DateTime [9911,9919]
name: DateTime [9878,9886]
===
match
---
operator: } [13584,13585]
operator: } [13551,13552]
===
match
---
name: str [6374,6377]
name: str [6341,6344]
===
match
---
fstring_end: " [13437,13438]
fstring_end: " [13404,13405]
===
match
---
name: query [11402,11407]
name: query [11369,11374]
===
match
---
name: filter [11254,11260]
name: filter [11221,11227]
===
match
---
operator: = [11400,11401]
operator: = [11367,11368]
===
match
---
name: XCom [9553,9557]
name: XCom [9520,9524]
===
match
---
operator: == [3708,3710]
operator: == [3677,3679]
===
match
---
string: 'return_value' [1586,1600]
string: 'return_value' [1586,1600]
===
match
---
arglist [1731,1752]
arglist [1731,1752]
===
match
---
if_stmt [11752,11843]
if_stmt [11719,11810]
===
match
---
atom_expr [13516,13645]
atom_expr [13483,13612]
===
match
---
name: xcom [9717,9721]
name: xcom [9684,9688]
===
match
---
trailer [11407,11414]
trailer [11374,11381]
===
match
---
string: "run_id" [2500,2508]
string: "run_id" [2500,2508]
===
match
---
trailer [6353,6380]
trailer [6320,6347]
===
match
---
return_stmt [9352,9377]
return_stmt [9319,9344]
===
match
---
operator: , [2990,2991]
operator: , [2990,2991]
===
match
---
decorator [2929,2946]
decorator [2929,2946]
===
match
---
atom_expr [8000,8068]
atom_expr [7967,8035]
===
match
---
operator: = [4265,4266]
operator: = [4232,4233]
===
match
---
name: run_id [4087,4093]
name: run_id [4054,4060]
===
match
---
name: session [3821,3828]
name: session [3789,3796]
===
match
---
fstring_string: Expected XCom; received  [9692,9716]
fstring_string: Expected XCom; received  [9659,9683]
===
match
---
name: xcoms [9476,9481]
name: xcoms [9443,9448]
===
match
---
string: """         Clears all XCom data from the database for the task instance          ``run_id`` and ``execution_date`` are mutually exclusive.          :param execution_date: Execution date for the task         :type execution_date: pendulum.datetime or None         :param dag_id: ID of DAG to clear the XCom for.         :type dag_id: str         :param task_id: Only XComs from task with matching id will be cleared.         :type task_id: str         :param run_id: Dag run id for the task         :type run_id: str or None         :param session: database session         :type session: sqlalchemy.orm.session.Session         """ [10070,10701]
string: """         Clears all XCom data from the database for the task instance          ``run_id`` and ``execution_date`` are mutually exclusive.          :param execution_date: Execution date for the task         :type execution_date: pendulum.datetime or None         :param dag_id: ID of DAG to clear the XCom for.         :type dag_id: str         :param task_id: Only XComs from task with matching id will be cleared.         :type task_id: str         :param run_id: Dag run id for the task         :type run_id: str or None         :param session: database session         :type session: sqlalchemy.orm.session.Session         """ [10037,10668]
===
match
---
param [4324,4348]
param [4291,4315]
===
match
---
try_stmt [12451,12613]
try_stmt [12418,12580]
===
match
---
operator: = [3033,3034]
operator: = [3033,3034]
===
match
---
string: "xcom_backend" [13371,13385]
string: "xcom_backend" [13338,13352]
===
match
---
operator: , [5890,5891]
operator: , [5857,5858]
===
match
---
name: getimport [13353,13362]
name: getimport [13320,13329]
===
match
---
import_from [1216,1262]
import_from [1216,1262]
===
match
---
param [2968,2974]
param [2968,2974]
===
match
---
name: Iterable [6304,6312]
name: Iterable [6271,6279]
===
match
---
name: task_ids [8259,8267]
name: task_ids [8226,8234]
===
match
---
atom_expr [8228,8269]
atom_expr [8195,8236]
===
match
---
name: cls [8434,8437]
name: cls [8401,8404]
===
match
---
atom_expr [11613,11627]
atom_expr [11580,11594]
===
insert-node
---
name: BaseXCom [1609,1617]
to
classdef [1603,13269]
at 0
===
insert-tree
---
arglist [1618,1636]
    name: Base [1618,1622]
    operator: , [1622,1623]
    name: LoggingMixin [1624,1636]
to
classdef [1603,13269]
at 1
===
insert-tree
---
simple_stmt [1643,1678]
    string: """Base class for XCom objects.""" [1643,1677]
to
suite [1638,13269]
at 0
===
update-node
---
name: commit [3777,3783]
replace commit by flush
===
update-node
---
name: commit [3941,3947]
replace commit by flush
===
delete-node
---
name: BaseXCom [1609,1617]
===
===
delete-tree
---
arglist [1618,1636]
    name: Base [1618,1622]
    operator: , [1622,1623]
    name: LoggingMixin [1624,1636]
===
delete-tree
---
simple_stmt [1643,1678]
    string: """Base class for XCom objects.""" [1643,1677]
===
delete-tree
---
simple_stmt [3490,3512]
    atom_expr [3490,3511]
        name: session [3490,3497]
        trailer [3497,3509]
            name: expunge_all [3498,3509]
        trailer [3509,3511]
